/**
 * game.js — PILOTAGE. Bring a generated fishing fleet home to its moorings among the islands at dusk.
 *
 * ONE SENTENCE OF DESIGN: every boat needs a mooring of her own and a boat once moored stays, and the nearest free
 * mooring is the wrong one — the obvious pilot (join the closest boat and mooring, repeat) strands a far boat with a far
 * mooring. The proved-least towing for the whole fleet (anchorage.js solve(), an exact DP over subsets) is the par.
 * The insight, which the game never prints until a pass: never keep two tows that would both be shorter swapped.
 *
 * ⛔ THE PRIMARY INPUT IS A HOLD / DRAG (wing §0a-2): hold a direction and the pilot launch steers through the channels
 *    one cell at a time while the TOW number updates every step; on touch or with a mouse she steers to where the
 *    finger is. Z is the one press: take the boat you are on in tow, or moor her on the free mooring you are on.
 * ⛔ THE ONE NUMBER (the aux screen's model, which is what the par measures): a tow is the boat's SHORTEST way through
 *    the channels from where she waited to her mooring. The pilot's own steering is free, so the puzzle is WHICH boat
 *    to WHICH mooring, never how neatly you steer. TOW = that distance to where the pilot is now.
 * ⛔ §1a: the automation tab is hidden and rAF is throttled to zero there, so every harness drives the game through the
 *    synchronous `window.PILOTAGE.step(n)` and reads `window.PILOTAGE.frames`.
 * ⛔ §6b-64: every device the listing claims is driven with its REAL vocabulary by the harness — keyboard holds
 *    (4-way), pointer cells under a finger — never an exact vector no device produces.
 * ⛔ §0z-1c: every refusal names its reason (run.refusals), so a harness can read WHY.
 */
(function (root) {
  'use strict';

  var ART = root.ART, FONT = root.DW_FONT, C = root.CONTENT, SND = root.PSOUND, ANCH = root.ANCHORAGE;
  var W = ART.W, H = ART.H, LIT = ART.LIT, FACE = ART.FACE, MID = ART.MID, SHADOW = ART.SHADOW;
  var GW = ART.GW, GH = ART.GH, N = GW * GH;
  var DMG = ['#9bbc0f', '#8bac0f', '#306230', '#0f380f'];
  var WALK_FRAMES = 5, DAS_FRAMES = 12, TOW_FRAMES_PER_CELL = 3, DONE_FRAMES = 130;

  if (!C || !C.anchorages || !C.anchorages.length) throw new Error('content: no anchorages');

  var S = {
    screen: 'title', frames: 0, ai: 0, run: null, result: null,
    dirOrder: [], muted: false, paused: false, endPage: 0, ledgerPage: 0, toast: null,
    best: {}, pointer: null,
  };

  var ED = C.edition === 'full' ? 'full' : 'free';
  var BEST_KEY = 'PILOTAGE_BEST_' + ED, AI_KEY = 'PILOTAGE_AI_' + ED;
  try { S.best = JSON.parse(root.localStorage.getItem(BEST_KEY) || '{}') || {}; } catch (e) { S.best = {}; }
  function saveBest() { try { root.localStorage.setItem(BEST_KEY, JSON.stringify(S.best)); } catch (e) { /* private mode */ } }
  function saveAi() { try { root.localStorage.setItem(AI_KEY, String(S.ai)); } catch (e) { /* private mode */ } }
  function bestFor(id) { var b = S.best[String(id)]; return typeof b === 'number' ? b : null; }

  var cache = {};
  function anchorage(ix) { var sd = C.anchorages[ix].seed; if (!cache[sd]) cache[sd] = ANCH.generate(sd); return cache[sd]; }
  function par(ix) { return ANCH.solve(anchorage(ix)).cost; }

  /* ⛔ THE MEDAL LINES ARE IN TOW STEPS, NOT PERCENT (REVIEW 2026-09-28, defects 1-2). The channels are a square grid,
   * which is bipartite, so every tow has the parity of its two ends' checkerboard colours and EVERY one-to-one plan
   * totals par, par+2, par+4... (Internal_Ops/_measure_bands2.js: 8,000 random plans over the shipped 40, 0 odd).
   * The old 1% / 3% / 5% lines therefore admitted only par on most boards: SILVER was unreachable on 26/40 and free
   * anchorages 2 and 9 passed on the exact optimum alone. The ladder is now what the parity makes it: GOLD = par (the
   * least towing there is), SILVER = 2 over, BRONZE = 4 over, LONG TOWS beyond. MEASURED on the shipped 40: the
   * insight player (the obvious play, then every improving two-tow swap) is at most 2 steps over (40/40 pass, 35
   * GOLD); the obvious HAND passes 14/40 (free 5/10) and loses the lesson anchorage by 10 steps. */
  var MEDALS = [
    // REVIEW 2026-09-28 (defect 16): 'THE LEAST TOWING THERE IS' (25) wrapped at 24 to an orphan "IS"
    { name: 'GOLD', over: 0, line: 'THE LEAST THERE IS' },
    { name: 'SILVER', over: 2, line: 'TWO STEPS OVER THE LEAST' },
    { name: 'BRONZE', over: 4, line: 'EVERY BOAT IS HOME' },
    { name: 'LONG TOWS', over: Infinity, line: 'THE FLEET CAME HOME LATE' },
  ];
  function medalFor(towed, least) { var e = towed - least; for (var i = 0; i < MEDALS.length; i++) if (e <= MEDALS[i].over) return MEDALS[i]; return MEDALS[3]; }
  /** The next anchorage opens on BRONZE or better; LONG TOWS is the loss (retry, or look at a clue). */
  function passed(ix) { var b = bestFor(C.anchorages[ix].id); return b !== null && medalFor(b, par(ix)).name !== 'LONG TOWS'; }
  function unlocked(ix) { return ix === 0 || passed(ix - 1) || bestFor(C.anchorages[ix].id) !== null; }
  (function restoreAi() {
    var v = 0;
    try { v = parseInt(root.localStorage.getItem(AI_KEY) || '0', 10) || 0; } catch (e) { v = 0; }
    v = Math.max(0, Math.min(C.anchorages.length - 1, v));
    while (v > 0 && !unlocked(v)) v--;
    S.ai = v;
  }());

  /* ------------------------------------------------------------------------ the steering */
  function beginRun() {
    var A = anchorage(S.ai), opt = ANCH.solve(A), start = ANCH.startCell(A);
    S.run = {
      A: A, opt: opt, fleet: ART.fleetDesigns(A.seed, A.k), cursor: start, cooldown: 0, lastDir: null, confirm: false,
      inTow: -1, moored: new Array(A.k).fill(-1), berthTaken: new Array(A.k).fill(-1), order: [], towing: null,
      logged: 0, done: 0, steps: 0, bumps: 0, refusals: {}, trace: [],
    };
    S.screen = 'play'; S.paused = false; S.toast = null; S.pointer = null;
    if (SND) SND.cue('start');
  }
  function mooredCount(r) { var n = 0; for (var i = 0; i < r.moored.length; i++) if (r.moored[i] >= 0) n++; return n; }
  /** THE ONE NUMBER: the tow of the boat on the line if she were moored where the pilot is now (-1 = no line). */
  function towHere(r) { return r.inTow >= 0 ? ANCH.towTo(r.A, r.inTow, r.cursor) : -1; }

  var DIRS = { left: [-1, 0], right: [1, 0], up: [0, -1], down: [0, 1] };
  function neighbour(i, d) {
    var x = i % GW, y = (i / GW) | 0, nx = x + DIRS[d][0], ny = y + DIRS[d][1];
    if (nx < 0 || ny < 0 || nx >= GW || ny >= GH) return -1;
    return ny * GW + nx;
  }
  function toast(msg) { S.toast = { msg: msg, until: S.frames + 70 }; }

  var LAND_WORD = {}; LAND_WORD[ANCH.QUAY] = 'THE QUAY'; LAND_WORD[ANCH.ISLAND] = 'AN ISLAND';
  function refuse(r, why, msg) {
    r.refusals[why] = (r.refusals[why] || 0) + 1; r.bumps++;
    if (r.lastRefusal !== why || S.frames - (r.lastRefusalAt || 0) > 20) { if (SND) SND.cue('bump'); if (msg) toast(msg); }
    r.lastRefusal = why; r.lastRefusalAt = S.frames;
    return false;
  }
  function tryMove(d) {
    var r = S.run, A = r.A, t = neighbour(r.cursor, d);
    if (t < 0) return refuse(r, 'edge', null);
    if (!A.reach[t]) {
      if (A.land[t]) return refuse(r, 'land' + A.kind[t], LAND_WORD[A.kind[t]] || 'LAND');
      return refuse(r, 'lagoon', 'NO WAY THROUGH');
    }
    r.cursor = t; r.cooldown = WALK_FRAMES; r.steps++;
    if (SND) SND.cue('step');
    return true;
  }
  function heldDir() { return S.dirOrder.length ? S.dirOrder[S.dirOrder.length - 1] : null; }

  /** A steer to a touched cell: the shortest way through the channels (BFS over the reachable water). */
  function steerPath(A, a, b) {
    if (a === b) return [];
    if (!A.reach[b]) return null;
    var prev = new Int16Array(N).fill(-1), seen = new Uint8Array(N), q = [a]; seen[a] = 1;
    for (var h = 0; h < q.length; h++) { var u = q[h]; if (u === b) break;
      for (var k = 0; k < 4; k++) { var d = ['left', 'right', 'up', 'down'][k], v = neighbour(u, d); if (v >= 0 && A.reach[v] && !seen[v]) { seen[v] = 1; prev[v] = u; q.push(v); } } }
    if (!seen[b]) return null;
    var out = []; for (var c = b; c !== a; c = prev[c]) out.push(c); return out.reverse();
  }
  function dirTo(a, b) {
    var ax = a % GW, ay = (a / GW) | 0, bx = b % GW, by = (b / GW) | 0;
    if (ay === by && bx === ax - 1) return 'left'; if (ay === by && bx === ax + 1) return 'right';
    if (ax === bx && by === ay - 1) return 'up'; if (ax === bx && by === ay + 1) return 'down';
    return null;
  }

  function stepPlay() {
    var r = S.run;
    if (r.towing) { r.towing.t++; if (r.towing.t >= r.towing.frames) landTow(); return; }
    if (r.done > 0) { r.done--; if (r.done === 0) finish(); return; }
    if (r.cooldown > 0) { r.cooldown--; return; }
    if (r.confirm) return;
    if (r.trace.length) {
      var next = r.trace[0], d0 = dirTo(r.cursor, next);
      if (!d0) { r.trace.length = 0; return; }
      if (tryMove(d0)) r.trace.shift(); else r.trace.length = 0;
      return;
    }
    var d = heldDir();
    if (!d) { r.lastDir = null; return; }
    var fresh = d !== r.lastDir, moved = tryMove(d);
    if (fresh && moved) r.cooldown = Math.max(r.cooldown, DAS_FRAMES);
    r.lastDir = d;
  }

  /** Z during play: take the boat you are on in tow · cast her off · switch the line · or ask to moor on a free mooring. */
  function act() {
    var r = S.run, A = r.A, c = r.cursor, bi = A.boatAt[c], bj = A.berthAt[c];
    var boatWaiting = bi >= 0 && r.moored[bi] < 0;
    if (r.inTow < 0) {
      if (boatWaiting) { r.inTow = bi; if (SND) SND.cue('tow'); return true; }
      if (bj >= 0) return refuse(r, 'noline', r.berthTaken[bj] >= 0 ? 'A BOAT IS MOORED HERE' : 'TAKE A BOAT IN TOW FIRST');
      return refuse(r, 'noboat', 'NO BOAT HERE');
    }
    if (bj >= 0 && r.berthTaken[bj] < 0) { r.confirm = true; r.trace.length = 0; S.dirOrder = []; if (SND) SND.cue('ok'); return true; }
    if (bj >= 0) return refuse(r, 'taken', 'THAT MOORING IS TAKEN');
    if (bi === r.inTow) { r.inTow = -1; if (SND) SND.cue('cast'); toast('LINE CAST OFF'); return true; }
    if (boatWaiting) { r.inTow = bi; if (SND) SND.cue('tow'); toast('A NEW LINE'); return true; }
    return refuse(r, 'nomooring', 'NO MOORING HERE');
  }
  /** MOOR: irreversible. The boat is towed home along her shortest channel, then she stays. */
  function moor() {
    var r = S.run, A = r.A, i = r.inTow, j = A.berthAt[r.cursor];
    r.confirm = false;
    var route = ANCH.route(A, i, r.cursor);
    r.towing = { boat: i, berth: j, route: route, t: 0, frames: Math.max(18, route.length * TOW_FRAMES_PER_CELL) };
    r.moored[i] = j; r.berthTaken[j] = i; r.order.push(i); r.inTow = -1;
    r.logged += ANCH.tow(A, i, j);
    if (SND) SND.cue('moor');
  }
  function landTow() {
    var r = S.run; r.towing = null;
    if (mooredCount(r) === r.A.k) { r.done = DONE_FRAMES; if (SND) SND.cue('home'); }
  }

  function finish() {
    var r = S.run, c = C.anchorages[S.ai], towed = ANCH.cost(r.A, r.moored), ratio = towed / r.opt.cost, prev = bestFor(c.id);
    var isBest = prev === null || towed < prev;
    if (isBest) { S.best[String(c.id)] = towed; saveBest(); }
    var m = medalFor(towed, r.opt.cost);
    S.result = { ok: true, towed: towed, par: r.opt.cost, ratio: ratio, medal: m, late: m.name === 'LONG TOWS', newBest: isBest, hadBest: prev !== null, prev: prev };
    if (SND) SND.cue(m.name === 'LONG TOWS' ? 'late' : 'done');
    S.screen = 'result';
  }

  /* ----------------------------------------------------------------------------- drawing */
  var plane = new ART.Plane(W, H, LIT);
  var baseCache = { key: '', plane: null };
  var CARDCH = Math.floor((W - 12 - 8) / FONT.FACES.body.adv);
  function wrap(str, max) {
    var words = String(str).split(' '), lines = [], cur = '';
    for (var i = 0; i < words.length; i++) { var nx = cur ? cur + ' ' + words[i] : words[i]; if (nx.length > max && cur) { lines.push(cur); cur = words[i]; } else cur = nx; }
    if (cur) lines.push(cur); return lines;
  }
  function baseFor(A) {
    if (baseCache.key !== A.seed) { var b = ART.anchoragePlane(A); ART.skyBand(b, A.seed % 7); baseCache.plane = b; baseCache.key = A.seed; }
    plane.px.set(baseCache.plane.px);
  }
  function text(str, x, y, o) { o = o || {}; if (o.halo === undefined && o.shade === LIT) o.halo = SHADOW; FONT.textPlane(plane, str, x, y, o); }

  /** The pilot, with four blinking corner brackets round her cell — the cell Z acts on.
   *  ⛔ SCREENS ROUND 1 (LOOKED AT 04_in_tow.png): MILLWRIGHT's brackets blink dark <-> LIT, and on this game's lit
   *  water the LIT phase is invisible, so half the time the pilot was one more small boat. Dark <-> shade 2 now. */
  function drawCursor(r) {
    var on = (S.frames >> 3) % 2 === 0, X = ART.cellX(r.cursor), Y = ART.cellY(r.cursor), s = on ? SHADOW : MID;
    [[-1, -1, 1, 1], [8, -1, -1, 1], [-1, 8, 1, -1], [8, 8, -1, -1]].forEach(function (b) { for (var k = 0; k < 3; k++) { plane.set(X + b[0] + b[2] * k, Y + b[1], s); plane.set(X + b[0], Y + b[1] + b[3] * k, s); } });
    ART.drawPilot(plane, X, Y, (S.frames >> 4) & 1, r.cooldown > 0);
  }
  /** Everything on the water for a run's CURRENT state: moored tows (pale, the log), free moorings, moored boats,
   *  waiting boats, the live line and the pilot. */
  function drawWater(r, opts) {
    opts = opts || {};
    var A = r.A;
    for (var i = 0; i < A.k; i++) if (r.moored[i] >= 0 && !(r.towing && r.towing.boat === i)) ART.drawLine(plane, ANCH.route(A, i, A.berths[r.moored[i]]), MID, 0);
    for (var j = 0; j < A.k; j++) if (r.berthTaken[j] < 0 || (r.towing && r.towing.berth === j)) ART.drawMooring(plane, A.berths[j]);
    if (r.inTow >= 0 && !opts.noCursor) ART.drawLine(plane, ANCH.route(A, r.inTow, r.cursor), SHADOW, (S.frames >> 2) % 3);
    for (var b = 0; b < A.k; b++) {
      if (r.towing && r.towing.boat === b) continue;
      if (opts.blink === b && (S.frames >> 4) % 2) { ART.drawBoat(plane, ART.cellX(A.boats[b]), ART.cellY(A.boats[b]), r.fleet[b], 'ghost'); continue; }
      if (r.moored[b] >= 0) { var mc = A.berths[r.moored[b]]; ART.drawBoat(plane, ART.cellX(mc), ART.cellY(mc), r.fleet[b], 'home'); }
      else ART.drawBoat(plane, ART.cellX(A.boats[b]), ART.cellY(A.boats[b]), r.fleet[b], 'sail');
    }
    if (r.towing) {
      var T = r.towing, rt = T.route; ART.drawLine(plane, rt, SHADOW, 0);
      var pos = Math.min(1, T.t / T.frames) * (rt.length - 1), k = Math.min(rt.length - 2, Math.floor(pos)), f = pos - k;
      if (rt.length >= 2) { var a = rt[k], c2 = rt[k + 1]; ART.drawBoat(plane, ART.cellX(a) + (ART.cellX(c2) - ART.cellX(a)) * f, ART.cellY(a) + (ART.cellY(c2) - ART.cellY(a)) * f, r.fleet[T.boat], 'sail'); }
    }
  }

  function hud(r) {
    // ⛔ THE ONE NUMBER at the top left: TOW (this boat to here) while a line is on, else TOWED (the fleet so far).
    var tw = towHere(r);
    text(r.inTow >= 0 ? 'TOW ' + tw : 'TOWED ' + r.logged, 3, 3, { shade: LIT });
    text('PAR ' + r.opt.cost + ' FOR ALL', 3, 13, { shade: LIT });
    // ⛔ REVIEW 2026-09-28 (defect 8): lit "home" glyphs sat on the sky's shade-1 cloud bars (0 next to 1: worth nothing,
    // §0-ART-g). They sit on a shade-2 plaque now: lit home glyphs and dark out-on-the-water glyphs both read on it.
    var k = r.A.k, gx = W - 3 - k * 9 - 2;
    plane.rect(gx, 1, W - gx - 1, 11, MID); plane.hline(gx, W - 2, 12, SHADOW);
    for (var i = 0; i < k; i++) ART.boatGlyph(plane, W - 3 - (k - i) * 9, 3, r.moored[i] >= 0);
  }

  function drawPlayScreen() {
    var r = S.run;
    baseFor(r.A);
    drawWater(r);
    if (!r.towing && r.done === 0) drawCursor(r);
    hud(r);
    if (r.confirm) {
      plane.rect(19, 57, 122, 30, LIT); plane.rect(20, 58, 120, 28, SHADOW);
      // ⛔ REVIEW 2026-09-28 (defect 5): "MOOR HER HERE? TOW 12" is 126 px in a 120 px box; a third of all moorings
      // overflowed it. 16 characters at most now (a tow is under 100 cells: 20x15 grid), 96 px.
      text('MOOR HER? TOW ' + towHere(r), W / 2, 62, { align: 'center', shade: LIT });
      FONT.textPlane(plane, 'Z YES   X NO', W / 2, 74, { align: 'center', shade: FACE });
    }
    if (S.toast && S.frames < S.toast.until) {
      var w = S.toast.msg.length * 6 + 8, x = Math.round((W - w) / 2), low = ((r.cursor / GW) | 0) >= GH / 2, ty = low ? ART.FIELD_Y + 2 : 128;
      plane.rect(x, ty, w, 11, SHADOW); plane.hline(x, x + w - 1, low ? ty + 11 : ty - 1, LIT);
      text(S.toast.msg, W / 2, ty + 2, { align: 'center', shade: LIT, halo: undefined });
    }
    if (S.paused) {
      plane.rect(29, 53, 102, 40, LIT); plane.rect(30, 54, 100, 38, SHADOW);
      text('PAUSED', W / 2, 60, { align: 'center', shade: LIT });
      FONT.textPlane(plane, 'P RESUME', W / 2, 72, { align: 'center', shade: FACE });
      FONT.textPlane(plane, 'X GIVE UP', W / 2, 81, { align: 'center', shade: FACE });
    }
  }

  function cardFrame(title) {
    plane.px.fill(MID);
    for (var i = 0; i < 10; i++) plane.hline(0, W - 1, 7 + i * 15, SHADOW);
    plane.rect(6, 14, W - 12, H - 34, SHADOW);
    plane.hline(6, W - 7, 14, LIT);
    FONT.textPlane(plane, title, W / 2, 20, { align: 'center', shade: LIT });
    plane.hline(30, W - 31, 30, MID);
  }
  function card(title, lines, footer) {
    cardFrame(title);
    var flat = [];
    for (var j = 0; j < lines.length; j++) { if (!lines[j]) { flat.push(''); continue; } wrap(lines[j], CARDCH).forEach(function (l) { flat.push(l); }); }
    for (var k = 0; k < flat.length && 36 + k * 9 <= H - 22; k++) FONT.textPlane(plane, flat[k], W / 2, 36 + k * 9, { align: 'center', shade: FACE });
    if (footer) FONT.textPlane(plane, footer, W / 2, H - 12, FOOT);
  }
  /* ⛔ REVIEW 2026-09-28 (defect 12): footers were dark text with a LIT halo on the striped band, and the halo filled
   * the gap in a colon ("LEFT RIGHT: PAGE" read "RIGHT8") and the counters of M and N. Lit text, dark halo now — the
   * HUD's own style, which the review found legible. */
  var FOOT = { align: 'center', shade: LIT, halo: SHADOW };

  var titleBase = null, titleImg = null, titleState = 'none';
  var FREE_BAND = { x: 36, y: H - 26, w: 88, h: 11 }, PRESS_BAND = { x: 44, y: H - 13, w: 72, h: 11 };
  function loadTitle() {
    if (titleState !== 'none' || !root.Image) return;
    titleState = 'loading';
    titleImg = new root.Image();
    titleImg.onload = function () { titleState = 'ready'; };
    titleImg.onerror = function () { titleState = 'failed'; };
    titleImg.src = 'art/title.png';
  }
  function drawTitle() {
    if (!titleBase) titleBase = ART.titlePlane(FONT);
    plane.px.set(titleBase.px);
    if (C.edition !== 'full') { plane.rect(FREE_BAND.x, FREE_BAND.y, FREE_BAND.w, FREE_BAND.h, SHADOW); FONT.textPlane(plane, 'FREE EDITION', W / 2, FREE_BAND.y + 2, { align: 'center', shade: LIT }); }
    if (S.frames % 48 < 32) { plane.rect(PRESS_BAND.x, PRESS_BAND.y, PRESS_BAND.w, PRESS_BAND.h, SHADOW); FONT.textPlane(plane, 'Z OR TAP', W / 2, PRESS_BAND.y + 2, { align: 'center', shade: LIT }); }
  }

  /** The anchorage before the run: the fleet out, every mooring free. */
  function startState(A) { return { A: A, fleet: ART.fleetDesigns(A.seed, A.k), moored: new Array(A.k).fill(-1), berthTaken: new Array(A.k).fill(-1), inTow: -1, towing: null, cursor: ANCH.startCell(A), cooldown: 0 }; }
  function drawYard() {
    var A = anchorage(S.ai), c = C.anchorages[S.ai], b = bestFor(c.id);
    baseFor(A);
    var st = startState(A); drawWater(st, { noCursor: true }); ART.drawPilot(plane, ART.cellX(st.cursor), ART.cellY(st.cursor), 0, false);
    text(c.name, 3, 3, { shade: LIT });
    text('Z START', W - 3, 3, { align: 'right', shade: LIT });
    text((S.ai + 1) + '/' + C.anchorages.length, 3, 13, { shade: LIT });
    text(b === null ? A.k + ' BOATS' : medalFor(b, par(S.ai)).name, W - 3, 13, { align: 'right', shade: LIT });
    if (S.toast && S.frames < S.toast.until) {
      var w = S.toast.msg.length * 6 + 8, x = Math.round((W - w) / 2);
      plane.rect(x, 128, w, 11, SHADOW); plane.hline(x, x + w - 1, 127, LIT);
      text(S.toast.msg, W / 2, 130, { align: 'center', shade: LIT, halo: undefined });
    }
  }

  function drawResult() {
    var R = S.result, c = C.anchorages[S.ai];
    cardFrame(R.medal.name);
    var A = S.run.A, ox = 9, oy = 36;
    plane.rect(ox - 2, oy - 2, 64, 49, LIT);
    thumb(A, ox, oy, 3, S.run.moored);
    var tx = 113;
    // ⛔ REVIEW 2026-09-28 (defect 15): the longest paid name (14 characters, 84 px) started ON the thumbnail's frame. The column right of the
    // thumbnail holds 12 characters clear of the frame (x 74..152); a longer name prints its first word. (The four
    // paid names over 12 characters were also renamed.)
    FONT.textPlane(plane, c.name.length > 12 ? c.name.split(' ')[0] : c.name, tx, 34, { align: 'center', shade: LIT });
    FONT.textPlane(plane, 'YOUR TOWING', tx, 48, { align: 'center', shade: FACE });
    FONT.textPlane(plane, String(R.towed), tx, 57, { align: 'center', shade: LIT });
    FONT.textPlane(plane, 'THE LEAST', tx, 70, { align: 'center', shade: FACE });
    FONT.textPlane(plane, String(R.par), tx, 79, { align: 'center', shade: LIT });
    // ⛔ REVIEW 2026-09-28 (defect 6): "FIRST TRY" (a success idiom) was printed under a LOSS.
    var note = R.late ? (R.hadBest ? 'YOUR BEST ' + R.prev : 'NO MEDAL YET') : (R.newBest ? (R.hadBest ? 'A NEW BEST' : 'FIRST PASS') : 'YOUR BEST ' + R.prev);
    FONT.textPlane(plane, note, tx, 92, { align: 'center', shade: FACE });
    var line = R.late ? 'LATE HOME. BRONZE OPENS THE NEXT ANCHORAGE.' : R.medal.line;
    wrap(line, 24).slice(0, 2).forEach(function (l, i) { FONT.textPlane(plane, l, W / 2, 106 + i * 8, { align: 'center', shade: FACE }); });
    FONT.textPlane(plane, R.late ? 'Z RETRY  X A CLUE' : 'Z NEXT  X BEST TOWS', W / 2, H - 12, FOOT);
  }
  /** An anchorage thumbnail at `sc` px per cell: water lit, land shade 2, and — if `moored` is given — every tow as a
   *  dark line from where the boat waited to her mooring, the boat's start a dark block and her mooring a dark ring. */
  function thumb(A, ox, oy, sc, moored) {
    for (var c = 0; c < N; c++) plane.rect(ox + (c % GW) * sc, oy + ((c / GW) | 0) * sc, sc, sc, A.land[c] ? MID : LIT);
    var mid = function (cell) { return { x: ox + (cell % GW) * sc + (sc >> 1), y: oy + ((cell / GW) | 0) * sc + (sc >> 1) }; };
    if (moored) for (var i = 0; i < A.k; i++) { if (moored[i] < 0) continue; var rt = ANCH.route(A, i, A.berths[moored[i]]); for (var k = 1; k < rt.length; k++) { var a = mid(rt[k - 1]), b = mid(rt[k]); ART.line(plane, a.x, a.y, b.x, b.y, SHADOW); } }
    A.berths.forEach(function (cell) { var m = mid(cell); if (sc >= 3) { plane.rect(m.x - 1, m.y - 1, 3, 3, SHADOW); plane.set(m.x, m.y, LIT); } else plane.set(m.x, m.y, FACE); });
    A.boats.forEach(function (cell) { var m = mid(cell); if (sc >= 3) plane.rect(m.x - 1, m.y - 1, 3, 3, SHADOW); else plane.set(m.x, m.y, SHADOW); });
  }

  /** THE LESSON, on request after a PASS: the proved-best tows, every boat on her best mooring, your own tows pale
   *  beneath — the thing the player can learn to see (two tows that cross are usually the wrong pair).
   *  ⛔ MILLWRIGHT review defect 10 (MAJOR), carried over: after a LOSS the answer would be copied — lose, look, retry
   *  = GOLD. After a loss this screen shows a CLUE instead: the boats whose tow differs from the best plan NEAREST
   *  YOUR OWN (anchorage.js solve with a tie-break toward your plan, so an equally-good plan is never called wrong)
   *  are ringed where they waited, and NO mooring is marked. Which boat goes where is still the player's. */
  /* ⛔ REVIEW 2026-09-28 (defect 3, MAJOR): ringing EVERY boat the nearest least plan moves handed the answer over —
   * the unringed boats keep their moorings, so two rings meant "swap these two" (43% of 1,244 losing plans left exactly
   * one par plan). (defect 4) it could also ring a boat an equally good plan keeps. The clue is now: HOW MANY boats the
   * least towing moves (the fewest any least plan needs), and ONE ringed boat that EVERY least plan moves
   * (anchorage.js clue(): bestWith proves no least plan keeps her). Which of the others move, and where she goes, stay
   * the player's. */
  function revealIsClue() { return !!(S.result && S.result.late); }
  function clueFor(r) { if (!r.clue || r.clueKey !== r.moored.join(',')) { r.clue = ANCH.clue(r.A, r.moored); r.clueKey = r.moored.join(','); } return r.clue; }
  function drawReveal() {
    var r = S.run, A = r.A, clue = revealIsClue(), foot = (S.frames % 192) < 96;
    baseFor(A);
    if (clue) {
      var cl = clueFor(r), st = startState(A);
      for (var i = 0; i < A.k; i++) ART.drawLine(plane, ANCH.route(A, i, A.berths[r.moored[i]]), MID, 0);
      // REVIEW RE-CHECK (defect 7 residue): at the field edge the brackets can still touch a diagonal neighbour, so the
      // ringed boat herself also blinks between her sail and a dotted outline — the mark cannot be read as the other boat.
      drawWater(st, { noCursor: true, blink: cl.ringed });
      if (cl.ringed >= 0) {
        // ⛔ REVIEW 2026-09-28 (defect 7): a dotted box 3 px outside the cell ran off the screen for a column-0 boat and
        // through the boat waiting diagonally below, so the picture did not say WHICH boat. Now four solid corner
        // brackets hugging her own 8x12 sprite (clamped inside the field), blinking dark <-> shade 2 — a mark no boat,
        // buoy or tow line is drawn with.
        var bxC = ART.cellX(A.boats[cl.ringed]), byC = ART.cellY(A.boats[cl.ringed]), sh = (S.frames >> 3) % 2 ? MID : SHADOW;
        var X0 = Math.max(0, bxC - 2), X1 = Math.min(W - 1, bxC + 9), Y0 = Math.max(ART.FIELD_Y - 3, byC - 6), Y1 = byC + 9;
        [[X0, Y0, 1, 1], [X1, Y0, -1, 1], [X0, Y1, 1, -1], [X1, Y1, -1, -1]].forEach(function (b) { for (var q = 0; q < 4; q++) { plane.set(b[0] + b[2] * q, b[1], sh); plane.set(b[0], b[1] + b[3] * q, sh); } });
      }
      text('A CLUE: MOVE ' + cl.moves + ' BOATS', 3, 3, { shade: LIT });
      text(foot ? 'RINGED: ONE OF THEM' : 'Z BACK  X ANCHORAGES', 3, 13, { shade: LIT });
      return;
    }
    var best = { A: A, fleet: r.fleet, moored: r.opt.asg.slice(), berthTaken: [], inTow: -1, towing: null };
    for (var j = 0; j < A.k; j++) best.berthTaken[j] = -1; for (var b2 = 0; b2 < A.k; b2++) best.berthTaken[best.moored[b2]] = b2;
    // ⛔ REVIEW 2026-09-28 (defect 9): yours (shade 2, dotted) and the least (shade 3, dotted) read as one set of dark
    // dotted lines, and every tow's start dangled in open water. Now: YOUR differing tows are sparse shade-2 dots, the
    // least tows are SOLID dark lines, and each boat's waiting spot carries her ghost (a dotted outline), so every line
    // runs from a boat to a boat.
    for (var i2 = 0; i2 < A.k; i2++) if (r.moored[i2] !== r.opt.asg[i2]) ART.drawLine(plane, ANCH.route(A, i2, A.berths[r.moored[i2]]), MID, 1, 2);
    for (var i3 = 0; i3 < A.k; i3++) ART.drawLine(plane, ANCH.route(A, i3, A.berths[r.opt.asg[i3]]), SHADOW, 0, 99);
    for (var i5 = 0; i5 < A.k; i5++) ART.drawBoat(plane, ART.cellX(A.boats[i5]), ART.cellY(A.boats[i5]), r.fleet[i5], 'ghost');
    for (var i4 = 0; i4 < A.k; i4++) { var mc = A.berths[r.opt.asg[i4]]; ART.drawBoat(plane, ART.cellX(mc), ART.cellY(mc), r.fleet[i4], 'home'); }
    text('LEAST ' + r.opt.cost, 3, 3, { shade: LIT });
    text('YOURS ' + ANCH.cost(A, r.moored), W - 3, 3, { align: 'right', shade: LIT });
    text(foot ? 'SOLID: THE LEAST' : 'Z BACK  X ANCHORAGES', 3, 13, { shade: LIT });
  }

  /** THE LOG: every anchorage in miniature, ten to a page, with its medal. */
  function drawLedger() {
    plane.px.fill(MID);
    plane.rect(0, 0, W, 12, SHADOW);
    var pages = Math.ceil(C.anchorages.length / 10), pg = Math.max(0, Math.min(S.ledgerPage, pages - 1));
    var got = 0; C.anchorages.forEach(function (c) { if (bestFor(c.id) !== null) got++; });
    FONT.textPlane(plane, 'HARBOUR LOG ' + got + '/' + C.anchorages.length, 3, 3, { shade: LIT });
    FONT.textPlane(plane, (pg + 1) + '/' + pages, W - 3, 3, { align: 'right', shade: LIT });
    for (var i = 0; i < 10; i++) {
      var ix = pg * 10 + i; if (ix >= C.anchorages.length) break;
      var c = C.anchorages[ix], cx = 3 + (i % 5) * 31, cy = 16 + Math.floor(i / 5) * 58;
      plane.rect(cx, cy, 29, 54, SHADOW);
      var b = bestFor(c.id);
      if (b !== null || unlocked(ix)) thumb(anchorage(ix), cx + 4, cy + 4, 1, null);
      if (b !== null) { var med = medalFor(b, par(ix)).name; FONT.textPlane(plane, med === 'LONG TOWS' ? '-' : med.charAt(0), cx + 14, cy + 24, { align: 'center', shade: LIT }); }
      else FONT.textPlane(plane, '?', cx + 14, cy + 24, { align: 'center', shade: MID });
      FONT.textPlane(plane, String(ix + 1), cx + 14, cy + 40, { align: 'center', shade: b !== null ? FACE : MID });
    }
    FONT.textPlane(plane, pages > 1 ? 'LEFT RIGHT: PAGE  X BACK' : 'X BACK', W / 2, H - 9, FOOT);
  }

  var LINES_PER_PAGE = 9;
  function endingPages() {
    var raw = C.ending || [].concat(C.demoEnd || ''), paras = [];
    for (var i = 0; i < raw.length; i++) if (raw[i]) paras.push(wrap(raw[i], CARDCH));
    var pages = [], cur = [];
    paras.forEach(function (p) {
      if (cur.length && (LINES_PER_PAGE - cur.length < 3 || (cur.length + 1 + p.length > LINES_PER_PAGE && p.length <= LINES_PER_PAGE))) { pages.push(cur); cur = []; }
      if (cur.length) cur.push('');
      for (var k = 0; k < p.length; k++) { if (cur.length >= LINES_PER_PAGE) { pages.push(cur); cur = []; } cur.push(p[k]); }
    });
    if (cur.length) pages.push(cur);
    return pages.length ? pages : [['']];
  }
  function drawEnding() {
    var pages = endingPages(), page = Math.max(0, Math.min(S.endPage, pages.length - 1));
    cardFrame(C.ending ? C.endingTitle : 'END OF THE FREE EDITION');
    for (var k = 0; k < pages[page].length; k++) FONT.textPlane(plane, pages[page][k], W / 2, 38 + k * 9, { align: 'center', shade: FACE });
    var more = page < pages.length - 1;
    FONT.textPlane(plane, more ? 'Z MORE ' + (page + 1) + '/' + pages.length : 'Z CREDITS', W / 2, H - 12, FOOT);
  }
  // ⛔ REVIEW 2026-09-28 (defect 13): the card never said how to steer or what passes, and its rules ran together.
  // Nine lines, each rule one line, grouped: the hands, the moves, the numbers.
  var RULES = ['HOLD A WAY TO STEER.', '', 'Z ON A BOAT: TOW HER.', 'Z ON A BUOY: MOOR HER.', 'A MOORED BOAT STAYS.', '',
    'TOW: HER WAY TO HERE.', 'PAR: THE LEAST FOR ALL.', 'PAR +4 OR LESS PASSES.'];
  var RULES_KEY = 'PILOTAGE_RULES_SEEN', rulesSeen = false;
  try { rulesSeen = root.localStorage.getItem(RULES_KEY) === '1'; } catch (e) { rulesSeen = false; }
  function markRulesSeen() { rulesSeen = true; try { root.localStorage.setItem(RULES_KEY, '1'); } catch (e) { /* private mode */ } }
  function drawRules() { card('THE ANCHORAGE', RULES, S.rulesThenRun ? 'Z START  X BACK' : 'Z OR X BACK'); }
  function drawCredits() {
    card('PILOTAGE', ['CORE SYSTEMS', 'ASSET FACTORY', '', 'CODE, ART AND TEXT MADE', 'WITH AI ASSISTANCE.', 'MUSIC AND SOUND ARE', 'SYNTHESISED FROM NOTES.'], 'X BACK');
  }
  function drawGaveUp() { card('LEFT AT SEA', ['THE FLEET WAITS FOR ITS MOORINGS.', '', 'THE NEAREST FREE MOORING IS NOT ALWAYS HERS.'], 'Z RETRY  X ANCHORAGES'); }

  /* ------------------------------------------------------------------------------ paint */
  var cv, ctx, img, data;
  var PAL = DMG.map(function (h) { return [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)]; });
  function paint() {
    for (var i = 0, p = 0; i < plane.px.length; i++, p += 4) { var c = PAL[plane.px[i]] || PAL[0]; data[p] = c[0]; data[p + 1] = c[1]; data[p + 2] = c[2]; data[p + 3] = 255; }
    ctx.putImageData(img, 0, 0);
    if (S.screen === 'title' && titleState === 'ready') {
      ctx.drawImage(titleImg, 0, 0, W, H);
      if (C.edition !== 'full') ctx.putImageData(img, 0, 0, FREE_BAND.x, FREE_BAND.y, FREE_BAND.w, FREE_BAND.h);
      ctx.putImageData(img, 0, 0, PRESS_BAND.x, PRESS_BAND.y, PRESS_BAND.w, PRESS_BAND.h);
    }
  }

  /* ------------------------------------------------------------------------------ input */
  function press(k) {
    if (SND) SND.unlock();
    if (k === 'mute') { S.muted = !S.muted; if (SND) SND.setMuted(S.muted); return; }
    if (S.screen === 'title') { if (k === 'ok') { S.screen = 'yard'; if (SND) SND.cue('ok'); } else if (k === 'back') S.screen = 'credits'; return; }
    if (S.screen === 'yard') {
      if (k === 'left' && S.ai > 0) { S.ai--; saveAi(); if (SND) SND.cue('page'); }
      else if (k === 'right' && S.ai < C.anchorages.length - 1 && unlocked(S.ai + 1)) { S.ai++; saveAi(); if (SND) SND.cue('page'); }
      else if (k === 'right' && S.ai < C.anchorages.length - 1) { if (SND) SND.cue('bump'); toast('BRONZE OPENS THE NEXT'); }
      else if (k === 'up') { S.screen = 'ledger'; S.ledgerPage = Math.floor(S.ai / 10); if (SND) SND.cue('ok'); }
      else if (k === 'down') { S.screen = 'rules'; S.rulesThenRun = false; if (SND) SND.cue('ok'); }
      else if (k === 'ok' && !rulesSeen) { S.screen = 'rules'; S.rulesThenRun = true; if (SND) SND.cue('ok'); }
      else if (k === 'ok') beginRun();
      else if (k === 'back') S.screen = 'title';
      return;
    }
    if (S.screen === 'rules') {
      if (k === 'ok' && S.rulesThenRun) { markRulesSeen(); beginRun(); }
      else if (k === 'ok' || k === 'back') { markRulesSeen(); S.screen = 'yard'; if (SND) SND.cue('ok'); }
      return;
    }
    if (S.screen === 'ledger') {
      var pages = Math.ceil(C.anchorages.length / 10);
      if (k === 'left' && S.ledgerPage > 0) { S.ledgerPage--; if (SND) SND.cue('page'); }
      else if (k === 'right' && S.ledgerPage < pages - 1) { S.ledgerPage++; if (SND) SND.cue('page'); }
      else if (k === 'back' || k === 'ok' || k === 'down') { S.screen = 'yard'; if (SND) SND.cue('ok'); }
      return;
    }
    if (S.screen === 'play') {
      var r = S.run;
      if (r.towing || r.done > 0) return;
      if (r.confirm) { if (k === 'ok') moor(); else if (k === 'back') { r.confirm = false; if (SND) SND.cue('page'); } return; }
      if (k === 'pause' || (k === 'back' && !S.paused)) { S.paused = !S.paused; if (SND) SND.cue('ok'); }
      else if (k === 'back' && S.paused) { S.paused = false; S.result = { ok: false, gaveUp: true, moored: mooredCount(r) }; S.screen = 'gaveup'; }
      else if (k === 'ok' && S.paused) { S.paused = false; }
      else if (k === 'ok') act();
      return;
    }
    if (S.screen === 'gaveup') { if (k === 'ok') beginRun(); else if (k === 'back') { S.screen = 'yard'; if (SND) SND.cue('ok'); } return; }
    if (S.screen === 'result') {
      if (k === 'back') { S.screen = 'reveal'; if (SND) SND.cue('ok'); return; }
      if (k === 'ok') {
        if (S.result.late) { beginRun(); return; }
        if (S.ai >= C.anchorages.length - 1) { S.screen = 'ending'; S.endPage = 0; }
        else { S.ai++; saveAi(); S.screen = 'yard'; }
        if (SND) SND.cue('ok');
      }
      return;
    }
    if (S.screen === 'reveal') { if (k === 'ok') { S.screen = 'result'; if (SND) SND.cue('ok'); } else if (k === 'back') { S.screen = 'yard'; if (SND) SND.cue('ok'); } return; }
    if (S.screen === 'ending') {
      if (k === 'ok') { if (S.endPage < endingPages().length - 1) { S.endPage++; if (SND) SND.cue('page'); } else S.screen = 'credits'; }
      return;
    }
    if (S.screen === 'credits') { if (k === 'back' || k === 'ok') S.screen = 'title'; }
  }

  var HELD = {};
  function holdKey(k, down) {
    HELD[k] = down;
    S.dirOrder = S.dirOrder.filter(function (d) { return d !== k; });
    if (down) S.dirOrder.push(k);
  }
  var KEYMAP = {
    ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down',
    a: 'left', d: 'right', w: 'up', s: 'down', A: 'left', D: 'right', W: 'up', S: 'down',
    z: 'ok', Z: 'ok', Enter: 'ok', ' ': 'ok', x: 'back', X: 'back', Escape: 'back', Backspace: 'back',
    p: 'pause', P: 'pause', m: 'mute', M: 'mute',
  };

  function cellAt(px, py) {
    if (py < ART.FIELD_Y) return -1;
    var x = Math.floor(px / ART.CELL), y = Math.floor((py - ART.FIELD_Y) / ART.CELL);
    if (x < 0 || y < 0 || x >= GW || y >= GH) return -1;
    return y * GW + x;
  }
  /** The pointer vocabulary, shared by the page's real events and the harness (§6b-64: the harness sends the same CELLS
   *  a finger lands on). A finger on the water sets where the pilot steers; she goes there cell by cell at her own
   *  pace, round every island, and TOW updates every step. A tap ON her is Z. */
  function pointerDown(cell) {
    S.pointer = { down: true, cell: cell, t0: S.frames, moved: false, onCursor: false };
    var r = S.run;
    if (S.screen !== 'play' || !r || S.paused || r.towing || r.done > 0 || cell < 0) return;
    // ⛔ REVIEW 2026-09-28 (defect 11): a tap ON the launch is Z everywhere — including the moor question, where it was
    // silently ignored — and it STOPS her where she is, so the Z acts on the cell the player tapped, not a later one.
    if (cell === r.cursor) { S.pointer.onCursor = true; r.trace.length = 0; return; }
    if (r.confirm) return;
    var path = steerPath(r.A, r.cursor, cell);
    if (path) r.trace = path;
    else if (r.A.land[cell]) refuse(r, 'land' + r.A.kind[cell], LAND_WORD[r.A.kind[cell]] || 'LAND');
    else refuse(r, 'lagoon', 'NO WAY THROUGH');
  }
  function pointerMove(cell) {
    var P = S.pointer;
    if (!P || !P.down || cell === P.cell) return;
    P.moved = true; P.cell = cell;
    var r = S.run;
    if (cell < 0 || S.screen !== 'play' || !r || S.paused || r.confirm || r.towing || r.done > 0) return;
    var path = steerPath(r.A, r.cursor, cell);
    if (path) r.trace = path;
  }
  function pointerUp() {
    var P = S.pointer; S.pointer = null;
    if (P && P.onCursor && !P.moved && S.screen === 'play' && S.run && !S.paused) press('ok');
    return P;
  }

  /* ------------------------------------------------------------------------------- loop */
  var draw = true;
  function step(n) {
    n = n === undefined ? 1 : n;
    for (var i = 0; i < n; i++) {
      S.frames++;
      if (S.screen === 'play' && !S.paused) stepPlay();
    }
    if (!draw) return;
    if (S.screen === 'title') drawTitle();
    else if (S.screen === 'yard') drawYard();
    else if (S.screen === 'play') drawPlayScreen();
    else if (S.screen === 'result') drawResult();
    else if (S.screen === 'reveal') drawReveal();
    else if (S.screen === 'ledger') drawLedger();
    else if (S.screen === 'ending') drawEnding();
    else if (S.screen === 'credits') drawCredits();
    else if (S.screen === 'rules') drawRules();
    else if (S.screen === 'gaveup') drawGaveUp();
    if (ctx) paint();
  }
  var STEP_MS = 1000 / 60, acc = 0, lastT = null;
  function frame(t) {
    if (lastT === null) lastT = t;
    acc += Math.min(250, t - lastT); lastT = t;
    var n = 0;
    while (acc >= STEP_MS && n < 4) { acc -= STEP_MS; n++; }
    if (n) step(n);
    root.requestAnimationFrame(frame);
  }

  function boot() {
    cv = root.document.getElementById('screen');
    ctx = cv.getContext('2d'); ctx.imageSmoothingEnabled = false;
    img = ctx.createImageData(W, H); data = img.data;
    loadTitle();
    root.addEventListener('keydown', function (e) {
      var k = KEYMAP[e.key]; if (!k) return;
      e.preventDefault();
      if (k === 'left' || k === 'right' || k === 'up' || k === 'down') {
        var was = HELD[k]; holdKey(k, true);
        if (!was && S.screen !== 'play') press(k);
        if (!was && S.screen === 'play' && S.run && S.run.cooldown > 0 && S.run.lastDir !== k) S.run.cooldown = Math.min(S.run.cooldown, 2);
      } else if (!e.repeat) press(k);
    });
    root.addEventListener('keyup', function (e) { var k = KEYMAP[e.key]; if (k && HELD[k]) holdKey(k, false); });
    root.addEventListener('blur', function () { HELD = {}; S.dirOrder = []; S.pointer = null; });
    function gamePt(e) { var b = cv.getBoundingClientRect(); return { x: (e.clientX - b.left) * W / b.width, y: (e.clientY - b.top) * H / b.height }; }
    var swipe = null;
    cv.addEventListener('pointerdown', function (e) {
      e.preventDefault(); if (SND) SND.unlock();
      try { cv.setPointerCapture(e.pointerId); } catch (err) { /* not capturable */ }
      var g = gamePt(e);
      swipe = { x: g.x, y: g.y, t: Date.now(), moved: false };
      if (S.screen === 'play') pointerDown(cellAt(g.x, g.y));
    });
    cv.addEventListener('pointermove', function (e) {
      if (!swipe) return;
      var g = gamePt(e);
      if (S.screen === 'play') { pointerMove(cellAt(g.x, g.y)); return; }
      // ⛔ FOUND BY THE SWIPE ARM (verify_web.js, 2026-09-28): the origin was reset after every 10 px, so ONE long swipe
      // fired several presses (log -> anchorages -> rules). One gesture is one press now.
      if (swipe.fired) return;
      var dx = g.x - swipe.x, dy = g.y - swipe.y;
      if (Math.hypot(dx, dy) < 10) return;
      swipe.moved = true; swipe.fired = true;
      press(Math.abs(dx) > Math.abs(dy) ? (dx < 0 ? 'left' : 'right') : (dy < 0 ? 'up' : 'down'));
    });
    function up() {
      if (!swipe) return;
      var quick = !swipe.moved && Date.now() - swipe.t < 300;
      var wasPlay = S.screen === 'play';
      if (wasPlay) pointerUp();
      swipe = null;
      if (quick && !wasPlay) press('ok');
    }
    cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
    root.__plPress = function (k) { press(k); };
    if (/[?&]harness=1\b/.test(root.location.search)) { step(1); return; }
    step(1);
    root.requestAnimationFrame(frame);
  }

  root.PILOTAGE = {
    step: step, setDraw: function (v) { draw = !!v; }, press: press,
    hold: function (dir, down) { holdKey(dir, down !== false); },
    releaseAll: function () { HELD = {}; S.dirOrder = []; S.pointer = null; },
    pointerDown: pointerDown, pointerMove: pointerMove, pointerUp: pointerUp, cellAt: cellAt,
    state: S, plane: plane, beginRun: beginRun, anchorage: anchorage, par: par, endingPages: endingPages, medalFor: medalFor, unlocked: unlocked,
    revealIsClue: revealIsClue, clueFor: clueFor, towHere: towHere,
    titleState: function () { return titleState; },
    get frames() { return S.frames; }, version: '1.0.0',
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.PILOTAGE;
  else if (root.document) { if (root.document.readyState === 'loading') root.addEventListener('DOMContentLoaded', boot); else boot(); }
}(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this)));
