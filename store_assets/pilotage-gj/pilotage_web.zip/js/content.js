/**
 * content.js — PILOTAGE, the FREE EDITION's content: the first ten anchorages.
 * ⛔ wing §1-DEMO: the other thirty anchorage SPECS and the ending live in content_full.js, which the free index.html
 *    has no <script> tag for and the free package does not contain.
 * A spec is { id, seed, name }; anchorage.js turns `seed` into the anchorage. `seed` is a SCREENED seed (the aux
 * screen's rows, reproduced exactly by Internal_Ops/verify_anchorage.js), chosen and ordered by
 * Internal_Ops/select_anchorages.js (rule and yield printed there). Anchorage 1 is the lesson: the obvious play is 20%
 * over par there.
 * ⛔ The demo-end line is STORE-NEUTRAL from day one (ROOTWORK/NIGHT PLOUGH 1.0.1: "on this page" was false on Game Jolt)
 *    and names only what Internal_Ops/_measure_ramp.js measures as rising.
 */
(function (root) {
  'use strict';
  root.CONTENT = {
    edition: 'free',
    anchorages: [
      { id: 1,  seed: 10, name: 'GULL SOUND' },
      { id: 2,  seed: 22, name: 'SKERRY ROADS' },
      { id: 3,  seed: 44, name: 'HERON BAY' },
      { id: 4,  seed: 25, name: 'CROWSTONE' },
      { id: 5,  seed: 36, name: 'KELP HOLE' },
      { id: 6,  seed: 12, name: 'MARRAM COVE' },
      { id: 7,  seed: 30, name: 'SEAL HOLM' },
      { id: 8,  seed: 33, name: 'WRACK POOL' },
      { id: 9,  seed: 4,  name: 'TERN REACH' },
      { id: 10, seed: 13, name: 'CORRAN ROADS' },
    ],
    endingTitle: 'LAMPS ON THE WATER',
    ending: null,
    // MEASURED (_measure_ramp.js): fleets of eight 0/10 free vs 23/30 paid; par 54.9 -> 68.9; islands 2.5 -> 3.2.
    demoEnd: ['TEN FLEETS ARE HOME.', 'THIRTY MORE WAIT, MOST OF THEM FLEETS OF EIGHT. THE FULL GAME IS A PAID WINDOWS DOWNLOAD.'],
  };
}(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this)));
