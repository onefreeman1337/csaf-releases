/**
 * art.js — PILOTAGE. The anchorage picture, the fishing boats, the moorings, the pilot launch, the tow lines and the
 * title art — THE SINGLE SOURCE OF TRUTH for them (the contact sheets, the store captures and the game all require
 * this file).
 *
 * ⛔ PALETTE LAW (wing §0-ART-g): DMG luma is 158 / 144 / 77 / 39 — shade 0 next to shade 3 is the only strong edge;
 *    0 next to 1 is worth nothing. So the WATER (the ground the player reads routes across) is shade 0 with shade-1
 *    ripples (texture, never an edge), and everything the player must READ is dark on it: every island's coastline,
 *    every hull, every mooring buoy, every tow line.
 * ⛔ THE PICTURE MUST NEVER CONTRADICT THE COLLISION (§0z-1): a land cell (island or quay) is land and looks it, with a
 *    dark coastline exactly on the cell edges that meet water; a water cell is water. Corners are rounded only where
 *    BOTH neighbours are water, and a rounded corner is drawn as water, which the pilot may never enter anyway (the
 *    cell is land) — the rounding is at most 2 px, inside the cell, never across a channel.
 * ⛔ §0-ART-b: nothing tiles on a fixed period — every ripple, speck and tree is hashed per PIXEL / per cell.
 * ⛔ §0-ART-f: the volume lives in the evidence surface — forty generated archipelagos, and every boat in every fleet
 *    is generated (hull length, bow, stern, rig, sail cloth, strake, pennant, heading) so no two in a fleet match.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.ART = api;
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const LIT = 0, FACE = 1, MID = 2, SHADOW = 3, NONE = 255;
  const W = 160, H = 144, FIELD_Y = 24, CELL = 8, GW = 20, GH = 15;
  const WATER = 0, QUAY = 1, ISLAND = 2;

  function Plane(w, h, fill) { this.w = w; this.h = h; this.px = new Uint8Array(w * h).fill(fill === undefined ? NONE : fill); }
  Plane.prototype.set = function (x, y, s) { if (s === NONE) return; x = Math.round(x); y = Math.round(y); if (x < 0 || y < 0 || x >= this.w || y >= this.h) return; this.px[y * this.w + x] = s; };
  Plane.prototype.get = function (x, y) { return (x < 0 || y < 0 || x >= this.w || y >= this.h) ? NONE : this.px[y * this.w + x]; };
  Plane.prototype.rect = function (x, y, w, h, s) { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) this.set(x + i, y + j, s); };
  Plane.prototype.hline = function (x0, x1, y, s) { for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) this.set(x, y, s); };
  Plane.prototype.vline = function (x, y0, y1, s) { for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++) this.set(x, y, s); };

  function hash2(x, y) { let n = (x | 0) * 374761393 + (y | 0) * 668265263; n = Math.imul(n ^ (n >>> 13), 1274126177); return ((n ^ (n >>> 16)) >>> 0) / 4294967296; }
  const cellX = (i) => (i % GW) * CELL, cellY = (i) => FIELD_Y + ((i / GW) | 0) * CELL;
  const centre = (i) => ({ x: cellX(i) + 3.5, y: cellY(i) + 3.5 });
  function line(p, x0, y0, x1, y1, s) {
    const n = Math.max(1, Math.ceil(Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0))));
    for (let k = 0; k <= n; k++) p.set(Math.round(x0 + (x1 - x0) * k / n), Math.round(y0 + (y1 - y0) * k / n), s);
  }

  /* ------------------------------------------------------------------ water */
  /** Calm evening water: shade 0 with short shade-1 ripple dashes, hashed per pixel row so no stretch repeats. */
  function waterPixel(px, py) {
    const row = py % 3 === 1, ph = (px + Math.floor(hash2(0, py) * 11)) % 9;
    if (row && ph < 3 && hash2(px >> 2, py) < 0.42) return FACE;
    if (hash2(px, py * 3 + 7) < 0.012) return FACE;
    return LIT;
  }

  /* ------------------------------------------------------------------ the anchorage */
  /** The static picture of an anchorage (water, islands, quay, the free moorings). `A` from ANCHORAGE.generate. */
  function anchoragePlane(A) {
    const p = new Plane(W, H, LIT);
    const landC = (x, y) => (x < 0 || y < 0 || x >= GW) ? false : (y >= GH ? true : !!A.land[y * GW + x]);
    // pixel land mask for the field, with outer corners rounded where both orthogonal neighbours are water
    const FH = GH * CELL, mask = new Uint8Array(W * FH);
    for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
      if (!A.land[y * GW + x]) continue;
      const L = landC(x - 1, y), R = landC(x + 1, y), U = landC(x, y - 1), D = landC(x, y + 1);
      const ul = !L && !U, ur = !R && !U, dl = !L && !D, dr = !R && !D;
      for (let j = 0; j < CELL; j++) for (let i = 0; i < CELL; i++) {
        const cut = (ul && i + j < 3) || (ur && (7 - i) + j < 3) || (dl && i + (7 - j) < 3) || (dr && (7 - i) + (7 - j) < 3);
        if (!cut) mask[(y * CELL + j) * W + x * CELL + i] = 1;
      }
    }
    const isLand = (px, fy) => (px < 0 || px >= W || fy < 0) ? false : (fy >= FH ? true : !!mask[fy * W + px]);
    for (let fy = 0; fy < FH; fy++) for (let px = 0; px < W; px++) {
      const py = FIELD_Y + fy;
      if (!isLand(px, fy)) { p.set(px, py, waterPixel(px, py)); continue; }
      const cy = (fy / CELL) | 0, cx = (px / CELL) | 0, kind = A.kind[cy * GW + cx];
      const rim = !isLand(px - 1, fy) || !isLand(px + 1, fy) || !isLand(px, fy - 1) || !isLand(px, fy + 1);
      if (kind === QUAY) { p.set(px, py, quayPixel(px, fy - (GH - 1) * CELL, !isLand(px, fy - 1))); continue; }
      if (rim) { p.set(px, py, SHADOW); continue; }
      // the lit shore: the band just inside a coastline that faces up or left (the evening light is low in the west)
      const lit = (!isLand(px, fy - 1 - 0) || !isLand(px, fy - 2) || !isLand(px - 1, fy) || !isLand(px - 2, fy)) && hash2(px, py) < 0.8;
      if (lit) { p.set(px, py, FACE); continue; }
      // ⛔ ART ROUND 1: 10% dark specks made every island a noisy mat that hid its own pines. 3% now.
      const h = hash2(px * 5 + 1, py * 3 + A.seed);
      p.set(px, py, h < 0.03 ? SHADOW : h < 0.08 ? FACE : MID);
    }
    // a 1-px shallows glint on the water side of every coastline facing the light (texture, shade 1)
    for (let fy = 1; fy < FH; fy++) for (let px = 1; px < W; px++) {
      if (isLand(px, fy)) continue;
      if ((isLand(px + 1, fy) || isLand(px, fy + 1)) && hash2(px, fy * 7) < 0.55) p.set(px, FIELD_Y + fy, FACE);
    }
    // trees and rocks on the islands: dark pines on interior cells, a rock on some shore cells (hashed per cell)
    for (let y = 0; y < GH - 1; y++) for (let x = 0; x < GW; x++) {
      if (A.kind[y * GW + x] !== ISLAND) continue;
      const interior = landC(x - 1, y) && landC(x + 1, y) && landC(x, y - 1) && landC(x, y + 1) && A.kind[(y + 1) * GW + x] !== QUAY;
      const h = hash2(x * 13 + A.seed, y * 7 + 3);
      const X = x * CELL, Y = FIELD_Y + y * CELL;
      if (interior || h < 0.6) {
        // a stand of pines: two on an interior cell, one on a shore cell, kept 2 px inside the coastline
        const n = interior ? 2 : 1;
        for (let t = 0; t < n; t++) {
          const tx = X + (n === 2 ? (t === 0 ? 2 : 6) : 3 + Math.floor(hash2(x + 3, y + A.seed) * 2)), ty = Y + (n === 2 ? (t === 0 ? 0 : 2) : 1);
          pine(p, tx, ty);
        }
      } else if (h < 0.85) { const rx = X + 2 + Math.floor(h * 7) % 3, ry = Y + 3; p.rect(rx, ry, 3, 2, SHADOW); p.set(rx, ry, FACE); p.set(rx + 1, ry, FACE); }
    }
    // the quay furniture: bollards and harbour lamps (lit, it is dusk), spaced by hash
    for (let x = 0; x < GW; x++) {
      const c = (GH - 1) * GW + x; if (A.kind[c] !== QUAY || A.land[c - GW]) continue;
      const X = x * CELL, Y = FIELD_Y + (GH - 1) * CELL, h = hash2(x * 17 + A.seed, 91);
      if (h < 0.3) { p.rect(X + 3, Y + 2, 2, 2, SHADOW); p.set(X + 3, Y + 2, FACE); }
      else if (h < 0.45) { p.vline(X + 4, Y + 1, Y + 5, SHADOW); p.rect(X + 3, Y, 3, 2, SHADOW); p.set(X + 4, Y, LIT); }
    }
    return p;
  }
  /** The quay: a dark edge against the water, a lit coping, then coursed stone (shade 2 stones, dark joints). */
  function quayPixel(px, j, edge) {
    if (edge && j <= 0) return SHADOW;
    if (j === 1) return FACE;
    const row = Math.floor((j - 2) / 3), off = (row % 2) * 3, stone = ((px + off) % 6 !== 0) && ((j - 2) % 3 !== 2);
    return stone ? (hash2(px, j + 50) < 0.15 ? FACE : MID) : SHADOW;
  }
  function pine(p, x, y) {
    // 5 x 6: a tip, two widening tiers and a trunk — dark on the island's shade-2 ground, a lit needle on the sun side
    const rows = ['..3..', '.333.', '..3..', '.333.', '33333', '..3..'];
    for (let j = 0; j < rows.length; j++) for (let i = 0; i < 5; i++) if (rows[j][i] === '3') p.set(x + i - 2, y + j, SHADOW);
    p.set(x - 1, y + 3, FACE);
  }

  /* ------------------------------------------------------------------ the fleet */
  /* ⛔ ART ROUND 1 (LOOKED AT art/zoom_fleet_4x.png): boats drawn inside their own 8x8 cell had 2-3 px sails and read
   * as CUPS, all seven alike, and the free moorings (a buoy with a knob) read as boats. A boat is now 8 wide x 12 tall:
   * her sail rises 4 px into the cell above (a boat waits in OPEN water, so that cell is always water and never holds
   * another boat or a mooring — the generator keeps every pair 2 cells apart). Six rig SILHOUETTES (a leg-of-mutton,
   * a gaff, a sloop, a cutter, a lateen, a square sail), three cloths (tan, white, tarred), so a fleet reads as eight
   * different boats at 1x. A mooring is now LOW and ROUND with no mast, so nothing tall is ever a buoy. */
  // rig templates, bow to the RIGHT, 8 wide x 8 rows (the rows above the hull); M = mast, S = main cloth, J = jib cloth
  const RIG_ROWS = {
    tri:     ['....M...', '...SM...', '...SM...', '..SSM...', '..SSM...', '.SSSM...', 'SSSSM...', 'SSSSM...'],
    gaff:    ['..SSM...', '.SSSM...', '.SSSM...', 'SSSSM...', 'SSSSM...', 'SSSSM...', 'SSSSM...', 'SSSSM...'],
    sloop:   ['....M...', '...SMJ..', '...SMJ..', '..SSMJJ.', '..SSMJJ.', '.SSSMJJJ', 'SSSSMJJJ', 'SSSSM...'],
    cutter:  ['..SSM...', '.SSSMJ..', '.SSSMJ..', 'SSSSMJJ.', 'SSSSMJJ.', 'SSSSMJJJ', 'SSSSMJJJ', 'SSSSM...'],
    lateen:  ['S.......', 'SS......', 'SSS.M...', 'SSSSM...', 'SSSSMS..', 'SSSSMSS.', '.SSSMSSS', '....M...'],
    // ⛔ ART ROUND 2: a bellied square sail in white read as a round LANTERN at 1x. A flat yard, straight sides.
    square:  ['SSSSSSS.', 'SSSSSSS.', 'SSSSSSS.', 'SSSSSSS.', 'SSSSSSS.', '.SSSSS..', '....M...', '....M...'],
  };
  const RIGS = Object.keys(RIG_ROWS), CLOTHS = ['tan', 'white', 'tarred'];
  /** A fishing boat's generated design. `seed` = the anchorage seed, `i` = the boat's index in its fleet. Designs in
   *  one fleet are forced distinct on (rig, cloth) — 18 pairs for at most 8 boats — by walking the choice until unused. */
  function fleetDesigns(seed, k) {
    const used = new Set(), out = [];
    for (let i = 0; i < k; i++) {
      const h = (n) => hash2(seed * 131 + i * 17 + n, seed + n * 29);
      // tan (the fishing fleet's barked cloth) is the most common, then white, then tarred
      let rig = Math.floor(h(1) * RIGS.length), cloth = h(3) < 0.45 ? 0 : h(3) < 0.75 ? 1 : 2;
      let guard = 0;
      while (used.has(rig + ':' + cloth) && guard++ < 40) { rig = (rig + 1) % RIGS.length; if (guard % RIGS.length === 0) cloth = (cloth + 1) % 3; }
      used.add(rig + ':' + cloth);
      out.push({ rig: RIGS[rig], len: 6 + Math.floor(h(2) * 3), cloth: CLOTHS[cloth], bow: h(4) < 0.5 ? 'raked' : 'plumb', stern: h(5) < 0.5 ? 'transom' : 'canoe',
        strake: h(6) < 0.55, pennant: h(7) < 0.5, face: h(8) < 0.5 ? 1 : -1 });
    }
    return out;
  }
  /** Draw a boat whose HULL sits in the 8x8 box at (X, Y) (the top-left of her cell, or any point for an animation);
   *  her rig rises 4 px above it. mode: 'sail' (waiting at anchor, sails up) · 'home' (moored: sail furled, masthead
   *  lamp lit) · 'ghost' (a dotted outline). */
  function drawBoat(p, X, Y, d, mode) {
    X = Math.round(X); Y = Math.round(Y);
    const f = d.face, ghost = mode === 'ghost';
    const bx = (i) => f > 0 ? X + i : X + 7 - i;               // template column -> screen x (mirrored for a left-facing boat)
    // ⛔ REVIEW 2026-09-28 (defect 7): a boat waiting in ROW 0 raised her rig into the HUD's second text line (27/40
    // anchorages have one). A boat on the field never draws above FIELD_Y - 3: her masthead is cut at the horizon.
    const minY = Y >= FIELD_Y ? FIELD_Y - 3 : -Infinity;
    const put = (x, y, s) => { if (y < minY) return; if (ghost) { if ((x + y) % 2 === 0) p.set(x, y, SHADOW); return; } p.set(x, y, s); };
    const pset = (x, y, s) => { if (y >= minY) p.set(x, y, s); };
    // hull: the sheer (row 4), the side (row 5), the bilge (row 6, inset), a shade-1 reflection (row 7)
    const x0 = Math.round(4 - d.len / 2), x1 = x0 + d.len - 1;   // template columns, bow at x1
    for (let i = x0; i <= x1; i++) { put(bx(i), Y + 4, SHADOW); put(bx(i), Y + 5, SHADOW); }
    for (let i = x0 + 1; i <= x1 - (d.stern === 'canoe' ? 1 : 0) - 1 + (d.bow === 'raked' ? 0 : 1); i++) put(bx(i), Y + 6, SHADOW);
    if (d.bow === 'raked') put(bx(x1 + 1), Y + 3, SHADOW);
    if (d.stern === 'canoe' && !ghost) p.set(bx(x0), Y + 5, LIT);
    if (d.strake && !ghost) for (let i = x0 + 1; i <= x1 - 1; i++) p.set(bx(i), Y + 5, FACE);
    if (!ghost) for (let i = x0; i <= x1; i += 2) p.set(bx(i), Y + 7, FACE);
    const top = Y - 4;                                          // template row 0
    if (mode === 'home') {
      // ⛔ STORE-SHOT ROUND 1 (shot_4 at 4x): a bare mast with a 2-px bundle read as an ANCHOR SYMBOL. Moored now: the
      // mast, the sail furled as a fat cloth roll along a boom (her own cloth tone, outlined), a riding lamp lit at the
      // masthead, and her mooring buoy peeping out at the bow.
      for (let y = top + 1; y <= Y + 3; y++) put(bx(4), y, SHADOW);
      for (let i = 0; i <= 4; i++) put(bx(4 - i), Y + 3, SHADOW);
      if (!ghost) {
        const roll = d.cloth === 'white' ? LIT : d.cloth === 'tan' ? MID : SHADOW;
        for (let i = 0; i <= 3; i++) { pset(bx(3 - i), Y + 1, SHADOW); pset(bx(3 - i), Y + 2, i === 0 || i === 3 ? SHADOW : roll); }
        pset(bx(4), top, LIT); pset(bx(3), top, SHADOW); pset(bx(5), top, SHADOW); pset(bx(4), top - 1, SHADOW);
        pset(bx(x1 + 1), Y + 6, SHADOW); pset(bx(x1 + 1), Y + 5, SHADOW); pset(bx(x1 + 2), Y + 6, LIT);
      }
      return;
    }
    const R = RIG_ROWS[d.rig];
    const cell = (i, j) => (i < 0 || i > 7 || j < 0 || j > 7) ? '.' : R[j][i];
    const isCloth = (i, j) => { const c = cell(i, j); return c === 'S' || c === 'J'; };
    for (let j = 0; j < 8; j++) for (let i = 0; i < 8; i++) {
      const c = R[j][i]; if (c === '.') continue;
      const x = bx(i), y = top + j;
      if (c === 'M') { put(x, y, SHADOW); continue; }
      const edge = !isCloth(i - 1, j) || !isCloth(i + 1, j) || !isCloth(i, j - 1) || !isCloth(i, j + 1);
      if (ghost) { if (edge) put(x, y, SHADOW); continue; }
      let s;
      if (d.cloth === 'white') s = edge ? SHADOW : LIT;
      else if (d.cloth === 'tan') s = edge ? SHADOW : MID;
      else s = (!edge && j % 3 === 1) ? MID : SHADOW;          // tarred: dark cloth with shade-2 panel seams
      pset(x, y, s);
    }
    if (d.pennant && !ghost) { pset(bx(4), top - 1, SHADOW); pset(bx(5), top - 1, SHADOW); pset(bx(6), top - 1, SHADOW); }
  }

  /** THE PILOT LAUNCH — the one powered boat on the water: a low dark hull, a wheelhouse with lit windows, and a
   *  masthead light that blinks. `frame` 0/1 = light on/off; `wake` draws a bow wave while she moves. */
  function drawPilot(p, X, Y, frame, wake) {
    X = Math.round(X); Y = Math.round(Y);
    // 9 wide x 8 tall (her masthead light rises above the cell): a raised stem at the bow, a long foredeck, a
    // wheelhouse aft with ONE wide lit window, a dark hull. No sail — she is the one boat on the water with an engine.
    // ⛔ STORE-SHOT ROUND 1 (LOOKED AT shot_2_in_tow.png at 4x): the old launch was a dark box with TWO lit windows side
    // by side, and inside its blinking brackets it read as a bug's FACE. One window, a bow, a foredeck: a boat.
    const HULL = ['.......3.', '.......3.', '.....3333', '.....3003', '3....3333', '333333333', '.3333333.', '..33333..'];
    const ox = X - 1, top = Y;
    for (let j = 0; j < HULL.length; j++) for (let i = 0; i < 9; i++) if (HULL[j][i] !== '.') for (const [dx, dy] of [[1, 0], [-1, 0], [0, -1], [0, 1]]) {
      const ni = i + dx, nj = j + dy; if (ni < 0 || nj < 0 || ni >= 9 || nj >= HULL.length || HULL[nj][ni] === '.') p.set(ox + ni, top + nj, LIT);
    }
    for (let j = 0; j < HULL.length; j++) for (let i = 0; i < 9; i++) { const ch = HULL[j][i]; if (ch === '3') p.set(ox + i, top + j, SHADOW); else if (ch === '0') p.set(ox + i, top + j, LIT); }
    // the masthead light: lit and ringed dark on frame 0, dark on frame 1 (it blinks)
    if (!frame) { p.set(ox + 7, top - 1, LIT); p.set(ox + 6, top - 1, SHADOW); p.set(ox + 8, top - 1, SHADOW); p.set(ox + 7, top - 2, SHADOW); }
    else p.set(ox + 7, top - 1, SHADOW);
    if (wake) { p.set(ox - 1, top + 5, FACE); p.set(ox - 2, top + 6, FACE); p.set(ox + 9, top + 6, FACE); p.set(ox + 10, top + 6, FACE); }
  }

  /** A free mooring: a LOW, ROUND buoy (dark, with a lit band round its middle) riding a shade-1 ripple ring — no mast,
   *  so nothing tall is ever a buoy (ART ROUND 1). */
  function drawMooring(p, c) {
    const X = cellX(c), Y = cellY(c);
    const B = ['.3333.', '333333', '300003', '333333', '.3333.'];
    for (let j = 0; j < B.length; j++) for (let i = 0; i < 6; i++) { const ch = B[j][i]; if (ch === '3') p.set(X + 1 + i, Y + 2 + j, SHADOW); else if (ch === '0') p.set(X + 1 + i, Y + 2 + j, LIT); }
    for (const [dx, dy] of [[0, 3], [7, 3], [0, 5], [7, 5], [2, 7], [5, 7], [1, 1], [6, 1]]) p.set(X + dx, Y + dy, FACE);
  }

  /** A tow line along a list of cells (dotted through the cell centres). `phase` animates the dots. */
  function drawLine(p, cells, s, phase, gap) {
    gap = gap || 3;
    for (let k = 1; k < cells.length; k++) {
      const a = centre(cells[k - 1]), b = centre(cells[k]);
      const n = 8;
      for (let t = 0; t < n; t++) { if ((t + k * n + (phase || 0)) % gap === 0) continue; p.set(Math.round(a.x + (b.x - a.x) * t / n), Math.round(a.y + (b.y - a.y) * t / n) + 1, s); }
    }
  }

  /** The HUD's boat glyph (7x7): lit = home on her mooring, dark = still out on the water. */
  function boatGlyph(p, x, y, home) {
    const G = ['...3...', '..33...', '.333...', '3333...', '...3...', '3333333', '.33333.'];
    for (let j = 0; j < G.length; j++) for (let i = 0; i < 7; i++) if (G[j][i] === '3') p.set(x + i, y + j, home ? LIT : SHADOW);
  }

  /** The sky band (24 rows): dusk. Shade-2 sky, long shade-1 cloud bars, a low lit sun sinking into a far sea, and the
   *  dark line of distant islands along the horizon. */
  function skyBand(p, seedVar) {
    for (let y = 0; y < FIELD_Y; y++) for (let x = 0; x < W; x++) p.set(x, y, MID);
    [[18 + seedVar * 5, 7, 18], [96 - seedVar * 3, 4, 24], [140, 11, 14]].forEach(([cx, cy, L]) => { for (let i = -L; i <= L; i++) { if (hash2(cx + i, cy) < 0.85) p.set(cx + i, cy, FACE); if (Math.abs(i) < L - 5) p.set(cx + i + 2, cy + 1, FACE); } });
    // the sun, half down, and its glitter on the far sea
    const sx = 120 + (seedVar % 3) * 6, sy = FIELD_Y - 4;
    for (let j = -6; j <= 0; j++) for (let i = -6; i <= 6; i++) if (i * i + j * j <= 30) p.set(sx + i, sy + j, LIT);
    for (let y = sy + 1; y < FIELD_Y - 1; y++) for (let x = 0; x < W; x++) p.set(x, y, FACE);
    for (let y = sy + 1; y < FIELD_Y - 1; y++) for (let i = -8; i <= 8; i++) if (hash2(sx + i, y) < 0.55 - Math.abs(i) * 0.05) p.set(sx + i, y, LIT);
    // far islands on the horizon: dark humps, hashed so every anchorage's horizon differs
    for (let x = 0; x < W; x++) {
      const hh = Math.max(0, Math.round(2.4 * Math.sin(x * 0.07 + seedVar) + 1.6 * Math.sin(x * 0.19 + seedVar * 2) - 0.6));
      for (let y = sy + 1 - hh; y <= sy; y++) if (Math.abs(x - sx) > 7 || y > sy - 1) p.set(x, y, SHADOW);
    }
    p.hline(0, W - 1, FIELD_Y - 1, SHADOW);
  }

  /* ============================================================================ THE TITLE ART
   * Baked to art/title.png by Internal_Ops/build_art.js (a REAL shipped file, drawn with drawImage — never read back,
   * so it works on the paid build's file:// origin). A headland with a lighthouse on the left, the sun going down
   * over the far islands, the fleet coming home under tan sails across lit water, buoys waiting in the foreground,
   * the lettering in a dark band at the top. */
  function titlePlane(font) {
    const p = new Plane(W, H, MID);
    // sky: shade 2 with cloud bars
    [[30, 34, 26], [110, 30, 34], [70, 44, 20]].forEach(([cx, cy, L]) => { for (let i = -L; i <= L; i++) { p.set(cx + i, cy, FACE); if (Math.abs(i) < L - 7) p.set(cx + i + 3, cy - 1, FACE); } });
    const HZ = 70, sx = 104;
    // the sun on the horizon, a clean disc crossed by two thin cloud streaks (TITLE ROUND 1: a hashed halo read as noise)
    for (let j = -11; j <= 0; j++) for (let i = -11; i <= 11; i++) if (i * i + j * j <= 121) p.set(sx + i, HZ + j, LIT);
    for (const [yy, a, b] of [[HZ - 7, -16, 9], [HZ - 3, -6, 18]]) for (let i = a; i <= b; i++) p.set(sx + i, yy, i * i + (yy - HZ) * (yy - HZ) <= 121 ? MID : FACE);
    // far islands on the horizon
    for (let x = 0; x < W; x++) { const hh = Math.max(0, Math.round(3 * Math.sin(x * 0.05 + 1) + 2 * Math.sin(x * 0.17) - 1)); for (let y = HZ - hh; y <= HZ; y++) if (Math.abs(x - sx) > 12 || y >= HZ) p.set(x, y, SHADOW); }
    // the sea: shade 0 below the horizon with ripples that lengthen toward the viewer, a glitter road under the sun
    for (let y = HZ + 1; y < H; y++) for (let x = 0; x < W; x++) {
      const depth = (y - HZ) / (H - HZ), len = 2 + Math.round(depth * 8), ph = (x + Math.floor(hash2(1, y) * 40)) % (len * 3);
      let s = (y % (2 + Math.round(depth * 3)) === 0 && ph < len) ? FACE : LIT;
      if (y < HZ + 5) s = (hash2(x, y) < 0.5) ? FACE : LIT;
      const road = Math.abs(x - sx) < 4 + depth * 22 && y % 2 === 0 && hash2(x >> 1, y) < 0.35 - depth * 0.15;
      if (road) s = LIT; else if (Math.abs(x - sx) < 4 + depth * 22 && s === FACE) s = LIT;
      p.set(x, y, s);
    }
    // the headland and the lighthouse, left.
    // ⛔ TITLE ROUND 1 (LOOKED AT 01_title.png): the headland was a speckled wedge with a hard vertical edge (it read as
    // a WALL) and the lamp's beams were hashed dots that read as static. Now: a rounded hill that runs down into the sea
    // with a rocky, foamed shoreline, a lit rim on its sun side, pines on the ridge; the beams are two solid lit rays.
    const shore = HZ + 20;
    // TITLE ROUND 2: a 24 px peak put the lantern and both beams UNDER the lettering band. Lower hill, shorter tower.
    const head = (x) => Math.round(HZ - 16 * Math.exp(-((x - 16) ** 2) / 520) + Math.max(0, x - 40) * 0.9);
    for (let x = 0; x < 72; x++) {
      const top = head(x); if (top >= shore) continue;
      for (let y = top; y <= shore; y++) {
        const rim = y === top || y === top + 1, lit = !rim && y <= top + 3 && x > 16;
        p.set(x, y, rim ? SHADOW : lit ? FACE : (hash2(x, y) < 0.03 ? SHADOW : MID));
      }
    }
    for (let x = 0; x < 72; x++) { if (head(x) >= shore) continue; p.set(x, shore, SHADOW); p.set(x, shore + 1, hash2(x, 3) < 0.6 ? LIT : FACE); if (hash2(x, 9) < 0.3) p.set(x, shore - 1, SHADOW); }
    [[4, 1], [9, 0], [27, 1], [33, 0], [44, 2], [52, 1]].forEach(([tx, v]) => { const ty = head(tx) - 4; pine(p, tx, ty + v); });
    const lx = 16, lb = head(lx) + 1, lt = lb - 20;
    for (let y = lt; y <= lb; y++) { const half = 3 + (y - lt) / (lb - lt) * 2; for (let x = Math.round(lx - half); x <= Math.round(lx + half); x++) { const edge = x === Math.round(lx - half) || x === Math.round(lx + half); const band = Math.floor((y - lt) / 5) % 2 === 1; p.set(x, y, edge ? SHADOW : band ? SHADOW : LIT); } }
    p.rect(lx - 5, lt - 2, 11, 2, SHADOW); p.rect(lx - 3, lt - 8, 7, 6, SHADOW); p.rect(lx - 2, lt - 7, 5, 4, LIT); p.rect(lx - 3, lt - 10, 7, 2, SHADOW); p.set(lx, lt - 11, SHADOW); p.set(lx, lt - 12, SHADOW);
    // the lamp's two beams: solid lit rays widening out to the right over the sky, edged in shade 1
    for (let t = 4; t < 92; t++) {
      const cy = lt - 5, a0 = cy - 1 - t * 0.05, a1 = cy + 1 + t * 0.06;
      for (let y = Math.round(a0); y <= Math.round(a1); y++) { const edge = y === Math.round(a0) || y === Math.round(a1); if (p.get(lx + t, y) === MID || p.get(lx + t, y) === FACE) p.set(lx + t, y, edge ? FACE : LIT); }
    }
    // the fleet coming home: far (small), middle, near (big)
    // ⛔ REVIEW 2026-09-28 (defect 10): the FREE EDITION band (x 36-124, y 118-128) cut the near boat's hull and the
    // Z OR TAP band (x 44-116, y 131-142) hid two of the three buoys. The near boat now rides above the bands and the
    // buoys sit either side of them.
    bigBoat(p, 78, HZ + 2, 0.45, MID); bigBoat(p, 136, HZ + 6, 0.6, LIT); bigBoat(p, 92, HZ + 20, 1.0, MID); bigBoat(p, 134, HZ + 36, 1.3, MID);
    // buoys waiting in the foreground — the SAME low round buoy as the game's moorings (TITLE ROUND 2: the old bell shape)
    [[8, 126], [20, 136], [138, 130]].forEach(([bx, by]) => { const B = ['..3333..', '.333333.', '30000003', '33333333', '.333333.', '..3333..']; for (let j = 0; j < B.length; j++) for (let i = 0; i < 8; i++) { const ch = B[j][i]; if (ch === '3') p.set(bx + i, by + j, SHADOW); else if (ch === '0') p.set(bx + i, by + j, LIT); } for (let i = -3; i <= 10; i++) if (i < 0 || i > 7) p.set(bx + i, by + 4, FACE); });
    if (font) {
      p.rect(0, 2, W, 20, SHADOW); p.hline(0, W - 1, 1, MID); p.hline(0, W - 1, 22, MID);
      font.textPlane(p, 'PILOTAGE', W / 2, 6, { align: 'center', face: 'display', shade: LIT });
    }
    return p;
  }
  /** A title-art fishing boat at scale s: a dark hull, a mast and a big lug sail (shade `cloth`) with a dark leech. */
  function bigBoat(p, x, y, s, cloth) {
    const L = Math.round(26 * s), hh = Math.max(2, Math.round(5 * s)), mh = Math.round(30 * s);
    for (let j = 0; j < hh; j++) { const inset = Math.round(j * 1.2); for (let i = inset; i < L - inset * 0.6; i++) p.set(x - L / 2 + i, y + j, SHADOW); }
    for (let i = 0; i < L; i++) if (hash2(i, y) < 0.7) p.set(x - L / 2 + i, y + hh, FACE);
    const mx = Math.round(x + L * 0.1);
    for (let j = 1; j <= mh; j++) p.set(mx, y - j, SHADOW);
    const top = y - mh + 1, bot = y - Math.max(2, Math.round(3 * s));
    for (let yy = top; yy <= bot; yy++) { const t = (yy - top) / Math.max(1, bot - top), w = Math.round((6 + 10 * t) * s); for (let i = 1; i <= w; i++) { const edge = i === w || yy === top || yy === bot; p.set(mx - i, yy, edge ? SHADOW : cloth); } }
    const jt = y - Math.round(mh * 0.8);
    for (let yy = jt; yy <= bot; yy++) { const w = Math.round((yy - jt) * 0.45); for (let i = 1; i <= w; i++) p.set(mx + i, yy, i === w ? SHADOW : cloth); }
  }

  return { LIT, FACE, MID, SHADOW, NONE, W, H, FIELD_Y, CELL, GW, GH, Plane, hash2, cellX, cellY, centre, line, waterPixel, anchoragePlane, fleetDesigns, drawBoat, drawPilot, drawMooring, drawLine, boatGlyph, skyBand, titlePlane, pine };
}));
