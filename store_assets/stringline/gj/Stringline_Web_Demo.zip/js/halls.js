/* STRINGLINE - halls.js : the Great Hall of Castle Harrowgate (the free demo's room).
 * rows:    '#','O','A' stone · 'G' iron · 'P' wood (fixed pews) · '.' floor · ',' an opening in a wall (a slit, a door,
 *          an arch: floor you can stand in).
 * regions: the same grid; a letter marks a floor tile as part of a NAMED REGION an archer could have stood in unseen.
 *          '.' and ' ' = no region (open floor in plain sight). A letter on a solid tile is ignored.
 * The chapel and the gatehouse are in js/halls_full.js, which only the full game loads. Dual-mode like trace.js. */
(function (root) {
  'use strict';
  var HALLS = { great: {
    "id": "great",
    "title": "The Great Hall",
    "rows": [
      "#####,#####,######,#####",
      "#......................#",
      "#..O....O......O....O..#",
      ",......................#",
      "#......................#",
      "#......................,",
      "#..O....O......O....O..#",
      "#......................#",
      ",......................#",
      "#......................#",
      "#..O....O......O....O..#",
      "#......................#",
      "#......................#",
      "####,#######,#######,###"
    ],
    "regions": [
      "     a     a      a     ",
      " bbbbbbbbbbbbbbbbbbbbbb ",
      " cc..................dd ",
      "ccc..................dd ",
      " cc.eeeeeee..fffffff.dd ",
      " cc.eeeeeee..fffffff.ddd",
      " cc.eeeeeee..fffffff.dd ",
      " cc.eeeeeee..fffffff.dd ",
      "ccc.eeeeeee..fffffff.dd ",
      " cc..................dd ",
      " cc..................dd ",
      " ccggggggggggggggggggdd ",
      " ccggggggggggggggggggdd ",
      "    h       h       h   "
    ],
    "names": {
      "a": "the Falcon Slits",
      "b": "the Minstrels' Gallery",
      "c": "the West Aisle",
      "d": "the East Aisle",
      "e": "the West Pillars",
      "f": "the East Pillars",
      "g": "the High Table",
      "h": "the South Doors"
    }
  } };
  var API = { HALLS: HALLS, ORDER: ['great', 'chapel', 'gate'] };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  else root.SL_HALLS = API;
})(typeof window !== 'undefined' ? window : this);
