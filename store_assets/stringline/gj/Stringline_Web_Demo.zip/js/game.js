/* game.js - STRINGLINE. A castle whodunit where every clue is a line you draw.
 * The page owns one clock: tick(dt) is the ONLY place a frame happens; requestAnimationFrame calls it, and
 * window.__slTick(n) is a second caller so a harness can drive the SHIPPED build in a hidden tab
 * (Wings/Games/CLAUDE.md §6b-18). Every refusal names its reason (§0z-1c). */
(function (root) {
  'use strict';
  var TR = root.SL_TRACE, HL = root.SL_HALLS, R = root.SL_RENDER, F = root.SL_FONT, SND = root.SL_SOUND;
  var W = 480, H = 270, T = 16;
  var CASES = root.SL_CASES || [], TOTAL = root.SL_CASES_TOTAL || CASES.length, FULL = !!root.SL_FULL;
  var cv = document.getElementById('c'), g = cv.getContext('2d');
  g.imageSmoothingEnabled = false;
  var COL = { ink: '#efe3c4', dim: '#a8977a', faint: '#6f6250', gold: '#e8bd5a', red: '#c8413a', thread: '#f0473f', bg: '#140f0c', panel: '#221913', edge: '#6b4f2a', ok: '#9fc27a' };
  var SAVE_KEY = 'stringline.save.v1';
  var BAND_TXT = { buried: ['BURIED TO THE FLETCHING', 0, 7], sunk: ['HALF SUNK', 7, 14], shallow: ['BARELY IN', 14, 21] };

  // ---- save ----------------------------------------------------------------------------------------
  var save = { v: 1, seals: {} };
  try { var raw = localStorage.getItem(SAVE_KEY); if (raw) { var p = JSON.parse(raw); if (p && p.v === 1 && p.seals) save = p; } } catch (e) { /* storage refused: play without saving */ }
  function writeSave() { try { localStorage.setItem(SAVE_KEY, JSON.stringify(save)); } catch (e) { S.msg('YOUR BROWSER REFUSED TO SAVE PROGRESS.'); } }

  // ---- state ---------------------------------------------------------------------------------------
  var S = {
    screen: 'title', t: 0, book: 0, page: 0, pauseSel: 0, mouse: null, down: false, keys: {}, msgs: [], msgT: 0,
    C: null, verdict: null, frames: 0, lastRefusal: null,
    msg: function (m) { S.msgs.unshift(String(m).toUpperCase()); S.msgs.length = Math.min(S.msgs.length, 2); S.msgT = S.t; }
  };
  function sealOf(n) { return save.seals[n] || null; }
  /* review #4: a COLD case does not open the next one (it was reached with 14 cold cases and one solve) */
  function solvedSeal(n) { var s = sealOf(n); return s === 'clean' || s === 'solved'; }
  function unlocked(n) { if (n === 1) return true; if (n > CASES.length) return false; return solvedSeal(n - 1); }

  // ---- a case --------------------------------------------------------------------------------------
  function hallOf(id) { var h = HL.HALLS[id]; if (!h) throw new Error('hall ' + id + ' is not in this build'); return h; }
  function openCase(n) {
    var rec = CASES[n - 1]; if (!rec) throw new Error('case ' + n + ' is not in this build');
    var hall = hallOf(rec.hall);
    var base = TR.makeGrid(hall), cells = [];
    rec.furniture.forEach(function (o) { for (var i = 0; i < o.w; i++) cells.push({ x: o.x + i, y: o.y, ch: o.ch }); });
    var grid = TR.withFurniture(base, cells);
    S.C = {
      n: n, rec: rec, hall: hall, grid: grid, objects: rec.furniture,
      bolts: rec.bolts.map(function (b) { return { stop: b.stop, din: b.din, face: b.face, tile: b.tile, mat: b.mat, band: b.band }; }),
      strings: rec.bolts.map(function () { return { bends: [], len: 0 }; }),
      sel: 0, candles: 3, cold: false, solved: false, torn: rec.torn || [], layer: R.composeHall(hall, grid, rec.furniture), dragging: false
    };
    S.verdict = null;
    S.screen = 'case';
    SND.setMood(1);
    S.msg('DRAG FROM A BOLT TO PULL ITS STRING. THE RULES BUTTON SHOWS HOW TO PLAY.');
  }

  // ---- string geometry -----------------------------------------------------------------------------
  function dist(a, b) { return Math.hypot(a[0] - b[0], a[1] - b[1]); }
  function reach(i) { var C = S.C; return TR.stringPath(C.grid, C.bolts[i], C.strings[i].bends, TR.MAX_LEN); }
  function tailInfo(i) {
    var C = S.C, s = C.strings[i], b = C.bolts[i], full = reach(i), k = s.bends.length;
    var before = 0; for (var j = 0; j < k; j++) before += dist(full.points[j], full.points[j + 1]);
    var P = full.points[k], dir = k ? s.bends[k - 1] : [-b.din[0], -b.din[1]];
    var next = full.points[k + 1], tailMax = next ? dist(P, next) : 0;
    return { full: full, k: k, before: before, P: P, dir: dir, tailMax: tailMax, surface: full.surfaces[k] || null, pinSurface: k ? full.surfaces[k - 1] : null };
  }
  function awaySign(sf) { var a = sf.face === 'v' ? sf.dirIn[0] : sf.dirIn[1]; return -TR.sgn(a); }
  function nearestLeaving(sf, vx, vy) {
    var aw = awaySign(sf), n = sf.face === 'v' ? [aw, 0] : [0, aw];
    if (vx * n[0] + vy * n[1] <= 0.02) return null;
    var best = null, bc = -2, L = Math.hypot(vx, vy);
    TR.leavingDirs(sf.face, aw).forEach(function (d) { var c = (d[0] * vx + d[1] * vy) / (Math.hypot(d[0], d[1]) * L); if (c > bc) { bc = c; best = d; } });
    return best;
  }
  function stringNow(i) { var C = S.C; return TR.stringPath(C.grid, C.bolts[i], C.strings[i].bends, C.strings[i].len); }
  /* the mouse (in paces) pulls string i. Three gestures, none of which applies a rule (that is the player's job):
   *  - PULL PAST a surface: the string catches there (a pin), first bent as a mirror would bend it;
   *  - SWING around the pin, out in the open: the bend follows the mouse, snapped to the 16-point compass;
   *  - REEL BACK straight along the stretch that came into the pin: the pin comes out (unwind).
   * (A first version caught only when the pull ran PAST the surface along the old line AND out in the open: a steep
   * bend's new stretch projects BACKWARDS onto the old line, so a big bend could never be caught. Found by writing
   * the harness's mouse path, before any run.) */
  function pullTo(i, M) {
    var C = S.C, s = C.strings[i];
    for (var iter = 0; iter < 8; iter++) {
      var ti = tailInfo(i);
      var vx = M[0] - ti.P[0], vy = M[1] - ti.P[1], vl = Math.hypot(vx, vy);
      if (ti.k > 0) {
        var prev = ti.full.points[ti.k - 1], ux = ti.P[0] - prev[0], uy = ti.P[1] - prev[1], ul = Math.hypot(ux, uy);
        // reel back: the pull points (within 12 degrees) back down the stretch that came in
        if (vl > 0.6 && ul > 0 && (-(vx * ux + vy * uy) / (vl * ul)) > Math.cos(12 * Math.PI / 180)) { s.bends.pop(); SND.cue('sfx_unwind', 0.5); continue; }
        if (vl > 0.45) {
          var best = nearestLeaving(ti.pinSurface, vx, vy);
          if (best && (best[0] !== ti.dir[0] || best[1] !== ti.dir[1])) { s.bends[ti.k - 1] = best; continue; }
        }
      }
      var dl = Math.hypot(ti.dir[0], ti.dir[1]), t = (vx * ti.dir[0] + vy * ti.dir[1]) / dl;
      if (ti.surface && t > ti.tailMax + 0.25 && ti.k < TR.MAX_WRAPS && ti.before + ti.tailMax < TR.MAX_LEN - 0.05) {
        var hp = ti.surface.point, nb = nearestLeaving(ti.surface, M[0] - hp[0], M[1] - hp[1]) || TR.reflect(ti.dir, ti.surface.face);
        s.bends.push(nb); SND.cue('sfx_catch', 0.6); continue;
      }
      s.len = ti.before + Math.max(0, Math.min(t, ti.tailMax));
      if (ti.k === 0 && t < 0) s.len = 0;
      return;
    }
  }
  function extend(i, dp) {
    var C = S.C, s = C.strings[i], ti = tailInfo(i);
    var tail = s.len - ti.before + dp;
    if (tail > ti.tailMax) {
      if (ti.surface && ti.k < TR.MAX_WRAPS && dp > 0 && ti.before + ti.tailMax < TR.MAX_LEN - 0.05) {
        s.bends.push(TR.reflect(ti.dir, ti.surface.face)); s.len = ti.before + ti.tailMax; SND.cue('sfx_catch', 0.6); return;
      }
      tail = ti.tailMax;
    }
    if (tail < 0) { if (ti.k > 0) { s.bends.pop(); SND.cue('sfx_unwind', 0.5); s.len = ti.before; return; } tail = 0; }
    s.len = ti.before + tail;
  }
  function rotate(i, step) {
    var C = S.C, s = C.strings[i], ti = tailInfo(i);
    if (!ti.k) { S.msg('THE FIRST STRETCH RUNS ALONG THE SHAFT. PULL IT TO A SURFACE TO BEND IT.'); return; }
    var sf = ti.pinSurface, list = TR.leavingDirs(sf.face, awaySign(sf)).slice();
    list.sort(function (a, b) { return Math.atan2(a[1], a[0]) - Math.atan2(b[1], b[0]); });
    var at = list.findIndex(function (d) { return d[0] === ti.dir[0] && d[1] === ti.dir[1]; });
    var nx = list[(at + step + list.length) % list.length];
    s.bends[ti.k - 1] = nx;
    var t2 = tailInfo(i); if (s.len > t2.before + t2.tailMax) s.len = t2.before + t2.tailMax;
    SND.cue('sfx_select', 0.35);
  }
  function endRegion(i) {
    var C = S.C, s = C.strings[i]; if (s.len <= 0) return null;
    var sp = stringNow(i), e = sp.points[sp.points.length - 1], d = sp.dir, dl = Math.hypot(d[0], d[1]);
    return TR.regionAt(C.grid, Math.floor(e[0] - d[0] / dl * 1e-3), Math.floor(e[1] - d[1] / dl * 1e-3));
  }
  function meetRegion() {
    var C = S.C, r = null;
    for (var i = 0; i < C.strings.length; i++) { var e = endRegion(i); if (!e) return null; if (r && r !== e) return null; r = e; }
    return r;
  }
  function regionName(id) { var r = S.C.grid.regions[id]; return r ? r.name.toUpperCase() : 'THE OPEN HALL'; }

  // ---- the court -----------------------------------------------------------------------------------
  function hearingBlocked() {
    var C = S.C;
    for (var i = 0; i < C.strings.length; i++) if (C.strings[i].len <= 0) return 'BOLT ' + (i + 1) + ' HAS NO STRING YET.';
    for (i = 0; i < C.strings.length; i++) if (!endRegion(i)) return 'STRING ' + (i + 1) + ' ENDS IN THE OPEN HALL. NO ARCHER STOOD THERE UNSEEN.';
    if (!meetRegion()) return 'THE STRINGS DO NOT MEET. THEY MUST ALL END WHERE THE ARCHER STOOD.';
    return null;
  }
  function brokenText(i, br) {
    var C = S.C, sp = stringNow(i);
    if (br.rule === 'R6') { var bt = BAND_TXT[br.band]; return 'BOLT ' + (i + 1) + ' IS ' + bt[0] + ': IT FLEW ' + bt[1] + ' TO ' + bt[2] + ' PACES. YOUR STRING RUNS ' + br.len.toFixed(1) + '.'; }
    var sf = sp.surfaces[br.bend], what = sf ? (R.describeTile(C.grid, C.objects, sf.tile[0], sf.tile[1]) || 'THAT').split(':')[0] : 'THAT';
    // review #12/#13: say WHICH bolt, and speak in the chalk ANGLE NUMBERS the board draws
    var who = 'BOLT ' + (i + 1) + ': ';
    if (br.rule === 'R3') return who + 'WOOD HOLDS A BOLT. NOTHING GLANCES OFF THE ' + what + '.';
    if (br.rule === 'R1' && br.why === 'steep') return who + 'STONE THROWS A BOLT BACK ONLY AT ANGLE 1. NOT OFF THE ' + what + ' AT THAT ANGLE.';
    if (br.rule === 'R1') return who + 'STONE SENDS A BOLT OFF AT THE SAME ANGLE IT CAME IN. CHECK THE CHALK AT THE ' + what + '.';
    if (br.rule === 'R2') return who + 'IRON SENDS A BOLT AWAY ONE ANGLE FLATTER THAN IT CAME IN. CHECK THE CHALK AT THE ' + what + '.';
    return who + 'A BOLT KEEPS ITS COURSE ALONG A WALL: IT CANNOT DOUBLE BACK AT THE ' + what + '.';
  }
  function callHearing() {
    var C = S.C; if (!C || C.solved) return;
    if (C.cold) { S.msg('THE CASE IS COLD. PRESS REOPEN (OR R) TO TRY AGAIN.'); S.lastRefusal = 'cold'; return; }
    var why = hearingBlocked();
    if (why) { S.msg(why); S.lastRefusal = why; SND.cue('sfx_ui', 0.4); return; }
    SND.cue('sfx_gavel', 0.8);
    for (var i = 0; i < C.strings.length; i++) {
      var s = C.strings[i], j = TR.judgeString(C.grid, C.bolts[i], s.bends, s.len);
      if (!j.ok) {
        C.candles--;
        S.verdict = { ok: false, text: brokenText(i, j.broken), bolt: i, rule: j.broken.rule, t: S.t };
        SND.cue('sfx_candle', 0.8);
        if (C.candles <= 0) { C.cold = true; if (!sealOf(C.n)) { save.seals[C.n] = 'cold'; writeSave(); } SND.cue('sfx_cold', 0.8); }
        S.screen = 'verdict';
        return;
      }
    }
    var region = meetRegion();
    C.solved = true;
    var seal = C.candles === 3 ? 'clean' : 'solved';
    var prev = sealOf(C.n);
    if (prev !== 'clean') { save.seals[C.n] = seal; writeSave(); }
    S.verdict = { ok: true, region: region, name: regionName(region), who: (C.rec.roster && C.rec.roster[region]) || '', seal: seal, t: S.t };
    SND.cue('sfx_seal', 0.9);
    S.screen = 'verdict';
  }
  function afterVerdict() {
    var C = S.C, v = S.verdict;
    if (!v.ok) { S.screen = 'case'; if (C.cold) S.msg('THE MAGISTRATE RISES. THE CASE GOES COLD. PRESS REOPEN (OR R).'); return; }
    if (C.n === CASES.length && !FULL) { S.screen = 'demoend'; SND.setMood(0); return; }
    if (C.n === TOTAL && FULL) { S.screen = 'ending'; SND.setMood(0); return; }
    S.screen = 'book'; S.book = Math.min(C.n, CASES.length - 1); SND.setMood(0);
  }
  function reopen() { var n = S.C.n; openCase(n); S.msg('THE CASE IS REOPENED WITH THREE FRESH CANDLES.'); }

  // ---- input ---------------------------------------------------------------------------------------
  function toLogical(ev) {
    var r = cv.getBoundingClientRect();
    return [(ev.clientX - r.left) * W / r.width, (ev.clientY - r.top) * H / r.height];
  }
  function toPaces(p) { return [(p[0] - R.HX) / T, (p[1] - R.HY) / T]; }
  function inHall(p) { return p[0] >= R.HX && p[1] >= R.HY && p[0] < R.HX + 24 * T && p[1] < R.HY + 14 * T; }
  function boltAt(p) {
    var C = S.C, best = -1, bd = 1e9;
    C.bolts.forEach(function (b, i) { var d = Math.hypot(R.px(b.stop[0]) - p[0], R.py(b.stop[1]) - p[1]); if (d < bd) { bd = d; best = i; } });
    return bd <= 9 ? best : -1;
  }
  var BUTTONS = [];
  function button(id, x, y, w, h, label, enabled, hot) { BUTTONS.push({ id: id, x: x, y: y, w: w, h: h, enabled: enabled }); return { id: id, x: x, y: y, w: w, h: h, label: label, enabled: enabled, hot: hot }; }
  function hitButton(p) { for (var i = 0; i < BUTTONS.length; i++) { var b = BUTTONS[i]; if (p[0] >= b.x && p[1] >= b.y && p[0] < b.x + b.w && p[1] < b.y + b.h) return b; } return null; }

  function onDown(ev) {
    SND.unlock(); var p = toLogical(ev); S.mouse = p; S.down = true; cv.focus();
    if (ev.button === 2) { if (S.screen === 'case' && S.C && !S.C.solved) { S.C.strings[S.C.sel] = { bends: [], len: 0 }; SND.cue('sfx_unwind', 0.5); } return; }
    var b = hitButton(p);
    if (b) { press(b.id, b.enabled); return; }
    if (S.screen === 'case') {
      var C = S.C; if (C.solved || C.cold || !inHall(p)) return;
      var hitB = boltAt(p);
      if (hitB >= 0) { if (hitB !== C.sel) SND.cue('sfx_select', 0.5); C.sel = hitB; }
      S.msgs = []; // review #10: a status line that contradicts the board is worse than none
      C.dragging = true; pullTo(C.sel, toPaces(p));
      return;
    }
    // review #3/#8: screens with their own buttons (pause, rules, casebook) never "advance" on a stray click
    if (S.screen === 'pause' || S.screen === 'help' || S.screen === 'book') return;
    advance();
  }
  function onMove(ev) {
    var p = toLogical(ev); S.mouse = p;
    if (S.screen === 'case' && S.C && S.C.dragging) pullTo(S.C.sel, toPaces(p));
  }
  function onUp() {
    S.down = false;
    if (S.screen === 'case' && S.C && S.C.dragging) { S.C.dragging = false; var s = S.C.strings[S.C.sel]; if (s.len > 0) SND.twang(s.len); }
  }
  function press(id, enabled) {
    if (!enabled) { if (id === 'hearing' && S.C) { var why = hearingBlocked(); S.msg(why || 'NOT NOW.'); S.lastRefusal = why; } return; }
    SND.cue('sfx_ui', 0.5);
    var pm = /^p([0-4])$/.exec(id), cm = /^case:(\d+)$/.exec(id);
    if (id === 'hearing') callHearing();
    else if (id === 'rules') { S.ret = S.screen; S.screen = 'help'; S.page = 0; }
    // review #14: TAKE DOWN does what R does - the SELECTED string only
    else if (id === 'reset') { if (S.C.cold) reopen(); else { S.C.strings[S.C.sel] = { bends: [], len: 0 }; S.msg('STRING ' + (S.C.sel + 1) + ' IS TAKEN DOWN.'); } }
    else if (id === 'mute') { SND.toggleMute(); }
    else if (id === 'menu') { S.screen = 'pause'; S.pauseSel = 0; }
    else if (pm) { S.pauseSel = +pm[1]; pauseChoose(+pm[1]); }
    else if (id === 'help-prev') S.page = Math.max(0, S.page - 1);
    else if (id === 'help-next') S.page = Math.min(helpPages().length - 1, S.page + 1);
    else if (id === 'help-back') S.screen = S.ret || 'book';
    else if (cm) { S.book = +cm[1] - 1; advance(); }
    else if (id === 'book-title') S.screen = 'title';
    else if (id === 'book-rules') { S.ret = 'book'; S.screen = 'help'; S.page = 0; }
    else if (id === 'book-credits') S.screen = 'credits';
  }
  var KEYMAP = { ArrowUp: 'up', KeyW: 'up', ArrowDown: 'down', KeyS: 'down', ArrowLeft: 'left', KeyA: 'left', ArrowRight: 'right', KeyD: 'right' };
  function onKey(ev) {
    SND.unlock();
    var k = ev.code;
    if (KEYMAP[k] || k === 'Space' || k === 'Enter' || k === 'Tab' || k === 'Backspace') ev.preventDefault();
    if (ev.repeat && !KEYMAP[k]) return;
    if (KEYMAP[k]) S.keys[KEYMAP[k]] = true;
    if (k === 'KeyM') { SND.toggleMute(); return; }
    if (S.screen === 'case') {
      var C = S.C;
      if (k === 'Escape') { S.screen = 'pause'; S.pauseSel = 0; return; }
      if (k === 'KeyH' || k === 'F1' || k === 'Slash') { S.ret = 'case'; S.screen = 'help'; S.page = 0; return; }
      if (C.solved) return;
      if (k === 'KeyR') { if (C.cold) reopen(); else { C.strings[C.sel] = { bends: [], len: 0 }; S.msg('STRING ' + (C.sel + 1) + ' IS TAKEN DOWN.'); } return; }
      if (k === 'Backspace') { C.strings[C.sel] = { bends: [], len: 0 }; return; }
      if (C.cold) { S.msg('THE CASE IS COLD. PRESS REOPEN (OR R) TO TRY AGAIN.'); S.lastRefusal = 'cold'; return; }
      if (k === 'Enter') { callHearing(); return; }
      if (k === 'Tab') { C.sel = (C.sel + (ev.shiftKey ? C.bolts.length - 1 : 1)) % C.bolts.length; SND.cue('sfx_select', 0.5); return; }
      var num = /^Digit([1-9])$/.exec(k); if (num && +num[1] <= C.bolts.length) { C.sel = +num[1] - 1; SND.cue('sfx_select', 0.5); return; }
      if (k === 'ArrowLeft' || k === 'KeyA') { if (!ev.repeat) rotate(C.sel, -1); return; }
      if (k === 'ArrowRight' || k === 'KeyD') { if (!ev.repeat) rotate(C.sel, 1); return; }
      return;
    }
    if (S.screen === 'pause') {
      if (k === 'Escape') { S.screen = 'case'; return; }
      if (k === 'ArrowUp' || k === 'KeyW') S.pauseSel = (S.pauseSel + 4) % 5;
      if (k === 'ArrowDown' || k === 'KeyS') S.pauseSel = (S.pauseSel + 1) % 5;
      if (k === 'Enter' || k === 'Space') pauseChoose(S.pauseSel);
      return;
    }
    if (S.screen === 'book') {
      if (k === 'ArrowUp' || k === 'KeyW' || k === 'ArrowLeft' || k === 'KeyA') S.book = Math.max(0, S.book - 1);
      else if (k === 'ArrowDown' || k === 'KeyS' || k === 'ArrowRight' || k === 'KeyD') S.book = Math.min(TOTAL - 1, S.book + 1);
      else if (k === 'Escape') S.screen = 'title';
      else if (k === 'KeyH') { S.ret = 'book'; S.screen = 'help'; S.page = 0; }
      else if (k === 'KeyC') S.screen = 'credits';
      else if (k === 'Enter' || k === 'Space') advance();
      return;
    }
    if (S.screen === 'help') { if (k === 'ArrowRight' || k === 'KeyD') S.page = Math.min(helpPages().length - 1, S.page + 1); else if (k === 'ArrowLeft' || k === 'KeyA') S.page = Math.max(0, S.page - 1); else advance(k === 'Escape'); return; }
    if (k === 'Escape' && (S.screen === 'intro' || S.screen === 'credits')) { S.screen = 'book'; return; }
    if (k === 'Enter' || k === 'Space' || k === 'Escape') advance(k === 'Escape');
  }
  function onKeyUp(ev) { var k = KEYMAP[ev.code]; if (k) S.keys[k] = false; }
  function pauseChoose(i) {
    SND.cue('sfx_ui', 0.5);
    if (i === 0) S.screen = 'case';
    else if (i === 1) { S.ret = 'case'; S.screen = 'help'; S.page = 0; }
    else if (i === 2) { S.screen = 'book'; S.book = S.C.n - 1; SND.setMood(0); }
    else if (i === 3) { SND.toggleMute(); }
    else if (i === 4) { S.screen = 'title'; SND.setMood(0); }
  }
  /* the generic "go on" for every card */
  function advance(back) {
    SND.cue('sfx_page', 0.45);
    if (S.screen === 'title') { S.screen = 'book'; S.book = firstOpen(); return; }
    if (S.screen === 'book') { var n = S.book + 1; if (n > CASES.length) { S.msg(FULL ? 'NOT YET.' : 'CASES 4 TO 15 ARE IN THE FULL GAME.'); S.lastRefusal = 'locked-demo'; return; } if (!unlocked(n)) { S.msg('SOLVE CASE ' + (n - 1) + ' FIRST.'); S.lastRefusal = 'locked'; return; } S.introN = n; S.page = 0; S.screen = 'intro'; return; }
    if (S.screen === 'intro') { var rec = CASES[S.introN - 1]; var pages = rec.rulePage ? 2 : 1; if (back) { S.screen = 'book'; return; } if (S.page + 1 < pages) { S.page++; return; } openCase(S.introN); return; }
    if (S.screen === 'verdict') { afterVerdict(); return; }
    if (S.screen === 'help') { S.screen = S.ret || 'book'; return; }
    if (S.screen === 'demoend') { S.screen = 'book'; S.book = CASES.length - 1; return; }
    if (S.screen === 'ending') { S.screen = 'credits'; return; }
    if (S.screen === 'credits') { S.screen = 'book'; return; }
  }
  function firstOpen() { for (var n = 1; n <= CASES.length; n++) if (!solvedSeal(n)) return n - 1; return 0; }

  // ---- drawing helpers -----------------------------------------------------------------------------
  /* every line of text is bounds-checked against the canvas: an overflow is RECORDED, and the playthrough fails on any */
  var OVERFLOW = {};
  function text(s, x, y, o) {
    o = o || {};
    var w = F.width(s, o.face), x0 = o.align === 'center' ? x - w / 2 : o.align === 'right' ? x - w : x;
    if (x0 < 0 || x0 + w > W || y < 0 || y + (o.face === 'display' ? 12 : 7) > H) OVERFLOW[S.screen + ':' + String(s).slice(0, 40)] = [Math.round(x0), Math.round(x0 + w), y];
    return F.text(g, s, x, y, o);
  }
  function wrap(s, maxChars) {
    var words = String(s).split(' '), lines = [], cur = '';
    words.forEach(function (w) { if ((cur + ' ' + w).trim().length > maxChars) { lines.push(cur.trim()); cur = w; } else cur = (cur + ' ' + w).trim(); });
    if (cur) lines.push(cur); return lines;
  }
  function box(x, y, w, h, fill, edge) { g.fillStyle = fill || COL.panel; g.fillRect(x, y, w, h); g.fillStyle = edge || COL.edge; g.fillRect(x, y, w, 1); g.fillRect(x, y + h - 1, w, 1); g.fillRect(x, y, 1, h); g.fillRect(x + w - 1, y, 1, h); }
  function drawButton(b) {
    var hover = S.mouse && S.mouse[0] >= b.x && S.mouse[1] >= b.y && S.mouse[0] < b.x + b.w && S.mouse[1] < b.y + b.h;
    box(b.x, b.y, b.w, b.h, !b.enabled ? '#1a1410' : b.hot ? (hover ? '#5a2a1a' : '#43200f') : (hover ? '#3a2b1d' : '#2c2117'), b.enabled ? (b.hot ? COL.gold : COL.edge) : '#3a3026');
    text(b.label, b.x + b.w / 2, b.y + Math.floor((b.h - 7) / 2), { align: 'center', colour: b.enabled ? (b.hot ? COL.gold : COL.ink) : COL.faint });
  }
  function candle(x, y, lit) {
    g.fillStyle = lit ? '#efe0c0' : '#6d6252'; g.fillRect(x, y + 5, 5, 9); g.fillStyle = lit ? '#cdb996' : '#554b3e'; g.fillRect(x + 4, y + 5, 1, 9);
    g.fillStyle = '#2a1a10'; g.fillRect(x + 2, y + 3, 1, 2);
    if (lit) { var f = Math.sin(S.t * 13 + x) > 0 ? 1 : 0; g.fillStyle = '#ffcf5a'; g.fillRect(x + 1 + f, y, 2, 3); g.fillStyle = '#fff4c8'; g.fillRect(x + 2, y + 1, 1, 1); }
    else { g.fillStyle = 'rgba(200,200,200,0.35)'; g.fillRect(x + 2 + Math.round(Math.sin(S.t * 2 + x)), y - 2, 1, 2); }
  }
  function sealIcon(x, y, kind) {
    var c = kind === 'clean' ? '#e0b24a' : kind === 'solved' ? '#b23a30' : kind === 'cold' ? '#6b6f78' : null;
    if (!c) { g.fillStyle = '#3a2e22'; g.fillRect(x + 2, y + 3, 5, 1); return; }
    g.fillStyle = c; g.fillRect(x + 1, y, 7, 9); g.fillRect(x, y + 1, 9, 7);
    g.fillStyle = 'rgba(0,0,0,0.3)'; g.fillRect(x + 3, y + 3, 3, 3);
  }
  function vignette(strength) {
    var grd = g.createRadialGradient(W / 2, H / 2, 60, W / 2, H / 2, 300);
    grd.addColorStop(0, 'rgba(0,0,0,0)'); grd.addColorStop(1, 'rgba(0,0,0,' + strength + ')');
    g.fillStyle = grd; g.fillRect(0, 0, W, H);
  }
  function glowAt(x, y, r, col, a) {
    var grd = g.createRadialGradient(x, y, 1, x, y, r);
    grd.addColorStop(0, col + a + ')'); grd.addColorStop(1, col + '0)');
    g.fillStyle = grd; g.fillRect(x - r, y - r, r * 2, r * 2);
  }

  // ---- the case screen -----------------------------------------------------------------------------
  function drawHall(C, opts) {
    opts = opts || {};
    g.drawImage(C.layer, R.HX, R.HY);
    R.drawAnimated(g, C.objects, S.t, C.torn);
    // warm light from fire and candles, cool from the chapel glass
    var look = R.LOOK[C.hall.id];
    g.globalCompositeOperation = 'lighter';
    C.objects.forEach(function (o) { if (o.art === 'brazier' || o.art === 'candelabrum') glowAt(R.px(o.x + 0.5), R.py(o.y + 0.5), o.art === 'brazier' ? 30 : 20, 'rgba(255,170,80,', 0.16 + 0.03 * Math.sin(S.t * 7 + o.x)); });
    g.globalCompositeOperation = 'source-over';
    var hover = opts.hoverRegion || null, meet = opts.meet || null;
    R.drawRegions(g, C.grid, C.hall.id, meet || hover, !!meet, S.t);
    var paths = C.strings.map(function (s, i) {
      if (s.len <= 0) return null;
      var sp = TR.stringPath(C.grid, C.bolts[i], s.bends, s.len);
      sp.bendsUsed = s.bends;
      R.drawString(g, sp, i === C.sel ? COL.thread : '#c23a36', s.bends.length, S.t, false);
      return sp;
    });
    C.bolts.forEach(function (b, i) { R.drawBolt(g, b, i + 1, i === C.sel && !opts.noSel, S.t, C.grid); });
    // review #5: the chalk angle numerals go LAST, so no bolt tag can cover the number the court judges
    paths.forEach(function (sp, i) { if (sp) R.drawStringChalk(g, sp, C.strings[i].bends.length); });
  }
  function drawCase() {
    BUTTONS.length = 0;
    var C = S.C;
    g.fillStyle = COL.bg; g.fillRect(0, 0, W, H);
    var mp = S.mouse && inHall(S.mouse) ? toPaces(S.mouse) : null;
    var hoverRegion = mp ? TR.regionAt(C.grid, Math.floor(mp[0]), Math.floor(mp[1])) : null;
    drawHall(C, { hoverRegion: hoverRegion, meet: meetRegion() });
    vignette(0.35);
    // frame around the hall
    g.fillStyle = COL.edge; g.fillRect(R.HX - 1, R.HY - 1, 24 * T + 2, 1); g.fillRect(R.HX - 1, R.HY + 14 * T, 24 * T + 2, 1); g.fillRect(R.HX - 1, R.HY - 1, 1, 14 * T + 2); g.fillRect(R.HX + 24 * T, R.HY - 1, 1, 14 * T + 2);
    // panel
    var X = 392;
    box(X, 3, 85, 226, COL.panel, COL.edge);
    text('CASE ' + C.n, X + 42, 7, { face: 'display', align: 'center', colour: COL.gold });
    text(C.hall.title.replace(/^THE /i, '').replace(/ OF SAINT ORM/i, ''), X + 42, 22, { align: 'center', colour: COL.dim });
    for (var c = 0; c < 3; c++) candle(X + 26 + c * 12, 33, c < C.candles);
    text(C.cold ? 'COLD' : C.solved ? 'SOLVED' : 'CANDLES', X + 42, 50, { align: 'center', colour: C.cold ? '#9aa0aa' : COL.faint });
    var y = 64;
    text('BOLTS', X + 5, y, { colour: COL.faint }); y += 10;
    C.bolts.forEach(function (b, i) {
      var s = C.strings[i], sel = i === C.sel, er = endRegion(i);
      if (sel) { g.fillStyle = '#3b2a1b'; g.fillRect(X + 2, y - 2, 81, 20); }
      text((i + 1) + ' ' + (b.band === 'buried' ? 'BURIED' : b.band === 'sunk' ? 'HALF SUNK' : 'BARELY IN'), X + 5, y, { colour: sel ? COL.gold : COL.ink });
      // review #15: "1B" was never explained - spell it out (the line holds 13 characters at most)
      var st = s.len > 0 ? (s.bends.length ? s.bends.length + (s.bends.length === 1 ? ' BEND ' : ' BENDS ') : 'STRAIGHT ') + s.len.toFixed(1) : 'NO STRING';
      text(st, X + 5, y + 9, { colour: er ? COL.ok : COL.dim });
      y += 22;
    });
    var blocked = hearingBlocked();
    drawButton(button('hearing', X + 3, 172, 79, 13, 'HEARING', !blocked && !C.solved && !C.cold, true));
    drawButton(button('rules', X + 3, 188, 79, 12, 'RULES', true));
    drawButton(button('reset', X + 3, 202, 79, 12, C.cold ? 'REOPEN' : 'TAKE DOWN', !C.solved));
    drawButton(button('menu', X + 3, 216, 55, 11, 'MENU', true));
    drawButton(button('mute', X + 60, 216, 22, 11, SND.muted ? 'OFF' : 'ON', true));
    // bottom bar
    box(3, 231, 474, 36, '#1a130e', COL.edge);
    var l1 = '';
    if (mp) {
      var d = R.describeTile(C.grid, C.objects, Math.floor(mp[0]), Math.floor(mp[1]));
      l1 = d ? d : hoverRegion ? regionName(hoverRegion) : 'OPEN FLOOR';
      var nb = boltAt(S.mouse); if (nb >= 0) l1 = 'BOLT ' + (nb + 1) + ': ' + BAND_TXT[C.bolts[nb].band][0] + ' (' + BAND_TXT[C.bolts[nb].band][1] + ' TO ' + BAND_TXT[C.bolts[nb].band][2] + ' PACES)';
    }
    text(l1, 8, 235, { colour: COL.ink });
    var cs = C.strings[C.sel], er2 = endRegion(C.sel);
    var l2 = 'STRING ' + (C.sel + 1) + ': ' + (cs.len > 0 ? cs.len.toFixed(1) + ' PACES, ' + cs.bends.length + ' BEND' + (cs.bends.length === 1 ? '' : 'S') + ', ENDS ' + (er2 ? 'IN ' + regionName(er2) : 'IN THE OPEN') : 'DRAG FROM THE BOLT TO PULL IT');
    text(l2, 8, 245, { colour: COL.dim });
    // review #10: a message lives 6 s, then it is gone (it used to linger, contradicting the board)
    if (S.msgs[0] && S.t - S.msgT < 6) text(S.msgs[0], 8, 256, { colour: S.t - S.msgT < 3 ? COL.gold : COL.dim });
    else text('GOAL: EVERY STRING ENDS IN ONE CHALKED PLACE. THEN CALL THE HEARING.', 8, 256, { colour: COL.faint });
  }

  // ---- other screens --------------------------------------------------------------------------------
  /* display lettering at an integer scale (nearest neighbour), cached per string */
  var BIG = {};
  function bigText(s, cx, y, scale, colour, outline) {
    var key = s + '|' + colour + '|' + outline;
    if (!BIG[key]) {
      var c = document.createElement('canvas'); c.width = F.width(s, 'display') + 2; c.height = 14;
      var cg = c.getContext('2d'); F.text(cg, s, 1, 1, { face: 'display', colour: colour, outline: outline }); BIG[key] = c;
    }
    var im = BIG[key], w = im.width * scale;
    if (cx - w / 2 < 0 || cx + w / 2 > W) OVERFLOW['big:' + s] = [Math.round(cx - w / 2), Math.round(cx + w / 2), y];
    g.drawImage(im, Math.round(cx - w / 2), y, w, im.height * scale);
  }
  function drawTitle() {
    BUTTONS.length = 0;
    g.fillStyle = COL.bg; g.fillRect(0, 0, W, H);
    var ex = root.SL_EXHIBIT;
    // review #16: the 384-wide hall is CENTRED (it used to stop at x=388, leaving the right fifth black)
    if (ex && S.exhibit) { g.save(); g.translate(Math.round((W - 24 * T) / 2) - R.HX, Math.round((H - 14 * T) / 2) - R.HY); drawHall(S.exhibit, { meet: ex.region, noSel: true }); g.restore(); }
    g.fillStyle = 'rgba(10,6,4,0.30)'; g.fillRect(0, 0, W, H);
    vignette(0.55);
    g.fillStyle = 'rgba(12,7,4,0.78)'; g.fillRect(0, 50, W, 70);
    g.fillStyle = COL.edge; g.fillRect(0, 50, W, 1); g.fillRect(0, 119, W, 1);
    bigText('STRINGLINE', W / 2, 56, 3, COL.gold, '#2a1206');
    g.fillStyle = COL.thread; g.fillRect(W / 2 - 138, 99, 276, 1); g.fillStyle = '#5a0e0e'; g.fillRect(W / 2 - 137, 100, 276, 1);
    text('A CASTLE WHODUNIT WHERE EVERY CLUE IS A LINE YOU DRAW', W / 2, 106, { align: 'center', colour: COL.ink, outline: '#1a0c06' });
    if (Math.floor(S.t * 2) % 2 === 0) text('CLICK OR PRESS ENTER', W / 2, 190, { align: 'center', colour: COL.gold, outline: '#1a0c06' });
    g.fillStyle = 'rgba(12,7,4,0.78)'; g.fillRect(0, 208, W, 30);
    text('MOUSE: DRAG STRINGS / KEYS: 1-3 BOLT, W/S PULL, A/D BEND, ENTER HEARING', W / 2, 212, { align: 'center', colour: COL.ink, outline: '#1a0c06' });
    text((FULL ? 'THE FULL CASEBOOK' : 'FREE DEMO: THE FIRST 3 OF 15 CASES') + '  /  M: SOUND ' + (SND.muted ? 'OFF' : 'ON'), W / 2, 225, { align: 'center', colour: COL.gold, outline: '#1a0c06' });
    text('CORE SYSTEMS ASSET FACTORY', W / 2, 252, { align: 'center', colour: COL.dim, outline: '#1a0c06' });
  }
  function drawBook() {
    BUTTONS.length = 0;
    g.fillStyle = COL.bg; g.fillRect(0, 0, W, H);
    box(10, 8, 460, 254, '#241a12', COL.edge);
    text('THE HARROWGATE CASEBOOK', W / 2, 16, { face: 'display', align: 'center', colour: COL.gold });
    var halls = [['I. THE GREAT HALL', 1, 5], ['II. THE CHAPEL', 6, 10], ['III. THE GATEHOUSE', 11, 15]];
    halls.forEach(function (h, col) {
      var x = 22 + col * 150;
      text(h[0], x, 40, { colour: COL.dim });
      for (var n = h[1]; n <= h[2]; n++) {
        var y = 56 + (n - h[1]) * 30, sel = S.book === n - 1, have = n <= CASES.length, open = have && unlocked(n);
        var hov = S.mouse && S.mouse[0] >= x - 4 && S.mouse[0] < x + 140 && S.mouse[1] >= y - 4 && S.mouse[1] < y + 22;
        if (sel || hov) { g.fillStyle = sel ? '#3b2a1b' : '#2e2217'; g.fillRect(x - 4, y - 4, 144, 26); if (sel) { g.fillStyle = COL.gold; g.fillRect(x - 4, y - 4, 2, 26); } }
        BUTTONS.push({ id: 'case:' + n, x: x - 4, y: y - 4, w: 144, h: 26, enabled: true }); // review #8: pick a case by mouse or touch
        var rec = CASES[n - 1];
        sealIcon(x, y, sealOf(n));
        text(n + '. ' + (have ? rec.title : 'IN THE FULL GAME'), x + 14, y, { colour: !have ? COL.faint : open ? (sel ? COL.gold : COL.ink) : COL.faint });
        text(!have ? '' : !open ? 'SOLVE CASE ' + (n - 1) + ' FIRST' : sealOf(n) === 'clean' ? 'CLEAN SEAL' : sealOf(n) === 'solved' ? 'SEALED' : sealOf(n) === 'cold' ? 'COLD' : rec.bolts.length + ' BOLTS', x + 14, y + 10, { colour: COL.faint });
      }
    });
    var cleanCount = Object.keys(save.seals).filter(function (k) { return save.seals[k] === 'clean'; }).length;
    text('CLEAN SEALS ' + cleanCount + ' OF ' + TOTAL + '  /  CLICK A CASE OR USE ARROWS + ENTER', 22, 216, { colour: COL.dim });
    drawButton(button('book-rules', 22, 238, 90, 13, 'RULES', true));
    drawButton(button('book-credits', 118, 238, 90, 13, 'CREDITS', true));
    drawButton(button('book-title', 214, 238, 90, 13, 'TITLE', true));
    drawButton(button('mute', 310, 238, 60, 13, SND.muted ? 'SOUND OFF' : 'SOUND ON', true));
    // review #11: a refusal on this screen is DRAWN, never silent
    if (S.msgs[0] && S.t - S.msgT < 4) text(S.msgs[0], 22, 226, { colour: COL.gold });
  }
  function drawIntro() {
    BUTTONS.length = 0;
    var rec = CASES[S.introN - 1];
    g.fillStyle = COL.bg; g.fillRect(0, 0, W, H);
    box(40, 24, 400, 222, '#241a12', COL.edge);
    if (rec.rulePage && S.page === 0) {
      text('A NEW RULE', W / 2, 34, { align: 'center', colour: COL.faint });
      text(rec.rulePage.title, W / 2, 46, { face: 'display', align: 'center', colour: COL.gold });
      rulePicture(rec.rulePage.id, W / 2, 104);
      var yy = 150; rec.rulePage.lines.forEach(function (l) { wrap(l, 60).forEach(function (w) { text(w, W / 2, yy, { align: 'center', colour: COL.ink }); yy += 10; }); yy += 3; });
      text('ENTER: THE CASE', W / 2, 232, { align: 'center', colour: COL.gold });
      return;
    }
    text('CASE ' + rec.n + ' / ' + hallOf(rec.hall).title.toUpperCase(), W / 2, 30, { align: 'center', colour: COL.faint });
    text(rec.title, W / 2, 42, { face: 'display', align: 'center', colour: COL.gold });
    var y = 62; rec.story.forEach(function (l) { wrap(l, 62).forEach(function (w) { text(w, W / 2, y, { align: 'center', colour: COL.ink }); y += 10; }); y += 3; });
    // review #22: the card was ~40% empty - show the room itself, the case's own composed hall at half scale
    if (!S.introLayer || S.introLayer.n !== rec.n) {
      var hall = hallOf(rec.hall), base = TR.makeGrid(hall), cells = [];
      rec.furniture.forEach(function (o) { for (var i = 0; i < o.w; i++) cells.push({ x: o.x + i, y: o.y, ch: o.ch }); });
      S.introLayer = { n: rec.n, cv: R.composeHall(hall, TR.withFurniture(base, cells), rec.furniture) };
    }
    var tx = W / 2 - 96, ty = 111;
    g.fillStyle = COL.edge; g.fillRect(tx - 2, ty - 2, 196, 116);
    g.imageSmoothingEnabled = true; g.drawImage(S.introLayer.cv, tx, ty, 192, 112); g.imageSmoothingEnabled = false;
    text(rec.bolts.length + ' BOLTS. THREE CANDLES. FIND WHERE THE ARCHER STOOD.', W / 2, 227, { align: 'center', colour: COL.dim });
    text('ENTER OR CLICK: BEGIN  /  ESC: BACK', W / 2, 237, { align: 'center', colour: COL.gold });
  }
  /* small diagrams for the rule pages, drawn with the same pixels the hall uses */
  function rulePicture(id, cx, cy) {
    var wall = '#9c9384', thread = COL.thread;
    function lineC(x0, y0, x1, y1, c) { R.line(g, x0, y0, x1, y1, c); }
    g.fillStyle = '#1a130e'; g.fillRect(cx - 120, cy - 36, 240, 70);
    /* ⛔ review #1/#6: every leg is drawn on the game's own lattice (angle 1 = run 2 : rise 1, 2 = 1:1, 3 = 1:2) and
     * labelled with the SAME chalk numeral the board draws, so the picture cannot teach a different rule */
    function num(v, x, y) { R.chalkNum(g, v, x, y); }
    if (id === 'R1') {
      var fy = cy + 18;
      g.fillStyle = wall; g.fillRect(cx - 112, fy, 104, 6); g.fillRect(cx + 8, fy, 104, 6);
      lineC(cx - 100, fy - 20, cx - 60, fy, thread); lineC(cx - 60, fy, cx - 20, fy - 20, thread);   // in at 1, out at 1: a mirror
      num(1, cx - 107, fy - 20); num(1, cx - 13, fy - 20);
      text('ANGLE 1: IT SKIPS', cx - 60, cy - 32, { align: 'center', colour: COL.ok });
      lineC(cx + 49, fy - 22, cx + 60, fy, thread); g.fillStyle = COL.gold; g.fillRect(cx + 59, fy - 2, 3, 3);   // in at 3: it sticks
      num(3, cx + 42, fy - 22);
      text('ANGLE 3: IT STICKS', cx + 60, cy - 32, { align: 'center', colour: COL.red });
    } else if (id === 'R6') {
      [['BURIED', 3, '0-7'], ['HALF SUNK', 7, '7-14'], ['BARELY IN', 11, '14-21']].forEach(function (b, i) {
        var x = cx - 80 + i * 80; g.fillStyle = wall; g.fillRect(x - 3, cy - 10, 6, 30);
        lineC(x - 3, cy + 4, x - 3 - b[1], cy + 4, '#a9794a'); lineC(x - 3 - b[1], cy + 4, x - 6 - b[1], cy + 1, '#e9dfc6'); lineC(x - 3 - b[1], cy + 4, x - 6 - b[1], cy + 7, '#e9dfc6');
        text(b[0], x, cy - 26, { align: 'center', colour: COL.ink }); text(b[2] + ' PACES', x, cy + 24, { align: 'center', colour: COL.dim });
      });
    } else if (id === 'R2') {
      var iy = cy + 16, px0 = cx - 10;
      g.fillStyle = '#6f7682'; g.fillRect(cx - 40, iy, 80, 6); g.fillStyle = '#9aa2ae'; g.fillRect(cx - 40, iy, 80, 1);
      lineC(px0 - 22, iy - 44, px0, iy, thread); lineC(px0, iy, px0 + 40, iy - 40, thread);   // in at 3 (1:2), out at 2 (1:1)
      num(3, px0 - 29, iy - 44); num(2, px0 + 47, iy - 40);
      text('IN AT 3', px0 - 56, cy - 34, { align: 'center', colour: COL.ink });
      text('OUT AT 2', px0 + 62, cy - 34, { align: 'center', colour: COL.ok });
    } else if (id === 'R4') {
      g.fillStyle = '#9b2a2a'; g.fillRect(cx - 4, cy - 26, 8, 40); g.fillStyle = '#e0b458'; g.fillRect(cx - 2, cy - 18, 4, 4);
      lineC(cx - 100, cy - 10, cx + 100, cy + 10, thread);
      text('STRAIGHT THROUGH', cx, cy + 22, { align: 'center', colour: COL.ok });
    }
  }
  function helpPages() {
    var known = [];
    var maxN = 0; Object.keys(save.seals).forEach(function (k) { maxN = Math.max(maxN, +k); });
    if (S.C) maxN = Math.max(maxN, S.C.n);
    CASES.forEach(function (c) { if (c.rulePage && c.n <= Math.max(1, maxN)) known.push(c.rulePage); });
    var pages = [{ id: 'basics' }].concat(known);
    return pages;
  }
  function drawHelp() {
    BUTTONS.length = 0;
    g.fillStyle = COL.bg; g.fillRect(0, 0, W, H);
    box(30, 14, 420, 242, '#241a12', COL.edge);
    var pages = helpPages(), pg = pages[Math.min(S.page, pages.length - 1)];
    text('RULES OF THE STRING  ' + (S.page + 1) + ' / ' + pages.length, W / 2, 22, { align: 'center', colour: COL.faint });
    if (pg.id === 'basics') {
      text('HOW TO PLAY', W / 2, 36, { face: 'display', align: 'center', colour: COL.gold });
      var lines = [
        'EVERY BOLT STOPPED WHERE YOU SEE IT. ITS SHAFT POINTS BACK ALONG THE LAST STRETCH IT FLEW.',
        'DRAG FROM A BOLT TO PULL ITS STRING BACK. PULL PAST A WALL, PILLAR OR IRON TO BEND THE STRING THERE; SWING THE MOUSE TO CHOOSE THE BEND. PULL STRAIGHT BACK DOWN THE STRING TO UNDO IT.',
        'THE CHALK NUMBER AT A BEND IS THE ANGLE: 1 LOW, 2 DIAGONAL, 3 STEEP, 4 SQUARE ON. A DARK KNOT MARKS EVERY PACE, A PALE BEAD EVERY FIFTH.',
        'THE ARCHER STOOD SOMEWHERE IN ONE CHALKED PLACE. WHEN EVERY STRING ENDS IN THE SAME ONE, CALL THE HEARING.',
        'THE COURT CHECKS YOUR STRINGS AGAINST THE RULES. A BROKEN RULE COSTS A CANDLE. LOSE ALL THREE AND THE CASE GOES COLD.',
        'A BOLT FLIES AT MOST 21 PACES AND GLANCES AT MOST THREE TIMES. WOOD HOLDS EVERY BOLT.',
        'KEYS: 1-3 OR TAB PICK A BOLT / W/S PULL / A/D SWING A BEND / R TAKE DOWN / ENTER HEARING / ESC MENU'
      ];
      var y = 58; lines.forEach(function (l) { wrap(l, 66).forEach(function (w) { text(w, 42, y, { colour: COL.ink }); y += 10; }); y += 4; });
    } else {
      text(pg.title, W / 2, 36, { face: 'display', align: 'center', colour: COL.gold });
      rulePicture(pg.id, W / 2, 100);
      var yy = 146; pg.lines.forEach(function (l) { wrap(l, 62).forEach(function (w) { text(w, W / 2, yy, { align: 'center', colour: COL.ink }); yy += 10; }); yy += 3; });
    }
    // review #8: page and leave by mouse or touch, not only by keys
    drawButton(button('help-prev', 40, 238, 70, 13, 'PREV', S.page > 0));
    drawButton(button('help-back', 205, 238, 70, 13, 'BACK', true, true));
    drawButton(button('help-next', 370, 238, 70, 13, 'NEXT', S.page < pages.length - 1));
    text('A/D OR ARROWS', W / 2, 228, { align: 'center', colour: COL.faint });
  }
  function drawVerdict() {
    drawCase(); BUTTONS.length = 0;
    var v = S.verdict, C = S.C;
    g.fillStyle = 'rgba(8,5,3,0.72)'; g.fillRect(0, 0, W, H);
    box(60, 60, 360, 150, '#241a12', v.ok ? COL.gold : COL.red);
    if (v.ok) {
      text('THE COURT IS SATISFIED', W / 2, 72, { face: 'display', align: 'center', colour: COL.gold });
      text('THE ARCHER STOOD IN ' + v.name + '.', W / 2, 98, { align: 'center', colour: COL.ink });
      var y = 112; wrap(v.who, 56).forEach(function (w) { text(w, W / 2, y, { align: 'center', colour: COL.dim }); y += 10; });
      var k = Math.min(1, (S.t - v.t) / 0.6);
      var sx = W / 2 - 9, sy = 150 - Math.round((1 - k) * 30);
      g.globalAlpha = k; g.fillStyle = v.seal === 'clean' ? '#e0b24a' : '#b23a30'; g.fillRect(sx, sy, 18, 18); g.fillRect(sx - 2, sy + 2, 22, 14); g.fillRect(sx + 2, sy - 2, 14, 22);
      g.fillStyle = 'rgba(0,0,0,0.3)'; g.fillRect(sx + 5, sy + 5, 8, 8); g.globalAlpha = 1;
      text(v.seal === 'clean' ? 'A CLEAN SEAL: NOT ONE CANDLE BURNED' : 'SEALED, WITH ' + (3 - C.candles) + ' CANDLE' + (3 - C.candles === 1 ? '' : 'S') + ' BURNED', W / 2, 178, { align: 'center', colour: COL.ink });
    } else {
      text('THE COURT IS NOT CONVINCED', W / 2, 72, { face: 'display', align: 'center', colour: COL.red });
      var y2 = 100; wrap(v.text, 56).forEach(function (w) { text(w, W / 2, y2, { align: 'center', colour: COL.ink }); y2 += 11; });
      for (var c = 0; c < 3; c++) candle(W / 2 - 17 + c * 12, 150, c < C.candles);
      text(C.cold ? 'THE LAST CANDLE IS OUT. THE CASE GOES COLD.' : 'A CANDLE BURNS DOWN. ' + C.candles + ' LEFT.', W / 2, 172, { align: 'center', colour: COL.dim });
    }
    text('ENTER OR CLICK', W / 2, 196, { align: 'center', colour: COL.gold });
  }
  function drawPause() {
    drawCase(); BUTTONS.length = 0;
    g.fillStyle = 'rgba(8,5,3,0.7)'; g.fillRect(0, 0, W, H);
    box(170, 70, 140, 120, '#241a12', COL.edge);
    text('PAUSED', W / 2, 80, { face: 'display', align: 'center', colour: COL.gold });
    ['RESUME', 'RULES', 'CASEBOOK', 'SOUND: ' + (SND.muted ? 'OFF' : 'ON'), 'TITLE'].forEach(function (l, i) {
      var b = button('p' + i, 180, 102 + i * 16, 120, 13, l, true, i === S.pauseSel); drawButton(b);
    });
    text('CLICK, OR ARROWS + ENTER. ESC RESUMES.', W / 2, 196, { align: 'center', colour: COL.dim });
  }
  function drawCard(title, lines, foot) {
    BUTTONS.length = 0;
    g.fillStyle = COL.bg; g.fillRect(0, 0, W, H);
    box(30, 20, 420, 230, '#241a12', COL.edge);
    text(title, W / 2, 32, { face: 'display', align: 'center', colour: COL.gold });
    var y = 60; lines.forEach(function (l) { if (!l) { y += 6; return; } wrap(l, 64).forEach(function (w) { text(w, W / 2, y, { align: 'center', colour: COL.ink }); y += 10; }); y += 3; });
    text(foot, W / 2, 236, { align: 'center', colour: COL.gold });
  }
  function drawDemoEnd() {
    drawCard('THE CASEBOOK GOES ON', [
      'YOU HAVE SOLVED THE FIRST THREE CASES OF HARROWGATE.',
      '',
      'THE FULL GAME HAS 15 CASES: TWO MORE IN THE GREAT HALL, THEN THE CHAPEL OF SAINT ORM AND THE GATEHOUSE, WITH TWO NEW RULES TO LEARN (IRON AND CLOTH), AND THE ENDING.',
      '',
      'IT IS A DOWNLOAD FOR WINDOWS ON THIS PAGE. THANK YOU FOR PLAYING THE DEMO.'
    ], 'ENTER: BACK TO THE CASEBOOK');
  }
  function drawEnding() {
    var clean = 0; for (var n = 1; n <= TOTAL; n++) if (sealOf(n) === 'clean') clean++;
    drawCard('THE CASEBOOK CLOSES', (root.SL_ENDING || []).concat(['', 'CLEAN SEALS: ' + clean + ' OF ' + TOTAL + '.']), 'ENTER: CREDITS');
  }
  function drawCredits() {
    drawCard('STRINGLINE', [
      'A GAME BY CORE SYSTEMS ASSET FACTORY.',
      '',
      'ART: CSAF TILESETS VERDANT 07 INTERIORS, VERDANT 13 CASTLE AND VERDANT 15 PALACE, COMPOSED BY THE GAME.',
      'MUSIC AND SOUND: SYNTHESISED BY CSAF FROM NOTE DATA. NO SAMPLES.',
      'LETTERING: CSAF.',
      '',
      'MADE WITH AI: THE CODE, THE ART AND THE TEXT WERE MADE WITH AI TOOLS. THE SOUND IS PROCEDURAL.',
      '',
      'THANK YOU FOR PULLING THE STRINGS.'
    ], 'ENTER: CASEBOOK');
  }

  // ---- the clock ------------------------------------------------------------------------------------
  function tick(dt) {
    S.t += dt; S.frames++;
    if (S.screen === 'case' && S.C && !S.C.solved && !S.C.cold && !S.C.dragging) {
      var sp = 5 * dt;
      if (S.keys.up) extend(S.C.sel, sp);
      if (S.keys.down) extend(S.C.sel, -sp);
    }
  }
  function draw() {
    if (R.state.failed) { g.fillStyle = '#200a0a'; g.fillRect(0, 0, W, H); text('THE ART FAILED TO LOAD: ' + R.state.failed.toUpperCase(), W / 2, H / 2, { align: 'center', colour: '#ffb4a8' }); return; }
    if (!R.state.ready) { g.fillStyle = COL.bg; g.fillRect(0, 0, W, H); text('LOADING', W / 2, H / 2, { align: 'center', colour: COL.dim }); return; }
    if (root.SL_EXHIBIT && !S.exhibit) S.exhibit = buildExhibit(root.SL_EXHIBIT);
    if (S.screen === 'title') drawTitle();
    else if (S.screen === 'book') drawBook();
    else if (S.screen === 'intro') drawIntro();
    else if (S.screen === 'case') drawCase();
    else if (S.screen === 'verdict') drawVerdict();
    else if (S.screen === 'pause') drawPause();
    else if (S.screen === 'help') drawHelp();
    else if (S.screen === 'demoend') drawDemoEnd();
    else if (S.screen === 'ending') drawEnding();
    else if (S.screen === 'credits') drawCredits();
  }
  function buildExhibit(ex) {
    var hall = hallOf(ex.hall), base = TR.makeGrid(hall), cells = [];
    ex.furniture.forEach(function (o) { for (var i = 0; i < o.w; i++) cells.push({ x: o.x + i, y: o.y, ch: o.ch }); });
    var grid = TR.withFurniture(base, cells);
    return { n: 0, hall: hall, grid: grid, objects: ex.furniture, bolts: ex.bolts, strings: ex.strings.map(function (s) { return { bends: s.bends, len: s.len }; }), sel: -1, layer: R.composeHall(hall, grid, ex.furniture) };
  }
  var last = null;
  function frame(ts) {
    if (last === null) last = ts;
    var dt = Math.min(0.05, (ts - last) / 1000); last = ts;
    tick(dt); draw();
    root.requestAnimationFrame(frame);
  }
  function fit() {
    var s = Math.min(root.innerWidth / W, root.innerHeight / H);
    if (s >= 2) s = Math.floor(s);
    cv.style.width = Math.floor(W * s) + 'px'; cv.style.height = Math.floor(H * s) + 'px';
  }
  root.addEventListener('resize', fit); fit();
  cv.addEventListener('mousedown', onDown);
  root.addEventListener('mousemove', onMove);
  root.addEventListener('mouseup', onUp);
  cv.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  cv.addEventListener('touchstart', function (e) { e.preventDefault(); var t0 = e.changedTouches[0]; onDown({ clientX: t0.clientX, clientY: t0.clientY, button: 0 }); }, { passive: false });
  cv.addEventListener('touchmove', function (e) { e.preventDefault(); var t0 = e.changedTouches[0]; onMove({ clientX: t0.clientX, clientY: t0.clientY }); }, { passive: false });
  cv.addEventListener('touchend', function (e) { e.preventDefault(); onUp(); }, { passive: false });
  root.addEventListener('keydown', onKey);
  root.addEventListener('keyup', onKeyUp);
  root.addEventListener('blur', function () { S.keys = {}; if (S.C) S.C.dragging = false; });
  SND.load();
  // ?harness=1: the harness owns the clock (a background tab gets no rAF at all, §6b-18); a player never sees it
  var HARNESS = /[?&]harness=1/.test(location.search);
  if (!HARNESS) root.requestAnimationFrame(frame);

  // ---- the harness hook: the SHIPPED page, driven, never a copy of it --------------------------------
  root.__slTick = function (n, dt) { for (var i = 0; i < (n || 1); i++) { tick(dt || 1 / 60); } draw(); return S.frames; };
  root.SL_GAME = {
    S: S, save: function () { return JSON.parse(JSON.stringify(save)); }, openCase: openCase, callHearing: callHearing, pullTo: pullTo, extend: extend, rotate: rotate,
    endRegion: endRegion, meetRegion: meetRegion, hearingBlocked: hearingBlocked, stringNow: stringNow, tailInfo: tailInfo, buttons: function () { return BUTTONS.slice(); },
    cases: function () { return CASES.length; }, total: TOTAL, full: FULL, fontMissing: F.missing, renderMissing: R.state.missing, overflow: OVERFLOW,
    snapshot: function () { var C = S.C; return { screen: S.screen, caseN: C ? C.n : null, candles: C ? C.candles : null, solved: C ? C.solved : null, cold: C ? C.cold : null, sel: C ? C.sel : null,
      strings: C ? C.strings.map(function (s) { return { bends: s.bends.slice(), len: +s.len.toFixed(3) }; }) : null, verdict: S.verdict, msgs: S.msgs.slice(), lastRefusal: S.lastRefusal, seals: JSON.parse(JSON.stringify(save.seals)), sound: SND.report() }; }
  };
})(window);
