/* render.js - STRINGLINE's pictures. The halls are COMPOSED at load from CSAF's own tilesets (art/harrowgate.png,
 * indexed by art/atlas.js): a floor fill, the wall as a 47-mask autotile set laid on it, the hall's fixed furniture and
 * the case's own furniture, all by tile id. Then, every frame, on top: chalk (the regions, the protractors), the bolts
 * with their depth tells, the red strings with knots and pins, and the light.
 * Drawing is in LOGICAL pixels (480x270); the page scales the canvas by an integer. */
(function (root) {
  'use strict';
  var TR = root.SL_TRACE, A = root.SL_ATLAS;
  var T = 16, HX = 4, HY = 4;
  var N = 1, NE = 2, E = 4, SE = 8, S = 16, SW = 32, W = 64, NW = 128;
  var LOOK = {
    great: { floor: 'plank', walls: 'mason_on_plank', chalk: '#f3ead2', light: 'rgba(255,196,120,', dark: 'rgba(12,8,6,' },
    chapel: { floor: 'flag', walls: 'plaster_on_flag', chalk: '#e8eef8', light: 'rgba(200,210,255,', dark: 'rgba(6,8,16,' },
    gate: { floor: 'bailey', walls: 'curtain_on_bailey', chalk: '#f0ecd8', light: 'rgba(255,210,150,', dark: 'rgba(8,8,8,' }
  };
  var PROP_ART = { table_long: 'table_long', bench: 'bench', long_table: 'long_table', chest: 'chest', anvil: 'anvil', candelabrum: 'candelabrum', brazier: 'brazier', banner: 'banner' };
  var MATNAME = { stone: 'STONE', iron: 'IRON', wood: 'WOOD', cloth: 'CLOTH' };
  var THING = { table_long: 'TABLE', bench: 'BENCH', long_table: 'HIGH TABLE', chest: 'CHEST', anvil: 'ANVIL', candelabrum: 'CANDELABRUM', brazier: 'BRAZIER', banner: 'BANNER', pew: 'PEW', altar: 'ALTAR', weapon_rack: 'WEAPON RACK' };

  var img = new Image();
  var state = { ready: false, failed: null, missing: {} };
  img.onload = function () { state.ready = true; };
  img.onerror = function () { state.failed = 'art/harrowgate.png did not load'; };
  img.src = A.sheet;

  function ih(a, b, c) {
    var h = Math.imul(a | 0, 374761393) ^ Math.imul(b | 0, 668265263) ^ Math.imul(c | 0, 2246822519);
    h = Math.imul(h ^ (h >>> 15), 2246822507); h = Math.imul(h ^ (h >>> 13), 3266489909); h ^= h >>> 16;
    return (h >>> 0) / 4294967296;
  }
  function blit(g, id, x, y) {
    var t = A.tiles[id];
    if (!t) { state.missing[id] = (state.missing[id] || 0) + 1; return false; }
    var r = t.r; g.drawImage(img, r[0], r[1], r[2], r[3], Math.round(x), Math.round(y), r[2], r[3]); return true;
  }
  function normalise(m) {
    var r = m;
    if (!((m & N) && (m & E))) r &= ~NE; if (!((m & E) && (m & S))) r &= ~SE;
    if (!((m & S) && (m & W))) r &= ~SW; if (!((m & W) && (m & N))) r &= ~NW;
    return r & 255;
  }
  function maskName(m) {
    if (m === 255) return 'fill'; if (m === 0) return 'single';
    var p = []; if (m & N) p.push('n'); if (m & E) p.push('e'); if (m & S) p.push('s'); if (m & W) p.push('w');
    var c = []; if (m & NE) c.push('ne'); if (m & SE) c.push('se'); if (m & SW) c.push('sw'); if (m & NW) c.push('nw');
    return (p.join('') || 'x') + (c.length ? '_' + c.join('') : '');
  }

  /* Compose a case's hall to an offscreen canvas (static layer). g0 = the grid WITH furniture; objects = the case's
   * furniture list. Animated props (banners, braziers) are drawn per frame by drawAnimated. */
  function composeHall(hall, grid, objects) {
    var L = LOOK[hall.id];
    var c = document.createElement('canvas'); c.width = grid.w * T; c.height = grid.h * T;
    var g = c.getContext('2d'); g.imageSmoothingEnabled = false;
    var isWall = function (x, y) { if (x < 0 || y < 0 || x >= grid.w || y >= grid.h) return true; var ch = hall.rows[y][x]; return ch === '#' || ch === 'O'; };
    for (var y = 0; y < grid.h; y++) for (var x = 0; x < grid.w; x++) blit(g, L.floor + '_' + (1 + Math.floor(ih(x, y, 77) * 4)), x * T, y * T);
    for (y = 0; y < grid.h; y++) for (x = 0; x < grid.w; x++) {
      if (!isWall(x, y)) continue;
      var m = 0;
      if (isWall(x, y - 1)) m |= N; if (isWall(x + 1, y - 1)) m |= NE; if (isWall(x + 1, y)) m |= E; if (isWall(x + 1, y + 1)) m |= SE;
      if (isWall(x, y + 1)) m |= S; if (isWall(x - 1, y + 1)) m |= SW; if (isWall(x - 1, y)) m |= W; if (isWall(x - 1, y - 1)) m |= NW;
      blit(g, L.walls + '_' + maskName(normalise(m)), x * T, y * T);
    }
    // wall openings read as dark thresholds (a slit, a door, an arch you could stand in)
    for (y = 0; y < grid.h; y++) for (x = 0; x < grid.w; x++) {
      if (hall.rows[y][x] !== ',') continue;
      g.fillStyle = 'rgba(10,8,6,0.55)'; g.fillRect(x * T + 2, y * T + 2, T - 4, T - 4);
      g.fillStyle = 'rgba(10,8,6,0.35)'; g.fillRect(x * T, y * T, T, T);
    }
    // fixed furniture from the hall map: pews and altar in pairs, racks per cell
    for (y = 0; y < grid.h; y++) {
      var row = hall.rows[y];
      for (x = 0; x < grid.w; x++) {
        var ch = row[x];
        if ((ch === 'P' || ch === 'A') && row[x + 1] === ch) { blit(g, ch === 'P' ? 'pew' : 'altar', x * T, y * T); x++; }
        else if (ch === 'G') blit(g, 'anvil', x * T, y * T); // the gatehouse forge: iron that READS as iron (a rack of spears read as wood)
      }
    }
    objects.forEach(function (o) {
      if (o.art === 'banner' || o.art === 'brazier') return; // animated: drawn per frame
      blit(g, PROP_ART[o.art], o.x * T, o.y * T);
    });
    return c;
  }
  /* torn = [[x,y]...] banner tiles a bolt passed through: a dark slit with a pale frayed edge, on the cloth */
  function drawAnimated(g, objects, t, torn) {
    objects.forEach(function (o) {
      if (o.art !== 'banner' && o.art !== 'brazier') return;
      var f = Math.floor(t * (o.art === 'brazier' ? 8 : 4) + ih(o.x, o.y, 3) * 4) % 4;
      blit(g, o.art + '_f' + f, HX + o.x * T, HY + o.y * T);
      if (o.art === 'banner' && torn && torn.some(function (q) { return q[0] === o.x && q[1] === o.y; })) {
        // review #21: the first tear was a 1x4 fleck beside the banner's own notch; a rent must read at 1x
        var bx = HX + o.x * T, by = HY + o.y * T;
        g.fillStyle = '#120404'; g.fillRect(bx + 8, by + 3, 2, 6); g.fillRect(bx + 10, by + 4, 1, 4); g.fillRect(bx + 7, by + 5, 1, 2);
        g.fillStyle = '#f4d2b0'; g.fillRect(bx + 7, by + 3, 1, 2); g.fillRect(bx + 10, by + 3, 1, 1); g.fillRect(bx + 11, by + 7, 1, 2); g.fillRect(bx + 7, by + 8, 1, 1);
      }
    });
  }

  // ---- chalk and thread -----------------------------------------------------------------------------
  function px(v) { return HX + v * T; }
  function py(v) { return HY + v * T; }
  function line(g, x0, y0, x1, y1, col, dotted) {
    x0 = Math.round(x0); y0 = Math.round(y0); x1 = Math.round(x1); y1 = Math.round(y1);
    var dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, err = dx + dy, k = 0;
    g.fillStyle = col;
    for (;;) {
      if (!dotted || (k++ % dotted) === 0) g.fillRect(x0, y0, 1, 1);
      if (x0 === x1 && y0 === y1) break;
      var e2 = 2 * err;
      if (e2 >= dy) { err += dy; x0 += sx; }
      if (e2 <= dx) { err += dx; y0 += sy; }
    }
  }
  /* The regions as chalk: a dotted outline on every edge between a region tile and anything that is not the same
   * region. `hi` = the region to brighten (hovered / every string ends there). */
  function drawRegions(g, grid, look, hi, glow, t) {
    var chalk = LOOK[look].chalk;
    for (var y = 0; y < grid.h; y++) for (var x = 0; x < grid.w; x++) {
      var r = TR.regionAt(grid, x, y);
      if (!r) continue;
      var strong = r === hi;
      if (strong && glow) { g.fillStyle = 'rgba(255,214,120,' + (0.10 + 0.06 * Math.sin(t * 3)) + ')'; g.fillRect(px(x), py(y), T, T); }
      else if (strong) { g.fillStyle = 'rgba(255,255,255,0.07)'; g.fillRect(px(x), py(y), T, T); }
      g.globalAlpha = strong ? 0.85 : 0.32;
      if (TR.regionAt(grid, x, y - 1) !== r) line(g, px(x), py(y), px(x + 1) - 1, py(y), chalk, 2);
      if (TR.regionAt(grid, x, y + 1) !== r) line(g, px(x), py(y + 1) - 1, px(x + 1) - 1, py(y + 1) - 1, chalk, 2);
      if (TR.regionAt(grid, x - 1, y) !== r) line(g, px(x), py(y), px(x), py(y + 1) - 1, chalk, 2);
      if (TR.regionAt(grid, x + 1, y) !== r) line(g, px(x + 1) - 1, py(y), px(x + 1) - 1, py(y + 1) - 1, chalk, 2);
      g.globalAlpha = 1;
    }
  }
  var SHOW = { buried: 5, sunk: 9, shallow: 13 };
  /* A bolt: the shaft stands out of the struck face BACK along the line it arrived on; how much shows is the depth.
   * Two-tone shaft (dark wood + lit edge), a steel point hole at the face, cream fletching, a numbered tag well clear
   * of the nock. (First pass drew a 3 px stub under its own tag: found by looking at 4x, 2026-09-19.) */
  function drawBolt(g, b, n, selected, t, grid) {
    var sx = px(b.stop[0]), sy = py(b.stop[1]);
    var d = b.din, L = Math.sqrt(d[0] * d[0] + d[1] * d[1]), ux = -d[0] / L, uy = -d[1] / L;
    var len = SHOW[b.band];
    var tag = tagPlace(b, grid, sx, sy, ux, uy, len);
    var ex = sx + ux * len, ey = sy + uy * len;
    if (selected) { var a = 0.35 + 0.25 * Math.sin(t * 6); g.fillStyle = 'rgba(255,226,140,' + a + ')'; g.fillRect(Math.round(sx) - 3, Math.round(sy) - 3, 7, 7); }
    g.fillStyle = 'rgba(0,0,0,0.55)'; g.fillRect(Math.round(sx) - 1, Math.round(sy) - 1, 3, 3);
    line(g, sx + 1, sy + 1, ex + 1, ey + 1, 'rgba(0,0,0,0.55)');
    line(g, sx, sy, ex, ey, '#4a2c14');
    line(g, sx - uy * 0.9, sy + ux * 0.9, ex - uy * 0.9, ey + ux * 0.9, '#c08a52');
    // fletching: two cream vanes swept back from the nock, with a red cock feather
    var fx = -ux * 4, fy = -uy * 4;
    line(g, ex, ey, ex + fx + uy * 3, ey + fy - ux * 3, '#f1e6cc');
    line(g, ex, ey, ex + fx - uy * 3, ey + fy + ux * 3, '#f1e6cc');
    line(g, ex - ux, ey - uy, ex - ux + fx * 0.6, ey - uy + fy * 0.6, '#c8413a');
    // the tag: BESIDE the shaft (review #5/#23 - past the nock it sat on the string's first stretch, over the angle
    // numeral the court judges, and once over the answer region), on open floor where the room allows
    var tx = tag[0], ty = tag[1];
    g.fillStyle = 'rgba(0,0,0,0.5)'; g.fillRect(tx + 1, ty + 1, 9, 11);
    g.fillStyle = selected ? '#ffe39a' : '#eee2c6'; g.fillRect(tx, ty, 9, 11);
    g.fillStyle = selected ? '#b8862a' : '#8a6a3a'; g.fillRect(tx, ty, 9, 1); g.fillRect(tx, ty + 10, 9, 1); g.fillRect(tx, ty, 1, 11); g.fillRect(tx + 8, ty, 1, 11);
    root.SL_FONT.text(g, String(n), tx + 2, ty + 2, { colour: '#3a2412' });
  }
  /* the tag's top-left: try both sides of the shaft (and then further out), prefer a spot on open floor that is
   * neither solid nor inside a region; fall back to the old past-the-nock spot */
  function tagPlace(b, grid, sx, sy, ux, uy, len) {
    var mx = sx + ux * len * 0.5, my = sy + uy * len * 0.5, best = null, bestScore = -1;
    [[-uy, ux], [uy, -ux]].forEach(function (pv) {
      [9, 13].forEach(function (dist) {
        var cx = mx + pv[0] * dist, cy = my + pv[1] * dist;
        var tx = Math.round(cx) - 4, ty = Math.round(cy) - 5;
        if (tx < HX || ty < HY || tx + 9 > HX + 24 * T || ty + 11 > HY + 14 * T) return;
        var score = 0;
        if (grid) {
          var cells = [[tx, ty], [tx + 8, ty], [tx, ty + 10], [tx + 8, ty + 10]].map(function (q) { return [Math.floor((q[0] - HX) / T), Math.floor((q[1] - HY) / T)]; });
          var floor = cells.every(function (c) { return TR.matAt(grid, c[0], c[1]) === 'floor'; });
          var noRegion = cells.every(function (c) { return !TR.regionAt(grid, c[0], c[1]); });
          score = (floor ? 2 : 0) + (noRegion ? 1 : 0);
        }
        score -= dist === 13 ? 0.1 : 0;
        if (score > bestScore) { bestScore = score; best = [tx, ty]; }
      });
    });
    return best || [Math.round(sx + ux * (len + 9)) - 4, Math.round(sy + uy * (len + 9)) - 5];
  }
  function chalkNum(g, v, x, y) { root.SL_FONT.text(g, String(v), Math.round(x) - 2, Math.round(y) - 3, { colour: '#f7f1e0', outline: '#1a120c' }); }
  /* A string: red thread with a shadow, a knot every pace, a brass pin at each bend and at its end, chalk
   * protractors (ticks = angle class) either side of each bend. */
  function drawString(g, sp, colour, bends, t, faded) {
    var pts = sp.points;
    g.globalAlpha = faded ? 0.5 : 1;
    for (var i = 0; i + 1 < pts.length; i++) line(g, px(pts[i][0]) + 1, py(pts[i][1]) + 1, px(pts[i + 1][0]) + 1, py(pts[i + 1][1]) + 1, 'rgba(20,0,0,0.6)');
    for (i = 0; i + 1 < pts.length; i++) line(g, px(pts[i][0]), py(pts[i][1]), px(pts[i + 1][0]), py(pts[i + 1][1]), colour);
    // knots: walk the polyline - a dark knot every pace, a pale bead every fifth, so the paces can be COUNTED
    var acc = 0, next = 1;
    for (i = 0; i + 1 < pts.length; i++) {
      var ax = pts[i][0], ay = pts[i][1], bx = pts[i + 1][0], by = pts[i + 1][1], seg = Math.hypot(bx - ax, by - ay);
      while (next <= acc + seg + 1e-9 && seg > 0) {
        var f = (next - acc) / seg, kx = Math.round(px(ax + (bx - ax) * f)), ky = Math.round(py(ay + (by - ay) * f));
        if (next % 5 === 0) { g.fillStyle = '#1a0606'; g.fillRect(kx - 2, ky - 2, 4, 4); g.fillStyle = '#f6dca0'; g.fillRect(kx - 1, ky - 1, 2, 2); }
        else { g.fillStyle = '#3a0808'; g.fillRect(kx - 1, ky - 1, 2, 2); }
        next++;
      }
      acc += seg;
    }
    // pins at bends (the chalk numerals are a SEPARATE pass, drawString's caller draws them after the bolts: review #5)
    for (i = 0; i < bends && i < sp.surfaces.length; i++) {
      var s = sp.surfaces[i], p = s.point, cx = px(p[0]), cy = py(p[1]);
      g.fillStyle = '#2a1a06'; g.fillRect(Math.round(cx) - 2, Math.round(cy) - 2, 4, 4);
      g.fillStyle = '#e8c04a'; g.fillRect(Math.round(cx) - 1, Math.round(cy) - 1, 2, 2);
    }
    var e = pts[pts.length - 1];
    var ex2 = Math.round(px(e[0])), ey2 = Math.round(py(e[1]));
    g.fillStyle = '#2a1a06'; g.fillRect(ex2 - 2, ey2 - 2, 5, 5);
    g.fillStyle = '#f1d27a'; g.fillRect(ex2 - 1, ey2 - 1, 3, 3);
    g.fillStyle = colour; g.fillRect(ex2, ey2, 1, 1);
    g.globalAlpha = 1;
  }
  /* the chalk for one string: a protractor at every bend, and at the surface the tail rests on before the player has
   * bent there. Drawn AFTER the bolts and their tags so nothing covers the number the court judges (review #5). */
  function drawStringChalk(g, sp, bends) {
    for (var i = 0; i < bends && i < sp.surfaces.length; i++) {
      var s = sp.surfaces[i];
      drawProtractor(g, s.face, px(s.point[0]), py(s.point[1]), s.dirIn, s.ang, sp.bendsUsed ? sp.bendsUsed[i] : null);
    }
    if (sp.end && sp.end.kind === 'hit' && sp.surfaces.length > bends) {
      var sf = sp.surfaces[bends];
      drawProtractor(g, sf.face, px(sf.point[0]), py(sf.point[1]), sf.dirIn, sf.ang, null);
    }
  }
  /* the chalk protractor at a bend: the face as a chalk rule, and the ANGLE CLASS of each leg written as a numeral
   * (1 low · 2 diagonal · 3 steep · 4 square) just out along that leg. (First pass drew 1-4 single chalk pixels:
   * the whole rule set rests on this number and nobody could read it at 1x.) */
  function drawProtractor(g, face, cx, cy, dIn, inCls, dOut) {
    if (face === 'v') line(g, cx, cy - 7, cx, cy + 7, 'rgba(248,242,226,0.8)', 2); else line(g, cx - 7, cy, cx + 7, cy, 'rgba(248,242,226,0.8)', 2);
    function num(dir, cls) {
      var L = Math.hypot(dir[0], dir[1]), ux = dir[0] / L, uy = dir[1] / L;
      // out along the leg, then nudged off the thread to the side away from the face so it never sits on the string
      var ox = cx + ux * 9, oy = cy + uy * 9;
      if (face === 'v') oy += (uy >= 0 ? 5 : -5); else ox += (ux >= 0 ? 5 : -5);
      chalkNum(g, cls, ox, oy);
    }
    num([-dIn[0], -dIn[1]], inCls);
    if (dOut) num(dOut, TR.angleClass(dOut, face));
  }
  function describeTile(grid, objects, x, y) {
    var m = TR.matAt(grid, x, y);
    if (m === 'void' || m === 'floor') return null;
    var o = objects.find(function (q) { return y === q.y && x >= q.x && x < q.x + q.w; });
    var ch = TR.charAt(grid, x, y);
    var thing = o ? THING[o.art] : ch === 'P' ? THING.pew : ch === 'A' ? THING.altar : ch === 'G' ? 'FORGE ANVIL' : (ch === 'O' ? 'PILLAR' : 'WALL');
    return thing + ': ' + MATNAME[m];
  }
  root.SL_RENDER = { state: state, img: img, T: T, HX: HX, HY: HY, LOOK: LOOK, composeHall: composeHall, drawAnimated: drawAnimated, drawRegions: drawRegions,
    drawBolt: drawBolt, drawString: drawString, drawStringChalk: drawStringChalk, chalkNum: chalkNum, line: line, px: px, py: py, blit: blit, describeTile: describeTile, ih: ih };
})(window);
