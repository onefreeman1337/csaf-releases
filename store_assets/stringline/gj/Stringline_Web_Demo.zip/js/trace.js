/* STRINGLINE - trace.js
 * The one geometry + rules engine. The game, the case generator, the solver and every harness player
 * run THIS file (Wings/Games/CLAUDE.md §6b-16: knower and brute-forcer run the same code).
 * Dual-mode: a <script> in the browser (window.SL_TRACE) and require() in Node (§6b-5: IIFE, no shared consts).
 *
 * Units: one tile = one pace. Positions are always multiples of 0.25 (lattice directions from tile centres and
 * face hits keep them there), so every position comparison below is EXACT in binary floating point.
 *
 * v2 (2026-09-19): the archer stood in a REGION (a named stretch of the hall), not at a point. v1's point
 * stations failed the pre-registered sweep control (PREREG_2026-09-19_sweep.md: median m = 1).
 */
(function (root) {
  'use strict';

  // The 16 lattice directions a bolt can fly in (compass order, north first, clockwise).
  var DIRS = [
    [0, -1], [1, -2], [1, -1], [2, -1], [1, 0], [2, 1], [1, 1], [1, 2],
    [0, 1], [-1, 2], [-1, 1], [-2, 1], [-1, 0], [-2, -1], [-1, -1], [-1, -2]
  ];

  var MAT = {
    '#': 'stone', 'O': 'stone', 'A': 'stone', 'S': 'stone',
    'I': 'iron', 'G': 'iron',
    'T': 'wood', 'P': 'wood', 'W': 'wood', 'C': 'wood', 'B': 'wood',
    '~': 'cloth',
    '.': 'floor', ',': 'floor'
  };
  var SOLID = { stone: true, iron: true, wood: true };

  var ANG = { SHALLOW: 1, DIAGONAL: 2, STEEP: 3, SQUARE: 4 };
  var ANG_NAME = { 1: 'shallow', 2: 'diagonal', 3: 'steep', 4: 'square' };

  var MAX_LEN = 21;   // paces a bolt can fly at most (told to the player)
  var MAX_WRAPS = 3;  // ricochets at most (told to the player)
  var BANDS = [       // depth tells: how much shaft is left showing says how far the bolt flew
    { id: 'buried', lo: 0, hi: 7 },
    { id: 'sunk', lo: 7, hi: 14 },
    { id: 'shallow', lo: 14, hi: 21 }
  ];

  // ---- the rules (v3) --------------------------------------------------------------------------------
  // fwd(mat, classIn) -> classOut | null (the bolt sticks). pre(mat, classOut) -> [classIn...] (backwards: which
  // arrivals could have left at this class). Stone MIRRORS, shallow only. Iron GLANCES: it throws a bolt off one
  // class FLATTER than it came in (steep->diagonal, diagonal->shallow, shallow->shallow); square sticks. Wood stops.
  var GLANCE = { 1: 1, 2: 1, 3: 2, 4: null };
  var GLANCE_PRE = { 1: [1, 2], 2: [3], 3: [], 4: [] };
  function trueFwd(mat, a) {
    if (mat === 'stone') return a === ANG.SHALLOW ? a : null;
    if (mat === 'iron') return GLANCE[a];
    return null;
  }
  function truePre(mat, a) {
    if (mat === 'stone') return a === ANG.SHALLOW ? [a] : [];
    if (mat === 'iron') return GLANCE_PRE[a];
    return [];
  }
  function mirrorFwd(a) { return a; }
  function mirrorPre(a) { return [a]; }
  var RULES = {
    TRUE: { name: 'true', fwd: trueFwd, pre: truePre, bothSigns: false, cloth: 'pass', tears: true, depth: true, maxWraps: MAX_WRAPS },
    // everyone's intuition: every surface is a mirror, at any angle; cloth passes; tears and depth unread
    NAIVE: { name: 'naive', fwd: function (m, a) { return mirrorFwd(a); }, pre: function (m, a) { return mirrorPre(a); }, bothSigns: false, cloth: 'pass', tears: false, depth: false, maxWraps: MAX_WRAPS },
    // the free tool used by someone who knows no rule: bend any way at any surface
    SWEEP: { name: 'sweep', fwd: null, pre: function () { return [1, 2, 3, 4]; }, bothSigns: true, cloth: 'pass', tears: false, depth: false, maxWraps: MAX_WRAPS },
    STRAIGHT: { name: 'straight', fwd: function () { return null; }, pre: function () { return []; }, bothSigns: false, cloth: 'pass', tears: false, depth: false, maxWraps: 0 }
  };
  function ablate(rule) {
    var r = { name: 'no-' + rule, fwd: trueFwd, pre: truePre, bothSigns: false, cloth: 'pass', tears: true, depth: true, maxWraps: MAX_WRAPS };
    if (rule === 'R1') { r.fwd = function (m, a) { return m === 'stone' ? a : trueFwd(m, a); }; r.pre = function (m, a) { return m === 'stone' ? [a] : truePre(m, a); }; }
    else if (rule === 'R2') { r.fwd = function (m, a) { return m === 'iron' ? a : trueFwd(m, a); }; r.pre = function (m, a) { return m === 'iron' ? [a] : truePre(m, a); }; }
    else if (rule === 'R3') { r.fwd = function (m, a) { return m === 'wood' ? (a === ANG.SHALLOW ? a : null) : trueFwd(m, a); }; r.pre = function (m, a) { return m === 'wood' ? (a === ANG.SHALLOW ? [a] : []) : truePre(m, a); }; }
    else if (rule === 'R4') r.cloth = 'block';
    else if (rule === 'R5') r.tears = false;
    else if (rule === 'R6') r.depth = false;
    else throw new Error('ablate: unknown rule ' + rule);
    return r;
  }
  // Build the lattice direction leaving a face: `awaySign` points out of the solid, `alongSign` along the face.
  var CLASS_MAG = { 1: [1, 2], 2: [1, 1], 3: [2, 1], 4: [1, 0] }; // [across, along]
  function leave(face, awaySign, alongSign, cls) {
    var m = CLASS_MAG[cls];
    var across = awaySign * m[0], along = m[1] === 0 ? 0 : alongSign * m[1];
    return face === 'v' ? [across, along] : [along, across];
  }

  // ---- the hall ----------------------------------------------------------------------------------
  function makeGrid(hall) {
    var rows = hall.rows, regs = hall.regions, names = hall.names;
    var h = rows.length, w = rows[0].length;
    if (!regs || regs.length !== h) throw new Error('makeGrid: region rows missing or wrong height for ' + hall.id);
    var cells = [], region = [];
    var regions = {};
    for (var y = 0; y < h; y++) {
      if (rows[y].length !== w) throw new Error('makeGrid: ragged row ' + y + ' (' + rows[y].length + ' vs ' + w + ') in ' + hall.id);
      if (regs[y].length !== w) throw new Error('makeGrid: ragged region row ' + y + ' (' + regs[y].length + ' vs ' + w + ') in ' + hall.id);
      for (var x = 0; x < w; x++) {
        var c = rows[y][x];
        if (!MAT[c]) throw new Error('makeGrid: unknown map char "' + c + '" at ' + x + ',' + y + ' in ' + hall.id);
        cells.push(c);
        var r = regs[y][x];
        if (r >= 'a' && r <= 'z' && MAT[c] === 'floor') {
          if (!names[r]) throw new Error('makeGrid: region ' + r + ' has no name in ' + hall.id);
          region.push(r);
          (regions[r] = regions[r] || { id: r, name: names[r], tiles: [] }).tiles.push([x, y]);
        } else region.push(null);
      }
    }
    Object.keys(names).forEach(function (k) { if (!regions[k]) throw new Error('makeGrid: named region ' + k + ' has no floor tile in ' + hall.id); });
    return { id: hall.id, w: w, h: h, cells: cells, region: region, regions: regions };
  }
  function charAt(g, x, y) {
    if (x < 0 || y < 0 || x >= g.w || y >= g.h) return null;
    return g.cells[y * g.w + x];
  }
  function matAt(g, x, y) {
    var c = charAt(g, x, y);
    return c === null ? 'void' : MAT[c];
  }
  function regionAt(g, x, y) {
    if (x < 0 || y < 0 || x >= g.w || y >= g.h) return null;
    return MAT[g.cells[y * g.w + x]] === 'floor' ? g.region[y * g.w + x] : null;
  }
  function withFurniture(g, placements) {
    var cells = g.cells.slice();
    for (var i = 0; i < placements.length; i++) {
      var p = placements[i];
      var k = p.y * g.w + p.x;
      if (cells[k] !== '.') throw new Error('withFurniture: tile ' + p.x + ',' + p.y + ' is "' + cells[k] + '", not open floor');
      if (!MAT[p.ch] || MAT[p.ch] === 'floor') throw new Error('withFurniture: "' + p.ch + '" is not furniture');
      cells[k] = p.ch;
    }
    var regions = {};
    Object.keys(g.regions).forEach(function (id) {
      var tiles = g.regions[id].tiles.filter(function (t) { return MAT[cells[t[1] * g.w + t[0]]] === 'floor'; });
      regions[id] = { id: id, name: g.regions[id].name, tiles: tiles };
    });
    return { id: g.id, w: g.w, h: g.h, cells: cells, region: g.region, regions: regions };
  }

  // ---- geometry ----------------------------------------------------------------------------------
  function sgn(v) { return v > 0 ? 1 : v < 0 ? -1 : 0; }
  function dlen(d) { return Math.sqrt(d[0] * d[0] + d[1] * d[1]); }
  function angleClass(d, face) {
    var along = face === 'v' ? Math.abs(d[1]) : Math.abs(d[0]);
    var across = face === 'v' ? Math.abs(d[0]) : Math.abs(d[1]);
    if (across === 0) return 0;
    if (along === 0) return ANG.SQUARE;
    var r = across / along;
    if (r === 0.5) return ANG.SHALLOW;
    if (r === 1) return ANG.DIAGONAL;
    if (r === 2) return ANG.STEEP;
    throw new Error('angleClass: non-lattice direction ' + d);
  }

  /* Cast one straight segment from p along lattice direction d for at most sMax parameter units (length =
   * s*|d|). Returns { visits:[{x,y,sIn,sOut,mat}], end:{kind,s,point,...} }. The first visit is the tile the
   * segment STARTS in (sIn 0) - a point on a face starts inside the tile it is moving into.
   * end.kind: 'hit' (solid face) | 'corner' (a tile corner with a solid or void neighbour) | 'exit' | 'range'. */
  function cast(g, p, d, sMax) {
    var px = p[0], py = p[1], dx = d[0], dy = d[1];
    var tx = Math.floor(px + dx * 1e-6), ty = Math.floor(py + dy * 1e-6);
    var visits = [];
    var sIn = 0, guard = 0;
    for (;;) {
      if (++guard > 400) throw new Error('cast: runaway');
      var sx = Infinity, sy = Infinity;
      if (dx > 0) sx = (tx + 1 - px) / dx; else if (dx < 0) sx = (tx - px) / dx;
      if (dy > 0) sy = (ty + 1 - py) / dy; else if (dy < 0) sy = (ty - py) / dy;
      var sNext = Math.min(sx, sy);
      if (sNext > sMax) {
        visits.push({ x: tx, y: ty, sIn: sIn, sOut: sMax, mat: matAt(g, tx, ty) });
        return { visits: visits, end: { kind: 'range', s: sMax, point: [px + sMax * dx, py + sMax * dy] } };
      }
      visits.push({ x: tx, y: ty, sIn: sIn, sOut: sNext, mat: matAt(g, tx, ty) });
      var point = [px + sNext * dx, py + sNext * dy];
      if (sx === sy) {
        var ma = matAt(g, tx + sgn(dx), ty), mb = matAt(g, tx, ty + sgn(dy)), mc = matAt(g, tx + sgn(dx), ty + sgn(dy));
        if (SOLID[ma] || SOLID[mb] || SOLID[mc] || ma === 'void' || mb === 'void' || mc === 'void') {
          return { visits: visits, end: { kind: 'corner', s: sNext, point: point } };
        }
        tx += sgn(dx); ty += sgn(dy);
      } else {
        var face = sx < sy ? 'v' : 'h';
        var nx = sx < sy ? tx + sgn(dx) : tx, ny = sx < sy ? ty : ty + sgn(dy);
        var m = matAt(g, nx, ny);
        if (m === 'void') return { visits: visits, end: { kind: 'exit', s: sNext, point: point } };
        if (SOLID[m]) {
          return { visits: visits, end: { kind: 'hit', s: sNext, point: point, face: face, tile: [nx, ny], mat: m, ang: angleClass(d, face) } };
        }
        tx = nx; ty = ny;
      }
      sIn = sNext;
    }
  }
  function reflect(d, face) { return face === 'v' ? [-d[0], d[1]] : [d[0], -d[1]]; }

  function bandOf(len) {
    for (var i = 0; i < BANDS.length; i++) if (len > BANDS[i].lo && len <= BANDS[i].hi) return BANDS[i].id;
    return null;
  }
  function band(id) {
    for (var i = 0; i < BANDS.length; i++) if (BANDS[i].id === id) return BANDS[i];
    throw new Error('band: unknown band ' + id);
  }

  /* Fly a bolt FORWARD from the centre of floor tile `origin` [x,y]. Returns a bolt record or {reject}. */
  function fly(g, origin, d, R) {
    R = R || RULES.TRUE;
    if (matAt(g, origin[0], origin[1]) !== 'floor') throw new Error('fly: origin ' + origin + ' is not floor');
    var p = [origin[0] + 0.5, origin[1] + 0.5], dir = d.slice(), L = 0, wraps = [], tears = [], segs = [];
    for (;;) {
      var r = cast(g, p, dir, (MAX_LEN - L) / dlen(dir));
      for (var i = 0; i < r.visits.length; i++) if (r.visits[i].mat === 'cloth') tears.push([r.visits[i].x, r.visits[i].y]);
      var e = r.end;
      segs.push({ from: p.slice(), to: e.point.slice(), d: dir.slice() });
      L += e.s * dlen(dir);
      if (e.kind === 'exit') return { reject: 'exit' };
      if (e.kind === 'corner') return { reject: 'corner' };
      if (e.kind === 'range') return { reject: 'spent' };
      if (e.ang === 0) throw new Error('fly: parallel hit');
      var out = R.fwd(e.mat, e.ang);
      if (out) {
        if (wraps.length >= R.maxWraps) return { reject: 'wrap-cap' };
        var acr = e.face === 'v' ? dir[0] : dir[1], alg = e.face === 'v' ? dir[1] : dir[0];
        var nd = leave(e.face, -sgn(acr), sgn(alg), out);
        wraps.push({ point: e.point.slice(), face: e.face, mat: e.mat, ang: e.ang, out: out, tile: e.tile });
        dir = nd;
        p = e.point.slice();
        continue;
      }
      return {
        origin: origin.slice(), region: regionAt(g, origin[0], origin[1]), d0: d.slice(), stop: e.point.slice(), din: dir.slice(),
        face: e.face, tile: e.tile, mat: e.mat, ang: e.ang, len: L, band: bandOf(L), wraps: wraps, tears: dedupeTiles(tears), segs: segs
      };
    }
  }
  function dedupeTiles(list) {
    var seen = {}, out = [];
    list.forEach(function (t) { var k = t[0] + ',' + t[1]; if (!seen[k]) { seen[k] = true; out.push(t); } });
    return out;
  }

  /* Trace a bolt BACKWARD under rule set R. Returns every place the rule-valid string may END:
   * [{ id: region, lo, hi (paces along the string, clipped to the depth band if R.depth), cloths:[[x,y]], wraps }].
   * Also returns, in `.path`, the polyline the string follows under R (for drawing and for the harness). */
  function traceBack(g, bolt, R, torn) {
    var out = [];
    var bd = R.depth ? band(bolt.band) : null;
    var budget = { n: 0 };
    (function walk(p, b, L, wraps, cloths, bends) {
      if (++budget.n > 5000) throw new Error('traceBack: branch budget exceeded');
      var r = cast(g, p, b, (MAX_LEN - L) / dlen(b));
      for (var i = 0; i < r.visits.length; i++) {
        var v = r.visits[i];
        if (v.mat === 'cloth') {
          if (R.cloth === 'block' || (R.tears && torn && !torn[v.x + ',' + v.y])) return;
          if (!cloths.some(function (c) { return c[0] === v.x && c[1] === v.y; })) cloths = cloths.concat([[v.x, v.y]]);
          continue;
        }
        var id = regionAt(g, v.x, v.y);
        if (!id) continue;
        var lo = L + v.sIn * dlen(b), hi = L + v.sOut * dlen(b);
        if (bd) { lo = Math.max(lo, bd.lo); hi = Math.min(hi, bd.hi); }
        if (hi - lo > 1e-9) {
          var ck = cloths.map(function (c) { return c[0] + ',' + c[1]; }).sort().join('|');
          out.push({ id: id, lo: lo, hi: hi, cloths: cloths.slice(), ck: ck, wraps: wraps, bends: bends });
        }
      }
      var e = r.end;
      if (e.kind !== 'hit' || wraps >= R.maxWraps) return;
      var ins = R.pre(e.mat, e.ang);
      if (!ins.length) return;
      var acr = e.face === 'v' ? b[0] : b[1], alg = e.face === 'v' ? b[1] : b[0];
      var L2 = L + e.s * dlen(b);
      var seen = {};
      for (var k = 0; k < ins.length; k++) {
        var signs = R.bothSigns ? [1, -1] : [sgn(alg)];
        for (var j = 0; j < signs.length; j++) {
          var nb = leave(e.face, -sgn(acr), signs[j], ins[k]);
          if (nb[0] === 0 && nb[1] === 0) continue;
          var key = nb[0] + ',' + nb[1];
          if (seen[key]) continue;
          seen[key] = true;
          walk(e.point.slice(), nb, L2, wraps + 1, cloths, bends.concat([nb]));
        }
      }
    })(bolt.stop.slice(), [-bolt.din[0], -bolt.din[1]], 0, 0, [], []);
    return out;
  }

  /* The directions a string may leave a face in (the open half-plane; never parallel to the face). */
  function leavingDirs(face, awaySign) {
    return DIRS.filter(function (d) { return (face === 'v' ? d[0] : d[1]) * awaySign > 0; });
  }

  /* The court (TRUE rules; tears are scenery). Reads a PLAYER's string - bends at the surfaces it met, ending at
   * `len` paces - and returns { ok, region, len, broken:{rule, bend, text} }. The court never knows the answer:
   * any string set that obeys every rule and ends in one region is the truth by the campaign's uniqueness proof. */
  function judgeString(g, bolt, bends, len) {
    var sp = stringPath(g, bolt, bends, len);
    for (var i = 0; i < bends.length; i++) {
      var s = sp.surfaces[i];
      if (!s) return { ok: false, broken: { rule: 'geometry', bend: i, text: 'a bend with no surface under it' } };
      var b = s.dirIn, nb = bends[i];
      var acr = s.face === 'v' ? b[0] : b[1], alg = s.face === 'v' ? b[1] : b[0];
      var nacr = s.face === 'v' ? nb[0] : nb[1], nalg = s.face === 'v' ? nb[1] : nb[0];
      var outCls = angleClass(nb, s.face);
      if (s.mat === 'wood') return { ok: false, broken: { rule: 'R3', bend: i, mat: s.mat } };
      if (sgn(nacr) !== -sgn(acr)) return { ok: false, broken: { rule: 'geometry', bend: i, mat: s.mat } };
      if (s.mat === 'stone') {
        if (s.ang !== ANG.SHALLOW) return { ok: false, broken: { rule: 'R1', bend: i, mat: s.mat, why: 'steep' } };
        if (outCls !== s.ang || sgn(nalg) !== sgn(alg)) return { ok: false, broken: { rule: 'R1', bend: i, mat: s.mat, why: 'angle' } };
      } else if (s.mat === 'iron') {
        var pre = truePre('iron', s.ang);
        if (pre.indexOf(outCls) < 0 || sgn(nalg) !== sgn(alg)) return { ok: false, broken: { rule: 'R2', bend: i, mat: s.mat } };
      }
    }
    var bd = band(bolt.band);
    var endLen = Math.min(len, sp.length);
    if (!(endLen > bd.lo && endLen <= bd.hi)) return { ok: false, broken: { rule: 'R6', band: bolt.band, len: endLen } };
    // the tile the string ENDS in: nudge back along the tail so an end exactly on a boundary counts the tile it lies in
    var e = sp.points[sp.points.length - 1], d = sp.dir, dl = dlen(d);
    var qx = e[0] - d[0] / dl * 1e-3, qy = e[1] - d[1] / dl * 1e-3;
    var region = regionAt(g, Math.floor(qx), Math.floor(qy));
    return { ok: true, region: region, len: endLen };
  }

  /* The polyline a PLAYER's string follows: from the bolt, backwards, bending at each surface met in the given
   * order of outgoing directions (`bends`, one lattice direction per surface), for `length` paces. The game draws
   * this; it applies NO rule (the tool is a string, not a physicist). Returns {points, end, length, surfaces}. */
  function stringPath(g, bolt, bends, length) {
    var p = bolt.stop.slice(), b = [-bolt.din[0], -bolt.din[1]], L = 0, pts = [p.slice()], surfaces = [];
    for (var i = 0; ; i++) {
      var r = cast(g, p, b, (Math.min(length, MAX_LEN) - L) / dlen(b));
      var e = r.end;
      pts.push(e.point.slice());
      L += e.s * dlen(b);
      if (e.kind !== 'hit') return { points: pts, end: e, length: L, surfaces: surfaces, dir: b };
      surfaces.push({ point: e.point.slice(), face: e.face, mat: e.mat, ang: e.ang, tile: e.tile, dirIn: b.slice() });
      if (i >= bends.length) return { points: pts, end: e, length: L, surfaces: surfaces, dir: b };
      b = bends[i].slice();
      p = e.point.slice();
    }
  }

  function tornSet(bolts) {
    var t = {};
    bolts.forEach(function (b) { b.tears.forEach(function (c) { t[c[0] + ',' + c[1]] = true; }); });
    return t;
  }

  /* Solve a case under R: the regions where EVERY bolt's string can end (and, if R.tears, where some choice of
   * one ending per bolt explains the torn set exactly). Returns sorted region ids. */
  function solve(g, bolts, R) {
    var torn = tornSet(bolts);
    var per = bolts.map(function (b) { return traceBack(g, b, R, R.tears ? torn : null); });
    var ids = null;
    per.forEach(function (list) {
      var s = {};
      list.forEach(function (c) { s[c.id] = true; });
      ids = ids === null ? s : Object.keys(ids).reduce(function (o, k) { if (s[k]) o[k] = true; return o; }, {});
    });
    var cand = Object.keys(ids || {}).sort();
    if (!R.tears) return cand;
    var tornKey = Object.keys(torn).sort().join('|');
    return cand.filter(function (id) {
      var options = per.map(function (list) {
        var seen = {};
        return list.filter(function (c) { if (c.id !== id || seen[c.ck]) return false; seen[c.ck] = true; return true; });
      });
      var found = false;
      (function rec(i, acc) {
        if (found) return;
        if (i === options.length) { if (Object.keys(acc).sort().join('|') === tornKey) found = true; return; }
        for (var j = 0; j < options[i].length; j++) {
          var next = Object.assign({}, acc);
          options[i][j].cloths.forEach(function (c) { next[c[0] + ',' + c[1]] = true; });
          rec(i + 1, next);
        }
      })(0, {});
      return found;
    });
  }

  /* Closest approach of a path to any solid-tile corner (legibility: a string must visibly clear or visibly hit). */
  function closestGraze(g, segs) {
    var best = Infinity;
    for (var i = 0; i < segs.length; i++) {
      var a = segs[i].from, b = segs[i].to;
      var vx = b[0] - a[0], vy = b[1] - a[1], vv = vx * vx + vy * vy;
      if (vv === 0) continue;
      var minx = Math.floor(Math.min(a[0], b[0])) - 1, maxx = Math.ceil(Math.max(a[0], b[0])) + 1;
      var miny = Math.floor(Math.min(a[1], b[1])) - 1, maxy = Math.ceil(Math.max(a[1], b[1])) + 1;
      for (var y = miny; y <= maxy; y++) for (var x = minx; x <= maxx; x++) {
        if (!SOLID[matAt(g, x, y)]) continue;
        var cs = [[x, y], [x + 1, y], [x, y + 1], [x + 1, y + 1]];
        for (var k = 0; k < 4; k++) {
          var t = ((cs[k][0] - a[0]) * vx + (cs[k][1] - a[1]) * vy) / vv;
          if (t <= 0.02 || t >= 0.98) continue;
          var qx = a[0] + t * vx - cs[k][0], qy = a[1] + t * vy - cs[k][1];
          var dd = Math.sqrt(qx * qx + qy * qy);
          if (dd < best) best = dd;
        }
      }
    }
    return best;
  }

  var API = {
    DIRS: DIRS, MAT: MAT, SOLID: SOLID, ANG: ANG, ANG_NAME: ANG_NAME, MAX_LEN: MAX_LEN, MAX_WRAPS: MAX_WRAPS, BANDS: BANDS,
    RULES: RULES, ablate: ablate, trueFwd: trueFwd, truePre: truePre, GLANCE: GLANCE, leave: leave, sgn: sgn,
    makeGrid: makeGrid, withFurniture: withFurniture, charAt: charAt, matAt: matAt, regionAt: regionAt,
    cast: cast, reflect: reflect, angleClass: angleClass, dlen: dlen, band: band, bandOf: bandOf,
    fly: fly, traceBack: traceBack, stringPath: stringPath, solve: solve, tornSet: tornSet, closestGraze: closestGraze,
    leavingDirs: leavingDirs, judgeString: judgeString
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  else root.SL_TRACE = API;
})(typeof window !== 'undefined' ? window : this);
