/* sound.js - STRINGLINE's sound. Two arrangements of one theme (the STUDY: casebook and title; the HALL: a case in
 * progress), rendered to the SAME length so they crossfade in step; nine cues; and the TWANG - a plucked-string note
 * synthesised live whose pitch follows the string's length (a short string sings high, a long one low).
 * Two backends (Wings/Games/CLAUDE.md §8a rule 2, §2a): on http(s) gapless AudioBufferSourceNodes; on file:// (the paid
 * Windows download, where fetch cannot read a file at all) bare <audio> elements OUT of the WebAudio graph, volume
 * driven directly. The twang is an oscillator and works on both. Nothing plays before the first press (autoplay).
 * Every cue is gated on ITS OWN buffer and a running context, never on the music being ready (§8a rule 4). */
(function (root) {
  'use strict';
  var MUSIC = ['mus_study', 'mus_hall'];
  var CUES = ['sfx_catch', 'sfx_unwind', 'sfx_select', 'sfx_ui', 'sfx_candle', 'sfx_gavel', 'sfx_seal', 'sfx_cold', 'sfx_page'];
  var IS_FILE = location.protocol === 'file:';
  var MUSIC_VOL = 0.5;
  function Sound() {
    this.muted = false; try { this.muted = localStorage.getItem('stringline.muted') === '1'; } catch (e) { /* storage refused */ }
    this.ctx = null; this.buffers = {}; this.els = {}; this.pool = {}; this.gains = {}; this.sources = {};
    this.started = false; this.errors = []; this.weights = [1, 0]; this.mood = 0; this.cueCount = 0; this.twangCount = 0;
    this.loaded = { music: 0, cues: 0 };
  }
  Sound.prototype.load = function () {
    var self = this;
    try { this.ctx = new (root.AudioContext || root.webkitAudioContext)(); this.master = this.ctx.createGain(); this.master.gain.value = this.muted ? 0 : 1; this.master.connect(this.ctx.destination); } catch (e) { this.errors.push('no AudioContext: ' + e.message); }
    if (IS_FILE || !this.ctx) {
      MUSIC.forEach(function (n) { var el = new Audio('audio/' + n + '.ogg'); el.loop = true; el.preload = 'auto'; el.volume = 0; el.addEventListener('canplaythrough', function () { self.loaded.music++; }, { once: true }); el.addEventListener('error', function () { self.errors.push(n + '.ogg failed'); }); self.els[n] = el; });
      CUES.forEach(function (n) { self.pool[n] = [0, 1, 2].map(function () { var el = new Audio('audio/' + n + '.ogg'); el.preload = 'auto'; return el; }); self.pool[n][0].addEventListener('canplaythrough', function () { self.loaded.cues++; }, { once: true }); });
      return;
    }
    MUSIC.concat(CUES).forEach(function (n) {
      fetch('audio/' + n + '.ogg').then(function (r) { if (!r.ok) throw new Error(n + '.ogg ' + r.status); return r.arrayBuffer(); })
        .then(function (ab) { return new Promise(function (res, rej) { self.ctx.decodeAudioData(ab, res, rej); }); })
        .then(function (buf) { self.buffers[n] = buf; if (MUSIC.indexOf(n) >= 0) self.loaded.music++; else self.loaded.cues++; if (self.started && MUSIC.indexOf(n) >= 0) self._startTrack(n); })
        .catch(function (e) { self.errors.push(String(e.message || e)); });
    });
  };
  Sound.prototype.unlock = function () {
    if (this.started) return; this.started = true;
    var self = this;
    if (this.ctx && this.ctx.state !== 'running') this.ctx.resume().catch(function (e) { self.errors.push('resume refused: ' + e.message); });
    if (IS_FILE || !this.ctx) {
      MUSIC.forEach(function (n, i) { var el = self.els[n]; el.volume = self.muted ? 0 : self.weights[i] * MUSIC_VOL; var p = el.play(); if (p && p.catch) p.catch(function (e) { self.errors.push('autoplay denied: ' + e.message); }); });
    } else MUSIC.forEach(function (n) { if (self.buffers[n]) self._startTrack(n); });
  };
  Sound.prototype._startTrack = function (n) {
    if (this.sources[n]) return;
    var i = MUSIC.indexOf(n), gn = this.ctx.createGain(); gn.gain.value = this.weights[i] * MUSIC_VOL; gn.connect(this.master);
    if (this.t0 == null) this.t0 = this.ctx.currentTime + 0.05;
    var src = this.ctx.createBufferSource(); src.buffer = this.buffers[n]; src.loop = true; src.connect(gn);
    var len = this.buffers[n].duration, off = Math.max(0, this.ctx.currentTime - this.t0) % len;
    src.start(this.ctx.currentTime + 0.02, off); this.sources[n] = src; this.gains[n] = gn;
  };
  /* mood 0 = the study, 1 = the hall */
  Sound.prototype.setMood = function (m) {
    this.mood = m; this.weights = [1 - m, m];
    var self = this;
    MUSIC.forEach(function (n, i) {
      var v = self.muted ? 0 : self.weights[i] * MUSIC_VOL;
      if (self.gains[n]) self.gains[n].gain.setTargetAtTime(v, self.ctx.currentTime, 0.8);
      if (self.els[n] && self.started) self.els[n].volume = Math.max(0, Math.min(1, v));
    });
  };
  Sound.prototype.cue = function (n, gain) {
    if (this.muted) return false;
    if (IS_FILE || !this.ctx) { var els = this.pool[n]; if (!els) return false; var el = els.find(function (e) { return e.paused || e.ended; }) || els[0]; try { el.currentTime = 0; } catch (e) { /* not seekable yet */ } el.volume = Math.min(1, gain || 0.8); var p = el.play(); if (p && p.catch) p.catch(function () {}); this.cueCount++; return true; }
    var b = this.buffers[n]; if (!b || this.ctx.state !== 'running') return false;
    var s = this.ctx.createBufferSource(), gn = this.ctx.createGain(); gn.gain.value = gain || 0.8; s.buffer = b; s.connect(gn); gn.connect(this.master); s.start(); this.cueCount++; return true;
  };
  /* the twang: a plucked string, pitch from its length in paces (1 pace ~ G5, 21 paces ~ G2), on D dorian */
  var SCALE = [0, 2, 3, 5, 7, 9, 10];
  Sound.prototype.twang = function (paces) {
    if (this.muted || !this.ctx || this.ctx.state !== 'running') return false;
    var k = Math.max(0, Math.min(20, Math.round(21 - paces))), oct = Math.floor(k / 7), semis = SCALE[k % 7] + 12 * oct;
    var f = 98 * Math.pow(2, (2 + semis) / 12);
    var t = this.ctx.currentTime, o = this.ctx.createOscillator(), o2 = this.ctx.createOscillator(), gn = this.ctx.createGain(), lp = this.ctx.createBiquadFilter();
    o.type = 'triangle'; o.frequency.value = f; o2.type = 'sawtooth'; o2.frequency.value = f * 1.003;
    lp.type = 'lowpass'; lp.frequency.setValueAtTime(3200, t); lp.frequency.exponentialRampToValueAtTime(500, t + 0.5);
    gn.gain.setValueAtTime(0.0001, t); gn.gain.exponentialRampToValueAtTime(0.14, t + 0.006); gn.gain.exponentialRampToValueAtTime(0.0001, t + 0.9);
    var g2 = this.ctx.createGain(); g2.gain.value = 0.22; o2.connect(g2); g2.connect(lp); o.connect(lp); lp.connect(gn); gn.connect(this.master);
    o.start(t); o2.start(t); o.stop(t + 1); o2.stop(t + 1); this.twangCount++; return true;
  };
  Sound.prototype.setMuted = function (on) {
    this.muted = !!on; try { localStorage.setItem('stringline.muted', on ? '1' : '0'); } catch (e) { /* ignore */ }
    if (this.master) this.master.gain.value = on ? 0 : 1;
    this.setMood(this.mood);
    return this.muted;
  };
  Sound.prototype.toggleMute = function () { return this.setMuted(!this.muted); };
  Sound.prototype.report = function () {
    return { backend: IS_FILE || !this.ctx ? 'media-element' : 'webaudio', ctx: this.ctx ? this.ctx.state : 'none', started: this.started, muted: this.muted,
      loaded: this.loaded, want: { music: MUSIC.length, cues: CUES.length }, weights: this.weights.map(function (x) { return +x.toFixed(3); }), cues: this.cueCount, twangs: this.twangCount, errors: this.errors.slice() };
  };
  root.SL_SOUND = new Sound();
  root.SL_SOUND.MUSIC = MUSIC; root.SL_SOUND.CUES = CUES;
})(window);
