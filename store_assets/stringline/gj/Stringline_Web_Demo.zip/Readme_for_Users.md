# Stringline

A castle whodunit where every clue is a line you draw. Crossbow bolts are stuck in the walls of Castle Harrowgate.
Pull a red string back from each one, bend it where you think the bolt glanced off stone or iron, and find the one
place every string can end: that is where the archer stood.

There are two editions on the same page:

- **The free browser demo**: the first 3 of the 15 cases, in the Great Hall.
- **The Windows download**: all 15 cases across the Great Hall, the Chapel of Saint Orm and the Gatehouse, two more
  rules to learn, and the ending.

## How to play

- **Pull a string**: press on a bolt and drag. The string runs back along the bolt's shaft.
- **Bend it**: pull past a wall, pillar or piece of iron and the string catches there. Swing the mouse around the pin
  to choose the bend. Pull straight back down the string to take the pin out again.
- **Read the chalk**: at every bend the chalk numbers give the angle of each side: 1 low, 2 diagonal, 3 steep,
  4 square on. A dark knot marks every pace on the string and a pale bead every fifth.
- **Call the hearing** when every string ends in the same chalk-outlined place. The court checks your strings against
  the rules. A broken rule burns one of your three candles; lose all three and the case goes cold (you can reopen it).
- A clean seal means no candle burned.

The rules are taught one at a time in the casebook: stone, depth, iron and cloth. A bolt flies at most 21 paces and
glances at most three times, and wood holds every bolt.

### Keys

1 to 3 or TAB pick a bolt · W/S or UP/DOWN pull and let out · A/D or LEFT/RIGHT swing a bend · R take a string down ·
ENTER call the hearing · H rules · ESC menu · M sound on or off.

The game saves your seals as you go.

## Requirements

The demo runs in any modern browser with a mouse or a keyboard (touch works for dragging). The download is a
portable Windows program: run the .exe, nothing is installed.

## More from CSAF

Other games and tools by Core Systems Asset Factory: https://csaf.itch.io (including Linguist of the Deep, a game
about learning an alien language underwater).

## Credits

A game by Core Systems Asset Factory (CSAF).

- The halls are built from three CSAF tilesets: **Verdant 07 · Interiors**, **Verdant 13 · Castle** and
  **Verdant 15 · Palace**.
- Lettering drawn by CSAF. Music and sound synthesised by CSAF from note data; no samples.
- **Made with AI:** the code, art and words of this game were written with generative AI assistance.
  The music and sound are procedural synthesis, not generative audio.

© 2026 Core Systems Asset Factory. See LICENSE.txt.
