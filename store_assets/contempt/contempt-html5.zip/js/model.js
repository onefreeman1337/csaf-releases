/* CONTEMPT — model.js
 *
 * THE WHOLE TRIAL, AS PURE ARITHMETIC. No DOM, no canvas, no audio, no timers. `game.js` renders
 * this and `Internal_Ops/harness.js` plays it headless, so the thing that is BALANCED is the same
 * object that is SHIPPED — master §2b records a wing whose balance gate certified a fight the
 * player could never lose because the harness and the game had drifted apart.
 *
 * ⛔ THE TWO SYSTEMS, AND WHY THEY ARE ONE GAME (wing gate 4). The LEGAL system is an evidence
 *    economy: objections are typed parries that pay evidence, evidence buys presses, presses move
 *    the verdict. The CONTEMPT system is a loan: STRIKE always works, costs nothing you have, and
 *    charges a point of judicial patience — and patience is only repaid by a run of clean legal
 *    play. So the strike is not a second button, it is a debt instrument denominated in the first
 *    system's currency, and that is the interaction the floor asks for.
 *
 * ⛔ EVERY TIMING NUMBER IS IN TICKS AT EXACTLY 60/s AND NOTHING HERE READS A CLOCK. A model that
 *    reads wall time cannot be swept, and a sweep is the only way an agent that cannot play the
 *    game can know whether it is fair (§0z).
 */
'use strict';

(function (root, factory) {
  const M = factory();
  if (typeof module === 'object' && module.exports) module.exports = M;
  else root.CONTEMPT_MODEL = M;
}(typeof self !== 'undefined' ? self : this, function () {

  const TPS = 60;

  /* ------------------------------------------------------------------ deterministic randomness
   * ⛔ Math.random() would make every sweep unrepeatable and every bug report unreproducible.
   * mulberry32: 32-bit state, uniform enough for choosing an argument class. */
  function rng(seed) {
    let a = (seed >>> 0) || 1;
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /* ----------------------------------------------------------------------- objection classes
   * The class is the whole parry. A correctly TIMED objection of the WRONG class is overruled, so
   * the player is reading two things at once (which tell, and when) rather than mashing one key. */
  const CLASSES = [
    { id: 'HEARSAY', key: '1', label: 'Hearsay', hue: 196,
      tell: 'the witness is quoting someone who is not here' },
    { id: 'SPECULATION', key: '2', label: 'Speculation', hue: 276,
      tell: 'they are asking the witness to guess' },
    { id: 'RELEVANCE', key: '3', label: 'Relevance', hue: 36,
      tell: 'this has nothing to do with the charge' },
    { id: 'LEADING', key: '4', label: 'Leading', hue: 128,
      tell: 'the question contains its own answer' },
  ];
  const CLASS_INDEX = {};
  CLASSES.forEach(function (c, i) { CLASS_INDEX[c.id] = i; });

  /* --------------------------------------------------------------------------------- the cases
   * Five opponents. Each one adds ONE new thing rather than raising a number, so the difficulty
   * curve is knowledge rather than stats — a beginner who learns feints beats case 2 forever.
   *
   * classes      how many objection types this opponent can raise (unlock pacing)
   * windup       telegraph length in ticks
   * window       how many of the LAST telegraph ticks accept an objection
   * gap          ticks between arguments
   * dmg/comp     verdict and composure damage of an unanswered argument
   * feint        chance an argument evaporates instead of resolving (objecting to it is overruled)
   * compound     chance an argument carries a SECOND class that must be objected to as well
   * bait         chance an argument is contempt bait (striking it costs 2 patience, not 1)
   * drift        VERDICT LOST PER SECOND simply by letting the trial run on — see below
   *
   * ⛔⛔ `drift` EXISTS BECAUSE THE FIRST TWO SWEEPS READ 100% FOR THE EXPERT ON ALL FIVE CASES,
   *    AND THE SECOND ONE READ 100% *AFTER* GIVING THAT EXPERT A HUMAN REACTION TIME. Diagnosed
   *    rather than tuned: at case 5 the expert was taking 5 unanswered arguments and 5 overrulings
   *    a bout (-80 verdict) and still finishing +104, because it also landed 21 PRESSES in the
   *    gaps. Pressing was free money, so the whole design — the windows, the feints, the compound
   *    arguments — was competing against an income stream none of it touched. Drift is the burden
   *    of proof: the jury slides toward the prosecution unless you actively hold it, so a player
   *    must generate a positive RATE rather than a positive total, and a long stalemate is a loss
   *    on its own. It is the one dial that scales with the length of the bout, which is exactly
   *    the quantity the expert was exploiting. */
  const CASES = [
    { id: 1, foe: 'foe1_intern', name: 'The Intern',
      blurb: 'Two years out of law school and reading from a folder. He telegraphs everything.',
      classes: 2, windup: 118, window: 46, gap: 70, dmg: 10, comp: 11, drift: 1.60,
      feint: 0, compound: 0, bait: 0, composure: 100 },
    { id: 2, foe: 'foe2_counsel', name: 'Corporate Counsel',
      blurb: 'Bills more per hour than you make in a week. Half of what he starts, he never finishes.',
      classes: 3, windup: 104, window: 40, gap: 66, dmg: 8, comp: 10, drift: 1.15,
      feint: 0.28, compound: 0, bait: 0, composure: 115 },
    { id: 3, foe: 'foe3_firebrand', name: 'The Firebrand',
      blurb: 'Fast, loud, and happy to be shouted at. Standing back will not save you from her.',
      classes: 3, windup: 88, window: 32, gap: 54, dmg: 10, comp: 12, drift: 2.95,
      feint: 0.30, compound: 0.34, bait: 0, composure: 125 },
    { id: 4, foe: 'foe4_oldbull', name: 'The Old Bull',
      blurb: 'Thirty years at this bench. He builds arguments in pairs and waits for you to swing.',
      classes: 4, windup: 96, window: 34, gap: 58, dmg: 11, comp: 13, drift: 2.75,
      feint: 0.28, compound: 0.42, bait: 0.22, composure: 150 },
    { id: 5, foe: 'foe5_champion', name: "The State's Champion",
      blurb: 'Never lost a case. Never raised his voice. He is counting your contempt for you.',
      classes: 4, windup: 84, window: 30, gap: 48, dmg: 12, comp: 14, drift: 2.65,
      feint: 0.34, compound: 0.46, bait: 0.34, composure: 170 },
  ];

  /* ------------------------------------------------------------------------------- precedents
   * Won between cases, kept forever, chosen 3-from-the-pool. They are deliberately RULE changes
   * rather than +5%s: a percentage is a number the player cannot feel, and the operator's own
   * complaint about this wing was that its games were "a bit simplistic". */
  const PRECEDENTS = [
    { id: 'leading_question', name: 'Leading Question',
      text: 'Your press also shakes them: -5 composure on every point you land.' },
    { id: 'sidebar', name: 'Sidebar',
      text: 'The judge cools off with time: one contempt forgiven every 18 seconds.' },
    { id: 'continuance', name: 'Continuance',
      text: 'A mistrial no longer wipes the record: you restart the case at half your verdict.' },
    { id: 'impeachment', name: 'Impeachment',
      text: 'Objections landed while they are reeling are worth double.' },
    { id: 'sustained_motion', name: 'Sustained Motion',
      text: 'You may hold seven pieces of evidence instead of five.' },
    { id: 'chain_of_custody', name: 'Chain of Custody',
      text: 'Evidence comes in faster: one every four seconds instead of seven.' },
    { id: 'bad_faith', name: 'Bad Faith',
      text: 'Being overruled costs half as much and half the silence.' },
    { id: 'bench_warrant', name: 'Bench Warrant',
      text: 'When you strike, they stay down twice as long.' },
  ];
  const PRECEDENT_INDEX = {};
  PRECEDENTS.forEach(function (p) { PRECEDENT_INDEX[p.id] = p; });

  /* ----------------------------------------------------------------------------- the constants
   * Named, in one place, because a sweep that cannot name what it moved is a sweep nobody can
   * reproduce. Tuned values are recorded in Internal_Ops/balance_gate.js with their bands. */
  const K = {
    verdictWin: 100,
    objectGain: 7, objectComposure: 15,
    overruledCost: 4, overruledLock: 46,
    pressWindup: 26, pressGain: 6, pressComposure: 8,
    /* ⛔ strikeCooldown WAS 66 (1.1s) AND IT MADE THE SECOND SYSTEM A TRAP RATHER THAN A CHOICE.
     * MEASURED at n=40 on the first full sweep: the beginner model lost 33-40 of 40 bouts to
     * CONTEMPT rather than to the verdict on every case, because three strikes fit inside 3.3
     * seconds and the patience debt could not be repaid inside that. A loan you cannot service is
     * not a risk/reward dial, it is a hidden fail button. 150 ticks (2.5s) plus a cheaper
     * repayment below gives a strike a real runway. */
    strikeGain: 11, strikeComposure: 26, strikeStagger: 84, strikeCooldown: 150,
    staggerOnBreak: 120, breakRecover: 0.6,
    flusteredLock: 84, flusteredCost: 10,
    evidenceStart: 2, evidenceCap: 5, evidenceEvery: 10 * TPS,
    cleanForPatience: 2, contemptLimit: 3,
    timeLimit: 150 * TPS,
    leanInPress: 1.6, leanInTake: 1.5, leanInWindow: 0.8,
    leanOutPress: 0.6, leanOutTake: 0.6, leanOutWindow: 1.25,
    staggerPress: 1.5,
    compoundGap: 30,
  };

  /* ------------------------------------------------------------------------------ bout creation */
  function createBout(opts) {
    opts = opts || {};
    const caseIndex = Math.max(0, Math.min(CASES.length - 1, opts.caseIndex | 0));
    const spec = CASES[caseIndex];
    const precedents = (opts.precedents || []).slice();
    const has = function (id) { return precedents.indexOf(id) >= 0; };

    const s = {
      tick: 0,
      caseIndex: caseIndex,
      spec: spec,
      rand: rng((opts.seed | 0) || 12345),
      precedents: precedents,
      has: has,

      verdict: opts.startVerdict || 0,
      contempt: 0,
      clean: 0,
      evidence: K.evidenceStart,
      evidenceT: 0,
      strikeCd: 0,

      you: { composure: 100, max: 100, lock: 0, pressT: 0, lean: 0, flash: 0 },
      foe: { composure: spec.composure, max: spec.composure, stagger: 0, flash: 0 },

      arg: null,          /* the argument in flight, or null while they draw breath */
      argWait: 90,        /* ticks until the next argument begins */
      over: null,         /* null | 'win' | 'verdict' | 'contempt' */
      events: [],
      stats: { objected: 0, overruled: 0, pressed: 0, struck: 0, taken: 0, feintsBaited: 0 },
    };
    s.evidenceMax = has('sustained_motion') ? 7 : K.evidenceCap;
    s.evidenceEvery = has('chain_of_custody') ? 6 * TPS : K.evidenceEvery;
    return s;
  }

  function emit(s, type, extra) {
    const e = { type: type, tick: s.tick };
    if (extra) for (const k in extra) e[k] = extra[k];
    s.events.push(e);
    return e;
  }

  /* --------------------------------------------------------------------------- argument drawing */
  function drawArgument(s) {
    const spec = s.spec;
    const n = spec.classes;
    const first = CLASSES[Math.floor(s.rand() * n)].id;
    const a = {
      cls: first,
      second: null,
      t: 0,
      windup: spec.windup,
      window: spec.window,
      feint: s.rand() < spec.feint,
      bait: s.rand() < spec.bait,
      phase: 'draw',       /* draw -> (second) -> resolved */
      answered: 0,
      parts: 1,
    };
    if (s.rand() < spec.compound) {
      let other = CLASSES[Math.floor(s.rand() * n)].id;
      if (other === first) other = CLASSES[(CLASS_INDEX[first] + 1) % n].id;
      a.second = other;
      a.parts = 2;
      a.feint = false; /* a compound feint is unreadable; two mechanics stacked is noise, not depth */
    }
    return a;
  }

  /* ------------------------------------------------------------------------------ helper: window
   * The parry window is the LAST `window` ticks of the telegraph, stretched or squeezed by stance.
   * Leaning in is a real trade: more damage out, less time to read. */
  function windowFor(s, a) {
    let w = a.window;
    if (s.you.lean > 0) w *= K.leanInWindow;
    else if (s.you.lean < 0) w *= K.leanOutWindow;
    return w;
  }
  function inWindow(s, a) {
    return a.phase !== 'resolved' && a.t >= a.windup - windowFor(s, a) && a.t <= a.windup;
  }

  function payPatience(s) {
    s.clean += 1;
    if (s.clean >= K.cleanForPatience && s.contempt > 0) {
      s.contempt -= 1;
      s.clean -= K.cleanForPatience;
      emit(s, 'patience');
    }
  }

  function damageFoe(s, amount) {
    s.foe.composure -= amount;
    s.foe.flash = 8;
    if (s.foe.composure <= 0) {
      s.foe.composure = s.foe.max * K.breakRecover;
      s.foe.stagger = K.staggerOnBreak;
      s.arg = null;
      emit(s, 'break');
    }
  }

  function moveVerdict(s, d) {
    s.verdict = Math.max(-K.verdictWin, Math.min(K.verdictWin, s.verdict + d));
    if (s.verdict >= K.verdictWin) { s.over = 'win'; emit(s, 'win'); }
    else if (s.verdict <= -K.verdictWin) { s.over = 'verdict'; emit(s, 'lose', { how: 'verdict' }); }
  }

  /* ------------------------------------------------------------------------------ player actions */
  function object(s, clsId) {
    if (s.over || s.you.lock > 0 || s.you.pressT > 0) return;
    const a = s.arg;
    s.stats.objected++;
    const wantedNow = a && !a.feint
      && (a.phase === 'draw' ? a.cls : a.second)
      === clsId && inWindow(s, a);

    if (!a || a.feint || !inWindow(s, a) || !wantedNow) {
      /* OVERRULED. Includes the feint, which is the whole point of the feint. */
      const half = s.has('bad_faith') ? 0.5 : 1;
      s.stats.overruled++;
      if (a && a.feint && inWindow(s, a)) s.stats.feintsBaited++;
      s.you.lock = Math.round(K.overruledLock * half);
      /* ⚠️ AN OVERRULING COSTS ONE STEP OF PATIENCE PROGRESS, NOT ALL OF IT. Zeroing it here was
       * measured to make the contempt system a beginner-killer rather than a choice: a player who
       * is often overruled could NEVER repay a strike, so 33-40 of every 40 beginner losses were
       * ejections. The judge is annoyed, not enraged. */
      s.clean = Math.max(0, s.clean - 1);
      moveVerdict(s, -K.overruledCost * half);
      emit(s, 'overruled');
      return;
    }

    /* SUSTAINED. */
    let gain = K.objectGain;
    if (s.has('impeachment') && s.foe.stagger > 0) gain *= 2;
    a.answered++;
    if (a.second && a.phase === 'draw') {
      /* half a compound answered: the second half still has to be read */
      a.phase = 'second';
      a.cls = a.second;
      a.second = null;
      a.t = Math.max(0, a.windup - K.compoundGap - a.window);
      gain *= 0.6;
    } else {
      s.arg = null;
      s.argWait = s.spec.gap;
    }
    s.evidence = Math.min(s.evidenceMax, s.evidence + 1);
    damageFoe(s, K.objectComposure);
    payPatience(s);
    moveVerdict(s, gain);
    emit(s, 'sustained', { gain: gain });
  }

  function press(s) {
    if (s.over || s.you.lock > 0 || s.you.pressT > 0) return;
    if (s.evidence < 1) { emit(s, 'noEvidence'); return; }
    s.evidence -= 1;
    s.you.pressT = K.pressWindup;
    s.stats.pressed++;
    emit(s, 'pressStart');
  }

  function resolvePress(s) {
    let gain = K.pressGain;
    if (s.you.lean > 0) gain *= K.leanInPress;
    else if (s.you.lean < 0) gain *= K.leanOutPress;
    if (s.foe.stagger > 0) gain *= K.staggerPress;
    let comp = K.pressComposure + (s.has('leading_question') ? 5 : 0);
    damageFoe(s, comp);
    payPatience(s);
    moveVerdict(s, gain);
    emit(s, 'press', { gain: gain });
  }

  function strike(s) {
    if (s.over || s.strikeCd > 0 || s.you.lock > 0) return;
    const bait = !!(s.arg && s.arg.bait);
    s.strikeCd = K.strikeCooldown;
    s.you.pressT = 0;
    s.stats.struck++;
    s.foe.stagger = Math.max(s.foe.stagger, K.strikeStagger * (s.has('bench_warrant') ? 2 : 1));
    s.arg = null;
    s.argWait = s.spec.gap;
    damageFoe(s, K.strikeComposure);
    s.contempt += bait ? 2 : 1;
    /* ⚠️ ONE STEP OF PROGRESS, NOT ALL OF IT — the same lesson as the overruling above. Zeroing it
     * here charged a strike TWICE (a patience point AND the runway to repay it), and the sweep
     * read it as 97-100% of all beginner losses being ejections. */
    s.clean = Math.max(0, s.clean - 1);
    moveVerdict(s, K.strikeGain);
    emit(s, 'strike', { bait: bait });
    if (s.contempt >= K.contemptLimit && !s.over) {
      s.contempt = K.contemptLimit;
      s.over = 'contempt';
      emit(s, 'lose', { how: 'contempt' });
    }
  }

  /* ---------------------------------------------------------------------------------- the tick
   * ⛔ ONE fixed step. `game.js` accumulates real time and calls this a whole number of times, so a
   * slow frame changes how SMOOTH the game is and never what it DOES. */
  function step(s, input) {
    if (s.over) return s.events.splice(0);
    input = input || {};
    s.tick++;

    /* THE BURDEN OF PROOF, AND THE JURY'S MEMORY. Applied before anything the player does, so the
     * number they see is always the number they have to beat.
     *
     * ⛔⛔ THE MULTIPLIER IS NOT A FLOURISH — IT IS WHAT STOPS EVERY HARD CASE ENDING ON THE CLOCK.
     *    MEASURED at n=120 with FLAT drift: case 5 read a healthy-looking 65.8% expert win rate
     *    with a median bout of 150.0s, which is the jury clock EXACTLY — i.e. nearly every trial
     *    was a grind to time rather than a case won or lost, and case 4 was heading the same way at
     *    113s. That is what a pure tug-of-war equilibrium looks like, and raising drift only moves
     *    which side the stalemate settles on. A jury that has started to believe you takes less
     *    convincing, and one that has stopped believing you takes more: the lead compounds, so
     *    bouts END. Clamped at both ends so neither a runaway nor a total stall is possible. */
    if (s.spec.drift) {
      const lean = 1 - 0.85 * (s.verdict / K.verdictWin);
      const d = s.spec.drift * Math.max(0.15, Math.min(1.85, lean));
      s.verdict = Math.max(-K.verdictWin, s.verdict - d / TPS);
      if (s.verdict <= -K.verdictWin && !s.over) { s.over = 'verdict'; emit(s, 'lose', { how: 'verdict' }); }
    }

    /* ⛔ THE JURY RETURNS. A trial that never ends is not a stalemate the PLAYER should sit in —
     * itch's own median session is minutes, and a bout with no clock lets a cautious line grind
     * forever. At the limit whoever is ahead wins, and a dead-level board goes to the prosecution
     * because the burden of proof is yours. The harness's own ceiling sits ABOVE this one, so a
     * timeout THERE means a model hung, not that a trial ran long. */
    if (s.tick >= K.timeLimit && !s.over) {
      s.byDecision = true;
      if (s.verdict > 0) { s.over = 'win'; emit(s, 'win', { byDecision: true }); }
      else { s.over = 'verdict'; emit(s, 'lose', { how: 'verdict', byDecision: true }); }
      return s.events.splice(0);
    }

    s.you.lean = input.lean === 1 ? 1 : input.lean === -1 ? -1 : 0;
    if (s.you.lock > 0) s.you.lock--;
    if (s.strikeCd > 0) s.strikeCd--;
    if (s.you.flash > 0) s.you.flash--;
    if (s.foe.flash > 0) s.foe.flash--;

    /* evidence trickles back so a player who runs dry is never stuck, only slowed */
    if (s.evidence < s.evidenceMax) {
      s.evidenceT++;
      if (s.evidenceT >= s.evidenceEvery) { s.evidenceT = 0; s.evidence++; emit(s, 'evidence'); }
    } else s.evidenceT = 0;

    if (s.has('sidebar') && s.contempt > 0 && s.tick % (18 * TPS) === 0) {
      s.contempt--; emit(s, 'patience');
    }

    /* player's press resolves on its own clock; being hit does not cancel it, standing in it does */
    if (s.you.pressT > 0) {
      s.you.pressT--;
      if (s.you.pressT === 0) resolvePress(s);
    }

    /* inputs are edge-triggered by the caller: one flag, one action */
    if (input.object != null) object(s, input.object);
    if (input.press) press(s);
    if (input.strike) strike(s);
    if (s.over) return s.events.splice(0);

    /* the opponent */
    if (s.foe.stagger > 0) {
      s.foe.stagger--;
      s.arg = null;
      s.argWait = Math.max(s.argWait, 24);
    } else if (!s.arg) {
      s.argWait--;
      if (s.argWait <= 0) { s.arg = drawArgument(s); emit(s, 'argument', { cls: s.arg.cls }); }
    } else {
      const a = s.arg;
      a.t++;
      if (a.t > a.windup) {
        if (a.feint) {
          emit(s, 'feint');
        } else {
          let dmg = s.spec.dmg, comp = s.spec.comp;
          if (a.parts === 2 && a.answered > 0) { dmg *= 0.5; comp *= 0.5; }
          if (s.you.lean > 0) { dmg *= K.leanInTake; comp *= K.leanInTake; }
          else if (s.you.lean < 0) { dmg *= K.leanOutTake; comp *= K.leanOutTake; }
          s.stats.taken++;
          s.you.composure -= comp;
          s.you.flash = 8;
          moveVerdict(s, -dmg);
          emit(s, 'hit', { dmg: dmg });
          if (s.you.composure <= 0 && !s.over) {
            s.you.composure = s.you.max * K.breakRecover;
            s.you.lock = K.flusteredLock;
            moveVerdict(s, -K.flusteredCost);
            emit(s, 'flustered');
          }
        }
        s.arg = null;
        s.argWait = s.spec.gap;
      }
    }
    return s.events.splice(0);
  }

  /* --------------------------------------------------------------------------- view projection
   * Everything `game.js` needs to draw a frame, and nothing it can write back. Keeping the render
   * read-only against the model is what stops a drawing bug becoming a rules bug. */
  function view(s) {
    const a = s.arg;
    return {
      tick: s.tick,
      verdict: s.verdict,
      verdictWin: K.verdictWin,
      contempt: s.contempt,
      contemptLimit: K.contemptLimit,
      clean: s.clean,
      cleanFor: K.cleanForPatience,
      evidence: s.evidence,
      evidenceMax: s.evidenceMax,
      you: { composure: Math.max(0, s.you.composure), max: s.you.max, lock: s.you.lock,
        press: s.you.pressT, pressMax: K.pressWindup, lean: s.you.lean, flash: s.you.flash },
      foe: { composure: Math.max(0, s.foe.composure), max: s.foe.max,
        stagger: s.foe.stagger, flash: s.foe.flash },
      strikeCd: s.strikeCd, strikeCdMax: K.strikeCooldown,
      arg: a ? {
        cls: a.cls, second: a.second, t: a.t, windup: a.windup,
        window: windowFor(s, a), open: inWindow(s, a), parts: a.parts,
        answered: a.answered, bait: a.bait,
        /* ⭐ THE FEINT HAS A TELL, AND THAT IS A DESIGN DECISION, NOT A LEAK. Without one, a feint
         * is a coin toss the player cannot play around, and case 2 would be 28% unavoidable
         * punishment — the kind of "difficulty" that is really just noise. Revealing it at 72% of
         * the telegraph makes it a REACTION test: the objection window is already open when the
         * argument starts to waver, so the skill is pulling your hand back, not guessing. The
         * renderer draws this as the tell losing its nerve. */
        waver: !!(a.feint && a.t > a.windup * 0.72),
      } : null,
      over: s.over,
      spec: { id: s.spec.id, name: s.spec.name, foe: s.spec.foe, classes: s.spec.classes },
    };
  }

  return {
    TPS: TPS, K: K, CLASSES: CLASSES, CASES: CASES, PRECEDENTS: PRECEDENTS,
    PRECEDENT_INDEX: PRECEDENT_INDEX,
    createBout: createBout, step: step, view: view, rng: rng,
    /* exported for the harness and the balance gate only */
    _internals: { object: object, press: press, strike: strike, drawArgument: drawArgument,
      inWindow: inWindow, windowFor: windowFor },
  };
}));
