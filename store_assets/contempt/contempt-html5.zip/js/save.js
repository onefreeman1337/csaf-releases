/* save.js — generated from Wings/GamesLite/Kit/save_kit.js. Edit the KIT, not this copy.
 *
 * Save/resume is a standing design law for this wing (operator ledger B4): death returns the
 * player to a meaningful checkpoint with progress kept, never a full restart.
 *
 * Every refusal is NAMED. A bare null cannot tell a hostile input from a version skew from a
 * defect in this function, and a guard that fails closed imitates exactly the condition it
 * exists for.
 */
'use strict';

function makeSave(key, version, validate) {
  var lastRefusal = null;

  function write(state) {
    try {
      window.localStorage.setItem(key, JSON.stringify({ v: version, at: Date.now(), state: state }));
      return true;
    } catch (e) {
      /* Private browsing, a full quota, or a blocked origin. Never interrupt play. */
      lastRefusal = 'write-failed:' + (e && e.name ? e.name : 'unknown');
      return false;
    }
  }

  function read() {
    lastRefusal = null;
    var raw;
    try {
      raw = window.localStorage.getItem(key);
    } catch (e) {
      lastRefusal = 'storage-unavailable';
      return null;
    }
    if (raw === null || raw === undefined) { lastRefusal = 'absent'; return null; }
    var box;
    try { box = JSON.parse(raw); } catch (e) { lastRefusal = 'corrupt-json'; return null; }
    if (!box || typeof box !== 'object') { lastRefusal = 'not-an-object'; return null; }
    if (box.v !== version) { lastRefusal = 'version-skew:' + box.v + '!=' + version; return null; }
    if (!box.state) { lastRefusal = 'no-state'; return null; }
    var why = validate ? validate(box.state) : null;
    if (why) { lastRefusal = 'shape:' + why; return null; }
    return box.state;
  }

  function clear() {
    try { window.localStorage.removeItem(key); return true; }
    catch (e) { lastRefusal = 'clear-failed'; return false; }
  }

  function has() { return read() !== null; }
  function why() { return lastRefusal; }

  return { write: write, read: read, clear: clear, has: has, why: why, key: key, version: version };
}

if (typeof module !== 'undefined' && module.exports) module.exports = { makeSave: makeSave };
if (typeof window !== 'undefined') window.makeSave = makeSave;
