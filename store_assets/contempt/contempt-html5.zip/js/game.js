/* CONTEMPT — game.js. The renderer, the input, and the scenes. THE RULES ARE NOT HERE.
 *
 * ⛔ EVERY RULE LIVES IN model.js AND THIS FILE ONLY DRAWS IT. Master §2b records a wing whose
 *    balance gate certified a boss the player could not lose, because the harness and the game had
 *    drifted into two different games. Here `Internal_Ops/harness.js` and this file call the SAME
 *    `M.step`, and this file never writes model state — it reads `M.view(s)`, which is a read-only
 *    projection, so a drawing bug can never become a rules bug.
 *
 * ⛔ DESIGN RESOLUTION IS 960x600 AND EVERYTHING SCALES FROM IT. Wing §3d: a game developed at the
 *    harness's window size and shipped into itch's fixed embed is a game nobody has seen at the
 *    size the player gets. 960x600 is this wing's declared embed; the canvas letterboxes into
 *    anything smaller, including a 360x640 phone, and NEVER crops.
 *
 * ⛔ TOUCH IS NOT AN AFTERTHOUGHT. Every keyboard verb has an on-screen control, because the itch
 *    listing declares Touchscreen as an input and a listing that declares an input it does not have
 *    is a §4.1 falsehood.
 */
'use strict';

(function () {
  const M = window.CONTEMPT_MODEL;
  const DW = 960, DH = 600;

  /* The audio manifest, in ONE place, in a form Internal_Ops/measure_audio.js parses out of this
   * file rather than keeping a second copy of (a second copy of a list is a list that drifts). */
  const SFX_FILES = ['sustain', 'overruled', 'press', 'strike', 'hit', 'gavel', 'break', 'argue',
    'win', 'lose', 'ui'];

  /* ======================================================================== canvas + scaling */
  const cv = document.getElementById('game');
  const ctx = cv.getContext('2d', { alpha: false });
  let scale = 1, offX = 0, offY = 0;

  function resize() {
    const w = Math.max(1, window.innerWidth), h = Math.max(1, window.innerHeight);
    cv.width = w; cv.height = h;
    scale = Math.min(w / DW, h / DH);
    offX = Math.round((w - DW * scale) / 2);
    offY = Math.round((h - DH * scale) / 2);
    ctx.imageSmoothingEnabled = false;
  }
  window.addEventListener('resize', resize);

  /* ============================================================================== assets */
  const art = { cast: null, castIndex: null, plates: null, plateIndex: null, ready: false };
  const sfx = {};
  let audioBlocked = false;

  function loadImage(src) {
    return new Promise(function (res, rej) {
      const i = new Image();
      i.onload = function () { res(i); };
      i.onerror = function () { rej(new Error('image failed: ' + src)); };
      i.src = src;
    });
  }
  function loadJson(src) {
    return fetch(src).then(function (r) {
      if (!r.ok) throw new Error('json ' + r.status + ': ' + src);
      return r.json();
    });
  }

  function loadAudio() {
    for (const name of SFX_FILES) {
      const a = new Audio('audio/sfx_' + name + '.wav');
      a.preload = 'auto';
      sfx[name] = a;
    }
  }
  /* ⚠️ AUTOPLAY DENIAL IS NORMAL, NOT AN ERROR. Chrome refuses sound before a gesture; the game
   * must carry on silently and start sounding once the player touches something. A rejected play()
   * promise that nobody catches is an unhandled rejection in the console on every single frame. */
  function play(name, vol) {
    const a = sfx[name];
    if (!a) return;
    try {
      const c = a.cloneNode();
      c.volume = vol == null ? 0.7 : vol;
      const p = c.play();
      if (p && p.catch) p.catch(function () { audioBlocked = true; });
    } catch (e) { audioBlocked = true; }
  }

  /* ============================================================================== save */
  const SAVE_KEY = 'CONTEMPT_SAVE_V1';
  const save = window.makeSave(SAVE_KEY, 1, function (st) {
    if (typeof st.caseIndex !== 'number') return 'caseIndex';
    if (!Array.isArray(st.precedents)) return 'precedents';
    if (typeof st.won !== 'number') return 'won';
    return null;
  });

  let progress = save.read() || { caseIndex: 0, precedents: [], won: 0, mistrials: 0 };
  const persist = function () { save.write(progress); };

  /* ============================================================================== input */
  const keys = Object.create(null);
  const edge = { object: null, press: false, strike: false, confirm: false, back: false,
    help: false, restart: false, pick: -1 };
  const OBJECT_KEYS = { Digit1: 0, Digit2: 1, Digit3: 2, Digit4: 3,
    KeyA: 0, KeyS: 1, KeyD: 2, KeyF: 3 };

  window.addEventListener('keydown', function (e) {
    if (e.repeat) return;
    const c = e.code;
    keys[c] = true;
    if (OBJECT_KEYS[c] != null) { edge.object = OBJECT_KEYS[c]; edge.pick = OBJECT_KEYS[c]; }
    if (c === 'Space' || c === 'KeyJ') { edge.press = true; edge.confirm = true; e.preventDefault(); }
    if (c === 'ShiftLeft' || c === 'ShiftRight' || c === 'KeyK') edge.strike = true;
    if (c === 'Enter') edge.confirm = true;
    if (c === 'Escape') edge.back = true;
    if (c === 'KeyH') edge.help = true;
    if (c === 'KeyR') edge.restart = true;
    if (c === 'ArrowUp' || c === 'ArrowDown' || c === 'ArrowLeft' || c === 'ArrowRight') e.preventDefault();
  });
  window.addEventListener('keyup', function (e) { keys[e.code] = false; });
  window.addEventListener('blur', function () { for (const k in keys) keys[k] = false; });

  /* pointer: buttons are rectangles in DESIGN space, so one transform serves mouse and touch */
  const buttons = [];
  let heldButton = null;
  function toDesign(clientX, clientY) {
    return { x: (clientX - offX) / scale, y: (clientY - offY) / scale };
  }
  function hit(p) {
    for (let i = buttons.length - 1; i >= 0; i--) {
      const b = buttons[i];
      if (p.x >= b.x && p.x <= b.x + b.w && p.y >= b.y && p.y <= b.y + b.h) return b;
    }
    return null;
  }
  function pointerDown(clientX, clientY) {
    const b = hit(toDesign(clientX, clientY));
    if (!b) { edge.confirm = true; return; }
    heldButton = b;
    if (b.act === 'object') { edge.object = b.arg; edge.pick = b.arg; }
    else if (b.act === 'press') edge.press = true;
    else if (b.act === 'strike') edge.strike = true;
    else if (b.act === 'confirm') edge.confirm = true;
    else if (b.act === 'help') edge.help = true;
    else if (b.act === 'back') edge.back = true;
    else if (b.act === 'restart') edge.restart = true;
    else if (b.act === 'pick') { edge.pick = b.arg; edge.confirm = true; }
  }
  cv.addEventListener('mousedown', function (e) { pointerDown(e.clientX, e.clientY); });
  window.addEventListener('mouseup', function () { heldButton = null; });
  cv.addEventListener('touchstart', function (e) {
    e.preventDefault();
    const t = e.changedTouches[0];
    pointerDown(t.clientX, t.clientY);
  }, { passive: false });
  window.addEventListener('touchend', function (e) { e.preventDefault(); heldButton = null; },
    { passive: false });

  function leanInput() {
    if (heldButton && heldButton.act === 'lean') return heldButton.arg;
    if (keys.ArrowUp || keys.KeyW) return 1;
    if (keys.ArrowDown) return -1;
    return 0;
  }
  function clearEdges() {
    edge.object = null; edge.press = false; edge.strike = false;
    edge.confirm = false; edge.back = false; edge.help = false; edge.restart = false;
  }

  /* ============================================================================== scenes */
  let scene = 'title';
  let bout = null;
  let banner = null, bannerT = 0;
  let offers = [];
  let shake = 0, flashCol = null, flashT = 0;
  let helpFrom = 'title';

  function startCase(idx, keepVerdict) {
    bout = M.createBout({
      caseIndex: idx,
      seed: (Date.now() ^ (idx * 7919)) & 0x7fffffff,
      precedents: progress.precedents,
      startVerdict: keepVerdict || 0,
    });
    scene = 'trial';
    banner = null;
  }

  function offerPrecedents() {
    const pool = M.PRECEDENTS.filter(function (p) { return progress.precedents.indexOf(p.id) < 0; });
    offers = [];
    /* deterministic from the number of wins, so reloading the page cannot reroll the choice */
    const r = M.rng(1000 + progress.won * 31 + progress.caseIndex);
    const copy = pool.slice();
    while (offers.length < Math.min(3, copy.length)) {
      offers.push(copy.splice(Math.floor(r() * copy.length), 1)[0]);
    }
    scene = offers.length ? 'precedent' : 'brief';
  }

  /* ============================================================================== drawing */
  const bg = document.createElement('canvas');
  bg.width = DW; bg.height = DH;
  const bgx = bg.getContext('2d');
  let bgBuiltFor = -1;

  function plate(name) {
    const i = art.plateIndex.order.indexOf(name);
    return { sx: i * art.plateIndex.size, sy: 0, s: art.plateIndex.size };
  }
  function tile(c, name, x, y, w, h, zoom) {
    const p = plate(name), z = zoom || 1, step = p.s * z;
    c.save();
    c.beginPath(); c.rect(x, y, w, h); c.clip();
    for (let ty = y; ty < y + h; ty += step) {
      for (let tx = x; tx < x + w; tx += step) {
        c.drawImage(art.plates, p.sx, p.sy, p.s, p.s, tx, ty, step, step);
      }
    }
    c.restore();
  }

  /* THE COURTROOM, built once per case into an offscreen canvas. Rebuilding a tiled background
   * every frame is how a 60fps game becomes a 30fps game on a phone. */
  function buildBackground(caseIndex) {
    const c = bgx;
    c.fillStyle = '#0a0908'; c.fillRect(0, 0, DW, DH);

    tile(c, 'oak_a', 0, 0, DW, 300, 1);
    tile(c, 'oak_b', 0, 300, DW, 100, 1);
    tile(c, 'gallery_a', 0, 60, 300, 240, 1);
    tile(c, 'gallery_b', DW - 300, 60, 300, 240, 1);
    /* ⛔ A TILED PLATE DROPPED INTO A WALL IS A RECTANGLE OF WALLPAPER UNTIL SOMETHING FRAMES IT.
     * Two captures in a row showed the gallery texture ending on a hard edge at x=300 — the first
     * fix (darkening it) treated the pattern, which was the wrong half of the problem: the EDGE was
     * the artefact. A real courtroom gallery sits behind a timber surround, so it gets one, and the
     * rectangle becomes an opening. */
    const surround = function (x0) {
      tile(c, 'rail_b', x0, 48, 300, 14, 1);
      tile(c, 'rail_b', x0, 300, 300, 14, 1);
      tile(c, 'rail_b', x0 === 0 ? 288 : DW - 300, 48, 12, 266, 1);
      c.fillStyle = 'rgba(0,0,0,0.45)';
      c.fillRect(x0, 62, 300, 5);
      c.fillRect(x0 === 0 ? 283 : DW - 300, 48, 5, 266);
    };
    surround(0);
    surround(DW - 300);
    /* ⚠️ THE PUBLIC GALLERY IS A REPEATING PLATE AND AT FULL BRIGHTNESS IT READS AS WALLPAPER.
     * The tile passes every proof the Kit has; what it cannot pass is being looked at three tiles
     * wide. Dropping it most of the way to black turns a pattern into a dark room full of people,
     * which is what it is meant to be, and the advocates gain their contrast back. */
    /* ⚠️ AND IT HAS TO BE A GRADIENT. The first version was a flat rectangle over each gallery and
     * the capture showed exactly that: two hard-edged dark boxes with a visible vertical seam at
     * x=300. A darkening that announces its own boundary is worse than the pattern it hides. */
    const gl = c.createLinearGradient(0, 0, 340, 0);
    gl.addColorStop(0, 'rgba(6,6,10,0.72)'); gl.addColorStop(1, 'rgba(6,6,10,0)');
    c.fillStyle = gl; c.fillRect(0, 0, 340, 400);
    const gr = c.createLinearGradient(DW, 0, DW - 340, 0);
    gr.addColorStop(0, 'rgba(6,6,10,0.72)'); gr.addColorStop(1, 'rgba(6,6,10,0)');
    c.fillStyle = gr; c.fillRect(DW - 340, 0, 340, 400);

    /* the bench: a stone dais with the judge's oak bench on it, dead centre and high */
    tile(c, 'stone_a', 300, 0, 360, 150, 1);
    tile(c, 'stone_b', 300, 150, 360, 40, 1);

    /* the floor, and the rail across the front of the shot */
    tile(c, 'floor_a', 0, 400, DW, 200, 1);

    /* a warm pool of light on the bench and two colder ones on the advocates */
    const g = c.createRadialGradient(DW / 2, 120, 30, DW / 2, 160, 420);
    g.addColorStop(0, 'rgba(255,225,170,0.20)');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    c.fillStyle = g; c.fillRect(0, 0, DW, 420);

    /* vignette — pulls the eye to the middle and hides the tiling in the corners */
    const v = c.createRadialGradient(DW / 2, DH / 2, 200, DW / 2, DH / 2, 640);
    v.addColorStop(0, 'rgba(0,0,0,0)');
    v.addColorStop(1, 'rgba(0,0,0,0.72)');
    c.fillStyle = v; c.fillRect(0, 0, DW, DH);
    bgBuiltFor = caseIndex;
  }

  function drawCast(c, id, cx, footY, h, flip, lean, flash) {
    const cell = art.castIndex.cells[id];
    if (!cell) return;
    const k = h / cell.h;
    const w = cell.w * k;
    c.save();
    c.translate(cx, footY);
    if (lean) c.rotate(lean * (flip ? -0.035 : 0.035));
    if (flip) c.scale(-1, 1);
    c.drawImage(art.cast, cell.x, cell.y, cell.w, cell.h, -w / 2, -h, w, h);
    if (flash > 0) {
      c.globalCompositeOperation = 'source-atop';
      c.fillStyle = 'rgba(255,120,110,' + (0.55 * flash / 8) + ')';
      c.fillRect(-w / 2, -h, w, h);
    }
    c.restore();
  }

  /* -------------------------------------------------------------------------- HUD atoms */
  function panel(c, x, y, w, h, a) {
    c.fillStyle = 'rgba(12,10,8,' + (a == null ? 0.78 : a) + ')';
    c.fillRect(x, y, w, h);
    c.strokeStyle = 'rgba(173,129,84,0.55)';
    c.lineWidth = 2;
    c.strokeRect(x + 1, y + 1, w - 2, h - 2);
  }
  function text(c, s, x, y, size, col, align, weight) {
    c.font = (weight || 700) + ' ' + size + 'px Georgia, "Times New Roman", serif';
    c.fillStyle = col || '#e8dcc6';
    c.textAlign = align || 'left';
    c.textBaseline = 'alphabetic';
    c.fillText(s, x, y);
  }
  function button(c, b, label, sub, active, dim) {
    buttons.push(b);
    const held = heldButton === b;
    c.fillStyle = held ? 'rgba(120,86,54,0.95)' : (active ? 'rgba(60,44,30,0.92)' : 'rgba(24,20,16,0.85)');
    c.fillRect(b.x, b.y, b.w, b.h);
    c.strokeStyle = dim ? 'rgba(120,100,80,0.35)' : (active ? '#ad8154' : 'rgba(150,120,90,0.6)');
    c.lineWidth = 2;
    c.strokeRect(b.x + 1, b.y + 1, b.w - 2, b.h - 2);
    /* ⛔ SHRINK THE LABEL TO ITS BUTTON RATHER THAN TRUSTING IT TO FIT. "HOW TO PLAY" at 20px is
     * about 160px wide and its button was 145 — the capture showed the words hanging out of both
     * ends of the frame. A centred label does not clip, it just spills, so no bounds check catches
     * this and nothing but measuring the text can. */
    let size = 20;
    c.font = '700 ' + size + 'px Georgia, "Times New Roman", serif';
    while (size > 11 && c.measureText(label).width > b.w - 18) {
      size -= 1;
      c.font = '700 ' + size + 'px Georgia, "Times New Roman", serif';
    }
    text(c, label, b.x + b.w / 2, b.y + b.h / 2 + (sub ? 2 : 7), size, dim ? '#7a6b58' : '#f0e4cc', 'center');
    if (sub) text(c, sub, b.x + b.w / 2, b.y + b.h - 8, 12, '#a89170', 'center', 400);
  }

  function drawVerdictBar(c, v) {
    const x = 190, y = 26, w = 580, h = 26;
    panel(c, x - 6, y - 6, w + 12, h + 12, 0.72);
    /* their half and yours, meeting at the middle */
    const g = c.createLinearGradient(x, 0, x + w, 0);
    g.addColorStop(0, '#5a1f26'); g.addColorStop(0.5, '#2a2521'); g.addColorStop(1, '#1f4a33');
    c.fillStyle = g; c.fillRect(x, y, w, h);
    const t = (v.verdict / v.verdictWin + 1) / 2;
    const mx = x + w * t;
    c.fillStyle = 'rgba(240,228,204,0.14)';
    c.fillRect(x + w / 2, y, mx - w / 2, h);
    c.fillStyle = '#f0e4cc'; c.fillRect(mx - 3, y - 5, 6, h + 10);
    c.strokeStyle = 'rgba(240,228,204,0.45)'; c.lineWidth = 1;
    c.beginPath(); c.moveTo(x + w / 2, y); c.lineTo(x + w / 2, y + h); c.stroke();
    text(c, 'CONVICTION', x + 6, y + 19, 13, '#d9a2a2', 'left');
    text(c, 'ACQUITTAL', x + w - 6, y + 19, 13, '#9fd9b6', 'right');
  }

  /* ⛔ THIS GAUGE USED TO SIT AT THE TOP CENTRE AND IT LANDED SQUARELY ON THE JUDGE'S FACE.
   * Nothing measured it — the collision was found by capturing the trial screen and LOOKING at it,
   * which is the half of Gate 1 no script does (master §2b: look at rendered output before
   * shipping). The judge owns the centre of the frame because he is the thing the contempt meter is
   * ABOUT, so the meter moved to the left margin where nothing stands. */
  function drawContempt(c, v) {
    const x = 24, y = 78;
    text(c, 'CONTEMPT', x, y - 6, 13, v.contempt >= 2 ? '#e0836f' : '#a89170', 'left');
    for (let i = 0; i < v.contemptLimit; i++) {
      const lit = i < v.contempt;
      c.fillStyle = lit ? '#c8503c' : 'rgba(255,255,255,0.13)';
      c.fillRect(x + i * 42, y, 34, 8);
    }
    /* the patience the player has banked toward forgiving one point */
    const pw = 118 * (v.clean / v.cleanFor);
    c.fillStyle = 'rgba(160,215,180,0.5)';
    c.fillRect(x, y + 11, Math.min(118, pw), 3);
    text(c, v.contempt >= v.contemptLimit - 1 ? 'ONE MORE AND IT IS A MISTRIAL' : 'clean play forgives',
      x, y + 28, 11, '#8d7d68', 'left', 400);
  }

  function drawComposure(c, x, y, w, val, max, col) {
    c.fillStyle = 'rgba(0,0,0,0.55)'; c.fillRect(x, y, w, 9);
    c.fillStyle = col; c.fillRect(x + 1, y + 1, Math.max(0, (w - 2) * val / max), 7);
    c.strokeStyle = 'rgba(240,228,204,0.35)'; c.lineWidth = 1; c.strokeRect(x + 0.5, y + 0.5, w - 1, 8);
  }

  /* THE TELL. The one thing the player is really reading, so it gets the middle of the screen, a
   * class colour, a countdown ring and a window that visibly OPENS. */
  function drawTell(c, v) {
    const a = v.arg;
    if (!a) return;
    const cls = M.CLASSES[M.CLASSES.findIndex(function (k) { return k.id === a.cls; })];
    /* ⚠️ 690,208 PUT THIS CARD OVER THE OPPONENT'S FACE — again found by looking at the capture, not
     * by a metric. It now sits ABOVE his head and clear of the judge's dais (which spans x 385-575),
     * so the two things the player reads — the tell and the man raising it — are never stacked. */
    const cx = 742, cy = 138;
    const wob = a.waver ? Math.sin(v.tick * 0.9) * 4 : 0;
    c.save();
    c.translate(cx + wob, cy);
    const hue = cls.hue;
    const alpha = a.waver ? 0.45 : 1;
    c.globalAlpha = alpha;
    c.fillStyle = 'rgba(10,9,8,0.9)';
    c.fillRect(-118, -54, 236, 108);
    c.strokeStyle = 'hsl(' + hue + ',62%,' + (a.open ? 68 : 42) + '%)';
    c.lineWidth = a.open ? 4 : 2;
    c.strokeRect(-118, -54, 236, 108);
    text(c, cls.label.toUpperCase(), 0, -22, 26, 'hsl(' + hue + ',70%,74%)', 'center');
    text(c, cls.tell, 0, 2, 13, '#cbbba0', 'center', 400);
    if (a.parts === 2) {
      text(c, a.answered ? 'AND THE SECOND HALF' : 'COMPOUND — TWO OBJECTIONS',
        0, 22, 12, '#e0c07a', 'center', 400);
    }
    if (a.bait) text(c, 'DO NOT SWING', 0, 40, 12, '#e08a6f', 'center', 400);
    if (a.waver) text(c, 'wavering...', 0, 40, 13, '#9a9a9a', 'center', 400);

    /* the timing bar: the whole telegraph, with the objection window lit at the end of it */
    const bw = 220, bx = -110, by = 62;
    c.fillStyle = 'rgba(255,255,255,0.10)'; c.fillRect(bx, by, bw, 10);
    const winStart = (a.windup - a.window) / a.windup;
    c.fillStyle = 'hsla(' + hue + ',60%,55%,0.45)';
    c.fillRect(bx + bw * winStart, by, bw * (1 - winStart), 10);
    const p = Math.min(1, a.t / a.windup);
    c.fillStyle = a.open ? 'hsl(' + hue + ',80%,72%)' : '#cbbba0';
    c.fillRect(bx + bw * p - 2, by - 4, 4, 18);
    c.restore();
    c.globalAlpha = 1;
  }

  function drawTrial() {
    const v = M.view(bout);
    const c = ctx;
    if (bgBuiltFor !== bout.caseIndex) buildBackground(bout.caseIndex);

    c.save();
    c.translate(offX, offY); c.scale(scale, scale);
    c.beginPath(); c.rect(0, 0, DW, DH); c.clip();
    if (shake > 0) c.translate((Math.random() - 0.5) * shake, (Math.random() - 0.5) * shake);

    c.drawImage(bg, 0, 0);

    /* the judge, high and central */
    drawCast(c, 'judge', DW / 2, 200, 190, false, 0, 0);

    /* the two advocates. The player is MIRRORED because every generated sprite faces left. */
    const youLean = v.you.lean;
    drawCast(c, 'advocate', 210, 470, 300, true, youLean, v.you.flash);
    drawCast(c, v.spec.foe, 742, 470, 300, false, 0, v.foe.flash);

    /* the rail across the front of the shot — it is what makes one scene out of seven portraits
     * drawn at seven different waistlines */
    tile(c, 'rail_a', 0, 452, DW, 64, 1);
    tile(c, 'floor_b', 0, 516, DW, 84, 1);
    c.fillStyle = 'rgba(0,0,0,0.35)'; c.fillRect(0, 452, DW, 6);

    drawVerdictBar(c, v);
    drawContempt(c, v);
    /* ⚠️ NAMEPLATES, NOT BARE TEXT. Both labels used to be drawn straight onto the picture and both
     * were unreadable where it mattered: "THE INTERN" fell across his own bright clipboard. A label
     * over an illustrated sprite needs its own ground, and a courtroom has nameplates anyway. */
    const plate2 = function (x, w, label, col) {
      c.fillStyle = 'rgba(10,9,8,0.82)'; c.fillRect(x - 6, 414, w + 12, 36);
      c.strokeStyle = 'rgba(173,129,84,0.45)'; c.lineWidth = 1; c.strokeRect(x - 5.5, 414.5, w + 11, 35);
      text(c, label, x, 430, 13, col, 'left');
    };
    plate2(118, 184, 'YOU', '#9fbdd8');
    plate2(654, 184, v.spec.name.toUpperCase(), '#d8a98a');
    drawComposure(c, 118, 436, 184, v.you.composure, v.you.max, '#7fb0d8');
    drawComposure(c, 654, 436, 184, v.foe.composure, v.foe.max, '#c88a6a');

    /* ⚠️ THESE TWO USED TO BE BARE TEXT AT FACE HEIGHT and a GIF frame showed "REELING" written
     * across the opponent's glasses — the same lesson as the nameplates, one layer up. A state
     * word over an illustrated character needs its own ground and needs to sit on the BODY, not
     * the head: the face is the thing the player is reading for a tell. */
    const shout = function (x, label, col) {
      c.font = '700 24px Georgia, "Times New Roman", serif';
      const w = c.measureText(label).width + 28;
      c.fillStyle = 'rgba(10,9,8,0.86)'; c.fillRect(x - w / 2, 336, w, 34);
      c.strokeStyle = col; c.lineWidth = 2; c.strokeRect(x - w / 2 + 1, 337, w - 2, 32);
      text(c, label, x, 360, 24, col, 'center');
    };
    if (v.foe.stagger > 0) shout(742, 'REELING', '#ffd98a');
    if (v.you.lock > 0) shout(210, 'OVERRULED', '#e08a6f');
    if (v.you.press > 0) {
      const p = 1 - v.you.press / v.you.pressMax;
      c.fillStyle = 'rgba(255,255,255,0.14)'; c.fillRect(140, 320, 140, 8);
      c.fillStyle = '#e8d8a8'; c.fillRect(140, 320, 140 * p, 8);
      text(c, 'MAKING YOUR POINT', 210, 314, 12, '#e8d8a8', 'center', 400);
    }

    drawTell(c, v);

    /* ---------------------------------------------------------------- the control bar */
    buttons.length = 0;
    panel(c, 0, DH - 84, DW, 84, 0.82);
    const unlocked = v.spec.classes;
    for (let i = 0; i < 4; i++) {
      const cls = M.CLASSES[i];
      const b = { x: 16 + i * 118, y: DH - 74, w: 108, h: 44, act: 'object', arg: cls.id };
      if (i < unlocked) {
        const armed = !!(v.arg && v.arg.open && !v.you.lock);
        buttons.push(b);
        c.fillStyle = heldButton === b ? 'hsla(' + cls.hue + ',55%,45%,0.95)' : 'rgba(22,19,16,0.9)';
        c.fillRect(b.x, b.y, b.w, b.h);
        c.strokeStyle = 'hsl(' + cls.hue + ',55%,' + (armed ? 62 : 34) + '%)';
        c.lineWidth = 2; c.strokeRect(b.x + 1, b.y + 1, b.w - 2, b.h - 2);
        text(c, cls.label, b.x + b.w / 2, b.y + 26, 17, 'hsl(' + cls.hue + ',60%,76%)', 'center');
        text(c, cls.key, b.x + b.w / 2, b.y + 40, 11, '#8d7d68', 'center', 400);
      } else {
        c.fillStyle = 'rgba(16,14,12,0.7)'; c.fillRect(b.x, b.y, b.w, b.h);
        c.strokeStyle = 'rgba(90,80,70,0.35)'; c.lineWidth = 2;
        c.strokeRect(b.x + 1, b.y + 1, b.w - 2, b.h - 2);
        text(c, 'LOCKED', b.x + b.w / 2, b.y + 28, 14, '#5f5648', 'center', 400);
      }
    }
    button(c, { x: 500, y: DH - 74, w: 120, h: 44, act: 'press' },
      'PRESS', 'space  ' + v.evidence + '/' + v.evidenceMax, v.evidence > 0, v.evidence === 0);
    button(c, { x: 628, y: DH - 74, w: 120, h: 44, act: 'strike' },
      'STRIKE', v.strikeCd > 0 ? 'recovering' : 'shift  +1 contempt', v.strikeCd === 0, v.strikeCd > 0);
    /* ⚠️ "LEAN IN" and "STAND BACK" at 20px OVERFLOWED THEIR 92px BUTTONS AND RAN INTO EACH OTHER.
     * The label is drawn centred, so it does not clip — it just collides, which no bounds check
     * would have caught either. Short labels, and the long word goes in the sub-line. */
    button(c, { x: 756, y: DH - 74, w: 92, h: 44, act: 'lean', arg: 1 }, 'IN', 'lean  up', youLean === 1);
    button(c, { x: 852, y: DH - 74, w: 92, h: 44, act: 'lean', arg: -1 }, 'BACK', 'stand  down', youLean === -1);

    /* evidence, as physical documents on the rail in front of you */
    for (let i = 0; i < v.evidenceMax; i++) {
      const x = 20 + i * 22, y = 468;
      c.fillStyle = i < v.evidence ? '#e6ddc6' : 'rgba(255,255,255,0.10)';
      c.fillRect(x, y, 17, 22);
      if (i < v.evidence) {
        c.fillStyle = 'rgba(60,44,30,0.55)';
        for (let l = 0; l < 4; l++) c.fillRect(x + 3, y + 4 + l * 4, 11, 1);
      }
    }
    text(c, 'EVIDENCE', 20, 464, 11, '#a89170', 'left', 400);

    if (audioBlocked) text(c, 'sound is muted until you tap', DW - 12, DH - 92, 12, '#7a6b58', 'right', 400);

    if (banner) {
      c.globalAlpha = Math.min(1, bannerT / 20);
      text(c, banner.text, DW / 2, 340, 44, banner.col, 'center');
      c.globalAlpha = 1;
    }
    if (flashT > 0) {
      c.fillStyle = flashCol; c.globalAlpha = flashT / 12; c.fillRect(0, 0, DW, DH); c.globalAlpha = 1;
    }
    c.restore();
  }

  /* ------------------------------------------------------------------------ full-screen scenes */
  function frame(draw) {
    const c = ctx;
    c.fillStyle = '#070605';
    c.fillRect(0, 0, cv.width, cv.height);
    c.save();
    c.translate(offX, offY); c.scale(scale, scale);
    c.beginPath(); c.rect(0, 0, DW, DH); c.clip();
    buttons.length = 0;
    draw(c);
    c.restore();
  }

  function sceneBackdrop(c) {
    if (art.ready) {
      tile(c, 'oak_a', 0, 0, DW, DH, 1);
      c.fillStyle = 'rgba(6,5,4,0.72)'; c.fillRect(0, 0, DW, DH);
    } else {
      c.fillStyle = '#12100e'; c.fillRect(0, 0, DW, DH);
    }
  }

  function drawTitle() {
    frame(function (c) {
      sceneBackdrop(c);
      if (art.ready) {
        drawCast(c, 'advocate', 250, 560, 420, true, 0, 0);
        drawCast(c, 'foe5_champion', 720, 560, 420, false, 0, 0);
        c.fillStyle = 'rgba(6,5,4,0.55)'; c.fillRect(0, 0, DW, DH);
      }
      text(c, 'CONTEMPT', DW / 2, 190, 96, '#f0e4cc', 'center');
      text(c, 'a courtroom brawler', DW / 2, 226, 22, '#ad8154', 'center', 400);
      text(c, 'The trial is the fight. Objections are parries. Evidence is ammunition.',
        DW / 2, 288, 19, '#cbbba0', 'center', 400);
      text(c, 'Hitting opposing counsel works. It also gets you held in contempt.',
        DW / 2, 314, 19, '#cbbba0', 'center', 400);

      const resume = progress.caseIndex > 0 || progress.precedents.length > 0;
      button(c, { x: DW / 2 - 150, y: 366, w: 300, h: 56, act: 'confirm' },
        resume ? 'RESUME — CASE ' + (progress.caseIndex + 1) : 'OPEN THE FIRST CASE',
        'space or tap', true);
      if (resume) {
        button(c, { x: DW / 2 - 200, y: 434, w: 190, h: 46, act: 'help' }, 'HOW TO PLAY', 'H', true);
        button(c, { x: DW / 2 + 10, y: 434, w: 190, h: 46, act: 'restart' }, 'NEW CAREER', 'R', true);
      } else {
        button(c, { x: DW / 2 - 110, y: 434, w: 220, h: 46, act: 'help' }, 'HOW TO PLAY', 'H', true);
      }
      text(c, 'Core Systems Asset Factory', DW / 2, DH - 26, 14, '#6d5f4c', 'center', 400);
    });
  }

  function drawHelp() {
    frame(function (c) {
      sceneBackdrop(c);
      text(c, 'HOW A TRIAL WORKS', DW / 2, 74, 40, '#f0e4cc', 'center');
      const lines = [
        /* ⚠️ "OBJECT 1 2 3 4 / A S D F" ran into the description column — its trailing F sat on the
         * word "They". A two-column layout needs the widest LABEL measured against the gutter, and
         * this one was simply the longest string in the list. Shortened, and the column moved. */
        ['OBJECT  1-4  or  A-F',
          'They telegraph an argument. Its CLASS is named on the card. Press the matching key while'],
        ['', 'the bar is inside the lit window: sustained, they lose composure, you gain a document.'],
        ['', 'Wrong class or wrong moment and you are OVERRULED — silenced, and the jury drifts.'],
        ['THE FEINT', 'Some arguments go nowhere. When one starts to WAVER, take your hand off the key.'],
        ['COMPOUND', 'Two classes in one breath. Answer the first, then read the second.'],
        ['PRESS  space', 'Spend a document to make your own point. It has a wind-up: start one with an'],
        ['', 'argument landing and you will eat it. Free while they are reeling.'],
        ['STRIKE  shift', 'Hit them. It always lands. It always costs a point of the judge\'s patience,'],
        ['', 'and three points is a mistrial. Two clean actions pay one point back.'],
        ['STANCE  up / down', 'Lean in for a harder press and a narrower window. Stand back for the reverse.'],
        ['THE CLOCK', 'The burden of proof is yours: the jury drifts to the prosecution on its own, faster'],
        ['', 'the further behind you are. At 150 seconds they return with whoever is ahead.'],
        ['MISTRIAL', 'You keep every precedent you have won and restart the same case. Progress is saved.'],
      ];
      /* ⛔ MEASURE EVERY LINE AGAINST THE MARGIN. Moving the text column right to clear the key
       * column pushed the longest line off the RIGHT edge instead — the same defect walking across
       * the screen, because a two-column layout has TWO constraints and fixing one by hand breaks
       * the other. Shrink to fit and the layout can no longer be wrong in either direction. */
      const RIGHT = DW - 26;
      let y = 128;
      for (const [k, s] of lines) {
        if (k) text(c, k, 86, y, 17, '#ad8154');
        let size = 16;
        c.font = '400 ' + size + 'px Georgia, serif';
        while (size > 11 && 326 + c.measureText(s).width > RIGHT) {
          size -= 1;
          c.font = '400 ' + size + 'px Georgia, serif';
        }
        text(c, s, 326, y, size, '#cbbba0', 'left', 400);
        y += k && s ? 30 : 24;
      }
      button(c, { x: DW / 2 - 90, y: DH - 74, w: 180, h: 48, act: 'back' }, 'BACK', 'esc or tap', true);
    });
  }

  function drawBrief() {
    const spec = M.CASES[progress.caseIndex];
    frame(function (c) {
      /* ⚠️ THE PORTRAIT USED TO SIT DEAD CENTRE AND THE TEXT RAN STRAIGHT ACROSS HIS FACE — the
       * blurb over his hair, the mechanics line over his forehead. Found by opening the capture.
       * Dimming the sprite did not help because the type is drawn after the dim. The layout is the
       * fix: copy in the left column, the man on the right, and neither crosses the other. */
      sceneBackdrop(c);
      if (art.ready) drawCast(c, spec.foe, 730, 520, 400, false, 0, 0);
      const veil = c.createLinearGradient(0, 0, DW, 0);
      veil.addColorStop(0, 'rgba(6,5,4,0.92)');
      veil.addColorStop(0.55, 'rgba(6,5,4,0.72)');
      veil.addColorStop(1, 'rgba(6,5,4,0.18)');
      c.fillStyle = veil; c.fillRect(0, 0, DW, DH);
      text(c, 'CASE ' + (progress.caseIndex + 1) + ' OF ' + M.CASES.length, 64, 132, 20, '#ad8154');
      text(c, spec.name.toUpperCase(), 64, 190, 50, '#f0e4cc');
      /* wrap the blurb inside the left column rather than trusting it to be short */
      const words = spec.blurb.split(' ');
      let line = '', y = 232;
      c.font = '400 19px Georgia, serif';
      for (const w of words) {
        if (c.measureText(line + ' ' + w).width > 470) {
          text(c, line, 64, y, 19, '#cbbba0', 'left', 400); line = w; y += 26;
        } else line = line ? line + ' ' + w : w;
      }
      text(c, line, 64, y, 19, '#cbbba0', 'left', 400);
      const bits = [];
      bits.push(spec.classes + ' objection classes in play');
      if (spec.feint) bits.push('feints');
      if (spec.compound) bits.push('compound arguments');
      if (spec.bait) bits.push('contempt bait');
      text(c, bits.join('  ·  '), 64, y + 40, 16, '#9a8a70', 'left', 400);
      if (progress.precedents.length) {
        text(c, 'PRECEDENTS ON THE RECORD', 64, y + 92, 15, '#ad8154');
        let pl = '', py = y + 116;
        c.font = '400 15px Georgia, serif';
        for (const w of progress.precedents.map(function (id) { return M.PRECEDENT_INDEX[id].name; })) {
          if (c.measureText(pl + ' · ' + w).width > 470) {
            text(c, pl, 64, py, 15, '#cbbba0', 'left', 400); pl = w; py += 22;
          } else pl = pl ? pl + ' · ' + w : w;
        }
        text(c, pl, 64, py, 15, '#cbbba0', 'left', 400);
      }
      button(c, { x: 64, y: DH - 96, w: 280, h: 52, act: 'confirm' }, 'CALL THE COURT', 'space', true);
    });
  }

  function drawPrecedent() {
    frame(function (c) {
      sceneBackdrop(c);
      text(c, 'THE COURT SETS A PRECEDENT', DW / 2, 96, 38, '#f0e4cc', 'center');
      text(c, 'Choose one. It is yours for the rest of the career.', DW / 2, 130, 17, '#cbbba0', 'center', 400);
      offers.forEach(function (p, i) {
        const b = { x: 60 + i * 288, y: 190, w: 264, h: 230, act: 'pick', arg: i };
        buttons.push(b);
        c.fillStyle = heldButton === b ? 'rgba(120,86,54,0.9)' : 'rgba(20,17,14,0.92)';
        c.fillRect(b.x, b.y, b.w, b.h);
        c.strokeStyle = '#ad8154'; c.lineWidth = 2; c.strokeRect(b.x + 1, b.y + 1, b.w - 2, b.h - 2);
        text(c, String(i + 1), b.x + 16, b.y + 34, 20, '#8d7d68');
        text(c, p.name, b.x + b.w / 2, b.y + 74, 23, '#f0e4cc', 'center');
        const words = p.text.split(' ');
        let line = '', y = b.y + 112;
        c.font = '400 15px Georgia, serif';
        for (const w of words) {
          if (c.measureText(line + ' ' + w).width > b.w - 34) {
            text(c, line, b.x + b.w / 2, y, 15, '#cbbba0', 'center', 400); line = w; y += 22;
          } else line = line ? line + ' ' + w : w;
        }
        text(c, line, b.x + b.w / 2, y, 15, '#cbbba0', 'center', 400);
      });
      text(c, 'press 1, 2 or 3', DW / 2, 470, 15, '#8d7d68', 'center', 400);
    });
  }

  function drawEnd(won) {
    frame(function (c) {
      sceneBackdrop(c);
      const finished = won && progress.caseIndex >= M.CASES.length;
      text(c, finished ? 'THE RECORD IS CLEAR' : (won ? 'SUSTAINED' : (bout && bout.over === 'contempt'
        ? 'HELD IN CONTEMPT' : 'THE VERDICT IS IN')),
        DW / 2, 180, 60, won ? '#9fd9b6' : '#d9a2a2', 'center');
      const msg = finished
        ? 'Five cases, five verdicts. The State\'s Champion has lost one.'
        : won ? 'The jury believes you. The next case is already on the list.'
          : (bout && bout.over === 'contempt'
            ? 'The judge has had enough of you. Mistrial — you keep every precedent.'
            : 'They convinced the jury first. Mistrial — you keep every precedent.');
      text(c, msg, DW / 2, 232, 20, '#cbbba0', 'center', 400);
      if (bout) {
        const s = bout.stats;
        text(c, 'objections ' + s.objected + '  ·  overruled ' + s.overruled + '  ·  points ' + s.pressed
          + '  ·  strikes ' + s.struck + '  ·  arguments taken ' + s.taken,
          DW / 2, 286, 16, '#9a8a70', 'center', 400);
      }
      button(c, { x: DW / 2 - 150, y: 360, w: 300, h: 56, act: 'confirm' },
        finished ? 'BACK TO THE TITLE' : (won ? 'CONTINUE' : 'TAKE THE CASE AGAIN'), 'space', true);
      if (!finished) {
        button(c, { x: DW / 2 - 150, y: 434, w: 300, h: 44, act: 'back' }, 'TITLE SCREEN', 'esc', true);
      }
    });
  }

  function drawLoading(err) {
    frame(function (c) {
      c.fillStyle = '#12100e'; c.fillRect(0, 0, DW, DH);
      text(c, err ? 'THE COURT CANNOT SIT' : 'CONTEMPT', DW / 2, 280, 52, '#f0e4cc', 'center');
      text(c, err ? String(err) : 'assembling the courtroom...', DW / 2, 324, 18, '#cbbba0', 'center', 400);
    });
  }

  /* ============================================================================== the loop */
  let acc = 0, last = 0, loadError = null;

  /* ⛔ RESOLVE THE OBJECTION INPUT DEFENSIVELY, AND THIS IS NOT PARANOIA — IT WAS A LIVE DEFECT.
   * `edge.object` is an INDEX from the keyboard map and the on-screen buttons, and the capture tool
   * passed a class STRING instead. `M.CLASSES['HEARSAY'].id` throws, inside requestAnimationFrame,
   * which kills the loop silently: the game freezes on its last frame while `scene()` still answers
   * "trial", so the tool's own assertion PASSED over a dead game (master §2b, the vacuous-check
   * family). Accepting both spellings and returning null for anything else means a bad caller can
   * no longer take the render loop down with it. */
  function objectionId(v) {
    if (typeof v === 'number') return M.CLASSES[v] ? M.CLASSES[v].id : null;
    if (typeof v === 'string') return M.CLASSES.some(function (c) { return c.id === v; }) ? v : null;
    return null;
  }

  function stepTrial() {
    const inp = {
      object: objectionId(edge.object),
      press: edge.press, strike: edge.strike, lean: leanInput(),
    };
    const events = M.step(bout, inp);
    for (const e of events) {
      if (e.type === 'sustained') { play('sustain'); banner = { text: 'SUSTAINED', col: '#9fd9b6' }; bannerT = 34; }
      else if (e.type === 'overruled') { play('overruled'); banner = { text: 'OVERRULED', col: '#e08a6f' }; bannerT = 30; shake = 5; }
      else if (e.type === 'press') play('press');
      else if (e.type === 'strike') { play('strike'); shake = 12; play('gavel', 0.5); }
      else if (e.type === 'hit') { play('hit'); shake = 7; flashCol = 'rgba(190,60,50,0.6)'; flashT = 10; }
      else if (e.type === 'break') { play('break'); banner = { text: 'REELING', col: '#ffd98a' }; bannerT = 34; }
      else if (e.type === 'argument') play('argue', 0.35);
      else if (e.type === 'flustered') { banner = { text: 'FLUSTERED', col: '#e08a6f' }; bannerT = 40; shake = 14; }
      else if (e.type === 'patience') banner = { text: 'THE JUDGE RELENTS', col: '#9fd9b6' }, bannerT = 30;
      else if (e.type === 'win') { play('win'); endBout(true); }
      else if (e.type === 'lose') { play('lose'); endBout(false); }
    }
  }

  function endBout(won) {
    if (won) {
      progress.won++;
      progress.caseIndex++;
      persist();
      scene = 'won';
    } else {
      progress.mistrials++;
      persist();
      scene = 'lost';
    }
  }

  function update() {
    if (scene === 'trial') stepTrial();
    if (bannerT > 0) bannerT--; else banner = null;
    if (shake > 0) shake *= 0.86;
    if (flashT > 0) flashT--;
  }

  function handleMenus() {
    if (scene === 'title') {
      if (edge.help) { helpFrom = 'title'; scene = 'help'; play('ui'); }
      else if (edge.restart) {
        progress = { caseIndex: 0, precedents: [], won: 0, mistrials: 0 };
        persist(); play('ui');
      } else if (edge.confirm) { play('ui'); scene = 'brief'; }
    } else if (scene === 'help') {
      if (edge.back || edge.confirm) { scene = helpFrom; play('ui'); }
    } else if (scene === 'brief') {
      if (edge.back) { scene = 'title'; play('ui'); }
      else if (edge.help) { helpFrom = 'brief'; scene = 'help'; play('ui'); }
      else if (edge.confirm) { play('ui'); startCase(progress.caseIndex, 0); }
    } else if (scene === 'precedent') {
      const i = edge.pick;
      if (i >= 0 && i < offers.length && (edge.confirm || edge.object != null)) {
        progress.precedents.push(offers[i].id);
        persist(); play('ui');
        scene = progress.caseIndex >= M.CASES.length ? 'done' : 'brief';
      }
    } else if (scene === 'won') {
      if (edge.confirm) {
        play('ui');
        if (progress.caseIndex >= M.CASES.length) { scene = 'done'; }
        else offerPrecedents();
      }
    } else if (scene === 'lost') {
      if (edge.back) { scene = 'title'; play('ui'); }
      else if (edge.confirm) {
        play('ui');
        /* CONTINUANCE: a mistrial normally wipes the board, but the precedent keeps half of it.
         * Either way the case, the precedents and the career survive — never a full restart. */
        const keep = progress.precedents.indexOf('continuance') >= 0 && bout
          ? Math.max(0, Math.round(bout.verdict / 2)) : 0;
        startCase(progress.caseIndex, keep);
      }
    } else if (scene === 'done') {
      if (edge.confirm || edge.back) {
        play('ui');
        progress = { caseIndex: 0, precedents: [], won: 0, mistrials: 0 };
        persist();
        scene = 'title';
      }
    } else if (scene === 'trial') {
      if (edge.help) { helpFrom = 'trial'; scene = 'help'; }
      else if (edge.back) { scene = 'title'; }
    }
    edge.pick = -1;
  }

  /* ⚠️ THE ROTATE HINT, AND IT IS AN HONESTY FEATURE AS MUCH AS A UX ONE. At 360x640 the design box
   * scales to 0.375 and the objection labels are about 6px tall — playable in the sense that every
   * input works, unreadable in the sense that matters. The listing therefore does NOT tick
   * "mobile friendly", and the game says the same thing to the player instead of pretending. It is
   * drawn in the LETTERBOX, so it never covers the game and never blocks a tap. */
  function drawRotateHint() {
    if (window.innerHeight < window.innerWidth * 1.1) return;
    if (scale >= 0.5) return;
    const c = ctx;
    const y = offY + DH * scale + 18;
    if (y + 40 > cv.height) return;
    c.font = '700 16px Georgia, "Times New Roman", serif';
    c.textAlign = 'center';
    c.fillStyle = '#ad8154';
    c.fillText('TURN YOUR PHONE SIDEWAYS', cv.width / 2, y + 16);
    c.font = '400 13px Georgia, serif';
    c.fillStyle = '#8d7d68';
    c.fillText('the court is wider than it is tall', cv.width / 2, y + 36);
  }

  function render() {
    if (!art.ready) { drawLoading(loadError); return; }
    if (scene === 'title') drawTitle();
    else if (scene === 'help') drawHelp();
    else if (scene === 'brief') drawBrief();
    else if (scene === 'precedent') drawPrecedent();
    else if (scene === 'trial') drawTrial();
    else if (scene === 'won') drawEnd(true);
    else if (scene === 'lost') drawEnd(false);
    else if (scene === 'done') drawEnd(true);
    drawRotateHint();
  }

  function loop(now) {
    if (!last) last = now;
    let dt = (now - last) / 1000;
    last = now;
    /* ⚠️ CLAMP. A backgrounded tab returns with a huge dt and would otherwise run thousands of
     * fixed steps in one frame — the trial would resolve itself while nobody was looking. */
    if (dt > 0.25) dt = 0.25;
    acc += dt;
    const stepDur = 1 / M.TPS;
    let guard = 0;
    while (acc >= stepDur && guard < 8) { acc -= stepDur; update(); guard++; }
    if (guard >= 8) acc = 0;
    handleMenus();
    render();
    clearEdges();
    requestAnimationFrame(loop);
  }

  /* ============================================================================== boot */
  resize();
  drawLoading(null);
  loadAudio();
  Promise.all([
    loadImage('art/cast.png'), loadJson('art/cast.json'),
    loadImage('art/plates.png'), loadJson('art/plates.json'),
  ]).then(function (r) {
    art.cast = r[0]; art.castIndex = r[1];
    art.plates = r[2]; art.plateIndex = r[3];
    art.ready = true;
    /* expose a tiny, read-only surface for the automated playthrough harness. It drives the SAME
     * inputs a player produces; it cannot write model state. */
    window.CONTEMPT_DEBUG = {
      scene: function () { return scene; },
      view: function () { return bout ? M.view(bout) : null; },
      progress: function () { return JSON.parse(JSON.stringify(progress)); },
      press: function (what, arg) {
        if (what === 'object') { edge.object = arg; edge.pick = arg; }
        else if (what === 'press') edge.press = true;
        else if (what === 'strike') edge.strike = true;
        else if (what === 'confirm') edge.confirm = true;
        else if (what === 'back') edge.back = true;
        else if (what === 'help') edge.help = true;
        else if (what === 'restart') edge.restart = true;
        else if (what === 'pick') { edge.pick = arg; edge.confirm = true; }
      },
      buttons: function () { return buttons.map(function (b) { return { x: b.x, y: b.y, w: b.w, h: b.h, act: b.act }; }); },
      audioBlocked: function () { return audioBlocked; },
      saveWhy: function () { return save.why(); },
    };
    requestAnimationFrame(loop);
  }).catch(function (e) {
    loadError = e && e.message ? e.message : String(e);
    drawLoading(loadError);
  });
}());
