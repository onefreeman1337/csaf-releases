/* BITTERWORKS — data.js
 *
 * Every tunable number in the game, in one place, as plain data. The simulation reads this and
 * owns none of it; the art generators read the ORDER of these lists to lay out their sheets, so
 * a machine added here appears in the sheet without anybody retyping a column index.
 *
 * ⛔ Nothing in this file may import anything. It is loaded first, in a plain <script> tag, and
 * it must work identically under node (the campaign probe and the tests require it) and in the
 * browser.
 */
'use strict';

/* ── THE BOARD ────────────────────────────────────────────────────────────────────────────────
 * Nine columns by six rows of lake bed. The lake lies to the WEST (low x) and the railhead to the
 * EAST (high x), and that opposition is the whole spatial game: brine is strongest under the
 * water's edge, and soda ash can only leave from the causeway column. The works has to stretch.
 */
const BOARD = {
  cols: 9,
  rows: 6,
  /* Columns 0..shoreline-1 are still under water and cannot be built on. The shoreline retreats
   * WEST one column at the start of the years listed, permanently exposing new bed. */
  shorelineStart: 3,
  shorelineYears: [3, 5, 7],       /* start of year 3, 5 and 7 → shoreline 2, then 1, then 0 */
};

/* ── MATERIALS ────────────────────────────────────────────────────────────────────────────────
 * Order matters: the icon sheet is generated in this order.
 */
const MATERIALS = [
  { id: 'brine', name: 'Brine', short: 'BRN', colour: '#2d6a4c', hint: 'Raw liquor pumped out of the bed. Weak, heavy, and worth nothing until the sun has had it.' },
  { id: 'liquor', name: 'Liquor', short: 'LIQ', colour: '#d2b95c', hint: 'Brine reduced in the pans until it is close to giving up its salt.' },
  { id: 'salt', name: 'Salt', short: 'SLT', colour: '#f8f1e7', hint: 'Crystallised out of the liquor. Half the soda recipe.' },
  { id: 'bittern', name: 'Bittern', short: 'BIT', colour: '#1c4c3c', hint: 'What the pan will not give up as salt. The works is named for it because everyone else throws it away.' },
  { id: 'potash', name: 'Potash', short: 'PTS', colour: '#b76c2c', hint: 'Bittern taken round again in a still. The other half of the soda recipe.' },
  { id: 'soda', name: 'Soda ash', short: 'SDA', colour: '#aab2bc', hint: 'The only thing the railhead will buy for the standing order. It has to REACH the causeway.' },
];

/* ── MACHINES ─────────────────────────────────────────────────────────────────────────────────
 * Order matters: the machine sheet is generated in this order, two rows (idle, running).
 *
 * `takes`  — materials this machine accepts from an orthogonal neighbour.
 * `recipe` — { in: {mat: qty}, out: {mat: qty}, per: seconds } at rate 1.
 * `cap`    — buffer capacity per material.
 *
 * ⭐ THERE ARE NO BELTS. A machine pushes its output only into the four cells orthogonally
 * touching it. That is the entire logistics system, and it is why a fixed board is a puzzle
 * rather than a checklist.
 */
const MACHINES = [
  {
    id: 'well', name: 'Well', cost: 30, cap: 30, takes: [],
    line: 'Draws brine out of the bed beneath it. Runs dry if you take more than the ground can carry.',
    /* wells have no material input; the sim reads the bed field instead */
    recipe: { in: {}, out: { brine: 3 }, per: 1.0 },
  },
  {
    id: 'pan', name: 'Pan', cost: 26, cap: 40, takes: ['brine', 'liquor'],
    line: 'An evaporation pan. The sun does the work, so a pan is only as good as the season and its neighbours. Pans run as a CASCADE: a full pan passes its surplus brine along, and every pan hands its liquor down the line until something crystallises it.',
    recipe: { in: { brine: 3 }, out: { liquor: 1 }, per: 1.0 },
  },
  {
    id: 'crystalliser', name: 'Crystalliser', cost: 65, cap: 26, takes: ['liquor'],
    line: 'Takes the liquor down to crystal. Gives salt and, because it must, bittern.',
    /* ⭐ `vent` IS THE TITLE OF THE GAME. Every other works on the lake tips its bittern back into
     * the bed, so a crystalliser with nowhere to send it does the same rather than jamming — and
     * the game counts every tonne it throws away, which is the argument for building a still. */
    recipe: { in: { liquor: 2 }, out: { salt: 1, bittern: 0.7 }, per: 1.2, vent: ['bittern'] },
  },
  {
    id: 'still', name: 'Still', cost: 110, cap: 22, takes: ['bittern'],
    line: 'Boils bittern back round into potash. Everyone else calls bittern waste.',
    recipe: { in: { bittern: 2 }, out: { potash: 1 }, per: 1.4 },
  },
  {
    id: 'sodaworks', name: 'Soda works', cost: 200, cap: 20, takes: ['salt', 'potash'],
    line: 'Burns salt and potash together into soda ash. Standing on the causeway, it exports; anywhere else, the soda has to be carried.',
    recipe: { in: { salt: 2, potash: 1 }, out: { soda: 1 }, per: 1.6 },
  },
  {
    id: 'cistern', name: 'Cistern', cost: 34, cap: 90, takes: ['brine', 'liquor', 'salt', 'bittern', 'potash', 'soda'],
    line: 'Holds one material and passes it along. The only way across a gap, and it costs a whole cell to cross one.',
    recipe: null,                    /* pure buffer + relay; the material is chosen on placement */
  },
];

/* ── THE YEAR ─────────────────────────────────────────────────────────────────────────────────
 * Four seasons of equal length. `sun` scales every pan; `recharge` scales the bed's diffusion and
 * its inflow from the lake. The two are deliberately opposed: the season that dries your liquor
 * fastest is the season that empties your wells fastest.
 */
const SEASON_LENGTH = 75;          /* seconds per season → 300s (5 min) per year at speed 1 */
const SEASONS = [
  { id: 'thaw', name: 'THAW', sun: 0.70, recharge: 1.60, line: 'Meltwater in the bed. The pans are slow and the ground is generous.' },
  { id: 'glare', name: 'GLARE', sun: 1.65, recharge: 0.25, line: 'The pans will never run better and the bed will never run worse.' },
  { id: 'gather', name: 'GATHER', sun: 1.00, recharge: 0.60, line: 'An even season. Nothing is an excuse in GATHER.' },
  { id: 'rain', name: 'RAIN', sun: 0.28, recharge: 1.90, line: 'The pans stall. Build now, and let the bed fill behind you.' },
];

/* ── THE LEASE ────────────────────────────────────────────────────────────────────────────────
 * Eight years, one standing order, one verdict. A fixed arc is half of this game's Gate 2 claim:
 * the shelf is full of idlers that never end.
 */
const LEASE_YEARS = 8;
const ORDER_SODA = 1150;           /* tonnes of soda ash owed over the whole lease */
const START_MARKS = 420;
const START_CREW = 2;
const CREW_PERIOD = 95;            /* seconds per new crew */
const CREW_CAP = 4;

/* ── WHAT THE RAILHEAD PAYS ───────────────────────────────────────────────────────────────────
 * ⭐ THE SECOND DECISION IN THE GAME, and it is a real one: the causeway buys salt and potash as
 * well as soda, so a works can pay for itself long before it can make soda ash. But the LEASE is
 * written in soda, and every tonne of salt you sell is a tonne that is not going into the furnace.
 * Selling raw is how you survive year one and how you lose year eight.
 */
const PRICES = { brine: 0, liquor: 0, salt: 2.0, bittern: 0.4, potash: 4.5, soda: 18 };
const CONTRACT_SODA_PRICE = 24;    /* the `contract` upgrade */

/* ── RESEARCH ─────────────────────────────────────────────────────────────────────────────────
 * Layered upgrades, paced by CUMULATIVE SODA EXPORTED rather than by clock — a player who builds
 * well reaches the next tier sooner, which is what pacing is supposed to mean.
 * Order matters: the research mark sheet is generated in this order.
 */
const RESEARCH = [
  { id: 'deepwell', name: 'Deep sinking', cost: 120, needSoda: 0, line: 'A well reads the four cells around it as well as its own.' },
  { id: 'linedpans', name: 'Lined pans', cost: 100, needSoda: 0, line: 'Pans stop losing liquor into the bed. +30% pan rate.' },
  { id: 'hoppers', name: 'Hoppers', cost: 90, needSoda: 0, line: 'Cisterns hold half as much again and pass it on faster.' },
  { id: 'gangs', name: 'Second gang', cost: 160, needSoda: 60, line: 'Two more crew, and they arrive a third faster.' },
  { id: 'windrow', name: 'Windrowing', cost: 220, needSoda: 60, line: 'Crystallisers work the beds in rows. +30%.' },
  { id: 'doublestill', name: 'Double still', cost: 280, needSoda: 120, line: 'Stills run a second pass. +40%.' },
  { id: 'sondes', name: 'Sondes', cost: 260, needSoda: 120, line: 'Wells read the bed before they take it. 35% less depletion.' },
  { id: 'covers', name: 'Pan covers', cost: 380, needSoda: 220, line: 'The pans keep some heat through RAIN. Season sun never falls below 0.62.' },
  { id: 'tramway', name: 'Tramway', cost: 460, needSoda: 220, line: 'The railhead reaches one column further west. Two columns now export.' },
  { id: 'bitternpump', name: 'Bittern pump', cost: 480, needSoda: 380, line: 'Crystallisers recover a third more bittern.' },
  { id: 'calciner', name: 'Calciner', cost: 620, needSoda: 380, line: 'The soda works burns hotter. +45%.' },
  { id: 'lighters', name: 'Lighters', cost: 620, needSoda: 520, line: 'Cisterns move soda half as fast again, and the causeway ships more.' },
  { id: 'artesian', name: 'Artesian bore', cost: 700, needSoda: 520, line: 'The bed recharges half as fast again everywhere.' },
  { id: 'gradient', name: 'Graded pans', cost: 760, needSoda: 700, line: 'Pans feed each other. Each adjacent pan is worth +11% instead of +7%.' },
  { id: 'contract', name: 'Long contract', cost: 800, needSoda: 700, line: 'The railhead pays 24 a tonne for soda instead of 18.' },
  { id: 'furnace', name: 'Regenerative furnace', cost: 1100, needSoda: 860, line: 'The soda works needs one less salt per batch.' },
];

/* ── THE VERDICT ──────────────────────────────────────────────────────────────────────────────
 * Read against ORDER_SODA at the end of the lease. Descending: the first match wins.
 */
const VERDICTS = [
  { at: 1.50, id: 'bitterworks', title: 'THE BITTERWORKS', line: 'The company sends a man out with a new lease and a different tone of voice. He calls the bittern still "your process". It was always the bittern. Nobody else on the lake bothers with it, and nobody else on the lake is still open.' },
  { at: 1.00, id: 'renewed', title: 'RENEWED', line: 'The order is met and the lease is renewed on the same terms, which is what a lease being renewed means. The bed you leave behind is drier than the one you found and there is nothing in the contract about that.' },
  { at: 0.60, id: 'short', title: 'SHORT', line: 'Short of the order. The company takes what there is at the agreed price and does not renew. The pans will be here a long time after the paperwork.' },
  { at: 0.00, id: 'lapsed', title: 'LAPSED', line: 'The lease lapses. Salt keeps forming in the pans for a season or two out of habit, and then the bed takes them back.' },
];

/* ── AUDIO ────────────────────────────────────────────────────────────────────────────────────
 * Everything here was composed or synthesised by the factory's own tools (Kernel/capture/
 * make_audio.js): our own IP, no licence, no attribution, and — because self-contained procedural
 * synthesis is not generative AI — the itch AI disclosure for SOUNDS is honestly "no".
 *
 * ⚠️ `loopSeconds` is the SCORE's length (32 beats at 60bpm), not the file's: the renderer leaves
 * the release tail on the end, so playing the file with plain `loop` puts a hole in the music every
 * pass. The player sets loopEnd to this number instead.
 */
const AUDIO = {
  theme: 'audio/bitterworks_theme.ogg',
  loopSeconds: 32,
  sfx: {
    place: 'audio/sfx_place.wav',
    sell: 'audio/sfx_sell.wav',
    research: 'audio/sfx_research.wav',
    season: 'audio/sfx_season.wav',
    deny: 'audio/sfx_deny.wav',
    dry: 'audio/sfx_dry.wav',
  },
};

const DATA = {
  AUDIO,
  BOARD, MATERIALS, MACHINES, SEASONS, SEASON_LENGTH, RESEARCH, VERDICTS,
  LEASE_YEARS, ORDER_SODA, START_MARKS, START_CREW, CREW_PERIOD, CREW_CAP,
  PRICES, CONTRACT_SODA_PRICE,
  machine: (id) => MACHINES.find((m) => m.id === id) || null,
  material: (id) => MATERIALS.find((m) => m.id === id) || null,
  research: (id) => RESEARCH.find((r) => r.id === id) || null,
};

if (typeof window !== 'undefined') window.DATA = DATA;
if (typeof module !== 'undefined' && module.exports) module.exports = DATA;
