/* BITTERWORKS — sound.js
 *
 * A composed loop and six cues, all rendered by the factory's own synth from
 * Internal_Ops/make_music.js and make_sfx.js, plus one live WebAudio layer: the WIND, which is the
 * only sound on a salt flat and is generated here rather than shipped as a file.
 *
 * No files we did not make, no licences, no attribution burden — and per Playbook_itch §15f the
 * itch AI disclosure for SOUNDS is honestly "no", because self-contained procedural synthesis is
 * not generative AI.
 *
 * ⭐ THE SOUNDSCAPE FOLLOWS THE SEASON, because the season is the thing a player most needs to feel
 * without reading: the wind opens up and goes dry and bright in GLARE, and closes down to a wet
 * hiss in RAIN. Nothing loops audibly and nothing is a jingle.
 *
 * ⚠️ AUTOPLAY POLICY: browsers refuse to start audio without a gesture. The context is created
 * lazily on the first click and every entry point re-checks, so a muted first frame can never leave
 * the game permanently silent.
 */
'use strict';

const SOUND = (() => {
  let ctx = null, master = null, windGain = null, windFilter = null;
  let started = false, muted = false;
  let music = null, musicGain = null, musicBuf = null;
  const buffers = {};

  function ensure() {
    if (ctx) return true;
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return false;
      ctx = new AC();
      master = ctx.createGain();
      master.gain.value = muted ? 0 : 0.55;
      master.connect(ctx.destination);
      return true;
    } catch (e) { ctx = null; return false; }
  }

  let noiseBuf = null;
  function noise() {
    if (noiseBuf) return noiseBuf;
    const len = Math.floor(ctx.sampleRate * 3);
    noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0;
    for (let i = 0; i < len; i++) {
      const w = Math.random() * 2 - 1;
      b0 = 0.99765 * b0 + w * 0.0990460;
      b1 = 0.96300 * b1 + w * 0.2965164;
      b2 = 0.57000 * b2 + w * 1.0526913;
      d[i] = (b0 + b1 + b2 + w * 0.1848) * 0.16;
    }
    return noiseBuf;
  }

  /** Fetch and decode a file into an AudioBuffer. A failure is silent by design: no audio must
   *  never mean no game (and `fetch` of a local path fails under file://). */
  function loadBuffer(url, key) {
    if (typeof fetch !== 'function') return Promise.resolve(null);
    return fetch(url)
      .then((r) => (r.ok ? r.arrayBuffer() : Promise.reject(new Error('HTTP ' + r.status))))
      .then((ab) => new Promise((res, rej) => ctx.decodeAudioData(ab, res, rej)))
      .then((buf) => { buffers[key] = buf; return buf; })
      .catch(() => null);
  }

  function start() {
    if (started || !ensure()) return;
    started = true;

    const src = ctx.createBufferSource();
    src.buffer = noise();
    src.loop = true;
    windFilter = ctx.createBiquadFilter();
    windFilter.type = 'lowpass';
    windFilter.frequency.value = 520;
    windGain = ctx.createGain();
    windGain.gain.value = 0.15;
    src.connect(windFilter); windFilter.connect(windGain); windGain.connect(master);
    src.start();

    musicGain = ctx.createGain();
    musicGain.gain.value = 0.42;
    musicGain.connect(master);

    const A = window.DATA && window.DATA.AUDIO;
    if (!A) return;
    loadBuffer(A.theme, 'theme').then((buf) => {
      if (!buf) return;
      musicBuf = buf;
      music = ctx.createBufferSource();
      music.buffer = buf;
      music.loop = true;
      /* ⛔ loopEnd is the SCORE length, not the file length: the render leaves a release tail on
       * the end, and looping the whole file puts an audible hole in the music every pass. */
      music.loopStart = 0;
      music.loopEnd = Math.min(A.loopSeconds || buf.duration, buf.duration);
      music.connect(musicGain);
      music.start();
    });
    for (const [id, url] of Object.entries(A.sfx || {})) loadBuffer(url, id);
  }

  /** One cue. Missing buffers are simply not played. */
  function play(id, gain) {
    if (!ensure() || muted) return;
    const buf = buffers[id];
    if (!buf) return;
    const s = ctx.createBufferSource();
    s.buffer = buf;
    const g = ctx.createGain();
    g.gain.value = gain === undefined ? 0.55 : gain;
    s.connect(g); g.connect(master);
    s.start();
  }

  /** The wind follows the season: bright and open in GLARE, closed and wet in RAIN. */
  function season(id) {
    if (!ctx || !windFilter) return;
    const table = {
      thaw: [560, 0.13], glare: [1500, 0.24], gather: [760, 0.16], rain: [300, 0.10],
    };
    const [f, g] = table[id] || [600, 0.15];
    const t = ctx.currentTime;
    windFilter.frequency.cancelScheduledValues(t);
    windFilter.frequency.linearRampToValueAtTime(f, t + 2.5);
    windGain.gain.cancelScheduledValues(t);
    windGain.gain.linearRampToValueAtTime(muted ? 0 : g, t + 2.5);
  }

  function setMuted(m) {
    muted = !!m;
    if (master) master.gain.value = muted ? 0 : 0.55;
    return muted;
  }
  const isMuted = () => muted;

  return { start, play, season, setMuted, isMuted, get ready() { return started; } };
})();

if (typeof window !== 'undefined') window.SOUND = SOUND;
