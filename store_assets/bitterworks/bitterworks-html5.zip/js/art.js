/* BITTERWORKS — art.js
 *
 * Loads the generated PNGs and turns them into draw calls. Every pixel this file puts on screen
 * came out of Internal_Ops/plates.js or Internal_Ops/sprites.js — our own IP, no API, no licence,
 * no Gen-AI tag (§0-ART source (a)). Nothing here draws a shape with a path; if something is
 * missing from a sheet, the fix is in the generator, not in a `ctx.arc`.
 *
 * ⛔ SHEET LAYOUTS COME FROM art/sheets.json, WHICH THE GENERATOR WRITES. They are never retyped
 * here: two places both meaning "column 4 of the machine sheet is the soda works" is exactly the
 * stale-duplicate defect the master constitution keeps recording.
 */
'use strict';

const ART = (() => {
  const imgs = {};
  let sheets = null;
  let ready = false;

  const FILES = {
    pan: 'art/plate_pan.png',
    crust: 'art/plate_crust.png',
    silt: 'art/plate_silt.png',
    water: 'art/plate_water.png',
    causeway: 'art/plate_causeway.png',
    machines: 'art/sheet_machines.png',
    track: 'art/sheet_track.png',
    marks: 'art/sheet_marks.png',
    icons: 'art/sheet_icons.png',
    status: 'art/sheet_status.png',
  };

  function load() {
    const jobs = Object.entries(FILES).map(([name, src]) => new Promise((res) => {
      const im = new Image();
      im.onload = () => { imgs[name] = im; res(true); };
      /* ⚠️ A MISSING IMAGE RESOLVES, IT DOES NOT REJECT. One 404 must not stop the game starting:
       * `ready` still flips, `missing()` reports the gap, and the board falls back to flat colour.
       * A black screen tells a player nothing. */
      im.onerror = () => { res(false); };
      im.src = src;
    }));
    /* ⚠️ fetch() of a local file fails under file://, which is how a player unzips and opens the
     * game by hand. The manifest is therefore OPTIONAL and every draw call has a fallback. */
    const manifest = (typeof fetch === 'function'
      ? fetch('art/sheets.json').then((r) => r.json()).then((j) => { sheets = j; }).catch(() => { sheets = null; })
      : Promise.resolve());
    return Promise.all([...jobs, manifest]).then(() => { ready = true; return { ready, sheets }; });
  }

  const missing = () => Object.keys(FILES).filter((n) => !imgs[n]);

  const patterns = {};
  function pattern(ctx, name) {
    if (patterns[name]) return patterns[name];
    if (!imgs[name]) return null;
    patterns[name] = ctx.createPattern(imgs[name], 'repeat');
    return patterns[name];
  }

  const FALLBACK = { pan: '#7a6b5d', crust: '#cfb4ab', silt: '#4b4f31', water: '#155a58', causeway: '#333d50' };

  /** Fill a rect with a tiling plate, anchored to the CANVAS so the ground is continuous across
   *  cells rather than restarting in each one — a restart draws a grid nobody asked for. */
  function plate(ctx, name, x, y, w, h) {
    const p = pattern(ctx, name);
    if (!p) { ctx.fillStyle = FALLBACK[name] || '#333'; ctx.fillRect(x, y, w, h); return; }
    ctx.save();
    ctx.fillStyle = p;
    ctx.fillRect(x, y, w, h);
    ctx.restore();
  }

  const cellOf = (sheet, dflt) => (sheets && sheets[sheet] && sheets[sheet].cell) || dflt;
  const orderOf = (sheet) => (sheets && sheets[sheet] && sheets[sheet].order) || null;
  const colsOf = (sheet, dflt) => (sheets && sheets[sheet] && sheets[sheet].cols) || dflt;

  function indexOf(sheet, id, fallbackList) {
    const o = orderOf(sheet);
    if (o) { const i = o.indexOf(id); if (i >= 0) return i; }
    if (fallbackList) { const i = fallbackList.indexOf(id); if (i >= 0) return i; }
    return -1;
  }

  function drawMachine(ctx, id, running, x, y, size) {
    const im = imgs.machines;
    if (!im) return false;
    const [w, h] = cellOf('machines', [64, 64]);
    const col = indexOf('machines', id, window.DATA ? window.DATA.MACHINES.map((m) => m.id) : null);
    if (col < 0) return false;
    ctx.drawImage(im, col * w, (running ? 1 : 0) * h, w, h, Math.round(x), Math.round(y), size, size);
    return true;
  }

  function drawTrack(ctx, x, y, size) {
    const im = imgs.track;
    if (!im) return false;
    ctx.drawImage(im, 0, 0, im.width, im.height, Math.round(x), Math.round(y), size, size);
    return true;
  }

  function drawMark(ctx, id, x, y, size) {
    const im = imgs.marks;
    if (!im) return false;
    const [w, h] = cellOf('marks', [24, 24]);
    const cols = colsOf('marks', 8);
    const i = indexOf('marks', id, window.DATA ? window.DATA.RESEARCH.map((r) => r.id) : null);
    if (i < 0) return false;
    ctx.drawImage(im, (i % cols) * w, Math.floor(i / cols) * h, w, h, Math.round(x), Math.round(y), size, size);
    return true;
  }

  function drawIcon(ctx, id, x, y, size) {
    const im = imgs.icons;
    if (!im) return false;
    const [w, h] = cellOf('icons', [20, 20]);
    const fallback = window.DATA
      ? window.DATA.MATERIALS.map((m) => m.id).concat(window.DATA.SEASONS.map((s) => s.id))
      : null;
    const i = indexOf('icons', id, fallback);
    if (i < 0) return false;
    ctx.drawImage(im, i * w, 0, w, h, Math.round(x), Math.round(y), size, size);
    return true;
  }

  function drawStatus(ctx, id, x, y, size) {
    const im = imgs.status;
    if (!im) return false;
    const [w, h] = cellOf('status', [16, 16]);
    const i = indexOf('status', id, ['dry', 'jammed', 'venting']);
    if (i < 0) return false;
    ctx.drawImage(im, i * w, 0, w, h, Math.round(x), Math.round(y), size, size);
    return true;
  }

  /**
   * ⭐ THE DRAWDOWN VEIL — the one place the second system becomes visible without a number.
   * A cell darkens as its brine is pumped out and darkens FURTHER, permanently, as its capacity
   * is exhausted, so the works leaves a visible scar on the bed behind it.
   *
   * ⚠️ `multiply` with a colour, not a flat grey wash: a translucent grey greys the plates and the
   * ground stops looking like ground and starts looking like a spreadsheet.
   */
  function drawdown(ctx, x, y, w, h, wet, spent) {
    if (wet < 0.999) {
      ctx.save();
      ctx.globalCompositeOperation = 'multiply';
      ctx.globalAlpha = Math.min(0.62, (1 - wet) * 0.68);
      ctx.fillStyle = '#4a3a2c';
      ctx.fillRect(x, y, w, h);
      ctx.restore();
    }
    if (spent > 0.01) {
      ctx.save();
      ctx.globalCompositeOperation = 'multiply';
      ctx.globalAlpha = Math.min(0.55, spent * 0.6);
      ctx.fillStyle = '#6b5a4a';
      ctx.fillRect(x, y, w, h);
      ctx.restore();
    }
  }

  /** An image element for a single sheet cell, used by the DOM panel so the icons in the text are
   *  the same pictures as the icons on the board. */
  function iconCanvas(id, size) {
    const cv = document.createElement('canvas');
    cv.width = size; cv.height = size;
    const g = cv.getContext('2d');
    g.imageSmoothingEnabled = false;
    drawIcon(g, id, 0, 0, size);
    return cv;
  }

  function markCanvas(id, size) {
    const cv = document.createElement('canvas');
    cv.width = size; cv.height = size;
    const g = cv.getContext('2d');
    g.imageSmoothingEnabled = false;
    drawMark(g, id, 0, 0, size);
    return cv;
  }

  function machineCanvas(id, size) {
    const cv = document.createElement('canvas');
    cv.width = size; cv.height = size;
    const g = cv.getContext('2d');
    g.imageSmoothingEnabled = false;
    drawMachine(g, id, false, 0, 0, size);
    return cv;
  }

  return {
    load, missing, plate, drawdown,
    drawMachine, drawTrack, drawMark, drawIcon, drawStatus,
    iconCanvas, markCanvas, machineCanvas,
    get sheets() { return sheets; },
    get ready() { return ready; },
    get images() { return imgs; },
  };
})();

if (typeof window !== 'undefined') window.ART = ART;
