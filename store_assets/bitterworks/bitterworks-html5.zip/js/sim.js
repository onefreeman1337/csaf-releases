/* BITTERWORKS — sim.js
 *
 * The whole simulation, headless. It draws nothing, reads no DOM and touches no timer, so the
 * campaign probe and the unit tests run the SAME code the browser runs. Wing doctrine §3f-1 is
 * blunt about why that matters: SWALLET was measured completely unplayable twice while all 54 of
 * its unit assertions passed, because the assertions tested pieces and nobody made the economy
 * play itself.
 *
 * THE THREE SYSTEMS, and they are separate on purpose:
 *   1. THE WORKS  — machines on a fixed grid, linked by orthogonal adjacency only. No belts.
 *   2. THE BED    — a per-cell subsurface brine field, depleted by pumping, recharged by
 *                   diffusion from its neighbours and by inflow from the lake to the west.
 *   3. THE YEAR   — four seasons that scale the sun (pans) and the recharge (bed) in OPPOSITE
 *                   directions, and a shoreline that retreats and exposes new bed.
 */
'use strict';

(function (root, factory) {
  const SIM = factory(typeof require === 'function' && typeof module !== 'undefined'
    ? require('./data.js')
    : root.DATA);
  if (typeof module !== 'undefined' && module.exports) module.exports = SIM;
  if (root) root.SIM = SIM;
}(typeof globalThis !== 'undefined' ? globalThis : this, (D) => {

  /* ── deterministic noise ────────────────────────────────────────────────────────────────── */

  function mulberry32(a) {
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /** Smooth value noise on a coarse lattice, bilinearly interpolated. Small and deterministic. */
  function valueField(cols, rows, lat, rnd) {
    const gw = Math.ceil(cols / lat) + 2, gh = Math.ceil(rows / lat) + 2;
    const g = [];
    for (let j = 0; j < gh; j++) { const r = []; for (let i = 0; i < gw; i++) r.push(rnd()); g.push(r); }
    const sm = (t) => t * t * (3 - 2 * t);
    const out = [];
    for (let y = 0; y < rows; y++) {
      const r = [];
      for (let x = 0; x < cols; x++) {
        const fx = x / lat, fy = y / lat;
        const x0 = Math.floor(fx), y0 = Math.floor(fy);
        const tx = sm(fx - x0), ty = sm(fy - y0);
        const a = g[y0][x0] * (1 - tx) + g[y0][x0 + 1] * tx;
        const b = g[y0 + 1][x0] * (1 - tx) + g[y0 + 1][x0 + 1] * tx;
        r.push(a * (1 - ty) + b * ty);
      }
      out.push(r);
    }
    return out;
  }

  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const clamp01 = (v) => clamp(v, 0, 1);

  /* ── constants the designer tunes, kept next to the code that uses them ─────────────────── */

  /* ⛔ THESE THREE NUMBERS ARE THE GAME'S SECOND SYSTEM AND THE FIRST DRAFT OF THEM DELETED IT.
   * With INFLOW at 0.075 the probe finished a whole lease with the bed still at 91-98% of its
   * capacity and the relocate-the-wells policy making ZERO moves — i.e. the depleting field, which
   * is the entire Gate 2 claim, was measurably not happening. A well must outrun its own recharge
   * by a clear margin or the ground is scenery. */
  const DEPLETE = 0.0035;      /* bed lost per unit of brine drawn */
  /* ⛔⭐ EXHAUSTION IS WHAT MAKES THE GROUND MOVE, AND IT HAD TO BE STRUCTURAL RATHER THAN TUNED.
   * The first three drafts tried to get "a well that was excellent in year one is a dry hole in
   * year four" out of depletion-versus-recharge alone, and the probe measured wells finishing the
   * whole lease at 70% of capacity with a yield of 0.74 — i.e. the claim was FALSE and would have
   * shipped as a Gate 2 argument. Any equilibrium between a draw and a recharge is a stable point,
   * so tuning it harder only moves the stable point; it never produces a well that dies.
   * A small share of every tonne drawn therefore comes out of the cell's CAPACITY and does not
   * come back — the fossil brine under a drying lake is finite, which is the one true thing about
   * a drying lake. `sondes` slows it; `deepwell` spreads it over five cells; nothing stops it. */
  const EXHAUST = 0.00012;     /* permanent capacity lost per unit of brine drawn */
  const DIFFUSE = 0.018;       /* bed levelling between neighbours, per second at recharge 1 */
  const INFLOW = 0.030;        /* bed refilled from the lake, per second, at the water's edge */
  const INFLOW_FALLOFF = 1.8;  /* how fast that dies with distance from the water — see bed() */
  const FLOW = 11;             /* units per second a machine can push out, per material */
  const CIST_FLOW = 7;         /* a cistern relays more slowly than a machine feeds */
  const EXPORT_FLOW = 6;       /* soda per second one causeway cell can put on the tram */
  const PAN_ADJ = 0.07;        /* per adjacent pan */
  const PAN_ADJ_GRADED = 0.11;

  const yearLength = () => D.SEASON_LENGTH * D.SEASONS.length;

  /* ── state ──────────────────────────────────────────────────────────────────────────────── */

  function newGame(seed) {
    const s = {
      seed: (seed === undefined || seed === null) ? 1337 : (seed | 0),
      t: 0,
      speed: 1,
      paused: false,
      marks: D.START_MARKS,
      crew: D.START_CREW,
      crewClock: 0,
      shoreline: D.BOARD.shorelineStart,
      cells: [],                 /* row-major, cells[y][x] = { bed, cap, m } */
      done: {},                  /* research id -> true */
      exported: 0,               /* cumulative soda on the tram */
      earned: 0,
      ended: false,
      verdict: null,
      freeWorks: false,
      log: [],
      sold: {},                  /* material id -> tonnes put on the tram */
      wasted: {},                /* material id -> tonnes tipped back into the bed */
      stats: { built: 0, moved: 0, demolished: 0, driedOut: 0 },
    };
    const rnd = mulberry32(s.seed * 2654435761 % 2147483647 || 7);
    const f = valueField(D.BOARD.cols, D.BOARD.rows, 3, rnd);
    for (let y = 0; y < D.BOARD.rows; y++) {
      const row = [];
      for (let x = 0; x < D.BOARD.cols; x++) {
        /* Brine is strongest under the water's edge in the west and weakest in the long-dry east.
         * The noise decides the detail; the gradient decides the argument. */
        const west = 1 - (x / (D.BOARD.cols - 1));
        const cap = clamp(0.34 + west * 0.46 + (f[y][x] - 0.5) * 0.36, 0.12, 1);
        row.push({ bed: cap, cap, cap0: cap, m: null });
      }
      s.cells.push(row);
    }
    return s;
  }

  const at = (s, x, y) => (x < 0 || y < 0 || x >= D.BOARD.cols || y >= D.BOARD.rows ? null : s.cells[y][x]);
  const NB = [[1, 0], [-1, 0], [0, 1], [0, -1]];
  const neighbours = (s, x, y) => NB.map(([dx, dy]) => at(s, x + dx, y + dy)).filter(Boolean);

  const seasonIndex = (s) => Math.floor((s.t % yearLength()) / D.SEASON_LENGTH) % D.SEASONS.length;
  const season = (s) => D.SEASONS[seasonIndex(s)];
  const year = (s) => Math.floor(s.t / yearLength()) + 1;
  /** Pan covers put a floor under the worst season rather than raising every season. */
  const sunOf = (s) => (s.done.covers ? Math.max(season(s).sun, 0.62) : season(s).sun);
  const exportCol = (s) => (s.done.tramway ? D.BOARD.cols - 2 : D.BOARD.cols - 1);
  const isWater = (s, x) => x < s.shoreline;
  const isExport = (s, x) => x >= exportCol(s);

  function say(s, text) {
    s.log.unshift({ t: s.t, text });
    if (s.log.length > 40) s.log.length = 40;
  }

  /* ── building ───────────────────────────────────────────────────────────────────────────── */

  function costOf(id) { const m = D.machine(id); return m ? m.cost : Infinity; }

  function canBuild(s, x, y, id) {
    const c = at(s, x, y);
    if (!c) return 'off the bed';
    if (isWater(s, x)) return 'still under water';
    if (c.m) return 'already built on';
    if (!D.machine(id)) return 'no such machine';
    if (s.marks < costOf(id)) return 'not enough marks';
    return null;
  }

  function build(s, x, y, id, material) {
    const why = canBuild(s, x, y, id);
    if (why) return { ok: false, why };
    const def = D.machine(id);
    s.marks -= def.cost;
    at(s, x, y).m = {
      /* `ran` starts at the moment it was built, not at zero: a machine put down at minute nine
       * has not "not run for nine minutes", it has not run yet, and the board should give it a
       * moment before it shouts. */
      id, buf: {}, running: false, ran: s.t,
      material: id === 'cistern' ? (material || 'brine') : null,
      builtAt: s.t,
    };
    s.stats.built++;
    return { ok: true };
  }

  function demolish(s, x, y) {
    const c = at(s, x, y);
    if (!c || !c.m) return { ok: false, why: 'nothing there' };
    s.marks += Math.floor(costOf(c.m.id) * 0.5);
    c.m = null;
    s.stats.demolished++;
    return { ok: true };
  }

  /** Relocating costs a crew, which is the scarce thing. Everything else costs marks. */
  function move(s, x0, y0, x1, y1) {
    const a = at(s, x0, y0), b = at(s, x1, y1);
    if (!a || !a.m) return { ok: false, why: 'nothing there' };
    if (!b) return { ok: false, why: 'off the bed' };
    if (b.m) return { ok: false, why: 'already built on' };
    if (isWater(s, x1)) return { ok: false, why: 'still under water' };
    if (s.crew < 1) return { ok: false, why: 'no crew free' };
    s.crew -= 1;
    b.m = a.m; a.m = null;
    b.m.buf = {};                    /* a machine in pieces on a cart is not holding anything */
    s.stats.moved++;
    return { ok: true };
  }

  function canResearch(s, id) {
    const r = D.research(id);
    if (!r) return 'no such work';
    if (s.done[id]) return 'already done';
    if (s.exported < r.needSoda) return `needs ${r.needSoda} soda exported`;
    if (s.marks < r.cost) return 'not enough marks';
    return null;
  }

  function research(s, id) {
    const why = canResearch(s, id);
    if (why) return { ok: false, why };
    s.marks -= D.research(id).cost;
    s.done[id] = true;
    say(s, `${D.research(id).name} put into the works.`);
    return { ok: true };
  }

  /* ── the tick ───────────────────────────────────────────────────────────────────────────── */

  const bufOf = (m, mat) => m.buf[mat] || 0;
  function capOf(s, m, mat) {
    const def = D.machine(m.id);
    let cap = def.cap;
    if (m.id === 'cistern' && s.done.hoppers) cap *= 1.5;
    return cap;
  }
  function addBuf(s, m, mat, q) {
    const room = capOf(s, m, mat) - bufOf(m, mat);
    const put = Math.min(room, q);
    if (put > 0) m.buf[mat] = bufOf(m, mat) + put;
    return put;
  }

  /** Multiplier on a machine's conversion rate, from research and (for pans) from the board. */
  function rateOf(s, m, x, y) {
    switch (m.id) {
      case 'pan': {
        let adj = 0;
        for (const n of neighbours(s, x, y)) if (n.m && n.m.id === 'pan') adj++;
        const per = s.done.gradient ? PAN_ADJ_GRADED : PAN_ADJ;
        return sunOf(s) * (1 + adj * per) * (s.done.linedpans ? 1.30 : 1);
      }
      case 'crystalliser': return s.done.windrow ? 1.30 : 1;
      case 'still': return s.done.doublestill ? 1.40 : 1;
      case 'sodaworks': return s.done.calciner ? 1.45 : 1;
      default: return 1;
    }
  }

  /** How much brine the ground under a well will give, 0..1. */
  function wellYield(s, x, y) {
    const c = at(s, x, y);
    let v = c.bed;
    if (s.done.deepwell) {
      let sum = c.bed, n = 1;
      for (const nb of neighbours(s, x, y)) { sum += nb.bed; n++; }
      v = sum / n;
    }
    return clamp01((v - 0.05) / 0.55);
  }

  function produce(s, dt) {
    for (let y = 0; y < D.BOARD.rows; y++) {
      for (let x = 0; x < D.BOARD.cols; x++) {
        const c = s.cells[y][x];
        const m = c.m;
        if (!m) continue;
        m.running = false;
        const def = D.machine(m.id);
        if (!def.recipe) continue;

        if (m.id === 'well') {
          const y0 = wellYield(s, x, y);
          if (y0 <= 0) continue;
          const want = def.recipe.out.brine / def.recipe.per * y0 * dt;
          const got = addBuf(s, m, 'brine', want);
          if (got <= 0) continue;
          /* ⛔ THE COST IS PAID BY THE GROUND, not by a counter. Deep sinking spreads the draw
           * over the plus shape it reads, which is why it is worth more than its rate bonus. */
          const soft = s.done.sondes ? 0.65 : 1;
          const drawn = got * DEPLETE * soft;
          const gone = got * EXHAUST * soft;
          const cells = s.done.deepwell ? [c].concat(neighbours(s, x, y)) : [c];
          for (const cc of cells) {
            cc.cap = Math.max(0.02, cc.cap - gone / cells.length);
            cc.bed = Math.max(0, Math.min(cc.cap, cc.bed - drawn / cells.length));
          }
          m.running = true; m.ran = s.t;
          continue;
        }

        const r = def.recipe;
        const vent = r.vent || [];
        const mul = rateOf(s, m, x, y) / r.per * dt;
        if (mul <= 0) continue;
        /* One batch scaled by dt, limited by the scarcest input and by output room. A VENTED
         * byproduct never limits the batch — it is tipped back into the bed instead. */
        let f = 1;
        for (const [mat, q] of Object.entries(r.in)) {
          const need = q * mul;
          const have = bufOf(m, mat);
          if (need > 0) f = Math.min(f, have / need);
        }
        for (const [mat, q] of Object.entries(r.out)) {
          if (vent.includes(mat)) continue;
          const room = capOf(s, m, mat) - bufOf(m, mat);
          const make = q * mul;
          if (make > 0) f = Math.min(f, room / make);
        }
        if (!(f > 0.0001)) continue;
        for (const [mat, q] of Object.entries(r.in)) {
          let use = q * mul * f;
          if (m.id === 'sodaworks' && mat === 'salt' && s.done.furnace) use *= 0.5;
          m.buf[mat] = Math.max(0, bufOf(m, mat) - use);
        }
        for (const [mat, q] of Object.entries(r.out)) {
          let make = q * mul * f;
          if (m.id === 'crystalliser' && mat === 'bittern' && s.done.bitternpump) make *= 1.33;
          const took = addBuf(s, m, mat, make);
          if (vent.includes(mat)) s.wasted[mat] = (s.wasted[mat] || 0) + (make - took);
        }
        m.running = true; m.ran = s.t;
      }
    }
  }

  /** Does this machine burn that material, as opposed to merely holding and passing it on? */
  function consumes(m, mat) {
    const def = D.machine(m.id);
    return !!(def.recipe && def.recipe.in && def.recipe.in[mat] > 0);
  }

  /**
   * What a machine is currently offering to its neighbours.
   *
   * ⭐ THE PAN CASCADE IS THE REASON THIS IS NOT JUST `recipe.out`. A real salt works runs brine
   * through a SERIES of pans, each one giving up a little more water, and a pan that is brimming
   * passes its surplus down the line rather than overflowing. So a pan offers its liquor always,
   * and its brine once it is more than three-fifths full. Without that, a second column of pans
   * is decoration: it cannot reach a well and produces nothing.
   */
  function offers(s, m) {
    if (m.id === 'cistern') return bufOf(m, m.material) > 0 ? [m.material] : [];
    const def = D.machine(m.id);
    if (!def.recipe) return [];
    const out = Object.keys(def.recipe.out).filter((mat) => bufOf(m, mat) > 0);
    if (m.id === 'pan' && bufOf(m, 'brine') > 0.6 * capOf(s, m, 'brine')) out.push('brine');
    return out;
  }

  /**
   * Can this machine take that material from a neighbour, and does it want it right now?
   *
   * ⛔ THE BALANCE CLAUSE IS LOAD BEARING AND IT WAS FOUND BY THE PROBE, NOT BY READING THE CODE.
   * A machine with two inputs — only the soda works — will otherwise fill itself to the brim with
   * whichever input arrives first and sit there. That is not a slow start, it is a hard deadlock:
   * the soda works fills with salt, so the crystalliser cannot pass salt on, so it stops, so it
   * makes no bittern, so the still makes no potash, so the soda works never gets the other half of
   * its recipe. The probe measured it as a works that froze in year 3 with every buffer full.
   * A furnace that will not take a sixth batch of salt while it has no potash cannot deadlock.
   */
  const SLACK_BATCHES = 6;
  function wants(s, m, mat) {
    const def = D.machine(m.id);
    if (!def.takes.includes(mat)) return false;
    if (m.id === 'cistern') return m.material === mat && bufOf(m, mat) < capOf(s, m, mat);
    if (!(bufOf(m, mat) < capOf(s, m, mat))) return false;
    const inp = def.recipe && def.recipe.in;
    if (inp && inp[mat] > 0 && Object.keys(inp).length > 1) {
      const mine = bufOf(m, mat) / inp[mat];
      let other = Infinity;
      for (const [k, q] of Object.entries(inp)) {
        if (k === mat) continue;
        other = Math.min(other, bufOf(m, k) / q);
      }
      if (mine > other + SLACK_BATCHES) return false;
    }
    return true;
  }

  const fill = (s, m, mat) => bufOf(m, mat) / capOf(s, m, mat);

  function transfer(s, dt) {
    for (let y = 0; y < D.BOARD.rows; y++) {
      for (let x = 0; x < D.BOARD.cols; x++) {
        const m = s.cells[y][x].m;
        if (!m) continue;
        for (const mat of offers(s, m)) {
          const takers = [];
          for (const [dx, dy] of NB) {
            const n = at(s, x + dx, y + dy);
            if (!n || !n.m || !wants(s, n.m, mat)) continue;
            /* ⭐ MATERIAL RUNS DOWN THE FILL GRADIENT. A machine that BURNS the material is always
             * a sink and always accepts. A machine that only holds it — a cistern, or a pan being
             * handed liquor or surplus brine — accepts only from a fuller neighbour, with
             * hysteresis, or two of them pass one tonne back and forth forever and the works looks
             * alive while doing nothing. */
            const gradient = !consumes(n.m, mat)
              || (mat === 'brine' && m.id === 'pan' && n.m.id === 'pan');
            if (gradient && fill(s, n.m, mat) >= fill(s, m, mat) - 0.02) continue;
            takers.push(n.m);
          }
          if (!takers.length) continue;
          let rate = m.id === 'cistern' ? CIST_FLOW : FLOW;
          if (m.id === 'cistern' && s.done.hoppers) rate *= 1.4;
          if (m.id === 'cistern' && mat === 'soda' && s.done.lighters) rate *= 2;
          const budget = Math.min(bufOf(m, mat), rate * dt);
          const each = budget / takers.length;
          let moved = 0;
          for (const t of takers) moved += addBuf(s, t, mat, each);
          m.buf[mat] = Math.max(0, bufOf(m, mat) - moved);
        }
      }
    }
  }

  /** The price the railhead pays today. Only soda has a contract. */
  function priceOf(s, mat) {
    if (mat === 'soda' && s.done.contract) return D.CONTRACT_SODA_PRICE;
    return D.PRICES[mat] || 0;
  }

  /**
   * ⭐ THE CAUSEWAY BUYS WHAT THE WORKS HAS NO USE FOR, and that one rule is the whole export
   * layer. A machine on the causeway sells only what it is OFFERING to its neighbours and only
   * when no neighbour wants it — so a potash cistern beside a soda works feeds the furnace
   * instead of selling out from under it, and moving that cistern one cell away is how you
   * choose to sell raw. The order is written in SODA and nothing else, so selling raw pays for
   * year one and costs you year eight.
   */
  function sellAtCauseway(s, dt) {
    for (let y = 0; y < D.BOARD.rows; y++) {
      for (let x = exportCol(s); x < D.BOARD.cols; x++) {
        const m = s.cells[y][x].m;
        if (!m) continue;
        let budget = EXPORT_FLOW * dt * (s.done.lighters ? 1.6 : 1);
        for (const mat of offers(s, m)) {
          if (budget <= 0) break;
          const price = priceOf(s, mat);
          if (price <= 0) continue;
          const held = bufOf(m, mat);
          if (held <= 0) continue;
          let claimed = false;
          for (const [dx, dy] of NB) {
            const n = at(s, x + dx, y + dy);
            if (n && n.m && wants(s, n.m, mat)) { claimed = true; break; }
          }
          if (claimed) continue;
          const out = Math.min(held, budget);
          budget -= out;
          m.buf[mat] = held - out;
          if (mat === 'soda') s.exported += out;
          s.sold[mat] = (s.sold[mat] || 0) + out;
          s.earned += out * price;
          s.marks += out * price;
        }
      }
    }
  }

  function bed(s, dt) {
    const rc = season(s).recharge * (s.done.artesian ? 1.5 : 1);
    const next = [];
    for (let y = 0; y < D.BOARD.rows; y++) {
      const row = [];
      for (let x = 0; x < D.BOARD.cols; x++) {
        const c = s.cells[y][x];
        let sum = 0, n = 0;
        for (const nb of neighbours(s, x, y)) { sum += nb.bed; n++; }
        const lap = n ? (sum / n) - c.bed : 0;
        /* ⭐ INFLOW FALLS OFF WITH DISTANCE FROM THE WATER, AND THE WATER MOVES. That single line
         * is what makes the good ground travel west during a run: a well dug beside the lake in
         * year one is three columns inland by year seven without anybody touching it, and its
         * recharge has fallen by five sixths. The bed does not "run out" so much as leave. */
        const dist = Math.max(0, x - s.shoreline);
        const inflow = (INFLOW / (1 + Math.pow(dist, INFLOW_FALLOFF))) * (c.cap - c.bed);
        row.push(clamp(c.bed + (DIFFUSE * lap + inflow) * rc * dt, 0, c.cap));
      }
      next.push(row);
    }
    for (let y = 0; y < D.BOARD.rows; y++) for (let x = 0; x < D.BOARD.cols; x++) s.cells[y][x].bed = next[y][x];
  }

  /**
   * Where the water's edge is, DERIVED from the clock rather than decremented on a year boundary.
   *
   * ⛔ THE FIRST VERSION SUBTRACTED ONE WHENEVER IT SAW A YEAR CHANGE, which is a value that can
   * drift: skip the boundary — by loading a save, or by any path that moves `t` without ticking
   * through it — and the shoreline is wrong for the rest of the run with nothing to catch it. The
   * test that found it did exactly that. A derived value cannot drift.
   */
  function shorelineFor(s) {
    const y = year(s);
    let sl = D.BOARD.shorelineStart;
    for (const at of D.BOARD.shorelineYears) if (y >= at) sl -= 1;
    return Math.max(0, sl);
  }

  function calendar(s, before) {
    const yl = yearLength();
    const y0 = Math.floor(before / yl) + 1, y1 = year(s);
    const sl = shorelineFor(s);
    if (sl !== s.shoreline) {
      s.shoreline = sl;
      say(s, `The water is off column ${sl + 1}. New bed, and the best brine on the lake sits on it.`);
    }
    if (y1 !== y0) {
      say(s, `Year ${y1} opens.`);
      if (y1 > D.LEASE_YEARS && !s.ended) finish(s);
    }
    const s0 = Math.floor((before % yl) / D.SEASON_LENGTH) % D.SEASONS.length;
    const s1 = seasonIndex(s);
    if (s1 !== s0) say(s, `${season(s).name}. ${season(s).line}`);
  }

  function finish(s) {
    s.ended = true;
    const ratio = s.exported / D.ORDER_SODA;
    s.verdict = D.VERDICTS.find((v) => ratio >= v.at) || D.VERDICTS[D.VERDICTS.length - 1];
    s.verdictRatio = ratio;
    say(s, `The lease is up. ${s.verdict.title}.`);
  }

  function crewTick(s, dt) {
    const cap = D.CREW_CAP + (s.done.gangs ? 2 : 0);
    if (s.crew >= cap) { s.crewClock = 0; return; }
    s.crewClock += dt * (s.done.gangs ? 1.33 : 1);
    if (s.crewClock >= D.CREW_PERIOD) { s.crewClock -= D.CREW_PERIOD; s.crew++; say(s, 'A hand walks out along the causeway looking for work.'); }
  }

  /**
   * One step. `dt` is REAL seconds already multiplied by the speed control; the caller owns the
   * clock. Steps larger than 0.5 s are split, because the transfer stage is a fixed-rate flow and
   * a large step would let material cross the whole board in one frame.
   */
  function tick(s, dt) {
    if (s.paused) return;
    let left = Math.min(dt, 8);
    while (left > 0) {
      const h = Math.min(left, 0.25);
      left -= h;
      const before = s.t;
      s.t += h;
      produce(s, h);
      transfer(s, h);
      sellAtCauseway(s, h);
      bed(s, h);
      crewTick(s, h);
      calendar(s, before);
      if (s.ended && !s.freeWorks) { s.t = before + h; break; }
    }
  }

  /* ── read-only helpers the UI and the probe both use ────────────────────────────────────── */

  function totals(s) {
    const t = {};
    for (const mat of D.MATERIALS) t[mat.id] = 0;
    for (let y = 0; y < D.BOARD.rows; y++) for (let x = 0; x < D.BOARD.cols; x++) {
      const m = s.cells[y][x].m;
      if (!m) continue;
      for (const [k, v] of Object.entries(m.buf)) t[k] = (t[k] || 0) + v;
    }
    return t;
  }

  function count(s, id) {
    let n = 0;
    for (let y = 0; y < D.BOARD.rows; y++) for (let x = 0; x < D.BOARD.cols; x++) {
      if (s.cells[y][x].m && s.cells[y][x].m.id === id) n++;
    }
    return n;
  }

  /** Every cell a machine could legally go on right now. */
  function openCells(s) {
    const out = [];
    for (let y = 0; y < D.BOARD.rows; y++) for (let x = 0; x < D.BOARD.cols; x++) {
      if (!isWater(s, x) && !s.cells[y][x].m) out.push([x, y]);
    }
    return out;
  }

  return {
    newGame, tick, build, demolish, move, research, canBuild, canResearch,
    at, neighbours, totals, count, openCells,
    season, seasonIndex, year, sunOf, exportCol, isWater, isExport, wellYield, rateOf, priceOf,
    shorelineFor,
    yearLength, finish, say,
    consts: { DEPLETE, DIFFUSE, INFLOW, FLOW, CIST_FLOW, EXPORT_FLOW, PAN_ADJ },
  };
}));
