/* BITTERWORKS — save.js
 *
 * The wing's standing design rule is save/resume, never a full restart (ledger B4). This game has
 * no death to punish anybody with, so the rule shows up as: the run is written after every action
 * and every few seconds of play, and closing the tab loses nothing.
 *
 * ⚠️ localStorage throws in some privacy modes and when a quota is full. Every entry point here
 * swallows that and reports it once, because a game that refuses to start because it cannot save
 * is worse than a game that cannot save.
 */
'use strict';

const SAVE = (() => {
  const KEY = 'bitterworks.run.v1';
  let warned = false;

  function ok() {
    try { return typeof localStorage !== 'undefined'; } catch (e) { return false; }
  }

  function write(state) {
    if (!ok()) return false;
    try {
      localStorage.setItem(KEY, JSON.stringify({ v: 1, at: Date.now(), state }));
      return true;
    } catch (e) {
      if (!warned) { warned = true; console.warn('BITTERWORKS: cannot save — ' + e.message); }
      return false;
    }
  }

  function read() {
    if (!ok()) return null;
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return null;
      const j = JSON.parse(raw);
      if (!j || j.v !== 1 || !j.state) return null;
      return j.state;
    } catch (e) { return null; }
  }

  function clear() {
    if (!ok()) return;
    try { localStorage.removeItem(KEY); } catch (e) { /* nothing to do */ }
  }

  const has = () => read() !== null;

  return { write, read, clear, has, KEY };
})();

if (typeof window !== 'undefined') window.SAVE = SAVE;
