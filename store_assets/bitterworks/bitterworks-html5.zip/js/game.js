/* BITTERWORKS — game.js
 *
 * The board, the panel and the input. The SIMULATION is in sim.js and this file never duplicates a
 * rule from it: everything drawn here is read back out of the state the headless simulation owns,
 * which is why the campaign probe and the browser can never disagree about how the works behaves.
 *
 * ⛔ THE CANVAS DRAWS NO TEXT. Every string in this game is a DOM node, so it wraps natively, and
 * the layout gate measures real boxes instead of guessing at `measureText` (wing §3e-1/§3e-2, where
 * a canvas string ran 1035px across a 960px canvas with 133 assertions green).
 */
'use strict';

(() => {
  const D = window.DATA, SIM = window.SIM, ART = window.ART, SAVE = window.SAVE, SOUND = window.SOUND;

  const CELL = 64;
  const $ = (id) => document.getElementById(id);
  const el = (tag, cls, text) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  };

  const board = $('board');
  const ctx = board.getContext('2d');
  ctx.imageSmoothingEnabled = false;

  let S = null;
  const ui = {
    tab: 'works',
    build: null,          /* machine id armed for placing */
    buildMat: 'brine',    /* which material a new cistern holds */
    sel: null,            /* [x,y] of the inspected cell */
    moving: null,         /* [x,y] of a machine waiting for a destination */
    hover: null,
    speed: 1,
    lastSave: 0,
    lastSeason: -1,
    started: false,
  };

  /* ── boot ───────────────────────────────────────────────────────────────────────────────── */

  /**
   * ⭐ THE BOARD IS BUILT AND DRAWN BEFORE THE TITLE CARD IS SHOWN, and the card is translucent
   * over it. The first draft put the title on a black rectangle, and the store screenshot of it was
   * about half empty frame — a title screen that shows the game behind it is both a better picture
   * and a more honest one, because it is the actual board this run will be played on.
   */
  function boot() {
    ART.load().then(() => {
      const miss = ART.missing();
      if (miss.length) console.warn('BITTERWORKS: missing art — ' + miss.join(', '));
      S = SAVE.read() || freshGame();
      const fresh = SIM.newGame(1);
      for (const k of Object.keys(fresh)) if (S[k] === undefined) S[k] = fresh[k];
      ui.speed = 0;
      render();
      title();
      requestAnimationFrame(loop);
    });
    bindEvents();
  }

  function freshGame() {
    const s = SIM.newGame(Date.now() & 0x7fffffff);
    SIM.say(s, 'The lease is signed. Eight years, ' + D.ORDER_SODA + ' tonnes of soda ash, and a lake that is going away.');
    SIM.say(s, 'Sink a well in the bed, run the brine east through pans to a crystalliser, and get something onto the causeway.');
    return s;
  }

  /** Start playing whatever board is already on screen — a restored save or the fresh one. */
  function begin() {
    ui.begun = true;
    ui.speed = 1;
    hideOverlay();
    forcePanel();
    render();
  }

  function newRun() {
    SAVE.clear();
    S = freshGame();
    ui.sel = null; ui.build = null; ui.moving = null;
    begin();
  }

  /* ── the loop ───────────────────────────────────────────────────────────────────────────── */

  let last = 0;
  function loop(now) {
    requestAnimationFrame(loop);
    if (!S) return;
    const dt = Math.min(0.25, (now - last) / 1000 || 0);
    last = now;

    if (ui.speed > 0 && !S.ended) {
      const before = SIM.seasonIndex(S);
      SIM.tick(S, dt * ui.speed);
      const after = SIM.seasonIndex(S);
      if (after !== before) { SOUND.play('season', 0.35); SOUND.season(SIM.season(S).id); }
      if (S.ended) { ui.speed = 0; ending(); }
    }

    render();

    if (now - ui.lastSave > 4000) { ui.lastSave = now; SAVE.write(S); }
  }

  /* ── drawing ────────────────────────────────────────────────────────────────────────────── */

  /** Which plate a cell shows. The ground itself tells the player what kind of ground it is. */
  function plateOf(x, y) {
    if (SIM.isWater(S, x)) return 'water';
    if (SIM.isExport(S, x)) return 'causeway';
    /* bed the lake gave up during THIS run still looks wet */
    if (x < D.BOARD.shorelineStart) return 'silt';
    return S.cells[y][x].cap0 >= 0.62 ? 'crust' : 'pan';
  }

  function render() {
    if (!S) return;
    const W = D.BOARD.cols, H = D.BOARD.rows;

    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const c = S.cells[y][x];
        const px = x * CELL, py = y * CELL;
        ART.plate(ctx, plateOf(x, y), px, py, CELL, CELL);

        if (!SIM.isWater(S, x)) {
          const wet = c.cap > 0 ? c.bed / c.cap : 0;
          const spent = c.cap0 > 0 ? 1 - c.cap / c.cap0 : 0;
          ART.drawdown(ctx, px, py, CELL, CELL, wet, spent);
        }
        if (SIM.isExport(S, x)) ART.drawTrack(ctx, px, py, CELL);

        if (c.m) {
          ART.drawMachine(ctx, c.m.id, !!c.m.running, px, py, CELL);
          drawBuffers(c.m, px, py);
          drawStatusOf(c, x, y, px, py);
        }

        /* the grid, quiet: it is a placement game, so the cells have to be countable */
        ctx.strokeStyle = 'rgba(20,16,11,0.36)';
        ctx.lineWidth = 1;
        ctx.strokeRect(px + 0.5, py + 0.5, CELL - 1, CELL - 1);
      }
    }

    /* the shoreline, drawn as an edge rather than announced in a message */
    if (S.shoreline > 0) {
      ctx.fillStyle = 'rgba(159, 214, 194, 0.30)';
      ctx.fillRect(S.shoreline * CELL - 2, 0, 3, H * CELL);
    }
    /* and the causeway edge */
    ctx.fillStyle = 'rgba(210, 185, 92, 0.28)';
    ctx.fillRect(SIM.exportCol(S) * CELL, 0, 2, H * CELL);

    if (ui.hover) highlight(ui.hover, 'rgba(237,227,212,0.42)');
    if (ui.sel) highlight(ui.sel, 'rgba(210,185,92,0.85)');
    if (ui.moving) highlight(ui.moving, 'rgba(180,89,60,0.9)');

    header();
    panelIfChanged();
    logView();
  }

  /**
   * ⛔ THE PANEL IS NOT REBUILT EVERY FRAME, AND THE FIRST DRAFT WAS. Rebuilding a DOM list sixty
   * times a second detaches every node between a player's mousedown and mouseup, so a click on a
   * machine row can land on an element that no longer exists — the browser smoke test caught it
   * immediately ("element was detached from the DOM, retrying", 59 times). It also killed the hover
   * state and reset the scroll position. Rebuild only when something a row DISPLAYS has changed.
   */
  let lastSig = '';
  function panelSig() {
    let running = 0, machines = 0;
    for (let y = 0; y < D.BOARD.rows; y++) {
      for (let x = 0; x < D.BOARD.cols; x++) {
        const m = S.cells[y][x].m;
        if (!m) continue;
        machines++;
        if (m.running) running += 1;
      }
    }
    return [
      ui.tab, ui.build, ui.buildMat, ui.sel && ui.sel.join(','), ui.moving && ui.moving.join(','),
      Math.floor(S.marks / 5), S.crew, Math.floor(S.exported / 5), Object.keys(S.done).length,
      SIM.seasonIndex(S), machines, running, Math.floor(S.t / 2),
    ].join('|');
  }
  function panelIfChanged() {
    const sig = panelSig();
    if (sig === lastSig) return;
    /* ⚠️ AND NEVER WHILE THE POINTER IS OVER IT. Even a twice-a-second rebuild can detach a row
     * between mousedown and mouseup and eat the click. A player reading the panel is not watching
     * a number tick; the refresh can wait for the pointer to leave. */
    if (ui.panelHot) return;
    lastSig = sig;
    panel();
  }

  function highlight([x, y], colour) {
    ctx.strokeStyle = colour;
    ctx.lineWidth = 2;
    ctx.strokeRect(x * CELL + 1, y * CELL + 1, CELL - 2, CELL - 2);
  }

  /** Contents, as pips along the bottom of the cell. No numbers on the canvas, ever. */
  function drawBuffers(m, px, py) {
    const def = D.machine(m.id);
    const mats = D.MATERIALS.filter((mm) => (m.buf[mm.id] || 0) > 0.05);
    if (!mats.length) return;
    const w = Math.floor((CELL - 8) / mats.length);
    mats.forEach((mm, i) => {
      const cap = m.id === 'cistern' ? def.cap * 1.5 : def.cap;
      const f = Math.max(0.06, Math.min(1, (m.buf[mm.id] || 0) / cap));
      const x = px + 4 + i * w, yb = py + CELL - 5;
      ctx.fillStyle = 'rgba(12,10,7,0.75)';
      ctx.fillRect(x, yb - 1, w - 2, 5);
      ctx.fillStyle = mm.colour;
      ctx.fillRect(x + 1, yb, Math.max(1, Math.round((w - 4) * f)), 3);
    });
  }

  function drawStatusOf(c, x, y, px, py) {
    const m = c.m;
    let mark = null;
    if (m.id === 'well' && SIM.wellYield(S, x, y) < 0.16) mark = 'dry';
    else if (m.id === 'crystalliser' && m.running && !hasBitternSink(x, y)) mark = 'venting';
    /* ⚠️ NOT "it is idle this instant". A machine in a working chain idles for a fraction of a
     * second constantly while it waits for the next batch, and marking that put an alarm on half
     * the board in a screenshot of a works that was running perfectly. A machine is only STOPPED
     * if it has not run for four seconds of game time. */
    else if (D.machine(m.id).recipe && S.t - (m.ran || 0) > 4) mark = 'jammed';
    if (mark) ART.drawStatus(ctx, mark, px + CELL - 19, py + 3, 16);
  }

  function hasBitternSink(x, y) {
    for (const n of SIM.neighbours(S, x, y)) {
      if (n.m && D.machine(n.m.id).takes.indexOf('bittern') >= 0) return true;
    }
    return SIM.isExport(S, x);
  }

  /* ── header ─────────────────────────────────────────────────────────────────────────────── */

  function header() {
    const se = SIM.season(S);
    $('s-year').firstChild.textContent = SIM.year(S) + ' / ' + D.LEASE_YEARS;
    $('s-season').firstChild.textContent = se.name;
    $('s-marks').firstChild.textContent = Math.floor(S.marks);
    $('s-crew').firstChild.textContent = S.crew;
    $('order-num').textContent = Math.floor(S.exported) + ' / ' + D.ORDER_SODA;
    $('order-fill').style.width = Math.min(100, 100 * S.exported / D.ORDER_SODA).toFixed(1) + '%';
  }

  /* ── the panel ──────────────────────────────────────────────────────────────────────────── */

  /** Rebuild the panel NOW, whatever the pointer is doing — used by the panel's own handlers,
   *  where the pointer is by definition inside it. */
  function forcePanel() {
    panel();
    lastSig = panelSig();
  }

  function panel() {
    const body = $('tabbody');
    const scroll = body.scrollTop;
    body.textContent = '';
    if (ui.tab === 'works') worksTab(body);
    else if (ui.tab === 'research') researchTab(body);
    else ledgerTab(body);
    body.scrollTop = scroll;
  }

  function worksTab(body) {
    if (ui.sel) {
      const [x, y] = ui.sel;
      const c = SIM.at(S, x, y);
      if (c && c.m) { machineInfo(body, x, y, c); return; }
    }

    body.appendChild(headed('h3', 'PUT UP A MACHINE'));
    const note = el('p', 'note', ui.build
      ? 'Now click a cell. Machines pass materials to the four cells touching them, and to nothing else.'
      : 'Pick one, then click the bed. There are no belts: a machine feeds only the four cells it touches.');
    body.appendChild(note);

    for (const def of D.MACHINES) {
      const affordable = S.marks >= def.cost;
      const row = el('div', 'row' + (ui.build === def.id ? ' on' : '') + (affordable ? '' : ' dead'));
      row.appendChild(ART.machineCanvas(def.id, 34));
      const b = el('div', 'body');
      const nm = el('div', 'name');
      nm.appendChild(el('span', null, def.name));
      nm.appendChild(el('i', null, def.cost + ' marks'));
      b.appendChild(nm);
      b.appendChild(el('div', 'line', def.line));
      row.appendChild(b);
      if (affordable) {
        row.onclick = () => {
          ui.build = ui.build === def.id ? null : def.id;
          ui.moving = null;
          forcePanel();
        };
      }
      body.appendChild(row);
    }

    if (ui.build === 'cistern') {
      body.appendChild(headed('h3', 'THIS CISTERN WILL HOLD'));
      const wrap = el('div', 'bufs');
      for (const mat of D.MATERIALS) {
        const btn = el('button', 'btn' + (ui.buildMat === mat.id ? ' on' : ''), mat.name);
        if (ui.buildMat === mat.id) btn.style.color = 'var(--gold)';
        btn.onclick = () => { ui.buildMat = mat.id; forcePanel(); };
        wrap.appendChild(btn);
      }
      body.appendChild(wrap);
    }
  }

  function machineInfo(body, x, y, c) {
    const m = c.m, def = D.machine(m.id);
    const head = el('div', 'row on');
    head.appendChild(ART.machineCanvas(m.id, 34));
    const hb = el('div', 'body');
    const nm = el('div', 'name');
    nm.appendChild(el('span', null, def.name + (m.id === 'cistern' ? ' of ' + D.material(m.material).name.toLowerCase() : '')));
    nm.appendChild(el('i', null, m.running ? 'running' : 'idle'));
    hb.appendChild(nm);
    hb.appendChild(el('div', 'line', def.line));
    head.appendChild(hb);
    body.appendChild(head);

    const t = el('table', 'kv');
    const add = (k, v) => {
      const tr = el('tr');
      tr.appendChild(el('td', 'k', k));
      tr.appendChild(el('td', 'v', v));
      t.appendChild(tr);
    };
    if (m.id === 'well') {
      add('brine under it', (100 * (c.cap > 0 ? c.bed / c.cap : 0)).toFixed(0) + '% of what is left');
      add('the ground itself', (100 * (c.cap0 > 0 ? c.cap / c.cap0 : 0)).toFixed(0) + '% of what it started with');
      add('yield now', (100 * SIM.wellYield(S, x, y)).toFixed(0) + '%');
      add('distance to water', Math.max(0, x - S.shoreline) + ' column(s)');
    } else if (m.id === 'pan') {
      let adj = 0;
      for (const n of SIM.neighbours(S, x, y)) if (n.m && n.m.id === 'pan') adj++;
      add('sun this season', SIM.sunOf(S).toFixed(2) + '×');
      add('pans touching it', String(adj));
      add('working at', (100 * SIM.rateOf(S, m, x, y)).toFixed(0) + '%');
    } else if (def.recipe) {
      add('working at', (100 * SIM.rateOf(S, m, x, y)).toFixed(0) + '%');
    }
    if (SIM.isExport(S, x)) add('on the causeway', 'anything nothing else wants is sold here');
    body.appendChild(t);

    const bufs = el('div', 'bufs');
    for (const mat of D.MATERIALS) {
      const q = m.buf[mat.id] || 0;
      if (q <= 0.05) continue;
      const b = el('div', 'buf');
      const sw = el('i');
      sw.style.background = mat.colour;
      b.appendChild(sw);
      b.appendChild(el('span', null, mat.name + ' ' + q.toFixed(0)));
      bufs.appendChild(b);
    }
    if (bufs.childNodes.length) body.appendChild(bufs);

    const acts = el('div', 'actions');
    const mv = el('button', 'btn', ui.moving ? 'CLICK A CELL' : 'MOVE (1 crew)');
    mv.onclick = () => {
      if (S.crew < 1) { flash('No hands free. A gang walks out along the causeway every so often.'); SOUND.play('deny', 0.4); return; }
      ui.moving = ui.moving ? null : [x, y];
      ui.build = null;
      forcePanel();
    };
    acts.appendChild(mv);
    const dm = el('button', 'btn', 'TAKE DOWN (+' + Math.floor(def.cost * 0.5) + ')');
    dm.onclick = () => {
      SIM.demolish(S, x, y);
      SIM.say(S, def.name + ' taken down. Half the timber is worth having back.');
      ui.sel = null; ui.moving = null;
      SOUND.play('place', 0.4);
      forcePanel();
    };
    acts.appendChild(dm);
    const bk = el('button', 'btn', 'BACK');
    bk.onclick = () => { ui.sel = null; ui.moving = null; forcePanel(); };
    acts.appendChild(bk);
    body.appendChild(acts);
  }

  function researchTab(body) {
    body.appendChild(headed('h3', 'WORK IN HAND'));
    body.appendChild(el('p', 'note',
      'Every piece of work is unlocked by soda ash already on the tram, so building well is what buys the next one.'));
    for (const r of D.RESEARCH) {
      const done = !!S.done[r.id];
      const why = SIM.canResearch(S, r.id);
      const row = el('div', 'row' + (done ? ' dead' : why ? ' dead' : ''));
      row.appendChild(ART.markCanvas(r.id, 30));
      const b = el('div', 'body');
      const nm = el('div', 'name');
      nm.appendChild(el('span', null, r.name));
      nm.appendChild(el('i', null, done ? 'done' : r.cost + ' marks'));
      b.appendChild(nm);
      b.appendChild(el('div', 'line', done ? r.line
        : (S.exported < r.needSoda ? 'needs ' + r.needSoda + ' soda shipped — ' + r.line : r.line)));
      row.appendChild(b);
      if (!done && !why) {
        row.classList.remove('dead');
        row.onclick = () => {
          const res = SIM.research(S, r.id);
          if (res.ok) SOUND.play('research', 0.45); else SOUND.play('deny', 0.4);
          forcePanel();
        };
      }
      body.appendChild(row);
    }
  }

  function ledgerTab(body) {
    body.appendChild(headed('h3', 'THE LEASE'));
    const t = el('table', 'kv');
    const add = (k, v) => {
      const tr = el('tr');
      tr.appendChild(el('td', 'k', k));
      tr.appendChild(el('td', 'v', v));
      t.appendChild(tr);
    };
    add('year', SIM.year(S) + ' of ' + D.LEASE_YEARS);
    add('season', SIM.season(S).name);
    add('soda ash shipped', Math.floor(S.exported) + ' of ' + D.ORDER_SODA);
    add('earned', Math.floor(S.earned) + ' marks');
    add('machines standing', String(countMachines()));
    add('hands', S.crew + ' free');
    body.appendChild(t);

    body.appendChild(headed('h3', 'ON THE TRAM SO FAR'));
    const sold = el('div', 'bufs');
    let any = false;
    for (const mat of D.MATERIALS) {
      const q = S.sold[mat.id] || 0;
      if (q <= 0.5) continue;
      any = true;
      const b = el('div', 'buf');
      const sw = el('i');
      sw.style.background = mat.colour;
      b.appendChild(sw);
      b.appendChild(el('span', null, mat.name + ' ' + Math.floor(q) + ' @ ' + SIM.priceOf(S, mat.id)));
      sold.appendChild(b);
    }
    if (!any) sold.appendChild(el('div', 'buf', 'Nothing has left the works yet.'));
    body.appendChild(sold);

    const wasted = Math.floor(S.wasted.bittern || 0);
    body.appendChild(headed('h3', 'TIPPED BACK INTO THE BED'));
    body.appendChild(el('p', 'note', wasted > 0
      ? wasted + ' tonnes of bittern, because a crystalliser with nowhere to send it does what every other works on this lake does. A still turns that into potash, and potash is half of soda.'
      : 'Nothing yet. Bittern is thrown away by every other works on the lake; a still is what makes this one different.'));

    body.appendChild(headed('h3', 'THE SEASON'));
    body.appendChild(el('p', 'note', SIM.season(S).line));
  }

  function countMachines() {
    let n = 0;
    for (let y = 0; y < D.BOARD.rows; y++) for (let x = 0; x < D.BOARD.cols; x++) if (S.cells[y][x].m) n++;
    return n;
  }

  function headed(tag, text) { return el(tag, null, text); }

  let lastLog = null;
  function logView(force) {
    const top = S.log.length ? S.log[0] : null;
    if (!force && top === lastLog) return;
    lastLog = top;
    const box = $('log');
    box.textContent = '';
    for (const e of S.log.slice(0, 8)) box.appendChild(el('div', null, e.text));
  }

  function flash(text) { SIM.say(S, text); logView(true); }

  /* ── input ──────────────────────────────────────────────────────────────────────────────── */

  function cellAt(ev) {
    const r = board.getBoundingClientRect();
    const x = Math.floor((ev.clientX - r.left) * (board.width / r.width) / CELL);
    const y = Math.floor((ev.clientY - r.top) * (board.height / r.height) / CELL);
    if (x < 0 || y < 0 || x >= D.BOARD.cols || y >= D.BOARD.rows) return null;
    return [x, y];
  }

  function bindEvents() {
    board.addEventListener('mousemove', (ev) => {
      const c = cellAt(ev);
      ui.hover = c;
      showTip(ev, c);
    });
    board.addEventListener('mouseleave', () => { ui.hover = null; $('tip').hidden = true; });

    board.addEventListener('click', (ev) => {
      SOUND.start();
      const at = cellAt(ev);
      if (!at || !S) return;
      const [x, y] = at;

      if (ui.moving) {
        const r = SIM.move(S, ui.moving[0], ui.moving[1], x, y);
        if (r.ok) {
          SIM.say(S, 'Taken up and set down again. A gang is spent on it.');
          SOUND.play('place', 0.5);
          ui.sel = [x, y]; ui.moving = null;
        } else { flash('Cannot move it there: ' + r.why + '.'); SOUND.play('deny', 0.4); }
        render();
        return;
      }

      if (ui.build) {
        const r = SIM.build(S, x, y, ui.build, ui.buildMat);
        if (r.ok) SOUND.play('place', 0.5);
        else { flash('Cannot build there: ' + r.why + '.'); SOUND.play('deny', 0.4); }
        render();
        return;
      }

      const c = SIM.at(S, x, y);
      ui.sel = (c && c.m) ? [x, y] : null;
      if (ui.sel) ui.tab = 'works';
      syncTabs();
      render();
    });

    const panelEl = $('panel');
    panelEl.addEventListener('mouseenter', () => { ui.panelHot = true; });
    panelEl.addEventListener('mouseleave', () => { ui.panelHot = false; });

    for (const t of document.querySelectorAll('.tab')) {
      t.addEventListener('click', () => { ui.tab = t.dataset.tab; ui.sel = null; syncTabs(); forcePanel(); });
    }
    for (const b of document.querySelectorAll('.spd')) {
      b.addEventListener('click', () => {
        SOUND.start();
        ui.speed = parseInt(b.dataset.speed, 10);
        for (const o of document.querySelectorAll('.spd')) o.classList.toggle('on', o === b);
      });
    }
    $('mute').addEventListener('click', () => {
      SOUND.start();
      const m = SOUND.setMuted(!SOUND.isMuted());
      $('mute').classList.toggle('off', m);
      $('mute').textContent = m ? 'SILENT' : 'SOUND';
    });
    $('helpbtn').addEventListener('click', () => help());

    document.addEventListener('keydown', (ev) => {
      if (ev.key === 'Escape') { ui.build = null; ui.moving = null; ui.sel = null; forcePanel(); }
      if (ev.key === ' ') { ev.preventDefault(); toggleHold(); }
    });
  }

  function toggleHold() {
    const b = document.querySelector('.spd[data-speed="' + (ui.speed === 0 ? '1' : '0') + '"]');
    if (b) b.click();
  }

  function syncTabs() {
    for (const t of document.querySelectorAll('.tab')) t.classList.toggle('on', t.dataset.tab === ui.tab);
  }

  function showTip(ev, at) {
    const tip = $('tip');
    if (!at || !S) { tip.hidden = true; return; }
    const [x, y] = at;
    const c = SIM.at(S, x, y);
    tip.textContent = '';

    /* ⚠️ NODES, NOT `innerHTML`. Nothing in this game is untrusted — every string below comes from
     * data.js or from a number — but a tooltip built by string concatenation is the shape that
     * becomes an injection the first time somebody adds a name a player can type. */
    const line = (...parts) => {
      const d = el('div');
      for (const p of parts) d.appendChild(typeof p === 'string' ? document.createTextNode(p) : p);
      tip.appendChild(d);
    };
    const strong = (t) => el('b', null, t);
    const warn = (t) => el('span', 'warn', t);
    const good = (t) => el('span', 'good', t);

    if (SIM.isWater(S, x)) {
      line(strong('Under water'));
      line('The lake is still here. It will not be for ever.');
    } else {
      const wet = c.cap > 0 ? c.bed / c.cap : 0;
      const spent = c.cap0 > 0 ? 1 - c.cap / c.cap0 : 0;
      line(strong(SIM.isExport(S, x) ? 'Causeway' : 'Bed'));
      line('Brine standing: ', strong((100 * wet).toFixed(0) + '%'));
      line('Ground left: ', strong((100 * (1 - spent)).toFixed(0) + '%'),
        ...(spent > 0.25 ? [' ', warn('worked out')] : []));
      line('A well here would yield ', strong((100 * SIM.wellYield(S, x, y)).toFixed(0) + '%'));
      if (SIM.isExport(S, x)) line(good('Anything standing here that nothing else wants goes on the tram.'));
      if (c.m) line(D.machine(c.m.id).name + ' — ', c.m.running ? good('running') : warn('idle'));
    }

    const r = board.getBoundingClientRect();
    const wrap = $('boardwrap').getBoundingClientRect();
    let px = ev.clientX - wrap.left + 14;
    let py = ev.clientY - wrap.top + 14;
    if (px + 210 > r.width) px = ev.clientX - wrap.left - 210;
    if (py + 120 > r.height) py = Math.max(0, ev.clientY - wrap.top - 120);
    tip.style.left = px + 'px';
    tip.style.top = py + 'px';
    tip.hidden = false;
  }

  /* ── overlays ───────────────────────────────────────────────────────────────────────────── */

  function showOverlay(build) {
    const sheet = $('sheet');
    sheet.textContent = '';
    build(sheet);
    $('overlay').hidden = false;
  }
  function hideOverlay() { $('overlay').hidden = true; }

  function title() {
    showOverlay((s) => {
      s.appendChild(el('h1', null, 'BITTERWORKS'));
      s.appendChild(el('p', 'lead',
        'A soda works on a drying salt lake. The brine under the bed is finite, it moves, and the '
        + 'layout that was right in year one is a row of dry holes by year four.'));
      s.appendChild(el('h2', null, 'What you are doing'));
      s.appendChild(el('p', null,
        'Sink wells into the bed, evaporate the brine in pans, crystallise salt and bittern, still '
        + 'the bittern into potash, and burn salt and potash together into soda ash. The railhead '
        + 'is the last column on the east. The best brine is under the water on the west. The works '
        + 'has to stretch between them, and the ground under it does not last.'));
      const b = el('div', 'buttons');
      const resuming = SAVE.has();
      const go = el('button', 'big', resuming ? 'CARRY ON' : 'TAKE THE LEASE');
      go.onclick = () => { SOUND.start(); begin(); };
      b.appendChild(go);
      if (resuming) {
        const nw = el('button', 'big quiet', 'START AGAIN');
        nw.onclick = () => { SOUND.start(); newRun(); };
        b.appendChild(nw);
      }
      const hp = el('button', 'big quiet', 'HOW IT WORKS');
      hp.onclick = () => help();
      b.appendChild(hp);
      s.appendChild(b);
      s.appendChild(credits());
    });
  }

  function help() {
    showOverlay((s) => {
      s.appendChild(el('h1', null, 'HOW IT WORKS'));
      s.appendChild(el('h2', null, 'There are no belts'));
      s.appendChild(el('p', null,
        'A machine pushes what it makes into the four cells it touches, and nowhere else. That is '
        + 'the whole logistics system, and it is why the board is a puzzle rather than a shopping '
        + 'list. A cistern holds one material and passes it on, which is the only way across a gap '
        + '— and it costs a whole cell to cross one.'));
      s.appendChild(el('h2', null, 'The chain'));
      const ul = el('ul');
      for (const m of D.MACHINES) {
        const li = el('li');
        li.appendChild(el('b', null, m.name + ' — '));
        li.appendChild(document.createTextNode(m.line));
        ul.appendChild(li);
      }
      s.appendChild(ul);
      s.appendChild(el('p', null,
        'Pans run as a cascade: a full pan passes its surplus brine along, and every pan hands its '
        + 'liquor down the line until something crystallises it. A crystalliser with nowhere to put '
        + 'its bittern tips it back into the bed, like every other works on this lake. A still is '
        + 'what makes this one different.'));
      s.appendChild(el('h2', null, 'The bed'));
      s.appendChild(el('p', null,
        'Every cell holds brine, and pumping takes it out faster than the lake puts it back. Some '
        + 'of what you take never comes back at all — the ground itself is used up — so a cell '
        + 'darkens permanently under a working well. Recharge comes from the lake and falls away '
        + 'sharply with distance from the water, and the water is going west. Wells are meant to be '
        + 'moved; that is what the crew are for.'));
      s.appendChild(el('h2', null, 'The year'));
      const su = el('ul');
      for (const se of D.SEASONS) {
        const li = el('li');
        li.appendChild(el('b', null, se.name + ' — '));
        li.appendChild(document.createTextNode(se.line + ' (sun ' + se.sun.toFixed(2) + '×, recharge ' + se.recharge.toFixed(2) + '×)'));
        su.appendChild(li);
      }
      s.appendChild(su);
      s.appendChild(el('h2', null, 'The lease'));
      s.appendChild(el('p', null,
        'Eight years, and a standing order for ' + D.ORDER_SODA + ' tonnes of soda ash. The causeway '
        + 'will buy salt and potash too, which is how you survive year one — but the order is '
        + 'written in soda and nothing else, so everything you sell raw is something you did not '
        + 'put in the furnace.'));
      s.appendChild(el('h2', null, 'Controls'));
      s.appendChild(el('p', null,
        'Mouse only. Click a machine in the panel then click the bed to build it. Click a machine on '
        + 'the board to inspect, move or take it down. Space holds the clock; Escape cancels. The '
        + 'run saves itself continuously — closing the tab loses nothing.'));
      const b = el('div', 'buttons');
      const go = el('button', 'big', ui.begun ? 'BACK TO THE WORKS' : 'TAKE THE LEASE');
      go.onclick = () => { SOUND.start(); if (ui.begun) hideOverlay(); else begin(); };
      b.appendChild(go);
      s.appendChild(b);
      s.appendChild(credits());
    });
  }

  function ending() {
    SAVE.write(S);
    showOverlay((s) => {
      s.appendChild(el('h1', null, 'THE LEASE IS UP'));
      s.appendChild(el('div', 'verdict', S.verdict ? S.verdict.title : '—'));
      s.appendChild(el('p', 'lead', S.verdict ? S.verdict.line : ''));
      s.appendChild(el('h2', null, 'Eight years'));
      const t = el('table', 'kv');
      const add = (k, v) => {
        const tr = el('tr');
        tr.appendChild(el('td', 'k', k));
        tr.appendChild(el('td', 'v', v));
        t.appendChild(tr);
      };
      add('soda ash shipped', Math.floor(S.exported) + ' of ' + D.ORDER_SODA);
      add('earned', Math.floor(S.earned) + ' marks');
      add('machines standing', String(countMachines()));
      add('machines moved', String(S.stats.moved));
      add('bittern tipped away', Math.floor(S.wasted.bittern || 0) + ' tonnes');
      let left = 0, was = 0;
      for (let y = 0; y < D.BOARD.rows; y++) for (let x = 0; x < D.BOARD.cols; x++) { left += S.cells[y][x].cap; was += S.cells[y][x].cap0; }
      add('the bed you leave', (100 * left / was).toFixed(0) + '% of the ground you found');
      s.appendChild(t);
      const b = el('div', 'buttons');
      const again = el('button', 'big', 'TAKE A NEW LEASE');
      again.onclick = () => { newRun(); };
      b.appendChild(again);
      const keep = el('button', 'big quiet', 'STAY ON THE LAKE');
      keep.onclick = () => { S.freeWorks = true; ui.speed = 1; hideOverlay(); };
      b.appendChild(keep);
      s.appendChild(b);
      s.appendChild(credits());
    });
  }

  function credits() {
    const c = el('div', 'credits');
    c.appendChild(document.createTextNode(
      'BITTERWORKS — a free browser game by Core Systems Asset Factory. Code and graphics are '
      + 'AI-written; the art is generated by our own tools and the music and sound are '
      + 'procedurally synthesised, not AI-generated. '));
    const a = el('a', null, 'More free browser games and game-dev assets at csaf.itch.io');
    a.href = 'https://csaf.itch.io';
    a.target = '_blank';
    a.rel = 'noopener';
    c.appendChild(a);
    return c;
  }

  /* expose a little for the tests and the capture harness — never used by the game itself */
  window.BW = {
    get state() { return S; },
    set state(v) { S = v; },
    ui, render, newRun, help, ending, title, plateOf,
  };

  boot();
})();
