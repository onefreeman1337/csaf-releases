/**
 * sim.js - FLYWAY's observatory, as pure rules: no drawing, no DOM, no clock of its own. game.js calls SIM.step(gm, minutes)
 * and draws what is in gm. It also runs under Node (module.exports at the end), so whole seasons can be played without a page.
 *
 * Three systems that lean on each other:
 *   THE WEATHER   each day has a wind and a sky. Migrants fly over on clear nights; an onshore wind with rain at dawn
 *                 puts them down on the headland (a FALL). Nobody can schedule it.
 *   THE NETS      birds land in COVER (scrub, reeds, the garden), and nets set beside cover catch them. A bird must not
 *                 wait: every net round costs a ringer's time, so more open nets mean more birds only while there are
 *                 hands to check them. A bird left too long is let go unringed, and the observatory says so.
 *   THE RINGS     every bird is identified, aged, ringed and released. A few rings are found again somewhere down the
 *                 flyway, and each one draws a line on the map. Rings, rarities and recoveries bring members and visiting
 *                 birders, and that pays for the next net, the next planting, the next season.
 */
'use strict';

var SIM = (function () {
  var COLS = 16, ROWS = 10, DAY_START = 6 * 60, DAY_END = 19 * 60, SEASON_DAYS = 40, STEP = 10, NET_LIMIT = 40, BAG_LIMIT = 70, TRAP_LIMIT = 90;

  /* a seeded generator: every random thing in a season comes from the season's own seed */
  function rng(seed) { var s = (seed >>> 0) || 1; return function () { s = (s + 0x6d2b79f5) >>> 0; var t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function hash(a, b, c) { var h = (Math.imul(a | 0, 374761393) + Math.imul(b | 0, 668265263) + Math.imul(c | 0, 1442695041)) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); h ^= h >>> 16; return (h >>> 0) / 4294967296; }

  /* ---------------------------------------------------------------- the headland (authored) */
  // ~ sea  . shore  g grass  s scrub  r reeds  w garden wall  G walled garden  L lighthouse  H ringing hut  P pool
  var MAP = [
    'gggggggggsg.~~~~',
    'gsgggggggss..~~~',
    'gssgggrrgggg.~~~',
    'ggsgggrPrgwwww.~',
    'gggggrrrrgwGGw.~',
    'ggsggrrrgHwGGw..',
    'gggsggggggwwww.L',
    'ggggggsggggsgg..',
    'gggssggggggggg.~',
    'gggggggggggg..~~',
  ];
  var DIRS = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
  var ONSHORE = { N: 0.35, NE: 0.85, E: 1, SE: 0.9, S: 0.35, SW: 0.05, W: 0, NW: 0.1 };   // the sea is to the east

  /* ---------------------------------------------------------------- the birds (the rules half; art.js draws them) */
  // hab: where they land. ab: abundance. pk/wd: the day of the season they peak and the spread (days). rare: 0 common,
  // 1 scarce, 2 rare. dif: identification and ageing time (0-3). rec: chance a ring is found again. route: where they go.
  // sexed: whether the plumage tells male from female in the hand.
  var SPECIES = [
    { id: 'robin', name: 'Robin', hab: 'scrub', ab: 9, pk: 26, wd: 9, rare: 0, dif: 1, rec: 0.012, route: 'sw', sexed: false },
    { id: 'goldcrest', name: 'Goldcrest', hab: 'scrub', ab: 10, pk: 28, wd: 7, rare: 0, dif: 1, rec: 0.006, route: 'w', sexed: true },
    { id: 'chiffchaff', name: 'Chiffchaff', hab: 'scrub', ab: 7, pk: 22, wd: 10, rare: 0, dif: 1, rec: 0.006, route: 'iberia', sexed: false },
    { id: 'willow', name: 'Willow Warbler', hab: 'scrub', ab: 5, pk: 6, wd: 7, rare: 0, dif: 1, rec: 0.004, route: 'africa', sexed: false },
    { id: 'blackcap', name: 'Blackcap', hab: 'garden', ab: 7, pk: 20, wd: 10, rare: 0, dif: 0, rec: 0.01, route: 'iberia', sexed: true },
    { id: 'gardenw', name: 'Garden Warbler', hab: 'garden', ab: 4, pk: 10, wd: 7, rare: 0, dif: 1, rec: 0.005, route: 'africa', sexed: false },
    { id: 'lwhitethroat', name: 'Lesser Whitethroat', hab: 'scrub', ab: 3, pk: 9, wd: 7, rare: 0, dif: 1, rec: 0.005, route: 'east', sexed: false },
    { id: 'whitethroat', name: 'Whitethroat', hab: 'scrub', ab: 4, pk: 6, wd: 6, rare: 0, dif: 1, rec: 0.005, route: 'africa', sexed: true },
    { id: 'sedge', name: 'Sedge Warbler', hab: 'reed', ab: 5, pk: 5, wd: 6, rare: 0, dif: 1, rec: 0.01, route: 'africa', sexed: false },
    { id: 'reedw', name: 'Reed Warbler', hab: 'reed', ab: 6, pk: 10, wd: 8, rare: 0, dif: 2, rec: 0.012, route: 'africa', sexed: false },
    { id: 'reedbunting', name: 'Reed Bunting', hab: 'reed', ab: 4, pk: 30, wd: 9, rare: 0, dif: 1, rec: 0.006, route: 'sw', sexed: true },
    { id: 'wren', name: 'Wren', hab: 'scrub', ab: 4, pk: 24, wd: 14, rare: 0, dif: 0, rec: 0.004, route: 'sw', sexed: false },
    { id: 'dunnock', name: 'Dunnock', hab: 'scrub', ab: 3, pk: 24, wd: 14, rare: 0, dif: 1, rec: 0.003, route: 'sw', sexed: false },
    { id: 'songthrush', name: 'Song Thrush', hab: 'garden', ab: 5, pk: 30, wd: 7, rare: 0, dif: 1, rec: 0.02, route: 'sw', sexed: false },
    { id: 'redwing', name: 'Redwing', hab: 'garden', ab: 7, pk: 35, wd: 5, rare: 0, dif: 1, rec: 0.02, route: 'iberia', sexed: false },
    { id: 'blackbird', name: 'Blackbird', hab: 'garden', ab: 6, pk: 34, wd: 7, rare: 0, dif: 1, rec: 0.02, route: 'w', sexed: true },
    { id: 'fieldfare', name: 'Fieldfare', hab: 'open', ab: 3, pk: 37, wd: 5, rare: 0, dif: 1, rec: 0.015, route: 'sw', sexed: false },
    { id: 'ringouzel', name: 'Ring Ouzel', hab: 'scrub', ab: 1.2, pk: 26, wd: 6, rare: 1, dif: 1, rec: 0.02, route: 'iberia', sexed: true },
    { id: 'redstart', name: 'Redstart', hab: 'garden', ab: 3, pk: 9, wd: 6, rare: 0, dif: 1, rec: 0.006, route: 'africa', sexed: true },
    { id: 'blackredstart', name: 'Black Redstart', hab: 'open', ab: 1.5, pk: 29, wd: 8, rare: 1, dif: 1, rec: 0.008, route: 'iberia', sexed: true },
    { id: 'piedfly', name: 'Pied Flycatcher', hab: 'garden', ab: 3, pk: 7, wd: 5, rare: 0, dif: 1, rec: 0.008, route: 'africa', sexed: true },
    { id: 'spotfly', name: 'Spotted Flycatcher', hab: 'garden', ab: 2, pk: 6, wd: 6, rare: 0, dif: 0, rec: 0.006, route: 'africa', sexed: false },
    { id: 'wheatear', name: 'Wheatear', hab: 'open', ab: 3, pk: 8, wd: 9, rare: 0, dif: 1, rec: 0.008, route: 'africa', sexed: true },
    { id: 'whinchat', name: 'Whinchat', hab: 'open', ab: 2, pk: 7, wd: 6, rare: 0, dif: 1, rec: 0.006, route: 'africa', sexed: true },
    { id: 'stonechat', name: 'Stonechat', hab: 'open', ab: 2, pk: 28, wd: 9, rare: 0, dif: 0, rec: 0.006, route: 'sw', sexed: true },
    { id: 'treepipit', name: 'Tree Pipit', hab: 'open', ab: 2, pk: 7, wd: 6, rare: 0, dif: 2, rec: 0.004, route: 'africa', sexed: false },
    { id: 'meadowpipit', name: 'Meadow Pipit', hab: 'open', ab: 6, pk: 24, wd: 9, rare: 0, dif: 1, rec: 0.005, route: 'iberia', sexed: false },
    { id: 'chaffinch', name: 'Chaffinch', hab: 'garden', ab: 6, pk: 32, wd: 7, rare: 0, dif: 0, rec: 0.006, route: 'w', sexed: true },
    { id: 'brambling', name: 'Brambling', hab: 'garden', ab: 3, pk: 34, wd: 5, rare: 0, dif: 1, rec: 0.01, route: 'east', sexed: true },
    { id: 'siskin', name: 'Siskin', hab: 'garden', ab: 4, pk: 27, wd: 9, rare: 0, dif: 0, rec: 0.008, route: 'sw', sexed: true },
    { id: 'goldfinch', name: 'Goldfinch', hab: 'open', ab: 4, pk: 20, wd: 14, rare: 0, dif: 1, rec: 0.005, route: 'iberia', sexed: false },
    { id: 'linnet', name: 'Linnet', hab: 'open', ab: 4, pk: 22, wd: 12, rare: 0, dif: 1, rec: 0.005, route: 'iberia', sexed: true },
    { id: 'firecrest', name: 'Firecrest', hab: 'scrub', ab: 1, pk: 30, wd: 7, rare: 1, dif: 1, rec: 0.006, route: 'w', sexed: true },
    { id: 'ybwarbler', name: 'Yellow-browed Warbler', hab: 'scrub', ab: 1.1, pk: 27, wd: 5, rare: 1, dif: 1, rec: 0.003, route: 'east', sexed: false },
    { id: 'pallass', name: "Pallas's Warbler", hab: 'scrub', ab: 0.25, pk: 34, wd: 4, rare: 2, dif: 1, rec: 0.003, route: 'east', sexed: false },
    { id: 'rbfly', name: 'Red-breasted Flycatcher', hab: 'garden', ab: 0.35, pk: 24, wd: 6, rare: 2, dif: 1, rec: 0.004, route: 'east', sexed: true },
    { id: 'barred', name: 'Barred Warbler', hab: 'scrub', ab: 0.35, pk: 16, wd: 6, rare: 2, dif: 2, rec: 0.004, route: 'east', sexed: false },
    { id: 'icterine', name: 'Icterine Warbler', hab: 'garden', ab: 0.4, pk: 6, wd: 5, rare: 2, dif: 2, rec: 0.004, route: 'africa', sexed: false },
    { id: 'bluethroat', name: 'Bluethroat', hab: 'reed', ab: 0.3, pk: 14, wd: 6, rare: 2, dif: 1, rec: 0.006, route: 'east', sexed: true },
    { id: 'wryneck', name: 'Wryneck', hab: 'open', ab: 0.4, pk: 8, wd: 6, rare: 2, dif: 1, rec: 0.006, route: 'africa', sexed: false },
    { id: 'rbshrike', name: 'Red-backed Shrike', hab: 'scrub', ab: 0.35, pk: 7, wd: 6, rare: 2, dif: 1, rec: 0.006, route: 'africa', sexed: true },
    { id: 'lapland', name: 'Lapland Bunting', hab: 'open', ab: 0.4, pk: 30, wd: 7, rare: 2, dif: 1, rec: 0.004, route: 'east', sexed: true },
    { id: 'snowbunting', name: 'Snow Bunting', hab: 'open', ab: 0.6, pk: 37, wd: 5, rare: 1, dif: 1, rec: 0.006, route: 'east', sexed: true },
    { id: 'woodcock', name: 'Woodcock', hab: 'garden', ab: 0.6, pk: 38, wd: 4, rare: 1, dif: 0, rec: 0.03, route: 'w', sexed: false },
  ];
  var BY_ID = {}; SPECIES.forEach(function (s, i) { s.ix = i; BY_ID[s.id] = s; });

  // the night list: moths in the trap (art.js draws them)
  var MOTHS = [
    { id: 'lyu', name: 'Large Yellow Underwing', ab: 9, pk: 14, wd: 18 }, { id: 'setaceous', name: 'Setaceous Hebrew Character', ab: 7, pk: 10, wd: 14 },
    { id: 'angleshades', name: 'Angle Shades', ab: 4, pk: 20, wd: 16 }, { id: 'merveille', name: 'Merveille du Jour', ab: 2, pk: 30, wd: 8 },
    { id: 'blairs', name: 'Blair\'s Shoulder-knot', ab: 3, pk: 30, wd: 9 }, { id: 'snout', name: 'Snout', ab: 3, pk: 8, wd: 10 },
    { id: 'silvery', name: 'Silver Y', ab: 6, pk: 12, wd: 14 }, { id: 'convolvulus', name: 'Convolvulus Hawk-moth', ab: 0.35, pk: 12, wd: 9 },
    { id: 'redunder', name: 'Red Underwing', ab: 1.2, pk: 10, wd: 8 }, { id: 'feathered', name: 'Feathered Thorn', ab: 2, pk: 36, wd: 6 },
    { id: 'sprawler', name: 'Sprawler', ab: 2, pk: 33, wd: 6 }, { id: 'clifden', name: 'Clifden Nonpareil', ab: 0.15, pk: 22, wd: 10 },
  ];
  var MOTH_BY_ID = {}; MOTHS.forEach(function (m, i) { m.ix = i; MOTH_BY_ID[m.id] = m; });

  // where rings are found again: longitude and latitude in degrees (east and north positive), the land side of the place
  // where its name is a coast; the flyway map (js/coast.js, drawn by game.js) puts each dot there
  var PLACES = {
    w: [{ n: 'Cape Clear, Ireland', lon: -9.49, lat: 51.44 }, { n: 'Pembrokeshire, Wales', lon: -4.95, lat: 51.82 }, { n: 'Cornwall', lon: -4.95, lat: 50.4 }],
    sw: [{ n: 'Brittany, France', lon: -3.2, lat: 48.3 }, { n: 'Gironde estuary, France', lon: -0.95, lat: 45.45 }, { n: 'Landes, France', lon: -1.05, lat: 44.1 }, { n: 'Basque coast, Spain', lon: -2.45, lat: 43.25 }],
    iberia: [{ n: 'Tagus estuary, Portugal', lon: -8.95, lat: 38.85 }, { n: 'Doñana, Spain', lon: -6.4, lat: 37.0 }, { n: 'Tarifa, Spain', lon: -5.6, lat: 36.02 }, { n: 'Valencia, Spain', lon: -0.4, lat: 39.45 }],
    africa: [{ n: 'Merja Zerga, Morocco', lon: -6.27, lat: 34.84 }, { n: 'Banc d\'Arguin, Mauritania', lon: -16.15, lat: 20.0 }, { n: 'Senegal delta', lon: -16.3, lat: 16.35 }],
    east: [{ n: 'Heligoland, Germany', lon: 7.885, lat: 54.18 }, { n: 'Falsterbo, Sweden', lon: 12.83, lat: 55.4 }, { n: 'Utsira, Norway', lon: 4.88, lat: 59.31 }, { n: 'Ottenby, Sweden', lon: 16.43, lat: 56.24 }],
  };
  // the observatory: a chalk headland on the east coast, facing the North Sea (so the easterlies are its onshore winds)
  var HOME = { lon: -0.08, lat: 54.12 };

  /* ---------------------------------------------------------------- the ladder (nine unlocks) */
  var UNLOCKS = [
    { id: 'ride2', name: 'Second net ride', cost: 120, why: 'three more nets by the scrub' },
    { id: 'trap', name: 'Heligoland trap', cost: 300, why: 'a funnel trap: 90 minutes' },
    { id: 'moth', name: 'Moth trap', cost: 150, why: 'a light by the hut at night' },
    { id: 'seawatch', name: 'Seawatch hide', cost: 220, why: 'onshore winds bring visitors' },
    { id: 'garden', name: 'Garden planting', cost: 180, why: 'thrushes and warblers' },
    { id: 'ringer2', name: 'Second ringer', cost: 400, why: 'another pair of hands' },
    { id: 'reedride', name: 'Reedbed ride', cost: 260, why: 'nets in the reeds' },
    { id: 'instruments', name: 'Weather instruments', cost: 200, why: 'tomorrow\'s wind and sky' },
    { id: 'report', name: 'The annual report', cost: 600, why: 'the year in print', needs: 25 },
  ];
  var UNLOCK_BY_ID = {}; UNLOCKS.forEach(function (u) { UNLOCK_BY_ID[u.id] = u; });
  var COST = { plant: 25, net: 20 };

  /* ---------------------------------------------------------------- a new observatory */
  function newGame(seed) {
    var cells = [];
    for (var y = 0; y < ROWS; y++) for (var x = 0; x < COLS; x++) {
      var ch = MAP[y][x], k = { '~': 'sea', '.': 'shore', g: 'grass', s: 'scrub', r: 'reed', w: 'wall', G: 'garden', L: 'light', H: 'hut', P: 'pool' }[ch];
      cells.push({ x: x, y: y, k: k, cover: k === 'scrub' ? 3 : k === 'reed' ? 3 : k === 'garden' ? 1 : 0, birds: {}, net: false, open: false });
    }
    var gm = { v: 1, seed: seed >>> 0, cells: cells, year: 1, day: 1, min: DAY_START, phase: 'season', money: 80, members: 12, reputation: 60,
      hands: 1, nets: [], trap: null, unlocked: {}, waitNet: [], bags: [], handsBusy: [0], lastRound: DAY_START, roundEvery: 30,
      ringed: 0, ringedBy: {}, listed: {}, firstDay: {}, recoveries: [], pending: [], released: 0, ringNo: 1000, moths: {}, mothNights: 0,
      seabirds: 0, log: [], seq: 0, stats: { caught: 0, ringed: 0, early: 0, falls: 0, visitors: 0, rarities: 0 }, weather: null, todayIn: 0, visitorsToday: 0 };
    // two starter nets beside the scrub nearest the hut
    gm.weather = makeWeather(gm, 1);
    // beside the two scrub clumps, where birds land: the first is open, the second is set but closed, so a new warden
    // learns one net (and its waiting bar) before opening a second
    seedNet(gm, 3, 2, true); seedNet(gm, 10, 0, false);
    say(gm, 'A new season on the headland. Watch the wind: an easterly with rain at dawn brings a fall.', 'info');
    dawn(gm);
    return gm;
  }
  function seedNet(gm, x, y, open) { var i = y * COLS + x; gm.cells[i].net = true; gm.cells[i].open = !!open; gm.nets.push(i); }

  function say(gm, text, kind) { gm.seq++; gm.log.push({ seq: gm.seq, day: gm.day, year: gm.year, min: gm.min, text: text, kind: kind || 'info' }); if (gm.log.length > 80) gm.log.splice(0, gm.log.length - 80); }

  /* ---------------------------------------------------------------- the weather */
  function makeWeather(gm, year) {
    var r = rng(gm.seed * 31 + year * 7919), days = [], dir = Math.floor(r() * 8), wet = 0;
    for (var d = 1; d <= SEASON_DAYS + 3; d++) {
      if (r() < 0.38) dir = (dir + (r() < 0.5 ? 1 : 7) + (r() < 0.2 ? 1 : 0)) % 8;   // the wind swings, a point or two at a time
      if (r() < 0.07) dir = 2 + Math.floor(r() * 2);                                    // an easterly airflow sets in
      var str = Math.max(1, Math.min(7, Math.round(2 + r() * 3 + (r() < 0.15 ? 2 : 0))));
      wet = r() < (wet ? 0.45 : 0.22) ? 1 : 0;
      var cloud = wet ? 1 : r() < 0.4 ? 1 : 0;
      days.push({ dir: DIRS[dir], str: str, rain: wet, cloud: cloud });
    }
    if (year === 1) days[0] = { dir: 'E', str: 2, rain: 1, cloud: 1 };   // the first morning of the first autumn: a light easterly with rain, a small fall for a first morning
    return { days: days };
  }
  /** the fall index of a day: how many night migrants come down on the headland (0 = they flew over) */
  function fallIndex(w) {
    var on = ONSHORE[w.dir], sky = w.rain ? 1.6 : w.cloud ? 0.9 : 0.25, push = Math.min(1.4, 0.5 + w.str * 0.15);
    return on * sky * push;
  }
  function today(gm) { return gm.weather.days[gm.day - 1]; }
  /** a plain sentence for the day's sky, the one the forecast and the log use */
  function describe(w) { return w.dir + ' ' + w.str + (w.rain ? ', rain at dawn' : w.cloud ? ', overcast' : ', clear'); }

  /* ---------------------------------------------------------------- arrivals */
  function phen(s, day) { var z = (day - s.pk) / s.wd; return Math.exp(-0.5 * z * z); }
  function attract(c, hab, unlocked) {
    if (c.k === 'scrub') return hab === 'scrub' ? 1 + c.cover * 0.5 : hab === 'garden' ? 0.6 : 0.2;
    if (c.k === 'reed') return hab === 'reed' ? 2 : 0.15;
    if (c.k === 'garden') return hab === 'garden' ? (unlocked.garden ? 2.6 : 0.9) : hab === 'scrub' ? (unlocked.garden ? 1 : 0.4) : 0.1;
    if (c.k === 'grass') return hab === 'open' ? 0.5 : c.cover > 0 ? (hab === 'scrub' ? 0.3 + c.cover * 0.35 : 0.15) : 0;
    if (c.k === 'shore') return hab === 'open' ? 0.4 : 0;
    return 0;
  }
  function dawn(gm) {
    var w = today(gm), f = fallIndex(w), r = rng(gm.seed * 131 + gm.year * 977 + gm.day);
    var size = 0.06 + f * 1.6, arrivals = 0, rares = [];
    gm.todayIn = 0;
    // overnight: most of yesterday's birds leave on a clear night, many stay when it is wet
    gm.cells.forEach(function (c) { for (var k in c.birds) { c.birds[k] = Math.floor(c.birds[k] * (w.rain ? 0.6 : w.cloud ? 0.4 : 0.15)); if (!c.birds[k]) delete c.birds[k]; } });
    SPECIES.forEach(function (s) {
      var mean = s.ab * phen(s, gm.day) * size * 1.3, n = 0;
      // Poisson by inversion, capped
      var L = Math.exp(-Math.min(mean, 60)), p = 1, k = 0; do { k++; p *= r(); } while (p > L && k < 400); n = k - 1;
      if (mean > 60) n = Math.round(mean + (r() - 0.5) * Math.sqrt(mean) * 2);
      if (!n) return;
      // spread them across the cover they like
      var weights = [], tot = 0;
      gm.cells.forEach(function (c, i) { var a = attract(c, s.hab, gm.unlocked); if (a > 0) { weights.push([i, a]); tot += a; } });
      for (var b = 0; b < n; b++) { var t = r() * tot; for (var q = 0; q < weights.length; q++) { t -= weights[q][1]; if (t <= 0) { var cc = gm.cells[weights[q][0]]; cc.birds[s.id] = (cc.birds[s.id] || 0) + 1; break; } } }
      arrivals += n; if (s.rare === 2) rares.push(s.name);
    });
    gm.todayIn = arrivals;
    var sky = describe(w);
    if (f > 1.1 && arrivals > 60) { gm.stats.falls++; say(gm, 'Day ' + gm.day + ': ' + sky + '. A FALL. Every bush is full of birds.', 'good'); }
    else if (arrivals < 12) say(gm, 'Day ' + gm.day + ': ' + sky + '. The migrants flew over. A quiet day is a quiet day.', 'info');
    else say(gm, 'Day ' + gm.day + ': ' + sky + '. Birds in the bushes.', 'info');
    if (rares.length) say(gm, 'Something different in the bushes this morning.', 'good');
    // visitors come for a fall, a rarity and a seawatch
    var vis = Math.round((f > 1.1 ? 3 + arrivals / 30 : arrivals / 60) + rares.length * 4 + (gm.unlocked.seawatch && ONSHORE[w.dir] > 0.6 ? 2 + w.str : 0));
    gm.visitorsToday = vis; gm.stats.visitors += vis; gm.money += vis;
    if (gm.unlocked.seawatch && ONSHORE[w.dir] > 0.6) { var sb = Math.round(w.str * 40 * (0.6 + r())); gm.seabirds += sb; say(gm, 'Seawatch: ' + sb + ' seabirds past the point on the ' + w.dir + ' wind.', 'info'); }
    // nets are furled in rain at dawn and opened when it clears (soaked birds in a net is the one thing never done)
    gm.rainUntil = w.rain ? DAY_START + 60 + Math.floor(r() * 90) : DAY_START;
  }

  /* ---------------------------------------------------------------- the clock */
  function activity(min) { var h = min / 60; return h < 10 ? 1 : h < 13 ? 0.55 : 0.32; }
  function neighbours(i) { var x = i % COLS, y = Math.floor(i / COLS), out = []; for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) { var a = x + dx, b = y + dy; if (a >= 0 && b >= 0 && a < COLS && b < ROWS) out.push(b * COLS + a); } return out; }
  function birdsNear(gm, i) { var n = 0; neighbours(i).forEach(function (j) { for (var k in gm.cells[j].birds) n += gm.cells[j].birds[k]; }); return n; }
  function takeBird(gm, i, r) {
    var pool = []; neighbours(i).forEach(function (j) { for (var k in gm.cells[j].birds) pool.push([j, k, gm.cells[j].birds[k]]); });
    var tot = 0; pool.forEach(function (p) { tot += p[2]; }); if (!tot) return null;
    var t = r() * tot; for (var q = 0; q < pool.length; q++) { t -= pool[q][2]; if (t <= 0) { var c = gm.cells[pool[q][0]]; c.birds[pool[q][1]]--; if (!c.birds[pool[q][1]]) delete c.birds[pool[q][1]]; return pool[q][1]; } }
    return null;
  }
  function wetNow(gm) { return gm.min < gm.rainUntil; }
  function netsOpen(gm) { return wetNow(gm) ? 0 : gm.nets.filter(function (i) { return gm.cells[i].open; }).length; }

  /** advance the observatory by `minutes` (whole STEPs). Returns nothing; everything that happened is in gm.log. */
  function step(gm, minutes) {
    if (gm.phase !== 'season') return;
    var n = Math.max(1, Math.round(minutes / STEP));
    for (var s = 0; s < n && gm.phase === 'season'; s++) tick(gm);
  }
  function tick(gm) {
    var r = rng(gm.seed * 7 + gm.year * 104729 + gm.day * 1009 + gm.min);
    var act = activity(gm.min), w = today(gm), wind = w.str >= 6 ? 0.45 : 1;
    // 1 catches
    if (!wetNow(gm)) gm.nets.forEach(function (i) {
      var c = gm.cells[i]; if (!c.open) return;
      var near = birdsNear(gm, i), p = Math.min(0.9, near * 0.05 * act * wind);
      var tries = p > 0 ? (r() < p ? 1 : 0) + (r() < p * 0.6 ? 1 : 0) + (r() < p * 0.3 ? 1 : 0) : 0;
      for (var t = 0; t < tries; t++) { var sp = takeBird(gm, i, r); if (!sp) break; gm.waitNet.push({ sp: sp, net: i, at: gm.min }); gm.stats.caught++; }
    });
    if (gm.trap !== null) {
      var near2 = birdsNear(gm, gm.trap), p2 = Math.min(0.8, near2 * 0.03 * act);
      if (r() < p2) { var sp2 = takeBird(gm, gm.trap, r); if (sp2) { gm.bags.push({ sp: sp2, at: gm.min, trap: true }); gm.stats.caught++; } }
    }
    // 2 the hands: a round when a bird has waited 20 minutes or the round is due; otherwise the ringing table
    for (var h = 0; h < gm.hands; h++) {
      if (gm.handsBusy[h] > gm.min) continue;
      var oldest = gm.waitNet.length ? gm.min - gm.waitNet[0].at : 0;
      if (gm.waitNet.length && (oldest >= 20 || gm.min - gm.lastRound >= gm.roundEvery)) {
        var nb = gm.waitNet.length, cost = 6 + netsOpen(gm) * 2 + Math.ceil(nb * 1.5);
        gm.waitNet.forEach(function (b) { gm.bags.push({ sp: b.sp, at: b.at }); });
        gm.waitNet = []; gm.lastRound = gm.min; gm.handsBusy[h] = gm.min + cost;
      } else if (gm.bags.length) {
        var b = gm.bags.shift(), sp = BY_ID[b.sp];
        gm.handsBusy[h] = gm.min + 2 + Math.round(sp.dif * 1.5);
        ring(gm, b, r);
      }
    }
    // 3 the welfare clock: never leave a bird. 40 minutes in a net or 70 in a bag and it goes free, unringed (the clock
    //   ticks in 10 minute steps, so a limit that is a multiple of 10 is the limit a player is told)
    var early = 0;
    gm.waitNet = gm.waitNet.filter(function (b) { if (gm.min - b.at >= NET_LIMIT) { early++; return false; } return true; });
    gm.bags = gm.bags.filter(function (b) { if (gm.min - b.at >= (b.trap ? TRAP_LIMIT : BAG_LIMIT)) { early++; return false; } return true; });
    if (early) {
      gm.stats.early += early; gm.released += early;
      // the first morning of the first autumn is a grace: the release is counted, the members are not told, and the
      // first release ever is explained once, in amber, before any red line appears
      var grace = gm.year === 1 && gm.day === 1;
      if (!grace) gm.reputation = Math.max(0, gm.reputation - early * 2);
      if (!gm.toldRelease) { gm.toldRelease = true; say(gm, early + (early === 1 ? ' bird' : ' birds') + ' let go unringed: a bird may wait ' + NET_LIMIT + ' minutes in a net or ' + BAG_LIMIT + ' in a bag. When the bar under the map turns amber, close a net.', 'warn'); }
      else say(gm, early + (early === 1 ? ' bird' : ' birds') + ' let go unringed: they waited too long. Close a net or two when the bags back up.', grace ? 'warn' : 'bad');
    }
    // 4 birds move on through the day
    // each bird leaves on its own chance (a whole-cell multiply floored to an integer emptied every cell of one bird each hour)
    if (gm.min % 60 === 0) { var pLeave = w.rain ? 0.05 : gm.min >= 13 * 60 ? 0.12 : 0.08; gm.cells.forEach(function (c) { for (var k in c.birds) { var n = c.birds[k], go = 0; for (var q = 0; q < n; q++) if (r() < pLeave) go++; c.birds[k] = n - go; if (!c.birds[k]) delete c.birds[k]; } }); }
    // 5 recoveries arrive
    for (var q = gm.pending.length - 1; q >= 0; q--) { var pr = gm.pending[q]; if (pr.year === gm.year && pr.day === gm.day && pr.min <= gm.min) { gm.pending.splice(q, 1); recover(gm, pr); } }
    gm.min += STEP;
    if (gm.min >= DAY_END) endDay(gm);
  }

  function ring(gm, b, r) {
    var sp = BY_ID[b.sp], first = !gm.listed[sp.id];
    gm.ringNo++; gm.ringed++; gm.stats.ringed++; gm.ringedBy[sp.id] = (gm.ringedBy[sp.id] || 0) + 1;
    var age = r() < 0.72 ? 'first-winter' : 'adult', sex = sp.sexed ? (r() < 0.5 ? 'male' : 'female') : '';
    gm.last = { sp: sp.id, ring: ringCode(gm.ringNo), age: age, sex: sex, trap: !!b.trap };
    if (first) { gm.listed[sp.id] = { day: gm.day, year: gm.year }; gm.members += sp.rare === 2 ? 4 : sp.rare === 1 ? 2 : 1; say(gm, 'New for the year list: ' + sp.name + (sp.rare === 2 ? '. A rarity in the hand!' : '.'), sp.rare ? 'good' : 'info'); }
    if (sp.rare === 2) { gm.stats.rarities++; gm.money += 15; }
    if (gm.ringed % 25 === 0) gm.members++;   // every 25 rings, word gets round
    // will this ring be found again?
    if (r() < sp.rec * 4) {
      var places = PLACES[sp.route], pl = places[Math.floor(r() * places.length)], later = 3 + Math.floor(r() * 50);
      var day = gm.day + later, year = gm.year; while (day > SEASON_DAYS) { day -= SEASON_DAYS; year++; }
      gm.pending.push({ sp: sp.id, ring: ringCode(gm.ringNo), place: pl.n, lon: pl.lon, lat: pl.lat, day: day, year: year, min: DAY_START + 120 + Math.floor(r() * 360), ringedDay: gm.day, ringedYear: gm.year });
    }
  }
  function ringCode(n) { return 'FW' + String(n).padStart(5, '0'); }
  /** the great-circle distance from the headland, to the nearest 10 km */
  function km(lon, lat) {
    var rad = Math.PI / 180, p1 = HOME.lat * rad, p2 = lat * rad, dp = p2 - p1, dl = (lon - HOME.lon) * rad;
    var a = Math.sin(dp / 2) * Math.sin(dp / 2) + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
    return Math.round(6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)) / 10) * 10;
  }
  function recover(gm, pr) {
    var sp = BY_ID[pr.sp], days = (pr.year - pr.ringedYear) * SEASON_DAYS + (pr.day - pr.ringedDay);
    pr.km = km(pr.lon, pr.lat); pr.days = days;
    gm.recoveries.push(pr); gm.members += 3; gm.money += 8;
    say(gm, 'A ring reported: ' + sp.name + ' ' + pr.ring + ', found at ' + pr.place + ', ' + pr.km.toLocaleString('en-GB') + ' km, ' + days + ' days after ringing.', 'good');
  }

  function endDay(gm) {
    // the members pay, the night list, then the next dawn
    var dues = Math.round(gm.members * 0.3); gm.money += dues;
    if (gm.unlocked.moth) night(gm);
    gm.waitNet.forEach(function (b) { gm.bags.push({ sp: b.sp, at: DAY_END - 10 }); }); gm.waitNet = [];
    var r = rng(gm.seed + gm.day * 13 + gm.year * 71);
    while (gm.bags.length) ring(gm, gm.bags.shift(), r);   // the last bags are ringed before dark
    gm.handsBusy = gm.handsBusy.map(function () { return 0; });
    gm.reputation = Math.min(100, gm.reputation + 1);
    if (gm.reputation >= 70 && gm.day % 5 === 0) gm.members++;
    if (gm.reputation < 30 && gm.day % 3 === 0) { gm.members = Math.max(0, gm.members - 1); say(gm, 'A member left after hearing of birds let go unringed.', 'bad'); }
    // planted cover grows
    gm.cells.forEach(function (c) { if (c.k === 'grass' && c.cover > 0 && c.cover < 3) c.cover = Math.min(3, c.cover + 0.25); });
    gm.day++; gm.min = DAY_START; gm.lastRound = DAY_START;
    if (gm.day > SEASON_DAYS) { endSeason(gm); return; }
    dawn(gm);
  }
  function night(gm) {
    var w = today(gm), r = rng(gm.seed * 3 + gm.day * 37 + gm.year * 5), warm = (w.cloud ? 1.3 : 0.7) * (w.str <= 3 ? 1.2 : 0.7), n = 0, newOnes = [];
    MOTHS.forEach(function (m) { var mean = m.ab * phen(m, gm.day) * warm * 1.4, k = 0; for (var i = 0; i < 12; i++) if (r() < mean / 12) k++; if (k) { if (!gm.moths[m.id]) newOnes.push(m.name); gm.moths[m.id] = (gm.moths[m.id] || 0) + k; n += k; } });
    gm.mothNights++; gm.lastTrap = n;
    if (n) say(gm, 'Moth trap: ' + n + ' moths' + (newOnes.length ? ', new: ' + newOnes.join(', ') : '') + '.', newOnes.length ? 'good' : 'info');
    if (newOnes.length) gm.members += newOnes.length;
  }
  function endSeason(gm) {
    gm.phase = 'over';
    gm.summary = { year: gm.year, ringed: gm.stats.ringed, species: Object.keys(gm.listed).length, recoveries: gm.recoveries.length, early: gm.stats.early, falls: gm.stats.falls };
    say(gm, 'The season is over. ' + gm.stats.ringed + ' birds ringed, ' + Object.keys(gm.listed).length + ' species.', 'good');
  }
  /** the next autumn: the headland, the nets, the members and the year list carry on */
  function nextSeason(gm) {
    if (gm.phase !== 'over') return 'the season is still running';
    gm.year++; gm.day = 1; gm.min = DAY_START; gm.phase = 'season'; gm.weather = makeWeather(gm, gm.year);
    gm.stats = { caught: 0, ringed: 0, early: 0, falls: 0, visitors: 0, rarities: 0 }; gm.summary = null; gm.last = null;
    gm.cells.forEach(function (c) { c.birds = {}; });
    say(gm, 'Autumn ' + gm.year + ' on the headland.', 'info');
    dawn(gm);
    return '';
  }

  /* ---------------------------------------------------------------- what the player does */
  function canNetAt(gm, i) {
    var c = gm.cells[i]; if (!c) return 'not on the headland';
    if (c.net) return 'there is a net here already';
    if (c.k === 'reed') return gm.unlocked.reedride ? '' : 'nets in the reeds need the reedbed ride';
    if (c.k !== 'grass' && c.k !== 'shore') return 'a net stands on open ground beside cover';
    var cover = neighbours(i).some(function (j) { var d = gm.cells[j]; return d.k === 'scrub' || d.k === 'reed' || d.k === 'garden' || d.cover >= 1; });
    return cover ? '' : 'set a net beside cover, where birds are';
  }
  function maxNets(gm) { return 3 + (gm.unlocked.ride2 ? 3 : 0) + (gm.unlocked.reedride ? 3 : 0) + (gm.unlocked.ringer2 ? 1 : 0); }
  function setNet(gm, i) {
    var why = canNetAt(gm, i); if (why) return why;
    if (gm.nets.length >= maxNets(gm)) return 'every net you own is up: buy a net ride for more';
    if (gm.money < COST.net) return 'a net costs £' + COST.net;
    gm.money -= COST.net; gm.cells[i].net = true; gm.cells[i].open = true; gm.nets.push(i); return '';
  }
  function toggleNet(gm, i) { var c = gm.cells[i]; if (!c || !c.net) return 'no net here'; c.open = !c.open; return ''; }
  function takeDownNet(gm, i) {
    var c = gm.cells[i]; if (!c || !c.net) return 'no net here';
    gm.waitNet.forEach(function (b) { if (b.net === i) gm.bags.push({ sp: b.sp, at: b.at }); }); gm.waitNet = gm.waitNet.filter(function (b) { return b.net !== i; });
    c.net = false; c.open = false; gm.nets = gm.nets.filter(function (n) { return n !== i; }); gm.money += Math.floor(COST.net / 2); return '';
  }
  function plant(gm, i) {
    var c = gm.cells[i]; if (!c) return 'not on the headland';
    if (c.k !== 'grass') return 'plant on open grass';
    if (c.net) return 'a net stands there';
    if (c.cover >= 1) return 'already planted';
    var cost = gm.unlocked.garden ? Math.round(COST.plant * 0.6) : COST.plant;
    if (gm.money < cost) return 'planting costs £' + cost;
    gm.money -= cost; c.cover = gm.unlocked.garden ? 1.5 : 0.5; return '';
  }
  function placeTrap(gm, i) {
    if (!gm.unlocked.trap) return 'buy the Heligoland trap first';
    var c = gm.cells[i]; if (!c || (c.k !== 'garden' && c.k !== 'scrub')) return 'the trap stands in the garden or the scrub';
    gm.trap = i; return '';
  }
  function setRound(gm, mins) { if ([20, 30, 45].indexOf(mins) < 0) return 'rounds every 20, 30 or 45 minutes'; gm.roundEvery = mins; return ''; }
  function buy(gm, id) {
    var u = UNLOCK_BY_ID[id]; if (!u) return 'nothing called that';
    if (gm.unlocked[id]) return 'already done';
    if (u.needs && Object.keys(gm.listed).length < u.needs) return 'the report needs ' + u.needs + ' species on the list';
    if (gm.money < u.cost) return u.name + ' costs £' + u.cost;
    gm.money -= u.cost; gm.unlocked[id] = { day: gm.day, year: gm.year };
    if (id === 'ringer2') { gm.hands = 2; gm.handsBusy.push(0); }
    if (id === 'trap') { var g = -1; gm.cells.forEach(function (c, i) { if (g < 0 && c.k === 'garden') g = i; }); gm.trap = g; }
    say(gm, u.name + ': done. ' + u.why.charAt(0).toUpperCase() + u.why.slice(1) + '.', 'good');
    return '';
  }
  /** tomorrow, for the weather instruments (a forecast is the day's own weather: honest instruments) */
  function forecast(gm, ahead) { var d = gm.weather.days[gm.day - 1 + ahead]; if (!d) return null; return { sky: describe(d), fall: fallIndex(d), w: d }; }

  return {
    COLS: COLS, ROWS: ROWS, STEP: STEP, NET_LIMIT: NET_LIMIT, BAG_LIMIT: BAG_LIMIT, TRAP_LIMIT: TRAP_LIMIT, DAY_START: DAY_START, DAY_END: DAY_END, SEASON_DAYS: SEASON_DAYS,
    SPECIES: SPECIES, BY_ID: BY_ID, MOTHS: MOTHS, MOTH_BY_ID: MOTH_BY_ID, PLACES: PLACES, HOME: HOME, UNLOCKS: UNLOCKS, COST: COST, DIRS: DIRS,
    rng: rng, hash: hash, newGame: newGame, step: step, fallIndex: fallIndex, describe: describe, today: today, forecast: forecast,
    setNet: setNet, toggleNet: toggleNet, takeDownNet: takeDownNet, plant: plant, placeTrap: placeTrap, setRound: setRound, buy: buy, nextSeason: nextSeason,
    canNetAt: canNetAt, maxNets: maxNets, netsOpen: netsOpen, wetNow: wetNow, birdsNear: birdsNear, km: km,
  };
}());
if (typeof module === 'object' && module.exports) module.exports = SIM;
