/**
 * art.js - FLYWAY's bird and moth renderer. One parametric bird drawn from each species' own row below (build, bill,
 * and the plumage regions a ringer reads: cap, crown stripe, supercilium, eye-stripe, mask, bib, breast spots or
 * streaks, wing bars and panels, tail pattern), lit from the upper left. It draws LARGE in the hand at the ringing
 * table and SMALL in the field, where the same drawing is struck onto a tiny canvas and kept crisp.
 * Nothing here is an image file: every bird and moth is generated.
 */
'use strict';

var ART = (function () {
  /* ---------------------------------------------------------------- the birds' plumage rows */
  // b: build {w body length, h body depth, head, tail, tilt}  bill: [length, depth, colour, curve]  legs colour
  // up upperparts, cr crown, fa face, th throat, br breast, be belly, fl flank, wi wing, ta tail
  // patterns: cap, crs (crown stripe [centre, border]), sup (supercilium), eye (eye-stripe), mask, ring (eye-ring),
  // cheek, bib, spots (breast spots), streak (breast streaks), bars [colour, count], panel (wing panel), rump, tedge
  // (white outer tail), tbase (pale tail base, a wheatear's T), tred (red tail), m/f: overrides by sex
  var BUILD = {
    warbler: { w: 0.62, h: 0.3, head: 0.17, tail: 0.32, tilt: -0.12 },
    crest: { w: 0.5, h: 0.32, head: 0.19, tail: 0.22, tilt: -0.08 },
    plump: { w: 0.55, h: 0.38, head: 0.19, tail: 0.24, tilt: -0.2 },
    wren: { w: 0.5, h: 0.36, head: 0.17, tail: 0.18, tilt: -0.1, cock: 1 },
    chat: { w: 0.58, h: 0.33, head: 0.17, tail: 0.3, tilt: -0.32 },
    thrush: { w: 0.7, h: 0.36, head: 0.18, tail: 0.38, tilt: -0.22 },
    finch: { w: 0.58, h: 0.34, head: 0.19, tail: 0.32, tilt: -0.15, fork: 1 },
    bunting: { w: 0.62, h: 0.32, head: 0.18, tail: 0.4, tilt: -0.12, fork: 1 },
    pipit: { w: 0.66, h: 0.28, head: 0.16, tail: 0.42, tilt: -0.05 },
    fly: { w: 0.58, h: 0.32, head: 0.19, tail: 0.32, tilt: -0.35 },
    shrike: { w: 0.66, h: 0.33, head: 0.2, tail: 0.46, tilt: -0.3 },
    wryneck: { w: 0.7, h: 0.3, head: 0.17, tail: 0.44, tilt: -0.05 },
    woodcock: { w: 0.78, h: 0.42, head: 0.21, tail: 0.18, tilt: 0.05 },
  };
  var B = {
    robin: { b: 'plump', bill: [0.12, 0.05, '#2a2420'], legs: '#a58a72', up: '#7d6d4f', cr: '#7d6d4f', fa: '#e2652e', th: '#e2652e', br: '#e8692f', be: '#efe9df', fl: '#c9b49a', wi: '#776648', ta: '#6f5e44', edgeFace: '#9aa3a8' },
    goldcrest: { b: 'crest', bill: [0.08, 0.03, '#2a2a24'], legs: '#9c8d5e', up: '#8a9a4c', cr: '#8a9a4c', fa: '#b9c08f', th: '#d9d7b8', br: '#d6d2ae', be: '#e6e1c6', fl: '#c6c39a', wi: '#6c7a3a', ta: '#6a7638', crs: ['#f2c22a', '#1f201c'], ring: '#e8e6cf', bars: ['#f1f0e0', 2], m: { crs: ['#f08a1c', '#1f201c'] } },
    chiffchaff: { b: 'warbler', bill: [0.11, 0.035, '#2b2a26'], legs: '#2b2620', up: '#7d7d55', cr: '#7d7d55', fa: '#a9a580', th: '#e6e0c4', br: '#dcd5b2', be: '#ebe6d3', fl: '#c8bf98', wi: '#6c6c47', ta: '#66664a', sup: '#ddd8b4', eye: '#5e5b40', ring: '#e8e2c4' },
    willow: { b: 'warbler', bill: [0.12, 0.035, '#6b5a3a'], legs: '#c4a27a', up: '#86913f', cr: '#86913f', fa: '#c9c66e', th: '#f1e88a', br: '#ede07a', be: '#f4efce', fl: '#d9cf7c', wi: '#6f7a34', ta: '#6d7535', sup: '#f2e58a', eye: '#646a2c' },
    blackcap: { b: 'warbler', bill: [0.12, 0.04, '#2a2a2a'], legs: '#3b3836', up: '#7b7b74', cr: '#7b7b74', fa: '#a7a8a3', th: '#c9cac6', br: '#bebfba', be: '#e2e2de', fl: '#b0b0a8', wi: '#6a6a62', ta: '#64645c', cap: '#161616', f: { cap: '#9a4f2a' } },
    gardenw: { b: 'warbler', bill: [0.13, 0.05, '#4c463c'], legs: '#77727a', up: '#8a8166', cr: '#8a8166', fa: '#b8b29b', th: '#dcd6c3', br: '#d3cab1', be: '#e7e2d4', fl: '#c4b998', wi: '#7c735a', ta: '#766e58', ring: '#ddd6c0', sideneck: '#a3a7a8' },
    lwhitethroat: { b: 'warbler', bill: [0.12, 0.045, '#2e2c2a'], legs: '#3e3c3c', up: '#8e8a7e', cr: '#7d8188', fa: '#4b4c50', th: '#f7f6f2', br: '#ebe6dc', be: '#f2efe8', fl: '#d8d0c0', wi: '#7a7266', ta: '#5f5c58', tedge: '#e6e3dc', mask: '#4b4c50' },
    whitethroat: { b: 'warbler', bill: [0.12, 0.045, '#5a4d40'], legs: '#c2a582', up: '#8c7656', cr: '#8f9196', fa: '#8f9196', th: '#fbfaf6', br: '#e8d8c6', be: '#f1ebe1', fl: '#dcc6aa', wi: '#a06e3c', ta: '#6e5f4c', tedge: '#e8e2d6', ring: '#ece6da', f: { cr: '#8c7656', fa: '#9c8a70', br: '#ece2d2' } },
    sedge: { b: 'warbler', bill: [0.12, 0.04, '#4a3d30'], legs: '#9e8a72', up: '#8f7a54', cr: '#4c4232', fa: '#a59272', th: '#f0e6cf', br: '#ead9b8', be: '#f2ead8', fl: '#d8c094', wi: '#7a6646', ta: '#7a6646', sup: '#f1e4c0', eye: '#5a4b36', backstreak: '#4e4130', rump: '#b2884e' },
    reedw: { b: 'warbler', bill: [0.15, 0.04, '#5c5040'], legs: '#8e7d6a', up: '#9a7f58', cr: '#9a7f58', fa: '#b59c78', th: '#f2eadb', br: '#e8d8bc', be: '#f1e9da', fl: '#d9bf95', wi: '#8b7050', ta: '#8b7050', sup: '#e6d6b8', rump: '#b08454' },
    reedbunting: { b: 'bunting', bill: [0.1, 0.07, '#4d4740'], legs: '#8b6f5a', up: '#8c6a44', cr: '#5e4a34', fa: '#8a6d4e', th: '#e6dccb', br: '#d9cdb8', be: '#ece5d8', fl: '#c8b394', wi: '#7a5634', ta: '#3e342c', tedge: '#f2efe8', sup: '#d8c8a8', streak: '#6a5640', backstreak: '#3c3024', mous: '#3c3228', m: { cr: '#171513', fa: '#171513', th: '#171513', sup: null, collar: '#f2efe8', mous: '#f2efe8' } },
    wren: { b: 'wren', bill: [0.13, 0.03, '#4a3b2c'], legs: '#9c8066', up: '#7c5838', cr: '#7c5838', fa: '#a07c58', th: '#c9a988', br: '#bd9a76', be: '#c6a582', fl: '#8e6a4a', wi: '#6e4c30', ta: '#6a4a30', sup: '#d6bc9a', barring: '#4a3424' },
    dunnock: { b: 'warbler', bill: [0.11, 0.04, '#2e2a26'], legs: '#c49270', up: '#7a5c3e', cr: '#6f7177', fa: '#6f7177', th: '#7d8086', br: '#7c7f86', be: '#cfc8bc', fl: '#9c826a', wi: '#6b4c32', ta: '#5f4834', backstreak: '#3e2c1e', flstreak: '#6b5038' },
    songthrush: { b: 'thrush', bill: [0.14, 0.05, '#4a4036'], legs: '#d1ad94', up: '#7d6448', cr: '#7d6448', fa: '#c4a882', th: '#f1e8d6', br: '#ecd8a6', be: '#f3eee3', fl: '#e2cc9a', wi: '#6e5640', ta: '#6e5640', spots: '#3a2c20', bars: ['#c8a676', 1] },
    redwing: { b: 'thrush', bill: [0.13, 0.05, '#3a3632'], legs: '#c9a487', up: '#6e5a48', cr: '#6e5a48', fa: '#6a5646', th: '#f2ede4', br: '#f0ebe2', be: '#f4f0ea', fl: '#c8402a', wi: '#5e4c3c', ta: '#5e4c3c', sup: '#f5efe2', streak: '#4a3a2c', mous: '#f0e8da' },
    blackbird: { b: 'thrush', bill: [0.13, 0.055, '#f0a21e'], legs: '#3a2c22', up: '#1a1816', cr: '#1a1816', fa: '#1a1816', th: '#1e1b18', br: '#1c1916', be: '#1f1c19', fl: '#1c1a17', wi: '#14120f', ta: '#121010', ring: '#f2b23a', f: { bill: [0.13, 0.055, '#8c6a3a'], up: '#4c3828', cr: '#4c3828', fa: '#4c3828', th: '#8e6e50', br: '#6e543c', be: '#5e4a36', fl: '#5a4634', wi: '#40301f', ta: '#3a2c1e', ring: null, streak: '#3a2a1c' } },
    fieldfare: { b: 'thrush', bill: [0.13, 0.055, '#e2b04a'], legs: '#3a302a', up: '#8a5a3c', cr: '#8f969c', fa: '#8f969c', th: '#e8b44c', br: '#e6a648', be: '#f2efe8', fl: '#e7dccb', wi: '#6e4c34', ta: '#2a2420', rump: '#9aa1a6', spots: '#2c2420', sup: '#f2efe8' },
    ringouzel: { b: 'thrush', bill: [0.13, 0.055, '#d4b04a'], legs: '#3a302a', up: '#2a2622', cr: '#2a2622', fa: '#2a2622', th: '#2c2824', br: '#2a2622', be: '#2e2a26', fl: '#2c2824', wi: '#5c5852', ta: '#1e1c1a', bib: '#f1ece2', scale: '#8a847c', f: { bib: '#c9bca8' } },
    redstart: { b: 'chat', bill: [0.11, 0.035, '#262422'], legs: '#2a2624', up: '#8e939a', cr: '#8e939a', fa: '#161616', th: '#161616', br: '#e5652a', be: '#efe2d6', fl: '#e8803e', wi: '#6e6a66', ta: '#d8502a', tred: 1, sup: '#f4f2ee', f: { up: '#9a8a76', cr: '#9a8a76', fa: '#b9a88e', th: '#e8dccb', br: '#e8c8a2', fl: '#e6c29a', sup: null } },
    blackredstart: { b: 'chat', bill: [0.11, 0.035, '#262422'], legs: '#2a2624', up: '#3f4246', cr: '#3f4246', fa: '#141414', th: '#141414', br: '#1e1e20', be: '#6e6c6a', fl: '#3c3c3e', wi: '#2e2e30', ta: '#c8502a', tred: 1, panel: '#e9e6e0', f: { up: '#55504c', cr: '#55504c', fa: '#55504c', th: '#5c5752', br: '#5c5752', be: '#7a746e', fl: '#5c5752', wi: '#45403c', panel: null } },
    piedfly: { b: 'fly', bill: [0.1, 0.04, '#161616'], legs: '#202020', up: '#7a6e60', cr: '#7a6e60', fa: '#f2f0ec', th: '#f6f5f2', br: '#f2f0ec', be: '#f6f5f2', fl: '#e8e4dc', wi: '#2a2622', ta: '#2a2622', panel: '#f6f5f2', tedge: '#f2f0ec', m: { up: '#161616', cr: '#161616', forehead: '#f6f5f2' } },
    spotfly: { b: 'fly', bill: [0.11, 0.045, '#262422'], legs: '#262422', up: '#8b8578', cr: '#7c766a', fa: '#c8c2b6', th: '#f2efe8', br: '#e9e5dc', be: '#f2f0ea', fl: '#ddd6c8', wi: '#78726a', ta: '#6e685e', streak: '#8a8070', crstreak: '#4e4a42' },
    wheatear: { b: 'chat', bill: [0.11, 0.035, '#161616'], legs: '#161616', up: '#9aa0a2', cr: '#9aa0a2', fa: '#1a1a1a', th: '#f0dcc0', br: '#efcfa4', be: '#f4eee4', fl: '#ecd6b6', wi: '#2a2622', ta: '#1a1a1a', tbase: '#f6f4f0', rump: '#f6f4f0', sup: '#f6f4f0', mask: '#1a1a1a', f: { up: '#a08870', cr: '#a08870', fa: '#8a7258', mask: '#8a7258', wi: '#5a4a3a', sup: '#ecdcc4' } },
    whinchat: { b: 'chat', bill: [0.1, 0.035, '#1e1c1a'], legs: '#262220', up: '#8a6a44', cr: '#6e5638', fa: '#4e3c2a', th: '#f0b878', br: '#ecb070', be: '#f1e6d4', fl: '#e2b88a', wi: '#5a4430', ta: '#3a2e24', tedge: '#f2efe8', sup: '#f4ece0', mask: '#4e3c2a', backstreak: '#4a3826', panel: '#f2efe8', f: { fa: '#8a6e50', mask: '#8a6e50', th: '#eccba0', br: '#e8c6a0', sup: '#ecdcc4' } },
    stonechat: { b: 'chat', bill: [0.1, 0.035, '#161616'], legs: '#161616', up: '#4a3c30', cr: '#161616', fa: '#161616', th: '#161616', br: '#d9692c', be: '#f0e6da', fl: '#e0884a', wi: '#2e2620', ta: '#1e1a18', collar: '#f4f2ee', panel: '#f4f2ee', f: { cr: '#6a5440', fa: '#6a5440', th: '#8a7258', br: '#d8946a', collar: '#cdbfae', backstreak: '#3e3024' } },
    treepipit: { b: 'pipit', bill: [0.12, 0.04, '#5a4e40'], legs: '#d6a88c', up: '#8a7c58', cr: '#8a7c58', fa: '#c4ae86', th: '#f2e8d4', br: '#ead9b0', be: '#f3eee4', fl: '#e1d0aa', wi: '#6e6044', ta: '#5a4e3a', tedge: '#f0ece2', sup: '#ebdcb8', streak: '#3e3226', backstreak: '#4e4430', mous: '#4a3c2c', bars: ['#e2d4b0', 2] },
    meadowpipit: { b: 'pipit', bill: [0.12, 0.035, '#5a4e40'], legs: '#d6b098', up: '#7f7a58', cr: '#7f7a58', fa: '#b3aa88', th: '#efe9da', br: '#e2dbc6', be: '#f0ede4', fl: '#d4cbb2', wi: '#5e5a40', ta: '#504c38', tedge: '#f0ece2', streak: '#2e2a22', flstreak: '#3a3428', backstreak: '#3c3a28', bars: ['#d8d0b0', 2] },
    chaffinch: { b: 'finch', bill: [0.1, 0.075, '#8a96a2'], legs: '#8a6e5e', up: '#8a6a4c', cr: '#6e8aa8', fa: '#d88a74', th: '#d8826c', br: '#d8826a', be: '#efe2d8', fl: '#d79a84', wi: '#2a2622', ta: '#2a2622', tedge: '#f2efe8', bars: ['#f4f2ec', 2], rump: '#8aa260', f: { cr: '#8a7c62', fa: '#b6a68c', th: '#cdbfa8', br: '#c9b9a2', fl: '#c4b49c', up: '#857258', bill: [0.1, 0.075, '#a89a88'] } },
    brambling: { b: 'finch', bill: [0.1, 0.075, '#e2b65a'], legs: '#8a6e5e', up: '#3a2e24', cr: '#2a2622', fa: '#3e342c', th: '#ec9a46', br: '#ec9a46', be: '#f4efe6', fl: '#e6a258', wi: '#262220', ta: '#262220', bars: ['#ec9a46', 2], rump: '#f4f2ee', flspot: '#2a2622', backstreak: '#1e1814', f: { cr: '#6e5e4e', fa: '#9a8c7c', th: '#e2a870', br: '#e2a870' } },
    siskin: { b: 'finch', bill: [0.1, 0.05, '#c8b48a'], legs: '#4a3c32', up: '#7c9238', cr: '#7c9238', fa: '#b8c64a', th: '#e8e45a', br: '#dcdc58', be: '#f2f0dc', fl: '#cdd282', wi: '#262620', ta: '#262620', bars: ['#e8e45a', 2], streak: '#5a6430', backstreak: '#4a5a22', sup: '#e8e45a', m: { cap: '#1a1a16', bib: null } },
    goldfinch: { b: 'finch', bill: [0.11, 0.06, '#f0e2c8'], legs: '#d2b8a2', up: '#b08a5c', cr: '#161616', fa: '#f4f2ee', th: '#f4f2ee', br: '#c99a68', be: '#f4f2ee', fl: '#cfa476', wi: '#161616', ta: '#161616', panel: '#f2d42a', mask: '#d8202a', tedge: '#f4f2ee', bars: ['#f4f2ee', 1], blaze: '#d8202a' },
    linnet: { b: 'finch', bill: [0.09, 0.06, '#7a7a80'], legs: '#5a4a44', up: '#a0784e', cr: '#8a8c94', fa: '#8a8c94', th: '#e8dccb', br: '#d4625a', be: '#efe8de', fl: '#c6a48a', wi: '#6e4a2c', ta: '#3e322a', tedge: '#f2efe8', panel: '#f2efe8', streak: '#8a6a52', f: { br: '#d6c2a8', cr: '#9a8a74', fa: '#a89a84' } },
    firecrest: { b: 'crest', bill: [0.09, 0.03, '#2a2a24'], legs: '#9c8d5e', up: '#7aa03a', cr: '#7aa03a', fa: '#c8cdc0', th: '#f1efe6', br: '#ecebe0', be: '#f4f2ea', fl: '#d6d6c2', wi: '#5c7232', ta: '#5a6c34', crs: ['#f2b81e', '#141414'], sup: '#f4f4f0', eye: '#1a1a1a', shoulder: '#e6b43a', bars: ['#f1f0e0', 2], m: { crs: ['#f06a1a', '#141414'] } },
    ybwarbler: { b: 'crest', bill: [0.1, 0.03, '#3a362c'], legs: '#9c8d6e', up: '#7e9446', cr: '#7a8c46', fa: '#c4c49a', th: '#f0eedc', br: '#ecebd8', be: '#f4f2e6', fl: '#dcdcc0', wi: '#4e5a2e', ta: '#5a6634', sup: '#f2eaa6', eye: '#3a4220', bars: ['#f2eec6', 2] },
    pallass: { b: 'crest', bill: [0.09, 0.03, '#2a2a24'], legs: '#9c8d6e', up: '#7aa040', cr: '#5e7a32', fa: '#c8d080', th: '#f0f0e0', br: '#ecebd8', be: '#f4f2e6', fl: '#dcdcc0', wi: '#4e6230', ta: '#5a6c34', crs: ['#eef0a0', '#4e6a2a'], sup: '#f4ec8a', eye: '#3a4a22', bars: ['#f2eec6', 2], rump: '#f2ec7a' },
    rbfly: { b: 'fly', bill: [0.09, 0.04, '#262422'], legs: '#262422', up: '#8c8072', cr: '#8c8072', fa: '#a39a8e', th: '#efe6da', br: '#e8dfd2', be: '#f4f2ec', fl: '#ddd2c2', wi: '#5e564c', ta: '#1e1c1a', tbase: '#f4f2ec', ring: '#f4efe6', m: { th: '#e2734a', fa: '#9aa0a6', cr: '#9aa0a6' } },
    barred: { b: 'shrike', bill: [0.13, 0.05, '#4a4440'], legs: '#8a8478', up: '#7c7c76', cr: '#7c7c76', fa: '#a8a8a2', th: '#ecebe6', br: '#e2e0d8', be: '#ecebe4', fl: '#d4d2c8', wi: '#6a6a64', ta: '#5e5e58', bars: ['#e8e6de', 2], barring: '#8e8c84', ring: '#f2e08a' },
    icterine: { b: 'warbler', bill: [0.15, 0.05, '#c8a46a'], legs: '#7c8aa0', up: '#8a9a54', cr: '#8a9a54', fa: '#d8d27a', th: '#f2e88e', br: '#efe282', be: '#f4eecc', fl: '#e2d898', wi: '#6e7c42', ta: '#6e7840', sup: '#f2e88e', panel: '#d6d6a6' },
    bluethroat: { b: 'chat', bill: [0.11, 0.035, '#1e1c1a'], legs: '#5a4a3e', up: '#7a6650', cr: '#7a6650', fa: '#7a6650', th: '#2a64c8', br: '#c84a2a', be: '#f0e8dc', fl: '#cdb79c', wi: '#6a5844', ta: '#2a2420', tbase: '#d8642e', sup: '#f2ebde', breastband: '#c84a2a', bib: '#2a64c8', redspot: '#c84a2a', f: { th: '#f2ebde', bib: '#2e2a28', redspot: null, breastband: '#2e2a28' } },
    wryneck: { b: 'wryneck', bill: [0.12, 0.045, '#6a5a48'], legs: '#9a8a74', up: '#8c8270', cr: '#8c8270', fa: '#c8b48a', th: '#e8d29a', br: '#e2cc96', be: '#efe8d6', fl: '#dccca4', wi: '#8e7c5c', ta: '#8e8470', barring: '#4a3e30', crown: '#3e3226', backstreak: '#3e3226', eye: '#5e4a34', vermic: 1 },
    rbshrike: { b: 'shrike', bill: [0.13, 0.06, '#161616'], legs: '#262422', up: '#a0523a', cr: '#9aa2aa', fa: '#9aa2aa', th: '#f6f2ee', br: '#ecd2cc', be: '#f4ece8', fl: '#e2c2b8', wi: '#9a4a32', ta: '#262422', tedge: '#f2efe8', mask: '#141414', f: { cr: '#8a6448', fa: '#a88a70', up: '#8a6448', wi: '#7a5038', mask: '#5a4434', barring: '#9a7a62', br: '#ece2d6' } },
    lapland: { b: 'bunting', bill: [0.1, 0.07, '#d8b47a'], legs: '#3a302a', up: '#8a6a44', cr: '#6e5636', fa: '#c4a07a', th: '#efe6d6', br: '#e4d8c4', be: '#f1ece2', fl: '#d8c8ae', wi: '#c0743a', ta: '#3e342c', tedge: '#f2efe8', bars: ['#f0e6d2', 2], streak: '#4e3e2c', backstreak: '#2e2418', sup: '#e8d4b0', nape: '#c8783a', cheek: '#8a6a4a', mous: '#3a2e22', panel: '#b86a34', m: { th: '#1a1816', fa: '#1a1816', cheek: '#1a1816', sup: '#f2ead8', nape: '#c0602a' }, f: { nape: '#b08a5c', cheek: '#a08060' } },
    snowbunting: { b: 'bunting', bill: [0.1, 0.07, '#e6b45a'], legs: '#262220', up: '#a8865c', cr: '#c8925a', fa: '#d6a46c', th: '#f6f2ea', br: '#e8c49a', be: '#f8f6f0', fl: '#ecd8bc', wi: '#f6f4ee', ta: '#2a2622', tedge: '#f6f4ee', panel: '#f6f4ee', backstreak: '#3a2c1e', primaries: '#262220', f: { cr: '#a07a50', fa: '#c49a68', wi: '#cfc4b0', panel: '#e8e2d4' } },
    woodcock: { b: 'woodcock', bill: [0.42, 0.045, '#9a7e64'], legs: '#a89c88', up: '#9a7450', cr: '#3e2e20', fa: '#c8a876', th: '#d8bc90', br: '#c8a87c', be: '#ccb08a', fl: '#b8966c', wi: '#8a6440', ta: '#4a3828', barring: '#5a4028', headbars: '#3e2e20', backstreak: '#3e2c1c', vermic: 1, eye: null },
  };

  /* ---------------------------------------------------------------- helpers */
  function hex(h) { return [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)]; }
  function rgb(c) { return 'rgb(' + c[0] + ',' + c[1] + ',' + c[2] + ')'; }
  function shade(h, k) { var c = hex(h); return rgb(c.map(function (v) { return Math.max(0, Math.min(255, Math.round(k > 1 ? v + (255 - v) * (k - 1) : v * k))); })); }
  function plume(id, sex) {
    var base = B[id]; if (!base) throw new Error('no plumage row for ' + id);
    var o = {}; for (var k in base) o[k] = base[k];
    var over = sex === 'male' ? base.m : sex === 'female' ? base.f : null;
    if (over) for (var k2 in over) o[k2] = over[k2];
    return o;
  }

  /**
   * draw one bird in profile, facing right, its body centred on (x, y), `len` pixels from bill tip to tail tip.
   * opts: { sex: 'male'|'female'|'', outline: true, flip: false, wings: 0..1 (a spread wing in the hand) }
   */
  var BIG = {}, BIG_N = 0;
  /**
   * draw one bird in profile, facing right, centred on (x, y), `len` px from bill tip to tail tip. The bird is drawn on
   * its OWN canvas (so the light falls only on the bird) and cached per (species, size, sex, flip).
   */
  function bird(g, id, x, y, len, opts) {
    opts = opts || {};
    var key = id + ':' + Math.round(len) + ':' + (opts.sex || '') + ':' + (opts.flip ? 1 : 0) + ':' + (opts.light === false ? 0 : 1) + ':' + (opts.ring ? 1 : 0);
    var c = BIG[key];
    if (!c) {
      if (BIG_N > 220) { BIG = {}; BIG_N = 0; }
      c = document.createElement('canvas'); c.width = Math.ceil(len * 1.5); c.height = Math.ceil(len * 1.25);
      drawBird(c.getContext('2d'), id, c.width / 2, c.height * 0.42, len, opts);
      BIG[key] = c; BIG_N++;
    }
    g.drawImage(c, x - c.width / 2, y - c.height * 0.42);
  }
  function drawBird(g, id, x, y, len, opts) {
    opts = opts || {};
    var p = plume(id, opts.sex || ''), bd = BUILD[p.b], s = len / (bd.w + bd.tail + bd.head * 1.6 + p.bill[0]);
    g.save(); g.translate(x, y); if (opts.flip) g.scale(-1, 1); g.scale(s, s); g.rotate(bd.tilt);
    var rx = bd.w / 2, ry = bd.h / 2, hx = rx * 0.78, hy = -ry * 0.78, hr = bd.head, lw = 1.2 / s;
    var ink = 'rgba(28,22,18,0.9)';
    // tail: a fan behind the body (cocked for a wren)
    var tl = bd.tail, ta = bd.cock ? 0.95 : 0.18;   // a wren cocks its tail UP (a positive turn lifts the -x end)
    g.save(); g.translate(-rx * 0.82, ry * 0.05); g.rotate(ta);
    g.beginPath(); g.moveTo(0, -ry * 0.32); g.lineTo(-tl, -ry * 0.34 + (bd.fork ? 0.02 : 0)); if (bd.fork) g.lineTo(-tl * 0.9, 0); g.lineTo(-tl, ry * 0.34); g.lineTo(0, ry * 0.3); g.closePath();
    g.fillStyle = p.ta; g.fill(); g.lineWidth = lw; g.strokeStyle = ink; g.stroke();
    if (p.tred) { g.fillStyle = p.ta; g.fillRect(-tl * 0.98, -ry * 0.3, tl * 0.98, ry * 0.6); g.fillStyle = shade(p.ta, 0.6); g.fillRect(-tl * 0.98, -ry * 0.06, tl * 0.98, ry * 0.12); }
    if (p.tbase) { g.fillStyle = p.tbase; g.fillRect(-tl * 0.55, -ry * 0.3, tl * 0.55, ry * 0.6); }
    if (p.tedge) { g.fillStyle = p.tedge; g.fillRect(-tl * 0.98, ry * 0.2, tl * 0.98, ry * 0.12); }
    g.strokeStyle = shade(p.ta, 0.7); g.lineWidth = lw * 0.7; for (var f = -1; f <= 1; f++) { g.beginPath(); g.moveTo(-tl * 0.1, f * ry * 0.12); g.lineTo(-tl * 0.95, f * ry * 0.18); g.stroke(); }
    if (p.barring && p.b === 'wryneck') { g.fillStyle = p.barring; for (var tb = 0.2; tb < 1; tb += 0.22) g.fillRect(-tl * tb, -ry * 0.3, tl * 0.05, ry * 0.6); }
    g.restore();
    // legs
    g.strokeStyle = p.legs; g.lineWidth = Math.max(lw, 0.025); g.lineCap = 'round';
    for (var lg = 0; lg < 2; lg++) { var lx = -0.02 + lg * 0.07; g.beginPath(); g.moveTo(lx, ry * 0.7); g.lineTo(lx + 0.02, ry * 1.55); g.lineTo(lx + 0.09, ry * 1.6); g.stroke(); }
    // a ringed bird (the one in the hand): a metal ring closed on the near leg's tarsus, where the leg itself runs
    if (opts.ring) { var rgx = 0.05 + 0.02 * (1.3 - 0.7) / 0.85, rgw = Math.max(0.04, lw * 3), rgh = ry * 0.2, rgy = ry * 1.2; g.fillStyle = '#c9d2da'; g.fillRect(rgx - rgw / 2, rgy, rgw, rgh); g.fillStyle = '#f4f7f9'; g.fillRect(rgx - rgw / 2, rgy, rgw, rgh * 0.3); g.strokeStyle = 'rgba(40,46,52,0.85)'; g.lineWidth = lw * 0.6; g.strokeRect(rgx - rgw / 2, rgy, rgw, rgh); }
    // the body
    function bodyPath() { g.beginPath(); g.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2); }
    bodyPath(); g.fillStyle = p.be; g.fill();
    g.save(); bodyPath(); g.clip();
    // flank wash, breast, upperparts
    g.fillStyle = p.fl; g.beginPath(); g.ellipse(-rx * 0.2, ry * 0.3, rx * 0.75, ry * 0.5, 0, 0, Math.PI * 2); g.fill();
    g.fillStyle = p.br; g.beginPath(); g.ellipse(rx * 0.5, ry * 0.05, rx * 0.55, ry * 0.75, 0, 0, Math.PI * 2); g.fill();
    if (p.breastband) { g.fillStyle = p.breastband; g.fillRect(rx * 0.2, ry * 0.15, rx, ry * 0.18); }
    g.fillStyle = p.up; g.beginPath(); g.moveTo(-rx * 1.2, -ry * 0.1); g.quadraticCurveTo(0, -ry * 0.35, rx * 1.2, -ry * 0.45); g.lineTo(rx * 1.2, -ry * 1.2); g.lineTo(-rx * 1.2, -ry * 1.2); g.closePath(); g.fill();
    if (p.rump) { g.fillStyle = p.rump; g.beginPath(); g.ellipse(-rx * 0.9, -ry * 0.2, rx * 0.25, ry * 0.3, 0, 0, Math.PI * 2); g.fill(); }
    // breast spots, streaks, flank streaks, barring
    var r = SIMRNG(id.length * 97 + 13);
    if (p.spots) { g.fillStyle = p.spots; for (var k3 = 0; k3 < 26; k3++) { var sx = rx * (0.05 + r() * 0.85), sy = -ry * 0.1 + r() * ry * 0.9; g.beginPath(); g.ellipse(sx, sy, 0.012, 0.018, -0.4, 0, Math.PI * 2); g.fill(); } }
    if (p.streak) { g.strokeStyle = p.streak; g.lineWidth = 0.014; for (var k4 = 0; k4 < 18; k4++) { var tx = rx * (0.15 + r() * 0.8), ty = -ry * 0.05 + r() * ry * 0.6; g.beginPath(); g.moveTo(tx, ty); g.lineTo(tx - 0.012, ty + 0.05); g.stroke(); } }
    if (p.flstreak) { g.strokeStyle = p.flstreak; g.lineWidth = 0.012; for (var k5 = 0; k5 < 10; k5++) { var fx = -rx * 0.5 + r() * rx * 0.8, fy = ry * (0.2 + r() * 0.4); g.beginPath(); g.moveTo(fx, fy); g.lineTo(fx - 0.04, fy + 0.02); g.stroke(); } }
    if (p.flspot) { g.fillStyle = p.flspot; for (var k6 = 0; k6 < 6; k6++) { g.beginPath(); g.arc(-rx * 0.4 + r() * rx * 0.6, ry * (0.35 + r() * 0.2), 0.012, 0, Math.PI * 2); g.fill(); } }
    if (p.barring && p.b !== 'wryneck') { g.strokeStyle = p.barring; g.lineWidth = 0.009; for (var by = -ry * 0.1; by < ry; by += 0.03) { g.beginPath(); g.moveTo(-rx, by); g.quadraticCurveTo(0, by + 0.012, rx, by); g.stroke(); } }
    if (p.backstreak) { g.strokeStyle = p.backstreak; g.lineWidth = 0.016; for (var k7 = 0; k7 < 9; k7++) { var bx = -rx * 0.7 + k7 * rx * 0.17, byy = -ry * (0.55 + (k7 % 2) * 0.15); g.beginPath(); g.moveTo(bx, byy); g.lineTo(bx - 0.06, byy + 0.015); g.stroke(); } }
    if (p.vermic) { g.strokeStyle = shade(p.up, 0.6); g.lineWidth = 0.008; for (var k8 = 0; k8 < 30; k8++) { var vx = -rx + r() * rx * 2, vy = -ry + r() * ry * 0.7; g.beginPath(); g.moveTo(vx, vy); g.lineTo(vx + 0.03, vy + 0.008); g.stroke(); } }
    if (p.scale) { g.strokeStyle = p.scale; g.lineWidth = 0.008; for (var k9 = 0; k9 < 20; k9++) { var cx2 = -rx * 0.6 + r() * rx * 1.4, cy2 = -ry * 0.2 + r() * ry; g.beginPath(); g.arc(cx2, cy2, 0.02, 0.2, Math.PI - 0.2); g.stroke(); } }
    g.restore();
    bodyPath(); g.lineWidth = lw; g.strokeStyle = ink; g.stroke();
    // the wing: a folded wing on the flank, feathers edged, bars and a panel
    g.save(); g.translate(-rx * 0.05, -ry * 0.18); g.rotate(0.12);
    function wingPath() { g.beginPath(); g.moveTo(rx * 0.55, -ry * 0.1); g.quadraticCurveTo(rx * 0.1, -ry * 0.55, -rx * 0.6, -ry * 0.25); g.quadraticCurveTo(-rx * 1.05, ry * 0.05, -rx * 1.15, ry * 0.32); g.quadraticCurveTo(-rx * 0.2, ry * 0.55, rx * 0.5, ry * 0.25); g.closePath(); }
    wingPath(); g.fillStyle = p.wi; g.fill();
    g.save(); wingPath(); g.clip();
    if (p.primaries) { g.fillStyle = p.primaries; g.fillRect(-rx * 1.2, -ry, rx * 0.55, ry * 2); }
    if (p.panel) { g.fillStyle = p.panel; g.fillRect(-rx * 0.35, -ry * 0.2, rx * 0.4, ry * 0.42); }
    if (p.bars) { g.fillStyle = p.bars[0]; for (var wb = 0; wb < p.bars[1]; wb++) { g.beginPath(); g.ellipse(rx * (0.18 - wb * 0.26), -ry * 0.05 + wb * ry * 0.06, rx * 0.06, ry * 0.42, 0.25, 0, Math.PI * 2); g.fill(); } }
    if (p.shoulder) { g.fillStyle = p.shoulder; g.beginPath(); g.arc(rx * 0.45, -ry * 0.1, ry * 0.12, 0, Math.PI * 2); g.fill(); }
    g.strokeStyle = shade(p.wi, 1.35); g.lineWidth = lw * 0.8;
    for (var fe = 0; fe < 5; fe++) { g.beginPath(); g.moveTo(rx * (0.2 - fe * 0.18), -ry * 0.25 + fe * 0.01); g.quadraticCurveTo(-rx * 0.5, ry * 0.05, -rx * (0.6 + fe * 0.1), ry * (0.1 + fe * 0.05)); g.stroke(); }
    g.restore();
    wingPath(); g.lineWidth = lw; g.strokeStyle = ink; g.stroke();
    g.restore();
    // the head
    function headPath() { g.beginPath(); g.arc(hx, hy, hr, 0, Math.PI * 2); }
    headPath(); g.fillStyle = p.fa; g.fill();
    g.save(); headPath(); g.clip();
    g.fillStyle = p.th; g.beginPath(); g.ellipse(hx + hr * 0.45, hy + hr * 0.75, hr * 0.7, hr * 0.55, 0, 0, Math.PI * 2); g.fill();
    if (p.bib) { g.fillStyle = p.bib; g.beginPath(); g.ellipse(hx + hr * 0.4, hy + hr * 0.95, hr * 0.75, hr * 0.5, 0, 0, Math.PI * 2); g.fill(); }
    if (p.redspot) { g.fillStyle = p.redspot; g.beginPath(); g.arc(hx + hr * 0.45, hy + hr * 0.85, hr * 0.18, 0, Math.PI * 2); g.fill(); }
    g.fillStyle = p.cr; g.beginPath(); g.ellipse(hx - hr * 0.1, hy - hr * 0.55, hr * 1.05, hr * 0.62, 0, 0, Math.PI * 2); g.fill();
    if (p.nape) { g.fillStyle = p.nape; g.beginPath(); g.ellipse(hx - hr * 0.8, hy - hr * 0.05, hr * 0.35, hr * 0.5, 0, 0, Math.PI * 2); g.fill(); }
    if (p.cap) { g.fillStyle = p.cap; g.beginPath(); g.ellipse(hx - hr * 0.05, hy - hr * 0.62, hr * 0.95, hr * 0.5, 0, 0, Math.PI * 2); g.fill(); }
    if (p.forehead) { g.fillStyle = p.forehead; g.beginPath(); g.arc(hx + hr * 0.82, hy - hr * 0.3, hr * 0.2, 0, Math.PI * 2); g.fill(); }
    if (p.crs) { g.fillStyle = p.crs[1]; g.fillRect(hx - hr * 1.1, hy - hr * 0.98, hr * 2, hr * 0.42); g.fillStyle = p.crs[0]; g.fillRect(hx - hr * 1.1, hy - hr * 0.94, hr * 1.95, hr * 0.2); }
    if (p.headbars) { g.fillStyle = p.headbars; for (var hb = 0; hb < 3; hb++) g.fillRect(hx - hr * (0.75 - hb * 0.35), hy - hr, hr * 0.18, hr * 0.85); }
    if (p.blaze) { g.fillStyle = p.blaze; g.beginPath(); g.ellipse(hx + hr * 0.62, hy - hr * 0.08, hr * 0.42, hr * 0.36, 0, 0, Math.PI * 2); g.fill(); }
    if (p.mask) { g.fillStyle = p.mask; g.beginPath(); g.moveTo(hx + hr * 1.05, hy - hr * 0.12); g.lineTo(hx - hr * 0.6, hy - hr * 0.22); g.lineTo(hx - hr * 0.6, hy + hr * 0.25); g.lineTo(hx + hr * 1.05, hy + hr * 0.12); g.closePath(); g.fill(); }
    if (p.sup) { g.strokeStyle = p.sup; g.lineWidth = hr * 0.17; g.beginPath(); g.moveTo(hx + hr * 0.95, hy - hr * 0.35); g.quadraticCurveTo(hx + hr * 0.1, hy - hr * 0.55, hx - hr * 0.75, hy - hr * 0.3); g.stroke(); }
    if (p.eye) { g.strokeStyle = p.eye; g.lineWidth = hr * 0.12; g.beginPath(); g.moveTo(hx + hr * 1.0, hy - hr * 0.08); g.lineTo(hx - hr * 0.7, hy - hr * 0.05); g.stroke(); }
    if (p.cheek) { g.fillStyle = p.cheek; g.beginPath(); g.ellipse(hx - hr * 0.05, hy + hr * 0.3, hr * 0.42, hr * 0.32, 0, 0, Math.PI * 2); g.fill(); }
    if (p.mous) { g.strokeStyle = p.mous; g.lineWidth = hr * 0.13; g.beginPath(); g.moveTo(hx + hr * 0.7, hy + hr * 0.35); g.lineTo(hx - hr * 0.2, hy + hr * 0.7); g.stroke(); }
    if (p.crstreak) { g.strokeStyle = p.crstreak; g.lineWidth = hr * 0.08; for (var cs = 0; cs < 4; cs++) { g.beginPath(); g.moveTo(hx - hr * 0.6 + cs * hr * 0.35, hy - hr * 0.9); g.lineTo(hx - hr * 0.7 + cs * hr * 0.35, hy - hr * 0.5); g.stroke(); } }
    g.restore();
    if (p.collar) { g.fillStyle = p.collar; g.beginPath(); g.ellipse(hx - hr * 0.2, hy + hr * 0.95, hr * 0.7, hr * 0.22, 0.3, 0, Math.PI * 2); g.fill(); }
    if (p.sideneck) { g.fillStyle = p.sideneck; g.beginPath(); g.ellipse(hx - hr * 0.6, hy + hr * 0.6, hr * 0.35, hr * 0.25, 0, 0, Math.PI * 2); g.fill(); }
    headPath(); g.lineWidth = lw; g.strokeStyle = ink; g.stroke();
    // the bill
    var bl = p.bill[0], bdp = p.bill[1], bx0 = hx + hr * 0.88, by0 = hy + hr * 0.05;
    g.beginPath(); g.moveTo(bx0, by0 - bdp / 2); g.quadraticCurveTo(bx0 + bl * 0.6, by0 - bdp * 0.45, bx0 + bl, by0 + (p.b === 'woodcock' ? bdp * 0.3 : 0)); g.lineTo(bx0, by0 + bdp / 2); g.closePath();
    g.fillStyle = p.bill[2]; g.fill(); g.lineWidth = lw * 0.8; g.strokeStyle = ink; g.stroke();
    g.strokeStyle = shade(p.bill[2], 0.5); g.beginPath(); g.moveTo(bx0, by0 + bdp * 0.05); g.lineTo(bx0 + bl * 0.8, by0 + bdp * 0.08); g.stroke();
    // the eye: dark, with its ring and a catchlight
    var ex = hx + hr * (p.b === 'woodcock' ? 0.05 : 0.45), ey = hy - hr * 0.12, er = hr * (p.b === 'woodcock' ? 0.24 : 0.2);
    if (p.ring) { g.fillStyle = p.ring; g.beginPath(); g.arc(ex, ey, er * 1.45, 0, Math.PI * 2); g.fill(); }
    g.fillStyle = '#120e0c'; g.beginPath(); g.arc(ex, ey, er, 0, Math.PI * 2); g.fill();
    g.fillStyle = 'rgba(255,255,255,0.85)'; g.beginPath(); g.arc(ex + er * 0.3, ey - er * 0.35, er * 0.3, 0, Math.PI * 2); g.fill();
    g.restore();
    // light from the upper left, laid over what was drawn (only where the bird is)
    if (opts.light !== false) {
      g.save(); g.globalCompositeOperation = 'source-atop';
      var gr = g.createLinearGradient(x - len * 0.3, y - len * 0.35, x + len * 0.25, y + len * 0.35);
      gr.addColorStop(0, 'rgba(255,248,230,0.22)'); gr.addColorStop(0.55, 'rgba(255,255,255,0)'); gr.addColorStop(1, 'rgba(20,16,30,0.28)');
      g.fillStyle = gr; g.fillRect(x - len, y - len, len * 2, len * 2); g.restore();
    }
  }
  var SIMRNG = function (seed) { var s = seed >>> 0 || 1; return function () { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; };

  /* ---------------------------------------------------------------- small birds for the field (struck once, cached) */
  var SMALL = {};
  /** a field sprite: the same bird struck at `len` px onto its own canvas, alpha hardened so it stays crisp */
  function small(id, len, sex, flip) {
    var key = id + ':' + len + ':' + (sex || '') + ':' + (flip ? 1 : 0);
    if (SMALL[key]) return SMALL[key];
    var c = document.createElement('canvas'); c.width = Math.ceil(len * 1.3); c.height = Math.ceil(len * 1.0);
    var g = c.getContext('2d');
    drawBird(g, id, c.width * 0.55, c.height * 0.45, len, { sex: sex, flip: flip, light: true });
    var d = g.getImageData(0, 0, c.width, c.height), a = d.data;
    for (var i = 3; i < a.length; i += 4) a[i] = a[i] > 110 ? 255 : 0;
    g.putImageData(d, 0, 0);
    SMALL[key] = c;
    return c;
  }

  /* ---------------------------------------------------------------- moths */
  // Each moth is drawn as it sits on the egg tray at dawn, head up, in the pose its row sets: SET (H > 0, the wings
  // open so the hindwing shows: the underwings, the hawk-moth, the thorn) or AT REST (H = 0, the forewings folded back
  // over the body into the species' own outline). Units are s = span / 2: every moth fits x -1..1, y -0.75..0.75.
  // fw forewing, mark its ink, pat the species' own forewing mark, hw hindwing ground, hb its bands (bands: pairs of
  // [the margin scaled toward the root, band width]), ab abdomen rings, and shape, the outline family:
  //   long     narrow wings, a rounded apex             tri    a straight-edged delta, square at the margin
  //   crumple  a creased dead leaf, a toothed margin    snout  a flat pointed delta, the palps a long beak
  //   hawk     narrow pointed blades, a heavy body      thorn  a hooked apex, an angled margin, feathered antennae
  // geo: [L forewing length, D its depth at the margin, a its sweep back (radians), t how oblique the margin is (0 square
  //       .. 1 pointed), H hindwing length (0 = folded away), ha the hindwing's sweep]
  var M = {
    lyu: { fw: '#8a6a44', mark: '#24180c', pat: 'kidney', hw: '#e8b028', hb: '#1e1a16', bands: [0.84, 0.07], shape: 'long', geo: [0.98, 0.3, 0.52, 0.35, 0.58, 1.02] },
    setaceous: { fw: '#7a6a62', mark: '#1a1210', pat: 'hebrew', hw: '#c8bcb2', shape: 'tri', geo: [1.08, 0.32, 1.06, 0.22, 0, 0] },
    angleshades: { fw: '#c4a88c', mark: '#56643a', pat: 'chevron', hw: '#d8ccb0', shape: 'crumple', geo: [0.98, 0.44, 0.86, 0.2, 0, 0] },
    merveille: { fw: '#9ec8a2', mark: '#121a14', pat: 'lichen', hw: '#a8a8a0', shape: 'tri', geo: [0.94, 0.46, 0.56, 0.16, 0, 0] },
    blairs: { fw: '#9a9890', mark: '#161412', pat: 'dash', hw: '#c4c0b8', shape: 'long', geo: [1.06, 0.2, 1.28, 0.6, 0, 0] },
    snout: { fw: '#7a6450', mark: '#2a1c12', pat: 'lines', hw: '#a89884', shape: 'snout', geo: [1.0, 0.34, 0.7, 0.9, 0, 0] },
    silvery: { fw: '#6a6066', mark: '#2a2228', pat: 'y', hw: '#9a908a', shape: 'tri', geo: [0.9, 0.44, 0.78, 0.4, 0, 0] },
    convolvulus: { fw: '#8a8a88', mark: '#262626', pat: 'hawk', hw: '#8c8682', hb: '#34302e', bands: [0.52, 0.05, 0.82, 0.07], ab: '#d86a8a', shape: 'hawk', geo: [0.98, 0.22, 0.34, 0.9, 0.42, 0.95] },
    redunder: { fw: '#8e8a84', mark: '#24201e', pat: 'zigzag', hw: '#d22e3a', hb: '#1a1416', bands: [0.88, 0.13, 0.56, 0.09], shape: 'long', geo: [0.88, 0.42, 0, 0.3, 0.7, 0.66] },
    feathered: { fw: '#c49a5e', mark: '#6a4222', pat: 'thorn', hw: '#d8b888', hb: '#a8784a', bands: [0.66, 0.025], shape: 'thorn', geo: [0.84, 0.44, -0.22, 0.2, 0.52, 0.5] },
    sprawler: { fw: '#a69478', mark: '#261c12', pat: 'veins', hw: '#cbbca4', shape: 'tri', geo: [0.86, 0.44, 0.94, 0.04, 0, 0] },
    clifden: { fw: '#9a9ca2', mark: '#2a2c32', pat: 'frost', hw: '#22222a', hb: '#8fb0e6', bands: [0.62, 0.17], shape: 'long', geo: [0.92, 0.44, -0.16, 0.22, 0.74, 0.56] },
  };
  // a quadratic edge drawn plain (n 0), scalloped (n > 0) or toothed (n < 0) in |n| steps standing `amp` proud of it
  function edge(g, x0, y0, cx, cy, x1, y1, n, amp) {
    if (!n) { g.quadraticCurveTo(cx, cy, x1, y1); return; }
    var k = Math.abs(n), at = function (u, i) { var v = 1 - u; return v * v * (i ? y0 : x0) + 2 * v * u * (i ? cy : cx) + u * u * (i ? y1 : x1); };
    for (var i = 1; i <= k; i++) {
      var u = (i - 0.5) / k, dx = 2 * (1 - u) * (cx - x0) + 2 * u * (x1 - cx), dy = 2 * (1 - u) * (cy - y0) + 2 * u * (y1 - cy), d = Math.sqrt(dx * dx + dy * dy) || 1;
      var ox = at(u, 0) + dy / d * amp, oy = at(u, 1) - dx / d * amp;
      if (n > 0) g.quadraticCurveTo(ox, oy, at(i / k, 0), at(i / k, 1)); else { g.lineTo(ox, oy); g.lineTo(at(i / k, 0), at(i / k, 1)); }
    }
  }
  // the forewing in its own frame: the root at the origin, the costa along the top, the apex out at +x; at rest the
  // inner margin swells over the midline so the folded wings close over the body
  function fwPath(g, sh, L, D, t, rest) {
    var tx = L - 0.04 - t * D * 1.4;
    g.beginPath(); g.moveTo(0, -0.06);
    if (sh === 'crumple') { g.quadraticCurveTo(L * 0.28, -0.13, L * 0.48, -0.08); g.lineTo(L * 0.56, -0.01); g.quadraticCurveTo(L * 0.78, -0.09, L, -0.02); }
    else if (sh === 'tri' || sh === 'snout') g.lineTo(L, -0.03);
    else g.quadraticCurveTo(L * 0.55, sh === 'hawk' ? -0.08 : -0.13, L, -0.03);
    if (sh === 'thorn') { g.lineTo(L + 0.04, 0.05); g.lineTo(L - 0.08, D * 0.34); g.lineTo(L - 0.01, D * 0.58); g.lineTo(tx, D); }
    else if (sh === 'crumple') edge(g, L, -0.02, L + 0.02, D * 0.5, tx, D, -3, 0.07);
    else if (sh === 'tri' || sh === 'snout') g.lineTo(tx, D);
    else if (sh === 'hawk') g.quadraticCurveTo(L * 0.94, D * 0.78, tx, D);
    else g.quadraticCurveTo(L + 0.05, D * 0.55, tx, D);
    g.quadraticCurveTo(tx * 0.5, D * (rest ? 1.45 : 0.82), 0, 0.07); g.closePath();
  }
  // the hindwing in its own frame: its outer margin (apex round to the anal angle), then the whole wing
  function hwMargin(g, sh, H, sc) {
    if (sh === 'thorn') { g.lineTo(H * 0.95, H * 0.36); g.lineTo(H * 0.74, H * 0.5); g.lineTo(H * 0.34, H * 0.72); }
    else if (sh === 'hawk') g.quadraticCurveTo(H * 0.95, H * 0.62, H * 0.3, H * 0.62);
    else edge(g, H, 0, H * 1.06, H * 0.72, H * 0.32, H * 0.74, sc, 0.03);
  }
  function hwPath(g, sh, H, sc) { g.beginPath(); g.moveTo(0, -0.04); g.quadraticCurveTo(H * 0.5, -0.09, H, 0); hwMargin(g, sh, H, sc); g.quadraticCurveTo(0.03, H * 0.52, 0, 0.06); g.closePath(); }
  // the lamp over the tray: a lift at the wing root, a shade toward the margin (inside the wing's own clip)
  function lit(g, L, D) {
    var gr = g.createLinearGradient(0, -0.1, L * 0.9, D + 0.1);
    gr.addColorStop(0, 'rgba(255,244,222,0.18)'); gr.addColorStop(0.45, 'rgba(255,255,255,0)'); gr.addColorStop(1, 'rgba(14,10,22,0.26)');
    g.fillStyle = gr; g.fillRect(-0.3, -0.4, L + 0.6, D + 0.8);
  }
  // the species' own forewing mark, in the wing's frame: P(fx, fy) is fx along the wing, fy from costa (0) to dorsum (1)
  function marks(g, m, L, D, px, r, rest) {
    var mk = m.mark, w = Math.max(px, 0.03), dark = shade(m.fw, 0.62), pale = shade(m.fw, 1.5), pt = m.pat, i, tx = L - 0.04 - m.geo[3] * D * 1.4;
    function P(fx, fy) { var u = Math.min(1, fx * L / tx); return [fx * L, -0.07 + fy * (0.14 + (D - 0.07) * fx) * (rest ? 1 + 1.9 * u * (1 - u) : 1)]; }
    function poly(pts, fill) { g.beginPath(); for (var j = 0; j < pts.length; j++) { var o = P(pts[j][0], pts[j][1]); if (j) g.lineTo(o[0], o[1]); else g.moveTo(o[0], o[1]); } g.closePath(); g.fillStyle = fill; g.fill(); }
    function spot(fx, fy, rx, ry, rot, fill, ring) { var o = P(fx, fy); g.beginPath(); g.ellipse(o[0], o[1], rx, ry, rot, 0, Math.PI * 2); if (fill) { g.fillStyle = fill; g.fill(); } if (ring) { g.lineWidth = w * 0.8; g.strokeStyle = ring; g.stroke(); } }
    function seg(f0, y0, f1, y1, lw, col) { var a = P(f0, y0), b = P(f1, y1); g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.lineWidth = lw; g.strokeStyle = col; g.stroke(); }
    // a cross-line from costa to dorsum, zigzag (or wavy when smooth) in n steps of `amp`
    function xl(f0, f1, n, amp, lw, col, smooth) {
      var a = P(f0, -0.2); g.beginPath(); g.moveTo(a[0], a[1]);
      for (var j = 1; j <= n; j++) {
        var u = j / n, hu = u - 0.5 / n, b = P(f0 + (f1 - f0) * u, -0.2 + 1.4 * u), h = P(f0 + (f1 - f0) * hu, -0.2 + 1.4 * hu), o = j % 2 ? amp : -amp;
        if (smooth) g.quadraticCurveTo(h[0] + o, h[1], b[0], b[1]); else { g.lineTo(h[0] + o, h[1]); g.lineTo(b[0], b[1]); }
      }
      g.lineWidth = lw; g.strokeStyle = col; g.stroke();
    }
    function fleck(n, col, alpha) { g.globalAlpha = alpha; g.fillStyle = col; for (var j = 0; j < n; j++) { var o = P(r(), r() * 1.1); g.fillRect(o[0], o[1], 0.02 + r() * 0.025, 0.016); } g.globalAlpha = 1; }
    // the veins, faint, on every wing
    g.globalAlpha = 0.3; for (i = 0; i < 4; i++) seg(0.05, 0.5, 1.05, 0.08 + i * 0.27, px * 0.8, dark); g.globalAlpha = 1;
    if (pt === 'kidney') {          // Large Yellow Underwing: ringed stigmas and the black wedge at the apex
      g.globalAlpha = 0.55; xl(0.28, 0.24, 4, 0.02, w, mk, true); xl(0.7, 0.62, 6, 0.02, w, mk, true); g.globalAlpha = 1;
      xl(0.87, 0.83, 7, 0.018, w * 1.2, pale, true);
      spot(0.42, 0.42, 0.04, 0.035, 0, dark, pale); spot(0.62, 0.48, 0.035, 0.075, 0.25, dark, pale);
      poly([[0.82, -0.2], [0.95, -0.2], [0.89, 0.34]], mk);
    } else if (pt === 'hebrew') {   // Setaceous Hebrew Character: the black saddle with the pale wedge cut into it
      poly([[0.62, -0.2], [1.05, -0.2], [1.05, 0.06], [0.64, 0.1]], 'rgba(226,206,190,0.35)');
      poly([[0.2, -0.2], [0.62, -0.2], [0.66, 0.55], [0.5, 0.74], [0.3, 0.52]], mk);
      poly([[0.31, -0.2], [0.52, -0.2], [0.42, 0.56]], '#dcc4b0');
      spot(0.78, 0.48, 0.035, 0.07, 0.25, null, dark); xl(0.92, 0.88, 6, 0.015, w, dark, true);
    } else if (pt === 'chevron') {  // Angle Shades: the olive V, its pink heart, the creases of a dead leaf
      poly([[0.72, -0.2], [1.1, -0.2], [1.1, 1.2], [0.62, 1.2]], 'rgba(200,120,110,0.3)');
      poly([[0.24, -0.2], [0.74, -0.2], [0.5, 1.2]], mk); poly([[0.36, -0.2], [0.62, -0.2], [0.49, 0.62]], '#c88c7c');
      seg(0.02, 0.38, 1.05, 0.3, w, 'rgba(255,240,220,0.45)'); seg(0.02, 0.48, 1.05, 0.42, w, 'rgba(30,20,10,0.35)');
      seg(0.3, 0.8, 1.05, 0.76, w * 0.8, 'rgba(30,20,10,0.3)');
    } else if (pt === 'lichen') {   // Merveille du Jour: lichen green, black and white cross-lines, a white patch
      fleck(36, mk, 0.7); fleck(24, '#f2f6ee', 0.8);
      xl(0.3, 0.24, 5, 0.035, w * 2.4, '#eef4ea'); xl(0.3, 0.24, 5, 0.035, w, mk); xl(0.66, 0.56, 7, 0.03, w * 2.4, '#eef4ea'); xl(0.66, 0.56, 7, 0.03, w, mk);
      spot(0.42, 0.4, 0.05, 0.045, 0, '#e6efe2', mk); spot(0.6, 0.5, 0.045, 0.08, 0.25, '#e6efe2', mk); spot(0.5, 0.98, 0.06, 0.035, 0, '#f4f6f0');
    } else if (pt === 'dash') {     // Blair's Shoulder-knot: the black dash at the base, a russet inner margin
      poly([[0, 0.72], [0.6, 0.8], [1.1, 1.2], [0, 1.2]], 'rgba(150,100,64,0.5)');
      poly([[0.06, 0.22], [0.56, 0.42], [0.06, 0.62]], mk); poly([[0.58, 0.4], [1.05, 0.26], [1.05, 0.42], [0.62, 0.54]], dark);
      spot(0.54, 0.46, 0.03, 0.06, 0.2, null, mk);
      for (i = 0; i < 3; i++) seg(0.76, [0.14, 0.62, 0.8][i], 1.05, [0.1, 0.6, 0.8][i], w * 0.8, mk);
    } else if (pt === 'lines') {    // Snout: a darker outer wing, a pale-edged oblique line, the apical streak
      poly([[0.62, -0.2], [1.1, -0.2], [1.1, 1.2], [0.48, 1.2]], 'rgba(40,24,14,0.24)');
      xl(0.3, 0.38, 2, 0.03, w, mk); seg(0.665, -0.2, 0.505, 1.2, w * 2.4, pale); seg(0.645, -0.2, 0.485, 1.2, w * 1.3, mk);
      poly([[1.0, -0.2], [1.08, -0.2], [0.86, 0.46]], mk); spot(0.46, 0.42, 0.024, 0.024, 0, mk);
      for (i = 0; i < 5; i++) spot(0.88 - i * 0.02, 0.12 + i * 0.2, 0.012, 0.012, 0, mk);
    } else if (pt === 'y') {        // Silver Y: the metal gamma on a dark purple ground
      poly([[0.3, 0.05], [0.68, 0], [0.72, 0.76], [0.34, 0.86]], 'rgba(58,36,56,0.5)');
      xl(0.26, 0.22, 4, 0.02, w, pale, true); xl(0.76, 0.68, 6, 0.02, w, pale, true);
      [[w * 3.2, mk], [w * 2, '#d8e0e6'], [w * 0.8, '#ffffff']].forEach(function (k) {
        var a = P(0.36, 0.26), b = P(0.6, 0.22), c = P(0.5, 0.58), d = P(0.6, 0.84);
        g.beginPath(); g.moveTo(a[0], a[1]); g.quadraticCurveTo(a[0] + 0.02, c[1] - 0.02, c[0], c[1]); g.moveTo(b[0], b[1]); g.quadraticCurveTo(b[0], c[1] - 0.04, c[0], c[1]);
        g.quadraticCurveTo(c[0] + 0.02, d[1] - 0.04, d[0], d[1]); g.lineWidth = k[0]; g.strokeStyle = k[1]; g.stroke();
      });
    } else if (pt === 'hawk') {     // Convolvulus Hawk-moth: grey blades, a long dark streak, fine wavy lines
      poly([[0.1, -0.2], [0.55, -0.2], [0.45, 0.24], [0.08, 0.24]], 'rgba(240,236,228,0.22)');
      g.globalAlpha = 0.6; for (i = 0; i < 4; i++) xl(0.2 + i * 0.18, 0.12 + i * 0.18, 4, 0.02, w * 0.8, dark, true); g.globalAlpha = 1;
      poly([[0, 0.44], [0.74, 0.52], [0, 0.66]], 'rgba(28,28,28,0.55)'); poly([[0.96, -0.2], [1.08, -0.2], [0.8, 0.64]], mk);
    } else if (pt === 'zigzag') {   // Red Underwing: grey bark, a sharply toothed line, a pale kidney
      fleck(40, mk, 0.22);
      xl(0.3, 0.26, 4, 0.03, w, mk); xl(0.7, 0.58, 9, 0.035, w, mk); xl(0.86, 0.8, 8, 0.015, w * 1.3, pale, true);
      spot(0.56, 0.44, 0.035, 0.075, 0.25, null, mk);
    } else if (pt === 'thorn') {    // Feathered Thorn: two lines round a darker band, a dark spot between them
      poly([[0.32, -0.2], [0.64, -0.2], [0.56, 1.2], [0.24, 1.2]], 'rgba(120,70,30,0.22)');
      xl(0.32, 0.24, 2, 0.04, w * 1.2, mk, true); xl(0.64, 0.56, 1, 0, w * 1.2, mk); spot(0.48, 0.36, 0.025, 0.025, 0, mk); fleck(16, mk, 0.35);
    } else if (pt === 'veins') {    // Sprawler: black streaks along the veins, a dark bar between pale stigmas
      for (i = 0; i < 5; i++) seg(0.52, 0.12 + i * 0.18, 1.06, 0.1 + i * 0.16, w * 0.7, mk);
      poly([[0, 0.45], [0.32, 0.52], [0, 0.6]], mk); poly([[0.4, 0.3], [0.64, 0.38], [0.64, 0.6], [0.4, 0.52]], dark);
      spot(0.38, 0.4, 0.035, 0.03, 0, pale, mk); spot(0.66, 0.48, 0.03, 0.065, 0.2, pale, mk);
    } else if (pt === 'frost') {    // Clifden Nonpareil: frosted grey, a pale cloud round the kidney, a dark margin
      poly([[0.72, -0.2], [1.1, -0.2], [1.1, 1.2], [0.6, 1.2]], 'rgba(40,42,50,0.35)'); spot(0.56, 0.44, 0.1, 0.13, 0.3, 'rgba(240,242,248,0.6)');
      xl(0.3, 0.24, 5, 0.03, w, mk); xl(0.7, 0.6, 9, 0.03, w, mk); xl(0.88, 0.82, 8, 0.02, w * 1.4, 'rgba(236,238,244,0.85)', true);
      spot(0.56, 0.44, 0.03, 0.065, 0.25, null, mk);
    }
  }
  // how far the drawn moth reaches up and down (in s), from the same outline points it is drawn through, so each one
  // hangs centred in its box whatever its pose
  var MDY = {};
  function mothDy(m) {
    var q = m.geo, L = q[0], D = q[1], H = q[4], tx = L - 0.04 - q[3] * D * 1.4, ys = [m.shape === 'snout' ? -0.69 : H || m.shape === 'hawk' ? -0.67 : -0.43, m.shape === 'hawk' ? 0.64 : 0.44];
    function put(p, oy, a) { ys.push(oy + p[0] * Math.sin(a) + p[1] * Math.cos(a)); }
    [[L, -0.03], [tx, D], m.shape === 'tri' || m.shape === 'snout' ? [L, -0.03] : [L + 0.03, D * 0.55], [tx * 0.5, D * (H ? 0.66 : 1.0)]].forEach(function (p) { put(p, -0.24, q[2]); });
    if (H) [[H, 0], [H * 0.92, H * 0.5], [H * 0.62, H * 0.75], [H * 0.32, H * 0.75]].forEach(function (p) { put(p, -0.1, q[5]); });
    return -(Math.min.apply(null, ys) + Math.max.apply(null, ys)) / 2;
  }
  /** draw one moth, head up, centred on (x, y), `span` px across the wings; it stays inside span x 0.75 span */
  function moth(g, id, x, y, span) {
    var m = M[id]; if (!m) throw new Error('no moth ' + id);
    var s = span / 2, sh = m.shape, q = m.geo, L = q[0], D = q[1], H = q[4], px = 1 / s, lw = Math.max(1, s / 40) / s, ink = 'rgba(22,16,12,0.88)';
    var sc = m.pat === 'frost' ? 7 : m.pat === 'zigzag' ? 5 : 0, hk = sh === 'hawk', seed = id.length * 131 + id.charCodeAt(0) * 7, side, i;
    if (MDY[id] == null) MDY[id] = mothDy(m);
    g.save(); g.translate(x, y + MDY[id] * s); g.scale(s, s); g.lineJoin = 'round'; g.lineCap = 'round';
    function wing(sd, hind) { g.save(); g.scale(sd, 1); if (hind) { g.translate(0.05, -0.1); g.rotate(q[5]); } else { g.translate(0.06, -0.24); g.rotate(q[2]); } }
    // the hindwings, with their bands and (on the underwings) a chequered fringe
    if (H) for (side = -1; side <= 1; side += 2) {
      wing(side, true); hwPath(g, sh, H, sc); g.fillStyle = m.hw; g.fill();
      g.save(); g.clip();
      for (i = 0; m.bands && i < m.bands.length; i += 2) {
        g.save(); g.scale(m.bands[i], m.bands[i]); g.beginPath(); g.moveTo(H, -0.3); g.lineTo(H, 0); hwMargin(g, sh, H, sc); g.lineTo(-0.5, H * 0.8); g.restore();
        g.lineWidth = m.bands[i + 1]; g.strokeStyle = m.hb; g.stroke();
      }
      if (sc) { g.beginPath(); g.moveTo(H, 0); hwMargin(g, sh, H, sc); g.setLineDash([0.04, 0.04]); g.lineWidth = 0.05; g.strokeStyle = 'rgba(238,234,226,0.9)'; g.stroke(); g.setLineDash([]); }
      lit(g, H, H * 0.7); g.restore();
      hwPath(g, sh, H, sc); g.lineWidth = lw; g.strokeStyle = ink; g.stroke(); g.restore();
    }
    // the abdomen (under the folded wings at rest; banded pink and black on the hawk-moth)
    var ay = hk ? 0.2 : 0.14, arx = hk ? 0.1 : 0.072, ary = hk ? 0.44 : 0.3;
    g.beginPath(); g.ellipse(0, ay, arx, ary, 0, 0, Math.PI * 2); g.fillStyle = shade(m.fw, 0.8); g.fill();
    g.save(); g.clip();
    for (i = 0; i < 6; i++) { var ry = ay - ary * 0.55 + i * ary * 0.27; if (m.ab) { g.fillStyle = i % 2 ? '#1c1a1a' : m.ab; g.fillRect(-arx, ry, arx * 2, ary * 0.14); } else { g.fillStyle = 'rgba(0,0,0,0.18)'; g.fillRect(-arx, ry, arx * 2, px); } }
    if (m.ab) { g.fillStyle = shade(m.fw, 0.9); g.fillRect(-arx * 0.28, ay - ary, arx * 0.56, ary * 2); }
    g.restore(); g.lineWidth = lw; g.strokeStyle = ink; g.stroke();
    // the forewings: outline, the species' mark, the lamp, and the edge stroked
    for (side = -1; side <= 1; side += 2) {
      wing(side, false); fwPath(g, sh, L, D, q[3], !H); g.fillStyle = m.fw; g.fill();
      g.save(); g.clip(); marks(g, m, L, D, px, SIMRNG(seed), !H); lit(g, L, D); g.restore();
      fwPath(g, sh, L, D, q[3], !H); g.lineWidth = lw; g.strokeStyle = ink; g.stroke(); g.restore();
    }
    // the palps of the Snout, a beak held out in front
    if (sh === 'snout') { g.beginPath(); g.moveTo(-0.045, -0.37); g.quadraticCurveTo(-0.03, -0.55, -0.008, -0.69); g.lineTo(0.008, -0.69); g.quadraticCurveTo(0.03, -0.55, 0.045, -0.37); g.closePath(); g.fillStyle = shade(m.fw, 0.72); g.fill(); g.lineWidth = lw; g.strokeStyle = ink; g.stroke(); }
    // thorax, collar, the Silver Y's crest, head, and eyes that shine in the trap light
    g.beginPath(); g.ellipse(0, -0.2, 0.1, 0.13, 0, 0, Math.PI * 2); g.fillStyle = shade(m.fw, 0.88); g.fill(); g.lineWidth = lw; g.strokeStyle = ink; g.stroke();
    g.beginPath(); g.ellipse(0, -0.29, 0.085, 0.035, 0, 0, Math.PI * 2); g.fillStyle = shade(m.fw, 0.68); g.fill();
    if (m.pat === 'y') for (side = -1; side <= 1; side += 2) { g.beginPath(); g.moveTo(side * 0.012, -0.1); g.lineTo(side * 0.07, -0.24); g.lineTo(side * 0.075, -0.1); g.closePath(); g.fillStyle = shade(m.fw, 0.55); g.fill(); }
    g.beginPath(); g.ellipse(0, -0.35, 0.065, 0.055, 0, 0, Math.PI * 2); g.fillStyle = shade(m.fw, 0.75); g.fill(); g.lineWidth = lw; g.strokeStyle = ink; g.stroke();
    for (side = -1; side <= 1; side += 2) { g.beginPath(); g.arc(side * 0.055, -0.36, 0.03, 0, Math.PI * 2); g.fillStyle = '#170f0b'; g.fill(); g.beginPath(); g.arc(side * 0.048, -0.37, 0.012, 0, Math.PI * 2); g.fillStyle = 'rgba(255,198,112,0.9)'; g.fill(); }
    // antennae: feathered on the thorn, held out on a set moth, laid back along the costa at rest
    g.strokeStyle = shade(m.fw, 0.45);
    for (side = -1; side <= 1; side += 2) {
      g.save(); g.scale(side, 1); g.lineWidth = Math.max(px, 0.02) * (hk ? 1.6 : 1); g.beginPath(); g.moveTo(0.03, -0.39);
      if (H || hk) g.quadraticCurveTo(0.1, -0.6, 0.32, -0.66); else g.quadraticCurveTo(0.22, -0.48, 0.36, -0.14);
      g.stroke();
      if (sh === 'thorn') { g.lineWidth = Math.max(px * 0.8, 0.012); g.beginPath(); for (i = 1; i < 9; i++) { var u = i / 9, v = 1 - u, ax = 2 * v * u * 0.1 + u * u * 0.32 + v * v * 0.03, ay2 = v * v * -0.39 + 2 * v * u * -0.6 + u * u * -0.66, f = 0.045 * (1 - u * 0.6); g.moveTo(ax, ay2); g.lineTo(ax - f * 0.3, ay2 - f); g.moveTo(ax, ay2); g.lineTo(ax + f, ay2 + f * 0.2); } g.stroke(); }
      g.restore();
    }
    g.restore();
  }

  return { B: B, M: M, bird: bird, small: small, moth: moth, plume: plume, shade: shade, hex: hex };
}());
if (typeof module === 'object' && module.exports) module.exports = ART;
