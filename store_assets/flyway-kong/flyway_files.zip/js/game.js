/**
 * game.js - FLYWAY: layout (two shapes), drawing, input, save/resume and the loop. Every number on screen is read from
 * SIM (sim.js); every bird and moth is drawn by ART (art.js); this file computes none of the observatory.
 *
 * Surfaces, chosen by the viewport: WIDE 960x600, SHORT 800x500 (a landscape phone) and TALL 540x960 (a phone held
 * upright: the board turns a quarter so its cells are big enough to tap, and the panels become full-height sheets). The
 * canvas element keeps the surface's aspect (CSS aspect-ratio from --ar), so a tap maps with ONE scale on both axes.
 * Type and controls have floors in CSS pixels, converted with the live scale: body type is never under 10 css px and no
 * control is under 24 css px, whatever the screen. Save/resume, never a restart: autosave on every action, every game
 * day and every 5 s. Keys are preventDefault-ed only for the ones the game uses; Tab is never taken (WCAG 2.1.2).
 * Every string goes through text() and every control through button(), so both floors live in one place each.
 */
'use strict';

(function () {
  var cv = document.getElementById('cv');
  var g = cv.getContext('2d');
  var SAVE_KEY = 'flyway.observatory.v1';
  var SHAPES = { wide: { W: 960, H: 600 }, short: { W: 800, H: 500 }, tall: { W: 540, H: 960 } };
  var shape = 'wide', W = 960, H = 600, DPR = 1;
  var C = {
    night: '#0f1720', bg: '#16212c', panel: '#1d2a37', panelEdge: '#46607a', ink: '#eef0ea', inkDim: '#c3ccd4', inkFaint: '#8d9aa7',
    sea: '#2b5d7e', seaDeep: '#1f4763', foam: '#cfe2ea', sand: '#c9b48a', grass: '#5d7d45', grassDk: '#4a6a37', scrub: '#3c5a2e', scrubLit: '#5f8442',
    reed: '#b39a5e', reedDk: '#7e6c3e', wall: '#8a8378', wallDk: '#5e584f', soil: '#5a4432', lamp: '#ffcf7a', warm: '#f2b25a', good: '#a9de8a', bad: '#ff8f72', warn: '#ffd36a',
    btn: '#253445', btnOn: '#35506a', btnEdge: '#7f99b2', net: 'rgba(225,232,236,0.75)', desk: '#3a2a1e', deskLit: '#6a4a2e',
  };
  var UI = '"FW Body", "Trebuchet MS", sans-serif';
  try { if (document.fonts && document.fonts.load) { document.fonts.load('500 16px "FW Body"'); document.fonts.load('800 16px "FW Body"'); } } catch (e) { /* the fallback stays */ }
  var PLATES = {};
  ['grass', 'sea', 'sand'].forEach(function (k) { var im = new Image(); im.onload = function () { try { PLATES[k] = g.createPattern(im, 'repeat'); BOARD = null; } catch (e) { /* flat colour stays */ } }; im.src = 'art/plate_' + k + '.png'; });

  var state = { screen: 'title', game: null, tool: 'net', tab: 'table', speed: 1, paused: false, help: false, helpFrom: 'play', coach: 0, sel: -1, cursor: -1, toast: [], lastSaveReal: 0, confirmNew: 0, lastRingSeen: 0, listPage: 0, mothPage: 0, reportPage: 0, confirmDown: -1, confirmUntil: 0 };
  var COACH_KEY = 'flyway.coached.v1';
  function coached() { try { return localStorage.getItem(COACH_KEY) === '1'; } catch (e) { return true; } }
  function setCoached() { try { localStorage.setItem(COACH_KEY, '1'); } catch (e) { /* blocked: the coach shows again next time */ } }

  /* ------------------------------------------------------------------ save */
  var saveFailSaid = false;
  function save() {
    if (!state.game) return;
    try { localStorage.setItem(SAVE_KEY, JSON.stringify({ v: 1, savedAt: Date.now(), game: state.game })); state.lastSaveReal = Date.now(); }
    catch (e) { if (!saveFailSaid) { saveFailSaid = true; toast('This browser is blocking saves: progress will not persist.', 'bad'); } }
  }
  function num(x) { return typeof x === 'number' && isFinite(x); }
  /** a save is loaded only if every structure the loop READS has the right shape (a bad save starts a new season) */
  function valid(a) {
    if (!a || a.v !== 1 || !Array.isArray(a.cells) || a.cells.length !== SIM.COLS * SIM.ROWS) return false;
    if (!num(a.year) || !num(a.day) || !num(a.min) || !num(a.money) || !num(a.members) || !num(a.reputation) || !num(a.hands)) return false;
    if (['season', 'over'].indexOf(a.phase) < 0 || !a.weather || !Array.isArray(a.weather.days) || a.weather.days.length < SIM.SEASON_DAYS) return false;
    if (!Array.isArray(a.nets) || !Array.isArray(a.waitNet) || !Array.isArray(a.bags) || !Array.isArray(a.handsBusy) || !Array.isArray(a.recoveries) || !Array.isArray(a.pending) || !Array.isArray(a.log)) return false;
    if (!a.unlocked || !a.listed || !a.ringedBy || !a.moths || !a.stats) return false;
    for (var i = 0; i < a.cells.length; i++) { var c = a.cells[i]; if (!c || typeof c.k !== 'string' || !c.birds || typeof c.birds !== 'object') return false; for (var k in c.birds) if (!SIM.BY_ID[k] || !num(c.birds[k])) return false; }
    for (var n = 0; n < a.nets.length; n++) if (!(a.nets[n] >= 0 && a.nets[n] < a.cells.length)) return false;
    for (var q = 0; q < a.bags.length; q++) if (!a.bags[q] || !SIM.BY_ID[a.bags[q].sp]) return false;
    if (a.phase === 'over' && !a.summary) return false;
    return true;
  }
  function load() { try { var raw = localStorage.getItem(SAVE_KEY); if (!raw) return null; var d = JSON.parse(raw); return d && valid(d.game) ? d.game : null; } catch (e) { return null; } }
  function clearSave() { try { localStorage.removeItem(SAVE_KEY); } catch (e) { /* blocked */ } }

  /* ------------------------------------------------------------------ text: the one door every string goes through */
  var REC = null, MAPREC = null;   // while recording: every string drawn, and every flyway map's frame and dots
  // THE TYPE FLOOR: a size asked for in logical px is raised until it is at least FLOOR_CSS css px at the live scale
  // (SCALE = the canvas element's css width over the surface width, read every frame in fit())
  var SCALE = 1, FLOOR_CSS = 10, TAP_CSS = 24;
  function eff(px) { return Math.max(px, Math.ceil(FLOOR_CSS / SCALE * 10) / 10); }
  function lh(px) { return Math.ceil(eff(px) * 1.3); }
  function font(px, w) { g.font = (w || '') + ' ' + eff(px) + 'px ' + UI; }
  function text(s, x, y, px, col, align, w) {
    var p = eff(px); font(px, w); g.fillStyle = col || C.ink; g.textAlign = align || 'left'; g.textBaseline = 'alphabetic';
    g.fillText(s, x, y);
    var tw = g.measureText(s).width;
    if (REC) { var x0 = align === 'center' ? x - tw / 2 : align === 'right' ? x - tw : x; var t = g.getTransform(); REC.push({ s: String(s), x: (x0 * t.a + t.e) / DPR, y: ((y - p * 0.8) * t.d + t.f) / DPR, w: tw * t.a / DPR, h: p * t.d / DPR, screen: state.screen, tab: state.tab }); }
    return tw;
  }
  function measure(s, px, w) { font(px, w); return g.measureText(s).width; }
  /** wrap on spaces; a single word wider than the line breaks after a hyphen if it has one */
  function wrap(s, maxW, px, w) {
    var words = []; String(s).split(' ').forEach(function (wd) { if (measure(wd, px, w) > maxW && wd.indexOf('-') > 0) { var parts = wd.split('-'); parts.forEach(function (pp, k) { words.push(k < parts.length - 1 ? pp + '-' : pp); }); words.push(null); } else words.push(wd); });
    var out = [], line = '';
    for (var i = 0; i < words.length; i++) {
      if (words[i] === null) continue; var join = line && !/-$/.test(line) ? ' ' : '';
      var t = line ? line + join + words[i] : words[i]; if (measure(t, px, w) > maxW && line) { out.push(line); line = words[i]; } else line = t;
    }
    if (line) out.push(line); return out;
  }
  function widest(lines, px, w) { var m = 0; lines.forEach(function (l) { m = Math.max(m, measure(l, px, w)); }); return m; }
  /** fit a line into a width by shrinking it, never below the type floor; it is never cut: a line that still cannot fit
   *  is drawn whole */
  function fitText(s, x, y, maxW, px, col, align, w) { var p = px; while (eff(p) > eff(1) && measure(s, p, w) > maxW) p -= 0.5; return text(s, x, y, p, col, align, w); }
  /** a name in a grid tile: wrapped onto at most two lines at ONE size the grid chose, centred, never cut */
  function nameBlock(s, cx, yBottom, maxW, px, col) { var lines = wrap(s, maxW, px); var L2 = lh(px); lines.forEach(function (ln, k) { text(ln, cx, yBottom - (lines.length - 1 - k) * L2, px, col, 'center'); }); return lines.length; }
  /** the largest column count (up to maxCols) at which every name wraps onto two lines or fewer inside its tile */
  function gridCols(names, totalW, px, maxCols, pad) { for (var c = maxCols; c > 1; c--) { var cw = totalW / c - pad; if (names.every(function (n) { var ls = wrap(n, cw, px); return ls.length <= 2 && widest(ls, px) <= cw; })) return c; } return 1; }

  /* ---- FLYWAY's display type: tall pixel capitals (5 x 9), for titles and the report cover ---- */
  var GLYPH = {
    A: ['01110', '11011', '11011', '11011', '11111', '11111', '11011', '11011', '11011'], B: ['11110', '11011', '11011', '11110', '11011', '11011', '11011', '11011', '11110'],
    C: ['01111', '11000', '11000', '11000', '11000', '11000', '11000', '11000', '01111'], D: ['11110', '11011', '11011', '11011', '11011', '11011', '11011', '11011', '11110'],
    E: ['11111', '11000', '11000', '11110', '11000', '11000', '11000', '11000', '11111'], F: ['11111', '11000', '11000', '11110', '11000', '11000', '11000', '11000', '11000'],
    G: ['01111', '11000', '11000', '11000', '11011', '11011', '11011', '11011', '01111'], H: ['11011', '11011', '11011', '11111', '11011', '11011', '11011', '11011', '11011'],
    I: ['11111', '01110', '01110', '01110', '01110', '01110', '01110', '01110', '11111'], K: ['11011', '11011', '11110', '11100', '11100', '11110', '11011', '11011', '11011'],
    L: ['11000', '11000', '11000', '11000', '11000', '11000', '11000', '11000', '11111'], M: ['1100011', '1110111', '1111111', '1101011', '1100011', '1100011', '1100011', '1100011', '1100011'],
    N: ['110011', '111011', '111011', '111111', '110111', '110111', '110011', '110011', '110011'], O: ['01110', '11011', '11011', '11011', '11011', '11011', '11011', '11011', '01110'],
    P: ['11110', '11011', '11011', '11011', '11110', '11000', '11000', '11000', '11000'], R: ['11110', '11011', '11011', '11011', '11110', '11110', '11011', '11011', '11011'],
    S: ['01111', '11000', '11000', '11100', '01110', '00111', '00011', '00011', '11110'], T: ['11111', '01110', '01110', '01110', '01110', '01110', '01110', '01110', '01110'],
    U: ['11011', '11011', '11011', '11011', '11011', '11011', '11011', '11011', '01110'], W: ['1100011', '1100011', '1100011', '1100011', '1101011', '1111111', '1111111', '1110111', '1100011'],
    Y: ['110011', '110011', '110011', '110011', '011110', '001100', '001100', '001100', '001100'], V: ['110011', '110011', '110011', '110011', '110011', '110011', '011110', '011110', '001100'],
    '0': ['01110', '11011', '11011', '11011', '11011', '11011', '11011', '11011', '01110'], '1': ['00110', '01110', '11110', '00110', '00110', '00110', '00110', '00110', '11111'],
    '2': ['01110', '11011', '00011', '00011', '00110', '01100', '11000', '11000', '11111'], '3': ['11110', '00011', '00011', '01110', '00011', '00011', '00011', '00011', '11110'],
    '4': ['00110', '01110', '11110', '11110', '11111', '00110', '00110', '00110', '00110'], '5': ['11111', '11000', '11000', '11110', '00011', '00011', '00011', '00011', '11110'],
    '6': ['01110', '11000', '11000', '11110', '11011', '11011', '11011', '11011', '01110'], '7': ['11111', '00011', '00011', '00110', '00110', '01100', '01100', '01100', '01100'],
    '8': ['01110', '11011', '11011', '01110', '11011', '11011', '11011', '11011', '01110'], '9': ['01110', '11011', '11011', '11011', '01111', '00011', '00011', '00011', '01110'],
  };
  // every stem is two cells wide (M and W are seven cells, N, V and Y six); the highlight is the outer top edge only
  // (row 0), and the cell size is a whole number of pixels so no letter shows a seam
  function display(s, x, y, px, col, align, shadow) {
    s = String(s).toUpperCase(); px = Math.max(1, Math.round(px)); var wdt = 0;
    var adv = function (ch) { var gl = GLYPH[ch]; return gl ? (gl[0].length + 1) * px : 3 * px; };
    for (var i = 0; i < s.length; i++) wdt += adv(s[i]); wdt -= px;
    var x0 = Math.round(align === 'center' ? x - wdt / 2 : align === 'right' ? x - wdt : x); y = Math.round(y);
    for (var pass = shadow ? 0 : 1; pass < 2; pass++) {
      var cx = x0;
      for (var k = 0; k < s.length; k++) {
        var gl = GLYPH[s[k]]; if (!gl) { cx += 3 * px; continue; }
        for (var r = 0; r < 9; r++) for (var c = 0; c < gl[r].length; c++) {
          if (gl[r][c] !== '1') continue;
          if (pass === 0) { g.fillStyle = shadow; g.fillRect(cx + c * px + px, y + r * px + px, px, px); continue; }
          g.fillStyle = r === 0 ? '#fff6dc' : col; g.fillRect(cx + c * px, y + r * px, px, px);
        }
        cx += adv(s[k]);
      }
    }
    if (REC) REC.push({ s: s, x: x0, y: y, w: wdt, h: 9 * px, screen: state.screen, display: true });
    return wdt;
  }

  /* ------------------------------------------------------------------ buttons: the one door every control goes through */
  var BTN = [];
  function roundRect(x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
  function button(id, label, x, y, w, h, opts) {
    opts = opts || {}; var on = !!opts.on, enabled = opts.enabled !== false;
    // THE TAP FLOOR, in the one door every control goes through: a control smaller than TAP_CSS css px at the live
    // scale grows about its own centre (no ceiling: on the smallest screen it is exactly the floor or more)
    var m = TAP_CSS / SCALE; if (h < m) { y -= (m - h) / 2; h = m; } if (w < m) { x -= (m - w) / 2; w = m; }
    g.fillStyle = on ? C.btnOn : enabled ? C.btn : '#1f2833'; roundRect(x, y, w, h, 5); g.fill();
    g.strokeStyle = on ? C.warm : enabled ? C.btnEdge : '#36424f'; g.lineWidth = on ? 2 : 1; roundRect(x + 0.5, y + 0.5, w - 1, h - 1, 5); g.stroke();
    var px = opts.px || 14; while (eff(px) > eff(1) && measure(label, px, 'bold') > w - 10) px -= 0.5;
    var n0 = REC ? REC.length : 0;
    text(label, x + w / 2, y + h / 2 + eff(px) * 0.36, px, opts.col || (enabled ? C.ink : C.inkFaint), 'center', 'bold');
    if (REC) { for (var q = n0; q < REC.length; q++) REC[q].btn = id; REC.push({ s: '[' + id + ']', x: x, y: y, w: w, h: h, screen: state.screen, rect: id }); }
    BTN.push({ id: id, x: x, y: y, w: w, h: h, enabled: enabled, label: label, why: opts.why || '' });
  }
  function panel(x, y, w, h, fill) { g.fillStyle = fill || C.panel; roundRect(x, y, w, h, 8); g.fill(); g.strokeStyle = C.panelEdge; g.lineWidth = 1; roundRect(x + 0.5, y + 0.5, w - 1, h - 1, 8); g.stroke(); }
  /** an opaque card drawn over part of the screen: strings and controls drawn earlier under it stop being live */
  function cover(x, y, w, h) {
    var inside = function (r) { return r.x < x + w && r.x + r.w > x && r.y < y + h && r.y + r.h > y; };
    BTN = BTN.filter(function (b) { return !inside(b); });
    if (REC) for (var i = REC.length - 1; i >= 0; i--) if (inside(REC[i])) REC.splice(i, 1);
  }
  function toast(msg, kind) { if (state.toast.some(function (t) { return t.msg === msg; })) return; state.toast.push({ msg: msg, kind: kind || 'info', until: Date.now() + 3200 }); if (state.toast.length > 3) state.toast.shift(); }

  /* ------------------------------------------------------------------ layout, per shape */
  function L() {
    if (shape === 'tall') {
      // the upright phone: a top bar, a row of tabs, and one full-height sheet under them. On the Board sheet the map is
      // turned a quarter (east, the sea, at the top) so 10 cells span the width and each is a tap target; the strip sits
      // under it. Every other tab is a sheet of its own.
      var top = 100, tabs = { x: 12, y: top + 4, w: W - 24, h: 40 }, body = { x: 12, y: tabs.y + tabs.h + 6, w: W - 24, h: H - (tabs.y + tabs.h + 6) - 8 };
      var stripH = 160, cell = Math.floor(Math.min(body.w / SIM.ROWS, (body.h - stripH - 8) / SIM.COLS));
      var map = { x: Math.round((W - cell * SIM.ROWS) / 2), y: body.y, w: cell * SIM.ROWS, h: cell * SIM.COLS };
      var sy = map.y + map.h + 8;
      return { top: top, tabs: tabs, map: map, strip: { x: body.x, y: sy, w: body.w, h: body.y + body.h - sy }, side: body, rot: true };
    }
    // wide and short share one arrangement, sized from the surface: a square-celled map, the strip under it, the side panel
    var mw = Math.round(W * (shape === 'short' ? 0.56 : 0.6) / SIM.COLS) * SIM.COLS, mh = mw * SIM.ROWS / SIM.COLS, top2 = 46;
    var map2 = { x: 12, y: top2 + 8, w: mw, h: mh }, sy2 = map2.y + mh + 8, sx = map2.x + mw + 12;
    return { top: top2, map: map2, strip: { x: 12, y: sy2, w: mw, h: H - sy2 - 12 }, side: { x: sx, y: map2.y, w: W - sx - 12, h: H - map2.y - 12 } };
  }
  function rot() { return shape === 'tall'; }
  /** where a cell of the (16 x 10) headland is drawn: its display column and row (turned a quarter on the tall shape) */
  function cellRC(i) { var c = i % SIM.COLS, r = Math.floor(i / SIM.COLS); return rot() ? { dc: r, dr: SIM.COLS - 1 - c } : { dc: c, dr: r }; }
  function cellSize() { var m = L().map; return rot() ? { w: m.w / SIM.ROWS, h: m.h / SIM.COLS } : { w: m.w / SIM.COLS, h: m.h / SIM.ROWS }; }
  function cellRect(i) { var m = L().map, s = cellSize(), p = cellRC(i); return { x: m.x + p.dc * s.w, y: m.y + p.dr * s.h, w: s.w, h: s.h }; }
  function boardShown() { return !rot() || state.tab === 'board'; }
  function cellAt(px, py) {
    var m = L().map, s = cellSize(); if (!boardShown() || px < m.x || py < m.y || px >= m.x + m.w || py >= m.y + m.h) return -1;
    var dc = Math.floor((px - m.x) / s.w), dr = Math.floor((py - m.y) / s.h);
    return rot() ? dc * SIM.COLS + (SIM.COLS - 1 - dr) : dr * SIM.COLS + dc;
  }

  /* ------------------------------------------------------------------ the headland board (static ground, cached) */
  var BOARD = null, BOARD_KEY = '';
  function hsh(a, b, c) { return SIM.hash(a, b, c); }
  function boardCanvas() {
    var gm = state.game, m = L().map, s = cellSize();
    var key = shape + '|' + DPR + '|' + gm.cells.map(function (c) { return c.k[0] + Math.round(c.cover * 4); }).join('') + '|' + (gm.trap === null ? -1 : gm.trap) + '|' + (gm.unlocked.garden ? 1 : 0) + '|' + Object.keys(PLATES).join('');
    if (BOARD && BOARD_KEY === key) return BOARD;
    var c = document.createElement('canvas'); c.width = Math.ceil(m.w * DPR); c.height = Math.ceil(m.h * DPR);
    var b = c.getContext('2d'); b.scale(DPR, DPR);
    gm.cells.forEach(function (cell, i) {
      var p = cellRC(i), x = p.dc * s.w, y = p.dr * s.h, w = s.w, h = s.h;
      var under = cell.k === 'sea' ? (PLATES.sea || C.sea) : cell.k === 'shore' ? (PLATES.sand || C.sand) : (PLATES.grass || C.grass);
      b.fillStyle = under; b.fillRect(x, y, w + 0.5, h + 0.5);
      tile(b, cell, i, x, y, w, h, gm);
    });
    // shore surf where land meets sea, drawn on whichever side of the DRAWN cell the land lies
    gm.cells.forEach(function (cell, i) {
      if (cell.k !== 'sea') return; var p = cellRC(i), x = p.dc * s.w, y = p.dr * s.h, c0 = i % SIM.COLS, r0 = Math.floor(i / SIM.COLS);
      b.fillStyle = 'rgba(220,236,240,0.75)';
      [[-1, 0], [1, 0], [0, -1], [0, 1]].forEach(function (d) {
        var a = c0 + d[0], bb = r0 + d[1]; if (a < 0 || bb < 0 || a >= SIM.COLS || bb >= SIM.ROWS) return; var j = bb * SIM.COLS + a; if (gm.cells[j].k === 'sea') return;
        var q = cellRC(j), ddx = q.dc - p.dc, ddy = q.dr - p.dr;
        if (ddx < 0) b.fillRect(x, y, 3, s.h); else if (ddx > 0) b.fillRect(x + s.w - 3, y, 3, s.h); else if (ddy < 0) b.fillRect(x, y, s.w, 3); else b.fillRect(x, y + s.h - 3, s.w, 3);
      });
    });
    BOARD = c; BOARD_KEY = key; return c;
  }
  /** one cell of ground, drawn from its own seed: bushes are clumps of lit leaf-blobs, reeds are stems, the wall is coursed stone */
  function tile(b, cell, i, x, y, w, h, gm) {
    var r = SIM.rng(i * 7919 + 13);
    if (cell.k === 'scrub' || (cell.k === 'grass' && cell.cover > 0)) {
      var n = cell.k === 'scrub' ? 4 : Math.max(1, Math.round(cell.cover * 1.3)), big = cell.k === 'scrub' ? 1 : 0.45 + cell.cover * 0.18;
      for (var k = 0; k < n; k++) { var bx = x + w * (0.2 + r() * 0.6), by = y + h * (0.3 + r() * 0.55), br = w * (0.2 + r() * 0.12) * big; bush(b, bx, by, br, r); }
      if (cell.k === 'grass') { b.fillStyle = 'rgba(40,30,20,0.35)'; b.fillRect(x + w * 0.15, y + h * 0.9, w * 0.7, 2); }
    } else if (cell.k === 'reed') {
      b.fillStyle = '#6e7a3e'; b.fillRect(x, y, w, h);
      for (var s2 = 0; s2 < 18; s2++) { var sx = x + r() * w, top = y + r() * h * 0.4, lean = (r() - 0.5) * 4; b.strokeStyle = s2 % 3 ? C.reed : C.reedDk; b.lineWidth = 1.4; b.beginPath(); b.moveTo(sx, y + h); b.lineTo(sx + lean, top); b.stroke(); if (s2 % 4 === 0) { b.fillStyle = '#5e4a2e'; b.fillRect(sx + lean - 1.5, top - 3, 3, 6); } }
    } else if (cell.k === 'pool') {
      b.fillStyle = '#6e7a3e'; b.fillRect(x, y, w, h); b.fillStyle = '#3d6c80'; b.beginPath(); b.ellipse(x + w / 2, y + h / 2, w * 0.42, h * 0.36, 0, 0, 6.3); b.fill(); b.fillStyle = 'rgba(220,236,240,0.4)'; b.fillRect(x + w * 0.3, y + h * 0.4, w * 0.2, 1.5);
    } else if (cell.k === 'wall') {
      b.fillStyle = C.wallDk; b.fillRect(x, y, w, h);
      for (var row = 0; row < 5; row++) for (var col = 0; col < 4; col++) { var sw = w / 3.5, sh = h / 5, ox = (row % 2) * sw / 2; b.fillStyle = r() < 0.5 ? C.wall : '#9a9387'; b.fillRect(x + col * sw - ox + 1, y + row * sh + 1, sw - 2, sh - 2); b.fillStyle = 'rgba(255,255,255,0.15)'; b.fillRect(x + col * sw - ox + 1, y + row * sh + 1, sw - 2, 1); }
    } else if (cell.k === 'garden') {
      b.fillStyle = C.soil; b.fillRect(x, y, w, h);
      for (var rw = 0; rw < 4; rw++) { b.fillStyle = 'rgba(30,20,12,0.4)'; b.fillRect(x, y + rw * h / 4 + h / 8, w, 2); }
      var nn = gm.unlocked.garden ? 5 : 2; for (var k2 = 0; k2 < nn; k2++) bush(b, x + w * (0.2 + r() * 0.6), y + h * (0.25 + r() * 0.6), w * (gm.unlocked.garden ? 0.18 : 0.12), r, gm.unlocked.garden ? '#a04a3a' : null);
    } else if (cell.k === 'light') {
      b.fillStyle = C.sand; b.fillRect(x, y, w, h);
      b.fillStyle = '#f2efe6'; b.fillRect(x + w * 0.36, y + h * 0.15, w * 0.28, h * 0.8); b.fillStyle = '#c8402e'; b.fillRect(x + w * 0.36, y + h * 0.42, w * 0.28, h * 0.12); b.fillRect(x + w * 0.36, y + h * 0.72, w * 0.28, h * 0.1);
      b.fillStyle = '#2a2a30'; b.fillRect(x + w * 0.32, y + h * 0.06, w * 0.36, h * 0.12); b.fillStyle = C.lamp; b.fillRect(x + w * 0.4, y + h * 0.08, w * 0.2, h * 0.08);
    } else if (cell.k === 'hut') {
      b.fillStyle = '#7a5a3a'; b.fillRect(x + w * 0.1, y + h * 0.35, w * 0.8, h * 0.6); b.fillStyle = '#4a3424'; b.beginPath(); b.moveTo(x + w * 0.02, y + h * 0.38); b.lineTo(x + w * 0.5, y + h * 0.08); b.lineTo(x + w * 0.98, y + h * 0.38); b.fill();
      b.fillStyle = C.lamp; b.fillRect(x + w * 0.25, y + h * 0.52, w * 0.18, h * 0.18); b.fillStyle = '#2a1e16'; b.fillRect(x + w * 0.58, y + h * 0.55, w * 0.18, h * 0.4);
      for (var pl = 0; pl < 4; pl++) { b.fillStyle = 'rgba(0,0,0,0.2)'; b.fillRect(x + w * 0.1, y + h * (0.45 + pl * 0.13), w * 0.8, 1); }
    } else if (cell.k === 'grass') {
      for (var t = 0; t < 6; t++) { b.fillStyle = r() < 0.5 ? '#6f9150' : '#4c6b38'; b.fillRect(x + r() * w, y + r() * h, 1.5, 3); }
    } else if (cell.k === 'shore') {
      for (var rk = 0; rk < 3; rk++) { var rx = x + w * (0.15 + r() * 0.7), ry = y + h * (0.2 + r() * 0.6); b.fillStyle = '#8a8478'; b.beginPath(); b.ellipse(rx, ry, w * 0.1, h * 0.07, 0, 0, 6.3); b.fill(); b.fillStyle = '#b4ad9e'; b.fillRect(rx - w * 0.06, ry - h * 0.05, w * 0.06, 2); }
    }
    if (gm.trap === i) trapArt(b, x, y, w, h);
  }
  function bush(b, cx, cy, rr, r, berry) {
    b.fillStyle = 'rgba(20,30,16,0.45)'; b.beginPath(); b.ellipse(cx + rr * 0.15, cy + rr * 0.7, rr * 1.05, rr * 0.45, 0, 0, 6.3); b.fill();
    for (var k = 0; k < 5; k++) { var a = k * 1.25 + r(), ox = Math.cos(a) * rr * 0.45, oy = Math.sin(a) * rr * 0.35; b.fillStyle = C.scrub; b.beginPath(); b.arc(cx + ox, cy + oy, rr * 0.62, 0, 6.3); b.fill(); }
    for (var q = 0; q < 4; q++) { b.fillStyle = C.scrubLit; b.beginPath(); b.arc(cx - rr * 0.3 + r() * rr * 0.4, cy - rr * 0.35 + r() * rr * 0.3, rr * 0.28, 0, 6.3); b.fill(); }
    if (berry) for (var k2 = 0; k2 < 3; k2++) { b.fillStyle = berry; b.fillRect(cx + (r() - 0.5) * rr, cy + (r() - 0.5) * rr, 2, 2); }
  }
  function trapArt(b, x, y, w, h) {
    b.strokeStyle = 'rgba(230,236,240,0.85)'; b.lineWidth = 1; b.beginPath(); b.moveTo(x + 2, y + 3); b.lineTo(x + w * 0.5, y + h * 0.7); b.lineTo(x + w - 2, y + 3); b.stroke();
    for (var k = 1; k < 5; k++) { b.beginPath(); b.moveTo(x + 2 + k * w * 0.1, y + 3 + k * h * 0.13); b.lineTo(x + w - 2 - k * w * 0.1, y + 3 + k * h * 0.13); b.stroke(); }
    b.fillStyle = '#7a5a3a'; b.fillRect(x + w * 0.38, y + h * 0.68, w * 0.24, h * 0.24); b.fillStyle = 'rgba(230,236,240,0.7)'; b.fillRect(x + w * 0.42, y + h * 0.72, w * 0.16, h * 0.1);
  }

  /* ------------------------------------------------------------------ drawing the play screen */
  var T0 = performance.now();
  function clock() { return (performance.now() - T0) / 1000; }
  function hhmm(min) { var h = Math.floor(min / 60), m = min % 60; return (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m; }
  function sky(gm) {
    var t = (gm.min - SIM.DAY_START) / (SIM.DAY_END - SIM.DAY_START), w = SIM.today(gm);
    return { dawn: Math.max(0, 1 - t * 6), dusk: Math.max(0, (t - 0.82) * 5.5), rain: SIM.wetNow(gm) ? 1 : 0, wind: w };
  }
  function drawMap() {
    var gm = state.game, m = L().map, s = cellSize();
    g.drawImage(boardCanvas(), m.x, m.y, m.w, m.h);
    // the sea moves
    var t = clock();
    g.save(); g.beginPath(); g.rect(m.x, m.y, m.w, m.h); g.clip();
    gm.cells.forEach(function (c, i) { if (c.k !== 'sea') return; var r = cellRect(i); for (var k = 0; k < 2; k++) { var yy = r.y + ((k * 0.5 + (t * 0.08 + (i % 7) * 0.13)) % 1) * r.h; g.fillStyle = 'rgba(220,236,240,0.35)'; g.fillRect(r.x + r.w * 0.15 + k * r.w * 0.3, yy, r.w * 0.3, 1.2); } });
    // nets: a fine mesh between two poles; furled when closed or in the rain
    gm.nets.forEach(function (i) { var r = cellRect(i), c = gm.cells[i], open = c.open && !SIM.wetNow(gm); netArt(r, open, i); });
    // grounded birds: small sprites in the cover, up to three per cell
    gm.cells.forEach(function (c, i) {
      var keys = Object.keys(c.birds); if (!keys.length) return;
      var r = cellRect(i), shown = 0, total = 0; keys.forEach(function (k) { total += c.birds[k]; });
      keys.sort(function (a, b) { return c.birds[b] - c.birds[a]; });
      for (var q = 0; q < keys.length && shown < 2; q++, shown++) {
        var hop = Math.sin(t * 3 + i * 1.7 + q * 2.1) > 0.92 ? -2 : 0;
        var sp = ART.small(keys[q], Math.round(s.w * (q ? 0.5 : 0.62)), '', (i + q) % 2 === 1);
        g.drawImage(sp, Math.round(r.x + r.w * (q ? 0.42 : -0.04)), Math.round(r.y + r.h * (q ? 0.02 : 0.04) + hop), sp.width, sp.height);
      }
      // the count sits in the bottom-right corner of the cell, off the birds it counts
      if (total > 2) { var bt = String(total), bw2 = measure(bt, 10, 'bold') + 6, bh2 = eff(10) + 2; g.fillStyle = 'rgba(14,20,28,0.78)'; roundRect(r.x + r.w - bw2 - 1, r.y + r.h - bh2 - 1, bw2, bh2, 3); g.fill(); text(bt, r.x + r.w - 1 - bw2 / 2, r.y + r.h - 3 - eff(10) * 0.12, 10, C.ink, 'center', 'bold'); }
    });
    // birds waiting in nets
    gm.waitNet.forEach(function (b, k) { var r = cellRect(b.net), sp = ART.small(b.sp, Math.round(s.w * 0.38), '', k % 2 === 0); g.drawImage(sp, r.x + r.w * (0.1 + (k % 3) * 0.24), r.y + r.h * 0.3 + (k % 2) * 4); });
    // the weather on the board: rain, a dawn glow, the lighthouse beam at dawn and dusk
    var sk = sky(gm);
    if (sk.rain) { g.strokeStyle = 'rgba(200,215,230,0.45)'; g.lineWidth = 1; for (var k3 = 0; k3 < 90; k3++) { var rx = m.x + ((k3 * 73 + t * 300) % m.w), ry = m.y + ((k3 * 41 + t * 520) % m.h); g.beginPath(); g.moveTo(rx, ry); g.lineTo(rx - 3, ry + 9); g.stroke(); } }
    if (sk.dawn > 0) { g.fillStyle = 'rgba(255,170,110,' + (0.22 * sk.dawn) + ')'; g.fillRect(m.x, m.y, m.w, m.h); }
    if (sk.dusk > 0) { g.fillStyle = 'rgba(30,30,70,' + (0.35 * Math.min(1, sk.dusk)) + ')'; g.fillRect(m.x, m.y, m.w, m.h); }
    if (sk.dawn > 0 || sk.dusk > 0) {
      var li = -1; gm.cells.forEach(function (c, i) { if (c.k === 'light') li = i; }); var lr = cellRect(li), ang = t * 0.9;
      var lx = lr.x + lr.w / 2, ly = lr.y + lr.h * 0.12, gr = g.createRadialGradient(lx, ly, 2, lx, ly, m.w * 0.7);
      gr.addColorStop(0, 'rgba(255,230,160,0.45)'); gr.addColorStop(1, 'rgba(255,230,160,0)');
      g.fillStyle = gr; g.beginPath(); g.moveTo(lx, ly); g.arc(lx, ly, m.w * 0.7, ang, ang + 0.16); g.closePath(); g.fill();
    }
    // the cursor / selection
    var sel = state.cursor >= 0 ? state.cursor : state.hover;
    if (sel >= 0) { var sr = cellRect(sel); g.strokeStyle = C.warn; g.lineWidth = 2; g.strokeRect(sr.x + 1, sr.y + 1, sr.w - 2, sr.h - 2); }
    g.restore();
    g.strokeStyle = C.panelEdge; g.lineWidth = 1; g.strokeRect(m.x + 0.5, m.y + 0.5, m.w - 1, m.h - 1);
  }
  function netArt(r, open, i) {
    var x0 = r.x + r.w * 0.08, x1 = r.x + r.w * 0.92, y0 = r.y + r.h * 0.12, y1 = r.y + r.h * 0.88;
    g.strokeStyle = '#3a2c20'; g.lineWidth = 2; g.beginPath(); g.moveTo(x0, y0 - 2); g.lineTo(x0, y1 + 2); g.moveTo(x1, y0 - 2); g.lineTo(x1, y1 + 2); g.stroke();
    if (!open) { g.strokeStyle = 'rgba(225,232,236,0.85)'; g.lineWidth = 3; g.beginPath(); g.moveTo(x0, y0 + 2); g.lineTo(x1, y0 + 2); g.stroke(); return; }
    g.strokeStyle = C.net; g.lineWidth = 0.6;
    for (var k = 0; k <= 8; k++) { var xx = x0 + (x1 - x0) * k / 8; g.beginPath(); g.moveTo(xx, y0); g.lineTo(xx + 2, y1); g.stroke(); }
    for (var s = 0; s <= 4; s++) { var yy = y0 + (y1 - y0) * s / 4; g.lineWidth = s % 2 ? 0.6 : 1.2; g.beginPath(); g.moveTo(x0, yy); g.lineTo(x1, yy + 1); g.stroke(); }
  }

  function arrow(ax, ay, dir) {
    var ang = { N: -Math.PI / 2, NE: -Math.PI / 4, E: 0, SE: Math.PI / 4, S: Math.PI / 2, SW: 3 * Math.PI / 4, W: Math.PI, NW: -3 * Math.PI / 4 }[dir] + Math.PI;
    g.save(); g.translate(ax, ay); g.rotate(ang); g.strokeStyle = C.warn; g.lineWidth = 2; g.beginPath(); g.moveTo(-7, 0); g.lineTo(7, 0); g.lineTo(3, -4); g.moveTo(7, 0); g.lineTo(3, 4); g.stroke(); g.restore();
  }
  function topButtons(bx, by, bh) {
    // speed and pause are two controls: the speed button only changes speed, the pause button only pauses
    var x = bx;
    button('speed', state.speed + 'x', x, by, 52, bh); x += 58;
    button('pause', state.paused ? 'Play' : 'Pause', x, by, 70, bh, { on: state.paused }); x += 76;
    button('sound', AUDIO.isMuted() ? 'Sound: off' : 'Sound: on', x, by, 96, bh); x += 102;
    button('help', '?', x, by, 34, bh);
    return x + 34;
  }
  function topWidth() { return 52 + 6 + 70 + 6 + 96 + 6 + 34; }
  function drawTop() {
    var gm = state.game, top = L().top;
    g.fillStyle = '#121b25'; g.fillRect(0, 0, W, top);
    var w = SIM.today(gm), fall = SIM.fallIndex(w), sky = SIM.describe(w) + (fall > 1.1 ? ' · FALL' : fall < 0.25 ? ' · flying over' : '');
    var date = 'Autumn ' + gm.year + ' · day ' + Math.min(gm.day, SIM.SEASON_DAYS) + ' of ' + SIM.SEASON_DAYS + ' · ' + hhmm(gm.min);
    if (shape === 'tall') {
      // three rows: the wordmark and the controls; the date and the purse; the wind and the sky
      display('FLYWAY', 12, 12, 3, '#e8c27a', 'left', '#3a2a14');
      topButtons(W - 12 - topWidth(), 6, 36);
      var r2 = 66, r3 = 92;
      text(date, 12, r2, 13, C.inkDim, 'left', 'bold');
      var mw = text(gm.members + ' members', W - 12, r2, 12, C.inkDim, 'right');
      text('£' + gm.money, W - 12 - mw - 12, r2, 15, C.good, 'right', 'bold');
      arrow(22, r3 - eff(12) * 0.35, w.dir);
      fitText(sky, 38, r3, W - 50, 12, fall > 1.1 ? C.warn : C.inkDim);
      return;
    }
    var x = 12 + display('FLYWAY', 12, 9, 3, '#e8c27a', 'left', '#3a2a14') + 16;
    text(date, x, 19, 13, C.inkDim, 'left', 'bold');
    arrow(x + 8, 34, w.dir);
    var rx = W - 12, moneyW = Math.max(measure('£' + gm.money, 15, 'bold'), measure(gm.members + ' members', 12)), bx = rx - moneyW - 12 - topWidth();
    fitText(sky, x + 22, 39, bx - x - 30, 12, fall > 1.1 ? C.warn : C.inkDim);
    text('£' + gm.money, rx, 19, 15, C.good, 'right', 'bold');
    text(gm.members + ' members', rx, 39, 12, C.inkDim, 'right');
    topButtons(bx, 8, 30);
  }

  function drawStrip() {
    var gm = state.game, s = L().strip;
    panel(s.x, s.y, s.w, s.h);
    var x = s.x + 12, y = s.y + 22;
    var hw = text('NETS AND HANDS', x, y, 12, C.warm, 'left', 'bold');
    if (gm.unlocked.instruments) {   // the barograph and the vane: tomorrow's weather, read off the same days the season will play
      var fc = SIM.forecast(gm, 1);
      if (fc) fitText('Tomorrow: ' + fc.sky + (fc.fall > 1.1 ? ' · fall likely' : fc.fall < 0.25 ? ' · flying over' : ''), s.x + s.w - 12, y, s.w - hw - 40, 12, fc.fall > 1.1 ? C.warn : C.inkDim, 'right', 'bold');
    }
    var open = SIM.netsOpen(gm), wet = SIM.wetNow(gm);
    fitText(wet ? 'Nets furled: rain. They open when it clears, at ' + hhmm(gm.rainUntil) + '.' : open + ' of ' + gm.nets.length + ' nets open · ' + gm.nets.length + ' of ' + SIM.maxNets(gm) + ' set · ' + gm.hands + (gm.hands === 1 ? ' ringer' : ' ringers'), x, y + lh(13), s.w - 24, 13, wet ? C.warn : C.inkDim);
    // the welfare clock: the bird nearest its own limit (40 in a net, 70 in a bag, 90 in the trap). The bar is that
    // fraction; the line prints the real minutes and the limit that applies.
    var worst = null; gm.waitNet.forEach(function (b) { var wt = gm.min - b.at, f0 = wt / SIM.NET_LIMIT; if (!worst || f0 > worst.f) worst = { f: f0, wait: wt, limit: SIM.NET_LIMIT, where: 'net' }; });
    gm.bags.forEach(function (b) { var lim = b.trap ? SIM.TRAP_LIMIT : SIM.BAG_LIMIT, wt = gm.min - b.at, f0 = wt / lim; if (!worst || f0 > worst.f) worst = { f: f0, wait: wt, limit: lim, where: b.trap ? 'trap' : 'bag' }; });
    var bw = s.w - 24, by = y + lh(13) + 10;
    BAR = { x: x, y: by, w: bw, h: 14 };
    g.fillStyle = '#0f1720'; roundRect(x, by, bw, 14, 4); g.fill();
    var f = worst ? Math.min(1, worst.f) : 0; g.fillStyle = f < 0.45 ? C.good : f < 0.75 ? C.warn : C.bad; roundRect(x, by, Math.max(4, bw * f), 14, 4); g.fill();
    var wline = gm.waitNet.length + ' in nets · ' + gm.bags.length + ' in bags · ' + (worst ? 'oldest waited ' + worst.wait + ' of ' + worst.limit + ' min (' + worst.where + ')' : 'nobody waiting');
    var wl = wrap(wline, bw, 12); wl.forEach(function (ln, k) { text(ln, x, by + 14 + lh(12) + k * lh(12), 12, f < 0.45 ? C.inkDim : f < 0.75 ? C.warn : C.bad); });
    // tools and the round
    var bh = 30, ty = s.y + s.h - bh - 10, tw = shape === 'short' ? 84 : shape === 'wide' ? 96 : 88;
    button('tool_net', 'Nets', x, ty, tw, bh, { on: state.tool === 'net' });
    button('tool_plant', 'Plant £' + (gm.unlocked.garden ? Math.round(SIM.COST.plant * 0.6) : SIM.COST.plant), x + tw + 6, ty, tw, bh, { on: state.tool === 'plant' });
    button('tool_down', 'Take down', x + (tw + 6) * 2, ty, tw, bh, { on: state.tool === 'down' });
    var rx = x + (tw + 6) * 3 + 8, rw = 44;
    if (shape === 'tall') { var lw = text('Rounds', rx, ty + bh / 2 + eff(12) * 0.36, 12, C.inkFaint); rx += lw + 8; rw = Math.min(52, (s.x + s.w - 12 - rx - 12) / 3); }
    else text('Rounds every', rx, ty - 6, 12, C.inkFaint);
    [20, 30, 45].forEach(function (mn, k) { button('round_' + mn, mn + 'm', rx + k * (rw + 4), ty, rw, bh, { on: gm.roundEvery === mn }); });
  }
  var BAR = null;

  function tabList() { var l = [['table', 'Table'], ['ladder', 'Ladder'], ['list', 'List'], ['map', 'Map'], ['log', 'Log']]; if (shape === 'tall') l.unshift(['board', 'Board']); return l; }
  function tabs() {
    var lay = L(), list = tabList();
    if (shape === 'tall') {
      var tb = lay.tabs, tw2 = (tb.w + 4) / list.length;
      list.forEach(function (t, k) { button('tab_' + t[0], t[1], tb.x + k * tw2, tb.y, tw2 - 4, tb.h, { on: state.tab === t[0] }); });
      return lay.side;
    }
    var sd = lay.side, tw = (sd.w - 8) / list.length;
    list.forEach(function (t, k) { button('tab_' + t[0], t[1], sd.x + k * tw + (k ? 2 : 0), sd.y, tw - 2, 30, { on: state.tab === t[0] }); });
    var top = sd.y + Math.max(30, TAP_CSS / SCALE) + 6;
    return { x: sd.x, y: top, w: sd.w, h: sd.y + sd.h - top };
  }
  function drawSide() {
    var gm = state.game, r = tabs();
    if (shape !== 'tall' && state.tab === 'board') state.tab = 'table';
    if (state.coach && shape !== 'tall') { drawCoach(r); return; }
    if (state.tab === 'board') return;
    if (state.tab === 'table') drawTable(r);
    else if (state.tab === 'ladder') drawLadder(r);
    else if (state.tab === 'list') drawList(r);
    else if (state.tab === 'map') {
      panel(r.x, r.y, r.w, r.h, '#d8cfb8'); var cap = gm.recoveries.length ? gm.recoveries.length + (gm.recoveries.length === 1 ? ' ring' : ' rings') + ' found again. Each line runs from the headland to where it was found.' : 'No ring has been found again yet. When one is, its line is drawn here.';
      var cl = wrap(cap, r.w - 20, 12), ch = cl.length * lh(12) + 8;
      drawFlyway(r.x + 6, r.y + 6, r.w - 12, r.h - 12 - ch, gm.recoveries, true);
      cl.forEach(function (ln, k) { text(ln, r.x + 10, r.y + r.h - 10 - (cl.length - 1 - k) * lh(12), 12, '#3a2e22'); });
    }
    else drawLog(r);
  }
  /* ---- the first-morning coach: three steps, the clock waits until the last one ---- */
  var COACH = [
    ['A NET BESIDE A BUSH', 'Birds land in cover: scrub, reeds, the garden. A mist net set on the open ground beside cover catches them. The ringed cell is your first net, open. Tap a net to open or close it.'],
    ['THE WAITING BAR', 'Under the map is the waiting bar: the bird that has waited longest against its limit, ' + SIM.NET_LIMIT + ' minutes in a net or ' + SIM.BAG_LIMIT + ' in a bag. The ringers walk rounds and ring at the hut.'],
    ['CLOSE A NET WHEN IT GOES AMBER', 'When the bar turns amber, close a net until the hands catch up. A bird that waits too long is let go unringed. A second net is set and closed: open it when you are ready.'],
  ];
  function drawCoach(r) {
    var st = COACH[state.coach - 1], pad = 14;
    panel(r.x, r.y, r.w, r.h, '#1b2734'); cover(r.x, r.y, r.w, r.h);
    var y = r.y + pad + eff(12);
    text('FIRST MORNING · ' + state.coach + ' of ' + COACH.length, r.x + pad, y, 12, C.inkFaint, 'left', 'bold'); y += lh(14) + 4;
    wrap(st[0], r.w - 2 * pad, 14, 'bold').forEach(function (ln) { text(ln, r.x + pad, y, 14, C.warm, 'left', 'bold'); y += lh(14); }); y += 4;
    var bh = Math.max(32, TAP_CSS / SCALE), by = r.y + r.h - bh - pad;
    // a picture made with the game's own art: the bush and net for step 1 and 3, the bar for step 2
    var lines = wrap(st[1], r.w - 2 * pad, 13), textH = lines.length * lh(13), picH = by - 10 - y - textH - 8;
    if (picH > 40) { coachPicture(r.x + pad, y, r.w - 2 * pad, Math.min(picH, 140)); y += Math.min(picH, 140) + 10; }
    lines.forEach(function (ln) { text(ln, r.x + pad, y + eff(13), 13, C.ink); y += lh(13); });
    var last = state.coach === COACH.length;
    button('coach_skip', 'Skip', r.x + pad, by, 80, bh);
    button('coach_next', last ? 'Start the day' : 'Next', r.x + r.w - pad - 140, by, 140, bh, { on: true });
  }
  function coachPicture(x, y, w, h) {
    g.fillStyle = '#26384a'; roundRect(x, y, w, h, 6); g.fill();
    if (state.coach === 2) {   // the bar, filling green, amber, red
      var bx = x + 14, bw = w - 28, by2 = y + h / 2 - 7; [['#a9de8a', 0.3], ['#ffd36a', 0.6], ['#ff8f72', 0.9]].forEach(function (c, k) { var yy = by2 - 24 + k * 24; g.fillStyle = '#0f1720'; roundRect(bx, yy, bw, 12, 4); g.fill(); g.fillStyle = c[0]; roundRect(bx, yy, bw * c[1], 12, 4); g.fill(); });
      return;
    }
    var cs = Math.min(h - 12, (w - 20) / 3), cx = x + (w - cs * 3) / 2, cy = y + (h - cs) / 2, r2 = SIM.rng(42);
    g.fillStyle = PLATES.grass || C.grass; g.fillRect(cx, cy, cs * 3, cs);
    bush(g, cx + cs * 0.5, cy + cs * 0.55, cs * 0.3, r2); bush(g, cx + cs * 0.35, cy + cs * 0.4, cs * 0.22, r2);
    netArt({ x: cx + cs, y: cy, w: cs, h: cs }, state.coach !== 3, -1);
    var sp = ART.small('robin', Math.round(cs * 0.5), '', false); g.drawImage(sp, cx + cs * 0.15, cy + cs * 0.05);
    if (state.coach === 3) { var sp2 = ART.small('goldcrest', Math.round(cs * 0.45), '', true); g.drawImage(sp2, cx + cs * 2.2, cy + cs * 0.3); }
    g.strokeStyle = C.warn; g.lineWidth = 2; g.strokeRect(cx + cs + 1, cy + 1, cs - 2, cs - 2);
  }
  /** the coach's pointer on the play screen: a ring around the thing the step names */
  function coachMark() {
    if (!state.coach) return; var gm = state.game; g.save(); g.strokeStyle = C.warn; g.lineWidth = 3; g.setLineDash([6, 4]);
    if (state.coach === 2 && BAR) { g.strokeRect(BAR.x - 4, BAR.y - 4, BAR.w + 8, BAR.h + 8); }
    else if (boardShown()) { var n = gm.nets.filter(function (i) { return gm.cells[i].open; })[0]; if (n === undefined) n = gm.nets[0]; if (n !== undefined) { var cr = cellRect(n); g.strokeRect(cr.x - 3, cr.y - 3, cr.w + 6, cr.h + 6); } }
    g.restore();
  }
  /** on the upright phone the coach card sits over the sea at the top of the board */
  function drawCoachTall() {
    var m = L().map, st = COACH[state.coach - 1], pad = 12, lines = wrap(st[1], W - 24 - 2 * pad, 12), bh = Math.max(32, TAP_CSS / SCALE);
    var r = { x: 12, y: m.y, w: W - 24, h: pad + lh(12) + 2 + lines.length * lh(12) + 8 + bh + 10 };
    panel(r.x, r.y, r.w, r.h, '#1b2734'); cover(r.x, r.y, r.w, r.h);
    var y = r.y + pad + eff(12);
    text(state.coach + ' of ' + COACH.length + ' · ' + st[0], r.x + pad, y, 12, C.warm, 'left', 'bold'); y += lh(12) + 2;
    var by = r.y + r.h - bh - 10;
    lines.forEach(function (ln) { text(ln, r.x + pad, y, 12, C.ink); y += lh(12); });
    button('coach_skip', 'Skip', r.x + pad, by, 80, bh);
    button('coach_next', state.coach === COACH.length ? 'Start the day' : 'Next', r.x + r.w - pad - 150, by, 150, bh, { on: true });
  }
  function drawTable(r) {
    var gm = state.game;
    // the ringing room: lamplight on a wooden table
    var gr = g.createRadialGradient(r.x + r.w * 0.5, r.y + 20, 20, r.x + r.w * 0.5, r.y + 60, r.w * 0.9);
    gr.addColorStop(0, '#7a5434'); gr.addColorStop(1, C.desk); g.fillStyle = gr; roundRect(r.x, r.y, r.w, r.h, 8); g.fill();
    for (var k = 1; k < 6; k++) { g.fillStyle = 'rgba(0,0,0,0.16)'; g.fillRect(r.x + 4, r.y + k * r.h / 6, r.w - 8, 1); }
    text('THE RINGING TABLE', r.x + 12, r.y + 22, 12, C.lamp, 'left', 'bold');
    // the footer first, so the bird and the bag queue are sized into what is left
    var foot = ['Ringed this autumn: ' + gm.stats.ringed, 'Year list: ' + Object.keys(gm.listed).length + ' of ' + SIM.SPECIES.length, 'Let go unringed: ' + gm.stats.early, 'Visitors today: ' + gm.visitorsToday + (gm.unlocked.moth ? ' · moths last night: ' + (gm.lastTrap || 0) : '')];
    var colW = (r.w - 32) / 2, two = foot.every(function (f) { return measure(f, 12) <= colW - 6; }) && measure(foot[3], 12) <= colW - 6;
    var fRows = two ? 2 : 4, fh = fRows * lh(12) + 12, qy = r.y + r.h - fh - 8;
    g.fillStyle = 'rgba(15,10,6,0.45)'; roundRect(r.x + 8, qy, r.w - 16, fh, 6); g.fill();
    foot.forEach(function (f, k) { var col = two ? k % 2 : 0, row = two ? Math.floor(k / 2) : k; text(f, r.x + 16 + col * colW, qy + 6 + eff(12) + row * lh(12), 12, k === 2 && gm.stats.early ? '#ffb39a' : '#f0e2c8'); });
    var last = gm.last, y0 = r.y + 22 + lh(12), tl = shape === 'tall';
    // the bag queue: as many rows of small birds as the band holds (bigger on the upright sheet), oldest first
    var qcell = tl ? 46 : 34, qart = tl ? 40 : 30, qcols = Math.max(1, Math.floor((r.w - 24) / qcell)), qrows = Math.min(tl ? 3 : 2, Math.ceil(gm.bags.length / qcols));
    var queueH = gm.bags.length ? lh(12) + 6 + qrows * qcell : 0;
    if (!last) { wrap('No bird in the hand yet. Birds land in cover; nets beside cover catch them; each round brings them to this table.', r.w - 24, 13).forEach(function (ln, i) { y0 += lh(13); text(ln, r.x + 12, y0, 13, '#f0e2c8'); }); y0 += 10; }
    else {
      var sp = SIM.BY_ID[last.sp], room = qy - y0 - 8 - lh(18) - lh(13) - 14 - queueH, big = Math.max(60, Math.min(r.w * 0.62, tl ? 300 : 190, room));
      // on the upright sheet the bird, its lines and the queue sit in the middle of the lamplit table, not at its top
      if (tl) y0 += Math.max(0, (qy - 8 - y0 - (big * 0.82 + eff(18) + lh(13) + 12 + queueH)) / 2);
      var bcx = r.x + r.w / 2, bcy = y0 + big * 0.42;
      // the bird in the hand: the ringer's fingers under it, and the ring closed on its leg
      g.fillStyle = 'rgba(232,200,160,0.85)'; [-0.16, -0.05, 0.06].forEach(function (o, k) { g.beginPath(); g.ellipse(bcx + big * o, y0 + big * 0.61 + k * 1.5, big * 0.07, big * 0.035, -0.2, 0, 6.3); g.fill(); });
      g.fillStyle = 'rgba(200,160,120,0.9)'; g.beginPath(); g.ellipse(bcx + big * 0.16, y0 + big * 0.62, big * 0.11, big * 0.05, 0.3, 0, 6.3); g.fill();
      ART.bird(g, sp.id, bcx, bcy, big, { sex: last.sex, ring: true });
      var ty = y0 + big * 0.82 + eff(18);
      fitText(sp.name, bcx, ty, r.w - 20, 18, '#fff1d6', 'center', 'bold');
      fitText('Ring ' + last.ring + ' · ' + last.age + (last.sex ? ' ' + last.sex : '') + (last.trap ? ' · from the trap' : ''), bcx, ty + lh(13), r.w - 20, 13, '#f0d8b0', 'center');
      y0 = ty + lh(13) + 12;
    }
    // the empty band holds the bag queue: the next birds waiting at the hut, drawn small, oldest first
    if (gm.bags.length && qy - y0 > lh(12) + 6 + qcell) {
      text('NEXT IN THE BAGS · ' + gm.bags.length, r.x + 12, y0 + eff(12), 12, C.lamp, 'left', 'bold');
      var rowsFit = Math.max(1, Math.min(qrows, Math.floor((qy - 8 - (y0 + eff(12) + 6)) / qcell))), n = Math.min(gm.bags.length, rowsFit * qcols);
      for (var k2 = 0; k2 < n; k2++) { var sp3 = ART.small(gm.bags[k2].sp, qart, '', k2 % 2 === 1); g.drawImage(sp3, r.x + 12 + (k2 % qcols) * qcell, y0 + eff(12) + 6 + Math.floor(k2 / qcols) * qcell); }
    }
  }
  function drawLadder(r) {
    var gm = state.game; panel(r.x, r.y, r.w, r.h);
    text('THE LADDER', r.x + 12, r.y + 22, 12, C.warm, 'left', 'bold');
    // three states that read apart: bought (a tick, or Read for the report), affordable (an amber price), not yet (grey)
    var step = function (u) {
      var done = !!gm.unlocked[u.id], needList = u.needs && Object.keys(gm.listed).length < u.needs, read = done && u.id === 'report';
      var why = done ? '' : needList ? 'The report needs ' + u.needs + ' species on the year list' : gm.money < u.cost ? 'Not enough money yet' : '';
      return { done: done, label: read ? 'Read' : done ? '✓ Bought' : '£' + u.cost, opts: { enabled: read || (!done && !why), why: why, col: done && !read ? C.good : !done && !why ? C.warn : null, on: read } };
    };
    if (shape === 'tall') {
      // the upright sheet: nine cards, three by three, each the step, what it gives and its button
      var gap = 8, top = r.y + 34, cw = (r.w - 24 - gap * 2) / 3, chh = (r.y + r.h - 10 - top - gap * 2) / 3, bh = Math.max(34, TAP_CSS / SCALE);
      SIM.UNLOCKS.forEach(function (u, k) {
        var s = step(u), x = r.x + 12 + (k % 3) * (cw + gap), y = top + Math.floor(k / 3) * (chh + gap), yy = y + 8;
        g.fillStyle = s.done ? 'rgba(169,222,138,0.08)' : 'rgba(255,255,255,0.05)'; roundRect(x, y, cw, chh, 6); g.fill();
        wrap(u.name, cw - 16, 13, 'bold').forEach(function (ln) { yy += lh(13); text(ln, x + 8, yy - eff(13) * 0.25, 13, s.done ? C.good : C.ink, 'left', 'bold'); });
        yy += 4; wrap(u.why, cw - 16, 12).forEach(function (ln) { yy += lh(12); text(ln, x + 8, yy - eff(12) * 0.25, 12, C.inkFaint); });
        button('buy_' + u.id, s.label, x + 8, y + chh - bh - 8, cw - 16, bh, s.opts);
      });
      return;
    }
    var rowH = (r.h - 36) / SIM.UNLOCKS.length;
    SIM.UNLOCKS.forEach(function (u, k) {
      var y = r.y + 32 + k * rowH, s = step(u), done = s.done;
      button('buy_' + u.id, s.label, r.x + r.w - 92, y + 4, 82, rowH - 10, s.opts);
      var nh = eff(13), gap = Math.max(4, (rowH - nh - eff(12)) / 3);
      fitText(u.name, r.x + 12, y + gap + nh * 0.8, r.w - 114, 13, done ? C.good : C.ink, 'left', 'bold');
      fitText(u.why, r.x + 12, y + gap * 2 + nh + eff(12) * 0.8, r.w - 114, 12, C.inkFaint);
    });
  }
  function drawList(r) {
    var gm = state.game; panel(r.x, r.y, r.w, r.h);
    if (gm.unlocked.moth) button('list_mode', state.listMode === 'moths' ? 'Birds' : 'Moths', r.x + r.w - 82, r.y + 6, 74, 24);
    if (gm.unlocked.moth && state.listMode === 'moths') { drawMoths(r); return; }
    var keys = SIM.SPECIES.filter(function (s) { return gm.listed[s.id]; });
    text('YEAR LIST · ' + keys.length + ' of ' + SIM.SPECIES.length, r.x + 12, r.y + 22, 12, C.warm, 'left', 'bold');
    tileGrid(r, SIM.SPECIES, state.listPage, 'list', 44, function (s, x, y, cw, ch, nameY, art) {
      var seen = !!gm.listed[s.id];
      g.fillStyle = seen ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.2)'; roundRect(x + 2, y, cw - 4, ch - 4, 5); g.fill();
      if (seen) { ART.bird(g, s.id, x + cw / 2, y + 6 + art / 2, Math.min(art, cw * 0.6), { sex: s.sexed ? 'male' : '' }); text(String(gm.ringedBy[s.id] || 0), x + cw - 8, y + 4 + eff(11), 11, C.inkFaint, 'right', 'bold'); nameBlock(s.name, x + cw / 2, nameY, cw - 10, 12, s.rare === 2 ? C.warn : C.inkDim); }
      else { pill(x + cw / 2, y + 6 + art / 2, 'not yet'); nameBlock(s.rare === 2 ? 'a rarity' : '?', x + cw / 2, nameY, cw - 10, 12, C.inkFaint); }
    }, function (s) { return s.name; });
  }
  /** a locked tile's mark: a small dark pill with a question mark, not a bare glyph */
  function pill(cx, cy, label) { var w = measure(label, 11, 'bold') + 14, h = eff(11) + 6; g.fillStyle = 'rgba(160,175,190,0.18)'; roundRect(cx - w / 2, cy - h / 2, w, h, h / 2); g.fill(); text(label, cx, cy + eff(11) * 0.36, 11, C.inkFaint, 'center', 'bold'); }
  /** a paged grid of tiles whose names wrap onto two lines at ONE size: the column count is chosen by measuring every
   *  name, the rows by the room left, and the page buttons appear only when the list does not fit */
  function tileGrid(r, items, page, id, artH, drawTile, nameOf) {
    // the grid starts under the header row, whose Birds / Moths button may have grown to the tap floor
    var names = items.map(nameOf), cols = gridCols(names, r.w - 16, 12, shape === 'tall' ? 4 : 3, 10);
    var ch = 6 + artH + 6 + 2 * lh(12) + 8, bh = Math.max(28, TAP_CSS / SCALE), top = r.y + Math.max(34, 22 + TAP_CSS / SCALE / 2);
    var rowsAll = Math.floor((r.y + r.h - 8 - top) / ch);
    // when the whole list fits on one page, use the fewest columns that still do it: bigger tiles, no empty band below
    if (Math.ceil(items.length / cols) <= rowsAll) for (var c2 = 2; c2 < cols; c2++) if (Math.ceil(items.length / c2) <= rowsAll) { cols = c2; break; }
    var cw = (r.w - 16) / cols, per = cols * rowsAll, pages = Math.ceil(items.length / per);
    if (pages > 1) { rowsAll = Math.floor((r.y + r.h - 8 - bh - 8 - top) / ch); per = cols * rowsAll; pages = Math.ceil(items.length / per); }
    var pg = Math.min(page, pages - 1); if (id === 'list') state.listPage = pg; else state.mothPage = pg;
    // the rows share the room that is left, so a short page has taller tiles, never a band of empty panel
    var avail = (pages > 1 ? r.y + r.h - 8 - bh - 8 : r.y + r.h - 8) - top, usedRows = Math.min(rowsAll, Math.ceil(items.length / cols));
    ch = Math.max(ch, Math.min(ch * 1.6, Math.floor(avail / Math.max(1, pages > 1 ? rowsAll : usedRows))));
    var art = ch - (6 + 6 + 2 * lh(12) + 8);
    items.slice(pg * per, pg * per + per).forEach(function (it, k) { var x = r.x + 8 + (k % cols) * cw, y = top + Math.floor(k / cols) * ch; drawTile(it, x, y, cw, ch, y + ch - 12, art); });
    if (pages > 1) {
      var py = r.y + r.h - bh - 6;
      button(id + '_prev', 'Prev', r.x + 8, py, 72, bh, { enabled: pg > 0 }); text('Page ' + (pg + 1) + ' of ' + pages, r.x + r.w / 2, py + bh / 2 + eff(12) * 0.36, 12, C.inkDim, 'center'); button(id + '_next', 'Next', r.x + r.w - 80, py, 72, bh, { enabled: pg < pages - 1 });
    }
  }
  function drawMoths(r) {
    var gm = state.game, got = SIM.MOTHS.filter(function (m) { return gm.moths[m.id]; }).length;
    text('THE NIGHT LIST · ' + got + ' of ' + SIM.MOTHS.length, r.x + 12, r.y + 22, 12, C.warm, 'left', 'bold');
    var mh = shape === 'tall' ? 90 : 52;
    tileGrid(r, SIM.MOTHS, state.mothPage, 'moth', mh, function (m, x, y, cw, ch, nameY, art) {
      var n = gm.moths[m.id] || 0;
      g.fillStyle = n ? 'rgba(232,222,196,0.12)' : 'rgba(0,0,0,0.2)'; roundRect(x + 2, y, cw - 4, ch - 4, 5); g.fill();
      if (n) { ART.moth(g, m.id, x + cw / 2, y + 6 + art / 2, Math.min(cw * 0.7, art * 1.3)); text(String(n), x + cw - 8, y + 4 + eff(11), 11, C.inkFaint, 'right', 'bold'); nameBlock(m.name, x + cw / 2, nameY, cw - 10, 12, C.inkDim); }
      else { pill(x + cw / 2, y + 6 + art / 2, 'not yet'); nameBlock('?', x + cw / 2, nameY, cw - 10, 12, C.inkFaint); }
    }, function (m) { return m.name; });
  }
  function drawLog(r) {
    var gm = state.game; panel(r.x, r.y, r.w, r.h);
    text('THE LOG', r.x + 12, r.y + 22, 12, C.warm, 'left', 'bold');
    // one size throughout: the time stamp is its own column and the entry wraps in the width that is left, so no line
    // ever has to shrink to fit; only whole entries are drawn, newest first, until the panel is full
    var stampW = measure('D40 18:50', 12, 'bold') + 10, tw = r.w - 24 - stampW, y = r.y + 22 + lh(12) + 6, bottom = r.y + r.h - 6, L2 = lh(12);
    for (var i = gm.log.length - 1; i >= 0; i--) {
      var e = gm.log[i], lns = wrap(e.text, tw, 12); if (y + (lns.length - 1) * L2 + eff(12) * 0.25 > bottom) break;
      var col = e.kind === 'bad' ? C.bad : e.kind === 'warn' ? C.warn : e.kind === 'good' ? C.good : C.inkDim;
      text('D' + e.day + ' ' + hhmm(e.min), r.x + 12, y, 12, C.inkFaint, 'left', 'bold');
      lns.forEach(function (ln, k) { text(ln, r.x + 12 + stampW, y + k * L2, 12, col); }); y += lns.length * L2 + 4;
    }
  }

  /* ------------------------------------------------------------------ the flyway map */
  // The coastlines are real geography (js/coast.js: degrees of longitude and latitude) on a Mercator projection. The view
  // always holds the whole flyway, every place a ring can be found from the Norwegian coast to the Senegal delta, with a
  // margin; a box of another shape shows more of the same coastline to the sides or above and below, never past what
  // coast.js carries, and the frame crops the rest. If a box is so wide that the flyway must be cropped, the view slides
  // so that the headland and every dot actually drawn stay inside the frame.
  var LANDS = COAST.land, SEAS = COAST.sea;
  var MAP_NEED = { lon0: -18.5, lon1: 18.6, lat0: 14.6, lat1: 61.2 }, MAP_DATA = { lon0: -42, lon1: 32, lat0: 12, lat1: 62.8 };
  function mercY(lat) { return -Math.log(Math.tan(Math.PI / 4 + lat * Math.PI / 360)) * 180 / Math.PI; }   // north is up: a smaller y
  function mapView(x0, y0, w0, h0, pts) {
    var nx0 = MAP_NEED.lon0, nx1 = MAP_NEED.lon1, ny0 = mercY(MAP_NEED.lat1), ny1 = mercY(MAP_NEED.lat0);
    var dx0 = MAP_DATA.lon0, dx1 = MAP_DATA.lon1, dy0 = mercY(MAP_DATA.lat1), dy1 = mercY(MAP_DATA.lat0);
    // fit the flyway inside the box, then zoom in only if the view would reach past the coastline data
    var s = Math.max(Math.min(w0 / (nx1 - nx0), h0 / (ny1 - ny0)), w0 / (dx1 - dx0), h0 / (dy1 - dy0));
    var vw = w0 / s, vh = h0 / s, cx = (nx0 + nx1) / 2, cy = (ny0 + ny1) / 2, m = 14 / s;
    var keep = function (c, lo, hi, half) { if (hi - lo + 2 * m <= 2 * half) { c = Math.max(c, hi + m - half); c = Math.min(c, lo - m + half); } return c; };
    if (pts.length) {
      var xs = pts.map(function (p) { return p[0]; }), ys = pts.map(function (p) { return mercY(p[1]); });
      cx = keep(cx, Math.min.apply(null, xs), Math.max.apply(null, xs), vw / 2); cy = keep(cy, Math.min.apply(null, ys), Math.max.apply(null, ys), vh / 2);
    }
    cx = Math.max(dx0 + vw / 2, Math.min(dx1 - vw / 2, cx)); cy = Math.max(dy0 + vh / 2, Math.min(dy1 - vh / 2, cy));
    return { s: s, ox: x0 + w0 / 2 - cx * s, oy: y0 + h0 / 2 - cy * s };
  }
  function drawFlyway(x0, y0, w0, h0, recs, labels) {
    var home = [SIM.HOME.lon, SIM.HOME.lat], rs = recs.filter(function (rc) { return num(rc.lon) && num(rc.lat); });
    var v = mapView(x0, y0, w0, h0, [home].concat(rs.map(function (rc) { return [rc.lon, rc.lat]; })));
    var X = function (lon) { return v.ox + lon * v.s; }, Y = function (lat) { return v.oy + mercY(lat) * v.s; };
    g.save(); g.beginPath(); g.rect(x0, y0, w0, h0); g.clip();
    g.fillStyle = '#a9c2c8'; g.fillRect(x0, y0, w0, h0);
    // the graticule, every ten degrees, on the sea
    g.fillStyle = 'rgba(255,255,255,0.16)';
    for (var lo = -60; lo <= 60; lo += 10) { var gx = Math.round(X(lo)); if (gx > x0 && gx < x0 + w0) g.fillRect(gx, y0, 1, h0); }
    for (var la = 0; la <= 80; la += 10) { var gy = Math.round(Y(la)); if (gy > y0 && gy < y0 + h0) g.fillRect(x0, gy, w0, 1); }
    var ring = function (pts) { g.beginPath(); for (var k = 0; k < pts.length; k++) { var px = X(pts[k][0]), py = Y(pts[k][1]); if (k) g.lineTo(px, py); else g.moveTo(px, py); } g.closePath(); };
    g.lineJoin = 'round'; g.lineWidth = 1; g.strokeStyle = '#7a6a4e';
    LANDS.forEach(function (l) { ring(l[1]); g.fillStyle = '#e6dcc0'; g.fill(); g.stroke(); });
    SEAS.forEach(function (l) { ring(l[1]); g.fillStyle = '#a9c2c8'; g.fill(); g.stroke(); });
    var hx = X(home[0]), hy = Y(home[1]);
    rs.forEach(function (rc, k) {
      var ex = X(rc.lon), ey = Y(rc.lat), mx = (hx + ex) / 2 + (ey - hy) * 0.12, my = (hy + ey) / 2 - (ex - hx) * 0.12;
      var latest = k === rs.length - 1; g.strokeStyle = latest ? 'rgba(160,40,30,0.95)' : 'rgba(160,40,30,0.38)'; g.lineWidth = latest ? 2.2 : 1; g.setLineDash([5, 3]); g.beginPath(); g.moveTo(hx, hy); g.quadraticCurveTo(mx, my, ex, ey); g.stroke(); g.setLineDash([]);
      g.fillStyle = latest ? '#a0281e' : 'rgba(160,40,30,0.6)'; g.beginPath(); g.arc(ex, ey, latest ? 4 : 2.5, 0, 6.3); g.fill();
    });
    g.fillStyle = '#1e5a3a'; g.beginPath(); g.arc(hx, hy, 5, 0, 6.3); g.fill(); g.strokeStyle = '#f6f0dc'; g.lineWidth = 2; g.stroke();
    g.restore();
    if (MAPREC) MAPREC.push({ x: x0, y: y0, w: w0, h: h0, home: [hx, hy], dots: rs.map(function (rc) { return [X(rc.lon), Y(rc.lat)]; }), screen: state.screen });
    // the latest recovery is named ON the map, beside its own dot, on a paper label kept inside the frame
    if (labels && rs.length) {
      var lastR = rs[rs.length - 1], lx = X(lastR.lon), ly = Y(lastR.lat), l1 = SIM.BY_ID[lastR.sp].name, l2 = lastR.place;
      var lw = Math.max(measure(l1, 12, 'bold'), measure(l2, 12)) + 12, lhh = lh(12) * 2 + 6;
      var bx = lx + 10 + lw <= x0 + w0 - 4 ? lx + 10 : lx - 10 - lw; bx = Math.max(x0 + 4, Math.min(bx, x0 + w0 - 4 - lw));
      var by = Math.max(y0 + 4, Math.min(ly - lhh / 2, y0 + h0 - 4 - lhh));
      g.fillStyle = 'rgba(246,240,220,0.94)'; roundRect(bx, by, lw, lhh, 4); g.fill(); g.strokeStyle = '#a0281e'; g.lineWidth = 1; roundRect(bx + 0.5, by + 0.5, lw - 1, lhh - 1, 4); g.stroke();
      text(l1, bx + 6, by + 3 + eff(12), 12, '#3a1e14', 'left', 'bold'); text(l2, bx + 6, by + 3 + eff(12) + lh(12), 12, '#5a3a24');
    }
    g.strokeStyle = '#5a4a36'; g.lineWidth = 1; g.strokeRect(x0 + 0.5, y0 + 0.5, w0 - 1, h0 - 1);
  }

  /* ------------------------------------------------------------------ the other screens */
  function backdrop() {
    var gr = g.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, '#1c2b3a'); gr.addColorStop(0.55, '#2f4658'); gr.addColorStop(1, '#8a6a4a'); g.fillStyle = gr; g.fillRect(0, 0, W, H);
    // the headland in silhouette with the lighthouse, and a skein of migrants
    g.fillStyle = '#16212b'; g.beginPath(); g.moveTo(0, H * 0.8); g.quadraticCurveTo(W * 0.35, H * 0.7, W * 0.62, H * 0.76); g.lineTo(W * 0.8, H * 0.8); g.lineTo(W, H * 0.86); g.lineTo(W, H); g.lineTo(0, H); g.closePath(); g.fill();
    var lx = W * (shape === 'tall' ? 0.86 : 0.7), ly = H * 0.62; g.fillStyle = '#16212b'; g.fillRect(lx - 8, ly, 16, H * 0.16); g.fillRect(lx - 11, ly - 10, 22, 12); g.fillStyle = C.lamp; g.fillRect(lx - 6, ly - 8, 12, 7);
    var t = clock(), a = t * 0.5, gr2 = g.createRadialGradient(lx, ly - 4, 2, lx, ly - 4, W * 0.6); gr2.addColorStop(0, 'rgba(255,230,160,0.4)'); gr2.addColorStop(1, 'rgba(255,230,160,0)');
    g.fillStyle = gr2; g.beginPath(); g.moveTo(lx, ly - 4); g.arc(lx, ly - 4, W * 0.6, Math.PI + 0.3 * Math.sin(a), Math.PI + 0.3 * Math.sin(a) + 0.18); g.closePath(); g.fill();
    g.strokeStyle = 'rgba(20,28,36,0.85)'; g.lineWidth = 1.6;
    for (var k = 0; k < 14; k++) { var bx = W * 0.15 + k * W * 0.035 + ((t * 18) % (W * 0.04)), by = H * 0.22 + Math.abs(k - 6) * 9 + Math.sin(t * 4 + k) * 2; g.beginPath(); g.moveTo(bx - 5, by - 2); g.quadraticCurveTo(bx - 2, by - 4, bx, by); g.quadraticCurveTo(bx + 2, by - 4, bx + 5, by - 2); g.stroke(); }
  }
  function drawTitle() {
    backdrop();
    var cx = W / 2, px = shape === 'tall' ? 7 : 9;
    display('FLYWAY', cx, H * 0.1, px, '#e8c27a', 'center', '#2a1c0e');
    var sub = 'A bird observatory on a migration headland';
    fitText(sub, cx, H * 0.1 + px * 9 + 30, W - 40, 18, C.ink, 'center');
    // three birds on a wire as the title's figure
    var wy = H * 0.47 + (shape === 'wide' ? 24 : 20); g.strokeStyle = '#0d141b'; g.lineWidth = 2; g.beginPath(); g.moveTo(0, wy - 6); g.quadraticCurveTo(W / 2, wy + 10, W, wy - 6); g.stroke();
    // each bird is placed on the wire where it sits: the wire's height at that x, less the bird's own foot depth
    var wireAt = function (x) { var t = x / W; return wy - 6 + 32 * t * (1 - t); }, FEET = 0.21, dx = shape === 'wide' ? 150 : 110;
    [['robin', -dx, shape === 'wide' ? 110 : 90, {}], ['goldcrest', 0, shape === 'wide' ? 96 : 80, { sex: 'male' }], ['bluethroat', dx, shape === 'wide' ? 110 : 90, { sex: 'male' }]].forEach(function (b) {
      ART.bird(g, b[0], cx + b[1], wireAt(cx + b[1]) - FEET * b[2], b[2], b[3]);
    });
    var has = !!load(), bw = shape === 'tall' ? 240 : 220, bh = Math.max(36, TAP_CSS / SCALE), gap = bh + 8, by = H * 0.62;
    if (has) button('continue', 'Continue the season', cx - bw / 2, by, bw, bh, { px: 15 });
    button('new', has && state.confirmNew > Date.now() ? 'Start over? Press again' : 'New observatory', cx - bw / 2, by + (has ? gap : 0), bw, bh, { px: 15 });
    button('help_title', 'How it works', cx - bw / 2, by + (has ? gap * 2 : gap), bw, bh);
    button('credits', 'Credits', cx - bw / 2, by + (has ? gap * 3 : gap * 2), bw, bh);
    button('sound', AUDIO.isMuted() ? 'Sound: off' : 'Sound: on', W - 122, H - 12 - bh, 110, bh);
  }
  var HELP = [
    'Each dawn brings a wind and a sky. On a clear night the migrants fly over and the headland is quiet. An onshore wind (from the sea: north-east, east, south-east) with rain at dawn puts them down: a FALL, and every bush is full.',
    'Birds land in cover: scrub, reeds, the walled garden. Set NETS on open ground beside cover (tap a cell with the Nets tool); tap a net to open or close it. Plant more cover on grass and it grows over the days.',
    'Your ringers walk net rounds and ring at the hut. A bird must never wait: ' + SIM.NET_LIMIT + ' minutes in a net, or ' + SIM.BAG_LIMIT + ' in a bag, and it is let go unringed, which members hear about. On a fall, close nets until the hands can keep up.',
    'Every bird is ringed and released. A few rings are found again down the flyway: each draws a line on the Map. Rings, rarities and recoveries bring members and visitors, and that buys the ladder: nine steps to the annual report.',
    'Keys: arrows move the cursor, Enter uses the tool, 1 nets, 2 plant, 3 take down, Space pauses, + and - change speed, M sound, H this help.',
  ];
  function drawHelp() {
    g.fillStyle = 'rgba(8,12,18,0.86)'; g.fillRect(0, 0, W, H);
    var bw = Math.min(W - 24, 720), bx = (W - bw) / 2, by = 16, bh = H - 32; panel(bx, by, bw, bh, '#1b2734');
    text('HOW THE OBSERVATORY WORKS', bx + 18, by + 30, 15, C.warm, 'left', 'bold');
    var bbh = Math.max(36, TAP_CSS / SCALE), foot = by + bh - bbh - 12;
    // three small pictures made with the game's own art, then the five paragraphs in the room that is left
    var pad = 18, px = shape === 'wide' ? 13 : 12, paras = HELP.map(function (p) { return wrap(p, bw - 2 * pad, px); });
    var textH = paras.reduce(function (a, ls) { return a + ls.length * lh(px) + 6; }, 0), picTop = by + 30 + 12, picH = Math.min(shape === 'tall' ? 220 : 140, foot - 8 - textH - picTop - 10);
    var y = picTop;
    if (picH >= 56) { helpPictures(bx + pad, y, bw - 2 * pad, picH); y += picH + 10; }
    // the room left over is shared between the paragraphs, so the panel never ends in a band of nothing
    var spare = Math.max(0, foot - 8 - y - textH), gap = 6 + Math.min(28, spare / paras.length);
    paras.forEach(function (ls) { ls.forEach(function (ln) { y += lh(px); text(ln, bx + pad, y - eff(px) * 0.25, px, C.ink); }); y += gap; });
    button('help_close', state.helpFrom === 'title' ? 'Back' : 'Back to the headland', bx + bw / 2 - 120, foot, 240, bbh);
  }
  function helpPictures(x, y, w, h) {
    var n = 3, gap = 10, pw = (w - gap * (n - 1)) / n;
    for (var k = 0; k < n; k++) {
      var px0 = x + k * (pw + gap); g.fillStyle = '#26384a'; roundRect(px0, y, pw, h, 6); g.fill();
      if (k === 0) { var cs = Math.min(h - 10, pw / 2.4), cx = px0 + (pw - cs * 2) / 2, cy = y + (h - cs) / 2, r2 = SIM.rng(7); g.fillStyle = PLATES.grass || C.grass; g.fillRect(cx, cy, cs * 2, cs); bush(g, cx + cs * 0.5, cy + cs * 0.55, cs * 0.3, r2); netArt({ x: cx + cs, y: cy, w: cs, h: cs }, true, -1); var sp = ART.small('robin', Math.round(cs * 0.5), '', false); g.drawImage(sp, cx + cs * 0.1, cy + cs * 0.05); }
      else if (k === 1) { var bx2 = px0 + 12, bw2 = pw - 24; [['#a9de8a', 0.3], ['#ffd36a', 0.6], ['#ff8f72', 0.92]].forEach(function (c, q) { var yy = y + h / 2 - 22 + q * 18; g.fillStyle = '#0f1720'; roundRect(bx2, yy, bw2, 10, 3); g.fill(); g.fillStyle = c[0]; roundRect(bx2, yy, bw2 * c[1], 10, 3); g.fill(); }); }
      else { g.fillStyle = '#d8cfb8'; roundRect(px0 + 4, y + 4, pw - 8, h - 8, 4); g.fill(); var hx = px0 + pw * 0.62, hy = y + h * 0.3, ex = px0 + pw * 0.22, ey = y + h * 0.82; g.strokeStyle = 'rgba(160,40,30,0.95)'; g.lineWidth = 2; g.setLineDash([5, 3]); g.beginPath(); g.moveTo(hx, hy); g.quadraticCurveTo((hx + ex) / 2 + 20, (hy + ey) / 2, ex, ey); g.stroke(); g.setLineDash([]); g.fillStyle = '#1e5a3a'; g.beginPath(); g.arc(hx, hy, 5, 0, 6.3); g.fill(); g.fillStyle = '#a0281e'; g.beginPath(); g.arc(ex, ey, 4, 0, 6.3); g.fill(); }
    }
  }
  function drawCredits() {
    backdrop(); var bw = Math.min(W - 24, 600), bx = (W - bw) / 2, bbh = Math.max(34, TAP_CSS / SCALE);
    var paras = ['A free browser game by Core Systems Asset Factory.', 'Code, graphics and text were made with AI assistance; the music was composed as note data and synthesised in code, with no AI audio. Every bird and moth is drawn by the game from a parameter row.', 'Type: Alegreya Sans, SIL Open Font License (fonts/OFL-AlegreyaSans.txt).', 'Bird ringing is licensed work done under a ringing scheme by trained ringers. The welfare rule in the game is the real one: no bird waits.'];
    var lines = paras.map(function (p) { return wrap(p, bw - 48, 14); }), textH = lines.reduce(function (a, l) { return a + l.length * lh(14) + 10; }, 0);
    var ph = 36 + 40 + textH + bbh + 30, py = Math.max(12, (H - ph) / 2);
    // an opaque card: the backdrop never shows through the words
    panel(bx, py, bw, ph, '#16212c');
    display('FLYWAY', W / 2, py + 22, 4, '#e8c27a', 'center', '#2a1c0e');
    var y = py + 22 + 36 + 16; lines.forEach(function (ls) { ls.forEach(function (ln) { y += lh(14); text(ln, W / 2, y - eff(14) * 0.25, 14, C.ink, 'center'); }); y += 10; });
    button('credits_back', 'Back', W / 2 - 70, py + ph - bbh - 16, 140, bbh);
  }
  function drawSeasonEnd() {
    var gm = state.game, sm = gm.summary, tl = shape === 'tall';
    // upright: the figures, then the map under them; wide and short: the figures in a column, the map beside them at a
    // shape that holds the whole flyway
    backdrop(); var bw = Math.min(W - 40, tl ? 640 : 880), bx = (W - bw) / 2, by = tl ? 30 : 20, bh = H - 2 * by; panel(bx, by, bw, bh, 'rgba(22,33,44,0.94)');
    var colX = bx + 30, colW = tl ? bw - 60 : Math.round(bw * 0.4), inset = tl ? 10 : 0, bbh = Math.max(36, TAP_CSS / SCALE), fy = by + bh - bbh - 14;
    display('AUTUMN ' + sm.year, colX + colW / 2, by + 20, 4, '#e8c27a', 'center', '#2a1c0e');
    var rows = [['Birds ringed', sm.ringed], ['Species on the year list', sm.species + ' of ' + SIM.SPECIES.length], ['Falls', sm.falls], ['Rings found again (all years)', gm.recoveries.length], ['Let go unringed', sm.early], ['Members', gm.members]];
    var rh = Math.max(26, lh(15)), ry = by + 92; rows.forEach(function (r, k) { var y = ry + k * rh; text(r[0], colX + inset, y, 15, C.inkDim); text(String(r[1]), colX + colW - inset, y, 15, r[0] === 'Let go unringed' && r[1] > 0 ? C.bad : C.ink, 'right', 'bold'); });
    if (tl) {
      var my = ry + rows.length * rh, mh = fy - 10 - my;
      drawFlyway(colX, my, colW, mh, gm.recoveries, false);
      if (gm.unlocked.report) { button('season_report', 'The report', W / 2 - 210, fy, 200, bbh, { px: 15 }); button('next', 'Next autumn', W / 2 + 10, fy, 200, bbh, { px: 15 }); }
      else button('next', 'Next autumn', W / 2 - 100, fy, 200, bbh, { px: 15 });
      return;
    }
    button('next', 'Next autumn', colX, fy, colW, bbh, { px: 15 });
    var top2 = fy - 12; if (gm.unlocked.report) { button('season_report', 'The report', colX, fy - bbh - 8, colW, bbh, { px: 15 }); top2 -= bbh + 8; }
    // the latest ring found again, in words, in the room between the figures and the buttons
    var lr = gm.recoveries[gm.recoveries.length - 1], y2 = ry + rows.length * rh + 10;
    if (lr && SIM.BY_ID[lr.sp]) {
      var words = wrap(SIM.BY_ID[lr.sp].name + ' ' + lr.ring + ', found at ' + lr.place + ', ' + Number(lr.km || 0).toLocaleString('en-GB') + ' km and ' + lr.days + ' days after it was ringed.', colW, 13);
      if (y2 + lh(12) + words.length * lh(13) <= top2) { text('THE LATEST RING FOUND AGAIN', colX, y2 + eff(12), 12, C.warm, 'left', 'bold'); words.forEach(function (ln, k) { text(ln, colX, y2 + eff(12) + lh(12) + 4 + k * lh(13), 13, C.inkDim); }); }
    }
    var mx = colX + colW + 24; drawFlyway(mx, by + 20, bx + bw - 20 - mx, bh - 40, gm.recoveries, false);
  }
  function drawReport() {
    var gm = state.game;
    g.fillStyle = '#efe6cf'; g.fillRect(0, 0, W, H);
    var head = shape === 'wide' ? 140 : shape === 'short' ? 112 : 170; g.fillStyle = '#1e3a2e'; g.fillRect(0, 0, W, head);
    display('FLYWAY', 24, 20, shape === 'wide' ? 6 : 5, '#e8c27a', 'left', '#0a1a12');
    var subW = W - 24 - (shape === 'wide' ? 240 : shape === 'short' ? 160 : 150), sub = wrap('Annual report, autumn ' + gm.year + ' · ' + Object.keys(gm.listed).length + ' species · ' + gm.ringed + ' birds ringed in all · ' + gm.recoveries.length + ' recoveries', subW, 14, 'bold');
    sub.forEach(function (ln, k) { text(ln, 24, (shape === 'wide' ? 116 : shape === 'short' ? 94 : 96) + k * lh(14), 14, '#f0e6cf', 'left', 'bold'); });
    // the cover bird: the year's rarest
    var rarest = SIM.SPECIES.filter(function (s) { return gm.listed[s.id]; }).sort(function (a, b) { return b.rare - a.rare || a.ab - b.ab; })[0];
    if (rarest) ART.bird(g, rarest.id, W - (shape === 'wide' ? 120 : 80), shape === 'wide' ? 70 : shape === 'short' ? 52 : 130, shape === 'wide' ? 150 : shape === 'short' ? 92 : 110, { sex: rarest.sexed ? 'male' : '' });
    // the list, bird by bird (a small bird and its name on at most two lines, one size for the whole grid), and the map
    var seen = SIM.SPECIES.filter(function (s) { return gm.listed[s.id]; }), tl = shape === 'tall', bbh = Math.max(36, TAP_CSS / SCALE), foot = H - bbh - 10;
    var listW = tl ? W - 24 : Math.round(W * 0.62), top = head + 10, bird = 30, px = 12;
    var cols = gridCols(seen.map(function (s) { return s.name; }), listW, px, tl ? 4 : 6, bird + 8), cw = listW / cols, ch = Math.max(bird + 4, 2 * lh(px) + 4);
    var rows = Math.max(1, Math.floor((foot - 8 - top) / ch)), per = rows * cols, listPages = Math.max(1, Math.ceil(seen.length / per));
    // a list that fits on one page shares the height it has between its rows (up to half as tall again)
    if (listPages === 1) ch = Math.max(ch, Math.min(ch * 1.5, Math.floor((foot - 8 - top) / Math.max(1, Math.ceil(seen.length / cols)))));
    // on the upright phone the map is a page of its own after the list, at the full height of the sheet
    var pages = listPages + (tl ? 1 : 0); if (state.reportPage >= pages) state.reportPage = 0;
    var mapPage = tl && state.reportPage === pages - 1;
    if (!mapPage) seen.slice(state.reportPage * per, state.reportPage * per + per).forEach(function (s, k) {
      var x = 12 + (k % cols) * cw, y = top + Math.floor(k / cols) * ch, ls = wrap(s.name, cw - bird - 8, px);
      ART.bird(g, s.id, x + bird / 2 + 2, y + ch / 2, bird, { sex: s.sexed ? 'male' : '' });
      var ty = y + ch / 2 - (ls.length - 1) * lh(px) / 2 + eff(px) * 0.35; ls.forEach(function (ln, q) { text(ln, x + bird + 6, ty + q * lh(px), px, '#3a2e22'); });
    });
    if (mapPage) drawFlyway(12, top, W - 24, foot - 8 - top, gm.recoveries, false);
    else if (!tl) drawFlyway(12 + listW + 8, top, W - (12 + listW + 8) - 12, foot - 8 - top, gm.recoveries, false);
    if (pages > 1) {
      button('report_prev', mapPage ? 'List' : 'Prev', 12, foot, 80, bbh, { enabled: state.reportPage > 0 });
      button('report_next', tl && state.reportPage === pages - 2 ? 'Map' : 'Next', W - 92, foot, 80, bbh, { enabled: state.reportPage < pages - 1 });
    }
    button('report_close', 'Back to the headland', W / 2 - 120, foot, 240, bbh, { px: 15 });
  }

  function drawToasts() {
    var now = Date.now(); state.toast = state.toast.filter(function (t) { return t.until > now; });
    // toasts hang from the top of the map, over the sea and the field: never over a control
    var m = boardShown() ? L().map : L().side, y = m.y + 8;
    state.toast.forEach(function (t) {
      var ls = wrap(t.msg, m.w - 40, 13), w = Math.min(m.w - 16, widest(ls, 13) + 28), x = m.x + (m.w - w) / 2, h = ls.length * lh(13) + 10;
      g.fillStyle = 'rgba(10,14,20,0.92)'; roundRect(x, y, w, h, 6); g.fill(); g.strokeStyle = t.kind === 'bad' ? C.bad : t.kind === 'good' ? C.good : C.panelEdge; g.lineWidth = 1; roundRect(x + 0.5, y + 0.5, w - 1, h - 1, 6); g.stroke();
      cover(x, y, w, h); ls.forEach(function (ln, q) { text(ln, m.x + m.w / 2, y + 5 + eff(13) * 0.85 + q * lh(13), 13, C.ink, 'center'); }); y += h + 6;
    });
  }

  function render() {
    BTN = [];
    g.setTransform(DPR, 0, 0, DPR, 0, 0);
    g.fillStyle = C.night; g.fillRect(0, 0, W, H);
    if (state.screen === 'title') drawTitle();
    else if (state.screen === 'credits') drawCredits();
    else if (state.screen === 'season') drawSeasonEnd();
    else if (state.screen === 'report') drawReport();
    else {
      // the coach belongs to the first morning only
      if (state.coach && state.game && (state.game.day > 1 || state.game.year > 1)) endCoach();
      drawTop();
      if (boardShown()) { drawMap(); drawStrip(); }
      drawSide();
      if (boardShown()) { coachMark(); if (state.coach && shape === 'tall') drawCoachTall(); }
    }
    if (state.help) { BTN = []; if (REC) REC.length = 0; if (MAPREC) MAPREC.length = 0; backdrop(); drawHelp(); }   // the help covers the screen: nothing under it is drawn as live text
    if (state.screen === 'play' && !state.help) drawToasts();   // a toast belongs to the headland: never over a result screen or its buttons
  }

  /* ------------------------------------------------------------------ actions */
  function act(fn, okSound) { var no = fn(); if (no) { toast(no.charAt(0).toUpperCase() + no.slice(1) + '.', 'bad'); AUDIO.play('no'); } else { if (okSound) AUDIO.play(okSound); BOARD = null; save(); } return !no; }
  function useTool(i) {
    var gm = state.game; if (!gm || gm.phase !== 'season') return;
    var c = gm.cells[i]; if (!c) return;
    state.sel = i;
    if (state.tool === 'net') { if (c.net) act(function () { return SIM.toggleNet(gm, i); }, c.open ? 'furl' : 'open'); else act(function () { return SIM.setNet(gm, i); }, 'net'); }
    else if (state.tool === 'plant') act(function () { return SIM.plant(gm, i); }, 'plant');
    else if (state.tool === 'down') {
      if (!c.net) { toast('No net here to take down.', 'bad'); AUDIO.play('no'); return; }
      if (state.confirmDown !== i || Date.now() > state.confirmUntil) { state.confirmDown = i; state.confirmUntil = Date.now() + 2500; toast('Take this net down? Choose it again.', 'info'); return; }
      state.confirmDown = -1; act(function () { return SIM.takeDownNet(gm, i); }, 'furl');
    }
  }
  function press(id) {
    var gm = state.game;
    AUDIO.unlock();
    if (id === 'new') {
      if (load() && state.confirmNew < Date.now()) { state.confirmNew = Date.now() + 3000; return; }
      clearSave(); state.game = SIM.newGame(Math.floor(Date.now() % 1e6) + 1); state.screen = 'play'; state.tab = shape === 'tall' ? 'board' : 'table'; BOARD = null; hear(state.game);
      // the first New on this browser starts paused, with the three-step coach; the clock waits for "Start the day"
      if (!coached()) { state.coach = 1; state.paused = true; } else state.paused = false;
      save(); AUDIO.play('chime'); return;
    }
    if (id === 'continue') { state.game = load(); if (!state.game) { toast('That save could not be read: a new observatory instead.', 'bad'); state.game = SIM.newGame(1); } state.screen = state.game.phase === 'over' ? 'season' : 'play'; if (shape === 'tall') state.tab = 'board'; BOARD = null; hear(state.game); AUDIO.play('chime'); return; }
    if (id === 'coach_next') { if (state.coach >= COACH.length) endCoach(); else state.coach++; AUDIO.play('tick'); return; }
    if (id === 'coach_skip') { endCoach(); AUDIO.play('tick'); return; }
    if (id === 'help_title' || id === 'help') { state.help = true; state.helpFrom = state.screen === 'title' ? 'title' : 'play'; AUDIO.play('tick'); return; }
    if (id === 'help_close') { state.help = false; AUDIO.play('tick'); return; }
    if (id === 'credits') { state.screen = 'credits'; AUDIO.play('tick'); return; }
    if (id === 'credits_back') { state.screen = 'title'; AUDIO.play('tick'); return; }
    if (id === 'sound') { AUDIO.toggle(); return; }
    if (id === 'speed') { state.speed = state.speed === 1 ? 3 : state.speed === 3 ? 8 : 1; AUDIO.play('tick'); return; }
    if (id === 'pause') { if (state.coach) endCoach(); else state.paused = !state.paused; AUDIO.play('tick'); return; }
    if (id.indexOf('tab_') === 0) { if (state.coach && !(shape === 'tall' && id === 'tab_board')) endCoach(); state.tab = id.slice(4); AUDIO.play('tick'); return; }
    if (id.indexOf('tool_') === 0) { state.tool = id.slice(5); AUDIO.play('tick'); return; }
    if (id.indexOf('round_') === 0) { act(function () { return SIM.setRound(gm, Number(id.slice(6))); }, 'tick'); return; }
    if (id.indexOf('buy_') === 0) {
      var u = id.slice(4);
      if (u === 'report' && gm.unlocked.report) { state.reportPage = 0; state.screen = 'report'; AUDIO.play('tick'); return; }   // bought: the row reads Read
      if (act(function () { return SIM.buy(gm, u); }, 'buy') && u === 'report') { state.reportPage = 0; state.screen = 'report'; AUDIO.play('fanfare'); }
      return;
    }
    if (id === 'season_report') { state.reportPage = 0; state.screen = 'report'; AUDIO.play('tick'); return; }
    if (id === 'list_mode') { state.listMode = state.listMode === 'moths' ? 'birds' : 'moths'; AUDIO.play('tick'); return; }
    if (id === 'list_prev') { state.listPage = Math.max(0, state.listPage - 1); return; }
    if (id === 'list_next') { state.listPage++; return; }
    if (id === 'moth_prev') { state.mothPage = Math.max(0, state.mothPage - 1); return; }
    if (id === 'moth_next') { state.mothPage++; return; }
    if (id === 'report_prev') { state.reportPage = Math.max(0, state.reportPage - 1); return; }
    if (id === 'report_next') { state.reportPage++; return; }
    if (id === 'next') { act(function () { return SIM.nextSeason(gm); }, 'chime'); hear(gm); state.screen = 'play'; if (shape === 'tall') state.tab = 'board'; return; }
    if (id === 'report_close') { state.screen = gm.phase === 'over' ? 'season' : 'play'; return; }
  }
  function endCoach() { if (state.coach) { state.coach = 0; state.paused = false; setCoached(); } }

  /* ------------------------------------------------------------------ input */
  function toLogical(ev) { var r = cv.getBoundingClientRect(); var s = r.width / W; return { x: (ev.clientX - r.left) / s, y: (ev.clientY - r.top) / s }; }
  function hit(p) { for (var i = BTN.length - 1; i >= 0; i--) { var b = BTN[i]; if (p.x >= b.x && p.x <= b.x + b.w && p.y >= b.y && p.y <= b.y + b.h) return b; } return null; }
  var lastDown = 0;
  cv.addEventListener('pointerdown', function (ev) {
    try { window.focus(); } catch (e) { /* cross-origin */ } try { cv.focus({ preventScroll: true }); } catch (e) { /* old engine */ }
    ev.preventDefault();
    var now = performance.now(); if (now - lastDown < 40) return; lastDown = now;
    AUDIO.unlock(); render();
    var p = toLogical(ev), b = hit(p);
    if (b) { if (b.enabled) press(b.id); else { AUDIO.play('no'); if (b.why) toast(b.why + '.', 'bad'); } render(); return; }
    if (state.screen !== 'play' || state.help) return;
    var i = cellAt(p.x, p.y); if (i >= 0) { state.cursor = -1; useTool(i); }
  });
  cv.addEventListener('pointermove', function (ev) { if (state.screen !== 'play') return; var p = toLogical(ev); state.hover = cellAt(p.x, p.y); });
  cv.addEventListener('pointerleave', function () { state.hover = -1; });
  window.addEventListener('keydown', function (ev) {
    var k = ev.key; AUDIO.unlock();
    if (k === 'm' || k === 'M') { press('sound'); return; }
    if (state.help) { if (k === 'Escape' || k === 'h' || k === 'H' || k === 'Enter') { state.help = false; ev.preventDefault(); } return; }
    if (state.screen === 'title') { if (k === 'Enter') { press(load() ? 'continue' : 'new'); ev.preventDefault(); } else if (k === 'h' || k === 'H') press('help_title'); return; }
    if (state.screen === 'credits' && (k === 'Escape' || k === 'Enter')) { press('credits_back'); return; }
    if (state.screen === 'season' && (k === 'n' || k === 'N' || k === 'Enter')) { press('next'); ev.preventDefault(); return; }
    if (state.screen === 'report' && (k === 'Enter' || k === 'Escape')) { press('report_close'); return; }
    if (state.screen !== 'play') return;
    if (k === '1') { state.tool = 'net'; return; } if (k === '2') { state.tool = 'plant'; return; } if (k === '3') { state.tool = 'down'; return; }
    if (k === 'h' || k === 'H') { state.help = true; return; }
    if (state.coach && k === 'Enter') { press('coach_next'); ev.preventDefault(); return; }
    if (k === ' ') { if (state.coach) endCoach(); else state.paused = !state.paused; ev.preventDefault(); return; }
    if (k === '+' || k === '=') { state.speed = state.speed === 1 ? 3 : 8; if (!state.coach) state.paused = false; return; }
    if (k === '-' || k === '_') { state.speed = state.speed === 8 ? 3 : 1; return; }
    if (k.indexOf('Arrow') === 0) {
      ev.preventDefault(); if (state.cursor < 0) state.cursor = 5 * SIM.COLS + 8;
      var x = state.cursor % SIM.COLS, y = Math.floor(state.cursor / SIM.COLS), dx = 0, dy = 0;
      if (k === 'ArrowLeft') dx = -1; if (k === 'ArrowRight') dx = 1; if (k === 'ArrowUp') dy = -1; if (k === 'ArrowDown') dy = 1;
      // on the upright phone the board is turned a quarter: screen-up is east, screen-right is south
      if (rot()) { var t0 = dx; dx = -dy; dy = t0; }
      x = Math.max(0, Math.min(SIM.COLS - 1, x + dx)); y = Math.max(0, Math.min(SIM.ROWS - 1, y + dy));
      state.cursor = y * SIM.COLS + x; return;
    }
    if (k === 'Enter' && state.cursor >= 0) { ev.preventDefault(); useTool(state.cursor); }
    if (k === 'Escape') state.cursor = -1;
  });

  /* ------------------------------------------------------------------ shape and size */
  function fit() {
    var vw = (window.visualViewport && window.visualViewport.width) || window.innerWidth, vh = (window.visualViewport && window.visualViewport.height) || window.innerHeight;
    var want = vw / vh < 0.9 ? 'tall' : vh < 520 ? 'short' : 'wide';
    if (want !== shape) { shape = want; W = SHAPES[shape].W; H = SHAPES[shape].H; BOARD = null; }
    var dpr = Math.min(2, window.devicePixelRatio || 1); if (dpr !== DPR) { DPR = dpr; BOARD = null; }
    if (cv.width !== W * DPR || cv.height !== H * DPR) { cv.width = W * DPR; cv.height = H * DPR; }
    document.documentElement.style.setProperty('--ar', String(W / H));
    var rc = cv.getBoundingClientRect(); if (rc.width > 0) SCALE = rc.width / W;   // the live scale the two floors convert with
  }
  window.addEventListener('resize', fit); if (window.visualViewport) window.visualViewport.addEventListener('resize', fit);

  /* ------------------------------------------------------------------ the loop: the game's own clock */
  var MIN_MS = 50;   // ten game minutes take half a second at 1x: a day is about 40 seconds
  // what the player has already been told about: compared with LIFETIME counts (gm.ringed never resets between
  // autumns), and set from the game itself whenever a game is started, continued or handed in
  var heard = { seq: 0, ring: 0, rec: 0 };
  function hear(gm) { heard = { seq: gm.log.length ? gm.log[gm.log.length - 1].seq : 0, ring: gm.ringed, rec: gm.recoveries.length }; }
  function advance(minutes) {
    var gm = state.game; if (!gm || gm.phase !== 'season') return;
    var d0 = gm.day, y0 = gm.year;
    SIM.step(gm, minutes);
    if (gm.day !== d0 || gm.year !== y0) { save(); AUDIO.play('dawn'); }
    if (gm.ringed > heard.ring) { AUDIO.play('ring'); heard.ring = gm.ringed; }
    if (gm.recoveries.length > heard.rec) { AUDIO.play('recovery'); heard.rec = gm.recoveries.length; toast('A ring has been found again: see the Map.', 'good'); }
    for (var i = gm.log.length - 1; i >= 0 && gm.log[i].seq > heard.seq; i--) if (gm.log[i].kind === 'bad') { AUDIO.play('bad'); break; }
    if (gm.log.length) heard.seq = gm.log[gm.log.length - 1].seq;
    if (gm.phase === 'over') { state.screen = 'season'; AUDIO.play('fanfare'); save(); }
  }
  var lastT = 0, acc = 0;
  function frame(t) {
    var dt = lastT ? Math.min(250, t - lastT) : 0; lastT = t;
    fit();
    if (state.screen === 'play' && !state.paused && !state.help && state.game && !FROZEN) { acc += dt * state.speed; var steps = Math.floor(acc / MIN_MS / SIM.STEP); if (steps > 0) { acc -= steps * MIN_MS * SIM.STEP; advance(steps * SIM.STEP); } }
    if (Date.now() - state.lastSaveReal > 5000 && state.game) save();
    render();
    requestAnimationFrame(frame);
  }
  var FROZEN = false;
  fit(); render(); requestAnimationFrame(frame);

  /* ------------------------------------------------------------------ a small read and drive interface for tools that inspect the page */
  window.FLYWAY = {
    shape: function () { return { name: shape, W: W, H: H }; },
    render: function () { render(); return BTN.length; },
    findButton: function (id) { render(); for (var i = 0; i < BTN.length; i++) if (BTN[i].id === id) return Object.assign({}, BTN[i]); return null; },
    buttons: function () { render(); return BTN.map(function (b) { return Object.assign({}, b); }); },
    cellRect: cellRect,
    advance: function (m) { advance(m || SIM.STEP); render(); },
    state: function () { return state; },
    game: function () { return state.game; },
    setGame: function (gm) { state.game = gm; BOARD = null; hear(gm); },
    freeze: function (f) { FROZEN = !!f; },
    record: function (on) { REC = on ? [] : null; MAPREC = on ? [] : null; return REC; },
    recorded: function () { return REC ? REC.slice() : null; },
    mapsDrawn: function () { return MAPREC ? MAPREC.slice() : null; },
    setScreen: function (s) { state.screen = s; render(); },
    setTab: function (t) { state.tab = t; render(); },
    save: save, load: load,
  };
}());
