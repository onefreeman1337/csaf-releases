/**
 * audio.js - FLYWAY's sound: effects synthesised live with WebAudio, a sea-and-wind bed under the headland, and one
 * composed music loop (audio/flyway_theme.ogg). Effects: a tick for a tab, a mist-net run out and staked, a net opened
 * and furled, a spade for planting, a ring closed with pliers and a bird's call as it is let go, a postcard bell for a
 * recovery, coins, a chime, a dawn cue, a low warning for a bird let go unringed and a fanfare for the season and the
 * report. Muting is remembered and PAUSES the music (iPhone Safari ignores a media element's volume).
 */
'use strict';

var AUDIO = (function () {
  var ctx = null, master = null, muted = false, noiseBuf = null, BUS = 1.6, MUSIC_VOL = 0.26, bed = null;
  try { muted = localStorage.getItem('flyway.muted') === '1'; } catch (e) { /* storage blocked */ }
  var music = null;
  function playMusic() {
    if (!music || muted || document.hidden || !music.paused) return;
    var pr = music.play(); if (pr && pr.catch) pr.catch(function () { /* autoplay refused: the next tap retries */ });
  }
  function startMusic() {
    if (music) { playMusic(); return; }
    try { music = new Audio('audio/flyway_theme.ogg'); music.loop = true; music.volume = MUSIC_VOL; playMusic(); } catch (e) { music = null; }
  }
  function duck(sec) { if (!music) return; music.volume = 0.1; setTimeout(function () { if (music) music.volume = MUSIC_VOL; }, sec * 1000); }
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) { if (music) music.pause(); if (ctx && ctx.state === 'running') ctx.suspend(); }
    else { playMusic(); if (ctx && ctx.state === 'suspended') ctx.resume(); }
  });
  function unlock() {
    startMusic();
    if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    try {
      ctx = new AC();
      master = ctx.createGain(); master.gain.value = muted ? 0 : BUS; master.connect(ctx.destination);
      noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
      var d = noiseBuf.getChannelData(0), s = 4471;
      for (var i = 0; i < d.length; i++) { s = (s * 1103515245 + 12345) & 0x7fffffff; d[i] = (s / 0x7fffffff) * 2 - 1; }
      seaBed();
    } catch (e) { ctx = null; }
  }
  function tone(freq, dur, type, vol, slide, delay) {
    if (!ctx || muted) return;
    var t = ctx.currentTime + (delay || 0);
    var o = ctx.createOscillator(), gn = ctx.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(freq, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, freq * slide), t + dur);
    gn.gain.setValueAtTime(0.0001, t); gn.gain.exponentialRampToValueAtTime(vol || 0.2, t + 0.01); gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(gn); gn.connect(master); o.start(t); o.stop(t + dur + 0.02);
  }
  function noise(dur, freq, q, vol, sweep, delay, type) {
    if (!ctx || muted || !noiseBuf) return;
    var t = ctx.currentTime + (delay || 0);
    var src = ctx.createBufferSource(); src.buffer = noiseBuf;
    var f = ctx.createBiquadFilter(); f.type = type || 'bandpass'; f.frequency.setValueAtTime(freq, t); f.Q.value = q || 1;
    if (sweep) f.frequency.exponentialRampToValueAtTime(freq * sweep, t + dur);
    var gn = ctx.createGain(); gn.gain.setValueAtTime(0.0001, t); gn.gain.exponentialRampToValueAtTime(vol || 0.2, t + 0.02); gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f); f.connect(gn); gn.connect(master); src.start(t); src.stop(t + dur + 0.05);
  }
  /** a small bird's call: a quick downward chip or a thin rising seep */
  function call(kind, delay) { if (kind) { tone(6200, 0.05, 'sine', 0.05, 0.7, delay); tone(5600, 0.05, 'sine', 0.04, 0.7, (delay || 0) + 0.08); } else tone(7200, 0.16, 'sine', 0.035, 1.12, delay); }
  /* the sea on the shore and the wind in the reeds, very low, for as long as the page is open */
  function seaBed() {
    try {
      var src = ctx.createBufferSource(); src.buffer = noiseBuf; src.loop = true;
      var f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 380; f.Q.value = 0.6;
      var gn = ctx.createGain(); gn.gain.value = 0.05;
      var lfo = ctx.createOscillator(), lg = ctx.createGain(); lfo.frequency.value = 0.12; lg.gain.value = 0.03; lfo.connect(lg); lg.connect(gn.gain); lfo.start();
      src.connect(f); f.connect(gn); gn.connect(master); src.start();
      bed = { src: src, gn: gn };
    } catch (e) { bed = null; }
  }
  /* every cue the game can play, in one table (SFX_CUES lists them by name) */
  var CUE = {
    tick: function () { tone(880, 0.05, 'triangle', 0.06); },
    no: function () { tone(220, 0.12, 'square', 0.05, 0.8); tone(180, 0.14, 'square', 0.04, 0.8, 0.09); },
    /* a mist net run out along its poles and the guy lines staked */
    net: function () { noise(0.5, 2400, 1.5, 0.08, 0.6); tone(330, 0.07, 'triangle', 0.12, 0.7, 0.45); tone(300, 0.07, 'triangle', 0.1, 0.7, 0.58); },
    open: function () { noise(0.35, 1800, 1.2, 0.08, 1.6); call(1, 0.3); },
    furl: function () { noise(0.3, 1600, 1.2, 0.09, 0.5); tone(260, 0.06, 'triangle', 0.08, 0.8, 0.28); },
    plant: function () { noise(0.12, 600, 1, 0.2, 0.6, 0, 'lowpass'); noise(0.18, 400, 1, 0.16, 0.6, 0.18, 'lowpass'); },
    /* a ring closed with pliers, and the bird away with a call */
    ring: function () { tone(3400, 0.03, 'square', 0.04); tone(2600, 0.04, 'triangle', 0.05, 1, 0.05); call(Math.random() < 0.5, 0.2); },
    recovery: function () { duck(1.2); tone(1568, 0.25, 'sine', 0.09); tone(2093, 0.4, 'sine', 0.07, 1, 0.12); tone(2637, 0.5, 'sine', 0.05, 1, 0.26); },
    buy: function () { tone(1320, 0.09, 'square', 0.05); tone(1760, 0.18, 'square', 0.045, 1, 0.07); },
    chime: function () { tone(784, 0.35, 'sine', 0.12); tone(1175, 0.45, 'sine', 0.09, 1, 0.09); },
    dawn: function () { tone(523, 0.6, 'sine', 0.05); tone(659, 0.7, 'sine', 0.04, 1, 0.2); call(0, 0.5); call(1, 0.9); },
    bad: function () { tone(196, 0.3, 'triangle', 0.1, 0.85); tone(185, 0.35, 'triangle', 0.08, 0.85, 0.2); },
    fanfare: function () { duck(2.2); var n = [392, 494, 587, 784, 988]; for (var i = 0; i < n.length; i++) tone(n[i], 0.6, 'triangle', 0.1, 1, i * 0.17); },
  };
  var API = {
    SFX_CUES: Object.keys(CUE),
    play: function (name) { var f = CUE[name]; if (!f) return false; try { f(); } catch (e) { /* audio is never fatal */ } return true; },
    unlock: unlock,
    toggle: function () {
      muted = !muted;
      try { localStorage.setItem('flyway.muted', muted ? '1' : '0'); } catch (e) { /* storage blocked */ }
      if (master) master.gain.value = muted ? 0 : BUS;
      if (music) { if (muted) music.pause(); else playMusic(); }
      return muted;
    },
    isMuted: function () { return muted; },
    musicPlaying: function () { return !!music && !music.paused; },
    bedOn: function () { return !!bed; },
  };
  return API;
})();
