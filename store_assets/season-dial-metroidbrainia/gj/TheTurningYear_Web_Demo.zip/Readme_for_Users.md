# The Turning Year

**A world with one dial, and it does not hold still.**

One overworld, drawn four times over. You do not unlock anything in this game and you never will.
You cross it by turning the season — and the year pulls back the whole time you hold it.

Ice is a bridge. Flood is a road. Drought is a door.

---

## How to play

You hold a season open against its own drift. Let go and the year slides home. Push a season deeper
and it gets harder to hold: the strain ring around the dial fills, and the further you are from the
land's own home season, the faster it slips back.

| | keyboard | gamepad | touch |
| --- | --- | --- | --- |
| walk | arrow keys or WASD | left stick or d-pad | drag anywhere on the board |
| **turn the year** | hold **Q** / **E** (or `,` / `.`) | hold **L1/L2** or **R1/R2**, or the right stick | drag your thumb round the dial ring |
| read a sign, act | space, enter or Z | A or X | tap |
| pause | esc or P | start | tap the strip at the top |
| retry this board | R | Y | — (from the loss card, tap) |
| sound on/off | **M** | select | pause, then tap the right half |
| quit to title | hold Q on the pause screen | — | — |

A mouse wheel turns the year too.

Your sound choice is remembered between sessions. Nothing plays until you press or tap something —
no browser is ever ambushed.

**On a phone:** turn it sideways. The board is wider than it is tall, and in portrait you get a
letterbox. The game is fully playable either way.

---

## What is in this build

This is the **free demo**: the Meadow and the Mere, ending at the inscription. The paid build adds
two more boards — the Fell, where winter rests, and the Dunes, where summer does — the river that
runs between them, and the ending the inscription is pointing at.

The demo is not a slice with the interesting parts removed — the flood road and the drowned door are
both in it, and those are the two ideas the whole game is built on. The paid boards are not in these
files at all.

---

## Sound

One theme, four arrangements — spring, summer, autumn, winter — playing **at the same time**, mixed
live by where the dial is standing. At summer you hear the full band. Halfway between summer and
autumn you hear both, at half each, of the same bar of the same tune. The score drifts because the
year does.

Every note was written as data and rendered by oscillator. There is no sample, no soundfont and no
AI music service anywhere in it.

---

## Credits and disclosure

**Core Systems Asset Factory.**

Made with AI tools, stated plainly:

- **Code** — yes.
- **Graphics** — yes.
- **Text and dialogue** — yes.
- **Sound and music** — **no.** Composed here as note data and synthesised by oscillator, which is
  not generative AI.

Art built on four of CSAF's own tile packs — *Verdant Seasons*, *Verdant 01 Overworld*,
*Verdant 24 Desert* and *Verdant Props*. Nothing in this game is third-party licensed content.

---

## If something goes wrong

The game tells you rather than showing you a black screen. If you ever see **THE YEAR STOPPED**,
reload the page — and the text on that card is the actual fault, so it is worth quoting if you write
in.

Runs in any modern browser. No install, no account, no network after the page has loaded.

© Core Systems Asset Factory. See LICENSE.txt.
