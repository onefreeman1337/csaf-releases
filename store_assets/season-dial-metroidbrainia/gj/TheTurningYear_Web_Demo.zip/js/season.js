/* ================================================================================================
 * season.js — THE DIAL. One continuous angle the whole world turns through, and the pull that
 * drags it home.
 * ================================================================================================
 * The primary input of this game is a HELD TURN against a DRIFT (wing §0a-2, DESIGN.md §6):
 *
 *   dd/dt = u·ω·(1 − s) − δ·arc          u = held turn input in [−1, 1]
 *   ds/dt = +σ·|arc|   while pushing away from home     (strain)
 *         = −ρ         otherwise
 *
 * `arc` is the signed shortest arc from HOME (the home season of the land under the hero's feet) to
 * the dial. Hold a key and the dial settles at arc* = ω(1 − s)/δ, then slides home as strain builds —
 * the deeper you push a season, the less you can hold it. Let go and it drifts home exponentially.
 *
 * ⛔ PURE AND CLOCK-FREE. Every function advances by exactly the dt it is handed and reads real time
 * never (wing §6b-2 closing rule: the caller owns the clock). Bots and the browser run the SAME code.
 * ⛔ DUAL-MODE + IIFE (wing §6b-5 rules 1 and 2).
 * ---------------------------------------------------------------------------------------------- */
'use strict';

(function (root) {
  const YEAR = 4;                         /* seasons per turn of the dial */
  const SEASONS = ['spring', 'summer', 'autumn', 'winter'];

  /* ⚠️ v1 constants (DESIGN.md §6). Tuned ONLY against the pre-registered bars of DESIGN.md §8. */
  const K = Object.freeze({
    omega: 1.8,     /* seasons/s the held turn drives the dial at zero strain */
    delta: 1.2,     /* 1/s drift coefficient: drift speed = delta·|arc| */
    sigma: 0.12,    /* strain per second per season of arc while pushing away */
    rho: 0.30,      /* strain recovered per second while not pushing */
    tMean: 6.5,     /* °C at spring and autumn */
    tAmp: 18.5,     /* °C half-swing: summer 25, winter −12 */
  });

  function wrap(d) { d %= YEAR; return d < 0 ? d + YEAR : d; }

  /* Signed shortest arc from `home` to `d`, in (−2, 2]. */
  function arc(d, home) {
    let a = wrap(d) - wrap(home);
    if (a > YEAR / 2) a -= YEAR;
    if (a <= -YEAR / 2) a += YEAR;
    return a;
  }

  /* The temperature law: one number the whole world reads. Summer (d=1) 25, winter (d=3) −12. */
  function temperature(d) { return K.tMean + K.tAmp * Math.cos(Math.PI * (wrap(d) - 1) / 2); }

  /* The season name nearest the dial, and the blend toward the next one (for the renderer). */
  function nearest(d) { return SEASONS[Math.round(wrap(d)) % YEAR]; }
  function blend(d) {
    const w = wrap(d);
    const i = Math.floor(w) % YEAR;
    return { from: SEASONS[i], to: SEASONS[(i + 1) % YEAR], t: w - Math.floor(w) };
  }

  function Dial(d, s) { this.d = wrap(d || 0); this.s = s || 0; this.slipped = false; }
  Dial.prototype.clone = function () { const x = new Dial(this.d, this.s); x.slipped = this.slipped; return x; };

  /* Advance the dial by `dt` seconds under held input `u` in [−1, 1], toward `home`.
   * Returns the dial (mutated). Deterministic: same inputs, same bits. */
  Dial.prototype.step = function (u, home, dt) {
    if (!(dt > 0)) throw new Error('Dial.step: dt must be > 0 (got ' + dt + ')');
    if (typeof home !== 'number' || !isFinite(home)) throw new Error('Dial.step: home must be a finite season number (got ' + home + ')');
    u = Math.max(-1, Math.min(1, +u || 0));
    const a = arc(this.d, home);
    /* "pushing away" = input in the same direction as the arc (or leaving home) */
    const pushingAway = u !== 0 && (Math.abs(a) < 1e-9 || Math.sign(u) === Math.sign(a));
    const push = u * K.omega * (1 - this.s);
    const drift = -K.delta * a;
    this.d = wrap(this.d + (push + drift) * dt);
    if (pushingAway) this.s = Math.min(1, this.s + K.sigma * Math.abs(a) * dt);
    else this.s = Math.max(0, this.s - K.rho * dt);
    return this;
  };

  const API = { YEAR, SEASONS, K, wrap, arc, temperature, nearest, blend, Dial };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  root.TY_SEASON = API;
})(typeof globalThis !== 'undefined' ? globalThis : this);
