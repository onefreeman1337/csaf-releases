/* ================================================================================================
 * world.js — THE YEAR'S PHYSICS. Tiles with heights, lakes with a level and a skin of ice, one
 * snowpack for the whole island, and the boat. Everything here is a function of the dial's history.
 * ================================================================================================
 * DESIGN.md §6, the four processes, each integrated over time (so the world REMEMBERS):
 *
 *   ice, per lake    dI/dt = kf·max(0,−T) − km·max(0,T)          walkable at I ≥ ICE_WALK
 *   snow, global     dS/dt = ks·max(0,−T) − melt,  melt = ksm·max(0,T) while S > 0
 *   level, per lake  unfrozen: dL/dt = g·melt − ke·max(0, T − T_EVAP)
 *                    frozen  : the level is LOCKED; inflow waits on the ice (`pending`) until thaw
 *   heights          a step between two tiles is legal only if their surfaces differ by ≤ STEP
 *
 * ⭐ Every tile's surface height is either its own elevation (dry ground, dry lake bed) or its lake's
 * level (water, ice). That single rule is what makes "flood + freeze = a road at the flood's height"
 * and "a dry brook is a ditch" true without either being a special case.
 *
 * ⛔ Every refusal names its reason (wing §0z-1c): `surface()` returns a `why` on every non-walkable
 * tile, because a silent refusal cannot be told apart from a failure.
 * ⛔ Pure, clock-free, deterministic. ⛔ DUAL-MODE + IIFE.
 * ---------------------------------------------------------------------------------------------- */
'use strict';

(function (root) {
  const SEASON = (typeof require === 'function' && typeof module !== 'undefined') ? require('./season.js') : root.TY_SEASON;

  const TILE = 16;
  const SCREEN_W = 20, SCREEN_H = 10;       /* a board: 320 x 160 px, the HUD strip takes the other 20 */
  const GRID_COLS = 3, GRID_ROWS = 3;        /* the island is at most a 3 x 3 of boards */
  const W = SCREEN_W * GRID_COLS, H = SCREEN_H * GRID_ROWS;

  /* ⚠️ v1 constants (DESIGN.md §6); tuned only against DESIGN.md §8's pre-registered bars. */
  const P = Object.freeze({
    STEP: 1.0,          /* max surface-height difference between adjacent tiles you can walk */
    ICE_WALK: 0.4,      /* ice at least this thick bears the hero */
    ICE_SOLID: 1.0,     /* below this it is THIN: standing still on it breaks it */
    ICE_CAP: 3.0,
    T_EVAP: 15,         /* °C above which open water evaporates */
    ks: 0.0125,         /* snowfall per s per °C of frost */
    ksm: 0.03,          /* snowmelt per s per °C above zero */
    SNOW_CAP: 6.0,
    PENDING_RATE: 0.6,  /* level/s at which water held on the ice pours in once the ice is gone */
    THIN_BREAK_S: 0.9,  /* seconds standing still on thin ice before it gives */
    DRIFT_BURY: 3.2,    /* snowpack at which a snowdrift slot closes */
    BOAT_CLEAR: 0.5,    /* how much headroom the boat needs under a lintel */
  });

  /* ---- terrain legend --------------------------------------------------------------------------- */
  const LEGEND = {
    '.': { type: 'grass' }, ',': { type: 'path' }, ':': { type: 'sand' }, '_': { type: 'stone' },
    '@': { type: 'grass', spawn: true },
    'r': { type: 'reeds' },
    'T': { type: 'tree', block: 'a tree' }, 'R': { type: 'rock', block: 'a rock' },
    '#': { type: 'cliff', block: 'a cliff' }, 'w': { type: 'ruin', block: 'a ruin wall' },
    's': { type: 'sign', block: 'a signpost', read: true }, 'g': { type: 'glyph', block: 'a glyph stone', read: true },
    'B': { type: 'inscription', block: 'the inscription stone', read: true },
    'I': { type: 'island' },
    'x': { type: 'drift', drift: true },
    '~': { type: 'bed', lake: 1 }, '=': { type: 'bed', lake: 2 },
    /* the warm spring: part of the lake, but it NEVER freezes — the island is the boat's alone */
    'h': { type: 'bed', lake: 1, warm: true },
    /* THE OLD SLUICE: a sill the water must clear (e + hp) and a lintel the boat must pass under.
     * The boat goes through only in the window sill < L <= lintel − BOAT_CLEAR. Never walkable. */
    'f': { type: 'bed', lake: 1, prop: { k: 'sluice', hp: 1.0, lintel: 4.8, solid: true } },
    'o': { type: 'bed', lake: 1, boat: true },
    'D': { type: 'bed', lake: 1, door: true },
    ' ': { type: 'void', block: 'the edge of the island' },
  };

  function elevOf(ch, dflt) {
    if (ch === 'm') return -1;
    if (ch >= '0' && ch <= '9') return ch.charCodeAt(0) - 48;
    if (ch === '.' || ch === undefined) return dflt;
    throw new Error('world: unknown elevation char "' + ch + '"');
  }

  function idx(tx, ty) { return ty * W + tx; }
  function inGrid(tx, ty) { return tx >= 0 && ty >= 0 && tx < W && ty < H; }

  /* ================================================================================================
   * Building the island from registered content (content.js always; content_full.js only in the paid
   * build — wing §1-DEMO: paid content is a FILE the free build does not load, never a branch).
   * ================================================================================================ */
  function build(contentList) {
    if (!contentList || !contentList.length) throw new Error('world.build: no content registered');
    const lands = {}, lakes = {}, screens = [], texts = {};
    let start = null;
    for (const c of contentList) {
      Object.assign(lands, c.lands || {});
      Object.assign(lakes, c.lakes || {});
      Object.assign(texts, c.texts || {});
      for (const s of (c.screens || [])) screens.push(s);
      if (c.start) start = c.start;
    }
    if (!start) throw new Error('world.build: no start declared');

    const tiles = new Array(W * H);
    for (let i = 0; i < W * H; i++) tiles[i] = { type: 'void', block: 'the edge of the island', e: 0, land: null, lake: null, screen: null };

    const screenIndex = {};
    const boats = [];
    for (const s of screens) {
      if (screenIndex[s.id]) throw new Error('world.build: duplicate screen id ' + s.id);
      if (!lands[s.land]) throw new Error('world.build: screen ' + s.id + ' names unknown land ' + s.land);
      if (s.terrain.length !== SCREEN_H || s.elev.length !== SCREEN_H) throw new Error('world.build: screen ' + s.id + ' must have ' + SCREEN_H + ' terrain and elev rows');
      screenIndex[s.id] = s;
      for (let y = 0; y < SCREEN_H; y++) {
        const trow = s.terrain[y], erow = s.elev[y], lrow = s.landRows ? s.landRows[y] : null;
        if (trow.length !== SCREEN_W || erow.length !== SCREEN_W) throw new Error('world.build: screen ' + s.id + ' row ' + y + ' is not ' + SCREEN_W + ' wide (terrain ' + trow.length + ', elev ' + erow.length + ')');
        for (let x = 0; x < SCREEN_W; x++) {
          const ch = trow[x];
          const def = LEGEND[ch];
          if (!def) throw new Error('world.build: screen ' + s.id + ' (' + x + ',' + y + ') unknown terrain "' + ch + '"');
          const tx = s.col * SCREEN_W + x, ty = s.row * SCREEN_H + y;
          let landId = s.land;
          if (lrow) { const lc = lrow[x]; if (lc !== '.') { landId = (s.landKey || {})[lc]; if (!landId || !lands[landId]) throw new Error('world.build: screen ' + s.id + ' landRows char "' + lc + '" unknown'); } }
          const t = {
            type: def.type, e: elevOf(erow[x], s.defaultElev != null ? s.defaultElev : 5),
            land: def.type === 'void' ? null : landId, screen: s.id, lake: null,
            block: def.block || null, read: !!def.read, drift: !!def.drift, door: !!def.door, warm: !!def.warm,
            prop: def.prop ? Object.assign({}, def.prop) : null, spawn: !!def.spawn, tx, ty,
            sign: (s.signs && s.signs[x + ',' + y]) || null,
          };
          if (def.lake) {
            const lakeId = def.lake === 1 ? s.lake : s.lake2;
            if (!lakeId || !lakes[lakeId]) throw new Error('world.build: screen ' + s.id + ' (' + x + ',' + y + ') is lake bed but lake ' + def.lake + ' is not declared');
            t.lake = lakeId;
          }
          /* ⛔ A BLOCK NAMES WHAT IT IS ON THE BOARD THE PLAYER IS STANDING ON. The Dunes' border is
           * the same `T` as the Meadow's — deliberately, so the COLLISION and every reachability
           * proof in `_level_selftest.js` stay byte-identical while the renderer draws the desert
           * its own frame (art director round-2 major defect 5). But a refusal that says "a tree"
           * when the picture is a date palm is the same class of lie as a caption over the wrong
           * board, so the word follows the art. The type is untouched: this changes one string. */
          if (t.type === 'tree' && landId === 'dunes') t.block = 'a date palm';
          if (def.boat) boats.push({ lake: t.lake, x: (tx + 0.5) * TILE, y: (ty + 0.5) * TILE, grounded: false, locked: false });
          if (t.read && !t.sign) throw new Error('world.build: screen ' + s.id + ' (' + x + ',' + y + ') is a readable "' + ch + '" with no text in signs');
          tiles[idx(tx, ty)] = t;
        }
      }
    }
    return { tiles, lands, lakeDefs: lakes, screens: screenIndex, start, texts, boats };
  }

  /* ================================================================================================
   * World — the mutable year
   * ================================================================================================ */
  function World(contentList) {
    const b = build(contentList);
    this.tiles = b.tiles; this.lands = b.lands; this.screens = b.screens; this.start = b.start; this.texts = b.texts;
    this.lakeDefs = b.lakeDefs;
    this.lakes = {};
    for (const [id, d] of Object.entries(b.lakeDefs)) {
      for (const k of ['L0', 'kf', 'km', 'g', 'ke', 'capL', 'minL']) if (typeof d[k] !== 'number') throw new Error('world: lake ' + id + ' missing numeric ' + k);
      this.lakes[id] = { id, L: d.L0, I: d.I0 || 0, pending: 0, holes: {} };
    }
    this.boats = b.boats;
    this.S = 0;                              /* the snowpack, in "snow units" */
    this.dial = new SEASON.Dial(b.start.d || 0);
    this.T = SEASON.temperature(this.dial.d);
    this.time = 0;
    this.meltRate = 0;
    /* counts of WORK (master §2b rule 2) */
    this.stats = { steps: 0, iceBreaks: 0 };
  }

  World.prototype.tile = function (tx, ty) { return inGrid(tx, ty) ? this.tiles[idx(tx, ty)] : null; };
  World.prototype.homeAt = function (tx, ty) {
    const t = this.tile(tx, ty);
    if (!t || !t.land) return null;
    return this.lands[t.land].home;
  };

  /* One simulation step: the dial (under held input u, pulled toward `home`), then the snow, then
   * every lake. ⛔ `home` is REQUIRED: a default would silently drift every bot toward spring. */
  World.prototype.step = function (dt, u, home) {
    if (typeof home !== 'number') throw new Error('World.step: home season required (got ' + home + ')');
    this.dial.step(u, home, dt);
    const T = this.T = SEASON.temperature(this.dial.d);

    const fall = P.ks * Math.max(0, -T);
    let melt = 0;
    if (this.S > 0 && T > 0) melt = Math.min(this.S / dt, P.ksm * T);
    this.S = Math.max(0, Math.min(P.SNOW_CAP, this.S + (fall - melt) * dt));
    this.meltRate = melt;

    for (const lake of Object.values(this.lakes)) {
      const d = this.lakeDefs[lake.id];
      const dI = d.kf * Math.max(0, -T) - d.km * Math.max(0, T);
      lake.I = Math.max(0, Math.min(P.ICE_CAP, lake.I + dI * dt));
      if (lake.I === 0) lake.holes = {};
      const inflow = d.g * melt;
      if (lake.I > 0) {
        lake.pending += inflow * dt;                         /* ⭐ ice locks the level where it froze */
      } else {
        const pour = Math.min(lake.pending, P.PENDING_RATE * dt);
        lake.pending -= pour;
        const evap = d.ke * Math.max(0, T - P.T_EVAP);
        lake.L = Math.max(d.minL, Math.min(d.capL, lake.L + (inflow - evap) * dt + pour));
      }
    }
    for (const bt of this.boats) this._boatStatus(bt);
    this.time += dt;
    this.stats.steps++;
  };

  /* ---- the one question everything asks: what is this tile, right now? -------------------------
   * kind: void | block | ground | bed | water | thin | ice | drift
   * h   : the surface height a foot stands at (null when there is no surface)
   * walk: can the hero stand here (ignoring the step rule, which needs a neighbour)
   * why : the NAMED reason when walk is false */
  World.prototype.surface = function (tx, ty) {
    const t = this.tile(tx, ty);
    if (!t || t.type === 'void') return { kind: 'void', h: null, walk: false, why: 'the edge of the island', t };
    if (t.block) return { kind: 'block', h: t.e, walk: false, why: t.block, t };
    if (t.drift) {
      if (this.S >= P.DRIFT_BURY) return { kind: 'drift', h: t.e, walk: false, why: 'the pass is buried in snow', t };
      return { kind: 'ground', h: t.e, walk: true, t };
    }
    if (!t.lake) return { kind: 'ground', h: t.e, walk: true, t };
    const lake = this.lakes[t.lake];
    const L = lake.L;
    const propTop = t.prop ? t.e + t.prop.hp : -Infinity;
    if (t.prop && t.prop.solid) return { kind: 'block', h: t.e, walk: false, why: 'the old ' + t.prop.k, t, lake, prop: true };
    if (t.e >= L) {
      if (t.prop) return { kind: 'bed', h: t.e, walk: false, why: 'a ' + t.prop.k, t, lake };
      return { kind: 'bed', h: t.e, walk: true, t, lake };
    }
    /* under water */
    if (propTop >= L) {
      /* the prop breaks the surface: an obstacle to a boat and to a walker on ice alike */
      return { kind: lake.I > 0 ? 'ice' : 'water', h: L, walk: false, why: 'a ' + t.prop.k + ' standing out of the ' + (lake.I > 0 ? 'ice' : 'water'), t, lake, propOut: true };
    }
    const key = tx + ',' + ty;
    if (t.warm) return { kind: 'water', h: L, walk: false, why: 'the warm spring never freezes', t, lake, warm: true };
    if (lake.I >= P.ICE_WALK && !lake.holes[key]) {
      return { kind: lake.I >= P.ICE_SOLID ? 'ice' : 'thin', h: L, walk: true, t, lake };
    }
    return { kind: 'water', h: L, walk: false, why: lake.holes[key] ? 'a hole in the ice' : (lake.I > 0 ? 'ice too thin to bear you' : 'open water'), t, lake };
  };

  /* A boat floats on open, unfrozen water it can clear. */
  World.prototype.boatable = function (tx, ty, lakeId) {
    const t = this.tile(tx, ty);
    if (!t || t.lake !== lakeId) return { ok: false, why: t && t.lake ? 'another water' : 'not water' };
    const lake = this.lakes[lakeId];
    if (t.e >= lake.L) return { ok: false, why: 'dry bed' };
    if (t.prop && t.e + t.prop.hp >= lake.L) return { ok: false, why: 'the ' + t.prop.k + ' sill breaks the surface' };
    if (t.prop && t.prop.lintel != null && lake.L > t.prop.lintel - P.BOAT_CLEAR) return { ok: false, why: 'the water is too high to pass under the ' + t.prop.k + ' lintel' };
    if (lake.I > 0 && !t.warm) return { ok: false, why: 'the water is frozen' };
    return { ok: true };
  };

  World.prototype._boatStatus = function (bt) {
    const tx = Math.floor(bt.x / TILE), ty = Math.floor(bt.y / TILE);
    const t = this.tile(tx, ty);
    const lake = this.lakes[bt.lake];
    bt.grounded = !t || t.e >= lake.L;
    bt.locked = !bt.grounded && lake.I > 0 && !(t && t.warm);
  };

  World.prototype.breakIce = function (tx, ty) {
    const t = this.tile(tx, ty);
    if (!t || !t.lake) return false;
    const lake = this.lakes[t.lake];
    lake.holes[tx + ',' + ty] = true;
    this.stats.iceBreaks++;
    return true;
  };

  /* ---- snapshots: the whole mutable year, so a retry restores exactly the board you entered ---- */
  World.prototype.snapshot = function () {
    const lakes = {};
    for (const [id, l] of Object.entries(this.lakes)) lakes[id] = { L: l.L, I: l.I, pending: l.pending, holes: Object.assign({}, l.holes) };
    return {
      lakes, S: this.S, dial: { d: this.dial.d, s: this.dial.s }, time: this.time,
      boats: this.boats.map((b) => Object.assign({}, b)),
    };
  };
  World.prototype.restore = function (snap) {
    for (const [id, l] of Object.entries(snap.lakes)) Object.assign(this.lakes[id], { L: l.L, I: l.I, pending: l.pending, holes: Object.assign({}, l.holes) });
    this.S = snap.S; this.dial.d = snap.dial.d; this.dial.s = snap.dial.s; this.time = snap.time;
    this.boats = snap.boats.map((b) => Object.assign({}, b));
    this.T = SEASON.temperature(this.dial.d);
  };

  World.prototype.screenOf = function (tx, ty) { const t = this.tile(tx, ty); return t ? t.screen : null; };

  const API = { TILE, SCREEN_W, SCREEN_H, GRID_COLS, GRID_ROWS, W, H, P, LEGEND, World, build };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  root.TY_WORLD = API;
})(typeof globalThis !== 'undefined' ? globalThis : this);
