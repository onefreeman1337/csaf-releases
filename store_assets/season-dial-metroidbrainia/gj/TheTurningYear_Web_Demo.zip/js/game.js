/* ================================================================================================
 * game.js — THE SHELL: input, the fixed-step loop, the screens. The model is run.js; this file only
 * turns keys into the input record every bot also uses, and decides which screen is up.
 * ================================================================================================
 * ⭐ THE CALLER OWNS THE CLOCK (wing §6b-2): the accumulator below is the ONLY place real time enters
 * the simulation, and it steps at exactly DT = 1/60, the step every gate was measured at. A slow frame
 * runs more steps, never a bigger one; the catch-up is CLAMPED so a tab that comes back from the
 * background does not run thousands of steps at once (§1.1b `breakit`: tab-away).
 * ⭐ `tick()` is the ONE place a frame happens (wing §6b-18). `window.__tyTick(n, input)` is a second
 * caller for the harness, because a background automation tab gets no rAF at all (§1a).
 * ---------------------------------------------------------------------------------------------- */
'use strict';

(function (root) {
  const RUN = root.TY_RUN, RENDER = root.TY_RENDER;
  const DT = 1 / 60, MAX_CATCHUP = 5;

  const KEYS = {
    left: ['ArrowLeft', 'KeyA'], right: ['ArrowRight', 'KeyD'], up: ['ArrowUp', 'KeyW'], down: ['ArrowDown', 'KeyS'],
    /* the held turn: Q/E, or , and . for keyboards where Q/E sit badly */
    back: ['KeyQ', 'Comma'], fwd: ['KeyE', 'Period'],
    interact: ['Space', 'Enter', 'KeyZ'], pause: ['Escape', 'KeyP'], retry: ['KeyR'], mute: ['KeyM'],
  };
  const SWALLOW = new Set(['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Space']);   /* never scroll the itch iframe */

  /* ---- the gamepad map -------------------------------------------------------------------------
   * Standard mapping. The HELD TURN is on the SHOULDERS and on the right stick's X, because this
   * game's primary verb is a hold against a drift (wing §0a-2) and a shoulder is the one control a
   * thumb can lean on while the left stick is still walking. */
  const PAD = {
    axisMoveX: 0, axisMoveY: 1, axisTurn: 2,
    turnBack: [4, 6], turnFwd: [5, 7],           /* L1/L2 and R1/R2 */
    interact: [0, 2], pause: [9], retry: [3], mute: [8],
    dpad: { up: 12, down: 13, left: 14, right: 15 },
  };
  const PAD_DEAD = 0.35;

  function Input(target, canvas) {
    this.down = {}; this.pressed = {}; this.wheel = 0; this.any = false;
    /* which device has been used at least once — the title screen's prompt reads this so a phone is
     * never told to "press any key" */
    this.seen = { key: false, mouse: false, pad: false, touch: false };
    this.pad = { dx: 0, dy: 0, turn: 0 };
    this.touch = { dx: 0, dy: 0, turn: 0 };
    this.padIndex = null;
    this.canvas = canvas || null;
    const map = {};
    for (const [act, codes] of Object.entries(KEYS)) for (const c of codes) map[c] = act;
    const self = this;
    this.onKey = function (e, isDown) {
      if (SWALLOW.has(e.code)) e.preventDefault();
      if (isDown) { self.any = true; self.seen.key = true; }
      const act = map[e.code]; if (!act) return;
      e.preventDefault();
      if (isDown && !self.down[act]) self.pressed[act] = true;
      self.down[act] = isDown;
    };
    target.addEventListener('keydown', (e) => self.onKey(e, true), { passive: false });
    target.addEventListener('keyup', (e) => self.onKey(e, false), { passive: false });
    target.addEventListener('blur', () => { self.down = {}; self.pressed = {}; self.touch = { dx: 0, dy: 0, turn: 0 }; self.touches = {}; });
    target.addEventListener('wheel', (e) => { self.wheel += Math.sign(e.deltaY) * 0.25; self.any = true; self.seen.mouse = true; e.preventDefault(); }, { passive: false });
    target.addEventListener('pointerdown', (e) => { self.any = true; if (e && e.pointerType === 'touch') self.seen.touch = true; else self.seen.mouse = true; });
    if (canvas) this._attachTouch(canvas);
  }

  /* ---- touch ------------------------------------------------------------------------------------
   * ⭐ THE DIAL IS A THING YOU TURN WITH YOUR THUMB, so on a touch screen you turn it with your
   * thumb — a drag anywhere in the dial's own corner rotates it, in the direction your finger goes
   * round the ring, exactly as the brief's beauty sentence describes. Anywhere else on the board is
   * a relative stick for walking, and a short tap that did not travel is `interact`.
   *
   * ⛔ Screen pixels are NOT logical pixels. The canvas is `object-fit: contain` inside a box of any
   * shape, so the bitmap is letterboxed and every coordinate has to come back through that scale
   * before it can be compared against the dial's logical centre. Getting this wrong puts the dial's
   * hit area somewhere else entirely at every viewport but one. */
  Input.prototype._toLogical = function (clientX, clientY) {
    const r = this.canvas.getBoundingClientRect();
    const W = this.canvas.width, H = this.canvas.height;
    const scale = Math.min(r.width / W, r.height / H) || 1;
    return {
      x: (clientX - r.left - (r.width - W * scale) / 2) / scale,
      y: (clientY - r.top - (r.height - H * scale) / 2) / scale,
    };
  };

  Input.prototype._attachTouch = function (canvas) {
    const self = this;
    this.touches = {};
    const L = RENDER && RENDER.LAYOUT ? RENDER.LAYOUT : { DIAL_X: 288, DIAL_Y: 148, DIAL_R: 26 };
    const start = function (e) {
      self.seen.touch = true; self.any = true;
      for (const t of e.changedTouches) {
        const p = self._toLogical(t.clientX, t.clientY);
        const onDial = Math.hypot(p.x - L.DIAL_X, p.y - L.DIAL_Y) <= L.DIAL_R + 18;
        self.touches[t.identifier] = { kind: onDial ? 'dial' : 'stick', x0: p.x, y0: p.y, x: p.x, y: p.y, t0: Date.now(), moved: 0, ang: Math.atan2(p.y - L.DIAL_Y, p.x - L.DIAL_X) };
      }
      e.preventDefault();
    };
    const move = function (e) {
      for (const t of e.changedTouches) {
        const s = self.touches[t.identifier]; if (!s) continue;
        const p = self._toLogical(t.clientX, t.clientY);
        s.moved = Math.max(s.moved, Math.hypot(p.x - s.x0, p.y - s.y0));
        if (s.kind === 'dial') {
          const a = Math.atan2(p.y - L.DIAL_Y, p.x - L.DIAL_X);
          let da = a - s.ang;
          while (da > Math.PI) da -= Math.PI * 2;
          while (da < -Math.PI) da += Math.PI * 2;
          /* a held direction, not a position: a thumb that stops moving stops turning, and the
           * drift takes the dial home again, which is the whole mechanic */
          if (Math.abs(da) > 0.012) { s.turn = da > 0 ? 1 : -1; s.ang = a; s.turnAt = Date.now(); }
        }
        s.x = p.x; s.y = p.y;
      }
      e.preventDefault();
    };
    const end = function (e) {
      for (const t of e.changedTouches) {
        const s = self.touches[t.identifier]; if (!s) continue;
        /* a tap: short, and it did not travel. ⛔ ITS POSITION IS KEPT, because on a touch screen
         * the tap is the ONLY button there is — pause, resume and mute are all keyboard-only
         * otherwise, and a phone player could not silence the game or take a break at all. The
         * shell decides what a tap at that point means, since only it knows which screen is up. */
        if (s.kind === 'stick' && s.moved < 6 && Date.now() - s.t0 < 300) {
          self.pressed.interact = true; self.tapped = true;
          self.lastTap = { x: s.x0, y: s.y0 };
        }
        delete self.touches[t.identifier];
      }
      e.preventDefault();
    };
    canvas.addEventListener('touchstart', start, { passive: false });
    canvas.addEventListener('touchmove', move, { passive: false });
    canvas.addEventListener('touchend', end, { passive: false });
    canvas.addEventListener('touchcancel', end, { passive: false });
  };

  /** Fold every live touch into one movement/turn record. Called once per frame from tick(). */
  Input.prototype.pollTouch = function () {
    const o = { dx: 0, dy: 0, turn: 0 };
    const now = Date.now();
    for (const k in this.touches) {
      if (!Object.prototype.hasOwnProperty.call(this.touches, k)) continue;
      const s = this.touches[k];
      if (s.kind === 'dial') {
        /* a turn expires 140 ms after the thumb last moved, so resting a finger on the ring does
         * not hold the season open for free */
        if (s.turn && now - (s.turnAt || 0) < 140) o.turn = s.turn;
      } else {
        const ddx = s.x - s.x0, ddy = s.y - s.y0;
        if (Math.abs(ddx) > 5) o.dx = ddx > 0 ? 1 : -1;
        if (Math.abs(ddy) > 5) o.dy = ddy > 0 ? 1 : -1;
      }
    }
    this.touch = o;
    return o;
  };

  /** Poll the gamepad. ⛔ Polled, never event-driven — the Gamepad API has no button events. */
  Input.prototype.pollPad = function () {
    const o = { dx: 0, dy: 0, turn: 0 };
    const nav = root.navigator;
    if (!nav || !nav.getGamepads) { this.pad = o; return o; }
    let pads;
    try { pads = nav.getGamepads(); } catch (e) { this.pad = o; return o; }
    let gp = null;
    for (let i = 0; i < pads.length; i++) if (pads[i] && pads[i].connected) { gp = pads[i]; this.padIndex = i; break; }
    if (!gp) { this.pad = o; this._padPrev = null; return o; }
    this.seen.pad = true;
    const ax = gp.axes || [], bt = gp.buttons || [];
    const btn = (i) => !!(bt[i] && (bt[i].pressed || bt[i].value > 0.5));
    const anyOf = (list) => list.some(btn);
    const dz = (v) => (Math.abs(v) > PAD_DEAD ? (v > 0 ? 1 : -1) : 0);
    o.dx = dz(ax[PAD.axisMoveX] || 0) || (btn(PAD.dpad.right) ? 1 : 0) - (btn(PAD.dpad.left) ? 1 : 0);
    o.dy = dz(ax[PAD.axisMoveY] || 0) || (btn(PAD.dpad.down) ? 1 : 0) - (btn(PAD.dpad.up) ? 1 : 0);
    o.turn = (anyOf(PAD.turnFwd) ? 1 : 0) - (anyOf(PAD.turnBack) ? 1 : 0) || dz(ax[PAD.axisTurn] || 0);
    /* rising edges for the discrete buttons, since the API reports level not edge */
    const prev = this._padPrev || {};
    const nowPressed = { interact: anyOf(PAD.interact), pause: anyOf(PAD.pause), retry: anyOf(PAD.retry), mute: anyOf(PAD.mute) };
    for (const act of ['interact', 'pause', 'retry', 'mute']) {
      if (nowPressed[act] && !prev[act]) { this.pressed[act] = true; this.any = true; }
    }
    this._padPrev = nowPressed;
    this.pad = o;
    return o;
  };

  /* the input record, exactly the shape the bots hand run.step() */
  Input.prototype.take = function () {
    const pad = this.pad || { dx: 0, dy: 0, turn: 0 };
    const tch = this.touch || { dx: 0, dy: 0, turn: 0 };
    let turn = (this.down.fwd ? 1 : 0) - (this.down.back ? 1 : 0) || pad.turn || tch.turn;
    if (this.wheel) { turn = Math.max(-1, Math.min(1, turn + Math.sign(this.wheel))); this.wheel -= Math.sign(this.wheel) * Math.min(Math.abs(this.wheel), DT); }
    const o = {
      dx: ((this.down.right ? 1 : 0) - (this.down.left ? 1 : 0)) || pad.dx || tch.dx,
      dy: ((this.down.down ? 1 : 0) - (this.down.up ? 1 : 0)) || pad.dy || tch.dy,
      turn, interact: !!this.pressed.interact,
    };
    this.pressed.interact = false;
    return o;
  };
  Input.prototype.edge = function (act) { const v = !!this.pressed[act]; this.pressed[act] = false; return v; };

  function Game(canvas, contentList) {
    this.canvas = canvas;
    this.content = contentList;
    this.renderer = new RENDER.Renderer(canvas);
    this.input = new Input(root, canvas);
    this.screen = 'title';
    this.run = null;
    this.message = null; this.messageT = 0;
    this.errorText = '';
    this.acc = 0; this.last = 0;
    /* counts of WORK, never verdicts (master §2b rule 2) */
    this.stats = { frames: 0, steps: 0, longestFrameMs: 0 };
    /* the score. It loads at once and stays silent until the first key or tap (no autoplay). */
    this.sound = root.TY_SOUND ? new root.TY_SOUND.Sound().load() : null;
    this._cueState = { tile: null, dialQuarter: null };
  }

  Game.prototype.begin = function () {
    this.run = new RUN.Run(this.content);
    this.screen = 'playing';
    this.message = null;
    this._cueState = { tile: null, dialQuarter: null };
  };

  /** The dial angle the SCORE is mixed at. In play it is the world's own dial; on the title and the
   *  credits it is the same slow automatic turn the renderer draws there, so what you see the ring
   *  doing and what you hear the year doing are the same number. */
  Game.prototype.musicDial = function () {
    if (this.run) return this.run.world.dial.d;
    return (this.renderer.stats.frames / 260) % 4;
  };

  /**
   * ⛔ THE TOUCH PLAYER'S ONLY BUTTON. Pause, resume, quit and mute are all bound to keys, so a
   * phone player could not pause the game, could not get back to the title and — worst of the three
   * — could not SILENCE IT, which on a phone is not a nicety.
   *
   * A tap has a position, so it can mean different things in different places, and the two places
   * are the ones already drawn: the HUD strip across the top (pause), and the two halves of the
   * pause plate (resume on the left, sound on the right). Both are ANNOUNCED on screen when a touch
   * device is in use — wing §6b-12: a mechanic the screen never mentions is not a mechanic.
   *
   * Returns true when the tap was consumed, so it is not also read as `interact`.
   */
  Game.prototype._touchButtons = function (screen) {
    const tap = this.input.lastTap;
    if (!tap || !this.input.seen.touch) return false;
    this.input.lastTap = null;
    const L = RENDER.LAYOUT;
    if (screen === 'playing' && tap.y <= L.HUD_H) {
      this.input.pressed.interact = false;
      this.screen = 'paused';
      if (this.sound) this.sound.cue('sfx_ui');
      return true;
    }
    if (screen === 'paused') {
      this.input.pressed.interact = false;
      if (tap.x >= L.W / 2) { if (this.sound) { this.sound.setMuted(!this.sound.muted); this.sound.cue('sfx_ui', 0.8); } }
      else { this.screen = 'playing'; if (this.sound) this.sound.cue('sfx_ui'); }
      return true;
    }
    return false;
  };

  /** Fire the cues one fixed step's worth of events asks for. Called from stepOnce, so a harness
   *  driving stepOnce directly exercises the audio exactly as the rAF loop does (wing §6b-18). */
  Game.prototype._cues = function (ev) {
    const s = this.sound; if (!s) return;
    for (const e of ev) {
      if (e.k === 'crack') s.cue('sfx_crack', 0.9);
      else if (e.k === 'lost') s.cue('sfx_splash', 1);
      else if (e.k === 'board') s.cue('sfx_board', 1);
      else if (e.k === 'disembark') s.cue('sfx_ashore', 0.9);
      else if (e.k === 'read') s.cue('sfx_read', 0.9);
      else if (e.k === 'screen') s.cue('sfx_screen', 0.8);
      else if (e.k === 'demoEnd' || e.k === 'ending') s.cue('sfx_end', 1);
    }
    const r = this.run; if (!r) return;
    /* a footfall each time the hero's tile changes, and a detent each quarter-season the dial
     * crosses — the two things the hands are doing, given back as sound */
    const key = r.hero.tx() + ',' + r.hero.ty();
    if (this._cueState.tile !== null && key !== this._cueState.tile) s.cue('sfx_step', 0.8);
    this._cueState.tile = key;
    const q = Math.floor(r.world.dial.d * 4);
    if (this._cueState.dialQuarter !== null && q !== this._cueState.dialQuarter) s.cue('sfx_turn', 0.7);
    this._cueState.dialQuarter = q;
  };

  /* one fixed step of whatever screen is up, given an input record */
  Game.prototype.stepOnce = function (inp) {
    const s = this.screen;
    /* ⛔ THE SOUND IS DRIVEN FROM HERE, NOT FROM tick(). stepOnce is the one function both the rAF
     * loop and every harness call, so a test that replays a tape exercises the real audio path
     * (wing §6b-18). It advances on the fixed DT, so the cue throttle is deterministic too — and
     * it touches no model state, which is why verify_page's bit-identical replay still holds. */
    if (this.sound) this.sound.setDial(this.musicDial(), DT);
    if (this.input.edge('mute') && this.sound) { this.sound.setMuted(!this.sound.muted); this.sound.cue('sfx_ui', 0.8); }
    if (this._touchButtons(s)) return;
    if (s === 'title') { if (this.input.any || inp.any) { this.input.any = false; if (this.sound) this.sound.cue('sfx_ui'); this.begin(); } return; }
    if (s === 'paused') {
      if (this.input.edge('pause')) { this.screen = 'playing'; if (this.sound) this.sound.cue('sfx_ui'); }
      else if (this.input.edge('retry')) { this.run.retry(); this.screen = 'playing'; if (this.sound) this.sound.cue('sfx_ui'); }
      else if (this.input.down.back && this.input.edge('back')) { this.screen = 'title'; this.run = null; this.input.any = false; if (this.sound) this.sound.cue('sfx_ui'); }
      return;
    }
    if (s === 'lost') { if (this.input.edge('interact') || inp.interact || this.input.edge('retry')) { this.run.retry(); this.screen = 'playing'; this.message = null; if (this.sound) this.sound.cue('sfx_ui'); } return; }
    if (s === 'demoEnd' || s === 'ending') { if (this.input.edge('interact') || inp.interact) { this.screen = 'credits'; if (this.sound) this.sound.cue('sfx_ui'); } return; }
    if (s === 'credits') { if (this.input.edge('interact') || inp.interact) { this.screen = 'title'; this.run = null; this.input.any = false; if (this.sound) this.sound.cue('sfx_ui'); } return; }
    if (s !== 'playing') return;
    if (this.input.edge('pause')) { this.screen = 'paused'; if (this.sound) this.sound.cue('sfx_ui'); return; }
    if (this.input.edge('retry')) { this.run.retry(); if (this.sound) this.sound.cue('sfx_ui'); return; }
    const ev = this.run.step(DT, inp);
    this.stats.steps++;
    for (const e of ev) {
      if (e.k === 'read') { this.message = this.run.world.texts[e.text] || ''; this.messageT = 5; }
      if (e.k === 'lost') this.screen = 'lost';
      if (e.k === 'demoEnd') this.screen = 'demoEnd';
      if (e.k === 'ending') this.screen = 'ending';
      if (e.k === 'screen') this.message = null;
    }
    this._cues(ev);
    if (this.message && (this.messageT -= DT) <= 0) this.message = null;
  };

  Game.prototype.tick = function () {
    const t = now();
    let el = (t - this.last) / 1000;
    if (this.last) this.stats.longestFrameMs = Math.max(this.stats.longestFrameMs, t - this.last);
    this.last = t;
    if (!isFinite(el) || el < 0) el = 0;
    /* a harness replaying a tape holds the clock: the loop draws but never steps, so no zero-input
     * step slips in between two replayed ones */
    if (root.__tyHold) { this.acc = 0; this.renderer.frame(this); this.stats.frames++; return; }
    /* polled devices, once per FRAME — the Gamepad API fires no events, and a touch's held state is
     * a fact about now rather than about a step */
    this.input.pollPad();
    this.input.pollTouch();
    this.acc = Math.min(this.acc + el, MAX_CATCHUP * DT);
    while (this.acc >= DT) { this.stepOnce(this.input.take()); this.acc -= DT; }
    this.renderer.frame(this);
    this.stats.frames++;
  };

  function now() { return (root.performance && root.performance.now) ? root.performance.now() : Date.now(); }

  Game.prototype.start = function () {
    const self = this;
    this.last = now();
    const loop = function () { try { self.tick(); } catch (e) { self.fail(e); } root.requestAnimationFrame(loop); };
    root.requestAnimationFrame(loop);
    return this;
  };
  Game.prototype.fail = function (e) {
    /* ⛔ NAMED, never a blank canvas (wing §0z-1c) */
    this.screen = 'error'; this.errorText = 'Something broke: ' + (e && e.message ? e.message : String(e));
    if (root.console) root.console.error(e);
  };

  /* ---- the harness door ------------------------------------------------------------------------ */
  function install(game) {
    root.__tyGame = game;
    /* ⛔ NO AUTOPLAY. The context is resumed on the player's FIRST gesture and never before; a
     * browser that refuses records the refusal and the game carries on silent (wing §1b). */
    if (game.sound) {
      const wake = function () { game.sound.unlock(); };
      for (const evt of ['keydown', 'pointerdown', 'touchstart']) {
        root.addEventListener(evt, wake, { passive: true });
      }
    }
    /* step n fixed steps with a given input record, draw once, report the state */
    root.__tyTick = function (n, inp) {
      inp = inp || {};
      for (let i = 0; i < (n || 1); i++) game.stepOnce(Object.assign({ dx: 0, dy: 0, turn: 0, interact: false }, inp, { interact: i === 0 && !!inp.interact }));
      game.renderer.frame(game);
      return root.TY.state();
    };
    root.TY = {
      state: function () {
        const r = game.run;
        if (!r) return { screen: game.screen, frames: game.stats.frames, steps: game.stats.steps };
        const w = r.world;
        return {
          screen: game.screen, board: r.screen, outcome: r.outcome, edition: r.edition,
          hero: { tx: r.hero.tx(), ty: r.hero.ty(), aboard: r.hero.aboard }, dial: { d: +w.dial.d.toFixed(4), s: +w.dial.s.toFixed(4) },
          T: +w.T.toFixed(2), S: +w.S.toFixed(3), lakes: Object.fromEntries(Object.values(w.lakes).map((l) => [l.id, { L: +l.L.toFixed(3), I: +l.I.toFixed(3) }])),
          message: game.message, frames: game.stats.frames, steps: game.stats.steps, visibility: root.document ? root.document.visibilityState : null,
        };
      },
      start: function () { game.begin(); return root.TY.state(); },
      /* ⭐ AN AGENT CANNOT LISTEN. This is how a test proves the audio really ran: which backend was
       * chosen, how many files decoded, the live mix weights, and a count of every cue that actually
       * started. A silent green suite over silent audio is the exact §2b shape this exists against. */
      sound: function () { return game.sound ? game.sound.report() : { backend: 'none' }; },
      unlockSound: function () { if (game.sound) game.sound.unlock(); return root.TY.sound(); },
      muteToggle: function () { return game.sound ? game.sound.toggleMute() : null; },
      /* what the player has actually touched — the title prompt reads it, and a test can set it */
      devices: function () { return Object.assign({}, game.input.seen, { padIndex: game.input.padIndex }); },
    };
  }

  root.TY_GAME = { Game, install, DT, KEYS };
})(typeof globalThis !== 'undefined' ? globalThis : this);
