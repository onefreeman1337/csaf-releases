/* ================================================================================================
 * sound.js — THE YEAR, HEARD. Four arrangements of one theme, mixed live by the dial.
 * ================================================================================================
 * This is not a soundtrack laid over the game, it is the same mechanic in another sense. The four
 * .ogg files are the SAME 16 bars at the same tempo and the same length to the sample, and this file
 * plays all four at once at gains that are a triangular partition of unity over the dial angle:
 *
 *     weight(season i) = max(0, 1 − |arc(d, i)|)        arc is season.js's own signed shortest arc
 *
 * At d = 1.0 you hear summer alone. At d = 1.5 you hear summer and autumn at half each — and because
 * the arrangements share the melody's rhythm to the beat, that reads as one tune changing instrument
 * rather than two tunes fighting. Hold the dial between two seasons and the score is held there too.
 *
 * ⛔ TWO BACKENDS, AND THE REASON IS THE PAID DOWNLOAD (wing §8a rule 2 and §2a).
 *   http(s)  WEB AUDIO. decodeAudioData gives four AudioBuffers started at ONE ctx.currentTime, so
 *            they are sample-locked forever and each gets its own GainNode.
 *   file://   BARE <audio> ELEMENTS. fetch and XHR are both blocked there, so decodeAudioData can
 *            never run. ⛔ The elements are NOT fed to createMediaElementSource and crossOrigin is
 *            NEVER set — both of those produce SILENCE on file:// and that silence has shipped in
 *            this wing before. Volume is driven on el.volume directly, and because four independent
 *            media elements have no shared clock, this backend RE-SYNCS them (see resync below).
 *
 * ⛔ NO AUTOPLAY. Nothing makes a sound until the player's first key or tap; a browser that refuses
 * the resume is recorded and the game carries on silent rather than throwing.
 *
 * ⭐ THE HARNESS DOOR. An agent cannot listen, so this object REPORTS: which backend it chose, what
 * loaded, what failed, the live weights, and a count of every cue actually played. `report()` is how
 * the test harness proves sound happened without hearing it.
 *
 * LICENCE: every file it loads was composed in Internal_Ops/Audio/compose.js and rendered by
 * oscillator. CSAF's own IP, no attribution owed, and no Gen-AI audio tag (master §4.1).
 * ---------------------------------------------------------------------------------------------- */
'use strict';

(function (root) {
  var SEASON = root.TY_SEASON;
  var SEASONS = ['spring', 'summer', 'autumn', 'winter'];
  var MUSIC = ['mus_spring', 'mus_summer', 'mus_autumn', 'mus_winter'];
  var CUES = ['sfx_turn', 'sfx_step', 'sfx_crack', 'sfx_splash', 'sfx_board',
    'sfx_ashore', 'sfx_read', 'sfx_screen', 'sfx_ui', 'sfx_end'];

  /* how often one cue may retrigger, in seconds — a walking player must not be machine-gunned */
  var MIN_GAP = { sfx_step: 0.20, sfx_turn: 0.16, sfx_crack: 0.45, sfx_ui: 0.08 };
  var DEFAULT_GAP = 0.05;

  var STORE_KEY = 'ty.muted';
  var MUSIC_GAIN = 0.55, SFX_GAIN = 0.75;

  /* The audio lives beside the code (`js/` and `audio/` are siblings), so the base comes from THIS
   * script's own URL — true for every page that loads it, wherever that page lives. The art loader
   * learned this the hard way in the art stage: a page-relative path 404s from a second directory. */
  var BASE = (function () {
    try {
      var s = (typeof document !== 'undefined' && document.currentScript && document.currentScript.src) || '';
      if (s) return s.slice(0, s.lastIndexOf('/') + 1) + '../audio/';
    } catch (e) { /* fall through */ }
    return 'audio/';
  })();

  var IS_FILE = (function () {
    try { return String(root.location && root.location.protocol) === 'file:'; } catch (e) { return false; }
  })();

  /* ---- the mix law ----------------------------------------------------------------------------
   * ⭐ ONE function, exported, and the test harness asserts against IT rather than against a copy —
   * a rule restated in a checker is the same defect as a measurement copied into a listing. */
  function weights(d) {
    var w = [0, 0, 0, 0], sum = 0, i;
    for (i = 0; i < 4; i++) {
      var a = Math.abs(SEASON.arc(d, i));
      w[i] = a >= 1 ? 0 : 1 - a;
      sum += w[i];
    }
    /* the triangular kernel already sums to 1 for any d; normalise anyway so a future kernel change
     * cannot silently make the whole score louder or quieter */
    if (sum > 0) for (i = 0; i < 4; i++) w[i] /= sum;
    return w;
  }

  function Sound() {
    this.backend = null;            /* 'webaudio' | 'media' | 'none' */
    this.ready = false;             /* the music is actually running */
    this.loaded = { music: 0, cues: 0 };
    this.errors = [];
    this.played = {};               /* cue name -> how many times it really started */
    this.lastAt = {};
    this.muted = false;
    this.weights = [1, 0, 0, 0];
    this.dial = 0;
    this.unlockTried = false;
    this.t = 0;                     /* seconds of game time, for the cue throttle */
    try {
      var m = root.localStorage && root.localStorage.getItem(STORE_KEY);
      this.muted = m === '1';
    } catch (e) { /* storage can be denied; silence is not a crash */ }
    for (var i = 0; i < CUES.length; i++) { this.played[CUES[i]] = 0; this.lastAt[CUES[i]] = -99; }
  }

  /* ---- loading ---------------------------------------------------------------------------------
   * Kicked off immediately; nothing SOUNDS until unlock(). */
  Sound.prototype.load = function () {
    var self = this;
    if (IS_FILE) return this._loadMedia();
    if (!root.AudioContext && !root.webkitAudioContext) {
      this.errors.push('no AudioContext in this browser — falling back to media elements');
      return this._loadMedia();
    }
    try {
      var Ctx = root.AudioContext || root.webkitAudioContext;
      this.ctx = new Ctx();
      this.master = this.ctx.createGain();
      this.musicBus = this.ctx.createGain();
      this.sfxBus = this.ctx.createGain();
      this.musicBus.gain.value = MUSIC_GAIN;
      this.sfxBus.gain.value = SFX_GAIN;
      this.master.gain.value = this.muted ? 0 : 1;
      this.musicBus.connect(this.master);
      this.sfxBus.connect(this.master);
      this.master.connect(this.ctx.destination);
      this.backend = 'webaudio';
    } catch (e) {
      this.errors.push('AudioContext failed: ' + e.message);
      return this._loadMedia();
    }
    this.buffers = {};
    this.gains = [];
    MUSIC.concat(CUES).forEach(function (name) {
      root.fetch(BASE + name + '.ogg')
        .then(function (r) { if (!r.ok) throw new Error(name + '.ogg ' + r.status); return r.arrayBuffer(); })
        .then(function (ab) {
          return new Promise(function (res, rej) {
            /* the callback form: Safari still does not return a promise from decodeAudioData */
            var p = self.ctx.decodeAudioData(ab, res, rej);
            if (p && p.then) p.then(res, rej);
          });
        })
        .then(function (buf) {
          self.buffers[name] = buf;
          if (MUSIC.indexOf(name) >= 0) self.loaded.music++; else self.loaded.cues++;
          if (self.loaded.music === MUSIC.length && self.wantMusic) self._startWebAudio();
        })
        .catch(function (e) { self.errors.push(String(e.message || e)); });
    });
    return this;
  };

  Sound.prototype._loadMedia = function () {
    var self = this;
    this.backend = 'media';
    this.els = {};
    this.pool = {};
    MUSIC.forEach(function (name) {
      var el = new root.Audio();
      /* ⛔ NO crossOrigin. Setting it on a file:// source is one of the two ways this wing has
       * shipped a silent paid download. */
      el.src = BASE + name + '.ogg';
      el.loop = true;
      el.preload = 'auto';
      el.volume = 0;
      el.addEventListener('canplaythrough', function () { self.loaded.music++; }, { once: true });
      el.addEventListener('error', function () { self.errors.push(name + '.ogg failed to load'); });
      self.els[name] = el;
    });
    CUES.forEach(function (name) {
      /* three voices per cue so two footfalls can overlap */
      self.pool[name] = [0, 1, 2].map(function () {
        var el = new root.Audio();
        el.src = BASE + name + '.ogg';
        el.preload = 'auto';
        el.volume = 0;
        return el;
      });
      self.pool[name].next = 0;
      self.loaded.cues++;
    });
    return this;
  };

  /* ---- the first gesture ----------------------------------------------------------------------
   * ⛔ A browser that refuses is RECORDED, never thrown. Autoplay denial is one of the adversarial
   * cases the test report has to cover, and a game that dies on it is worse than a silent one. */
  Sound.prototype.unlock = function () {
    if (this.ready || this.unlockTried) return;
    this.unlockTried = true;
    this.wantMusic = true;
    var self = this;
    if (this.backend === 'webaudio') {
      var go = function () {
        if (self.loaded.music === MUSIC.length) self._startWebAudio();
        self.ready = self.live();
      };
      if (this.ctx.state === 'suspended') {
        var p = this.ctx.resume();
        if (p && p.catch) p.then(go, function (e) { self.errors.push('autoplay denied: ' + (e && e.message ? e.message : e)); self.unlockTried = false; });
        else go();
      } else go();
    } else if (this.backend === 'media') {
      var started = 0;
      MUSIC.forEach(function (name) {
        var el = self.els[name];
        var p = el.play();
        if (p && p.catch) {
          p.then(function () { started++; self.unlocked = true; self.ready = true; },
            function (e) { self.errors.push('autoplay denied: ' + (e && e.message ? e.message : e)); self.unlockTried = false; });
        } else { started++; self.unlocked = true; self.ready = true; }
      });
      this.mediaEpoch = root.performance ? root.performance.now() : Date.now();
    }
  };

  /* ⛔ IS THE AUDIO ACTUALLY LIVE? `ready` used to mean "the music sources were created", and that
   * is NOT the same question — the sources get created as soon as the four files decode, even into
   * a context the browser has REFUSED to resume, and the flag then reported a running score over
   * silence. MEASURED by the autoplay-denied arm of verify_audio_input.js, which read ready:true
   * while resume() was rejecting. The context's own state is the only honest answer. */
  Sound.prototype.live = function () {
    if (this.backend === 'webaudio') return !!(this.ctx && this.ctx.state === 'running');
    if (this.backend === 'media') return !!this.unlocked;
    return false;
  };

  Sound.prototype._startWebAudio = function () {
    if (this.sources || !this.ctx) return;
    var self = this, at = this.ctx.currentTime + 0.08;
    this.sources = [];
    MUSIC.forEach(function (name, i) {
      var src = self.ctx.createBufferSource();
      src.buffer = self.buffers[name];
      src.loop = true;
      var g = self.ctx.createGain();
      g.gain.value = self.weights[i];
      src.connect(g); g.connect(self.musicBus);
      /* ⭐ ONE start time for all four. This is the whole reason the four files must be the same
       * length: started together and looped forever, they never drift by a single sample. */
      src.start(at);
      self.sources.push(src); self.gains.push(g);
    });
    this.ready = this.live();
  };

  /* ---- per frame ------------------------------------------------------------------------------- */
  Sound.prototype.setDial = function (d, dt) {
    this.t += (dt || 0);
    this.dial = d;
    var w = weights(d);
    this.weights = w;
    var i;
    if (this.backend === 'webaudio' && this.gains.length === 4) {
      for (i = 0; i < 4; i++) {
        /* a short time constant, so a fast turn does not zipper */
        this.gains[i].gain.setTargetAtTime(w[i], this.ctx.currentTime, 0.05);
      }
    } else if (this.backend === 'media' && this.els) {
      var mul = this.muted ? 0 : MUSIC_GAIN;
      for (i = 0; i < 4; i++) {
        var el = this.els[MUSIC[i]];
        if (el) { var v = w[i] * mul; el.volume = v < 0 ? 0 : (v > 1 ? 1 : v); }
      }
      this._resync();
    }
  };

  /* ⛔ FOUR MEDIA ELEMENTS HAVE NO SHARED CLOCK. They start together and drift, and `loop` restarts
   * each one on its own schedule — so on the file:// backend the four arrangements have to be pulled
   * back together or the year slowly smears. Checked every two seconds and only corrected past a
   * threshold a seek would not itself cause. */
  Sound.prototype._resync = function () {
    if (!this.live() || this.t - (this._lastResync || 0) < 2) return;
    this._lastResync = this.t;
    var lead = this.els[MUSIC[0]];
    if (!lead || !lead.duration) return;
    var worst = 0;
    for (var i = 1; i < 4; i++) {
      var el = this.els[MUSIC[i]];
      if (!el || !el.duration) continue;
      var dev = Math.abs(el.currentTime - lead.currentTime);
      if (dev > lead.duration / 2) dev = lead.duration - dev;      /* one wrapped, the other had not */
      if (dev > worst) worst = dev;
      if (dev > 0.06) { try { el.currentTime = lead.currentTime; } catch (e) { /* seeking can throw mid-load */ } }
    }
    this.maxDrift = Math.max(this.maxDrift || 0, worst);
  };

  /* ---- cues ------------------------------------------------------------------------------------ */
  /* ⛔ A CUE MUST NOT WAIT FOR THE MUSIC. `ready` only turns true once all four 360 kB arrangements
   * have DECODED, and gating cues on it swallowed every sound the player made until then — on a slow
   * connection that is several seconds of a game that feels dead, and the very first press (the one
   * that leaves the title) was swallowed every single time, because unlock() resolves a promise and
   * the cue is fired on the next frame. MEASURED: sfx_ui x0 over a full session.
   * The honest condition is the one that matters per cue: is the output live, and is THIS buffer in? */
  Sound.prototype.cue = function (name, gain) {
    if (this.muted || !this.live()) return false;
    if (CUES.indexOf(name) < 0) { this.errors.push('unknown cue ' + name); return false; }
    var gap = MIN_GAP[name] == null ? DEFAULT_GAP : MIN_GAP[name];
    if (this.t - this.lastAt[name] < gap) return false;
    this.lastAt[name] = this.t;
    var g = gain == null ? 1 : gain;
    if (this.backend === 'webaudio') {
      var buf = this.buffers && this.buffers[name];
      if (!buf) return false;
      var src = this.ctx.createBufferSource();
      src.buffer = buf;
      var node = this.ctx.createGain();
      node.gain.value = g;
      src.connect(node); node.connect(this.sfxBus);
      src.start();
    } else if (this.backend === 'media') {
      var pool = this.pool && this.pool[name];
      if (!pool) return false;
      var el = pool[pool.next % pool.length];
      pool.next++;
      /* ⛔ el.volume is driven explicitly — mute must reach the media path too (wing §2a) */
      el.volume = this.muted ? 0 : Math.min(1, g * SFX_GAIN);
      try { el.currentTime = 0; } catch (e) { /* a cue still loading cannot seek */ }
      var p = el.play();
      if (p && p.catch) p.catch(function () { /* a denied cue is not a crash */ });
    } else return false;
    this.played[name]++;
    return true;
  };

  /* ---- mute ------------------------------------------------------------------------------------ */
  Sound.prototype.setMuted = function (on) {
    this.muted = !!on;
    try { root.localStorage && root.localStorage.setItem(STORE_KEY, this.muted ? '1' : '0'); } catch (e) { /* denied storage is fine */ }
    if (this.backend === 'webaudio' && this.master) {
      this.master.gain.setTargetAtTime(this.muted ? 0 : 1, this.ctx.currentTime, 0.02);
    } else if (this.backend === 'media' && this.els) {
      /* ⛔ drive el.volume in the SAME edit that sets the flag — a mute that only sets a boolean is
       * the wing's §2a defect verbatim */
      var mul = this.muted ? 0 : MUSIC_GAIN;
      for (var i = 0; i < 4; i++) { var el = this.els[MUSIC[i]]; if (el) el.volume = this.weights[i] * mul; }
    }
    return this.muted;
  };
  Sound.prototype.toggleMute = function () { return this.setMuted(!this.muted); };

  /* ---- the harness door ------------------------------------------------------------------------
   * ⭐ I cannot hear. This is how a test proves a cue fired, the mix moved and nothing 404'd. */
  Sound.prototype.report = function () {
    var total = 0;
    for (var k in this.played) if (Object.prototype.hasOwnProperty.call(this.played, k)) total += this.played[k];
    return {
      backend: this.backend, ready: this.ready, live: this.live(), muted: this.muted,
      loaded: { music: this.loaded.music, cues: this.loaded.cues },
      expected: { music: MUSIC.length, cues: CUES.length },
      weights: this.weights.map(function (x) { return +x.toFixed(4); }),
      dial: +this.dial.toFixed(4),
      played: this.played, cuesPlayed: total,
      maxDrift: this.maxDrift == null ? null : +this.maxDrift.toFixed(4),
      base: BASE, errors: this.errors.slice(0, 8),
    };
  };

  var API = { Sound: Sound, weights: weights, MUSIC: MUSIC, CUES: CUES, SEASONS: SEASONS, BASE: BASE };
  root.TY_SOUND = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof globalThis !== 'undefined' ? globalThis : this);
