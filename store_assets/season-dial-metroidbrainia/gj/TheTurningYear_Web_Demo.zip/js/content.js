/* ================================================================================================
 * content.js — THE FREE YEAR: the Meadow and the Mere. Loaded by BOTH editions.
 * ================================================================================================
 * ⛔ WING §1-DEMO: paid content is a FILE the free build does not load, never a branch it does not
 * take. Everything past the Mere — the Fell, the Dunes, the drowned door's ending — lives in
 * content_full.js. This file must never name a paid screen, a paid text or the ending's words;
 * `proto/_content_selftest.js` greps the shipped bytes for them.
 *
 * THE MERE'S THREE ROADS (DESIGN.md §7, revised 2026-09-10 after bar D1 measured the first layout at a
 * thin 6.2x): the island is the BOAT'S alone — ringed by a warm spring (`h`) that never freezes and walled
 * on its west face by the shrine (`w`) — and the boat reaches it only through the old sluice (`f`), whose
 * sill wants the Mere above 4.0 and whose lintel wants it at or below 4.3. The drowned door sits at the
 * shrine's foot on the terrace (`D`), across the cold moat, and wants the Mere between 0 and 1 and frozen.
 *
 * MAP FORMAT. Each board is 20 x 10 tiles. `terrain` uses world.js's LEGEND; `elev` gives each tile's
 * elevation (0-9, `m` = −1). A lake-bed tile's surface is its lake's level while it is under water.
 * Heights are the puzzle: a step is legal only within 1 (world.js P.STEP).
 * ---------------------------------------------------------------------------------------------- */
'use strict';

(function (root) {
  const CONTENT = {
    edition: 'free',
    lands: {
      meadow: { home: 0, name: 'The Meadow' },
      mere: { home: 0, name: 'The Mere' },
    },
    lakes: {
      /* the brook is spring-fed (minL 3): only ICE crosses it, and from the first minute */
      brook: { L0: 3.4, kf: 0.024, km: 0.025, g: 0.25, ke: 0.012, capL: 3.9, minL: 3.0 },
      /* the river always runs (minL 4.1), so its ice is always at a height you can step onto */
      river: { L0: 4.3, kf: 0.018, km: 0.006, g: 0.5, ke: 0.012, capL: 4.9, minL: 4.1 },
      /* THE MERE: floods to 5 with snowmelt, drains to an empty moat under a long summer. The boat's
       * window is (4.0, 4.3]: from 2.5 that is 1.9 to 2.25 units of melted snow (g = 0.8). */
      mere: { L0: 2.5, kf: 0.03, km: 0.025, g: 0.8, ke: 0.012, capL: 5.0, minL: -1.0 },
    },
    start: { screen: 'meadow', x: 2, y: 2, d: 0 },
    screens: [
      {
        id: 'meadow', col: 0, row: 1, land: 'meadow', lake: 'brook',
        terrain: [
          'TTTTTTTTT~~~TTTTTTTT',
          'T.r..T...~~~...T...T',
          'T.@......~~~.......T',
          'T...s....~~~.......,',
          'T........~~~....,,,,',
          'T..R.....~~~...,,...',
          'T........~~~.......,',
          'T..T.....~~~..R....T',
          'T.r......~~~.......T',
          'TTTTTTTTT~~~TTTTTTTT',
        ],
        elev: [
          '55555555422245555555',
          '55555555422245555555',
          '55555555422245555555',
          '55555555422245555555',
          '55555555422245555555',
          '55555555422245555555',
          '55555555422245555555',
          '55555555422245555555',
          '55555555422245555555',
          '55555555422245555555',
        ],
        signs: { '4,3': 'sign.meadow' },
      },
      {
        id: 'mere', col: 1, row: 1, land: 'mere', lake: 'mere', lake2: 'river',
        /* ⛔ A TILE THAT IS NEVER UNDER WATER IS LAND, NOT LAKE BED. The six points below (2,3) (6,3)
         * (7,3) (16,3) (2,7) (8,7) sit at elevation 5, at or above the Mere's 5.0 cap, so they are dry
         * at every level the lake can reach. Left as lake bed they rendered as `mud` — and a dry bed
         * tile in the middle of a shoreline photographs as a BROWN SQUARE DROPPED ON THE WATER, which
         * is what the first cut of this shoreline actually shipped into a capture. Seen, not measured:
         * the shoreline gate was green over that picture, because the OUTLINE was right and the
         * MATERIAL was wrong (wing §0z-1: a numeric proof is not proof it is visible). As land they
         * take the meadow's own grass and the derived bank wraps them, so they read as headlands.
         * ⚠️ Tiles that are dry only at SOME levels stay lake bed on purpose — exposed mud is exactly
         * what a draining lake should show. */
        terrain: [
          '====================',
          '====================',
          's..................T',
          '...~~f..~~~~hhhh..TT',
          /* ⛔ THE SECOND SIGN IS A STONE, NOT A SECOND POST — round-4 minor 10: "two near-identical
           * signposts stand one tile apart on the Mere's left edge ... the fix is new art, not a
           * move" (they carry different text, so neither can go). `g` is the glyph stone, which is
           * readable exactly as `s` is and is now a broken column drum rather than a timber post, so
           * the pair reads as two different things a player can read. */
          'g.~~~f~~~~~~wIIh~..T',
          '..o~~f~~~~~DwBIh~..T',
          '..~~~f~~~~~~wIIh~.TT',
          '...~~f~~.~~~hhhh~.TT',
          '...................T',
          'TTTTTTTTTTTTsT,,,TTT',
        ],
        /* THE BED IS THE SHORELINE. A tile is under water iff its elevation is below the lake's level
         * (world.js `surface()`: `t.e >= L` is dry bed), so this grid is not depth data with a shore
         * drawn on top of it — it IS the shore, at every level the Mere reaches, and a bed of uniform
         * runs draws a rectangle. It did: two art-director rounds and an independent reviewer each
         * named "the Mere is a rectangle with straight shores" without being shown the others.
         *
         * So the rim is cut rather than filled. Reading the numbers as a map: a stony spit at the two
         * west corners and one on the south shelf (5 — above the 5.0 cap, so never flooded), a rocky
         * point beside the sluice at (6,3), and a south shelf that drains in pieces (3/4/5) instead of
         * all at once. The waterline therefore MIGRATES and stays irregular through the whole range,
         * which is the game's own subject: the shape of the shore tells you the level.
         *
         * ⛔ LOAD-BEARING, DO NOT SCULPT (proved by proto/_level_selftest.js over 726 checks):
         * col 5 rows 3-7 the sluice sill, (11,5) the drowned door at elevation 1 (its window is
         * 0 <= L <= 1, closed at 1 because the tile is dry at L = 1 exactly), the `m` ring that walls
         * the island, cols 12-14 the island itself, and (2,5) where the boat moors. Row 5 is untouched
         * on purpose: it carries the boat, the mooring and the door.
         * Gate: proto/_shoreline_selftest.js. Aid: Internal_Ops/Art/_probe_waterline.js. */
        /* ⛔ AND THE EAST BANK WAS A RULED LINE — round-4 minor 7: "the left and right banks of the
         * open water run dead-straight columns (18 distinct edge-x over 344 rows, 61.6% on 16+ tile
         * straight runs), so the basin reads as a channel between two walls rather than a natural
         * shore." MEASURED on this grid before editing: the WEST edge already steps 3-2-1-1-3 across
         * rows 3..7 and is not the offender; the EAST edge stood at column 16 for four rows running.
         * Two cells move it, and neither is on the load-bearing list above: (17,4) drops to 3 so the
         * water reaches a column further east on that row, and (16,6) rises to 5 — above the cap, so
         * never flooded — which cuts a notch back. The east edge now steps 16-17-16-15-16 and no bank
         * is a straight column for more than two tiles. Row 5 is untouched, as its own note requires. */
        elev: [
          '22222222222222222222',
          '33333333333333333333',
          '55555555555555555555',
          '5553235512mmmmmm5555',
          '5532231111mm555m2355',
          '5422232222m1555m2555',
          '5322333333mm555m5555',
          '5554443453mmmmmm2555',
          '55555555555555555555',
          '55555555555555555555',
        ],
        /* ⛔ a readable stone is a BLOCK: never put one in a one-tile corridor (2026-09-10: the south
         * sign at (13,8) cut the Mere off from the Dunes road, found by the full knower) */
        signs: { '0,2': 'sign.mere.north', '0,4': 'sign.sluice', '12,9': 'sign.mere.south', '13,5': 'inscription' },
      },
    ],
    texts: {
      /* ⛔ {TURN} IS A TOKEN, NOT A TYPO, and it exists because this sign used to read "Hold Q or E".
       * That is the game's FIRST teaching sign, and after the polish stage it was naming a key that
       * two of the four supported input paths do not have: a phone has no Q, and neither does a
       * gamepad. The renderer substitutes it for whatever the player is actually holding. */
      'sign.meadow': 'Hold {TURN} to turn the year. Let go, and it turns back.',
      'sign.mere.north': 'The river comes down from the Fell, where winter never leaves.',
      'sign.mere.south': 'South, the road to the Dunes, where it is always summer.',
      'inscription': 'The door lies below the lowest water.',
      'sign.sluice': 'The old sluice. The boat passes when the water clears the sill and not the lintel.',
      /* ⚠️ This line used to enumerate what lies past the Mere, and once the buy line below started
       * naming the same two places the card said the same thing twice in two colours — which reads
       * as padding, not as a pitch. Flavour here; the concrete offer is `demo.buy`. LOOKED AT in
       * Internal_Ops/Playtest/screens/10_demo_end.png, which is how the duplication was caught. */
      'demo.end': 'The free year ends here, at the edge of the Mere. The year itself goes on.',
      /* the OTHER way the free year ends — the player has just stepped onto the dry door, so they
       * are not told to go and look for it (see render.js demoEnd) */
      'demo.end.door': 'You found the door under the water, and the free year ends at its step.',
      /* ⚠️ EVERY CLAIM HERE IS CHECKED AGAINST THE PAID FILE, AND THE FIRST DRAFT WAS WRONG.
       * It promised three boards including one read off the paid file's land table that no screen
       * uses — dead data that read as a feature. Store copy is a claim about the product, so it is
       * checked against the product: verify_artefact.js asserts that no free text names a land no
       * screen uses. The two places named below are already named in the free build on purpose, in
       * two signs at the Mere, which is the demo doing its job.
       * ⛔ Do not write the paid file's internal ids into this file, even in a comment: the demo
       * split gate searches these bytes for them and cannot tell prose from data.
       * No price and no URL: the web build is embedded on the store page, where the price is. */
      'demo.buy': 'The full year adds the Fell and the Dunes, and the ending the door opens.',
      /* ⛔⛔ THE OFFER, ON THE ONE SCREEN THAT CONVERTS. Round-4 major 4: the card named what the full
       * year adds and then stopped — "no price and no available-now call to action" — on the screen a
       * player reaches at the moment of highest intent. This is the whole offer: what it costs and
       * where it is. No URL, deliberately: the demo runs EMBEDDED on the itch listing, so the buy
       * button is already above this canvas and a printed address could not be verified from inside
       * the game.
       * ⛔ THE PRICE IS A CLAIM ABOUT THE PRODUCT, SO IT IS GATED, NOT TYPED AND FORGOTTEN:
       * `proto/_suites.js` reads Wings/Games/state.json's priceUSD for this project and requires this
       * string to carry that number. A price that moves on the store and not in the build is a lie
       * the buyer reads first (§2b: an assert must RE-DERIVE, never hold its own copy). */
      /* ⚠️ SHORT ENOUGH FOR THE CARD, MEASURED: the plate's inner width is 256 px and the body face
       * advances 6 px, so 42 characters is the ceiling and the first draft ran off both edges of the
       * card in `10_demo_end.png`. Counted here rather than trusted: 36. */
      'demo.cta': 'The full game is on this page: $9.99',
      /* ⚠️ This line no longer names a cause. The cause is `run.outcome.why`, drawn above it by
       * render.js — this is the close, not the report, so that a drowning in open water is not
       * announced as ice giving way. */
      'lose': 'The year took you.',
    },
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = CONTENT;
  root.TY_CONTENT = (root.TY_CONTENT || []).concat([CONTENT]);
})(typeof globalThis !== 'undefined' ? globalThis : this);
