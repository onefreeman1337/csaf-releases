/* ================================================================================================
 * run.js — ONE PLAY OF THE YEAR: the hero, the boat, and the rules that end a run. The browser shell
 * and every bot drive THIS object with the same inputs, so a bot's verdict is a verdict on the game.
 * ================================================================================================
 * Input per step: { dx, dy } in [−1, 1] (walk or sail), `turn` in [−1, 1] (the held dial), and
 * `interact` (an EDGE: read the stone you face).
 *
 * ⭐ The hero stands on a SURFACE, never on a tile: `world.surface()` says how high the ground under
 * each foot is, and a step is legal only within P.STEP. Ice is a surface at the lake's level; when it
 * thins out from under you, you fall. That is the one hard fail (DESIGN.md §5, T6 loss mode 1).
 *
 * ⛔ The caller owns the clock (wing §6b-2); nothing here reads real time.
 * ⛔ Every refusal records its reason (`hero.lastRefusal`), wing §0z-1c.
 * ---------------------------------------------------------------------------------------------- */
'use strict';

(function (root) {
  const isNode = (typeof require === 'function' && typeof module !== 'undefined');
  const WORLD = isNode ? require('./world.js') : root.TY_WORLD;
  const { TILE, SCREEN_W, SCREEN_H, P } = WORLD;

  const H = Object.freeze({
    SPEED: 64,          /* px/s walking: four tiles a second */
    BOAT_SPEED: 56,     /* px/s sailing */
    HX: 4, HY: 3,       /* feet box half-extents, px */
    BOAT_R: 6,          /* boat hull half-extent, px */
    BOARD_R: 24,        /* px: how near a boat must be to step into it */
    STILL_PX: 0.3,      /* moving less than this in a step counts as standing still */
  });

  function tileOf(px) { return Math.floor(px / TILE); }

  function Hero(x, y) {
    this.x = x; this.y = y;
    this.fx = 0; this.fy = 1;        /* facing, for reading stones */
    this.aboard = -1;                /* index into world.boats, or −1 */
    this.still = 0;                  /* seconds standing still on thin ice */
    this.lastRefusal = null;
    this.moved = 0;
  }
  Hero.prototype.clone = function () { return Object.assign(new Hero(0, 0), this); };
  Hero.prototype.tx = function () { return tileOf(this.x); };
  Hero.prototype.ty = function () { return tileOf(this.y); };

  /* the tiles a feet box centred at (x, y) overlaps */
  function boxTiles(x, y, hx, hy) {
    const out = [];
    const x0 = tileOf(x - hx), x1 = tileOf(x + hx - 1e-6), y0 = tileOf(y - hy), y1 = tileOf(y + hy - 1e-6);
    for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) out.push([tx, ty]);
    return out;
  }

  function supportHeight(world, hero) {
    const s = world.surface(hero.tx(), hero.ty());
    return s.h;
  }

  /* can a foot at support height `hs` step onto (tx, ty)? */
  function enterable(world, tx, ty, hs) {
    const s = world.surface(tx, ty);
    if (!s.walk) return { ok: false, why: s.why, s };
    if (hs == null) return { ok: false, why: 'nothing underfoot', s };
    const dh = s.h - hs;
    if (dh > P.STEP + 1e-9) return { ok: false, why: 'too high to climb', s };
    if (dh < -P.STEP - 1e-9) return { ok: false, why: 'too far to drop', s };
    return { ok: true, s };
  }

  /* ================================================================================================ */
  function Run(contentList) {
    this.world = new WORLD.World(contentList);
    const st = this.world.start;
    const sc = this.world.screens[st.screen];
    if (!sc) throw new Error('Run: start screen ' + st.screen + ' is not in the loaded content');
    const tx = sc.col * SCREEN_W + st.x, ty = sc.row * SCREEN_H + st.y;
    this.hero = new Hero((tx + 0.5) * TILE, (ty + 0.5) * TILE);
    this.edition = contentList.some((c) => c.edition === 'full') ? 'full' : 'free';
    this.screen = st.screen;
    this.outcome = null;             /* null | {kind:'lost'|'demoEnd'|'ending', why} */
    this.flags = { inscriptionRead: false };
    this.lastHome = this.world.homeAt(tx, ty);
    this.snap = null;
    this.stats = { steps: 0, falls: 0, retries: 0, reads: 0, boardings: 0, screens: 1 };
    this.snap = this.snapshot();
  }

  Run.prototype.snapshot = function () {
    return { world: this.world.snapshot(), hero: this.hero.clone(), screen: this.screen, flags: Object.assign({}, this.flags), lastHome: this.lastHome };
  };
  Run.prototype.restore = function (s) {
    this.world.restore(s.world);
    this.hero = s.hero.clone();
    this.screen = s.screen; this.flags = Object.assign({}, s.flags); this.lastHome = s.lastHome;
  };
  /* Retry the board you are on, from the moment you entered it. */
  Run.prototype.retry = function () {
    this.restore(this.snap);
    this.outcome = null;
    this.stats.retries++;
  };

  Run.prototype.home = function () {
    const h = this.world.homeAt(this.hero.tx(), this.hero.ty());
    if (h != null) this.lastHome = h;
    return this.lastHome;
  };

  /* One fixed step. Returns the events it produced. */
  Run.prototype.step = function (dt, input) {
    const ev = [];
    if (this.outcome) return ev;
    input = input || {};
    const w = this.world, hero = this.hero;
    w.step(dt, input.turn || 0, this.home());

    if (hero.aboard >= 0) this._sail(dt, input, ev);
    else this._walk(dt, input, ev);

    /* what is under the feet NOW — after the world moved and the hero moved */
    if (hero.aboard < 0) {
      const s = w.surface(hero.tx(), hero.ty());
      if (s.kind === 'water') { this._lose(s.why === 'open water' ? 'the ice melted from under you' : s.why, ev); return ev; }
      if (s.kind === 'thin') {
        if (hero.moved < H.STILL_PX) hero.still += dt; else hero.still = 0;
        if (hero.still >= P.THIN_BREAK_S) {
          w.breakIce(hero.tx(), hero.ty());
          this._lose('the thin ice gave way under you', ev);
          return ev;
        }
        if (hero.still > 0.35) ev.push({ k: 'crack', t: hero.still });
      } else hero.still = 0;
      /* the drowned door: only a DRY door is a door */
      if (s.t && s.t.door && s.kind === 'bed') {
        this.outcome = { kind: this.edition === 'full' ? 'ending' : 'demoEnd', why: 'door' };
        ev.push({ k: this.outcome.kind });
        return ev;
      }
    }

    if (input.interact) this._interact(ev);

    const scr = w.screenOf(hero.tx(), hero.ty());
    if (scr && scr !== this.screen) {
      ev.push({ k: 'screen', from: this.screen, to: scr });
      this.screen = scr;
      this.stats.screens++;
      this.pendingSnap = true;
    }
    /* ⛔ THE RETRY POINT IS TAKEN ON SOLID FOOTING, NEVER ON ICE. Measured 2026-09-10 by the D4
     * wanderer (seed 17: 804 falls in 900 s): a board entered FROM the river ice snapshotted the hero
     * standing on melting ice, so every retry restored a death. Until the hero stands on ground in
     * the new board, a fall retries the previous board's snapshot instead. */
    if (this.pendingSnap && hero.aboard < 0) {
      const s = w.surface(hero.tx(), hero.ty());
      if (s.kind === 'ground' || s.kind === 'bed') { this.snap = this.snapshot(); this.pendingSnap = false; this.stats.snaps = (this.stats.snaps || 0) + 1; }
    }
    this.stats.steps++;
    return ev;
  };

  Run.prototype._lose = function (why, ev) {
    this.outcome = { kind: 'lost', why };
    this.stats.falls++;
    ev.push({ k: 'lost', why });
  };

  Run.prototype._walk = function (dt, input, ev) {
    const w = this.world, hero = this.hero;
    let dx = Math.max(-1, Math.min(1, +input.dx || 0)), dy = Math.max(-1, Math.min(1, +input.dy || 0));
    const mag = Math.hypot(dx, dy);
    if (mag > 1) { dx /= mag; dy /= mag; }
    if (dx || dy) { hero.fx = Math.sign(dx) || 0; hero.fy = Math.sign(dy) || 0; if (Math.abs(dx) > Math.abs(dy)) hero.fy = 0; else if (Math.abs(dy) > Math.abs(dx)) hero.fx = 0; }
    const x0 = hero.x, y0 = hero.y;
    const tryAxis = (nx, ny) => {
      const hs = supportHeight(w, hero);
      const cur = new Set(boxTiles(hero.x, hero.y, H.HX, H.HY).map((a) => a[0] + ',' + a[1]));
      for (const [tx, ty] of boxTiles(nx, ny, H.HX, H.HY)) {
        if (cur.has(tx + ',' + ty)) continue;
        const r = enterable(w, tx, ty, hs);
        if (!r.ok) {
          hero.lastRefusal = { tx, ty, why: r.why };
          if (this._tryBoard(tx, ty, hs, ev)) return 'boarded';
          return false;
        }
      }
      /* ⛔ A SUCCESSFUL MOVE CLEARS THE REASON. Without this, `lastRefusal` is a high-water mark
       * that never resets, so "is the hero being refused right now" is unanswerable and any reader
       * of it shows a stale sentence about a wall the player left a minute ago. The field existed
       * for four sessions with no reader at all (the art director's major defect 12: "written in
       * four places and read nowhere ... the reason is computed and discarded"), and wing §0z-1c
       * says a dead reader is an untested code path — so the reader and the writer are fixed in the
       * same edit, which is what that rule actually asks for. */
      hero.lastRefusal = null;
      hero.x = nx; hero.y = ny;
      return true;
    };
    const step = H.SPEED * dt;
    if (dx) { const r = tryAxis(hero.x + dx * step, hero.y); if (r === 'boarded') { hero.moved = 1; return; } }
    if (dy) { const r = tryAxis(hero.x, hero.y + dy * step); if (r === 'boarded') { hero.moved = 1; return; } }
    hero.moved = Math.hypot(hero.x - x0, hero.y - y0);
  };

  /* step into a boat floating on the water you just bumped into */
  Run.prototype._tryBoard = function (tx, ty, hs, ev) {
    const w = this.world, hero = this.hero;
    const t = w.tile(tx, ty);
    if (!t || !t.lake) return false;
    for (let i = 0; i < w.boats.length; i++) {
      const b = w.boats[i];
      if (b.lake !== t.lake || b.grounded || b.locked) continue;
      if (Math.hypot(b.x - hero.x, b.y - hero.y) > H.BOARD_R) continue;
      const L = w.lakes[b.lake].L;
      if (hs == null || Math.abs(L - hs) > P.STEP + 1e-9) { hero.lastRefusal = { tx, ty, why: L < hs ? 'the boat sits too far below' : 'the boat rides too high' }; continue; }
      hero.aboard = i; hero.x = b.x; hero.y = b.y; hero.still = 0;
      this.stats.boardings++;
      ev.push({ k: 'board', boat: i });
      return true;
    }
    return false;
  };

  Run.prototype._sail = function (dt, input, ev) {
    const w = this.world, hero = this.hero;
    const b = w.boats[hero.aboard];
    let dx = Math.max(-1, Math.min(1, +input.dx || 0)), dy = Math.max(-1, Math.min(1, +input.dy || 0));
    const mag = Math.hypot(dx, dy);
    if (mag > 1) { dx /= mag; dy /= mag; }
    if (dx || dy) { hero.fx = Math.sign(dx) || 0; hero.fy = Math.sign(dy) || 0; }
    hero.moved = 0;
    /* a frozen or grounded boat is just something to stand on: step off the way you push */
    if (b.locked || b.grounded) {
      if (dx || dy) { hero.aboard = -1; ev.push({ k: 'disembark', why: b.locked ? 'the boat is frozen in' : 'the boat is aground' }); this._walk(dt, input, ev); }
      return;
    }
    const L = w.lakes[b.lake].L;
    const tryAxis = (nx, ny, ddx, ddy) => {
      for (const [tx, ty] of boxTiles(nx, ny, H.BOAT_R, H.BOAT_R)) {
        const r = w.boatable(tx, ty, b.lake);
        if (!r.ok) {
          /* blocked: is the way ahead a shore you can step onto? then step off */
          const ax = tileOf(b.x + ddx * (H.BOAT_R + 6)), ay = tileOf(b.y + ddy * (H.BOAT_R + 6));
          const s = w.surface(ax, ay);
          if (s.walk && Math.abs(s.h - L) <= P.STEP + 1e-9 && !(ax === tileOf(b.x) && ay === tileOf(b.y))) {
            hero.aboard = -1;
            hero.x = (ax + 0.5) * TILE; hero.y = (ay + 0.5) * TILE;
            ev.push({ k: 'disembark', why: 'shore' });
            return 'off';
          }
          hero.lastRefusal = { tx, ty, why: r.why };
          return false;
        }
      }
      b.x = nx; b.y = ny;
      return true;
    };
    const step = H.BOAT_SPEED * dt;
    if (dx) { if (tryAxis(b.x + dx * step, b.y, Math.sign(dx), 0) === 'off') return; }
    if (dy) { if (tryAxis(b.x, b.y + dy * step, 0, Math.sign(dy)) === 'off') return; }
    hero.x = b.x; hero.y = b.y;
    hero.moved = 1;
  };

  Run.prototype._interact = function (ev) {
    const w = this.world, hero = this.hero;
    const px = hero.x + hero.fx * 12, py = hero.y + hero.fy * 12;
    const t = w.tile(tileOf(px), tileOf(py));
    if (!t || !t.read || !t.sign) return;
    this.stats.reads++;
    ev.push({ k: 'read', text: t.sign });
    if (t.sign === 'inscription') {
      this.flags.inscriptionRead = true;
      if (this.edition !== 'full') { this.outcome = { kind: 'demoEnd', why: 'inscription' }; ev.push({ k: 'demoEnd' }); }
    }
  };

  const API = { H, Hero, Run, boxTiles, enterable };
  if (isNode) module.exports = API;
  root.TY_RUN = API;
})(typeof globalThis !== 'undefined' ? globalThis : this);
