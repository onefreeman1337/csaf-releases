/* ================================================================================================
 * render.js — THE LOOK. Every surface is real pack art blitted from one atlas.
 * ================================================================================================
 * WHAT CHANGED AT THE ART STAGE. The build stage shipped a placeholder renderer: one `fillRect` per
 * tile kind, flat colour, square edges. This file replaces every one of those entry points with art
 * from `verdant-seasons` (wing-tilesets' own pack, built for exactly this problem: one meadow drawn
 * four times a year) and `verdant-01-overworld`, plus a small set of tiles DERIVED from those by
 * declared, palette-closed transforms. Provenance for every key: `Internal_Ops/Art/provenance.json`.
 *
 * ⛔ CRAFT DOCTRINE `real-assets`: code-drawn rectangles are placeholders and never ship. The only
 * `fillRect` calls left in this file are the season particles and flat UI plates, which the design
 * brief's checklist explicitly exempts ("a probe counts fillRect in the render path and expects 0
 * outside particles"). `Internal_Ops/Art/_probe_real_assets.js` counts them.
 *
 * ⛔ THE YEAR DRIFTS, IT DOES NOT SNAP. The brief's Avoid list bans "a discrete season toggle
 * between four static tilesets". Every seasonal ground has 8 in-between frames per adjacent season
 * pair and the shoreline autotiles have 3, all ordered-dither mixes — so at any dial angle the
 * world is showing a real intermediate, and the ice visibly thickens under the player's feet.
 *
 * ⛔ DUAL-MODE + IIFE (wing §6b-5): this file is loaded by a <script> tag AND required by Node
 * tooling, `<script>`s share one scope so a stray `const` would kill the file, and the renderer
 * READS the model and never writes it.
 * ---------------------------------------------------------------------------------------------- */
'use strict';

(function (root) {
  var SEASON = root.TY_SEASON, WORLD = root.TY_WORLD;
  var TILE = (WORLD && WORLD.TILE) || 16;
  var SCREEN_W = (WORLD && WORLD.SCREEN_W) || 20;
  var SCREEN_H = (WORLD && WORLD.SCREEN_H) || 10;

  /**
   * ⛔ THE ART PATH IS RESOLVED FROM THIS SCRIPT, NOT FROM THE PAGE — and that is a bug fix, not a
   * preference. The first spelling was the page-relative literal `'art/'`, which is correct for
   * `Product_Release/index.html` and 404s for `Internal_Ops/proto/play_full.html`, because the two
   * pages sit in different directories. `verify_page.js` caught it as two failed requests on the
   * full build. This is exactly wing §1-BUILD: "Asset base, audio base and page names change
   * silently at build: fallback art, swallowed au(), a 404 read as the ending", whose remedy is
   * "declare the layout ONCE".
   *
   * The art lives beside the code (`js/` and `art/` are siblings), so deriving the base from this
   * script's own URL is true for every page that loads it, wherever that page lives.
   */
  var ART_BASE = (function () {
    try {
      var s = (typeof document !== 'undefined' && document.currentScript && document.currentScript.src) || '';
      if (s) return s.slice(0, s.lastIndexOf('/') + 1) + '../art/';
    } catch (e) { /* fall through to the page-relative default */ }
    return 'art/';
  })();

  var LAYOUT = {
    W: 320, H: 180,
    HUD_H: 20,
    BOARD_Y: 20,
    DIAL_X: 288, DIAL_Y: 148, DIAL_R: 26,
    /* ⭐ THE FULL-SCREEN PLATES, PUBLISHED so a test can read them instead of re-typing them.
     * A measurement copied into a checker certifies the checker (master §2b). */
    MSG: { x: 14, y: 132, w: 258, h: 40 },
    PAUSE: { x: 56, y: 48, w: 208, h: 88 }
  };

  /* the brief's palette, for UI plates and text only — every WORLD pixel comes from the atlas */
  var PAL = {
    spring: { grass: '#7FBF5A', accent: '#F2A7C4' },
    summer: { grass: '#3E8E3A', accent: '#F5D76E' },
    autumn: { grass: '#D1782F', accent: '#8C3B22' },
    winter: { grass: '#DCE9F2', accent: '#6FA3C8' },
    soil: '#4A3527', stone: '#7C7F86', water: '#2F6F9F', ink: '#1C1F2B',
    paper: '#F2F7FB', dim: '#9D948B'
  };

  var SEASON_NAMES = ['spring', 'summer', 'autumn', 'winter'];

  function hex(c) { var n = parseInt(c.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  function mix(a, b, t) {
    var A = hex(a), B = hex(b), o = [], i;
    for (i = 0; i < 3; i++) o.push(Math.round(A[i] + (B[i] - A[i]) * t));
    return 'rgb(' + o.join(',') + ')';
  }
  function hexMix(a, b, t) {
    var A = hex(a), B = hex(b), s = '#', i, v;
    for (i = 0; i < 3; i++) { v = Math.round(A[i] + (B[i] - A[i]) * t); s += (v < 16 ? '0' : '') + v.toString(16); }
    return s;
  }

  /* ⛔ THE WEATHER'S TWO TONES, PER SEASON, DERIVED — see particles_ for what a typed copy cost.
   * A mote is the season's own accent (blossom, seed, leaf, snow) with a shadow one pixel down-right,
   * and the shadow is that same accent carried toward the night ink rather than a colour chosen by
   * hand. Autumn and winter name a second tone from their OWN row; neither borrows another season's. */
  var MOTE = {
    spring: { core: PAL.spring.accent, halo: hexMix(PAL.spring.accent, PAL.ink, 0.45) },
    summer: { core: PAL.summer.accent, halo: hexMix(PAL.summer.accent, PAL.ink, 0.45) },
    autumn: { core: PAL.autumn.grass, halo: PAL.autumn.accent },
    winter: { core: PAL.paper, halo: PAL.winter.accent },
  };
  /* ⛔⛔ WEATHER HAS TO KNOW WHAT GROUND IT FALLS ON. Found by an independent reviewer, round 5c.
   *
   * MEASURED on the shipped captures before this edit (`Art/_probe_r6_reviewer.js`): the DUNES in
   * spring carried 256 px of #f2a7c4 in 16 components of exactly 4x4, and the bare FELL carried 240
   * px in 15 — i.e. all sixteen weather particles, drawing CHERRY BLOSSOM over a desert and over bare
   * rock. Zero in summer and winter, which is the tell that it is the spring row of the table and not
   * something baked.
   *
   * ⛔ THIS IS THE SAME DEFECT CLASS THE ROUND JUST CLOSED FOR AUTUMN LEAVES ON SUMMER WATER, one
   * axis over: that one was the wrong SEASON's accent, this is the right season's accent on a board
   * that has nothing to shed it. A season's accent is a thing the GROUND produces — blossom, seed,
   * leaf — so on a board with no vegetation the first three seasons blow grit and dust instead, and
   * only winter, which falls out of the sky rather than off a plant, is unchanged.
   */
  var MOTE_BARE = {
    spring: { core: PAL.dim, halo: hexMix(PAL.dim, PAL.ink, 0.45) },
    summer: { core: PAL.dim, halo: hexMix(PAL.dim, PAL.ink, 0.45) },
    autumn: { core: PAL.dim, halo: hexMix(PAL.dim, PAL.ink, 0.45) },
    winter: { core: PAL.paper, halo: PAL.winter.accent },
  };
  /* the lands that grow nothing. Declared here rather than inferred from a tile, because weather is
   * a property of the BOARD and the fell board carries a strip of vale at its foot. */
  var BARE_LANDS = { dunes: true, fell: true };
  function seasonColour(d, key) { var bl = SEASON.blend(d); return mix(PAL[bl.from][key], PAL[bl.to][key], bl.t); }

  /* a stable hash so a tile's variant never flickers between frames */
  function hash2(x, y, salt) {
    var h = (x * 374761393 + y * 668265263 + (salt || 0) * 2246822519) | 0;
    h = (h ^ (h >>> 13)) * 1274126177 | 0;
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  }

  /* ---- blob47 neighbourhood bits. ⛔ Same constants as Kernel/tilesets/blob47.js, which is the
   * module that OWNS this fact; they are restated here only because the browser cannot require it,
   * and `Internal_Ops/Art/_probe_real_assets.js` asserts the two agree (wing §5q: when a module
   * owns a fact, import it — and when you cannot, check you match). ---------------------------- */
  var B_N = 1, B_NE = 2, B_E = 4, B_SE = 8, B_S = 16, B_SW = 32, B_W = 64, B_NW = 128;
  function normaliseMask(m) {
    var r = m;
    if (!((m & B_N) && (m & B_E))) r &= ~B_NE;
    if (!((m & B_E) && (m & B_S))) r &= ~B_SE;
    if (!((m & B_S) && (m & B_W))) r &= ~B_SW;
    if (!((m & B_W) && (m & B_N))) r &= ~B_NW;
    return r & 255;
  }

  /* ============================================================================ the atlas ==== */

  function Atlas() {
    this.ready = false;
    this.failed = null;
    this.index = null;
    this.img = null;
    this.morph = null;
  }

  /**
   * Load the atlas. ⛔ A 404 must be LOUD, never silently fall back to flat colour: wing §1-BUILD
   * records a 404 being read as the ending, and a game that quietly renders placeholder art would
   * ship the exact defect this stage exists to remove.
   */
  Atlas.prototype.load = function (cb) {
    var self = this;
    if (typeof Image !== 'function') { this.failed = 'no browser image support'; if (cb) cb(this.failed); return; }
    var gotJson = null, gotImg = null;
    function done() {
      if (!gotJson || !gotImg) return;
      self.index = gotJson.index; self.morph = gotJson.morph; self.autoSets = gotJson.autoSets;
      self.img = gotImg; self.ready = true;
      if (cb) cb(null);
    }
    /*
     * ⛔ THE INDEX IS LOADED BY <script>, NOT BY fetch, AND THAT IS A MEASURED FIX.
     *
     * This used to fetch art/atlas.json. Over http that is fine; over file:// — which is exactly
     * where the PAID DESKTOP BUILD loads from — Chromium answers, verbatim:
     *
     *   Fetch API cannot load file:///.../art/atlas.json. URL scheme "file" is not supported
     *
     * so the atlas never arrived and the whole game rendered its "ART FAILED TO LOAD" card. Nothing
     * caught it, because every harness before verify_audio_input.js served the game over http. The
     * wing's own constitution says fetch and XHR are both blocked there (§8a rule 2); this product
     * had simply never been asked the question.
     *
     * `art/atlas.js` is the same index as a plain assignment to window.TY_ATLAS, loaded by a script
     * tag in the page. Script tags work on every protocol, need no CORS, and cost one request
     * fewer. atlas.json stays in the package as the human-auditable copy (master §3), and
     * Internal_Ops/Art/emit_atlas_js.js REFUSES to run if the two ever disagree.
     *
     * The fetch path is kept as a fallback for any page that forgets the script tag, and a page
     * that has neither is told so rather than quietly drawing nothing.
     */
    if (root.TY_ATLAS) {
      gotJson = root.TY_ATLAS;
    } else if (typeof fetch === 'function') {
      fetch(ART_BASE + 'atlas.json').then(function (r) {
        if (!r.ok) throw new Error('atlas.json ' + r.status);
        return r.json();
      }).then(function (j) { gotJson = j; done(); }).catch(function (e) {
        self.failed = 'could not load the atlas: ' + e.message
          + ' (the page should load art/atlas.js before js/render.js)';
        if (cb) cb(self.failed);
      });
    } else {
      this.failed = 'no atlas: art/atlas.js was not loaded and this page has no fetch';
      if (cb) cb(this.failed); return;
    }
    var im = new Image();
    im.onload = function () { gotImg = im; done(); };
    im.onerror = function () { self.failed = 'could not load art/atlas.png'; if (cb) cb(self.failed); };
    im.src = ART_BASE + 'atlas.png';
    if (gotJson) done();
  };

  /** Blit one atlas entry. Returns false when the key is absent, so callers can report rather than
   * draw nothing and leave a hole nobody notices. */
  Atlas.prototype.draw = function (g, key, dx, dy) {
    if (!this.ready) return false;
    var e = this.index[key];
    if (!e) return false;
    g.drawImage(this.img, e.x, e.y, e.w, e.h, dx, dy, e.w, e.h);
    return true;
  };
  Atlas.prototype.has = function (key) { return !!(this.ready && this.index[key]); };
  /* Draw a RECTANGLE of a tile somewhere else — used by the drift spill (round-6 major 2b), where a
   * drift's crest has to land on the two or three pixels of the tile NEXT to it. ⛔ Source rect is in
   * tile-local coordinates and is clamped to the cell, so a bad call cannot smear a neighbouring
   * atlas entry across the board (the atlas is one sheet; an over-read is another tile's art). */
  Atlas.prototype.drawRegion = function (g, key, sx, sy, sw, sh, dx, dy) {
    if (!this.ready) return false;
    var e = this.index[key];
    if (!e) return false;
    if (sx < 0 || sy < 0 || sx + sw > e.w || sy + sh > e.h) {
      throw new Error('Atlas.drawRegion: ' + key + ' source rect ' + sx + ',' + sy + ' ' + sw + 'x' + sh + ' is outside the ' + e.w + 'x' + e.h + ' cell');
    }
    g.drawImage(this.img, e.x + sx, e.y + sy, sw, sh, dx, dy, sw, sh);
    return true;
  };
  /* ⛔ INTEGER SCALES ONLY (tilesets §4c: a fractional scale resamples, and resampled pixel art is
   * the clearest amateur tell on a store page). Used by the ending card, where a 16-px doorway has
   * to be the SUBJECT of a picture rather than a detail in one. */
  Atlas.prototype.drawScaled = function (g, key, dx, dy, k) {
    if (!this.ready) return false;
    var e = this.index[key];
    if (!e) return false;
    if (k !== Math.round(k) || k < 1) throw new Error('Atlas.drawScaled: integer scale >= 1 only, got ' + k);
    g.drawImage(this.img, e.x, e.y, e.w, e.h, dx, dy, e.w * k, e.h * k);
    return true;
  };

  /* ========================================================================== the renderer ==== */

  function Renderer(canvas) {
    this.c = canvas;
    this.g = canvas.getContext('2d');
    this.g.imageSmoothingEnabled = false;
    this.particles = [];
    this.atlas = new Atlas();
    this.missing = {};                 /* key -> count, so a hole is COUNTED not guessed at */
    this.stats = { frames: 0, tiles: 0, blits: 0, missing: 0 };
    var self = this;
    this.atlas.load(function () { self.stats.artReadyAt = self.stats.frames; });
  }

  /* ---- choosing the right art for a dial angle ------------------------------------------------ */

  /**
   * The season pair the dial currently sits between, and how far along it is.
   * `SEASON.blend(d)` gives {from, to, t}; the atlas morph frames are indexed 1..steps strictly
   * between the two endpoints, so t maps onto step = round(t * (steps+1)).
   */
  /* `nvOverride` exists for ONE case: the dune crest is derived rather than staged from a pack, and
   * it has three phases, not `groundVariants`. A caller that knows its set's size says so; everything
   * else reads the atlas (see below). */
  Renderer.prototype.pick = function (kind, d, vx, vy, seasonal, nvOverride) {
    /* ⛔ THE COUNT COMES FROM THE ATLAS, NOT FROM A LITERAL. It was `4`, and round-6 major 2(a)
     * measured what four buys on a 20-tile field: "the morph's four-variant dither, which repeats
     * every four tiles across the whole vale ... at thumbnail it reads as wallpaper". There are
     * eight now (build_art.js GROUND_VARIANTS, the last four reflections of the pack's), and a
     * renderer holding its own copy of that number is how a hole opens at every cell the day the
     * builder changes it. */
    var nv = nvOverride || (this.atlas.morph && this.atlas.morph.groundVariants) || 4;
    var v = Math.floor(hash2(vx, vy, 3) * nv);
    if (!seasonal) return 'ground/' + kind + '/all/' + v;
    var bl = SEASON.blend(d);
    var steps = (this.atlas.morph && this.atlas.morph.steps) || 8;
    var step = Math.round(bl.t * (steps + 1));
    if (step <= 0) return 'ground/' + kind + '/' + bl.from + '/' + v;
    if (step > steps) return 'ground/' + kind + '/' + bl.to + '/' + v;
    return 'morph/' + kind + '/' + bl.from + '->' + bl.to + '/' + v + '/' + step;
  };

  /**
   * ⛔ THE DUNES' GROUND, WITH A CREST ON ABOUT ONE CELL IN SIX — round-3 minor defect 11: "the
   * Dunes' sand is a flat two-tone noise that reads as camouflage at 4x — no dune line, no ripple,
   * no light direction ... It is the paid board's only image."
   * ⚠️ Measured before writing this: `ground/sand/all/0..3` are three colours each, the SAME three,
   * with the dominant tone at 66/67/66/68% — one tile four times, so `pick`'s four-way variance was
   * buying nothing on this board. The crest tiles are derived in build_art.js from sand's own
   * palette, and 1-in-6 is deliberate: a crest on every cell is corduroy, which is the same defect
   * wearing a different texture.
   * ⚠️ A SEPARATE HASH SALT from the one `pick` uses, so which cells are crests is independent of
   * which plain variant a non-crest cell gets.
   */
  Renderer.prototype.pickSand = function (d, tx, ty) {
    /* ⛔⛔ SEASONAL SINCE ROUND 7, AND THE `all` THAT USED TO SIT IN BOTH LINES WAS ROUND-6 MAJOR 5:
     * "THE PAID DESERT DOES NOT TURN ... pass D measured 16.8% of pixels changing spring->summer
     * against 77.8% on the Meadow". The sand and its crests were staged under the literal key `all`,
     * so, exactly as the fell before round 5, there was nothing for the dial to reach — wing §0z-1h:
     * a capability can be absent BY KEY NAME, so grep the keys before debugging the draw call. */
    if (hash2(tx, ty, 37) < 0.17) return this.pick('sand_crest', d, tx, ty, true, 3);
    /* ⚠️ `pick`, not `pickSand`. A blind text replace of the three call sites rewrote this line too,
     * inside the function's own definition, making it call itself unconditionally — a stack overflow
     * on the first Dunes tile drawn, from an edit whose stated scope was "the call sites". A
     * find-and-replace does not know which occurrence is the DEFINITION. */
    return this.pick('sand', d, tx, ty, true);
  };

  /**
   * The same choice for a shoreline autotile mask (fewer steps — see build_art.js).
   *
   * ⛔⛔ THE TILE'S OWN COORDINATES ARE PART OF THE CHOICE — round-6 major defect 1. The atlas used
   * to hold ONE tile per edge mask, so a straight bank was one tile stamped down its whole length:
   * MEASURED at 100.0% identity at the tile pitch against a 32.6% control on the same run of ground,
   * and the art director read it at 1x before any instrument ("a dark-blue dash every tile down the
   * left bank ... for 720 px"). The atlas now carries `morph.edgeVariants` variants of every mask,
   * identical in boundary GEOMETRY and re-phased inside, and which one a cell gets is a hash of the
   * cell's own world position.
   *
   * ⚠️ A SEPARATE SALT from `pick`'s, so which edge variant a shoreline cell takes is independent of
   * which ground variant the cell behind it took — the same reason `pickSand` salts separately.
   * ⛔ The variant is a function of the TILE, not of the mask or the season, so it does not change
   * when the year turns: a shore that re-rolled its texture as the dial moved would shimmer.
   */
  Renderer.prototype.edgeVariant = function (tx, ty) {
    var n = (this.atlas.morph && this.atlas.morph.edgeVariants) || 1;
    return Math.floor(hash2(tx, ty, 53) * n);
  };

  Renderer.prototype.pickEdge = function (setName, mask, d, tx, ty) {
    /* ⛔ the coordinates are REQUIRED. A call site that forgot them would silently draw variant 0
     * everywhere and restore the stamp at exit 0 — the defect wearing the fix's clothes. */
    if (typeof tx !== 'number' || typeof ty !== 'number') {
      throw new Error('pickEdge: tile coordinates are required (set ' + setName + ', mask ' + mask + ')');
    }
    var v = this.edgeVariant(tx, ty);
    var bl = SEASON.blend(d);
    var steps = (this.atlas.morph && this.atlas.morph.edgeSteps) || 3;
    var step = Math.round(bl.t * (steps + 1));
    if (step <= 0) return 'auto/' + setName + '/' + bl.from + '/' + mask + '/' + v;
    if (step > steps) return 'auto/' + setName + '/' + bl.to + '/' + mask + '/' + v;
    return 'edgemorph/' + setName + '/' + bl.from + '->' + bl.to + '/' + mask + '/' + v + '/' + step;
  };

  Renderer.prototype.blit = function (key, dx, dy) {
    if (this.atlas.draw(this.g, key, dx, dy)) { this.stats.blits++; return true; }
    this.missing[key] = (this.missing[key] || 0) + 1;
    this.stats.missing++;
    return false;
  };

  /* ---- the board ------------------------------------------------------------------------------ */

  /** Is the tile at (tx,ty) part of a sluice structure? Used to pick head / shaft / sill. */
  function isSluice(w, tx, ty) {
    var t = w.tile(tx, ty);
    return !!(t && t.prop && t.prop.k === 'sluice');
  }

  /** Is this tile's SURFACE water-like (open, ice, thin, slush)? Used for the shoreline mask. */
  function isWet(w, tx, ty) {
    var t = w.tile(tx, ty);
    if (!t) return false;
    if (!t.lake) return false;
    var s = w.surface(tx, ty);
    return s.kind !== 'bed';
  }

  /** The complement isWet() throws away: a lake cell whose water has GONE. Used for the bank mask.
   * ⛔ These two are not each other's negation over all tiles — a grass cell is neither — so both
   * are written out rather than one being spelled `!isWet` at the call site. */
  function isBed(w, tx, ty) {
    var t = w.tile(tx, ty);
    if (!t || !t.lake) return false;
    return w.surface(tx, ty).kind === 'bed';
  }

  Renderer.prototype.board = function (run) {
    var g = this.g, w = run.world, d = w.dial.d;
    var sc = w.screens[run.screen];
    var ox = sc.col * SCREEN_W, oy = sc.row * SCREEN_H;
    var x, y, tx, ty, t, s, px, py, key;

    /* ---- pass 1: the ground of every cell ---- */
    for (y = 0; y < SCREEN_H; y++) {
      for (x = 0; x < SCREEN_W; x++) {
        tx = ox + x; ty = oy + y;
        t = w.tile(tx, ty);
        px = x * TILE; py = LAYOUT.BOARD_Y + y * TILE;
        this.stats.tiles++;
        if (!t || t.type === 'void') { g.fillStyle = PAL.ink; g.fillRect(px, py, TILE, TILE); continue; }
        s = w.surface(tx, ty);
        key = this.groundKey(w, t, s, tx, ty, d);
        if (!this.blit(key, px, py)) { g.fillStyle = PAL.ink; g.fillRect(px, py, TILE, TILE); }
      }
    }

    /* ---- pass 2a: THE PATH EDGE. A grass cell touching a path takes the blob47 mask for its
     * neighbourhood, exactly as the shoreline does.
     *
     * ⛔ THIS SET EXISTED IN THE ATLAS ALL ALONG AND NOTHING DREW IT. `auto/grass_on_path/*` is 188
     * staged tiles — four seasons of 47 masks — and pass 2 below referenced only `grass_on_water`,
     * so every path met the meadow at a raw rectangle. The art director saw the consequence in the
     * winter capture: "the meadow's brown patch renders in winter as a soft grey smear with no edge
     * ... it reads as a rendering artefact rather than snow-covered ground". Wing §0z-1c calls a
     * reader nothing writes an untested code path; an ASSET nothing blits is the same defect from
     * the other side, and it was shipping in the download.
     *
     * ⚠️ Drawn BEFORE the water and the bed so those two overwrite it: where a path runs to a
     * shore, the shore is the boundary that matters. */
    for (y = 0; y < SCREEN_H; y++) {
      for (x = 0; x < SCREEN_W; x++) {
        tx = ox + x; ty = oy + y;
        t = w.tile(tx, ty);
        if (!t || t.type !== 'grass' || t.lake || t.drift || t.block) continue;
        var pm = 0, anyPath = false;
        var pdirs = [[0, -1, B_N], [1, -1, B_NE], [1, 0, B_E], [1, 1, B_SE], [0, 1, B_S], [-1, 1, B_SW], [-1, 0, B_W], [-1, -1, B_NW]];
        for (var pi = 0; pi < 8; pi++) {
          var pnx = tx + pdirs[pi][0], pny = ty + pdirs[pi][1];
          var pt = w.tile(pnx, pny);
          if (pt && pt.type === 'path' && !pt.lake) anyPath = true; else pm |= pdirs[pi][2];
        }
        if (!anyPath) continue;
        px = x * TILE; py = LAYOUT.BOARD_Y + y * TILE;
        this.blit(this.pickEdge('grass_on_path', normaliseMask(pm), d, tx, ty), px, py);
      }
    }

    /* ---- pass 2: the shoreline. A land cell touching water takes the blob47 mask for its
     * neighbourhood, which is what turns a rectangular lake into a shaped one. The mask art bakes
     * the water in (MEASURED: every mask tile is fully opaque), so this is one blit, not a layer. */
    for (y = 0; y < SCREEN_H; y++) {
      for (x = 0; x < SCREEN_W; x++) {
        tx = ox + x; ty = oy + y;
        t = w.tile(tx, ty);
        if (!t || t.type === 'void' || t.lake || t.drift || t.block) continue;
        /* ⛔⛔ `sand` WAS NOT IN THIS LIST, AND THAT WAS THE WHOLE OF ROUND-6 MINOR 8. The review read
         * it as a shading defect — "the oasis bed has a dark lip and no lit rim where the Mere's
         * shore has both" — and the cause is one rung up: the Dunes' shore cells are `sand`, so this
         * pass SKIPPED THEM and the full oasis met its water at a raw rectangle while the drained one
         * had a bank. A land type missing from a list is §0z-1c's dead reader wearing a third face.
         * ⚠️ Which SET a cell takes is decided by its land, exactly as the bank pass below does it. */
        if (t.type !== 'grass' && t.type !== 'reeds' && t.type !== 'path' && t.type !== 'sand') continue;
        /* bit set = that neighbour is LAND like me; clear = water. A cell with no wet neighbour
         * is interior and keeps its plain fill from pass 1. */
        var m = 0, anyWet = false;
        var dirs = [[0, -1, B_N], [1, -1, B_NE], [1, 0, B_E], [1, 1, B_SE], [0, 1, B_S], [-1, 1, B_SW], [-1, 0, B_W], [-1, -1, B_NW]];
        for (var i = 0; i < 8; i++) {
          var nx = tx + dirs[i][0], ny = ty + dirs[i][1];
          if (isWet(w, nx, ny)) anyWet = true; else m |= dirs[i][2];
        }
        if (!anyWet) continue;
        px = x * TILE; py = LAYOUT.BOARD_Y + y * TILE;
        this.blit(this.pickEdge(t.type === 'sand' ? 'shore_sand_on_water' : 'grass_on_water', normaliseMask(m), d, tx, ty), px, py);
      }
    }

    /* ---- pass 2b: THE BANK OF A DRAINED LAKE. ⛔⛔ THE ART DIRECTOR'S BLOCKING DEFECT.
     *
     * `isWet()` deliberately excludes a `bed`, so pass 2 above gives a DRAINED lake no edge at
     * all: every drained lake in the game was "a brown noise rectangle inside a tan noise
     * rectangle, meeting at a razor right angle with no bank, no lip, no crack, no shade" — the
     * doctrine's blocking definition of a flat fill, in a store image, on a board a buyer is being
     * sold. A lake that is FULL had an organic shoreline and the same lake DRAINED had a rectangle.
     *
     * The bank is its own autotile family (`bank_<land>_on_bed`), composed from blob47's own
     * outline and shaded so the hollow carries the bank's shadow on its upper-left inside and the
     * land a lit crest on the lower-right outside — see build_art.js's EDGE section, and
     * `_probe_edge_shading.js` for the geometry gate. Land type picks the family: the Dunes' oasis
     * drains into sand, the Mere and the brook into meadow.
     *
     * ⚠️ The polarity matches pass 2 exactly — the tile is drawn on the LAND cell, and a set bit
     * means "that neighbour is land like me" — so this is the same shape of logic, not a new one. */
    for (y = 0; y < SCREEN_H; y++) {
      for (x = 0; x < SCREEN_W; x++) {
        tx = ox + x; ty = oy + y;
        t = w.tile(tx, ty);
        if (!t || t.type === 'void' || t.lake || t.drift || t.block) continue;
        var bankSet = t.land === 'dunes' ? 'bank_sand_on_bed' : 'bank_grass_on_bed';
        var bm = 0, anyBed = false;
        var bdirs = [[0, -1, B_N], [1, -1, B_NE], [1, 0, B_E], [1, 1, B_SE], [0, 1, B_S], [-1, 1, B_SW], [-1, 0, B_W], [-1, -1, B_NW]];
        for (var bi2 = 0; bi2 < 8; bi2++) {
          var bnx = tx + bdirs[bi2][0], bny = ty + bdirs[bi2][1];
          if (isBed(w, bnx, bny)) anyBed = true; else bm |= bdirs[bi2][2];
        }
        if (!anyBed) continue;
        px = x * TILE; py = LAYOUT.BOARD_Y + y * TILE;
        /* the sand bank is not seasonal — pickEdge would ask for a season that does not exist */
        this.blit(bankSet === 'bank_sand_on_bed'
          ? 'auto/bank_sand_on_bed/all/' + normaliseMask(bm) + '/' + this.edgeVariant(tx, ty)
          : this.pickEdge('bank_grass_on_bed', normaliseMask(bm), d, tx, ty), px, py);
      }
    }

    /* ---- pass 2a-2: THE DUNES' LITTER. Round-6 major 5, second clause.
     *
     * "away from the bed the board is still the sparsest in the gallery (34.4% one colour; the right
     * 60% carries a column, a sign, a cactus and three pebbles)." Three flat marks — bones, pebbles
     * and a line of tracks — scattered over WALKABLE sand at about one cell in four, which is the
     * density the review asks for.
     *
     * ⛔ THEY BLOCK NOTHING, and that is deliberate: see build_objects.js for why a thing you walk
     * OVER is the only way to furnish the middle of this board without moving a single wall. Not one
     * tile's `block` or `type` is touched, so every reachability proof stands unchanged.
     * ⚠️ Drawn after the ground and BEFORE the props, so a cactus standing on a littered cell still
     * covers its own litter rather than floating over it.
     * ⚠️ A separate hash salt again (pickSand's lesson), so which cells carry litter is independent
     * of which sand variant and which crest they drew. */
    for (y = 0; y < SCREEN_H; y++) {
      for (x = 0; x < SCREEN_W; x++) {
        tx = ox + x; ty = oy + y;
        t = w.tile(tx, ty);
        if (!t || t.type !== 'sand' || t.block || t.lake) continue;
        /* ⚠️ 0.22, set by LOOKING: at 0.26 with the darker pen the sand read as confetti, which is
         * the flat-noise defect wearing a prop's clothes (the fell's dressing header records the same
         * mistake). Bones stay pale, pebbles and tracks are re-penned near the sand's own dark tone. */
        var lh = hash2(tx, ty, 71);
        if (lh >= 0.22) continue;
        px = x * TILE; py = LAYOUT.BOARD_Y + y * TILE;
        this.blit(lh < 0.05 ? 'object/dune_bones' : lh < 0.14 ? 'object/dune_pebbles' : 'object/dune_track', px, py);
      }
    }

    /* ---- pass 2b-2: THE RETREATING WATERLINE OVER AN EXPOSED BED. Round-6 minor 9, measured.
     *
     * `isWet()` deliberately excludes a bed and pass 2 runs on LAND types, so a BED cell sitting
     * beside a WATER cell was reached by no edge pass at all: a part-drained lake met its own mud at
     * a hard step, which is the rectangle the review's `mere_summer_mud_3x` crop shows. Same shape of
     * defect as the drained lake's missing bank (pass 2b) and the full oasis's missing shore (pass 2),
     * on the third of the three material pairs — and it is worth naming as a class: EVERY pair of
     * materials that can meet needs an edge, and the ones nobody thought of are the ones that ship.
     *
     * ⚠️ Drawn on the BED cell, mask bits set where the neighbour is also bed — the same polarity as
     * every other edge pass here, so this is not a new shape of logic.
     * ⚠️ One variant and no morph frames for this set (art_sources.js records why), so the key is
     * built directly rather than through `pickEdge`. */
    for (y = 0; y < SCREEN_H; y++) {
      for (x = 0; x < SCREEN_W; x++) {
        tx = ox + x; ty = oy + y;
        if (!isBed(w, tx, ty)) continue;
        var wm = 0, anyWater = false;
        var wdirs = [[0, -1, B_N], [1, -1, B_NE], [1, 0, B_E], [1, 1, B_SE], [0, 1, B_S], [-1, 1, B_SW], [-1, 0, B_W], [-1, -1, B_NW]];
        for (var wi = 0; wi < 8; wi++) {
          var wnx = tx + wdirs[wi][0], wny = ty + wdirs[wi][1];
          if (isWet(w, wnx, wny)) anyWater = true; else wm |= wdirs[wi][2];
        }
        if (!anyWater) continue;
        px = x * TILE; py = LAYOUT.BOARD_Y + y * TILE;
        this.blit('auto/bed_on_water/' + SEASON_NAMES[Math.round(d) % 4] + '/' + normaliseMask(wm) + '/0', px, py);
      }
    }

    /* ---- pass 2b-3: THE ICE MEETS ITS BANK AS A MATERIAL, NOT AS A CLEAN STRIP. Round-6 major 3.
     *
     * The last clause of that defect, after the base tone was separated: "with a 1-px darker rim on
     * the ice side of each bank so the road is a material, not a clean strip". A frozen brook is a
     * sheet lying IN a channel, so the bank stands a little above it and throws a line of shade onto
     * it — without that the ice is a coloured ribbon laid on top of the snow.
     *
     * ⛔ NORTH AND WEST ONLY, like every other shaded edge in this game: light is upper-left, so a
     * bank casts down and right. A rim on all four sides is a joint outlined twice, which §0-ART-b
     * forbids and which is what made the round-4 shoreline read as a drawn outline.
     * ⚠️ A MULTIPLY, for major 2(c)'s reason one pass down: ice, thin ice and slush are three
     * different tones and a fixed ink would be right on one of them. */
    for (y = 0; y < SCREEN_H; y++) {
      for (x = 0; x < SCREEN_W; x++) {
        tx = ox + x; ty = oy + y;
        if (!isWet(w, tx, ty)) continue;
        var sk = w.surface(tx, ty).kind;
        if (sk !== 'ice' && sk !== 'thin' && sk !== 'slush') continue;
        var bankN = !isWet(w, tx, ty - 1) && !!w.tile(tx, ty - 1);
        var bankW = !isWet(w, tx - 1, ty) && !!w.tile(tx - 1, ty);
        if (!bankN && !bankW) continue;
        px = x * TILE; py = LAYOUT.BOARD_Y + y * TILE;
        var prevIceOp = g.globalCompositeOperation;
        g.globalCompositeOperation = 'multiply';
        g.fillStyle = '#b4b4b4';                       /* 0.71x — a line of shade, not an ink */
        if (bankN) g.fillRect(px, py, TILE, 1);
        if (bankW) g.fillRect(px, py, 1, TILE);
        g.globalCompositeOperation = prevIceOp;
      }
    }

    /* ---- pass 2c: THE CRAG'S SHADOW ON THE LAND BELOW IT. Round-5 blocking defect 2.
     *
     * "A hard rectangle of vale floating on a flat dark-slate noise field; the only edge between them
     * is a 1-px pale line." That pale line is the cliff's lit crown doing its job. What was missing
     * is the other half of the same fact: the fell STANDS ABOVE the vale, so it throws a shadow onto
     * it, and without one the vale is not lower ground, it is only a different colour — which is what
     * makes the rectangle read as pasted on rather than as ground meeting ground.
     *
     * ⚠️ LAST of the ground passes deliberately: it must darken whatever material actually ended up
     * in the cell (meadow, snow, path, shoreline, bed), so it runs after 2a/2/2b rather than beside
     * pass 1 where the shoreline would paint straight over it.
     * ⛔ Light is upper-left everywhere in this game, so a crag casts DOWN and RIGHT — north-facing
     * and west-facing edges only. A cell in an inside corner takes both and is correctly darkest. */
    for (y = 0; y < SCREEN_H; y++) {
      for (x = 0; x < SCREEN_W; x++) {
        tx = ox + x; ty = oy + y;
        t = w.tile(tx, ty);
        if (!t || t.type === 'void' || t.type === 'cliff') continue;
        var nAbove = w.tile(tx, ty - 1), nLeft = w.tile(tx - 1, ty);
        var castN = !!(nAbove && nAbove.type === 'cliff');
        var castW = !!(nLeft && nLeft.type === 'cliff');
        if (!castN && !castW) continue;
        px = x * TILE; py = LAYOUT.BOARD_Y + y * TILE;
        /* ⛔⛔ MULTIPLY, NOT SOURCE-OVER — round-6 major 2(c). Blitted normally, these two tiles are
         * alpha night-ink, which tints snow blue and does nothing at all to green (see edgeShade's
         * header for why those are one fact, not two). Under multiply the same tile takes 20% of the
         * light off WHATEVER is beneath it, on every board and in every season.
         * ⚠️ The mode is restored immediately: a composite op left set leaks into every draw after it,
         * and the next pass is the props. */
        var prevOp = g.globalCompositeOperation;
        g.globalCompositeOperation = 'multiply';
        if (castN) this.blit('object/cliff_shade_n', px, py);
        if (castW) this.blit('object/cliff_shade_w', px, py);
        g.globalCompositeOperation = prevOp;
      }
    }

    /* ---- pass 3: props and objects, painted back to front so a tree in front overlaps the one
     * behind it. A tree is 2x2 in the pack over a 1-cell block: drawn centred on its tile with its
     * base on the tile's bottom edge, which is how a row of them reads as a treeline rather than a
     * row of bushes. The COLLISION is still exactly the one tile the model blocks. */
    for (y = 0; y < SCREEN_H; y++) {
      for (x = 0; x < SCREEN_W; x++) {
        tx = ox + x; ty = oy + y;
        t = w.tile(tx, ty);
        if (!t || !t.block) continue;
        px = x * TILE; py = LAYOUT.BOARD_Y + y * TILE;
        this.drawBlock(g, w, px, py, t, d, tx, ty);
      }
    }

    /* ---- pass 3b: THE DRIFT SPILLS ONTO WHAT IT SHUTS. Round-6 major 2(b).
     *
     * ⛔ IT RUNS AFTER THE BLOCK PASS, AND IT DID NOT AT FIRST — which is the same ordering mistake
     * the crag's shadow records one pass up, and it was invisible in the code and obvious in the
     * plate. The drift's neighbours on the Fell are CLIFF tiles, cliffs are drawn by `drawBlock` in
     * pass 3, so a spill laid down in pass 2 was painted straight over and shot_7 came back with the
     * slab's four ruled edges intact. Opened, not inferred.
     *
     * "The snowdrift that shuts the gap — the object the caption is about — is a flat near-white slab
     * two tiles wide with hard edges on all four sides (drift_crown_6x); the wind scallops are two
     * faint bands." The scallops are inside the tile and they were the right idea at the wrong scale:
     * what makes a drift read as a drift is not its surface, it is that snow does not stop at a
     * boundary. A slab with four ruled edges is a slab whatever is painted on it.
     *
     * So the drift overdraws its NEIGHBOURS: a lit crest 2-3 px onto the tile on its windward (north
     * and west) side, and a shadow foot on the lee (south and east) side. ⛔ SAFE BY CONSTRUCTION and
     * this is the whole reason it is done here rather than in the model — it is DECORATION on cells
     * that already exist, drawn after every ground pass and before every prop; not one tile's `block`
     * or `type` is touched, so the Fell's four-season walk and `_gates_selftest.js` are untouched
     * (wing §0z-1h: decoration on already-blocking tiles cannot change reachability).
     * ⚠️ The spill is the drift's OWN art, clipped to a few pixels — it cannot introduce a colour the
     * drift did not already have, so palette closure is not at risk. A scalloped edge comes free: the
     * drift tile's crown is already scalloped, and clipping it is what puts that scallop at the
     * BOUNDARY where it can be seen. */
    for (y = 0; y < SCREEN_H; y++) {
      for (x = 0; x < SCREEN_W; x++) {
        tx = ox + x; ty = oy + y;
        t = w.tile(tx, ty);
        if (!t || t.type === 'void' || t.drift) continue;
        var dN = w.tile(tx, ty + 1), dW = w.tile(tx + 1, ty);      /* a drift BELOW me spills UP onto me */
        var dS = w.tile(tx, ty - 1), dE = w.tile(tx - 1, ty);
        px = x * TILE; py = LAYOUT.BOARD_Y + y * TILE;
        var dk = this.pick('drift', d, tx, ty, false);
        var spill = 0, si, dep;
        /* ⛔⛔ THE SPILL IS SCALLOPED PER COLUMN, AND A FULL-WIDTH ONE DID NOTHING BUT MOVE THE RULE.
         * The first spelling blitted a 16x3 strip of the drift's crest onto the neighbour, and the
         * crest is near-solid, so the slab simply became three pixels taller with an edge exactly as
         * straight as before — visible at 3x on shot_7 and invisible in the code. Snow does not stop
         * at a line, so the depth wanders per COLUMN (and per row on the vertical edges): a hash of
         * the world position gives 1..3 px, which is what makes the boundary ragged.
         * ⚠️ World-position keyed, not tile-local, so the scallop does not repeat every 16 px — the
         * same rule the ground variants and the edge variants are built on. */
        var depth = function (a, b, max) { return 1 + Math.floor(hash2(a, b, 83) * max); };
        /* a drift BELOW or RIGHT of me is windward: its lit CREST (the drift tile's top rows) reaches
         * onto my edge — the "lit crest 2-3 px overdrawn onto the neighbouring tiles on its windward
         * side" the review asks for */
        if (dN && dN.drift) {
          for (si = 0; si < TILE; si++) { dep = depth(tx * TILE + si, ty, 3); this.atlas.drawRegion(g, dk, si, 0, 1, dep, px + si, py + TILE - dep); }
          spill++;
        }
        if (dW && dW.drift) {
          for (si = 0; si < TILE; si++) { dep = depth(tx, ty * TILE + si, 3); this.atlas.drawRegion(g, dk, 0, si, dep, 1, px + TILE - dep, py + si); }
          spill++;
        }
        /* a drift ABOVE or LEFT of me is lee: its shadowed FOOT (the drift tile's bottom rows) lies
         * on mine, so the drift reads as standing above the ground on that side */
        if (dS && dS.drift) {
          for (si = 0; si < TILE; si++) { dep = depth(tx * TILE + si, ty + 7, 2); this.atlas.drawRegion(g, dk, si, TILE - dep, 1, dep, px + si, py); }
          spill++;
        }
        if (dE && dE.drift) {
          for (si = 0; si < TILE; si++) { dep = depth(tx + 7, ty * TILE + si, 2); this.atlas.drawRegion(g, dk, TILE - dep, si, dep, 1, px, py + si); }
          spill++;
        }
        this.stats.driftSpill = (this.stats.driftSpill || 0) + spill;
      }
    }

    /* ---- pass 4: the lake's own furniture: the sluice, the drowned door, the boat ---- */
    for (y = 0; y < SCREEN_H; y++) {
      for (x = 0; x < SCREEN_W; x++) {
        tx = ox + x; ty = oy + y;
        t = w.tile(tx, ty);
        if (!t) continue;
        px = x * TILE; py = LAYOUT.BOARD_Y + y * TILE;
        s = w.surface(tx, ty);
        if (t.prop && t.prop.k === 'sluice') {
          /* ⛔ ONE STRUCTURE, NOT N COPIES. Pick the piece from the run: head where there is no
           * sluice above, sill where there is none below, shaft in between. Drawing the whole
           * sprite per tile stacked into a ladder in this stage's first Mere capture. */
          var upIsSluice = isSluice(w, tx, ty - 1), downIsSluice = isSluice(w, tx, ty + 1);
          var piece = !upIsSluice ? 'sluice_head' : !downIsSluice ? 'sluice_sill' : 'sluice_shaft';
          this.blit('object/' + piece, px, py);
        }
        if (t.door) this.blit(s.kind === 'bed' ? 'object/door_open' : 'object/door_drowned', px, py - TILE);
      }
    }
    for (var bi = 0; bi < w.boats.length; bi++) {
      var b = w.boats[bi];
      var btx = Math.floor(b.x / TILE), bty = Math.floor(b.y / TILE);
      if (w.screenOf(btx, bty) !== run.screen) continue;
      this.blit('object/boat', Math.round(b.x - ox * TILE) - 12, Math.round(b.y - oy * TILE) + LAYOUT.BOARD_Y - 8);
    }

    /* ---- pass 5: the hero ---- */
    this.drawHero(run, ox, oy);

    this.particles_(run);
  };

  /**
   * Which ground art a cell takes, given its type and its lake surface.
   * ⛔ A `snow` ARGUMENT USED TO BE THREADED IN HERE AND INTO drawBlock, AND NEITHER BODY EVER READ
   * IT. `board()` computed `Math.min(1, w.S / 1.5)` every frame and handed it to both. The model
   * tracks snowpack with exact conservation and it is the mechanism that drains the Mere to expose
   * the drowned door, so a reader — including this session — reasonably assumed the ground showed
   * it. It never did: a dusting and a metre of pack drew the same tiles. A parameter nobody reads
   * is a promise the code does not keep (wing §0z-1c: a dead reader is an untested code path), so
   * it is gone rather than quietly retained. ⚠️ Making snow DEPTH visible is a real and wanted art
   * change — it is recorded for the art director, and it needs deep-snow tiles that do not exist.
   */
  Renderer.prototype.groundKey = function (w, t, s, tx, ty, d) {
    if (t.lake) {
      if (s.kind === 'bed') return this.pick('mud', d, tx, ty, false);
      if (t.warm) return this.pick('warm', d, tx, ty, false);
      /* ⛔⛔ SOLID ICE HAS ITS OWN MATERIAL. This line used to read
       *     if (s.kind === 'ice') return this.pick('water', 3, tx, ty, true);   // winter art = ice
       * which is not "ice art", it is the ORDINARY WATER TILE at the winter dial angle. MEASURED
       * (Internal_Ops/_probe_ice_vs_water.js, over the shipped atlas): at dial 3.00 — winter, where
       * the player necessarily stands to freeze a lake and walk on it — that resolved to the SAME
       * ATLAS KEY as open water below, so the surface that carries you and the surface that drowns
       * you were pixel-identical at the exact moment the game's central verb is used.
       * `ground/ice` is flat, pale and straight-seamed; open water stays busy and dark. It is not
       * seasonal, because ice looks like ice whenever it exists. */
      if (s.kind === 'ice') return this.pick('ice', d, tx, ty, false);
      if (s.kind === 'thin') return this.pick('thin_ice', d, tx, ty, false);
      if (s.lake.I > 0) return this.pick('slush', d, tx, ty, false);
      return this.pick('water', d, tx, ty, true);
    }
    if (t.drift) return this.pick('drift', d, tx, ty, false);
    if (t.type === 'sand') return this.pickSand(d, tx, ty);
    if (t.type === 'stone' || t.type === 'island') return this.pick('stone', d, tx, ty, false);
    if (t.type === 'path') return this.pick('path', d, tx, ty, true);
    /* ⛔ THE FALLBACK IS LAND-AWARE, and it was not. Every tile whose `type` is a PROP rather than
     * a terrain — rock, sign, glyph, inscription, ruin, shrub — fell through to grass, on every
     * board. drawBlock papered over it for non-tree props by re-picking with `t.land`, so the only
     * visible survivor was the meadow baked into the prop SPRITE (see build_art's prop staging).
     * But a fallback that is wrong and compensated downstream is one edit away from being wrong and
     * visible, and it made the real defect look like it had already been fixed. */
    /* ⛔⛔ AND IT MUST BE THE SCREEN'S LAND, NOT THE TILE'S — round-5, found by looking at shot_5.
     *
     * The Dunes board's top two rows belong to the MERE (`landRows`, the transition band), so a tile
     * up there has `land === 'mere'` while every tile around it is sand. A prop placed on one of them
     * took the `grass` fallback and drew A GREEN MEADOW SQUARE IN THE MIDDLE OF THE DESERT, in the
     * paid board's only gallery image. It had been latent since the landRows were written: the board
     * had three props, all on dunes tiles, so nothing ever stood there until this round added five
     * more. ⚠️ The instrument that found it was the PNG, after every gate was green (§0z-1e).
     *
     * A prop stands on the ground its BOARD is made of. On the Fell — the other two-land board —
     * both lands' ground is grass, so this is a no-op there, which is the check that it is a fix and
     * not a preference. `verify_prop_ground.js` asserts the whole class against the neighbours. */
    /* ⭐ AND THE RULE THAT COVERS THE WHOLE CLASS: A PROP STANDS ON WHAT ITS NEIGHBOURS STAND ON.
     * `verify_prop_ground.js` walked all 155 blocking tiles with the land rule above in place and
     * found four more the same shape — the Mere's ruin and its inscription stone stand on the
     * island's STONE platform and were drawing grass. Keying on the land, the screen or the board is
     * always one level edit from being wrong somewhere; the tiles around a prop are the ground it is
     * standing on, by definition. Deterministic, stateless and local, so a harness sees what a
     * player sees and nothing flickers between frames. */
    var counts = {}, nd, nt, nm, bestM = null, bestN = 0;
    var NB = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1], [1, -1], [-1, 1]];
    for (nd = 0; nd < NB.length; nd++) {
      nt = w.tile(tx + NB[nd][0], ty + NB[nd][1]);
      if (!nt || nt.block || nt.lake || nt.type === 'void' || nt.drift) continue;
      nm = nt.type === 'sand' ? 'sand'
        : (nt.type === 'stone' || nt.type === 'island') ? 'stone'
          : nt.type === 'path' ? 'path'
            : nt.type === 'grass' || nt.type === 'reeds' ? 'grass' : null;
      if (!nm) continue;
      counts[nm] = (counts[nm] || 0) + 1;
      if (counts[nm] > bestN) { bestN = counts[nm]; bestM = nm; }
    }
    if (bestM === 'sand') return this.pickSand(d, tx, ty);
    if (bestM === 'stone') return this.pick('stone', d, tx, ty, false);
    if (bestM === 'path') return this.pick('path', d, tx, ty, true);
    if (bestM === 'grass') return this.pick('grass', d, tx, ty, true);
    /* no usable neighbour (a prop walled in by other props): the board's own material */
    var scr = w.screens && w.screens[t.screen];
    if (((scr && scr.land) || t.land) === 'dunes') return this.pickSand(d, tx, ty);
    return this.pick('grass', d, tx, ty, true);
  };

  /**
   * A blocking tile. Each kind names one thing a real sprite draws; nothing here is a rectangle.
   * ⚠️ A block stands on the ground of ITS land (2026-09-10: every rock and sign drew a green grass
   * square on the Fell's snow and the Dunes' sand) — so the ground is drawn first from the same
   * chooser the rest of the board uses, then the prop on top.
   */
  /**
   * ⛔ WHICH OF THE FOUR TREE VARIANTS THIS CELL DRAWS, with NO TWO ADJACENT CELLS ALIKE.
   *
   * A bare `hash2` puts two neighbours on the same variant about a quarter of the time, and a
   * repeated pair next to each other is exactly the rhythm major defect 3 is about. The exclusion
   * is applied by walking WEST to the start of the contiguous run and then forward — which is
   * EXACT, where a one- or two-cell lookback is a heuristic that gets it right most of the time.
   * (I wrote the lookback first. It is the same shape of mistake as a bound stated in a comment:
   * it would have been correct on nearly every board and wrong where two runs happened to align,
   * with nothing able to tell me which board that was.)
   *
   * ⚠️ Deterministic and stateless: it depends only on the tiles, so it never flickers between
   * frames and a harness sees what a player sees. A run is at most one screen wide (20 cells).
   */
  function treeVariant(w, t, tx, ty) {
    var startX = tx;
    while (true) {
      var prev = w.tile(startX - 1, ty);
      if (!prev || prev.type !== 'tree' || prev.land !== t.land) break;
      startX--;
      if (tx - startX > 64) break;      /* a bound that can never bind on a 20-wide screen */
    }
    var v = Math.floor(hash2(startX, ty, 13) * 4), prevV = -1;
    for (var x = startX; x <= tx; x++) {
      v = Math.floor(hash2(x, ty, 13) * 4);
      if (v === prevV) v = (v + 1) % 4;
      prevV = v;
    }
    return v;
  }

  Renderer.prototype.drawBlock = function (g, w, px, py, t, d, tx, ty) {
    var season = SEASON_NAMES[Math.round(d) % 4];
    /* ⚠️ a `var v = Math.floor(hash2(tx, ty, 3) * 4)` stood here and was READ BY NOTHING — left
     * behind when §0z-1f's "one chooser" fix moved the ground decision out of this function. It is
     * deleted rather than updated: a dead variable that looks like a ground-variant pick is a trap
     * for the next reader, who would have found it holding 4 while `pick` had moved to 8. */

    if (t.type === 'tree') {
      /* ⛔⛔ THE DUNES GET THEIR OWN FRAME — the art director's round-2 major defect 5: "the paid
       * desert board is a tan rectangle inside a ring of lush green grass and summer oaks, the
       * Meadow's exact border tiles, so the buyer's first sight of a paid board is a sandpit in a
       * park." The terrain character is still `T` and the collision is byte-identical, because
       * `_level_selftest.js` proves reachability over the whole domain and a border that changed
       * SHAPE would invalidate those proofs for a purely visual fix. What changes is what is DRAWN:
       * on the Dunes a `T` is a date palm standing on sandstone, both from Verdant24_Desert (see
       * art_sources.js for the measurements that chose that pack). */
      /* ⛔ THE FRAME BELONGS TO THE BOARD, NOT TO THE TILE'S NOMINAL LAND. Keyed on `t.land` first,
       * and the Dunes came back with three desert edges and a GREEN HEDGE ACROSS THE TOP: the
       * screen's first two terrain rows carry `landRows` of `m` (the Mere), because that is the
       * neighbour you reach going north. Correct for the model and wrong for the picture — a solid
       * band of meadow oaks meeting sand at a razor line is the same "sandpit in a park" reading
       * from one side instead of four. A tree is impassable, so its land never decides anything the
       * player can act on; the SCREEN's land decides what its own frame is made of. ⚠️ Scoped to
       * trees deliberately: the Fell's `v` rows are walkable transition ground and must keep the
       * Vale's material. */
      var scr = w.screens && w.screens[t.screen];
      if ((scr && scr.land === 'dunes') || t.land === 'dunes') {
        /* the border's own ground, so the desert's edge is made of the desert */
        this.blit(this.pick('sandstone', d, tx, ty, false), px, py);
        var pv = hash2(tx, ty, 11);
        this.shadow(px, py, pv < 0.68);
        if (pv < 0.68) {
          /* ⛔⛔ FOUR PALMS, PICKED BY POSITION — round-3 major defect 4: "every palm along the
           * bottom row and down both columns has the same frond shape, the same lean and the same
           * pair of orange coconuts at the same spacing". It was ONE sprite stamped on a period.
           * The variants are derived in build_art.js through the same PROP_VARIANTS table the tree
           * border has used since round 2 (mirror, crop, and a strip that takes the fruit off two
           * of them); this is the line that was still asking for the single sprite.
           * ⚠️ A SEPARATE HASH SALT from `pv`. Re-using 11 would tie which palm is drawn to whether
           * a palm is drawn at all, so the gaps and the stumps would fall on the same variants
           * every time and the border would carry a longer, subtler period instead of none. */
          var pvv = 'prop/palm/all/v' + Math.floor(hash2(tx, ty, 29) * 4) + '/';
          this.blit(pvv + '00', px - 8, py - TILE);
          this.blit(pvv + '10', px + 8, py - TILE);
          this.blit(pvv + '01', px - 8, py);
          this.blit(pvv + '11', px + 8, py);
        } else if (pv < 0.86) {
          this.blit('prop/palm_stump/all/00', px, py);
        }
        /* pv >= 0.86: bare sandstone — a gap in the palms, which is what keeps a line of them from
         * being a fence in the desert as well */
        return;
      }
      /* The 2x2 tree: base on this tile, centred, so it overhangs into the cells above and beside —
       * which is how a row of them reads as a treeline rather than a row of bushes.
       * ⚠️ A HASHED VERTICAL JITTER, because a contiguous run of trees drew a perfectly flat canopy
       * line and read as a picket fence in the four-season plate. Each tree's right half is
       * overdrawn by its neighbour, so without the jitter every one shows the same 16 px of itself
       * at the same height. Two pixels of variation is enough to break the rhythm (tilesets §4b-1
       * rule 2: a full-span feature at a FIXED offset is a pattern, not a texture). The jitter is a
       * function of the tile only, so it never flickers between frames. */
      var jy = Math.floor(hash2(tx, ty, 9) * 3);
      /* ⛔⛔ AND THE JITTER WAS NOT ENOUGH, BECAUSE IT MOVED ONE SPRITE RATHER THAN CHOOSING AMONG
       * SEVERAL. Major defect 3: "the same bare tree appears at x = 0, 100, 200, 300, 400 of a
       * 420-px 3x crop ... It reads as a picket fence, not a forest edge." Two pixels of height on
       * one silhouette cannot fix a repeated silhouette — the eye is matching the SHAPE.
       * build_art.js now derives four trunk-and-canopy variants per season (the pack's own, its
       * mirror at a measured 69% pixel difference, and two shorter cuts), and the variant is chosen
       * by a hash of the tile position exactly as the ground variants are.
       * ⛔ AND NO TWO ADJACENT CELLS TAKE THE SAME ONE: a plain hash puts neighbours on the same
       * variant about a quarter of the time, and a repeated pair is the thing being fixed. The
       * west neighbour's variant is excluded by rotating past it, which is deterministic, needs no
       * state, and cannot flicker. */
      var tv = treeVariant(w, t, tx, ty);
      /* the tree's shadow goes down before its trunk, and takes the WIDE footprint: a 12-px
       * ellipse under a 32-px canopy reads as a puddle, not as the tree's own shadow */
      this.shadow(px, py, true);
      var tk = 'prop/tree/' + season + '/v' + tv + '/';
      this.blit(tk + '00', px - 8, py - TILE - jy);
      this.blit(tk + '10', px + 8, py - TILE - jy);
      this.blit(tk + '01', px - 8, py - jy);
      this.blit(tk + '11', px + 8, py - jy);
      return;
    }
    if (t.type === 'cliff') {
      /* ⛔ ONLY AN EXPOSED CROWN IS LIT. A cliff with another cliff directly above it has no top
       * edge to catch the light; lighting every tile made a cliff face read as stacked shelves
       * with a bright line every 16 px (seen in this stage's first board capture, and the same
       * defect tilesets §4b-1 rule 7 shipped live once). Look north and pick. */
      var above = w.tile(tx, ty - 1);
      var capped = !(above && above.type === 'cliff');
      /* ⛔⛔ SEASONAL SINCE ROUND 5, and the `false` that used to sit here was the whole of the art
       * director's blocking defect 2: "between winter and spring only the rectangle recolours — the
       * dial does nothing visible to the fell". The cliff was staged as `ground/cliff/all/<v>`, so
       * there was nothing for the dial to reach. Four states and eight morph steps now exist
       * (build_art.js deriveCliffSeason), and this argument is what asks for them. */
      this.blit(this.pick(capped ? 'cliff' : 'cliff_body', d, tx, ty, true), px, py);
      /* ⛔⛔ THE FELL HAS FURNITURE ON IT — round-5 blocking 2, and it does double duty.
       *
       * The review asked for "one prop per four tiles from a fell family (boulders, scree, a cairn,
       * a broken wall, heather and lichen patches)" because the slate had NOTHING on it. It also
       * fixes something found by looking at the rebuilt board: four tile variants of a high-contrast
       * faceted rock TILE VISIBLY across a field this large — the crag came back reading as
       * patterned wallpaper, which is the same "placeholder" verdict by another route. Furniture
       * breaks the period in a way more tile variants would only postpone.
       *
       * ⛔ SAFE BY CONSTRUCTION: these sit on CLIFF tiles, which already block, so not one of them
       * can change what the player can reach. The vale/fell geometry is load-bearing for the
       * four-season walk and `_gates_selftest.js` is what says so — this pass never touches it.
       * ⚠️ A separate hash salt from `pick`'s, so which cells carry furniture is independent of
       * which rock variant they drew (the lesson pickSand's crests record). */
      var fh = hash2(tx, ty, 61);
      if (fh < 0.26) {
        var which = hash2(tx, ty, 67);
        if (which < 0.34) this.blit('object/cairn', px + 2, py + 2);
        else if (which < 0.72) this.blit('object/scree', px, py + 6);
        else this.blit('prop/rock/' + season + '/00', px, py);
      }
      return;
    }

    /* ⛔⛔ ONE DECISION, ONE CHOOSER. This used to be a SECOND rule for the same question —
     * `t.land === 'dunes' ? sand : inscription ? stone : grass` — sitting on top of `groundKey`'s
     * own fallback and overdrawing whatever it had just decided. So when round 5 fixed the fallback
     * (a prop stands on what its neighbours stand on) the green meadow square in the desert did not
     * move one pixel, because this line drew it afterwards. §2b's rule about a shared fact: two
     * copies of a decision drift the moment one of them is corrected, and the one nobody edited wins.
     * The ground under a prop is now asked of the same function the rest of the board asks. */
    this.blit(this.groundKey(w, t, w.surface(tx, ty), tx, ty, d), px, py);

    /* ⛔ A CONTACT SHADOW, BECAUSE NOTHING IN THIS GAME CAST ONE. The pack bakes one into its own
     * props for the meadow they were drawn against; every object authored here — sign, ruin,
     * glyph, inscription — stood on the ground with no contact at all, and beside Alwa's rooms
     * that is most of what reads as flat. See build_objects.js softShadow for why it is alpha. */
    this.shadow(px, py, false);

    /* ⛔ THE DUNES' STANDING PROP IS A CACTUS, NOT THE MEADOW'S ROCK. Last clause of major defect 5:
     * "the grey rounded object near the hero reads as a gravestone". It is `prop/rock` — the spine's
     * grey meadow boulder — sitting on sand in a paid board's store image. VerdantProps ships two
     * desert cacti in a transparent form; which one is a hash of the tile, so a board with several
     * does not repeat one silhouette (the same rule the tree border needed). */
    var scrL = w.screens && w.screens[t.screen];
    var inDunes = (scrL && scrL.land === 'dunes') || t.land === 'dunes';
    if (t.type === 'rock' && inDunes) {
      /* ⛔ THREE FORMS, NOT TWO. Round-4 minor 9 asked for more props AND for more than one kind of
       * prop; adding count alone would have made one sprite repeat eight times, which is the palm
       * border's old defect moved inland. The dead palm stump already ships for the border's gaps,
       * so the third form costs no new art. */
      var dp = hash2(tx, ty, 17);
      this.blit(dp < 0.4 ? 'prop/cactus_barrel/all/00' : dp < 0.75 ? 'prop/cactus_column/all/00' : 'prop/palm_stump/all/00', px, py);
    } else if (t.type === 'rock' && ((scrL && scrL.land === 'fell') || t.land === 'fell')) {
      /* ⛔⛔ ONE OUTLINE AND SHADOW POLICY PER BOARD — round-6 minor 12. "Two rock hands 130 px apart
       * on shot_7: the pack boulders are warm brown-grey with a soft green baked shadow; the slate
       * props (cairns, scree, the column) are cool grey with a hard #1c1f2b outline and a hard drop
       * shadow. One board, two outline and shadow policies."
       *
       * The review offered two cures and the cheap one is also the right one: the Fell already HAS a
       * rock family — `object/cairn` and `object/scree`, authored in this project's own pens, cool
       * grey with the night-ink outline every other authored object here carries — and they are
       * already scattered over the crag by the furniture pass above. So a `rock` cell on the Fell
       * takes one of them instead of the pack's warm meadow boulder, and the board has ONE policy.
       * ⚠️ A separate hash salt again, so which form a rock takes is independent of anything else
       * the cell decided (the lesson `pickSand`'s crests record).
       * ⛔ The DUNES branch above stays exactly as it is: that board's answer is a cactus, and this
       * is not a licence to make every land's rock an exception — each one names its own family. */
      this.blit(hash2(tx, ty, 23) < 0.55 ? 'object/cairn' : 'object/scree', px, py);
    } else if (t.type === 'rock') this.blit('prop/rock/' + season + '/00', px, py);
    else if (t.type === 'ruin') this.blit('object/ruin', px, py);
    else if (t.type === 'sign') this.blit('object/sign', px, py - TILE);
    else if (t.type === 'glyph') this.blit('object/glyph', px, py);
    else if (t.type === 'inscription') this.blit('object/inscription', px, py - TILE);
    else this.blit('prop/shrub/' + season + '/00', px, py);
  };

  /**
   * A contact shadow on the ground at a tile's foot. `wide` picks the 22-px footprint for a tree.
   * ⚠️ Anchored on the tile's BOTTOM EDGE, not its centre, because that is where a standing thing
   * touches the floor (§6b-31: anchor a sprite by the FIGURE, not the cell).
   */
  Renderer.prototype.shadow = function (px, py, wide) {
    var key = wide ? 'object/shadow_wide' : 'object/shadow';
    var e = this.atlas.index && this.atlas.index[key];
    if (!e) { this.blit(key, px, py); return; }        /* blit() records the miss by name */
    this.blit(key, px + Math.round((TILE - e.w) / 2), py + TILE - e.h - 1);
  };

  /** Reeds are a prop on grass, not a block — drawn in the ground pass's wake. */
  Renderer.prototype.drawHero = function (run, ox, oy) {
    var h = run.hero;
    var dir = h.fy > 0 ? 'south' : h.fy < 0 ? 'north' : h.fx < 0 ? 'west' : h.fx > 0 ? 'east' : 'south';
    /* two-frame walk, advanced by distance travelled so the cycle matches the feet */
    var moving = (h.fx || h.fy) && !h.still;
    var frame = moving ? (Math.floor((h.x + h.y) / 8) % 2) : 0;
    var hx = Math.round(h.x - ox * TILE), hy = Math.round(h.y - oy * TILE) + LAYOUT.BOARD_Y;
    /* ⛔ THE HERO CAST NO SHADOW EITHER, and he is the object a buyer looks at. Down before the
     * sprite, anchored at his feet — the sprite is 24x32 blitted from (hx-12, hy-32), so his feet
     * are at hy. ⚠️ NOT drawn when he is on a boat or in the water: a shadow on open water at the
     * moment he is swimming or drowning would say the wrong thing about the surface, and the two
     * surfaces are exactly what this product spent a session making distinguishable. */
    /* ⛔⛔ ICE IS NOT WATER FOR THIS PURPOSE, AND USING `isWet` HERE DELETED THE SHADOW FROM THE
     * ONE SURFACE THE WHOLE GAME IS ABOUT. `isWet` is the SHORELINE predicate — it answers "is this
     * cell's surface water-LIKE", and ice, thin ice and slush all say yes. So the hero cast a
     * contact shadow on grass and sand and cast NONE while standing on a frozen brook, which is the
     * product's central image and its store shot. An independent reviewer found it by deliberately
     * looking at the hero on near-white ice as a positive control, which is exactly the right place
     * to look for a missing shadow.
     * A shadow is wrong only where he is not STANDING on the surface: open water and slush (he is
     * swimming, boating or drowning). Ice carries him, so ice takes the shadow. */
    var hkind = (function (w2, tx2, ty2) {
      var t2 = w2.tile(tx2, ty2);
      if (!t2 || !t2.lake) return 'land';
      return w2.surface(tx2, ty2).kind;
    })(run.world, Math.floor(h.x / TILE), Math.floor(h.y / TILE));
    var onWater = (hkind === 'open' || hkind === 'slush');
    if (!onWater) {
      var e = this.atlas.index && this.atlas.index['object/shadow'];
      /* straddle the foot line rather than sitting entirely above it: a shadow wholly behind the
       * boots is hidden by them, which is what the first placement did */
      if (e) this.blit('object/shadow', hx - Math.round(e.w / 2), hy - Math.round(e.h / 2));
    }
    this.blit('hero/' + dir + '_' + frame, hx - 12, hy - 32);
  };

  /**
   * Season particles — petals, pollen, leaves, snow. ⭐ These are the one place the brief's
   * `real-assets` rule allows a primitive, because a particle IS a single lit pixel.
   */
  Renderer.prototype.particles_ = function (run) {
    var g = this.g, name = SEASON.nearest(run.world.dial.d);
    /* ⛔⛔ SEEDED AND CLOSED-FORM, for two reasons that turned out to be the same reason.
     *
     * (1) `Math.random()` seeded these, so the weather was DIFFERENT ON EVERY RUN — in a renderer
     *     whose every other "random" choice goes through `hash2` precisely so it cannot flicker.
     *     A capture harness cannot photograph the same frame twice, and two store shots of one
     *     board differ in ways nobody chose.
     * (2) The motion was Euler-integrated per frame (`p.x += Math.sin(p.p) * 0.4`). Scaling that by
     *     dt makes the RATE framerate-independent but not the POSITION: summing a nonlinear term at
     *     different step sizes lands in different places, so the 60 Hz and 20 Hz arms of
     *     `_probe_framerate.js` still diverged after the dt fix. Closed form removes the integration
     *     entirely — position is a pure function of the fixed-step clock, identical at any
     *     framerate and at any draw cadence, which is what the art director's assertion asks for.
     */
    var want = 16, i, p;
    while (this.particles.length < want) {
      var n = this.particles.length;
      this.particles.push({
        x0: hash2(n, 1, 77) * 320,
        y0: 20 + hash2(n, 2, 77) * 160,
        v: 12 + hash2(n, 3, 77) * 24,          /* px per second, was 0.2-0.6 per frame at 60 Hz */
        ph: hash2(n, 4, 77) * 6.283,
      });
    }
    /* ⛔⛔ THE MOTE PALETTE IS DERIVED FROM THE SEASON'S OWN ROW OF `PAL`, and that is the round-4
     * major defect 5 fixed at its real cause.
     *
     * The review: "The Mere draws autumn leaves on the water in spring and summer ... 0.110% orange
     * in spring and 0.871% in summer against 1.115% in autumn, while the Meadow gates correctly to
     * 0.000%", addressed to "the Mere water-litter / drift pass (the season gate)". ⚠️ THE GATE WAS
     * NEVER MISSING — this pass has been keyed on `SEASON.nearest(d)` since it was written. What was
     * wrong is what the gate SELECTED: the halo colours were a hand-typed second palette, and two of
     * its four rows were literally other seasons' entries — spring's halo was `#8C3B22`, which is
     * PAL.autumn.accent, and summer's was `#D1782F`, which is PAL.autumn.grass. MEASURED on the
     * shipped plates by exact colour before this edit (`Art/_probe_r5_motes.js`): 256 px of
     * PAL.autumn.accent on the spring Mere and 144 px of PAL.autumn.grass on the summer Mere, and
     * those are the only autumn-family pixels either plate carries. Autumn leaves in spring, drawn
     * by a correct gate reading a wrong table.
     *
     * ⛔ So the table is no longer typed. A season's mote is its own accent over its own shade, and
     * `_suites.js` asserts that no season's pair contains a colour from another season's row — a
     * hand-copied constant is a fact that moves when its source moves (§2b: a measurement copied
     * into a checker certifies the staleness it exists to catch). */
    /* ⛔ and the TABLE is chosen by the board, not only by the season — see MOTE_BARE's header for
     * the 256 pixels of cherry blossom this drew over a desert. */
    var scB = run.world.screens && run.world.screens[run.screen];
    var m = (scB && BARE_LANDS[scB.land]) ? MOTE_BARE[name] : MOTE[name];
    var col = m.core, halo = m.halo;
    /* ⛔ A CORE WITH A DIMMER HALO, NOT A LONE BRIGHT PIXEL. The art director's minor defect 18:
     * "Orange and yellow single-pixel specks over the Mere's water around the door platform read as
     * confetti or noise rather than fireflies or sparks." A single maximum-brightness pixel on a
     * busy dithered field is indistinguishable from the field's own highlights — it has no shape,
     * so the eye files it as noise. Two tones give it one. It is the same lesson the ice crack
     * needed (a dark line alone competes with the ice's own dither; a dark/light PAIR is an edge)
     * and the same one the hero's rim light needed, three times in one session.
     * ⭐ The framerate-bound drift below is unchanged here and recorded as still open. */
    for (i = 0; i < this.particles.length; i++) {
      p = this.particles[i];
      /* POSITION AS A PURE FUNCTION OF THE FIXED-STEP CLOCK — no accumulation, so the same
       * simulated time is the same pixel whatever the framerate or the draw cadence. */
      var T = this.clock || 0;
      var drift = p.v * (name === 'summer' ? -0.3 : 1) * T;
      var yy = p.y0 + drift;
      yy = 20 + (((yy - 20) % 160) + 160) % 160;                  /* wrap into the board band */
      var xx = p.x0 + Math.sin(p.ph + T * 3) * 8;
      xx = ((xx % 320) + 320) % 320;
      var px = xx | 0, py = yy | 0;
      var w = name === 'winter' ? 2 : 1, h = name === 'autumn' ? 2 : 1;
      /* ⛔ THE HALO IS ONE PIXEL, DOWN-RIGHT — not a cross. The first attempt at this fix drew the
       * dimmer tone on all four sides, which is five pixels of mass per particle: opened in
       * shot_4_the_mere.png the Mere's sixteen motes read as a dense orange SWARM over the water.
       * That is the art director's defect 18 made larger rather than fixed — "confetti" became
       * bigger confetti. A core with a single offset shadow gives a mote a SHAPE and a light
       * direction (the same upper-left source as everything else) at two pixels instead of five. */
      g.fillStyle = halo;
      g.fillRect(px + 1, py + 1, w, h);
      g.fillStyle = col;
      g.fillRect(px, py, w, h);                   /* the core */
    }
  };

  /* ---- type ----------------------------------------------------------------------------------- */

  /**
   * The game's own lettering, blitted from the atlas glyph sheet. ⛔ The brief forbids a browser
   * default ("never a browser default") and a 320x180 canvas rendering 8px system text is the
   * clearest amateur tell there is. `display` is the tall engraved face, `body` the small one.
   */
  Renderer.prototype.text = function (str, x, y, opts) {
    var o = opts || {};
    var face = o.face || 'body';
    var colour = o.colour || PAL.paper;
    var align = o.align || 'left';
    var s = String(str).toUpperCase();
    /* ADVANCE, not glyph width: the faces are 5x7 and 8x12 with one column of side bearing, so
     * the advances are 6 and 9. These must match build_objects.js or every centred line drifts. */
    var cw = face === 'display' ? 9 : 6;
    var width = s.length * cw, i, k;
    var dx = align === 'center' ? Math.round(x - width / 2) : align === 'right' ? x - width : x;
    if (!this.atlas.ready) return width;
    /* ⛔ AN OUTLINE, FOR TYPE THAT SITS ON THE BOARD RATHER THAN ON A PLATE. Round-5 minor: the
     * refusal whisper "runs across the water, over the stair, the stone and the hero's feet — it
     * reads as a debug label rather than a prop name". Type over a plate needs no outline because the
     * plate carries it; type over the LIVING BOARD has four seasons of ground behind it and no fixed
     * contrast, so without one it is a browser-console print laid on the picture. One pixel of the
     * night ink on all four sides is the pixel-art answer and costs no new glyphs.
     * ⚠️ Drawn as a ring UNDER the fill, so the letterform itself is unchanged and the advance is
     * identical — a centred line cannot drift because of this. */
    var OUT = [[-1, 0], [1, 0], [0, -1], [0, 1]], oi, sx0 = dx;
    if (o.outline) {
      for (oi = 0; oi < OUT.length; oi++) {
        dx = sx0;
        for (i = 0; i < s.length; i++) {
          k = 'font/' + face + '/' + s.charCodeAt(i);
          if (s[i] !== ' ') this.tinted(k, dx + OUT[oi][0], y + OUT[oi][1], o.outline === true ? PAL.ink : o.outline);
          dx += cw;
        }
      }
      dx = sx0;
    }
    /* tint: the glyph sheet ships white, and a coloured copy is produced by drawing it through a
     * composite rather than shipping one sheet per colour */
    for (i = 0; i < s.length; i++) {
      k = 'font/' + face + '/' + s.charCodeAt(i);
      if (s[i] !== ' ') this.tinted(k, dx, y, colour);
      dx += cw;
    }
    return width;
  };

  /** Draw an atlas entry recoloured. A tiny offscreen canvas is reused for every glyph. */
  Renderer.prototype.tinted = function (key, dx, dy, colour) {
    var e = this.atlas.index && this.atlas.index[key];
    if (!e) { this.missing[key] = (this.missing[key] || 0) + 1; this.stats.missing++; return false; }
    if (!this._tc) {
      this._tc = (typeof document !== 'undefined') ? document.createElement('canvas') : null;
      if (this._tc) { this._tc.width = 16; this._tc.height = 16; this._tg = this._tc.getContext('2d'); }
    }
    if (!this._tg) return false;
    this._tg.clearRect(0, 0, 16, 16);
    this._tg.globalCompositeOperation = 'source-over';
    this._tg.drawImage(this.atlas.img, e.x, e.y, e.w, e.h, 0, 0, e.w, e.h);
    this._tg.globalCompositeOperation = 'source-in';
    this._tg.fillStyle = colour;
    this._tg.fillRect(0, 0, e.w, e.h);
    this.g.drawImage(this._tc, 0, 0, e.w, e.h, dx, dy, e.w, e.h);
    this.stats.blits++;
    return true;
  };

  /**
   * ⚠️ LEADING. The body face is 7px tall and this used to advance 8px a line — ONE pixel of
   * leading, which photographed as cramped, run-together blocks on the error, loss and end cards
   * (the three screens made entirely of body text). 10px gives the face the same 1.4x leading a
   * book would use and costs 2px a line on cards that had dead space anyway. The display face keeps
   * 14 over a 12px cell for the same reason.
   */
  var LEAD = { display: 14, body: 10 };
  /**
   * How many lines `wrap` will produce, without drawing any of them.
   * ⛔ So a plate can be SIZED FROM ITS COPY instead of left at a round number. The art director's
   * major defect 11 was two cards with ~60% of the plate blank; the same file already records the
   * loss card being cut from 76 to a measured height for exactly that reason, and this makes the
   * measurement available rather than done by eye once.
   */
  Renderer.prototype.wrapLines = function (text, maxW, opts) {
    var o = opts || {}, cw = (o.face === 'display' ? 9 : 6);
    var words = String(text).split(' '), line = '', n = 1, i, test;
    for (i = 0; i < words.length; i++) {
      test = line ? line + ' ' + words[i] : words[i];
      if (test.length * cw > maxW && line) { n++; line = words[i]; } else line = test;
    }
    return n;
  };
  Renderer.prototype.wrap = function (text, x, y, maxW, opts) {
    var o = opts || {}, cw = (o.face === 'display' ? 9 : 6);
    var words = String(text).split(' '), line = '', yy = y, i, test;
    for (i = 0; i < words.length; i++) {
      test = line ? line + ' ' + words[i] : words[i];
      if (test.length * cw > maxW && line) { this.text(line, x, yy, o); line = words[i]; yy += (o.face === 'display' ? LEAD.display : LEAD.body); }
      else line = test;
    }
    if (line) this.text(line, x, yy, o);
    return yy + (o.face === 'display' ? LEAD.display : LEAD.body);
  };

  /* ---- the dial ------------------------------------------------------------------------------- */

  /**
   * THE MOTIF. The brief: "the dial ring of four season glyphs (bud, sun, leaf, snowflake) — HUD,
   * title frame, save slots, pause, credits, cover", and "our dial is ONE solid drawn ring with a
   * pointer, fixed bottom-right, the four glyphs engraved in it, never detached pips."
   * The ring, its four engraved glyphs and the pointer are drawn art in the atlas; the only thing
   * computed here is the pointer's ANGLE and the strain arc.
   */
  Renderer.prototype.drawDial = function (dial, home) {
    var g = this.g;
    var cx = LAYOUT.DIAL_X, cy = LAYOUT.DIAL_Y, r = LAYOUT.DIAL_R;
    /* 1.7 rad per FRAME was 102 rad/s at 60 Hz and 245 at 144; the clock keeps it at 102 everywhere.
     * ⚠️ `_sabotageShake` is the control arm of `_probe_framerate.js` and nothing else ever sets it:
     * it puts this effect back on the frame counter so the 60 Hz / 20 Hz comparison MUST go red.
     * ⛔ The control was first aimed at the title screen's prompt blink and reported red — but that
     * test drives the BOARD, so the title branch never ran and the redness came from the particles'
     * `Math.random()` seeding instead. A sabotage that goes red for a reason other than the one it
     * names is worth nothing (§2b: judge an arm on WHICH assertion fired), and it hid the real
     * finding until the particles were made deterministic. The ring shake is on screen during play,
     * which is where this test looks. */
    var shakePhase = this._sabotageShake ? this.stats.frames * 1.7 : (this.clock || 0) * 102;
    var shake = dial.s > 0.5 ? (Math.sin(shakePhase) * (dial.s - 0.5) * 2) : 0;
    var bx = Math.round(cx + shake) - 32, by = cy - 32;

    /* ⛔⛔ THE RING HAD NO FACE, SO THE GAME'S ENTIRE INTERFACE WAS DRAWN ON THE WORLD.
     *
     * An independent reviewer, polish round 5: "the world renders straight through the ring's
     * interior. On the winter board the bronze ring sits on brown tree trunks and brown snow-speckle
     * and is very nearly invisible. This is the game's entire interface." CONFIRMED by opening the
     * dial at 4x on shot_6: grass, a tree and the brook run through the instrument, and the pointer
     * is dark bronze ON GREEN.
     *
     * A dial is an object with a FACE. This is that face — the night ink, so the board still shows
     * through as a shadow under glass (the ring is part of the world, not a dashboard: the brief
     * bans "the code-drawn dark-dashboard look") but every mark on the instrument has one consistent
     * ground to be read against. ⚠️ Drawn BEFORE the ring art, so the band's own bevel still sits on
     * top and the face cannot cover it.
     *
     * ⛔⛔ AND "IN EVERY SEASON" WAS THE HALF THAT WAS NOT TRUE — round-7 reviewer finding 4, measured
     * on the shipped plates (`Art/_probe_r7_verify.js`, needle-vs-disc |dL| over the disc's own SD):
     *
     *     spring 4.72 · summer 4.78 · spring-on-the-fell 4.00 · WINTER 2.47
     *
     * because the face was 62% and a snow board is both brighter and far busier than grass, so 38% of
     * it came through and the disc's SD went 18.1 -> 26.0. Half the contrast margin, in the one season
     * the game's headline plate sells, on the instrument the game is named after — and the tell was
     * that a warm-pixel classifier aimed at the needle caught 1,985 px in winter against ~830 in every
     * other season: the tree trunks were showing through the glass INTO the needle's own colour range.
     * ⛔ THE NEW VALUE IS DERIVED, NOT PICKED. Residual board SD is (1 - alpha) x boardSD, so winter's
     * boardSD is 26.0 / 0.38 = 68.4; to hold the margin at the weakest good reading (4.00) the disc
     * needs SD <= 64.3 / 4.00 = 16.1, i.e. alpha >= 1 - 16.1/68.4 = 0.765. 0.78 is that, rounded up.
     * The board is still legible through the glass; it is simply no longer competing with the needle. */
    g.save();
    g.fillStyle = 'rgba(28,31,43,0.78)';
    g.beginPath();
    g.arc(cx + shake, cy, r - 1, 0, Math.PI * 2);
    g.fill();
    g.restore();

    this.blit('object/dial_ring', bx, by);

    /* ⛔ THE HOME NOTCH WAS A WHITE SQUARE — the art director's round-2 major defect 2 lists it
     * among the four things that made this a "placeholder gauge": "a white square knob". #F2F7FB is
     * the PAPER tone, the brightest thing in the palette, stamped as a 3x3 block on the outside of a
     * weathered bronze ring. It is now a small GOLD NOTCH cut into the band's outer edge — two
     * pixels of the ring's own highlight with a dark shoulder, which is a mark on the metal rather
     * than a UI dot laid over it. */
    var ha = -Math.PI / 2 + home * Math.PI / 2;
    var hx = Math.round(cx + shake + Math.cos(ha) * (r + 3)), hy = Math.round(cy + Math.sin(ha) * (r + 3));
    g.fillStyle = '#2a241c';
    g.fillRect(hx - 2, hy - 2, 4, 4);
    g.fillStyle = '#e0b93f';
    g.fillRect(hx - 1, hy - 1, 2, 2);

    /* ⛔ THE STRAIN NOW FILLS THE BAND ITSELF, instead of drawing a bright yellow hoop OUTSIDE the
     * ring. At r + 4 it sat clear of the metal (the band spans r−4..r+4), so the one piece of live
     * feedback the dial gives was a separate floating arc — a second widget, when the whole defect
     * is that the motif is drawn twice. A 7-px stroke centred on r covers the band exactly, so the
     * ring itself glows warm as the player pushes the year away from where it wants to be. */
    if (dial.s > 0.02) {
      g.save();
      g.globalCompositeOperation = 'lighter';
      g.strokeStyle = 'rgba(150,86,28,' + (0.18 + dial.s * 0.55).toFixed(2) + ')';
      g.lineWidth = 7;
      g.beginPath();
      g.arc(cx + shake, cy, r, -Math.PI / 2, -Math.PI / 2 + dial.s * Math.PI * 2);
      g.stroke();
      g.restore();
    }

    /* ⛔⛔ THE NEEDLE IS DRAWN, NOT A ROTATED BITMAP — A ROTATED BITMAP SHEARS.
     *
     * This blitted `object/dial_pointer` inside `g.rotate(dial.d * PI/2)`. At the four cardinal
     * angles that is a clean 90° step and the sprite is exact; at every angle BETWEEN them the
     * canvas resamples a 2-px-wide pixel-art stem with smoothing disabled, and the stem breaks up.
     * An independent reviewer: "at diagonals the needle breaks into a bar and a DETACHED ARROWHEAD
     * with a visible gap" — confirmed by opening the dial at 4x on shot_6 (dial 1.2), where the bar
     * is two misaligned rectangles and the head floats clear of it.
     *
     * ⛔ The honest fixes are to pre-render N rotations into the atlas or to draw the shape. Drawing
     * it wins here: the needle is a solid tapered form, so a filled path is CONNECTED BY
     * CONSTRUCTION at any angle, it costs no atlas space, and the ring it sits in is itself a drawn
     * circle. Anti-aliasing softens its edge by a pixel — a soft needle beats a broken one, and it
     * is the only drawn-not-blitted mark on the board.
     * ⚠️ Tones are the ring's own metal so the instrument stays one object: the dark shoulder first,
     * the lit face over it, and the gold head that the four medallions already use. */
    var pa = dial.d * Math.PI / 2 - Math.PI / 2;     /* 0 = spring = straight up */
    var px0 = cx + shake, py0 = cy;
    var tipX = px0 + Math.cos(pa) * (r - 3), tipY = py0 + Math.sin(pa) * (r - 3);
    var nx = Math.cos(pa + Math.PI / 2), ny = Math.sin(pa + Math.PI / 2);
    g.save();
    /* the shaft: a tapered quad from a 3px-wide boss at the centre to a 1px neck under the head */
    var neckX = px0 + Math.cos(pa) * (r - 9), neckY = py0 + Math.sin(pa) * (r - 9);
    var shaft = function (w0, w1, fill) {
      g.fillStyle = fill;
      g.beginPath();
      g.moveTo(px0 + nx * w0, py0 + ny * w0);
      g.lineTo(neckX + nx * w1, neckY + ny * w1);
      g.lineTo(neckX - nx * w1, neckY - ny * w1);
      g.lineTo(px0 - nx * w0, py0 - ny * w0);
      g.closePath();
      g.fill();
    };
    shaft(3.2, 2.0, '#2a241c');                       /* the shoulder, drawn first and wider */
    shaft(2.0, 1.0, '#8a6a3a');                       /* the lit face of the metal */
    /* the head: a triangle whose base sits ON the neck, so it can never float free of the shaft */
    g.fillStyle = '#2a241c';
    g.beginPath();
    g.moveTo(tipX + Math.cos(pa) * 1.5, tipY + Math.sin(pa) * 1.5);
    g.lineTo(neckX + nx * 4.2, neckY + ny * 4.2);
    g.lineTo(neckX - nx * 4.2, neckY - ny * 4.2);
    g.closePath();
    g.fill();
    g.fillStyle = '#e0b93f';
    g.beginPath();
    g.moveTo(tipX, tipY);
    g.lineTo(neckX + nx * 3.0, neckY + ny * 3.0);
    g.lineTo(neckX - nx * 3.0, neckY - ny * 3.0);
    g.closePath();
    g.fill();
    /* the boss the needle turns on */
    g.fillStyle = '#2a241c';
    g.beginPath(); g.arc(px0, py0, 3.4, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#8a6a3a';
    g.beginPath(); g.arc(px0, py0, 2.1, 0, Math.PI * 2); g.fill();
    g.restore();
  };

  /* ---- HUD ------------------------------------------------------------------------------------ */

  Renderer.prototype.hud = function (run, game) {
    var g = this.g, w = run.world;
    /* a thin strip, not a dark dashboard: the brief bans "the code-drawn dark-dashboard look" */
    g.fillStyle = PAL.ink;
    g.fillRect(0, 0, LAYOUT.W, LAYOUT.HUD_H);
    g.fillStyle = seasonColour(w.dial.d, 'accent');
    g.fillRect(0, LAYOUT.HUD_H - 1, LAYOUT.W, 1);

    var t = w.tile(run.hero.tx(), run.hero.ty());
    var land = t && t.land ? w.lands[t.land].name : '';
    this.text(land, 6, 7, { face: 'body', colour: PAL.paper });
    this.text(SEASON.nearest(w.dial.d), 160, 7, { face: 'body', colour: seasonColour(w.dial.d, 'accent'), align: 'center' });
    /* ⭐ a muted game must SAY it is muted, or the player's first conclusion is that it is broken.
     * Right-aligned in the strip so it never collides with the centred season name. */
    if (game && game.sound && game.sound.muted) this.text('muted', 314, 7, { face: 'body', colour: PAL.dim, align: 'right' });
    this.drawDial(w.dial, run.home());
  };

  /* ---- screens -------------------------------------------------------------------------------- */

  /**
   * ⛔ NAME THE CONTROL THE PLAYER ACTUALLY HAS.
   *
   * The world's signs teach the game, and a sign that says "hold Q or E" is wrong for two of the
   * four input paths this build supports — a phone has no Q and neither does a gamepad. The texts
   * carry a {TURN} token instead and it is resolved HERE, at draw time, against what the player has
   * actually touched, so the same sign reads correctly on a keyboard, a pad and a thumb.
   *
   * ⚠️ Resolved in the RENDERER rather than baked into content.js on purpose: a player can pick up
   * a pad halfway through, and the sign should change when they do.
   */
  /** Is this player driving with a thumb and only a thumb? Every "press enter" on every card is a
   *  lie if so, and there is no keyboard to correct it with. */
  function touchOnly(game) {
    var seen = (game && game.input && game.input.seen) || {};
    return !!seen.touch && !seen.key;
  }

  function controlWords(text, game) {
    if (typeof text !== 'string' || text.indexOf('{') < 0) return text;
    var seen = (game && game.input && game.input.seen) || {};
    var turn = 'Q or E';
    if (seen.touch && !seen.key) turn = 'a thumb on the dial';
    else if (seen.pad && !seen.key) turn = 'a shoulder button';
    return text.replace(/\{TURN\}/g, turn);
  }

  /**
   * ⛔⛔ A PLATE MADE OF THE RING, THAT DOES NOT COVER THE RING. The art director's major defect 7:
   *
   *   "Every UI plate covers the dial ring and none carries the motif. The message plate, the pause
   *    plate, the demo-end card and the ending card all overlap the ring's upper-left arc; only the
   *    error card was derived to avoid it. All four are plain navy rectangles with one coloured rule
   *    — the doctrine's 'dark dashboard drawn in code' — while the brief made the ring the motif of
   *    title, pause, saves and credits, and shot_6's own caption claims EVERY SCREEN CARRIES THE
   *    RING."
   *
   * Two fixes, and the first is geometric so it cannot regress:
   *
   * 1. THE PLATE'S RIGHT EDGE IS DERIVED FROM THE DIAL, never typed. `plateRight()` returns
   *    DIAL_X − DIAL_R − margin, so moving the dial moves every plate out of its way automatically.
   *    Hand-typed rects are how three of the four came to overlap while the fourth did not.
   * 2. THE FRAME IS THE RING'S OWN METAL: a 2-px engraved bronze border (dark rim, lit inner edge
   *    top-left, shadowed bottom-right — the same one light source as everything else) with the four
   *    engraved season bosses at the corners, blitted from the atlas pieces `build_objects.js` now
   *    emits from the very cell lists the ring engraves. The season-tinted rule stays as the heading
   *    divider, and the pointer tick sits in it, so the plate says which season is being held.
   */
  var PLATE_MARGIN = 4;
  function plateRight() { return LAYOUT.DIAL_X - LAYOUT.DIAL_R - PLATE_MARGIN; }

  Renderer.prototype.plate = function (d, x, y, w, h) {
    var g = this.g;
    /* ⛔ CLAMP TO CLEAR THE DIAL. Published as a function so the suite can assert it rather than
     * re-typing the arithmetic (a measurement copied into a checker certifies the checker). */
    var maxW = plateRight() - x;
    if (w > maxW) w = maxW;

    /* ⛔ OPAQUE. Round-3 minor defect 7: "the pause plate is translucent enough that the sluice
     * column and the dock show through it as a dark pillar and grey smudges beside the menu text —
     * reads as dirt on the UI rather than deliberate glass."
     * ⚠️ The fix it offers is "plate alpha >= 0.92", and the plate was ALREADY 0.94 — measured here
     * before changing anything (wing §0z-1d). Six percent of a dark grey sluice column behind dark
     * plate ink is exactly the faint smudge the review describes, so the stated bar was already met
     * and the defect was real anyway: at this contrast the threshold was never the right instrument.
     * The review's own second option is taken instead — an opaque plate — which cannot show
     * anything through it at any contrast. The bronze frame and the corner bosses are unchanged, so
     * the plate still reads as an object rather than a box. */
    g.fillStyle = '#1c1f2b';
    g.fillRect(x, y, w, h);

    /* the engraved bronze frame — dark rim outside, bevel inside */
    g.fillStyle = '#1c1f2b';
    g.fillRect(x, y, w, 1); g.fillRect(x, y + h - 1, w, 1);
    g.fillRect(x, y, 1, h); g.fillRect(x + w - 1, y, 1, h);
    g.fillStyle = '#e0b93f';                                  /* lit: top and left */
    g.fillRect(x + 1, y + 1, w - 2, 1); g.fillRect(x + 1, y + 1, 1, h - 2);
    g.fillStyle = '#6b4227';                                  /* shadowed: bottom and right */
    g.fillRect(x + 1, y + h - 2, w - 2, 1); g.fillRect(x + w - 2, y + 1, 1, h - 2);

    /* the four season bosses, one per corner, in the ring's order: spring top-left, summer
     * top-right, autumn bottom-right, winter bottom-left — the same way round as the ring */
    var bosses = [['spring', x + 2, y + 2], ['summer', x + w - 9, y + 2],
      ['autumn', x + w - 9, y + h - 9], ['winter', x + 2, y + h - 9]];
    for (var bi = 0; bi < bosses.length; bi++) {
      this.blit('object/mark_' + bosses[bi][0], bosses[bi][1], bosses[bi][2]);
    }

    return { x: x, y: y, w: w, h: h };
  };

  /**
   * A plate's heading: the title, then the season rule UNDER it, then the dial's pointer tick in
   * that rule so the plate says which season is being held.
   *
   * ⛔ THE RULE'S Y IS DERIVED FROM THE TYPE, NOT GUESSED, and that is not a style preference — this
   * project has already shipped a gold rule drawn straight through the feet of its own headline
   * (86 of 433 snow pixels overdrawn, on the best image in the gallery). The display cell is 12
   * rows; the rule sits 3 below it. The sibling invariant in build_plates.js says the same thing in
   * the same words, and the reason both say it is that it was enforced on one path and not the
   * other (§6b-18: an invariant enforced on ONE path is not enforced).
   */
  var PLATE_TITLE_DY = 6, DISPLAY_CELL = 12, PLATE_RULE_GAP = 3;
  Renderer.prototype.plateHeading = function (p, d, title, colour) {
    var g = this.g;
    var cx = p.x + Math.round(p.w / 2);
    var ty = p.y + PLATE_TITLE_DY;
    this.text(title, cx, ty, { face: 'display', colour: colour || PAL.summer.accent, align: 'center' });
    var ry = ty + DISPLAY_CELL + PLATE_RULE_GAP;
    g.fillStyle = seasonColour(d, 'accent');
    g.fillRect(p.x + 10, ry, p.w - 20, 1);
    /* the tick at the dial's own angle round the year */
    var tickX = Math.round(p.x + 10 + (p.w - 20) * (((d % 4) + 4) % 4) / 4);
    g.fillRect(tickX, ry - 2, 1, 5);
    return ry + 6;                     /* where the body may begin */
  };
  /**
   * ⛔⛔ THE WHISPER — WHY THE YEAR JUST REFUSED YOU. The art director's major defect 12:
   *
   *   "Silent refusals. hero.lastRefusal is written in four places and read nowhere: in a deduction
   *    game the player walks into deep water or a ledge and is told nothing — the wing's own law is
   *    that every refusal names its reason, and here the reason is computed and discarded."
   *
   * That law is wing §0z-1c, and it was already paid for on this product: a unit mismatch into a
   * bounds check made open grass read as a wall, and the ONLY reason it was findable was that every
   * refusal recorded a reason. The reasons were being recorded and thrown away, which is the same
   * defect one step later — a dead reader is an untested code path.
   *
   * ⛔ THE TIMER IS IN MODEL STEPS, NOT FRAMES, and that is deliberate: the model steps at a fixed
   * rate off game.js's accumulator, so a whisper that lasts 40 steps lasts the same wall-clock time
   * on a 60 Hz and a 144 Hz display. Five presentation effects in this renderer are framerate-bound
   * (the art director's minor defect 16 — snow falls 2.4x too fast at 144 Hz); this one is not,
   * because it never counts frames.
   */
  var REFUSAL_STEPS = 40;
  Renderer.prototype.refusal = function (run) {
    var r = run.hero.lastRefusal;
    var step = run.stats.steps;
    if (r && r.why) {
      var sig = r.why + '@' + r.tx + ',' + r.ty;
      if (this._refusalSig !== sig) { this._refusalSig = sig; this._refusalStep = step; }
      this._refusalWhy = r.why;
    }
    if (!this._refusalWhy || step - this._refusalStep > REFUSAL_STEPS) return;
    /* above the dial, in the dim paper tone: a note, not an alarm.
     * ⛔ OUTLINED since round 5: this line sits directly on the board — the reviewer read it over the
     * Mere's water, the island stair and the hero's feet and called it a debug label. It has no plate
     * behind it by design (a transient note should not blank a sixth of the screen), so the contrast
     * has to come from the type itself. Also lifted clear of the paper tone to the brighter one: dim
     * over dark water was illegible as well as unanchored. */
    this.text(this._refusalWhy, LAYOUT.DIAL_X - LAYOUT.DIAL_R - 6, LAYOUT.DIAL_Y - LAYOUT.DIAL_R - 12,
      { face: 'body', colour: PAL.paper, align: 'right', outline: true });
  };

  /**
   * THE FOUR-SEASON SIGIL — one place, four times a year, in 34 pixels of the game's own tiles.
   * Used on the demo-end card so the screen whose job is to convert shows the product's argument
   * rather than describing it (the art director: "the demo-end card carries a miniature of the
   * four-season 2x2 beside the buy line so the pitch is a picture, not a sentence").
   * ⚠️ Built from the SHIPPED ground tiles, so it can never disagree with the boards it advertises.
   */
  /**
   * ⛔⛔ THE ENDING'S PICTURE — round-4 major defect 3.
   *
   * "The $9.99 ending is a text card over the darkened title art, built exactly like the loss card.
   *  Nothing pictures what the player earned — the drowned door open below the lowest water. The
   *  payoff of the purchase reads like the failure screen with different words."
   *
   * So the win gets the thing it is about: the door OPEN, standing on the bed the water left, with
   * the lowest water held back along the top of the frame. ⛔ Built from the SHIPPED tiles and the
   * SHIPPED door sprite — the same rule the season sigil beside it follows — so the last screen of
   * the paid game cannot show a door the game does not contain. The bronze frame is the sigil's, so
   * the two miniatures on the two end cards are one family.
   *
   * ⚠️ 80x48: five tiles by three. Any smaller and the door's arch is under ten pixels; any larger
   * and the card stops fitting the 320x180 canvas with its copy.
   */
  Renderer.prototype.doorPlate = function (x, y) {
    var g = this.g, tx, ty;
    var W = 96, H = 64;
    g.save();
    g.beginPath(); g.rect(x, y, W, H); g.clip();
    /* the bed the water came off, under everything */
    for (ty = 0; ty < 4; ty++) {
      for (tx = 0; tx < 6; tx++) this.blit('ground/mud/all/' + ((tx + ty) % 4), x + tx * 16, y + ty * 16 - 4);
    }
    /* the LOWEST water, held along the top of the frame — this is what "below the lowest water" is */
    g.save();
    g.beginPath(); g.rect(x, y, W, 13); g.clip();
    for (tx = 0; tx < 6; tx++) this.blit('ground/water/spring/' + (tx % 4), x + tx * 16, y - 3);
    g.restore();
    /* the waterline reads as a SHELF, not a cut: the water's own pale shallow tone at the edge and a
     * soft shadow on the bed below it — the same section the shoreline tiles carry */
    g.fillStyle = 'rgba(158,196,214,0.85)'; g.fillRect(x, y + 12, W, 1);
    g.fillStyle = 'rgba(28,31,43,0.35)'; g.fillRect(x, y + 13, W, 2);
    /* ⛔ THE DAMP BAND — round-5 minor: "the bed shows no damp band under the water line". Bed that
     * the water came off an hour ago is WET, and it dries downward; without that the waterline is a
     * colour change rather than an event. Three rows, fading, over the bed and under the door. */
    g.fillStyle = 'rgba(28,31,43,0.22)'; g.fillRect(x, y + 15, W, 2);
    g.fillStyle = 'rgba(28,31,43,0.12)'; g.fillRect(x, y + 17, W, 2);
    /* ⛔⛔ THE DOOR IS THE SUBJECT, SO IT IS DRAWN AT 2x. At 1:1 the shipped 16x32 sprite read as a
     * pale slot in a brown field — measured by looking at the first cut of this plate. Wing
     * §0-ART-b2: every product that has sold here is one board and ONE LARGE OBJECT. */
    /* ⚠️ AT y+2 THE SPRITE FITS EXACTLY. Its rows 0-1 and 31 are blank, so the drawn art runs y+6 to
     * y+63 inside a 64-tall plate — nothing is clipped. That is worth stating because the thing that
     * WAS clipped here was a second stone step drawn at 2x below the threshold: 18 of its 32 rows fell
     * outside the plate and it read as rubble heaped against the door. An independent reviewer saw the
     * cut ("the stone base is cut off by the frame") and it is gone — the sprite carries its own
     * threshold, which is what a step is for. */
    /* ⛔ THE DOOR'S OWN SHADOW — round-5 minor: "it casts no shadow ... the frame sits ON the mud like
     * a cut-out rather than IN it". Light is upper-left everywhere in this game, so the frame throws
     * down and to the RIGHT: a band under the sill and a strip down the outside of the right jamb.
     * Drawn BEFORE the door so the sprite's own edge stays crisp on top of it. */
    var dX = x + Math.round((W - 32) / 2), dY = y + 2;
    g.fillStyle = 'rgba(28,31,43,0.45)';
    g.fillRect(dX + 4, dY + 60, 32, 3);          /* the sill's contact shadow on the bed */
    g.fillRect(dX + 62, dY + 10, 3, 52);         /* down the right jamb's outer edge     */
    g.fillStyle = 'rgba(28,31,43,0.25)';
    g.fillRect(dX + 2, dY + 63, 36, 2);          /* the skirt, one tone softer           */

    /* ⛔⛔ SOMETHING COMES OUT OF THE DOOR — round-6 major 6, and it is the last thing a $9.99 buyer
     * sees. "THE PAID ENDING IS A PICTURE OF A GREY DOOR ON MUD ... the round-5 minor (shadow line,
     * damp band) was done and the picture is still a diagram: no light comes out of an open door 'the
     * year let you in' through, no figure stands at it, nothing in the frame is the reward for a whole
     * year's turning."
     *
     * Four things, in the order light actually behaves, all of them drawn BEFORE the door sprite so
     * its own jambs stay crisp on top and nothing has to be cut around:
     *   1. the doorway's interior filled with a warm gold-to-amber ramp, banded in three flat steps
     *      rather than a canvas gradient — ⛔ a smooth gradient is not this medium, and the pack's
     *      summer accents are where the tones come from;
     *   2. a light POOL spilling out onto the bed, 7 px deep, widening as it leaves the threshold;
     *   3. the hero from BEHIND at the threshold, one step in, drawn from the shipped north-facing
     *      frame at 2x so the hood catches the light — ⛔ the SHIPPED sprite, because an ending that
     *      pictures a character the game does not contain is the thing the sigil rule exists to stop;
     *   4. a few motes rising in the doorway, the same mark the warm spring uses, so the light reads
     *      as air rather than as paint.
     * ⚠️ The doorway's opening inside the 32x64 scaled sprite is measured from the art, not guessed:
     * `door_open`'s jambs are 3 px at 1x, so at 2x the opening runs 12 px in from each side and from
     * the springing of the arch (row 16 at 2x) down to the threshold. */
    /* ⚠️ MEASURED OFF `door_open.png` AND NOT GUESSED, and the first attempt is why that is stated:
     * placed from an estimate, the light drew a gold block BESIDE the door and the figure stood on
     * the mud next to it (opened, in 12_ending.png, before this line existed — wing §0z-1d). The
     * sprite is 16x32; its dark interior runs x 4..11 and y 5..27, with pale jambs at x 2..3 and
     * 12..13. At the card's 2x that is a 16x46 opening starting 8 px in and 10 px down. */
    var oX = dX + 8, oY = dY + 10, oW = 16, oH = 46;
    this.atlas.drawScaled(g, 'object/door_open', dX, dY, 2);
    /* ⛔⛔ THE LIGHT AND THE FIGURE GO **AFTER** THE DOOR, CLIPPED TO ITS OPENING — and the first
     * attempt put them before it, which is why this says so. The sprite's interior is OPAQUE BLACK,
     * so a gold ramp drawn underneath it was painted straight back out; the capture showed a door
     * with no light in it and a 48-px-wide figure standing on the mud beside it, because `hero/*` is
     * 24x32 and at the card's 2x that is three times the opening's width. Measured, both of them
     * (`_probe_r7_doorway.js` and the atlas index) — §0z-1e: open the PNG after every change.
     * The figure is drawn at the SAME 2x as the door, so the card holds one scale, and it is the
     * CLIP that fits it to the doorway: head and shoulders in the light, cut at the threshold, which
     * is what "one step in" looks like from behind. */
    g.save();
    g.beginPath(); g.rect(oX, oY, oW, oH); g.clip();
    var BANDS = ['#f2e2a8', '#e0b93f', '#ee9f52'];        /* the pack's own summer accents, pale deep inside -> hot at the sill */
    for (var bi = 0; bi < BANDS.length; bi++) {
      g.fillStyle = BANDS[bi];
      g.fillRect(oX, oY + Math.round(bi * oH / BANDS.length), oW, Math.ceil(oH / BANDS.length));
    }
    /* the motes, rising: a hot core with a paler pixel above it, the warm spring's own mark */
    for (var mi = 0; mi < 5; mi++) {
      var mx = oX + 2 + Math.floor(hash2(mi, 7, 91) * (oW - 4));
      var my = oY + 4 + Math.floor(hash2(mi, 9, 93) * (oH - 12));
      g.fillStyle = '#f2e2a8'; g.fillRect(mx, my, 1, 1);
      g.fillStyle = 'rgba(238,159,82,0.70)'; g.fillRect(mx, my - 1, 1, 1);
    }
    if (this.atlas.has('hero/north_0')) {
      /* ⛔ AT 1x, AND THAT IS PERSPECTIVE RATHER THAN A SCALE MISMATCH. At the door's own 2x the
       * 24x32 frame is 48x64 — three times the opening's width — so clipping it to the doorway shows
       * the middle third of a torso and reads as an orange mass (opened, and that is exactly what it
       * looked like). A figure a few steps BEYOND a threshold is smaller than the frame around it,
       * which is both what the picture needs and what makes the light readable: drawn at 1x and
       * centred, the light surrounds the figure instead of being hidden behind it.
       * ⚠️ Feet two pixels clear of the sill, so the figure stands INSIDE rather than on the lip. */
      this.blit('hero/north_0', oX + Math.round((oW - 24) / 2), oY + oH - 34);
      g.fillStyle = 'rgba(28,31,43,0.35)';
      g.fillRect(oX + 4, oY + oH - 3, oW - 8, 1);     /* its own contact shadow on the lit floor */
    } else this.missing['hero/north_0'] = (this.missing['hero/north_0'] || 0) + 1;
    g.restore();
    /* ⛔ THE POOL GOES LAST, AND OUTSIDE THE CLIP. Drawn before the door it was painted straight over
     * by the sprite's own threshold rows, which is the same mistake the light itself made one edit
     * earlier — the door is opaque and it is 64 px tall on a 64 px plate, so there is no bed BELOW it
     * to spill onto. Light out of this doorway therefore falls SIDEWAYS across the bed at the sill:
     * three steps, each wider and fainter, reaching past both jambs. */
    var POOL = ['rgba(238,159,82,0.50)', 'rgba(224,185,63,0.30)', 'rgba(242,226,168,0.16)'];
    for (var pi = 0; pi < POOL.length; pi++) {
      g.fillStyle = POOL[pi];
      g.fillRect(dX - 4 - pi * 7, dY + 56 + pi * 2, 40 + pi * 14, 2);
    }
    g.restore();
    /* ⛔ THE SAME FRAME AS THE SIGIL — a dark keyline and a gold inner rule (seasonSigil below) */
    g.fillStyle = PAL.ink;
    g.fillRect(x - 1, y - 1, W + 2, 1); g.fillRect(x - 1, y + H, W + 2, 1);
    g.fillRect(x - 1, y - 1, 1, H + 2); g.fillRect(x + W, y - 1, 1, H + 2);
    g.fillStyle = '#e0b93f';
    g.fillRect(x - 1, y - 2, W + 2, 1); g.fillRect(x - 1, y + H + 1, W + 2, 1);
  };

  Renderer.prototype.seasonSigil = function (x, y) {
    var at = [[0, 0], [16, 0], [16, 16], [0, 16]];
    /* ⛔⛔ THE GROUND ALONE DOES NOT SAY "FOUR SEASONS". The art director's round-2 minor defect 11:
     * "The demo-end card's 2x2 sigil reads as green / green / white / olive at 1x — only winter is
     * unmistakable, so the picture beside the buy line does not say 'four seasons'." That is exactly
     * what four bare meadow tiles ARE: spring and summer are both green, autumn is olive, and only
     * snow is unambiguous at sixteen pixels. The quadrants now carry each season's TREE over its
     * ground — blossom, oak, orange canopy, bare branches — which are four different silhouettes,
     * and a silhouette is what reads at this size (§0-ART-d). The tree is drawn at its own 2x2 size
     * and clipped to the quadrant, so it fills the cell rather than sitting in it.
     * ⚠️ Still built from the SHIPPED tiles, so it can never disagree with the boards it advertises. */
    /* ⛔⛔ FOUR LANDS, NOT FOUR SEASONS OF ONE — round-6 major 7, and the defect is what the picture
     * is ABOUT rather than how well it is drawn.
     *
     * "THE $9.99 CARD SELLS THE FELL AND THE DUNES WITH FOUR PICTURES OF THE MEADOW. On 10_demo_end
     * the 2x2 season sigil beside 'THE FULL YEAR ADDS THE FELL AND THE DUNES, AND THE ENDING THE DOOR
     * OPENS' is meadow spring / meadow summer / meadow snow / meadow leaf-litter — 9-12 colours each,
     * three with no object in them. The one place the demo player is asked to pay shows nothing of
     * what the money buys."
     *
     * ⚠️ Round 2 was right that four bare grounds cannot say "four seasons" and this is not a revert:
     * the SEASON is already carried by the dial on every screen, and the thing the buy line promises
     * — two more boards and an ending — was the one thing the picture never showed. So each quadrant
     * is a land, drawn from that board's own material with its own marker over it, and the two PAID
     * quadrants take the card's gold rule so the eye goes to them:
     *     Meadow  spring brook      · Mere   the island in open water
     *     Fell    slate over vale   · Dunes  palms over the oasis
     * ⛔ Still built from the SHIPPED tiles and sprites, so it can never advertise a board the game
     * does not contain — the rule this function has carried since round 2. */
    var g = this.g;
    var QUAD = [
      { ground: 'ground/water/spring/0', over: 'auto/grass_on_water/spring/31/0', paid: false },
      { ground: 'ground/water/summer/0', over: 'ground/stone/all/0', overSmall: true, ix: 5, iy: 5, paid: false },
      { ground: 'ground/cliff/winter/0', over: 'ground/grass/spring/0', overSmall: true, ix: 8, iy: 9, paid: true },
      { ground: 'ground/sand/summer/0', over: 'prop/palm/all/v0/10', paid: true },
    ];
    for (var i = 0; i < 4; i++) {
      var qx = x + at[i][0], qy = y + at[i][1], q = QUAD[i];
      this.blit(q.ground, qx, qy);
      g.save();
      g.beginPath(); g.rect(qx, qy, 16, 16); g.clip();
      if (q.overSmall) {
        /* ⚠️ A SMALL inset, and the size is the whole point: at ten pixels square the second material
         * covered most of a sixteen-pixel cell and the Mere read as a grey square rather than as an
         * island IN water (opened, at 3x, in 10_demo_end.png). Seven by six leaves the ground around
         * it, which is what says "island" and "vale under a crag" at this size. */
        g.save();
        g.beginPath(); g.rect(qx + q.ix, qy + q.iy, 7, 6); g.clip();
        this.blit(q.over, qx + q.ix, qy + q.iy);
        g.restore();
      } else this.blit(q.over, qx, qy);
      g.restore();
      if (q.paid) {
        g.fillStyle = '#e0b93f';
        g.fillRect(qx, qy, 16, 1); g.fillRect(qx, qy + 15, 16, 1);
        g.fillRect(qx, qy, 1, 16); g.fillRect(qx + 15, qy, 1, 16);
      }
    }
    g.fillStyle = '#1c1f2b';
    g.fillRect(x - 1, y - 1, 34, 1); g.fillRect(x - 1, y + 32, 34, 1);
    g.fillRect(x - 1, y - 1, 1, 34); g.fillRect(x + 32, y - 1, 1, 34);
    g.fillStyle = '#e0b93f';
    g.fillRect(x + 15, y, 1, 32); g.fillRect(x, y + 15, 32, 1);     /* the cross that divides the four lands */
  };

  /* published for the suite (wing §0z-1c: geometry published by the UI and READ by the test) */
  Renderer.prototype.plateBounds = function (x, y, w, h) {
    var maxW = plateRight() - x;
    return { x: x, y: y, w: Math.min(w, maxW), h: h };
  };
  Renderer.prototype.dialBounds = function () {
    return { x: LAYOUT.DIAL_X - LAYOUT.DIAL_R, y: LAYOUT.DIAL_Y - LAYOUT.DIAL_R, w: LAYOUT.DIAL_R * 2, h: LAYOUT.DIAL_R * 2 };
  };

  Renderer.prototype.frame = function (game) {
    var g = this.g;
    this.stats.frames++;
    /* ⛔⛔ PRESENTATION RUNS ON THE FIXED-STEP CLOCK, NOT ON FRAMES — the art director's minor
     * defect 16: "Presentation is framerate-dependent in five places (weather, loading arc, title
     * dial, prompt blink, ring shake) — on a 144 Hz display snow falls 2.4x too fast, contradicting
     * game.js's headline that the accumulator is the only place real time enters."
     *
     * That headline is true of the SIMULATION and was false of the picture, which is the worse half
     * to get wrong: a buyer on a 144 Hz laptop sees a different game from the one every gate
     * measured. `game.stats.steps` advances once per fixed DT, on every screen, through the one
     * function both the rAF loop and every harness call — so seconds derived from it are the same
     * seconds the model uses.
     * ⚠️ The frame counter survives as a FALLBACK for a caller with no game clock (the atlas-failure
     * and loading branches can be reached before a Game exists), and a fallback is not a default:
     * it is only ever wrong by the ratio this defect is about, and only where nothing else exists. */
    this.clock = (game && game.stats && typeof game.stats.steps === 'number')
      ? game.stats.steps / 60
      : this.stats.frames / 60;
    this.dt = Math.max(0, Math.min(0.25, this.clock - (this._lastClock == null ? this.clock : this._lastClock)));
    this._lastClock = this.clock;
    g.fillStyle = PAL.ink;
    g.fillRect(0, 0, LAYOUT.W, LAYOUT.H);

    /* ⛔⛔ ART FAILURES ARE SAID — AND FOR TWO SESSIONS THEY WERE NOT, BECAUSE THE MESSAGE WAS
     * WRITTEN IN THE FONT THAT HAD JUST FAILED TO LOAD.
     *
     * This branch used to call `this.wrap('ART FAILED TO LOAD: …')`. Every glyph in this game is
     * blitted out of `art/atlas.png`, so when THAT is the file that failed there is nothing to draw
     * letters with, and the player gets a flat ink screen — the exact black-screen outcome wing
     * §1-BUILD exists to prevent. MEASURED by aborting the atlas request and LOOKING at the
     * screenshot: `renderer.report().failed` was correctly populated and the canvas was empty. A
     * check that reads an internal field and concludes "the game says so" is master §2b's first row.
     *
     * The canvas half is now drawn in code, like the loading frame: a broken ring, struck through.
     * The words go to the PAGE (`TY_ON_FAULT`), which has a font of its own and does not need ours.
     */
    if (this.atlas.failed) {
      if (!this._faultSaid) {
        this._faultSaid = true;
        try { if (root.TY_ON_FAULT) root.TY_ON_FAULT(String(this.atlas.failed)); } catch (e) { /* the page's problem, not the game's */ }
      }
      var fcx = LAYOUT.W / 2, fcy = LAYOUT.H / 2, fr = 22;
      g.strokeStyle = PAL.dim; g.lineWidth = 2;
      g.beginPath(); g.arc(fcx, fcy, fr, Math.PI * 0.15, Math.PI * 1.85); g.stroke();   /* a ring with a gap */
      g.strokeStyle = PAL.spring.accent;
      g.beginPath(); g.moveTo(fcx - fr * 0.7, fcy - fr * 0.7); g.lineTo(fcx + fr * 0.7, fcy + fr * 0.7); g.stroke();
      g.lineWidth = 1;
      return;
    }
    if (!this.atlas.ready) {
      /* ⛔ THE FIRST THING EVERY PLAYER SEES, and it used to be a grey rectangle sliding on a flat
       * ground. It cannot use the game's type — the lettering is blitted from the atlas glyph sheet
       * and the atlas is precisely what has not arrived yet — so it is drawn as the one thing that
       * needs no assets and is the game's whole motif anyway: THE DIAL, turning. Four ticks for the
       * four seasons, a dim ring, and a bright arc going round it. Found by LOOKING at the forced
       * loading capture (02_loading.png). */
      /* ⛔⛔ AND IT IS DRAWN AT THE PIXEL SCALE — round-6 minor 14. "the loading ring (02_loading) is
       * an anti-aliased vector stroke — 163 colours in 3,573 px against the in-game ring's 39 — a
       * different medium in the first thing a player sees."
       *
       * `g.arc(...).stroke()` anti-aliases, and there is no flag that stops it: `imageSmoothingEnabled`
       * governs drawImage, not paths. So the ring is PLOTTED — one pixel per degree, snapped to
       * integers and filled as 1x1 rects — which is the same way the medium draws every other circle
       * in this game. ⚠️ Two radii are plotted rather than one, so the ring is 2 px thick without a
       * line width: a stroked width of 2 is where the grey halo came from. */
      var lcx = Math.round(LAYOUT.W / 2), lcy = Math.round(LAYOUT.H / 2), lr = 22;
      var turn = ((this.clock || 0) / 1.5) % (Math.PI * 2);        /* was frames/90 = 1.5 s at 60 Hz */
      var plotArc = function (r0, a0, a1, col) {
        g.fillStyle = col;
        var steps = Math.max(8, Math.round((a1 - a0) * r0 * 1.6));
        for (var si = 0; si <= steps; si++) {
          var a = a0 + (a1 - a0) * (si / steps);
          for (var rr = 0; rr < 2; rr++) {
            g.fillRect(Math.round(lcx + Math.cos(a) * (r0 - rr)), Math.round(lcy + Math.sin(a) * (r0 - rr)), 1, 1);
          }
        }
      };
      plotArc(lr, 0, Math.PI * 2, PAL.dim);
      /* the four season marks, so even the loading frame says what kind of game this is */
      g.fillStyle = PAL.dim;
      for (var q = 0; q < 4; q++) {
        var qa = -Math.PI / 2 + q * Math.PI / 2;
        g.fillRect(Math.round(lcx + Math.cos(qa) * lr) - 1, Math.round(lcy + Math.sin(qa) * lr) - 1, 3, 3);
      }
      /* the sweeping arc, tinted by whichever season it is currently passing */
      plotArc(lr, turn - Math.PI / 2, turn - Math.PI / 2 + Math.PI / 3, seasonColour((turn / (Math.PI / 2)) % 4, 'accent'));
      return;
    }

    var s = game.screen;
    var d = game.run ? game.run.world.dial.d : ((this.clock || 0) / 4.3333) % 4;   /* was frames/260 */

    /* ⛔ THE ERROR CARD IS A SCREEN TOO, AND IT WAS THE ONLY UNDESIGNED ONE.
     * It used to be one bare line of body text on a flat ground — no plate, no ring, no heading —
     * while every other screen in the game carries the dial motif and a season-ruled plate. It is
     * also the screen a player sees at the worst possible moment, so it is the last one that should
     * look unfinished. Found by LOOKING at 03_error.png. */
    if (s === 'error') {
      this.drawDial({ d: d, s: 0 }, 0);
      /* ⚠️ the plate stops at y = 116 because the dial ring's top edge is at DIAL_Y − DIAL_R = 122:
       * an 84-tall plate put its bottom rule straight through the ring. Derived, not guessed. */
      var erp = this.plate(d, 26, 40, 268, 76);
      var erby = this.plateHeading(erp, d, 'THE YEAR STOPPED', PAL.spring.accent);
      this.wrap(game.errorText, erp.x + 14, erby, erp.w - 28, { face: 'body', colour: PAL.paper });
      /* ⛔⛔ THE PAID BUILD IS NOT A PAGE, AND THIS LINE TOLD A BUYER TO RELOAD ONE.
       *
       * Found by an independent reviewer: "RELOAD THE PAGE TO BEGIN AGAIN" is an unconditional
       * string, and the paid product is an Electron desktop build. A paying customer who hits any
       * fault is handed an instruction that is meaningless where they are standing — on the one
       * screen where they are already unhappy. The free browser demo and the paid download run the
       * SAME bytes (28 files, sha-identical, asserted by build_desktop.js), which is exactly why a
       * sentence that is true of one of them is a defect in the other.
       *
       * ⚠️ Detected, not configured: Electron sets `process.versions.electron`, and `file:` is the
       * scheme the desktop build loads from. A build FLAG would be a second declaration of which
       * edition this is, and wing §1-DEMO's whole lesson is that editions must differ by a FILE, not
       * by a flag somebody remembers to set. */
      var desktop = (function () {
        try {
          if (typeof process !== 'undefined' && process.versions && process.versions.electron) return true;
          return typeof location !== 'undefined' && location.protocol === 'file:';
        } catch (e) { return false; }
      })();
      this.text(desktop ? 'close and reopen the game to begin again' : 'reload the page to begin again',
        erp.x + Math.round(erp.w / 2), erp.y + erp.h - 12,
        { face: 'body', colour: PAL.dim, align: 'center' });
      return;
    }

    if (s === 'title') {
      this.blit('object/title_plate', 0, 0);
      /* ⛔⛔ NO HUD DIAL HERE. The art director's round-2 major defect 2 ends: "On the title screen
       * hide the HUD dial (the painted ring IS the dial there)" — and at 3x the crop showed exactly
       * what it describes, a flat gauge in the bottom-right corner sitting on top of the cover
       * painting's own engraved ring. TWO DIALS ON ONE SCREEN, drawn at two scales in two
       * materials, on the first picture anybody sees. The painting has a ring with a pointer in it;
       * that is the dial on this screen, and drawing a second one over it was never a decision,
       * only the HUD branch running where it was not wanted. */
      /* ⛔ THE TITLE IS NOT DRAWN HERE ANY MORE. It is the LOCKUP, baked into `object/title_plate`
       * by build_title.js — outlined, bevelled, with the ring's season glyphs as ornaments — so the
       * game and the store show the same logotype. This blitter can only stamp flat glyphs, and a
       * second, lesser title drawn over the plate would be the drift build_title.js exists to
       * prevent (the art director: "Draw one logotype asset and use it everywhere"). */
      this.text('a world with one dial', 160, 68, { face: 'body', colour: seasonColour(d, 'accent'), align: 'center' });
      this.text('and it does not hold still', 160, 78, { face: 'body', colour: seasonColour(d, 'accent'), align: 'center' });
      /* ⛔ "PRESS ANY KEY" IS A LIE ON A PHONE, and this game is playable in a browser on one. The
       * prompt reads what the player has actually touched: a touch screen is told to tap, a pad is
       * told which button, and only a keyboard is told about keys. */
      /* ⛔ IT PULSES BETWEEN TWO TONES, IT NEVER GOES OUT. It used to draw only on even 30-frame
       * windows, so half of all frames had NO CALL TO ACTION — and the store's title screen was
       * captured on one of them (the art director's minor defect 13: "the store's title screen has
       * no call to action"). A prompt that is absent half the time is a prompt that a screenshot
       * will eventually miss, and the fix is not a luckier capture index: an always-drawn prompt
       * cannot be photographed away. */
      var seen = game.input && game.input.seen ? game.input.seen : {};
      var prompt = seen.touch ? 'tap to begin' : (seen.pad && !seen.key ? 'press a button' : 'press any key');
      /* ⚠️ `_sabotageBlink` exists for ONE caller: `_probe_framerate.js`'s control arm, which puts
       * this effect back on the frame counter and requires the 60 Hz / 20 Hz comparison to go RED.
       * Without a way to reintroduce the defect, a green comparison proves only that something was
       * compared. It is never set by the game, and the shipped build has no path that sets it. */
      var bright = this._sabotageBlink
        ? Math.floor(this.stats.frames / 30) % 2 === 0
        : Math.floor((this.clock || 0) * 2) % 2 === 0;    /* was frames/30 = 0.5 s at 60 Hz */
      this.text(prompt, 160, 120, { face: 'body', colour: bright ? PAL.paper : PAL.dim, align: 'center' });
      if (game.sound && game.sound.muted) this.text('sound off  (m)', 160, 168, { face: 'body', colour: PAL.dim, align: 'center' });
      return;
    }

    if (game.run) { this.board(game.run); this.hud(game.run, game); this.refusal(game.run); }

    /* ⛔ THE MESSAGE PLATE IS A BOARD THING AND MUST NOT SURVIVE INTO A MENU.
     * MEASURED by looking at 06_paused.png: the pause plate occupies y 48..136 and the message
     * plate y 132..172, so the two overlapped by four rows and the pause card sat on a sentence
     * left over from before the player paused. The geometry is published below so the check is
     * about the RECTANGLES and not about the words in them (wing §0z-1: ask what the check
     * COMPARES, not what its message says). */
    if (game.message && s === 'playing') {
      var mp = this.plate(d, LAYOUT.MSG.x, LAYOUT.MSG.y, LAYOUT.MSG.w, LAYOUT.MSG.h);
      /* ⚠️ no plateHeading here: a sign has no title, and a heading rule would eat two of the four
       * lines a message gets. The frame and the corner bosses still carry the motif. */
      this.wrap(controlWords(game.message, game), mp.x + 10, mp.y + 7, mp.w - 20, { face: 'body', colour: PAL.paper });
    }

    if (s === 'paused') {
      var touch = touchOnly(game);
      var pp = this.plate(d, LAYOUT.PAUSE.x, LAYOUT.PAUSE.y, LAYOUT.PAUSE.w, LAYOUT.PAUSE.h);
      var pcx = pp.x + Math.round(pp.w / 2);
      this.plateHeading(pp, d, 'PAUSED', PAL.summer.accent);
      /* the mute control is DISCOVERABLE here, with its live state — a key nobody is told about is
       * a key nobody presses (wing §6b-12: a mechanic the screen never mentions is not a mechanic),
       * and on a touch screen the KEY NAMES would be a lie, so the taps are named instead */
      /* ⛔⛔ ONE GREY MEANT TWO THINGS — round-6 minor 14, second clause: "in the pause menu one grey
       * ink means both 'this setting is off' and 'this action is live'." `PAL.dim` was carrying both
       * "sound is muted" and "this is a hint, not a command", so a player reading the card could not
       * tell a disabled setting from an available one. Every line here IS live — they are all keys
       * the player can press — so the dim ink is wrong on all of them, and an OFF state needs a
       * treatment of its own rather than a shade of the same one.
       * ⚠️ The value is BRACKETED, which is a form and not a colour: `sound: [off]` reads as off at
       * 1x, in one ink, and survives a player who cannot separate two greys. */
      /* ⛔⛔ THE COPY LIVES AT THE CALL SITE, because that is what the coverage gate can read. Round 7
       * built this line through a helper (`offMark('sound:', muted)`), so the literal `' [off]'` was
       * in a FUNCTION and `bodyStrings()` — which reads `this.text(...)` calls — never saw it. The
       * brackets were not in the body face, `render.js`'s blitter skips an undrawn glyph in silence,
       * and an independent reviewer photographed `M SOUND:    OFF` with two holes in it. ⇒ never put
       * drawn copy behind an indirection the gate cannot follow.
       * ⛔ AND THE VALUE CARRIES BOTH SIGNALS. A form alone was the round-6 prescription; the reviewer
       * then found the opposite fault — with every line in paper ink there was no dim register left
       * in the card at all. The COMMAND stays paper because it is live; the VALUE is dim when it is
       * off and paper when it is on, and it is bracketed either way, so the state reads in colour AND
       * in shape. Drawn as two calls so one string cannot carry two inks. */
      var muted = !!(game.sound && game.sound.muted);
      if (touch) {
        this.text('tap left to resume', pcx, 84, { face: 'body', colour: PAL.paper, align: 'center' });
        this.text('tap right: sound', pcx - 4, 98, { face: 'body', colour: PAL.paper, align: 'right' });
        this.text(muted ? '[off]' : '[on]', pcx + 4, 98, { face: 'body', colour: muted ? PAL.dim : PAL.paper, align: 'left' });
        this.text('tap the top strip to pause', pcx, 112, { face: 'body', colour: PAL.dim, align: 'center' });
      } else {
        this.text('esc resume', pcx, 82, { face: 'body', colour: PAL.paper, align: 'center' });
        this.text('r retry board', pcx, 92, { face: 'body', colour: PAL.paper, align: 'center' });
        this.text('m sound', pcx - 4, 102, { face: 'body', colour: PAL.paper, align: 'right' });
        this.text(muted ? '[off]' : '[on]', pcx + 4, 102, { face: 'body', colour: muted ? PAL.dim : PAL.paper, align: 'left' });
        this.text('q quit to title', pcx, 112, { face: 'body', colour: PAL.paper, align: 'center' });
      }
    }

    if (s === 'lost') {
      /* ⛔ TELL THEM WHAT ACTUALLY KILLED THEM. `run.js` computes three distinct reasons — the ice
       * melted from under you, the thin ice gave way under you, or the surface's own `why` — stores
       * them in `outcome.why`, and this card used to draw ONE fixed sentence and throw the reason
       * away. Drown in open water that was never ice and you were told the ice gave way. In a game
       * whose whole subject is working out what the year is doing, a death that misreports its own
       * cause is not a small thing: it teaches the wrong rule. The reason leads; the authored line
       * closes it. */
      /* ⚠️ The plate is sized to the copy rather than left at a round number: the first version was
       * 76 tall for two short lines and a prompt, which photographed as a large empty band between
       * them (LOOKED AT in Playtest/screens/09_lost.png). */
      var why = (game.run.outcome && game.run.outcome.why) || '';
      var lead = why ? why.charAt(0).toUpperCase() + why.slice(1) + '.' : '';
      /* ⛔ SIZED FROM THE COPY, like the demo-end card. Removing the repeated heading from the body
       * (minor defect 8) left a plate cut for two lines drawing one, and the result photographed as
       * the same empty band the art director rejected on the ending card — "~60% of the plate is
       * blank". A fix at one end breaking the other (§0z-1); the fix is to stop typing a round
       * number, not to put the repetition back. */
      var lbody = this.wrapLines(lead || (game.run.world.texts.lose || 'The year took you.'),
        this.plateBounds(26, 48, 268, 0).w - 28, { face: 'body' });
      var lp = this.plate(d, 26, 48, 268, 27 + lbody * LEAD.body + 18);
      var lby = this.plateHeading(lp, d, 'THE YEAR TOOK YOU', PAL.spring.accent);
      /* ⛔ THE HEADING IS SAID ONCE. The art director's round-2 minor defect 8: "The loss card
       * repeats its heading in its body: THE YEAR TOOK YOU as the title, then 'THE THIN ICE GAVE
       * WAY UNDER YOU. THE YEAR TOOK YOU.'" The authored `lose` line and the card's heading are the
       * same sentence, and printing both under each other reads as a stutter. The cause is the body
       * — it is the only part that differs between deaths and the only part worth reading — and the
       * authored line survives ONLY as the fallback for a death with no recorded cause, which is
       * what it was written for. ⚠️ Not deleted from content.js: a card with an empty body is worse
       * than a repeated one, and `why` is computed in three places that could each miss. */
      if (lead) this.wrap(lead, lp.x + 14, lby, lp.w - 28, { face: 'body', colour: PAL.paper });
      else this.wrap(game.run.world.texts.lose || 'The year took you.', lp.x + 14, lby, lp.w - 28, { face: 'body', colour: PAL.paper });
      this.text(touchOnly(game) ? 'tap to try this board again' : 'enter to try this board again',
        lp.x + Math.round(lp.w / 2), lp.y + lp.h - 12, { face: 'body', colour: PAL.paper, align: 'center' });
    }

    if (s === 'demoEnd' || s === 'ending') {
      /* ⛔⛔ CEREMONY, BECAUSE BOTH OF THESE WERE BARE PANELS — the art director's major defect 11:
       * "THE YEAR TURNS and a two-line sentence occupy the top third of a navy plate over the
       * spring Meadow; ~60% of the plate is blank; no image, no ceremony. 10_demo_end.png has the
       * same shape. A $9.99 game's ending — and the one screen whose job is to convert — are both
       * bare panels."
       *
       * The ending now opens on the title plate's OWN painting (the shrine island and the ring, the
       * best asset this product has), darkened, with the dial at rest in the season the player
       * ended in — so the last screen is a picture and not a paragraph. The demo-end card carries a
       * four-season sigil built from the game's own ground tiles beside the buy line, which makes
       * the pitch the thing the game is actually about rather than a sentence about it. */
      if (s === 'ending') {
        /* ⛔ `shrine_plate`, NOT `title_plate` — the same painting WITHOUT the lockup. The ending
         * draws a card over its backdrop, and with the lockup baked in the card's gold rule sliced
         * the wordmark in half ("YFAR"). Caught by an independent reviewer, confirmed at 3x. */
        this.blit('object/shrine_plate', 0, 0);
        g.fillStyle = 'rgba(28,31,43,0.55)';                 /* hold the type off the painting */
        g.fillRect(0, 0, LAYOUT.W, LAYOUT.H);
        this.drawDial({ d: d, s: 0 }, Math.round(d) % 4);
      }
      var texts = game.run.world.texts;
      var txt;
      if (s === 'ending') txt = texts.ending || '';
      else {
        /* ⛔ THE DEMO END CARD USED ONE TEXT FOR TWO DIFFERENT ENDINGS AND CONTRADICTED ONE OF THEM.
         * `run.js` fires demoEnd for two reasons: the inscription at the edge of the free year, and
         * — in the free edition — STEPPING ON THE DRY DOOR. The single text said "the year goes on
         * past the Mere: the Fell, the Dunes, and the door below the lowest water", so a player who
         * had just solved the door was told to go and find the door. */
        txt = (game.run.outcome && game.run.outcome.why === 'door' && texts['demo.end.door'])
          ? texts['demo.end.door'] : (texts['demo.end'] || '');
      }
      /* ⛔ SIZED FROM THE COPY, and the copy differs between the two cards: the ending is one
       * sentence, the demo end is a sentence plus a buy line beside a 32-px sigil. A single round
       * number left the shorter one 60% empty (defect 11) and would clip the longer one if it grew.
       * heading (6 + 12 + 3 + 6) + body lines + the buy block + the prompt, all measured. */
      var innerW = this.plateBounds(18, 34, 284, 0).w - 28;
      var bodyLines = this.wrapLines(txt, innerW, { face: 'body' });
      var buyH = (s === 'demoEnd' && texts['demo.buy']) ? 38 : 0;      /* the sigil is 32 + margin */
      /* ⛔ the ending's picture is 48 tall plus its frame and margins — sized here, with the copy,
       * so the card grows around it instead of the plate being dropped onto a card built for text */
      var doorH = (s === 'ending') ? 72 : 0;
      var ctaH = (s === 'demoEnd' && texts['demo.cta']) ? LEAD.body + 4 : 0;
      var epH = 27 + bodyLines * LEAD.body + buyH + ctaH + doorH + 18;
      var ep = this.plate(d, 18, Math.max(24, Math.round((LAYOUT.H - epH) / 2)), 284, epH);
      var ey = this.plateHeading(ep, d, s === 'ending' ? 'THE YEAR TURNS' : 'END OF THE FREE YEAR', PAL.summer.accent);
      ey = this.wrap(txt, ep.x + 14, ey + 2, ep.w - 28, { face: 'body', colour: PAL.paper });
      /* ⛔ THE ONE SCREEN WHOSE JOB IS TO CONVERT SAID NOTHING ABOUT THE FULL GAME. A free player
       * reached the end of the demo and was offered only "enter for credits". This names what the
       * paid edition actually contains — three more boards and the drowned door's ending — and
       * nothing it cannot support. ⚠️ No URL is printed: the web build is embedded ON the store
       * page, so the buy button is already above this canvas, and a URL printed here could not be
       * verified from inside the game. */
      if (s === 'demoEnd' && texts['demo.buy']) {
        /* the sigil sits LEFT of the buy line: four of the game's own ground tiles, one per season,
         * which is the product's whole argument in 34 pixels */
        this.seasonSigil(ep.x + 14, ey + 4);
        this.wrap(texts['demo.buy'], ep.x + 54, ey + 6, ep.w - 68, { face: 'body', colour: PAL.summer.accent });
        /* ⛔ AND THE OFFER ITSELF. Round-4 major 4: "The free demo's end card gives the player no way
         * to get the full game ... The player who just finished the demo is the single highest-intent
         * buyer the product ever has." The line names the price and where the build is, and nothing
         * else — on itch the paid download shares this listing, so there is no URL to print and none
         * that could be verified from inside the game. */
        if (texts['demo.cta']) {
          this.text(texts['demo.cta'], ep.x + Math.round(ep.w / 2), ey + 6 + 34,
            { face: 'body', colour: PAL.paper, align: 'center' });
        }
      }
      if (s === 'ending') {
        /* the door, open, on the bed the water left — what the player just earned, pictured */
        this.doorPlate(ep.x + Math.round((ep.w - 96) / 2), ey + 6);
      }
      this.text(touchOnly(game) ? 'tap for credits' : 'enter for credits',
        ep.x + Math.round(ep.w / 2), ep.y + ep.h - 12, { face: 'body', colour: PAL.dim, align: 'center' });
    }

    if (s === 'credits') {
      /* ⛔⛔ THE LAST SCREEN A FINISHING PLAYER SEES WAS THE ONLY UNDESIGNED ONE LEFT.
       * The art director's round-2 major defect 6: "11_credits.png is a flat navy fill with the
       * title in the plain display face (not the lockup), CORE SYSTEMS ASSET FACTORY, four lines of
       * credits and disclosure, ENTER TO RETURN and the HUD dial — no backdrop, no frame, no motif.
       * It is the last screen every player who finishes sees, and the one 'edge' (Craft Doctrine
       * §0.5) the polish stage did not finish."
       *
       * It now has the same ceremony the ending got, and for the same reason: the shrine painting
       * darkened as a backdrop, THE LOCKUP rather than a second flat title (build_title.js exists
       * so the game and the store never show two different wordmarks), and the text inside a
       * bronze-framed plate that clears the ring — which the `plate()` geometry guarantees rather
       * than my arithmetic promising it.
       * ⚠️ `shrine_plate`, not `title_plate`: this screen draws a card over its backdrop, and that
       * is precisely the case that sliced the wordmark into "YFAR" on the ending. */
      this.blit('object/shrine_plate', 0, 0);
      g.fillStyle = 'rgba(28,31,43,0.72)';
      g.fillRect(0, 0, LAYOUT.W, LAYOUT.H);
      /* the dial at rest in the season the player ended in, as on the ending card */
      this.drawDial({ d: d, s: 0 }, Math.round(d) % 4);
      /* the lockup, centred above the card — the same asset the title and the cover carry */
      var cle = this.atlas.index && this.atlas.index['object/lockup'];
      if (cle) this.blit('object/lockup', Math.round((LAYOUT.W - cle.w) / 2), 10);
      else this.text('THE TURNING YEAR', 160, 16, { face: 'display', colour: PAL.summer.accent, align: 'center' });
      var cp = this.plate(d, 22, (cle ? 10 + cle.h + 6 : 34), 250, 92);
      var cy0 = cp.y + 10;
      this.text('Core Systems Asset Factory', cp.x + Math.round(cp.w / 2), cy0, { face: 'body', colour: PAL.paper, align: 'center' });
      /* ⛔ FOUR, AND THE NUMBER IS CHECKED. Round-4 minor 10: "the credits name one art pack where
       * the Readme names two and the code uses four." The atlas is built from VerdantSeasons,
       * Verdant01_Overworld, Verdant24_Desert and VerdantProps — all four this factory's own tile
       * products — and `verify_artefact.js` re-derives that count from `Art/art_sources.js` and
       * requires this line and the Readme to agree with it, so the three surfaces cannot drift
       * apart again (§2b: a measurement copied into a checker certifies its own staleness). */
      this.text('art: four verdant tile packs, ours', cp.x + Math.round(cp.w / 2), cy0 + 14, { face: 'body', colour: PAL.dim, align: 'center' });
      this.text('music: one theme, four arrangements', cp.x + Math.round(cp.w / 2), cy0 + 24, { face: 'body', colour: PAL.dim, align: 'center' });
      /* ⚠️ THE AI DISCLOSURE IS PART OF THE PRODUCT (master §4.1) and is stated here as well as on
       * the listing. ⛔ SOUND IS "NO" AND THAT IS A MEASURED CLAIM, NOT A CONVENIENCE: every note
       * was written as data in Internal_Ops/Audio/compose.js and rendered by oscillator, with no
       * sample, no soundfont and no AI music service anywhere in the chain — which is exactly the
       * case itch calls self-contained procedural synthesis rather than generative AI. */
      this.text('made with ai tools:', cp.x + Math.round(cp.w / 2), cy0 + 40, { face: 'body', colour: PAL.dim, align: 'center' });
      this.text('code yes  graphics yes  text yes', cp.x + Math.round(cp.w / 2), cy0 + 50, { face: 'body', colour: PAL.dim, align: 'center' });
      this.text('sound no: written and synthesised here', cp.x + Math.round(cp.w / 2), cy0 + 60, { face: 'body', colour: PAL.dim, align: 'center' });
      this.text(touchOnly(game) ? 'tap to return' : 'enter to return',
        cp.x + Math.round(cp.w / 2), cp.y + cp.h + 12, { face: 'body', colour: PAL.paper, align: 'center' });
    }
  };

  /** What the renderer could not draw. ⛔ A hole is COUNTED and reportable, never guessed at. */
  Renderer.prototype.report = function () {
    return { ready: this.atlas.ready, failed: this.atlas.failed, stats: this.stats, missing: this.missing };
  };

  var API = { LAYOUT: LAYOUT, PAL: PAL, MOTE: MOTE, Renderer: Renderer, Atlas: Atlas, normaliseMask: normaliseMask, ART_BASE: ART_BASE };
  root.TY_RENDER = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof globalThis !== 'undefined' ? globalThis : this);
