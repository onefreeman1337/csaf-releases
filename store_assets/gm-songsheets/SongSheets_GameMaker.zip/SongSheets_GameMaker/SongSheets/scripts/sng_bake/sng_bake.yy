{
  "$GMScript": "v1",
  "%Name": "sng_bake",
  "name": "sng_bake",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}