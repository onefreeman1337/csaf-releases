/// sng_bake.gml - renders the store sheets THROUGH THE PRODUCT'S OWN DRAW CODE (`SongSheets.exe -bake`), so the
/// listing can truthfully say every image on the page was engraved by the thing being sold.
///
/// Song Sheets - Every Song Engraved and Played, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ NOTHING IN THIS FILE CAN SEE A PICTURE. The ink box below catches a sheet that is CLIPPED or EMPTY and
/// nothing else. The sheets are opened and looked at, every time, and that is the actual gate.

#macro SNG_BAKE_GROUND_R 22
#macro SNG_BAKE_GROUND_G 17
#macro SNG_BAKE_GROUND_B 14

/// @function sng_bake_ground()
function sng_bake_ground() { return make_colour_rgb(SNG_BAKE_GROUND_R, SNG_BAKE_GROUND_G, SNG_BAKE_GROUND_B); }

/// @function sng_bake_opaque(w, h)
/// @description Force every pixel's alpha to 1 before saving, so a sheet has no transparent holes.
function sng_bake_opaque(_w, _h) {
    gpu_set_colorwriteenable(false, false, false, true);
    sng_rect_fill(0, 0, _w, _h, c_white, 1);
    gpu_set_colorwriteenable(true, true, true, true);
}

/// @function sng_bake_ink(surface, w, h, ground)
/// @description The ink bounding box and sample count of a finished sheet. Every row, every second column: a
/// clipped hairline lands on ONE row, and an even-only row scan walks straight past it.
function sng_bake_ink(_sf, _w, _h, _ground) {
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    var _x0 = _w, _y0 = _h, _x1 = -1, _y1 = -1, _n = 0;
    var _gr = colour_get_red(_ground), _gg = colour_get_green(_ground), _gb = colour_get_blue(_ground);
    for (var _y = 0; _y < _h; _y++) for (var _x = 0; _x < _w; _x += 2) {
        var _o = (_y * _w + _x) * 4;
        if (abs(buffer_peek(_b, _o, buffer_u8) - _gr) > 10 || abs(buffer_peek(_b, _o + 1, buffer_u8) - _gg) > 10 || abs(buffer_peek(_b, _o + 2, buffer_u8) - _gb) > 10) {
            _n++;
            if (_x < _x0) _x0 = _x;
            if (_x > _x1) _x1 = _x;
            if (_y < _y0) _y0 = _y;
            if (_y > _y1) _y1 = _y;
        }
    }
    buffer_delete(_b);
    return { x0: _x0, y0: _y0, x1: _x1, y1: _y1, px: _n };
}

/// @function sng_bake_sheet(name, w, h, fn)
/// @description Render one sheet onto a surface at 2x, filter it down to its size, measure it, save it.
/// ⭐ The 2x render IS the product's own path (sng_plate supersamples the same way), so a sheet shows the
/// plates exactly as smooth as a buyer's game will.
function sng_bake_sheet(_name, _w, _h, _fn) {
    var _big = surface_create(_w * 2, _h * 2);
    surface_set_target(_big);
    draw_clear(sng_bake_ground());
    var _fin = _fn(_w * 2, _h * 2);
    sng_bake_opaque(_w * 2, _h * 2);
    surface_reset_target();
    var _sf = surface_create(_w, _h);
    surface_set_target(_sf);
    draw_clear(sng_bake_ground());
    var _prev = gpu_get_texfilter();
    gpu_set_texfilter(true);
    draw_surface_ext(_big, 0, 0, 0.5, 0.5, 0, c_white, 1);
    gpu_set_texfilter(_prev);
    sng_bake_opaque(_w, _h);
    surface_reset_target();
    surface_free(_big);
    var _ink = sng_bake_ink(_sf, _w, _h, sng_bake_ground());
    surface_save(_sf, "sng_sheet_" + _name + ".png");
    surface_free(_sf);
    array_push(global.sng_bake_log, { sheet: _name, w: _w, h: _h, drew_to: is_real(_fin) ? _fin / 2 : -1,
                                      ink_px: _ink.px, x0: _ink.x0, y0: _ink.y0, x1: _ink.x1, y1: _ink.y1 });
}

/// @function sng_bake_head(w, title, sub, k)
/// @description A sheet's head: a title in the display face and one sentence under it. `k` is the 2x factor.
function sng_bake_head(_w, _title, _sub, _k) {
    sng_text(_w * 0.5, 22 * _k, _title, 46 * _k, make_colour_rgb(238, 224, 194), fa_center, fa_top, fnt_songsheets_title, 1, _w * 0.9);
    sng_text(_w * 0.5, 74 * _k, _sub, 21 * _k, make_colour_rgb(190, 172, 142), fa_center, fa_top, fnt_songsheets, 1, _w * 0.9);
}

/// @function sng_bake_caption(cx, y, w, text, k)
/// @description A caption under a plate, on the dark sheet ground.
function sng_bake_caption(_cx, _y, _w, _s, _k) {
    sng_text_tracked(_cx, _y, string_upper(_s), 13 * _k, 0.16, make_colour_rgb(206, 186, 150), fnt_songsheets, 1, _w);
}

/// @function sng_bake_shadowed(song, x, y, w, h, k, [marks])
/// @description A plate with a soft drop shadow under it, engraved directly at sheet resolution.
function sng_bake_shadowed(_song, _x, _y, _w, _h, _k, _marks = undefined) {
    sng_rect_fill(_x + 6 * _k, _y + 8 * _k, _w, _h, c_black, 0.45);
    sng_rect_fill(_x + 3 * _k, _y + 4 * _k, _w, _h, c_black, 0.35);
    return sng_engrave(_song, _x, _y, _w, _h, _marks);
}

/// @function sng_bake_hero(w, h)
/// @description THE HERO: a reel engraved large, a plainchant beside it, as a buyer would show two sheets.
function sng_bake_hero(_w, _h) {
    var _k = 2;
    sng_bake_head(_w, "SONG SHEETS", "Every song your player learns is engraved as a plate - and the plate plays what it shows.", _k);
    var _top = 132 * _k, _gap = 30 * _k, _pad = 40 * _k;
    var _aw = (_w - _pad * 2 - _gap) * 0.58, _bw = (_w - _pad * 2 - _gap) - _aw;
    var _ph = _h - _top - 60 * _k;
    sng_bake_shadowed(sng_song("millers-daughter", "folk", 62, "The Miller's Daughter"), _pad, _top, _aw, _ph, _k);
    sng_bake_shadowed(sng_song("hours-of-ash", "chant"), _pad + _aw + _gap, _top, _bw, _ph, _k);
    sng_bake_caption(_pad + _aw / 2, _top + _ph + 18 * _k, _aw, "A reel - beamed, barred, 6/8", _k);
    sng_bake_caption(_pad + _aw + _gap + _bw / 2, _top + _ph + 18 * _k, _bw, "Plainchant - square neumes, sung text", _k);
    return _top + _ph + 40 * _k;
}

/// @function sng_bake_traditions(w, h)
/// @description All ten traditions, one plate each - ten notation systems, papers, inks and frames.
function sng_bake_traditions(_w, _h) {
    var _k = 2, _T = sng_traditions();
    sng_bake_head(_w, "TEN TRADITIONS, TEN KINDS OF PAGE", "Each has its own melodic construction, notation, paper, ink, frame, instrument and tempo.", _k);
    var _cols = 5, _rows = 2, _pad = 24 * _k, _gx = 18 * _k, _gy = 44 * _k, _top = 128 * _k;
    var _cw = (_w - _pad * 2 - _gx * (_cols - 1)) / _cols;
    var _ch = (_h - _top - _pad - _gy * _rows) / _rows;
    var _fin = _top;
    for (var _i = 0; _i < 10; _i++) {
        var _c = _i mod _cols, _r = _i div _cols;
        var _x = _pad + _c * (_cw + _gx), _y = _top + _r * (_ch + _gy);
        var _s = sng_song("tradition-" + _T[_i], _T[_i]);
        sng_bake_shadowed(_s, _x, _y, _cw, _ch, _k);
        sng_bake_caption(_x + _cw / 2, _y + _ch + 12 * _k, _cw, _s.tradition_name + " - " + _s.notation, _k);
        _fin = max(_fin, _y + _ch + 30 * _k);
    }
    return _fin;
}

/// @function sng_bake_wall(w, h)
/// @description FORTY different sheets, four of each tradition - the volume the suite measures as forty
/// distinct pictures, shown.
function sng_bake_wall(_w, _h) {
    var _k = 2, _T = sng_traditions();
    sng_bake_head(_w, "FORTY SONGS, FORTY PLATES", "No two sheets are the same picture, because no two songs are the same melody.", _k);
    var _cols = 8, _rows = 5, _pad = 20 * _k, _g = 12 * _k, _top = 126 * _k;
    var _cw = (_w - _pad * 2 - _g * (_cols - 1)) / _cols;
    var _ch = (_h - _top - _pad - _g * (_rows - 1)) / _rows;
    for (var _i = 0; _i < 40; _i++) {
        var _c = _i mod _cols, _r = _i div _cols;
        sng_bake_shadowed(sng_song("wall-" + string(_i), _T[(_i * 3) mod 10]), _pad + _c * (_cw + _g), _top + _r * (_ch + _g), _cw, _ch, _k);
    }
    return _top + _rows * (_ch + _g);
}

/// @function sng_bake_songbook(w, h)
/// @description The songbook screen, with a sheet PLAYING and its playhead on a notehead.
function sng_bake_songbook(_w, _h) {
    var _ui = sng_songbook_create(sng_demo_book());
    _ui.sel = 0;
    _ui.song = sng_book_song(_ui.book, 0);
    _ui.sched = sng_schedule(_ui.song);
    _ui.clock = _ui.sched[6].at + 0.02;
    sng_songbook_draw(_ui, 0, 0, _w, _h);
    sng_songbook_free(_ui);
    return _h;
}

/// @function sng_bake_plays(w, h)
/// @description THE SHEET PLAYS WHAT IT SHOWS: a plate, the waveform the product synthesised for it drawn
/// underneath, and a thread from every notehead down to the moment it sounds.
function sng_bake_plays(_w, _h) {
    var _k = 2;
    sng_bake_head(_w, "THE SHEET PLAYS WHAT IT SHOWS", "The melody is synthesised into a GameMaker audio buffer. This is that buffer, under the plate it came from.", _k);
    // ⚠️ a PLUCKED air, on purpose: a sustained voice or reed draws as flat rectangles at this zoom, which is an
    // honest envelope and reads as a bar chart; a plucked string's attack-and-decay is the shape people know as sound
    var _s = sng_song("pavane-merrow", "courtly");
    var _pad = 60 * _k, _top = 128 * _k, _pw = _w - _pad * 2, _ph = (_h - _top) * 0.46;
    var _marks = [];
    sng_bake_shadowed(_s, _pad, _top, _pw, _ph, _k, _marks);
    var _r = sng_render(_s);
    var _wy = _top + _ph + 110 * _k, _wh = _h - _wy - 70 * _k, _mid = _wy + _wh / 2;
    sng_rect_fill(_pad, _wy, _pw, _wh, make_colour_rgb(30, 23, 18));
    sng_seg(_pad, _mid, _pad + _pw, _mid, 1 * _k, make_colour_rgb(90, 70, 50));
    var _cols = floor(_pw / 2), _spc = _r.samples / _cols;
    for (var _c = 0; _c < _cols; _c++) {
        var _hi = 0, _lo = 0;
        for (var _q = floor(_c * _spc); _q < floor((_c + 1) * _spc); _q += 2) {
            var _v = buffer_peek(_r.buffer, _q * 2, buffer_s16) / 32767;
            _hi = max(_hi, _v); _lo = min(_lo, _v);
        }
        var _sc = _wh * 0.46 / max(0.001, _r.peak);
        sng_seg(_pad + _c * 2, _mid - _hi * _sc, _pad + _c * 2, _mid - _lo * _sc, 2, make_colour_rgb(214, 170, 96));
    }
    // a thread from every notehead to the moment it sounds: an S-curve, vertical at both ends, so forty threads
    // read as a loom rather than a tangle
    var _sch = sng_schedule(_s), _dur = _r.seconds;
    for (var _i = 0; _i < array_length(_marks); _i++) {
        var _m = _marks[_i];
        var _ox = _pad + (_sch[_m.i].at / _dur) * _pw;
        var _y0 = _top + _ph + 8 * _k, _y1 = _wy - 6 * _k, _ym = (_y0 + _y1) / 2;
        sng_polyline(sng_bezier(_m.x, _y0, _m.x, _ym, _ox, _ym, _ox, _y1, 16), 1.3 * _k, make_colour_rgb(176, 128, 76), 0.7);
        sng_disc(_m.x, _y0, 2.5 * _k, make_colour_rgb(176, 128, 76));
        sng_disc(_ox, _y1, 3 * _k, make_colour_rgb(214, 170, 96));
    }
    buffer_delete(_r.buffer);
    sng_bake_caption(_w / 2, _h - 44 * _k, _w * 0.86, "a courtly air - " + string(array_length(_s.notes)) + " notes, " + string_format(_r.seconds, 1, 1) + " seconds, plucked timbre, synthesised in GML, no audio file", _k);
    return _h - 20 * _k;
}

/// @function sng_bake_detail(w, h)
/// @description THE ENGRAVING, CLOSE: a plate drawn at four times its game size and cropped, so the broad-nib
/// clef, sloped beams, ledger lines and the flat can be read - a real redraw, never a scaled bitmap.
function sng_bake_detail(_w, _h) {
    var _k = 2;
    sng_bake_head(_w, "ENGRAVED, NOT PRINTED", "The clef is cut with a broad nib; beams slope with the melody and are clamped the way an engraver clamps them.", _k);
    var _top = 128 * _k, _pad = 40 * _k;
    var _vw = _w - _pad * 2, _vh = _h - _top - 40 * _k;
    // ⛔ FRAMED FROM THE LAYOUT, NOT BY EYE: the first version guessed an offset and cropped the plate to a
    // title and empty paper with the first note below the frame. The plate here is sized so its first system
    // is large, and placed so that system's own centre line - computed by the same solver the engraver uses -
    // sits in the middle of the crop.
    var _song = sng_song("millers-daughter", "folk", 62, "The Miller's Daughter");
    var _PW = _vw * 1.02, _PH = _vh * 1.55;
    var _u = sng_unit(_PW, _PH);
    var _L = sng_layout(_song.notation, _PW - 48 * _u, _PH - 78 * _u, array_length(_song.notes), _u);
    var _sysmid = 60 * _u + _L.band_h * 0.5;
    gpu_set_scissor(_pad, _top, _vw, _vh);
    sng_engrave(_song, _pad - _vw * 0.01, _top + _vh * 0.56 - _sysmid, _PW, _PH);
    gpu_set_scissor(0, 0, _w, _h);
    sng_rect_line(_pad, _top, _vw, _vh, 2 * _k, make_colour_rgb(120, 96, 70));
    return _top + _vh;
}

/// @function sng_bake_cover(w, h)
/// @description A 630x500 cover plate, in case the generated cover is ever unavailable.
function sng_bake_cover(_w, _h) {
    var _k = 2;
    sng_engrave(sng_song("millers-daughter", "folk", 62, "Song Sheets"), 0, 0, _w, _h);
    return _h;
}

/// @function sng_bake_pad4(n)
/// @description A frame index as four digits, by ARITHMETIC - `string_replace` replaces one occurrence, so the
/// obvious padding trick turns "  7" into "0 7". Pure.
function sng_bake_pad4(_n) {
    _n = clamp(floor(is_real(_n) ? _n : 0), 0, 9999);
    var _s = string(_n);
    while (string_length(_s) < 4) _s = "0" + _s;
    return _s;
}

/// @function sng_bake_gif()
/// @description The GIF frames: three plates in three notation systems, each FULL FRAME, the playhead stepping
/// note by note (driven from the schedule, so every frame lands on a real onset) - through sng_plate and
/// sng_playhead_draw, the path a buyer's game uses.
/// ⚠️ Full-frame PLATES, not the songbook screen: the songbook is its own still in the gallery, and a GIF of the
/// same scene hashed d=8 against it - the same picture twice in a buyer's thumbnail strip.
function sng_bake_gif() {
    var _w = 640, _h = 400, _n = 0;
    var _sf = surface_create(_w, _h);
    var _songs = [sng_song("millers-daughter", "folk", 62, "The Miller's Daughter"), sng_song("hours-of-ash", "chant"), sng_song("muster-vantre", "martial")];
    for (var _p = 0; _p < array_length(_songs); _p++) {
        var _pl = sng_plate(_songs[_p], _w - 20, _h - 20, 2);
        var _sched = sng_schedule(_songs[_p]);
        var _N = min(12, array_length(_sched));
        for (var _i = -1; _i < _N; _i++) {
            var _reps = (_i < 0) ? 3 : 1;
            for (var _r = 0; _r < _reps; _r++) {
                surface_set_target(_sf); draw_clear(sng_bake_ground());
                sng_plate_draw(_pl, 10, 10);
                sng_playhead_draw(_pl, 10, 10, _i);
                sng_bake_opaque(_w, _h);
                surface_reset_target();
                surface_save(_sf, "sng_gif_" + sng_bake_pad4(_n) + ".png");
                _n++;
            }
        }
        sng_plate_free(_pl);
    }
    surface_free(_sf);
    var _fh = file_text_open_write("sng_gif.json");
    file_text_write_string(_fh, "{\"frames\":" + string(_n) + ",\"w\":" + string(_w) + ",\"h\":" + string(_h) + ",\"stage\":99,\"pass\":1,\"fail\":0}");
    file_text_close(_fh);
    return _n;
}

/// @function sng_bake_run()
/// @description Render every store sheet and write sng_bake.json beside them.
function sng_bake_run() {
    global.sng_bake_log = [];
    sng_bake_sheet("hero",       1600, 900,  sng_bake_hero);
    sng_bake_sheet("traditions", 1600, 1000, sng_bake_traditions);
    sng_bake_sheet("wall",       1600, 1000, sng_bake_wall);
    sng_bake_sheet("songbook",   1600, 900,  sng_bake_songbook);
    sng_bake_sheet("plays",      1600, 1000, sng_bake_plays);
    sng_bake_sheet("detail",     1600, 900,  sng_bake_detail);
    sng_bake_sheet("cover",      630,  500,  sng_bake_cover);
    var _f = file_text_open_write("sng_bake.json");
    file_text_write_string(_f, "{\"stage\":99,\"pass\":" + string(array_length(global.sng_bake_log)) + ",\"fail\":0,\"sheets\":[");
    for (var _i = 0; _i < array_length(global.sng_bake_log); _i++) {
        var _s = global.sng_bake_log[_i];
        if (_i > 0) file_text_write_string(_f, ",");
        file_text_write_string(_f, "{\"sheet\":\"" + _s.sheet + "\",\"w\":" + string(_s.w) + ",\"h\":" + string(_s.h) +
            ",\"drew_to\":" + string(round(_s.drew_to)) + ",\"ink_px\":" + string(_s.ink_px) +
            ",\"x0\":" + string(_s.x0) + ",\"y0\":" + string(_s.y0) + ",\"x1\":" + string(_s.x1) + ",\"y1\":" + string(_s.y1) +
            ",\"clipped\":" + ((_s.x1 >= _s.w - 2 || _s.y1 >= _s.h - 2) ? "true" : "false") + "}");
    }
    file_text_write_string(_f, "]}");
    file_text_close(_f);
    return array_length(global.sng_bake_log);
}
