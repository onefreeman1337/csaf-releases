/// sng_engrave.gml - the engraver: draws a song as a plate of real notation in one of FIVE systems, laid out to
/// fill whatever rectangle it is given, on aged paper with its tradition's own page furniture.
///
/// Song Sheets - Every Song Engraved and Played, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ THE RISK THIS FILE CARRIES, STATED UP FRONT. Notation is the "small marks that must READ" problem at ten
/// times the complexity - a musician spots a wrong beam instantly and no mechanical check can. So:
///   - the five systems are drawn by genuinely different code paths, not one path with different constants;
///   - stem direction, beam SLOPE and grouping, barlines and ledger lines follow real engraving rules, because
///     those are what a musician reads first;
///   - the layout is SOLVED from the plate size (sng_layout), never typed, so a plate fills its paper at any size.
///
/// PUBLIC API:
///   sng_engrave(song, x, y, w, h, [marks])  -> draws the plate; returns {system, notes, layout, fill, box, unit}
///   sng_plate(song, w, h, [ss])             -> a SUPERSAMPLED plate sprite {sprite, w, h, marks, ...}
///   sng_plate_draw(plate, x, y, [alpha], [scale])
///   sng_plate_free(plate)
///   sng_playhead_draw(plate, x, y, index, [colour], [scale])  -> lights the notehead that is sounding
///   sng_layout(kind, box_w, box_h, notes)   -> the solved layout (pure; the suite sweeps it)
///   sng_ink(key)                             -> {line, accent, paper} colours for an ink (pure)

/// @function sng_ink(key)
/// @description An ink: its line colour, its accent (rubrics, seals, the playhead) and its paper. Unknown keys
/// fall back to "iron". Pure.
function sng_ink(_key) {
    static _I = undefined;
    if (_I == undefined) _I = {
        sepia:     { line: sng_rgb("#4A3A28"), accent: sng_rgb("#9C3B24"), paper: sng_rgb("#EFE4CC") },
        iron:      { line: sng_rgb("#2C2C33"), accent: sng_rgb("#5A4632"), paper: sng_rgb("#EDE7D8") },
        oxide:     { line: sng_rgb("#3A2A22"), accent: sng_rgb("#8C3A1E"), paper: sng_rgb("#E6D9C0") },
        ash:       { line: sng_rgb("#33343A"), accent: sng_rgb("#4A4E5A"), paper: sng_rgb("#DEDCD6") },
        verdigris: { line: sng_rgb("#22403A"), accent: sng_rgb("#2E6F5E"), paper: sng_rgb("#E4EADF") },
        indigo:    { line: sng_rgb("#1F2B44"), accent: sng_rgb("#3E5C86"), paper: sng_rgb("#E2E6ED") },
        ember:     { line: sng_rgb("#2E1F1B"), accent: sng_rgb("#A8521C"), paper: sng_rgb("#E9DCC6") }
    };
    if (is_string(_key) && variable_struct_exists(_I, _key)) return _I[$ _key];
    return _I.iron;
}

/// @function sng_profile(kind)
/// @description Layout profile of a laid-out system, in units of its own `step`. ⛔ `band` is a MEASUREMENT of
/// the ink one system occupies, not a comfort margin: a guessed-high figure once made the fill metric read
/// 1.000 on plates that were 40% empty paper. `collide` is the spacing below which noteheads physically
/// overlap (a correctness bound); `min_adv` is a comfort preference, scored, never asserted below plate size.
function sng_profile(_kind) {
    static _P = {
        modern:   { band: 21.0, ideal: 7.0, min_adv: 4.2,  collide: 2.6, indent: 11.5, rpad: 2.0, min_step: 3.2, max_step: 13.0, max_sys: 6 },
        mensural: { band: 14.0, ideal: 6.0, min_adv: 3.2,  collide: 2.6, indent: 8.0,  rpad: 2.0, min_step: 3.2, max_step: 13.0, max_sys: 6 },
        neume:    { band: 6.8,  ideal: 2.1, min_adv: 1.35, collide: 1.0, indent: 2.4,  rpad: 0.8, min_step: 7.0, max_step: 22.0, max_sys: 5 }
    };
    return variable_struct_exists(_P, _kind) ? _P[$ _kind] : _P.modern;
}

/// @function sng_unit(w, h)
/// @description The plate's scale unit: 1.0 on a 470x190 plate, growing with the plate. Every page-furniture
/// size, every type size AND the layout's stave clamps are multiples of it. Pure.
function sng_unit(_w, _h) { return max(0.75, min(_w / 470, _h / 190)); }

/// @function sng_layout(kind, box_w, box_h, n, [unit])
/// @description Choose systems, step and note advance TOGETHER so the notation fills the box without
/// overflowing it or crowding its noteheads. Returns {systems, per, step, adv, band_h, indent, used_h, fill,
/// adv_ratio, feasible}. Pure. ⛔ The step obeys BOTH axes, and overflow is punished harder than crowding:
/// overlapping staves are unreadable, tight noteheads are merely tight.
/// ⛔ `unit` (sng_unit of the plate) SCALES the stave's pixel clamps. Without it the clamps were raw pixels, and a
/// plate drawn SUPERSAMPLED at twice its size got a stave capped at half the size it should be: the suite
/// measured 129 of 336 plate-size layouts filling less than half their box, every chant plate among them.
function sng_layout(_kind, _bw, _bh, _n, _unit = 1) {
    var _cfg = sng_profile(is_string(_kind) ? _kind : "modern");
    if (!is_numeric(_bw) || !is_numeric(_bh)) { _bw = 1; _bh = 1; }
    _bw = max(1, _bw); _bh = max(1, _bh);
    _n = is_numeric(_n) ? clamp(floor(_n), 1, 4096) : 1;
    var _uu = is_numeric(_unit) ? max(0.25, _unit) : 1;
    var _minstep = _cfg.min_step * _uu, _maxstep = _cfg.max_step * _uu;
    var _best = undefined, _any = false;
    var _maxs = min(_cfg.max_sys, max(1, _n));
    for (var _S = 1; _S <= _maxs; _S++) {
        var _per = ceil(_n / _S);
        var _step = min(_bh / _S / _cfg.band, _bw / (_cfg.indent + _cfg.rpad + _cfg.ideal * _per));
        _step = clamp(_step, _minstep, _maxstep);
        var _ind = _cfg.indent * _step;
        var _usable = _bw - _ind - _cfg.rpad * _step;
        if (_usable <= 0) continue;
        var _adv = _usable / _per, _ratio = _adv / _step;
        var _used = _S * _step * _cfg.band;
        var _fill = min(1, _used / _bh);
        var _cost = abs(_ratio - _cfg.ideal) / _cfg.ideal + (1 - _fill) * 2.2;
        if (_ratio < _cfg.min_adv) _cost += 6 + (_cfg.min_adv - _ratio);
        if (_used > _bh * 1.02) _cost += 12 + (_used / _bh - 1) * 3;
        if (_used <= _bh * 1.02 && _ratio >= _cfg.collide) _any = true;
        if (_best == undefined || _cost < _best.cost) {
            _best = { systems: _S, per: _per, step: _step, adv: _adv, band_h: _bh / _S, indent: _ind,
                      used_h: _used, fill: _fill, adv_ratio: _ratio, cost: _cost, kind: _kind, feasible: false };
        }
    }
    if (_best == undefined) {
        _best = { systems: 1, per: _n, step: _minstep, adv: max(1, _bw / _n), band_h: _bh,
                  indent: _cfg.indent * _minstep, used_h: _minstep * _cfg.band, fill: 0,
                  adv_ratio: 0, cost: 999999, kind: _kind, feasible: false };
    }
    _best.feasible = _any;
    return _best;
}

/// @function sng_notehead(x, y, rx, ry, filled, colour, lw)
/// @description A notehead: an ellipse tilted about -20 degrees, filled or open.
function sng_notehead(_x, _y, _rx, _ry, _filled, _col, _lw) {
    if (_filled) sng_fill_convex(sng_ellipse_pts(_x, _y, _rx, _ry, -0.34, 28), _col, 1);
    else sng_ring(_x, _y, _rx - _lw * 0.5, _ry - _lw * 0.5, -0.34, _lw, _col, 1);
}

/// @function sng_ledgers(x, y, top, bottom, gap, colour, halfw, lw)
/// @description Ledger lines for a note above or below a stave. ⚠️ These locate the pitch: wrong ones make the
/// note read as a different note, which is not cosmetic.
function sng_ledgers(_x, _y, _top, _bot, _gap, _col, _hw, _lw) {
    var _yy;
    for (_yy = _top - _gap; _yy >= _y - _gap * 0.4; _yy -= _gap) sng_seg(_x - _hw, _yy, _x + _hw, _yy, _lw, _col);
    for (_yy = _bot + _gap; _yy <= _y + _gap * 0.4; _yy += _gap) sng_seg(_x - _hw, _yy, _x + _hw, _yy, _lw, _col);
}

/// @function sng_flat(x, y, step, colour, lw)
/// @description A flat sign - the one accidental this modal corpus needs.
function sng_flat(_x, _y, _step, _col, _lw) {
    sng_seg(_x, _y - _step * 2.4, _x, _y + _step * 0.9, _lw * 1.3, _col);
    var _b = sng_bezier(_x, _y - _step * 0.5, _x + _step * 1.2, _y - _step * 1.3, _x + _step * 1.5, _y - _step * 0.2, _x, _y + _step * 0.9, 10);
    sng_polyline(_b, _lw * 1.5, _col);
}

/// @function sng_sharp(x, y, step, colour, lw)
/// @description A sharp sign: two uprights and two THICK rising bars - the bars carry the weight, as engraved.
function sng_sharp(_x, _y, _step, _col, _lw) {
    var _h = _step * 0.42, _dx = _step * 0.36, _rise = _step * 0.28, _th = max(1.2, _step * 0.42);
    sng_seg(_x - _dx, _y - _step * 1.75, _x - _dx, _y + _step * 2.0, _lw * 1.1, _col);
    sng_seg(_x + _dx, _y - _step * 2.0, _x + _dx, _y + _step * 1.75, _lw * 1.1, _col);
    for (var _b = -1; _b <= 1; _b += 2) {
        var _cy = _y + _b * _step * 0.62;
        sng_fill_convex([_x - _step * 0.78, _cy + _rise, _x + _step * 0.78, _cy - _rise,
                         _x + _step * 0.78, _cy - _rise + _th, _x - _step * 0.78, _cy + _rise + _th], _col);
    }
}

/// @function sng_key_signature(x, midy, step, spelling, colour, lw)
/// @description Draw a treble-stave key signature in the standard ORDER and PLACES (sharps F C G D A E B on F5 C5
/// G5 D5 A4 E5 B4; flats B E A D G C F on B4 E5 A4 D5 G4 C5 F4). Returns the width it used (0 for none).
function sng_key_signature(_x, _midy, _step, _sp, _col, _lw) {
    static _SL = [3, 0, 4, 1, 5, 2, 6], _SS = [45, 42, 46, 43, 40, 44, 41];
    static _FL = [6, 2, 5, 1, 4, 0, 3], _FS = [41, 44, 40, 43, 39, 42, 38];
    if (!is_struct(_sp) || array_length(_sp.key) == 0) return 0;
    var _cx = _x + _step * 0.9, _i, _k;
    for (_i = 0; _i < 7; _i++) for (_k = 0; _k < array_length(_sp.key); _k++) {
        if (_sp.key[_k].acc > 0 && _sp.key[_k].letter == _SL[_i]) { sng_sharp(_cx, _midy - (_SS[_i] - 41) * _step, _step, _col, _lw); _cx += _step * 1.9; }
    }
    for (_i = 0; _i < 7; _i++) for (_k = 0; _k < array_length(_sp.key); _k++) {
        if (_sp.key[_k].acc < 0 && _sp.key[_k].letter == _FL[_i]) { sng_flat(_cx - _step * 0.4, _midy - (_FS[_i] - 41) * _step, _step, _col, _lw); _cx += _step * 1.6; }
    }
    return _cx - _x + _step * 0.4;
}

/// @function sng_clef_g(x, midy, step, colour)
/// @description A treble clef drawn with a broad nib: a spiral round the G line, a stem rising through the
/// stave to a loop above it, and a tail ending in a ball below. Stated as points it PASSES THROUGH, in stave
/// spaces from the G line (y up), then smoothed - never a font glyph, because the plate must not depend on a
/// music font the buyer does not have.
function sng_clef_g(_x, _midy, _step, _col) {
    static _C = [
         0.16, -0.08,   -0.06,  0.30,   -0.46,  0.18,   -0.58, -0.30,   -0.20, -0.84,    0.42, -0.86,
         0.86, -0.36,    0.84,  0.40,    0.34,  1.02,   -0.30,  1.62,   -0.64,  2.34,   -0.52,  3.16,
        -0.12,  3.86,    0.22,  4.10,    0.40,  3.72,    0.30,  3.04,   -0.02,  2.30,   -0.14,  1.30,
        -0.10,  0.10,    0.02, -1.20,    0.06, -2.10,   -0.12, -2.62,   -0.50, -2.72,   -0.74, -2.44
    ];
    var _sp = _step * 2;                              // one stave space
    var _gy = _midy + _sp;                            // the G line is the second line from the bottom
    var _pts = [];
    for (var _i = 0; _i < array_length(_C); _i += 2) array_push(_pts, _x + _C[_i] * _sp, _gy - _C[_i + 1] * _sp);
    var _curve = sng_catmull(_pts, 7);
    sng_pen(_curve, max(0.8, _step * 0.16), max(1.6, _step * 0.62), 0.55, _col, 1, 0.04);
    sng_disc(_x - 0.60 * _sp, _gy + 2.36 * _sp, _step * 0.46, _col);
}

/// @function sng_draw_modern(song, box, ink, lay, marks)
/// @description SYSTEM 1 - modern five-line notation: treble clef, time signature, stems, SLOPED beams,
/// barlines that beams never cross, ledger lines, flats, a final double bar.
function sng_draw_modern(_song, _box, _ink, _lay, _marks) {
    var _step = _lay.step, _gap = _step * 2, _lw = max(0.7, _step * 0.19);
    var _notes = _song.notes, _n = array_length(_notes);
    var _bar = sng_bar_sixteenths(_song.meter);
    var _ref = sng_staff_step(71);                    // B4 sits on the middle line
    var _minstem = _step * 5.5;
    var _sp = sng_spelling(_song.tonic, _song.mode);
    var _kw = (array_length(_sp.key) > 0) ? (_sp.sharps * 1.9 + _sp.flats * 1.6 + 1.3) * _step : 0;
    var _adv = max(_step * 2.6, _lay.adv - _kw / max(1, _lay.per));
    for (var _s = 0; _s < _lay.systems; _s++) {
        var _from = _s * _lay.per, _to = min(_n, _from + _lay.per);
        if (_from >= _to) break;
        var _midy = _box.y + _s * _lay.band_h + _lay.band_h * 0.5;
        var _topl = _midy - 2 * _gap, _botl = _midy + 2 * _gap, _i;
        for (_i = 0; _i < 5; _i++) {
            var _ly = _midy - (_i - 2) * _gap;
            sng_seg(_box.x, _ly, _box.x + _box.w, _ly, _lw, _ink.line);
        }
        sng_clef_g(_box.x + _step * 3.4, _midy, _step, _ink.line);
        // the key signature on EVERY system, as printed music repeats it; the metre on the first only
        sng_key_signature(_box.x + _step * 6.4, _midy, _step, _sp, _ink.line, _lw);
        if (_s == 0 && _bar > 0) {
            var _tx = _box.x + _step * 8.2 + _kw;
            sng_text(_tx, _midy - _gap, string(_song.meter[0]), _step * 6.0, _ink.line, fa_center, fa_middle, fnt_songsheets_title);
            sng_text(_tx, _midy + _gap, string(_song.meter[1]), _step * 6.0, _ink.line, fa_center, fa_middle, fnt_songsheets_title);
        }
        var _xs = _box.x + _lay.indent + _kw;
        var _px = array_create(_to - _from, 0), _py = array_create(_to - _from, 0);
        for (_i = _from; _i < _to; _i++) {
            _px[_i - _from] = _xs + (_i - _from) * _adv + _adv * 0.35;
            _py[_i - _from] = _midy - (sng_spelled_step(_notes[_i].pitch, _sp) - _ref) * _step;
        }
        // barlines BEFORE the notes, so no barline is ever drawn over a notehead
        if (_bar > 0) {
            for (_i = _from + 1; _i < _to; _i++) {
                if (floor(_notes[_i].start / _bar) != floor(_notes[_i - 1].start / _bar)) {
                    var _bx = (_px[_i - _from] + _px[_i - 1 - _from]) * 0.5;
                    sng_seg(_bx, _topl, _bx, _botl, _lw * 1.2, _ink.line);
                }
            }
        }
        if (is_array(_marks)) for (_i = 0; _i < _to - _from; _i++) array_push(_marks, { i: _from + _i, x: _px[_i], y: _py[_i] });
        for (_i = 0; _i < _to - _from; _i++) {
            var _nt = _notes[_from + _i];
            sng_ledgers(_px[_i], _py[_i], _topl, _botl, _gap, _ink.line, _step * 1.6, _lw * 1.25);
            sng_notehead(_px[_i], _py[_i], _step * 1.0, _step * 0.74, _nt.dur <= 8, _ink.line, _lw * 1.7);
            // every in-mode note is covered by the key signature; only a pitch OUTSIDE the mode needs its own sign
            var _pcn = ((_nt.pitch mod 12) + 12) mod 12;
            if (_sp.letter[_pcn] < 0 && sng_is_altered(_nt.pitch)) sng_sharp(_px[_i] - _step * 2.4, _py[_i], _step, _ink.line, _lw);
            // a dotted value (3 or 6 or 12 sixteenths) carries its augmentation dot, in a SPACE, as engraved
            if (_nt.dur == 3 || _nt.dur == 6 || _nt.dur == 12) {
                var _dy = ((sng_spelled_step(_nt.pitch, _sp) - _ref) mod 2 == 0) ? -_step : 0;
                sng_disc(_px[_i] + _step * 1.75, _py[_i] + _dy, _step * 0.30, _ink.line);
            }
        }
        // beam groups; a beam never crosses a barline
        var _groups = [], _cur = [];
        var _perbeam = (_song.meter[0] == 6 || _song.meter[0] == 5) ? 3 : 2;
        for (_i = 0; _i < _to - _from; _i++) {
            var _nn = _notes[_from + _i];
            var _crossed = _bar > 0 && _i > 0 && floor(_nn.start / _bar) != floor(_notes[_from + _i - 1].start / _bar);
            if (_crossed && array_length(_cur) > 0) { array_push(_groups, _cur); _cur = []; }
            if (_nn.dur <= 4) {
                array_push(_cur, _i);
                if (array_length(_cur) == _perbeam) { array_push(_groups, _cur); _cur = []; }
            } else {
                if (array_length(_cur) > 0) { array_push(_groups, _cur); _cur = []; }
                array_push(_groups, [_i]);
            }
        }
        if (array_length(_cur) > 0) array_push(_groups, _cur);
        for (var _g = 0; _g < array_length(_groups); _g++) {
            sng_beam_group(_groups[_g], _px, _py, _midy, _step, _minstem, _lw, _ink.line, _notes, _from);
        }
        if (_s == _lay.systems - 1 || _to >= _n) {
            var _ex = _box.x + _box.w;
            sng_seg(_ex - _step * 1.6, _topl, _ex - _step * 1.6, _botl, _lw * 1.2, _ink.line);
            sng_rect_fill(_ex - _step * 0.8, _topl, _step * 0.8, _botl - _topl, _ink.line);
        }
    }
}

/// @function sng_beam_group(grp, px, py, midy, step, minstem, lw, colour, notes, offset)
/// @description Solve and draw one beam group. Stems go up for low notes and down for high ones; the beam
/// slopes WITH the melody but is clamped to one stave space, then shifted so the SHORTEST stem still clears
/// its minimum - the rule a real engraver applies, which is why a beam over a leap still looks calm.
function sng_beam_group(_grp, _px, _py, _midy, _step, _minstem, _lw, _col, _notes, _off) {
    var _k = array_length(_grp), _i, _sum = 0;
    if (_k == 1 && _notes[_off + _grp[0]].dur >= 16) return;   // ⛔ a semibreve has NO stem
    for (_i = 0; _i < _k; _i++) _sum += _py[_grp[_i]];
    var _up = (_sum / _k) >= _midy;
    var _sdx = _up ? _step * 0.92 : -_step * 0.92;
    var _first = _grp[0], _last = _grp[_k - 1];
    var _x0 = _px[_first] + _sdx, _x1 = _px[_last] + _sdx;
    var _rise = _py[_last] - _py[_first];
    var _slope = clamp(_rise * 0.42, -_step * 2, _step * 2);
    var _m = (_k > 1 && abs(_x1 - _x0) > 0.001) ? _slope / (_x1 - _x0) : 0;
    var _B = _up ? 1000000 : -1000000;
    for (_i = 0; _i < _k; _i++) {
        var _want = _up ? _py[_grp[_i]] - _minstem : _py[_grp[_i]] + _minstem;
        var _rel = _m * (_px[_grp[_i]] + _sdx - _x0);
        _B = _up ? min(_B, _want - _rel) : max(_B, _want - _rel);
    }
    for (_i = 0; _i < _k; _i++) {
        var _sx = _px[_grp[_i]] + _sdx;
        sng_seg(_sx, _py[_grp[_i]] + (_up ? -_step * 0.15 : _step * 0.15), _sx, _B + _m * (_sx - _x0), _lw * 1.3, _col);
    }
    var _d0 = _notes[_off + _first].dur;
    var _th = _step * 0.82;
    if (_k > 1 && _d0 <= 4) {
        var _ay = _B, _by = _B + _m * (_x1 - _x0), _sg = _up ? 1 : -1;
        sng_fill_convex([_x0 - _lw * 0.6, _ay, _x1 + _lw * 0.6, _by, _x1 + _lw * 0.6, _by + _th * _sg, _x0 - _lw * 0.6, _ay + _th * _sg], _col);
        if (_d0 <= 2) {
            var _o2 = _sg * _th * 1.8;
            sng_fill_convex([_x0 - _lw * 0.6, _ay + _o2, _x1 + _lw * 0.6, _by + _o2, _x1 + _lw * 0.6, _by + _o2 + _th * _sg, _x0 - _lw * 0.6, _ay + _o2 + _th * _sg], _col);
        }
    } else if (_k == 1 && _d0 <= 4) {
        // an unbeamed quaver gets its FLAG - a single note on its own still says what it is
        var _sx2 = _px[_first] + _sdx, _ty = _B;
        var _fl = sng_bezier(_sx2, _ty, _sx2 + _step * 0.2, _ty + (_up ? 1 : -1) * _step * 1.6,
                             _sx2 + _step * 1.9, _ty + (_up ? 1 : -1) * _step * 2.2, _sx2 + _step * 1.3, _ty + (_up ? 1 : -1) * _step * 4.2, 12);
        sng_pen(_fl, _lw * 0.9, _lw * 2.6, 0.9, _col, 1, 0.15);
    }
}

/// @function sng_draw_neume(song, box, ink, lay, marks)
/// @description SYSTEM 2 - square notation: FOUR lines, one red, no stems, a C-clef that MOVES to keep the
/// melody on the stave (a chant stave has no ledger lines), ligatures on rising steps, a virga tail on long
/// notes, and a line of sung syllables under every neume.
function sng_draw_neume(_song, _box, _ink, _lay, _marks) {
    static _SYL = ["ky", "ri", "e", "lae", "son", "do", "mi", "nus", "ve", "ni", "te", "a", "do", "re", "mus",
                   "glo", "ri", "a", "san", "ctus", "be", "ne", "dic", "tus", "ho", "san", "na", "in", "ex", "cel",
                   "sis", "lu", "men", "ae", "ter", "num", "req", "ui", "em", "pa", "cem"];
    var _step = _lay.step, _lw = max(0.8, _step * 0.09);
    var _notes = _song.notes, _n = array_length(_notes), _i;
    var _seed = sng_hash(_song.song_id);
    var _sp = sng_spelling(_song.tonic, _song.mode);
    var _lo = 1000000, _hi = -1000000;
    for (_i = 0; _i < _n; _i++) { var _ss = sng_spelled_step(_notes[_i].pitch, _sp); _lo = min(_lo, _ss); _hi = max(_hi, _ss); }
    var _ref = sng_jsround((_lo + _hi) / 2);         // MIDRANGE, so the cadence stays on the stave
    for (var _s = 0; _s < _lay.systems; _s++) {
        var _from = _s * _lay.per, _to = min(_n, _from + _lay.per);
        if (_from >= _to) break;
        var _top = _box.y + _s * _lay.band_h;
        var _midy = _top + _lay.band_h * 0.40;
        for (_i = 0; _i < 4; _i++) {
            var _ly = _midy - (_i - 1.5) * _step;
            sng_seg(_box.x, _ly, _box.x + _box.w, _ly, (_i == 1) ? _lw * 1.8 : _lw, (_i == 1) ? _ink.accent : _ink.line);
        }
        // the C-clef: two square heads on a stroke, standing on the line it names
        var _cy = _midy - 0.5 * _step, _cx = _box.x + _step * 0.75, _q = _step * 0.34;
        sng_seg(_cx - _q, _cy - _step * 0.62, _cx - _q, _cy + _step * 0.62, max(1.2, _step * 0.14), _ink.line);
        sng_rect_fill(_cx - _q, _cy - _step * 0.62, _q * 2.2, _q * 1.25, _ink.line);
        sng_rect_fill(_cx - _q, _cy + _step * 0.62 - _q * 1.25, _q * 2.2, _q * 1.25, _ink.line);
        var _xs = _box.x + _lay.indent, _half = _step * 0.42;
        for (_i = _from; _i < _to; _i++) {
            var _nt = _notes[_i];
            var _sy = _midy - (sng_spelled_step(_nt.pitch, _sp) - _ref) * (_step / 2);
            var _sx = _xs + (_i - _from) * _lay.adv + _lay.adv * 0.3;
            if (is_array(_marks)) array_push(_marks, { i: _i, x: _sx, y: _sy });
            // a punctum is a quadrilateral cut by a broad pen, so its top and bottom lean very slightly
            var _lean = _half * 0.16;
            sng_fill_convex([_sx - _half, _sy - _half * 0.74 + _lean, _sx + _half, _sy - _half * 0.74,
                             _sx + _half, _sy + _half * 0.74, _sx - _half, _sy + _half * 0.74 + _lean], _ink.line);
            if (_nt.dur >= 12) sng_rect_fill(_sx + _half * 0.62, _sy, _half * 0.38, _step * 1.05, _ink.line);
            var _syl = _SYL[floor(real((_seed + _i * 2654435761.0) mod array_length(_SYL)))];
            // ⛔ the syllable is sized by the GAP between neumes, not by the stave: sized off the stave, two
            // syllables once ran together into one unreadable word when the notes were made bigger
            sng_text(_sx, _top + _lay.band_h * 0.80, _syl, max(7, min(_step * 0.95, _lay.adv * 0.52)),
                     _ink.line, fa_center, fa_middle, fnt_songsheets, 0.9);
            if (_i < _to - 1) {
                var _ny = _midy - (sng_spelled_step(_notes[_i + 1].pitch, _sp) - _ref) * (_step / 2);
                if (_ny < _sy && (_sy - _ny) <= _step * 1.1) {
                    var _nx = _xs + (_i + 1 - _from) * _lay.adv + _lay.adv * 0.3;
                    sng_seg(_sx + _half, _sy - _half * 0.6, _nx - _half, _ny + _half * 0.6, max(1.4, _step * 0.16), _ink.line);
                }
            }
        }
        // the custos: a small guide mark at the end of each system showing the first note of the next line
        if (_to < _n) {
            var _gy = _midy - (sng_spelled_step(_notes[_to].pitch, _sp) - _ref) * (_step / 2);
            var _gx = _box.x + _box.w - _step * 0.5;
            sng_fill_convex([_gx - _step * 0.22, _gy - _step * 0.16, _gx + _step * 0.22, _gy - _step * 0.16,
                             _gx + _step * 0.22, _gy + _step * 0.16, _gx - _step * 0.22, _gy + _step * 0.16], _ink.line);
            sng_seg(_gx + _step * 0.18, _gy, _gx + _step * 0.38, _gy - _step * 0.7, max(1, _step * 0.07), _ink.line);
        } else {
            var _ex = _box.x + _box.w - _step * 0.3;
            sng_seg(_ex, _midy - _step * 1.5, _ex, _midy + _step * 1.5, max(1.2, _step * 0.12), _ink.line);
        }
    }
}

/// @function sng_draw_mensural(song, box, ink, lay, marks)
/// @description SYSTEM 3 - mensural notation: VOID noteheads, diamond longs, short unbeamed down-stems, a
/// mensuration circle instead of a time signature, no barlines, and a signum closing each system.
function sng_draw_mensural(_song, _box, _ink, _lay, _marks) {
    var _step = _lay.step, _gap = _step * 2, _lw = max(0.7, _step * 0.17);
    var _notes = _song.notes, _n = array_length(_notes), _i;
    var _ref = sng_staff_step(71);
    var _sp = sng_spelling(_song.tonic, _song.mode);
    // a G-clef written as the LETTER, as sixteenth-century part-books did, then the signature, then the circle
    var _kw = (array_length(_sp.key) > 0) ? (_sp.sharps * 1.9 + _sp.flats * 1.6 + 1.3) * _step : 0;
    var _lead = _step * 3.0 + _kw;
    var _adv = max(_step * 2.6, _lay.adv - _lead / max(1, _lay.per));
    for (var _s = 0; _s < _lay.systems; _s++) {
        var _from = _s * _lay.per, _to = min(_n, _from + _lay.per);
        if (_from >= _to) break;
        var _midy = _box.y + _s * _lay.band_h + _lay.band_h * 0.5;
        var _topl = _midy - 2 * _gap, _botl = _midy + 2 * _gap;
        for (_i = 0; _i < 5; _i++) {
            var _ly = _midy - (_i - 2) * _gap;
            sng_seg(_box.x, _ly, _box.x + _box.w, _ly, _lw, _ink.line);
        }
        sng_text(_box.x + _step * 1.5, _midy + _gap, "G", _step * 5.2, _ink.line, fa_center, fa_middle, fnt_songsheets_title);
        sng_key_signature(_box.x + _step * 2.8, _midy, _step, _sp, _ink.line, _lw);
        // mensuration sign: an open circle with a dot (tempus perfectum), repeated on every system
        var _mx = _box.x + _step * 3.2 + _lead, _arc = [];
        for (var _a = 0.5; _a <= 2 * pi - 0.5; _a += 0.12) array_push(_arc, _mx + cos(_a) * _step * 1.4, _midy + sin(_a) * _step * 1.4);
        sng_polyline(_arc, _lw * 1.7, _ink.line);
        sng_disc(_mx, _midy, _step * 0.34, _ink.line);
        var _xs = _box.x + _lay.indent + _lead;
        for (_i = _from; _i < _to; _i++) {
            var _nt = _notes[_i];
            var _sy = _midy - (sng_spelled_step(_nt.pitch, _sp) - _ref) * _step;
            var _sx = _xs + (_i - _from) * _adv + _adv * 0.35;
            if (is_array(_marks)) array_push(_marks, { i: _i, x: _sx, y: _sy });
            sng_ledgers(_sx, _sy, _topl, _botl, _gap, _ink.line, _step * 1.6, _lw * 1.2);
            // WHITE MENSURAL SHAPES: a breve is a void SQUARE, a semibreve a void LOZENGE, a minim a lozenge with a
            // stem rising from its top point. (The MZ plugin drew round heads with a stem hanging off the left,
            // which reads as modern notation drawn badly; these are the shapes a sixteenth-century part-book uses.)
            var _d = _step * 0.95;
            if (_nt.dur >= 16) {
                sng_polyline([_sx - _d, _sy - _d * 0.8, _sx + _d, _sy - _d * 0.8, _sx + _d, _sy + _d * 0.8, _sx - _d, _sy + _d * 0.8], _lw * 1.6, _ink.line, 1, true);
                sng_seg(_sx - _d, _sy - _d * 1.1, _sx - _d, _sy + _d * 1.1, _lw * 1.6, _ink.line);
                sng_seg(_sx + _d, _sy - _d * 1.1, _sx + _d, _sy + _d * 1.1, _lw * 1.6, _ink.line);
            } else {
                var _lz = [_sx - _d * 0.78, _sy, _sx, _sy - _d * 1.02, _sx + _d * 0.78, _sy, _sx, _sy + _d * 1.02];
                sng_polyline(_lz, _lw * 1.7, _ink.line, 1, true);
                if (_nt.dur <= 8) sng_seg(_sx, _sy - _d * 1.02, _sx, _sy - _step * 3.6, _lw * 1.4, _ink.line);
                if (_nt.dur <= 4) sng_fill_convex(_lz, _ink.line);   // a semiminim is the blackened minim
            }
            var _pcm = ((_nt.pitch mod 12) + 12) mod 12;
            if (_sp.letter[_pcm] < 0 && sng_is_altered(_nt.pitch)) sng_sharp(_sx - _step * 2.4, _sy, _step, _ink.line, _lw);
        }
        var _ex = _box.x + _box.w - _step * 1.2;
        sng_ring(_ex, _midy, _step * 0.9, _step * 0.9, 0, _lw * 1.4, _ink.accent);
        sng_disc(_ex, _midy, _step * 0.28, _ink.accent);
    }
}

/// @function sng_draw_grid(song, box, ink, u, marks)
/// @description SYSTEM 4 - percussion tablature: three lanes (the call split by register, and a TREAD derived
/// from the metre so it can never be empty) above a charted signal line for the pitched call. No pitch stave at
/// all. ⛔ A cell's height is derived from its WIDTH, and every label is sized to the margin MEASURED for it.
function sng_draw_grid(_song, _box, _ink, _u, _marks) {
    var _RES = 4, _i, _c;
    var _notes = _song.notes, _n = array_length(_notes);
    var _cols = max(8, ceil(_song.total_sixteenths / _RES));
    var _rows = 3, _lw = max(0.7, _u);
    var _LANES = is_array(_song.lanes) ? _song.lanes : ["HORN", "DRUM", "TREAD"];
    var _CALL = is_string(_song.call_lane) ? _song.call_lane : "CALL";
    var _pad = 4 * _u;
    var _lf = max(8, min(13 * _u, _box.h * 0.05));
    var _lwid = 0;
    for (_i = 0; _i < 3; _i++) _lwid = max(_lwid, sng_text_w(_LANES[_i], _lf));
    _lwid = min(max(_lwid, sng_text_w(_CALL, _lf)) + _pad * 2, _box.w * 0.18);
    var _gx = _box.x + _lwid, _gy = _box.y, _gw = _box.w - _lwid, _cw = _gw / _cols;
    var _rowh = max(10 * _u, min(_box.h * 0.17, _cw * 2.4));
    var _gh = _rowh * _rows, _gaph = _box.h * 0.07;
    var _hornh = max(_box.h * 0.18, _box.h - _gh - _gaph);
    for (_c = 0; _c <= _cols; _c++) sng_seg(_gx + _c * _cw, _gy, _gx + _c * _cw, _gy + _gh, _lw * 0.8, _ink.line, 0.45);
    for (_i = 0; _i <= _rows; _i++) sng_seg(_gx, _gy + _i * _rowh, _gx + _gw, _gy + _i * _rowh, _lw * 1.1, _ink.line);
    var _perbar = max(2, sng_jsround(sng_bar_sixteenths(_song.meter) / _RES));
    if (_perbar <= 0) _perbar = 4;
    for (_c = 0; _c <= _cols; _c += _perbar) sng_seg(_gx + _c * _cw, _gy - _rowh * 0.18, _gx + _c * _cw, _gy + _gh + _rowh * 0.18, _lw * 1.9, _ink.accent);
    for (_i = 0; _i < _rows; _i++) sng_text(_gx - _pad, _gy + _i * _rowh + _rowh / 2, _LANES[_i], _lf, _ink.line, fa_right, fa_middle, fnt_songsheets, 0.85);
    var _lo = 127, _hi = 0;
    for (_i = 0; _i < _n; _i++) { _lo = min(_lo, _notes[_i].pitch); _hi = max(_hi, _notes[_i].pitch); }
    var _mid = (_lo + _hi) / 2;
    // TREAD: the company's footfall, one hit per beat, the strong beat heavier
    var _beat = max(1, sng_jsround((16 / max(1, _song.meter[1])) / _RES));
    var _ty = _gy + 2 * _rowh + _rowh / 2, _td = min(_cw * 0.22, _rowh * 0.16);
    for (_c = 0; _c < _cols; _c += _beat) sng_disc(_gx + (_c + 0.5) * _cw, _ty, ((_c mod _perbar) == 0) ? _td * 1.55 : _td, _ink.line, 0.85);
    for (_i = 0; _i < _n; _i++) {
        var _nt = _notes[_i];
        var _col = floor(_nt.start / _RES);
        if (_col >= _cols) continue;
        var _row = (_nt.pitch >= _mid) ? 0 : 1;
        var _cx = _gx + (_col + 0.5) * _cw, _cy = _gy + _row * _rowh + _rowh / 2;
        if (_nt.dur >= 8) {
            var _span = min(_cols - _col, max(1, sng_jsround(_nt.dur / _RES)));
            sng_rect_fill(_cx - _cw * 0.32, _cy - _rowh * 0.12, _span * _cw - _cw * 0.36, _rowh * 0.24, _ink.line);
        } else {
            var _d = min(_cw * 0.34, _rowh * 0.24);
            sng_fill_convex([_cx, _cy - _d * 1.3, _cx + _d * 1.3, _cy, _cx, _cy + _d * 1.3, _cx - _d * 1.3, _cy], _ink.line);
        }
    }
    // THE CALL, charted: a ruled band, a stepped contour (a bugle holds a pitch until the next call), shaded
    var _hy = _gy + _gh + _gaph, _hs = _hornh * 0.78;
    for (_i = 0; _i <= 4; _i++) {
        var _firm = (_i == 0 || _i == 4);
        sng_seg(_gx, _hy + (_i / 4) * _hs, _gx + _gw, _hy + (_i / 4) * _hs, _firm ? _lw * 1.1 : _lw * 0.8, _ink.line, _firm ? 1 : 0.3);
    }
    sng_text(_gx - _pad, _hy + _hs * 0.5, _CALL, _lf, _ink.line, fa_right, fa_middle, fnt_songsheets, 0.85);
    var _span2 = max(1, _hi - _lo), _inset = _hs * 0.10;
    var _dotr = max(2.2, min(_cw * 0.30, _hs * 0.055));
    var _xs = [], _ys = [];
    for (_i = 0; _i < _n; _i++) {
        if (floor(_notes[_i].start / _RES) >= _cols) continue;
        array_push(_xs, _gx + (floor(_notes[_i].start / _RES) + 0.5) * _cw);
        array_push(_ys, _hy + _hs - _inset - ((_notes[_i].pitch - _lo) / _span2) * (_hs - _inset * 2));
        if (is_array(_marks)) array_push(_marks, { i: _i, x: _xs[array_length(_xs) - 1], y: _ys[array_length(_ys) - 1] });
    }
    var _k = array_length(_xs);
    if (_k > 1) {
        // the shaded area under the call, as vertical strips (a step profile is concave - never a fan)
        for (_i = 0; _i < _k; _i++) {
            var _xr = (_i < _k - 1) ? _xs[_i + 1] : _xs[_i] + _cw * 0.5;
            sng_rect_fill(_xs[_i], _ys[_i], _xr - _xs[_i], _hy + _hs - _ys[_i], _ink.accent, 0.14);
        }
        var _line = [_xs[0], _ys[0]];
        for (_i = 1; _i < _k; _i++) array_push(_line, _xs[_i], _ys[_i - 1], _xs[_i], _ys[_i]);
        sng_polyline(_line, _lw * 1.6, _ink.accent);
    }
    for (_i = 0; _i < _k; _i++) sng_disc(_xs[_i], _ys[_i], _dotr, _ink.accent);
}

/// @function sng_draw_spiral(song, box, ink, u, marks)
/// @description SYSTEM 5 - an invented stave for the fae: three guide lines CURLED into a spiral (a stave rolled
/// up), each note placed perpendicular to it by pitch and STEMMED to the centre curl so it reads as a note on a
/// line, not a star on a chart, and a dashed ARROWED return from the last note to the first, because a round
/// comes round.
function sng_draw_spiral(_song, _box, _ink, _u, _marks) {
    var _cx = _box.x + _box.w / 2, _cy = _box.y + _box.h / 2, _turns = 2.35, _i;
    var _ry = _box.h * 0.46, _rx = min(_box.w * 0.46, _ry * 3.2), _r0 = 0.30, _gp = 0.13;
    var _notes = _song.notes, _n = array_length(_notes);
    for (var _s = -1; _s <= 1; _s++) {
        var _pts = [];
        for (var _t = 0; _t <= 1.0001; _t += 0.004) {
            var _ang = _t * _turns * 2 * pi - pi / 2, _f = _r0 + _t * (1 - _r0 - _gp) + _s * _gp;
            array_push(_pts, _cx + cos(_ang) * _rx * _f, _cy + sin(_ang) * _ry * _f);
        }
        sng_polyline(_pts, max(0.7, _u * 0.9), _ink.line, (_s == 0) ? 0.8 : 0.45);
    }
    var _spokes = (_song.meter[0] > 0) ? _song.meter[0] : 5;
    for (_i = 0; _i < _spokes; _i++) {
        var _a = (_i / _spokes) * 2 * pi - pi / 2;
        sng_seg(_cx + cos(_a) * _rx * (_r0 - _gp), _cy + sin(_a) * _ry * (_r0 - _gp), _cx + cos(_a) * _rx, _cy + sin(_a) * _ry, max(0.6, _u * 0.8), _ink.accent, 0.3);
    }
    var _lo = 127, _hi = 0;
    for (_i = 0; _i < _n; _i++) { _lo = min(_lo, _notes[_i].pitch); _hi = max(_hi, _notes[_i].pitch); }
    var _span = max(1, _hi - _lo);
    var _px = array_create(_n, 0), _py = array_create(_n, 0), _ax = array_create(_n, 0), _ay = array_create(_n, 0);
    for (_i = 0; _i < _n; _i++) {
        var _tt = _i / max(1, _n - 1), _off = ((_notes[_i].pitch - _lo) / _span) * 2 - 1;
        var _an = _tt * _turns * 2 * pi - pi / 2;
        var _fo = _r0 + _tt * (1 - _r0 - _gp) + _off * _gp, _fa = _r0 + _tt * (1 - _r0 - _gp);
        _px[_i] = _cx + cos(_an) * _rx * _fo; _py[_i] = _cy + sin(_an) * _ry * _fo;
        _ax[_i] = _cx + cos(_an) * _rx * _fa; _ay[_i] = _cy + sin(_an) * _ry * _fa;
    }
    // the melodic line, drawn ALONG the curl so it reads as one voice
    var _mel = [];
    for (_i = 0; _i < _n; _i++) {
        if (_i == 0) { array_push(_mel, _px[0], _py[0]); continue; }
        var _tp = (_i - 1) / max(1, _n - 1), _ti = _i / max(1, _n - 1);
        var _op = ((_notes[_i - 1].pitch - _lo) / _span) * 2 - 1, _oi = ((_notes[_i].pitch - _lo) / _span) * 2 - 1;
        for (var _k = 1; _k <= 6; _k++) {
            var _f2 = _k / 6, _tq = _tp + (_ti - _tp) * _f2, _oq = _op + (_oi - _op) * _f2;
            var _aq = _tq * _turns * 2 * pi - pi / 2, _rq = _r0 + _tq * (1 - _r0 - _gp) + _oq * _gp;
            array_push(_mel, _cx + cos(_aq) * _rx * _rq, _cy + sin(_aq) * _ry * _rq);
        }
    }
    sng_polyline(_mel, max(0.9, _u * 1.1), _ink.accent, 0.6);
    for (_i = 0; _i < _n; _i++) {
        sng_seg(_ax[_i], _ay[_i], _px[_i], _py[_i], max(0.8, _u * 0.95), _ink.line, 0.85);
        var _rr = _u * (2.0 + min(4.2, _notes[_i].dur * 0.30));
        if (is_array(_marks)) array_push(_marks, { i: _i, x: _px[_i], y: _py[_i] });
        sng_disc(_px[_i], _py[_i], _rr, _ink.line);
        if (_notes[_i].dur >= 12) sng_ring(_px[_i], _py[_i], _rr + _u * 2.6, _rr + _u * 2.6, 0, max(0.8, _u), _ink.line);
    }
    if (_n > 1) {
        // the return, dashed and arrowed: a quadratic from the last note back to the first
        var _qx = _cx, _qy = _cy - _ry * 1.02, _dash = [];
        var _x0 = _px[_n - 1], _y0 = _py[_n - 1], _x2 = _px[0], _y2 = _py[0];
        var _steps = 60, _on = true, _acc = 0, _dl = _u * 5, _gl = _u * 3.5, _prevx = _x0, _prevy = _y0;
        for (_i = 1; _i <= _steps; _i++) {
            var _t2 = _i / _steps, _u2 = 1 - _t2;
            var _bx = _u2 * _u2 * _x0 + 2 * _u2 * _t2 * _qx + _t2 * _t2 * _x2;
            var _by = _u2 * _u2 * _y0 + 2 * _u2 * _t2 * _qy + _t2 * _t2 * _y2;
            if (_on) sng_seg(_prevx, _prevy, _bx, _by, max(1.1, _u * 1.5), _ink.accent, 0.9);
            _acc += point_distance(_prevx, _prevy, _bx, _by);
            if (_acc >= (_on ? _dl : _gl)) { _on = !_on; _acc = 0; }
            _prevx = _bx; _prevy = _by;
        }
        var _tx = _x2 - _qx, _ty = _y2 - _qy, _tl = max(0.0001, sqrt(_tx * _tx + _ty * _ty));
        _tx /= _tl; _ty /= _tl;
        var _ah = _u * 6.5, _aw = _u * 3.4;
        sng_fill_convex([_x2, _y2, _x2 - _tx * _ah - _ty * _aw, _y2 - _ty * _ah + _tx * _aw, _x2 - _tx * _ah + _ty * _aw, _y2 - _ty * _ah - _tx * _aw], _ink.accent);
    }
}

/// @function sng_paper(x, y, w, h, ink, seed, u)
/// @description The sheet: paper tone, laid lines, foxing, a PLATE MARK (the rectangle an intaglio plate
/// presses into the paper, which is what makes a print read as ENGRAVED rather than typeset) and handled
/// edges. Deterministic per song.
function sng_paper(_x, _y, _w, _h, _ink, _seed, _u) {
    var _g = sng_rng(_seed), _i;
    sng_rect_fill(_x, _y, _w, _h, _ink.paper);
    var _gap = 7 * _u;
    for (var _yy = _y + _gap; _yy < _y + _h; _yy += _gap) {
        sng_seg(_x, _yy + (sng_rng_next(_g) - 0.5) * _u, _x + _w, _yy + (sng_rng_next(_g) - 0.5) * _u, max(0.6, _u), _ink.line, 0.05);
    }
    var _spots = sng_jsround(18 * max(1, _u * 0.7));
    var _fox = make_colour_rgb(140, 105, 60);
    for (_i = 0; _i < _spots; _i++) {
        var _rad = (3 + sng_rng_next(_g) * 13) * _u;
        var _fx = _x + _rad + sng_rng_next(_g) * max(0, _w - _rad * 2);
        var _fy = _y + _rad + sng_rng_next(_g) * max(0, _h - _rad * 2);
        sng_spot(_fx, _fy, _rad, _fox, 0.10 + sng_rng_next(_g) * 0.05);
    }
    // the plate mark: the pressed plate area is a shade smoother and cooler; its edge catches light on one
    // side and shadow on the other
    var _pm = 5 * _u;
    sng_rect_fill(_x + _pm, _y + _pm, _w - _pm * 2, _h - _pm * 2, c_white, 0.10);
    sng_seg(_x + _pm, _y + _pm, _x + _w - _pm, _y + _pm, max(1, _u * 1.1), _ink.line, 0.16);
    sng_seg(_x + _pm, _y + _pm, _x + _pm, _y + _h - _pm, max(1, _u * 1.1), _ink.line, 0.16);
    sng_seg(_x + _pm, _y + _h - _pm, _x + _w - _pm, _y + _h - _pm, max(1, _u * 1.1), c_white, 0.55);
    sng_seg(_x + _w - _pm, _y + _pm, _x + _w - _pm, _y + _h - _pm, max(1, _u * 1.1), c_white, 0.55);
    sng_edge_shade(_x, _y, _w, _h, 16 * _u, make_colour_rgb(120, 90, 50), 0.18);
}

/// @function sng_flourish(x, y, dir, len, u, colour)
/// @description An engraver's swash beside the title: a tapered stroke that runs out from the title and ends in
/// a small curl. `dir` is -1 (to the left) or 1 (to the right).
function sng_flourish(_x, _y, _dir, _len, _u, _col) {
    var _p = sng_bezier(_x, _y, _x + _dir * _len * 0.35, _y - _u * 4, _x + _dir * _len * 0.7, _y + _u * 5, _x + _dir * _len, _y, 18);
    // the curl at the tip
    var _cx = _x + _dir * _len, _cr = _u * 3.2;
    for (var _a = 0; _a <= 1.6 * pi; _a += 0.35) {
        var _r = _cr * (1 - _a / (2.2 * pi));
        array_push(_p, _cx + _dir * sin(_a) * _r, _y - _cr + cos(_a) * _r);
    }
    sng_pen(_p, max(0.6, _u * 0.35), max(1.2, _u * 1.6), 0.4, _col, 1, 0.12);
    sng_disc(_x + _dir * _u * 2, _y, max(1, _u * 1.1), _col);
}

/// @function sng_furniture(song, x, y, w, h, ink, u)
/// @description Page furniture per tradition, so two plates never share a frame: an illuminated initial, a
/// double border with studs, a stamped seal, a hymnal's double rule and number, a rope, binding rings, tallies,
/// a mourning band, thorns, or a plain rule.
function sng_furniture(_song, _x, _y, _w, _h, _ink, _u) {
    var _f = _song.furniture, _i;
    switch (_f) {
        case "illuminated":
            sng_rect_line(_x + 9 * _u, _y + 9 * _u, _w - 18 * _u, _h - 18 * _u, 1.2 * _u, _ink.line);
            var _b = 30 * _u;
            sng_rect_fill(_x + 14 * _u, _y + 14 * _u, _b, _b, _ink.accent);
            sng_rect_line(_x + 14 * _u + 2 * _u, _y + 14 * _u + 2 * _u, _b - 4 * _u, _b - 4 * _u, 0.8 * _u, _ink.paper, 0.6);
            // ⛔ the initial is the SONG's, never the tradition's: one red "P" on every chant plate reads stamped
            var _init = string_upper(string_char_at(_song.title, 1));
            if (_init == "T" && string_length(_song.title) > 4 && string_upper(string_copy(_song.title, 1, 4)) == "THE ") _init = string_upper(string_char_at(_song.title, 5));
            sng_text(_x + 14 * _u + _b / 2, _y + 14 * _u + _b / 2 + _u, _init, _b * 0.86, _ink.paper, fa_center, fa_middle, fnt_songsheets_title);
            break;
        case "bordered":
            sng_rect_line(_x + 8 * _u, _y + 8 * _u, _w - 16 * _u, _h - 16 * _u, 1.0 * _u, _ink.line);
            sng_rect_line(_x + 12 * _u, _y + 12 * _u, _w - 24 * _u, _h - 24 * _u, 0.8 * _u, _ink.line);
            for (_i = 0; _i < 4; _i++) sng_disc(_x + ((_i mod 2 == 0) ? 12 * _u : _w - 12 * _u), _y + ((_i < 2) ? 12 * _u : _h - 12 * _u), 2.8 * _u, _ink.accent);
            break;
        case "stamped":
            sng_rect_line(_x + 10 * _u, _y + 10 * _u, _w - 20 * _u, _h - 20 * _u, 2.4 * _u, _ink.line);
            var _sx = _x + _w - 34 * _u, _sy = _y + 34 * _u;
            sng_ring(_sx, _sy, 13 * _u, 13 * _u, 0, 1.6 * _u, _ink.accent, 0.9);
            sng_ring(_sx, _sy, 9 * _u, 9 * _u, 0, 1.1 * _u, _ink.accent, 0.9);
            for (_i = 0; _i < 12; _i++) {
                var _a = _i / 12 * 2 * pi;
                sng_seg(_sx + cos(_a) * 9 * _u, _sy + sin(_a) * 9 * _u, _sx + cos(_a) * 13 * _u, _sy + sin(_a) * 13 * _u, 0.9 * _u, _ink.accent, 0.8);
            }
            sng_fill_convex([_sx, _sy - 4.5 * _u, _sx + 4.5 * _u, _sy, _sx, _sy + 4.5 * _u, _sx - 4.5 * _u, _sy], _ink.accent, 0.9);
            break;
        case "ruled":
            sng_seg(_x + 12 * _u, _y + 13 * _u, _x + _w - 12 * _u, _y + 13 * _u, 1.8 * _u, _ink.line);
            sng_seg(_x + 12 * _u, _y + 17 * _u, _x + _w - 12 * _u, _y + 17 * _u, 0.7 * _u, _ink.line);
            sng_seg(_x + 12 * _u, _y + _h - 13 * _u, _x + _w - 12 * _u, _y + _h - 13 * _u, 1.8 * _u, _ink.line);
            sng_seg(_x + 12 * _u, _y + _h - 17 * _u, _x + _w - 12 * _u, _y + _h - 17 * _u, 0.7 * _u, _ink.line);
            sng_text(_x + _w - 18 * _u, _y + 22 * _u, string(1 + (sng_hash(_song.song_id) mod 700)), 18 * _u, _ink.accent, fa_right, fa_top, fnt_songsheets_title);
            break;
        case "roped":
            var _seg = 9 * _u, _rp = [], _rq = [];
            for (var _rx = _x + 11 * _u; _rx < _x + _w - 11 * _u; _rx += _seg) {
                var _e = min(_rx + _seg, _x + _w - 11 * _u);
                var _up = (sng_jsround((_rx - _x) / _seg) mod 2 == 0);
                sng_polyline(sng_bezier(_rx, _y + 11 * _u, (_rx + _e) / 2, _y + 11 * _u + (_up ? 3.4 : -3.4) * _u, (_rx + _e) / 2, _y + 11 * _u + (_up ? 3.4 : -3.4) * _u, _e, _y + 11 * _u, 6), 1.9 * _u, _ink.accent);
                sng_polyline(sng_bezier(_rx, _y + _h - 11 * _u, (_rx + _e) / 2, _y + _h - 11 * _u + (_up ? 3.4 : -3.4) * _u, (_rx + _e) / 2, _y + _h - 11 * _u + (_up ? 3.4 : -3.4) * _u, _e, _y + _h - 11 * _u, 6), 1.9 * _u, _ink.accent);
            }
            sng_rect_line(_x + 15 * _u, _y + 15 * _u, _w - 30 * _u, _h - 30 * _u, 0.8 * _u, _ink.line);
            break;
        case "sigilled":
            sng_rect_line(_x + 10 * _u, _y + 10 * _u, _w - 20 * _u, _h - 20 * _u, 1.1 * _u, _ink.line);
            for (_i = 0; _i < 4; _i++) {
                var _qx = _x + ((_i mod 2 == 0) ? 10 * _u : _w - 10 * _u), _qy = _y + ((_i < 2) ? 10 * _u : _h - 10 * _u);
                sng_disc(_qx, _qy, 8 * _u, _ink.paper);
                sng_ring(_qx, _qy, 7 * _u, 7 * _u, 0, 1.4 * _u, _ink.accent);
                sng_ring(_qx, _qy, 3 * _u, 3 * _u, 0, 1.2 * _u, _ink.accent);
                sng_seg(_qx - 7 * _u, _qy, _qx + 7 * _u, _qy, 1.2 * _u, _ink.accent);
                sng_seg(_qx, _qy - 7 * _u, _qx, _qy + 7 * _u, 1.2 * _u, _ink.accent);
            }
            break;
        case "tallied":
            sng_rect_line(_x + 10 * _u, _y + 10 * _u, _w - 20 * _u, _h - 20 * _u, 1.2 * _u, _ink.line);
            // ⛔ the tallies live in the TITLE band: at the foot they struck through the bottom of the chart
            var _tal = 3 + (sng_hash(_song.song_id) mod 9);
            for (_i = 0; _i < _tal; _i++) {
                var _grp = _i div 5, _ing = _i mod 5;
                var _bx = _x + _w - 22 * _u - _grp * 17 * _u - _ing * 3.2 * _u;
                if (_ing == 4) sng_seg(_bx + 12 * _u, _y + 22 * _u, _bx - 1.5 * _u, _y + 34 * _u, 1.6 * _u, _ink.accent);
                else sng_seg(_bx, _y + 22 * _u, _bx, _y + 34 * _u, 1.6 * _u, _ink.accent);
            }
            break;
        case "mourning":
            sng_rect_fill(_x + 6 * _u, _y + 6 * _u, _w - 12 * _u, 4 * _u, _ink.line);
            sng_rect_fill(_x + 6 * _u, _y + _h - 10 * _u, _w - 12 * _u, 4 * _u, _ink.line);
            sng_rect_line(_x + 6 * _u, _y + 6 * _u, _w - 12 * _u, _h - 12 * _u, 0.8 * _u, _ink.line);
            break;
        case "thorned":
            for (var _t = 0; _t <= _w - 20 * _u; _t += 6 * _u) {
                var _big = (sng_jsround(_t / _u) mod 12 == 0);
                sng_seg(_x + 10 * _u + _t, _y + 10 * _u, _x + 10 * _u + _t + 3 * _u, _y + 10 * _u - (_big ? 4 : 2) * _u, 1.0 * _u, _ink.accent);
                sng_seg(_x + 10 * _u + _t, _y + _h - 10 * _u, _x + 10 * _u + _t + 3 * _u, _y + _h - 10 * _u + (_big ? 4 : 2) * _u, 1.0 * _u, _ink.accent);
            }
            sng_rect_line(_x + 10 * _u, _y + 10 * _u, _w - 20 * _u, _h - 20 * _u, 1.0 * _u, _ink.line);
            break;
        case "plain":
            // named, not left to the default: an unconfigured default is not a decision
            sng_rect_line(_x + 10 * _u, _y + 10 * _u, _w - 20 * _u, _h - 20 * _u, 1.0 * _u, _ink.line);
            sng_rect_line(_x + 13 * _u, _y + 13 * _u, _w - 26 * _u, _h - 26 * _u, 0.6 * _u, _ink.line, 0.6);
            break;
        default:
            sng_rect_line(_x + 10 * _u, _y + 10 * _u, _w - 20 * _u, _h - 20 * _u, 1.0 * _u, _ink.line);
            break;
    }
}

/// @function sng_engrave(song, x, y, w, h, [marks])
/// @description DRAW A SONG AS AN ENGRAVED PLATE into the current target, filling the rect. `marks`, if an
/// array, is cleared and filled with the screen position of every notehead in note order ({i, x, y}) - only the
/// code that laid a note out knows where it went, so the playhead reads it from here. Returns {system, notes,
/// layout, fill, box, unit}, or undefined for a non-song. Never throws.
function sng_engrave(_song, _x, _y, _w, _h, _marks = undefined) {
    if (!sng_is_song(_song)) return undefined;
    if (!is_real(_x) || !is_real(_y) || !is_real(_w) || !is_real(_h)) return undefined;
    if (_w < 40 || _h < 40) return undefined;
    if (is_array(_marks)) array_resize(_marks, 0);
    var _ink = sng_ink(_song.ink);
    var _u = sng_unit(_w, _h);
    sng_paper(_x, _y, _w, _h, _ink, sng_hash(_song.song_id), _u);
    sng_furniture(_song, _x, _y, _w, _h, _ink, _u);
    // THE TITLE CARTOUCHE: the song's name in the display face, centred, between two engraved swashes, and the
    // tradition line under it in tracked capitals
    var _tpx = 17 * _u, _ty = _y + 17 * _u;
    var _reserve = (_song.furniture == "illuminated" || _song.furniture == "stamped" || _song.furniture == "tallied" || _song.furniture == "ruled") ? 62 * _u : 26 * _u;
    var _tw = sng_text(_x + _w / 2, _ty, _song.title, _tpx, _ink.line, fa_center, fa_top, fnt_songsheets_title, 1, _w - _reserve * 2 - 40 * _u);
    var _fl = min(46 * _u, (_w - _tw) / 2 - _reserve - 6 * _u);
    if (_fl > 10 * _u) {
        sng_flourish(_x + _w / 2 - _tw / 2 - 5 * _u, _ty + _tpx * 0.62, -1, _fl, _u, _ink.line);
        sng_flourish(_x + _w / 2 + _tw / 2 + 5 * _u, _ty + _tpx * 0.62, 1, _fl, _u, _ink.line);
    }
    var _sub = string_upper(_song.tradition_name) + "   " + string_upper(_song.mode) + "   " +
               ((_song.meter[0] > 0) ? string(_song.meter[0]) + "/" + string(_song.meter[1]) : "FREE");
    sng_text_tracked(_x + _w / 2, _ty + _tpx * 1.28, _sub, 7.5 * _u, 0.22, _ink.accent, fnt_songsheets, 0.9, _w - _reserve * 2);
    var _box = { x: _x + 24 * _u, y: _y + 60 * _u, w: _w - 48 * _u, h: _h - 78 * _u };
    var _lay = undefined;
    switch (_song.notation) {
        case "modern":   _lay = sng_layout("modern", _box.w, _box.h, array_length(_song.notes), _u);   sng_draw_modern(_song, _box, _ink, _lay, _marks); break;
        case "mensural": _lay = sng_layout("mensural", _box.w, _box.h, array_length(_song.notes), _u); sng_draw_mensural(_song, _box, _ink, _lay, _marks); break;
        case "neume":    _lay = sng_layout("neume", _box.w, _box.h, array_length(_song.notes), _u);    sng_draw_neume(_song, _box, _ink, _lay, _marks); break;
        case "spiral":   sng_draw_spiral(_song, _box, _ink, _u, _marks); break;
        default:         sng_draw_grid(_song, _box, _ink, _u, _marks); break;
    }
    return { system: _song.notation, notes: array_length(_song.notes), layout: _lay,
             fill: is_struct(_lay) ? _lay.fill : 1, box: _box, unit: _u };
}

/// @function sng_plate(song, w, h, [ss])
/// @description Render the plate ONCE, supersampled (`ss` times the size, default 2, then filtered down when
/// drawn), into a sprite you can draw every frame for the cost of one quad. Returns {sprite, w, h, ss, marks,
/// info, song} or undefined. Free it with sng_plate_free when done. ⭐ This is the path to use in a game: the
/// engraver draws hundreds of primitives, a plate sprite draws one.
function sng_plate(_song, _w, _h, _ss = 2) {
    if (!sng_is_song(_song) || !is_real(_w) || !is_real(_h)) return undefined;
    _w = clamp(floor(_w), 40, 4096); _h = clamp(floor(_h), 40, 4096);
    _ss = clamp(floor(is_real(_ss) ? _ss : 2), 1, 3);
    // a supersampled surface is w*ss by h*ss; above 4096 a side the memory (and a weak GPU's texture limit) is
    // not worth the smoothness, so a huge plate is drawn at 1x rather than refused
    while (_ss > 1 && (_w * _ss > 4096 || _h * _ss > 4096)) _ss--;
    var _sf = surface_create(_w * _ss, _h * _ss);
    if (!surface_exists(_sf)) return undefined;
    var _marks = [];
    surface_set_target(_sf);
    draw_clear_alpha(c_black, 0);
    var _info = sng_engrave(_song, 0, 0, _w * _ss, _h * _ss, _marks);
    // ⛔ FORCE THE ALPHA CHANNEL TO 1. The default blend writes srcA*srcA + dstA*(1-srcA) into a surface's
    // alpha, so every translucent stroke (laid lines, foxing, the playhead glow) would punch a partly
    // transparent hole through the opaque paper, and the sprite would show whatever is behind it there.
    gpu_set_colorwriteenable(false, false, false, true);
    sng_rect_fill(0, 0, _w * _ss, _h * _ss, c_white, 1);
    gpu_set_colorwriteenable(true, true, true, true);
    surface_reset_target();
    var _spr = sprite_create_from_surface(_sf, 0, 0, _w * _ss, _h * _ss, false, false, 0, 0);
    surface_free(_sf);
    for (var _i = 0; _i < array_length(_marks); _i++) { _marks[_i].x /= _ss; _marks[_i].y /= _ss; }
    return { sng_kind: "plate", sprite: _spr, w: _w, h: _h, ss: _ss, marks: _marks, info: _info, song: _song };
}

/// @function sng_is_plate(value)
/// @description True if value is a live plate from sng_plate. Pure.
function sng_is_plate(_p) {
    return is_struct(_p) && variable_struct_exists(_p, "sng_kind") && _p.sng_kind == "plate"
        && sprite_exists(_p.sprite);
}

/// @function sng_plate_draw(plate, x, y, [alpha], [scale])
/// @description Draw a plate with its top-left at (x, y), filtered down from its supersampled size.
function sng_plate_draw(_p, _x, _y, _alpha = 1, _scale = 1) {
    if (!sng_is_plate(_p) || !is_real(_x) || !is_real(_y)) return;
    var _prev = gpu_get_texfilter();
    gpu_set_texfilter(true);
    var _k = (is_real(_scale) ? _scale : 1) / _p.ss;
    draw_sprite_ext(_p.sprite, 0, _x, _y, _k, _k, 0, c_white, is_real(_alpha) ? _alpha : 1);
    gpu_set_texfilter(_prev);
}

/// @function sng_plate_free(plate)
/// @description Free a plate's sprite. Safe on anything.
function sng_plate_free(_p) {
    if (sng_is_plate(_p)) { sprite_delete(_p.sprite); _p.sng_kind = "freed"; }
}

/// @function sng_playhead_draw(plate, x, y, index, [colour], [scale])
/// @description Light the notehead that is sounding: a warm glow under a ring, in the plate's own coordinates
/// offset to (x, y). `index` is a note index (sng_playing_index), -1 draws nothing.
function sng_playhead_draw(_p, _x, _y, _index, _col = -1, _scale = 1) {
    if (!sng_is_plate(_p) || !is_real(_index) || _index < 0 || !is_real(_x) || !is_real(_y)) return;
    if (!is_real(_scale)) _scale = 1;
    var _ink = sng_ink(_p.song.ink);
    var _c = (is_real(_col) && _col >= 0) ? _col : _ink.accent;
    for (var _i = 0; _i < array_length(_p.marks); _i++) {
        var _m = _p.marks[_i];
        if (_m.i != _index) continue;
        var _u = is_struct(_p.info) ? _p.info.unit / _p.ss : 1;
        var _mx = _x + _m.x * _scale, _my = _y + _m.y * _scale, _r = max(6, 11 * _u) * _scale;
        sng_spot(_mx, _my, _r * 2.2, make_colour_rgb(255, 214, 120), 0.55);
        sng_ring(_mx, _my, _r, _r, 0, max(1.5, 1.6 * _u * _scale), _c, 0.9);
        return;
    }
}
