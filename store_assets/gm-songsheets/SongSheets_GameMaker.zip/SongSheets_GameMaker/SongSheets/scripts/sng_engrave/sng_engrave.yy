{
  "$GMScript": "v1",
  "%Name": "sng_engrave",
  "name": "sng_engrave",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}