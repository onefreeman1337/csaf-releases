/// sng_selftest.gml - the in-engine suite (`SongSheets.exe -selftest` writes sng_selftest.json, plus
/// sng_oracle.json and ten sng_wav_<tradition>.wav files that are checked OUTSIDE the engine).
///
/// Song Sheets - Every Song Engraved and Played, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Stage 99 = the suite reached its end.
///
/// ⚠️ GML applies an epsilon of 0.00001 to every numeric comparison, so NOTHING here compares two reals with a
/// tolerance below it: generator draws are compared as exact 32-bit INTEGERS (draw * 2^32), and every
/// threshold is either an integer count or well above 1e-4. A suite green on its first run has not proven it
/// can go red - every threshold below carries a control.

function sng_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 60) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
function sng_st_stage(_st, _n) { _st.stage = _n; global.sng_stage = _n; }
function sng_st_note(_st, _s) { array_push(_st.notes, _s); }

/// @function sng_st_ink(surface, w, h, ground, [threshold])
/// @description Count pixels darker than the paper by more than `threshold` levels (default 70), every row,
/// every second column. The notation is dark ink on pale paper, so this separates it from the laid lines and
/// foxing, which are deliberately faint.
function sng_st_ink(_sf, _w, _h, _ground, _thr = 70) {
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    var _gl = (colour_get_red(_ground) + colour_get_green(_ground) + colour_get_blue(_ground)) / 3, _n = 0;
    for (var _y = 0; _y < _h; _y++) for (var _x = 0; _x < _w; _x += 2) {
        var _o = (_y * _w + _x) * 4;
        var _l = (buffer_peek(_b, _o, buffer_u8) + buffer_peek(_b, _o + 1, buffer_u8) + buffer_peek(_b, _o + 2, buffer_u8)) / 3;
        if (_gl - _l > _thr) _n++;
    }
    buffer_delete(_b);
    return _n;
}

/// @function sng_st_bright(surface, w, h, level)
/// @description Count samples (every row, every second column) whose average channel is above `level`.
function sng_st_bright(_sf, _w, _h, _lv) {
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    var _n = 0;
    for (var _y = 0; _y < _h; _y++) for (var _x = 0; _x < _w; _x += 2) {
        var _o = (_y * _w + _x) * 4;
        if ((buffer_peek(_b, _o, buffer_u8) + buffer_peek(_b, _o + 1, buffer_u8) + buffer_peek(_b, _o + 2, buffer_u8)) / 3 > _lv) _n++;
    }
    buffer_delete(_b);
    return _n;
}

/// @function sng_st_grid(surface, w, h, ground, cols, rows)
/// @description A coarse ink-occupancy signature of a plate: a cols x rows grid, each cell 1 if more than 4% of
/// its sampled pixels are ink. Two plates that LOOK different have different grids; this is the volume check's
/// instrument, measured on the drawn pixels rather than on the song data.
function sng_st_grid(_sf, _w, _h, _ground, _cols, _rows) {
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    var _gl = (colour_get_red(_ground) + colour_get_green(_ground) + colour_get_blue(_ground)) / 3;
    var _cw = _w / _cols, _ch = _h / _rows, _sig = "";
    for (var _r = 0; _r < _rows; _r++) for (var _c = 0; _c < _cols; _c++) {
        var _hit = 0, _tot = 0;
        for (var _y = floor(_r * _ch); _y < floor((_r + 1) * _ch); _y += 2) for (var _x = floor(_c * _cw); _x < floor((_c + 1) * _cw); _x += 2) {
            var _o = (_y * _w + _x) * 4;
            var _l = (buffer_peek(_b, _o, buffer_u8) + buffer_peek(_b, _o + 1, buffer_u8) + buffer_peek(_b, _o + 2, buffer_u8)) / 3;
            _tot++;
            if (_gl - _l > 70) _hit++;
        }
        _sig += (_hit * 25 > _tot) ? "1" : "0";
    }
    buffer_delete(_b);
    return _sig;
}

/// @function sng_st_grid_rect(surface, sw, ground, x, y, w, h, cols, rows)
/// @description sng_st_grid restricted to a rectangle of the surface (`sw` = the surface's width).
function sng_st_grid_rect(_sf, _sw, _ground, _rx, _ry, _rw, _rh, _cols, _rows) {
    var _sh = surface_get_height(_sf);
    var _b = buffer_create(_sw * _sh * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    var _gl = (colour_get_red(_ground) + colour_get_green(_ground) + colour_get_blue(_ground)) / 3;
    var _cw = _rw / _cols, _ch = _rh / _rows, _sig = "";
    for (var _r = 0; _r < _rows; _r++) for (var _c = 0; _c < _cols; _c++) {
        var _hit = 0, _tot = 0;
        for (var _y = floor(_ry + _r * _ch); _y < floor(_ry + (_r + 1) * _ch); _y++) for (var _x = floor(_rx + _c * _cw); _x < floor(_rx + (_c + 1) * _cw); _x += 2) {
            var _o = (_y * _sw + _x) * 4;
            var _l = (buffer_peek(_b, _o, buffer_u8) + buffer_peek(_b, _o + 1, buffer_u8) + buffer_peek(_b, _o + 2, buffer_u8)) / 3;
            _tot++;
            if (_gl - _l > 70) _hit++;
        }
        // ⛔ FOUR LEVELS, NOT ONE BIT. On a five-line stave every cell already holds a stave line, so a 1-bit
        // "any ink" grid saturated and measured the STAVES - two different hymns read 3 cells apart. A stave line
        // alone is a thin fraction of a cell; a notehead, beam or neume is a thick one, and the levels separate them.
        var _fr = (_tot > 0) ? _hit / _tot : 0;
        _sig += (_fr < 0.03) ? "0" : ((_fr < 0.12) ? "1" : ((_fr < 0.30) ? "2" : "3"));
    }
    buffer_delete(_b);
    return _sig;
}

/// @function sng_st_hamming(a, b)
/// @description Number of positions at which two equal-length signatures differ. Pure.
function sng_st_hamming(_a, _b) {
    var _d = 0;
    for (var _i = 1; _i <= string_length(_a); _i++) if (string_char_at(_a, _i) != string_char_at(_b, _i)) _d++;
    return _d;
}

function sng_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, failures: [], stage: 0, notes: [] };
    var _T = sng_traditions(), _i, _j, _t;

    sng_st_stage(_st, 1);    // the hash and the generator, against values computed by the shipped JavaScript
    sng_st_assert(_st, sng_hash("") == 2166136261, "hash of the empty string is the FNV offset basis");
    sng_st_assert(_st, sng_hash("a") == 3826002220, "hash('a') matches the MZ plugin: " + string(sng_hash("a")));
    sng_st_assert(_st, sng_hash("millers-daughter|folk") == 1429104553, "hash of a seed string matches the MZ plugin: " + string(sng_hash("millers-daughter|folk")));
    sng_st_assert(_st, sng_hash("The quick brown fox jumps over the lazy dog") == 2552316936, "a 43-character hash matches the MZ plugin (the double-precision multiply is kept): " + string(sng_hash("The quick brown fox jumps over the lazy dog")));
    var _g = sng_rng(1429104553);
    var _d1 = floor(sng_rng_next(_g) * SNG_U32), _d2 = floor(sng_rng_next(_g) * SNG_U32), _d3 = floor(sng_rng_next(_g) * SNG_U32);
    sng_st_assert(_st, _d1 == 88102477 && _d2 == 2472777561 && _d3 == 4137388435, "the first three mulberry32 draws match the MZ plugin exactly: " + string(_d1) + " " + string(_d2) + " " + string(_d3));
    var _g0 = sng_rng(0);
    var _z1 = floor(sng_rng_next(_g0) * SNG_U32), _z2 = floor(sng_rng_next(_g0) * SNG_U32);
    sng_st_assert(_st, _z1 == 1144304738 && _z2 == 1416247, "seed 0 draws match the MZ plugin: " + string(_z1) + " " + string(_z2));
    var _md = sng_song("millers-daughter", "folk");
    var _mp = "", _mdur = "";
    for (_i = 0; _i < array_length(_md.notes); _i++) { _mp += ((_i > 0) ? "," : "") + string(_md.notes[_i].pitch); _mdur += ((_i > 0) ? "," : "") + string(_md.notes[_i].dur); }
    sng_st_assert(_st, _mp == "66,72,71,67,66,67,71,69,72,74,71,66,67,62", "The Miller's Daughter has the MZ plugin's pitches: " + _mp);
    sng_st_assert(_st, _mdur == "4,2,2,4,4,2,4,4,2,4,2,2,2,4", "and its durations: " + _mdur);

    sng_st_stage(_st, 2);    // every tradition, swept over many ids
    var _floor_distinct = 99, _floor_trad = "";
    for (_t = 0; _t < array_length(_T); _t++) {
        var _D = sng_tradition(_T[_t]);
        var _modes = sng_modes()[$ _D.mode];
        var _bad_range = 0, _bad_mode = 0, _bad_len = 0, _bad_sum = 0, _min_d = 99;
        for (_j = 0; _j < 60; _j++) {
            var _s = sng_song("sweep-" + string(_j), _T[_t]);
            var _n = array_length(_s.notes), _sum = 0, _seen = {}, _dist = 0;
            if (_n < 14 || _n > 19) _bad_len++;
            for (_i = 0; _i < _n; _i++) {
                var _p = _s.notes[_i].pitch;
                if (_p < _D.range[0] || _p > _D.range[1]) _bad_range++;
                var _pc = (((_p - _s.tonic) mod 12) + 12) mod 12, _in = false;
                for (var _k = 0; _k < 7; _k++) if (_modes[_k] == _pc) _in = true;
                if (!_in) _bad_mode++;
                if (!variable_struct_exists(_seen, string(_p))) { _seen[$ string(_p)] = 1; _dist++; }
                _sum += _s.notes[_i].dur;
            }
            if (_sum != _s.total_sixteenths) _bad_sum++;
            _min_d = min(_min_d, _dist);
        }
        sng_st_assert(_st, _bad_len == 0, _T[_t] + ": every song has 14-19 notes");
        sng_st_assert(_st, _bad_range == 0, _T[_t] + ": every pitch inside the tradition's range (" + string(_bad_range) + " outside)");
        sng_st_assert(_st, _bad_mode == 0, _T[_t] + ": every pitch belongs to the " + _D.mode + " mode (" + string(_bad_mode) + " outside)");
        sng_st_assert(_st, _bad_sum == 0, _T[_t] + ": total_sixteenths is the sum of the durations");
        sng_st_note(_st, _T[_t] + " min distinct pitches over 60 songs: " + string(_min_d));
        if (_min_d < _floor_distinct) { _floor_distinct = _min_d; _floor_trad = _T[_t]; }
    }
    // ⛔ the MINIMUM, never the mean: a run is what independent draws produce, and a mean never shows it
    sng_st_assert(_st, _floor_distinct >= 3, "no song in the sweep collapses below 3 distinct pitches (floor " + string(_floor_distinct) + " in " + _floor_trad + ")");
    // structural properties, one per construction
    var _pal_ok = 0, _ref_ok = 0, _fan_ok = 0, _round_ok = 0, _chant_ok = 0, _hymn_ok = 0;
    for (_j = 0; _j < 40; _j++) {
        var _sp = sng_song("s" + string(_j), "spell"), _m = array_length(_sp.notes), _pal = true;
        for (_i = 0; _i < _m; _i++) if (_sp.notes[_i].pitch != _sp.notes[_m - 1 - _i].pitch || _sp.notes[_i].dur != _sp.notes[_m - 1 - _i].dur) _pal = false;
        if (_pal) _pal_ok++;
        var _sea = sng_song("s" + string(_j), "sea"), _has = false;
        for (_i = 0; _i + 3 < array_length(_sea.notes); _i++) if (_sea.notes[_i].degree == 4 && _sea.notes[_i + 1].degree == 2 && _sea.notes[_i + 2].degree == 1 && _sea.notes[_i + 3].degree == 0) _has = true;
        if (_has) _ref_ok++;
        var _fa = sng_song("s" + string(_j), "martial"), _fm = array_length(_fa.notes);
        if (_fa.notes[_fm - 2].degree == 4 && _fa.notes[_fm - 1].degree == 0) _fan_ok++;
        var _fe = sng_song("s" + string(_j), "fae"), _fem = array_length(_fe.notes);
        if (abs(_fe.notes[_fem - 1].degree - _fe.notes[0].degree) == 1) _round_ok++;
        var _ch = sng_song("s" + string(_j), "chant"), _cm = array_length(_ch.notes);
        if (_ch.notes[_cm - 2].degree == 1 && _ch.notes[_cm - 1].degree == 0) _chant_ok++;
        var _hy = sng_song("s" + string(_j), "hymn");
        if (_hy.notes[array_length(_hy.notes) - 1].degree == 0) _hymn_ok++;
    }
    sng_st_assert(_st, _pal_ok == 40, "every incantation reads the same backwards, pitches AND rhythm: " + string(_pal_ok) + "/40");
    sng_st_assert(_st, _ref_ok == 40, "every shanty carries its literal crew refrain: " + string(_ref_ok) + "/40");
    sng_st_assert(_st, _fan_ok == 40, "every muster call resolves fifth-to-tonic: " + string(_fan_ok) + "/40");
    sng_st_assert(_st, _round_ok == 40, "every fae round ends a step from where it began: " + string(_round_ok) + "/40");
    sng_st_assert(_st, _chant_ok == 40 && _hymn_ok == 40, "chant cadences to the final, hymns end on the tonic");
    // the ten constructions are genuinely different: one id through all ten gives ten different interval traces
    var _traces = {}, _tdist = 0;
    for (_t = 0; _t < array_length(_T); _t++) {
        var _tt = sng_song("same-id", _T[_t]), _tr = "";
        for (_i = 1; _i < array_length(_tt.notes); _i++) _tr += string(_tt.notes[_i].degree - _tt.notes[_i - 1].degree) + ",";
        if (!variable_struct_exists(_traces, _tr)) { _traces[$ _tr] = 1; _tdist++; }
    }
    sng_st_assert(_st, _tdist == 10, "one id through ten traditions gives ten different interval traces: " + string(_tdist));
    // determinism and the control
    var _a = sng_song("determinism", "hymn"), _b = sng_song("determinism", "hymn"), _c = sng_song("determinism-2", "hymn"), _same = true, _diff = false;
    for (_i = 0; _i < array_length(_a.notes); _i++) if (_a.notes[_i].pitch != _b.notes[_i].pitch || _a.notes[_i].dur != _b.notes[_i].dur) _same = false;
    for (_i = 0; _i < min(array_length(_a.notes), array_length(_c.notes)); _i++) if (_a.notes[_i].pitch != _c.notes[_i].pitch) _diff = true;
    sng_st_assert(_st, _same, "the same id is the same melody, every time");
    sng_st_assert(_st, _diff || array_length(_a.notes) != array_length(_c.notes), "control: a different id is a different melody");
    var _fb = sng_song("x", "no-such-tradition");
    sng_st_assert(_st, _fb.tradition == "folk" && _fb.fallback, "an unknown tradition falls back to folk and SAYS so");
    // SPELLING: one letter per degree, the accidentals a musician expects, and the signature that follows from them
    var _mx = sng_spelling(62, "mixolydian"), _ph2 = sng_spelling(62, "phrygian"), _io = sng_spelling(62, "ionian");
    sng_st_assert(_st, _mx.sharps == 1 && _mx.flats == 0 && _mx.letter[6] == 3 && _mx.acc[6] == 1, "D mixolydian: one sharp, and pitch class 6 is F-SHARP (letter F, +1), never G-flat or F-flat");
    sng_st_assert(_st, _ph2.flats == 2 && _ph2.sharps == 0 && _ph2.letter[3] == 2 && _ph2.acc[3] == -1 && _ph2.letter[10] == 6 && _ph2.acc[10] == -1, "D phrygian: two flats, E-flat on the E line and B-flat on the B line");
    sng_st_assert(_st, _io.sharps == 2 && sng_spelling(62, "dorian").sharps + sng_spelling(62, "dorian").flats == 0, "D ionian carries two sharps; D dorian carries none");
    sng_st_assert(_st, sng_spelling(62, "lydian").sharps == 3 && sng_spelling(62, "locrian").flats == 3 && sng_spelling(62, "aeolian").flats == 1, "D lydian 3 sharps, D locrian 3 flats, D aeolian 1 flat");
    sng_st_assert(_st, sng_spelled_step(66, _mx) == sng_staff_step(65) && sng_spelled_step(63, _ph2) == sng_staff_step(64), "F-sharp is drawn on the F position; E-flat on the E position");
    // across every tradition and three tonics, every note spells to a letter whose natural lies within a semitone
    var _spell_bad = 0, _spell_n = 0, _TON = [62, 55, 67];
    for (_t = 0; _t < array_length(_T); _t++) for (var _to2 = 0; _to2 < 3; _to2++) {
        var _sg2 = sng_song("spell-" + string(_to2), _T[_t], _TON[_to2]), _spg = sng_spelling(_sg2.tonic, _sg2.mode);
        for (_i = 0; _i < array_length(_sg2.notes); _i++) {
            var _pc2 = ((_sg2.notes[_i].pitch mod 12) + 12) mod 12;
            _spell_n++;
            if (_spg.letter[_pc2] < 0 || abs(_spg.acc[_pc2]) > 1) _spell_bad++;
        }
    }
    sng_st_assert(_st, _spell_n > 400 && _spell_bad == 0, "every note of every tradition at three tonics has a letter and at most one accidental (" + string(_spell_bad) + " of " + string(_spell_n) + " not)");
    var _tp = sng_song("x", "hymn", 67);
    sng_st_assert(_st, _tp.tonic == 67 && sng_song("x", "hymn", "not a number").tonic == 62, "a tonic is honoured; a non-number falls back to 62");
    // titles: generated, deterministic, printable ASCII (the shipped fonts hold 32..126 only), and varied
    var _titles = {}, _tdn = 0, _ascii = true;
    for (_t = 0; _t < array_length(_T); _t++) for (_j = 0; _j < 6; _j++) {
        var _ti = sng_title("t" + string(_j), _T[_t]);
        for (_i = 1; _i <= string_length(_ti); _i++) { var _o = ord(string_char_at(_ti, _i)); if (_o < 32 || _o > 126) _ascii = false; }
        if (!variable_struct_exists(_titles, _ti)) { _titles[$ _ti] = 1; _tdn++; }
    }
    sng_st_note(_st, "60 generated titles, " + string(_tdn) + " distinct");
    sng_st_assert(_st, _ascii, "every generated title is printable ASCII");
    sng_st_assert(_st, _tdn >= 50, "generated titles vary: " + string(_tdn) + " distinct of 60");
    sng_st_assert(_st, sng_title("q", "folk") == sng_title("q", "folk") && sng_song("q", "folk").title == sng_title("q", "folk"), "a title is deterministic and is what an unnamed song prints");
    sng_st_assert(_st, sng_song("q", "folk", 62, "My Own Name").title == "My Own Name", "an author's title is kept");

    sng_st_stage(_st, 3);    // the schedule, the playhead and the synthesiser
    var _ss = sng_song("millers-daughter", "folk"), _sch = sng_schedule(_ss);
    sng_st_assert(_st, array_length(_sch) == array_length(_ss.notes), "one schedule event per note");
    var _mono = true, _hits = 0;
    for (_i = 1; _i < array_length(_sch); _i++) if (_sch[_i].at <= _sch[_i - 1].at) _mono = false;
    for (_i = 0; _i < array_length(_sch); _i++) if (sng_note_at(_sch, _sch[_i].at + _sch[_i].dur * 0.5) == _i) _hits++;
    sng_st_assert(_st, _mono, "onsets strictly increase");
    sng_st_assert(_st, _hits == array_length(_sch), "the playhead finds every note at its own midpoint: " + string(_hits) + "/" + string(array_length(_sch)));
    sng_st_assert(_st, sng_note_at(_sch, -1) == -1 && sng_note_at(_sch, sng_duration(_ss) + 1) == -1, "before the first note and after the last, nothing is lit");
    sng_st_assert(_st, sng_note_at(undefined, 1) == -1 && array_length(sng_schedule(undefined)) == 0, "a non-song schedules nothing and lights nothing");
    var _worst_ms = 0, _worst_t = "", _quiet = 0, _wav_ok = 0;
    for (_t = 0; _t < array_length(_T); _t++) {
        var _song = sng_song("audio-" + _T[_t], _T[_t]);
        var _t0 = get_timer();
        var _r = sng_render(_song);
        var _ms = (get_timer() - _t0) / 1000;
        if (_ms > _worst_ms) { _worst_ms = _ms; _worst_t = _T[_t]; }
        sng_st_assert(_st, is_struct(_r) && _r.samples == ceil((sng_duration(_song) + SNG_TAIL) * _r.rate), _T[_t] + ": the buffer is exactly as long as the song plus its tail");
        sng_st_assert(_st, _r.peak > 0.05 && _r.peak <= 1, _T[_t] + ": the render is audible and does not clip (peak " + string_format(_r.peak, 1, 3) + ")");
        // every note must SOUND: the RMS inside each note's own window, from the buffer the speakers get
        var _s2 = sng_schedule(_song);
        for (_i = 0; _i < array_length(_s2); _i++) {
            var _a0 = floor(_s2[_i].at * _r.rate), _a1 = min(_r.samples, floor((_s2[_i].at + max(0.03, _s2[_i].dur * 0.5)) * _r.rate)), _acc = 0;
            for (var _q = _a0; _q < _a1; _q++) { var _v = buffer_peek(_r.buffer, _q * 2, buffer_s16) / 32767; _acc += _v * _v; }
            if (sqrt(_acc / max(1, _a1 - _a0)) < 0.01) _quiet++;
        }
        buffer_delete(_r.buffer);
        var _bytes = sng_save_wav(_song, "sng_wav_" + _T[_t] + ".wav");
        if (_bytes == 44 + _r.samples * 2) _wav_ok++;
        sng_st_note(_st, _T[_t] + " render " + string_format(_ms, 1, 1) + " ms for " + string_format(_r.seconds, 1, 2) + " s of audio");
    }
    sng_st_assert(_st, _quiet == 0, "every note of every tradition is audible in its own window (" + string(_quiet) + " silent)");
    sng_st_assert(_st, _wav_ok == 10, "ten WAV files written at exactly header + samples bytes: " + string(_wav_ok));
    sng_st_note(_st, "slowest render " + string_format(_worst_ms, 1, 1) + " ms (" + _worst_t + ")");
    // a control for the audibility check: a buffer of zeros must read as silent
    var _zb = buffer_create(2000, buffer_fixed, 2), _zacc = 0;
    buffer_fill(_zb, 0, buffer_s16, 0, 2000);
    for (_i = 0; _i < 1000; _i++) { var _zv = buffer_peek(_zb, _i * 2, buffer_s16) / 32767; _zacc += _zv * _zv; }
    buffer_delete(_zb);
    sng_st_assert(_st, sqrt(_zacc / 1000) < 0.01, "control: a silent buffer reads silent to the same check");
    // ⭐ STREAMING IS EXACT: the song rendered chunk by chunk (as sng_play streams it) is byte-identical to the song
    // rendered in one piece - the synthesis is stateless per sample, and this is the assertion that says so
    var _cs = sng_song("chunk-test", "courtly"), _plan = sng_voice_plan(_cs, SNG_RATE);
    var _whole = sng_render(_cs), _parts = buffer_create(_plan.total * 2, buffer_fixed, 2);
    for (var _cc = 0; _cc < _plan.total; _cc += SNG_CHUNK) sng_render_into(_plan, _cc, min(_plan.total, _cc + SNG_CHUNK), _parts, _cc * 2);
    var _m1 = buffer_md5(_whole.buffer, 0, _whole.bytes), _m2 = buffer_md5(_parts, 0, _plan.total * 2);
    sng_st_assert(_st, _m1 == _m2 && _plan.total > SNG_CHUNK * 4, "a song streamed in " + string(ceil(_plan.total / SNG_CHUNK)) + " chunks is byte-identical to the same song rendered whole");
    // control: a chunk boundary off by one sample is NOT identical, so the md5 comparison can go red
    buffer_poke(_parts, SNG_CHUNK * 2 + 2, buffer_s16, buffer_peek(_parts, SNG_CHUNK * 2 + 2, buffer_s16) + 1);
    sng_st_assert(_st, buffer_md5(_parts, 0, _plan.total * 2) != _m1, "control: one changed sample changes the digest");
    buffer_delete(_parts); buffer_delete(_whole.buffer);
    // the streaming player: play starts after a small render, update keeps rendering, a heard song replays instantly
    var _tp0 = get_timer();
    var _inst = sng_play(_ss);
    var _play_ms = (get_timer() - _tp0) / 1000;
    sng_st_note(_st, "sng_play started in " + string_format(_play_ms, 1, 1) + " ms (instance " + string(_inst) + ")");
    sng_st_assert(_st, _play_ms < 120, "play starts without rendering the whole song first (" + string_format(_play_ms, 1, 1) + " ms)");
    var _job = sng_audio_cache().job, _n0 = is_struct(_job) ? _job.next : -1;
    sng_st_assert(_st, is_struct(_job) && _n0 > 0 && _n0 < _job.plan.total, "after play, the rest of the song is still to render (" + string(_n0) + " samples done)");
    // simulate the playback clock running 30 s on, so update is allowed to render ahead
    sng_audio_cache().t0 -= 30000000;
    var _guard = 0;
    while (sng_update(50) && _guard++ < 400) { }
    sng_st_assert(_st, sng_audio_cache().job == undefined && variable_struct_exists(sng_audio_cache().done, sng_song_key(_ss)), "update finishes the render and caches the song (" + string(_guard) + " calls)");
    sng_stop();
    var _tp1 = get_timer();
    sng_play(_ss);
    var _replay_ms = (get_timer() - _tp1) / 1000;
    sng_st_assert(_st, sng_audio_cache().job == undefined, "a song heard in full replays with no render job at all (" + string_format(_replay_ms, 1, 2) + " ms)");
    sng_stop();
    var _pp = sng_song("prepare-me", "lament"), _prog = 0, _pg = 0;
    while (_prog < 1 && _pg++ < 500) _prog = sng_prepare(_pp, 20);
    sng_st_assert(_st, _prog == 1 && variable_struct_exists(sng_audio_cache().done, sng_song_key(_pp)), "prepare renders a song into the cache in slices (" + string(_pg) + " calls)");
    sng_st_assert(_st, sng_play(undefined) == -1 && sng_prepare("x") == 0, "refusals: play and prepare on a non-song");
    sng_audio_free();
    sng_st_assert(_st, variable_struct_names_count(sng_audio_cache().done) == 0 && !sng_is_playing(), "audio_free empties the cache and stops");

    sng_st_stage(_st, 4);    // the layout solver, swept
    // swept over PLATE sizes, with the box and unit derived exactly as sng_engrave derives them - the first version
    // swept bare boxes with no unit, which is a different question from the one a plate asks
    var _cases = 0, _over = 0, _crowd = 0, _feas = 0, _plates = 0, _hist = array_create(10, 0), _worstfill = 1, _worstcase = "";
    var _K = ["modern", "mensural", "neume"];
    for (var _kk = 0; _kk < 3; _kk++) for (var _w = 300; _w <= 1900; _w += 160) for (var _h = 200; _h <= 1300; _h += 110) for (var _nn = 14; _nn <= 19; _nn += 5) {
        var _uu = sng_unit(_w, _h);
        var _bw = _w - 48 * _uu, _bh = _h - 78 * _uu;
        var _L = sng_layout(_K[_kk], _bw, _bh, _nn, _uu), _P = sng_profile(_K[_kk]);
        _cases++;
        if (_L.feasible) {
            _feas++;
            if (_L.used_h > _bh * 1.02) _over++;
            if (_L.adv_ratio < _P.collide) _crowd++;
            // "plate size" = the aspect range a sheet is actually shown at (portrait to 2.4:1 landscape)
            if (_w / _h >= 0.6 && _w / _h <= 2.4) {
                _plates++;
                _hist[min(9, floor(_L.fill * 10))]++;
                if (_L.fill < _worstfill) { _worstfill = _L.fill; _worstcase = _K[_kk] + " " + string(_w) + "x" + string(_h) + " n" + string(_nn); }
            }
        }
    }
    var _hs = "";
    for (_i = 0; _i < 10; _i++) _hs += string(_i * 10) + "%:" + string(_hist[_i]) + " ";
    sng_st_note(_st, "layout sweep: " + string(_cases) + " cases, " + string(_feas) + " feasible, " + string(_plates) + " at plate aspect; fill histogram " + _hs + "; worst " + string_format(_worstfill, 1, 2) + " (" + _worstcase + ")");
    sng_st_assert(_st, _feas > _cases / 2, "the sweep is not vacuous: most cases are feasible (" + string(_feas) + "/" + string(_cases) + ")");
    sng_st_assert(_st, _over == 0, "no feasible layout overruns its box (" + string(_over) + ")");
    sng_st_assert(_st, _crowd == 0, "no feasible layout overlaps its noteheads (" + string(_crowd) + ")");
    sng_st_assert(_st, _plates > 0 && _worstfill >= 0.5, "at plate aspect the notation fills at least half the box (worst " + string_format(_worstfill, 1, 2) + ", " + _worstcase + ")");
    // control: WITHOUT the unit (the shipped defect) a large neume plate does under-fill, so the check can see it
    var _bad = sng_layout("neume", 1600 - 48 * 3.4, 1240 - 78 * 3.4, 16, 1);
    sng_st_assert(_st, _bad.fill < 0.5, "control: the unitless layout of a large chant plate under-fills (" + string_format(_bad.fill, 1, 2) + ")");

    sng_st_stage(_st, 5);    // the drawn plates: ink, marks, containment, distinctness
    var _pw = 940, _ph = 400, _sf = surface_create(_pw, _ph);
    var _ink_min = 999999999, _ink_min_t = "", _mark_bad = 0;
    for (_t = 0; _t < array_length(_T); _t++) {
        var _so = sng_song("plate-" + _T[_t], _T[_t]), _marks = [];
        surface_set_target(_sf); draw_clear(c_black);
        var _info = sng_engrave(_so, 0, 0, _pw, _ph, _marks);
        surface_reset_target();
        var _ink = sng_st_ink(_sf, _pw, _ph, sng_ink(_so.ink).paper);
        if (_ink < _ink_min) { _ink_min = _ink; _ink_min_t = _T[_t]; }
        sng_st_assert(_st, is_struct(_info) && _info.system == _so.notation, _T[_t] + ": engraved in its own system (" + _so.notation + ")");
        sng_st_assert(_st, array_length(_marks) == array_length(_so.notes), _T[_t] + ": one notehead mark per note (" + string(array_length(_marks)) + "/" + string(array_length(_so.notes)) + ")");
        for (_i = 0; _i < array_length(_marks); _i++) {
            var _mk = _marks[_i];
            if (_mk.x < _info.box.x - 2 || _mk.x > _info.box.x + _info.box.w + 2 || _mk.y < _info.box.y - 40 || _mk.y > _info.box.y + _info.box.h + 40) _mark_bad++;
        }
    }
    sng_st_assert(_st, _mark_bad == 0, "every notehead lies inside its plate's content box (" + string(_mark_bad) + " outside)");
    // the ink floor, with its control: bare paper must read as (almost) no ink to the same instrument
    surface_set_target(_sf); draw_clear(c_black);
    sng_paper(0, 0, _pw, _ph, sng_ink("iron"), 1234, 2);
    surface_reset_target();
    var _bare = sng_st_ink(_sf, _pw, _ph, sng_ink("iron").paper);
    sng_st_note(_st, "ink: thinnest plate " + string(_ink_min) + " px (" + _ink_min_t + "), bare paper " + string(_bare) + " px");
    sng_st_assert(_st, _bare < 400, "control: bare paper is not ink to the ink counter (" + string(_bare) + ")");
    sng_st_assert(_st, _ink_min > _bare * 10 && _ink_min > 4000, "every tradition's plate carries real notation ink (thinnest " + string(_ink_min) + ")");
    // VOLUME, measured on the PICTURES: 40 songs, 4 of each tradition, as 40 coarse ink grids
    var _sigs = [], _fine = [], _seen2 = {}, _dsig = 0, _mind = 999, _minpair = "", _fmin = 99999, _fpair = "";
    for (_j = 0; _j < 40; _j++) {
        var _sv = sng_song("wall-" + string(_j), _T[_j mod 10]);
        surface_set_target(_sf); draw_clear(c_black);
        var _inf = sng_engrave(_sv, 0, 0, _pw, _ph);
        surface_reset_target();
        var _sg = sng_st_grid(_sf, _pw, _ph, sng_ink(_sv.ink).paper, 32, 12);
        array_push(_sigs, _sg);
        // ⚠️ the NOTATION box only, at a finer grid: two plates of one tradition share their furniture and page
        // layout by design, so a whole-plate coarse grid mostly measures what they SHARE (the first run read two
        // chant plates as 2 cells of 384 apart). The music is what must differ, so that is where this looks.
        array_push(_fine, sng_st_grid_rect(_sf, _pw, sng_ink(_sv.ink).paper, _inf.box.x, _inf.box.y, _inf.box.w, _inf.box.h, 64, 24));
        if (!variable_struct_exists(_seen2, _sg)) { _seen2[$ _sg] = 1; _dsig++; }
    }
    var _within = "";
    for (_i = 0; _i < 40; _i++) for (_j = _i + 1; _j < 40; _j++) {
        var _hd = sng_st_hamming(_sigs[_i], _sigs[_j]);
        if (_hd < _mind) { _mind = _hd; _minpair = string(_i) + "-" + string(_j); }
        if ((_i mod 10) == (_j mod 10)) {
            var _fd = sng_st_hamming(_fine[_i], _fine[_j]);
            if (_fd < _fmin) { _fmin = _fd; _fpair = string(_i) + "-" + string(_j) + " (" + _T[_i mod 10] + ")"; }
        }
    }
    for (_t = 0; _t < 10; _t++) {
        var _tm = 99999;
        for (_i = _t; _i < 40; _i += 10) for (_j = _i + 10; _j < 40; _j += 10) _tm = min(_tm, sng_st_hamming(_fine[_i], _fine[_j]));
        _within += _T[_t] + ":" + string(_tm) + " ";
    }
    sng_st_note(_st, "40 plates: " + string(_dsig) + " distinct whole-plate grids (closest " + _minpair + " at " + string(_mind) + "/384); notation-box grids, closest same-tradition pair " + _fpair + " at " + string(_fmin) + "/1536; per tradition " + _within);
    sng_st_assert(_st, _dsig == 40, "forty songs engrave as forty different pictures (" + string(_dsig) + " distinct)");
    // THE BAR IS MEASURED, NOT CHOSEN: a near-copy is defined as a plate with ONE note moved. Every real pair of
    // same-tradition plates must differ by more than that, or two songs in a player's book look like one edited.
    var _one = sng_song("wall-6", "hymn"), _edit = sng_song("wall-6", "hymn");
    _edit.notes[5].pitch += 4; _edit.notes[5].degree += 2;
    surface_set_target(_sf); draw_clear(c_black); var _i1 = sng_engrave(_one, 0, 0, _pw, _ph); surface_reset_target();
    var _g1 = sng_st_grid_rect(_sf, _pw, sng_ink(_one.ink).paper, _i1.box.x, _i1.box.y, _i1.box.w, _i1.box.h, 64, 24);
    surface_set_target(_sf); draw_clear(c_black); sng_engrave(_edit, 0, 0, _pw, _ph); surface_reset_target();
    var _g2 = sng_st_grid_rect(_sf, _pw, sng_ink(_edit.ink).paper, _i1.box.x, _i1.box.y, _i1.box.w, _i1.box.h, 64, 24);
    var _d_one = sng_st_hamming(_g1, _g2);
    sng_st_note(_st, "near-copy control: one note moved a third reads " + string(_d_one) + " cells");
    sng_st_assert(_st, _d_one > 0, "control: the instrument can see ONE moved note (" + string(_d_one) + " cells)");
    sng_st_assert(_st, _fmin > _d_one, "every same-tradition pair differs by more than a one-note edit (closest " + string(_fmin) + " vs " + string(_d_one) + ")");
    // control for the distinctness instrument: the same song twice gives the SAME grid
    var _ctl = sng_song("wall-0", "chant");
    surface_set_target(_sf); draw_clear(c_black); sng_engrave(_ctl, 0, 0, _pw, _ph); surface_reset_target();
    sng_st_assert(_st, sng_st_grid(_sf, _pw, _ph, sng_ink(_ctl.ink).paper, 32, 12) == _sigs[0], "control: the same song engraves the same grid twice");
    surface_free(_sf);
    // the supersampled plate
    var _pl = sng_plate(sng_song("plate-test", "hymn"), 600, 420, 2);
    sng_st_assert(_st, sng_is_plate(_pl) && sprite_get_width(_pl.sprite) == 1200 && sprite_get_height(_pl.sprite) == 840, "a plate sprite is rendered at twice its size");
    var _okm = true;
    for (_i = 0; _i < array_length(_pl.marks); _i++) if (_pl.marks[_i].x < 0 || _pl.marks[_i].x > 600 || _pl.marks[_i].y < 0 || _pl.marks[_i].y > 420) _okm = false;
    sng_st_assert(_st, _okm && array_length(_pl.marks) == array_length(_pl.song.notes), "a plate's marks are in its DISPLAY coordinates");
    sng_plate_free(_pl);
    sng_st_assert(_st, !sng_is_plate(_pl), "a freed plate is no longer a plate");
    sng_st_assert(_st, sng_engrave(undefined, 0, 0, 100, 100) == undefined && sng_engrave(_ctl, 0, 0, 10, 10) == undefined && sng_plate("x", 100, 100) == undefined, "refusals: a non-song, a rect too small, a string");

    sng_st_stage(_st, 6);    // the book
    var _bk = sng_book_create();
    sng_book_learn(_bk, "a", "chant"); sng_book_learn(_bk, "b", "fae", "Named"); sng_book_learn(_bk, "a", "folk");
    sng_st_assert(_st, sng_book_count(_bk) == 2 && sng_book_song(_bk, 0).tradition == "chant", "learning a song twice keeps the first and does not duplicate");
    sng_st_assert(_st, sng_book_has(_bk, "b") && !sng_book_has(_bk, "zz"), "has() tells a learned sheet from an unknown one");
    var _sv2 = sng_book_save(_bk), _ld = sng_book_load(_sv2);
    sng_st_assert(_st, sng_book_count(_ld) == 2 && _ld.songs[1].title == "Named" && _ld.songs[0].tradition == "chant", "a book survives save and load");
    var _s1 = sng_book_song(_bk, 0), _s1b = sng_book_song(_ld, 0), _eq = true;
    for (_i = 0; _i < array_length(_s1.notes); _i++) if (_s1.notes[_i].pitch != _s1b.notes[_i].pitch) _eq = false;
    sng_st_assert(_st, _eq, "a loaded sheet is the same melody");
    sng_st_assert(_st, sng_book_count(sng_book_load("not json {")) == 0 && sng_book_count(sng_book_load("")) == 0 && sng_book_count(sng_book_load(undefined)) == 0, "a damaged save loads as an empty book, never a crash");
    var _future = sng_book_load("{\"version\":7,\"extra\":\"keep\",\"songs\":[{\"id\":\"x\",\"tradition\":\"nope\"},{\"title\":\"no id\"}]}");
    sng_st_assert(_st, _future.version == 7 && _future.extra == "keep" && sng_book_count(_future) == 1 && _future.songs[0].tradition == "folk", "a LATER version's fields are kept, bad entries dropped, unknown traditions become folk");
    sng_st_assert(_st, sng_book_forget(_bk, "a") && !sng_book_forget(_bk, "a") && sng_book_count(_bk) == 1, "forget removes once and reports the second as absent");
    sng_st_assert(_st, sng_book_learn(undefined, "x", "folk") == undefined && sng_book_learn(_bk, "", "folk") == undefined, "refusals: not a book, an empty id");

    sng_st_stage(_st, 7);    // the songbook screen, drawn for real
    var _ui = sng_songbook_create(sng_demo_book());
    var _usf = surface_create(1280, 720);
    surface_set_target(_usf); draw_clear(c_black);
    sng_songbook_draw(_ui, 0, 0, 1280, 720);
    surface_reset_target();
    sng_st_assert(_st, sng_is_plate(_ui.plate), "the songbook renders the selected sheet as a plate");
    sng_songbook_step(_ui, false, true, false, false);
    sng_st_assert(_st, _ui.sel == 1, "DOWN selects the next sheet");
    sng_songbook_step(_ui, true, false, false, false); sng_songbook_step(_ui, true, false, false, false);
    sng_st_assert(_st, _ui.sel == sng_book_count(_ui.book) - 1, "UP from the first sheet wraps to the last");
    _ui.song = sng_book_song(_ui.book, _ui.sel); _ui.sched = sng_schedule(_ui.song); _ui.clock = _ui.sched[2].at + 0.01;
    sng_st_assert(_st, sng_songbook_playhead(_ui) == 2, "with no sound playing, the playhead follows the screen's own clock");
    surface_set_target(_usf); draw_clear(c_black); sng_songbook_draw(_ui, 0, 0, 1280, 720); surface_reset_target();
    // ⛔ NOT an ink count: a surface cleared to black and never drawn on is "ink" to every darker-than-paper
    // counter, so that assertion would pass on a screen that drew NOTHING. Count PAPER-BRIGHT pixels instead
    // (the plate and the index slips), which an undrawn surface cannot fake - and prove it with the control.
    var _ubright = sng_st_bright(_usf, 1280, 720, 170);
    surface_set_target(_usf); draw_clear(c_black); surface_reset_target();
    var _ublank = sng_st_bright(_usf, 1280, 720, 170);
    sng_st_note(_st, "songbook screen: " + string(_ubright) + " paper-bright samples (blank control " + string(_ublank) + ")");
    sng_st_assert(_st, _ublank == 0, "control: an undrawn surface has no paper-bright pixels");
    sng_st_assert(_st, _ubright > 100000, "the songbook screen draws its plate and index (" + string(_ubright) + " paper-bright samples)");
    surface_free(_usf);
    sng_songbook_free(_ui);

    sng_st_stage(_st, 8);    // the oracle: melodies written out for the NODE-side comparison against the MZ plugin
    var _f = file_text_open_write("sng_oracle.json");
    file_text_write_string(_f, "{\"songs\":[");
    var _first = true, _count = 0;
    var _tonics = [62, 55, 67];
    for (_j = 0; _j < 30; _j++) for (_t = 0; _t < array_length(_T); _t++) {
        var _to = _tonics[_j mod 3];
        var _os = sng_song("oracle-" + string(_j), _T[_t], _to);
        var _row = "{\"id\":\"oracle-" + string(_j) + "\",\"t\":\"" + _T[_t] + "\",\"tonic\":" + string(_to) + ",\"n\":[";
        for (_i = 0; _i < array_length(_os.notes); _i++) _row += ((_i > 0) ? "," : "") + "[" + string(_os.notes[_i].pitch) + "," + string(_os.notes[_i].start) + "," + string(_os.notes[_i].dur) + "]";
        file_text_write_string(_f, (_first ? "" : ",") + _row + "]}");
        _first = false; _count++;
    }
    file_text_write_string(_f, "]}");
    file_text_close(_f);
    sng_st_note(_st, "oracle: " + string(_count) + " songs written for comparison with the MZ plugin");
    sng_st_assert(_st, _count == 300, "300 oracle songs written");

    sng_st_stage(_st, 99);
    return _st;
}

function sng_selftest_write(_st) {
    var _f = file_text_open_write("sng_selftest.json");
    file_text_write_string(_f, "{\"total\":" + string(_st.total) + ",\"pass\":" + string(_st.pass) + ",\"fail\":" + string(_st.fail) + ",\"stage\":" + string(_st.stage) + ",\"notes\":[");
    for (var _i = 0; _i < array_length(_st.notes); _i++) { if (_i > 0) file_text_write_string(_f, ","); file_text_write_string(_f, "\"" + string_replace_all(_st.notes[_i], "\"", "'") + "\""); }
    file_text_write_string(_f, "],\"failures\":[");
    for (var _i = 0; _i < array_length(_st.failures); _i++) { if (_i > 0) file_text_write_string(_f, ","); file_text_write_string(_f, "\"" + string_replace_all(_st.failures[_i], "\"", "'") + "\""); }
    file_text_write_string(_f, "]}");
    file_text_close(_f);
}
