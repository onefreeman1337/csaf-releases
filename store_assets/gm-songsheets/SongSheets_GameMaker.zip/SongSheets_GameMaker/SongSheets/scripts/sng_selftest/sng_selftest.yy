{
  "$GMScript": "v1",
  "%Name": "sng_selftest",
  "name": "sng_selftest",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}