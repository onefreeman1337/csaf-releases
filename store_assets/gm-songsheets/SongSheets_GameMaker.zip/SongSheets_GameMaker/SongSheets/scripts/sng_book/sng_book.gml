/// sng_book.gml - the player's collection of sheets, its save format, and a SONGBOOK screen that draws it:
/// a writing desk, an index of every sheet learned, the selected plate, and a playhead that follows the music.
///
/// Song Sheets - Every Song Engraved and Played, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// The book stores only what cannot be regenerated - id, tradition, title, tonic - so a save stays tiny and a
/// sheet looks and sounds identical on every machine that loads it.
///
/// PUBLIC API:
///   sng_book_create()                               -> an empty book
///   sng_book_learn(book, id, tradition, [title], [tonic])  -> the learned song (or the one already there)
///   sng_book_forget(book, id)        sng_book_has(book, id)        sng_book_count(book)
///   sng_book_find(book, id)          sng_book_song(book, index)    sng_book_ids(book)
///   sng_book_save(book)  -> string   sng_book_load(string) -> book (an empty one if the string is not a book)
///   sng_songbook_create(book)        sng_songbook_step(ui, up, down, play, stop)
///   sng_songbook_draw(ui, x, y, w, h)                sng_songbook_free(ui)

#macro SNG_BOOK_VERSION 1

/// @function sng_book_create()
/// @description A new, empty book. Pure.
function sng_book_create() { return { sng_kind: "book", version: SNG_BOOK_VERSION, songs: [] }; }

/// @function sng_is_book(value)
/// @description True if value is a book. Pure.
function sng_is_book(_b) {
    return is_struct(_b) && variable_struct_exists(_b, "sng_kind") && _b.sng_kind == "book" && is_array(_b.songs);
}

/// @function sng_book_find(book, id)
/// @description The index of a song id in the book, or -1. Pure.
function sng_book_find(_b, _id) {
    if (!sng_is_book(_b)) return -1;
    _id = string(_id);
    for (var _i = 0; _i < array_length(_b.songs); _i++) if (_b.songs[_i].id == _id) return _i;
    return -1;
}

/// @function sng_book_learn(book, id, tradition, [title], [tonic])
/// @description Add a sheet. Learning a song already in the book changes nothing and returns it. Returns the
/// song struct, or undefined if `book` is not a book or `id` is empty. An unknown tradition is stored as "folk"
/// (the song struct's `.fallback` says so) rather than refused, so a typo in a cutscene never loses the song.
function sng_book_learn(_b, _id, _trad, _title = undefined, _tonic = 62) {
    if (!sng_is_book(_b)) return undefined;
    _id = string(_id);
    if (_id == "") return undefined;
    var _at = sng_book_find(_b, _id);
    if (_at >= 0) return sng_book_song(_b, _at);
    var _song = sng_song(_id, _trad, _tonic, _title);
    array_push(_b.songs, { id: _id, tradition: _song.tradition, title: _song.title, tonic: _song.tonic });
    return _song;
}

/// @function sng_book_forget(book, id)
/// @description Remove a sheet. Returns true if it was there.
function sng_book_forget(_b, _id) {
    var _at = sng_book_find(_b, _id);
    if (_at < 0) return false;
    array_delete(_b.songs, _at, 1);
    return true;
}

/// @function sng_book_has(book, id)
/// @description True if the player has this sheet. Pure.
function sng_book_has(_b, _id) { return sng_book_find(_b, _id) >= 0; }

/// @function sng_book_count(book)
/// @description How many sheets the book holds. Pure.
function sng_book_count(_b) { return sng_is_book(_b) ? array_length(_b.songs) : 0; }

/// @function sng_book_ids(book)
/// @description A copy of the book's song ids, in learning order. Pure.
function sng_book_ids(_b) {
    var _out = [];
    if (!sng_is_book(_b)) return _out;
    for (var _i = 0; _i < array_length(_b.songs); _i++) array_push(_out, _b.songs[_i].id);
    return _out;
}

/// @function sng_book_song(book, index)
/// @description The full song struct for the sheet at `index`, regenerated from its id. undefined if out of
/// range.
function sng_book_song(_b, _i) {
    if (!sng_is_book(_b) || !is_real(_i)) return undefined;
    _i = floor(_i);
    if (_i < 0 || _i >= array_length(_b.songs)) return undefined;
    var _e = _b.songs[_i];
    return sng_song(_e.id, _e.tradition, _e.tonic, _e.title);
}

/// @function sng_book_save(book)
/// @description The book as a string for your save file. Returns "" for a non-book.
function sng_book_save(_b) {
    if (!sng_is_book(_b)) return "";
    return json_stringify(_b);
}

/// @function sng_book_load(string)
/// @description A book from a saved string. Anything that is not a readable book comes back as an EMPTY book,
/// never an exception - a damaged save must not stop a game loading. Entries missing an id are dropped; fields
/// this version does not know are kept, so a save written by a LATER version is never downgraded.
function sng_book_load(_s) {
    var _b = sng_book_create();
    if (!is_string(_s) || _s == "") return _b;
    var _raw = undefined;
    try { _raw = json_parse(_s); } catch (_e) { return _b; }
    if (!is_struct(_raw) || !variable_struct_exists(_raw, "songs") || !is_array(_raw.songs)) return _b;
    var _keys = variable_struct_get_names(_raw);
    for (var _k = 0; _k < array_length(_keys); _k++) if (_keys[_k] != "songs") _b[$ _keys[_k]] = _raw[$ _keys[_k]];
    _b.sng_kind = "book";
    if (!variable_struct_exists(_raw, "version")) _b.version = SNG_BOOK_VERSION;
    for (var _i = 0; _i < array_length(_raw.songs); _i++) {
        var _e = _raw.songs[_i];
        if (!is_struct(_e) || !variable_struct_exists(_e, "id")) continue;
        var _id = string(_e.id);
        if (_id == "" || sng_book_find(_b, _id) >= 0) continue;
        var _t = variable_struct_exists(_e, "tradition") ? string(_e.tradition) : "folk";
        if (sng_tradition(_t) == undefined) _t = "folk";
        var _ti = variable_struct_exists(_e, "title") ? string(_e.title) : sng_title(_id, _t);
        var _to = (variable_struct_exists(_e, "tonic") && is_numeric(_e.tonic)) ? clamp(floor(_e.tonic), 24, 96) : 62;
        array_push(_b.songs, { id: _id, tradition: _t, title: _ti, tonic: _to });
    }
    return _b;
}

/// @function sng_songbook_create(book)
/// @description The state of a songbook screen showing `book`. Holds the selection and one cached plate.
function sng_songbook_create(_b) {
    return { sng_kind: "songbook", book: _b, sel: 0, top: 0, plate: undefined, plate_key: "", plate_w: 0, plate_h: 0,
             song: undefined, sched: [], clock: -1, auto: false };
}

/// @function sng_is_songbook(value)
/// @description True if value is a songbook screen state. Pure.
function sng_is_songbook(_u) {
    return is_struct(_u) && variable_struct_exists(_u, "sng_kind") && _u.sng_kind == "songbook" && sng_is_book(_u.book);
}

/// @function sng_songbook_step(ui, up, down, play, stop)
/// @description Drive the screen from four booleans (pressed this step): move the selection, play the selected
/// sheet, stop. CALL IT EVERY STEP: it also keeps the playing song rendering ahead of the music (sng_update) and
/// advances the screen's own clock. Returns the selected index.
/// ⛔ The first version left sng_update() to the caller, and the demo never called it - so every song stopped
/// after the half second sng_play renders up front. The screen that plays a song now owns keeping it fed.
function sng_songbook_step(_ui, _up, _down, _play, _stop) {
    if (!sng_is_songbook(_ui)) return -1;
    // a string in an `if` throws in GML, so anything that is not a number or a bool counts as "not pressed"
    _up = (is_numeric(_up) || is_bool(_up)) && _up;
    _down = (is_numeric(_down) || is_bool(_down)) && _down;
    _play = (is_numeric(_play) || is_bool(_play)) && _play;
    _stop = (is_numeric(_stop) || is_bool(_stop)) && _stop;
    sng_update();
    if (_ui.clock >= 0) {
        _ui.clock += delta_time / 1000000;
        if (is_struct(_ui.song) && _ui.clock > sng_duration(_ui.song) + SNG_TAIL && !sng_is_playing()) _ui.clock = -1;
    }
    var _n = sng_book_count(_ui.book);
    if (_n == 0) { _ui.sel = 0; return -1; }
    var _was = _ui.sel;
    if (_up) _ui.sel = (_ui.sel - 1 + _n) mod _n;
    if (_down) _ui.sel = (_ui.sel + 1) mod _n;
    _ui.sel = clamp(_ui.sel, 0, _n - 1);
    if (_ui.sel != _was) { sng_stop(); _ui.clock = -1; }
    if (_stop) { sng_stop(); _ui.clock = -1; }
    if (_play) {
        var _song = sng_book_song(_ui.book, _ui.sel);
        _ui.song = _song;
        _ui.sched = sng_schedule(_song);
        _ui.clock = 0;
        sng_play(_song);
    }
    return _ui.sel;
}

/// @function sng_songbook_playhead(ui)
/// @description The note index the screen should light: the SOUND's own position while audio plays, and the
/// screen's own clock when it cannot (no audio device, or a capture) - so the plate animates either way.
function sng_songbook_playhead(_ui) {
    if (!sng_is_songbook(_ui) || _ui.clock < 0) return -1;
    var _t = sng_position();
    if (_t < 0) _t = _ui.clock;
    return sng_note_at(_ui.sched, _t);
}

/// @function sng_songbook_emblem(tradition, x, y, r, colour)
/// @description A small mark standing for a tradition's NOTATION in the index: a square neume, a void note, a
/// beamed pair, a grid cell or a curl.
function sng_songbook_emblem(_trad, _x, _y, _r, _col) {
    var _T = sng_tradition(_trad);
    var _sys = is_struct(_T) ? _T.notation : "modern";
    switch (_sys) {
        case "neume":
            sng_rect_fill(_x - _r * 0.55, _y - _r * 0.2, _r * 0.8, _r * 0.6, _col);
            sng_rect_fill(_x + _r * 0.05, _y - _r * 0.75, _r * 0.8, _r * 0.6, _col);
            sng_seg(_x - _r * 0.9, _y + _r * 0.55, _x + _r * 0.9, _y + _r * 0.55, max(1, _r * 0.1), _col);
            break;
        case "mensural":
            // a void lozenge with its stem rising from the top point: the minim the plate itself draws
            sng_polyline([_x - _r * 0.42, _y + _r * 0.35, _x, _y - _r * 0.2, _x + _r * 0.42, _y + _r * 0.35, _x, _y + _r * 0.9], max(1, _r * 0.15), _col, 1, true);
            sng_seg(_x, _y - _r * 0.2, _x, _y - _r * 1.05, max(1, _r * 0.13), _col);
            break;
        case "grid":
            sng_rect_line(_x - _r * 0.8, _y - _r * 0.6, _r * 1.6, _r * 1.2, max(1, _r * 0.1), _col);
            sng_seg(_x - _r * 0.8, _y, _x + _r * 0.8, _y, max(1, _r * 0.08), _col);
            sng_fill_convex([_x - _r * 0.3, _y - _r * 0.3, _x - _r * 0.05, _y - _r * 0.05, _x - _r * 0.3, _y + _r * 0.2, _x - _r * 0.55, _y - _r * 0.05], _col);
            sng_disc(_x + _r * 0.4, _y + _r * 0.3, _r * 0.18, _col);
            break;
        case "spiral":
            var _p = [];
            for (var _a = 0; _a <= 4 * pi; _a += 0.3) array_push(_p, _x + cos(_a) * _r * (0.15 + _a / (4 * pi) * 0.8), _y + sin(_a) * _r * (0.15 + _a / (4 * pi) * 0.8));
            sng_polyline(_p, max(1, _r * 0.12), _col);
            break;
        default:
            sng_fill_convex(sng_ellipse_pts(_x - _r * 0.45, _y + _r * 0.5, _r * 0.34, _r * 0.25, -0.34, 16), _col);
            sng_fill_convex(sng_ellipse_pts(_x + _r * 0.45, _y + _r * 0.3, _r * 0.34, _r * 0.25, -0.34, 16), _col);
            sng_seg(_x - _r * 0.13, _y + _r * 0.5, _x - _r * 0.13, _y - _r * 0.85, max(1, _r * 0.1), _col);
            sng_seg(_x + _r * 0.77, _y + _r * 0.3, _x + _r * 0.77, _y - _r * 1.05, max(1, _r * 0.1), _col);
            sng_fill_convex([_x - _r * 0.18, _y - _r * 0.85, _x + _r * 0.82, _y - _r * 1.05, _x + _r * 0.82, _y - _r * 0.8, _x - _r * 0.18, _y - _r * 0.6], _col);
            break;
    }
}

/// @function sng_desk(x, y, w, h, seed)
/// @description A dark writing desk: walnut boards with generated grain, a lamp's warm pool, and a vignette.
function sng_desk(_x, _y, _w, _h, _seed) {
    var _g = sng_rng(_seed), _i;
    var _wood = make_colour_rgb(46, 30, 20), _dark = make_colour_rgb(28, 18, 12), _lite = make_colour_rgb(92, 62, 40);
    sng_rect_fill(_x, _y, _w, _h, _wood);
    var _board = max(60, _h / 5);
    for (var _by = _y; _by < _y + _h; _by += _board) {
        sng_seg(_x, _by, _x + _w, _by, 2, _dark, 0.8);
        for (_i = 0; _i < 14; _i++) {
            var _gy = _by + sng_rng_next(_g) * _board, _amp = 2 + sng_rng_next(_g) * 6, _ph = sng_rng_next(_g) * 6;
            var _pts = [];
            for (var _gx = _x; _gx <= _x + _w; _gx += 24) array_push(_pts, _gx, _gy + sin(_gx / (90 + _i * 7) + _ph) * _amp);
            sng_polyline(_pts, 1, (sng_rng_next(_g) < 0.5) ? _dark : _lite, 0.22 + sng_rng_next(_g) * 0.18);
        }
    }
    sng_spot(_x + _w * 0.62, _y + _h * 0.42, max(_w, _h) * 0.75, make_colour_rgb(255, 190, 110), 0.16);
    sng_edge_shade(_x, _y, _w, _h, min(_w, _h) * 0.22, c_black, 0.55);
}

/// @function sng_songbook_draw(ui, x, y, w, h)
/// @description Draw the whole songbook screen into the rect: desk, index of sheets (with each tradition's
/// emblem), the selected plate on the desk, its playhead while it plays, and a count. The plate is rendered
/// once and cached until the selection or the size changes.
function sng_songbook_draw(_ui, _x, _y, _w, _h) {
    if (!sng_is_songbook(_ui) || !is_real(_x) || !is_real(_y) || !is_real(_w) || !is_real(_h)) return;
    if (_w < 200 || _h < 150) return;
    sng_desk(_x, _y, _w, _h, 7);
    var _n = sng_book_count(_ui.book);
    var _pad = _h * 0.045;
    var _hdr = _h * 0.085;
    var _paper = make_colour_rgb(236, 226, 204), _ink = make_colour_rgb(58, 42, 28), _rub = make_colour_rgb(150, 58, 36);
    sng_text(_x + _pad, _y + _pad * 0.6, "SONGBOOK", _hdr * 0.62, _paper, fa_left, fa_top, fnt_songsheets_title);
    sng_text(_x + _pad, _y + _pad * 0.6 + _hdr * 0.64, string(_n) + ((_n == 1) ? " sheet learned" : " sheets learned"), _hdr * 0.30, make_colour_rgb(200, 180, 150), fa_left, fa_top, fnt_songsheets);
    // THE INDEX: a column of paper slips, one per sheet
    var _ix = _x + _pad, _iy = _y + _pad + _hdr + _pad * 0.4;
    var _iw = _w * 0.30, _ih = _h - (_iy - _y) - _pad;
    // ⛔ the row height is a share of the SCREEN, not a pixel cap: capped at 64 px, a large screen drew fourteen
    // small slips and left the lower third of the index column as bare desk
    var _rowh = clamp(_ih / 9, _h * 0.035, _h * 0.09);
    var _rows = max(1, floor(_ih / _rowh));
    if (_ui.sel < _ui.top) _ui.top = _ui.sel;
    if (_ui.sel >= _ui.top + _rows) _ui.top = _ui.sel - _rows + 1;
    _ui.top = clamp(_ui.top, 0, max(0, _n - _rows));
    for (var _r = 0; _r < _rows; _r++) {
        var _i = _ui.top + _r;
        if (_i >= _n) break;
        var _e = _ui.book.songs[_i];
        var _ry = _iy + _r * _rowh, _sel = (_i == _ui.sel);
        var _sx = _ix + (_sel ? _iw * 0.04 : 0);
        sng_rect_fill(_sx + 3, _ry + 4, _iw, _rowh - 6, c_black, 0.35);
        sng_rect_fill(_sx, _ry + 1, _iw, _rowh - 6, _sel ? _paper : make_colour_rgb(206, 192, 164));
        if (_sel) {
            // a ribbon bookmark on the selected sheet
            sng_fill_convex([_sx + _iw - _rowh * 0.34, _ry - 2, _sx + _iw - _rowh * 0.12, _ry - 2, _sx + _iw - _rowh * 0.12, _ry + _rowh * 0.95, _sx + _iw - _rowh * 0.23, _ry + _rowh * 0.8, _sx + _iw - _rowh * 0.34, _ry + _rowh * 0.95], _rub);
        }
        var _em = _rowh * 0.26;
        sng_songbook_emblem(_e.tradition, _sx + _rowh * 0.42, _ry + _rowh * 0.46, _em, _sel ? _rub : _ink);
        var _T = sng_tradition(_e.tradition);
        sng_text(_sx + _rowh * 0.85, _ry + _rowh * 0.10, _e.title, _rowh * 0.40, _ink, fa_left, fa_top, fnt_songsheets, 1, _iw - _rowh * 1.35);
        sng_text(_sx + _rowh * 0.85, _ry + _rowh * 0.52, string_upper(is_struct(_T) ? _T.name : _e.tradition), _rowh * 0.24, _rub, fa_left, fa_top, fnt_songsheets, 0.9, _iw - _rowh * 1.35);
    }
    if (_n > _rows) {
        var _bar = _ih * (_rows / _n), _pos = _ih * (_ui.top / _n);
        sng_rect_fill(_ix - _pad * 0.35, _iy + _pos, 3, _bar, _paper, 0.5);
    }
    // THE PLATE
    var _px = _ix + _iw + _pad * 1.4, _pw = _x + _w - _pad - _px;
    var _ph = min(_h - _pad * 2 - _hdr * 0.2, _pw * 0.78);
    var _py = _y + (_h - _ph) * 0.5 + _hdr * 0.25;
    if (_n == 0) {
        sng_text(_px + _pw / 2, _py + _ph / 2, "No sheets learned yet", _h * 0.04, _paper, fa_center, fa_middle, fnt_songsheets, 0.7);
        return;
    }
    var _key = _ui.book.songs[_ui.sel].id + "|" + string(floor(_pw)) + "x" + string(floor(_ph));
    if (_key != _ui.plate_key || !sng_is_plate(_ui.plate)) {
        sng_plate_free(_ui.plate);
        _ui.plate = sng_plate(sng_book_song(_ui.book, _ui.sel), _pw, _ph, 2);
        _ui.plate_key = _key;
    }
    sng_rect_fill(_px + _pad * 0.25, _py + _pad * 0.3, _pw, _ph, c_black, 0.45);
    sng_plate_draw(_ui.plate, _px, _py);
    sng_playhead_draw(_ui.plate, _px, _py, sng_songbook_playhead(_ui));
}

/// @function sng_songbook_free(ui)
/// @description Free the screen's cached plate and stop its song.
function sng_songbook_free(_ui) {
    if (!sng_is_songbook(_ui)) return;
    sng_stop();
    sng_plate_free(_ui.plate);
    _ui.plate = undefined;
    _ui.plate_key = "";
}
