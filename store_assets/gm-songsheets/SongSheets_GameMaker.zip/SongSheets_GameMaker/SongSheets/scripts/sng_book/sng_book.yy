{
  "$GMScript": "v1",
  "%Name": "sng_book",
  "name": "sng_book",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}