/// sng_player.gml - sounds a song. Every note is SYNTHESISED into GameMaker audio buffers at run time and
/// STREAMED through an audio play queue; no audio file ships, because the melody does not exist until the
/// player's song id does.
///
/// Song Sheets - Every Song Engraved and Played, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ WHY IT STREAMS. The first version rendered a whole song into one buffer before playing it, and the in-engine
/// suite MEASURED that at 2.9 seconds for a 52-second plainchant on the VM runtime (about 2.5 microseconds per
/// sample) - a freeze the moment a player presses play. So sng_play() renders only the first half second, starts
/// the sound, and sng_update() keeps rendering a little ahead of the music in a small per-step time budget. Once a
/// song has been heard in full its chunks are cached and a replay starts instantly.
///
/// ⭐ ONE SCHEDULE. The notes the speakers make and the notehead the plate lights both read sng_schedule(), so
/// they cannot disagree; the synthesis is also STATELESS per sample (phase and envelope are computed from the
/// sample's own index), so a song rendered in chunks is byte-identical to the same song rendered in one piece.
///
/// ⚠️ AUDIO IS NEVER LOAD-BEARING. If a queue cannot be made the functions return -1/false and the plate still
/// animates on the screen's own clock; a song sheet must never crash a game because a machine has no sound device.
///
/// PUBLIC API:
///   sng_schedule(song)            -> [{i, pitch, at, dur}] in seconds (pure)
///   sng_duration(song)            -> seconds from the first onset to the end of the last note (pure)
///   sng_note_at(schedule, secs)   -> index of the note sounding at `secs`, or -1 (pure)
///   sng_timbres()                 -> the nine instrument keys (pure)
///   sng_play(song, [gain])        -> starts the song streaming; returns the sound instance, or -1
///   sng_update([budget_ms])       -> CALL EVERY STEP while a song plays (the songbook does this for you)
///   sng_stop()                    -> stops whatever Song Sheets is playing
///   sng_is_playing()              -> true while a song is sounding
///   sng_position()                -> seconds into the current song, or -1
///   sng_playing_index()           -> the note index sounding right now, or -1
///   sng_prepare(song, [budget_ms])-> renders a song into the cache ahead of time; returns progress 0..1
///   sng_render(song)              -> the whole song synthesised into one new buffer (blocking; you own it)
///   sng_save_wav(song, filename)  -> writes the song as a 16-bit mono WAV; returns bytes written, or 0
///   sng_audio_free()              -> frees every cached chunk (call when leaving the songbook)

#macro SNG_RATE 22050
// the tail must hold the LONGEST release (glass, 0.50 s) plus a margin, or the last note is cut mid-ring
#macro SNG_TAIL 0.55
#macro SNG_CHUNK 5513
#macro SNG_AHEAD 1.5

/// @function sng_timbre(key)
/// @description One instrument: oscillator `wave`, a sine `partial` at a harmonic ratio (0 = none) and its level,
/// and an envelope a/d/s/r in seconds. ⛔ The nine differ in ENVELOPE and HARMONIC CONTENT, not in pitch: a plucked
/// lute and a bowed viol built from the same wave are different instruments because their first fifty
/// milliseconds are. Unknown keys fall back to "voice". Pure.
function sng_timbre(_key) {
    static _T = {
        voice:   { wave: 0, partial: 2,   pgain: 0.13, a: 0.06,  d: 0.09, s: 0.80, r: 0.22 },
        plucked: { wave: 1, partial: 3,   pgain: 0.22, a: 0.004, d: 0.30, s: 0.10, r: 0.20 },
        reed:    { wave: 2, partial: 0,   pgain: 0,    a: 0.02,  d: 0.06, s: 0.70, r: 0.10 },
        brass:   { wave: 2, partial: 2,   pgain: 0.18, a: 0.035, d: 0.10, s: 0.75, r: 0.14 },
        bowed:   { wave: 1, partial: 2,   pgain: 0.10, a: 0.13,  d: 0.14, s: 0.85, r: 0.34 },
        bell:    { wave: 0, partial: 3.5, pgain: 0.30, a: 0.002, d: 0.55, s: 0.02, r: 0.42 },
        organ:   { wave: 3, partial: 2,   pgain: 0.16, a: 0.03,  d: 0.02, s: 0.92, r: 0.10 },
        glass:   { wave: 0, partial: 4.2, pgain: 0.24, a: 0.09,  d: 0.40, s: 0.35, r: 0.50 },
        hammer:  { wave: 3, partial: 5,   pgain: 0.28, a: 0.001, d: 0.14, s: 0.05, r: 0.08 }
    };
    if (is_string(_key) && variable_struct_exists(_T, _key)) return _T[$ _key];
    return _T.voice;
}

/// @function sng_timbres()
/// @description The nine instrument keys. Nine, not ten: plainchant and the shanty are both unaccompanied singing
/// and share `voice`, differing by mode, metre, tempo and detune. Pure.
function sng_timbres() {
    static _k = ["voice", "plucked", "reed", "brass", "bowed", "bell", "organ", "glass", "hammer"];
    return _k;
}

/// @function sng_hz(midi)
/// @description Equal temperament, A440. Pure.
function sng_hz(_midi) { return 440 * power(2, (_midi - 69) / 12); }

/// @function sng_schedule(song)
/// @description The song as absolute times in seconds: [{i, pitch, at, dur}]. Pure. [] for anything not a song.
function sng_schedule(_song) {
    var _out = [];
    if (!sng_is_song(_song)) return _out;
    var _per16 = (60 / max(1, _song.bpm)) / 4;
    for (var _i = 0; _i < array_length(_song.notes); _i++) {
        var _n = _song.notes[_i];
        array_push(_out, { i: _i, pitch: _n.pitch, at: _n.start * _per16, dur: max(0.06, _n.dur * _per16) });
    }
    return _out;
}

/// @function sng_duration(song)
/// @description Seconds from the first onset to the end of the last note. Pure.
function sng_duration(_song) {
    var _s = sng_schedule(_song);
    var _n = array_length(_s);
    if (_n == 0) return 0;
    return _s[_n - 1].at + _s[_n - 1].dur;
}

/// @function sng_note_at(schedule, seconds)
/// @description The index of the note sounding `seconds` into the song, or -1 before the first onset, between
/// notes and after the last. Pure, allocation-free: pass a schedule built ONCE, never one built per frame.
function sng_note_at(_sched, _t) {
    if (!is_array(_sched) || !is_numeric(_t)) return -1;
    for (var _i = array_length(_sched) - 1; _i >= 0; _i--) {
        var _e = _sched[_i];
        if (_t >= _e.at) return (_t <= _e.at + _e.dur) ? _i : -1;
    }
    return -1;
}

/// @function sng_env(t, dur, tb)
/// @description The envelope level (peak 1) at `t` seconds into a note of length `dur`: linear attack and decay,
/// sustain for the note's WHOLE written length, then an exponential release to -80 dB that rings past it.
/// Pure. The renderer inlines exactly this arithmetic.
/// ⛔ The release used to END at the written length (as the MZ plugin's WebAudio ramp does). An exponential fall
/// to -80 dB spends its last ~40% under -50 dB, so every note finished with a fifth of a second of near-silence
/// before the next - MEASURED by audio_check.js as up to 60 dead 50 ms windows in one song, a detached, gappy
/// line under a plate that shows a slurred one. The release now rings over the next onset, as a string or bell does.
function sng_env(_t, _dur, _tb) {
    if (_t < 0) return 0;
    var _body = max(0.02, _dur);
    if (_t < _body) return sng_env_hold(_t, _tb);
    var _lv = sng_env_hold(_body, _tb);
    var _k = (_t - _body) / max(0.0001, _tb.r);
    if (_k >= 1) return 0;
    return _lv * exp(ln(0.0001 / max(0.0001, _lv)) * _k);
}

/// @function sng_env_hold(t, tb)
/// @description The attack-decay-sustain part of the envelope, before any release. Pure.
function sng_env_hold(_u, _tb) {
    if (_u < _tb.a) return _u / max(0.0001, _tb.a);
    if (_u < _tb.a + _tb.d) return 1 + (_tb.s - 1) * ((_u - _tb.a) / max(0.0001, _tb.d));
    return _tb.s;
}

/// @function sng_voice_plan(song, rate)
/// @description Everything the renderer needs per note, computed once: start and end sample, frequency, the
/// envelope's breakpoints in samples. Pure.
function sng_voice_plan(_song, _rate) {
    var _sched = sng_schedule(_song), _tb = sng_timbre(_song.timbre);
    var _det = power(2, _song.detune / 1200), _plan = [];
    for (var _i = 0; _i < array_length(_sched); _i++) {
        var _ev = _sched[_i];
        var _body = max(0.02, _ev.dur);
        var _lv = sng_env_hold(_body, _tb);
        var _f = sng_hz(_ev.pitch) * _det;
        array_push(_plan, {
            s0: floor(_ev.at * _rate), len: ceil((_body + _tb.r + 0.02) * _rate),
            dt: _f / _rate, dt2: _f * _tb.partial / _rate,
            A: _tb.a * _rate, D: _tb.d * _rate, S: _tb.s, B: _body * _rate, R: _tb.r * _rate,
            lv: _lv, c: ln(0.0001 / max(0.0001, _lv)) / max(1, _tb.r * _rate)
        });
    }
    return { notes: _plan, tb: _tb, rate: _rate, total: ceil((sng_duration(_song) + SNG_TAIL) * _rate) };
}

/// @function sng_render_into(plan, s0, s1, buffer, offset)
/// @description Synthesise samples [s0, s1) of a planned song into `buffer` as s16 starting at byte `offset`.
/// Returns the peak absolute sample (0..1). STATELESS per sample - a chunk equals the same span of a whole render.
function sng_render_into(_plan, _s0, _s1, _buf, _off) {
    var _n = _s1 - _s0;
    if (_n <= 0) return 0;
    var _mix = array_create(_n, 0);
    var _tb = _plan.tb, _wave = _tb.wave, _part = _tb.partial, _pg = _tb.pgain, _twopi = 2 * pi, _amp = 0.34;
    for (var _e = 0; _e < array_length(_plan.notes); _e++) {
        var _v = _plan.notes[_e];
        var _a0 = max(_s0, _v.s0), _a1 = min(_s1, _v.s0 + _v.len);
        if (_a1 <= _a0) continue;
        var _dt = _v.dt, _dt2 = _v.dt2, _A = _v.A, _AD = _v.A + _v.D, _B = _v.B, _E = _v.B + _v.R;
        for (var _idx = _a0; _idx < _a1; _idx++) {
            var _k = _idx - _v.s0, _env;
            if (_k < _B) {
                if (_k < _A) _env = _k / max(0.0001, _A);
                else if (_k < _AD) _env = 1 + (_v.S - 1) * ((_k - _A) / max(0.0001, _v.D));
                else _env = _v.S;
            } else if (_k < _E) {
                _env = _v.lv * exp(_v.c * (_k - _B));
            } else continue;
            var _ph = _k * _dt; _ph -= floor(_ph);
            var _s;
            if (_wave == 0) _s = sin(_twopi * _ph);
            else if (_wave == 1) _s = 1 - 4 * abs(_ph - 0.5);
            else if (_wave == 2) {
                _s = 2 * _ph - 1;
                if (_ph < _dt) { var _x = _ph / _dt; _s -= _x + _x - _x * _x - 1; }
                else if (_ph > 1 - _dt) { var _y = (_ph - 1) / _dt; _s -= _y * _y + _y + _y + 1; }
            } else {
                _s = (_ph < 0.5) ? 1 : -1;
                if (_ph < _dt) { var _x2 = _ph / _dt; _s += _x2 + _x2 - _x2 * _x2 - 1; }
                else if (_ph > 1 - _dt) { var _y2 = (_ph - 1) / _dt; _s += _y2 * _y2 + _y2 + _y2 + 1; }
                var _pb = _ph + 0.5; if (_pb >= 1) _pb -= 1;
                if (_pb < _dt) { var _x3 = _pb / _dt; _s -= _x3 + _x3 - _x3 * _x3 - 1; }
                else if (_pb > 1 - _dt) { var _y3 = (_pb - 1) / _dt; _s -= _y3 * _y3 + _y3 + _y3 + 1; }
                _s *= 0.7;
            }
            if (_part > 0) { var _p2 = _k * _dt2; _p2 -= floor(_p2); _s += _pg * sin(_twopi * _p2); }
            _mix[_idx - _s0] += _s * _env * _amp;
        }
    }
    var _pk = 0;
    buffer_seek(_buf, buffer_seek_start, _off);
    for (var _i = 0; _i < _n; _i++) {
        var _smp = clamp(_mix[_i], -1, 1);
        if (abs(_smp) > _pk) _pk = abs(_smp);
        buffer_write(_buf, buffer_s16, floor(_smp * 32767));
    }
    return _pk;
}

/// @function sng_render(song, [rate])
/// @description SYNTHESISE the whole song into one new 16-bit mono buffer. Blocking - it takes about as long as the
/// suite reports per tradition - so use sng_play for playback; this is for export and measurement. Returns
/// {buffer, bytes, samples, rate, seconds, peak} or undefined for a non-song. The caller owns the buffer.
function sng_render(_song, _rate = SNG_RATE) {
    if (!sng_is_song(_song)) return undefined;
    _rate = clamp(floor(is_numeric(_rate) ? _rate : SNG_RATE), 8000, 48000);
    var _plan = sng_voice_plan(_song, _rate);
    var _buf = buffer_create(_plan.total * 2, buffer_fixed, 2);
    var _pk = sng_render_into(_plan, 0, _plan.total, _buf, 0);
    return { buffer: _buf, bytes: _plan.total * 2, samples: _plan.total, rate: _rate, seconds: _plan.total / _rate, peak: _pk };
}

/// @function sng_audio_cache()
/// @description The shared player state: finished songs' chunk lists, the job being streamed, and the clock.
function sng_audio_cache() {
    static _c = { done: {}, job: undefined, playing: -1, queue: -1, t0: 0, song: undefined, sched: [], prep: {} };
    return _c;
}

/// @function sng_song_key(song)
/// @description The cache key of a song's audio. Pure.
function sng_song_key(_song) { return _song.song_id + "|" + _song.tradition + "|" + string(_song.tonic); }

/// @function sng_job_create(song)
/// @description A render job for a song: its plan and the chunks rendered so far. Internal.
function sng_job_create(_song) {
    return { key: sng_song_key(_song), plan: sng_voice_plan(_song, SNG_RATE), next: 0, chunks: [], queued: 0, peak: 0 };
}

/// @function sng_job_step(job)
/// @description Render ONE more chunk of a job. Returns true if a chunk was rendered, false if the job is done.
function sng_job_step(_job) {
    if (_job.next >= _job.plan.total) return false;
    var _s1 = min(_job.plan.total, _job.next + SNG_CHUNK);
    var _buf = buffer_create((_s1 - _job.next) * 2, buffer_fixed, 2);
    _job.peak = max(_job.peak, sng_render_into(_job.plan, _job.next, _s1, _buf, 0));
    array_push(_job.chunks, { buffer: _buf, samples: _s1 - _job.next });
    _job.next = _s1;
    return true;
}

/// @function sng_job_finish(job)
/// @description Store a completed job's chunks so the song replays without rendering. Internal.
function sng_job_finish(_job) {
    var _c = sng_audio_cache();
    _c.done[$ _job.key] = { chunks: _job.chunks, total: _job.plan.total, peak: _job.peak };
    if (variable_struct_exists(_c.prep, _job.key)) variable_struct_remove(_c.prep, _job.key);
}

/// @function sng_queue_pending(job)
/// @description Hand every rendered-but-unqueued chunk to the play queue. Internal.
function sng_queue_pending(_c, _job) {
    if (_c.queue < 0) return;
    while (_job.queued < array_length(_job.chunks)) {
        var _ch = _job.chunks[_job.queued];
        audio_queue_sound(_c.queue, _ch.buffer, 0, _ch.samples * 2);
        _job.queued++;
    }
}

/// @function sng_play(song, [gain])
/// @description Play a song from the top (stopping any Song Sheets song already sounding). Renders about half a
/// second, starts the sound, and leaves the rest to sng_update(). Returns the sound instance, or -1 if nothing
/// could be played - never throws. A song heard in full before replays with no rendering at all.
function sng_play(_song, _gain = 1) {
    sng_stop();
    if (!sng_is_song(_song)) return -1;
    var _c = sng_audio_cache();
    _c.song = _song;
    _c.sched = sng_schedule(_song);
    _c.t0 = get_timer();
    var _q = audio_create_play_queue(buffer_s16, SNG_RATE, audio_mono);
    if (_q < 0) return -1;
    _c.queue = _q;
    var _key = sng_song_key(_song);
    if (variable_struct_exists(_c.done, _key)) {
        var _d = _c.done[$ _key];
        for (var _i = 0; _i < array_length(_d.chunks); _i++) audio_queue_sound(_q, _d.chunks[_i].buffer, 0, _d.chunks[_i].samples * 2);
        _c.job = undefined;
    } else {
        var _job = variable_struct_exists(_c.prep, _key) ? _c.prep[$ _key] : sng_job_create(_song);
        _job.queued = 0;
        sng_job_step(_job); sng_job_step(_job);
        sng_queue_pending(_c, _job);
        if (_job.next >= _job.plan.total) { sng_job_finish(_job); _c.job = undefined; } else _c.job = _job;
    }
    var _inst = audio_play_sound(_q, 10, false);
    if (is_numeric(_gain) && _inst >= 0) audio_sound_gain(_inst, clamp(_gain, 0, 4), 0);
    _c.playing = _inst;
    _c.t0 = get_timer();
    return _inst;
}

/// @function sng_update([budget_ms])
/// @description Keep the playing song rendered about 1.5 seconds ahead of the music, spending at most
/// `budget_ms` (default 3) of this step. CALL IT EVERY STEP while a song plays; the songbook screen does. Returns
/// true while there is still rendering left to do.
function sng_update(_budget = 3) {
    var _c = sng_audio_cache();
    var _job = _c.job;
    if (!is_struct(_job)) return false;
    var _t0 = get_timer(), _lim = (is_numeric(_budget) ? max(0.5, _budget) : 3) * 1000;
    var _elapsed = (get_timer() - _c.t0) / 1000000;
    while (_job.next < _job.plan.total) {
        var _ahead = _job.next / _job.plan.rate - _elapsed;
        if (_ahead > SNG_AHEAD) break;
        sng_job_step(_job);
        if (get_timer() - _t0 > _lim) break;
    }
    sng_queue_pending(_c, _job);
    if (_job.next >= _job.plan.total) { sng_job_finish(_job); _c.job = undefined; return false; }
    return true;
}

/// @function sng_prepare(song, [budget_ms])
/// @description Render a song into the cache ahead of time - on a loading screen, or while the songbook shows
/// its sheet - spending at most `budget_ms` per call. Returns progress 0..1 (1 = it will replay instantly).
function sng_prepare(_song, _budget = 3) {
    if (!sng_is_song(_song)) return 0;
    var _c = sng_audio_cache(), _key = sng_song_key(_song);
    if (variable_struct_exists(_c.done, _key)) return 1;
    if (is_struct(_c.job) && _c.job.key == _key) return _c.job.next / _c.job.plan.total;
    var _job = variable_struct_exists(_c.prep, _key) ? _c.prep[$ _key] : sng_job_create(_song);
    _c.prep[$ _key] = _job;
    var _t0 = get_timer(), _lim = (is_numeric(_budget) ? max(0.5, _budget) : 3) * 1000;
    while (sng_job_step(_job)) if (get_timer() - _t0 > _lim) break;
    if (_job.next >= _job.plan.total) { sng_job_finish(_job); return 1; }
    return _job.next / _job.plan.total;
}

/// @function sng_stop()
/// @description Stop whatever Song Sheets is playing. A song stopped part-way keeps the chunks it rendered, so
/// playing it again resumes the rendering rather than starting over. Safe to call at any time.
function sng_stop() {
    var _c = sng_audio_cache();
    if (_c.playing >= 0) audio_stop_sound(_c.playing);
    if (_c.queue >= 0) audio_free_play_queue(_c.queue);
    if (is_struct(_c.job)) { _c.job.queued = 0; _c.prep[$ _c.job.key] = _c.job; }
    _c.job = undefined;
    _c.playing = -1;
    _c.queue = -1;
    _c.song = undefined;
    _c.sched = [];
}

/// @function sng_is_playing()
/// @description True while a Song Sheets song is sounding.
function sng_is_playing() {
    var _c = sng_audio_cache();
    return _c.playing >= 0 && audio_is_playing(_c.playing);
}

/// @function sng_position()
/// @description Seconds into the current song since it started, or -1 when nothing is playing.
function sng_position() {
    if (!sng_is_playing()) return -1;
    return (get_timer() - sng_audio_cache().t0) / 1000000;
}

/// @function sng_playing_index()
/// @description The index of the note sounding right now, or -1.
function sng_playing_index() {
    var _t = sng_position();
    if (_t < 0) return -1;
    return sng_note_at(sng_audio_cache().sched, _t);
}

/// @function sng_save_wav(song, filename)
/// @description Write the song as a 16-bit mono PCM WAV (the same samples sng_play streams). Returns the number
/// of bytes written, or 0. Blocking, like sng_render.
function sng_save_wav(_song, _file) {
    if (!sng_is_song(_song) || !is_string(_file) || _file == "") return 0;
    var _r = sng_render(_song);
    if (!is_struct(_r)) return 0;
    var _w = buffer_create(44 + _r.bytes, buffer_fixed, 1);
    buffer_write(_w, buffer_u8, 82); buffer_write(_w, buffer_u8, 73); buffer_write(_w, buffer_u8, 70); buffer_write(_w, buffer_u8, 70);
    buffer_write(_w, buffer_u32, 36 + _r.bytes);
    buffer_write(_w, buffer_u8, 87); buffer_write(_w, buffer_u8, 65); buffer_write(_w, buffer_u8, 86); buffer_write(_w, buffer_u8, 69);
    buffer_write(_w, buffer_u8, 102); buffer_write(_w, buffer_u8, 109); buffer_write(_w, buffer_u8, 116); buffer_write(_w, buffer_u8, 32);
    buffer_write(_w, buffer_u32, 16);
    buffer_write(_w, buffer_u16, 1);                 // PCM
    buffer_write(_w, buffer_u16, 1);                 // mono
    buffer_write(_w, buffer_u32, _r.rate);
    buffer_write(_w, buffer_u32, _r.rate * 2);       // byte rate
    buffer_write(_w, buffer_u16, 2);                 // block align
    buffer_write(_w, buffer_u16, 16);                // bits
    buffer_write(_w, buffer_u8, 100); buffer_write(_w, buffer_u8, 97); buffer_write(_w, buffer_u8, 116); buffer_write(_w, buffer_u8, 97);
    buffer_write(_w, buffer_u32, _r.bytes);
    buffer_copy(_r.buffer, 0, _r.bytes, _w, 44);
    buffer_save(_w, _file);
    buffer_delete(_w);
    buffer_delete(_r.buffer);
    return 44 + _r.bytes;
}

/// @function sng_audio_free()
/// @description Stop playback and free every cached chunk. Call when the songbook closes, or never - a whole song
/// is small (a 12-second song is about 530 KB).
function sng_audio_free() {
    sng_stop();
    var _c = sng_audio_cache(), _i, _j;
    var _keys = variable_struct_get_names(_c.done);
    for (_i = 0; _i < array_length(_keys); _i++) {
        var _ch = _c.done[$ _keys[_i]].chunks;
        for (_j = 0; _j < array_length(_ch); _j++) if (buffer_exists(_ch[_j].buffer)) buffer_delete(_ch[_j].buffer);
    }
    var _pk = variable_struct_get_names(_c.prep);
    for (_i = 0; _i < array_length(_pk); _i++) {
        var _pc = _c.prep[$ _pk[_i]].chunks;
        for (_j = 0; _j < array_length(_pc); _j++) if (buffer_exists(_pc[_j].buffer)) buffer_delete(_pc[_j].buffer);
    }
    _c.done = {};
    _c.prep = {};
}
