/// sng_demo.gml - the demo room's book: a player's collection across all ten traditions.
///
/// Song Sheets - Every Song Engraved and Played, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function sng_demo_book()
/// @description A book of fourteen learned sheets covering every tradition. Most titles are GENERATED (pass no
/// title and sng_title writes one in the tradition's voice); two are authored, to show both paths.
function sng_demo_book() {
    var _b = sng_book_create();
    sng_book_learn(_b, "millers-daughter", "folk", "The Miller's Daughter");
    sng_book_learn(_b, "hours-of-ash", "chant");
    sng_book_learn(_b, "muster-vantre", "martial");
    sng_book_learn(_b, "nine-turns", "fae");
    sng_book_learn(_b, "quarry-binding", "spell");
    sng_book_learn(_b, "pavane-merrow", "courtly");
    sng_book_learn(_b, "salt-marsh", "lament");
    sng_book_learn(_b, "low-fields", "hymn");
    sng_book_learn(_b, "capstan", "sea");
    sng_book_learn(_b, "forge-tollmere", "work");
    sng_book_learn(_b, "harvest-reel", "folk");
    sng_book_learn(_b, "vespers-bell", "chant");
    sng_book_learn(_b, "the-drowned-bell", "spell", "The Drowned Bell");
    sng_book_learn(_b, "greywater", "lament");
    return _b;
}

/// @function sng_demo_new_id(n)
/// @description A fresh song id and tradition for the demo's LEARN key, cycling through the ten traditions so
/// every press shows a different kind of sheet. Pure.
function sng_demo_new_id(_n) {
    var _T = sng_traditions();
    return { id: "found-" + string(_n), tradition: _T[_n mod array_length(_T)] };
}
