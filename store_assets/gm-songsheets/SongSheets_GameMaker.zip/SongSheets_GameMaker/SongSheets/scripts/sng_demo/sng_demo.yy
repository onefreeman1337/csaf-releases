{
  "$GMScript": "v1",
  "%Name": "sng_demo",
  "name": "sng_demo",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}