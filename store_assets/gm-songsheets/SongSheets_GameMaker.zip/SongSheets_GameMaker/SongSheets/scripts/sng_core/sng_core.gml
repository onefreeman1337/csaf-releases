/// sng_core.gml - the song corpus and the melody engine. PURE GML: no drawing, no audio, no instances.
///
/// Song Sheets - Every Song Engraved and Played, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// A song id maps to exactly ONE melody, forever, on every machine and in every save. That is what makes a
/// printed plate meaningful - a plate is a picture OF a specific melody - and it is why nothing in this file
/// calls random(): every draw comes from a seeded generator whose stream is fixed by the id.
///
/// ⭐ FIDELITY. This is a port of the melody engine in Core Systems Asset Factory's RPG Maker MZ plugin
/// `Song Sheets`, and it is kept NOTE-FOR-NOTE identical to it: the same id and tradition give the same
/// pitches, starts and durations in both engines. That is tested, not assumed - the in-engine suite writes its
/// melodies out and they are compared against the shipped JavaScript as an oracle. Two consequences shape the
/// arithmetic below:
///   - the hash multiplies in DOUBLE precision on purpose, because the JavaScript does (`h * 16777619` there is
///     a float multiply that rounds above 2^53), and a "correct" 64-bit FNV would silently give every song a
///     different melody from the one the MZ plate shows;
///   - every rounding is done with `sng_jsround` (floor of x + 0.5), never GML's round(), whose tie rule is not
///     JavaScript's.
///
/// PUBLIC API (the header of each function says more):
///   sng_song(id, tradition, [tonic], [title])   -> a song struct (the whole musical truth of one song)
///   sng_traditions()                             -> the ten tradition keys, in catalogue order
///   sng_tradition(key)                           -> one tradition's definition, or undefined
///   sng_title(id, tradition)                     -> a generated title in the tradition's own voice
///   sng_is_song(value)                           -> true if value is a song struct from sng_song

#macro SNG_VERSION "1.0.0"
// ⛔ WRITTEN WITH A DECIMAL POINT ON PURPOSE. An integer literal above 2^31 compiles as an int64, and int64
// arithmetic here would silently turn the hash's DOUBLE multiply into an exact one - a different hash, so a
// different melody, from the MZ plate of the same song.
#macro SNG_U32 4294967296.0

/// @function sng_jsround(x)
/// @description JavaScript's Math.round: halves go UP (toward +infinity). Pure.
function sng_jsround(_x) { return floor(_x + 0.5); }

/// @function sng_u32(x)
/// @description An integer-valued real reduced to an unsigned 32-bit value, exactly as JavaScript's `>>> 0`
/// does (mathematical modulo, never negative). Pure.
function sng_u32(_x) {
    var _r = _x mod SNG_U32;
    if (_r < 0) _r += SNG_U32;
    return _r;
}

/// @function sng_i32(u)
/// @description An unsigned 32-bit value read as SIGNED, exactly as JavaScript's ToInt32. Pure.
function sng_i32(_u) { return (_u >= 2147483648) ? _u - SNG_U32 : _u; }

/// @function sng_imul(a, b)
/// @description JavaScript's Math.imul on two unsigned 32-bit values: the low 32 bits of the product, as an
/// unsigned value. Split into 16-bit halves so every partial product stays below 2^53 and is exact in a double.
function sng_imul(_a, _b) {
    var _ah = real(_a >> 16), _al = real(_a & 65535);
    var _bh = real(_b >> 16), _bl = real(_b & 65535);
    var _mid = (_ah * _bl + _al * _bh) mod 65536;
    return (_al * _bl + _mid * 65536) mod SNG_U32;
}

/// @function sng_hash(string)
/// @description The song-id hash (FNV-1a in the SAME double-precision arithmetic as the MZ plugin - see the
/// file header for why that matters). Returns an unsigned 32-bit value. Pure.
function sng_hash(_s) {
    _s = string(_s);
    var _h = 2166136261;
    var _n = string_length(_s);
    for (var _i = 1; _i <= _n; _i++) {
        var _x = real(sng_i32(real(_h ^ ord(string_char_at(_s, _i)))));
        _h = sng_u32(_x * 16777619.0);
    }
    return _h;
}

/// @function sng_rng(seed)
/// @description A mulberry32 generator seeded from an unsigned 32-bit value. Draw with sng_rng_next(). Pure.
function sng_rng(_seed) { return { a: sng_u32(floor(real(_seed))) }; }

/// @function sng_rng_next(rng)
/// @description The next draw in [0, 1). Advances the generator.
function sng_rng_next(_g) {
    _g.a = (_g.a + 1831565813) mod SNG_U32;
    var _t = _g.a;
    _t = sng_imul(real(_t ^ (_t >> 15)), real(_t | 1));
    var _m = sng_imul(real(_t ^ (_t >> 7)), real(_t | 61));
    _t = real(_t ^ ((_t + _m) mod SNG_U32));
    return real(_t ^ (_t >> 14)) / SNG_U32;
}

/// @function sng_pick(rng, array)
/// @description One element of an array, drawn from the generator (the MZ plugin's `pick`).
function sng_pick(_g, _arr) {
    var _n = array_length(_arr);
    return _arr[floor(sng_rng_next(_g) * _n) mod _n];
}

/// @function sng_modes()
/// @description Pitch-class offsets from the tonic for the seven church modes. Pure.
function sng_modes() {
    static _m = {
        ionian:     [0, 2, 4, 5, 7, 9, 11],
        dorian:     [0, 2, 3, 5, 7, 9, 10],
        phrygian:   [0, 1, 3, 5, 7, 8, 10],
        lydian:     [0, 2, 4, 6, 7, 9, 11],
        mixolydian: [0, 2, 4, 5, 7, 9, 10],
        aeolian:    [0, 2, 3, 5, 7, 8, 10],
        locrian:    [0, 1, 3, 5, 6, 8, 10]
    };
    return _m;
}

/// @function sng_traditions()
/// @description The ten tradition keys, in catalogue order. Pure.
function sng_traditions() {
    static _k = ["chant", "courtly", "folk", "martial", "lament", "fae", "hymn", "sea", "spell", "work"];
    return _k;
}

/// @function sng_tradition(key)
/// @description One tradition's definition: its name, mode, melodic CONTOUR (a genuinely different
/// construction per tradition, not one generator with different numbers), notation system, metre, range,
/// rhythmic density, ink, page furniture, instrument, tempo and detune. Returns undefined for an unknown key.
///
/// ⛔ A PALETTE IS NOT A COMPOSITION. The ten differ in STRUCTURE: `contour` selects a different melodic
/// construction and `notation` a different engraving system, so four-line red neumes cannot collide with a
/// percussion grid however the numbers fall.
function sng_tradition(_key) {
    static _T = {
        chant:   { name: "Plainchant",  mode: "dorian",     contour: "reciting",     notation: "neume",    meter: [0, 0], range: [57, 72], density: "long",   ink: "sepia",     furniture: "illuminated", timbre: "voice",   bpm: 56,  detune: 0,  mirror: false, lanes: undefined, call_lane: undefined },
        courtly: { name: "Courtly Air", mode: "ionian",     contour: "arch",         notation: "mensural", meter: [3, 2], range: [60, 79], density: "medium", ink: "iron",      furniture: "bordered",    timbre: "plucked", bpm: 76,  detune: 4,  mirror: false, lanes: undefined, call_lane: undefined },
        folk:    { name: "Reel",        mode: "mixolydian", contour: "period",       notation: "modern",   meter: [6, 8], range: [62, 81], density: "quick",  ink: "iron",      furniture: "plain",       timbre: "reed",    bpm: 132, detune: 6,  mirror: false, lanes: undefined, call_lane: undefined },
        martial: { name: "Muster Call", mode: "ionian",     contour: "fanfare",      notation: "grid",     meter: [4, 4], range: [55, 75], density: "blunt",  ink: "oxide",     furniture: "stamped",     timbre: "brass",   bpm: 104, detune: 0,  mirror: false, lanes: ["HORN", "DRUM", "TREAD"], call_lane: "CALL" },
        lament:  { name: "Lament",      mode: "phrygian",   contour: "descent",      notation: "modern",   meter: [4, 4], range: [53, 70], density: "long",   ink: "ash",       furniture: "mourning",    timbre: "bowed",   bpm: 48,  detune: 3,  mirror: false, lanes: undefined, call_lane: undefined },
        fae:     { name: "Fae Round",   mode: "lydian",     contour: "wander",       notation: "spiral",   meter: [5, 8], range: [64, 86], density: "quick",  ink: "verdigris", furniture: "thorned",     timbre: "bell",    bpm: 148, detune: 9,  mirror: false, lanes: undefined, call_lane: undefined },
        hymn:    { name: "Hymnal",      mode: "ionian",     contour: "chorale",      notation: "modern",   meter: [4, 4], range: [58, 76], density: "medium", ink: "iron",      furniture: "ruled",       timbre: "organ",   bpm: 66,  detune: 0,  mirror: false, lanes: undefined, call_lane: undefined },
        sea:     { name: "Shanty",      mode: "dorian",     contour: "callresponse", notation: "modern",   meter: [2, 2], range: [55, 74], density: "quick",  ink: "indigo",    furniture: "roped",       timbre: "voice",   bpm: 96,  detune: 7,  mirror: false, lanes: undefined, call_lane: undefined },
        spell:   { name: "Incantation", mode: "locrian",    contour: "palindrome",   notation: "neume",    meter: [0, 0], range: [59, 77], density: "medium", ink: "ember",     furniture: "sigilled",    timbre: "glass",   bpm: 60,  detune: 12, mirror: true,  lanes: undefined, call_lane: undefined },
        work:    { name: "Work Song",   mode: "aeolian",    contour: "hammer",       notation: "grid",     meter: [3, 4], range: [52, 69], density: "blunt",  ink: "ash",       furniture: "tallied",     timbre: "hammer",  bpm: 88,  detune: 2,  mirror: false, lanes: ["ANVIL", "BELLOWS", "STAMP"], call_lane: "VOICE" }
    };
    if (!is_string(_key)) return undefined;
    return variable_struct_exists(_T, _key) ? _T[$ _key] : undefined;
}

/// @function sng_density(key)
/// @description A tradition's duration vocabulary, in sixteenths. Pure.
function sng_density(_key) {
    static _D = {
        long:   [16, 12, 8, 8, 4],
        medium: [8, 8, 4, 4, 6, 2],
        quick:  [4, 4, 2, 2, 4, 8],
        blunt:  [8, 4, 4, 8, 16]
    };
    return variable_struct_exists(_D, _key) ? _D[$ _key] : _D.medium;
}

/// @function sng_degree_pitch(tonic, mode, degree)
/// @description A scale degree (any integer, negative allowed) as a MIDI pitch. Pure.
function sng_degree_pitch(_tonic, _mode, _degree) {
    var _tbl = sng_modes()[$ _mode];
    var _n = array_length(_tbl);
    var _oct = floor(_degree / _n);
    var _idx = ((_degree mod _n) + _n) mod _n;
    return _tonic + _tbl[_idx] + 12 * _oct;
}

/// @function sng_contour(kind, rng, n)
/// @description The ten melodic constructions. Each returns an array of n scale DEGREES. Pure but for the
/// generator it advances. ⛔ The ORDER of draws is part of the contract: it is what keeps every song id the
/// same melody as the MZ plugin's, so a refactor that reorders two draws changes every song in every save.
function sng_contour(_kind, _g, _n) {
    var _out = [], _i;
    switch (_kind) {
        case "reciting":
            // Chant: a reciting tone with occasional excursions, then a cadence down to the final.
            var _recite = 4;
            for (_i = 0; _i < _n; _i++) {
                var _u = sng_rng_next(_g);
                if (_u < 0.58) array_push(_out, _recite);
                else if (_u < 0.80) array_push(_out, _recite + ((sng_rng_next(_g) < 0.5) ? 1 : -1));
                else if (_u < 0.93) array_push(_out, _recite + ((sng_rng_next(_g) < 0.5) ? 2 : -2));
                else array_push(_out, _recite - 3);
            }
            _out[_n - 2] = 1; _out[_n - 1] = 0;
            return _out;

        case "arch":
            // Courtly: a rising arch that peaks near the middle and returns.
            for (_i = 0; _i < _n; _i++) {
                var _t = _i / (_n - 1);
                var _base = sng_jsround(7 * sin(pi * _t));
                var _orn = 0;
                if (sng_rng_next(_g) < 0.35) _orn = (sng_rng_next(_g) < 0.5) ? 1 : -1;
                array_push(_out, _base + _orn);
            }
            _out[_n - 1] = 0;
            return _out;

        case "period":
            // Folk: two periods, the second answering the first. ⛔ The first period is a TURN over a chord
            // skeleton, not independent draws - independent draws produce RUNS, and a run is not a melody.
            var _SK = [[0, 2, 4, 2], [4, 2, 0, 4], [2, 4, 5, 2], [0, 4, 2, 5]];
            var _sk = _SK[floor(sng_rng_next(_g) * 4) mod 4];
            var _PASS = [1, -1, 2];
            var _prot = floor(sng_rng_next(_g) * 3) mod 3;
            var _half = floor(_n / 2), _a = [];
            for (_i = 0; _i < _half; _i++) {
                var _tone = _sk[_i mod 4];
                array_push(_a, (_i mod 2 == 0) ? _tone : _tone + _PASS[(floor(_i / 2) + _prot) mod 3]);
            }
            for (_i = 0; _i < _half; _i++) array_push(_out, _a[_i]);
            for (_i = 0; _i < _n - _half; _i++) {
                var _src = _a[_i mod array_length(_a)];
                if (_i == _n - _half - 1) array_push(_out, 0);
                else array_push(_out, _src + ((sng_rng_next(_g) < 0.5) ? 0 : 2));
            }
            return _out;

        case "fanfare":
            // Martial: a bugle call is a FIGURE, not a draw from the triad - a figure cannot collapse to two
            // pitches, and a call has to be recognised across a field.
            var _FIG = [[0, 0, 2, 4, 2, 0], [4, 2, 0, 2, 4, 7], [0, 2, 4, 7, 4, 2], [7, 4, 2, 4, 2, 0]];
            var _fig = _FIG[floor(sng_rng_next(_g) * 4) mod 4];
            var _rot = floor(sng_rng_next(_g) * 6) mod 6;
            for (_i = 0; _i < _n; _i++) {
                array_push(_out, _fig[(_i + _rot) mod 6]);
                if (sng_rng_next(_g) < 0.22 && array_length(_out) < _n) array_push(_out, _out[array_length(_out) - 1]);
            }
            array_resize(_out, _n);
            _out[_n - 2] = 4;   // the fifth...
            _out[_n - 1] = 0;   // ...falling to the tonic: a fanfare resolves
            return _out;

        case "descent":
            // Lament: a stepwise descent with sighs, restarting higher each time.
            var _cur = 7;
            for (_i = 0; _i < _n; _i++) {
                array_push(_out, _cur);
                _cur -= (sng_rng_next(_g) < 0.75) ? 1 : 2;
                if (_cur < 0) _cur = 5 + floor(sng_rng_next(_g) * 2);
            }
            _out[_n - 1] = 0;
            return _out;

        case "wander":
            // Fae: a ROUND. It never settles on the final - but the last note lands a step from the first, so
            // the loop can come round again without a break.
            var _c = 4, _STEP = [-4, -3, 2, 3, 4, 6];
            for (_i = 0; _i < _n; _i++) {
                array_push(_out, _c);
                _c += _STEP[floor(sng_rng_next(_g) * 6) mod 6];
                if (_c > 11) _c -= 7;
                if (_c < -2) _c += 7;
            }
            _out[_n - 1] = _out[0] + ((sng_rng_next(_g) < 0.5) ? 1 : -1);
            return _out;

        case "chorale":
            // Hymn: four square phrases, each cadencing on a chord tone - leave, wander, return, arrive.
            var _phrase = max(2, sng_jsround(_n / 4));
            var _CAD = [4, 2, 4, 0];
            for (_i = 0; _i < _n; _i++) {
                var _p = min(3, floor(_i / _phrase));
                if (((_i + 1) mod _phrase) == 0) array_push(_out, _CAD[_p]);
                else array_push(_out, 1 + floor(sng_rng_next(_g) * 5));
            }
            _out[_n - 1] = 0;
            return _out;

        case "callresponse":
            // Shanty: a varying leader's call against a FIXED, literally repeated crew refrain.
            var _REF = [4, 2, 1, 0];
            while (array_length(_out) < _n) {
                var _call = 2 + floor(sng_rng_next(_g) * 2);
                for (var _k = 0; _k < _call && array_length(_out) < _n; _k++) array_push(_out, 2 + floor(sng_rng_next(_g) * 5));
                for (var _j = 0; _j < 4 && array_length(_out) < _n; _j++) array_push(_out, _REF[_j]);
            }
            array_resize(_out, _n);
            _out[_n - 1] = 0;
            return _out;

        case "palindrome":
            // Incantation: a phrase and its exact retrograde. The first half is a seeded SHUFFLE of the mode's
            // degrees, so it is all-distinct by construction and cannot fall into a two-note cycle.
            var _hf = ceil(_n / 2);
            var _pool = [-1, 0, 1, 2, 3, 4, 5, 6];
            for (_i = 7; _i > 0; _i--) {
                var _jj = floor(sng_rng_next(_g) * (_i + 1)) mod (_i + 1);
                var _tmp = _pool[_i]; _pool[_i] = _pool[_jj]; _pool[_jj] = _tmp;
            }
            var _h = [];
            for (_i = 0; _i < _hf; _i++) array_push(_h, _pool[_i mod 8] + ((_i >= 8) ? 7 : 0));
            for (_i = 0; _i < _hf; _i++) array_push(_out, _h[_i]);
            for (_i = _n - _hf - 1; _i >= 0; _i--) array_push(_out, _h[_i]);
            array_resize(_out, _n);
            return _out;

        case "hammer":
            // Work song: a struck anchor alternating with a varying answer. The answer walks a fixed figure,
            // rotated by the seed - an ornament that landed inside its own vocabulary once collapsed this to
            // three pitches, so there is none.
            var _FG = [[2, 4, 3, 6, 5, 3], [3, 5, 4, 2, 6, 4], [2, 3, 5, 6, 4, 5]];
            var _f = _FG[floor(sng_rng_next(_g) * 3) mod 3];
            var _r = floor(sng_rng_next(_g) * 6) mod 6;
            var _cycle = 3 + floor(sng_rng_next(_g) * 3);
            var _phase = floor(sng_rng_next(_g) * _cycle);
            var _kk = 0, _strike = 0, _lift = floor(_n * 0.66);
            for (_i = 0; _i < _n; _i++) {
                if (_i mod 2 == 0) {
                    array_push(_out, (((_strike + _phase) mod _cycle) == 0) ? 4 : 0);
                    _strike++;
                } else {
                    array_push(_out, _f[(_kk + _r) mod 6] + ((_i >= _lift) ? 1 : 0));
                    _kk++;
                }
            }
            _out[_n - 1] = 0;
            return _out;
    }
    // unknown contour: a plain descent to the final, so a caller still gets a melody rather than a crash
    for (_i = 0; _i < _n; _i++) array_push(_out, _n - 1 - _i);
    return _out;
}

/// @function sng_song(id, tradition, [tonic], [title])
/// @description THE WHOLE MUSICAL TRUTH OF ONE SONG, in one deterministic call. `id` is any string (it IS the
/// seed); `tradition` one of sng_traditions() (an unknown one falls back to "folk" and says so in `.fallback`);
/// `tonic` a MIDI note (default 62); `title` what the plate prints (default: a generated title, sng_title).
/// Returns a struct: song_id, tradition, tradition_name, mode, notation, meter [beats, unit], ink, furniture,
/// timbre, bpm, detune, lanes, call_lane, tonic, title, notes (array of {pitch, start, dur, degree}, starts and
/// durations in sixteenths), total_sixteenths.
function sng_song(_id, _trad, _tonic = 62, _title = undefined) {
    _id = string(_id);
    var _fallback = false;
    var _T = sng_tradition(_trad);
    if (_T == undefined) { _trad = "folk"; _T = sng_tradition("folk"); _fallback = true; }
    if (!is_real(_tonic) && !is_int32(_tonic) && !is_int64(_tonic)) _tonic = 62;
    _tonic = clamp(floor(_tonic), 24, 96);

    var _g = sng_rng(sng_hash(_id + "|" + _trad));
    var _n = 14 + floor(sng_rng_next(_g) * 6);                // 14-19 notes
    var _deg = sng_contour(_T.contour, _g, _n);
    var _durs = sng_density(_T.density);

    // durations are drawn FIRST so a tradition can mirror them: an incantation whose pitches read the same
    // backwards but whose rhythm does not is only half a palindrome
    var _picked = array_create(array_length(_deg), 0), _i;
    for (_i = 0; _i < array_length(_deg); _i++) _picked[_i] = sng_pick(_g, _durs);
    if (_T.mirror) {
        var _m = array_length(_deg);
        for (_i = 0; _i < _m; _i++) _picked[_i] = _picked[min(_i, _m - 1 - _i)];
    }

    var _notes = [], _at = 0;
    for (_i = 0; _i < array_length(_deg); _i++) {
        var _p = sng_degree_pitch(_tonic, _T.mode, _deg[_i]);
        // FOLD into the tradition's tessitura rather than clamping - a clamp flattens a contour into a plateau
        while (_p > _T.range[1]) _p -= 12;
        while (_p < _T.range[0]) _p += 12;
        array_push(_notes, { pitch: _p, start: _at, dur: _picked[_i], degree: _deg[_i] });
        _at += _picked[_i];
    }
    return {
        sng_kind: "song",
        song_id: _id,
        tradition: _trad,
        tradition_name: _T.name,
        mode: _T.mode,
        notation: _T.notation,
        meter: [_T.meter[0], _T.meter[1]],
        ink: _T.ink,
        furniture: _T.furniture,
        timbre: _T.timbre,
        bpm: _T.bpm,
        detune: _T.detune,
        lanes: _T.lanes,
        call_lane: _T.call_lane,
        tonic: _tonic,
        title: is_string(_title) && _title != "" ? _title : sng_title(_id, _trad),
        notes: _notes,
        total_sixteenths: _at,
        fallback: _fallback
    };
}

/// @function sng_is_song(value)
/// @description True if value is a song struct made by sng_song. Pure.
function sng_is_song(_v) {
    return is_struct(_v) && variable_struct_exists(_v, "sng_kind") && _v.sng_kind == "song"
        && is_array(_v.notes) && array_length(_v.notes) > 0;
}

/// @function sng_title(id, tradition)
/// @description A title for a song nobody named, written in its tradition's own voice ("The Miller's
/// Daughter", "Hymn of the Low Fields", "Nine Turns Widdershins"). Drawn from its OWN generator stream, so
/// naming a song never changes its melody. Pure.
function sng_title(_id, _trad) {
    static _W = {
        noun:   ["Miller", "Weaver", "Ferryman", "Shepherd", "Tanner", "Cooper", "Smith", "Fowler", "Carter", "Reeve", "Warden", "Pilgrim", "Harper", "Collier", "Thatcher", "Chandler"],
        kin:    ["Daughter", "Son", "Widow", "Bride", "Lament", "Fancy", "Return", "Wager", "Farewell", "Lantern"],
        place:  ["Ashford", "Vantre", "Holloway", "Caddon", "Merrow", "the Low Fields", "the Salt Marsh", "Greywater", "Tollmere", "Brackenridge", "the North Road", "Sallow Hill"],
        thing:  ["Hours", "Ashes", "Lanterns", "Waters", "Bells", "Candles", "Fields", "Wells", "Stones", "Swallows", "Embers", "Rushes"],
        sea:    ["Anchor", "Mainsail", "Bowline", "Capstan", "Tide", "Harbour Light", "Grey Gull", "Long Haul"],
        num:    ["Three", "Five", "Seven", "Nine", "Twelve"],
        fae:    ["Turns Widdershins", "Rings of Moss", "Doors in the Hill", "Stars Under Water", "Steps Backward", "Knots of Briar"],
        spell:  ["Binding", "Warding", "Opening", "Unmaking", "Calling", "Sealing"],
        spellx: ["the Quarry", "the Well", "the Ninth Gate", "the Red Door", "the Drowned Bell", "the Mirror"],
        muster: ["Muster at", "Call to Arms at", "Reveille at", "Last Post at", "Rally at"],
        work:   ["Hammer Song of", "Forge Song of", "Anvil Round of", "Haul Song of", "Stamp Song of"],
        courtly: ["Pavane for", "Galliard for", "Air for", "Alman for", "Basse Danse for"],
        lady:   ["Lady Merrow", "the Queen of Tollmere", "Lord Caddon", "the Countess Vale", "Sir Ambry", "the Duke of Ashford"]
    };
    var _g = sng_rng(sng_hash(string(_id) + "|title|" + string(_trad)));
    switch (_trad) {
        case "chant":   return sng_pick(_g, ["Hymn of the ", "Office of the ", "Antiphon of the ", "Vespers of the "]) + sng_pick(_g, _W.thing);
        case "courtly": return sng_pick(_g, _W.courtly) + " " + sng_pick(_g, _W.lady);
        case "folk":    return "The " + sng_pick(_g, _W.noun) + "'s " + sng_pick(_g, _W.kin);
        case "martial": return sng_pick(_g, _W.muster) + " " + sng_pick(_g, _W.place);
        case "lament":  return "Lament for " + sng_pick(_g, _W.place);
        case "fae":     return sng_pick(_g, _W.num) + " " + sng_pick(_g, _W.fae);
        case "hymn":    return "Hymn " + string(1 + (sng_hash(string(_id)) mod 700)) + ", " + sng_pick(_g, _W.place);
        case "sea":     return "Haul on the " + sng_pick(_g, _W.sea);
        case "spell":   return "The " + sng_pick(_g, _W.spell) + " of " + sng_pick(_g, _W.spellx);
        case "work":    return sng_pick(_g, _W.work) + " " + sng_pick(_g, _W.place);
    }
    return "The " + sng_pick(_g, _W.noun) + "'s " + sng_pick(_g, _W.kin);
}

/// @function sng_bar_sixteenths(meter)
/// @description Sixteenths in one bar of a metre; 0 for unmetered music (plainchant has no barlines because
/// plainchant genuinely has none, not because they were skipped). Pure.
function sng_bar_sixteenths(_meter) {
    if (!is_array(_meter) || array_length(_meter) < 2 || _meter[0] == 0 || _meter[1] == 0) return 0;
    return _meter[0] * (16 / _meter[1]);
}

/// @function sng_staff_step(pitch)
/// @description A MIDI pitch as a diatonic staff position (white-key steps). Pure.
function sng_staff_step(_pitch) {
    static _pc = [0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5, 6];
    var _p = floor(_pitch);
    return floor(_p / 12) * 7 + _pc[((_p mod 12) + 12) mod 12];
}

/// @function sng_is_altered(pitch)
/// @description True for a black-key pitch. Pure.
function sng_is_altered(_pitch) {
    var _c = ((floor(_pitch) mod 12) + 12) mod 12;
    return _c == 1 || _c == 3 || _c == 6 || _c == 8 || _c == 10;
}

/// @function sng_spelling(tonic, mode)
/// @description How a mode on a tonic is SPELLED: each of its seven degrees gets its own letter name, starting
/// from the tonic's, and the accidental that letter needs. Returns {letter: [12], acc: [12], key: [{letter, acc}],
/// sharps, flats} where letter/acc are indexed by pitch class (-1 / 0 for a pitch class outside the mode) and
/// letters count C=0 .. B=6. Pure.
///
/// ⛔ WHY THIS EXISTS. The first engraving mapped every black key to the white key BELOW it and drew a FLAT in
/// front, so D mixolydian's F-sharp was printed as an F-flat and D phrygian's E-flat sat on the D line: every
/// accidental on every plate was a different note from the one that sounded, which is the first thing a musician
/// reads. Diatonic spelling - one letter per degree - is the rule an engraver follows, and it is what lets the
/// plate carry a real KEY SIGNATURE instead of an accidental in front of every note.
function sng_spelling(_tonic, _mode) {
    static _NAT = [0, 2, 4, 5, 7, 9, 11];
    // enumerate the KINDS of bad input, not just the range: a non-number tonic and a non-string mode refuse to
    // a usable spelling rather than throwing inside the buyer's draw event
    if (!is_numeric(_tonic)) _tonic = 62;
    if (!is_string(_mode) || !variable_struct_exists(sng_modes(), _mode)) _mode = "ionian";
    var _tbl = sng_modes()[$ _mode];
    var _tp = ((floor(_tonic) mod 12) + 12) mod 12;
    var _tl = -1, _i;
    for (_i = 0; _i < 7; _i++) if (_NAT[_i] == _tp) _tl = _i;
    if (_tl < 0) {
        // a black-key tonic: sharp-side modes take the letter below, flat-side modes the letter above
        var _sharpish = (_mode == "ionian" || _mode == "lydian" || _mode == "mixolydian");
        for (_i = 0; _i < 7; _i++) {
            if (_sharpish && _NAT[_i] == _tp - 1) _tl = _i;
            if (!_sharpish && _NAT[_i] == (_tp + 1) mod 12) _tl = _i;
        }
    }
    var _letter = array_create(12, -1), _acc = array_create(12, 0), _key = [], _ns = 0, _nf = 0;
    for (var _d = 0; _d < 7; _d++) {
        var _L = (_tl + _d) mod 7;
        var _pc = (_tp + _tbl[_d]) mod 12;
        var _a = ((_pc - _NAT[_L] + 18) mod 12) - 6;
        _letter[_pc] = _L; _acc[_pc] = _a;
        if (_a != 0) array_push(_key, { letter: _L, acc: _a });
        if (_a > 0) _ns++;
        if (_a < 0) _nf++;
    }
    return { letter: _letter, acc: _acc, key: _key, sharps: _ns, flats: _nf };
}

/// @function sng_spelled_step(pitch, spelling)
/// @description A pitch's staff position (octave * 7 + letter) under a spelling, so an F-sharp sits on the F line
/// and an E-flat on the E line. A pitch class outside the mode falls back to the white key below. Pure.
function sng_spelled_step(_pitch, _sp) {
    var _p = floor(_pitch), _pc = ((_p mod 12) + 12) mod 12;
    if (!is_struct(_sp) || _sp.letter[_pc] < 0) return sng_staff_step(_p);
    var _nat = _p - _sp.acc[_pc];
    return floor(_nat / 12) * 7 + _sp.letter[_pc];
}
