/// sng_draw.gml - the drawing primitives the engraver is built from: thick segments with round joins, filled
/// convex shapes, rotated ellipses and rings, soft radial spots, tapered pen strokes, and sized type.
///
/// Song Sheets - Every Song Engraved and Played, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ TWO FACTS ABOUT THIS RENDERER DECIDE EVERYTHING BELOW:
///   1. It has NO ANTIALIASING and `draw_line_width` floors every stroke at one pixel. So a stroke thinner than a
///      pixel is drawn as a one-pixel line at a proportionally lower ALPHA, and every plate the product shows is
///      rendered SUPERSAMPLED (sng_plate draws at 2x and filters down) - that, not a thicker pen, is what makes
///      a stave line read as engraved rather than as a staircase.
///   2. `draw_vertex_colour` carries its own alpha and IGNORES draw_set_alpha, so every primitive here takes
///      its alpha as an argument rather than trusting the global one.
/// Every function draws into whatever target is current (the GUI layer, a surface) and leaves the draw
/// colour, alpha, font and alignment as it found them wherever it changes them.

/// @function sng_rgb(hex)
/// @description A "#RRGGBB" string as a GameMaker colour. Pure. A malformed string returns c_black, never a
/// half-parsed colour.
function sng_rgb(_hex) {
    if (!is_string(_hex) || string_length(_hex) != 7 || string_char_at(_hex, 1) != "#") return c_black;
    var _v = 0, _digits = "0123456789ABCDEF";
    for (var _i = 2; _i <= 7; _i++) {
        var _d = string_pos(string_upper(string_char_at(_hex, _i)), _digits) - 1;
        if (_d < 0) return c_black;
        _v = _v * 16 + _d;
    }
    return make_colour_rgb((_v >> 16) & 255, (_v >> 8) & 255, _v & 255);
}

/// @function sng_mix(a, b, t)
/// @description Blend two colours, t in 0..1. Pure.
function sng_mix(_a, _b, _t) { return merge_colour(_a, _b, clamp(_t, 0, 1)); }

/// @function sng_seg(x1, y1, x2, y2, w, colour, [alpha])
/// @description A straight stroke `w` pixels wide. Below one pixel it is drawn one pixel wide at alpha * w,
/// which is how a sub-pixel line reads on a display that cannot draw one.
function sng_seg(_x1, _y1, _x2, _y2, _w, _col, _alpha = 1) {
    var _dx = _x2 - _x1, _dy = _y2 - _y1;
    var _len = sqrt(_dx * _dx + _dy * _dy);
    if (_len <= 0) return;
    var _a = _alpha, _ww = _w;
    if (_w < 1) { _a = _alpha * max(0.15, _w); _ww = 1; }
    var _nx = -_dy / _len * _ww * 0.5, _ny = _dx / _len * _ww * 0.5;
    draw_primitive_begin(pr_trianglestrip);
    draw_vertex_colour(_x1 + _nx, _y1 + _ny, _col, _a);
    draw_vertex_colour(_x1 - _nx, _y1 - _ny, _col, _a);
    draw_vertex_colour(_x2 + _nx, _y2 + _ny, _col, _a);
    draw_vertex_colour(_x2 - _nx, _y2 - _ny, _col, _a);
    draw_primitive_end();
}

/// @function sng_disc(x, y, r, colour, [alpha])
/// @description A filled circle, segment count scaled with its radius so a large disc is round and a small
/// one is cheap.
function sng_disc(_x, _y, _r, _col, _alpha = 1) {
    if (_r <= 0) return;
    var _n = clamp(ceil(_r * 1.4), 8, 64);
    draw_primitive_begin(pr_trianglefan);
    draw_vertex_colour(_x, _y, _col, _alpha);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n * 2 * pi;
        draw_vertex_colour(_x + cos(_t) * _r, _y + sin(_t) * _r, _col, _alpha);
    }
    draw_primitive_end();
}

/// @function sng_spot(x, y, r, colour, alpha)
/// @description A soft radial spot: full alpha at the centre falling LINEARLY to nothing at the rim (a fan
/// whose rim vertices carry alpha 0). Used for foxing, glows and the playhead.
function sng_spot(_x, _y, _r, _col, _alpha) {
    if (_r <= 0) return;
    var _n = clamp(ceil(_r * 0.8), 12, 48);
    draw_primitive_begin(pr_trianglefan);
    draw_vertex_colour(_x, _y, _col, _alpha);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n * 2 * pi;
        draw_vertex_colour(_x + cos(_t) * _r, _y + sin(_t) * _r, _col, 0);
    }
    draw_primitive_end();
}

/// @function sng_polyline(pts, w, colour, [alpha], [closed])
/// @description A stroke through a flat array of points [x0, y0, x1, y1, ...]. Joins are filled with a disc
/// of the stroke's own radius: `draw_line_width`-style segments are butt-ended, and two meeting at an angle
/// leave a notch of bare paper on the outside of every turn.
function sng_polyline(_pts, _w, _col, _alpha = 1, _closed = false) {
    var _n = array_length(_pts) div 2;
    if (_n < 2) return;
    for (var _i = 0; _i < _n - 1; _i++) {
        sng_seg(_pts[_i * 2], _pts[_i * 2 + 1], _pts[_i * 2 + 2], _pts[_i * 2 + 3], _w, _col, _alpha);
    }
    if (_closed) sng_seg(_pts[_n * 2 - 2], _pts[_n * 2 - 1], _pts[0], _pts[1], _w, _col, _alpha);
    if (_w >= 2 && _alpha >= 0.999) {
        var _from = _closed ? 0 : 1, _to = _closed ? _n : _n - 1;
        for (var _j = _from; _j < _to; _j++) sng_disc(_pts[_j * 2], _pts[_j * 2 + 1], _w * 0.5, _col, _alpha);
    }
}

/// @function sng_fill_convex(pts, colour, [alpha])
/// @description Fill a CONVEX outline (flat array of points) as a triangle fan. ⛔ A fan spans a concavity
/// silently, so this is only ever handed shapes that are convex by construction (noteheads, beams, neumes,
/// discs); anything concave is built from strips instead.
function sng_fill_convex(_pts, _col, _alpha = 1) {
    var _n = array_length(_pts) div 2;
    if (_n < 3) return;
    draw_primitive_begin(pr_trianglefan);
    for (var _i = 0; _i < _n; _i++) draw_vertex_colour(_pts[_i * 2], _pts[_i * 2 + 1], _col, _alpha);
    draw_primitive_end();
}

/// @function sng_ellipse_pts(cx, cy, rx, ry, rot, n)
/// @description n points round a rotated ellipse, as a flat array. Pure.
function sng_ellipse_pts(_cx, _cy, _rx, _ry, _rot, _n) {
    var _out = array_create(_n * 2, 0);
    var _c = cos(_rot), _s = sin(_rot);
    for (var _i = 0; _i < _n; _i++) {
        var _t = _i / _n * 2 * pi;
        var _ex = cos(_t) * _rx, _ey = sin(_t) * _ry;
        _out[_i * 2] = _cx + _ex * _c - _ey * _s;
        _out[_i * 2 + 1] = _cy + _ex * _s + _ey * _c;
    }
    return _out;
}

/// @function sng_ring(cx, cy, rx, ry, rot, lw, colour, [alpha])
/// @description The outline of a rotated ellipse as a strip between an inner and an outer ellipse - exact,
/// where a stroked polyline would show a faceted rim at a notehead's size.
function sng_ring(_cx, _cy, _rx, _ry, _rot, _lw, _col, _alpha = 1) {
    var _n = clamp(ceil(max(_rx, _ry) * 2), 16, 72);
    var _c = cos(_rot), _s = sin(_rot), _h = _lw * 0.5;
    draw_primitive_begin(pr_trianglestrip);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n * 2 * pi;
        var _ox = cos(_t) * (_rx + _h), _oy = sin(_t) * (_ry + _h);
        var _ix = cos(_t) * max(0, _rx - _h), _iy = sin(_t) * max(0, _ry - _h);
        draw_vertex_colour(_cx + _ox * _c - _oy * _s, _cy + _ox * _s + _oy * _c, _col, _alpha);
        draw_vertex_colour(_cx + _ix * _c - _iy * _s, _cy + _ix * _s + _iy * _c, _col, _alpha);
    }
    draw_primitive_end();
}

/// @function sng_bezier(x0, y0, x1, y1, x2, y2, x3, y3, n, [out])
/// @description Sample a cubic bezier into n+1 points, appended to `out` (a flat array; a new one if omitted).
/// Returns the array. Pure.
function sng_bezier(_x0, _y0, _x1, _y1, _x2, _y2, _x3, _y3, _n, _out = undefined) {
    if (!is_array(_out)) _out = [];
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n, _u = 1 - _t;
        var _a = _u * _u * _u, _b = 3 * _u * _u * _t, _c = 3 * _u * _t * _t, _d = _t * _t * _t;
        array_push(_out, _a * _x0 + _b * _x1 + _c * _x2 + _d * _x3, _a * _y0 + _b * _y1 + _c * _y2 + _d * _y3);
    }
    return _out;
}

/// @function sng_catmull(ctrl, per)
/// @description A smooth curve THROUGH every control point (Catmull-Rom), `per` samples per span, as a flat
/// array. Used for hand-authored letterforms like the clef, whose shape is easiest to state as points it
/// passes through. Pure.
function sng_catmull(_c, _per) {
    var _n = array_length(_c) div 2, _out = [];
    if (_n < 2) return _out;
    for (var _i = 0; _i < _n - 1; _i++) {
        var _i0 = max(0, _i - 1), _i3 = min(_n - 1, _i + 2);
        var _p0x = _c[_i0 * 2], _p0y = _c[_i0 * 2 + 1];
        var _p1x = _c[_i * 2], _p1y = _c[_i * 2 + 1];
        var _p2x = _c[_i * 2 + 2], _p2y = _c[_i * 2 + 3];
        var _p3x = _c[_i3 * 2], _p3y = _c[_i3 * 2 + 1];
        for (var _k = (_i == 0) ? 0 : 1; _k <= _per; _k++) {
            var _t = _k / _per, _t2 = _t * _t, _t3 = _t2 * _t;
            array_push(_out,
                0.5 * (2 * _p1x + (-_p0x + _p2x) * _t + (2 * _p0x - 5 * _p1x + 4 * _p2x - _p3x) * _t2 + (-_p0x + 3 * _p1x - 3 * _p2x + _p3x) * _t3),
                0.5 * (2 * _p1y + (-_p0y + _p2y) * _t + (2 * _p0y - 5 * _p1y + 4 * _p2y - _p3y) * _t2 + (-_p0y + 3 * _p1y - 3 * _p2y + _p3y) * _t3));
        }
    }
    return _out;
}

/// @function sng_pen(pts, wmin, wmax, nib, colour, [alpha], [taper])
/// @description A BROAD-NIB stroke through a flat array of points: the width at each point is set by the
/// direction the pen travels against a fixed nib angle (radians), so a clef's downstroke swells and its
/// hairlines stay hairlines - the stress an engraver cuts. `taper` thins both ends over that fraction of the
/// length. Built as ONE triangle strip plus a disc at every interior point, so it has no notches and a
/// crossing stroke simply overprints itself.
function sng_pen(_p, _wmin, _wmax, _nib, _col, _alpha = 1, _taper = 0) {
    var _n = array_length(_p) div 2;
    if (_n < 2) return;
    var _w = array_create(_n, _wmin), _i;
    for (_i = 0; _i < _n; _i++) {
        var _a = max(0, _i - 1), _b = min(_n - 1, _i + 1);
        var _tx = _p[_b * 2] - _p[_a * 2], _ty = _p[_b * 2 + 1] - _p[_a * 2 + 1];
        var _ang = arctan2(_ty, _tx);
        var _ww = _wmin + (_wmax - _wmin) * abs(sin(_ang - _nib));
        if (_taper > 0) {
            var _f = _i / (_n - 1);
            _ww *= clamp(min(_f, 1 - _f) / _taper, 0.25, 1);
        }
        _w[_i] = _ww;
    }
    draw_primitive_begin(pr_trianglestrip);
    for (_i = 0; _i < _n; _i++) {
        var _a2 = max(0, _i - 1), _b2 = min(_n - 1, _i + 1);
        var _dx = _p[_b2 * 2] - _p[_a2 * 2], _dy = _p[_b2 * 2 + 1] - _p[_a2 * 2 + 1];
        var _l = max(0.0001, sqrt(_dx * _dx + _dy * _dy));
        var _nx = -_dy / _l * _w[_i] * 0.5, _ny = _dx / _l * _w[_i] * 0.5;
        draw_vertex_colour(_p[_i * 2] + _nx, _p[_i * 2 + 1] + _ny, _col, _alpha);
        draw_vertex_colour(_p[_i * 2] - _nx, _p[_i * 2 + 1] - _ny, _col, _alpha);
    }
    draw_primitive_end();
    for (_i = 1; _i < _n - 1; _i++) if (_w[_i] >= 2) sng_disc(_p[_i * 2], _p[_i * 2 + 1], _w[_i] * 0.5, _col, _alpha);
}

/// @function sng_rect_fill(x, y, w, h, colour, [alpha])
/// @description A filled axis-aligned rectangle with its own alpha.
function sng_rect_fill(_x, _y, _w, _h, _col, _alpha = 1) {
    if (_w <= 0 || _h <= 0) return;
    draw_primitive_begin(pr_trianglestrip);
    draw_vertex_colour(_x, _y, _col, _alpha);
    draw_vertex_colour(_x + _w, _y, _col, _alpha);
    draw_vertex_colour(_x, _y + _h, _col, _alpha);
    draw_vertex_colour(_x + _w, _y + _h, _col, _alpha);
    draw_primitive_end();
}

/// @function sng_rect_line(x, y, w, h, lw, colour, [alpha])
/// @description A rectangle outline `lw` wide, drawn INSIDE the given rect so it never bleeds past it.
function sng_rect_line(_x, _y, _w, _h, _lw, _col, _alpha = 1) {
    var _t = max(1, _lw), _a = (_lw < 1) ? _alpha * max(0.15, _lw) : _alpha;
    sng_rect_fill(_x, _y, _w, _t, _col, _a);
    sng_rect_fill(_x, _y + _h - _t, _w, _t, _col, _a);
    sng_rect_fill(_x, _y + _t, _t, _h - _t * 2, _col, _a);
    sng_rect_fill(_x + _w - _t, _y + _t, _t, _h - _t * 2, _col, _a);
}

/// @function sng_edge_shade(x, y, w, h, depth, colour, alpha)
/// @description Darken the four edges of a rect with a soft inward fade `depth` pixels deep - the handled,
/// aged margin of a real sheet.
function sng_edge_shade(_x, _y, _w, _h, _d, _col, _alpha) {
    _d = min(_d, _w * 0.5, _h * 0.5);
    draw_primitive_begin(pr_trianglelist);
    // top
    draw_vertex_colour(_x, _y, _col, _alpha); draw_vertex_colour(_x + _w, _y, _col, _alpha); draw_vertex_colour(_x + _w - _d, _y + _d, _col, 0);
    draw_vertex_colour(_x, _y, _col, _alpha); draw_vertex_colour(_x + _w - _d, _y + _d, _col, 0); draw_vertex_colour(_x + _d, _y + _d, _col, 0);
    // bottom
    draw_vertex_colour(_x, _y + _h, _col, _alpha); draw_vertex_colour(_x + _d, _y + _h - _d, _col, 0); draw_vertex_colour(_x + _w - _d, _y + _h - _d, _col, 0);
    draw_vertex_colour(_x, _y + _h, _col, _alpha); draw_vertex_colour(_x + _w - _d, _y + _h - _d, _col, 0); draw_vertex_colour(_x + _w, _y + _h, _col, _alpha);
    // left
    draw_vertex_colour(_x, _y, _col, _alpha); draw_vertex_colour(_x + _d, _y + _d, _col, 0); draw_vertex_colour(_x + _d, _y + _h - _d, _col, 0);
    draw_vertex_colour(_x, _y, _col, _alpha); draw_vertex_colour(_x + _d, _y + _h - _d, _col, 0); draw_vertex_colour(_x, _y + _h, _col, _alpha);
    // right
    draw_vertex_colour(_x + _w, _y, _col, _alpha); draw_vertex_colour(_x + _w, _y + _h, _col, _alpha); draw_vertex_colour(_x + _w - _d, _y + _h - _d, _col, 0);
    draw_vertex_colour(_x + _w, _y, _col, _alpha); draw_vertex_colour(_x + _w - _d, _y + _h - _d, _col, 0); draw_vertex_colour(_x + _w - _d, _y + _d, _col, 0);
    draw_primitive_end();
}

/// @function sng_font_px(font)
/// @description The pixel size a font resource was rasterised at, so type can be drawn at any size by scale.
function sng_font_px(_font) {
    if (_font == fnt_songsheets_display) return 120;
    if (_font == fnt_songsheets_title) return 56;
    if (_font == fnt_songsheets) return 26;
    return 17;   // fnt_songsheets_ui (Open Sans 17)
}

/// @function sng_font_for(font, px)
/// @description The atlas to draw `px`-tall display type from. ⛔ A bitmap font scaled UP goes soft: the 56 px
/// title atlas drawn at a full-screen plate's time signature (~250 px) was a 4.5x blur, visible on the store's
/// close-up. Display type above 84 px comes from the 120 px atlas instead. Pure.
function sng_font_for(_font, _px) {
    if (_font == fnt_songsheets_title && _px > 84) return fnt_songsheets_display;
    return _font;
}

/// @function sng_text(x, y, string, px, colour, [halign], [valign], [font], [alpha], [maxw])
/// @description Draw type `px` pixels tall (the font's nominal size), optionally shrunk to fit `maxw`. Returns
/// the drawn width. ⛔ Texture filtering is switched ON for the draw and RESTORED after: a scaled-down atlas
/// with point sampling drops one-pixel strokes (a "T" whose crossbar is one row becomes an "I"), and a helper
/// that forced it OFF afterwards once unfiltered every caption drawn after it.
function sng_text(_x, _y, _s, _px, _col, _ha = fa_left, _va = fa_top, _font = fnt_songsheets, _alpha = 1, _maxw = -1) {
    _s = string(_s);
    _font = sng_font_for(_font, _px);
    var _prevf = draw_get_font(), _prevh = draw_get_halign(), _prevv = draw_get_valign();
    var _preva = draw_get_alpha(), _prevc = draw_get_colour(), _prevt = gpu_get_texfilter();
    draw_set_font(_font);
    var _sc = _px / sng_font_px(_font);
    var _w = string_width(_s) * _sc;
    if (_maxw > 0 && _w > _maxw && _w > 0) { _sc *= _maxw / _w; _w = _maxw; }
    draw_set_halign(_ha); draw_set_valign(_va);
    draw_set_colour(_col); draw_set_alpha(_alpha);
    gpu_set_texfilter(true);
    draw_text_transformed(_x, _y, _s, _sc, _sc, 0);
    gpu_set_texfilter(_prevt);
    draw_set_font(_prevf); draw_set_halign(_prevh); draw_set_valign(_prevv);
    draw_set_alpha(_preva); draw_set_colour(_prevc);
    return _w;
}

/// @function sng_text_w(string, px, [font])
/// @description The width `sng_text` would draw a string at. Pure but for the font it sets and restores.
function sng_text_w(_s, _px, _font = fnt_songsheets) {
    _font = sng_font_for(_font, _px);
    var _prevf = draw_get_font();
    draw_set_font(_font);
    var _w = string_width(string(_s)) * _px / sng_font_px(_font);
    draw_set_font(_prevf);
    return _w;
}

/// @function sng_text_tracked(cx, y, string, px, track, colour, [font], [alpha], [maxw])
/// @description Letter-spaced capitals centred on cx - the engraver's small-caps subtitle line. `track` is
/// extra space per letter as a fraction of px. Returns the drawn width.
function sng_text_tracked(_cx, _y, _s, _px, _track, _col, _font = fnt_songsheets, _alpha = 1, _maxw = -1) {
    _s = string(_s);
    var _n = string_length(_s), _gap = _px * _track, _tot = 0, _i;
    for (_i = 1; _i <= _n; _i++) _tot += sng_text_w(string_char_at(_s, _i), _px, _font) + ((_i < _n) ? _gap : 0);
    var _sc = 1;
    if (_maxw > 0 && _tot > _maxw) _sc = _maxw / _tot;
    var _x = _cx - _tot * _sc * 0.5;
    for (_i = 1; _i <= _n; _i++) {
        var _ch = string_char_at(_s, _i);
        sng_text(_x, _y, _ch, _px * _sc, _col, fa_left, fa_top, _font, _alpha);
        _x += (sng_text_w(_ch, _px, _font) + _gap) * _sc;
    }
    return _tot * _sc;
}
