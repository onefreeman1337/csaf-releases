{
  "$GMScript": "v1",
  "%Name": "sng_draw",
  "name": "sng_draw",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}