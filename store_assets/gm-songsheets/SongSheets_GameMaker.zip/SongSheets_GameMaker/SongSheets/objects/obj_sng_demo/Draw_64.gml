/// @description The songbook fills the GUI layer; a control line sits along the bottom edge.
if (!sng_is_songbook(ui)) exit;
var _w = display_get_gui_width(), _h = display_get_gui_height();
sng_songbook_draw(ui, 0, 0, _w, _h - 26);
sng_rect_fill(0, _h - 26, _w, 26, make_colour_rgb(20, 13, 9));
sng_text(12, _h - 13, "[UP/DOWN] choose   [SPACE] play   [BACKSPACE] stop   [L] learn a new song   [F] forget", 15,
         make_colour_rgb(214, 196, 160), fa_left, fa_middle, fnt_songsheets_ui);
