/// @description Free the songbook's plate and every rendered song.
if (sng_is_songbook(ui)) sng_songbook_free(ui);
sng_audio_free();
