/// @description Keys: UP/DOWN choose a sheet, SPACE or ENTER plays it (the notation follows the music),
/// BACKSPACE stops, L learns a newly found song, F forgets the selected one.
if (!sng_is_songbook(ui)) exit;
var _play = keyboard_check_pressed(vk_space) || keyboard_check_pressed(vk_enter);
sng_songbook_step(ui, keyboard_check_pressed(vk_up), keyboard_check_pressed(vk_down), _play, keyboard_check_pressed(vk_backspace));
if (keyboard_check_pressed(ord("L"))) {
    var _new = sng_demo_new_id(found);
    found++;
    sng_book_learn(book, _new.id, _new.tradition);
    ui.sel = sng_book_count(book) - 1;
    sng_songbook_step(ui, false, false, true, false);
}
if (keyboard_check_pressed(ord("F")) && sng_book_count(book) > 1) {
    sng_stop();
    sng_book_forget(book, book.songs[ui.sel].id);
    ui.sel = clamp(ui.sel, 0, sng_book_count(book) - 1);
}
