/// @description Song Sheets demo - and the headless entry points (-selftest, -bake, -gif).
/// ⛔ The crash handler is installed FIRST, and every variable a later event reads is declared ABOVE the early
/// exits: Clean Up always runs, even when Create leaves early, and it must not free what was never assigned.
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("sng_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.sng_stage) + ": " + string(_ex.message) + " | " + string(_ex.stacktrace));
    file_text_close(_f);
    game_end();
});
global.sng_stage = 0;
book = undefined;
ui = undefined;
found = 0;
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";
if (string_pos("-selftest", _args) > 0) { global.sng_stage = 1; sng_selftest_write(sng_selftest_run()); game_end(); exit; }
if (string_pos("-gif", _args) > 0) { global.sng_stage = 3; sng_bake_gif(); game_end(); exit; }
if (string_pos("-bake", _args) > 0) { global.sng_stage = 2; sng_bake_run(); game_end(); exit; }
book = sng_demo_book();
ui = sng_songbook_create(book);
