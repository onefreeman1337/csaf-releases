# Song Sheets - for GameMaker

**Every song your player learns is engraved as a plate they collect - and the plate plays what it shows.**

Ten musical traditions, five notation systems, one package. A plainchant is set as square neumes on a red
four-line stave with sung syllables beneath. A courtly air is white mensural notation - lozenge noteheads,
a letter clef, a mensuration circle. A reel is modern notation with a key signature, sloped beams and
barlines. A muster call is a percussion grid over a charted horn call. A fae round curls its stave into a
spiral that comes back to where it began.

None of it is an image file and none of it is an audio file. Every plate is drawn at run time from the
song's own id, and every note is synthesised into GameMaker audio buffers - so a song that does not exist
until your player finds it still has a score, and a sound.

---

## What it does

- **The melody is generated, not stored.** A song id maps to exactly one melody, forever, on every machine
  and in every save. `"hours-of-ash"` is always the same piece of music.
- **Ten traditions, ten kinds of page.** Plainchant, Courtly Air, Reel, Muster Call, Lament, Fae Round,
  Hymnal, Shanty, Incantation and Work Song each have their own melodic construction, mode, metre, notation,
  paper, ink, page frame, instrument and tempo.
- **It is real notation.** Notes are spelled with one letter per scale degree and carry a real key
  signature. Stems flip at the middle line; beams slope with the melody and never cross a barline; ledger
  lines locate notes off the stave; a whole note has no stem; a dotted note has its dot. Plainchant has no
  barlines because plainchant has none.
- **The sheet plays.** `sng_play` starts a song within a few milliseconds and streams the rest; the
  songbook lights each notehead as it sounds.
- **A songbook screen** - a writing desk, an index of every sheet learned, the selected plate and its
  playhead - that looks nothing like a default GameMaker menu.
- **Titles write themselves.** Learn a song without naming it and it gets a title in its tradition's
  voice ("The Miller's Daughter", "Hymn 69, Holloway", "Nine Turns Widdershins").
- **The same songs as the RPG Maker MZ edition.** The melody engine is note-for-note identical to our
  Song Sheets plugin for RPG Maker MZ: the same id and tradition give the same notes in both engines.

## Requirements

GameMaker 2024.14 or later. Built and tested with the **runtime 2024.14.4.268** on Windows (the VM
runtime). Pure GML: no extension, no DLL, no shader.

## Install

1. **Tools > Import Local Package**, choose `SongSheets.yymps`, and import everything.
2. Press Play. `rm_sng_demo` opens the songbook with fourteen sheets already learned.

If you only want the library, import the `sng_*` scripts and the four `fnt_songsheets*` fonts;
`obj_sng_demo` and `rm_sng_demo` are the demo.

## Quickstart

Put this in an object's events.

```gml
// Create
my_book = sng_book_create();
sng_book_learn(my_book, "millers-daughter", "folk", "The Miller's Daughter");
sng_book_learn(my_book, "hours-of-ash", "chant");
my_songbook = sng_songbook_create(my_book);

// Step
sng_songbook_step(my_songbook, keyboard_check_pressed(vk_up), keyboard_check_pressed(vk_down),
                  keyboard_check_pressed(vk_space), keyboard_check_pressed(vk_backspace));

// Draw GUI
sng_songbook_draw(my_songbook, 0, 0, display_get_gui_width(), display_get_gui_height());

// Clean Up
sng_songbook_free(my_songbook);
sng_audio_free();
```

`sng_songbook_step` must run every step: it also keeps the playing song rendering ahead of the music.

### A single plate, anywhere

```gml
// Create - render once
my_plate = sng_plate(sng_song("salt-marsh", "lament"), 520, 380);

// Draw GUI - one quad per frame
sng_plate_draw(my_plate, 40, 40);
sng_playhead_draw(my_plate, 40, 40, sng_playing_index());

// When the player presses a key
sng_play(my_plate.song);

// Step, while it plays
sng_update();

// Clean Up
sng_plate_free(my_plate);
```

`sng_plate` renders the plate once at twice its size into a sprite and draws it filtered down, which is
what keeps thin stave lines smooth. Draw a plate every frame for the cost of one sprite.

### Saving

```gml
my_saved = sng_book_save(my_book);          // a short string for your save file
my_book = sng_book_load(my_saved);          // a damaged string loads as an empty book, never a crash
```

## The API

| Function | What it does |
| --- | --- |
| `sng_song(id, tradition, [tonic], [title])` | The whole song: mode, metre, notation, notes, tempo, title. |
| `sng_traditions()` | The ten tradition keys. |
| `sng_tradition(key)` | One tradition's definition, or `undefined`. |
| `sng_title(id, tradition)` | A generated title in the tradition's voice. |
| `sng_is_song(value)` | True for a song struct. |
| `sng_spelling(tonic, mode)` | How a mode is spelled: one letter per degree, and its key signature. |
| `sng_engrave(song, x, y, w, h, [marks])` | Draw a plate directly into the current target. |
| `sng_plate(song, w, h, [ss])` | Render a plate once, supersampled, into a sprite. |
| `sng_plate_draw(plate, x, y, [alpha], [scale])` | Draw a plate. |
| `sng_plate_free(plate)` | Free a plate's sprite. |
| `sng_playhead_draw(plate, x, y, index, [colour], [scale])` | Light the notehead that is sounding. |
| `sng_ink(key)` | An ink's line, accent and paper colours. |
| `sng_layout(kind, box_w, box_h, notes, [unit])` | The layout the engraver solves for a stave system. |
| `sng_play(song, [gain])` | Start a song; returns the sound instance or -1. |
| `sng_update([budget_ms])` | Keep the playing song rendered ahead. Call every step while playing. |
| `sng_stop()` | Stop. |
| `sng_is_playing()` | True while a song sounds. |
| `sng_position()` | Seconds into the current song, or -1. |
| `sng_playing_index()` | The note sounding now, or -1. |
| `sng_prepare(song, [budget_ms])` | Render a song ahead of time in slices; returns progress 0 to 1. |
| `sng_schedule(song)` | The notes as seconds: the one schedule the sound and the playhead share. |
| `sng_duration(song)` | Length in seconds. |
| `sng_note_at(schedule, seconds)` | Which note sounds at a time, or -1. |
| `sng_timbres()` | The nine instrument keys. |
| `sng_render(song)` | The whole song synthesised into a new buffer (blocking; you own it). |
| `sng_save_wav(song, filename)` | Write the song as a 16-bit mono WAV. |
| `sng_audio_free()` | Free every cached song. |
| `sng_book_create()` | An empty book. |
| `sng_book_learn(book, id, tradition, [title], [tonic])` | Learn a sheet; learning twice changes nothing. |
| `sng_book_forget(book, id)` | Forget a sheet. |
| `sng_book_has(book, id)` | Has the player got it? |
| `sng_book_count(book)` | How many sheets. |
| `sng_book_find(book, id)` | Its index, or -1. |
| `sng_book_song(book, index)` | The song at an index. |
| `sng_book_ids(book)` | Every id, in learning order. |
| `sng_book_save(book)` | The book as a string. |
| `sng_book_load(string)` | A book from a string. |
| `sng_songbook_create(book)` | The songbook screen's state. |
| `sng_songbook_step(ui, up, down, play, stop)` | Drive the screen. Call every step. |
| `sng_songbook_draw(ui, x, y, w, h)` | Draw the screen into a rectangle. |
| `sng_songbook_free(ui)` | Free the screen's plate and stop its song. |

Every function checks what it is handed. A wrong type, `undefined`, or an out-of-range number returns a
refusal value (`undefined`, `-1`, `0` or an empty array) instead of throwing inside your game.

## The traditions

| Key | Tradition | Mode | Metre | Notation | Instrument |
| --- | --- | --- | --- | --- | --- |
| `chant` | Plainchant | dorian | free | square neumes, four-line stave, sung syllables | voice |
| `courtly` | Courtly Air | ionian | 3/2 | white mensural: lozenges, letter clef, mensuration circle | plucked |
| `folk` | Reel | mixolydian | 6/8 | modern stave, beamed | reed |
| `martial` | Muster Call | ionian | 4/4 | percussion grid over a charted horn call | brass |
| `lament` | Lament | phrygian | 4/4 | modern stave, mourning bands | bowed |
| `fae` | Fae Round | lydian | 5/8 | a spiral stave that returns to its start | bell |
| `hymn` | Hymnal | ionian | 4/4 | modern stave, ruled, with a hymn number | organ |
| `sea` | Shanty | dorian | 2/2 | modern stave, rope border | voice |
| `spell` | Incantation | locrian | free | square neumes, and the whole piece is a palindrome | glass |
| `work` | Work Song | aeolian | 3/4 | anvil grid over a voice chart, with tally marks | hammer |

Each tradition is a different CONSTRUCTION, not one generator with different numbers: the reel is built on
a chord turn, the shanty answers every call with the same literal refrain, the incantation is a phrase
followed by its exact retrograde (rhythm included), the work song strikes an anvil against a cycling answer.

## Performance

Measured on the test machine with the VM runtime:

- `sng_play` starts a song in under 20 ms: it renders half a second and streams the rest, a few
  milliseconds per step, well ahead of the music.
- Synthesising a whole song in one call (`sng_render`, `sng_save_wav`) runs roughly 20 to 35 times faster
  than real time depending on the instrument - a 52-second plainchant took about a second and a half - so
  keep those for export and loading screens, and use `sng_play` or `sng_prepare` in play.
- A plate is rendered once by `sng_plate`; after that it costs one sprite draw per frame.

## Namespacing

Every script, function and macro is prefixed `sng_` or `SNG_`; the resources are `obj_sng_demo`,
`rm_sng_demo` and the four `fnt_songsheets` fonts. Nothing collides with your project.

## Fonts

Three fonts are IM Fell DW Pica (SIL Open Font License 1.1) and one is Open Sans (Apache License 2.0). The
fonts set every plate's title, its tradition line, time signatures, sung syllables and grid lanes, so keep
them. Their licences and notices are in `SongSheets/fonts/`.

## Licence and disclosure

One commercial licence per developer, unlimited games. Everything the package draws or plays in your game is
yours to ship. See `LICENSE.txt`.

This package's code and its store images were produced with AI assistance. The audio is procedural
synthesis written in GML: there is no generative audio model anywhere in it, and no audio files ship with it.

Copyright (c) 2026 Core Systems Asset Factory.

*More GameMaker systems from Core Systems Asset Factory: <https://csaf.itch.io>*
