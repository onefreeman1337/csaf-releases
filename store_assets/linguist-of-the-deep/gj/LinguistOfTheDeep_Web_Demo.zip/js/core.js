/* core.js — Linguist of the Deep: THE ONE RUN OBJECT. The page drives it through step(input); the caller owns
 * the clock. Lifted from Internal_Ops/proto/core.js (the object every design bot measured) with two changes:
 *   1. it reads the page's content (window.LOD_SPEC, built by js/content.js and, in the paid build,
 *      js/content_full.js) instead of the design file;
 *   2. the read beat R1 is ACTED ON: three current mouths in the Vents' far wall, and only the warm one goes on
 *      (DESIGN §7c — a reading beat, low stakes by design: every word it uses is also required by a speak gate).
 *      Speaking its sentence to the elder shoal still opens it too, so the bots' path is unchanged. */
(function (root) {
  'use strict';
  const SPEC = root.LOD_SPEC;
  const DT = 0.1, ZW = 640, ZH = 180, SCENE_GAP = 120, GATE_CLEAR = 64;
  const P = { vmax: 60, acc: 240, drag: 4, seeR: 56, speakR: 32, window: 4, sayCost: 3.5, streak: 3, retreat: 20 };

  function hash(str, salt) { let h = 2166136261 ^ salt; for (const c of str) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); } return (h >>> 0) / 4294967296; }
  function rng(seed) {
    let a = Math.imul((seed >>> 0) ^ 0x9e3779b9, 0x85ebca6b) >>> 0;
    return () => { a = (a + 0x6d2b79f5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  const SLOTS = [];
  for (let i = 0; i < 5; i++) SLOTS.push([60 + i * 120, 40]);
  for (let i = 0; i < 4; i++) SLOTS.push([120 + i * 120, 150]);

  function layout(periodOf, opts) {
    const zones = (opts && opts.zones) || SPEC.ZONES.length;
    const byZone = {};
    for (const s of SPEC.SCENES.filter((q) => q.zone < zones)) (byZone[s.zone] = byZone[s.zone] || []).push(s);
    const scenes = [], placed = [];
    for (const z of Object.keys(byZone).map(Number).sort((a, b) => a - b)) {
      const list = byZone[z];
      if (list.length > SLOTS.length) throw new Error('layout: zone ' + z + ' has ' + list.length + ' scenes for ' + SLOTS.length + ' slots');
      const order = SLOTS.map((sl, i) => [hash('z' + z + 's' + i, 11), sl]).sort((a, b) => a[0] - b[0]).map((p) => p[1]);
      list.forEach((s, i) => {
        const period = periodOf(s.zone);
        const x = z * ZW + order[i][0], y = order[i][1];
        for (const q of placed) if (q.zone === z && Math.hypot(q.x - x, q.y - y) < SCENE_GAP) throw new Error('layout: ' + s.id + ' within ' + SCENE_GAP + ' of ' + q.id);
        if (Math.hypot(z * ZW + ZW - 20 - x, 90 - y) < GATE_CLEAR) throw new Error('layout: ' + s.id + ' crowds the gate');
        const out = Object.assign({}, s, { x, y, period, phase: hash(s.id, 3) * period });
        placed.push(out); scenes.push(out);
      });
    }
    scenes.sort((a, b) => SPEC.SCENES.findIndex((q) => q.id === a.id) - SPEC.SCENES.findIndex((q) => q.id === b.id));
    const gates = SPEC.GATES.map((g) => Object.assign({}, g, { zone: g.into === null ? SPEC.ZONES.length - 1 : g.into - 1 }))
      .filter((g) => g.zone < zones || (g.into !== null && g.into === zones)).map((g) => {
        const z = g.zone;
        const y = g.id === 'R1' ? 50 : g.id === 'G5' ? 130 : 90;
        const x = g.into === null ? z * ZW + ZW / 2 : z * ZW + ZW - 20;
        const out = Object.assign({}, g, { x, y });
        if (g.kind === 'read') {
          /* three mouths in the far wall; which one is warm is fixed by the gate's id (deterministic, never random) */
          const warm = Math.floor(hash(g.id, 29) * 3);
          out.mouths = [40, 90, 140].map((my, i) => ({ x: z * ZW + ZW - 6, y: my, warm: i === warm }));
          out.y = 90; out.x = z * ZW + ZW - 44;   /* the elder shoal waits in front of the wall */
        }
        return out;
      });
    return { scenes, gates, zones };
  }

  function Run(lay) {
    this.t = 0; this.x = 20; this.y = 90; this.vx = 0; this.vy = 0;
    this.zones = lay.zones || SPEC.ZONES.length;
    this.scenes = lay.scenes;
    this.gates = lay.gates.map((g) => Object.assign({}, g, { open: false, wrong: 0, streak: 0, awayUntil: 0 }));
    this.seen = []; this.busyUntil = 0; this.wrongTotal = 0; this.log = []; this.lastRefusal = null; this.coldTotal = 0;
  }
  Run.prototype.maxZone = function () {
    let z = 0;
    for (let k = 1; k < this.zones; k++) { if (this.gates.filter((g) => g.into === k).every((g) => g.open)) z = k; else break; }
    return z;
  };
  Run.prototype.playing = function (s, t) { return ((t - s.phase) % s.period + s.period) % s.period < P.window; };
  Run.prototype.phaseOf = function (s, t) { return ((t - s.phase) % s.period + s.period) % s.period; };
  Run.prototype.listenerNear = function () {
    return this.gates.find((g) => !g.open && g.zone <= this.maxZone() && Math.hypot(g.x - this.x, g.y - this.y) <= P.speakR && this.t >= g.awayUntil);
  };
  /* review D15: a listener in reach but turned away is a different refusal from "nobody here" */
  Run.prototype.awayNear = function () {
    return this.gates.find((g) => !g.open && g.zone <= this.maxZone() && Math.hypot(g.x - this.x, g.y - this.y) <= P.speakR && this.t < g.awayUntil);
  };
  /* input: { dx, dy } in [-1,1]; speak: array of glyph ids | null (an EDGE). Returns an event or null.
   * Every refusal names its reason (wing §0z-1c). */
  Run.prototype.step = function (input) {
    let ev = null;
    /* ⛔ a sentence flashed while the last is still being spoken was DROPPED IN SILENCE (verify_suite breakit found it);
     * now it is refused by name like every other refusal */
    if (this.t < this.busyUntil) { if (input.speak) { ev = { refused: 'still speaking' }; this.lastRefusal = ev.refused; } input = { dx: 0, dy: 0 }; }
    else if (input.speak) {
      const g = this.listenerNear();
      if (!g) { ev = { refused: this.awayNear() ? 'not listening yet' : 'no listener in reach' }; this.lastRefusal = ev.refused; }
      else {
        this.busyUntil = this.t + P.sayCost;
        const bag = (a) => a.slice().sort().join(',');
        const right = input.speak.length === g.words.length && bag(input.speak) === bag(g.words);
        if (right) { g.open = true; ev = { opened: g.id, t: this.t }; }
        else {
          g.wrong++; this.wrongTotal++; g.streak++; ev = { wrong: g.id };
          if (g.streak >= P.streak) { g.streak = 0; g.awayUntil = this.t + P.sayCost + P.retreat; ev.retreat = true; }
        }
      }
    }
    const m = Math.hypot(input.dx, input.dy); const ix = m > 1 ? input.dx / m : input.dx, iy = m > 1 ? input.dy / m : input.dy;
    this.vx += (ix * P.acc - this.vx * P.drag) * DT; this.vy += (iy * P.acc - this.vy * P.drag) * DT;
    const px = this.x;
    this.x += this.vx * DT; this.y += this.vy * DT;
    const mz = this.maxZone();
    /* review D12: the wall is SOLID where it is drawn. Once a gate opens you pass through its GAP (or a mouth), never
     * through the rock; the picture and the collision agree. (Before it opens the zone clamp below holds you.) */
    for (const g of this.gates) {
      if (g.into === null || !g.open) continue;
      const wx0 = (g.zone + 1) * ZW - 20, wx1 = (g.zone + 1) * ZW + 4;
      if (this.x > wx0 && this.x < wx1) {
        const gaps = g.mouths ? g.mouths.filter((mo) => mo.warm).map((mo) => mo.y) : [g.y];
        if (!gaps.some((gy) => Math.abs(this.y - gy) < 11)) { this.x = px <= wx0 ? wx0 : px >= wx1 ? wx1 : px; this.vx = 0; }
      }
    }
    /* the read beat: swim into a mouth of the wall. Warm goes on; a cold one's current throws you back. */
    for (const g of this.gates) {
      if (g.kind !== 'read' || g.open || g.zone !== mz || !g.mouths) continue;
      for (const mo of g.mouths) {
        if (Math.hypot(mo.x - this.x, mo.y - this.y) > 12) continue;
        if (mo.warm) { g.open = true; if (!ev) ev = { opened: g.id, t: this.t, by: 'mouth' }; }
        else { this.x -= 70; this.vx = -40; this.busyUntil = this.t + 1.2; this.coldTotal++; if (!ev) ev = { cold: g.id }; }
        break;
      }
    }
    const xmax = (this.maxZone() + 1) * ZW - 4;
    this.x = Math.max(4, Math.min(xmax, this.x)); this.y = Math.max(16, Math.min(ZH - 4, this.y));   /* D13: never under the HUD strip */
    for (const s of this.scenes) {
      if (s.zone > this.maxZone() || this.seen.includes(s.id)) continue;
      if (this.playing(s, this.t) && Math.hypot(s.x - this.x, s.y - this.y) <= P.seeR) { this.seen.push(s.id); this.log.push({ t: this.t, scene: s.id }); if (!ev) ev = { logged: s.id }; }
    }
    this.t += DT;
    return ev;
  };

  const LOD_CORE = { SPEC, DT, ZW, ZH, P, SCENE_GAP, GATE_CLEAR, hash, rng, layout, Run };
  root.LOD_CORE = LOD_CORE;
})(window);
