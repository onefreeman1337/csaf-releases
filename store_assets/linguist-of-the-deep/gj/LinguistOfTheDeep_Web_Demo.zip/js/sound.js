/* sound.js — the reef's sound. Three arrangements of one theme (shallow, twilight, abyss), rendered to the SAME
 * length so they can sound together, crossfaded by depth; eight cues; and the glyph TONES — every glyph has its own
 * note, synthesised live, so a sentence is heard as a short phrase and sound helps tell glyphs apart.
 * Two backends (wing §8a rule 2, §2a): on http(s) gapless AudioBufferSourceNodes; on file:// (the paid Windows
 * download, where fetch cannot read a file at all) bare <audio> elements OUT of the WebAudio graph, volume driven
 * directly. Tones are oscillators and work on both. Nothing plays before the first key press (autoplay rules).
 * Every cue is gated on ITS OWN buffer and a running context, never on the music being ready (wing §8a rule 4). */
(function (root) {
  'use strict';
  const MUSIC = ['mus_shallow', 'mus_twilight', 'mus_abyss'];
  const CUES = ['sfx_logged', 'sfx_open', 'sfx_wrong', 'sfx_eel', 'sfx_lamp', 'sfx_ui', 'sfx_cold', 'sfx_end'];
  const IS_FILE = location.protocol === 'file:';
  const MUSIC_VOL = 0.55;
  function Sound() {
    this.muted = false; try { this.muted = localStorage.getItem('lod.muted') === '1'; } catch (e) { /* storage refused */ }
    this.ctx = null; this.buffers = {}; this.els = {}; this.pool = {}; this.gains = {}; this.sources = {};
    this.started = false; this.errors = []; this.weights = [1, 0, 0]; this.depth = 0; this.cueCount = 0; this.toneCount = 0;
    this.loaded = { music: 0, cues: 0 };
  }
  Sound.prototype.load = function () {
    const self = this;
    try { this.ctx = new (root.AudioContext || root.webkitAudioContext)(); this.master = this.ctx.createGain(); this.master.gain.value = this.muted ? 0 : 1; this.master.connect(this.ctx.destination); } catch (e) { this.errors.push('no AudioContext: ' + e.message); }
    if (IS_FILE || !this.ctx) {
      MUSIC.forEach((n) => { const el = new Audio('audio/' + n + '.ogg'); el.loop = true; el.preload = 'auto'; el.volume = 0; el.addEventListener('canplaythrough', () => { self.loaded.music++; }, { once: true }); el.addEventListener('error', () => self.errors.push(n + '.ogg failed')); self.els[n] = el; });
      CUES.forEach((n) => { self.pool[n] = [0, 1, 2].map(() => { const el = new Audio('audio/' + n + '.ogg'); el.preload = 'auto'; return el; }); self.pool[n][0].addEventListener('canplaythrough', () => { self.loaded.cues++; }, { once: true }); });
      return;
    }
    MUSIC.concat(CUES).forEach((n) => {
      fetch('audio/' + n + '.ogg').then((r) => { if (!r.ok) throw new Error(n + '.ogg ' + r.status); return r.arrayBuffer(); })
        .then((ab) => new Promise((res, rej) => self.ctx.decodeAudioData(ab, res, rej)))
        .then((buf) => { self.buffers[n] = buf; if (MUSIC.includes(n)) self.loaded.music++; else self.loaded.cues++; if (self.started && MUSIC.includes(n)) self._startTrack(n); })
        .catch((e) => self.errors.push(String(e.message || e)));
    });
  };
  /* the first key press: resume the context and start the music */
  Sound.prototype.unlock = function () {
    if (this.started) return; this.started = true;
    const self = this;
    if (this.ctx && this.ctx.state !== 'running') this.ctx.resume().catch((e) => self.errors.push('resume refused: ' + e.message));
    if (IS_FILE || !this.ctx) {
      MUSIC.forEach((n, i) => { const el = self.els[n]; el.volume = self.muted ? 0 : self.weights[i] * MUSIC_VOL; const p = el.play(); if (p && p.catch) p.catch((e) => self.errors.push('autoplay denied: ' + e.message)); });
    } else MUSIC.forEach((n) => { if (self.buffers[n]) self._startTrack(n); });
  };
  Sound.prototype._startTrack = function (n) {
    if (this.sources[n]) return;
    const i = MUSIC.indexOf(n), gn = this.ctx.createGain(); gn.gain.value = this.weights[i] * MUSIC_VOL; gn.connect(this.master);
    /* every track starts on the same clock tick as the first one, so the arrangements stay in step */
    if (this.t0 == null) this.t0 = this.ctx.currentTime + 0.05;
    const src = this.ctx.createBufferSource(); src.buffer = this.buffers[n]; src.loop = true; src.connect(gn);
    const len = this.buffers[n].duration, off = Math.max(0, this.ctx.currentTime - this.t0) % len;
    src.start(this.ctx.currentTime + 0.02, off); this.sources[n] = src; this.gains[n] = gn;
  };
  /* depth 0..6 (zone, fractional) -> weights over the three arrangements */
  Sound.prototype.setDepth = function (d) {
    this.depth = d;
    const w = [Math.max(0, 1 - d / 2), 0, Math.max(0, Math.min(1, (d - 3) / 2))]; w[1] = Math.max(0, 1 - w[0] - w[2]);
    this.weights = w;
    const self = this;
    MUSIC.forEach((n, i) => {
      const v = self.muted ? 0 : w[i] * MUSIC_VOL;
      if (self.gains[n]) self.gains[n].gain.setTargetAtTime(v, self.ctx.currentTime, 0.6);
      if (self.els[n] && self.started) self.els[n].volume = Math.max(0, Math.min(1, v));
    });
  };
  Sound.prototype.cue = function (n, gain) {
    if (this.muted) return false;
    if (IS_FILE || !this.ctx) { const els = this.pool[n]; if (!els) return false; const el = els.find((e) => e.paused || e.ended) || els[0]; try { el.currentTime = 0; } catch (e) { /* not seekable yet */ } el.volume = Math.min(1, gain || 0.8); const p = el.play(); if (p && p.catch) p.catch(() => {}); this.cueCount++; return true; }
    const b = this.buffers[n]; if (!b || this.ctx.state !== 'running') return false;
    const s = this.ctx.createBufferSource(), gn = this.ctx.createGain(); gn.gain.value = gain || 0.8; s.buffer = b; s.connect(gn); gn.connect(this.master); s.start(); this.cueCount++; return true;
  };
  /* a glyph's own note: a soft bell on a pentatonic scale, pitch from the glyph's hue (hue order, not gloss) */
  const SCALE = [0, 2, 4, 7, 9];
  Sound.prototype.tone = function (hue, when) {
    if (this.muted || !this.ctx || this.ctx.state !== 'running') return false;
    const step = Math.floor(hue / 360 * 10), semis = SCALE[step % 5] + 12 * Math.floor(step / 5), f = 392 * Math.pow(2, semis / 12);
    const t = this.ctx.currentTime + (when || 0), o = this.ctx.createOscillator(), o2 = this.ctx.createOscillator(), gn = this.ctx.createGain();
    o.type = 'sine'; o.frequency.value = f; o2.type = 'triangle'; o2.frequency.value = f * 2.005;
    gn.gain.setValueAtTime(0.0001, t); gn.gain.exponentialRampToValueAtTime(0.16, t + 0.02); gn.gain.exponentialRampToValueAtTime(0.0001, t + 0.9);
    const g2 = this.ctx.createGain(); g2.gain.value = 0.25; o2.connect(g2); g2.connect(gn); o.connect(gn); gn.connect(this.master);
    o.start(t); o2.start(t); o.stop(t + 1); o2.stop(t + 1); this.toneCount++; return true;
  };
  Sound.prototype.setMuted = function (on) {
    this.muted = !!on; try { localStorage.setItem('lod.muted', on ? '1' : '0'); } catch (e) { /* ignore */ }
    if (this.master) this.master.gain.value = on ? 0 : 1;
    this.setDepth(this.depth);
    return this.muted;
  };
  Sound.prototype.toggleMute = function () { return this.setMuted(!this.muted); };
  Sound.prototype.report = function () {
    return { backend: IS_FILE || !this.ctx ? 'media-element' : 'webaudio', ctx: this.ctx ? this.ctx.state : 'none', started: this.started, muted: this.muted,
      loaded: this.loaded, want: { music: MUSIC.length, cues: CUES.length }, weights: this.weights.map((x) => +x.toFixed(3)), cues: this.cueCount, tones: this.toneCount, errors: this.errors.slice() };
  };
  root.LOD_SOUND = new Sound();
  root.LOD_SOUND.MUSIC = MUSIC; root.LOD_SOUND.CUES = CUES;
})(window);
