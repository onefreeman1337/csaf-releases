/* game.js — Linguist of the Deep. Swim an alien reef, overhear its creatures talking in light, and work out enough
 * of their language to ask them for help. Nothing unlocks except what you understand.
 * ⛔ Scenes carry NO TEXT: a meaning shown as a word is a meaning given away. The only words the game ever prints
 * about the language are in the paid ending, where the lexicon is revealed beside your own pencilled guesses.
 * tick() is the ONE place a frame happens; window.__lodTick(n, input) lets a harness drive the shipped page with
 * no requestAnimationFrame (a hidden automation tab gets none). */
(function () {
  'use strict';
  const C = window.LOD_CORE, SPEC = window.LOD_SPEC, WORLD = window.LOD_WORLD, GL = window.LOD_GLYPHS;
  const CR = window.LOD_CREATURES, F = window.LOD_FONT, SND = window.LOD_SOUND;
  const W = 320, H = 180, ZW = C.ZW;
  const FULL = SPEC.EDITION === 'full';
  const ZONES = FULL ? SPEC.ZONES.length : SPEC.DEMO_ZONES;
  const LAST_DEMO_GATE = SPEC.GATES.find((q) => q.into === SPEC.DEMO_ZONES).id;
  const SAVE_KEY = 'lod.save.v1.' + SPEC.EDITION;
  const cv = document.getElementById('c'), g = cv.getContext('2d');
  g.imageSmoothingEnabled = false;
  const STAGE = SPEC.STAGE, LISTENER = SPEC.LISTENER;
  const lay = C.layout((z) => 10 + 6 * z, { zones: ZONES });
  const PAL = { ink: '#050a12', panel: 'rgba(6,14,24,0.92)', line: '#27455a', text: '#dcecf7', dim: '#8aa3b3', gold: '#ffd97a', warm: '#ff9c5a', cyan: '#7fe3ff' };

  let run = null;
  const ui = { screen: 'title', mode: 'swim', lamp: [], sel: 0, guesses: {}, bookSel: 0, page: 0, flash: null, toast: null, frames: 0,
    menu: 0, pause: 0, banner: null, hints: {}, hint: null, endT: 0, face: 1, moving: false, lastZone: -1, t: 0, saved: null, demoSeen: false, lastEvent: null };
  const keys = {};
  let prev = { x: 20, y: 90 };

  function hasSave() { try { return !!localStorage.getItem(SAVE_KEY); } catch (e) { return false; } }
  function save() {
    if (!run) return;
    const s = { v: 1, seen: run.seen.slice(), open: run.gates.filter((q) => q.open).map((q) => q.id), guesses: ui.guesses, x: run.x, y: run.y, t: run.t, hints: ui.hints };
    try { localStorage.setItem(SAVE_KEY, JSON.stringify(s)); ui.saved = run.t; } catch (e) { /* storage refused: play on */ }
  }
  function newRun() { run = new window.LOD_EEL.EelRun(lay, 7); prev = { x: run.x, y: run.y }; ui.guesses = {}; ui.hints = {}; ui.lastZone = -1; ui.mode = 'swim'; ui.lamp = []; ui.flash = null; ui.toast = null; }
  function loadRun() {
    let s = null; try { s = JSON.parse(localStorage.getItem(SAVE_KEY) || 'null'); } catch (e) { s = null; }
    newRun(); if (!s || s.v !== 1) return false;
    run.seen = (s.seen || []).filter((id) => run.scenes.some((q) => q.id === id));
    for (const gt of run.gates) if ((s.open || []).includes(gt.id)) gt.open = true;
    run.t = s.t || 0; run.x = s.x || 20; run.y = s.y || 90; prev = { x: run.x, y: run.y };
    ui.guesses = s.guesses || {}; ui.hints = s.hints || {};
    return true;
  }
  function seenGlyphs() { const out = []; for (const id of run.seen) { const sc = SPEC.SCENES.find((x) => x.id === id); if (sc) for (const w of sc.utt) if (!out.includes(w)) out.push(w); } return out; }
  function seenIdeas() {
    const s = new Set();
    for (const id of run.seen) { const st = STAGE[id]; if (!st) continue; s.add(st.speaker); for (const a of st.acts) { s.add(a[0]); if (a[1] !== 'idle') s.add('~' + a[1]); if (a[2]) s.add(a[2]); } if (st.diver) s.add('DIVER'); if (st.warm) s.add('~warm'); if (st.dark) s.add('~dark'); }
    return [...s];
  }
  function zoneOf(x) { return Math.max(0, Math.min(ZONES - 1, Math.floor(x / ZW))); }

  /* ------------------------------------------------------------------ input */
  function swimInput() {
    if (ui.screen !== 'play' || ui.mode === 'book') return { dx: 0, dy: 0 };
    return { dx: (keys.ArrowRight || keys.d || keys.D ? 1 : 0) - (keys.ArrowLeft || keys.a || keys.A ? 1 : 0), dy: (keys.ArrowDown || keys.s || keys.S ? 1 : 0) - (keys.ArrowUp || keys.w || keys.W ? 1 : 0) };
  }
  const TITLE_ITEMS = () => (hasSave() ? ['CONTINUE'] : []).concat(['NEW DIVE', 'HOW TO PLAY', 'SOUND', 'CREDITS']);
  const PAUSE_ITEMS = ['RESUME', 'HOW TO PLAY', 'SOUND', 'SAVE AND QUIT'];
  function handleKey(k) {
    SND.unlock();
    const up = k === 'ArrowUp' || k === 'w' || k === 'W', down = k === 'ArrowDown' || k === 's' || k === 'S', go = k === 'Enter' || k === ' ';
    if (ui.screen === 'title') {
      const items = TITLE_ITEMS();
      if (up) { ui.menu = (ui.menu + items.length - 1) % items.length; SND.cue('sfx_ui', 0.5); }
      else if (down) { ui.menu = (ui.menu + 1) % items.length; SND.cue('sfx_ui', 0.5); }
      else if (go) {
        const it = items[ui.menu % items.length]; SND.cue('sfx_ui', 0.7);
        if (it === 'CONTINUE') { loadRun(); ui.screen = 'play'; }
        else if (it === 'NEW DIVE') { if (hasSave()) ui.screen = 'confirm'; else { newRun(); ui.screen = 'play'; save(); } }   /* review D14 */
        else if (it === 'HOW TO PLAY') { ui.back = 'title'; ui.screen = 'help'; }
        else if (it === 'SOUND') SND.toggleMute();
        else if (it === 'CREDITS') { ui.back = 'title'; ui.screen = 'credits'; ui.endT = 0; }
      }
      return;
    }
    if (ui.screen === 'help' || ui.screen === 'credits') { if (go || k === 'Escape' || k === 'Backspace') { ui.screen = ui.back || 'title'; SND.cue('sfx_ui', 0.5); } return; }
    if (ui.screen === 'pause') {
      if (up) { ui.pause = (ui.pause + PAUSE_ITEMS.length - 1) % PAUSE_ITEMS.length; SND.cue('sfx_ui', 0.5); }
      else if (down) { ui.pause = (ui.pause + 1) % PAUSE_ITEMS.length; SND.cue('sfx_ui', 0.5); }
      else if (k === 'Escape') ui.screen = 'play';
      else if (go) {
        const it = PAUSE_ITEMS[ui.pause]; SND.cue('sfx_ui', 0.7);
        if (it === 'RESUME') ui.screen = 'play';
        else if (it === 'HOW TO PLAY') { ui.back = 'pause'; ui.screen = 'help'; }
        else if (it === 'SOUND') SND.toggleMute();
        else { save(); ui.screen = 'title'; ui.menu = 0; }
      }
      return;
    }
    /* review D21: KEEP SWIMMING returns you to the Ridge a little way back from the gate; reaching it again re-shows the card */
    if (ui.screen === 'demoend') { if (go) { ui.screen = 'play'; run.x -= 60; run.vx = 0; prev = { x: run.x, y: run.y }; } else if (k === 'Escape') { save(); ui.screen = 'title'; ui.menu = 0; } return; }
    if (ui.screen === 'confirm') { if (go) { newRun(); ui.screen = 'play'; save(); } else if (k === 'Escape' || k === 'Backspace') ui.screen = 'title'; return; }
    if (ui.screen === 'ending') { if (ui.endT > 4 && go) { if (ui.endStage === 0) ui.endStage = 1; else { ui.screen = 'credits'; ui.back = 'title'; ui.endT = 0; } } return; }
    if (ui.screen !== 'play') return;
    if (k === 'm' || k === 'M') { SND.toggleMute(); return; }
    if (ui.mode === 'swim') {
      if (k === 'Escape') { ui.screen = 'pause'; ui.pause = 0; save(); }
      else if (k === 'Tab' || k === 'b' || k === 'B') { ui.mode = 'book'; ui.bookSel = 0; ui.page = 0; ui.hints.book = 1; SND.cue('sfx_ui', 0.6); }
      else if (k === ' ' || k === 'l' || k === 'L') { if (seenGlyphs().length) { ui.mode = 'lamp'; ui.lamp = []; ui.sel = 0; ui.hints.lamp = 1; SND.cue('sfx_lamp', 0.6); } else toast('YOUR LAMP KNOWS NO GLYPHS YET'); }
    } else if (ui.mode === 'lamp') {
      const gs = seenGlyphs();
      if (k === 'Escape' || k === 'l' || k === 'L') ui.mode = 'swim';
      else if (k === 'e' || k === 'E') { ui.sel = (ui.sel + 1) % gs.length; SND.tone(GL.hue(gs[ui.sel])); }
      else if (k === 'q' || k === 'Q') { ui.sel = (ui.sel + gs.length - 1) % gs.length; SND.tone(GL.hue(gs[ui.sel])); }
      else if ((k === 'f' || k === 'F' || k === 'Enter') && ui.lamp.length < 3) { ui.lamp.push(gs[ui.sel]); SND.tone(GL.hue(gs[ui.sel])); }
      else if (k === 'r' || k === 'R' || k === 'Backspace') ui.lamp.pop();
      else if (k === ' ' && ui.lamp.length) {
        ui.pendingSpeak = ui.lamp.slice();
        if (run.t < run.busyUntil) toast('YOUR WORDS WAIT FOR YOUR LAST ONES TO FADE');
        ui.lamp.forEach((w, j) => SND.tone(GL.hue(w), j * 0.35)); ui.lamp = []; ui.mode = 'swim';
      }
      else if (k === 'Tab' || k === 'b' || k === 'B') { ui.mode = 'book'; ui.bookSel = 0; ui.page = 0; }
    } else if (ui.mode === 'book') {
      const gs = seenGlyphs(), ideas = seenIdeas();
      if (k === 'Tab' || k === 'b' || k === 'B' || k === 'Escape') ui.mode = 'swim';
      else if (k === 'ArrowRight' || k === 'd' || k === 'D') { ui.bookSel = Math.min(gs.length - 1, ui.bookSel + 1); if (gs[ui.bookSel]) SND.tone(GL.hue(gs[ui.bookSel])); }
      else if (k === 'ArrowLeft' || k === 'a' || k === 'A') { ui.bookSel = Math.max(0, ui.bookSel - 1); if (gs[ui.bookSel]) SND.tone(GL.hue(gs[ui.bookSel])); }
      else if ((up || down) && gs.length && ideas.length) {
        const gid = gs[ui.bookSel]; const opts = [null].concat(ideas); const i = opts.indexOf(ui.guesses[gid] || null);
        ui.guesses[gid] = opts[(i + (up ? 1 : opts.length - 1)) % opts.length]; SND.cue('sfx_ui', 0.4);
      }
      else if (k === ']' || k === 'PageDown' || k === 'x' || k === 'X') ui.page = (ui.page || 0) + 1;
      else if (k === '[' || k === 'PageUp' || k === 'z' || k === 'Z') ui.page = Math.max(0, (ui.page || 0) - 1);
    }
  }
  function toast(txt, extra) { ui.toast = Object.assign({ txt, until: (run ? run.t : ui.t) + 2.2 }, extra || {}); }

  /* ------------------------------------------------------------------ the one place a frame happens */
  let acc = 0;
  function tick(input) {
    ui.frames++; ui.t += 1 / 60;
    if (ui.screen === 'ending' || ui.screen === 'credits') ui.endT += 1 / 60;
    if (ui.screen === 'play' && run) {
      acc += 1 / 60; if (ui.mode === 'book') acc = 0;
      while (acc >= C.DT - 1e-9) {
        acc -= C.DT; prev = { x: run.x, y: run.y };
        const inp = Object.assign({}, input || swimInput());
        ui.moving = Math.abs(inp.dx) + Math.abs(inp.dy) > 0; if (inp.dx) ui.face = inp.dx > 0 ? 1 : -1;
        /* review D05: a sentence composed while the last still glows WAITS for the glow to end and is then spoken —
         * never dropped (a dropped right answer reads as a wrong one, the worst lie a deduction game can tell) */
        if (ui.pendingSpeak && run.t >= run.busyUntil) { inp.speak = ui.pendingSpeak; ui.pendingSpeak = null; ui.flash = { glyphs: inp.speak.slice(), until: run.t + C.P.sayCost }; if (ui.toast && !ui.toast.logged) ui.toast = null; }
        const ev = run.step(inp);
        if (ev) onEvent(ev);
        if (ui.screen !== 'play') break;
      }
      if (!FULL && ui.screen === 'play' && run.gates.some((q) => q.id === LAST_DEMO_GATE && q.open && run.x > q.x - 6)) ui.screen = 'demoend';
      const z = zoneOf(run.x);
      if (z !== ui.lastZone) { if (ui.lastZone >= 0 || z === 0) ui.banner = { txt: SPEC.ZONES[z], until: run.t + 3 }; ui.lastZone = z; }
      SND.setDepth(Math.max(0, run.x / ZW - 0.5));
      if (ui.saved == null || run.t - ui.saved > 15) save();
    }
    render(ui.screen === 'play' ? acc / C.DT : 1);
  }
  function onEvent(ev) {
    ui.lastEvent = ev;
    if (ev.opened) {
      SND.cue('sfx_open', 0.9); toast('', { opened: ev.opened }); if (ev.opened === 'R1') ui.hints.read = 1; save();
      if (ev.opened === LAST_DEMO_GATE && !FULL) { ui.screen = 'demoend'; ui.demoSeen = true; }
      if (FULL && SPEC.GATES.find((q) => q.id === ev.opened).into === null) { ui.screen = 'ending'; ui.endT = 0; ui.endStage = 0; SND.cue('sfx_end', 1); try { localStorage.removeItem(SAVE_KEY); } catch (e) { /* ignore */ } }
    } else if (ev.struck !== undefined) { SND.cue('sfx_eel', 0.9); toast('THE EEL! YOUR LAMP GUTTERS'); ui.fade = { until: run.t + 0.8 }; prev = { x: run.x, y: run.y }; }
    else if (ev.cold) { SND.cue('sfx_cold', 0.8); toast('COLD WATER THROWS YOU BACK'); }
    else if (ev.wrong) { SND.cue('sfx_wrong', 0.8); toast(ev.retreat ? 'IT TURNS AWAY FOR A WHILE' : 'A PUZZLED FLICKER'); }
    else if (ev.refused) toast(ev.refused === 'still speaking' ? 'WAIT - YOUR LAST WORDS STILL GLOW' : ev.refused === 'not listening yet' ? 'IT IS NOT LISTENING YET' : 'NOBODY HERE TO LISTEN');
    else if (ev.logged) { SND.cue('sfx_logged', 0.7); ui.toast = { txt: '', logged: ev.logged, until: run.t + 1.6 }; const sc = SPEC.SCENES.find((x) => x.id === ev.logged); sc.utt.forEach((w, j) => SND.tone(GL.hue(w), 0.1 + j * 0.3)); }
  }

  /* ------------------------------------------------------------------ drawing a scene */
  const ENTITY = new Set(['SHELL', 'SHOAL', 'RAY', 'KELP', 'ANGLER', 'EEL', 'VENT']);
  /* ONE picture of a scene, used by the world AND the logbook. q: when given, glyphs are QUEUED so they draw after
   * the light pass (emissive); the logbook passes none and draws them at once. */
  function drawScene(s, st, sx, sy, ph, on, k, dpx, dpy, withGlyphs, t, scale, q, lights) {
    const sc = scale || 1;
    if (withGlyphs && on) k = Math.max(0, Math.min(1, (ph - (0.6 * s.utt.length + 0.3)) / 1.2));   /* said, a beat, then done */
    if (st.warm && on) { for (let n = 0; n < 5; n++) { const wx = sx - 16 * sc + n * 8 * sc, wy = sy + 8 * sc - ((t * 12 + n * 7) % (22 * sc)); g.strokeStyle = 'rgba(255,150,70,0.8)'; g.beginPath(); g.moveTo(wx, wy); g.quadraticCurveTo(wx + 2, wy - 3, wx, wy - 6 * sc); g.stroke(); } if (lights) lights.push([sx, sy, 30, 0.45]); }
    if (st.dark && on) { const rg = g.createRadialGradient(sx, sy, 4 * sc, sx, sy, 30 * sc); rg.addColorStop(0, 'rgba(0,0,12,0.6)'); rg.addColorStop(1, 'rgba(0,0,12,0)'); g.fillStyle = rg; g.beginPath(); g.arc(sx, sy, 30 * sc, 0, 7); g.fill(); }
    if (st.lightSource && on) { g.fillStyle = `rgba(200,255,210,${0.35 * k + 0.2})`; g.beginPath(); g.arc(sx + 14 * sc, sy - 10 * sc, 4 * sc, 0, 7); g.fill(); if (lights) lights.push([sx + 14 * sc, sy - 10 * sc, 20, 0.8]); }
    const ents = [st.speaker];
    for (const a of st.acts) { if (!ents.includes(a[0])) ents.push(a[0]); if (a[2] && ENTITY.has(a[2]) && !ents.includes(a[2])) ents.push(a[2]); }
    ents.forEach((e, i) => {
      let ex = sx + (i - (ents.length - 1) / 2) * 17 * sc, ey = sy; const stt = {};
      for (const a of st.acts) if (a[0] === e && on) {
        if (a[1] === 'open') stt.open = k;
        if (a[1] === 'rise') { ey -= 16 * k * sc; for (let n = 0; n < 3; n++) { g.fillStyle = 'rgba(220,240,255,0.75)'; g.fillRect(Math.round(ex - 4 + n * 4), Math.round(ey + 9 + n * 3), 1, 1); } }
        if (a[1] === 'hide') { stt.alpha = 1 - 0.5 * k; if (a[2] && ents.includes(a[2])) ex += (ents.indexOf(a[2]) - i) * 12 * k * sc; }
        if (a[1] === 'eat' && a[2] && ents.includes(a[2])) ex += (ents.indexOf(a[2]) - i) * 10 * k * sc;
        if (a[1] === 'follow') { if (a[2] && ents.includes(a[2])) ex += (ents.indexOf(a[2]) - i) * 12 * k * sc; else { ex += (dpx - ex) * 0.5 * k; ey += (dpy - ey) * 0.5 * k; } }
        if (a[1] === 'light') { stt.glow = Math.max(0.3, k); if (lights) lights.push([ex + (e === 'ANGLER' ? 10 : 0), ey - (e === 'ANGLER' ? 10 : 12), 26 + 14 * k, 0.9]); }
        if (a[1] === 'sink') { ey += 14 * k * sc; g.fillStyle = 'rgba(200,220,255,0.55)'; for (let n = 0; n < 3; n++) g.fillRect(Math.round(ex - 1), Math.round(ey - 9 - n * 4), 2, 1); if (a[2] && ents.includes(a[2])) ex += (ents.indexOf(a[2]) - i) * 8 * k * sc; }
        if (a[1] === 'far') { stt.alpha = 1 - 0.6 * k; ex += 22 * k * sc; ey -= 6 * k * sc; }
      }
      g.save(); if (sc !== 1) { g.translate(ex, ey); g.scale(sc, sc); CR.ent(g, e, 0, 0, t + i, stt); } else CR.ent(g, e, ex, ey, t + i, stt); g.restore();
      if (on && e === st.speaker) {
        if (withGlyphs) {
          const utt = s.utt, gy = Math.max(15, Math.round(ey - 22));
          utt.forEach((w, j) => { const a = Math.max(0, Math.min(1, (ph - j * 0.6) / 0.4)); const gx = Math.round(ex - utt.length * GL.GSTEP / 2 + j * GL.GSTEP); if (q) q.push([w, gx, gy, a]); else GL.draw(g, w, gx, gy, a, 1, { plate: true }); });
        }
        if (st.diver) { g.strokeStyle = 'rgba(255,217,122,0.4)'; g.setLineDash([2, 3]); g.beginPath(); g.moveTo(ex, ey); g.lineTo(dpx, dpy); g.stroke(); g.setLineDash([]); }
        g.fillStyle = 'rgba(207,232,255,0.75)'; g.fillRect(Math.round(ex) - 3, Math.round(ey) + 9 * sc, 7, 1);   /* the speaker, underlined */
      }
      if (on && k > 0.2 && st.acts.some((a) => a[1] === 'eat' && (a[2] === e || (!a[2] && a[0] === e)))) { g.fillStyle = '#fff6d8'; for (let n = 0; n < 4; n++) g.fillRect(Math.round(ex - 4 + n * 3), Math.round(ey - 5 - ((ph * 4 + n * 2) % 6)), 1, 1); }
    });
  }

  /* ------------------------------------------------------------------ screens */
  let panels = [];   /* the panels drawn this frame — text() checks each line against the one it sits in (review D01-D04) */
  function panel(x, y, w, h) { panels.push([x, y, w, h]); g.fillStyle = PAL.panel; g.fillRect(x, y, w, h); g.strokeStyle = PAL.line; g.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1); g.fillStyle = 'rgba(127,227,255,0.18)'; g.fillRect(x + 1, y + 1, w - 2, 1); }
  /* every line drawn is bounds-checked against the canvas; a line that runs off it is RECORDED (window.__lodState
   * .textOverflow), because an overflowing card is silent on every other instrument */
  const overflow = {};
  function text(s, x, y, o) {
    const w = F.width(s, o && o.face), x0 = o && o.align === 'center' ? x - w / 2 : o && o.align === 'right' ? x - w : x;
    if (x0 < 0 || x0 + w > W) overflow[String(s)] = Math.round(x0) + '..' + Math.round(x0 + w);
    const h = (o && o.face === 'display') ? 12 : 7;
    for (const [px, py, pw, ph] of panels) if (y >= py && y + h <= py + ph + 1 && x0 < px + pw && x0 + w > px && (x0 < px + 1 || x0 + w > px + pw - 1)) overflow['PANEL ' + String(s)] = Math.round(x0) + '..' + Math.round(x0 + w) + ' in ' + px + '..' + (px + pw);
    return F.text(g, s, x, y, o);
  }
  function renderPlay(frac) {
    const px = prev.x + (run.x - prev.x) * frac, py = prev.y + (run.y - prev.y) * frac;
    /* review D08: the camera may look 44 px past the zone's end when there is a next zone, so a wall and its gap (or
     * the read beat's three mouths) are fully on screen instead of clipped at the frame edge */
    const over = run.maxZone() + 1 < ZONES ? 44 : 0;
    const camX = Math.round(Math.max(0, Math.min(px - W / 2, (run.maxZone() + 1) * ZW - W + over)));
    ui.camX = camX;
    g.fillStyle = '#061018'; g.fillRect(0, 0, W, H);
    WORLD.drawGround(g, camX, ZONES);
    WORLD.drawCaustics(g, camX, run.t, ZONES);
    const lights = [], q = [];
    /* vents and lanterns in the seabed give their own light */
    const glows = [];   /* emissive colour, drawn AFTER the light pass: [x, y, r, 'r,g,b', a] */
    for (let z = 0; z < ZONES; z++) {
      const Z = WORLD.state.zones[z]; if (!Z) continue; const deep = SPEC.LOOKS[z].dark >= 0.3;
      for (const [cx, cy, id] of Z.props) {
        const sx = z * ZW + cx - camX; if (sx < -40 || sx > W + 40) continue;
        if (/vent/.test(id)) { lights.push([sx, cy - 6, 40, 0.75]); glows.push([sx, cy - 10, 16, '255,130,60', 0.35 + 0.1 * Math.sin(run.t * 2 + cx)]); }
        else if (id === 'lantern') { lights.push([sx, cy, 30, 0.85]); glows.push([sx, cy, 10, '255,210,120', 0.4]); }
        else if (deep) {
          /* review D10: the dark reef is bioluminescent — every prop in a dark zone carries a slow, faint living light */
          const hue = [[120, 230, 255], [255, 120, 210], [150, 255, 170], [190, 150, 255]][Math.floor(cx * 7 + cy * 3) % 4];
          const a = 0.16 + 0.1 * Math.sin(run.t * 1.3 + cx * 0.7);
          lights.push([sx, cy, 22, 0.4]); glows.push([sx, cy - 2, 12, hue.join(','), a]);
        }
      }
    }
    for (const gt of run.gates) {
      WORLD.drawWall(g, gt, camX, run.t);
      /* the read beat's mouths carry their own light: warm water glows, cold water is a faint blue */
      if (gt.mouths && !gt.open) for (const m of gt.mouths) { const mx = m.x - camX; lights.push([mx, m.y, 34, 0.8]); glows.push([mx, m.y, m.warm ? 18 : 12, m.warm ? '255,140,60' : '120,180,255', m.warm ? 0.45 : 0.25]); }
    }
    for (const s of run.scenes) {
      const sx = s.x - camX, sy = s.y; if (sx < -34 || sx > W + 34) continue;
      const st = STAGE[s.id]; if (!st) continue;
      const ph = run.phaseOf(s, run.t), on = ph < C.P.window;
      drawScene(s, st, sx, sy, ph, on, on ? Math.min(1, ph / 1.5) : 0, px - camX, py, true, run.t, 1, q, lights);
      lights.push([sx, sy, on ? 38 : 22, on ? 0.85 : 0.45]);
      if (run.seen.includes(s.id)) { g.fillStyle = 'rgba(255,217,122,0.7)'; g.fillRect(Math.round(sx) - 1, sy + 13, 3, 1); }
    }
    for (const gt of run.gates) {
      const gx = gt.x - camX; if (gx < -40 || gx > W + 40) continue;
      const away = run.t < gt.awayUntil, who = LISTENER[gt.id];
      if (!gt.open || who === 'SHELL') CR.ent(g, who, gx + (away ? 18 : 0) + (gt.open ? 0 : 0), gt.y + (gt.open && who !== 'SHELL' ? -30 : 0), run.t, { alpha: away ? 0.35 : 1, open: gt.open ? 1 : 0 });
      else if (gt.open) CR.ent(g, who, gx - 30, gt.y - 28, run.t, { alpha: 0.8 });
      lights.push([gx, gt.y, 30, 0.7]);
      if (away) { const left = (gt.awayUntil - run.t) / (C.P.retreat + C.P.sayCost); g.fillStyle = 'rgba(255,217,122,0.7)'; g.fillRect(Math.round(gx + 10), gt.y - 14, Math.round(16 * left), 1); }
      if (!gt.open && gt.kind !== 'read' && Math.hypot(gt.x - px, gt.y - py) < C.P.speakR + 24) { g.strokeStyle = 'rgba(255,217,122,0.55)'; g.beginPath(); g.arc(Math.round(gx) + 0.5, gt.y + 0.5, C.P.speakR, 0, 7); g.stroke(); if (!ui.hints.lamp) ui.hint = 'SPACE: ASK IT, IN ITS WORDS, TO OPEN THE WAY'; }
      if (gt.kind === 'read' && !gt.open && Math.hypot(gt.x - px, gt.y - py) < 90 && !ui.hints.read) ui.hint = 'THE ELDER IS TELLING YOU SOMETHING. DO IT.';
      /* the elder shoal flashes its instruction to anyone who comes near (the read beat) */
      if (gt.kind === 'read' && !gt.open && Math.hypot(gt.x - px, gt.y - py) < 90) gt.words.forEach((w, j) => q.push([w, Math.round(gx - 18 + j * GL.GSTEP), gt.y - 24, 0.6 + 0.4 * Math.sin(run.t * 3 + j)]));
    }
    if (run.eels) for (const e of run.eels) {
      if (e.z > run.maxZone()) continue; const exs = e.x - camX; if (exs < -30 || exs > W + 30) continue;
      CR.ent(g, 'EEL', exs, e.y, run.t * 1.5, { scale: 1.5, hunter: true });
      if (e.hunting) { g.strokeStyle = 'rgba(255,90,74,0.7)'; g.beginPath(); g.arc(Math.round(exs), Math.round(e.y), 13, 0, 7); g.stroke(); }
      lights.push([exs, e.y, 14, 0.5]);
    }
    const lit = run.litUntil !== undefined && run.t < run.litUntil;
    CR.ent(g, 'DIVER', px - camX, py, run.t, { face: ui.face, moving: ui.moving });
    lights.push([px - camX, py, lit ? 70 : 54, 1]);
    const amb = WORLD.drawWater(g, camX, lights, 0);
    /* ---- emissive: after the light pass ---- */
    g.save(); g.globalCompositeOperation = 'lighter';
    for (const [x, y, r, rgb, a] of glows) { const rg = g.createRadialGradient(x, y, 0, x, y, r); rg.addColorStop(0, `rgba(${rgb},${a})`); rg.addColorStop(1, `rgba(${rgb},0)`); g.fillStyle = rg; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill(); }
    g.restore();
    for (const [w, x, y, a] of q) GL.draw(g, w, x, y, a, 1, { plate: true });   /* review D18: a plate in dark water too */
    if (ui.fade && run.t < ui.fade.until) { g.fillStyle = `rgba(0,0,0,${Math.max(0, (ui.fade.until - run.t) / 0.8)})`; g.fillRect(0, 0, W, H); }   /* D22 */
    if (lit) { g.save(); g.globalCompositeOperation = 'lighter'; g.fillStyle = 'rgba(255,220,140,0.12)'; g.beginPath(); g.arc(px - camX, py, 20, 0, 7); g.fill(); g.restore(); }
    if (ui.flash && run.t < ui.flash.until) ui.flash.glyphs.forEach((w, j) => GL.draw(g, w, Math.round(px - camX - 1.5 * GL.GSTEP + j * GL.GSTEP), Math.round(py - 24), 1, 1, { plate: true }));
    if (run.eels) for (const e of run.eels) { if (e.z > run.maxZone()) continue; const exs = e.x - camX; if (exs > -10 && exs < W + 10) { g.fillStyle = '#ff5a4a'; g.fillRect(Math.round(exs) + 2, Math.round(e.y) - 2, 2, 2); } }
    WORLD.drawSnow(g, camX, run.t, amb.dark);
    renderHud();
    if (ui.mode === 'lamp') renderLamp();
    if (ui.mode === 'book') renderBook();
  }
  function renderHud() {
    const gs = seenGlyphs();
    g.fillStyle = 'rgba(4,10,18,0.78)'; g.fillRect(0, 0, W, 12);
    /* review D07: the "just logged" signal lives HERE, in the HUD — the new sentence's glyphs glow and are underlined
     * in the strip — never as a plate floating in the world over some other creature's evidence */
    const fresh = ui.toast && ui.toast.logged && run.t < ui.toast.until ? SPEC.SCENES.find((x) => x.id === ui.toast.logged).utt : [];
    gs.forEach((w, i) => { const x = 3 + i * (GL.SPAN + 3); const on = fresh.includes(w); GL.draw(g, w, x, 2, 0.95, 1, { halo: on }); if (on) { g.fillStyle = PAL.gold; g.fillRect(x, 11, GL.SPAN + 1, 1); } });
    text(run.seen.length + ' SCENES', W - 3, 3, { align: 'right', colour: fresh.length ? PAL.gold : PAL.dim });
    if (ui.banner && run.t < ui.banner.until) {
      const a = Math.min(1, (ui.banner.until - run.t) / 0.8);
      g.save(); g.globalAlpha = a; text(ui.banner.txt, W / 2, 26, { face: 'display', align: 'center', colour: '#e8f6ff', outline: true }); g.restore();
    }
    let hint = null;
    /* review D11: the hint about the gate in front of you wins over the logbook reminder */
    if (ui.hint) hint = ui.hint;
    else if (!ui.hints.swim && run.t < 12) hint = 'ARROWS OR WASD: SWIM   ESC: PAUSE';
    else if (run.seen.length && !ui.hints.book) hint = 'THEY SPOKE! TAB: YOUR LOGBOOK';
    if (run.t > 12) ui.hints.swim = 1;
    ui.hint = null;
    if (hint && ui.mode === 'swim') { const w = F.width(hint) + 8; g.fillStyle = 'rgba(4,10,18,0.8)'; g.fillRect(W / 2 - w / 2, H - 14, w, 11); text(hint, W / 2, H - 12, { align: 'center', colour: PAL.gold }); }
    if (ui.toast && run.t < ui.toast.until) {
      if (ui.toast.logged) { /* shown in the HUD strip above (D07) */ }
      else if (ui.toast.opened) text('THE WAY OPENS', W / 2, 42, { align: 'center', colour: PAL.gold, outline: true });
      else if (ui.toast.txt) text(ui.toast.txt, W / 2, 42, { align: 'center', colour: PAL.gold, outline: true });
    }
  }
  function renderLamp() {
    const gs = seenGlyphs();
    /* review D02: the key line fits its panel (45 characters) and names ESC; the three cells sit INSIDE the panel */
    panel(18, 108, 284, 70);
    text('Q/E PICK  F ADD  R UNDO  SPACE SAY  ESC CLOSE', 160, 112, { align: 'center', colour: PAL.dim });
    gs.forEach((w, i) => { const x = 24 + i * 15; if (i === ui.sel) { g.strokeStyle = PAL.gold; g.strokeRect(x - 2.5, 121.5, GL.SPAN + 5, 26); } GL.draw(g, w, x, 124, 1, 1, { halo: i === ui.sel }); CR.idea(g, ui.guesses[w], x + GL.HALF, 140); });
    for (let j = 0; j < 3; j++) { g.strokeStyle = 'rgba(159,179,191,0.55)'; g.strokeRect(112.5 + j * 34, 152.5, 2 * GL.SPAN + 8, 2 * GL.SPAN + 2); if (ui.lamp[j]) GL.draw(g, ui.lamp[j], 116 + j * 34, 153, 1, 2); }
  }
  /* LOGBOOK: the lexicon strip (every glyph seen, your pencilled guess under it), then every scene you have seen,
   * as the picture you saw it in, with its sentence; the selected glyph lights every scene it occurs in */
  function renderBook() {
    const gs = seenGlyphs();
    g.fillStyle = 'rgb(8,16,26)'; g.fillRect(4, 13, 312, 165); g.strokeStyle = PAL.line; g.strokeRect(4.5, 13.5, 311, 164); panels.push([4, 13, 312, 165]);
    /* review D04/D23: 9 cards a page (3 rows) so the key line never crosses a card; the page counter sits on the title
     * line; the page index is clamped */
    const ids = run.seen.slice().reverse(), per = 9, pages = Math.max(1, Math.ceil(ids.length / per));
    ui.page = Math.max(0, Math.min(ui.page || 0, pages - 1));
    const page = ui.page, show = ids.slice(page * per, page * per + per);
    text('LOGBOOK', 9, 17, { colour: PAL.cyan });
    text('PAGE ' + (page + 1) + '/' + pages, 311, 17, { align: 'right', colour: PAL.dim });
    text('L/R GLYPH  U/D PENCIL  Z/X PAGE  TAB CLOSE', 160, 166, { align: 'center', colour: PAL.dim });
    gs.forEach((w, i) => { const x = 10 + i * 17; if (i === ui.bookSel) { g.strokeStyle = PAL.gold; g.strokeRect(x - 2.5, 26.5, GL.SPAN + 5, 26); } GL.draw(g, w, x, 28, 1, 1, { halo: i === ui.bookSel }); CR.idea(g, ui.guesses[w], x + 4, 44); });
    const selG = gs[ui.bookSel];
    /* review D17: the note under the selected glyph is NAMED while you choose it (your own word, never the answer) */
    const NOTE = { SHELL: 'SHELL', SHOAL: 'SHOAL', RAY: 'RAY', KELP: 'KELP', ANGLER: 'ANGLER', EEL: 'EEL', VENT: 'VENT', DIVER: 'YOU', '~open': 'OPENS', '~eat': 'EATS', '~hide': 'HIDES', '~rise': 'RISES', '~follow': 'FOLLOWS', '~warm': 'WARMTH', '~light': 'LIGHT', '~dark': 'DARKNESS', '~sink': 'SINKS', '~far': 'AWAY' };
    if (selG) text('YOUR NOTE: ' + (ui.guesses[selG] ? NOTE[ui.guesses[selG]] || '?' : 'NONE'), 311, 51, { align: 'right', colour: PAL.gold });
    show.forEach((id, n) => {
      const s = SPEC.SCENES.find((x) => x.id === id), st = STAGE[id]; if (!st) return;
      const col = n % 3, row = Math.floor(n / 3), cx = 8 + col * 103, cy = 61 + row * 32;
      const hit = selG && s.utt.includes(selG);
      g.fillStyle = hit ? 'rgba(120,100,40,0.5)' : 'rgba(30,60,72,0.55)'; g.fillRect(cx, cy, 100, 28);
      if (hit) { g.strokeStyle = PAL.gold; g.strokeRect(cx + 0.5, cy + 0.5, 99, 27); }
      g.save(); g.beginPath(); g.rect(cx, cy, 60, 28); g.clip();
      /* review D24: a dark scene's card is not darkened (a black smudge hid the evidence); a small dark mark says it */
      drawScene(s, Object.assign({}, st, { dark: false }), cx + 26, cy + 17, 9, true, 1, cx + 50, cy + 9, false, 0, 0.8, null, null);
      if (st.diver) CR.ent(g, 'DIVER', cx + 50, cy + 9, 0, { face: -1 });
      if (st.dark) CR.idea(g, '~dark', cx + 6, cy + 6);
      g.restore();
      s.utt.forEach((w, j) => { GL.draw(g, w, cx + 62 + j * 12, cy + 3, 1, 1, { halo: w === selG }); CR.idea(g, ui.guesses[w], cx + 66 + j * 12, cy + 20); });
    });
    if (!ids.length) text('NOTHING OVERHEARD YET', 160, 100, { align: 'center', colour: PAL.dim });
  }
  /* the title: the Shallows drifting behind, the name in the display face, glyphs rising like bubbles */
  function backdrop(zone, t, dark) {
    const camX = Math.round(zone * ZW + 160 + Math.sin(t * 0.05) * 150);
    g.fillStyle = '#061018'; g.fillRect(0, 0, W, H);
    WORLD.drawGround(g, camX, ZONES); WORLD.drawCaustics(g, camX, t, ZONES);
    const lights = [[160, 70, 150, 0.5]];
    WORLD.drawWater(g, camX, lights, dark || 0.35);
    WORLD.drawSnow(g, camX, t, 0.6);
  }
  function renderTitle() {
    backdrop(1, ui.t, 0.62);   /* the Kelp Forest under deeper water: the first picture is lit by the glyphs, not washed out */
    const ids = GL.GLYPH_IDS;
    for (let i = 0; i < 9; i++) { const id = ids[(i * 5) % ids.length], x = 20 + i * 34 + Math.sin(ui.t + i) * 4, y = H - ((ui.t * (6 + i % 3) + i * 23) % (H + 20)); GL.draw(g, id, Math.round(x), Math.round(y), 0.55, 1); }
    text('LINGUIST', W / 2, 28, { face: 'display', align: 'center', colour: '#bff4ff', outline: '#031019' });
    text('OF THE DEEP', W / 2, 44, { face: 'display', align: 'center', colour: '#7fe3ff', outline: '#031019' });
    text('THE REEF SPEAKS IN LIGHT', W / 2, 62, { align: 'center', colour: PAL.gold, outline: true });
    const items = TITLE_ITEMS();
    panel(104, 84, 112, 14 + items.length * 11);
    items.forEach((it, i) => { const label = it === 'SOUND' ? 'SOUND: ' + (SND.muted ? 'OFF' : 'ON') : it; const sel = i === ui.menu % items.length; text((sel ? '> ' : '  ') + label, 114, 92 + i * 11, { colour: sel ? PAL.gold : PAL.text }); });
    text(FULL ? 'FULL GAME' : 'FREE DEMO', 4, H - 10, { colour: PAL.dim });
    text('UP/DOWN + ENTER', W - 4, H - 10, { align: 'right', colour: PAL.dim });
  }
  function renderHelp() {
    backdrop(0, ui.t, 0.7);
    panel(14, 10, 292, 160);
    text('HOW TO PLAY', W / 2, 16, { face: 'display', align: 'center', colour: PAL.cyan });
    /* ⛔ every line <= 36 characters: the body face is 6 px a character and this column is 222 px wide. The first
     * card ran its lines off the panel and off the canvas (seen in verify_suite's in_help.png). */
    const L = [
      ['SWIM', 'ARROWS OR WASD'],
      ['WATCH', 'CREATURES TALK IN GLYPHS, THEN ACT.'],
      ['', 'SWIM CLOSE WHILE ONE SPEAKS.'],
      ['LOGBOOK', 'TAB: EVERY SCENE YOU HAVE SEEN.'],
      ['', 'UP/DOWN PENCILS A GUESS.'],
      ['SPEAK', 'SPACE BY A CREATURE IN THE WAY.'],
      ['', 'ASK IT IN ITS WORDS TO OPEN THE WAY'],
      ['', 'Q/E PICK  F ADD  R UNDO  SPACE SAY'],
      ['', 'THREE WORDS, IN ANY ORDER.'],
      ['BEWARE', 'SPEAKING LIGHTS YOU UP.'],
      ['', 'EELS HUNT LIGHT.'],
      ['PAUSE', 'ESC      M: SOUND ON/OFF'],
    ];
    for (const [, b] of L) if (b.length > 36) throw new Error('help line over 36 characters: ' + b);
    L.forEach(([a, b], i) => { text(a, 22, 32 + i * 10, { colour: PAL.gold }); text(b, 76, 32 + i * 10, { colour: PAL.text }); });
    text('NOTHING TELLS YOU WHAT A WORD MEANS.', W / 2, 158, { align: 'center', colour: PAL.dim });
  }
  function renderConfirm() {
    backdrop(0, ui.t, 0.6);
    panel(60, 64, 200, 52);
    text('START A NEW DIVE?', W / 2, 72, { align: 'center', colour: PAL.cyan });
    text('YOUR SAVED DIVE WILL BE LOST.', W / 2, 86, { align: 'center', colour: PAL.text });
    text('ENTER: NEW DIVE    ESC: BACK', W / 2, 102, { align: 'center', colour: PAL.gold });
  }
  function renderPause() {
    renderPlay(1);
    g.fillStyle = 'rgba(2,6,12,0.6)'; g.fillRect(0, 0, W, H);
    panel(96, 44, 128, 22 + PAUSE_ITEMS.length * 12);
    text('PAUSED', W / 2, 50, { face: 'display', align: 'center', colour: PAL.cyan });
    PAUSE_ITEMS.forEach((it, i) => { const label = it === 'SOUND' ? 'SOUND: ' + (SND.muted ? 'OFF' : 'ON') : it; const sel = i === ui.pause; text((sel ? '> ' : '  ') + label, 104, 68 + i * 12, { colour: sel ? PAL.gold : PAL.text }); });
    text(SPEC.ZONES[zoneOf(run.x)] + '   ' + seenGlyphs().length + ' OF 18 GLYPHS SEEN', W / 2, 150, { align: 'center', colour: PAL.dim, outline: true });
  }
  function renderDemoEnd() {
    backdrop(2, ui.t, 0.75);
    panel(20, 18, 280, 146);
    text('THE TRENCH MOUTH', W / 2, 26, { face: 'display', align: 'center', colour: PAL.cyan });
    /* review D06: the first cut claimed "YOU HAVE HEARD IT SPEAK TWICE" — no demo scene has an eel speaker (its scenes
     * are paid content). Every line here must be true of the DEMO the player just finished. */
    const L = ['THE ANGLER LIGHTS THE WAY DOWN.', 'BELOW, AN EEL GUARDS THE PASSAGE.', 'IT SPEAKS WORDS YOU HAVE NOT HEARD YET.', '', 'THIS IS THE END OF THE FREE DEMO.', 'THE FULL GAME ADDS THE TRENCH, THE VENTS,', 'THE WARM CURRENT, THE ABYSS AND THE ENDING,', 'WHERE THE WHOLE LANGUAGE IS REVEALED.', '', 'LINGUIST OF THE DEEP  -  WINDOWS  -  $9.99'];
    L.forEach((l, i) => text(l, W / 2, 46 + i * 10, { align: 'center', colour: i === 9 ? PAL.gold : i < 3 ? PAL.text : PAL.dim }));
    text('ENTER: KEEP SWIMMING    ESC: TITLE', W / 2, 152, { align: 'center', colour: PAL.gold });
  }
  /* THE ENDING (paid): the elder ray takes you down, then the lexicon is revealed beside your pencilled notes */
  function renderEnding() {
    const t = ui.endT;
    if (ui.endStage === 0) {
      backdrop(6, ui.t, Math.min(0.94, 0.6 + t * 0.05));
      CR.ent(g, 'RAY', 160, 70 + t * 6, ui.t, { alpha: Math.max(0, 1 - t / 9) });
      CR.ent(g, 'DIVER', 150, 84 + t * 6, ui.t, { face: 1, moving: true, alpha: Math.max(0, 1 - t / 9) });
      SPEC.ENDING.forEach((l, i) => { g.save(); g.globalAlpha = Math.max(0, Math.min(1, t - 1 - i * 1.2)); text(l, W / 2, 130 + i * 11, { align: 'center', colour: PAL.text, outline: true }); g.restore(); });
      if (t > 4) text('ENTER', W / 2, 168, { align: 'center', colour: PAL.gold });
      return;
    }
    g.fillStyle = '#030811'; g.fillRect(0, 0, W, H);
    text('THE REEF\'S OLDEST WORDS', W / 2, 6, { face: 'display', align: 'center', colour: PAL.cyan });
    let right = 0;
    GL.GLYPH_IDS.forEach((id, i) => {
      const col = i % 3, row = Math.floor(i / 3), x = 10 + col * 104, y = 26 + row * 24;
      const meaning = SPEC.GLOSS[id], mine = ui.guesses[id], ok = mine && SPEC.IDEA_OF[meaning] === mine;
      if (ok) right++;
      g.fillStyle = ok ? 'rgba(80,120,60,0.45)' : 'rgba(30,50,64,0.5)'; g.fillRect(x, y, 100, 21);
      GL.draw(g, id, x + 4, y + 6, 1, 1);
      CR.idea(g, mine, x + 26, y + 11);
      text(meaning, x + 38, y + 7, { colour: ok ? '#c8ffb0' : PAL.text });
    });
    text('YOUR NOTES READ ' + right + ' OF 18 RIGHTLY.  ENTER: CREDITS', W / 2, 172, { align: 'center', colour: PAL.gold });
  }
  function renderCredits() {
    backdrop(ZONES - 1, ui.t, 0.8);
    const L = [['LINGUIST OF THE DEEP', 'display', PAL.cyan], ['', 'body'], ['A GAME BY CORE SYSTEMS ASSET FACTORY (CSAF)', 'body', PAL.text], ['', 'body'],
      ['SEABED: VERDANT 26 - DEEP OCEAN, A CSAF TILESET', 'body', PAL.dim], ['LETTERING: CSAF, DRAWN FOR THIS STUDIO', 'body', PAL.dim], ['MUSIC AND SOUND: SYNTHESISED BY CSAF, NO SAMPLES', 'body', PAL.dim], ['', 'body'],
      ['MADE WITH AI: THE CODE, ART AND WORDS OF THIS GAME', 'body', PAL.gold], ['WERE WRITTEN WITH GENERATIVE AI ASSISTANCE.', 'body', PAL.gold], ['', 'body'],
      ['(C) 2026 CORE SYSTEMS ASSET FACTORY', 'body', PAL.dim], ['THANK YOU FOR LISTENING TO THE REEF.', 'body', PAL.text]];
    L.forEach(([s, face, col], i) => text(s, W / 2, 16 + i * 11, { face, align: 'center', colour: col, outline: true }));
    text('ENTER', W / 2, 168, { align: 'center', colour: PAL.gold });
  }
  function renderLoading() {
    g.fillStyle = '#061018'; g.fillRect(0, 0, W, H);
    text(WORLD.state.failed ? 'THE REEF COULD NOT LOAD: ' + WORLD.state.failed : 'DIVING...', W / 2, 86, { align: 'center', colour: WORLD.state.failed ? '#ff8a7a' : PAL.dim });
  }
  function render(frac) {
    panels = [];
    if (!WORLD.state.ready) { renderLoading(); return; }
    if (!WORLD.state.zones.length) WORLD.build(lay);
    if (ui.screen === 'title') renderTitle();
    else if (ui.screen === 'help') renderHelp();
    else if (ui.screen === 'credits') renderCredits();
    else if (ui.screen === 'pause') renderPause();
    else if (ui.screen === 'demoend') renderDemoEnd();
    else if (ui.screen === 'confirm') renderConfirm();
    else if (ui.screen === 'ending') renderEnding();
    else renderPlay(frac);
  }

  /* ------------------------------------------------------------------ wiring */
  function fit() {
    /* whole-number scales (square pixels) from 2x up; below that the canvas fills the screen at a fractional scale —
     * a phone held upright (390 px) showed a 320 px game at 82% width when this floored to 1x (verify_suite viewport) */
    const s = Math.min(innerWidth / W, innerHeight / H), k = s >= 2 ? Math.floor(s) : s;
    cv.style.width = Math.round(W * k) + 'px'; cv.style.height = Math.round(H * k) + 'px';
  }
  addEventListener('resize', fit); fit();
  addEventListener('keydown', (e) => { if (['Tab', ' ', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Backspace'].includes(e.key)) e.preventDefault(); if (!e.repeat) handleKey(e.key); keys[e.key] = true; });
  addEventListener('keyup', (e) => { keys[e.key] = false; });
  addEventListener('blur', () => { for (const k in keys) keys[k] = false; if (ui.screen === 'play') { ui.screen = 'pause'; ui.pause = 0; save(); } });
  addEventListener('mousedown', () => { SND.unlock(); window.focus(); });
  SND.load();
  let last = 0;
  function loop(ts) { if (!last) last = ts; let n = Math.min(4, Math.round((ts - last) / (1000 / 60))); last += n * (1000 / 60); if (ts - last > 200) last = ts; while (n-- > 0) tick(); requestAnimationFrame(loop); }
  window.__lodTick = function (n, input) { for (let i = 0; i < (n || 1); i++) tick(input); return window.__lodState(); };
  window.__lodKey = function (k) { handleKey(k); return ui.screen + '/' + ui.mode; };
  window.__lodState = function () {
    return { screen: ui.screen, mode: ui.mode, edition: SPEC.EDITION, t: run ? +run.t.toFixed(2) : 0, x: run ? +run.x.toFixed(1) : 0, y: run ? +run.y.toFixed(1) : 0,
      seen: run ? run.seen.slice() : [], open: run ? run.gates.filter((q) => q.open).map((q) => q.id) : [], zone: run ? zoneOf(run.x) : 0, camZone: Math.floor(((ui.camX || 0) + W / 2) / ZW), frames: ui.frames,
      artReady: WORLD.state.ready, artMissing: Object.keys(WORLD.state.missing), fontMissing: Object.keys(F.missing), textOverflow: Object.assign({}, overflow), contacts: run ? run.contacts : 0, eels: run && run.eels ? run.eels.map((e) => [e.z, Math.round(e.x), Math.round(e.y)]) : [], sound: SND.report() };
  };
  window.__lod = { get run() { return run; }, ui, lay, GLYPH: GL.GLYPH, drawGlyph: (id, x, y, a, s, ctx) => GL.strokes(ctx || g, id, x, y, a == null ? 1 : a, s || 1), GLYPH_NODES: GL.NODES, GLYPH_SPAN: GL.SPAN, seenGlyphs, newRun, save, loadRun, handleKey,
    /* after a harness moves the diver, the renderer must not interpolate from the old spot (a staged Trench shot drew
     * the Kelp Forest: prev lagged one 0.1 s step behind the teleport) */
    snap: () => { prev = { x: run.x, y: run.y }; acc = 0; } };
  if (!/[?&]harness=1/.test(location.search)) requestAnimationFrame(loop);
})();
