/* world.js — the reef. Each zone's seabed is COMPOSED at load from CSAF's own tileset Verdant 26 · Deep Ocean
 * (art/deep.png, indexed by art/atlas.js): a base fill, autotiled regions laid ON it (the pack's `X_on_Y` sets, one
 * 47-mask blob each), and the pack's own props. Deterministic: the same zone always builds the same floor.
 * Then, every frame: sunlight caustics in the shallows, drifting marine snow, and the LIGHT PASS — the water goes
 * dark with depth and only lights cut it (your lamp, a scene while it plays, a lure, a vent). Emissive things are
 * drawn by the caller AFTER this pass (wing §0z-1: emissive ink after the light pass, lit surfaces before it). */
(function (root) {
  'use strict';
  const C = root.LOD_CORE, SPEC = root.LOD_SPEC, A = root.LOD_ATLAS;
  const T = 16, ZW = C.ZW, ZH = C.ZH, COLS = ZW / T, ROWS = Math.ceil(ZH / T);
  const N = 1, NE = 2, E = 4, SE = 8, S = 16, SW = 32, W = 64, NW = 128;
  function normalise(m) {
    let r = m;
    if (!((m & N) && (m & E))) r &= ~NE; if (!((m & E) && (m & S))) r &= ~SE;
    if (!((m & S) && (m & W))) r &= ~SW; if (!((m & W) && (m & N))) r &= ~NW;
    return r & 255;
  }
  function maskName(m) {
    if (m === 255) return 'fill'; if (m === 0) return 'single';
    const p = []; if (m & N) p.push('n'); if (m & E) p.push('e'); if (m & S) p.push('s'); if (m & W) p.push('w');
    const c = []; if (m & NE) c.push('ne'); if (m & SE) c.push('se'); if (m & SW) c.push('sw'); if (m & NW) c.push('nw');
    return (p.join('') || 'x') + (c.length ? '_' + c.join('') : '');
  }
  const img = new Image();
  const state = { ready: false, failed: null, zones: [], missing: {} };
  img.onload = () => { state.ready = true; };
  img.onerror = () => { state.failed = 'art/deep.png did not load'; };
  img.src = A.sheet;

  function blit(g, id, x, y) {
    const t = A.tiles[id];
    if (!t) { state.missing[id] = (state.missing[id] || 0) + 1; return false; }
    const r = t.r; g.drawImage(img, r[0], r[1], r[2], r[3], Math.round(x), Math.round(y), r[2], r[3]); return true;
  }
  /* ⛔ An INTEGER hash with a finaliser. The first build hashed the string "z:layer:x:y" with FNV-1a, whose high bits
   * barely see the LAST character — so the field varied with x and hardly with y, and every region rendered as a
   * full-height vertical stripe (smoke frame 03). Seen by looking; the build had no error. */
  function ih(a, b, c) {
    let h = Math.imul(a | 0, 374761393) ^ Math.imul(b | 0, 668265263) ^ Math.imul(c | 0, 2246822519);
    h = Math.imul(h ^ (h >>> 15), 2246822507); h = Math.imul(h ^ (h >>> 13), 3266489909); h ^= h >>> 16;
    return (h >>> 0) / 4294967296;
  }
  /* smooth value noise, seeded per zone+layer */
  function field(z, layer) {
    const H = (x, y) => ih(x + 1000 * (layer + 1), y + 7 * z, 9173 + z * 131 + layer * 17);
    const sm = (t) => t * t * (3 - 2 * t);
    const at = (x, y, f) => { const X = Math.floor(x / f), Y = Math.floor(y / f), fx = sm(x / f - X), fy = sm(y / f - Y);
      const a = H(X, Y), b = H(X + 1, Y), c = H(X, Y + 1), d = H(X + 1, Y + 1); return (a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + d * fx) * fy; };
    const v = [];
    for (let y = 0; y < ROWS; y++) for (let x = 0; x < COLS; x++) v.push(at(x, y, 5) * 0.7 + at(x, y, 2.3) * 0.3);
    return v;
  }
  /* a region = the cells above the coverage QUANTILE of its own field (coverage is exact whatever the seed), minus
   * the wall columns and cells another region owns, then cleaned: no single-cell islands, no single-cell holes */
  function region(z, layer, coverage, taken) {
    const v = field(z, layer), idx = v.map((_, i) => i).filter((i) => (i % COLS) < COLS - 3 && !taken[i]);
    const cut = idx.map((i) => v[i]).sort((a, b) => b - a)[Math.max(0, Math.floor(idx.length * coverage) - 1)];
    let on = v.map((val, i) => !taken[i] && (i % COLS) < COLS - 3 && val >= cut ? 1 : 0);
    for (let pass = 0; pass < 2; pass++) {
      const nx = on.slice();
      for (let y = 0; y < ROWS; y++) for (let x = 0; x < COLS; x++) {
        const i = y * COLS + x; let n = 0;
        for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const X = x + dx, Y = y + dy; if (X >= 0 && Y >= 0 && X < COLS && Y < ROWS && on[Y * COLS + X]) n++; }
        if (on[i] && n <= 1) nx[i] = 0;
        if (!on[i] && n >= 3 && !taken[i] && x < COLS - 3) nx[i] = 1;
      }
      on = nx;
    }
    /* a buffer ring so two regions never touch (each draws its own edge onto the base) */
    for (let i = 0; i < on.length; i++) if (on[i]) { const x = i % COLS, y = (i / COLS) | 0; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const X = x + dx, Y = y + dy; if (X >= 0 && Y >= 0 && X < COLS && Y < ROWS) taken[Y * COLS + X] = taken[Y * COLS + X] || 2; } }
    for (let i = 0; i < on.length; i++) if (on[i]) taken[i] = 1;
    return on;
  }
  function buildZone(z, lay) {
    const L = SPEC.LOOKS[z];
    const c = document.createElement('canvas'); c.width = ZW; c.height = ROWS * T;
    const g = c.getContext('2d'); g.imageSmoothingEnabled = false;
    for (let y = 0; y < ROWS; y++) for (let x = 0; x < COLS; x++) blit(g, L.base + '_' + (1 + Math.floor(ih(x, y, 50 + z) * 4)), x * T, y * T);
    const taken = new Array(COLS * ROWS).fill(0);
    L.regions.forEach(([set, cov], k) => {
      const on = region(z, k, cov, taken);
      const inR = (x, y) => x >= 0 && y >= 0 && x < COLS && y < ROWS ? on[y * COLS + x] : (x < 0 || x >= COLS ? 0 : on[Math.max(0, Math.min(ROWS - 1, y)) * COLS + x]);
      for (let y = 0; y < ROWS; y++) for (let x = 0; x < COLS; x++) {
        if (!on[y * COLS + x]) continue;
        let m = 0;
        if (inR(x, y - 1)) m |= N; if (inR(x + 1, y - 1)) m |= NE; if (inR(x + 1, y)) m |= E; if (inR(x + 1, y + 1)) m |= SE;
        if (inR(x, y + 1)) m |= S; if (inR(x - 1, y + 1)) m |= SW; if (inR(x - 1, y)) m |= W; if (inR(x - 1, y - 1)) m |= NW;
        blit(g, set + '_' + maskName(normalise(m)), x * T, y * T);
      }
    });
    /* props: hashed cells, clear of every scene slot, the gate and each other */
    const keep = lay.scenes.filter((s) => s.zone === z).map((s) => [s.x - z * ZW, s.y]).concat([[ZW - 20, 90], [20, 90]]);
    const placed = [];
    const want = L.propCount || (9 + Math.floor(C.hash('props' + z, 7) * 4));
    for (let k = 0; k < 600 && placed.length < want; k++) {
      const id = L.props[Math.floor(C.hash(z + 'p' + k, 13) * L.props.length)], t = A.tiles[id];
      if (!t) { state.missing[id] = 1; continue; }
      const px = 8 + Math.floor(C.hash(z + 'x' + k, 19) * (ZW - 72)), py = 4 + Math.floor(C.hash(z + 'y' + k, 23) * (ZH - 12 - t.r[3]));
      const cx = px + t.r[2] / 2, cy = py + t.r[3] / 2;
      if (keep.some(([kx, ky]) => Math.hypot(kx - cx, ky - cy) < 34)) continue;
      if (placed.some(([qx, qy]) => Math.hypot(qx - cx, qy - cy) < 30)) continue;
      blit(g, id, px, py); placed.push([cx, cy, id]);
    }
    return { canvas: c, props: placed };
  }
  function build(lay) {
    state.zones = [];
    for (let z = 0; z < lay.zones; z++) state.zones.push(buildZone(z, lay));
  }

  /* the wall at a zone's far edge: stacked dark rock with a gap where the listener waits (speak gates) or three
   * current mouths (the read beat) */
  function drawWall(g, gate, camX, t) {
    if (gate.into === null) return;   /* G6 waits in open water: the ending, not a wall */
    const x0 = Math.round(gate.zone * ZW + ZW - 16 - camX);
    if (x0 < -40 || x0 > 360) return;
    const gaps = gate.mouths ? gate.mouths.map((m) => m.y) : [gate.y];
    const rock = SPEC.LOOKS[gate.zone].base === 'rubble' ? 'basalt_vent' : 'rubble';
    for (let y = 0; y < ZH; y += 16) {
      if (gaps.some((gy) => Math.abs(y + 8 - gy) < 14)) continue;
      blit(g, rock + '_' + (1 + (y / 16) % 4), x0, y); blit(g, rock + '_' + (1 + ((y / 16) + 2) % 4), x0 + 8, y);
    }
    /* review D08/D10: a wall must read as a WALL against any floor — a soft shade band either side hides the biome seam,
     * the rock's lit west edge (light is upper-left) and its cast shadow east separate it from the ground it stands on */
    const band = (xa, dir) => { const gr = g.createLinearGradient(xa, 0, xa + dir * 22, 0); gr.addColorStop(0, 'rgba(2,6,14,0.55)'); gr.addColorStop(1, 'rgba(2,6,14,0)'); g.fillStyle = gr; g.fillRect(Math.min(xa, xa + dir * 22), 0, 22, ZH); };
    band(x0, -1); band(x0 + 24, 1);
    for (let y = 0; y < ZH; y += 16) {
      if (gaps.some((gy) => Math.abs(y + 8 - gy) < 14)) continue;
      g.fillStyle = 'rgba(210,225,235,0.28)'; g.fillRect(x0 - 1, y, 1, 16);
      g.fillStyle = 'rgba(0,0,0,0.45)'; g.fillRect(x0 + 24, y, 3, 16);
    }
    if (gate.mouths) for (const m of gate.mouths) {
      /* each mouth is an OPENING: a dark hole with a rim, not only a glow */
      g.fillStyle = '#02060c'; g.beginPath(); g.ellipse(x0 + 12, m.y, 7, 10, 0, 0, 7); g.fill();
      g.strokeStyle = m.warm ? 'rgba(255,150,80,0.8)' : 'rgba(140,190,255,0.6)'; g.lineWidth = 1; g.beginPath(); g.ellipse(x0 + 12, m.y, 7.5, 10.5, 0, 0, 7); g.stroke();
    }
    if (gate.mouths) for (const m of gate.mouths) {
      /* warm water shimmers orange and rises; cold water streams back at you */
      for (let q = 0; q < 6; q++) {
        const ph = (t * (m.warm ? 14 : 30) + q * 9) % 40;
        g.fillStyle = m.warm ? `rgba(255,${140 + q * 12},70,${0.55 - ph / 90})` : `rgba(150,200,255,${0.45 - ph / 100})`;
        if (m.warm) g.fillRect(x0 + 2 + (q % 3) * 4, Math.round(m.y + 6 - ph / 3), 1, 3); else g.fillRect(Math.round(x0 + 12 - ph), m.y - 6 + q * 2, 5, 1);
      }
    }
  }
  function drawGround(g, camX, zones) {
    for (let z = 0; z < zones; z++) {
      const Z = state.zones[z]; if (!Z) continue;
      const x = Math.round(z * ZW - camX); if (x > 320 || x + ZW < 0) continue;
      g.drawImage(Z.canvas, x, 0);
    }
  }
  /* sunlight caustics — the pack's own animated overlay, faded by LAYER opacity (it ships opaque) */
  function drawCaustics(g, camX, t, zones) {
    const frame = Math.floor(t * 6) % 6;
    for (let z = 0; z < zones; z++) {
      const L = SPEC.LOOKS[z]; if (!L.caustic) continue;
      const x0 = z * ZW - camX; if (x0 > 320 || x0 + ZW < 0) continue;
      g.save(); g.globalCompositeOperation = 'lighter'; g.globalAlpha = L.caustic * 0.22;
      for (let y = 0; y < ROWS; y++) for (let x = 0; x < COLS; x++) {
        const sx = x0 + x * T; if (sx < -16 || sx > 320) continue;
        blit(g, 'caustic_' + (1 + Math.floor(ih(x, y, 77 + z) * 4)) + '_f' + frame, sx, y * T);   /* the pack ships sets 1-4 */
      }
      g.restore();
    }
  }
  /* marine snow: slow pale motes, denser in the dark */
  function drawSnow(g, camX, t, amb) {
    g.save();
    for (let i = 0; i < 46; i++) {
      const sx = ((i * 71 - camX * (0.4 + (i % 3) * 0.2) + t * (3 + i % 4)) % 340 + 340) % 340 - 10;
      const sy = ((i * 37 + t * (2 + (i % 5))) % 190) - 5;
      g.fillStyle = `rgba(200,225,240,${0.12 + 0.25 * amb})`; g.fillRect(Math.round(sx), Math.round(sy), 1, 1);
    }
    g.restore();
  }
  /* the water: a depth tint, then darkness cut by lights. lights = [[x, y, radius, strength]] in screen px. */
  const dark = document.createElement('canvas'); dark.width = 320; dark.height = 180;
  const dg = dark.getContext('2d');
  function ambientAt(camX) {
    const cz = (camX + 160) / ZW, z0 = Math.max(0, Math.min(SPEC.LOOKS.length - 1, Math.floor(cz - 0.5))), z1 = Math.min(SPEC.LOOKS.length - 1, z0 + 1);
    const f = Math.max(0, Math.min(1, cz - 0.5 - z0));
    const a = SPEC.LOOKS[z0], b = SPEC.LOOKS[z1];
    const mix = (p, q) => p + (q - p) * f;
    return { dark: mix(a.dark, b.dark), tintA: mix(a.tintA || 0.16, b.tintA || 0.16), tint: [0, 1, 2].map((i) => Math.round(mix(a.tint[i], b.tint[i]))) };
  }
  function drawWater(g, camX, lights, extraDark) {
    const amb = ambientAt(camX);
    g.save(); g.globalAlpha = amb.tintA; g.fillStyle = `rgb(${amb.tint[0]},${amb.tint[1]},${amb.tint[2]})`; g.fillRect(0, 0, 320, 180); g.restore();
    const d = Math.min(0.94, amb.dark + (extraDark || 0));
    if (d <= 0.01) return amb;
    dg.globalCompositeOperation = 'source-over'; dg.clearRect(0, 0, 320, 180);
    dg.fillStyle = `rgba(2,6,${14 + amb.tint[2] / 8 | 0},${d})`; dg.fillRect(0, 0, 320, 180);
    dg.globalCompositeOperation = 'destination-out';
    for (const [lx, ly, r, s] of lights) {
      if (lx < -r || lx > 320 + r) continue;
      const rg = dg.createRadialGradient(lx, ly, 0, lx, ly, r);
      rg.addColorStop(0, `rgba(0,0,0,${s})`); rg.addColorStop(0.55, `rgba(0,0,0,${s * 0.6})`); rg.addColorStop(1, 'rgba(0,0,0,0)');
      dg.fillStyle = rg; dg.beginPath(); dg.arc(lx, ly, r, 0, 7); dg.fill();
    }
    g.drawImage(dark, 0, 0);
    return amb;
  }
  root.LOD_WORLD = { state, build, blit, drawGround, drawCaustics, drawSnow, drawWater, drawWall, ambientAt, img, T, ROWS, COLS, maskName, normalise };
})(window);
