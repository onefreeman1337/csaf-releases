/* glyphs.js — the eighteen bioluminescent glyphs of the reef's language.
 * Lifted EXACTLY from the graybox (Internal_Ops/proto/game.js, lattice v2): the same seeded permutations and the
 * same stroke search, so the shapes are the ones glyph_discriminability.js measured at 5.58 rendered, grayscale,
 * against a 4.0 bar (every pair differs by >= 5 strokes). Shapes and hues come from two INDEPENDENT permutations
 * of the ids, so neither order leaks a gate's sentence (review B2).
 * The release adds one thing: a soft halo behind the WHOLE glyph (never per stroke — a per-stroke glow is what
 * merged strokes into blobs at M9) and a dark backing so a glyph reads over pale sand. */
(function (root) {
  'use strict';
  const C = root.LOD_CORE, SPEC = root.LOD_SPEC;
  const SPAN = 8, HALF = SPAN / 2, GSTEP = SPAN + 4;
  const NODES = [];
  for (const y of [0, HALF, SPAN]) for (const x of [0, HALF, SPAN]) NODES.push([x, y]);
  const EDGES = [];
  for (let a = 0; a < 9; a++) for (let b = a + 1; b < 9; b++) {
    const [ax, ay] = NODES[a], [bx, by] = NODES[b];
    if (Math.max(Math.abs(ax - bx), Math.abs(ay - by)) === HALF) EDGES.push([a, b]);
  }
  const GLYPH_IDS = SPEC.GLYPH_IDS.slice();
  const GLYPH = {};
  const permute = (arr, seed) => { const R = C.rng(seed), a = arr.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(R() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  const SHAPE_ORDER = permute(GLYPH_IDS, 4127), HUE_ORDER = permute(GLYPH_IDS, 9311);
  (function buildGlyphs() {
    const R = C.rng(1809);
    const chosen = [];
    const connected = (es) => { const seen = new Set([es[0][0]]); let grew = true; while (grew) { grew = false; for (const [a, b] of es) { if (seen.has(a) !== seen.has(b)) { seen.add(a); seen.add(b); grew = true; } } } return es.every(([a, b]) => seen.has(a) && seen.has(b)); };
    for (const id of SHAPE_ORDER) {
      for (let tries = 0; tries < 5000; tries++) {
        const n = 4 + Math.floor(R() * 2);
        const es = []; while (es.length < n) { const e = EDGES[Math.floor(R() * EDGES.length)]; if (!es.includes(e)) es.push(e); }
        if (!connected(es)) continue;
        const key = es.map((e) => EDGES.indexOf(e)).sort((x, y) => x - y);
        const ok = chosen.every((k) => { const same = key.filter((e) => k.includes(e)).length; return (key.length + k.length - 2 * same) >= 5; });
        if (!ok) continue;
        chosen.push(key); GLYPH[id] = { edges: es, hue: Math.round((HUE_ORDER.indexOf(id) * 360 / GLYPH_IDS.length + 7) % 360) };
        break;
      }
      if (!GLYPH[id]) throw new Error('glyph search failed for ' + id + ' (refusing to draw a duplicate)');
    }
  })();

  /* the measured drawing — identical strokes and passes to the graybox */
  function strokes(g, id, x, y, alpha, s) {
    const gl = GLYPH[id];
    g.save(); g.globalAlpha = alpha == null ? 1 : alpha;
    for (const pass of [[2, 0.16], [1, 1]]) {
      g.strokeStyle = `hsla(${gl.hue},90%,${pass[1] === 1 ? 75 : 60}%,${pass[1]})`; g.lineWidth = pass[0] * s;
      g.beginPath();
      for (const [a, b] of gl.edges) { g.moveTo(x + NODES[a][0] * s + 0.5, y + NODES[a][1] * s + 0.5); g.lineTo(x + NODES[b][0] * s + 0.5, y + NODES[b][1] * s + 0.5); }
      g.stroke();
    }
    g.restore();
  }
  /* draw(g, id, x, y, alpha, scale, opts) — opts.halo (default true): the soft light the creature casts;
   * opts.plate: a dark backing so the glyph reads over pale ground */
  function draw(g, id, x, y, alpha, scale, opts) {
    const s = scale || 1, a = alpha == null ? 1 : alpha, o = opts || {};
    const gl = GLYPH[id]; if (!gl) return;
    const cx = x + HALF * s, cy = y + HALF * s;
    if (o.plate) { g.save(); g.globalAlpha = 0.55 * a; g.fillStyle = '#04101a'; g.fillRect(Math.round(x - 2 * s), Math.round(y - 2 * s), Math.round((SPAN + 5) * s), Math.round((SPAN + 5) * s)); g.restore(); }
    if (o.halo !== false && a > 0.05) {
      g.save(); g.globalCompositeOperation = 'lighter';
      const r = 9 * s, rg = g.createRadialGradient(cx, cy, 0, cx, cy, r);
      rg.addColorStop(0, `hsla(${gl.hue},90%,60%,${0.30 * a})`); rg.addColorStop(1, `hsla(${gl.hue},90%,50%,0)`);
      g.fillStyle = rg; g.beginPath(); g.arc(cx, cy, r, 0, 7); g.fill(); g.restore();
    }
    strokes(g, id, x, y, a, s);
  }
  function hue(id) { return GLYPH[id] ? GLYPH[id].hue : 0; }
  root.LOD_GLYPHS = { GLYPH, GLYPH_IDS, NODES, SPAN, HALF, GSTEP, draw, strokes, hue };
})(window);
