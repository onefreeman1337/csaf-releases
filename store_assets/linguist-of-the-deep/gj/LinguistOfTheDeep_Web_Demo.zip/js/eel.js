/* eel.js — the hunter eel. Lifted from Internal_Ops/proto/eel.js, the module the eel sim measured GREEN on
 * (PREREG_2026-09-18d: patrol band 20 px tall, kept off the scene rows; 1.75 contacts per careful run; guessing at
 * its gate costs 3.9x the contacts per minute). The band (ay: 20) is baked in here rather than patched by the page.
 * It patrols the dark zones and is drawn to LIGHT: speaking lights you for a few seconds. A touch is a setback,
 * never a game over — your lamp gutters and you drift back to the zone's shelter. */
(function (root) {
  'use strict';
  const CORE = root.LOD_CORE;
  const { Run, P, ZW, DT, rng, SPEC } = CORE;
  const E = { patrol: 30, hunt: 52, lit: 6, notice: 160, touch: 12, ax: 200, ay: 20, stun: 3, firstDark: 2 };

  function EelRun(lay, seed) {
    Run.call(this, lay);
    const R = rng(seed);
    this.eels = [];
    for (let z = E.firstDark; z < (lay.zones || SPEC.ZONES.length); z++) {
      const ph = R() * Math.PI * 2;
      this.eels.push({ z, ph, x: z * ZW + ZW / 2 + Math.cos(ph) * E.ax, y: 90 + Math.sin(ph) * E.ay, hunting: false });
    }
    this.litUntil = -1; this.contacts = 0; this.contactsByZone = {}; this.lostSec = 0;
  }
  EelRun.prototype = Object.create(Run.prototype);
  EelRun.prototype.step = function (input) {
    const ev = Run.prototype.step.call(this, input);
    if (ev && (ev.opened || ev.wrong)) this.litUntil = this.t + E.lit;
    const mz = this.maxZone(), dz = Math.floor(this.x / ZW);
    let hit = null;
    for (const e of this.eels) {
      if (e.z > mz) continue;
      const d = Math.hypot(this.x - e.x, this.y - e.y) || 1;
      e.hunting = this.t < this.litUntil && dz === e.z && d < E.notice;
      if (e.hunting) {
        e.x += (this.x - e.x) / d * E.hunt * DT; e.y += (this.y - e.y) / d * E.hunt * DT;
      } else {
        e.ph += (E.patrol / ((E.ax + E.ay) / 2)) * DT;
        const tx = e.z * ZW + ZW / 2 + Math.cos(e.ph) * E.ax, ty = 90 + Math.sin(e.ph) * E.ay;
        const dd = Math.hypot(tx - e.x, ty - e.y) || 1; const stepLen = Math.min(dd, E.patrol * 1.5 * DT);
        e.x += (tx - e.x) / dd * stepLen; e.y += (ty - e.y) / dd * stepLen;
      }
      e.dir = e.hunting ? Math.atan2(this.y - e.y, this.x - e.x) : Math.atan2(Math.cos(e.ph), -Math.sin(e.ph));
      if (dz === e.z && Math.hypot(this.x - e.x, this.y - e.y) < E.touch) {
        this.contacts++; this.contactsByZone[e.z] = (this.contactsByZone[e.z] || 0) + 1;
        this.lostSec += Math.abs(this.x - (e.z * ZW + 20)) / P.vmax + E.stun;
        this.x = e.z * ZW + 20; this.y = 90; this.vx = 0; this.vy = 0; this.busyUntil = this.t + E.stun; this.litUntil = -1;
        e.ph += Math.PI; hit = e.z;
      }
    }
    if (hit !== null && !(ev && ev.opened)) return Object.assign({}, ev || {}, { struck: hit });
    return ev;
  };
  root.LOD_EEL = { E, EelRun };
})(window);
