/* creatures.js — the reef's speakers and the diver, drawn at the tileset's scale (16 px cells): shell 14, angler
 * 18, ray 22, eel as 4 px segments, a shoal of 4 px fish, diver 13. Kelp and vents are the pack's OWN props
 * (kelp_stand, vent_chimney), so a scene's kelp is the same kelp that grows in the forest around it.
 * Contract (from the graybox): ent(g, kind, x, y, t, st) with st.alpha, st.open (0..1), st.glow (0..1), st.face. */
(function (root) {
  'use strict';
  const W = root.LOD_WORLD;
  const INK = '#07121c';
  function px(g, c, x, y, w, h) { g.fillStyle = c; g.fillRect(Math.round(x), Math.round(y), w || 1, h || 1); }
  function blob(g, x, y, rx, ry, fill, edge) { g.fillStyle = edge; g.beginPath(); g.ellipse(x, y, rx + 1, ry + 1, 0, 0, 7); g.fill(); g.fillStyle = fill; g.beginPath(); g.ellipse(x, y, rx, ry, 0, 0, 7); g.fill(); }

  function SHELL(g, x, y, t, st) {
    const open = st.open || 0;
    blob(g, x, y + 2, 7, 3, '#c98f98', INK);                                   // lower valve
    for (let i = -5; i <= 5; i += 2) px(g, '#a8707c', x + i, y + 2, 1, 2);      // ridges
    if (open > 0.3) { px(g, '#2a1620', x - 5, y - 1, 10, 3); px(g, '#fff6d8', x - 1, y, 2, 2); px(g, '#ffffff', x - 1, y, 1, 1); } // the pearl
    g.save(); g.translate(x - 7, y + 1); g.rotate(-open * 0.85);
    blob(g, 7, 0, 7, 3, '#ecc0c6', INK); for (let i = 2; i <= 12; i += 2) px(g, '#d49aa3', i, -2, 1, 2);
    g.restore();
  }
  /* review D19: the shoal read as speed lines (3x1 dashes). Now six fish with a body, a forked tail and an eye,
   * schooling in one direction so it reads as ONE creature */
  function SHOAL(g, x, y, t) {
    const dir = Math.cos(t * 0.6) >= 0 ? 1 : -1;
    for (let i = 0; i < 6; i++) {
      const a = t * 1.6 + i * 1.05, fx = Math.round(x + ((i % 3) - 1) * 6 + Math.cos(a) * 2), fy = Math.round(y + (i < 3 ? -3 : 3) + Math.sin(a * 1.3) * 1.5);
      const hx = dir > 0 ? fx + 2 : fx - 2, tx = dir > 0 ? fx - 3 : fx + 3;
      px(g, INK, fx - 3, fy - 2, 7, 5);
      px(g, i % 2 ? '#d6ecf8' : '#b2d4ea', fx - 2, fy - 1, 5, 3);             // body
      px(g, '#8fb6d2', fx - 2, fy + 1, 5, 1);                                   // belly shade
      px(g, '#7aa2c0', tx, fy - 2, 1, 1); px(g, '#7aa2c0', tx, fy + 2, 1, 1); // forked tail
      px(g, '#0b1622', hx, fy - 1, 1, 1);                                       // eye
    }
  }
  function RAY(g, x, y, t) {
    const f = Math.sin(t * 3) * 2;
    const wing = (c, grow) => { g.fillStyle = c; g.beginPath(); g.moveTo(x, y - 5 - grow); g.lineTo(x + 11 + grow, y + f); g.lineTo(x, y + 5 + grow); g.lineTo(x - 11 - grow, y + f); g.closePath(); g.fill(); };
    wing(INK, 1); wing('#5f7298', 0);
    g.fillStyle = '#7f93bb'; g.beginPath(); g.moveTo(x, y - 3); g.lineTo(x + 6, y + f * 0.6); g.lineTo(x, y + 3); g.lineTo(x - 6, y + f * 0.6); g.closePath(); g.fill();
    px(g, '#c8d8f0', x - 3, y - 1); px(g, '#c8d8f0', x + 2, y - 1);            // spots
    px(g, '#1b2436', x - 1, y - 4, 3, 1);                                      // mouth edge
    g.strokeStyle = '#4b5a7c'; g.lineWidth = 1; g.beginPath(); g.moveTo(x + 0.5, y + 5); g.lineTo(x + 0.5 + Math.sin(t * 2) * 2.5, y + 13); g.stroke();
  }
  function KELP(g, x, y, t, st) {
    W.blit(g, 'kelp_stand_tall', x - 8, y - 22);
    if (st.open) { px(g, '#f2df7e', x - 4, y - 8, 2, 2); px(g, '#f2df7e', x + 2, y - 3, 2, 2); px(g, '#fff4b0', x - 1, y - 12, 1, 1); }
  }
  function ANGLER(g, x, y, t, st) {
    const glow = st.glow || 0;
    blob(g, x, y, 8, 6, '#4a4466', INK);
    px(g, '#5e5886', x - 5, y - 4, 7, 2);                                      // back highlight
    px(g, '#2c2842', x - 11, y - 3, 3, 6);                                     // tail
    px(g, '#2c2842', x - 6, y + 4, 4, 2);                                      // fin
    for (let i = 0; i < 4; i++) px(g, '#eee6f4', x + 1 + i * 2, y + 2, 1, 2);  // teeth
    px(g, '#ffd97a', x + 4, y - 2, 1, 1);                                      // eye
    g.strokeStyle = '#6b6490'; g.lineWidth = 1; g.beginPath(); g.moveTo(x + 3, y - 5); g.quadraticCurveTo(x + 7, y - 13, x + 10, y - 9); g.stroke();
    px(g, glow > 0 ? '#e4ffe0' : '#8f8aa8', x + 9, y - 10, 2, 2);             // lure (its glow is emissive: see light())
  }
  function EEL(g, x, y, t, st) {
    const s = st.scale || 1, n = 7;
    for (let i = n - 1; i >= 0; i--) {
      const sx = x - i * 4 * s, sy = y + Math.sin(t * 4 - i * 0.8) * 2 * s, r = (i === 0 ? 3 : 2.5 - i * 0.15) * s;
      blob(g, sx, sy, r, r, i === 0 ? '#5f8052' : (i % 2 ? '#48633f' : '#52704a'), INK);
    }
    px(g, st.hunter ? '#ff5a4a' : '#ffd97a', x + 1, y - 1, 1, 1);
    px(g, '#e9f2d8', x + 2, y + 1, 1, 1);
  }
  function VENT(g, x, y, t, st) {
    W.blit(g, 'vent_chimney', x - 8, y - 24);
    const glow = st.glow || 0;
    px(g, `rgba(255,150,70,${0.45 + 0.4 * glow})`, x - 2, y - 24, 4, 2);
    for (let i = 0; i < 5; i++) { const py = y - 26 - ((t * 10 + i * 5) % 20); px(g, 'rgba(215,215,225,0.4)', x - 1 + Math.sin(t + i) * 2, py, 2, 2); }
  }
  /* the diver, side-on, head leading; two kick frames */
  const DIVER_ROWS = [
    ['......kkkk...', '..kk.kyyyyk..', '.kFFkoooooOkk', 'kFFFkoOOOOoss', '.kFFkoooooOkk', '..kk.kkkkkk..'],
    ['......kkkk...', '.kk..kyyyyk..', 'kFFk.oooooOkk', '.kFFkoOOOOoss', 'kFFk.oooooOkk', '.kk..kkkkkk..'],
  ];
  const DPAL = { k: INK, y: '#e8c14a', o: '#e07b39', O: '#f5a462', F: '#2b9aa3', s: '#9fe6ff' };
  function DIVER(g, x, y, t, st) {
    const rows = DIVER_ROWS[Math.floor(t * 4) % 2 * (st.moving ? 1 : 0)], face = st.face || 1;
    for (let r = 0; r < rows.length; r++) for (let c = 0; c < rows[r].length; c++) {
      const ch = rows[r][c]; if (ch === '.') continue;
      px(g, DPAL[ch], face > 0 ? x - 6 + c : x + 6 - c, y - 3 + r);
    }
    px(g, '#fff6c8', face > 0 ? x + 7 : x - 7, y, 1, 1);                       // the lamp
  }
  const DRAW = { SHELL, SHOAL, RAY, KELP, ANGLER, EEL, VENT, DIVER };
  function ent(g, kind, x, y, t, st) {
    st = st || {}; const f = DRAW[kind]; if (!f) return false;
    g.save(); g.globalAlpha = st.alpha == null ? 1 : st.alpha; f(g, Math.round(x), Math.round(y), t, st); g.restore(); return true;
  }
  /* a pencilled guess: a PICTURE, never a word (a meaning shown as a word is a meaning given away) */
  function idea(g, tok, x, y) {
    if (!tok) { px(g, '#3b4a55', x - 1, y - 3, 3, 1); px(g, '#3b4a55', x + 1, y - 2, 1, 2); px(g, '#3b4a55', x, y, 1, 1); px(g, '#3b4a55', x, y + 2, 1, 1); return; }
    if (tok[0] !== '~') {
      g.save(); g.translate(x, y); g.scale(0.7, 0.7);
      if (tok === 'KELP') { g.translate(0, 8); }
      if (tok === 'VENT') { g.translate(0, 12); }
      ent(g, tok, 0, 0, 0, {}); g.restore(); return;
    }
    const c = '#ffd97a'; g.fillStyle = c; g.strokeStyle = c; g.lineWidth = 1;
    /* review D17: verbs get their own pictograms, never a creature (an open SHELL for OPENS and a faint SHOAL for HIDES
     * were twins of the SHELL and SHOAL notes) */
    if (tok === '~open') { g.beginPath(); g.moveTo(x - 4.5, y + 2.5); g.lineTo(x - 0.5, y - 3.5); g.moveTo(x + 4.5, y + 2.5); g.lineTo(x + 0.5, y - 3.5); g.stroke(); px(g, '#fff', x - 1, y + 1, 2, 2); }
    else if (tok === '~eat') { for (let q = 0; q < 3; q++) px(g, c, x - 3 + q * 3, y - 1 - q); px(g, '#fff', x - 4, y + 2, 8, 1); }
    else if (tok === '~hide') { px(g, '#3b4a55', x - 1, y - 4, 5, 8); px(g, c, x - 4, y - 1, 3, 2); }
    else if (tok === '~rise') { g.beginPath(); g.moveTo(x + 0.5, y + 4); g.lineTo(x + 0.5, y - 4); g.moveTo(x - 2.5, y - 1); g.lineTo(x + 0.5, y - 4); g.lineTo(x + 3.5, y - 1); g.stroke(); }
    else if (tok === '~sink') { g.beginPath(); g.moveTo(x + 0.5, y - 4); g.lineTo(x + 0.5, y + 4); g.moveTo(x - 2.5, y + 1); g.lineTo(x + 0.5, y + 4); g.lineTo(x + 3.5, y + 1); g.stroke(); }
    else if (tok === '~follow') { g.setLineDash([1, 2]); g.beginPath(); g.moveTo(x - 5, y + 3); g.quadraticCurveTo(x, y - 5, x + 5, y + 3); g.stroke(); g.setLineDash([]); }
    else if (tok === '~warm') { for (let q = 0; q < 3; q++) { px(g, 'rgba(255,140,60,0.95)', x - 3 + q * 3, y - 2 + (q % 2), 1, 4); } }
    else if (tok === '~light') { px(g, '#e4ffe0', x - 1, y - 1, 3, 3); for (const [dx, dy] of [[0, -4], [0, 4], [-4, 0], [4, 0]]) px(g, '#bfffcc', x + dx, y + dy); }
    else if (tok === '~dark') { g.fillStyle = '#01050a'; g.beginPath(); g.arc(x, y, 4, 0, 7); g.fill(); g.strokeStyle = '#3b4a55'; g.beginPath(); g.arc(x, y, 4.5, 0, 7); g.stroke(); }
    else if (tok === '~far') { px(g, c, x - 4, y + 2, 2, 2); px(g, c, x, y, 1, 1); px(g, c, x + 3, y - 2, 1, 1); }
  }
  root.LOD_CREATURES = { ent, idea, DRAW };
})(window);
