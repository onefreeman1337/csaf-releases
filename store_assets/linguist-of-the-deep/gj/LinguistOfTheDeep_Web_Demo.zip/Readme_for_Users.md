# Linguist of the Deep

Swim an alien reef, overhear its creatures talking in light, and work out enough of their language to ask
them for help. Nothing ever unlocks except what you understand.

This is the **free demo**: the Shallows, the Kelp Forest and the Ridge, ending at the mouth of the Trench.

## How to play

- **Swim**: arrow keys or WASD.
- **Watch**: the reef's creatures talk to each other in glowing glyphs, then something happens. Swim close
  while one speaks and the scene goes into your logbook.
- **Logbook**: TAB. Every scene you have seen, drawn as it happened, with its sentence. Pick a glyph with
  LEFT/RIGHT and pencil a guess under it with UP/DOWN. The selected glyph lights up every scene it occurs in.
- **Speak**: when a creature blocks the way, swim up to it and press SPACE to raise your lamp.
  Q/E pick a glyph, F adds it, R removes the last, SPACE flashes the sentence. Three words; their order does
  not matter.
- **Beware**: speaking lights you up, and in the dark water the eels hunt light. A bite is a setback, never
  a game over.
- ESC pauses. M turns sound on and off. The game saves as you go.

Nothing in the game ever tells you what a word means. You work it out from what you watched.

## Requirements

Runs in any modern browser. No install, no account. If the page ever shows an error line, reload the page.

A keyboard is required.

## Credits

A game by Core Systems Asset Factory (CSAF).

- The seabed is built from **Verdant 26 · Deep Ocean**, a CSAF tileset.
- Lettering drawn by CSAF. Music and sound synthesised by CSAF from note data; no samples.
- **Made with AI:** the code, art and words of this game were written with generative AI assistance.
  The music and sound are procedural synthesis, not generative audio.

© 2026 Core Systems Asset Factory. See LICENSE.txt.
