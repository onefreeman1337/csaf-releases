/**
 * sim.js - COPPICE's wood, its trade and its wildlife. Pure and deterministic (every "random" choice is a hash of
 * the day and a cell), and the ONLY place a number is computed: the renderer reads what this file exports, so a
 * figure on screen cannot disagree with the figure the wood runs on.
 *
 * CUT IT DOWN AND IT GROWS BACK. A neglected hazel wood: most stools have not been cut in twenty years and are
 * choking on their own poles, brambles hold the gaps, and a few old oaks stand over it all. The keeper marks
 * stools; in the cutting season (autumn and winter) the crew cuts them, and each stool grows again from the stump.
 *
 * THREE SYSTEMS THAT CHANGE EACH OTHER:
 *   THE WOOD     a 14 x 8 wood of hazel stools, oak standards and bramble gaps. A stool's AGE (years of regrowth)
 *                decides what a cut gives: beanpoles, hurdle rods, or cordwood. A stool left past 16 years is
 *                OVERSTOOD: it loses vigour, and an old weak one can collapse into bramble. Oaks shade the stools
 *                beside them. Deer browse fresh regrowth unless it is hedged, fenced or the herd is kept down.
 *   THE TRADE    what the crew cuts goes to the yard. Each market takes only so much a day, and each wants more in
 *                its own season, so a wood cut all at one age floods one market while the others wait. A hurdle
 *                maker weaves rods into hurdles; a charcoal clamp burns cordwood into charcoal.
 *   THE WILDLIFE every spring the Trust surveys the wood. Bluebells need fresh light, fritillaries fresh light the
 *                deer left alone, nightingales a block of thicket, dormice connected hazel old enough to bear nuts,
 *                woodpeckers grown oaks. Each species found pays a grant; ALL FIVE in one survey is the goal. No
 *                single age can hold them: only a wood cut in rotation, a patchwork of every age, can.
 *
 * Units: t is in DAYS. game.js turns real seconds into days (DAY_SEC seconds a day at normal speed).
 */
'use strict';

var SIM = (function () {
  /* ------------------------------------------------------------ calendar */
  var DAY_SEC = 2.5;                           // real seconds per day at 1x
  var SEASONS = ['SPRING', 'SUMMER', 'AUTUMN', 'WINTER'];
  var SEASON_DAYS = 8;
  var YEAR_DAYS = SEASON_DAYS * 4;             // 80 real seconds a year at 1x
  var STEP = 0.05;                             // the sim's own granularity in days
  var GROW_SEASON = [1.6, 1.6, 0.6, 0.2];      // regrowth by season; the mean is 1.0 year a year
  var SURVEY_DAY = 3;                          // the survey walks the wood on this day of spring

  /* ----------------------------------------------------------------- wood */
  var COLS = 14, ROWS = 8, N = COLS * ROWS;
  var OVERSTOOD = 16;                          // years: past this a stool declines
  var MATURE_OAK = 20;                         // years: an oak this old shades, and counts for the woodpecker
  var HEDGE_COST = 6, LAYER_COST = 6, OAK_COST = 20;
  var HEDGE_YEARS = 3;

  /* the products, what they fetch, and how much each market takes in a day, by season (SPRING SUMMER AUTUMN WINTER) */
  var PRODUCTS = [
    { id: 'beanpoles', name: 'BEANPOLES', unit: 'bundle', price: 1.0, depth: 3, sDepth: [2.6, 0.8, 0.3, 0.4], sPrice: [1.3, 1, 0.8, 0.9], note: 'thin rods, 2 to 4 years: the gardens want them in spring' },
    { id: 'rods',      name: 'HURDLE RODS', unit: 'bundle', price: 1.6, depth: 3, sDepth: [1, 1, 1, 1], sPrice: [1, 1, 1, 1], note: 'straight rods, 5 to 9 years: steady trade, or weave them into hurdles' },
    { id: 'cordwood',  name: 'CORDWOOD', unit: 'cord', price: 1.8, depth: 3, sDepth: [0.6, 0.3, 1.6, 2.0], sPrice: [0.9, 0.7, 1.1, 1.3], note: 'poles of 10 years and more: firewood for the winter, or the charcoal clamp' },
    { id: 'hurdles',   name: 'HURDLES', unit: 'hurdle', price: 10, depth: 1, sDepth: [1.3, 0.5, 1.0, 1.6], sPrice: [1.1, 0.9, 1, 1.2], note: 'woven from five rods: shepherds pen their lambs with them' },
    { id: 'charcoal',  name: 'CHARCOAL', unit: 'sack', price: 8, depth: 2, sDepth: [1, 1.2, 1, 1], sPrice: [1, 1.1, 1, 1], note: 'burned from cordwood: the forge takes it all year' },
  ];
  var P = { beanpoles: 0, rods: 1, cordwood: 2, hurdles: 3, charcoal: 4 };

  var UPGRADES = {
    woodsman: { name: 'Another woodsman',        base: 30,  mult: 1.9,  max: 5 },
    billhook: { name: 'Better billhooks',        base: 60,  mult: 2.5,  max: 2 },
    carter:   { name: 'A carter\'s round',        base: 70,  mult: 2.2,  max: 3, rot: 0.10 },
    hurdler:  { name: 'A hurdle maker',           base: 110, mult: 1,    max: 1, rot: 0.15 },
    clamp:    { name: 'A charcoal clamp',         base: 120, mult: 1,    max: 1, rot: 0.20 },
    oaks:     { name: 'An oak nursery',           base: 90,  mult: 1,    max: 1, rot: 0.30 },
    fence:    { name: 'A deer fence',             base: 240, mult: 1,    max: 1, rot: 0.40 },
    keeper:   { name: 'A deer keeper',            base: 180, mult: 2.0,  max: 2, rot: 0.35 },
    woodward: { name: 'A woodward',               base: 320, mult: 1,    max: 1, rot: 0.50 },
    kiln:     { name: 'An iron ring kiln',        base: 380, mult: 1,    max: 1, rot: 0.60, needs: 'clamp' },
    walkers:  { name: 'Open the wood to walkers', base: 260, mult: 1,    max: 1, rot: 0.70 },
  };
  var SPECIES = [
    { id: 'bluebell',   name: 'BLUEBELLS',   need: 10, note: 'a carpet needs light: 10 stools under 3 years old (fresh cuts or layered rods)' },
    { id: 'fritillary', name: 'FRITILLARY',  need: 5,  note: 'a butterfly of fresh clearings: 5 stools under 2 years, beside another, that the deer left alone this year' },
    { id: 'nightingale',name: 'NIGHTINGALE', need: 6,  note: 'sings from dense thicket: 6 stools of 3 to 7 years, each with 2 neighbours of that age' },
    { id: 'dormouse',   name: 'DORMOUSE',    need: 8,  note: 'eats hazelnuts and never touches the ground: 8 healthy stools (vigour 60%+) of 8 to 16 years, each beside another stool of 8+ or an oak of 20+' },
    { id: 'woodpecker', name: 'WOODPECKER',  need: 4,  note: 'drums on old oak: 4 oaks of 20 years or more' },
  ];
  var GRANT = 10;                              // funds per species the survey finds
  var WALKER_PAY = 0.6;                        // funds a day per species the last survey found (review D14: 0.3 paid back in 6 years)
  /* the woodward's rotation, in years. Review D5 MEASURED woodward-only runs: R=7 never won in 25 years (no stool
   * reaches the dormouse's 8), R=10 year 21, R=12 year 17, R=14 year 13. probe_rotation.js (the IDLE policy, which hires
   * the woodward at 50% in rotation, 8 woods) MEASURED medians R=10 14, R=12 14, R=14 19, R=16 22. Both say 7 is a
   * trap, so it is gone; 12 is the default, the one rotation both measurements rank well */
  var ROTATIONS = [10, 12, 14, 16];

  /* ------------------------------------------------------------- helpers */
  function hash(n) { n = n | 0; n = (n ^ 61) ^ (n >>> 16); n = n + (n << 3); n = n ^ (n >>> 4); n = Math.imul(n, 0x27d4eb2d); n = n ^ (n >>> 15); return (n >>> 0) / 4294967296; }
  /* one epsilon for every calendar reading, so a step that ends a hair before midnight changes the day and the season
   * together */
  function tt(a) { return a.t + 1e-7; }
  function day(a) { return Math.floor(tt(a)); }
  function season(a) { return Math.floor((tt(a) % YEAR_DAYS) / SEASON_DAYS); }
  function year(a) { return Math.floor(tt(a) / YEAR_DAYS) + 1; }
  function dayOfSeason(a) { return Math.floor(tt(a) % SEASON_DAYS); }
  function cx(i) { return i % COLS; }
  function cy(i) { return Math.floor(i / COLS); }
  function neighbours(i) {
    var x = cx(i), y = cy(i), out = [];
    if (x > 0) out.push(i - 1); if (x < COLS - 1) out.push(i + 1);
    if (y > 0) out.push(i - COLS); if (y < ROWS - 1) out.push(i + COLS);
    return out;
  }
  function cuttingSeason(a) { var s = season(a); return s === 2 || s === 3; }

  /* the wood's lie: a smooth field decides where bramble took the gaps */
  function field(x, y, seed) {
    function lat(ix, iy) { return hash(ix * 374761 + iy * 668265 + seed); }
    var fx = x / 3.2, fy = y / 3.2, ix = Math.floor(fx), iy = Math.floor(fy), tx = fx - ix, ty = fy - iy;
    tx = tx * tx * (3 - 2 * tx); ty = ty * ty * (3 - 2 * ty);
    var a = lat(ix, iy), b = lat(ix + 1, iy), c = lat(ix, iy + 1), d = lat(ix + 1, iy + 1);
    return (a + (b - a) * tx) * (1 - ty) + (c + (d - c) * tx) * ty;
  }
  function hazel(age, vig) { return { k: 'hazel', age: age, vig: vig, hedge: 0, cutAt: -99, browsed: 0, mark: 0, work: 0 }; }
  /* every wood is dealt from a seed; the game deals 1709 unless the player asks for another wood */
  function newWood(seed) {
    var S = (seed === undefined ? 1709 : seed | 0);
    var a = { v: 1, seed: S, t: 2 * SEASON_DAYS + 0.2, funds: 30, brash: 6, deer: 5, cells: [], levels: {}, stock: [0, 0, 0, 0, 0], demand: [0, 0, 0, 0, 0],
      queue: [], burn: null, toggles: { hurdles: true, charcoal: true }, rotation: 12, rot: 0, bestRot: 0, announced: 0,
      events: [], seq: 0, won: false, endingSeen: false, lastSurvey: null, surveys: 0, everSeen: [0, 0, 0, 0, 0],
      stats: { cut: 0, earned: 0, grants: 0, browsed: 0, collapsed: 0, layered: 0, hedged: 0, oaksPlanted: 0, oaksFelled: 0, sold: [0, 0, 0, 0, 0], made: [0, 0, 0, 0, 0], tooYoung: 0 } };
    for (var k in UPGRADES) a.levels[k] = 0;
    for (var i = 0; i < N; i++) {
      var v = field(cx(i), cy(i), S) * 0.8 + hash(i * 31 + 11 + S) * 0.2;
      if (v < 0.27) a.cells.push({ k: 'gap', bramble: 0.6 + 0.4 * hash(i * 7 + S) });
      else a.cells.push(hazel(18 + 12 * hash(i * 13 + 3 + S), 0.38 + 0.34 * hash(i * 17 + 5 + S)));
    }
    /* seven old oak standards, never side by side */
    var placed = 0;
    for (var tries = 0; placed < 7 && tries < 400; tries++) {
      var j = Math.floor(hash(tries * 977 + 41 + S) * N);
      if (a.cells[j].k !== 'hazel') continue;
      var nb = neighbours(j), ok = true;
      for (var q = 0; q < nb.length; q++) if (a.cells[nb[q]].k === 'oak') ok = false;
      if (!ok) continue;
      a.cells[j] = { k: 'oak', age: 34 + Math.floor(36 * hash(j * 3 + 1)), mark: 0, work: 0 };
      placed++;
    }
    /* the last woodman's final coupe: four stools side by side, cut four years ago */
    var best = -1, bestScore = -1;
    for (var s = 0; s < N; s++) {
      if (cx(s) >= COLS - 1 || cy(s) >= ROWS - 1) continue;
      var four = [s, s + 1, s + COLS, s + COLS + 1], sc = 0;
      for (var f = 0; f < 4; f++) if (a.cells[four[f]].k === 'hazel') sc++;
      if (sc === 4) { var h = hash(s * 5 + 3 + S); if (h > bestScore) { bestScore = h; best = s; } }
    }
    if (best >= 0) [best, best + 1, best + COLS, best + COLS + 1].forEach(function (c, n) { a.cells[c] = hazel(4 + 0.15 * n, 0.95); a.cells[c].cutAt = a.t - 4 * YEAR_DAYS; });
    refresh(a);
    return a;
  }

  /* ------------------------------------------------------------- queries */
  function isHazel(c) { return !!c && c.k === 'hazel'; }
  function matureOak(c) { return !!c && c.k === 'oak' && c.age >= MATURE_OAK; }
  function shaded(a, i) { var nb = neighbours(i); for (var k = 0; k < nb.length; k++) if (matureOak(a.cells[nb[k]])) return true; return false; }
  function hedged(a, c) { return !!c && c.hedge > a.t; }
  /* IN ROTATION: a hazel stool of 16 years or under, so a stool counts the moment it is cut or layered (review D4: it
   * once also needed vigour 55%+, which the game never said, so a restoration cut barely moved the number) */
  function inRotation(c) { return isHazel(c) && c.age <= OVERSTOOD; }
  function coppiceGround(a) { var n = 0; for (var i = 0; i < N; i++) if (a.cells[i].k !== 'oak') n++; return n; }
  function rotationOf(a) { var n = 0; for (var i = 0; i < N; i++) if (inRotation(a.cells[i])) n++; return n / Math.max(1, coppiceGround(a)); }
  function count(a, fn) { var n = 0; for (var i = 0; i < N; i++) if (fn(a.cells[i], i)) n++; return n; }
  function crew(a) { return 1 + a.levels.woodsman; }
  function workRate(a) { return crew(a) * Math.pow(1.35, a.levels.billhook); }   // work-days of cutting per day
  function workNeeded(c) { return c.k === 'oak' ? 6 : 1 + c.age / 8; }
  function growRate(a, i) { var c = a.cells[i]; if (!isHazel(c)) return 0; return c.vig * (shaded(a, i) ? 0.75 : 1); }
  /* what a stool of this age gives when it is cut */
  function yieldOf(c) {
    if (!isHazel(c)) return null;
    var a = c.age, vf = 0.5 + 0.5 * Math.min(1, c.vig);
    if (a < 2) return { p: -1, q: 0, brash: 2, label: 'nothing but brash (cut too young)' };
    if (a < 5) return { p: P.beanpoles, q: Math.max(1, Math.round(a * 2 * vf)), brash: 2 + Math.floor(a / 3) };
    if (a < 10) return { p: P.rods, q: Math.max(1, Math.round(a * 2 * vf)), brash: 2 + Math.floor(a / 3) };
    if (a <= OVERSTOOD) return { p: P.cordwood, q: Math.max(1, Math.round(a * 1.5 * vf)), brash: 2 + Math.floor(a / 3) };
    return { p: P.cordwood, q: Math.max(1, Math.round(Math.min(a, 24) * 1.0 * vf)), brash: 4 + Math.floor(a / 4) };
  }
  function productOfAge(age) { return age < 2 ? -1 : age < 5 ? P.beanpoles : age < 10 ? P.rods : P.cordwood; }
  /* review D13: at 40 + 2.5 x age, felling three oaks in year 1 paid 376 funds against 148 for three stools, a free
   * dominant opening; timber is now worth about what a good stool gives, and it still leaves the woodpecker short */
  function oakTimber(c) { return Math.round(20 + c.age); }
  function priceOf(a, p) { var d = PRODUCTS[p]; return d.price * d.sPrice[season(a)]; }
  function depthOf(a, p) { var d = PRODUCTS[p]; return d.depth * d.sDepth[season(a)] * (1 + 0.6 * a.levels.carter); }
  function burnCap(a) { return a.levels.kiln ? 24 : 12; }
  function burnDays(a) { return a.levels.kiln ? 2 : 4; }
  function burnYield(a) { return a.levels.kiln ? 0.31 : 0.25; }    // sacks of charcoal per cord
  function hurdlesPerDay(a) { return a.levels.hurdler ? 1 : 0; }
  function surplusCords(a) { return Math.max(0, Math.floor(a.stock[P.cordwood] - 2 * depthOf(a, P.cordwood))); }
  function refresh(a) { a.rot = rotationOf(a); if (a.rot > a.bestRot) a.bestRot = a.rot; }

  /* ------------------------------------------------------------- the survey */
  function survey(a) {
    var fresh3 = 0, frit = 0, thicket = 0, dorm = 0, oaks = 0, y = year(a);
    for (var i = 0; i < N; i++) {
      var c = a.cells[i];
      if (c.k === 'oak') { if (c.age >= MATURE_OAK) oaks++; continue; }
      if (!isHazel(c)) continue;
      var nb = neighbours(i);
      /* a stool under 3 years can only be one the crew cut or a rod the keeper layered: the light is fresh */
      if (c.age < 3) fresh3++;
      if (c.age < 2 && c.browsed !== y) {
        var fn = 0; for (var q = 0; q < nb.length; q++) { var d = a.cells[nb[q]]; if (isHazel(d) && d.age < 2) fn++; }
        if (fn >= 1) frit++;
      }
      if (c.age >= 3 && c.age < 8) {
        var tn = 0; for (var r = 0; r < nb.length; r++) { var e = a.cells[nb[r]]; if (isHazel(e) && e.age >= 3 && e.age < 8) tn++; }
        if (tn >= 2) thicket++;
      }
      if (c.age >= 8 && c.age <= OVERSTOOD && c.vig >= 0.6) {
        var dn = 0; for (var s = 0; s < nb.length; s++) { var f = a.cells[nb[s]]; if ((isHazel(f) && f.age >= 8) || matureOak(f)) dn++; }
        if (dn >= 1) dorm++;
      }
    }
    var counts = [fresh3, frit, thicket, dorm, oaks];
    return { counts: counts, found: counts.map(function (n, k) { return n >= SPECIES[k].need; }) };
  }

  /* review D6: the long wait for the dormouse, forecast. The years until the nearest healthy stool now under `target`
   * reaches it at its own growth rate (vigour x light, a year a year at full vigour), or -1 if none is growing toward it */
  function yearsToAge(a, target) {
    var best = -1;
    for (var i = 0; i < N; i++) {
      var c = a.cells[i];
      if (!isHazel(c) || c.age >= target || c.vig < 0.6) continue;
      var r = growRate(a, i); if (r <= 0) continue;
      var y = (target - c.age) / r;
      if (best < 0 || y < best) best = y;
    }
    return best;
  }

  /* ------------------------------------------------------------- prices */
  function cost(a, k) { var u = UPGRADES[k]; return Math.round(u.base * Math.pow(u.mult, a.levels[k])); }
  function whyNot(a, k) {
    var u = UPGRADES[k];
    if (!u) return 'there is no such thing';
    if (a.levels[k] >= u.max) return 'already done';
    if (u.rot && a.bestRot < u.rot - 1e-9) return 'the wood must reach ' + Math.round(u.rot * 100) + '% in rotation';
    if (u.needs && !a.levels[u.needs]) return 'it needs ' + UPGRADES[u.needs].name.toLowerCase() + ' first';
    if (a.funds < cost(a, k)) return 'not enough funds';
    return '';
  }
  function whyNotMark(a, i) {
    var c = a.cells[i];
    if (!c) return 'there is no such cell';
    if (c.k === 'gap') return 'bramble holds that gap: LAYER a rod from a hazel beside it';
    if (c.k === 'oak' && c.age < 6) return 'that oak is a sapling';
    return '';
  }
  function whyNotHedge(a, i) {
    var c = a.cells[i];
    if (!c) return 'there is no such cell';
    if (!isHazel(c)) return 'a dead hedge guards a hazel stool';
    if (hedged(a, c)) return 'a dead hedge already rings that stool';
    if (a.brash < HEDGE_COST) return 'not enough brash (' + HEDGE_COST + '): every cut leaves some';
    return '';
  }
  function whyNotLayer(a, i) {
    var c = a.cells[i];
    if (!c) return 'there is no such cell';
    if (c.k !== 'gap') return 'only a bramble gap can be layered';
    var nb = neighbours(i), ok = false;
    for (var q = 0; q < nb.length; q++) { var d = a.cells[nb[q]]; if (isHazel(d) && d.age >= 3) ok = true; }
    if (!ok) return 'no hazel beside it has a rod long enough (3 years) to bend down';
    if (a.funds < LAYER_COST) return 'not enough funds';
    return '';
  }
  function whyNotOak(a, i) {
    var c = a.cells[i];
    if (!c) return 'there is no such cell';
    if (!a.levels.oaks) return 'the oak nursery is on the UPGRADES tab';
    if (c.k === 'oak') return 'an oak grows there already';
    if (!(c.k === 'gap' || (isHazel(c) && c.age < 2))) return 'an oak can go in a gap or on a stool under 2 years';
    if (a.funds < OAK_COST) return 'not enough funds';
    return '';
  }

  /* -------------------------------------------------------------- events */
  function ev(a, kind, msg, extra) {
    a.seq++;
    var e = { seq: a.seq, t: a.t, kind: kind, msg: msg };
    if (extra) for (var k in extra) e[k] = extra[k];
    a.events.push(e);
    if (a.events.length > 40) a.events.shift();
    return e;
  }

  /* ------------------------------------------------------------- actions */
  function buy(a, k) {
    var w = whyNot(a, k); if (w) return w;
    a.funds -= cost(a, k); a.levels[k]++;
    return '';
  }
  /* mark or unmark a stool (or an oak) for the crew; marks are cut in the order they were made */
  function mark(a, i) {
    var w = whyNotMark(a, i); if (w) return w;
    var c = a.cells[i];
    if (c.mark) { c.mark = 0; c.work = 0; var at = a.queue.indexOf(i); if (at >= 0) a.queue.splice(at, 1); return ''; }
    c.mark = 1; c.work = 0; a.queue.push(i);
    return '';
  }
  function hedge(a, i) {
    var w = whyNotHedge(a, i); if (w) return w;
    a.brash -= HEDGE_COST; a.cells[i].hedge = a.t + HEDGE_YEARS * YEAR_DAYS; a.stats.hedged++;
    return '';
  }
  function layer(a, i) {
    var w = whyNotLayer(a, i); if (w) return w;
    a.funds -= LAYER_COST; a.cells[i] = hazel(0, 0.7); a.cells[i].cutAt = a.t; a.stats.layered++;
    refresh(a);
    return '';
  }
  function plantOak(a, i) {
    var w = whyNotOak(a, i); if (w) return w;
    var at = a.queue.indexOf(i); if (at >= 0) a.queue.splice(at, 1);
    a.funds -= OAK_COST; a.cells[i] = { k: 'oak', age: 0, mark: 0, work: 0 }; a.stats.oaksPlanted++;
    refresh(a);
    return '';
  }
  function setRotation(a, r) { if (ROTATIONS.indexOf(r) < 0) return 'no such rotation'; a.rotation = r; return ''; }
  function toggle(a, what) { if (!(what in a.toggles)) return 'no such workshop'; a.toggles[what] = !a.toggles[what]; return ''; }

  /* the crew finishes a cut: what the stool gives goes to the yard, and it grows again from the stump */
  function finishCut(a, i) {
    var c = a.cells[i];
    if (c.k === 'oak') {
      var tim = oakTimber(c);
      a.funds += tim; a.stats.earned += tim; a.stats.oaksFelled++;
      a.cells[i] = { k: 'gap', bramble: 0.1 };
      ev(a, 'fell', 'An oak of ' + Math.floor(c.age) + ' years is felled: its timber sold for ' + tim + ' funds. The gap it leaves is full of light.', { funds: tim });
      return;
    }
    var y = yieldOf(c);
    if (y.p >= 0) { a.stock[y.p] += y.q; a.stats.made[y.p] += y.q; }
    else { c.vig = Math.max(0.25, c.vig - 0.1); a.stats.tooYoung++; }
    if (c.age > OVERSTOOD) c.vig = Math.max(0.25, c.vig - 0.05);
    a.brash = Math.min(60, a.brash + y.brash);
    c.age = 0; c.cutAt = a.t; c.mark = 0; c.work = 0; c.browsed = 0;
    a.stats.cut++;
    a.lastCut = { i: i, p: y.p, q: y.q, t: a.t };
  }
  /* one day of the crew's work, spread down the queue */
  function crewWork(a, dt) {
    if (!cuttingSeason(a)) return;
    var w = workRate(a) * dt;
    while (w > 1e-9 && a.queue.length) {
      var i = a.queue[0], c = a.cells[i];
      if (!c.mark) { a.queue.shift(); continue; }
      var need = workNeeded(c) - c.work;
      if (w >= need) { w -= need; a.queue.shift(); finishCut(a, i); }
      else { c.work += w; w = 0; }
    }
  }

  /* the woodward: each autumn, marks ONE COUPE, a 1/R share of the hazel (R = the rotation), as contiguous blocks
   * grown outward from the oldest stool. Cutting a share a year is what spreads the wood across every age; cutting
   * everything that is ripe at once keeps it all one age. Stools younger than three quarters of the rotation are left. */
  function coupeSize(a) {
    var hz = count(a, isHazel), crewCap = Math.max(2, Math.floor(workRate(a) * 2 * SEASON_DAYS / (1 + a.rotation / 8)));
    return Math.min(crewCap, Math.ceil(hz / a.rotation));
  }
  function woodwardPlan(a) {
    var cap = coupeSize(a), minAge = a.rotation * 0.75, picked = [], seen = {};
    function eligible(i) { var c = a.cells[i]; return isHazel(c) && !c.mark && !seen[i] && c.age >= minAge; }
    function oldest(list) { var b = -1; for (var k = 0; k < list.length; k++) if (b < 0 || a.cells[list[k]].age > a.cells[list[b]].age + 1e-9) b = k; return b; }
    while (picked.length < cap) {
      var pool = []; for (var i = 0; i < N; i++) if (eligible(i)) pool.push(i);
      if (!pool.length) break;
      var front = [pool[oldest(pool)]];
      while (front.length && picked.length < cap) {
        var fk = oldest(front), j = front.splice(fk, 1)[0];
        if (seen[j]) continue;
        seen[j] = 1; picked.push(j);
        var nb = neighbours(j);
        for (var q = 0; q < nb.length; q++) if (eligible(nb[q])) front.push(nb[q]);
      }
    }
    return picked;
  }
  function woodward(a) {
    var picked = woodwardPlan(a);
    for (var k = 0; k < picked.length; k++) mark(a, picked[k]);
    ev(a, 'woodward', picked.length ? 'The woodward marked a coupe of ' + picked.length + (picked.length === 1 ? ' stool' : ' stools') + ' (a ' + a.rotation + '-year rotation cuts about 1 in ' + a.rotation + ' each winter).' : 'The woodward found nothing near ' + a.rotation + ' years old to mark this autumn.', { n: picked.length });
  }

  /* ----------------------------------------------------------------- time */
  function doSurvey(a) {
    var s = survey(a), n = 0, names = [];
    for (var k = 0; k < SPECIES.length; k++) if (s.found[k]) { n++; names.push(SPECIES[k].name); if (!a.everSeen[k]) a.everSeen[k] = year(a); }
    var grant = n * GRANT;
    a.funds += grant; a.stats.earned += grant; a.stats.grants += grant; a.surveys++;
    a.lastSurvey = { year: year(a), counts: s.counts, found: s.found, grant: grant };
    ev(a, 'survey', 'THE SPRING SURVEY, year ' + year(a) + ': ' + (n ? names.join(', ') + ' found (' + n + ' of 5). The Trust pays ' + grant + ' funds.' : 'no indicator species found yet.'), { n: n });
    if (!a.won && n === SPECIES.length) {
      a.won = true; a.wonAt = a.t;
      a.wonStats = { year: year(a), day: day(a), cut: a.stats.cut, earned: Math.round(a.stats.earned), rot: a.rot, crew: crew(a), counts: s.counts.slice(), collapsed: a.stats.collapsed };
      ev(a, 'win', 'All five species in one survey. The wood is in rotation again.');
    }
  }
  function seasonStart(a) {
    var s = season(a), y = year(a);
    if (s === 0) {
      /* the herd grows over the winter unless it is kept down */
      a.deer = Math.max(1, Math.min(14, a.deer + 1 - 1.8 * a.levels.keeper));
      ev(a, 'season', 'SPRING, year ' + y + '. The sap is rising: the stools grow fastest now, and the deer go for the fresh shoots. The herd is about ' + Math.round(a.deer) + '.');
    } else if (s === 1) ev(a, 'season', 'SUMMER, year ' + y + '. Full leaf. The crew waits for autumn to cut.');
    else if (s === 2) {
      ev(a, 'season', 'AUTUMN, year ' + y + '. The cutting season opens: the crew cuts every marked stool, in the order you marked them.');
      if (a.levels.woodward) woodward(a);
    } else {
      /* an old, weak stool can collapse into bramble at the turn of winter */
      var gone = 0;
      for (var i = 0; i < N; i++) {
        var c = a.cells[i];
        if (isHazel(c) && c.age > 22 && c.vig <= 0.36 && hash(i * 131 + y * 17) < 0.3) {
          var at = a.queue.indexOf(i); if (at >= 0) a.queue.splice(at, 1);
          a.cells[i] = { k: 'gap', bramble: 0.5 }; gone++;
        }
      }
      a.stats.collapsed += gone;
      ev(a, 'season', 'WINTER, year ' + y + '. The crew cuts on through the cold.' + (gone ? ' ' + gone + (gone === 1 ? ' old stool' : ' old stools') + ' collapsed under their own poles; bramble takes the gap.' : ''), { collapsed: gone });
      refresh(a);
    }
  }
  function sell(a) {
    var income = 0;
    for (var p = 0; p < PRODUCTS.length; p++) {
      var dp = depthOf(a, p);
      a.demand[p] = Math.min(dp * 2, a.demand[p] + dp);
      var n = Math.floor(Math.min(a.stock[p], a.demand[p]));
      if (n <= 0) continue;
      var got = n * priceOf(a, p);
      a.stock[p] -= n; a.demand[p] -= n; a.stats.sold[p] += n; income += got;
    }
    a.funds += income; a.stats.earned += income;
    a.lastIncome = income;
  }
  function workshops(a) {
    /* the hurdle maker weaves from the rods before the carter takes them */
    if (a.levels.hurdler && a.toggles.hurdles) {
      var h = Math.min(hurdlesPerDay(a), Math.floor(a.stock[P.rods] / 5));
      if (h > 0) { a.stock[P.rods] -= 5 * h; a.stock[P.hurdles] += h; a.stats.made[P.hurdles] += h; }
    }
    if (a.levels.clamp) {
      if (a.burn) {
        a.burn.left -= 1;
        if (a.burn.left <= 0) {
          var sacks = Math.floor(a.burn.cords * burnYield(a) + 1e-9);
          a.stock[P.charcoal] += sacks; a.stats.made[P.charcoal] += sacks;
          ev(a, 'burn', 'The ' + (a.levels.kiln ? 'kiln' : 'clamp') + ' is opened: ' + a.burn.cords + ' cords burned into ' + sacks + ' sacks of charcoal.', { sacks: sacks });
          a.burn = null;
        }
      } else if (a.toggles.charcoal && surplusCords(a) >= 8) {
        /* the clamp burns only the SURPLUS: cordwood the market cannot take in the next two days (review D15: burning
         * everything lost money in winter, when cordwood sells for more than its charcoal) */
        var cords = Math.min(burnCap(a), surplusCords(a));
        a.stock[P.cordwood] -= cords; a.burn = { cords: cords, left: burnDays(a) };
      }
    }
  }
  function browse(a) {
    var s = season(a); if (s !== 0 && s !== 1) return 0;
    var y = year(a), n = 0, base = Math.min(0.3, a.deer * 0.008) * (a.levels.fence ? 0.35 : 1);
    for (var i = 0; i < N; i++) {
      var c = a.cells[i];
      if (!isHazel(c) || c.age >= 2 || hedged(a, c)) continue;
      var nb = neighbours(i), fn = 0;
      for (var q = 0; q < nb.length; q++) { var d = a.cells[nb[q]]; if (isHazel(d) && d.age < 2) fn++; }
      var p = base * Math.max(0.25, 1 - 0.18 * fn);
      if (hash(i * 7919 + day(a) * 31 + 7) < p) { c.age = Math.max(0, c.age - 0.15); c.vig = Math.max(0.25, c.vig - 0.03); c.browsed = y; n++; }
    }
    if (n) { a.stats.browsed += n; a.pendingBrowse = (a.pendingBrowse || 0) + n; }
    return n;
  }
  function dawn(a) {
    var oldBest = a.announced === undefined ? a.bestRot : a.announced;
    refresh(a);
    workshops(a);
    sell(a);
    browse(a);
    if (a.pendingBrowse && (dayOfSeason(a) === 7 || season(a) === 2)) {
      ev(a, 'browse', 'The deer browsed fresh shoots on ' + a.pendingBrowse + (a.pendingBrowse === 1 ? ' stool' : ' stools') + ' this ' + SEASONS[season(a) === 2 ? 1 : season(a)].toLowerCase() + '. Hedge the fresh cuts, fence the wood or keep the herd down.', { n: a.pendingBrowse });
      a.pendingBrowse = 0;
    }
    if (season(a) === 0 && dayOfSeason(a) === SURVEY_DAY) doSurvey(a);
    var un = [];
    for (var k in UPGRADES) { var u = UPGRADES[k]; if (u.rot && oldBest < u.rot - 1e-9 && a.bestRot >= u.rot - 1e-9) un.push([u.rot, Math.round(u.rot * 100) + '% in rotation: ' + u.name + ' is on the UPGRADES tab now.']); }
    a.announced = a.bestRot;
    un.sort(function (x, y) { return x[0] - y[0]; });
    for (var ui = 0; ui < un.length; ui++) ev(a, 'unlock', un[ui][1]);
  }

  /* one small step (dt <= STEP days) */
  function micro(a, dt) {
    var oldDay = day(a), oldSeason = season(a), gs = GROW_SEASON[season(a)];
    for (var i = 0; i < N; i++) {
      var c = a.cells[i];
      if (c.k === 'oak') { c.age += dt / YEAR_DAYS; continue; }
      if (!isHazel(c)) continue;
      c.age += growRate(a, i) * gs * dt / YEAR_DAYS;
      /* a stool past 16 years declines; a cut one comes back strong (coppicing is what keeps hazel young) */
      if (c.age > OVERSTOOD) c.vig = Math.max(0.25, c.vig - 0.05 * dt / YEAR_DAYS);
      else if (c.age < 12 && c.vig < 1) c.vig = Math.min(1, c.vig + 0.15 * dt / YEAR_DAYS);
    }
    crewWork(a, dt);
    if (a.levels.walkers && a.lastSurvey) { var wk = WALKER_PAY * a.lastSurvey.found.filter(Boolean).length * dt; a.funds += wk; a.stats.earned += wk; }
    a.t += dt;
    if (day(a) !== oldDay) { if (season(a) !== oldSeason) seasonStart(a); dawn(a); }
  }
  /* advance by dt days, never crossing a dawn inside a step */
  function step(a, dt) {
    while (dt > 1e-12) {
      var edge = day(a) + 1 - a.t;
      var h = Math.min(dt, STEP, Math.max(1e-9, edge));
      micro(a, h);
      dt -= h;
    }
    refresh(a);
  }
  /* the days of work the queue still needs, and whether this season's crew can finish it */
  function queueWork(a) { var w = 0; for (var k = 0; k < a.queue.length; k++) { var c = a.cells[a.queue[k]]; w += workNeeded(c) - c.work; } return w; }

  return {
    DAY_SEC: DAY_SEC, SEASONS: SEASONS, SEASON_DAYS: SEASON_DAYS, YEAR_DAYS: YEAR_DAYS, COLS: COLS, ROWS: ROWS, N: N, GROW_SEASON: GROW_SEASON,
    OVERSTOOD: OVERSTOOD, MATURE_OAK: MATURE_OAK, HEDGE_COST: HEDGE_COST, LAYER_COST: LAYER_COST, OAK_COST: OAK_COST, HEDGE_YEARS: HEDGE_YEARS,
    PRODUCTS: PRODUCTS, P: P, UPGRADES: UPGRADES, SPECIES: SPECIES, GRANT: GRANT, ROTATIONS: ROTATIONS, SURVEY_DAY: SURVEY_DAY,
    hash: hash, newWood: newWood, day: day, season: season, year: year, dayOfSeason: dayOfSeason, cx: cx, cy: cy, neighbours: neighbours,
    cuttingSeason: cuttingSeason, isHazel: isHazel, matureOak: matureOak, shaded: shaded, hedged: hedged, inRotation: inRotation,
    rotationOf: rotationOf, count: count, crew: crew, workRate: workRate, workNeeded: workNeeded, growRate: growRate, yieldOf: yieldOf,
    productOfAge: productOfAge, oakTimber: oakTimber, priceOf: priceOf, depthOf: depthOf, burnCap: burnCap, burnDays: burnDays, burnYield: burnYield,
    hurdlesPerDay: hurdlesPerDay, surplusCords: surplusCords, yearsToAge: yearsToAge, WALKER_PAY: WALKER_PAY, survey: survey, cost: cost, whyNot: whyNot, whyNotMark: whyNotMark, whyNotHedge: whyNotHedge,
    whyNotLayer: whyNotLayer, whyNotOak: whyNotOak, buy: buy, mark: mark, hedge: hedge, layer: layer, plantOak: plantOak,
    setRotation: setRotation, toggle: toggle, woodward: woodward, woodwardPlan: woodwardPlan, coupeSize: coupeSize, step: step, queueWork: queueWork, refresh: refresh,
  };
})();

if (typeof module !== 'undefined') module.exports = SIM;
