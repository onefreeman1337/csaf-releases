/**
 * game.js - COPPICE: layout (two shapes), drawing, input, save/resume and the loop. Every number on screen is read
 * from SIM (sim.js); this file computes none of the wood.
 *
 * Two logical surfaces, chosen by the viewport's aspect: WIDE 960x600 and TALL 480x960.
 * The canvas element keeps the surface's aspect (CSS aspect-ratio from --ar), so a tap maps with ONE scale on
 *   both axes and the picture is never letterboxed inside its own box.
 * Save/resume, never a restart: autosave on every action, every season and every 5 s; the wood keeps growing while
 *   you are away (up to one year), crew, markets and deer included.
 * No key is ever preventDefault-ed except the arrow keys while the wood cursor is in use: the embed never traps
 *   Tab (WCAG 2.1.2).
 */
'use strict';

(function () {
  var cv = document.getElementById('cv');
  var g = cv.getContext('2d');
  var SAVE_KEY = 'coppice.wood.v1';
  var SHAPES = { wide: { W: 960, H: 600 }, tall: { W: 480, H: 960 } };
  var shape = 'wide', W = 960, H = 600;

  var C = {
    bg: '#10140c', panel: '#1a2114', panelEdge: '#4a5a36', ink: '#f1ecd8', inkDim: '#d2cbb0', inkFaint: '#a39d84',
    moss: '#9fcf6a', gold: '#e8c56a', good: '#a6e08a', alarm: '#ff8a5c', blue: '#9fb6ff', btn: '#2a3620', btnOn: '#3e5a2a', btnEdge: '#7f9a5a',
  };
  var PLATES = { litter: null, clearing: null, bramble: null }, platesReady = 0;
  ['litter', 'clearing', 'bramble'].forEach(function (k) {
    var img = new Image();
    img.onload = function () { try { PLATES[k] = g.createPattern(img, 'repeat'); platesReady++; } catch (e) { /* keep the flat colour */ } };
    img.src = 'art/plate_' + k + '.png';
  });
  var SERIF = 'Georgia, "Times New Roman", serif';
  var UI = '"Trebuchet MS", Verdana, sans-serif';

  var state = {
    screen: 'title', wood: null, tab: 'upgrades', t: 0, speed: 1, help: false, confirmNewUntil: 0, lastSaveReal: 0,
    eventsSeen: 0, cutsSeen: 0, toast: [], toastQ: [], cut: 0, pendingToast: null, tool: 'mark', cursor: -1, hoverCell: -1, splash: [], chips: [],
  };

  /* ---------------------------------------------------------------- save */
  var saveFailSaid = false;
  function save() {
    if (!state.wood) return;
    try { localStorage.setItem(SAVE_KEY, JSON.stringify({ v: 1, savedAt: Date.now(), paused: !!state.userPaused, wood: state.wood })); }
    catch (e) { if (!saveFailSaid) { saveFailSaid = true; toast('This browser is blocking saves. Progress will not persist.', 'bad'); } }
  }
  function num(x) { return typeof x === 'number' && isFinite(x); }
  function valid(a) {
    if (!a || a.v !== 1 || !Array.isArray(a.cells) || a.cells.length !== SIM.N) return false;
    if (!num(a.t) || a.t < 0 || !num(a.funds) || !num(a.brash) || !num(a.deer) || !num(a.rot) || !num(a.bestRot) || !num(a.seq)) return false;
    if (!Array.isArray(a.stock) || a.stock.length !== 5 || !Array.isArray(a.demand) || a.demand.length !== 5) return false;
    for (var s = 0; s < 5; s++) if (!num(a.stock[s]) || a.stock[s] < 0 || !num(a.demand[s])) return false;
    if (!a.levels || typeof a.levels !== 'object') return false;
    for (var k in SIM.UPGRADES) if (!num(a.levels[k]) || a.levels[k] < 0 || a.levels[k] > SIM.UPGRADES[k].max) return false;
    if (!Array.isArray(a.queue) || !Array.isArray(a.events) || !a.stats || typeof a.stats !== 'object' || !a.toggles || SIM.ROTATIONS.indexOf(a.rotation) < 0) return false;
    if (!Array.isArray(a.everSeen) || a.everSeen.length !== 5) return false;
    /* review D21: a save holding one null event passed and froze the loop (116 page errors in 2 s); every structure the
     * loop READS is now checked, and negative funds are refused */
    if (a.funds < 0 || a.brash < 0) return false;
    for (var ev = 0; ev < a.events.length; ev++) { var e = a.events[ev]; if (!e || typeof e !== 'object' || !num(e.seq) || typeof e.kind !== 'string' || typeof e.msg !== 'string') return false; }
    if (a.lastSurvey !== null && a.lastSurvey !== undefined) { var ls = a.lastSurvey; if (typeof ls !== 'object' || !Array.isArray(ls.counts) || ls.counts.length !== 5 || !Array.isArray(ls.found) || ls.found.length !== 5 || !num(ls.year)) return false; }
    if (a.burn !== null && a.burn !== undefined && (typeof a.burn !== 'object' || !num(a.burn.cords) || !num(a.burn.left))) return false;
    if (typeof a.toggles !== 'object' || typeof a.toggles.hurdles !== 'boolean' || typeof a.toggles.charcoal !== 'boolean') return false;
    if (!Array.isArray(a.stats.sold) || a.stats.sold.length !== 5 || !Array.isArray(a.stats.made) || a.stats.made.length !== 5) return false;
    var SK = ['cut', 'earned', 'grants', 'browsed', 'collapsed', 'layered', 'hedged', 'oaksPlanted', 'oaksFelled', 'tooYoung'];
    for (var q = 0; q < SK.length; q++) if (!num(a.stats[SK[q]])) return false;
    for (var qi = 0; qi < a.queue.length; qi++) if (!(a.queue[qi] >= 0 && a.queue[qi] < SIM.N)) return false;
    for (var i = 0; i < a.cells.length; i++) {
      var c = a.cells[i];
      if (!c || (c.k !== 'hazel' && c.k !== 'oak' && c.k !== 'gap')) return false;
      if (c.k === 'hazel' && (!num(c.age) || !num(c.vig) || !num(c.hedge) || !num(c.work))) return false;
      if (c.k === 'oak' && (!num(c.age) || !num(c.work))) return false;
    }
    return true;
  }
  function load() {
    try {
      var raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return null;
      var d = JSON.parse(raw);
      if (!d || !valid(d.wood)) return null;
      return d;
    } catch (e) { return null; }
  }
  function hasSave() { try { return !!localStorage.getItem(SAVE_KEY); } catch (e) { return false; } }
  /* the wood keeps going while you are away, up to one year */
  function catchUp(a, seconds) {
    var days = Math.max(0, Math.min(seconds / SIM.DAY_SEC, SIM.YEAR_DAYS));
    SIM.step(a, days);
    return days;
  }

  /* every message holds the bar for at least TOAST_MIN seconds: two events on one dawn (an autumn's woodward and its
   * browsing report) otherwise left the first one on screen for no frames at all on a phone, where the bar shows
   * one message */
  var TOAST_MIN = 2.5;
  /* toast(): the answer to something the player just did, shown AT ONCE. note(): news from the wood (an event),
   * which waits its turn behind a message younger than TOAST_MIN */
  function toast(msg, kind, queued) {
    var top = state.toast[0];
    if (top && top.base === msg && state.t - top.at < 8) { top.n++; top.msg = msg + ' x' + top.n; top.at = state.t; return; }
    for (var q = 0; q < state.toastQ.length; q++) if (state.toastQ[q].base === msg) return;
    var item = { msg: msg, base: msg, n: 1, kind: kind || 'info', at: state.t };
    if (queued && top && state.t - top.at < TOAST_MIN) { state.toastQ.push(item); if (state.toastQ.length > 6) state.toastQ.shift(); return; }
    state.toast.unshift(item); if (state.toast.length > 4) state.toast.pop();
  }
  function note(msg, kind) { toast(msg, kind, true); }
  function toastTick() {
    if (!state.toastQ.length) return;
    var top = state.toast[0];
    if (top && state.t - top.at < TOAST_MIN) return;
    var next = state.toastQ.shift(); next.at = state.t;
    state.toast.unshift(next); if (state.toast.length > 4) state.toast.pop();
  }
  function fs(n) { return shape === 'tall' ? Math.round(n * 1.1) : n; }
  function cap1(s) { return s.charAt(0).toUpperCase() + s.slice(1); }
  function fmt(n) { n = Math.floor(n); return n >= 1e6 ? (n / 1e6).toFixed(2) + 'M' : n >= 1e4 ? Math.round(n / 1000) + 'k' : String(n); }
  function pct(x) { return Math.floor(x * 100 + 1e-9) + '%'; }
  function yrs(x) { return x < 10 ? x.toFixed(1) : String(Math.floor(x)); }

  /* -------------------------------------------------------------- layout */
  function L() {
    if (shape === 'wide') return {
      top: { x: 0, y: 0, w: 960, h: 52 },
      wood: { x: 8, y: 58, cw: 40, ch: 36 },
      crew: { x: 576, y: 58, w: 376, h: 288 },
      panel: { x: 8, y: 354, w: 944, h: 194 }, bottom: { x: 0, y: 552, w: 960, h: 48 },
    };
    return {
      top: { x: 0, y: 0, w: 480, h: 86 },
      wood: { x: 7, y: 92, cw: 33, ch: 30 },
      crew: { x: 8, y: 338, w: 464, h: 206 },
      panel: { x: 8, y: 550, w: 464, h: 330 }, bottom: { x: 0, y: 884, w: 480, h: 76 },
    };
  }
  function woodRect() { var r = L().wood; return { x: r.x, y: r.y, w: r.cw * SIM.COLS, h: r.ch * SIM.ROWS, cw: r.cw, ch: r.ch }; }
  function cellRect(i) { var r = woodRect(); return { x: r.x + SIM.cx(i) * r.cw, y: r.y + SIM.cy(i) * r.ch, w: r.cw, h: r.ch }; }
  function cellAt(x, y) {
    var r = woodRect();
    if (x < r.x || y < r.y || x >= r.x + r.w || y >= r.y + r.h) return -1;
    return Math.floor((y - r.y) / r.ch) * SIM.COLS + Math.floor((x - r.x) / r.cw);
  }

  /* ------------------------------------------------------------- drawing */
  var buttons = [];
  function T(s, x, y, size, col, align, weight, family) {
    g.font = (weight || '400') + ' ' + size + 'px ' + (family || UI);
    g.textAlign = align || 'left'; g.textBaseline = 'alphabetic';
    g.fillStyle = col || C.ink;
    g.fillText(s, x, y);
    return g.measureText(s).width;
  }
  function tw(s, size, weight) { g.font = (weight || '400') + ' ' + size + 'px ' + UI; return g.measureText(s).width; }
  function rr(x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
  function btn(id, x, y, w, h, label, enabled, on, sub, why) {
    var b = { id: id, x: x, y: y, w: w, h: h, label: label, enabled: enabled !== false, on: !!on, sub: sub, why: why };
    buttons.push(b); return b;
  }
  var hoverBtn = null;
  function drawButtons() {
    for (var i = 0; i < buttons.length; i++) {
      var b = buttons[i];
      if (b.silent) continue;
      var armed = state.armed === b.id && state.t - state.armedAt <= 8;
      /* a finished upgrade has its own green fill, so it no longer looks like one you cannot afford (review D18) */
      g.fillStyle = b.done ? '#23361e' : !b.enabled ? '#1c2216' : b.on ? C.btnOn : (b === hoverBtn || armed ? '#34452a' : C.btn);
      g.strokeStyle = b.on || armed ? C.gold : b.done ? '#5f8a44' : b.enabled ? C.btnEdge : '#3a4430';
      g.lineWidth = b.on || armed ? 2 : 1;
      rr(b.x, b.y, b.w, b.h, 5); g.fill(); g.stroke();
      var f = fs(b.h >= 34 ? 13 : 12), cx0 = b.x + b.w / 2;
      if (b.label) T(b.label, cx0, b.y + (b.sub ? b.h / 2 - 2 : b.h / 2 + f * 0.36), f, b.enabled ? C.ink : '#8d927f', 'center', '700');
      if (b.sub) T(b.sub, cx0, b.y + b.h / 2 + fs(11) + 1, fs(11), b.enabled ? (b.subCol || C.gold) : '#8d927f', 'center', '400');
    }
  }
  function bar(x, y, w, h, f, col, back) {
    g.fillStyle = back || '#2a3322'; rr(x, y, w, h, h / 2); g.fill();
    var fw = Math.max(0, Math.min(1, f)) * w;
    if (fw > 0.5) { g.fillStyle = col; rr(x, y, Math.max(h, fw), h, h / 2); g.fill(); }
  }
  function wrapText(s, x, y, w, size, col, weight, lh) {
    g.font = (weight || '400') + ' ' + size + 'px ' + UI;
    var words = s.split(' '), line = '';
    for (var i = 0; i < words.length; i++) {
      var tst = line ? line + ' ' + words[i] : words[i];
      if (g.measureText(tst).width > w && line) { T(line, x, y, size, col, 'left', weight); y += lh || size + 5; line = words[i]; } else line = tst;
    }
    if (line) { T(line, x, y, size, col, 'left', weight); y += lh || size + 5; }
    return y;
  }
  function wrapCenter(s, cx, y, w, size, col) {
    g.font = '400 ' + size + 'px ' + UI;
    var words = s.split(' '), line = '';
    for (var i = 0; i < words.length; i++) { var tst = line ? line + ' ' + words[i] : words[i]; if (g.measureText(tst).width > w && line) { T(line, cx, y, size, col, 'center'); y += size + 6; line = words[i]; } else line = tst; }
    if (line) { T(line, cx, y, size, col, 'center'); y += size + 6; }
    return y;
  }
  function hash(n) { return SIM.hash(n); }
  function mix(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }
  function rgb(c, k) { k = k || 1; return 'rgb(' + Math.round(Math.min(255, c[0] * k)) + ',' + Math.round(Math.min(255, c[1] * k)) + ',' + Math.round(Math.min(255, c[2] * k)) + ')'; }
  function rgba(c, al) { return 'rgba(' + Math.round(c[0]) + ',' + Math.round(c[1]) + ',' + Math.round(c[2]) + ',' + al + ')'; }

  /* ------------------------------------------------------------ the wood
   * Seen from above. The SEASON sets every colour: spring's fresh green and bluebells, summer's deep leaf, autumn's
   * gold, winter's bare twigs. A hazel stool is DRAWN from its age: a ring of pale cut stubs, a fan of shoots, a
   * rounded bush of rods, a full crown, and past 16 years a dark overgrown tangle with dead grey poles. Oaks spread
   * their crowns over the stools beside them. */
  var LEAF = [  /* [dark, mid, light] per season: SPRING SUMMER AUTUMN WINTER(no leaf) */
    [[70, 118, 44], [108, 162, 60], [160, 206, 92]],
    [[40, 82, 34], [62, 112, 44], [96, 148, 62]],
    [[128, 88, 30], [184, 132, 44], [226, 180, 76]],
    [[82, 64, 48], [110, 88, 66], [140, 116, 90]],
  ];
  var OAKLEAF = [
    [[64, 104, 40], [92, 140, 54], [140, 186, 82]],
    [[34, 70, 30], [52, 96, 40], [86, 130, 56]],
    [[120, 70, 28], [160, 104, 38], [204, 150, 64]],
    [[70, 58, 46], [96, 80, 62], [124, 106, 84]],
  ];
  var FLAT = { litter: '#3a2e20', clearing: '#574832', bramble: '#282e1e' };
  function seasonOf(a) { return a ? SIM.season(a) : 0; }
  function drawGround(c, i, x, y, w, h, se) {
    var fresh = c.k === 'hazel' && c.age < 3, key = c.k === 'gap' ? 'bramble' : fresh ? 'clearing' : 'litter';
    g.fillStyle = PLATES[key] || FLAT[key]; g.fillRect(x, y, w, h);
    if (se === 3) { g.fillStyle = 'rgba(236,240,248,0.75)'; for (var fr = 0; fr < 10; fr++) g.fillRect(x + 1 + hash(i * 211 + fr * 7) * (w - 3), y + 1 + hash(i * 223 + fr * 11) * (h - 3), 2, 2); }
  }
  /* the flora on a fresh coupe, drawn in a SECOND pass over all the ground so a clump can bleed into the next cell
   * (drawn with the ground, the next cell's plate painted over it) */
  function drawFlora(c, i, x, y, w, h, se) {
    var fresh = c.k === 'hazel' && c.age < 3;
    if (fresh) {
      /* the light on a fresh coupe: bluebells in spring, bracken and flowers in summer */
      var n = 30, k;
      if (se === 0) {
        /* a bluebell CARPET (the first version drew fourteen 2 px dots, invisible in a gallery plate whose caption named
         * the bluebells). Review D9: a flat violet square per cell then read as a selection highlight, so the carpet is
         * three or four feathered clumps per cell, each its own size and place, bleeding past the cell edge into the
         * next fresh one: a coupe reads as one drift of flowers with a ragged border */
        var clumps = 3 + Math.floor(hash(i * 97 + 3) * 2);
        for (var cl = 0; cl < clumps; cl++) {
          var qx = x + w * (0.15 + 0.7 * hash(i * 211 + cl * 17)), qy = y + h * (0.15 + 0.7 * hash(i * 223 + cl * 29)), qr = Math.min(w, h) * (0.32 + 0.22 * hash(i * 227 + cl * 31));
          var rg = g.createRadialGradient(qx, qy, 0, qx, qy, qr);
          rg.addColorStop(0, 'rgba(116,106,230,0.46)'); rg.addColorStop(0.6, 'rgba(112,104,224,0.24)'); rg.addColorStop(1, 'rgba(112,104,224,0)');
          g.fillStyle = rg; g.beginPath(); g.arc(qx, qy, qr, 0, Math.PI * 2); g.fill();
        }
        for (k = 0; k < n; k++) {
          var bx = x + 1 + hash(i * 131 + k * 17) * (w - 3), by = y + 1 + hash(i * 71 + k * 29 + 5) * (h - 3);
          g.fillStyle = k % 4 === 0 ? '#d4c8ff' : k % 3 === 0 ? '#8a82f0' : '#6c63e0'; g.fillRect(bx, by, 2, 3);
          if (k % 7 === 0) { g.fillStyle = '#f2e27a'; g.fillRect(bx + 3, by - 1, 2, 2); }
        }
      } else if (se === 1) {
        for (k = 0; k < 8; k++) { var fx = x + 3 + hash(i * 53 + k * 13) * (w - 6), fy = y + 3 + hash(i * 37 + k * 11) * (h - 6); g.fillStyle = k % 3 ? '#6e9a3e' : '#d9a0c8'; g.fillRect(fx, fy, 2, k % 3 ? 3 : 2); }
      }
    }
  }
  function drawBramble(c, i, x, y, w, h, se) {
    /* the gap: a tangle of arching stems over the plate, flowers in summer, berries in autumn */
    g.strokeStyle = se === 3 ? '#6a3a40' : '#7a3844'; g.lineWidth = 1.5;
    for (var k = 0; k < 4; k++) {
      var cx0 = x + w * (0.2 + 0.6 * hash(i * 17 + k)), cy0 = y + h * (0.3 + 0.5 * hash(i * 23 + k * 3)), r = Math.min(w, h) * (0.25 + 0.2 * hash(i + k * 7));
      g.beginPath(); g.arc(cx0, cy0, r, Math.PI * (1 + hash(i * 3 + k)), Math.PI * (1.9 + hash(i * 5 + k))); g.stroke();
    }
    if (se !== 3) { g.fillStyle = se === 2 ? '#4a4a2a' : '#3f6a2c'; for (var q = 0; q < 6; q++) g.fillRect(x + 3 + hash(i * 41 + q) * (w - 6), y + 3 + hash(i * 43 + q) * (h - 6), 3, 2); }
    if (se === 1) { g.fillStyle = '#f0d0dc'; for (var f = 0; f < 3; f++) g.fillRect(x + 4 + hash(i * 61 + f) * (w - 8), y + 4 + hash(i * 67 + f) * (h - 8), 2, 2); }
    if (se === 2) { g.fillStyle = '#2a1030'; for (var b = 0; b < 4; b++) g.fillRect(x + 4 + hash(i * 71 + b) * (w - 8), y + 4 + hash(i * 73 + b) * (h - 8), 2, 2); }
  }
  function drawStool(c, i, x, y, w, h, se, now) {
    var m = Math.min(w, h), cx0 = x + w / 2, cy0 = y + h / 2, age = c.age, seed = i * 7919;
    var L0 = LEAF[se], vigK = 0.75 + 0.25 * Math.min(1, c.vig);
    var over = age > SIM.OVERSTOOD;
    /* the stool itself: a dark boss with the cut stubs of old poles */
    g.fillStyle = 'rgba(20,14,8,0.45)'; g.beginPath(); g.ellipse(cx0 + 1, cy0 + 2, m * 0.24, m * 0.2, 0, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#4a3624'; g.beginPath(); g.arc(cx0, cy0, m * 0.2, 0, Math.PI * 2); g.fill();
    var stubs = 6 + Math.floor(hash(seed) * 4);
    for (var k = 0; k < stubs; k++) {
      var an = k / stubs * Math.PI * 2 + hash(seed + k) * 0.5, rd = m * (0.1 + 0.08 * hash(seed + k * 3));
      var sx = cx0 + Math.cos(an) * rd, sy = cy0 + Math.sin(an) * rd, fresh = age < 0.6;
      g.fillStyle = fresh ? '#e6cf9c' : '#6e5638'; g.beginPath(); g.arc(sx, sy, Math.max(1.2, m * 0.05), 0, Math.PI * 2); g.fill();
      if (fresh) { g.fillStyle = '#b89464'; g.fillRect(sx - 0.5, sy - 0.5, 1, 1); }
    }
    if (age < 0.25) return;
    /* the rods: a fan from the stool, longer and thicker with age */
    var reach = m * Math.min(0.62, 0.16 + 0.05 * age + (over ? 0.08 : 0)), rods = 7 + Math.min(9, Math.floor(age));
    g.lineCap = 'round';
    for (var r = 0; r < rods; r++) {
      var ra = r / rods * Math.PI * 2 + hash(seed + r * 5) * 0.4, rl = reach * (0.65 + 0.35 * hash(seed + r * 7));
      var ex = cx0 + Math.cos(ra) * rl, ey = cy0 + Math.sin(ra) * rl;
      var dead = over && hash(seed + r * 11) < 0.25;
      g.strokeStyle = dead ? '#9a9486' : se === 3 ? (r % 2 ? '#b8966c' : '#9c7c58') : '#6a5238'; g.lineWidth = Math.max(1, Math.min(3, 0.6 + age * 0.12));
      g.beginPath(); g.moveTo(cx0, cy0); g.lineTo(ex, ey); g.stroke();
    }
    if (se === 3) {
      /* winter: bare twigs, and catkins on grown hazel late in the season */
      if (age >= 4) { g.fillStyle = '#d8c060'; for (var ck = 0; ck < 5; ck++) { var ca = hash(seed + ck * 13) * Math.PI * 2, cd = reach * (0.5 + 0.4 * hash(seed + ck)); g.fillRect(cx0 + Math.cos(ca) * cd - 0.5, cy0 + Math.sin(ca) * cd, 1.5, 3); } }
      return;
    }
    /* the leaf: clusters on the rods, a rounded crown once the stool is grown */
    var blobs = Math.min(12, 3 + Math.floor(age * 1.2)), br = m * Math.min(0.2, 0.06 + 0.012 * age);
    for (var b = 0; b < blobs; b++) {
      var ba = b / blobs * Math.PI * 2 + hash(seed + b * 19) * 0.7, bd = reach * (0.35 + 0.55 * hash(seed + b * 23));
      var bx = cx0 + Math.cos(ba) * bd, by = cy0 + Math.sin(ba) * bd, rr0 = br * (0.7 + 0.5 * hash(seed + b * 29));
      g.fillStyle = rgb(L0[0], vigK * (over ? 0.75 : 1)); g.beginPath(); g.arc(bx + 1, by + 1, rr0, 0, Math.PI * 2); g.fill();
      g.fillStyle = rgb(L0[1], vigK * (over ? 0.8 : 1)); g.beginPath(); g.arc(bx, by, rr0 * 0.9, 0, Math.PI * 2); g.fill();
      g.fillStyle = rgb(L0[2], vigK * (over ? 0.8 : 1)); g.beginPath(); g.arc(bx - rr0 * 0.3, by - rr0 * 0.3, rr0 * 0.4, 0, Math.PI * 2); g.fill();
    }
    /* hazelnuts in autumn on stools old enough to bear */
    if (se === 2 && age >= 8 && !over) { g.fillStyle = '#7a4a22'; for (var nk = 0; nk < 4; nk++) { var na = hash(seed + nk * 31) * Math.PI * 2, nd = reach * 0.6; g.beginPath(); g.arc(cx0 + Math.cos(na) * nd, cy0 + Math.sin(na) * nd, 1.6, 0, Math.PI * 2); g.fill(); } }
  }
  function drawOakCrown(c, i, x, y, w, h, se, now) {
    var cx0 = x + w / 2, cy0 = y + h / 2, m = Math.min(w, h), seed = i * 104729, O = OAKLEAF[se];
    var R = c.age < 6 ? m * (0.18 + 0.03 * c.age) : c.age < SIM.MATURE_OAK ? m * (0.36 + 0.02 * (c.age - 6)) : m * Math.min(0.95, 0.66 + 0.004 * c.age);
    /* the trunk and a shadow thrown down-right */
    g.fillStyle = 'rgba(12,10,6,0.32)'; g.beginPath(); g.ellipse(cx0 + R * 0.25, cy0 + R * 0.3, R * 1.02, R * 0.92, 0, 0, Math.PI * 2); g.fill();
    if (se === 3) {
      /* bare winter oak: pale limbs so the tree reads over dark ground (a dark brown one vanished), each limb laid over
       * a dark underlay and the whole tree over a heavier shadow, so at store scale it no longer merges with the pale
       * hazel starbursts (review D24) */
      g.fillStyle = 'rgba(12,10,6,0.30)'; g.beginPath(); g.ellipse(cx0 + R * 0.2, cy0 + R * 0.25, R * 0.95, R * 0.85, 0, 0, Math.PI * 2); g.fill();
      g.lineCap = 'round';
      for (var pass = 0; pass < 2; pass++) {
        g.strokeStyle = pass ? '#b49c7a' : '#241a10';
        for (var k = 0; k < 7; k++) {
          var an = k / 7 * Math.PI * 2 + hash(seed + k) * 0.5, mx = cx0 + Math.cos(an) * R * 0.55, my = cy0 + Math.sin(an) * R * 0.55;
          g.lineWidth = Math.max(1.5, R * 0.1) + (pass ? 0 : 2.5); g.beginPath(); g.moveTo(cx0, cy0); g.lineTo(mx, my); g.stroke();
          g.lineWidth = Math.max(1, R * 0.05) + (pass ? 0 : 2);
          for (var f = -1; f <= 1; f += 2) { var fa = an + f * 0.45, fl = R * 0.45; g.beginPath(); g.moveTo(mx, my); g.lineTo(mx + Math.cos(fa) * fl, my + Math.sin(fa) * fl); g.stroke(); }
        }
      }
      g.fillStyle = '#8a7258'; g.beginPath(); g.arc(cx0, cy0, Math.max(2, R * 0.14), 0, Math.PI * 2); g.fill();
      return;
    }
    var lobes = 9;
    for (var l = 0; l < lobes; l++) {
      var la = l / lobes * Math.PI * 2 + hash(seed + l) * 0.4, ld = R * 0.55, lr = R * (0.42 + 0.12 * hash(seed + l * 3));
      g.fillStyle = rgb(O[0]); g.beginPath(); g.arc(cx0 + Math.cos(la) * ld + 1.5, cy0 + Math.sin(la) * ld + 1.5, lr, 0, Math.PI * 2); g.fill();
    }
    for (var l2 = 0; l2 < lobes; l2++) {
      var la2 = l2 / lobes * Math.PI * 2 + hash(seed + l2) * 0.4, ld2 = R * 0.5, lr2 = R * (0.38 + 0.12 * hash(seed + l2 * 3));
      g.fillStyle = rgb(O[1]); g.beginPath(); g.arc(cx0 + Math.cos(la2) * ld2, cy0 + Math.sin(la2) * ld2, lr2, 0, Math.PI * 2); g.fill();
    }
    g.fillStyle = rgb(O[1]); g.beginPath(); g.arc(cx0, cy0, R * 0.6, 0, Math.PI * 2); g.fill();
    for (var hl = 0; hl < 7; hl++) {
      var ha = -Math.PI * 0.75 + (hash(seed + hl * 7) - 0.5) * 1.6, hd = R * (0.2 + 0.45 * hash(seed + hl * 11)), hr = R * (0.12 + 0.1 * hash(seed + hl * 13));
      g.fillStyle = rgb(O[2]); g.beginPath(); g.arc(cx0 + Math.cos(ha) * hd, cy0 + Math.sin(ha) * hd, hr, 0, Math.PI * 2); g.fill();
    }
    if (se === 2) { g.fillStyle = '#e0b060'; for (var ac = 0; ac < 6; ac++) g.fillRect(cx0 + (hash(seed + ac * 17) - 0.5) * R * 1.4, cy0 + (hash(seed + ac * 19) - 0.5) * R * 1.4, 2, 2); }
  }
  function drawHedge(x, y, w, h) {
    /* a dead hedge: brash woven into a low fence round the stool */
    g.strokeStyle = '#8a6a44'; g.lineWidth = 2; g.setLineDash([3, 2]); g.strokeRect(x + 2.5, y + 2.5, w - 5, h - 5); g.setLineDash([]);
    g.strokeStyle = '#5e4630'; g.lineWidth = 1;
    for (var k = 0; k < 4; k++) { var px = x + 3 + k * (w - 6) / 3; g.beginPath(); g.moveTo(px, y + 1); g.lineTo(px + 2, y + 5); g.stroke(); g.beginPath(); g.moveTo(px, y + h - 1); g.lineTo(px + 2, y + h - 5); g.stroke(); }
  }
  function drawMark(x, y, w, h, n, oak) {
    /* the woodward's mark: a white slash of paint and a ribbon, with the stool's place in the queue */
    g.fillStyle = oak ? '#ff8a5c' : '#f4f0e0'; g.save(); g.translate(x + w * 0.28, y + h * 0.3); g.rotate(-0.6); g.fillRect(-5, -1.5, 10, 3); g.restore();
    g.fillStyle = oak ? '#c0402a' : '#d8342a'; g.fillRect(x + w - 10, y + 3, 5, 7); g.beginPath(); g.moveTo(x + w - 10, y + 10); g.lineTo(x + w - 7.5, y + 8); g.lineTo(x + w - 5, y + 10); g.fill();
    if (n) { g.fillStyle = 'rgba(16,20,12,0.75)'; rr(x + 2, y + h - 13, 14, 11, 3); g.fill(); T(String(n), x + 9, y + h - 4, 9, C.ink, 'center', '700'); }
  }
  function drawWoodAt(a, r, now, opts) {
    opts = opts || {};
    var cols = opts.cols || SIM.COLS, rows = opts.rows || SIM.ROWS, cells = opts.cells || a.cells, se = opts.season !== undefined ? opts.season : seasonOf(a);
    var i, x, y, c;
    for (i = 0; i < cells.length; i++) { x = r.x + (i % cols) * r.cw; y = r.y + Math.floor(i / cols) * r.ch; drawGround(cells[i], i, x, y, r.cw, r.ch, se); }
    for (i = 0; i < cells.length; i++) { x = r.x + (i % cols) * r.cw; y = r.y + Math.floor(i / cols) * r.ch; drawFlora(cells[i], i, x, y, r.cw, r.ch, se); }
    for (i = 0; i < cells.length; i++) { c = cells[i]; if (c.k !== 'gap') continue; x = r.x + (i % cols) * r.cw; y = r.y + Math.floor(i / cols) * r.ch; drawBramble(c, i, x, y, r.cw, r.ch, se); }
    for (i = 0; i < cells.length; i++) { c = cells[i]; if (c.k !== 'hazel') continue; x = r.x + (i % cols) * r.cw; y = r.y + Math.floor(i / cols) * r.ch; drawStool(c, i, x, y, r.cw, r.ch, se, now); if (a && c.hedge > a.t) drawHedge(x, y, r.cw, r.ch); }
    for (i = 0; i < cells.length; i++) { c = cells[i]; if (c.k !== 'oak') continue; x = r.x + (i % cols) * r.cw; y = r.y + Math.floor(i / cols) * r.ch; drawOakCrown(c, i, x, y, r.cw, r.ch, se, now); }
  }
  /* the crew: a figure at each stool being cut, the axe rising and falling */
  function drawCrew(a, r, now) {
    if (!SIM.cuttingSeason(a) || !a.queue.length) return;
    var n = Math.min(SIM.crew(a), a.queue.length);
    for (var k = 0; k < n; k++) {
      var i = a.queue[k], cr = cellRect(i), px = cr.x + cr.w * (0.2 + 0.6 * hash(i * 3 + k)), py = cr.y + cr.h * 0.78;
      var sw = Math.sin(now * 9 + k * 1.7);
      g.fillStyle = 'rgba(10,8,4,0.35)'; g.beginPath(); g.ellipse(px + 2, py + 3, 4, 2, 0, 0, Math.PI * 2); g.fill();
      g.fillStyle = '#3a4a6a'; g.fillRect(px - 2.5, py - 5, 5, 6);
      g.fillStyle = '#e0b890'; g.beginPath(); g.arc(px, py - 7, 2.4, 0, Math.PI * 2); g.fill();
      g.fillStyle = '#6a4a2a'; g.fillRect(px - 2.5, py - 10, 5, 2);
      g.strokeStyle = '#8a6a44'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(px + 2, py - 4); var ax = px + 2 + Math.cos(-1.2 + sw * 0.9) * 7, ay = py - 4 + Math.sin(-1.2 + sw * 0.9) * 7; g.lineTo(ax, ay); g.stroke();
      g.fillStyle = '#c8ccd0'; g.fillRect(ax - 1.5, ay - 1.5, 3, 3);
      if (k === 0) { var c0 = a.cells[i], p = Math.min(1, c0.work / SIM.workNeeded(c0)); g.strokeStyle = C.gold; g.lineWidth = 2; g.beginPath(); g.arc(cr.x + cr.w / 2, cr.y + cr.h / 2, Math.min(cr.w, cr.h) * 0.42, -Math.PI / 2, -Math.PI / 2 + p * Math.PI * 2); g.stroke(); }
    }
  }
  /* the deer: a few of the herd, drifting to the freshest stools in spring and summer */
  function drawDeer(a, r, now) {
    var se = seasonOf(a), n = Math.min(7, Math.round(a.deer / 2));
    if (!n) return;
    var fresh = [];
    for (var i = 0; i < SIM.N; i++) { var c = a.cells[i]; if (SIM.isHazel(c) && c.age < 2 && !(c.hedge > a.t)) fresh.push(i); }
    for (var k = 0; k < n; k++) {
      var ph = now * 0.05 + k * 0.37, tx, ty;
      if ((se === 0 || se === 1) && fresh.length && !a.levels.fence) { var ci = cellRect(fresh[(k * 7 + Math.floor(ph)) % fresh.length]); tx = ci.x + ci.w / 2; ty = ci.y + ci.h / 2; }
      else { tx = r.x + ((hash(k * 13) * r.w + now * (6 + k)) % r.w); ty = r.y + r.h * (0.15 + 0.7 * hash(k * 17)) + Math.sin(now * 0.3 + k) * 6; }
      var dx = tx + Math.sin(now * 0.7 + k) * 5, dy = ty + Math.cos(now * 0.5 + k) * 3, fl = Math.sin(now * 0.6 + k) > 0 ? 1 : -1;
      g.fillStyle = 'rgba(10,8,4,0.3)'; g.beginPath(); g.ellipse(dx + 2, dy + 3, 7, 2.5, 0, 0, Math.PI * 2); g.fill();
      g.fillStyle = '#9a6a3e'; g.beginPath(); g.ellipse(dx, dy, 7, 3.2, 0, 0, Math.PI * 2); g.fill();
      g.fillStyle = '#b07e4c'; g.beginPath(); g.ellipse(dx + fl * 7, dy - 2, 2.8, 2, 0, 0, Math.PI * 2); g.fill();
      g.fillStyle = '#f2ead8'; g.fillRect(dx - fl * 7 - 1, dy - 1, 2, 2);
      g.strokeStyle = '#5a3a1e'; g.lineWidth = 1; g.beginPath(); g.moveTo(dx + fl * 8, dy - 4); g.lineTo(dx + fl * 9, dy - 7); g.stroke();
    }
  }
  function drawSeasonAir(a, r, now) {
    var se = seasonOf(a);
    g.save(); g.beginPath(); g.rect(r.x, r.y, r.w, r.h); g.clip();
    if (se === 3) {
      g.fillStyle = 'rgba(220,230,240,0.10)'; g.fillRect(r.x, r.y, r.w, r.h);
      g.fillStyle = 'rgba(245,248,255,0.8)';
      for (var s = 0; s < 40; s++) { var sx = r.x + ((hash(s * 7) * r.w + now * (8 + 6 * hash(s))) % r.w), sy = r.y + ((hash(s * 3) * r.h + now * (14 + 8 * hash(s * 5))) % r.h); g.fillRect(sx, sy, 1.5, 1.5); }
    } else if (se === 2) {
      for (var f = 0; f < 18; f++) { var fx = r.x + ((hash(f * 11) * r.w + now * 10) % r.w), fy = r.y + ((hash(f * 13) * r.h + now * (12 + 6 * hash(f))) % r.h); g.fillStyle = f % 2 ? '#d89a3a' : '#b86a2a'; g.save(); g.translate(fx, fy); g.rotate(now * 2 + f); g.fillRect(-2, -1, 4, 2); g.restore(); }
    } else if (se === 1 && a && a.lastSurvey && a.lastSurvey.found[1]) {
      /* fritillaries over the fresh coupes, once the survey has found them */
      for (var b = 0; b < 8; b++) { var bx = r.x + ((hash(b * 19) * r.w + now * 18) % r.w), by = r.y + r.h * hash(b * 23) + Math.sin(now * 5 + b) * 5, fw = Math.abs(Math.sin(now * 12 + b)) * 3 + 1; g.fillStyle = '#f09a3a'; g.fillRect(bx - fw, by - 1, fw, 3); g.fillRect(bx + 1, by - 1, fw, 3); g.fillStyle = '#3a2410'; g.fillRect(bx, by - 1, 1, 3); }
    }
    /* the sun from the upper left */
    var sg = g.createLinearGradient(r.x, r.y, r.x + r.w, r.y + r.h);
    sg.addColorStop(0, se === 3 ? 'rgba(200,215,235,0.10)' : 'rgba(255,240,190,0.10)'); sg.addColorStop(1, 'rgba(10,20,8,0.18)');
    g.fillStyle = sg; g.fillRect(r.x, r.y, r.w, r.h);
    g.restore();
  }
  function drawWood(a) {
    var r = woodRect(), now = state.t;
    g.save(); rr(r.x - 2, r.y - 2, r.w + 4, r.h + 4, 6); g.clip();
    drawWoodAt(a, r, now);
    for (var i = 0; i < SIM.N; i++) {
      var c = a.cells[i]; if (!c.mark) continue;
      var cr = cellRect(i); drawMark(cr.x, cr.y, cr.w, cr.h, a.queue.indexOf(i) + 1, c.k === 'oak');
    }
    drawCrew(a, r, now);
    if (!state.noDeer) drawDeer(a, r, now);
    drawSeasonAir(a, r, now);
    /* a finished cut: chips fly for a moment */
    for (var b = state.chips.length - 1; b >= 0; b--) {
      var sp = state.chips[b], age = state.t - sp.at; if (age > 1) { state.chips.splice(b, 1); continue; }
      var ch = cellRect(sp.i);
      for (var k = 0; k < 8; k++) { var an = k / 8 * Math.PI * 2 + hash(sp.i + k), d = 4 + age * 18; g.fillStyle = 'rgba(236,214,160,' + (1 - age).toFixed(2) + ')'; g.fillRect(ch.x + ch.w / 2 + Math.cos(an) * d, ch.y + ch.h / 2 + Math.sin(an) * d - age * 6, 2, 2); }
    }
    for (var s2 = state.splash.length - 1; s2 >= 0; s2--) {
      var sp2 = state.splash[s2], ag = state.t - sp2.at; if (ag > 1) { state.splash.splice(s2, 1); continue; }
      var cr2 = cellRect(sp2.i); g.strokeStyle = 'rgba(240,236,200,' + (0.8 * (1 - ag)).toFixed(2) + ')'; g.lineWidth = 1.5;
      g.beginPath(); g.arc(cr2.x + cr2.w / 2, cr2.y + cr2.h / 2, 6 + ag * 14, 0, Math.PI * 2); g.stroke();
    }
    drawHints(a, r);
    g.restore();
    g.strokeStyle = C.panelEdge; g.lineWidth = 1; rr(r.x - 2, r.y - 2, r.w + 4, r.h + 4, 6); g.stroke();
  }
  /* where the chosen tool can act: a small mark in each cell it can work, so the wood answers "where?" */
  function toolOk(a, i) {
    if (state.tool === 'mark') return !SIM.whyNotMark(a, i);
    /* review D16: the hint crosses mark only the stools a hedge HELPS (under 2 years, the ones the deer browse);
     * hedging an older one is still allowed */
    if (state.tool === 'hedge') return !SIM.whyNotHedge(a, i) && a.cells[i].age < 2;
    if (state.tool === 'layer') return !SIM.whyNotLayer(a, i);
    return !SIM.whyNotOak(a, i);
  }
  function drawHints(a, r) {
    var cur = state.cursor, hov = state.hoverCell;
    if (state.tool !== 'mark') {
      for (var i = 0; i < SIM.N; i++) {
        if (!toolOk(a, i)) continue;
        var cr = cellRect(i), cx0 = cr.x + cr.w / 2, cy0 = cr.y + cr.h / 2;
        g.fillStyle = state.tool === 'hedge' ? 'rgba(255,220,150,0.9)' : state.tool === 'layer' ? 'rgba(170,240,130,0.9)' : 'rgba(255,200,120,0.9)';
        g.fillRect(cx0 - 4, cy0 - 1, 8, 2); g.fillRect(cx0 - 1, cy0 - 4, 2, 8);
      }
    }
    if (hov >= 0) { var h = cellRect(hov); g.strokeStyle = 'rgba(255,255,255,0.85)'; g.lineWidth = 1.5; g.strokeRect(h.x + 1, h.y + 1, h.w - 2, h.h - 2); }
    if (cur >= 0) { var c2 = cellRect(cur); g.strokeStyle = C.gold; g.lineWidth = 2; g.setLineDash([4, 3]); g.strokeRect(c2.x + 1.5, c2.y + 1.5, c2.w - 3, c2.h - 3); g.setLineDash([]); }
  }

  /* ------------------------------------------------------------ top bar */
  function drawTop(a) {
    var t = L().top, se = SIM.season(a);
    g.fillStyle = '#131a0e'; g.fillRect(t.x, t.y, t.w, t.h);
    g.fillStyle = C.panelEdge; g.fillRect(t.x, t.y + t.h - 1, t.w, 1);
    var small = fs(12), seasonCol = [C.moss, C.good, C.gold, C.blue][se];
    /* review D18: the day is the day OF THE SEASON (the absolute day started at 17 on a new wood) */
    var dayLine = SIM.SEASONS[se] + ' day ' + (SIM.dayOfSeason(a) + 1) + ' · YEAR ' + SIM.year(a);
    var rotInfo = 'in rotation: the share of the wood\'s ground (stools and bramble gaps, not oaks) that is hazel of 16 years or under. A stool counts the moment it is cut or layered; the upgrades open as it rises';
    if (shape === 'wide') {
      T('COPPICE', 14, 34, 25, C.moss, 'left', '700', SERIF);
      var x = 156, y1 = 22, y2 = 41;
      T(dayLine, x, y1, small, C.inkDim, 'left', '700');
      T(SIM.cuttingSeason(a) ? 'cutting season' : 'growing season', x, y2, small, seasonCol, 'left', '700');
      T('FUNDS', 372, y1, small, C.inkFaint, 'left', '700'); T(fmt(a.funds), 372, y2, fs(15), C.gold, 'left', '700');
      T('IN ROTATION', 446, y1, small, C.inkFaint, 'left', '700'); T(pct(a.rot), 446, y2, fs(15), C.ink, 'left', '700');
      var rb = btn('info:rot', 440, 6, 96, 42, '', true, false); rb.silent = true; rb.info = rotInfo;
      var found = a.lastSurvey ? a.lastSurvey.found.filter(Boolean).length : 0;
      T('SURVEY', 546, y1, small, C.inkFaint, 'left', '700'); T(found + ' of 5', 546, y2, fs(15), found === 5 ? C.good : C.ink, 'left', '700');
      T('DEER', 626, y1, small, C.inkFaint, 'left', '700'); T(String(Math.round(a.deer)), 626, y2, fs(15), a.deer >= 9 ? C.alarm : C.ink, 'left', '700');
      btn('pause', 700, 11, 58, 30, 'PAUSE');
      btn('help', 764, 11, 56, 30, 'HELP');
      btn('mute', 826, 11, 66, 30, AUDIO.muted() ? 'MUTED' : 'SOUND');
      btn('speed', 898, 11, 50, 30, state.speed > 1 ? '3x' : '1x', true, state.speed > 1);
    } else {
      T('COPPICE', 10, 30, 22, C.moss, 'left', '700', SERIF);
      btn('pause', 166, 6, 64, 36, 'PAUSE'); btn('help', 236, 6, 64, 36, 'HELP'); btn('mute', 306, 6, 98, 36, AUDIO.muted() ? 'MUTED' : 'SOUND'); btn('speed', 410, 6, 62, 36, state.speed > 1 ? '3x' : '1x', true, state.speed > 1);
      T(SIM.SEASONS[se] + ' day ' + (SIM.dayOfSeason(a) + 1) + ' · Y' + SIM.year(a), 10, 60, small, C.inkDim, 'left', '700');
      T(SIM.cuttingSeason(a) ? 'cutting' : 'growing', 196, 60, small, seasonCol, 'left', '700');
      T('DEER ' + Math.round(a.deer), 470, 60, small, a.deer >= 9 ? C.alarm : C.inkFaint, 'right', '700');
      var fnd = a.lastSurvey ? a.lastSurvey.found.filter(Boolean).length : 0;
      T('FUNDS ' + fmt(a.funds), 10, 79, small, C.gold, 'left', '700');
      T('ROTATION ' + pct(a.rot), 150, 79, small, C.ink, 'left', '700');
      var rt = btn('info:rot', 146, 50, 150, 36, '', true, false); rt.silent = true; rt.info = rotInfo;
      T('SURVEY ' + fnd + '/5', 310, 79, small, fnd === 5 ? C.good : C.ink, 'left', '700');
    }
  }

  /* ------------------------------------------------------------ the crew */
  var TOOLS = [['mark', 'MARK'], ['hedge', 'HEDGE'], ['layer', 'LAYER'], ['oak', 'OAK']];
  function drawCrewPanel(a) {
    var n = L().crew, wide = shape === 'wide';
    g.fillStyle = C.panel; rr(n.x, n.y, n.w, n.h, 6); g.fill(); g.strokeStyle = C.panelEdge; g.lineWidth = 1; g.stroke();
    var x = n.x + 10, y = n.y + fs(17), gap = 6;
    T('THE CREW', x, y, fs(12), C.gold, 'left', '700');
    T(SIM.crew(a) + (SIM.crew(a) === 1 ? ' woodsman' : ' woodsmen') + ' · ' + SIM.workRate(a).toFixed(1) + ' days of cutting a day', n.x + n.w - 10, y, fs(11), C.inkFaint, 'right');
    var tb = (n.w - 20 - 3 * gap) / 4, th = wide ? 40 : 42, ty = y + 8;
    var subs = { mark: 'for the crew', hedge: SIM.HEDGE_COST + ' brash', layer: SIM.LAYER_COST + ' funds', oak: a.levels.oaks ? SIM.OAK_COST + ' funds' : 'locked' };
    for (var k = 0; k < TOOLS.length; k++) {
      var id = TOOLS[k][0], en = id !== 'oak' || !!a.levels.oaks;
      var b = btn('tool:' + id, x + k * (tb + gap), ty, tb, th, TOOLS[k][1], en, state.tool === id, subs[id], id === 'oak' ? 'the oak nursery is on the UPGRADES tab' : '');
      if (!en) b.subCol = C.inkFaint;
    }
    /* line 1: what is marked, with CLEAR MARKS at its right end (a button at least 24 css px tall at the smallest
     * phone that picks each shape: 24 logical px wide, 36 tall) */
    var yy = ty + th + fs(17) + (wide ? 0 : 8);
    var q = a.queue.length, qw = SIM.queueWork(a), cap = SIM.workRate(a) * SIM.SEASON_DAYS * 2;
    var cmW = wide ? 104 : 124, cmH = wide ? 24 : 36;
    if (q) btn('clearmarks', n.x + n.w - 10 - cmW, yy - (wide ? 16 : 24), cmW, cmH, 'CLEAR MARKS');
    var line1 = q ? q + ' marked · ' + qw.toFixed(1) + ' days of cutting' : 'Nothing marked. Tap stools with MARK for the crew.';
    T(line1, x, yy, fs(12), q ? C.ink : C.inkDim, 'left', q ? '700' : '400');
    yy += fs(16) + (wide ? 0 : 8);
    /* line 2: what the crew is doing; the last cut is reported HERE, not in the message bar, so a big crew never
     * buries a survey or an unlock under its own news */
    var lc = a.lastCut && a.t - a.lastCut.t < 3 && a.lastCut.p >= 0 ? a.lastCut : null;
    var line2 = SIM.cuttingSeason(a) ? (lc ? 'Last cut: ' + productWord(lc.p, lc.q) + ' to the yard.' : q ? 'Cutting now, in the order you marked them.' : 'The crew is idle: mark something to cut.') : 'The crew waits for autumn; a season of cutting does about ' + Math.round(cap / 2) + ' days.';
    yy = wrapText(line2, x, yy, n.w - 20, fs(11), SIM.cuttingSeason(a) && !q && !lc ? C.alarm : C.inkFaint, '400', fs(11) + 4);
    yy += 2;
    /* review D15: a fence cuts browsing by 65%, it does not keep the deer out */
    T('BRASH ' + Math.floor(a.brash) + ' · DEER ' + Math.round(a.deer) + (a.levels.fence ? ' (fenced: browse -65%)' : '') + (a.levels.keeper ? ' · keeper x' + a.levels.keeper : ''), x, yy, fs(11), C.inkDim, 'left', '700');
    yy += fs(15) + (wide ? 8 : 0);
    if (a.levels.woodward) {
      /* review D10: the rotation row sits on its own line, 8 px clear of the brash line above it */
      var rw = wide ? 44 : 54, rh = wide ? 24 : 36, rx = n.x + n.w - 10 - 4 * rw - 3 * 4;
      T(wide ? 'WOODWARD\'S ROTATION' : 'WOODWARD · up to ' + SIM.coupeSize(a), x, yy + (wide ? 2 : 12), fs(11), C.gold, 'left', '700');
      for (var ri = 0; ri < SIM.ROTATIONS.length; ri++) { var R = SIM.ROTATIONS[ri]; btn('rot:' + R, rx + ri * (rw + 4), yy - (wide ? 14 : 10), rw, rh, R + ' yr', true, a.rotation === R); }
      yy += wide ? 18 : 34;
      /* review D17: the coupe is an upper bound (the plan skips stools under three quarters of the rotation); review D5:
       * say what the survey needs from the choice */
      if (wide) yy = wrapText('Each autumn the woodward marks up to ' + SIM.coupeSize(a) + ' stools, the oldest first. Dormice need hazel of 8 to 16 years: a longer rotation leaves more of it standing.', x, yy + 2, n.w - 20, fs(11), C.inkFaint, '400', fs(11) + 4);
    }
    /* the age key: a stool of each age, drawn by the wood's own renderer in this season, with what it gives */
    var keyH = wide ? 74 : 62;
    if (yy + 4 <= n.y + n.h - keyH) drawAgeKey(a, n.x + 8, n.y + n.h - keyH, n.w - 16, keyH - 6);
    else if (yy > n.y + n.h + 2) state.cut = 1;
  }
  var AGE_KEY = [[1, '1 YR', 'brash'], [3.5, '3 YRS', 'beanpoles'], [7, '7 YRS', 'hurdle rods'], [12, '12 YRS', 'cordwood'], [21, '20+', 'overstood']];
  function drawAgeKey(a, x, y, w, h) {
    var n = AGE_KEY.length, gap = 4, cw = (w - gap * (n - 1)) / n, se = SIM.season(a), box = Math.min(cw - 8, h - (shape === 'wide' ? 30 : 26));
    for (var k = 0; k < n; k++) {
      var bx = x + k * (cw + gap), c = { k: 'hazel', age: AGE_KEY[k][0], vig: k === 4 ? 0.45 : 0.95, hedge: 0 };
      g.fillStyle = '#141a10'; rr(bx, y, cw, h, 4); g.fill();
      var sx = bx + (cw - box) / 2, sy = y + 3;
      g.save(); g.beginPath(); g.rect(sx, sy, box, box); g.clip();
      drawGround(c, 900 + k, sx, sy, box, box, se); drawFlora(c, 900 + k, sx, sy, box, box, se); drawStool(c, 900 + k, sx, sy, box, box, se, state.t);
      g.restore();
      T(AGE_KEY[k][1], bx + cw / 2, sy + box + fs(11), fs(10), C.ink, 'center', '700');
      if (shape === 'wide') T(AGE_KEY[k][2], bx + cw / 2, sy + box + fs(11) + 12, fs(10), k === 4 ? C.alarm : C.inkFaint, 'center');
    }
  }

  /* -------------------------------------------------------------- panel */
  var TABS = [['upgrades', 'UPGRADES'], ['yard', 'THE YARD'], ['survey', 'THE SURVEY']];
  function daysToSurvey(a) { var se = SIM.season(a), d = SIM.dayOfSeason(a); return se === 0 && d < SIM.SURVEY_DAY ? SIM.SURVEY_DAY - d : (3 - se) * SIM.SEASON_DAYS + (SIM.SEASON_DAYS - d) + SIM.SURVEY_DAY; }
  function panelFrame() {
    var p = L().panel;
    g.fillStyle = C.panel; rr(p.x, p.y, p.w, p.h, 6); g.fill(); g.strokeStyle = C.panelEdge; g.lineWidth = 1; g.stroke();
    var tw2 = shape === 'wide' ? 128 : 144, th = shape === 'wide' ? 30 : 36;
    for (var i = 0; i < TABS.length; i++) btn('tab:' + TABS[i][0], p.x + 8 + i * (tw2 + 6), p.y + 8, tw2, th, TABS[i][1], true, state.tab === TABS[i][0]);
    if (shape === 'wide') {
      var dts = daysToSurvey(state.wood);
      T('next spring survey in ' + dts + (dts === 1 ? ' day' : ' days'), p.x + p.w - 12, p.y + 28, fs(12), C.inkFaint, 'right', '700');
    }
    return { x: p.x + 12, y: p.y + th + 18, w: p.w - 24, h: p.h - th - 26 };
  }
  var UPG = [
    ['woodsman', 'WOODSMAN'], ['billhook', 'BILLHOOKS'], ['carter', 'CARTER'], ['hurdler', 'HURDLE MAKER'],
    ['clamp', 'CHARCOAL CLAMP'], ['oaks', 'OAK NURSERY'], ['keeper', 'DEER KEEPER'], ['fence', 'DEER FENCE'],
    ['woodward', 'WOODWARD'], ['kiln', 'RING KILN'], ['walkers', 'WALKERS'],
  ];
  var DONE = {
    woodsman: function (a) { return SIM.crew(a) + ' in the crew'; }, billhook: function () { return 'cutting 1.8x'; }, carter: function (a) { return 'markets x' + (1 + 0.6 * a.levels.carter).toFixed(1); },
    hurdler: function () { return 'a hurdle a day'; }, clamp: function () { return 'burning surplus cordwood'; }, oaks: function () { return 'OAK tool unlocked'; },
    keeper: function () { return 'herd kept down'; }, fence: function () { return 'browsing cut 65%'; }, woodward: function () { return 'marks each autumn'; },
    kiln: function () { return 'twice as fast'; }, walkers: function () { return 'pay for wildlife'; },
  };
  var UPGRADE_INFO = {
    woodsman: 'another pair of hands: more stools cut in each cutting season',
    billhook: 'sharper tools: every woodsman cuts 35% faster, each level',
    carter: 'a carter\'s round to more villages: every market takes 60% more a day, each level',
    hurdler: 'a hurdle maker weaves five rods into a hurdle each day; a hurdle sells for 1.1 to 1.5 times the five rods, and to a market of its own',
    clamp: 'an earth clamp burns the cordwood the market cannot take into charcoal for the forge: 12 cords at a time, 4 days a burn',
    oaks: 'an oak nursery: plant an oak in a gap or on a fresh cut (the OAK tool); oaks shade, and in 20 years count for the woodpecker',
    keeper: 'a keeper culls the deer: the herd shrinks each spring instead of growing',
    fence: 'a deer fence round the wood: the deer browse 65% less',
    woodward: 'a woodward marks one coupe each autumn, up to 1 stool in R for an R-year rotation you choose, oldest first',
    kiln: 'an iron ring kiln: 24 cords a burn, 2 days, a quarter more charcoal per cord',
    walkers: 'open the wood to walkers: they pay ' + SIM.WALKER_PAY + ' funds a day for each species the last survey found',
  };
  function shortWhy(why) {
    var m = /reach (\d+)% in rotation/.exec(why || '');
    if (m) return 'at ' + m[1] + '% in rotation';
    if (/needs a charcoal clamp/.test(why || '')) return 'needs the clamp';
    return why;
  }
  function drawUpgrades(a, c) {
    var wide = shape === 'wide', cols = wide ? 4 : 2, gap = 6, bw = (c.w - gap * (cols - 1)) / cols, bh = 40, rowH = bh + (wide ? 6 : 5);
    for (var i = 0; i < UPG.length; i++) {
      var k = UPG[i][0], u = SIM.UPGRADES[k], lv = a.levels[k], done = lv >= u.max, why = SIM.whyNot(a, k);
      var x = c.x + (i % cols) * (bw + gap), y = c.y + Math.floor(i / cols) * rowH;
      /* the label shows the level HELD (review D18: "WOODSMAN 3/5" used to mean the third was for sale) */
      var lab = UPG[i][1] + (u.max > 1 ? ' ' + lv + '/' + u.max : '');
      var sub = done ? DONE[k](a) : why && why !== 'not enough funds' ? shortWhy(why) : SIM.cost(a, k) + ' funds';
      var b = btn('buy:' + k, x, y, bw, bh, lab, !why, false, sub, done ? 'already done' : why);
      b.info = UPGRADE_INFO[k]; b.done = done;
      if (done) b.subCol = C.good; else if (why && why !== 'not enough funds') b.subCol = C.inkFaint;
      if (y + bh > c.y + c.h + 2) state.cut = 1;
    }
    if (wide) {
      var lx = c.x + 3 * (bw + gap), ly = c.y + 2 * rowH;
      wrapText('Hover an upgrade (or tap it once) to read what it does.', lx + 4, ly + 16, bw - 8, fs(11), C.inkFaint, '400', 14);
    }
  }
  function drawYard(a, c) {
    var wide = shape === 'wide', x = c.x, y = c.y + fs(10);
    var colX = wide ? [x, x + 150, x + 230, x + 330, x + 440] : [x, x + 136, x + 204, x + 290, x + 380];
    var heads = wide ? ['PRODUCT', 'IN THE YARD', 'PRICE TODAY', 'MARKET A DAY', 'SOLD'] : ['PRODUCT', 'YARD', 'PRICE', 'A DAY', 'SOLD'];
    for (var hI = 0; hI < heads.length; hI++) T(heads[hI], colX[hI], y, fs(11), C.gold, 'left', '700');
    for (var p = 0; p < SIM.PRODUCTS.length; p++) {
      var P = SIM.PRODUCTS[p], yy = y + fs(16) * (p + 1), made = a.stats.made[p] > 0 || a.stock[p] > 0;
      T(P.name, colX[0], yy, fs(12), made ? C.ink : C.inkFaint, 'left', '700');
      T(String(Math.floor(a.stock[p])), colX[1], yy, fs(12), a.stock[p] > SIM.depthOf(a, p) * 8 ? C.alarm : C.ink);
      T(SIM.priceOf(a, p).toFixed(2), colX[2], yy, fs(12), C.gold);
      T(SIM.depthOf(a, p).toFixed(1), colX[3], yy, fs(12), C.ink);
      T(fmt(a.stats.sold[p]), colX[4], yy, fs(12), C.inkDim);
    }
    var y2 = y + fs(16) * 6 + 4;
    if (wide) {
      var wx = x + 540, wy = y, ww = c.w - 540;
      T('THE WORKSHOPS', wx, wy, fs(11), C.gold, 'left', '700');
      wy = drawWorkshops(a, wx, wy + 8, ww);
      wrapText('A market that is offered more than it takes a day keeps the rest in the yard: a wood cut at one age floods one market while the others wait. A red number in the yard is a glut.', wx, wy + 6, ww, fs(11), C.inkFaint, '400', fs(11) + 4);
    } else {
      T('THE WORKSHOPS', x, y2 + 4, fs(11), C.gold, 'left', '700');
      var ey = drawWorkshops(a, x, y2 + 12, c.w);
      /* review D11: the glut note on the tall shape too */
      ey = wrapText('A market takes only so much a day; the rest waits in the yard. A red number is a glut.', x, ey + 4, c.w, fs(11), C.inkFaint, '400', fs(11) + 4);
      if (ey - fs(11) > c.y + c.h + 2) state.cut = 1;
    }
  }
  function drawWorkshops(a, x, y, w) {
    var bw = Math.min(160, (w - 6) / 2), bh = shape === 'wide' ? 34 : 40;
    var hb = btn('toggle:hurdles', x, y, bw, bh, 'HURDLE MAKER', !!a.levels.hurdler, a.levels.hurdler && a.toggles.hurdles, a.levels.hurdler ? (a.toggles.hurdles ? 'weaving rods' : 'stopped') : 'not hired', 'hire the hurdle maker on the UPGRADES tab');
    if (!a.levels.hurdler) hb.subCol = C.inkFaint;
    var burning = a.burn ? 'burning ' + a.burn.cords + ' cords, ' + Math.ceil(a.burn.left) + ' d left' : a.toggles.charcoal ? 'waiting for 8 cords' : 'stopped';
    var cb = btn('toggle:charcoal', x + bw + 6, y, bw, bh, a.levels.kiln ? 'RING KILN' : 'CHARCOAL CLAMP', !!a.levels.clamp, a.levels.clamp && a.toggles.charcoal, a.levels.clamp ? burning : 'not built', 'build the clamp on the UPGRADES tab');
    if (!a.levels.clamp) cb.subCol = C.inkFaint;
    return y + bh + fs(14);
  }
  function speciesCounted(a) { return SIM.survey(a); }
  function drawSurvey(a, c) {
    var wide = shape === 'wide', x = c.x, y = c.y + fs(10), s = speciesCounted(a), ls = a.lastSurvey;
    var colX = wide ? [x, x + 132, x + 206, x + 290] : [x, x + 124, x + 196, x + 276];
    T('SPECIES', colX[0], y, fs(11), C.gold, 'left', '700'); T('NEEDS', colX[1], y, fs(11), C.gold, 'left', '700'); T('NOW', colX[2], y, fs(11), C.gold, 'left', '700'); T(wide ? 'LAST SURVEY' : 'LAST', colX[3], y, fs(11), C.gold, 'left', '700');
    for (var k = 0; k < SIM.SPECIES.length; k++) {
      var S = SIM.SPECIES[k], yy = y + fs(16) * (k + 1), ok = s.found[k];
      T(S.name, colX[0], yy, fs(12), ok ? C.good : C.ink, 'left', '700');
      T(String(S.need), colX[1], yy, fs(12), C.inkDim);
      T(String(s.counts[k]), colX[2], yy, fs(12), ok ? C.good : C.alarm, 'left', '700');
      T(ls ? (ls.found[k] ? 'found, Y' + ls.year : 'absent') : 'not yet', colX[3], yy, fs(12), ls && ls.found[k] ? C.good : C.inkFaint);
    }
    var nx = wide ? x + 420 : x, ny = wide ? y : y + fs(16) * 6 + 6, nw = wide ? c.w - 420 : c.w;
    var hov = hoverBtn && hoverBtn.species !== undefined ? hoverBtn.species : -1;
    var words = hov >= 0 ? SIM.SPECIES[hov].name + ': ' + SIM.SPECIES[hov].note + '.' :
      (a.won ? 'Won: all five in one survey. The wood is in rotation; keep it that way.' : 'THE GOAL: all five species in ONE spring survey. No single age holds them all: fresh light, thicket, old hazel and grown oak have to stand in the wood at once, each in a block.');
    /* review D6: the long wait is the dormouse's, so forecast it; review D11: the countdown on the tall shape too */
    if (hov < 0 && !a.won && !s.found[3]) {
      var yd = SIM.yearsToAge(a, 8);
      words += yd < 0 ? ' Dormice: no healthy young hazel is growing toward 8 years yet; cut or layer some and leave it.' : ' Dormice: your nearest healthy stool reaches 8 years in about ' + Math.max(1, Math.round(yd)) + (Math.round(yd) <= 1 ? ' year.' : ' years.');
    }
    if (!wide) words += ' Tap a species to read what it needs. Next survey in ' + daysToSurvey(a) + ' days.';
    var ey = wrapText(words, nx, ny + 4, nw, fs(11), C.inkDim, '400', fs(11) + 4);
    if (!wide || true) {
      /* one invisible hover target per species row, so the notes read in the bar and here */
      for (var r = 0; r < SIM.SPECIES.length; r++) { var hb = btn('species:' + r, colX[0] - 2, y + fs(16) * r + 4, colX[3] - colX[0] - 6, fs(16), '', true, false); hb.silent = true; hb.species = r; hb.info = SIM.SPECIES[r].name.toLowerCase() + ': ' + SIM.SPECIES[r].note; }
    }
    if (ey > c.y + c.h + 2) state.cut = 1;
  }

  /* ---------------------------------------------------------- the bottom */
  function cellInfo(a, i) {
    var c = a.cells[i];
    if (c.k === 'gap') return 'BRAMBLE GAP · nothing grows here until a hazel beside it is LAYERED into it (' + SIM.LAYER_COST + ' funds)';
    if (c.k === 'oak') return (c.age < SIM.MATURE_OAK ? 'OAK SAPLING · ' + Math.floor(c.age) + ' years (shades and counts at ' + SIM.MATURE_OAK + ')' : 'OAK · ' + Math.floor(c.age) + ' years · shades the stools beside it · felled it would sell for ' + SIM.oakTimber(c)) + (c.mark ? ' · MARKED TO FELL' : '');
    /* review D3/D4: a stool's age is its years of GROWTH (a year a year at full vigour, slower when weak or shaded), so
     * the readout also says when it was cut, how fast it grows, and whether it counts toward IN ROTATION */
    var y = SIM.yieldOf(c), what = y.p < 0 ? 'nothing but brash' : y.q + ' ' + SIM.PRODUCTS[y.p].name;
    var since = c.cutAt > -90 ? ' (cut ' + yrs(Math.max(0, (a.t - c.cutAt) / SIM.YEAR_DAYS)) + ' years ago)' : '';
    return 'HAZEL · ' + yrs(c.age) + ' years of growth' + since + (c.age > SIM.OVERSTOOD ? ' · OVERSTOOD' : ' · in rotation') + ' · grows ' + SIM.growRate(a, i).toFixed(2) + ' a year · cut now: ' + what + (SIM.hedged(a, c) ? ' · hedged' : '') + (c.mark ? ' · marked #' + (a.queue.indexOf(i) + 1) : '');
  }
  function drawBottom() {
    var b = L().bottom, a = state.wood;
    g.fillStyle = '#131a0e'; g.fillRect(b.x, b.y, b.w, b.h);
    g.fillStyle = C.panelEdge; g.fillRect(b.x, b.y, b.w, 1);
    var tm = state.toast[0], size = fs(13), focus = state.hoverCell >= 0 ? state.hoverCell : state.cursor;
    var hb = hoverBtn && buttons.indexOf(hoverBtn) >= 0 && (hoverBtn.info || (hoverBtn.why && !hoverBtn.enabled)) ? hoverBtn : null;
    var hoverMsg = hb ? (hb.info ? cap1(hb.info) + (hb.enabled || !hb.why ? '.' : ' · ' + hb.why + '.') : cap1(hb.why) + '.') : a && state.hoverCell >= 0 ? cellInfo(a, state.hoverCell) : null;
    if (hoverMsg || !tm || state.t - tm.at > 12) {
      var bad = hb && !hb.enabled && hb.why && hb.why !== 'already done';
      var msg = hoverMsg || (a && focus >= 0 ? cellInfo(a, focus) : (shape === 'wide' ? 'MARK stools for the crew · 1-4 tools · arrows + Enter · T tabs · F speed · P pause · H help · M sound' : 'MARK stools, and the crew cuts them in autumn and winter.'));
      if (shape === 'wide') T(msg, b.x + 14, b.y + b.h / 2 + 5, tw(msg, fs(12)) > b.w - 28 ? fs(11) : fs(12), bad ? C.alarm : C.inkFaint);
      else wrapText(msg, b.x + 12, b.y + 24, b.w - 24, fs(12), bad ? C.alarm : C.inkFaint, '400', fs(12) + 5);
      return;
    }
    var col = tm.kind === 'bad' ? C.alarm : tm.kind === 'good' ? C.good : C.ink, prev = state.toast[1];
    if (shape === 'wide') {
      T(tm.msg, b.x + 14, b.y + 20, tw(tm.msg, size) > b.w - 28 ? fs(11) : size, col);
      if (prev) T(prev.msg, b.x + 14, b.y + 39, tw(prev.msg, fs(12)) > b.w - 28 ? fs(10) : fs(12), C.inkFaint);
    } else {
      var ny = wrapText(tm.msg, b.x + 12, b.y + 22, b.w - 24, size, col, '400', size + 5);
      if (prev && ny + 2 < b.y + b.h - 4 && tw(prev.msg, fs(12)) <= b.w - 24) T(prev.msg, b.x + 12, ny + 2, fs(12), C.inkFaint);
    }
  }

  /* --------------------------------------------------------- the overlays */
  function scrim(al) { g.fillStyle = 'rgba(8,10,6,' + al + ')'; g.fillRect(0, 0, W, H); }
  function drawHelp() {
    g.fillStyle = C.bg; g.fillRect(0, 0, W, H);
    var wide = shape === 'wide', x = wide ? 56 : 20, w = W - 2 * x, y = wide ? 40 : 56;
    T('HOW TO WORK A COPPICE', W / 2, y, fs(22), C.moss, 'center', '700', SERIF);
    y += 22;
    var S = wide ? 12 : fs(12), secs = [
      ['THE WOOD', 'Hazel grows back from the stump when you cut it: that is coppicing. A stool\'s age is its years of growth, a year a year at full vigour and slower when it is weak or an oak shades it. Past 16 years it is OVERSTOOD: it loses vigour, and an old weak one can collapse into bramble. IN ROTATION is the share of the wood that is hazel of 16 years or under; the upgrades open as it rises.'],
      ['THE CREW', 'MARK stools (or an oak to fell). The crew cuts them in AUTUMN and WINTER, in the order you marked them; in spring and summer they wait. What a cut gives depends on the stool\'s age: 2-4 years BEANPOLES, 5-9 HURDLE RODS, 10 and more CORDWOOD. Every cut leaves BRASH.'],
      ['THE YARD', 'Each market takes only so much a day, and each wants more in its season: beanpoles in spring, cordwood in winter. A hurdle maker weaves rods into hurdles; a clamp burns cordwood into charcoal.'],
      ['THE DEER', 'Deer browse fresh shoots in spring and summer and set them back. HEDGE a fresh stool with brash (' + SIM.HEDGE_COST + ') to guard it for ' + SIM.HEDGE_YEARS + ' years; a big coupe suffers less than a lone cut; a fence and a keeper help. LAYER a hazel rod into a bramble gap to make a new stool; plant an OAK once you have the nursery.'],
      ['THE SURVEY', 'Every spring the Trust surveys the wood and pays ' + SIM.GRANT + ' funds for each species found. BLUEBELLS want stools under 3 years, FRITILLARIES the same light the deer left alone, NIGHTINGALES a block of 3-7 year thicket, DORMICE connected healthy hazel of 8-16 years, WOODPECKERS four oaks of 20 years. Tap a species on THE SURVEY tab for its exact rule.'],
      ['THE GOAL', 'All five species in ONE survey: cut a share of the wood each winter, in blocks, so every age stands at once. The wood saves itself and keeps growing while you are away (a year at most).'],
    ];
    for (var i = 0; i < secs.length; i++) { T(secs[i][0], x, y, S, C.gold, 'left', '700'); y = wrapText(secs[i][1], x, y + S + 4, w, S, C.ink, '400', S + 4) + 2; }
    T('CONTROLS', x, y + 2, S, C.gold, 'left', '700');
    y = wrapText('Tap or click. Keys: 1 MARK · 2 HEDGE · 3 LAYER · 4 OAK · arrows move a cursor over the wood, Enter or Space act there · T the tabs · F speed · P pause · H this page · M sound · Esc close.', x, y + S + 6, w, S, C.ink, '400', S + 4);
    T('MADE BY', x, y + 4, S, C.gold, 'left', '700');
    y = wrapText('Core Systems Asset Factory. Code, text and pictures were made with AI assistance; the music and every sound are synthesised by our own code, no AI audio model.', x, y + S + 8, w, S, C.inkDim, '400', S + 4);
    btn('closehelp', W / 2 - 110, Math.min(H - 48, y + 6), 220, 38, state.wood ? 'BACK TO THE WOOD' : 'BACK');
  }
  function drawPause() {
    scrim(0.78);
    var cy = shape === 'wide' ? 250 : 420, cw = shape === 'wide' ? 420 : 400;
    g.fillStyle = C.panel; rr(W / 2 - cw / 2, cy - 58, cw, 196, 8); g.fill(); g.strokeStyle = C.panelEdge; g.lineWidth = 1; g.stroke();
    T('PAUSED', W / 2, cy, fs(40), C.moss, 'center', '700', SERIF);
    T('The wood stands still until you come back.', W / 2, cy + 34, fs(14), C.ink, 'center');
    btn('resume', W / 2 - 110, cy + 58, 220, 40, 'RESUME');
    T('P, Esc or Enter also resumes', W / 2, cy + 124, fs(12), C.inkFaint, 'center');
  }
  /* the ending: the wood in rotation, full-surface in spring, bluebells in the fresh coupes */
  function drawEnding(a) {
    g.fillStyle = C.bg; g.fillRect(0, 0, W, H);
    /* review D7: stretching the 14 x 8 wood over the 480 x 960 phone surface drew 34 x 120 px cells (stools as bands,
     * bluebells as slabs). The phone shows the player's wood with SQUARE cells, framed at the top, over the title's
     * square-celled spring wood */
    g.save();
    if (shape === 'wide') drawWoodAt(a, { x: 0, y: 0, w: W, h: H, cw: W / SIM.COLS, ch: H / SIM.ROWS }, state.t, { season: 0 });
    else { drawTitleWood(); var cs = (W - 16) / SIM.COLS, fr = { x: 8, y: 24, w: cs * SIM.COLS, h: cs * SIM.ROWS, cw: cs, ch: cs }; g.fillStyle = 'rgba(10,14,6,0.6)'; g.fillRect(fr.x - 4, fr.y - 4, fr.w + 8, fr.h + 8); g.beginPath(); g.rect(fr.x, fr.y, fr.w, fr.h); g.clip(); drawWoodAt(a, fr, state.t, { season: 0 }); }
    g.restore();
    g.fillStyle = 'rgba(10,14,6,0.35)'; g.fillRect(0, 0, W, H);
    var y = shape === 'wide' ? 150 : 380;
    g.fillStyle = 'rgba(12,16,8,0.84)'; rr(28, y - 64, W - 56, shape === 'wide' ? 260 : 360, 12); g.fill();
    g.save(); g.shadowColor = 'rgba(170,220,110,0.5)'; g.shadowBlur = 16;
    /* review D7: the title is sized to fit INSIDE its panel (it overran it by 8 px a side on a phone) */
    var ts = fs(shape === 'wide' ? 36 : 26);
    g.font = '700 ' + ts + 'px ' + SERIF; while (g.measureText('THE WOOD IS IN ROTATION').width > W - 56 - 40 && ts > 14) { ts--; g.font = '700 ' + ts + 'px ' + SERIF; }
    T('THE WOOD IS IN ROTATION', W / 2, y, ts, C.moss, 'center', '700', SERIF);
    g.restore();
    var ws = a.wonStats || { year: SIM.year(a), cut: a.stats.cut, earned: Math.round(a.stats.earned), rot: a.rot, crew: SIM.crew(a), counts: [0, 0, 0, 0, 0], collapsed: a.stats.collapsed };
    var lines = [
      'The spring survey found bluebells, fritillaries, a nightingale, dormice and a woodpecker, all in one wood. It is a working coppice again.',
      'Year ' + ws.year + ' · ' + ws.cut + ' stools cut · ' + fmt(ws.earned) + ' funds earned · ' + pct(ws.rot) + ' in rotation · a crew of ' + ws.crew,
      'Survey counts: ' + SIM.SPECIES.map(function (s, k) { return s.name.toLowerCase() + ' ' + ws.counts[k]; }).join(', ') + '.',
    ];
    var yy = y + 38;
    for (var i = 0; i < lines.length; i++) { yy = wrapCenter(lines[i], W / 2, yy, W - 80, fs(14), i === 0 ? C.ink : C.inkDim); yy += 6; }
    btn('closeending', W / 2 - 150, yy + 12, 300, 40, 'KEEP WORKING THE WOOD');
  }
  /* the title: a wood in rotation in spring, every age, drawn by the game's own renderer over the whole surface */
  var titleCells = null;
  function stagedCells(cols, rows) {
    var out = [];
    for (var i = 0; i < cols * rows; i++) {
      var x = i % cols, y = Math.floor(i / cols), band = Math.floor((x + Math.floor(y / 3) * 2) / 3) % 5;
      var v = hash(x * 31 + y * 17 + 5);
      if (v < 0.07) out.push({ k: 'gap' });
      else if (v > 0.93) out.push({ k: 'oak', age: 40 + 30 * hash(i) });
      else out.push({ k: 'hazel', age: [0.8, 2.4, 5, 9, 13][band] + hash(i * 3) * 1.2, vig: 0.95, hedge: 0 });
    }
    return out;
  }
  function drawTitleWood() {
    var wide = shape === 'wide', cols = wide ? 24 : 12, rows = wide ? 15 : 24, cw = W / cols, ch = H / rows;
    if (!titleCells || titleCells.length !== cols * rows) titleCells = stagedCells(cols, rows);
    var r = { x: 0, y: 0, w: W, h: H, cw: cw, ch: ch };
    drawWoodAt(null, r, state.t, { cols: cols, rows: rows, cells: titleCells, season: 0 });
    var wg = g.createLinearGradient(0, 0, 0, H); wg.addColorStop(0, 'rgba(255,240,190,0.10)'); wg.addColorStop(1, 'rgba(10,18,6,0.35)');
    g.fillStyle = wg; g.fillRect(0, 0, W, H);
  }
  function drawTitle() {
    drawTitleWood();
    var wide = shape === 'wide', cy = wide ? 150 : 250;
    g.fillStyle = 'rgba(12,16,8,0.72)'; rr(W / 2 - (wide ? 330 : 220), cy - (wide ? 92 : 80), wide ? 660 : 440, wide ? 390 : 470, 12); g.fill();
    g.save(); g.shadowColor = 'rgba(170,220,110,0.5)'; g.shadowBlur = 18;
    T('COPPICE', W / 2, cy, wide ? 78 : 56, C.moss, 'center', '700', SERIF);
    g.restore();
    T('Cut the wood. It grows back.', W / 2, cy + 38, fs(18), C.ink, 'center', '400', SERIF);
    var sy = wrapCenter('A woodland incremental: bring a neglected hazel wood back into rotation, sell what each age gives, and keep a patchwork of light and shade the wildlife needs.', W / 2, cy + 64, wide ? 560 : W - 80, fs(wide ? 13 : 12), C.inkDim);
    var has = hasSave(), bw = 260, bx = W / 2 - bw / 2, by = sy + 8;
    btn('start', bx, by, bw, 42, has ? 'CONTINUE' : 'TAKE ON THE WOOD', true, false);
    var armed = state.t < state.confirmNewUntil;
    /* review D19: with no save, NEW WOOD did exactly what TAKE ON THE WOOD does; it shows only when there is a wood to
     * replace */
    if (has) btn('fresh', bx, by + 50, bw, 36, armed ? 'PRESS AGAIN TO ERASE' : 'NEW WOOD', true, armed);
    btn('help', bx, by + (has ? 94 : 50), bw, 36, 'HOW TO PLAY');
    if (armed) T('A new wood erases your saved one.', W / 2, by + 150, fs(12), C.alarm, 'center');
    g.fillStyle = 'rgba(10,12,6,0.85)'; g.fillRect(0, H - 30, W, 30);
    T('Free · saves in your browser · by Core Systems Asset Factory', W / 2, H - 11, fs(11), C.inkDim, 'center');
  }

  function render() {
    buttons = []; state.cut = 0;
    g.setTransform(1, 0, 0, 1, 0, 0);
    g.fillStyle = C.bg; g.fillRect(0, 0, W, H);
    if (state.screen === 'title') { drawTitle(); if (state.help) { buttons = []; drawHelp(); } drawButtons(); return; }
    var a = state.wood;
    drawWood(a);
    drawTop(a);
    drawCrewPanel(a);
    var c = panelFrame();
    if (state.tab === 'upgrades') drawUpgrades(a, c); else if (state.tab === 'yard') drawYard(a, c); else drawSurvey(a, c);
    drawBottom();
    /* the play screen's controls are drawn BEFORE any overlay, so a veil lies over a whole screen rather than over
     * empty panels */
    drawButtons();
    if (state.help) { buttons = []; drawHelp(); drawButtons(); return; }
    if (a.won && !a.endingSeen) { buttons = []; drawEnding(a); drawButtons(); return; }
    if (state.userPaused) { buttons = []; drawPause(); drawButtons(); return; }
  }

  /* ------------------------------------------------------------------ tick */
  function productWord(p, q) { var P = SIM.PRODUCTS[p]; return q + ' ' + (q === 1 ? P.unit : P.unit + 's') + ' of ' + P.name.toLowerCase(); }
  function tick(dt) {
    state.t += dt;
    toastTick();
    var a = state.wood;
    if (state.screen !== 'play' || !a || state.help || state.userPaused || (a.won && !a.endingSeen)) return;
    SIM.step(a, dt * state.speed / SIM.DAY_SEC);
    if (a.stats.cut > state.cutsSeen) {
      state.cutsSeen = a.stats.cut;
      var lc = a.lastCut;
      /* a good cut is reported in THE CREW panel (see drawCrewPanel); only a mistake reaches the message bar */
      if (lc) { state.chips.push({ i: lc.i, at: state.t }); AUDIO.chop(); if (lc.p < 0) toast('The crew cut a stool too young: nothing but brash, and the stool is weakened.', 'bad'); }
    }
    for (var ei = 0; ei < a.events.length; ei++) {
      var e = a.events[ei];
      if (!(e.seq > state.eventsSeen)) continue;
      state.eventsSeen = e.seq;
      if (e.kind === 'browse') { note(e.msg, 'bad'); AUDIO.browse(); }
      else if (e.kind === 'season') { note(e.msg, e.collapsed ? 'bad' : 'info'); if (e.collapsed) AUDIO.collapse(); else AUDIO.season(); save(); }
      else if (e.kind === 'unlock') { note(e.msg, 'good'); AUDIO.chime(); }
      else if (e.kind === 'survey') { note(e.msg, e.n ? 'good' : 'info'); AUDIO.birds(); save(); }
      else if (e.kind === 'woodward') { note(e.msg, 'info'); AUDIO.mark(); save(); }
      else if (e.kind === 'burn') { note(e.msg, 'good'); AUDIO.burn(); }
      else if (e.kind === 'fell') { note(e.msg, 'good'); AUDIO.fell(); save(); }
      else if (e.kind === 'win') { AUDIO.fanfare(); save(); }
    }
    if (Date.now() - state.lastSaveReal > 5000) { state.lastSaveReal = Date.now(); save(); }
  }

  /* ----------------------------------------------------------------- input */
  var actedThisFrame = false;
  function toSurface(ev) {
    var r = cv.getBoundingClientRect();
    return { x: (ev.clientX - r.left) * (W / r.width), y: (ev.clientY - r.top) * (H / r.height) };
  }
  function btnAt(x, y) { for (var i = buttons.length - 1; i >= 0; i--) { var b = buttons[i]; if (x >= b.x && x < b.x + b.w && y >= b.y && y < b.y + b.h) return b; } return null; }
  function overlayUp() { var a = state.wood; return state.screen !== 'play' || !a || state.help || state.userPaused || (a.won && !a.endingSeen); }
  cv.addEventListener('pointerdown', function (ev) {
    try { window.focus(); } catch (e) { /* cross-origin parent */ }
    try { cv.focus({ preventScroll: true }); } catch (e) { /* old browser */ }
    AUDIO.unlock();
    if (ev.button !== undefined && ev.button !== 0) return;
    var p = toSurface(ev);
    if (actedThisFrame) return;
    var b = btnAt(p.x, p.y), touch = ev.pointerType === 'touch';
    /* a silent info target (a species row, the IN ROTATION figure) answers a tap with its rule: a phone has no hover
     * (review D1) */
    if (b && b.silent) { if (b.info) { actedThisFrame = true; toast(cap1(b.info) + '.', 'info'); AUDIO.tick(); } return; }
    /* on touch the first tap on an upgrade EXPLAINS it and a second buys it (review D1: the first tap used to buy
     * before the player could read what it did) */
    if (b && touch && b.id.indexOf('buy:') === 0 && b.info && (state.armed !== b.id || state.t - state.armedAt > 8)) {
      actedThisFrame = true; state.armed = b.id; state.armedAt = state.t; AUDIO.tick();
      toast(cap1(b.info) + (b.enabled ? '. Tap again to buy it for ' + b.sub + '.' : b.why && b.why !== 'already done' ? '. ' + cap1(b.why) + '.' : '.'), b.enabled || b.why === 'already done' ? 'info' : 'bad');
      return;
    }
    state.armed = null;
    if (b && b.enabled) { actedThisFrame = true; doButton(b); return; }
    if (b && b.why) { actedThisFrame = true; toast(cap1(b.why) + '.', 'bad'); AUDIO.tick(); return; }
    if (!overlayUp()) { var i = cellAt(p.x, p.y); if (i >= 0) { actedThisFrame = true; state.cursor = -1; actOnCell(i); } }
  });
  cv.addEventListener('pointermove', function (ev) { var p = toSurface(ev); hoverBtn = btnAt(p.x, p.y); state.hoverCell = overlayUp() || ev.pointerType === 'touch' ? -1 : cellAt(p.x, p.y); });
  cv.addEventListener('pointerleave', function () { hoverBtn = null; state.hoverCell = -1; });
  cv.addEventListener('contextmenu', function (ev) { ev.preventDefault(); });

  function actOnCell(i) {
    var a = state.wood, c = a.cells[i], w;
    if (state.tool === 'mark') {
      var was = c.mark;
      w = SIM.mark(a, i);
      if (!w) {
        AUDIO.mark(); save();
        if (was) toast('Unmarked. ' + cellInfo(a, i), 'info');
        else if (c.k === 'oak') toast('An oak of ' + Math.floor(c.age) + ' years is marked to fell (' + SIM.oakTimber(c) + ' funds). The woodpecker needs four grown oaks: tap it again to spare it.', 'bad');
        else toast('Marked #' + a.queue.length + '. ' + (SIM.yieldOf(c).p < 0 ? 'Under 2 years it gives nothing but brash and weakens the stool.' : 'Cut now it gives ' + productWord(SIM.yieldOf(c).p, SIM.yieldOf(c).q) + '.') + (SIM.cuttingSeason(a) ? '' : ' The crew starts in autumn.'), SIM.yieldOf(c) && SIM.yieldOf(c).p < 0 ? 'bad' : 'good');
        return;
      }
    } else if (state.tool === 'hedge') {
      w = SIM.hedge(a, i);
      if (!w) { AUDIO.hedge(); state.splash.push({ i: i, at: state.t }); toast('A dead hedge of brash rings the stool: the deer cannot reach it for ' + SIM.HEDGE_YEARS + ' years.', 'good'); save(); return; }
    } else if (state.tool === 'layer') {
      w = SIM.layer(a, i);
      if (!w) { AUDIO.layer(); state.splash.push({ i: i, at: state.t }); toast('A hazel rod is bent down and pegged into the gap. It will root into a new stool.', 'good'); save(); return; }
    } else {
      w = SIM.plantOak(a, i);
      if (!w) { AUDIO.layer(); state.splash.push({ i: i, at: state.t }); toast('An oak sapling is planted. In ' + SIM.MATURE_OAK + ' years it will shade and count for the woodpecker.', 'good'); save(); return; }
    }
    toast(cap1(w) + '.', 'bad'); AUDIO.tick();
  }

  window.addEventListener('keydown', function (ev) {
    var k = ev.key, primary = k === 'Enter' || k === ' ';
    AUDIO.unlock();
    if (state.help) { if (k === 'Escape' || primary || k === 'h' || k === 'H' || k === '?') closeHelp(); else if (k === 'm' || k === 'M') AUDIO.toggleMute(); return; }
    if (k === 'm' || k === 'M') { AUDIO.toggleMute(); return; }
    if (state.screen === 'title') { if (primary) doButton({ id: 'start' }); else if (k === 'h' || k === 'H' || k === '?') state.help = true; return; }
    if (state.screen !== 'play' || !state.wood) return;
    if (state.wood.won && !state.wood.endingSeen) { if (k === 'Escape' || primary) doButton({ id: 'closeending' }); return; }
    if (state.userPaused) { if (k === 'p' || k === 'P' || k === 'Escape' || primary) { state.userPaused = false; save(); AUDIO.tick(); } return; }
    if (k === 'p' || k === 'P') { state.userPaused = true; save(); AUDIO.tick(); return; }
    if (k === 'h' || k === 'H' || k === '?') { state.help = true; return; }
    if (/^[1-4]$/.test(k)) { var tl = TOOLS[+k - 1][0]; doButton({ id: 'tool:' + tl }); return; }
    if (k === 't' || k === 'T') { var ti = 0; for (var q = 0; q < TABS.length; q++) if (TABS[q][0] === state.tab) ti = q; state.tab = TABS[(ti + 1) % TABS.length][0]; AUDIO.tick(); return; }
    if (k === 'f' || k === 'F') { state.speed = state.speed > 1 ? 1 : 3; AUDIO.tick(); return; }
    if (k === 'Escape') { state.cursor = -1; return; }
    var mv = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[k];
    if (mv) {
      /* the arrows drive the wood cursor; only they are held back from scrolling the page */
      ev.preventDefault();
      var cur = state.cursor < 0 ? Math.floor(SIM.ROWS / 2) * SIM.COLS + Math.floor(SIM.COLS / 2) : state.cursor;
      var x = Math.max(0, Math.min(SIM.COLS - 1, SIM.cx(cur) + (state.cursor < 0 ? 0 : mv[0]))), y = Math.max(0, Math.min(SIM.ROWS - 1, SIM.cy(cur) + (state.cursor < 0 ? 0 : mv[1])));
      state.cursor = y * SIM.COLS + x; return;
    }
    if (primary) { if (state.cursor < 0) { state.cursor = Math.floor(SIM.ROWS / 2) * SIM.COLS + Math.floor(SIM.COLS / 2); return; } actOnCell(state.cursor); }
  });

  function startPlay(a, fromSave) {
    state.wood = a; state.screen = 'play'; state.tab = 'upgrades'; state.eventsSeen = a.seq || 0; state.cutsSeen = a.stats.cut; state.tool = 'mark'; state.cursor = -1;
    state.help = !fromSave;
    save();
  }
  function closeHelp() {
    state.help = false;
    if (state.pendingToast) { toast(state.pendingToast.msg, state.pendingToast.kind); state.pendingToast = null; }
  }
  function awayReport(a, days, seq0, cut0) {
    state.eventsSeen = a.seq || 0; state.cutsSeen = a.stats.cut;
    var nd = Math.floor(days), survey = null, collapsed = 0, browsed = 0, won = false;
    for (var i = 0; i < a.events.length; i++) {
      var e = a.events[i]; if (!(e.seq > (seq0 || 0))) continue;
      if (e.kind === 'survey') survey = e.msg; else if (e.kind === 'browse') browsed += e.n || 0; else if (e.kind === 'season') collapsed += e.collapsed || 0; else if (e.kind === 'win') won = true;
    }
    if (days < 1) { toast('Welcome back to the wood.', 'good'); return; }
    var parts = [], cut = a.stats.cut - (cut0 || 0);
    if (cut) parts.push('the crew cut ' + cut + (cut === 1 ? ' stool' : ' stools'));
    if (browsed) parts.push('deer browsed ' + browsed);
    if (collapsed) parts.push(collapsed + (collapsed === 1 ? ' old stool' : ' old stools') + ' collapsed');
    if (survey) toast(survey, 'good');
    toast('While you were away, ' + nd + (nd === 1 ? ' day' : ' days') + ' passed' + (parts.length ? ': ' + parts.join(', ') : '') + '. The wood is ' + pct(a.rot) + ' in rotation.', collapsed ? 'bad' : 'good');
  }
  function doButton(b) {
    var a = state.wood;
    if (b.id === 'start') {
      var d = load(), away = 0, seq0 = 0, cut0 = 0;
      if (d && !d.paused) { seq0 = d.wood.seq || 0; cut0 = d.wood.stats.cut; try { away = catchUp(d.wood, (Date.now() - (d.savedAt || Date.now())) / 1000); } catch (e) { d = null; } }
      /* review D22: userPaused is set BEFORE startPlay saves, so the stored flag never reads false while the pause
       * card is up */
      if (d && d.paused) { state.userPaused = true; startPlay(d.wood, true); state.eventsSeen = d.wood.seq || 0; toast('The wood waited where you paused it. Nothing grew while you were away.', 'good'); }
      else if (d) { startPlay(d.wood, true); awayReport(d.wood, away, seq0, cut0); }
      else {
        /* a save that fails validation is KEPT ASIDE under its own key and the player is told, never silently overwritten */
        var unreadable = hasSave();
        if (unreadable) { try { localStorage.setItem(SAVE_KEY + '.unreadable', localStorage.getItem(SAVE_KEY)); } catch (e) { /* storage refused */ } }
        startPlay(SIM.newWood(), false);
        state.pendingToast = state.pendingToast && /could not be read/.test(state.pendingToast.msg) ? state.pendingToast : unreadable ? { msg: 'Your saved wood could not be read. It was kept aside, and a new wood begins.', kind: 'bad' }
          : { msg: 'It is autumn: the cutting season. MARK a few overstood stools for your woodsman.', kind: 'good' };
      }
      AUDIO.tick(); return;
    }
    if (b.id === 'fresh') {
      if (!hasSave()) { doButton({ id: 'start' }); return; }
      if (!(state.t < state.confirmNewUntil)) { state.confirmNewUntil = state.t + 4; return; }
      state.confirmNewUntil = 0; startPlay(SIM.newWood(1709 + Math.floor(Math.random() * 9000)), false); state.pendingToast = { msg: 'A new wood. It is autumn: MARK some overstood stools.', kind: 'good' }; return;
    }
    if (b.id === 'closehelp') { closeHelp(); return; }
    if (b.id === 'closeending') { a.endingSeen = true; save(); AUDIO.tick(); return; }
    if (b.id === 'help') { state.help = true; return; }
    if (b.id === 'mute') { AUDIO.toggleMute(); return; }
    if (b.id === 'speed') { state.speed = state.speed > 1 ? 1 : 3; AUDIO.tick(); return; }
    if (b.id === 'pause') { state.userPaused = true; save(); AUDIO.tick(); return; }
    if (b.id === 'resume') { state.userPaused = false; save(); AUDIO.tick(); return; }
    if (b.id.indexOf('tab:') === 0) { state.tab = b.id.slice(4); AUDIO.tick(); return; }
    if (!a) return;
    if (b.id.indexOf('tool:') === 0) {
      var tl = b.id.slice(5);
      if (tl === 'oak' && !a.levels.oaks) { toast('The oak nursery is on the UPGRADES tab.', 'bad'); AUDIO.tick(); return; }
      state.tool = tl; AUDIO.tick();
      toast({ mark: 'MARK: tap a stool (or an oak) for the crew to cut in autumn and winter. Tap again to unmark.', hedge: 'HEDGE: ring a fresh stool with brash (' + SIM.HEDGE_COST + ') so the deer cannot browse it.', layer: 'LAYER: peg a hazel rod into a bramble gap beside it to root a new stool (' + SIM.LAYER_COST + ' funds).', oak: 'OAK: plant a sapling in a gap or on a fresh cut (' + SIM.OAK_COST + ' funds).' }[tl], 'info');
      return;
    }
    if (b.id === 'clearmarks') { var nq = a.queue.slice(); for (var qi = 0; qi < nq.length; qi++) SIM.mark(a, nq[qi]); toast('All marks cleared.', 'info'); AUDIO.tick(); save(); return; }
    var mr = /^rot:(\d+)$/.exec(b.id);
    if (mr) { SIM.setRotation(a, +mr[1]); toast('The woodward will cut on a ' + mr[1] + '-year rotation: a coupe of about ' + SIM.coupeSize(a) + ' each autumn.', 'good'); AUDIO.tick(); save(); return; }
    var mt = /^toggle:(\w+)$/.exec(b.id);
    if (mt) { SIM.toggle(a, mt[1]); toast((mt[1] === 'hurdles' ? 'The hurdle maker ' : 'The ' + (a.levels.kiln ? 'kiln ' : 'clamp ')) + (a.toggles[mt[1]] ? 'is working.' : 'is stopped: the carter sells the ' + (mt[1] === 'hurdles' ? 'rods' : 'cordwood') + ' as they are.'), 'info'); AUDIO.tick(); save(); return; }
    if (b.id.indexOf('buy:') === 0) {
      var key = b.id.slice(4), res = SIM.buy(a, key);
      if (res) toast(cap1(res) + '.', 'bad');
      else { toast(cap1(UPGRADE_INFO[key]) + '.', 'good'); if (key === 'woodsman' || key === 'billhook') AUDIO.chop(); else AUDIO.coin(); save(); }
      return;
    }
  }

  /* ---------------------------------------------------------------- shape */
  function pickShape() { setShape((window.innerWidth / Math.max(1, window.innerHeight)) < 1 ? 'tall' : 'wide'); }
  function setShape(s) {
    if (!SHAPES[s]) return;
    shape = s; W = SHAPES[s].W; H = SHAPES[s].H;
    if (cv.width !== W) cv.width = W;
    if (cv.height !== H) cv.height = H;
    document.documentElement.style.setProperty('--ar', String(W / H));
  }
  window.addEventListener('resize', pickShape);
  pickShape();

  /* ------------------------------------------------------------------ loop */
  var last = 0, paused = false;
  function frame(ts) {
    requestAnimationFrame(frame);
    if (!last) last = ts;
    var dt = Math.min(0.1, (ts - last) / 1000);
    last = ts;
    if (!paused) { try { tick(dt); actedThisFrame = false; render(); } catch (e) { rescue(e); } }
  }
  /* review D21: an exception inside the loop used to repeat every frame over a frozen screen. The wood that caused it
   * is kept aside under its own key, the game returns to the title, and the player is told on the next start. The
   * error is RE-THROWN once, asynchronously, so every test harness still sees it as a page error. */
  function rescue(e) {
    if (state.rescued) return;
    state.rescued = true;
    try { var raw = localStorage.getItem(SAVE_KEY); if (raw) { localStorage.setItem(SAVE_KEY + '.unreadable', raw); localStorage.removeItem(SAVE_KEY); } } catch (x) { /* storage blocked */ }
    state.wood = null; state.screen = 'title'; state.help = false; state.userPaused = false; buttons = [];
    state.pendingToast = { msg: 'Something in your saved wood could not be read. It was kept aside, and a new wood begins.', kind: 'bad' };
    setTimeout(function () { state.rescued = false; throw e; }, 0);
  }
  requestAnimationFrame(frame);
  /* rAF stops in a hidden tab: back from hidden, the wood catches up exactly as CONTINUE does (up to a year) */
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) { state.hiddenAt = Date.now(); save(); return; }
    var a = state.wood, at = state.hiddenAt; state.hiddenAt = 0;
    if (!at || state.screen !== 'play' || !a || (a.won && !a.endingSeen) || state.help || state.userPaused) return;
    var secs = (Date.now() - at) / 1000;
    if (secs < 8) return;
    var seq0 = a.seq || 0, cut0 = a.stats.cut;
    awayReport(a, catchUp(a, secs), seq0, cut0);
    save();
  });

  window.COPPICE = {
    state: state, sim: SIM,
    isReady: function () { return state.t > 0; },
    platesReady: function () { return platesReady; },
    buttons: function () { return buttons.slice(); },
    findButton: function (id) { for (var i = 0; i < buttons.length; i++) if (buttons[i].id === id) return buttons[i]; return null; },
    shape: function () { return { shape: shape, W: W, H: H }; },
    setShape: setShape,
    setPaused: function (p) { paused = !!p; },
    advance: function (sec) { var n = Math.max(1, Math.ceil(sec / 0.05)); for (var i = 0; i < n; i++) tick(sec / n); actedThisFrame = false; render(); },
    newWood: function (seed) { startPlay(SIM.newWood(seed), true); },
    cellRect: cellRect, cellAt: cellAt,
    render: render,
    /* the wood itself over the whole surface, no interface (capture only; players never see it) */
    renderWood: function (season) {
      var a = state.wood; if (!a) return;
      buttons = []; g.setTransform(1, 0, 0, 1, 0, 0); g.fillStyle = C.bg; g.fillRect(0, 0, W, H);
      var r = { x: 0, y: 0, w: W, h: H, cw: W / SIM.COLS, ch: H / SIM.ROWS };
      drawWoodAt(a, r, state.t, { season: season === undefined ? SIM.season(a) : season });
    },
    /* the store cover: the title's wood under the name, no buttons (capture only; players never see it) */
    renderCover: function (cx, ty) {
      cx = cx || W / 2; ty = ty || 200;
      buttons = []; g.setTransform(1, 0, 0, 1, 0, 0); g.fillStyle = C.bg; g.fillRect(0, 0, W, H);
      drawTitleWood(); g.fillStyle = 'rgba(10,14,6,0.25)'; g.fillRect(0, 0, W, H);
      g.fillStyle = 'rgba(12,16,8,0.55)'; rr(cx - 300, ty - 90, 600, 150, 14); g.fill();
      g.save(); g.shadowColor = 'rgba(170,220,110,0.55)'; g.shadowBlur = 22; T('COPPICE', cx, ty, 80, C.moss, 'center', '700', SERIF); g.restore();
      T('Cut the wood. It grows back.', cx, ty + 42, 22, C.ink, 'center', '400', SERIF);
    },
  };
})();
