/**
 * audio.js - COPPICE's sound: effects synthesised live with WebAudio, plus one composed music loop
 * (audio/coppice_theme.ogg). Effects: a soft tick for a tab, a chalk scrape for a mark, an axe on hazel when the
 * crew finishes a cut, a rustle of brash for a hedge, a soft thud of earth for a layer or a sapling, coins, a chime
 * for something unlocked, a short birdsong for the spring survey, a snort for browsing deer, a creak and crash when
 * an old stool collapses, a whoosh when the charcoal is drawn, a long crack and fall for an oak, two tones for a
 * season and a rising cadence when the wood is in rotation. Muting is remembered, and PAUSES the music (iPhone
 * Safari ignores a media element's volume).
 */
'use strict';

var AUDIO = (function () {
  /* review D20: at 1.0 the survey birdsong measured -37.5 dBFS rms under a -28.4 dBFS music bed, with the loudest cue
   * peaking at -14.4 dBFS: 14 dB unused. The bus is 1.8 (measure_sfx.js checks no cue clips), and the music DUCKS
   * under the two cues that carry news (the survey and the win) */
  var ctx = null, master = null, muted = false, noiseBuf = null, BUS = 1.8, MUSIC_VOL = 0.3, duckUntil = 0;
  function duck(sec) {
    if (!music) return;
    music.volume = 0.1; duckUntil = Date.now() + sec * 1000;
    setTimeout(function () { if (Date.now() >= duckUntil - 20 && music) music.volume = MUSIC_VOL; }, sec * 1000);
  }
  try { muted = localStorage.getItem('coppice.muted') === '1'; } catch (e) { /* storage blocked */ }

  var music = null;
  function playMusic() {
    if (!music || muted || document.hidden || !music.paused) return;
    var pr = music.play(); if (pr && pr.catch) pr.catch(function () { /* autoplay refused: the next tap retries */ });
  }
  function startMusic() {
    if (music) { playMusic(); return; }
    try { music = new Audio('audio/coppice_theme.ogg'); music.loop = true; music.volume = MUSIC_VOL; playMusic(); } catch (e) { music = null; }
  }
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) { if (music) music.pause(); if (ctx && ctx.state === 'running') ctx.suspend(); }
    else { playMusic(); if (ctx && ctx.state === 'suspended') ctx.resume(); }
  });
  function unlock() {
    startMusic();
    if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    try {
      ctx = new AC();
      master = ctx.createGain(); master.gain.value = muted ? 0 : BUS; master.connect(ctx.destination);
      /* one second of fixed noise for the brush, the axe and the fall (fixed, so each cue sounds the same) */
      noiseBuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
      var d = noiseBuf.getChannelData(0), s = 24681;
      for (var i = 0; i < d.length; i++) { s = (s * 1103515245 + 12345) & 0x7fffffff; d[i] = (s / 0x7fffffff) * 2 - 1; }
    } catch (e) { ctx = null; }
  }
  function tone(freq, dur, type, vol, slide, delay) {
    if (!ctx || muted) return;
    var t = ctx.currentTime + (delay || 0);
    var o = ctx.createOscillator(), gn = ctx.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(freq, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, freq * slide), t + dur);
    gn.gain.setValueAtTime(0.0001, t); gn.gain.exponentialRampToValueAtTime(vol || 0.2, t + 0.01); gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(gn); gn.connect(master); o.start(t); o.stop(t + dur + 0.02);
  }
  function noise(dur, freq, q, vol, sweep, delay, type) {
    if (!ctx || muted || !noiseBuf) return;
    var t = ctx.currentTime + (delay || 0);
    var src = ctx.createBufferSource(); src.buffer = noiseBuf;
    var f = ctx.createBiquadFilter(); f.type = type || 'bandpass'; f.frequency.setValueAtTime(freq, t); f.Q.value = q || 1;
    if (sweep) f.frequency.exponentialRampToValueAtTime(freq * sweep, t + dur);
    var gn = ctx.createGain(); gn.gain.setValueAtTime(0.0001, t); gn.gain.exponentialRampToValueAtTime(vol || 0.2, t + 0.02); gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f); f.connect(gn); gn.connect(master); src.start(t); src.stop(t + dur + 0.05);
  }

  /* the whole API is the list of cues; SFX_CUES is read by the offline measurer so it cannot miss a new one */
  var API = {
    tick: function () { tone(880, 0.05, 'triangle', 0.06); },
    mark: function () { noise(0.14, 3400, 2.5, 0.22, 0.7); tone(1200, 0.05, 'triangle', 0.03, 0.8, 0.02); },
    /* an axe into green hazel: a knock and a short woody ring, twice */
    chop: function () { tone(190, 0.12, 'triangle', 0.16, 0.6); noise(0.06, 1400, 2, 0.3, 0.6); tone(170, 0.1, 'triangle', 0.12, 0.6, 0.16); noise(0.05, 1200, 2, 0.24, 0.6, 0.16); },
    hedge: function () { noise(0.18, 1800, 0.9, 0.3, 0.7); noise(0.16, 2400, 0.9, 0.24, 0.8, 0.16); noise(0.14, 1500, 0.9, 0.2, 0.9, 0.3); },
    layer: function () { tone(110, 0.22, 'sine', 0.2, 0.7); noise(0.16, 500, 1, 0.2, 0.6, 0.02, 'lowpass'); },
    coin: function () { tone(1320, 0.09, 'square', 0.05); tone(1760, 0.18, 'square', 0.045, 1, 0.07); },
    chime: function () { tone(784, 0.35, 'sine', 0.12); tone(1175, 0.45, 'sine', 0.09, 1, 0.09); },
    /* a woodland bird: a run of quick rising whistles and a trill */
    birds: function () { duck(1.6); var n = [2600, 3100, 2800, 3500, 3300, 3900]; for (var i = 0; i < n.length; i++) tone(n[i], 0.09, 'sine', 0.05, 1.18, i * 0.09); for (var j = 0; j < 5; j++) tone(3000, 0.04, 'sine', 0.04, 1.4, 0.62 + j * 0.05); },
    browse: function () { noise(0.22, 700, 1.5, 0.18, 1.6); tone(240, 0.18, 'sawtooth', 0.03, 0.8, 0.05); },
    collapse: function () { tone(140, 0.6, 'sawtooth', 0.05, 0.6); noise(0.9, 800, 0.8, 0.25, 0.3, 0.35, 'lowpass'); },
    season: function () { tone(392, 0.3, 'sine', 0.07); tone(494, 0.4, 'sine', 0.06, 1, 0.14); },
    burn: function () { noise(1.0, 400, 0.7, 0.24, 2.2, 0, 'lowpass'); noise(0.6, 2200, 0.6, 0.06, 0.5, 0.2); },
    fell: function () { tone(120, 0.9, 'sawtooth', 0.05, 0.5); noise(0.4, 2000, 1, 0.2, 0.3); noise(1.2, 300, 0.7, 0.35, 0.5, 0.7, 'lowpass'); },
    fanfare: function () { duck(2.2); var n = [392, 494, 587, 784, 988]; for (var i = 0; i < n.length; i++) tone(n[i], 0.6, 'triangle', 0.1, 1, i * 0.17); },
  };
  var SFX_CUES = Object.keys(API);
  API.unlock = unlock;
  API.SFX_CUES = SFX_CUES;
  API.toggleMute = function () {
    muted = !muted;
    try { localStorage.setItem('coppice.muted', muted ? '1' : '0'); } catch (e) { /* storage blocked */ }
    if (master) master.gain.value = muted ? 0 : BUS;
    if (music) { if (muted) music.pause(); else playMusic(); }
    return muted;
  };
  API.muted = function () { return muted; };
  API.musicPlaying = function () { return !!music && !music.paused; };
  return API;
})();
