# COPPICE

Cut the wood. It grows back.

Free, plays in the browser, nothing to install and no account needed.

## The wood

A hazel wood nobody has cut in twenty years. Hazel grows back from the stump when you cut it, and for centuries
this wood was cut a patch at a time and never cleared. Now most stools are **overstood**: past 16 years, choking
on their own poles, losing vigour, and an old weak one can collapse into bramble. A few old oaks stand over it
all, and the last woodman's final coupe, four stools cut four years ago, is still coming up.

## The one rule

**A stool's age when it is cut decides what it gives.**

| age at the cut | what the crew brings to the yard |
| --- | --- |
| under 2 years | nothing but brash, and the stool is weakened |
| 2 to 4 years | BEANPOLES |
| 5 to 9 years | HURDLE RODS |
| 10 years and more | CORDWOOD |
| overstood (past 16) | coarse cordwood, less for its years |

Every cut also leaves **brash**, and the stool grows again from the stump.

A stool's age is its **years of growth**: a year a year at full vigour, slower when it is weak or a grown oak shades
it. A newly cut overstood stool starts weak and grows slowly until its vigour comes back. Hover a stool to see its
age, when it was cut and how fast it grows (on a phone, MARK it and tap it again: the unmark message reads it out).

## How to work it

- **MARK** a stool (or an oak you mean to fell). The crew cuts what is marked in **autumn and winter**, in the
  order you marked it. In spring and summer they wait. Tap a mark again to take it off.
- **HEDGE** rings a fresh stool with brash (6) so the deer cannot browse it for 3 years.
- **LAYER** bends a hazel rod down into a bramble gap beside it to root a new stool (the hazel must be 3 years
  or older).
- **OAK** plants a sapling in a gap or on a fresh cut, once you have the oak nursery. A grown oak shades the
  stools beside it, and in 20 years it counts for the woodpecker.

## The yard

Each market takes only so much a day, and each wants more in its own season: the gardens want beanpoles in
spring, the villages want cordwood for the winter, shepherds want hurdles for lambing. Whatever the market does
not take waits in the yard, so a wood cut all at one age floods one market while the others go without. A
**hurdle maker** weaves five rods into a hurdle; a **charcoal clamp** (and later an iron ring kiln) burns the
cordwood the market cannot take into charcoal for the forge.

## The deer

Deer browse fresh shoots in spring and summer and set them back. A big coupe suffers less than a lone cut. A dead
hedge, a deer fence and a keeper all help.

## The survey

Every spring the Trust walks the wood and pays 10 funds for each of five species it finds:

- **BLUEBELLS** want fresh light: 10 stools under 3 years old (fresh cuts or layered rods).
- **FRITILLARIES** (a butterfly) want fresh clearings the deer left alone: 5 stools under 2 years, each beside
  another.
- **NIGHTINGALES** sing from dense thicket: 6 stools of 3 to 7 years, each with 2 neighbours of that age.
- **DORMICE** eat hazelnuts and never touch the ground: 8 healthy stools (vigour 60% or more) of 8 to 16 years, each
  beside another stool of 8 years or more or an oak of 20 years or more. THE SURVEY tab forecasts how long your
  nearest healthy stool needs to reach 8.
- **WOODPECKERS** drum on old oak: 4 oaks of 20 years or more.

**The goal is all five in one survey.** No single age of hazel holds them all. Only a wood cut in rotation, a
share each winter and in blocks, so that every age stands at once, can.

## Upgrades

More woodsmen and better billhooks cut more each winter; a carter's round reaches more villages; the hurdle
maker, the clamp and the ring kiln turn cheap wood into dear; an oak nursery, a deer fence and a keeper; a
**woodward** who marks up to one coupe each autumn, the oldest stools first, on the rotation you choose (10, 12, 14
or 16 years; dormice need hazel of 8 to 16, so a longer rotation leaves more of it standing); and walkers who pay
every day for each species the last survey found. They open up as more of the wood comes back into rotation: **IN
ROTATION** is the share of the wood's ground (stools and bramble gaps) that is hazel of 16 years or under, so a stool
counts the moment it is cut or layered.

## Saving

The wood saves itself as you go. While you are away it keeps growing, the crew keeps cutting and the carter keeps
selling, up to one year. Pause it and it waits exactly where you left it.

## Controls

Tap or click. On a phone, tap an upgrade once to read what it does and again to buy it, and tap a species on THE
SURVEY tab to read its rule. Keys: **1** mark, **2** hedge, **3** layer, **4** oak, arrows move a cursor over the wood and
**Enter** or **Space** acts there, **T** the tabs, **F** speed, **P** pause, **H** help, **M** sound, **Esc**
close. The game never takes the Tab key.

## Made by

Core Systems Asset Factory. Code, text and pictures were made with AI assistance; the music and every sound are
synthesised by our own code, with no generative audio model. See CREDITS.txt and LICENSE.txt.
