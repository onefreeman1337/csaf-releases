/**
 * content.js — ROOTWORK, the FREE EDITION's content: the first ten soils.
 * ⛔ wing §1-DEMO: the other thirty soil SPECS and the ending live in content_full.js, which the free
 *    index.html has no <script> tag for and the free package does not contain.
 * A spec is { id, seed, name, form }; soil.js turns `seed` into the soil. `seed` is the SCREENED soil index
 * (Internal_Ops/screen.js, _screen_rows.json), so every number in the candidate screen describes these soils.
 * The ten were picked as a ramp by Internal_Ops/select_soils.js.
 */
(function (root) {
  'use strict';
  root.CONTENT = {
    edition: 'free',
    soils: [
      { id: 1,  seed: 26,  name: 'HAREBELL',    form: 'BELL' },
      { id: 2,  seed: 183, name: 'OXEYE DAISY', form: 'DAISY' },
      { id: 3,  seed: 178, name: 'YARROW',      form: 'UMBEL' },
      { id: 4,  seed: 106, name: 'FOXGLOVE',    form: 'SPIKE' },
      { id: 5,  seed: 177, name: 'BUTTERCUP',   form: 'CUP' },
      { id: 6,  seed: 83,  name: 'STITCHWORT',  form: 'STAR' },
      { id: 7,  seed: 88,  name: 'SELFHEAL',    form: 'SPIKE' },
      { id: 8,  seed: 55,  name: 'COW PARSLEY', form: 'UMBEL' },
      { id: 9,  seed: 89,  name: 'PRIMROSE',    form: 'CUP' },
      { id: 10, seed: 182, name: 'FEVERFEW',    form: 'DAISY' },
    ],
    endingTitle: 'IN FULL BLOOM',
    ending: null,
    // ⛔ REVIEW 2026-09-23 (defect 9): 'DEEPER, STONIER' was false (same 20x15 grid, stones 10.8 -> 10.5). What
    // really rises is pools (5.7 -> 7.0 mean) and par (76 -> 98), so the line says that.
    // ⛔ 1.0.1 (2026-09-23): 'THE PAID DOWNLOAD ON THIS PAGE' was true on itch and FALSE on Game Jolt (no paid download
    // there), and Kongregate's §4(f) bars pointing outside the build. The line is now store-neutral: no page, no URL.
    // (Naming the studio here LOOKED AT: it spilled 'SYSTEMS ASSET FACTORY.' alone onto a second card; the credits
    // card that follows names the studio, so the line stops at the download and fits the 9-line card exactly.)
    demoEnd: ['TEN SEEDS HAVE FLOWERED.', 'THIRTY MORE WAIT, WITH MORE POOLS TO SHARE, AND THE LAST ONE FILLS THE MEADOW. THE FULL GAME IS A PAID WINDOWS DOWNLOAD.'],
  };
}(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this)));
