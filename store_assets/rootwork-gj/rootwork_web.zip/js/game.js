/**
 * game.js — ROOTWORK. Grow one seed's roots down through the soil to every pool of water.
 *
 * ONE SENTENCE OF DESIGN: roots never grow upward and every cell of root costs sugar — the proved-cheapest
 * root system (soil.js solve(), a directed Steiner arborescence) is the par.
 *
 * ⛔ THE PRIMARY INPUT IS A HOLD / TRACE (wing §0a-2): hold a direction and the root tip grows into the soil,
 *    or slides along roots you already grew (free). Clay grows slowly because it costs more; a burrow is quick.
 *    On a touchscreen or with a mouse the tip follows your finger; a tap on a root jumps the tip there.
 * ⛔ §1a: the automation tab is hidden and rAF is throttled to zero there, so every harness drives the game
 *    through the synchronous `window.ROOTWORK.step(n)` and reads `window.ROOTWORK.frames`.
 * ⛔ §6b-64: every device the listing claims is driven with its REAL vocabulary by the harness — keyboard
 *    holds (4-way), pointer traces (cells under a finger) — never with an exact vector no device produces.
 */
(function (root) {
  'use strict';

  var ART = root.ART, FONT = root.DW_FONT, C = root.CONTENT, SND = root.PSOUND, SOIL = root.SOIL;
  var W = ART.W, H = ART.H, LIT = ART.LIT, FACE = ART.FACE, MID = ART.MID, SHADOW = ART.SHADOW;
  var GW = ART.GW, GH = ART.GH, N = GW * GH;
  var DMG = ['#9bbc0f', '#8bac0f', '#306230', '#0f380f'];
  var SUGAR_SLACK = 1.30, FRAMES_PER_SUGAR = 3, SLIDE_FRAMES = 3, BLOOM_FRAMES = 50, PLANT_SIZE = 18;

  if (!C || !C.soils || !C.soils.length) throw new Error('content: no soils');

  var S = {
    screen: 'title', frames: 0, si: 0, run: null, result: null,
    held: { x: 0, y: 0 }, dirOrder: [], muted: false, paused: false, endPage: 0, herbPage: 0, toast: null,
    best: {}, pointer: null,
  };

  var ED = C.edition === 'full' ? 'full' : 'free';
  var BEST_KEY = 'ROOTWORK_BEST_' + ED, SI_KEY = 'ROOTWORK_SI_' + ED;
  try { S.best = JSON.parse(root.localStorage.getItem(BEST_KEY) || '{}') || {}; } catch (e) { S.best = {}; }
  function saveBest() { try { root.localStorage.setItem(BEST_KEY, JSON.stringify(S.best)); } catch (e) { /* private mode */ } }
  function saveSi() { try { root.localStorage.setItem(SI_KEY, String(S.si)); } catch (e) { /* private mode */ } }
  function bestFor(id) { var b = S.best[String(id)]; return typeof b === 'number' ? b : null; }
  function unlocked(ix) { return ix === 0 || bestFor(C.soils[ix - 1].id) !== null || bestFor(C.soils[ix].id) !== null; }

  function soil(ix) { return SOIL.generate(C.soils[ix]); }
  function specFor(ix) { var c = C.soils[ix]; return ART.plantSpec(c.form, c.seed); }
  (function restoreSi() {
    var v = 0;
    try { v = parseInt(root.localStorage.getItem(SI_KEY) || '0', 10) || 0; } catch (e) { v = 0; }
    v = Math.max(0, Math.min(C.soils.length - 1, v));
    while (v > 0 && !unlocked(v)) v--;
    S.si = v;
  }());

  var MEDALS = [
    { name: 'GOLD', max: 1.0 + 1e-9, line: 'AS LEAN AS ROOTS CAN BE' },
    { name: 'SILVER', max: 1.05, line: 'A SKILFUL GARDEN' },
    { name: 'BRONZE', max: 1.15, line: 'IT BLOOMED' },
    { name: 'BLOOMED', max: Infinity, line: 'IN FLOWER, BUT HUNGRY' },
  ];
  function medalFor(ratio) { for (var i = 0; i < MEDALS.length; i++) if (ratio <= MEDALS[i].max) return MEDALS[i]; return MEDALS[3]; }

  /* ------------------------------------------------------------------------ the growing */

  function beginRun() {
    var s = soil(S.si), opt = SOIL.solve(s);
    var parent = new Int16Array(N).fill(-1), isRoot = new Uint8Array(N);
    isRoot[s.seed] = 1;
    var reachedSet = new Uint8Array(N);
    S.run = {
      soil: s, opt: opt, parent: parent, isRoot: isRoot, reachedSet: reachedSet, cursor: s.seed,
      sugarMax: Math.ceil(opt.cost * SUGAR_SLACK), sugar: Math.ceil(opt.cost * SUGAR_SLACK), spent: 0,
      reached: 0, cooldown: 0, lastDir: null, bloom: 0, ripples: [], grown: 0, bumps: 0, refusals: {}, trace: [],
    };
    S.screen = 'grow'; S.paused = false; S.toast = null; S.pointer = null;
    if (SND) SND.cue('start');
  }

  var DIRS = { left: [-1, 0], right: [1, 0], up: [0, -1], down: [0, 1] };
  function neighbour(i, d) {
    var x = i % GW, y = (i / GW) | 0, nx = x + DIRS[d][0], ny = y + DIRS[d][1];
    if (nx < 0 || ny < 0 || nx >= GW || ny >= GH) return -1;
    return ny * GW + nx;
  }
  function toast(msg) { S.toast = { msg: msg, until: S.frames + 70 }; }

  /** Every refusal names its reason (wing §0z-1c) — counted in run.refusals, so a harness can read WHY. */
  function refuse(r, why, cueId) {
    r.refusals[why] = (r.refusals[why] || 0) + 1; r.bumps++;
    if (r.lastRefusal !== why || S.frames - (r.lastRefusalAt || 0) > 20) { if (SND) SND.cue(cueId || 'bump'); }
    r.lastRefusal = why; r.lastRefusalAt = S.frames;
    if (why === 'up') toast('ROOTS GROW DOWN');
    else if (why === 'stone') toast('A STONE');
    else if (why === 'sugar') toast('NOT ENOUGH SUGAR');
    return false;
  }

  /** Try one move of the tip in direction d. Returns true if it moved or grew. */
  function tryMove(d) {
    var r = S.run, s = r.soil, t = neighbour(r.cursor, d);
    if (t < 0) return refuse(r, 'edge');
    if (r.isRoot[t]) { r.cursor = t; r.cooldown = SLIDE_FRAMES; if (SND) SND.cue('move'); return true; }
    if (d === 'up') return refuse(r, 'up', 'nope');
    var type = s.grid[t];
    if (type === SOIL.ROCK) return refuse(r, 'stone');
    var cost = SOIL.COST[type];
    if (cost > r.sugar) return refuse(r, 'sugar', 'nope');
    r.sugar -= cost; r.spent += cost; r.grown++;
    r.isRoot[t] = 1; r.parent[t] = r.cursor; r.cursor = t;
    r.cooldown = FRAMES_PER_SUGAR * cost;
    if (SND) SND.cue(type === SOIL.CLAY ? 'growClay' : type === SOIL.BURROW ? 'growBurrow' : 'grow');
    if (s.pockets.indexOf(t) >= 0 && !r.reachedSet[t]) {
      r.reachedSet[t] = 1; r.reached++;
      r.ripples.push({ cell: t, t0: S.frames });
      if (SND) SND.cue('drink');
      if (r.reached === s.pockets.length) { r.bloom = BLOOM_FRAMES; if (SND) SND.cue('bloom'); return true; }
    }
    checkWither(r);
    return true;
  }

  /** Lost only when NO remaining pool can be reached with the sugar left (cheapest path from any root cell). */
  function checkWither(r) {
    var s = r.soil, w = SOIL.weights(s), dist = new Float64Array(N).fill(Infinity), h = SOIL.heap();
    for (var i = 0; i < N; i++) if (r.isRoot[i]) { dist[i] = 0; h.push(i, 0); }
    while (h.size()) {
      var top = h.pop(), d = top[0], u = top[1]; if (d > dist[u]) continue;
      var nx = SOIL.nexts(u);
      for (var k = 0; k < nx.length; k++) { var v = nx[k]; if (w[v] === Infinity) continue; var c = d + (r.isRoot[v] ? 0 : w[v]); if (c < dist[v]) { dist[v] = c; h.push(v, c); } }
    }
    var cheapest = Infinity;
    for (var p = 0; p < s.pockets.length; p++) if (!r.reachedSet[s.pockets[p]]) cheapest = Math.min(cheapest, dist[s.pockets[p]]);
    if (cheapest > r.sugar) finish(false);
  }

  function heldDir() {
    // the most recently pressed held key wins (keyboard); a pointer trace is handled in stepGrow
    for (var i = S.dirOrder.length - 1; i >= 0; i--) return S.dirOrder[i];
    var hx = S.held.x, hy = S.held.y;
    if (!hx && !hy) return null;
    return Math.abs(hx) >= Math.abs(hy) ? (hx < 0 ? 'left' : 'right') : (hy < 0 ? 'up' : 'down');
  }

  /* ⛔ REVIEW 2026-09-23 (defect 7): the trace used to step toward the finger's CURRENT cell by an L-shaped greedy
   * path, whatever route the finger took — dragging back along your own root cut a new staircase through the soil
   * (70 of 70 cases), a one-cell nudge far from the tip grew ~15 cells, and tracing the proved optimum at 10 cells/s
   * earned GOLD 2 times in 40. A trace is now a QUEUE OF THE CELLS THE FINGER PASSED THROUGH (4-connected, gaps
   * filled along the straight line), consumed one cell per move at the soil's own speed: over roots it slides, into
   * soil it grows exactly the traced cell, and the first refused step (up, a stone, no sugar) clears the rest of
   * the queue WITH its toast (defect 19: touch players now hear and see the rules too). A trace only starts ON a
   * root or within one cell of the tip — a stray touch elsewhere grows nothing. */
  var DAS_FRAMES = 14;   // defect 8: a first press moves one cell, auto-repeat only after ~230 ms
  function stepGrow() {
    var r = S.run;
    if (r.bloom > 0) { r.bloom--; if (r.bloom === 0) finish(true); return; }
    if (r.cooldown > 0) { r.cooldown--; return; }
    if (r.trace && r.trace.length) {
      var next = r.trace[0];
      if (next === r.cursor) { r.trace.shift(); return; }
      var d0 = dirTo(r.cursor, next);
      if (!d0) { r.trace.length = 0; return; }           // not adjacent: the queue is stale, drop it
      // a refusal ends this trace AND this touch: dragging on past a stone must not re-queue a straight line to the
      // finger (that was the old greedy L-path by another route). Lift and press again to carry on.
      if (tryMove(d0)) r.trace.shift(); else { r.trace.length = 0; if (S.pointer) S.pointer.active = false; }
      return;
    }
    var d = heldDir();
    if (!d) { r.lastDir = null; return; }
    var fresh = d !== r.lastDir;
    var moved = tryMove(d);
    if (fresh && moved) r.cooldown = Math.max(r.cooldown, DAS_FRAMES);
    r.lastDir = d;
  }
  function dirTo(a, b) {
    var ax = a % GW, ay = (a / GW) | 0, bx = b % GW, by = (b / GW) | 0;
    if (ay === by && bx === ax - 1) return 'left'; if (ay === by && bx === ax + 1) return 'right';
    if (ax === bx && by === ay - 1) return 'up'; if (ax === bx && by === ay + 1) return 'down';
    return null;
  }
  /** Shortest path from a to b THROUGH ROOT CELLS ONLY (4-connected, any direction — sliding is free), or null. */
  function rootPath(r, a, b) {
    if (!r.isRoot[a] || !r.isRoot[b]) return null;
    var prev = new Int16Array(N).fill(-1), seen = new Uint8Array(N), q = [a]; seen[a] = 1;
    for (var h = 0; h < q.length; h++) { var u = q[h]; if (u === b) break;
      ['left', 'right', 'up', 'down'].forEach(function (d) { var v = neighbour(u, d); if (v >= 0 && r.isRoot[v] && !seen[v]) { seen[v] = 1; prev[v] = u; q.push(v); } }); }
    if (!seen[b]) return null;
    var out = []; for (var c = b; c !== a; c = prev[c]) out.push(c); return out.reverse();
  }
  /** Append the 4-connected cells from the last traced cell to `cell`. ⛔ REVIEW 2026-09-23 (defect 7, case B,
   *  re-measured after the first fix): a quick flick from the tip back to an old root skipped cells, and a straight
   *  line between them cut through SOIL (1 cell grown in 70 of 70). When both ends are roots the gap is bridged
   *  ALONG THE ROOTS (free); only otherwise by the straight line. */
  function traceTo(r, cell) {
    var last = r.trace.length ? r.trace[r.trace.length - 1] : r.cursor;
    var viaRoots = rootPath(r, last, cell);
    if (viaRoots) { for (var k = 0; k < viaRoots.length; k++) r.trace.push(viaRoots[k]); return; }
    var x = last % GW, y = (last / GW) | 0, tx = cell % GW, ty = (cell / GW) | 0, guard = 0;
    while ((x !== tx || y !== ty) && guard++ < GW + GH) {
      var ddx = tx - x, ddy = ty - y;
      // step along the axis with more still to go, so a diagonal drag becomes a fair staircase
      if (Math.abs(ddx) >= Math.abs(ddy)) x += ddx > 0 ? 1 : -1;
      else y += ddy > 0 ? 1 : -1;
      r.trace.push(y * GW + x);
    }
  }

  function finish(ok) {
    var r = S.run, c = C.soils[S.si];
    if (ok) {
      var ratio = r.spent / r.opt.cost, prev = bestFor(c.id);
      var isBest = prev === null || r.spent < prev;
      if (isBest) { S.best[String(c.id)] = r.spent; saveBest(); }
      S.result = { ok: true, spent: r.spent, opt: r.opt.cost, ratio: ratio, medal: medalFor(ratio), newBest: isBest, hadBest: prev !== null, prev: prev };
    } else {
      S.result = { ok: false, reached: r.reached, pockets: r.soil.pockets.length, spent: r.spent };
      if (SND) SND.cue('wilt');
    }
    S.screen = 'result';
  }

  /* ----------------------------------------------------------------------------- drawing */

  var plane = new ART.Plane(W, H, LIT);
  var baseCache = { key: '', plane: null };
  var CARDCH = Math.floor((W - 12 - 8) / FONT.FACES.body.adv);
  function wrap(str, max) {
    var words = String(str).split(' '), lines = [], cur = '';
    for (var i = 0; i < words.length; i++) { var nx = cur ? cur + ' ' + words[i] : words[i]; if (nx.length > max && cur) { lines.push(cur); cur = words[i]; } else cur = nx; }
    if (cur) lines.push(cur); return lines;
  }
  function baseFor(s) {
    var key = s.name + ':' + s.seed;
    if (baseCache.key !== key) { baseCache.plane = ART.soilPlane(s); baseCache.key = key; }
    plane.px.set(baseCache.plane.px);
  }
  function text(str, x, y, o) { o = o || {}; if (o.halo === undefined && o.shade === LIT) o.halo = SHADOW; FONT.textPlane(plane, str, x, y, o); }

  function drawCursor(r) {
    var j = ART.joint(r.cursor), on = (S.frames >> 3) % 2 === 0, cx = Math.round(j.x), cy = Math.round(j.y);
    var c = on ? LIT : SHADOW, e = on ? SHADOW : LIT;
    // ⛔ REVIEW 2026-09-23 (defect 20a): four 2-px corner brackets took a search to find at 5x. The tip is now a
    // full blinking square round its cell (lit/dark alternating, so it reads on loam, clay and roots alike) with
    // a dark halo outside it, and the dot in the middle.
    var X = ART.cellX(r.cursor), Y = ART.cellY(r.cursor);
    for (var k = -1; k <= 8; k++) { plane.set(X + k, Y - 1, SHADOW); plane.set(X + k, Y + 8, SHADOW); plane.set(X - 1, Y + k, SHADOW); plane.set(X + 8, Y + k, SHADOW); }
    for (var k2 = 0; k2 <= 7; k2++) { var s2 = (k2 % 2 === 0) === on ? LIT : SHADOW; plane.set(X + k2, Y, s2); plane.set(X + k2, Y + 7, s2); plane.set(X, Y + k2, s2); plane.set(X + 7, Y + k2, s2); }
    plane.set(cx, cy, c); plane.set(cx + 1, cy, e);
  }

  function hud(r) {
    // the sugar gauge (top left, in the sky) with the par notch: where it will stand after the proved-best roots
    var gx = 3, gw = 46, gy = 3;
    text('SUGAR', gx, gy, { shade: LIT });
    var by = gy + 9;
    for (var e = 0; e < gw; e++) { plane.set(gx + e, by, SHADOW); plane.set(gx + e, by + 5, SHADOW); }
    for (var e2 = by; e2 <= by + 5; e2++) { plane.set(gx, e2, SHADOW); plane.set(gx + gw - 1, e2, SHADOW); }
    plane.rect(gx + 1, by + 1, gw - 2, 4, MID);
    var fill = Math.max(0, Math.round((gw - 4) * r.sugar / r.sugarMax));
    if (fill > 0) plane.rect(gx + 2, by + 2, fill, 2, LIT);
    var parX = gx + 2 + Math.round((gw - 4) * (r.sugarMax - r.opt.cost) / r.sugarMax);
    for (var py = by - 1; py <= by + 6; py++) plane.set(parX, py, (py >= by + 2 && py <= by + 3 && parX < gx + 2 + fill) ? SHADOW : (py < by + 1 || py > by + 4 ? SHADOW : LIT));
    // ⛔ SCREENS ROUND 2: the number sat at x 52+, inside the seed column (x 59..99), where the plant grows.
    text(String(r.sugar), gx + 36, gy, { shade: LIT });
    // pools reached (top right)
    var k = r.soil.pockets.length;
    text(r.reached + '/' + k, W - 3, gy, { align: 'right', shade: LIT });
    for (var i = 0; i < k; i++) {
      var x = W - 4 - (k - i) * 6, y = gy + 10, got = i < r.reached;
      for (var j = 0; j < 4; j++) for (var q = 0; q < 4; q++) { var edge = j === 0 || j === 3 || q === 0 || q === 3; if ((j === 0 || j === 3) && (q === 0 || q === 3)) continue; plane.set(x + q, y + j, edge ? SHADOW : (got ? LIT : MID)); }
    }
  }

  function drawField(r, opts) {
    var s = r.soil;
    baseFor(s);
    ART.drawRoots(plane, s, r.parent, r.isRoot);
    ART.drawSeed(plane, s);
    for (var p = 0; p < s.pockets.length; p++) ART.drawPocket(plane, s.pockets[p], !!r.reachedSet[s.pockets[p]], S.frames);
    // a ripple where a pool was just drunk
    r.ripples = r.ripples.filter(function (q) { return S.frames - q.t0 < 24; });
    r.ripples.forEach(function (q) {
      var j = ART.joint(q.cell), rad = 3 + (S.frames - q.t0) / 3;
      for (var a = 0; a < 20; a++) { var t = a / 20 * 6.283; plane.set(Math.round(j.x + Math.cos(t) * rad), Math.round(j.y + Math.sin(t) * rad), LIT); }
    });
    var prog = r.bloom > 0 ? 1 : r.reached / s.pockets.length * 0.85;
    ART.drawPlant(plane, specFor(S.si), Math.round(ART.joint(s.seed).x), ART.SOIL_Y - 2, PLANT_SIZE, r.bloom > 0 ? 1 : prog);
    if (r.bloom > 0) { // petals of light rising off the flower
      var j0 = ART.joint(s.seed), f = BLOOM_FRAMES - r.bloom;
      for (var k2 = 0; k2 < 6; k2++) { var ang = k2 / 6 * 6.283 + f * 0.05, rr = f * 0.35; plane.set(Math.round(j0.x + Math.cos(ang) * rr), Math.round(6 + Math.sin(ang) * rr * 0.5), LIT); }
    }
    if (!opts || !opts.noCursor) drawCursor(r);
  }

  function drawGrowScreen() {
    var r = S.run;
    drawField(r);
    hud(r);
    if (S.toast && S.frames < S.toast.until) {
      // ⛔ REVIEW 2026-09-23 (defect 20c): the toast covered the bottom two rows for 70 frames, often over the tip
      // and a pool. It now sits at the TOP of the soil when the tip is in the lower half, and at the bottom otherwise.
      var w = S.toast.msg.length * 6 + 8, x = Math.round((W - w) / 2), low = ((r.cursor / GW) | 0) >= GH / 2, ty = low ? ART.SOIL_Y + 2 : 128;
      plane.rect(x, ty, w, 11, SHADOW); plane.hline(x, x + w - 1, low ? ty + 11 : ty - 1, LIT);
      text(S.toast.msg, W / 2, ty + 2, { align: 'center', shade: LIT, halo: undefined });
    }
    if (S.paused) {
      // ⛔ REVIEW 2026-09-23 (defect 20b): a shade-3 panel on shade-3 soil had only a top rule. Full lit border now.
      plane.rect(29, 53, 102, 40, LIT);
      plane.rect(30, 54, 100, 38, SHADOW); plane.hline(30, 129, 54, LIT);
      text('PAUSED', W / 2, 60, { align: 'center', shade: LIT });
      FONT.textPlane(plane, 'P RESUME', W / 2, 72, { align: 'center', shade: FACE });
      FONT.textPlane(plane, 'X GIVE UP', W / 2, 81, { align: 'center', shade: FACE });
    }
  }

  function cardFrame(title) {
    plane.px.fill(MID);
    for (var i = 0; i < 10; i++) plane.hline(0, W - 1, 7 + i * 15, SHADOW);
    plane.rect(6, 14, W - 12, H - 34, SHADOW);
    plane.hline(6, W - 7, 14, LIT);
    FONT.textPlane(plane, title, W / 2, 20, { align: 'center', shade: LIT });
    plane.hline(30, W - 31, 30, MID);
  }
  function card(title, lines, footer) {
    cardFrame(title);
    var flat = [];
    for (var j = 0; j < lines.length; j++) { if (!lines[j]) { flat.push(''); continue; } wrap(lines[j], CARDCH).forEach(function (l) { flat.push(l); }); }
    for (var k = 0; k < flat.length && 36 + k * 9 <= H - 22; k++) FONT.textPlane(plane, flat[k], W / 2, 36 + k * 9, { align: 'center', shade: FACE });
    if (footer) FONT.textPlane(plane, footer, W / 2, H - 12, { align: 'center', shade: SHADOW, halo: LIT });
  }

  /* The title art is a real shipped file, art/title.png, baked from ART.titlePlane() by Internal_Ops/build_art.js
   * and composited with drawImage in paint() — never read back, so it works on the paid build's file:// origin.
   * The plane underneath holds the SAME picture drawn from code, so a failed load still shows the title, and
   * verify_web.js asserts the file really loads (an asset nothing blits is a dead reader, wing §0z-1c). */
  var titleBase = null, titleImg = null, titleState = 'none';
  // ⛔ SCREENS ROUND 3 (looked at Playtest/free_itch_embed_title.png): a band at y 24 cut the head off the title's
  // hero daisy. The free band now sits just above PRESS, narrowed to its words, over the soil.
  var FREE_BAND = { x: 36, y: H - 26, w: 88, h: 11 }, PRESS_BAND = { x: 44, y: H - 13, w: 72, h: 11 };
  function loadTitle() {
    if (titleState !== 'none' || !root.Image) return;
    titleState = 'loading';
    titleImg = new root.Image();
    titleImg.onload = function () { titleState = 'ready'; };
    titleImg.onerror = function () { titleState = 'failed'; };
    titleImg.src = 'art/title.png';
  }
  function drawTitle() {
    if (!titleBase) titleBase = ART.titlePlane(FONT);
    plane.px.set(titleBase.px);
    if (C.edition !== 'full') { plane.rect(FREE_BAND.x, FREE_BAND.y, FREE_BAND.w, FREE_BAND.h, SHADOW); FONT.textPlane(plane, 'FREE EDITION', W / 2, FREE_BAND.y + 2, { align: 'center', shade: LIT }); }
    if (S.frames % 48 < 32) { plane.rect(PRESS_BAND.x, PRESS_BAND.y, PRESS_BAND.w, PRESS_BAND.h, SHADOW); FONT.textPlane(plane, 'Z OR TAP', W / 2, PRESS_BAND.y + 2, { align: 'center', shade: LIT }); }
  }

  function drawYard() {
    var s = soil(S.si), c = C.soils[S.si], opt = SOIL.solve(s);
    baseFor(s);
    ART.drawSeed(plane, s);
    for (var p = 0; p < s.pockets.length; p++) ART.drawPocket(plane, s.pockets[p], false, S.frames);
    ART.drawPlant(plane, specFor(S.si), Math.round(ART.joint(s.seed).x), ART.SOIL_Y - 2, PLANT_SIZE, 0);
    var b = bestFor(c.id);
    // ⛔ REVIEW 2026-09-23 (defect 2): the seed screen never said how to start. 'Z GROW' sits top right (clear of the
    // bud in the seed column); the name drops its number (the count is on the line below) so 15-char names fit.
    text(c.name, 3, 3, { shade: LIT });
    text('Z GROW', W - 3, 3, { align: 'right', shade: LIT });
    text(b === null ? s.pockets.length + ' POOLS' : medalFor(b / opt.cost).name, W - 3, 13, { align: 'right', shade: LIT });
    // ⛔ '<' is not in the body face (DW_FONT.missing counted it, capture_screens 09-23): say it in words
    // ⛔ SCREENS ROUND 2: 'SEED 1/40' reached x 57, touching the bud in the seed column. The count alone is clear.
    text((S.si + 1) + '/' + C.soils.length, 3, 13, { shade: LIT });
  }

  function drawResult() {
    var R = S.result, c = C.soils[S.si];
    if (R.ok) {
      cardFrame(R.medal.name);
      // the flower, big, in its own panel
      plane.rect(12, 34, 52, 76, MID); plane.hline(12, 63, 33, LIT);
      for (var x = 12; x < 64; x++) { plane.set(x, 106, SHADOW); if (ART.hash2(x, 3) < 0.4) plane.set(x, 105, SHADOW); }
      plane.rect(12, 107, 52, 3, SHADOW);
      ART.drawPlant(plane, specFor(S.si), 38, 104, 58, 1);
      var tx = 110;
      // ⛔ REVIEW 2026-09-23 (defect 17): a name over 14 chars was cut to its first word ('VIPER'S'). It now wraps.
      if (c.name.length > 14 && c.name.indexOf(' ') > 0) { var sp = c.name.indexOf(' '); FONT.textPlane(plane, c.name.slice(0, sp), tx, 33, { align: 'center', shade: LIT }); FONT.textPlane(plane, c.name.slice(sp + 1), tx, 41, { align: 'center', shade: LIT }); }
      else FONT.textPlane(plane, c.name, tx, 36, { align: 'center', shade: LIT });
      FONT.textPlane(plane, 'YOUR ROOTS', tx, 52, { align: 'center', shade: FACE });
      FONT.textPlane(plane, String(R.spent), tx, 61, { align: 'center', shade: LIT });
      FONT.textPlane(plane, 'BEST THERE IS', tx, 74, { align: 'center', shade: FACE });
      FONT.textPlane(plane, String(R.opt), tx, 83, { align: 'center', shade: LIT });
      FONT.textPlane(plane, R.newBest ? (R.hadBest ? 'A NEW BEST' : 'FIRST BLOOM') : 'YOUR BEST ' + R.prev, tx, 97, { align: 'center', shade: FACE });
      wrap(R.medal.line, 24).forEach(function (l, i) { FONT.textPlane(plane, l, W / 2, 112 + i * 8, { align: 'center', shade: FACE }); });
      FONT.textPlane(plane, 'Z NEXT  X BEST ROOTS', W / 2, H - 12, { align: 'center', shade: SHADOW, halo: LIT });
    } else {
      card(R.gaveUp ? 'LEFT TO SEED' : 'IT WITHERED', [
        'POOLS REACHED ' + R.reached + ' OF ' + R.pockets,
        '',
        R.gaveUp ? 'EVERY SOIL HAS A LEANEST ROOT SYSTEM. TRY ANOTHER WAY DOWN.' : 'NO POOL LEFT WITHIN REACH OF THE SUGAR THAT REMAINS. ROOTS THAT SHARE A PATH PAY FOR IT ONCE.',
      ], 'Z RETRY  X SEEDS');
    }
  }

  /** THE LESSON, on request after a bloom: the proved-best root system drawn over the soil, its branch points
   *  ringed, with your own roots beneath it in shade 2 — the thing the player can learn to see. */
  function drawReveal() {
    var r = S.run, s = r.soil, opt = r.opt;
    baseFor(s);
    // yours, DASHED (texture, not tone — STORE ROUND 1); the best, SOLID on top and blinking, so where they coincide
    // the solid covers the dash, and every dash left showing is a root you grew that the best system does without.
    ART.drawRoots(plane, s, r.parent, r.isRoot, { dash: true, noHairs: true });
    var parent = new Int16Array(N).fill(-1), isRoot = new Uint8Array(N);
    opt.cells.forEach(function (c) { isRoot[c] = 1; }); opt.edges.forEach(function (e) { parent[e[1]] = e[0]; });
    if ((S.frames >> 4) % 4 !== 3) ART.drawRoots(plane, s, parent, isRoot, { noHairs: true });
    ART.drawSeed(plane, s);
    for (var p = 0; p < s.pockets.length; p++) ART.drawPocket(plane, s.pockets[p], true, S.frames);
    // ⛔ REVIEW 2026-09-23 (defect 14): 20 sparse dots at radius 5 were the SAME dotted texture the legend calls
    // 'yours'. A fork is now a SOLID lit ring with a dark ring outside it, drawn last so nothing covers it.
    opt.branchCells.forEach(function (c) { var j = ART.joint(c);
      for (var a = 0; a < 64; a++) { var t = a / 64 * 6.283; plane.set(Math.round(j.x + Math.cos(t) * 6), Math.round(j.y + Math.sin(t) * 6), SHADOW); }
      for (var a2 = 0; a2 < 48; a2++) { var t2 = a2 / 48 * 6.283; plane.set(Math.round(j.x + Math.cos(t2) * 5), Math.round(j.y + Math.sin(t2) * 5), LIT); } });
    // ⛔ STORE ROUND 2: 'BEST 92 SOLID' + 'YOURS 98 DASHED' is 28 characters on a 26-character line — they collided.
    text('BEST ' + opt.cost, 3, 3, { shade: LIT });
    text('YOURS ' + r.spent, W - 3, 3, { align: 'right', shade: LIT });
    text('SOLID BEST, DOTS YOURS', 3, 13, { shade: LIT });
  }

  /** THE HERBARIUM: every flower bloomed, pressed on a page, ten to a page, with its medal. */
  function drawHerbarium() {
    plane.px.fill(MID);
    plane.rect(0, 0, W, 12, SHADOW);
    var pages = Math.ceil(C.soils.length / 10), pg = Math.max(0, Math.min(S.herbPage, pages - 1));
    var got = 0; C.soils.forEach(function (c) { if (bestFor(c.id) !== null) got++; });
    FONT.textPlane(plane, 'HERBARIUM ' + got + '/' + C.soils.length, 3, 3, { shade: LIT });
    FONT.textPlane(plane, (pg + 1) + '/' + pages, W - 3, 3, { align: 'right', shade: LIT });
    for (var i = 0; i < 10; i++) {
      var ix = pg * 10 + i; if (ix >= C.soils.length) break;
      var c = C.soils[ix], cx = 4 + (i % 5) * 31, cy = 16 + Math.floor(i / 5) * 60;
      // ⛔ SCREENS ROUND 1: empty slots were the BRIGHTEST cells, so the eye went to what is missing. Empty = dark.
      plane.rect(cx, cy, 28, 56, SHADOW);
      var b = bestFor(c.id);
      if (b !== null) {
        plane.rect(cx + 1, cy + 1, 26, 44, MID);
        // ⛔ REVIEW 2026-09-23 (defect 11): at size 38 the flowers spilled out of their slots and off the screen. Drawn
        // at 32 into a scratch plane and CLIPPED to the slot's panel.
        herbScratch.px.fill(ART.NONE);
        ART.drawPlant(herbScratch, ART.plantSpec(c.form, c.seed), cx + 14, cy + 42, 32, 1);
        for (var yy = cy + 1; yy < cy + 45; yy++) for (var xx = cx + 1; xx < cx + 27; xx++) { var v = herbScratch.px[yy * W + xx]; if (v !== ART.NONE) plane.px[yy * W + xx] = v; }
        // ⛔ REVIEW 2026-09-23 (defect 3): BRONZE and BLOOMED both printed 'B'. A plain bloom (no medal) gets no letter.
        var med = medalFor(b / SOIL.solve(soil(ix)).cost).name;
        if (med !== 'BLOOMED') FONT.textPlane(plane, med.charAt(0), cx + 14, cy + 47, { align: 'center', shade: LIT });
      } else {
        FONT.textPlane(plane, '?', cx + 14, cy + 18, { align: 'center', shade: MID });
        FONT.textPlane(plane, String(ix + 1), cx + 14, cy + 47, { align: 'center', shade: MID });
      }
    }
    // ⛔ REVIEW 2026-09-23 (defect 5): the free edition (one page) offered paging that does not exist.
    FONT.textPlane(plane, pages > 1 ? 'LEFT RIGHT: PAGE  X BACK' : 'X BACK', W / 2, H - 9, { align: 'center', shade: SHADOW, halo: LIT });
  }
  var herbScratch = new ART.Plane(W, H, ART.NONE);

  var LINES_PER_PAGE = 9;   // the card fits 9 body lines (38..122); at 8 the ending's first page held one line
  function endingPages() {
    var raw = C.ending || [].concat(C.demoEnd || ''), paras = [];
    for (var i = 0; i < raw.length; i++) if (raw[i]) paras.push(wrap(raw[i], CARDCH));
    var pages = [], cur = [];
    paras.forEach(function (p) {
      // ⛔ REVIEW 2026-09-23 (defect 13): a paragraph that did not fit whole went to the NEXT page, leaving page 1 of
      // the paid ending with two lines on an empty card. A paragraph now flows on and breaks mid-way; a new page is
      // only started when fewer than 3 lines are left (no orphan line).
      if (cur.length && LINES_PER_PAGE - cur.length < 3) { pages.push(cur); cur = []; }
      if (cur.length) cur.push('');
      for (var k = 0; k < p.length; k++) { if (cur.length >= LINES_PER_PAGE) { pages.push(cur); cur = []; } cur.push(p[k]); }
    });
    if (cur.length) pages.push(cur);
    return pages.length ? pages : [['']];
  }
  function drawEnding() {
    var pages = endingPages(), page = Math.max(0, Math.min(S.endPage, pages.length - 1));
    cardFrame(C.ending ? C.endingTitle : 'END OF THE FREE EDITION');
    for (var k = 0; k < pages[page].length; k++) FONT.textPlane(plane, pages[page][k], W / 2, 38 + k * 9, { align: 'center', shade: FACE });
    var more = page < pages.length - 1;
    FONT.textPlane(plane, more ? 'Z MORE ' + (page + 1) + '/' + pages.length : 'Z CREDITS', W / 2, H - 12, { align: 'center', shade: SHADOW, halo: LIT });
  }
  /** ⛔ REVIEW 2026-09-23 (defect 2): every rule lived in one HTML line under the canvas (hidden under 420 px tall,
   *  absent from every capture). The rules card is shown before the first soil and on DOWN from the seed screen. */
  var RULES = ['REACH EVERY POOL AND THE SEED FLOWERS.', 'ROOTS GROW DOWN OR SIDEWAYS, NEVER UP. STONES STOP THEM.',
    'SUGAR A CELL: LOAM 2, CLAY 5, BURROW 1.', 'SLIDE BACK ALONG ROOTS FREE. SHARE A ROOT AND PAY ONCE.'];
  var RULES_KEY = 'ROOTWORK_RULES_SEEN', rulesSeen = false;
  try { rulesSeen = root.localStorage.getItem(RULES_KEY) === '1'; } catch (e) { rulesSeen = false; }
  function markRulesSeen() { rulesSeen = true; try { root.localStorage.setItem(RULES_KEY, '1'); } catch (e) { /* private mode */ } }
  function drawRules() { card('HOW ROOTS GROW', RULES, S.rulesThenRun ? 'Z GROW  X BACK' : 'Z OR X BACK'); }
  function drawCredits() {
    card('ROOTWORK', ['CORE SYSTEMS', 'ASSET FACTORY', '', 'CODE, ART AND TEXT MADE', 'WITH AI ASSISTANCE.', 'MUSIC AND SOUND ARE', 'SYNTHESISED FROM NOTES.'], 'X BACK');
  }

  /* ------------------------------------------------------------------------------ paint */
  var cv, ctx, img, data;
  var PAL = DMG.map(function (h) { return [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)]; });
  function paint() {
    for (var i = 0, p = 0; i < plane.px.length; i++, p += 4) { var c = PAL[plane.px[i]] || PAL[0]; data[p] = c[0]; data[p + 1] = c[1]; data[p + 2] = c[2]; data[p + 3] = 255; }
    ctx.putImageData(img, 0, 0);
    if (S.screen === 'title' && titleState === 'ready') {
      ctx.drawImage(titleImg, 0, 0, W, H);
      if (C.edition !== 'full') ctx.putImageData(img, 0, 0, FREE_BAND.x, FREE_BAND.y, FREE_BAND.w, FREE_BAND.h);
      ctx.putImageData(img, 0, 0, PRESS_BAND.x, PRESS_BAND.y, PRESS_BAND.w, PRESS_BAND.h);
    }
  }

  /* ------------------------------------------------------------------------------ input */
  function press(k) {
    if (SND) SND.unlock();
    if (k === 'mute') { S.muted = !S.muted; if (SND) SND.setMuted(S.muted); return; }
    if (S.screen === 'title') { if (k === 'ok') { S.screen = 'yard'; if (SND) SND.cue('ok'); } else if (k === 'back') S.screen = 'credits'; return; }
    if (S.screen === 'yard') {
      if (k === 'left' && S.si > 0) { S.si--; saveSi(); if (SND) SND.cue('page'); }
      else if (k === 'right' && S.si < C.soils.length - 1 && unlocked(S.si + 1)) { S.si++; saveSi(); if (SND) SND.cue('page'); }
      else if (k === 'right' && S.si < C.soils.length - 1) { if (SND) SND.cue('bump'); }
      else if (k === 'up') { S.screen = 'herbarium'; S.herbPage = Math.floor(S.si / 10); if (SND) SND.cue('ok'); }
      else if (k === 'down') { S.screen = 'rules'; S.rulesThenRun = false; if (SND) SND.cue('ok'); }
      else if (k === 'ok' && !rulesSeen) { S.screen = 'rules'; S.rulesThenRun = true; if (SND) SND.cue('ok'); }
      else if (k === 'ok') beginRun();   // ⛔ not 'down': the key would still be held and grow a root on frame one
      else if (k === 'back') S.screen = 'title';
      return;
    }
    if (S.screen === 'rules') {
      if (k === 'ok' && S.rulesThenRun) { markRulesSeen(); beginRun(); }
      else if (k === 'ok' || k === 'back') { markRulesSeen(); S.screen = 'yard'; if (SND) SND.cue('ok'); }
      return;
    }
    if (S.screen === 'herbarium') {
      var pages = Math.ceil(C.soils.length / 10);
      if (k === 'left' && S.herbPage > 0) { S.herbPage--; if (SND) SND.cue('page'); }
      else if (k === 'right' && S.herbPage < pages - 1) { S.herbPage++; if (SND) SND.cue('page'); }
      else if (k === 'back' || k === 'ok' || k === 'down') { S.screen = 'yard'; if (SND) SND.cue('ok'); }
      return;
    }
    if (S.screen === 'grow') {
      if (S.run.bloom > 0) return;
      if (k === 'pause' || (k === 'back' && !S.paused)) { S.paused = !S.paused; if (SND) SND.cue('ok'); }
      else if (k === 'back' && S.paused) { S.paused = false; S.result = { ok: false, gaveUp: true, reached: S.run.reached, pockets: S.run.soil.pockets.length, spent: S.run.spent }; S.screen = 'result'; }
      else if (k === 'ok' && S.paused) { S.paused = false; }
      return;
    }
    if (S.screen === 'result') {
      if (k === 'back' && !S.result.ok) { S.screen = 'yard'; if (SND) SND.cue('ok'); return; }
      if (k === 'back') { S.screen = 'reveal'; if (SND) SND.cue('ok'); return; }
      if (k === 'ok') {
        if (S.result.ok) {
          if (S.si >= C.soils.length - 1) { S.screen = 'ending'; S.endPage = 0; }
          else { S.si++; saveSi(); S.screen = 'yard'; }
        } else { beginRun(); return; }
        if (SND) SND.cue('ok');
      }
      return;
    }
    if (S.screen === 'reveal') { if (k === 'back' || k === 'ok') { S.screen = 'result'; if (SND) SND.cue('ok'); } return; }
    if (S.screen === 'ending') {
      if (k === 'ok') { if (S.endPage < endingPages().length - 1) { S.endPage++; if (SND) SND.cue('page'); } else S.screen = 'credits'; }
      return;
    }
    if (S.screen === 'credits') { if (k === 'back' || k === 'ok') S.screen = 'title'; }
  }

  var HELD = {};
  function holdKey(k, down) {
    HELD[k] = down;
    S.dirOrder = S.dirOrder.filter(function (d) { return d !== k; });
    if (down) S.dirOrder.push(k);
  }
  var KEYMAP = {
    ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down',
    a: 'left', d: 'right', w: 'up', s: 'down', A: 'left', D: 'right', W: 'up', S: 'down',
    z: 'ok', Z: 'ok', Enter: 'ok', ' ': 'ok', x: 'back', X: 'back', Escape: 'back', Backspace: 'back',
    p: 'pause', P: 'pause', m: 'mute', M: 'mute',
  };

  /** Pointer (mouse AND touch): game pixel -> soil cell. */
  function cellAt(px, py) {
    if (py < ART.SOIL_Y) return -1;
    var x = Math.floor(px / ART.CELL), y = Math.floor((py - ART.SOIL_Y) / ART.CELL);
    if (x < 0 || y < 0 || x >= GW || y >= GH) return -1;
    return y * GW + x;
  }
  /** The pointer vocabulary, shared by the page's real events and the harness (§6b-64: the harness sends the
   *  same CELLS a finger lands on). down(cell) on a root jumps the tip there; a held pointer traces. */
  function pointerDown(cell) {
    S.pointer = { down: true, cell: cell, t0: S.frames, moved: false, active: false };
    var r = S.run;
    if (S.screen !== 'grow' || !r || S.paused || cell < 0 || r.bloom > 0) return;
    r.trace = [];
    if (r.isRoot[cell]) { if (cell !== r.cursor) { r.cursor = cell; if (SND) SND.cue('move'); } S.pointer.active = true; return; }
    // a finger that lands just off a root (a fingertip covers ~3x3 cells at 2x) SNAPS to it: the tip if it is within
    // one cell, else a 4-adjacent root, else a diagonal one. The touched soil cell is NOT grown — only the drag that
    // follows grows anything. (Re-measured: with no snap, a 2 px touch jitter stalled every soil of the trace probe.)
    var x = cell % GW, y = (cell / GW) | 0, best = -1, bestRank = 9;
    for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) {
      var nx = x + dx, ny = y + dy; if (nx < 0 || ny < 0 || nx >= GW || ny >= GH) continue;
      var c = ny * GW + nx; if (!r.isRoot[c]) continue;
      var rank = c === r.cursor ? 0 : (dx === 0 || dy === 0) ? 1 : 2;
      if (rank < bestRank) { bestRank = rank; best = c; }
    }
    // P.cell stays the TOUCHED cell, so the finger resting there grows nothing; its first move to a new cell traces on
    if (best >= 0) { if (best !== r.cursor) { r.cursor = best; if (SND) SND.cue('move'); } S.pointer.active = true; }
  }
  function pointerMove(cell) {
    var P = S.pointer;
    if (!P || !P.down || cell === P.cell) return;
    P.moved = true; P.cell = cell;
    if (!P.active || cell < 0 || S.screen !== 'grow' || !S.run || S.paused) return;
    traceTo(S.run, cell);
  }
  /** Lifting the finger does NOT cancel the path already traced: the tip finishes it at the soil's own speed. */
  function pointerUp() { var P = S.pointer; S.pointer = null; return P; }

  /* ------------------------------------------------------------------------------- loop */
  var draw = true;
  function step(n) {
    n = n === undefined ? 1 : n;
    for (var i = 0; i < n; i++) {
      S.frames++;
      if (S.screen === 'grow' && !S.paused) stepGrow();
    }
    if (!draw) return;
    if (S.screen === 'title') drawTitle();
    else if (S.screen === 'yard') drawYard();
    else if (S.screen === 'grow') drawGrowScreen();
    else if (S.screen === 'result') drawResult();
    else if (S.screen === 'reveal') drawReveal();
    else if (S.screen === 'herbarium') drawHerbarium();
    else if (S.screen === 'ending') drawEnding();
    else if (S.screen === 'credits') drawCredits();
    else if (S.screen === 'rules') drawRules();
    if (ctx) paint();
  }
  /* A fixed 60 Hz simulation clock, stepped as many times as real time asks (capped, so a tab returning
   * from the background does not fast-forward a whole soil) — NIGHT PLOUGH's review defect 4, inherited fixed. */
  var STEP_MS = 1000 / 60, acc = 0, lastT = null;
  function frame(t) {
    if (lastT === null) lastT = t;
    acc += Math.min(250, t - lastT); lastT = t;
    var n = 0;
    while (acc >= STEP_MS && n < 4) { acc -= STEP_MS; n++; }
    if (n) step(n);
    root.requestAnimationFrame(frame);
  }

  function boot() {
    cv = root.document.getElementById('screen');
    ctx = cv.getContext('2d'); ctx.imageSmoothingEnabled = false;
    img = ctx.createImageData(W, H); data = img.data;
    loadTitle();
    root.addEventListener('keydown', function (e) {
      var k = KEYMAP[e.key]; if (!k) return;
      e.preventDefault();
      if (k === 'left' || k === 'right' || k === 'up' || k === 'down') {
        var was = HELD[k]; holdKey(k, true);
        if (!was && S.screen !== 'grow') press(k);
        if (!was && S.screen === 'grow' && S.run && S.run.cooldown > 0 && S.run.lastDir !== k) S.run.cooldown = Math.min(S.run.cooldown, 2);
      } else if (!e.repeat) press(k);
    });
    root.addEventListener('keyup', function (e) { var k = KEYMAP[e.key]; if (k && HELD[k]) holdKey(k, false); });
    root.addEventListener('blur', function () { HELD = {}; S.dirOrder = []; S.pointer = null; });
    // pointer: mouse and touch alike. On the soil during a grow: tap a root to jump, hold/drag to trace.
    // Elsewhere: a quick tap confirms, a swipe is a direction.
    function gamePt(e) { var b = cv.getBoundingClientRect(); return { x: (e.clientX - b.left) * W / b.width, y: (e.clientY - b.top) * H / b.height }; }
    var swipe = null;
    cv.addEventListener('pointerdown', function (e) {
      e.preventDefault(); if (SND) SND.unlock();
      try { cv.setPointerCapture(e.pointerId); } catch (err) { /* not capturable */ }
      var g = gamePt(e);
      swipe = { x: g.x, y: g.y, t: Date.now(), moved: false };
      if (S.screen === 'grow') pointerDown(cellAt(g.x, g.y));
    });
    // ⛔ REVIEW 2026-09-23 (defect 7): a finger jittering on a cell border flipped cells and traced a wobble. A new
    // cell only registers once the point is 1.5 game px inside it (a dead zone at every border).
    function stickyCell(x, y) {
      var c = cellAt(x, y), P = S.pointer;
      if (!P || c < 0 || c === P.cell || P.cell < 0) return c;
      var lx = x - (c % GW) * ART.CELL, ly = y - ART.SOIL_Y - ((c / GW) | 0) * ART.CELL, m = 1.5;
      return (lx >= m && lx <= ART.CELL - m && ly >= m && ly <= ART.CELL - m) ? c : P.cell;
    }
    cv.addEventListener('pointermove', function (e) {
      if (!swipe) return;
      var g = gamePt(e);
      if (S.screen === 'grow') { pointerMove(stickyCell(g.x, g.y)); return; }
      var dx = g.x - swipe.x, dy = g.y - swipe.y;
      if (Math.hypot(dx, dy) < 10) return;
      swipe.moved = true;
      press(Math.abs(dx) > Math.abs(dy) ? (dx < 0 ? 'left' : 'right') : (dy < 0 ? 'up' : 'down'));
      swipe.x = g.x; swipe.y = g.y;
    });
    function up(e) {
      if (!swipe) return;
      var quick = !swipe.moved && Date.now() - swipe.t < 300;
      var P = S.screen === 'grow' ? pointerUp() : null;
      swipe = null;
      if (quick && S.screen !== 'grow') press('ok');
      else if (quick && S.screen === 'grow' && P && !P.active && S.paused) press('ok');
    }
    cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
    root.__rwPress = function (k) { press(k); };
    if (/[?&]harness=1\b/.test(root.location.search)) { step(1); return; }
    step(1);
    root.requestAnimationFrame(frame);
  }

  root.ROOTWORK = {
    step: step, setDraw: function (v) { draw = !!v; }, press: press,
    hold: function (dir, down) { holdKey(dir, down !== false); },
    releaseAll: function () { HELD = {}; S.dirOrder = []; S.pointer = null; },
    pointerDown: pointerDown, pointerMove: pointerMove, pointerUp: pointerUp, cellAt: cellAt,
    state: S, plane: plane, beginRun: beginRun, soil: soil, endingPages: endingPages, medalFor: medalFor,
    titleState: function () { return titleState; },
    get frames() { return S.frames; }, version: '1.0.1',
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.ROOTWORK;
  else if (root.document) { if (root.document.readyState === 'loading') root.addEventListener('DOMContentLoaded', boot); else boot(); }
}(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this)));
