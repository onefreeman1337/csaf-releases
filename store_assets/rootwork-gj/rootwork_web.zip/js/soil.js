/**
 * soil.js — ROOTWORK. The soils (generated cross-sections) and the proved-cheapest root system.
 * Pure: no drawing, no input. The game, the store copy's numbers and every bot use THIS file.
 *
 * A soil is a W x H grid of cells. Each cell is LOAM, CLAY, BURROW (an old worm run, easy going) or ROCK
 * (impassable). One SEED sits in the top row. Roots grow from any root cell into the cell BELOW, LEFT or
 * RIGHT of it — never upward — and every cell of root costs its soil's price in sugar. The cheapest set of
 * root cells that reaches every POCKET of water is a directed, node-weighted Steiner arborescence rooted at
 * the seed; solve() computes it EXACTLY (Dreyfus-Wagner subset DP, <= 8 pockets).
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.SOIL = api;
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const W = 20, H = 15;
  const LOAM = 0, CLAY = 1, BURROW = 2, ROCK = 3;
  const COST = [2, 5, 1, Infinity];      // sugar per cell of root
  const NAMES = ['LOAM', 'CLAY', 'BURROW', 'ROCK'];

  function rng(seed) { let s = (seed >>> 0) || 1; return function () { s ^= s << 13; s >>>= 0; s ^= s >> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; }
  const idx = (x, y) => y * W + x;

  /** Forward moves a root can make from cell i: down, left, right. */
  function nexts(i) {
    const x = i % W, y = (i / W) | 0, out = [];
    if (y + 1 < H) out.push(i + W);
    if (x > 0) out.push(i - 1);
    if (x + 1 < W) out.push(i + 1);
    return out;
  }
  /** Cells that can grow INTO cell i: above, right-of, left-of. */
  function prevs(i) {
    const x = i % W, y = (i / W) | 0, out = [];
    if (y > 0) out.push(i - W);
    if (x + 1 < W) out.push(i + 1);
    if (x > 0) out.push(i - 1);
    return out;
  }

  function reachableFrom(grid, s) {
    const seen = new Uint8Array(W * H); const st = [s]; seen[s] = 1;
    while (st.length) { const u = st.pop(); for (const v of nexts(u)) if (!seen[v] && grid[v] !== ROCK) { seen[v] = 1; st.push(v); } }
    return seen;
  }

  const cache = {};
  /** A soil from its SPEC ({ seed, k? }). A bare number n means { seed: n }. */
  function generate(spec) {
    if (typeof spec === 'number') spec = { seed: spec };
    const key = spec.seed + ':' + (spec.k || 0);
    if (cache[key]) return cache[key];
    let tries = 0, s = null;
    while (!s) { s = build(spec.seed, spec.k, tries++); if (tries > 400) throw new Error('soil ' + spec.seed + ': no valid layout in 400 tries'); }
    s.tries = tries;
    s.name = spec.name || ('SOIL ' + (spec.seed + 1));
    s.id = spec.id;
    cache[key] = s;
    return s;
  }

  function build(seedNo, kWanted, attempt) {
    const r = rng(0x5011000 + seedNo * 7919 + attempt * 104729 + 1);
    const grid = new Uint8Array(W * H).fill(LOAM);
    // clay strata: wavy full-width bands with gaps
    const bands = 1 + Math.floor(r() * 3);
    for (let b = 0; b < bands; b++) {
      let y = 3 + Math.floor(r() * (H - 5)); const thick = 1 + Math.floor(r() * 2);
      const gaps = []; const ng = 1 + Math.floor(r() * 2);
      for (let g = 0; g < ng; g++) { const gx = Math.floor(r() * W); gaps.push([gx, gx + 1 + Math.floor(r() * 2)]); }
      for (let x = 0; x < W; x++) {
        if (r() < 0.25) y = Math.max(2, Math.min(H - 2, y + (r() < 0.5 ? -1 : 1)));
        if (gaps.some(([a, c]) => x >= a && x <= c)) continue;
        for (let t = 0; t < thick; t++) if (y + t < H) grid[idx(x, y + t)] = CLAY;
      }
    }
    // clay lenses
    const lenses = Math.floor(r() * 3);
    for (let l = 0; l < lenses; l++) {
      const cx = Math.floor(r() * W), cy = 2 + Math.floor(r() * (H - 3)), rx = 1 + Math.floor(r() * 3), ry = 1 + Math.floor(r() * 2);
      for (let y = cy - ry; y <= cy + ry; y++) for (let x = cx - rx; x <= cx + rx; x++)
        if (x >= 0 && x < W && y >= 1 && y < H && ((x - cx) / (rx + 0.5)) ** 2 + ((y - cy) / (ry + 0.5)) ** 2 <= 1) grid[idx(x, y)] = CLAY;
    }
    // burrows: meandering runs, mostly sideways
    const burrows = 1 + Math.floor(r() * 3);
    for (let b = 0; b < burrows; b++) {
      let x = Math.floor(r() * W), y = 2 + Math.floor(r() * (H - 3)); const len = 5 + Math.floor(r() * 6); const dir = r() < 0.5 ? -1 : 1;
      for (let t = 0; t < len; t++) {
        grid[idx(x, y)] = BURROW;
        if (r() < 0.25) y = Math.max(1, Math.min(H - 1, y + (r() < 0.5 ? -1 : 1))); else x += dir;
        if (x < 0 || x >= W) break;
      }
    }
    // rocks
    const rocks = 3 + Math.floor(r() * 4);
    for (let k = 0; k < rocks; k++) {
      const cx = Math.floor(r() * W), cy = 1 + Math.floor(r() * (H - 1)); const n = 1 + Math.floor(r() * 4);
      let x = cx, y = cy;
      for (let t = 0; t < n; t++) { grid[idx(x, y)] = ROCK; if (r() < 0.5) x = Math.max(0, Math.min(W - 1, x + (r() < 0.5 ? -1 : 1))); else y = Math.max(1, Math.min(H - 1, y + 1)); }
    }
    // seed
    const sx = 7 + Math.floor(r() * 6); const seed = idx(sx, 0); grid[seed] = LOAM;
    // pockets
    const k = kWanted || (5 + Math.floor(r() * 4));
    const pockets = [];
    let guard = 0;
    while (pockets.length < k && guard++ < 500) {
      const x = Math.floor(r() * W), y = 3 + Math.floor(r() * (H - 3)); const i = idx(x, y);
      if (grid[i] === ROCK) continue;
      if (pockets.some(p => Math.max(Math.abs(p % W - x), Math.abs(((p / W) | 0) - y)) < 3)) continue;
      pockets.push(i);
    }
    if (pockets.length < k) return null;
    const seen = reachableFrom(grid, seed);
    if (!pockets.every(p => seen[p])) return null;
    return { W, H, grid, seed, pockets, k };
  }

  function weights(soil) {
    const w = new Float64Array(W * H);
    for (let i = 0; i < W * H; i++) w[i] = COST[soil.grid[i]];
    w[soil.seed] = 0;
    return w;
  }

  /** Tiny binary heap keyed on a Float64Array. */
  function heap() {
    const a = [];
    return {
      size: () => a.length,
      push(v, key) { a.push([key, v]); let i = a.length - 1; while (i > 0) { const p = (i - 1) >> 1; if (a[p][0] <= a[i][0]) break; [a[p], a[i]] = [a[i], a[p]]; i = p; } },
      pop() { const top = a[0]; const last = a.pop(); if (a.length) { a[0] = last; let i = 0; for (;;) { const l = 2 * i + 1, rr = l + 1; let m = i; if (l < a.length && a[l][0] < a[m][0]) m = l; if (rr < a.length && a[rr][0] < a[m][0]) m = rr; if (m === i) break; [a[m], a[i]] = [a[i], a[m]]; i = m; } } return top; }
    };
  }

  const solveCache = new WeakMap();
  /** EXACT cheapest root system. Returns { cost, cells:Set<index>, edges:[[from,to]], branchCells:[...] }. */
  function solve(soil) {
    if (solveCache.has(soil)) return solveCache.get(soil);
    const N = W * H, k = soil.pockets.length, FULL = (1 << k) - 1, w = weights(soil);
    const dp = Array.from({ length: FULL + 1 }, () => new Float64Array(N).fill(Infinity));
    const how = Array.from({ length: FULL + 1 }, () => new Int32Array(N).fill(-1)); // >=0: ext to node; <-1: merge with submask (-(A)-2)
    soil.pockets.forEach((p, i) => { dp[1 << i][p] = w[p]; });
    for (let S = 1; S <= FULL; S++) {
      const d = dp[S], hw = how[S];
      if (S & (S - 1)) { // merge
        const low = S & -S;
        for (let A = (S - 1) & S; A > 0; A = (A - 1) & S) {
          if (!(A & low)) continue;
          const B = S ^ A, dA = dp[A], dB = dp[B];
          for (let v = 0; v < N; v++) { if (w[v] === Infinity) continue; const c = dA[v] + dB[v] - w[v]; if (c < d[v]) { d[v] = c; hw[v] = -A - 2; } }
        }
      }
      // extend: dp[S][u] = w[u] + dp[S][v] for u -> v (u in prevs(v))
      const h = heap(); for (let v = 0; v < N; v++) if (d[v] < Infinity) h.push(v, d[v]);
      while (h.size()) {
        const [dv, v] = h.pop(); if (dv > d[v]) continue;
        for (const u of prevs(v)) { if (w[u] === Infinity) continue; const c = dv + w[u]; if (c < d[u]) { d[u] = c; hw[u] = v; h.push(u, c); } }
      }
    }
    const cells = new Set(), edges = [];
    (function rec(S, v) {
      cells.add(v);
      const hv = how[S][v];
      if (hv === -1) return;                          // base: v is the single pocket of S
      if (hv >= 0) { edges.push([v, hv]); rec(S, hv); return; }
      const A = -hv - 2; rec(A, v); rec(S ^ A, v);
    }(FULL, soil.seed));
    const out = new Map(); for (const [a] of edges) out.set(a, (out.get(a) || 0) + 1);
    const pset = new Set(soil.pockets);
    const branchCells = [...out].filter(([c, n]) => n >= 2 && c !== soil.seed && !pset.has(c)).map(([c]) => c);
    let cost = 0; for (const c of cells) cost += w[c];
    const res = { cost, cells, edges, branchCells, dpCost: dp[FULL][soil.seed] };
    solveCache.set(soil, res);
    return res;
  }

  /** Price of a set of root cells (seed free). */
  function price(soil, cells) { const w = weights(soil); let c = 0; for (const i of cells) c += w[i]; return c; }

  return { W, H, LOAM, CLAY, BURROW, ROCK, COST, NAMES, idx, nexts, prevs, generate, solve, price, weights, heap, reachableFrom, rng };
}));
