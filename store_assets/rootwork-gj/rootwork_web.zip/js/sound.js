/**
 * sound.js — ROOTWORK's audio (forked from NIGHT PLOUGH's, the same two laws below).
 *
 * ⛔⛔ TWO WING LAWS SET THE WHOLE SHAPE OF THIS FILE, AND BOTH WERE PAID FOR BY SHIPPED DEFECTS:
 *
 *  §2a — "USE AN <audio> ELEMENT" IS NECESSARY AND NOT SUFFICIENT. The paid desktop build loads
 *        from file://, where fetch and XHR are both blocked outright. Music therefore plays from
 *        a BARE <audio> element with its own `volume`, OUT of the WebAudio graph. ⛔ NEVER set
 *        crossOrigin and NEVER feed the element to createMediaElementSource — on file:// both
 *        give silence in the paid download, which is the worst possible place for it.
 *
 *  §8a-4 — A CUE GATED ON THE MUSIC'S READINESS IS SWALLOWED. Every SFX cue is gated on its own
 *        requirement and nothing else: an AudioContext in state 'running'. The SFX are synthesised
 *        from oscillators at cue time, so there is no buffer to wait for at all.
 *
 * ⚠ Procedural synthesis is NOT generative AI (wing §0-ART): no Sounds tag on the listing. The
 *   music loop is rendered by Kernel/capture/make_audio.js from a note spec we wrote — our own
 *   IP, no licence, no model.
 */
(function (root) {
  'use strict';

  var ctx = null, muted = false, music = null, wantMusic = false;

  function ac() {
    if (ctx) return ctx;
    var AC = root.AudioContext || root.webkitAudioContext;
    if (!AC) return null;
    try { ctx = new AC(); } catch (e) { ctx = null; }
    return ctx;
  }

  /** ⛔ No autoplay. The first real input starts the context; called from every input path. */
  function unlock() {
    var c = ac();
    if (c && c.state === 'suspended') c.resume();
    if (music && wantMusic && music.paused && !muted) {
      var p = music.play();
      if (p && p.catch) p.catch(function () { /* autoplay refused: the next press tries again */ });
    }
  }

  function voice(o) {
    var c = ac();
    if (!c || c.state !== 'running' || muted) return false;   // ⛔ its OWN requirement, nothing else
    var t = c.currentTime + (o.delay || 0);
    var g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, o.gain), t + (o.attack || 0.005));
    g.gain.exponentialRampToValueAtTime(0.0001, t + o.dur);
    g.connect(c.destination);
    var src;
    if (o.noise) {
      var n = Math.max(1, Math.floor(c.sampleRate * o.dur));
      var buf = c.createBuffer(1, n, c.sampleRate);
      var d = buf.getChannelData(0), last = 0;
      for (var i = 0; i < n; i++) { var w = Math.random() * 2 - 1; last = last * 0.86 + w * 0.14; d[i] = o.bright ? w : last * 3; }
      src = c.createBufferSource(); src.buffer = buf;
      if (o.filter) { var f = c.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = o.filter; f.Q.value = 1.4; src.connect(f); f.connect(g); }
      else src.connect(g);
    } else {
      src = c.createOscillator();
      src.type = o.type || 'square';
      src.frequency.setValueAtTime(o.f0, t);
      if (o.f1 && o.f1 !== o.f0) src.frequency.exponentialRampToValueAtTime(Math.max(1, o.f1), t + o.dur);
      src.connect(g);
    }
    src.start(t);
    src.stop(t + o.dur + 0.02);
    return true;
  }

  var CUES = {
    move:       function () { voice({ type: 'triangle', f0: 620, f1: 700, dur: 0.035, gain: 0.03 }); },          // sliding along a root
    ok:         function () { voice({ type: 'triangle', f0: 330, f1: 660, dur: 0.12, gain: 0.08 }); },
    page:       function () { voice({ type: 'square', f0: 420, f1: 520, dur: 0.045, gain: 0.05 }); },
    start:      function () { voice({ type: 'triangle', f0: 196, f1: 294, dur: 0.3, gain: 0.08 }); voice({ noise: true, filter: 500, dur: 0.2, gain: 0.04 }); },
    grow:       function () { voice({ noise: true, filter: 900, dur: 0.06, gain: 0.05 }); },                     // loam: a soft crumble
    growClay:   function () { voice({ noise: true, filter: 360, dur: 0.16, gain: 0.07 }); voice({ type: 'sine', f0: 90, f1: 70, dur: 0.14, gain: 0.05 }); },  // clay: slow and heavy
    growBurrow: function () { voice({ noise: true, filter: 1800, dur: 0.035, gain: 0.03 }); },                   // a burrow: quick and hollow
    bump:       function () { voice({ type: 'square', f0: 140, f1: 110, dur: 0.08, gain: 0.05 }); },             // a stone / the edge / locked
    nope:       function () { voice({ type: 'square', f0: 220, f1: 165, dur: 0.1, gain: 0.05 }); },               // up, or not enough sugar
    drink:      function () {                                                                                    // a pool reached
      voice({ type: 'sine', f0: 520, f1: 980, dur: 0.14, gain: 0.09 });
      voice({ type: 'triangle', f0: 784, f1: 784, dur: 0.12, gain: 0.05, delay: 0.09 });
    },
    bloom:      function () {
      [392, 494, 587, 784].forEach(function (f, i) { voice({ type: 'triangle', f0: f, f1: f, dur: 0.22, gain: 0.08, delay: i * 0.11 }); });
      voice({ type: 'sine', f0: 1175, f1: 1568, dur: 0.5, gain: 0.04, delay: 0.44 });
    },
    wilt:       function () { voice({ type: 'triangle', f0: 330, f1: 110, dur: 0.7, gain: 0.08 }); voice({ noise: true, filter: 250, dur: 0.5, gain: 0.03 }); },
  };

  /** ⛔ Counted, never silent: an unknown cue id is a defect, not a no-op. */
  var unknown = {};
  function cue(id) {
    var f = CUES[id];
    if (!f) { unknown[id] = (unknown[id] || 0) + 1; return false; }
    f();
    return true;
  }

  /** ⛔ §2a: a BARE element, its own volume, never in the WebAudio graph, no crossOrigin. */
  function attachMusic(el) {
    music = el;
    if (!music) return;
    music.loop = true;
    music.volume = muted ? 0 : 0.42;
    wantMusic = true;
  }

  /** ⛔ Mute drives el.volume EXPLICITLY, in the same edit that sets the flag. */
  function setMuted(m) {
    muted = !!m;
    if (music) {
      music.volume = muted ? 0 : 0.42;
      if (muted) music.pause();
      else if (wantMusic) { var p = music.play(); if (p && p.catch) p.catch(function () {}); }
    }
    try { root.localStorage.setItem('ROOTWORK_MUTE', muted ? '1' : '0'); } catch (e) { /* private mode */ }
  }

  function restoreMuted() {
    try { return root.localStorage.getItem('ROOTWORK_MUTE') === '1'; } catch (e) { return false; }
  }

  root.PSOUND = {
    cue: cue, unlock: unlock, setMuted: setMuted, restoreMuted: restoreMuted,
    attachMusic: attachMusic, unknown: unknown,
    state: function () { return { ctx: ctx ? ctx.state : 'none', muted: muted, music: !!music }; },
    CUES: CUES,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.PSOUND;
}(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this)));
