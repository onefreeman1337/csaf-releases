/**
 * art.js — ROOTWORK. The soil picture, the roots, the wildflowers and the title art — THE SINGLE SOURCE OF
 * TRUTH for them (the contact sheets, the store captures and the game all require this file).
 *
 * ⛔ PALETTE LAW (wing §0-ART-g): DMG luma is 158 / 144 / 77 / 39 — shade 0 next to shade 3 is the only
 *    strong edge. Roots are shade 0 on shade-3 loam: the bright root system growing through dark soil IS
 *    the progress picture. Nothing important is ever shade 0 on shade 1 without a shade-3 edge between.
 * ⛔ TAILRACE (§0-ART-f): a constant-width stroke on right angles reads as WIRE. ART ROUND 1 (looked at
 *    art/sheet_grown_1x.png) read exactly so — "circuit boards". Roots are now CURVES through the midpoints
 *    of their cells (no right angles anywhere), TAPERED by how many pockets they feed (1..4 px), and carry
 *    root hairs — grown, not drawn.
 * ⛔ §0-ART-b: never texture a tile that repeats on a fixed period — every soil speck is hashed per PIXEL.
 * ⛔ ROUND 1 also found: pockets were pinheads, burrows read as a UI dotted line, rocks as bricks, flowers as
 *    outlined coins on a white ground. Each is fixed below and named where it is fixed.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.ART = api;
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const LIT = 0, FACE = 1, MID = 2, SHADOW = 3, NONE = 255;
  const W = 160, H = 144, HUD_H = 0, SOIL_Y = 24, CELL = 8, GW = 20, GH = 15;
  const LOAM = 0, CLAY = 1, BURROW = 2, ROCK = 3;

  function Plane(w, h, fill) { this.w = w; this.h = h; this.px = new Uint8Array(w * h).fill(fill === undefined ? NONE : fill); }
  Plane.prototype.set = function (x, y, s) { if (s === NONE) return; x = Math.round(x); y = Math.round(y); if (x < 0 || y < 0 || x >= this.w || y >= this.h) return; this.px[y * this.w + x] = s; };
  Plane.prototype.get = function (x, y) { return (x < 0 || y < 0 || x >= this.w || y >= this.h) ? NONE : this.px[y * this.w + x]; };
  Plane.prototype.rect = function (x, y, w, h, s) { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) this.set(x + i, y + j, s); };
  Plane.prototype.hline = function (x0, x1, y, s) { for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) this.set(x, y, s); };
  Plane.prototype.vline = function (x, y0, y1, s) { for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++) this.set(x, y, s); };

  function hash2(x, y) { let n = (x | 0) * 374761393 + (y | 0) * 668265263; n = Math.imul(n ^ (n >>> 13), 1274126177); return ((n ^ (n >>> 16)) >>> 0) / 4294967296; }

  const cellX = (i) => (i % GW) * CELL, cellY = (i) => SOIL_Y + ((i / GW) | 0) * CELL;
  /** The point a root passes through in cell i — jittered ±1 px per cell so a straight run wanders. */
  // ⛔ REVIEW 2026-09-23 (defect 10): at ±1 px a sideways run stayed ruler-straight for 30 px and read as a trace
  // on a circuit board. ±2 px (still inside the cell) makes every run wander.
  function joint(i) { const x = i % GW, y = (i / GW) | 0; return { x: x * CELL + 3.5 + (hash2(x * 7, y * 13) * 2 - 1) * 2, y: SOIL_Y + y * CELL + 3.5 + (hash2(x * 11, y * 5) * 2 - 1) * 2 }; }

  /* ------------------------------------------------------------------ the soil */
  function soilPlane(soil) {
    const p = new Plane(W, H, SHADOW);
    const g = soil.grid, at = (x, y) => (x < 0 || y < 0 || x >= GW || y >= GH) ? -1 : g[y * GW + x];
    for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
      const t = g[y * GW + x], X = x * CELL, Y = SOIL_Y + y * CELL;
      for (let j = 0; j < CELL; j++) for (let i = 0; i < CELL; i++) {
        const px = X + i, py = Y + j, h = hash2(px, py);
        let s = h < 0.035 ? MID : SHADOW;                                               // loam crumbs
        if (t === CLAY) {
          // banded clay: shade 2 with wavy shade-3 laminae (continuous across cells — keyed on the pixel)
          const lam = Math.sin(px * 0.21 + py * 1.9 + hash2(0, py) * 5) > 0.72;
          s = lam ? SHADOW : (h < 0.03 ? FACE : MID);
          const up = at(x, y - 1), dn = at(x, y + 1), lf = at(x - 1, y), rt = at(x + 1, y);
          if ((j === 0 && up !== CLAY && h < 0.55) || (j === CELL - 1 && dn !== CLAY && h < 0.55) ||
              (i === 0 && lf !== CLAY && lf !== -1 && h < 0.4) || (i === CELL - 1 && rt !== CLAY && rt !== -1 && h < 0.4)) s = SHADOW;
        }
        p.set(px, py, s);
      }
    }
    // ⛔ ROUND 1: burrows read as a dotted UI line. A burrow is a HOLLOW TUNNEL: a void (3) between crumbling
    // shade-2 walls, joined to its neighbours, with a worm living in it.
    for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
      if (at(x, y) !== BURROW) continue;
      const X = x * CELL, Y = SOIL_Y + y * CELL, L = at(x - 1, y) === BURROW, R = at(x + 1, y) === BURROW, U = at(x, y - 1) === BURROW, D = at(x, y + 1) === BURROW;
      const horiz = L || R || !(U || D);
      for (let j = 0; j < CELL; j++) for (let i = 0; i < CELL; i++) {
        const px = X + i, py = Y + j;
        const inH = horiz && j >= 1 && j <= 6 && (i >= (L ? 0 : 2) && i <= (R ? 7 : 5));
        const inV = (U || D) && i >= 1 && i <= 6 && (j >= (U ? 0 : 2) && j <= (D ? 7 : 5));
        const inC = i >= 1 && i <= 6 && j >= 1 && j <= 6;
        if (inH || inV || inC) {
          const wallH = horiz && (j === 1 || j === 6) && !((U && j === 1 && i >= 1 && i <= 6) || (D && j === 6 && i >= 1 && i <= 6));
          const wallV = (U || D) && (i === 1 || i === 6) && !((L && i === 1 && j >= 1 && j <= 6) || (R && i === 6 && j >= 1 && j <= 6));
          const cornerOnly = !inH && !inV;
          const wall = (wallH || wallV || (cornerOnly && (i === 1 || i === 6 || j === 1 || j === 6)));
          // ⛔ ROUND 2: shade-2 walls round a dark void read as a rail track. The hollow itself is lighter (2), its
          // floor edge dark, its roof crumbling — an air-filled tunnel, not two lines.
          p.set(px, py, wall ? SHADOW : (hash2(px, py * 3) < 0.06 ? FACE : MID));
        }
      }
      // a worm in the first cell of each run
      if (!L && !U && hash2(x, y * 9) < 0.9) { const wx = X + 2, wy = Y + 4; for (let k = 0; k < 4; k++) p.set(wx + k, wy - (k % 2), SHADOW); p.set(wx + 4, wy - 1, SHADOW); p.set(wx + 4, wy - 2, LIT); }
    }
    // ⛔ ROUND 1: rocks read as bricks/tetrominoes. A rock is now a ROUNDED BOULDER: the union of disks on its
    // cells (clipped to them), pale (1), shade-2 underside, a lit highlight, a crack, a dark rim.
    const isRock = (px, py) => {
      const cx = Math.floor(px / CELL), cy = Math.floor((py - SOIL_Y) / CELL);
      if (at(cx, cy) !== ROCK) return false;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        if (at(cx + dx, cy + dy) !== ROCK) continue;
        const ox = (cx + dx) * CELL + 3.5, oy = SOIL_Y + (cy + dy) * CELL + 3.5;
        if (dx && dy && !(at(cx + dx, cy) === ROCK && at(cx, cy + dy) === ROCK)) continue;
        const r = (dx || dy) ? 4.6 : 4.2;
        if ((px - ox) ** 2 + (py - oy) ** 2 <= r * r) return true;
        if ((dx === 0) !== (dy === 0)) { // capsule between two orthogonal rock cells
          const ax = cx * CELL + 3.5, ay = SOIL_Y + cy * CELL + 3.5;
          const t = Math.max(0, Math.min(1, ((px - ax) * (ox - ax) + (py - ay) * (oy - ay)) / (((ox - ax) ** 2 + (oy - ay) ** 2) || 1)));
          if ((px - (ax + (ox - ax) * t)) ** 2 + (py - (ay + (oy - ay) * t)) ** 2 <= 4.2 * 4.2) return true;
        }
      }
      return false;
    };
    // ⛔ REVIEW 2026-09-23 (defect 1): pale (1) boulders with a lit highlight were the ROOTS' OWN TONE (158 v 144
    // luma, §0-ART-g) and a one-cell boulder read as a drunk pool. A stone is now DULL AND PITTED: a shade-2 body
    // with shade-3 pits and a dithered shade-3 underside, and NO shade-0 or shade-1 pixel anywhere — the pale
    // shades mean exactly two things in this game, a living root and water.
    for (let py = SOIL_Y; py < H; py++) for (let px = 0; px < W; px++) {
      if (!isRock(px, py)) continue;
      const rim = !isRock(px - 1, py) || !isRock(px + 1, py) || !isRock(px, py - 1) || !isRock(px, py + 1);
      let s = MID;
      if (rim) s = SHADOW;
      else if (!isRock(px, py + 2) || !isRock(px + 2, py)) s = hash2(px, py) < 0.55 ? SHADOW : MID;   // underside
      // (a shade-1 lit edge was tried first and LOOKED AT in the real exe at 4x: it drew thin pale L-lines round every
      // stone that read as thin roots — defect 1 again, smaller. Stones carry NO shade 0 or 1 at all.)
      else if (hash2(px * 3, py * 5) < 0.16 || (Math.abs((px - py * 0.6) % 11) < 0.6 && hash2(px >> 2, py >> 2) < 0.3)) s = SHADOW; // pits, a crack
      p.set(px, py, s);
    }
    meadow(p, soil ? soil.seed : 0);
    return p;
  }

  /** The strip above ground (24 rows): sky (0), a cloud, a grass line with tufts (3/2).
   *  ⛔ ROUND 1: a dark 12-row HUD band left the flower 11 px of sky. The HUD now sits IN the sky. */
  function meadow(p, seedVar) {
    // ⛔ ROUND 2: a shade-0 sky made shade-0 petals invisible (only outlines showed). The sky is shade 2.
    for (let y = 0; y < SOIL_Y; y++) for (let x = 0; x < W; x++) p.set(x, y, MID);
    // ⛔ SCREENS ROUND 1: the cloud sat under the HUD's sugar number and the seed screen's text. No cloud in play.
    for (let x = 0; x < W; x++) {
      p.set(x, SOIL_Y - 1, SHADOW);
      const h = hash2(x * 3 + seedVar, 17);
      if (h < 0.4) p.set(x, SOIL_Y - 2, SHADOW);
      if (h < 0.14) p.set(x, SOIL_Y - 3, SHADOW);
      if (h > 0.96) { p.set(x, SOIL_Y - 3, SHADOW); p.set(x + 1, SOIL_Y - 4, SHADOW); }
    }
  }

  /* ------------------------------------------------------------------ the roots */
  /** load[i] = number of pockets fed through cell i (for the taper). parent: Int16Array, -1 = none. */
  function loads(soil, parent, isRoot) {
    const N = GW * GH, load = new Uint8Array(N);
    for (const pk of soil.pockets) { if (!isRoot[pk]) continue; let c = pk, guard = 0; while (c >= 0 && guard++ < N) { load[c]++; if (c === soil.seed) break; c = parent[c]; } }
    return load;
  }
  function widthFor(load) { return load >= 5 ? 4 : load >= 3 ? 3 : 2; }

  function dot(p, x, y, w, s) {
    const o = w > 2 ? 1 : 0, r = w / 2;
    for (let oy = 0; oy < w; oy++) for (let ox = 0; ox < w; ox++) {
      if (w >= 3 && (ox === 0 || ox === w - 1) && (oy === 0 || oy === w - 1) && w === 4) continue; // round the 4-px nib
      p.set(Math.round(x) + ox - o - (w === 4 ? 1 : 0) + (w === 4 ? 1 : 0), Math.round(y) + oy - o, s);
    }
    return r;
  }
  function line(p, a, b, w, s) {
    const dx = b.x - a.x, dy = b.y - a.y, n = Math.max(1, Math.ceil(Math.max(Math.abs(dx), Math.abs(dy))));
    for (let k = 0; k <= n; k++) dot(p, a.x + dx * k / n, a.y + dy * k / n, w, s);
  }
  /** Quadratic curve a -> (control c) -> b, width w0 for the first half and w1 for the second. */
  function curve(p, a, c, b, w0, w1, s) {
    const n = Math.max(2, Math.ceil((Math.hypot(c.x - a.x, c.y - a.y) + Math.hypot(b.x - c.x, b.y - c.y)) * 1.5));
    for (let k = 0; k <= n; k++) { const t = k / n, u = 1 - t; dot(p, u * u * a.x + 2 * u * t * c.x + t * t * b.x, u * u * a.y + 2 * u * t * c.y + t * t * b.y, t < 0.5 ? w0 : w1, s); }
  }
  const mid = (a, b) => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });

  /** Draw the grown roots over the soil: for every root cell c with parent p, a curve from the midpoint of
   *  (grandparent, p) through p to the midpoint of (p, c) — so every joint and every fork is ROUNDED. A dark
   *  (3) outline pass first, so shade 0 never meets clay's shade 2 without an edge. */
  function drawRoots(p, soil, parent, isRoot, opts) {
    opts = opts || {};
    const load = loads(soil, parent, isRoot), N = GW * GH, seedPt = joint(soil.seed);
    const kids = new Map();
    for (let i = 0; i < N; i++) if (isRoot[i] && parent[i] >= 0) { if (!kids.has(parent[i])) kids.set(parent[i], []); kids.get(parent[i]).push(i); }
    // ⛔ REVIEW 2026-09-23 (defect 10): width by POOLS FED left nearly every run at 2 px — wiring. A real root
    // thickens with everything that hangs BELOW it, so width follows the SUBTREE (cells downstream): every branch
    // runs thick at its base and thin at its tip, continuously, and the trunk under the seed is the thickest thing.
    const below = new Uint16Array(N);
    { const order = []; const st = [soil.seed]; const seen = new Uint8Array(N); seen[soil.seed] = 1;
      while (st.length) { const u = st.pop(); order.push(u); for (const k of (kids.get(u) || [])) if (!seen[k]) { seen[k] = 1; st.push(k); } }
      for (let k = order.length - 1; k >= 0; k--) { const u = order[k]; below[u] += 1; if (parent[u] >= 0 && u !== soil.seed) below[parent[u]] += below[u]; } }
    const wOf = (i) => below[i] <= 2 ? 1 : below[i] <= 9 ? 2 : below[i] <= 24 ? 3 : 4;
    const segs = [];
    for (let c = 0; c < N; c++) {
      if (!isRoot[c] || parent[c] < 0) continue;
      const pa = parent[c], g = parent[pa];
      const P = joint(pa), Cc = joint(c);
      const a = pa === soil.seed ? { x: seedPt.x, y: seedPt.y - 2 } : mid(g >= 0 ? joint(g) : P, P);
      const b = kids.has(c) ? mid(P, Cc) : Cc;
      const wP = Math.max(wOf(c), Math.min(wOf(pa), wOf(c) + 1)), wC = wOf(c);
      segs.push([a, P, b, wP, wC]);
      if (!kids.has(c)) segs.push([mid(P, Cc), Cc, Cc, wC, wC]);  // run the tip right into its cell
    }
    const s = opts.shade === undefined ? LIT : opts.shade;
    if (opts.dash) {
      // ⛔ STORE ROUND 1: 'your roots' in shade 1 beside the best in shade 0 (14 luma) were indistinguishable. The
      // second system is told apart by TEXTURE, not tone: a checker of shade 0 on the soil, no outline, 1 px.
      const q = new Plane(W, H, NONE);
      for (const [a, c, b] of segs) curve(q, a, c, b, 1, 1, s);
      for (let i = 0; i < q.px.length; i++) if (q.px[i] !== NONE && ((i % W) + ((i / W) | 0)) % 2 === 0) p.px[i] = s;
      return;
    }
    for (const [a, c, b, w0, w1] of segs) curve(p, a, c, b, w0 + 2, w1 + 2, SHADOW);
    for (const [a, c, b, w0, w1] of segs) curve(p, a, c, b, w0, w1, s);
    // root hairs: short hairs angled down and away, only into dark soil — on every run of width <= 2 (REVIEW
    // 2026-09-23: hairs on the thinnest runs only left the long 2-px runs bare, which is what read as wire)
    if (!opts.noHairs) for (let i = 0; i < N; i++) {
      if (!isRoot[i] || i === soil.seed || wOf(i) > 2) continue;
      const j = joint(i), h = hash2(i, 77);
      for (let n = 0; n < (h < 0.5 ? 2 : 1); n++) {
        const side = (hash2(i, 91 + n) < 0.5 ? -1 : 1), slope = 0.4 + hash2(i, 13 + n) * 0.9, len = 3 + Math.floor(hash2(i, 5 + n) * 3);
        for (let k = 2; k <= len; k++) { const x = Math.round(j.x + side * k), y = Math.round(j.y + k * slope); if (p.get(x, y) === SHADOW) p.set(x, y, k === len ? FACE : LIT); }
      }
    }
    // the taproot rises out of the seed to the grass line
    line(p, { x: seedPt.x, y: SOIL_Y - 1 }, seedPt, 2, s);
  }

  /** Pockets. ⛔ ROUND 1: 6-px dim droplets read as pinheads. A pocket is now a round POOL filling its cell:
   *  a lit (0) ring on the dark soil, a shade-2 water body, a glint, and a slow shimmer. A reached pocket is
   *  drunk: its body turns lit and the ring dark. */
  const POOL = ['..XXXX..', '.XXXXXX.', 'XXXXXXXX', 'XXXXXXXX', 'XXXXXXXX', 'XXXXXXXX', '.XXXXXX.', '..XXXX..'];
  function drawPocket(p, i, reached, frame) {
    const X = cellX(i), Y = cellY(i), f = frame || 0;
    if (reached) {
      // ⛔ REVIEW 2026-09-23 (defect 10): a lit disc with a dark ring and a centre notch on the end of a root was a
      // SOLDER PAD. A drunk pool is now DAMP SOIL the root has spread into: no ring, a dithered shade-2 stain, and a
      // brush of lit rootlets fanning out from the centre.
      for (let j = 0; j < 8; j++) for (let k = 0; k < 8; k++) { if (POOL[j][k] !== 'X') continue; if (hash2(X + k, Y + j) < 0.55) p.set(X + k, Y + j, MID); }
      const cx = X + 3.5, cy = Y + 3.5;
      for (let r = 0; r < 6; r++) { const a = r / 6 * 6.283 + hash2(i, 3) * 1.5, L = 2.5 + hash2(i, r) * 1.8; for (let t = 1; t <= L; t += 0.5) p.set(Math.round(cx + Math.cos(a) * t), Math.round(cy + Math.sin(a) * t), t > L - 0.6 ? FACE : LIT); }
      return;
    }
    for (let j = 0; j < 8; j++) for (let k = 0; k < 8; k++) {
      if (POOL[j][k] !== 'X') continue;
      const edge = POOL[j][k - 1] !== 'X' || POOL[j][k + 1] !== 'X' || !POOL[j - 1] || POOL[j - 1][k] !== 'X' || !POOL[j + 1] || POOL[j + 1][k] !== 'X';
      p.set(X + k, Y + j, edge ? LIT : (j <= 2 ? FACE : MID));
    }
    const ph = ((f >> 3) + i) % 12;
    p.set(X + 2, Y + 2, LIT); p.set(X + 3, Y + 2, LIT);
    if (ph < 3) { p.set(X + 4 + ph % 2, Y + 4 + (ph >> 1), FACE); }
  }

  /** The seed: a husk at the top of the soil, split where the taproot leaves it. */
  function drawSeed(p, soil) {
    const X = cellX(soil.seed), Y = cellY(soil.seed);
    const SH = ['.XXXXX..', 'XX...XX.', 'X.....X.', 'XX...XX.', '.XXXXX..'];
    for (let j = 0; j < SH.length; j++) for (let k = 0; k < 8; k++) if (SH[j][k] === 'X') p.set(X + k, Y + j, MID); else if (j > 0 && j < 4 && k > 0 && k < 6) p.set(X + k, Y + j, FACE);
  }

  /* ------------------------------------------------------------------ the wildflowers */
  /** A plant FORM + variation from the soil's seed. forms: DAISY BELL UMBEL SPIKE CUP STAR. */
  function plantSpec(form, seed) {
    const r = (k) => hash2(seed * 31 + k, 911);
    return { form, stemH: 0.72 + r(1) * 0.28, lean: (r(2) - 0.5) * 0.3, leaves: 2 + Math.floor(r(3) * 3), leafSide: r(4) < 0.5 ? -1 : 1, petals: 5 + Math.floor(r(5) * 4), heads: 1 + Math.floor(r(6) * 3), leafForm: Math.floor(r(7) * 3), petalLen: 0.9 + r(8) * 0.4 };
  }
  /** A filled ellipse at angle `ang`: pass 'o' = the 1-px dark outline region, pass 'f' = the interior. */
  function ellipse(p, cx, cy, rx, ry, ang, pass, fill, shadeLow) {
    const ca = Math.cos(ang), sa = Math.sin(ang), R = Math.ceil(Math.max(rx, ry)) + 2;
    for (let j = -R; j <= R; j++) for (let i = -R; i <= R; i++) {
      const u = (i * ca + j * sa) / rx, v = (-i * sa + j * ca) / ry, d = u * u + v * v;
      const X = Math.round(cx + i), Y = Math.round(cy + j);
      if (pass === 'o') { const u2 = (i * ca + j * sa) / (rx + 1), v2 = (-i * sa + j * ca) / (ry + 1); if (u2 * u2 + v2 * v2 <= 1) p.set(X, Y, SHADOW); }
      else if (d <= 1) p.set(X, Y, shadeLow && j > 0 && d > 0.25 ? shadeLow : fill);
    }
  }
  /** Draw a plant with its base at (bx, by), `size` = full height in px, grown to `progress` 0..1.
   *  ⛔ ROUND 1: petals were outlines on a same-shade ground and leaves single-pixel herringbones. Every
   *  petal and leaf is now a FILLED shape: outline pass for the whole plant first, then the fills, so
   *  overlapping petals merge into one flower with a single dark silhouette. */
  function drawPlant(p, spec, bx, by, size, progress) {
    const g = Math.max(0, Math.min(1, progress));
    const h = Math.max(3, Math.round(size * spec.stemH * (0.3 + 0.7 * g)));
    const topX = bx + spec.lean * h, topY = by - h;
    const pt = (t) => ({ x: bx + (topX - bx) * t + Math.sin(t * 3.1) * spec.lean * size * 0.12, y: by - h * t });
    const big = size >= 28, sw = big ? 2 : 1;
    const shapes = [];   // [kind, args...] drawn in two passes
    const nLeaves = Math.max(1, Math.round((spec.leaves + (big ? 1 : 0)) * Math.min(1, 0.35 + g)));
    for (let k = 0; k < nLeaves; k++) {
      const t = 0.08 + 0.55 * (k + 0.5) / nLeaves, q = pt(t), side = (k % 2 ? -1 : 1) * spec.leafSide;
      const L = Math.max(1.6, size * (spec.leafForm === 2 ? 0.2 : 0.15) * (1 - t * 0.5));
      const ang = side > 0 ? -0.55 - (spec.leafForm === 1 ? 0.35 : 0) : Math.PI + 0.55 + (spec.leafForm === 1 ? 0.35 : 0);
      shapes.push(['leaf', q.x + Math.cos(ang) * L, q.y + Math.sin(ang) * L, L, Math.max(1, L * (spec.leafForm === 0 ? 0.42 : 0.3)), ang]);
    }
    const heads = [];
    if (g >= 0.999) {
      const nh = spec.form === 'UMBEL' || spec.form === 'SPIKE' ? 1 : Math.min(spec.heads, big ? 3 : 2);
      for (let hd = 0; hd < nh; hd++) {
        if (hd === 0) { heads.push([pt(1), size]); continue; }
        const t = 0.62 + 0.12 * hd, b = pt(t), side = hd % 2 ? 1 : -1, e = { x: b.x + side * size * 0.22, y: b.y - size * 0.16 };
        heads.push([e, size * 0.7, b]);
      }
    }
    // stems (dark), then outline pass, then fill pass
    for (let t = 0; t <= 1; t += 0.4 / h) { const q = pt(t); for (let o = 0; o < sw; o++) p.set(Math.round(q.x) + o, Math.round(q.y), SHADOW); }
    for (const hd of heads) if (hd[2]) line(p, hd[2], hd[0], 1, SHADOW);
    for (const pass of ['o', 'f']) {
      for (const s of shapes) ellipse(p, s[1], s[2], s[3], s[4], s[5], pass, FACE, null);
      if (pass === 'f') for (const s of shapes) { const L = s[3]; for (let k = -L + 1; k < L - 0.5; k += 0.5) p.set(Math.round(s[1] + Math.cos(s[5]) * k), Math.round(s[2] + Math.sin(s[5]) * k), SHADOW); }
      if (g < 0.999) { const q = pt(1), r = big ? 2.4 : 1.4; ellipse(p, q.x, q.y - r * 0.6, r * 0.8, r * 1.2, 0, pass, g > 0.6 ? FACE : MID, null); }
      for (const [q, sz] of heads) flowerHead(p, spec, q.x, q.y, sz, pass);
    }
  }
  function flowerHead(p, spec, cx, cy, size, pass) {
    const R = Math.max(1.6, size * 0.12);
    const E = (x, y, rx, ry, a, fill, low) => ellipse(p, x, y, rx, ry, a, pass, fill, low);
    if (spec.form === 'DAISY' || spec.form === 'STAR') {
      const n = spec.petals + (spec.form === 'STAR' ? 0 : 2), star = spec.form === 'STAR';
      const len = R * spec.petalLen * (star ? 1.15 : 1);
      for (let k = 0; k < n; k++) { const a = k / n * 6.283 + (star ? -1.57 : 0.2); E(cx + Math.cos(a) * len * 0.72, cy + Math.sin(a) * len * 0.62, len * 0.62, Math.max(0.8, len * (star ? 0.24 : 0.3)), a, LIT, star ? null : FACE); }
      E(cx, cy, Math.max(1, R * 0.42), Math.max(1, R * 0.38), 0, star ? FACE : MID, null);
    } else if (spec.form === 'BELL') {
      // ⛔ SCREENS ROUND 1: at card size the bells overlapped into one blob. They now HANG, spaced, from an arching stalk.
      const n = Math.min(3, 1 + (spec.petals % 3)), bw = Math.max(1.2, R * 0.55), bh = Math.max(2, R * 1.1), side = spec.leafSide;
      for (let k = 0; k < n; k++) {
        const t = (k + 1) / (n + 0.6), ax = cx + side * R * 2.6 * t, ay = cy - R * 0.9 * Math.sin(Math.PI * t * 0.9);
        const bx = ax, by = ay + bh * 0.9;
        if (pass === 'o') { line(p, { x: cx, y: cy }, { x: ax, y: ay }, 1, SHADOW); line(p, { x: ax, y: ay }, { x: bx, y: by - bh * 0.55 }, 1, SHADOW); }
        E(bx, by, bw, bh * 0.6, 0, LIT, FACE);
        E(bx, by + bh * 0.5, bw * 1.3, Math.max(0.8, bh * 0.18), 0, LIT, null);
      }
    } else if (spec.form === 'UMBEL') {
      const n = 6 + (spec.petals % 4), span = R * 2.1;
      for (let k = 0; k < n; k++) {
        const t = (k / (n - 1) - 0.5) * 2, ex = cx + t * span, ey = cy - R * 1.1 + t * t * R * 0.7;
        if (pass === 'o') line(p, { x: cx, y: cy + R * 0.3 }, { x: ex, y: ey }, 1, SHADOW);
        E(ex, ey, Math.max(1, R * 0.45), Math.max(1, R * 0.38), 0, LIT, null);
        if (k % 2) E(ex + R * 0.25, ey - R * 0.4, Math.max(0.8, R * 0.32), Math.max(0.8, R * 0.3), 0, LIT, null);
      }
    } else if (spec.form === 'SPIKE') {
      // ⛔ SCREENS ROUND 2: at card size the spike ran 60 px down the stem and over the card text. It spans 35% of the plant.
      const n = Math.max(3, Math.min(8, Math.round(size / 7))), gap = Math.max(1.4, size * 0.35 / n);
      for (let k = n - 1; k >= 0; k--) { const y = cy + k * gap, side = k % 2 ? 1 : -1, sz = Math.max(1, R * (0.35 + 0.35 * k / n)); E(cx + side * sz * 0.9, y, sz * 1.1, sz * 0.9, 0, k === 0 ? FACE : LIT, k > 1 ? FACE : null); }
    } else { // CUP
      const cw = Math.max(1.6, R * 0.95), ch = Math.max(1.6, R * 0.95);
      E(cx - cw * 0.55, cy - ch * 0.5, cw * 0.7, ch, -0.3, LIT, FACE);
      E(cx + cw * 0.55, cy - ch * 0.5, cw * 0.7, ch, 0.3, LIT, FACE);
      E(cx, cy - ch * 0.6, cw * 0.65, ch * 1.05, 0, LIT, null);
    }
  }

  /* ============================================================================ THE TITLE ART
   * Baked to art/title.png by Internal_Ops/build_art.js (a REAL shipped file, drawn by the game with
   * drawImage — never read back, so it works on the paid build's file:// origin). Sky, wildflowers on the
   * meadow, and below the grass line a soil cross-section with a bright tapered root system reaching pools.
   * The lettering band sits in the SKY, clear of the roots. */
  function titlePlane(font) {
    // ⛔ SCREENS ROUND 1: a shade-0 title sky hid shade-0 petals (the in-game sky is shade 2 for exactly that).
    const p = new Plane(W, H, MID);
    for (let j = -8; j <= 8; j++) for (let i = -8; i <= 8; i++) { const d = Math.hypot(i, j); if (d <= 6.5) p.set(140 + i, 44 + j, LIT); else if (d <= 7.5) p.set(140 + i, 44 + j, SHADOW); }
    for (let k = 0; k < 12; k++) { const a = k / 12 * 6.283; for (let s = 10; s <= 12; s++) p.set(Math.round(140 + Math.cos(a) * s), Math.round(44 + Math.sin(a) * s), FACE); }
    [[22, 34], [96, 52]].forEach(([cx, cy]) => { for (let i = -9; i <= 9; i++) { p.set(cx + i, cy, FACE); if (Math.abs(i) < 6) p.set(cx + i, cy - 1, FACE); if (Math.abs(i) < 3) p.set(cx + i + 2, cy - 2, FACE); } });
    const GL = 80;
    for (let y = GL; y < H; y++) for (let x = 0; x < W; x++) p.set(x, y, hash2(x, y) < 0.035 ? MID : SHADOW);
    for (let y = 104; y < 112; y++) for (let x = 0; x < W; x++) { const yy = y + Math.round(Math.sin(x * 0.05) * 2); p.set(x, yy, Math.sin(x * 0.21 + yy * 1.9) > 0.72 ? SHADOW : (hash2(x, yy) < 0.03 ? FACE : MID)); }
    for (let x = 0; x < W; x++) { p.set(x, GL - 1, SHADOW); const h = hash2(x * 3, 5); if (h < 0.4) p.set(x, GL - 2, SHADOW); if (h < 0.15) p.set(x, GL - 3, SHADOW); if (h > 0.95) { p.set(x, GL - 3, SHADOW); p.set(x - 1, GL - 4, SHADOW); } }
    [[114, 118, 7, 4], [22, 130, 6, 3.5]].forEach(([sx, sy, rx, ry]) => { for (let j = -5; j <= 5; j++) for (let i = -8; i <= 8; i++) { const e = (i / rx) ** 2 + (j / ry) ** 2; if (e > 1) continue; p.set(sx + i, sy + j, e > 0.72 ? SHADOW : (j > 1 ? MID : (j < -1 && i < 0 ? LIT : FACE))); } });
    // the root system: tapered curves from the seed at (60, GL)
    const seedX = 60;
    const R = (pts, w) => { for (let pass = 0; pass < 2; pass++) for (let k = 1; k < pts.length - 1; k++) { const a = k === 1 ? { x: pts[0][0], y: pts[0][1] } : mid({ x: pts[k - 1][0], y: pts[k - 1][1] }, { x: pts[k][0], y: pts[k][1] }); const c = { x: pts[k][0], y: pts[k][1] }; const b = k === pts.length - 2 ? { x: pts[k + 1][0], y: pts[k + 1][1] } : mid(c, { x: pts[k + 1][0], y: pts[k + 1][1] }); curve(p, a, c, b, pass ? w : w + 2, pass ? w : w + 2, pass ? LIT : SHADOW); } };
    R([[seedX, GL - 1], [seedX, 90], [62, 100], [60, 106]], 4);
    R([[60, 106], [52, 112], [40, 116], [26, 116], [18, 118]], 2);
    R([[60, 106], [70, 112], [82, 116], [88, 124]], 3);
    R([[52, 112], [50, 124], [46, 134], [44, 138]], 1);
    R([[88, 124], [100, 128], [118, 132], [136, 134]], 2);
    R([[82, 116], [96, 104], [106, 100], [116, 96]], 1);
    R([[88, 124], [86, 132], [84, 139]], 1);
    for (let k = 0; k < 70; k++) { const x = 16 + Math.floor(hash2(k, 1) * 126), y = 92 + Math.floor(hash2(k, 2) * 48); if (p.get(x, y) === LIT && p.get(x, y + 2) === SHADOW) { const s = hash2(k, 3) < 0.5 ? -1 : 1; p.set(x + s * 2, y + 2, LIT); p.set(x + s * 3, y + 3, FACE); } }
    [[16, 118, 1], [44, 139, 1], [138, 134, 0], [118, 96, 1], [84, 140, 0]].forEach(([x, y, drunk]) => { const X = x - 4, Y = y - 4; for (let j = 0; j < 8; j++) for (let k = 0; k < 8; k++) { if (POOL[j][k] !== 'X') continue; const edge = POOL[j][k - 1] !== 'X' || POOL[j][k + 1] !== 'X' || !POOL[j - 1] || POOL[j - 1][k] !== 'X' || !POOL[j + 1] || POOL[j + 1][k] !== 'X'; p.set(X + k, Y + j, drunk ? (edge ? SHADOW : LIT) : (edge ? LIT : (j <= 2 ? FACE : MID))); } if (!drunk) { p.set(X + 2, Y + 2, LIT); p.set(X + 3, Y + 2, LIT); } });
    // the meadow flowers
    drawPlant(p, { form: 'DAISY', stemH: 1, lean: -0.06, leaves: 3, leafSide: 1, petals: 7, heads: 2, leafForm: 1, petalLen: 1.1 }, seedX, GL - 2, 46, 1);
    drawPlant(p, { form: 'BELL', stemH: 1, lean: 0.14, leaves: 2, leafSide: -1, petals: 5, heads: 1, leafForm: 0, petalLen: 1 }, 100, GL - 2, 26, 1);
    drawPlant(p, { form: 'UMBEL', stemH: 1, lean: -0.1, leaves: 2, leafSide: 1, petals: 7, heads: 1, leafForm: 2, petalLen: 1 }, 20, GL - 2, 24, 1);
    drawPlant(p, { form: 'SPIKE', stemH: 1, lean: 0.05, leaves: 2, leafSide: 1, petals: 6, heads: 1, leafForm: 0, petalLen: 1 }, 128, GL - 2, 28, 1);
    if (font) {
      p.rect(0, 2, W, 20, SHADOW); p.hline(0, W - 1, 1, MID); p.hline(0, W - 1, 22, MID);
      font.textPlane(p, 'ROOTWORK', W / 2, 6, { align: 'center', face: 'display', shade: LIT });
    }
    return p;
  }

  return { LIT, FACE, MID, SHADOW, NONE, W, H, HUD_H, SOIL_Y, CELL, GW, GH, Plane, hash2, joint, cellX, cellY, soilPlane, meadow, drawRoots, drawPocket, drawSeed, loads, widthFor, line, curve, ellipse, plantSpec, drawPlant, titlePlane, POOL };
}));
