/// crt_demo.gml - the demo room's scene: a dialogue that walks the 24-speaker cast (every tradition, every rank), each
/// line typed into that speaker's own box, with a portrait toggle, a gallery of six boxes and a street of six
/// townsfolk. It uses ONLY the public calls a game uses (crt_read, crt_draw, crt_text_rect, crt_ink, crt_draw_portrait).
/// Not needed at runtime: delete it with the demo object.
///
/// Cartouche - The Message Box Drawn as an Object, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function crt_demo_state()
/// @description A fresh demo: {cast, index, shown, tick, portrait, view, bust}.
function crt_demo_state() {
    return { cast: crt_oracle_cast(), index: 0, shown: 0, tick: 0, portrait: false, view: 0, bust: undefined };
}

/// @function crt_demo_bust_sprite()
/// @description The demo's stand-in portrait: a drawn bust silhouette, so the aperture has something to hold. Your
/// game passes its own portrait sprite to crt_draw_portrait instead.
function crt_demo_bust_sprite() {
    var _s = 144, _ss = 2, _sf = surface_create(_s * _ss, _s * _ss);
    gpu_push_state();
    surface_set_target(_sf);
    draw_clear_alpha(c_black, 0);
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    var _c = crt_cx_create(_ss);
    var _g = crt_cx_linear(_c, 0, 30, 0, 144);
    crt_cx_stop(_g, 0, [92, 84, 104]); crt_cx_stop(_g, 1, [40, 36, 48]);
    _c.fill = _g;
    crt_cx_begin(_c); crt_cx_ellipse(_c, 72, 150, 66, 50, 0, 0, pi * 2); crt_cx_fill(_c);
    crt_cx_begin(_c); crt_cx_rect(_c, 60, 78, 24, 30); crt_cx_fill(_c);
    crt_cx_begin(_c); crt_cx_ellipse(_c, 72, 58, 27, 33, 0, 0, pi * 2); crt_cx_fill(_c);
    _c.fill = crt_cx_solid([150, 140, 160], 0.35);
    crt_cx_begin(_c); crt_cx_ellipse(_c, 64, 48, 12, 16, -0.4, 0, pi * 2); crt_cx_fill(_c);
    surface_reset_target();
    var _sm = surface_create(_s, _s);
    surface_set_target(_sm);
    draw_clear_alpha(c_black, 0);
    gpu_set_blendenable(false);
    gpu_set_texfilter(true);
    draw_surface_ext(_sf, 0, 0, 1 / _ss, 1 / _ss, 0, c_white, 1);
    surface_reset_target();
    gpu_pop_state();
    var _spr = sprite_create_from_surface(_sm, 0, 0, _s, _s, false, false, 0, 0);
    surface_free(_sf); surface_free(_sm);
    return _spr;
}

/// @function crt_demo_step(demo)
/// @description Keys: Space / Enter / Right finish the line or go to the next speaker, Left goes back, P toggles the
/// portrait, G cycles the view (dialogue, gallery of six, a street of six townsfolk).
function crt_demo_step(_d) {
    _d.tick++;
    var _line = _d.cast[_d.index].line;
    if (_d.shown < string_length(_line)) _d.shown = min(string_length(_line), _d.shown + 1);
    if (keyboard_check_pressed(vk_space) || keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_right)) {
        if (_d.shown < string_length(_line)) _d.shown = string_length(_line);
        else { _d.index = (_d.index + 1) mod array_length(_d.cast); _d.shown = 0; }
    }
    if (keyboard_check_pressed(vk_left)) { _d.index = (_d.index + array_length(_d.cast) - 1) mod array_length(_d.cast); _d.shown = 0; }
    if (keyboard_check_pressed(ord("P"))) _d.portrait = !_d.portrait;
    if (keyboard_check_pressed(ord("G"))) _d.view = (_d.view + 1) mod 3;
    if (_d.portrait && (is_undefined(_d.bust) || !sprite_exists(_d.bust))) _d.bust = crt_demo_bust_sprite();
}

/// @function crt_demo_backdrop(w, h)
/// @description A dim night scene behind the dialogue, so the box reads as an object in a game.
function crt_demo_backdrop(_w, _h) {
    draw_rectangle_colour(0, 0, _w, _h * 0.6, make_colour_rgb(22, 26, 40), make_colour_rgb(22, 26, 40), make_colour_rgb(44, 40, 52), make_colour_rgb(44, 40, 52), false);
    draw_rectangle_colour(0, _h * 0.6, _w, _h, make_colour_rgb(44, 40, 52), make_colour_rgb(44, 40, 52), make_colour_rgb(18, 16, 22), make_colour_rgb(18, 16, 22), false);
}

/// @function crt_demo_box(spec, speaker, line, shown, x, y, w, h, portrait, bust, phase)
/// @description One speaker's box with its text typed into crt_text_rect in crt_ink - the calls a game makes.
function crt_demo_box(_spec, _sp, _line, _shown, _x, _y, _w, _h, _portrait, _bust, _phase) {
    var _name = string(crt__field(_sp, "name", ""));
    var _done = _shown >= string_length(_line);
    crt_draw(_spec, _x, _y, _w, _h, { name: _name, portrait: _portrait, phase: _phase, caret: _done });
    if (_portrait && !is_undefined(_bust) && sprite_exists(_bust)) crt_draw_portrait(_spec, _x, _y, _w, _h, _bust);
    var _tr = crt_text_rect(_spec, _w, _h, _portrait);
    var _px = clamp(_w * 0.032, 14, 30);
    var _pf = draw_get_font(), _pc = draw_get_colour(), _tf = gpu_get_texfilter();
    draw_set_font(fnt_cartouche); draw_set_colour(crt_ink(_spec)); draw_set_halign(fa_left); draw_set_valign(fa_top);
    gpu_set_texfilter(true);
    var _k = _px / 26;
    draw_text_ext_transformed(_x + _tr.x, _y + _tr.y, string_copy(_line, 1, _shown), 34, _tr.w / _k, _k, _k, 0);
    gpu_set_texfilter(_tf);
    draw_set_font(_pf); draw_set_colour(_pc);
}

/// @function crt_demo_draw(demo, w, h)
/// @description The whole demo screen at GUI size w x h.
function crt_demo_draw(_d, _w, _h) {
    crt_demo_backdrop(_w, _h);
    var _phase = (_d.tick mod 60) / 60, _i;
    if (_d.view == 0) {
        var _bw = min(_w - 48, 960);
        var _bh = 4 * 36 + crt_max_frame_height(_bw);
        var _c = _d.cast[_d.index], _spec = crt_read(_c.speaker);
        crt_demo_box(_spec, _c.speaker, _c.line, _d.shown, (_w - _bw) / 2, _h - _bh - 20, _bw, _bh, _d.portrait, _d.bust, _phase);
        crt_text(24, 20, "CARTOUCHE  -  " + crt_describe(_spec) + "  (" + _spec.kind + ")", 17, make_colour_rgb(214, 204, 182), fa_left, fa_top, fnt_cartouche_ui);
    } else if (_d.view == 1) {
        var _gw = min((_w - 72) / 2, 560), _gh = 150;
        for (_i = 0; _i < 6; _i++) {
            var _cc = _d.cast[(_d.index + _i) mod array_length(_d.cast)];
            var _gx = (_w - _gw * 2 - 24) / 2 + (_i mod 2) * (_gw + 24), _gy = 60 + (_i div 2) * (_gh + 14);
            crt_demo_box(crt_read(_cc.speaker), _cc.speaker, _cc.line, 9999, _gx, _gy, _gw, _gh, false, undefined, _phase);
        }
        crt_text(24, 20, "SIX SPEAKERS, SIX OBJECTS", 17, make_colour_rgb(214, 204, 182), fa_left, fa_top, fnt_cartouche_ui);
    } else {
        var _sw = min((_w - 72) / 2, 560), _sh = 150;
        for (_i = 0; _i < 6; _i++) {
            var _sp = { name: "Villager", kind: "commons", slot: _i };
            var _sx = (_w - _sw * 2 - 24) / 2 + (_i mod 2) * (_sw + 24), _sy = 60 + (_i div 2) * (_sh + 14);
            crt_demo_box(crt_read(_sp), _sp, "Same name, same kind, a different slot: " + crt_describe(crt_read(_sp)) + ".", 9999, _sx, _sy, _sw, _sh, false, undefined, _phase);
        }
        crt_text(24, 20, "ONE STREET: SIX VILLAGERS OF ONE KIND", 17, make_colour_rgb(214, 204, 182), fa_left, fa_top, fnt_cartouche_ui);
    }
    crt_text(_w - 24, 20, "Space next    Left back    P portrait    G gallery / street", 15, make_colour_rgb(170, 160, 146), fa_right, fa_top, fnt_cartouche_ui);
}

/// @function crt_demo_free(demo)
/// @description Free the demo's portrait and every cached box.
function crt_demo_free(_d) {
    if (is_struct(_d) && !is_undefined(_d.bust) && sprite_exists(_d.bust)) sprite_delete(_d.bust);
    crt_cache_clear();
}
