{
  "$GMScript": "v1",
  "%Name": "crt_oracle",
  "name": "crt_oracle",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}