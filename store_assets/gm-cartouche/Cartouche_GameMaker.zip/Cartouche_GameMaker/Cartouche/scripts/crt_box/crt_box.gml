/// crt_box.gml - composition and the public drawing API. Turns one speaker's SPEC into a drawn object - field, rails,
/// material, crest, arcade, bands, joints, corners, nameplate, portrait aperture and caret - and gives your game the
/// calls it needs: where the text goes, what colour it is, and the box itself, baked once and drawn every frame.
///
/// Cartouche - The Message Box Drawn as an Object, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ crt_layout() IS THE SINGLE SOURCE OF EVERY DIMENSION. Nothing else computes a rail width; a caller that needs one
/// calls crt_layout. A second copy of a constant does not drift, it WINS.
/// ⛔ THE FRAME IS SIZED FROM THE BOX'S WIDTH AND IS ADDED TO THE TEXT AREA, NOT CARVED OUT OF IT. A message box is a
/// letterbox (about 816 x 180); a frame sized from the short side is 1-3% of the picture and every ornament on it is
/// invisible. So the OBJECT is taller than its text: crt_frame_height() says by how much.
/// ⛔ THE BOX IS DRAWN INSET INSIDE THE RECT IT IS GIVEN (the `bleed`), and the margin is what projecting corners -
/// finials, horns, rays, crowns - project INTO. Nothing is drawn outside the rect you pass.

/// @function crt_rails(w, profile)
/// @description The three rail widths, the bleed and the unit every ornament is sized from, for a box `w` wide. Pure.
function crt_rails(_w, _prof) {
    var _base = max(8, _w * 0.030);
    return { base: _base, top: _base * 1.26 * _prof.railTop, side: _base * 0.66 * _prof.railSide, foot: _base * 0.78 * _prof.railFoot, bleed: crt_jsround(_base * 0.8) };
}

/// @function crt__layout_prof(w, h, profile)
/// @description The layout for a profile row. Internal (crt_layout takes a spec).
function crt__layout_prof(_w, _h, _prof) {
    var _r = crt_rails(_w, _prof);
    var _ow = max(16, _w - _r.bleed * 2);
    var _oh = max(16, _h - _r.bleed * 2);
    // the clamps are load-bearing: a heavy canopied profile on a one-line box degrades to a thinner frame rather than
    // eating the text
    var _fy = min(_r.top, _oh * 0.34);
    var _fFoot = min(_r.foot, _oh * 0.22);
    return {
        base: _r.base, top: _r.top, side: _r.side, foot: _r.foot, bleed: _r.bleed,
        ox: _r.bleed, oy: _r.bleed, ow: _ow, oh: _oh,
        fx: _r.bleed + _r.side, fy: _r.bleed + _fy, fw: max(8, _ow - _r.side * 2), fh: max(8, _oh - _fy - _fFoot)
    };
}

/// @function crt__prof(spec)
/// @description The profile row of a spec, or undefined. Internal.
function crt__prof(_spec) { return is_struct(_spec) ? crt_look("profiles", crt__field(_spec, "profile", "")) : undefined; }

/// @function crt_layout(spec, w, h)
/// @description Every dimension of the box for `spec` in a w x h rect, relative to the rect's top-left: {base, top,
/// side, foot, bleed, ox, oy, ow, oh (the OBJECT), fx, fy, fw, fh (the FIELD the text sits on)}. undefined for a bad
/// spec or size.
function crt_layout(_spec, _w, _h) {
    var _p = crt__prof(_spec);
    if (is_undefined(_p) || !is_numeric(_w) || !is_numeric(_h) || !(_w > 0) || !(_h > 0)) return undefined;
    return crt__layout_prof(_w, _h, _p);
}

/// @function crt_frame_height(spec, w)
/// @description How many pixels TALLER than its text area the box for `spec` is at width w (a whole number). 0 for a
/// bad spec.
function crt_frame_height(_spec, _w) {
    var _p = crt__prof(_spec);
    if (is_undefined(_p) || !is_numeric(_w) || !(_w > 0)) return 0;
    var _r = crt_rails(_w, _p);
    return ceil(_r.top + _r.foot + _r.bleed * 2);
}

/// @function crt_max_frame_height(w)
/// @description The LARGEST frame allowance any speaker can ask for at width w. Size your message box ONCE as
/// text height + this, and every speaker's object fits it: a plain box sits in more field, a canopied one fills it.
function crt_max_frame_height(_w) {
    if (!is_numeric(_w) || !(_w > 0)) return 0;
    var _corp = crt_corpus();
    var _t = _corp.profiles, _ids = variable_struct_get_names(_t), _best = 0;
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _r = crt_rails(_w, _t[$ _ids[_i]]);
        _best = max(_best, ceil(_r.top + _r.foot + _r.bleed * 2));
    }
    return _best;
}

/// @function crt__reserve_l(layout, profile)
/// @description The portrait aperture in the layout's coordinates. Internal.
function crt__reserve_l(_L, _prof) {
    var _inset = _L.base * 0.34;
    return { x: _L.fx + _inset, y: _L.fy + _inset, w: min(144, max(28, _L.fw * 0.30)), h: max(24, _L.fh - _inset * 2), head: clamp(floor(_prof.crest), 0, 2) };
}

/// @function crt_reserve(spec, w, h)
/// @description The portrait aperture - a panel sunk into the field, its head square, round-arched or pointed after
/// the speaker's own crest: {x, y, w, h, head}, relative to the rect. undefined for a bad spec or size.
function crt_reserve(_spec, _w, _h) {
    var _L = crt_layout(_spec, _w, _h);
    if (is_undefined(_L)) return undefined;
    return crt__reserve_l(_L, crt__prof(_spec));
}

/// @function crt_text_rect(spec, w, h, [portrait])
/// @description Where YOUR text engine should draw the dialogue, relative to the rect: {x, y, w, h}. Clear of the
/// frame, of the portrait aperture when there is one, and of the caret. undefined for a bad spec or size.
function crt_text_rect(_spec, _w, _h, _portrait = false) {
    var _L = crt_layout(_spec, _w, _h);
    if (is_undefined(_L)) return undefined;
    var _left = _L.fx + _L.base * 0.5;
    if (_portrait) { var _rv = crt__reserve_l(_L, crt__prof(_spec)); _left = _rv.x + _rv.w + _L.base * 0.55; }
    var _top = _L.fy + _L.base * 0.35;
    var _right = _L.fx + _L.fw - _L.base * 1.4, _bottom = _L.fy + _L.fh - _L.base * 0.35;
    return { x: _left, y: _top, w: max(1, _right - _left), h: max(1, _bottom - _top) };
}

/// @function crt__solve(spec, w)
/// @description Every colour a box is drawn in, solved from its material: {body, lit, dark, ink, dim, seed_ow}.
/// Internal.
function crt__solve(_spec) {
    var _mat = crt_look("materials", crt__field(_spec, "material", ""));
    var _gnd = crt_look("grounds", crt__field(_spec, "ground", ""));
    if (is_undefined(_mat) || is_undefined(_gnd)) return undefined;
    var _tint = crt__num(crt__field(_spec, "tint", 1));
    var _body = crt_mix(_mat.frame, [255, 255, 255], (_tint - 1) * 0.05);
    var _rel = 26 + _mat.lustre * 34;
    var _ink = crt_ink_for(_mat.field, _mat.frame, CRT_AAA_RATIO, _gnd.amp);
    return { mat: _mat, gnd: _gnd, body: _body, lit: crt_relief(_body, 1, _rel), dark: crt_relief(_body, -1, _rel), ink: _ink, dim: crt_mix(_ink, _mat.field, 0.42) };
}

/// @function crt_ink_rgb(spec)
/// @description The text colour for a speaker's field as [r, g, b]: SOLVED to WCAG AAA (7:1) against the field's least
/// legible texture, starting from the material's own hue. undefined for a bad spec.
function crt_ink_rgb(_spec) { var _s = crt__solve(_spec); return is_undefined(_s) ? undefined : _s.ink; }

/// @function crt_ink(spec)
/// @description The text colour for a speaker's field as a GameMaker colour (see crt_ink_rgb). c_black for a bad spec.
function crt_ink(_spec) { var _s = crt__solve(_spec); return is_undefined(_s) ? c_black : crt_col(_s.ink); }

/// @function crt_ink_dim(spec)
/// @description A quieter ink for secondary text (the ink 42% of the way to the field). c_dkgray for a bad spec.
function crt_ink_dim(_spec) { var _s = crt__solve(_spec); return is_undefined(_s) ? c_dkgray : crt_col(_s.dim); }

/// @function crt_box_draw(ctx, x, y, w, h, spec, [opts])
/// @description Draw one box onto a crt_canvas context (its transform decides the pixel scale). opts: {name,
/// portrait, phase, caret (default true), seed}. Returns the draw report {counts, ink, dim, layout, band_counts,
/// corner_ops, structural: {crest, arcade, joints, material, reserve}} or undefined when the spec names an id the
/// corpus does not have (refused, never drawn half).
function crt_box_draw(_c, _x, _y, _w, _h, _spec, _o = undefined) {
    if (!is_struct(_o)) _o = {};
    var _mat = crt_look("materials", crt__field(_spec, "material", ""));
    var _prof = crt_look("profiles", crt__field(_spec, "profile", ""));
    var _corn = crt_look("corners", crt__field(_spec, "corner", ""));
    var _plat = crt_look("plates", crt__field(_spec, "plate", ""));
    var _gnd = crt_look("grounds", crt__field(_spec, "ground", ""));
    var _car = crt_look("carets", crt__field(_spec, "caret", ""));
    var _bands = crt__field(_spec, "bands", []);
    if (is_undefined(_mat) || is_undefined(_prof) || is_undefined(_corn) || is_undefined(_plat) || is_undefined(_gnd) || is_undefined(_car) || !is_array(_bands)) return undefined;
    if (!is_numeric(_w) || !is_numeric(_h) || !(_w >= 32) || !(_h >= 24) || _w > 4096 || _h > 4096) return undefined;
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _phase = crt__num(crt__field(_o, "phase", 0));
    var _L = crt__layout_prof(_w, _h, _prof);
    var _ox = _x + _L.ox, _oy = _y + _L.oy, _ow = _L.ow, _oh = _L.oh;
    var _seed = is_numeric(crt__field(_o, "seed", undefined)) ? _o.seed : crt_lum(_mat.frame) * 977 + _ow;
    var _tint = crt__num(crt__field(_spec, "tint", 1));
    var _body = crt_mix(_mat.frame, [255, 255, 255], (_tint - 1) * 0.05);
    var _rel = 26 + _mat.lustre * 34;
    var _lit = crt_relief(_body, 1, _rel);
    var _dark = crt_relief(_body, -1, _rel);
    var _ink = crt_ink_for(_mat.field, _mat.frame, CRT_AAA_RATIO, _gnd.amp);
    var _dim = crt_mix(_ink, _mat.field, 0.42);
    var _c0 = { path: _c.counts.path, fill: _c.counts.fill, stroke: _c.counts.stroke, rect: _c.counts.rect };
    var _headH = _L.fy - _L.oy;
    var _footH = _L.oy + _L.oh - (_L.fy + _L.fh);

    // 1. the whole plaque, so the frame is one mass the field is cut into rather than four bars
    crt__fs(_c, _body);
    crt_cx_begin(_c);
    crt_cx_round_rect(_c, _ox, _oy, _ow, _oh, _L.base * 0.4);
    crt_cx_fill(_c);
    // 2. the rails, as sections
    crt_moulded_rail(_c, _ox, _oy, _ow, _headH, _prof.steps, _body, _lit, _dark, "top");
    crt_moulded_rail(_c, _ox, _oy + _oh - _footH, _ow, _footH, _prof.steps, _body, _lit, _dark, "bottom");
    crt_moulded_rail(_c, _ox, _oy, _L.side, _oh, _prof.steps, _body, _lit, _dark, "left");
    crt_moulded_rail(_c, _ox + _ow - _L.side, _oy, _L.side, _oh, _prof.steps, _body, _lit, _dark, "right");
    // 2b. what the frame is MADE of - after the mouldings, at partial alpha, so the section relief survives
    var _matOps = 0;
    _matOps += crt_body_surface(_c, _ox, _oy, _ow, _headH, _mat.family, _mat.grain, _body, _lit, _dark, _seed, false);
    _matOps += crt_body_surface(_c, _ox, _oy + _oh - _footH, _ow, _footH, _mat.family, _mat.grain, _body, _lit, _dark, _seed + 31, false);
    _matOps += crt_body_surface(_c, _ox, _oy, _L.side, _oh, _mat.family, _mat.grain, _body, _lit, _dark, _seed + 61, true);
    _matOps += crt_body_surface(_c, _ox + _ow - _L.side, _oy, _L.side, _oh, _mat.family, _mat.grain, _body, _lit, _dark, _seed + 97, true);
    // 3. the field, cut into the frame and given its ground, with its own edge shadow (recessed, not painted on)
    crt_surface(_c, _x + _L.fx, _y + _L.fy, _L.fw, _L.fh, _mat.field, _gnd.texture, _gnd.amp, _seed);
    crt__ss(_c, _dark);
    _c.lw = max(1, _L.base * 0.14);
    crt_cx_stroke_rect(_c, _x + _L.fx, _y + _L.fy, _L.fw, _L.fh);
    // 3a. the portrait aperture - only when this line HAS a portrait (an empty niche is a hole the box cannot explain)
    var _resOps = 0;
    if (crt__field(_o, "portrait", false) == true) {
        var _rv = crt__reserve_l(_L, _prof);
        _resOps = crt_reserve_recess(_c, _x + _rv.x, _y + _rv.y, _rv.w, _rv.h, _rv.head, _mat.field, _body, _lit, _dark);
    }
    // 3b. the crest: the head rail's inner silhouette, after the field because its job is to cut into it
    var _crestOps = crt_crest_soffit(_c, _ox, _oy, _ow, _headH, _prof.crest, _body, _lit, _dark);
    // 3c. blind arcading standing on the soffit line; a canopy that consumes its rail leaves no room and draws none
    var _arcOps = 0;
    if (_prof.arcade) {
        var _rise = crt_crest_drop(_headH, _prof.crest) * ((_prof.crest == 1) ? 2 : 1.75);
        _arcOps = crt_arcade_run(_c, _ox + _L.side, _oy, _ow - _L.side * 2, _headH - _rise, _body, _lit, _dark);
    }
    // 4. the bands along the head and foot rails (a third runs the side rails); the COUNT is derived, never typed
    var _fits = [], _bandCounts = [];
    for (var _i = 0; _i < array_length(_bands); _i++) {
        var _bd = crt_look("bands", _bands[_i]);
        if (is_undefined(_bd)) continue;
        var _onTop = (_i mod 2) == 0;
        var _thick = (_onTop ? _headH : _footH) * 0.42;
        var _by = _onTop ? _oy + max(1, _headH * 0.08) : _oy + _oh - _footH + 1;
        var _f;
        if (_i >= 2) {
            _thick = _L.side * 0.42;
            _f = crt_band_run(_c, _ox + _L.side - _thick - 1, _oy + _headH, _oh - _headH - _footH, _thick, _bd.motif, _bd.pitch, _bd.depth, _bd.cut, _body, _lit, _dark, true);
        } else {
            _f = crt_band_run(_c, _ox + _L.side, _by, _ow - _L.side * 2, _thick, _bd.motif, _bd.pitch, _bd.depth, _bd.cut, _body, _lit, _dark, false);
        }
        array_push(_fits, _f); array_push(_bandCounts, _f.count);
    }
    // 5. the corners, and the JOINT at each, clockwise from the top-left; the joint first, so the corner sits ON a made
    // frame. The stile sizes the ink, the head rail the reach, the bleed the room to project into.
    var _cornerOps = 0, _jointOps = 0;
    var _cs = [[_ox, _oy], [_ox + _ow, _oy], [_ox + _ow, _oy + _oh], [_ox, _oy + _oh]];
    for (var _q = 0; _q < 4; _q++) {
        _jointOps += crt_joint_mark(_c, _cs[_q][0], _cs[_q][1], _L.side, _prof.joint, _q, _body, _lit, _dark);
        _cornerOps += crt_corner_mark(_c, _cs[_q][0], _cs[_q][1], _L.side, _L.top, _corn.form, _corn.reach, _corn.pieces, _q, _body, _lit, _dark, _L.bleed);
    }
    // 6. the nameplate, struck into the head rail rather than floated above it; every lettering layer solved
    var _name = string(crt__field(_o, "name", ""));
    if (_name != "") {
        var _pw = min(_ow * 0.52, max(_ow * 0.22, string_length(_name) * _L.base * 0.62));
        var _ph = max(_L.base * 0.9, _headH * 0.62);
        var _px = _ox + _L.side + _L.base * 0.4;
        var _py = _oy + _headH * 0.5 - _ph / 2 + _plat.drop * _ph;
        crt_plate_shape(_c, _px, _py, _pw, _ph, _plat.form, _plat.attach, _body, _lit, _dark);
        var _ground = crt_plate_face(_plat.form, _body, _dark);
        var _layers = crt_lettering_layers(_ground, _mat.frame, _plat.lettering, CRT_AAA_RATIO);
        var _fs = crt_jsround(_ph * 0.62);
        crt_cx_save(_c);
        for (var _li = 0; _li < array_length(_layers); _li++) {
            var _lay = _layers[_li];
            crt_cx_text(_c, _name, _px + _pw / 2 + _lay.dx, _py + _ph * 0.55 + _lay.dy, _fs, _lay.bold, _lay.colour, _lay.alpha);
        }
        crt_cx_restore(_c);
    }
    // 7. the caret, in the field's lower right, in the field's own solved ink
    if (crt__field(_o, "caret", true) != false) {
        crt_caret_mark(_c, _x + _L.fx + _L.fw - _L.base * 0.9, _y + _L.fy + _L.fh - _L.base * 0.9, _L.base * 0.8, _car.form, _car.motion, _phase, _ink, _dim);
    }
    math_set_epsilon(_eps);
    return {
        counts: { path: _c.counts.path - _c0.path, fill: _c.counts.fill - _c0.fill, stroke: _c.counts.stroke - _c0.stroke, rect: _c.counts.rect - _c0.rect },
        ink: _ink, dim: _dim, layout: _L, band_counts: _bandCounts, corner_ops: _cornerOps,
        structural: { crest: _crestOps, arcade: _arcOps, joints: _jointOps, material: _matOps, reserve: _resOps }
    };
}

/// @function crt_box_sprite(spec, w, h, [opts])
/// @description The box for `spec` baked into a NEW sprite exactly w x h (drawn at 2x and filtered down, so every edge
/// is smooth), WITHOUT the caret (crt_draw_caret animates it). opts: {name, portrait, supersample (1..4, default 2)}.
/// ⛔ The sprite's colours are PREMULTIPLIED by alpha: draw it with gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha),
/// or let crt_draw do it. The sprite is YOURS: sprite_delete() it when done - in Step or Clean Up, never straight
/// after drawing it (a sprite deleted before the frame is presented draws as a white box). undefined for a bad spec
/// or size.
function crt_box_sprite(_spec, _w, _h, _o = undefined) {
    if (!is_numeric(_w) || !is_numeric(_h) || !(_w >= 32) || !(_h >= 24) || _w > 4096 || _h > 4096) return undefined;
    if (is_undefined(crt__prof(_spec))) return undefined;
    if (!is_struct(_o)) _o = {};
    var _sv = crt__field(_o, "supersample", 2);
    var _ss = is_numeric(_sv) ? clamp(round(_sv), 1, 4) : 2;
    var _W = ceil(_w), _H = ceil(_h);
    var _big = surface_create(_W * _ss, _H * _ss);
    gpu_push_state();
    surface_set_target(_big);
    draw_clear_alpha(c_black, 0);
    // ⛔ colour blends as usual, ALPHA blends as "over": under the default blend a translucent mark LOWERS the
    // surface's alpha and the box comes out perforated wherever grain was drawn
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    var _ctx = crt_cx_create(_ss);
    var _res = crt_box_draw(_ctx, 0, 0, _W, _H, _spec, { name: crt__field(_o, "name", ""), portrait: crt__field(_o, "portrait", false), caret: false });
    surface_reset_target();
    var _small = surface_create(_W, _H);
    surface_set_target(_small);
    draw_clear_alpha(c_black, 0);
    gpu_set_blendenable(false);
    gpu_set_texfilter(true);
    draw_surface_ext(_big, 0, 0, 1 / _ss, 1 / _ss, 0, c_white, 1);
    surface_reset_target();
    gpu_pop_state();
    var _spr = sprite_create_from_surface(_small, 0, 0, _W, _H, false, false, 0, 0);
    surface_free(_big); surface_free(_small);
    if (is_undefined(_res)) { sprite_delete(_spr); return undefined; }
    return _spr;
}

// ---------------------------------------------------------------------------------------------------------------
// The cache crt_draw keeps, so a box is baked once per speaker and size and drawn every frame for nothing
// ---------------------------------------------------------------------------------------------------------------

#macro CRT_CACHE_MAX 48

/// @function crt__cache()
/// @description The sprite cache. Internal.
function crt__cache() {
    if (!variable_global_exists("crt__cache_store") || !is_struct(global.crt__cache_store)) global.crt__cache_store = { map: {}, order: [], tick: 0, bakes: 0 };
    return global.crt__cache_store;
}

/// @function crt__cache_get(key, make)
/// @description The cached sprite for a key, baking it with make() on a miss. ⛔ Old sprites are evicted only AFTER
/// the new bake has set and reset a surface target, which flushes every draw queued so far this frame - so a sprite
/// drawn earlier in the frame is never deleted under its own queued draw. Internal.
function crt__cache_get(_key, _make) {
    var _cc = crt__cache();
    _cc.tick++;
    if (variable_struct_exists(_cc.map, _key)) { var _e = _cc.map[$ _key]; _e.used = _cc.tick; return _e.spr; }
    var _spr = _make();
    _cc.bakes++;
    if (is_undefined(_spr)) return undefined;
    _cc.map[$ _key] = { spr: _spr, used: _cc.tick };
    array_push(_cc.order, _key);
    while (array_length(_cc.order) > CRT_CACHE_MAX) {
        var _oldest = 0, _ou = infinity;
        for (var _i = 0; _i < array_length(_cc.order); _i++) { var _u = _cc.map[$ _cc.order[_i]].used; if (_u < _ou) { _ou = _u; _oldest = _i; } }
        var _k = _cc.order[_oldest];
        if (sprite_exists(_cc.map[$ _k].spr)) sprite_delete(_cc.map[$ _k].spr);
        variable_struct_remove(_cc.map, _k);
        array_delete(_cc.order, _oldest, 1);
    }
    return _spr;
}

/// @function crt_cache_clear()
/// @description Free every box the cache holds. Call it in Clean Up or Room End - not between drawing a box and the end
/// of that frame.
function crt_cache_clear() {
    var _cc = crt__cache();
    for (var _i = 0; _i < array_length(_cc.order); _i++) { var _e = _cc.map[$ _cc.order[_i]]; if (sprite_exists(_e.spr)) sprite_delete(_e.spr); }
    _cc.map = {}; _cc.order = [];
}

/// @function crt_cache_count()
/// @description How many baked boxes the cache holds (at most 48; the least recently drawn is evicted).
function crt_cache_count() { return array_length(crt__cache().order); }

/// @function crt__box_key(spec, w, h, name, portrait)
/// @description The cache key: what the picture depends on and nothing else. Internal.
function crt__box_key(_spec, _w, _h, _name, _portrait) { return "box|" + crt_spec_key(_spec) + "|" + string(ceil(_w)) + "x" + string(ceil(_h)) + "|" + string(_name) + "|" + (_portrait ? "p" : "-"); }

/// @function crt_prepare(spec, w, h, [opts])
/// @description Bake a box into the cache now (a loading screen, a room start) so its first crt_draw costs nothing.
/// Returns true when the box is cached. opts: {name, portrait}.
function crt_prepare(_spec, _w, _h, _o = undefined) {
    // validate BEFORE the cache key is built (the key rounds the size, and ceil() throws on a non-number)
    if (is_undefined(crt_layout(_spec, _w, _h))) return false;
    if (!is_struct(_o)) _o = {};
    var _name = string(crt__field(_o, "name", "")), _por = crt__field(_o, "portrait", false) == true;
    return !is_undefined(crt__cache_get(crt__box_key(_spec, _w, _h, _name, _por), method({ s: _spec, w: _w, h: _h, n: _name, p: _por }, function() { return crt_box_sprite(s, w, h, { name: n, portrait: p }); })));
}

/// @function crt_draw(spec, x, y, w, h, [opts])
/// @description Draw the speaker's box in the rect (x, y, w, h), baking it into the cache the first time, then its
/// animated caret. Call in a Draw or Draw GUI event. opts: {name, portrait, phase (0..1, the caret's animation),
/// caret (default true), alpha (default 1)}. Returns the layout (see crt_layout), or undefined for a bad spec or size.
function crt_draw(_spec, _x, _y, _w, _h, _o = undefined) {
    if (!is_struct(_o)) _o = {};
    var _L = crt_layout(_spec, _w, _h);
    if (is_undefined(_L)) return undefined;
    var _name = string(crt__field(_o, "name", "")), _por = crt__field(_o, "portrait", false) == true;
    var _spr = crt__cache_get(crt__box_key(_spec, _w, _h, _name, _por), method({ s: _spec, w: _w, h: _h, n: _name, p: _por }, function() { return crt_box_sprite(s, w, h, { name: n, portrait: p }); }));
    if (is_undefined(_spr)) return undefined;
    var _a = clamp(crt__num(crt__field(_o, "alpha", 1)), 0, 1);
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_one, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    draw_sprite_ext(_spr, 0, _x, _y, 1, 1, 0, make_colour_rgb(255 * _a, 255 * _a, 255 * _a), _a);
    gpu_pop_state();
    if (crt__field(_o, "caret", true) != false) crt_draw_caret(_spec, _x, _y, _w, _h, crt__num(crt__field(_o, "phase", 0)), _a);
    return _L;
}

/// @function crt_draw_caret(spec, x, y, w, h, [phase], [alpha])
/// @description Only the advance caret for the box in (x, y, w, h) - the speaker's own mark, in the field's solved
/// ink, moved by `phase` 0..1 (drive it from your own counter; phase 0 is the still). Draw it when the page has
/// finished typing.
function crt_draw_caret(_spec, _x, _y, _w, _h, _phase = 0, _alpha = 1) {
    var _L = crt_layout(_spec, _w, _h);
    var _car = crt_look("carets", crt__field(_spec, "caret", ""));
    var _sv = crt__solve(_spec);
    if (is_undefined(_L) || is_undefined(_car) || is_undefined(_sv)) return false;
    var _ctx = crt_cx_create(1);
    _ctx.alpha = clamp(_alpha, 0, 1);
    crt_caret_mark(_ctx, _x + _L.fx + _L.fw - _L.base * 0.9, _y + _L.fy + _L.fh - _L.base * 0.9, _L.base * 0.8, _car.form, _car.motion, is_numeric(_phase) ? _phase : 0, _sv.ink, _sv.dim);
    return true;
}

/// @function crt_portrait_sprite(spec, w, h, sprite, [subimg])
/// @description YOUR portrait sprite fitted into the speaker's aperture: scaled to cover it (aspect kept, anchored at
/// the top, where a face is), clipped to the aperture's own outline and faded out over its last quarter, so the bust
/// sinks into the recess instead of being cut off square. A NEW premultiplied sprite the size of the aperture
/// (crt_reserve); yours to sprite_delete(). undefined for a bad spec, size or sprite.
function crt_portrait_sprite(_spec, _w, _h, _sprite, _sub = 0) {
    var _rv = crt_reserve(_spec, _w, _h);
    if (is_undefined(_rv) || !is_numeric(_sprite) || !sprite_exists(_sprite)) return undefined;
    var _ss = 2, _rw = ceil(_rv.w), _rh = ceil(_rv.h);
    var _sw = sprite_get_width(_sprite), _sh = sprite_get_height(_sprite);
    if (_sw <= 0 || _sh <= 0 || _rw < 4 || _rh < 4) return undefined;
    var _k = max(_rw / _sw, _rh / _sh);
    var _big = surface_create(_rw * _ss, _rh * _ss);
    gpu_push_state();
    surface_set_target(_big);
    draw_clear_alpha(c_black, 0);
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_texfilter(true);
    draw_sprite_ext(_sprite, _sub, (_rw - _sw * _k) / 2 * _ss + sprite_get_xoffset(_sprite) * _k * _ss, sprite_get_yoffset(_sprite) * _k * _ss, _k * _ss, _k * _ss, 0, c_white, 1);
    // erase everything outside the aperture (the rect minus the aperture, even-odd), then fade the foot
    gpu_set_blendmode_ext(bm_zero, bm_inv_src_alpha);
    var _ctx = crt_cx_create(_ss);
    crt_reserve_path(_ctx, 0, 0, _rw, _rh, _rv.head);
    var _ring = crt_cx__rings(_ctx);
    var _all = [[-2, -2], [_rw * _ss + 2, -2], [_rw * _ss + 2, _rh * _ss + 2], [-2, _rh * _ss + 2]];
    if (array_length(_ring) > 0) crt_cx__fill(_ctx, [_all, _ring[0]], crt_cx_solid([0, 0, 0]), 1, CRT_FILL_EVENODD);
    var _fade = crt_cx_linear(_ctx, 0, _rh * 0.74, 0, _rh);
    crt_cx_stop(_fade, 0, [0, 0, 0], 0); crt_cx_stop(_fade, 1, [0, 0, 0], 1);
    _ctx.fill = _fade;
    crt_cx_fill_rect(_ctx, 0, _rh * 0.74, _rw, _rh * 0.26 + 1);
    surface_reset_target();
    var _small = surface_create(_rw, _rh);
    surface_set_target(_small);
    draw_clear_alpha(c_black, 0);
    gpu_set_blendenable(false);
    draw_surface_ext(_big, 0, 0, 1 / _ss, 1 / _ss, 0, c_white, 1);
    surface_reset_target();
    gpu_pop_state();
    var _spr = sprite_create_from_surface(_small, 0, 0, _rw, _rh, false, false, 0, 0);
    surface_free(_big); surface_free(_small);
    return _spr;
}

/// @function crt_draw_portrait(spec, x, y, w, h, sprite, [subimg], [alpha])
/// @description Draw YOUR portrait sprite into the aperture of the box in (x, y, w, h) - fitted, clipped to the
/// aperture's outline and foot-faded (cached like the box). Draw the box first with {portrait: true}. Returns false for
/// a bad spec, size or sprite.
function crt_draw_portrait(_spec, _x, _y, _w, _h, _sprite, _sub = 0, _alpha = 1) {
    var _rv = crt_reserve(_spec, _w, _h);
    if (is_undefined(_rv) || !is_numeric(_sprite) || !sprite_exists(_sprite)) return false;
    var _key = "por|" + crt_spec_key(_spec) + "|" + string(ceil(_w)) + "x" + string(ceil(_h)) + "|" + sprite_get_name(_sprite) + "#" + string(_sprite) + "|" + string(_sub);
    var _spr = crt__cache_get(_key, method({ s: _spec, w: _w, h: _h, sp: _sprite, sb: _sub }, function() { return crt_portrait_sprite(s, w, h, sp, sb); }));
    if (is_undefined(_spr)) return false;
    var _a = clamp(crt__num(_alpha), 0, 1);
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_one, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    draw_sprite_ext(_spr, 0, _x + floor(_rv.x), _y + floor(_rv.y), 1, 1, 0, make_colour_rgb(255 * _a, 255 * _a, 255 * _a), _a);
    gpu_pop_state();
    return true;
}
