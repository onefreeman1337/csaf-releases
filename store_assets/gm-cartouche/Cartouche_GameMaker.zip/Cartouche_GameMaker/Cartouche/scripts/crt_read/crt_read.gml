/// crt_read.gml - reads a SPEAKER into a box specification: who is talking, and therefore what their message box is
/// made of. Draws nothing.
///
/// Cartouche - The Message Box Drawn as an Object, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// HOW A SPEAKER BECOMES AN OBJECT
///   KIND  (who they are)     -> the TRADITION the object belongs to: which materials exist at all, which frame
///                               constructions, bands, corners, plates, grounds and carets.
///   RANK  (what they carry)  -> how much WORK the object carries: a WINDOW into the tradition's own ordering, how
///                               many bands run round the frame, which corners and plates are reachable.
///   HASH  (which individual) -> freedom, and only where freedom is meaningless: which of the equivalent grounds,
///                               which tint inside the material's range, which caret.
/// ⛔ The axes were once independent slices of one hash, so a goblin could draw a temple spirit's material and a
/// sovereign a plain rim: the boxes DIFFERED without MEANING anything. A tradition throws a small, a standard and a
/// great version of each job, and they are different FORMS, not one form at three sizes.
///
/// A SPEAKER is a struct; every field is optional:
///   name      the name struck into the nameplate, and part of who the speaker is
///   kind      "company" (the party), "commons" (the town), "adversary" (the enemy), "bestial" (the wild) or
///             "numinous" (spirits, gods) - or an alias (party, hero, town, villager, enemy, villain, monster, beast,
///             spirit, god ...). Any other word is assigned to one of the five by hash, never dropped. Default commons.
///   slot      a number telling apart two speakers of one kind and name (default 0)
///   rank      0..4 or "plain" "kept" "worked" "honoured" "sovereign"; omitted, it is read from the kind and identity
///   level     an actor's level: a level RAISED above 1 decides the rank (a level of 1 says nothing)
///   title     an actor's title or epithet: a non-empty one lifts the rank one step
///   bounty    an enemy's worth (gold, xp, threat): 5, 8, 15 and 50 are the steps
///   identity  a string that replaces the automatic identity (two speakers with one identity share a box)
/// level, title and bounty are read only when the speaker has a name, as the original reads its database by name.

/// @function crt_kinds()
/// @description The five traditions, in their fixed order. Pure.
function crt_kinds() { return ["company", "commons", "adversary", "bestial", "numinous"]; }

/// @function crt_ranks()
/// @description The five ranks, low to high. Pure.
function crt_ranks() { return ["plain", "kept", "worked", "honoured", "sovereign"]; }

/// @function crt__aliases()
/// @description Kind words and aliases -> tradition. Built once. Internal.
function crt__aliases() {
    if (variable_global_exists("crt__alias_table") && is_struct(global.crt__alias_table)) return global.crt__alias_table;
    global.crt__alias_table = {
        company: "company", party: "company", hero: "company", heroine: "company", ally: "company", companion: "company", actor: "company",
        commons: "commons", town: "commons", townsfolk: "commons", villager: "commons", npc: "commons", people: "commons", common: "commons",
        adversary: "adversary", enemy: "adversary", villain: "adversary", foe: "adversary", evil: "adversary", rival: "adversary",
        bestial: "bestial", wild: "bestial", monster: "bestial", beast: "bestial", creature: "bestial", animal: "bestial",
        numinous: "numinous", spirit: "numinous", god: "numinous", goddess: "numinous", divine: "numinous", nature: "numinous", ghost: "numinous"
    };
    return global.crt__alias_table;
}

/// @function crt_vocab()
/// @description THE VOCABULARY, declared once. ORDERED axes (materials, profiles, plates, corners) run PLAIN -> RICH
/// and rank windows into them; PEER axes (bands, grounds, carets) are equals the hash picks among. crt_corpus.gml says
/// what each id LOOKS like and the suite asserts the two agree in both directions. Built once.
function crt_vocab() {
    if (variable_global_exists("crt__vocab_table") && is_struct(global.crt__vocab_table)) return global.crt__vocab_table;
    global.crt__vocab_table = {
        // The party. Kept, personal, heraldic: leather, planed wood, brass, enamel.
        company: {
            materials: ["waxed-oak", "limed-ash", "tooled-leather", "pewter-bound", "brass-bound-walnut", "silvered-steel", "enamelled-bronze", "gilt-and-garnet"],
            profiles: ["panel", "bound", "battened", "moulded", "arcaded", "canopied"],
            bands: ["bead", "cable", "chevron", "punched", "reed", "guilloche"],
            corners: ["square", "cut", "shouldered", "lapped", "scrolled", "crested"],
            plates: ["ruled", "strap-tag", "stamped-band", "let-in-tablet", "enamel-lozenge", "chased-cartouche", "crested-tablet"],
            grounds: ["smooth-gesso", "combed", "stippled", "figured-grain"],
            carets: ["chevron", "lozenge", "pennon"]
        },
        // The town. Humble, hand-worked, honest - and the commonest speaker in any game.
        commons: {
            materials: ["limewash-board", "rush-woven", "pine-plank", "waxed-hide", "tinned-iron", "polished-slate", "glazed-earthenware", "brass-bound-elm"],
            profiles: ["plank", "pegged", "battened", "framed", "moulded", "gabled"],
            bands: ["peg", "nailhead", "rope", "notch", "scallop", "chip-carved"],
            corners: ["square", "cut", "lapped", "pegged-scroll", "bracketed", "finialled"],
            plates: ["chalked", "nailed-tag", "burnt-brand", "painted-panel", "sign-board", "carved-tablet", "gilded-board"],
            grounds: ["brushed-lime", "sawn", "worn-scrub", "slip-poured"],
            carets: ["wedge", "drop", "nail"]
        },
        // The enemy. Hard, dark, cut, cold.
        adversary: {
            materials: ["pitch-lacquer", "blackened-iron", "raw-slag", "tarnished-silver", "obsidian", "bloodstone", "jet-and-gilt", "black-enamel-and-gold"],
            profiles: ["strapped", "riveted", "barred", "fluted", "spined", "throned"],
            bands: ["rivet", "barb", "fret", "chain", "saw", "serpentine"],
            corners: ["square", "clipped", "spurred", "hooked", "taloned", "crowned"],
            plates: ["scored", "riveted-tag", "branded-strip", "inlaid-strip", "gilt-cartouche", "crowned-boss", "jewelled-boss"],
            grounds: ["hammered", "pitted", "soot-blacked", "polished-void"],
            carets: ["barb", "spike", "ember"]
        },
        // The wild. Organic, irregular, spliced from what a creature is made of.
        bestial: {
            materials: ["raw-hide", "bleached-bone", "bark-and-sinew", "dark-horn", "chitin", "petrified-wood", "ivory-and-sinew", "amber-and-ivory"],
            profiles: ["spliced", "lashed", "ribbed", "plated", "antlered", "crowned-antler"],
            bands: ["lashing", "tooth", "scale", "bristle", "scored", "feathered"],
            corners: ["broken", "snagged", "curled", "tusked", "horned", "crested-horn"],
            plates: ["scratched", "sinew-tag", "burnt-mark", "set-tooth", "inlaid-shell", "crowned-horn", "gilded-tusk"],
            grounds: ["porous", "grained-horn", "pebbled-hide", "waxed-shell"],
            carets: ["claw", "fang", "quill"]
        },
        // Spirits, gods, the other side. Luminous, translucent, grown rather than made.
        numinous: {
            materials: ["river-stone", "hoarfrost", "living-wood", "moon-glass", "sea-glass", "stained-glass", "star-iron", "nacre-and-gold"],
            profiles: ["waterworn", "grown", "woven-light", "tracery", "radiant", "aureoled"],
            bands: ["came", "frond", "dewline", "rune", "ray", "spiral"],
            corners: ["rounded", "budded", "leafed", "flowering", "rayed", "haloed"],
            plates: ["etched", "leaf-tag", "frosted-panel", "glass-lozenge", "lit-panel", "haloed-tablet", "star-set-tablet"],
            grounds: ["veiled", "rippled", "mossed", "starred"],
            carets: ["mote", "leaf", "star"]
        }
    };
    return global.crt__vocab_table;
}

/// @function crt_rank_base(kind)
/// @description Where a tradition SITS on the rank scale before anything else is known: a spirit's box is grander than
/// a fishwife's before either has a name. ⛔ Never at the ends of the scale - the reading spreads one step either way,
/// and a base of 0 would clamp two of three outcomes onto one rank. Pure.
function crt_rank_base(_kind) {
    switch (_kind) {
        case "company": return 2; case "commons": return 1; case "adversary": return 2;
        case "bestial": return 1; case "numinous": return 3;
    }
    return 1;
}

/// @function crt__window(axis)
/// @description How wide a window each ORDERED axis gives the individual. ⛔ materials is 3, not 4: a wider window
/// OVERLAPS its neighbours more, and 400 synthetic towns measured more collisions at 4 (90.8%) than at 3 (74.8%). Pure.
function crt__window(_axis) {
    switch (_axis) { case "materials": return 3; case "profiles": return 2; case "plates": return 2; case "corners": return 2; }
    return 1;
}

/// @function crt_bands_for_work(work)
/// @description How many bands run round the frame at work 0..4 (the two humblest ranks differ structurally). Pure.
function crt_bands_for_work(_work) { var _b = [1, 2, 2, 3, 3]; return _b[clamp(_work, 0, 4)]; }

/// @function crt_window_start(n, w, work)
/// @description The lowest index of the rank window into an ordered vocabulary of n entries, window w, work 0..4:
/// a plain speaker draws only from the humble end, a sovereign only from the rich end. Pure.
function crt_window_start(_n, _w, _work) {
    if (_n <= _w) return 0;
    var _lo = crt_jsround((_work / 4) * (_n - _w));
    return max(0, min(_n - _w, _lo));
}

/// @function crt__stream(identity, axis)
/// @description An independent hash stream for one axis (salted, never bit-sliced from one hash). The identity and the
/// axis are joined by the control character U+0001, as in the original - a separator no name can contain, so
/// "ab" + "c" and "a" + "bc" never share a stream. Internal.
function crt__stream(_id, _axis) { return crt_hash(string(_id) + chr(1) + string(_axis)); }

/// @function crt__pick_windowed(list, w, work, h)
/// @description One entry from an ordered vocabulary inside the rank window. Internal.
function crt__pick_windowed(_list, _w, _work, _h) {
    var _n = array_length(_list), _width = min(_w, _n);
    var _lo = crt_window_start(_n, _width, _work);
    return _list[_lo + (_h mod _width)];
}

/// @function crt__pick_distinct(list, count, h)
/// @description `count` DISTINCT entries from a peer vocabulary (a partial Fisher-Yates on a 32-bit xorshift): two
/// identical bands are the same treatment drawn twice, not a second treatment. Internal.
function crt__pick_distinct(_list, _count, _h) {
    var _pool = [], _out = [], _i;
    for (_i = 0; _i < array_length(_list); _i++) array_push(_pool, _list[_i]);
    var _seed = _h & $FFFFFFFF;
    var _take = min(_count, array_length(_pool));
    for (_i = 0; _i < _take; _i++) {
        _seed = (_seed ^ ((_seed << 13) & $FFFFFFFF)) & $FFFFFFFF;
        _seed = (_seed ^ (_seed >> 17)) & $FFFFFFFF;
        _seed = (_seed ^ ((_seed << 5) & $FFFFFFFF)) & $FFFFFFFF;
        var _k = _seed mod array_length(_pool);
        array_push(_out, _pool[_k]);
        array_delete(_pool, _k, 1);
    }
    return _out;
}

/// @function crt__num(v)
/// @description A numeric field as a number, 0 when absent or not a number. Internal.
function crt__num(_v) {
    if (is_numeric(_v)) return is_nan(_v) || is_infinity(_v) ? 0 : _v;
    if (is_string(_v)) { var _t = string_trim(_v); if (_t != "" && string_digits(_t) == _t) return real(_t); }
    return 0;
}

/// @function crt__field(struct, name, default)
/// @description A field of a buyer's struct, or the default when it is missing. Internal.
function crt__field(_s, _k, _d) { return (is_struct(_s) && variable_struct_exists(_s, _k) && !is_undefined(_s[$ _k])) ? _s[$ _k] : _d; }

/// @function crt_kind_of(word)
/// @description The tradition for a kind word or alias; any other word is assigned by hash (never dropped), and an
/// empty one is the town. Pure.
function crt_kind_of(_word) {
    var _k = string_lower(string_trim(string(_word)));
    if (_k == "") return "commons";
    var _al = crt__aliases();
    if (variable_struct_exists(_al, _k)) return _al[$ _k];
    var _ks = crt_kinds();
    return _ks[crt_hash(_k) mod 5];
}

/// @function crt__face_work(kindword, slot, name)
/// @description The always-available reading of standing: the tradition's base, spread one step either way by the
/// speaker's identity. Internal.
function crt__face_work(_kw, _slot, _name) {
    var _base = crt_rank_base(crt_kind_of(_kw));
    var _spread = crt_hash(_kw + ":" + string(_slot) + ":" + _name) mod 3;
    return clamp(_base - 1 + _spread, 0, 4);
}

/// @function crt__rank_of(sp, kindword, slot, name)
/// @description Rank from enrichment when the speaker gives any, else from the face reading. ⛔ A level of 1 is the
/// engine default in most games and is evidence of nothing, so only a RAISED level outranks the reading. Internal.
function crt__rank_of(_sp, _kw, _slot, _name) {
    var _base = crt__face_work(_kw, _slot, _name);
    var _ranks = crt_ranks();
    if (_name != "") {
        var _hasLevel = is_struct(_sp) && variable_struct_exists(_sp, "level") && !is_undefined(_sp.level);
        var _hasTitle = is_struct(_sp) && variable_struct_exists(_sp, "title") && !is_undefined(_sp.title);
        if (_hasLevel || _hasTitle) {
            var _lv = _hasLevel ? crt__num(_sp.level) : 0;
            var _w = (_lv > 1) ? ((_lv >= 40) ? 4 : ((_lv >= 25) ? 3 : ((_lv >= 12) ? 2 : ((_lv >= 5) ? 1 : 0)))) : _base;
            if (_hasTitle && string_trim(string(_sp.title)) != "") _w += 1;
            return _ranks[clamp(_w, 0, 4)];
        }
        var _g = crt__num(crt__field(_sp, "bounty", 0));
        if (_g > 0) return _ranks[(_g >= 50) ? 4 : ((_g >= 15) ? 3 : ((_g >= 8) ? 2 : ((_g >= 5) ? 1 : 0)))];
    }
    return _ranks[_base];
}

/// @function crt_read(speaker)
/// @description Read a speaker (see the top of this file) into a box SPEC: {kind, rank, work, identity, material,
/// profile, plate, corner, bands[], ground, caret, tint}. Deterministic: the same speaker gives the same box on every
/// machine. Never throws: a missing or wrong field falls back as documented.
function crt_read(_sp) {
    if (!is_struct(_sp)) _sp = {};
    var _kw = string_lower(string_trim(string(crt__field(_sp, "kind", ""))));
    // a whole number: string(2.5) is "2.50" in GML and "2.5" in the original, and the slot is part of the identity
    var _slot = floor(crt__num(crt__field(_sp, "slot", 0)));
    var _name = string(crt__field(_sp, "name", ""));
    var _kind = crt_kind_of(_kw);
    var _ranks = crt_ranks();
    var _rank = crt__field(_sp, "rank", undefined);
    if (is_numeric(_rank)) _rank = (_rank == floor(_rank) && _rank >= 0 && _rank <= 4) ? _ranks[_rank] : string(_rank);
    if (is_undefined(_rank) || _rank == "") _rank = crt__rank_of(_sp, _kw, _slot, _name);
    _rank = string_lower(string(_rank));
    var _work = -1;
    for (var _i = 0; _i < 5; _i++) if (_ranks[_i] == _rank) _work = _i;
    if (_work < 0) { _rank = _ranks[0]; _work = 0; }
    var _idf = crt__field(_sp, "identity", "");
    var _identity = (is_string(_idf) && _idf != "") ? _idf : (_kw + "#" + string(_slot) + "#" + _name);
    var _voc = crt_vocab();
    var _V = _voc[$ _kind];
    return {
        kind: _kind, rank: _rank, work: _work, identity: _identity,
        material: crt__pick_windowed(_V.materials, crt__window("materials"), _work, crt__stream(_identity, "material")),
        profile: crt__pick_windowed(_V.profiles, crt__window("profiles"), _work, crt__stream(_identity, "profile")),
        plate: crt__pick_windowed(_V.plates, crt__window("plates"), _work, crt__stream(_identity, "plate")),
        corner: crt__pick_windowed(_V.corners, crt__window("corners"), _work, crt__stream(_identity, "corner")),
        bands: crt__pick_distinct(_V.bands, crt_bands_for_work(_work), crt__stream(_identity, "bands")),
        ground: _V.grounds[crt__stream(_identity, "ground") mod array_length(_V.grounds)],
        caret: _V.carets[crt__stream(_identity, "caret") mod array_length(_V.carets)],
        tint: crt__stream(_identity, "tint") mod 3
    };
}

/// @function crt_speaker(name, kind, [slot], [rank])
/// @description Shorthand for crt_read({name, kind, slot, rank}).
function crt_speaker(_name, _kind, _slot = 0, _rank = undefined) {
    var _s = { name: _name, kind: _kind, slot: _slot };
    if (!is_undefined(_rank)) _s.rank = _rank;
    return crt_read(_s);
}

/// @function crt_spec_key(spec)
/// @description Every axis a player could tell apart, joined (identity deliberately left out). Pure.
function crt_spec_key(_s) {
    if (!is_struct(_s)) return "";
    var _f = function(_t, _k) { return string(crt__field(_t, _k, "")); };
    return _f(_s, "kind") + "|" + _f(_s, "rank") + "|" + _f(_s, "material") + "|" + _f(_s, "profile") + "|" + _f(_s, "corner") + "|"
        + crt__join(crt__field(_s, "bands", []), "+") + "|" + _f(_s, "plate") + "|" + _f(_s, "ground") + "|" + _f(_s, "caret") + "|" + _f(_s, "tint");
}

/// @function crt_silhouette_key(spec)
/// @description What separates two boxes ACROSS A ROOM: material, construction, corner, bands. Pure. "" for a non-spec.
function crt_silhouette_key(_s) {
    if (!is_struct(_s)) return "";
    return string(crt__field(_s, "material", "")) + "|" + string(crt__field(_s, "profile", "")) + "|" + string(crt__field(_s, "corner", "")) + "|" + crt__join(crt__field(_s, "bands", []), "+");
}

/// @function crt__join(array, sep)
/// @description Join an array's entries as strings. Internal.
function crt__join(_a, _sep) {
    var _o = "";
    if (!is_array(_a)) return _o;
    for (var _i = 0; _i < array_length(_a); _i++) _o += ((_i > 0) ? _sep : "") + string(_a[_i]);
    return _o;
}

/// @function crt_describe(spec)
/// @description A one-line plain description of a spec, derived from it (for a caption or a debug overlay), e.g.
/// "worked - polished slate - battened - lapped corners". ASCII only. Pure.
function crt_describe(_s) {
    if (!is_struct(_s)) return "";
    return string(_s.rank) + " - " + string_replace_all(string(_s.material), "-", " ") + " - " + string_replace_all(string(_s.profile), "-", " ") + " - " + string_replace_all(string(_s.corner), "-", " ") + " corners";
}
