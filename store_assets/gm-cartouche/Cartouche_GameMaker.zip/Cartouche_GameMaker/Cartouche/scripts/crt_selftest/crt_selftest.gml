/// crt_selftest.gml - the in-engine suite (`Cartouche.exe -selftest` writes crt_selftest.json). Stage 99 = the suite
/// reached its end. Not needed at runtime: delete it with the -selftest branch of the demo object's Create event.
///
/// Cartouche - The Message Box Drawn as an Object, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// What it holds the port to: the published RPG Maker MZ original's own answers (crt_oracle.gml) for every spec, every
/// ink and every draw report - how many paths, fills, strokes and rectangles each box draws, so a branch dropped in
/// the port shows as a count that moved. What it measures on pixels: ink, containment inside the rect, determinism,
/// premultiplied edges, the portrait clip, the caret's motion and the cache. ⛔ Every picture claim is INK counted on a
/// rendered surface, never "a sprite exists"; every ink assertion has a control. Surface bytes read R, G, B, A.

function crt_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 80) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
function crt_st_stage(_st, _n) { _st.stage = _n; global.crt_stage = _n; }
function crt_st_note(_st, _s) { array_push(_st.notes, _s); }
function crt_st_near(_a, _b, _tol = 0.0001) { return is_numeric(_a) && is_numeric(_b) && abs(_a - _b) <= _tol; }
function crt_st_rgb_eq(_a, _b) { return is_array(_a) && is_array(_b) && array_length(_a) == 3 && array_length(_b) == 3 && _a[0] == _b[0] && _a[1] == _b[1] && _a[2] == _b[2]; }
function crt_st_arr_eq(_a, _b) {
    if (!is_array(_a) || !is_array(_b) || array_length(_a) != array_length(_b)) return false;
    for (var _i = 0; _i < array_length(_a); _i++) if (_a[_i] != _b[_i]) return false;
    return true;
}

/// @function crt_st_grab_sprite(sprite)
/// @description A sprite's raw pixels {b, w, h}, drawn with blending OFF (bytes R, G, B, A).
function crt_st_grab_sprite(_spr) {
    var _w = sprite_get_width(_spr), _h = sprite_get_height(_spr);
    var _sf = surface_create(_w, _h);
    surface_set_target(_sf); draw_clear_alpha(c_black, 0); gpu_set_blendenable(false); draw_sprite(_spr, 0, 0, 0); gpu_set_blendenable(true); surface_reset_target();
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    surface_free(_sf);
    return { b: _b, w: _w, h: _h };
}

/// @function crt_st_grab_surface(surface)
function crt_st_grab_surface(_sf) {
    var _w = surface_get_width(_sf), _h = surface_get_height(_sf);
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    return { b: _b, w: _w, h: _h };
}

/// @function crt_st_px(grab, x, y)
/// @description [r, g, b, a] of one pixel.
function crt_st_px(_g, _x, _y) {
    var _o = (clamp(floor(_y), 0, _g.h - 1) * _g.w + clamp(floor(_x), 0, _g.w - 1)) * 4;
    return [buffer_peek(_g.b, _o, buffer_u8), buffer_peek(_g.b, _o + 1, buffer_u8), buffer_peek(_g.b, _o + 2, buffer_u8), buffer_peek(_g.b, _o + 3, buffer_u8)];
}

/// @function crt_st_count(grab, x0, y0, x1, y1, pred)
/// @description How many pixels in [x0, x1) x [y0, y1) satisfy pred(r, g, b, a).
function crt_st_count(_g, _x0, _y0, _x1, _y1, _pred) {
    var _n = 0;
    for (var _y = max(0, _y0); _y < min(_g.h, _y1); _y++) {
        for (var _x = max(0, _x0); _x < min(_g.w, _x1); _x++) {
            var _o = (_y * _g.w + _x) * 4;
            if (_pred(buffer_peek(_g.b, _o, buffer_u8), buffer_peek(_g.b, _o + 1, buffer_u8), buffer_peek(_g.b, _o + 2, buffer_u8), buffer_peek(_g.b, _o + 3, buffer_u8))) _n++;
        }
    }
    return _n;
}

/// @function crt_st_same(a, b)
/// @description Pixels differing between two grabs of one size (any channel).
function crt_st_same(_a, _b) {
    if (_a.w != _b.w || _a.h != _b.h) return -1;
    var _n = 0;
    for (var _o = 0; _o < _a.w * _a.h * 4; _o++) if (buffer_peek(_a.b, _o, buffer_u8) != buffer_peek(_b.b, _o, buffer_u8)) _n++;
    return _n;
}

/// @function crt_selftest_run()
/// @description Run every stage; returns {total, pass, fail, stage, notes, failures, metrics}.
function crt_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, stage: 0, notes: [], failures: [], metrics: {} }, _i, _j, _k;
    var _A = crt_oracle_arith();

    // ---- 1: the pure arithmetic, against the original ----
    crt_st_stage(_st, 1);
    var _bad = 0;
    for (_i = 0; _i < array_length(_A.nz); _i++) if (!crt_st_near(crt_nz(_A.nz[_i][0]), _A.nz[_i][1], 0.0000001)) { _bad++; crt_st_note(_st, "nz(" + string(_A.nz[_i][0]) + ") = " + string_format(crt_nz(_A.nz[_i][0]), 1, 12) + " want " + string_format(_A.nz[_i][1], 1, 12)); }
    crt_st_assert(_st, _bad == 0 && array_length(_A.nz) >= 10, "crt_nz matches the original on " + string(array_length(_A.nz) - _bad) + " of " + string(array_length(_A.nz)) + " inputs (fractional, negative, past 2^32)");
    _bad = 0;
    for (_i = 0; _i < array_length(_A.hash); _i++) if (crt_hash(_A.hash[_i][0]) != _A.hash[_i][1]) _bad++;
    crt_st_assert(_st, _bad == 0, "crt_hash matches the original FNV-1a on every string (" + string(_bad) + " wrong)");
    _bad = 0;
    for (_i = 0; _i < array_length(_A.windows); _i++) { var _wv = _A.windows[_i]; if (crt_window_start(_wv[0], _wv[1], _wv[2]) != _wv[3]) _bad++; }
    crt_st_assert(_st, _bad == 0 && array_length(_A.windows) == 80, "the rank window matches on all " + string(array_length(_A.windows)) + " (n, w, work) triples (" + string(_bad) + " wrong)");
    _bad = 0;
    for (_i = 0; _i < array_length(_A.repeats); _i++) {
        var _ra = _A.repeats[_i][0];
        var _rr = (array_length(_ra) > 3) ? crt_repeats_for(_ra[0], _ra[1], _ra[2], _ra[3]) : crt_repeats_for(_ra[0], _ra[1], _ra[2]);
        if (_rr.count != _A.repeats[_i][1] || !crt_st_near(_rr.pitch, _A.repeats[_i][2]) || _rr.floored != _A.repeats[_i][3]) _bad++;
    }
    crt_st_assert(_st, _bad == 0, "the pitch law (count, pitch, floored) matches on every case (" + string(_bad) + " wrong)");
    _bad = 0;
    for (_i = 0; _i < array_length(_A.relief); _i++) { var _rl = _A.relief[_i]; if (!crt_st_rgb_eq(crt_relief(_rl[0], _rl[1], _rl[2]), _rl[3])) _bad++; }
    crt_st_assert(_st, _bad == 0, "relief (the absolute-separation rule) matches on all " + string(array_length(_A.relief)) + " cases (" + string(_bad) + " wrong)");
    var _inkBad = 0, _aaa = 0, _aa = 0, _minRatio = 99;
    for (_i = 0; _i < array_length(_A.inks); _i++) {
        var _row = _A.inks[_i], _mat = crt_look("materials", _row[0]), _gnd = crt_look("grounds", _row[1]);
        var _ink = crt_ink_for(_mat.field, _mat.frame, CRT_AAA_RATIO, _gnd.amp);
        if (!crt_st_rgb_eq(_ink, _row[2])) _inkBad++;
        var _pale = crt_lum(_ink) > crt_lum(_mat.field);
        var _ratio = crt_contrast(_ink, crt_field_extreme(_mat.field, _gnd.amp, _pale));
        _minRatio = min(_minRatio, _ratio);
        if (_ratio >= 7) _aaa++;
        if (_ratio >= 4.5) _aa++;
    }
    crt_st_assert(_st, _inkBad == 0 && array_length(_A.inks) == 160, "the solved ink matches the original for all " + string(array_length(_A.inks)) + " material x ground pairs (" + string(_inkBad) + " wrong)");
    crt_st_assert(_st, _aa == array_length(_A.inks), "every ink clears WCAG AA (4.5:1) against its ground's LEAST legible excursion (" + string(_aa) + " of " + string(array_length(_A.inks)) + ")");
    _st.metrics.ink_aaa = _aaa; _st.metrics.ink_pairs = array_length(_A.inks); _st.metrics.ink_min_ratio = _minRatio;
    crt_st_note(_st, "inks: " + string(_aaa) + " of " + string(array_length(_A.inks)) + " at AAA 7:1, worst " + string_format(_minRatio, 1, 2) + ":1");
    _bad = 0;
    for (_i = 0; _i < array_length(_A.lettering); _i++) {
        var _lr = _A.lettering[_i], _ly = crt_lettering_layers(_lr[1], [120, 74, 48], _lr[0], 7);
        if (array_length(_ly) != array_length(_lr[2])) { _bad++; continue; }
        for (_j = 0; _j < array_length(_ly); _j++) {
            var _want = _lr[2][_j];
            if (!crt_st_rgb_eq(_ly[_j].colour, _want[0]) || !crt_st_near(_ly[_j].dx, _want[1]) || !crt_st_near(_ly[_j].dy, _want[2]) || !crt_st_near(_ly[_j].alpha, _want[3]) || _ly[_j].bold != _want[4]) _bad++;
        }
    }
    crt_st_assert(_st, _bad == 0, "nameplate lettering layers match for all five lettering modes on three plates (" + string(_bad) + " wrong)");
    _bad = 0;
    for (_i = 0; _i < array_length(_A.max_frame); _i++) if (crt_max_frame_height(_A.max_frame[_i][0]) != _A.max_frame[_i][1]) _bad++;
    crt_st_assert(_st, _bad == 0, "the largest frame allowance matches at 816, 560 and 1024 px");
    // a positive control: the arithmetic CAN disagree (a nudged input moves the answer)
    crt_st_assert(_st, crt_nz(12345) != crt_nz(12346) && crt_hash("a") != crt_hash("b"), "control: the noise and the hash move when their input moves");

    // ---- 2: the vocabulary and the corpus agree, both directions ----
    crt_st_stage(_st, 2);
    var _axes = ["materials", "profiles", "bands", "corners", "plates", "grounds", "carets"], _voc = crt_vocab(), _kinds = crt_kinds();
    var _missing = 0, _used = {};
    for (_i = 0; _i < 5; _i++) {
        var _V = _voc[$ _kinds[_i]];
        for (_j = 0; _j < array_length(_axes); _j++) {
            var _list = _V[$ _axes[_j]];
            for (_k = 0; _k < array_length(_list); _k++) { if (is_undefined(crt_look(_axes[_j], _list[_k]))) _missing++; _used[$ _axes[_j] + ":" + _list[_k]] = true; }
        }
    }
    var _unreach = 0, _total = 0, _corp = crt_corpus();
    // ⛔ an accessor on a CALL RESULT (`crt_corpus()[$ k]`) inside a loop crashed the asset compiler itself
    // (NullReferenceException in GMLNewArrayAccessors.RewriteArrayRef, runtime 2024.14.4.268): read it into a local
    for (_j = 0; _j < array_length(_axes); _j++) {
        var _ids = variable_struct_get_names(_corp[$ _axes[_j]]);
        _total += array_length(_ids);
        for (_k = 0; _k < array_length(_ids); _k++) if (!variable_struct_exists(_used, _axes[_j] + ":" + _ids[_k])) _unreach++;
    }
    crt_st_assert(_st, _missing == 0 && _unreach == 0 && _total == 194, "every id a speaker can resolve to has an appearance, and every appearance is reachable (" + string(_total) + " entries, " + string(_missing) + " missing, " + string(_unreach) + " unreachable)");
    crt_st_assert(_st, crt_corpus_count("materials") == 40 && crt_corpus_count("profiles") == 28 && crt_corpus_count("corners") == 26 && crt_corpus_count("grounds") == 20, "the corpus holds 40 materials, 28 constructions, 26 corners and 20 grounds");
    crt_st_assert(_st, is_undefined(crt_look("materials", "unobtainium")) && is_undefined(crt_look("nope", "waxed-oak")) && is_undefined(crt_look(3, 4)), "an unknown axis or id is undefined, never a silent default");
    _bad = 0;
    for (_i = 0; _i < array_length(_A.aliases); _i++) if (crt_kind_of(_A.aliases[_i][0]) != _A.aliases[_i][1]) _bad++;
    crt_st_assert(_st, _bad == 0 && array_length(_A.aliases) >= 30, "all " + string(array_length(_A.aliases)) + " kind words resolve to the tradition the oracle used (" + string(_bad) + " wrong)");

    // ---- 3: every spec, against the original ----
    crt_st_stage(_st, 3);
    var _cast = crt_oracle_cast(), _fx = crt_oracle_fixtures();
    var _sets = [_cast, _fx], _specBad = 0, _specN = 0;
    for (var _s = 0; _s < 2; _s++) {
        for (_i = 0; _i < array_length(_sets[_s]); _i++) {
            var _want = _sets[_s][_i].spec, _got = crt_read(_sets[_s][_i].speaker);
            _specN++;
            var _ok = _got.kind == _want.kind && _got.rank == _want.rank && _got.work == _want.work && _got.identity == _want.identity
                && _got.material == _want.material && _got.profile == _want.profile && _got.plate == _want.plate && _got.corner == _want.corner
                && crt_st_arr_eq(_got.bands, _want.bands) && _got.ground == _want.ground && _got.caret == _want.caret && _got.tint == _want.tint;
            if (!_ok) { _specBad++; if (_specBad <= 6) crt_st_note(_st, "spec mismatch for '" + string(crt__field(_sets[_s][_i].speaker, "name", "")) + "': got " + _got.identity + " " + crt_spec_key(_got) + " want " + _want.identity + " " + crt_spec_key(_want)); }
        }
    }
    crt_st_assert(_st, _specBad == 0 && _specN == 47, "all " + string(_specN) + " speakers (cast and edge fixtures) read to the original's spec, every field (" + string(_specBad) + " wrong)");
    var _sil = {}, _dups = 0;
    for (_i = 0; _i < array_length(_cast); _i++) { var _key = crt_silhouette_key(crt_read(_cast[_i].speaker)); if (variable_struct_exists(_sil, _key)) _dups++; _sil[$ _key] = true; }
    crt_st_assert(_st, _dups == 0 && array_length(_cast) == 24, "the 24-speaker demo cast is 24 different objects at a glance (material, construction, corner, bands): " + string(_dups) + " look-alikes");
    var _a = crt_read({ name: "Guard", kind: "commons", slot: 1 }), _b = crt_read({ name: "Guard", kind: "commons", slot: 1 });
    crt_st_assert(_st, crt_spec_key(_a) == crt_spec_key(_b) && _a.identity == _b.identity, "the same speaker reads to the same box every time");
    var _town = 0, _tk = {};
    for (_i = 0; _i < 6; _i++) { var _ts = crt_read({ name: "Villager", kind: "commons", slot: _i }); if (!variable_struct_exists(_tk, crt_silhouette_key(_ts))) _town++; _tk[$ crt_silhouette_key(_ts)] = true; }
    crt_st_note(_st, "six villagers of one name on one kind: " + string(_town) + " distinct at a glance");
    crt_st_assert(_st, _town >= 5, "six townsfolk of one kind are at least five different objects at a glance (" + string(_town) + ")");
    var _r0 = crt_read({ name: "Hero", kind: "company", rank: 0 }), _r4 = crt_read({ name: "Hero", kind: "company", rank: 4 });
    crt_st_assert(_st, _r0.rank == "plain" && _r4.rank == "sovereign" && array_length(_r0.bands) == 1 && array_length(_r4.bands) == 3 && _r0.material != _r4.material, "rank is visible: a plain speaker carries one band and a humble material, a sovereign three bands and a rich one");

    // ---- 4: every draw report, against the original ----
    crt_st_stage(_st, 4);
    var _sf = surface_create(900, 280), _draws = crt_oracle_draws(), _pd = crt_oracle_profile_draws();
    var _cntBad = 0, _inkDBad = 0, _layBad = 0, _bandBad = 0, _structBad = 0, _fhBad = 0, _t0 = get_timer();
    surface_set_target(_sf);
    draw_clear_alpha(c_black, 0);
    for (_i = 0; _i < array_length(_draws); _i++) {
        var _d = _draws[_i], _sp = crt_read(_cast[_d.index].speaker);
        var _ctx = crt_cx_create(1);
        var _rep = crt_box_draw(_ctx, 0, 0, _d.w, _d.h, _sp, { name: _d.name, portrait: _d.portrait, phase: 0 });
        if (is_undefined(_rep)) { _cntBad++; continue; }
        if (_rep.counts.path != _d.counts.path || _rep.counts.fill != _d.counts.fill || _rep.counts.stroke != _d.counts.stroke || _rep.counts.rect != _d.counts.rect) {
            _cntBad++;
            if (_cntBad <= 6) crt_st_note(_st, "draw " + string(_i) + " (" + _d.name + " " + string(_d.w) + "x" + string(_d.h) + (_d.portrait ? " portrait" : "") + "): got " + json_stringify(_rep.counts) + " want " + json_stringify(_d.counts));
        }
        if (!crt_st_rgb_eq(_rep.ink, _d.ink) || !crt_st_rgb_eq(_rep.dim, _d.dim)) _inkDBad++;
        var _Lg = _rep.layout, _Lw = _d.layout;
        if (!crt_st_near(_Lg.base, _Lw.base) || !crt_st_near(_Lg.top, _Lw.top) || !crt_st_near(_Lg.side, _Lw.side) || !crt_st_near(_Lg.foot, _Lw.foot) || _Lg.bleed != _Lw.bleed
            || !crt_st_near(_Lg.fx, _Lw.fx) || !crt_st_near(_Lg.fy, _Lw.fy) || !crt_st_near(_Lg.fw, _Lw.fw) || !crt_st_near(_Lg.fh, _Lw.fh)) _layBad++;
        if (!crt_st_arr_eq(_rep.band_counts, _d.band_counts) || _rep.corner_ops != _d.corner_ops) _bandBad++;
        var _sg = _rep.structural, _sw = _d.structural;
        if (_sg.crest != _sw.crest || _sg.arcade != _sw.arcade || _sg.joints != _sw.joints || _sg.material != _sw.material || _sg.reserve != _sw.reserve) {
            _structBad++;
            if (_structBad <= 4) crt_st_note(_st, "structural " + string(_i) + ": got " + json_stringify(_sg) + " want " + json_stringify(_sw));
        }
        if (crt_frame_height(_sp, _d.w) != _d.frame_height) _fhBad++;
    }
    for (_i = 0; _i < array_length(_pd); _i++) {
        var _p = _pd[_i];
        var _ctx2 = crt_cx_create(1);
        var _rep2 = crt_box_draw(_ctx2, 0, 0, 816, 240, _p.spec, { name: "Test Plate", portrait: true, phase: 0.25 });
        if (is_undefined(_rep2) || _rep2.counts.path != _p.counts.path || _rep2.counts.fill != _p.counts.fill || _rep2.counts.stroke != _p.counts.stroke || _rep2.counts.rect != _p.counts.rect) {
            _cntBad++;
            if (!is_undefined(_rep2) && _cntBad <= 8) crt_st_note(_st, "profile draw " + _p.spec.profile + ": got " + json_stringify(_rep2.counts) + " want " + json_stringify(_p.counts));
            continue;
        }
        var _s2 = _rep2.structural, _w2 = _p.structural;
        if (_s2.crest != _w2.crest || _s2.arcade != _w2.arcade || _s2.joints != _w2.joints || _s2.material != _w2.material || _s2.reserve != _w2.reserve || _rep2.corner_ops != _p.corner_ops || !crt_st_arr_eq(_rep2.band_counts, _p.band_counts)) _structBad++;
    }
    surface_reset_target();
    var _drawMs = (get_timer() - _t0) / 1000;
    surface_free(_sf);
    var _nDraw = array_length(_draws) + array_length(_pd);
    crt_st_assert(_st, _cntBad == 0 && _nDraw == 102, "all " + string(_nDraw) + " boxes draw exactly the original's number of paths, fills, strokes and rectangles (" + string(_cntBad) + " differ)");
    crt_st_assert(_st, _structBad == 0, "crest, arcade, joints, material marks, portrait recess, corner ops and band counts match the original on every box (" + string(_structBad) + " differ)");
    crt_st_assert(_st, _inkDBad == 0 && _layBad == 0 && _bandBad == 0 && _fhBad == 0, "inks, layout, band fits and frame heights match on every cast draw (ink " + string(_inkDBad) + ", layout " + string(_layBad) + ", bands " + string(_bandBad) + ", frame " + string(_fhBad) + ")");
    _st.metrics.draw_ms_1x_per_box = _drawMs / max(1, _nDraw);
    crt_st_note(_st, "drew " + string(_nDraw) + " boxes at 1x in " + string(round(_drawMs)) + " ms");

    // ---- 5: pictures: ink, a real field, containment, determinism ----
    crt_st_stage(_st, 5);
    var _spec0 = crt_read(_cast[0].speaker), _bakeMs = [];
    var _tb = get_timer();
    var _spr = crt_box_sprite(_spec0, 816, 240, { name: "Aldric" });
    array_push(_bakeMs, (get_timer() - _tb) / 1000);
    crt_st_assert(_st, !is_undefined(_spr) && sprite_exists(_spr) && sprite_get_width(_spr) == 816 && sprite_get_height(_spr) == 240, "crt_box_sprite bakes an 816 x 240 sprite");
    var _g = crt_st_grab_sprite(_spr);
    var _opaque = crt_st_count(_g, 0, 0, _g.w, _g.h, function(_r, _gg, _bb, _aa) { return _aa > 200; });
    var _white = crt_st_count(_g, 0, 0, _g.w, _g.h, function(_r, _gg, _bb, _aa) { return _aa > 250 && _r > 250 && _gg > 250 && _bb > 250; });
    var _L0 = crt_layout(_spec0, 816, 240), _mat0 = crt_look("materials", _spec0.material);
    // the OBJECT is inset by the bleed on every side (the margin projecting corners use), so it is ow x oh, not w x h
    crt_st_assert(_st, _opaque > _L0.ow * _L0.oh * 0.97, "the box covers its object with paint (" + string(_opaque) + " opaque px, object " + string(round(_L0.ow)) + " x " + string(round(_L0.oh)) + ")");
    crt_st_assert(_st, _opaque < 816 * 240 * 0.98, "control: the bleed margin is left clear (" + string(816 * 240 - _opaque) + " px not opaque)");
    crt_st_assert(_st, _white < 816 * 240 * 0.02, "the box is not a white box - a sprite with no texture (" + string(_white) + " pure white px)");
    var _fc = crt_st_px(_g, _L0.fx + _L0.fw * 0.5, _L0.fy + _L0.fh * 0.5);
    crt_st_assert(_st, abs(_fc[0] - _mat0.field[0]) < 40 && abs(_fc[1] - _mat0.field[1]) < 40 && abs(_fc[2] - _mat0.field[2]) < 40 && _fc[3] > 250, "the centre of the field is the material's field colour, opaque (" + string(_fc) + " vs " + string(_mat0.field) + ")");
    var _rail = crt_st_px(_g, _L0.ox + _L0.ow * 0.5, _L0.oy + 2);
    crt_st_assert(_st, abs(crt_lum([_rail[0], _rail[1], _rail[2]]) - crt_lum(_mat0.field)) > 20, "the head rail is not the field: the frame is a different material (rail lum " + string(round(crt_lum([_rail[0], _rail[1], _rail[2]]))) + ", field " + string(round(crt_lum(_mat0.field))) + ")");
    var _spr2 = crt_box_sprite(_spec0, 816, 240, { name: "Aldric" });
    var _g2 = crt_st_grab_sprite(_spr2);
    var _diff = crt_st_same(_g, _g2);
    crt_st_assert(_st, _diff == 0, "the same speaker bakes to the same pixels twice (" + string(_diff) + " bytes differ)");
    var _specN2 = crt_read(_cast[11].speaker);
    var _spr3 = crt_box_sprite(_specN2, 816, 240, { name: "The Warden" });
    var _g3 = crt_st_grab_sprite(_spr3);
    var _diff2 = crt_st_same(_g, _g3);
    crt_st_assert(_st, _diff2 > 816 * 240, "control: a different speaker bakes to different pixels (" + string(_diff2) + " bytes differ)");
    buffer_delete(_g.b); buffer_delete(_g2.b); buffer_delete(_g3.b);
    // containment: every construction and corner drawn with room around it - nothing may land outside the rect
    var _pad = 60, _outside = 0, _inside = 0, _worst = "", _objArea = 0;
    for (_i = 0; _i < array_length(_pd); _i++) {
        var _lp = crt_layout(_pd[_i].spec, 816, 240);
        _objArea += _lp.ow * _lp.oh;
        var _cs = surface_create(816 + _pad * 2, 240 + _pad * 2);
        surface_set_target(_cs); draw_clear_alpha(c_black, 0);
        gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
        crt_box_draw(crt_cx_create(1), _pad, _pad, 816, 240, _pd[_i].spec, { name: "Test Plate", portrait: true, phase: 0.25 });
        gpu_set_blendmode(bm_normal);
        surface_reset_target();
        var _cg = crt_st_grab_surface(_cs);
        surface_free(_cs);
        var _all = crt_st_count(_cg, 0, 0, _cg.w, _cg.h, function(_r, _gg, _bb, _aa) { return _aa > 8; });
        var _in = crt_st_count(_cg, _pad, _pad, _pad + 816, _pad + 240, function(_r, _gg, _bb, _aa) { return _aa > 8; });
        buffer_delete(_cg.b);
        if (_all - _in > 0) { _outside += _all - _in; _worst = _pd[_i].spec.profile + "/" + _pd[_i].spec.corner; }
        _inside += _in;
    }
    crt_st_assert(_st, _outside == 0 && _inside > _objArea * 0.97, "no construction or corner draws outside its rect - projecting ornament is scaled into the bleed (" + string(_outside) + " px outside, 30 boxes" + ((_worst != "") ? ", worst " + _worst : "") + ")");
    // timing: bakes of the cast at 2x (the cost a speaker's first line pays, or crt_prepare pays at load)
    for (_i = 1; _i < 6; _i++) {
        _tb = get_timer();
        var _sx = crt_box_sprite(crt_read(_cast[_i * 4].speaker), 816, 240, { name: crt__field(_cast[_i * 4].speaker, "name", "") });
        array_push(_bakeMs, (get_timer() - _tb) / 1000);
        if (!is_undefined(_sx)) sprite_delete(_sx);
    }
    array_sort(_bakeMs, true);
    _st.metrics.bake_ms_816x240_2x = _bakeMs;
    crt_st_note(_st, "bake at 816x240, 2x supersample: " + string(_bakeMs) + " ms");

    // ---- 6: premultiplied edges, the caret, the portrait ----
    crt_st_stage(_st, 6);
    var _bgs = [c_black, c_white], _fields = [];
    for (_i = 0; _i < 2; _i++) {
        var _ps = surface_create(816, 240);
        surface_set_target(_ps); draw_clear(_bgs[_i]);
        crt_draw(_spec0, 0, 0, 816, 240, { name: "Aldric", caret: false });
        surface_reset_target();
        var _pg = crt_st_grab_surface(_ps);
        surface_free(_ps);
        array_push(_fields, crt_st_px(_pg, _L0.fx + _L0.fw * 0.5, _L0.fy + _L0.fh * 0.5));
        buffer_delete(_pg.b);
    }
    crt_st_assert(_st, abs(_fields[0][0] - _fields[1][0]) <= 2 && abs(_fields[0][1] - _fields[1][1]) <= 2 && abs(_fields[0][2] - _fields[1][2]) <= 2, "crt_draw composites the box the same over black and white (premultiplied, no halo): " + string(_fields[0]) + " vs " + string(_fields[1]));
    crt_st_assert(_st, abs(_fields[0][0] - _fc[0]) <= 2 && abs(_fields[0][1] - _fc[1]) <= 2, "and the drawn field is the baked field colour, not darkened by a second multiply");
    var _carets = [];
    var _specB = crt_read(_cast[0].speaker);
    var _car = crt_look("carets", _specB.caret);
    for (_i = 0; _i < 2; _i++) {
        var _cs2 = surface_create(816, 240);
        surface_set_target(_cs2); draw_clear(c_black);
        crt_draw_caret(_specB, 0, 0, 816, 240, _i * 0.25);
        surface_reset_target();
        array_push(_carets, crt_st_grab_surface(_cs2));
        surface_free(_cs2);
    }
    var _cInk = crt_st_count(_carets[0], 0, 0, 816, 240, function(_r, _gg, _bb, _aa) { return _r + _gg + _bb > 60; });
    var _cMove = crt_st_same(_carets[0], _carets[1]);
    crt_st_assert(_st, _cInk > 20, "the caret draws ink (" + string(_cInk) + " px, form " + _car.form + ")");
    crt_st_assert(_st, _cMove > 0, "the caret moves with its phase (" + _car.motion + ": " + string(_cMove) + " bytes differ between phase 0 and 0.25)");
    buffer_delete(_carets[0].b); buffer_delete(_carets[1].b);
    // the portrait: a solid test sprite fitted, clipped to the aperture and foot-faded
    var _ts = surface_create(64, 64);
    surface_set_target(_ts); draw_clear(make_colour_rgb(200, 60, 40)); surface_reset_target();
    var _face = sprite_create_from_surface(_ts, 0, 0, 64, 64, false, false, 0, 0);
    surface_free(_ts);
    var _specP = crt_read(_cast[22].speaker);
    var _rv = crt_reserve(_specP, 816, 240);
    var _por = crt_portrait_sprite(_specP, 816, 240, _face, 0);
    crt_st_assert(_st, !is_undefined(_por) && sprite_get_width(_por) == ceil(_rv.w) && sprite_get_height(_por) == ceil(_rv.h), "crt_portrait_sprite is the size of the aperture (" + string(ceil(_rv.w)) + " x " + string(ceil(_rv.h)) + ", head " + string(_rv.head) + ")");
    if (!is_undefined(_por)) {
        var _pgr = crt_st_grab_sprite(_por);
        var _mid = crt_st_px(_pgr, _pgr.w / 2, _pgr.h * 0.45), _foot = crt_st_px(_pgr, _pgr.w / 2, _pgr.h - 1), _corner = crt_st_px(_pgr, 0, 0);
        crt_st_assert(_st, _mid[3] > 240 && _mid[0] > 150, "the portrait fills its aperture (centre " + string(_mid) + ")");
        crt_st_assert(_st, _foot[3] < 40, "the portrait fades out at its foot (bottom row alpha " + string(_foot[3]) + ")");
        crt_st_assert(_st, _rv.head == 0 || _corner[3] < 20, "the portrait is clipped to the aperture's head (top corner alpha " + string(_corner[3]) + ", head " + string(_rv.head) + ")");
        buffer_delete(_pgr.b);
        sprite_delete(_por);
    }

    // ---- 7: the cache ----
    crt_st_stage(_st, 7);
    crt_cache_clear();
    var _cc = crt__cache(), _b0 = _cc.bakes;
    var _cs3 = surface_create(816, 240);
    surface_set_target(_cs3);
    crt_draw(_spec0, 0, 0, 816, 240, { name: "Aldric" });
    crt_draw(_spec0, 0, 0, 816, 240, { name: "Aldric" });
    surface_reset_target();
    crt_st_assert(_st, _cc.bakes - _b0 == 1 && crt_cache_count() == 1, "the second draw of a box costs no bake (" + string(_cc.bakes - _b0) + " bakes)");
    // draw A, then force enough bakes to evict A in the SAME target, then read A's pixels: never a white box
    surface_set_target(_cs3);
    draw_clear(c_black);
    crt_draw(_spec0, 0, 0, 816, 240, { name: "Aldric", caret: false });
    for (_i = 0; _i < 50; _i++) crt_prepare(crt_read({ name: "Evict " + string(_i), kind: _kinds[_i mod 5], slot: _i }), 240, 96);
    surface_reset_target();
    var _eg = crt_st_grab_surface(_cs3);
    var _ew = crt_st_count(_eg, 0, 0, 816, 240, function(_r, _gg, _bb, _aa) { return _r > 250 && _gg > 250 && _bb > 250; });
    crt_st_assert(_st, crt_cache_count() <= 48, "the cache is bounded at 48 boxes (" + string(crt_cache_count()) + ")");
    crt_st_assert(_st, _ew < 816 * 240 * 0.02, "a box evicted after it was drawn in the same frame is not a white box (" + string(_ew) + " white px)");
    buffer_delete(_eg.b);
    surface_free(_cs3);
    crt_cache_clear();
    crt_st_assert(_st, crt_cache_count() == 0, "crt_cache_clear empties the cache");

    // ---- 8: refusals are values, never crashes ----
    crt_st_stage(_st, 8);
    var _e = crt_read(undefined);
    crt_st_assert(_st, is_struct(_e) && _e.kind == "commons" && is_array(_e.bands), "crt_read(undefined) is the town's plain box, not a crash");
    crt_st_assert(_st, is_undefined(crt_layout(undefined, 800, 200)) && is_undefined(crt_layout(_spec0, -5, 200)) && is_undefined(crt_layout(_spec0, "x", 200)), "crt_layout refuses a bad spec or size");
    crt_st_assert(_st, is_undefined(crt_box_sprite(_spec0, 10, 10)) && is_undefined(crt_box_sprite({ profile: "nope" }, 400, 120)) && is_undefined(crt_box_sprite(_spec0, 5000, 200)), "crt_box_sprite refuses a bad size or spec");
    crt_st_assert(_st, is_undefined(crt_draw(undefined, 0, 0, 800, 200)) && !crt_draw_caret(undefined, 0, 0, 800, 200, 0) && !crt_draw_portrait(_spec0, 0, 0, 800, 200, -1), "crt_draw, crt_draw_caret and crt_draw_portrait refuse bad input");
    var _odd = { kind: "commons", rank: "plain", work: 0, identity: "x", material: "pine-plank", profile: "plank", plate: "chalked", corner: "square", bands: ["no-such-band"], ground: "sawn", caret: "wedge", tint: 1 };
    var _ctx3 = crt_cx_create(1);
    var _sf3 = surface_create(400, 140);
    surface_set_target(_sf3);
    var _r3 = crt_box_draw(_ctx3, 0, 0, 400, 140, _odd, {});
    surface_reset_target();
    surface_free(_sf3);
    crt_st_assert(_st, is_struct(_r3) && array_length(_r3.band_counts) == 0, "an unknown band id is skipped and REPORTED (0 band fits), never a crash");
    crt_st_assert(_st, crt_frame_height(undefined, 800) == 0 && crt_max_frame_height(-1) == 0 && crt_ink(undefined) == c_black, "the size and ink helpers answer 0 / black for bad input");
    // found by the generated adversarial harness on the first buyer run: crt_spec_key and crt_prepare threw on a non-spec
    crt_st_assert(_st, crt_spec_key(undefined) == "" && crt_spec_key("xyzzy") == "" && crt_silhouette_key(4096) == "" && !crt_prepare(undefined, 816, 240) && !crt_prepare("xyzzy", 816, 240) && !crt_prepare(_spec0, undefined, "tall"),"crt_spec_key, crt_silhouette_key and crt_prepare refuse a non-spec instead of throwing");
    sprite_delete(_spr); sprite_delete(_spr2); sprite_delete(_spr3); sprite_delete(_face);

    // ---- 9: a contact sheet of the cast, saved for LOOKING (crt_render_cast.png) - the suite cannot judge a picture ----
    crt_st_stage(_st, 9);
    var _sheet = surface_create(1680, 2060), _sprs = [];
    for (_i = 0; _i < 16; _i++) array_push(_sprs, crt_box_sprite(crt_read(_cast[_i].speaker), 816, 240, { name: crt__field(_cast[_i].speaker, "name", ""), portrait: (_i mod 5) == 2 }));
    surface_set_target(_sheet);
    draw_clear(make_colour_rgb(24, 22, 28));
    for (_i = 0; _i < 16; _i++) {
        var _xx = 16 + (_i mod 2) * 832, _yy = 16 + (_i div 2) * 256;
        if (!is_undefined(_sprs[_i])) {
            gpu_set_blendmode_ext_sepalpha(bm_one, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
            draw_sprite(_sprs[_i], 0, _xx, _yy);
            gpu_set_blendmode(bm_normal);
            var _spc = crt_read(_cast[_i].speaker), _trc = crt_text_rect(_spc, 816, 240, (_i mod 5) == 2);
            draw_set_font(fnt_cartouche); draw_set_colour(crt_ink(_spc)); draw_set_halign(fa_left); draw_set_valign(fa_top);
            draw_text_ext(_xx + _trc.x, _yy + _trc.y, _cast[_i].line, 34, _trc.w);
            crt_draw_caret(_spc, _xx, _yy, 816, 240, 0);
        }
    }
    surface_reset_target();
    surface_save(_sheet, "crt_render_cast.png");
    surface_free(_sheet);
    for (_i = 0; _i < 16; _i++) if (!is_undefined(_sprs[_i])) sprite_delete(_sprs[_i]);
    crt_st_stage(_st, 99);
    return _st;
}

/// @function crt_selftest_write(st)
/// @description Write the suite's result to crt_selftest.json in the game's save area.
function crt_selftest_write(_st) {
    var _f = file_text_open_write("crt_selftest.json");
    file_text_write_string(_f, json_stringify(_st));
    file_text_close(_f);
}
