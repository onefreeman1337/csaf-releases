/// crt_render.gml - the drawing primitives a Cartouche box is built from: the text field and its ground, the frame's
/// own material and grain, the moulded rails, repeated bands, corner treatments, the crest and arcade, the joints,
/// the portrait aperture, the nameplate and its lettering, and the advance caret. Each draws onto a crt_canvas context.
///
/// Cartouche - The Message Box Drawn as an Object, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ A PORT HELD TO ITS ORIGINAL. These functions follow the published RPG Maker MZ Cartouche renderer op for op, and
/// the in-engine suite compares the number of paths, fills, strokes and rectangles each box draws with the number
/// the original drew for the same speaker (crt_oracle.gml). A branch dropped in the port changes those counts.
/// Three laws every function below obeys, each paid for by a picture that looked wrong while every check was green:
///   - NO INK IS HARD-CODED. `lit` and `dark` are solved from the body by crt_relief to an ABSOLUTE separation, so a
///     grain on near-black jet reads for the same reason it reads on bleached bone.
///   - A REPEATED TREATMENT DECLARES A PITCH, never a count: the count comes from the real run (crt_repeats_for), and a
///     rail too small to carry a treatment draws none rather than a smear. `.count` is read, never the record itself.
///   - EVERY MARK THAT CAN BE DRAWN IS COUNTED AND RETURNED, so an axis that draws nothing is distinguishable from one
///     that honestly has nothing to draw at this size.

/// @function crt__css_rgba(rgb)
/// @description An [r, g, b] colour rounded to bytes, as the original's css() writes it. Internal.
function crt__b(_c) { return [crt_b255(_c[0]), crt_b255(_c[1]), crt_b255(_c[2])]; }

/// @function crt__fill_style(ctx, rgb)
/// @description Set a flat fill paint. Internal.
function crt__fs(_c, _rgb) { _c.fill = crt_cx_solid(crt__b(_rgb)); }

/// @function crt__ss(ctx, rgb)
/// @description Set a flat stroke paint. Internal.
function crt__ss(_c, _rgb) { _c.stroke = crt_cx_solid(crt__b(_rgb)); }

/// @function crt__line_at(ctx, x, y, w, h, vertical, u0, v0, u1, v1)
/// @description One stroked line in rail coordinates (u along the rail, v across it). Internal.
function crt__line_at(_c, _x, _y, _vert, _u0, _v0, _u1, _v1) {
    crt_cx_begin(_c);
    if (_vert) { crt_cx_move(_c, _x + _v0, _y + _u0); crt_cx_line(_c, _x + _v1, _y + _u1); }
    else { crt_cx_move(_c, _x + _u0, _y + _v0); crt_cx_line(_c, _x + _u1, _y + _v1); }
    crt_cx_stroke(_c);
}

/// @function crt_surface(ctx, x, y, w, h, field, texture, amp, seed)
/// @description The text field, laid in the material's field colour and given its ground. ⛔ `amp` is a small
/// luminance excursion by law: this is the one surface the player reads for the whole game, and the ink is solved
/// against the ground's worst excursion, so raising it costs contrast. One-colour textures draw in the direction that
/// has headroom (`edge`); speckles keep both directions.
function crt_surface(_c, _x, _y, _w, _h, _field, _tex, _amp, _seed) {
    crt_cx_save(_c);
    crt_cx_begin(_c);
    crt_cx_rect(_c, _x, _y, _w, _h);
    crt_cx_clip(_c);
    crt__fs(_c, _field);
    crt_cx_fill_rect(_c, _x, _y, _w, _h);
    var _dark = crt_mix(_field, [0, 0, 0], _amp * 2.2);
    var _light = crt_mix(_field, [255, 255, 255], _amp * 2.2);
    var _edge = (crt_lum(_field) > 140) ? _dark : _light;
    var _i, _j, _n, _px, _py, _step;
    if (_tex == "flat") {
        // Nothing. A polished void is polished.
    } else if (_tex == "comb" || _tex == "reed") {
        // A combed line UNDULATES, and every line has its own phase: a periodic set in register IS a raster.
        _step = max(7, _h / 11);
        crt__ss(_c, _dark);
        _c.lw = 1;
        _i = 0; _py = _y + _step * 0.5;
        while (_py < _y + _h) {
            var _camp = _step * 0.34;
            var _cph = crt_nz(_seed + _i * 7) * 6.283;
            var _cwv = 34 + crt_nz(_seed + _i * 7 + 3) * 26;
            crt_cx_begin(_c);
            crt_cx_move(_c, _x, _py + sin(_cph) * _camp);
            _px = _x;
            while (_px <= _x + _w) { crt_cx_line(_c, _px, _py + sin(_cph + (_px - _x) / _cwv) * _camp); _px += 5; }
            crt_cx_stroke(_c);
            _py += _step; _i++;
        }
    } else if (_tex == "grain") {
        // CATHEDRAL FIGURE: nested arcs that CONVERGE. Parallel lines across a text field read as ruled paper, and
        // one through a line of dialogue is a strikethrough; converging lines cannot form a raster.
        crt__ss(_c, _dark);
        _c.lw = 1.1;
        var _figs = max(1, crt_jsround(_w / 260));
        for (_i = 0; _i < _figs; _i++) {
            var _fcx = _x + _w * ((_i + 0.5) / _figs + (crt_nz(_seed + _i * 9) - 0.5) * 0.16);
            var _fdown = crt_nz(_seed + _i * 9 + 1) > 0.5;
            var _rings = 4 + crt_jsround(crt_nz(_seed + _i * 9 + 2) * 3);
            for (_j = 0; _j < _rings; _j++) {
                var _spread = _w * (0.05 + _j * 0.030) * (0.8 + crt_nz(_seed + _i * 9 + _j) * 0.5);
                var _rise = _h * (0.30 + _j * 0.10);
                var _apex = _y + (_fdown ? _h * 0.86 - _rise : _h * 0.14 + _rise);
                crt_cx_begin(_c);
                crt_cx_move(_c, _fcx - _spread, _y - _h * 0.1);
                crt_cx_quad(_c, _fcx, _apex, _fcx + _spread, _y - _h * 0.1);
                crt_cx_stroke(_c);
                crt_cx_begin(_c);
                crt_cx_move(_c, _fcx - _spread, _y + _h * 1.1);
                crt_cx_quad(_c, _fcx, _apex + (_fdown ? -_h * 0.06 : _h * 0.06), _fcx + _spread, _y + _h * 1.1);
                crt_cx_stroke(_c);
            }
        }
        _step = _h / 3.5;
        _i = 0; _py = _y + _step * 0.7;
        while (_py < _y + _h) {
            crt_cx_begin(_c);
            crt_cx_move(_c, _x, _py + crt_nz(_seed + _i + 300) * 3);
            crt_cx_line(_c, _x + _w, _py + crt_nz(_seed + _i + 700) * 3);
            crt_cx_stroke(_c);
            _py += _step; _i++;
        }
    } else if (_tex == "pour") {
        // A poured slip POOLS: soft lobes thicker in the middle than at the rim. A radial gradient has no edge at all.
        _n = max(3, crt_jsround((_w * _h) / 5200));
        for (_i = 0; _i < _n; _i++) {
            _px = _x + crt_nz(_seed + _i * 3) * _w;
            _py = _y + crt_nz(_seed + _i * 3 + 1) * _h;
            var _pr = 9 + crt_nz(_seed + _i * 3 + 2) * 26;
            var _tone = (crt_nz(_seed + _i + 41) > 0.5) ? _light : _dark;
            var _pg = crt_cx_radial(_c, _px, _py, 0, _px, _py, _pr);
            crt_cx_stop(_pg, 0, _tone, 0.55); crt_cx_stop(_pg, 0.65, _tone, 0.22); crt_cx_stop(_pg, 1, _tone, 0);
            _c.fill = _pg;
            crt_cx_begin(_c);
            crt_cx_arc(_c, _px, _py, _pr, 0, pi * 2);
            crt_cx_fill(_c);
        }
    } else if (_tex == "stipple" || _tex == "pebble" || _tex == "pit" || _tex == "pore") {
        // Four grades of one idea, separated by GRAIN SIZE: a pit is a dark bite, a pore arrives in a clutch, a
        // pebble is a mixed aggregate, a stipple an even scatter.
        var _dense = (_tex == "pebble") ? 260 : ((_tex == "pore") ? 300 : 520);
        _n = crt_jsround((_w * _h) / _dense);
        for (_i = 0; _i < _n; _i++) {
            _px = _x + crt_nz(_seed + _i * 2) * _w;
            _py = _y + crt_nz(_seed + _i * 2 + 1) * _h;
            if (_tex == "pore") {
                _px += (crt_nz(_seed + _i * 2 + 400) - 0.5) * 14;
                _py += (crt_nz(_seed + _i * 2 + 401) - 0.5) * 9;
            }
            crt__fs(_c, (_tex == "pit") ? _dark : ((crt_nz(_seed + _i + 77) > 0.5) ? _dark : _light));
            var _r = (_tex == "pebble") ? 1.2 + crt_nz(_seed + _i + 5) * 1.8 : ((_tex == "pit") ? 1.5 + crt_nz(_seed + _i + 5) * 1.1 : 0.9);
            crt_cx_begin(_c);
            crt_cx_arc(_c, _px, _py, _r, 0, pi * 2);
            crt_cx_fill(_c);
        }
    } else if (_tex == "brush" || _tex == "scrub") {
        // A brush mark is SHORT and laid in a scatter, never one long rule per row across the words.
        var _bw2 = (_tex == "scrub") ? 2.6 : 1.6;
        var _blen = (_tex == "scrub") ? 26 : 34;
        _n = crt_jsround((_w * _h) / ((_tex == "scrub") ? 520 : 760));
        _c.cap = 1;
        _c.lw = _bw2;
        for (_i = 0; _i < _n; _i++) {
            _px = _x + crt_nz(_seed + _i * 4) * _w;
            _py = _y + crt_nz(_seed + _i * 4 + 1) * _h;
            var _ang = (crt_nz(_seed + _i * 4 + 2) - 0.5) * 0.5 + ((_tex == "scrub") ? 0.35 : 0);
            var _len = _blen * (0.5 + crt_nz(_seed + _i * 4 + 3));
            crt__ss(_c, (crt_nz(_seed + _i + 17) > 0.5) ? _dark : _light);
            crt_cx_begin(_c);
            crt_cx_move(_c, _px, _py);
            crt_cx_line(_c, _px + cos(_ang) * _len, _py + sin(_ang) * _len);
            crt_cx_stroke(_c);
        }
        _c.cap = 0;
    } else if (_tex == "saw") {
        _step = max(4, _h / 20);
        crt__ss(_c, _dark);
        _c.lw = 1;
        _i = 0; _py = _y;
        while (_py < _y + _h) {
            crt_cx_begin(_c);
            crt_cx_move(_c, _x, _py);
            _px = _x;
            while (_px < _x + _w) { crt_cx_line(_c, _px, _py + (((_px mod 12) == 0) ? 1.4 : -1.4)); _px += 6; }
            crt_cx_stroke(_c);
            _py += _step; _i++;
        }
    } else if (_tex == "hammer") {
        // A planished surface is a field of shallow DISHES: a soft gradient from a lit lip to a shaded floor.
        _step = max(9, min(_w, _h) / 9);
        _j = 0; _py = _y + _step / 2;
        while (_py < _y + _h + _step) {
            _i = 0; _px = _x + _step / 2 + (_j mod 2) * _step / 2;
            while (_px < _x + _w + _step) {
                var _hr = _step * 0.52;
                var _up = crt_nz(_seed + _i * 31 + _j * 7) > 0.5;
                var _hg = crt_cx_radial(_c, _px - _hr * 0.3, _py - _hr * 0.3, _hr * 0.08, _px, _py, _hr);
                crt_cx_stop(_hg, 0, _up ? _light : _dark); crt_cx_stop(_hg, 1, _up ? _dark : _light);
                _c.alpha = 0.55;
                crt_cx_begin(_c);
                crt_cx_arc(_c, _px, _py, _hr, 0, pi * 2);
                _c.fill = _hg;
                crt_cx_fill(_c);
                _c.alpha = 1;
                _px += _step; _i++;
            }
            _py += _step; _j++;
        }
    } else if (_tex == "smoke" || _tex == "veil") {
        _n = 7;
        for (_i = 0; _i < _n; _i++) {
            crt_cx_begin(_c);
            crt_cx_ellipse(_c, _x + crt_nz(_seed + _i) * _w, _y + crt_nz(_seed + _i + 30) * _h,
                _w * (0.18 + crt_nz(_seed + _i + 60) * 0.22), _h * (0.2 + crt_nz(_seed + _i + 90) * 0.3), 0, 0, pi * 2);
            crt__fs(_c, (_tex == "veil") ? _edge : _dark);
            _c.alpha = 0.30;
            crt_cx_fill(_c);
            _c.alpha = 1;
        }
    } else if (_tex == "ripple") {
        // Water ripples RADIATE - concentric arcs from a disturbance, flattened as a ring on water seen low.
        crt__ss(_c, _edge);
        _c.lw = 1.2;
        var _srcs = max(2, crt_jsround(_w / 300));
        for (_j = 0; _j < _srcs; _j++) {
            var _rx = _x + _w * ((_j + 0.5) / _srcs + (crt_nz(_seed + _j * 11) - 0.5) * 0.3);
            var _ry = _y + _h * (0.25 + crt_nz(_seed + _j * 11 + 1) * 0.5);
            var _rn = 5 + crt_jsround(crt_nz(_seed + _j * 11 + 2) * 4);
            for (_i = 1; _i <= _rn; _i++) {
                var _rr = _h * 0.13 * _i * (0.85 + crt_nz(_seed + _j * 11 + _i) * 0.4);
                crt_cx_begin(_c);
                crt_cx_ellipse(_c, _rx, _ry, _rr, _rr * 0.42, 0, 0, pi * 2);
                crt_cx_stroke(_c);
            }
        }
    } else if (_tex == "star") {
        _n = max(8, crt_jsround((_w * _h) / 2600));
        for (_i = 0; _i < _n; _i++) {
            _px = _x + crt_nz(_seed + _i * 3) * _w;
            _py = _y + crt_nz(_seed + _i * 3 + 1) * _h;
            var _s = 1.1 + crt_nz(_seed + _i * 3 + 2) * 1.6;
            crt__ss(_c, _edge);
            _c.lw = 1;
            crt_cx_begin(_c);
            crt_cx_move(_c, _px - _s, _py); crt_cx_line(_c, _px + _s, _py);
            crt_cx_move(_c, _px, _py - _s); crt_cx_line(_c, _px, _py + _s);
            crt_cx_stroke(_c);
        }
    }
    crt_cx_restore(_c);
}

/// @function crt_body_surface(ctx, x, y, w, h, family, grain, body, lit, dark, seed, vertical)
/// @description The FRAME's own material: what makes a pine rail and a pewter rail different objects rather than two
/// colours. Drawn over the moulded rail at partial alpha (a moulding is the shape cut INTO a material). Metal is read
/// from its specular sweep, wood from a soft longitudinal wash, stone from blotches, glass from a sheet and facets,
/// hide from grain speckle, horn and nacre from layers, a glaze from pooling, rush from a weave. Returns marks laid
/// (0 is legitimate on a rail below the resolution floor).
function crt_body_surface(_c, _x, _y, _w, _h, _fam, _grain, _body, _lit, _dark, _seed, _vert) {
    if (_w <= 0 || _h <= 0) return 0;
    var _drawn = 0;
    crt_cx_save(_c);
    crt_cx_begin(_c);
    crt_cx_rect(_c, _x, _y, _w, _h);
    crt_cx_clip(_c);
    var _i, _n, _g, _step, _px, _py;
    var _along = _vert ? _h : _w;
    var _across = _vert ? _w : _h;
    if (_fam == "metal" || _fam == "lacquer") {
        _g = _vert ? crt_cx_linear(_c, _x, _y, _x + _w, _y) : crt_cx_linear(_c, _x, _y, _x, _y + _h);
        crt_cx_stop(_g, 0, crt__b(_dark));
        crt_cx_stop(_g, 0.34, crt__b(_lit));
        crt_cx_stop(_g, 0.48, crt__b(crt_mix(_lit, [255, 255, 255], (_fam == "lacquer") ? 0.5 : 0.25)));
        crt_cx_stop(_g, 0.62, crt__b(_body));
        crt_cx_stop(_g, 1, crt__b(_dark));
        _c.fill = _g;
        _c.alpha = 0.62;
        crt_cx_fill_rect(_c, _x, _y, _w, _h);
        _c.alpha = 1;
        _drawn++;
    } else if (_fam == "wood") {
        _g = _vert ? crt_cx_linear(_c, _x, _y, _x + _w, _y) : crt_cx_linear(_c, _x, _y, _x, _y + _h);
        crt_cx_stop(_g, 0, crt__b(crt_mix(_body, _dark, 0.35)));
        crt_cx_stop(_g, 0.45, crt__b(crt_mix(_body, _lit, 0.25)));
        crt_cx_stop(_g, 1, crt__b(crt_mix(_body, _dark, 0.5)));
        _c.fill = _g;
        _c.alpha = 0.45;
        crt_cx_fill_rect(_c, _x, _y, _w, _h);
        _c.alpha = 1;
        _drawn++;
    } else if (_fam == "stone") {
        _n = max(4, crt_jsround(_along / 26));
        for (_i = 0; _i < _n; _i++) {
            var _u0 = crt_nz(_seed + _i * 3) * _along, _v0 = crt_nz(_seed + _i * 3 + 1) * _across;
            var _cx0 = _vert ? _x + _v0 : _x + _u0, _cy0 = _vert ? _y + _u0 : _y + _v0;
            crt_cx_begin(_c);
            crt_cx_ellipse(_c, _cx0, _cy0, _across * (0.22 + crt_nz(_seed + _i) * 0.4), _across * (0.16 + crt_nz(_seed + _i + 7) * 0.3), crt_nz(_seed + _i + 3) * 3.14, 0, pi * 2);
            crt__fs(_c, (crt_nz(_seed + _i + 55) > 0.5) ? _dark : _lit);
            _c.alpha = 0.28;
            crt_cx_fill(_c);
            _c.alpha = 1;
            _drawn++;
        }
    } else if (_fam == "glass" || _fam == "ice") {
        _g = _vert ? crt_cx_linear(_c, _x, _y, _x + _w, _y) : crt_cx_linear(_c, _x, _y, _x, _y + _h);
        crt_cx_stop(_g, 0, crt__b(_lit));
        crt_cx_stop(_g, 0.55, crt__b(_body));
        crt_cx_stop(_g, 1, crt__b(crt_mix(_body, _lit, 0.45)));
        _c.fill = _g;
        _c.alpha = 0.62;
        crt_cx_fill_rect(_c, _x, _y, _w, _h);
        _c.alpha = 1;
        _drawn++;
        _n = max(2, crt_jsround(_along / 34));
        crt__ss(_c, _lit);
        _c.lw = 1.2;
        for (_i = 1; _i < _n; _i++) { crt__line_at(_c, _x, _y, _vert, (_along / _n) * _i, 0, (_along / _n) * _i, _across); _drawn++; }
    } else if (_fam == "leather" || _fam == "organic" || _fam == "chitin") {
        _n = crt_jsround((_w * _h) / ((_fam == "chitin") ? 90 : 46));
        for (_i = 0; _i < _n; _i++) {
            _px = _x + crt_nz(_seed + _i * 2) * _w;
            _py = _y + crt_nz(_seed + _i * 2 + 1) * _h;
            crt__fs(_c, (crt_nz(_seed + _i + 13) > 0.5) ? _dark : _lit);
            _c.alpha = 0.5;
            crt_cx_begin(_c);
            crt_cx_arc(_c, _px, _py, (_fam == "chitin") ? 1.6 : 0.9, 0, pi * 2);
            crt_cx_fill(_c);
            _c.alpha = 1;
            _drawn++;
        }
    } else if (_fam == "bone" || _fam == "horn" || _fam == "amber" || _fam == "nacre") {
        // ONE GRADIENT, NOT N RECTANGLES: a layered material has no hard edges, and a gradient stop cannot seam.
        _n = max(3, crt_jsround(_along / 22));
        var _bg2 = _vert ? crt_cx_linear(_c, _x, _y, _x, _y + _h) : crt_cx_linear(_c, _x, _y, _x + _w, _y);
        for (_i = 0; _i <= _n; _i++) {
            crt_cx_stop(_bg2, min(1, _i / _n), crt__b((_fam == "nacre") ? crt_mix(_lit, [200, 220, 255], crt_nz(_seed + _i)) : crt_mix(_dark, _lit, crt_nz(_seed + _i))));
        }
        _c.alpha = 0.34;
        _c.fill = _bg2;
        crt_cx_fill_rect(_c, _x, _y, _w, _h);
        _c.alpha = 1;
        _drawn++;
    } else if (_fam == "ceramic") {
        _g = _vert ? crt_cx_linear(_c, _x, _y, _x + _w, _y) : crt_cx_linear(_c, _x, _y, _x, _y + _h);
        crt_cx_stop(_g, 0, crt__b(_lit));
        crt_cx_stop(_g, 0.6, crt__b(_body));
        crt_cx_stop(_g, 1, crt__b(_dark));
        _c.fill = _g;
        _c.alpha = 0.62;
        crt_cx_fill_rect(_c, _x, _y, _w, _h);
        _c.alpha = 1;
        _drawn++;
    } else if (_fam == "fibre") {
        var _ff = crt_repeats_for(_across, 1, 4);
        _step = _ff.pitch;
        _c.lw = 1;
        _i = 0; _py = 0;
        while (_i < _ff.count) { crt__ss(_c, (_i mod 2) ? _dark : _lit); crt__line_at(_c, _x, _y, _vert, 0, _py, _along, _py); _drawn++; _py += _step; _i++; }
        if (_ff.count > 0) {
            _i = 0; _px = 0;
            while (_px < _along) { crt__ss(_c, (_i mod 2) ? _lit : _dark); crt__line_at(_c, _x, _y, _vert, _px, 0, _px, _across); _drawn++; _px += _step; _i++; }
        }
    }
    _drawn += crt_grain_mark(_c, _x, _y, _w, _h, _grain, _body, _lit, _dark, _seed, _vert);
    crt_cx_restore(_c);
    return _drawn;
}

/// @function crt_grain_mark(ctx, x, y, w, h, grain, body, lit, dark, seed, vertical)
/// @description THE SURFACE'S OWN FIGURE - one branch per declared grain, read in exactly one place, which is why
/// forty materials are forty objects and not fourteen structures in forty colours. Returns marks laid.
function crt_grain_mark(_c, _x, _y, _w, _h, _grain, _body, _lit, _dark, _seed, _vert) {
    if (!is_string(_grain) || _grain == "none" || _w <= 1 || _h <= 1) return 0;
    var _drawn = 0;
    var _i, _j, _n, _t;
    var _along = _vert ? _h : _w;
    var _across = _vert ? _w : _h;
    crt_cx_save(_c);
    if (_grain == "straight") {
        // Straight-sawn: MANY close parallel lines - a sawn board's signal is DENSITY.
        var _sf = crt_repeats_for(_across, 1, 3);
        _c.lw = 1;
        _i = 0; _t = _sf.pitch * 0.5;
        while (_i < _sf.count) {
            _c.alpha = 0.45 + crt_nz(_seed + _i + 3) * 0.4;
            crt__ss(_c, (crt_nz(_seed + _i) > 0.45) ? _dark : _lit);
            crt__line_at(_c, _x, _y, _vert, 0, _t, _along, _t + (crt_nz(_seed + _i + 11) - 0.5) * 1.6);
            _drawn++; _t += _sf.pitch; _i++;
        }
        _c.alpha = 1;
    } else if (_grain == "figured") {
        // Figured timber BOWS toward one shared crown, so the curves NEST and read as one piece of timber.
        var _gf = crt_repeats_for(_across, 1, 3);
        _c.lw = 1;
        var _crown = _along * (0.3 + crt_nz(_seed) * 0.4);
        _i = 0; _t = _gf.pitch * 0.5;
        while (_i < _gf.count) {
            _c.alpha = 0.5 + crt_nz(_seed + _i + 3) * 0.4;
            crt__ss(_c, (crt_nz(_seed + _i) > 0.45) ? _dark : _lit);
            var _bow = (_t / max(1, _across) - 0.5) * _across * 0.9 + (crt_nz(_seed + _i) - 0.5) * _gf.pitch;
            var _mu = _crown, _mv = _t + _bow, _e1v = _t + (crt_nz(_seed + _i + 11) - 0.5) * _gf.pitch;
            crt_cx_begin(_c);
            if (_vert) { crt_cx_move(_c, _x + _t, _y); crt_cx_quad(_c, _x + _mv, _y + _mu, _x + _e1v, _y + _along); }
            else { crt_cx_move(_c, _x, _y + _t); crt_cx_quad(_c, _x + _mu, _y + _mv, _x + _along, _y + _e1v); }
            crt_cx_stroke(_c);
            _drawn++; _t += _gf.pitch; _i++;
        }
        _c.alpha = 1;
    } else if (_grain == "fibrous") {
        // Bast and sinew: fine fibres that BREAK, each running part of the length.
        var _fb = crt_repeats_for(_across, 1, 2);
        _c.lw = 1;
        _i = 0; _t = _fb.pitch * 0.5;
        while (_i < _fb.count) {
            for (_j = 0; _j < 3; _j++) {
                var _fu0 = crt_nz(_seed + _i * 7 + _j * 3) * _along;
                var _fu1 = _fu0 + _along * (0.10 + crt_nz(_seed + _i * 7 + _j * 3 + 1) * 0.35);
                _c.alpha = 0.4 + crt_nz(_seed + _i + _j) * 0.5;
                crt__ss(_c, (crt_nz(_seed + _i + _j * 5) > 0.5) ? _dark : _lit);
                crt__line_at(_c, _x, _y, _vert, _fu0, _t, min(_along, _fu1), _t + (crt_nz(_seed + _i + _j + 5) - 0.5) * 1.2);
                _drawn++;
            }
            _t += _fb.pitch; _i++;
        }
        _c.alpha = 1;
    } else if (_grain == "tooled") {
        // Tooled leather is STAMPED: a repeated punch in a grid, cut into the surface.
        var _tu = max(4, _across * 0.42);
        var _ta = crt_repeats_for(_along, _tu, 1.35), _tc = crt_repeats_for(_across, _tu, 1.35);
        _c.lw = 1;
        for (_i = 0; _i < _ta.count; _i++) {
            for (_j = 0; _j < _tc.count; _j++) {
                var _cu = _ta.pitch * (_i + 0.5), _cv = _tc.pitch * (_j + 0.5), _r = _tu * 0.30;
                crt__ss(_c, _dark);
                crt_cx_begin(_c);
                if (_vert) {
                    crt_cx_move(_c, _x + _cv, _y + _cu - _r); crt_cx_line(_c, _x + _cv, _y + _cu + _r);
                    crt_cx_move(_c, _x + _cv - _r, _y + _cu); crt_cx_line(_c, _x + _cv + _r, _y + _cu);
                } else {
                    crt_cx_move(_c, _x + _cu - _r, _y + _cv); crt_cx_line(_c, _x + _cu + _r, _y + _cv);
                    crt_cx_move(_c, _x + _cu, _y + _cv - _r); crt_cx_line(_c, _x + _cu, _y + _cv + _r);
                }
                crt_cx_stroke(_c);
                _drawn++;
            }
        }
    } else if (_grain == "pebbled") {
        // Raised grain: a lit cap over a shadowed underside - one flat dot is a speckle, not a texture.
        var _pu = max(2.4, _across * 0.22);
        var _pa = crt_repeats_for(_along, _pu, 1.5), _pcr = crt_repeats_for(_across, _pu, 1.5);
        for (_i = 0; _i < _pa.count; _i++) {
            for (_j = 0; _j < _pcr.count; _j++) {
                var _qu = _pa.pitch * (_i + 0.5) + (crt_nz(_seed + _i * 7 + _j) - 0.5) * _pu * 0.4;
                var _qv = _pcr.pitch * (_j + 0.5) + (crt_nz(_seed + _i + _j * 7) - 0.5) * _pu * 0.4;
                var _qx = _vert ? _x + _qv : _x + _qu, _qy = _vert ? _y + _qu : _y + _qv;
                crt__fs(_c, _dark);
                crt_cx_begin(_c); crt_cx_arc(_c, _qx, _qy + _pu * 0.14, _pu * 0.34, 0, pi * 2); crt_cx_fill(_c);
                crt__fs(_c, _lit);
                crt_cx_begin(_c); crt_cx_arc(_c, _qx, _qy - _pu * 0.10, _pu * 0.30, 0, pi * 2); crt_cx_fill(_c);
                _drawn++;
            }
        }
    } else if (_grain == "cleaved") {
        // Slate splits along FLAT planes: each sheet at its own tone with a lit fracture edge between them.
        var _cf = crt_repeats_for(_across, 2, 5);
        _i = 0; _t = 0;
        while (_i < _cf.count) {
            var _skew = (crt_nz(_seed + _i) - 0.5) * _across * 0.5;
            _c.alpha = 0.18 + crt_nz(_seed + _i * 3) * 0.2;
            crt__fs(_c, (crt_nz(_seed + _i * 3 + 1) > 0.5) ? _lit : _dark);
            crt_cx_begin(_c);
            if (_vert) {
                crt_cx_move(_c, _x + _t, _y); crt_cx_line(_c, _x + _t + _skew, _y + _along);
                crt_cx_line(_c, _x + _t + _skew + _cf.pitch, _y + _along); crt_cx_line(_c, _x + _t + _cf.pitch, _y);
            } else {
                crt_cx_move(_c, _x, _y + _t); crt_cx_line(_c, _x + _along, _y + _t + _skew);
                crt_cx_line(_c, _x + _along, _y + _t + _skew + _cf.pitch); crt_cx_line(_c, _x, _y + _t + _cf.pitch);
            }
            crt_cx_close(_c);
            crt_cx_fill(_c);
            _c.alpha = 1;
            _c.lw = 1.2;
            crt__ss(_c, _dark);
            crt__line_at(_c, _x, _y, _vert, 0, _t, _along, _t + _skew);
            _c.lw = 1;
            crt__ss(_c, _lit);
            crt__line_at(_c, _x, _y, _vert, 0, _t - 1.2, _along, _t + _skew - 1.2);
            _drawn++;
            _t += _cf.pitch; _i++;
        }
    } else if (_grain == "conchoidal") {
        // Obsidian fractures in SHELL-SHAPED ripples spreading from a strike point.
        _n = max(1, crt_jsround(_along / 90));
        _c.lw = 1;
        for (_i = 0; _i < _n; _i++) {
            var _ou = _along * ((_i + 0.5) / _n), _ov = _across * (0.3 + crt_nz(_seed + _i) * 0.4);
            var _ox = _vert ? _x + _ov : _x + _ou, _oy = _vert ? _y + _ou : _y + _ov;
            for (_j = 1; _j <= 4; _j++) {
                crt__ss(_c, (_j mod 2) ? _lit : _dark);
                _c.alpha = 0.75 - _j * 0.12;
                crt_cx_begin(_c);
                crt_cx_arc(_c, _ox, _oy, _across * 0.22 * _j, 0, pi * 2);
                crt_cx_stroke(_c);
                _drawn++;
            }
            _c.alpha = 1;
        }
    } else if (_grain == "mottled") {
        // Irregular soft BLOTCHES at two depths: inclusion, not dirt.
        _n = max(3, crt_jsround(_along / 18));
        for (_i = 0; _i < _n; _i++) {
            var _mu2 = crt_nz(_seed + _i * 5) * _along, _mv2 = crt_nz(_seed + _i * 5 + 1) * _across;
            var _mx = _vert ? _x + _mv2 : _x + _mu2, _my = _vert ? _y + _mu2 : _y + _mv2;
            _c.alpha = 0.22 + crt_nz(_seed + _i) * 0.26;
            crt__fs(_c, (crt_nz(_seed + _i + 3) > 0.45) ? _dark : _lit);
            crt_cx_begin(_c);
            crt_cx_ellipse(_c, _mx, _my, _across * (0.10 + crt_nz(_seed + _i + 9) * 0.26), _across * (0.07 + crt_nz(_seed + _i + 13) * 0.2), crt_nz(_seed + _i + 17) * 3.14, 0, pi * 2);
            crt_cx_fill(_c);
            _c.alpha = 1;
            _drawn++;
        }
    } else if (_grain == "porous") {
        // PITS: a dark disc with a LIT lower lip - the lip is what makes it a hole rather than a dot.
        var _vu = max(2.2, _across * 0.17);
        var _va = crt_repeats_for(_along, _vu, 1.7), _vc = crt_repeats_for(_across, _vu, 1.7);
        for (_i = 0; _i < _va.count; _i++) {
            for (_j = 0; _j < _vc.count; _j++) {
                if (crt_nz(_seed + _i * 11 + _j * 3) < 0.34) continue;
                var _pu2 = _va.pitch * (_i + 0.5) + (crt_nz(_seed + _i + _j) - 0.5) * _vu * 0.5;
                var _pv2 = _vc.pitch * (_j + 0.5) + (crt_nz(_seed + _i * 3 + _j) - 0.5) * _vu * 0.5;
                var _hx = _vert ? _x + _pv2 : _x + _pu2, _hy = _vert ? _y + _pu2 : _y + _pv2, _rad = _vu * (0.22 + crt_nz(_seed + _i * _j + 7) * 0.16);
                crt__fs(_c, _lit);
                crt_cx_begin(_c); crt_cx_arc(_c, _hx, _hy + _rad * 0.5, _rad, 0, pi * 2); crt_cx_fill(_c);
                crt__fs(_c, _dark);
                crt_cx_begin(_c); crt_cx_arc(_c, _hx, _hy, _rad, 0, pi * 2); crt_cx_fill(_c);
                _drawn++;
            }
        }
    } else if (_grain == "waterworn") {
        // A river stone has no hard edge anywhere: broad soft overlapping hollows, the tone ROLLING across it.
        _n = max(2, crt_jsround(_along / 55));
        for (_i = 0; _i < _n; _i++) {
            var _hu = _along * ((_i + 0.4 + crt_nz(_seed + _i) * 0.3) / _n);
            var _hv = _across * (0.2 + crt_nz(_seed + _i + 3) * 0.6);
            var _wx = _vert ? _x + _hv : _x + _hu, _wy = _vert ? _y + _hu : _y + _hv;
            var _wr = _across * (0.55 + crt_nz(_seed + _i + 7) * 0.7);
            var _wg = crt_cx_radial(_c, _wx, _wy, 0, _wx, _wy, max(2, _wr));
            var _tone = (crt_nz(_seed + _i * 5) > 0.5) ? _lit : _dark;
            crt_cx_stop(_wg, 0, crt__b(_tone), 0.5); crt_cx_stop(_wg, 1, crt__b(_tone), 0);
            _c.fill = _wg;
            crt_cx_begin(_c);
            crt_cx_arc(_c, _wx, _wy, max(2, _wr), 0, pi * 2);
            crt_cx_fill(_c);
            _drawn++;
        }
    } else if (_grain == "banded") {
        // Horn is layered ACROSS the piece - the opposite direction to every wood grain.
        var _bf = crt_repeats_for(_along, 3, 4);
        for (_i = 0; _i < _bf.count; _i++) {
            var _bu = _bf.pitch * _i;
            var _bw = _bf.pitch * (0.35 + crt_nz(_seed + _i) * 0.5);
            _c.alpha = 0.30;
            crt__fs(_c, (crt_nz(_seed + _i * 3) > 0.5) ? _dark : _lit);
            if (_vert) crt_cx_fill_rect(_c, _x, _y + _bu, _across, _bw);
            else crt_cx_fill_rect(_c, _x + _bu, _y, _bw, _across);
            _c.alpha = 1;
            _drawn++;
        }
    } else if (_grain == "crystal") {
        // Hoarfrost grows as NEEDLES from nucleation points - radiating, never parallel.
        _n = max(1, crt_jsround(_along / 46));
        _c.lw = 1;
        crt__ss(_c, _lit);
        for (_i = 0; _i < _n; _i++) {
            var _nu = _along * ((_i + 0.5) / _n), _nv = _across * (0.25 + crt_nz(_seed + _i) * 0.5);
            for (_j = 0; _j < 6; _j++) {
                var _ang = (_j / 6) * pi * 2 + crt_nz(_seed + _i * 7) * 1.4;
                var _len = _across * (0.28 + crt_nz(_seed + _i * 3 + _j) * 0.4);
                crt__line_at(_c, _x, _y, _vert, _nu, _nv, _nu + cos(_ang) * _len, _nv + sin(_ang) * _len);
                _drawn++;
            }
        }
    } else if (_grain == "frosted") {
        // Abraded glass: a dense fine speckle that kills reflection - many small marks, no structure.
        _n = max(8, crt_jsround((_w * _h) / 26));
        crt__fs(_c, _lit);
        _c.alpha = 0.5;
        for (_i = 0; _i < _n; _i++) { crt_cx_fill_rect(_c, _x + crt_nz(_seed + _i * 2) * _w, _y + crt_nz(_seed + _i * 2 + 1) * _h, 1, 1); _drawn++; }
        _c.alpha = 1;
    } else if (_grain == "hammered") {
        // Planished iron: overlapping shallow dishes, each catching the light on the SAME side.
        var _hu2 = max(4, _across * 0.5);
        var _ha = crt_repeats_for(_along, _hu2, 1.05), _hc = crt_repeats_for(_across, _hu2, 1.05);
        for (_i = 0; _i < _ha.count; _i++) {
            for (_j = 0; _j < _hc.count; _j++) {
                var _du = _ha.pitch * (_i + 0.5) + (_j mod 2) * _ha.pitch * 0.5;
                var _dv = _hc.pitch * (_j + 0.5);
                var _dx = _vert ? _x + _dv : _x + _du, _dy = _vert ? _y + _du : _y + _dv, _dr = _hu2 * 0.46;
                _c.alpha = 0.34;
                crt__fs(_c, _dark);
                crt_cx_begin(_c); crt_cx_arc(_c, _dx, _dy, _dr, 0, pi * 2); crt_cx_fill(_c);
                crt__fs(_c, _lit);
                crt_cx_begin(_c); crt_cx_arc(_c, _dx - _dr * 0.24, _dy - _dr * 0.24, _dr * 0.62, 0, pi * 2); crt_cx_fill(_c);
                _c.alpha = 1;
                _drawn++;
            }
        }
    } else if (_grain == "widmanstatten") {
        // The meteoric lattice: two families of long bands crossing at a fixed angle - no terrestrial metal has it.
        _c.lw = max(1, _across * 0.06);
        for (var _dir = 0; _dir < 2; _dir++) {
            var _slope = _dir ? 0.7 : -0.7;
            var _wfit = crt_repeats_for(_along, _c.lw, 5);
            var _lim = _wfit.count + ceil(_across / _wfit.pitch);
            for (_i = 0; _i < _lim; _i++) {
                var _su = _wfit.pitch * _i - _across * (_dir ? 0.7 : 0);
                crt__ss(_c, ((_i mod 3) == 0) ? _lit : _dark);
                _c.alpha = 0.5;
                crt__line_at(_c, _x, _y, _vert, _su, 0, _su + _across * _slope, _across);
                _c.alpha = 1;
                _drawn++;
            }
        }
    } else if (_grain == "iridescent") {
        // Nacre is laid in GROWTH ARCS; the arcs are why a shell is not a painted surface.
        _n = max(3, crt_jsround(_along / 20));
        _c.lw = 1.2;
        for (_i = 0; _i < _n; _i++) {
            var _iu = _along * (_i / _n) - _along * 0.1;
            crt__ss(_c, (_i mod 2) ? _lit : _dark);
            _c.alpha = 0.45;
            crt_cx_begin(_c);
            if (_vert) { crt_cx_move(_c, _x, _y + _iu); crt_cx_quad(_c, _x + _across * 0.5, _y + _iu + _along * 0.09, _x + _across, _y + _iu); }
            else { crt_cx_move(_c, _x + _iu, _y); crt_cx_quad(_c, _x + _iu + _along * 0.09, _y + _across * 0.5, _x + _iu, _y + _across); }
            crt_cx_stroke(_c);
            _c.alpha = 1;
            _drawn++;
        }
    } else if (_grain == "woven") {
        // A weave goes OVER AND UNDER: the alternation separates rush matting from a scored grid.
        var _vf = crt_repeats_for(_across, 1, 4);
        _c.lw = max(1, _vf.pitch * 0.42);
        _i = 0; _t = 0;
        while (_i < _vf.count) { crt__ss(_c, (_i mod 2) ? _dark : _lit); crt__line_at(_c, _x, _y, _vert, 0, _t, _along, _t); _drawn++; _t += _vf.pitch; _i++; }
        if (_vf.count > 0) {
            _i = 0; _t = 0;
            while (_t < _along) {
                crt__ss(_c, (_i mod 2) ? _lit : _dark);
                _c.alpha = 0.62;
                crt__line_at(_c, _x, _y, _vert, _t, 0, _t, _across);
                _c.alpha = 1;
                _drawn++; _t += _vf.pitch; _i++;
            }
        }
    } else if (_grain == "plated") {
        // Chitin: DIVISIONS across the run, each with a raised trailing lip - segments of one shell.
        var _pf = crt_repeats_for(_along, 2, 15);
        _c.lw = 1.6;
        for (_i = 1; _i < _pf.count; _i++) {
            var _xu = _pf.pitch * _i;
            crt__ss(_c, _dark);
            crt__line_at(_c, _x, _y, _vert, _xu, 0, _xu, _across);
            crt__ss(_c, _lit);
            _c.lw = 1;
            crt__line_at(_c, _x, _y, _vert, _xu + 1.8, 0, _xu + 1.8, _across);
            _c.lw = 1.6;
            _drawn++;
        }
    }
    crt_cx_restore(_c);
    return _drawn;
}

/// @function crt_lettering_layers(surface, frame, lettering, [want_ratio])
/// @description How a nameplate's letters are made - as LAYERS in draw order, every colour solved against the plate
/// it sits on: incised (a lit lip BELOW, drawn first), struck (the burr up-left), gilt (gold seated in its shadow,
/// darkened until it reads), chalk (a lighter hand with a dusty pass), painted. Returns [{colour, dx, dy, alpha, bold}].
function crt_lettering_layers(_surf, _frame, _let, _want = CRT_AAA_RATIO) {
    var _solved = crt_ink_for(_surf, _frame, _want, 0);
    var _lip = crt_relief(_surf, 1, 20);
    var _seat = crt_relief(_surf, -1, 20);
    if (_let == "incised") return [{ colour: _lip, dx: 0.9, dy: 1.2, alpha: 1, bold: true }, { colour: _solved, dx: 0, dy: 0, alpha: 1, bold: true }];
    if (_let == "struck") return [{ colour: _lip, dx: -0.9, dy: -1.1, alpha: 1, bold: true }, { colour: _solved, dx: 0, dy: 0, alpha: 1, bold: true }];
    if (_let == "gilt") return [{ colour: _seat, dx: 1.1, dy: 1.3, alpha: 1, bold: true }, { colour: crt_ink_for(_surf, [212, 175, 92], _want, 0), dx: 0, dy: 0, alpha: 1, bold: true }];
    if (_let == "chalk") {
        var _ck = crt_ink_for(_surf, [242, 240, 232], _want, 0);
        return [{ colour: _ck, dx: 0.7, dy: 0.7, alpha: 0.35, bold: false }, { colour: _ck, dx: 0, dy: 0, alpha: 0.95, bold: false }];
    }
    return [{ colour: _solved, dx: 0, dy: 0, alpha: 1, bold: true }];
}

/// @function crt_arcade_run(ctx, x, y, w, h, body, lit, dark)
/// @description Blind arcading along the head rail: a row of small arches, the count derived from the run. Returns
/// the arch count (0 when the rail cannot carry two).
function crt_arcade_run(_c, _x, _y, _w, _h, _body, _lit, _dark) {
    if (_h < 5 || _w < 20) return 0;
    var _unit = max(10, _h * 1.15);
    var _fit = crt_repeats_for(_w, _unit, 1.0, 1.5);
    if (_fit.count < 2) return 0;
    crt_cx_save(_c);
    crt__ss(_c, _dark);
    _c.lw = crt_pen_for(_h * 0.3, _fit.pitch, _h);
    crt__fs(_c, crt_mix(_body, _dark, 0.35));
    var _pad = (_w - _fit.count * _fit.pitch) / 2;
    for (var _i = 0; _i < _fit.count; _i++) {
        var _ax = _x + _pad + _i * _fit.pitch + _fit.pitch * 0.12;
        var _aw = _fit.pitch * 0.76;
        var _r = _aw / 2;
        crt_cx_begin(_c);
        crt_cx_move(_c, _ax, _y + _h);
        crt_cx_line(_c, _ax, _y + _h - (_h - _r) * 0.9);
        crt_cx_arc(_c, _ax + _r, _y + _h - (_h - _r) * 0.9, _r, pi, 0);
        crt_cx_line(_c, _ax + _aw, _y + _h);
        crt_cx_close(_c);
        crt_cx_fill(_c);
        crt_cx_stroke(_c);
    }
    crt_cx_restore(_c);
    return _fit.count;
}

/// @function crt_crest_drop(rail_h, level)
/// @description How far a crest eats up into its own rail. ONE declaration: the soffit shapes the edge and the arcade
/// stands on it. Pure.
function crt_crest_drop(_railH, _level) {
    if (_level <= 0 || _railH < 6) return 0;
    return _railH * ((_level == 1) ? 0.30 : 0.52);
}

/// @function crt_crest_soffit(ctx, x, y, w, rail_h, level, body, lit, dark)
/// @description The head rail's inner SILHOUETTE - on a box this wide and shallow, the one line that runs the whole
/// width against the bright field. Level 1 is a scalloped soffit, 2 a central arch with pendants. Returns the level.
function crt_crest_soffit(_c, _x, _y, _w, _railH, _level, _body, _lit, _dark) {
    if (_level <= 0 || _railH < 6) return 0;
    var _drop = crt_crest_drop(_railH, _level);
    crt_cx_save(_c);
    crt__fs(_c, _body);
    crt__ss(_c, _dark);
    _c.lw = crt_pen_for(_railH * 0.22, _w, _railH);
    crt_cx_begin(_c);
    crt_cx_move(_c, _x, _y);
    crt_cx_line(_c, _x + _w, _y);
    crt_cx_line(_c, _x + _w, _y + _railH);
    if (_level == 1) {
        var _unit = max(14, _railH * 1.6);
        var _fit = crt_repeats_for(_w, _unit, 1.0, 2.0);
        var _n = max(2, _fit.count);
        var _step = _w / _n;
        for (var _i = _n - 1; _i >= 0; _i--) crt_cx_quad(_c, _x + _step * (_i + 0.5), _y + _railH - _drop * 2, _x + _step * _i, _y + _railH);
    } else {
        crt_cx_line(_c, _x + _w * 0.80, _y + _railH);
        crt_cx_quad(_c, _x + _w * 0.76, _y + _railH - _drop * 0.55, _x + _w * 0.70, _y + _railH - _drop * 0.55);
        crt_cx_bezier(_c, _x + _w * 0.60, _y + _railH - _drop * 1.75, _x + _w * 0.40, _y + _railH - _drop * 1.75, _x + _w * 0.30, _y + _railH - _drop * 0.55);
        crt_cx_quad(_c, _x + _w * 0.24, _y + _railH - _drop * 0.55, _x + _w * 0.20, _y + _railH);
    }
    crt_cx_line(_c, _x, _y + _railH);
    crt_cx_close(_c);
    crt_cx_fill(_c);
    crt_cx_stroke(_c);
    // a bright lip along the shaped edge, so the soffit reads as an edge with thickness, not an outline
    crt__ss(_c, _lit);
    _c.lw = max(1, _c.lw * 0.55);
    crt_cx_stroke(_c);
    crt_cx_restore(_c);
    return _level;
}

/// @function crt_joint_mark(ctx, cx, cy, rail, joint, q, body, lit, dark)
/// @description How the rails are JOINED, where they meet (quadrant q, 0 = top-left, clockwise). `cast` and `none`
/// honestly draw nothing. Returns marks laid.
function crt_joint_mark(_c, _cx, _cy, _rail, _joint, _q, _body, _lit, _dark) {
    if (_joint == "cast" || _joint == "none") return 0;
    crt_cx_save(_c);
    crt_cx_translate(_c, _cx, _cy);
    crt_cx_rotate(_c, (pi / 2) * _q);
    crt__ss(_c, _dark);
    crt__fs(_c, _lit);
    _c.lw = max(1, _rail * 0.12);
    var _r = _rail, _drawn = 0;
    if (_joint == "mitre") {
        crt_cx_begin(_c); crt_cx_move(_c, 0, 0); crt_cx_line(_c, _r, _r); crt_cx_stroke(_c); _drawn = 1;
    } else if (_joint == "butt") {
        crt_cx_begin(_c); crt_cx_move(_c, _r, 0); crt_cx_line(_c, _r, _r); crt_cx_stroke(_c); _drawn = 1;
    } else if (_joint == "lap") {
        crt_cx_begin(_c); crt_cx_move(_c, _r, 0); crt_cx_line(_c, _r, _r); crt_cx_line(_c, 0, _r); crt_cx_stroke(_c); _drawn = 1;
    } else if (_joint == "peg") {
        crt_cx_begin(_c); crt_cx_arc(_c, _r * 0.5, _r * 0.5, max(1.4, _r * 0.18), 0, pi * 2);
        crt_cx_fill(_c); crt_cx_stroke(_c); _drawn = 1;
    } else if (_joint == "strap") {
        crt_cx_begin(_c);
        crt_cx_move(_c, _r * 1.7, _r * 0.28); crt_cx_line(_c, _r * 0.28, _r * 1.7);
        _c.lw = max(2, _rail * 0.3);
        crt__ss(_c, _lit); crt_cx_stroke(_c);
        crt__ss(_c, _dark); _c.lw = 1; crt_cx_stroke(_c);
        _drawn = 1;
    } else if (_joint == "lash") {
        _c.lw = max(1, _rail * 0.14);
        for (var _i = 0; _i < 3; _i++) {
            crt_cx_begin(_c);
            crt_cx_move(_c, _r * (0.9 + _i * 0.4), _r * 0.1);
            crt_cx_line(_c, _r * 0.1, _r * (0.9 + _i * 0.4));
            crt_cx_stroke(_c); _drawn++;
        }
    } else if (_joint == "lead") {
        _c.lw = max(2, _rail * 0.22);
        crt__ss(_c, _dark);
        crt_cx_begin(_c); crt_cx_move(_c, 0, _r * 1.2); crt_cx_line(_c, _r * 1.2, 0); crt_cx_stroke(_c); _drawn = 1;
    }
    crt_cx_restore(_c);
    return _drawn;
}

/// @function crt_moulded_rail(ctx, x, y, w, h, steps, body, lit, dark, side)
/// @description A rail's section: `steps` mouldings stepped in from the outer edge, lit from the upper left. `side` is
/// "top", "bottom", "left" or "right", so the four rails read as four faces of one moulding.
function crt_moulded_rail(_c, _x, _y, _w, _h, _steps, _body, _lit, _dark, _side) {
    var _n = max(1, floor(_steps));
    var _vert = (_side == "left" || _side == "right");
    var _depth = (_vert ? _w : _h) / _n;
    for (var _i = 0; _i < _n; _i++) {
        var _out = (_side == "top" || _side == "left") ? ((_i mod 2) == 0) : ((_i mod 2) == 1);
        crt__fs(_c, (_i == 0) ? _body : (_out ? _lit : _dark));
        if (_vert) {
            var _xs = (_side == "left") ? _x + _i * _depth : _x + _w - (_i + 1) * _depth;
            crt_cx_fill_rect(_c, _xs, _y, _depth + 0.5, _h);
        } else {
            var _ys = (_side == "top") ? _y + _i * _depth : _y + _h - (_i + 1) * _depth;
            crt_cx_fill_rect(_c, _x, _ys, _w, _depth + 0.5);
        }
    }
}

/// @function crt_band_run(ctx, x, y, len, thick, motif, pitch_mul, depth, cut, body, lit, dark, vertical)
/// @description A repeated treatment along one rail. The count is derived HERE from the run: {count, pitch, floored}.
/// `incised` bites into the rail (dark marks), `raised` stands proud (lit marks).
function crt_band_run(_c, _x, _y, _len, _thick, _motif, _mul, _depthK, _cut, _body, _lit, _dark, _vert) {
    var _fit = crt_repeats_for(_len, _thick, _mul);
    if (_fit.count <= 0) return _fit;
    var _mark = (_cut == "incised") ? _dark : _lit;
    var _back = (_cut == "incised") ? _lit : _dark;
    var _t = _thick;
    var _d = max(1, _t * _depthK);
    crt_cx_save(_c);
    crt_cx_translate(_c, _x, _y);
    if (_vert) { crt_cx_rotate(_c, pi / 2); crt_cx_scale(_c, 1, -1); }
    for (var _i = 0; _i < _fit.count; _i++) {
        var _u = (_i + 0.5) * _fit.pitch;
        var _mid = _t / 2;
        var _p = _fit.pitch;
        crt__fs(_c, _mark);
        crt__ss(_c, _mark);
        _c.lw = max(1, _t * 0.16);
        if (_motif == "bead" || _motif == "dot" || _motif == "nail") {
            var _r = (_motif == "nail") ? _d * 0.42 : _d * 0.5;
            crt_cx_begin(_c); crt_cx_arc(_c, _u, _mid, _r, 0, pi * 2); crt_cx_fill(_c);
            if (_motif == "nail") {
                crt_cx_begin(_c); crt_cx_arc(_c, _u - _r * 0.3, _mid - _r * 0.3, _r * 0.42, 0, pi * 2);
                crt__fs(_c, _back); crt_cx_fill(_c);
            }
        } else if (_motif == "cable") {
            crt_cx_begin(_c); crt_cx_move(_c, _u - _p * 0.5, _mid + _d * 0.5); crt_cx_quad(_c, _u, _mid - _d * 0.9, _u + _p * 0.5, _mid + _d * 0.5); crt_cx_stroke(_c);
        } else if (_motif == "chevron" || _motif == "triangle") {
            crt_cx_begin(_c);
            crt_cx_move(_c, _u - _p * 0.36, _mid + _d * 0.5); crt_cx_line(_c, _u, _mid - _d * 0.55); crt_cx_line(_c, _u + _p * 0.36, _mid + _d * 0.5);
            if (_motif == "triangle") { crt_cx_close(_c); crt_cx_fill(_c); } else crt_cx_stroke(_c);
        } else if (_motif == "reed") {
            crt_cx_begin(_c); crt_cx_move(_c, _u, _mid - _d * 0.6); crt_cx_line(_c, _u, _mid + _d * 0.6); crt_cx_stroke(_c);
        } else if (_motif == "notch") {
            crt_cx_begin(_c);
            crt_cx_move(_c, _u - _d * 0.28, _mid - _d * 0.6); crt_cx_line(_c, _u + _d * 0.28, _mid - _d * 0.6); crt_cx_line(_c, _u, _mid + _d * 0.35);
            crt_cx_close(_c); crt_cx_fill(_c);
        } else if (_motif == "scallop") {
            crt_cx_begin(_c); crt_cx_arc(_c, _u, _mid + _d * 0.35, _d * 0.55, pi, 0); crt_cx_fill(_c);
        } else if (_motif == "guilloche" || _motif == "wave") {
            crt_cx_begin(_c); crt_cx_move(_c, _u - _p * 0.5, _mid);
            crt_cx_bezier(_c, _u - _p * 0.25, _mid - _d * 0.8, _u + _p * 0.25, _mid + _d * 0.8, _u + _p * 0.5, _mid);
            crt_cx_stroke(_c);
        } else if (_motif == "fret") {
            crt_cx_begin(_c);
            crt_cx_move(_c, _u - _p * 0.34, _mid + _d * 0.45); crt_cx_line(_c, _u - _p * 0.34, _mid - _d * 0.45);
            crt_cx_line(_c, _u + _p * 0.10, _mid - _d * 0.45); crt_cx_line(_c, _u + _p * 0.10, _mid + _d * 0.10);
            crt_cx_stroke(_c);
        } else if (_motif == "chain") {
            crt_cx_begin(_c); crt_cx_ellipse(_c, _u, _mid, _p * 0.30, _d * 0.48, 0, 0, pi * 2); crt_cx_stroke(_c);
        } else if (_motif == "barb" || _motif == "feather") {
            crt_cx_begin(_c); crt_cx_move(_c, _u - _p * 0.4, _mid + _d * 0.5); crt_cx_quad(_c, _u, _mid - _d * 0.2, _u + _p * 0.42, _mid - _d * 0.62); crt_cx_stroke(_c);
        } else if (_motif == "wrap") {
            crt_cx_begin(_c); crt_cx_move(_c, _u - _p * 0.3, _mid + _d * 0.62); crt_cx_line(_c, _u + _p * 0.3, _mid - _d * 0.62); crt_cx_stroke(_c);
        } else if (_motif == "rune") {
            crt_cx_begin(_c);
            crt_cx_move(_c, _u, _mid - _d * 0.6); crt_cx_line(_c, _u, _mid + _d * 0.6);
            crt_cx_move(_c, _u - _d * 0.34, _mid - _d * 0.24); crt_cx_line(_c, _u + _d * 0.34, _mid + _d * 0.16);
            crt_cx_stroke(_c);
        } else if (_motif == "ray") {
            crt_cx_begin(_c);
            crt_cx_move(_c, _u, _mid + _d * 0.62); crt_cx_line(_c, _u - _d * 0.20, _mid - _d * 0.62); crt_cx_line(_c, _u + _d * 0.20, _mid - _d * 0.62);
            crt_cx_close(_c); crt_cx_fill(_c);
        }
    }
    crt_cx_restore(_c);
    return _fit;
}

/// @function crt_corner_mark(ctx, cx, cy, rail, span, form, reach, pieces, q, body, lit, dark, max_out)
/// @description A corner treatment into quadrant q (0 = top-left, clockwise). ⛔ Three scales: the stile `rail` sizes
/// the PEN, the head rail `span` sizes how far the piece REACHES, and `max_out` is the margin it may project into -
/// the whole piece is scaled uniformly to fit it, never cut off. Every piece starts INSIDE the rail it grows from.
/// Returns marks laid.
function crt_corner_mark(_c, _cx, _cy, _rail, _span, _form, _reach, _pieces, _q, _body, _lit, _dark, _maxOut) {
    if (_form == "square" || _reach <= 0) return 0;
    var _drawn = 0;
    var _R0 = _span * _reach;
    var _fit = (_maxOut > 0 && _R0 > _maxOut) ? _maxOut / _R0 : 1;
    crt_cx_save(_c);
    crt_cx_translate(_c, _cx, _cy);
    crt_cx_rotate(_c, (pi / 2) * _q);
    if (_fit != 1) crt_cx_scale(_c, _fit, _fit);
    crt__fs(_c, _lit);
    crt__ss(_c, _dark);
    _c.lw = crt_pen_for(_rail * 0.3, _R0, _R0);
    var _root = -_rail * 0.35;
    if (_form == "chamfer") {
        crt_cx_begin(_c);
        crt_cx_move(_c, _root, _R0); crt_cx_line(_c, _R0, _root); crt_cx_line(_c, _root, _root); crt_cx_close(_c);
        crt__fs(_c, _dark); crt_cx_fill(_c); _drawn++;
    } else if (_form == "round") {
        crt_cx_begin(_c);
        crt_cx_move(_c, _root, _R0); crt_cx_quad(_c, _root, _root, _R0, _root);
        crt_cx_line(_c, _root, _root); crt_cx_close(_c);
        crt__fs(_c, _dark); crt_cx_fill(_c); _drawn++;
    } else if (_form == "shoulder" || _form == "lap" || _form == "bracket") {
        crt_cx_begin(_c);
        crt_cx_move(_c, _root, _R0); crt_cx_line(_c, _R0 * 0.45, _R0 * 0.45); crt_cx_line(_c, _R0, _root); crt_cx_line(_c, _root, _root);
        crt_cx_close(_c);
        crt_cx_fill(_c); crt_cx_stroke(_c); _drawn++;
        if (_pieces > 1 && _form == "bracket") {
            crt_cx_begin(_c);
            crt_cx_move(_c, _root, _R0 * 0.75); crt_cx_quad(_c, _R0 * 0.35, _R0 * 0.35, _R0 * 0.75, _root);
            crt_cx_stroke(_c); _drawn++;
        }
    } else if (_form == "volute" || _form == "curled" || _form == "snag") {
        crt_cx_begin(_c);
        crt_cx_move(_c, _root, _R0);
        crt_cx_bezier(_c, _R0 * 0.10, _R0 * 0.55, _R0 * 0.55, _R0 * 0.45, _R0 * 0.62, _R0 * 0.02);
        crt_cx_bezier(_c, _R0 * 0.66, -_R0 * 0.30, _R0 * 0.30, -_R0 * 0.42, _R0 * 0.16, -_R0 * 0.18);
        crt_cx_stroke(_c); _drawn++;
    } else if (_form == "crest" || _form == "finial" || _form == "flower" || _form == "halo") {
        crt_cx_begin(_c);
        crt_cx_move(_c, _root, _R0 * 0.30);
        crt_cx_quad(_c, _R0 * 0.30, _R0 * 0.30, _R0 * 0.42, _root);
        crt_cx_quad(_c, _R0 * 0.55, -_R0 * 0.55, _R0 * 0.05, -_R0 * 0.42);
        crt_cx_quad(_c, _root, -_R0 * 0.35, _root, _R0 * 0.30);
        crt_cx_close(_c);
        crt_cx_fill(_c); crt_cx_stroke(_c); _drawn++;
        // ⛔ the radius is CLAMPED: `0.22 - p * 0.05` goes negative at p >= 5, and a buyer's corpus edit must never
        // crash a message box
        for (var _p = 1; _p < _pieces; _p++) {
            var _pr = _R0 * (0.22 - _p * 0.05);
            if (_pr < 0.6) break;
            crt_cx_begin(_c);
            crt_cx_arc(_c, _R0 * 0.18 * _p, -_R0 * 0.18 * _p, _pr, 0, pi * 2);
            crt__fs(_c, (_p mod 2) ? _dark : _lit);
            crt_cx_fill(_c); _drawn++;
        }
    } else if (_form == "spur" || _form == "hook" || _form == "talon" || _form == "tusk" || _form == "horn") {
        var _curl = (_form == "hook" || _form == "talon") ? -0.55 : ((_form == "horn") ? -0.30 : -0.05);
        crt_cx_begin(_c);
        crt_cx_move(_c, _root, _R0 * 0.34);
        crt_cx_quad(_c, _R0 * 0.55, _R0 * 0.10, _R0 * 0.92, _R0 * _curl);
        crt_cx_quad(_c, _R0 * 0.50, -_R0 * 0.02, _root, -_R0 * 0.10);
        crt_cx_close(_c);
        crt_cx_fill(_c); crt_cx_stroke(_c); _drawn++;
        if (_pieces > 2) {
            crt_cx_begin(_c);
            crt_cx_move(_c, _root, -_R0 * 0.10);
            crt_cx_quad(_c, _R0 * 0.30, -_R0 * 0.45, _R0 * 0.58, -_R0 * 0.52);
            crt_cx_quad(_c, _R0 * 0.26, -_R0 * 0.26, _root, -_R0 * 0.30);
            crt_cx_close(_c);
            crt_cx_fill(_c); crt_cx_stroke(_c); _drawn++;
        }
    } else if (_form == "break") {
        crt_cx_begin(_c);
        crt_cx_move(_c, _root, _R0); crt_cx_line(_c, _R0 * 0.30, _R0 * 0.20); crt_cx_line(_c, _R0 * 0.10, _R0 * 0.10);
        crt_cx_line(_c, _R0, _root); crt_cx_line(_c, _root, _root); crt_cx_close(_c);
        crt__fs(_c, _dark); crt_cx_fill(_c); _drawn++;
    } else if (_form == "bud" || _form == "leaf") {
        crt_cx_begin(_c);
        crt_cx_move(_c, _root, _R0 * 0.20);
        crt_cx_quad(_c, _R0 * 0.20, _R0 * 0.10, _R0 * 0.70, -_R0 * 0.35);
        crt_cx_quad(_c, _R0 * 0.12, -_R0 * 0.10, _root, -_R0 * 0.22);
        crt_cx_close(_c);
        crt_cx_fill(_c); crt_cx_stroke(_c); _drawn++;
        if (_form == "leaf") {
            crt_cx_begin(_c);
            crt_cx_move(_c, _root, -_R0 * 0.02); crt_cx_quad(_c, _R0 * 0.24, -_R0 * 0.08, _R0 * 0.62, -_R0 * 0.30);
            crt_cx_stroke(_c); _drawn++;
        }
    } else if (_form == "ray") {
        var _k = max(3, _pieces + 2);
        for (var _i = 0; _i < _k; _i++) {
            var _a = -pi * 0.05 - _i * (pi * 0.42) / _k;
            crt_cx_begin(_c);
            crt_cx_move(_c, _root, _root);
            crt_cx_line(_c, cos(_a) * _R0, sin(_a) * _R0);
            crt_cx_stroke(_c); _drawn++;
        }
    }
    crt_cx_restore(_c);
    return _drawn;
}

/// @function crt_reserve_path(ctx, x, y, w, h, head)
/// @description Trace the portrait aperture (head 0 square with cut corners, 1 round-arched, 2 pointed) as the
/// current path. The recess and the portrait clip are BOTH traced by this one function.
function crt_reserve_path(_c, _x, _y, _w, _h, _head) {
    var _r = min(_w * 0.5, _h * 0.42);
    crt_cx_begin(_c);
    if (_head == 2) {
        // ⛔ A LANCET, and it must READ as pointed. The original's two quadratics had their controls near the top
        // corners, so both arrived at the apex nearly horizontal and the niche baked as a flattened basket arch under a
        // caption saying "pointed" (found by zooming the store plate, 2026-09-28). Each side now leaves the springing
        // VERTICALLY and reaches the apex at about 50 degrees, as a gothic arch does. Same single path, same op count.
        crt_cx_move(_c, _x, _y + _h);
        crt_cx_line(_c, _x, _y + _r);
        crt_cx_bezier(_c, _x, _y + _r * 0.45, _x + _w * 0.42, _y + _r * 0.2, _x + _w / 2, _y);
        crt_cx_bezier(_c, _x + _w * 0.58, _y + _r * 0.2, _x + _w, _y + _r * 0.45, _x + _w, _y + _r);
        crt_cx_line(_c, _x + _w, _y + _h);
    } else if (_head == 1) {
        crt_cx_move(_c, _x, _y + _h);
        crt_cx_line(_c, _x, _y + _r);
        crt_cx_arc(_c, _x + _w / 2, _y + _r, _w / 2, pi, 0);
        crt_cx_line(_c, _x + _w, _y + _h);
    } else {
        var _cc = min(_w, _h) * 0.10;
        crt_cx_move(_c, _x, _y + _h);
        crt_cx_line(_c, _x, _y + _cc);
        crt_cx_line(_c, _x + _cc, _y);
        crt_cx_line(_c, _x + _w - _cc, _y);
        crt_cx_line(_c, _x + _w, _y + _cc);
        crt_cx_line(_c, _x + _w, _y + _h);
    }
    crt_cx_close(_c);
}

/// @function crt_reserve_recess(ctx, x, y, w, h, head, field, body, lit, dark)
/// @description The sunk panel a portrait sits in: its floor, a DIRECTIONAL rebate (shadow inside the top-left edge,
/// light inside the bottom-right - the opposite of a raised plate), and a rim of the frame's own stock. Returns
/// marks laid.
function crt_reserve_recess(_c, _x, _y, _w, _h, _head, _field, _body, _lit, _dark) {
    if (_w < 12 || _h < 12) return 0;
    var _drawn = 0;
    crt_cx_save(_c);
    crt_reserve_path(_c, _x, _y, _w, _h, _head);
    crt__fs(_c, crt_mix(_field, [0, 0, 0], 0.10));
    crt_cx_fill(_c); _drawn++;
    crt_cx_save(_c);
    crt_reserve_path(_c, _x, _y, _w, _h, _head);
    crt_cx_clip(_c);
    var _t = max(2, min(_w, _h) * 0.045);
    _c.lw = _t * 2;
    crt__ss(_c, crt_relief(_field, -1, 34));
    crt_cx_save(_c); crt_cx_translate(_c, _t * 0.6, _t * 0.6);
    crt_reserve_path(_c, _x, _y, _w, _h, _head); crt_cx_stroke(_c); crt_cx_restore(_c); _drawn++;
    crt__ss(_c, crt_relief(_field, 1, 22));
    crt_cx_save(_c); crt_cx_translate(_c, -_t * 0.6, -_t * 0.6);
    crt_reserve_path(_c, _x, _y, _w, _h, _head); crt_cx_stroke(_c); crt_cx_restore(_c); _drawn++;
    crt_cx_restore(_c);
    crt_reserve_path(_c, _x, _y, _w, _h, _head);
    _c.lw = crt_pen_for(max(1.4, min(_w, _h) * 0.035), _w, _h) * 2.2;
    crt__ss(_c, _body);
    crt_cx_stroke(_c); _drawn++;
    _c.lw = max(1, _c.lw * 0.34);
    crt__ss(_c, _lit);
    crt_cx_stroke(_c); _drawn++;
    crt_cx_restore(_c);
    return _drawn;
}

/// @function crt_plate_face(form, body, dark)
/// @description The colour a plate face is FILLED with - one declaration, read by the plate and by the lettering
/// solve, so a name is never solved against a surface it is not drawn on. Pure.
function crt_plate_face(_form, _body, _dark) { return (_form == "rule") ? _dark : _body; }

/// @function crt_plate_shape(ctx, x, y, w, h, form, attach, body, lit, dark)
/// @description The nameplate body (the lettering is the caller's): a let-in plate casts INWARD, a riveted or hung
/// one casts OUTWARD and carries its fixings. Forms: rule, tag, band, tablet, lozenge, cartouche, board, boss.
function crt_plate_shape(_c, _x, _y, _w, _h, _form, _attach, _body, _lit, _dark) {
    var _r = min(_h * 0.34, _w * 0.12);
    var _sunk = (_attach == "let-in");
    crt_cx_save(_c);
    crt__fs(_c, _dark);
    var _off = max(1.5, _h * 0.10);
    crt_cx_begin(_c);
    if (_sunk) crt_cx_round_rect(_c, _x - _off * 0.5, _y - _off * 0.5, _w + _off, _h + _off, _r);
    else crt_cx_round_rect(_c, _x + _off * 0.6, _y + _off * 0.7, _w, _h, _r);
    crt_cx_fill(_c);
    crt_cx_begin(_c);
    if (_form == "lozenge") {
        crt_cx_move(_c, _x + _w / 2, _y); crt_cx_line(_c, _x + _w, _y + _h / 2); crt_cx_line(_c, _x + _w / 2, _y + _h); crt_cx_line(_c, _x, _y + _h / 2);
        crt_cx_close(_c);
    } else if (_form == "boss") {
        crt_cx_ellipse(_c, _x + _w / 2, _y + _h / 2, _w / 2, _h / 2, 0, 0, pi * 2);
    } else if (_form == "cartouche") {
        crt_cx_move(_c, _x + _h * 0.5, _y);
        crt_cx_line(_c, _x + _w - _h * 0.5, _y);
        crt_cx_quad(_c, _x + _w + _h * 0.22, _y + _h / 2, _x + _w - _h * 0.5, _y + _h);
        crt_cx_line(_c, _x + _h * 0.5, _y + _h);
        crt_cx_quad(_c, _x - _h * 0.22, _y + _h / 2, _x + _h * 0.5, _y);
        crt_cx_close(_c);
    } else if (_form == "tag" || _form == "board") {
        crt_cx_round_rect(_c, _x, _y, _w, _h, _r);
    } else if (_form == "rule") {
        crt_cx_rect(_c, _x, _y + _h - max(1.4, _h * 0.14), _w, max(1.4, _h * 0.14));
    } else {
        crt_cx_round_rect(_c, _x, _y, _w, _h, _r * 0.5);
    }
    crt__fs(_c, crt_plate_face(_form, _body, _dark));
    crt_cx_fill(_c);
    if (_form != "rule") {
        crt__ss(_c, _sunk ? _dark : _lit);
        _c.lw = crt_pen_for(_h * 0.2, _w, _h);
        crt_cx_stroke(_c);
    }
    if (_attach == "hung" || _attach == "riveted") {
        var _n = (_attach == "hung") ? 2 : 4;
        for (var _i = 0; _i < _n; _i++) {
            var _px = _x + (((_i mod 2) == 0) ? _w * 0.08 : _w * 0.92);
            var _py = _y + _h * 0.5;
            if (_attach == "riveted") _py = _y + ((_i < 2) ? _h * 0.22 : _h * 0.78);
            crt_cx_begin(_c);
            crt_cx_arc(_c, _px, _py, max(1.2, _h * 0.09), 0, pi * 2);
            crt__fs(_c, _lit);
            crt_cx_fill(_c);
        }
    }
    crt_cx_restore(_c);
}

/// @function crt_caret_mark(ctx, cx, cy, size, form, motion, phase, colour, dim)
/// @description The advance caret, which belongs to the speaker's set. ⛔ `phase` is an explicit number 0..1, never a
/// clock (a still is phase 0), so a capture is reproducible. Motions: bob, drift, pulse.
function crt_caret_mark(_c, _cx, _cy, _size, _form, _motion, _phase, _col, _dim) {
    var _ph = is_numeric(_phase) ? _phase : 0;
    var _bob = (_motion == "bob") ? sin(_ph * pi * 2) * _size * 0.22 : 0;
    var _drift = (_motion == "drift") ? sin(_ph * pi * 2) * _size * 0.16 : 0;
    var _pulse = (_motion == "pulse") ? 0.86 + sin(_ph * pi * 2) * 0.14 : 1;
    var _s = _size * _pulse;
    if (is_undefined(_dim)) _dim = _col;
    crt_cx_save(_c);
    crt_cx_translate(_c, _cx + _drift, _cy + _bob);
    crt__fs(_c, _col);
    crt__ss(_c, _col);
    _c.lw = max(1, _size * 0.14);
    crt_cx_begin(_c);
    if (_form == "chevron" || _form == "wedge") {
        crt_cx_move(_c, -_s * 0.6, -_s * 0.35); crt_cx_line(_c, 0, _s * 0.45); crt_cx_line(_c, _s * 0.6, -_s * 0.35);
        if (_form == "wedge") { crt_cx_close(_c); crt_cx_fill(_c); } else crt_cx_stroke(_c);
    } else if (_form == "barb") {
        // a barb hooks BACKWARD - the hook is the whole difference from the company's chevron
        crt_cx_move(_c, -_s * 0.55, -_s * 0.45); crt_cx_line(_c, 0, _s * 0.5); crt_cx_line(_c, _s * 0.55, -_s * 0.45);
        crt_cx_stroke(_c);
        crt_cx_begin(_c);
        crt_cx_move(_c, 0, _s * 0.5); crt_cx_line(_c, -_s * 0.30, _s * 0.02);
        crt_cx_move(_c, 0, _s * 0.5); crt_cx_line(_c, _s * 0.30, _s * 0.02);
        crt_cx_stroke(_c);
    } else if (_form == "lozenge" || _form == "mote") {
        crt_cx_move(_c, 0, -_s * 0.55); crt_cx_line(_c, _s * 0.42, 0); crt_cx_line(_c, 0, _s * 0.55); crt_cx_line(_c, -_s * 0.42, 0);
        crt_cx_close(_c); crt_cx_fill(_c);
    } else if (_form == "pennon") {
        crt_cx_move(_c, -_s * 0.5, -_s * 0.5); crt_cx_line(_c, _s * 0.5, -_s * 0.2); crt_cx_line(_c, -_s * 0.5, _s * 0.1);
        crt_cx_close(_c); crt_cx_fill(_c);
        crt_cx_begin(_c); crt_cx_move(_c, -_s * 0.5, -_s * 0.55); crt_cx_line(_c, -_s * 0.5, _s * 0.55); crt_cx_stroke(_c);
    } else if (_form == "drop") {
        // heavy at the BOTTOM, drawn to a point at the top by the thread it hangs on
        crt_cx_move(_c, 0, _s * 0.55);
        crt_cx_quad(_c, _s * 0.48, _s * 0.05, 0, -_s * 0.55);
        crt_cx_quad(_c, -_s * 0.48, _s * 0.05, 0, _s * 0.55);
        crt_cx_close(_c); crt_cx_fill(_c);
    } else if (_form == "ember") {
        // a flame runs the OTHER way: broad at the base, tapering up, licking to one side, with a hot centre
        crt_cx_move(_c, 0, -_s * 0.6);
        crt_cx_quad(_c, _s * 0.14, -_s * 0.12, _s * 0.40, _s * 0.20);
        crt_cx_quad(_c, _s * 0.30, _s * 0.55, 0, _s * 0.55);
        crt_cx_quad(_c, -_s * 0.34, _s * 0.55, -_s * 0.36, _s * 0.16);
        crt_cx_quad(_c, -_s * 0.20, -_s * 0.10, 0, -_s * 0.6);
        crt_cx_close(_c); crt_cx_fill(_c);
        crt_cx_begin(_c);
        crt__fs(_c, _dim);
        crt_cx_move(_c, 0, -_s * 0.10);
        crt_cx_quad(_c, _s * 0.16, _s * 0.18, 0, _s * 0.38);
        crt_cx_quad(_c, -_s * 0.16, _s * 0.18, 0, -_s * 0.10);
        crt_cx_close(_c); crt_cx_fill(_c);
    } else if (_form == "nail") {
        crt_cx_move(_c, -_s * 0.3, -_s * 0.4); crt_cx_line(_c, _s * 0.3, -_s * 0.4); crt_cx_line(_c, 0, _s * 0.55);
        crt_cx_close(_c); crt_cx_fill(_c);
    } else if (_form == "spike") {
        // a spike is its LENGTH, thrown clear of a collar
        crt_cx_move(_c, -_s * 0.13, -_s * 0.15); crt_cx_line(_c, _s * 0.13, -_s * 0.15); crt_cx_line(_c, 0, _s * 0.62);
        crt_cx_close(_c); crt_cx_fill(_c);
        crt_cx_begin(_c);
        crt_cx_move(_c, -_s * 0.42, -_s * 0.30); crt_cx_line(_c, _s * 0.42, -_s * 0.30);
        crt_cx_line(_c, _s * 0.22, -_s * 0.05); crt_cx_line(_c, -_s * 0.22, -_s * 0.05);
        crt_cx_close(_c); crt_cx_fill(_c);
    } else if (_form == "claw" || _form == "fang" || _form == "quill") {
        crt_cx_move(_c, -_s * 0.45, -_s * 0.45);
        crt_cx_quad(_c, _s * 0.10, -_s * 0.05, _s * 0.20, _s * 0.55);
        crt_cx_quad(_c, -_s * 0.02, -_s * 0.02, -_s * 0.45, -_s * 0.20);
        crt_cx_close(_c); crt_cx_fill(_c);
    } else if (_form == "leaf") {
        crt_cx_move(_c, 0, -_s * 0.55);
        crt_cx_quad(_c, _s * 0.45, 0, 0, _s * 0.55);
        crt_cx_quad(_c, -_s * 0.45, 0, 0, -_s * 0.55);
        crt_cx_close(_c); crt_cx_fill(_c);
        crt_cx_begin(_c); crt_cx_move(_c, 0, -_s * 0.5); crt_cx_line(_c, 0, _s * 0.5);
        crt__ss(_c, _dim); crt_cx_stroke(_c);
    } else if (_form == "star") {
        for (var _i = 0; _i < 4; _i++) {
            var _a = (pi / 4) * _i;
            crt_cx_move(_c, -cos(_a) * _s * 0.55, -sin(_a) * _s * 0.55);
            crt_cx_line(_c, cos(_a) * _s * 0.55, sin(_a) * _s * 0.55);
        }
        crt_cx_stroke(_c);
    }
    crt_cx_restore(_c);
}
