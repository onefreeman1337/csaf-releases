/// crt_corpus.gml - what every id in the vocabulary LOOKS like: colours, surfaces, pitches and form selectors.
/// Data only. Draws nothing and decides nothing (crt_read.gml decides which ids a speaker resolves to).
///
/// Cartouche - The Message Box Drawn as an Object, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ GENERATED from the published RPG Maker MZ Cartouche corpus by Internal_Ops/_gen_corpus.js - edit the generator,
/// never this file. Every id crt_read can emit has an entry here and every entry is reachable; the suite asserts both.
///
/// COLOUR IS AUTHORED AS A PAIR, NEVER AS AN INK: a material declares `frame` (the body of the object) and `field`
/// (the surface the text sits on). Every other colour - rims, relief, shadow, lettering, the caret - is SOLVED from
/// them when the box is drawn. The adversary tradition has DARK fields, which is why the ink must be solved.
/// PROFILES: rail widths are multiples of the base rail; `joint` is how rails meet; `steps` the moulding count;
/// `arcade` and `crest` are structures. BANDS: `pitch` is a multiple of the band's own thickness, NEVER a count.
/// CORNERS: `reach` is a multiple of the head rail. PLATES: `attach` is how the nameplate meets the rail. GROUNDS:
/// `amp` is capped low on purpose - a ground is a whisper under the text. CARETS: `motion` is driven by an explicit
/// phase, never a clock.

/// @function crt_corpus()
/// @description Every appearance table, keyed by axis then id. Built once.
function crt_corpus() {
    if (variable_global_exists("crt__corpus_table") && is_struct(global.crt__corpus_table)) return global.crt__corpus_table;
    var _t = {};
    var _materials = {};
    _materials[$ "waxed-oak"] = { family: "wood", frame: [138, 104, 66], field: [232, 220, 198], grain: "straight", lustre: 0.25 };
    _materials[$ "limed-ash"] = { family: "wood", frame: [198, 186, 166], field: [244, 240, 230], grain: "straight", lustre: 0.18 };
    _materials[$ "tooled-leather"] = { family: "leather", frame: [120, 74, 48], field: [226, 206, 178], grain: "tooled", lustre: 0.22 };
    _materials[$ "pewter-bound"] = { family: "metal", frame: [146, 150, 156], field: [226, 228, 230], grain: "none", lustre: 0.45 };
    _materials[$ "brass-bound-walnut"] = { family: "wood", frame: [92, 62, 42], field: [232, 214, 180], grain: "figured", lustre: 0.4 };
    _materials[$ "silvered-steel"] = { family: "metal", frame: [186, 192, 200], field: [234, 238, 244], grain: "none", lustre: 0.7 };
    _materials[$ "enamelled-bronze"] = { family: "metal", frame: [148, 106, 52], field: [238, 226, 196], grain: "none", lustre: 0.55 };
    _materials[$ "gilt-and-garnet"] = { family: "metal", frame: [196, 158, 74], field: [246, 236, 208], grain: "none", lustre: 0.8 };
    _materials[$ "limewash-board"] = { family: "wood", frame: [214, 208, 192], field: [240, 236, 224], grain: "straight", lustre: 0.1 };
    _materials[$ "rush-woven"] = { family: "fibre", frame: [186, 160, 104], field: [232, 222, 196], grain: "woven", lustre: 0.12 };
    _materials[$ "pine-plank"] = { family: "wood", frame: [190, 152, 102], field: [238, 226, 198], grain: "straight", lustre: 0.15 };
    _materials[$ "waxed-hide"] = { family: "leather", frame: [126, 92, 62], field: [222, 202, 172], grain: "pebbled", lustre: 0.2 };
    _materials[$ "tinned-iron"] = { family: "metal", frame: [162, 166, 168], field: [226, 228, 228], grain: "hammered", lustre: 0.38 };
    _materials[$ "polished-slate"] = { family: "stone", frame: [78, 84, 90], field: [206, 210, 214], grain: "cleaved", lustre: 0.3 };
    _materials[$ "glazed-earthenware"] = { family: "ceramic", frame: [176, 110, 72], field: [238, 222, 198], grain: "none", lustre: 0.45 };
    _materials[$ "brass-bound-elm"] = { family: "wood", frame: [110, 80, 52], field: [234, 218, 186], grain: "figured", lustre: 0.35 };
    _materials[$ "pitch-lacquer"] = { family: "lacquer", frame: [28, 26, 30], field: [46, 42, 48], grain: "none", lustre: 0.55 };
    _materials[$ "blackened-iron"] = { family: "metal", frame: [44, 44, 48], field: [58, 56, 62], grain: "fibrous", lustre: 0.35 };
    _materials[$ "raw-slag"] = { family: "stone", frame: [58, 50, 46], field: [74, 66, 60], grain: "porous", lustre: 0.18 };
    _materials[$ "tarnished-silver"] = { family: "metal", frame: [112, 112, 120], field: [64, 62, 70], grain: "mottled", lustre: 0.5 };
    _materials[$ "obsidian"] = { family: "stone", frame: [26, 24, 32], field: [44, 40, 52], grain: "conchoidal", lustre: 0.75 };
    _materials[$ "bloodstone"] = { family: "stone", frame: [72, 28, 32], field: [58, 34, 36], grain: "mottled", lustre: 0.4 };
    _materials[$ "jet-and-gilt"] = { family: "stone", frame: [24, 22, 26], field: [48, 42, 38], grain: "none", lustre: 0.65 };
    _materials[$ "black-enamel-and-gold"] = { family: "lacquer", frame: [20, 20, 24], field: [52, 44, 34], grain: "none", lustre: 0.8 };
    _materials[$ "raw-hide"] = { family: "leather", frame: [150, 120, 88], field: [226, 210, 182], grain: "pebbled", lustre: 0.12 };
    _materials[$ "bleached-bone"] = { family: "bone", frame: [226, 220, 202], field: [242, 238, 226], grain: "porous", lustre: 0.2 };
    _materials[$ "bark-and-sinew"] = { family: "organic", frame: [104, 84, 62], field: [216, 202, 176], grain: "fibrous", lustre: 0.14 };
    _materials[$ "dark-horn"] = { family: "horn", frame: [72, 58, 44], field: [204, 190, 166], grain: "banded", lustre: 0.4 };
    _materials[$ "chitin"] = { family: "chitin", frame: [88, 66, 48], field: [198, 182, 158], grain: "plated", lustre: 0.6 };
    _materials[$ "petrified-wood"] = { family: "stone", frame: [124, 104, 86], field: [220, 208, 188], grain: "figured", lustre: 0.3 };
    _materials[$ "ivory-and-sinew"] = { family: "bone", frame: [230, 222, 198], field: [244, 238, 222], grain: "fibrous", lustre: 0.35 };
    _materials[$ "amber-and-ivory"] = { family: "amber", frame: [206, 146, 58], field: [246, 234, 204], grain: "none", lustre: 0.55 };
    _materials[$ "river-stone"] = { family: "stone", frame: [140, 146, 148], field: [224, 228, 228], grain: "waterworn", lustre: 0.22 };
    _materials[$ "hoarfrost"] = { family: "ice", frame: [206, 222, 232], field: [238, 246, 250], grain: "crystal", lustre: 0.5 };
    _materials[$ "living-wood"] = { family: "wood", frame: [96, 122, 78], field: [226, 232, 212], grain: "fibrous", lustre: 0.2 };
    _materials[$ "moon-glass"] = { family: "glass", frame: [176, 190, 214], field: [232, 238, 248], grain: "none", lustre: 0.6 };
    _materials[$ "sea-glass"] = { family: "glass", frame: [126, 170, 166], field: [222, 238, 234], grain: "frosted", lustre: 0.55 };
    _materials[$ "stained-glass"] = { family: "glass", frame: [72, 88, 158], field: [214, 224, 244], grain: "none", lustre: 0.7 };
    _materials[$ "star-iron"] = { family: "metal", frame: [96, 102, 124], field: [218, 222, 236], grain: "widmanstatten", lustre: 0.65 };
    _materials[$ "nacre-and-gold"] = { family: "nacre", frame: [226, 214, 224], field: [246, 240, 246], grain: "iridescent", lustre: 0.85 };
    _t.materials = _materials;
    var _profiles = {};
    _profiles[$ "panel"] = { railTop: 0.9, railSide: 0.9, railFoot: 0.9, joint: "mitre", steps: 1, arcade: false, crest: 0 };
    _profiles[$ "bound"] = { railTop: 1.1, railSide: 0.85, railFoot: 0.95, joint: "strap", steps: 1, arcade: false, crest: 0 };
    _profiles[$ "battened"] = { railTop: 1, railSide: 0.95, railFoot: 1.05, joint: "butt", steps: 2, arcade: false, crest: 0 };
    _profiles[$ "moulded"] = { railTop: 1.25, railSide: 1, railFoot: 1.1, joint: "mitre", steps: 3, arcade: false, crest: 0 };
    _profiles[$ "arcaded"] = { railTop: 1.5, railSide: 1, railFoot: 1.1, joint: "mitre", steps: 3, arcade: true, crest: 0 };
    _profiles[$ "canopied"] = { railTop: 1.9, railSide: 1.05, railFoot: 1.15, joint: "mitre", steps: 4, arcade: true, crest: 1 };
    _profiles[$ "plank"] = { railTop: 0.85, railSide: 0.8, railFoot: 0.85, joint: "butt", steps: 1, arcade: false, crest: 0 };
    _profiles[$ "pegged"] = { railTop: 0.95, railSide: 0.9, railFoot: 0.95, joint: "peg", steps: 1, arcade: false, crest: 0 };
    _profiles[$ "framed"] = { railTop: 1.15, railSide: 1, railFoot: 1.05, joint: "mitre", steps: 2, arcade: false, crest: 0 };
    _profiles[$ "gabled"] = { railTop: 1.7, railSide: 0.95, railFoot: 1, joint: "butt", steps: 2, arcade: false, crest: 1 };
    _profiles[$ "strapped"] = { railTop: 0.95, railSide: 0.9, railFoot: 0.95, joint: "strap", steps: 1, arcade: false, crest: 0 };
    _profiles[$ "riveted"] = { railTop: 1.05, railSide: 0.95, railFoot: 1, joint: "strap", steps: 2, arcade: false, crest: 0 };
    _profiles[$ "barred"] = { railTop: 1.15, railSide: 1.05, railFoot: 1.05, joint: "butt", steps: 2, arcade: true, crest: 0 };
    _profiles[$ "fluted"] = { railTop: 1.2, railSide: 1.1, railFoot: 1.1, joint: "mitre", steps: 3, arcade: false, crest: 0 };
    _profiles[$ "spined"] = { railTop: 1.35, railSide: 1.05, railFoot: 1.05, joint: "cast", steps: 3, arcade: false, crest: 1 };
    _profiles[$ "throned"] = { railTop: 2, railSide: 1.15, railFoot: 1.2, joint: "cast", steps: 4, arcade: false, crest: 2 };
    _profiles[$ "spliced"] = { railTop: 0.9, railSide: 0.9, railFoot: 0.9, joint: "lash", steps: 1, arcade: false, crest: 0 };
    _profiles[$ "lashed"] = { railTop: 1, railSide: 0.95, railFoot: 0.95, joint: "lash", steps: 1, arcade: false, crest: 0 };
    _profiles[$ "ribbed"] = { railTop: 1.1, railSide: 1, railFoot: 1, joint: "butt", steps: 2, arcade: true, crest: 0 };
    _profiles[$ "plated"] = { railTop: 1.2, railSide: 1.05, railFoot: 1.05, joint: "lap", steps: 2, arcade: false, crest: 0 };
    _profiles[$ "antlered"] = { railTop: 1.55, railSide: 1, railFoot: 1, joint: "lash", steps: 2, arcade: false, crest: 1 };
    _profiles[$ "crowned-antler"] = { railTop: 2.05, railSide: 1.05, railFoot: 1.1, joint: "lash", steps: 3, arcade: false, crest: 2 };
    _profiles[$ "waterworn"] = { railTop: 0.95, railSide: 0.95, railFoot: 0.95, joint: "none", steps: 1, arcade: false, crest: 0 };
    _profiles[$ "grown"] = { railTop: 1.1, railSide: 1, railFoot: 0.95, joint: "none", steps: 2, arcade: false, crest: 0 };
    _profiles[$ "woven-light"] = { railTop: 1.15, railSide: 1.05, railFoot: 1, joint: "lead", steps: 2, arcade: false, crest: 0 };
    _profiles[$ "tracery"] = { railTop: 1.4, railSide: 1.05, railFoot: 1.05, joint: "lead", steps: 3, arcade: true, crest: 0 };
    _profiles[$ "radiant"] = { railTop: 1.6, railSide: 1.1, railFoot: 1.1, joint: "lead", steps: 3, arcade: true, crest: 1 };
    _profiles[$ "aureoled"] = { railTop: 2.1, railSide: 1.15, railFoot: 1.15, joint: "lead", steps: 4, arcade: false, crest: 2 };
    _t.profiles = _profiles;
    var _bands = {};
    _bands[$ "bead"] = { motif: "bead", pitch: 1.15, depth: 0.55, cut: "raised" };
    _bands[$ "cable"] = { motif: "cable", pitch: 1.6, depth: 0.65, cut: "raised" };
    _bands[$ "chevron"] = { motif: "chevron", pitch: 1.8, depth: 0.4, cut: "incised" };
    _bands[$ "punched"] = { motif: "dot", pitch: 2.1, depth: 0.3, cut: "incised" };
    _bands[$ "reed"] = { motif: "reed", pitch: 1, depth: 0.45, cut: "raised" };
    _bands[$ "guilloche"] = { motif: "guilloche", pitch: 2.6, depth: 0.5, cut: "incised" };
    _bands[$ "peg"] = { motif: "dot", pitch: 3.2, depth: 0.6, cut: "raised" };
    _bands[$ "nailhead"] = { motif: "nail", pitch: 2.8, depth: 0.7, cut: "raised" };
    _bands[$ "rope"] = { motif: "cable", pitch: 1.4, depth: 0.5, cut: "raised" };
    _bands[$ "notch"] = { motif: "notch", pitch: 1.7, depth: 0.55, cut: "incised" };
    _bands[$ "scallop"] = { motif: "scallop", pitch: 1.9, depth: 0.45, cut: "incised" };
    _bands[$ "chip-carved"] = { motif: "triangle", pitch: 1.55, depth: 0.6, cut: "incised" };
    _bands[$ "rivet"] = { motif: "nail", pitch: 2.4, depth: 0.75, cut: "raised" };
    _bands[$ "barb"] = { motif: "barb", pitch: 2, depth: 0.8, cut: "raised" };
    _bands[$ "fret"] = { motif: "fret", pitch: 2.3, depth: 0.4, cut: "incised" };
    _bands[$ "chain"] = { motif: "chain", pitch: 1.75, depth: 0.6, cut: "raised" };
    _bands[$ "saw"] = { motif: "triangle", pitch: 1.2, depth: 0.7, cut: "raised" };
    _bands[$ "serpentine"] = { motif: "wave", pitch: 2.5, depth: 0.45, cut: "incised" };
    _bands[$ "lashing"] = { motif: "wrap", pitch: 1.3, depth: 0.55, cut: "raised" };
    _bands[$ "tooth"] = { motif: "triangle", pitch: 1.85, depth: 0.75, cut: "raised" };
    _bands[$ "scale"] = { motif: "scallop", pitch: 1.25, depth: 0.5, cut: "raised" };
    _bands[$ "bristle"] = { motif: "reed", pitch: 0.9, depth: 0.35, cut: "raised" };
    _bands[$ "scored"] = { motif: "notch", pitch: 1.1, depth: 0.4, cut: "incised" };
    _bands[$ "feathered"] = { motif: "feather", pitch: 1.45, depth: 0.45, cut: "raised" };
    _bands[$ "came"] = { motif: "reed", pitch: 2.7, depth: 0.35, cut: "raised" };
    _bands[$ "frond"] = { motif: "feather", pitch: 2.2, depth: 0.4, cut: "incised" };
    _bands[$ "dewline"] = { motif: "bead", pitch: 2.9, depth: 0.3, cut: "raised" };
    _bands[$ "rune"] = { motif: "rune", pitch: 3, depth: 0.45, cut: "incised" };
    _bands[$ "ray"] = { motif: "ray", pitch: 2.15, depth: 0.35, cut: "incised" };
    _bands[$ "spiral"] = { motif: "guilloche", pitch: 2.45, depth: 0.4, cut: "incised" };
    _t.bands = _bands;
    var _corners = {};
    _corners[$ "square"] = { form: "square", reach: 0, pieces: 0 };
    _corners[$ "cut"] = { form: "chamfer", reach: 0.55, pieces: 0 };
    _corners[$ "shouldered"] = { form: "shoulder", reach: 0.85, pieces: 1 };
    _corners[$ "lapped"] = { form: "lap", reach: 0.7, pieces: 1 };
    _corners[$ "scrolled"] = { form: "volute", reach: 1.25, pieces: 1 };
    _corners[$ "crested"] = { form: "crest", reach: 1.8, pieces: 2 };
    _corners[$ "pegged-scroll"] = { form: "volute", reach: 1.05, pieces: 1 };
    _corners[$ "bracketed"] = { form: "bracket", reach: 1.4, pieces: 2 };
    _corners[$ "finialled"] = { form: "finial", reach: 1.75, pieces: 2 };
    _corners[$ "clipped"] = { form: "chamfer", reach: 0.75, pieces: 0 };
    _corners[$ "spurred"] = { form: "spur", reach: 1.1, pieces: 1 };
    _corners[$ "hooked"] = { form: "hook", reach: 1.35, pieces: 1 };
    _corners[$ "taloned"] = { form: "talon", reach: 1.65, pieces: 2 };
    _corners[$ "crowned"] = { form: "crest", reach: 2.1, pieces: 3 };
    _corners[$ "broken"] = { form: "break", reach: 0.45, pieces: 0 };
    _corners[$ "snagged"] = { form: "snag", reach: 0.8, pieces: 1 };
    _corners[$ "curled"] = { form: "volute", reach: 1.15, pieces: 1 };
    _corners[$ "tusked"] = { form: "tusk", reach: 1.5, pieces: 1 };
    _corners[$ "horned"] = { form: "horn", reach: 1.85, pieces: 2 };
    _corners[$ "crested-horn"] = { form: "horn", reach: 2.2, pieces: 3 };
    _corners[$ "rounded"] = { form: "round", reach: 0.5, pieces: 0 };
    _corners[$ "budded"] = { form: "bud", reach: 0.9, pieces: 1 };
    _corners[$ "leafed"] = { form: "leaf", reach: 1.2, pieces: 1 };
    _corners[$ "flowering"] = { form: "flower", reach: 1.55, pieces: 2 };
    _corners[$ "rayed"] = { form: "ray", reach: 1.8, pieces: 2 };
    _corners[$ "haloed"] = { form: "halo", reach: 2.15, pieces: 3 };
    _t.corners = _corners;
    var _plates = {};
    _plates[$ "ruled"] = { form: "rule", attach: "flush", lettering: "painted", drop: 0 };
    _plates[$ "strap-tag"] = { form: "tag", attach: "hung", lettering: "painted", drop: 0.55 };
    _plates[$ "stamped-band"] = { form: "band", attach: "flush", lettering: "struck", drop: 0 };
    _plates[$ "let-in-tablet"] = { form: "tablet", attach: "let-in", lettering: "incised", drop: 0.1 };
    _plates[$ "enamel-lozenge"] = { form: "lozenge", attach: "let-in", lettering: "painted", drop: 0.15 };
    _plates[$ "chased-cartouche"] = { form: "cartouche", attach: "riveted", lettering: "struck", drop: 0.25 };
    _plates[$ "crested-tablet"] = { form: "tablet", attach: "riveted", lettering: "gilt", drop: 0.35 };
    _plates[$ "chalked"] = { form: "rule", attach: "flush", lettering: "chalk", drop: 0 };
    _plates[$ "nailed-tag"] = { form: "tag", attach: "riveted", lettering: "painted", drop: 0.2 };
    _plates[$ "burnt-brand"] = { form: "band", attach: "flush", lettering: "incised", drop: 0 };
    _plates[$ "painted-panel"] = { form: "tablet", attach: "flush", lettering: "painted", drop: 0.05 };
    _plates[$ "sign-board"] = { form: "board", attach: "hung", lettering: "painted", drop: 0.7 };
    _plates[$ "carved-tablet"] = { form: "tablet", attach: "let-in", lettering: "incised", drop: 0.15 };
    _plates[$ "gilded-board"] = { form: "board", attach: "hung", lettering: "gilt", drop: 0.6 };
    _plates[$ "scored"] = { form: "rule", attach: "flush", lettering: "incised", drop: 0 };
    _plates[$ "riveted-tag"] = { form: "tag", attach: "riveted", lettering: "struck", drop: 0.25 };
    _plates[$ "branded-strip"] = { form: "band", attach: "flush", lettering: "incised", drop: 0 };
    _plates[$ "inlaid-strip"] = { form: "band", attach: "let-in", lettering: "gilt", drop: 0.1 };
    _plates[$ "gilt-cartouche"] = { form: "cartouche", attach: "let-in", lettering: "gilt", drop: 0.2 };
    _plates[$ "crowned-boss"] = { form: "boss", attach: "riveted", lettering: "struck", drop: 0.4 };
    _plates[$ "jewelled-boss"] = { form: "boss", attach: "riveted", lettering: "gilt", drop: 0.5 };
    _plates[$ "scratched"] = { form: "rule", attach: "flush", lettering: "incised", drop: 0 };
    _plates[$ "sinew-tag"] = { form: "tag", attach: "hung", lettering: "incised", drop: 0.6 };
    _plates[$ "burnt-mark"] = { form: "band", attach: "flush", lettering: "incised", drop: 0 };
    _plates[$ "set-tooth"] = { form: "boss", attach: "riveted", lettering: "struck", drop: 0.3 };
    _plates[$ "inlaid-shell"] = { form: "lozenge", attach: "let-in", lettering: "struck", drop: 0.15 };
    _plates[$ "crowned-horn"] = { form: "cartouche", attach: "riveted", lettering: "struck", drop: 0.45 };
    _plates[$ "gilded-tusk"] = { form: "cartouche", attach: "riveted", lettering: "gilt", drop: 0.55 };
    _plates[$ "etched"] = { form: "rule", attach: "flush", lettering: "incised", drop: 0 };
    _plates[$ "leaf-tag"] = { form: "tag", attach: "hung", lettering: "incised", drop: 0.5 };
    _plates[$ "frosted-panel"] = { form: "tablet", attach: "flush", lettering: "incised", drop: 0.05 };
    _plates[$ "glass-lozenge"] = { form: "lozenge", attach: "let-in", lettering: "painted", drop: 0.15 };
    _plates[$ "lit-panel"] = { form: "tablet", attach: "let-in", lettering: "painted", drop: 0.2 };
    _plates[$ "haloed-tablet"] = { form: "tablet", attach: "riveted", lettering: "gilt", drop: 0.35 };
    _plates[$ "star-set-tablet"] = { form: "cartouche", attach: "riveted", lettering: "gilt", drop: 0.45 };
    _t.plates = _plates;
    var _grounds = {};
    _grounds[$ "smooth-gesso"] = { texture: "flat", amp: 0.01 };
    _grounds[$ "combed"] = { texture: "comb", amp: 0.03 };
    _grounds[$ "stippled"] = { texture: "stipple", amp: 0.025 };
    _grounds[$ "figured-grain"] = { texture: "grain", amp: 0.035 };
    _grounds[$ "brushed-lime"] = { texture: "brush", amp: 0.03 };
    _grounds[$ "sawn"] = { texture: "saw", amp: 0.04 };
    _grounds[$ "worn-scrub"] = { texture: "scrub", amp: 0.045 };
    _grounds[$ "slip-poured"] = { texture: "pour", amp: 0.025 };
    _grounds[$ "hammered"] = { texture: "hammer", amp: 0.045 };
    _grounds[$ "pitted"] = { texture: "pit", amp: 0.04 };
    _grounds[$ "soot-blacked"] = { texture: "smoke", amp: 0.03 };
    _grounds[$ "polished-void"] = { texture: "flat", amp: 0.008 };
    _grounds[$ "porous"] = { texture: "pore", amp: 0.045 };
    _grounds[$ "grained-horn"] = { texture: "grain", amp: 0.04 };
    _grounds[$ "pebbled-hide"] = { texture: "pebble", amp: 0.05 };
    _grounds[$ "waxed-shell"] = { texture: "pour", amp: 0.02 };
    _grounds[$ "veiled"] = { texture: "veil", amp: 0.022 };
    _grounds[$ "rippled"] = { texture: "ripple", amp: 0.032 };
    _grounds[$ "mossed"] = { texture: "scrub", amp: 0.038 };
    _grounds[$ "starred"] = { texture: "star", amp: 0.028 };
    _t.grounds = _grounds;
    var _carets = {};
    _carets[$ "chevron"] = { form: "chevron", motion: "bob" };
    _carets[$ "lozenge"] = { form: "lozenge", motion: "pulse" };
    _carets[$ "pennon"] = { form: "pennon", motion: "bob" };
    _carets[$ "wedge"] = { form: "wedge", motion: "bob" };
    _carets[$ "drop"] = { form: "drop", motion: "drift" };
    _carets[$ "nail"] = { form: "nail", motion: "pulse" };
    _carets[$ "barb"] = { form: "barb", motion: "bob" };
    _carets[$ "spike"] = { form: "spike", motion: "pulse" };
    _carets[$ "ember"] = { form: "ember", motion: "drift" };
    _carets[$ "claw"] = { form: "claw", motion: "bob" };
    _carets[$ "fang"] = { form: "fang", motion: "pulse" };
    _carets[$ "quill"] = { form: "quill", motion: "drift" };
    _carets[$ "mote"] = { form: "mote", motion: "drift" };
    _carets[$ "leaf"] = { form: "leaf", motion: "drift" };
    _carets[$ "star"] = { form: "star", motion: "pulse" };
    _t.carets = _carets;
    global.crt__corpus_table = _t;
    return _t;
}

/// @function crt_look(axis, id)
/// @description The appearance of one id on one axis ("materials", "profiles", "bands", "corners", "plates", "grounds",
/// "carets"), or undefined for an unknown axis or id - never a silent default.
function crt_look(_axis, _id) {
    var _t = crt_corpus();
    if (!is_string(_axis) || !variable_struct_exists(_t, _axis)) return undefined;
    var _a = _t[$ _axis];
    if (!is_string(_id) || !variable_struct_exists(_a, _id)) return undefined;
    return _a[$ _id];
}

/// @function crt_corpus_count(axis)
/// @description How many ids an axis holds (0 for an unknown axis).
function crt_corpus_count(_axis) {
    var _t = crt_corpus();
    if (!is_string(_axis) || !variable_struct_exists(_t, _axis)) return 0;
    return array_length(variable_struct_get_names(_t[$ _axis]));
}
