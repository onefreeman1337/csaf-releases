/// crt_canvas.gml - a small 2D path renderer on GameMaker primitives: paths under an affine transform, a NONZERO
/// scanline fill whose span ends carry their fractional coverage as alpha, linear and radial gradients, strokes built
/// as the UNION of their segments (so a translucent line never darkens where its pieces overlap), convex clip regions,
/// and text. Every Cartouche box is drawn through it.
///
/// Cartouche - The Message Box Drawn as an Object, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ FOUR FACTS ABOUT GAMEMAKER DECIDE THE SHAPE OF THIS FILE:
///   1. Its primitives have NO antialiasing. Every fill here is a scanline fill whose span ends carry their coverage,
///      and a box is drawn SUPERSAMPLED (the context's base transform scales by 2) then filtered down.
///   2. draw_vertex_colour carries its own alpha and IGNORES draw_set_alpha, so alpha is always passed explicitly.
///   3. One draw_primitive_begin batch SILENTLY DROPS vertices past a limit (~1000): every batch flushes at 900.
///   4. A triangle fan spans a concavity silently, so no path is ever fanned; the scanline fill takes any shape.
/// A context holds DEVICE coordinates: every point is transformed as it is added, as a canvas does.

#macro CRT_FILL_NONZERO 1
#macro CRT_FILL_EVENODD 0

/// @function crt_cx_create(scale)
/// @description A drawing context whose base transform scales by `scale` (the supersample factor). Draws onto
/// whatever surface is the current target. Returns a struct; nothing to free.
function crt_cx_create(_ss = 1) {
    _ss = is_numeric(_ss) ? max(0.01, _ss) : 1;
    return {
        m: [_ss, 0, 0, _ss, 0, 0], alpha: 1, lw: 1, cap: 0,
        fill: crt_cx_solid([0, 0, 0]), stroke: crt_cx_solid([0, 0, 0]),
        stack: [], subs: [], cur: undefined, clips: [],
        counts: { path: 0, fill: 0, stroke: 0, rect: 0 }, ss: _ss, verts: 0
    };
}

/// @function crt_cx_solid(rgb, [a])
/// @description A flat paint from an [r, g, b] colour. Pure.
function crt_cx_solid(_rgb, _a = 1) { return { kind: 0, col: crt_col(_rgb), a: _a }; }

/// @function crt_cx_linear(ctx, x0, y0, x1, y1)
/// @description A linear gradient between two USER-space points under the current transform. Add stops with
/// crt_cx_stop. Pure but for reading ctx.
function crt_cx_linear(_ctx, _x0, _y0, _x1, _y1) {
    var _p = crt_cx__pt(_ctx, _x0, _y0), _q = crt_cx__pt(_ctx, _x1, _y1);
    return { kind: 1, x0: _p[0], y0: _p[1], x1: _q[0], y1: _q[1], stops: [] };
}

/// @function crt_cx_radial(ctx, x0, y0, r0, x1, y1, r1)
/// @description A two-circle radial gradient (the canvas definition) in USER space under the current transform.
function crt_cx_radial(_ctx, _x0, _y0, _r0, _x1, _y1, _r1) {
    var _p = crt_cx__pt(_ctx, _x0, _y0), _q = crt_cx__pt(_ctx, _x1, _y1), _s = crt_cx__scale(_ctx);
    return { kind: 2, x0: _p[0], y0: _p[1], r0: _r0 * _s, x1: _q[0], y1: _q[1], r1: _r1 * _s, stops: [] };
}

/// @function crt_cx_stop(grad, t, rgb, [a])
/// @description Add a colour stop to a gradient. Stops must be added in increasing t (every caller here does).
function crt_cx_stop(_g, _t, _rgb, _a = 1) { array_push(_g.stops, [clamp(_t, 0, 1), crt_col(_rgb), _a]); }

// ---------------------------------------------------------------------------------------------------------------
// State and transform
// ---------------------------------------------------------------------------------------------------------------

/// @function crt_cx_save(ctx)
function crt_cx_save(_c) {
    array_push(_c.stack, { m: [_c.m[0], _c.m[1], _c.m[2], _c.m[3], _c.m[4], _c.m[5]], alpha: _c.alpha, lw: _c.lw, cap: _c.cap,
        fill: _c.fill, stroke: _c.stroke, clips: array_length(_c.clips) });
}

/// @function crt_cx_restore(ctx)
function crt_cx_restore(_c) {
    var _n = array_length(_c.stack);
    if (_n == 0) return;
    var _s = _c.stack[_n - 1];
    array_delete(_c.stack, _n - 1, 1);
    _c.m = _s.m; _c.alpha = _s.alpha; _c.lw = _s.lw; _c.cap = _s.cap; _c.fill = _s.fill; _c.stroke = _s.stroke;
    if (array_length(_c.clips) > _s.clips) array_resize(_c.clips, _s.clips);
}

// ⛔ A transform is REPLACED, never written through an alias: a buyer's project may still run GameMaker's legacy
// array copy-on-write option, under which `var m = ctx.m; m[4] += x;` edits a private copy and the context never moves.

/// @function crt_cx_translate(ctx, x, y)
function crt_cx_translate(_c, _x, _y) {
    var _m = _c.m;
    _c.m = [_m[0], _m[1], _m[2], _m[3], _m[4] + _m[0] * _x + _m[2] * _y, _m[5] + _m[1] * _x + _m[3] * _y];
}

/// @function crt_cx_rotate(ctx, radians)
function crt_cx_rotate(_c, _r) {
    var _m = _c.m, _co = cos(_r), _si = sin(_r);
    _c.m = [_m[0] * _co + _m[2] * _si, _m[1] * _co + _m[3] * _si, -_m[0] * _si + _m[2] * _co, -_m[1] * _si + _m[3] * _co, _m[4], _m[5]];
}

/// @function crt_cx_scale(ctx, sx, sy)
function crt_cx_scale(_c, _sx, _sy) {
    var _m = _c.m;
    _c.m = [_m[0] * _sx, _m[1] * _sx, _m[2] * _sy, _m[3] * _sy, _m[4], _m[5]];
}

/// @function crt_cx__pt(ctx, x, y)
/// @description A user-space point in device space. Internal.
function crt_cx__pt(_c, _x, _y) {
    var _m = _c.m;
    return [_m[0] * _x + _m[2] * _y + _m[4], _m[1] * _x + _m[3] * _y + _m[5]];
}

/// @function crt_cx__scale(ctx)
/// @description The linear scale of the current transform (what a line width is multiplied by). Internal.
function crt_cx__scale(_c) { var _m = _c.m; return sqrt(abs(_m[0] * _m[3] - _m[1] * _m[2])); }

// ---------------------------------------------------------------------------------------------------------------
// Paths
// ---------------------------------------------------------------------------------------------------------------

/// @function crt_cx_begin(ctx)
/// @description Start a new path (counted: the draw report compares op counts with the original).
function crt_cx_begin(_c) { _c.subs = []; _c.cur = undefined; _c.counts.path++; }

/// @function crt_cx_move(ctx, x, y)
function crt_cx_move(_c, _x, _y) {
    _c.cur = { pts: [crt_cx__pt(_c, _x, _y)], closed: false };
    array_push(_c.subs, _c.cur);
}

/// @function crt_cx_line(ctx, x, y)
function crt_cx_line(_c, _x, _y) {
    if (is_undefined(_c.cur)) { crt_cx_move(_c, _x, _y); return; }
    array_push(_c.cur.pts, crt_cx__pt(_c, _x, _y));
}

/// @function crt_cx__last(ctx)
/// @description The current device point. Internal.
function crt_cx__last(_c) { var _p = _c.cur.pts; return _p[array_length(_p) - 1]; }

/// @function crt_cx_quad(ctx, cx, cy, x, y)
/// @description A quadratic curve, flattened in device space at about 3 px a segment.
function crt_cx_quad(_c, _cx, _cy, _x, _y) {
    if (is_undefined(_c.cur)) crt_cx_move(_c, _cx, _cy);
    var _p0 = crt_cx__last(_c), _p1 = crt_cx__pt(_c, _cx, _cy), _p2 = crt_cx__pt(_c, _x, _y);
    var _len = point_distance(_p0[0], _p0[1], _p1[0], _p1[1]) + point_distance(_p1[0], _p1[1], _p2[0], _p2[1]);
    var _n = clamp(ceil(_len / 3), 2, 64);
    for (var _i = 1; _i <= _n; _i++) {
        var _t = _i / _n, _u = 1 - _t;
        array_push(_c.cur.pts, [_u * _u * _p0[0] + 2 * _u * _t * _p1[0] + _t * _t * _p2[0], _u * _u * _p0[1] + 2 * _u * _t * _p1[1] + _t * _t * _p2[1]]);
    }
}

/// @function crt_cx_bezier(ctx, c1x, c1y, c2x, c2y, x, y)
/// @description A cubic curve, flattened in device space at about 3 px a segment.
function crt_cx_bezier(_c, _ax, _ay, _bx, _by, _x, _y) {
    if (is_undefined(_c.cur)) crt_cx_move(_c, _ax, _ay);
    var _p0 = crt_cx__last(_c), _p1 = crt_cx__pt(_c, _ax, _ay), _p2 = crt_cx__pt(_c, _bx, _by), _p3 = crt_cx__pt(_c, _x, _y);
    var _len = point_distance(_p0[0], _p0[1], _p1[0], _p1[1]) + point_distance(_p1[0], _p1[1], _p2[0], _p2[1]) + point_distance(_p2[0], _p2[1], _p3[0], _p3[1]);
    var _n = clamp(ceil(_len / 3), 2, 96);
    for (var _i = 1; _i <= _n; _i++) {
        var _t = _i / _n, _u = 1 - _t;
        var _a = _u * _u * _u, _b = 3 * _u * _u * _t, _cc = 3 * _u * _t * _t, _d = _t * _t * _t;
        array_push(_c.cur.pts, [_a * _p0[0] + _b * _p1[0] + _cc * _p2[0] + _d * _p3[0], _a * _p0[1] + _b * _p1[1] + _cc * _p2[1] + _d * _p3[1]]);
    }
}

/// @function crt_cx__sweep(a0, a1, ccw)
/// @description The swept angle of a canvas arc from a0 to a1 (the canvas rule: a full turn or more draws a full
/// circle; otherwise the end is brought within one turn of the start in the arc's direction). Internal.
function crt_cx__sweep(_a0, _a1, _ccw) {
    var _tau = 2 * pi;
    if (!_ccw) {
        if (_a1 - _a0 >= _tau) return _tau;
        var _s = (_a1 - _a0) - floor((_a1 - _a0) / _tau) * _tau;
        return _s;
    }
    if (_a0 - _a1 >= _tau) return -_tau;
    var _r = (_a0 - _a1) - floor((_a0 - _a1) / _tau) * _tau;
    return -_r;
}

/// @function crt_cx_ellipse(ctx, cx, cy, rx, ry, rot, a0, a1, [ccw])
/// @description An elliptical arc (a circle when rx == ry). Joins the current point to its start with a line, as a
/// canvas does. A negative radius is drawn as zero rather than thrown.
function crt_cx_ellipse(_c, _cx, _cy, _rx, _ry, _rot, _a0, _a1, _ccw = false) {
    _rx = max(0, _rx); _ry = max(0, _ry);
    var _sw = crt_cx__sweep(_a0, _a1, _ccw);
    var _cr = cos(_rot), _sr = sin(_rot), _s = crt_cx__scale(_c);
    var _n = clamp(ceil(max(_rx, _ry) * _s * abs(_sw) / 3), 2, 128);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _a0 + _sw * _i / _n;
        var _ex = cos(_t) * _rx, _ey = sin(_t) * _ry;
        var _ux = _cx + _ex * _cr - _ey * _sr, _uy = _cy + _ex * _sr + _ey * _cr;
        if (_i == 0 && is_undefined(_c.cur)) crt_cx_move(_c, _ux, _uy); else crt_cx_line(_c, _ux, _uy);
    }
}

/// @function crt_cx_arc(ctx, cx, cy, r, a0, a1, [ccw])
function crt_cx_arc(_c, _cx, _cy, _r, _a0, _a1, _ccw = false) { crt_cx_ellipse(_c, _cx, _cy, _r, _r, 0, _a0, _a1, _ccw); }

/// @function crt_cx_rect(ctx, x, y, w, h)
/// @description A closed rectangle subpath.
function crt_cx_rect(_c, _x, _y, _w, _h) {
    crt_cx_move(_c, _x, _y); crt_cx_line(_c, _x + _w, _y); crt_cx_line(_c, _x + _w, _y + _h); crt_cx_line(_c, _x, _y + _h);
    crt_cx_close(_c);
}

/// @function crt_cx_close(ctx)
function crt_cx_close(_c) {
    if (is_undefined(_c.cur)) return;
    _c.cur.closed = true;
    var _p0 = _c.cur.pts[0];
    _c.cur = { pts: [[_p0[0], _p0[1]]], closed: false };
    array_push(_c.subs, _c.cur);
}

/// @function crt_cx_round_rect(ctx, x, y, w, h, r)
/// @description A rounded-rectangle subpath; a negative or oversize radius is clamped rather than thrown.
function crt_cx_round_rect(_c, _x, _y, _w, _h, _r) {
    var _rr = max(0, min(_r, _w / 2, _h / 2));
    crt_cx_move(_c, _x + _rr, _y);
    crt_cx_line(_c, _x + _w - _rr, _y);
    crt_cx_arc(_c, _x + _w - _rr, _y + _rr, _rr, -pi / 2, 0);
    crt_cx_line(_c, _x + _w, _y + _h - _rr);
    crt_cx_arc(_c, _x + _w - _rr, _y + _h - _rr, _rr, 0, pi / 2);
    crt_cx_line(_c, _x + _rr, _y + _h);
    crt_cx_arc(_c, _x + _rr, _y + _h - _rr, _rr, pi / 2, pi);
    crt_cx_line(_c, _x, _y + _rr);
    crt_cx_arc(_c, _x + _rr, _y + _rr, _rr, pi, pi * 1.5);
    crt_cx_close(_c);
}

/// @function crt_cx__rings(ctx)
/// @description The current path's subpaths with at least three points, as device rings. Internal.
function crt_cx__rings(_c) {
    var _o = [];
    for (var _i = 0; _i < array_length(_c.subs); _i++) if (array_length(_c.subs[_i].pts) >= 3) array_push(_o, _c.subs[_i].pts);
    return _o;
}

// ---------------------------------------------------------------------------------------------------------------
// Painting
// ---------------------------------------------------------------------------------------------------------------

// ⛔ SPEED IS A PRODUCT PROPERTY HERE: a box is baked when a speaker first talks, inside the buyer's frame. MEASURED on
// the first build (2026-09-28): every mark through the scanline union cost 336 ms a box at 1x and 0.7-2.7 s a bake at
// 2x - a long wavy stroke is hundreds of quads, all active on every row. So the common shapes take direct paths:
// a CONVEX fill is a fan, a RADIAL fill a mesh, an axis-aligned rectangle one quad (or one band per stop of an axis
// gradient), a SOLID stroke one miter-joined triangle strip - clipped by the GPU scissor when every clip is a
// rectangle. The exact scanline union remains for everything else (concave shapes, a shaped clip, a diagonal
// gradient). The draw report counts the same ops either way.

/// @function crt_cx_fill(ctx)
/// @description Fill the current path with the fill paint (nonzero winding) at the context's alpha.
function crt_cx_fill(_c) {
    _c.counts.fill++;
    var _r = crt_cx__rings(_c);
    if (array_length(_r) == 1 && _c.fill.kind != 1 && crt_cx__rect_clips(_c) && crt_cx__convex(_r[0])) { crt_cx__fan(_c, _r[0], _c.fill, _c.alpha); return; }
    crt_cx__fill(_c, _r, _c.fill, _c.alpha, CRT_FILL_NONZERO);
}

/// @function crt_cx_fill_rect(ctx, x, y, w, h)
/// @description Fill a rectangle without touching the current path.
function crt_cx_fill_rect(_c, _x, _y, _w, _h) {
    _c.counts.rect++;
    if (!(_w > 0) || !(_h > 0)) return;
    var _m = _c.m;
    if (_m[1] == 0 && _m[2] == 0 && crt_cx__rect_clips(_c) && (_c.fill.kind == 0 || _c.fill.kind == 1)) {
        var _p = crt_cx__pt(_c, _x, _y), _q = crt_cx__pt(_c, _x + _w, _y + _h);
        if (crt_cx__rect_fast(_c, min(_p[0], _q[0]), min(_p[1], _q[1]), max(_p[0], _q[0]), max(_p[1], _q[1]), _c.fill, _c.alpha)) return;
    }
    crt_cx__fill(_c, [[crt_cx__pt(_c, _x, _y), crt_cx__pt(_c, _x + _w, _y), crt_cx__pt(_c, _x + _w, _y + _h), crt_cx__pt(_c, _x, _y + _h)]], _c.fill, _c.alpha, CRT_FILL_NONZERO);
}

/// @function crt_cx_stroke(ctx)
/// @description Stroke the current path with the stroke paint, at the line width under the current transform.
function crt_cx_stroke(_c) {
    _c.counts.stroke++;
    if (_c.stroke.kind == 0 && crt_cx__rect_clips(_c)) { crt_cx__strip_subs(_c, _c.subs); return; }
    crt_cx__stroke_subs(_c, _c.subs);
}

/// @function crt_cx_stroke_rect(ctx, x, y, w, h)
/// @description Stroke a rectangle without touching the current path (not counted, as a canvas recorder does not).
function crt_cx_stroke_rect(_c, _x, _y, _w, _h) {
    var _s = { pts: [crt_cx__pt(_c, _x, _y), crt_cx__pt(_c, _x + _w, _y), crt_cx__pt(_c, _x + _w, _y + _h), crt_cx__pt(_c, _x, _y + _h)], closed: true };
    if (_c.stroke.kind == 0 && crt_cx__rect_clips(_c)) { crt_cx__strip_subs(_c, [_s]); return; }
    crt_cx__stroke_subs(_c, [_s]);
}

/// @function crt_cx__rect_clips(ctx)
/// @description True when every clip region is an axis-aligned rectangle (the GPU scissor can apply it). Internal.
function crt_cx__rect_clips(_c) {
    for (var _k = 0; _k < array_length(_c.clips); _k++) if (!_c.clips[_k].rect) return false;
    return true;
}

/// @function crt_cx__scissor_on(ctx)
/// @description Apply the rectangular clips as the GPU scissor; returns the previous scissor (or undefined when there
/// is no clip). Internal.
function crt_cx__scissor_on(_c) {
    var _n = array_length(_c.clips);
    if (_n == 0) return undefined;
    var _x0 = -1000000, _y0 = -1000000, _x1 = 1000000, _y1 = 1000000;
    for (var _k = 0; _k < _n; _k++) { var _cp = _c.clips[_k]; _x0 = max(_x0, _cp.x0); _y0 = max(_y0, _cp.y0); _x1 = min(_x1, _cp.x1); _y1 = min(_y1, _cp.y1); }
    var _prev = gpu_get_scissor();
    var _ix0 = max(_prev.x, floor(_x0 + 0.5)), _iy0 = max(_prev.y, floor(_y0 + 0.5));
    var _ix1 = min(_prev.x + _prev.w, floor(_x1 + 0.5)), _iy1 = min(_prev.y + _prev.h, floor(_y1 + 0.5));
    gpu_set_scissor(_ix0, _iy0, max(0, _ix1 - _ix0), max(0, _iy1 - _iy0));
    return _prev;
}

/// @function crt_cx__scissor_off(prev)
/// @description Restore the scissor crt_cx__scissor_on replaced. Internal.
function crt_cx__scissor_off(_prev) { if (is_struct(_prev)) gpu_set_scissor(_prev.x, _prev.y, _prev.w, _prev.h); }

/// @function crt_cx__convex(ring)
/// @description True when a ring turns one way only (near-zero turns and repeated points ignored). Internal.
function crt_cx__convex(_r) {
    var _n = array_length(_r), _sign = 0;
    if (_n < 3) return false;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _r[_i], _b = _r[(_i + 1) mod _n], _d = _r[(_i + 2) mod _n];
        var _cr = (_b[0] - _a[0]) * (_d[1] - _b[1]) - (_b[1] - _a[1]) * (_d[0] - _b[0]);
        if (abs(_cr) < 0.0001) continue;
        var _s = (_cr > 0) ? 1 : -1;
        if (_sign == 0) _sign = _s; else if (_s != _sign) return false;
    }
    return _sign != 0;
}

/// @function crt_cx__fan(ctx, ring, paint, alpha)
/// @description A convex ring as a fan (flat paint) or a mesh of concentric rings (radial paint, every vertex coloured
/// at its own point). Internal.
function crt_cx__fan(_c, _r, _paint, _alpha) {
    var _n = array_length(_r), _cx = 0, _cy = 0, _i, _k;
    for (_i = 0; _i < _n; _i++) { _cx += _r[_i][0]; _cy += _r[_i][1]; }
    _cx /= _n; _cy /= _n;
    var _prev = crt_cx__scissor_on(_c);
    if (_paint.kind == 0) {
        var _a = _alpha * _paint.a;
        draw_primitive_begin(pr_trianglelist);
        var _v = 0;
        for (_i = 0; _i < _n; _i++) {
            if (_v >= 900) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); _v = 0; }
            var _p = _r[_i], _q = _r[(_i + 1) mod _n];
            draw_vertex_colour(_cx, _cy, _paint.col, _a); draw_vertex_colour(_p[0], _p[1], _paint.col, _a); draw_vertex_colour(_q[0], _q[1], _paint.col, _a);
            _v += 3;
        }
        draw_primitive_end();
    } else {
        // at most 48 spokes and 6 rings: a radial wash has no edge to resolve, only a ramp
        var _step = max(1, ceil(_n / 48)), _pts = [];
        for (_i = 0; _i < _n; _i += _step) array_push(_pts, _r[_i]);
        var _m = array_length(_pts), _K = 6;
        draw_primitive_begin(pr_trianglelist);
        var _vv = 0;
        for (_k = 0; _k < _K; _k++) {
            var _t0 = _k / _K, _t1 = (_k + 1) / _K;
            for (_i = 0; _i < _m; _i++) {
                if (_vv >= 894) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); _vv = 0; }
                var _a0 = _pts[_i], _b0 = _pts[(_i + 1) mod _m];
                var _p00x = _cx + (_a0[0] - _cx) * _t0, _p00y = _cy + (_a0[1] - _cy) * _t0, _p01x = _cx + (_b0[0] - _cx) * _t0, _p01y = _cy + (_b0[1] - _cy) * _t0;
                var _p10x = _cx + (_a0[0] - _cx) * _t1, _p10y = _cy + (_a0[1] - _cy) * _t1, _p11x = _cx + (_b0[0] - _cx) * _t1, _p11y = _cy + (_b0[1] - _cy) * _t1;
                var _c00 = crt_cx__paint_at(_paint, _p00x, _p00y), _c01 = crt_cx__paint_at(_paint, _p01x, _p01y);
                var _c10 = crt_cx__paint_at(_paint, _p10x, _p10y), _c11 = crt_cx__paint_at(_paint, _p11x, _p11y);
                draw_vertex_colour(_p00x, _p00y, _c00[0], _alpha * _c00[1]); draw_vertex_colour(_p10x, _p10y, _c10[0], _alpha * _c10[1]); draw_vertex_colour(_p11x, _p11y, _c11[0], _alpha * _c11[1]);
                draw_vertex_colour(_p00x, _p00y, _c00[0], _alpha * _c00[1]); draw_vertex_colour(_p11x, _p11y, _c11[0], _alpha * _c11[1]); draw_vertex_colour(_p01x, _p01y, _c01[0], _alpha * _c01[1]);
                _vv += 6;
            }
        }
        draw_primitive_end();
    }
    crt_cx__scissor_off(_prev);
}

/// @function crt_cx__rect_fast(ctx, x0, y0, x1, y1, paint, alpha)
/// @description An axis-aligned device rectangle: one quad (flat), or one band per stop of a gradient running along x
/// or y. Returns false (the caller falls back) for a diagonal gradient. Internal.
function crt_cx__rect_fast(_c, _x0, _y0, _x1, _y1, _paint, _alpha) {
    if (_paint.kind == 1) {
        var _gx = _paint.x1 - _paint.x0, _gy = _paint.y1 - _paint.y0;
        if (abs(_gx) > 0.0001 && abs(_gy) > 0.0001) return false;
    }
    var _prev = crt_cx__scissor_on(_c);
    draw_primitive_begin(pr_trianglelist);
    if (_paint.kind == 0) {
        var _a = _alpha * _paint.a;
        draw_vertex_colour(_x0, _y0, _paint.col, _a); draw_vertex_colour(_x1, _y0, _paint.col, _a); draw_vertex_colour(_x0, _y1, _paint.col, _a);
        draw_vertex_colour(_x1, _y0, _paint.col, _a); draw_vertex_colour(_x1, _y1, _paint.col, _a); draw_vertex_colour(_x0, _y1, _paint.col, _a);
    } else {
        var _alongX = abs(_paint.x1 - _paint.x0) > 0.0001;
        var _g0 = _alongX ? _paint.x0 : _paint.y0, _g1 = _alongX ? _paint.x1 : _paint.y1;
        var _lo = _alongX ? _x0 : _y0, _hi = _alongX ? _x1 : _y1;
        // cut points: the rect's own ends plus every stop that falls inside it
        var _cuts = [_lo, _hi], _s = _paint.stops;
        for (var _i = 0; _i < array_length(_s); _i++) { var _u = _g0 + (_g1 - _g0) * _s[_i][0]; if (_u > _lo && _u < _hi) array_push(_cuts, _u); }
        array_sort(_cuts, true);
        for (var _j = 0; _j + 1 < array_length(_cuts); _j++) {
            var _ua = _cuts[_j], _ub = _cuts[_j + 1];
            if (_ub - _ua < 0.0001) continue;
            var _ca = crt_cx__paint_at(_paint, _alongX ? _ua : _x0, _alongX ? _y0 : _ua), _cb = crt_cx__paint_at(_paint, _alongX ? _ub : _x0, _alongX ? _y0 : _ub);
            var _aa = _alpha * _ca[1], _ab = _alpha * _cb[1];
            if (_alongX) {
                draw_vertex_colour(_ua, _y0, _ca[0], _aa); draw_vertex_colour(_ub, _y0, _cb[0], _ab); draw_vertex_colour(_ua, _y1, _ca[0], _aa);
                draw_vertex_colour(_ub, _y0, _cb[0], _ab); draw_vertex_colour(_ub, _y1, _cb[0], _ab); draw_vertex_colour(_ua, _y1, _ca[0], _aa);
            } else {
                draw_vertex_colour(_x0, _ua, _ca[0], _aa); draw_vertex_colour(_x1, _ua, _ca[0], _aa); draw_vertex_colour(_x0, _ub, _cb[0], _ab);
                draw_vertex_colour(_x1, _ua, _ca[0], _aa); draw_vertex_colour(_x1, _ub, _cb[0], _ab); draw_vertex_colour(_x0, _ub, _cb[0], _ab);
            }
        }
    }
    draw_primitive_end();
    crt_cx__scissor_off(_prev);
    return true;
}

/// @function crt_cx__strip_subs(ctx, subs)
/// @description Solid strokes as one triangle strip per subpath, the vertices MITRE-joined (the offset at each vertex is
/// the bisector of its two segments' normals, capped at 4x), so consecutive segments share an edge instead of
/// overlapping - a translucent line never darkens at its joints and never gaps. Round caps are discs. Internal.
function crt_cx__strip_subs(_c, _subs) {
    var _w = _c.lw * crt_cx__scale(_c), _a = _c.alpha;
    if (!(_w > 0)) return;
    if (_w < 1) { _a *= max(0.15, _w); _w = 1; }
    var _h = _w * 0.5, _col = _c.stroke.col, _ca = _a * _c.stroke.a;
    var _prev = crt_cx__scissor_on(_c);
    for (var _s = 0; _s < array_length(_subs); _s++) {
        var _raw = _subs[_s].pts, _cl = _subs[_s].closed;
        // drop repeated points (a zero-length segment has no direction)
        var _p = [];
        for (var _i = 0; _i < array_length(_raw); _i++) {
            if (array_length(_p) > 0) { var _l = _p[array_length(_p) - 1]; if (abs(_l[0] - _raw[_i][0]) < 0.001 && abs(_l[1] - _raw[_i][1]) < 0.001) continue; }
            array_push(_p, _raw[_i]);
        }
        if (_cl && array_length(_p) > 2) { var _f = _p[0], _e = _p[array_length(_p) - 1]; if (abs(_f[0] - _e[0]) < 0.001 && abs(_f[1] - _e[1]) < 0.001) array_delete(_p, array_length(_p) - 1, 1); }
        var _n = array_length(_p);
        if (_n < 2) continue;
        if (_n == 2) _cl = false;
        // unit normals of every segment
        var _segs = _cl ? _n : _n - 1, _nx = array_create(_segs), _ny = array_create(_segs);
        for (var _k = 0; _k < _segs; _k++) {
            var _pa = _p[_k], _pb = _p[(_k + 1) mod _n];
            var _dx = _pb[0] - _pa[0], _dy = _pb[1] - _pa[1], _dl = max(0.000001, sqrt(_dx * _dx + _dy * _dy));
            _nx[_k] = -_dy / _dl; _ny[_k] = _dx / _dl;
        }
        // the mitred offset at every point: the bisector of its two segments' normals, lengthened to keep the stroke's
        // width across the turn, capped at 4x so a hairpin cannot throw a spike
        var _ox = array_create(_n), _oy = array_create(_n);
        for (var _j = 0; _j < _n; _j++) {
            if (!_cl && _j == 0) { _ox[_j] = _nx[0]; _oy[_j] = _ny[0]; continue; }
            if (!_cl && _j == _n - 1) { _ox[_j] = _nx[_segs - 1]; _oy[_j] = _ny[_segs - 1]; continue; }
            var _i0 = (_j - 1 + _segs) mod _segs, _i1 = _j mod _segs;
            var _mx = _nx[_i0] + _nx[_i1], _my = _ny[_i0] + _ny[_i1], _ml = sqrt(_mx * _mx + _my * _my);
            if (_ml < 0.001) { _ox[_j] = _nx[_i0]; _oy[_j] = _ny[_i0]; continue; }
            _mx /= _ml; _my /= _ml;
            var _k2 = 1 / max(0.25, _mx * _nx[_i0] + _my * _ny[_i0]);
            _ox[_j] = _mx * _k2; _oy[_j] = _my * _k2;
        }
        // one quad per segment; neighbours share their mitred edge exactly, so nothing overlaps and nothing gaps
        draw_primitive_begin(pr_trianglelist);
        var _v = 0;
        for (var _q = 0; _q < _segs; _q++) {
            if (_v >= 900) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); _v = 0; }
            var _ia = _q, _ib = (_q + 1) mod _n, _A = _p[_ia], _B = _p[_ib];
            var _ax1 = _A[0] + _ox[_ia] * _h, _ay1 = _A[1] + _oy[_ia] * _h, _ax2 = _A[0] - _ox[_ia] * _h, _ay2 = _A[1] - _oy[_ia] * _h;
            var _bx1 = _B[0] + _ox[_ib] * _h, _by1 = _B[1] + _oy[_ib] * _h, _bx2 = _B[0] - _ox[_ib] * _h, _by2 = _B[1] - _oy[_ib] * _h;
            draw_vertex_colour(_ax1, _ay1, _col, _ca); draw_vertex_colour(_bx1, _by1, _col, _ca); draw_vertex_colour(_ax2, _ay2, _col, _ca);
            draw_vertex_colour(_bx1, _by1, _col, _ca); draw_vertex_colour(_bx2, _by2, _col, _ca); draw_vertex_colour(_ax2, _ay2, _col, _ca);
            _v += 6;
        }
        draw_primitive_end();
        if (_c.cap == 1 && !_cl) {
            crt_cx__fan(_c, crt_cx__disc(_p[0][0], _p[0][1], _h), _c.stroke, _a);
            crt_cx__fan(_c, crt_cx__disc(_p[_n - 1][0], _p[_n - 1][1], _h), _c.stroke, _a);
        }
    }
    crt_cx__scissor_off(_prev);
}

/// @function crt_cx__stroke_subs(ctx, subs)
/// @description The union of every segment's quad (plus round joins and caps) filled once, nonzero, so a translucent
/// stroke never doubles its alpha where segments meet. Internal.
function crt_cx__stroke_subs(_c, _subs) {
    var _w = _c.lw * crt_cx__scale(_c), _a = _c.alpha;
    if (!(_w > 0)) return;
    if (_w < 1) { _a *= max(0.15, _w); _w = 1; }
    var _h = _w * 0.5, _rings = [];
    for (var _s = 0; _s < array_length(_subs); _s++) {
        var _p = _subs[_s].pts, _cl = _subs[_s].closed, _n = array_length(_p);
        if (_n < 2) continue;
        var _m = _cl ? _n : _n - 1;
        for (var _i = 0; _i < _m; _i++) {
            var _pa = _p[_i], _pb = _p[(_i + 1) mod _n];
            var _dx = _pb[0] - _pa[0], _dy = _pb[1] - _pa[1], _l = sqrt(_dx * _dx + _dy * _dy);
            if (_l < 0.0001) continue;
            var _nx = -_dy / _l * _h, _ny = _dx / _l * _h;
            array_push(_rings, crt_cx__pos([[_pa[0] + _nx, _pa[1] + _ny], [_pb[0] + _nx, _pb[1] + _ny], [_pb[0] - _nx, _pb[1] - _ny], [_pa[0] - _nx, _pa[1] - _ny]]));
        }
        if (_w >= 2.5) {
            var _from = _cl ? 0 : 1, _to = _cl ? _n : _n - 1;
            for (var _j = _from; _j < _to; _j++) array_push(_rings, crt_cx__disc(_p[_j][0], _p[_j][1], _h));
        }
        if (_c.cap == 1 && !_cl) {
            array_push(_rings, crt_cx__disc(_p[0][0], _p[0][1], _h));
            array_push(_rings, crt_cx__disc(_p[_n - 1][0], _p[_n - 1][1], _h));
        }
    }
    crt_cx__fill(_c, _rings, _c.stroke, _a, CRT_FILL_NONZERO);
}

/// @function crt_cx__disc(x, y, r)
/// @description A small disc ring, positively wound. Internal.
function crt_cx__disc(_x, _y, _r) {
    var _n = clamp(ceil(_r * 1.6), 8, 40), _o = array_create(_n);
    for (var _i = 0; _i < _n; _i++) { var _t = _i / _n * 2 * pi; _o[_i] = [_x + cos(_t) * _r, _y + sin(_t) * _r]; }
    return _o;
}

/// @function crt_cx__pos(ring)
/// @description The ring wound positively (reversed if its signed area is negative), so a union fills. Internal.
function crt_cx__pos(_r) {
    var _a = 0, _n = array_length(_r);
    for (var _i = 0; _i < _n; _i++) { var _j = (_i + 1) mod _n; _a += _r[_i][0] * _r[_j][1] - _r[_j][0] * _r[_i][1]; }
    if (_a < 0) array_reverse_ext(_r);
    return _r;
}

/// @function crt_cx_clip(ctx)
/// @description Intersect the clip region with the current path. ⛔ The path must be CONVEX (a rectangle, the
/// portrait aperture): a convex region crosses a scanline once, and that single interval is what every span is cut
/// to. A concave clip is refused (returns false) rather than clipped wrongly.
function crt_cx_clip(_c) {
    var _r = crt_cx__rings(_c);
    if (array_length(_r) != 1) return false;
    var _ring = _r[0], _y0 = 1000000, _y1 = -1000000, _x0 = 1000000, _x1 = -1000000, _n = array_length(_ring);
    for (var _i = 0; _i < _n; _i++) { _x0 = min(_x0, _ring[_i][0]); _x1 = max(_x1, _ring[_i][0]); _y0 = min(_y0, _ring[_i][1]); _y1 = max(_y1, _ring[_i][1]); }
    // an axis-aligned rectangle is the GPU scissor's shape; anything else is cut span by span in the scanline fill
    var _rect = (_n == 4);
    for (var _e = 0; _e < _n && _rect; _e++) {
        var _a = _ring[_e], _b = _ring[(_e + 1) mod _n];
        if (abs(_a[0] - _b[0]) > 0.0001 && abs(_a[1] - _b[1]) > 0.0001) _rect = false;
    }
    array_push(_c.clips, { ring: _ring, x0: _x0, y0: _y0, x1: _x1, y1: _y1, rect: _rect });
    return true;
}

/// @function crt_cx__clip_span(ctx, y)
/// @description The clip interval [l, r] on the scanline at y, or undefined when the row is clipped away (or
/// [-inf, +inf] with no clip). Internal.
function crt_cx__clip_span(_c, _y) {
    var _l = -1000000, _r = 1000000;
    for (var _k = 0; _k < array_length(_c.clips); _k++) {
        var _cp = _c.clips[_k];
        if (_y < _cp.y0 || _y > _cp.y1) return undefined;
        var _ring = _cp.ring, _n = array_length(_ring), _lo = 1000000, _hi = -1000000, _hit = false;
        for (var _i = 0; _i < _n; _i++) {
            var _a = _ring[_i], _b = _ring[(_i + 1) mod _n];
            if ((_a[1] <= _y && _b[1] > _y) || (_b[1] <= _y && _a[1] > _y)) {
                var _x = _a[0] + (_y - _a[1]) * (_b[0] - _a[0]) / (_b[1] - _a[1]);
                _lo = min(_lo, _x); _hi = max(_hi, _x); _hit = true;
            }
        }
        if (!_hit) return undefined;
        _l = max(_l, _lo); _r = min(_r, _hi);
        if (_r <= _l) return undefined;
    }
    return [_l, _r];
}

/// @function crt_cx__paint_at(paint, x, y)
/// @description The [colour, alpha] of a paint at a device point (gradients extend their end stops). Internal.
function crt_cx__paint_at(_p, _x, _y) {
    if (_p.kind == 0) return [_p.col, _p.a];
    var _t = 0;
    if (_p.kind == 1) {
        var _gx = _p.x1 - _p.x0, _gy = _p.y1 - _p.y0, _l2 = _gx * _gx + _gy * _gy;
        _t = (_l2 > 0) ? ((_x - _p.x0) * _gx + (_y - _p.y0) * _gy) / _l2 : 0;
    } else {
        _t = crt_cx__radial_t(_p, _x, _y);
        if (is_undefined(_t)) return [c_black, 0];
    }
    return crt_cx__stops_at(_p.stops, _t);
}

/// @function crt_cx__radial_t(paint, x, y)
/// @description The canvas two-circle gradient parameter at a point: the largest t whose circle passes through it with
/// a non-negative radius, or undefined. Internal.
function crt_cx__radial_t(_p, _x, _y) {
    var _cdx = _p.x1 - _p.x0, _cdy = _p.y1 - _p.y0, _dr = _p.r1 - _p.r0;
    var _pdx = _x - _p.x0, _pdy = _y - _p.y0;
    var _a = _cdx * _cdx + _cdy * _cdy - _dr * _dr;
    var _b = _pdx * _cdx + _pdy * _cdy + _p.r0 * _dr;
    var _cc = _pdx * _pdx + _pdy * _pdy - _p.r0 * _p.r0;
    var _t;
    if (abs(_a) < 0.000001) {
        if (abs(_b) < 0.000001) return undefined;
        _t = _cc / (2 * _b);
    } else {
        var _disc = _b * _b - _a * _cc;
        if (_disc < 0) return undefined;
        var _sq = sqrt(_disc), _t1 = (_b + _sq) / _a, _t2 = (_b - _sq) / _a;
        _t = max(_t1, _t2);
        if (_p.r0 + _t * _dr < 0) { _t = min(_t1, _t2); if (_p.r0 + _t * _dr < 0) return undefined; }
    }
    return _t;
}

/// @function crt_cx__stops_at(stops, t)
/// @description [colour, alpha] of a stop list at t, clamped to its ends. Internal.
function crt_cx__stops_at(_s, _t) {
    var _n = array_length(_s);
    if (_n == 0) return [c_black, 0];
    if (_t <= _s[0][0]) return [_s[0][1], _s[0][2]];
    for (var _i = 1; _i < _n; _i++) {
        if (_t <= _s[_i][0]) {
            var _a = _s[_i - 1], _b = _s[_i], _sp = _b[0] - _a[0];
            var _k = (_sp > 0.000001) ? (_t - _a[0]) / _sp : 1;
            return [merge_colour(_a[1], _b[1], _k), _a[2] + (_b[2] - _a[2]) * _k];
        }
    }
    return [_s[_n - 1][1], _s[_n - 1][2]];
}

/// @function crt_cx__room(ctx, n)
/// @description Make room for n vertices in the open triangle list, flushing at 900. Internal.
function crt_cx__room(_c, _n) {
    if (_c.verts + _n > 900) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); _c.verts = 0; }
    _c.verts += _n;
}

/// @function crt_cx__fill(ctx, rings, paint, alpha, rule)
/// @description Scanline-fill device rings (nonzero or even-odd) with a paint, cut to the clip region. Each span end
/// carries its fractional coverage as alpha. Returns the number of spans drawn. Internal.
function crt_cx__fill(_c, _rings, _paint, _alpha, _rule) {
    if (!is_array(_rings) || !(_alpha > 0)) return 0;
    var _edges = [], _y0 = 1000000, _y1 = -1000000;
    for (var _r = 0; _r < array_length(_rings); _r++) {
        var _ring = _rings[_r];
        var _n = array_length(_ring);
        if (_n < 3) continue;
        for (var _i = 0; _i < _n; _i++) {
            var _a = _ring[_i], _b = _ring[(_i + 1) mod _n];
            if (abs(_a[1] - _b[1]) < 0.00001) continue;
            var _down = (_a[1] < _b[1]);
            var _top = _down ? _a : _b, _bot = _down ? _b : _a;
            array_push(_edges, [_top[1], _bot[1], _top[0], (_bot[0] - _top[0]) / (_bot[1] - _top[1]), _down ? 1 : -1]);
            _y0 = min(_y0, _top[1]); _y1 = max(_y1, _bot[1]);
        }
    }
    var _ne = array_length(_edges);
    if (_ne < 2) return 0;
    // ⛔ The comparator returns a SIGN, never a difference: a fractional difference reads as "equal" to the sort and
    // admits edges rows late (a disc lost two thirds of its interior that way in a sibling product).
    array_sort(_edges, function(_p, _q) { return (_p[0] < _q[0]) ? -1 : ((_p[0] > _q[0]) ? 1 : 0); });
    var _active = [], _next = 0, _spans = 0;
    _c.verts = 0;
    draw_primitive_begin(pr_trianglelist);
    for (var _y = floor(_y0) + 0.5; _y < _y1; _y += 1) {
        while (_next < _ne && _edges[_next][0] <= _y) { array_push(_active, _edges[_next]); _next++; }
        var _xs = [], _keep = [];
        for (var _k = 0; _k < array_length(_active); _k++) {
            var _e = _active[_k];
            if (_e[1] <= _y) continue;
            array_push(_keep, _e);
            if (_e[0] <= _y) array_push(_xs, [_e[2] + (_y - _e[0]) * _e[3], _e[4]]);
        }
        _active = _keep;
        var _nx = array_length(_xs);
        if (_nx < 2) continue;
        var _cl = crt_cx__clip_span(_c, _y);
        if (is_undefined(_cl)) continue;
        array_sort(_xs, function(_p, _q) { return (_p[0] < _q[0]) ? -1 : ((_p[0] > _q[0]) ? 1 : 0); });
        var _w = 0, _from = 0;
        for (var _s = 0; _s < _nx; _s++) {
            var _was = (_rule == CRT_FILL_EVENODD) ? ((_w & 1) != 0) : (_w != 0);
            _w += (_rule == CRT_FILL_EVENODD) ? 1 : _xs[_s][1];
            var _in = (_rule == CRT_FILL_EVENODD) ? ((_w & 1) != 0) : (_w != 0);
            if (_in && !_was) _from = _xs[_s][0];
            if (!_in && _was) {
                var _xa = max(_from, _cl[0]), _xb = min(_xs[_s][0], _cl[1]);
                if (_xb - _xa >= 0.001) { crt_cx__span(_c, _xa, _xb, _y, _paint, _alpha); _spans++; }
            }
        }
    }
    draw_primitive_end();
    _c.verts = 0;
    return _spans;
}

/// @function crt_cx__span(ctx, xa, xb, y, paint, alpha)
/// @description One scanline span: coverage-alpha ends, a gradient sampled along it. Internal.
function crt_cx__span(_c, _xa, _xb, _y, _paint, _alpha) {
    var _L = floor(_xa), _R = floor(_xb), _ya = _y - 0.5, _yb = _y + 0.5;
    if (_L == _R) { crt_cx__piece(_c, _L, _L + 1, _ya, _yb, _y, _paint, _alpha * (_xb - _xa)); return; }
    crt_cx__piece(_c, _L, _L + 1, _ya, _yb, _y, _paint, _alpha * (_L + 1 - _xa));
    if (_R > _L + 1) {
        if (_paint.kind == 0) crt_cx__piece(_c, _L + 1, _R, _ya, _yb, _y, _paint, _alpha);
        else {
            // a gradient is sampled at most 4 px apart along the row (exact for a linear gradient between stops)
            var _k = max(1, ceil((_R - _L - 1) / 4));
            for (var _i = 0; _i < _k; _i++) crt_cx__piece(_c, _L + 1 + (_R - _L - 1) * _i / _k, _L + 1 + (_R - _L - 1) * (_i + 1) / _k, _ya, _yb, _y, _paint, _alpha);
        }
    }
    if (_xb - _R > 0.001) crt_cx__piece(_c, _R, _R + 1, _ya, _yb, _y, _paint, _alpha * (_xb - _R));
}

/// @function crt_cx__piece(ctx, xa, xb, ya, yb, yc, paint, alpha)
/// @description Two triangles of one span piece, coloured at each end from the paint. Internal.
function crt_cx__piece(_c, _xa, _xb, _ya, _yb, _yc, _paint, _alpha) {
    var _ca, _cb, _aa, _ab;
    if (_paint.kind == 0) { _ca = _paint.col; _cb = _ca; _aa = _alpha * _paint.a; _ab = _aa; }
    else {
        var _pa = crt_cx__paint_at(_paint, _xa, _yc), _pb = crt_cx__paint_at(_paint, _xb, _yc);
        _ca = _pa[0]; _cb = _pb[0]; _aa = _alpha * _pa[1]; _ab = _alpha * _pb[1];
    }
    if (_aa <= 0 && _ab <= 0) return;
    crt_cx__room(_c, 6);
    draw_vertex_colour(_xa, _ya, _ca, _aa); draw_vertex_colour(_xb, _ya, _cb, _ab); draw_vertex_colour(_xa, _yb, _ca, _aa);
    draw_vertex_colour(_xb, _ya, _cb, _ab); draw_vertex_colour(_xb, _yb, _cb, _ab); draw_vertex_colour(_xa, _yb, _ca, _aa);
}

// ---------------------------------------------------------------------------------------------------------------
// Type
// ---------------------------------------------------------------------------------------------------------------

/// @function crt_font_px(font)
/// @description The pixel size a font resource was rasterised at (a buyer's own font is measured from its "H").
function crt_font_px(_font) {
    if (_font == fnt_cartouche_display) return 120;
    if (_font == fnt_cartouche_title) return 56;
    if (_font == fnt_cartouche) return 26;
    if (_font == fnt_cartouche_ui) return 17;
    var _prev = draw_get_font();
    draw_set_font(_font);
    var _h = string_height("H");
    draw_set_font(_prev);
    return max(1, _h);
}

/// @function crt_font_for(px)
/// @description The serif atlas to draw `px`-tall type from: a bitmap font scaled UP goes soft, so large type comes
/// from the bigger atlas of the same face. Pure.
function crt_font_for(_px) {
    if (_px > 84) return fnt_cartouche_display;
    if (_px > 38) return fnt_cartouche_title;
    return fnt_cartouche;
}

/// @function crt_text(x, y, string, px, colour, [halign], [valign], [font], [alpha])
/// @description Draw type `px` pixels tall (the serif by default, from the atlas that suits the size). Returns the
/// drawn width. ⛔ Texture filtering is switched ON for the draw and RESTORED after: a scaled atlas with point
/// sampling drops one-pixel strokes (a "T" becomes an "I").
function crt_text(_x, _y, _s, _px, _col, _ha = fa_left, _va = fa_top, _font = undefined, _alpha = 1) {
    _s = string(_s);
    if (is_undefined(_font)) _font = crt_font_for(_px);
    var _pf = draw_get_font(), _ph = draw_get_halign(), _pv = draw_get_valign(), _pa = draw_get_alpha(), _pc = draw_get_colour(), _pt = gpu_get_texfilter();
    draw_set_font(_font);
    var _sc = _px / crt_font_px(_font);
    var _w = string_width(_s) * _sc;
    draw_set_halign(_ha); draw_set_valign(_va); draw_set_colour(_col); draw_set_alpha(_alpha);
    gpu_set_texfilter(true);
    draw_text_transformed(_x, _y, _s, _sc, _sc, 0);
    gpu_set_texfilter(_pt);
    draw_set_font(_pf); draw_set_halign(_ph); draw_set_valign(_pv); draw_set_alpha(_pa); draw_set_colour(_pc);
    return _w;
}

/// @function crt_text_w(string, px, [font])
/// @description The width crt_text would draw a string at.
function crt_text_w(_s, _px, _font = undefined) {
    if (is_undefined(_font)) _font = crt_font_for(_px);
    var _pf = draw_get_font();
    draw_set_font(_font);
    var _w = string_width(string(_s)) * _px / crt_font_px(_font);
    draw_set_font(_pf);
    return _w;
}

/// @function crt_cx_text(ctx, string, x, y, px, bold, rgb, alpha)
/// @description Centred type at a USER-space point under the current transform. `bold` is struck twice, a hair apart
/// (the plate serif has one weight). Returns the drawn width in user units.
function crt_cx_text(_c, _s, _x, _y, _px, _bold, _rgb, _alpha) {
    var _p = crt_cx__pt(_c, _x, _y), _k = crt_cx__scale(_c), _col = crt_col(_rgb), _dpx = _px * _k;
    var _w = crt_text(_p[0], _p[1], _s, _dpx, _col, fa_center, fa_middle, undefined, _alpha * _c.alpha);
    if (_bold) crt_text(_p[0] + max(0.6, _dpx * 0.035), _p[1], _s, _dpx, _col, fa_center, fa_middle, undefined, _alpha * _c.alpha);
    return _w / max(0.0001, _k);
}
