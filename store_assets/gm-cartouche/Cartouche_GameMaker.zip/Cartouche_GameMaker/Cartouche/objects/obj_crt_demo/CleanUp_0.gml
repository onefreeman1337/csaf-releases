/// @description Free the demo portrait and every cached box.
if (variable_instance_exists(id, "demo") && is_struct(demo)) crt_demo_free(demo);
demo = undefined;
