/// @description Space / Enter / Right finish the line or go to the next speaker, Left goes back, P toggles the portrait,
/// G cycles the view (dialogue, a gallery of six speakers, a street of six townsfolk).
if (!is_struct(demo)) exit;
crt_demo_step(demo);
