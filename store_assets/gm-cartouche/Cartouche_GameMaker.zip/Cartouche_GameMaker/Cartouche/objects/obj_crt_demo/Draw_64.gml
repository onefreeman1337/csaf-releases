/// @description The scene and the speaker's box (crt_draw is the same call your game makes), then the keys.
if (!is_struct(demo)) exit;
crt_demo_draw(demo, display_get_gui_width(), display_get_gui_height());
