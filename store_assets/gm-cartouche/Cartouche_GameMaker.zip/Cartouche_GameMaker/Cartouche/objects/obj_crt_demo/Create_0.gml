/// @description Cartouche demo - a dialogue that walks a 24-speaker cast, every line in that speaker's own box - and the
/// headless entry point (-selftest).
/// ⛔ The crash handler is installed FIRST, and every variable a later event reads is declared ABOVE the early exits:
/// Clean Up always runs, even when Create leaves early.
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("crt_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.crt_stage) + ": " + string(_ex.message) + " | " + string(_ex.stacktrace));
    file_text_close(_f);
    game_end();
});
global.crt_stage = 0;
demo = crt_demo_state();
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";
if (string_pos("-selftest", _args) > 0) { global.crt_stage = 1; crt_selftest_write(crt_selftest_run()); game_end(); exit; }
