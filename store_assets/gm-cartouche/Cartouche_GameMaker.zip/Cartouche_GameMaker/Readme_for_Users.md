# Cartouche - The Message Box Drawn as an Object, for GameMaker

**GameMaker 2024.14 or newer · pure GML · no sprites, no shaders, no extensions**
Core Systems Asset Factory · <https://csaf.itch.io>

Most games draw every line of dialogue in one box, whoever is speaking. Cartouche draws the box as an
OBJECT, generated for the speaker: what its frame is made of and how it is built, the bands worked along
its rails, its corners, a nameplate struck into the head rail, a sunk panel for a portrait, a ground under
the text, and an advance caret that belongs to the set. The king's box is not the goblin's box, and
neither is the innkeeper's. Every box is drawn in code at run time. **Nothing here is an image file.**

It draws the box only. Your text still comes from your own text code (`draw_text_ext`, Scribble, anything):
Cartouche tells it where to write and in what colour.

---

## Quick start

1. **Tools > Import Local Package**, choose `Cartouche.yymps`, import everything.
2. Open `rm_crt_demo` and press Play: **Space** finishes a line or goes to the next speaker, **Left** goes
   back, **P** puts a portrait in the box, **G** switches to a gallery of six speakers and to a street of
   six townsfolk.
3. In your own game, read a speaker once and draw their box where your dialogue goes:

```gml
// when a line of dialogue starts
my_speaker = crt_read({ name: "Innkeeper", kind: "commons" });

// Draw GUI
var my_w = 816, my_h = 4 * 36 + crt_max_frame_height(816);   // four lines of text plus the frame
var my_x = 32, my_y = display_get_gui_height() - my_h - 16;
crt_draw(my_speaker, my_x, my_y, my_w, my_h, { name: "Innkeeper", phase: (current_time mod 1000) / 1000 });
var my_text = crt_text_rect(my_speaker, my_w, my_h);
draw_set_colour(crt_ink(my_speaker));
draw_text_ext(my_x + my_text.x, my_y + my_text.y, "Rooms are two silver a night.", 34, my_text.w);

// Clean Up (or Room End)
crt_cache_clear();
```

`crt_draw` bakes each box into a sprite the first time it is drawn and draws that sprite every frame after,
so a box costs nothing once it exists. To pay for a box before its first line (a loading screen, a room
start), call `crt_prepare` with the same speaker, size and options.

---

## What a speaker reads

A speaker is a struct. Every field is optional.

| Field | Meaning |
| --- | --- |
| `name` | The name struck into the nameplate is the `name` you pass to `crt_draw`; this one is part of who the speaker IS, so two speakers with different names get different boxes. |
| `kind` | Which of the five traditions the box belongs to: `"company"` (your party), `"commons"` (the town), `"adversary"` (the enemy), `"bestial"` (the wild), `"numinous"` (spirits and gods). Aliases work too: party, hero, ally, town, villager, npc, enemy, villain, foe, monster, beast, creature, spirit, god, ghost and more. Any other word is assigned to one of the five by hash, never dropped. Nothing at all is the town. |
| `slot` | A whole number telling apart two speakers of one kind and one name (six guards called "Guard"). |
| `rank` | `0` to `4`, or `"plain"`, `"kept"`, `"worked"`, `"honoured"`, `"sovereign"`. Leave it out and the rank is read from the kind (a spirit stands higher than a fishwife) and the speaker's identity. |
| `level` | A character's level. A level RAISED above 1 decides the rank (5, 12, 25 and 40 are the steps); a level of 1 says nothing. |
| `title` | A character's title or epithet ("the Bold"). A non-empty title lifts the rank one step. |
| `bounty` | An enemy's worth (gold, experience, threat). 5, 8, 15 and 50 are the steps. |
| `identity` | A string that replaces the automatic identity. Two speakers with one identity share a box. |

`level`, `title` and `bounty` are read only when the speaker has a `name`.

### How a speaker becomes an object

- **The kind** chooses a TRADITION: which materials, frame constructions, bands, corners, plates, grounds
  and carets exist at all. The party is leather, planed wood, brass and enamel; the town is limewash,
  rush, pine and slate; the enemy is lacquer, iron, obsidian and bloodstone on DARK fields; the wild is
  hide, bone, horn and chitin; the numinous is stone, frost, glass and nacre.
- **The rank** chooses how much WORK the object carries: a window into the tradition's own ordering (a plain
  speaker draws only from the humble end, a sovereign only from the rich end), how many bands run round the
  frame (one, two or three), and which corners and plates are reachable. The corner says the standing.
- **The identity** chooses what carries no meaning: which of the equal grounds, which tint, which caret.
  The identity is the kind WORD you wrote, the slot and the name: `"town"` and `"commons"` are the same
  tradition but two different individuals, so pick one word per character and keep it.

The same speaker gets the same box on every machine, every time.

### What is in it

40 materials, drawn with 18 surface figures (sawn, figured, fibrous, tooled, pebbled, cleaved, conchoidal,
mottled, porous, waterworn, banded, crystal, frosted, hammered, the meteoric lattice, nacre's growth arcs,
woven, plated) over each family's own finish (a metal's specular sweep, a glaze pooling at the foot, horn's
layers) · 28 frame constructions (with crests, blind
arcading and joints: mitre, butt, lap, peg, strap, lash, lead) · 30 bands · 26 corners · 35 nameplates ·
20 grounds · 15 carets, across 5 traditions and 5 ranks.

**The text colour is SOLVED, never picked.** For every material on every ground its tradition can give it,
the ink is walked from the material's own hue until it clears WCAG AAA (7:1) against the ground's least
legible texture - all 160 pairings clear 7:1. A villain's box is a pale hand on a dark field for that
reason. Read it with `crt_ink`.

---

## Sizing a box

The frame is sized from the box's WIDTH and is ADDED to the text area rather than carved out of it: the
object is taller than the text it holds. `crt_frame_height(speaker, w)` says how much taller one speaker's
box is; `crt_max_frame_height(w)` is the most any speaker needs, so a message box sized once as
`text height + crt_max_frame_height(w)` fits everyone (a plain box simply has more field).

Each box is drawn INSET inside the rect you give it. The margin is where a finial, horn, ray or crown
projects, so nothing is ever drawn outside your rect.

---

## Portraits

Pass `portrait: true` and the box cuts a sunk panel into its field (its head square, round-arched or
pointed, after the speaker's own crest). Then hand it your portrait sprite:

```gml
crt_draw(my_speaker, my_x, my_y, my_w, my_h, { name: "Innkeeper", portrait: true });
crt_draw_portrait(my_speaker, my_x, my_y, my_w, my_h, spr_my_innkeeper_face);
var my_text = crt_text_rect(my_speaker, my_w, my_h, true);   // the text now starts right of the panel
```

The portrait is scaled to cover the panel (aspect kept, anchored at the top, where a face is), clipped to
the panel's own outline and faded out over its last quarter, so the bust sinks into the recess instead of
being cut off square.

---

## Functions

| Function | Returns |
| --- | --- |
| `crt_read(speaker)` | a box spec (see the table above): `{kind, rank, work, identity, material, profile, plate, corner, bands, ground, caret, tint}` |
| `crt_speaker(name, kind, [slot], [rank])` | shorthand for `crt_read({name, kind, slot, rank})` |
| `crt_draw(spec, x, y, w, h, [opts])` | draws the box (baking it the first time) and its caret; returns the layout, or `undefined` for a bad spec or size. `opts`: `name`, `portrait`, `phase` (0 to 1, the caret's animation), `caret` (`false` hides it while text is still typing), `alpha` |
| `crt_draw_caret(spec, x, y, w, h, [phase], [alpha])` | only the caret; `false` for a bad spec |
| `crt_draw_portrait(spec, x, y, w, h, sprite, [subimg], [alpha])` | your portrait in the box's panel; `false` for a bad spec, size or sprite |
| `crt_text_rect(spec, w, h, [portrait])` | `{x, y, w, h}` where your text goes, relative to the box's rect |
| `crt_ink(spec)` | the text colour (a GameMaker colour) solved for that speaker's field |
| `crt_ink_rgb(spec)` | the same as `[r, g, b]` |
| `crt_ink_dim(spec)` | a quieter ink for secondary text |
| `crt_layout(spec, w, h)` | every dimension: `{base, top, side, foot, bleed, ox, oy, ow, oh, fx, fy, fw, fh}` (the object and the field) |
| `crt_frame_height(spec, w)` | how much taller than its text the box is |
| `crt_max_frame_height(w)` | the most any speaker needs at that width |
| `crt_reserve(spec, w, h)` | the portrait panel: `{x, y, w, h, head}` |
| `crt_box_sprite(spec, w, h, [opts])` | the box (without its caret) baked into a new sprite that is yours to `sprite_delete`. Its colours are PREMULTIPLIED: draw it with `gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha)` |
| `crt_portrait_sprite(spec, w, h, sprite, [subimg])` | your portrait fitted, clipped and faded into a new premultiplied sprite |
| `crt_prepare(spec, w, h, [opts])` | bakes a box into the cache now; `true` when it is cached |
| `crt_cache_clear()` | frees every cached box (Clean Up or Room End) |
| `crt_cache_count()` | how many boxes are cached (at most 48; the least recently drawn is freed) |
| `crt_kind_of(word)` | the tradition a kind word resolves to |
| `crt_kinds()` | the five traditions, in a stable order |
| `crt_ranks()` | the five ranks, low to high |
| `crt_describe(spec)` | a plain one-line description, e.g. `worked - polished slate - battened - lapped corners` |
| `crt_spec_key(spec)` | a string naming every visible choice (two speakers with one key share a box) |

A bad argument is a refusal (`undefined`, `false`, `0` or black), never a crash inside your Draw event.

### Two rules for your Draw event

- Keep a sprite from `crt_box_sprite` or `crt_portrait_sprite` alive until the frame that drew it has been
  shown: delete it in Step or Clean Up, never on the line after drawing it (a sprite deleted before the
  frame is presented draws as a white box). `crt_draw` and `crt_draw_portrait` manage their own sprites.
- Call `crt_cache_clear()` in Clean Up or Room End, not between drawing a box and the end of that frame.

---

## Speed

A box is baked once per speaker, size, name and portrait, then drawn as one sprite. The bake took 19 to 67 ms
for an 816 x 240 box across two test runs on our machine (the VM runtime, with other work running), so the
first line a speaker says can cost a few frames; `crt_prepare` moves that cost to a moment you choose.

---

## Fonts and licences

The nameplates and the demo's dialogue are set in IM Fell DW Pica (SIL Open Font License 1.1), bundled as
three font resources under the name "Cartouche Plate Serif"; the demo's help line is Open Sans (Apache
2.0). Both licence texts and the notices ship in `Cartouche/fonts/`. See `LICENSE.txt` for the package
licence.

This package was written with AI assistance, disclosed on every store listing.
