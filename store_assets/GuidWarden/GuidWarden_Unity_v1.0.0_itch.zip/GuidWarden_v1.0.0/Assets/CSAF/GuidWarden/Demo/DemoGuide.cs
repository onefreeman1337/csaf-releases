// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

// CSAF GUID Warden - demo scene guide.
// Copyright (c) Corey Gallant and Stephanie Thomason. See LICENSE.txt.

using UnityEngine;

namespace CSAF.GuidWarden.Demo
{
    /// <summary>
    /// On-screen instructions for the demo scene.
    /// </summary>
    /// <remarks>
    /// GUID Warden is an editor tool with no runtime behaviour, and an Asset Store reviewer opens
    /// the demo scene and presses Play. A scene that does visibly nothing reads as a broken
    /// sample, so this draws the walkthrough - including the deliberately broken sandbox that lets
    /// every repair be demonstrated without touching real assets.
    /// </remarks>
    [AddComponentMenu("CSAF/GUID Warden Demo Guide")]
    public sealed class DemoGuide : MonoBehaviour
    {
        private const int Margin = 24;

        private static readonly string[] Steps =
        {
            "1.  Tools  >  CSAF  >  GUID Warden  >  Open Window",
            "2.  Tools  >  CSAF  >  GUID Warden  >  Create Sandbox Issues",
            "     Three deliberately broken states appear in Assets/GuidWardenSandbox -",
            "     an asset with no .meta, an orphaned .meta, and TWO assets claiming ONE GUID.",
            "     Unity has not noticed them yet. That is the point: this is the window in which",
            "     references can still be saved. On a refresh, Unity would 'fix' all three silently.",
            "3.  Press 'Scan now'. One designed card per finding, each with its repair inline:",
            "",
            "     MISSING .META      restore it from git history - the GUID (and every reference",
            "                        to it) survives. Or accept a fresh GUID as an explicit decision.",
            "     ORPHANED .META     delete it - a byte-exact backup is kept, restorable in one click.",
            "     ONE GUID, TWO      choose which claimant keeps the GUID. The other is re-minted",
            "     CLAIMANTS          explicitly, with a receipt - never silently.",
            "",
            "4.  GIT HYGIENE panel: install the smart-merge rules, the UnityYAMLMerge driver and",
            "     the pre-commit guard that refuses reference-breaking commits.",
            "5.  Every act appears under RECEIPTS with what was verified after the write.",
            "6.  CI: run CSAF.GuidWarden.CI.GuidWardenCI.Run in batch mode to fail a build",
            "     on integrity issues. Tools > CSAF > GUID Warden > Remove Sandbox cleans up.",
        };

        private Styles? _styles;

        /// <summary>
        /// Built once, on the first OnGUI. Constructing a GUIStyle every OnGUI call is a per-frame
        /// allocation in a loop that runs continuously, which this factory treats as a defect
        /// rather than a detail.
        /// </summary>
        private sealed class Styles
        {
            public readonly GUIStyle Heading;
            public readonly GUIStyle Body;

            public Styles()
            {
                Heading = new GUIStyle(GUI.skin.label)
                {
                    fontSize = 20,
                    fontStyle = FontStyle.Bold,
                    normal = { textColor = new Color(0.92f, 0.94f, 0.97f) }
                };
                Body = new GUIStyle(GUI.skin.label)
                {
                    fontSize = 13,
                    richText = false,
                    normal = { textColor = new Color(0.74f, 0.78f, 0.84f) }
                };
            }
        }

        private void OnGUI()
        {
            Styles s = _styles ?? (_styles = new Styles());

            GUI.Label(new Rect(Margin, Margin, 900f, 30f), "GUID WARDEN", s.Heading);
            GUI.Label(new Rect(Margin, Margin + 28f, 940f, 22f),
                "Meta and GUID integrity, guarded before references break.", s.Body);

            float y = Margin + 62f;
            for (int i = 0; i < Steps.Length; i++)
            {
                GUI.Label(new Rect(Margin, y, 960f, 20f), Steps[i], s.Body);
                y += 20f;
            }
        }
    }
}
