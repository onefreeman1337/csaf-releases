// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

// CSAF GUID Warden - a minimal, shell-free git runner.
// Copyright (c) Corey Gallant and Stephanie Thomason. See LICENSE.txt.

using System;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace CSAF.GuidWarden.Acts
{
    /// <summary>Result of one git invocation: exit code plus captured streams.</summary>
    public sealed class GitResult
    {
        /// <summary>Process exit code, or -1 when git could not be started at all.</summary>
        public int ExitCode { get; }

        /// <summary>Captured stdout, verbatim.</summary>
        public string StdOut { get; }

        /// <summary>Captured stderr, verbatim.</summary>
        public string StdErr { get; }

        /// <summary>True when git ran and exited 0.</summary>
        public bool Ok { get { return ExitCode == 0; } }

        /// <summary>Creates one result.</summary>
        public GitResult(int exitCode, string stdOut, string stdErr)
        {
            ExitCode = exitCode;
            StdOut = stdOut;
            StdErr = stdErr;
        }
    }

    /// <summary>
    /// Runs git with an argv array - never through a shell, so no path or quote is ever re-parsed.
    /// Every call is bounded by a timeout; a hung git is killed rather than hanging the editor.
    /// </summary>
    public static class GitCli
    {
        /// <summary>Wall-clock ceiling per git call.</summary>
        public const int TimeoutMs = 15000;

        /// <summary>
        /// Walks up from <paramref name="startDirectory"/> looking for a <c>.git</c> directory or
        /// file (worktrees and submodules use a file). Returns the repository root's absolute path
        /// with '/' separators, or null when none is found.
        /// </summary>
        public static string? FindRepoRoot(string startDirectory)
        {
            var dir = new DirectoryInfo(startDirectory);
            while (dir != null)
            {
                string probe = Path.Combine(dir.FullName, ".git");
                if (Directory.Exists(probe) || File.Exists(probe))
                {
                    return dir.FullName.Replace('\\', '/');
                }
                dir = dir.Parent;
            }
            return null;
        }

        /// <summary>Runs one git command in <paramref name="workingDirectory"/>.</summary>
        /// <param name="workingDirectory">Directory git runs in.</param>
        /// <param name="args">Argv entries. Quoted with Windows CommandLineToArgvW rules by
        /// <see cref="QuoteArgument"/> - never handed to a shell, so nothing is re-parsed.</param>
        public static GitResult Run(string workingDirectory, params string[] args)
        {
            var argLine = new StringBuilder();
            for (int i = 0; i < args.Length; i++)
            {
                if (i > 0) { argLine.Append(' '); }
                argLine.Append(QuoteArgument(args[i]));
            }

            var psi = new ProcessStartInfo
            {
                FileName = "git",
                Arguments = argLine.ToString(),
                WorkingDirectory = workingDirectory,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8,
            };

            try
            {
                using (var proc = Process.Start(psi))
                {
                    if (proc == null) { return new GitResult(-1, string.Empty, "git could not be started."); }

                    // Both streams are drained concurrently: a sequential ReadToEnd deadlocks
                    // when the other pipe's buffer fills first.
                    System.Threading.Tasks.Task<string> so = proc.StandardOutput.ReadToEndAsync();
                    System.Threading.Tasks.Task<string> se = proc.StandardError.ReadToEndAsync();
                    if (!proc.WaitForExit(TimeoutMs))
                    {
                        try { proc.Kill(); } catch (InvalidOperationException) { }
                        return new GitResult(-1, string.Empty, "git timed out after " + TimeoutMs + " ms.");
                    }
                    return new GitResult(proc.ExitCode, so.Result, se.Result);
                }
            }
            catch (Exception e) when (e is System.ComponentModel.Win32Exception || e is IOException)
            {
                return new GitResult(-1, string.Empty, "git could not be started: " + e.Message);
            }
        }

        /// <summary>
        /// Quotes one argument by CommandLineToArgvW's rules: wrap in double quotes, double every
        /// backslash run that precedes a quote or the end, escape embedded quotes. Encoding this
        /// here is what makes passing paths with spaces safe without a shell.
        /// </summary>
        public static string QuoteArgument(string arg)
        {
            bool needsQuotes = arg.Length == 0;
            for (int i = 0; i < arg.Length && !needsQuotes; i++)
            {
                char c = arg[i];
                if (c == ' ' || c == '\t' || c == '"') { needsQuotes = true; }
            }
            if (!needsQuotes) { return arg; }

            var sb = new StringBuilder(arg.Length + 8);
            sb.Append('"');
            int backslashes = 0;
            for (int i = 0; i < arg.Length; i++)
            {
                char c = arg[i];
                if (c == '\\') { backslashes++; continue; }
                if (c == '"')
                {
                    sb.Append('\\', backslashes * 2 + 1);
                    sb.Append('"');
                }
                else
                {
                    sb.Append('\\', backslashes);
                    sb.Append(c);
                }
                backslashes = 0;
            }
            sb.Append('\\', backslashes * 2);
            sb.Append('"');
            return sb.ToString();
        }

        /// <summary>
        /// Reads one file's content at HEAD, or null when the path is not tracked there.
        /// <paramref name="repoRelativePath"/> must use '/' separators.
        /// </summary>
        public static string? ShowHead(string repoRoot, string repoRelativePath)
        {
            GitResult r = Run(repoRoot, "show", "HEAD:" + repoRelativePath);
            return r.Ok ? r.StdOut : null;
        }
    }
}
