// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

// CSAF GUID Warden - the always-on guard.
// Copyright (c) Corey Gallant and Stephanie Thomason. See LICENSE.txt.

using System;
using System.Threading.Tasks;
using CSAF.GuidWarden.Model;
using CSAF.GuidWarden.Scan;
using UnityEditor;
using UnityEngine;

namespace CSAF.GuidWarden.Guard
{
    /// <summary>
    /// Owns the background scan and the last result. The scan itself is pure filesystem code, so
    /// it runs on a worker thread and the editor never blocks - the checklist rule is zero work
    /// per frame, and this class does none at all until an asset event or a click asks for it.
    /// </summary>
    public static class GuardService
    {
        /// <summary>EditorPrefs key for the auto-guard toggle, namespaced to this product so it
        /// can never collide with a buyer's own keys.</summary>
        public const string AutoGuardPrefKey = "CSAF.GuidWarden.AutoGuard";

        private static ScanResult? _last;
        private static bool _running;
        private static bool _rerunQueued;

        /// <summary>Raised on the main thread when a scan completes.</summary>
        public static event Action<ScanResult>? ScanCompleted;

        /// <summary>The most recent completed result, or null before the first scan.</summary>
        public static ScanResult? LastResult { get { return _last; } }

        /// <summary>True while a scan is in flight.</summary>
        public static bool Running { get { return _running; } }

        /// <summary>Whether the import watcher triggers automatic scans. Defaults on - the guard
        /// IS the product; the toggle exists for enormous projects that prefer manual runs.</summary>
        public static bool AutoGuard
        {
            get { return EditorPrefs.GetBool(AutoGuardPrefKey, true); }
            set { EditorPrefs.SetBool(AutoGuardPrefKey, value); }
        }

        /// <summary>Starts a background scan of the project's <c>Assets</c> folder. When one is
        /// already running the request is coalesced into a single follow-up scan. Must be called
        /// from the main thread (menu items, asset postprocessors and windows all are).</summary>
        public static void RequestScan()
        {
            if (_running) { _rerunQueued = true; return; }
            _running = true;

            string assetsRoot = Application.dataPath; // main-thread only; captured here.

            // The completion is marshalled back through the main thread's synchronization
            // context - appending to EditorApplication.delayCall from a worker thread is not
            // documented thread-safe, so it is not done.
            Task.Run(() => MetaScanner.Scan(assetsRoot)).ContinueWith(
                t =>
                {
                    _running = false;
                    if (t.Exception != null)
                    {
                        Debug.LogError("[GUID Warden] Scan failed: " + t.Exception.GetBaseException().Message);
                    }
                    else if (t.Status == TaskStatus.RanToCompletion)
                    {
                        _last = t.Result;
                        Action<ScanResult>? handler = ScanCompleted;
                        if (handler != null) { handler(t.Result); }
                    }
                    if (_rerunQueued)
                    {
                        _rerunQueued = false;
                        RequestScan();
                    }
                },
                System.Threading.CancellationToken.None,
                TaskContinuationOptions.None,
                TaskScheduler.FromCurrentSynchronizationContext());
        }
    }

    /// <summary>
    /// Watches asset imports and re-scans after each batch (debounced through
    /// <see cref="GuardService"/>'s coalescing). This is the moment that matters: a lost meta is
    /// repairable only in the window between the file appearing and Unity's fresh GUID being
    /// committed to anyone else's machine.
    /// </summary>
    public sealed class ImportWatch : AssetPostprocessor
    {
        private static void OnPostprocessAllAssets(
            string[] importedAssets, string[] deletedAssets, string[] movedAssets, string[] movedFromAssetPaths)
        {
            if (!GuardService.AutoGuard) { return; }
            if (importedAssets.Length == 0 && deletedAssets.Length == 0 && movedAssets.Length == 0)
            {
                return;
            }
            GuardService.RequestScan();
        }
    }
}
