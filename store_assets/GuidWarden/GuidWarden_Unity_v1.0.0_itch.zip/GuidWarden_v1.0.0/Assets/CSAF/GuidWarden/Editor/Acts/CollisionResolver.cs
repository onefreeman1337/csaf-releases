// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

// CSAF GUID Warden - explicit duplicate-GUID resolution.
// Copyright (c) Corey Gallant and Stephanie Thomason. See LICENSE.txt.

using System;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using CSAF.GuidWarden.Model;

namespace CSAF.GuidWarden.Acts
{
    /// <summary>
    /// Resolves a duplicate-GUID collision the way Unity never does: explicitly, with a chosen
    /// winner and a receipt, instead of a silent re-mint that breaks references without a word.
    /// </summary>
    /// <remarks>
    /// The winner keeps the contested GUID - every existing reference keeps resolving to it. Each
    /// loser's <c>.meta</c> is rewritten with a fresh GUID via a byte-scoped edit: only the GUID
    /// characters change, every other byte is proven identical by comparison after the write.
    /// </remarks>
    public static class CollisionResolver
    {
        private static readonly Regex GuidLine = new Regex(
            @"^(guid:\s*)([0-9a-fA-F]{32})(\s*)$", RegexOptions.Multiline | RegexOptions.Compiled);

        /// <summary>Mints a fresh lowercase 32-hex GUID that collides with nothing in
        /// <paramref name="taken"/>.</summary>
        public static string FreshGuid(Func<string, bool> taken)
        {
            for (int attempt = 0; attempt < 64; attempt++)
            {
                string candidate = System.Guid.NewGuid().ToString("N").ToLowerInvariant();
                if (!taken(candidate)) { return candidate; }
            }
            throw new InvalidOperationException("Could not mint a non-colliding GUID in 64 attempts.");
        }

        /// <summary>
        /// Rewrites one loser's <c>.meta</c> with <paramref name="freshGuid"/>. Every byte outside
        /// the 32 GUID characters is verified unchanged after the write; on any mismatch the
        /// original bytes are restored and the receipt says so.
        /// </summary>
        /// <param name="projectRoot">Absolute project root.</param>
        /// <param name="loserMetaProjectRelative">Project-relative '/'-separated meta path.</param>
        /// <param name="expectedOldGuid">The contested GUID the file must currently carry -
        /// a mismatch means the file changed since the scan, and the act refuses.</param>
        /// <param name="freshGuid">The replacement 32-hex GUID.</param>
        public static ActReceipt ReMintGuid(
            string projectRoot, string loserMetaProjectRelative, string expectedOldGuid, string freshGuid)
        {
            string metaAbs = Path.Combine(projectRoot, loserMetaProjectRelative.Replace('/', Path.DirectorySeparatorChar));
            if (!File.Exists(metaAbs))
            {
                return new ActReceipt("remint-guid", loserMetaProjectRelative,
                    "Meta file is gone. Re-scan before resolving.", false, DateTime.UtcNow, null);
            }

            byte[] originalBytes = File.ReadAllBytes(metaAbs);
            string original = DecodeUtf8(originalBytes);

            Match m = GuidLine.Match(original);
            if (!m.Success)
            {
                return new ActReceipt("remint-guid", loserMetaProjectRelative,
                    "No guid line found - not a well-formed .meta. Nothing was written.",
                    false, DateTime.UtcNow, null);
            }
            string currentGuid = m.Groups[2].Value.ToLowerInvariant();
            if (!string.Equals(currentGuid, expectedOldGuid.ToLowerInvariant(), StringComparison.Ordinal))
            {
                return new ActReceipt("remint-guid", loserMetaProjectRelative,
                    "File carries guid " + currentGuid + " but the scan saw " + expectedOldGuid +
                    " - it changed since the scan. Re-scan and try again. Nothing was written.",
                    false, DateTime.UtcNow, null);
            }

            // The edit is EXACTLY the 32 characters of the guid group - splice by span, so the
            // verification below can prove byte identity outside it rather than trusting a regex.
            int guidStart = m.Groups[2].Index;
            string rewritten = original.Substring(0, guidStart)
                + freshGuid.ToLowerInvariant()
                + original.Substring(guidStart + 32);
            File.WriteAllText(metaAbs, rewritten, new UTF8Encoding(false));

            // Read back and prove: the disk carries the intended text, the new GUID parses out,
            // and everything outside the 32-character span is untouched (true by construction of
            // `rewritten`, so disk==rewritten IS the whole claim).
            string readBack = File.ReadAllText(metaAbs);
            string? verifiedGuid = Scan.MetaScanner.ReadGuid(metaAbs);
            bool ok = verifiedGuid == freshGuid.ToLowerInvariant()
                && string.Equals(readBack, rewritten, StringComparison.Ordinal);

            if (!ok)
            {
                File.WriteAllBytes(metaAbs, originalBytes);
                return new ActReceipt("remint-guid", loserMetaProjectRelative,
                    "Post-write verification failed; original bytes were restored.",
                    false, DateTime.UtcNow, null);
            }

            return new ActReceipt("remint-guid", loserMetaProjectRelative,
                string.Format(CultureInfo.InvariantCulture,
                    "guid {0} -> {1}. Every byte outside the GUID verified unchanged.",
                    currentGuid, freshGuid.ToLowerInvariant()),
                true, DateTime.UtcNow, null);
        }

        private static string DecodeUtf8(byte[] bytes)
        {
            // Metas are ASCII in practice; UTF-8 without BOM emission keeps the bytes stable.
            return new UTF8Encoding(false).GetString(bytes);
        }
    }
}
