// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

// CSAF GUID Warden - the scan engine.
// Copyright (c) Corey Gallant and Stephanie Thomason. See LICENSE.txt.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;
using CSAF.GuidWarden.Model;

namespace CSAF.GuidWarden.Scan
{
    /// <summary>
    /// Walks a folder tree the way Unity's asset database does and reports every decidable
    /// integrity defect: assets missing a <c>.meta</c>, orphaned <c>.meta</c> files, and one GUID
    /// claimed by two or more <c>.meta</c> files.
    /// </summary>
    /// <remarks>
    /// Pure filesystem code with no <c>AssetDatabase</c> dependency, so every rule is unit-tested
    /// against synthetic trees. Paths in results are relative to the scan root's PARENT (so a scan
    /// of <c>Assets</c> yields <c>Assets/...</c> paths), always '/'-separated.
    /// </remarks>
    public static class MetaScanner
    {
        private static readonly Regex GuidLine = new Regex(
            @"^guid:\s*([0-9a-fA-F]{32})\s*$", RegexOptions.Multiline | RegexOptions.Compiled);

        /// <summary>
        /// Scans <paramref name="rootAbsolute"/> (typically the project's <c>Assets</c> folder).
        /// </summary>
        /// <param name="rootAbsolute">Absolute path of the folder to scan. Must exist.</param>
        /// <param name="shouldCancel">Optional cancellation probe, polled between directories.
        /// A cancelled scan throws <see cref="OperationCanceledException"/> - it never returns a
        /// partial result that could read as a clean one.</param>
        public static ScanResult Scan(string rootAbsolute, Func<bool>? shouldCancel = null)
        {
            if (!Directory.Exists(rootAbsolute))
            {
                throw new DirectoryNotFoundException("Scan root does not exist: " + rootAbsolute);
            }

            var sw = Stopwatch.StartNew();
            string rootFull = Path.GetFullPath(rootAbsolute).Replace('\\', '/').TrimEnd('/');
            string parentFull = Path.GetDirectoryName(rootFull.Replace('/', Path.DirectorySeparatorChar)) is string p
                ? p.Replace('\\', '/')
                : rootFull;

            var issues = new List<MetaIssue>();
            var guidClaims = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
            int filesExamined = 0;
            int metasParsed = 0;

            var pending = new Stack<string>();
            pending.Push(rootFull);

            while (pending.Count > 0)
            {
                if (shouldCancel != null && shouldCancel())
                {
                    throw new OperationCanceledException("GUID Warden scan cancelled.");
                }

                string dir = pending.Pop();

                // Entries are gathered per directory so the meta<->asset pairing is local and cheap.
                var assetNames = new HashSet<string>(StringComparer.Ordinal);
                var metaNames = new List<string>();

                foreach (string entryAbs in Directory.EnumerateFileSystemEntries(dir))
                {
                    string entry = entryAbs.Replace('\\', '/');
                    string name = FileName(entry);
                    if (UnityIgnoreRules.IsHiddenName(name)) { continue; }

                    bool isDir = Directory.Exists(entry);
                    if (name.EndsWith(".meta", StringComparison.OrdinalIgnoreCase) && !isDir)
                    {
                        metaNames.Add(name);
                        continue;
                    }

                    filesExamined++;
                    assetNames.Add(name);
                    if (isDir) { pending.Push(entry); }
                }

                foreach (string name in assetNames)
                {
                    if (!File.Exists(dir + "/" + name + ".meta"))
                    {
                        string assetRel = Relative(parentFull, dir + "/" + name);
                        issues.Add(new MetaIssue(
                            IssueKind.MissingMeta, assetRel, assetRel + ".meta",
                            null, Directory.Exists(dir + "/" + name)));
                    }
                }

                foreach (string metaName in metaNames)
                {
                    string metaAbs = dir + "/" + metaName;
                    string assetName = metaName.Substring(0, metaName.Length - ".meta".Length);
                    string metaRel = Relative(parentFull, metaAbs);

                    metasParsed++;
                    string? guid = ReadGuid(metaAbs);
                    if (guid != null)
                    {
                        if (!guidClaims.TryGetValue(guid, out List<string>? claimants) || claimants == null)
                        {
                            claimants = new List<string>();
                            guidClaims[guid] = claimants;
                        }
                        claimants.Add(metaRel);
                    }

                    // A meta for a hidden asset name is an orphan too: Unity will not import the
                    // asset, so the meta serves nothing.
                    bool assetPresent = assetName.Length > 0
                        && !UnityIgnoreRules.IsHiddenName(assetName)
                        && (File.Exists(dir + "/" + assetName) || Directory.Exists(dir + "/" + assetName));
                    if (!assetPresent)
                    {
                        issues.Add(new MetaIssue(
                            IssueKind.OrphanMeta,
                            Relative(parentFull, dir + "/" + assetName),
                            metaRel, guid, false));
                    }
                }
            }

            var duplicates = new List<DuplicateGuidGroup>();
            foreach (KeyValuePair<string, List<string>> claim in guidClaims)
            {
                if (claim.Value.Count > 1)
                {
                    claim.Value.Sort(StringComparer.Ordinal);
                    duplicates.Add(new DuplicateGuidGroup(claim.Key.ToLowerInvariant(), claim.Value));
                }
            }
            duplicates.Sort((a, b) => string.CompareOrdinal(a.Guid, b.Guid));
            issues.Sort((a, b) => string.CompareOrdinal(a.MetaPath, b.MetaPath));

            sw.Stop();
            return new ScanResult(filesExamined, metasParsed, issues, duplicates, sw.Elapsed, DateTime.UtcNow);
        }

        /// <summary>Reads the 32-hex GUID out of one <c>.meta</c> file, or null when the file has
        /// none (a malformed meta - itself worth surfacing, which the orphan path does).</summary>
        public static string? ReadGuid(string metaAbsolutePath)
        {
            // Metas are small YAML; reading the whole file is cheaper than line-buffering logic.
            string text;
            try { text = File.ReadAllText(metaAbsolutePath); }
            catch (IOException) { return null; }
            catch (UnauthorizedAccessException) { return null; }

            Match m = GuidLine.Match(text);
            return m.Success ? m.Groups[1].Value.ToLowerInvariant() : null;
        }

        private static string FileName(string path)
        {
            int slash = path.LastIndexOf('/');
            return slash < 0 ? path : path.Substring(slash + 1);
        }

        private static string Relative(string parentFull, string absolute)
        {
            string abs = absolute.Replace('\\', '/');
            if (abs.StartsWith(parentFull + "/", StringComparison.OrdinalIgnoreCase))
            {
                return abs.Substring(parentFull.Length + 1);
            }
            return abs;
        }
    }
}
