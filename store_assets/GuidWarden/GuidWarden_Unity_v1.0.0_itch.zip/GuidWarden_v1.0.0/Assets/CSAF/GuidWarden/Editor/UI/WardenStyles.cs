// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

// CSAF GUID Warden - visual language.
// Copyright (c) Corey Gallant and Stephanie Thomason. See LICENSE.txt.

using CSAF.GuidWarden.Model;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace CSAF.GuidWarden.UI
{
    /// <summary>
    /// The window's whole visual language, defined in C#.
    ///
    /// No USS file and no <c>Resources/</c> folder: a Resources folder inside a store package is
    /// loaded into every build of every project that imports it, forever. Inline styles cost a
    /// little verbosity here and cost the buyer nothing at all.
    /// </summary>
    internal static class WardenStyles
    {
        public static bool Dark { get { return EditorGUIUtility.isProSkin; } }

        public static Color Canvas { get { return Dark ? new Color(0.125f, 0.133f, 0.157f) : new Color(0.925f, 0.929f, 0.937f); } }
        public static Color Panel { get { return Dark ? new Color(0.161f, 0.173f, 0.200f) : new Color(0.976f, 0.976f, 0.980f); } }
        public static Color PanelDeep { get { return Dark ? new Color(0.141f, 0.149f, 0.176f) : new Color(0.949f, 0.953f, 0.961f); } }
        public static Color Line { get { return Dark ? new Color(0.243f, 0.259f, 0.298f) : new Color(0.820f, 0.831f, 0.851f); } }
        public static Color Ink { get { return Dark ? new Color(0.902f, 0.914f, 0.937f) : new Color(0.106f, 0.118f, 0.137f); } }
        public static Color Muted { get { return Dark ? new Color(0.573f, 0.600f, 0.651f) : new Color(0.412f, 0.435f, 0.478f); } }

        /// <summary>Healthy green - the all-clear header and passing chips.</summary>
        public static Color Healthy { get { return new Color(0.243f, 0.639f, 0.478f); } }
        /// <summary>Missing meta - amber. Repairable, urgent, not yet a loss.</summary>
        public static Color Missing { get { return new Color(0.902f, 0.702f, 0.259f); } }
        /// <summary>Orphaned meta - slate. Litter, not danger.</summary>
        public static Color Orphan { get { return new Color(0.522f, 0.565f, 0.659f); } }
        /// <summary>Duplicate GUID - the red of silent reference breakage.</summary>
        public static Color Duplicate { get { return new Color(0.847f, 0.310f, 0.408f); } }
        /// <summary>Interactive accent.</summary>
        public static Color Accent { get { return new Color(0.357f, 0.561f, 0.902f); } }

        public static Color For(IssueKind kind)
        {
            switch (kind)
            {
                case IssueKind.MissingMeta: return Missing;
                case IssueKind.OrphanMeta: return Orphan;
                default: return Duplicate;
            }
        }

        public static void Border(VisualElement e, Color c, float width, float radius)
        {
            e.style.borderTopWidth = width;
            e.style.borderRightWidth = width;
            e.style.borderBottomWidth = width;
            e.style.borderLeftWidth = width;
            e.style.borderTopColor = c;
            e.style.borderRightColor = c;
            e.style.borderBottomColor = c;
            e.style.borderLeftColor = c;
            e.style.borderTopLeftRadius = radius;
            e.style.borderTopRightRadius = radius;
            e.style.borderBottomLeftRadius = radius;
            e.style.borderBottomRightRadius = radius;
        }

        public static void Pad(VisualElement e, float t, float r, float b, float l)
        {
            e.style.paddingTop = t;
            e.style.paddingRight = r;
            e.style.paddingBottom = b;
            e.style.paddingLeft = l;
        }

        public static Label Text(string s, int size, Color color, FontStyle style = FontStyle.Normal)
        {
            var l = new Label(s);
            l.style.fontSize = size;
            l.style.color = color;
            l.style.unityFontStyleAndWeight = style;
            l.style.whiteSpace = WhiteSpace.Normal;
            return l;
        }

        /// <summary>A small count chip - the readable unit the header is built from.</summary>
        public static VisualElement Chip(string text, Color color)
        {
            var chip = new VisualElement();
            chip.style.flexDirection = FlexDirection.Row;
            chip.style.alignItems = Align.Center;
            chip.style.backgroundColor = new Color(color.r, color.g, color.b, Dark ? 0.18f : 0.14f);
            Border(chip, new Color(color.r, color.g, color.b, 0.55f), 1f, 9f);
            Pad(chip, 1f, 7f, 1f, 7f);
            chip.style.marginRight = 4f;

            var label = Text(text, 10, color, FontStyle.Bold);
            chip.Add(label);
            return chip;
        }

        /// <summary>An issue card: severity bar on the left, content column on the right.</summary>
        public static VisualElement Card(Color severity, out VisualElement content)
        {
            var card = new VisualElement();
            card.style.flexDirection = FlexDirection.Row;
            card.style.backgroundColor = Panel;
            Border(card, Line, 1f, 6f);
            card.style.marginBottom = 6f;
            card.style.overflow = Overflow.Hidden;

            var bar = new VisualElement();
            bar.style.width = 4f;
            bar.style.backgroundColor = severity;
            bar.style.flexShrink = 0f;
            card.Add(bar);

            content = new VisualElement();
            content.style.flexGrow = 1f;
            Pad(content, 8f, 10f, 8f, 10f);
            card.Add(content);
            return card;
        }

        /// <summary>A compact styled action button.</summary>
        public static Button ActionButton(string text, Color tint, System.Action onClick)
        {
            var b = new Button(onClick) { text = text };
            b.style.fontSize = 11;
            b.style.unityFontStyleAndWeight = FontStyle.Bold;
            b.style.color = Ink;
            b.style.backgroundColor = new Color(tint.r, tint.g, tint.b, Dark ? 0.22f : 0.16f);
            Border(b, new Color(tint.r, tint.g, tint.b, 0.6f), 1f, 5f);
            Pad(b, 3f, 10f, 3f, 10f);
            b.style.marginRight = 6f;
            b.style.marginTop = 6f;
            // Buttons size to their text: inside a column flex container the default stretch
            // turns every action into a full-width bar, which reads as a broken layout.
            b.style.alignSelf = Align.FlexStart;
            return b;
        }

        /// <summary>Monospace path label that can be clicked to ping the asset.</summary>
        public static Label PathLabel(string path)
        {
            var l = Text(path, 11, Ink);
            l.style.unityFontStyleAndWeight = FontStyle.Normal;
            l.style.marginTop = 1f;
            return l;
        }
    }
}
