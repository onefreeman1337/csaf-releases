// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

// CSAF GUID Warden - Unity's hidden-asset rules, encoded once and unit-tested.
// Copyright (c) Corey Gallant and Stephanie Thomason. See LICENSE.txt.

using System;

namespace CSAF.GuidWarden.Scan
{
    /// <summary>
    /// The rules Unity uses to decide a file or folder is NOT an asset and needs no <c>.meta</c>.
    /// </summary>
    /// <remarks>
    /// Mirrors the "Hidden assets" list in Unity's Special-folders documentation: names starting
    /// with '.', names ending with '~', the name <c>cvs</c> (any case), and files with the
    /// extension <c>.tmp</c>. A scanner that gets one of these wrong reports false missing-meta
    /// findings on files Unity never imports, so these rules live in one place and are unit-tested
    /// in both directions.
    /// </remarks>
    public static class UnityIgnoreRules
    {
        /// <summary>True when a single file or folder NAME (not a path) is hidden from the
        /// asset database by Unity's rules.</summary>
        public static bool IsHiddenName(string name)
        {
            if (name.Length == 0) { return true; }
            if (name[0] == '.') { return true; }
            if (name[name.Length - 1] == '~') { return true; }
            if (string.Equals(name, "cvs", StringComparison.OrdinalIgnoreCase)) { return true; }
            if (name.EndsWith(".tmp", StringComparison.OrdinalIgnoreCase)) { return true; }
            return false;
        }

        /// <summary>True when any segment of a '/'-separated relative path is hidden - Unity
        /// ignores the entire subtree under a hidden folder.</summary>
        public static bool IsHiddenPath(string relativePath)
        {
            int start = 0;
            while (start < relativePath.Length)
            {
                int slash = relativePath.IndexOf('/', start);
                int end = slash < 0 ? relativePath.Length : slash;
                if (end > start && IsHiddenName(relativePath.Substring(start, end - start)))
                {
                    return true;
                }
                start = end + 1;
            }
            return false;
        }
    }
}
