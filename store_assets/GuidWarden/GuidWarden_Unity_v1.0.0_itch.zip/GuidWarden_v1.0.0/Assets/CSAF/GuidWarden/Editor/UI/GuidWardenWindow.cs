// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

// CSAF GUID Warden - the integrity dashboard.
// Copyright (c) Corey Gallant and Stephanie Thomason. See LICENSE.txt.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using CSAF.GuidWarden.Acts;
using CSAF.GuidWarden.Guard;
using CSAF.GuidWarden.Model;
using CSAF.GuidWarden.Scan;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace CSAF.GuidWarden.UI
{
    /// <summary>
    /// The GUID Warden dashboard: health header, one designed card per finding with its repair
    /// act inline, the git-hygiene panel, and the receipt journal. Everything is rebuilt on state
    /// changes only - the window does zero work per frame.
    /// </summary>
    public sealed class GuidWardenWindow : EditorWindow
    {
        private readonly List<ActReceipt> _receipts = new List<ActReceipt>();
        private readonly Dictionary<string, IReadOnlyList<string>> _referencers =
            new Dictionary<string, IReadOnlyList<string>>(StringComparer.Ordinal);

        /// <summary>Opens (or focuses) the window.</summary>
        [MenuItem("Tools/CSAF/GUID Warden/Open Window", false, 100)]
        [MenuItem("Window/CSAF/GUID Warden")]
        public static void Open()
        {
            var w = GetWindow<GuidWardenWindow>();
            w.titleContent = new GUIContent("GUID Warden");
            w.minSize = new Vector2(560f, 420f);
            w.Show();
        }

        private void OnEnable()
        {
            // Set here as well as in Open(): a window restored by layout or opened through
            // GetWindow elsewhere would otherwise show the class name in its dock tab.
            titleContent = new GUIContent("GUID Warden");
            GuardService.ScanCompleted += OnScanCompleted;
            Rebuild();
            if (GuardService.LastResult == null) { GuardService.RequestScan(); }
        }

        private void OnDisable()
        {
            GuardService.ScanCompleted -= OnScanCompleted;
        }

        private void OnScanCompleted(ScanResult result)
        {
            _referencers.Clear();
            Rebuild();
        }

        private string ProjectRoot
        {
            get
            {
                string data = Application.dataPath.Replace('\\', '/');
                int slash = data.LastIndexOf('/');
                return slash > 0 ? data.Substring(0, slash) : data;
            }
        }

        private void Act(Func<ActReceipt> act, bool refreshAssets)
        {
            ActReceipt receipt = act();
            _receipts.Insert(0, receipt);
            if (receipt.Ok && refreshAssets) { AssetDatabase.Refresh(); }
            GuardService.RequestScan();
            Rebuild();
        }

        private void Rebuild()
        {
            rootVisualElement.Clear();
            rootVisualElement.style.backgroundColor = WardenStyles.Canvas;

            var scroll = new ScrollView(ScrollViewMode.Vertical);
            WardenStyles.Pad(scroll.contentContainer, 12f, 14f, 20f, 14f);
            rootVisualElement.Add(scroll);

            BuildHeader(scroll.contentContainer);

            ScanResult? r = GuardService.LastResult;
            if (r != null)
            {
                BuildStats(scroll.contentContainer, r);
                BuildIssues(scroll.contentContainer, r);
            }
            else
            {
                var waiting = WardenStyles.Text(
                    GuardService.Running ? "Scanning…" : "No scan yet. Press Scan.",
                    12, WardenStyles.Muted);
                waiting.style.marginTop = 10f;
                scroll.contentContainer.Add(waiting);
            }

            BuildHygiene(scroll.contentContainer);
            BuildReceipts(scroll.contentContainer);
        }

        private void BuildHeader(VisualElement parent)
        {
            var row = new VisualElement();
            row.style.flexDirection = FlexDirection.Row;
            row.style.alignItems = Align.Center;
            parent.Add(row);

            var titleCol = new VisualElement();
            titleCol.style.flexGrow = 1f;
            row.Add(titleCol);

            var title = WardenStyles.Text("GUID WARDEN", 19, WardenStyles.Ink, FontStyle.Bold);
            title.style.letterSpacing = 2f;
            titleCol.Add(title);
            titleCol.Add(WardenStyles.Text(
                "Meta and GUID integrity, guarded before references break.", 11, WardenStyles.Muted));

            var guardToggle = new Toggle("Auto-guard") { value = GuardService.AutoGuard };
            guardToggle.style.color = WardenStyles.Muted;
            guardToggle.RegisterValueChangedCallback(evt => { GuardService.AutoGuard = evt.newValue; });
            row.Add(guardToggle);

            var scanBtn = WardenStyles.ActionButton(
                GuardService.Running ? "Scanning…" : "Scan now", WardenStyles.Accent,
                () => { GuardService.RequestScan(); Rebuild(); });
            scanBtn.SetEnabled(!GuardService.Running);
            scanBtn.style.marginTop = 0f;
            row.Add(scanBtn);
        }

        private void BuildStats(VisualElement parent, ScanResult r)
        {
            int missing = 0, orphans = 0;
            for (int i = 0; i < r.Issues.Count; i++)
            {
                if (r.Issues[i].Kind == IssueKind.MissingMeta) { missing++; } else { orphans++; }
            }

            var panel = new VisualElement();
            panel.style.backgroundColor = WardenStyles.Panel;
            WardenStyles.Border(panel, WardenStyles.Line, 1f, 8f);
            WardenStyles.Pad(panel, 10f, 12f, 10f, 12f);
            panel.style.marginTop = 10f;
            parent.Add(panel);

            var headline = new VisualElement();
            headline.style.flexDirection = FlexDirection.Row;
            headline.style.alignItems = Align.Center;
            panel.Add(headline);

            Color verdictColor = r.Clean ? WardenStyles.Healthy : WardenStyles.Duplicate;
            var count = WardenStyles.Text(
                r.Clean ? "ALL CLEAR" : r.IssueCount.ToString(CultureInfo.InvariantCulture) +
                    (r.IssueCount == 1 ? " ISSUE" : " ISSUES"),
                17, verdictColor, FontStyle.Bold);
            headline.Add(count);

            var detail = WardenStyles.Text(
                string.Format(CultureInfo.InvariantCulture,
                    "   {0} entries · {1} metas · {2:0} ms · {3:HH:mm:ss} UTC",
                    r.FilesExamined, r.MetasParsed, r.Duration.TotalMilliseconds, r.AtUtc),
                10, WardenStyles.Muted);
            headline.Add(detail);

            var chips = new VisualElement();
            chips.style.flexDirection = FlexDirection.Row;
            chips.style.marginTop = 6f;
            panel.Add(chips);
            chips.Add(WardenStyles.Chip(missing + " missing meta", missing > 0 ? WardenStyles.Missing : WardenStyles.Muted));
            chips.Add(WardenStyles.Chip(orphans + " orphaned", orphans > 0 ? WardenStyles.Orphan : WardenStyles.Muted));
            chips.Add(WardenStyles.Chip(r.Duplicates.Count + " GUID collisions",
                r.Duplicates.Count > 0 ? WardenStyles.Duplicate : WardenStyles.Muted));
        }

        private void BuildIssues(VisualElement parent, ScanResult r)
        {
            if (r.IssueCount == 0) { return; }

            var section = WardenStyles.Text("FINDINGS", 11, WardenStyles.Muted, FontStyle.Bold);
            section.style.marginTop = 14f;
            section.style.letterSpacing = 1.5f;
            parent.Add(section);

            for (int i = 0; i < r.Duplicates.Count; i++) { BuildDuplicateCard(parent, r.Duplicates[i]); }
            for (int i = 0; i < r.Issues.Count; i++) { BuildIssueCard(parent, r.Issues[i]); }
        }

        private void BuildIssueCard(VisualElement parent, MetaIssue issue)
        {
            VisualElement card = WardenStyles.Card(WardenStyles.For(issue.Kind), out VisualElement content);
            parent.Add(card);

            if (issue.Kind == IssueKind.MissingMeta)
            {
                content.Add(WardenStyles.Text(
                    (issue.IsFolder ? "FOLDER MISSING .META" : "ASSET MISSING .META"),
                    11, WardenStyles.Missing, FontStyle.Bold));
                content.Add(WardenStyles.PathLabel(issue.AssetPath));
                content.Add(WardenStyles.Text(
                    "Unity will mint a fresh GUID on the next refresh - existing references then break silently. " +
                    "If the meta was ever committed, restore it and the references survive.",
                    10, WardenStyles.Muted));

                var actions = new VisualElement();
                actions.style.flexDirection = FlexDirection.Row;
                content.Add(actions);
                actions.Add(WardenStyles.ActionButton("Restore .meta from git", WardenStyles.Healthy,
                    () => Act(() => MetaRepair.RestoreMetaFromGit(ProjectRoot, issue.AssetPath), true)));
                actions.Add(WardenStyles.ActionButton("Accept fresh GUID", WardenStyles.Missing,
                    () => Act(() =>
                    {
                        AssetDatabase.ImportAsset(issue.AssetPath);
                        string? minted = MetaScanner.ReadGuid(
                            Path.Combine(ProjectRoot, issue.MetaPath.Replace('/', Path.DirectorySeparatorChar)));
                        return new ActReceipt("accept-fresh-guid", issue.AssetPath,
                            minted != null
                                ? "Unity minted guid " + minted + " - an explicit decision, on the record."
                                : "Import requested; no meta reads back yet. Re-scan.",
                            minted != null, DateTime.UtcNow, null);
                    }, false)));
            }
            else
            {
                content.Add(WardenStyles.Text("ORPHANED .META", 11, WardenStyles.Orphan, FontStyle.Bold));
                content.Add(WardenStyles.PathLabel(issue.MetaPath));
                content.Add(WardenStyles.Text(
                    "Its asset is gone" + (issue.Guid != null ? " (guid " + issue.Guid + ")" : "") +
                    ". Committed orphans make every teammate import a ghost. Deletion keeps a byte-exact backup.",
                    10, WardenStyles.Muted));

                var actions = new VisualElement();
                actions.style.flexDirection = FlexDirection.Row;
                content.Add(actions);
                actions.Add(WardenStyles.ActionButton("Delete (backed up)", WardenStyles.Orphan,
                    () => Act(() => MetaRepair.DeleteOrphanMeta(ProjectRoot, issue.MetaPath), true)));
            }
        }

        private void BuildDuplicateCard(VisualElement parent, DuplicateGuidGroup group)
        {
            VisualElement card = WardenStyles.Card(WardenStyles.Duplicate, out VisualElement content);
            parent.Add(card);

            content.Add(WardenStyles.Text("ONE GUID, " + group.ClaimantMetaPaths.Count + " CLAIMANTS",
                11, WardenStyles.Duplicate, FontStyle.Bold));
            content.Add(WardenStyles.PathLabel("guid " + group.Guid));
            content.Add(WardenStyles.Text(
                "Unity resolves this silently by re-minting one side, breaking its references without a word. " +
                "Choose which claimant keeps the GUID; every other claimant gets a fresh one, explicitly.",
                10, WardenStyles.Muted));

            if (_referencers.TryGetValue(group.Guid, out IReadOnlyList<string>? refs) && refs != null)
            {
                var refPanel = new VisualElement();
                refPanel.style.backgroundColor = WardenStyles.PanelDeep;
                WardenStyles.Border(refPanel, WardenStyles.Line, 1f, 4f);
                WardenStyles.Pad(refPanel, 6f, 8f, 6f, 8f);
                refPanel.style.marginTop = 6f;
                content.Add(refPanel);
                refPanel.Add(WardenStyles.Text(
                    refs.Count == 0
                        ? "No text-serialized asset references this GUID."
                        : refs.Count + " referencing asset(s) - these all currently resolve to whichever claimant wins:",
                    10, WardenStyles.Muted, FontStyle.Bold));
                for (int i = 0; i < refs.Count && i < 12; i++)
                {
                    refPanel.Add(WardenStyles.PathLabel(refs[i]));
                }
                if (refs.Count > 12)
                {
                    refPanel.Add(WardenStyles.Text("… and " + (refs.Count - 12) + " more", 10, WardenStyles.Muted));
                }
            }

            var actions = new VisualElement();
            actions.style.flexDirection = FlexDirection.Row;
            actions.style.flexWrap = Wrap.Wrap;
            content.Add(actions);

            for (int i = 0; i < group.ClaimantMetaPaths.Count; i++)
            {
                string winner = group.ClaimantMetaPaths[i];
                actions.Add(WardenStyles.ActionButton("Keep " + AssetOf(winner), WardenStyles.Healthy,
                    () => ResolveCollision(group, winner)));
            }
            actions.Add(WardenStyles.ActionButton("Show referencers", WardenStyles.Accent,
                () => LoadReferencers(group.Guid)));
        }

        private static string AssetOf(string metaPath)
        {
            string asset = metaPath.EndsWith(".meta", StringComparison.OrdinalIgnoreCase)
                ? metaPath.Substring(0, metaPath.Length - 5)
                : metaPath;
            int slash = asset.LastIndexOf('/');
            return slash < 0 ? asset : asset.Substring(slash + 1);
        }

        private void ResolveCollision(DuplicateGuidGroup group, string winnerMetaPath)
        {
            var existing = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            ScanResult? last = GuardService.LastResult;
            if (last != null)
            {
                // Freshly minted GUIDs must not collide with anything the scan saw.
                foreach (DuplicateGuidGroup g in last.Duplicates) { existing.Add(g.Guid); }
            }

            for (int i = 0; i < group.ClaimantMetaPaths.Count; i++)
            {
                string loser = group.ClaimantMetaPaths[i];
                if (string.Equals(loser, winnerMetaPath, StringComparison.Ordinal)) { continue; }
                string fresh = CollisionResolver.FreshGuid(g => existing.Contains(g));
                existing.Add(fresh);
                Act(() => CollisionResolver.ReMintGuid(ProjectRoot, loser, group.Guid, fresh), false);
            }
            AssetDatabase.Refresh();
        }

        private void LoadReferencers(string guid)
        {
            // Scoped, on-demand, main-thread with a progress bar: this reads file contents, so it
            // is the one deliberately synchronous operation - and it is cancellable.
            try
            {
                EditorUtility.DisplayProgressBar("GUID Warden", "Searching text-serialized assets…", 0.4f);
                _referencers[guid] = ReferenceIndex.FindReferencers(Application.dataPath, guid);
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
            Rebuild();
        }

        private void BuildHygiene(VisualElement parent)
        {
            var section = WardenStyles.Text("GIT HYGIENE", 11, WardenStyles.Muted, FontStyle.Bold);
            section.style.marginTop = 16f;
            section.style.letterSpacing = 1.5f;
            parent.Add(section);

            HygieneStatus st = GitHygiene.Check(ProjectRoot);

            var panel = new VisualElement();
            panel.style.backgroundColor = WardenStyles.Panel;
            WardenStyles.Border(panel, WardenStyles.Line, 1f, 8f);
            WardenStyles.Pad(panel, 8f, 12f, 8f, 12f);
            panel.style.marginTop = 6f;
            parent.Add(panel);

            if (st.RepoRoot == null)
            {
                panel.Add(WardenStyles.Text(
                    "No git repository found above this project. The commit guard needs one; the " +
                    "scanner and repairs above work regardless.", 11, WardenStyles.Muted));
                var copyBtn = WardenStyles.ActionButton("Copy hook text anyway", WardenStyles.Accent,
                    () => { EditorGUIUtility.systemCopyBuffer = GitHygiene.HookText; });
                panel.Add(copyBtn);
                return;
            }

            panel.Add(HygieneRow(
                "Smart-merge rules (.gitattributes)",
                st.Attributes == HookState.Ours,
                st.Attributes == HookState.Foreign
                    ? "a unityyamlmerge rule by someone else exists - left untouched"
                    : "scenes, prefabs and assets merge structurally instead of clobbering",
                st.Attributes == HookState.Absent
                    ? WardenStyles.ActionButton("Install", WardenStyles.Healthy,
                        () => Act(() => GitHygiene.InstallAttributes(ProjectRoot), false))
                    : null));

            panel.Add(HygieneRow(
                "UnityYAMLMerge driver (repo-local)",
                st.MergeDriverConfigured,
                "points git at this machine's UnityYAMLMerge",
                st.MergeDriverConfigured
                    ? null
                    : WardenStyles.ActionButton("Configure", WardenStyles.Healthy,
                        () => Act(() => GitHygiene.ConfigureMergeDriver(ProjectRoot, YamlMergePath()), false))));

            panel.Add(HygieneRow(
                "Pre-commit guard",
                st.Hook == HookState.Ours,
                st.Hook == HookState.Foreign
                    ? "a foreign pre-commit hook exists - left untouched; copy ours and merge by hand"
                    : "refuses commits that would break references (bypass: git commit --no-verify)",
                st.Hook == HookState.Absent
                    ? WardenStyles.ActionButton("Install", WardenStyles.Healthy,
                        () => Act(() => GitHygiene.InstallHook(ProjectRoot), false))
                    : null));

            var copy = WardenStyles.ActionButton("Copy hook text", WardenStyles.Accent,
                () => { EditorGUIUtility.systemCopyBuffer = GitHygiene.HookText; });
            panel.Add(copy);
        }

        private static VisualElement HygieneRow(string title, bool ok, string detail, Button? action)
        {
            var row = new VisualElement();
            row.style.flexDirection = FlexDirection.Row;
            row.style.alignItems = Align.Center;
            row.style.marginBottom = 4f;

            row.Add(WardenStyles.Chip(ok ? "OK" : "—", ok ? WardenStyles.Healthy : WardenStyles.Muted));

            var col = new VisualElement();
            col.style.flexGrow = 1f;
            row.Add(col);
            col.Add(WardenStyles.Text(title, 11, WardenStyles.Ink, FontStyle.Bold));
            col.Add(WardenStyles.Text(detail, 10, WardenStyles.Muted));

            if (action != null)
            {
                action.style.marginTop = 0f;
                row.Add(action);
            }
            return row;
        }

        private static string YamlMergePath()
        {
            string tools = EditorApplication.applicationContentsPath + "/Tools/UnityYAMLMerge";
            return File.Exists(tools + ".exe") ? tools + ".exe" : tools;
        }

        private void BuildReceipts(VisualElement parent)
        {
            if (_receipts.Count == 0) { return; }

            var section = WardenStyles.Text("RECEIPTS - what was actually done, verified",
                11, WardenStyles.Muted, FontStyle.Bold);
            section.style.marginTop = 16f;
            section.style.letterSpacing = 1.5f;
            parent.Add(section);

            for (int i = 0; i < _receipts.Count && i < 20; i++)
            {
                ActReceipt r = _receipts[i];
                VisualElement card = WardenStyles.Card(
                    r.Ok ? WardenStyles.Healthy : WardenStyles.Duplicate, out VisualElement content);
                card.style.marginTop = i == 0 ? 6f : 0f;
                parent.Add(card);

                var head = new VisualElement();
                head.style.flexDirection = FlexDirection.Row;
                content.Add(head);
                head.Add(WardenStyles.Chip(r.Ok ? "DONE" : "REFUSED",
                    r.Ok ? WardenStyles.Healthy : WardenStyles.Duplicate));
                head.Add(WardenStyles.Text(r.Act + "  ·  " + r.Path, 11, WardenStyles.Ink, FontStyle.Bold));

                content.Add(WardenStyles.Text(r.Detail, 10, WardenStyles.Muted));

                if (r.BackupPath != null && r.Ok && r.Act == "delete-orphan-meta")
                {
                    string metaRel = r.Path;
                    string backup = r.BackupPath;
                    content.Add(WardenStyles.ActionButton("Restore from backup", WardenStyles.Accent,
                        () => Act(() => MetaRepair.RestoreFromBackup(ProjectRoot, metaRel, backup), true)));
                }
            }
        }
    }
}
