// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

// CSAF GUID Warden - integrity model.
// Copyright (c) Corey Gallant and Stephanie Thomason. See LICENSE.txt.

using System;
using System.Collections.Generic;

namespace CSAF.GuidWarden.Model
{
    /// <summary>The three decidable integrity defects this tool guards against.</summary>
    public enum IssueKind
    {
        /// <summary>An asset (file or folder) Unity will import has no <c>.meta</c> beside it.
        /// On the next refresh Unity mints a FRESH GUID, and every reference that pointed at the
        /// old one breaks silently.</summary>
        MissingMeta,

        /// <summary>A <c>.meta</c> file whose asset is gone. Harmless until it is committed, at
        /// which point every teammate imports a ghost and merges fight over it.</summary>
        OrphanMeta,

        /// <summary>One GUID claimed by two or more <c>.meta</c> files. Unity resolves this by
        /// silently re-minting one of them - breaking references without a word.</summary>
        DuplicateGuid,
    }

    /// <summary>A single missing-meta or orphan-meta finding, in project-relative paths.</summary>
    public sealed class MetaIssue
    {
        /// <summary>Which defect this is. Never <see cref="IssueKind.DuplicateGuid"/> - those are
        /// modelled as <see cref="DuplicateGuidGroup"/> because they span files.</summary>
        public IssueKind Kind { get; }

        /// <summary>Project-relative path of the asset ('/' separators). For an orphan this is the
        /// path the missing asset WOULD have had.</summary>
        public string AssetPath { get; }

        /// <summary>Project-relative path of the <c>.meta</c> file ('/' separators). For a missing
        /// meta this is the path the meta SHOULD have had.</summary>
        public string MetaPath { get; }

        /// <summary>The GUID involved, when one exists (orphans have one; missing metas do not).</summary>
        public string? Guid { get; }

        /// <summary>True when <see cref="AssetPath"/> is a folder.</summary>
        public bool IsFolder { get; }

        /// <summary>Creates one finding. Paths must already be project-relative with '/' separators.</summary>
        public MetaIssue(IssueKind kind, string assetPath, string metaPath, string? guid, bool isFolder)
        {
            Kind = kind;
            AssetPath = assetPath;
            MetaPath = metaPath;
            Guid = guid;
            IsFolder = isFolder;
        }
    }

    /// <summary>One GUID claimed by two or more <c>.meta</c> files.</summary>
    public sealed class DuplicateGuidGroup
    {
        /// <summary>The contested 32-hex GUID.</summary>
        public string Guid { get; }

        /// <summary>Project-relative <c>.meta</c> paths that all declare <see cref="Guid"/>,
        /// in scan order.</summary>
        public IReadOnlyList<string> ClaimantMetaPaths { get; }

        /// <summary>Creates one collision group. At least two claimants are required.</summary>
        public DuplicateGuidGroup(string guid, IReadOnlyList<string> claimantMetaPaths)
        {
            if (claimantMetaPaths.Count < 2)
            {
                throw new ArgumentException("A duplicate group needs at least two claimants.", nameof(claimantMetaPaths));
            }
            Guid = guid;
            ClaimantMetaPaths = claimantMetaPaths;
        }
    }

    /// <summary>Everything one scan measured. Counts are of work performed, never inferred -
    /// a result with zero <see cref="FilesExamined"/> is a scan that did not happen.</summary>
    public sealed class ScanResult
    {
        /// <summary>Files and folders actually walked (excluding ones Unity ignores).</summary>
        public int FilesExamined { get; }

        /// <summary><c>.meta</c> files actually parsed.</summary>
        public int MetasParsed { get; }

        /// <summary>Missing-meta and orphan-meta findings.</summary>
        public IReadOnlyList<MetaIssue> Issues { get; }

        /// <summary>Duplicate-GUID findings.</summary>
        public IReadOnlyList<DuplicateGuidGroup> Duplicates { get; }

        /// <summary>Wall-clock duration of the scan.</summary>
        public TimeSpan Duration { get; }

        /// <summary>When the scan finished (UTC).</summary>
        public DateTime AtUtc { get; }

        /// <summary>Total number of findings across both lists.</summary>
        public int IssueCount { get { return Issues.Count + Duplicates.Count; } }

        /// <summary>True when the scan examined at least one file and found nothing wrong.</summary>
        public bool Clean { get { return FilesExamined > 0 && IssueCount == 0; } }

        /// <summary>Creates one immutable result.</summary>
        public ScanResult(
            int filesExamined,
            int metasParsed,
            IReadOnlyList<MetaIssue> issues,
            IReadOnlyList<DuplicateGuidGroup> duplicates,
            TimeSpan duration,
            DateTime atUtc)
        {
            FilesExamined = filesExamined;
            MetasParsed = metasParsed;
            Issues = issues;
            Duplicates = duplicates;
            Duration = duration;
            AtUtc = atUtc;
        }
    }

    /// <summary>What a repair actually did - the receipt the window renders and the journal keeps.
    /// Every act writes one; an act without a receipt did not happen.</summary>
    public sealed class ActReceipt
    {
        /// <summary>Machine-readable act name, e.g. <c>restore-meta-from-git</c>.</summary>
        public string Act { get; }

        /// <summary>The file the act touched, project-relative.</summary>
        public string Path { get; }

        /// <summary>Human-readable description of what was verified after the write.</summary>
        public string Detail { get; }

        /// <summary>True when the act completed AND its read-back verification passed.</summary>
        public bool Ok { get; }

        /// <summary>When the act finished (UTC).</summary>
        public DateTime AtUtc { get; }

        /// <summary>Absolute path of a backup written before a destructive act, or null.</summary>
        public string? BackupPath { get; }

        /// <summary>Creates one receipt.</summary>
        public ActReceipt(string act, string path, string detail, bool ok, DateTime atUtc, string? backupPath)
        {
            Act = act;
            Path = path;
            Detail = detail;
            Ok = ok;
            AtUtc = atUtc;
            BackupPath = backupPath;
        }
    }
}
