// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

// CSAF GUID Warden - git hygiene: smart-merge rules, merge driver, and the pre-commit guard.
// Copyright (c) Corey Gallant and Stephanie Thomason. See LICENSE.txt.

using System;
using System.IO;
using System.Text;
using CSAF.GuidWarden.Model;

namespace CSAF.GuidWarden.Acts
{
    /// <summary>What each of the three git-hygiene layers currently looks like.</summary>
    public enum HookState
    {
        /// <summary>No git repository was found above the project.</summary>
        NoRepo,
        /// <summary>Nothing is installed.</summary>
        Absent,
        /// <summary>Installed by GUID Warden (the marker line is present).</summary>
        Ours,
        /// <summary>Something else is installed. GUID Warden never touches a file it did not
        /// write - the window shows the path and offers the hook text to merge by hand.</summary>
        Foreign,
    }

    /// <summary>Snapshot of the repo's Unity-hygiene configuration.</summary>
    public sealed class HygieneStatus
    {
        /// <summary>Repository root, '/'-separated, or null when there is none.</summary>
        public string? RepoRoot { get; }
        /// <summary>State of the <c>.gitattributes</c> smart-merge block.</summary>
        public HookState Attributes { get; }
        /// <summary>True when <c>merge.unityyamlmerge.driver</c> is configured.</summary>
        public bool MergeDriverConfigured { get; }
        /// <summary>State of the pre-commit hook.</summary>
        public HookState Hook { get; }
        /// <summary>Absolute path of the pre-commit hook file git would run.</summary>
        public string? HookPath { get; }

        /// <summary>Creates one snapshot.</summary>
        public HygieneStatus(string? repoRoot, HookState attributes, bool mergeDriverConfigured, HookState hook, string? hookPath)
        {
            RepoRoot = repoRoot;
            Attributes = attributes;
            MergeDriverConfigured = mergeDriverConfigured;
            Hook = hook;
            HookPath = hookPath;
        }
    }

    /// <summary>
    /// Installs and verifies the three pieces of git configuration that prevent the whole class of
    /// meta/GUID breakage: smart-merge attributes, the UnityYAMLMerge driver, and a dependency-free
    /// POSIX-sh pre-commit hook that refuses reference-breaking commits.
    /// </summary>
    public static class GitHygiene
    {
        /// <summary>Marker present in everything this class writes; how we recognise our own work
        /// and the reason we can promise never to touch anyone else's.</summary>
        public const string Marker = "CSAF-GUID-WARDEN";

        /// <summary>The <c>.gitattributes</c> block, LF-terminated.</summary>
        public const string AttributesBlock =
            "# --- " + Marker + " smart-merge rules v1 (installed by GUID Warden; safe to keep) ---\n" +
            "*.unity merge=unityyamlmerge\n" +
            "*.prefab merge=unityyamlmerge\n" +
            "*.asset merge=unityyamlmerge\n" +
            "# --- end " + Marker + " ---\n";

        /// <summary>
        /// The pre-commit hook, POSIX sh, no dependencies beyond git itself. LF line endings only -
        /// a CRLF shebang breaks sh on every non-Windows machine, and tests assert this.
        /// </summary>
        /// <remarks>
        /// Three refusals: an asset staged without its <c>.meta</c> in the index; a <c>.meta</c>
        /// deletion that leaves its asset tracked; and two staged <c>.meta</c> files declaring one
        /// GUID. Paths with tabs are the one known limitation. Bypass is always available with
        /// <c>git commit --no-verify</c> and the refusal card says so.
        /// </remarks>
        public static readonly string HookText =
            "#!/bin/sh\n" +
            "# " + Marker + "-HOOK v1 - installed by CSAF GUID Warden (Unity editor tool).\n" +
            "# Refuses commits that would silently break Unity asset references.\n" +
            "# Reinstall from the GUID Warden window rather than editing in place.\n" +
            "# Bypass once with:  git commit --no-verify\n" +
            "\n" +
            "warded_root=\"Assets/\"\n" +
            "tmp=\"${TMPDIR:-/tmp}/guid-warden-pc.$$\"\n" +
            ": > \"$tmp\" || exit 0\n" +
            "\n" +
            "# 1+2: assets staged without metas / meta deletions that leave the asset behind\n" +
            "git -c core.quotepath=off diff --cached --name-status --no-renames |\n" +
            "while IFS=\"$(printf '\\t')\" read -r status path rest; do\n" +
            "  case \"$path\" in\n" +
            "    \"$warded_root\"*) ;;\n" +
            "    *) continue ;;\n" +
            "  esac\n" +
            "  base=\"${path##*/}\"\n" +
            "  case \"$status\" in\n" +
            "    A*)\n" +
            "      case \"$path\" in\n" +
            "        *.meta) ;;\n" +
            "        *)\n" +
            "          case \"$base\" in\n" +
            "            .*|*~|*.tmp|*.TMP|cvs|CVS) continue ;;\n" +
            "          esac\n" +
            "          if ! git ls-files --cached --error-unmatch -- \"$path.meta\" >/dev/null 2>&1; then\n" +
            "            printf 'MISSING META   %s\\n   The asset is staged but its .meta is not. Unity will mint a fresh GUID\\n   on every other machine and existing references will break silently.\\n   Fix:  git add \"%s.meta\"\\n' \"$path\" \"$path\" >> \"$tmp\"\n" +
            "          fi\n" +
            "          ;;\n" +
            "      esac\n" +
            "      ;;\n" +
            "    D*)\n" +
            "      case \"$path\" in\n" +
            "        *.meta)\n" +
            "          asset=\"${path%.meta}\"\n" +
            "          if git ls-files --cached --error-unmatch -- \"$asset\" >/dev/null 2>&1; then\n" +
            "            printf 'ORPHANED ASSET %s\\n   Its .meta is being deleted while the asset stays tracked. Unity will\\n   re-mint the GUID and references to it will break.\\n   Fix: restore the meta, or delete the asset in the same commit.\\n' \"$asset\" >> \"$tmp\"\n" +
            "          fi\n" +
            "          ;;\n" +
            "      esac\n" +
            "      ;;\n" +
            "  esac\n" +
            "done\n" +
            "\n" +
            "# 3: duplicate GUIDs inside the staged set (the copy-pasted-folder case)\n" +
            "git -c core.quotepath=off diff --cached --name-only --no-renames --diff-filter=AM |\n" +
            "grep '\\.meta$' |\n" +
            "while IFS= read -r p; do\n" +
            "  g=\"$(git show :\"$p\" 2>/dev/null | sed -n 's/^guid: \\([0-9a-fA-F]\\{32\\}\\)[[:space:]]*$/\\1/p' | sed -n 1p)\"\n" +
            "  if [ -n \"$g\" ]; then printf '%s\\t%s\\n' \"$g\" \"$p\"; fi\n" +
            "done | sort | awk -F\"\\t\" '\n" +
            "  $1 == prev { print \"DUPLICATE GUID \" $1; print \"   claimed by  \" prevfile; print \"   and         \" $2 }\n" +
            "  { prev = $1; prevfile = $2 }\n" +
            "' >> \"$tmp\"\n" +
            "\n" +
            "if [ -s \"$tmp\" ]; then\n" +
            "  echo \"\"\n" +
            "  echo \"+----------------------------------------------------------------+\"\n" +
            "  echo \"|  GUID WARDEN refused this commit - references would break      |\"\n" +
            "  echo \"+----------------------------------------------------------------+\"\n" +
            "  cat \"$tmp\"\n" +
            "  echo \"\"\n" +
            "  echo \"  Nothing was committed. Fix the items above, or bypass once with:\"\n" +
            "  echo \"      git commit --no-verify\"\n" +
            "  rm -f \"$tmp\"\n" +
            "  exit 1\n" +
            "fi\n" +
            "rm -f \"$tmp\"\n" +
            "exit 0\n";

        /// <summary>Reads the current hygiene state of the repo above <paramref name="projectRoot"/>.</summary>
        public static HygieneStatus Check(string projectRoot)
        {
            string? repoRoot = GitCli.FindRepoRoot(projectRoot);
            if (repoRoot == null)
            {
                return new HygieneStatus(null, HookState.NoRepo, false, HookState.NoRepo, null);
            }

            string attrPath = repoRoot + "/.gitattributes";
            HookState attrs = HookState.Absent;
            if (File.Exists(attrPath))
            {
                string text = File.ReadAllText(attrPath);
                if (text.Contains(Marker)) { attrs = HookState.Ours; }
                else if (text.Contains("unityyamlmerge")) { attrs = HookState.Foreign; }
            }

            GitResult drv = GitCli.Run(repoRoot, "config", "--get", "merge.unityyamlmerge.driver");
            bool driver = drv.Ok && drv.StdOut.Trim().Length > 0;

            string? hookPath = ResolveHookPath(repoRoot);
            HookState hook = HookState.Absent;
            if (hookPath != null && File.Exists(hookPath))
            {
                hook = File.ReadAllText(hookPath).Contains(Marker) ? HookState.Ours : HookState.Foreign;
            }

            return new HygieneStatus(repoRoot, attrs, driver, hook, hookPath);
        }

        /// <summary>Appends the smart-merge block to <c>.gitattributes</c> (creating the file if
        /// needed). Never rewrites existing content; refuses when a foreign unityyamlmerge rule is
        /// already present. Idempotent - a second install is a no-op with an honest receipt.</summary>
        public static ActReceipt InstallAttributes(string projectRoot)
        {
            HygieneStatus st = Check(projectRoot);
            if (st.RepoRoot == null)
            {
                return new ActReceipt("install-gitattributes", ".gitattributes",
                    "No git repository found above the project.", false, DateTime.UtcNow, null);
            }
            if (st.Attributes == HookState.Ours)
            {
                return new ActReceipt("install-gitattributes", ".gitattributes",
                    "Already installed - nothing to do.", true, DateTime.UtcNow, null);
            }
            if (st.Attributes == HookState.Foreign)
            {
                return new ActReceipt("install-gitattributes", ".gitattributes",
                    "A unityyamlmerge rule not written by GUID Warden already exists. Refusing to " +
                    "touch a file someone else configured - merge the block by hand if you want ours.",
                    false, DateTime.UtcNow, null);
            }

            string attrPath = st.RepoRoot + "/.gitattributes";
            string existing = File.Exists(attrPath) ? File.ReadAllText(attrPath) : string.Empty;
            string joined = existing.Length == 0 || existing.EndsWith("\n", StringComparison.Ordinal)
                ? existing + AttributesBlock
                : existing + "\n" + AttributesBlock;
            File.WriteAllText(attrPath, joined, new UTF8Encoding(false));

            bool ok = File.ReadAllText(attrPath).Contains(Marker);
            return new ActReceipt("install-gitattributes", ".gitattributes",
                ok ? "Smart-merge rules appended; existing content untouched; marker read back."
                   : "Write did not read back - inspect .gitattributes by hand.",
                ok, DateTime.UtcNow, null);
        }

        /// <summary>Configures <c>merge.unityyamlmerge</c> to point at this machine's
        /// UnityYAMLMerge, repo-locally (never <c>--global</c> - the path is machine-specific and
        /// a teammate's machine keeps its own).</summary>
        /// <param name="projectRoot">Absolute project root.</param>
        /// <param name="yamlMergeAbsolutePath">Absolute path of UnityYAMLMerge(.exe).</param>
        public static ActReceipt ConfigureMergeDriver(string projectRoot, string yamlMergeAbsolutePath)
        {
            HygieneStatus st = Check(projectRoot);
            if (st.RepoRoot == null)
            {
                return new ActReceipt("configure-merge-driver", "merge.unityyamlmerge",
                    "No git repository found above the project.", false, DateTime.UtcNow, null);
            }
            if (!File.Exists(yamlMergeAbsolutePath))
            {
                return new ActReceipt("configure-merge-driver", "merge.unityyamlmerge",
                    "UnityYAMLMerge not found at " + yamlMergeAbsolutePath, false, DateTime.UtcNow, null);
            }

            string exe = yamlMergeAbsolutePath.Replace('\\', '/');
            string driver = "\"" + exe + "\" merge -p %O %B %A %A";
            GitResult a = GitCli.Run(st.RepoRoot, "config", "merge.unityyamlmerge.name", "Unity SmartMerge (UnityYAMLMerge)");
            GitResult b = GitCli.Run(st.RepoRoot, "config", "merge.unityyamlmerge.driver", driver);
            GitResult back = GitCli.Run(st.RepoRoot, "config", "--get", "merge.unityyamlmerge.driver");
            bool ok = a.Ok && b.Ok && back.Ok && back.StdOut.Trim() == driver;
            return new ActReceipt("configure-merge-driver", "merge.unityyamlmerge",
                ok ? "Driver set repo-locally and read back: " + driver
                   : "git config did not read back what was written: " + back.StdOut.Trim() + " " + b.StdErr.Trim(),
                ok, DateTime.UtcNow, null);
        }

        /// <summary>Installs the pre-commit hook. Only ever writes when the slot is empty or
        /// already ours; a foreign hook is reported, never modified.</summary>
        public static ActReceipt InstallHook(string projectRoot)
        {
            HygieneStatus st = Check(projectRoot);
            if (st.RepoRoot == null || st.HookPath == null)
            {
                return new ActReceipt("install-pre-commit-hook", "pre-commit",
                    "No git repository found above the project.", false, DateTime.UtcNow, null);
            }
            if (st.Hook == HookState.Foreign)
            {
                return new ActReceipt("install-pre-commit-hook", st.HookPath,
                    "A pre-commit hook not written by GUID Warden exists. Refusing to modify it - " +
                    "use 'Copy hook text' and merge it into your hook by hand.",
                    false, DateTime.UtcNow, null);
            }

            string? hookDir = Path.GetDirectoryName(st.HookPath);
            if (hookDir != null) { Directory.CreateDirectory(hookDir); }
            File.WriteAllText(st.HookPath, HookText, new UTF8Encoding(false));

            string readBack = File.ReadAllText(st.HookPath);
            bool ok = readBack == HookText && !readBack.Contains("\r");
            return new ActReceipt("install-pre-commit-hook", st.HookPath,
                ok ? "Hook installed, read back byte-identical, LF-only. On macOS/Linux run once: " +
                     "chmod +x .git/hooks/pre-commit"
                   : "Hook did not read back byte-identical.",
                ok, DateTime.UtcNow, null);
        }

        /// <summary>Where git will actually look for the pre-commit hook, honouring
        /// <c>core.hooksPath</c> and worktrees. Null when git cannot answer.</summary>
        public static string? ResolveHookPath(string repoRoot)
        {
            GitResult r = GitCli.Run(repoRoot, "rev-parse", "--git-path", "hooks/pre-commit");
            if (!r.Ok) { return null; }
            string p = r.StdOut.Trim().Replace('\\', '/');
            if (p.Length == 0) { return null; }
            if (!Path.IsPathRooted(p)) { p = repoRoot + "/" + p; }
            return p;
        }
    }
}
