// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

// CSAF GUID Warden - the CI gate.
// Copyright (c) Corey Gallant and Stephanie Thomason. See LICENSE.txt.

using System;
using System.Globalization;
using System.IO;
using System.Text;
using CSAF.GuidWarden.Model;
using CSAF.GuidWarden.Scan;
using UnityEditor;
using UnityEngine;

namespace CSAF.GuidWarden.CI
{
    /// <summary>
    /// Batch-mode entry point: scans the project and fails the build when integrity issues exist,
    /// so a broken reference never reaches a teammate's machine through CI.
    /// </summary>
    /// <example>
    /// <code>
    /// Unity.exe -batchmode -quit -nographics -projectPath . ^
    ///   -executeMethod CSAF.GuidWarden.CI.GuidWardenCI.Run ^
    ///   -guidWardenReport Temp/guid-warden-report.json
    /// </code>
    /// Exit 0 = clean (and at least one file was examined - a scan of nothing never passes).
    /// Exit 1 = issues found. Exit 2 = the scan itself failed.
    /// </example>
    public static class GuidWardenCI
    {
        /// <summary>Command-line flag naming the JSON report path.</summary>
        public const string ReportFlag = "-guidWardenReport";

        /// <summary>Default report path when the flag is absent.</summary>
        public const string DefaultReportPath = "Temp/guid-warden-report.json";

        /// <summary>Runs the scan, writes the JSON report, and exits with the verdict.</summary>
        public static void Run()
        {
            int exit;
            try
            {
                exit = RunCore(Environment.GetCommandLineArgs(), Application.dataPath, out string summary);
                Debug.Log("[GUID Warden CI] " + summary);
            }
            catch (Exception e)
            {
                Debug.LogError("[GUID Warden CI] scan failed: " + e);
                exit = 2;
            }
            EditorApplication.Exit(exit);
        }

        /// <summary>
        /// The testable core: parses <paramref name="args"/> for the report flag, scans
        /// <paramref name="assetsRoot"/>, writes the report, returns the exit code.
        /// </summary>
        public static int RunCore(string[] args, string assetsRoot, out string summary)
        {
            string reportPath = DefaultReportPath;
            for (int i = 0; i < args.Length - 1; i++)
            {
                if (string.Equals(args[i], ReportFlag, StringComparison.OrdinalIgnoreCase))
                {
                    reportPath = args[i + 1];
                }
            }

            ScanResult result = MetaScanner.Scan(assetsRoot);
            string? dir = Path.GetDirectoryName(reportPath);
            if (dir != null && dir.Length > 0) { Directory.CreateDirectory(dir); }
            File.WriteAllText(reportPath, ToJson(result), new UTF8Encoding(false));

            summary = string.Format(CultureInfo.InvariantCulture,
                "examined {0} entries, parsed {1} metas: {2} missing, {3} orphaned, {4} GUID collisions -> {5} ({6})",
                result.FilesExamined, result.MetasParsed,
                CountKind(result, IssueKind.MissingMeta), CountKind(result, IssueKind.OrphanMeta),
                result.Duplicates.Count,
                result.Clean ? "CLEAN" : "ISSUES", reportPath);

            // A scan that examined zero files is a failure wearing a pass - refuse it.
            if (result.FilesExamined == 0) { return 2; }
            return result.IssueCount == 0 ? 0 : 1;
        }

        /// <summary>Serializes a result as stable, dependency-free JSON.</summary>
        public static string ToJson(ScanResult r)
        {
            var sb = new StringBuilder(4096);
            sb.Append("{\n");
            sb.Append("  \"tool\": \"CSAF GUID Warden\",\n");
            sb.Append("  \"atUtc\": \"").Append(r.AtUtc.ToString("o", CultureInfo.InvariantCulture)).Append("\",\n");
            sb.Append("  \"filesExamined\": ").Append(r.FilesExamined.ToString(CultureInfo.InvariantCulture)).Append(",\n");
            sb.Append("  \"metasParsed\": ").Append(r.MetasParsed.ToString(CultureInfo.InvariantCulture)).Append(",\n");
            sb.Append("  \"clean\": ").Append(r.Clean ? "true" : "false").Append(",\n");
            sb.Append("  \"issues\": [\n");
            for (int i = 0; i < r.Issues.Count; i++)
            {
                MetaIssue issue = r.Issues[i];
                sb.Append("    { \"kind\": \"").Append(issue.Kind.ToString()).Append("\", \"asset\": ");
                AppendJsonString(sb, issue.AssetPath);
                sb.Append(", \"meta\": ");
                AppendJsonString(sb, issue.MetaPath);
                sb.Append(", \"guid\": ");
                if (issue.Guid == null) { sb.Append("null"); } else { AppendJsonString(sb, issue.Guid); }
                sb.Append(" }").Append(i + 1 < r.Issues.Count ? ",\n" : "\n");
            }
            sb.Append("  ],\n");
            sb.Append("  \"duplicateGuids\": [\n");
            for (int i = 0; i < r.Duplicates.Count; i++)
            {
                DuplicateGuidGroup g = r.Duplicates[i];
                sb.Append("    { \"guid\": ");
                AppendJsonString(sb, g.Guid);
                sb.Append(", \"claimants\": [");
                for (int c = 0; c < g.ClaimantMetaPaths.Count; c++)
                {
                    if (c > 0) { sb.Append(", "); }
                    AppendJsonString(sb, g.ClaimantMetaPaths[c]);
                }
                sb.Append("] }").Append(i + 1 < r.Duplicates.Count ? ",\n" : "\n");
            }
            sb.Append("  ]\n");
            sb.Append("}\n");
            return sb.ToString();
        }

        private static int CountKind(ScanResult r, IssueKind kind)
        {
            int n = 0;
            for (int i = 0; i < r.Issues.Count; i++)
            {
                if (r.Issues[i].Kind == kind) { n++; }
            }
            return n;
        }

        private static void AppendJsonString(StringBuilder sb, string s)
        {
            sb.Append('"');
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (c == '"' || c == '\\') { sb.Append('\\').Append(c); }
                else if (c == '\n') { sb.Append("\\n"); }
                else if (c == '\r') { sb.Append("\\r"); }
                else if (c == '\t') { sb.Append("\\t"); }
                else if (c < ' ') { sb.Append("\\u").Append(((int)c).ToString("x4", CultureInfo.InvariantCulture)); }
                else { sb.Append(c); }
            }
            sb.Append('"');
        }
    }
}
