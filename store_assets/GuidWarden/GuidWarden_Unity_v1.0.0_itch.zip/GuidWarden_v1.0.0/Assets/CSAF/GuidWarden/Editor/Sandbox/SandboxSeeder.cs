// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

// CSAF GUID Warden - the demo sandbox.
// Copyright (c) Corey Gallant and Stephanie Thomason. See LICENSE.txt.

using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace CSAF.GuidWarden.Sandbox
{
    /// <summary>
    /// Creates a small, clearly-labelled folder of deliberately broken meta state so the demo can
    /// show every card and every act on a project that is not the buyer's own.
    /// </summary>
    /// <remarks>
    /// The files are written WITHOUT <c>AssetDatabase.Refresh()</c>, and that is the demo: Unity
    /// has not noticed them yet, which is exactly the window in which GUID Warden repairs are
    /// possible. Once Unity refreshes, it would mint fresh GUIDs and re-mint duplicates silently -
    /// the behaviour the product exists to intercept.
    /// </remarks>
    public static class SandboxSeeder
    {
        /// <summary>Project-relative sandbox folder. Deliberately outside the package folder so
        /// removing the package never leaves sandbox litter behind.</summary>
        public const string SandboxRoot = "Assets/GuidWardenSandbox";

        private const string DupGuid = "feedfacefeedfacefeedfacefeedface";

        /// <summary>Creates the sandbox: one asset missing its meta, one orphaned meta, and two
        /// metas claiming one GUID.</summary>
        [MenuItem("Tools/CSAF/GUID Warden/Create Sandbox Issues", false, 200)]
        public static void Create()
        {
            string abs = Path.GetFullPath(SandboxRoot);
            Directory.CreateDirectory(abs);

            // The folder itself gets a meta so the sandbox adds exactly the issues it claims.
            WriteIfAbsent(abs + ".meta", FolderMeta("0d15ea5e0d15ea5e0d15ea5e0d15ea5e"));

            // 1. Missing meta: the file exists, no .meta beside it.
            WriteIfAbsent(Path.Combine(abs, "Unmapped.txt"),
                "This asset has no .meta. On the next refresh Unity would mint a fresh GUID.\n");

            // 2. Orphaned meta: a .meta whose asset is gone.
            WriteIfAbsent(Path.Combine(abs, "Ghost.txt.meta"), TextMeta("a11ce5a11ce5a11ce5a11ce5a11ce5aa"));

            // 3. Duplicate GUID: two assets, two metas, one GUID.
            WriteIfAbsent(Path.Combine(abs, "Crystal_A.txt"), "Claimant A of a contested GUID.\n");
            WriteIfAbsent(Path.Combine(abs, "Crystal_A.txt.meta"), TextMeta(DupGuid));
            WriteIfAbsent(Path.Combine(abs, "Crystal_B.txt"), "Claimant B of the same GUID.\n");
            WriteIfAbsent(Path.Combine(abs, "Crystal_B.txt.meta"), TextMeta(DupGuid));

            Debug.Log("[GUID Warden] Sandbox created at " + SandboxRoot + " - open the window and Scan. " +
                      "No AssetDatabase.Refresh was performed, deliberately: this is the window in which " +
                      "repairs are still possible.");
        }

        /// <summary>Removes the sandbox folder, its meta, and everything inside.</summary>
        [MenuItem("Tools/CSAF/GUID Warden/Remove Sandbox", false, 201)]
        public static void Remove()
        {
            string abs = Path.GetFullPath(SandboxRoot);
            if (Directory.Exists(abs)) { Directory.Delete(abs, true); }
            if (File.Exists(abs + ".meta")) { File.Delete(abs + ".meta"); }
            AssetDatabase.Refresh();
            Debug.Log("[GUID Warden] Sandbox removed.");
        }

        private static void WriteIfAbsent(string path, string content)
        {
            if (!File.Exists(path))
            {
                File.WriteAllText(path, content, new UTF8Encoding(false));
            }
        }

        private static string TextMeta(string guid)
        {
            return "fileFormatVersion: 2\nguid: " + guid + "\nTextScriptImporter:\n" +
                   "  externalObjects: {}\n  userData: \n  assetBundleName: \n  assetBundleVariant: \n";
        }

        private static string FolderMeta(string guid)
        {
            return "fileFormatVersion: 2\nguid: " + guid + "\nfolderAsset: yes\nDefaultImporter:\n" +
                   "  externalObjects: {}\n  userData: \n  assetBundleName: \n  assetBundleVariant: \n";
        }
    }
}
