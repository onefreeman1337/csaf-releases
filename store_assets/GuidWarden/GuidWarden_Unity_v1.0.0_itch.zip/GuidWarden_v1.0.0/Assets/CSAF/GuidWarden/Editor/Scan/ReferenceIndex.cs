// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

// CSAF GUID Warden - who references a GUID.
// Copyright (c) Corey Gallant and Stephanie Thomason. See LICENSE.txt.

using System;
using System.Collections.Generic;
using System.IO;
using CSAF.GuidWarden.Model;

namespace CSAF.GuidWarden.Scan
{
    /// <summary>
    /// Finds every text-serialized asset that references a given GUID. Used to show the blast
    /// radius of a duplicate-GUID collision before anyone resolves it.
    /// </summary>
    /// <remarks>
    /// Only Unity's text-serialized formats are searched - scenes, prefabs, materials and the
    /// rest all record references as <c>guid: &lt;32 hex&gt;</c> in plain YAML. Binary-serialized
    /// projects are out of scope and the UI says so rather than pretending; a search that scanned
    /// binaries with a text regex would produce confident wrong answers.
    /// </remarks>
    public static class ReferenceIndex
    {
        /// <summary>Extensions Unity serializes as text (with Force Text serialization, the
        /// default for years). Sorted; membership is checked case-insensitively.</summary>
        public static readonly string[] TextAssetExtensions =
        {
            ".anim", ".asset", ".controller", ".guiskin", ".mat", ".overrideController",
            ".physicMaterial", ".physicsMaterial2D", ".playable", ".prefab", ".preset",
            ".renderTexture", ".shadergraph", ".shadervariants", ".unity",
        };

        /// <summary>
        /// Scans <paramref name="rootAbsolute"/> for text assets whose content mentions
        /// <paramref name="guid"/>. Returns project-relative '/'-separated paths, sorted.
        /// </summary>
        /// <param name="rootAbsolute">Folder to search, typically the project's <c>Assets</c>.</param>
        /// <param name="guid">The 32-hex GUID to look for.</param>
        /// <param name="shouldCancel">Optional cancellation probe, polled per file.</param>
        public static IReadOnlyList<string> FindReferencers(
            string rootAbsolute, string guid, Func<bool>? shouldCancel = null)
        {
            if (guid.Length != 32)
            {
                throw new ArgumentException("Expected a 32-hex GUID, got: " + guid, nameof(guid));
            }

            string rootFull = Path.GetFullPath(rootAbsolute).Replace('\\', '/').TrimEnd('/');
            string parentFull = Path.GetDirectoryName(rootFull.Replace('/', Path.DirectorySeparatorChar)) is string p
                ? p.Replace('\\', '/')
                : rootFull;

            var hits = new List<string>();
            var pending = new Stack<string>();
            pending.Push(rootFull);

            while (pending.Count > 0)
            {
                string dir = pending.Pop();
                foreach (string entryAbs in Directory.EnumerateFileSystemEntries(dir))
                {
                    if (shouldCancel != null && shouldCancel())
                    {
                        throw new OperationCanceledException("GUID Warden reference search cancelled.");
                    }

                    string entry = entryAbs.Replace('\\', '/');
                    string name = entry.Substring(entry.LastIndexOf('/') + 1);
                    if (UnityIgnoreRules.IsHiddenName(name)) { continue; }

                    if (Directory.Exists(entry)) { pending.Push(entry); continue; }
                    if (!HasTextAssetExtension(name)) { continue; }

                    string text;
                    try { text = File.ReadAllText(entry); }
                    catch (IOException) { continue; }
                    catch (UnauthorizedAccessException) { continue; }

                    if (text.IndexOf(guid, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        string rel = entry.StartsWith(parentFull + "/", StringComparison.OrdinalIgnoreCase)
                            ? entry.Substring(parentFull.Length + 1)
                            : entry;
                        hits.Add(rel);
                    }
                }
            }

            hits.Sort(StringComparer.Ordinal);
            return hits;
        }

        /// <summary>True when the file name carries one of Unity's text-serialized extensions.</summary>
        public static bool HasTextAssetExtension(string fileName)
        {
            int dot = fileName.LastIndexOf('.');
            if (dot < 0) { return false; }
            string ext = fileName.Substring(dot);
            for (int i = 0; i < TextAssetExtensions.Length; i++)
            {
                if (string.Equals(ext, TextAssetExtensions[i], StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
