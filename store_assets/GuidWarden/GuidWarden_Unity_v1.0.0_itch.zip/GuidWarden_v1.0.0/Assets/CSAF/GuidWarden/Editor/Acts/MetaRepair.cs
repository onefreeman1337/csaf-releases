// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

// CSAF GUID Warden - the repair acts.
// Copyright (c) Corey Gallant and Stephanie Thomason. See LICENSE.txt.

using System;
using System.IO;
using CSAF.GuidWarden.Model;

namespace CSAF.GuidWarden.Acts
{
    /// <summary>
    /// The acts that fix missing and orphaned <c>.meta</c> files. Every act verifies its own write
    /// by reading the file back, and every destructive act writes a byte-exact backup first -
    /// a save that reports success is not a save.
    /// </summary>
    public static class MetaRepair
    {
        /// <summary>Where destructive acts park a byte-exact copy before touching anything.
        /// Lives under <c>Library</c>, so it is never committed and never ships.</summary>
        public static string BackupRoot
        {
            get { return "Library/CSAF.GuidWarden/backups"; }
        }

        /// <summary>
        /// Restores a lost <c>.meta</c> from git HEAD, so the asset keeps the GUID every existing
        /// reference points at. This is the act Unity itself cannot perform - on the next refresh
        /// it would mint a fresh GUID and every reference would break silently.
        /// </summary>
        /// <param name="projectRoot">Absolute project root (the folder containing Assets).</param>
        /// <param name="assetProjectRelative">Project-relative asset path, '/'-separated.</param>
        public static ActReceipt RestoreMetaFromGit(string projectRoot, string assetProjectRelative)
        {
            string metaRel = assetProjectRelative + ".meta";
            string metaAbs = Path.Combine(projectRoot, metaRel.Replace('/', Path.DirectorySeparatorChar));

            string? repoRoot = GitCli.FindRepoRoot(projectRoot);
            if (repoRoot == null)
            {
                return new ActReceipt("restore-meta-from-git", metaRel,
                    "No git repository found above the project. Nothing was written.",
                    false, DateTime.UtcNow, null);
            }

            // The repo root may sit above the project root; git wants repo-relative paths.
            string projectFull = Path.GetFullPath(projectRoot).Replace('\\', '/').TrimEnd('/');
            string repoRelPrefix = projectFull.Length > repoRoot.Length
                ? projectFull.Substring(repoRoot.Length).TrimStart('/') + "/"
                : string.Empty;
            string metaRepoRel = repoRelPrefix + metaRel;

            string? content = GitCli.ShowHead(repoRoot, metaRepoRel);
            if (content == null)
            {
                return new ActReceipt("restore-meta-from-git", metaRel,
                    "git HEAD has no " + metaRepoRel + " - the meta was never committed, so there " +
                    "is no old GUID to preserve. Use 'Accept fresh GUID' instead.",
                    false, DateTime.UtcNow, null);
            }

            if (File.Exists(metaAbs))
            {
                return new ActReceipt("restore-meta-from-git", metaRel,
                    "A .meta already exists on disk. Refusing to overwrite it.",
                    false, DateTime.UtcNow, null);
            }

            File.WriteAllText(metaAbs, content);

            // Read-back: the write is only claimed after the file on disk carries a GUID.
            string? readBack = Scan.MetaScanner.ReadGuid(metaAbs);
            bool ok = readBack != null;
            return new ActReceipt("restore-meta-from-git", metaRel,
                ok ? "Restored from git HEAD; read back guid " + readBack + "."
                   : "Wrote the file but no GUID reads back - inspect " + metaRel + " by hand.",
                ok, DateTime.UtcNow, null);
        }

        /// <summary>
        /// Deletes an orphaned <c>.meta</c> after copying it byte-exact into
        /// <see cref="BackupRoot"/>. The receipt carries the backup path, and the window offers a
        /// one-click restore from it.
        /// </summary>
        /// <param name="projectRoot">Absolute project root.</param>
        /// <param name="metaProjectRelative">Project-relative path of the orphan, '/'-separated.</param>
        public static ActReceipt DeleteOrphanMeta(string projectRoot, string metaProjectRelative)
        {
            string metaAbs = Path.Combine(projectRoot, metaProjectRelative.Replace('/', Path.DirectorySeparatorChar));
            if (!File.Exists(metaAbs))
            {
                return new ActReceipt("delete-orphan-meta", metaProjectRelative,
                    "Already gone - nothing to delete.", false, DateTime.UtcNow, null);
            }

            byte[] original = File.ReadAllBytes(metaAbs);
            string backupAbs = Path.Combine(
                projectRoot,
                BackupRoot.Replace('/', Path.DirectorySeparatorChar),
                DateTime.UtcNow.ToString("yyyyMMdd-HHmmss") + "-" + metaProjectRelative.Replace('/', '_'));
            string? backupDir = Path.GetDirectoryName(backupAbs);
            if (backupDir != null) { Directory.CreateDirectory(backupDir); }
            File.WriteAllBytes(backupAbs, original);

            // Verify the backup byte-for-byte BEFORE deleting - a backup that was never compared
            // is a hope, not a backup.
            byte[] backedUp = File.ReadAllBytes(backupAbs);
            if (!BytesEqual(original, backedUp))
            {
                return new ActReceipt("delete-orphan-meta", metaProjectRelative,
                    "Backup did not verify byte-for-byte. The orphan was NOT deleted.",
                    false, DateTime.UtcNow, backupAbs);
            }

            File.Delete(metaAbs);
            bool gone = !File.Exists(metaAbs);
            return new ActReceipt("delete-orphan-meta", metaProjectRelative,
                gone ? "Deleted. Byte-exact backup kept." : "Delete reported no error but the file is still there.",
                gone, DateTime.UtcNow, backupAbs);
        }

        /// <summary>Restores a previously deleted orphan from its backup receipt.</summary>
        public static ActReceipt RestoreFromBackup(string projectRoot, string metaProjectRelative, string backupAbsolute)
        {
            string metaAbs = Path.Combine(projectRoot, metaProjectRelative.Replace('/', Path.DirectorySeparatorChar));
            if (!File.Exists(backupAbsolute))
            {
                return new ActReceipt("restore-from-backup", metaProjectRelative,
                    "Backup file is missing: " + backupAbsolute, false, DateTime.UtcNow, backupAbsolute);
            }
            if (File.Exists(metaAbs))
            {
                return new ActReceipt("restore-from-backup", metaProjectRelative,
                    "A .meta already exists on disk. Refusing to overwrite it.", false, DateTime.UtcNow, backupAbsolute);
            }
            byte[] bytes = File.ReadAllBytes(backupAbsolute);
            File.WriteAllBytes(metaAbs, bytes);
            bool ok = File.Exists(metaAbs) && BytesEqual(File.ReadAllBytes(metaAbs), bytes);
            return new ActReceipt("restore-from-backup", metaProjectRelative,
                ok ? "Restored byte-exact from backup." : "Restore did not verify.", ok, DateTime.UtcNow, backupAbsolute);
        }

        private static bool BytesEqual(byte[] a, byte[] b)
        {
            if (a.Length != b.Length) { return false; }
            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] != b[i]) { return false; }
            }
            return true;
        }
    }
}
