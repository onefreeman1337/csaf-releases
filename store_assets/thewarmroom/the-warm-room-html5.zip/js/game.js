/* THE WARM ROOM — game.js
 *
 * Presentation, input and the clock. Every RULE lives in sim.js; this file may read state and call
 * sim actions, and must never decide anything about the economy itself. That separation is what
 * lets `test_sim.js` and `balance.js` gate the game without a browser.
 *
 * LAYOUT (canvas 960x620, embedded at 960x680 so the itch page has room under it):
 *   HUD      y 0..56       the day, the clock, the room temperature, the purse
 *   BOARD    14,62         15x9 cells at 40px = 600x360
 *   LOG      14,432        what just happened, in words
 *   PANEL    628,62        the three tabs: BUILD / SOW / ROOM
 */
'use strict';

(() => {
  const W = 960, H = 620;
  const CELL = 40;
  const BX = 14, BY = 62;
  const PANEL_X = 628, PANEL_Y = 62, PANEL_W = 318;
  const LOG_X = 14, LOG_Y = 432, LOG_W = 600, LOG_H = 174;
  const SECONDS_PER_HOUR = 0.9;      // ⚠️ balance.js quotes the session length from this exact value

  const C = {
    ink: '#141119', ink2: '#1e1a24', paper: '#e8e0cf', dim: '#a99f8c',
    warm: '#e8a24a', cold: '#7fa0d8', good: '#8fbf6a', bad: '#c96a5a',
    panel: '#221d29', panelHi: '#2e2734', line: '#3a3242',
  };

  let cv, ctx, state, D, running = true, speed = 1, acc = 0, last = 0;
  let tab = 'build';
  let sel = null;                    // {kind:'fix'|'seed'|'glass'|'board'|'remove', id}
  let hover = -1;
  let hits = [];
  let toast = null, toastT = 0;
  let ending = null;
  let bootError = null;

  /* ── boot ────────────────────────────────────────────────────────────────────────────────── */
  function boot() {
    cv = document.getElementById('game');
    ctx = cv.getContext('2d', { alpha: false });
    ctx.imageSmoothingEnabled = false;
    D = window.DATA;

    const loaded = window.SAVE.read();
    state = loaded || window.SIM.createState((Date.now() ^ 0x5eed) >>> 0);
    if (!loaded) firstDay();

    cv.addEventListener('mousemove', onMove);
    cv.addEventListener('click', onClick);
    cv.addEventListener('contextmenu', onRight);
    window.addEventListener('keydown', onKey);
    window.addEventListener('beforeunload', () => window.SAVE.write(state));

    window.ART.load().then(() => {
      const miss = window.ART.missing();
      if (miss.length) bootError = `missing art: ${miss.join(', ')}`;
      last = performance.now();
      requestAnimationFrame(frame);
    });
  }

  function firstDay() {
    /* The opening move the tutorial talks the player through. It is placed for them so the very
     * first thing they see is a room that already has something alive in it — and the balance
     * probe asserts this exact move is affordable, because a version where it was not shipped a
     * game whose growth economy could never start.
     *
     * ⚠️ THE STORY LINES GO IN FIRST. Placing then narrating put "Put in a brazier." above "They
     * gave you the key", so the log opened mid-sentence and the premise arrived fourth. The log is
     * the only narrator this game has. */
    const S = window.SIM;
    S.logLine(state, 'They gave you the key at the town hall and did not ask for anything back.', 'event');
    S.logLine(state, 'Ninety days until spring. Keep the fire in and see who comes.', 'event');
    S.place(state, S.idx(7, 4), 'brazier');
    S.place(state, S.idx(6, 4), 'bench');
    S.place(state, S.idx(8, 4), 'bed_cold');
    S.sow(state, S.idx(8, 4), 'mache');
    S.logLine(state, 'Wood for about two days in the basket. Buy more under ROOM.', 'quiet');
  }

  /* ── loop ────────────────────────────────────────────────────────────────────────────────── */
  function frame(now) {
    const dt = Math.min(0.25, (now - last) / 1000);
    last = now;
    if (running && !state.ended) {
      acc += dt * speed;
      while (acc >= SECONDS_PER_HOUR) {
        acc -= SECONDS_PER_HOUR;
        step();
      }
    }
    if (toastT > 0) toastT -= dt;
    render();
    requestAnimationFrame(frame);
  }

  let warnedFuel = false;
  function step() {
    const before = { people: state.people.length, residents: state.residents.length, coin: state.coin };
    const r = window.SIM.stepHour(state);
    const S = window.SIM;
    /* ⚠️ THE FIRE GOING OUT IS THE FIRST THING THAT HAPPENS TO EVERY PLAYER and the first build
     * said nothing about it: the HUD turned one number red and the room quietly got colder. The
     * opening wood lasts about two days by design — that lesson only lands if the game says so
     * once, in words, at the moment it happens. */
    if (state.fuel <= 0 && !warnedFuel) {
      warnedFuel = true;
      S.logLine(state, 'The fire is out. Buy wood under ROOM — it is cheap, and nothing grows in a cold room.', 'loss');
    } else if (state.fuel > 6) warnedFuel = false;
    if (state.people.length > before.people) window.SOUND.play('arrive');
    if (state.residents.length > before.residents) window.SOUND.play('resident');
    else if (state.coin > before.coin + 2) window.SOUND.play('coin');
    if (r.dayEnded) {
      window.SAVE.write(state);
      window.SOUND.play(r.event ? 'event' : 'day');
    }
    const out = S.outsideTemp(state, state.day, state.hour);
    window.SOUND.setRoom((S.roomMean(state) - out) / 22, state.people.length);
    if (state.ended && !ending) {
      ending = S.ending(state);
      window.SOUND.play('spring');
      window.SAVE.write(state);
    }
  }

  /* ── input ───────────────────────────────────────────────────────────────────────────────── */
  function pos(e) {
    const r = cv.getBoundingClientRect();
    return { x: (e.clientX - r.left) * (W / r.width), y: (e.clientY - r.top) * (H / r.height) };
  }
  function cellAt(p) {
    const cx = Math.floor((p.x - BX) / CELL), cy = Math.floor((p.y - BY) / CELL);
    if (cx < 0 || cy < 0 || cx >= D.COLS || cy >= D.ROWS) return -1;
    return window.SIM.idx(cx, cy);
  }
  function onMove(e) { hover = cellAt(pos(e)); }
  function onRight(e) {
    e.preventDefault();
    const i = cellAt(pos(e));
    if (i >= 0) act(window.SIM.remove(state, i), 'remove');
  }
  function onKey(e) {
    if (e.key === ' ') { running = !running; e.preventDefault(); }
    if (e.key === '1') speed = 1;
    if (e.key === '2') speed = 2;
    if (e.key === '3') speed = 4;
    if (e.key === 'm' || e.key === 'M') window.SOUND.toggleMute();
    if (e.key === 'Escape') sel = null;
  }

  function onClick(e) {
    window.SOUND.ensure(); window.SOUND.resume(); window.SOUND.startBed();
    const p = pos(e);
    for (const h of hits) {
      if (p.x >= h.x && p.y >= h.y && p.x < h.x + h.w && p.y < h.y + h.h) { h.fn(); return; }
    }
    const i = cellAt(p);
    if (i < 0) return;
    const S = window.SIM;

    if (state.panes[i]) {                       // a pane
      if (sel && sel.kind === 'board') act(S.boardPane(state, i), 'glass');
      else act(S.upgradePane(state, i), 'glass');
      return;
    }
    const cell = state.cells[i];
    // a ripe bed is harvested by clicking it, whatever tool is held — the obvious thing works
    if (cell.crop && !cell.crop.dead) {
      const cr = D.crop(cell.crop.id);
      if (cr && cell.crop.hours >= cr.hours) { S.harvest(state, i); window.SOUND.play('harvest'); return; }
    }
    if (cell.crop && cell.crop.dead) { cell.crop = null; window.SOUND.play('remove'); return; }
    if (!sel) return;
    if (sel.kind === 'fix') act(S.place(state, i, sel.id), 'place');
    else if (sel.kind === 'seed') act(S.sow(state, i, sel.id), 'sow');
    else if (sel.kind === 'remove') act(S.remove(state, i), 'remove');
  }

  function act(res, sfx) {
    if (res && res.ok) { window.SOUND.play(sfx); window.SAVE.write(state); }
    else { window.SOUND.play('deny'); if (res && res.why) say(res.why); }
  }
  function say(t) { toast = t; toastT = 2.6; }

  /* ── drawing helpers ─────────────────────────────────────────────────────────────────────── */
  function text(t, x, y, size, col, align, weight) {
    ctx.fillStyle = col || C.paper;
    ctx.font = `${weight || 500} ${size || 13}px ui-sans-serif, "Segoe UI", system-ui, sans-serif`;
    ctx.textAlign = align || 'left';
    ctx.textBaseline = 'alphabetic';
    ctx.fillText(t, x, y);
    ctx.textAlign = 'left';
  }
  function box(x, y, w, h, fill, stroke) {
    ctx.fillStyle = fill;
    ctx.fillRect(x, y, w, h);
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1; ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1); }
  }
  const tempColour = (t) => (t < 2 ? C.cold : t < 9 ? '#b9c4d6' : t < 16 ? C.paper : C.warm);

  /* ── render ──────────────────────────────────────────────────────────────────────────────── */
  function render() {
    hits = [];
    ctx.fillStyle = '#0f0d13';
    ctx.fillRect(0, 0, W, H);
    drawHud();
    drawBoard();
    drawLog();
    drawPanel();
    if (toastT > 0 && toast) {
      const w = ctx.measureText(toast).width + 28;
      box(BX + 300 - w / 2, BY + 330, w, 26, 'rgba(20,17,25,0.92)', C.line);
      text(toast, BX + 300, BY + 347, 13, C.paper, 'center');
    }
    if (bootError) text(bootError, 8, H - 6, 11, C.bad);
    if (ending) drawEnding();
  }

  function drawHud() {
    box(0, 0, W, 56, C.ink2);
    const S = window.SIM;
    const mean = S.roomMean(state), out = S.outsideTemp(state, state.day, state.hour);
    const hh = String(state.hour).padStart(2, '0');
    text('THE WARM ROOM', 14, 24, 15, C.paper, 'left', 700);
    const ev = S.eventFor(state.day);
    text(ev ? ev.name : `Day ${state.day + 1} of ${D.WINTER.days}`, 14, 43, 12, ev ? C.warm : C.dim);

    const stats = [
      [`${hh}:00`, C.paper],
      [`inside ${mean.toFixed(1)}°`, tempColour(mean)],
      [`outside ${out.toFixed(1)}°`, C.cold],
      [`${Math.floor(state.coin)} coin`, C.paper],
      [`${Math.floor(state.fuel)} wood`, state.fuel < 8 ? C.bad : C.paper],
      [`${state.produce} produce`, C.paper],
      [`${state.people.length}/${S.peopleCap(state)} in`, C.good],
    ];
    let x = 190;
    for (const [t, col] of stats) {
      text(t, x, 24, 13, col, 'left', 600);
      x += Math.max(88, ctx.measureText(t).width + 22);
    }
    text(`"${S.wordTier(state).name}"  ·  word ${state.word}`, 190, 43, 12, C.dim);

    // clock controls, right-aligned
    const btns = [[running ? 'II' : '>', () => { running = !running; }], ['1x', () => { speed = 1; running = true; }],
      ['2x', () => { speed = 2; running = true; }], ['4x', () => { speed = 4; running = true; }],
      [window.SOUND.isMuted() ? 'off' : 'snd', () => window.SOUND.toggleMute()]];
    let bx = W - 14 - btns.length * 44;
    for (const [label, fn] of btns) {
      const on = (label === '1x' && speed === 1 && running) || (label === '2x' && speed === 2 && running)
        || (label === '4x' && speed === 4 && running);
      box(bx, 14, 38, 28, on ? C.panelHi : C.panel, C.line);
      text(label, bx + 19, 32, 12, on ? C.warm : C.dim, 'center');
      hits.push({ x: bx, y: 14, w: 38, h: 28, fn });
      bx += 44;
    }
  }

  function drawBoard() {
    const S = window.SIM;
    for (let y = 0; y < D.ROWS; y++) {
      for (let x = 0; x < D.COLS; x++) {
        const i = S.idx(x, y);
        const px = BX + x * CELL, py = BY + y * CELL;
        const g = state.panes[i];
        if (g) { drawPane(px, py, g, i); continue; }

        const cell = state.cells[i];
        const f = cell.fix ? D.fixture(cell.fix) : null;
        // floor: soil under a bed, slate under a work bench, brick everywhere else
        const mat = f && f.family === 'bed' ? 'soil' : f && f.family === 'work' ? 'slate' : 'brick';
        ctx.save();
        ctx.beginPath(); ctx.rect(px, py, CELL, CELL); ctx.clip();
        window.ART.plate(ctx, mat, px - (px % 256), py - (py % 256), 256 + CELL, 256 + CELL,
          mat === 'brick' ? '#5c372c' : mat === 'soil' ? '#342a22' : '#333a44');
        ctx.restore();
        window.ART.tint(ctx, px, py, CELL, CELL, state.temp[i]);

        if (cell.fix) window.ART.drawFitting(ctx, cell.fix, px + 1, py + 1);
        if (cell.crop) {
          const cr = D.crop(cell.crop.id);
          const stage = cell.crop.dead ? 3
            : Math.min(3, Math.floor((cell.crop.hours / cr.hours) * 3.999));
          window.ART.drawCrop(ctx, cell.crop.id, stage, cell.crop.dead, px + 5, py + 5);
          if (!cell.crop.dead && cell.crop.hours >= cr.hours) {
            // ready: a soft ring so a ripe bed is findable without reading anything
            ctx.strokeStyle = C.good; ctx.lineWidth = 2;
            ctx.strokeRect(px + 2.5, py + 2.5, CELL - 5, CELL - 5);
          } else if (!cell.crop.dead && cell.crop.chill > 0) {
            ctx.fillStyle = C.cold;
            ctx.fillRect(px + 3, py + CELL - 6, Math.min(CELL - 6, (cell.crop.chill / cr.chillDeath) * (CELL - 6)), 3);
          }
        }
        ctx.strokeStyle = 'rgba(0,0,0,0.22)';
        ctx.lineWidth = 1;
        ctx.strokeRect(px + 0.5, py + 0.5, CELL - 1, CELL - 1);
      }
    }
    for (const p of state.people) {
      window.ART.drawPerson(ctx, p.id, !!p.gotSeat, BX + p.x * CELL + 9, BY + p.y * CELL + 5);
      if (p.met) { ctx.fillStyle = C.good; ctx.fillRect(BX + p.x * CELL + 32, BY + p.y * CELL + 4, 4, 4); }
    }
    if (hover >= 0) {
      const hx = hover % D.COLS, hy = Math.floor(hover / D.COLS);
      ctx.strokeStyle = sel ? C.warm : C.paper;
      ctx.lineWidth = 2;
      ctx.strokeRect(BX + hx * CELL + 1, BY + hy * CELL + 1, CELL - 2, CELL - 2);
      drawTip(hover);
    }
  }

  /**
   * THE PERIMETER. Forty-four of these ring every screenshot, so they carry more of the look than
   * anything else on the board.
   *
   * ⚠️ The first version filled a flat slab and scratched two black lines on the broken ones, and
   * it read as a row of dark tiles with a punctuation mark in each — it made the whole building
   * look like a spreadsheet border. What a pane has to say at a glance is (1) how sound it is and
   * (2) that there is WEATHER on the other side of it, because that is the thing the player is
   * fighting. So: a timber frame, glass whose tone steps up the ladder, a diagonal light on
   * anything intact, frost that thickens as the night gets colder, and an actual HOLE with the
   * night showing through on a broken one.
   */
  function drawPane(px, py, g, i) {
    const out = window.SIM.outsideTemp(state, state.day, state.hour);
    const night = window.SIM.isNight(state.hour);
    const glass = { broken: '#1b2029', patched: '#4a6570', single: '#63909c', double: '#8dbcc4' };

    box(px, py, CELL, CELL, '#241d17');                        // the frame, in timber tones
    ctx.fillStyle = '#33291f';
    ctx.fillRect(px + 1, py + 1, CELL - 2, 2);
    ctx.fillRect(px + 1, py + CELL - 3, CELL - 2, 2);

    if (g === 'door') {
      box(px + 3, py + 3, CELL - 6, CELL - 6, '#6b4a2c');
      ctx.fillStyle = '#573a22';
      for (let k = 0; k < 4; k++) ctx.fillRect(px + 5, py + 7 + k * 8, CELL - 10, 1);
      ctx.fillStyle = '#c9a86a';
      ctx.fillRect(px + CELL - 11, py + CELL / 2 - 1, 4, 3);   // the handle
      return;
    }
    if (g === 'boarded') {
      box(px + 3, py + 3, CELL - 6, CELL - 6, '#5b432a');
      ctx.fillStyle = '#3a2a1b';
      for (let k = 0; k < 3; k++) ctx.fillRect(px + 4, py + 8 + k * 10, CELL - 8, 2);
      ctx.fillStyle = '#82623c';
      for (let k = 0; k < 3; k++) ctx.fillRect(px + 6, py + 5 + k * 10, CELL - 12, 1);
      return;
    }

    box(px + 3, py + 3, CELL - 6, CELL - 6, glass[g] || '#3d5a63');

    if (g === 'broken') {
      // a real hole: the night, or the daylight, showing straight through it
      ctx.fillStyle = night ? '#0b0e14' : '#39424f';
      ctx.beginPath();
      const s = (i * 7919) % 5;
      ctx.moveTo(px + 6 + s, py + 5);
      ctx.lineTo(px + CELL - 7, py + 9 + s);
      ctx.lineTo(px + CELL - 9, py + CELL - 8);
      ctx.lineTo(px + 8, py + CELL - 6 - s);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = '#9fb6c4'; ctx.lineWidth = 1;      // the surviving shards catching light
      ctx.stroke();
    } else {
      // a diagonal light across sound glass, brighter the better the glazing
      ctx.save();
      ctx.beginPath(); ctx.rect(px + 3, py + 3, CELL - 6, CELL - 6); ctx.clip();
      ctx.globalAlpha = g === 'double' ? 0.30 : g === 'single' ? 0.22 : 0.14;
      ctx.fillStyle = '#eaf6f8';
      ctx.beginPath();
      ctx.moveTo(px + 4, py + CELL - 10); ctx.lineTo(px + CELL - 12, py + 2);
      ctx.lineTo(px + CELL - 5, py + 2); ctx.lineTo(px + 11, py + CELL - 10);
      ctx.closePath(); ctx.fill();
      ctx.restore();
      if (g === 'double') {                                  // the second pane, as a thin inner line
        ctx.strokeStyle = 'rgba(234,246,248,0.35)'; ctx.lineWidth = 1;
        ctx.strokeRect(px + 6.5, py + 6.5, CELL - 13, CELL - 13);
      }
    }

    // frost, heavier the colder it is out. The weather is visible from inside, which is the point.
    const frost = Math.max(0, Math.min(1, (3 - out) / 15));
    if (frost > 0.04) {
      ctx.save();
      ctx.globalAlpha = frost * 0.55;
      ctx.fillStyle = '#dcecef';
      for (let k = 0; k < 9; k++) {
        const a = ((i * 37 + k * 91) % 26) + 5, b = ((i * 53 + k * 17) % 26) + 5;
        ctx.fillRect(px + a, py + b, 2, 2);
        if (k % 3 === 0) ctx.fillRect(px + a - 1, py + b + 2, 4, 1);
      }
      ctx.restore();
    }
    ctx.strokeStyle = 'rgba(0,0,0,0.4)'; ctx.lineWidth = 1;
    ctx.strokeRect(px + 0.5, py + 0.5, CELL - 1, CELL - 1);
  }

  function drawTip(i) {
    const S = window.SIM;
    const lines = [];
    if (state.panes[i]) {
      const gl = D.glazing(state.panes[i]);
      lines.push(gl.name, gl.desc);
      if (state.panes[i] !== 'door') {
        const nx = D.glazing(S.nextGlazing(state.panes[i]));
        if (nx && nx.id !== state.panes[i]) lines.push(`Click to fit ${nx.name.toLowerCase()} — ${nx.cost} coin`);
      }
    } else {
      lines.push(`${state.temp[i].toFixed(1)}°`);
      const cell = state.cells[i];
      if (cell.fix) {
        const f = D.fixture(cell.fix);
        lines.push(f.name, f.desc);
      }
      if (cell.crop) {
        const cr = D.crop(cell.crop.id);
        if (cell.crop.dead) lines.push(`${cr.name} — lost. Click to clear.`);
        else {
          const pct = Math.floor((cell.crop.hours / cr.hours) * 100);
          lines.push(`${cr.name} — ${Math.min(100, pct)}% grown, wants ${cr.min}° or better`);
          if (cell.crop.chill > 0) lines.push(`Chilled ${Math.floor((cell.crop.chill / cr.chillDeath) * 100)}%`);
        }
      }
    }
    const w = Math.max(...lines.map((l) => { ctx.font = '12px ui-sans-serif, system-ui, sans-serif'; return ctx.measureText(l).width; })) + 20;
    const hgt = 8 + lines.length * 16;
    const hx = i % D.COLS, hy = Math.floor(i / D.COLS);
    let tx = BX + hx * CELL + CELL + 6, ty = BY + hy * CELL;
    if (tx + w > BX + 600) tx = BX + hx * CELL - w - 6;
    if (ty + hgt > BY + 360) ty = BY + 360 - hgt;
    box(tx, ty, w, hgt, 'rgba(16,13,20,0.95)', C.line);
    lines.forEach((l, k) => text(l, tx + 10, ty + 20 + k * 16, 12, k === 0 ? C.paper : C.dim));
  }

  function drawLog() {
    box(LOG_X, LOG_Y, LOG_W, LOG_H, C.panel, C.line);
    const cols = { good: C.good, great: C.warm, loss: C.bad, person: C.paper, event: C.warm, quiet: C.dim };
    const lines = state.log.slice(-9);
    lines.forEach((l, k) => {
      text(l.text, LOG_X + 12, LOG_Y + 22 + k * 18, 12.5, cols[l.kind] || C.dim);
    });
    if (!lines.length) text('Nothing yet.', LOG_X + 12, LOG_Y + 22, 12.5, C.dim);
  }

  /* ── the panel ───────────────────────────────────────────────────────────────────────────── */
  function drawPanel() {
    box(PANEL_X, PANEL_Y, PANEL_W, H - PANEL_Y - 14, C.panel, C.line);
    const tabs = [['build', 'BUILD'], ['sow', 'SOW'], ['room', 'ROOM']];
    tabs.forEach(([id, label], k) => {
      const x = PANEL_X + 8 + k * 101, y = PANEL_Y + 8;
      box(x, y, 97, 28, tab === id ? C.panelHi : C.panel, C.line);
      text(label, x + 48, y + 19, 12, tab === id ? C.warm : C.dim, 'center', 700);
      hits.push({ x, y, w: 97, h: 28, fn: () => { tab = id; sel = null; } });
    });
    if (tab === 'build') drawBuild();
    else if (tab === 'sow') drawSow();
    else drawRoom();
  }

  function rowHit(x, y, w, h, fn) { hits.push({ x, y, w, h, fn }); }

  function drawBuild() {
    let y = PANEL_Y + 46;
    const S = window.SIM;
    const fams = [['heat', 'Heat'], ['mass', 'Holding heat'], ['bed', 'Beds'], ['comfort', 'Comfort'], ['work', 'Work']];
    for (const [fam, label] of fams) {
      const items = D.FIXTURES.filter((f) => f.family === fam && state.day >= f.unlockDay);
      if (!items.length) continue;
      text(label.toUpperCase(), PANEL_X + 12, y, 10.5, C.dim, 'left', 700);
      y += 6;
      for (const f of items) {
        const locked = f.unlockWord && state.word < f.unlockWord;
        const poor = state.coin < f.cost;
        const on = sel && sel.kind === 'fix' && sel.id === f.id;
        box(PANEL_X + 8, y, PANEL_W - 16, 30, on ? C.panelHi : 'rgba(0,0,0,0.16)', on ? C.warm : C.line);
        window.ART.drawFittingAt(ctx, f.id, PANEL_X + 12, y + 4, 22);
        text(f.name, PANEL_X + 40, y + 20, 12.5, locked ? C.dim : poor ? '#b9a08a' : C.paper);
        text(locked ? `word ${f.unlockWord}` : `${f.cost}`, PANEL_X + PANEL_W - 14, y + 20, 12,
          locked ? C.bad : poor ? C.bad : C.good, 'right');
        if (!locked) rowHit(PANEL_X + 8, y, PANEL_W - 16, 30, () => { sel = { kind: 'fix', id: f.id }; });
        y += 33;
      }
      y += 4;
    }
    y += 2;
    const rm = sel && sel.kind === 'remove';
    box(PANEL_X + 8, y, PANEL_W - 16, 28, rm ? C.panelHi : 'rgba(0,0,0,0.16)', rm ? C.warm : C.line);
    text('Take something out  (or right-click)', PANEL_X + PANEL_W / 2, y + 18, 12, C.dim, 'center');
    rowHit(PANEL_X + 8, y, PANEL_W - 16, 28, () => { sel = rm ? null : { kind: 'remove' }; });
    y += 36;
    if (sel && sel.kind === 'fix') {
      const f = D.fixture(sel.id);
      wrapText(f.desc, PANEL_X + 12, y, PANEL_W - 24, 15, 12, C.dim);
    }
  }

  function drawSow() {
    let y = PANEL_Y + 50;
    text('A bed grows what the room is warm enough for.', PANEL_X + 12, y, 12, C.dim);
    y += 22;
    for (const cr of D.CROPS) {
      const locked = state.day < cr.unlockDay;
      const have = state.seeds[cr.id] || 0;
      const on = sel && sel.kind === 'seed' && sel.id === cr.id;
      box(PANEL_X + 8, y, PANEL_W - 16, 34, on ? C.panelHi : 'rgba(0,0,0,0.16)', on ? C.warm : C.line);
      window.ART.drawCropAt(ctx, cr.id, 3, PANEL_X + 11, y + 2, 30);
      text(locked ? '???' : cr.name, PANEL_X + 46, y + 15, 12.5, locked ? C.dim : C.paper);
      text(locked ? `from day ${cr.unlockDay + 1}` : `wants ${cr.min}°  ·  worth ${cr.yield}`,
        PANEL_X + 46, y + 29, 11, C.dim);
      if (!locked) {
        text(`${have}`, PANEL_X + PANEL_W - 58, y + 22, 13, have ? C.good : C.dim, 'right');
        const bx = PANEL_X + PANEL_W - 50;
        box(bx, y + 5, 42, 24, 'rgba(0,0,0,0.25)', C.line);
        text(`buy ${cr.seed}`, bx + 21, y + 21, 10.5, state.coin >= cr.seed ? C.paper : C.bad, 'center');
        rowHit(bx, y + 5, 42, 24, () => act(window.SIM.buySeed(state, cr.id), 'coin'));
        rowHit(PANEL_X + 8, y, PANEL_W - 66, 34, () => { sel = { kind: 'seed', id: cr.id }; });
      }
      y += 37;
    }
  }

  function drawRoom() {
    const S = window.SIM;
    let y = PANEL_Y + 52;
    // thermostat
    text('HOW WARM TO KEEP IT', PANEL_X + 12, y, 10.5, C.dim, 'left', 700);
    y += 10;
    box(PANEL_X + 8, y, PANEL_W - 16, 40, 'rgba(0,0,0,0.18)', C.line);
    text(`${state.target}°`, PANEL_X + PANEL_W / 2, y + 27, 18, C.warm, 'center', 700);
    for (const [dx, d] of [[14, -1], [PANEL_W - 56, 1]]) {
      box(PANEL_X + dx, y + 8, 34, 24, C.panel, C.line);
      text(d < 0 ? '−' : '+', PANEL_X + dx + 17, y + 25, 15, C.paper, 'center');
      rowHit(PANEL_X + dx, y + 8, 34, 24, () => { state.target = Math.max(4, Math.min(26, state.target + d)); });
    }
    y += 48;
    const damp = Math.round((state.lastDamper === undefined ? 1 : state.lastDamper) * 100);
    text(`The fire is working at ${damp}%.`, PANEL_X + 12, y, 12, damp > 80 ? C.warm : C.dim);
    y += 16;
    wrapText('A full room needs less fire. That is not a bonus, it is the people warming it.',
      PANEL_X + 12, y, PANEL_W - 24, 15, 11.5, C.dim);
    y += 42;

    // wood and produce
    for (const [label, sub, fn, okCol] of [
      [`Buy 40 wood`, `${Math.ceil(40 * S.FUEL_PRICE)} coin`, () => act(S.buyFuel(state, 40), 'coin'), state.coin >= Math.ceil(40 * S.FUEL_PRICE)],
      [`Sell produce at the gate`, `${state.produce} produce`, () => act(S.sellProduce(state), 'coin'), state.produce > 0],
    ]) {
      box(PANEL_X + 8, y, PANEL_W - 16, 32, 'rgba(0,0,0,0.18)', C.line);
      text(label, PANEL_X + 14, y + 20, 12.5, okCol ? C.paper : C.dim);
      text(sub, PANEL_X + PANEL_W - 14, y + 20, 12, okCol ? C.good : C.dim, 'right');
      rowHit(PANEL_X + 8, y, PANEL_W - 16, 32, fn);
      y += 36;
    }
    y += 6;
    const boardSel = sel && sel.kind === 'board';
    box(PANEL_X + 8, y, PANEL_W - 16, 30, boardSel ? C.panelHi : 'rgba(0,0,0,0.18)', boardSel ? C.warm : C.line);
    text(`Board a broken pane  ·  ${D.BOARDED.cost}`, PANEL_X + 14, y + 19, 12, C.paper);
    rowHit(PANEL_X + 8, y, PANEL_W - 16, 30, () => { sel = boardSel ? null : { kind: 'board' }; });
    y += 34;
    wrapText('Cheap, and it blocks the light for the rest of the winter. Glass is better if you can find it.',
      PANEL_X + 12, y, PANEL_W - 24, 14, 11, C.dim);
    y += 40;

    text('WHO STAYED', PANEL_X + 12, y, 10.5, C.dim, 'left', 700);
    y += 8;
    if (!state.residents.length) {
      wrapText('Nobody yet. Put in a place for a job — a potting bench, a wood store — and someone who keeps coming back will take it on.',
        PANEL_X + 12, y + 10, PANEL_W - 24, 15, 11.5, C.dim);
    } else {
      for (const r of state.residents) {
        const role = D.ROLES[r.role];
        box(PANEL_X + 8, y, PANEL_W - 16, 30, 'rgba(0,0,0,0.18)', C.line);
        text(r.name, PANEL_X + 14, y + 13, 12, C.paper);
        text(role.desc, PANEL_X + 14, y + 25, 10.5, C.dim);
        y += 33;
      }
    }
  }

  function wrapText(str, x, y, maxW, lh, size, col) {
    ctx.font = `500 ${size}px ui-sans-serif, "Segoe UI", system-ui, sans-serif`;
    const words = String(str).split(' ');
    let line = '', yy = y;
    for (const w of words) {
      const t = line ? line + ' ' + w : w;
      if (ctx.measureText(t).width > maxW && line) { text(line, x, yy, size, col); line = w; yy += lh; }
      else line = t;
    }
    if (line) text(line, x, yy, size, col);
    return yy + lh;
  }

  function drawEnding() {
    ctx.fillStyle = 'rgba(10,8,14,0.86)';
    ctx.fillRect(0, 0, W, H);
    // ⚠️ 388 tall, not 340: at 340 the 'Another winter' button sat ON TOP of the last two stat
    // rows. Six rows at 20px from by+186 end at by+306; the button starts at by+342.
    const bw = 620, bh = 388, bx = (W - bw) / 2, by = (H - bh) / 2;
    box(bx, by, bw, bh, C.panel, C.warm);
    text('SPRING', bx + bw / 2, by + 48, 26, C.warm, 'center', 700);
    text(ending.title, bx + bw / 2, by + 82, 17, C.paper, 'center', 600);
    wrapText(ending.text, bx + 40, by + 116, bw - 80, 20, 13.5, C.dim);
    const s = state.stats;
    const rows = [
      ['People through the door', s.visits],
      ['Who got what they came for', s.satisfied],
      ['Harvests', s.harvests],
      ['Meals cooked', s.meals],
      ['People who stayed on', state.residents.length],
      ['Panes mended', s.panesFixed],
    ];
    rows.forEach((r, i) => {
      const yy = by + 186 + i * 20;
      text(r[0], bx + 40, yy, 12.5, C.dim);
      text(String(r[1]), bx + bw - 40, yy, 12.5, C.paper, 'right');
    });
    box(bx + bw / 2 - 90, by + bh - 46, 180, 32, C.panelHi, C.warm);
    text('Another winter', bx + bw / 2, by + bh - 25, 13, C.warm, 'center', 600);
    hits.push({
      x: bx + bw / 2 - 90, y: by + bh - 46, w: 180, h: 32,
      fn: () => { window.SAVE.clear(); state = window.SIM.createState((Date.now() ^ 0x51e2) >>> 0); firstDay(); ending = null; running = true; },
    });
  }

  /* ── the capture and test hook ────────────────────────────────────────────────────────────
   * ⚠️ A DELIBERATE, DOCUMENTED HOOK IN SHIPPED CODE. `smoke.js` and the gallery capture need to
   * reach a late-winter room, and there is no honest way to do that through the UI — nine seconds
   * of wall clock at the fastest speed is a day and a half, so every screenshot would be of the
   * opening week and the game's whole payoff would be invisible on its own store page.
   *
   * It exposes only what a capture needs: read the state, advance the SIM, choose a tab. It cannot
   * grant coin or skip a cost, so it is not a cheat surface — and a player who opens the console
   * and fast-forwards their own winter is welcome to.
   */
  window.WARMROOM = {
    get state() { return state; },
    /* ⚠️ THIS MUST DO THE END-OF-WINTER BOOKKEEPING THAT `step()` DOES, or the hook can drive the
     * simulation past day 90 while the PRESENTATION never notices. It did exactly that: a capture
     * advanced to the end, asserted `state.ended === true` — which was honestly true — and
     * photographed a perfectly ordinary board, because the ending overlay is drawn from a variable
     * that only `step()` sets. A green assertion on the STATE beside a wrong PICTURE. */
    advance(hours) {
      for (let i = 0; i < hours && !state.ended; i++) window.SIM.stepHour(state);
      if (state.ended && !ending) ending = window.SIM.ending(state);
    },
    /** What the presentation currently believes — so a capture can assert the OVERLAY, not the flag. */
    get ending() { return ending; },
    tab(t) { tab = t; sel = null; },
    pause() { running = false; },
    resume() { running = true; },
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
