/* THE WARM ROOM — sound.js
 *
 * Procedural WebAudio. No files, no licences, no attribution burden, and — per Playbook_itch §15f
 * — self-contained synthesis means the itch AI disclosure for SOUNDS is honestly "no".
 *
 * ⭐ WHY THIS FILE IS WORTH ITS SIZE IN A JAM ENTRY: `uplifting-game-jam-9` scores entries on
 * SEVEN categories and one of them is Music/Sfx, which is the category jam entries most often skip
 * altogether. A game with a considered soundscape is competing against a field where many entries
 * are silent.
 *
 * The soundscape is the game's thesis in audio: a cold empty room is wind and a ticking stove,
 * and as people arrive the room gains a low warm hum. Nothing is a jingle; nothing loops audibly.
 *
 * ⚠️ AUTOPLAY POLICY: browsers refuse to start audio without a gesture. The context is created
 * lazily on the first click and every entry point re-checks, so a muted first frame can never
 * leave the game permanently silent.
 */
'use strict';

const SOUND = (() => {
  let ctx = null;
  let master = null;
  let bedGain = null;
  let windFilter = null;
  let started = false;
  let muted = false;

  function ensure() {
    if (ctx) return true;
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return false;
      ctx = new AC();
      master = ctx.createGain();
      master.gain.value = muted ? 0 : 0.5;
      master.connect(ctx.destination);
      return true;
    } catch (e) { ctx = null; return false; }
  }

  /** Pink-ish noise buffer, reused for wind and for the fire. Generated once. */
  let noiseBuf = null;
  function noise() {
    if (noiseBuf) return noiseBuf;
    const len = ctx.sampleRate * 3;
    noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0;
    for (let i = 0; i < len; i++) {
      const w = Math.random() * 2 - 1;
      b0 = 0.99765 * b0 + w * 0.0990460;
      b1 = 0.96300 * b1 + w * 0.2965164;
      b2 = 0.57000 * b2 + w * 1.0526913;
      d[i] = (b0 + b1 + b2 + w * 0.1848) * 0.16;
    }
    return noiseBuf;
  }

  /**
   * THE THEME. A 55-second loop rendered by the factory's own synth (Kernel/capture/make_audio.js)
   * from Internal_Ops/audio_specs/music_the_warm_room.json — our IP, no licence, no attribution,
   * and no Generative-AI audio tag, because self-contained procedural synthesis is not generative
   * AI. It ships as one .ogg rather than being synthesised in the page because a four-voice
   * arrangement wants to be COMPOSED, and the arrangement is the point: section A is the empty
   * room, section B is the same harmony with people in it.
   *
   * ⚠️ It is deliberately quiet and it sits UNDER the procedural wind, not instead of it. A cozy
   * game whose music is louder than its room is a menu screen with a garden painted on it.
   */
  let music = null;
  function startMusic() {
    if (music) return;
    try {
      music = new Audio('audio/warm_room_theme.ogg');
      music.loop = true;
      music.volume = muted ? 0 : 0.34;
      const p = music.play();
      // a rejected play() is the autoplay policy, not an error — the next click retries
      if (p && p.catch) p.catch(() => {});
    } catch (e) { music = null; }
  }

  /** The continuous bed: wind outside, filtered by how sound the glass is. */
  function startBed() {
    startMusic();
    if (!ensure() || started) return;
    started = true;
    const src = ctx.createBufferSource();
    src.buffer = noise();
    src.loop = true;
    windFilter = ctx.createBiquadFilter();
    windFilter.type = 'lowpass';
    windFilter.frequency.value = 420;
    bedGain = ctx.createGain();
    bedGain.gain.value = 0.10;
    src.connect(windFilter); windFilter.connect(bedGain); bedGain.connect(master);
    src.start();
  }

  /**
   * The room's own voice. `warmth` is 0..1 (how far the room is above outside) and `people` is the
   * headcount — together they open the filter and lift a low hum, so a full warm room literally
   * sounds different from a cold empty one without a single new sample.
   */
  let hum = null, humGain = null;
  function setRoom(warmth, people) {
    if (!ctx || !started) return;
    const w = Math.max(0, Math.min(1, warmth));
    const p = Math.max(0, Math.min(1, people / 10));
    if (windFilter) windFilter.frequency.setTargetAtTime(300 + 900 * (1 - w * 0.8), ctx.currentTime, 1.5);
    if (bedGain) bedGain.gain.setTargetAtTime(0.13 - 0.07 * w, ctx.currentTime, 1.5);
    if (!hum) {
      hum = ctx.createOscillator();
      hum.type = 'sine';
      hum.frequency.value = 96;
      humGain = ctx.createGain();
      humGain.gain.value = 0;
      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass'; lp.frequency.value = 300;
      hum.connect(lp); lp.connect(humGain); humGain.connect(master);
      hum.start();
    }
    humGain.gain.setTargetAtTime(0.015 + 0.055 * p * (0.4 + 0.6 * w), ctx.currentTime, 2.0);
  }

  /** One short tone with a soft envelope. Everything below is built from this. */
  function blip(freq, dur, type, vol, delay, slideTo) {
    if (!ensure()) return;
    const t0 = ctx.currentTime + (delay || 0);
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(freq, t0);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol === undefined ? 0.12 : vol, t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(master);
    o.start(t0); o.stop(t0 + dur + 0.05);
  }

  /* A warm major-ish set. Nothing here resolves to a fanfare — the game never congratulates the
   * player, it just sounds a little better as the room fills. */
  const A = { c: 261.63, d: 293.66, e: 329.63, g: 392.00, a: 440.00, c2: 523.25, e2: 659.25, g2: 783.99 };

  const S = {
    place: () => { blip(A.d, 0.10, 'triangle', 0.10); blip(A.g, 0.14, 'triangle', 0.07, 0.05); },
    remove: () => blip(A.d, 0.14, 'triangle', 0.07, 0, A.c * 0.7),
    sow: () => { blip(A.e, 0.09, 'sine', 0.08); blip(A.g, 0.12, 'sine', 0.06, 0.06); },
    harvest: () => { blip(A.g, 0.10, 'triangle', 0.10); blip(A.c2, 0.12, 'triangle', 0.09, 0.07); blip(A.e2, 0.16, 'sine', 0.07, 0.14); },
    coin: () => { blip(A.e2, 0.07, 'square', 0.045); blip(A.g2, 0.10, 'square', 0.035, 0.05); },
    arrive: () => { blip(A.c, 0.13, 'sine', 0.07); blip(A.e, 0.16, 'sine', 0.055, 0.07); },
    /** ⭐ A resident joining is the biggest thing that happens in the game, so it is the only
     *  cue with three notes and a real chord underneath it. */
    resident: () => {
      blip(A.c, 0.34, 'sine', 0.075);
      blip(A.e, 0.34, 'sine', 0.065, 0.09);
      blip(A.g, 0.40, 'sine', 0.070, 0.18);
      blip(A.c2, 0.46, 'triangle', 0.045, 0.27);
    },
    glass: () => { blip(880, 0.06, 'square', 0.035); blip(1180, 0.09, 'sine', 0.03, 0.04); },
    lose: () => blip(A.e, 0.30, 'sine', 0.06, 0, A.c * 0.6),
    day: () => blip(A.a, 0.18, 'sine', 0.04),
    event: () => { blip(A.g, 0.22, 'sine', 0.06); blip(A.d, 0.28, 'sine', 0.05, 0.12); },
    deny: () => blip(150, 0.09, 'square', 0.045),
    spring: () => {
      [A.c, A.e, A.g, A.c2, A.e2].forEach((f, i) => blip(f, 0.6, 'sine', 0.07, i * 0.13));
    },
  };

  function play(name) {
    if (muted) return;
    const f = S[name];
    if (f) { ensure(); f(); }
  }
  function toggleMute() {
    muted = !muted;
    if (master && ctx) master.gain.setTargetAtTime(muted ? 0 : 0.5, ctx.currentTime, 0.05);
    // ⚠️ the theme is an <audio> element, NOT on the WebAudio graph — muting the master gain does
    // not touch it, and the first version of this left the music playing over a "sound off" button
    if (music) music.volume = muted ? 0 : 0.34;
    return muted;
  }
  function isMuted() { return muted; }
  function resume() {
    if (ctx && ctx.state === 'suspended') ctx.resume();
    if (music && music.paused && !muted) { const p = music.play(); if (p && p.catch) p.catch(() => {}); }
  }

  return { play, startBed, startMusic, setRoom, toggleMute, isMuted, resume, ensure, names: Object.keys(S) };
})();

if (typeof window !== 'undefined') window.SOUND = SOUND;
