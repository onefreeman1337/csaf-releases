/* THE WARM ROOM — save.js
 *
 * Autosave at every day-end, and on the way out of the tab. There is NO death state in this game
 * (wing ledger B4, and the jam's own brief), so a save is never a checkpoint you fall back to — it
 * is simply where the winter had got to. That is why it is safe to write it constantly.
 *
 * ⚠️ THE RNG STATE IS PART OF THE SAVE. Without it, reloading would reroll every future visitor
 * and a player could refresh the page until the person they wanted walked in. It also means the
 * balance probe and a real playthrough follow the same sequence, which is the only reason the
 * probe's numbers describe the game anyone actually plays.
 */
'use strict';

const SAVE = (() => {
  const KEY = 'csaf.thewarmroom.v1';

  function write(state) {
    try {
      localStorage.setItem(KEY, JSON.stringify({
        v: 1, at: Date.now(), state,
      }));
      return true;
    } catch (e) {
      /* Private browsing, a full quota, or a blocked origin. A failed save must never interrupt
       * play — the room carries on and the player loses only the ability to come back to it. */
      return false;
    }
  }

  function read() {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return null;
      const box = JSON.parse(raw);
      if (!box || box.v !== 1 || !box.state) return null;
      const s = box.state;
      /* ⛔ VALIDATE THE SHAPE, DO NOT TRUST IT. A save written by an older build, or edited by
       * hand, must be REFUSED rather than half-loaded — a state missing `temp` would throw on the
       * first frame and lose a whole winter to a black screen. */
      if (!Array.isArray(s.temp) || !Array.isArray(s.cells) || !Array.isArray(s.panes)) return null;
      if (typeof s.day !== 'number' || typeof s.hour !== 'number') return null;
      if (s.temp.length !== s.panes.length || s.cells.length !== s.panes.length) return null;
      return s;
    } catch (e) {
      return null;
    }
  }

  function clear() {
    try { localStorage.removeItem(KEY); return true; } catch (e) { return false; }
  }

  function has() { return read() !== null; }

  return { write, read, clear, has, KEY };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = SAVE;
if (typeof window !== 'undefined') window.SAVE = SAVE;
