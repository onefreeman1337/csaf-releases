/* THE WARM ROOM — data.js
 *
 * ALL CONTENT LIVES HERE AND NOTHING ELSE DOES. sim.js contains the rules; this file contains the
 * things the rules are applied to. The split is not tidiness — it is the Gate 3 mitigation written
 * into the architecture. The jam's second theme is still "THEME TBA" at build time, so when it
 * drops the entry has to change WHAT is in the room, not HOW the room works: a visitor roster, a
 * calendar event, and flavour strings. Anything that would force a change to sim.js is a design
 * mistake at this stage, and this comment is here so a later session can tell the difference.
 *
 * Balance figures carry their units. A heat figure is in "warmth units per hour" as consumed by
 * sim.js's field update, NOT in degrees — degrees are what the field settles to, which is an
 * OUTPUT and can only be read off the balance probe.
 */
'use strict';

const DATA = (() => {
  /* ── the building ───────────────────────────────────────────────────────────────────────────
   * 15 x 9 cells. The outermost ring is glass (panes); everything inside is floor the player can
   * build on. Two door cells break the ring on the south wall — a door leaks more than glass and
   * cannot be glazed, which is why the bench nearest the door is always the cold seat.
   */
  const COLS = 15;
  const ROWS = 9;

  /* Outside temperature across the winter, in degrees C, as a per-day curve.
   * Day 0 is the first day of the ninety. The Longest Night at day 45 is a scripted spike DOWN
   * applied by the calendar, not by this curve — keeping them separate means the set-piece can be
   * retuned without moving the whole winter. */
  const WINTER = {
    days: 90,
    baseHigh: 6.0,     // early-winter daytime high
    deepLow: -7.0,    // coldest daily low, reached around the midpoint
    dayNightSwing: 5.5,
  };

  /* ── materials the perimeter can be in ──────────────────────────────────────────────────────
   * `leak` is warmth units lost per hour per degree of difference with outside. Lower is better.
   * The ladder is deliberately steep at the bottom: patching a broken pane is the single highest
   * value-per-coin action in the game for the first two weeks, and it should feel that way.
   */
  /* ⚠️ BOARDING IS NOT A RUNG ON THIS LADDER, AND IT USED TO BE, WHICH WAS A DESIGN BUG.
   * With `boarded` sitting between `broken` and `patched`, the cheapest repair on a broken pane
   * stepped the player into a light-blocking board — so "mend the glass" actively hurt the beds
   * behind it, and the glazier role (which always steps up one rung) methodically boarded up the
   * whole building. Boarding is a SIDE OPTION with a real trade, not a stage on the way to glass:
   * it is the cheapest way to stop a draught and it costs you that wall's sunlight all winter.
   * The ladder below is now monotonic in BOTH leak and cost, which `test_sim.js` asserts. */
  const GLAZING = [
    { id: 'broken', name: 'Broken pane', leak: 0.300, cost: 0, desc: 'Wind straight through it.' },
    { id: 'patched', name: 'Patched glass', leak: 0.125, cost: 14, desc: 'Salvaged glass and putty. Lets the sun back in.' },
    { id: 'single', name: 'Sound glass', leak: 0.073, cost: 30, desc: 'A whole new pane, properly bedded.' },
    { id: 'double', name: 'Double glazed', leak: 0.045, cost: 70, desc: 'Two panes and a hand-width of still air between them.' },
  ];
  const BOARDED = { id: 'boarded', name: 'Boarded', leak: 0.170, cost: 8, blocksLight: true, desc: 'A board and four nails. Blocks the wind, and the light with it.' };
  const DOOR = { id: 'door', name: 'Door', leak: 0.220, cost: 0, desc: 'It has to open. That is the whole problem with a door.' };

  /* ── fixtures the player places on floor cells ──────────────────────────────────────────────
   * Every fixture is one of five families and each family interacts with a different pair of
   * systems, which is how the complexity floor is actually met rather than asserted:
   *
   *   heat     -> HEAT              (makes warmth, burns fuel)
   *   mass     -> HEAT over TIME    (buffers warmth, so it changes WHEN not HOW MUCH)
   *   bed      -> HEAT into GROWTH  (converts held temperature into produce)
   *   comfort  -> HEAT into PEOPLE  (converts held temperature into willingness to stay)
   *   work     -> PEOPLE into HEAT/GROWTH (a place a resident stands to do their job)
   */
  const FIXTURES = [
    {
      id: 'brazier', family: 'heat', name: 'Brazier', cost: 0, tier: 1, unlockDay: 0,
      heat: 9.0, fuelPerHour: 0.55, radius: 2,
      desc: 'An iron basket on legs. Hot right beside it, useless four steps away.',
    },
    {
      id: 'stove', family: 'heat', name: 'Iron stove', cost: 90, tier: 2, unlockDay: 6, unlockWord: 6,
      heat: 21.0, fuelPerHour: 0.95, radius: 3,
      desc: 'A closed firebox. Twice the warmth from half again the wood, and it holds through a lull.',
    },
    {
      id: 'banked', family: 'heat', name: 'Banked stove', cost: 340, tier: 3, unlockDay: 22, unlockWord: 26,
      heat: 26.0, fuelPerHour: 1.15, radius: 4, nightBonus: 0.35,
      desc: 'Damped down and packed with ash, it gives back most of the night for nothing.',
    },
    {
      id: 'barrel', family: 'mass', name: 'Water barrel', cost: 45, tier: 1, unlockDay: 2,
      capacity: 90, exchange: 0.16,
      desc: 'Fills with warmth all afternoon and hands it back after dark. It makes the day colder and the night survivable.',
    },
    {
      id: 'cistern', family: 'mass', name: 'Slate cistern', cost: 190, tier: 2, unlockDay: 30, unlockWord: 34,
      capacity: 260, exchange: 0.13,
      desc: 'Half a tonne of water under slate. Slow to charge, and it will carry you through a whole bad night.',
    },
    {
      id: 'compost', family: 'mass', name: 'Compost heap', cost: 30, tier: 1, unlockDay: 4,
      heat: 4.6, radius: 2, soil: 0.35, needsMatter: 0.4,
      desc: 'It is warm because it is busy. Feed it trimmings and it never goes out.',
    },
    {
      id: 'reflector', family: 'mass', name: 'Tin reflector', cost: 60, tier: 1, unlockDay: 12, unlockWord: 14,
      solarGain: 0.55, radius: 3,
      desc: 'Beaten tin behind the beds. Doubles what little sun a winter day gives you.',
    },
    {
      id: 'bed_cold', family: 'bed', name: 'Cold frame', cost: 18, tier: 1, unlockDay: 0,
      slots: 1, chillGuard: 3.2,
      desc: 'A low box with a lid. Holds a couple of degrees over the room, which in January is everything.',
    },
    {
      id: 'bed_deep', family: 'bed', name: 'Deep bed', cost: 65, tier: 2, unlockDay: 10, unlockWord: 12,
      slots: 1, chillGuard: 1.8, yieldBonus: 0.45,
      desc: 'Two feet of good soil. Nothing grows faster, but what does grow is worth more.',
    },
    {
      id: 'bed_hot', family: 'bed', name: 'Hotbed', cost: 150, tier: 3, unlockDay: 26, unlockWord: 30,
      slots: 1, chillGuard: 4.2, needsMatter: 0.3,
      desc: 'A deep bed built on packed manure. The heat comes up from underneath, all winter.',
    },
    {
      id: 'bench', family: 'comfort', name: 'Bench', cost: 12, tier: 1, unlockDay: 0,
      seats: 2, comfort: 0.9, radius: 2,
      desc: 'Somewhere to sit is the difference between a visit and a look through the door.',
    },
    {
      id: 'kettle', family: 'comfort', name: 'Kettle and hob', cost: 55, tier: 2, unlockDay: 8, unlockWord: 10,
      seats: 0, comfort: 1.6, radius: 3, servesDrink: true, fuelPerHour: 0.10,
      desc: 'Something hot to hold. It costs almost no wood and it changes how long people stay.',
    },
    {
      id: 'rug', family: 'comfort', name: 'Rag rug', cost: 24, tier: 1, unlockDay: 5,
      seats: 0, comfort: 1.1, radius: 2, footWarmth: true,
      desc: 'Cold comes up through a brick floor. Everybody knows it and nobody mentions it.',
    },
    {
      id: 'lamp', family: 'comfort', name: 'Oil lamp', cost: 40, tier: 2, unlockDay: 16, unlockWord: 18,
      seats: 0, comfort: 1.35, radius: 3, heat: 1.1, nightOnly: true,
      desc: 'By four o\'clock in December it is dark. A lit room reads as an open one from the lane.',
    },
    {
      id: 'potting', family: 'work', name: 'Potting bench', cost: 35, tier: 1, unlockDay: 7, unlockWord: 6,
      role: 'gardener',
      desc: 'Somewhere for a gardener to stand. Roles need a place to work before anyone will take them.',
    },
    {
      id: 'woodstore', family: 'work', name: 'Wood store', cost: 50, tier: 1, unlockDay: 9, unlockWord: 10,
      role: 'forager', fuelCap: 120,
      desc: 'Dry wood burns; wet wood steams. It also gives a forager somewhere to put it.',
    },
    {
      id: 'glazier_bench', family: 'work', name: 'Glazier\'s bench', cost: 80, tier: 2, unlockDay: 14, unlockWord: 16,
      role: 'glazier',
      desc: 'A diamond, a straight edge and a tin of putty. Panes stop being a purchase and start being a job.',
    },
    {
      id: 'range', family: 'work', name: 'Cook\'s range', cost: 130, tier: 2, unlockDay: 20, unlockWord: 22,
      role: 'cook', heat: 5.5, radius: 2, fuelPerHour: 0.25,
      desc: 'Produce becomes meals, and a meal is worth far more to a cold person than a carrot.',
    },
    {
      id: 'desk', family: 'work', name: 'Keeper\'s desk', cost: 110, tier: 2, unlockDay: 24, unlockWord: 28,
      role: 'keeper',
      desc: 'A ledger, a bell and a list of who has not been in for a while.',
    },
  ];

  /* ── crops ──────────────────────────────────────────────────────────────────────────────────
   * BANDS, NOT TIMERS. `min` is the temperature below which growth stops and chill accrues;
   * `ideal` is where growth runs at full rate. A crop above `ideal` does not grow faster — that
   * asymmetry is what stops "build every stove" from being the answer to everything.
   * `chillDeath` is how many chill-hours the crop tolerates before it is lost.
   */
  const CROPS = [
    {
      id: 'mache', name: 'Corn salad', seed: 3, min: 0.0, ideal: 9.0, hours: 96, yield: 7, chillDeath: 150,
      unlockDay: 0, desc: 'It does not mind the cold and it does not ask for much. Everyone starts here.',
    },
    {
      id: 'kale', name: 'Kale', seed: 5, min: 1.0, ideal: 11.0, hours: 130, yield: 12, chillDeath: 170,
      unlockDay: 0, desc: 'Sweeter after a frost, which is the only kind thing winter does.',
    },
    {
      id: 'leek', name: 'Leeks', seed: 8, min: 3.5, ideal: 12.0, hours: 190, yield: 22, chillDeath: 130,
      unlockDay: 6, desc: 'Slow, patient and worth waiting for. The backbone of a winter kitchen.',
    },
    {
      id: 'carrot', name: 'Carrots', seed: 9, min: 4.5, ideal: 13.5, hours: 175, yield: 24, chillDeath: 110,
      unlockDay: 11, desc: 'Wants deep soil and no stones. Children will eat them raw and dirty.',
    },
    {
      id: 'herbs', name: 'Winter herbs', seed: 14, min: 6.0, ideal: 15.0, hours: 150, yield: 30, chillDeath: 90,
      unlockDay: 18, comfortBonus: 0.5, desc: 'Thyme, parsley, a little rosemary. The whole room smells different.',
    },
    {
      id: 'chard', name: 'Rainbow chard', seed: 16, min: 6.5, ideal: 16.0, hours: 165, yield: 38, chillDeath: 95,
      unlockDay: 26, desc: 'Stems in five colours. People stop and look at it, which is worth something on its own.',
    },
    {
      id: 'tomato', name: 'Winter tomatoes', seed: 30, min: 10.0, ideal: 20.0, hours: 230, yield: 78, chillDeath: 55,
      unlockDay: 40, desc: 'Absurd in January. That is exactly why it matters that you managed it.',
    },
    {
      id: 'lemon', name: 'Lemon tree', seed: 55, min: 11.5, ideal: 21.0, hours: 300, yield: 130, chillDeath: 48,
      unlockDay: 56, desc: 'It will outlive you if you get it through this winter. That is the deal.',
    },
  ];

  /* ── the people ─────────────────────────────────────────────────────────────────────────────
   * Each visitor has ONE need. That is a deliberate limit: a visitor with three needs is a puzzle,
   * and a puzzle at the door makes a warm room feel like an exam.
   *
   * `need` is resolved against room state by sim.js:
   *   warm   — the cell they settle in is at or above `needTemp`
   *   sit    — a free seat exists
   *   drink  — a kettle is lit
   *   food   — a meal is available (cook's range + produce)
   *   quiet  — fewer than `needQuiet` other people in the room
   *   green  — at least `needGreen` living plants
   */
  const VISITORS = [
    { id: 'postman', name: 'The postman', need: 'warm', needTemp: 8, gift: 'fuel', giftAmt: 6, line: 'Five more streets. Just five minutes.' },
    { id: 'nurse', name: 'A night nurse', need: 'sit', gift: 'coin', giftAmt: 10, line: 'I came off at seven. I do not want to go home yet.' },
    { id: 'boy', name: 'A boy with a bicycle', need: 'warm', needTemp: 10, gift: 'matter', giftAmt: 8, line: 'My hands have gone stupid.' },
    { id: 'widow', name: 'A widow from the terrace', need: 'quiet', needQuiet: 4, gift: 'seed', giftAmt: 2, line: 'It is very loud at my daughter\'s.' },
    { id: 'busdriver', name: 'A bus driver', need: 'drink', gift: 'coin', giftAmt: 14, line: 'Twenty minutes till the return. Anything hot.' },
    { id: 'student', name: 'A student', need: 'sit', gift: 'coin', giftAmt: 6, line: 'The library shuts at six and my room is freezing.' },
    { id: 'joiner', name: 'A joiner', need: 'warm', needTemp: 11, gift: 'tool', giftAmt: 1, line: 'I could look at that door frame for you.' },
    { id: 'twins', name: 'Two small twins', need: 'green', needGreen: 4, gift: 'word', giftAmt: 2, line: 'Are they real ones? Can we touch them?' },
    { id: 'shiftworker', name: 'A shift worker', need: 'food', gift: 'coin', giftAmt: 20, line: 'I have not eaten since last night.' },
    { id: 'gardener_old', name: 'A retired gardener', need: 'green', needGreen: 6, gift: 'seed', giftAmt: 4, line: 'You have got the chard too close to the glass, love.' },
    { id: 'busker', name: 'A busker', need: 'warm', needTemp: 12, gift: 'word', giftAmt: 3, line: 'Nobody stops in the rain. Mind if I thaw?' },
    { id: 'refugee', name: 'A new arrival', need: 'quiet', needQuiet: 6, gift: 'seed', giftAmt: 3, line: 'At home this month is the hot one.' },
    { id: 'binman', name: 'A bin man', need: 'drink', gift: 'matter', giftAmt: 12, line: 'I saved you the good pallets.' },
    { id: 'teacher', name: 'A teacher', need: 'food', gift: 'word', giftAmt: 4, line: 'Could I bring the class? They have never seen a lemon growing.' },
    { id: 'insomniac', name: 'Someone who cannot sleep', need: 'quiet', needQuiet: 3, gift: 'coin', giftAmt: 8, line: 'The light was on. I hope that is all right.' },
    { id: 'plumber', name: 'A plumber', need: 'sit', gift: 'tool', giftAmt: 1, line: 'I can get you a cistern for nothing, if you have got room.' },
  ];

  /* Roles a resident can take. Each automates one piece of another system — which is the point:
   * people are not a score, they are the labour that runs the building. */
  const ROLES = {
    gardener: { name: 'Gardener', fixture: 'potting', desc: 'Tends the beds. Halves the chill a crop accrues.', chillRelief: 0.5 },
    forager: { name: 'Forager', fixture: 'woodstore', desc: 'Brings wood in every morning.', fuelPerDay: 9 },
    glazier: { name: 'Glazier', fixture: 'glazier_bench', desc: 'Works along the glass, mending one pane at a time.', paneDays: 2 },
    cook: { name: 'Cook', fixture: 'range', desc: 'Turns produce into meals. A meal feeds a need no carrot can.', mealsPerDay: 3 },
    keeper: { name: 'Keeper', fixture: 'desk', desc: 'Knows who has not been in. Raises how many can come at once.', capBonus: 4 },
  };

  /* ── the calendar ───────────────────────────────────────────────────────────────────────────
   * Named days. `tempDelta` is applied to that day's outside temperature. The Longest Night is the
   * set-piece the whole first half is a preparation for, and it is survivable by design: it costs
   * plants, never the room.
   */
  const EVENTS = [
    { day: 0, id: 'key', name: 'The key', text: 'They gave you the key at the town hall and did not ask for anything back. Ninety days until spring.' },
    { day: 7, id: 'firstfrost', name: 'First hard frost', tempDelta: -3.5, text: 'A hard frost overnight. You can see your breath indoors.' },
    { day: 16, id: 'word1', name: 'Word gets round', text: 'Someone has written the opening hours on a card and put it in the bus shelter.' },
    { day: 24, id: 'snow', name: 'Snow', tempDelta: -2.5, solarMul: 0.35, text: 'Snow on the glass. Quiet, dim, and colder than it looks.' },
    { day: 33, id: 'gale', name: 'A gale', tempDelta: -1.5, leakMul: 1.6, text: 'Wind from the north-east all day. Every gap in the glass is finding it.' },
    { day: 45, id: 'longestnight', name: 'The longest night', tempDelta: -9.0, text: 'The coldest night of the winter, and everyone in the district knows it is coming. If the room holds tonight, it holds.' },
    { day: 52, id: 'thanks', name: 'Somebody says thank you', text: 'A card, pushed under the door, unsigned. It says the room got them through last week.' },
    { day: 63, id: 'lightreturns', name: 'The light comes back', solarMul: 1.35, text: 'It is light until half past five. You had stopped noticing that it was not.' },
    { day: 74, id: 'thaw', name: 'The thaw', tempDelta: 3.0, text: 'Water running off the roof all day. The beds are soft again.' },
    { day: 89, id: 'spring', name: 'Spring', text: 'The last day of the ninety. Whatever is standing in here now, you got it through a winter.' },
  ];

  /* Word-of-mouth tiers. `cap` is how many people can be in the room at once. */
  const WORD_TIERS = [
    { at: 0, name: 'Nobody knows', cap: 2 },
    { at: 6, name: 'A few neighbours', cap: 4 },
    { at: 16, name: 'The street', cap: 6 },
    { at: 34, name: 'The district', cap: 9 },
    { at: 60, name: 'The whole town', cap: 12 },
    { at: 95, name: 'People come on the bus', cap: 16 },
  ];

  /* ── the opening position ───────────────────────────────────────────────────────────────────
   * ⚠️ THESE TWO NUMBERS ONCE SILENTLY BROKE THE WHOLE GAME. Starting coin was 26 while the
   * tutorial's own opening move (a bench at 12 and a cold frame at 18) costs 30, so the FIRST BED
   * WAS NEVER PLACED — and with no bed there is no crop, with no crop no produce, and with no
   * produce no income for the remaining eighty-nine days. The balance probe found it as "0
   * harvests"; nothing else would have. The opening move must be affordable with something left
   * over for a seed, and there is now an arc check that says so.
   */
  const START = { coin: 44, fuel: 24, matter: 10 };

  return {
    COLS, ROWS, WINTER, GLAZING, BOARDED, DOOR, FIXTURES, CROPS, VISITORS, ROLES, EVENTS,
    WORD_TIERS, START,
    fixture: (id) => FIXTURES.find((f) => f.id === id),
    crop: (id) => CROPS.find((c) => c.id === id),
    visitor: (id) => VISITORS.find((v) => v.id === id),
    glazing: (id) => (id === 'door' ? DOOR : id === 'boarded' ? BOARDED : GLAZING.find((g) => g.id === id)),
    glazingIndex: (id) => GLAZING.findIndex((g) => g.id === id),
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = DATA;
if (typeof window !== 'undefined') window.DATA = DATA;
