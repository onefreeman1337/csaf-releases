/* THE WARM ROOM — art.js
 *
 * Loads the generated PNGs and turns them into draw calls. Every pixel this file puts on screen
 * came out of Internal_Ops/plates.js or Internal_Ops/sprites.js — our own IP, no API, no licence
 * (§0-ART source (a)). Nothing here draws a shape with a path; if something is missing from the
 * sheets, the fix is in the generator, not in a `ctx.arc`.
 *
 * ⛔ SHEET LAYOUTS COME FROM art/sheets.json, WHICH THE GENERATOR WRITES. They are never retyped
 * here: two places meaning "column 7 is the cold frame" is exactly the stale-duplicate defect the
 * master constitution keeps recording.
 */
'use strict';

const ART = (() => {
  const SCALE = 2;                 // sheets are authored at half size and blitted at x2
  const imgs = {};
  let sheets = null;
  let ready = false;

  const FILES = {
    brick: 'art/plate_brick.png',
    soil: 'art/plate_soil.png',
    slate: 'art/plate_slate.png',
    timber: 'art/plate_timber.png',
    people: 'art/sheet_people.png',
    crops: 'art/sheet_crops.png',
    fittings: 'art/sheet_fittings.png',
  };

  function load() {
    const jobs = Object.entries(FILES).map(([name, src]) => new Promise((res) => {
      const im = new Image();
      im.onload = () => { imgs[name] = im; res(true); };
      /* ⚠️ A MISSING IMAGE RESOLVES, IT DOES NOT REJECT. One 404 must not stop the game from
       * starting — `ready` still flips, `has()` reports the gap, and the board draws flat colour
       * where the plate should be. A black screen tells a player nothing; a room with a missing
       * floor at least still plays. */
      im.onerror = () => { res(false); };
      im.src = src;
    }));
    const manifest = fetch('art/sheets.json').then((r) => r.json()).then((j) => { sheets = j; })
      .catch(() => { sheets = null; });
    return Promise.all([...jobs, manifest]).then(() => { ready = true; return { ready, sheets }; });
  }

  const has = (n) => !!imgs[n];
  const missing = () => Object.keys(FILES).filter((n) => !imgs[n]).concat(sheets ? [] : ['sheets.json']);

  /** Patterns are built once and reused; creating one per frame is a real cost at 15x9 cells. */
  const patterns = {};
  function pattern(ctx, name) {
    if (patterns[name]) return patterns[name];
    if (!imgs[name]) return null;
    patterns[name] = ctx.createPattern(imgs[name], 'repeat');
    return patterns[name];
  }

  /** Fill a rect with a tiling plate, offset so the pattern is continuous across the whole board
   *  rather than restarting in every cell (which would draw a grid nobody asked for). */
  function plate(ctx, name, x, y, w, h, fallback) {
    const p = pattern(ctx, name);
    if (!p) { ctx.fillStyle = fallback || '#3a2a20'; ctx.fillRect(x, y, w, h); return; }
    ctx.save();
    ctx.fillStyle = p;
    ctx.fillRect(x, y, w, h);
    ctx.restore();
  }

  function personIndex(id) {
    /* A visitor id maps to a livery deterministically by hashing its name, so the postman is
     * always the same person to look at across a whole winter and across a reload. */
    let h = 0;
    for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
    return h % (sheets ? sheets.people.count : 16);
  }

  function drawPerson(ctx, id, seated, x, y) {
    const im = imgs.people;
    if (!im) return;
    const [w, h] = sheets ? sheets.people.cell : [11, 15];
    const col = personIndex(id);
    const row = seated ? 1 : 0;
    ctx.drawImage(im, col * w, row * h, w, h, Math.round(x), Math.round(y), w * SCALE, h * SCALE);
  }

  function drawCrop(ctx, cropId, stage, dead, x, y) {
    const im = imgs.crops;
    if (!im || !sheets) return;
    const [w, h] = sheets.crops.cell;
    const row = dead ? sheets.crops.deadRow : sheets.crops.order.indexOf(cropId);
    if (row < 0) return;
    const col = Math.max(0, Math.min(sheets.crops.stages - 1, stage));
    ctx.drawImage(im, col * w, row * h, w, h, Math.round(x), Math.round(y), w * SCALE, h * SCALE);
  }

  function drawFitting(ctx, fixId, x, y) {
    const im = imgs.fittings;
    if (!im || !sheets) return;
    const [w, h] = sheets.fittings.cell;
    const col = sheets.fittings.order.indexOf(fixId);
    if (col < 0) return;
    ctx.drawImage(im, col * w, 0, w, h, Math.round(x), Math.round(y), w * SCALE, h * SCALE);
  }

  /** Draw a fitting scaled to fit an arbitrary box — used by the shop list in the side panel, so
   *  the icon a player picks from is the same picture that lands on the floor. */
  function drawFittingAt(ctx, fixId, x, y, size) {
    const im = imgs.fittings;
    if (!im || !sheets) return;
    const [w, h] = sheets.fittings.cell;
    const col = sheets.fittings.order.indexOf(fixId);
    if (col < 0) return;
    ctx.drawImage(im, col * w, 0, w, h, Math.round(x), Math.round(y), size, size);
  }

  function drawCropAt(ctx, cropId, stage, x, y, size) {
    const im = imgs.crops;
    if (!im || !sheets) return;
    const [w, h] = sheets.crops.cell;
    const row = sheets.crops.order.indexOf(cropId);
    if (row < 0) return;
    ctx.drawImage(im, stage * w, row * h, w, h, Math.round(x), Math.round(y), size, size);
  }

  /**
   * ⭐ THE TEMPERATURE WASH — the one place the whole simulation becomes visible at a glance.
   * A cold cell gets a blue veil, a warm one an amber glow, and the plate underneath keeps its
   * value structure so the floor is still legible either way (which is why the plates were
   * authored to carry identity in VALUE rather than in hue).
   *
   * ⚠️ `screen` for warmth and `multiply` for cold, NOT alpha over the top: a flat translucent
   * wash greys everything and the room stops looking like brick and starts looking like a
   * spreadsheet with a tint.
   */
  function tint(ctx, x, y, w, h, temp) {
    const cold = Math.max(0, Math.min(1, (6 - temp) / 18));
    const warm = Math.max(0, Math.min(1, (temp - 12) / 16));
    if (cold > 0.01) {
      ctx.save();
      ctx.globalCompositeOperation = 'multiply';
      ctx.globalAlpha = 0.10 + cold * 0.55;
      ctx.fillStyle = '#6d86c9';
      ctx.fillRect(x, y, w, h);
      ctx.restore();
    }
    if (warm > 0.01) {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      ctx.globalAlpha = 0.06 + warm * 0.30;
      ctx.fillStyle = '#c9752a';
      ctx.fillRect(x, y, w, h);
      ctx.restore();
    }
  }

  return {
    load, has, missing, plate, tint, SCALE,
    drawPerson, drawCrop, drawFitting, drawFittingAt, drawCropAt, personIndex,
    get sheets() { return sheets; },
    get ready() { return ready; },
    get images() { return imgs; },
  };
})();

if (typeof window !== 'undefined') window.ART = ART;
