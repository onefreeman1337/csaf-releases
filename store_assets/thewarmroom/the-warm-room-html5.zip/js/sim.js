/* THE WARM ROOM — sim.js
 *
 * THE RULES. No DOM, no canvas, no audio, no timers: this file is a pure function of state and it
 * is the reason the game can be gated at all. `test_sim.js` runs it headless in node and
 * `balance.js` plays a whole ninety-day winter through it without drawing a pixel.
 *
 * ─────────────────────────────────────────────────────────────────────────────────────────────
 * UNITS, STATED ONCE, BECAUSE A SILENT UNIT MISMATCH IS THE CHEAPEST WAY TO SHIP A BROKEN ECONOMY.
 *
 *   temperature   degrees C. An OUTPUT — it is what the field settles to.
 *   warmth unit   the thing heat sources emit. One floor cell has a heat capacity of exactly
 *                 1.0 warmth units per degree, so into a SINGLE isolated cell 1 unit = 1 degree.
 *                 It does not stay that way once diffusion spreads it over a dozen cells, which is
 *                 exactly why `data.js` calls a brazier 9.0 and the room does not become 9 degrees
 *                 warmer. Read the settled temperature off the balance probe, never off the datum.
 *   leak          degrees per hour per degree of difference with outside, per perimeter cell.
 *   tick          ONE HOUR. Everything below is per-hour.
 * ─────────────────────────────────────────────────────────────────────────────────────────────
 *
 * ⛔ THE DIFFUSION STEP MUST BE READ FROM A SNAPSHOT, NOT UPDATED IN PLACE. Updating in place
 * makes the result depend on iteration order, so heat travels further to the right and down than
 * to the left and up — a bug that looks like nothing on a number and looks like a bright diagonal
 * smear the moment the field is drawn. `test_sim.js` asserts the field stays symmetric about a
 * centred source for exactly this reason.
 */
'use strict';

const SIM = (() => {
  const D = (typeof require !== 'undefined' && typeof module !== 'undefined')
    ? require('./data.js')
    : window.DATA;

  const { COLS, ROWS } = D;
  const N = COLS * ROWS;

  /* Diffusion rate per neighbour per hour. Stability for an explicit 4-neighbour scheme needs
   * 4*K < 1; 0.115 leaves a wide margin and gives a room that equalises over a few hours rather
   * than instantly, which is what makes a cold corner a real place. */
  const K_DIFFUSE = 0.115;
  const BODY_HEAT = 0.55;        // warmth units per person per hour
  /* Warmth units per admitting pane at noon. ⚠️ CALIBRATED, NOT CHOSEN: there are 44 perimeter
   * cells, so this is multiplied by 44 before it meets the room. At the first value tried (2.05)
   * midday solar alone was 90 units against a well-glazed room's total leak of 2.0, which pinned
   * the whole building at the 45-degree clamp every sunny afternoon. */
  const SOLAR_PEAK = 0.55;
  const MEAL_PRODUCE = 4;        // produce consumed per meal
  const FUEL_PRICE = 0.32;       // coin per unit of wood
  /* THE TIN BY THE DOOR. Every visitor who got what they came for leaves a little, on top of
   * whatever named gift they carry. It is the mechanical statement of the game's thesis — the room
   * is funded by the people it looks after — and it is also what makes the early economy solvable:
   * the balance probe measured gift income alone at roughly 7.5 coin a day against a heating bill
   * of 17, which is a game that cannot be played. */
  const TIN_PER_HAPPY_VISITOR = 3;

  /* ── deterministic RNG ──────────────────────────────────────────────────────────────────────
   * mulberry32. Seeded and carried IN STATE so a save reloads into the same future — without that
   * a player could reload to reroll a visitor, and the balance probe could not be repeated.
   */
  function rng(state) {
    state.rngState = (state.rngState + 0x6D2B79F5) >>> 0;
    let t = state.rngState;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  const pick = (state, arr) => arr[Math.floor(rng(state) * arr.length) % arr.length];

  const idx = (x, y) => y * COLS + x;
  const inBounds = (x, y) => x >= 0 && y >= 0 && x < COLS && y < ROWS;
  const isPerimeter = (x, y) => x === 0 || y === 0 || x === COLS - 1 || y === ROWS - 1;
  /* The two doors sit on the south wall, off-centre, so the cold draught has a SIDE. A centred
   * door makes the room symmetric and the layout puzzle disappears. */
  const isDoor = (x, y) => y === ROWS - 1 && (x === 4 || x === 5);

  function createState(seed) {
    const s = {
      version: 1,
      seed: seed >>> 0,
      rngState: seed >>> 0,
      day: 0,
      hour: 7,
      target: 16,   // the temperature the player asks the room to hold; the damper works to it
      totalHours: 0,
      temp: new Array(N).fill(2.0),
      cells: new Array(N).fill(null).map(() => ({ fix: null, crop: null, store: 0 })),
      panes: new Array(N).fill(null),
      coin: D.START.coin,
      fuel: D.START.fuel,
      matter: D.START.matter,
      produce: 0,
      meals: 0,
      tools: 0,
      seeds: { mache: 3, kale: 1 },
      word: 0,
      people: [],
      residents: [],
      knownVisitors: {},
      log: [],
      ended: false,
      stats: {
        visits: 0, satisfied: 0, meals: 0, harvests: 0, plantsLost: 0,
        panesFixed: 0, coldestNightHeld: 99, warmestCell: 2.0, residentsGained: 0,
        tin: 0,
      },
    };
    for (let y = 0; y < ROWS; y++) {
      for (let x = 0; x < COLS; x++) {
        if (!isPerimeter(x, y)) continue;
        s.panes[idx(x, y)] = isDoor(x, y) ? 'door' : 'broken';
      }
    }
    return s;
  }

  /* ── weather ────────────────────────────────────────────────────────────────────────────────
   * A single smooth winter curve plus a day/night swing, then whatever the calendar does to that
   * day. Deliberately NOT random: the player is meant to be able to plan for the Longest Night,
   * and a random cold snap would make preparation feel like luck.
   */
  function eventFor(day) { return D.EVENTS.find((e) => e.day === day) || null; }

  function outsideTemp(state, day, hour) {
    const W = D.WINTER;
    // 0 at the start, 1 at the deepest point (day 45), back toward 0.35 by spring
    const t = day / (W.days - 1);
    const depth = Math.sin(Math.PI * Math.min(1, t * 1.12)) ** 1.15;
    const mean = W.baseHigh + (W.deepLow - W.baseHigh) * depth;
    // coldest just before dawn (hour 6), warmest mid-afternoon (hour 15)
    const swing = -Math.cos(((hour - 6 + 24) % 24) / 24 * Math.PI * 2) * (W.dayNightSwing / 2);
    const ev = eventFor(day);
    return mean + swing + (ev && ev.tempDelta ? ev.tempDelta : 0);
  }

  /** Fraction of peak sun, 0 at night. Winter days are short and that shortness is felt. */
  function solarFactor(state, day, hour) {
    const dayLen = 7.4 + 3.6 * (day / (D.WINTER.days - 1)); // ~7.4h of useful light rising to ~11h
    const noon = 12.4;
    const half = dayLen / 2;
    if (hour < noon - half || hour > noon + half) return 0;
    const f = Math.cos(((hour - noon) / half) * (Math.PI / 2));
    const ev = eventFor(day);
    return Math.max(0, f) * (ev && ev.solarMul ? ev.solarMul : 1);
  }

  const isNight = (hour) => hour < 7 || hour >= 17;

  /* ── lookups over placed fixtures ───────────────────────────────────────────────────────────*/
  function fixturesOf(state, family) {
    const out = [];
    for (let i = 0; i < N; i++) {
      const c = state.cells[i];
      if (!c.fix) continue;
      const f = D.fixture(c.fix);
      if (f && (!family || f.family === family)) out.push({ i, x: i % COLS, y: Math.floor(i / COLS), f, cell: c });
    }
    return out;
  }
  function hasRole(state, role) { return state.residents.some((r) => r.role === role); }
  function roleCount(state, role) { return state.residents.filter((r) => r.role === role).length; }

  function wordTier(state) {
    let t = D.WORD_TIERS[0];
    for (const w of D.WORD_TIERS) if (state.word >= w.at) t = w;
    return t;
  }
  function peopleCap(state) {
    return wordTier(state).cap + (hasRole(state, 'keeper') ? D.ROLES.keeper.capBonus : 0);
  }

  function seatCount(state) {
    let n = 0;
    for (const { f } of fixturesOf(state, 'comfort')) n += (f.seats || 0);
    return n;
  }

  /** Comfort at a cell: what fittings within range contribute. Drives how long a visitor stays. */
  function comfortAt(state, x, y) {
    let c = 0;
    for (const fx of fixturesOf(state, 'comfort')) {
      if (fx.f.nightOnly && !isNight(state.hour)) continue;
      const d = Math.max(Math.abs(fx.x - x), Math.abs(fx.y - y));
      if (d <= (fx.f.radius || 1)) c += fx.f.comfort * (1 - d / ((fx.f.radius || 1) + 1));
    }
    for (const b of fixturesOf(state, 'bed')) {
      if (!b.cell.crop || b.cell.crop.dead) continue;
      const cr = D.crop(b.cell.crop.id);
      if (cr && cr.comfortBonus) {
        const d = Math.max(Math.abs(b.x - x), Math.abs(b.y - y));
        if (d <= 3) c += cr.comfortBonus;
      }
    }
    return c;
  }

  /**
   * ⭐ THE DAMPER — how hard the fires are working, 0 to 1, from how far the room is below the
   * temperature the player has asked for.
   *
   * This exists because the balance probe found a fully-built room sitting at 30 degrees in March
   * with cells pinned against the safety clamp: the equilibrium is about 23 degrees above outside,
   * and outside climbs back to +7 by spring, so a stove that never throttles cooks the building.
   * Clamping harder would have hidden that; a thermostat answers it, and it is what a person with
   * a stove actually does.
   *
   * ⭐ AND IT IS THE GAME'S THESIS MADE VISIBLE, which is why it earned its place rather than just
   * fixing a number. Bodies are a heat source, so as the room fills the damper closes and the fire
   * burns less wood. The player SEES the fire go quiet when enough people are in — the room is
   * being heated by the people in it, and the fuel bill says so.
   */
  function damperThrottle(state) {
    const target = state.target === undefined ? 16 : state.target;
    const mean = roomMean(state);
    // proportional band: full blast 2 degrees under target, shut 2 degrees over
    return Math.max(0, Math.min(1, (target - mean + 2) / 4));
  }
  /** A damped fire still ticks over — you do not let it go out to save a handful of sticks. */
  const PILOT = 0.12;

  /* ── THE HEAT STEP ──────────────────────────────────────────────────────────────────────────*/
  function stepHeat(state) {
    const out = outsideTemp(state, state.day, state.hour);
    const ev = eventFor(state.day);
    const leakMul = ev && ev.leakMul ? ev.leakMul : 1;
    const sun = solarFactor(state, state.day, state.hour);
    const night = isNight(state.hour);
    const add = new Float64Array(N);

    // 1. burning sources -------------------------------------------------------------------
    const damper = damperThrottle(state);
    state.lastDamper = damper;
    let fuelWanted = 0;
    const burners = [];
    for (const fx of fixturesOf(state)) {
      const f = fx.f;
      if (!f.fuelPerHour && !f.heat) continue;
      if (f.nightOnly && !night) continue;
      if (f.fuelPerHour) {
        fuelWanted += f.fuelPerHour * (PILOT + (1 - PILOT) * damper);
        burners.push(fx);
      }
      else if (f.heat && f.id === 'compost') {
        // compost burns matter, not wood, and only while it is being fed
        if (state.matter >= f.needsMatter) {
          state.matter -= f.needsMatter;
          spread(add, fx.x, fx.y, f.heat, f.radius || 1);
        }
      } else if (f.heat) {
        spread(add, fx.x, fx.y, f.heat, f.radius || 1);
      }
    }
    /* ⚠️ FUEL IS RATIONED PROPORTIONALLY, NOT FIRST-COME. Iterating and letting the first stove
     * take everything makes output depend on placement order, which is invisible and infuriating:
     * moving a bench could put a stove out. Everything that burns gets the same fraction. */
    let ration = 1;
    if (fuelWanted > 0) {
      if (state.fuel <= 0) ration = 0;
      else if (state.fuel < fuelWanted) ration = state.fuel / fuelWanted;
      state.fuel = Math.max(0, state.fuel - fuelWanted * ration);
    }
    for (const fx of burners) {
      const f = fx.f;
      let h = (f.heat || 0) * ration * (PILOT + (1 - PILOT) * damper);
      if (f.nightBonus && night) h *= 1 + f.nightBonus;
      if (h > 0) spread(add, fx.x, fx.y, h, f.radius || 1);
    }
    state.lastRation = ration;

    // 2. bodies ------------------------------------------------------------------------------
    for (const p of state.people) add[idx(p.x, p.y)] += BODY_HEAT;

    /* 3. SUN THROUGH GLASS. Every pane admits light EXCEPT a boarded one — including a broken one,
     * which admits the weather along with it. That is the whole tension of the cheapest repair:
     * boarding is less than half the leak of a hole for a fifth of the price of glass, and it
     * costs you the light on the beds behind it for the rest of the winter. */
    if (sun > 0) {
      for (let i = 0; i < N; i++) {
        const g = state.panes[i];
        if (!g) continue;
        const gl = D.glazing(g);
        if (!gl || gl.blocksLight) continue;
        const px = i % COLS, py = Math.floor(i / COLS);
        const inx = px === 0 ? 1 : px === COLS - 1 ? COLS - 2 : px;
        const iny = py === 0 ? 1 : py === ROWS - 1 ? ROWS - 2 : py;
        if (!inBounds(inx, iny)) continue;
        let gain = SOLAR_PEAK * sun;
        /* ⚠️ ONLY THE BEST REFLECTOR IN RANGE COUNTS — they do not stack. Multiplying a cell's
         * solar gain by every reflector that can see it made two tin sheets a 2.4x multiplier and
         * three a 3.7x, and the balance probe caught the result as a cell pinned against the 44
         * degree safety rail on sunny afternoons. Physically it is also the right model: a second
         * mirror aimed at ground the first one already lights adds very little. */
        let best = 0;
        for (const r of fixturesOf(state, 'mass')) {
          if (!r.f.solarGain) continue;
          const d = Math.max(Math.abs(r.x - inx), Math.abs(r.y - iny));
          if (d <= (r.f.radius || 1)) best = Math.max(best, r.f.solarGain);
        }
        gain *= 1 + best;
        /* ⚠️ SPREAD IT, DO NOT DUMP IT INTO ONE CELL. Every pane was adding its whole gain to the
         * single interior cell inward of it — and the four CORNER cells are inward of three panes
         * each (the corner pane diagonally, plus the first pane along each wall), so they took
         * triple solar every noon and sat pinned against the safety rail. Spreading over a radius
         * of one conserves the same total, softens the corner into something physical, and it is
         * also just true: light through a pane falls on more than one square of floor. */
        spread(add, inx, iny, gain, 1);
      }
    }

    // 4. apply sources, then leak, then diffuse ----------------------------------------------
    for (let i = 0; i < N; i++) if (!state.panes[i]) state.temp[i] += add[i];

    for (let i = 0; i < N; i++) {
      const g = state.panes[i];
      if (!g) continue;
      const gl = D.glazing(g);
      const px = i % COLS, py = Math.floor(i / COLS);
      const inx = px === 0 ? 1 : px === COLS - 1 ? COLS - 2 : px;
      const iny = py === 0 ? 1 : py === ROWS - 1 ? ROWS - 2 : py;
      if (!inBounds(inx, iny) || state.panes[idx(inx, iny)]) continue;
      const j = idx(inx, iny);
      state.temp[j] -= gl.leak * leakMul * (state.temp[j] - out);
    }

    /* SNAPSHOT FIRST — see the header. */
    const prev = state.temp.slice();
    for (let y = 1; y < ROWS - 1; y++) {
      for (let x = 1; x < COLS - 1; x++) {
        const i = idx(x, y);
        let acc = 0, n = 0;
        for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
          const nx = x + dx, ny = y + dy;
          if (!inBounds(nx, ny) || state.panes[idx(nx, ny)]) continue;
          acc += prev[idx(nx, ny)] - prev[i];
          n++;
        }
        if (n) state.temp[i] += K_DIFFUSE * acc;
      }
    }

    /* 5. THERMAL MASS. A barrel absorbs while its cell is above the room mean and gives back while
     * it is below, which is why it makes the day colder and the night survivable.
     *
     * ⚠️ `store` is in WARMTH UNITS and `flow` is in DEGREES OF THIS CELL, and because a cell's
     * heat capacity is 1.0 they convert one for one. That is the ONLY reason the arithmetic below
     * can move a number straight from one to the other, so if a cell ever gets a capacity other
     * than 1 this block needs a conversion and every barrel in the game changes value.
     *
     * (An earlier draft of this loop added `room` to `store` twice — once through an expression
     * that multiplied and divided by `exchange` and cancelled to `room`, and again on the very next
     * line. It ran clean, conserved nothing, and made barrels roughly twice as good as data.js
     * says they are. It is caught now by a conservation assertion in test_sim.js rather than by
     * this comment.) */
    for (const m of fixturesOf(state, 'mass')) {
      if (!m.f.capacity) continue;
      const r = massExchange(state.temp[m.i], roomMean(state), m.cell.store, m.f);
      state.temp[m.i] = r.temp;
      m.cell.store = r.store;
    }

    for (let i = 0; i < N; i++) {
      if (state.panes[i]) { state.temp[i] = out; continue; }
      /* A room cannot fall below outside, and clamping is honest here: the alternative is a
       * numerical drift that lets an unheated corner read colder than the night, which players
       * read as a bug and which no amount of explanation fixes. */
      if (state.temp[i] < out) state.temp[i] = out;
      /* The upper clamp is a SAFETY RAIL, not a design feature. If the room is sitting on it, the
       * calibration is wrong and the balance probe should say so — which is why it is set just
       * above any temperature the game should ever legitimately reach, and why `balance.js`
       * asserts the room never touches it. */
      if (state.temp[i] > 44) state.temp[i] = 44;
    }
  }

  /**
   * ONE THERMAL-MASS EXCHANGE, AS A PURE FUNCTION, so the conservation claim can be asserted with
   * exact equality instead of inferred from a plausible-looking room. Whatever leaves the store
   * arrives in the cell and vice versa — `test_sim.js` checks `dTemp === -dStore` to the bit.
   * Extracted for exactly that reason: the in-place version of this loop shipped a double-add that
   * every integration test in the world would have called "a slightly warm room".
   */
  function massExchange(temp, mean, store, f) {
    const flow = (temp - mean) * f.exchange;
    if (flow > 0) {
      const taken = Math.min(flow, f.capacity - store);
      return { temp: temp - taken, store: store + taken };
    }
    const given = Math.min(-flow, store);
    return { temp: temp + given, store: store - given };
  }

  /**
   * Distribute a source's output over the cells around it.
   *
   * Weighted by distance so a source has a SHAPE, and normalised against the FULL disc so that a
   * bigger radius is not secretly a bigger stove — the upgrade ladder in data.js has to mean what
   * it says.
   *
   * ⭐ HEAT AIMED AT A WALL IS LOST, NOT REDIRECTED, and this is the one line that makes stove
   * PLACEMENT a real decision. The first version normalised against the cells that survived
   * clipping, so a radius-4 banked stove tucked into a corner — where two thirds of its disc falls
   * outside the building — delivered its entire output into the handful of cells left, and the
   * balance probe found a bench at (7,3) pinned against the 44 degree safety rail at four in the
   * morning with no sun and nobody in the room. Dividing by the unclipped total instead means a
   * stove against a wall genuinely wastes what it throws at the wall, which is both physical and
   * the more interesting rule: the middle of the room is the efficient place, and the corner is
   * cheap floor you pay for in wood.
   */
  function spread(add, cx, cy, amount, radius) {
    const cells = [];
    let total = 0;
    for (let y = cy - radius; y <= cy + radius; y++) {
      for (let x = cx - radius; x <= cx + radius; x++) {
        const d = Math.max(Math.abs(x - cx), Math.abs(y - cy));
        if (d > radius) continue;
        const wFull = 1 / (1 + d);
        total += wFull;                       // the FULL disc, walls included
        if (!inBounds(x, y) || isPerimeter(x, y)) continue;
        /* ⚠️ FALLOFF IS 1/(1+d), NOT 1/(1+d²). The inverse-square version concentrated a large
         * stove's whole output into its own cell and the two beside it — with a radius-4 banked
         * stove the centre cell took 8% of 35 units every hour and sat pinned against the safety
         * clamp while the far end of the room was still freezing. A gentler falloff also says the
         * right thing about the fittings: a brazier at radius 2 is still sharply local, while a
         * big stove at radius 4 genuinely warms a room, which is what the two descriptions in
         * data.js promise the player. */
        cells.push([idx(x, y), wFull]);
      }
    }
    if (!total) return;
    for (const [i, w] of cells) add[i] += amount * (w / total);
  }

  function roomMean(state) {
    let acc = 0, n = 0;
    for (let i = 0; i < N; i++) { if (state.panes[i]) continue; acc += state.temp[i]; n++; }
    return n ? acc / n : 0;
  }
  function roomMin(state) {
    let m = Infinity;
    for (let i = 0; i < N; i++) if (!state.panes[i]) m = Math.min(m, state.temp[i]);
    return m === Infinity ? 0 : m;
  }
  function roomMax(state) {
    let m = -Infinity;
    for (let i = 0; i < N; i++) if (!state.panes[i]) m = Math.max(m, state.temp[i]);
    return m === -Infinity ? 0 : m;
  }

  /* ── THE GROWTH STEP ────────────────────────────────────────────────────────────────────────*/
  function stepGrowth(state) {
    const relief = hasRole(state, 'gardener') ? D.ROLES.gardener.chillRelief : 1;
    for (const b of fixturesOf(state, 'bed')) {
      const crop = b.cell.crop;
      if (!crop || crop.dead) continue;
      const cr = D.crop(crop.id);
      if (!cr) continue;
      let t = state.temp[b.i] + (b.f.chillGuard || 0);
      if (b.f.needsMatter) {
        if (state.matter >= b.f.needsMatter) state.matter -= b.f.needsMatter;
        else t -= (b.f.chillGuard || 0); // an unfed hotbed is just a deep bed
      }
      if (t < cr.min) {
        crop.chill += (cr.min - t) * relief;
        if (crop.chill >= cr.chillDeath) {
          crop.dead = true;
          state.stats.plantsLost++;
          logLine(state, `The ${cr.name.toLowerCase()} did not come through the cold.`, 'loss');
        }
      } else {
        /* Full rate at the ideal, no bonus above it, and a FLOOR just inside the band.
         * ⚠️ The floor is not generosity, it is the difference between a band and a cliff: with a
         * purely linear ramp a crop sitting one degree inside its minimum grows at about 6% rate,
         * which is 66 real days for a 96-hour crop — indistinguishable from dead, and the balance
         * probe showed a whole mid-winter where the beds were technically growing and the player
         * could not have told. A plant just warm enough should creep, visibly. */
        const span = Math.max(0.1, cr.ideal - cr.min);
        const frac = Math.min(1, (t - cr.min) / span);
        const rate = 0.12 + 0.88 * frac;
        crop.hours += rate;
        crop.chill = Math.max(0, crop.chill - 0.4);
      }
    }
  }

  function harvestReady(state) {
    const out = [];
    for (const b of fixturesOf(state, 'bed')) {
      const c = b.cell.crop;
      if (!c || c.dead) continue;
      const cr = D.crop(c.id);
      if (cr && c.hours >= cr.hours) out.push(b);
    }
    return out;
  }

  function harvest(state, i) {
    const cell = state.cells[i];
    if (!cell || !cell.crop) return 0;
    const cr = D.crop(cell.crop.id);
    const f = D.fixture(cell.fix);
    if (!cr) return 0;
    if (cell.crop.dead) { cell.crop = null; return 0; }
    if (cell.crop.hours < cr.hours) return 0;
    const amt = Math.round(cr.yield * (1 + (f && f.yieldBonus ? f.yieldBonus : 0)));
    state.produce += amt;
    state.matter += Math.max(1, Math.round(amt * 0.25));
    state.stats.harvests++;
    cell.crop = null;
    logLine(state, `Cut ${amt} of ${cr.name.toLowerCase()}.`, 'good');
    return amt;
  }

  /* ── THE PEOPLE STEP ────────────────────────────────────────────────────────────────────────*/
  function needMet(state, p) {
    const t = state.temp[idx(p.x, p.y)];
    switch (p.need) {
      case 'warm': return t >= (p.needTemp || 8);
      case 'sit': return p.gotSeat === true;
      case 'drink': return fixturesOf(state, 'comfort').some((f) => f.f.servesDrink) && state.fuel > 0;
      case 'food': return state.meals > 0;
      case 'quiet': return state.people.length <= (p.needQuiet || 4);
      case 'green': return livingPlants(state) >= (p.needGreen || 3);
      default: return false;
    }
  }
  function livingPlants(state) {
    let n = 0;
    for (const b of fixturesOf(state, 'bed')) if (b.cell.crop && !b.cell.crop.dead) n++;
    return n;
  }

  /** Where a newcomer settles: the warmest free interior cell, preferring comfort. */
  function findSpot(state) {
    let best = null, bestScore = -Infinity;
    const taken = new Set(state.people.map((p) => idx(p.x, p.y)));
    for (let y = 1; y < ROWS - 1; y++) {
      for (let x = 1; x < COLS - 1; x++) {
        const i = idx(x, y);
        if (taken.has(i)) continue;
        const c = state.cells[i];
        if (c.fix) {
          const f = D.fixture(c.fix);
          if (!f || (f.family !== 'comfort' && f.family !== 'work') || (f.family === 'comfort' && !f.seats)) continue;
        }
        const score = state.temp[i] + comfortAt(state, x, y) * 2.2;
        if (score > bestScore) { bestScore = score; best = { x, y, i }; }
      }
    }
    return best;
  }

  function stepPeople(state) {
    const cap = peopleCap(state);
    const out = outsideTemp(state, state.day, state.hour);
    /* ARRIVALS. Open hours are daylight plus the early evening — the evening matters because that
     * is when a lit room is most visible from the lane and when someone coming off a shift is
     * coldest. Nobody arrives after nine or before seven. */
    const openHours = !isNight(state.hour) || (state.hour >= 17 && state.hour < 21);
    if (state.people.length < cap && openHours) {
      /* ⭐ PEOPLE COME IN BECAUSE IT IS WARMER IN HERE THAN OUT THERE — a RELATIVE comparison, not
       * an absolute one, and getting this wrong was the last and most stubborn defect in the
       * economy. The first version measured `roomMean - 3`, so during the eight coldest weeks of
       * the winter, when the room sat a degree or two below zero, it counted as having no draw at
       * all and almost nobody arrived. That is backwards: a room at -2 when the street is -10 is
       * the warmest place on that street, and it is exactly when a public glasshouse matters most.
       * The balance probe showed it as a forty-day flat trough where the player could do nothing,
       * which read as a difficulty problem and was really a modelling one. */
      const relWarmth = Math.max(0, roomMean(state) - out);
      const chance = Math.min(0.72, 0.035 + state.word * 0.0050 + relWarmth * 0.020);
      /* ⭐ MORE THAN ONE PERSON CAN COME IN AN HOUR ONCE THE PLACE IS KNOWN, and without this the
       * game quietly failed its own premise. A single attempt per hour caps throughput at 0.72
       * arrivals an hour, and with a stay of about five hours the room settles at FOUR PEOPLE no
       * matter how far word has spread — against a late-game capacity of sixteen. Every arc check
       * still passed, because they counted total VISITS over ninety days rather than how many
       * people were ever in the room at once, and the gallery frame of a "full" glasshouse had one
       * figure standing in it. Attempts scale with word, so the early game is untouched. */
      const attempts = Math.max(1, Math.min(3, 1 + Math.floor(state.word / 60)));
      for (let k = 0; k < attempts && state.people.length < cap; k++) {
      if (rng(state) < chance) {
        const spot = findSpot(state);
        if (spot) {
          const v = pick(state, D.VISITORS);
          const seats = seatCount(state);
          const seated = state.people.filter((p) => p.gotSeat).length;
          const p = {
            uid: state.totalHours * 97 + state.people.length,
            id: v.id, name: v.name, need: v.need, needTemp: v.needTemp,
            needQuiet: v.needQuiet, needGreen: v.needGreen,
            gift: v.gift, giftAmt: v.giftAmt, line: v.line,
            x: spot.x, y: spot.y, hours: 0, stay: 2 + Math.floor(rng(state) * 3),
            gotSeat: seated < seats, met: false, given: false,
          };
          state.people.push(p);
          state.stats.visits++;
          state.knownVisitors[v.id] = (state.knownVisitors[v.id] || 0) + 1;
          logLine(state, `${v.name} came in. "${v.line}"`, 'person');
        }
      }
      }
    }

    for (const p of state.people) {
      p.hours++;
      if (!p.met && needMet(state, p)) {
        p.met = true;
        state.stats.satisfied++;
        if (p.need === 'food' && state.meals > 0) state.meals--;
        // comfort extends the stay: a met need plus a warm seat is why people come back
        p.stay += 1 + Math.floor(comfortAt(state, p.x, p.y));
      }
    }

    // departures
    const staying = [];
    for (const p of state.people) {
      if (p.hours < p.stay) { staying.push(p); continue; }
      if (p.met && !p.given) {
        state.coin += TIN_PER_HAPPY_VISITOR;
        state.stats.tin += TIN_PER_HAPPY_VISITOR;
        givePresent(state, p);
        state.word += 1 + (p.gift === 'word' ? p.giftAmt : 0);
        maybeResident(state, p);
      } else if (!p.met) {
        // nobody is punished for a room that is not ready yet; they simply do not stay long
        logLine(state, `${p.name} did not stay.`, 'quiet');
      }
    }
    state.people = staying;
  }

  function givePresent(state, p) {
    p.given = true;
    const amt = p.giftAmt || 1;
    switch (p.gift) {
      case 'coin': state.coin += amt; logLine(state, `${p.name} left ${amt} in the tin.`, 'good'); break;
      case 'fuel': state.fuel += amt; logLine(state, `${p.name} left ${amt} of wood by the door.`, 'good'); break;
      case 'matter': state.matter += amt; logLine(state, `${p.name} brought ${amt} of trimmings for the heap.`, 'good'); break;
      case 'seed': {
        const open = D.CROPS.filter((c) => c.unlockDay <= state.day);
        const c = pick(state, open);
        state.seeds[c.id] = (state.seeds[c.id] || 0) + amt;
        logLine(state, `${p.name} left seed for ${amt} ${c.name.toLowerCase()}.`, 'good');
        break;
      }
      case 'tool': state.tools += amt; logLine(state, `${p.name} left a tool. It will save you a job.`, 'good'); break;
      case 'word': logLine(state, `${p.name} will tell people about this.`, 'good'); break;
      default: break;
    }
  }

  /** After enough visits, and if the job has a place to be done, a visitor stays on. */
  function maybeResident(state, p) {
    if (state.residents.some((r) => r.visitorId === p.id)) return;
    if ((state.knownVisitors[p.id] || 0) < 3) return;
    for (const [role, def] of Object.entries(D.ROLES)) {
      if (hasRole(state, role)) continue;
      const placed = fixturesOf(state, 'work').some((f) => f.f.role === role);
      if (!placed) continue;
      state.residents.push({ visitorId: p.id, name: p.name, role });
      state.stats.residentsGained++;
      logLine(state, `${p.name} asked if they could take on the ${def.name.toLowerCase()}'s job. You said yes.`, 'great');
      return;
    }
  }

  /* ── residents doing their jobs, once a day ─────────────────────────────────────────────────*/
  function stepDailyRoles(state) {
    if (hasRole(state, 'forager')) {
      const store = fixturesOf(state, 'work').find((f) => f.f.id === 'woodstore');
      const cap = store ? store.f.fuelCap : 60;
      const before = state.fuel;
      state.fuel = Math.min(cap, state.fuel + D.ROLES.forager.fuelPerDay * roleCount(state, 'forager'));
      if (state.fuel > before) logLine(state, `Wood in the store: ${Math.round(state.fuel)}.`, 'quiet');
    }
    if (hasRole(state, 'glazier') && state.day % D.ROLES.glazier.paneDays === 0) {
      const worst = worstPane(state);
      if (worst >= 0) {
        state.panes[worst] = nextGlazing(state.panes[worst]);
        state.stats.panesFixed++;
        logLine(state, 'The glazier mended a pane.', 'good');
      }
    }
    if (hasRole(state, 'cook')) {
      const want = D.ROLES.cook.mealsPerDay;
      const can = Math.floor(state.produce / MEAL_PRODUCE);
      const made = Math.min(want, can);
      if (made > 0) {
        state.produce -= made * MEAL_PRODUCE;
        state.meals += made;
        state.stats.meals += made;
        logLine(state, `${made} meal${made > 1 ? 's' : ''} on the range.`, 'good');
      }
    }
  }

  function worstPane(state) {
    let worst = -1, worstLeak = -1;
    for (let i = 0; i < N; i++) {
      const g = state.panes[i];
      if (!g || g === 'door') continue;
      const gi = D.glazingIndex(g);
      if (gi < 0 || gi >= D.GLAZING.length - 1) continue;
      const leak = D.glazing(g).leak;
      if (leak > worstLeak) { worstLeak = leak; worst = i; }
    }
    return worst;
  }
  /** The next rung of real glass. A boarded pane is OFF the ladder, so it rejoins at `patched`. */
  function nextGlazing(cur) {
    if (cur === 'boarded') return 'patched';
    const i = D.glazingIndex(cur);
    if (i < 0) return cur;
    return D.GLAZING[Math.min(D.GLAZING.length - 1, i + 1)].id;
  }

  /* ── the clock ──────────────────────────────────────────────────────────────────────────────*/
  function stepHour(state) {
    if (state.ended) return { dayEnded: false, event: null };
    stepHeat(state);
    stepGrowth(state);
    stepPeople(state);
    state.stats.warmestCell = Math.max(state.stats.warmestCell, roomMax(state));
    state.totalHours++;
    state.hour++;
    let dayEnded = false;
    let event = null;
    if (state.hour >= 24) {
      state.hour = 0;
      // the coldest the room got overnight, as a record of whether it HELD
      state.stats.coldestNightHeld = Math.min(state.stats.coldestNightHeld, roomMean(state));
      state.day++;
      dayEnded = true;
      if (state.day >= D.WINTER.days) {
        state.ended = true;
        logLine(state, 'Spring.', 'great');
      } else {
        stepDailyRoles(state);
        event = eventFor(state.day);
        if (event) logLine(state, event.text, 'event');
      }
    }
    return { dayEnded, event };
  }

  function logLine(state, text, kind) {
    state.log.push({ d: state.day, h: state.hour, text, kind: kind || 'quiet' });
    if (state.log.length > 220) state.log.splice(0, state.log.length - 220);
  }

  /* ── player actions. Each returns {ok, why} so the UI never has to guess. ───────────────────*/
  function canPlace(state, i, fixId) {
    const f = D.fixture(fixId);
    if (!f) return { ok: false, why: 'No such fitting.' };
    if (state.panes[i]) return { ok: false, why: 'That is the glass.' };
    if (state.cells[i].fix) return { ok: false, why: 'Something is there already.' };
    if (state.day < (f.unlockDay || 0)) return { ok: false, why: `Not until day ${f.unlockDay + 1}.` };
    if (f.unlockWord && state.word < f.unlockWord) return { ok: false, why: `Needs word of ${f.unlockWord}.` };
    if (state.coin < f.cost) return { ok: false, why: `Costs ${f.cost}. You have ${Math.floor(state.coin)}.` };
    if (state.people.some((p) => idx(p.x, p.y) === i)) return { ok: false, why: 'Someone is standing there.' };
    return { ok: true };
  }
  function place(state, i, fixId) {
    const c = canPlace(state, i, fixId);
    if (!c.ok) return c;
    const f = D.fixture(fixId);
    state.coin -= f.cost;
    state.cells[i] = { fix: fixId, crop: null, store: 0 };
    logLine(state, `Put in a ${f.name.toLowerCase()}.`, 'quiet');
    return { ok: true };
  }
  function remove(state, i) {
    const c = state.cells[i];
    if (!c.fix) return { ok: false, why: 'Nothing there.' };
    const f = D.fixture(c.fix);
    if (c.crop && !c.crop.dead) return { ok: false, why: 'Something is growing in it.' };
    state.coin += Math.floor(f.cost * 0.5);
    state.cells[i] = { fix: null, crop: null, store: 0 };
    logLine(state, `Took out the ${f.name.toLowerCase()}.`, 'quiet');
    return { ok: true };
  }
  function canSow(state, i, cropId) {
    const cell = state.cells[i];
    const cr = D.crop(cropId);
    if (!cr) return { ok: false, why: 'No such seed.' };
    if (!cell.fix) return { ok: false, why: 'Sow into a bed.' };
    const f = D.fixture(cell.fix);
    if (!f || f.family !== 'bed') return { ok: false, why: 'That is not a bed.' };
    if (cell.crop && !cell.crop.dead) return { ok: false, why: 'It is already sown.' };
    if (state.day < (cr.unlockDay || 0)) return { ok: false, why: `${cr.name} is not available yet.` };
    if ((state.seeds[cropId] || 0) < 1) return { ok: false, why: `No ${cr.name.toLowerCase()} seed.` };
    return { ok: true };
  }
  function sow(state, i, cropId) {
    const c = canSow(state, i, cropId);
    if (!c.ok) return c;
    state.seeds[cropId]--;
    state.cells[i].crop = { id: cropId, hours: 0, chill: 0, dead: false };
    logLine(state, `Sowed ${D.crop(cropId).name.toLowerCase()}.`, 'quiet');
    return { ok: true };
  }
  function buySeed(state, cropId) {
    const cr = D.crop(cropId);
    if (!cr) return { ok: false, why: 'No such seed.' };
    if (state.day < (cr.unlockDay || 0)) return { ok: false, why: 'Not available yet.' };
    if (state.coin < cr.seed) return { ok: false, why: `Costs ${cr.seed}.` };
    state.coin -= cr.seed;
    state.seeds[cropId] = (state.seeds[cropId] || 0) + 1;
    return { ok: true };
  }
  function upgradePane(state, i) {
    const g = state.panes[i];
    if (!g) return { ok: false, why: 'Not a pane.' };
    if (g === 'door') return { ok: false, why: 'A door has to open.' };
    const gi = D.glazingIndex(g);
    if (gi >= D.GLAZING.length - 1) return { ok: false, why: 'Already double glazed.' };
    // a boarded pane is off the ladder; glazing it takes the board off and puts glass back in
    const next = D.glazing(nextGlazing(g));
    let cost = next.cost;
    if (state.tools > 0) cost = Math.ceil(cost * 0.6);
    if (state.coin < cost) return { ok: false, why: `Costs ${cost}.` };
    state.coin -= cost;
    if (state.tools > 0) state.tools--;
    state.panes[i] = next.id;
    state.stats.panesFixed++;
    return { ok: true };
  }
  function boardPane(state, i) {
    const g = state.panes[i];
    if (!g || g === 'door') return { ok: false, why: 'Not a pane.' };
    if (g !== 'broken') return { ok: false, why: 'Only a broken pane is worth boarding.' };
    const b = D.BOARDED;
    if (state.coin < b.cost) return { ok: false, why: `Costs ${b.cost}.` };
    state.coin -= b.cost;
    state.panes[i] = 'boarded';
    return { ok: true };
  }
  function buyFuel(state, amount) {
    const cost = Math.ceil(amount * FUEL_PRICE);
    if (state.coin < cost) return { ok: false, why: `Costs ${cost}.` };
    state.coin -= cost;
    state.fuel += amount;
    return { ok: true };
  }
  function sellProduce(state) {
    if (state.produce <= 0) return { ok: false, why: 'Nothing to sell.' };
    const amt = state.produce;
    state.coin += amt;
    state.produce = 0;
    logLine(state, `Sold ${amt} at the gate.`, 'good');
    return { ok: true, amt };
  }

  /** The ending. Every grade is kind — the jam brief and the design agree on that. */
  function ending(state) {
    const s = state.stats;
    const score = s.visits * 1.0 + s.satisfied * 2.2 + s.harvests * 4 + s.meals * 3
      + s.residentsGained * 25 + s.panesFixed * 2;
    const tiers = [
      { at: 0, title: 'You kept the key', text: 'The glass is still standing and the door still opens. That is not nothing — it was falling down when they gave it to you.' },
      { at: 90, title: 'A place to warm up', text: 'People know they can come in. On the coldest nights, some of them did.' },
      { at: 220, title: 'The room held', text: 'It was warm in here all winter, and it was warm because of who was in it.' },
      { at: 420, title: 'A working glasshouse', text: 'Beds full, panes sound, and a rota on the wall in three different handwritings.' },
      { at: 700, title: 'The warm room', text: 'It stopped being yours somewhere around February. Now it belongs to the street, and the street looks after it.' },
    ];
    let t = tiers[0];
    for (const x of tiers) if (score >= x.at) t = x;
    return { score: Math.round(score), ...t };
  }

  return {
    COLS, ROWS, N, K_DIFFUSE, BODY_HEAT, SOLAR_PEAK, FUEL_PRICE, TIN_PER_HAPPY_VISITOR,
    createState, idx, inBounds, isPerimeter, isDoor,
    outsideTemp, solarFactor, isNight, eventFor,
    stepHour, stepHeat, stepGrowth, stepPeople, stepDailyRoles, damperThrottle,
    roomMean, roomMin, roomMax, comfortAt, seatCount, livingPlants,
    fixturesOf, hasRole, wordTier, peopleCap, harvestReady, harvest,
    canPlace, place, remove, canSow, sow, buySeed, upgradePane, boardPane,
    buyFuel, sellProduce, ending, logLine, worstPane, nextGlazing, rng,
    // exported so the gates can assert the two claims the comments above make, directly
    spread, massExchange,
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = SIM;
if (typeof window !== 'undefined') window.SIM = SIM;
