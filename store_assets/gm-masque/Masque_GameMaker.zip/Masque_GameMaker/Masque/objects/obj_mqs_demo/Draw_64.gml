/// @description The rack, or one creature's true face. Both are drawn by the package's own scene functions.
if (is_undefined(masque)) exit;
var _w = display_get_gui_width(), _h = display_get_gui_height();
if (showing != "") mqs_reveal_draw(masque, showing, 0, 0, _w, _h, "ITS TRUE FACE", "Enter to return to the rack");
else {
    mqs_rack_draw(masque, 0, 0, _w, _h, cursor);
    draw_set_font(fnt_masque_ui);
    draw_set_colour(make_colour_rgb(201, 188, 160));
    draw_set_alpha(0.7);
    draw_set_halign(fa_right);
    draw_text(_w - 16, 12, "Space: meet the next creature   Arrows + Enter: a mask's true face");
    draw_set_halign(fa_left);
    draw_set_alpha(1);
    draw_set_colour(c_white);
}
