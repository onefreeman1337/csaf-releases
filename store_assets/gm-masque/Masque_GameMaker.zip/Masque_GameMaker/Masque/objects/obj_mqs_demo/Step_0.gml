/// @description Carve in the background (3 ms a frame), and the demo's keys.
if (is_undefined(masque)) exit;
mqs_masque_update(masque, 3);
var _n = mqs_masque_total(masque), _cols = mqs_rack_layout(masque, display_get_gui_width(), display_get_gui_height()).cols;
if (showing != "") {
    if (keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_escape) || keyboard_check_pressed(vk_space) || mouse_check_button_pressed(mb_left)) showing = "";
    exit;
}
if (keyboard_check_pressed(vk_right)) cursor = (cursor + 1) mod _n;
if (keyboard_check_pressed(vk_left)) cursor = (cursor - 1 + _n) mod _n;
if (keyboard_check_pressed(vk_down)) cursor = min(_n - 1, cursor + _cols);
if (keyboard_check_pressed(vk_up)) cursor = max(0, cursor - _cols);
if (keyboard_check_pressed(vk_enter) && mqs_masque_taken(masque, masque.profiles[cursor])) showing = masque.profiles[cursor].key;
if (keyboard_check_pressed(vk_space) || mouse_check_button_pressed(mb_left)) {
    var _p = next_unmet();
    if (!is_undefined(_p)) {
        mqs_masque_meet(masque, _p);
        showing = _p.key;
        for (var _i = 0; _i < _n; _i++) if (masque.profiles[_i].key == _p.key) cursor = _i;
    }
}
