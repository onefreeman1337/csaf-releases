/// @description Free every mask, job and the wall.
if (variable_instance_exists(id, "masque") && is_struct(masque)) mqs_masque_free(masque);
masque = undefined;
