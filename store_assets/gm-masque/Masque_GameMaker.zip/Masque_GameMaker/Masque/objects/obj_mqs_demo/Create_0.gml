/// @description Masque demo: a rack of 56 pegs, one per record of a small invented roster. Space meets the next creature
/// (its mask is carved in front of you and hung on the rack); arrows move along the rack; Enter shows a taken mask's
/// true face; Escape goes back. Also the headless -selftest entry.
/// ⛔ The crash handler is installed FIRST, and every variable a later event reads is declared ABOVE the early exits:
/// Clean Up always runs, even when Create leaves early.
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("mqs_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.mqs_stage) + ": " + string(_ex.message) + " | " + string(_ex.stacktrace));
    file_text_close(_f);
    game_end();
});
global.mqs_stage = 0;
masque = undefined;
cursor = 0;
showing = "";
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";
if (string_pos("-selftest", _args) > 0) { global.mqs_stage = 1; mqs_selftest_write(mqs_selftest_run()); game_end(); exit; }

// Your records are every enemy and character in your game; the demo borrows the suite's invented roster of 56.
masque = mqs_masque_create(mqs_oracle_roster(), { factions: mqs_oracle_factions(), rack_title: "THE RACK" });
// a rack that has been played for a while: every third creature already met
for (var _k = 0; _k < mqs_masque_total(masque); _k += 3) mqs_masque_meet(masque, masque.profiles[_k]);

/// the next creature the player has not met yet, or undefined
next_unmet = function() {
    for (var _n = 0; _n < mqs_masque_total(masque); _n++) if (!mqs_masque_taken(masque, masque.profiles[_n])) return masque.profiles[_n];
    return undefined;
};
