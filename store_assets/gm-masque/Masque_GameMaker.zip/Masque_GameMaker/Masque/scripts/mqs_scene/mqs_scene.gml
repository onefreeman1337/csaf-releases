/// mqs_scene.gml - the things a mask hangs from and is named by: the walnut wall, an iron peg, the knotted cord and a
/// brass placard, all lit by the same one light as the masks. Drawn with GameMaker primitives; call them in a Draw event
/// or while a surface is the target.
///
/// Masque - Every Creature Carves Its Own Mask, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// PUBLIC
///   mqs_wall_sprite(w, h, [seed], [plank])       -> a sprite of the wall (dark walnut planks, grain, vignette); yours to free
///   mqs_peg_draw(x, y, r)                        -> an iron peg with its own short cast shadow
///   mqs_cord_draw(peg_x, peg_y, knot_x, knot_y, [width], [part]) -> the knotted cord; part "run" (behind the mask),
///                                                   "knot" (in front of it) or "all"
///   mqs_placard_draw(x, y, w, h, title, [readings]) -> an engraved brass placard
///   mqs_text_fit(font, text, max_w, size)         -> the scale that draws text at `size` px, or narrower if it must fit
/// ⛔ Every function here blends alpha as "over" and restores your GPU state (a translucent mark drawn onto a surface
/// would otherwise LOWER its alpha and punch a hole in your own UI).

// ================================================================================================ small primitives

/// @function mqs__font(font)
/// @description The font if it is one, else the shipped sans (a wrong argument never reaches draw_set_font). Internal.
function mqs__font(_f) { if ((is_handle(_f) || is_numeric(_f)) && font_exists(_f)) return _f; return fnt_masque_ui; }

/// @function mqs__over_begin()
/// @description Push the GPU state and blend alpha as "over". Pair with gpu_pop_state(). Internal.
function mqs__over_begin() { gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha); }

/// @function mqs__ellipse(cx, cy, rx, ry, rot, colour, alpha)
/// @description A filled, rotated ellipse (a triangle fan; rot in radians, clockwise on screen). Internal.
function mqs__ellipse(_cx, _cy, _rx, _ry, _rot, _col, _a) {
    var _n = clamp(ceil(max(_rx, _ry) * 0.9), 12, 48), _c = cos(_rot), _s = sin(_rot);
    draw_primitive_begin(pr_trianglefan);
    draw_vertex_colour(_cx, _cy, _col, _a);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = 2 * pi * _i / _n, _u = cos(_t) * _rx, _v = sin(_t) * _ry;
        draw_vertex_colour(_cx + _u * _c - _v * _s, _cy + _u * _s + _v * _c, _col, _a);
    }
    draw_primitive_end();
}

/// @function mqs__polyline(pts, width, colour, alpha)
/// @description A stroke along points, with a disc at every joint and end (butt-ended segments leave a wedge of bare
/// ground on the outside of every turn). Internal.
function mqs__polyline(_pts, _w, _col, _a) {
    draw_set_colour(_col); draw_set_alpha(_a);
    var _n = array_length(_pts);
    for (var _i = 0; _i + 1 < _n; _i++) draw_line_width(_pts[_i][0], _pts[_i][1], _pts[_i + 1][0], _pts[_i + 1][1], _w);
    if (_w >= 2) for (var _j = 0; _j < _n; _j++) mqs__ellipse(_pts[_j][0], _pts[_j][1], _w / 2, _w / 2, 0, _col, _a);
    draw_set_alpha(1);
}

/// @function mqs__quad(x0, y0, cx, cy, x1, y1, steps)
/// @description Points along a quadratic curve. Internal, pure.
function mqs__quad(_x0, _y0, _cx, _cy, _x1, _y1, _n) {
    var _o = [];
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n, _u = 1 - _t;
        array_push(_o, [_u * _u * _x0 + 2 * _u * _t * _cx + _t * _t * _x1, _u * _u * _y0 + 2 * _u * _t * _cy + _t * _t * _y1]);
    }
    return _o;
}

// ================================================================================================ the wall

/// @function mqs_wall_sprite(w, h, [seed], [plank])
/// @description The wall every mask hangs on - dark walnut planks with a shadowed groove between boards, long grain
/// strokes running with the board, and a vignette so the eye goes to the mask - baked ONCE into a sprite (it is
/// thousands of strokes: never draw it every frame). The sprite is yours: sprite_delete it when you are done.
function mqs_wall_sprite(_w, _h, _seed = 4242, _plank = 96) {
    _w = clamp(floor(mqs__num(_w)), 8, 4096); _h = clamp(floor(mqs__num(_h)), 8, 4096);
    var _pitch = max(24, mqs__num(_plank));
    var _P = mqs_palette();
    // ⛔ a bake runs under IDENTITY and hands the caller's world matrix and scissor back (a bake inside a transformed or
    // clipped draw otherwise lands scaled, or clears the caller's clip: surface switches reset the scissor)
    var _mw = matrix_get(matrix_world), _sc = gpu_get_scissor();
    matrix_set(matrix_world, matrix_build_identity());
    var _s = surface_create(_w, _h);
    surface_set_target(_s);
    draw_clear_alpha(c_black, 0);
    mqs__over_begin();
    // the board colour: a diagonal gradient, lit upper left
    var _L = mqs_colour(_P.wall_lit), _D = mqs_colour(_P.wall_dark);
    var _gx = _w * 0.75, _gy = _h, _gl = _gx * _gx + _gy * _gy;
    var _t10 = clamp((_w * _gx) / _gl, 0, 1), _t01 = clamp((_h * _gy) / _gl, 0, 1), _t11 = clamp((_w * _gx + _h * _gy) / _gl, 0, 1);
    draw_rectangle_colour(0, 0, _w, _h, _L, merge_colour(_L, _D, _t10), merge_colour(_L, _D, _t11), merge_colour(_L, _D, _t01), false);
    var _n = mqs__noise1((mqs__num(_seed) ^ $51ED) & $FFFFFFFF, 3);
    for (var _y = 0; _y < _h; _y += _pitch) {
        draw_set_alpha(0.55); draw_set_colour(make_colour_rgb(8, 5, 3)); draw_rectangle(0, _y, _w, _y + 1, false);
        draw_set_alpha(0.055); draw_set_colour(make_colour_rgb(255, 226, 190)); draw_rectangle(0, _y + 2, _w, _y + 2, false);
        var _rows = floor(_pitch / 7);
        for (var _k = 0; _k < _rows; _k++) {
            var _yy = _y + 5 + _k * 7 + mqs__n1(_n, _k * 3.1 + _y) * 2;
            draw_set_alpha(0.055 + abs(mqs__n1(_n, _k + _y * 0.02)) * 0.055);
            draw_set_colour(make_colour_rgb(214, 178, 134));
            var _px = 0, _py = _yy + mqs__n1(_n, _k * 7.3 + _y) * 1.8;
            for (var _x = 16; _x <= _w + 15; _x += 16) {
                var _ny = _yy + mqs__n1(_n, _x * 0.02 + _k * 7.3 + _y) * 1.8;
                draw_line(_px, _py, _x, _ny);
                _px = _x; _py = _ny;
            }
        }
    }
    draw_set_alpha(1);
    // the vignette: rings from clear to 0.62 black, centred a little up and left
    var _cx = _w * 0.46, _cy = _h * 0.45, _r0 = min(_w, _h) * 0.18, _r1 = max(_w, _h) * 0.78;
    var _rings = 18, _seg = 48;
    for (var _r = 0; _r < _rings; _r++) {
        var _ra = lerp(_r0, _r1, _r / _rings), _rb = lerp(_r0, _r1, (_r + 1) / _rings);
        var _aa = 0.62 * power(_r / _rings, 1.4), _ab = 0.62 * power((_r + 1) / _rings, 1.4);
        draw_primitive_begin(pr_trianglestrip);
        for (var _i = 0; _i <= _seg; _i++) {
            var _t = 2 * pi * _i / _seg;
            draw_vertex_colour(_cx + cos(_t) * _ra, _cy + sin(_t) * _ra, c_black, _aa);
            draw_vertex_colour(_cx + cos(_t) * _rb, _cy + sin(_t) * _rb, c_black, _ab);
        }
        draw_primitive_end();
    }
    gpu_pop_state();
    surface_reset_target();
    var _spr = sprite_create_from_surface(_s, 0, 0, _w, _h, false, false, 0, 0);
    surface_free(_s);
    matrix_set(matrix_world, _mw);
    gpu_set_scissor(_sc);
    return _spr;
}

// ================================================================================================ the peg, the cord, the placard

/// @function mqs_peg_draw(x, y, r)
/// @description An iron peg (centre x, y, radius r px), with its short cast shadow down-right and one catch of light.
function mqs_peg_draw(_x, _y, _r) {
    _x = mqs__num(_x); _y = mqs__num(_y); _r = clamp(mqs__num(_r), 2, 512);
    mqs__over_begin();
    mqs__ellipse(_x + _r * 0.9, _y + _r * 1.0, _r * 1.15, _r * 0.7, 0, c_black, 0.45);
    mqs__ellipse(_x, _y, _r, _r * 0.92, 0, make_colour_rgb(38, 38, 43), 1);
    mqs__ellipse(_x - _r * 0.14, _y - _r * 0.14, _r * 0.80, _r * 0.74, 0, make_colour_rgb(90, 90, 96), 1);
    mqs__ellipse(_x - _r * 0.26, _y - _r * 0.27, _r * 0.52, _r * 0.48, 0, make_colour_rgb(138, 138, 144), 0.85);
    mqs__ellipse(_x - _r * 0.32, _y - _r * 0.34, _r * 0.26, _r * 0.20, -0.5, make_colour_rgb(255, 248, 230), 0.55);
    gpu_pop_state();
}

/// @function mqs_cord_draw(peg_x, peg_y, knot_x, knot_y, [width], [part])
/// @description The single knotted cord. ⛔ It sags along its OWN LENGTH (slack is how much cord there is, not how far
/// apart its ends are left to right), it has a laid twist and a highlight (a cord is not a line), and its knot is a bound
/// lump with two cut tails. Draw part "run" BEFORE the mask and "knot" AFTER it: a cord passing over an edge is in front
/// of some of the object and behind the rest.
function mqs_cord_draw(_px, _py, _kx, _ky, _w = 3, _part = "all") {
    _px = mqs__num(_px); _py = mqs__num(_py); _kx = mqs__num(_kx); _ky = mqs__num(_ky);
    _w = clamp(mqs__num(_w), 1, 64);
    if (!is_string(_part)) _part = "all";
    var _P = mqs_palette(), _cord = mqs_colour(_P.cord);
    var _span = point_distance(_px, _py, _kx, _ky), _sag = max(2.5, _span * 0.085);
    var _mx = (_px + _kx) / 2, _my = (_py + _ky) / 2 + _sag;
    var _n = clamp(ceil(_span / 6), 6, 40);
    mqs__over_begin();
    if (_part != "knot") {
        mqs__polyline(mqs__quad(_px + 2, _py + 2.4, _mx + 2, _my + 2.4, _kx + 2, _ky + 2.4, _n), _w + 2, c_black, 0.45);
        mqs__polyline(mqs__quad(_px, _py, _mx, _my, _kx, _ky, _n), _w, _cord, 1);
        mqs__polyline(mqs__quad(_px - 0.7, _py - 0.7, _mx - 0.7, _my - 0.7, _kx - 0.7, _ky - 0.7, _n), max(1, _w * 0.32), make_colour_rgb(255, 214, 196), 0.26);
        // the lay of the rope: ticks across it at a PITCH derived from the real length, never a typed count
        var _pitch = max(3.2, _w * 1.9), _turns = max(2, floor(_span / _pitch));
        draw_set_colour(c_black); draw_set_alpha(0.26);
        for (var _i = 1; _i < _turns; _i++) {
            var _t = _i / _turns, _u = 1 - _t, _t2 = min(1, _t + 0.012), _u2 = 1 - _t2;
            var _ax = _u * _u * _px + 2 * _u * _t * _mx + _t * _t * _kx, _ay = _u * _u * _py + 2 * _u * _t * _my + _t * _t * _ky;
            var _bx = _u2 * _u2 * _px + 2 * _u2 * _t2 * _mx + _t2 * _t2 * _kx, _by = _u2 * _u2 * _py + 2 * _u2 * _t2 * _my + _t2 * _t2 * _ky;
            var _dx = _bx - _ax, _dy = _by - _ay, _l = max(0.0001, sqrt(_dx * _dx + _dy * _dy));
            var _nx = -_dy / _l, _ny = _dx / _l;
            draw_line_width(_ax - _nx * _w * 0.5 + _dx * 2, _ay - _ny * _w * 0.5 + _dy * 2, _ax + _nx * _w * 0.5 - _dx * 2, _ay + _ny * _w * 0.5 - _dy * 2, max(1, _w * 0.26));
        }
        draw_set_alpha(1);
    }
    if (_part != "run") {
        var _ta = arctan2(_ky - _my, _kx - _mx);
        for (var _s = -1; _s <= 1; _s += 2) {
            var _c1x = _kx + cos(_ta + _s * 0.55) * _w * 2.6, _c1y = _ky + sin(_ta + _s * 0.55) * _w * 2.6;
            var _e1x = _kx + cos(_ta + _s * 1.05) * _w * 4.6, _e1y = _ky + sin(_ta + _s * 1.05) * _w * 4.6;
            mqs__polyline(mqs__quad(_kx + 1.2, _ky + 1.4, _c1x + 1.2, _c1y + 1.4, _e1x + 1.2, _e1y + 1.4, 8), max(1.2, _w), c_black, 0.4);
            mqs__polyline(mqs__quad(_kx, _ky, _c1x, _c1y, _e1x, _e1y, 8), max(1, _w * 0.85), _cord, 1);
        }
        mqs__ellipse(_kx + _w * 0.5, _ky + _w * 0.55, _w * 2.7, _w * 2.1, 0.5, c_black, 0.45);
        mqs__ellipse(_kx, _ky, _w * 2.5, _w * 1.9, 0.5, _cord, 1);
        for (var _t3 = -1; _t3 <= 1; _t3 += 2) {
            mqs__polyline(mqs__quad(_kx - _w * 1.9 + _t3 * _w * 0.5, _ky - _w * 0.9 + _t3 * _w * 0.55, _kx + _t3 * _w * 0.4, _ky + _t3 * _w * 0.2,
                _kx + _w * 1.9 + _t3 * _w * 0.5, _ky + _w * 0.9 + _t3 * _w * 0.55, 8), max(0.8, _w * 0.34), c_black, 0.34);
        }
        mqs__ellipse(_kx - _w * 0.7, _ky - _w * 0.6, _w * 0.9, _w * 0.5, 0.5, make_colour_rgb(255, 206, 188), 0.30);
    }
    gpu_pop_state();
}

/// @function mqs_text_fit(font, text, max_w, size)
/// @description The scale that draws `text` in `font` at `size` px tall, shrunk further only if it would be wider than
/// max_w (a caption that CAN overflow will; the data is never shortened to make it fit). Pure but for the font query.
function mqs_text_fit(_font, _text, _maxw, _size) {
    _font = mqs__font(_font); _text = is_string(_text) ? _text : mqs__str(_text);
    _maxw = max(1, mqs__num(_maxw)); _size = max(1, mqs__num(_size));
    draw_set_font(_font);
    var _h = max(1, string_height("M")), _k = _size / _h;
    var _w = string_width(_text) * _k;
    if (_w > _maxw && _w > 0) _k *= _maxw / _w;
    return _k;
}

/// @function mqs__engrave(font, text, x, y, scale, ink, ink_alpha)
/// @description Engraved text centred on x, baseline-ish at y: a one-pixel light offset beneath, then the ink (which is
/// what an engraved letter actually looks like). Internal.
function mqs__engrave(_font, _text, _x, _y, _k, _ink, _ia) {
    draw_set_font(_font); draw_set_halign(fa_center); draw_set_valign(fa_middle);
    var _tf = gpu_get_texfilter();
    gpu_set_texfilter(true);
    draw_text_transformed_colour(_x, _y + 1, _text, _k, _k, 0, make_colour_rgb(255, 238, 200), make_colour_rgb(255, 238, 200), make_colour_rgb(255, 238, 200), make_colour_rgb(255, 238, 200), 0.55);
    draw_text_transformed_colour(_x, _y, _text, _k, _k, 0, _ink, _ink, _ink, _ink, _ia);
    gpu_set_texfilter(_tf);
    draw_set_halign(fa_left); draw_set_valign(fa_top);
}

/// @function mqs_placard_draw(x, y, w, h, title, [readings])
/// @description An engraved brass placard: a cast shadow, a lit brass face, two fine borders, the title in the plate
/// serif and the four readings (structure, standing, pigment, house) beneath it, separated by small struck dots. The
/// ink is solved against the brass (both directions tried), never typed.
function mqs_placard_draw(_x, _y, _w, _h, _title, _readings = undefined) {
    _x = mqs__num(_x); _y = mqs__num(_y); _w = clamp(mqs__num(_w), 8, 4096); _h = clamp(mqs__num(_h), 8, 1024);
    var _P = mqs_palette();
    mqs__over_begin();
    draw_set_alpha(0.45); draw_set_colour(c_black); draw_rectangle(_x + 3, _y + 4, _x + _w + 2, _y + _h + 3, false); draw_set_alpha(1);
    var _hi = mqs_colour(_P.brass_hi), _mid = mqs_colour(_P.brass), _lo = mqs_colour(_P.brass_deep);
    draw_rectangle_colour(_x, _y, _x + _w, _y + _h, _hi, _mid, _lo, merge_colour(_mid, _lo, 0.35), false);
    draw_set_alpha(0.45); draw_set_colour(make_colour_rgb(255, 240, 200)); draw_rectangle(_x, _y, _x + _w - 1, _y + _h - 1, true);
    draw_set_alpha(0.5); draw_set_colour(make_colour_rgb(60, 40, 10)); draw_rectangle(_x + 2, _y + 2, _x + _w - 3, _y + _h - 3, true);
    draw_set_alpha(1);
    var _ink = mqs_ink_for(_P.brass, 4.5);
    var _ic = mqs_colour(_ink.rgb);
    var _hasR = is_array(_readings) && array_length(_readings) > 0;
    if (is_string(_title) && _title != "") {
        var _k = mqs_text_fit(fnt_masque, _title, _w - 16, _h * (_hasR ? 0.46 : 0.56));
        mqs__engrave(fnt_masque, _title, _x + _w / 2, _y + _h * (_hasR ? 0.36 : 0.50), _k, _ic, 1);
    }
    if (_hasR) {
        // the readings in the sans (lining figures), with a struck dot between them (the shipped fonts are ASCII only)
        var _gap = _h * 0.20, _sz = _h * 0.22, _tw = 0, _parts = [];
        draw_set_font(fnt_masque_ui);
        var _kk = _sz / max(1, string_height("M"));
        for (var _i = 0; _i < array_length(_readings); _i++) { var _t = string(_readings[_i]); array_push(_parts, _t); _tw += string_width(_t) * _kk; }
        _tw += _gap * (array_length(_parts) - 1);
        if (_tw > _w - 14) { var _f = (_w - 14) / _tw; _kk *= _f; _gap *= _f; _tw = _w - 14; }
        var _cx = _x + _w / 2 - _tw / 2, _cy = _y + _h * 0.76;
        for (var _j = 0; _j < array_length(_parts); _j++) {
            var _pw = string_width(_parts[_j]) * _kk;
            mqs__engrave(fnt_masque_ui, _parts[_j], _cx + _pw / 2, _cy, _kk, _ic, 0.92);
            _cx += _pw;
            if (_j + 1 < array_length(_parts)) { mqs__ellipse(_cx + _gap / 2, _cy, max(1, _h * 0.028), max(1, _h * 0.028), 0, _ic, 0.8); _cx += _gap; }
        }
    }
    gpu_pop_state();
}
