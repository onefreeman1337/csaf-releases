{
  "$GMScript": "v1",
  "%Name": "mqs_scene",
  "name": "mqs_scene",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}