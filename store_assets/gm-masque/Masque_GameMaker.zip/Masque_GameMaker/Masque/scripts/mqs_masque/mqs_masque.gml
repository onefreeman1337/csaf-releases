/// mqs_masque.gml - the collection: every record in your game gets a mask, the player takes a mask by meeting what it
/// belongs to, and the masks hang on a rack. Also the two screens that show them: the RACK (the wall the player fills)
/// and the REVEAL (one creature's true face, carved as you watch, with its engraved placard).
///
/// Masque - Every Creature Carves Its Own Mask, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// PUBLIC
///   mqs_masque_create(records, [options])     -> a masque: every record read once (rank is a percentile of the WHOLE
///                                               roster, so it is computed once, never per mask)
///   mqs_masque_update(masque, [budget_ms])    -> call every Step: carves waiting masks under the budget (default 3 ms)
///   mqs_masque_meet(masque, who)              -> the player has met it: its mask is taken (true if that is NEW).
///                                               `who` = a profile, a key ("enemy:7:Bog Wight"), a name, or an id
///   mqs_masque_find(masque, who, [kind])      -> the profile, or undefined
///   mqs_masque_taken(masque, who)             -> has the player taken this mask?
///   mqs_masque_count(masque) / mqs_masque_total(masque)
///   mqs_masque_mask(masque, who, height)      -> the finished mask at that height, or undefined (it is queued)
///   mqs_masque_save(masque) -> string         mqs_masque_load(masque, string) -> true if it read
///   mqs_masque_free(masque)                   -> frees every sprite and job it holds (call in Clean Up)
///   mqs_rack_layout(masque, w, h)             -> {cols, rows, cell, per_page, x0, y0, head, foot}
///   mqs_rack_draw(masque, x, y, w, h, [cursor], [title]) -> draws the rack in a rectangle; the cursor is an index
///   mqs_reveal_draw(masque, who, x, y, w, h, [eyebrow], [hint]) -> draws the reveal; true once the mask is fully carved
/// options: { elements, factions (as mqs_read), rack_title ("THE RACK"), reveal_height (0 = fit the screen) }
///
/// ⛔ Masks are carved, never loaded: nothing here is an image file. A masque holds sprites, so free it in Clean Up
/// (never straight after a draw: GameMaker queues draws, and a sprite deleted in the frame it was drawn is a white box).

#macro MQS_SAVE_VERSION 1

/// @function mqs_masque_create(records, [options])
/// @description Read every record into a mask profile and start an empty rack. Returns a masque struct.
function mqs_masque_create(_records, _opts = undefined) {
    var _profiles = mqs_read(_records, _opts);
    var _m = {
        profiles: _profiles, taken: {}, masks: {}, queue: [], job: undefined, job_key: "",
        wall: -1, wall_w: 0, wall_h: 0, rack_title: mqs__str(mqs__get(_opts, "rack_title", "THE RACK")),
        reveal_height: mqs__num(mqs__get(_opts, "reveal_height", 0)), reveal_job: undefined, reveal_key: "", stats: { carved: 0, ms: 0, worst_step_ms: 0 }
    };
    if (_m.rack_title == "") _m.rack_title = "THE RACK";
    return _m;
}

/// @function mqs_masque_find(masque, who, [kind])
/// @description The profile for a profile, a key ("enemy:7:Bog Wight"), a name (the placard name or the record's own),
/// or an id (with kind "enemy" or "character"), or undefined.
function mqs_masque_find(_m, _who, _kind = undefined) {
    if (!is_struct(_m)) return undefined;
    if (is_struct(_who) && variable_struct_exists(_who, "key")) _who = _who.key;
    var _ps = _m.profiles;
    for (var _i = 0; _i < array_length(_ps); _i++) {
        var _p = _ps[_i];
        if (!is_undefined(_kind) && _p.kind != _kind) continue;
        if (is_string(_who) && (_p.key == _who || _p.name == _who || mqs__str(mqs__get(_p.record, "name", "")) == _who)) return _p;
        if (mqs__fin(_who) && mqs__fin(_p.id) && _p.id == _who) return _p;
    }
    return undefined;
}

/// @function mqs_masque_taken(masque, who)
/// @description Has the player taken this mask?
function mqs_masque_taken(_m, _who) {
    var _p = mqs_masque_find(_m, _who);
    return !is_undefined(_p) && variable_struct_exists(_m.taken, _p.key) && _m.taken[$ _p.key] == true;
}

/// @function mqs_masque_count(masque)
/// @description How many masks the player has taken.
function mqs_masque_count(_m) {
    if (!is_struct(_m)) return 0;
    var _n = 0;
    for (var _i = 0; _i < array_length(_m.profiles); _i++) if (variable_struct_exists(_m.taken, _m.profiles[_i].key)) _n++;
    return _n;
}

/// @function mqs_masque_total(masque)
/// @description How many masks there are to take.
function mqs_masque_total(_m) { return is_struct(_m) ? array_length(_m.profiles) : 0; }

/// @function mqs_masque_meet(masque, who)
/// @description The player has met this creature: its mask is taken (returns true if that is NEW). It is carved the first
/// time the rack or the reveal shows it (mqs_masque_update does the carving, under your budget).
function mqs_masque_meet(_m, _who) {
    var _p = mqs_masque_find(_m, _who);
    if (is_undefined(_p)) return false;
    var _new = !variable_struct_exists(_m.taken, _p.key);
    _m.taken[$ _p.key] = true;
    return _new;
}

/// @function mqs__mask_key(profile, height)
/// @description The cache key of a mask at a height. Internal, pure.
function mqs__mask_key(_p, _h) { return _p.key + "@" + string(floor(_h)); }

/// @function mqs_masque_mask(masque, who, height)
/// @description The finished mask at a height, or undefined - in which case it is queued and mqs_masque_update carves it.
function mqs_masque_mask(_m, _who, _h) {
    var _p = mqs_masque_find(_m, _who);
    if (is_undefined(_p)) return undefined;
    _h = max(8, floor(mqs__num(_h)));
    var _k = mqs__mask_key(_p, _h);
    if (variable_struct_exists(_m.masks, _k)) return _m.masks[$ _k];
    for (var _i = 0; _i < array_length(_m.queue); _i++) if (_m.queue[_i][0] == _k) return undefined;
    if (_m.job_key == _k) return undefined;
    array_push(_m.queue, [_k, _p, _h]);
    return undefined;
}

/// @function mqs_masque_update(masque, [budget_ms])
/// @description Carve waiting masks for up to budget_ms (default 3). The reveal's mask goes first. Returns how many
/// masks are still waiting.
function mqs_masque_update(_m, _budget = 3) {
    if (!is_struct(_m)) return 0;
    var _t0 = get_timer(), _end = _t0 + max(0.1, mqs__num(_budget)) * 1000;
    if (is_struct(_m.reveal_job) && !_m.reveal_job.done) {
        mqs_carve_step(_m.reveal_job, max(0.1, mqs__num(_budget)));
        if (_m.reveal_job.done) { _m.masks[$ _m.reveal_key] = _m.reveal_job.mask; _m.stats.carved++; _m.stats.ms += _m.reveal_job.mask.ms; }
    }
    while (get_timer() < _end) {
        if (is_undefined(_m.job)) {
            if (array_length(_m.queue) == 0) break;
            var _q = _m.queue[0];
            array_delete(_m.queue, 0, 1);
            if (variable_struct_exists(_m.masks, _q[0])) continue;
            _m.job = mqs_carve_begin(_q[1], _q[2]);
            _m.job_key = _q[0];
        }
        var _left = (_end - get_timer()) / 1000;
        if (_left <= 0) break;
        var _s0 = get_timer();
        if (mqs_carve_step(_m.job, _left)) {
            _m.masks[$ _m.job_key] = _m.job.mask;
            _m.stats.carved++; _m.stats.ms += _m.job.mask.ms;
            _m.job = undefined; _m.job_key = "";
        }
        _m.stats.worst_step_ms = max(_m.stats.worst_step_ms, (get_timer() - _s0) / 1000);
    }
    return array_length(_m.queue) + (is_undefined(_m.job) ? 0 : 1);
}

/// @function mqs_masque_save(masque)
/// @description The player's rack as a string (which masks are taken): store it in your own save.
function mqs_masque_save(_m) {
    if (!is_struct(_m)) return json_stringify({ v: MQS_SAVE_VERSION, taken: [] });
    var _keys = [];
    for (var _i = 0; _i < array_length(_m.profiles); _i++) if (variable_struct_exists(_m.taken, _m.profiles[_i].key)) array_push(_keys, _m.profiles[_i].key);
    return json_stringify({ v: MQS_SAVE_VERSION, taken: _keys });
}

/// @function mqs_masque_load(masque, string)
/// @description Restore a rack saved by mqs_masque_save. A key that no longer names a record is kept (a creature renamed
/// back will find its mask again) but never drawn. Returns true if the string read.
function mqs_masque_load(_m, _s) {
    if (!is_struct(_m) || !is_string(_s)) return false;
    var _d = undefined;
    try { _d = json_parse(_s); } catch (_e) { return false; }
    if (!is_struct(_d) || !variable_struct_exists(_d, "taken") || !is_array(_d.taken)) return false;
    _m.taken = {};
    for (var _i = 0; _i < array_length(_d.taken); _i++) if (is_string(_d.taken[_i])) _m.taken[$ _d.taken[_i]] = true;
    return true;
}

/// @function mqs_masque_free(masque)
/// @description Free every sprite, job and buffer the masque holds. Call it in Clean Up.
function mqs_masque_free(_m) {
    if (!is_struct(_m)) return;
    var _ks = variable_struct_get_names(_m.masks);
    for (var _i = 0; _i < array_length(_ks); _i++) mqs_mask_free(_m.masks[$ _ks[_i]]);
    _m.masks = {};
    if (is_struct(_m.job)) { mqs_carve_cancel(_m.job); if (_m.job.done) mqs_mask_free(_m.job.mask); }
    if (is_struct(_m.reveal_job)) { mqs_carve_cancel(_m.reveal_job); }
    _m.job = undefined; _m.reveal_job = undefined; _m.queue = [];
    if (variable_struct_exists(_m, "walls")) {
        var _ws = variable_struct_get_names(_m.walls);
        for (var _w = 0; _w < array_length(_ws); _w++) if (sprite_exists(_m.walls[$ _ws[_w]])) sprite_delete(_m.walls[$ _ws[_w]]);
        _m.walls = {};
    }
    if (sprite_exists(_m.wall)) sprite_delete(_m.wall);
    _m.wall = -1;
}

// ================================================================================================ the rack

/// @function mqs_rack_layout(masque, w, h)
/// @description SOLVE the peg grid for a rectangle - never a hard-coded column count: every columns x rows pair is tried,
/// cells under 140 px are refused (never icon scale) unless nothing else fits, and above that floor the grid showing the
/// MOST of the collection wins, then the largest cell, then the fewest empty pegs. {cols, rows, cell, per_page, x0, y0,
/// head, foot} (x0/y0 relative to the rectangle).
function mqs_rack_layout(_m, _w, _h) {
    _w = clamp(mqs__num(_w), 64, 8192); _h = clamp(mqs__num(_h), 64, 8192);
    var _head = max(44, floor(_h * 0.10)), _foot = max(24, floor(_h * 0.05));
    var _aw = _w - 48, _ah = _h - _head - _foot;
    var _n = max(1, mqs_masque_total(_m)), _best = undefined;
    for (var _floor = 140; _floor >= 60 && is_undefined(_best); _floor -= 40) {
        for (var _c = 3; _c <= 8; _c++) for (var _r = 2; _r <= 5; _r++) {
            var _cell = min(floor(_aw / _c), floor(_ah / _r));
            if (_cell < _floor) continue;
            var _per = _c * _r, _empty = (_per - ((_n mod _per == 0) ? _per : (_n mod _per))) mod _per;
            if (is_undefined(_best) || _per > _best.per || (_per == _best.per && _cell > _best.cell) || (_per == _best.per && _cell == _best.cell && _empty < _best.empty)) {
                _best = { cols: _c, rows: _r, cell: _cell, per: _per, empty: _empty };
            }
        }
    }
    if (is_undefined(_best)) _best = { cols: 2, rows: 2, cell: max(40, floor(min(_aw / 2, _ah / 2))), per: 4, empty: 0 };
    return { cols: _best.cols, rows: _best.rows, cell: _best.cell, per_page: _best.cols * _best.rows,
        x0: floor((_w - _best.cols * _best.cell) / 2), y0: _head + floor((_ah - _best.rows * _best.cell) / 2), head: _head, foot: _foot };
}

/// @function mqs__wall_for(masque, w, h)
/// @description The masque's wall sprite at a size, made once per size and KEPT until mqs_masque_free. ⛔ Never deleted
/// on a size change: GameMaker queues draws, so a wall deleted in the same frame it was drawn at another size would draw
/// as a white box. Internal.
function mqs__wall_for(_m, _w, _h) {
    if (!variable_struct_exists(_m, "walls")) _m.walls = {};
    var _k = string(_w) + "x" + string(_h);
    if (!variable_struct_exists(_m.walls, _k) || !sprite_exists(_m.walls[$ _k])) _m.walls[$ _k] = mqs_wall_sprite(_w, _h, 4242, 96);
    _m.wall = _m.walls[$ _k];
    return _m.wall;
}

/// @function mqs_rack_draw(masque, x, y, w, h, [cursor], [title])
/// @description Draw the rack in a rectangle: the wall, a peg per record, and on each peg the player has filled, its mask
/// hanging from its knotted cord (a mask still being carved shows its cord and waits). An EMPTY peg is drawn, never
/// skipped - the wall has to read as incomplete. The cursor's mask gets a warm rim (never a cursor rectangle), its name
/// is on the foot and a brass plate counts the taken masks. Returns the layout (with the page shown).
function mqs_rack_draw(_m, _x, _y, _w, _h, _cursor = 0, _title = undefined) {
    if (!is_struct(_m)) return undefined;
    _x = mqs__num(_x); _y = mqs__num(_y); _w = clamp(floor(mqs__num(_w)), 64, 8192); _h = clamp(floor(mqs__num(_h)), 64, 8192);
    var _L = mqs_rack_layout(_m, _w, _h);
    var _n = mqs_masque_total(_m);
    _cursor = clamp(floor(mqs__num(_cursor)), 0, max(0, _n - 1));
    var _page = floor(_cursor / _L.per_page), _pages = max(1, ceil(_n / _L.per_page)), _first = _page * _L.per_page;
    draw_sprite(mqs__wall_for(_m, _w, _h), 0, _x, _y);
    var _msz = floor(_L.cell * 0.64);
    for (var _i = 0; _i < _L.per_page; _i++) {
        var _idx = _first + _i;
        if (_idx >= _n) break;
        var _col = _i mod _L.cols, _row = _i div _L.cols;
        var _cx = _x + _L.x0 + _col * _L.cell + floor(_L.cell / 2), _top = _y + _L.y0 + _row * _L.cell;
        var _p = _m.profiles[_idx];
        var _cordLen = max(9, floor(_L.cell * 0.125)), _pegR = max(3, floor(_L.cell * 0.034));
        var _pegY = _top + floor(_L.cell * 0.07);
        var _mk = variable_struct_exists(_m.taken, _p.key) ? mqs_masque_mask(_m, _p, _msz) : undefined;
        if (!is_undefined(_mk)) {
            // the same derived stack as the reveal, per cell: cord plus object measured and centred in its cell
            var _stack = _cordLen + _mk.box_h;
            var _sTop = max(_top + 3, _top + floor((_L.cell - _stack) / 2));
            var _mTop = _sTop + _cordLen, _mx = _cx - _mk.box_w / 2;
            var _kx = _mx + _mk.box_knot_x, _ky = _mTop + _mk.box_knot_y;
            _pegY = max(_top + 3, min(_ky - _cordLen, _mTop - 4));
            var _cw = max(1.5, _L.cell * 0.016);
            mqs_peg_draw(_cx, _pegY, _pegR);
            mqs_cord_draw(_cx, _pegY, _kx, _ky, _cw, "run");
            if (_idx == _cursor) {
                mqs_mask_draw_shadow(_mk, _mx, _mTop, 1, make_colour_rgb(255, 208, 130), 0.95, 1.10);
                mqs_mask_draw_shadow(_mk, _mx, _mTop, 1, make_colour_rgb(255, 208, 130), 0.85, 1.04);
            } else {
                mqs_mask_draw_shadow(_mk, _mx + _L.cell * 0.032, _mTop + _L.cell * 0.036, 1, c_black, 0.55, 1.02);
            }
            mqs_mask_draw(_mk, _mx, _mTop, 1, 1);
            mqs_cord_draw(_cx, _pegY, _kx, _ky, _cw, "knot");
            continue;
        }
        mqs_peg_draw(_cx, _pegY, _pegR);
        mqs__over_begin();
        // an empty peg: a short loose end of cord, faint; the cursor on an empty peg is a faint warm halo
        mqs__polyline([[_cx, _pegY + 4], [_cx - _L.cell * 0.04, _pegY + _L.cell * 0.16]], 2, make_colour_rgb(140, 43, 36), 0.35);
        if (_idx == _cursor) mqs__ellipse(_cx, _pegY, _pegR * 2.2, _pegR * 2.2, 0, make_colour_rgb(255, 208, 130), 0.22);
        gpu_pop_state();
    }
    // the brass count plate, the title and the foot
    var _count = string(mqs_masque_count(_m)) + " OF " + string(_n);
    mqs__placard_count(_x + 24, _y + floor(_L.head * 0.22), 150, floor(_L.head * 0.62), _count);
    var _t = is_string(_title) ? _title : _m.rack_title;
    mqs__over_begin();
    var _k = mqs_text_fit(fnt_masque_title, _t, _w - 380, _L.head * 0.50);
    draw_set_font(fnt_masque_title); draw_set_halign(fa_center); draw_set_valign(fa_middle);
    var _tf = gpu_get_texfilter(); gpu_set_texfilter(true);
    draw_text_transformed_colour(_x + _w / 2, _y + _L.head * 0.52, _t, _k, _k, 0, make_colour_rgb(230, 217, 190), make_colour_rgb(230, 217, 190), make_colour_rgb(230, 217, 190), make_colour_rgb(230, 217, 190), 0.92);
    var _sel = (_cursor < _n) ? _m.profiles[_cursor] : undefined;
    var _foot = is_undefined(_sel) ? "" : (variable_struct_exists(_m.taken, _sel.key) ? _sel.name : "an empty peg");
    var _kf = mqs_text_fit(fnt_masque, _foot, _w - 200, _L.foot * 0.62);
    draw_set_font(fnt_masque);
    draw_text_transformed_colour(_x + _w / 2, _y + _h - _L.foot * 0.55, _foot, _kf, _kf, 0, make_colour_rgb(230, 217, 190), make_colour_rgb(230, 217, 190), make_colour_rgb(230, 217, 190), make_colour_rgb(230, 217, 190), 0.78);
    if (_pages > 1) {
        draw_set_font(fnt_masque_ui); draw_set_halign(fa_right);
        var _ku = _L.foot * 0.46 / max(1, string_height("M"));
        draw_text_transformed_colour(_x + _w - 20, _y + _h - _L.foot * 0.55, string(_page + 1) + " / " + string(_pages), _ku, _ku, 0, make_colour_rgb(201, 162, 74), make_colour_rgb(201, 162, 74), make_colour_rgb(201, 162, 74), make_colour_rgb(201, 162, 74), 0.8);
    }
    gpu_set_texfilter(_tf);
    draw_set_halign(fa_left); draw_set_valign(fa_top);
    gpu_pop_state();
    _L.page = _page; _L.pages = _pages; _L.first = _first;
    return _L;
}

/// @function mqs__placard_count(x, y, w, h, text)
/// @description The small brass count plate: the count is FIGURES, so it is set in the sans (the plate serif's old-style
/// "1" reads as a small capital I). Internal.
function mqs__placard_count(_x, _y, _w, _h, _text) {
    mqs_placard_draw(_x, _y, _w, _h, "", undefined);
    var _P = mqs_palette(), _ink = mqs_colour(mqs_ink_for(_P.brass, 4.5).rgb);
    var _k = mqs_text_fit(fnt_masque_ui, _text, _w - 16, _h * 0.52);
    mqs__over_begin();
    mqs__engrave(fnt_masque_ui, _text, _x + _w / 2, _y + _h * 0.50, _k, _ink, 1);
    gpu_pop_state();
}

// ================================================================================================ the reveal

/// @function mqs_reveal_draw(masque, who, x, y, w, h, [eyebrow], [hint])
/// @description Draw one creature's true face in a rectangle: the wall, a peg, the cord, the mask with its cast shadow,
/// and an engraved placard with its name and its four readings. The mask carves itself ON SCREEN, band by band, the first
/// time (mqs_masque_update does the carving); returns true once it is whole. ⛔ The layout is derived from the MASK, not
/// from fractions of the screen: a crowned mask is half again as tall as a bare one, so the whole stack - cord, mask, gap,
/// placard - is measured and centred.
function mqs_reveal_draw(_m, _who, _x, _y, _w, _h, _eyebrow = "ITS TRUE FACE", _hint = "") {
    if (!is_struct(_m)) return false;
    var _p = mqs_masque_find(_m, _who);
    _x = mqs__num(_x); _y = mqs__num(_y); _w = clamp(floor(mqs__num(_w)), 64, 8192); _h = clamp(floor(mqs__num(_h)), 64, 8192);
    if (!is_string(_eyebrow)) _eyebrow = ""; if (!is_string(_hint)) _hint = "";
    draw_sprite(mqs__wall_for(_m, _w, _h), 0, _x, _y);
    if (is_undefined(_p)) return false;
    var _plH = max(34, floor(_h * 0.07)), _plGap = floor(_h * 0.022), _hint_room = floor(_h * 0.042), _top0 = floor(_h * 0.11);
    var _size = (_m.reveal_height > 0) ? _m.reveal_height : floor(min(_h * 0.60, _w * 0.62));
    var _k = mqs__mask_key(_p, _size);
    var _mk = variable_struct_exists(_m.masks, _k) ? _m.masks[$ _k] : undefined;
    var _job = undefined;
    if (is_undefined(_mk)) {
        if (_m.reveal_key != _k || !is_struct(_m.reveal_job)) {
            if (is_struct(_m.reveal_job) && !_m.reveal_job.done) mqs_carve_cancel(_m.reveal_job);
            _m.reveal_job = mqs_carve_begin(_p, _size);
            _m.reveal_key = _k;
        }
        _job = _m.reveal_job;
    }
    // the stack, measured: while it carves the unrotated job size stands in for the finished box
    var _bw = is_undefined(_mk) ? _job.w : _mk.box_w, _bh = is_undefined(_mk) ? _job.h : _mk.box_h;
    var _cordLen = max(24, floor(_size * 0.125));
    var _stack = _cordLen + _bh + _plGap + _plH;
    var _top = max(_top0, floor((_h - _hint_room - _stack) / 2));
    var _mTop = _y + _top + _cordLen, _cx = _x + floor(_w / 2), _mx = _cx - _bw / 2;
    var _kx, _ky;
    if (is_undefined(_mk)) { _kx = _mx + _job.w * 0.30; _ky = _mTop + _job.h * 0.10; }
    else { _kx = _mx + _mk.box_knot_x; _ky = _mTop + _mk.box_knot_y; }
    var _pegY = max(_y + 20, min(_ky - _cordLen, _mTop - 10));
    var _cw = max(2, floor(_size * 0.0075));
    mqs_peg_draw(_cx, _pegY, max(5, floor(_size * 0.031)));
    if (!is_undefined(_mk)) {
        mqs_cord_draw(_cx, _pegY, _kx, _ky, _cw, "run");
        mqs_mask_draw_shadow(_mk, _mx + _size * 0.034, _mTop + _size * 0.038, 1, c_black, 0.62, 1.03);
        mqs_mask_draw(_mk, _mx, _mTop, 1, 1);
        mqs_cord_draw(_cx, _pegY, _kx, _ky, _cw, "knot");
    } else {
        // carving: the rows struck so far appear on the wall where the mask will hang
        var _s = mqs_carve_preview(_job);
        if (surface_exists(_s)) {
            mqs__over_begin();
            gpu_set_texfilter(true);
            draw_surface_ext(_s, _cx + _job.w * 0.5 - _job.w, _mTop + (_bh - _job.h) / 2, 1, 1, 0, c_white, 1);
            gpu_pop_state();
        }
    }
    // the eyebrow, the placard and the hint
    mqs__over_begin();
    var _tf = gpu_get_texfilter(); gpu_set_texfilter(true);
    draw_set_halign(fa_center); draw_set_valign(fa_middle);
    if (is_string(_eyebrow) && _eyebrow != "") {
        var _ke = mqs_text_fit(fnt_masque_ui, _eyebrow, _w - 40, max(11, _h * 0.024));
        draw_set_font(fnt_masque_ui);
        draw_text_transformed_colour(_cx, _y + _h * 0.065, _eyebrow, _ke, _ke, 0, make_colour_rgb(201, 162, 74), make_colour_rgb(201, 162, 74), make_colour_rgb(201, 162, 74), make_colour_rgb(201, 162, 74), 0.85);
    }
    if (is_string(_hint) && _hint != "") {
        var _kh = mqs_text_fit(fnt_masque_ui, _hint, _w - 40, max(10, _h * 0.021));
        draw_set_font(fnt_masque_ui);
        draw_text_transformed_colour(_cx, _y + _h - _hint_room * 0.55, _hint, _kh, _kh, 0, make_colour_rgb(230, 217, 190), make_colour_rgb(230, 217, 190), make_colour_rgb(230, 217, 190), make_colour_rgb(230, 217, 190), 0.45);
    }
    gpu_set_texfilter(_tf);
    draw_set_halign(fa_left); draw_set_valign(fa_top);
    gpu_pop_state();
    var _pw = min(_w - 40, max(300, floor(_w * 0.40)));
    mqs_placard_draw(_cx - _pw / 2, min(_y + _h - _hint_room - _plH, _mTop + _bh + _plGap), _pw, _plH, _p.name, _p.readings);
    return !is_undefined(_mk);
}
