/// mqs_carve.gml - Masque's carving: strikes a mask from a profile - ten face structures, twelve superstructures, banded
/// paint, inlay, wear and one break - into a sprite, as a JOB you can spread over frames.
///
/// Masque - Every Creature Carves Its Own Mask, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// PUBLIC
///   mqs_carve(profile, height)                -> a finished mask: { sprite, w, h, tilt, knot_x, knot_y, box_w, box_h,
///                                                box_knot_x, box_knot_y, shadow, ms } (runs the whole job now)
///   mqs_carve_begin(profile, height)          -> a job; step it with mqs_carve_step until it returns true
///   mqs_carve_step(job, budget_ms)            -> true when the mask is finished (job.mask is then the result above)
///   mqs_carve_progress(job)                   -> 0..1
///   mqs_carve_cancel(job)                     -> free whatever a job holds (a finished job's sprites are yours)
///   mqs_mask_draw(mask, x, y, [scale], [alpha]) -> draws a finished mask with its tilt, its box's top-left at x, y
///   mqs_mask_free(mask)                       -> deletes a finished mask's sprites
///
/// ONE DRAW PATH, SCALED. The reveal carves at ~420 px, the rack at ~100 px, your own code at whatever you ask for: the
/// same function every time, and the only thing that differs is `height`. ⛔ There is deliberately no second, "simpler"
/// carver for small sizes - two code paths that must agree drift apart, and the one that re-implements is the one that
/// drifts.
///
/// WHAT A MASK IS MADE OF
///   the SILHOUETTE      a half-width curve sampled down the face, mirrored, with a seeded lean (no mask is symmetrical)
///   the RELIEF          masses summed into a height field and LIT: the highlight and the shadow are consequences of form
///   the VOIDS           eye-holes and a mouth cut THROUGH, with a lit inner rim. A mask has holes; a portrait has eyes.
///   the SUPERSTRUCTURE  grows out of the brow, lit by the same light as the face
///   the PIGMENT         banded paint that follows the planes and wears thin on the ridges; the base material shows at
///                       every edge, the paint layer has a lit lip, and the grain of the wood runs THROUGH it
///   the INLAY           one side only; the WEAR: grain, chips on the lit edge, a crack that lengthens; the BREAK: one
///
/// ⛔ The GEOMETRY and the per-point functions are ported line for line from the RPG Maker MZ VisageCarve.js and held to it
/// (mqs_oracle). The PIXEL PASS lights the relief from a 3 px grid of it (gridn3: the height summed at grid nodes, the
/// slope taken at the nodes and interpolated), and answers "is this point part of the object" from a 2x2-per-pixel
/// grid built once per mask: MEASURED in the design probe as 2.2-4x cheaper than summing every mass at every pixel, and
/// LOOKED AT at 4x beside the direct sum (no visible difference).

#macro MQS_FACE_ASPECT 0.46
// MQS_PI is JavaScript's Math.PI written out, so the geometry uses the same constant as the MZ original. (It did NOT
// fix the mane's one mismatched lock - that was the sign of a cosine at 3 x pi / 2, see the mane below.)
#macro MQS_PI 3.141592653589793
#macro MQS_PAINT_T 0.24
#macro MQS_PAINT_EDGE 0.155
#macro MQS_LIP_TEXELS 1.25
#macro MQS_PAINT_WANT 30
#macro MQS_PAINT_WANT_AGE 12
#macro MQS_CAVITY 0.18
#macro MQS_BOUND_TOP 0.16
#macro MQS_BOUND_BOTTOM 0.68

// ================================================================================================ the tables

/// @function mqs__silhouette(structure)
/// @description The structure's half-widths, top (y 0) to chin (y 1), in face units. A construct is a slab, a spirit
/// tapers to nothing, an insect is narrow at the crown and wide at the mandible. Internal, pure.
function mqs__silhouette(_s) {
    switch (_s) {
        case "beast": return [0.46, 0.70, 0.86, 0.82, 0.66, 0.46, 0.34, 0.22];
        case "undead": return [0.50, 0.70, 0.78, 0.70, 0.58, 0.50, 0.44, 0.20];
        case "spirit": return [0.38, 0.58, 0.68, 0.64, 0.56, 0.42, 0.26, 0.08];
        case "construct": return [0.66, 0.78, 0.82, 0.82, 0.80, 0.74, 0.62, 0.46];
        case "dragon": return [0.44, 0.72, 0.88, 0.80, 0.66, 0.52, 0.40, 0.26];
        case "insect": return [0.34, 0.56, 0.72, 0.80, 0.84, 0.70, 0.46, 0.24];
        case "aquatic": return [0.54, 0.76, 0.88, 0.86, 0.78, 0.62, 0.42, 0.16];
        case "plant": return [0.58, 0.74, 0.84, 0.82, 0.76, 0.66, 0.50, 0.28];
        case "fiend": return [0.56, 0.80, 0.84, 0.76, 0.64, 0.48, 0.32, 0.10];
        default: return [0.52, 0.72, 0.80, 0.78, 0.70, 0.56, 0.36, 0.12];
    }
}

/// @function mqs__masses_for(structure)
/// @description Each structure's relief masses in face units (a negative amp is a hollow). The nose ridge carries the one
/// specular in every set: it is the highest thing on the face. Internal, pure.
function mqs__masses_for(_s) {
    var _m = [
        mqs__mass(0, 0.16, 0.74, 0.22, 0.50), mqs__mass(0, 0.34, 0.82, 0.075, 0.70, "ridge"),
        mqs__mass(-0.44, 0.56, 0.32, 0.21, 0.58), mqs__mass(0.44, 0.56, 0.32, 0.21, 0.58),
        mqs__mass(0, 0.50, 0.105, 0.25, 0.98, "ridge"), mqs__mass(0, 0.86, 0.38, 0.15, 0.44),
        mqs__mass(-0.40, 0.43, 0.23, 0.115, -0.66, "hollow"), mqs__mass(0.40, 0.43, 0.23, 0.115, -0.66, "hollow"),
        mqs__mass(0, 0.745, 0.26, 0.075, -0.30, "hollow")
    ];
    var _x = [];
    switch (_s) {
        case "beast": _x = [mqs__mass(0, 0.70, 0.26, 0.20, 0.62), mqs__mass(0, 0.62, 0.13, 0.13, 0.40)]; break;
        case "undead": _x = [mqs__mass(-0.62, 0.30, 0.16, 0.14, -0.34, "hollow"), mqs__mass(0.62, 0.30, 0.16, 0.14, -0.34, "hollow"),
            mqs__mass(-0.46, 0.54, 0.20, 0.09, 0.40, "ridge"), mqs__mass(0.46, 0.54, 0.20, 0.09, 0.40, "ridge")]; break;
        case "spirit": _x = [mqs__mass(0, 0.28, 0.50, 0.16, 0.22)]; break;
        case "construct": _x = [mqs__mass(0, 0.50, 0.90, 0.035, 0.34, "ridge"), mqs__mass(-0.52, 0.70, 0.24, 0.16, 0.30),
            mqs__mass(0.52, 0.70, 0.24, 0.16, 0.30)]; break;
        case "dragon": _x = [mqs__mass(0, 0.72, 0.22, 0.24, 0.70, "ridge"), mqs__mass(-0.54, 0.30, 0.14, 0.10, 0.46),
            mqs__mass(0.54, 0.30, 0.14, 0.10, 0.46)]; break;
        case "insect": _x = [mqs__mass(-0.52, 0.80, 0.18, 0.16, 0.56), mqs__mass(0.52, 0.80, 0.18, 0.16, 0.56),
            mqs__mass(0, 0.22, 0.36, 0.05, 0.30, "ridge")]; break;
        case "aquatic": _x = [mqs__mass(-0.66, 0.62, 0.12, 0.18, 0.34, "ridge"), mqs__mass(0.66, 0.62, 0.12, 0.18, 0.34, "ridge"),
            mqs__mass(0, 0.30, 0.60, 0.26, 0.26)]; break;
        case "plant": _x = [mqs__mass(-0.34, 0.24, 0.16, 0.13, 0.44), mqs__mass(0.48, 0.36, 0.13, 0.11, 0.38),
            mqs__mass(-0.20, 0.80, 0.15, 0.12, 0.34)]; break;
        case "fiend": _x = [mqs__mass(-0.30, 0.38, 0.30, 0.06, 0.54, "ridge", -0.42), mqs__mass(0.30, 0.38, 0.30, 0.06, 0.54, "ridge", 0.42),
            mqs__mass(0, 0.92, 0.16, 0.12, 0.40)]; break;
    }
    for (var _i = 0; _i < array_length(_x); _i++) array_push(_m, _x[_i]);
    return _m;
}

/// @function mqs__relief_depth(material)
/// @description How deep the relief reads, by material. Lacquer is flatter and glossier. Internal, pure.
function mqs__relief_depth(_mat) { return (_mat == "bone") ? 0.38 : ((_mat == "lacquer") ? 0.30 : 0.44); }

/// @function mqs__eye(structure)
/// @description [w, h, tilt, form] of the eye-holes, the width in REAL units (converted once, in the geometry). Internal.
function mqs__eye(_s) {
    switch (_s) {
        case "beast": return [0.22, 0.070, 0.26, "almond"];
        case "undead": return [0.19, 0.145, 0.00, "round"];
        case "spirit": return [0.085, 0.170, 0.10, "slit"];
        case "construct": return [0.24, 0.055, 0.00, "slot"];
        case "dragon": return [0.24, 0.055, 0.30, "slit"];
        case "insect": return [0.25, 0.165, 0.14, "round"];
        case "aquatic": return [0.20, 0.150, 0.00, "round"];
        case "plant": return [0.19, 0.105, 0.18, "leaf"];
        case "fiend": return [0.23, 0.095, 0.34, "wedge"];
        default: return [0.20, 0.085, 0.06, "almond"];
    }
}

/// @function mqs__mouth(structure)
/// @description [w, h, form, teeth] of the mouth, the width in REAL units. Internal, pure.
function mqs__mouth(_s) {
    switch (_s) {
        case "beast": return [0.24, 0.095, "snarl", 5];
        case "undead": return [0.34, 0.075, "grin", 7];
        case "spirit": return [0.12, 0.100, "slot", 0];
        case "construct": return [0.40, 0.045, "grille", 6];
        case "dragon": return [0.30, 0.090, "snarl", 6];
        case "insect": return [0.22, 0.110, "grin", 4];
        case "aquatic": return [0.30, 0.115, "round", 0];
        case "plant": return [0.22, 0.085, "leaf", 0];
        case "fiend": return [0.30, 0.080, "grin", 8];
        default: return [0.26, 0.055, "slot", 0];
    }
}

// ================================================================================================ the superstructures
// A crown is a list of LIMBS (closed polygons, lit exactly like the face, never with a highlight of their own) plus the
// masses that give them relief. ⛔ Every number is in REAL units (fractions of the mask's height) and the whole set is
// converted to face-x exactly ONCE, at the end of mqs__crown_of: a number authored in the squeezed face space looks
// untouched and has changed meaning.

/// @function mqs__horn(bx, by, len, thick, sweep, dir, [ang0])
/// @description A tapered horn as a closed polygon (real units): base, length, base half-width, total bend (radians),
/// -1 left / +1 right, and where it points at the root (default up with a lean). Internal, pure.
function mqs__horn(_bx, _by, _len, _thick, _sweep, _dir, _ang0 = undefined) {
    var _left = [], _right = [];
    var _ang = is_undefined(_ang0) ? (-MQS_PI / 2 + _dir * 0.42) : _ang0;
    var _x = _bx, _y = _by, _steps = 14;
    for (var _i = 0; _i <= _steps; _i++) {
        var _t = _i / _steps;
        var _w = _thick * (1 - _t) * (1 - _t * 0.35);
        var _nx = cos(_ang + MQS_PI / 2) * _w, _ny = sin(_ang + MQS_PI / 2) * _w;
        array_push(_left, [_x + _nx, _y + _ny]);
        array_push(_right, [_x - _nx, _y - _ny]);
        _ang += _sweep / _steps;
        _x += cos(_ang) * (_len / _steps);
        _y += sin(_ang) * (_len / _steps);
    }
    for (var _j = array_length(_right) - 1; _j >= 0; _j--) array_push(_left, _right[_j]);
    return _left;
}

/// @function mqs__spine(masses, x0, y0, x1, y1, rad, amp)
/// @description A ridge along any axis, built from overlapping ROUND masses (a circle needs no rotation). The count
/// comes from the run at a pitch of 0.85 r - a typed count leaves gaps, and a gap between two swells is a string of
/// beads. Real units. Internal.
function mqs__spine(_m, _x0, _y0, _x1, _y1, _rad, _amp) {
    var _run = sqrt((_x1 - _x0) * (_x1 - _x0) + (_y1 - _y0) * (_y1 - _y0));
    var _pitch = max(0.0001, _rad * 0.85);
    var _n = max(2, floor(_run / _pitch + 0.5));
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n;
        array_push(_m, mqs__mass(_x0 + (_x1 - _x0) * _t, _y0 + (_y1 - _y0) * _t, _rad, _rad, _amp));
    }
}

/// @function mqs__crown_of(crown, rng)
/// @description The superstructure for a crown id: {limbs, masses} in FACE space. Draws from the mask's own generator in
/// the MZ original's order (each draw its own statement). Internal.
function mqs__crown_of(_crown, _r) {
    var _limbs = [], _masses = [];
    switch (_crown) {
        case "browRidge": {
            array_push(_masses, mqs__mass(0, 0.255, 0.33, 0.06, 0.70, "ridge"));
            var _b = [];
            for (var _i = 0; _i < 28; _i++) { var _a = MQS_PI * (1 + _i / 27); array_push(_b, [cos(_a) * 0.47, 0.295 + sin(_a) * 0.225]); }
            array_push(_b, [0.40, 0.36]); array_push(_b, [-0.40, 0.36]);
            array_push(_limbs, _b);
            break;
        }
        case "twinHorns": {
            var _j1 = mqs_rnd(_r);
            array_push(_limbs, mqs__horn(-0.26, 0.17, 0.42, 0.055, 0.30 + 0.25 * _j1, -1));
            var _j2 = mqs_rnd(_r);
            array_push(_limbs, mqs__horn(0.26, 0.17, 0.42, 0.055, -(0.30 + 0.25 * _j2), 1));
            array_push(_masses, mqs__mass(-0.26, 0.14, 0.07, 0.10, 0.5));
            array_push(_masses, mqs__mass(0.26, 0.14, 0.07, 0.10, 0.5));
            break;
        }
        case "crest": {
            var _jh = mqs_rnd(_r);
            var _h = 0.42 + 0.12 * _jh, _cw = 0.072;
            var _c = [];
            for (var _k = 0; _k < 34; _k++) {
                var _a2 = MQS_PI * (_k / 33);
                var _notch = 1 - 0.17 * abs(sin(_a2 * 4.5));
                array_push(_c, [cos(_a2) * _cw * (0.62 + 0.38 * sin(_a2)), 0.12 - sin(_a2) * _h * _notch]);
            }
            array_push(_c, [-_cw * 0.62, 0.26]); array_push(_c, [_cw * 0.62, 0.26]);
            array_push(_limbs, _c);
            mqs__spine(_masses, 0, 0.10 - _h * 0.10, 0, 0.10 - _h * 0.86, _cw * 0.60, 0.26);
            array_push(_masses, mqs__mass(0, 0.13, 0.085, 0.075, 0.46));
            break;
        }
        case "fan": {
            for (var _bl = 0; _bl < 5; _bl++) {
                var _u2 = _bl / 4;
                var _a3 = -MQS_PI * (0.16 + 0.68 * _u2);
                var _len = 0.30 + sin(MQS_PI * _u2) * 0.24;
                var _bx = cos(_a3) * 0.17, _by = 0.17 + sin(_a3) * 0.10;
                var _jf = mqs_rnd(_r);
                array_push(_limbs, mqs__horn(_bx, _by, _len, 0.052, -0.18 + 0.36 * _jf, (_a3 < -MQS_PI / 2) ? -1 : 1, _a3));
                mqs__spine(_masses, _bx + cos(_a3) * _len * 0.16, _by + sin(_a3) * _len * 0.16,
                    _bx + cos(_a3) * _len * 0.78, _by + sin(_a3) * _len * 0.78, 0.028, 0.24);
            }
            array_push(_masses, mqs__mass(0, 0.12, 0.20, 0.08, 0.46, "ridge"));
            break;
        }
        case "antlerFrame": {
            for (var _s = -1; _s <= 1; _s += 2) {
                var _ja = mqs_rnd(_r);
                array_push(_limbs, mqs__horn(_s * 0.23, 0.15, 0.50, 0.034, -_s * (0.5 + 0.3 * _ja), _s));
                array_push(_limbs, mqs__horn(_s * 0.30, -0.06, 0.26, 0.021, -_s * 0.4, _s));
                array_push(_limbs, mqs__horn(_s * 0.19, -0.16, 0.22, 0.019, -_s * 0.9, _s));
            }
            break;
        }
        case "plume": {
            for (var _p = 0; _p < 3; _p++) {
                var _lean = (_p - 1) * 0.155;
                var _jp = mqs_rnd(_r);
                var _plen = ((_p == 1) ? 0.62 : 0.50) * (0.92 + 0.16 * _jp);
                var _pw = 0.052;
                var _f = [];
                for (var _q = 0; _q < 18; _q++) { var _t = _q / 17; var _w = _pw * sin(MQS_PI * _t) * (1 - _t * 0.22); array_push(_f, [_lean * (0.3 + _t) + _w, 0.12 - _t * _plen]); }
                for (var _q2 = 0; _q2 < 18; _q2++) { var _uu = 1 - _q2 / 17; var _w2 = _pw * sin(MQS_PI * _uu) * (1 - _uu * 0.22); array_push(_f, [_lean * (0.3 + _uu) - _w2, 0.12 - _uu * _plen]); }
                array_push(_limbs, _f);
                mqs__spine(_masses, _lean * 0.48, 0.12 - 0.18 * _plen, _lean * 1.14, 0.12 - 0.84 * _plen, _pw * 0.50, 0.24);
            }
            array_push(_masses, mqs__mass(0, 0.10, 0.12, 0.09, 0.42));
            break;
        }
        case "haloRing": {
            // ⛔ a ring is a STRIP OF QUADS, never an outer loop with a reversed inner loop joined to it: the even-odd
            // test over one point list turns the seam edges into missing ring
            for (var _i2 = 0; _i2 < 44; _i2++) {
                var _b0 = MQS_PI * 2 * (_i2 / 44), _b1 = MQS_PI * 2 * ((_i2 + 1) / 44);
                array_push(_limbs, [[cos(_b0) * 0.47, 0.06 + sin(_b0) * 0.44], [cos(_b1) * 0.47, 0.06 + sin(_b1) * 0.44],
                    [cos(_b1) * 0.395, 0.06 + sin(_b1) * 0.365], [cos(_b0) * 0.395, 0.06 + sin(_b0) * 0.365]]);
            }
            break;
        }
        case "tuskPair": {
            array_push(_limbs, mqs__horn(-0.30, 0.62, 0.38, 0.042, -0.75, -1));
            array_push(_limbs, mqs__horn(0.30, 0.62, 0.38, 0.042, 0.75, 1));
            break;
        }
        case "crownOfThorns": {
            for (var _c2 = 0; _c2 < 11; _c2++) {
                var _a4 = MQS_PI * (1.06 + 0.88 * (_c2 / 10));
                var _l2 = 0.16 + (_c2 % 3) * 0.07;
                array_push(_limbs, mqs__horn(cos(_a4) * 0.37, 0.26 + sin(_a4) * 0.32, _l2, 0.018, ((_c2 % 2) != 0) ? 0.5 : -0.5, (_c2 < 5.5) ? -1 : 1));
            }
            break;
        }
        case "mane": {
            for (var _m2 = 0; _m2 < 13; _m2++) {
                var _a5 = MQS_PI * (1.02 + 0.96 * (_m2 / 12));
                var _l3 = 0.20 + sin(MQS_PI * (_m2 / 12)) * 0.26 + (_m2 % 2) * 0.05;
                // ⛔ the MZ original chose the side by the SIGN of cos(a); the middle lock sits exactly on 3 x pi / 2, where
                // JavaScript returns -1.8e-16 and GML's cos did not give the same sign (the suite's lattice check failed
                // on this lock with either pi constant), so the side is decided by position instead, which is what that
                // sign always meant: the first seven locks lean left (suite stage 30 then matched the MZ original)
                array_push(_limbs, mqs__horn(cos(_a5) * 0.39, 0.34 + sin(_a5) * 0.36, _l3, 0.036, ((_m2 % 2) != 0) ? 0.35 : -0.30, (_m2 * 2 <= 12) ? -1 : 1));
            }
            break;
        }
        case "sunDisc": {
            // the disc is a backing plate the jaw hangs below; its rays are horns rooted INSIDE it, upper arc only
            var _cy = 0.21, _disc = [];
            for (var _i3 = 0; _i3 < 56; _i3++) {
                var _a6 = MQS_PI * 2 * (_i3 / 56);
                var _jw = mqs_rnd(_r);
                var _wob = 1 + sin(_a6 * 3 + _jw * 6.28) * 0.030;
                array_push(_disc, [cos(_a6) * 0.470 * _wob, _cy + sin(_a6) * 0.430 * _wob]);
            }
            array_push(_limbs, _disc);
            for (var _pq = 0; _pq < 11; _pq++) {
                var _a7 = MQS_PI * (1.045 + 0.91 * (_pq / 10));
                var _top = sin(MQS_PI * (_pq / 10));
                var _ln = 0.24 + 0.20 * _top;
                // two seeded rays broken short (JavaScript's || short-circuits: the second draw only happens on a miss)
                var _d1 = mqs_rnd(_r);
                if (_pq == 2 + floor(_d1 * 3)) _ln *= 0.62;
                else { var _d2 = mqs_rnd(_r); if (_pq == 7 + floor(_d2 * 3)) _ln *= 0.62; }
                var _half = 0.046 - 0.009 * _top, _rIn = 0.340;
                var _cA = cos(_a7), _sA = sin(_a7);
                array_push(_limbs, mqs__horn(_cA * _rIn, _cy + _sA * _rIn * 0.92, _ln + (_rIn * 0.34), _half * 1.35, ((_pq % 2) != 0) ? 0.22 : -0.26, (_cA < 0) ? -1 : 1, _a7));
            }
            array_push(_masses, mqs__mass(0, _cy, 0.34, 0.36, 0.24));
            break;
        }
        default: break;
    }
    // ⛔ THE CONVERSION HAPPENS EXACTLY ONCE, HERE: everything above is real units, everything downstream face space
    for (var _L = 0; _L < array_length(_limbs); _L++) {
        var _pts = _limbs[_L];
        for (var _pi = 0; _pi < array_length(_pts); _pi++) _pts[_pi][0] = _pts[_pi][0] / MQS_FACE_ASPECT;
    }
    for (var _M = 0; _M < array_length(_masses); _M++) { _masses[_M][0] /= MQS_FACE_ASPECT; _masses[_M][2] /= MQS_FACE_ASPECT; }
    return { limbs: _limbs, masses: _masses };
}

// ================================================================================================ geometry

/// @function mqs__half_width(table, y)
/// @description Half-width of the silhouette at a height, smoothly interpolated between the eight samples. Internal.
function mqs__half_width(_tab, _y) {
    if (_y < 0 || _y > 1) return 0;
    var _f = _y * 7;
    var _i = min(6, floor(_f));
    var _t = _f - _i;
    var _s = _t * _t * (3 - 2 * _t);
    return _tab[_i] + (_tab[_i + 1] - _tab[_i]) * _s;
}

/// @function mqs__in_poly(pts, x, y)
/// @description Even-odd point in polygon. Internal, pure.
function mqs__in_poly(_pts, _x, _y) {
    var _in = false, _n = array_length(_pts), _j = _n - 1;
    for (var _i = 0; _i < _n; _i++) {
        var _xi = _pts[_i][0], _yi = _pts[_i][1], _xj = _pts[_j][0], _yj = _pts[_j][1];
        if (((_yi > _y) != (_yj > _y))) {
            var _dy = _yj - _yi;
            if (_x < (_xj - _xi) * (_y - _yi) / ((_dy != 0) ? _dy : 0.000000001) + _xi) _in = !_in;
        }
        _j = _i;
    }
    return _in;
}

/// @function mqs__dentition(mouth, rng)
/// @description Two INDEPENDENT rows of tooth depths for one mouth, built once per mask. ⛔ Perfectly interlocking
/// triangles are a zigzag, and a zigzag is a cartoon monster: a real jaw has independent rows, teeth of different
/// lengths and real GAPS. Internal.
function mqs__dentition(_mouth, _r) {
    var _n = max(2, _mouth.teeth), _top = [], _bot = [], _point = 1.55;
    switch (_mouth.form) {
        case "snarl":
            _point = 1.05;
            for (var _i = 0; _i < _n; _i++) {
                var _u = abs((_i + 0.5) / _n * 2 - 1);
                var _a = mqs_rnd(_r);
                array_push(_top, (0.30 + 0.52 * _u * _u) * (0.85 + _a * 0.30));
                var _b = mqs_rnd(_r);
                if (_b < 0.45) array_push(_bot, 0); else { var _c = mqs_rnd(_r); array_push(_bot, (0.14 + 0.34 * _u) * (0.8 + _c * 0.4)); }
            }
            break;
        case "grin":
            _point = 2.1;
            for (var _i2 = 0; _i2 < _n; _i2++) {
                var _a2 = mqs_rnd(_r);
                if (_a2 < 0.18) array_push(_top, 0); else { var _b2 = mqs_rnd(_r); array_push(_top, 0.34 + _b2 * 0.22); }
                var _c2 = mqs_rnd(_r);
                if (_c2 < 0.34) array_push(_bot, 0); else { var _d2 = mqs_rnd(_r); array_push(_bot, 0.26 + _d2 * 0.20); }
            }
            break;
        case "leaf": case "round": case "slot":
            _point = 1.9;
            for (var _i3 = 0; _i3 < _n; _i3++) {
                var _a3 = mqs_rnd(_r);
                if (_a3 < 0.5) { var _b3 = mqs_rnd(_r); array_push(_top, 0.22 + _b3 * 0.16); } else array_push(_top, 0);
                array_push(_bot, 0);
            }
            break;
        default:
            _point = 1.0;
            for (var _i4 = 0; _i4 < _n; _i4++) {
                var _a4 = mqs_rnd(_r);
                if (_a4 < 0.22) array_push(_top, 0); else { var _b4 = mqs_rnd(_r); array_push(_top, 0.24 + _b4 * 0.44); }
                var _c4 = mqs_rnd(_r);
                if (_c4 < 0.30) array_push(_bot, 0); else { var _d4 = mqs_rnd(_r); array_push(_bot, 0.20 + _d4 * 0.40); }
            }
            break;
    }
    return { n: _n, point: _point, top: _top, bot: _bot };
}

/// @function mqs__geometry(profile)
/// @description Every piece of geometry a mask needs, in face units. Internal.
function mqs__geometry(_p) {
    var _r = mqs_rng(_p.seed);
    var _sil = mqs__silhouette(_p.structure);
    var _crown = mqs__crown_of(_p.crown, _r);
    var _masses = mqs__masses_for(_p.structure);
    for (var _i = 0; _i < array_length(_crown.masses); _i++) array_push(_masses, _crown.masses[_i]);
    // ⛔ THE FIRST OF THE THREE ASYMMETRIES, AND IT IS CONSTRUCTION: vertical symmetry snaps the eye to a known glyph
    // (two holes and a slot is a SMILEY), so every mask leans a little and its eyes sit at slightly different heights
    var _d0 = mqs_rnd(_r); var _lean = ((_d0 - 0.5) * 0.045) / MQS_FACE_ASPECT;
    var _d1 = mqs_rnd(_r); var _eyeSkew = (_d1 - 0.5) * 0.05;
    var _d2 = mqs_rnd(_r); var _mouthSkew = ((_d2 - 0.5) * 0.014) / MQS_FACE_ASPECT;
    var _d3 = mqs_rnd(_r); var _inlaySide = (_d3 < 0.5) ? -1 : 1;
    var _d4 = mqs_rnd(_r); var _crackX = (_d4 - 0.5) * 0.9;
    var _d5 = mqs_rnd(_r); var _d6 = mqs_rnd(_r);
    var _tilt = ((_d5 < 0.5) ? -1 : 1) * (3 + _d6 * 4) * MQS_PI / 180;
    var _mat = mqs__structure_material(_p.structure);
    var _mats = mqs__materials();
    var _e = mqs__eye(_p.structure), _mo = mqs__mouth(_p.structure);
    var _geo = {
        profile: _p, sil: _sil, lean: _lean, crown_limbs: _crown.limbs, masses: _masses,
        relief: mqs__relief_depth(_mat), material_id: _mat, material: _mats[$ _mat],
        eye: { w: _e[0] / MQS_FACE_ASPECT, h: _e[1], tilt: _e[2], form: _e[3], c: cos(_e[2]), s: sin(_e[2]) },
        mouth: { w: _mo[0] / MQS_FACE_ASPECT, h: _mo[1], form: _mo[2], teeth: _mo[3] },
        eye_x: 0.185 / MQS_FACE_ASPECT, eye_y: 0.44, eye_skew: _eyeSkew / MQS_FACE_ASPECT, mouth_y: 0.745, mouth_skew: _mouthSkew,
        inlay_side: _inlaySide, crack_x: _crackX,
        crack_wobble: mqs__noise1((_p.seed ^ $2C41) & $FFFFFFFF, 3), grain: mqs__noise1((_p.seed ^ $7A3B) & $FFFFFFFF, 3),
        chip: mqs__noise2((_p.seed ^ $11D7) & $FFFFFFFF), tilt: _tilt, rng: _r,
        broken_limb: -1, broken_y: -1
    };
    _geo.teeth = mqs__dentition(_geo.mouth, _r);
    // ⛔ A BOUNDING BOX PER LIMB: the inside test runs several times per pixel
    var _minX = -1.05, _maxX = 1.05, _minY = 0, _maxY = 1.02;
    _geo.limb_box = [];
    for (var _li = 0; _li < array_length(_crown.limbs); _li++) {
        var _L = _crown.limbs[_li], _x0 = infinity, _x1 = -infinity, _y0 = infinity, _y1 = -infinity;
        for (var _k = 0; _k < array_length(_L); _k++) {
            var _q = _L[_k];
            if (_q[0] < _x0) _x0 = _q[0]; if (_q[0] > _x1) _x1 = _q[0];
            if (_q[1] < _y0) _y0 = _q[1]; if (_q[1] > _y1) _y1 = _q[1];
        }
        array_push(_geo.limb_box, [_x0, _y0, _x1, _y1]);
        if (_x0 < _minX) _minX = _x0; if (_x1 > _maxX) _maxX = _x1;
        if (_y0 < _minY) _minY = _y0; if (_y1 > _maxY) _maxY = _y1;
    }
    _geo.bounds = { min_x: _minX - 0.04, max_x: _maxX + 0.04, min_y: _minY - 0.04, max_y: _maxY + 0.04 };
    // ⛔ THE BREAK MUST BE ABLE TO HAPPEN: a broken horn cannot happen to a bare brow, so the substitution is explicit
    // and RECORDED (declared vs drawn)
    _geo.break_declared = _p.break_kind;
    _geo.break_drawn = _p.break_kind;
    if (_geo.break_drawn == "brokenHorn") {
        var _nl = array_length(_crown.limbs);
        if (_nl == 0) _geo.break_drawn = "chippedJaw";
        else {
            var _d7 = mqs_rnd(_r);
            _geo.broken_limb = floor(_d7 * _nl);
            var _box = _geo.limb_box[_geo.broken_limb];
            // ⛔ how deep the snap cuts depends on how many limbs there are to lose: a single-limb crown keeps its horn
            var _d8 = mqs_rnd(_r);
            var _deep = (_nl > 1) ? (0.34 + _d8 * 0.26) : (0.13 + _d8 * 0.13);
            _geo.broken_y = _box[1] + (_box[3] - _box[1]) * _deep;
        }
    }
    return _geo;
}

// ================================================================================================ the per-point functions

/// @function mqs__inside(geo, x, y)
/// @description Is this point part of the object: the silhouette or any crown limb (a snapped limb stops at its break).
/// Internal, pure.
function mqs__inside(_g, _x, _y) {
    if (_y >= 0 && _y <= 1) { if (abs(_x - _g.lean * _y) <= mqs__half_width(_g.sil, _y)) return true; }
    var _b = _g.limb_box;
    for (var _i = 0; _i < array_length(_g.crown_limbs); _i++) {
        var _bb = _b[_i];
        if (_x < _bb[0] || _x > _bb[2] || _y < _bb[1] || _y > _bb[3]) continue;
        if (_g.broken_limb == _i && _y < _g.broken_y) continue;
        if (mqs__in_poly(_g.crown_limbs[_i], _x, _y)) return true;
    }
    return false;
}

/// @function mqs__in_void(geo, x, y)
/// @description 0 outside the eye-holes and mouth, 1 inside, a value between on the rim. Internal, pure.
function mqs__in_void(_g, _x, _y) {
    var _e = _g.eye;
    for (var _s = -1; _s <= 1; _s += 2) {
        var _ex = _s * _g.eye_x + ((_s > 0) ? _g.eye_skew : 0);
        var _dx = _x - _ex, _dy = _y - _g.eye_y;
        var _c = _e.c, _sn = _s * _e.s;
        var _u = (_dx * _c - _dy * _sn) / (_e.w / 2);
        var _v = (_dx * _sn + _dy * _c) / (_e.h / 2);
        var _d;
        if (_e.form == "wedge") _d = abs(_u) + abs(_v) * 1.3;
        else if (_e.form == "leaf") _d = power(abs(_u), 1.6) + abs(_v);
        else _d = sqrt(_u * _u + _v * _v);
        if (_e.form == "slot") _d = max(abs(_u), abs(_v) * 1.1);
        if (_d < 1) return 1;
        if (_d < 1.10) return (1.10 - _d) / 0.10;
    }
    var _m = _g.mouth;
    var _mx = (_x - _g.mouth_skew) / (_m.w / 2), _my = (_y - _g.mouth_y) / (_m.h / 2);
    var _md;
    if (_m.form == "grin" || _m.form == "grille") _md = max(abs(_mx), abs(_my));
    else if (_m.form == "snarl") { var _q = max(0, _my) * 0.7 + max(0, -_my); _md = sqrt(_mx * _mx + _q * _q); }
    else if (_m.form == "leaf") _md = power(abs(_mx), 1.7) + abs(_my);
    else _md = sqrt(_mx * _mx + _my * _my);
    if (_md < 1) {
        if (_m.teeth > 0) {
            if (_m.form == "grille") {
                var _band = (_x - _g.mouth_skew + _m.w / 2) / (_m.w / (_m.teeth * 2));
                if ((_band - floor(_band)) < 0.34 && abs(_my) > 0.12) return 0;
            } else {
                var _T = _g.teeth;
                var _f = ((_mx + 1) / 2) * _T.n;
                var _ci = clamp(floor(_f), 0, _T.n - 1);
                var _cell = _f - _ci;
                var _tri = 1 - abs(_cell * 2 - 1);
                var _prof = min(1, _tri * _T.point);
                var _up = _T.top[_ci] * _prof, _dn = _T.bot[_ci] * _prof;
                if (_up > 0 && _my < -1 + _up * 2) return 0;
                if (_dn > 0 && _my > 1 - _dn * 2) return 0;
            }
        }
        return 1;
    }
    return (_md < 1.10) ? (1.10 - _md) / 0.10 : 0;
}

/// @function mqs__edge_distance(geo, x, y)
/// @description Distance from a point to the silhouette edge in face units, clamped at 0.3 (a crown limb counts as
/// edge-free, so a horn does not lose its paint along its whole length). Internal, pure.
function mqs__edge_distance(_g, _x, _y) {
    if (_y < 0 || _y > 1) return 0.3;
    var _d = mqs__half_width(_g.sil, _y) - abs(_x - _g.lean * _y);
    if (_d < 0) return 0.3;
    return min(0.3, min(_d, min(_y, 1 - _y) * 1.4));
}

/// @function mqs__rim_at(geo, x, y, px, py)
/// @description The lit rim, from the silhouette (never a stroke painted along a path): 0..1. Internal, pure.
function mqs__rim_at(_g, _x, _y, _px, _py) {
    var _o = 0;
    if (!mqs__inside(_g, _x - _px * 2, _y)) _o += 0.5;
    if (!mqs__inside(_g, _x, _y - _py * 2)) _o += 0.5;
    if (!mqs__inside(_g, _x - _px * 1.2, _y - _py * 1.2)) _o += 0.4;
    return min(1, _o);
}

/// @function mqs__bound_crack_x(geo, y)
/// @description Where a bound crack sits at a height. ⛔ One function, two consumers: the pixel pass cuts the crack and
/// the staples are set across it, so they can never disagree. Internal, pure.
function mqs__bound_crack_x(_g, _y) {
    var _sign = (_g.crack_x < 0) ? -1 : 1;
    return _g.crack_x * 0.92 + (_y - MQS_BOUND_TOP) * 0.30 * _sign + mqs__n1(_g.crack_wobble, _y * 5.5 + 2) * 0.040;
}

/// @function mqs__wear_at(geo, x, y, age, px)
/// @description Wear at a point: 0 sound, 1 bruised, 2 gone (the three breaks that are CUT are cut here). Internal, pure.
function mqs__wear_at(_g, _x, _y, _age, _px) {
    var _brk = _g.break_drawn, _hw, _d;
    if (_brk == "chippedJaw" && _y > 0.70) {
        _hw = mqs__half_width(_g.sil, _y);
        _d = _hw - abs(_x - _g.lean * _y);
        var _bite = 0.16 * (1 - abs(_y - 0.86) / 0.18);
        if (_x > 0 && _d < _bite) return 2;
        if (_x > 0 && _d < _bite + 0.02) return 1;
    }
    if (_brk == "faceCrack") {
        // a crack runs from ONE edge, at an angle, and stops (vertical, centred and full height reads as a seam)
        var _run = 0.14 + 0.62 * min(1, max(0, (_y - 0.06) / 0.80));
        var _fcx = _g.crack_x * 0.9 + (_y - 0.06) * 0.42 * ((_g.crack_x < 0) ? -1 : 1) + mqs__n1(_g.crack_wobble, _y * 5 + 3) * 0.045;
        if (_y > 0.06 && _y < 0.06 + _run * 1.02) {
            if (abs(_x - _fcx) < _px * 0.9) return 2;
            if (abs(_x - _fcx) < _px * 2.1) return 1;
        }
    }
    if (_brk == "boundCrack" && _y > MQS_BOUND_TOP && _y < MQS_BOUND_BOTTOM) {
        var _bcx = mqs__bound_crack_x(_g, _y);
        if (abs(_x - _bcx) < _px * 0.9) return 2;
        if (abs(_x - _bcx) < _px * 2.0) return 1;
    }
    if (_age <= 0) return 0;
    if (_y >= 0 && _y <= 1) {
        _hw = mqs__half_width(_g.sil, _y);
        _d = _hw - abs(_x - _g.lean * _y);
        var _lit = (_x < 0 || _y < 0.35);
        if (_d < 0.032 * _age && _lit) {
            var _n = mqs__n2(_g.chip, _x * 11, _y * 11);
            if (_n > 0.95 - _age * 0.055) return 2;
            if (_n > 0.88 - _age * 0.050) return 1;
        }
    }
    var _reach = 0.18 + _age * 0.19;
    if (_y < _reach) {
        var _cx = _g.crack_x + (_y * 0.30) * ((_g.crack_x < 0) ? -1 : 1) + mqs__n1(_g.crack_wobble, _y * 6) * 0.030;
        var _w = _px * (0.7 + _age * 0.22);
        if (abs(_x - _cx) < _w) return 1;
    }
    return 0;
}

/// @function mqs__paint_at(h, slope, edge, age, grain)
/// @description How much pigment sits on a point, 0..1: banded zones that follow the planes (never a flat tint), rubbed
/// through on the ridges (the slope is normalised FIRST: it is a gradient magnitude, p50 2.2, p90 8.8, not a fraction),
/// never held at an edge, and flaking off in patches with age (old paint flakes; it does not fade). Internal, pure.
function mqs__paint_at(_h, _slope, _edge, _age, _grain) {
    var _wear = 0.10 + _age * 0.175;
    // JavaScript's `% 1` keeps the sign of the dividend (a hollow's negative height gives a negative band, which reads as
    // inside the duty): written out as x - trunc(x) so the answer never depends on a runtime's modulo convention
    var _bx = _h * 1.45 + 0.25;
    var _band = _bx - ((_bx < 0) ? ceil(_bx) : floor(_bx));
    var _duty = 0.56 - _wear * 0.14;
    var _cover = (_band < _duty) ? 1 : max(0, 1 - (_band - _duty) * 4.2);
    var _rub = _slope / (_slope + 5.0);
    _cover *= 1 - _rub * (0.30 + _wear * 0.58);
    _cover *= min(1, _edge / (0.030 + _wear * 0.048));
    _cover *= 1 - max(0, _grain) * _wear * 0.45;
    var _lo = -0.05 + _age * 0.038, _hi = 0.78 - _age * 0.040;
    _cover = (_cover - _lo) / (_hi - _lo);
    return max(0, min(1, _cover));
}

/// @function mqs__paint_ink(cover)
/// @description The hard edge of the paint layer: 0 bare, 1 painted, a short ramp between. ⛔ Paint is a LAYER WITH AN
/// EDGE, not a tint with a falloff: a smooth field mixed straight on is an airbrush. Internal, pure.
function mqs__paint_ink(_cover) {
    var _v = (_cover - MQS_PAINT_T) / MQS_PAINT_EDGE + 0.5;
    return (_v <= 0) ? 0 : ((_v >= 1) ? 1 : _v);
}

/// @function mqs__paint_colour(profile, mid_rgb)
/// @description The colour the paint is laid in, separated from its own material, or undefined when the record carries
/// no pigment (physical is left unpainted by design). The separation wanted RISES with age: a relic's paint survives in
/// patches, so what survives must be more distinct. Internal, pure.
function mqs__paint_colour(_p, _mid) {
    if (!is_struct(_p) || !variable_struct_exists(_p, "pigment") || !is_struct(_p.pigment)) return undefined;
    var _base = mqs_rgb(_p.pigment.hex);
    if (is_undefined(_base)) return undefined;
    var _age = mqs__get(_p, "age_index", 0);
    if (!mqs__fin(_age)) _age = 0;
    return mqs__separate(_base, _mid, MQS_PAINT_WANT + _age * MQS_PAINT_WANT_AGE);
}
