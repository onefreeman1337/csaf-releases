{
  "$GMScript": "v1",
  "%Name": "mqs_carve",
  "name": "mqs_carve",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}