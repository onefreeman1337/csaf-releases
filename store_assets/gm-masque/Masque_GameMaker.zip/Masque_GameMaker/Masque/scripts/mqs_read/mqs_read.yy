{
  "$GMScript": "v1",
  "%Name": "mqs_read",
  "name": "mqs_read",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}