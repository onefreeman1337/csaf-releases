/// mqs_surface.gml - Masque's surface: colour, the three materials a mask is struck from, seeded grain, and the relief
/// field every mask is lit from. Nothing here knows what a mask is; it knows what oak, bone and lacquer are and how a
/// carved form behaves under ONE light. Pure: nothing here draws.
///
/// Masque - Every Creature Carves Its Own Mask, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// PUBLIC
///   mqs_palette()                     -> the palette by role, each an [r, g, b] array
///   mqs_colour(rgb)                   -> a GameMaker colour from an [r, g, b] array
///   mqs_rgb(hex)                      -> [r, g, b] from "#rrggbb" or "#rgb", or undefined for anything unreadable
///   mqs_ink_for(rgb, [want])          -> {rgb, ratio, cleared}: the ink to write on a surface (both directions tried)
///
/// THE ONE LIGHT. Every mask, peg, cord and placard is lit from the UPPER LEFT and slightly in front. One direction for
/// the whole product is what makes a wall of forty masks read as one wall rather than forty stickers.
/// HOW THE CARVING IS LIT. Not as shapes with a highlight painted on: a RELIEF is a sum of smooth masses (a brow, two
/// cheekbones, a nose ridge, a jaw) minus hollows (the sockets), and every pixel is lit from that relief's own slope.
/// Move a cheekbone and the highlight, the shadow and the worn edge all move with it.
///
/// ⛔ PORTED FROM THE RPG MAKER MZ VisageRender.js AND HELD TO IT (mqs_oracle: the shade, separate, noise and relief
/// numbers). The canvas drawing half of that file (wall, peg, cord, placard) lives in mqs_scene.gml.

// ================================================================================================ the palette

/// @function mqs_palette()
/// @description The palette by role, each [r, g, b]. ⛔ Nothing else in Masque types a colour.
function mqs_palette() {
    static _p = {
        wall_dark: [35, 26, 20], wall_lit: [58, 42, 30],
        oak: [122, 82, 48], oak_lit: [176, 124, 74], oak_shadow: [74, 49, 32],
        bone: [230, 217, 190], bone_lit: [244, 235, 214], bone_shadow: [185, 169, 138],
        lacquer: [21, 16, 13], lacquer_lit: [60, 51, 44], lacquer_shadow: [9, 7, 7],
        brass: [201, 162, 74], brass_deep: [126, 95, 34], brass_hi: [227, 194, 113],
        cord: [140, 43, 36], gold_wire: [217, 184, 92], verdigris: [94, 143, 122], iron_rivet: [110, 110, 114],
        shell_inlay: [232, 216, 208], lacquer_thread: [42, 26, 20], ink_dark: [18, 12, 8]
    };
    return _p;
}

/// @function mqs__materials()
/// @description The three base materials: {mid, lit, shadow, gloss, grain}. Oak for things that grew, bone for things
/// that died or never lived, lacquer for things that were made. Internal.
function mqs__materials() {
    static _m = undefined;
    if (is_undefined(_m)) {
        var _p = mqs_palette();
        _m = {
            oak: { mid: _p.oak, lit: _p.oak_lit, shadow: _p.oak_shadow, gloss: 0.10, grain: 0.85 },
            bone: { mid: _p.bone, lit: _p.bone_lit, shadow: _p.bone_shadow, gloss: 0.16, grain: 0.30 },
            lacquer: { mid: _p.lacquer, lit: _p.lacquer_lit, shadow: _p.lacquer_shadow, gloss: 0.55, grain: 0.12 }
        };
    }
    return _m;
}

/// @function mqs__structure_material(structure)
/// @description Which material each of the ten structures is cut from. Internal, pure.
function mqs__structure_material(_s) {
    switch (_s) {
        case "undead": case "spirit": case "aquatic": return "bone";
        case "construct": case "fiend": case "insect": return "lacquer";
        default: return "oak";
    }
}

/// @function mqs__light()
/// @description The one light, normalised: upper left and in front. Internal.
function mqs__light() {
    static _l = undefined;
    if (is_undefined(_l)) { var _m = sqrt(0.52 * 0.52 + 0.68 * 0.68 + 0.52 * 0.52); _l = [-0.52 / _m, -0.68 / _m, 0.52 / _m]; }
    return _l;
}

// ================================================================================================ colour

/// @function mqs_colour(rgb)
/// @description A GameMaker colour from an [r, g, b] array (channels rounded and clamped). Pure.
function mqs_colour(_c) {
    if (!is_array(_c) || array_length(_c) < 3) return c_black;
    return make_colour_rgb(clamp(floor(mqs__num(_c[0]) + 0.5), 0, 255), clamp(floor(mqs__num(_c[1]) + 0.5), 0, 255), clamp(floor(mqs__num(_c[2]) + 0.5), 0, 255));
}

/// @function mqs_rgb(hex)
/// @description [r, g, b] from "#rrggbb" or "#rgb" (the # optional), or undefined for anything unreadable. ⛔ Never NaN
/// channels: an unreadable colour means UNPAINTED, a state the product already draws well. Pure.
function mqs_rgb(_hex) {
    if (!is_string(_hex)) return undefined;
    var _h = string_replace(_hex, "#", "");
    var _dig = "0123456789abcdef", _l = string_lower(_h), _n = string_length(_l);
    if (_n != 3 && _n != 6) return undefined;
    var _v = [];
    for (var _i = 1; _i <= _n; _i++) { var _d = string_pos(string_char_at(_l, _i), _dig); if (_d == 0) return undefined; array_push(_v, _d - 1); }
    if (_n == 3) return [_v[0] * 17, _v[1] * 17, _v[2] * 17];
    return [_v[0] * 16 + _v[1], _v[2] * 16 + _v[3], _v[4] * 16 + _v[5]];
}

/// @function mqs__mix(a, b, t)
/// @description Mix two [r, g, b] colours, t clamped to 0..1. Internal, pure.
function mqs__mix(_a, _b, _t) {
    var _u = (_t < 0) ? 0 : ((_t > 1) ? 1 : _t);
    return [_a[0] + (_b[0] - _a[0]) * _u, _a[1] + (_b[1] - _a[1]) * _u, _a[2] + (_b[2] - _a[2]) * _u];
}

/// @function mqs__luminance(rgb)
/// @description Relative luminance, GAMMA-EXPANDED (a channel average is not a luminance). Internal, pure.
function mqs__luminance(_c) {
    var _o = 0, _w = [0.2126, 0.7152, 0.0722];
    for (var _i = 0; _i < 3; _i++) {
        var _s = _c[_i] / 255;
        _o += _w[_i] * ((_s <= 0.03928) ? _s / 12.92 : power((_s + 0.055) / 1.055, 2.4));
    }
    return _o;
}

/// @function mqs__contrast(a, b)
/// @description The WCAG contrast ratio of two colours. Internal, pure.
function mqs__contrast(_a, _b) {
    var _la = mqs__luminance(_a), _lb = mqs__luminance(_b);
    return (max(_la, _lb) + 0.05) / (min(_la, _lb) + 0.05);
}

/// @function mqs_ink_for(surface_rgb, [want])
/// @description The ink to write on a surface: try BOTH directions (bone and near-black) and keep the first that clears
/// the bar (default 4.5), else the better of the two. {rgb, ratio, cleared}. Pure.
function mqs_ink_for(_bg, _want = 4.5) {
    if (!is_array(_bg) || array_length(_bg) < 3) _bg = [128, 128, 128];
    else _bg = [clamp(mqs__num(_bg[0]), 0, 255), clamp(mqs__num(_bg[1]), 0, 255), clamp(mqs__num(_bg[2]), 0, 255)];
    _want = mqs__num(_want);
    if (_want <= 0) _want = 4.5;
    var _p = mqs_palette();
    var _cl = mqs__contrast(_bg, _p.bone), _cd = mqs__contrast(_bg, _p.ink_dark);
    if (_cd >= _want) return { rgb: _p.ink_dark, ratio: _cd, cleared: true };
    if (_cl >= _want) return { rgb: _p.bone, ratio: _cl, cleared: true };
    return (_cl > _cd) ? { rgb: _p.bone, ratio: _cl, cleared: false } : { rgb: _p.ink_dark, ratio: _cd, cleared: false };
}

/// @function mqs__channel_distance(a, b)
/// @description Mean per-channel distance between two colours, 0..255. Internal, pure.
function mqs__channel_distance(_a, _b) { return (abs(_a[0] - _b[0]) + abs(_a[1] - _b[1]) + abs(_a[2] - _b[2])) / 3; }

/// @function mqs__separate(pigment, material, want)
/// @description Push a pigment away from the material it is painted on until the two are visibly different (a mean
/// per-channel distance of `want`), keeping as much of its hue as the separation allows: {colour, got, moved, cleared}.
/// ⛔ By SCALING the channels, not blending toward white or black (a blend toward white is a blend toward NO hue: earth
/// on oak came out as plaster). Both directions are tried, the solve stops at the FIRST step that clears (overshoot is a
/// failure too), and a blend toward the extreme is only the last resort. Internal, pure.
function mqs__separate(_pig, _mat, _want) {
    var _have = mqs__channel_distance(_pig, _mat);
    if (_have >= _want) return { colour: _pig, got: _have, moved: 0, cleared: true };
    var _best = { colour: _pig, got: _have, moved: 0, cleared: false };
    var _lum = mqs__luminance(_mat);
    var _up = [], _down = [];
    for (var _i = 1; _i <= 24; _i++) { array_push(_up, 1 + _i * 0.085); array_push(_down, 1 - _i * 0.035); }
    var _orders = (_lum > 0.18) ? [_down, _up] : [_up, _down];
    for (var _d = 0; _d < 2; _d++) {
        var _o = _orders[_d];
        for (var _s = 0; _s < array_length(_o); _s++) {
            var _k = _o[_s];
            var _c = [clamp(_pig[0] * _k, 0, 255), clamp(_pig[1] * _k, 0, 255), clamp(_pig[2] * _k, 0, 255)];
            var _got = mqs__channel_distance(_c, _mat);
            if (_got > _best.got) _best = { colour: _c, got: _got, moved: _k, cleared: (_got >= _want) };
            if (_got >= _want) return { colour: _c, got: _got, moved: _k, cleared: true };
        }
    }
    var _ext = (_lum > 0.18) ? [8, 6, 5] : [255, 252, 244];
    for (var _t = 1; _t <= 20; _t++) {
        var _c2 = mqs__mix(_pig, _ext, _t / 20);
        var _g2 = mqs__channel_distance(_c2, _mat);
        if (_g2 > _best.got) _best = { colour: _c2, got: _g2, moved: _t / 20, cleared: (_g2 >= _want) };
        if (_g2 >= _want) return { colour: _c2, got: _g2, moved: _t / 20, cleared: true };
    }
    return _best;
}

// ================================================================================================ seeded grain
// ⛔ Never random(): a generator is made per mask from that mask's own seed and never shared, or a mask would depend on
// how many masks were drawn before it.

/// @function mqs__perm(seed, n)
/// @description n draws of mqs_rng(seed) mapped to -1..1, the generator written out inline (a noise table is thousands of
/// draws, and a function call per draw was a fixed cost of every mask). The same stream as mqs_rnd, draw for draw (the
/// suite holds the noise values to the MZ original). Internal, pure.
function mqs__perm(_seed, _n) {
    var _a = mqs__fin(_seed) ? (floor(_seed) & $FFFFFFFF) : mqs_hash(_seed);
    if (_a == 0) _a = 1;
    var _p = array_create(_n, 0);
    for (var _i = 0; _i < _n; _i++) {
        _a = (_a + $6D2B79F5) & $FFFFFFFF;
        var _x = _a ^ (_a >> 15), _y = 1 | _a;
        var _t = (((_x & $FFFF) * _y) + (((((_x >> 16) & $FFFF) * _y) & $FFFF) << 16)) & $FFFFFFFF;
        var _x2 = _t ^ (_t >> 7), _y2 = 61 | _t;
        var _m = (((_x2 & $FFFF) * _y2) + (((((_x2 >> 16) & $FFFF) * _y2) & $FFFF) << 16)) & $FFFFFFFF;
        _t = ((_t + _m) & $FFFFFFFF) ^ _t;
        _p[_i] = (((_t ^ (_t >> 14)) & $FFFFFFFF) / 4294967296) * 2 - 1;
    }
    return _p;
}

/// @function mqs__noise1(seed, octaves)
/// @description Smooth 1D value noise (grain along the cut of the wood): a state for mqs__n1. Internal.
function mqs__noise1(_seed, _oct) {
    return { perm: mqs__perm(_seed, 256), oct: (_oct > 0) ? _oct : 3 };
}

/// @function mqs__n1(noise, x)
/// @description A 1D noise value in -1..1. Internal, pure.
function mqs__n1(_n, _x) {
    var _p = _n.perm, _sum = 0, _amp = 1, _norm = 0, _f = 1;
    for (var _o = 0; _o < _n.oct; _o++) {
        var _xf = _x * _f, _fl = floor(_xf);
        var _i0 = _fl & 255, _i1 = (_i0 + 1) & 255, _t = _xf - _fl;
        var _s = _t * _t * (3 - 2 * _t);
        _sum += (_p[_i0] + (_p[_i1] - _p[_i0]) * _s) * _amp;
        _norm += _amp; _amp *= 0.5; _f *= 2.1;
    }
    return _sum / ((_norm != 0) ? _norm : 1);
}

/// @function mqs__noise2(seed)
/// @description Smooth 2D value noise (chipping, the wall): a state for mqs__n2. Internal.
function mqs__noise2(_seed) {
    return { perm: mqs__perm(_seed, 4096) };
}

/// @function mqs__n2(noise, x, y)
/// @description A 2D noise value in -1..1. Internal, pure.
function mqs__n2(_n, _x, _y) {
    var _p = _n.perm;
    var _x0 = floor(_x), _y0 = floor(_y);
    var _tx = _x - _x0, _ty = _y - _y0;
    var _sx = _tx * _tx * (3 - 2 * _tx), _sy = _ty * _ty * (3 - 2 * _ty);
    var _a = _p[((((_x0 & 63) << 6) | (_y0 & 63)) & 4095)];
    var _b = _p[(((((_x0 + 1) & 63) << 6) | (_y0 & 63)) & 4095)];
    var _c = _p[((((_x0 & 63) << 6) | ((_y0 + 1) & 63)) & 4095)];
    var _d = _p[(((((_x0 + 1) & 63) << 6) | ((_y0 + 1) & 63)) & 4095)];
    var _ab = _a + (_b - _a) * _sx;
    return _ab + ((_c + (_d - _c) * _sx) - _ab) * _sy;
}

// ================================================================================================ the relief
// A mass is [x, y, rx, ry, amp, rot, k] in face space (x across the face, y 0 top .. 1 chin); k is the falloff (1.6 for a
// ridge, sharper across than along; 1.1 for a bump or a hollow; a hollow has a negative amp).

/// @function mqs__mass(x, y, rx, ry, amp, [kind], [rot])
/// @description One relief mass. Internal, pure.
function mqs__mass(_x, _y, _rx, _ry, _amp, _kind = "bump", _rot = 0) { return [_x, _y, _rx, _ry, _amp, _rot, (_kind == "ridge") ? 1.6 : 1.1]; }

/// @function mqs__field_at(masses, x, y)
/// @description The relief height at a point: the sum of every mass (nothing beyond three sigma). Internal, pure.
function mqs__field_at(_m, _x, _y) {
    var _h = 0, _n = array_length(_m);
    for (var _i = 0; _i < _n; _i++) {
        var _q = _m[_i];
        var _dx = _x - _q[0], _dy = _y - _q[1];
        if (_q[5] != 0) {
            var _c = cos(_q[5]), _s = sin(_q[5]);
            var _rx = _dx * _c - _dy * _s, _ry = _dx * _s + _dy * _c;
            _dx = _rx; _dy = _ry;
        }
        var _u = _dx / ((_q[2] != 0) ? _q[2] : 0.2), _v = _dy / ((_q[3] != 0) ? _q[3] : 0.2);
        var _d2 = _u * _u + _v * _v;
        if (_d2 > 9) continue;
        _h += _q[4] * exp(-_d2 * _q[6]);
    }
    return _h;
}

/// @function mqs__field_grad(masses, x, y)
/// @description The relief's slope at a point, by central difference (so a mass kind added later can never be forgotten
/// in the normal): [dx, dy]. Internal, pure.
function mqs__field_grad(_m, _x, _y) {
    var _e = 0.004;
    return [(mqs__field_at(_m, _x + _e, _y) - mqs__field_at(_m, _x - _e, _y)) / (2 * _e),
        (mqs__field_at(_m, _x, _y + _e) - mqs__field_at(_m, _x, _y - _e)) / (2 * _e)];
}

/// @function mqs__shade(gx, gy, relief)
/// @description Light one point of a relief from its slope: {diffuse, spec, slope}. Internal, pure.
function mqs__shade(_gx, _gy, _relief) {
    var _k = (_relief != 0) ? _relief : 0.35;
    var _L = mqs__light();
    var _nx = -_gx * _k, _ny = -_gy * _k;
    var _m = sqrt(_nx * _nx + _ny * _ny + 1);
    _nx /= _m; _ny /= _m; var _nz = 1 / _m;
    var _d = _nx * _L[0] + _ny * _L[1] + _nz * _L[2];
    var _hz = _L[2] + 1, _hm = sqrt(_L[0] * _L[0] + _L[1] * _L[1] + _hz * _hz);
    var _s = _nx * (_L[0] / _hm) + _ny * (_L[1] / _hm) + _nz * (_hz / _hm);
    return { diffuse: max(0, _d), spec: power(max(0, _s), 22), slope: sqrt(_gx * _gx + _gy * _gy) };
}
