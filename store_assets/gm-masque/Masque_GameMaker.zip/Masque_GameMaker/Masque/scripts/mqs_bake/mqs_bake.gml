/// mqs_bake.gml - the carving as a JOB: a mask is struck into a pixel buffer row by row under a time budget you choose,
/// then made into a sprite (plus a soft shadow sprite to hang it by). A rack mask takes tens of milliseconds and a
/// full-screen reveal a few hundred on the VM, so neither is ever carved inside one frame by accident: bake a mask when
/// its creature is first met, and let the reveal carve itself band by band on screen.
///
/// Masque - Every Creature Carves Its Own Mask, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// PUBLIC
///   mqs_carve_begin(profile, height) -> job        mqs_carve_step(job, budget_ms) -> true when done (job.mask)
///   mqs_carve(profile, height) -> mask             mqs_carve_progress(job) -> 0..1     mqs_carve_cancel(job)
///   mqs_carve_preview(job) -> a surface showing the rows carved so far (for a reveal that carves on screen), or -1
///   mqs_mask_draw(mask, x, y, [scale], [alpha])    mqs_mask_draw_shadow(mask, x, y, [scale], [colour], [alpha], [spread])
///   mqs_mask_free(mask)
/// A MASK is { sprite, shadow, w, h, tilt, knot_x, knot_y, box_w, box_h, box_knot_x, box_knot_y, height, key, ms }:
///   the sprite is the mask UNROTATED with its origin at its centre; `tilt` (radians) is how it hangs; box_* is the
///   rotated mask's bounding box and where its cord ties inside that box (what a layout needs); `ms` is how long it took.
/// ⛔ The sprites belong to you once the job is done: free them with mqs_mask_free (mqs_masque_free frees a whole rack).

// ================================================================================================ the job

/// @function mqs_carve_begin(profile, height)
/// @description Start carving a profile at a height in pixels (crown included; 8..1024 - the coverage grid is four
/// entries per pixel - and anything unreadable means 420).
/// Returns a job for mqs_carve_step. Allocates the pixel buffer; nothing is drawn yet.
function mqs_carve_begin(_p, _height) {
    if (!mqs__is_profile(_p)) return undefined;
    var _eps = mqs__eps0();
    var _px0 = mqs__parse_num(_height);
    if (is_undefined(_px0) || _px0 <= 0) _px0 = 420;
    var _size = clamp(_px0, 8, 1024);
    var _g = mqs__geometry(_p);
    var _b = _g.bounds;
    var _uT = _b.max_y - _b.min_y, _uW = _b.max_x - _b.min_x;
    var _scale = _size / _uT, _scaleX = _scale * MQS_FACE_ASPECT;
    var _W = max(8, ceil(_uW * _scaleX)), _H = max(8, ceil(_size));
    var _mat = _g.material;
    var _sep = mqs__paint_colour(_p, _mat.mid);
    var _step = (_H < 200) ? 2 : 3;
    var _gw = ceil(_W / _step) + 3, _gh = ceil(_H / _step) + 3;
    var _job = {
        profile: _p, geo: _g, size: _size, w: _W, h: _H, scale: _scale, scale_x: _scaleX,
        min_x: _b.min_x, min_y: _b.min_y, px: _uW / _W, py: _uT / _H,
        buf: buffer_create(_W * _H * 4, buffer_fixed, 1),
        pig: is_undefined(_sep) ? undefined : _sep.colour,
        mid: _mat.mid, lit: _mat.lit, sha: _mat.shadow, gloss: _mat.gloss, grain_k: _mat.grain, relief: _g.relief,
        step: _step, gw: _gw, gh: _gh, hg: array_create(_gw * _gh, 0), gxn: array_create(_gw * _gh, 0), gyn: array_create(_gw * _gh, 0),
        sw: _W * 2, sh: _H * 2, ins: array_create(_W * 2 * _H * 2, 0),
        phase: 0, row: 0, us: 0, done: false, mask: undefined, knot_x: 0, knot_y: 0, preview: -1, cancelled: false,
        phase_us: array_create(8, 0), worst_unit_us: 0, ops: [], op_i: 0, op_y: 0
    };
    // transparent pixels carry the material's own colour, so a filtered edge fades into the mask and never into black
    var _m = _mat.mid;
    buffer_fill(_job.buf, 0, buffer_u32, (floor(_m[0]) | (floor(_m[1]) << 8) | (floor(_m[2]) << 16)), _W * _H * 4);
    _job.voids = mqs__void_boxes(_g);
    math_set_epsilon(_eps);
    return _job;
}

/// @function mqs__is_profile(p)
/// @description Is this a profile mqs_read made (every field the carver reads, of the right kind)? Internal, pure.
function mqs__is_profile(_p) {
    if (!is_struct(_p)) return false;
    var _s = ["key", "structure", "crown", "house", "break_kind"], _n = ["seed", "age_index"];
    for (var _i = 0; _i < array_length(_s); _i++) if (!variable_struct_exists(_p, _s[_i]) || !is_string(_p[$ _s[_i]])) return false;
    for (var _j = 0; _j < array_length(_n); _j++) if (!variable_struct_exists(_p, _n[_j]) || !mqs__fin(_p[$ _n[_j]])) return false;
    return variable_struct_exists(_p, "pigment") && is_struct(_p.pigment);
}

/// @function mqs__void_boxes(geo)
/// @description Conservative boxes around the two eye-holes and the mouth (face units): [x0, y0, x1, y1] x 3. Outside
/// them the void test is 0 by construction, so the per-pixel pass never runs it there. Internal, pure.
function mqs__void_boxes(_g) {
    var _e = _g.eye, _m = _g.mouth;
    var _er = 1.1 * (_e.w / 2 + _e.h / 2);
    var _xl = -_g.eye_x, _xr = _g.eye_x + _g.eye_skew;
    return [[_xl - _er, _g.eye_y - _er, _xl + _er, _g.eye_y + _er], [_xr - _er, _g.eye_y - _er, _xr + _er, _g.eye_y + _er],
        [_g.mouth_skew - 1.12 * _m.w / 2, _g.mouth_y - 1.12 * _m.h / 2, _g.mouth_skew + 1.12 * _m.w / 2, _g.mouth_y + 1.6 * _m.h / 2]];
}

/// @function mqs__in_void_boxed(job, x, y)
/// @description The void test, skipped (0) outside the conservative boxes. Internal, pure.
function mqs__in_void_boxed(_job, _x, _y) {
    var _vb = _job.voids;
    for (var _i = 0; _i < 3; _i++) {
        var _b = _vb[_i];
        if (_x >= _b[0] && _x <= _b[2] && _y >= _b[1] && _y <= _b[3]) return mqs__in_void(_job.geo, _x, _y);
    }
    return 0;
}

/// @function mqs_carve_progress(job)
/// @description How far a job has got, 0..1.
function mqs_carve_progress(_job) {
    if (!is_struct(_job)) return 0;
    if (_job.done) return 1;
    var _w = [0.10, 0.02, 0.16, 0.60, 0.04, 0.04, 0.03, 0.01];
    var _tot = [_job.gh, 1, _job.sh, _job.h, max(1, _job.row + 1), max(1, ceil(_job.h / 2)), 6, variable_struct_exists(_job, "sh_sh") ? _job.sh_sh + 1 : 1];
    var _p = 0;
    for (var _i = 0; _i < _job.phase && _i < 8; _i++) _p += _w[_i];
    if (_job.phase < 8) _p += _w[_job.phase] * clamp(_job.row / max(1, _tot[_job.phase]), 0, 1);
    return clamp(_p, 0, 1);
}

/// @function mqs_carve_step(job, budget_ms)
/// @description Carve for up to budget_ms (default 4) and return true once the mask is finished (job.mask). Rows are
/// the unit of work, so a step can run over its budget by one row.
function mqs_carve_step(_job, _budget = 4) {
    if (!is_struct(_job) || _job.cancelled) return false;
    if (_job.done) return true;
    var _eps = mqs__eps0();
    var _b = mqs__parse_num(_budget);
    if (is_undefined(_b) || _b <= 0) _b = 4;
    var _t0 = get_timer(), _end = _t0 + _b * 1000;
    while (!_job.done && get_timer() < _end) {
        var _ph = _job.phase, _s0 = get_timer();
        switch (_ph) {
            case 0: mqs__bake_relief_row(_job); break;
            case 1: mqs__bake_gradients(_job); break;
            case 2: mqs__bake_inside_row(_job); break;
            case 3: mqs__bake_pixel_row(_job); break;
            case 4: mqs__bake_marks_row(_job); break;
            case 5: mqs__bake_finish(_job); break;
            case 6: mqs__bake_blur(_job); break;
            case 7: mqs__bake_done(_job); break;
        }
        var _dt = get_timer() - _s0;
        _job.phase_us[_ph] += _dt;
        _job.worst_unit_us = max(_job.worst_unit_us, _dt);
    }
    _job.us += get_timer() - _t0;
    if (_job.done) { _job.mask.ms = _job.us / 1000; _job.mask.phase_ms = []; for (var _p = 0; _p < 8; _p++) array_push(_job.mask.phase_ms, _job.phase_us[_p] / 1000); _job.mask.worst_unit_ms = _job.worst_unit_us / 1000; }
    math_set_epsilon(_eps);
    return _job.done;
}

/// @function mqs_carve(profile, height)
/// @description Carve a mask NOW, in one call, and return it (see the header for its fields). ⛔ A reveal-sized mask is
/// a few hundred milliseconds on the VM: use the job (mqs_carve_begin / mqs_carve_step) inside a running game.
function mqs_carve(_p, _height) {
    var _job = mqs_carve_begin(_p, _height);
    if (!is_struct(_job)) return undefined;
    while (!mqs_carve_step(_job, 1000)) { if (_job.cancelled) break; }
    return _job.mask;
}

/// @function mqs_carve_cancel(job)
/// @description Stop a job and free what it holds (an unfinished job's buffer and preview). A finished job's mask is not
/// freed: it is yours (mqs_mask_free).
function mqs_carve_cancel(_job) {
    if (!is_struct(_job)) return;
    _job.cancelled = true;
    if (!is_undefined(_job.buf) && buffer_exists(_job.buf)) buffer_delete(_job.buf);
    _job.buf = undefined;
    if (!_job.done) {
        if (variable_struct_exists(_job, "sh_b") && buffer_exists(_job.sh_b)) buffer_delete(_job.sh_b);
        if (variable_struct_exists(_job, "spr") && sprite_exists(_job.spr)) sprite_delete(_job.spr);
    }
    if (surface_exists(_job.preview)) surface_free(_job.preview);
    _job.preview = -1;
}

/// @function mqs_carve_preview(job)
/// @description A surface (job.w x job.h) holding the rows carved so far, refreshed from the buffer on every call, or -1
/// before the pixel pass starts. For a reveal that shows the carve appearing. Free it with mqs_carve_cancel or when done.
function mqs_carve_preview(_job) {
    if (!is_struct(_job) || _job.cancelled || is_undefined(_job.buf) || _job.phase < 3) return -1;
    if (!surface_exists(_job.preview)) _job.preview = surface_create(_job.w, _job.h);
    buffer_set_surface(_job.buf, _job.preview, 0);
    return _job.preview;
}

// ================================================================================================ phase 0-1: the relief grid

/// @function mqs__bake_relief_row(job)
/// @description One row of relief heights at the grid nodes. Only the masses that can reach the row are summed (beyond
/// three sigma a mass adds nothing: the same cut the field itself makes), which is most of the relief's cost. Internal.
function mqs__bake_relief_row(_job) {
    var _j = _job.row, _gw = _job.gw, _st = _job.step, _m = _job.geo.masses, _hg = _job.hg, _px = _job.px, _mx = _job.min_x;
    var _fy = _job.min_y + ((_j - 1) * _st + 0.5) * _job.py;
    var _act = [], _n = array_length(_m);
    for (var _k = 0; _k < _n; _k++) {
        var _q = _m[_k], _rx = (_q[2] != 0) ? _q[2] : 0.2, _ry = (_q[3] != 0) ? _q[3] : 0.2;
        var _reach = 3 * ((_q[5] != 0) ? max(_rx, _ry) : _ry);
        if (abs(_fy - _q[1]) <= _reach) array_push(_act, _q);
    }
    var _na = array_length(_act);
    for (var _i = 0; _i < _gw; _i++) {
        var _fx = _mx + ((_i - 1) * _st + 0.5) * _px, _h = 0;
        for (var _a = 0; _a < _na; _a++) {
            var _q2 = _act[_a];
            var _dx = _fx - _q2[0], _dy = _fy - _q2[1];
            if (_q2[5] != 0) { var _c = cos(_q2[5]), _s = sin(_q2[5]); var _rx2 = _dx * _c - _dy * _s, _ry2 = _dx * _s + _dy * _c; _dx = _rx2; _dy = _ry2; }
            var _u = _dx / ((_q2[2] != 0) ? _q2[2] : 0.2), _v = _dy / ((_q2[3] != 0) ? _q2[3] : 0.2);
            var _d2 = _u * _u + _v * _v;
            if (_d2 > 9) continue;
            _h += _q2[4] * exp(-_d2 * _q2[6]);
        }
        _hg[_j * _gw + _i] = _h;
    }
    _job.row++;
    if (_job.row >= _job.gh) { _job.phase = 1; _job.row = 0; }
}

/// @function mqs__bake_gradients(job)
/// @description The slope at every grid node by central differences, in face units (the MZ original takes the slope of
/// the same field by central difference; here it is taken on the grid and interpolated per pixel). Internal.
function mqs__bake_gradients(_job) {
    var _gw = _job.gw, _gh = _job.gh, _hg = _job.hg, _gx = _job.gxn, _gy = _job.gyn;
    var _kx = 1 / (2 * _job.step * _job.px), _ky = 1 / (2 * _job.step * _job.py);
    for (var _j = 1; _j < _gh - 1; _j++) for (var _i = 1; _i < _gw - 1; _i++) {
        var _o = _j * _gw + _i;
        _gx[_o] = (_hg[_o + 1] - _hg[_o - 1]) * _kx;
        _gy[_o] = (_hg[_o + _gw] - _hg[_o - _gw]) * _ky;
    }
    _job.phase = 2; _job.row = 0;
}

// ================================================================================================ phase 2: what is object

/// @function mqs__bake_inside_row(job)
/// @description One row of the 2x2-per-pixel object grid: 1 object, 2 object but a hole (an eye or the mouth), 0 wall.
/// The silhouette is an interval per row; each limb is its even-odd crossings at that row, exactly the MZ inPoly rule;
/// a snapped limb stops at its break. Internal.
function mqs__bake_inside_row(_job) {
    var _g = _job.geo, _j = _job.row, _SW = _job.sw, _ins = _job.ins;
    var _hpx = _job.px / 2, _hpy = _job.py / 2;
    var _sy = _job.min_y + (_j + 0.5) * _hpy;
    var _base = _j * _SW;
    if (_sy >= 0 && _sy <= 1) {
        var _hw = mqs__half_width(_g.sil, _sy), _c = _g.lean * _sy;
        var _i0 = max(0, ceil((_c - _hw - _job.min_x) / _hpx - 0.5)), _i1 = min(_SW - 1, floor((_c + _hw - _job.min_x) / _hpx - 0.5));
        for (var _i = _i0; _i <= _i1; _i++) _ins[_base + _i] = 1;
    }
    var _limbs = _g.crown_limbs, _boxes = _g.limb_box, _xs = [];
    for (var _l = 0; _l < array_length(_limbs); _l++) {
        var _bb = _boxes[_l];
        if (_sy < _bb[1] || _sy > _bb[3]) continue;
        if (_g.broken_limb == _l && _sy < _g.broken_y) continue;
        var _pts = _limbs[_l], _n = array_length(_pts), _k = _n - 1;
        array_resize(_xs, 0);
        for (var _q = 0; _q < _n; _q++) {
            var _xi = _pts[_q][0], _yi = _pts[_q][1], _xj = _pts[_k][0], _yj = _pts[_k][1];
            if ((_yi > _sy) != (_yj > _sy)) {
                var _dy = _yj - _yi;
                array_push(_xs, (_xj - _xi) * (_sy - _yi) / ((_dy != 0) ? _dy : 0.000000001) + _xi);
            }
            _k = _q;
        }
        var _nx = array_length(_xs);
        if (_nx < 2) continue;
        array_sort(_xs, true);
        for (var _p = 0; _p + 1 < _nx; _p += 2) {
            var _a0 = max(0, ceil((_xs[_p] - _job.min_x) / _hpx - 0.5));
            var _a1 = min(_SW - 1, ceil((_xs[_p + 1] - _job.min_x) / _hpx - 0.5) - 1);
            for (var _ii = _a0; _ii <= _a1; _ii++) _ins[_base + _ii] = 1;
        }
    }
    // the holes: only inside the three conservative void boxes
    var _vb = _job.voids;
    for (var _v = 0; _v < 3; _v++) {
        var _b = _vb[_v];
        if (_sy < _b[1] || _sy > _b[3]) continue;
        var _v0 = max(0, floor((_b[0] - _job.min_x) / _hpx)), _v1 = min(_SW - 1, ceil((_b[2] - _job.min_x) / _hpx));
        for (var _iv = _v0; _iv <= _v1; _iv++) {
            if (_ins[_base + _iv] != 1) continue;
            if (mqs__in_void(_g, _job.min_x + (_iv + 0.5) * _hpx, _sy) >= 1) _ins[_base + _iv] = 2;
        }
    }
    _job.row++;
    if (_job.row >= _job.sh) { _job.phase = 3; _job.row = 0; }
}

// ================================================================================================ phase 3: the pixel pass

/// @function mqs__bake_pixel_row(job)
/// @description Light, paint, grain, rim and wear one row of the mask into the buffer - the MZ carve() loop body, line
/// for line, with the relief read from the grid and "is it object" from the 2x2 grid. The grain noise, the paint window
/// and the interpolation are written out inline (a function call per pixel is most of a VM's cost), and the wear and void
/// tests are only called where they can answer something other than 0. Internal.
function mqs__bake_pixel_row(_job) {
    var _g = _job.geo, _y = _job.row, _W = _job.w, _SW = _job.sw, _SH = _job.sh, _ins = _job.ins;
    var _px = _job.px, _py = _job.py, _FA = MQS_FACE_ASPECT;
    var _fy = _job.min_y + (_y + 0.5) * _py;
    var _rowFace = (_fy >= 0 && _fy <= 1), _hwRow = mqs__half_width(_g.sil, _fy), _cRow = _g.lean * _fy;
    var _st = _job.step, _gw = _job.gw, _hg = _job.hg, _gxn = _job.gxn, _gyn = _job.gyn;
    var _cy = _y / _st + 1, _j0 = min(floor(_cy), _job.gh - 3), _vy = _cy - _j0;
    var _r0 = (2 * _y) * _SW, _r1 = (2 * _y + 1) * _SW, _jc = 2 * _y + 1;
    var _mid = _job.mid, _lit = _job.lit, _sha = _job.sha, _pig = _job.pig, _hasPig = !is_undefined(_pig);
    var _age = _job.profile.age_index, _gloss = _job.gloss, _grk = _job.grain_k, _relief = _job.relief;
    var _L = mqs__light(), _lx = _L[0], _ly = _L[1], _lz = _L[2];
    var _hz = _lz + 1, _hm = sqrt(_lx * _lx + _ly * _ly + _hz * _hz), _hx = _lx / _hm, _hy = _ly / _hm, _hzz = _hz / _hm;
    var _l2m = sqrt(_lx * _lx + _ly * _ly), _l2x = _lx / _l2m, _l2y = _ly / _l2m;
    var _dhx = _l2x * MQS_LIP_TEXELS * _px * _FA, _dhy = _l2y * MQS_LIP_TEXELS * _py;
    var _perm = _g.grain.perm, _buf = _job.buf;
    var _edgeY = _rowFace ? min(_fy, 1 - _fy) * 1.4 : 0;
    var _pr = 0, _pg = 0, _pb = 0;
    if (_hasPig) { _pr = _pig[0]; _pg = _pig[1]; _pb = _pig[2]; }
    // the paint's constants for this mask (mqs__paint_at, written out)
    var _wearP = 0.10 + _age * 0.175, _duty = 0.56 - _wearP * 0.14, _lo = -0.05 + _age * 0.038, _hi = 0.78 - _age * 0.040;
    var _edgeK = 0.030 + _wearP * 0.048, _inkK = 1 / MQS_PAINT_EDGE;
    // which of the cut breaks and wear terms can touch this row at all
    var _brk = _g.break_drawn;
    var _rowCut = (_brk == "chippedJaw" && _fy > 0.70) || (_brk == "faceCrack" && _fy > 0.06) || (_brk == "boundCrack" && _fy > MQS_BOUND_TOP && _fy < MQS_BOUND_BOTTOM);
    var _rowCrack = (_age > 0) && (_fy < 0.18 + _age * 0.19);
    var _chipBand = (_age > 0) ? 0.032 * _age : -1;
    var _vb = _job.voids, _rowVoid = false;
    for (var _vv = 0; _vv < 3; _vv++) if (_fy >= _vb[_vv][1] && _fy <= _vb[_vv][3]) _rowVoid = true;
    var _f1 = 2.1, _f2 = 2.1 * 2.1;
    for (var _x = 0; _x < _W; _x++) {
        var _i2 = 2 * _x;
        var _cov = ((_ins[_r0 + _i2] == 1) + (_ins[_r0 + _i2 + 1] == 1) + (_ins[_r1 + _i2] == 1) + (_ins[_r1 + _i2 + 1] == 1)) * 0.25;
        if (_cov <= 0) continue;
        var _fx = _job.min_x + (_x + 0.5) * _px;
        var _v = _rowVoid ? mqs__in_void_boxed(_job, _fx, _fy) : 0;
        // the relief: height and slope from the grid, the slope re-scaled to REAL space (the face is squeezed across)
        var _cx = _x / _st + 1, _i0 = min(floor(_cx), _gw - 3), _vx = _cx - _i0, _a = _j0 * _gw + _i0, _ab = _a + _gw;
        var _t0 = _hg[_a] + (_hg[_a + 1] - _hg[_a]) * _vx, _t1 = _hg[_ab] + (_hg[_ab + 1] - _hg[_ab]) * _vx;
        var _hh = _t0 + (_t1 - _t0) * _vy;
        _t0 = _gxn[_a] + (_gxn[_a + 1] - _gxn[_a]) * _vx; _t1 = _gxn[_ab] + (_gxn[_ab + 1] - _gxn[_ab]) * _vx;
        var _gX = (_t0 + (_t1 - _t0) * _vy) / _FA;
        _t0 = _gyn[_a] + (_gyn[_a + 1] - _gyn[_a]) * _vx; _t1 = _gyn[_ab] + (_gyn[_ab + 1] - _gyn[_ab]) * _vx;
        var _gY = _t0 + (_t1 - _t0) * _vy;
        var _rgX = _gX, _rgY = _gY;
        var _ic = _i2 + 1;
        var _dEdge = _hwRow - abs(_fx - _cRow);
        // a superstructure is lit like the face it grows out of: outside the silhouette the normal comes from the limb's
        // own edge, which rounds every limb into a tube under the one light
        if (!(_rowFace && _dEdge >= 0)) {
            var _ep = ((_ic + 5 < _SW) && (_ins[_jc * _SW + _ic + 5] >= 1)) - ((_ic - 5 >= 0) && (_ins[_jc * _SW + _ic - 5] >= 1));
            var _eq = ((_jc + 5 < _SH) && (_ins[(_jc + 5) * _SW + _ic] >= 1)) - ((_jc - 5 >= 0) && (_ins[(_jc - 5) * _SW + _ic] >= 1));
            _gX -= _ep * 1.9;
            _gY -= _eq * 1.9;
        }
        // the one light
        var _nx = -_gX * _relief, _ny = -_gY * _relief, _nm = sqrt(_nx * _nx + _ny * _ny + 1);
        _nx /= _nm; _ny /= _nm; var _nz = 1 / _nm;
        var _t = max(0, _nx * _lx + _ny * _ly + _nz * _lz);
        var _sd = max(0, _nx * _hx + _ny * _hy + _nz * _hzz);
        var _slope = sqrt(_gX * _gX + _gY * _gY);
        var _cr, _cg, _cb, _k;
        if (_t > 0.62) { _k = min(1, (_t - 0.62) / 0.38); _cr = _mid[0] + (_lit[0] - _mid[0]) * _k; _cg = _mid[1] + (_lit[1] - _mid[1]) * _k; _cb = _mid[2] + (_lit[2] - _mid[2]) * _k; }
        else { _k = min(1, _t / 0.62); _cr = _sha[0] + (_mid[0] - _sha[0]) * _k; _cg = _sha[1] + (_mid[1] - _sha[1]) * _k; _cb = _sha[2] + (_mid[2] - _sha[2]) * _k; }
        // the grain runs with the log (down the face): two samples of the three-octave value noise, written out
        var _xa = _fx * 23 + _fy * 2.4, _fl, _n0, _tt, _ss, _sa;
        _fl = floor(_xa); _n0 = _fl & 255; _tt = _xa - _fl; _ss = _tt * _tt * (3 - 2 * _tt); _sa = _perm[_n0] + (_perm[(_n0 + 1) & 255] - _perm[_n0]) * _ss;
        _xa *= 1; var _xb = (_fx * 23 + _fy * 2.4) * _f1;
        _fl = floor(_xb); _n0 = _fl & 255; _tt = _xb - _fl; _ss = _tt * _tt * (3 - 2 * _tt); _sa += (_perm[_n0] + (_perm[(_n0 + 1) & 255] - _perm[_n0]) * _ss) * 0.5;
        _xb = (_fx * 23 + _fy * 2.4) * _f2;
        _fl = floor(_xb); _n0 = _fl & 255; _tt = _xb - _fl; _ss = _tt * _tt * (3 - 2 * _tt); _sa += (_perm[_n0] + (_perm[(_n0 + 1) & 255] - _perm[_n0]) * _ss) * 0.25;
        var _grC = _sa / 1.75;
        var _xc = _fx * 57 + _fy * 5.5, _sb;
        _fl = floor(_xc); _n0 = _fl & 255; _tt = _xc - _fl; _ss = _tt * _tt * (3 - 2 * _tt); _sb = _perm[_n0] + (_perm[(_n0 + 1) & 255] - _perm[_n0]) * _ss;
        _xb = _xc * _f1;
        _fl = floor(_xb); _n0 = _fl & 255; _tt = _xb - _fl; _ss = _tt * _tt * (3 - 2 * _tt); _sb += (_perm[_n0] + (_perm[(_n0 + 1) & 255] - _perm[_n0]) * _ss) * 0.5;
        _xb = _xc * _f2;
        _fl = floor(_xb); _n0 = _fl & 255; _tt = _xb - _fl; _ss = _tt * _tt * (3 - 2 * _tt); _sb += (_perm[_n0] + (_perm[(_n0 + 1) & 255] - _perm[_n0]) * _ss) * 0.25;
        var _gr = _grC * 0.72 + (_sb / 1.75) * 0.28;
        // cavity: the deep ground beside the brow, the nose and the sockets holds shadow
        var _cav = (0.34 - _hh) / 0.21;
        if (_cav > 0) { _k = min(1, _cav) * MQS_CAVITY; _cr += (_sha[0] - _cr) * _k; _cg += (_sha[1] - _cg) * _k; _cb += (_sha[2] - _cb) * _k; }
        // banded pigment: a LAYER with an edge, a lit lip toward the light, a dark one away, a cast shadow beside it
        var _ink = 0;
        if (_hasPig) {
            var _ed = 0.3;
            if (_rowFace && _dEdge >= 0) _ed = min(0.3, min(_dEdge, _edgeY));
            _ed *= _FA;
            var _pk = (1 - (_slope / (_slope + 5.0)) * (0.30 + _wearP * 0.58)) * min(1, _ed / _edgeK) * (1 - max(0, _gr) * _wearP * 0.45);
            var _dh = _rgX * _dhx + _rgY * _dhy, _bx, _bnd, _cv;
            _bx = _hh * 1.45 + 0.25; _bnd = _bx - ((_bx < 0) ? ceil(_bx) : floor(_bx));
            _cv = ((_bnd < _duty) ? 1 : max(0, 1 - (_bnd - _duty) * 4.2)) * _pk; _cv = clamp((_cv - _lo) / (_hi - _lo), 0, 1);
            _ink = clamp((_cv - MQS_PAINT_T) * _inkK + 0.5, 0, 1);
            _bx = (_hh + _dh) * 1.45 + 0.25; _bnd = _bx - ((_bx < 0) ? ceil(_bx) : floor(_bx));
            _cv = ((_bnd < _duty) ? 1 : max(0, 1 - (_bnd - _duty) * 4.2)) * _pk; _cv = clamp((_cv - _lo) / (_hi - _lo), 0, 1);
            var _inkL = clamp((_cv - MQS_PAINT_T) * _inkK + 0.5, 0, 1);
            _bx = (_hh - _dh) * 1.45 + 0.25; _bnd = _bx - ((_bx < 0) ? ceil(_bx) : floor(_bx));
            _cv = ((_bnd < _duty) ? 1 : max(0, 1 - (_bnd - _duty) * 4.2)) * _pk; _cv = clamp((_cv - _lo) / (_hi - _lo), 0, 1);
            var _inkD = clamp((_cv - MQS_PAINT_T) * _inkK + 0.5, 0, 1);
            if (_ink > 0) {
                var _t2 = min(1, _t);
                var _plr = _pr * 0.62 + ((_pr + (255 - _pr) * 0.16) - _pr * 0.62) * _t2;
                var _plg = _pg * 0.62 + ((_pg + (252 - _pg) * 0.16) - _pg * 0.62) * _t2;
                var _plb = _pb * 0.62 + ((_pb + (244 - _pb) * 0.16) - _pb * 0.62) * _t2;
                _k = _ink * 0.97; _cr += (_plr - _cr) * _k; _cg += (_plg - _cg) * _k; _cb += (_plb - _cb) * _k;
                var _lip = _ink * (1 - _inkL);
                if (_lip > 0.02) { _k = _lip * 0.40; _cr += (255 - _cr) * _k; _cg += (247 - _cg) * _k; _cb += (228 - _cb) * _k; }
                var _back = _ink * (1 - _inkD);
                if (_back > 0.02) { _k = _back * 0.32; _cr += (24 - _cr) * _k; _cg += (13 - _cg) * _k; _cb += (7 - _cb) * _k; }
            }
            var _cast = (1 - _ink) * _inkL;
            if (_cast > 0.02) { _k = _cast * 0.26; _cr += (20 - _cr) * _k; _cg += (11 - _cg) * _k; _cb += (6 - _cb) * _k; }
        }
        // the figure of the wood runs THROUGH the paint
        var _gAmt = abs(_gr) * _grk * 0.17;
        if (_ink < 1) {
            _k = _gAmt * (1 - _ink);
            if (_gr > 0) { _cr += (_lit[0] - _cr) * _k; _cg += (_lit[1] - _cg) * _k; _cb += (_lit[2] - _cb) * _k; }
            else { _cr += (_sha[0] - _cr) * _k; _cg += (_sha[1] - _cg) * _k; _cb += (_sha[2] - _cb) * _k; }
        }
        if (_ink > 0) {
            _k = _gAmt * _ink * 0.66;
            if (_gr > 0) { _cr += (255 - _cr) * _k; _cg += (248 - _cg) * _k; _cb += (232 - _cb) * _k; }
            else { _cr += (14 - _cr) * _k; _cg += (9 - _cg) * _k; _cb += (6 - _cb) * _k; }
        }
        var _line = (abs(_grC) - 0.62) / 0.38;
        if (_line > 0) {
            _k = min(1, _line) * _grk * 0.26;
            if (_ink > 0.5) { _k *= 0.74; _cr += (14 - _cr) * _k; _cg += (9 - _cg) * _k; _cb += (6 - _cb) * _k; }
            else { _cr += (_sha[0] - _cr) * _k; _cg += (_sha[1] - _cg) * _k; _cb += (_sha[2] - _cb) * _k; }
        }
        // one specular, on whatever stands highest: a glint, not a sweep (capped and squared)
        if (_sd > 0.83) {
            var _spec = power(_sd, 22);
            if (_spec > 0.02) { _k = min(0.52, _spec * _spec * (0.45 + _gloss)); _cr += (255 - _cr) * _k; _cg += (246 - _cg) * _k; _cb += (226 - _cb) * _k; }
        }
        // the lit rim where the form turns away, on the light's side only: it separates the mask from the wall
        var _rim = 0;
        if (!((_ic - 4 >= 0) && (_ins[_jc * _SW + _ic - 4] >= 1))) _rim += 0.5;
        if (!((_jc - 4 >= 0) && (_ins[(_jc - 4) * _SW + _ic] >= 1))) _rim += 0.5;
        if (!((_ic - 3 >= 0) && (_jc - 3 >= 0) && (_ins[(_jc - 3) * _SW + _ic - 3] >= 1))) _rim += 0.4;
        if (_rim > 0) { _k = min(1, _rim) * 0.55; _cr += (255 - _cr) * _k; _cg += (240 - _cg) * _k; _cb += (214 - _cb) * _k; }
        // the inner rim of a void
        if (_v > 0) { _k = _v * 0.5; _cr += (255 - _cr) * _k; _cg += (236 - _cg) * _k; _cb += (206 - _cb) * _k; }
        // wear: chips out of the lit edge, the crack of age, and the cut breaks (asked only where it can answer)
        if (_rowCut || _rowCrack || (_rowFace && _dEdge < _chipBand)) {
            var _wear = mqs__wear_at(_g, _fx, _fy, _age, _px);
            if (_wear == 2) continue;
            if (_wear == 1) { _cr += (_sha[0] - _cr) * 0.72; _cg += (_sha[1] - _cg) * 0.72; _cb += (_sha[2] - _cb) * 0.72; }
        }
        var _A = floor(_cov * 255 + 0.5);
        buffer_poke(_buf, (_y * _W + _x) * 4, buffer_u32, clamp(floor(_cr + 0.5), 0, 255) | (clamp(floor(_cg + 0.5), 0, 255) << 8) | (clamp(floor(_cb + 0.5), 0, 255) << 16) | (_A << 24));
    }
    _job.row++;
    if (_job.row >= _job.h) { _job.phase = 4; _job.row = 0; }
}

// ================================================================================================ phase 4: knot and marks
// ⛔ The marks are a LIST OF OPS drawn one pixel ROW at a time: a mark drawn whole (a wire down the whole face, a scorch a
// third of the mask across) was one indivisible step of ~300 ms inside a 4 ms budget (MEASURED, suite stage 70).

/// @function mqs__bake_knot(job)
/// @description Where the cord ties: over the highest point of the upper-left shoulder, READ FROM THE PIXELS (a model of
/// the shape is wrong both ways: the bounding box floats the knot in mid-air, one chosen column misses a narrow crown).
/// Internal.
function mqs__bake_knot(_job) {
    var _g = _job.geo, _W = _job.w, _H = _job.h, _buf = _job.buf;
    var _knotY = 0.055, _knotX = _g.lean * _knotY - mqs__half_width(_g.sil, _knotY) * 0.70;
    var _kx = floor((_knotX - _job.min_x) * _job.scale_x + 0.5), _ky = (_knotY - _job.min_y) * _job.scale;
    var _lo = max(0, floor(_W * 0.12 + 0.5)), _hi = min(_W - 1, floor(_W * 0.48 + 0.5));
    var _bestY = _H, _bestX = _kx;
    for (var _cx = _lo; _cx <= _hi; _cx++) {
        for (var _cy = 0; _cy < _bestY; _cy++) {
            if (buffer_peek(_buf, (_cy * _W + _cx) * 4 + 3, buffer_u8) > 8) { if (_cy < _bestY) { _bestY = _cy; _bestX = _cx; } break; }
        }
    }
    if (_bestY < _H) { _kx = _bestX; _ky = _bestY + max(2, _job.scale * 0.030); }
    _job.knot_x = _kx; _job.knot_y = _ky;
}

/// @function mqs__over(job, x, y, r, g, b, a)
/// @description Composite one colour OVER one buffer pixel (non-premultiplied, alpha as "over"). Internal.
function mqs__over(_job, _x, _y, _r, _g, _b, _a) {
    if (_a <= 0 || _x < 0 || _y < 0 || _x >= _job.w || _y >= _job.h) return;
    var _o = (_y * _job.w + _x) * 4, _d = buffer_peek(_job.buf, _o, buffer_u32);
    var _da = ((_d >> 24) & 255) / 255, _oa = _a + _da * (1 - _a);
    if (_oa <= 0) return;
    var _w = _da * (1 - _a);
    var _nr = (_r * _a + (_d & 255) * _w) / _oa, _ng = (_g * _a + ((_d >> 8) & 255) * _w) / _oa, _nb = (_b * _a + ((_d >> 16) & 255) * _w) / _oa;
    buffer_poke(_job.buf, _o, buffer_u32, clamp(floor(_nr + 0.5), 0, 255) | (clamp(floor(_ng + 0.5), 0, 255) << 8) | (clamp(floor(_nb + 0.5), 0, 255) << 16) | (clamp(floor(_oa * 255 + 0.5), 0, 255) << 24));
}

/// @function mqs__tint(job, x, y, r, g, b, a)
/// @description Mix one colour into a buffer pixel's colour ONLY, leaving its alpha: a mark that lies on the surface
/// cannot reach off it. Internal.
function mqs__tint(_job, _x, _y, _r, _g, _b, _a) {
    if (_a <= 0 || _x < 0 || _y < 0 || _x >= _job.w || _y >= _job.h) return;
    var _o = (_y * _job.w + _x) * 4, _d = buffer_peek(_job.buf, _o, buffer_u32);
    if (((_d >> 24) & 255) == 0) return;
    var _nr = (_d & 255) + (_r - (_d & 255)) * _a, _ng = ((_d >> 8) & 255) + (_g - ((_d >> 8) & 255)) * _a, _nb = ((_d >> 16) & 255) + (_b - ((_d >> 16) & 255)) * _a;
    buffer_poke(_job.buf, _o, buffer_u32, clamp(floor(_nr + 0.5), 0, 255) | (clamp(floor(_ng + 0.5), 0, 255) << 8) | (clamp(floor(_nb + 0.5), 0, 255) << 16) | (_d & $FF000000));
}

/// @function mqs__seg_dist(px, py, x0, y0, x1, y1)
/// @description Distance from a point to a segment. Internal, pure.
function mqs__seg_dist(_px, _py, _x0, _y0, _x1, _y1) {
    var _dx = _x1 - _x0, _dy = _y1 - _y0, _l2 = _dx * _dx + _dy * _dy;
    var _t = (_l2 > 0) ? clamp(((_px - _x0) * _dx + (_py - _y0) * _dy) / _l2, 0, 1) : 0;
    var _ex = _x0 + _dx * _t - _px, _ey = _y0 + _dy * _t - _py;
    return sqrt(_ex * _ex + _ey * _ey);
}

/// @function mqs__poly_cov(pts, x, y)
/// @description Antialiased coverage of a pixel centre by a polygon, from its SIGNED distance to the outline (exact for
/// any outline, concave included; one inside test and one distance per edge, not sixteen inside tests). Internal, pure.
function mqs__poly_cov(_pts, _x, _y) {
    var _n = array_length(_pts), _d = infinity, _j = _n - 1;
    for (var _i = 0; _i < _n; _i++) { _d = min(_d, mqs__seg_dist(_x, _y, _pts[_j][0], _pts[_j][1], _pts[_i][0], _pts[_i][1])); _j = _i; }
    return mqs__in_poly(_pts, _x, _y) ? clamp(0.5 + _d, 0, 1) : clamp(0.5 - _d, 0, 1);
}

/// @function mqs__op_box(op, x0, y0, x1, y1, job)
/// @description Clamp an op's pixel box to the mask and set its row range. Internal.
function mqs__op_box(_op, _x0, _y0, _x1, _y1, _job) {
    _op.x0 = max(0, floor(_x0)); _op.x1 = min(_job.w - 1, ceil(_x1));
    _op.y0 = max(0, floor(_y0)); _op.y1 = min(_job.h - 1, ceil(_y1));
    return _op;
}

/// @function mqs__op_stroke(job, pts, width, rgb, alpha, [surface_only])
/// @description An antialiased round-ended stroke along a polyline, blended ONCE per pixel (a translucent stroke must not
/// darken at its own joints). Internal.
function mqs__op_stroke(_job, _pts, _wid, _c, _al, _surf = false) {
    var _h = _wid / 2, _x0 = infinity, _y0 = infinity, _x1 = -infinity, _y1 = -infinity;
    for (var _i = 0; _i < array_length(_pts); _i++) { _x0 = min(_x0, _pts[_i][0]); _x1 = max(_x1, _pts[_i][0]); _y0 = min(_y0, _pts[_i][1]); _y1 = max(_y1, _pts[_i][1]); }
    return mqs__op_box({ t: 0, pts: _pts, h: _h, c: _c, a: _al, surf: _surf }, _x0 - _h - 1, _y0 - _h - 1, _x1 + _h + 1, _y1 + _h + 1, _job);
}

/// @function mqs__op_ellipse(job, cx, cy, rx, ry, rot, rgb, alpha)
/// @description An antialiased filled ellipse (rot in radians). Internal.
function mqs__op_ellipse(_job, _ex, _ey, _rx, _ry, _rot, _c, _al) {
    var _R = max(_rx, _ry) + 1.5;
    return mqs__op_box({ t: 1, cx: _ex, cy: _ey, rx: _rx, ry: _ry, cs: cos(_rot), sn: sin(_rot), mn: max(0.5, min(_rx, _ry)), c: _c, a: _al }, _ex - _R, _ey - _R, _ex + _R, _ey + _R, _job);
}

/// @function mqs__op_poly(job, pts, rgb, alpha, [clip])
/// @description An antialiased filled polygon, optionally clipped to a second one. Internal.
function mqs__op_poly(_job, _pts, _c, _al, _clip = undefined) {
    var _x0 = infinity, _y0 = infinity, _x1 = -infinity, _y1 = -infinity;
    for (var _i = 0; _i < array_length(_pts); _i++) { _x0 = min(_x0, _pts[_i][0]); _x1 = max(_x1, _pts[_i][0]); _y0 = min(_y0, _pts[_i][1]); _y1 = max(_y1, _pts[_i][1]); }
    return mqs__op_box({ t: 2, pts: _pts, clip: _clip, c: _c, a: _al }, _x0 - 1, _y0 - 1, _x1 + 1, _y1 + 1, _job);
}

/// @function mqs__op_row(job, op, y)
/// @description Draw one pixel row of one op. Internal.
function mqs__op_row(_job, _op, _y) {
    var _cy = _y + 0.5, _x;
    switch (_op.t) {
        case 0: {
            // only the segments that can reach this row, and only the columns they can reach
            var _pts = _op.pts, _n = array_length(_pts), _hh = _op.h + 1, _segs = [], _xl = infinity, _xr = -infinity;
            for (var _s0 = 0; _s0 + 1 < _n; _s0++) {
                var _ya = _pts[_s0][1], _yb = _pts[_s0 + 1][1];
                if (min(_ya, _yb) - _hh <= _cy && max(_ya, _yb) + _hh >= _cy) {
                    array_push(_segs, _s0);
                    _xl = min(_xl, _pts[_s0][0], _pts[_s0 + 1][0]); _xr = max(_xr, _pts[_s0][0], _pts[_s0 + 1][0]);
                }
            }
            var _ns = array_length(_segs);
            if (_ns == 0) break;
            for (_x = max(_op.x0, floor(_xl - _hh)); _x <= min(_op.x1, ceil(_xr + _hh)); _x++) {
                var _cx = _x + 0.5, _d = infinity;
                for (var _si = 0; _si < _ns; _si++) {
                    var _s = _segs[_si], _ax = _pts[_s][0], _ay = _pts[_s][1], _ddx = _pts[_s + 1][0] - _ax, _ddy = _pts[_s + 1][1] - _ay;
                    var _l2 = _ddx * _ddx + _ddy * _ddy;
                    var _tq = (_l2 > 0) ? clamp(((_cx - _ax) * _ddx + (_cy - _ay) * _ddy) / _l2, 0, 1) : 0;
                    var _ex = _ax + _ddx * _tq - _cx, _ey = _ay + _ddy * _tq - _cy;
                    _d = min(_d, sqrt(_ex * _ex + _ey * _ey));
                }
                var _cov = clamp(_op.h + 0.5 - _d, 0, 1);
                if (_cov <= 0) continue;
                if (_op.surf) mqs__tint(_job, _x, _y, _op.c[0], _op.c[1], _op.c[2], _op.a * _cov);
                else mqs__over(_job, _x, _y, _op.c[0], _op.c[1], _op.c[2], _op.a * _cov);
            }
            break;
        }
        case 1: {
            for (_x = _op.x0; _x <= _op.x1; _x++) {
                var _dx = _x + 0.5 - _op.cx, _dy = _cy - _op.cy;
                var _u = _dx * _op.cs + _dy * _op.sn, _v = -_dx * _op.sn + _dy * _op.cs;
                var _q = sqrt((_u / _op.rx) * (_u / _op.rx) + (_v / _op.ry) * (_v / _op.ry));
                var _c1 = clamp(0.5 - (_q - 1) * _op.mn, 0, 1);
                if (_c1 > 0) mqs__over(_job, _x, _y, _op.c[0], _op.c[1], _op.c[2], _op.a * _c1);
            }
            break;
        }
        case 2: {
            for (_x = _op.x0; _x <= _op.x1; _x++) {
                var _c2 = mqs__poly_cov(_op.pts, _x + 0.5, _cy);
                if (_c2 > 0 && !is_undefined(_op.clip)) _c2 *= mqs__poly_cov(_op.clip, _x + 0.5, _cy);
                if (_c2 > 0) mqs__over(_job, _x, _y, _op.c[0], _op.c[1], _op.c[2], _op.a * _c2);
            }
            break;
        }
        case 3: {
            // a burn ON the surface: a radial gradient inside a tilted ellipse, darkening what is there, never the air
            for (_x = _op.x0; _x <= _op.x1; _x++) {
                var _ddx = _x + 0.5 - _op.cx, _ddy = _cy - _op.cy;
                var _uu = _ddx * _op.cs + _ddy * _op.sn, _vv = -_ddx * _op.sn + _ddy * _op.cs;
                var _qq = sqrt((_uu / _op.rx) * (_uu / _op.rx) + (_vv / _op.ry) * (_vv / _op.ry));
                var _ec = clamp(0.5 - (_qq - 1) * _op.ry, 0, 1);
                if (_ec <= 0) continue;
                var _tt = clamp((sqrt(_ddx * _ddx + _ddy * _ddy) - _op.r0) / (_op.r1 - _op.r0), 0, 1);
                var _ga, _gr, _gg, _gb;
                if (_tt < 0.6) { var _f = _tt / 0.6; _gr = lerp(10, 24, _f); _gg = lerp(6, 14, _f); _gb = lerp(4, 8, _f); _ga = lerp(0.80, 0.40, _f); }
                else { _gr = 24; _gg = 14; _gb = 8; _ga = lerp(0.40, 0, (_tt - 0.6) / 0.4); }
                mqs__tint(_job, _x, _y, _gr, _gg, _gb, _ga * _ec);
            }
            break;
        }
    }
}

/// @function mqs__piece_path(x, y, r, house, geo, u)
/// @description The outline of one inlaid piece, by house (pixel units): a cast diamond plaque (verdigris), a pin lying
/// along the run (bone), an irregular cut plate (shell) - each house its own SHAPE, never one ellipse in four colours.
/// Internal, pure.
function mqs__piece_path(_x, _y, _r, _house, _g, _u) {
    if (_house == "verdigris") return [[_x, _y - _r], [_x + _r * 0.74, _y], [_x, _y + _r], [_x - _r * 0.74, _y]];
    if (_house == "bonePin") {
        var _a = 0.42 + mqs__n1(_g.grain, _u * 23) * 0.30, _c = cos(_a), _s = sin(_a);
        var _q = [[-0.34, -1.05], [0.34, -1.05], [0.30, 1.05], [-0.30, 1.05]], _o = [];
        for (var _i = 0; _i < 4; _i++) { var _dx = _q[_i][0] * _r, _dy = _q[_i][1] * _r; array_push(_o, [_x + _dx * _c - _dy * _s, _y + _dx * _s + _dy * _c]); }
        return _o;
    }
    var _p = [];
    for (var _k = 0; _k < 7; _k++) {
        var _th = MQS_PI * 2 * (_k / 7);
        var _rr = _r * (0.74 + abs(mqs__n1(_g.grain, _u * 31 + _k * 2.3)) * 0.50);
        array_push(_p, [_x + cos(_th) * _rr, _y + sin(_th) * _rr * 0.88]);
    }
    return _p;
}

/// @function mqs__bake_marks_plan(job)
/// @description Plan the marks as an op list: the inlay and the binding down ONE side (the second asymmetry), then the one
/// break that is laid ON the mask (a cord scar, a bound crack's staples, a scorch). Internal.
function mqs__bake_marks_plan(_job) {
    var _g = _job.geo, _P = mqs_palette(), _house = _job.profile.house, _side = _g.inlay_side;
    var _sc = _job.scale, _sx = _job.scale_x, _mx = _job.min_x, _my = _job.min_y, _ops = [];
    var _studs = [];
    for (var _i = 0; _i <= 16; _i++) {
        var _fy = 0.10 + (_i / 16) * 0.80;
        var _fx = _g.lean * _fy + _side * (mqs__half_width(_g.sil, _fy) - 0.135);   // inset, never on the edge
        array_push(_studs, [(_fx - _mx) * _sx, (_fy - _my) * _sc]);
    }
    // ⛔ a wire is a PHYSICAL width: proportional going down, capped going up (at the product's largest size a purely
    // proportional stroke was a 16 px tube down the face - found by looking at a 1024 px carve)
    var _lw = clamp(_sc * 0.016, 1, 5);
    if (_house == "goldWire" || _house == "lacquerThread") {
        var _wire = (_house == "goldWire") ? _P.gold_wire : _P.lacquer_thread;
        var _sh = [], _wp = [];
        for (var _k = 0; _k < array_length(_studs); _k++) {
            array_push(_sh, [_studs[_k][0] + 1.5, _studs[_k][1] + 1.5]);
            array_push(_wp, [_studs[_k][0] + sin(_k * 0.8) * _lw * 0.55, _studs[_k][1]]);
        }
        array_push(_ops, mqs__op_stroke(_job, _sh, _lw * 1.9, [0, 0, 0], 0.45));
        array_push(_ops, mqs__op_stroke(_job, _wp, _lw * 1.3, _wire, 1));
        if (_house == "goldWire") array_push(_ops, mqs__op_stroke(_job, _wp, max(0.6, _lw * 0.45), [255, 244, 206], 0.6));
    } else {
        var _fill = _P.iron_rivet;
        if (_house == "verdigris") _fill = _P.verdigris; else if (_house == "shell") _fill = _P.shell_inlay; else if (_house == "bonePin") _fill = _P.bone;
        var _rad = max(1.1, _sc * 0.026), _run = 0;
        for (var _s = 1; _s < array_length(_studs); _s++) _run += point_distance(_studs[_s - 1][0], _studs[_s - 1][1], _studs[_s][0], _studs[_s][1]);
        var _pitch = max(_rad * 2 + 2.6, _rad * 3.4);                 // a PITCH, and the count derived from the real run
        var _count = max(3, floor(_run / _pitch));
        for (var _q = 0; _q < _count; _q++) {
            var _u = (_q + 0.5) / _count, _fi = _u * 16, _a0 = floor(_fi), _ft = _fi - _a0, _a1 = min(16, _a0 + 1);
            var _x = _studs[_a0][0] + (_studs[_a1][0] - _studs[_a0][0]) * _ft;
            var _y = _studs[_a0][1] + (_studs[_a1][1] - _studs[_a0][1]) * _ft;
            // evenly spaced pieces of one size read as a zipper: each is cut and fitted by hand
            var _jig = mqs__n1(_g.grain, _u * 17 + 4);
            var _siz = 0.74 + abs(mqs__n1(_g.grain, _u * 29 + 11)) * 0.62;
            _x += _jig * _rad * 0.55;
            _y += mqs__n1(_g.grain, _u * 13 + 7) * _rad * 0.30;
            var _rr = _rad * _siz;
            if (_house == "ironRivet") {
                // the one piece that is genuinely proud of the surface: a rivet is hammered, so it keeps its dome
                array_push(_ops, mqs__op_ellipse(_job, _x + _rr * 0.38, _y + _rr * 0.44, _rr * 0.82, _rr * 0.74, 0, [0, 0, 0], 0.42));
                array_push(_ops, mqs__op_ellipse(_job, _x, _y, _rr * 0.80, _rr * 0.72, 0, _fill, 1));
                array_push(_ops, mqs__op_ellipse(_job, _x - _rr * 0.26, _y - _rr * 0.28, _rr * 0.30, _rr * 0.24, 0, [236, 238, 244], 0.45));
                continue;
            }
            // SET INTO the surface: the socket is dark on the light's side, the piece sits flat, one catch lower-right
            array_push(_ops, mqs__op_poly(_job, mqs__piece_path(_x, _y, _rr * 1.14, _house, _g, _u), [0, 0, 0], 0.42));
            var _piece = mqs__piece_path(_x + _rr * 0.10, _y + _rr * 0.12, _rr * 0.92, _house, _g, _u);
            array_push(_ops, mqs__op_poly(_job, _piece, _fill, 0.86));
            array_push(_ops, mqs__op_poly(_job, mqs__piece_path(_x + _rr * 0.30, _y + _rr * 0.34, _rr * 0.92, _house, _g, _u), [255, 252, 242], 0.26 * 0.86, _piece));
        }
    }
    // the one seeded break that is laid ON the mask (brokenHorn, faceCrack and chippedJaw were CUT in the pixel pass)
    var _kind = _g.break_drawn;
    if (_kind == "cordScar") {
        // a cord strapped across the face (face units, as the MZ original places it); it passes the edge as a binding does
        var _ax = (-0.85 - _mx) * _sx, _ay = (0.50 - _my) * _sc, _cx2 = (0.35 - _mx) * _sx, _cy2 = (0.82 - _my) * _sc;
        array_push(_ops, mqs__op_stroke(_job, [[_ax + 2, _ay + 2], [_cx2 + 2, _cy2 + 2]], clamp(_sc * 0.030, 2, 10), [0, 0, 0], 0.45));
        array_push(_ops, mqs__op_stroke(_job, [[_ax, _ay], [_cx2, _cy2]], clamp(_sc * 0.022, 1.5, 7), _P.cord, 1));
    } else if (_kind == "boundCrack") {
        // staples set ACROSS the crack the pixel pass cut (mqs__bound_crack_x is read by both); a PITCH, not a count
        var _runPx = (MQS_BOUND_BOTTOM - MQS_BOUND_TOP) * _sc, _pitchPx = max(_sc * 0.13, 16);
        var _n = clamp(floor(_runPx / _pitchPx + 0.5), 2, 6);
        var _half = max(2.5, _sc * 0.052), _thick = clamp(_sc * 0.013, 1.2, 5);
        for (var _t = 0; _t < _n; _t++) {
            var _by = MQS_BOUND_TOP + (_t + 0.5) * (MQS_BOUND_BOTTOM - MQS_BOUND_TOP) / _n;
            var _jt = mqs__n1(_g.grain, _by * 19 + 5) * 0.012;
            var _ppx = (mqs__bound_crack_x(_g, _by) + _jt - _mx) * _sx, _ppy = (_by + mqs__n1(_g.grain, _by * 7 + 1) * 0.008 - _my) * _sc;
            var _tl = mqs__n1(_g.grain, _by * 23 + 9) * 0.30;
            var _len = _half * (0.82 + abs(mqs__n1(_g.grain, _by * 31 + 3)) * 0.42);
            var _dx = cos(_tl) * _len, _dy = sin(_tl) * _len;
            array_push(_ops, mqs__op_stroke(_job, [[_ppx - _dx + 1.2, _ppy - _dy + 1.4], [_ppx + _dx + 1.2, _ppy + _dy + 1.4]], _thick * 1.7, [0, 0, 0], 0.55));
            array_push(_ops, mqs__op_stroke(_job, [[_ppx - _dx, _ppy - _dy], [_ppx + _dx, _ppy + _dy]], _thick, _P.iron_rivet, 1));
            array_push(_ops, mqs__op_stroke(_job, [[_ppx - _dx, _ppy - _dy - _thick * 0.42], [_ppx + _dx, _ppy + _dy - _thick * 0.42]], max(0.6, _thick * 0.40), [236, 238, 244], 0.40));
        }
    } else if (_kind == "scorch") {
        var _scx = (-0.40 - _mx) * _sx, _scy = (0.62 - _my) * _sc, _erx = _sc * 0.30;
        array_push(_ops, mqs__op_box({ t: 3, cx: _scx, cy: _scy, rx: _erx, ry: _sc * 0.24, cs: cos(0.3), sn: sin(0.3), r0: _sc * 0.02, r1: _sc * 0.30 },
            _scx - _erx, _scy - _erx, _scx + _erx, _scy + _erx, _job));
    }
    _job.ops = _ops; _job.op_i = 0; _job.op_y = (array_length(_ops) > 0) ? _ops[0].y0 : 0;
}

/// @function mqs__bake_marks_row(job)
/// @description Phase 4: on the first call the knot is read and the marks planned; after that each call draws ONE pixel
/// row of ONE mark. Internal.
function mqs__bake_marks_row(_job) {
    if (_job.row == 0) { mqs__bake_knot(_job); mqs__bake_marks_plan(_job); _job.row = 1; return; }
    if (_job.op_i >= array_length(_job.ops)) { _job.phase = 5; _job.row = 0; return; }
    var _op = _job.ops[_job.op_i];
    if (_job.op_y <= _op.y1 && _op.x1 >= _op.x0) mqs__op_row(_job, _op, _job.op_y);
    _job.op_y++;
    if (_job.op_y > _op.y1) { _job.op_i++; if (_job.op_i < array_length(_job.ops)) _job.op_y = _job.ops[_job.op_i].y0; }
    _job.row++;
}

// ================================================================================================ phase 5-7: the sprites
// ⛔ A time-sliced job is only as smooth as its largest indivisible step: the shadow is downsampled row by row and blurred
// one pass per step, so no single step holds the whole blur.

/// @function mqs__bake_finish(job)
/// @description Phase 5, one row per call: the mask's alpha downsampled to half resolution into a padded field (the
/// shadow is blurred from it). On the last row the mask sprite is made (origin at its centre). Internal.
function mqs__bake_finish(_job) {
    var _W = _job.w, _H = _job.h;
    if (_job.row == 0) {
        _job.sh_w = ceil(_W / 2); _job.sh_h = ceil(_H / 2);
        _job.sh_br = max(1, floor(_job.size * 0.034 / 2));
        _job.sh_pad = _job.sh_br * 3 + 2;
        _job.sh_sw = _job.sh_w + _job.sh_pad * 2; _job.sh_sh = _job.sh_h + _job.sh_pad * 2;
        _job.sh_a = array_create(_job.sh_sw * _job.sh_sh, 0);
        _job.sh_t = array_create(_job.sh_sw * _job.sh_sh, 0);
    }
    var _y = _job.row, _pad = _job.sh_pad, _SW = _job.sh_sw, _a = _job.sh_a;
    for (var _x = 0; _x < _job.sh_w; _x++) {
        var _s = 0, _c = 0;
        for (var _dy = 0; _dy < 2; _dy++) for (var _dx = 0; _dx < 2; _dx++) {
            var _ix = _x * 2 + _dx, _iy = _y * 2 + _dy;
            if (_ix < _W && _iy < _H) { _s += buffer_peek(_job.buf, (_iy * _W + _ix) * 4 + 3, buffer_u8); _c++; }
        }
        _a[(_y + _pad) * _SW + _x + _pad] = (_c > 0) ? _s / _c : 0;
    }
    _job.row++;
    if (_job.row >= _job.sh_h) {
        var _surf = surface_create(_W, _H);
        buffer_set_surface(_job.buf, _surf, 0);
        _job.spr = sprite_create_from_surface(_surf, 0, 0, _W, _H, false, false, _W / 2, _H / 2);
        surface_free(_surf);
        _job.phase = 6; _job.row = 0;
    }
}

/// @function mqs__bake_blur(job)
/// @description Phase 6: six box passes (horizontal then vertical, three times: close to a gaussian of sigma about
/// size x 0.034), each done in bands of 32 lines per call so no call holds a whole pass. Internal.
function mqs__bake_blur(_job) {
    var _SW = _job.sh_sw, _SH = _job.sh_sh, _br = _job.sh_br, _win = _br * 2 + 1, _a = _job.sh_a, _t = _job.sh_t;
    if (!variable_struct_exists(_job, "bl_pos")) _job.bl_pos = 0;
    var _p0 = _job.bl_pos, _band = 32;
    if ((_job.row mod 2) == 0) {
        for (var _j = _p0; _j < min(_SH, _p0 + _band); _j++) {
            var _acc = 0, _o = _j * _SW;
            for (var _i = -_br; _i <= _br; _i++) if (_i >= 0 && _i < _SW) _acc += _a[_o + _i];
            for (var _i2 = 0; _i2 < _SW; _i2++) {
                _t[_o + _i2] = _acc / _win;
                var _add = _i2 + _br + 1, _sub = _i2 - _br;
                if (_add < _SW) _acc += _a[_o + _add];
                if (_sub >= 0) _acc -= _a[_o + _sub];
            }
        }
    } else {
        for (var _i3 = _p0; _i3 < min(_SW, _p0 + _band); _i3++) {
            var _acc2 = 0;
            for (var _j2 = -_br; _j2 <= _br; _j2++) if (_j2 >= 0 && _j2 < _SH) _acc2 += _t[_j2 * _SW + _i3];
            for (var _j3 = 0; _j3 < _SH; _j3++) {
                _a[_j3 * _SW + _i3] = _acc2 / _win;
                var _add2 = _j3 + _br + 1, _sub2 = _j3 - _br;
                if (_add2 < _SH) _acc2 += _t[_add2 * _SW + _i3];
                if (_sub2 >= 0) _acc2 -= _t[_sub2 * _SW + _i3];
            }
        }
    }
    _job.bl_pos += _band;
    if (_job.bl_pos >= (((_job.row mod 2) == 0) ? _SH : _SW)) { _job.bl_pos = 0; _job.row++; }
    if (_job.row >= 6) { _job.phase = 7; _job.row = 0; }
}

/// @function mqs__bake_done(job)
/// @description Phase 7: the shadow sprite (white, so it can be drawn in any colour: black for a shadow, warm for a
/// glow), the rotated box, and the finished mask record. Frees the job's buffers. Internal.
function mqs__bake_done(_job) {
    var _W = _job.w, _H = _job.h, _g = _job.geo, _SW = _job.sh_sw, _SH = _job.sh_sh, _a = _job.sh_a;
    // one row of the shadow per call (a whole shadow written at once was an indivisible step)
    if (_job.row == 0) _job.sh_b = buffer_create(_SW * _SH * 4, buffer_fixed, 1);
    if (_job.row < _SH) {
        var _o = _job.row * _SW;
        for (var _k = 0; _k < _SW; _k++) buffer_poke(_job.sh_b, (_o + _k) * 4, buffer_u32, $FFFFFF | (clamp(floor(_a[_o + _k] + 0.5), 0, 255) << 24));
        _job.row++;
        return;
    }
    var _sb = _job.sh_b;
    var _ss = surface_create(_SW, _SH);
    buffer_set_surface(_sb, _ss, 0);
    var _shadow = sprite_create_from_surface(_ss, 0, 0, _SW, _SH, false, false, _SW / 2, _SH / 2);
    surface_free(_ss);
    buffer_delete(_sb);
    buffer_delete(_job.buf);
    _job.buf = undefined;
    if (surface_exists(_job.preview)) surface_free(_job.preview);
    _job.preview = -1;
    // the rotated box: W|cos| + H|sin| by H|cos| + W|sin| (both terms, or a tilted crown loses its tips)
    var _ca = abs(cos(_g.tilt)), _sa = abs(sin(_g.tilt));
    var _BW = ceil(_W * _ca + _H * _sa) + 4, _BH = ceil(_H * _ca + _W * _sa) + 4;
    var _rx = _job.knot_x - _W / 2, _ry = _job.knot_y - _H / 2, _cs = cos(_g.tilt), _sn = sin(_g.tilt);
    _job.mask = {
        sprite: _job.spr, shadow: _shadow, shadow_scale: _W / max(1, _job.sh_w), shadow_pad: _job.sh_pad,
        w: _W, h: _H, tilt: _g.tilt, knot_x: _job.knot_x, knot_y: _job.knot_y, box_w: _BW, box_h: _BH,
        box_knot_x: _BW / 2 + _rx * _cs - _ry * _sn, box_knot_y: _BH / 2 + _rx * _sn + _ry * _cs,
        height: _job.size, key: _job.profile.key, break_drawn: _g.break_drawn, ms: _job.us / 1000
    };
    _job.ins = undefined; _job.hg = undefined; _job.gxn = undefined; _job.gyn = undefined; _job.sh_a = undefined; _job.sh_t = undefined;
    _job.done = true;
}

// ================================================================================================ drawing a finished mask

/// @function mqs_mask_draw(mask, x, y, [scale], [alpha])
/// @description Draw a finished mask hanging at its tilt, the top-left of its rotated box at x, y. Filtered (it is
/// rotated), alpha blended as "over" so it can be drawn onto your own surfaces without punching holes in them.
function mqs_mask_draw(_m, _x, _y, _scale = 1, _alpha = 1) {
    if (!is_struct(_m) || !variable_struct_exists(_m, "sprite") || !sprite_exists(_m.sprite)) return;
    _x = mqs__num(_x); _y = mqs__num(_y); _scale = clamp(mqs__num(_scale), 0, 64); _alpha = clamp(mqs__num(_alpha), 0, 1);
    gpu_push_state();
    gpu_set_texfilter(true);
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    draw_sprite_ext(_m.sprite, 0, _x + _m.box_w * _scale / 2, _y + _m.box_h * _scale / 2, _scale, _scale, -_m.tilt * 180 / pi, c_white, _alpha);
    gpu_pop_state();
}

/// @function mqs_mask_draw_shadow(mask, x, y, [scale], [colour], [alpha], [spread])
/// @description Draw a finished mask's soft shadow (or, in a warm colour at no offset, its glow), placed as
/// mqs_mask_draw would place the mask; `spread` scales the shadow about the mask's centre (1 = the mask's own size).
function mqs_mask_draw_shadow(_m, _x, _y, _scale = 1, _col = c_black, _alpha = 0.6, _spread = 1) {
    if (!is_struct(_m) || !variable_struct_exists(_m, "shadow") || !sprite_exists(_m.shadow)) return;
    _x = mqs__num(_x); _y = mqs__num(_y); _scale = clamp(mqs__num(_scale), 0, 64); _alpha = clamp(mqs__num(_alpha), 0, 1);
    _spread = clamp(mqs__num(_spread), 0, 8); _col = is_numeric(_col) ? _col : c_black;
    gpu_push_state();
    gpu_set_texfilter(true);
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    var _k = _scale * _m.shadow_scale * _spread;
    draw_sprite_ext(_m.shadow, 0, _x + _m.box_w * _scale / 2, _y + _m.box_h * _scale / 2, _k, _k, -_m.tilt * 180 / pi, _col, _alpha);
    gpu_pop_state();
}

/// @function mqs_mask_free(mask)
/// @description Delete a finished mask's sprites. Call it in Clean Up, never straight after drawing (GameMaker queues
/// draws: a sprite deleted in the same frame it was drawn draws as a white box).
function mqs_mask_free(_m) {
    if (!is_struct(_m)) return;
    if (variable_struct_exists(_m, "sprite") && sprite_exists(_m.sprite)) sprite_delete(_m.sprite);
    if (variable_struct_exists(_m, "shadow") && sprite_exists(_m.shadow)) sprite_delete(_m.shadow);
    _m.sprite = -1; _m.shadow = -1;
}
