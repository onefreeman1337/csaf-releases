{
  "$GMScript": "v1",
  "%Name": "mqs_oracle",
  "name": "mqs_oracle",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}