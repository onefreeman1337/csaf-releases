# Masque - Every Creature Carves Its Own Mask, for GameMaker

**GameMaker 2024.14 or newer · pure GML · no sprites, no shaders, no extensions**
Core Systems Asset Factory · <https://csaf.itch.io>

A mask pack ships five masks. A face pack ships a hundred faces, and your own creature is not one of them.

Masque reads the enemy and character records YOU wrote and carves each one a mask, lit and painted and worn, in pure
GML. A Bog Wight and a Cinder Drake do not merely get different labels: they get a different face structure, a
different superstructure growing out of the brow, a different pigment, a different inlay and a different amount of
wear, and every one of those is traceable back to a field in your records. The player fills a rack with the masks of
what they have met, and any mask can be shown full screen as a creature's true face, carving itself as you watch.

**Nothing here is an image file.** The demo roster of 56 invented creatures and party members resolves to 56 different
masks.

---

## Quick start

1. **Tools > Import Local Package**, choose `Masque.yymps`, import everything.
2. Open `rm_mqs_demo` and press Play: a rack of 56 pegs, a third of them filled. **Space** meets the next creature (its
   mask carves itself in front of you and goes on the rack), the **arrows** move along the rack, **Enter** shows a taken
   mask's true face.
3. In your own game, make one masque from your records, carve in the background, and draw the rack or a reveal:

```gml
// Create (once, e.g. in a persistent controller)
my_masque = mqs_masque_create(my_records, { factions: my_factions });

// when the player first meets a creature (after a battle, in a bestiary, anywhere)
mqs_masque_meet(my_masque, "Bog Wight");

// Step: carve waiting masks for up to 3 ms a frame
mqs_masque_update(my_masque, 3);

// Draw GUI: the rack, with a cursor you move with your own input
my_layout = mqs_rack_draw(my_masque, 0, 0, display_get_gui_width(), display_get_gui_height(), my_cursor);

// ...or one creature's true face (true once its mask is fully carved)
my_done = mqs_reveal_draw(my_masque, "Bog Wight", 0, 0, display_get_gui_width(), display_get_gui_height());

// Clean Up
mqs_masque_free(my_masque);
```

A mask is carved the first time the rack or the reveal shows it, by `mqs_masque_update`, under the budget you give
it. The reveal's mask is always carved first, and while it carves the reveal shows the rows struck so far.

### What you pass in

**Your records** are every enemy and character in your game, as an array (or a struct of structs). Rank is a
PERCENTILE of your own roster, so "strong" means strong for YOUR game. Every field is optional except `name`:

```gml
my_records = [
    { name: "Bog Wight", hp: 1500, atk: 60, def: 50, mat: 40, mdf: 45, agi: 20, luk: 12, exp: 400,
      strikes: ["darkness"], resists: [["water", 0.5], ["darkness", 0]], state_resists: 2,
      carries: ["Grave Salts"], faction: "Barrow Kin" },
    { name: "Cinder Drake", hp: 2200, atk: 90, def: 70, mat: 80, mdf: 60, agi: 40, luk: 20, exp: 900,
      strikes: "fire", carries: ["Cotton Robe"] },
    { kind: "character", name: "Sera Quill", class: "Sorcerer", level: 16, hp: 480, mat: 110,
      skills: [{ element: "fire", rating: 6 }, "ice"], carries: ["Oak Staff", "Silk Robe"] },
];
my_factions = [
    { name: "Barrow Kin", treatment: "bonePin" },
    { name: "Thornwood Clan", treatment: "goldWire", members: [4, 9] },
];
```

| field | what it decides |
| --- | --- |
| `name`, `sprite`, `words`, `class`, `title` | the face STRUCTURE, from its words (the name counts most) |
| `hp mp atk def mat mdf agi luk`, `level`, `exp` | the RANK (a percentile of its own kind in your roster), and the structure when no word says anything |
| `strikes`, `skills`, `resists` | the PIGMENT: what it strikes with, else the commonest element of its skills, else the element it resists hardest (a thing made of fire does not burn) |
| `resists`, `state_resists` | with rank, how OLD the mask looks |
| `faction`, `carries` | the HOUSE (the inlay and binding): its faction, else a faction that lists its id, else what it carries |
| `id`, `kind` | the mask's key (`kind:id:name`); enemies and characters are ranked separately. `kind` is `"enemy"` (the default) or `"character"` |

Elements are names (`"fire"`, `"ice"`, `"thunder"`, `"water"`, `"earth"`, `"wind"`, `"light"`, `"darkness"`, and
`"dark"`, `"holy"`, `"lightning"` read as their element) or index numbers. `"physical"` is never a colour: an
unpainted mask shows its bare material. Add your own elements with `options.elements`, a list of names by index
(`mqs_elements_default()` is the list it starts from); an element past the ninth gets a pigment of its own.

Carried things are read by their words: a sword, axe, spear, staff, bow, crossbow, dagger, claw or glove votes twice
as hard as a robe, leather, plate, buckler or shield; anything else (`"Herb"`, `"Grave Salts"`) is an item.

### The hand always wins

Any record can override what is read: `mask_type` (one of `mqs_structures()`), `mask_rank` (0-11),
`mask_element` (a name or an index), `mask_age` (one of `mqs_ages()`, or 0-4), `mask_name` (the name engraved on the
placard) and `mask_skip: true` (never carve this one).

---

## What it reads, and what it decides

`mqs_read(records, [options])` turns your records into **profiles**, one per record, and `mqs_signature(profile)`
names its five axes as one string. The six axes:

| axis | values | from |
| --- | --- | --- |
| structure | 10: beast, humanoid, undead, spirit, construct, dragon, insect, aquatic, plant, fiend | its words, else the shape of its numbers (a character with no telling words is a humanoid) |
| superstructure | 12, humblest to grandest: bare, brow ridge, twin horns, crest, fan, antler frame, plume, halo ring, tusks, crown of thorns, mane, sun disc | rank |
| pigment | 8 elements plus any you add, or unpainted | what it fights with |
| house | 6: gold wire, verdigris, iron rivet, shell inlay, bone pin, lacquer thread | its faction, else what it carries |
| age | 5: green, seasoned, old, ancient, relic | rank and hardiness |
| break | 6: a broken horn, a face crack, a cord scar, a chipped jaw, a bound crack, a scorch | the record's own seed |

Every choice is read from the record or hashed from its key, so a creature's mask is the same mask on every machine
and in every save. Nothing uses `random()`.

## What gets carved

A **silhouette** from the structure, leaning a little to one side (no mask is symmetrical); a **relief** of masses (a
brow, cheekbones, a nose ridge, a jaw, the sockets) summed into a height field and **lit by one light**, so the
highlight and the shadow are consequences of the form; **eye-holes and a mouth cut through**, with teeth where the
structure has them; the **superstructure** grown out of the brow and lit like the face; **banded paint** that follows
the planes, wears thin on the ridges, keeps a lit lip at its edge and lets the wood's grain run through it; **inlay**
down one side; **chips** on the lit edge and a crack that lengthens with age; and exactly **one break**. The rack hangs
each mask from an iron peg by a knotted cord tied over its highest shoulder; the reveal adds an engraved brass placard
with its name and its four readings.

---

## The functions

### The collection and its screens

| function | does |
| --- | --- |
| `mqs_masque_create(records, [options])` | reads every record once; options `{ elements, factions, rack_title, reveal_height }` |
| `mqs_masque_update(masque, [budget_ms])` | carves waiting masks for up to budget_ms (default 3); returns how many still wait |
| `mqs_masque_meet(masque, who)` | the player has met it; true if that is new. `who` is a profile, a key, a name or an id |
| `mqs_masque_find(masque, who, [kind])` | the profile, or undefined |
| `mqs_masque_taken(masque, who)` | has the player taken this mask? |
| `mqs_masque_count(masque)` / `mqs_masque_total(masque)` | how many are taken / how many there are |
| `mqs_masque_mask(masque, who, height)` | the finished mask at that height, or undefined (it is then queued) |
| `mqs_masque_save(masque)` / `mqs_masque_load(masque, string)` | the rack as a string for your own save file, and back |
| `mqs_masque_free(masque)` | frees every sprite it holds (call in Clean Up) |
| `mqs_rack_layout(masque, w, h)` | the solved peg grid for a rectangle: `{ cols, rows, cell, per_page, x0, y0, head, foot }` |
| `mqs_rack_draw(masque, x, y, w, h, [cursor], [title])` | draws the rack; returns the layout plus `page` and `pages` |
| `mqs_reveal_draw(masque, who, x, y, w, h, [eyebrow], [hint])` | draws one true face; true once it is fully carved |

The rack solves its own grid for the rectangle you give it (it never uses cells under 140 px when it can avoid it, and
pages when the collection is larger than a screen). The cursor is an index into the roster; move it with your input.

### Carving one mask yourself

| function | does |
| --- | --- |
| `mqs_read(records, [options])` | the profiles, without a collection |
| `mqs_carve(profile, height)` | carves a mask NOW and returns it (height 8 to 1024 px, crown included) |
| `mqs_carve_begin(profile, height)` / `mqs_carve_step(job, budget_ms)` | the same, as a job you step under a budget; `job.mask` once it returns true |
| `mqs_carve_progress(job)` / `mqs_carve_preview(job)` / `mqs_carve_cancel(job)` | 0..1 / a surface of the rows carved so far / stop and free |
| `mqs_mask_draw(mask, x, y, [scale], [alpha])` | draws a finished mask at its tilt, its rotated box's top-left at x, y |
| `mqs_mask_draw_shadow(mask, x, y, [scale], [colour], [alpha], [spread])` | its soft shadow, or in a warm colour its glow |
| `mqs_mask_free(mask)` | deletes its sprites |

A **mask** is `{ sprite, shadow, w, h, tilt, knot_x, knot_y, box_w, box_h, box_knot_x, box_knot_y, height, key, ms }`.
The sprite is unrotated with its origin at its centre; `box_*` is the rotated mask's box and where its cord ties in it.

```gml
// a boss's mask on your own title card, carved once (Create), drawn every frame (Draw), freed in Clean Up
my_profiles = mqs_read(my_records);
my_mask = mqs_carve(my_profiles[0], 300);
mqs_mask_draw(my_mask, 100, 40);
```

### The things a mask hangs from

`mqs_wall_sprite(w, h, [seed], [plank])` (a walnut wall as a sprite, yours to free), `mqs_peg_draw(x, y, r)`,
`mqs_cord_draw(peg_x, peg_y, knot_x, knot_y, [width], [part])` (part `"run"` before the mask, `"knot"` after it),
`mqs_placard_draw(x, y, w, h, title, [readings])`, `mqs_text_fit(font, text, max_w, size)`, `mqs_palette()`,
`mqs_colour(rgb)`, `mqs_rgb(hex)`, `mqs_ink_for(rgb, [want])`.

### Vocabularies and helpers

`mqs_structures()`, `mqs_crowns()`, `mqs_houses()`, `mqs_ages()`, `mqs_breaks()`, `mqs_elements_default()`,
`mqs_crown_label(rank)`, `mqs_house_label(house)`, `mqs_names_word(text, word)`, `mqs_goods_kind(text)`,
`mqs_hash(text)`, `mqs_rng(seed)`, `mqs_rnd(state)`, `mqs_signature(profile)`.

---

## Notes

- **Cost.** A mask is carved pixel by pixel on the CPU, so it is a job, never something to do inside one frame by
  accident. Measured on the GameMaker VM (runtime 2024.14.4.268, three runs on a busy machine): about **0.15 to 0.4
  seconds** of carving per 100 px rack mask and **2.4 to 3.1 seconds** for a 420 px reveal, spread over frames by
  `mqs_masque_update` (no single step of a 4 ms budget ran past about 12 ms). The YYC target is faster; it was not
  measured. Carve in a loading screen, or when a creature is first met, and the rack is instant after that.
- **Draw calls** blend alpha as "over" and restore your GPU state, so the rack can be drawn onto your own surfaces.
  `mqs_wall_sprite` bakes under an identity matrix and hands your world matrix and scissor back.
- **Saving.** Only which masks are taken is saved (`mqs_masque_save`); masks are carved again from the records, so a
  save never holds an image.
- **The fonts** (`fnt_masque*`) letter the placards and the rack; replace them in the IDE to use your own typeface.
- **The demo** borrows `mqs_oracle`, the suite's invented roster; `mqs_selftest` is the in-engine suite
  (`Masque.exe -selftest`). Neither is needed at run time: delete both, and the `-selftest` lines of the demo object's
  Create event, if you like.
- **Tested on** the GameMaker 2024.14 runtime (VM). GMRT is not claimed.
- **Made with AI.** Masque was written with AI assistance, and every listing says so.
- **Licence:** see `LICENSE.txt`. Copyright (c) 2026 Core Systems Asset Factory.
