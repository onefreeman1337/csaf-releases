/* =====================================================================
   sound.js — BANNERET: SUCCESSION. Every sound, synthesized.

   No audio files ship with this game. Each effect is a ZzFX parameter
   set — sound as code, matching art.js's every-pixel-drawn thesis.

   Contains ZzFXMicro v1.3.2, MIT licence:
     Copyright (c) 2019 Frank Force  (github.com/KilledByAPixel/ZzFX)
     Permission is hereby granted, free of charge, to any person
     obtaining a copy of this software and associated documentation
     files (the "Software"), to deal in the Software without
     restriction, including without limitation the rights to use, copy,
     modify, merge, publish, distribute, sublicense, and/or sell copies
     of the Software. The above notice shall be included in all copies
     or substantial portions of the Software. THE SOFTWARE IS PROVIDED
     "AS IS", WITHOUT WARRANTY OF ANY KIND.
   MODIFIED here (as the MIT licence permits): the AudioContext is
   created LAZILY on the first play instead of at load — browsers block
   audio before a user gesture, and every play in this game originates
   from a click handler, so the first click both creates and unlocks it.
   ===================================================================== */
'use strict';

(function (root) {

  var zzfxV = 0.3;          /* master volume */
  var zzfxX = null;         /* AudioContext — created on first play */

  /* ZzFXMicro v1.3.2 by Frank Force, MIT (see header). Reformatted only
     as far as the lazy-context change required; the algorithm is his. */
  function zzfx(p, k, b, e, r, t, q, D, u, y, v, z, l, E, A, F, c, w, m, B, N) {
    p = p === undefined ? 1 : p; k = k || .05; b = b === undefined ? 220 : b;
    e = e || 0; r = r || 0; t = t === undefined ? .1 : t; q = q || 0;
    D = D === undefined ? 1 : D; u = u || 0; y = y || 0; v = v || 0; z = z || 0;
    l = l || 0; E = E || 0; A = A || 0; F = F || 0; c = c || 0;
    w = w === undefined ? 1 : w; m = m || 0; B = B || 0; N = N || 0;
    if (!zzfxX) zzfxX = new (root.AudioContext || root.webkitAudioContext)();
    if (zzfxX.state === 'suspended') zzfxX.resume();
    var M = Math, d = 2 * M.PI, R = 44100, G = u *= 500 * d / R / R,
        C = b *= (1 - k + 2 * k * M.random(k = [])) * d / R,
        g = 0, H = 0, a = 0, n = 1, I = 0, J = 0, f = 0, h = N < 0 ? -1 : 1,
        x = d * h * N * 2 / R, L = M.cos(x), Z = M.sin, K = Z(x) / 4, O = 1 + K,
        X = -2 * L / O, Y = (1 - K) / O, P = (1 + h * L) / 2 / O, Q = -(h + L) / O,
        S = P, T = 0, U = 0, V = 0, W = 0;
    e = R * e + 9; m *= R; r *= R; t *= R; c *= R; y *= 500 * d / R ** 3;
    A *= d / R; v *= d / R; z *= R; l = R * l | 0; p *= zzfxV;
    for (h = e + m + r + t + c | 0; a < h; k[a++] = f * p)
      ++J % (100 * F | 0) || (
        f = q ? 1 < q ? 2 < q ? 3 < q ? 4 < q ?
              (g / d % 1 < D / 2) * 2 - 1 : Z(g ** 3) :
              M.max(M.min(M.tan(g), 1), -1) :
              1 - (2 * g / d % 2 + 2) % 2 :
              1 - 4 * M.abs(M.round(g / d) - g / d) : Z(g),
        f = (l ? 1 - B + B * Z(d * a / l) : 1) *
            (4 < q ? f : (f < 0 ? -1 : 1) * M.abs(f) ** D) *
            (a < e ? a / e : a < e + m ? 1 - (a - e) / m * (1 - w) :
             a < e + m + r ? w : a < h - c ? (h - a - c) / t * w : 0),
        f = c ? f / 2 + (c > a ? 0 : (a < h - c ? 1 : (h - a) / c) * k[a - c | 0] / 2 / p) : f,
        N ? f = W = S * T + Q * (T = U) + P * (U = f) - Y * V - X * (V = W) : 0),
      x = (b += u += y) * M.cos(A * H++), g += x + x * E * Z(a ** 5),
      n && ++n > z && (b += v, C += v, n = 0),
      !l || ++I % l || (b = C, u = G, n = n || 1);
    var buf = zzfxX.createBuffer(1, h, R);
    buf.getChannelData(0).set(k);
    var src = zzfxX.createBufferSource();
    src.buffer = buf;
    src.connect(zzfxX.destination);
    src.start();
  }

  /* --------------------------------------------------- the instrument */

  var MUTE_KEY = 'banneret_succession_mute';
  var muted = false;
  try { muted = localStorage.getItem(MUTE_KEY) === '1'; } catch (e) {}

  /* Named sounds, tuned to the vellum-and-iron register: low, dry,
     nothing chirpy. Every one fires from a user gesture. */
  var BANK = {
    /* the wax seal presses */
    click: [.6, , 218, .006, .01, .04, 4, 1.6, , , , , , , , , , .62, .01],
    /* the banner lands and the ground answers */
    charge: [1.1, , 68, .02, .08, .34, 4, 1.9, -1, , , , , .4, , .3, , .48, .04],
    /* iron through a pike line */
    trample: [.9, , 129, .01, .05, .19, 4, 2.6, , , , , , 1.1, , .4, , .44, .02],
    /* a knight falls */
    death: [1, , 84, .03, .14, .5, 3, 1.2, , , -40, , , .6, , .5, , .4, .08],
    /* a bolt crosses the field */
    bolt: [.7, , 793, .004, .02, .09, 1, 3.9, -22, , , , , , , , , .5, .01],
    /* the horse refuses */
    refuse: [.55, , 96, .01, .03, .12, 4, .9, , , , , , .8, , , , .5, .03],
    /* the field is won */
    win: [.85, , 262, .04, .22, .4, 1, 1.4, , , 148, .08, .07, , , , , .6, .12],
    /* the march fails */
    lose: [.9, , 62, .06, .3, .7, 2, .8, , , , , , .3, , .4, , .42, .18],
    /* renown, unlocks, the gold leaf */
    gilt: [.7, , 524, .02, .14, .3, 1, 1.8, , , 262, .06, .05, , , , , .55, .08],
    /* an heir takes up the banner */
    heir: [.8, , 147, .05, .18, .42, 2, 1.1, , , 49, .1, .08, , , , , .5, .1]
  };

  function play(name) {
    if (muted) return;
    var s = BANK[name];
    if (!s) return;
    try { zzfx.apply(null, s); } catch (e) { /* audio is never fatal */ }
  }

  function toggleMute() {
    muted = !muted;
    try { localStorage.setItem(MUTE_KEY, muted ? '1' : '0'); } catch (e) {}
    return muted;
  }

  root.Sfx = { play: play, toggleMute: toggleMute, isMuted: function () { return muted; } };

})(typeof window !== 'undefined' ? window : globalThis);
