/* =====================================================================
   music.js — BANNERET: SUCCESSION. The score.

   Two looping tracks ship as real .ogg files in audio/:

     music_hall  — D aeolian, 76bpm,  12.63s. Every screen but the field.
     music_march — D aeolian, 116bpm,  8.28s. While a battle is on the board.

   SAME MODE, opposite articulation. The hall theme is built on a
   sustained OPEN FIFTH drone (D2 + A2, no third anywhere in it) — that
   is medieval organum, and the absent third is the whole point: a bare
   fifth is the sound of a chapel, and it is precisely what a triad is
   not. The march theme drops the drone, puts the bass in crotchets, adds
   a tabor and swaps the chant for a pulse fanfare. The mode is the
   house; the articulation is the situation.

   ⛔ OUR OWN IP, NO LICENCE, NO AI TAG.
   Composed as note data (Internal_Ops/Audio/music_*.json) and rendered
   by Kernel/capture/make_audio.js — oscillators, not samples, not a
   model. itch is explicit that self-contained procedural synthesis is
   not generative AI, so the Sounds disclosure stays "no" while the
   AI-written code is covered by Code = yes. Nothing to attribute and
   nothing that can be taken down.

   Web Audio rather than <audio loop>: HTMLAudioElement re-buffers at
   the wrap and most browsers insert an audible gap, which would waste
   the seam work these files were verified for (measured wrap
   discontinuity: 0.59% and 0.31% of peak, limit 5%).

   The AudioContext is created LAZILY on the first play — browsers block
   audio before a user gesture, and every route into this game starts
   with a click or a keypress.
   ===================================================================== */
'use strict';

(function (root) {

  var TRACKS = {
    hall:  'audio/music_hall.ogg',
    march: 'audio/music_march.ogg'
  };

  var VOL = 0.5;             /* under the cannons, never over them */
  var FADE = 0.9;            /* seconds */

  var ctx = null, master = null;
  var buffers = {};
  var current = null;        /* { name, src, gain } */
  var wanted = null;
  var muted = false;
  var loading = false;

  /* Same persisted key Sfx uses, so the two layers can never disagree
     across a reload. */
  try { muted = localStorage.getItem('banneret_succession_mute') === '1'; } catch (e) {}

  function ensureCtx() {
    if (ctx) return true;
    try {
      var AC = root.AudioContext || root.webkitAudioContext;
      if (!AC) return false;
      ctx = new AC();
      master = ctx.createGain();
      master.gain.value = muted ? 0 : VOL;
      master.connect(ctx.destination);
      return true;
    } catch (e) { return false; }   /* audio is never fatal */
  }

  function preload() {
    if (loading || !ensureCtx()) return;
    loading = true;
    Object.keys(TRACKS).forEach(function (name) {
      fetch(TRACKS[name])
        .then(function (r) { if (!r.ok) throw new Error(r.status); return r.arrayBuffer(); })
        .then(function (buf) {
          return new Promise(function (res, rej) {
            /* callback form first — the one Safari has always supported */
            var p = ctx.decodeAudioData(buf, res, rej);
            if (p && p.then) p.then(res, rej);
          });
        })
        .then(function (audio) {
          buffers[name] = audio;
          if (wanted === name && (!current || current.name !== name)) start(name);
        })
        .catch(function () { /* a missing track just means no music */ });
    });
  }

  function start(name) {
    if (!ctx || !buffers[name]) return;
    var g = ctx.createGain();
    g.gain.value = 0;
    g.connect(master);

    var src = ctx.createBufferSource();
    src.buffer = buffers[name];
    src.loop = true;                  /* sample-accurate; no gap at the wrap */
    src.connect(g);
    src.start(0);

    var now = ctx.currentTime;
    g.gain.linearRampToValueAtTime(1, now + FADE);

    if (current) {
      var old = current;
      old.gain.gain.cancelScheduledValues(now);
      old.gain.gain.setValueAtTime(old.gain.gain.value, now);
      old.gain.gain.linearRampToValueAtTime(0, now + FADE);
      /* stop AFTER the fade, or the crossfade is a cut */
      try { old.src.stop(now + FADE + 0.05); } catch (e) {}
    }
    current = { name: name, src: src, gain: g };
  }

  /**
   * Ask for a track. Safe to call on every scene change with the same name —
   * a request for whatever is already playing is ignored, so the score does
   * not restart each time the player opens and closes the cove.
   */
  function play(name) {
    if (!TRACKS[name]) return;
    wanted = name;
    if (!ensureCtx()) return;
    if (ctx.state === 'suspended' && ctx.resume) { try { ctx.resume(); } catch (e) {} }
    if (!loading) preload();
    if (current && current.name === name) return;
    if (buffers[name]) start(name);
  }

  function setMuted(m) {
    muted = !!m;
    if (!ctx) return;
    var now = ctx.currentTime;
    master.gain.cancelScheduledValues(now);
    master.gain.setValueAtTime(master.gain.value, now);
    master.gain.linearRampToValueAtTime(muted ? 0 : VOL, now + 0.25);
  }

  root.Music = {
    play: play,
    setMuted: setMuted,
    isPlaying: function () { return current ? current.name : null; },
    /* For the playtest: proves the tracks DECODED, not merely that play()
       was called without throwing. Both layers fail silently by design, so
       "no console errors" is equally true of a build with no audio at all. */
    loaded: function () { return Object.keys(buffers); },
    trackList: function () { return Object.keys(TRACKS); }
  };

})(typeof window !== 'undefined' ? window : globalThis);
