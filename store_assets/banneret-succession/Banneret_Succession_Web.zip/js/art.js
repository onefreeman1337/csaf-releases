/* =====================================================================
   art.js — BANNERET: SUCCESSION. Every pixel, drawn.

   Gate 1 (master CLAUDE.md §1.1a) says the look IS the product. This
   file is that claim's whole implementation, and it ships ZERO image
   files: the arms, the knights, the pikes, the map itself are all
   canvas paths generated from a seed. That is the point — a House's
   coat is unique to its save, and no two players' chronicles look alike.

   The visual thesis is a CAMPAIGN MAP INKED ON THE SAME VELLUM as the
   page around it. So nothing here draws a "tile" or a "sprite grid":
     · the grid is PRICKED and RULED, the way a scribe lays out a page,
       with a wobble that is seeded per-field and therefore stable
     · walls are hatched masonry, not filled squares
     · every foe is a silhouette in iron-gall ink; every knight is a
       silhouette in HIS OWN TINCTURES, differenced by generation
     · gold leaf appears only for renown, victory and the gate

   Nothing here knows the rules. It is handed a level, a state, and
   (for a charge) the exact object `Rules.resolve()` returned, and it
   draws that. The hover preview is drawn from a real resolve() call —
   so it is not a prediction of the outcome, it IS the outcome.
   ===================================================================== */
'use strict';

(function (root) {

  var Names = root.Names;

  /* ------------------------------------------------------------ pigments */

  var INK = '#241a10';
  var INK_SOFT = 'rgba(36,26,16,.62)';
  var INK_GHOST = 'rgba(36,26,16,.30)';
  var RUBRIC = '#a3271d';
  var GOLD = '#b8892b';
  var GOLD_LIT = '#dcae4e';
  var VELLUM = '#e9dcc0';

  function rng(seed) {
    var a = seed >>> 0;
    return function () {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      var t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }

  /* A hand-drawn line: three short segments with seeded drift, so ruled
     ink never reads as a 1px CSS border. */
  function inkLine(ctx, x1, y1, x2, y2, r, jitter) {
    var j = jitter == null ? 0.9 : jitter;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    var n = 3;
    for (var i = 1; i <= n; i++) {
      var t = i / n;
      var px = x1 + (x2 - x1) * t + (r() - 0.5) * j * (i < n ? 1 : 0.25);
      var py = y1 + (y2 - y1) * t + (r() - 0.5) * j * (i < n ? 1 : 0.25);
      ctx.lineTo(px, py);
    }
    ctx.stroke();
  }

  function roundRect(ctx, x, y, w, h, rad) {
    ctx.beginPath();
    ctx.moveTo(x + rad, y);
    ctx.arcTo(x + w, y, x + w, y + h, rad);
    ctx.arcTo(x + w, y + h, x, y + h, rad);
    ctx.arcTo(x, y + h, x, y, rad);
    ctx.arcTo(x, y, x + w, y, rad);
    ctx.closePath();
  }

  /* Crisp canvas at any device pixel ratio. Returns the CSS size. */
  function fitCanvas(cv, cssW, cssH) {
    var dpr = Math.min(root.devicePixelRatio || 1, 2.5);
    cv.width = Math.max(1, Math.round(cssW * dpr));
    cv.height = Math.max(1, Math.round(cssH * dpr));
    cv.style.width = cssW + 'px';
    cv.style.height = cssH + 'px';
    var ctx = cv.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    return ctx;
  }

  /* ===================================================================
     HERALDRY — a heater shield, honestly divided and charged.
     =================================================================== */

  /* The heater outline: straight sides, a curve to a point. */
  function shieldPath(ctx, x, y, w, h) {
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + w, y);
    ctx.lineTo(x + w, y + h * 0.52);
    ctx.quadraticCurveTo(x + w, y + h * 0.86, x + w / 2, y + h);
    ctx.quadraticCurveTo(x, y + h * 0.86, x, y + h * 0.52);
    ctx.closePath();
  }

  function fillDivision(ctx, x, y, w, h, div, fieldFill, chargeFill) {
    ctx.fillStyle = fieldFill;
    ctx.fillRect(x - 1, y - 1, w + 2, h + 2);
    ctx.fillStyle = chargeFill;
    if (div === 'per_pale') {
      ctx.fillRect(x + w / 2, y - 1, w / 2 + 2, h + 2);
    } else if (div === 'per_fess') {
      ctx.fillRect(x - 1, y + h * 0.46, w + 2, h + 2);
    } else if (div === 'per_bend') {
      ctx.beginPath();
      ctx.moveTo(x - 1, y - 1); ctx.lineTo(x + w + 1, y - 1);
      ctx.lineTo(x + w + 1, y + h + 1); ctx.closePath(); ctx.fill();
    } else if (div === 'per_chevron') {
      ctx.beginPath();
      ctx.moveTo(x - 1, y + h + 1); ctx.lineTo(x + w / 2, y + h * 0.34);
      ctx.lineTo(x + w + 1, y + h + 1); ctx.closePath(); ctx.fill();
    } else if (div === 'quarterly') {
      ctx.fillRect(x + w / 2, y - 1, w / 2 + 2, h * 0.47);
      ctx.fillRect(x - 1, y + h * 0.46, w / 2 + 1, h * 0.6);
    }
  }

  /* The charges. Each is drawn into a unit box (0..1) and scaled, so a
     charge reads the same on a 22px roster sigil and a 96px crest. */
  var CHARGE = {
    lion: function (ctx) {
      /* a lion rampant, reduced to the silhouette a seal would carry */
      ctx.beginPath();
      ctx.moveTo(.30, .92); ctx.lineTo(.34, .62); ctx.lineTo(.24, .50);
      ctx.quadraticCurveTo(.20, .34, .34, .26);
      ctx.lineTo(.36, .14); ctx.lineTo(.46, .22);
      ctx.quadraticCurveTo(.58, .16, .64, .26);
      ctx.lineTo(.78, .22); ctx.lineTo(.70, .34);
      ctx.quadraticCurveTo(.80, .48, .70, .60);
      ctx.lineTo(.74, .92); ctx.lineTo(.64, .92); ctx.lineTo(.60, .70);
      ctx.lineTo(.46, .72); ctx.lineTo(.42, .92);
      ctx.closePath(); ctx.fill();
      /* the tail */
      ctx.lineWidth = .055; ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(.72, .58);
      ctx.quadraticCurveTo(.94, .52, .86, .28);
      ctx.stroke();
    },
    cross: function (ctx) {
      ctx.fillRect(.42, .10, .16, .78);
      ctx.fillRect(.14, .38, .72, .16);
    },
    chevron: function (ctx) {
      ctx.beginPath();
      ctx.moveTo(.06, .78); ctx.lineTo(.50, .24); ctx.lineTo(.94, .78);
      ctx.lineTo(.78, .78); ctx.lineTo(.50, .44); ctx.lineTo(.22, .78);
      ctx.closePath(); ctx.fill();
    },
    roundels: function (ctx) {
      var pts = [[.30, .28], [.70, .28], [.30, .62], [.70, .62], [.50, .45]];
      for (var i = 0; i < pts.length; i++) {
        ctx.beginPath();
        ctx.arc(pts[i][0], pts[i][1], .115, 0, Math.PI * 2);
        ctx.fill();
      }
    },
    crescent: function (ctx) {
      ctx.beginPath();
      ctx.arc(.50, .48, .34, 0, Math.PI * 2);
      ctx.arc(.62, .40, .28, 0, Math.PI * 2, true);
      ctx.fill('evenodd');
    },
    mullet: function (ctx) {
      ctx.beginPath();
      for (var i = 0; i < 10; i++) {
        var a = -Math.PI / 2 + i * Math.PI / 5;
        var rr = i % 2 ? .16 : .38;
        var px = .50 + Math.cos(a) * rr, py = .48 + Math.sin(a) * rr;
        i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
      }
      ctx.closePath(); ctx.fill();
    },
    tower: function (ctx) {
      ctx.fillRect(.30, .34, .40, .54);
      ctx.fillRect(.26, .22, .10, .16);
      ctx.fillRect(.45, .22, .10, .16);
      ctx.fillRect(.64, .22, .10, .16);
      ctx.save();
      ctx.globalCompositeOperation = 'destination-out';
      ctx.fillRect(.44, .58, .12, .30);
      ctx.restore();
    },
    lances: function (ctx) {
      ctx.lineWidth = .07; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(.22, .88); ctx.lineTo(.50, .14); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(.78, .88); ctx.lineTo(.50, .14); ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(.50, .06); ctx.lineTo(.58, .22); ctx.lineTo(.42, .22);
      ctx.closePath(); ctx.fill();
    },
    bend: function (ctx) {
      ctx.beginPath();
      ctx.moveTo(.04, .30); ctx.lineTo(.30, .04); ctx.lineTo(.96, .66);
      ctx.lineTo(.70, .92); ctx.closePath(); ctx.fill();
    },
    boar: function (ctx) {
      ctx.beginPath();
      ctx.moveTo(.14, .70); ctx.quadraticCurveTo(.10, .44, .34, .38);
      ctx.lineTo(.44, .24); ctx.lineTo(.52, .38);
      ctx.quadraticCurveTo(.84, .38, .88, .60);
      ctx.quadraticCurveTo(.90, .82, .70, .82);
      ctx.lineTo(.66, .92); ctx.lineTo(.58, .82);
      ctx.lineTo(.38, .82); ctx.lineTo(.34, .92); ctx.lineTo(.26, .82);
      ctx.quadraticCurveTo(.14, .82, .14, .70);
      ctx.closePath(); ctx.fill();
      /* the tusk */
      ctx.lineWidth = .04;
      ctx.beginPath(); ctx.moveTo(.20, .62); ctx.lineTo(.10, .54); ctx.stroke();
    }
  };

  /* Cadency marks — real heraldic practice, and the reason a third-
     generation knight's shield is legibly his father's coat. */
  var MARK = {
    label: function (ctx) {
      ctx.fillRect(.24, .10, .52, .08);
      ctx.fillRect(.29, .18, .08, .12);
      ctx.fillRect(.46, .18, .08, .12);
      ctx.fillRect(.63, .18, .08, .12);
    },
    crescent: function (ctx) {
      ctx.beginPath();
      ctx.arc(.50, .22, .13, 0, Math.PI * 2);
      ctx.arc(.55, .19, .105, 0, Math.PI * 2, true);
      ctx.fill('evenodd');
    },
    mullet: function (ctx) {
      ctx.beginPath();
      for (var i = 0; i < 10; i++) {
        var a = -Math.PI / 2 + i * Math.PI / 5;
        var rr = i % 2 ? .055 : .14;
        var px = .50 + Math.cos(a) * rr, py = .22 + Math.sin(a) * rr;
        i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
      }
      ctx.closePath(); ctx.fill();
    },
    martlet: function (ctx) {
      ctx.beginPath();
      ctx.moveTo(.36, .28); ctx.quadraticCurveTo(.44, .10, .62, .16);
      ctx.quadraticCurveTo(.70, .20, .64, .28);
      ctx.quadraticCurveTo(.52, .34, .36, .28);
      ctx.closePath(); ctx.fill();
    },
    annulet: function (ctx) {
      ctx.lineWidth = .05;
      ctx.beginPath(); ctx.arc(.50, .22, .11, 0, Math.PI * 2); ctx.stroke();
    },
    fleur: function (ctx) {
      ctx.beginPath();
      ctx.moveTo(.50, .08); ctx.quadraticCurveTo(.60, .18, .50, .32);
      ctx.quadraticCurveTo(.40, .18, .50, .08); ctx.closePath(); ctx.fill();
      ctx.fillRect(.36, .24, .28, .045);
    }
  };

  /* Draw a full coat of arms. `gen` (optional) adds the cadency mark. */
  function arms(ctx, x, y, w, h, her, gen) {
    ctx.save();
    shieldPath(ctx, x, y, w, h);
    ctx.save();
    ctx.clip();
    fillDivision(ctx, x, y, w, h, her.division, her.field.fill, her.charge.fill);

    /* the charge, in the opposing tincture, inset from the edge */
    var pad = w * 0.13;
    var cw = w - pad * 2, ch = h * 0.78 - pad;
    ctx.save();
    ctx.translate(x + pad, y + pad * 0.7);
    ctx.scale(cw, ch);
    ctx.fillStyle = her.charge.fill;
    ctx.strokeStyle = her.charge.fill;
    ctx.lineWidth = 0.05;
    /* On a divided field the charge would vanish into its own tincture,
       so a divided coat wears the ACCENT instead — still tincture-legal
       because the accent is always a colour and the charge sits over a
       metal half. */
    if (her.division !== 'plain') { ctx.fillStyle = her.accent.fill; ctx.strokeStyle = her.accent.fill; }
    (CHARGE[her.chargeShape] || CHARGE.cross)(ctx);
    ctx.restore();

    if (gen) {
      var m = MARK[Names.cadency(gen)];
      if (m) {
        ctx.save();
        ctx.translate(x + pad, y + pad * 0.7);
        ctx.scale(cw, ch);
        ctx.fillStyle = 'rgba(255,252,244,.92)';
        ctx.strokeStyle = 'rgba(255,252,244,.92)';
        ctx.lineWidth = 0.05;
        m(ctx);
        ctx.restore();
      }
    }

    /* the burnish: light from the upper left, shadow in the point */
    var g = ctx.createLinearGradient(x, y, x + w * 0.4, y + h);
    g.addColorStop(0, 'rgba(255,255,255,.26)');
    g.addColorStop(.42, 'rgba(255,255,255,0)');
    g.addColorStop(1, 'rgba(0,0,0,.24)');
    ctx.fillStyle = g;
    ctx.fillRect(x - 1, y - 1, w + 2, h + 2);
    ctx.restore();

    /* the rim */
    ctx.lineWidth = Math.max(1, w * 0.035);
    ctx.strokeStyle = 'rgba(30,22,12,.75)';
    ctx.stroke();
    ctx.restore();
  }

  /* Fill a whole canvas element with a House's arms. */
  function paintArms(cv, her, gen, cssW, cssH) {
    var w = cssW || parseFloat(cv.style.width) || cv.width;
    var h = cssH || parseFloat(cv.style.height) || cv.height;
    var ctx = fitCanvas(cv, w, h);
    ctx.clearRect(0, 0, w, h);
    var pad = Math.max(1, w * 0.06);
    arms(ctx, pad, pad * 0.6, w - pad * 2, h - pad * 1.4, her, gen);
    return ctx;
  }

  /* ===================================================================
     THE FIELD — units, in ink and in tincture.
     =================================================================== */

  /* A knight: barded horse in silhouette, shield in House colours, lance
     down. Drawn in a unit box so the board can size him freely. */
  function knightGlyph(ctx, s, her, opts) {
    var o = opts || {};
    ctx.save();
    ctx.translate(-s / 2, -s / 2);
    ctx.scale(s, s);

    if (o.dir && o.dir.dx < 0) { ctx.translate(1, 0); ctx.scale(-1, 1); }

    /* the destrier */
    ctx.fillStyle = o.dead ? 'rgba(36,26,16,.30)' : 'rgba(30,22,14,.88)';
    ctx.beginPath();
    ctx.moveTo(.16, .82);
    ctx.lineTo(.20, .58);
    ctx.quadraticCurveTo(.16, .44, .30, .40);
    ctx.lineTo(.62, .40);
    ctx.quadraticCurveTo(.74, .40, .76, .30);
    ctx.lineTo(.82, .18);
    ctx.lineTo(.90, .22);
    ctx.lineTo(.86, .38);
    ctx.quadraticCurveTo(.84, .50, .70, .54);
    ctx.lineTo(.72, .82);
    ctx.lineTo(.64, .82);
    ctx.lineTo(.60, .60);
    ctx.lineTo(.32, .60);
    ctx.lineTo(.26, .82);
    ctx.closePath();
    ctx.fill();

    /* the caparison — House colours over the horse */
    if (!o.dead) {
      ctx.fillStyle = her.field.fill;
      ctx.beginPath();
      ctx.moveTo(.26, .44); ctx.lineTo(.62, .44); ctx.lineTo(.58, .64);
      ctx.lineTo(.30, .64); ctx.closePath();
      ctx.fill();
      ctx.fillStyle = her.charge.fill;
      ctx.beginPath();
      ctx.moveTo(.44, .44); ctx.lineTo(.62, .44); ctx.lineTo(.58, .64);
      ctx.lineTo(.42, .64); ctx.closePath();
      ctx.fill();
    }

    /* the rider: helm, and the shield that carries his arms */
    ctx.fillStyle = o.dead ? 'rgba(36,26,16,.34)' : 'rgba(24,18,10,.92)';
    ctx.beginPath();
    ctx.arc(.46, .26, .10, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillRect(.40, .30, .14, .16);

    if (!o.dead) {
      ctx.save();
      shieldPath(ctx, .22, .26, .19, .24);
      ctx.clip();
      fillDivision(ctx, .22, .26, .19, .24, her.division, her.field.fill, her.charge.fill);
      ctx.restore();
      ctx.lineWidth = .018;
      ctx.strokeStyle = 'rgba(24,18,10,.8)';
      shieldPath(ctx, .22, .26, .19, .24);
      ctx.stroke();

      /* the lance, couched */
      ctx.strokeStyle = 'rgba(24,18,10,.9)';
      ctx.lineWidth = .032;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(.30, .34); ctx.lineTo(.96, .20); ctx.stroke();
      /* the pennon at the lance-head, in the charge tincture */
      ctx.fillStyle = her.charge.fill;
      ctx.beginPath();
      ctx.moveTo(.80, .225); ctx.lineTo(.92, .205); ctx.lineTo(.84, .28);
      ctx.closePath(); ctx.fill();
    }
    ctx.restore();
  }

  /* Foes are ink: this army has no heralds, only pikes. */
  function foeGlyph(ctx, s, kind, facing, opts) {
    var o = opts || {};
    ctx.save();
    ctx.translate(-s / 2, -s / 2);
    ctx.scale(s, s);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    var ink = o.doomed ? 'rgba(163,39,29,.85)' : 'rgba(30,22,14,.86)';
    ctx.fillStyle = ink;
    ctx.strokeStyle = ink;

    if (kind === 'wall') {
      /* a pikewall: four shafts locked, shields braced at the foot */
      ctx.lineWidth = .05;
      for (var i = 0; i < 4; i++) {
        var bx = .20 + i * .20;
        ctx.beginPath(); ctx.moveTo(bx, .84); ctx.lineTo(bx + .07, .22); ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(bx + .07, .12); ctx.lineTo(bx + .115, .26); ctx.lineTo(bx + .025, .26);
        ctx.closePath(); ctx.fill();
      }
      ctx.globalAlpha = .55;
      ctx.fillRect(.12, .70, .76, .14);
      ctx.globalAlpha = 1;
    } else if (kind === 'bow') {
      /* a crossbow, with its facing spelled out by the bolt in the groove */
      ctx.lineWidth = .055;
      ctx.save();
      var rot = { N: -Math.PI / 2, S: Math.PI / 2, E: 0, W: Math.PI }[facing || 'S'] || 0;
      ctx.translate(.5, .5); ctx.rotate(rot); ctx.translate(-.5, -.5);
      ctx.beginPath(); ctx.moveTo(.26, .50); ctx.lineTo(.78, .50); ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(.44, .22); ctx.quadraticCurveTo(.56, .50, .44, .78);
      ctx.stroke();
      ctx.lineWidth = .028;
      ctx.beginPath(); ctx.moveTo(.44, .24); ctx.lineTo(.44, .76); ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(.86, .50); ctx.lineTo(.74, .44); ctx.lineTo(.74, .56);
      ctx.closePath(); ctx.fill();
      ctx.restore();
    } else if (kind === 'captain') {
      /* the captain: a man, a plume, and a standard of his own */
      ctx.lineWidth = .05;
      ctx.beginPath(); ctx.arc(.42, .30, .105, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath();
      ctx.moveTo(.32, .42); ctx.lineTo(.52, .42); ctx.lineTo(.56, .82);
      ctx.lineTo(.28, .82); ctx.closePath(); ctx.fill();
      /* plume */
      ctx.fillStyle = 'rgba(163,39,29,.9)';
      ctx.beginPath();
      ctx.moveTo(.42, .19); ctx.quadraticCurveTo(.30, .06, .40, .02);
      ctx.quadraticCurveTo(.46, .10, .48, .19);
      ctx.closePath(); ctx.fill();
      /* standard */
      ctx.strokeStyle = ink; ctx.lineWidth = .04;
      ctx.beginPath(); ctx.moveTo(.72, .86); ctx.lineTo(.72, .16); ctx.stroke();
      ctx.fillStyle = 'rgba(30,22,14,.72)';
      ctx.beginPath();
      ctx.moveTo(.72, .18); ctx.lineTo(.94, .26); ctx.lineTo(.72, .38);
      ctx.closePath(); ctx.fill();
    } else {
      /* a pike: shaft, head, and a hand on it */
      ctx.lineWidth = .06;
      ctx.beginPath(); ctx.moveTo(.34, .88); ctx.lineTo(.56, .20); ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(.58, .06); ctx.lineTo(.68, .28); ctx.lineTo(.48, .26);
      ctx.closePath(); ctx.fill();
      ctx.globalAlpha = .5;
      ctx.beginPath(); ctx.arc(.42, .62, .075, 0, Math.PI * 2); ctx.fill();
      ctx.globalAlpha = 1;
    }
    ctx.restore();
  }

  /* The banner itself — the one thing the player places. */
  function bannerGlyph(ctx, s, alpha, sway) {
    ctx.save();
    ctx.globalAlpha = alpha == null ? 1 : alpha;
    ctx.translate(-s / 2, -s / 2);
    ctx.scale(s, s);
    ctx.strokeStyle = 'rgba(30,22,14,.9)';
    ctx.lineWidth = .045; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(.34, .94); ctx.lineTo(.34, .10); ctx.stroke();
    var w = .34 + Math.sin(sway || 0) * .05;
    var g = ctx.createLinearGradient(.34, 0, .34 + w + .3, 0);
    g.addColorStop(0, '#b8342a');
    g.addColorStop(1, '#7d1b14');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(.34, .12);
    ctx.lineTo(.34 + w + .3, .18 + Math.sin(sway || 0) * .02);
    ctx.lineTo(.34 + w + .16, .34);
    ctx.lineTo(.34 + w + .3, .50);
    ctx.lineTo(.34, .44);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = GOLD;
    ctx.beginPath(); ctx.arc(.34, .085, .045, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  /* ===================================================================
     THE BOARD — the map, its background cached, its actors live.
     =================================================================== */

  function Board(canvas) {
    this.cv = canvas;
    this.ctx = canvas.getContext('2d');
    this.bg = document.createElement('canvas');
    this.level = null;
    this.state = null;
    this.her = null;
    this.knightMeta = {};      /* id -> { gen, name, traits } */
    this.preview = null;       /* a resolve() result for the hovered tile */
    this.hover = null;
    this.anim = null;
    this.tile = 40;
    this.ox = 0; this.oy = 0;
    this.t0 = 0;
    this._raf = null;
    this._loop = this._loop.bind(this);
  }

  Board.prototype.setField = function (level, state, her, knightMeta) {
    this.level = level;
    this.state = state;
    this.her = her;
    this.knightMeta = knightMeta || {};
    this.preview = null;
    this.anim = null;
    this.layout();
  };

  Board.prototype.setState = function (state) { this.state = state; this.draw(); };

  /* Size to the box the CSS gave us, keeping tiles square and integral. */
  Board.prototype.layout = function () {
    if (!this.level) return;
    var box = this.cv.parentNode;
    var availW = Math.max(120, box.clientWidth - 4);
    var availH = Math.max(120, box.clientHeight - 4);
    var t = Math.floor(Math.min(availW / this.level.w, availH / this.level.h));
    t = Math.max(22, Math.min(t, 86));
    this.tile = t;
    var w = t * this.level.w, h = t * this.level.h;
    this.ctx = fitCanvas(this.cv, w, h);
    this.ox = 0; this.oy = 0;
    this.paintBackground(w, h);
    this.draw();
  };

  /* The map itself: vellum panel, pricked-and-ruled grid, hatched
     masonry, scattered caltrops, a gilded gate. Cached — it never moves. */
  Board.prototype.paintBackground = function (w, h) {
    var lv = this.level, t = this.tile;
    var dpr = Math.min(root.devicePixelRatio || 1, 2.5);
    this.bg.width = Math.round(w * dpr);
    this.bg.height = Math.round(h * dpr);
    var c = this.bg.getContext('2d');
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    var r = rng((lv.w * 73856093) ^ (lv.h * 19349663) ^ ((lv.foes.length + 1) * 83492791));

    /* the panel: the same calfskin, rubbed a shade darker where the map
       has been unrolled and re-rolled a hundred times */
    var g = c.createLinearGradient(0, 0, w * .3, h);
    g.addColorStop(0, '#e4d5b6');
    g.addColorStop(.5, '#dccaa7');
    g.addColorStop(1, '#d3bf9a');
    c.fillStyle = g;
    c.fillRect(0, 0, w, h);

    /* foxing — the little rust-coloured blooms old vellum grows */
    for (var i = 0; i < Math.round(w * h / 2600); i++) {
      var fx = r() * w, fy = r() * h, fr = 1 + r() * 3.4;
      c.globalAlpha = .05 + r() * .07;
      c.fillStyle = r() < .5 ? '#8a6a3a' : '#6d5a3c';
      c.beginPath(); c.arc(fx, fy, fr, 0, Math.PI * 2); c.fill();
    }
    c.globalAlpha = 1;

    /* the ruled grid, pricked at the intersections like a scribe's page */
    c.strokeStyle = 'rgba(36,26,16,.17)';
    c.lineWidth = 1;
    var x, y;
    for (x = 1; x < lv.w; x++) inkLine(c, x * t, 2, x * t, h - 2, r, 1.1);
    for (y = 1; y < lv.h; y++) inkLine(c, 2, y * t, w - 2, y * t, r, 1.1);
    c.fillStyle = 'rgba(36,26,16,.30)';
    for (x = 0; x <= lv.w; x++) {
      for (y = 0; y <= lv.h; y++) {
        c.beginPath(); c.arc(x * t, y * t, .9, 0, Math.PI * 2); c.fill();
      }
    }

    /* ------------------------------------------------------- THE DOWNS

       High ground, drawn the way a period map draws it: HACHURES — short
       strokes running DOWNHILL from the crest line, thick at the top and
       tapering out. It is the correct cartographic convention for this
       object on this surface, which is why it was chosen over a tint or a
       drop shadow: those say "a different tile", and hachures say "this
       ground is higher than that ground", which is the actual rule.

       Drawn UNDER the masonry, the caltrops and the gate, because terrain
       is beneath the things standing on it. */
    var ridge = lv.ridge || [];
    if (ridge.length) {
      var onRidge = {};
      for (var ri0 = 0; ri0 < ridge.length; ri0++) onRidge[ridge[ri0][0] + ',' + ridge[ri0][1]] = true;
      var high = function (rx, ry) { return !!onRidge[rx + ',' + ry]; };

      /* the plateau itself: a shade the light catches, laid down whole so
         the interior of a wide ridge has no seams between its tiles */
      for (var rj = 0; rj < ridge.length; rj++) {
        var rx0 = ridge[rj][0] * t, ry0 = ridge[rj][1] * t;
        c.fillStyle = 'rgba(198,166,112,.30)';
        c.fillRect(rx0, ry0, t, t);
      }

      /* the crest line and its hachures, edge by edge, outward = downhill */
      var EDGES = [
        { dx: 0, dy: -1, ax: 1, ay: 0 },   /* north face */
        { dx: 0, dy: 1, ax: 1, ay: 0 },    /* south face */
        { dx: -1, dy: 0, ax: 0, ay: 1 },   /* west face  */
        { dx: 1, dy: 0, ax: 0, ay: 1 }     /* east face  */
      ];
      for (var rk = 0; rk < ridge.length; rk++) {
        var gx0 = ridge[rk][0], gy0 = ridge[rk][1];
        for (var e = 0; e < EDGES.length; e++) {
          var ed = EDGES[e];
          if (high(gx0 + ed.dx, gy0 + ed.dy)) continue;   /* interior: no crest here */

          /* the edge runs from (ex,ey) along (ax,ay) for one tile */
          var ex = gx0 * t + (ed.dx > 0 ? t : 0) + (ed.dx === 0 ? 0 : 0);
          var ey = gy0 * t + (ed.dy > 0 ? t : 0);
          if (ed.dx < 0) ex = gx0 * t;
          if (ed.dy < 0) ey = gy0 * t;

          /* crest line: a firm ink stroke, the map's statement of height */
          c.strokeStyle = 'rgba(58,44,24,.60)';
          c.lineWidth = 1.6;
          c.beginPath();
          c.moveTo(ex, ey);
          c.lineTo(ex + ed.ax * t, ey + ed.ay * t);
          c.stroke();

          /* hachures: 5 per edge, downhill, tapering, jittered so the hill
             reads as drawn by a hand rather than stamped by a machine */
          c.strokeStyle = 'rgba(58,44,24,.42)';
          for (var hn = 0; hn < 5; hn++) {
            var f0 = (hn + .5) / 5 + (r() - .5) * .10;
            var px0 = ex + ed.ax * t * f0;
            var py0 = ey + ed.ay * t * f0;
            var len = t * (.14 + r() * .13);
            c.lineWidth = 1.5 - r() * .7;
            c.beginPath();
            c.moveTo(px0, py0);
            c.lineTo(px0 + ed.dx * len + ed.ax * (r() - .5) * 2.2,
                     py0 + ed.dy * len + ed.ay * (r() - .5) * 2.2);
            c.stroke();
          }
        }
      }
    }

    /* masonry: hatched blocks with an inked edge, never a filled square */
    for (var wi = 0; wi < lv.walls.length; wi++) {
      var wx = lv.walls[wi][0] * t, wy = lv.walls[wi][1] * t;
      c.save();
      c.beginPath();
      c.rect(wx + 1.5, wy + 1.5, t - 3, t - 3);
      c.fillStyle = 'rgba(58,46,32,.30)';
      c.fill();
      c.clip();
      c.strokeStyle = 'rgba(30,22,14,.42)';
      c.lineWidth = 1;
      for (var hx = -t; hx < t * 2; hx += 5) {
        c.beginPath();
        c.moveTo(wx + hx, wy - 2);
        c.lineTo(wx + hx + t + 4, wy + t + 2);
        c.stroke();
      }
      /* courses of stone */
      c.strokeStyle = 'rgba(24,18,10,.45)';
      c.lineWidth = 1.2;
      for (var cy = 1; cy < 3; cy++) {
        c.beginPath(); c.moveTo(wx, wy + (t / 3) * cy); c.lineTo(wx + t, wy + (t / 3) * cy); c.stroke();
      }
      c.beginPath();
      c.moveTo(wx + t / 2, wy); c.lineTo(wx + t / 2, wy + t / 3);
      c.moveTo(wx + t / 4, wy + t / 3); c.lineTo(wx + t / 4, wy + t * 2 / 3);
      c.moveTo(wx + t * 3 / 4, wy + t * 2 / 3); c.lineTo(wx + t * 3 / 4, wy + t);
      c.stroke();
      c.restore();
      c.strokeStyle = 'rgba(24,18,10,.62)';
      c.lineWidth = 1.4;
      c.strokeRect(wx + 1.5, wy + 1.5, t - 3, t - 3);
    }

    /* caltrops: four-point stars, scattered, never centred */
    for (var ci = 0; ci < lv.caltrops.length; ci++) {
      var cx0 = lv.caltrops[ci][0] * t, cy0 = lv.caltrops[ci][1] * t;
      c.fillStyle = 'rgba(30,22,14,.62)';
      for (var k = 0; k < 5; k++) {
        var px = cx0 + t * (.22 + r() * .56), py = cy0 + t * (.22 + r() * .56);
        var sz = t * .07;
        c.save();
        c.translate(px, py);
        c.rotate(r() * Math.PI);
        c.beginPath();
        c.moveTo(0, -sz); c.lineTo(sz * .3, -sz * .3); c.lineTo(sz, 0);
        c.lineTo(sz * .3, sz * .3); c.lineTo(0, sz); c.lineTo(-sz * .3, sz * .3);
        c.lineTo(-sz, 0); c.lineTo(-sz * .3, -sz * .3);
        c.closePath(); c.fill();
        c.restore();
      }
    }

    /* the gate: gold leaf, the only gilding on the map */
    if (lv.gate) {
      var gx = lv.gate[0] * t, gy = lv.gate[1] * t;
      c.save();
      c.translate(gx, gy);
      var gg = c.createLinearGradient(0, 0, 0, t);
      gg.addColorStop(0, 'rgba(220,174,78,.42)');
      gg.addColorStop(1, 'rgba(184,137,43,.18)');
      c.fillStyle = gg;
      c.fillRect(2, 2, t - 4, t - 4);
      c.strokeStyle = 'rgba(150,110,30,.85)';
      c.lineWidth = 2;
      c.beginPath();
      c.moveTo(t * .20, t * .88);
      c.lineTo(t * .20, t * .44);
      c.quadraticCurveTo(t * .50, t * .06, t * .80, t * .44);
      c.lineTo(t * .80, t * .88);
      c.stroke();
      c.lineWidth = 1;
      c.beginPath();
      c.moveTo(t * .50, t * .16); c.lineTo(t * .50, t * .88);
      c.stroke();
      c.restore();
    }

    /* the border the map was trimmed to */
    c.strokeStyle = 'rgba(36,26,16,.45)';
    c.lineWidth = 2;
    c.strokeRect(1, 1, w - 2, h - 2);
    c.strokeStyle = 'rgba(163,39,29,.22)';
    c.lineWidth = 1;
    c.strokeRect(4.5, 4.5, w - 9, h - 9);
  };

  Board.prototype.cell = function (px, py) {
    var t = this.tile;
    var x = Math.floor(px / t), y = Math.floor(py / t);
    if (!this.level || x < 0 || y < 0 || x >= this.level.w || y >= this.level.h) return null;
    return { x: x, y: y };
  };

  Board.prototype.centre = function (x, y) {
    return { x: x * this.tile + this.tile / 2, y: y * this.tile + this.tile / 2 };
  };

  /* --------------------------------------------------------- the drawing */

  Board.prototype.draw = function () {
    if (!this.level || !this.ctx) return;
    var ctx = this.ctx, t = this.tile;
    var w = t * this.level.w, h = t * this.level.h;
    ctx.clearRect(0, 0, w, h);
    ctx.drawImage(this.bg, 0, 0, w, h);

    var a = this.anim;
    if (a) this.drawAnimated(ctx, a);
    else this.drawStatic(ctx);
  };

  Board.prototype.drawStatic = function (ctx) {
    var self = this, t = this.tile, st = this.state, pv = this.preview;
    var i;

    /* the preview, UNDER the pieces: ghost tracks, then verdicts on top */
    if (pv && this.hover) {
      var pulse = 0.5 + 0.5 * Math.sin(Date.now() / 260);

      /* the tracks each knight would ride */
      ctx.save();
      ctx.lineWidth = Math.max(2, t * 0.10);
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.setLineDash([t * 0.16, t * 0.14]);
      ctx.lineDashOffset = -(Date.now() / 34) % (t * 0.30);
      for (i = 0; i < pv.riders.length; i++) {
        var r = pv.riders[i];
        if (r.path.length < 2) continue;
        ctx.strokeStyle = r.dead ? 'rgba(163,39,29,.42)' : 'rgba(36,26,16,.30)';
        ctx.beginPath();
        for (var p = 0; p < r.path.length; p++) {
          var c = this.centre(r.path[p].x, r.path[p].y);
          p ? ctx.lineTo(c.x, c.y) : ctx.moveTo(c.x, c.y);
        }
        ctx.stroke();
        /* the arrowhead where he ends up */
        var end = this.centre(r.x, r.y);
        ctx.setLineDash([]);
        ctx.fillStyle = r.dead ? 'rgba(163,39,29,.5)' : 'rgba(36,26,16,.36)';
        ctx.beginPath();
        ctx.arc(end.x, end.y, t * 0.09, 0, Math.PI * 2);
        ctx.fill();
        ctx.setLineDash([t * 0.16, t * 0.14]);
      }
      ctx.restore();

      /* the banner ghost, swaying, on the tile under the cursor */
      var bc = this.centre(this.hover.x, this.hover.y);
      ctx.save();
      ctx.translate(bc.x, bc.y);
      bannerGlyph(ctx, t * 0.9, 0.45 + pulse * 0.3, Date.now() / 320);
      ctx.restore();
    }

    /* foes */
    var doomed = {};
    if (pv) for (i = 0; i < pv.trampled.length; i++) doomed[pv.trampled[i].x + ',' + pv.trampled[i].y] = true;
    for (i = 0; i < st.foes.length; i++) {
      var f = st.foes[i];
      var fc = this.centre(f.x, f.y);
      ctx.save();
      ctx.translate(fc.x, fc.y);
      foeGlyph(ctx, t * 0.82, f.kind, f.facing, { doomed: doomed[f.x + ',' + f.y] });
      ctx.restore();
      if (doomed[f.x + ',' + f.y]) this.markKill(ctx, fc.x, fc.y, t);
    }

    /* knights */
    for (i = 0; i < st.knights.length; i++) {
      var k = st.knights[i];
      var kc = this.centre(k.x, k.y);
      var meta = this.knightMeta[k.id] || {};
      var pr = pv ? pv.riders.filter(function (rr) { return rr.id === k.id; })[0] : null;
      ctx.save();
      ctx.translate(kc.x, kc.y);
      knightGlyph(ctx, t * 0.88, this.her, { dir: pr ? pr.dir : null });
      ctx.restore();
      /* ⛔ THE NAMEPLATE AND THE FATE LABEL SHARE THE SAME BAND UNDER THE
         FIGURE, so drawing both overprints one on the other — measured by
         eye on shot_2_preview, where "Norbert" and a red "SHOT" landed on
         top of each other and neither was readable. The fate wins: WHO he
         is is already on his roster card (highlighted red) and in the
         verdict line under the board, while WHAT is about to happen to him
         exists only here. */
      var doomed = !!(pr && pr.dead);
      if (!doomed) this.nameplate(ctx, kc.x, kc.y, t, meta);
      if (doomed) this.markDeath(ctx, kc.x, kc.y, t, pr.stalled ? 'STALLED' : 'SHOT');
      if (pr && pr.saved) this.markSaved(ctx, kc.x, kc.y, t);
      if (pr && pr.refused) this.markRefused(ctx, kc.x, kc.y, t);
    }

    /* the bolts a preview promises — drawn faint, because they only fly
       if the field does not already end */
    if (pv && pv.bolts.length && !pv.won) {
      ctx.save();
      ctx.strokeStyle = 'rgba(163,39,29,.34)';
      ctx.lineWidth = Math.max(1.4, t * 0.05);
      ctx.setLineDash([t * 0.1, t * 0.1]);
      for (i = 0; i < pv.bolts.length; i++) {
        var b = pv.bolts[i];
        var b0 = this.centre(b.from.x, b.from.y), b1 = this.centre(b.to.x, b.to.y);
        ctx.beginPath(); ctx.moveTo(b0.x, b0.y); ctx.lineTo(b1.x, b1.y); ctx.stroke();
      }
      ctx.restore();
    }

    /* the captain's next step */
    if (pv && pv.captainMove && !pv.won) {
      var cm = this.centre(pv.captainMove.to.x, pv.captainMove.to.y);
      ctx.save();
      ctx.strokeStyle = 'rgba(163,39,29,.45)';
      ctx.lineWidth = 1.6;
      ctx.setLineDash([3, 3]);
      ctx.strokeRect(cm.x - t * 0.36, cm.y - t * 0.36, t * 0.72, t * 0.72);
      ctx.restore();
    }
  };

  Board.prototype.nameplate = function (ctx, cx, cy, t, meta) {
    if (!meta.name || t < 34) return;
    ctx.save();
    ctx.font = '600 ' + Math.max(7, Math.round(t * 0.17)) + 'px ' +
      "'Iowan Old Style','Palatino Linotype',Palatino,Georgia,serif";
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    var label = meta.name;
    var wq = ctx.measureText(label).width;
    ctx.fillStyle = 'rgba(233,220,192,.72)';
    roundRect(ctx, cx - wq / 2 - 3, cy + t * 0.30, wq + 6, t * 0.20 + 3, 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(36,26,16,.82)';
    ctx.fillText(label, cx, cy + t * 0.31);
    ctx.restore();
  };

  Board.prototype.markKill = function (ctx, cx, cy, t) {
    ctx.save();
    ctx.strokeStyle = 'rgba(163,39,29,.78)';
    ctx.lineWidth = Math.max(2, t * 0.07);
    ctx.lineCap = 'round';
    var s = t * 0.24;
    ctx.beginPath();
    ctx.moveTo(cx - s, cy - s); ctx.lineTo(cx + s, cy + s);
    ctx.moveTo(cx + s, cy - s); ctx.lineTo(cx - s, cy + s);
    ctx.stroke();
    ctx.restore();
  };

  Board.prototype.markDeath = function (ctx, cx, cy, t, why) {
    ctx.save();
    ctx.translate(cx, cy - t * 0.06);
    ctx.strokeStyle = RUBRIC;
    ctx.lineWidth = Math.max(2, t * 0.06);
    ctx.beginPath();
    ctx.arc(0, 0, t * 0.36, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillStyle = RUBRIC;
    ctx.font = '600 ' + Math.max(6, Math.round(t * 0.15)) + 'px ' +
      "'Iowan Old Style','Palatino Linotype',Palatino,Georgia,serif";
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    /* ⛔ KEEP THE LABEL INSIDE ITS OWN TILE. At 0.52t (measured from a centre
       already lifted by 0.06t) this sat BELOW the tile boundary and landed in
       the nameplate band of whoever stood on the next square down — the
       canvas-text gate caught it as "Berthe x STALLED" on a real field.
       0.34t puts it in the band the nameplate would have used, which is free
       here because a doomed rider draws no nameplate. Every mark now stays
       within its own square, so adjacency cannot produce an overprint. */
    /* ...on its own plate. Moving the label inside the tile put it on top of
       the rider's own dark figure, where rubric-on-black barely read — the
       collision was fixed and the LEGIBILITY was not, which a box-overlap
       gate cannot see and only looking at the frame catches. Same vellum
       plate the nameplate uses, so the two marks are visibly one family. */
    var label = why || 'DIES';
    var lw = ctx.measureText(label).width;
    ctx.fillStyle = 'rgba(233,220,192,.86)';
    roundRect(ctx, -lw / 2 - 3, t * 0.34 - Math.round(t * 0.15) * 0.62 - 2, lw + 6, Math.round(t * 0.15) * 1.24 + 4, 2);
    ctx.fill();
    ctx.fillStyle = RUBRIC;
    ctx.fillText(label, 0, t * 0.34);
    ctx.restore();
  };

  Board.prototype.markSaved = function (ctx, cx, cy, t) {
    ctx.save();
    ctx.strokeStyle = GOLD;
    ctx.lineWidth = Math.max(2, t * 0.055);
    ctx.beginPath();
    ctx.arc(cx, cy, t * 0.38, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  };

  Board.prototype.markRefused = function (ctx, cx, cy, t) {
    ctx.save();
    ctx.fillStyle = RUBRIC;
    ctx.font = 'italic 600 ' + Math.max(7, Math.round(t * 0.17)) + 'px ' +
      "'Iowan Old Style','Palatino Linotype',Palatino,Georgia,serif";
    ctx.textAlign = 'center';
    ctx.fillText('refuses', cx, cy - t * 0.40);
    ctx.restore();
  };

  /* ------------------------------------------------------- the animation */

  /* Play back exactly what resolve() returned. Three beats:
       ride (riders travel their real paths, trampling as they arrive)
       loose (crossbows answer)
       close (the captain steps)
     The caller gets a callback when the ink settles. */
  Board.prototype.play = function (result, done) {
    var self = this;
    /* When does each trampled foe leave the field? At the step the rider
       who killed it reached its tile. */
    var kills = result.trampled.map(function (tr) {
      var r = result.riders[tr.by];
      var at = 0;
      if (r) {
        for (var i = 0; i < r.path.length; i++) {
          if (r.path[i].x === tr.x && r.path[i].y === tr.y) { at = i; break; }
          at = i;   /* jumpTrample lands past it: use the last index reached */
        }
      }
      return { x: tr.x, y: tr.y, kind: tr.kind, at: at, by: tr.by };
    });
    var span = 1;
    result.riders.forEach(function (r) { span = Math.max(span, r.path.length - 1); });

    this.anim = {
      res: result,
      kills: kills,
      span: span,
      phase: 'ride',
      t: 0,
      rideMs: 190 + span * 105,
      looseMs: result.bolts.length ? 330 : 0,
      closeMs: result.captainMove ? 260 : 0,
      restMs: 420,
      done: done
    };
    this.preview = null;
    this.hover = null;
    this.t0 = 0;
    this.start();
  };

  Board.prototype.drawAnimated = function (ctx, a) {
    var t = this.tile, res = a.res, i;
    var ridePos = a.phase === 'ride' ? (a.t / a.rideMs) : 1;
    ridePos = Math.min(1, ridePos);
    /* ease-out: a charge is fastest at the start, and settles */
    var eased = 1 - Math.pow(1 - ridePos, 2.1);
    var travelled = eased * a.span;

    /* foes still standing at this instant */
    var gone = {};
    for (i = 0; i < a.kills.length; i++) {
      var kl = a.kills[i];
      var r = res.riders[kl.by];
      var rProgress = r ? Math.min(travelled, r.path.length - 1) : 0;
      if (a.phase !== 'ride' || rProgress >= kl.at - 0.15) gone[kl.x + ',' + kl.y] = true;
    }
    /* lanced foes fall when the ride ends */
    for (i = 0; i < res.riders.length; i++) {
      if (res.riders[i].lanced && (a.phase !== 'ride' || ridePos > 0.92)) {
        gone[res.riders[i].lanced.x + ',' + res.riders[i].lanced.y] = true;
      }
    }

    /* the captain, mid-step */
    var capFrom = res.captainMove ? res.captainMove.from : null;
    for (i = 0; i < this.state.foes.length; i++) {
      var f = this.state.foes[i];
      if (gone[f.x + ',' + f.y]) continue;
      var fx = f.x, fy = f.y, slide = 0;
      if (capFrom && f.kind === 'captain' && f.x === capFrom.x && f.y === capFrom.y) {
        if (a.phase === 'close') slide = Math.min(1, a.t / a.closeMs);
        else if (a.phase === 'rest') slide = 1;
      }
      var fc = this.centre(fx, fy);
      if (slide > 0 && res.captainMove) {
        var to = this.centre(res.captainMove.to.x, res.captainMove.to.y);
        var e = slide * slide * (3 - 2 * slide);
        fc = { x: fc.x + (to.x - fc.x) * e, y: fc.y + (to.y - fc.y) * e };
      }
      ctx.save();
      ctx.translate(fc.x, fc.y);
      foeGlyph(ctx, t * 0.82, f.kind, f.facing);
      ctx.restore();
    }

    /* the dust a trampled pike leaves */
    for (i = 0; i < a.kills.length; i++) {
      var k2 = a.kills[i];
      if (!gone[k2.x + ',' + k2.y]) continue;
      var kc = this.centre(k2.x, k2.y);
      var age = a.phase === 'ride' ? Math.max(0, travelled - k2.at) : 3;
      var fade = Math.max(0, 1 - age / 1.6);
      if (fade <= 0) continue;
      ctx.save();
      ctx.globalAlpha = fade * 0.5;
      ctx.strokeStyle = 'rgba(36,26,16,.6)';
      ctx.lineWidth = 2;
      for (var d = 0; d < 5; d++) {
        var ang = (d / 5) * Math.PI * 2 + age;
        var rad = t * (0.18 + age * 0.16);
        ctx.beginPath();
        ctx.arc(kc.x + Math.cos(ang) * rad, kc.y + Math.sin(ang) * rad, t * 0.05 * fade, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.restore();
    }

    /* the riders */
    for (i = 0; i < res.riders.length; i++) {
      var rd = res.riders[i];
      var idx = Math.min(travelled, rd.path.length - 1);
      var i0 = Math.floor(idx), i1 = Math.min(rd.path.length - 1, i0 + 1);
      var frac = idx - i0;
      var p0 = this.centre(rd.path[i0].x, rd.path[i0].y);
      var p1 = this.centre(rd.path[i1].x, rd.path[i1].y);
      var px = p0.x + (p1.x - p0.x) * frac;
      var py = p0.y + (p1.y - p0.y) * frac;
      var moving = idx < rd.path.length - 1;

      /* dies at the end of the ride, or when the bolt reaches him */
      var dying = false, deadAlpha = 1;
      if (rd.dead) {
        if (rd.stalled) {
          dying = a.phase !== 'ride' || ridePos > 0.86;
        } else if (rd.shot) {
          dying = a.phase === 'close' || a.phase === 'rest' ||
                  (a.phase === 'loose' && a.t / Math.max(1, a.looseMs) > 0.55);
        }
        if (dying) {
          var since = a.phase === 'rest' ? a.t / a.restMs : 0.25;
          deadAlpha = Math.max(0.18, 1 - since * 0.9);
        }
      }

      /* the gallop: a slight rise and fall while travelling */
      var bob = moving ? Math.sin(idx * Math.PI * 1.7) * t * 0.035 : 0;

      ctx.save();
      ctx.globalAlpha = deadAlpha;
      ctx.translate(px, py + bob);
      if (dying) ctx.rotate(0.5);
      knightGlyph(ctx, t * 0.88, this.her, { dir: rd.dir, dead: dying });
      ctx.restore();

      /* the dust of the charge itself */
      if (moving && rd.dist > 0) {
        ctx.save();
        ctx.globalAlpha = 0.20;
        ctx.fillStyle = 'rgba(60,46,30,.8)';
        for (var q = 1; q <= 3; q++) {
          var back = q * t * 0.22;
          var bx = px - (rd.dir ? rd.dir.dx : 0) * back;
          var by = py - (rd.dir ? rd.dir.dy : 0) * back;
          ctx.beginPath();
          ctx.arc(bx, by + t * 0.24, t * 0.05 * (4 - q) / 3, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      }

      if (dying) this.markKill(ctx, px, py, t);
    }

    /* the bolts */
    if ((a.phase === 'loose' || a.phase === 'close' || a.phase === 'rest') && res.bolts.length) {
      var bp = a.phase === 'loose' ? Math.min(1, a.t / Math.max(1, a.looseMs)) : 1;
      ctx.save();
      ctx.strokeStyle = 'rgba(163,39,29,.9)';
      ctx.lineWidth = Math.max(1.8, t * 0.06);
      ctx.lineCap = 'round';
      for (i = 0; i < res.bolts.length; i++) {
        var b = res.bolts[i];
        var s0 = this.centre(b.from.x, b.from.y), s1 = this.centre(b.to.x, b.to.y);
        var head = Math.min(1, bp * 1.5);
        var tail = Math.max(0, bp * 1.5 - 0.45);
        ctx.globalAlpha = bp < 1 ? 1 : Math.max(0, 1 - (a.phase !== 'loose' ? 0.7 : 0));
        ctx.beginPath();
        ctx.moveTo(s0.x + (s1.x - s0.x) * tail, s0.y + (s1.y - s0.y) * tail);
        ctx.lineTo(s0.x + (s1.x - s0.x) * head, s0.y + (s1.y - s0.y) * head);
        ctx.stroke();
      }
      ctx.restore();
    }

    /* the banner, planted, sitting under everything that just happened */
    var bc = this.centre(res.banner.x, res.banner.y);
    ctx.save();
    ctx.translate(bc.x, bc.y);
    bannerGlyph(ctx, t * 0.9, 0.9, a.t / 300);
    ctx.restore();
  };

  Board.prototype.start = function () {
    if (this._raf) return;
    this.t0 = 0;
    this._raf = root.requestAnimationFrame(this._loop);
  };

  Board.prototype.stop = function () {
    if (this._raf) root.cancelAnimationFrame(this._raf);
    this._raf = null;
  };

  Board.prototype._loop = function (ts) {
    this._raf = null;
    if (!this.t0) this.t0 = ts;
    var dt = Math.min(64, ts - this.t0);
    this.t0 = ts;

    var a = this.anim;
    if (a) {
      a.t += dt;
      var cap = a.phase === 'ride' ? a.rideMs
              : a.phase === 'loose' ? a.looseMs
              : a.phase === 'close' ? a.closeMs : a.restMs;
      if (a.t >= cap) {
        a.t = 0;
        a.phase = a.phase === 'ride' ? (a.looseMs ? 'loose' : (a.closeMs ? 'close' : 'rest'))
                : a.phase === 'loose' ? (a.closeMs ? 'close' : 'rest')
                : a.phase === 'close' ? 'rest'
                : 'over';
      }
      this.draw();
      if (a.phase === 'over') {
        var cb = a.done;
        this.anim = null;
        this.draw();
        if (cb) cb();
        return;
      }
      this._raf = root.requestAnimationFrame(this._loop);
      return;
    }

    /* idle: keep the preview's dashes marching and the banner swaying */
    if (this.preview && this.hover) {
      this.draw();
      this._raf = root.requestAnimationFrame(this._loop);
      return;
    }
    this.draw();
  };

  /* ===================================================================
     TITLE ART — the standard, hoisted, for the front page.
     =================================================================== */

  function paintStandard(cv, her, cssW, cssH) {
    var w = cssW, h = cssH;
    var ctx = fitCanvas(cv, w, h);
    ctx.clearRect(0, 0, w, h);
    var r = rng(her.seed ^ 0x5bf03635);

    /* the pole */
    ctx.strokeStyle = 'rgba(30,22,14,.85)';
    ctx.lineWidth = Math.max(3, w * 0.028);
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(w * 0.30, h * 0.97);
    ctx.lineTo(w * 0.30, h * 0.10);
    ctx.stroke();

    /* the finial, in gold */
    var fg = ctx.createLinearGradient(0, h * 0.02, 0, h * 0.12);
    fg.addColorStop(0, GOLD_LIT); fg.addColorStop(1, GOLD);
    ctx.fillStyle = fg;
    ctx.beginPath();
    ctx.moveTo(w * 0.30, h * 0.03);
    ctx.lineTo(w * 0.345, h * 0.10);
    ctx.lineTo(w * 0.30, h * 0.13);
    ctx.lineTo(w * 0.255, h * 0.10);
    ctx.closePath(); ctx.fill();

    /* the banner cloth, hanging with a real fold in it */
    var bw = w * 0.52, bh = h * 0.60;
    var bx = w * 0.30, by = h * 0.13;
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(bx, by);
    ctx.quadraticCurveTo(bx + bw * 0.5, by + h * 0.03, bx + bw, by + h * 0.015);
    ctx.lineTo(bx + bw, by + bh * 0.80);
    ctx.quadraticCurveTo(bx + bw * 0.72, by + bh * 0.94, bx + bw * 0.5, by + bh * 0.80);
    ctx.quadraticCurveTo(bx + bw * 0.28, by + bh * 0.66, bx, by + bh * 0.82);
    ctx.closePath();
    ctx.save();
    ctx.clip();
    fillDivision(ctx, bx, by, bw, bh, her.division, her.field.fill, her.charge.fill);
    ctx.save();
    ctx.translate(bx + bw * 0.16, by + bh * 0.10);
    ctx.scale(bw * 0.68, bh * 0.62);
    ctx.fillStyle = her.division !== 'plain' ? her.accent.fill : her.charge.fill;
    ctx.strokeStyle = ctx.fillStyle;
    ctx.lineWidth = 0.05;
    (CHARGE[her.chargeShape] || CHARGE.cross)(ctx);
    ctx.restore();
    /* the fold's shadow */
    var sg = ctx.createLinearGradient(bx, 0, bx + bw, 0);
    sg.addColorStop(0, 'rgba(0,0,0,.30)');
    sg.addColorStop(.18, 'rgba(0,0,0,0)');
    sg.addColorStop(.62, 'rgba(0,0,0,0)');
    sg.addColorStop(.78, 'rgba(0,0,0,.18)');
    sg.addColorStop(1, 'rgba(0,0,0,.02)');
    ctx.fillStyle = sg;
    ctx.fillRect(bx, by, bw, bh);
    ctx.restore();
    ctx.strokeStyle = 'rgba(30,22,14,.55)';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.restore();

    /* a small shield hung on the pole, so the coat reads twice */
    arms(ctx, w * 0.06, h * 0.60, w * 0.26, h * 0.30, her);

    /* ink flecks: the page has been handled */
    ctx.fillStyle = 'rgba(36,26,16,.18)';
    for (var i = 0; i < 26; i++) {
      ctx.beginPath();
      ctx.arc(r() * w, r() * h, r() * 1.2, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  root.Art = {
    INK: INK, RUBRIC: RUBRIC, GOLD: GOLD, VELLUM: VELLUM,
    rng: rng, fitCanvas: fitCanvas, roundRect: roundRect,
    arms: arms, paintArms: paintArms, shieldPath: shieldPath,
    knightGlyph: knightGlyph, foeGlyph: foeGlyph, bannerGlyph: bannerGlyph,
    paintStandard: paintStandard,
    Board: Board
  };

})(typeof window !== 'undefined' ? window : globalThis);

if (typeof module !== 'undefined' && module.exports) {
  module.exports = (typeof window !== 'undefined' ? window : globalThis).Art;
}
