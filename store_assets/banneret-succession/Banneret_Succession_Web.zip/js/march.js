/* =====================================================================
   march.js — BANNERET: SUCCESSION. The House, the march, the lineage.

   Everything above the battlefield lives here, and all of it is pure:
   no canvas, no storage, no Date, no Math.random. Randomness comes from
   a seeded generator whose state is saved WITH the run, so a reloaded
   march continues exactly — the save/resume rule is a design law of the
   whole lite track, and purity is how it is kept honest.

   THE HOUSE OUTLIVES THE MARCH. That is the game:

     · A march is one expedition: three acts of fields, route choices,
       musters and shrines, ending at the enemy's Standard.
     · Knights who die on a march are DEAD. Their heirs ride to the next
       muster carrying one inherited trait and one mutation — possibly a
       flaw. You choose: seat the heir, or pass the lance to an unproven
       recruit and end the line.
     · Defeat ends the march, never the House. Renown, lineage, unlocks
       and the chronicle persist. The checkpoint IS the House.

   RENOWN is the pacing spine (the complexity floor's "unlocks paced
   over time"): shrines, deeper trait pools and harder march tiers
   unlock as the House's name grows.
   ===================================================================== */
'use strict';

(function (root) {

  var Names = root.Names || (typeof require !== 'undefined' ? require('./names.js') : null);

  /* ------------------------------------------------------------ constants */

  var ROSTER_CAP = 5;
  var TRAIT_CAP = 3;

  var BASE_TRAITS = ['steady', 'ironshod', 'reckless', 'craven'];
  var UNLOCK_TRAITS = ['longlance', 'outrider'];
  var UNLOCK_TRAITS2 = ['hillman', 'shieldbearer'];
  var NEGATIVE = ['craven'];

  /* THE LADDER. v1.2 doubles it and interleaves the two spines so the
     House is always four or five fields from the next thing it has never
     had: a trait pool, then a new Order, then a harder march, then a
     deeper pool, and so on to renown 24. The four v1.1 thresholds keep
     their exact renown values, so a House loaded from an old save is at
     precisely the rung it went to sleep on. */
  var UNLOCKS = [
    { at: 3, id: 'shrine', label: 'Wayshrines appear on the march' },
    { at: 5, id: 'horn', kind: 'order', label: 'THE HORN — an Order: no knight stall-dies this charge' },
    { at: 6, id: 'traits', label: 'Deeper blood: longlance and outrider enter the lineage' },
    { at: 8, id: 'wheel', kind: 'order', label: 'THE WHEEL — an Order: ties break vertical this charge' },
    { at: 10, id: 'tier2', label: 'March II — the Marches of Iron' },
    { at: 12, id: 'rein', kind: 'order', label: 'THE REIN — an Order: one named knight holds his ground' },
    { at: 14, id: 'orders2', label: 'The banner-serjeant: a second Order each march' },
    { at: 16, id: 'tier3', label: 'March III — the Long Winter' },
    { at: 19, id: 'traits2', label: 'The old blood: hillman and shieldbearer enter the lineage' },
    { at: 24, id: 'orders3', label: 'The war-council: a third Order each march' }
  ];

  /* Which unlock ids are Orders, derived from the ladder rather than
     restated beside it — two lists that must agree is one list too many. */
  var ORDER_IDS = UNLOCKS.filter(function (u) { return u.kind === 'order'; })
                         .map(function (u) { return u.id; });

  var RENOWN = { field: 1, perfect: 1, captain: 2, march: 5 };

  var TIER_NAMES = ['', 'The Border March', 'The Marches of Iron', 'The Long Winter'];

  /* ----------------------------------------------------------------- rng */

  function nextRand(bag) {
    /* One step of mulberry32 with the state kept IN the save. */
    bag.rngState = (bag.rngState + 0x6D2B79F5) | 0;
    var t = bag.rngState;
    t = Math.imul(t ^ t >>> 15, 1 | t);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  }
  function randInt(bag, n) { return Math.floor(nextRand(bag) * n); }
  function pickFrom(bag, arr) { return arr[randInt(bag, arr.length)]; }

  /* --------------------------------------------------------------- house */

  function newHouse(seed) {
    var bag = { rngState: seed | 0 };
    var r = function () { return nextRand(bag); };
    var name = Names.houseName(r);
    var house = {
      v: 1,
      seed: seed | 0,
      rngState: bag.rngState,
      name: name,
      heraldrySeed: (seed * 2654435761) | 0,
      renown: 0,
      unlocked: {},                /* id -> true */
      roster: [],
      nextKnightId: 1,
      pendingHeirs: [],            /* deaths awaiting succession */
      graveyard: [],               /* the memorial */
      chronicle: ['House ' + name + ' raises its banner.'],
      stats: { marches: 0, victories: 0, fieldsWon: 0, perfects: 0, trampled: 0, captains: 0 }
    };
    /* The founding generation: three knights, one trait among them. */
    addKnight(house, 1, null);
    addKnight(house, 1, null);
    var third = addKnight(house, 1, null);
    third.traits = [pickFrom(house, ['steady', 'ironshod'])];
    return house;
  }

  function addKnight(house, gen, sire) {
    var r = function () { return nextRand(house); };
    var name = Names.knightName(r);
    /* Two living knights with one name reads as a bug, not as history.
       Re-roll on collision — seeded, so still deterministic per save. */
    var guard = 0;
    while (guard++ < 8 && house.roster.some(function (o) { return o.name === name; })) {
      name = Names.knightName(r);
    }
    var k = {
      id: house.nextKnightId++,
      name: name,
      epithet: nextRand(house) < 0.35 ? Names.epithet(r) : null,
      gen: gen,
      traits: [],
      sire: sire || null,          /* { name, gen, fate } */
      fieldsSurvived: 0
    };
    house.roster.push(k);
    return k;
  }

  function traitPool(house) {
    var pool = BASE_TRAITS.slice();
    if (house.unlocked.traits) pool = pool.concat(UNLOCK_TRAITS);
    if (house.unlocked.traits2) pool = pool.concat(UNLOCK_TRAITS2);
    return pool;
  }

  /* ---------------------------------------------------------- the orders

     Orders are the march's spendable stock: earned by renown, replenished
     at every muster, and spent one per charge. They are deliberately NOT
     per-field — a resource that refills every field is a button, and a
     button is not a decision. */

  function availableOrders(house) {
    return ORDER_IDS.filter(function (id) { return !!house.unlocked[id]; });
  }

  function orderCap(house) {
    if (!availableOrders(house).length) return 0;
    return 1 + (house.unlocked.orders2 ? 1 : 0) + (house.unlocked.orders3 ? 1 : 0);
  }

  /* A march made before an Order was ever unlocked has no `orders` field.
     Reading it as 0 would silently strip the stock off an in-flight save,
     so it is filled from the cap instead — the same shape as the unlock
     reconcile below, and for the same reason. */
  function ordersLeft(house, march) {
    if (!march) return 0;
    if (march.orders == null) march.orders = orderCap(house);
    return march.orders;
  }

  function spendOrder(house, march) {
    if (ordersLeft(house, march) <= 0) return false;
    march.orders--;
    return true;
  }

  function replenishOrders(house, march) {
    if (!march) return;
    march.orders = Math.max(march.orders || 0, orderCap(house));
  }

  /* MIGRATION — and the honest description of it, which is NOT the one
     first written here. The first version of this comment claimed a v1.1
     House would be "permanently missing three rungs it had already paid
     for". That is FALSE, and the control test beside it (march_v12) went
     red and proved it: `grantRenown` tests `house.renown >= u.at` against
     the RUNNING TOTAL, not against the delta it was handed, so it already
     sweeps the whole ladder on every call and a returning House would
     collect the new rungs the next time it won anything.

     What the reconcile actually buys is the gap before that: at LOAD the
     House would show no Orders bar, no order stock, and `newMarch` would
     stamp `orders: orderCap(house)` = 0 onto a march begun before the
     first win. Correct one field later is still wrong on the screen the
     player is looking at. So: reconcile on load, and hand the caller the
     list so it can say what he woke up holding. */
  function reconcileUnlocks(house) {
    if (!house) return [];
    if (!house.unlocked) house.unlocked = {};
    var newly = [];
    UNLOCKS.forEach(function (u) {
      if (house.renown >= u.at && !house.unlocked[u.id]) {
        house.unlocked[u.id] = true;
        newly.push(u);
      }
    });
    return newly;
  }

  function knightTitle(k) {
    return 'Ser ' + k.name + (k.epithet ? ' ' + k.epithet : '');
  }

  /* ---------------------------------------------------------- succession */

  /* A death on the field. The knight leaves the roster; an heir claim is
     queued for the next muster. Fate is a short human line for the
     memorial ("fell to the pikes at the Weeping Ford"). */
  function recordDeath(house, march, knightId, fate) {
    var i = house.roster.findIndex(function (k) { return k.id === knightId; });
    if (i < 0) return;
    var dead = house.roster.splice(i, 1)[0];
    house.graveyard.push({
      name: knightTitle(dead), gen: dead.gen, traits: dead.traits.slice(),
      fate: fate, march: house.stats.marches
    });
    house.pendingHeirs.push({
      sireName: knightTitle(dead), sireGen: dead.gen,
      sireTraits: dead.traits.slice(), fate: fate
    });
    var mi = march ? march.rosterIds.indexOf(knightId) : -1;
    if (mi >= 0) march.rosterIds.splice(mi, 1);
    house.chronicle.push(knightTitle(dead) + ' ' + fate + '.');
  }

  /* Build the heir a pending death produces. One inherited trait from the
     sire (if any), plus one mutation from the pool — which can be a flaw.
     The mutation roll is where lineage gets interesting: */
  function makeHeir(house, pending) {
    var r = function () { return nextRand(house); };
    var traits = [];
    if (pending.sireTraits.length > 0) {
      traits.push(pickFrom(house, pending.sireTraits));
    }
    if (nextRand(house) < 0.75) {                    /* 75%: the blood tells */
      var pool = traitPool(house).filter(function (t) { return traits.indexOf(t) < 0; });
      if (pool.length > 0) {
        /* flaws breed true: a craven line begets craven sons more often */
        var flawBias = pending.sireTraits.indexOf('craven') >= 0 ? 0.35 : 0.18;
        var flaws = pool.filter(function (t) { return NEGATIVE.indexOf(t) >= 0; });
        var virtues = pool.filter(function (t) { return NEGATIVE.indexOf(t) < 0; });
        var m = (flaws.length && nextRand(house) < flawBias) ? pickFrom(house, flaws)
              : (virtues.length ? pickFrom(house, virtues) : null);
        if (m) traits.push(m);
      }
    }
    return {
      name: Names.knightName(r),
      epithet: null,
      gen: pending.sireGen + 1,
      traits: traits.slice(0, TRAIT_CAP),
      sire: { name: pending.sireName, gen: pending.sireGen, fate: pending.fate }
    };
  }

  /* The muster's succession choices: for every pending death, the heir —
     already rolled, shown honestly — or an unproven recruit (no traits,
     no lineage, generation 1). Rolled ONCE and stored, so reloading the
     save cannot reroll a bad mutation. */
  function musterChoices(house) {
    if (house.musterOffers) return house.musterOffers;
    var offers = house.pendingHeirs.map(function (p) {
      return { pending: p, heir: makeHeir(house, p) };
    });
    /* An under-strength House also gets one recruit offer per muster. */
    var slots = ROSTER_CAP - house.roster.length - offers.length;
    var recruit = null;
    if (slots > 0) {
      recruit = { name: Names.knightName(function () { return nextRand(house); }), gen: 1, traits: [] };
    }
    house.musterOffers = { offers: offers, recruit: recruit, taken: [] };
    return house.musterOffers;
  }

  /* choice: 'heir' seats the rolled heir; 'lance' passes the lance to a
     fresh recruit and ends the line. */
  function applyMusterChoice(house, offerIndex, choice) {
    var mo = house.musterOffers;
    if (!mo || !mo.offers[offerIndex] || mo.taken.indexOf(offerIndex) >= 0) return null;
    var offer = mo.offers[offerIndex];
    mo.taken.push(offerIndex);
    var pi = house.pendingHeirs.indexOf(offer.pending);
    if (pi >= 0) house.pendingHeirs.splice(pi, 1);
    var k;
    if (choice === 'heir') {
      k = addKnight(house, offer.heir.gen, offer.heir.sire);
      k.name = offer.heir.name;
      k.traits = offer.heir.traits.slice();
      house.chronicle.push(knightTitle(k) + ', ' + ordinal(k.gen) + ' of the line, takes up the banner of ' + offer.pending.sireName + '.');
    } else {
      k = addKnight(house, 1, null);
      house.chronicle.push('The line of ' + offer.pending.sireName + ' ends. ' + knightTitle(k) + ' is given the lance.');
    }
    return k;
  }

  function takeRecruit(house) {
    var mo = house.musterOffers;
    if (!mo || !mo.recruit || mo.recruitTaken) return null;
    mo.recruitTaken = true;
    var k = addKnight(house, 1, null);
    k.name = mo.recruit.name;
    house.chronicle.push(knightTitle(k) + ' swears to the banner.');
    return k;
  }

  /* The muster is where the column re-forms, so it is also where the
     Orders come back. `march` is optional: the tests and the old call
     shape pass only the house, and a muster with no march is a no-op. */
  function closeMuster(house, march) {
    house.musterOffers = null;
    if (march) replenishOrders(house, march);
  }

  function ordinal(n) {
    return n === 1 ? 'first' : n === 2 ? 'second' : n === 3 ? 'third' :
           n === 4 ? 'fourth' : n === 5 ? 'fifth' : n + 'th';
  }

  /* --------------------------------------------------------------- march */

  /* The graph is five steps per act; each step offers one or two nodes.
     Musters open every act (succession must happen SOON after a death —
     the design beat the whole game is named for). Shrines appear only
     once unlocked; before that the fork offers battles both ways. */
  function actPlan(house, act, tier) {
    var shrineOk = !!house.unlocked.shrine;
    var mid = act === 3 && shrineOk ? ['shrine', 'muster'] : (shrineOk ? ['shrine', 'battle'] : ['battle', 'ambush']);
    return [
      [{ type: 'muster' }],
      twoOf(house, ['battle', 'battle', 'ambush']),
      mid.map(function (t) { return { type: t }; }),
      twoOf(house, ['ambush', 'battle', 'battle']),
      [{ type: act === 3 ? 'final' : 'captain' }]
    ];
  }
  function twoOf(house, types) {
    var a = pickFrom(house, types);
    var b = pickFrom(house, types.filter(function (t) { return t !== a; }));
    return [{ type: a }, { type: b }];
  }

  function newMarch(house, tier) {
    tier = tier || 1;
    house.stats.marches++;
    var march = {
      v: 1,
      tier: tier,
      rngState: (house.rngState ^ (house.stats.marches * 7919)) | 0,
      act: 1, step: 0,
      graph: null,                 /* filled per act, uses march rng */
      rosterIds: house.roster.map(function (k) { return k.id; }).slice(0, ROSTER_CAP),
      usedFields: [],
      fieldsWon: 0, perfects: 0,
      boons: { budget: 0 },        /* farrier's blessing: +1 budget, N fields */
      orders: orderCap(house),     /* the spendable stock, refilled at every muster */
      node: null,                  /* the active node instance */
      fieldLive: null              /* mid-field serialized state */
    };
    march.graph = actPlan(house, 1, tier);
    house.chronicle.push(TIER_NAMES[tier] + ' begins — march the ' + house.stats.marches + '.');
    return march;
  }

  function options(march) {
    return march.graph[march.step] || [];
  }

  /* -------------------------------------------------------------- fields */

  /* Field selection: seeded, no repeats within a march, pool keyed by
     tier + act + node type. FIELDS comes from fields.js (generated
     offline, every entry carrying a solver proof). */
  function poolKey(march, type) {
    if (type === 'final') return 't' + march.tier + '_final';
    if (type === 'captain') return 't' + march.tier + '_captain' + march.act;
    return 't' + march.tier + '_a' + march.act + '_' + type;
  }

  function pickField(march, FIELDS, type) {
    var kk = poolKey(march, type);
    var pool = FIELDS.pools[kk] || [];
    if (pool.length === 0) return null;
    var fresh = [];
    for (var i = 0; i < pool.length; i++) {
      if (march.usedFields.indexOf(kk + ':' + i) < 0) fresh.push(i);
    }
    var idx = fresh.length ? fresh[randInt(march, fresh.length)] : randInt(march, pool.length);
    march.usedFields.push(kk + ':' + idx);
    return { key: kk, index: idx, data: pool[idx] };
  }

  function choose(march, house, FIELDS, optIndex) {
    var opt = options(march)[optIndex];
    if (!opt) return null;
    var node = { type: opt.type, act: march.act, step: march.step };
    if (opt.type === 'battle' || opt.type === 'ambush' || opt.type === 'captain' || opt.type === 'final') {
      node.field = pickField(march, FIELDS, opt.type);
      /* farrier's blessing spends itself */
      if (march.boons.budget > 0) {
        node.budgetBonus = 1;
        march.boons.budget--;
      }
    }
    march.node = node;
    return node;
  }

  /* The roster as the resolver wants it, in march order. */
  function fieldRoster(house, march) {
    return march.rosterIds.map(function (id) {
      var k = house.roster.find(function (x) { return x.id === id; });
      return k ? { id: k.id, traits: k.traits } : null;
    }).filter(Boolean);
  }

  /* ------------------------------------------------------ field outcomes */

  function fieldWon(house, march, summary) {
    /* summary: { moves, minMoves, trampled, captainFell, deaths:[{id,fate}] } */
    march.fieldsWon++;
    house.stats.fieldsWon++;
    house.stats.trampled += summary.trampled || 0;
    var gained = RENOWN.field;
    var perfect = summary.minMoves != null && summary.moves <= summary.minMoves;
    if (perfect) { march.perfects++; house.stats.perfects++; gained += RENOWN.perfect; }
    if (summary.captainFell) { house.stats.captains++; gained += RENOWN.captain; }
    (summary.deaths || []).forEach(function (d) { recordDeath(house, march, d.id, d.fate); });
    march.rosterIds.forEach(function (id) {
      var k = house.roster.find(function (x) { return x.id === id; });
      if (k) k.fieldsSurvived++;
    });
    var unlocks = grantRenown(house, gained);
    march.node = null;
    march.fieldLive = null;
    return { renown: gained, perfect: perfect, unlocks: unlocks };
  }

  /* Defeat ends the march, never the House. */
  function marchLost(house, march, why, deaths) {
    (deaths || []).forEach(function (d) { recordDeath(house, march, d.id, d.fate); });
    house.chronicle.push('The march fails — ' + why + '. The House endures.');
    return { renownKept: true };
  }

  function marchWon(house, march) {
    house.stats.victories++;
    var unlocks = grantRenown(house, RENOWN.march);
    house.chronicle.push('VICTORY. The enemy Standard is cast down. Renown to House ' + house.name + '.');
    return { renown: RENOWN.march, unlocks: unlocks };
  }

  function grantRenown(house, n) {
    house.renown += n;
    var newly = [];
    UNLOCKS.forEach(function (u) {
      if (house.renown >= u.at && !house.unlocked[u.id]) {
        house.unlocked[u.id] = true;
        newly.push(u);
        house.chronicle.push('(' + u.label + ')');
      }
    });
    return newly;
  }

  function advance(march, house) {
    march.step++;
    if (march.step >= march.graph.length) {
      if (march.act >= 3) return 'won';
      march.act++;
      march.step = 0;
      march.graph = actPlan(house, march.act, march.tier);
    }
    return 'going';
  }

  function maxTier(house) {
    return house.unlocked.tier3 ? 3 : house.unlocked.tier2 ? 2 : 1;
  }

  /* -------------------------------------------------------------- shrine */

  function shrineOffers(house, march) {
    if (march.node && march.node.offers) return march.node.offers;
    var all = [
      { id: 'cleanse', label: 'The Confessor', text: 'A named flaw is forgiven: choose a knight and strike a flaw from his blood.' },
      { id: 'bless', label: 'The Anointing', text: 'Choose a knight; the shrine grants him a virtue of the old blood.' },
      { id: 'farrier', label: "The Farrier's Rite", text: 'Fresh horses: one extra charge on each of the next two fields.' }
    ];
    /* The Quartermaster only exists once the House has Orders to carry —
       an offer you cannot spend is a wasted fork, not a hard choice. */
    if (orderCap(house) > 0) {
      all.push({ id: 'quartermaster', label: 'The Quartermaster', text: 'The baggage train is opened: two more Orders for this march.' });
    }
    var a = randInt(march, all.length);
    var b = (a + 1 + randInt(march, all.length - 1)) % all.length;
    march.node.offers = [all[a], all[b]];
    return march.node.offers;
  }

  function applyShrine(house, march, offerId, knightId) {
    if (offerId === 'farrier') {
      march.boons.budget += 2;
      house.chronicle.push('The Farrier shoes the column in silence.');
      return true;
    }
    if (offerId === 'quartermaster') {
      march.orders = ordersLeft(house, march) + 2;
      house.chronicle.push('The Quartermaster opens the baggage train.');
      return true;
    }
    var k = house.roster.find(function (x) { return x.id === knightId; });
    if (!k) return false;
    if (offerId === 'cleanse') {
      var fi = -1;
      for (var i = 0; i < k.traits.length; i++) if (NEGATIVE.indexOf(k.traits[i]) >= 0) fi = i;
      if (fi < 0) return false;
      var gone = k.traits.splice(fi, 1)[0];
      house.chronicle.push(knightTitle(k) + ' is shriven of "' + gone + '".');
      return true;
    }
    if (offerId === 'bless') {
      var pool = traitPool(house).filter(function (t) {
        return NEGATIVE.indexOf(t) < 0 && k.traits.indexOf(t) < 0;
      });
      if (!pool.length || k.traits.length >= TRAIT_CAP) return false;
      var t = pickFrom(march, pool);
      k.traits.push(t);
      house.chronicle.push(knightTitle(k) + ' rises anointed: "' + t + '".');
      return true;
    }
    return false;
  }

  /* ---------------------------------------------------------------- save */

  var SAVE_KEY = 'banneret_succession_v1';

  function serialize(house, march) {
    return JSON.stringify({ v: 1, house: house, march: march });
  }
  function deserialize(str) {
    try {
      var d = JSON.parse(str);
      if (!d || d.v !== 1 || !d.house) return null;
      /* The v1.1 -> v1.2 migration, run on the way IN so nothing
         downstream ever sees an un-reconciled House. Returned as
         `granted` so the caller can tell the player what he woke up
         holding — a silent upgrade reads as a bug. */
      d.granted = reconcileUnlocks(d.house);
      if (d.march) ordersLeft(d.house, d.march);
      return d;
    } catch (e) { return null; }
  }

  var API = {
    ROSTER_CAP: ROSTER_CAP, TRAIT_CAP: TRAIT_CAP,
    UNLOCKS: UNLOCKS, RENOWN: RENOWN, TIER_NAMES: TIER_NAMES,
    NEGATIVE: NEGATIVE, ORDER_IDS: ORDER_IDS,
    availableOrders: availableOrders, orderCap: orderCap,
    ordersLeft: ordersLeft, spendOrder: spendOrder,
    replenishOrders: replenishOrders, reconcileUnlocks: reconcileUnlocks,
    newHouse: newHouse, addKnight: addKnight, knightTitle: knightTitle,
    traitPool: traitPool,
    recordDeath: recordDeath, musterChoices: musterChoices,
    applyMusterChoice: applyMusterChoice, takeRecruit: takeRecruit,
    closeMuster: closeMuster,
    newMarch: newMarch, options: options, choose: choose,
    fieldRoster: fieldRoster, fieldWon: fieldWon,
    marchLost: marchLost, marchWon: marchWon, advance: advance,
    maxTier: maxTier, grantRenown: grantRenown,
    shrineOffers: shrineOffers, applyShrine: applyShrine,
    SAVE_KEY: SAVE_KEY, serialize: serialize, deserialize: deserialize
  };

  root.March = API;

})(typeof window !== 'undefined' ? window : globalThis);

if (typeof module !== 'undefined' && module.exports) {
  module.exports = (typeof window !== 'undefined' ? window : globalThis).March;
}
