/* =====================================================================
   names.js — BANNERET: SUCCESSION. Names and heraldry, out of a seed.

   Everything here is DATA GENERATION, deterministic from a seed:
   knight names, house names, epithets, and the parameters of a coat of
   arms. The drawing of the arms happens in game.js; this file only
   decides what they are, so the same House looks the same forever and
   the tests can assert on it.

   The heraldry is the factory's answer to Gate 1: infinite art out of
   code. No two Houses bear the same arms; every knight differences his
   father's coat with a cadency mark, which is — conveniently — real
   heraldic practice.
   ===================================================================== */
'use strict';

(function (root) {

  /* mulberry32 — small, seedable, good enough for cosmetics and for the
     march's field picks. NOT crypto, obviously. */
  function rng(seed) {
    var a = seed >>> 0;
    return function () {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      var t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }

  function pick(r, arr) { return arr[Math.floor(r() * arr.length)]; }

  /* --------------------------------------------------------------- names */

  var GIVEN = [
    'Aldric', 'Berenger', 'Corbin', 'Draven', 'Edmund', 'Fulk', 'Gerold',
    'Hamon', 'Ivo', 'Jocelin', 'Kester', 'Lambert', 'Maynard', 'Norbert',
    'Odo', 'Percival', 'Quentin', 'Ranulf', 'Simund', 'Thibaut', 'Ulric',
    'Vespasian', 'Walter', 'Ysembard', 'Anselm', 'Bertram', 'Clarembald',
    'Drogo', 'Eustace', 'Frederic', 'Guyon', 'Herluin', 'Isembart',
    'Aveline', 'Berthe', 'Clemence', 'Douce', 'Emma', 'Fressenda',
    'Gunnor', 'Hawise', 'Isabel', 'Judith', 'Mabel', 'Nesta', 'Orielde',
    'Petronilla', 'Rohese', 'Sibyl', 'Tiphaine', 'Ymma'
  ];

  var HOUSE = [
    'Fenwick', 'Harrowgate', 'Vexley', 'Mortemer', 'Ashcombe', 'Blackmoor',
    'Caradine', 'Dunhelm', 'Elsmere', 'Farrowmark', 'Grimsby', 'Hollowmere',
    'Ironfield', 'Kestrel', 'Lanyon', 'Marchmain', 'Netherby', 'Oxcroft',
    'Pellinore', 'Quarrell', 'Ravensworth', 'Severne', 'Thornhaugh',
    'Umberlee', 'Vane', 'Wolfram', 'Yarrow', 'Aldermere', 'Briarwood',
    'Coldwater', 'Draycott', 'Everbright'
  ];

  var EPITHET = [
    'the Steadfast', 'the Grim', 'the Younger', 'the Elder', 'Ironhand',
    'the Quiet', 'the Red', 'Oakenshield', 'the Lame', 'Longstride',
    'the Pious', 'Half-Lance', 'the Unbowed', 'Stormborn', 'the Patient',
    'Wallbreaker', 'the Gallant', 'Nine-Fingers', 'the Dour', 'Highhelm'
  ];

  /* Cadency marks, in birth order — the real system. A first son bears the
     label, a second the crescent, and so on. Generations wrap. */
  var CADENCY = ['label', 'crescent', 'mullet', 'martlet', 'annulet', 'fleur'];

  function knightName(r) { return pick(r, GIVEN); }
  function houseName(r) { return pick(r, HOUSE); }
  function epithet(r) { return pick(r, EPITHET); }

  /* ------------------------------------------------------------- heraldry

     A coat is: a field DIVISION, two TINCTURES drawn honestly from the
     rule of tincture (metal on colour, never metal on metal), and an
     ORDINARY or CHARGE. game.js knows how to draw each named part. */

  var METALS = [
    { id: 'or', fill: '#d9a930' },       /* gold  */
    { id: 'argent', fill: '#e8e3d5' }    /* silver */
  ];
  var COLOURS = [
    { id: 'gules', fill: '#a92b22' },    /* red    */
    { id: 'azure', fill: '#2e4a72' },    /* blue   */
    { id: 'sable', fill: '#2a2624' },    /* black  */
    { id: 'vert', fill: '#3d5c3a' },     /* green  */
    { id: 'purpure', fill: '#5c3a5c' }   /* purple */
  ];

  var DIVISIONS = ['plain', 'per_pale', 'per_fess', 'per_bend', 'per_chevron', 'quarterly'];
  var CHARGES = ['lion', 'cross', 'chevron', 'roundels', 'crescent', 'mullet', 'tower', 'lances', 'bend', 'boar'];

  function heraldry(seed) {
    var r = rng(seed >>> 0);
    var metal = pick(r, METALS);
    var colour = pick(r, COLOURS);
    var metalOnColour = r() < 0.5;
    return {
      seed: seed >>> 0,
      division: pick(r, DIVISIONS),
      /* field first, charge second — tincture rule respected either way */
      field: metalOnColour ? colour : metal,
      charge: metalOnColour ? metal : colour,
      chargeShape: pick(r, CHARGES),
      accent: pick(r, COLOURS.filter(function (c) { return c.id !== colour.id; }))
    };
  }

  /* A knight's personal arms: the House coat plus a cadency mark keyed to
     his generation. Drawing handles the mark; this just names it. */
  function cadency(gen) { return CADENCY[(gen - 1 + CADENCY.length * 8) % CADENCY.length]; }

  var API = {
    rng: rng, pick: pick,
    knightName: knightName, houseName: houseName, epithet: epithet,
    heraldry: heraldry, cadency: cadency,
    GIVEN: GIVEN, HOUSE: HOUSE
  };

  root.Names = API;

})(typeof window !== 'undefined' ? window : globalThis);

if (typeof module !== 'undefined' && module.exports) {
  module.exports = (typeof window !== 'undefined' ? window : globalThis).Names;
}
