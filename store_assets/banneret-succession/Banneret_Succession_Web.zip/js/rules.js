/* =====================================================================
   rules.js — BANNERET: SUCCESSION. The battle, as one pure function.

   A banneret is a knight who leads men under his own banner. That is the
   whole control scheme, inherited from BANNERET and still the point:

       Plant the banner. Every knight charges it at once.
       A charge that never started is a death.

   What SUCCESSION adds, all of it inside this file so it stays provable:

     TRAITS — knights are people now, and people are not interchangeable.
     A trait is a RULE MUTATION, never a stat bump. `ironshod` rides
     through the jam. `craven` refuses a defended banner and stands there,
     shaking, next to the pike that will kill him. Traits are inherited
     when a knight dies, which is the game the title promises.

     FOES — the pike learned new formations. A pikewall needs real
     momentum. A crossbow shoots back after the dust settles. A captain
     MOVES, one tile after every charge, which turns the puzzle into a
     fight. Caltrops end a gallop without a kill.

     OBJECTIVES — trample every foe, or break the captain and watch the
     rest run, or put one rider through the gate at full gallop.

   ---------------------------------------------------------------------
   V1.2 — THE DOWNS AND THE ORDERS. Two systems added on top of the
   above, both of which bend MOMENTUM, which is the currency every other
   rule in this file already spends. That is the point: they do not sit
   beside the game, they run through it.

     THE DOWNS — the ground is no longer flat. A field may carry `ridge`
     tiles: high ground. Two rules, and only two.

       CREST  — an impact made while riding DOWN off the ridge carries
                one extra tile of weight. A single tile of run, taken
                downhill, smashes a pikewall that needs two.
       CLIMB  — riding UP onto the ridge needs a run. From a standing
                start the horse balks at the bank and stops at the foot
                — which, beside a pike, is the stall rule and a death.

     Elevation therefore rewrites every momentum threshold in the file
     without adding a threshold of its own, and it makes the SHAPE of
     the ground a second question next to "where does the banner land".

     THE ORDERS — the spendable half. A march carries a small stock of
     Orders; one may ride with any plant, and it is resolved HERE so the
     hover preview shows it exactly, like everything else.

       horn  — the horn is sounded: no knight stall-dies this charge.
       wheel — the tie-break goes VERTICAL this charge, not horizontal.
       rein  — one named knight holds his ground and does not ride.

     Orders are the PLAYER's resource and never the field's crutch: the
     generator proves every field winnable by a plain, unhorned company,
     exactly as it already proves them winnable without traits.

   `resolve()` is pure — no canvas, no clock, no randomness. The field
   generator in Internal_Ops searches it exhaustively, so every shipped
   field is PROVEN winnable rather than hoped to be, and the hover preview
   in game.js is this exact function run against the tile under the
   cursor. What you are shown is what you get, by construction.
   ===================================================================== */
'use strict';

(function (root) {

  function key(x, y) { return x + ',' + y; }

  var ORTHO = [[1, 0], [-1, 0], [0, 1], [0, -1]];

  /* Foe kinds, and what momentum does to each.
       pike    — trampled at momentum >= 1. Kills a knight who stood still.
       wall    — a pikewall. Momentum >= 2 smashes through; exactly 1 tile
                 of momentum bounces off it and the rider stops short.
       bow     — a crossbow with a facing. Soft: trampled at momentum >= 1.
                 After every charge it puts one bolt down its line.
       captain — the first enemy that MOVES. Trampled at momentum >= 1,
                 but he steps one tile toward your nearest knight after
                 every charge, so he is never where he was.
     Every kind counts as "a pike" for the stall rule: a knight that moved
     zero tiles and stands beside ANY of them dies. */

  /* ------------------------------------------------------------ geometry */

  /* The direction a knight commits to: the axis it is FURTHEST from the
     banner on; a tie goes horizontal. Total, so preview cannot drift.

     `wheel` is the Order of the same name: for this one charge the tie
     breaks VERTICAL instead. It changes nothing else — which is why it
     is worth spending, and why it can also be a mistake. */
  function chargeDir(from, banner, wheel) {
    var dx = banner.x - from.x;
    var dy = banner.y - from.y;
    if (dx === 0 && dy === 0) return null;
    var ax = Math.abs(dx), ay = Math.abs(dy);
    if (ax === ay && wheel) return { dx: 0, dy: dy > 0 ? 1 : -1 };
    if (ax >= ay) return { dx: dx > 0 ? 1 : -1, dy: 0 };
    return { dx: 0, dy: dy > 0 ? 1 : -1 };
  }

  function inBounds(level, x, y) {
    return x >= 0 && y >= 0 && x < level.w && y < level.h;
  }

  /* --------------------------------------------------------- preparation */

  /* Fields ship as plain data (generated offline, proven solvable).
     This builds the lookups the resolver wants without mutating input.
       { w, h, walls:[[x,y]], caltrops:[[x,y]], ridge:[[x,y]],
         gate:[x,y]|null,
         knights:[[x,y]], foes:[[x,y,kind,facing?]],
         objective:'trample'|'rout'|'breach', budget, minMoves }

     `ridge` is optional and absent on every field generated before
     v1.2 — a field with no ridge plays exactly as it always did, which
     is what lets a save taken mid-field survive the upgrade. */
  function prepare(level) {
    if (level.wallSet) return level;
    var l = {
      w: level.w, h: level.h,
      walls: level.walls || [],
      caltrops: level.caltrops || [],
      ridge: level.ridge || [],
      gate: level.gate || null,
      knights: level.knights || [],
      foes: level.foes || [],
      objective: level.objective || 'trample',
      budget: level.budget,
      minMoves: level.minMoves,
      wallSet: new Set(),
      caltropSet: new Set(),
      ridgeSet: new Set()
    };
    var i;
    for (i = 0; i < l.walls.length; i++) l.wallSet.add(key(l.walls[i][0], l.walls[i][1]));
    for (i = 0; i < l.caltrops.length; i++) l.caltropSet.add(key(l.caltrops[i][0], l.caltrops[i][1]));
    for (i = 0; i < l.ridge.length; i++) l.ridgeSet.add(key(l.ridge[i][0], l.ridge[i][1]));
    return l;
  }

  function isWall(level, x, y) { return level.wallSet.has(key(x, y)); }
  function isCaltrop(level, x, y) { return level.caltropSet.has(key(x, y)); }
  function isRidge(level, x, y) { return level.ridgeSet.has(key(x, y)); }

  /* Start-of-field state. `roster` is optional: an array of knight objects
     ({ id, traits }) laid onto the field's start slots in order. Missing
     roster entries produce plain knights, so the solver and the tests can
     run the same fields the march does. */
  function startState(level, roster) {
    var l = prepare(level);
    var knights = [];
    for (var i = 0; i < l.knights.length; i++) {
      var slot = l.knights[i];
      var member = roster && roster[i];
      if (roster && !member) continue;         /* smaller roster: rear slots stay empty */
      knights.push({
        x: slot[0], y: slot[1],
        id: member ? member.id : ('k' + i),
        traits: member ? (member.traits || []).slice() : [],
        steadyUsed: false,
        shieldUsed: false
      });
    }
    return {
      knights: knights,
      foes: l.foes.map(function (f) {
        return { x: f[0], y: f[1], kind: f[2] || 'pike', facing: f[3] || null };
      }),
      moves: 0
    };
  }

  /* Order-insensitive identity for the solver's visited set. Knights with
     identical traits are interchangeable; foes carry kind+facing. */
  function stateKey(st) {
    var k = st.knights.map(function (u) {
      return u.x + ',' + u.y + ':' + (u.traits.length ? u.traits.slice().sort().join('+') : '') + (u.steadyUsed ? '!' : '') + (u.shieldUsed ? '#' : '');
    }).sort().join(' ');
    var f = st.foes.map(function (u) {
      return u.x + ',' + u.y + ':' + u.kind + (u.facing || '');
    }).sort().join(' ');
    return k + '|' + f;
  }

  function legalMoves(level) {
    var l = prepare(level);
    var out = [];
    for (var y = 0; y < l.h; y++) {
      for (var x = 0; x < l.w; x++) {
        if (!isWall(l, x, y)) out.push({ x: x, y: y });
      }
    }
    return out;
  }

  function has(u, trait) { return u.traits.indexOf(trait) >= 0; }

  function foeAt(foes, x, y) {
    for (var i = 0; i < foes.length; i++) {
      if (foes[i].x === x && foes[i].y === y) return i;
    }
    return -1;
  }

  function adjacentFoe(foes, x, y) {
    for (var i = 0; i < ORTHO.length; i++) {
      if (foeAt(foes, x + ORTHO[i][0], y + ORTHO[i][1]) >= 0) return true;
    }
    return false;
  }

  /* ------------------------------------------------------------ the charge

     Resolves one banner plant, completely:

       1. every knight charges simultaneously (traits and the ground
          bend the ride; a reined knight does not ride at all)
       2. lances: a stopping `longlance` knight spears the tile ahead
       3. the stall rule: dist 0 beside a surviving foe is a death
          (`steady` eats exactly one of those per field; the `horn`
          Order eats every one of them for this charge; a reined
          knight is holding, not stalling, and is exempt)
       4. win check — breach and rout end the field before any bolt flies
       5. surviving crossbows each fire one bolt down their line
          (`shieldbearer` turns exactly one aside per field)
       6. the captain takes one step toward the nearest knight
       7. lose check — wiped out, or out of charges

     `orders` is optional — { horn:bool, wheel:bool, rein:<knightId> }.
     Omitted, it is {} and the charge resolves exactly as it did in
     v1.1, which is what keeps the old proofs and the old tests honest.

     Returns { state, riders, trampled, bolts, captainMove, banner,
               won, lost, why } — riders carry full paths and event
     flags, which is what the renderer animates and the hover preview
     draws. The preview is not a prediction; it is this function. */
  function resolve(rawLevel, st, banner, orders) {
    var level = prepare(rawLevel);
    var ord = orders || {};
    var bannerDefended = adjacentFoe(st.foes, banner.x, banner.y);

    var riders = st.knights.map(function (u) {
      var reined = ord.rein != null && String(ord.rein) === String(u.id);
      var d = reined ? null : chargeDir(u, banner, ord.wheel);
      var refused = d !== null && has(u, 'craven') && bannerDefended;
      return {
        id: u.id, traits: u.traits,
        steadyUsed: u.steadyUsed, shieldUsed: !!u.shieldUsed,
        x: u.x, y: u.y, sx: u.x, sy: u.y,
        dir: d, dist: 0,
        moving: d !== null && !refused,
        refused: refused, held: reined,
        overrun: false, turned: false, balked: false,
        dead: false, stalled: false, shot: false, saved: false,
        shielded: false, horned: false,
        path: [{ x: u.x, y: u.y }],
        trampled: [], lanced: null, jumped: 0
      };
    });

    var foes = st.foes.map(function (f) {
      return { x: f.x, y: f.y, kind: f.kind, facing: f.facing };
    });
    var trampledAll = [];

    function riderAt(x, y, skip) {
      for (var i = 0; i < riders.length; i++) {
        if (i !== skip && !riders[i].dead && riders[i].x === x && riders[i].y === y) return i;
      }
      return -1;
    }

    /* `downhill` rides on the KILL record, not only on the rider's own
       list: the result exposes `trampled` (this array) and that is what
       the renderer and the tests read. A flag that exists on only one of
       two parallel lists is a flag that reads `undefined` like an answer. */
    function kill(fi, by, how, downhill) {
      trampledAll.push({
        x: foes[fi].x, y: foes[fi].y, kind: foes[fi].kind,
        by: by, how: how, downhill: !!downhill
      });
      foes.splice(fi, 1);
    }

    /* A stopping longlance knight spears the soft foe directly ahead.
       Requires a real charge (dist >= 1): a knight who never moved never
       lowered his lance — the stall rule stays supreme. Pikewalls shrug
       a lance off; they are why the lance exists.

       A stop is a STATE CHANGE the sweep must react to: the rider behind
       a knight who has just stopped may now jump (ironshod) — so stopping
       marks the sweep dirty and forces a re-scan. */
    var sweepDirty = false;
    function stopRider(r, i) {
      if (r.moving) sweepDirty = true;
      r.moving = false;
      if (r.dist >= 1 && has(r, 'longlance') && r.dir) {
        var fi = foeAt(foes, r.x + r.dir.dx, r.y + r.dir.dy);
        if (fi >= 0 && foes[fi].kind !== 'wall') {
          r.lanced = { x: foes[fi].x, y: foes[fi].y, kind: foes[fi].kind };
          kill(fi, i, 'lance');
        }
      }
    }

    /* --- 1. the simultaneous charge. Within a step we sweep until nothing
       else can move, so a column advances as a column instead of the front
       rider "blocking" one about to vacate its tile. */
    var maxSteps = (level.w + level.h + 2) * 2;
    for (var step = 0; step < maxSteps; step++) {
      var anyMoving = riders.some(function (r) { return r.moving && !r.dead; });
      if (!anyMoving) break;

      var movedThisStep = new Set();
      var progress = true;

      while (progress) {
        progress = false;
        sweepDirty = false;

        for (var i = 0; i < riders.length; i++) {
          var r = riders[i];
          if (r.dead || !r.moving || movedThisStep.has(i)) continue;

          /* Reaching the banner ends the charge — unless the knight is
             `reckless`, who overruns it by exactly one tile, every time. */
          if (r.x === banner.x && r.y === banner.y && !r.overrun) {
            if (has(r, 'reckless')) { r.overrun = true; }
            else { stopRider(r, i); continue; }
          }

          var nx = r.x + r.dir.dx, ny = r.y + r.dir.dy;

          /* THE CLIMB. Riding up onto the ridge needs a run: from a
             standing start the horse balks at the bank. A `hillman` was
             raised on this ground and takes it cold. */
          var balking = inBounds(level, nx, ny) && !isWall(level, nx, ny) &&
                        isRidge(level, nx, ny) && !isRidge(level, r.x, r.y) &&
                        r.dist < 1 && !has(r, 'hillman');

          /* Walls, the field edge, and a bank he cannot take. An
             `outrider` refuses to waste the charge: once per charge he
             turns toward the banner on the other axis and keeps riding
             — from anything the ground puts in front of him, which is
             one rule where it used to be two. */
          if (!inBounds(level, nx, ny) || isWall(level, nx, ny) || balking) {
            if (has(r, 'outrider') && !r.turned) {
              var alt = null;
              if (r.dir.dx !== 0 && banner.y !== r.y) alt = { dx: 0, dy: banner.y > r.y ? 1 : -1 };
              if (r.dir.dy !== 0 && banner.x !== r.x) alt = { dx: banner.x > r.x ? 1 : -1, dy: 0 };
              if (alt) {
                r.dir = alt; r.turned = true;
                progress = true;   /* re-attempt on a later sweep this step */
                continue;
              }
            }
            if (balking) r.balked = true;
            stopRider(r, i);
            continue;
          }

          /* THE CREST. An impact made while riding DOWN off the ridge
             carries one extra tile of weight — and only that impact:
             the horse is heavy for the moment it comes off the bank,
             not for the rest of the field. */
          var descent = (isRidge(level, r.x, r.y) && !isRidge(level, nx, ny)) ? 1 : 0;
          var weight = r.dist + descent;

          var fi = foeAt(foes, nx, ny);
          if (fi >= 0) {
            var f = foes[fi];
            var needed = f.kind === 'wall' ? 2 : 1;
            if (weight >= needed) {
              kill(fi, i, 'trample', descent > 0);
              r.trampled.push({ x: nx, y: ny, kind: f.kind, downhill: descent > 0 });
            } else if (f.kind === 'wall' && weight >= 1) {
              /* One tile of momentum bounces off a pikewall: the rider
                 stops SHORT of it, shaken but alive and not stalled. */
              stopRider(r, i);
              continue;
            } else {
              /* Standing start into any foe: the horse refuses. The rider
                 has not moved, which is exactly what the stall rule is
                 about — one rule, not two. */
              stopRider(r, i);
              continue;
            }
          }

          var blocker = riderAt(nx, ny, i);
          if (blocker >= 0) {
            if (!riders[blocker].moving && has(r, 'ironshod')) {
              /* `ironshod` does not stop behind a knight who has already
                 stopped: he rides through the jam — over any run of
                 stopped knights — and lands on the first open tile,
                 trampling if he lands on a soft foe with momentum. */
              var jx = nx, jy = ny, span = 0, landed = null;
              while (true) {
                var bi = riderAt(jx, jy, i);
                if (bi >= 0 && !riders[bi].moving) {
                  span++; jx += r.dir.dx; jy += r.dir.dy;
                  if (!inBounds(level, jx, jy) || isWall(level, jx, jy)) break;
                  continue;
                }
                if (bi >= 0) break;                      /* a MOVING rider: wait, no jump */
                var jf = foeAt(foes, jx, jy);
                if (jf >= 0) {
                  var need = foes[jf].kind === 'wall' ? 2 : 1;
                  if (r.dist + span + 1 >= need + 1) landed = { x: jx, y: jy, foe: jf };
                  break;
                }
                landed = { x: jx, y: jy, foe: -1 };
                break;
              }
              if (landed) {
                if (landed.foe >= 0) {
                  kill(landed.foe, i, 'trample');
                  r.trampled.push({ x: landed.x, y: landed.y, kind: 'jumpTrample' });
                }
                r.x = landed.x; r.y = landed.y;
                r.dist += span + 1; r.jumped += span;
                r.path.push({ x: landed.x, y: landed.y });
                movedThisStep.add(i);
                progress = true;
                /* The jump IS his placement: he rode through the jam and
                   found his place in the formation past it. He stops. */
                stopRider(r, i);
                continue;
              }
            }
            continue;   /* blocked by a rider; may clear on a later sweep */
          }

          r.x = nx; r.y = ny; r.dist++;
          r.path.push({ x: nx, y: ny });
          movedThisStep.add(i);
          progress = true;

          /* Caltrops end the gallop where it stands — no kill, no fall,
             just a charge that is suddenly over. */
          if (isCaltrop(level, nx, ny)) { stopRider(r, i); continue; }

          /* A reckless overrun is exactly one tile past the banner. */
          if (r.overrun && (r.x !== banner.x || r.y !== banner.y)) { stopRider(r, i); continue; }
        }

        /* A stop enables moves that were blocked a moment ago (the rider
           behind an ironshod jump, a column compressing) — re-scan. */
        if (sweepDirty) progress = true;
      }

      /* Anything still "moving" that could not move is jammed. That is a
         stop, and lances drop at a stop. */
      for (var j = 0; j < riders.length; j++) {
        if (riders[j].moving && !riders[j].dead && !movedThisStep.has(j)) stopRider(riders[j], j);
      }
    }

    /* --- 3. the rule the game is named for. A charge that never started
       is a death — unless the knight is `steady`, exactly once a field;
       unless the `horn` was sounded, which covers the whole company for
       this one charge; or unless he was REINED, in which case he is
       holding his ground under orders rather than failing to start. */
    for (var m = 0; m < riders.length; m++) {
      var rr = riders[m];
      if (rr.dist === 0 && !rr.dead && !rr.held && adjacentFoe(foes, rr.x, rr.y)) {
        if (ord.horn) {
          rr.horned = true; rr.saved = true;
        } else if (has(rr, 'steady') && !rr.steadyUsed) {
          rr.steadyUsed = true; rr.saved = true;
        } else {
          rr.dead = true; rr.stalled = true;
        }
      }
    }

    function alive() {
      return riders.filter(function (r) { return !r.dead; });
    }
    function packState() {
      return {
        knights: alive().map(function (r) {
          return { x: r.x, y: r.y, id: r.id, traits: r.traits, steadyUsed: r.steadyUsed, shieldUsed: r.shieldUsed };
        }),
        foes: foes,
        moves: st.moves + 1
      };
    }
    function result(extra) {
      var out = {
        state: packState(),
        riders: riders,
        trampled: trampledAll,
        bolts: extra.bolts || [],
        captainMove: extra.captainMove || null,
        banner: { x: banner.x, y: banner.y },
        won: !!extra.won, lost: !!extra.lost, why: extra.why || null
      };
      return out;
    }

    /* --- 4. wins that end the field before a single bolt flies.
       breach: any rider's PATH crossed the gate — he is through, gone,
       and the field is over. rout: the captain is down; the rest run.
       trample: no foe left standing means nobody left to shoot. */
    if (level.objective === 'breach' && level.gate) {
      var gx = level.gate[0], gy = level.gate[1];
      var through = riders.some(function (r) {
        if (r.dead) return false;
        return r.path.some(function (p) { return p.x === gx && p.y === gy; });
      });
      if (through) return result({ won: true, why: 'breach' });
    }
    if (level.objective === 'rout') {
      var capAlive = foes.some(function (f) { return f.kind === 'captain'; });
      if (!capAlive) return result({ won: true, why: 'rout' });
    }
    if (foes.length === 0) {
      return result({ won: true, why: 'trample' });
    }

    /* --- 5. crossbows answer. Each surviving bow sends one bolt down its
       facing; the first thing in the line takes it — wall and foe block,
       the first knight in line dies. */
    var bolts = [];
    for (var b = 0; b < foes.length; b++) {
      var bow = foes[b];
      if (bow.kind !== 'bow' || !bow.facing) continue;
      var d = { N: [0, -1], S: [0, 1], E: [1, 0], W: [-1, 0] }[bow.facing];
      var bx = bow.x + d[0], by = bow.y + d[1];
      var hit = null;
      while (inBounds(level, bx, by) && !isWall(level, bx, by)) {
        if (foeAt(foes, bx, by) >= 0) break;
        var ri = riderAt(bx, by, -1);
        if (ri >= 0) { hit = ri; break; }
        bx += d[0]; by += d[1];
      }
      /* A `shieldbearer` takes exactly one bolt on the shield per field.
         The bolt still flies and still ends its line on him — it simply
         does not kill him, which is why it is a rule and not a stat. */
      var turned = false;
      if (hit !== null && has(riders[hit], 'shieldbearer') && !riders[hit].shieldUsed) {
        riders[hit].shieldUsed = true;
        riders[hit].shielded = true;
        turned = true;
      }
      bolts.push({ from: { x: bow.x, y: bow.y }, to: { x: bx, y: by }, hit: hit, turned: turned });
      if (hit !== null && !turned) { riders[hit].dead = true; riders[hit].shot = true; }
    }

    /* --- 6. the captain closes in: one tile toward the nearest living
       knight, along the longer axis first, around anything in the way.
       He will not step on caltrops — he is the one who ordered them. */
    var captainMove = null;
    var living = alive();
    for (var c = 0; c < foes.length && living.length > 0; c++) {
      if (foes[c].kind !== 'captain') continue;
      var cap = foes[c];
      var best = null;
      for (var t = 0; t < living.length; t++) {
        var dd = Math.abs(living[t].x - cap.x) + Math.abs(living[t].y - cap.y);
        if (!best || dd < best.d || (dd === best.d && (living[t].y < best.k.y || (living[t].y === best.k.y && living[t].x < best.k.x)))) {
          best = { d: dd, k: living[t] };
        }
      }
      var ddx = best.k.x - cap.x, ddy = best.k.y - cap.y;
      var tries = Math.abs(ddx) >= Math.abs(ddy)
        ? [{ dx: ddx > 0 ? 1 : -1, dy: 0 }, { dx: 0, dy: ddy > 0 ? 1 : (ddy < 0 ? -1 : 0) }]
        : [{ dx: 0, dy: ddy > 0 ? 1 : -1 }, { dx: ddx > 0 ? 1 : (ddx < 0 ? -1 : 0), dy: 0 }];
      for (var q = 0; q < tries.length; q++) {
        var tv = tries[q];
        if (tv.dx === 0 && tv.dy === 0) continue;
        var tx = cap.x + tv.dx, ty = cap.y + tv.dy;
        if (!inBounds(level, tx, ty) || isWall(level, tx, ty)) continue;
        if (isCaltrop(level, tx, ty)) continue;
        if (foeAt(foes, tx, ty) >= 0) continue;
        if (riderAt(tx, ty, -1) >= 0) continue;
        captainMove = { from: { x: cap.x, y: cap.y }, to: { x: tx, y: ty } };
        cap.x = tx; cap.y = ty;
        break;
      }
      break;   /* one captain per field */
    }

    /* --- 7. the reckoning. */
    var final = packState();
    var lost = final.knights.length === 0 ||
               (final.moves >= level.budget);
    return result({
      bolts: bolts,
      captainMove: captainMove,
      lost: lost,
      why: lost ? (final.knights.length === 0 ? 'wiped' : 'budget') : null
    });
  }

  var API = {
    key: key,
    ORTHO: ORTHO,
    TRAITS: ['ironshod', 'steady', 'longlance', 'reckless', 'outrider', 'hillman', 'shieldbearer', 'craven'],
    NEGATIVE_TRAITS: ['craven'],
    ORDERS: ['horn', 'wheel', 'rein'],
    chargeDir: chargeDir,
    prepare: prepare,
    startState: startState,
    stateKey: stateKey,
    legalMoves: legalMoves,
    isRidge: isRidge,
    resolve: resolve
  };

  root.Rules = API;

})(typeof window !== 'undefined' ? window : globalThis);

if (typeof module !== 'undefined' && module.exports) {
  module.exports = (typeof window !== 'undefined' ? window : globalThis).Rules;
}
