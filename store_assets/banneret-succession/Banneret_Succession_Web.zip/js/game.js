/* =====================================================================
   game.js — BANNERET: SUCCESSION. The shell that turns four pure
   modules and one renderer into a game.

   Everything stateful-and-impure lives here, on purpose:
     · the DOM (seven screens built into #stage)
     · localStorage (save-as-you-go: the model is committed and saved
       the moment a charge is clicked; the animation that follows is
       purely visual, so a closed tab never loses a decision)
     · Date.now() for new-House seeds (the models stay seeded and pure)

   The flow:  title → route → (field | muster | shrine) → route → …
              → outcome → title, with the chronicle reachable anywhere.

   Three glue decisions worth knowing about (devlog carries the why):
     1. Boot always lands on the TITLE — the crest and the House name
        are the identity beat — and CONTINUE resumes the exact spot,
        including mid-field.
     2. The model commits BEFORE the charge animation plays. Death,
        renown, save: all written at the click. Crash-safe by shape.
     3. An heir seated at a muster joins the CURRENT march column
        (march.js's muster functions touch only the House; the march
        is this shell's to update).
   ===================================================================== */
'use strict';

(function () {

  var Rules = window.Rules, March = window.March, Art = window.Art,
      Names = window.Names, FIELDS = window.FIELDS;
  /* audio is never fatal: if sound.js failed to load, play into silence */
  var Sfx = window.Sfx || {
    play: function () {}, toggleMute: function () { return true; },
    isMuted: function () { return true; }
  };

  /* ------------------------------------------------------------- state */

  var house = null;          /* the House — outlives everything */
  var march = null;          /* the live march, or null */
  var her = null;            /* heraldry derived from house.heraldrySeed */

  var board = null;          /* Art.Board while the field screen is up */
  var fieldCtx = null;       /* { level, st, deaths, trampled, captainFell } */
  var fieldUI = null;        /* { verdict, margin } while the field screen is up */
  var kbCursor = null;       /* keyboard cursor on the field, or null */
  var resolving = false;     /* a charge animation is playing */
  var lastScreen = null;     /* what "Return" from the chronicle re-shows */
  var toastQ = [], toastLive = false;

  /* the march chronometer: rAF-driven, so it stops if the page's event
     loop does — it counts seconds only while a march is live, and the
     outcome screen shows it. Also the gate's `elapsed` (test surface). */
  var elapsed = 0;
  var marchT0 = 0;           /* elapsed at the start of the current sitting */
  var chargesCommitted = 0;  /* every banner planted this session */

  var stage = document.getElementById('stage');

  /* ------------------------------------------------------- persistence */

  function save() {
    try { localStorage.setItem(March.SAVE_KEY, March.serialize(house, march)); }
    catch (e) { /* private mode: play on, in-session only */ }
  }
  /* Rungs the v1.2 migration handed a returning House at load. Announced
     on the title screen rather than swallowed: a save that silently grows
     new powers reads as a bug, and this player earned them in v1.1. */
  var wokeWith = [];

  function load() {
    try {
      var d = March.deserialize(localStorage.getItem(March.SAVE_KEY));
      if (d) { house = d.house; march = d.march || null; wokeWith = d.granted || []; }
    } catch (e) { house = null; march = null; }
  }

  /* -------------------------------------------------------- dom helpers */

  function el(tag, cls, html) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (html != null) n.innerHTML = html;
    return n;
  }
  function seal(label, cls, onClick) {
    var b = el('button', 'seal' + (cls ? ' ' + cls : ''), label);
    b.type = 'button';
    b.addEventListener('click', function (ev) {
      Sfx.play('click');           /* a user gesture: also unlocks audio */
      onClick(ev);
    });
    return b;
  }
  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  function setHint(html) { document.getElementById('hint').innerHTML = html; }

  function swapScreen(node) {
    if (board) { board.stop(); board = null; }
    resolving = false;
    stage.innerHTML = '';
    stage.appendChild(node);
    stage.focus({ preventScroll: true });
    /* Every screen is the hall by default; showField overrides to the march
       immediately after its own swapScreen call. Doing it here rather than in
       seven show* functions means a screen added later cannot forget to set
       the score — it just gets the right default. Music.play ignores a request
       for whatever is already playing, so this is free to call every swap. */
    music('hall');
  }

  /* One guarded entry point: a missing or failed music layer must never throw
     inside a screen transition. Audio is never fatal — the rule Sfx follows. */
  function music(track) {
    if (typeof Music === 'undefined' || !Music) return;
    try { Music.play(track); } catch (e) {}
  }

  function toast(html) {
    toastQ.push(html);
    if (!toastLive) nextToast();
  }
  function nextToast() {
    var t = document.getElementById('toast');
    if (!toastQ.length) { toastLive = false; return; }
    toastLive = true;
    t.innerHTML = toastQ.shift();
    t.classList.add('up');
    setTimeout(function () {
      t.classList.remove('up');
      setTimeout(nextToast, 380);
    }, 2500);
  }

  /* --------------------------------------------------- crest and renown */

  function refreshCrest() {
    var cv = document.getElementById('crest');
    var nameEl = document.getElementById('houseName');
    var lineEl = document.getElementById('houseLine');
    var rbox = document.getElementById('renownBox');
    var chron = document.getElementById('btnChronicle');
    if (house) {
      her = Names.heraldry(house.heraldrySeed);
      Art.paintArms(cv, her, null, 56, 64);
      nameEl.textContent = 'HOUSE ' + house.name.toUpperCase();
      lineEl.textContent = 'BANNERET: SUCCESSION';
      rbox.hidden = false;
      chron.hidden = false;
      refreshRenown(false);
    } else {
      var c = cv.getContext('2d');
      c.clearRect(0, 0, cv.width, cv.height);
      nameEl.textContent = 'BANNERET';
      lineEl.textContent = 'SUCCESSION';
      rbox.hidden = true;
      chron.hidden = true;
    }
  }

  function refreshRenown(flash) {
    if (!house) return;
    document.getElementById('renownVal').textContent = house.renown;
    var next = null;
    for (var i = 0; i < March.UNLOCKS.length; i++) {
      if (!house.unlocked[March.UNLOCKS[i].id]) { next = March.UNLOCKS[i]; break; }
    }
    var fill = document.getElementById('renownFill');
    var lab = document.getElementById('renownNext');
    if (next) {
      fill.style.width = Math.min(100, Math.round(house.renown / next.at * 100)) + '%';
      lab.textContent = next.label + ' at ' + next.at;
    } else {
      fill.style.width = '100%';
      lab.textContent = 'the chronicle is full of your name';
    }
    if (flash) {
      var crest = document.getElementById('crest');
      crest.classList.add('hoisted');
      setTimeout(function () { crest.classList.remove('hoisted'); }, 700);
    }
  }

  function announceUnlocks(unlocks) {
    (unlocks || []).forEach(function (u) {
      Sfx.play('gilt');
      toast('<span class="tgold">UNLOCKED</span> — ' + esc(u.label));
    });
  }

  /* ------------------------------------------------------- small pieces */

  function ordinalWord(n) {
    return ['', 'first', 'second', 'third', 'fourth', 'fifth', 'sixth',
            'seventh', 'eighth', 'ninth', 'tenth'][n] || (n + 'th');
  }

  function traitChip(t) {
    /* DERIVED, not listed. This used to name longlance and outrider by
       hand, so v1.2's hillman and shieldbearer would have rendered as
       plain chips — the deep blood looking exactly like the common kind.
       Anything that is not a flaw and not in the founding pool is deep. */
    var cls = 'trait';
    if (March.NEGATIVE.indexOf(t) >= 0) cls += ' flaw';
    else if (['steady', 'ironshod', 'reckless'].indexOf(t) < 0) cls += ' blessed';
    return '<span class="' + cls + '">' + esc(t) + '</span>';
  }

  function knightCard(k, opts) {
    var o = opts || {};
    var card = el('div', 'knightCard' + (o.cls ? ' ' + o.cls : ''));
    var cv = document.createElement('canvas');
    card.appendChild(cv);
    var body = el('div', null,
      '<div class="kName">' + esc(March.knightTitle(k)) + '</div>' +
      '<div class="kGen">' + ordinalWord(k.gen) + ' of the line</div>' +
      (k.traits.length
        ? '<div class="kTraits">' + k.traits.map(traitChip).join('') + '</div>'
        : ''));
    body.style.minWidth = '0';
    card.appendChild(body);
    Art.paintArms(cv, her, k.gen, 26, 30);
    return card;
  }

  /* Roster ids the next march would ride with; used by the title screen. */
  function ensureRoster() {
    var sworn = false;
    while (house.roster.length < 3) {
      March.addKnight(house, 1, null);
      sworn = true;
    }
    if (sworn) house.chronicle.push('Fresh oaths are sworn at the keep gate.');
  }

  /* ============================================================= TITLE */

  function showTitle() {
    lastScreen = showTitle;
    var s = el('div', 'screen');
    var wrap = el('div', null); wrap.id = 'titleWrap';

    if (house) {
      var std = document.createElement('canvas');
      wrap.appendChild(std);
      Art.paintStandard(std, her, 170, 225);
    }

    wrap.appendChild(el('p', 'bigsub', house ? 'HOUSE ' + esc(house.name.toUpperCase()) : 'SUCCESSION'));
    /* a <p>, not an <h2>: the generic .screen h2 rule would out-rank .bigtitle */
    wrap.appendChild(el('p', 'bigtitle', 'BANNERET'));
    wrap.appendChild(el('p', 'creed',
      'Plant the banner and <b>every knight charges it at once</b>. ' +
      'A charge that never started is a death. Knights who fall are dead — ' +
      'their heirs inherit a trait, <b>and sometimes a flaw</b>.'));

    /* The returning House is told, once, what the new ladder gave it. */
    if (wokeWith.length) {
      var back = el('div', 'wokeWith');
      back.appendChild(el('div', 'wokeHead', 'THE HOUSE RETURNS TO A LONGER ROAD'));
      back.appendChild(el('div', 'wokeBody',
        'Renown you had already won reaches further in this telling. House ' +
        esc(house.name) + ' takes up ' + (wokeWith.length === 1 ? 'a rung' : wokeWith.length + ' rungs') +
        ' it had paid for and never been given:'));
      var ul = el('ul', 'wokeList');
      wokeWith.forEach(function (u) { ul.appendChild(el('li', null, esc(u.label))); });
      back.appendChild(ul);
      wrap.appendChild(back);
      wokeWith = [];                       /* said once, not every visit */
    }

    var btns = el('div', 'titleBtns');

    if (!house) {
      btns.appendChild(seal('RAISE YOUR BANNER', 'gilt', function () {
        var seed = (Date.now() ^ (Math.random() * 0x7fffffff)) | 0;
        house = March.newHouse(seed);
        refreshCrest();
        rideOut(1);
      }));
    } else {
      if (march) {
        btns.appendChild(seal('CONTINUE THE MARCH', 'gilt', function () { resumeFlow(); }));
      } else {
        var top = March.maxTier(house);
        for (var t = 1; t <= top; t++) {
          (function (tier) {
            btns.appendChild(seal('RIDE OUT — ' + esc(March.TIER_NAMES[tier].toUpperCase()),
              tier === top ? 'gilt' : '', function () { rideOut(tier); }));
          })(t);
        }
      }
      btns.appendChild(seal('THE CHRONICLE', 'ghost', function () { showChronicle(); }));

      /* founding a new House burns the chronicle: two clicks, never a
         browser dialog. */
      var burn = seal('FOUND A NEW HOUSE', 'ghost', function () {
        if (burn.dataset.armed) {
          house = null; march = null;
          try { localStorage.removeItem(March.SAVE_KEY); } catch (e) {}
          refreshCrest();
          showTitle();
        } else {
          burn.dataset.armed = '1';
          burn.textContent = 'THE CHRONICLE BURNS — ARE YOU CERTAIN?';
          setTimeout(function () {
            delete burn.dataset.armed;
            burn.textContent = 'FOUND A NEW HOUSE';
          }, 3200);
        }
      });
      btns.appendChild(burn);
    }

    wrap.appendChild(btns);
    s.appendChild(wrap);
    swapScreen(s);
    setHint(house && march
      ? 'The column waits where you left it. <b>Nothing is lost between sittings.</b>'
      : 'One banner. One order. <b>The whole House obeys it at once.</b>');
  }

  function rideOut(tier) {
    ensureRoster();
    march = March.newMarch(house, tier);
    marchT0 = elapsed;
    save();
    showRoute();
  }

  /* ============================================================= ROUTE */

  var NODE_COPY = {
    battle: { h: 'A BATTLE', p: 'Pikes hold the road. Leave none standing.', m: 'field' },
    ambush: { h: 'AN AMBUSH', p: 'Bolts from the treeline, iron in the grass.', m: 'field' },
    muster: { h: 'THE MUSTER', p: 'Heirs and oaths. The House is counted.', m: 'camp' },
    shrine: { h: 'A WAYSHRINE', p: 'The old blood answers those who kneel.', m: 'camp' },
    captain: { h: "THE CAPTAIN'S FIELD", p: 'He moves. Break him and the rest will run.', m: 'field' },
    final: { h: 'THE STANDARD', p: 'Cast it down, and the march is won.', m: 'field' }
  };

  function actRibbon() {
    var rib = el('div', null); rib.id = 'actRibbon';
    rib.appendChild(el('span', 'meta',
      '<span style="font-size:10px;letter-spacing:.24em;text-transform:uppercase;color:var(--ink-ghost)">' +
      'ACT ' + ['', 'I', 'II', 'III'][march.act] + ' · ' + esc(March.TIER_NAMES[march.tier]) + '</span>'));
    var dots = el('div', 'pathDots');
    for (var i = 0; i < march.graph.length; i++) {
      dots.appendChild(el('span', 'pdot' + (i < march.step ? ' done' : i === march.step ? ' here' : '')));
    }
    rib.appendChild(dots);
    return rib;
  }

  function showRoute() {
    lastScreen = showRoute;
    var s = el('div', 'screen');
    var wrap = el('div', null); wrap.id = 'routeWrap';
    s.appendChild(wrap);

    wrap.appendChild(el('h2', null, 'THE MARCH'));
    wrap.appendChild(el('p', 'sub', 'Choose the road. Every road is ridden the same way: banner first.'));
    wrap.appendChild(actRibbon());

    var row = el('div', null); row.id = 'routeRow';
    var opts = March.options(march);
    opts.forEach(function (o, i) {
      var c = NODE_COPY[o.type] || NODE_COPY.battle;
      var card = el('div', 'routeCard',
        '<span class="meta">' + esc(c.m) + '</span>' +
        '<h3>' + c.h + '</h3><p>' + c.p + '</p>');
      card.addEventListener('click', function () { pickRoute(i); });
      row.appendChild(card);
    });
    wrap.appendChild(row);
    swapScreen(s);
    setHint(opts.length > 1 ? 'Two roads. <b>Both end at the Standard.</b>'
                            : 'One road. <b>Ride it.</b>');
  }

  function pickRoute(i) {
    /* a double-click (or a stale card) must not choose twice: choosing
       burns a field from the pool and advances the rng */
    if (march.node) { enterNode(march.node); return; }
    var node = March.choose(march, house, FIELDS, i);
    if (!node) return;
    save();
    enterNode(node);
  }

  /* A camp node (muster/shrine) is DONE: clear it before advancing, so a
     save taken on the route screen never resumes into a stale camp — and
     a detached button's second click cannot advance the march twice. */
  function leaveCamp() {
    march.node = null;
    March.advance(march, house);
    save();
    showRoute();
  }

  function enterNode(node) {
    if (node.type === 'muster') return showMuster();
    if (node.type === 'shrine') return showShrine();
    return showField(false);
  }

  /* ============================================================= FIELD */

  var OBJ_COPY = {
    trample: 'Leave <em>no foe standing</em>.',
    rout: 'Break <em>the captain</em> — the rest will run.',
    breach: 'Put one rider <em>through the gate</em> at the gallop.'
  };

  /* ------------------------------------------------------------- ORDERS

     `armedOrder` is the one the next plant will carry: null, {id:'horn'},
     {id:'wheel'}, or {id:'rein', knightId}. It is UI state and never
     touches the save — an order only becomes real when the banner lands,
     which is also the moment the stock is debited. A tab closed with an
     order armed re-opens with the stock intact, which is the correct
     answer and comes for free. */
  var armedOrder = null;

  var ORDER_COPY = {
    horn:  { name: 'THE HORN',  key: '1', hint: 'No knight stall-dies this charge.' },
    wheel: { name: 'THE WHEEL', key: '2', hint: 'Ties break <em>vertical</em> this charge, not horizontal.' },
    rein:  { name: 'THE REIN',  key: '3', hint: 'One named knight holds his ground and does not ride.' }
  };

  /* What the resolver is handed. An armed `rein` with nobody chosen is
     not an order yet, so it resolves as none — the preview then shows the
     plain charge, which is the truth. */
  function currentOrders() {
    if (!armedOrder) return {};
    if (armedOrder.id === 'rein') {
      return armedOrder.knightId == null ? {} : { rein: armedOrder.knightId };
    }
    var o = {};
    o[armedOrder.id] = true;
    return o;
  }

  function orderIsLive() {
    var o = currentOrders();
    return !!(o.horn || o.wheel || o.rein != null);
  }

  function disarmOrder() {
    armedOrder = null;
    if (fieldUI) { refreshMargin(fieldUI.margin); repreview(); }
  }

  /* Re-run the preview under the current orders without needing a new
     hover: arming an order must change the picture immediately, or the
     player has to jiggle the mouse to find out what he just did. */
  function repreview() {
    var c = lastHover || kbCursor;
    if (!c) return;
    lastHover = null;                    /* defeat the same-cell early-out */
    previewAt(c);
  }

  function armOrder(id) {
    if (resolving || !march) return;
    if (March.ordersLeft(house, march) <= 0) return;
    if (armedOrder && armedOrder.id === id) { disarmOrder(); return; }
    armedOrder = { id: id, knightId: null };
    if (id === 'rein') {
      setHint('<b>THE REIN</b> — click the knight who is to hold his ground. Click the order again to cancel.');
    } else {
      setHint('<b>' + ORDER_COPY[id].name + '</b> — ' + ORDER_COPY[id].hint + ' It is spent when the banner lands.');
    }
    if (fieldUI) { refreshMargin(fieldUI.margin); repreview(); }
  }

  function ordersPanel() {
    var avail = March.availableOrders(house);
    if (!avail.length) return null;
    var left = March.ordersLeft(house, march);

    var box = el('div', 'ordersBox');
    var head = el('div', 'mhead', 'ORDERS');
    var pips = el('span', 'ordPips');
    for (var i = 0; i < Math.max(left, March.orderCap(house)); i++) {
      pips.appendChild(el('span', 'ordPip' + (i < left ? '' : ' spent')));
    }
    head.appendChild(pips);
    box.appendChild(head);

    avail.forEach(function (id) {
      var c = ORDER_COPY[id];
      var armed = armedOrder && armedOrder.id === id;
      var b = el('button', 'ordBtn' + (armed ? ' armed' : '') + (left <= 0 ? ' spentAll' : ''));
      b.type = 'button';
      b.innerHTML = '<span class="ordKey">' + c.key + '</span><span class="ordName">' + c.name + '</span>';
      b.title = c.hint.replace(/<[^>]+>/g, '');
      if (left <= 0) b.disabled = true;
      b.addEventListener('click', function () { armOrder(id); });
      box.appendChild(b);
    });

    if (left <= 0) {
      box.appendChild(el('div', 'ordNote', 'The stock is spent. It comes back at the next muster.'));
    } else if (armedOrder && armedOrder.id === 'rein' && armedOrder.knightId == null) {
      box.appendChild(el('div', 'ordNote', 'Choose the knight who holds &rarr;'));
    }
    return box;
  }

  function buildFieldCtx(resume) {
    var node = march.node;
    var data = node.field.data;
    var level = Rules.prepare(Object.assign({}, data, {
      budget: data.budget + (node.budgetBonus || 0)
    }));
    var st, deaths, trampled, captainFell;
    if (resume && march.fieldLive) {
      st = march.fieldLive.st;
      deaths = march.fieldLive.deaths || [];
      trampled = march.fieldLive.trampled || 0;
      captainFell = !!march.fieldLive.captainFell;
    } else {
      st = Rules.startState(level, March.fieldRoster(house, march));
      deaths = []; trampled = 0; captainFell = false;
      march.fieldLive = { st: st, deaths: deaths, trampled: trampled, captainFell: captainFell };
      save();
    }
    fieldCtx = { level: level, st: st, deaths: deaths, trampled: trampled, captainFell: captainFell };
  }

  function knightMeta() {
    var meta = {};
    house.roster.forEach(function (k) {
      meta[k.id] = { name: k.name, epithet: k.epithet, gen: k.gen, traits: k.traits };
    });
    return meta;
  }

  function showField(resume) {
    lastScreen = function () { showField(true); };
    buildFieldCtx(resume);

    var s = el('div', 'screen');
    var wrap = el('div', null); wrap.id = 'fieldWrap';
    s.appendChild(wrap);

    var box = el('div', null); box.id = 'boardBox';
    var stack = el('div', 'boardStack');
    var hold = el('div', 'boardHold');
    var cv = document.createElement('canvas'); cv.id = 'board';
    hold.appendChild(cv);
    stack.appendChild(hold);
    var verdict = el('div', null); verdict.id = 'verdict';
    stack.appendChild(verdict);
    box.appendChild(stack);
    wrap.appendChild(box);

    var margin = el('div', null); margin.id = 'margin';
    wrap.appendChild(margin);

    swapScreen(s);
    music('march');            /* the field is the one screen that is not the hall */

    board = new Art.Board(cv);
    board.setField(fieldCtx.level, fieldCtx.st, her, knightMeta());

    refreshMargin(margin);

    fieldUI = { verdict: verdict, margin: margin };
    kbCursor = null;

    cv.addEventListener('mousemove', function (ev) { hoverField(ev); });
    cv.addEventListener('mouseleave', function () { clearPreview(verdict, margin); });
    cv.addEventListener('click', function (ev) { clickField(ev); });

    setHint('Hover to see the whole charge <b>before</b> you commit. Click — or steer with the arrows and <b>Enter</b> — to plant the banner.');
  }

  function refreshMargin(margin) {
    var f = fieldCtx;
    margin.innerHTML = '';

    var order = el('div');
    order.appendChild(el('div', 'mhead', 'THE ORDER'));
    order.appendChild(el('div', 'objText', OBJ_COPY[f.level.objective] || OBJ_COPY.trample));
    var pips = el('div', 'charges');
    for (var i = 0; i < f.level.budget; i++) {
      var cls = 'pip';
      if (i < f.st.moves) cls += ' spent';
      else if (march.node.budgetBonus && i >= f.level.budget - march.node.budgetBonus) cls += ' bonus';
      pips.appendChild(el('span', cls));
    }
    order.appendChild(pips);
    margin.appendChild(order);

    /* THE GROUND — shown only on fields that have any, so it teaches itself
       the first time the player meets a ridge and then stops being noise.
       Tier 1 act 1 is flat by design, which is what makes this land. */
    if (f.level.ridge && f.level.ridge.length) {
      var gnd = el('div', 'groundBox');
      gnd.appendChild(el('div', 'mhead', 'THE DOWNS'));
      gnd.appendChild(el('div', 'gndLine',
        '<span class="gndMark down"></span><b>Riding down</b> off the high ground puts an extra tile of weight behind the blow.'));
      gnd.appendChild(el('div', 'gndLine',
        '<span class="gndMark up"></span><b>Riding up</b> needs a run. From a standing start the horse balks at the bank.'));
      margin.appendChild(gnd);
    }

    var ord = ordersPanel();
    if (ord) margin.appendChild(ord);

    var col = el('div');
    col.style.minHeight = '0';
    col.style.display = 'flex';
    col.style.flexDirection = 'column';
    col.appendChild(el('div', 'mhead', 'THE COLUMN'));
    var rost = el('div', 'rost');
    var meta = knightMeta();
    f.st.knights.forEach(function (u) {
      var m = meta[u.id];
      var k = m ? { id: u.id, name: m.name, epithet: m.epithet || null, gen: m.gen, traits: u.traits }
                : { id: u.id, name: String(u.id), epithet: null, gen: 1, traits: u.traits };
      var card = knightCard(k);
      card.dataset.kid = u.id;
      /* While the Rein is armed the roster becomes the picker. The cards
         are otherwise inert, so nothing else has to change. */
      if (armedOrder && armedOrder.id === 'rein') {
        card.classList.add('pickable');
        if (String(armedOrder.knightId) === String(u.id)) card.classList.add('reined');
        (function (kid) {
          card.addEventListener('click', function () {
            armedOrder.knightId = String(armedOrder.knightId) === String(kid) ? null : kid;
            setHint(armedOrder.knightId == null
              ? '<b>THE REIN</b> — click the knight who is to hold his ground.'
              : '<b>' + esc(March.knightTitle(k)) + '</b> will hold. Plant the banner to spend the order.');
            refreshMargin(margin);
            repreview();
          });
        })(u.id);
      }
      rost.appendChild(card);
    });
    col.appendChild(rost);
    margin.appendChild(col);
  }

  function markRosterPreview(margin, pv) {
    var cards = margin.querySelectorAll('.knightCard');
    for (var i = 0; i < cards.length; i++) {
      var id = cards[i].dataset.kid;
      cards[i].classList.remove('doomed', 'saved');
      if (!pv) continue;
      for (var j = 0; j < pv.riders.length; j++) {
        var r = pv.riders[j];
        if (String(r.id) !== String(id)) continue;
        if (r.dead) cards[i].classList.add('doomed');
        else if (r.saved) cards[i].classList.add('saved');
      }
    }
  }

  function previewVerdict(pv, meta) {
    var bits = [];
    if (pv.trampled.length) bits.push('<span class="kill">' + (pv.trampled.length > 1 ? pv.trampled.length + ' foes fall' : '1 foe falls') + '</span>');
    var dead = pv.riders.filter(function (r) { return r.dead; });
    var saved = pv.riders.filter(function (r) { return r.saved; });
    var refused = pv.riders.filter(function (r) { return r.refused; });
    dead.forEach(function (r) {
      var m = meta[r.id];
      bits.push('<span class="die">Ser ' + esc(m ? m.name : r.id) + ' dies</span>');
    });
    saved.forEach(function (r) {
      var m = meta[r.id];
      bits.push('Ser ' + esc(m ? m.name : r.id) + ' holds steady');
    });
    refused.forEach(function (r) {
      var m = meta[r.id];
      bits.push('Ser ' + esc(m ? m.name : r.id) + ' refuses');
    });
    if (pv.won) bits.push('<span class="win">' + (pv.why === 'breach' ? 'THE GATE' : pv.why === 'rout' ? 'THE ROUT' : 'THE FIELD') + ' IS WON</span>');
    else if (pv.lost) bits.push('<span class="die">' + (pv.why === 'wiped' ? 'the House would be wiped from this field' : 'the last charge would be spent') + '</span>');
    else if (pv.bolts.length) bits.push('crossbows will answer');
    if (!bits.length) bits.push('the charge lands quietly');
    return bits.join(' · ');
  }

  var lastHover = null;

  /* One preview path for mouse and keyboard: the keyboard cursor follows
     the mouse and the mouse is not surprised by the keyboard. */
  function previewAt(cell) {
    if (resolving || !board || !fieldUI) return;
    if (!cell || fieldCtx.level.wallSet.has(Rules.key(cell.x, cell.y))) {
      clearPreview(fieldUI.verdict, fieldUI.margin);
      return;
    }
    kbCursor = cell;
    if (lastHover && lastHover.x === cell.x && lastHover.y === cell.y) return;
    lastHover = cell;
    var pv = Rules.resolve(fieldCtx.level, fieldCtx.st, cell, currentOrders());
    board.preview = pv;
    board.hover = cell;
    board.start();
    fieldUI.verdict.innerHTML = previewVerdict(pv, knightMeta());
    markRosterPreview(fieldUI.margin, pv);
  }

  function hoverField(ev) {
    if (resolving || !board) return;
    previewAt(board.cell(ev.offsetX, ev.offsetY));
  }

  /* Where Enter plants when the arrows have not moved yet: the free tile
     nearest the centre of the field — always exists, walls are sparse. */
  function defaultCursor() {
    var lv = fieldCtx.level;
    var cx = (lv.w - 1) / 2, cy = (lv.h - 1) / 2;
    var best = null, bd = Infinity;
    for (var y = 0; y < lv.h; y++) for (var x = 0; x < lv.w; x++) {
      if (lv.wallSet.has(Rules.key(x, y))) continue;
      var d = (x - cx) * (x - cx) + (y - cy) * (y - cy);
      if (d < bd) { bd = d; best = { x: x, y: y }; }
    }
    return best;
  }

  function clearPreview(verdict, margin) {
    lastHover = null;
    if (board) { board.preview = null; board.hover = null; board.draw(); }
    if (verdict) verdict.innerHTML = '';
    if (margin) markRosterPreview(margin, null);
  }

  function fateFor(r) {
    if (r.stalled) return 'stood his charge too long and died on the pikes';
    if (r.shot) return 'was shot from the saddle';
    return 'fell on the field';
  }

  function clickField(ev) {
    if (resolving || !board) return;
    commitAt(board.cell(ev.offsetX, ev.offsetY));
  }

  function commitAt(cell) {
    if (resolving || !board || !fieldUI) return;
    if (!cell || fieldCtx.level.wallSet.has(Rules.key(cell.x, cell.y))) return;
    var verdict = fieldUI.verdict, margin = fieldUI.margin;
    chargesCommitted++;

    var f = fieldCtx;
    var orders = currentOrders();
    var res = Rules.resolve(f.level, f.st, cell, orders);

    /* The order is spent by the plant, not by the arming — and it is
       debited BEFORE the animation, in the same breath as the model, so
       a tab closed mid-charge cannot hand the stock back. */
    var spentOrder = null;
    if (orderIsLive() && March.spendOrder(house, march)) {
      spentOrder = armedOrder.id;
      house.chronicle.push(ORDER_COPY[spentOrder].name.replace('THE ', 'The ') + ' is given.');
    }
    armedOrder = null;

    /* ---- commit the model NOW; animate after. A closed tab keeps this. */
    resolving = true;
    board.cv.classList.add('resolving');
    lastHover = null;
    Sfx.play('charge');

    var meta = knightMeta();
    var chargeDeaths = res.riders.filter(function (r) { return r.dead; })
      .map(function (r) { return { id: r.id, fate: fateFor(r) }; });
    f.deaths = f.deaths.concat(chargeDeaths);
    f.trampled += res.trampled.length;
    if (res.trampled.some(function (t) { return t.kind === 'captain'; })) f.captainFell = true;
    f.st = res.state;

    var after;   /* what to do when the ink settles */

    if (res.won) {
      var summary = {
        moves: res.state.moves,
        minMoves: f.level.minMoves,
        trampled: f.trampled,
        captainFell: f.captainFell,
        deaths: f.deaths
      };
      var wonInfo = March.fieldWon(house, march, summary);
      march.renownGained = (march.renownGained || 0) + wonInfo.renown;
      var prog = March.advance(march, house);
      var marchDone = prog === 'won';
      var winInfo = null;
      if (marchDone) {
        winInfo = March.marchWon(house, march);
        march.renownGained += winInfo.renown;
      }
      var outcomeInfo = marchDone ? marchTally('won') : null;
      if (marchDone) march = null;
      save();
      after = function () {
        Sfx.play('win');
        refreshRenown(true);
        announceUnlocks(wonInfo.unlocks);
        if (winInfo) announceUnlocks(winInfo.unlocks);
        if (wonInfo.perfect) toast('<span class="tgold">A PERFECT CHARGE</span> — the scribes note it');
        if (marchDone) showOutcome('won', outcomeInfo);
        else showRoute();
      };
    } else if (res.lost) {
      March.marchLost(house, march, res.why === 'wiped' ? 'the column is destroyed' : 'the charges are spent', f.deaths);
      var lostInfo = marchTally('lost', res.why);
      march = null;
      save();
      after = function () {
        Sfx.play('lose');
        refreshRenown(false);
        showOutcome('lost', lostInfo);
      };
    } else {
      march.fieldLive = { st: f.st, deaths: f.deaths, trampled: f.trampled, captainFell: f.captainFell };
      save();
      after = function () {
        /* the ink settles: one sound for what the charge cost or won */
        if (chargeDeaths.length) Sfx.play('death');
        else if (res.trampled.length) Sfx.play('trample');
        else if (res.riders.some(function (r) { return r.refused; })) Sfx.play('refuse');
        if (res.bolts.length && res.bolts.some(function (b) { return b.hit !== null; })) Sfx.play('bolt');
        board.setState(f.st);
        refreshMargin(margin);
        var lines = [];
        if (res.trampled.length) lines.push('<span class="kill">' + (res.trampled.length > 1 ? res.trampled.length + ' foes fall' : '1 foe falls') + '</span>');
        chargeDeaths.forEach(function (d) {
          var m = meta[d.id];
          lines.push('<span class="die">Ser ' + esc(m ? m.name : d.id) + ' ' + esc(d.fate) + '</span>');
        });
        verdict.innerHTML = lines.length ? lines.join(' · ') : 'the banner stands; the field does not yield yet';
        resolving = false;
        board.cv.classList.remove('resolving');
      };
    }

    var isOver = res.won || res.lost;
    board.play(res, function () {
      if (isOver) {
        resolving = false;
        after();
      } else {
        after();
      }
    });
  }

  function marchTally(kind, why) {
    var fallen = house.graveyard.filter(function (g) { return g.march === house.stats.marches; });
    return {
      kind: kind,
      why: why || null,
      tier: march.tier,
      fieldsWon: march.fieldsWon,
      perfects: march.perfects,
      renown: march.renownGained || 0,
      seconds: Math.max(0, Math.round(elapsed - marchT0)),
      fallen: fallen
    };
  }

  function mmss(s) {
    s = Math.max(0, Math.round(s));
    return Math.floor(s / 60) + ':' + ('0' + (s % 60)).slice(-2);
  }

  /* ============================================================ MUSTER */

  function showMuster() {
    lastScreen = showMuster;
    /* `camp` centres the block in the sheet — see the note in banneret.css. */
    var s = el('div', 'screen camp');
    s.appendChild(el('h2', null, 'THE MUSTER'));

    var mo = March.musterChoices(house);
    /* the offers were just rolled (or restored): persist them NOW, so a
       closed tab cannot reroll a bad mutation — the model's own promise */
    save();
    var openOffers = mo.offers.filter(function (_, i) { return mo.taken.indexOf(i) < 0; });

    s.appendChild(el('p', 'sub', openOffers.length
      ? 'The dead are named. Their heirs stand before the banner — <b>look at what the blood carries before you seat it.</b>'
      : 'The House is counted. ' + (mo.recruit && !mo.recruitTaken ? 'A stranger waits by the fire.' : 'The column is whole.')));

    var row = el('div', null); row.id = 'choiceRow';
    s.appendChild(row);

    mo.offers.forEach(function (offer, idx) {
      if (mo.taken.indexOf(idx) >= 0) return;
      var h = offer.heir;
      var card = el('div', 'offer');
      var top = el('div', 'offerTop');
      var cv = document.createElement('canvas');
      top.appendChild(cv);
      top.appendChild(el('div', null,
        '<h3>' + esc(h.name) + '</h3>' +
        '<div class="line">' + ordinalWord(h.gen) + ' of the line of <b>' + esc(offer.pending.sireName) + '</b>, who ' +
        esc(offer.pending.fate) + '.</div>'));
      card.appendChild(top);
      card.appendChild(el('div', 'line', h.traits.length
        ? 'The blood carries: <span class="kTraits">' + h.traits.map(traitChip).join('') + '</span>'
        : 'The blood carries nothing — a clean slate, for good or ill.'));
      var foot = el('div', 'foot');
      foot.appendChild(seal('SEAT THE HEIR', 'gilt', function () { musterPick(idx, 'heir'); }));
      foot.appendChild(seal('PASS THE LANCE', 'ghost', function () { musterPick(idx, 'lance'); }));
      card.appendChild(foot);
      row.appendChild(card);
      Art.paintArms(cv, her, h.gen, 40, 46);
    });

    if (mo.recruit && !mo.recruitTaken) {
      var rc = el('div', 'offer');
      rc.appendChild(el('h3', null, esc(mo.recruit.name)));
      rc.appendChild(el('div', 'line', 'An unproven rider, no lineage, no flaw. He asks to <b>swear to the banner</b>.'));
      var rfoot = el('div', 'foot');
      rfoot.appendChild(seal('TAKE HIS OATH', '', function () {
        var k = March.takeRecruit(house);
        if (k && march && march.rosterIds.length < March.ROSTER_CAP) march.rosterIds.push(k.id);
        save();
        showMuster();
      }));
      rfoot.appendChild(el('span', 'line', 'or let him walk on'));
      rc.appendChild(rfoot);
      row.appendChild(rc);
    }

    /* the column as it stands */
    var colHead = el('div', 'mhead', 'THE COLUMN AS IT RIDES');
    colHead.style.marginTop = '10px';
    s.appendChild(colHead);
    var rost = el('div', 'rost');
    rost.style.flexDirection = 'row';
    rost.style.flexWrap = 'wrap';
    house.roster.forEach(function (k) { rost.appendChild(knightCard(k)); });
    s.appendChild(rost);

    var foot = el('div', 'titleBtns');
    foot.style.marginTop = '12px';
    var cont = seal('SOUND THE ADVANCE', 'gilt', function () {
      if (cont.disabled) return;
      cont.disabled = true;
      March.closeMuster(house, march);     /* the column re-forms: Orders come back */
      leaveCamp();
    });
    if (openOffers.length) {
      cont.disabled = true;
      cont.title = 'Every heir must be seated or set aside first.';
    }
    foot.appendChild(cont);
    s.appendChild(foot);

    swapScreen(s);
    setHint(openOffers.length
      ? 'A rolled heir is <b>rolled once</b>. Reloading the page will not change what the blood carries.'
      : 'The march waits on your word.');
  }

  function musterPick(idx, choice) {
    var k = March.applyMusterChoice(house, idx, choice);
    if (k && march && march.rosterIds.length < March.ROSTER_CAP) march.rosterIds.push(k.id);
    if (choice === 'heir') Sfx.play('heir');
    save();
    showMuster();
  }

  /* ============================================================ SHRINE */

  function showShrine(pickingFor) {
    lastScreen = function () { showShrine(); };
    var s = el('div', 'screen camp');
    s.appendChild(el('h2', null, 'THE WAYSHRINE'));

    if (pickingFor) {
      /* choose the knight the rite touches */
      s.appendChild(el('p', 'sub', pickingFor.id === 'cleanse'
        ? 'Name the knight to be <b>shriven of a flaw</b>.'
        : 'Name the knight the shrine will <b>anoint</b>.'));
      var rost = el('div', 'rost');
      rost.style.flexDirection = 'row';
      rost.style.flexWrap = 'wrap';
      var eligible = house.roster.filter(function (k) {
        if (pickingFor.id === 'cleanse') {
          return k.traits.some(function (t) { return March.NEGATIVE.indexOf(t) >= 0; });
        }
        return k.traits.length < March.TRAIT_CAP;
      });
      eligible.forEach(function (k) {
        var card = knightCard(k, { cls: 'selectable' });
        card.addEventListener('click', function () {
          if (!march.node) return;    /* already resolved */
          var ok = March.applyShrine(house, march, pickingFor.id, k.id);
          if (ok) leaveCamp();
        });
        rost.appendChild(card);
      });
      if (!eligible.length) rost.appendChild(el('p', 'sub', 'No knight in the column can receive this rite.'));
      s.appendChild(rost);
      var back = el('div', 'titleBtns');
      back.style.marginTop = '12px';
      back.appendChild(seal('STEP BACK', 'ghost', function () { showShrine(); }));
      s.appendChild(back);
      swapScreen(s);
      setHint('The rite is spent the moment it is given.');
      return;
    }

    s.appendChild(el('p', 'sub', 'Two rites are offered. Take one, or ride on and owe the old blood nothing.'));
    var row = el('div', null); row.id = 'choiceRow';
    /* ⛔ The shrine offers TWO rites of two lines each; the muster offers three
       heirs with lineage, traits and flaws. #choiceRow stretches its cards to
       fill the row, which is right for the muster and left the shrine as two
       tall cards roughly 60% EMPTY — dead space a player sees, and a Gate 1
       failure in the gallery. Same defect the RPG Maker wing recorded as "size
       windows to their contents". This class opts the shrine out of stretching;
       the muster keeps it. */
    row.className = 'shrineRow';
    var offers = March.shrineOffers(house, march);
    save();   /* same rolled-once promise as the muster */
    offers.forEach(function (o) {
      var card = el('div', 'offer');
      card.appendChild(el('h3', null, esc(o.label)));
      card.appendChild(el('div', 'line', esc(o.text)));
      var foot = el('div', 'foot');
      foot.appendChild(seal('KNEEL', 'gilt', function () {
        if (!march.node) return;      /* already resolved */
        if (o.id === 'farrier') {
          March.applyShrine(house, march, 'farrier', null);
          leaveCamp();
        } else {
          showShrine(o);
        }
      }));
      card.appendChild(foot);
      row.appendChild(card);
    });
    s.appendChild(row);

    var foot2 = el('div', 'titleBtns');
    foot2.style.marginTop = '12px';
    foot2.appendChild(seal('RIDE ON', 'ghost', function () {
      if (!march.node) return;        /* already resolved */
      leaveCamp();
    }));
    s.appendChild(foot2);

    swapScreen(s);
    setHint('A flaw shriven here <b>never breeds again</b>. A virtue granted here can.');
  }

  /* ========================================================= CHRONICLE */

  function showChronicle() {
    var backTo = lastScreen || showTitle;
    var s = el('div', 'screen');
    s.appendChild(el('h2', null, 'THE CHRONICLE'));
    s.appendChild(el('p', 'sub', 'House ' + esc(house.name) + ', as the scribe keeps it. ' +
      house.stats.marches + ' march' + (house.stats.marches === 1 ? '' : 'es') + ' · ' +
      house.stats.victories + ' victor' + (house.stats.victories === 1 ? 'y' : 'ies') + ' · ' +
      house.stats.trampled + ' foes trampled.'));

    var scroll = el('div', null); scroll.id = 'chronScroll';
    var lines = house.chronicle.slice(-220);
    lines.forEach(function (line) {
      var cls = 'chronLine';
      if (line.charAt(0) === '(') cls += ' gain';
      else if (/VICTORY|begins|raises its banner/.test(line)) cls += ' big';
      else if (/dies|died|shot|pikes|ends\.|fails/.test(line)) cls += ' death';
      scroll.appendChild(el('p', cls, esc(line)));
    });
    if (house.graveyard.length) {
      scroll.appendChild(el('p', 'chronLine big', 'THE MEMORIAL'));
      house.graveyard.slice(-40).forEach(function (g) {
        scroll.appendChild(el('div', 'graveRow',
          '<span class="gname">' + esc(g.name) + '</span>' +
          '<span class="gfate">' + esc(g.fate) + ' — march ' + g.march + '</span>'));
      });
    }
    s.appendChild(scroll);

    var foot = el('div', 'titleBtns');
    foot.style.marginTop = '10px';
    foot.appendChild(seal('RETURN', 'ghost', function () { backTo(); }));
    s.appendChild(foot);

    swapScreen(s);
    setHint('Everything the House has done, and everyone it has buried.');
  }

  /* =========================================================== OUTCOME */

  function showOutcome(kind, info) {
    lastScreen = showTitle;
    var s = el('div', 'screen');
    var wrap = el('div', null); wrap.id = 'outcomeWrap';
    s.appendChild(wrap);

    /* a <p> for the same reason as the title: .screen h2 would out-rank it */
    wrap.appendChild(el('p', 'outcomeTitle ' + kind,
      kind === 'won' ? 'THE STANDARD FALLS' : 'THE MARCH FAILS'));
    wrap.appendChild(el('p', 'outcomeBody', kind === 'won'
      ? 'The enemy Standard is cast down and dragged home behind the column. The scribes will need a second candle tonight.'
      : (info.why === 'wiped'
        ? 'The banner lies in the mud and no hand lifts it. The column is gone — but the House is not. The chronicle keeps what the field took.'
        : 'The horses are blown and the charges are spent. The column turns for home — but the House endures, and the chronicle keeps every name.')));

    var tally = el('div', 'tally');
    tally.appendChild(el('div', null, '<span class="tv">' + info.fieldsWon + '</span><span class="tl">fields won</span>'));
    tally.appendChild(el('div', null, '<span class="tv">' + info.perfects + '</span><span class="tl">perfect charges</span>'));
    tally.appendChild(el('div', null, '<span class="tv">' + info.renown + '</span><span class="tl">renown</span>'));
    /* under a minute the chronometer is noise, not a boast — a real march
       cannot finish that fast, so the tile only earns its place at 1:00+ */
    if (info.seconds >= 60) {
      tally.appendChild(el('div', null, '<span class="tv">' + mmss(info.seconds) + '</span><span class="tl">in the saddle</span>'));
    }
    tally.appendChild(el('div', null, '<span class="tv">' + info.fallen.length + '</span><span class="tl">the fallen</span>'));
    wrap.appendChild(tally);

    if (info.fallen.length) {
      var g = el('div', null);
      info.fallen.slice(0, 5).forEach(function (d) {
        g.appendChild(el('div', 'graveRow',
          '<span class="gname">' + esc(d.name) + '</span>' +
          '<span class="gfate">' + esc(d.fate) + '</span>'));
      });
      wrap.appendChild(g);
    }

    var btns = el('div', 'titleBtns');
    btns.appendChild(seal(info.fallen.length ? 'BURY THE DEAD, KEEP THE NAME' : 'RETURN TO THE KEEP', 'gilt', function () { showTitle(); }));
    btns.appendChild(seal('THE CHRONICLE', 'ghost', function () { showChronicle(); }));
    wrap.appendChild(btns);

    swapScreen(s);
    setHint(kind === 'won' ? 'Renown compounds. <b>The next march will be harder, and yours.</b>'
                           : 'Defeat ends the march, <b>never the House</b>.');
  }

  /* ============================================================ RESUME */

  function resumeFlow() {
    if (!house) return showTitle();
    if (!march) return showTitle();
    marchT0 = elapsed;   /* the chronometer counts this sitting, honestly */
    if (march.node) {
      if (march.node.type === 'muster') return showMuster();
      if (march.node.type === 'shrine') return showShrine();
      if (march.node.field) return showField(!!march.fieldLive);
    }
    return showRoute();
  }

  /* ============================================================== BOOT */

  document.getElementById('btnChronicle').addEventListener('click', function () {
    if (house) showChronicle();
  });

  window.addEventListener('resize', function () {
    if (board) {
      board.layout();
    }
  });

  /* Keyboard play: arrows steer a cursor on the field, Enter (or Space)
     plants the banner there. The cursor starts on the free tile nearest
     the centre and follows the mouse, so the two never fight. */
  window.addEventListener('keydown', function (ev) {
    if (!board || !fieldCtx || resolving || !fieldUI) return;
    if (ev.ctrlKey || ev.altKey || ev.metaKey) return;
    var k = ev.key;
    if (k === 'Enter' || k === ' ') {
      ev.preventDefault();
      commitAt(kbCursor || defaultCursor());
      return;
    }
    /* Orders on 1/2/3, in the order the House unlocked them, and Escape
       to stand them down. Mouse and keyboard reach the same two calls. */
    if (k === '1' || k === '2' || k === '3') {
      var avail = March.availableOrders(house);
      var pick = avail[+k - 1];
      if (pick) { ev.preventDefault(); armOrder(pick); }
      return;
    }
    if (k === 'Escape' && armedOrder) { ev.preventDefault(); disarmOrder(); return; }
    var dx = k === 'ArrowLeft' ? -1 : k === 'ArrowRight' ? 1 : 0;
    var dy = k === 'ArrowUp' ? -1 : k === 'ArrowDown' ? 1 : 0;
    if (!dx && !dy) return;
    ev.preventDefault();
    var lv = fieldCtx.level;
    var c = kbCursor || defaultCursor();
    if (!c) return;
    var nx = Math.max(0, Math.min(lv.w - 1, c.x + dx));
    var ny = Math.max(0, Math.min(lv.h - 1, c.y + dy));
    kbCursor = { x: nx, y: ny };
    previewAt(kbCursor);
  });

  /* The march chronometer. rAF-driven on purpose: if the page's event
     loop stalls (the failure the gate hunts), this clock stops with it. */
  var _tickPrev = 0;
  function _tick(ts) {
    if (_tickPrev && march) elapsed += Math.min(64, ts - _tickPrev) / 1000;
    _tickPrev = ts;
    window.requestAnimationFrame(_tick);
  }
  window.requestAnimationFrame(_tick);

  /* ⚠️ KEEP THIS SHORT. The footline is one flex row with the hint text, and
     'SUCCESSION · V1.2 THE DOWNS · A CSAF GAME' wrapped it onto a second line
     that overlapped the hint — caught by LOOKING at shot_2_preview, not by any
     check. Same length as the v1.0 string it replaced. */
  document.getElementById('version').textContent = 'SUCCESSION · V1.2 · A CSAF GAME';

  /* the mute toggle lives in the footline and survives sessions */
  var muteBtn = el('button', 'seal ghost', Sfx.isMuted() ? 'SOUND: OFF' : 'SOUND: ON');
  muteBtn.type = 'button';
  muteBtn.id = 'btnMute';
  muteBtn.addEventListener('click', function () {
    var m = Sfx.toggleMute();
    /* v1.1.0: this button existed and silenced ONLY the SFX. With a score
       shipping, a control labelled SOUND that leaves the music playing is a
       control that lies about what it does. */
    if (typeof Music !== 'undefined' && Music) { try { Music.setMuted(m); } catch (e) {} }
    muteBtn.textContent = m ? 'SOUND: OFF' : 'SOUND: ON';
    if (!m) Sfx.play('click');
  });
  /* Honour a mute persisted from a previous session on the music layer too. */
  if (typeof Music !== 'undefined' && Music) { try { Music.setMuted(Sfx.isMuted()); } catch (e) {} }
  document.getElementById('footline').insertBefore(muteBtn, document.getElementById('version'));

  /* the toast lives on the sheet so it can float over any screen */
  var toastEl = el('div'); toastEl.id = 'toast';
  document.getElementById('sheet').appendChild(toastEl);

  load();
  refreshCrest();
  showTitle();

  /* ---------------------------------------------------------- test surface

     Consumed by Kernel/engines/html5_gate.js (contract in its header).
     begin() raises a House if none stands, opens a tier-1 march, walks the
     opening camp with the same model calls the camp buttons make, and lands
     on the first field — where the chronometer runs and the board is live.
     The inputProbe is the KEYBOARD feature, not scaffolding: Enter plants
     the banner at the cursor (free tile nearest centre until the arrows or
     the mouse move it), which commits a real charge, which increments
     `chargesCommitted`. What gets proved is the window-level event wiring —
     the part that actually breaks inside the itch iframe. */
  function testBegin() {
    if (resolving) return;
    if (!house) {
      house = March.newHouse((Date.now() ^ (Math.random() * 0x7fffffff)) | 0);
      refreshCrest();
    }
    if (!march) {
      ensureRoster();
      march = March.newMarch(house, 1);
      marchT0 = elapsed;
      save();
    }
    var guard = 0;
    while (guard++ < 10) {
      var node = march.node || March.choose(march, house, FIELDS, 0);
      if (!node) { showRoute(); return; }
      if (node.type === 'muster' || node.type === 'shrine') {
        /* the same order leaveCamp() uses: resolve, then advance, then save */
        if (node.type === 'muster') March.closeMuster(house, march);
        march.node = null;
        March.advance(march, house);
        save();
        continue;
      }
      showField(false);
      return;
    }
  }

  window.__game = {
    get elapsed() { return elapsed; },
    get charges() { return chargesCommitted; },
    get houseName() { return house ? house.name : null; },
    begin: testBegin,
    inputProbe: {
      events: [{ type: 'keydown', init: { key: 'Enter', code: 'Enter', bubbles: true } }],
      read: function () { return chargesCommitted; },
      settleMs: 320
    },

    /* Harness only — Internal_Ops/Capture/capture.js. Every stager uses
       the model's OWN calls, so every staged screen is a real, reachable
       state — the deep sibling's precedent: never stage a picture play
       cannot produce (its Antipole shipped two dim death screens before
       that rule existed). */
    _h: {
      raise: function (seed) {
        house = March.newHouse((seed == null ? 1337 : seed) | 0);
        ensureRoster(); refreshCrest(); showTitle();
      },
      ride: function (tier) {
        ensureRoster(); march = March.newMarch(house, tier || 1);
        marchT0 = elapsed; save(); showRoute();
      },
      field: function () {
        var guard = 0;
        while (guard++ < 10) {
          var node = march.node || March.choose(march, house, FIELDS, 0);
          if (!node) { showRoute(); return false; }
          if (node.type === 'muster' || node.type === 'shrine') {
            if (node.type === 'muster') March.closeMuster(house, march);
            march.node = null; March.advance(march, house); save(); continue;
          }
          showField(false); return true;
        }
        return false;
      },
      fell: function (n) {
        var ids = (march ? march.rosterIds : house.roster.map(function (k) { return k.id; })).slice(0, n || 1);
        ids.forEach(function (id) { March.recordDeath(house, march, id, 'died on the pikes before the walls'); });
        save();
      },
      renown: function (n) { March.grantRenown(house, n | 0); refreshCrest(); save(); },
      winMarch: function () {
        /* the same calls clickField's won-branch makes, so the tally on
           the outcome screen is real model state end to end — and camps
           are walked as camps, never counted as field wins */
        var guard = 0;
        while (guard++ < 60) {
          var node = march.node || March.choose(march, house, FIELDS, 0);
          if (node && (node.type === 'muster' || node.type === 'shrine')) {
            if (node.type === 'muster') March.closeMuster(house, march);
            march.node = null;
            if (March.advance(march, house) === 'won') break;
            continue;
          }
          var w = March.fieldWon(house, march,
            { moves: 3, minMoves: 3, trampled: 4, captainFell: false, deaths: [] });
          march.renownGained = (march.renownGained || 0) + w.renown;
          if (March.advance(march, house) === 'won') break;
        }
        var winInfo = March.marchWon(house, march);
        march.renownGained += winInfo.renown;
        var info = marchTally('won');
        march = null; save(); refreshRenown(false);
        showOutcome('won', info);
      },
      title: function () { showTitle(); },
      route: function () { showRoute(); },
      muster: function () { showMuster(); },
      shrine: function () { showShrine(); },
      chronicle: function () { showChronicle(); },
      /* read-only peeks for the capture script's stage assertions */
      fieldCtx: function () { return fieldCtx; },
      board: function () { return board; },
      house: function () { return house; },
      march: function () { return march; },
      /* v1.2: the two input paths, exposed so Internal_Ops/playtest_v12.js
         drives the SAME functions a click and a keypress drive. A test that
         reaches past the UI into the model proves the model, which 90 unit
         tests already do; the point of the playtest is the wiring. */
      previewAt: function (cell) { previewAt(cell); },
      commitAt: function (cell) { commitAt(cell); },
      armOrder: function (id) { armOrder(id); },
      armedOrder: function () { return armedOrder; }
    }
  };

})();
