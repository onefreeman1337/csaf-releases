# BANNERET: SUCCESSION

**Plant the banner and every knight charges it at once. Knights who fall are dead
— their heirs inherit a trait, and sometimes a flaw.**

The first Banneret asked one question: where does the banner land? SUCCESSION asks
the second one: **who is left to ride at it, and whose blood are they carrying?**

---

## NEW IN v1.2 — THE DOWNS

Two systems, both of which bend **momentum** — the thing every other rule in this
game already spends. They do not sit beside the game; they run through it.

**THE DOWNS — the ground is no longer flat.**

- **Crest.** A blow struck while riding *down* off the high ground carries an extra
  tile of weight. One tile of run, taken downhill, smashes a pikewall that needs two.
- **Climb.** Riding *up* onto a ridge needs a run. From a standing start the horse
  balks at the bank — and a knight stopped at the foot of a hill beside a pike is
  the stall rule, which is to say a death.

High ground is drawn the way a period map draws it: a crest line with **hachures**
running downhill. Your first three fields are deliberately flat; the ridges start
in act II, once the charge itself is second nature.

**THE ORDERS — a spendable stock, replenished at every muster.**

| | | |
| --- | --- | --- |
| **1** | **THE HORN** | No knight stall-dies this charge. |
| **2** | **THE WHEEL** | Ties break *vertical* this charge instead of horizontal. |
| **3** | **THE REIN** | One named knight holds his ground and does not ride. |

An order rides with the plant and is spent when the banner lands — and the hover
preview shows exactly what it will do *before* you commit, because the preview is
the same function the charge is.

**Two more bloodlines,** taking the pool to eight: **hillman** takes a bank from a
standing start, **shieldbearer** turns one crossbow bolt aside per field.

**The ladder is more than twice as long** — ten rungs to renown 24, alternating
new blood, new orders and harder marches, so there is always another rung four or
five fields out. **Old saves keep everything:** a House that earned renown under
v1.1 is handed every rung it had already paid for, and is told so on the title
screen.

---

## The charge (unchanged, and still the whole law)

- You never move a knight. You plant a **banner**; every knight charges it at once.
- Each knight rides the axis it is **furthest** from the banner on. Ties go
  horizontal. Direction is locked the moment the banner lands.
- **Momentum kills.** A knight that rides even one tile tramples the soft foe it
  lands on. A knight that never started its charge **dies where it stands**.
- Pikes kill stalled knights. Pikewalls need momentum 2+ to smash. Crossbows fire
  down their line after every charge. Captains step. Caltrops end the gallop.
  **High ground adds a tile of weight downhill and costs you the climb going up.**
- Hover before you commit — the preview shows **every** track, kill, bolt and
  death the charge would cause. Then click. Or steer with the **arrow keys** and
  plant with **Enter**.

## The succession (new, and the reason for the name)

- Dead knights are **dead**. At the next muster their **heirs** stand before the
  banner: seat the heir, or pass the lance and end the line.
- Blood carries. An heir inherits a trait from the sire — *ironshod, steady,
  longlance, outrider, reckless* — **and sometimes a flaw**. A craven line will
  refuse a defended banner at the worst possible moment.
- Renown compounds across marches: wayshrines, deeper trait pools, and two
  harder marches unlock as the chronicle fills.
- Wayshrines can **cleanse a flaw for good** or anoint a virtue that breeds on.

## The march

Three acts, five steps each, two roads at most forks. Battles, ambushes, the
captain's field, and at the end of act III, the enemy Standard. Defeat ends the
march — **never the House**. The chronicle keeps every name and every grave.

## Saving

The game saves **at every click**, before the animation plays. Close the tab
mid-field and nothing is lost: CONTINUE resumes the exact spot. Death is never a
full restart — the House endures, renown intact.

## Controls

| Input | Effect |
| --- | --- |
| Hover | preview the whole charge before committing |
| Click | plant the banner |
| Arrow keys | steer the field cursor |
| Enter / Space | plant at the cursor |
| 1 / 2 / 3 | arm an Order (once the House has earned them) |
| Escape | stand the armed Order down |
| SOUND ON/OFF (footline) | toggle sound and music; the choice persists |

## Sound

Two music loops in the same mode: a slow hall theme built on a sustained open
fifth with no third in it — medieval organum, the sound of a chapel rather than
a chord — and a faster march that keeps the mode, drops the drone and adds a
tabor. The mode is the house; the articulation is the situation.

Both were composed as note data and rendered by oscillator: nothing here is
sampled and nothing is model-generated audio. The sound effects are synthesised
at runtime by **ZzFX** (© 2019 Frank Force, MIT licence; the notice is retained
in `js/sound.js`).

**AI disclosure:** this game's code and its store graphics are AI-generated, and
its written text is AI-authored. Its sound and music are procedural synthesis
from code, not generative audio. Disclosed truthfully on every storefront it
appears on.

---

Made by **CSAF** — Core Systems Asset Factory.

More from us on itch: **https://csaf.itch.io** — including the original
**Banneret**, **Wicklight**, **Antipole**, and our RPG Maker / GameMaker /
Unity / Unreal developer tools.
