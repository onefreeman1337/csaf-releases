/// wnt_core.gml - the pure layer every Wanted poster is computed from: a stable string hash, deterministic noise, and
/// the COLOUR rules (luminance, WCAG contrast, the absolute-separation relief, the solved ink) plus the two spacing
/// laws (a pitch, never a count; a pen sized from the shape it outlines). NO drawing and no engine state in this file.
///
/// Wanted - Every Bounty Prints Its Own Poster, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// Colours in this layer are [r, g, b] arrays of 0-255 numbers. wnt_col() turns one into a GameMaker colour at the
/// moment it is drawn.
///
/// ⛔ THIS FILE IS A PORT HELD TO ITS ORIGINAL. Every function below reproduces the published RPG Maker MZ Wanted
/// arithmetic bit for bit, and the in-engine suite checks it against values the original computed (wnt_oracle.gml):
///   - 32-bit integer arithmetic goes through wnt_mul32 (a GML real holds 53 bits exactly, a 32 x 32 product needs 64),
///   - JavaScript's Math.round is floor(x + 0.5), written wnt_jsround, because GML's round() is not the same function,
///   - comparisons that decide a colour run with the comparison epsilon at ZERO (GML's default 0.00001 flips a
///     boundary the original decides exactly) and restore the caller's epsilon.

/// @function wnt_mul32(a, b)
/// @description The low 32 bits of a * b for two unsigned 32-bit numbers (JavaScript's Math.imul, unsigned). Pure.
function wnt_mul32(_a, _b) {
    _a = _a & $FFFFFFFF;
    _b = _b & $FFFFFFFF;
    var _lo = (_a & $FFFF) * _b;
    var _hi = (((_a >> 16) & $FFFF) * _b) & $FFFF;
    return (_lo + (_hi << 16)) & $FFFFFFFF;
}

/// @function wnt_u32(v)
/// @description A number as JavaScript's ToUint32 sees it: truncated toward zero, then wrapped into 0..2^32-1. Pure.
function wnt_u32(_v) {
    if (!is_numeric(_v)) return 0;
    var _t = (_v >= 0) ? floor(_v) : -floor(-_v);
    _t = _t - floor(_t / 4294967296) * 4294967296;
    return _t & $FFFFFFFF;
}

/// @function wnt_jsround(v)
/// @description JavaScript's Math.round: halves round UP (toward +infinity). Pure.
function wnt_jsround(_v) { return floor(_v + 0.5); }

/// @function wnt_hash(text)
/// @description A stable 32-bit FNV-1a hash of a string: the same bounty gives the same poster forever, on every
/// machine. Pure. Anything that is not a string is hashed as its string form.
function wnt_hash(_s) {
    _s = string(_s);
    var _h = 2166136261;
    var _n = string_length(_s);
    for (var _i = 1; _i <= _n; _i++) {
        _h = (_h ^ (ord(string_char_at(_s, _i)) & $FFFF)) & $FFFFFFFF;
        _h = wnt_mul32(_h, 16777619);
    }
    return _h;
}

/// @function wnt_nz(i)
/// @description Deterministic noise in [0, 1) for surface texture. Never random(): a poster reseeded per frame would
/// shimmer, and a quarry's poster must be the same sheet in every session. Pure.
function wnt_nz(_i) {
    var _h = wnt_mul32(wnt_u32(_i) ^ $9E3779B9, $85EBCA6B);
    _h = (_h ^ (_h >> 13)) & $FFFFFFFF;
    _h = wnt_mul32(_h, $C2B2AE35);
    return ((_h ^ (_h >> 16)) & $FFFFFFFF) / 4294967296;
}

// ---------------------------------------------------------------------------------------------------------------
// Colour
// ---------------------------------------------------------------------------------------------------------------

#macro WNT_AAA_RATIO 7
#macro WNT_AA_RATIO 4.5

/// @function wnt_lum(c)
/// @description Perceived luminance on the 0..255 scale (Rec.709 weights), for RELIEF decisions. It is NOT the
/// instrument for text legibility; wnt_contrast() is. Pure.
function wnt_lum(_c) { return 0.2126 * _c[0] + 0.7152 * _c[1] + 0.0722 * _c[2]; }

/// @function wnt_linear(v)
/// @description One sRGB channel (0..255) linearised to 0..1, per IEC 61966-2-1. Pure.
function wnt_linear(_v) {
    var _s = _v / 255;
    return (_s <= 0.04045) ? _s / 12.92 : power((_s + 0.055) / 1.055, 2.4);
}

/// @function wnt_rel_lum(c)
/// @description Relative luminance 0..1 as the WCAG definition computes it. Pure.
function wnt_rel_lum(_c) { return 0.2126 * wnt_linear(_c[0]) + 0.7152 * wnt_linear(_c[1]) + 0.0722 * wnt_linear(_c[2]); }

/// @function wnt_contrast(a, b)
/// @description The WCAG 2.x contrast ratio between two colours, 1 (identical) to 21 (black on white). The bar this
/// product holds its lettering to is WCAG's own 7:1 (AAA), published long before this product existed. Pure.
function wnt_contrast(_a, _b) {
    var _la = wnt_rel_lum(_a), _lb = wnt_rel_lum(_b);
    return (max(_la, _lb) + 0.05) / (min(_la, _lb) + 0.05);
}

/// @function wnt_b255(v)
/// @description Clamp to a byte, rounding as JavaScript does. Pure.
function wnt_b255(_v) { return max(0, min(255, wnt_jsround(_v))); }

/// @function wnt_mix(a, b, t)
/// @description Mix two [r, g, b] colours; t = 0 returns a, 1 returns b. Pure.
function wnt_mix(_a, _b, _t) {
    return [wnt_b255(_a[0] + (_b[0] - _a[0]) * _t), wnt_b255(_a[1] + (_b[1] - _a[1]) * _t), wnt_b255(_a[2] + (_b[2] - _a[2]) * _t)];
}

/// @function wnt_col(c)
/// @description An [r, g, b] colour as a GameMaker colour.
function wnt_col(_c) { return make_colour_rgb(wnt_b255(_c[0]), wnt_b255(_c[1]), wnt_b255(_c[2])); }

/// @function wnt_headroom(c, dir)
/// @description Luminance levels available from a colour toward white (dir > 0) or black. An assertion about relief
/// must be written min(delta, headroom): there is nothing lighter than white. Pure.
function wnt_headroom(_c, _dir) { return (_dir > 0) ? 255 - wnt_lum(_c) : wnt_lum(_c); }

/// @function wnt_relief(c, dir, delta)
/// @description A raised (dir > 0) or shadowed version of a colour, separated from it by an ABSOLUTE luminance
/// delta - as close to `delta` as the headroom allows, with a small proportional floor so a bright surface still takes
/// a natural relief. ⛔ A multiplier would move a bright base far and a dark one barely; this is why a grain reads on
/// jet for the same reason it reads on bone. Pure.
function wnt_relief(_c, _dir, _delta) {
    var _target = (_dir > 0) ? [255, 255, 255] : [0, 0, 0];
    var _here = wnt_lum(_c);
    var _head = (_dir > 0) ? 255 - _here : _here;
    if (_head <= 0.5) return [_c[0], _c[1], _c[2]];
    var _want = min(_delta, _head);
    var _t = max(_want / _head, 0.06);
    return wnt_mix(_c, _target, min(1, _t));
}

/// @function wnt_field_extreme(field, amp, ink_is_pale)
/// @description The field at its LEAST legible: a textured ground is not a flat colour, so an ink is solved against
/// the excursion that moves the field toward the ink. Pure.
function wnt_field_extreme(_field, _amp, _pale) {
    return wnt_mix(_field, _pale ? [255, 255, 255] : [0, 0, 0], is_numeric(_amp) ? _amp : 0);
}

/// @function wnt_ink_for(field, frame, want_ratio, [amp])
/// @description Solve an ink for text on `field` under a ground of amplitude `amp`: walk from the material's own body
/// colour toward white and toward black, return the FIRST colour to clear the ratio (so the ink keeps as much of the
/// object's hue as contrast allows), else the most separated colour that exists. Pure.
function wnt_ink_for(_field, _frame, _want, _amp = 0) {
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _out = undefined, _outRatio = -1, _res = undefined;
    for (var _d = 0; _d < 2 && is_undefined(_res); _d++) {
        var _pale = (_d == 0);
        var _target = _pale ? [255, 255, 255] : [0, 0, 0];
        var _against = wnt_field_extreme(_field, _amp, _pale);
        for (var _t = 0; _t <= 1.0001; _t += 0.02) {
            var _best = wnt_mix(_frame, _target, _t);
            var _got = wnt_contrast(_best, _against);
            if (_got >= _want) { _res = _best; break; }
            if (_got > _outRatio) { _outRatio = _got; _out = _best; }
        }
    }
    math_set_epsilon(_eps);
    if (!is_undefined(_res)) return _res;
    return is_undefined(_out) ? [_frame[0], _frame[1], _frame[2]] : _out;
}

// ---------------------------------------------------------------------------------------------------------------
// The two spacing laws
// ---------------------------------------------------------------------------------------------------------------

#macro WNT_PAPER_MIN 2.6

/// @function wnt_repeats_for(run, thickness, pitch_mul, [paper_min])
/// @description How many marks of a repeated treatment fit along a run: {count, pitch, floored}. ⛔ It returns a
/// RECORD - read `.count`. The pitch is a multiple of the band's own thickness, floored at an ABSOLUTE gap of paper
/// between marks, because the eye reads the gap and not the proportion. Pure.
function wnt_repeats_for(_run, _thick, _mul, _paper = WNT_PAPER_MIN) {
    var _wanted = _thick * _mul;
    var _least = _thick + _paper;
    var _pitch = max(_wanted, _least);
    var _count = (_pitch > 0) ? max(0, floor(_run / _pitch)) : 0;
    return { count: _count, pitch: _pitch, floored: _wanted < _least };
}

/// @function wnt_pen_for(figure_ink, w, h)
/// @description The pen for outlining a shape, from the SHAPE's own short side (8% of it) and never wider than the
/// figure's ink. Pure.
function wnt_pen_for(_ink, _w, _h) { return max(0.9, min(_ink, min(_w, _h) * 0.08)); }
