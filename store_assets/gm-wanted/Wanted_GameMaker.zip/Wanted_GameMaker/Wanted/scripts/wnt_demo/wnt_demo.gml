/// wnt_demo.gml - the demo room's logic: a town bounty board of eight posters you can post, claim, expire and replace,
/// and an examine view of the selected one. Not needed at runtime: delete it with obj_wnt_demo and rm_wnt_demo.
///
/// Wanted - Every Bounty Prints Its Own Poster, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// Read this file as the quickstart: everything a game needs is wnt_poster(spec) once per bounty, wnt_poster_draw()
/// to show it, a new wnt_poster() when the bounty changes, and wnt_poster_free() in Clean Up.

/// @function wnt_demo_bounty(i)
/// @description The i-th demo bounty: a quarry from the corpus, a reward, a jurisdiction and a charge. Pure.
function wnt_demo_bounty(_i) {
    var _ids = wnt_quarry_ids();
    var _jur = ["THE FREE TOWN OF ALDERMOOR", "THE PORT OF SALTBRIDGE", "THE MARCH OF HOLLOWAY", "THE COUNTY OF GREYFELL", "THE ABBEY LANDS OF ST. OSWIN"];
    var _crime = ["for depredations upon the common herd", "for the burning of the mill at Harrow Ford", "for terrors visited upon the night road",
        "for the death of the ferryman", "for blighting the east orchards", "for the taking of nine sheep and a dog"];
    var _q = _ids[(_i * 5 + 2) mod array_length(_ids)];
    return { quarryId: _q, reward: 50 + ((_i * 137) mod 20) * 25, jurisdiction: _jur[_i mod array_length(_jur)], crime: _crime[_i mod array_length(_crime)], status: "posted" };
}

/// @function wnt_demo_state()
/// @description A fresh demo: eight bounties on the board, the first selected.
function wnt_demo_state() {
    var _d = { specs: [], posters: [], sel: 0, next: 8, note: "Eight bounties, eight posters - every one drawn from its own record." };
    for (var _i = 0; _i < 8; _i++) { var _s = wnt_demo_bounty(_i); array_push(_d.specs, _s); array_push(_d.posters, wnt_poster(_s)); }
    return _d;
}

/// @function wnt_demo_slot(i)
/// @description The board rectangle and tilt of slot i: {x, y, w, h, a}. Pure.
function wnt_demo_slot(_i) {
    return { x: 52 + (_i mod 4) * 192, y: 118 + (_i div 4) * 282, w: 168, h: 252, a: (wnt_nz(_i * 7 + 3) - 0.5) * 5 };
}

/// @function wnt_demo_set(d, status)
/// @description Change the selected bounty's status and print its poster again.
function wnt_demo_set(_d, _status) {
    var _s = _d.specs[_d.sel];
    _s.status = _status;
    _d.posters[_d.sel] = wnt_poster(_s);
    _d.note = (_status == "claimed") ? "Claimed: the seal splits and CLAIMED is overprinted across the sheet."
        : ((_status == "expired") ? "Expired: the sheet is overprinted EXPIRED in a second ink." : "Posted again, clean.");
}

/// @function wnt_demo_step(d)
/// @description Keyboard and mouse: arrows select, C claim, X expire, P post again, N a new bounty, click to select.
function wnt_demo_step(_d) {
    if (keyboard_check_pressed(vk_right)) _d.sel = (_d.sel + 1) mod 8;
    if (keyboard_check_pressed(vk_left)) _d.sel = (_d.sel + 7) mod 8;
    if (keyboard_check_pressed(vk_down) || keyboard_check_pressed(vk_up)) _d.sel = (_d.sel + 4) mod 8;
    if (keyboard_check_pressed(ord("C"))) wnt_demo_set(_d, "claimed");
    if (keyboard_check_pressed(ord("X"))) wnt_demo_set(_d, "expired");
    if (keyboard_check_pressed(ord("P"))) wnt_demo_set(_d, "posted");
    if (keyboard_check_pressed(ord("N"))) {
        var _s = wnt_demo_bounty(_d.next);
        _d.next += 1;
        _d.specs[_d.sel] = _s;
        _d.posters[_d.sel] = wnt_poster(_s);
        _d.note = "A new bounty: " + wnt_quarry_name(_s.quarryId) + ", " + string(_s.reward) + " gold.";
    }
    if (mouse_check_button_pressed(mb_left)) {
        var _mx = device_mouse_x_to_gui(0), _my = device_mouse_y_to_gui(0);
        for (var _i = 0; _i < 8; _i++) { var _r = wnt_demo_slot(_i); if (_mx >= _r.x && _mx < _r.x + _r.w && _my >= _r.y && _my < _r.y + _r.h) _d.sel = _i; }
    }
}

/// @function wnt_demo_board(x, y, w, h)
/// @description A plank board for the posters to hang on (drawn, not an image).
function wnt_demo_board(_x, _y, _w, _h) {
    var _pw = 64, _n = ceil(_w / _pw);
    for (var _i = 0; _i < _n; _i++) {
        var _t = wnt_nz(_i * 13 + 5);
        var _c0 = merge_colour(make_colour_rgb(92, 64, 42), make_colour_rgb(70, 47, 31), _t);
        var _c1 = merge_colour(_c0, c_black, 0.18);
        var _x0 = _x + _i * _pw, _x1 = min(_x + _w, _x0 + _pw);
        draw_rectangle_colour(_x0, _y, _x1, _y + _h, _c0, _c1, _c1, _c0, false);
        for (var _k = 0; _k < 7; _k++) {
            var _gx = _x0 + 6 + wnt_nz(_i * 31 + _k) * (_pw - 12);
            draw_set_alpha(0.18); draw_set_colour(make_colour_rgb(40, 26, 16));
            draw_line_width(_gx, _y, _gx + (wnt_nz(_i * 37 + _k) - 0.5) * 10, _y + _h, 1);
        }
        draw_set_alpha(0.55); draw_set_colour(make_colour_rgb(30, 20, 12));
        draw_line_width(_x0, _y, _x0, _y + _h, 2);
    }
    draw_set_alpha(1);
}

/// @function wnt_demo_draw(d)
/// @description The whole demo screen (Draw GUI).
function wnt_demo_draw(_d) {
    draw_clear(make_colour_rgb(28, 22, 18));
    wnt_demo_board(32, 96, 784, 584);
    wnt_text(40, 26, "WANTED", 44, make_colour_rgb(232, 214, 176), fa_left, fa_top, fnt_wanted_title);
    wnt_text(250, 40, "every bounty prints its own poster", 17, make_colour_rgb(200, 184, 150), fa_left, fa_top, fnt_wanted_ui);
    for (var _i = 0; _i < 8; _i++) {
        var _r = wnt_demo_slot(_i);
        var _spr = wnt_poster_sprite(_d.posters[_i], _r.w, _r.h);
        if (_spr >= 0) {
            // the shadow is the poster's own sprite in black, turned about the same centre (holes and all)
            var _ox = _r.x + _r.w / 2 - ((_r.w / 2) * dcos(_r.a) + (_r.h / 2) * dsin(_r.a));
            var _oy = _r.y + _r.h / 2 - (-(_r.w / 2) * dsin(_r.a) + (_r.h / 2) * dcos(_r.a));
            gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); gpu_set_texfilter(true);
            draw_sprite_ext(_spr, 0, _ox + 5, _oy + 7, 1, 1, _r.a, c_black, 0.45);
            gpu_pop_state();
        }
        wnt_poster_draw(_d.posters[_i], _r.x, _r.y, _r.w, _r.h, 1, _r.a);
        if (_i == _d.sel) {
            draw_set_colour(make_colour_rgb(236, 196, 96)); draw_set_alpha(0.9);
            draw_rectangle(_r.x - 6, _r.y - 6, _r.x + _r.w + 6, _r.y + _r.h + 6, true);
            draw_rectangle(_r.x - 7, _r.y - 7, _r.x + _r.w + 7, _r.y + _r.h + 7, true);
            draw_set_alpha(1);
        }
    }
    var _p = _d.posters[_d.sel];
    draw_set_colour(make_colour_rgb(14, 11, 9)); draw_rectangle(848, 96, 1252, 680, false);
    wnt_poster_draw(_p, 862, 104, 376, 564);
    wnt_text(40, 688, "ARROWS select   C claim   X expire   P post again   N new bounty   click a poster", 17, make_colour_rgb(200, 184, 150), fa_left, fa_top, fnt_wanted_ui);
    wnt_text(848, 72, wnt_quarry_name(_p.quarryId) + "  -  " + _p.stock + " stock, " + _p.device + " seal, " + _p.crimeClass, 17, make_colour_rgb(200, 184, 150), fa_left, fa_top, fnt_wanted_ui);
    wnt_text(848, 688, _d.note, 17, make_colour_rgb(236, 196, 96), fa_left, fa_top, fnt_wanted_ui);
}
