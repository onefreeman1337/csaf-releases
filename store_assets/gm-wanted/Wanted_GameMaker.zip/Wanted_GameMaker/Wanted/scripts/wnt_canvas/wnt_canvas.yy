{
  "$GMScript": "v1",
  "%Name": "wnt_canvas",
  "name": "wnt_canvas",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}