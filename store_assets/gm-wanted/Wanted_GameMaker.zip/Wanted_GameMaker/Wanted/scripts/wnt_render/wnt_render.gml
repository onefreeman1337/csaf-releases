/// wnt_render.gml - the drawing primitives every Wanted poster is made of: a seeded generator, a RECORDER that counts
/// every drawing operation (and can count without drawing), unit-space path playback, the woodcut figure, and
/// letterpress type set glyph by glyph.
///
/// Wanted - Every Bounty Prints Its Own Poster, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ THIS FILE IS A PORT HELD TO ITS ORIGINAL (the published RPG Maker MZ Wanted Posters, BountyRender.js). The suite
/// checks the generator's draws bit for bit and every poster's operation counts against numbers the original produced
/// (wnt_oracle.gml). Two GameMaker facts shape it:
///   - GML may evaluate the parts of ONE expression right to left, so every random draw is taken into a local in its
///     own statement, in the original's order, before it is used;
///   - GameMaker resolves a font by RESOURCE, not by a CSS name: a type spec here is {face, px}, where face is
///     WNT_FACE_WOOD (the wood type: WANTED, the name, the reward) or WNT_FACE_TEXT (the plate serif: every other line).
/// Nothing in this file runs per frame. A poster is composed ONCE into a sprite and drawn from it thereafter.

#macro WNT_FACE_WOOD 0
#macro WNT_FACE_TEXT 1

// ---------------------------------------------------------------------------------------------------------------
// Deterministic randomness
// ---------------------------------------------------------------------------------------------------------------

/// @function wnt_i32(v)
/// @description A number as JavaScript's ToInt32 sees it (`v | 0`). Pure.
function wnt_i32(_v) { var _u = wnt_u32(_v); return (_u >= 2147483648) ? _u - 4294967296 : _u; }

/// @function wnt_rng(seed)
/// @description A seeded generator (mulberry32, bit for bit the original's). The same bounty prints the same poster
/// on every machine and in every session; never random(). Returns a struct to pass to wnt_rnd.
function wnt_rng(_seed) {
    var _a = is_numeric(_seed) ? wnt_u32(_seed) : wnt_hash(_seed);
    if (_a == 0) _a = $9E3779B9;
    return { a: _a };
}

/// @function wnt_rnd(gen)
/// @description The next draw in [0, 1) from a wnt_rng generator.
function wnt_rnd(_g) {
    var _a = (_g.a + $6D2B79F5) & $FFFFFFFF;
    _g.a = _a;
    var _t = wnt_mul32(_a ^ (_a >> 15), 1 | _a);
    _t = ((_t + wnt_mul32(_t ^ (_t >> 7), 61 | _t)) & $FFFFFFFF) ^ _t;
    return ((_t ^ (_t >> 14)) & $FFFFFFFF) / 4294967296;
}

// ---------------------------------------------------------------------------------------------------------------
// Colour
// ---------------------------------------------------------------------------------------------------------------

/// @function wnt_shade(rgb, k)
/// @description A colour multiplied by k, each channel clamped to 0..255. Pure.
function wnt_shade(_c, _k) { return [max(0, min(255, _c[0] * _k)), max(0, min(255, _c[1] * _k)), max(0, min(255, _c[2] * _k))]; }

/// @function wnt_pick_contrast(bg, candidates)
/// @description Whichever candidate ink differs most in luminance from a background. ⛔ An ink is never hard-coded:
/// it is picked against what it sits on, so a dark paper cannot print dark on dark. Pure.
function wnt_pick_contrast(_bg, _cands) {
    var _lb = wnt_lum(_bg), _best = _cands[0], _bd = -1;
    for (var _i = 0; _i < array_length(_cands); _i++) {
        var _d = abs(wnt_lum(_cands[_i]) - _lb);
        if (_d > _bd) { _bd = _d; _best = _cands[_i]; }
    }
    return _best;
}

/// @function wnt_relief_tint(rgb, dir, min_delta)
/// @description The same colour moved toward white (dir > 0) or black far enough to be SEEN: the separation is stated in
/// ABSOLUTE luminance, so a device struck into black wax is as legible as one struck into cream. Pure.
function wnt_relief_tint(_c, _dir, _min) {
    var _lb = wnt_lum(_c);
    var _want = max(_min, _lb * 0.22);
    var _target = (_dir > 0) ? [255, 255, 255] : [0, 0, 0];
    var _span = abs(((_dir > 0) ? 255 : 0) - _lb);
    var _t = (_span < 1) ? 1 : min(1, _want / _span);
    return wnt_mix(_c, _target, _t);
}

// ---------------------------------------------------------------------------------------------------------------
// The recorder
// ---------------------------------------------------------------------------------------------------------------

/// @function wnt_rec(ctx)
/// @description A recorder over a wnt_cx context, or over `undefined` to COUNT ONLY (no surface, no GPU). Every drawing
/// operation is counted the way the original counts it, which is what lets the suite hold the port to the original's
/// own numbers: a dropped branch moves a count, while pixels never have to agree across two rasterisers.
function wnt_rec(_cx) { return { cx: _cx, n: { fill: 0, stroke: 0, path: 0, text: 0, glyph: 0, save: 0, image: 0 } }; }

/// @function wnt_rec_counts(rec)
/// @description A snapshot of the counters: {fill, stroke, path, text, glyph, save, image, total}.
function wnt_rec_counts(_r) {
    var _n = _r.n;
    return { fill: _n.fill, stroke: _n.stroke, path: _n.path, text: _n.text, glyph: _n.glyph, save: _n.save, image: _n.image,
        total: _n.fill + _n.stroke + _n.path + _n.glyph };
}

function wnt_rec_begin(_r) { _r.n.path += 1; if (!is_undefined(_r.cx)) wnt_cx_begin(_r.cx); }
function wnt_rec_move(_r, _x, _y) { if (!is_undefined(_r.cx)) wnt_cx_move(_r.cx, _x, _y); }
function wnt_rec_line(_r, _x, _y) { if (!is_undefined(_r.cx)) wnt_cx_line(_r.cx, _x, _y); }
function wnt_rec_quad(_r, _a, _b, _x, _y) { if (!is_undefined(_r.cx)) wnt_cx_quad(_r.cx, _a, _b, _x, _y); }
function wnt_rec_bezier(_r, _a, _b, _c, _d, _x, _y) { if (!is_undefined(_r.cx)) wnt_cx_bezier(_r.cx, _a, _b, _c, _d, _x, _y); }
function wnt_rec_arc(_r, _x, _y, _rad, _a0, _a1) { if (!is_undefined(_r.cx)) wnt_cx_arc(_r.cx, _x, _y, abs(_rad), _a0, _a1); }
function wnt_rec_close(_r) { if (!is_undefined(_r.cx)) wnt_cx_close(_r.cx); }
function wnt_rec_save(_r) { _r.n.save += 1; if (!is_undefined(_r.cx)) wnt_cx_save(_r.cx); }
function wnt_rec_restore(_r) { if (!is_undefined(_r.cx)) wnt_cx_restore(_r.cx); }
function wnt_rec_translate(_r, _x, _y) { if (!is_undefined(_r.cx)) wnt_cx_translate(_r.cx, _x, _y); }
function wnt_rec_rotate(_r, _a) { if (!is_undefined(_r.cx)) wnt_cx_rotate(_r.cx, _a); }
function wnt_rec_scale(_r, _sx, _sy) { if (!is_undefined(_r.cx)) wnt_cx_scale(_r.cx, _sx, _sy); }
function wnt_rec_count_text(_r) { _r.n.text += 1; }

/// @function wnt_rec_fill(rec, rgb, alpha, [evenodd])
/// @description Fill the current path (nonzero, or even-odd for the devices and fleurons authored as rings).
function wnt_rec_fill(_r, _rgb, _a, _evenodd = false) {
    _r.n.fill += 1;
    if (is_undefined(_r.cx) || !(_a > 0)) return;
    var _c = _r.cx;
    _c.fill = wnt_cx_solid(_rgb, _a);
    var _rings = wnt_cx__rings(_c);
    if (array_length(_rings) == 0) return;
    if (array_length(_rings) == 1 && wnt_cx__rect_clips(_c) && wnt_cx__convex(_rings[0])) { wnt_cx__fan(_c, _rings[0], _c.fill, _c.alpha); return; }
    wnt_cx__fill(_c, _rings, _c.fill, _c.alpha, _evenodd ? WNT_FILL_EVENODD : WNT_FILL_NONZERO);
}

/// @function wnt_rec_stroke(rec, rgb, alpha, width)
/// @description Stroke the current path with round caps; a width under 0.4 is drawn at 0.4, as the original does.
function wnt_rec_stroke(_r, _rgb, _a, _w) {
    _r.n.stroke += 1;
    if (is_undefined(_r.cx) || !(_a > 0)) return;
    var _c = _r.cx;
    _c.stroke = wnt_cx_solid(_rgb, _a);
    _c.lw = max(0.4, _w);
    _c.cap = 1;
    wnt_cx_stroke(_c);
}

/// @function wnt_rec_rect(rec, x, y, w, h, rgb, alpha)
/// @description Fill an axis rectangle without touching the current path (counted as a fill).
function wnt_rec_rect(_r, _x, _y, _w, _h, _rgb, _a) {
    _r.n.fill += 1;
    if (is_undefined(_r.cx) || !(_a > 0)) return;
    _r.cx.fill = wnt_cx_solid(_rgb, _a);
    wnt_cx_fill_rect(_r.cx, _x, _y, _w, _h);
}

/// @function wnt_rec_erase(rec)
/// @description REMOVE the current path's area from the sheet (to transparent), counted as a fill. ⚠️ Used for the
/// nail holes and the torn corner ONLY, where the paper really is gone and whatever the poster hangs on shows through.
/// A woodcut CUT is never erased: it is painted in the paper colour, because a cut reveals the paper.
function wnt_rec_erase(_r) {
    _r.n.fill += 1;
    if (is_undefined(_r.cx)) return;
    var _c = _r.cx;
    var _rings = wnt_cx__rings(_c);
    if (array_length(_rings) == 0) return;
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_zero, bm_inv_src_alpha, bm_zero, bm_inv_src_alpha);
    wnt_cx__fill(_c, _rings, wnt_cx_solid([0, 0, 0], 1), 1, WNT_FILL_NONZERO);
    gpu_pop_state();
}

// ---------------------------------------------------------------------------------------------------------------
// Unit-space path playback
// ---------------------------------------------------------------------------------------------------------------

/// @function wnt_trace_path(rec, ops, cx, cy, r)
/// @description Trace one quarry path (unit box -1..1, y down) into pixels: unit 1.0 becomes `r` pixels about (cx, cy).
/// This is the whole coordinate contract - one authored beast serves a board thumbnail and a full-size poster.
function wnt_trace_path(_r, _ops, _cx, _cy, _rad) {
    wnt_rec_begin(_r);
    if (is_undefined(_r.cx)) return;
    var _c = _r.cx;
    for (var _i = 0; _i < array_length(_ops); _i++) {
        var _o = _ops[_i];
        switch (_o[0]) {
            case "M": wnt_cx_move(_c, _cx + _o[1] * _rad, _cy + _o[2] * _rad); break;
            case "L": wnt_cx_line(_c, _cx + _o[1] * _rad, _cy + _o[2] * _rad); break;
            case "Q": wnt_cx_quad(_c, _cx + _o[1] * _rad, _cy + _o[2] * _rad, _cx + _o[3] * _rad, _cy + _o[4] * _rad); break;
            case "C": wnt_cx_bezier(_c, _cx + _o[1] * _rad, _cy + _o[2] * _rad, _cx + _o[3] * _rad, _cy + _o[4] * _rad, _cx + _o[5] * _rad, _cy + _o[6] * _rad); break;
            case "A":
                wnt_cx_move(_c, _cx + (_o[1] + _o[3]) * _rad, _cy + _o[2] * _rad);
                wnt_cx_arc(_c, _cx + _o[1] * _rad, _cy + _o[2] * _rad, abs(_o[3] * _rad), _o[4], _o[5]);
                break;
            case "Z": wnt_cx_close(_c); break;
        }
    }
}

/// @function wnt_trace_box(rec, ops, x, y, w, h)
/// @description Trace a 0..1-box path (a device, a crime mark, a fleuron) into a pixel box. ⚠️ NOT the quarry's
/// contract: a beast is authored about its centre in -1..1, a device in a box so it drops into a slot.
function wnt_trace_box(_r, _ops, _x, _y, _w, _h) {
    wnt_rec_begin(_r);
    if (is_undefined(_r.cx)) return;
    var _c = _r.cx;
    for (var _i = 0; _i < array_length(_ops); _i++) {
        var _o = _ops[_i];
        switch (_o[0]) {
            case "M": wnt_cx_move(_c, _x + _o[1] * _w, _y + _o[2] * _h); break;
            case "L": wnt_cx_line(_c, _x + _o[1] * _w, _y + _o[2] * _h); break;
            case "Q": wnt_cx_quad(_c, _x + _o[1] * _w, _y + _o[2] * _h, _x + _o[3] * _w, _y + _o[4] * _h); break;
            case "C": wnt_cx_bezier(_c, _x + _o[1] * _w, _y + _o[2] * _h, _x + _o[3] * _w, _y + _o[4] * _h, _x + _o[5] * _w, _y + _o[6] * _h); break;
            case "Z": wnt_cx_close(_c); break;
        }
    }
}

/// @function wnt_fill_box(rec, ops, x, y, w, h, rgb, alpha, [evenodd])
/// @description Fill a 0..1-box path. ⚠️ NONZERO by default, by measurement: the original fills every device even-odd,
/// which punches a hole wherever two solid parts OVERLAP - the portcullis read as a checkerboard and the quill, oak and
/// anchor showed notches at their joins (seen on the seal plate). The authored windings carry the intent instead: every
/// ring's inner circle runs against its outer one (the wheel, the anchor), so nonzero keeps those holes and unites the
/// bars. Only the two shapes whose hole runs the SAME way as their outline - the key's bow and the pierced fleuron - ask
/// for even-odd (wnt_box_evenodd). The fill is still one operation either way, so every count is unchanged.
function wnt_fill_box(_r, _ops, _x, _y, _w, _h, _rgb, _a, _evenodd = false) {
    wnt_trace_box(_r, _ops, _x, _y, _w, _h);
    wnt_rec_fill(_r, _rgb, _a, _evenodd);
}

/// @function wnt_box_evenodd(id)
/// @description True for the device or fleuron ids whose hole is wound the same way as their outline. Pure.
function wnt_box_evenodd(_id) { return _id == "key" || _id == "pierced"; }

/// @function wnt_draw_figure(rec, subpaths, cx, cy, r, ink, paper, halo)
/// @description One quarry figure as a woodcut block: an optional paper HALO (the cutter clears a margin round the
/// subject so a black beast on black hatching is not one mass), every inked mass, then every cut in the PAPER colour.
/// Stroke weight is derived from r, never a pixel constant, so a figure keeps its weight at any size.
function wnt_draw_figure(_r, _subs, _cx, _cy, _rad, _ink, _paper, _halo) {
    var _base = max(1, _rad * 0.030), _i, _sp, _w;
    var _n = array_length(_subs);
    if (_halo) {
        for (_i = 0; _i < _n; _i++) {
            if (_subs[_i].mode == "cut") continue;
            wnt_trace_path(_r, _subs[_i].d, _cx, _cy, _rad);
            wnt_rec_stroke(_r, _paper, 1, _base * 3.4);
        }
    }
    for (_i = 0; _i < _n; _i++) {
        _sp = _subs[_i];
        if (_sp.mode == "cut") continue;
        wnt_trace_path(_r, _sp.d, _cx, _cy, _rad);
        if (_sp.mode == "fill") {
            wnt_rec_fill(_r, _ink, 1);
            wnt_rec_stroke(_r, _ink, 1, max(1, _base * 0.5));
        } else {
            _w = (_sp.w != 0) ? _sp.w : 1;
            wnt_rec_stroke(_r, _ink, 1, max(1, _base * _w));
        }
    }
    for (_i = 0; _i < _n; _i++) {
        _sp = _subs[_i];
        if (_sp.mode != "cut") continue;
        wnt_trace_path(_r, _sp.d, _cx, _cy, _rad);
        _w = (_sp.w != 0) ? _sp.w : 1;
        wnt_rec_stroke(_r, _paper, 1, max(1, _base * _w * 0.85));
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Letterpress type
// ---------------------------------------------------------------------------------------------------------------

/// @function wnt__opt(struct, key, default)
/// @description A struct field, or the default when it is absent or undefined. Internal.
function wnt__opt(_o, _k, _d) { var _v = _o[$ _k]; return is_undefined(_v) ? _d : _v; }

/// @function wnt_rec_font(spec, device_px)
/// @description The font resource a type spec {face, px} is drawn from at a device size. Internal.
function wnt_rec_font(_f, _dpx) { return (_f.face == WNT_FACE_WOOD) ? wnt_font_wood(_dpx) : wnt_font_for(_dpx); }

/// @function wnt_rec_measure(rec, string, spec)
/// @description The width of a string set in a type spec, in user pixels, measured from the atlas it will be drawn
/// from (the font engine is always available, so - unlike the original's null context - this is never an estimate).
function wnt_rec_measure(_r, _s, _f) {
    var _k = is_undefined(_r.cx) ? 1 : wnt_cx__scale(_r.cx);
    var _font = wnt_rec_font(_f, _f.px * _k);
    var _pf = draw_get_font();
    draw_set_font(_font);
    var _w = string_width(_s) * _f.px / wnt_font_px(_font);
    draw_set_font(_pf);
    return _w;
}

/// @function wnt_tracked_width(rec, string, spec, track)
/// @description The width of a tracked string: the glyph advances plus the tracking BETWEEN them (n - 1 gaps, not n).
function wnt_tracked_width(_r, _s, _f, _track) {
    var _n = string_length(_s);
    if (_n == 0) return 0;
    return wnt_rec_measure(_r, _s, _f) + _track * (_n - 1);
}

/// @function wnt_rec_glyph(rec, char, x, y, spec, rgb, alpha)
/// @description Draw ONE glyph with its baseline at (x, y) under the current transform (rotated and condensed with it).
function wnt_rec_glyph(_r, _ch, _x, _y, _f, _rgb, _alpha) {
    _r.n.glyph += 1;
    if (is_undefined(_r.cx) || !(_alpha > 0)) return;
    var _c = _r.cx, _m = _c.m;
    var _sx = sqrt(_m[0] * _m[0] + _m[1] * _m[1]), _sy = sqrt(_m[2] * _m[2] + _m[3] * _m[3]);
    var _font = wnt_rec_font(_f, _f.px * _sy);
    var _k = _f.px / wnt_font_px(_font);
    var _p = wnt_cx__pt(_c, _x, _y - wnt_font_ascent(_font) * _k);
    draw_set_font(_font);
    draw_set_halign(fa_left); draw_set_valign(fa_top);
    draw_set_colour(wnt_col(_rgb)); draw_set_alpha(_alpha * _c.alpha);
    draw_text_transformed(_p[0], _p[1], _ch, _k * _sx, _k * _sy, -radtodeg(arctan2(_m[1], _m[0])));
}

/// @function wnt_fit_line(rec, string, max_w, opts)
/// @description Fit one line into a width: surrender TRACKING first (a set stays even), then SIZE in half-pixel steps,
/// and if it still does not fit, SAY SO: {size, track, width, fits, squeeze}. The caller applies the squeeze - a
/// fitter that fails silently is how "SEVEN OF WANDS" ships as "SEVEN OF WAND". opts: {face, size, minSize, track, minTrack}.
function wnt_fit_line(_r, _s, _maxW, _o) {
    var _face = wnt__opt(_o, "face", WNT_FACE_TEXT);
    var _minSize = wnt__opt(_o, "minSize", _o.size * 0.62);
    var _minTrack = wnt__opt(_o, "minTrack", 0);
    var _size = _o.size, _track = wnt__opt(_o, "track", 0);
    while (_track > _minTrack) {
        if (wnt_tracked_width(_r, _s, { face: _face, px: _size }, _track) <= _maxW) break;
        _track = max(_minTrack, _track - 0.25);
    }
    while (_size > _minSize) {
        if (wnt_tracked_width(_r, _s, { face: _face, px: _size }, _track) <= _maxW) break;
        _size = max(_minSize, _size - 0.5);
    }
    var _w = wnt_tracked_width(_r, _s, { face: _face, px: _size }, _track);
    return { size: _size, track: _track, width: _w, fits: _w <= _maxW + 0.5, squeeze: (_w > _maxW) ? _maxW / _w : 1 };
}

/// @function wnt__words(string)
/// @description The words of a phrase (split on whitespace, empties dropped). Internal.
function wnt__words(_s) {
    var _raw = string_split(string_replace_all(string_replace_all(string(_s), "\t", " "), "\n", " "), " ");
    var _o = [];
    for (var _i = 0; _i < array_length(_raw); _i++) if (string_length(_raw[_i]) > 0) array_push(_o, _raw[_i]);
    return _o;
}

/// @function wnt__join(words, from, to)
/// @description words[from..to) joined with single spaces. Internal.
function wnt__join(_w, _a, _b) {
    var _s = "";
    for (var _i = _a; _i < _b; _i++) _s += ((_i > _a) ? " " : "") + _w[_i];
    return _s;
}

/// @function wnt_greedy_break(rec, words, n, opts, max_w)
/// @description Break a word list into exactly n lines of roughly equal measured width, or undefined when there are
/// fewer words than lines.
function wnt_greedy_break(_r, _words, _n, _o, _maxW) {
    var _nw = array_length(_words);
    if (_nw < _n) return undefined;
    if (_n == 1) return [wnt__join(_words, 0, _nw)];
    var _f = { face: wnt__opt(_o, "face", WNT_FACE_TEXT), px: _o.size };
    var _total = wnt_rec_measure(_r, wnt__join(_words, 0, _nw), _f);
    var _target = _total / _n;
    var _lines = [], _cur = [], _w = 0;
    for (var _i = 0; _i < _nw; _i++) {
        var _ww = wnt_rec_measure(_r, _words[_i] + " ", _f);
        var _mustKeep = _n - array_length(_lines) - 1;
        if (array_length(_cur) > 0 && _w + _ww * 0.5 > _target && (_nw - _i) > _mustKeep && array_length(_lines) < _n - 1) {
            array_push(_lines, wnt__join(_cur, 0, array_length(_cur))); _cur = []; _w = 0;
        }
        array_push(_cur, _words[_i]); _w += _ww;
    }
    if (array_length(_cur) > 0) array_push(_lines, wnt__join(_cur, 0, array_length(_cur)));
    var _out = [];
    for (var _j = 0; _j < min(_n, array_length(_lines)); _j++) if (string_length(_lines[_j]) > 0) array_push(_out, _lines[_j]);
    return _out;
}

/// @function wnt_fit_block(rec, string, max_w, max_lines, opts)
/// @description Fit a phrase by WRAPPING it before shrinking it: each line count is tried in turn and the first that
/// fits at a size the set can live with wins (a compositor breaks a long name over two lines, he does not set it in
/// six point). Returns {lines, size, track, fits, squeeze, width}. opts: {face, size, minSize, track, minTrack, stepScale}.
function wnt_fit_block(_r, _s, _maxW, _maxLines, _o) {
    var _step = wnt__opt(_o, "stepScale", 0.80);
    var _face = wnt__opt(_o, "face", WNT_FACE_TEXT);
    var _words = wnt__words(_s), _best = undefined;
    for (var _n = 1; _n <= max(1, _maxLines); _n++) {
        var _lines = wnt_greedy_break(_r, _words, _n, _o, _maxW);
        if (is_undefined(_lines)) continue;
        var _try = _o.size * power(_step, _n - 1);
        var _opt = { face: _face, size: _try, minSize: wnt__opt(_o, "minSize", _o.size * 0.55),
            track: wnt__opt(_o, "track", 0) * power(_step, _n - 1), minTrack: wnt__opt(_o, "minTrack", 0) };
        var _widest = _lines[0], _ff = { face: _face, px: _try };
        for (var _i = 1; _i < array_length(_lines); _i++) {
            if (!(wnt_rec_measure(_r, _widest, _ff) > wnt_rec_measure(_r, _lines[_i], _ff))) _widest = _lines[_i];
        }
        var _f = wnt_fit_line(_r, _widest, _maxW, _opt);
        var _out = { lines: _lines, size: _f.size, track: _f.track, fits: _f.fits, squeeze: _f.squeeze, width: _f.width };
        if (_f.fits) return _out;
        if (is_undefined(_best) || _f.squeeze > _best.squeeze) _best = _out;
    }
    if (!is_undefined(_best)) return _best;
    return { lines: [string(_s)], size: _o.size, track: wnt__opt(_o, "track", 0), fits: false, squeeze: 1, width: _maxW };
}

/// @function wnt_set_line(rec, string, x, y, opts)
/// @description Set one line as INDIVIDUAL GLYPHS with letterpress variation - per-glyph baseline jitter, ink weight,
/// and now and then a glyph printed short of ink - all drawn from the SEEDED generator, so the same poster prints the
/// same way every time. y is the BASELINE. opts: {face, size, track, ink (rgb), inkA, align ("left"|"center"|"right"),
/// rng, press (0 clean .. 1 full), squeeze}. Returns the width set.
function wnt_set_line(_r, _s, _x, _y, _o) {
    var _f = { face: wnt__opt(_o, "face", WNT_FACE_TEXT), px: _o.size };
    var _track = wnt__opt(_o, "track", 0);
    var _rng = wnt__opt(_o, "rng", undefined);
    if (is_undefined(_rng)) _rng = wnt_rng($5EED);
    var _press = wnt__opt(_o, "press", 1);
    var _ink = wnt__opt(_o, "ink", [0, 0, 0]), _inkA = wnt__opt(_o, "inkA", 1);
    var _align = wnt__opt(_o, "align", "left");
    var _w = wnt_tracked_width(_r, _s, _f, _track);
    var _sq = wnt__opt(_o, "squeeze", 1);
    var _cx = _x;
    if (_align == "center") _cx = _x - (_w * _sq) / 2;
    else if (_align == "right") _cx = _x - _w * _sq;
    if (_sq != 1) {
        wnt_rec_save(_r);
        wnt_rec_translate(_r, _cx, 0);
        wnt_rec_scale(_r, _sq, 1);
        _cx = 0;
    }
    wnt_rec_count_text(_r);
    var _n = string_length(_s);
    for (var _i = 1; _i <= _n; _i++) {
        var _ch = string_char_at(_s, _i);
        if (_ch != " ") {
            var _r1 = wnt_rnd(_rng);
            var _jy = (_r1 - 0.5) * _o.size * 0.030 * _press;
            var _r2 = wnt_rnd(_rng);
            var _jx = (_r2 - 0.5) * _o.size * 0.018 * _press;
            var _r3 = wnt_rnd(_rng);
            var _a = 1 - _r3 * 0.20 * _press;
            var _r4 = wnt_rnd(_rng);
            // ⚠️ A low spot in the forme prints a glyph LIGHT, not a ghost. The original multiplies by 0.45, and on a
            // board-sized card that read as a rendering fault (a faint D in WANTED), so the port prints it at 0.70.
            // The draw is still taken, so every later draw - and every count the suite compares - is unchanged.
            if (_r4 < 0.035 * _press) _a *= 0.70;
            wnt_rec_glyph(_r, _ch, _cx + _jx, _y + _jy, _f, _ink, _inkA * _a);
        }
        _cx += wnt_rec_measure(_r, _ch, _f) + _track;
    }
    if (_sq != 1) wnt_rec_restore(_r);
    return _w * _sq;
}
