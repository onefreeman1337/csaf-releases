{
  "$GMScript": "v1",
  "%Name": "wnt_oracle",
  "name": "wnt_oracle",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}