{
  "$GMScript": "v1",
  "%Name": "wnt_poster",
  "name": "wnt_poster",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}