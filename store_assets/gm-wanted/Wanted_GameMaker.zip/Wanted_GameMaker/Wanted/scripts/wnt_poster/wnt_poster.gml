/// wnt_poster.gml - the composer and the public API. A bounty record goes in; a printed broadside comes out: aged
/// stock, a cast border, the WANTED, a framed woodcut of the quarry on a cut ground, the name, the crime, the reward,
/// the issuing jurisdiction's wax seal, nail holes, rain streaks, a torn corner - and CLAIMED or EXPIRED overprinted
/// across it when the bounty changes. Everything is generated; the package ships no image.
///
/// Wanted - Every Bounty Prints Its Own Poster, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// PUBLIC API (all prefixed wnt_):
///   wnt_poster(spec)                         -> a poster record (every derived choice seeded from the bounty)
///   wnt_poster_sprite(poster, w, h)          -> a cached sprite of the poster at w x h (baked once, supersampled)
///   wnt_poster_draw(poster, x, y, w, h, [a]) -> draw it (bakes on first use)
///   wnt_poster_compose(poster, w, h, [ss])   -> draw it straight onto the CURRENT surface target, top-left at 0,0
///   wnt_poster_count(poster, w, h)           -> {counts, fits} without drawing anything (the oracle's measure)
///   wnt_poster_free()                        -> free every cached sprite
///   wnt_quarry_ids() / wnt_quarry_name(id)   -> the 49 quarry figures
///   wnt_quarry_for(text)                     -> the quarry id whose name or clade a game's own enemy name matches
///
/// ⛔ THIS FILE IS A PORT HELD TO ITS ORIGINAL (BountyPoster.js). Every random draw is taken in its own statement, in the
/// original's order (GML may evaluate one expression's parts right to left), and the whole compose runs with the
/// comparison epsilon at ZERO and restores the caller's. The suite holds every poster's operation counts to the
/// original's (wnt_oracle.gml).
///
/// ⚠️ THE LAYOUT IS DERIVED FROM H, NOT TYPED. Every band is a fraction of the sheet, so one forme serves a 120 px board
/// card and a 900 px examine plate.

// ---------------------------------------------------------------------------------------------------------------
// The paper
// ---------------------------------------------------------------------------------------------------------------

/// @function wnt_draw_stock(rec, stock, W, H, seed)
/// @description Lay the sheet: ground, tonal drift, tooth, fibres, laid and chain lines, edge burn. No region is flat.
function wnt_draw_stock(_r, _st, _W, _H, _seed) {
    var _g = wnt_rng(wnt_u32(_seed) ^ $5A17), _i, _a, _b, _c, _d, _e;
    wnt_rec_rect(_r, 0, 0, _W, _H, _st.base, 1);
    for (_i = 0; _i < _st.blooms; _i++) {
        var _bx = wnt_rnd(_g) * _W;
        var _by = wnt_rnd(_g) * _H;
        _a = wnt_rnd(_g);
        var _br = (0.16 + _a * 0.30) * max(_W, _H);
        var _dark = wnt_rnd(_g) < 0.5;
        wnt_rec_begin(_r);
        wnt_rec_arc(_r, _bx, _by, _br, 0, pi * 2);
        wnt_rec_fill(_r, wnt_shade(_st.base, _dark ? 0.93 : 1.05), 0.16);
    }
    var _teeth = wnt_jsround(_W * _H * _st.tooth * 0.0016);
    for (_i = 0; _i < _teeth; _i++) {
        var _tx = wnt_rnd(_g) * _W;
        var _ty = wnt_rnd(_g) * _H;
        var _ta = wnt_rnd(_g) * pi;
        _a = wnt_rnd(_g);
        var _tl = 1 + _a * 2.2;
        wnt_rec_begin(_r);
        wnt_rec_move(_r, _tx, _ty);
        wnt_rec_line(_r, _tx + cos(_ta) * _tl, _ty + sin(_ta) * _tl);
        _b = wnt_rnd(_g);
        wnt_rec_stroke(_r, wnt_shade(_st.base, (_b < 0.5) ? 0.90 : 1.07), 0.30, 0.7);
    }
    for (_i = 0; _i < _st.fibres; _i++) {
        var _fx = wnt_rnd(_g) * _W;
        var _fy = wnt_rnd(_g) * _H;
        var _fa = wnt_rnd(_g) * pi * 2;
        _a = wnt_rnd(_g);
        var _fl = 3 + _a * 14;
        wnt_rec_begin(_r);
        wnt_rec_move(_r, _fx, _fy);
        _b = wnt_rnd(_g);
        _c = wnt_rnd(_g);
        wnt_rec_quad(_r, _fx + cos(_fa) * _fl * 0.5 + (_b - 0.5) * 4, _fy + sin(_fa) * _fl * 0.5 + (_c - 0.5) * 4, _fx + cos(_fa) * _fl, _fy + sin(_fa) * _fl);
        _d = wnt_rnd(_g);
        wnt_rec_stroke(_r, wnt_shade(_st.base, (_d < 0.22) ? 0.74 : 0.95), 0.22, 0.6);
    }
    if (_st.laid) {
        var _gap = max(3, _H * 0.011);
        for (var _y = _gap; _y < _H; _y += _gap) {
            wnt_rec_begin(_r);
            _a = wnt_rnd(_g);
            wnt_rec_move(_r, 0, _y + (_a - 0.5));
            _b = wnt_rnd(_g);
            wnt_rec_line(_r, _W, _y + (_b - 0.5));
            wnt_rec_stroke(_r, wnt_shade(_st.base, 0.96), 0.20, 0.6);
        }
        var _cgap = _W * 0.13;
        for (var _x = _cgap * 0.6; _x < _W; _x += _cgap) {
            wnt_rec_begin(_r);
            wnt_rec_move(_r, _x, 0); wnt_rec_line(_r, _x, _H);
            wnt_rec_stroke(_r, wnt_shade(_st.base, 1.05), 0.22, 1.4);
        }
    }
    var _band = max(6, min(_W, _H) * 0.05);
    for (_i = 0; _i < 5; _i++) {
        var _t = _i / 4;
        var _al = 0.055 * (1 - _t);
        var _in = _band * _t;
        wnt_rec_begin(_r);
        wnt_rec_move(_r, _in, _in); wnt_rec_line(_r, _W - _in, _in);
        wnt_rec_line(_r, _W - _in, _H - _in); wnt_rec_line(_r, _in, _H - _in); wnt_rec_close(_r);
        wnt_rec_stroke(_r, wnt_shade(_st.base, 0.70), _al, _band * 0.5);
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Rules and ornaments
// ---------------------------------------------------------------------------------------------------------------

/// @function wnt__rule_pass(rec, x1, x2, y, w, ink, inkA, gen)
/// @description One printed line in nine segments, each with its own impression. Internal.
function wnt__rule_pass(_r, _x1, _x2, _yy, _ww, _ink, _inkA, _g) {
    for (var _i = 0; _i < 9; _i++) {
        var _a = _x1 + (_x2 - _x1) * (_i / 9);
        var _b = _x1 + (_x2 - _x1) * ((_i + 1) / 9);
        wnt_rec_begin(_r);
        var _r1 = wnt_rnd(_g);
        wnt_rec_move(_r, _a, _yy + (_r1 - 0.5) * _ww * 0.30);
        var _r2 = wnt_rnd(_g);
        wnt_rec_line(_r, _b, _yy + (_r2 - 0.5) * _ww * 0.30);
        var _r3 = wnt_rnd(_g);
        wnt_rec_stroke(_r, _ink, _inkA, _ww * (0.86 + _r3 * 0.28));
    }
}

/// @function wnt_draw_rule(rec, x1, y, x2, kind, w, ink, inkA, gen)
/// @description A compositor's rule - 0 single, 1 double, 2 thick-thin - with an uneven impression.
function wnt_draw_rule(_r, _x1, _y, _x2, _kind, _w, _ink, _inkA, _g) {
    if (_kind == 2) { wnt__rule_pass(_r, _x1, _x2, _y, _w * 2.1, _ink, _inkA, _g); wnt__rule_pass(_r, _x1, _x2, _y + _w * 3.0, _w * 0.7, _ink, _inkA, _g); }
    else if (_kind == 1) { wnt__rule_pass(_r, _x1, _x2, _y, _w * 0.9, _ink, _inkA, _g); wnt__rule_pass(_r, _x1, _x2, _y + _w * 2.6, _w * 0.9, _ink, _inkA, _g); }
    else wnt__rule_pass(_r, _x1, _x2, _y, _w, _ink, _inkA, _g);
}

/// @function wnt_draw_fleuron_rule(rec, x1, y, x2, fleuron, w, ink, inkA, gen)
/// @description A rule broken in the middle by a fleuron - the compositor's separator.
function wnt_draw_fleuron_rule(_r, _x1, _y, _x2, _fid, _w, _ink, _inkA, _g) {
    var _mid = (_x1 + _x2) / 2, _s = max(6, _w * 7), _gap = _s * 0.95;
    wnt_draw_rule(_r, _x1, _y, _mid - _gap, 0, _w, _ink, _inkA, _g);
    wnt_draw_rule(_r, _mid + _gap, _y, _x2, 0, _w, _ink, _inkA, _g);
    var _fl = wnt_fleurons();
    wnt_fill_box(_r, _fl[$ _fid], _mid - _s / 2, _y - _s / 2, _s, _s, _ink, _inkA, wnt_box_evenodd(_fid));
}

/// @function wnt__frame_edges(rec, box, weight, ink, inkA, gen)
/// @description Four edges of a rectangle in eight segments each. Internal.
function wnt__frame_edges(_r, _b, _weight, _ink, _inkA, _g) {
    var _pts = [[_b[0], _b[1]], [_b[0] + _b[2], _b[1]], [_b[0] + _b[2], _b[1] + _b[3]], [_b[0], _b[1] + _b[3]]];
    for (var _e = 0; _e < 4; _e++) {
        var _a = _pts[_e], _c = _pts[(_e + 1) mod 4];
        for (var _k = 0; _k < 8; _k++) {
            var _t0 = _k / 8, _t1 = (_k + 1) / 8;
            wnt_rec_begin(_r);
            wnt_rec_move(_r, _a[0] + (_c[0] - _a[0]) * _t0, _a[1] + (_c[1] - _a[1]) * _t0);
            wnt_rec_line(_r, _a[0] + (_c[0] - _a[0]) * _t1, _a[1] + (_c[1] - _a[1]) * _t1);
            var _q = wnt_rnd(_g);
            wnt_rec_stroke(_r, _ink, _inkA, _weight * (0.85 + _q * 0.3));
        }
    }
}

/// @function wnt_draw_border(rec, W, H, u, fleuron, ink, inkA, gen)
/// @description A cast ornamental border round the whole sheet: two rules and a repeated sort running between them on
/// all four edges. The count of sorts comes from the real run length (a pitch, never a count).
function wnt_draw_border(_r, _W, _H, _u, _fid, _ink, _inkA, _g) {
    var _inset = _W * 0.026, _band = _W * 0.019, _i, _n;
    wnt__frame_edges(_r, [_inset, _inset, _W - _inset * 2, _H - _inset * 2], _u * 0.85, _ink, _inkA, _g);
    wnt__frame_edges(_r, [_inset + _band, _inset + _band, _W - (_inset + _band) * 2, _H - (_inset + _band) * 2], _u * 0.6, _ink, _inkA, _g);
    var _fl = wnt_fleurons(), _orn = _fl[$ _fid], _eo = wnt_box_evenodd(_fid);
    var _s = _band * 0.74, _step = _band * 1.15, _mid = _inset + _band / 2;
    var _ys = [_mid, _H - _mid];
    for (var _h = 0; _h < 2; _h++) {
        _n = floor((_W - _inset * 2 - _band * 2) / _step);
        var _x0 = (_W - _n * _step) / 2;
        for (_i = 0; _i < _n; _i++) wnt_fill_box(_r, _orn, _x0 + _i * _step + (_step - _s) / 2, _ys[_h] - _s / 2, _s, _s, _ink, _inkA, _eo);
    }
    var _xs = [_mid, _W - _mid];
    for (var _v = 0; _v < 2; _v++) {
        _n = floor((_H - _inset * 2 - _band * 2) / _step);
        var _y0 = (_H - _n * _step) / 2;
        for (_i = 0; _i < _n; _i++) wnt_fill_box(_r, _orn, _xs[_v] - _s / 2, _y0 + _i * _step + (_step - _s) / 2, _s, _s, _ink, _inkA, _eo);
    }
}

// ---------------------------------------------------------------------------------------------------------------
// The block
// ---------------------------------------------------------------------------------------------------------------

/// @function wnt__block_edges(rec, x, y, w, h, inset, weight, ink, gen)
/// @description The block frame's four edges in six jittered segments each. Internal.
function wnt__block_edges(_r, _x, _y, _w, _h, _inset, _weight, _ink, _g) {
    var _pts = [[_x + _inset, _y + _inset], [_x + _w - _inset, _y + _inset], [_x + _w - _inset, _y + _h - _inset], [_x + _inset, _y + _h - _inset]];
    for (var _i = 0; _i < 4; _i++) {
        var _a = _pts[_i], _b = _pts[(_i + 1) mod 4];
        for (var _k = 0; _k < 6; _k++) {
            var _t0 = _k / 6, _t1 = (_k + 1) / 6;
            wnt_rec_begin(_r);
            var _r1 = wnt_rnd(_g);
            var _r2 = wnt_rnd(_g);
            wnt_rec_move(_r, _a[0] + (_b[0] - _a[0]) * _t0 + (_r1 - 0.5) * _weight * 0.3, _a[1] + (_b[1] - _a[1]) * _t0 + (_r2 - 0.5) * _weight * 0.3);
            var _r3 = wnt_rnd(_g);
            var _r4 = wnt_rnd(_g);
            wnt_rec_line(_r, _a[0] + (_b[0] - _a[0]) * _t1 + (_r3 - 0.5) * _weight * 0.3, _a[1] + (_b[1] - _a[1]) * _t1 + (_r4 - 0.5) * _weight * 0.3);
            var _r5 = wnt_rnd(_g);
            wnt_rec_stroke(_r, _ink, 1, _weight * (0.9 + _r5 * 0.2));
        }
    }
}

/// @function wnt_draw_block_frame(rec, x, y, w, h, u, ink, gen)
/// @description The ruled border a woodcut sits in, with four solid corner blocks (a forme, not a rectangle).
function wnt_draw_block_frame(_r, _x, _y, _w, _h, _u, _ink, _g) {
    wnt__block_edges(_r, _x, _y, _w, _h, 0, _u * 1.9, _ink, _g);
    wnt__block_edges(_r, _x, _y, _w, _h, _u * 3.4, _u * 0.7, _ink, _g);
    var _cs = _u * 5.2;
    wnt_rec_rect(_r, _x, _y, _cs, _cs, _ink, 1);
    wnt_rec_rect(_r, _x + _w - _cs, _y, _cs, _cs, _ink, 1);
    wnt_rec_rect(_r, _x + _w - _cs, _y + _h - _cs, _cs, _cs, _ink, 1);
    wnt_rec_rect(_r, _x, _y + _h - _cs, _cs, _cs, _ink, 1);
}

/// @function wnt_draw_ground(rec, x, y, w, h, u, ink, gen)
/// @description The cut ground inside the block: a broken horizon, earth hatching that thins downward and ramps to
/// nothing at both ends of every row (a hard-ended run reads as a barcode), and a few sparse sky lines.
function wnt_draw_ground(_r, _x, _y, _w, _h, _u, _ink, _g) {
    var _q = wnt_rnd(_g), _i, _k;
    var _hy = _y + _h * (0.70 + _q * 0.06);
    for (_i = 0; _i < 11; _i++) {
        var _a = _x + _w * (_i / 11), _b = _x + _w * ((_i + 1) / 11);
        wnt_rec_begin(_r);
        var _r1 = wnt_rnd(_g);
        wnt_rec_move(_r, _a, _hy + (_r1 - 0.5) * _h * 0.012);
        var _r2 = wnt_rnd(_g);
        wnt_rec_line(_r, _b, _hy + (_r2 - 0.5) * _h * 0.012);
        var _r3 = wnt_rnd(_g);
        wnt_rec_stroke(_r, _ink, 1, _u * (0.7 + _r3 * 0.7));
    }
    for (_i = 0; _i < 7; _i++) {
        var _t = _i / 6;
        var _ry = _hy + (_h - (_hy - _y)) * 0.0 + (_y + _h - _hy) * (0.10 + _t * 0.80);
        var _n = max(3, wnt_jsround(16 * (1 - _t * 0.62)));
        for (_k = 0; _k < _n; _k++) {
            var _kt = _k / (_n - 1);
            var _run = sin(pi * _kt); _run *= _run;
            if (_run < 0.10) continue;
            var _r4 = wnt_rnd(_g);
            var _lx = _x + _w * (0.045 + _kt * 0.91) + (_r4 - 0.5) * _w * 0.012;
            var _r5 = wnt_rnd(_g);
            var _len = _h * 0.030 * _run * (0.7 + _r5 * 0.6);
            wnt_rec_begin(_r);
            wnt_rec_move(_r, _lx, _ry - _len / 2);
            var _r6 = wnt_rnd(_g);
            wnt_rec_line(_r, _lx + (_r6 - 0.5) * _w * 0.006, _ry + _len / 2);
            var _r7 = wnt_rnd(_g);
            wnt_rec_stroke(_r, _ink, 1, _u * (0.5 + _r7 * 0.4));
        }
    }
    var _r8 = wnt_rnd(_g);
    var _sky = 3 + floor(_r8 * 3);
    for (_i = 0; _i < _sky; _i++) {
        var _s1 = wnt_rnd(_g);
        var _sy = _y + _h * (0.10 + _s1 * 0.26);
        var _s2 = wnt_rnd(_g);
        var _sw = _w * (0.20 + _s2 * 0.34);
        var _s3 = wnt_rnd(_g);
        var _sx = _x + _w * 0.06 + _s3 * (_w * 0.88 - _sw);
        wnt_rec_begin(_r);
        wnt_rec_move(_r, _sx, _sy);
        var _s4 = wnt_rnd(_g);
        wnt_rec_quad(_r, _sx + _sw * 0.5, _sy + (_s4 - 0.5) * _h * 0.02, _sx + _sw, _sy);
        var _s5 = wnt_rnd(_g);
        wnt_rec_stroke(_r, _ink, 1, _u * (0.45 + _s5 * 0.35));
    }
}

// ---------------------------------------------------------------------------------------------------------------
// The seal
// ---------------------------------------------------------------------------------------------------------------

/// @function wnt_draw_seal(rec, device, wax, cx, cy, r, seed, broken)
/// @description A wax seal: an uneven blob with a dark rim, a recessed field, and the device ENGRAVED - struck twice,
/// shadow then face, offset along one light vector, in tints solved for an absolute separation so a dark wax still
/// shows its device. A claimed bounty's seal is broken.
function wnt_draw_seal(_r, _device, _wax, _cx, _cy, _rad, _seed, _broken) {
    var _g = wnt_rng(wnt_u32(_seed) ^ $2B0B);
    wnt_rec_begin(_r);
    for (var _i = 0; _i <= 26; _i++) {
        var _a = (_i / 26) * pi * 2;
        var _q = wnt_rnd(_g);
        var _rr = _rad * (0.92 + sin(_a * 3 + _seed) * 0.035 + _q * 0.06);
        var _px = _cx + cos(_a) * _rr, _py = _cy + sin(_a) * _rr;
        if (_i == 0) wnt_rec_move(_r, _px, _py); else wnt_rec_line(_r, _px, _py);
    }
    wnt_rec_close(_r);
    wnt_rec_fill(_r, _wax, 1);
    wnt_rec_stroke(_r, wnt_shade(_wax, 0.62), 0.9, _rad * 0.05);
    wnt_rec_begin(_r);
    wnt_rec_arc(_r, _cx, _cy, _rad * 0.74, 0, pi * 2);
    wnt_rec_fill(_r, wnt_shade(_wax, 0.88), 1);
    var _dv = wnt_devices(), _d = _dv[$ _device];
    if (is_undefined(_d)) _d = _dv[$ "tower"];
    var _s = _rad * 1.16, _off = _rad * 0.055;
    wnt_fill_box(_r, _d, _cx - _s / 2 + _off, _cy - _s / 2 + _off, _s, _s, wnt_relief_tint(_wax, -1, 30), 0.95, wnt_box_evenodd(_device));
    wnt_fill_box(_r, _d, _cx - _s / 2 - _off * 0.5, _cy - _s / 2 - _off * 0.5, _s, _s, wnt_relief_tint(_wax, 1, 34), 1, wnt_box_evenodd(_device));
    if (_broken) {
        // ⚠️ A claimed bounty's seal is SPLIT. The original traces this crack as a zero-alpha stroke (counted, never
        // seen); the port inks it - the same single stroke, so every count the suite compares is unchanged - as a dark
        // fissure across the wax, kept inside the blob so it cannot score the paper.
        wnt_rec_begin(_r);
        wnt_rec_move(_r, _cx - _rad * 0.86, _cy - _rad * 0.24);
        wnt_rec_quad(_r, _cx, _cy + _rad * 0.16, _cx + _rad * 0.86, _cy - _rad * 0.08);
        wnt_rec_stroke(_r, wnt_shade(_wax, 0.30), 0.95, max(1, _rad * 0.075));
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Weathering - the sheet has been outdoors, on a board, for a while
// ---------------------------------------------------------------------------------------------------------------

/// @function wnt_draw_nails(rec, nails, W, H, ink, gen)
/// @description Nail holes that are really holes (erased), a bruised rim, and the tear the sheet's own weight opened
/// running DOWN from each nail.
function wnt_draw_nails(_r, _nails, _W, _H, _ink, _g) {
    var _u = min(_W, _H) * 0.010;
    for (var _i = 0; _i < array_length(_nails); _i++) {
        var _nx = _nails[_i][0], _ny = _nails[_i][1];
        wnt_rec_begin(_r);
        for (var _k = 0; _k <= 9; _k++) {
            var _a = (_k / 9) * pi * 2;
            var _q = wnt_rnd(_g);
            var _rr = _u * (0.75 + _q * 0.55);
            var _px = _nx + cos(_a) * _rr, _py = _ny + sin(_a) * _rr;
            if (_k == 0) wnt_rec_move(_r, _px, _py); else wnt_rec_line(_r, _px, _py);
        }
        wnt_rec_close(_r);
        wnt_rec_erase(_r);
        wnt_rec_begin(_r);
        wnt_rec_arc(_r, _nx, _ny, _u * 1.9, 0, pi * 2);
        wnt_rec_stroke(_r, _ink, 0.16, _u * 1.5);
        var _q2 = wnt_rnd(_g);
        var _tl = _u * (3 + _q2 * 7);
        wnt_rec_begin(_r);
        wnt_rec_move(_r, _nx - _u * 0.5, _ny + _u * 0.4);
        var _q3 = wnt_rnd(_g);
        wnt_rec_line(_r, _nx + (_q3 - 0.5) * _u * 1.6, _ny + _tl);
        wnt_rec_line(_r, _nx + _u * 0.5, _ny + _u * 0.4);
        wnt_rec_close(_r);
        wnt_rec_erase(_r);
    }
}

/// @function wnt_draw_exposure(rec, nails, W, H, ink, age, gen)
/// @description Rain running down FROM the nails (where water collects), fly specks everywhere, and one side
/// sun-bleached in strips whose alpha falls off as a square, so the light vanishes instead of stopping at a seam.
function wnt_draw_exposure(_r, _nails, _W, _H, _ink, _age, _g) {
    var _i;
    for (_i = 0; _i < array_length(_nails); _i++) {
        var _q = wnt_rnd(_g);
        var _n = wnt_jsround(2 + _q * 3 * _age * 2);
        for (var _s = 0; _s < _n; _s++) {
            var _q1 = wnt_rnd(_g);
            var _sx = _nails[_i][0] + (_q1 - 0.5) * _W * 0.09;
            var _sy = _nails[_i][1];
            var _q2 = wnt_rnd(_g);
            var _len = _H * (0.10 + _q2 * 0.45) * (0.5 + _age);
            wnt_rec_begin(_r);
            wnt_rec_move(_r, _sx, _sy);
            var _q3 = wnt_rnd(_g);
            var _q4 = wnt_rnd(_g);
            wnt_rec_quad(_r, _sx + (_q3 - 0.5) * _W * 0.03, _sy + _len * 0.5, _sx + (_q4 - 0.5) * _W * 0.05, _sy + _len);
            var _q5 = wnt_rnd(_g);
            var _q6 = wnt_rnd(_g);
            wnt_rec_stroke(_r, _ink, 0.030 + _q5 * 0.045 * _age, _W * (0.006 + _q6 * 0.018));
        }
    }
    var _specks = wnt_jsround(_W * _H * 0.00016 * (0.4 + _age));
    for (_i = 0; _i < _specks; _i++) {
        var _fx = wnt_rnd(_g) * _W;
        var _fy = wnt_rnd(_g) * _H;
        wnt_rec_begin(_r);
        var _q7 = wnt_rnd(_g);
        wnt_rec_arc(_r, _fx, _fy, max(0.4, _q7 * _W * 0.0035), 0, pi * 2);
        var _q8 = wnt_rnd(_g);
        wnt_rec_fill(_r, _ink, 0.10 + _q8 * 0.35);
    }
    var _fromLeft = wnt_rnd(_g) < 0.5;
    for (var _b = 0; _b < 14; _b++) {
        var _t = _b / 13;
        var _k = (1 - _t) * (1 - _t);
        var _sw = _W * 0.58 / 14;
        var _x = _fromLeft ? _b * _sw : _W - (_b + 1) * _sw;
        wnt_rec_rect(_r, _x, 0, _sw + 1, _H, [255, 250, 235], (0.045 + _age * 0.055) * _k);
    }
}

/// @function wnt_tear_corner(rec, corner, W, H, bite, ink, gen)
/// @description Tear a corner OFF (erased, not tinted - a tint reads as a fold) and darken the torn edge.
function wnt_tear_corner(_r, _corner, _W, _H, _bite, _ink, _g) {
    var _cx = (_corner == 1 || _corner == 2) ? _W : 0;
    var _cy = (_corner >= 2) ? _H : 0;
    var _sx = (_cx == 0) ? 1 : -1, _sy = (_cy == 0) ? 1 : -1;
    var _q1 = wnt_rnd(_g);
    var _a = _W * _bite * (0.7 + _q1 * 0.6);
    var _q2 = wnt_rnd(_g);
    var _b = _H * _bite * (0.7 + _q2 * 0.6);
    var _pts = [[_cx, _cy + _sy * _b]];
    for (var _i = 1; _i <= 7; _i++) {
        var _t = _i / 7;
        var _q3 = wnt_rnd(_g);
        var _q4 = wnt_rnd(_g);
        array_push(_pts, [_cx + _sx * _a * _t + _sx * (_q3 - 0.5) * _a * 0.22, _cy + _sy * _b * (1 - _t) + _sy * (_q4 - 0.5) * _b * 0.22]);
    }
    array_push(_pts, [_cx, _cy]);
    wnt_rec_begin(_r);
    wnt_rec_move(_r, _pts[0][0], _pts[0][1]);
    for (var _k = 1; _k < array_length(_pts); _k++) wnt_rec_line(_r, _pts[_k][0], _pts[_k][1]);
    wnt_rec_close(_r);
    wnt_rec_erase(_r);
    wnt_rec_begin(_r);
    wnt_rec_move(_r, _pts[0][0], _pts[0][1]);
    for (var _m = 1; _m < 8; _m++) wnt_rec_line(_r, _pts[_m][0], _pts[_m][1]);
    wnt_rec_stroke(_r, _ink, 0.22, min(_W, _H) * 0.006);
}

/// @function wnt_draw_overprint(rec, word, ink, W, H, gen)
/// @description A status overprinted ACROSS the sheet in a second ink, boxed and diagonal - a plot fact, so it must
/// read on a board-sized card, where a tint or a corner note would be invisible.
function wnt_draw_overprint(_r, _word, _inkc, _W, _H, _g) {
    wnt_rec_save(_r);
    wnt_rec_translate(_r, _W / 2, _H / 2);
    var _q = wnt_rnd(_g);
    wnt_rec_rotate(_r, -0.30 + (_q - 0.5) * 0.08);
    var _size = _W * 0.145;
    var _fit = wnt_fit_line(_r, _word, _W * 1.04, { face: WNT_FACE_WOOD, size: _size, minSize: _W * 0.075, track: _size * 0.14, minTrack: _size * 0.02 });
    wnt_set_line(_r, _word, 0, _size * 0.36, { face: WNT_FACE_WOOD, size: _fit.size, track: _fit.track, ink: _inkc, inkA: 0.62, align: "center", rng: _g, press: 1.6 });
    var _bw = _fit.width * 1.10, _bh = _fit.size * 1.55;
    for (var _i = 0; _i < 2; _i++) {
        var _o = _i * _fit.size * 0.10;
        wnt_rec_begin(_r);
        wnt_rec_move(_r, -_bw / 2 - _o, -_bh / 2 - _o); wnt_rec_line(_r, _bw / 2 + _o, -_bh / 2 - _o);
        wnt_rec_line(_r, _bw / 2 + _o, _bh / 2 + _o); wnt_rec_line(_r, -_bw / 2 - _o, _bh / 2 + _o);
        wnt_rec_close(_r);
        wnt_rec_stroke(_r, _inkc, 0.62, _fit.size * ((_i > 0) ? 0.035 : 0.075));
    }
    wnt_rec_restore(_r);
}

// ---------------------------------------------------------------------------------------------------------------
// The record
// ---------------------------------------------------------------------------------------------------------------

/// @function wnt_quarry_name(id)
/// @description A quarry figure's display name ("Dire Wolf"), or "" for an unknown id.
function wnt_quarry_name(_id) {
    if (!is_string(_id)) return "";
    // ⛔ never an accessor on a call result (`wnt_quarry()[$ id]`): it crashes the asset compiler. Read into a local.
    var _q = wnt_quarry();
    var _b = _q[$ _id];
    return is_struct(_b) ? _b.name : "";
}

/// @function wnt_quarry_for(text)
/// @description The quarry id a game's own enemy name or kind points at: an exact id first ("wyvern"), then the first
/// figure whose id, name or clade appears as a word in the text ("Ashen Wyvern of the Fen" -> "wyvern"), else
/// undefined. Lets a buyer hand over their enemy record without keeping a mapping table.
function wnt_quarry_for(_text) {
    if (!is_string(_text) || string_length(_text) == 0) return undefined;
    var _q = wnt_quarry(), _low = string_lower(_text), _ids = wnt_quarry_ids();
    if (is_struct(_q[$ _low])) return _low;
    var _words = wnt__words(string_replace_all(string_replace_all(_low, "-", " "), ",", " "));
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _b = _q[$ _ids[_i]], _keys = [_ids[_i], string_lower(_b.name), string_lower(_b.clade)];
        for (var _k = 0; _k < 3; _k++) {
            var _kw = wnt__words(_keys[_k]);
            if (array_length(_kw) == 0) continue;
            var _last = _kw[array_length(_kw) - 1];
            for (var _w = 0; _w < array_length(_words); _w++) if (_words[_w] == _last || _words[_w] == _last + "s") return _ids[_i];
        }
    }
    return undefined;
}

/// @function wnt__num_string(v)
/// @description A number as JavaScript's String() writes it for the integers a reward is ("1250", never "1250.00"). Internal.
function wnt__num_string(_v) {
    if (is_string(_v)) return _v;
    if (!is_numeric(_v)) return string(_v);
    if (_v == floor(_v) && abs(_v) < 1000000000000000) return string(int64(_v));
    var _s = string_format(_v, 1, 6);
    while (string_length(_s) > 1 && string_char_at(_s, string_length(_s)) == "0") _s = string_delete(_s, string_length(_s), 1);
    if (string_char_at(_s, string_length(_s)) == ".") _s = string_delete(_s, string_length(_s), 1);
    return string_trim(_s);
}

/// @function wnt_poster(spec)
/// @description Normalise a bounty into a complete poster record. spec (every field optional): {quarryId, name, issuer,
/// crime, crimeClass, reward, rewardUnit, jurisdiction, dateline, device, fleuron, stock, wax ([r,g,b]), age (0..1),
/// status ("posted"|"claimed"|"expired"), seed}. ⛔ Every derived choice is SEEDED from the bounty (quarry, jurisdiction,
/// reward) - never random() - so the same bounty prints the same poster on every visit and a board never shuffles.
function wnt_poster(_spec = undefined) {
    var _s = is_struct(_spec) ? _spec : {};
    var _q = wnt_quarry();
    var _qid = wnt__opt(_s, "quarryId", undefined);
    if (!is_string(_qid) || !is_struct(_q[$ _qid])) { var _all = wnt_quarry_ids(); _qid = _all[0]; }
    var _b = _q[$ _qid];
    var _jur = wnt__opt(_s, "jurisdiction", undefined), _rew = wnt__opt(_s, "reward", undefined);
    var _seed;
    var _ss = wnt__opt(_s, "seed", undefined);
    if (is_numeric(_ss)) _seed = wnt_i32(_ss);
    else _seed = wnt_hash(_qid + "|" + ((is_string(_jur) && string_length(_jur) > 0) ? _jur : "") + "|" + (is_undefined(_rew) ? "0" : wnt__num_string(_rew)));
    var _g = wnt_rng(_seed);
    var _crimes = wnt_crimes(), _devices = wnt_devices(), _fleurons = wnt_fleurons(), _stocks = wnt_stocks();
    var _cc = wnt__opt(_s, "crimeClass", undefined);
    if (!is_string(_cc) || is_undefined(_crimes[$ _cc])) { var _ci = wnt_crimes_ids(); _cc = _ci[floor(wnt_rnd(_g) * array_length(_ci))]; }
    var _dv = wnt__opt(_s, "device", undefined);
    if (!is_string(_dv) || is_undefined(_devices[$ _dv])) { var _di = wnt_devices_ids(); _dv = _di[floor(wnt_rnd(_g) * array_length(_di))]; }
    var _fl = wnt__opt(_s, "fleuron", undefined);
    if (!is_string(_fl) || is_undefined(_fleurons[$ _fl])) { var _fi = wnt_fleurons_ids(); _fl = _fi[floor(wnt_rnd(_g) * array_length(_fi))]; }
    var _sk = wnt__opt(_s, "stock", undefined);
    if (!is_string(_sk) || is_undefined(_stocks[$ _sk])) { var _si = wnt_stocks_ids(); _sk = _si[floor(wnt_rnd(_g) * array_length(_si))]; }
    var _age = wnt__opt(_s, "age", undefined);
    if (!is_numeric(_age)) _age = 0.35 + wnt_rnd(_g) * 0.4;
    var _wax = wnt__opt(_s, "wax", undefined);
    if (!is_array(_wax) || array_length(_wax) < 3 || !is_numeric(_wax[0]) || !is_numeric(_wax[1]) || !is_numeric(_wax[2])) _wax = [122, 34, 30];
    var _txt = function(_o, _k, _d) { var _v = _o[$ _k]; return (is_string(_v) && string_length(_v) > 0) ? _v : (is_numeric(_v) ? string(_v) : _d); };
    var _status = wnt__opt(_s, "status", "posted");
    if (_status != "claimed" && _status != "expired") _status = "posted";
    return {
        quarryId: _qid,
        name: _txt(_s, "name", _b.name),
        issuer: _txt(_s, "issuer", "BY ORDER OF THE WARDEN"),
        crime: _txt(_s, "crime", "for depredations upon the common herd"),
        crimeClass: _cc,
        reward: is_undefined(_rew) ? 250 : _rew,
        rewardUnit: _txt(_s, "rewardUnit", "GOLD"),
        jurisdiction: _txt(_s, "jurisdiction", "THE FREE TOWN OF ALDERMOOR"),
        dateline: _txt(_s, "dateline", "posted this day, and not to be torn down"),
        device: _dv, fleuron: _fl, stock: _sk,
        wax: [_wax[0], _wax[1], _wax[2]],
        age: clamp(_age, 0, 1),
        status: _status,
        seed: _seed
    };
}

// ---------------------------------------------------------------------------------------------------------------
// The forme
// ---------------------------------------------------------------------------------------------------------------

/// @function wnt__compose(rec, poster, W, H)
/// @description Compose one poster through a recorder (drawing, or counting only). Returns {counts, fits}. Internal:
/// call wnt_poster_compose / wnt_poster_sprite / wnt_poster_count.
function wnt__compose(_r, _p, _W, _H) {
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _stocks = wnt_stocks(), _quarry = wnt_quarry(), _crimeT = wnt_crimes();
    var _st = _stocks[$ _p.stock];
    var _g = wnt_rng(wnt_u32(_p.seed) ^ $71C5);
    var _fits = {};
    var _ink = wnt_pick_contrast(_st.base, [_st.ink, [246, 240, 224]]);
    var _M = _W * 0.085, _IW = _W - _M * 2, _u = max(0.6, _H * 0.0030), _cx = _W / 2;

    wnt_draw_stock(_r, _st, _W, _H, _p.seed);
    wnt_draw_border(_r, _W, _H, _u, _p.fleuron, _ink, 0.72, _g);

    // the issuing line - ONE line, and it may condense
    var _issS = _H * 0.026;
    var _fI = wnt_fit_line(_r, _p.issuer, _IW * 0.92, { face: WNT_FACE_TEXT, size: _issS, minSize: _issS * 0.66, track: _issS * 0.24, minTrack: 0 });
    _fits.issuer = _fI;
    wnt_set_line(_r, _p.issuer, _cx, _H * 0.078, { face: WNT_FACE_TEXT, size: _fI.size, track: _fI.track, squeeze: _fI.squeeze, ink: _ink, inkA: 0.72, align: "center", rng: _g, press: 0.8 });
    wnt_draw_rule(_r, _M, _H * 0.100, _W - _M, 2, _u, _ink, 1, _g);

    // WANTED, the loudest thing on the sheet
    var _wS = _H * 0.098;
    var _fW = wnt_fit_line(_r, "WANTED", _IW, { face: WNT_FACE_WOOD, size: _wS, minSize: _wS * 0.6, track: _wS * 0.13, minTrack: _wS * 0.02 });
    _fits.wanted = _fW;
    wnt_set_line(_r, "WANTED", _cx, _H * 0.203, { face: WNT_FACE_WOOD, size: _fW.size, track: _fW.track, ink: _ink, inkA: 1, align: "center", rng: _g, press: 1.25 });
    wnt_draw_rule(_r, _M, _H * 0.228, _W - _M, 1, _u, _ink, 1, _g);

    // the woodcut block, sized from the figure (the corpus lives inside +-1.10 units)
    var _by = _H * 0.248, _bh = _H * 0.308, _pad = _u * 7;
    var _rad = (_bh / 2 - _pad) / 1.14;
    var _bw = min(_W - _M * 1.6, _rad * 2.2 + _pad * 4);
    var _bx = (_W - _bw) / 2;
    var _blockPaper = wnt_shade(_st.base, 1.045);
    wnt_rec_rect(_r, _bx, _by, _bw, _bh, _blockPaper, 0.55);
    wnt_draw_ground(_r, _bx, _by, _bw, _bh, _u, _ink, _g);
    wnt_draw_block_frame(_r, _bx, _by, _bw, _bh, _u, _ink, _g);
    var _beast = _quarry[$ _p.quarryId];
    wnt_draw_figure(_r, _beast.paths, _bx + _bw / 2, _by + _bh / 2 + _bh * 0.015, _rad, _ink, _blockPaper, true);

    // the quarry's name - WRAPS to two lines rather than shrinking to nothing
    var _nameBand = _H * 0.556, _nS = _H * 0.050;
    var _fN = wnt_fit_block(_r, string_upper(_p.name), _IW, 2, { face: WNT_FACE_WOOD, size: _nS, minSize: _nS * 0.62, track: _nS * 0.10, minTrack: 0, stepScale: 0.78 });
    _fits.name = _fN;
    var _nLead = _fN.size * 1.12, _ni;
    for (_ni = 0; _ni < array_length(_fN.lines); _ni++) {
        wnt_set_line(_r, _fN.lines[_ni], _cx, _nameBand + _fN.size * 0.92 + _ni * _nLead, { face: WNT_FACE_WOOD, size: _fN.size, track: _fN.track, squeeze: _fN.squeeze, ink: _ink, inkA: 1, align: "center", rng: _g, press: 1.1 });
    }

    // every band below is measured from where the name ACTUALLY ended
    var _nameBottom = _nameBand + _fN.size * 0.92 + (array_length(_fN.lines) - 1) * _nLead;
    var _ruleY = max(_H * 0.636, _nameBottom + _H * 0.026);
    wnt_draw_fleuron_rule(_r, _M, _ruleY, _W - _M, _p.fleuron, _u, _ink, 1, _g);
    var _ms = _H * 0.030, _mark = _crimeT[$ _p.crimeClass];
    wnt_fill_box(_r, _mark, _M - _ms * 0.15, _ruleY - _ms / 2, _ms, _ms, _ink, 0.72);
    wnt_fill_box(_r, _mark, _W - _M - _ms * 0.85, _ruleY - _ms / 2, _ms, _ms, _ink, 0.72);

    // the crime, wrapped and centred in the band that is LEFT
    var _lblY = _H * 0.782, _cTop = _ruleY + _H * 0.016, _cBottom = _lblY - _H * 0.024;
    var _bandH = _cBottom - _cTop, _cS = _H * 0.028, _lines = [], _cLead = 0;
    var _words = wnt__words(_p.crime);
    for (var _att = 0; _att < 4; _att++) {
        _cLead = _cS * 1.30;
        var _cf = { face: WNT_FACE_TEXT, px: _cS };
        _lines = [];
        var _cur = "";
        for (var _i = 0; _i < array_length(_words); _i++) {
            var _trial = (_cur != "") ? _cur + " " + _words[_i] : _words[_i];
            if (wnt_rec_measure(_r, _trial, _cf) > _IW * 0.94 && _cur != "") { array_push(_lines, _cur); _cur = _words[_i]; }
            else _cur = _trial;
        }
        if (_cur != "") array_push(_lines, _cur);
        var _need = (array_length(_lines) - 1) * _cLead + _cS * 0.94;
        if (_need <= _bandH) break;
        _cS *= 0.90;
    }
    var _maxLines = max(1, floor((_bandH - _cS * 0.94) / _cLead) + 1);
    _fits.crimeSize = _cS / _H;
    _fits.crimeLines = array_length(_lines);
    _fits.crimeTruncated = array_length(_lines) > _maxLines;
    if (array_length(_lines) > _maxLines) {
        array_resize(_lines, _maxLines);
        _lines[_maxLines - 1] = _lines[_maxLines - 1] + "...";
    }
    var _cBlock = (array_length(_lines) - 1) * _cLead;
    var _cFirst = (_cTop + _cBottom) / 2 - (_cBlock + _cS * 0.94) / 2 + _cS * 0.72;
    _fits.crimeClearH = (_cBottom - (_cFirst + _cBlock + _cS * 0.22)) / _H;
    for (var _L = 0; _L < array_length(_lines); _L++) {
        wnt_set_line(_r, _lines[_L], _cx, _cFirst + _L * _cLead, { face: WNT_FACE_TEXT, size: _cS, track: 0, ink: _ink, inkA: 0.72, align: "center", rng: _g, press: 0.7 });
    }

    // the reward
    var _lblS = _H * 0.026;
    wnt_set_line(_r, "THE REWARD IS SET AT", _cx, _lblY, { face: WNT_FACE_TEXT, size: _lblS, track: _lblS * 0.22, ink: _ink, inkA: 0.72, align: "center", rng: _g, press: 0.8 });
    var _rewardStr = wnt__num_string(_p.reward) + " " + _p.rewardUnit;
    var _rS = _H * 0.072;
    var _fR = wnt_fit_line(_r, _rewardStr, _IW * 0.96, { face: WNT_FACE_WOOD, size: _rS, minSize: _rS * 0.52, track: _rS * 0.05, minTrack: 0 });
    _fits.reward = _fR;
    wnt_set_line(_r, _rewardStr, _cx, _H * 0.856, { face: WNT_FACE_WOOD, size: _fR.size, track: _fR.track, squeeze: _fR.squeeze, ink: _ink, inkA: 1, align: "center", rng: _g, press: 1.2 });
    wnt_draw_rule(_r, _M, _H * 0.876, _W - _M, 0, _u, _ink, 1, _g);

    // the seal and the jurisdiction
    var _sr = _H * 0.046, _scx = _M + _sr * 1.05, _scy = _H * 0.928;
    wnt_draw_seal(_r, _p.device, _p.wax, _scx, _scy, _sr, _p.seed, _p.status == "claimed");
    var _jx = _scx + _sr * 1.5, _jw = (_W - _M) - _jx, _jS = _H * 0.025;
    var _fJ = wnt_fit_line(_r, _p.jurisdiction, _jw, { face: WNT_FACE_WOOD, size: _jS, minSize: _jS * 0.6, track: _jS * 0.08, minTrack: 0 });
    _fits.jurisdiction = _fJ;
    wnt_set_line(_r, _p.jurisdiction, _jx, _H * 0.917, { face: WNT_FACE_WOOD, size: _fJ.size, track: _fJ.track, ink: _ink, inkA: 1, align: "left", rng: _g, press: 0.9 });
    var _dS = _H * 0.021;
    var _fD = wnt_fit_line(_r, _p.dateline, _jw, { face: WNT_FACE_TEXT, size: _dS, minSize: _dS * 0.6, track: 0, minTrack: 0 });
    _fits.dateline = _fD;
    wnt_set_line(_r, _p.dateline, _jx, _H * 0.950, { face: WNT_FACE_TEXT, size: _fD.size, track: 0, ink: _ink, inkA: 0.72, align: "left", rng: _g, press: 0.7 });

    // and then it went outdoors
    var _n1 = wnt_rnd(_g);
    var _n2 = wnt_rnd(_g);
    var _n3 = wnt_rnd(_g);
    var _n4 = wnt_rnd(_g);
    var _nails = [[_W * (0.10 + _n1 * 0.05), _H * (0.030 + _n2 * 0.018)], [_W * (0.86 + _n3 * 0.05), _H * (0.028 + _n4 * 0.020)]];
    if (_p.age > 0.55) {
        var _n5 = wnt_rnd(_g);
        var _n6 = wnt_rnd(_g);
        array_push(_nails, [_W * (0.45 + _n5 * 0.12), _H * (0.965 - _n6 * 0.02)]);
    }
    wnt_draw_exposure(_r, _nails, _W, _H, _ink, _p.age, _g);
    wnt_draw_nails(_r, _nails, _W, _H, _ink, _g);
    if (_p.age > 0.45) {
        var _t1 = wnt_rnd(_g);
        var _corner = (_t1 < 0.5) ? 2 : 3;
        var _t2 = wnt_rnd(_g);
        wnt_tear_corner(_r, _corner, _W, _H, 0.05 + _t2 * 0.07, _ink, _g);
    }
    if (_p.status == "claimed") wnt_draw_overprint(_r, "CLAIMED", [104, 28, 24], _W, _H, _g);
    else if (_p.status == "expired") wnt_draw_overprint(_r, "EXPIRED", [58, 52, 44], _W, _H, _g);

    math_set_epsilon(_eps);
    return { counts: wnt_rec_counts(_r), fits: _fits };
}

/// @function wnt__valid_poster(p)
/// @description True when p is a poster record wnt_poster made (or one shaped like it). Internal.
function wnt__valid_poster(_p) {
    if (!is_struct(_p)) return false;
    var _need = ["quarryId", "name", "issuer", "crime", "crimeClass", "reward", "rewardUnit", "jurisdiction", "dateline", "device", "fleuron", "stock", "wax", "age", "status", "seed"];
    for (var _i = 0; _i < array_length(_need); _i++) if (is_undefined(_p[$ _need[_i]])) return false;
    if (!is_string(_p.quarryId) || !is_string(_p.stock) || !is_string(_p.crimeClass) || !is_string(_p.fleuron) || !is_string(_p.device)) return false;
    var _q = wnt_quarry(), _s = wnt_stocks(), _c = wnt_crimes(), _f = wnt_fleurons();
    if (!is_struct(_q[$ _p.quarryId]) || is_undefined(_s[$ _p.stock]) || is_undefined(_c[$ _p.crimeClass]) || is_undefined(_f[$ _p.fleuron])) return false;
    if (!is_array(_p.wax) || array_length(_p.wax) < 3 || !is_numeric(_p.age) || !is_numeric(_p.seed) || !is_string(_p.name) || !is_string(_p.crime)) return false;
    return true;
}

/// @function wnt__size_ok(w, h)
/// @description True for a drawable poster size (8..2048 px a side). Internal.
function wnt__size_ok(_w, _h) { return is_numeric(_w) && is_numeric(_h) && _w >= 8 && _h >= 8 && _w <= 2048 && _h <= 2048; }

/// @function wnt_poster_count(poster, w, h)
/// @description Every operation the poster would draw at w x h - {counts, fits} - WITHOUT drawing (no surface needed).
/// Returns undefined for a record that is not a poster or a size outside 8..2048.
function wnt_poster_count(_p, _w, _h) {
    if (!wnt__valid_poster(_p) || !wnt__size_ok(_w, _h)) return undefined;
    return wnt__compose(wnt_rec(undefined), _p, _w, _h);
}

/// @function wnt_poster_compose(poster, w, h, [supersample])
/// @description Draw the poster onto the CURRENT surface target, top-left at 0,0, at w x h user pixels times the
/// supersample factor. ⚠️ The target should be TRANSPARENT and dedicated: the nail holes and the torn corner ERASE
/// (whatever the poster hangs on must show through them), which would punch through anything already drawn there.
/// Returns {counts, fits}, or undefined for a bad record or size. Restores the caller's blend, filter and draw state.
function wnt_poster_compose(_p, _w, _h, _ss = 1) {
    if (!wnt__valid_poster(_p) || !wnt__size_ok(_w, _h)) return undefined;
    _ss = (is_numeric(_ss) && _ss > 0) ? min(_ss, 4) : 1;
    var _pf = draw_get_font(), _ph = draw_get_halign(), _pv = draw_get_valign(), _pc = draw_get_colour(), _pa = draw_get_alpha();
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_texfilter(true);
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false);
    var _out = wnt__compose(wnt_rec(wnt_cx_create(_ss)), _p, _w, _h);
    gpu_pop_state();
    draw_set_font(_pf); draw_set_halign(_ph); draw_set_valign(_pv); draw_set_colour(_pc); draw_set_alpha(_pa);
    return _out;
}

// ---------------------------------------------------------------------------------------------------------------
// Baking and the cache
// ---------------------------------------------------------------------------------------------------------------

/// @function wnt__poster_key(poster, w, h)
/// @description The cache key: every field that changes the picture, plus the size. Internal.
function wnt__poster_key(_p, _w, _h) {
    return string(_p.quarryId) + "|" + string(_p.name) + "|" + string(_p.issuer) + "|" + string(_p.crime) + "|" + string(_p.crimeClass) + "|"
        + wnt__num_string(_p.reward) + "|" + string(_p.rewardUnit) + "|" + string(_p.jurisdiction) + "|" + string(_p.dateline) + "|"
        + string(_p.device) + "|" + string(_p.fleuron) + "|" + string(_p.stock) + "|" + string(_p.wax[0]) + "," + string(_p.wax[1]) + "," + string(_p.wax[2]) + "|"
        + string(_p.age) + "|" + string(_p.status) + "|" + string(_p.seed) + "|" + string(floor(_w)) + "x" + string(floor(_h));
}

/// @function wnt__cache()
/// @description The sprite cache {map, order}. Internal.
function wnt__cache() {
    if (!variable_global_exists("wnt__poster_cache") || !is_struct(global.wnt__poster_cache)) global.wnt__poster_cache = { map: {}, order: [], limit: 64 };
    return global.wnt__poster_cache;
}

/// @function wnt_poster_sprite(poster, w, h)
/// @description The poster as a sprite w x h (origin top-left), baked ONCE at 2x and filtered down, then cached by its
/// fields and size. ⚠️ The sprite is PREMULTIPLIED (nail holes and the torn corner are transparent): wnt_poster_draw
/// draws it correctly; to draw it yourself use gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha). Bake outside a frame's
/// hot path - a poster is a few thousand marks. Returns -1 for a bad record or size. Do not delete the sprite yourself;
/// call wnt_poster_free().
function wnt_poster_sprite(_p, _w, _h) {
    if (!wnt__valid_poster(_p) || !wnt__size_ok(_w, _h)) return -1;
    _w = floor(_w); _h = floor(_h);
    var _c = wnt__cache(), _key = wnt__poster_key(_p, _w, _h);
    var _hit = _c.map[$ _key];
    if (!is_undefined(_hit) && sprite_exists(_hit)) return _hit;
    // ⛔ A bake inside a draw pass inherits the caller's matrix: run every internal pass under IDENTITY, hand it back.
    var _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_build_identity());
    var _big = surface_create(_w * 2, _h * 2);
    surface_set_target(_big);
    draw_clear_alpha(c_black, 0);
    wnt_poster_compose(_p, _w, _h, 2);
    surface_reset_target();
    var _small = surface_create(_w, _h);
    surface_set_target(_small);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    gpu_set_blendmode_ext(bm_one, bm_zero);
    gpu_set_texfilter(true);
    draw_surface_ext(_big, 0, 0, 0.5, 0.5, 0, c_white, 1);
    gpu_pop_state();
    surface_reset_target();
    var _spr = sprite_create_from_surface(_small, 0, 0, _w, _h, false, false, 0, 0);
    surface_free(_big);
    surface_free(_small);
    matrix_set(matrix_world, _mw);
    _c.map[$ _key] = _spr;
    array_push(_c.order, _key);
    // a bounded cache: the oldest poster is freed only after a surface target has been set and reset above, which
    // flushes every draw queued this frame (a sprite deleted right after it is drawn draws as a white box)
    while (array_length(_c.order) > _c.limit) {
        var _old = _c.order[0];
        array_delete(_c.order, 0, 1);
        var _os = _c.map[$ _old];
        if (!is_undefined(_os) && sprite_exists(_os)) sprite_delete(_os);
        variable_struct_remove(_c.map, _old);
    }
    return _spr;
}

/// @function wnt_poster_draw(poster, x, y, w, h, [alpha], [angle])
/// @description Draw a poster with its top-left at (x, y), w x h pixels (baked on first use, cached after), optionally
/// turned `angle` degrees (anticlockwise, about its centre - a poster nailed up slightly askew). Returns true when
/// something was drawn.
function wnt_poster_draw(_p, _x, _y, _w, _h, _alpha = 1, _angle = 0) {
    if (!is_numeric(_x) || !is_numeric(_y)) return false;
    var _spr = wnt_poster_sprite(_p, _w, _h);
    if (_spr < 0) return false;
    _alpha = is_numeric(_alpha) ? clamp(_alpha, 0, 1) : 1;
    _angle = is_numeric(_angle) ? _angle : 0;
    var _sw = sprite_get_width(_spr), _sh = sprite_get_height(_spr);
    var _cx = _x + _sw / 2, _cy = _y + _sh / 2;
    var _ox = _cx - ((_sw / 2) * dcos(_angle) + (_sh / 2) * dsin(_angle));
    var _oy = _cy - (-(_sw / 2) * dsin(_angle) + (_sh / 2) * dcos(_angle));
    gpu_push_state();
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    gpu_set_texfilter(true);
    var _k = round(255 * _alpha);
    draw_sprite_ext(_spr, 0, _ox, _oy, 1, 1, _angle, make_colour_rgb(_k, _k, _k), _alpha);
    gpu_pop_state();
    return true;
}

/// @function wnt_poster_free()
/// @description Free every cached poster sprite (call from Clean Up, or when the board changes completely).
function wnt_poster_free() {
    var _c = wnt__cache();
    for (var _i = 0; _i < array_length(_c.order); _i++) {
        var _s = _c.map[$ _c.order[_i]];
        if (!is_undefined(_s) && sprite_exists(_s)) sprite_delete(_s);
    }
    _c.map = {};
    _c.order = [];
}
