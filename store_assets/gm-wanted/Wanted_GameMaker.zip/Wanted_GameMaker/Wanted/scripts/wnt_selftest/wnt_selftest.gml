/// wnt_selftest.gml - the in-engine suite (`Wanted.exe -selftest` writes wnt_selftest.json). Stage 99 = the suite reached
/// its end. Not needed at runtime: delete it (and wnt_oracle.gml) with the -selftest branch of the demo object's Create.
///
/// Wanted - Every Bounty Prints Its Own Poster, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// What it holds the port to: the published RPG Maker MZ original's own answers (wnt_oracle.gml) - the generator's draws,
/// the hash, every normalised record and every poster's operation counts, so a branch dropped in the port shows as a
/// count that moved. What it measures on pixels: ink where the type and the woodcut are, holes where the nails are, the
/// torn corner, the overprint, determinism, a bake under a caller's transform, and the cache. ⛔ Every picture claim is
/// INK counted on a rendered surface (never "a sprite exists"), every ink assertion has a control, and surface bytes are
/// read R, G, B, A.

function wnt_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 80) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
function wnt_st_stage(_st, _n) { _st.stage = _n; global.wnt_stage = _n; }
function wnt_st_note(_st, _s) { array_push(_st.notes, _s); }

/// @function wnt_st_grab_sprite(sprite)
/// @description A sprite's raw pixels {b, w, h}, drawn with blending OFF (bytes R, G, B, A).
function wnt_st_grab_sprite(_spr) {
    var _w = sprite_get_width(_spr), _h = sprite_get_height(_spr);
    var _sf = surface_create(_w, _h);
    surface_set_target(_sf); draw_clear_alpha(c_black, 0); gpu_set_blendenable(false); draw_sprite(_spr, 0, 0, 0); gpu_set_blendenable(true); surface_reset_target();
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    surface_free(_sf);
    return { b: _b, w: _w, h: _h };
}

/// @function wnt_st_grab_surface(surface)
function wnt_st_grab_surface(_sf) {
    var _w = surface_get_width(_sf), _h = surface_get_height(_sf);
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    return { b: _b, w: _w, h: _h };
}

/// @function wnt_st_count(grab, x0, y0, x1, y1, pred)
/// @description How many pixels in [x0, x1) x [y0, y1) satisfy pred(r, g, b, a).
function wnt_st_count(_g, _x0, _y0, _x1, _y1, _pred) {
    var _n = 0;
    for (var _y = max(0, floor(_y0)); _y < min(_g.h, _y1); _y++) {
        for (var _x = max(0, floor(_x0)); _x < min(_g.w, _x1); _x++) {
            var _o = (_y * _g.w + _x) * 4;
            if (_pred(buffer_peek(_g.b, _o, buffer_u8), buffer_peek(_g.b, _o + 1, buffer_u8), buffer_peek(_g.b, _o + 2, buffer_u8), buffer_peek(_g.b, _o + 3, buffer_u8))) _n++;
        }
    }
    return _n;
}

/// @function wnt_st_diff(a, b)
/// @description Pixels differing between two grabs of one size (any channel); -1 on a size mismatch.
function wnt_st_diff(_a, _b) {
    if (_a.w != _b.w || _a.h != _b.h) return -1;
    var _n = 0;
    for (var _o = 0; _o < _a.w * _a.h * 4; _o += 4) {
        if (buffer_peek(_a.b, _o, buffer_u32) != buffer_peek(_b.b, _o, buffer_u32)) _n++;
    }
    return _n;
}

/// @function wnt_selftest_run()
/// @description Run every stage; returns {total, pass, fail, stage, notes, failures, metrics}.
function wnt_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, stage: 0, notes: [], failures: [], metrics: {} }, _i, _k;
    var _dark = function(_r, _g, _b, _a) { return _a > 200 && (0.2126 * _r + 0.7152 * _g + 0.0722 * _b) < 90; };
    var _clear = function(_r, _g, _b, _a) { return _a < 8; };
    var _opaque = function(_r, _g, _b, _a) { return _a > 247; };
    var _red = function(_r, _g, _b, _a) { return _a > 200 && _r > _g + 30 && _r > _b + 30; };

    // ---- 1: the generator and the hash, bit for bit against the original ----
    wnt_st_stage(_st, 1);
    var _D = wnt_oracle_draws();
    for (_i = 0; _i < array_length(_D); _i++) {
        var _g = wnt_rng(_D[_i].seed), _ok = true;
        for (_k = 0; _k < 6; _k++) { var _v = wnt_rnd(_g); if (_v != _D[_i].d[_k]) { _ok = false; break; } }
        wnt_st_assert(_st, _ok, "rng seed " + string(_D[_i].seed) + " draws differ from the original");
    }
    var _HS = wnt_oracle_hashes();
    for (_i = 0; _i < array_length(_HS); _i++) wnt_st_assert(_st, wnt_hash(_HS[_i].s) == _HS[_i].h, "hash of '" + _HS[_i].s + "' = " + string(wnt_hash(_HS[_i].s)) + ", original " + string(_HS[_i].h));
    wnt_st_assert(_st, wnt_i32(4294967295) == -1 && wnt_i32(-12345) == -12345 && wnt_i32(2147483648) == -2147483648, "ToInt32");

    // ---- 2: every normalised record and every operation count, against the original ----
    wnt_st_stage(_st, 2);
    var _O = wnt_oracle_posters(), _recBad = 0, _cntBad = 0, _glyphCmp = 0, _ops = 0;
    for (_i = 0; _i < array_length(_O); _i++) {
        var _e = _O[_i], _p = wnt_poster(_e.spec), _r = _e.rec;
        var _same = _p.quarryId == _r.quarryId && _p.crimeClass == _r.crimeClass && _p.device == _r.device && _p.fleuron == _r.fleuron && _p.stock == _r.stock && _p.seed == _r.seed && _p.age == _r.age;
        if (!wnt_st_assert(_st, _same, _e.label + ": record differs (" + string(_p.crimeClass) + "/" + string(_p.device) + "/" + string(_p.fleuron) + "/" + string(_p.stock) + " age " + string_format(_p.age, 1, 12) + " seed " + string(_p.seed) + ", original " + string(_r.crimeClass) + "/" + string(_r.device) + "/" + string(_r.fleuron) + "/" + string(_r.stock) + " age " + string_format(_r.age, 1, 12) + " seed " + string(_r.seed) + ")")) _recBad++;
        var _c = wnt_poster_count(_p, _e.w, _e.h);
        if (!wnt_st_assert(_st, is_struct(_c), _e.label + ": count returned nothing")) { _cntBad++; continue; }
        var _n = _c.counts, _o = _e.n;
        _ops += _n.fill + _n.stroke + _n.path;
        var _okc = _n.fill == _o.fill && _n.stroke == _o.stroke && _n.path == _o.path && _n.save == _o.save;
        if (!wnt_st_assert(_st, _okc, _e.label + ": fill/stroke/path/save " + string(_n.fill) + "/" + string(_n.stroke) + "/" + string(_n.path) + "/" + string(_n.save) + ", original " + string(_o.fill) + "/" + string(_o.stroke) + "/" + string(_o.path) + "/" + string(_o.save))) _cntBad++;
        var _tg = _n.text - _c.fits.crimeLines - array_length(_c.fits.name.lines), _to = _o.text - _e.crimeLines - _e.nameLines;
        wnt_st_assert(_st, _tg == _to, _e.label + ": fixed set lines " + string(_tg) + ", original " + string(_to));
        if (!_e.crimeTruncated && !_c.fits.crimeTruncated) { _glyphCmp++; wnt_st_assert(_st, _n.glyph == _o.glyph, _e.label + ": glyphs " + string(_n.glyph) + ", original " + string(_o.glyph)); }
        wnt_st_assert(_st, _c.fits.crimeClearH >= 0, _e.label + ": the crime runs into the reward label (clear " + string(_c.fits.crimeClearH) + ")");
    }
    _st.metrics.oraclePosters = array_length(_O);
    _st.metrics.oracleOps = _ops;
    _st.metrics.glyphCompared = _glyphCmp;
    wnt_st_assert(_st, _glyphCmp >= array_length(_O) - 2, "glyph comparison ran on only " + string(_glyphCmp) + " posters");
    wnt_st_note(_st, "oracle: " + string(array_length(_O)) + " posters, " + string(_ops) + " path/fill/stroke ops compared; records bad " + string(_recBad) + ", counts bad " + string(_cntBad));

    // ---- 3: the layout keeps its promises at every size (every fitter verdict honoured, the crime clear of the reward) ----
    wnt_st_stage(_st, 3);
    var _sizes = [[90, 135], [160, 240], [300, 450], [600, 900], [1000, 1500]];
    var _ids = wnt_quarry_ids();
    var _unfit = 0;
    for (_i = 0; _i < array_length(_ids); _i++) {
        var _pp = wnt_poster({ quarryId: _ids[_i], name: (_i mod 7 == 0) ? "The Three-Necked Terror of Blackwater Reach" : undefined, reward: 10 + _i * 211, crime: "for the burning of the mill at Harrow Ford and the taking of nine sheep from the common" });
        for (_k = 0; _k < array_length(_sizes); _k++) {
            var _cc = wnt_poster_count(_pp, _sizes[_k][0], _sizes[_k][1]);
            if (_cc.fits.crimeClearH < 0 || _cc.fits.name.squeeze < 0.5 || _cc.fits.reward.squeeze < 0.6) _unfit++;
        }
    }
    wnt_st_assert(_st, _unfit == 0, string(_unfit) + " poster/size pairs broke the layout (crime overlap, or a squeeze under 0.5 / 0.6)");

    // ---- 4: pixels. Control first: a blank surface reads blank, a painted one reads painted ----
    wnt_st_stage(_st, 4);
    var _ctl = surface_create(64, 64);
    surface_set_target(_ctl); draw_clear_alpha(c_black, 0); surface_reset_target();
    var _cg = wnt_st_grab_surface(_ctl);
    wnt_st_assert(_st, wnt_st_count(_cg, 0, 0, 64, 64, _clear) == 4096 && wnt_st_count(_cg, 0, 0, 64, 64, _dark) == 0, "blank control does not read blank");
    surface_set_target(_ctl); draw_clear_alpha(make_colour_rgb(20, 18, 16), 1); surface_reset_target();
    buffer_delete(_cg.b); _cg = wnt_st_grab_surface(_ctl);
    wnt_st_assert(_st, wnt_st_count(_cg, 0, 0, 64, 64, _dark) == 4096, "dark control does not read dark");
    var _bytes = [buffer_peek(_cg.b, 0, buffer_u8), buffer_peek(_cg.b, 1, buffer_u8), buffer_peek(_cg.b, 2, buffer_u8), buffer_peek(_cg.b, 3, buffer_u8)];
    wnt_st_note(_st, "control bytes for (20,18,16,255): " + string(_bytes));
    buffer_delete(_cg.b); surface_free(_ctl);

    // one poster, read like a buyer would: ink in the WANTED band, in the woodcut, in the reward; paper everywhere else
    var _W = 300, _H = 450;
    var _P1 = wnt_poster({ quarryId: "wyvern", reward: 800, jurisdiction: "THE MARCH OF HOLLOWAY", age: 0.9, status: "posted" });
    var _t0 = get_timer();
    var _s1 = wnt_poster_sprite(_P1, _W, _H);
    var _bake1 = (get_timer() - _t0) / 1000;
    wnt_st_assert(_st, sprite_exists(_s1) && sprite_get_width(_s1) == _W && sprite_get_height(_s1) == _H, "poster sprite missing or wrong size");
    var _G1 = wnt_st_grab_sprite(_s1);
    var _opq = wnt_st_count(_G1, 0, 0, _W, _H, _opaque) / (_W * _H);
    wnt_st_assert(_st, _opq > 0.90, "only " + string(_opq) + " of the sheet is opaque paper");
    var _inkWanted = wnt_st_count(_G1, _W * 0.085, _H * 0.11, _W * 0.915, _H * 0.215, _dark) / ((_W * 0.83) * (_H * 0.105));
    wnt_st_assert(_st, _inkWanted > 0.12 && _inkWanted < 0.80, "WANTED band ink " + string(_inkWanted));
    var _inkBlock = wnt_st_count(_G1, _W * 0.3, _H * 0.26, _W * 0.7, _H * 0.54, _dark) / ((_W * 0.4) * (_H * 0.28));
    wnt_st_assert(_st, _inkBlock > 0.10 && _inkBlock < 0.75, "woodcut block ink " + string(_inkBlock));
    var _inkReward = wnt_st_count(_G1, _W * 0.1, _H * 0.80, _W * 0.9, _H * 0.865, _dark) / ((_W * 0.8) * (_H * 0.065));
    wnt_st_assert(_st, _inkReward > 0.08, "reward band ink " + string(_inkReward));
    var _inkMargin = wnt_st_count(_G1, _W * 0.4, _H * 0.58, _W * 0.6, _H * 0.59, _dark);
    wnt_st_note(_st, "ink: wanted " + string_format(_inkWanted, 1, 3) + " block " + string_format(_inkBlock, 1, 3) + " reward " + string_format(_inkReward, 1, 3) + ", opaque " + string_format(_opq, 1, 3));
    // holes: an old poster has nail holes at the top and a torn bottom corner, both TRANSPARENT
    var _holesTop = wnt_st_count(_G1, 0, 0, _W, _H * 0.08, _clear);
    wnt_st_assert(_st, _holesTop > 4, "nail holes are not transparent (" + string(_holesTop) + " clear pixels in the top band)");
    var _tornL = wnt_st_count(_G1, 0, _H * 0.85, _W * 0.15, _H, _clear), _tornR = wnt_st_count(_G1, _W * 0.85, _H * 0.85, _W, _H, _clear);
    wnt_st_assert(_st, max(_tornL, _tornR) > 60, "the torn corner is not transparent (" + string(_tornL) + " / " + string(_tornR) + ")");
    var _young = wnt_poster({ quarryId: "wyvern", reward: 800, jurisdiction: "THE MARCH OF HOLLOWAY", age: 0.1, status: "posted" });
    var _sy = wnt_poster_sprite(_young, _W, _H), _GY = wnt_st_grab_sprite(_sy);
    var _yl = wnt_st_count(_GY, 0, _H * 0.85, _W * 0.15, _H, _clear) + wnt_st_count(_GY, _W * 0.85, _H * 0.85, _W, _H, _clear);
    wnt_st_assert(_st, _yl < 20, "a young poster (age 0.1) has a torn corner too (" + string(_yl) + " clear pixels) - the control");
    // determinism: free the cache, bake again, byte-identical
    wnt_poster_free();
    var _s1b = wnt_poster_sprite(_P1, _W, _H), _G1b = wnt_st_grab_sprite(_s1b);
    var _dd = wnt_st_diff(_G1, _G1b);
    wnt_st_assert(_st, _dd == 0, "the same poster baked twice differs in " + string(_dd) + " pixels");
    // a different quarry is a different picture (and the diff instrument can return non-zero)
    var _s2 = wnt_poster_sprite(wnt_poster({ quarryId: "bear", reward: 800, jurisdiction: "THE MARCH OF HOLLOWAY", age: 0.9 }), _W, _H), _G2 = wnt_st_grab_sprite(_s2);
    wnt_st_assert(_st, wnt_st_diff(_G1, _G2) > 2000, "two quarries baked the same picture");

    // ---- 5: the overprint is a plot fact and it shows ----
    wnt_st_stage(_st, 5);
    var _base = { quarryId: "stag", reward: 300, jurisdiction: "THE COUNTY OF GREYFELL", age: 0.3 };
    var _pp0 = wnt_poster(_base); _base.status = "claimed";
    var _pp1 = wnt_poster(_base); _base.status = "expired";
    var _pp2 = wnt_poster(_base);
    var _Ga = wnt_st_grab_sprite(wnt_poster_sprite(_pp0, _W, _H)), _Gb = wnt_st_grab_sprite(wnt_poster_sprite(_pp1, _W, _H)), _Gc = wnt_st_grab_sprite(wnt_poster_sprite(_pp2, _W, _H));
    var _redA = wnt_st_count(_Ga, 0, _H * 0.2, _W, _H * 0.8, _red), _redB = wnt_st_count(_Gb, 0, _H * 0.2, _W, _H * 0.8, _red);
    wnt_st_assert(_st, _redB > _redA + 1500, "CLAIMED adds too little red ink (" + string(_redA) + " -> " + string(_redB) + ")");
    wnt_st_assert(_st, wnt_st_diff(_Ga, _Gc) > 3000, "EXPIRED changes too little of the sheet");
    wnt_st_note(_st, "overprint red pixels: posted " + string(_redA) + ", claimed " + string(_redB));

    // ---- 6: a bake under a caller's transform gives the same picture and hands the matrix back ----
    wnt_st_stage(_st, 6);
    wnt_poster_free();
    var _m2 = matrix_build(0, 0, 0, 0, 0, 0, 2, 2, 1);
    matrix_set(matrix_world, _m2);
    var _sT = wnt_poster_sprite(_P1, _W, _H);
    var _after = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_build_identity());
    var _GT = wnt_st_grab_sprite(_sT);
    wnt_st_assert(_st, wnt_st_diff(_G1, _GT) == 0, "a bake under a 2x world matrix differs from the plain bake");
    wnt_st_assert(_st, _after[0] == 2 && _after[5] == 2, "the caller's world matrix was not handed back");

    // ---- 7: the public surface refuses nonsense without throwing, and still accepts the real thing ----
    wnt_st_stage(_st, 7);
    wnt_st_assert(_st, wnt_poster_sprite(undefined, 100, 150) == -1 && wnt_poster_sprite(_P1, 0, 150) == -1 && wnt_poster_sprite(_P1, 100, 5000) == -1 && wnt_poster_sprite({ quarryId: "nope" }, 100, 150) == -1, "bad sprite args not refused");
    wnt_st_assert(_st, is_undefined(wnt_poster_count(undefined, 100, 150)) && is_undefined(wnt_poster_count(_P1, "x", 150)), "bad count args not refused");
    wnt_st_assert(_st, wnt_poster_draw(undefined, 0, 0, 100, 150) == false && wnt_poster_draw(_P1, "a", 0, 100, 150) == false, "bad draw args not refused");
    var _q = wnt_poster({ quarryId: "nope", stock: "gold", device: 7, wax: "red", age: "old", status: "flying", reward: undefined, name: "" });
    wnt_st_assert(_st, wnt__valid_poster(_q) && _q.quarryId == "direwolf" && _q.status == "posted" && _q.reward == 250 && _q.name == "Dire Wolf", "a nonsense spec does not normalise to a valid poster");
    var _pu = wnt_poster(undefined);
    wnt_st_assert(_st, _pu.quarryId == "direwolf" && wnt__valid_poster(wnt_poster("x")), "a non-struct spec does not give the default poster");
    wnt_st_assert(_st, wnt_quarry_for("Ashen Wyvern of the Fen") == "wyvern" && wnt_quarry_for("giant rats") == "rat" && wnt_quarry_for("BEAR") == "bear" && is_undefined(wnt_quarry_for("xyzzy")) && is_undefined(wnt_quarry_for(12)), "wnt_quarry_for matching");
    wnt_st_assert(_st, wnt_quarry_name("hydra") != "" && wnt_quarry_name("nope") == "" && wnt_quarry_name(undefined) == "", "wnt_quarry_name");
    wnt_st_assert(_st, wnt__num_string(1250) == "1250" && wnt__num_string(12.5) == "12.5" && wnt__num_string("ten") == "ten", "reward number formatting");

    // ---- 8: the cache never draws a freed sprite as a white box (two sizes in one frame, then over the limit) ----
    wnt_st_stage(_st, 8);
    var _sf = surface_create(400, 300);
    surface_set_target(_sf); draw_clear_alpha(c_black, 1);
    wnt_poster_draw(_P1, 0, 0, 120, 180);
    wnt_poster_draw(_P1, 140, 0, 160, 240);
    surface_reset_target();
    var _GS = wnt_st_grab_surface(_sf);
    var _white = wnt_st_count(_GS, 0, 0, 400, 300, function(_r, _g, _b, _a) { return _r > 252 && _g > 252 && _b > 252; });
    wnt_st_assert(_st, _white < 50, string(_white) + " pure-white pixels: a poster drew as a white box");
    var _paper = wnt_st_count(_GS, 0, 0, 120, 180, function(_r, _g, _b, _a) { return _r > 120 && _g > 100; });
    wnt_st_assert(_st, _paper > 120 * 180 * 0.4, "the small poster did not draw (" + string(_paper) + " paper pixels)");
    buffer_delete(_GS.b); surface_free(_sf);
    var _cache = wnt__cache();
    var _lim = _cache.limit;
    for (_i = 0; _i < _lim + 6; _i++) wnt_poster_sprite(wnt_poster({ quarryId: _ids[_i mod array_length(_ids)], reward: _i }), 40, 60);
    _cache = wnt__cache();
    var _held = array_length(_cache.order);
    wnt_st_assert(_st, _held == _lim, "the cache grew past its limit (" + string(_held) + ")");

    // ---- 9: renders saved for LOOKING (the suite cannot judge a picture): the 49 figures, a board, one big poster ----
    wnt_st_stage(_st, 9);
    var _cs = 120, _cols = 7, _rows = 7;
    var _sheet = surface_create(_cs * _cols, _cs * _rows);
    surface_set_target(_sheet); draw_clear_alpha(make_colour_rgb(232, 220, 192), 1);
    gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    var _rc = wnt_rec(wnt_cx_create(1)), _thin = 0, _qt = wnt_quarry();
    surface_reset_target();
    gpu_pop_state();
    for (_i = 0; _i < array_length(_ids); _i++) {
        surface_set_target(_sheet);
        gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
        var _gx = (_i mod _cols) * _cs, _gy = (_i div _cols) * _cs;
        var _bst = _qt[$ _ids[_i]];
        wnt_draw_figure(_rc, _bst.paths, _gx + _cs / 2, _gy + _cs / 2, _cs * 0.40, [23, 19, 16], [232, 220, 192], false);
        gpu_pop_state();
        surface_reset_target();
    }
    var _GSH = wnt_st_grab_surface(_sheet);
    for (_i = 0; _i < array_length(_ids); _i++) {
        var _fx = (_i mod _cols) * _cs, _fy = (_i div _cols) * _cs;
        var _ink = wnt_st_count(_GSH, _fx, _fy, _fx + _cs, _fy + _cs, _dark) / (_cs * _cs);
        if (_ink < 0.04) { _thin++; wnt_st_note(_st, "thin figure: " + _ids[_i] + " ink " + string(_ink)); }
    }
    wnt_st_assert(_st, _thin == 0, string(_thin) + " of 49 figures drew under 4% ink");
    surface_save(_sheet, "wnt_render_quarry.png");
    buffer_delete(_GSH.b); surface_free(_sheet);
    // a board of twelve
    var _bw = 4 * 210 + 40, _bh = 3 * 300 + 40;
    var _board = surface_create(_bw, _bh);
    var _cards = [];
    for (_i = 0; _i < 12; _i++) {
        array_push(_cards, wnt_poster({ quarryId: _ids[(_i * 4 + 1) mod array_length(_ids)], reward: 50 + _i * 175, jurisdiction: ["THE FREE TOWN OF ALDERMOOR", "THE PORT OF SALTBRIDGE", "THE MARCH OF HOLLOWAY"][_i mod 3], status: ["posted", "posted", "claimed", "posted", "expired", "posted"][_i mod 6] }));
        wnt_poster_sprite(_cards[_i], 190, 285);
    }
    surface_set_target(_board); draw_clear_alpha(make_colour_rgb(74, 52, 36), 1);
    for (_i = 0; _i < 12; _i++) wnt_poster_draw(_cards[_i], 20 + (_i mod 4) * 210, 20 + (_i div 4) * 300, 190, 285);
    surface_reset_target();
    surface_save(_board, "wnt_render_board.png");
    surface_free(_board);
    var _bigP = wnt_poster({ quarryId: "wyvern", reward: 1250, name: "The Ash Wyvern of Holloway Fen", jurisdiction: "THE MARCH OF HOLLOWAY", crime: "for the burning of the mill at Harrow Ford and the taking of nine sheep", age: 0.7 });
    var _t1 = get_timer();
    var _bigS = wnt_poster_sprite(_bigP, 600, 900);
    var _bake2 = (get_timer() - _t1) / 1000;
    var _big = surface_create(600, 900);
    surface_set_target(_big); draw_clear_alpha(make_colour_rgb(74, 52, 36), 1); wnt_poster_draw(_bigP, 0, 0, 600, 900); surface_reset_target();
    surface_save(_big, "wnt_render_poster.png");
    surface_free(_big);
    _st.metrics.bakeMs300 = _bake1;
    _st.metrics.bakeMs600 = _bake2;
    wnt_st_note(_st, "bake ms: 300x450 " + string_format(_bake1, 1, 1) + ", 600x900 " + string_format(_bake2, 1, 1));
    wnt_st_assert(_st, _bake2 < 4000, "a 600x900 bake took " + string(_bake2) + " ms");
    buffer_delete(_G1.b); buffer_delete(_G1b.b); buffer_delete(_G2.b); buffer_delete(_GY.b); buffer_delete(_Ga.b); buffer_delete(_Gb.b); buffer_delete(_Gc.b); buffer_delete(_GT.b);
    wnt_poster_free();

    wnt_st_stage(_st, 99);
    return _st;
}

/// @function wnt_selftest_write(st)
/// @description Write the suite's result to wnt_selftest.json in the game's save area.
function wnt_selftest_write(_st) {
    var _f = file_text_open_write("wnt_selftest.json");
    file_text_write_string(_f, json_stringify(_st));
    file_text_close(_f);
}
