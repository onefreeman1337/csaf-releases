/// @description Free every cached poster sprite.
wnt_poster_free();
