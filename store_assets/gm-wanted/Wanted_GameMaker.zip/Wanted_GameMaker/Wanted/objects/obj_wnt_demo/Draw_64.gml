/// @description The board and the examine view.
wnt_demo_draw(demo);
