/// @description Select, claim, expire, re-post or replace a bounty.
wnt_demo_step(demo);
