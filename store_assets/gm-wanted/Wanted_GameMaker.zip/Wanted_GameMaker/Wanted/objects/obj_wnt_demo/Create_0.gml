/// @description Wanted demo - a bounty board of eight generated posters - and the headless entry point (-selftest).
/// ⛔ The crash handler is installed FIRST, and every variable a later event reads is declared ABOVE the early exits:
/// Clean Up always runs, even when Create leaves early.
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("wnt_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.wnt_stage) + ": " + string(_ex.message) + " | " + string(_ex.stacktrace));
    file_text_close(_f);
    game_end();
});
global.wnt_stage = 0;
demo = wnt_demo_state();
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";
if (string_pos("-selftest", _args) > 0) { global.wnt_stage = 1; wnt_selftest_write(wnt_selftest_run()); game_end(); exit; }
