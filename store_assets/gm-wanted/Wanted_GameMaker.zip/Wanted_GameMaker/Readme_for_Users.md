# Wanted - Every Bounty Prints Its Own Poster, for GameMaker

Every bounty in your game prints its own wanted poster, generated from the bounty itself: a woodcut figure of the
quarry, the WANTED set in wood type, the name, the charge, the reward, and the issuing jurisdiction's wax seal - struck
on aged paper that has been nailed to a board, rained on and torn. When the bounty is claimed or runs out, the same
sheet is overprinted CLAIMED or EXPIRED. Nothing is an image file: every sheet is drawn by the package.

- **49 woodcut quarry figures** (wolves, wyverns, serpents, spiders, a hydra, an anglerfish, a heron...), each a
  hand-authored silhouette, cut on its own ground inside a ruled block frame.
- **4 paper stocks** that differ in tooth, fibre, laid lines and tone (rag, pulp, linen, tar) - not one sheet in four tints.
- **12 seal devices** struck into the wax in relief, **10 crime marks**, **5 fleurons** for the cast border.
- **Letterpress type, glyph by glyph**: each letter carries its own baseline jitter and ink weight, and now and then one
  prints light - all from a seed, so the same bounty prints the same poster every time.
- **Weathering that follows from the board**: real holes at the nails (whatever the poster hangs on shows through),
  rain streaks running down from them, specks, a sun-faded side and, on an old sheet, a torn-off corner.
- **Statuses**: posted, claimed (the seal splits, CLAIMED is overprinted in red), expired (EXPIRED in a second ink).

Ported from our RPG Maker MZ plugin Wanted Posters and held to it: an in-engine suite checks every poster's drawing
operations against the numbers the original produced.

## Install

1. In GameMaker, **Tools > Import Local Package**, choose `Wanted.yymps`, and import everything.
2. Run the project with `rm_wnt_demo` first in the room order to see the demo board: arrows select, **C** claim,
   **X** expire, **P** post again, **N** a new bounty, click a poster to examine it.

Requires GameMaker 2024.14 or later. Built and tested on runtime 2024.14.4.268 (the VM, Windows). It is pure GML with no
extension; nothing here depends on GMRT.

## Quickstart

```gml
// Create - once per bounty
my_bounty = wnt_poster({
    quarryId: "wyvern",
    name: "The Ash Wyvern of Holloway Fen",
    reward: 1250,
    jurisdiction: "THE MARCH OF HOLLOWAY",
    crime: "for the burning of the mill at Harrow Ford"
});

// Draw or Draw GUI - the first draw bakes it, every later draw is one sprite
wnt_poster_draw(my_bounty, x, y, 200, 300);

// when the player turns it in
my_bounty.status = "claimed";      // the next draw bakes the overprinted sheet

// Clean Up
wnt_poster_free();
```

Your own enemy data can choose the figure: `wnt_quarry_for("Giant Rats of the Sewer")` returns `"rat"`,
`wnt_quarry_for("Ashen Wyvern")` returns `"wyvern"`, and `undefined` when nothing matches (then pick one yourself from
`wnt_quarry_ids()`).

## The bounty spec

Every field is optional. A missing or unusable field falls back to a default, never to a crash.

| field | what it is | default |
| --- | --- | --- |
| `quarryId` | which of the 49 figures (see `wnt_quarry_ids()`) | `"direwolf"` |
| `name` | the quarry's name, set in wood type; long names break over two lines | the figure's own name |
| `issuer` | the line above WANTED | `"BY ORDER OF THE WARDEN"` |
| `crime` | the charge, set in the plate serif, wrapped to fit | `"for depredations upon the common herd"` |
| `crimeClass` | the mark at both ends of the rule: depredation, slaughter, theft, blight, abduction, haunting, plunder, poison, trespass, heresy | seeded |
| `reward` | a number or a string | `250` |
| `rewardUnit` | the word after it | `"GOLD"` |
| `jurisdiction` | who issued it, beside the seal | `"THE FREE TOWN OF ALDERMOOR"` |
| `dateline` | the small line under it | `"posted this day, and not to be torn down"` |
| `device` | the seal's charge: tower, key, sword, antler, portcullis, oak, hand, wheel, anchor, quill, scales, crown | seeded |
| `fleuron` | the border ornament: lozenge, star, trefoil, pierced, acorn | seeded |
| `stock` | the paper: rag, pulp, linen, tar | seeded |
| `wax` | the seal's colour, `[r, g, b]` | `[122, 34, 30]` |
| `age` | 0..1; above 0.45 a corner is torn off, above 0.55 a third nail goes in | seeded, 0.35..0.75 |
| `status` | `"posted"`, `"claimed"` or `"expired"` | `"posted"` |
| `seed` | an integer; omit it and the seed is derived from the quarry, jurisdiction and reward | derived |

"Seeded" means derived from the bounty, so the same bounty always gets the same paper, seal and border.

## Functions

| function | what it does |
| --- | --- |
| `wnt_poster(spec)` | normalises a spec into a poster record (a plain struct; you may change its fields afterwards) |
| `wnt_poster_draw(poster, x, y, w, h, [alpha], [angle])` | draws the poster with its top-left at x, y, optionally turned `angle` degrees about its centre; returns true when it drew |
| `wnt_poster_sprite(poster, w, h)` | the poster as a cached sprite (baked once at 2x and filtered down); -1 for a bad record or a size outside 8..2048 |
| `wnt_poster_compose(poster, w, h, [supersample])` | draws the poster straight onto the current surface target at 0, 0 (for your own surfaces) |
| `wnt_poster_count(poster, w, h)` | every drawing operation the poster would make, `{counts, fits}`, without drawing anything |
| `wnt_poster_free()` | frees every cached poster sprite |
| `wnt_quarry_ids()` | the 49 figure ids |
| `wnt_quarry_name(id)` | a figure's display name, or `""` |
| `wnt_quarry_for(text)` | the figure an enemy name or kind points at, or `undefined` |

**The sprites are premultiplied** (the nail holes and the torn corner are transparent). `wnt_poster_draw` blends them
correctly; if you draw a sprite from `wnt_poster_sprite` yourself, use `gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha)`.
**Do not `sprite_delete` a cached sprite**; call `wnt_poster_free()`. The cache holds the 64 most recent posters and frees
the oldest itself.

`wnt_poster_compose` erases where the nails and the tear are, so give it a transparent surface of its own.

## Performance

A poster is a few thousand drawing operations, so it is baked once and drawn from a sprite after that. Measured in the
suite during development: a 300 x 450 poster in 193 to 216 ms and a 600 x 900 poster in 140 to 186 ms, over 3 runs on a shared Windows machine (the first bake in a session also loads the font atlases). Bake when a bounty is posted (a scene start, a quest update), not every
frame - `wnt_poster_draw` does exactly that for you.

## Removing the demo

Delete `obj_wnt_demo`, `rm_wnt_demo`, `wnt_demo`, `wnt_selftest` and `wnt_oracle`. Nothing else refers to them.

## Namespacing

Every function and macro is prefixed `wnt_` / `WNT_`; the only globals are `global.wnt__*` caches and `global.wnt_stage`
(the demo's crash reporter). The fonts are `fnt_wanted*`. Nothing here touches your rooms, layers or objects.

## Fonts

The wood type is Rye and the plate serif is IM Fell DW Pica, both under the SIL Open Font License 1.1, rasterised into
GameMaker atlases under the names "Wanted Wood Type" and "Wanted Plate Serif"; the demo's help line is Open Sans
(Apache 2.0). Licence texts and notices are in `Wanted/fonts/`. You may use them in your game freely.

## Verification

The in-engine suite (632 assertions, all passing on the shipped source) holds this port to the original RPG Maker MZ plugin: for 98 bounties, every random draw, every normalised record and every path, fill and stroke count - 174,029 operations - match the original exactly. It also counts ink on rendered posters (the type, the woodcut, the nail holes, the torn corner, the overprint) against controls. A fresh import into a blank project runs this Readme's own code (21 checks, all passing), and an adversarial pass makes 36 bad calls into the documented functions with 0 crashes.

## AI disclosure

This package was written with AI assistance: the code and the generated graphics. It contains no AI-generated audio.

Core Systems Asset Factory - https://csaf.itch.io
