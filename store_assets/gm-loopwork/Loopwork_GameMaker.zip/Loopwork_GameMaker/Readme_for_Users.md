# Loopwork - for GameMaker

**The world resets. The player does not. A time-loop engine with a Loop Ledger drawn as an engraved brass astrolabe.**

A time-loop game needs the same machinery every time: facts the player keeps across loops, a record of what
they did differently in each one, a snapshot of the world at dawn, and a rewind that puts the world back
without taking back what the player learned. Loopwork is that machinery, in pure GML, and it draws the
player's whole run as an instrument they will want to open.

The **Loop Ledger** is an astrolabe. The engraved plate is what the player DID: one ring per loop, oldest
innermost, the live loop inlaid in blued steel, and every choice they made differently struck into that
loop's ring as a blued-steel pin. The pierced rete laid over it is what they KNOW: every fact is a star with
a jewel in the colour of the loop it was learned in, and facts from the same loop are wired together. When
a loop closes, the rete turns once and the new ring is cut.

Beside it, **every fact is struck as its own wax seal**: an outline, a border band and a device composed
from the fact's id, in the wax of the loop it was learned in. None of it is an image file. All of it is
drawn at run time from the loop record, so a run nobody has played yet still has a Ledger.

---

## What it does

- **Facts that survive the reset.** `lpw_learn` is idempotent and remembers the loop a fact was FIRST
  learned in; learning it again in a later loop changes nothing, because that first loop is the story.
- **Loop-gated content.** `lpw_knows`, `lpw_fact_loop`, `lpw_learned_this_loop`, `lpw_diverged` and
  `lpw_loop` are the questions dialogue and events ask ("has the player learned the bell code?",
  "is this the first loop they rang the bell?", "is it loop 5 or later?").
- **Divergences, per loop.** `lpw_diverge` records a choice once per loop, so the same choice made again in
  a new loop is recorded again, in that loop. The Ledger draws each loop's own.
- **The rewind is a plan, not an action.** `lpw_anchor` snapshots the world at dawn as `[name, value]`
  pairs. `lpw_plan_rewind` returns which names to put back and which to leave alone (carried across loops)
  and changes nothing. You apply it to your own globals, instance variables or save struct. Loopwork never
  reaches into your game.
- **History that cannot grow without bound.** `lpw_close_loop` keeps the last 40 loops' records (you can
  change the cap). The loop COUNTER is never trimmed: how many loops the player survived is a story beat.
- **Saves that do not break.** `lpw_save` gives a string; `lpw_load` migrates the record on every load and
  turns anything unreadable into a fresh record rather than an exception.
- **The Loop Ledger screen.** `lpw_ledger_draw` lays out the astrolabe and a captioned seal for every fact
  inside any rectangle you give it, from a 640x360 journal page to a full-screen pause menu.
- **384 seals.** Eight outlines, six border bands, eight devices, and a wax for each loop. Within one
  ledger no two facts ever share a seal (up to 384 facts), and the first 48 all differ in outline AND band.
- **The same engine as the RPG Maker MZ edition.** The rules and the knowledge constellation's layout are
  the same as our Loop Core plugin for RPG Maker MZ: the same fact ids lay out identically in both engines.

## Requirements

GameMaker 2024.14 or later. Built and tested with the **runtime 2024.14.4.268** on Windows (the VM runtime).
Pure GML: no extension, no DLL, no shader, no sprites.

## Install

1. **Tools > Import Local Package**, choose `Loopwork.yymps`, and import everything.
2. Press Play. `rm_lpw_demo` opens the Loop Ledger of a run three loops deep. Press L to learn a fact, D to
   make a different choice, B and G to change the world, and R to end the loop and watch it rewind.

If you only want the library, import the `lpw_*` scripts and the four `fnt_loopwork*` fonts;
`obj_lpw_demo` and `rm_lpw_demo` are the demo, and `lpw_bake` only renders the store images.

## Quickstart

Put this in an object's events.

```gml
// Create
my_loop = lpw_create();
lpw_anchor(my_loop, [["bell_rung", false], ["gate_open", false]]);   // the world at dawn

// when the player finds something out
lpw_learn(my_loop, "mayor-lies", "The mayor lies about the flood");

// when the player does something differently this loop
lpw_diverge(my_loop, "took-the-boat", "Took the ferryman's boat");

// in dialogue: loop-gated lines
if (lpw_knows(my_loop, "mayor-lies")) show_debug_message("You again. You know, don't you.");

// when the loop ends
var my_plan = lpw_plan_rewind(my_loop, ["bell_rung", "gate_open"]);
for (var i = 0; i < array_length(my_plan.restore); i++) {
    variable_global_set(my_plan.restore[i][0], my_plan.restore[i][1]);
}
lpw_close_loop(my_loop, "drowned");

// Draw GUI - the Loop Ledger, anywhere
lpw_ledger_draw(my_loop, 40, 40, 1200, 640);
```

### Carrying something across loops

Name it in the third argument. A name that is both in the world list and carried is left alone and
reported in `skipped`:

```gml
var my_plan = lpw_plan_rewind(my_loop, ["gold", "door_open", "lamp_lit"], ["gold"]);
// my_plan.restore = [["door_open", false], ["lamp_lit", false]]    my_plan.skipped = ["gold"]
```

### Animating a loop closing

`lpw_ledger_draw` and `lpw_astrolabe_draw` take a `turn` (radians, the rete's rotation) and a `reveal`
(0 to 1, how far round the new loop's ring has been cut). Close the loop, then run `my_t` from 0 to 1:

```gml
// Step
if (my_t < 1) my_t = min(1, my_t + 1 / 75);

// Draw GUI
var my_e = 0.5 - 0.5 * cos(pi * my_t);
lpw_ledger_draw(my_loop, 40, 40, 1200, 640, { turn: my_e * 2 * pi, reveal: my_t });
```

### A single seal, anywhere

```gml
lpw_seal_draw("mayor-lies", lpw_fact_loop(my_loop, "mayor-lies"), 200, 200, 48);
```

For seals that are guaranteed distinct within a ledger, use `lpw_seal_specs(my_loop)` (one recipe per fact,
in learning order) and `lpw_seal_draw_spec(spec, x, y, radius)`.

### Saving

```gml
my_saved = lpw_save(my_loop);     // a string for your save file
my_loop = lpw_load(my_saved);     // a damaged string loads as a fresh record, never a crash
```

## The API

| Function | What it does |
| --- | --- |
| `lpw_create()` | A fresh loop record: loop 1, nothing known. |
| `lpw_is_state(value)` | True for a loop record. |
| `lpw_loop(state)` | The current loop number (1 on the first day). |
| `lpw_learn(state, id, [label])` | Learn a fact; returns true if it was new. |
| `lpw_knows(state, id)` | Is the fact known, in any loop? |
| `lpw_fact_loop(state, id)` | The loop a fact was first learned in, or 0. |
| `lpw_learned_this_loop(state, id)` | Was it learned in the current loop? |
| `lpw_forget(state, id)` | Remove a fact. |
| `lpw_facts(state)` | Every fact record `{id, label, loop, seq}`, in learning order. |
| `lpw_diverge(state, key, [label])` | Record a choice made differently this loop; true if new this loop. |
| `lpw_diverged(state, key)` | Has the player ever made this choice? |
| `lpw_divergences(state, loop)` | One loop's divergence records. |
| `lpw_anchor(state, pairs)` | Snapshot the world at dawn: an array of `[name, value]`. Returns how many were kept. |
| `lpw_plan_rewind(state, world, [carried])` | `{restore: [[name, value]], skipped: [name]}` - what a rewind should write. |
| `lpw_close_loop(state, [cause], [max_history])` | End the loop and start the next; returns the closed loop's record. |
| `lpw_history(state)` | The closed loops' records `{index, cause, facts, pins}`, oldest first. |
| `lpw_save(state)` | The record as a string. |
| `lpw_load(string)` | A record from a string, migrated. |
| `lpw_constellation(state, [passes])` | The knowledge constellation: `[{id, label, loop, x, y}]` in a 0..1 box. |
| `lpw_constellation_links(nodes)` | Pairs of stars learned in the same loop. |
| `lpw_hash(string)` | The 32-bit FNV-1a hash every layout is derived from. |
| `lpw_ledger_draw(state, x, y, w, h, [opts])` | Draw the Loop Ledger into a rectangle. `opts`: `{turn, reveal, ink, dim}`. |
| `lpw_ledger_layout(state, x, y, w, h)` | Where the Ledger puts everything, without drawing. |
| `lpw_astrolabe_draw(state, x, y, radius, [turn], [reveal])` | Draw the astrolabe alone. |
| `lpw_astrolabe_layout(state, x, y, radius, [turn], [reveal])` | Its rings, pins, stars and wires, without drawing. |
| `lpw_pin_angle(key)` | The angle a divergence is always struck at. |
| `lpw_seal_draw(id, loop, x, y, radius)` | Strike one fact's seal. |
| `lpw_seal_spec(id, loop)` | A seal's recipe: outline, border, device, wax. |
| `lpw_seal_specs(state)` | Every fact's recipe, no two alike within the ledger. |
| `lpw_seal_draw_spec(spec, x, y, radius)` | Strike a seal from a recipe. |
| `lpw_seal_outlines()` | The eight outline names. |
| `lpw_seal_borders()` | The six border band names. |
| `lpw_seal_devices()` | The eight device names. |
| `lpw_seal_waxes()` | The eight loop waxes `{name, base}`, cycling from loop 1. |

Every function checks what it is handed. A wrong type, `undefined`, or an out-of-range number returns a
refusal value (`undefined`, `false`, `0`, `""` or an empty array) instead of throwing inside your game.

## Sizes

The astrolabe occupies `x - radius` to `x + 1.05 radius` across and `y - radius` to `y + 1.07 radius` down,
its cast shadow included. `lpw_ledger_draw` keeps everything inside the rectangle it is given; with more
facts than fit at a captioned size, the seals get smaller and the captions are dropped.

## Performance

The Ledger draws every piece every call: a ledger of a dozen facts is a few thousand primitives. For a pause
screen that does not change, draw it once into a surface and draw the surface; redraw only when the record
changes or while a loop-closing animation runs. Everything in `lpw_core` is plain data and costs nothing to
keep in memory.

## Namespacing

Every script, function and macro is prefixed `lpw_` or `LPW_`; the resources are `obj_lpw_demo`,
`rm_lpw_demo` and the four `fnt_loopwork` fonts. Nothing collides with your project.

## Fonts

Three fonts are rasterised from IM Fell DW Pica (SIL Open Font License 1.1) and one is Open Sans (Apache
License 2.0). They set the astrolabe's numerals, the loop number and every caption, so keep them. Their
licences and notices are in `Loopwork/fonts/`, with `THIRD-PARTY-NOTICES.txt`. The fonts cover printable
ASCII: a fact label with other characters draws those characters as nothing.

## Licence and disclosure

One commercial licence per developer, unlimited games. Everything the package draws in your game is yours
to ship. See `LICENSE.txt`.

This package's code and its store images were produced with AI assistance.

Copyright (c) 2026 Core Systems Asset Factory.

*The RPG Maker MZ edition, Loop Core: <https://csaf.itch.io/loop-core>. More GameMaker systems from Core
Systems Asset Factory: <https://csaf.itch.io>*
