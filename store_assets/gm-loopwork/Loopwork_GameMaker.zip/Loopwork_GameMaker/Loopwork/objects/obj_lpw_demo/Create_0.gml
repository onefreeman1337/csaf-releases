/// @description Loopwork demo - a small time loop you can play with - and the headless entry points (-selftest, -bake, -gif).
/// ⛔ The crash handler is installed FIRST, and every variable a later event reads is declared ABOVE the early exits:
/// Clean Up always runs, even when Create leaves early.
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("lpw_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.lpw_stage) + ": " + string(_ex.message) + " | " + string(_ex.stacktrace));
    file_text_close(_f);
    game_end();
});
global.lpw_stage = 0;
loop = undefined;
world = { bell_rung: false, gate_open: false };
anim_t = 1;
message = "";
next_fact = 0;
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";
if (string_pos("-selftest", _args) > 0) { global.lpw_stage = 1; lpw_selftest_write(lpw_selftest_run()); game_end(); exit; }
if (string_pos("-bake", _args) > 0) { global.lpw_stage = 2; lpw_bake_run(); game_end(); exit; }
if (string_pos("-gif", _args) > 0) { global.lpw_stage = 3; lpw_bake_gif(); game_end(); exit; }

// the facts this little story can teach, in the order [L] reveals them
facts_to_learn = [
    ["ninth-hour", "The clock stops at the ninth hour"], ["salt-pact", "The salt pact was signed in blood"],
    ["north-bridge", "The north bridge falls at dusk"], ["sister-alive", "The ferryman's sister is alive"],
    ["old-map", "The old map shows a second well"], ["red-thread", "A red thread marks the traitor's door"],
    ["tide-table", "The tide table is wrong by an hour"], ["copper-key", "The copper key opens the vault"],
    ["masked-guest", "The masked guest is the mayor"], ["last-train", "The last train never leaves"],
    ["second-moon", "A second moon rises on the last night"], ["loop-zero", "Someone else remembers too"]];

// a playthrough already three loops deep, so the Ledger has something to show on the first frame; the world is
// anchored at dawn (bell_rung, gate_open are the names a rewind puts back)
loop = lpw_demo_seed();
message = "Loop " + string(lpw_loop(loop)) + ". Press L, D, B or G, then R to rewind.";
