/// @description Nothing to free: the loop record is a plain struct and the Ledger draws straight to the GUI layer.
loop = undefined;
