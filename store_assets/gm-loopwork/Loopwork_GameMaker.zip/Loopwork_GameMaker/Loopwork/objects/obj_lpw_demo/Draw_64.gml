/// @description The Loop Ledger, live, with the world state and the keys beneath it (drawn by lpw_demo_draw, the
/// same function the store bake uses to photograph this screen).
if (!lpw_is_state(loop)) exit;
lpw_demo_draw(loop, world, message, anim_t, display_get_gui_width(), display_get_gui_height());
