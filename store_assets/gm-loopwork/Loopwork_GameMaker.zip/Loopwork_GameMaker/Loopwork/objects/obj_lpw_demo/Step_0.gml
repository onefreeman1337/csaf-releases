/// @description Keys: [L] learn a fact  [D] make a different choice  [B] ring the bell  [G] open the gate  [R] end the loop.
/// The rewind is the engine's PLAN applied to this object's `world` struct - exactly what a buyer does with their own
/// globals or save data - and the Ledger animates the loop closing: the rete turns once while the new ring is cut.
if (!lpw_is_state(loop)) exit;
if (anim_t < 1) { anim_t = min(1, anim_t + 1 / 75); exit; }
if (keyboard_check_pressed(ord("L"))) {
    if (next_fact < array_length(facts_to_learn)) {
        var _fct = facts_to_learn[next_fact];
        if (lpw_learn(loop, _fct[0], _fct[1])) message = "Learned: " + _fct[1] + ".";
        next_fact++;
    } else message = "Nothing left to learn in this little story.";
}
if (keyboard_check_pressed(ord("D"))) {
    var _choices = ["took-the-boat", "rang-the-bell", "hid-in-cellar", "burned-letter", "followed-mayor", "stayed-home"];
    var _pick = _choices[(lpw_loop(loop) + array_length(lpw_divergences(loop, lpw_loop(loop)))) mod array_length(_choices)];
    message = lpw_diverge(loop, _pick) ? "A different choice this loop: " + _pick + "." : "Already done differently this loop.";
}
if (keyboard_check_pressed(ord("B"))) { world.bell_rung = true; message = "The bell rings."; }
if (keyboard_check_pressed(ord("G"))) { world.gate_open = true; message = "The gate stands open."; }
if (keyboard_check_pressed(ord("R"))) {
    var _plan = lpw_plan_rewind(loop, ["bell_rung", "gate_open"]);
    for (var _i = 0; _i < array_length(_plan.restore); _i++) variable_struct_set(world, _plan.restore[_i][0], _plan.restore[_i][1]);
    lpw_close_loop(loop, "rewound");
    lpw_anchor(loop, [["bell_rung", world.bell_rung], ["gate_open", world.gate_open]]);
    message = "Loop " + string(lpw_loop(loop)) + ". The bell and the gate are as they were. " + string(array_length(lpw_facts(loop))) + " facts are still known.";
    anim_t = 0;
}
