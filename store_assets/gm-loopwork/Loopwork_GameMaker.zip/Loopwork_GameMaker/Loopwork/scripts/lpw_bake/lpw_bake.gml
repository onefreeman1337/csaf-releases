/// lpw_bake.gml - renders the store sheets and the GIF frames THROUGH THE PRODUCT'S OWN DRAW CODE
/// (`Loopwork.exe -bake`, `Loopwork.exe -gif`), so the listing can truthfully say every image on the page was drawn by
/// the thing being sold. Not needed at runtime: a buyer may delete this script along with the -bake/-gif branches of
/// the demo object's Create event.
///
/// Loopwork - A Time Loop That Remembers, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ NOTHING IN THIS FILE CAN SEE A PICTURE. The ink box below catches a sheet that is CLIPPED or EMPTY and nothing
/// else. The sheets are opened and looked at, every time, and that is the actual gate.

/// @function lpw_bake_ground()
function lpw_bake_ground() { return make_colour_rgb(24, 20, 17); }

/// @function lpw_bake_opaque(w, h)
/// @description Force every pixel's alpha to 1 before saving, so a sheet has no transparent holes.
function lpw_bake_opaque(_w, _h) {
    gpu_set_colorwriteenable(false, false, false, true);
    lpw_rect_fill(0, 0, _w, _h, c_white, 1);
    gpu_set_colorwriteenable(true, true, true, true);
}

/// @function lpw_bake_ink(surface, w, h, ground)
/// @description The ink bounding box and sample count of a finished sheet: every row, every second column.
function lpw_bake_ink(_sf, _w, _h, _ground) {
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    var _x0 = _w, _y0 = _h, _x1 = -1, _y1 = -1, _n = 0;
    var _gr = colour_get_red(_ground), _gg = colour_get_green(_ground), _gb = colour_get_blue(_ground);
    for (var _y = 0; _y < _h; _y++) for (var _x = 0; _x < _w; _x += 2) {
        var _o = (_y * _w + _x) * 4;
        if (abs(buffer_peek(_b, _o, buffer_u8) - _gr) > 10 || abs(buffer_peek(_b, _o + 1, buffer_u8) - _gg) > 10 || abs(buffer_peek(_b, _o + 2, buffer_u8) - _gb) > 10) {
            _n++;
            if (_x < _x0) _x0 = _x;
            if (_x > _x1) _x1 = _x;
            if (_y < _y0) _y0 = _y;
            if (_y > _y1) _y1 = _y;
        }
    }
    buffer_delete(_b);
    return { x0: _x0, y0: _y0, x1: _x1, y1: _y1, px: _n };
}

/// @function lpw_bake_sheet(name, w, h, fn)
/// @description Render a sheet at 2x, filter it down, measure its ink, save it, log it.
function lpw_bake_sheet(_name, _w, _h, _fn) {
    var _big = surface_create(_w * 2, _h * 2);
    surface_set_target(_big); draw_clear(lpw_bake_ground()); _fn(_w * 2, _h * 2); lpw_bake_opaque(_w * 2, _h * 2); surface_reset_target();
    var _sf = surface_create(_w, _h);
    surface_set_target(_sf); draw_clear(lpw_bake_ground());
    var _prev = gpu_get_texfilter(); gpu_set_texfilter(true); draw_surface_ext(_big, 0, 0, 0.5, 0.5, 0, c_white, 1); gpu_set_texfilter(_prev);
    lpw_bake_opaque(_w, _h); surface_reset_target();
    surface_free(_big);
    var _ink = lpw_bake_ink(_sf, _w, _h, lpw_bake_ground());
    surface_save(_sf, "lpw_sheet_" + _name + ".png");
    surface_free(_sf);
    array_push(global.lpw_bake_log, { sheet: _name, w: _w, h: _h, px: _ink.px, x0: _ink.x0, y0: _ink.y0, x1: _ink.x1, y1: _ink.y1 });
}

/// @function lpw_bake_seal_ids()
/// @description Forty-eight fact ids a time-loop game might teach, for the corpus sheet. Pure.
function lpw_bake_seal_ids() {
    static _a = ["mayor-lies", "flood-gate", "bell-code", "river-key", "ferryman-debt", "clock-stops", "cellar-door", "widow-secret",
                 "lamp-oil", "north-bridge", "the-vault", "night-market", "sister-alive", "well-echo", "salt-pact", "burned-letter",
                 "tower-stair", "crow-sign", "orchard-grave", "harbor-chain", "old-map", "ninth-hour", "red-thread", "glass-eye",
                 "moth-choir", "winter-oath", "lost-ring", "abbey-bells", "stone-count", "silver-debt", "hollow-tree", "tide-table",
                 "masked-guest", "last-train", "empty-cradle", "copper-key", "mill-wheel", "sealed-room", "blind-judge", "ash-garden",
                 "second-moon", "the-tunnel", "drowned-choir", "iron-ledger", "chapel-fire", "false-heir", "quiet-road", "loop-zero"];
    return _a;
}

/// @function lpw_bake_label(id)
/// @description A fact id as a caption: "mayor-lies" -> "MAYOR LIES". Pure.
function lpw_bake_label(_id) { return string_upper(string_replace_all(_id, "-", " ")); }

/// @function lpw_bake_playthrough(loops)
/// @description A deterministic playthrough of `loops` loops: one to four facts learned and nought to four choices
/// made differently in each, the live loop last. Every sheet and the GIF draw from this, so they agree. Pure.
function lpw_bake_playthrough(_loops) {
    var _ids = lpw_bake_seal_ids(), _st = lpw_create(), _f = 0, _j;
    for (var _i = 0; _i < _loops; _i++) {
        var _nf = 1 + ((_i * 7 + 3) mod 4);
        for (_j = 0; _j < _nf && _f < 48; _j++) { lpw_learn(_st, _ids[_f], lpw_bake_label(_ids[_f])); _f++; }
        var _nd = (_i * 3 + 1) mod 5;
        for (_j = 0; _j < _nd; _j++) lpw_diverge(_st, "choice-" + string((_i * 11 + _j * 5) mod 23));
        if (_i < _loops - 1) lpw_close_loop(_st, "rewound");
    }
    return _st;
}

/// @function lpw_bake_head(w, title, sub, k)
function lpw_bake_head(_w, _title, _sub, _k) {
    lpw_text(_w * 0.5, 22 * _k, _title, 44 * _k, make_colour_rgb(238, 224, 194), fa_center, fa_top, fnt_loopwork_title, 1, _w * 0.9);
    lpw_text(_w * 0.5, 74 * _k, _sub, 20 * _k, make_colour_rgb(190, 172, 142), fa_center, fa_top, fnt_loopwork, 1, _w * 0.9);
}

/// @function lpw_bake_hero(w, h)
/// @description THE LEDGER of a nine-loop playthrough, exactly as lpw_ledger_draw lays it out for a buyer's screen.
function lpw_bake_hero(_w, _h) {
    var _k = 2;
    lpw_bake_head(_w, "THE LOOP LEDGER", "One ring per loop, a pin for every choice made differently, a star and a seal for every fact the player keeps.", _k);
    lpw_ledger_draw(lpw_bake_playthrough(9), 30 * _k, 118 * _k, _w - 60 * _k, _h - 136 * _k, { turn: 0.35 });
}

/// @function lpw_bake_seals(w, h)
/// @description FORTY-EIGHT SEALS, one per fact, in six loops' waxes: the volume claim, shown.
function lpw_bake_seals(_w, _h) {
    var _k = 2, _ids = lpw_bake_seal_ids();
    lpw_bake_head(_w, "EVERY FACT, STRUCK AS ITS OWN SEAL", "Outline, border band and device are composed from the fact's id; the wax is the loop it was learned in.", _k);
    var _cols = 8, _rows = 6, _top = 124 * _k, _pad = 24 * _k;
    var _cw = (_w - _pad * 2) / _cols, _ch = (_h - _top - _pad) / _rows;
    var _r = min(_cw, _ch - 22 * _k) * 0.47;
    var _led = lpw_create();
    for (var _j = 0; _j < 48; _j++) { lpw_learn(_led, _ids[_j]); if (_j mod 8 == 7) lpw_close_loop(_led, "rewound"); }
    var _specs = lpw_seal_specs(_led);
    for (var _i = 0; _i < 48; _i++) {
        var _c = _i mod _cols, _rw = _i div _cols;
        var _x = _pad + (_c + 0.5) * _cw, _y = _top + _rw * _ch + _r + 2 * _k;
        lpw_seal_draw_spec(_specs[_i], _x, _y, _r);
        lpw_text(_x, _y + _r * 1.18, lpw_bake_label(_ids[_i]), 11 * _k, make_colour_rgb(196, 180, 150), fa_center, fa_top, fnt_loopwork, 1, _cw * 0.94);
    }
}

/// @function lpw_bake_jewel(x, y, r, wax)
/// @description One rete jewel, drawn exactly as the astrolabe sets it (for the legend).
function lpw_bake_jewel(_x, _y, _jr, _wax) {
    lpw_disc(_x + _jr * 0.3, _y + _jr * 0.4, _jr * 1.05, c_black, 0.35);
    lpw_disc(_x, _y, _jr, merge_colour(_wax, c_black, 0.15));
    lpw_disc(_x - _jr * 0.12, _y - _jr * 0.15, _jr * 0.72, _wax);
    lpw_arc(_x, _y, _jr, 0, 2 * pi, max(1, _jr * 0.22), lpw_brass(0.35));
    lpw_spot(_x - _jr * 0.3, _y - _jr * 0.35, _jr * 0.6, c_white, 0.75);
}

/// @function lpw_bake_rete(w, h)
/// @description THE INSTRUMENT, CLOSE: one quadrant of a fourteen-loop astrolabe drawn at seven times its game size
/// and cropped - a real redraw, never a scaled bitmap - beside a legend of its three marks.
function lpw_bake_rete(_w, _h) {
    var _k = 2;
    lpw_bake_head(_w, "THE RETE IS WHAT THEY KNOW", "The plate beneath records what the player did; the pierced star map above it turns with every loop.", _k);
    var _top = 124 * _k, _vx = 36 * _k, _vw = _w * 0.60, _vh = _h - _top - 36 * _k;
    var _R = _vh * 1.35;
    gpu_set_scissor(_vx, _top, _vw, _vh);
    lpw_astrolabe_draw(lpw_bake_playthrough(14), _vx + _vw * 0.98, _top + _vh * 1.0, _R, 0.35);
    gpu_set_scissor(0, 0, _w, _h);
    lpw_rect_line(_vx, _top, _vw, _vh, 2 * _k, make_colour_rgb(120, 96, 64));
    // the legend: each mark drawn by the same code that draws it on the instrument
    var _lx = _vx + _vw + 44 * _k, _lw = _w - _lx - 36 * _k, _row = _vh / 3, _i, _W = lpw_seal_waxes();
    var _heads = ["A STAR FOR EVERY FACT", "A PIN FOR EVERY CHOICE", "A RING FOR EVERY LOOP"];
    var _lines = ["Set in the wax of the loop it was learned in. Facts from one loop are wired together, in order.",
                  "Struck in blued steel into that loop's ring, at an angle drawn from the choice itself.",
                  "Oldest innermost. The live loop is inlaid in blued steel, and the boss carries its number."];
    // ⚠️ the first bake drew these marks at game size and left most of the column dark; each is now shown at the size
    // the close-up shows it, with its words beside it
    for (_i = 0; _i < 3; _i++) {
        var _cy = _top + _row * (_i + 0.5), _ix = _lx + 52 * _k;
        switch (_i) {
            case 0: lpw_seg(_ix - 22 * _k, _cy - 12 * _k, _ix + 22 * _k, _cy + 16 * _k, 4 * _k, lpw_brass(0.7)); lpw_bake_jewel(_ix - 22 * _k, _cy - 12 * _k, 20 * _k, _W[0].base); lpw_bake_jewel(_ix + 22 * _k, _cy + 16 * _k, 20 * _k, _W[2].base); break;
            case 1: lpw_disc(_ix, _cy, 48 * _k, lpw_brass(0.45)); lpw_engrave_arc(_ix, _cy + 96 * _k, 96 * _k, -pi * 0.64, -pi * 0.36, 5 * _k); lpw_pin_draw(_ix, _cy, -pi / 2, 26 * _k); break;
            default: lpw_disc(_ix, _cy, 48 * _k, lpw_brass(0.45)); lpw_arc(_ix, _cy, 32 * _k, 0, 2 * pi, 11 * _k, lpw_brass(0.12)); lpw_arc(_ix, _cy, 32 * _k, 0, 2 * pi, 6.5 * _k, lpw_blued(0.5)); lpw_arc(_ix - 1.5 * _k, _cy - 1.8 * _k, 32 * _k, 0, 2 * pi, 2.2 * _k, lpw_blued(0.95), 0.8); break;
        }
        lpw_text(_lx + 124 * _k, _cy - 44 * _k, _heads[_i], 27 * _k, make_colour_rgb(238, 224, 194), fa_left, fa_top, fnt_loopwork_title, 1, _lw - 124 * _k);
        lpw_bake_wrap(_lx + 124 * _k, _cy - 6 * _k, _lines[_i], 19 * _k, make_colour_rgb(190, 172, 142), _lw - 124 * _k);
    }
}

/// @function lpw_bake_wrap(x, y, text, px, colour, maxw)
/// @description Word-wrap a line of body copy into `maxw`, returning the y it finished at.
function lpw_bake_wrap(_x, _y, _s, _px, _col, _maxw) {
    var _words = string_split(_s, " "), _line = "", _i;
    for (_i = 0; _i < array_length(_words); _i++) {
        var _try = (_line == "") ? _words[_i] : _line + " " + _words[_i];
        if (lpw_text_w(_try, _px) > _maxw && _line != "") { lpw_text(_x, _y, _line, _px, _col); _y += _px * 1.3; _line = _words[_i]; }
        else _line = _try;
    }
    if (_line != "") { lpw_text(_x, _y, _line, _px, _col); _y += _px * 1.3; }
    return _y;
}

/// @function lpw_bake_growth(w, h)
/// @description ONE PLAYTHROUGH, FOUR MOMENTS: the same record's instrument at loops 1, 3, 7 and 14. Every caption
/// is COUNTED from the record, never typed.
function lpw_bake_growth(_w, _h) {
    var _k = 2, _at = [1, 3, 7, 14];
    lpw_bake_head(_w, "IT GROWS WITH THE PLAYER", "One playthrough at four moments. Every ring, pin and star is drawn from the loop record, nothing else.", _k);
    // ⚠️ the sheet is 620 tall, not 900: four instruments in a row are wider than tall, and at 900 the first bake left
    // the bottom 40% of the page bare (ink stopped at y 541)
    var _top = 124 * _k, _cw = (_w - 40 * _k) / 4, _r = min(_cw * 0.44, (_h - _top - 96 * _k) / 2.12);
    for (var _i = 0; _i < 4; _i++) {
        var _s = lpw_bake_playthrough(_at[_i]);
        var _cx = 20 * _k + _cw * (_i + 0.5), _cy = _top + 10 * _k + _r;
        lpw_astrolabe_draw(_s, _cx, _cy, _r, 0.35 * _i);
        var _nd = 0, _nf = array_length(lpw_facts(_s));
        for (var _q = 1; _q <= lpw_loop(_s); _q++) _nd += array_length(lpw_divergences(_s, _q));
        lpw_text(_cx, _cy + _r * 1.14, "LOOP " + string(lpw_loop(_s)), 26 * _k, make_colour_rgb(238, 224, 194), fa_center, fa_top, fnt_loopwork_title, 1, _cw * 0.9);
        lpw_text(_cx, _cy + _r * 1.14 + 32 * _k, string(_nf) + ((_nf == 1) ? " FACT KEPT, " : " FACTS KEPT, ") + string(_nd) + ((_nd == 1) ? " CHOICE STRUCK" : " CHOICES STRUCK"),
                 14 * _k, make_colour_rgb(190, 172, 142), fa_center, fa_top, fnt_loopwork, 1, _cw * 0.9);
    }
}

/// @function lpw_bake_anatomy(w, h)
/// @description THE FOUR CHOICES A SEAL IS MADE OF: each row varies one axis and holds the other three.
function lpw_bake_anatomy(_w, _h) {
    var _k = 2;
    lpw_bake_head(_w, "384 SEALS FROM FOUR CHOICES", "Every seal is an outline, a border band, a device and a wax. Each row below changes one of them.", _k);
    var _O = lpw_seal_outlines(), _B = lpw_seal_borders(), _D = lpw_seal_devices(), _W = lpw_seal_waxes();
    var _rows = [["OUTLINE", _O], ["BORDER", _B], ["DEVICE", _D], ["WAX", _W]];
    var _top = 124 * _k, _lab = 190 * _k, _rh = (_h - _top - 20 * _k) / 4;
    for (var _r = 0; _r < 4; _r++) {
        var _list = _rows[_r][1], _n = array_length(_list), _cw = (_w - _lab - 30 * _k) / 8;
        var _cy = _top + _rh * _r + _rh * 0.44, _sr = min(_cw * 0.40, _rh * 0.34);
        lpw_text(40 * _k, _cy - 12 * _k, _rows[_r][0], 24 * _k, make_colour_rgb(238, 224, 194), fa_left, fa_top, fnt_loopwork_title);
        lpw_text(40 * _k, _cy + 18 * _k, string(_n) + " KINDS", 13 * _k, make_colour_rgb(160, 142, 112), fa_left, fa_top, fnt_loopwork);
        for (var _i = 0; _i < _n; _i++) {
            var _sp = lpw_seal_spec("mayor-lies", 1), _name = "";
            _sp.outline = "round"; _sp.border = "double"; _sp.device = "hourglass";
            switch (_r) {
                case 0: _sp.outline = _list[_i]; _name = _list[_i]; break;
                case 1: _sp.border = _list[_i]; _name = _list[_i]; break;
                case 2: _sp.device = _list[_i]; _name = _list[_i]; break;
                default: _sp.base = _list[_i].base; _sp.wax = _list[_i].name; _name = _list[_i].name; break;
            }
            var _cx = _lab + _cw * (_i + 0.5);
            lpw_seal_draw_spec(_sp, _cx, _cy, _sr);
            lpw_text(_cx, _cy + _sr * 1.16, string_upper(_name), 12 * _k, make_colour_rgb(196, 180, 150), fa_center, fa_top, fnt_loopwork, 1, _cw * 0.92);
        }
    }
}

/// @function lpw_bake_card(x, y, w, h, title, k)
/// @description A dark leather card with a brass edge and a title - the panels of the rewind diagram.
function lpw_bake_card(_x, _y, _w, _h, _title, _k) {
    lpw_rect_fill(_x + 5 * _k, _y + 7 * _k, _w, _h, c_black, 0.35);
    lpw_rect_fill(_x, _y, _w, _h, make_colour_rgb(46, 36, 28));
    lpw_edge_shade(_x, _y, _w, _h, 18 * _k, c_black, 0.35);
    lpw_rect_line(_x, _y, _w, _h, 2 * _k, lpw_brass(0.6));
    lpw_rect_line(_x + 6 * _k, _y + 6 * _k, _w - 12 * _k, _h - 12 * _k, 1 * _k, lpw_brass(0.35));
    lpw_text(_x + _w * 0.5, _y + 18 * _k, _title, 19 * _k, lpw_brass(0.85), fa_center, fa_top, fnt_loopwork_title, 1, _w * 0.9);
}

/// @function lpw_bake_rewind(w, h)
/// @description THE REWIND IS A PLAN: an anchor, the world at the loop's end, and the plan lpw_plan_rewind returns -
/// every line of the third card is printed from a real call, not typed.
function lpw_bake_rewind(_w, _h) {
    var _k = 2, _i;
    lpw_bake_head(_w, "THE REWIND IS A PLAN", "Loopwork snapshots the world at dawn and tells you what to put back. It never writes to your game.", _k);
    var _st = lpw_create();
    var _dawn = [["door_open", false], ["bell_rung", 0], ["gold", 12], ["lamp_lit", false], ["ferry_moored", true], ["mayor_mood", "calm"]];
    var _dusk = [["door_open", true], ["bell_rung", 3], ["gold", 40], ["lamp_lit", true], ["ferry_moored", false], ["mayor_mood", "furious"]];
    lpw_anchor(_st, _dawn);
    var _world = ["door_open", "bell_rung", "gold", "lamp_lit", "ferry_moored", "mayor_mood"], _carried = ["gold", "lamp_lit"];
    var _plan = lpw_plan_rewind(_st, _world, _carried);
    // ⚠️ the cards are as tall as what they hold: at half the page the first bake left each one half empty
    var _top = 130 * _k, _gap = 64 * _k, _cw = (_w - 80 * _k - _gap * 2) / 3, _chh = 64 * _k + 6 * 34 * _k + 58 * _k;
    var _cols = [make_colour_rgb(226, 210, 178), make_colour_rgb(156, 138, 108)];
    var _titles = ["THE WORLD AT DAWN", "THE WORLD AT DUSK", "THE PLAN"];
    for (var _c = 0; _c < 3; _c++) {
        var _cx = 40 * _k + (_cw + _gap) * _c;
        lpw_bake_card(_cx, _top, _cw, _chh, _titles[_c], _k);
        var _y = _top + 64 * _k;
        if (_c < 2) {
            var _src = (_c == 0) ? _dawn : _dusk;
            for (_i = 0; _i < array_length(_src); _i++) {
                var _isc = (_src[_i][0] == "gold" || _src[_i][0] == "lamp_lit");
                lpw_text(_cx + 26 * _k, _y, _src[_i][0], 17 * _k, _cols[0], fa_left, fa_top, fnt_loopwork_ui);
                lpw_text(_cx + _cw - 26 * _k, _y, lpw_bake_value(_src[_i][1]), 17 * _k, _isc && _c == 1 ? lpw_blued(0.8) : lpw_brass(0.8), fa_right, fa_top, fnt_loopwork_ui);
                _y += 34 * _k;
            }
            if (_c == 1) lpw_text(_cx + _cw * 0.5, _top + _chh - 40 * _k, "carried across loops: gold, lamp_lit", 14 * _k, lpw_blued(0.8), fa_center, fa_top, fnt_loopwork, 1, _cw * 0.9);
        } else {
            lpw_text(_cx + 26 * _k, _y, "RESTORE", 14 * _k, _cols[1], fa_left, fa_top, fnt_loopwork_title); _y += 26 * _k;
            for (_i = 0; _i < array_length(_plan.restore); _i++) {
                lpw_text(_cx + 26 * _k, _y, _plan.restore[_i][0], 17 * _k, _cols[0], fa_left, fa_top, fnt_loopwork_ui);
                lpw_text(_cx + _cw - 26 * _k, _y, lpw_bake_value(_plan.restore[_i][1]), 17 * _k, lpw_brass(0.8), fa_right, fa_top, fnt_loopwork_ui);
                _y += 30 * _k;
            }
            _y += 8 * _k;
            lpw_text(_cx + 26 * _k, _y, "LEAVE ALONE", 14 * _k, _cols[1], fa_left, fa_top, fnt_loopwork_title); _y += 26 * _k;
            for (_i = 0; _i < array_length(_plan.skipped); _i++) { lpw_text(_cx + 26 * _k, _y, _plan.skipped[_i], 17 * _k, lpw_blued(0.8), fa_left, fa_top, fnt_loopwork_ui); _y += 30 * _k; }
        }
        if (_c < 2) {   // an arrow to the next card
            var _axx = _cx + _cw + _gap * 0.5, _ayy = _top + _chh * 0.5;
            lpw_seg(_axx - _gap * 0.32, _ayy, _axx + _gap * 0.18, _ayy, 4 * _k, lpw_brass(0.7));
            lpw_fill_convex([_axx + _gap * 0.34, _ayy, _axx + _gap * 0.12, _ayy - 11 * _k, _axx + _gap * 0.12, _ayy + 11 * _k], lpw_brass(0.7));
        }
    }
    // the call, and what the plan never touches
    var _by = _top + _chh + 40 * _k, _cbh = _h - _by - 30 * _k;
    lpw_rect_fill(40 * _k, _by, _w * 0.56, _cbh, make_colour_rgb(16, 13, 11));
    lpw_rect_line(40 * _k, _by, _w * 0.56, _cbh, 1 * _k, lpw_brass(0.35));
    var _code = ["lpw_anchor(loop, dawn_pairs);                    // at dawn",
                 "var plan = lpw_plan_rewind(loop, world, carried); // at the rewind",
                 "for (var i = 0; i < array_length(plan.restore); i++)",
                 "    variable_global_set(plan.restore[i][0], plan.restore[i][1]);",
                 "lpw_close_loop(loop, \"drowned\");"];
    for (_i = 0; _i < array_length(_code); _i++) lpw_text(60 * _k, _by + 26 * _k + _i * 38 * _k, _code[_i], 17 * _k, (_i == 1) ? lpw_brass(0.85) : _cols[0], fa_left, fa_top, fnt_loopwork_ui, 1, _w * 0.53);
    var _sx = 40 * _k + _w * 0.56 + 40 * _k, _sw = _w - _sx - 40 * _k;
    lpw_text(_sx + _sw * 0.5, _by + 4 * _k, "AND WHAT THEY LEARNED IS NOT IN IT", 17 * _k, make_colour_rgb(238, 224, 194), fa_center, fa_top, fnt_loopwork_title, 1, _sw);
    var _led = lpw_bake_playthrough(3), _sp = lpw_seal_specs(_led), _nn = min(4, array_length(_sp)), _sr = min(_sw / 9.5, (_h - _by - 90 * _k) * 0.42);
    for (_i = 0; _i < _nn; _i++) lpw_seal_draw_spec(_sp[_i], _sx + _sw * (_i + 0.5) / _nn, _by + 50 * _k + _sr, _sr);
}

/// @function lpw_bake_value(v)
/// @description A world value as the cards print it. Pure.
function lpw_bake_value(_v) {
    if (is_bool(_v)) return _v ? "true" : "false";
    if (is_string(_v)) return "\"" + _v + "\"";
    return string(_v);
}

/// @function lpw_bake_cover(w, h)
/// @description A 630x500 fallback cover drawn by the product, in case the illustrated cover is ever unavailable.
function lpw_bake_cover(_w, _h) {
    var _k = 2;
    lpw_astrolabe_draw(lpw_bake_playthrough(9), _w * 0.5, _h * 0.44, _h * 0.40, 0.35);
    lpw_text(_w * 0.5, _h * 0.89, "LOOPWORK", 52 * _k, make_colour_rgb(238, 224, 194), fa_center, fa_middle, fnt_loopwork_title, 1, _w * 0.9);
}

/// @function lpw_bake_demo(w, h)
/// @description THE DEMO ROOM, photographed: the demo object's own screen (lpw_demo_draw) at 1280x720 after a fact
/// is learned and a choice struck - a verification image, looked at, not a store image.
function lpw_bake_demo(_w, _h) {
    var _s = lpw_demo_seed();
    lpw_learn(_s, "ninth-hour", "The clock stops at the ninth hour");
    lpw_diverge(_s, "stayed-home");
    // the demo draws in GUI pixels; the sheet surface is 2x, so the world matrix doubles it rather than halving its type
    matrix_set(matrix_world, matrix_build(0, 0, 0, 0, 0, 0, 2, 2, 1));
    lpw_demo_draw(_s, { bell_rung: true, gate_open: false }, "Learned: The clock stops at the ninth hour.", 1, _w / 2, _h / 2);
    matrix_set(matrix_world, matrix_build_identity());
}

/// @function lpw_bake_pad4(n)
/// @description A frame index as four digits, by ARITHMETIC (string_replace replaces one occurrence). Pure.
function lpw_bake_pad4(_n) {
    _n = clamp(floor(is_real(_n) ? _n : 0), 0, 9999);
    var _s = string(_n);
    while (string_length(_s) < 4) _s = "0" + _s;
    return _s;
}

/// @function lpw_bake_gif_frame(st, big, sf, n, turn, reveal, note)
/// @description One GIF frame: the instrument on the left, the newest fact's seal and the loop count on the right,
/// drawn at 2x and filtered down.
function lpw_bake_gif_frame(_st, _big, _sf, _n, _turn, _rev, _note) {
    var _k = 2, _W = 640, _H = 400;
    surface_set_target(_big); draw_clear(lpw_bake_ground());
    lpw_astrolabe_draw(_st, 200 * _k, 200 * _k, 178 * _k, _turn, _rev);
    var _f = lpw_facts(_st), _sp = lpw_seal_specs(_st), _rx = 505 * _k;
    lpw_text(_rx, 30 * _k, "LOOP " + string(lpw_loop(_st)), 44 * _k, make_colour_rgb(238, 224, 194), fa_center, fa_top, fnt_loopwork_title, 1, 250 * _k);
    lpw_text(_rx, 86 * _k, string(array_length(_f)) + " FACTS KEPT", 15 * _k, make_colour_rgb(170, 152, 122), fa_center, fa_top, fnt_loopwork, 1, 250 * _k);
    if (array_length(_f) > 0) {
        var _i = array_length(_f) - 1;
        lpw_seal_draw_spec(_sp[_i], _rx, 205 * _k, 62 * _k);
        lpw_text(_rx, 280 * _k, _f[_i].label, 15 * _k, make_colour_rgb(226, 210, 178), fa_center, fa_top, fnt_loopwork, 1, 250 * _k);
    }
    lpw_text(_rx, 340 * _k, _note, 13 * _k, lpw_blued(0.8), fa_center, fa_top, fnt_loopwork, 1, 250 * _k);
    lpw_bake_opaque(_W * _k, _H * _k);
    surface_reset_target();
    surface_set_target(_sf); draw_clear(lpw_bake_ground());
    var _prev = gpu_get_texfilter(); gpu_set_texfilter(true); draw_surface_ext(_big, 0, 0, 0.5, 0.5, 0, c_white, 1); gpu_set_texfilter(_prev);
    lpw_bake_opaque(_W, _H);
    surface_reset_target();
    surface_save(_sf, "lpw_gif_" + lpw_bake_pad4(_n) + ".png");
    return _n + 1;
}

/// @function lpw_bake_gif()
/// @description The GIF frames: two loops closing. In each, a fact is learned (a new star and seal), a choice is
/// struck (a new pin), and the loop closes - the rete turns one full revolution while the new loop's ring is cut.
function lpw_bake_gif() {
    var _big = surface_create(1280, 800), _sf = surface_create(640, 400), _n = 0, _c, _f, _j;
    var _st = lpw_bake_playthrough(4), _ids = lpw_bake_seal_ids(), _next = 0;
    for (_j = 0; _j < array_length(_ids); _j++) if (!lpw_knows(_st, _ids[_j])) { _next = _j; break; }
    for (_c = 0; _c < 2; _c++) {
        for (_f = 0; _f < 5; _f++) _n = lpw_bake_gif_frame(_st, _big, _sf, _n, 0, 1, "");
        lpw_learn(_st, _ids[_next], lpw_bake_label(_ids[_next])); _next++;
        for (_f = 0; _f < 6; _f++) _n = lpw_bake_gif_frame(_st, _big, _sf, _n, 0, 1, "LEARNED");
        lpw_diverge(_st, "gif-choice-" + string(_c));
        for (_f = 0; _f < 5; _f++) _n = lpw_bake_gif_frame(_st, _big, _sf, _n, 0, 1, "A DIFFERENT CHOICE");
        lpw_close_loop(_st, "rewound");
        for (_f = 0; _f < 18; _f++) {
            var _t = _f / 17, _e = 0.5 - 0.5 * cos(pi * _t);
            _n = lpw_bake_gif_frame(_st, _big, _sf, _n, _e * 2 * pi, _t, "THE WORLD RESETS. THEY DO NOT.");
        }
    }
    for (_f = 0; _f < 6; _f++) _n = lpw_bake_gif_frame(_st, _big, _sf, _n, 0, 1, "THE WORLD RESETS. THEY DO NOT.");
    surface_free(_big); surface_free(_sf);
    var _fh = file_text_open_write("lpw_gif.json");
    file_text_write_string(_fh, "{\"frames\":" + string(_n) + ",\"w\":640,\"h\":400,\"stage\":99,\"pass\":1,\"fail\":0}");
    file_text_close(_fh);
    return _n;
}

/// @function lpw_bake_run()
/// @description Render every store sheet and write lpw_bake.json with each sheet's ink box beside them.
function lpw_bake_run() {
    global.lpw_bake_log = [];
    lpw_bake_sheet("hero",    1600, 900,  lpw_bake_hero);
    lpw_bake_sheet("seals",   1600, 1000, lpw_bake_seals);
    lpw_bake_sheet("rete",    1600, 900,  lpw_bake_rete);
    lpw_bake_sheet("growth",  1600, 620,  lpw_bake_growth);
    lpw_bake_sheet("anatomy", 1600, 1000, lpw_bake_anatomy);
    lpw_bake_sheet("rewind",  1600, 760,  lpw_bake_rewind);
    lpw_bake_sheet("cover",   630,  500,  lpw_bake_cover);
    lpw_bake_sheet("demo",    1280, 720,  lpw_bake_demo);
    var _f = file_text_open_write("lpw_bake.json");
    file_text_write_string(_f, "{\"stage\":99,\"pass\":" + string(array_length(global.lpw_bake_log)) + ",\"fail\":0,\"sheets\":[");
    for (var _i = 0; _i < array_length(global.lpw_bake_log); _i++) {
        var _s = global.lpw_bake_log[_i];
        if (_i > 0) file_text_write_string(_f, ",");
        file_text_write_string(_f, "{\"sheet\":\"" + _s.sheet + "\",\"w\":" + string(_s.w) + ",\"h\":" + string(_s.h) + ",\"ink_px\":" + string(_s.px) +
            ",\"x0\":" + string(_s.x0) + ",\"y0\":" + string(_s.y0) + ",\"x1\":" + string(_s.x1) + ",\"y1\":" + string(_s.y1) +
            ",\"clipped\":" + ((_s.x1 >= _s.w - 2 || _s.y1 >= _s.h - 2) ? "true" : "false") + "}");
    }
    file_text_write_string(_f, "]}");
    file_text_close(_f);
}
