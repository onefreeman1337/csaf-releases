{
  "$GMScript": "v1",
  "%Name": "lpw_seal",
  "name": "lpw_seal",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}