/// lpw_seal.gml - every fact the player learns is struck as its own SEAL: a wax medallion whose outline, border band
/// and central device are composed from the fact's id, in the wax colour of the loop it was learned in.
///
/// Loopwork - A Time Loop That Remembers, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⭐ RELIEF, NOT FLAT FILL (Doctrine_Craft §1). The rim is a band of quads between the outline and an inset copy of
/// it, each shaded by how squarely its edge faces one fixed lamp at the upper left - that is what makes a seal read as
/// a pressed object rather than an icon. The device is DEBOSSED: a pale stroke offset down-right under a dark stroke,
/// the way an impression catches light on its lower lip.
/// ⛔ EVERY FILL IS A SCANLINE, never a triangle fan: a scalloped seal, a quatrefoil and a shield are all concave, and a
/// fan spans a concavity silently.
///
/// PUBLIC API:
///   lpw_seal_spec(id, loop)                -> {outline, border, device, wax, ...} (pure; the seal's recipe)
///   lpw_seal_draw(id, loop, x, y, radius)  -> draws the seal centred on (x, y); returns its spec, or undefined
///   lpw_seal_outlines() / lpw_seal_borders() / lpw_seal_devices() / lpw_seal_waxes()  -> the catalogues (pure)

/// @function lpw_seal_outlines()
function lpw_seal_outlines() { static _a = ["round", "scalloped", "octagon", "hexagon", "shield", "lozenge", "quatrefoil", "cogged"]; return _a; }
/// @function lpw_seal_borders()
function lpw_seal_borders() { static _a = ["double", "beaded", "rope", "dentil", "laurel", "notched"]; return _a; }
/// @function lpw_seal_devices()
function lpw_seal_devices() { static _a = ["hourglass", "key", "bell", "eye", "moon", "sun", "tower", "star"]; return _a; }
/// @function lpw_seal_waxes()
/// @description The wax of each loop, cycling: loop 1 crimson, 2 verdigris, 3 cobalt, 4 jet, 5 amber, 6 plum, 7 madder,
/// 8 slate. Pure.
function lpw_seal_waxes() {
    static _w = undefined;
    if (_w == undefined) _w = [
        { name: "crimson",   base: make_colour_rgb(150, 28, 34) },  { name: "verdigris", base: make_colour_rgb(46, 118, 98) },
        { name: "cobalt",    base: make_colour_rgb(38, 64, 150) },  { name: "jet",       base: make_colour_rgb(58, 52, 58) },
        { name: "amber",     base: make_colour_rgb(196, 124, 30) }, { name: "plum",      base: make_colour_rgb(104, 42, 96) },
        { name: "madder",    base: make_colour_rgb(184, 72, 64) },  { name: "slate",     base: make_colour_rgb(84, 98, 112) }];
    return _w;
}

/// @function lpw_seal_spec(id, loop)
/// @description The seal's recipe, composed from the id's hash (independent bit-fields choose each axis) and the loop's
/// wax. The same id is the same seal on every machine and in every save. Pure.
function lpw_seal_spec(_id, _loop) {
    var _h = int64(lpw_hash(lpw_id(_id)));
    var _h2 = int64(lpw_hash(lpw_id(_id) + "#seal"));
    var _O = lpw_seal_outlines(), _B = lpw_seal_borders(), _D = lpw_seal_devices(), _W = lpw_seal_waxes();
    var _lp = is_numeric(_loop) ? max(1, floor(_loop)) : 1;
    var _wx = _W[(_lp - 1) mod array_length(_W)];
    return {
        id: lpw_id(_id), loop: _lp,
        outline: _O[real(_h & 7)], border: _B[real((_h >> 3) mod 6)], device: _D[real((_h >> 7) & 7)],
        wax: _wx.name, base: _wx.base,
        lobes: 8 + real((_h2 & 3) * 2),                     // scalloped and cogged: 8, 10, 12 or 14
        rays: 8 + real((_h2 >> 2) & 7),                     // sun rays 8..15
        points: 5 + real((_h2 >> 5) & 3),                   // star points 5..8
        tilt: real((_h2 >> 8) & 15) / 16 * 0.5 - 0.25       // a seal is never struck perfectly square
    };
}

/// @function lpw_seal_specs(state)
/// @description The recipes of EVERY fact in a ledger, in learning order, with NO TWO ALIKE: a fact whose hashed recipe
/// (outline x border x device) is already taken steps to the next free combination, deterministically. Returns an
/// array parallel to the ledger's facts. Pure.
/// ⛔ WHY: hashing ids into 8 x 6 x 8 = 384 recipes COLLIDES by the birthday problem - the suite struck 48 facts and
/// MEASURED 46 distinct seals (night-market and stone-count were the same picture). Per-id hashing cannot avoid that;
/// assignment within the ledger can, and a player never sees two facts share a seal (up to 384 facts).
function lpw_seal_specs(_st) {
    var _out = [];
    if (!lpw_is_state(_st)) return _out;
    var _O = lpw_seal_outlines(), _B = lpw_seal_borders(), _D = lpw_seal_devices();
    var _nb = array_length(_B), _nd = array_length(_D), _total = array_length(_O) * _nb * _nd;
    // ⭐ THE SILHOUETTE CARRIES THE IDENTITY. The first assignment only kept full recipes unique, and the suite then
    // MEASURED two seals sharing outline, band and wax at 1 grid cell apart (a 1-pixel nudge moves 7): at thumbnail
    // size the small central device is not enough to tell two seals apart. So the 48 outline x band PAIRS are handed out
    // first - up to 48 facts all differ in shape AND band - and only then may a pair repeat, with a different device.
    var _npairs = array_length(_O) * _nb;
    var _used = {}, _pairs = {}, _npused = 0;
    for (var _i = 0; _i < array_length(_st.facts); _i++) {
        var _sp = lpw_seal_spec(_st.facts[_i].id, _st.facts[_i].loop);
        var _oi = 0, _bi = 0, _di = 0, _k;
        for (_k = 0; _k < array_length(_O); _k++) if (_O[_k] == _sp.outline) _oi = _k;
        for (_k = 0; _k < _nb; _k++) if (_B[_k] == _sp.border) _bi = _k;
        for (_k = 0; _k < _nd; _k++) if (_D[_k] == _sp.device) _di = _k;
        var _pi = _oi * _nb + _bi;
        if (_npused < _npairs) {
            for (var _u = 0; _u < _npairs && variable_struct_exists(_pairs, string(_pi)); _u++) _pi = (_pi + 1) mod _npairs;
            _pairs[$ string(_pi)] = 1; _npused++;
        }
        var _idx = _pi * _nd + _di;
        for (var _t = 0; _t < _total && variable_struct_exists(_used, string(_idx)); _t++) _idx = (_idx + 1) mod _total;
        _used[$ string(_idx)] = 1;
        _sp.outline = _O[_idx div (_nb * _nd)];
        _sp.border = _B[(_idx div _nd) mod _nb];
        _sp.device = _D[_idx mod _nd];
        array_push(_out, _sp);
    }
    return _out;
}

/// @function lpw_seal_outline(spec, cx, cy, r)
/// @description The seal's outline as a flat point array, STAR-SHAPED about its centre (so scaling toward the centre is
/// a safe inset for the rim). Pure.
function lpw_seal_outline(_sp, _cx, _cy, _r) {
    var _p = [], _i, _n, _a, _rr;
    switch (_sp.outline) {
        case "scalloped":
            _n = _sp.lobes * 8;
            for (_i = 0; _i < _n; _i++) { _a = _i / _n * 2 * pi; _rr = _r * (0.92 + 0.08 * abs(cos(_a * _sp.lobes / 2))); array_push(_p, _cx + cos(_a + _sp.tilt) * _rr, _cy + sin(_a + _sp.tilt) * _rr); }
            break;
        case "octagon": case "hexagon":
            _n = (_sp.outline == "octagon") ? 8 : 6;
            for (_i = 0; _i < _n; _i++) { _a = _i / _n * 2 * pi + pi / _n + _sp.tilt; array_push(_p, _cx + cos(_a) * _r, _cy + sin(_a) * _r); }
            break;
        case "shield":
            var _S = [-0.84, -0.86, 0.84, -0.86, 0.84, 0.02, 0.64, 0.50, 0.32, 0.80, 0, 0.98, -0.32, 0.80, -0.64, 0.50, -0.84, 0.02];
            for (_i = 0; _i < array_length(_S); _i += 2) array_push(_p, _cx + _S[_i] * _r, _cy + _S[_i + 1] * _r);
            break;
        case "lozenge":
            array_push(_p, _cx, _cy - _r, _cx + _r * 0.86, _cy, _cx, _cy + _r, _cx - _r * 0.86, _cy);
            break;
        case "quatrefoil":
            _n = 96;
            for (_i = 0; _i < _n; _i++) { _a = _i / _n * 2 * pi; _rr = _r * (0.80 + 0.20 * abs(cos(_a * 2))); array_push(_p, _cx + cos(_a + pi / 4 + _sp.tilt) * _rr, _cy + sin(_a + pi / 4 + _sp.tilt) * _rr); }
            break;
        case "cogged":
            _n = _sp.lobes * 4;
            for (_i = 0; _i < _n; _i++) { _a = _i / _n * 2 * pi + _sp.tilt; _rr = ((_i div 2) mod 2 == 0) ? _r : _r * 0.88; array_push(_p, _cx + cos(_a) * _rr, _cy + sin(_a) * _rr); }
            break;
        default:   // round
            _n = 72;
            for (_i = 0; _i < _n; _i++) { _a = _i / _n * 2 * pi; array_push(_p, _cx + cos(_a) * _r, _cy + sin(_a) * _r); }
            break;
    }
    return _p;
}

/// @function lpw_scale_pts(pts, cx, cy, k, [dx], [dy])
/// @description Scale a point array about a centre (and offset it). Pure.
function lpw_scale_pts(_p, _cx, _cy, _k, _dx = 0, _dy = 0) {
    var _o = array_create(array_length(_p), 0);
    for (var _i = 0; _i < array_length(_p); _i += 2) { _o[_i] = _cx + (_p[_i] - _cx) * _k + _dx; _o[_i + 1] = _cy + (_p[_i + 1] - _cy) * _k + _dy; }
    return _o;
}

/// @function lpw_fill_poly(pts, colour, [alpha])
/// @description Fill ANY simple polygon (concave included) by scanline: one span per pixel row between each pair of
/// edge crossings, all emitted in a single triangle list.
function lpw_fill_poly(_p, _col, _alpha = 1) {
    var _n = array_length(_p) div 2;
    if (_n < 3) return;
    var _y0 = 1000000, _y1 = -1000000, _i;
    for (_i = 0; _i < _n; _i++) { _y0 = min(_y0, _p[_i * 2 + 1]); _y1 = max(_y1, _p[_i * 2 + 1]); }
    // ⛔ FLUSH THE BATCH. One draw_primitive_begin/end holds a limited number of vertices and SILENTLY DROPS the rest:
    // the first version emitted every row into one list and a large seal filled only its top rows (MEASURED on the
    // A/B probe sheet: with the rim switched off the body stopped about a sixth of the way down), which at corpus size
    // showed as a dark crescent inside the lower rim. Rows are now flushed every 150 spans (900 vertices).
    var _verts = 0;
    draw_primitive_begin(pr_trianglelist);
    for (var _y = floor(_y0) + 0.5; _y < _y1; _y += 1) {
        if (_verts >= 900) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); _verts = 0; }
        var _xs = [];
        for (_i = 0; _i < _n; _i++) {
            var _ax = _p[_i * 2], _ay = _p[_i * 2 + 1];
            var _j = (_i + 1) mod _n, _bx = _p[_j * 2], _by = _p[_j * 2 + 1];
            if ((_ay <= _y && _by > _y) || (_by <= _y && _ay > _y)) array_push(_xs, _ax + (_y - _ay) / (_by - _ay) * (_bx - _ax));
        }
        array_sort(_xs, true);
        for (var _k = 0; _k + 1 < array_length(_xs); _k += 2) {
            var _xa = _xs[_k], _xb = _xs[_k + 1], _ya = _y - 0.5, _yb = _y + 0.5;
            draw_vertex_colour(_xa, _ya, _col, _alpha); draw_vertex_colour(_xb, _ya, _col, _alpha); draw_vertex_colour(_xa, _yb, _col, _alpha);
            draw_vertex_colour(_xb, _ya, _col, _alpha); draw_vertex_colour(_xb, _yb, _col, _alpha); draw_vertex_colour(_xa, _yb, _col, _alpha);
            _verts += 6;
        }
    }
    draw_primitive_end();
}

/// @function lpw_relief_rim(outer, inner, light, dark, base)
/// @description The rim band between an outline and its inset copy, one quad per edge, each coloured by how squarely
/// its outward normal faces the lamp (upper left). Each quad is a trapezoid of a star-shaped scaling, so it is convex.
function lpw_relief_rim(_o, _in, _light, _dark, _base) {
    var _n = array_length(_o) div 2;
    var _lx = -0.6, _ly = -0.8;
    for (var _i = 0; _i < _n; _i++) {
        var _j = (_i + 1) mod _n;
        var _ex = _o[_j * 2] - _o[_i * 2], _ey = _o[_j * 2 + 1] - _o[_i * 2 + 1];
        var _l = max(0.0001, sqrt(_ex * _ex + _ey * _ey));
        var _nx = _ey / _l, _ny = -_ex / _l;                     // outward normal for a clockwise-in-screen outline
        var _d = _nx * _lx + _ny * _ly;                          // -1 faces away, +1 faces the lamp
        var _c = (_d >= 0) ? merge_colour(_base, _light, _d) : merge_colour(_base, _dark, -_d);
        draw_primitive_begin(pr_trianglestrip);
        draw_vertex_colour(_o[_i * 2], _o[_i * 2 + 1], _c, 1); draw_vertex_colour(_in[_i * 2], _in[_i * 2 + 1], _c, 1);
        draw_vertex_colour(_o[_j * 2], _o[_j * 2 + 1], _c, 1); draw_vertex_colour(_in[_j * 2], _in[_j * 2 + 1], _c, 1);
        draw_primitive_end();
    }
}

/// @function lpw_seal_device(spec, cx, cy, s, colour, w)
/// @description Stroke the seal's central device (unit size `s`, stroke width `w`) in one colour.
function lpw_seal_device(_sp, _cx, _cy, _s, _col, _w) {
    var _i, _a, _p;
    switch (_sp.device) {
        case "hourglass":
            lpw_polyline([_cx - _s * 0.5, _cy - _s * 0.8, _cx + _s * 0.5, _cy - _s * 0.8, _cx - _s * 0.5, _cy + _s * 0.8, _cx + _s * 0.5, _cy + _s * 0.8, _cx - _s * 0.5, _cy - _s * 0.8], _w, _col);
            lpw_seg(_cx - _s * 0.7, _cy - _s * 0.8, _cx + _s * 0.7, _cy - _s * 0.8, _w * 1.3, _col);
            lpw_seg(_cx - _s * 0.7, _cy + _s * 0.8, _cx + _s * 0.7, _cy + _s * 0.8, _w * 1.3, _col);
            lpw_disc(_cx, _cy + _s * 0.6, _s * 0.12, _col);
            break;
        case "key":
            _p = []; for (_i = 0; _i <= 24; _i++) { _a = _i / 24 * 2 * pi; array_push(_p, _cx + cos(_a) * _s * 0.3, _cy - _s * 0.5 + sin(_a) * _s * 0.3); }
            lpw_polyline(_p, _w, _col);
            lpw_seg(_cx, _cy - _s * 0.2, _cx, _cy + _s * 0.9, _w, _col);
            lpw_seg(_cx, _cy + _s * 0.55, _cx + _s * 0.3, _cy + _s * 0.55, _w, _col);
            lpw_seg(_cx, _cy + _s * 0.8, _cx + _s * 0.24, _cy + _s * 0.8, _w, _col);
            break;
        case "bell":
            _p = lpw_bezier(_cx - _s * 0.6, _cy + _s * 0.5, _cx - _s * 0.45, _cy - _s * 0.9, _cx + _s * 0.45, _cy - _s * 0.9, _cx + _s * 0.6, _cy + _s * 0.5, 20);
            lpw_polyline(_p, _w, _col);
            lpw_seg(_cx - _s * 0.75, _cy + _s * 0.5, _cx + _s * 0.75, _cy + _s * 0.5, _w, _col);
            lpw_disc(_cx, _cy + _s * 0.72, _s * 0.14, _col);
            break;
        case "eye":
            lpw_polyline(lpw_bezier(_cx - _s * 0.85, _cy, _cx - _s * 0.3, _cy - _s * 0.6, _cx + _s * 0.3, _cy - _s * 0.6, _cx + _s * 0.85, _cy, 16), _w, _col);
            lpw_polyline(lpw_bezier(_cx - _s * 0.85, _cy, _cx - _s * 0.3, _cy + _s * 0.6, _cx + _s * 0.3, _cy + _s * 0.6, _cx + _s * 0.85, _cy, 16), _w, _col);
            lpw_ring(_cx, _cy, _s * 0.26, _s * 0.26, 0, _w, _col);
            lpw_disc(_cx, _cy, _s * 0.11, _col);
            break;
        case "moon":
            _p = []; for (_i = 0; _i <= 30; _i++) { _a = -pi / 2 + _i / 30 * pi; array_push(_p, _cx - _s * 0.1 + cos(_a) * _s * 0.75, _cy + sin(_a) * _s * 0.75); }
            for (_i = 30; _i >= 0; _i--) { _a = -pi / 2 + _i / 30 * pi; array_push(_p, _cx - _s * 0.1 + cos(_a) * _s * 0.3, _cy + sin(_a) * _s * 0.75); }
            lpw_polyline(_p, _w, _col, 1, true);
            break;
        case "sun":
            lpw_ring(_cx, _cy, _s * 0.34, _s * 0.34, 0, _w, _col);
            for (_i = 0; _i < _sp.rays; _i++) { _a = _i / _sp.rays * 2 * pi + _sp.tilt; lpw_seg(_cx + cos(_a) * _s * 0.48, _cy + sin(_a) * _s * 0.48, _cx + cos(_a) * _s * ((_i mod 2 == 0) ? 0.88 : 0.72), _cy + sin(_a) * _s * ((_i mod 2 == 0) ? 0.88 : 0.72), _w, _col); }
            break;
        case "tower":
            lpw_polyline([_cx - _s * 0.4, _cy + _s * 0.85, _cx - _s * 0.4, _cy - _s * 0.45, _cx + _s * 0.4, _cy - _s * 0.45, _cx + _s * 0.4, _cy + _s * 0.85], _w, _col);
            for (_i = 0; _i < 3; _i++) lpw_rect_fill(_cx - _s * 0.45 + _i * _s * 0.35, _cy - _s * 0.72, _s * 0.2, _s * 0.28, _col);
            lpw_polyline(lpw_bezier(_cx - _s * 0.15, _cy + _s * 0.85, _cx - _s * 0.15, _cy + _s * 0.35, _cx + _s * 0.15, _cy + _s * 0.35, _cx + _s * 0.15, _cy + _s * 0.85, 10), _w, _col);
            break;
        default:   // star
            _p = [];
            for (_i = 0; _i <= _sp.points * 2; _i++) { _a = _i / (_sp.points * 2) * 2 * pi - pi / 2 + _sp.tilt; var _rr = (_i mod 2 == 0) ? _s * 0.88 : _s * 0.38; array_push(_p, _cx + cos(_a) * _rr, _cy + sin(_a) * _rr); }
            lpw_polyline(_p, _w, _col);
            break;
    }
}

/// @function lpw_seal_border(spec, cx, cy, r, light, dark, w)
/// @description The border band struck inside the rim, raised: each mark drawn dark then light, offset toward the lamp.
function lpw_seal_border(_sp, _cx, _cy, _r, _light, _dark, _w) {
    var _i, _a, _n;
    for (var _pass = 0; _pass < 2; _pass++) {
        var _c = (_pass == 0) ? _dark : _light, _o = (_pass == 0) ? _w * 0.45 : -_w * 0.25;
        var _x = _cx + _o, _y = _cy + _o;
        switch (_sp.border) {
            case "beaded":
                _n = 22; for (_i = 0; _i < _n; _i++) { _a = _i / _n * 2 * pi; lpw_disc(_x + cos(_a) * _r, _y + sin(_a) * _r, _w * 1.05, _c); }
                break;
            case "rope":
                _n = 30; for (_i = 0; _i < _n; _i++) { _a = _i / _n * 2 * pi; lpw_seg(_x + cos(_a) * _r * 0.94, _y + sin(_a) * _r * 0.94, _x + cos(_a + 0.13) * _r * 1.06, _y + sin(_a + 0.13) * _r * 1.06, _w, _c); }
                break;
            case "dentil":
                _n = 36; for (_i = 0; _i < _n; _i++) { _a = _i / _n * 2 * pi; lpw_seg(_x + cos(_a) * _r * 0.92, _y + sin(_a) * _r * 0.92, _x + cos(_a) * _r * 1.07, _y + sin(_a) * _r * 1.07, _w * 1.2, _c); }
                break;
            case "laurel":
                _n = 18; for (_i = 0; _i < _n; _i++) { _a = _i / _n * 2 * pi; lpw_fill_convex(lpw_ellipse_pts(_x + cos(_a) * _r, _y + sin(_a) * _r, _w * 2.2, _w * 0.9, _a + pi / 2 + 0.5, 10), _c); }
                break;
            case "notched":
                _n = 24; for (_i = 0; _i < _n; _i++) { _a = _i / _n * 2 * pi; var _t = 0.07; lpw_fill_convex([_x + cos(_a) * _r * 1.07, _y + sin(_a) * _r * 1.07, _x + cos(_a + _t) * _r * 0.9, _y + sin(_a + _t) * _r * 0.9, _x + cos(_a - _t) * _r * 0.9, _y + sin(_a - _t) * _r * 0.9], _c); }
                break;
            default:   // double
                lpw_ring(_x, _y, _r * 1.05, _r * 1.05, 0, _w, _c);
                lpw_ring(_x, _y, _r * 0.9, _r * 0.9, 0, _w * 0.7, _c);
                break;
        }
    }
}

/// @function lpw_seal_band(spec)
/// @description The border band's radius as a fraction of the seal's: 0.66 where the face allows it, less where the
/// face's measured inradius does not (a band mark reaches 1.07 of the band radius, and must stay on the face, which
/// is the outline inset to 0.84). Pure.
function lpw_seal_band(_sp) {
    if (!is_struct(_sp) || !variable_struct_exists(_sp, "outline")) return 0.66;
    var _in = lpw_scale_pts(lpw_seal_outline(_sp, 0, 0, 100), 0, 0, 0.84);
    return min(0.66, (lpw_inradius(_in, 0, 0) / 100) / 1.07 * 0.97);
}

/// @function lpw_seal_draw(id, loop, x, y, radius)
/// @description Strike a fact's seal centred on (x, y). Returns its spec, or undefined for a bad input. Never throws.
function lpw_seal_draw(_id, _loop, _x, _y, _r) {
    if (!is_numeric(_x) || !is_numeric(_y) || !is_numeric(_r) || _r < 4 || lpw_id(_id) == "") return undefined;
    return lpw_seal_draw_spec(lpw_seal_spec(_id, _loop), _x, _y, _r);
}

/// @function lpw_seal_draw_spec(spec, x, y, radius)
/// @description Strike a seal from an explicit recipe (a spec from lpw_seal_spec, possibly edited). Returns the spec.
function lpw_seal_draw_spec(_sp, _x, _y, _r) {
    if (!is_struct(_sp) || !variable_struct_exists(_sp, "outline") || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_r) || _r < 4) return undefined;
    var _base = _sp.base, _light = merge_colour(_base, c_white, 0.42), _dark = merge_colour(_base, c_black, 0.55);
    var _o = lpw_seal_outline(_sp, _x, _y, _r);
    // cast shadow, SOFT: three stacked low-alpha fills. One hard fill at 0.32 read as a black lip under every seal on
    // the dark sheet (seen on the corpus bake) - a second edge, not a shadow.
    lpw_fill_poly(lpw_scale_pts(_o, _x, _y, 1.02, _r * 0.03, _r * 0.05), c_black, 0.14);
    lpw_fill_poly(lpw_scale_pts(_o, _x, _y, 1.0, _r * 0.05, _r * 0.08), c_black, 0.12);
    lpw_fill_poly(lpw_scale_pts(_o, _x, _y, 0.98, _r * 0.07, _r * 0.11), c_black, 0.10);
    lpw_fill_poly(_o, _base);
    var _in = lpw_scale_pts(_o, _x, _y, 0.84);
    lpw_relief_rim(_o, _in, _light, _dark, _base);
    lpw_fill_poly(_in, merge_colour(_base, c_black, 0.08));
    lpw_glow_poly(_in, _x, _y, _x - _r * 0.25, _y - _r * 0.3, _r * 0.8, _light, 0.22);      // the lamp on the face, kept ON the face
    // the band and the device are sized from the FACE'S measured inradius, not the seal's radius: a round face gives
    // the 0.66 band the corpus was tuned on; a lozenge's face is barely half the radius and gets a smaller band
    var _band = lpw_seal_band(_sp);
    lpw_seal_border(_sp, _x, _y, _r * _band, _light, _dark, max(1, _r * 0.035));
    // the device fills the field inside the band: 0.42 of the radius left it a small mark in a large face
    var _w = max(1.2, _r * 0.075), _ds = _r * 0.52 * (_band / 0.66);
    lpw_seal_device(_sp, _x + _r * 0.025, _y + _r * 0.03, _ds, _light, _w);                    // the lit lower lip
    lpw_seal_device(_sp, _x, _y, _ds, _dark, _w);                                                // the impression
    return _sp;
}
