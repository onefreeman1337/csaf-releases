/// lpw_core.gml - the loop engine. PURE GML: no drawing, no instances, no globals.
///
/// Loopwork - A Time Loop That Remembers, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// What a time-loop game needs and every author rebuilds by hand: facts the player keeps across loops, a record of
/// what they did differently each time, a snapshot of the world at the start of the day, and a rewind that restores
/// the world WITHOUT restoring what the player learned. Ported from Core Systems Asset Factory's RPG Maker MZ plugin
/// Loop Core; the engine's rules are the same and the layout of the knowledge constellation is identical.
///
/// ⭐ THE REWIND IS A PLAN, NOT AN ACTION. lpw_plan_rewind returns which named values to put back and changes nothing,
/// so the rules deciding what survives a reset are testable on plain data, and the buyer applies the plan to their
/// own globals, instance variables or save struct - Loopwork never reaches into the game.
///
/// ⚠️ EVERY COLLECTION IS AN ARRAY OF RECORDS, keyed by author text, never a struct keyed by author text: an id is
/// whatever the author typed, and a struct key taken from author text is a name collision with the record's own
/// fields waiting to happen.
///
/// PUBLIC API (each function's header says more):
///   lpw_create()                         lpw_is_state(value)            lpw_loop(state)
///   lpw_learn(state, id, [label])        lpw_knows(state, id)           lpw_forget(state, id)
///   lpw_fact_loop(state, id)             lpw_learned_this_loop(state, id)
///   lpw_facts(state)                     lpw_diverge(state, key, [label])
///   lpw_diverged(state, key)             lpw_divergences(state, loop)
///   lpw_anchor(state, pairs)             lpw_plan_rewind(state, world, [carried])
///   lpw_close_loop(state, [cause], [max_history])   lpw_history(state)
///   lpw_save(state) -> string            lpw_load(string) -> state
///   lpw_constellation(state, [passes])   lpw_constellation_links(nodes)
///   lpw_hash(string)

#macro LPW_VERSION "0.1.0"
#macro LPW_SCHEMA 1

/// @function lpw_hash(string)
/// @description 32-bit FNV-1a of a string, EXACT (int64 arithmetic, masked to 32 bits) - the same hash as the MZ
/// plugin's hash32, which is why the constellation lays out identically in both engines. Pure.
function lpw_hash(_s) {
    _s = string(_s);
    var _h = int64(2166136261);
    var _n = string_length(_s);
    for (var _i = 1; _i <= _n; _i++) {
        _h = ((_h ^ int64(ord(string_char_at(_s, _i)))) * int64(16777619)) & int64(4294967295);
    }
    return real(_h);
}

/// @function lpw_create()
/// @description A fresh loop record: loop 1, nothing known, no anchor. Pure.
function lpw_create() {
    return { lpw_kind: "loop", version: LPW_SCHEMA, loop_index: 1, anchored: false, anchor: [],
             facts: [], diverged: [], loops: [], seq: 0 };
}

/// @function lpw_is_state(value)
/// @description True if value is a loop record. Pure.
function lpw_is_state(_v) {
    return is_struct(_v) && variable_struct_exists(_v, "lpw_kind") && _v.lpw_kind == "loop"
        && is_array(_v.facts) && is_array(_v.diverged) && is_array(_v.loops);
}

/// @function lpw_id(value)
/// @description An author id as a trimmed string ("" for nothing usable). Pure.
function lpw_id(_v) {
    if (is_undefined(_v)) return "";
    var _s = string(_v);
    while (string_length(_s) > 0 && string_char_at(_s, 1) == " ") _s = string_delete(_s, 1, 1);
    while (string_length(_s) > 0 && string_char_at(_s, string_length(_s)) == " ") _s = string_delete(_s, string_length(_s), 1);
    return _s;
}

/// @function lpw_find(list, field, id)
/// @description Index of the record whose `field` equals `id`, or -1. Linear on purpose: a loop game carries tens of
/// facts, not thousands. Pure.
function lpw_find(_list, _field, _id) {
    for (var _i = 0; _i < array_length(_list); _i++) if (_list[_i][$ _field] == _id) return _i;
    return -1;
}

/// @function lpw_loop(state)
/// @description The current loop number (1 on the first day), or 0 for a non-state. Pure.
function lpw_loop(_st) { return lpw_is_state(_st) ? _st.loop_index : 0; }

/// @function lpw_learn(state, id, [label])
/// @description The player learns a fact. IDEMPOTENT: re-learning keeps the loop it was FIRST learned in, because that
/// is the interesting fact and re-triggering an event must not rewrite history. Returns true if it was new.
function lpw_learn(_st, _fid, _label = undefined) {
    if (!lpw_is_state(_st)) return false;
    var _id = lpw_id(_fid);
    if (_id == "" || lpw_find(_st.facts, "id", _id) >= 0) return false;
    _st.seq += 1;
    array_push(_st.facts, { id: _id, label: is_undefined(_label) ? _id : string(_label), loop: _st.loop_index, seq: _st.seq });
    return true;
}

/// @function lpw_knows(state, id)
/// @description Does the player know this fact (in any loop)? Pure.
function lpw_knows(_st, _fid) { return lpw_is_state(_st) && lpw_find(_st.facts, "id", lpw_id(_fid)) >= 0; }

/// @function lpw_fact_loop(state, id)
/// @description The loop a fact was learned in, or 0 if unknown. Pure.
function lpw_fact_loop(_st, _fid) {
    if (!lpw_is_state(_st)) return 0;
    var _i = lpw_find(_st.facts, "id", lpw_id(_fid));
    return (_i < 0) ? 0 : _st.facts[_i].loop;
}

/// @function lpw_learned_this_loop(state, id)
/// @description Was it learned during the CURRENT loop? Pure.
function lpw_learned_this_loop(_st, _fid) {
    if (!lpw_is_state(_st)) return false;
    var _i = lpw_find(_st.facts, "id", lpw_id(_fid));
    return _i >= 0 && _st.facts[_i].loop == _st.loop_index;
}

/// @function lpw_forget(state, id)
/// @description Remove a fact. Returns true if something was removed.
function lpw_forget(_st, _fid) {
    if (!lpw_is_state(_st)) return false;
    var _i = lpw_find(_st.facts, "id", lpw_id(_fid));
    if (_i < 0) return false;
    array_delete(_st.facts, _i, 1);
    return true;
}

/// @function lpw_facts(state)
/// @description A copy of the fact records ({id, label, loop, seq}), in learning order. Pure.
function lpw_facts(_st) {
    var _out = [];
    if (!lpw_is_state(_st)) return _out;
    for (var _i = 0; _i < array_length(_st.facts); _i++) array_push(_out, _st.facts[_i]);
    return _out;
}

/// @function lpw_diverge(state, key, [label])
/// @description The player did something THIS loop they had not done in it before. Divergences are recorded per loop
/// (the Ledger draws each loop's own). Returns true if new for this loop.
function lpw_diverge(_st, _key, _label = undefined) {
    if (!lpw_is_state(_st)) return false;
    var _id = lpw_id(_key);
    if (_id == "") return false;
    for (var _i = 0; _i < array_length(_st.diverged); _i++) {
        if (_st.diverged[_i].key == _id && _st.diverged[_i].loop == _st.loop_index) return false;
    }
    _st.seq += 1;
    array_push(_st.diverged, { key: _id, label: is_undefined(_label) ? _id : string(_label), loop: _st.loop_index, seq: _st.seq });
    return true;
}

/// @function lpw_diverged(state, key)
/// @description Has the player EVER done this, in any loop? Pure.
function lpw_diverged(_st, _key) { return lpw_is_state(_st) && lpw_find(_st.diverged, "key", lpw_id(_key)) >= 0; }

/// @function lpw_divergences(state, loop)
/// @description The divergence records of one loop. Pure.
function lpw_divergences(_st, _loop) {
    var _out = [];
    if (!lpw_is_state(_st) || !is_numeric(_loop)) return _out;
    for (var _i = 0; _i < array_length(_st.diverged); _i++) if (_st.diverged[_i].loop == _loop) array_push(_out, _st.diverged[_i]);
    return _out;
}

/// @function lpw_anchor(state, pairs)
/// @description Snapshot the world at the start of the day: `pairs` is an array of [name, value] - whatever world
/// state the buyer wants rewound (door states, NPC positions, quest flags). Loopwork keeps the snapshot and never
/// reads the game. Non-pair entries are skipped. Returns the number of pairs kept.
function lpw_anchor(_st, _pairs) {
    if (!lpw_is_state(_st)) return 0;
    _st.anchor = [];
    if (is_array(_pairs)) for (var _i = 0; _i < array_length(_pairs); _i++) {
        var _p = _pairs[_i];
        if (is_array(_p) && array_length(_p) >= 2 && lpw_id(_p[0]) != "") array_push(_st.anchor, [lpw_id(_p[0]), _p[1]]);
    }
    _st.anchored = true;
    return array_length(_st.anchor);
}

/// @function lpw_plan_rewind(state, world, [carried])
/// @description WHAT A REWIND SHOULD WRITE, without writing anything: {restore: [[name, value]], skipped: [name]}.
/// `world` is the array of names that rewind; `carried` the names that SURVIVE a loop. A name in both is carried -
/// the author named it as an exception. Names not in `world` are left alone. Pure.
function lpw_plan_rewind(_st, _world, _carried = []) {
    var _plan = { restore: [], skipped: [] };
    if (!lpw_is_state(_st) || !_st.anchored) return _plan;
    if (!is_array(_world)) _world = [];
    if (!is_array(_carried)) _carried = [];
    for (var _i = 0; _i < array_length(_st.anchor); _i++) {
        var _name = _st.anchor[_i][0];
        if (lpw_in(_carried, _name)) { array_push(_plan.skipped, _name); continue; }
        if (!lpw_in(_world, _name)) continue;
        array_push(_plan.restore, [_name, _st.anchor[_i][1]]);
    }
    return _plan;
}

/// @function lpw_in(array, name)
/// @description Is `name` in `array` (compared as trimmed strings)? Pure.
function lpw_in(_arr, _name) {
    for (var _i = 0; _i < array_length(_arr); _i++) if (lpw_id(_arr[_i]) == _name) return true;
    return false;
}

/// @function lpw_close_loop(state, [cause], [max_history])
/// @description End the current loop and start the next. The history keeps at most `max_history` loops (default
/// 40) so a long game cannot grow the save without bound; the loop COUNTER is never trimmed, because how many loops
/// the player survived is a story beat. Returns the closed loop's record {index, cause, facts, pins}, or undefined.
function lpw_close_loop(_st, _cause = "", _cap = 40) {
    if (!lpw_is_state(_st)) return undefined;
    var _learned = 0;
    for (var _i = 0; _i < array_length(_st.facts); _i++) if (_st.facts[_i].loop == _st.loop_index) _learned++;
    var _rec = { index: _st.loop_index, cause: is_undefined(_cause) ? "" : string(_cause), facts: _learned,
                 pins: array_length(lpw_divergences(_st, _st.loop_index)) };
    array_push(_st.loops, _rec);
    var _c = is_numeric(_cap) ? max(1, floor(_cap)) : 40;
    while (array_length(_st.loops) > _c) array_delete(_st.loops, 0, 1);
    _st.loop_index += 1;
    return _rec;
}

/// @function lpw_history(state)
/// @description The closed loops' records, oldest first. Pure.
function lpw_history(_st) {
    var _out = [];
    if (!lpw_is_state(_st)) return _out;
    for (var _i = 0; _i < array_length(_st.loops); _i++) array_push(_out, _st.loops[_i]);
    return _out;
}

/// @function lpw_save(state)
/// @description The loop record as a string for your save file ("" for a non-state).
function lpw_save(_st) { return lpw_is_state(_st) ? json_stringify(_st) : ""; }

/// @function lpw_load(string)
/// @description A loop record from a saved string, MIGRATED on every load (so the migration path runs constantly,
/// not only on the day it is needed). Anything unreadable becomes a fresh record, never an exception; a partial or
/// hand-edited record is repaired field by field rather than refused.
function lpw_load(_s) {
    var _raw = undefined;
    if (is_string(_s) && _s != "") { try { _raw = json_parse(_s); } catch (_e) { _raw = undefined; } }
    if (!is_struct(_raw)) return lpw_create();
    var _st = _raw;
    _st.lpw_kind = "loop";
    if (!variable_struct_exists(_st, "version") || !is_numeric(_st.version)) _st.version = 0;
    if (_st.version < 1) {
        if (!variable_struct_exists(_st, "facts") || !is_array(_st.facts)) _st.facts = [];
        if (!variable_struct_exists(_st, "diverged") || !is_array(_st.diverged)) _st.diverged = [];
        if (!variable_struct_exists(_st, "loops") || !is_array(_st.loops)) _st.loops = [];
        if (!variable_struct_exists(_st, "loop_index") || !is_numeric(_st.loop_index) || _st.loop_index < 1) _st.loop_index = 1;
        if (!variable_struct_exists(_st, "seq") || !is_numeric(_st.seq)) _st.seq = array_length(_st.facts) + array_length(_st.diverged);
        if (!variable_struct_exists(_st, "anchor") || !is_array(_st.anchor)) _st.anchor = [];
        if (!variable_struct_exists(_st, "anchored")) _st.anchored = array_length(_st.anchor) > 0;
        _st.version = 1;
    }
    // records that lost their id cannot be addressed; drop them rather than keep ghosts
    for (var _i = array_length(_st.facts) - 1; _i >= 0; _i--) {
        var _f = _st.facts[_i];
        if (!is_struct(_f) || !variable_struct_exists(_f, "id") || lpw_id(_f.id) == "") array_delete(_st.facts, _i, 1);
    }
    return _st;
}

/// @function lpw_constellation(state, [passes])
/// @description Lay the known facts out as a constellation in a 0..1 box: each fact's start position comes from two
/// halves of its own hash (so the same save always draws the same map), a fixed number of relaxation passes pushes
/// crowded stars apart, and the result is stretched to fill the box. Returns [{id, label, loop, x, y}]. Pure.
/// Identical to the MZ plugin's layout for the same fact ids (the suite checks it against the MZ plugin's numbers).
function lpw_constellation(_st, _passes = 24) {
    var _nodes = [], _i, _j;
    if (!lpw_is_state(_st)) return _nodes;
    for (_i = 0; _i < array_length(_st.facts); _i++) {
        var _h = lpw_hash(_st.facts[_i].id);
        array_push(_nodes, { id: _st.facts[_i].id, label: _st.facts[_i].label, loop: _st.facts[_i].loop,
            x: 0.12 + ((real(int64(_h) & 65535)) / 65535) * 0.76,
            y: 0.12 + ((real((int64(_h) >> 16) & 65535)) / 65535) * 0.76 });
    }
    var _n = is_numeric(_passes) ? clamp(floor(_passes), 0, 200) : 24;
    var _k = array_length(_nodes);
    var _mind = (_k > 1) ? min(0.18, 0.9 / sqrt(_k)) : 0.18;
    for (var _p = 0; _p < _n; _p++) {
        for (_i = 0; _i < _k; _i++) for (_j = _i + 1; _j < _k; _j++) {
            var _dx = _nodes[_j].x - _nodes[_i].x, _dy = _nodes[_j].y - _nodes[_i].y;
            var _d = sqrt(_dx * _dx + _dy * _dy);
            if (_d >= _mind || _d <= 0) continue;
            var _push = (_mind - _d) / 2, _ux = _dx / _d, _uy = _dy / _d;
            _nodes[_i].x -= _ux * _push; _nodes[_i].y -= _uy * _push;
            _nodes[_j].x += _ux * _push; _nodes[_j].y += _uy * _push;
        }
        for (_i = 0; _i < _k; _i++) {
            _nodes[_i].x = clamp(_nodes[_i].x, 0.06, 0.94);
            _nodes[_i].y = clamp(_nodes[_i].y, 0.06, 0.94);
        }
    }
    return lpw_fit_box(_nodes);
}

/// @function lpw_fit_box(nodes)
/// @description Stretch laid-out nodes so their bounding box fills 0.10..0.90 on both axes (a small fact set would
/// otherwise cluster in one corner). A degenerate axis is centred rather than divided by zero. Pure.
/// ⚠️ The degenerate test is `span > 0.0001`, never the MZ plugin's 1e-6: GML compares with an epsilon of 0.00001,
/// so a tolerance below it is FALSE for every value and the guard would be dead code.
function lpw_fit_box(_nodes) {
    var _k = array_length(_nodes), _i;
    if (_k < 2) { if (_k == 1) { _nodes[0].x = 0.5; _nodes[0].y = 0.5; } return _nodes; }
    var _x0 = 1000000, _x1 = -1000000, _y0 = 1000000, _y1 = -1000000;
    for (_i = 0; _i < _k; _i++) {
        _x0 = min(_x0, _nodes[_i].x); _x1 = max(_x1, _nodes[_i].x);
        _y0 = min(_y0, _nodes[_i].y); _y1 = max(_y1, _nodes[_i].y);
    }
    var _sx = _x1 - _x0, _sy = _y1 - _y0;
    for (_i = 0; _i < _k; _i++) {
        _nodes[_i].x = (_sx > 0.0001) ? 0.10 + ((_nodes[_i].x - _x0) / _sx) * 0.80 : 0.5;
        _nodes[_i].y = (_sy > 0.0001) ? 0.10 + ((_nodes[_i].y - _y0) / _sy) * 0.80 : 0.5;
    }
    return _nodes;
}

/// @function lpw_constellation_links(nodes)
/// @description Which stars to join: facts learned in the SAME loop, because the story that taught them relates
/// them - a picture that means something rather than a nearest-neighbour scatter. Returns [[i, j]]. Pure.
function lpw_constellation_links(_nodes) {
    var _out = [];
    if (!is_array(_nodes)) return _out;
    for (var _i = 0; _i < array_length(_nodes); _i++) for (var _j = _i + 1; _j < array_length(_nodes); _j++) {
        if (is_struct(_nodes[_i]) && is_struct(_nodes[_j]) && _nodes[_i].loop == _nodes[_j].loop) array_push(_out, [_i, _j]);
    }
    return _out;
}
