{
  "$GMScript": "v1",
  "%Name": "lpw_core",
  "name": "lpw_core",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}