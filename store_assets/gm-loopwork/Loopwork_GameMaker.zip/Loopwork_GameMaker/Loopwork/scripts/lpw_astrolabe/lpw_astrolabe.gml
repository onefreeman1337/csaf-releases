/// lpw_astrolabe.gml - the Loop Ledger's instrument: an engraved BRASS ASTROLABE generated from the loop record.
///
/// Loopwork - A Time Loop That Remembers, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// An astrolabe is two layers, and Loopwork uses both:
///   THE PLATE (engraved, fixed) is what the player DID. A clock limb runs round the edge; inside it there is one
///   engraved ring per loop (oldest innermost), the live loop inlaid in blued steel, and every divergence struck
///   into its ring as a faceted blued-steel pin at an angle derived from its own key.
///   THE RETE (pierced, raised, and it TURNS) is what the player KNOWS. Every fact is a star at the position
///   lpw_constellation gives it, pointed at by a flame with a jewel in the wax of the loop it was learned in;
///   facts learned in the same loop are joined by a wire, in the order they were learned. On a real astrolabe the
///   rete is the star map laid over the engraved plate; here it is the map of what the player knows, laid over
///   the record of what they did.
///
/// ⭐ LAYOUT IS PURE, DRAWING IS SEPARATE. lpw_astrolabe_layout computes every ring, pin, star, strut and wire
/// without touching a surface, so the suite asserts the geometry directly (Doctrine_Craft: a suite that cannot see
/// a picture asserts the contract).
/// ⛔ Nothing here is checked by looking except by looking: the bake renders the instrument and it is opened.
///
/// PUBLIC API:
///   lpw_astrolabe_layout(state, x, y, radius, [turn], [reveal]) -> the geometry (pure), or undefined
///   lpw_astrolabe_draw(state, x, y, radius, [turn], [reveal])   -> draws it; returns {rings, pins, stars} or undefined
///   lpw_pin_angle(key)                                           -> the angle (radians) a divergence is struck at
///   `turn` rotates the rete (radians). `reveal` 0..1 cuts the live loop's ring round from twelve o'clock and holds
///   back its pins until the cut reaches them. Together they animate a loop closing (see obj_lpw_demo).
///   The instrument occupies (x - 1.0 r) .. (x + 1.05 r) across and (y - 1.0 r) .. (y + 1.07 r) down, shadow included.

// Radii as fractions of the instrument's radius. The ring field sits inside the rete's outer ring, which sits inside
// the limb; the stars sit inside the rete ring and outside the boss, so no star can hide under either.
#macro LPW_ASTRO_BOSS 0.13
#macro LPW_ASTRO_RIN 0.19
#macro LPW_ASTRO_ROUT 0.60
#macro LPW_ASTRO_RETE 0.665
#macro LPW_ASTRO_ECL_OFF 0.20
#macro LPW_ASTRO_ECL_R 0.465
#macro LPW_ASTRO_STAR_IN 0.23
#macro LPW_ASTRO_STAR_OUT 0.58
#macro LPW_ASTRO_POINTER 0.075

/// @function lpw_pin_angle(key)
/// @description Where on its ring a divergence is struck: from the key's own hash, so the same choice always lands in
/// the same place and a crowded ring is visibly a loop where the player changed things. Pure.
function lpw_pin_angle(_key) { return (lpw_hash(lpw_id(_key) + "#pin") mod 3600) / 3600 * 2 * pi; }

/// @function lpw_brass(t)
/// @description A brass tone, t = 0 (deep shadow) .. 1 (highlight). Pure.
function lpw_brass(_t) {
    _t = clamp(_t, 0, 1);
    if (_t < 0.5) return merge_colour(make_colour_rgb(74, 50, 18), make_colour_rgb(178, 134, 58), _t * 2);
    return merge_colour(make_colour_rgb(178, 134, 58), make_colour_rgb(246, 214, 140), (_t - 0.5) * 2);
}

/// @function lpw_blued(t)
/// @description A blued-steel tone (the heat-blued steel of clock hands and screws), t = 0 .. 1. Pure.
function lpw_blued(_t) {
    _t = clamp(_t, 0, 1);
    if (_t < 0.5) return merge_colour(make_colour_rgb(12, 16, 44), make_colour_rgb(38, 66, 146), _t * 2);
    return merge_colour(make_colour_rgb(38, 66, 146), make_colour_rgb(156, 194, 246), (_t - 0.5) * 2);
}

/// @function lpw_arc(cx, cy, r, a0, a1, w, colour, [alpha])
/// @description A circular arc stroke `w` pixels wide from angle a0 to a1 (radians, a1 > a0), as one strip. Below
/// one pixel it is drawn one pixel wide at a proportional alpha. ⚠️ At most 400 segments (802 vertices), which keeps
/// the single batch under the ~1000-vertex limit that silently truncated the seal fills (Doctrine_Craft §7b).
function lpw_arc(_cx, _cy, _r, _a0, _a1, _w, _col, _alpha = 1) {
    if (_r <= 0 || _w <= 0 || _a1 <= _a0) return;
    var _a = _alpha, _ww = _w;
    if (_w < 1) { _a = _alpha * max(0.15, _w); _ww = 1; }
    var _n = clamp(ceil((_a1 - _a0) * _r / 3), 8, 400), _h = _ww * 0.5;
    draw_primitive_begin(pr_trianglestrip);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _a0 + (_a1 - _a0) * _i / _n;
        draw_vertex_colour(_cx + cos(_t) * (_r + _h), _cy + sin(_t) * (_r + _h), _col, _a);
        draw_vertex_colour(_cx + cos(_t) * max(0, _r - _h), _cy + sin(_t) * max(0, _r - _h), _col, _a);
    }
    draw_primitive_end();
}

/// @function lpw_engrave_arc(cx, cy, r, a0, a1, w, [alpha])
/// @description An engraved line along an arc: a dark cut with a lit lower lip, so it reads as cut INTO the brass.
function lpw_engrave_arc(_cx, _cy, _r, _a0, _a1, _w, _alpha = 1) {
    lpw_arc(_cx + _w * 0.45, _cy + _w * 0.55, _r, _a0, _a1, _w, lpw_brass(0.92), _alpha * 0.8);
    lpw_arc(_cx, _cy, _r, _a0, _a1, _w, lpw_brass(0.12), _alpha);
}

/// @function lpw_engrave_ring(cx, cy, r, w, [alpha])
/// @description A full engraved circle.
function lpw_engrave_ring(_cx, _cy, _r, _w, _alpha = 1) { lpw_engrave_arc(_cx, _cy, _r, 0, 2 * pi, _w, _alpha); }

/// @function lpw_rete_nearest(layout, px, py)
/// @description The nearest point of the rete's frame (outer ring, ecliptic ring, the four bars) to a point, as
/// [x, y, distance]. Pure.
function lpw_rete_nearest(_L, _px, _py) {
    var _best = [_px, _py, 1000000], _dx, _dy, _d, _e, _k, _b, _vx, _vy, _ll, _t, _qx, _qy;
    _dx = _px - _L.x; _dy = _py - _L.y; _d = sqrt(_dx * _dx + _dy * _dy);
    if (_d > 0.0001) { _e = abs(_d - _L.rete_r); if (_e < _best[2]) _best = [_L.x + _dx / _d * _L.rete_r, _L.y + _dy / _d * _L.rete_r, _e]; }
    _dx = _px - _L.ecliptic.x; _dy = _py - _L.ecliptic.y; _d = sqrt(_dx * _dx + _dy * _dy);
    if (_d > 0.0001) { _e = abs(_d - _L.ecliptic.r); if (_e < _best[2]) _best = [_L.ecliptic.x + _dx / _d * _L.ecliptic.r, _L.ecliptic.y + _dy / _d * _L.ecliptic.r, _e]; }
    for (_k = 0; _k < array_length(_L.bars); _k++) {
        _b = _L.bars[_k];
        _vx = _b[2] - _b[0]; _vy = _b[3] - _b[1]; _ll = _vx * _vx + _vy * _vy;
        _t = (_ll > 0) ? clamp(((_px - _b[0]) * _vx + (_py - _b[1]) * _vy) / _ll, 0, 1) : 0;
        _qx = _b[0] + _vx * _t; _qy = _b[1] + _vy * _t;
        _e = point_distance(_px, _py, _qx, _qy);
        if (_e < _best[2]) _best = [_qx, _qy, _e];
    }
    return _best;
}

/// @function lpw_astrolabe_layout(state, x, y, radius, [turn], [reveal])
/// @description Every piece of the instrument for a loop record, as plain data:
///   rings  [{loop, rr, live}]                       one per loop from the oldest kept to the live one
///   pins   [{x, y, a, rr, loop, key, live}]          one per divergence in those loops
///   stars  [{x, y, id, label, loop, wax, nx, ny, bx, by, strut, pointer, bend}]  one per known fact
///   links  [[i, j]]                                  same-loop facts joined in learning order
///   bars   [[x1, y1, x2, y2]], rete_r, ecliptic {x, y, r}, live, first, turn, reveal
/// Returns undefined for a non-state, a non-number position or a radius under 20. Pure.
function lpw_astrolabe_layout(_st, _x, _y, _r, _turn = 0, _reveal = 1) {
    if (!lpw_is_state(_st) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_r) || _r < 20) return undefined;
    if (!is_numeric(_turn)) _turn = 0;
    _reveal = is_numeric(_reveal) ? clamp(_reveal, 0, 1) : 1;
    var _L = { x: _x, y: _y, r: _r, turn: _turn, reveal: _reveal, rings: [], pins: [], stars: [], links: [], bars: [] };
    var _hist = lpw_history(_st), _live = lpw_loop(_st), _i, _k, _a;
    var _first = (array_length(_hist) > 0) ? _hist[0].index : _live;
    var _count = _live - _first + 1;
    _L.live = _live; _L.first = _first;
    // the plate: rings and pins
    var _rin = _r * LPW_ASTRO_RIN, _rout = _r * LPW_ASTRO_ROUT;
    for (_k = 0; _k < _count; _k++) {
        var _loop = _first + _k;
        var _rr = (_count <= 1) ? _rout : _rin + (_rout - _rin) * (_k / (_count - 1));
        array_push(_L.rings, { loop: _loop, rr: _rr, live: (_loop == _live) });
        var _dv = lpw_divergences(_st, _loop);
        for (_i = 0; _i < array_length(_dv); _i++) {
            _a = lpw_pin_angle(_dv[_i].key);
            array_push(_L.pins, { x: _x + cos(_a) * _rr, y: _y + sin(_a) * _rr, a: _a, rr: _rr, loop: _loop, key: _dv[_i].key, live: (_loop == _live) });
        }
    }
    // the rete's frame, turned
    _L.rete_r = _r * LPW_ASTRO_RETE;
    _L.ecliptic = { x: _x + cos(_turn - pi / 2) * _r * LPW_ASTRO_ECL_OFF, y: _y + sin(_turn - pi / 2) * _r * LPW_ASTRO_ECL_OFF, r: _r * LPW_ASTRO_ECL_R };
    for (_k = 0; _k < 4; _k++) {
        _a = _turn + _k * pi / 2;
        array_push(_L.bars, [_x + cos(_a) * _r * LPW_ASTRO_BOSS, _y + sin(_a) * _r * LPW_ASTRO_BOSS, _x + cos(_a) * _L.rete_r, _y + sin(_a) * _L.rete_r]);
    }
    // the stars: the constellation's 0.10..0.90 box mapped onto a disc, then onto the annulus between the boss and
    // the rete ring (a fact at the centre of the box would otherwise sit under the boss)
    var _nodes = lpw_constellation(_st), _W = lpw_seal_waxes(), _last = {};
    var _pl = _r * LPW_ASTRO_POINTER;
    for (_i = 0; _i < array_length(_nodes); _i++) {
        var _nd = _nodes[_i];
        var _u = clamp((_nd.x - 0.5) / 0.4, -1, 1), _v = clamp((_nd.y - 0.5) / 0.4, -1, 1);
        var _dx = _u * sqrt(1 - _v * _v / 2), _dy = _v * sqrt(1 - _u * _u / 2);
        var _rho = min(1, sqrt(_dx * _dx + _dy * _dy));
        var _ang = ((_rho > 0.0001) ? arctan2(_dy, _dx) : lpw_pin_angle(_nd.id)) + _turn;
        var _rp = _r * (LPW_ASTRO_STAR_IN + (LPW_ASTRO_STAR_OUT - LPW_ASTRO_STAR_IN) * _rho);
        var _sx = _x + cos(_ang) * _rp, _sy = _y + sin(_ang) * _rp;
        var _nb = lpw_rete_nearest(_L, _sx, _sy), _d = _nb[2];
        var _bx = _nb[0], _by = _nb[1], _strut = false, _ptr = true;
        if (_d < _r * 0.02) { _ptr = false; _bx = _sx; _by = _sy; }
        else if (_d > _pl) { _strut = true; _bx = _sx + (_nb[0] - _sx) / _d * _pl; _by = _sy + (_nb[1] - _sy) / _d * _pl; }
        var _lp = max(1, _nd.loop);
        array_push(_L.stars, { x: _sx, y: _sy, id: _nd.id, label: _nd.label, loop: _nd.loop, wax: _W[(_lp - 1) mod array_length(_W)].base,
            nx: _nb[0], ny: _nb[1], bx: _bx, by: _by, strut: _strut, pointer: _ptr,
            bend: ((lpw_hash(_nd.id + "#flame") & 1) == 0) ? 1 : -1 });
        var _lk = string(_nd.loop);
        if (variable_struct_exists(_last, _lk)) array_push(_L.links, [_last[$ _lk], _i]);
        _last[$ _lk] = _i;
    }
    return _L;
}

/// @function lpw_flame_pts(bx, by, tx, ty, hw, bend)
/// @description A star pointer's outline: a curved flame from its base (bx, by) to its tip (tx, ty), `hw` the widest
/// half-width, bending to one side. A flat point array, simple (it is only ever filled by scanline). Pure.
function lpw_flame_pts(_bx, _by, _tx, _ty, _hw, _bend) {
    var _dx = _tx - _bx, _dy = _ty - _by, _l = sqrt(_dx * _dx + _dy * _dy);
    if (_l <= 0) return [];
    var _nx = -_dy / _l, _ny = _dx / _l, _n = 12, _i, _t, _cx, _cy, _w;
    var _left = [], _right = [];
    for (_i = 0; _i <= _n; _i++) {
        _t = _i / _n;
        _cx = _bx + _dx * _t + _nx * _bend * _l * 0.18 * sin(pi * _t);
        _cy = _by + _dy * _t + _ny * _bend * _l * 0.18 * sin(pi * _t);
        _w = _hw * power(1 - _t, 0.8) * (0.55 + 0.45 * sin(pi * min(_t * 1.6, 1)));
        array_push(_left, _cx + _nx * _w, _cy + _ny * _w);
        array_push(_right, _cx - _nx * _w, _cy - _ny * _w);
    }
    var _out = _left;
    for (_i = array_length(_right) - 2; _i >= 0; _i -= 2) array_push(_out, _right[_i], _right[_i + 1]);
    return _out;
}

/// @function lpw_rete_seg(x1, y1, x2, y2, w, pass, sox, soy)
/// @description One straight rete member in one of three passes: 0 its cast shadow, 1 its body, 2 its lit edge.
function lpw_rete_seg(_x1, _y1, _x2, _y2, _w, _pass, _sox, _soy) {
    if (_pass == 0) { lpw_seg(_x1 + _sox, _y1 + _soy, _x2 + _sox, _y2 + _soy, _w, c_black, 0.32); return; }
    if (_pass == 1) { lpw_seg(_x1, _y1, _x2, _y2, _w, lpw_brass(0.70)); return; }
    var _dx = _x2 - _x1, _dy = _y2 - _y1, _l = sqrt(_dx * _dx + _dy * _dy);
    if (_l <= 0) return;
    var _nx = -_dy / _l, _ny = _dx / _l, _f = _nx * -0.6 + _ny * -0.8;
    if (_f < 0) { _nx = -_nx; _ny = -_ny; _f = -_f; }
    lpw_seg(_x1 + _nx * _w * 0.25, _y1 + _ny * _w * 0.25, _x2 + _nx * _w * 0.25, _y2 + _ny * _w * 0.25, max(1, _w * 0.3), lpw_brass(0.98), 0.35 + 0.6 * _f);
}

/// @function lpw_rete_ring(cx, cy, r, w, pass, sox, soy)
/// @description One ring of the rete in one pass. The lit edge is the same ring shifted toward the lamp: that puts
/// light on the OUTER edge at the upper left and the INNER edge at the lower right, as a raised round wire takes it.
function lpw_rete_ring(_cx, _cy, _r, _w, _pass, _sox, _soy) {
    if (_pass == 0) { lpw_arc(_cx + _sox, _cy + _soy, _r, 0, 2 * pi, _w, c_black, 0.32); return; }
    if (_pass == 1) { lpw_arc(_cx, _cy, _r, 0, 2 * pi, _w, lpw_brass(0.70)); return; }
    lpw_arc(_cx - _w * 0.12, _cy - _w * 0.16, _r, 0, 2 * pi, max(1, _w * 0.3), lpw_brass(0.98), 0.85);
}

/// @function lpw_pin_draw(x, y, a, s)
/// @description A struck divergence pin: a faceted blued-steel lozenge `s` in half-length, long axis along the
/// radius at angle `a`, each of its four facets lit by how squarely it faces the lamp.
function lpw_pin_draw(_px, _py, _a, _s) {
    var _ca = cos(_a), _sa = sin(_a), _w = _s * 0.62;
    var _v = [_px + _ca * _s, _py + _sa * _s, _px - _sa * _w, _py + _ca * _w, _px - _ca * _s, _py - _sa * _s, _px + _sa * _w, _py - _ca * _w];
    lpw_fill_convex([_v[0] + _s * 0.25, _v[1] + _s * 0.35, _v[2] + _s * 0.25, _v[3] + _s * 0.35, _v[4] + _s * 0.25, _v[5] + _s * 0.35, _v[6] + _s * 0.25, _v[7] + _s * 0.35], c_black, 0.38);
    for (var _j = 0; _j < 4; _j++) {
        var _k = (_j + 1) mod 4;
        var _mx = (_v[_j * 2] + _v[_k * 2]) * 0.5 - _px, _my = (_v[_j * 2 + 1] + _v[_k * 2 + 1]) * 0.5 - _py;
        var _ml = max(0.0001, sqrt(_mx * _mx + _my * _my));
        var _f = (_mx / _ml) * -0.6 + (_my / _ml) * -0.8;
        lpw_fill_convex([_px, _py, _v[_j * 2], _v[_j * 2 + 1], _v[_k * 2], _v[_k * 2 + 1]], lpw_blued(0.5 + 0.45 * _f));
    }
    lpw_polyline(_v, max(1, _s * 0.08), lpw_blued(0.04), 0.9, true);
}

/// @function lpw_astrolabe_draw(state, x, y, radius, [turn], [reveal])
/// @description Draw the whole instrument for a loop record. Returns {rings, pins, stars} (pins = pins DRAWN, which
/// `reveal` can hold back) or undefined. Never throws.
function lpw_astrolabe_draw(_st, _x, _y, _r, _turn = 0, _reveal = 1) {
    static _ROM = ["XII", "I", "II", "III", "IIII", "V", "VI", "VII", "VIII", "IX", "X", "XI"];
    var _L = lpw_astrolabe_layout(_st, _x, _y, _r, _turn, _reveal);
    if (is_undefined(_L)) return undefined;
    var _i, _a, _u = _r / 300, _pass;
    // ---- the plate: cast shadow, body, and a rim band shaded by normal against the lamp (upper left)
    lpw_disc(_x + _r * 0.03, _y + _r * 0.05, _r * 1.02, c_black, 0.35);
    lpw_disc(_x, _y, _r, lpw_brass(0.45));
    var _n = 144;
    for (_i = 0; _i < _n; _i++) {
        var _a0 = _i / _n * 2 * pi, _a1 = (_i + 1) / _n * 2 * pi, _am = (_a0 + _a1) / 2;
        var _c = lpw_brass(0.5 + (cos(_am) * -0.6 + sin(_am) * -0.8) * 0.45);
        draw_primitive_begin(pr_trianglestrip);
        draw_vertex_colour(_x + cos(_a0) * _r, _y + sin(_a0) * _r, _c, 1); draw_vertex_colour(_x + cos(_a0) * _r * 0.9, _y + sin(_a0) * _r * 0.9, _c, 1);
        draw_vertex_colour(_x + cos(_a1) * _r, _y + sin(_a1) * _r, _c, 1); draw_vertex_colour(_x + cos(_a1) * _r * 0.9, _y + sin(_a1) * _r * 0.9, _c, 1);
        draw_primitive_end();
    }
    // the lamp's sheen, CLIPPED to the plate: as a free disc it reached past the rim and lit the page (seen on the
    // first bakes as a halo up and left of every instrument)
    var _disc = [];
    for (_i = 0; _i < 96; _i++) array_push(_disc, _x + cos(_i / 96 * 2 * pi) * _r * 0.995, _y + sin(_i / 96 * 2 * pi) * _r * 0.995);
    lpw_glow_poly(_disc, _x, _y, _x - _r * 0.3, _y - _r * 0.35, _r * 0.95, lpw_brass(1), 0.28);
    // ---- the clock limb: 60 ticks running OUTWARD from the limb ring, every fifth long, and the twelve hours in their
    // own band between two engraved rings. ⚠️ The hours sit at the SAME angles as the long ticks, so at a shared radius
    // every long tick struck through its numeral (seen on the first ledger bake).
    var _lr = _r * 0.845;
    lpw_engrave_ring(_x, _y, _lr, max(1, 2.2 * _u));
    lpw_engrave_ring(_x, _y, _r * 0.715, max(1, 1.6 * _u));
    for (_i = 0; _i < 60; _i++) {
        _a = _i / 60 * 2 * pi - pi / 2;
        var _long = (_i mod 5 == 0);
        lpw_seg(_x + cos(_a) * _lr, _y + sin(_a) * _lr, _x + cos(_a) * _r * (_long ? 0.895 : 0.875), _y + sin(_a) * _r * (_long ? 0.895 : 0.875), max(1, (_long ? 2.4 : 1.4) * _u), lpw_brass(0.1));
    }
    for (_i = 0; _i < 12; _i++) {
        _a = _i / 12 * 2 * pi - pi / 2;
        lpw_text(_x + cos(_a) * _r * 0.78, _y + sin(_a) * _r * 0.78, _ROM[_i], 22 * _u, lpw_brass(0.08), fa_center, fa_middle, fnt_loopwork_title, 1, _r * 0.125);
    }
    // ---- the loop rings: engraved, the live one inlaid in blued steel and cut round as far as `reveal`
    var _sweep = _L.reveal * 2 * pi;
    for (_i = 0; _i < array_length(_L.rings); _i++) {
        var _rg = _L.rings[_i];
        if (_rg.live) {
            if (_sweep > 0) {
                lpw_engrave_arc(_x, _y, _rg.rr, -pi / 2, -pi / 2 + _sweep, max(1.5, 4.6 * _u));
                lpw_arc(_x, _y, _rg.rr, -pi / 2, -pi / 2 + _sweep, max(1, 2.8 * _u), lpw_blued(0.5));
                lpw_arc(_x - 0.5 * _u, _y - 0.6 * _u, _rg.rr, -pi / 2, -pi / 2 + _sweep, max(1, 0.9 * _u), lpw_blued(0.95), 0.8);
            }
        } else lpw_engrave_ring(_x, _y, _rg.rr, max(1, 1.8 * _u));
    }
    // ---- the pins, struck into the PLATE, so they sit under the rete (the first bakes drew them on top, and a pin
    // lay across a star's jewel); held back on the live ring until the cut reaches them
    var _ps = max(4, 10 * _u), _drawn = 0;
    for (_i = 0; _i < array_length(_L.pins); _i++) {
        var _pn = _L.pins[_i];
        if (_pn.live) {
            var _q = _pn.a + pi / 2;
            if (_q >= 2 * pi) _q -= 2 * pi;
            if (_q > _sweep) continue;
        }
        lpw_pin_draw(_pn.x, _pn.y, _pn.a, _ps);
        _drawn++;
    }
    // ---- the rete: every member's shadow first (so no shadow lies across another member), then bodies, then lit edges
    var _sox = _r * 0.012, _soy = _r * 0.018, _rw = _r * 0.024, _ew = _r * 0.034, _bw = _r * 0.016;
    var _sw = max(1, _r * 0.011), _ww = max(1, _r * 0.007), _hw = _r * 0.017, _st2, _p;
    for (_pass = 0; _pass < 3; _pass++) {
        lpw_rete_ring(_x, _y, _L.rete_r, _rw, _pass, _sox, _soy);
        lpw_rete_ring(_L.ecliptic.x, _L.ecliptic.y, _L.ecliptic.r, _ew, _pass, _sox, _soy);
        for (_i = 0; _i < array_length(_L.bars); _i++) lpw_rete_seg(_L.bars[_i][0], _L.bars[_i][1], _L.bars[_i][2], _L.bars[_i][3], _bw, _pass, _sox, _soy);
        for (_i = 0; _i < array_length(_L.stars); _i++) {
            _st2 = _L.stars[_i];
            if (_st2.strut) lpw_rete_seg(_st2.nx, _st2.ny, _st2.bx, _st2.by, _sw, _pass, _sox, _soy);
        }
        for (_i = 0; _i < array_length(_L.links); _i++) {
            var _sa = _L.stars[_L.links[_i][0]], _sb = _L.stars[_L.links[_i][1]];
            lpw_rete_seg(_sa.x, _sa.y, _sb.x, _sb.y, _ww, _pass, _sox, _soy);
        }
        for (_i = 0; _i < array_length(_L.stars); _i++) {
            _st2 = _L.stars[_i];
            if (!_st2.pointer) continue;
            _p = lpw_flame_pts(_st2.bx, _st2.by, _st2.x, _st2.y, _hw, _st2.bend);
            if (_pass == 0) lpw_fill_poly(lpw_scale_pts(_p, 0, 0, 1, _sox, _soy), c_black, 0.32);
            else if (_pass == 1) lpw_fill_poly(_p, lpw_brass(0.74));
            else lpw_polyline(_p, max(1, _r * 0.003), lpw_brass(0.98), 0.7, true);
        }
    }
    // the ecliptic's scale: a tick every ten degrees, every thirtieth long - it turns with the rete
    for (_i = 0; _i < 36; _i++) {
        _a = _L.turn + _i / 36 * 2 * pi;
        var _t0 = (_i mod 3 == 0) ? 0.46 : 0.30;
        lpw_seg(_L.ecliptic.x + cos(_a) * (_L.ecliptic.r - _ew * _t0), _L.ecliptic.y + sin(_a) * (_L.ecliptic.r - _ew * _t0),
                _L.ecliptic.x + cos(_a) * (_L.ecliptic.r + _ew * _t0), _L.ecliptic.y + sin(_a) * (_L.ecliptic.r + _ew * _t0), max(1, _r * 0.0035), lpw_brass(0.28));
    }
    // ---- the jewels: every known fact, set in the wax colour of the loop it was learned in
    var _jr = max(2, _r * 0.021);
    for (_i = 0; _i < array_length(_L.stars); _i++) {
        _st2 = _L.stars[_i];
        lpw_disc(_st2.x + _jr * 0.3, _st2.y + _jr * 0.4, _jr * 1.05, c_black, 0.35);
        lpw_disc(_st2.x, _st2.y, _jr, merge_colour(_st2.wax, c_black, 0.15));
        lpw_disc(_st2.x - _jr * 0.12, _st2.y - _jr * 0.15, _jr * 0.72, _st2.wax);
        lpw_arc(_st2.x, _st2.y, _jr, 0, 2 * pi, max(1, _jr * 0.22), lpw_brass(0.35));
        lpw_spot(_st2.x - _jr * 0.3, _st2.y - _jr * 0.35, _jr * 0.6, c_white, 0.75);
    }
    // ---- the boss: a raised disc carrying the live loop number
    var _br = _r * LPW_ASTRO_BOSS;
    lpw_disc(_x + _br * 0.1, _y + _br * 0.14, _br, c_black, 0.3);
    lpw_disc(_x, _y, _br, lpw_brass(0.62));
    lpw_arc(_x, _y, _br * 0.9, 0, 2 * pi, max(1, 2 * _u), lpw_brass(0.2));
    lpw_arc(_x - _br * 0.03, _y - _br * 0.04, _br * 0.97, pi, 1.5 * pi, max(1, 1.2 * _u), lpw_brass(0.95), 0.8);
    lpw_text(_x, _y + _br * 0.04, string(_L.live), _br * 1.3, lpw_brass(0.08), fa_center, fa_middle, fnt_loopwork_title, 1, _br * 1.6);
    return { rings: array_length(_L.rings), pins: _drawn, stars: array_length(_L.stars) };
}
