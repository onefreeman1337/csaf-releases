/// lpw_ledger.gml - the LOOP LEDGER screen: the astrolabe of the playthrough beside the seal of every fact the player
/// has kept, each captioned with its label and the loop it was learned in. Drop it into a pause menu or a journal.
///
/// Loopwork - A Time Loop That Remembers, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⭐ LAYOUT IS PURE AND SOLVED FROM THE RECT. The seal grid tries every column count and keeps the one that gives
/// the largest seal, so a ledger of 3 facts and one of 60 both fill the space they are given; nothing is placed by a
/// fixed pixel, and the suite asserts that every seal, caption and the instrument stay inside the rect.
/// ⚠️ Cost: it draws everything every call (a busy ledger is a few thousand primitives). For a static pause screen,
/// draw it once into a surface and show the surface; redraw only when the record changes or while animating.
///
/// PUBLIC API:
///   lpw_ledger_layout(state, x, y, w, h) -> {ax, ay, ar, cells, seal_r, captions, empty} (pure), or undefined
///   lpw_ledger_draw(state, x, y, w, h, [opts]) -> draws the screen; returns {rings, pins, stars, seals} or undefined
///     opts (all optional): { turn, reveal, ink, dim }
///       turn, reveal - passed to the astrolabe (animate a loop closing)
///       ink, dim     - caption colours; the defaults are pale parchment tones for a DARK screen

/// @function lpw_ledger_layout(state, x, y, w, h)
/// @description Where everything on the Ledger goes. cells[i] = {x, y, r, cap_y, cap_w, px, fact} is fact i's seal
/// centre, radius and caption line (captions is false when the seals are too small to caption). Pure.
function lpw_ledger_layout(_st, _x, _y, _w, _h) {
    if (!lpw_is_state(_st) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_h) || _w < 120 || _h < 80) return undefined;
    var _m = min(_w, _h) * 0.03;
    // the instrument: as large as the height allows, never more than just under half the width.
    // Its drawn extent is -1.0r .. +1.05r across and -1.0r .. +1.07r down (the cast shadow).
    var _ar = max(10, min((_h - 2 * _m) / 2.07, (_w * 0.5 - 2 * _m) / 2.05));
    var _ax = _x + _m + _ar;
    var _ay = _y + _m + _ar + max(0, (_h - 2 * _m - 2.07 * _ar) * 0.5);
    var _L = { ax: _ax, ay: _ay, ar: _ar, cells: [], seal_r: 0, captions: false, empty: true,
               gx: _ax + _ar * 1.05 + 2 * _m, gy: _y + _m };
    _L.gw = _x + _w - _m - _L.gx; _L.gh = _h - 2 * _m;
    var _facts = lpw_facts(_st), _n = array_length(_facts);
    if (_n == 0 || _L.gw < 20) return _L;
    _L.empty = false;
    // the grid: every column count tried, the largest seal wins
    var _best = { r: -1, c: 1, cw: 0, ch: 0, cap: 0, px: 0 };
    for (var _c = 1; _c <= _n; _c++) {
        var _rows = ceil(_n / _c), _cw = _L.gw / _c, _ch = _L.gh / _rows;
        // the caption: up to two label lines and the loop line beneath them
        var _px = clamp(_cw * 0.085, 9, 18), _cap = _px * 3.4;
        var _r = min(_cw * 0.42, (_ch - _cap) * 0.44);
        if (_r < 12) { _cap = 0; _r = min(_cw * 0.45, _ch * 0.44); }
        _r = min(_r, _ar * 0.30);
        if (_r > _best.r) _best = { r: _r, c: _c, cw: _cw, ch: _ch, cap: _cap, px: _px };
    }
    var _cols = _best.c, _nrows = ceil(_n / _cols), _sr = _best.r;
    // a small ledger does not spread its seals to the corners: each cell is only as large as its seal needs,
    // and the block is centred in the panel
    var _cwu = min(_best.cw, _sr * 2.7), _chu = min(_best.ch, _sr * 2.3 + _best.cap);
    var _ox = _L.gx + (_L.gw - _cwu * _cols) * 0.5, _oy = _L.gy + (_L.gh - _chu * _nrows) * 0.5;
    _L.seal_r = _sr; _L.captions = (_best.cap > 0);
    for (var _i = 0; _i < _n; _i++) {
        var _cx = _ox + ((_i mod _cols) + 0.5) * _cwu;
        var _cy = _oy + (_i div _cols) * _chu + (_chu - _best.cap) * 0.5 - _sr * 0.05;
        array_push(_L.cells, { x: _cx, y: _cy, r: _sr, cap_y: _cy + _sr * 1.14, cap_w: _cwu * 0.94, cap_h: _best.cap, px: _best.px, fact: _facts[_i] });
    }
    return _L;
}

/// @function lpw_ledger_wrap(text, px, maxw)
/// @description A caption as one line if it fits `maxw` at `px`, otherwise as two lines split at the word that makes
/// the longer line shortest. (A single word too long for the cell stays one line and lpw_text shrinks it.) Pure but
/// for the font it sets and restores.
function lpw_ledger_wrap(_s, _px, _maxw) {
    if (lpw_text_w(_s, _px) <= _maxw) return [_s];
    var _w = string_split(_s, " ", true), _n = array_length(_w);
    if (_n < 2) return [_s];
    var _best = [_s], _bw = 1000000;
    for (var _i = 1; _i < _n; _i++) {
        var _a = "", _b = "", _j;
        for (_j = 0; _j < _i; _j++) _a += ((_j > 0) ? " " : "") + _w[_j];
        for (_j = _i; _j < _n; _j++) _b += ((_j > _i) ? " " : "") + _w[_j];
        var _m = max(lpw_text_w(_a, _px), lpw_text_w(_b, _px));
        if (_m < _bw) { _bw = _m; _best = [_a, _b]; }
    }
    return _best;
}

/// @function lpw_ledger_draw(state, x, y, w, h, [opts])
/// @description Draw the Ledger into the rect. Returns {rings, pins, stars, seals} or undefined. Never throws.
function lpw_ledger_draw(_st, _x, _y, _w, _h, _opts = undefined) {
    var _L = lpw_ledger_layout(_st, _x, _y, _w, _h);
    if (is_undefined(_L)) return undefined;
    var _turn = 0, _rev = 1, _ink = make_colour_rgb(226, 210, 178), _dim = make_colour_rgb(156, 138, 108);
    if (is_struct(_opts)) {
        if (variable_struct_exists(_opts, "turn") && is_numeric(_opts.turn)) _turn = _opts.turn;
        if (variable_struct_exists(_opts, "reveal") && is_numeric(_opts.reveal)) _rev = _opts.reveal;
        if (variable_struct_exists(_opts, "ink") && is_numeric(_opts.ink)) _ink = _opts.ink;
        if (variable_struct_exists(_opts, "dim") && is_numeric(_opts.dim)) _dim = _opts.dim;
    }
    var _res = lpw_astrolabe_draw(_st, _L.ax, _L.ay, _L.ar, _turn, _rev);
    if (is_undefined(_res)) _res = { rings: 0, pins: 0, stars: 0 };
    _res.seals = 0;
    if (_L.empty) {
        lpw_text(_L.gx + _L.gw * 0.5, _L.gy + _L.gh * 0.5, "Nothing is known yet.", clamp(_L.gw * 0.05, 12, 30), _dim, fa_center, fa_middle, fnt_loopwork, 1, _L.gw * 0.9);
        return _res;
    }
    var _specs = lpw_seal_specs(_st);
    for (var _i = 0; _i < array_length(_L.cells); _i++) {
        var _cl = _L.cells[_i];
        if (_i >= array_length(_specs)) break;
        lpw_seal_draw_spec(_specs[_i], _cl.x, _cl.y, _cl.r);
        _res.seals++;
        if (_L.captions) {
            // the label as the author wrote it, on two lines before it is ever shrunk: squeezed onto one line, a
            // sentence-long fact drew about 7 px tall on the demo screen (seen on its first photograph)
            var _lines = lpw_ledger_wrap(string(_cl.fact.label), _cl.px, _cl.cap_w);
            for (var _k = 0; _k < array_length(_lines); _k++) lpw_text(_cl.x, _cl.cap_y + _k * _cl.px * 1.08, _lines[_k], _cl.px, _ink, fa_center, fa_top, fnt_loopwork, 1, _cl.cap_w);
            lpw_text(_cl.x, _cl.cap_y + array_length(_lines) * _cl.px * 1.08 + _cl.px * 0.1, "LOOP " + string(_cl.fact.loop), _cl.px * 0.8, _dim, fa_center, fa_top, fnt_loopwork, 1, _cl.cap_w);
        }
    }
    return _res;
}
