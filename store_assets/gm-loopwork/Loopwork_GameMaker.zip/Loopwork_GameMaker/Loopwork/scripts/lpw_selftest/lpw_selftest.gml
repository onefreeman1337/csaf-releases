/// lpw_selftest.gml - the in-engine suite (`Loopwork.exe -selftest` writes lpw_selftest.json).
///
/// Loopwork - A Time Loop That Remembers, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Stage 99 = the suite reached its end.
/// SESSION 1 SCOPE: the pure engine. Reals are compared as INTEGERS (value * 10^6, floored): GML applies an epsilon
/// of 0.00001 to every comparison, so a fine tolerance written as a real is false for every value.

function lpw_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 60) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
function lpw_st_stage(_st, _n) { _st.stage = _n; global.lpw_stage = _n; }
function lpw_st_note(_st, _s) { array_push(_st.notes, _s); }
function lpw_st_micro(_v) { return floor(_v * 1000000 + 0.5); }

function lpw_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, failures: [], stage: 0, notes: [] }, _i;

    lpw_st_stage(_st, 1);    // the hash, against exact FNV-1a (and the MZ plugin's hash32, which is the same)
    lpw_st_assert(_st, lpw_hash("") == 2166136261 && lpw_hash("a") == 3826002220, "FNV-1a of '' and 'a'");
    lpw_st_assert(_st, lpw_hash("mayor-lies") == 1433561029, "hash('mayor-lies') matches the MZ plugin: " + string(lpw_hash("mayor-lies")));
    lpw_st_assert(_st, lpw_hash("The quick brown fox jumps over the lazy dog") == 76545936, "the 43-character FNV-1a vector: " + string(lpw_hash("The quick brown fox jumps over the lazy dog")));

    lpw_st_stage(_st, 2);    // facts
    var _s = lpw_create();
    lpw_st_assert(_st, lpw_is_state(_s) && lpw_loop(_s) == 1 && array_length(lpw_facts(_s)) == 0, "a fresh record is loop 1 and knows nothing");
    lpw_st_assert(_st, lpw_learn(_s, "mayor-lies", "The mayor lies about the flood") && !lpw_learn(_s, "mayor-lies"), "learning is idempotent: the second learn reports not-new");
    lpw_st_assert(_st, lpw_knows(_s, "  mayor-lies  ") && !lpw_knows(_s, "nobody"), "ids are trimmed; an unknown id is unknown");
    lpw_st_assert(_st, !lpw_learn(_s, "") && !lpw_learn(_s, "   ") && !lpw_learn(_s, undefined), "an empty or undefined id is refused, not learned");
    lpw_st_assert(_st, lpw_fact_loop(_s, "mayor-lies") == 1 && lpw_learned_this_loop(_s, "mayor-lies"), "a fact remembers the loop it was learned in");

    lpw_st_stage(_st, 3);    // divergences and loops
    lpw_st_assert(_st, lpw_diverge(_s, "took-the-boat") && !lpw_diverge(_s, "took-the-boat"), "a divergence counts once per loop");
    var _r1 = lpw_close_loop(_s, "drowned");
    lpw_st_assert(_st, is_struct(_r1) && _r1.index == 1 && _r1.facts == 1 && _r1.pins == 1 && lpw_loop(_s) == 2, "closing loop 1 records 1 fact, 1 pin, and starts loop 2");
    lpw_st_assert(_st, lpw_diverge(_s, "took-the-boat") && array_length(lpw_divergences(_s, 2)) == 1 && array_length(lpw_divergences(_s, 1)) == 1, "the same divergence is recorded again in a NEW loop");
    lpw_learn(_s, "mayor-lies");
    lpw_st_assert(_st, lpw_fact_loop(_s, "mayor-lies") == 1 && !lpw_learned_this_loop(_s, "mayor-lies"), "re-learning in loop 2 does not rewrite history: still loop 1");
    lpw_st_assert(_st, lpw_diverged(_s, "took-the-boat") && !lpw_diverged(_s, "never-did"), "diverged() answers across all loops");
    var _cap = lpw_create();
    for (_i = 0; _i < 50; _i++) lpw_close_loop(_cap, "x", 40);
    lpw_st_assert(_st, array_length(lpw_history(_cap)) == 40 && lpw_loop(_cap) == 51 && lpw_history(_cap)[0].index == 11, "history is trimmed to 40 but the COUNTER is not (51, oldest kept is loop 11)");

    lpw_st_stage(_st, 4);    // the anchor and the rewind PLAN
    var _w = lpw_create();
    lpw_st_assert(_st, array_length(lpw_plan_rewind(_w, ["door"]).restore) == 0, "no anchor, no plan");
    var _kept = lpw_anchor(_w, [["door", false], ["bell_rung", 0], ["gold", 12], ["lamp_lit", true], "not a pair", [""]]);
    lpw_st_assert(_st, _kept == 4, "the anchor keeps the four real pairs and skips the malformed ones: " + string(_kept));
    var _plan = lpw_plan_rewind(_w, ["door", "bell_rung", "lamp_lit"], ["lamp_lit", "gold"]);
    var _names = "";
    for (_i = 0; _i < array_length(_plan.restore); _i++) _names += _plan.restore[_i][0] + ",";
    lpw_st_assert(_st, _names == "door,bell_rung,", "the plan restores the world names only: " + _names);
    lpw_st_assert(_st, array_length(_plan.skipped) == 2 && _plan.skipped[0] == "gold" && _plan.skipped[1] == "lamp_lit", "a CARRIED name wins over a world name (lamp_lit) and is reported skipped");
    lpw_st_assert(_st, _plan.restore[0][1] == false && _plan.restore[1][1] == 0, "the plan carries the ANCHORED values");
    lpw_st_assert(_st, array_length(lpw_plan_rewind(_w, "not an array").restore) == 0, "a non-array world list restores nothing rather than throwing");

    lpw_st_stage(_st, 5);    // save and load, migrated every time
    var _txt = lpw_save(_s), _back = lpw_load(_txt);
    lpw_st_assert(_st, lpw_is_state(_back) && lpw_loop(_back) == 2 && lpw_knows(_back, "mayor-lies") && lpw_fact_loop(_back, "mayor-lies") == 1, "a record survives save and load");
    lpw_st_assert(_st, lpw_loop(lpw_load("not json {")) == 1 && lpw_loop(lpw_load("")) == 1 && lpw_loop(lpw_load(undefined)) == 1, "an unreadable save loads as a fresh record, never a crash");
    var _old = lpw_load("{\"facts\":[{\"id\":\"a\",\"loop\":2},{\"label\":\"no id\"}],\"loop_index\":3}");
    lpw_st_assert(_st, lpw_is_state(_old) && _old.version == 1 && lpw_knows(_old, "a") && array_length(_old.facts) == 1 && is_array(_old.diverged) && lpw_loop(_old) == 3, "a version-0 record is migrated: missing arrays filled, an id-less fact dropped");

    lpw_st_stage(_st, 6);    // the constellation, against the MZ plugin's own numbers
    var _c = lpw_create();
    lpw_learn(_c, "mayor-lies"); lpw_learn(_c, "flood-gate"); lpw_learn(_c, "bell-code"); lpw_learn(_c, "river-key");
    var _n = lpw_constellation(_c);
    var _want = [[900000, 282139], [100000, 900000], [542740, 100000], [177217, 349472]], _ok = 0, _got = "";
    for (_i = 0; _i < 4; _i++) {
        var _mx = lpw_st_micro(_n[_i].x), _my = lpw_st_micro(_n[_i].y);
        _got += string(_mx) + "," + string(_my) + " ";
        if (abs(_mx - _want[_i][0]) <= 1 && abs(_my - _want[_i][1]) <= 1) _ok++;
    }
    lpw_st_assert(_st, _ok == 4, "the constellation lays out exactly as the MZ plugin does (micro-units): " + _got);
    var _big = lpw_create();
    for (_i = 0; _i < 30; _i++) lpw_learn(_big, "fact-" + string(_i));
    var _bn = lpw_constellation(_big), _inside = true, _mind = 1;
    for (_i = 0; _i < 30; _i++) {
        if (_bn[_i].x < 0.0999 || _bn[_i].x > 0.9001 || _bn[_i].y < 0.0999 || _bn[_i].y > 0.9001) _inside = false;
        for (var _j = _i + 1; _j < 30; _j++) _mind = min(_mind, point_distance(_bn[_i].x, _bn[_i].y, _bn[_j].x, _bn[_j].y));
    }
    lpw_st_note(_st, "30-fact constellation: closest pair " + string_format(_mind, 1, 4));
    lpw_st_assert(_st, _inside, "every star sits inside the 0.10..0.90 box");
    lpw_st_assert(_st, _mind > 0.02, "thirty stars are pushed apart (closest " + string_format(_mind, 1, 4) + ")");
    var _links = lpw_constellation_links(_n);
    lpw_st_assert(_st, array_length(_links) == 6, "four facts from one loop give six same-loop links: " + string(array_length(_links)));
    lpw_st_assert(_st, array_length(lpw_constellation(undefined)) == 0 && array_length(lpw_constellation_links("x")) == 0, "refusals: a non-state lays out nothing");

    lpw_st_stage(_st, 7);    // the seal corpus: VOLUME measured on the PIXELS, every seal in ONE wax so colour cannot inflate it
    var _ids = lpw_bake_seal_ids(), _sf = surface_create(128, 128), _sf2 = surface_create(128, 128), _sigs = [], _seen = {}, _distinct = 0;
    // the CONTROL: raw per-id recipes DO collide (the birthday problem), which is the defect the ledger assignment fixes
    var _raw = {}, _rawd = 0;
    for (_i = 0; _i < array_length(_ids); _i++) { var _rs = lpw_seal_spec(_ids[_i], 1), _rk = _rs.outline + _rs.border + _rs.device; if (!variable_struct_exists(_raw, _rk)) { _raw[$ _rk] = 1; _rawd++; } }
    lpw_st_note(_st, "raw per-id recipes: " + string(_rawd) + " distinct of 48 (the collision the ledger assignment removes)");
    lpw_st_assert(_st, _rawd < 48, "control: hashing alone collides on this corpus, so the assignment below is doing real work (" + string(_rawd) + ")");
    var _ledger = lpw_create();
    for (_i = 0; _i < array_length(_ids); _i++) lpw_learn(_ledger, _ids[_i]);
    var _specs = lpw_seal_specs(_ledger);
    lpw_st_assert(_st, array_length(_specs) == 48, "one recipe per fact in the ledger");
    for (_i = 0; _i < array_length(_ids); _i++) {
        surface_set_target(_sf); draw_clear(c_black); lpw_seal_draw_spec(_specs[_i], 64, 64, 54); surface_reset_target();
        var _g = lpw_st_levels(_sf, 128, 16);
        array_push(_sigs, _g);
        if (!variable_struct_exists(_seen, _g)) { _seen[$ _g] = 1; _distinct++; }
    }
    var _minp = 9999, _pair = "";
    for (_i = 0; _i < array_length(_sigs); _i++) for (var _q = _i + 1; _q < array_length(_sigs); _q++) {
        var _d = lpw_st_hamming(_sigs[_i], _sigs[_q]);
        if (_d < _minp) { _minp = _d; _pair = _ids[_i] + "/" + _ids[_q]; }
    }
    // the noise floor, MEASURED: one seal against itself drawn one pixel over. Two different seals must differ more.
    surface_set_target(_sf); draw_clear(c_black); lpw_seal_draw_spec(_specs[0], 65, 64, 54); surface_reset_target();
    var _noise = lpw_st_hamming(_sigs[0], lpw_st_levels(_sf, 128, 16));
    surface_set_target(_sf); draw_clear(c_black); lpw_seal_draw_spec(_specs[0], 64, 64, 54); surface_reset_target();
    var _same = lpw_st_hamming(_sigs[0], lpw_st_levels(_sf, 128, 16));
    surface_free(_sf);
    var _axes = { o: {}, b: {}, d: {} }, _no = 0, _nb = 0, _nd = 0;
    for (_i = 0; _i < array_length(_ids); _i++) {
        var _sp = _specs[_i];
        if (!variable_struct_exists(_axes.o, _sp.outline)) { _axes.o[$ _sp.outline] = 1; _no++; }
        if (!variable_struct_exists(_axes.b, _sp.border)) { _axes.b[$ _sp.border] = 1; _nb++; }
        if (!variable_struct_exists(_axes.d, _sp.device)) { _axes.d[$ _sp.device] = 1; _nd++; }
    }
    lpw_st_note(_st, "48 seals: " + string(_distinct) + " distinct pictures; closest pair " + _pair + " at " + string(_minp) + " of 256 cells; one-pixel noise floor " + string(_noise) + "; axes used " + string(_no) + "/8 outlines " + string(_nb) + "/6 borders " + string(_nd) + "/8 devices");
    lpw_st_assert(_st, _same == 0, "control: the same seal struck twice is the same picture");
    lpw_st_assert(_st, _distinct == 48, "forty-eight facts strike forty-eight different seals (" + string(_distinct) + ")");
    // ⚠️ THE GRID ABOVE MEASURES SILHOUETTE, NOT DEVICE: averaging each 8x8 cell to four levels erases a stroked
    // device, while a one-pixel nudge moves every edge across a cell boundary - so its "noise floor" was edge density.
    // It is REPORTED, not asserted. The asserted comparison is PER PIXEL (64x64 luminance, |difference| > 40), where a
    // nudge moves only the edges and a different device moves its whole stroke.
    var _lums = [];
    for (_i = 0; _i < array_length(_ids); _i++) {
        surface_set_target(_sf2); draw_clear(c_black); lpw_seal_draw_spec(_specs[_i], 64, 64, 54); surface_reset_target();
        array_push(_lums, lpw_st_lum(_sf2));
    }
    surface_set_target(_sf2); draw_clear(c_black); lpw_seal_draw_spec(_specs[0], 65, 64, 54); surface_reset_target();
    var _nudge = lpw_st_lum(_sf2);
    var _pnoise = lpw_st_pixdiff(_lums[0], _nudge), _pmin = 99999, _ppair = "";
    for (_i = 0; _i < array_length(_lums); _i++) for (var _q2 = _i + 1; _q2 < array_length(_lums); _q2++) {
        var _pd = lpw_st_pixdiff(_lums[_i], _lums[_q2]);
        if (_pd < _pmin) { _pmin = _pd; _ppair = _ids[_i] + "/" + _ids[_q2]; }
    }
    for (_i = 0; _i < array_length(_lums); _i++) buffer_delete(_lums[_i]);
    buffer_delete(_nudge);
    surface_free(_sf2);
    lpw_st_note(_st, "per-pixel: closest pair " + _ppair + " at " + string(_pmin) + " of 4096 pixels; one-pixel nudge " + string(_pnoise) + "; silhouette grid closest " + string(_minp) + " vs nudge " + string(_noise));
    lpw_st_assert(_st, _pmin > _pnoise, "every two seals differ, pixel for pixel, by more than one seal nudged a pixel (closest " + string(_pmin) + " vs " + string(_pnoise) + ")");
    lpw_st_assert(_st, _no == 8 && _nb == 6 && _nd == 8, "the 48-fact corpus reaches every outline, border and device");
    var _a = lpw_seal_spec("mayor-lies", 3), _b = lpw_seal_spec("mayor-lies", 3);
    lpw_st_assert(_st, _a.outline == _b.outline && _a.device == _b.device && _a.wax == "cobalt", "a seal is deterministic and loop 3 strikes it in cobalt");
    lpw_st_assert(_st, lpw_seal_draw("", 1, 0, 0, 10) == undefined && lpw_seal_draw("x", 1, "a", 0, 10) == undefined, "refusals: an empty id, a non-number position");

    lpw_st_stage(_st, 8);    // the astrolabe: its layout is PURE, so the geometry is asserted directly
    var _p = lpw_create(), _divs = 0, _k;
    for (_i = 0; _i < 6; _i++) {
        for (_k = 0; _k < 1 + (_i mod 3); _k++) lpw_learn(_p, _ids[(_i * 5 + _k) mod 48]);
        for (_k = 0; _k < (_i * 2) mod 5; _k++) { if (lpw_diverge(_p, "choice-" + string(_k * 7 + _i))) _divs++; }
        if (_i < 5) lpw_close_loop(_p, "rewound");
    }
    if (lpw_diverge(_p, "live-choice")) _divs++;
    var _AL = lpw_astrolabe_layout(_p, 200, 200, 150);
    lpw_st_assert(_st, is_struct(_AL) && array_length(_AL.rings) == array_length(lpw_history(_p)) + 1, "one ring per loop kept plus the live one: " + string(is_struct(_AL) ? array_length(_AL.rings) : -1));
    var _nlive = 0, _outer = true;
    for (_i = 0; _i < array_length(_AL.rings); _i++) if (_AL.rings[_i].live) { _nlive++; if (_i != array_length(_AL.rings) - 1) _outer = false; }
    lpw_st_assert(_st, _nlive == 1 && _outer, "exactly one live ring, and it is the outermost");
    lpw_st_assert(_st, _divs == 11 && array_length(_AL.pins) == _divs, "one pin per divergence: " + string(array_length(_AL.pins)) + " of " + string(_divs));
    var _onring = true;
    for (_i = 0; _i < array_length(_AL.pins); _i++) if (abs(point_distance(200, 200, _AL.pins[_i].x, _AL.pins[_i].y) - _AL.pins[_i].rr) > 0.01) _onring = false;
    lpw_st_assert(_st, _onring, "every pin sits on its own loop's ring");
    var _band = true, _dmin = 1000, _dmax = 0;
    for (_i = 0; _i < array_length(_AL.stars); _i++) {
        var _sd = point_distance(200, 200, _AL.stars[_i].x, _AL.stars[_i].y);
        _dmin = min(_dmin, _sd); _dmax = max(_dmax, _sd);
        if (_sd < 150 * (LPW_ASTRO_BOSS + 0.03) || _sd > 150 * (LPW_ASTRO_RETE - 0.03)) _band = false;
    }
    lpw_st_assert(_st, array_length(_AL.stars) == 12, "one star per known fact: " + string(array_length(_AL.stars)));
    lpw_st_assert(_st, _band, "every star sits between the boss and the rete ring (" + string_format(_dmin, 1, 1) + " .. " + string_format(_dmax, 1, 1) + " at r 150)");
    var _wantl = 0;
    for (_i = 0; _i < 6; _i++) _wantl += (1 + (_i mod 3)) - 1;
    lpw_st_assert(_st, array_length(_AL.links) == _wantl, "same-loop facts are chained, n-1 wires for n facts: " + string(array_length(_AL.links)) + " of " + string(_wantl));
    var _samel = true;
    for (_i = 0; _i < array_length(_AL.links); _i++) if (_AL.stars[_AL.links[_i][0]].loop != _AL.stars[_AL.links[_i][1]].loop) _samel = false;
    lpw_st_assert(_st, _samel, "every wire joins two facts of the SAME loop");
    var _held = true, _nptr = 0;
    for (_i = 0; _i < array_length(_AL.stars); _i++) {
        var _s0 = _AL.stars[_i];
        if (!_s0.pointer) continue;
        _nptr++;
        var _nb0 = lpw_rete_nearest(_AL, _s0.bx, _s0.by);
        if (!_s0.strut && _nb0[2] > 0.5) _held = false;
        if (_s0.strut && point_distance(_s0.bx, _s0.by, _s0.x, _s0.y) > 150 * LPW_ASTRO_POINTER + 0.01) _held = false;
    }
    lpw_st_assert(_st, _held && _nptr > 0, "every star's pointer stands on the rete or on a strut from it (" + string(_nptr) + " pointers)");
    var _T = lpw_astrolabe_layout(_p, 200, 200, 150, 1.0), _rot = true, _pinsame = true;
    for (_i = 0; _i < array_length(_T.stars); _i++) {
        var _da = arctan2(_T.stars[_i].y - 200, _T.stars[_i].x - 200) - arctan2(_AL.stars[_i].y - 200, _AL.stars[_i].x - 200);
        while (_da < 0) _da += 2 * pi;
        while (_da >= 2 * pi) _da -= 2 * pi;
        if (abs(_da - 1.0) > 0.001) _rot = false;
        if (abs(point_distance(200, 200, _T.stars[_i].x, _T.stars[_i].y) - point_distance(200, 200, _AL.stars[_i].x, _AL.stars[_i].y)) > 0.01) _rot = false;
    }
    for (_i = 0; _i < array_length(_T.pins); _i++) if (point_distance(_T.pins[_i].x, _T.pins[_i].y, _AL.pins[_i].x, _AL.pins[_i].y) > 0.01) _pinsame = false;
    lpw_st_assert(_st, _rot, "turning the rete rotates every star about the centre and moves none in or out");
    lpw_st_assert(_st, _pinsame, "the pins are on the PLATE: turning the rete does not move them");
    var _as = surface_create(400, 400);
    surface_set_target(_as); draw_clear_alpha(c_black, 0); surface_reset_target();
    var _blank = lpw_st_inkbox(_as, 400);
    surface_set_target(_as); draw_clear_alpha(c_black, 0); var _d1 = lpw_astrolabe_draw(_p, 200, 200, 150); surface_reset_target();
    var _box = lpw_st_inkbox(_as, 400);
    surface_set_target(_as); draw_clear_alpha(c_black, 0); var _d0 = lpw_astrolabe_draw(_p, 200, 200, 150, 0, 0); surface_reset_target();
    surface_free(_as);
    lpw_st_note(_st, "astrolabe ink at r 150: " + string(_box.px) + " px, box " + string(_box.x0) + "," + string(_box.y0) + " .. " + string(_box.x1) + "," + string(_box.y1));
    lpw_st_assert(_st, _blank.px == 0, "control: a cleared surface has no ink");
    lpw_st_assert(_st, _box.px > 20000, "the instrument puts ink down (" + string(_box.px) + " px)");
    lpw_st_assert(_st, _box.x0 >= 200 - 152 && _box.x1 <= 200 + 150 * 1.05 + 2 && _box.y0 >= 200 - 152 && _box.y1 <= 200 + 150 * 1.07 + 2, "the instrument stays inside its documented extent");
    lpw_st_assert(_st, is_struct(_d1) && _d1.pins == _divs && _d1.rings == array_length(_AL.rings) && _d1.stars == 12, "the drawn instrument reports what its layout holds");
    lpw_st_assert(_st, is_struct(_d0) && _d0.pins == _divs - 1, "reveal 0 holds back the live loop's pin until the cut reaches it (" + string(is_struct(_d0) ? _d0.pins : -1) + ")");
    lpw_st_assert(_st, is_undefined(lpw_astrolabe_layout(undefined, 0, 0, 100)) && is_undefined(lpw_astrolabe_draw(_p, 0, 0, 5)) && is_undefined(lpw_astrolabe_draw(_p, "x", 0, 100)), "refusals: a non-state, a tiny radius, a non-number position");
    var _L2 = lpw_astrolabe_layout(_p, 200, 200, 150, "spin", "all");
    lpw_st_assert(_st, is_struct(_L2) && _L2.turn == 0 && _L2.reveal == 1, "a non-number turn or reveal falls back to 0 and 1 rather than throwing");
    var _tr = lpw_create();
    for (_i = 0; _i < 50; _i++) { lpw_diverge(_tr, "c" + string(_i)); lpw_close_loop(_tr, "x", 40); }
    var _TL = lpw_astrolabe_layout(_tr, 200, 200, 150);
    lpw_st_assert(_st, array_length(_TL.rings) == 41 && array_length(_TL.pins) == 40, "a trimmed history draws the 40 kept loops plus the live one, and only their pins (" + string(array_length(_TL.rings)) + " rings, " + string(array_length(_TL.pins)) + " pins)");

    lpw_st_stage(_st, 9);    // the ledger: every seal, caption and the instrument inside the rect, 2 records x 3 rects
    var _rects = [[0, 0, 1280, 720], [40, 30, 900, 420], [10, 10, 640, 800]], _inside = true, _why = "";
    var _big2 = lpw_create();
    for (_i = 0; _i < 40; _i++) { lpw_learn(_big2, _ids[_i], string_upper(_ids[_i])); if (_i mod 6 == 5) lpw_close_loop(_big2); }
    var _recs = [_p, _big2];
    for (var _si = 0; _si < 2; _si++) for (var _ri = 0; _ri < 3; _ri++) {
        var _R = _rects[_ri], _LL = lpw_ledger_layout(_recs[_si], _R[0], _R[1], _R[2], _R[3]);
        if (!is_struct(_LL)) { _inside = false; _why += " no-layout"; continue; }
        if (_LL.ax - _LL.ar < _R[0] - 0.5 || _LL.ax + _LL.ar * 1.05 > _R[0] + _R[2] + 0.5 || _LL.ay - _LL.ar < _R[1] - 0.5 || _LL.ay + _LL.ar * 1.07 > _R[1] + _R[3] + 0.5) { _inside = false; _why += " astrolabe@" + string(_ri); }
        if (array_length(_LL.cells) != array_length(lpw_facts(_recs[_si]))) { _inside = false; _why += " cells@" + string(_ri); }
        for (var _ci = 0; _ci < array_length(_LL.cells); _ci++) {
            var _cc = _LL.cells[_ci];
            var _bot = _LL.captions ? _cc.cap_y + _cc.cap_h : _cc.y + _cc.r * 1.11;
            if (_cc.x - _cc.r < _R[0] || _cc.x + _cc.r * 1.07 > _R[0] + _R[2] || _cc.y - _cc.r < _R[1] || _bot > _R[1] + _R[3]) { _inside = false; _why += " seal" + string(_ci) + "@" + string(_ri); break; }
            if (_cc.x - _cc.r < _LL.ax + _LL.ar * 1.05) { _inside = false; _why += " over-astrolabe@" + string(_ri); break; }
        }
    }
    lpw_st_assert(_st, _inside, "every seal, caption and the instrument stay inside the ledger's rect, and no seal overlaps the instrument:" + _why);
    var _wr1 = lpw_ledger_wrap("The widow saw the mayor at the gate", 13, 120), _wr0 = lpw_ledger_wrap("Old map", 13, 120);
    var _wok = array_length(_wr1) == 2 && lpw_text_w(_wr1[0], 13) <= 120 && lpw_text_w(_wr1[1], 13) <= 120 && array_length(_wr0) == 1;
    lpw_st_assert(_st, _wok, "a sentence-long label wraps to two lines that each fit; a short one stays on one (" + string(array_length(_wr1)) + ")");
    var _L12 = lpw_ledger_layout(_p, 0, 0, 1280, 720);
    lpw_st_note(_st, "ledger of 12 facts at 1280x720: seal r " + string_format(_L12.seal_r, 1, 1) + ", captions " + string(_L12.captions));
    lpw_st_assert(_st, _L12.captions && _L12.seal_r >= 30, "a 12-fact ledger at 1280x720 gets CAPTIONED seals of a readable size (r " + string_format(_L12.seal_r, 1, 1) + ")");
    lpw_st_assert(_st, lpw_ledger_layout(lpw_create(), 0, 0, 1280, 720).empty && is_undefined(lpw_ledger_layout(_p, 0, 0, 50, 50)) && is_undefined(lpw_ledger_draw("x", 0, 0, 800, 600)), "refusals: an empty record lays out as empty; a tiny rect and a non-state are refused");
    var _ls = surface_create(640, 360);
    surface_set_target(_ls); draw_clear_alpha(c_black, 0);
    var _lr0 = lpw_ledger_draw(lpw_create(), 0, 0, 640, 360);
    var _lr1 = lpw_ledger_draw(_p, 0, 0, 640, 360, { turn: 0.5, reveal: 0.5, ink: c_white });
    surface_reset_target(); surface_free(_ls);
    lpw_st_assert(_st, is_struct(_lr0) && _lr0.seals == 0 && is_struct(_lr1) && _lr1.seals == 12, "the ledger draws an empty record and a full one, one seal per fact (" + string(is_struct(_lr1) ? _lr1.seals : -1) + ")");

    lpw_st_stage(_st, 10);   // containment of what was SEEN wrong on the first bakes
    // (a) the band and device sit on the face: every outline's band reaches (1.07 x band) inside the face's inradius
    var _O = lpw_seal_outlines(), _fits = true, _lozb = 1, _roundb = 0, _bands = "";
    for (_i = 0; _i < array_length(_O); _i++) {
        var _bs = lpw_seal_spec("fit-" + string(_i), 1);
        _bs.outline = _O[_i];
        var _bb = lpw_seal_band(_bs);
        var _face = lpw_inradius(lpw_scale_pts(lpw_seal_outline(_bs, 0, 0, 100), 0, 0, 0.84), 0, 0);
        _bands += _O[_i] + " " + string_format(_bb, 1, 3) + " ";
        if (_bb * 107 > _face + 0.01) _fits = false;
        if (_O[_i] == "lozenge") _lozb = _bb;
        if (_O[_i] == "round") _roundb = _bb;
    }
    lpw_st_note(_st, "band by outline: " + _bands);
    lpw_st_assert(_st, _fits, "every outline's border band stays on its face (" + _bands + ")");
    lpw_st_assert(_st, _roundb >= 0.659 && _lozb < 0.55, "vacuity: a round face keeps the full band and a lozenge's is measurably smaller (" + string_format(_lozb, 1, 3) + ")");
    // (b) no lamp light off the object: nothing brighter than the ground up and left of the rim, where the old free
    // spot lit the page. Down and right is the cast shadow, which is meant to be there.
    var _hs = surface_create(400, 400);
    surface_set_target(_hs); draw_clear(c_black); lpw_astrolabe_draw(_p, 200, 200, 150); surface_reset_target();
    var _halo = lpw_st_halo(_hs, 400, 200, 200, 151.5);
    var _hsp = lpw_seal_spec("halo-check", 1);
    _hsp.outline = "round";   // a shield's own corners stand outside its radius; a round seal's edge IS the radius
    surface_set_target(_hs); draw_clear(c_black); lpw_seal_draw_spec(_hsp, 200, 200, 120); surface_reset_target();
    var _shalo = lpw_st_halo(_hs, 400, 200, 200, 121.5);
    surface_free(_hs);
    lpw_st_assert(_st, _halo == 0, "the astrolabe lights nothing outside its rim toward the lamp (" + string(_halo) + " px)");
    lpw_st_assert(_st, _shalo == 0, "a seal lights nothing outside its rim toward the lamp (" + string(_shalo) + " px)");

    lpw_st_stage(_st, 99);
    return _st;
}

/// @function lpw_st_levels(surface, size, cells)
/// @description A cells x cells signature of a square surface: each cell's share of pixels brighter than the black
/// ground, quantised to four levels (a 1-bit grid saturates on a filled shape and measures only its silhouette).
function lpw_st_levels(_sf, _sz, _cells) {
    var _b = buffer_create(_sz * _sz * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    var _cw = _sz / _cells, _sig = "";
    for (var _r = 0; _r < _cells; _r++) for (var _c = 0; _c < _cells; _c++) {
        var _hit = 0, _tot = 0, _lum = 0;
        for (var _y = floor(_r * _cw); _y < floor((_r + 1) * _cw); _y++) for (var _x = floor(_c * _cw); _x < floor((_c + 1) * _cw); _x++) {
            var _o = (_y * _sz + _x) * 4;
            var _l = (buffer_peek(_b, _o, buffer_u8) + buffer_peek(_b, _o + 1, buffer_u8) + buffer_peek(_b, _o + 2, buffer_u8)) / 3;
            _tot++; _lum += _l;
        }
        var _m = _lum / max(1, _tot);   // mean brightness: the relief and the device both move it
        _sig += (_m < 12) ? "0" : ((_m < 45) ? "1" : ((_m < 80) ? "2" : "3"));
    }
    buffer_delete(_b);
    return _sig;
}

/// @function lpw_st_lum(surface)
/// @description A 64x64 luminance buffer of a 128x128 surface (every second pixel both ways).
function lpw_st_lum(_sf) {
    var _b = buffer_create(128 * 128 * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    var _out = buffer_create(4096, buffer_fixed, 1);
    for (var _y = 0; _y < 64; _y++) for (var _x = 0; _x < 64; _x++) {
        var _o = ((_y * 2) * 128 + _x * 2) * 4;
        buffer_poke(_out, _y * 64 + _x, buffer_u8, floor((buffer_peek(_b, _o, buffer_u8) + buffer_peek(_b, _o + 1, buffer_u8) + buffer_peek(_b, _o + 2, buffer_u8)) / 3));
    }
    buffer_delete(_b);
    return _out;
}

/// @function lpw_st_pixdiff(a, b)
/// @description How many of 4096 luminance samples differ by more than 40 levels.
function lpw_st_pixdiff(_a, _b) {
    var _n = 0;
    for (var _i = 0; _i < 4096; _i++) if (abs(buffer_peek(_a, _i, buffer_u8) - buffer_peek(_b, _i, buffer_u8)) > 40) _n++;
    return _n;
}

/// @function lpw_st_inkbox(surface, size)
/// @description The bounding box and count of pixels with any coverage (alpha > 8) on a square surface cleared to
/// transparent. Every row is scanned (a clipped hairline lands on one row).
function lpw_st_inkbox(_sf, _sz) {
    var _b = buffer_create(_sz * _sz * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    var _x0 = _sz, _y0 = _sz, _x1 = -1, _y1 = -1, _n = 0;
    for (var _y = 0; _y < _sz; _y++) for (var _x = 0; _x < _sz; _x++) {
        if (buffer_peek(_b, (_y * _sz + _x) * 4 + 3, buffer_u8) > 8) {
            _n++;
            if (_x < _x0) _x0 = _x;
            if (_x > _x1) _x1 = _x;
            if (_y < _y0) _y0 = _y;
            if (_y > _y1) _y1 = _y;
        }
    }
    buffer_delete(_b);
    return { x0: _x0, y0: _y0, x1: _x1, y1: _y1, px: _n };
}

/// @function lpw_st_halo(surface, size, cx, cy, r)
/// @description Pixels brighter than 6 levels on a black surface that lie OUTSIDE radius r of (cx, cy) on the lamp's
/// side (up and left of the centre). Every row, every pixel.
function lpw_st_halo(_sf, _sz, _cx, _cy, _r) {
    var _b = buffer_create(_sz * _sz * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    var _n = 0;
    for (var _y = 0; _y < _sz; _y++) for (var _x = 0; _x < _sz; _x++) {
        if ((_x - _cx) + (_y - _cy) >= 0) continue;
        if (point_distance(_x + 0.5, _y + 0.5, _cx, _cy) <= _r) continue;
        var _o = (_y * _sz + _x) * 4;
        if (buffer_peek(_b, _o, buffer_u8) > 6 || buffer_peek(_b, _o + 1, buffer_u8) > 6 || buffer_peek(_b, _o + 2, buffer_u8) > 6) _n++;
    }
    buffer_delete(_b);
    return _n;
}

/// @function lpw_st_hamming(a, b)
function lpw_st_hamming(_a, _b) {
    var _d = 0;
    for (var _i = 1; _i <= string_length(_a); _i++) if (string_char_at(_a, _i) != string_char_at(_b, _i)) _d++;
    return _d;
}

function lpw_selftest_write(_st) {
    var _f = file_text_open_write("lpw_selftest.json");
    file_text_write_string(_f, "{\"total\":" + string(_st.total) + ",\"pass\":" + string(_st.pass) + ",\"fail\":" + string(_st.fail) + ",\"stage\":" + string(_st.stage) + ",\"notes\":[");
    for (var _i = 0; _i < array_length(_st.notes); _i++) { if (_i > 0) file_text_write_string(_f, ","); file_text_write_string(_f, "\"" + string_replace_all(_st.notes[_i], "\"", "'") + "\""); }
    file_text_write_string(_f, "],\"failures\":[");
    for (var _i = 0; _i < array_length(_st.failures); _i++) { if (_i > 0) file_text_write_string(_f, ","); file_text_write_string(_f, "\"" + string_replace_all(_st.failures[_i], "\"", "'") + "\""); }
    file_text_write_string(_f, "]}");
    file_text_close(_f);
}
