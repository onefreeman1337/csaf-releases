/// lpw_demo.gml - the demo room's story and its screen, as functions, so the demo object and the store bake draw the
/// SAME screen (the bake renders it to a PNG that is opened and looked at; nothing else can see the demo room).
///
/// Loopwork - A Time Loop That Remembers, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
/// Not needed by the library: delete it with obj_lpw_demo and rm_lpw_demo.

/// @function lpw_demo_seed()
/// @description The demo's opening record: a run three loops deep, with the world anchored at dawn. Pure.
function lpw_demo_seed() {
    var _s = lpw_create();
    lpw_learn(_s, "mayor-lies", "The mayor lies about the flood");
    lpw_diverge(_s, "took-the-boat", "Took the ferryman's boat");
    lpw_close_loop(_s, "drowned");
    lpw_learn(_s, "flood-gate", "The flood gate sticks at dusk");
    lpw_learn(_s, "bell-code", "The bell code is three long rings");
    lpw_diverge(_s, "rang-the-bell", "Rang the bell at noon");
    lpw_diverge(_s, "warned-ferryman", "Warned the ferryman");
    lpw_close_loop(_s, "the bell tolled");
    lpw_learn(_s, "cellar-door", "The cellar door is open at noon");
    lpw_learn(_s, "widow-secret", "The widow saw the mayor at the gate");
    lpw_learn(_s, "river-key", "The river key is under the mill");
    lpw_diverge(_s, "hid-in-cellar", "Hid in the cellar");
    lpw_close_loop(_s, "found out");
    lpw_learn(_s, "clock-stops", "The clock can be stopped");
    lpw_anchor(_s, [["bell_rung", false], ["gate_open", false]]);
    return _s;
}

/// @function lpw_demo_draw(state, world, message, t, w, h)
/// @description The demo screen: the Ledger, the last thing that happened, and the keys with the world's state.
/// `t` runs 0..1 while a loop closes (1 when idle).
function lpw_demo_draw(_st, _world, _msg, _t, _gw, _gh) {
    lpw_rect_fill(0, 0, _gw, _gh, make_colour_rgb(24, 20, 17));
    lpw_text(_gw * 0.5, 14, "THE LOOP LEDGER", 30, make_colour_rgb(238, 224, 194), fa_center, fa_top, fnt_loopwork_title);
    var _e = 0.5 - 0.5 * cos(pi * _t);
    lpw_ledger_draw(_st, 16, 56, _gw - 32, _gh - 128, { turn: _e * 2 * pi, reveal: _t });
    lpw_text(_gw * 0.5, _gh - 66, _msg, 20, make_colour_rgb(226, 210, 178), fa_center, fa_top, fnt_loopwork, 1, _gw - 40);
    lpw_text(_gw * 0.5, _gh - 36, "[L] learn a fact    [D] a different choice    [B] ring the bell    [G] open the gate    [R] end the loop    bell: "
        + (_world.bell_rung ? "rung" : "silent") + "   gate: " + (_world.gate_open ? "open" : "shut"), 15, make_colour_rgb(160, 142, 112), fa_center, fa_top, fnt_loopwork_ui, 1, _gw - 40);
}
