{
  "$GMScript": "v1",
  "%Name": "lpw_demo",
  "name": "lpw_demo",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}