/* DOWSER - field.js: the ONE signal engine. The game, the generator and every simulated player read the ground
 * through these functions and nothing else (the Stringline lesson: one engine, so a sweeper tests the real tool).
 * A buried object at horizontal offset (dx, dy) tiles and depth d tiles adds to the reading. Width grows with depth,
 * the peak falls with it.
 *   relics (bronze, bone) only RISE: a smooth hump.
 *   iron SWINGS: a hump with the needle thrown back below the baseline on its EAST side (a dipole) - the tell that
 *        separates one iron object from two relics lying close, which only ever rise.
 *   a live shell RINGS: a sharp narrow peak inside a dead moat that reads below the baseline all round.
 *   a void reads BELOW the baseline, a soft hollow with no rise anywhere.
 * v2 2026-09-19: v1's plain-hump iron matched 99.5% of close relic pairs (C3-roof FAIL); see
 * Internal_Ops/PREREG_2026-09-19_candidate.md RESULT v2.
 * Dual-mode: a <script> in the page (window.DW_FIELD) or require() in Node. */
(function (root) {
  'use strict';
  const MATERIALS = {
    iron:   { amp: 1.00, w0: 1.00, wk: 0.40, moat: 0.00, lobe: 0.38, lobeAt: 1.30, relic: false, bust: false },
    bronze: { amp: 0.62, w0: 0.95, wk: 0.35, moat: 0.00, lobe: 0.00, lobeAt: 0,    relic: true,  bust: false },
    bone:   { amp: 0.38, w0: 1.30, wk: 0.35, moat: 0.00, lobe: 0.00, lobeAt: 0,    relic: true,  bust: false },
    void:   { amp: -0.40, w0: 1.20, wk: 0.30, moat: 0.00, lobe: 0.00, lobeAt: 0,   relic: false, bust: false },
    shell:  { amp: 0.95, w0: 0.40, wk: 0.12, moat: 0.55, lobe: 0.00, lobeAt: 0,    relic: false, bust: true }
  };
  const DEPTH_MIN = 0.5, DEPTH_MAX = 3.0;      // the playable band, tiles
  const GAUGE_STEP = 0.05;                     // one visible needle step, reading units
  const ROD_STEP = 0.25;                       // the rod samples the ground every quarter tile

  function width(m, d) { return m.w0 + m.wk * d; }
  function peak(m, d) { return m.amp / (1 + 0.45 * d); }
  /** The contribution of one object of material m at depth d, at horizontal offset (dx, dy) from it. */
  function kernel(m, dx, dy, d) {
    const w = width(m, d), p = peak(m, d);
    const r2 = dx * dx + dy * dy;
    const core = Math.exp(-r2 / (2 * w * w));
    let v = core;
    if (m.moat) {
      const w2 = 2.6 * w;                         // the moat is wider and shallower than the ring
      v -= m.moat * Math.exp(-r2 / (2 * w2 * w2)) * (1 - core);
    }
    if (m.lobe) {
      const ex = dx - m.lobeAt * w;               // the swing sits EAST of the object, scaled with its width
      v -= m.lobe * Math.exp(-(ex * ex + dy * dy) / (2 * w * w));
    }
    return p * v;
  }
  /** The reading at point (x, y) over a list of objects {mat, x, y, d}. */
  function readAt(objects, x, y) {
    let v = 0;
    for (const o of objects) {
      const m = typeof o.mat === 'string' ? MATERIALS[o.mat] : o.mat;
      if (!m) throw new Error('unknown material ' + o.mat);
      v += kernel(m, x - o.x, y - o.y, o.d);
    }
    return v;
  }
  /** What the needle SHOWS: the reading quantised to whole gauge steps. */
  function gauge(v) { return Math.round(v / GAUGE_STEP); }

  const api = { MATERIALS, DEPTH_MIN, DEPTH_MAX, GAUGE_STEP, ROD_STEP, width, peak, kernel, readAt, gauge };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.DW_FIELD = api;
})(typeof window !== 'undefined' ? window : globalThis);
