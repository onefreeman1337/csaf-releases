/* sound.js - DOWSER's sound. Two arrangements of one theme (the LEDGER: title and season book; the FIELD: a dig in
 * progress), rendered to the SAME length so they crossfade in step; nine cues; and the ROD'S VOICE - a live tone whose
 * note follows the needle, one step of the gauge = one step of a pentatonic scale, so a sweep plays the ground.
 * Two backends (Wings/Games/CLAUDE.md §8a rule 2, §2a): on http(s) gapless AudioBufferSourceNodes; on file:// (the paid
 * Windows download, where fetch cannot read a file at all) bare <audio> elements OUT of the WebAudio graph, volume
 * driven directly. The rod's voice is an oscillator and works on both. Nothing plays before the first press (autoplay).
 * Every cue is gated on ITS OWN buffer and a running context, never on the music being ready (§8a rule 4). */
(function (root) {
  'use strict';
  var MUSIC = ['mus_ledger', 'mus_field'];
  var CUES = ['sfx_stake', 'sfx_unstake', 'sfx_dig', 'sfx_find', 'sfx_iron', 'sfx_hollow', 'sfx_bust', 'sfx_ui', 'sfx_page'];
  var IS_FILE = location.protocol === 'file:';
  var MUSIC_VOL = 0.42;
  function Sound() {
    this.muted = false; try { this.muted = localStorage.getItem('dowser.muted') === '1'; } catch (e) { /* storage refused */ }
    this.ctx = null; this.buffers = {}; this.els = {}; this.pool = {}; this.gains = {}; this.sources = {};
    this.started = false; this.errors = []; this.weights = [1, 0]; this.mood = 0; this.cueCount = 0; this.voiceNotes = 0;
    this.loaded = { music: 0, cues: 0 }; this.voice = null; this.voiceStep = null;
  }
  Sound.prototype.load = function () {
    var self = this;
    try { this.ctx = new (root.AudioContext || root.webkitAudioContext)(); this.master = this.ctx.createGain(); this.master.gain.value = this.muted ? 0 : 1; this.master.connect(this.ctx.destination); } catch (e) { this.errors.push('no AudioContext: ' + e.message); }
    if (IS_FILE || !this.ctx) {
      MUSIC.forEach(function (n) { var el = new Audio('audio/' + n + '.ogg'); el.loop = true; el.preload = 'auto'; el.volume = 0; el.addEventListener('canplaythrough', function () { self.loaded.music++; }, { once: true }); el.addEventListener('error', function () { self.errors.push(n + '.ogg failed'); }); self.els[n] = el; });
      CUES.forEach(function (n) { self.pool[n] = [0, 1, 2].map(function () { var el = new Audio('audio/' + n + '.ogg'); el.preload = 'auto'; return el; }); self.pool[n][0].addEventListener('canplaythrough', function () { self.loaded.cues++; }, { once: true }); });
      return;
    }
    MUSIC.concat(CUES).forEach(function (n) {
      fetch('audio/' + n + '.ogg').then(function (r) { if (!r.ok) throw new Error(n + '.ogg ' + r.status); return r.arrayBuffer(); })
        .then(function (ab) { return new Promise(function (res, rej) { self.ctx.decodeAudioData(ab, res, rej); }); })
        .then(function (buf) { self.buffers[n] = buf; if (MUSIC.indexOf(n) >= 0) self.loaded.music++; else self.loaded.cues++; if (self.started && MUSIC.indexOf(n) >= 0) self._startTrack(n); })
        .catch(function (e) { self.errors.push(String(e.message || e)); });
    });
  };
  Sound.prototype.unlock = function () {
    if (this.started) return; this.started = true;
    var self = this;
    if (this.ctx && this.ctx.state !== 'running') this.ctx.resume().catch(function (e) { self.errors.push('resume refused: ' + e.message); });
    if (IS_FILE || !this.ctx) {
      MUSIC.forEach(function (n, i) { var el = self.els[n]; el.volume = self.muted ? 0 : self.weights[i] * MUSIC_VOL; var p = el.play(); if (p && p.catch) p.catch(function (e) { self.errors.push('autoplay denied: ' + e.message); }); });
    } else MUSIC.forEach(function (n) { if (self.buffers[n]) self._startTrack(n); });
  };
  Sound.prototype._startTrack = function (n) {
    if (this.sources[n]) return;
    var i = MUSIC.indexOf(n), gn = this.ctx.createGain(); gn.gain.value = this.weights[i] * MUSIC_VOL; gn.connect(this.master);
    if (this.t0 == null) this.t0 = this.ctx.currentTime + 0.05;
    var src = this.ctx.createBufferSource(); src.buffer = this.buffers[n]; src.loop = true; src.connect(gn);
    var len = this.buffers[n].duration, off = Math.max(0, this.ctx.currentTime - this.t0) % len;
    src.start(this.ctx.currentTime + 0.02, off); this.sources[n] = src; this.gains[n] = gn;
  };
  /* mood 0 = the ledger, 1 = the field */
  Sound.prototype.setMood = function (m) {
    this.mood = m; this.weights = [1 - m, m];
    var self = this;
    MUSIC.forEach(function (n, i) {
      var v = self.muted ? 0 : self.weights[i] * MUSIC_VOL * (m === 1 && self.voice ? 0.55 : 1);
      if (self.gains[n]) self.gains[n].gain.setTargetAtTime(v, self.ctx.currentTime, 0.8);
      if (self.els[n] && self.started) self.els[n].volume = Math.max(0, Math.min(1, v));
    });
  };
  Sound.prototype.cue = function (n, gain) {
    if (this.muted) return false;
    if (IS_FILE || !this.ctx) { var els = this.pool[n]; if (!els) return false; var el = els.find(function (e) { return e.paused || e.ended; }) || els[0]; try { el.currentTime = 0; } catch (e) { /* not seekable yet */ } el.volume = Math.min(1, gain || 0.8); var p = el.play(); if (p && p.catch) p.catch(function () {}); this.cueCount++; return true; }
    var b = this.buffers[n]; if (!b || this.ctx.state !== 'running') return false;
    var s = this.ctx.createBufferSource(), gn = this.ctx.createGain(); gn.gain.value = gain || 0.8; s.buffer = b; s.connect(gn); gn.connect(this.master); s.start(); this.cueCount++; return true;
  };
  /* THE ROD'S VOICE. step = the gauge reading in whole steps. Above the line a warm reed on A minor pentatonic, one
   * scale step per gauge step; below the line a hollow low drone that falls a step per gauge step. null = silent. */
  var PENTA = [0, 3, 5, 7, 10];
  function noteFreq(step) {
    if (step <= 0) return 110 * Math.pow(2, (step * 1) / 12);
    var k = step - 1, oct = Math.floor(k / 5), semis = PENTA[k % 5] + 12 * oct;
    return 220 * Math.pow(2, semis / 12);
  }
  Sound.prototype.rod = function (step) {
    if (!this.ctx || this.ctx.state !== 'running') return false;
    var t = this.ctx.currentTime;
    if (step === null || step === undefined) {
      if (this.voice) { this.voice.g.gain.setTargetAtTime(0.0001, t, 0.05); var v = this.voice; setTimeout(function () { try { v.o.stop(); v.o2.stop(); } catch (e) { /* already stopped */ } }, 400); this.voice = null; this.voiceStep = null; this.setMood(this.mood); }
      return false;
    }
    if (!this.voice) {
      var o = this.ctx.createOscillator(), o2 = this.ctx.createOscillator(), g = this.ctx.createGain(), lp = this.ctx.createBiquadFilter();
      o.type = 'triangle'; o2.type = 'sawtooth'; lp.type = 'lowpass'; lp.frequency.value = 1400;
      var g2 = this.ctx.createGain(); g2.gain.value = 0.18; o2.connect(g2); g2.connect(lp); o.connect(lp); lp.connect(g); g.connect(this.master);
      g.gain.value = 0.0001; o.start(t); o2.start(t);
      this.voice = { o: o, o2: o2, g: g, lp: lp }; this.setMood(this.mood);
    }
    if (step !== this.voiceStep) {
      var f = noteFreq(step);
      this.voice.o.frequency.setTargetAtTime(f, t, 0.012); this.voice.o2.frequency.setTargetAtTime(f * (step <= 0 ? 0.5 : 1.004), t, 0.012);
      this.voice.lp.frequency.setTargetAtTime(step <= 0 ? 500 : 900 + 60 * Math.min(20, step), t, 0.03);
      var vol = this.muted ? 0.0001 : (step === 0 ? 0.018 : step < 0 ? 0.05 : 0.04 + 0.004 * Math.min(12, step));
      this.voice.g.gain.setTargetAtTime(vol, t, 0.02);
      this.voiceStep = step; this.voiceNotes++;
    }
    return true;
  };
  Sound.prototype.setMuted = function (on) {
    this.muted = !!on; try { localStorage.setItem('dowser.muted', on ? '1' : '0'); } catch (e) { /* ignore */ }
    if (this.master) this.master.gain.value = on ? 0 : 1;
    this.setMood(this.mood);
    return this.muted;
  };
  Sound.prototype.toggleMute = function () { return this.setMuted(!this.muted); };
  Sound.prototype.report = function () {
    return { backend: IS_FILE || !this.ctx ? 'media-element' : 'webaudio', ctx: this.ctx ? this.ctx.state : 'none', started: this.started, muted: this.muted,
      loaded: this.loaded, want: { music: MUSIC.length, cues: CUES.length }, weights: this.weights.map(function (x) { return +x.toFixed(3); }), cues: this.cueCount, voiceNotes: this.voiceNotes, voiceOn: !!this.voice, errors: this.errors.slice() };
  };
  root.DW_SOUND = new Sound();
  root.DW_SOUND.MUSIC = MUSIC; root.DW_SOUND.CUES = CUES; root.DW_SOUND.noteFreq = noteFreq;
})(window);
