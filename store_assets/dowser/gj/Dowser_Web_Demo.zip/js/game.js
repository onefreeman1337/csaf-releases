/* game.js - DOWSER. Minesweeper with no numbers: sweep a rod over an old field, read the ground by hand, dig for relics
 * and leave the live shells where they lie.
 * The page owns one clock: tick(dt) is the ONLY place a frame happens; requestAnimationFrame calls it, and
 * window.__dwTick(n) is a second caller so a harness can drive the SHIPPED build in a hidden tab
 * (Wings/Games/CLAUDE.md §6b-18). The ground is read ONLY through js/field.js (the engine the solver proved).
 * Every refusal names its reason (§0z-1c). */
(function (root) {
  'use strict';
  var FD = root.DW_FIELD, F = root.DW_FONT, SND = root.DW_SOUND, A = root.DW_ATLAS;
  var W = 480, H = 270, T = 16, RES = 4;
  var FIELDS = root.DW_FIELDS || [], TOTAL = root.DW_FIELDS_TOTAL || FIELDS.length, FULL = !!root.DW_FULL, HALLS = root.DW_HALLS || {};
  var cv = document.getElementById('c'), g = cv.getContext('2d');
  g.imageSmoothingEnabled = false;
  var COL = { ink: '#f1e7cf', dim: '#b3a384', faint: '#776a55', gold: '#f0c24e', red: '#d4483a', bg: '#15110c', panel: '#221b13', edge: '#6e5530', ok: '#a6cf7e', cool: '#8fb0ff', brass: '#c99a3e' };
  var SAVE_KEY = 'dowser.save.v1';
  var SX = 4, SY = 4, SW = 304, SH = 210;              // the scene box (ground + ruins); the plot sits centred in it
  var PX0 = 312;                                        // the right-hand panel

  // ---- save ----------------------------------------------------------------------------------------
  var save = { v: 1, seals: {}, finds: {} };
  try { var raw = localStorage.getItem(SAVE_KEY); if (raw) { var p0 = JSON.parse(raw); if (p0 && p0.v === 1 && p0.seals) { save = p0; if (!save.finds) save.finds = {}; } } } catch (e) { /* storage refused: play without saving */ }
  function writeSave() { try { localStorage.setItem(SAVE_KEY, JSON.stringify(save)); } catch (e) { S.msg('YOUR BROWSER REFUSED TO SAVE PROGRESS.'); } }

  // ---- state ---------------------------------------------------------------------------------------
  var S = {
    screen: 'title', t: 0, book: 0, page: 0, pauseSel: 0, mouse: null, down: false, keys: {}, msgs: [], msgT: 0,
    D: null, result: null, frames: 0, lastRefusal: null, stakeMode: false,
    msg: function (m) { S.msgs.unshift(String(m).toUpperCase()); S.msgs.length = Math.min(S.msgs.length, 2); S.msgT = S.t; }
  };
  function sealOf(n) { return save.seals[n] || null; }
  function clearedSeal(n) { var s = sealOf(n); return s === 'clean' || s === 'dug'; }
  function unlocked(n) { if (n === 1) return true; if (n > FIELDS.length) return false; return clearedSeal(n - 1); }

  // ---- art -----------------------------------------------------------------------------------------
  var img = new Image(), art = { ready: false, failed: null, missing: {} };
  img.onload = function () { art.ready = true; };
  img.onerror = function () { art.failed = 'art/dowser.png did not load'; };
  img.src = A.sheet;
  function ih(a, b, c) {
    var h = Math.imul(a | 0, 374761393) ^ Math.imul(b | 0, 668265263) ^ Math.imul(c | 0, 2246822519);
    h = Math.imul(h ^ (h >>> 15), 2246822507); h = Math.imul(h ^ (h >>> 13), 3266489909); h ^= h >>> 16;
    return (h >>> 0) / 4294967296;
  }
  function blit(cg, id, x, y, scale) {
    var t = A.tiles[id];
    if (!t) { art.missing[id] = (art.missing[id] || 0) + 1; return false; }
    var r = t.r, s = scale || 1; cg.drawImage(img, r[0], r[1], r[2], r[3], Math.round(x), Math.round(y), r[2] * s, r[3] * s); return true;
  }

  // ---- the heat of a reading ---------------------------------------------------------------------------
  /* The glow is a CONTOUR MAP, not a wash (graybox look 2026-09-19: a smooth per-step ramp painted every faint tail
   * strong orange, and three relics and an iron melted into one sheet - only the shell could be read). Readings are
   * banded every 2 gauge steps; the faintest band is nearly clear; a dark line is drawn wherever two swept cells fall in
   * different bands, so every buried thing wears its own rings, like a survey map. Step 0 where the rod has been is a
   * faint dark wash, so the player can SEE what they have swept. */
  /* Bands are FINE where readings are faint and coarse where they are loud (a 2-step band gave a bone one ring at most
   * and it vanished beside iron - 3x look, 2026-09-19): a ring at 1, 2, 3, 4, 5, then 7, 9, 12, 15, 19, 24. */
  var UP = [1, 2, 3, 4, 5, 7, 9, 12, 15, 19, 24], DOWN = [1, 2, 3, 5, 7];
  function bandOf(step) {
    var b = 0, i;
    if (step > 0) { for (i = 0; i < UP.length; i++) if (step >= UP[i]) b = i + 1; return b; }
    if (step < 0) { for (i = 0; i < DOWN.length; i++) if (-step >= DOWN[i]) b = i + 1; return -b; }
    return 0;
  }
  var WARM = ['rgba(24,16,8,0.30)'], COOL = ['rgba(24,16,8,0.30)'];
  (function () {
    var stops = [[150, 110, 44], [214, 128, 36], [244, 184, 60], [255, 226, 150], [255, 250, 228]];
    for (var b = 1; b <= UP.length; b++) {
      var k = (b - 1) / (UP.length - 1), f = k * (stops.length - 1), i = Math.min(stops.length - 2, Math.floor(f)), u = f - i, a = stops[i], c = stops[i + 1];
      WARM.push('rgba(' + Math.round(a[0] + (c[0] - a[0]) * u) + ',' + Math.round(a[1] + (c[1] - a[1]) * u) + ',' + Math.round(a[2] + (c[2] - a[2]) * u) + ',' + (0.18 + 0.78 * Math.sqrt(k)).toFixed(2) + ')');
    }
    for (b = 1; b <= DOWN.length; b++) { var q = (b - 1) / (DOWN.length - 1); COOL.push('rgba(' + Math.round(60 + 90 * q) + ',' + Math.round(80 + 96 * q) + ',' + Math.round(164 + 91 * q) + ',' + (0.32 + 0.54 * q).toFixed(2) + ')'); }
  })();
  function heat(step) { var b = bandOf(step); return b >= 0 ? WARM[Math.min(WARM.length - 1, b)] : COOL[Math.min(COOL.length - 1, -b)]; }
  /* redraw the whole trace from the read cells (cheap: at most 64 x 40 cells), fills first, then the contour lines */
  function renderTrace(D) {
    var cw = D.fw * RES, ch = D.fh * RES, s = T / RES, tg = D.tg;
    tg.clearRect(0, 0, D.trace.width, D.trace.height);
    for (var cy = 0; cy < ch; cy++) for (var cx = 0; cx < cw; cx++) { var i = cy * cw + cx; if (!D.swept[i]) continue; tg.fillStyle = heat(D.cells[i]); tg.fillRect(cx * s, cy * s, s, s); }
    tg.fillStyle = 'rgba(28,16,4,0.62)';
    for (cy = 0; cy < ch; cy++) for (cx = 0; cx < cw; cx++) {
      i = cy * cw + cx; if (!D.swept[i]) continue;
      var b = bandOf(D.cells[i]);
      if (cx + 1 < cw && D.swept[i + 1] && bandOf(D.cells[i + 1]) !== b) tg.fillRect((cx + 1) * s - 1, cy * s, 1, s);
      if (cy + 1 < ch && D.swept[i + cw] && bandOf(D.cells[i + cw]) !== b) tg.fillRect(cx * s, (cy + 1) * s - 1, s, 1);
    }
    D.traceDirty = false;
  }

  // ---- a dig -----------------------------------------------------------------------------------------
  function hallOf(id) { var h = HALLS[id]; if (!h) throw new Error('hall ' + id + ' is not in this build'); return h; }
  function openField(n) {
    var rec = FIELDS[n - 1]; if (!rec) throw new Error('field ' + n + ' is not in this build');
    var hall = hallOf(rec.hall);
    var fw = rec.W, fh = rec.H;
    var D = {
      n: n, rec: rec, hall: hall, fw: fw, fh: fh,
      ox: SX + Math.floor((SW - fw * T) / 2), oy: SY + Math.floor((SH - fh * T) / 2),
      objects: rec.objects.map(function (o) { return { mat: o.mat, x: o.x, y: o.y, d: o.d, find: o.find || null }; }),
      cells: new Int16Array(fw * RES * fh * RES), swept: new Uint8Array(fw * RES * fh * RES), sweptN: 0,
      stakes: [], dug: [], rod: null, needle: 0, reading: null, dragging: false, digging: null, done: false, bust: false, haul: 0, plates: [], reveal: false
    };
    D.layer = composeScene(D);
    D.trace = document.createElement('canvas'); D.trace.width = fw * T; D.trace.height = fh * T;
    D.tg = D.trace.getContext('2d');
    S.D = D; S.result = null; S.screen = 'field'; S.stakeMode = false;
    SND.setMood(1);
    S.msg('DRAG THE ROD OVER THE PLOT. THE NEEDLE AND TONE READ WHAT LIES UNDER IT.');
  }
  /* The scene: the hall's ground everywhere, ruins standing round the roped plot (never on it). */
  function composeScene(D) {
    var hall = D.hall, c = document.createElement('canvas'); c.width = SW; c.height = SH;
    var cg = c.getContext('2d'); cg.imageSmoothingEnabled = false;
    var cols = Math.ceil(SW / T), rows = Math.ceil(SH / T);
    for (var y = 0; y < rows; y++) for (var x = 0; x < cols; x++) blit(cg, hall.ground + '_' + (1 + Math.floor(ih(x, y, 77 + D.n) * 4)), x * T, y * T);
    // ruins in the ring round the plot: a deterministic scatter, no overlap, a clear tile between them and the rope
    var px0 = Math.round((D.ox - SX) / T), py0 = Math.round((D.oy - SY) / T), used = {};
    /* a prop may stand right up against the rope, never on the plot; props keep a tile between each other. (v1 also
     * demanded a clear tile round the rope, which left the 16x10 Colonnade plots with no room for ANY ruin: review #5.) */
    var plotX0 = Math.floor((D.ox - SX) / T), plotX1 = Math.ceil((D.ox - SX + D.fw * T) / T) - 1, plotY0 = Math.floor((D.oy - SY) / T), plotY1 = Math.ceil((D.oy - SY + D.fh * T) / T) - 1;
    var free = function (x, y, w, h) {
      if (x < 0 || y < 0 || x + w > cols || y + h > rows) return false;
      for (var yy = y; yy < y + h; yy++) for (var xx = x; xx < x + w; xx++) if (xx >= plotX0 && xx <= plotX1 && yy >= plotY0 && yy <= plotY1) return false;
      for (yy = y - 1; yy <= y + h; yy++) for (xx = x - 1; xx <= x + w; xx++) if (used[xx + ',' + yy]) return false;
      return true;
    };
    void px0; void py0;
    var props = hall.props, placed = 0;
    for (var k = 0; k < 220 && placed < hall.propCount; k++) {
      var id = props[Math.floor(ih(k, D.n, 5) * props.length)], t = A.tiles[id]; if (!t) { art.missing[id] = 1; continue; }
      var w = Math.ceil(t.r[2] / T), h = Math.ceil(t.r[3] / T);
      var x0 = Math.floor(ih(k, D.n, 11) * cols), y0 = Math.floor(ih(k, D.n, 13) * rows);
      if (!free(x0, y0, w, h)) continue;
      for (var yy = y0; yy < y0 + h; yy++) for (var xx = x0; xx < x0 + w; xx++) used[xx + ',' + yy] = 1;
      // contact shadow, then the prop
      cg.fillStyle = 'rgba(12,8,4,0.30)'; cg.fillRect(x0 * T + 2, (y0 + h) * T - 3, w * T - 3, 3);
      blit(cg, id, x0 * T, y0 * T); placed++;
    }
    // the plot: a darker turned-earth wash under the rope so it reads as ground you are allowed to open
    var ox = D.ox - SX, oy = D.oy - SY;
    cg.fillStyle = 'rgba(20,12,4,0.16)'; cg.fillRect(ox, oy, D.fw * T, D.fh * T);
    return c;
  }
  function cellIdx(D, cx, cy) { return cy * D.fw * RES + cx; }
  /* sweep the rod from a to b (tiles): every quarter-tile cell within reach of the path is READ and painted */
  var REACH = 0.34;
  function sweep(D, a, b) {
    var len = Math.hypot(b[0] - a[0], b[1] - a[1]), n = Math.max(1, Math.ceil(len / 0.12));
    for (var s = 0; s <= n; s++) {
      var px = a[0] + (b[0] - a[0]) * s / n, py = a[1] + (b[1] - a[1]) * s / n;
      var c0 = Math.floor((px - REACH) * RES), c1 = Math.floor((px + REACH) * RES), r0 = Math.floor((py - REACH) * RES), r1 = Math.floor((py + REACH) * RES);
      for (var cy = Math.max(0, r0); cy <= Math.min(D.fh * RES - 1, r1); cy++) for (var cx = Math.max(0, c0); cx <= Math.min(D.fw * RES - 1, c1); cx++) {
        var ccx = (cx + 0.5) / RES, ccy = (cy + 0.5) / RES;
        if ((ccx - px) * (ccx - px) + (ccy - py) * (ccy - py) > REACH * REACH) continue;
        var i = cellIdx(D, cx, cy);
        if (D.swept[i]) continue;
        var v = FD.gauge(FD.readAt(D.objects, ccx, ccy));
        D.swept[i] = 1; D.cells[i] = v; D.sweptN++; D.traceDirty = true;
      }
    }
  }
  function readRod(D) { return D.rod ? FD.gauge(FD.readAt(D.objects, D.rod[0], D.rod[1])) : null; }
  function stakeAt(D, tx, ty) { for (var i = 0; i < D.stakes.length; i++) if (D.stakes[i][0] === tx && D.stakes[i][1] === ty) return i; return -1; }
  function dugAt(D, tx, ty) { for (var i = 0; i < D.dug.length; i++) if (D.dug[i].tx === tx && D.dug[i].ty === ty) return D.dug[i]; return null; }
  function toggleStake(tx, ty) {
    var D = S.D; if (!D || D.done || D.digging) return;
    if (tx < 0 || ty < 0 || tx >= D.fw || ty >= D.fh) { S.msg('STAKES GO INSIDE THE ROPE.'); S.lastRefusal = 'stake-outside'; return; }
    if (dugAt(D, tx, ty)) { S.msg('THAT GROUND IS ALREADY OPEN.'); S.lastRefusal = 'stake-dug'; return; }
    var i = stakeAt(D, tx, ty);
    if (i >= 0) { D.stakes.splice(i, 1); SND.cue('sfx_unstake', 0.5); return; }
    if (D.stakes.length >= D.rec.stakes) { S.msg('YOU HAVE ' + D.rec.stakes + ' STAKES. PULL ONE UP TO MOVE IT.'); S.lastRefusal = 'stakes-spent'; SND.cue('sfx_ui', 0.4); return; }
    D.stakes.push([tx, ty]); SND.cue('sfx_stake', 0.6);
  }
  function objectAt(D, tx, ty) { for (var i = 0; i < D.objects.length; i++) { var o = D.objects[i]; if (Math.floor(o.x) === tx && Math.floor(o.y) === ty) return o; } return null; }
  function digBlocked() {
    var D = S.D; if (!D) return 'NO PLOT IS OPEN.';
    if (D.done) return 'THIS PLOT IS FINISHED.';
    if (D.digging) return 'THE SPADE IS ALREADY IN THE GROUND.';
    if (!D.stakes.length) return 'PLACE A STAKE FIRST: RIGHT-CLICK A SPOT, OR PRESS THE STAKE BUTTON AND TAP IT.';
    return null;
  }
  function startDig() {
    var why = digBlocked();
    if (why) { S.msg(why); S.lastRefusal = why; SND.cue('sfx_ui', 0.4); return; }
    var D = S.D; D.digging = { queue: D.stakes.slice(), i: 0, t: 0 }; D.stakes = []; D.dragging = false; SND.rod(null);
    S.msgs = [];
  }
  var DIG_T = 0.75;
  function stepDig(dt) {
    var D = S.D, G = D.digging; if (!G) return;
    G.t += dt;
    if (G.t < DIG_T) return;
    G.t = 0;
    var st = G.queue[G.i], o = objectAt(D, st[0], st[1]), what = o ? o.mat : 'earth';
    D.dug.push({ tx: st[0], ty: st[1], what: what, find: o && o.find, d: o && o.d, t: S.t });
    if (what === 'shell') {
      D.bust = true; D.haul = 0; SND.cue('sfx_bust', 0.95); D.digging = null; D.shake = S.t; finishField(); return;
    }
    if (what === 'bronze' || what === 'bone') { D.haul += what === 'bronze' ? 3 : 2; D.plates.push({ mat: what, find: o.find, d: o.d, t: S.t }); SND.cue('sfx_find', 0.85); }
    else if (what === 'iron') SND.cue('sfx_iron', 0.8);
    else if (what === 'void') SND.cue('sfx_hollow', 0.8);
    else SND.cue('sfx_dig', 0.7);
    G.i++;
    if (G.i >= G.queue.length) { D.digging = null; finishField(); }
  }
  function finishField() {
    var D = S.D, rec = D.rec;
    var relics = D.objects.filter(function (o) { return o.mat === 'bronze' || o.mat === 'bone'; });
    var found = D.dug.filter(function (d) { return d.what === 'bronze' || d.what === 'bone'; });
    var wasted = D.dug.length - found.length;
    D.done = true; D.reveal = true; D.doneT = S.t;
    var seal = D.bust ? 'bust' : found.length === 0 ? 'empty' : (found.length === relics.length && wasted === 0 ? 'clean' : 'dug');
    var prev = sealOf(D.n);
    /* A CLEAN seal is only ever earned on the FIRST dig of a field: every result reveals where everything lay, so a
     * second attempt is read off the answer (fresh review #4: "a loss costs nothing, so the clean record means
     * nothing"). A perfect re-dig is recorded as DUG and says why. */
    var retry = !!prev && seal === 'clean';
    if (retry) seal = 'dug';
    var rank = { clean: 3, dug: 2, empty: 1, bust: 0 };
    if (!prev || rank[seal] > rank[prev]) save.seals[D.n] = seal;
    if (!D.bust) found.forEach(function (d) { if (d.find) save.finds[d.find] = (save.finds[d.find] || 0) + 1; });
    writeSave();
    S.result = { seal: seal, found: found.length, of: relics.length, wasted: wasted, haul: D.haul, t: S.t, retry: retry,
      iron: D.dug.filter(function (d) { return d.what === 'iron'; }).length, voids: D.dug.filter(function (d) { return d.what === 'void'; }).length };
  }
  function reopen() { var n = S.D.n; openField(n); S.msg('A FRESH PLOT OF THE SAME GROUND. IT HAS NOT MOVED.'); }

  // ---- input ---------------------------------------------------------------------------------------
  function toLogical(ev) { var r = cv.getBoundingClientRect(); return [(ev.clientX - r.left) * W / r.width, (ev.clientY - r.top) * H / r.height]; }
  function toTiles(p) { var D = S.D; return [(p[0] - D.ox) / T, (p[1] - D.oy) / T]; }
  function inPlot(p) { var D = S.D; return D && p[0] >= D.ox && p[1] >= D.oy && p[0] < D.ox + D.fw * T && p[1] < D.oy + D.fh * T; }
  var BUTTONS = [];
  function button(id, x, y, w, h, label, enabled, hot) { BUTTONS.push({ id: id, x: x, y: y, w: w, h: h, enabled: enabled }); return { id: id, x: x, y: y, w: w, h: h, label: label, enabled: enabled, hot: hot }; }
  function hitButton(p) { for (var i = 0; i < BUTTONS.length; i++) { var b = BUTTONS[i]; if (p[0] >= b.x && p[1] >= b.y && p[0] < b.x + b.w && p[1] < b.y + b.h) return b; } return null; }
  function onDown(ev) {
    SND.unlock(); var p = toLogical(ev); S.mouse = p; S.down = true; cv.focus();
    var b = hitButton(p);
    if (b) { press(b.id, b.enabled); return; }
    if (S.screen === 'field') {
      // a click on a finished plot does NOT leave it: that is the moment the player studies the reveal (review #11);
      // the banner's buttons and Enter move on
      var D = S.D; if (D.done || D.digging) return;
      if (!inPlot(p)) return;
      var tp = toTiles(p);
      if (ev.button === 2 || S.stakeMode) { toggleStake(Math.floor(tp[0]), Math.floor(tp[1])); return; }
      S.msgs = [];
      D.dragging = true; D.rod = tp; sweep(D, tp, tp);
      return;
    }
    if (ev.button === 2) return;
    if (S.screen === 'pause' || S.screen === 'help' || S.screen === 'ledger' || S.screen === 'cabinet') return;
    advance();
  }
  function onMove(ev) {
    var p = toLogical(ev); S.mouse = p;
    if (S.screen === 'field' && S.D && S.D.dragging) {
      var D = S.D, tp = toTiles(p);
      tp[0] = Math.max(0, Math.min(D.fw - 0.001, tp[0])); tp[1] = Math.max(0, Math.min(D.fh - 0.001, tp[1]));
      sweep(D, D.rod || tp, tp); D.rod = tp;
    }
  }
  function onUp() {
    S.down = false;
    if (S.screen === 'field' && S.D && S.D.dragging) { S.D.dragging = false; SND.rod(null); }
  }
  function press(id, enabled) {
    if (!enabled) { if (id === 'dig') { var why = digBlocked(); S.msg(why || 'NOT NOW.'); S.lastRefusal = why; } return; }
    SND.cue('sfx_ui', 0.5);
    var pm = /^p([0-4])$/.exec(id), fm = /^field:(\d+)$/.exec(id);
    if (id === 'dig') startDig();
    else if (id === 'stake') { S.stakeMode = !S.stakeMode; S.msg(S.stakeMode ? 'STAKE MODE: A CLICK OR TAP PLACES OR PULLS A STAKE.' : 'ROD MODE: DRAG TO SWEEP.'); }
    else if (id === 'notes') { S.ret = S.screen; S.screen = 'help'; S.page = 0; }
    else if (id === 'pull') { S.D.stakes = []; S.msg('EVERY STAKE IS PULLED UP.'); }
    else if (id === 'again') reopen();
    else if (id === 'mute') { SND.toggleMute(); }
    else if (id === 'menu') { S.screen = 'pause'; S.pauseSel = 0; SND.rod(null); if (S.D) S.D.dragging = false; }
    else if (pm) { S.pauseSel = +pm[1]; pauseChoose(+pm[1]); }
    else if (id === 'help-prev') S.page = Math.max(0, S.page - 1);
    else if (id === 'help-next') S.page = Math.min(helpPages().length - 1, S.page + 1);
    else if (id === 'help-back') S.screen = S.ret || 'ledger';
    else if (fm) { S.book = +fm[1] - 1; advance(); }
    else if (id === 'ledger-title') S.screen = 'title';
    else if (id === 'ledger-notes') { S.ret = 'ledger'; S.screen = 'help'; S.page = 0; }
    else if (id === 'ledger-cabinet') S.screen = 'cabinet';
    else if (id === 'ledger-credits') S.screen = 'credits';
    else if (id === 'cabinet-back') S.screen = 'ledger';
    else if (id === 'result-next') advance();
  }
  var KEYMAP = { ArrowUp: 'up', KeyW: 'up', ArrowDown: 'down', KeyS: 'down', ArrowLeft: 'left', KeyA: 'left', ArrowRight: 'right', KeyD: 'right' };
  function onKey(ev) {
    SND.unlock();
    var k = ev.code;
    if (KEYMAP[k] || k === 'Space' || k === 'Enter' || k === 'Tab' || k === 'Backspace') ev.preventDefault();
    if (KEYMAP[k]) S.keys[KEYMAP[k]] = true;
    if (ev.repeat && !KEYMAP[k]) return;
    if (k === 'KeyM') { SND.toggleMute(); return; }
    if (S.screen === 'field') {
      var D = S.D;
      if (k === 'Escape') { S.screen = 'pause'; S.pauseSel = 0; SND.rod(null); D.dragging = false; return; }
      if (k === 'KeyH' || k === 'F1' || k === 'Slash') { S.ret = 'field'; S.screen = 'help'; S.page = 0; return; }
      if (D.done) { if (k === 'Enter' || k === 'Space') advance(); else if (k === 'KeyR') reopen(); return; }
      if (D.digging) return;
      if (k === 'KeyE' || k === 'Space') { if (!D.rod) D.rod = [D.fw / 2, D.fh / 2]; toggleStake(Math.floor(D.rod[0]), Math.floor(D.rod[1])); return; }
      if (k === 'Enter') { startDig(); return; }
      if (k === 'KeyX' || k === 'Backspace') { D.stakes = []; S.msg('EVERY STAKE IS PULLED UP.'); return; }
      if (k === 'KeyT') { press('stake', true); return; }
      return;
    }
    if (S.screen === 'pause') {
      if (k === 'Escape') { S.screen = 'field'; return; }
      if (k === 'ArrowUp' || k === 'KeyW') S.pauseSel = (S.pauseSel + 4) % 5;
      if (k === 'ArrowDown' || k === 'KeyS') S.pauseSel = (S.pauseSel + 1) % 5;
      if (k === 'Enter' || k === 'Space') pauseChoose(S.pauseSel);
      return;
    }
    if (S.screen === 'ledger') {
      if (k === 'ArrowUp' || k === 'KeyW' || k === 'ArrowLeft' || k === 'KeyA') S.book = Math.max(0, S.book - 1);
      else if (k === 'ArrowDown' || k === 'KeyS' || k === 'ArrowRight' || k === 'KeyD') S.book = Math.min(TOTAL - 1, S.book + 1);
      else if (k === 'Escape') S.screen = 'title';
      else if (k === 'KeyH') { S.ret = 'ledger'; S.screen = 'help'; S.page = 0; }
      else if (k === 'KeyC') S.screen = 'cabinet';
      else if (k === 'Enter' || k === 'Space') advance();
      return;
    }
    if (S.screen === 'help') { if (k === 'ArrowRight' || k === 'KeyD') S.page = Math.min(helpPages().length - 1, S.page + 1); else if (k === 'ArrowLeft' || k === 'KeyA') S.page = Math.max(0, S.page - 1); else if (k === 'Escape' || k === 'Enter' || k === 'Space') S.screen = S.ret || 'ledger'; return; }
    if (S.screen === 'cabinet') { if (k === 'Escape' || k === 'Enter' || k === 'Space') S.screen = 'ledger'; return; }
    if (k === 'Escape' && (S.screen === 'intro' || S.screen === 'credits')) { S.screen = 'ledger'; return; }
    if (k === 'Enter' || k === 'Space' || k === 'Escape') advance(k === 'Escape');
  }
  function onKeyUp(ev) { var k = KEYMAP[ev.code]; if (k) S.keys[k] = false; if (S.D && !anyKey()) { if (S.D.kbSweep) { S.D.kbSweep = false; SND.rod(null); } } }
  function anyKey() { return S.keys.up || S.keys.down || S.keys.left || S.keys.right; }
  function pauseChoose(i) {
    SND.cue('sfx_ui', 0.5);
    if (i === 0) S.screen = 'field';
    else if (i === 1) { S.ret = 'field'; S.screen = 'help'; S.page = 0; }
    else if (i === 2) { S.screen = 'ledger'; S.book = S.D.n - 1; SND.setMood(0); }
    else if (i === 3) { SND.toggleMute(); }
    else if (i === 4) { S.screen = 'title'; SND.setMood(0); }
  }
  /* the generic "go on" for every card */
  function advance(back) {
    SND.cue('sfx_page', 0.45);
    if (S.screen === 'title') { S.screen = 'ledger'; S.book = firstOpen(); SND.setMood(0); return; }
    if (S.screen === 'ledger') { var n = S.book + 1; if (n > FIELDS.length) { S.msg(FULL ? 'NOT YET.' : 'FIELDS ' + (FIELDS.length + 1) + ' TO ' + TOTAL + ' ARE IN THE FULL GAME.'); S.lastRefusal = 'locked-demo'; return; } if (!unlocked(n)) { S.msg('CLEAR FIELD ' + (n - 1) + ' FIRST.'); S.lastRefusal = 'locked'; return; } S.introN = n; S.page = 0; S.screen = 'intro'; return; }
    if (S.screen === 'intro') { var rec = FIELDS[S.introN - 1]; var pages = rec.rulePage ? 2 : 1; if (back) { S.screen = 'ledger'; return; } if (S.page + 1 < pages) { S.page++; return; } openField(S.introN); return; }
    if (S.screen === 'field' && S.D && S.D.done) { afterResult(); return; }
    if (S.screen === 'demoend') { S.screen = 'ledger'; S.book = FIELDS.length - 1; return; }
    if (S.screen === 'ending') { S.screen = 'credits'; return; }
    if (S.screen === 'credits') { S.screen = 'ledger'; return; }
  }
  function afterResult() {
    var D = S.D, r = S.result;
    if (r.seal === 'bust' || r.seal === 'empty') { reopen(); return; }
    SND.setMood(0);
    if (D.n === FIELDS.length && !FULL) { S.screen = 'demoend'; return; }
    if (D.n === TOTAL && FULL) { S.screen = 'ending'; return; }
    S.screen = 'ledger'; S.book = Math.min(D.n, FIELDS.length - 1);
  }
  function firstOpen() { for (var n = 1; n <= FIELDS.length; n++) if (!clearedSeal(n)) return n - 1; return 0; }

  // ---- drawing helpers -----------------------------------------------------------------------------
  /* every line of text is bounds-checked against the canvas: an overflow is RECORDED, and the playthrough fails on any */
  var OVERFLOW = {};
  function text(s, x, y, o) {
    o = o || {};
    var w = F.width(s, o.face), x0 = o.align === 'center' ? x - w / 2 : o.align === 'right' ? x - w : x;
    if (x0 < 0 || x0 + w > W || y < 0 || y + (o.face === 'display' ? 12 : 7) > H) OVERFLOW[S.screen + ':' + String(s).slice(0, 40)] = [Math.round(x0), Math.round(x0 + w), y];
    return F.text(g, s, x, y, o);
  }
  function wrap(s, maxChars) {
    var words = String(s).split(' '), lines = [], cur = '';
    words.forEach(function (w) { if ((cur + ' ' + w).trim().length > maxChars) { lines.push(cur.trim()); cur = w; } else cur = (cur + ' ' + w).trim(); });
    if (cur) lines.push(cur); return lines;
  }
  function box(x, y, w, h, fill, edge) { g.fillStyle = fill || COL.panel; g.fillRect(x, y, w, h); g.fillStyle = edge || COL.edge; g.fillRect(x, y, w, 1); g.fillRect(x, y + h - 1, w, 1); g.fillRect(x, y, 1, h); g.fillRect(x + w - 1, y, 1, h); }
  function drawButton(b) {
    var hover = S.mouse && S.mouse[0] >= b.x && S.mouse[1] >= b.y && S.mouse[0] < b.x + b.w && S.mouse[1] < b.y + b.h;
    box(b.x, b.y, b.w, b.h, !b.enabled ? '#1a1510' : b.hot ? (hover ? '#5c3a14' : '#46290c') : (hover ? '#3b2d1d' : '#2c2218'), b.enabled ? (b.hot ? COL.gold : COL.edge) : '#3a3026');
    text(b.label, b.x + b.w / 2, b.y + Math.floor((b.h - 7) / 2), { align: 'center', colour: b.enabled ? (b.hot ? COL.gold : COL.ink) : COL.faint });
  }
  function vignette(strength) {
    var grd = g.createRadialGradient(W / 2, H / 2, 60, W / 2, H / 2, 300);
    grd.addColorStop(0, 'rgba(0,0,0,0)'); grd.addColorStop(1, 'rgba(0,0,0,' + strength + ')');
    g.fillStyle = grd; g.fillRect(0, 0, W, H);
  }
  var BIG = {};
  function bigText(s, cx, y, scale, colour, outline) {
    var key = s + '|' + colour + '|' + outline;
    if (!BIG[key]) {
      var c = document.createElement('canvas'); c.width = F.width(s, 'display') + 2; c.height = 14;
      var cg = c.getContext('2d'); F.text(cg, s, 1, 1, { face: 'display', colour: colour, outline: outline }); BIG[key] = c;
    }
    var im = BIG[key], w = im.width * scale;
    if (cx - w / 2 < 0 || cx + w / 2 > W) OVERFLOW['big:' + s] = [Math.round(cx - w / 2), Math.round(cx + w / 2), y];
    g.drawImage(im, Math.round(cx - w / 2), y, w, im.height * scale);
  }
  function sealIcon(x, y, kind) {
    var c = kind === 'clean' ? '#e8bc4c' : kind === 'dug' ? '#b98a4a' : kind === 'bust' ? '#b23a30' : kind === 'empty' ? '#6b6f78' : null;
    if (!c) { g.fillStyle = '#3a2e22'; g.fillRect(x + 2, y + 3, 5, 1); return; }
    g.fillStyle = c; g.fillRect(x + 1, y, 7, 9); g.fillRect(x, y + 1, 9, 7);
    g.fillStyle = 'rgba(0,0,0,0.3)'; g.fillRect(x + 3, y + 3, 3, 3);
  }
  var MATNAME = { bronze: 'BRONZE', bone: 'BONE', iron: 'IRON', void: 'A VOID', shell: 'A LIVE SHELL', earth: 'BARE EARTH' };
  /* a find drawn by its CONTENT box (atlas.json box), centred in (cx, cy), at the largest integer scale fitting maxW x maxH */
  function drawFind(name, cx, cy, maxW, maxH) {
    var t = A.tiles['find_' + name]; if (!t) { art.missing['find_' + name] = 1; return; }
    // at most 2x, one scale feel for the whole cabinet (review #12: 4x skulls beside 1x lanterns read as mush), and CLIPPED
    // to its cell (the lantern's post rose out of its cell)
    var b = t.box || [0, 0, t.r[2], t.r[3]], s = Math.max(1, Math.min(2, Math.floor(Math.min(maxW / b[2], maxH / b[3]))));
    g.save(); g.beginPath(); g.rect(Math.round(cx - maxW / 2), Math.round(cy - maxH / 2), maxW, maxH); g.clip();
    g.drawImage(img, t.r[0] + b[0], t.r[1] + b[1], b[2], b[3], Math.round(cx - b[2] * s / 2), Math.round(cy - b[3] * s / 2), b[2] * s, b[3] * s);
    g.restore();
  }
  function findLabel(name) { return String(name || '').replace(/_/g, ' ').toUpperCase(); }
  /* the brief as [relics, everything else] - "3 RELICS" and "1 SHELL, 1 IRON, 1 VOID" */
  function briefParts(rec) { var p = String(rec.brief).split(', '); return [p[0], p.slice(1).join(', ')]; }
  /* the ledger's short form (a column holds 22 characters): relics and shells only */
  function briefShort(rec) { var p = String(rec.brief).split(', '); return p[0] + (p[1] && /SHELL/.test(p[1]) ? ', ' + p[1] : ''); }

  // ---- the rod and the gauge --------------------------------------------------------------------------
  function drawRod(D) {
    if (!D.rod || D.done) return;
    var x = D.ox + D.rod[0] * T, y = D.oy + D.rod[1] * T, v = D.reading || 0;
    // the hazel fork: two arms from the hands (off the bottom-right) meeting at the tip
    g.strokeStyle = 'rgba(0,0,0,0.45)'; g.lineWidth = 2;
    g.beginPath(); g.moveTo(x + 1, y + 1); g.lineTo(x + 15, y + 23); g.moveTo(x + 1, y + 1); g.lineTo(x + 23, y + 13); g.stroke();
    g.strokeStyle = '#7a4f24'; g.lineWidth = 1.6;
    g.beginPath(); g.moveTo(x, y); g.lineTo(x + 14, y + 22); g.moveTo(x, y); g.lineTo(x + 22, y + 12); g.stroke();
    g.strokeStyle = '#c28a4a'; g.lineWidth = 0.8;
    g.beginPath(); g.moveTo(x, y - 1); g.lineTo(x + 14, y + 21); g.stroke();
    g.lineWidth = 1;
    // the brass bob at the tip, lit by the reading
    var glow = v > 0 ? Math.min(1, v / 14) : 0, cold = v < 0 ? Math.min(1, -v / 6) : 0;
    if (glow > 0.05) { var grd = g.createRadialGradient(x, y, 1, x, y, 10 + 8 * glow); grd.addColorStop(0, 'rgba(255,210,110,' + (0.5 * glow) + ')'); grd.addColorStop(1, 'rgba(255,210,110,0)'); g.fillStyle = grd; g.fillRect(x - 20, y - 20, 40, 40); }
    if (cold > 0.05) { var grc = g.createRadialGradient(x, y, 1, x, y, 12); grc.addColorStop(0, 'rgba(140,170,255,' + (0.45 * cold) + ')'); grc.addColorStop(1, 'rgba(140,170,255,0)'); g.fillStyle = grc; g.fillRect(x - 14, y - 14, 28, 28); }
    g.fillStyle = '#2a1a06'; g.fillRect(Math.round(x) - 2, Math.round(y) - 2, 5, 5);
    g.fillStyle = '#e2b24c'; g.fillRect(Math.round(x) - 1, Math.round(y) - 1, 3, 3);
    g.fillStyle = '#fff2c0'; g.fillRect(Math.round(x) - 1, Math.round(y) - 1, 1, 1);
  }
  var G_MIN = -8, G_MAX = 24;
  function drawGauge(cx, cy, r, value, live) {
    // bezel
    g.fillStyle = '#0d0a07'; g.beginPath(); g.arc(cx, cy, r + 6, Math.PI, 0); g.lineTo(cx + r + 6, cy + 8); g.lineTo(cx - r - 6, cy + 8); g.closePath(); g.fill();
    g.fillStyle = '#7a5a26'; g.beginPath(); g.arc(cx, cy, r + 4, Math.PI, 0); g.lineTo(cx + r + 4, cy + 6); g.lineTo(cx - r - 4, cy + 6); g.closePath(); g.fill();
    g.fillStyle = '#d9b566'; g.beginPath(); g.arc(cx, cy, r + 2, Math.PI, 0); g.lineTo(cx + r + 2, cy + 4); g.lineTo(cx - r - 2, cy + 4); g.closePath(); g.fill();
    // the face: aged paper, with the cool band below the line and the warm band above
    g.fillStyle = '#efe2bf'; g.beginPath(); g.arc(cx, cy, r, Math.PI, 0); g.lineTo(cx + r, cy + 2); g.lineTo(cx - r, cy + 2); g.closePath(); g.fill();
    var ang = function (v) { return Math.PI + (v - G_MIN) / (G_MAX - G_MIN) * Math.PI; };
    g.lineWidth = 5;
    g.strokeStyle = 'rgba(90,120,210,0.55)'; g.beginPath(); g.arc(cx, cy, r - 7, ang(G_MIN), ang(0)); g.stroke();
    g.strokeStyle = 'rgba(214,140,40,0.55)'; g.beginPath(); g.arc(cx, cy, r - 7, ang(0), ang(G_MAX)); g.stroke();
    g.lineWidth = 1;
    // ticks: every step a short tick, every 4 a long one with a numeral
    for (var v = G_MIN; v <= G_MAX; v++) {
      var a = ang(v), long = v % 4 === 0, r0 = r - (long ? 12 : 9), r1 = r - 3;
      g.strokeStyle = v === 0 ? '#1b1208' : '#5a4428'; g.lineWidth = v === 0 ? 2 : 1;
      g.beginPath(); g.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0); g.lineTo(cx + Math.cos(a) * r1, cy + Math.sin(a) * r1); g.stroke();
      // negatives carry their minus sign (review #7: -4 printed as a blue 4)
      if (long && v !== G_MIN && v !== G_MAX) { var tx = cx + Math.cos(a) * (r - 20), ty = cy + Math.sin(a) * (r - 20); F.text(g, String(v), Math.round(tx), Math.round(ty) - 3, { colour: v < 0 ? '#3c5aa8' : '#5a3a14', align: 'center' }); }
    }
    g.lineWidth = 1;
    // the maker's label sits low on the face, under the pivot's arc, clear of the numerals
    text('DOWSING', cx, cy - 14, { align: 'center', colour: '#a08a5a' });
    // the needle, with a shadow; it trembles a little while the rod is live
    var vv = Math.max(G_MIN - 0.6, Math.min(G_MAX + 0.6, value + (live ? Math.sin(S.t * 31) * 0.12 : 0)));
    var na = ang(vv), nx = cx + Math.cos(na) * (r - 5), ny = cy + Math.sin(na) * (r - 5);
    g.strokeStyle = 'rgba(0,0,0,0.35)'; g.lineWidth = 2; g.beginPath(); g.moveTo(cx + 1, cy + 1); g.lineTo(nx + 1, ny + 1); g.stroke();
    g.strokeStyle = '#8a1e14'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(cx, cy); g.lineTo(nx, ny); g.stroke();
    g.lineWidth = 1;
    g.fillStyle = '#3a2410'; g.fillRect(cx - 4, cy - 3, 9, 7); g.fillStyle = '#e0b04a'; g.fillRect(cx - 2, cy - 1, 5, 3);
  }

  // ---- the field screen ----------------------------------------------------------------------------
  function drawField() {
    BUTTONS.length = 0;
    var D = S.D;
    g.fillStyle = COL.bg; g.fillRect(0, 0, W, H);
    var shake = D.shake && S.t - D.shake < 0.5 ? Math.round(Math.sin(S.t * 90) * 3 * (1 - (S.t - D.shake) / 0.5)) : 0;
    g.save(); g.translate(shake, 0);
    g.drawImage(D.layer, SX, SY);
    if (D.traceDirty) renderTrace(D);
    g.drawImage(D.trace, D.ox, D.oy);
    // the rope and its pegs
    var x0 = D.ox - 1, y0 = D.oy - 1, x1 = D.ox + D.fw * T, y1 = D.oy + D.fh * T;
    g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(x0 + 1, y1 + 1, x1 - x0, 1); g.fillRect(x1 + 1, y0 + 1, 1, y1 - y0);
    g.fillStyle = '#d8c79c'; g.fillRect(x0, y0, x1 - x0 + 1, 1); g.fillRect(x0, y1, x1 - x0 + 1, 1); g.fillRect(x0, y0, 1, y1 - y0); g.fillRect(x1, y0, 1, y1 - y0 + 1);
    [[x0, y0], [x1, y0], [x0, y1], [x1, y1]].forEach(function (q) { g.fillStyle = '#3a2410'; g.fillRect(q[0] - 2, q[1] - 2, 5, 5); g.fillStyle = '#a8793e'; g.fillRect(q[0] - 1, q[1] - 1, 3, 3); });
    // hovered tile
    if (S.mouse && inPlot(S.mouse) && !D.done) {
      var ht = toTiles(S.mouse), hx = Math.floor(ht[0]), hy = Math.floor(ht[1]);
      if (S.stakeMode || D.stakes.length) { g.strokeStyle = S.stakeMode ? 'rgba(240,194,78,0.8)' : 'rgba(241,231,207,0.25)'; g.strokeRect(D.ox + hx * T + 0.5, D.oy + hy * T + 0.5, T - 1, T - 1); }
    }
    // dug holes
    D.dug.forEach(function (d) { drawHole(D, d); });
    // stakes
    D.stakes.forEach(function (s, i) { drawStake(D.ox + s[0] * T + 8, D.oy + s[1] * T + 8, i + 1); });
    if (D.digging) { var st = D.digging.queue[D.digging.i]; if (st) drawSpade(D.ox + st[0] * T + 8, D.oy + st[1] * T + 8, D.digging.t / DIG_T); }
    if (D.reveal) drawReveal(D);
    drawRod(D);
    g.restore();
    vignette(0.28);
    drawPanel(D);
    drawBar(D);
    if (D.done) drawResult(D);
    else if (D.plates.length && S.t - D.plates[D.plates.length - 1].t < 1.6) drawPlate(D.plates[D.plates.length - 1], 1 - (S.t - D.plates[D.plates.length - 1].t) / 1.6);
  }
  function drawStake(x, y, n) {
    g.fillStyle = 'rgba(0,0,0,0.4)'; g.fillRect(x - 1, y + 1, 3, 3);
    g.fillStyle = '#5a3a18'; g.fillRect(x, y - 9, 2, 11);
    g.fillStyle = '#c8413a'; g.fillRect(x + 2, y - 9, 6, 4); g.fillStyle = '#8e2a22'; g.fillRect(x + 2, y - 6, 6, 1);
    // the number sits to the right of the flag, so stakes a tile apart never stack labels on poles (review #17)
    F.text(g, String(n), x + 10, y - 10, { colour: '#fff0c8', outline: '#2a1206' });
  }
  function drawSpade(x, y, k) {
    var lift = Math.round(Math.abs(Math.sin(k * Math.PI * 2)) * 5);
    g.fillStyle = 'rgba(0,0,0,0.4)'; g.fillRect(x - 3, y + 3, 7, 2);
    g.fillStyle = '#6a4a26'; g.fillRect(x, y - 16 - lift, 2, 12);
    g.fillStyle = '#9aa2ae'; g.fillRect(x - 2, y - 5 - lift, 6, 6); g.fillStyle = '#d5dbe2'; g.fillRect(x - 2, y - 5 - lift, 6, 1);
    g.fillStyle = '#5a3a18'; for (var i = 0; i < 3; i++) g.fillRect(x - 4 + Math.round(ih(i, S.frames, 3) * 9), y + 1 - Math.round(ih(i, S.frames, 7) * 4), 2, 2);
  }
  function drawHole(D, d) {
    var x = D.ox + d.tx * T, y = D.oy + d.ty * T;
    g.fillStyle = '#2a1a0c'; g.fillRect(x + 3, y + 5, 10, 7); g.fillRect(x + 4, y + 4, 8, 9);
    g.fillStyle = '#140c05'; g.fillRect(x + 5, y + 6, 6, 5);
    g.fillStyle = '#7a5a34'; g.fillRect(x + 2, y + 12, 3, 2); g.fillRect(x + 11, y + 3, 3, 2);
    if (d.what === 'bronze') { g.fillStyle = '#f0c24e'; g.fillRect(x + 6, y + 7, 4, 3); g.fillStyle = '#fff2c0'; g.fillRect(x + 7, y + 7, 1, 1); }
    else if (d.what === 'bone') { g.fillStyle = '#ece6d6'; g.fillRect(x + 5, y + 8, 6, 2); g.fillRect(x + 5, y + 7, 1, 4); g.fillRect(x + 10, y + 7, 1, 4); }
    else if (d.what === 'iron') { g.fillStyle = '#8a4a2a'; g.fillRect(x + 5, y + 7, 6, 3); g.fillStyle = '#b86a3a'; g.fillRect(x + 6, y + 7, 2, 1); }
    else if (d.what === 'void') { g.fillStyle = '#05070c'; g.fillRect(x + 4, y + 5, 8, 7); g.fillStyle = 'rgba(140,170,255,0.35)'; g.fillRect(x + 4, y + 5, 8, 1); }
    else if (d.what === 'shell') {
      var k = Math.min(1, (S.t - d.t) / 0.6);
      g.fillStyle = '#0a0604'; g.fillRect(x - 2, y, 20, 15); g.fillRect(x, y - 2, 16, 19);
      g.fillStyle = 'rgba(255,170,60,' + (0.9 * (1 - k)) + ')'; g.beginPath(); g.arc(x + 8, y + 8, 6 + 26 * k, 0, Math.PI * 2); g.fill();
      g.fillStyle = 'rgba(120,110,100,' + (0.5 * (1 - k * 0.6)) + ')'; for (var i = 0; i < 6; i++) g.fillRect(x + 8 + Math.round(Math.cos(i) * 10 * k), y + 4 - Math.round(12 * k) - i * 2, 4, 3);
    }
  }
  /* the season map: after the last dig every buried thing shows where it lay */
  function drawReveal(D) {
    var k = Math.min(1, (S.t - D.doneT) / 0.8);
    D.objects.forEach(function (o) {
      if (dugAt(D, Math.floor(o.x), Math.floor(o.y))) return;
      var x = D.ox + o.x * T, y = D.oy + o.y * T;
      g.globalAlpha = k;
      var c = o.mat === 'shell' ? '#e2503e' : o.mat === 'iron' ? '#b8703e' : o.mat === 'void' ? '#8fb0ff' : o.mat === 'bronze' ? '#f0c24e' : '#ece6d6';
      g.strokeStyle = 'rgba(0,0,0,0.6)'; g.strokeRect(Math.round(x) - 5.5, Math.round(y) - 5.5, 12, 12);
      g.strokeStyle = c; g.strokeRect(Math.round(x) - 4.5, Math.round(y) - 4.5, 10, 10);
      if (o.mat === 'shell') { g.fillStyle = c; g.fillRect(Math.round(x) - 1, Math.round(y) - 3, 3, 4); g.fillRect(Math.round(x) - 1, Math.round(y) + 2, 3, 1); }
      g.globalAlpha = 1;
    });
  }
  function drawPlate(p, a) {
    var x = SX + SW / 2 - 70, y = SY + 40;
    g.globalAlpha = Math.min(1, a * 3);
    box(x, y, 140, 104, '#241a12', COL.gold);
    g.fillStyle = '#16100b'; g.fillRect(x + 6, y + 6, 128, 72);
    drawFind(p.find, x + 70, y + 42, 120, 64);
    text('A FIND', x + 70, y + 80, { align: 'center', colour: COL.faint });
    text(findLabel(p.find), x + 70, y + 90, { align: 'center', colour: COL.gold });
    g.globalAlpha = 1;
  }
  function drawPanel(D) {
    var X = PX0;
    box(X, 3, 165, 212, COL.panel, COL.edge);
    text('FIELD ' + D.n, X + 82, 7, { face: 'display', align: 'center', colour: COL.gold });
    text(D.hall.title, X + 82, 21, { align: 'center', colour: COL.dim });
    var live = D.dragging || !!D.kbSweep;
    // the gauge sits clear of the hall name (its bezel once cut through "THE THISTLE FIELD": store plate look, 09-19)
    drawGauge(X + 82, 99, 60, D.needle, live);
    var rd = D.reading;
    text(live && rd !== null ? (rd > 0 ? 'RISING ' + rd : rd < 0 ? 'SINKING ' + (-rd) : 'QUIET') : 'THE ROD IS STILL', X + 82, 112, { align: 'center', colour: live ? (rd > 0 ? COL.gold : rd < 0 ? COL.cool : COL.dim) : COL.faint });
    // what lies here (relics on one line, the rest on the next: a one-line brief with a void in it ran off the canvas,
    // play_through paid 2026-09-19), and the stakes
    var rec = D.rec, bp = briefParts(rec);
    text(bp[0], X + 82, 122, { align: 'center', colour: COL.gold });
    text(bp[1] || 'AND NOTHING ELSE', X + 82, 131, { align: 'center', colour: COL.ink });
    var left = rec.stakes - D.stakes.length;
    // a flag is red only for a stake actually placed (review #9: every flag went red at the dig, used or not)
    var committed = D.digging ? D.digging.queue.length : D.done ? D.dug.length : D.stakes.length;
    for (var i = 0; i < rec.stakes; i++) {
      var sx = X + 82 - rec.stakes * 6 + i * 12, used = i < committed;
      g.fillStyle = used ? '#5a3a18' : '#3a2e22'; g.fillRect(sx + 3, 141, 2, 9);
      g.fillStyle = used ? '#c8413a' : '#4a3a2c'; g.fillRect(sx + 5, 141, 5, 3);
    }
    text(D.done ? 'THE SPADE IS DOWN' : D.digging ? 'DIGGING' : left + ' OF ' + rec.stakes + ' STAKES LEFT', X + 82, 153, { align: 'center', colour: COL.dim });
    var blocked = digBlocked();
    drawButton(button('dig', X + 4, 164, 157, 14, D.digging ? 'DIGGING...' : 'DIG THE STAKES', !blocked, true));
    drawButton(button('stake', X + 4, 181, 77, 12, S.stakeMode ? 'STAKE: ON' : 'STAKE MODE', !D.done && !D.digging, S.stakeMode));
    drawButton(button('pull', X + 84, 181, 77, 12, 'PULL STAKES', !D.done && !D.digging && D.stakes.length > 0));
    drawButton(button('notes', X + 4, 196, 50, 12, 'NOTES', true));
    drawButton(button('menu', X + 57, 196, 50, 12, 'MENU', true));
    drawButton(button('mute', X + 110, 196, 51, 12, SND.muted ? 'SOUND OFF' : 'SOUND ON', true));
  }
  function drawBar(D) {
    box(3, 218, 474, 49, '#1a140e', COL.edge);
    var l1 = '';
    // while the keyboard walks the rod, the line reads the ROD's spot, not a stale mouse spot (review #15)
    var probe = D.kbSweep && D.rod ? D.rod : (S.mouse && inPlot(S.mouse) ? toTiles(S.mouse) : null);
    if (probe) {
      var tp = probe, tx = Math.floor(tp[0]), ty = Math.floor(tp[1]), dd = dugAt(D, tx, ty);
      if (dd) l1 = 'DUG: ' + (dd.what === 'bronze' || dd.what === 'bone' ? MATNAME[dd.what] + ', ' + findLabel(dd.find) : MATNAME[dd.what]);
      else {
        // the reading the rod left on this exact spot, if it has been swept
        var cx = Math.floor(tp[0] * RES), cy = Math.floor(tp[1] * RES), ci = cy * D.fw * RES + cx, rv = D.swept[ci] ? D.cells[ci] : null;
        var rtxt = rv === null ? 'NOT SWEPT YET' : rv > 0 ? 'THE ROD READ +' + rv + ' HERE' : rv < 0 ? 'THE ROD READ -' + (-rv) + ' HERE' : 'THE ROD READ NOTHING HERE';
        l1 = (stakeAt(D, tx, ty) >= 0 ? 'A STAKE. ' : '') + rtxt + '  (SPOT ' + (tx + 1) + ',' + (ty + 1) + ')';
      }
    } else l1 = 'SWEPT ' + Math.round(100 * D.sweptN / D.swept.length) + '% OF THE PLOT';
    text(l1, 8, 222, { colour: COL.ink });
    if (S.msgs[0] && S.t - S.msgT < 6) text(S.msgs[0], 8, 233, { colour: S.t - S.msgT < 3 ? COL.gold : COL.dim });
    else text('GOAL: STAKE EVERY RELIC, NOTHING ELSE, THEN DIG. A LIVE SHELL LOSES THE DAY.', 8, 233, { colour: COL.faint });
    text('MOUSE: DRAG SWEEPS, RIGHT-CLICK STAKES, ENTER DIGS', 8, 245, { colour: COL.faint });
    text('KEYS: ARROWS SWEEP, E STAKE, X PULL ALL, H NOTES, ESC MENU, M SOUND', 8, 256, { colour: COL.faint });
  }
  function drawResult(D) {
    var r = S.result, k = Math.min(1, (S.t - r.t) / 0.5);
    if (S.t - r.t < 0.9) return;                        // let the season map land first
    /* The verdict is a BANNER over the bottom bar, never a panel over the plot: the panel hid the season map the reveal
     * exists to show (store plate look, 2026-09-19). */
    var x = 3, y = 218, w = 474, h = 49;
    g.globalAlpha = k;
    box(x, y, w, h, '#241a12', r.seal === 'bust' ? COL.red : COL.gold);
    // titles say what the spade actually hit (fresh review #8: iron dug was titled NOTHING BUT EARTH, one relic in three
    // was THE CART IS LOADED)
    var hitOther = r.iron ? 'IRON' : r.voids ? 'A VOID' : 'BARE EARTH';
    var title = r.seal === 'bust' ? 'THE SHELL WENT UP' : r.seal === 'clean' ? 'A CLEAN DIG' : r.seal === 'empty' ? 'NO RELIC CAME UP'
      : r.found < r.of ? 'A PARTIAL HAUL' : r.retry ? 'CLEAN, SECOND TIME' : 'EVERY RELIC, AND A WASTED STAKE';
    if (r.seal !== 'bust') sealIcon(x + 7, y + 7, r.seal);
    text(title, x + (r.seal !== 'bust' ? 21 : 8), y + 5, { face: 'display', colour: r.seal === 'bust' ? COL.red : COL.gold });
    var lines = r.seal === 'bust'
      ? ['NOBODY IS HURT, BUT THE DAY\'S FINDS ARE LOST. THE SQUARES SHOW WHERE EVERYTHING LAY.']
      : r.retry ? ['EVERY RELIC, BUT THE GROUND HAD ALREADY SHOWN YOU. A CLEAN SEAL IS ONLY EARNED ON THE FIRST DIG.']
      : ['RELICS ' + r.found + ' OF ' + r.of + ' / WASTED STAKES ' + r.wasted + '. ' + (r.seal === 'clean' ? 'EVERY RELIC, AND NOT ONE STAKE WASTED.' : r.seal === 'empty' ? 'THE SPADE FOUND ' + hitOther + '. THE SQUARES SHOW WHERE THE RELICS LAY.' : 'THE SQUARES SHOW WHAT YOU LEFT IN THE GROUND.')];
    // hovering a dug spot on the finished plot names it here (the bar it used to live in is under this banner: review #10)
    if (S.mouse && inPlot(S.mouse)) { var tq = toTiles(S.mouse), dq = dugAt(D, Math.floor(tq[0]), Math.floor(tq[1])); if (dq) lines = ['DUG HERE: ' + (dq.what === 'bronze' || dq.what === 'bone' ? MATNAME[dq.what] + ', ' + findLabel(dq.find) : MATNAME[dq.what]) + '.']; }
    // wrapped to the space left of the buttons (a 54-character line once ran off the canvas: play_through, 2026-09-19)
    var yy = y + 21; lines.forEach(function (l) { wrap(l, 45).forEach(function (wl) { text(wl, x + 8, yy, { colour: COL.ink }); yy += 9; }); });
    var cont = r.seal === 'bust' || r.seal === 'empty' ? 'ENTER: DIG AGAIN' : 'ENTER: THE LEDGER';
    drawButton(button('result-next', x + w - 150, y + 7, 142, 15, cont, true, true));
    if (r.seal !== 'bust' && r.seal !== 'empty') drawButton(button('again', x + w - 150, y + 27, 142, 13, 'DIG IT AGAIN (R)', true));
    g.globalAlpha = 1;
  }

  // ---- other screens --------------------------------------------------------------------------------
  function drawTitle() {
    BUTTONS.length = 0;
    g.fillStyle = COL.bg; g.fillRect(0, 0, W, H);
    if (S.exhibit) { g.drawImage(S.exhibit.cv, Math.round((W - S.exhibit.cv.width) / 2), Math.round((H - S.exhibit.cv.height) / 2)); }
    g.fillStyle = 'rgba(10,6,4,0.30)'; g.fillRect(0, 0, W, H);
    vignette(0.6);
    g.fillStyle = 'rgba(14,9,5,0.80)'; g.fillRect(0, 50, W, 70);
    g.fillStyle = COL.edge; g.fillRect(0, 50, W, 1); g.fillRect(0, 119, W, 1);
    bigText('DOWSER', W / 2, 56, 3, COL.gold, '#2a1206');
    g.fillStyle = '#c8413a'; g.fillRect(W / 2 - 120, 99, 240, 1);
    text('READ THE GROUND BY HAND. DIG FOR RELICS. LEAVE THE SHELLS.', W / 2, 106, { align: 'center', colour: COL.ink, outline: '#1a0c06' });
    if (Math.floor(S.t * 2) % 2 === 0) text('CLICK OR PRESS ENTER', W / 2, 190, { align: 'center', colour: COL.gold, outline: '#1a0c06' });
    g.fillStyle = 'rgba(14,9,5,0.80)'; g.fillRect(0, 208, W, 30);
    text('MOUSE: DRAG THE ROD, RIGHT-CLICK A STAKE, ENTER DIGS  /  KEYS: ARROWS, E, ENTER', W / 2, 212, { align: 'center', colour: COL.ink, outline: '#1a0c06' });
    text((FULL ? 'THE FULL SEASON: ' + TOTAL + ' FIELDS' : 'FREE DEMO: THE FIRST ' + FIELDS.length + ' OF ' + TOTAL + ' FIELDS') + '  /  M: SOUND ' + (SND.muted ? 'OFF' : 'ON'), W / 2, 225, { align: 'center', colour: COL.gold, outline: '#1a0c06' });
    text('CORE SYSTEMS ASSET FACTORY', W / 2, 252, { align: 'center', colour: COL.dim, outline: '#1a0c06' });
  }
  function drawLedger() {
    BUTTONS.length = 0;
    g.fillStyle = COL.bg; g.fillRect(0, 0, W, H);
    box(10, 8, 460, 254, '#241a12', COL.edge);
    text('THE SEASON LEDGER', W / 2, 16, { face: 'display', align: 'center', colour: COL.gold });
    var halls = root.DW_HALL_ORDER || [];
    halls.forEach(function (h, col) {
      var x = 22 + col * 150;
      text(h.label, x, 40, { colour: COL.dim });
      for (var n = h.from; n <= h.to; n++) {
        var y = 56 + (n - h.from) * 30, sel = S.book === n - 1, have = n <= FIELDS.length, open = have && unlocked(n);
        var hov = S.mouse && S.mouse[0] >= x - 4 && S.mouse[0] < x + 140 && S.mouse[1] >= y - 4 && S.mouse[1] < y + 22;
        if (sel || hov) { g.fillStyle = sel ? '#3b2a1b' : '#2e2217'; g.fillRect(x - 4, y - 4, 144, 26); if (sel) { g.fillStyle = COL.gold; g.fillRect(x - 4, y - 4, 2, 26); } }
        BUTTONS.push({ id: 'field:' + n, x: x - 4, y: y - 4, w: 144, h: 26, enabled: true });
        var rec = FIELDS[n - 1];
        sealIcon(x, y, sealOf(n));
        text(n + '. ' + (have ? rec.title : 'IN THE FULL GAME'), x + 14, y, { colour: !have ? COL.faint : open ? (sel ? COL.gold : COL.ink) : COL.faint });
        var s = sealOf(n);
        text(!have ? '' : !open ? 'CLEAR FIELD ' + (n - 1) + ' FIRST' : s === 'clean' ? 'A CLEAN DIG' : s === 'dug' ? 'DUG' : s === 'bust' ? 'LOST TO A SHELL' : s === 'empty' ? 'NOTHING FOUND' : briefShort(rec), x + 14, y + 10, { colour: COL.faint });
      }
    });
    var cleanCount = Object.keys(save.seals).filter(function (k) { return save.seals[k] === 'clean'; }).length;
    text('CLEAN DIGS ' + cleanCount + ' OF ' + TOTAL + '  /  FINDS ' + Object.keys(save.finds).length + '  /  CLICK A FIELD OR ARROWS + ENTER', 22, 216, { colour: COL.dim });
    drawButton(button('ledger-notes', 22, 238, 84, 13, 'NOTES', true));
    drawButton(button('ledger-cabinet', 110, 238, 84, 13, 'THE CABINET', true));
    drawButton(button('ledger-credits', 198, 238, 84, 13, 'CREDITS', true));
    drawButton(button('ledger-title', 286, 238, 84, 13, 'TITLE', true));
    drawButton(button('mute', 374, 238, 84, 13, SND.muted ? 'SOUND OFF' : 'SOUND ON', true));
    if (S.msgs[0] && S.t - S.msgT < 4) text(S.msgs[0], 22, 226, { colour: COL.gold });
  }
  function drawIntro() {
    BUTTONS.length = 0;
    var rec = FIELDS[S.introN - 1];
    g.fillStyle = COL.bg; g.fillRect(0, 0, W, H);
    box(40, 20, 400, 230, '#241a12', COL.edge);
    if (rec.rulePage && S.page === 0) {
      text('A NEW NOTE FOR THE BOOK', W / 2, 30, { align: 'center', colour: COL.faint });
      text(rec.rulePage.title, W / 2, 42, { face: 'display', align: 'center', colour: COL.gold });
      rulePicture(rec.rulePage.id, W / 2, 98);
      var yy = 152; rec.rulePage.lines.forEach(function (l) { wrap(l, 60).forEach(function (w) { text(w, W / 2, yy, { align: 'center', colour: COL.ink }); yy += 10; }); yy += 3; });
      text('ENTER: THE FIELD', W / 2, 238, { align: 'center', colour: COL.gold });
      return;
    }
    var hall = hallOf(rec.hall);
    text('FIELD ' + rec.n + ' / ' + hall.title, W / 2, 28, { align: 'center', colour: COL.faint });
    text(rec.title, W / 2, 40, { face: 'display', align: 'center', colour: COL.gold });
    var y = 60; rec.story.forEach(function (l) { wrap(l, 62).forEach(function (w) { text(w, W / 2, y, { align: 'center', colour: COL.ink }); y += 10; }); y += 3; });
    y += 4;
    text('UNDER THIS GROUND: ' + rec.brief, W / 2, y, { align: 'center', colour: COL.gold }); y += 12;
    text('YOU HAVE ' + rec.stakes + ' STAKES. STAKE THE RELICS, THEN DIG.', W / 2, y, { align: 'center', colour: COL.dim });
    // the card used to be half empty: show the field itself, unswept, at half size (the ground and ruins you will read)
    if (!S.introLayer || S.introLayer.n !== rec.n) {
      var DD = { n: rec.n, hall: hall, fw: rec.W, fh: rec.H, ox: SX + Math.floor((SW - rec.W * T) / 2), oy: SY + Math.floor((SH - rec.H * T) / 2) };
      S.introLayer = { n: rec.n, cv: composeScene(DD), ox: DD.ox - SX, oy: DD.oy - SY, fw: rec.W, fh: rec.H };
    }
    var L = S.introLayer, tx = W / 2 - 76, ty = y + 14;
    g.fillStyle = COL.edge; g.fillRect(tx - 2, ty - 2, 156, 109);
    g.imageSmoothingEnabled = true; g.drawImage(L.cv, tx, ty, 152, 105); g.imageSmoothingEnabled = false;
    g.fillStyle = '#d8c79c'; var rx = tx + Math.round(L.ox / 2), ry = ty + Math.round(L.oy / 2), rw = L.fw * 8, rh = L.fh * 8;
    g.fillRect(rx, ry, rw, 1); g.fillRect(rx, ry + rh, rw + 1, 1); g.fillRect(rx, ry, 1, rh); g.fillRect(rx + rw, ry, 1, rh);
    text('ENTER OR CLICK: BEGIN  /  ESC: BACK', W / 2, 238, { align: 'center', colour: COL.gold });
  }
  /* The notes' pictures are drawn BY THE ENGINE: each is a real sweep of js/field.js over one buried thing, in the same
   * heat colours the plot uses, plus the needle's line along the centre pass. The picture cannot teach a different rule. */
  var RULE_OBJ = {
    rise: [{ mat: 'bronze', x: 3, y: 1.5, d: 0.5 }, { mat: 'bone', x: 9, y: 1.5, d: 0.5 }],
    ring: [{ mat: 'shell', x: 3, y: 1.5, d: 0.5 }, { mat: 'bronze', x: 9, y: 1.5, d: 0.5 }],
    depth: [{ mat: 'bronze', x: 3, y: 1.5, d: 0.5 }, { mat: 'bronze', x: 9, y: 1.5, d: 2.5 }],
    swing: [{ mat: 'iron', x: 3, y: 1.5, d: 0.5 }, { mat: 'bronze', x: 9, y: 1.5, d: 0.5 }],
    sink: [{ mat: 'void', x: 3, y: 1.5, d: 0.5 }, { mat: 'bone', x: 9, y: 1.5, d: 0.5 }],
    pair: [{ mat: 'bronze', x: 2.5, y: 1.5, d: 1.5 }, { mat: 'bone', x: 3.5, y: 1.5, d: 1.5 }, { mat: 'iron', x: 9, y: 1.5, d: 1.5 }]
  };
  var RULE_CACHE = {};
  function rulePicture(id, cx, cy) {
    var objs = RULE_OBJ[id]; if (!objs) return;
    if (!RULE_CACHE[id]) {
      var c = document.createElement('canvas'); c.width = 12 * T; c.height = 3 * T; var cg = c.getContext('2d');
      // the same renderer as the plot: a fully swept 12 x 3 strip, fills and contour lines
      var RD = { fw: 12, fh: 3, trace: c, tg: cg, cells: new Int16Array(12 * RES * 3 * RES), swept: new Uint8Array(12 * RES * 3 * RES) };
      for (var yy = 0; yy < 3 * RES; yy++) for (var xx = 0; xx < 12 * RES; xx++) { var k = yy * 12 * RES + xx; RD.cells[k] = FD.gauge(FD.readAt(objs, (xx + 0.5) / RES, (yy + 0.5) / RES)); RD.swept[k] = 1; }
      renderTrace(RD);
      RULE_CACHE[id] = c;
    }
    var x0 = Math.round(cx - 6 * T), y0 = Math.round(cy - 34);
    g.fillStyle = '#3b3222'; g.fillRect(x0 - 2, y0 - 2, 12 * T + 4, 3 * T + 4);
    g.fillStyle = '#4a3b26'; g.fillRect(x0, y0, 12 * T, 3 * T);
    g.drawImage(RULE_CACHE[id], x0, y0);
    // the needle along the centre pass, west to east
    var gy = y0 + 3 * T + 26;
    g.fillStyle = '#1a130e'; g.fillRect(x0, gy - 20, 12 * T, 30);
    g.fillStyle = '#5a4428'; g.fillRect(x0, gy, 12 * T, 1);
    var prev = null;
    for (var px = 0; px <= 12 * T; px++) {
      var v2 = FD.gauge(FD.readAt(objs, px / T, 1.5)), yv = gy - Math.max(-9, Math.min(19, v2)) * 1;
      if (prev !== null) { g.fillStyle = v2 < 0 ? COL.cool : COL.gold; g.fillRect(x0 + px, Math.min(prev, yv), 1, Math.abs(prev - yv) + 1); }
      prev = yv;
    }
    text('W', x0 - 8, gy - 3, { colour: COL.faint }); text('E', x0 + 12 * T + 3, gy - 3, { colour: COL.faint });
  }
  function helpPages() {
    var known = [], maxN = 0;
    Object.keys(save.seals).forEach(function (k) { maxN = Math.max(maxN, +k); });
    if (S.D) maxN = Math.max(maxN, S.D.n);
    FIELDS.forEach(function (c) { if (c.rulePage && c.n <= Math.max(1, maxN)) known.push(c.rulePage); });
    return [{ id: 'basics' }].concat(known);
  }
  function drawHelp() {
    BUTTONS.length = 0;
    g.fillStyle = COL.bg; g.fillRect(0, 0, W, H);
    box(30, 12, 420, 246, '#241a12', COL.edge);
    var pages = helpPages(), pg = pages[Math.min(S.page, pages.length - 1)];
    text('THE DOWSER\'S NOTES  ' + (S.page + 1) + ' / ' + pages.length, W / 2, 20, { align: 'center', colour: COL.faint });
    if (pg.id === 'basics') {
      text('HOW TO PLAY', W / 2, 34, { face: 'display', align: 'center', colour: COL.gold });
      var lines = [
        'DRAG THE ROD ACROSS THE ROPED PLOT. THE NEEDLE AND THE TONE FOLLOW WHATEVER LIES UNDER THE TIP, AND THE GRASS KEEPS A GLOW OF EVERYTHING YOU HAVE SWEPT.',
        'WARM MEANS SOMETHING BURIED PULLS THE NEEDLE UP. COOL MEANS IT SINKS BELOW THE LINE.',
        'EACH FIELD TELLS YOU WHAT IS BURIED AND GIVES YOU A FEW STAKES. RIGHT-CLICK A SPOT (OR USE STAKE MODE) TO PLACE ONE, THEN PRESS DIG.',
        'DIG A RELIC AND IT GOES IN THE CART. DIG IRON, A VOID OR BARE EARTH AND THE STAKE IS WASTED. DIG A LIVE SHELL AND THE DAY\'S FINDS ARE LOST.',
        'COUNT THE RISES: EVERY RELIC AND EVERY IRON MAKES ONE ROUND GLOW. STAKE THE CENTRE OF EACH RELIC\'S GLOW, AND HOVER TO READ EXACT NUMBERS.',
        'KEYS: ARROWS SWEEP / E STAKE / X PULL STAKES / ENTER DIG / T STAKE MODE / H NOTES / ESC MENU'
      ];
      var y = 54; lines.forEach(function (l) { wrap(l, 66).forEach(function (w) { text(w, 42, y, { colour: COL.ink }); y += 10; }); y += 4; });
    } else {
      text(pg.title, W / 2, 34, { face: 'display', align: 'center', colour: COL.gold });
      rulePicture(pg.id, W / 2, 90);
      var yy = 146; pg.lines.forEach(function (l) { wrap(l, 62).forEach(function (w) { text(w, W / 2, yy, { align: 'center', colour: COL.ink }); yy += 10; }); yy += 3; });
    }
    drawButton(button('help-prev', 40, 240, 70, 13, 'PREV', S.page > 0));
    drawButton(button('help-back', 205, 240, 70, 13, 'BACK', true, true));
    drawButton(button('help-next', 370, 240, 70, 13, 'NEXT', S.page < pages.length - 1));
    text('A/D OR ARROWS', W / 2, 230, { align: 'center', colour: COL.faint });
  }
  function drawCabinet() {
    BUTTONS.length = 0;
    g.fillStyle = COL.bg; g.fillRect(0, 0, W, H);
    box(10, 8, 460, 254, '#241a12', COL.edge);
    text('THE CABINET', W / 2, 16, { face: 'display', align: 'center', colour: COL.gold });
    var all = A.finds.bronze.concat(A.finds.bone), cols = 7;
    all.forEach(function (name, i) {
      var x = 24 + (i % cols) * 62, y = 36 + Math.floor(i / cols) * 58, have = save.finds[name];
      g.fillStyle = '#16100b'; g.fillRect(x, y, 58, 54);
      g.fillStyle = '#2c2219'; g.fillRect(x, y + 53, 58, 1);
      if (have) drawFind(name, x + 29, y + 27, 54, 50);
      else { g.fillStyle = '#2a2016'; g.fillRect(x + 23, y + 20, 12, 12); text('?', x + 29, y + 23, { align: 'center', colour: COL.faint }); }
      if (have > 1) text('X' + have, x + 55, y + 45, { align: 'right', colour: COL.dim });
    });
    text('FINDS ' + Object.keys(save.finds).length + ' OF ' + all.length + '. EVERY RELIC YOU DIG CLEAN COMES HOME TO THIS CABINET.', W / 2, 214, { align: 'center', colour: COL.dim });
    drawButton(button('cabinet-back', W / 2 - 45, 238, 90, 13, 'BACK', true, true));
  }
  function drawPause() {
    drawField(); BUTTONS.length = 0;
    g.fillStyle = 'rgba(8,5,3,0.7)'; g.fillRect(0, 0, W, H);
    box(114, 66, 252, 136, '#241a12', COL.edge);
    text('PAUSED', W / 2, 76, { face: 'display', align: 'center', colour: COL.gold });
    ['RESUME', 'NOTES', 'LEDGER', 'SOUND: ' + (SND.muted ? 'OFF' : 'ON'), 'TITLE'].forEach(function (l, i) {
      drawButton(button('p' + i, 180, 98 + i * 16, 120, 13, l, true, i === S.pauseSel));
    });
    text('CLICK, OR ARROWS + ENTER. ESC RESUMES.', W / 2, 186, { align: 'center', colour: COL.dim });
  }
  function drawCard(title, lines, foot) {
    BUTTONS.length = 0;
    g.fillStyle = COL.bg; g.fillRect(0, 0, W, H);
    box(30, 20, 420, 230, '#241a12', COL.edge);
    text(title, W / 2, 32, { face: 'display', align: 'center', colour: COL.gold });
    var y = 60; lines.forEach(function (l) { if (!l) { y += 6; return; } wrap(l, 64).forEach(function (w) { text(w, W / 2, y, { align: 'center', colour: COL.ink }); y += 10; }); y += 3; });
    text(foot, W / 2, 236, { align: 'center', colour: COL.gold });
  }
  function drawDemoEnd() {
    drawCard('THE SEASON GOES ON', [
      'YOU HAVE DUG THE FIRST ' + FIELDS.length + ' FIELDS.',
      '',
      'THE FULL GAME HAS ' + TOTAL + ' FIELDS OVER THREE DIGS: THE THISTLE FIELD, THE MOSAIC FLOOR AND THE COLONNADE, WITH HOLLOWS THAT SINK THE NEEDLE, CROWDED GROUND, MORE SHELLS AND IRON, AND THE WHOLE CABINET OF FINDS TO FILL.',
      '',
      'IT IS A DOWNLOAD FOR WINDOWS ON THIS PAGE. THANK YOU FOR PLAYING THE DEMO.'
    ], 'ENTER: BACK TO THE LEDGER');
  }
  function drawEnding() {
    var clean = 0; for (var n = 1; n <= TOTAL; n++) if (sealOf(n) === 'clean') clean++;
    drawCard('THE SEASON CLOSES', (root.DW_ENDING || []).concat(['', 'CLEAN DIGS: ' + clean + ' OF ' + TOTAL + '.  FINDS IN THE CABINET: ' + Object.keys(save.finds).length + '.']), 'ENTER: CREDITS');
    // the card's lower half carries the season's own haul: the first finds in the cabinet, on a shelf
    var got = A.finds.bronze.concat(A.finds.bone).filter(function (nm) { return save.finds[nm]; }).slice(0, 10);
    if (got.length) {
      var sw = got.length * 38, x0 = Math.round(W / 2 - sw / 2);
      g.fillStyle = '#16100b'; g.fillRect(x0 - 6, 158, sw + 12, 52); g.fillStyle = '#5a4428'; g.fillRect(x0 - 6, 204, sw + 12, 2);
      got.forEach(function (nm, i) { drawFind(nm, x0 + i * 38 + 19, 182, 34, 42); });
    }
  }
  function drawCredits() {
    drawCard('DOWSER', [
      'A GAME BY CORE SYSTEMS ASSET FACTORY.',
      '',
      'ART: CSAF TILESET VERDANT 23 RUINS AND CSAF SPRITES MOURNCREST 05 GRAVE GOODS, COMPOSED BY THE GAME. THE ROD, THE GAUGE AND THE GLOW ARE DRAWN BY THE GAME.',
      'MUSIC AND SOUND: SYNTHESISED BY CSAF FROM NOTE DATA. NO SAMPLES. THE ROD\'S TONE IS PLAYED LIVE FROM THE READING.',
      'LETTERING: CSAF.',
      '',
      'MADE WITH AI: THE CODE, THE ART AND THE TEXT WERE MADE WITH AI TOOLS. THE SOUND IS PROCEDURAL.',
      '',
      'THANK YOU FOR READING THE GROUND.'
    ], 'ENTER: LEDGER');
  }

  // ---- the clock ------------------------------------------------------------------------------------
  function tick(dt) {
    S.t += dt; S.frames++;
    var D = S.D;
    if (S.screen === 'field' && D) {
      if (D.digging) stepDig(dt);
      else if (!D.done) {
        // keyboard sweep: the arrows walk the rod and it reads as it goes
        var vx = (S.keys.right ? 1 : 0) - (S.keys.left ? 1 : 0), vy = (S.keys.down ? 1 : 0) - (S.keys.up ? 1 : 0);
        if (vx || vy) {
          if (!D.rod) D.rod = [D.fw / 2, D.fh / 2];
          var sp = 3.2 * dt, nr = [Math.max(0, Math.min(D.fw - 0.001, D.rod[0] + vx * sp)), Math.max(0, Math.min(D.fh - 0.001, D.rod[1] + vy * sp))];
          sweep(D, D.rod, nr); D.rod = nr; D.kbSweep = true;
        }
      }
      var live = D.dragging || D.kbSweep;
      D.reading = live ? readRod(D) : null;
      var target = live && D.reading !== null ? D.reading : 0;
      D.needle += (target - D.needle) * Math.min(1, dt * 14);
      if (live && !D.done && !D.digging) SND.rod(D.reading); else if (SND.voice) SND.rod(null);
    }
  }
  function draw() {
    if (art.failed) { g.fillStyle = '#200a0a'; g.fillRect(0, 0, W, H); text('THE ART FAILED TO LOAD: ' + art.failed.toUpperCase(), W / 2, H / 2, { align: 'center', colour: '#ffb4a8' }); return; }
    if (!art.ready) { g.fillStyle = COL.bg; g.fillRect(0, 0, W, H); text('LOADING', W / 2, H / 2, { align: 'center', colour: COL.dim }); return; }
    if (root.DW_EXHIBIT && !S.exhibit) S.exhibit = buildExhibit(root.DW_EXHIBIT);
    if (S.screen === 'title') drawTitle();
    else if (S.screen === 'ledger') drawLedger();
    else if (S.screen === 'intro') drawIntro();
    else if (S.screen === 'field') drawField();
    else if (S.screen === 'pause') drawPause();
    else if (S.screen === 'help') drawHelp();
    else if (S.screen === 'cabinet') drawCabinet();
    else if (S.screen === 'demoend') drawDemoEnd();
    else if (S.screen === 'ending') drawEnding();
    else if (S.screen === 'credits') drawCredits();
  }
  /* the title's backdrop: a finished plot, fully swept, drawn by the same code as play */
  function buildExhibit(ex) {
    var keep = { D: S.D, screen: S.screen };
    var hall = hallOf(ex.hall), D = { n: 0, rec: ex, hall: hall, fw: ex.W, fh: ex.H, ox: SX + Math.floor((SW - ex.W * T) / 2), oy: SY + Math.floor((SH - ex.H * T) / 2), objects: ex.objects,
      cells: new Int16Array(ex.W * RES * ex.H * RES), swept: new Uint8Array(ex.W * RES * ex.H * RES), sweptN: 0 };
    D.layer = composeScene(D);
    D.trace = document.createElement('canvas'); D.trace.width = ex.W * T; D.trace.height = ex.H * T; D.tg = D.trace.getContext('2d');
    for (var y = 0.25; y < ex.H; y += 0.5) sweep(D, [0, y], [ex.W - 0.001, y]);
    renderTrace(D);
    var c = document.createElement('canvas'); c.width = SW; c.height = SH; var cg = c.getContext('2d'); cg.imageSmoothingEnabled = false;
    cg.drawImage(D.layer, 0, 0); cg.drawImage(D.trace, D.ox - SX, D.oy - SY);
    S.D = keep.D; S.screen = keep.screen;
    var big = document.createElement('canvas'); big.width = W; big.height = H; var bg2 = big.getContext('2d'); bg2.imageSmoothingEnabled = false;
    // an exact 2x, cropped to the canvas: fills it edge to edge with square pixels (review #16: 1.5x left dark bars)
    bg2.drawImage(c, 0, 0, SW, SH, Math.round((W - SW * 2) / 2), Math.round((H - SH * 2) / 2), SW * 2, SH * 2);
    return { cv: big };
  }
  var last = null;
  function frame(ts) {
    if (last === null) last = ts;
    var dt = Math.min(0.05, (ts - last) / 1000); last = ts;
    tick(dt); draw();
    root.requestAnimationFrame(frame);
  }
  /* a phone held upright shrinks the canvas below 1x and the lettering drops rows (review #13): say so, plainly */
  var turn = document.createElement('div');
  turn.style.cssText = 'position:fixed;left:0;right:0;top:12px;text-align:center;font:15px/1.4 system-ui,sans-serif;color:#f0c24e;display:none;pointer-events:none';
  turn.textContent = 'Turn your phone sideways to play DOWSER.';
  document.body.appendChild(turn);
  function fit() {
    var s = Math.min(root.innerWidth / W, root.innerHeight / H);
    if (s >= 2) s = Math.floor(s);
    cv.style.width = Math.floor(W * s) + 'px'; cv.style.height = Math.floor(H * s) + 'px';
    turn.style.display = root.innerHeight > root.innerWidth && s < 1 ? 'block' : 'none';
  }
  root.addEventListener('resize', fit); fit();
  cv.addEventListener('mousedown', onDown);
  root.addEventListener('mousemove', onMove);
  root.addEventListener('mouseup', onUp);
  cv.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  cv.addEventListener('touchstart', function (e) { e.preventDefault(); var t0 = e.changedTouches[0]; onDown({ clientX: t0.clientX, clientY: t0.clientY, button: 0 }); }, { passive: false });
  cv.addEventListener('touchmove', function (e) { e.preventDefault(); var t0 = e.changedTouches[0]; onMove({ clientX: t0.clientX, clientY: t0.clientY }); }, { passive: false });
  cv.addEventListener('touchend', function (e) { e.preventDefault(); onUp(); }, { passive: false });
  root.addEventListener('keydown', onKey);
  root.addEventListener('keyup', onKeyUp);
  root.addEventListener('blur', function () { S.keys = {}; if (S.D) { S.D.dragging = false; S.D.kbSweep = false; } SND.rod(null); });
  SND.load();
  // ?harness=1: the harness owns the clock (a background tab gets no rAF at all, §6b-18); a player never sees it
  var HARNESS = /[?&]harness=1/.test(location.search);
  if (!HARNESS) root.requestAnimationFrame(frame);

  // ---- the harness hook: the SHIPPED page, driven, never a copy of it --------------------------------
  root.__dwTick = function (n, dt) { for (var i = 0; i < (n || 1); i++) tick(dt || 1 / 60); draw(); return S.frames; };
  root.DW_GAME = {
    S: S, save: function () { return JSON.parse(JSON.stringify(save)); }, openField: openField, toggleStake: toggleStake, startDig: startDig, sweep: function (a, b) { sweep(S.D, a, b); S.D.rod = b; },
    digBlocked: digBlocked, buttons: function () { return BUTTONS.slice(); }, fields: function () { return FIELDS.length; }, total: TOTAL, full: FULL,
    fontMissing: F.missing, artMissing: art.missing, overflow: OVERFLOW, advance: advance, press: press,
    snapshot: function () { var D = S.D; return { screen: S.screen, fieldN: D ? D.n : null, stakes: D ? D.stakes.slice() : null, dug: D ? D.dug.map(function (d) { return { tx: d.tx, ty: d.ty, what: d.what }; }) : null,
      done: D ? D.done : null, bust: D ? D.bust : null, haul: D ? D.haul : null, swept: D ? D.sweptN : null, result: S.result, msgs: S.msgs.slice(), lastRefusal: S.lastRefusal,
      seals: JSON.parse(JSON.stringify(save.seals)), finds: Object.keys(save.finds).length, sound: SND.report() }; }
  };
})(window);
