# Dowser

Minesweeper with no numbers. Sweep a dowsing rod over an old field and read the ground by hand: the needle and the
tone follow whatever lies under the tip, and the grass keeps a glow of everything you have swept. Stake the relics,
leave the live shells where they lie, then dig.

There are two editions on the same page:

- **The free browser demo**: the first 4 of the 15 fields, in the Thistle Field.
- **The Windows download**: all 15 fields across the Thistle Field, the Mosaic Floor and the Colonnade, one more
  note to learn (voids), crowded and deeper ground, the full cabinet of finds, and the end of the season.

## How to play

- **Sweep**: press inside the roped plot and drag. The needle, the tone and the glow on the grass read the ground
  under the rod. Warm means something pulls the needle up; cool means it sinks below the line.
- **Stake**: right-click a spot (or turn on STAKE MODE and click or tap it) to place a stake. Each field tells you
  what is buried and gives you a few stakes. Right-click a stake again to pull it up.
- **Dig**: press DIG (or ENTER). Every stake is dug in turn. A relic goes in the cart. Iron, a void or bare earth
  wastes the stake. A live shell loses the day's finds, and you dig the field again.
- A **clean dig** means every relic and not one stake wasted, on your first dig of that field. Every result shows
  where everything lay, so a perfect second dig is recorded as dug, not clean.

Every field was checked before it shipped by a solver and by a rule-follower that uses only the game's notes, reading
the glow the way a player does: each one can be read without guessing. Stake the centre of a round glow, and hover
over swept ground to read its exact number. The notes are taught one at a time in the season ledger: relics rise,
a live shell rings, depth spreads, iron swings, and a void sinks.

### Keys

ARROWS sweep the rod · E stake or pull up · X pull every stake · ENTER dig · T stake mode · H notes · ESC menu ·
M sound on or off.

The game saves your digs and your cabinet of finds as you go.

## Requirements

The demo runs in any modern browser with a mouse, a keyboard or touch. The download is a portable Windows program:
run the .exe, nothing is installed.

## More from CSAF

Other games and tools by Core Systems Asset Factory: https://csaf.itch.io (including Stringline, a castle whodunit
where every clue is a line you draw).

## Credits

A game by Core Systems Asset Factory (CSAF).

- The ground and the ruins are from the CSAF tileset **Verdant 23 · Ruins**; the finds are from the CSAF sprite
  pack **Mourncrest 05 · Grave Goods**. The rod, the gauge and the glow are drawn by the game.
- Lettering drawn by CSAF. Music and sound synthesised by CSAF from note data; no samples. The rod's tone is played
  live from the reading.
- **Made with AI:** the code, art and words of this game were written with generative AI assistance.
  The music and sound are procedural synthesis, not generative audio.

© 2026 Core Systems Asset Factory. See LICENSE.txt.
