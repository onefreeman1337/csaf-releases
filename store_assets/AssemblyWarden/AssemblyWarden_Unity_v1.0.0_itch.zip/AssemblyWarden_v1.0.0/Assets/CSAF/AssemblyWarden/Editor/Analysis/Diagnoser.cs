// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

using System;
using System.Collections.Generic;
using CSAF.AssemblyWarden.Model;
using CSAF.AssemblyWarden.Rules;
using ReflectionAssembly = System.Reflection.Assembly;

namespace CSAF.AssemblyWarden.Analysis
{
    /// <summary>
    /// Turns the measured graph into verdicts.
    ///
    /// The central rule is that an absent AssemblyRef is NOT on its own proof that a reference is
    /// unnecessary. Two mechanisms make a genuinely required reference emit no AssemblyRef:
    ///
    ///  1. CONST INLINING. If assembly A uses only a <c>const</c> from assembly B, the compiler
    ///     bakes the literal into A and emits no reference to B — yet the build still needs B to
    ///     resolve the constant. The same is true of some attribute and default-parameter usages.
    ///  2. CONDITIONAL COMPILATION. A reference used only inside an inactive <c>#if</c> branch
    ///     emits nothing on the current platform. Deleting it breaks the buyer's OTHER build
    ///     target, which no recompile on this machine can detect.
    ///
    /// So every candidate is put through a second, independent channel — the assembly's own source
    /// text — and anything that channel touches is downgraded to <see cref="ReferenceVerdict.Uncertain"/>
    /// and never removed automatically. The diagnosis fails toward keeping a reference, always.
    /// </summary>
    public static class Diagnoser
    {
        public static void Diagnose(WardenReport report)
        {
            if (report == null || report.Refused) return;

            var signalCache = new Dictionary<string, HashSet<string>>(StringComparer.Ordinal);

            for (int i = 0; i < report.Nodes.Count; i++)
            {
                AssemblyNode node = report.Nodes[i];
                HashSet<string>? identifiers = null;

                for (int r = 0; r < node.DeclaredReferences.Count; r++)
                {
                    ReferenceEntry entry = node.DeclaredReferences[r];

                    if (!node.CompiledOutputReadable)
                    {
                        entry.Verdict = ReferenceVerdict.Unknown;
                        entry.Uncertainty = UncertaintyReason.AssemblyNotLoaded;
                        entry.Explanation =
                            "No compiled assembly named '" + node.Name + "' is loaded, so the emitted " +
                            "reference table could not be read. Nothing is concluded about this reference.";
                        continue;
                    }

                    string? resolvedOrNull = entry.ResolvedName;
                    if (resolvedOrNull == null || resolvedOrNull.Length == 0)
                    {
                        entry.Verdict = ReferenceVerdict.Uncertain;
                        entry.Uncertainty = UncertaintyReason.AssemblyNotLoaded;
                        entry.Explanation =
                            "This entry (" + entry.RawValue + ") does not resolve to an assembly " +
                            "definition in this project. That is worth a look by hand — it is left " +
                            "untouched rather than guessed at.";
                        continue;
                    }

                    string resolved = resolvedOrNull;
                    if (GraphReader.IsIgnored(resolved))
                    {
                        entry.Verdict = ReferenceVerdict.Required;
                        entry.Explanation = "Engine or runtime assembly. Never a removal candidate.";
                        continue;
                    }

                    if (node.ActualReferences.Contains(resolved))
                    {
                        entry.Verdict = ReferenceVerdict.Required;
                        entry.Explanation =
                            "The compiler emitted an AssemblyRef to '" + resolved +
                            "'. The code genuinely uses it.";
                        continue;
                    }

                    // Candidate for removal. Corroborate before believing it.
                    if (identifiers == null) identifiers = GraphReader.ReadSourceIdentifiers(node.Name);
                    HashSet<string> signals = SignalsFor(resolved, signalCache);

                    string? hit = FirstIntersection(identifiers, signals);
                    if (hit != null)
                    {
                        entry.Verdict = ReferenceVerdict.Uncertain;
                        entry.Uncertainty = UncertaintyReason.SourceMentionsAssembly;
                        entry.Explanation =
                            "No AssemblyRef was emitted, but the source of '" + node.Name +
                            "' mentions '" + hit + "', which belongs to '" + resolved +
                            "'. That is the signature of a const, attribute or default-parameter " +
                            "usage the compiler inlined. Left in place.";
                        continue;
                    }

                    if (node.HasConditionalCompilation)
                    {
                        entry.Verdict = ReferenceVerdict.Uncertain;
                        entry.Uncertainty = UncertaintyReason.ConditionalCompilation;
                        entry.Explanation =
                            "No AssemblyRef was emitted, but '" + node.Name + "' contains " +
                            "preprocessor conditionals. A reference used only on another platform " +
                            "looks identical to an unused one from here, and a recompile on this " +
                            "machine cannot tell them apart. Left in place.";
                        continue;
                    }

                    entry.Verdict = ReferenceVerdict.Redundant;
                    entry.Explanation =
                        "The compiler emitted no AssemblyRef to '" + resolved +
                        "', and no identifier belonging to it appears anywhere in this assembly's " +
                        "source. Safe to remove — and the removal is still verified by a real " +
                        "recompile before it is kept.";
                }
            }

            EvaluateLayering(report);
        }

        private static void EvaluateLayering(WardenReport report)
        {
            LayeringRuleSet? ruleSet = LayeringRuleSet.FindInProject();
            if (ruleSet == null || ruleSet.Rules.Count == 0) return;

            for (int i = 0; i < report.Nodes.Count; i++)
            {
                AssemblyNode node = report.Nodes[i];

                for (int r = 0; r < ruleSet.Rules.Count; r++)
                {
                    LayeringRule rule = ruleSet.Rules[r];
                    if (!LayeringRuleSet.Matches(rule.From, node.Name)) continue;

                    // Declared edges.
                    for (int d = 0; d < node.DeclaredReferences.Count; d++)
                    {
                        string? to = node.DeclaredReferences[d].ResolvedName;
                        if (to == null || to.Length == 0) continue;
                        if (!LayeringRuleSet.Matches(rule.To, to)) continue;
                        AddViolation(report, rule, node.Name, to, true);
                    }

                    // Emitted edges that were never declared — a real violation the .asmdef hides.
                    for (int a = 0; a < node.UndeclaredReferences.Count; a++)
                    {
                        string to = node.UndeclaredReferences[a];
                        if (!LayeringRuleSet.Matches(rule.To, to)) continue;
                        AddViolation(report, rule, node.Name, to, false);
                    }
                }
            }
        }

        private static void AddViolation(WardenReport report, LayeringRule rule, string from, string to, bool declared)
        {
            for (int i = 0; i < report.Violations.Count; i++)
            {
                LayeringViolation v = report.Violations[i];
                if (v.RuleId == rule.Id && v.FromAssembly == from && v.ToAssembly == to) return;
            }

            report.Violations.Add(new LayeringViolation
            {
                RuleId = rule.Id,
                FromAssembly = from,
                ToAssembly = to,
                Note = rule.Note,
                IsDeclared = declared
            });
        }

        /// <summary>
        /// Identifiers that would appear in source if an assembly were used: its namespace segments
        /// and the short names of its exported types.
        /// </summary>
        private static HashSet<string> SignalsFor(string assemblyName, Dictionary<string, HashSet<string>> cache)
        {
            HashSet<string> cached;
            if (cache.TryGetValue(assemblyName, out cached)) return cached;

            var signals = new HashSet<string>(StringComparer.Ordinal);

            string[] segments = assemblyName.Split('.');
            for (int i = 0; i < segments.Length; i++)
            {
                if (segments[i].Length > 2) signals.Add(segments[i]);
            }

            ReflectionAssembly? loaded = FindLoaded(assemblyName);
            if (loaded != null)
            {
                // A partially loadable assembly still tells us plenty, so a
                // ReflectionTypeLoadException is harvested for the types that DID load rather than
                // discarded. Losing them here would silently weaken the corroboration channel and
                // push references toward "redundant" — the one direction that can break a build.
                var types = new List<Type>();
                try
                {
                    types.AddRange(loaded.GetTypes());
                }
                catch (System.Reflection.ReflectionTypeLoadException e)
                {
                    Type?[]? partial = e.Types;
                    if (partial != null)
                    {
                        for (int i = 0; i < partial.Length; i++)
                        {
                            Type? t = partial[i];
                            if (t != null) types.Add(t);
                        }
                    }
                }
                catch (Exception)
                {
                    // Unreadable metadata: the signal set stays as the namespace segments alone.
                }

                for (int i = 0; i < types.Count; i++)
                {
                    Type t = types[i];
                    if (!string.IsNullOrEmpty(t.Name)) signals.Add(StripGenericArity(t.Name));
                    string? ns = t.Namespace;
                    if (string.IsNullOrEmpty(ns)) continue;
                    string[] parts = ns.Split('.');
                    for (int n = 0; n < parts.Length; n++)
                    {
                        if (parts[n].Length > 2) signals.Add(parts[n]);
                    }
                }
            }

            cache[assemblyName] = signals;
            return signals;
        }

        private static string StripGenericArity(string name)
        {
            int tick = name.IndexOf('`');
            return tick < 0 ? name : name.Substring(0, tick);
        }

        private static ReflectionAssembly? FindLoaded(string name)
        {
            ReflectionAssembly[] all = AppDomain.CurrentDomain.GetAssemblies();
            for (int i = 0; i < all.Length; i++)
            {
                if (string.Equals(all[i].GetName().Name, name, StringComparison.Ordinal)) return all[i];
            }
            return null;
        }

        private static string? FirstIntersection(HashSet<string>? identifiers, HashSet<string>? signals)
        {
            if (identifiers == null || signals == null) return null;
            foreach (string s in signals)
            {
                if (identifiers.Contains(s)) return s;
            }
            return null;
        }
    }
}
