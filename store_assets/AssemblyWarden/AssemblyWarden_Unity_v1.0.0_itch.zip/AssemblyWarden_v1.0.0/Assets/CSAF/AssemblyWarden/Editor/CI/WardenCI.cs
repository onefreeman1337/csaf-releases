// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

using System;
using CSAF.AssemblyWarden.Analysis;
using CSAF.AssemblyWarden.Model;
using CSAF.AssemblyWarden.Reporting;
using UnityEditor;
using UnityEngine;

namespace CSAF.AssemblyWarden.CI
{
    /// <summary>
    /// The build-server entry point — the half of the product that keeps the graph correct after
    /// the day someone cleaned it up.
    ///
    /// <code>
    /// Unity.exe -batchmode -quit -projectPath &lt;project&gt; \
    ///           -executeMethod CSAF.AssemblyWarden.CI.WardenCI.Run \
    ///           -wardenFailOn layering,redundant \
    ///           -wardenReport artifacts/assembly-warden.json
    /// </code>
    ///
    /// Exit codes: 0 clean · 2 a fail-on condition was met · 3 the scan refused (the project does
    /// not compile, so the graph means nothing). Three codes, not two, because "could not measure"
    /// and "measured and it is bad" are different facts and a build log should never blur them.
    /// </summary>
    public static class WardenCI
    {
        private const string LogPrefix = "[Assembly Warden CI] ";

        public static void Run()
        {
            int code = Evaluate();
            if (Application.isBatchMode) EditorApplication.Exit(code);
        }

        /// <summary>Runs the gate and returns the exit code, without exiting. Callable from tests.</summary>
        public static int Evaluate()
        {
            string failOn = Arg("-wardenFailOn", "layering") ?? "layering";
            string? reportPath = Arg("-wardenReport", null);
            bool includePackages = HasFlag("-wardenIncludePackages");

            WardenReport report = GraphReader.Read(includePackages);
            Diagnoser.Diagnose(report);

            if (reportPath != null && reportPath.Length > 0)
            {
                try { ReportWriter.WriteJson(report, reportPath); }
                catch (Exception e) { Debug.LogWarning(LogPrefix + "Could not write report: " + e.Message); }
            }

            if (report.Refused)
            {
                Debug.LogError(LogPrefix + "REFUSED. " + report.RefusalReason);
                return 3;
            }

            int redundant = report.Count(ReferenceVerdict.Redundant);
            int uncertain = report.Count(ReferenceVerdict.Uncertain);
            int violations = report.Violations.Count;

            Debug.Log(LogPrefix + report.Nodes.Count + " assemblies · " + report.TotalDeclared +
                      " declared references · " + redundant + " redundant · " + uncertain +
                      " uncertain · " + violations + " layering violation(s).");

            for (int i = 0; i < report.Violations.Count; i++)
            {
                LayeringViolation v = report.Violations[i];
                Debug.LogError(LogPrefix + "LAYERING " + v.RuleId + ": " + v.FromAssembly + " -> " +
                               v.ToAssembly + (v.IsDeclared ? "" : " (emitted, never declared)") +
                               ". " + v.Note);
            }

            bool fail = false;
            if (Wants(failOn, "layering") && violations > 0) fail = true;
            if (Wants(failOn, "redundant") && redundant > 0) fail = true;
            if (Wants(failOn, "uncertain") && uncertain > 0) fail = true;

            if (fail)
            {
                Debug.LogError(LogPrefix + "FAILED on '" + failOn + "'.");
                return 2;
            }

            Debug.Log(LogPrefix + "PASS.");
            return 0;
        }

        private static bool Wants(string failOn, string key)
        {
            if (string.IsNullOrEmpty(failOn)) return false;
            string[] parts = failOn.Split(',');
            for (int i = 0; i < parts.Length; i++)
            {
                if (string.Equals(parts[i].Trim(), key, StringComparison.OrdinalIgnoreCase)) return true;
            }
            return false;
        }

        private static string? Arg(string name, string? fallback)
        {
            string[] args = Environment.GetCommandLineArgs();
            for (int i = 0; i < args.Length - 1; i++)
            {
                if (string.Equals(args[i], name, StringComparison.OrdinalIgnoreCase)) return args[i + 1];
            }
            return fallback;
        }

        private static bool HasFlag(string name)
        {
            string[] args = Environment.GetCommandLineArgs();
            for (int i = 0; i < args.Length; i++)
            {
                if (string.Equals(args[i], name, StringComparison.OrdinalIgnoreCase)) return true;
            }
            return false;
        }
    }
}
