// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

using System;
using System.Collections.Generic;
using CSAF.AssemblyWarden.Analysis;
using CSAF.AssemblyWarden.Apply;
using CSAF.AssemblyWarden.Model;
using CSAF.AssemblyWarden.Reporting;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace CSAF.AssemblyWarden.UI
{
    /// <summary>
    /// The Assembly Warden window: a drawn assembly graph, a verdict per reference with its
    /// reasoning in plain words, and a change you can read before it is written.
    /// </summary>
    public sealed class WardenWindow : EditorWindow
    {
        private const string IncludePackagesKey = "CSAF.AssemblyWarden.IncludePackages";

        private WardenReport? _report;
        private ApplyPlan? _plan;
        private AssemblyNode? _selected;

        // Assigned in CreateGUI, which Unity calls before any handler that reads them. The
        // null-forgiving operator states that contract instead of scattering guards through
        // every render method.
        private VisualElement _graphHost = null!;
        private VisualElement _sidebar = null!;
        private VisualElement _detail = null!;
        private Label _status = null!;

        private readonly Dictionary<string, Rect> _nodeRects = new Dictionary<string, Rect>(StringComparer.Ordinal);

        [MenuItem("Window/CSAF/Assembly Warden")]
        public static void Open()
        {
            var w = GetWindow<WardenWindow>();
            w.titleContent = new GUIContent("Assembly Warden");
            w.minSize = new Vector2(940f, 560f);
            w.Show();
        }

        private static bool IncludePackages
        {
            get { return EditorPrefs.GetBool(IncludePackagesKey, false); }
            set { EditorPrefs.SetBool(IncludePackagesKey, value); }
        }

        private void CreateGUI()
        {
            VisualElement root = rootVisualElement;
            root.style.backgroundColor = WardenStyles.Canvas;
            root.style.flexDirection = FlexDirection.Column;

            root.Add(BuildHeader());

            var body = new VisualElement();
            body.style.flexDirection = FlexDirection.Row;
            body.style.flexGrow = 1f;
            root.Add(body);

            _sidebar = new VisualElement();
            _sidebar.style.width = 268f;
            _sidebar.style.backgroundColor = WardenStyles.Panel;
            _sidebar.style.borderRightWidth = 1f;
            _sidebar.style.borderRightColor = WardenStyles.Line;
            body.Add(_sidebar);

            var right = new VisualElement();
            right.style.flexGrow = 1f;
            right.style.flexDirection = FlexDirection.Column;
            body.Add(right);

            _graphHost = new VisualElement();
            _graphHost.style.flexGrow = 1f;
            right.Add(_graphHost);

            _detail = new VisualElement();
            _detail.style.height = 208f;
            _detail.style.backgroundColor = WardenStyles.Panel;
            _detail.style.borderTopWidth = 1f;
            _detail.style.borderTopColor = WardenStyles.Line;
            right.Add(_detail);

            RenderEmpty();
        }

        private VisualElement BuildHeader()
        {
            var bar = new VisualElement();
            bar.style.flexDirection = FlexDirection.Row;
            bar.style.alignItems = Align.Center;
            bar.style.height = 46f;
            bar.style.backgroundColor = WardenStyles.Panel;
            bar.style.borderBottomWidth = 1f;
            bar.style.borderBottomColor = WardenStyles.Line;
            WardenStyles.Pad(bar, 0f, 12f, 0f, 14f);

            Label title = WardenStyles.Text("ASSEMBLY WARDEN", 12, WardenStyles.Ink, FontStyle.Bold);
            title.style.letterSpacing = 2f;
            title.style.marginRight = 6f;
            bar.Add(title);

            Label sub = WardenStyles.Text("a correct, minimal, enforced assembly graph", 10, WardenStyles.Muted);
            sub.style.marginRight = 18f;
            bar.Add(sub);

            bar.Add(Button("Scan", true, () => Scan()));
            bar.Add(Button("Preview changes", false, () => Preview()));
            bar.Add(Button("Apply + verify", false, () => Apply()));
            bar.Add(Button("Export report", false, () => Export()));

            var spacer = new VisualElement();
            spacer.style.flexGrow = 1f;
            bar.Add(spacer);

            var toggle = new Toggle("Include packages") { value = IncludePackages };
            toggle.style.marginRight = 12f;
            toggle.style.fontSize = 11;
            toggle.RegisterValueChangedCallback(e => IncludePackages = e.newValue);
            bar.Add(toggle);

            _status = WardenStyles.Text("Not scanned yet.", 11, WardenStyles.Muted);
            bar.Add(_status);

            return bar;
        }

        private VisualElement Button(string text, bool primary, Action action)
        {
            var b = new Button(action) { text = text };
            b.style.height = 24f;
            b.style.fontSize = 11;
            b.style.marginRight = 6f;
            b.style.paddingLeft = 12f;
            b.style.paddingRight = 12f;
            b.style.color = primary ? Color.white : WardenStyles.Ink;
            b.style.backgroundColor = primary ? WardenStyles.Accent : (WardenStyles.Dark ? new Color(0.212f, 0.227f, 0.263f) : new Color(1f, 1f, 1f));
            WardenStyles.Border(b, primary ? WardenStyles.Accent : WardenStyles.Line, 1f, 5f);
            return b;
        }

        // ---------------------------------------------------------------- actions

        private void Scan()
        {
            _plan = null;
            _selected = null;

            try
            {
                EditorUtility.DisplayProgressBar("Assembly Warden", "Reading the compiled assembly graph…", 0.35f);
                _report = GraphReader.Read(IncludePackages);
                EditorUtility.DisplayProgressBar("Assembly Warden", "Classifying declared references…", 0.75f);
                Diagnoser.Diagnose(_report);
                _plan = null;
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }

            RenderAll();
        }

        private void Preview()
        {
            if (!Ready()) return;

            _plan = ApplySession.BuildPlan(_report!);
            if (_plan.Files.Count == 0)
            {
                EditorUtility.DisplayDialog("Assembly Warden",
                    "Nothing to remove. Every declared reference is either required, or uncertain and " +
                    "therefore left alone on purpose.", "OK");
                return;
            }

            EditorUtility.DisplayDialog("Assembly Warden — preview",
                ApplySession.DescribePlan(_plan) +
                "\n\nNothing has been written. Choose \"Apply + verify\" to write these and recompile; " +
                "any compiler error restores every file to its original bytes.", "OK");
        }

        private void Apply()
        {
            if (!Ready()) return;
            if (_plan == null) _plan = ApplySession.BuildPlan(_report!);
            if (_plan.Files.Count == 0)
            {
                EditorUtility.DisplayDialog("Assembly Warden", "Nothing to apply.", "OK");
                return;
            }

            bool go = EditorUtility.DisplayDialog("Assembly Warden",
                ApplySession.DescribePlan(_plan) +
                "\n\nThese files will be rewritten and the project recompiled. If the compile fails, " +
                "every file is restored automatically.", "Apply and verify", "Cancel");
            if (!go) return;

            ApplySession.Apply(_plan);
            _plan = null;
        }

        private void Export()
        {
            if (!Ready()) return;
            string path = EditorUtility.SaveFilePanel("Export Assembly Warden report", "", "assembly-warden-report.json", "json");
            if (string.IsNullOrEmpty(path)) return;
            ReportWriter.WriteJson(_report!, path);
            Debug.Log("[Assembly Warden] Report written to " + path);
        }

        private bool Ready()
        {
            if (_report == null)
            {
                EditorUtility.DisplayDialog("Assembly Warden", "Run a scan first.", "OK");
                return false;
            }
            if (_report.Refused)
            {
                EditorUtility.DisplayDialog("Assembly Warden", _report.RefusalReason ?? string.Empty, "OK");
                return false;
            }
            return true;
        }

        // ---------------------------------------------------------------- rendering

        private void RenderEmpty()
        {
            _sidebar.Clear();
            _graphHost.Clear();
            _detail.Clear();

            var hint = new VisualElement();
            hint.style.flexGrow = 1f;
            hint.style.alignItems = Align.Center;
            hint.style.justifyContent = Justify.Center;

            Label a = WardenStyles.Text("Press Scan.", 15, WardenStyles.Ink, FontStyle.Bold);
            Label b = WardenStyles.Text(
                "Assembly Warden reads what the compiler actually emitted, not what your code appears to use.",
                11, WardenStyles.Muted);
            b.style.marginTop = 6f;
            b.style.maxWidth = 420f;
            b.style.unityTextAlign = TextAnchor.MiddleCenter;

            hint.Add(a);
            hint.Add(b);
            _graphHost.Add(hint);
        }

        private void RenderAll()
        {
            _sidebar.Clear();
            _graphHost.Clear();
            _detail.Clear();

            if (_report == null) { RenderEmpty(); return; }

            if (_report.Refused)
            {
                _status.text = "Refused.";
                _status.style.color = WardenStyles.Violation;

                var box = new VisualElement();
                WardenStyles.Pad(box, 24f, 24f, 24f, 24f);
                box.Add(WardenStyles.Text("The scan refused to draw conclusions", 14, WardenStyles.Violation, FontStyle.Bold));
                Label why = WardenStyles.Text(_report.RefusalReason ?? string.Empty, 11, WardenStyles.Ink);
                why.style.marginTop = 8f;
                why.style.maxWidth = 560f;
                box.Add(why);
                _graphHost.Add(box);
                return;
            }

            _status.text = _report.Nodes.Count + " assemblies · " + _report.TotalDeclared + " declared references";
            _status.style.color = WardenStyles.Muted;

            RenderSidebar();
            RenderGraph();
            RenderDetail(null);
        }

        private void RenderSidebar()
        {
            if (_report == null) return;

            var summary = new VisualElement();
            WardenStyles.Pad(summary, 12f, 12f, 12f, 12f);
            summary.style.borderBottomWidth = 1f;
            summary.style.borderBottomColor = WardenStyles.Line;
            summary.Add(WardenStyles.Text("VERDICTS", 9, WardenStyles.Muted, FontStyle.Bold));

            var chips = new VisualElement();
            chips.style.flexDirection = FlexDirection.Row;
            chips.style.flexWrap = Wrap.Wrap;
            chips.style.marginTop = 8f;
            chips.Add(WardenStyles.Chip(_report.Count(ReferenceVerdict.Required) + " required", WardenStyles.Required));
            chips.Add(WardenStyles.Chip(_report.Count(ReferenceVerdict.Redundant) + " redundant", WardenStyles.Redundant));
            chips.Add(WardenStyles.Chip(_report.Count(ReferenceVerdict.Uncertain) + " uncertain", WardenStyles.Uncertain));
            chips.Add(WardenStyles.Chip(_report.Count(ReferenceVerdict.Unknown) + " unknown", WardenStyles.Unknown));
            if (_report.Violations.Count > 0)
                chips.Add(WardenStyles.Chip(_report.Violations.Count + " layering", WardenStyles.Violation));
            summary.Add(chips);
            _sidebar.Add(summary);

            var scroll = new ScrollView(ScrollViewMode.Vertical);
            scroll.style.flexGrow = 1f;
            _sidebar.Add(scroll);

            for (int i = 0; i < _report.Nodes.Count; i++)
            {
                AssemblyNode node = _report.Nodes[i];
                scroll.Add(SidebarRow(node));
            }
        }

        private VisualElement SidebarRow(AssemblyNode node)
        {
            var row = new VisualElement();
            WardenStyles.Pad(row, 8f, 12f, 8f, 12f);
            row.style.borderBottomWidth = 1f;
            row.style.borderBottomColor = WardenStyles.Line;

            Label name = WardenStyles.Text(node.Name, 11, WardenStyles.Ink, FontStyle.Bold);
            row.Add(name);

            var chips = new VisualElement();
            chips.style.flexDirection = FlexDirection.Row;
            chips.style.marginTop = 4f;
            int red = node.CountOf(ReferenceVerdict.Redundant);
            int unc = node.CountOf(ReferenceVerdict.Uncertain);
            chips.Add(WardenStyles.Chip(node.DeclaredReferences.Count + " refs", WardenStyles.Muted));
            if (red > 0) chips.Add(WardenStyles.Chip(red + " redundant", WardenStyles.Redundant));
            if (unc > 0) chips.Add(WardenStyles.Chip(unc + " uncertain", WardenStyles.Uncertain));
            row.Add(chips);

            row.RegisterCallback<MouseDownEvent>(_ => { _selected = node; RenderDetail(node); });
            return row;
        }

        private void RenderGraph()
        {
            if (_report == null) return;

            _nodeRects.Clear();

            Dictionary<string, int> depth = ComputeDepths(_report);
            var columns = new Dictionary<int, int>();

            const float colWidth = 232f;
            const float rowHeight = 78f;
            const float nodeWidth = 188f;
            const float nodeHeight = 56f;

            float maxX = 0f, maxY = 0f;
            for (int i = 0; i < _report.Nodes.Count; i++)
            {
                AssemblyNode node = _report.Nodes[i];
                int d;
                if (!depth.TryGetValue(node.Name, out d)) d = 0;
                int slot;
                columns.TryGetValue(d, out slot);
                columns[d] = slot + 1;

                float x = 28f + d * colWidth;
                float y = 28f + slot * rowHeight;
                _nodeRects[node.Name] = new Rect(x, y, nodeWidth, nodeHeight);
                maxX = Mathf.Max(maxX, x + nodeWidth + 28f);
                maxY = Mathf.Max(maxY, y + nodeHeight + 28f);
            }

            var scroll = new ScrollView(ScrollViewMode.VerticalAndHorizontal);
            scroll.style.flexGrow = 1f;
            _graphHost.Add(scroll);

            var canvas = new VisualElement();
            canvas.style.width = Mathf.Max(maxX, 640f);
            canvas.style.height = Mathf.Max(maxY, 360f);
            scroll.Add(canvas);

            // Edges are painted behind the nodes, in one pass, only when the graph changes.
            var edges = new VisualElement();
            edges.style.position = Position.Absolute;
            edges.style.left = 0f;
            edges.style.top = 0f;
            edges.style.width = canvas.style.width.value.value;
            edges.style.height = canvas.style.height.value.value;
            edges.generateVisualContent += PaintEdges;
            canvas.Add(edges);

            for (int i = 0; i < _report.Nodes.Count; i++)
            {
                AssemblyNode node = _report.Nodes[i];
                canvas.Add(GraphNode(node, _nodeRects[node.Name]));
            }

            edges.MarkDirtyRepaint();
        }

        private void PaintEdges(MeshGenerationContext ctx)
        {
            if (_report == null) return;
            Painter2D p = ctx.painter2D;
            p.lineWidth = 1.4f;

            for (int i = 0; i < _report.Nodes.Count; i++)
            {
                AssemblyNode node = _report.Nodes[i];
                Rect from;
                if (!_nodeRects.TryGetValue(node.Name, out from)) continue;

                for (int r = 0; r < node.DeclaredReferences.Count; r++)
                {
                    ReferenceEntry entry = node.DeclaredReferences[r];
                    string? target = entry.ResolvedName;
                    if (target == null || target.Length == 0) continue;

                    Rect to;
                    if (!_nodeRects.TryGetValue(target, out to)) continue;

                    Color c = WardenStyles.For(entry.Verdict);
                    c.a = entry.Verdict == ReferenceVerdict.Required ? 0.45f : 0.95f;

                    var a = new Vector2(from.xMax, from.center.y);
                    var b = new Vector2(to.xMin, to.center.y);
                    float bow = Mathf.Max(36f, Mathf.Abs(b.x - a.x) * 0.45f);

                    p.strokeColor = c;
                    p.BeginPath();
                    p.MoveTo(a);
                    p.BezierCurveTo(new Vector2(a.x + bow, a.y), new Vector2(b.x - bow, b.y), b);
                    p.Stroke();
                }
            }
        }

        private VisualElement GraphNode(AssemblyNode node, Rect rect)
        {
            var card = new VisualElement();
            card.style.position = Position.Absolute;
            card.style.left = rect.x;
            card.style.top = rect.y;
            card.style.width = rect.width;
            card.style.height = rect.height;
            card.style.backgroundColor = WardenStyles.Panel;
            WardenStyles.Pad(card, 7f, 10f, 7f, 10f);

            int red = node.CountOf(ReferenceVerdict.Redundant);
            int unc = node.CountOf(ReferenceVerdict.Uncertain);
            Color edge = red > 0 ? WardenStyles.Redundant : (unc > 0 ? WardenStyles.Uncertain : WardenStyles.Line);
            WardenStyles.Border(card, edge, red > 0 ? 1.5f : 1f, 7f);

            Label name = WardenStyles.Text(Shorten(node.Name), 11, WardenStyles.Ink, FontStyle.Bold);
            name.style.overflow = Overflow.Hidden;
            card.Add(name);

            var meta = new VisualElement();
            meta.style.flexDirection = FlexDirection.Row;
            meta.style.marginTop = 4f;
            meta.Add(WardenStyles.Chip(node.SourceFileCount + " files", WardenStyles.Muted));
            if (red > 0) meta.Add(WardenStyles.Chip(red.ToString(), WardenStyles.Redundant));
            if (unc > 0) meta.Add(WardenStyles.Chip(unc.ToString(), WardenStyles.Uncertain));
            card.Add(meta);

            card.RegisterCallback<MouseDownEvent>(_ => { _selected = node; RenderDetail(node); });
            return card;
        }

        private static string Shorten(string name)
        {
            return name.Length <= 26 ? name : "…" + name.Substring(name.Length - 25);
        }

        private void RenderDetail(AssemblyNode? node)
        {
            _detail.Clear();

            var scroll = new ScrollView(ScrollViewMode.Vertical);
            scroll.style.flexGrow = 1f;
            WardenStyles.Pad(scroll, 12f, 14f, 12f, 14f);
            _detail.Add(scroll);

            if (node == null)
            {
                if (_report != null && _report.Violations.Count > 0)
                {
                    scroll.Add(WardenStyles.Text("LAYERING VIOLATIONS", 9, WardenStyles.Violation, FontStyle.Bold));
                    for (int i = 0; i < _report.Violations.Count; i++)
                    {
                        LayeringViolation v = _report.Violations[i];
                        Label l = WardenStyles.Text(
                            v.RuleId + ": " + v.FromAssembly + "  →  " + v.ToAssembly +
                            (v.IsDeclared ? "" : "  (emitted but never declared)") + "   " + v.Note,
                            11, WardenStyles.Ink);
                        l.style.marginTop = 5f;
                        scroll.Add(l);
                    }
                    return;
                }

                scroll.Add(WardenStyles.Text("Select an assembly to see every reference and why it was classified.",
                    11, WardenStyles.Muted));
                return;
            }

            scroll.Add(WardenStyles.Text(node.Name, 13, WardenStyles.Ink, FontStyle.Bold));
            Label path = WardenStyles.Text(node.AsmdefPath, 10, WardenStyles.Muted);
            path.style.marginBottom = 8f;
            scroll.Add(path);

            if (!node.CompiledOutputReadable)
            {
                scroll.Add(WardenStyles.Text(
                    "No compiled assembly of this name is loaded, so nothing is concluded here.",
                    11, WardenStyles.Unknown));
            }

            for (int i = 0; i < node.DeclaredReferences.Count; i++)
            {
                ReferenceEntry entry = node.DeclaredReferences[i];
                var row = new VisualElement();
                row.style.flexDirection = FlexDirection.Column;
                row.style.marginBottom = 7f;

                var head = new VisualElement();
                head.style.flexDirection = FlexDirection.Row;
                head.style.alignItems = Align.Center;
                head.Add(WardenStyles.Chip(entry.Verdict.ToString().ToUpperInvariant(), WardenStyles.For(entry.Verdict)));
                head.Add(WardenStyles.Text(entry.ResolvedName ?? entry.RawValue, 11, WardenStyles.Ink, FontStyle.Bold));
                row.Add(head);

                Label why = WardenStyles.Text(entry.Explanation, 10, WardenStyles.Muted);
                why.style.marginLeft = 4f;
                why.style.marginTop = 2f;
                row.Add(why);

                scroll.Add(row);
            }

            for (int i = 0; i < node.UndeclaredReferences.Count; i++)
            {
                Label l = WardenStyles.Text(
                    "MISSING — the compiler emitted a reference to '" + node.UndeclaredReferences[i] +
                    "' that this .asmdef never declares.", 10, WardenStyles.Violation);
                l.style.marginTop = 4f;
                scroll.Add(l);
            }
        }

        /// <summary>
        /// Longest-path layering, so a reference always points rightward. Unity forbids cyclic
        /// assembly references outright, but the walk is still bounded in case a project is in a
        /// state the engine has not yet rejected.
        /// </summary>
        private static Dictionary<string, int> ComputeDepths(WardenReport report)
        {
            var byName = new Dictionary<string, AssemblyNode>(StringComparer.Ordinal);
            for (int i = 0; i < report.Nodes.Count; i++) byName[report.Nodes[i].Name] = report.Nodes[i];

            var depth = new Dictionary<string, int>(StringComparer.Ordinal);
            for (int i = 0; i < report.Nodes.Count; i++) depth[report.Nodes[i].Name] = 0;

            int passes = Mathf.Min(report.Nodes.Count, 64);
            for (int pass = 0; pass < passes; pass++)
            {
                bool changed = false;
                for (int i = 0; i < report.Nodes.Count; i++)
                {
                    AssemblyNode node = report.Nodes[i];
                    for (int r = 0; r < node.DeclaredReferences.Count; r++)
                    {
                        string? to = node.DeclaredReferences[r].ResolvedName;
                        if (to == null || to.Length == 0 || !byName.ContainsKey(to)) continue;
                        if (depth[to] <= depth[node.Name])
                        {
                            depth[to] = depth[node.Name] + 1;
                            changed = true;
                        }
                    }
                }
                if (!changed) break;
            }
            return depth;
        }
    }
}
