// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

using System;
using System.Collections.Generic;

namespace CSAF.AssemblyWarden.Model
{
    /// <summary>
    /// What Assembly Warden concluded about one declared reference.
    /// The vocabulary is deliberately three-valued and biased toward keeping a reference:
    /// deleting a reference the compiler silently needed breaks the buyer's build, and no
    /// amount of speed is worth that.
    /// </summary>
    public enum ReferenceVerdict
    {
        /// <summary>The compiled assembly emitted an AssemblyRef for this reference. Keep it.</summary>
        Required = 0,

        /// <summary>
        /// No AssemblyRef was emitted, and nothing in the source contradicts that.
        /// Safe to remove — and still verified by a real recompile before the change is kept.
        /// </summary>
        Redundant = 1,

        /// <summary>
        /// No AssemblyRef was emitted, but a second channel says the reference may still be needed
        /// (const inlining, conditional compilation, attribute-only or default-parameter usage).
        /// Never removed automatically.
        /// </summary>
        Uncertain = 2,

        /// <summary>
        /// The compiled output for this assembly could not be read, so nothing can be concluded.
        /// Never removed automatically.
        /// </summary>
        Unknown = 3
    }

    /// <summary>Why a reference was classified <see cref="ReferenceVerdict.Uncertain"/>.</summary>
    public enum UncertaintyReason
    {
        None = 0,
        ConditionalCompilation = 1,
        SourceMentionsAssembly = 2,
        AssemblyNotLoaded = 3
    }

    /// <summary>One declared entry in an .asmdef "references" array.</summary>
    [Serializable]
    public sealed class ReferenceEntry
    {
        /// <summary>The literal string as written in the buyer's file — a name or "GUID:...".</summary>
        public string RawValue = string.Empty;

        /// <summary>The assembly name this entry resolves to, or null when it cannot be resolved.</summary>
        public string? ResolvedName;

        /// <summary>True when <see cref="RawValue"/> uses the "GUID:" form. Preserved on rewrite.</summary>
        public bool IsGuidForm;

        public ReferenceVerdict Verdict = ReferenceVerdict.Unknown;
        public UncertaintyReason Uncertainty = UncertaintyReason.None;

        /// <summary>Human-readable justification, shown in the UI and written to the report.</summary>
        public string Explanation = string.Empty;
    }

    /// <summary>One assembly definition file and everything measured about it.</summary>
    [Serializable]
    public sealed class AssemblyNode
    {
        /// <summary>Assembly name, e.g. "Game.Gameplay".</summary>
        public string Name = string.Empty;

        /// <summary>Project-relative path of the .asmdef.</summary>
        public string AsmdefPath = string.Empty;

        /// <summary>True when this assembly lives under a package rather than Assets/.</summary>
        public bool IsPackage;

        /// <summary>True when the compiled assembly was found in the loaded AppDomain.</summary>
        public bool CompiledOutputReadable;

        /// <summary>Names emitted by the compiler as real AssemblyRefs. Ground truth.</summary>
        public List<string> ActualReferences = new List<string>();

        /// <summary>Entries declared in the .asmdef, in file order.</summary>
        public List<ReferenceEntry> DeclaredReferences = new List<ReferenceEntry>();

        /// <summary>
        /// Assemblies the compiler emitted a reference to that the .asmdef does not declare.
        /// Rare in a project that compiles; reported rather than silently fixed.
        /// </summary>
        public List<string> UndeclaredReferences = new List<string>();

        /// <summary>Number of C# files compiled into this assembly.</summary>
        public int SourceFileCount;

        /// <summary>True when any source file contains a preprocessor conditional.</summary>
        public bool HasConditionalCompilation;

        public int CountOf(ReferenceVerdict v)
        {
            int n = 0;
            for (int i = 0; i < DeclaredReferences.Count; i++)
            {
                if (DeclaredReferences[i].Verdict == v) n++;
            }
            return n;
        }
    }

    /// <summary>A buyer-defined layering rule that was broken.</summary>
    [Serializable]
    public sealed class LayeringViolation
    {
        public string RuleId = string.Empty;
        public string FromAssembly = string.Empty;
        public string ToAssembly = string.Empty;
        public string Note = string.Empty;

        /// <summary>True when the edge is declared in the .asmdef; false when only the compiler emitted it.</summary>
        public bool IsDeclared;
    }

    /// <summary>The whole result of one scan.</summary>
    [Serializable]
    public sealed class WardenReport
    {
        public string GeneratedAtUtc = string.Empty;
        public string UnityVersion = string.Empty;

        public List<AssemblyNode> Nodes = new List<AssemblyNode>();
        public List<LayeringViolation> Violations = new List<LayeringViolation>();

        /// <summary>
        /// Set when the scan refused to draw conclusions — e.g. the project has compile errors,
        /// in which case the reference graph does not describe the code on disk.
        /// </summary>
        public string? RefusalReason;

        public bool Refused
        {
            get { return !string.IsNullOrEmpty(RefusalReason); }
        }

        public int TotalDeclared
        {
            get
            {
                int n = 0;
                for (int i = 0; i < Nodes.Count; i++) n += Nodes[i].DeclaredReferences.Count;
                return n;
            }
        }

        public int Count(ReferenceVerdict v)
        {
            int n = 0;
            for (int i = 0; i < Nodes.Count; i++) n += Nodes[i].CountOf(v);
            return n;
        }
    }
}
