// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

using CSAF.AssemblyWarden.Model;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace CSAF.AssemblyWarden.UI
{
    /// <summary>
    /// The window's whole visual language, defined in C#.
    ///
    /// No USS file and no <c>Resources/</c> folder: a Resources folder inside a store package is
    /// loaded into every build of every project that imports it, forever. Inline styles cost a
    /// little verbosity here and cost the buyer nothing at all.
    /// </summary>
    internal static class WardenStyles
    {
        public static bool Dark { get { return EditorGUIUtility.isProSkin; } }

        public static Color Canvas { get { return Dark ? new Color(0.129f, 0.137f, 0.161f) : new Color(0.925f, 0.929f, 0.937f); } }
        public static Color Panel { get { return Dark ? new Color(0.164f, 0.176f, 0.204f) : new Color(0.976f, 0.976f, 0.980f); } }
        public static Color Line { get { return Dark ? new Color(0.243f, 0.259f, 0.298f) : new Color(0.820f, 0.831f, 0.851f); } }
        public static Color Ink { get { return Dark ? new Color(0.902f, 0.914f, 0.937f) : new Color(0.106f, 0.118f, 0.137f); } }
        public static Color Muted { get { return Dark ? new Color(0.573f, 0.600f, 0.651f) : new Color(0.412f, 0.435f, 0.478f); } }

        public static Color Required { get { return new Color(0.243f, 0.639f, 0.478f); } }
        public static Color Redundant { get { return new Color(0.902f, 0.451f, 0.286f); } }
        public static Color Uncertain { get { return new Color(0.902f, 0.702f, 0.259f); } }
        public static Color Unknown { get { return new Color(0.451f, 0.478f, 0.545f); } }
        public static Color Violation { get { return new Color(0.847f, 0.310f, 0.408f); } }
        public static Color Accent { get { return new Color(0.357f, 0.561f, 0.902f); } }

        public static Color For(ReferenceVerdict v)
        {
            switch (v)
            {
                case ReferenceVerdict.Required: return Required;
                case ReferenceVerdict.Redundant: return Redundant;
                case ReferenceVerdict.Uncertain: return Uncertain;
                default: return Unknown;
            }
        }

        public static void Border(VisualElement e, Color c, float width, float radius)
        {
            e.style.borderTopWidth = width;
            e.style.borderRightWidth = width;
            e.style.borderBottomWidth = width;
            e.style.borderLeftWidth = width;
            e.style.borderTopColor = c;
            e.style.borderRightColor = c;
            e.style.borderBottomColor = c;
            e.style.borderLeftColor = c;
            e.style.borderTopLeftRadius = radius;
            e.style.borderTopRightRadius = radius;
            e.style.borderBottomLeftRadius = radius;
            e.style.borderBottomRightRadius = radius;
        }

        public static void Pad(VisualElement e, float t, float r, float b, float l)
        {
            e.style.paddingTop = t;
            e.style.paddingRight = r;
            e.style.paddingBottom = b;
            e.style.paddingLeft = l;
        }

        public static Label Text(string s, int size, Color color, FontStyle style = FontStyle.Normal)
        {
            var l = new Label(s);
            l.style.fontSize = size;
            l.style.color = color;
            l.style.unityFontStyleAndWeight = style;
            l.style.whiteSpace = WhiteSpace.Normal;
            return l;
        }

        /// <summary>A small count chip — the readable unit the whole window is built from.</summary>
        public static VisualElement Chip(string text, Color color)
        {
            var chip = new VisualElement();
            chip.style.flexDirection = FlexDirection.Row;
            chip.style.alignItems = Align.Center;
            chip.style.backgroundColor = new Color(color.r, color.g, color.b, Dark ? 0.18f : 0.14f);
            Border(chip, new Color(color.r, color.g, color.b, 0.55f), 1f, 9f);
            Pad(chip, 1f, 7f, 1f, 7f);
            chip.style.marginRight = 4f;

            var label = Text(text, 10, color, FontStyle.Bold);
            chip.Add(label);
            return chip;
        }
    }
}
