// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace CSAF.AssemblyWarden.Rules
{
    /// <summary>
    /// One architectural constraint the buyer wants enforced, e.g. "Game.Gameplay must never
    /// reference Game.UI".
    ///
    /// This is the half of the product Unity cannot do for you. Unity already refuses cyclic
    /// assembly references and fails the compile, so a cycle cannot exist in a project that builds
    /// — but "the gameplay layer must not know about the UI layer" is a decision, not a compile
    /// error, and nothing in the engine remembers it.
    /// </summary>
    [Serializable]
    public sealed class LayeringRule
    {
        [Tooltip("Short identifier used in reports and CI output, e.g. GAMEPLAY-NO-UI.")]
        public string Id = "RULE";

        [Tooltip("Assembly name pattern the rule applies FROM. '*' matches any run of characters.")]
        public string From = "Game.Gameplay*";

        [Tooltip("Assembly name pattern the rule forbids referencing. '*' matches any run of characters.")]
        public string To = "Game.UI*";

        [Tooltip("Shown to whoever trips the rule. Say WHY, not what.")]
        [TextArea(2, 4)]
        public string Note = "Gameplay must stay presentation-agnostic.";
    }

    /// <summary>
    /// The buyer's rule set, stored as a normal project asset.
    /// Deliberately not in a <c>Resources/</c> folder — a Resources folder is loaded into every
    /// build of every project that contains it, unconditionally, and shipping one inside a store
    /// package taxes every buyer forever.
    /// </summary>
    [CreateAssetMenu(
        menuName = "CSAF/Assembly Warden/Layering Rules",
        fileName = "AssemblyWardenRules")]
    public sealed class LayeringRuleSet : ScriptableObject
    {
        [SerializeField]
        private List<LayeringRule> _rules = new List<LayeringRule>();

        public IList<LayeringRule> Rules { get { return _rules; } }

        /// <summary>Finds the first rule set in the project, or null when the buyer has not made one.</summary>
        public static LayeringRuleSet? FindInProject()
        {
            string[] guids = AssetDatabase.FindAssets("t:" + typeof(LayeringRuleSet).Name);
            if (guids == null || guids.Length == 0) return null;
            string path = AssetDatabase.GUIDToAssetPath(guids[0]);
            return AssetDatabase.LoadAssetAtPath<LayeringRuleSet>(path);
        }

        /// <summary>Glob match on '*'. Case-sensitive, because assembly names are.</summary>
        public static bool Matches(string pattern, string value)
        {
            if (string.IsNullOrEmpty(pattern)) return false;
            if (string.IsNullOrEmpty(value)) return false;
            if (pattern == "*") return true;

            int p = 0, v = 0, star = -1, mark = 0;
            while (v < value.Length)
            {
                if (p < pattern.Length && (pattern[p] == value[v]))
                {
                    p++; v++;
                }
                else if (p < pattern.Length && pattern[p] == '*')
                {
                    star = p++;
                    mark = v;
                }
                else if (star >= 0)
                {
                    p = star + 1;
                    v = ++mark;
                }
                else
                {
                    return false;
                }
            }
            while (p < pattern.Length && pattern[p] == '*') p++;
            return p == pattern.Length;
        }
    }
}
