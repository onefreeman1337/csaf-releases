// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

using System.Globalization;
using System.IO;
using System.Text;
using CSAF.AssemblyWarden.Model;

namespace CSAF.AssemblyWarden.Reporting
{
    /// <summary>
    /// Writes the scan as JSON a build server can read.
    ///
    /// Hand-written rather than <c>JsonUtility</c> on purpose: the enum verdicts must appear as
    /// words, not as the integers <c>JsonUtility</c> emits, or every consumer has to keep its own
    /// copy of the enum order and will silently misread the file the day one is inserted.
    /// </summary>
    public static class ReportWriter
    {
        public static void WriteJson(WardenReport report, string path)
        {
            File.WriteAllText(path, ToJson(report), new UTF8Encoding(false));
        }

        public static string ToJson(WardenReport report)
        {
            var sb = new StringBuilder();
            sb.Append("{\n");
            sb.Append("  \"generatedAtUtc\": ").Append(Str(report.GeneratedAtUtc)).Append(",\n");
            sb.Append("  \"unityVersion\": ").Append(Str(report.UnityVersion)).Append(",\n");
            sb.Append("  \"refused\": ").Append(report.Refused ? "true" : "false").Append(",\n");
            sb.Append("  \"refusalReason\": ").Append(Str(report.RefusalReason)).Append(",\n");

            sb.Append("  \"totals\": {\n");
            sb.Append("    \"assemblies\": ").Append(report.Nodes.Count).Append(",\n");
            sb.Append("    \"declaredReferences\": ").Append(report.TotalDeclared).Append(",\n");
            sb.Append("    \"required\": ").Append(report.Count(ReferenceVerdict.Required)).Append(",\n");
            sb.Append("    \"redundant\": ").Append(report.Count(ReferenceVerdict.Redundant)).Append(",\n");
            sb.Append("    \"uncertain\": ").Append(report.Count(ReferenceVerdict.Uncertain)).Append(",\n");
            sb.Append("    \"unknown\": ").Append(report.Count(ReferenceVerdict.Unknown)).Append(",\n");
            sb.Append("    \"layeringViolations\": ").Append(report.Violations.Count).Append('\n');
            sb.Append("  },\n");

            sb.Append("  \"assemblies\": [\n");
            for (int i = 0; i < report.Nodes.Count; i++)
            {
                AssemblyNode n = report.Nodes[i];
                sb.Append("    {\n");
                sb.Append("      \"name\": ").Append(Str(n.Name)).Append(",\n");
                sb.Append("      \"asmdef\": ").Append(Str(n.AsmdefPath)).Append(",\n");
                sb.Append("      \"isPackage\": ").Append(n.IsPackage ? "true" : "false").Append(",\n");
                sb.Append("      \"compiledOutputReadable\": ").Append(n.CompiledOutputReadable ? "true" : "false").Append(",\n");
                sb.Append("      \"sourceFiles\": ").Append(n.SourceFileCount).Append(",\n");
                sb.Append("      \"hasConditionalCompilation\": ").Append(n.HasConditionalCompilation ? "true" : "false").Append(",\n");

                sb.Append("      \"references\": [\n");
                for (int r = 0; r < n.DeclaredReferences.Count; r++)
                {
                    ReferenceEntry e = n.DeclaredReferences[r];
                    sb.Append("        { \"declared\": ").Append(Str(e.RawValue));
                    sb.Append(", \"resolved\": ").Append(Str(e.ResolvedName));
                    sb.Append(", \"verdict\": ").Append(Str(e.Verdict.ToString()));
                    sb.Append(", \"uncertainty\": ").Append(Str(e.Uncertainty.ToString()));
                    sb.Append(", \"why\": ").Append(Str(e.Explanation)).Append(" }");
                    if (r < n.DeclaredReferences.Count - 1) sb.Append(',');
                    sb.Append('\n');
                }
                sb.Append("      ],\n");

                sb.Append("      \"undeclaredEmittedReferences\": [");
                for (int u = 0; u < n.UndeclaredReferences.Count; u++)
                {
                    if (u > 0) sb.Append(", ");
                    sb.Append(Str(n.UndeclaredReferences[u]));
                }
                sb.Append("]\n");

                sb.Append("    }");
                if (i < report.Nodes.Count - 1) sb.Append(',');
                sb.Append('\n');
            }
            sb.Append("  ],\n");

            sb.Append("  \"layeringViolations\": [\n");
            for (int i = 0; i < report.Violations.Count; i++)
            {
                LayeringViolation v = report.Violations[i];
                sb.Append("    { \"rule\": ").Append(Str(v.RuleId));
                sb.Append(", \"from\": ").Append(Str(v.FromAssembly));
                sb.Append(", \"to\": ").Append(Str(v.ToAssembly));
                sb.Append(", \"declared\": ").Append(v.IsDeclared ? "true" : "false");
                sb.Append(", \"note\": ").Append(Str(v.Note)).Append(" }");
                if (i < report.Violations.Count - 1) sb.Append(',');
                sb.Append('\n');
            }
            sb.Append("  ]\n");
            sb.Append("}\n");
            return sb.ToString();
        }

        private static string Str(string? s)
        {
            if (s == null) return "null";
            var sb = new StringBuilder(s.Length + 2);
            sb.Append('"');
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                switch (c)
                {
                    case '"': sb.Append("\\\""); break;
                    case '\\': sb.Append("\\\\"); break;
                    case '\n': sb.Append("\\n"); break;
                    case '\r': sb.Append("\\r"); break;
                    case '\t': sb.Append("\\t"); break;
                    default:
                        if (c < 32) sb.Append("\\u").Append(((int)c).ToString("x4", CultureInfo.InvariantCulture));
                        else sb.Append(c);
                        break;
                }
            }
            sb.Append('"');
            return sb.ToString();
        }
    }
}
