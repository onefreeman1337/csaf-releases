// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

using System;
using System.Collections.Generic;
using System.Text;

namespace CSAF.AssemblyWarden.Apply
{
    /// <summary>
    /// A surgical reader/writer for an .asmdef file.
    ///
    /// It deliberately does NOT deserialise the file into an object and serialise it back.
    /// Round-tripping through <c>JsonUtility</c> silently drops every field the model does not
    /// know about — <c>versionDefines</c>, <c>defineConstraints</c>, future Unity additions — and
    /// reformats the whole file, which turns a one-line change into an unreviewable diff in the
    /// buyer's version control.
    ///
    /// Instead this locates the exact character span of one array literal and replaces only that
    /// span, preserving every other byte of the file including indentation and key order.
    /// </summary>
    public sealed class AsmdefDocument
    {
        private readonly string _text;

        public string Path { get; private set; }
        public string Text { get { return _text; } }

        public AsmdefDocument(string path, string text)
        {
            Path = path;
            _text = text ?? string.Empty;
        }

        /// <summary>Reads the value of a top-level string key, or null when absent.</summary>
        public string? ReadStringValue(string key)
        {
            int keyAt = FindTopLevelKey(key);
            if (keyAt < 0) return null;

            int colon = IndexOfOutsideString(_text, ':', keyAt);
            if (colon < 0) return null;

            int i = SkipWhitespace(colon + 1);
            if (i >= _text.Length || _text[i] != '"') return null;

            int end;
            string value = ReadJsonString(_text, i, out end);
            return value;
        }

        /// <summary>Reads a top-level array of strings. Returns an empty list when the key is absent.</summary>
        public List<string> ReadStringArray(string key)
        {
            var result = new List<string>();
            int open, close;
            if (!TryLocateArray(key, out open, out close)) return result;

            int i = open + 1;
            while (i < close)
            {
                if (_text[i] == '"')
                {
                    int end;
                    result.Add(ReadJsonString(_text, i, out end));
                    i = end;
                    continue;
                }
                i++;
            }
            return result;
        }

        /// <summary>
        /// Returns the file text with one top-level string array replaced, and nothing else changed.
        /// When the key is absent it is inserted immediately after the opening brace.
        /// </summary>
        public string WithStringArray(string key, IList<string> values)
        {
            string indent = DetectIndentUnit();
            string entryIndent = indent + indent;
            // Match the file's own newline convention. Writing bare \n into a CRLF file would
            // leave mixed endings in the rewritten span — exactly the noisy diff this class
            // exists to avoid.
            string newline = _text.Contains("\r\n") ? "\r\n" : "\n";

            var sb = new StringBuilder();
            sb.Append('[');
            if (values.Count > 0)
            {
                sb.Append(newline);
                for (int i = 0; i < values.Count; i++)
                {
                    sb.Append(entryIndent).Append('"').Append(EscapeJson(values[i])).Append('"');
                    if (i < values.Count - 1) sb.Append(',');
                    sb.Append(newline);
                }
                sb.Append(indent);
            }
            sb.Append(']');

            int open, close;
            if (TryLocateArray(key, out open, out close))
            {
                return _text.Substring(0, open) + sb + _text.Substring(close + 1);
            }

            int brace = _text.IndexOf('{');
            if (brace < 0) throw new InvalidOperationException("Not a JSON object: " + Path);

            string inserted = newline + indent + "\"" + key + "\": " + sb;
            bool hasMore = HasNonWhitespaceBefore(_text, brace + 1, '}');
            if (hasMore) inserted += ",";
            return _text.Substring(0, brace + 1) + inserted + _text.Substring(brace + 1);
        }

        private bool TryLocateArray(string key, out int open, out int close)
        {
            open = -1;
            close = -1;

            int keyAt = FindTopLevelKey(key);
            if (keyAt < 0) return false;

            int colon = IndexOfOutsideString(_text, ':', keyAt);
            if (colon < 0) return false;

            int i = SkipWhitespace(colon + 1);
            if (i >= _text.Length || _text[i] != '[') return false;

            open = i;
            int depth = 0;
            while (i < _text.Length)
            {
                char c = _text[i];
                if (c == '"')
                {
                    int end;
                    ReadJsonString(_text, i, out end);
                    i = end;
                    continue;
                }
                if (c == '[') depth++;
                else if (c == ']')
                {
                    depth--;
                    if (depth == 0) { close = i; return true; }
                }
                i++;
            }
            return false;
        }

        /// <summary>Finds a key at object depth 1, ignoring identical text inside strings or nested objects.</summary>
        private int FindTopLevelKey(string key)
        {
            string needle = "\"" + key + "\"";
            int depth = 0;
            int i = 0;
            while (i < _text.Length)
            {
                char c = _text[i];
                if (c == '"')
                {
                    int end;
                    ReadJsonString(_text, i, out end);
                    if (depth == 1 && string.CompareOrdinal(_text, i, needle, 0, needle.Length) == 0)
                    {
                        // Only a key if a colon follows.
                        int after = SkipWhitespace(end);
                        if (after < _text.Length && _text[after] == ':') return i;
                    }
                    i = end;
                    continue;
                }
                if (c == '{' || c == '[') depth++;
                else if (c == '}' || c == ']') depth--;
                i++;
            }
            return -1;
        }

        private int SkipWhitespace(int i)
        {
            while (i < _text.Length && char.IsWhiteSpace(_text[i])) i++;
            return i;
        }

        private string DetectIndentUnit()
        {
            int nl = _text.IndexOf('\n');
            if (nl < 0) return "    ";
            int i = nl + 1;
            var sb = new StringBuilder();
            while (i < _text.Length && (_text[i] == ' ' || _text[i] == '\t'))
            {
                sb.Append(_text[i]);
                i++;
            }
            return sb.Length == 0 ? "    " : sb.ToString();
        }

        private static bool HasNonWhitespaceBefore(string s, int from, char stop)
        {
            for (int i = from; i < s.Length; i++)
            {
                if (s[i] == stop) return false;
                if (!char.IsWhiteSpace(s[i])) return true;
            }
            return false;
        }

        private static int IndexOfOutsideString(string s, char target, int from)
        {
            int i = from;
            while (i < s.Length)
            {
                if (s[i] == '"')
                {
                    int end;
                    ReadJsonString(s, i, out end);
                    i = end;
                    continue;
                }
                if (s[i] == target) return i;
                i++;
            }
            return -1;
        }

        /// <summary>Reads a JSON string starting at the opening quote. <paramref name="end"/> lands past the closing quote.</summary>
        private static string ReadJsonString(string s, int start, out int end)
        {
            var sb = new StringBuilder();
            int i = start + 1;
            while (i < s.Length)
            {
                char c = s[i];
                if (c == '\\' && i + 1 < s.Length)
                {
                    char n = s[i + 1];
                    switch (n)
                    {
                        case 'n': sb.Append('\n'); break;
                        case 't': sb.Append('\t'); break;
                        case 'r': sb.Append('\r'); break;
                        case '"': sb.Append('"'); break;
                        case '\\': sb.Append('\\'); break;
                        case '/': sb.Append('/'); break;
                        default: sb.Append(n); break;
                    }
                    i += 2;
                    continue;
                }
                if (c == '"') { end = i + 1; return sb.ToString(); }
                sb.Append(c);
                i++;
            }
            end = s.Length;
            return sb.ToString();
        }

        private static string EscapeJson(string s)
        {
            if (string.IsNullOrEmpty(s)) return string.Empty;
            return s.Replace("\\", "\\\\").Replace("\"", "\\\"");
        }
    }
}
