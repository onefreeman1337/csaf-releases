// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using CSAF.AssemblyWarden.Model;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;

namespace CSAF.AssemblyWarden.Apply
{
    /// <summary>One file's worth of pending change, kept so it can be undone byte for byte.</summary>
    [Serializable]
    public sealed class FileBackup
    {
        public string Path = string.Empty;
        public string OriginalText = string.Empty;
        public string NewText = string.Empty;
        public List<string> Removed = new List<string>();
    }

    /// <summary>The whole pending change, serialised into SessionState so it survives a domain reload.</summary>
    [Serializable]
    public sealed class ApplyPlan
    {
        public List<FileBackup> Files = new List<FileBackup>();

        public int RemovedCount
        {
            get
            {
                int n = 0;
                for (int i = 0; i < Files.Count; i++) n += Files[i].Removed.Count;
                return n;
            }
        }
    }

    /// <summary>
    /// Writes .asmdef changes, then proves them.
    ///
    /// The verify-and-rollback step is not polish, it is the feature that makes the headline safe
    /// to sell. A reference that emits no AssemblyRef can still be required (see
    /// <c>Diagnoser</c>), so every applied removal is followed by a REAL recompile, and any
    /// compiler error restores every touched file to the exact bytes it had before.
    ///
    /// The pending plan lives in <see cref="SessionState"/> rather than a field, because applying
    /// a change triggers a domain reload that destroys every static in this assembly. If the editor
    /// is killed mid-apply, the next load finds the plan and rolls it back.
    /// </summary>
    public static class ApplySession
    {
        private const string PendingKey = "CSAF.AssemblyWarden.PendingApply";
        private const string LogPrefix = "[Assembly Warden] ";

        private static readonly List<string> CompileErrors = new List<string>();

        /// <summary>Builds the change without writing anything. This is the dry run.</summary>
        public static ApplyPlan BuildPlan(WardenReport report)
        {
            var plan = new ApplyPlan();
            if (report == null || report.Refused) return plan;

            for (int i = 0; i < report.Nodes.Count; i++)
            {
                AssemblyNode node = report.Nodes[i];

                // A package's .asmdef belongs to its vendor and is often immutable. Never rewrite one.
                if (node.IsPackage) continue;
                if (node.CountOf(ReferenceVerdict.Redundant) == 0) continue;

                string original;
                try { original = File.ReadAllText(node.AsmdefPath); }
                catch (IOException e)
                {
                    Debug.LogWarning(LogPrefix + "Skipping " + node.AsmdefPath + ": " + e.Message);
                    continue;
                }

                var keep = new List<string>();
                var removed = new List<string>();
                for (int r = 0; r < node.DeclaredReferences.Count; r++)
                {
                    ReferenceEntry entry = node.DeclaredReferences[r];
                    if (entry.Verdict == ReferenceVerdict.Redundant)
                    {
                        // Preserve the buyer's own spelling in the report.
                        removed.Add(entry.RawValue);
                    }
                    else
                    {
                        keep.Add(entry.RawValue);
                    }
                }

                var doc = new AsmdefDocument(node.AsmdefPath, original);
                string updated = doc.WithStringArray("references", keep);
                if (string.Equals(updated, original, StringComparison.Ordinal)) continue;

                plan.Files.Add(new FileBackup
                {
                    Path = node.AsmdefPath,
                    OriginalText = original,
                    NewText = updated,
                    Removed = removed
                });
            }

            return plan;
        }

        /// <summary>A unified-ish diff of the plan, for the buyer to read before anything is written.</summary>
        public static string DescribePlan(ApplyPlan plan)
        {
            if (plan == null || plan.Files.Count == 0) return "Nothing to change.";

            var sb = new StringBuilder();
            for (int i = 0; i < plan.Files.Count; i++)
            {
                FileBackup f = plan.Files[i];
                sb.Append(f.Path).Append('\n');
                for (int r = 0; r < f.Removed.Count; r++)
                {
                    sb.Append("  - ").Append(f.Removed[r]).Append('\n');
                }
                sb.Append('\n');
            }
            sb.Append(plan.Files.Count).Append(" file(s), ").Append(plan.RemovedCount).Append(" reference(s) removed.");
            return sb.ToString();
        }

        public static bool HasPending
        {
            get { return !string.IsNullOrEmpty(SessionState.GetString(PendingKey, string.Empty)); }
        }

        /// <summary>Writes the plan, recompiles, and rolls the whole thing back if the compile fails.</summary>
        public static void Apply(ApplyPlan plan)
        {
            if (plan == null || plan.Files.Count == 0)
            {
                Debug.Log(LogPrefix + "Nothing to apply.");
                return;
            }

            if (HasPending)
            {
                Debug.LogWarning(LogPrefix + "A previous apply is still being verified. Not starting another.");
                return;
            }

            SessionState.SetString(PendingKey, JsonUtility.ToJson(plan));

            try
            {
                AssetDatabase.StartAssetEditing();
                for (int i = 0; i < plan.Files.Count; i++)
                {
                    File.WriteAllText(plan.Files[i].Path, plan.Files[i].NewText);
                }
            }
            catch (IOException e)
            {
                Debug.LogError(LogPrefix + "Write failed, rolling back: " + e.Message);
                AssetDatabase.StopAssetEditing();
                Rollback(plan, "a file could not be written");
                return;
            }
            finally
            {
                AssetDatabase.StopAssetEditing();
            }

            CompileErrors.Clear();
            CompilationPipeline.assemblyCompilationFinished += OnAssemblyCompiled;
            CompilationPipeline.compilationFinished += OnCompilationFinished;

            Debug.Log(LogPrefix + "Applied " + plan.RemovedCount + " removal(s) across " +
                      plan.Files.Count + " file(s). Recompiling to verify.");

            AssetDatabase.Refresh();
            CompilationPipeline.RequestScriptCompilation();
        }

        private static void OnAssemblyCompiled(string assemblyPath, CompilerMessage[] messages)
        {
            if (messages == null) return;
            for (int i = 0; i < messages.Length; i++)
            {
                if (messages[i].type != CompilerMessageType.Error) continue;
                CompileErrors.Add(messages[i].file + "(" + messages[i].line + "): " + messages[i].message);
            }
        }

        /// <summary>
        /// Fires in the CURRENT domain. A failed compile does not reload the domain, so this is
        /// where a bad removal is caught and undone.
        /// </summary>
        private static void OnCompilationFinished(object context)
        {
            CompilationPipeline.assemblyCompilationFinished -= OnAssemblyCompiled;
            CompilationPipeline.compilationFinished -= OnCompilationFinished;

            if (CompileErrors.Count == 0) return; // success: the domain is about to reload

            ApplyPlan? plan = ReadPending();
            string first = CompileErrors[0];
            CompileErrors.Clear();
            if (plan != null) Rollback(plan, "the project no longer compiles. First error: " + first);
        }

        /// <summary>
        /// Runs after every domain reload. Reaching here with a plan still pending means the
        /// assemblies swapped, which only happens when compilation succeeded.
        /// </summary>
        [InitializeOnLoadMethod]
        private static void OnDomainReload()
        {
            ApplyPlan? plan = ReadPending();
            if (plan == null) return;

            SessionState.EraseString(PendingKey);
            Debug.Log(LogPrefix + "VERIFIED. " + plan.RemovedCount + " reference(s) removed from " +
                      plan.Files.Count + " assembly definition(s), and the project recompiled cleanly.");
        }

        private static ApplyPlan? ReadPending()
        {
            string json = SessionState.GetString(PendingKey, string.Empty);
            if (string.IsNullOrEmpty(json)) return null;
            try { return JsonUtility.FromJson<ApplyPlan>(json); }
            catch (ArgumentException) { return null; }
        }

        /// <summary>Restores every touched file to the exact bytes it had before the apply.</summary>
        public static void Rollback(ApplyPlan plan, string reason)
        {
            if (plan == null) return;

            try
            {
                AssetDatabase.StartAssetEditing();
                for (int i = 0; i < plan.Files.Count; i++)
                {
                    File.WriteAllText(plan.Files[i].Path, plan.Files[i].OriginalText);
                }
            }
            catch (IOException e)
            {
                Debug.LogError(LogPrefix + "ROLLBACK FAILED for one or more files: " + e.Message +
                               ". Restore these from version control: " + PathList(plan));
            }
            finally
            {
                AssetDatabase.StopAssetEditing();
            }

            SessionState.EraseString(PendingKey);
            Debug.LogError(LogPrefix + "ROLLED BACK — " + reason +
                           ". Every touched assembly definition is back to its original bytes. " +
                           "The references involved are being re-classified as uncertain; this is the " +
                           "const-inlining case the scan warns about.");

            AssetDatabase.Refresh();
        }

        private static string PathList(ApplyPlan plan)
        {
            var sb = new StringBuilder();
            for (int i = 0; i < plan.Files.Count; i++)
            {
                if (i > 0) sb.Append(", ");
                sb.Append(plan.Files[i].Path);
            }
            return sb.ToString();
        }
    }
}
