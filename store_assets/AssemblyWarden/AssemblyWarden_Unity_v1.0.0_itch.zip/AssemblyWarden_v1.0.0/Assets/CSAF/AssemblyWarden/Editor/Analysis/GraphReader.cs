// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using CSAF.AssemblyWarden.Apply;
using CSAF.AssemblyWarden.Model;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;
using CompilationAssembly = UnityEditor.Compilation.Assembly;
using ReflectionAssembly = System.Reflection.Assembly;

namespace CSAF.AssemblyWarden.Analysis
{
    /// <summary>
    /// Builds the assembly graph from two independent sources and compares them:
    ///
    ///  * what each .asmdef DECLARES — read out of the file itself, GUID references resolved; and
    ///  * what the compiler actually EMITTED — <c>Assembly.GetReferencedAssemblies()</c> on the
    ///    assemblies loaded in the editor's own AppDomain.
    ///
    /// The second is ground truth rather than an inference: Roslyn writes an AssemblyRef row only
    /// for an assembly whose metadata the compiled code genuinely uses. That is the whole basis of
    /// the product, and it is why nothing here scrapes <c>using</c> directives.
    ///
    /// Mono.Cecil is deliberately NOT used. The same table is already in the loaded AppDomain, so
    /// reading it there needs no package dependency (Cecil is only present when Burst or Collections
    /// pull it in), holds no file lock on a DLL Unity is using, and cannot fail on a buyer's project.
    /// </summary>
    public static class GraphReader
    {
        /// <summary>Assemblies never treated as removable edges: engine, runtime and test plumbing.</summary>
        private static readonly string[] AlwaysIgnoredPrefixes =
        {
            "mscorlib", "netstandard", "System", "Mono.", "UnityEngine", "UnityEditor",
            "Unity.Burst.Unsafe", "Bee.", "nunit.framework"
        };

        public static WardenReport Read(bool includePackages)
        {
            var report = new WardenReport
            {
                GeneratedAtUtc = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ"),
                UnityVersion = Application.unityVersion
            };

            if (EditorApplication.isCompiling)
            {
                report.RefusalReason =
                    "Unity is still compiling. The reference graph would describe assemblies that are " +
                    "about to be replaced, so the scan refuses rather than reporting something that was " +
                    "true a moment ago.";
                return report;
            }

            CompilationAssembly[] assemblies = CompilationPipeline.GetAssemblies(AssembliesType.Editor);
            Dictionary<string, ReflectionAssembly> loaded = LoadedAssembliesByName();

            var asmdefNames = new HashSet<string>(StringComparer.Ordinal);
            for (int i = 0; i < assemblies.Length; i++)
            {
                if (!string.IsNullOrEmpty(CompilationPipeline.GetAssemblyDefinitionFilePathFromAssemblyName(assemblies[i].name)))
                    asmdefNames.Add(assemblies[i].name);
            }

            int readable = 0;
            for (int i = 0; i < assemblies.Length; i++)
            {
                CompilationAssembly asm = assemblies[i];
                string asmdefPath = CompilationPipeline.GetAssemblyDefinitionFilePathFromAssemblyName(asm.name);
                if (string.IsNullOrEmpty(asmdefPath)) continue; // predefined assembly; nothing to rewrite

                bool isPackage = !asmdefPath.StartsWith("Assets/", StringComparison.Ordinal);
                if (isPackage && !includePackages) continue;

                var node = new AssemblyNode
                {
                    Name = asm.name,
                    AsmdefPath = asmdefPath,
                    IsPackage = isPackage,
                    SourceFileCount = asm.sourceFiles != null ? asm.sourceFiles.Length : 0
                };

                ReflectionAssembly compiled;
                if (loaded.TryGetValue(asm.name, out compiled))
                {
                    node.CompiledOutputReadable = true;
                    readable++;
                    var names = compiled.GetReferencedAssemblies();
                    for (int r = 0; r < names.Length; r++) node.ActualReferences.Add(names[r].Name);
                }

                ReadDeclaredReferences(node, asmdefPath);
                node.HasConditionalCompilation = ContainsConditionalCompilation(asm.sourceFiles);

                // Emitted references to project assemblies that the .asmdef does not declare.
                for (int a = 0; a < node.ActualReferences.Count; a++)
                {
                    string actual = node.ActualReferences[a];
                    if (!asmdefNames.Contains(actual)) continue;
                    if (DeclaresName(node, actual)) continue;
                    if (!node.UndeclaredReferences.Contains(actual)) node.UndeclaredReferences.Add(actual);
                }

                report.Nodes.Add(node);
            }

            if (report.Nodes.Count > 0 && readable == 0)
            {
                report.RefusalReason =
                    "None of the project's assembly definitions could be matched to a compiled assembly " +
                    "in the editor's AppDomain. That normally means the project currently fails to " +
                    "compile. The reference graph is not trustworthy in that state, so the scan refuses.";
            }

            return report;
        }

        private static bool DeclaresName(AssemblyNode node, string name)
        {
            for (int i = 0; i < node.DeclaredReferences.Count; i++)
            {
                if (string.Equals(node.DeclaredReferences[i].ResolvedName, name, StringComparison.Ordinal))
                    return true;
            }
            return false;
        }

        private static void ReadDeclaredReferences(AssemblyNode node, string asmdefPath)
        {
            string text;
            try { text = File.ReadAllText(asmdefPath); }
            catch (IOException e)
            {
                Debug.LogWarning("[Assembly Warden] Could not read " + asmdefPath + ": " + e.Message);
                return;
            }

            var doc = new AsmdefDocument(asmdefPath, text);
            List<string> raw = doc.ReadStringArray("references");

            for (int i = 0; i < raw.Count; i++)
            {
                string value = raw[i];
                var entry = new ReferenceEntry { RawValue = value };

                if (value.StartsWith("GUID:", StringComparison.Ordinal))
                {
                    entry.IsGuidForm = true;
                    string guid = value.Substring("GUID:".Length);
                    string path = AssetDatabase.GUIDToAssetPath(guid);
                    entry.ResolvedName = string.IsNullOrEmpty(path) ? null : ReadAsmdefName(path);
                }
                else
                {
                    entry.ResolvedName = value;
                }

                node.DeclaredReferences.Add(entry);
            }
        }

        private static string? ReadAsmdefName(string asmdefPath)
        {
            try
            {
                var doc = new AsmdefDocument(asmdefPath, File.ReadAllText(asmdefPath));
                return doc.ReadStringValue("name");
            }
            catch (IOException)
            {
                return null;
            }
        }

        private static Dictionary<string, ReflectionAssembly> LoadedAssembliesByName()
        {
            var map = new Dictionary<string, ReflectionAssembly>(StringComparer.Ordinal);
            ReflectionAssembly[] all = AppDomain.CurrentDomain.GetAssemblies();
            for (int i = 0; i < all.Length; i++)
            {
                string name = all[i].GetName().Name;
                if (!map.ContainsKey(name)) map[name] = all[i];
            }
            return map;
        }

        /// <summary>
        /// True when any source file carries a preprocessor conditional. A reference used only inside
        /// an inactive <c>#if</c> branch emits no AssemblyRef on the current platform and would read
        /// as redundant — deleting it would break the buyer's OTHER build target, which no recompile
        /// on this machine can detect.
        /// </summary>
        private static bool ContainsConditionalCompilation(string[]? sourceFiles)
        {
            if (sourceFiles == null) return false;
            for (int i = 0; i < sourceFiles.Length; i++)
            {
                string text;
                try { text = File.ReadAllText(sourceFiles[i]); }
                catch (IOException) { return true; } // unreadable source: assume the hazard
                if (text.IndexOf("#if", StringComparison.Ordinal) >= 0) return true;
            }
            return false;
        }

        /// <summary>Identifiers appearing anywhere in an assembly's source, used as a second channel.</summary>
        public static HashSet<string> ReadSourceIdentifiers(string assemblyName)
        {
            var set = new HashSet<string>(StringComparer.Ordinal);
            CompilationAssembly[] assemblies = CompilationPipeline.GetAssemblies(AssembliesType.Editor);
            for (int i = 0; i < assemblies.Length; i++)
            {
                if (!string.Equals(assemblies[i].name, assemblyName, StringComparison.Ordinal)) continue;
                string[] files = assemblies[i].sourceFiles;
                if (files == null) return set;
                for (int f = 0; f < files.Length; f++)
                {
                    string text;
                    try { text = File.ReadAllText(files[f]); }
                    catch (IOException) { continue; }
                    Tokenize(text, set);
                }
                return set;
            }
            return set;
        }

        private static void Tokenize(string text, HashSet<string> into)
        {
            var sb = new StringBuilder(64);
            for (int i = 0; i < text.Length; i++)
            {
                char c = text[i];
                if (char.IsLetterOrDigit(c) || c == '_')
                {
                    sb.Append(c);
                    continue;
                }
                if (sb.Length > 0)
                {
                    into.Add(sb.ToString());
                    sb.Length = 0;
                }
            }
            if (sb.Length > 0) into.Add(sb.ToString());
        }

        /// <summary>True for assemblies that are never candidates for removal.</summary>
        public static bool IsIgnored(string assemblyName)
        {
            if (string.IsNullOrEmpty(assemblyName)) return true;
            for (int i = 0; i < AlwaysIgnoredPrefixes.Length; i++)
            {
                if (assemblyName.StartsWith(AlwaysIgnoredPrefixes[i], StringComparison.Ordinal)) return true;
            }
            return false;
        }
    }
}
