// Nullable reference types are enabled per FILE, not per project: a buyer whose project does not
// enable them would otherwise get CS8632 on every annotation here, and their -warnaserror turns
// that into a build failure in code they did not write.
#nullable enable

// CSAF Assembly Warden - demo scene guide.
// Copyright (c) Corey Gallant and Stephanie Thomason. See LICENSE.txt.

using UnityEngine;

namespace CSAF.AssemblyWarden.Demo
{
    /// <summary>
    /// On-screen instructions for the demo scene.
    /// </summary>
    /// <remarks>
    /// Assembly Warden is an editor tool with no runtime behaviour, and an Asset Store reviewer
    /// opens the demo scene and presses Play. A scene that does visibly nothing reads as a broken
    /// sample, so this draws the steps that show what the tool does — including the one that
    /// matters most, which is that a reference it is not sure about is left alone.
    /// </remarks>
    [AddComponentMenu("CSAF/Assembly Warden Demo Guide")]
    public sealed class DemoGuide : MonoBehaviour
    {
        private const int Margin = 24;

        private static readonly string[] Steps =
        {
            "1.  Window  >  CSAF  >  Assembly Warden",
            "2.  Press 'Scan'. Every assembly definition in the project is read, and every declared",
            "     reference is compared against what the C# compiler actually emitted.",
            "3.  Click any assembly to see each reference and the reason for its verdict.",
            "",
            "REQUIRED   the compiler emitted a reference to it. It stays.",
            "REDUNDANT  nothing in the compiled output or the source needs it. Safe to remove.",
            "UNCERTAIN  no emitted reference, but a const, an attribute or a #if branch may still",
            "                     need it. Never removed automatically - this is the point of the tool.",
            "",
            "4.  'Preview changes' shows the exact removals. Nothing is written yet.",
            "5.  'Apply + verify' writes them and recompiles. If the compile breaks, every file is",
            "     restored to its original bytes automatically.",
            "",
            "6.  Assets > Create > CSAF > Assembly Warden > Layering Rules adds architectural rules",
            "     such as \"Gameplay must never reference UI\", which the CI gate then enforces.",
        };

        private Styles? _styles;

        /// <summary>
        /// Built once, on the first OnGUI. Constructing a GUIStyle every OnGUI call is a per-frame
        /// allocation in a loop that runs continuously, which this factory treats as a defect
        /// rather than a detail.
        /// </summary>
        private sealed class Styles
        {
            public readonly GUIStyle Heading;
            public readonly GUIStyle Body;

            public Styles()
            {
                Heading = new GUIStyle(GUI.skin.label)
                {
                    fontSize = 20,
                    fontStyle = FontStyle.Bold,
                    normal = { textColor = new Color(0.92f, 0.94f, 0.97f) }
                };
                Body = new GUIStyle(GUI.skin.label)
                {
                    fontSize = 13,
                    richText = false,
                    normal = { textColor = new Color(0.74f, 0.78f, 0.84f) }
                };
            }
        }

        private void OnGUI()
        {
            Styles s = _styles ?? (_styles = new Styles());

            GUI.Label(new Rect(Margin, Margin, 900f, 30f), "ASSEMBLY WARDEN", s.Heading);
            GUI.Label(new Rect(Margin, Margin + 28f, 900f, 22f),
                "A correct, minimal, enforced assembly graph.", s.Body);

            float y = Margin + 62f;
            for (int i = 0; i < Steps.Length; i++)
            {
                GUI.Label(new Rect(Margin, y, 940f, 20f), Steps[i], s.Body);
                y += 20f;
            }
        }
    }
}
