/**
 * art.js — MILLWRIGHT. The parish picture, the farms, the windmills, the cart tracks and the title art — THE
 * SINGLE SOURCE OF TRUTH for them (the contact sheets, the store captures and the game all require this file).
 *
 * ⛔ PALETTE LAW (wing §0-ART-g): DMG luma is 158 / 144 / 77 / 39 — shade 0 next to shade 3 is the only strong
 *    edge; 0 next to 1 is worth nothing. So the parish GROUND is shade 0 with shade-1 grain (texture, not
 *    tone), and everything the player must READ is dark on it: cottages, walls, mills, the millwright.
 * ⛔ THE PICTURE MUST NEVER CONTRADICT THE COLLISION (§0z-1): a blocked cell is river, wall or pond and looks it;
 *    a passable cell is ground, farm or bridge and looks it. Field furrows are shade 1 on shade 0 — texture
 *    only, never an edge — so they cannot read as an obstacle.
 * ⛔ THE PUZZLE'S HIDDEN WEIGHT IS PRINTED ON THE FARM: a farm of w cottages sends w carts. The roofs are counted,
 *    so every cottage is the same size and a 1-cottage farm is one roof, never a bigger house.
 * ⛔ §0-ART-b: nothing tiles on a fixed period — every grain speck and furrow is hashed per PIXEL / per cluster.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.ART = api;
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const LIT = 0, FACE = 1, MID = 2, SHADOW = 3, NONE = 255;
  const W = 160, H = 144, FIELD_Y = 24, CELL = 8, GW = 20, GH = 15;
  const GROUND = 0, RIVER = 1, BRIDGE = 2, WALL = 3, POND = 4;

  function Plane(w, h, fill) { this.w = w; this.h = h; this.px = new Uint8Array(w * h).fill(fill === undefined ? NONE : fill); }
  Plane.prototype.set = function (x, y, s) { if (s === NONE) return; x = Math.round(x); y = Math.round(y); if (x < 0 || y < 0 || x >= this.w || y >= this.h) return; this.px[y * this.w + x] = s; };
  Plane.prototype.get = function (x, y) { return (x < 0 || y < 0 || x >= this.w || y >= this.h) ? NONE : this.px[y * this.w + x]; };
  Plane.prototype.rect = function (x, y, w, h, s) { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) this.set(x + i, y + j, s); };
  Plane.prototype.hline = function (x0, x1, y, s) { for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) this.set(x, y, s); };
  Plane.prototype.vline = function (x, y0, y1, s) { for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++) this.set(x, y, s); };

  function hash2(x, y) { let n = (x | 0) * 374761393 + (y | 0) * 668265263; n = Math.imul(n ^ (n >>> 13), 1274126177); return ((n ^ (n >>> 16)) >>> 0) / 4294967296; }
  const cellX = (i) => (i % GW) * CELL, cellY = (i) => FIELD_Y + ((i / GW) | 0) * CELL;
  const centre = (i) => ({ x: cellX(i) + 3.5, y: cellY(i) + 3.5 });

  function line(p, x0, y0, x1, y1, s, dotted) {
    const n = Math.max(1, Math.ceil(Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0))));
    for (let k = 0; k <= n; k++) { if (dotted && k % 2) continue; p.set(Math.round(x0 + (x1 - x0) * k / n), Math.round(y0 + (y1 - y0) * k / n), s); }
  }

  /* ------------------------------------------------------------------ the parish */
  /** The static picture of a parish (everything but mills, carts and the cursor). `P` from PARISH.generate. */
  function parishPlane(P) {
    const p = new Plane(W, H, LIT);
    const k = (x, y) => (x < 0 || y < 0 || x >= GW || y >= GH) ? -1 : P.kind[y * GW + x];
    const blocked = (x, y) => (x < 0 || y < 0 || x >= GW || y >= GH) ? false : !!P.block[y * GW + x];
    // ground: shade 0 with hashed shade-1 grain; FURROWS (shade 1, texture only) on the ground round each farm
    const farmNear = new Int16Array(GW * GH).fill(-1);
    P.homes.forEach((h, i) => { const hx = h.c % GW, hy = (h.c / GW) | 0; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const x = hx + dx, y = hy + dy; if (x >= 0 && y >= 0 && x < GW && y < GH && !blocked(x, y) && farmNear[y * GW + x] < 0) farmNear[y * GW + x] = i; } });
    for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
      const X = x * CELL, Y = FIELD_Y + y * CELL, fi = farmNear[y * GW + x];
      const dir = fi >= 0 ? Math.floor(hash2(fi * 7, P.seed) * 3) : -1;   // 0 horizontal, 1 vertical, 2 diagonal furrows
      for (let j = 0; j < CELL; j++) for (let i = 0; i < CELL; i++) {
        const px = X + i, py = Y + j, h = hash2(px, py);
        let s = h < 0.05 ? FACE : LIT;
        if (dir >= 0 && P.farmAt[y * GW + x] < 0) {
          const f = dir === 0 ? py : dir === 1 ? px : (px + py);
          if (f % 3 === 0 && h < 0.85) s = FACE;
        }
        p.set(px, py, s);
      }
    }
    // tussocks on open ground far from farms: a 3-px shade-1 tuft (never an edge colour)
    for (let c = 0; c < GW * GH; c++) if (!P.block[c] && farmNear[c] < 0 && hash2(c, P.seed * 3 + 1) < 0.18) { const X = cellX(c) + 1 + Math.floor(hash2(c, 5) * 5), Y = cellY(c) + 2 + Math.floor(hash2(c, 9) * 4); p.set(X, Y, FACE); p.set(X + 1, Y - 1, FACE); p.set(X + 2, Y, FACE); }

    // WATER: river and ponds share a body (shade 2) with a dark bank where it meets the land and lit ripples.
    const water = (x, y) => { const t = k(x, y); return t === RIVER || t === POND; };
    for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
      const t = k(x, y); if (t !== RIVER && t !== POND) continue;
      const X = x * CELL, Y = FIELD_Y + y * CELL;
      const L = water(x - 1, y) || k(x - 1, y) === BRIDGE, R = water(x + 1, y) || k(x + 1, y) === BRIDGE, U = water(x, y - 1) || k(x, y - 1) === BRIDGE || (t === RIVER && y === 0), D = water(x, y + 1) || k(x, y + 1) === BRIDGE || (t === RIVER && y === GH - 1);
      for (let j = 0; j < CELL; j++) for (let i = 0; i < CELL; i++) {
        // rounded outer corners where two sides are land
        const cut = (!L && !U && i + j < 2) || (!R && !U && (7 - i) + j < 2) || (!L && !D && i + (7 - j) < 2) || (!R && !D && (7 - i) + (7 - j) < 2);
        if (cut) continue;
        const bank = (!L && i === 0) || (!R && i === 7) || (!U && j === 0) || (!D && j === 7) || (!L && !U && i + j < 3) || (!R && !U && (7 - i) + j < 3) || (!L && !D && i + (7 - j) < 3) || (!R && !D && (7 - i) + (7 - j) < 3);
        const px = X + i, py = Y + j;
        let s = bank ? SHADOW : MID;
        if (!bank) {
          // ripples: short lit dashes, hashed per pixel row so a long river never repeats
          const ph = (t === RIVER) ? (px + Math.floor(hash2(0, py) * 9)) % 7 : (px * 2 + py * 3) % 11;
          if (ph === 0 && hash2(px >> 1, py) < 0.5 && (py % 3 === 1)) s = LIT;
          else if (hash2(px, py) < 0.06) s = SHADOW;
        }
        p.set(px, py, s);
      }
      // reeds on pond rims: dark ticks with a lit head, on the land side
      if (t === POND) for (let e = 0; e < 3; e++) if (hash2(x * 5 + e, y * 7) < 0.35) { const rx = X + 1 + Math.floor(hash2(x, y + e) * 6), ry = (!U ? Y : !D ? Y + 7 : Y + 3); if (!U || !D) { p.set(rx, ry - 1, SHADOW); p.set(rx, ry - 2, SHADOW); p.set(rx, ry - 3, FACE); } }
    }
    // BRIDGES: a lit plank deck with dark rails, laid ACROSS the water it spans
    // ⛔ REVIEW 2026-09-23 (defect 8): the generator (kept VERBATIM for the screen) turns ONE river-path cell into a
    // passable "bridge", but where the river jogs sideways that cell has water on only ONE side — a pier into water.
    // 9 of 26 drawn bridges on the shipped 40 did not cross. A bridge is now drawn only where it has water on two
    // OPPOSITE sides and passable land on the other two; any other bridge cell is what it really is to the walker —
    // a spit of river bank — and is drawn as bank ground with the water's edge.
    const land = (x, y) => x >= 0 && y >= 0 && x < GW && y < GH && !P.block[y * GW + x];
    const crosses = (x, y) => (water(x, y - 1) && water(x, y + 1) && land(x - 1, y) && land(x + 1, y)) || (water(x - 1, y) && water(x + 1, y) && land(x, y - 1) && land(x, y + 1));
    for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
      if (k(x, y) !== BRIDGE || crosses(x, y)) continue;
      const X = x * CELL, Y = FIELD_Y + y * CELL;
      for (let j = 0; j < CELL; j++) for (let i = 0; i < CELL; i++) {
        const edge = (water(x - 1, y) && i === 0) || (water(x + 1, y) && i === 7) || (water(x, y - 1) && j === 0) || (water(x, y + 1) && j === 7);
        p.set(X + i, Y + j, edge ? SHADOW : (hash2(X + i, Y + j) < 0.25 ? FACE : LIT));
      }
    }
    for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
      if (k(x, y) !== BRIDGE || !crosses(x, y)) continue;
      const X = x * CELL, Y = FIELD_Y + y * CELL, vertRiver = water(x, y - 1) || water(x, y + 1);
      for (let j = 0; j < CELL; j++) for (let i = 0; i < CELL; i++) {
        const a = vertRiver ? j : i, b = vertRiver ? i : j;   // a = across the deck (rail rows), b = along it
        let s;
        if (a === 0 || a === 7) s = MID;                         // water peeking at the ends of the span
        else if (a === 1 || a === 6) s = SHADOW;                 // the rails
        else s = (b % 3 === 2) ? FACE : LIT;                     // planks with seams
        p.set(X + i, Y + j, s);
      }
      // ⛔ ART ROUND 1: a deck exactly as wide as the river read as a GAP in it (a ford). The parapets now run 2 px
      // out over each bank and end in dark posts — a span over water, not a hole in it.
      for (let e = -2; e <= 9; e++) for (const r of [1, 6]) { if (vertRiver) p.set(X + e, Y + r, SHADOW); else p.set(X + r, Y + e, SHADOW); }
      for (const e of [-2, 9]) for (const r of [0, 2, 5, 7]) { if (vertRiver) p.set(X + e, Y + r, SHADOW); else p.set(X + r, Y + e, SHADOW); }
    }
    // WALLS: a drystone band through the cell, joined to its wall neighbours; dark with shade-2 stones
    for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
      if (k(x, y) !== WALL) continue;
      const X = x * CELL, Y = FIELD_Y + y * CELL, L = k(x - 1, y) === WALL, R = k(x + 1, y) === WALL, U = k(x, y - 1) === WALL, D = k(x, y + 1) === WALL;
      const inBand = (i, j) => (j >= 1 && j <= 6 && i >= (L ? 0 : 1) && i <= (R ? 7 : 6)) && (L || R || !(U || D)) || (i >= 1 && i <= 6 && j >= (U ? 0 : 1) && j <= (D ? 7 : 6)) && (U || D);
      const inCore = (i, j) => i >= 1 && i <= 6 && j >= 1 && j <= 6;
      for (let j = 0; j < CELL; j++) for (let i = 0; i < CELL; i++) {
        if (!inBand(i, j) && !inCore(i, j)) continue;
        const px = X + i, py = Y + j;
        // coursed stones: offset rows of 3-px stones, mortar dark
        const row = Math.floor(py / 2), off = (row % 2) * 2, stone = ((px + off) % 4 !== 0) && (py % 2 === 0 || hash2(px, py) < 0.3);
        p.set(px, py, stone ? MID : SHADOW);
      }
      // coping: a lit top edge on the upper face of horizontal runs so the wall stands UP from the field
      if (L || R || !(U || D)) for (let i = (L ? 0 : 1); i <= (R ? 7 : 6); i++) if (hash2(X + i, Y) < 0.7) p.set(X + i, Y + 1, FACE);
    }
    // FARMS: w cottages on a shade-1 yard
    P.homes.forEach((h) => drawFarm(p, h.c, h.w, P.seed));
    return p;
  }

  /* ⛔ ART ROUND 1 (LOOKED AT art/zoom_pair_4x.png): w identical 3-px cottages read as a line of TEXT ("aaaa"),
   * and a shade-1 yard on shade-0 ground was invisible (§0-ART-g). A farm is now ONE building whose SIZE AND
   * SILHOUETTE climb a four-step ladder — cottage, house, farmhouse with chimney, farmhouse with barn — lit walls
   * inside a dark outline, dark roofs, on a shade-2 yard; and the HUD prints the cart count when you stand on it. */
  // ⛔ REVIEW 2026-09-23 (defect 11): the 4-cart farm was the same footprint as the 3-cart one and a near-solid dark
  // square that read as a WALL STUB. The ladder now grows in WIDTH and in PEAKS: a small cottage (1), a house (2), a
  // wide farmhouse with a chimney (3), and a double-gabled farmhouse, two peaks and two lit windows (4).
  const FARMS = {
    1: ['........', '........', '........', '...33...', '..3333..', '..3003..', '..3033..', '..3333..'],
    2: ['........', '........', '...33...', '..3333..', '.333333.', '.300003.', '.303303.', '.333333.'],
    3: ['......3.', '...33.3.', '..333333', '.3333333', '33333333', '30000003', '30030303', '33333333'],
    4: ['..3..3..', '.333333.', '33333333', '33333333', '30033003', '30033003', '30333303', '33333333'],
  };
  function drawFarm(p, c, w, seed) {
    const X = cellX(c), Y = cellY(c), S = FARMS[Math.max(1, Math.min(4, w))];
    // the yard: shade 2, rounded, a little smaller than the cell — the farm's ground, and an edge against the field
    for (let j = 1; j < CELL; j++) for (let i = 0; i < CELL; i++) { if ((i === 0 || i === 7) && (j === 1 || j === 7)) continue; if (j >= 5) p.set(X + i, Y + j, MID); }
    for (let j = 0; j < 8; j++) for (let i = 0; i < 8; i++) { const ch = S[j][i]; if (ch === '3') p.set(X + i, Y + j, SHADOW); else if (ch === '0') p.set(X + i, Y + j, LIT); else if (ch === '2') p.set(X + i, Y + j, MID); }
  }

  /* ------------------------------------------------------------------ the windmill */
  /** A post mill: a dark tapered tower rising from cell `c`, a cap, and four sails turning at angle `ang`.
   *  mode: 'solid' (raised), 'ghost' (dotted outline — the proved-best mill in the reveal), 'plan' (small). */
  function drawMill(p, c, ang, mode) {
    const cx = cellX(c) + 3.5, base = cellY(c) + 7, top = base - 9, hub = { x: cx, y: top - 1 };
    const ghost = mode === 'ghost';
    // tower: trapezoid 6 px wide at the base, 4 at the top
    for (let y = top; y <= base; y++) {
      const t = (y - top) / (base - top), half = 2 + t * 1.2;
      for (let x = Math.round(cx - half); x <= Math.round(cx + half); x++) {
        const edge = x === Math.round(cx - half) || x === Math.round(cx + half) || y === top || y === base;
        if (ghost) { if (edge && (x + y) % 2 === 0) p.set(x, y, SHADOW); continue; }
        p.set(x, y, edge ? SHADOW : MID);
      }
    }
    if (!ghost) { p.set(Math.round(cx), base - 1, LIT); p.set(Math.round(cx), base - 2, LIT); p.set(Math.round(cx) - 1, top + 3, FACE); }  // door, window
    // cap
    for (let x = Math.round(cx - 2); x <= Math.round(cx + 2); x++) p.set(x, top - 1, ghost ? ((x % 2) ? SHADOW : NONE) : SHADOW);
    // ⛔ ART ROUND 1: spar + a stray cloth pixel per step read as a spiky SCRIBBLE. Each sail is now a FILLED
    // lattice blade: a dark spar, a shade-2 cloth panel 2 px wide beside it from t=2 to the tip, a dark outer edge.
    for (let b = 0; b < 4; b++) {
      const a = ang + b * Math.PI / 2, dx = Math.cos(a), dy = Math.sin(a), L = 7;
      if (ghost) { for (let t = 1; t <= L; t += 1) p.set(hub.x + dx * t, hub.y + dy * t, SHADOW); continue; }
      for (let t = 2; t <= L; t += 0.35) for (let w = 0.7; w <= 2.6; w += 0.35) p.set(hub.x + dx * t - dy * w, hub.y + dy * t + dx * w, (w > 2.2 || t > L - 0.4) ? SHADOW : MID);
      for (let t = 0.5; t <= L; t += 0.35) p.set(hub.x + dx * t, hub.y + dy * t, SHADOW);
    }
    p.set(Math.round(hub.x), Math.round(hub.y), ghost ? SHADOW : LIT);
  }
  /** The HUD's mill glyph (7x8): filled = raised, outline = still to raise. */
  function millGlyph(p, x, y, filled) {
    const G = ['3.....3', '.3...3.', '..333..', '.3.3.3.', '3.333.3', '..333..', '..333..', '.33333.'];
    for (let j = 0; j < G.length; j++) for (let i = 0; i < 7; i++) if (G[j][i] === '3') p.set(x + i, y + j, filled ? LIT : SHADOW);
  }

  /** A cart track along a list of cells (dotted, through the cell centres, jogging ±1 px so it reads as a lane). */
  function drawTrack(p, cells, s, phase) {
    for (let k = 1; k < cells.length; k++) {
      const a = centre(cells[k - 1]), b = centre(cells[k]);
      const n = 8;
      for (let t = 0; t < n; t++) { if ((t + k * n + (phase || 0)) % 3 === 0) continue; p.set(Math.round(a.x + (b.x - a.x) * t / n), Math.round(a.y + (b.y - a.y) * t / n), s); }
    }
  }
  /** A cart (6x5) at a point. ⛔ REVIEW 2026-09-23 (defect 13): a 4x3 dark cart was indistinguishable from the dotted
   *  track under it in a still. Now a LIT load of sacks inside a dark bed, on two dark wheels — the one lit thing on a
   *  dark dotted lane. */
  function drawCart(p, x, y) {
    x = Math.round(x) - 3; y = Math.round(y) - 3;
    p.rect(x, y + 1, 6, 3, SHADOW); p.rect(x + 1, y, 4, 3, LIT); p.set(x + 1, y, SHADOW); p.set(x + 4, y, SHADOW);
    p.set(x + 1, y + 4, SHADOW); p.set(x + 4, y + 4, SHADOW);
  }
  /** THE MILLWRIGHT (review defect 3: "tap the millwright" named a figure the picture never drew). 6x8, dark with a
   *  lit face, legs swinging on frame 1; a 1-px LIT halo first so he reads on a dark farm yard as well as the field. */
  const MILLWRIGHT_FRAMES = [
    ['..33..', '.3333.', '.3003.', '..33..', '.3333.', '3.33.3', '.3333.', '.3..3.'],
    ['..33..', '.3333.', '.3003.', '..33..', '.3333.', '3.33.3', '.3333.', '..3.3.'],
  ];
  function drawMillwright(p, c, frame) {
    const F = MILLWRIGHT_FRAMES[frame % 2], X = cellX(c) + 1, Y = cellY(c);
    for (let j = 0; j < 8; j++) for (let i = 0; i < 6; i++) if (F[j][i] !== '.') for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const ni = i + dx, nj = j + dy; if (ni < 0 || nj < 0 || ni >= 6 || nj >= 8 || F[nj][ni] === '.') p.set(X + ni, Y + nj, LIT);
    }
    for (let j = 0; j < 8; j++) for (let i = 0; i < 6; i++) { const ch = F[j][i]; if (ch === '3') p.set(X + i, Y + j, SHADOW); else if (ch === '0') p.set(X + i, Y + j, LIT); }
  }

  /** The sky band (24 rows): shade 2, a far hill line, a hedge line at the edge of the parish. */
  function skyBand(p, seedVar) {
    for (let y = 0; y < FIELD_Y; y++) for (let x = 0; x < W; x++) p.set(x, y, MID);
    for (let x = 0; x < W; x++) {
      const hh = Math.round(3 + 2 * Math.sin(x * 0.045 + seedVar) + 1.5 * Math.sin(x * 0.13 + seedVar * 2));
      for (let y = FIELD_Y - 1 - hh; y < FIELD_Y - 1; y++) p.set(x, y, (y === FIELD_Y - 1 - hh) ? SHADOW : (hash2(x, y) < 0.3 ? SHADOW : MID));
      p.set(x, FIELD_Y - 1, SHADOW);
    }
  }

  /* ============================================================================ THE TITLE ART
   * Baked to art/title.png by Internal_Ops/build_art.js (a REAL shipped file, drawn with drawImage — never read
   * back, so it works on the paid build's file:// origin). A big post mill on a rise, furrowed fields falling away
   * to a river and a hamlet, the lettering in a dark band at the top. */
  function titlePlane(font, sailAng) {
    const p = new Plane(W, H, MID);
    // sky: shade 2 with two long shade-1 cloud bars
    [[20, 40, 26], [104, 50, 30]].forEach(([cx, cy, L]) => { for (let i = -L; i <= L; i++) { p.set(cx + i, cy, FACE); if (Math.abs(i) < L - 6) p.set(cx + i + 3, cy - 1, FACE); } });
    // the land: a rise on the left for the mill, fields to the right
    const ground = (x) => Math.round(84 - 18 * Math.exp(-((x - 46) ** 2) / 1400) + 3 * Math.sin(x * 0.07));
    for (let x = 0; x < W; x++) { const g = ground(x); for (let y = g; y < H; y++) p.set(x, y, LIT); p.set(x, g, SHADOW); if (hash2(x, 3) < 0.4) p.set(x, g - 1, SHADOW); }
    // furrows in perspective, fanning from a vanishing point far right
    for (let y = 70; y < H; y++) for (let x = 0; x < W; x++) { if (p.get(x, y) !== LIT) continue; const u = (x - 150) / Math.max(1, y - 58); if (Math.abs((u * 9) - Math.round(u * 9)) < 0.12 * (1 + (y - 70) / 60)) p.set(x, y, FACE); }
    // a river winding across the bottom right
    // ⛔ TITLE ROUND 1 (LOOKED AT title_4x.png): (x+y)%7 stripes made the river a RAILWAY TRACK. Sparse short ripples.
    for (let y = 104; y < H; y++) { const cx = 118 + 10 * Math.sin(y * 0.09); for (let x = Math.round(cx - 5); x <= Math.round(cx + 5); x++) p.set(x, y, (x === Math.round(cx - 5) || x === Math.round(cx + 5)) ? SHADOW : (((x * 3 + y * 5) % 17 === 0 && y % 3 === 0) ? LIT : MID)); }
    // a hamlet: three farms
    [[88, 96, 3], [100, 112, 2], [70, 118, 4], [140, 92, 1]].forEach(([x, y, w]) => { const c = ((y - FIELD_Y) >> 3) * GW + (x >> 3); drawFarm(p, c, w, 0); });
    // the big mill on the rise
    // ⛔ TITLE ROUND 1: a 34-px tower with 30-px sails put the top blades INSIDE the lettering band. Shorter tower,
    // shorter sails: the highest blade tip now stops below y 23.
    const mx = 46, base = ground(46) + 2, top = base - 22;
    for (let y = top; y <= base; y++) { const t = (y - top) / (base - top), half = 5 + t * 4; for (let x = Math.round(mx - half); x <= Math.round(mx + half); x++) { const edge = x === Math.round(mx - half) || x === Math.round(mx + half); p.set(x, y, edge ? SHADOW : ((y % 5 === 0) ? SHADOW : MID)); } }
    for (let x = mx - 6; x <= mx + 6; x++) { p.set(x, top - 1, SHADOW); p.set(x, top - 2, SHADOW); } for (let x = mx - 4; x <= mx + 4; x++) p.set(x, top - 3, SHADOW);
    p.rect(mx - 1, base - 7, 3, 7, SHADOW); p.set(mx, base - 6, FACE);
    const hub = { x: mx, y: top - 1 }, a0 = sailAng === undefined ? 0.5 : sailAng;
    for (let b = 0; b < 4; b++) {
      const a = a0 + b * Math.PI / 2, dx = Math.cos(a), dy = Math.sin(a);
      for (let t = 2; t <= 20; t += 0.4) {
        const x = hub.x + dx * t, y = hub.y + dy * t;
        p.set(x, y, SHADOW); p.set(x + 0.5, y + 0.5, SHADOW);
        if (t >= 6) for (let w = 1; w <= 5; w++) { const sx = x - dy * w, sy = y + dx * w; p.set(sx, sy, (w === 5 || Math.round(t) % 4 === 0) ? SHADOW : LIT); }
      }
    }
    for (let j = -2; j <= 2; j++) for (let i = -2; i <= 2; i++) if (i * i + j * j <= 5) p.set(hub.x + i, hub.y + j, (i * i + j * j <= 1) ? LIT : SHADOW);
    if (font) {
      p.rect(0, 2, W, 20, SHADOW); p.hline(0, W - 1, 1, MID); p.hline(0, W - 1, 22, MID);
      font.textPlane(p, 'MILLWRIGHT', W / 2, 6, { align: 'center', face: 'display', shade: LIT });
    }
    return p;
  }

  return { LIT, FACE, MID, SHADOW, NONE, W, H, FIELD_Y, CELL, GW, GH, Plane, hash2, cellX, cellY, centre, line, parishPlane, drawFarm, drawMill, millGlyph, drawTrack, drawCart, drawMillwright, skyBand, titlePlane };
}));
