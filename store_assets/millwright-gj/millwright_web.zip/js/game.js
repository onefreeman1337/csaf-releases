/**
 * game.js — MILLWRIGHT. Raise three windmills in a farming parish; every farm carts its grain to its nearest mill.
 *
 * ONE SENTENCE OF DESIGN: a mill stays where you raise it, and the number at your feet — the parish's total hauling
 * if a mill stood here, with the mills already up — rewards the middle of everything, which is where the first
 * mill must NOT go. The proved-least hauling of any three mills (parish.js solve(), exhaustive) is the par.
 *
 * ⛔ PREREG_2 (Internal_Ops/PREREG_2_2026-09-23.md) BINDS THIS FILE: ONE preview number, for the set (raised + here);
 *    never a preview of a multi-mill set, never a reversible stake. GOLD = within 1% of par, the registered line.
 * ⛔ THE PRIMARY INPUT IS A HOLD / DRAG (wing §0a-2): hold a direction and the millwright walks the parish while the
 *    number updates every step; on touch or with a mouse he walks to where the finger is. RAISE is the one press.
 * ⛔ §1a: the automation tab is hidden and rAF is throttled to zero there, so every harness drives the game through
 *    the synchronous `window.MILLWRIGHT.step(n)` and reads `window.MILLWRIGHT.frames`.
 * ⛔ §6b-64: every device the listing claims is driven with its REAL vocabulary by the harness — keyboard holds
 *    (4-way), pointer cells under a finger — never an exact vector no device produces.
 */
(function (root) {
  'use strict';

  var ART = root.ART, FONT = root.DW_FONT, C = root.CONTENT, SND = root.PSOUND, PARISH = root.PARISH;
  var W = ART.W, H = ART.H, LIT = ART.LIT, FACE = ART.FACE, MID = ART.MID, SHADOW = ART.SHADOW;
  var GW = ART.GW, GH = ART.GH, N = GW * GH;
  var DMG = ['#9bbc0f', '#8bac0f', '#306230', '#0f380f'];
  var WALK_FRAMES = 5, DAS_FRAMES = 12, RAISE_FRAMES = 36, DONE_FRAMES = 150;

  if (!C || !C.parishes || !C.parishes.length) throw new Error('content: no parishes');

  var S = {
    screen: 'title', frames: 0, pi: 0, run: null, result: null,
    dirOrder: [], muted: false, paused: false, endPage: 0, ledgerPage: 0, toast: null,
    best: {}, pointer: null,
  };

  var ED = C.edition === 'full' ? 'full' : 'free';
  var BEST_KEY = 'MILLWRIGHT_BEST_' + ED, PI_KEY = 'MILLWRIGHT_PI_' + ED;
  try { S.best = JSON.parse(root.localStorage.getItem(BEST_KEY) || '{}') || {}; } catch (e) { S.best = {}; }
  function saveBest() { try { root.localStorage.setItem(BEST_KEY, JSON.stringify(S.best)); } catch (e) { /* private mode */ } }
  function savePi() { try { root.localStorage.setItem(PI_KEY, String(S.pi)); } catch (e) { /* private mode */ } }
  function bestFor(id) { var b = S.best[String(id)]; return typeof b === 'number' ? b : null; }

  var parishCache = {};
  function parish(ix) { var sd = C.parishes[ix].seed; if (!parishCache[sd]) parishCache[sd] = PARISH.generate(sd); return parishCache[sd]; }
  function par(ix) { return PARISH.solve(parish(ix)).cost; }

  /* ⛔ REVIEW 2026-09-23 (defect 2): with BRONZE at 15% the obvious "lowest number now" play passed 24 of 40 parishes,
   * so the insight was optional. MEASURED (Internal_Ops/_measure_bands.js on the pre-registered rows): the INSIGHT-LAST
   * player's worst shipped parish is 3.74% over par, so an 8% BRONZE line passes that player on 40/40 with double margin
   * while the obvious play passes 10/40. GOLD stays the pre-registered "within 1%". SILVER 4%, BRONZE 8%.
   * ⛔ (defect 9) "THE SHORTEST HAULING THERE IS" was false on a within-1% GOLD above par: the line now says which. */
  var MEDALS = [
    { name: 'GOLD', max: 1.01 + 1e-9, line: 'THE SHORTEST HAULING THERE IS', near: 'WITHIN 1% OF THE LEAST' },
    { name: 'SILVER', max: 1.04, line: 'A FINE PARISH' },
    { name: 'BRONZE', max: 1.08, line: 'THE GRAIN GETS THROUGH' },
    { name: 'LONG ROADS', max: Infinity, line: 'THE CARTS ARE LATE HOME' },
  ];
  function medalFor(ratio) { for (var i = 0; i < MEDALS.length; i++) if (ratio <= MEDALS[i].max) return MEDALS[i]; return MEDALS[3]; }
  /** The next parish opens on BRONZE or better; LONG ROADS is the loss (retry, or look at the best mills). */
  function passed(ix) { var b = bestFor(C.parishes[ix].id); return b !== null && medalFor(b / par(ix)).name !== 'LONG ROADS'; }
  function unlocked(ix) { return ix === 0 || passed(ix - 1) || bestFor(C.parishes[ix].id) !== null; }
  (function restorePi() {
    var v = 0;
    try { v = parseInt(root.localStorage.getItem(PI_KEY) || '0', 10) || 0; } catch (e) { v = 0; }
    v = Math.max(0, Math.min(C.parishes.length - 1, v));
    while (v > 0 && !unlocked(v)) v--;
    S.pi = v;
  }());

  /* ------------------------------------------------------------------------ the walking */
  function beginRun() {
    var P = parish(S.pi), opt = PARISH.solve(P), start = PARISH.startCell(P);
    S.run = {
      P: P, opt: opt, raised: [], cursor: start, cooldown: 0, lastDir: null, confirm: false,
      raising: 0, done: 0, steps: 0, bumps: 0, refusals: {}, trace: [], preview: PARISH.preview(P, [], start),
    };
    S.screen = 'play'; S.paused = false; S.toast = null; S.pointer = null;
    if (SND) SND.cue('start');
  }

  var DIRS = { left: [-1, 0], right: [1, 0], up: [0, -1], down: [0, 1] };
  function neighbour(i, d) {
    var x = i % GW, y = (i / GW) | 0, nx = x + DIRS[d][0], ny = y + DIRS[d][1];
    if (nx < 0 || ny < 0 || nx >= GW || ny >= GH) return -1;
    return ny * GW + nx;
  }
  function toast(msg) { S.toast = { msg: msg, until: S.frames + 70 }; }

  /** Every refusal names its reason (wing §0z-1c) — counted in run.refusals, so a harness can read WHY. */
  var BLOCK_WORD = {}; BLOCK_WORD[PARISH.RIVER] = 'THE RIVER'; BLOCK_WORD[PARISH.WALL] = 'A WALL'; BLOCK_WORD[PARISH.POND] = 'A POND';
  function refuse(r, why, msg) {
    r.refusals[why] = (r.refusals[why] || 0) + 1; r.bumps++;
    if (r.lastRefusal !== why || S.frames - (r.lastRefusalAt || 0) > 20) { if (SND) SND.cue('bump'); if (msg) toast(msg); }
    r.lastRefusal = why; r.lastRefusalAt = S.frames;
    return false;
  }
  function tryMove(d) {
    var r = S.run, P = r.P, t = neighbour(r.cursor, d);
    if (t < 0) return refuse(r, 'edge', null);
    if (!P.reach[t]) {
      if (P.block[t]) return refuse(r, 'kind' + P.kind[t], BLOCK_WORD[P.kind[t]] || 'NO WAY');
      return refuse(r, 'fenced', 'NO WAY THROUGH');
    }
    r.cursor = t; r.cooldown = WALK_FRAMES; r.steps++;
    r.preview = PARISH.preview(P, r.raised, t);
    if (SND) SND.cue('step');
    return true;
  }
  function heldDir() { return S.dirOrder.length ? S.dirOrder[S.dirOrder.length - 1] : null; }

  /** A walk to a touched cell: the shortest way round everything blocked (BFS over the reachable cells). */
  function walkPath(P, a, b) {
    if (a === b) return [];
    if (!P.reach[b]) return null;
    var prev = new Int16Array(N).fill(-1), seen = new Uint8Array(N), q = [a]; seen[a] = 1;
    for (var h = 0; h < q.length; h++) { var u = q[h]; if (u === b) break;
      for (var k = 0; k < 4; k++) { var d = ['left', 'right', 'up', 'down'][k], v = neighbour(u, d); if (v >= 0 && P.reach[v] && !seen[v]) { seen[v] = 1; prev[v] = u; q.push(v); } } }
    if (!seen[b]) return null;
    var out = []; for (var c = b; c !== a; c = prev[c]) out.push(c); return out.reverse();
  }
  function dirTo(a, b) {
    var ax = a % GW, ay = (a / GW) | 0, bx = b % GW, by = (b / GW) | 0;
    if (ay === by && bx === ax - 1) return 'left'; if (ay === by && bx === ax + 1) return 'right';
    if (ax === bx && by === ay - 1) return 'up'; if (ax === bx && by === ay + 1) return 'down';
    return null;
  }

  function stepPlay() {
    var r = S.run;
    if (r.raising > 0) { r.raising--; if (r.raising === 0 && r.raised.length === PARISH.K) { r.done = DONE_FRAMES; if (SND) SND.cue('carts'); } return; }
    if (r.done > 0) { r.done--; if (r.done === 0) finish(); return; }
    if (r.cooldown > 0) { r.cooldown--; return; }
    if (r.confirm) return;
    if (r.trace.length) {
      var next = r.trace[0], d0 = dirTo(r.cursor, next);
      if (!d0) { r.trace.length = 0; return; }
      if (tryMove(d0)) r.trace.shift(); else r.trace.length = 0;
      return;
    }
    var d = heldDir();
    if (!d) { r.lastDir = null; return; }
    var fresh = d !== r.lastDir, moved = tryMove(d);
    if (fresh && moved) r.cooldown = Math.max(r.cooldown, DAS_FRAMES);
    r.lastDir = d;
  }

  /** RAISE: the first press asks (a mill is for good), the second raises. */
  function askRaise() {
    var r = S.run;
    if (r.raised.indexOf(r.cursor) >= 0) return refuse(r, 'mill', 'A MILL STANDS HERE');
    r.confirm = true; r.trace.length = 0; S.dirOrder = [];
    if (SND) SND.cue('ok');
    return true;
  }
  function raise() {
    var r = S.run;
    r.confirm = false;
    r.raised.push(r.cursor);
    r.raising = RAISE_FRAMES;
    r.preview = PARISH.cost(r.P, r.raised);
    if (SND) SND.cue('raise');
  }

  function finish() {
    var r = S.run, c = C.parishes[S.pi], hauling = PARISH.cost(r.P, r.raised), ratio = hauling / r.opt.cost, prev = bestFor(c.id);
    var isBest = prev === null || hauling < prev;
    if (isBest) { S.best[String(c.id)] = hauling; saveBest(); }
    var m = medalFor(ratio);
    S.result = { ok: true, hauling: hauling, par: r.opt.cost, ratio: ratio, medal: m, late: m.name === 'LONG ROADS', newBest: isBest, hadBest: prev !== null, prev: prev };
    if (SND) SND.cue(m.name === 'LONG ROADS' ? 'late' : 'done');
    S.screen = 'result';
  }

  /* ----------------------------------------------------------------------------- drawing */
  var plane = new ART.Plane(W, H, LIT);
  var baseCache = { key: '', plane: null };
  var CARDCH = Math.floor((W - 12 - 8) / FONT.FACES.body.adv);
  function wrap(str, max) {
    var words = String(str).split(' '), lines = [], cur = '';
    for (var i = 0; i < words.length; i++) { var nx = cur ? cur + ' ' + words[i] : words[i]; if (nx.length > max && cur) { lines.push(cur); cur = words[i]; } else cur = nx; }
    if (cur) lines.push(cur); return lines;
  }
  function baseFor(P) {
    if (baseCache.key !== P.seed) { var b = ART.parishPlane(P); ART.skyBand(b, P.seed % 7); baseCache.plane = b; baseCache.key = P.seed; }
    plane.px.set(baseCache.plane.px);
  }
  function text(str, x, y, o) { o = o || {}; if (o.halo === undefined && o.shade === LIT) o.halo = SHADOW; FONT.textPlane(plane, str, x, y, o); }
  function sailAngle(k) { return S.frames * 0.035 + k * 0.7; }

  /** ⛔ REVIEW 2026-09-23 (defect 3): the "millwright" was a marching-ants box. He is now a figure (art.js
   *  drawMillwright), legs swinging while he walks, with four blinking corner brackets round his cell — the cell a
   *  mill would be raised on. */
  function drawCursor(r) {
    var on = (S.frames >> 3) % 2 === 0, X = ART.cellX(r.cursor), Y = ART.cellY(r.cursor), s = on ? SHADOW : LIT;
    [[-1, -1, 1, 1], [8, -1, -1, 1], [-1, 8, 1, -1], [8, 8, -1, -1]].forEach(function (b) { for (var k = 0; k < 3; k++) { plane.set(X + b[0] + b[2] * k, Y + b[1], s); plane.set(X + b[0], Y + b[1] + b[3] * k, s); } });
    ART.drawMillwright(plane, r.cursor, r.cooldown > 0 ? (S.frames >> 2) & 1 : 0);
  }
  /** ⛔ REVIEW 2026-09-23 (defect 13): a raised mill's tower and sails reach into the cells round it and covered the
   *  roofs the player counts. Every farm NOT standing under a mill is drawn again on top of the mills. */
  function redrawFarms(P, mills) {
    P.homes.forEach(function (h) { if (mills.indexOf(h.c) < 0) ART.drawFarm(plane, h.c, h.w, P.seed); });
  }
  function drawTracks(r, mills, shade, phase) {
    var who = PARISH.assign(r.P, mills);
    r.P.homes.forEach(function (h, i) { ART.drawTrack(plane, PARISH.track(r.P, i, mills[who[i]]), shade, phase); });
  }
  function drawCarts(r, t) {
    var who = PARISH.assign(r.P, r.raised);
    r.P.homes.forEach(function (h, i) {
      var tr = PARISH.track(r.P, i, r.raised[who[i]]); if (tr.length < 2) return;
      var pos = t * (tr.length - 1), k = Math.min(tr.length - 2, Math.floor(pos)), f = pos - k, a = ART.centre(tr[k]), b = ART.centre(tr[k + 1]);
      ART.drawCart(plane, a.x + (b.x - a.x) * f, a.y + (b.y - a.y) * f);
    });
  }

  function hud(r) {
    // the number at your feet, and the par beneath it. ⛔ REVIEW (defect 12): HAUL with one mill up reads 2-5x the par
    // under it and a new player took that as failing — PAR is a THREE-mill total, so the HUD says so.
    text('HAUL ' + r.preview, 3, 3, { shade: LIT });
    text('PAR ' + r.opt.cost + ' AT 3 MILLS', 3, 13, { shade: LIT });
    for (var i = 0; i < PARISH.K; i++) ART.millGlyph(plane, W - 3 - (PARISH.K - i) * 9, 3, i < r.raised.length);
    // ⛔ LOOKED AT the gallery: on line 2 the cart count ran into the new PAR label ("PAR 39 AT 3 MILLS 3 CARTS").
    // It sits on line 1 now, left of the mill glyphs (HAUL ends by x 57; this starts at x >= 84).
    var fi = r.P.farmAt[r.cursor];
    if (fi >= 0) { var w = r.P.homes[fi].w; text(w + (w === 1 ? ' CART' : ' CARTS'), W - 3 - PARISH.K * 9 - 4, 3, { align: 'right', shade: LIT }); }
  }

  function drawPlayScreen() {
    var r = S.run;
    baseFor(r.P);
    if (r.raised.length) drawTracks(r, r.raised, MID, (S.frames >> 2) % 3);
    r.raised.forEach(function (m, k) {
      if (k === r.raised.length - 1 && r.raising > 0) {
        // the raising: the tower grows up out of the ground, the sails last
        var f = 1 - r.raising / RAISE_FRAMES; if (f > 0.6) ART.drawMill(plane, m, sailAngle(k), 'solid');
        else { var X = ART.cellX(m), Y = ART.cellY(m); for (var y = 0; y < Math.round(f / 0.6 * 9); y++) plane.hline(X + 1, X + 6, Y + 7 - y, y % 3 === 0 ? SHADOW : MID); }
      } else ART.drawMill(plane, m, sailAngle(k), 'solid');
    });
    redrawFarms(r.P, r.raised);
    if (r.done > 0) drawCarts(r, Math.min(1, (DONE_FRAMES - r.done) / (DONE_FRAMES * 0.7)));
    else drawCursor(r);
    hud(r);
    if (r.confirm) {
      plane.rect(19, 57, 122, 30, LIT); plane.rect(20, 58, 120, 28, SHADOW);
      text('RAISE A MILL HERE?', W / 2, 62, { align: 'center', shade: LIT });
      FONT.textPlane(plane, 'Z YES   X NO', W / 2, 74, { align: 'center', shade: FACE });
    }
    if (S.toast && S.frames < S.toast.until) {
      var w = S.toast.msg.length * 6 + 8, x = Math.round((W - w) / 2), low = ((r.cursor / GW) | 0) >= GH / 2, ty = low ? ART.FIELD_Y + 2 : 128;
      plane.rect(x, ty, w, 11, SHADOW); plane.hline(x, x + w - 1, low ? ty + 11 : ty - 1, LIT);
      text(S.toast.msg, W / 2, ty + 2, { align: 'center', shade: LIT, halo: undefined });
    }
    if (S.paused) {
      plane.rect(29, 53, 102, 40, LIT); plane.rect(30, 54, 100, 38, SHADOW);
      text('PAUSED', W / 2, 60, { align: 'center', shade: LIT });
      FONT.textPlane(plane, 'P RESUME', W / 2, 72, { align: 'center', shade: FACE });
      FONT.textPlane(plane, 'X GIVE UP', W / 2, 81, { align: 'center', shade: FACE });
    }
  }

  function cardFrame(title) {
    plane.px.fill(MID);
    for (var i = 0; i < 10; i++) plane.hline(0, W - 1, 7 + i * 15, SHADOW);
    plane.rect(6, 14, W - 12, H - 34, SHADOW);
    plane.hline(6, W - 7, 14, LIT);
    FONT.textPlane(plane, title, W / 2, 20, { align: 'center', shade: LIT });
    plane.hline(30, W - 31, 30, MID);
  }
  function card(title, lines, footer) {
    cardFrame(title);
    var flat = [];
    for (var j = 0; j < lines.length; j++) { if (!lines[j]) { flat.push(''); continue; } wrap(lines[j], CARDCH).forEach(function (l) { flat.push(l); }); }
    for (var k = 0; k < flat.length && 36 + k * 9 <= H - 22; k++) FONT.textPlane(plane, flat[k], W / 2, 36 + k * 9, { align: 'center', shade: FACE });
    if (footer) FONT.textPlane(plane, footer, W / 2, H - 12, { align: 'center', shade: SHADOW, halo: LIT });
  }

  var titleBase = null, titleImg = null, titleState = 'none';
  var FREE_BAND = { x: 36, y: H - 26, w: 88, h: 11 }, PRESS_BAND = { x: 44, y: H - 13, w: 72, h: 11 };
  function loadTitle() {
    if (titleState !== 'none' || !root.Image) return;
    titleState = 'loading';
    titleImg = new root.Image();
    titleImg.onload = function () { titleState = 'ready'; };
    titleImg.onerror = function () { titleState = 'failed'; };
    titleImg.src = 'art/title.png';
  }
  function drawTitle() {
    if (!titleBase) titleBase = ART.titlePlane(FONT);
    plane.px.set(titleBase.px);
    if (C.edition !== 'full') { plane.rect(FREE_BAND.x, FREE_BAND.y, FREE_BAND.w, FREE_BAND.h, SHADOW); FONT.textPlane(plane, 'FREE EDITION', W / 2, FREE_BAND.y + 2, { align: 'center', shade: LIT }); }
    if (S.frames % 48 < 32) { plane.rect(PRESS_BAND.x, PRESS_BAND.y, PRESS_BAND.w, PRESS_BAND.h, SHADOW); FONT.textPlane(plane, 'Z OR TAP', W / 2, PRESS_BAND.y + 2, { align: 'center', shade: LIT }); }
  }

  function drawYard() {
    var P = parish(S.pi), c = C.parishes[S.pi], b = bestFor(c.id);
    baseFor(P);
    text(c.name, 3, 3, { shade: LIT });
    text('Z START', W - 3, 3, { align: 'right', shade: LIT });
    text((S.pi + 1) + '/' + C.parishes.length, 3, 13, { shade: LIT });
    text(b === null ? P.homes.length + ' FARMS' : medalFor(b / par(S.pi)).name, W - 3, 13, { align: 'right', shade: LIT });
    // ⛔ REVIEW 2026-09-23 (defect 4): the "BRONZE OPENS THE NEXT" toast was set here and drawn by nothing (0 pixels).
    if (S.toast && S.frames < S.toast.until) {
      var w = S.toast.msg.length * 6 + 8, x = Math.round((W - w) / 2);
      plane.rect(x, 128, w, 11, SHADOW); plane.hline(x, x + w - 1, 127, LIT);
      text(S.toast.msg, W / 2, 130, { align: 'center', shade: LIT, halo: undefined });
    }
  }

  function drawResult() {
    var R = S.result, c = C.parishes[S.pi];
    cardFrame(R.medal.name);
    // the parish in miniature, with your three mills on it
    // ⛔ REVIEW 2026-09-23 (defect 14) + my own look: at 2 px/cell the mills were shade-1 crosses on shade-0 ground
    // (§0-ART-g: worth nothing) and could not be found. 3 px/cell, walls and water in shade 2, farms as dark dots with
    // a lit gap, and each mill a dark 7-px X with a lit hub — the only X shape on the map.
    var P = S.run.P, ox = 9, oy = 36;
    plane.rect(ox - 2, oy - 2, 64, 49, LIT);
    thumb(P, ox, oy, 3, S.run.raised);
    var tx = 112;
    FONT.textPlane(plane, c.name, tx, 34, { align: 'center', shade: LIT });
    FONT.textPlane(plane, 'YOUR HAULING', tx, 48, { align: 'center', shade: FACE });
    FONT.textPlane(plane, String(R.hauling), tx, 57, { align: 'center', shade: LIT });
    FONT.textPlane(plane, 'THE LEAST', tx, 70, { align: 'center', shade: FACE });
    FONT.textPlane(plane, String(R.par), tx, 79, { align: 'center', shade: LIT });
    FONT.textPlane(plane, R.newBest ? (R.hadBest ? 'A NEW BEST' : 'FIRST TRY') : 'YOUR BEST ' + R.prev, tx, 92, { align: 'center', shade: FACE });
    var line = R.late ? 'LATE HOME. BRONZE OPENS THE NEXT PARISH.' : (R.medal.near && R.hauling > R.par ? R.medal.near : R.medal.line);
    wrap(line, 24).slice(0, 2).forEach(function (l, i) { FONT.textPlane(plane, l, W / 2, 106 + i * 8, { align: 'center', shade: FACE }); });
    FONT.textPlane(plane, R.late ? 'Z RETRY  X A CLUE' : 'Z NEXT  X BEST MILLS', W / 2, H - 12, { align: 'center', shade: SHADOW, halo: LIT });
  }
  /** A parish thumbnail at `sc` px per cell. */
  function thumb(P, ox, oy, sc, mills) {
    for (var c = 0; c < N; c++) {
      var x = ox + (c % GW) * sc, y = oy + ((c / GW) | 0) * sc, s = P.block[c] ? MID : LIT;
      plane.rect(x, y, sc, sc, s);
      if (P.farmAt[c] >= 0) { plane.rect(x, y, sc, sc, SHADOW); if (sc >= 3) plane.set(x + 1, y + 1, LIT); }
    }
    (mills || []).forEach(function (m) {
      var x = ox + (m % GW) * sc + (sc >> 1), y = oy + ((m / GW) | 0) * sc + (sc >> 1);
      for (var d = -3; d <= 3; d++) { plane.set(x + d, y + d, SHADOW); plane.set(x + d, y - d, SHADOW); }
      plane.set(x, y, LIT);
    });
  }

  /** THE LESSON, on request after a result: the proved-best three mills and every farm's track to them, your own
   *  mills beneath as ghosts — the thing the player can learn to see. */
  /* ⛔ REVIEW 2026-09-23 (defect 10, MAJOR): after a LOSS this screen drew the best three mills on the same parish,
   * and Z retried it — lose, look, copy = GOLD on 10/10 free parishes (§6b-2 rule 4: a fail state whose remedy is free
   * and repeatable is not one). Now the ANSWER is shown only after a PASS. After a loss the player gets a CLUE: dotted
   * boxes round the farms that share a mill in the best answer (A, B, C) and no mill positions — the insight ("one mill
   * per hamlet") without the cells; finding each group's best cell is still the player's.
   * ⛔ (defect 7) the best mills blinked OFF a quarter of the time; they stay on now. (defect 5) X goes to the parishes. */
  function revealIsClue() { return !!(S.result && S.result.late); }
  function drawReveal() {
    var r = S.run, clue = revealIsClue(), foot = (S.frames % 192) < 96;
    baseFor(r.P);
    if (clue) {
      var who = PARISH.assign(r.P, r.opt.mills), tabs = [];
      for (var g = 0; g < r.opt.mills.length; g++) {
        var cells = r.P.homes.filter(function (h, i) { return who[i] === g; }).map(function (h) { return h.c; });
        if (!cells.length) continue;
        var xs = cells.map(function (c) { return c % GW; }), ys = cells.map(function (c) { return (c / GW) | 0; });
        var X0 = Math.min.apply(null, xs) * 8 - 2, X1 = (Math.max.apply(null, xs) + 1) * 8 + 1, Y0 = ART.FIELD_Y + Math.min.apply(null, ys) * 8 - 2, Y1 = ART.FIELD_Y + (Math.max.apply(null, ys) + 1) * 8 + 1;
        var on = function (k) { return g === 0 ? k % 2 === 0 : g === 1 ? k % 5 < 3 : k % 7 < 5; };
        for (var x = X0; x <= X1; x++) { if (on(x)) { plane.set(x, Y0, SHADOW); plane.set(x, Y1, SHADOW); } }
        for (var y = Y0; y <= Y1; y++) { if (on(y)) { plane.set(X0, y, SHADOW); plane.set(X1, y, SHADOW); } }
        tabs.push({ x: Math.max(0, X0), y: Y0 - 9 < ART.FIELD_Y ? Y0 + 1 : Y0 - 9, g: g });
      }
      r.raised.forEach(function (m) { ART.drawMill(plane, m, 0.3, 'ghost'); });
      redrawFarms(r.P, []);
      // LOOKED AT shot_7: group A's letter tab was drawn first and a farm redrawn over it — the tabs go on LAST.
      tabs.forEach(function (t) { plane.rect(t.x, t.y, 9, 9, SHADOW); plane.hline(t.x, t.x + 8, t.y + 9, LIT); FONT.textPlane(plane, 'ABC'.charAt(t.g), t.x + 5, t.y + 1, { align: 'center', shade: LIT }); });
      text('A CLUE: WHO SHARES A MILL', 3, 3, { shade: LIT });
      text(foot ? 'BRONZE SHOWS THE MILLS' : 'Z BACK  X PARISHES', 3, 13, { shade: LIT });
      return;
    }
    drawTracks(r, r.opt.mills, SHADOW, 0);
    r.raised.forEach(function (m) { if (r.opt.mills.indexOf(m) < 0) ART.drawMill(plane, m, 0.3, 'ghost'); });
    r.opt.mills.forEach(function (m, k) { ART.drawMill(plane, m, sailAngle(k), 'solid'); });
    redrawFarms(r.P, r.opt.mills);
    text('LEAST ' + r.opt.cost, 3, 3, { shade: LIT });
    text('YOURS ' + PARISH.cost(r.P, r.raised), W - 3, 3, { align: 'right', shade: LIT });
    text(foot ? 'SOLID BEST, DOTS YOURS' : 'Z BACK  X PARISHES', 3, 13, { shade: LIT });
  }

  /** THE LEDGER: every parish in miniature, ten to a page, with its medal. */
  function drawLedger() {
    plane.px.fill(MID);
    plane.rect(0, 0, W, 12, SHADOW);
    var pages = Math.ceil(C.parishes.length / 10), pg = Math.max(0, Math.min(S.ledgerPage, pages - 1));
    var got = 0; C.parishes.forEach(function (c) { if (bestFor(c.id) !== null) got++; });
    FONT.textPlane(plane, 'LEDGER ' + got + '/' + C.parishes.length, 3, 3, { shade: LIT });
    FONT.textPlane(plane, (pg + 1) + '/' + pages, W - 3, 3, { align: 'right', shade: LIT });
    for (var i = 0; i < 10; i++) {
      var ix = pg * 10 + i; if (ix >= C.parishes.length) break;
      var c = C.parishes[ix], cx = 3 + (i % 5) * 31, cy = 16 + Math.floor(i / 5) * 58;
      plane.rect(cx, cy, 29, 54, SHADOW);
      var b = bestFor(c.id);
      if (b !== null || unlocked(ix)) thumb(parish(ix), cx + 4, cy + 4, 1, null);
      if (b !== null) { var med = medalFor(b / par(ix)).name; FONT.textPlane(plane, med === 'LONG ROADS' ? '-' : med.charAt(0), cx + 14, cy + 24, { align: 'center', shade: LIT }); }
      else FONT.textPlane(plane, '?', cx + 14, cy + 24, { align: 'center', shade: MID });
      FONT.textPlane(plane, String(ix + 1), cx + 14, cy + 40, { align: 'center', shade: b !== null ? FACE : MID });
    }
    FONT.textPlane(plane, pages > 1 ? 'LEFT RIGHT: PAGE  X BACK' : 'X BACK', W / 2, H - 9, { align: 'center', shade: SHADOW, halo: LIT });
  }

  var LINES_PER_PAGE = 9;
  function endingPages() {
    var raw = C.ending || [].concat(C.demoEnd || ''), paras = [];
    for (var i = 0; i < raw.length; i++) if (raw[i]) paras.push(wrap(raw[i], CARDCH));
    var pages = [], cur = [];
    paras.forEach(function (p) {
      // ⛔ REVIEW 2026-09-23 (defect 6): the pager split the ending's key sentence across two pages. A paragraph that
      // fits on a fresh page but not in what is left of this one now starts the next page whole.
      if (cur.length && (LINES_PER_PAGE - cur.length < 3 || (cur.length + 1 + p.length > LINES_PER_PAGE && p.length <= LINES_PER_PAGE))) { pages.push(cur); cur = []; }
      if (cur.length) cur.push('');
      for (var k = 0; k < p.length; k++) { if (cur.length >= LINES_PER_PAGE) { pages.push(cur); cur = []; } cur.push(p[k]); }
    });
    if (cur.length) pages.push(cur);
    return pages.length ? pages : [['']];
  }
  function drawEnding() {
    var pages = endingPages(), page = Math.max(0, Math.min(S.endPage, pages.length - 1));
    cardFrame(C.ending ? C.endingTitle : 'END OF THE FREE EDITION');
    for (var k = 0; k < pages[page].length; k++) FONT.textPlane(plane, pages[page][k], W / 2, 38 + k * 9, { align: 'center', shade: FACE });
    var more = page < pages.length - 1;
    FONT.textPlane(plane, more ? 'Z MORE ' + (page + 1) + '/' + pages.length : 'Z CREDITS', W / 2, H - 12, { align: 'center', shade: SHADOW, halo: LIT });
  }
  // ⛔ SCREENS ROUND 1: eleven wrapped lines on a ten-line card cut 'PAR: THE LEAST THERE IS.' off the bottom. Nine now.
  // ROUND 2: 'THERE IS.' wrapped a 10th line. REVIEW (defect 12): PAR never said it is a THREE-mill total.
  var RULES = ['FARMS CART THEIR GRAIN TO THE NEAREST MILL.', 'BIG FARMS SEND MORE.', 'RAISE THREE MILLS. EACH ONE STAYS.',
    'HAUL: ALL THE CARTING IF A MILL STOOD HERE.', 'PAR: THE LEAST 3 MILLS CAN DO.'];
  var RULES_KEY = 'MILLWRIGHT_RULES_SEEN', rulesSeen = false;
  try { rulesSeen = root.localStorage.getItem(RULES_KEY) === '1'; } catch (e) { rulesSeen = false; }
  function markRulesSeen() { rulesSeen = true; try { root.localStorage.setItem(RULES_KEY, '1'); } catch (e) { /* private mode */ } }
  function drawRules() { card('THE PARISH', RULES, S.rulesThenRun ? 'Z START  X BACK' : 'Z OR X BACK'); }
  function drawCredits() {
    card('MILLWRIGHT', ['CORE SYSTEMS', 'ASSET FACTORY', '', 'CODE, ART AND TEXT MADE', 'WITH AI ASSISTANCE.', 'MUSIC AND SOUND ARE', 'SYNTHESISED FROM NOTES.'], 'X BACK');
  }

  /* ------------------------------------------------------------------------------ paint */
  var cv, ctx, img, data;
  var PAL = DMG.map(function (h) { return [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)]; });
  function paint() {
    for (var i = 0, p = 0; i < plane.px.length; i++, p += 4) { var c = PAL[plane.px[i]] || PAL[0]; data[p] = c[0]; data[p + 1] = c[1]; data[p + 2] = c[2]; data[p + 3] = 255; }
    ctx.putImageData(img, 0, 0);
    if (S.screen === 'title' && titleState === 'ready') {
      ctx.drawImage(titleImg, 0, 0, W, H);
      if (C.edition !== 'full') ctx.putImageData(img, 0, 0, FREE_BAND.x, FREE_BAND.y, FREE_BAND.w, FREE_BAND.h);
      ctx.putImageData(img, 0, 0, PRESS_BAND.x, PRESS_BAND.y, PRESS_BAND.w, PRESS_BAND.h);
    }
  }

  /* ------------------------------------------------------------------------------ input */
  function press(k) {
    if (SND) SND.unlock();
    if (k === 'mute') { S.muted = !S.muted; if (SND) SND.setMuted(S.muted); return; }
    if (S.screen === 'title') { if (k === 'ok') { S.screen = 'yard'; if (SND) SND.cue('ok'); } else if (k === 'back') S.screen = 'credits'; return; }
    if (S.screen === 'yard') {
      if (k === 'left' && S.pi > 0) { S.pi--; savePi(); if (SND) SND.cue('page'); }
      else if (k === 'right' && S.pi < C.parishes.length - 1 && unlocked(S.pi + 1)) { S.pi++; savePi(); if (SND) SND.cue('page'); }
      else if (k === 'right' && S.pi < C.parishes.length - 1) { if (SND) SND.cue('bump'); toast('BRONZE OPENS THE NEXT'); }
      else if (k === 'up') { S.screen = 'ledger'; S.ledgerPage = Math.floor(S.pi / 10); if (SND) SND.cue('ok'); }
      else if (k === 'down') { S.screen = 'rules'; S.rulesThenRun = false; if (SND) SND.cue('ok'); }
      else if (k === 'ok' && !rulesSeen) { S.screen = 'rules'; S.rulesThenRun = true; if (SND) SND.cue('ok'); }
      else if (k === 'ok') beginRun();
      else if (k === 'back') S.screen = 'title';
      return;
    }
    if (S.screen === 'rules') {
      if (k === 'ok' && S.rulesThenRun) { markRulesSeen(); beginRun(); }
      else if (k === 'ok' || k === 'back') { markRulesSeen(); S.screen = 'yard'; if (SND) SND.cue('ok'); }
      return;
    }
    if (S.screen === 'ledger') {
      var pages = Math.ceil(C.parishes.length / 10);
      if (k === 'left' && S.ledgerPage > 0) { S.ledgerPage--; if (SND) SND.cue('page'); }
      else if (k === 'right' && S.ledgerPage < pages - 1) { S.ledgerPage++; if (SND) SND.cue('page'); }
      else if (k === 'back' || k === 'ok' || k === 'down') { S.screen = 'yard'; if (SND) SND.cue('ok'); }
      return;
    }
    if (S.screen === 'play') {
      var r = S.run;
      if (r.raising > 0 || r.done > 0) return;
      if (r.confirm) { if (k === 'ok') raise(); else if (k === 'back') { r.confirm = false; if (SND) SND.cue('page'); } return; }
      if (k === 'pause' || (k === 'back' && !S.paused)) { S.paused = !S.paused; if (SND) SND.cue('ok'); }
      else if (k === 'back' && S.paused) { S.paused = false; S.result = { ok: false, gaveUp: true, raised: r.raised.length }; S.screen = 'gaveup'; }
      else if (k === 'ok' && S.paused) { S.paused = false; }
      else if (k === 'ok') askRaise();
      return;
    }
    if (S.screen === 'gaveup') { if (k === 'ok') beginRun(); else if (k === 'back') { S.screen = 'yard'; if (SND) SND.cue('ok'); } return; }
    if (S.screen === 'result') {
      if (k === 'back') { S.screen = 'reveal'; if (SND) SND.cue('ok'); return; }
      if (k === 'ok') {
        if (S.result.late) { beginRun(); return; }
        if (S.pi >= C.parishes.length - 1) { S.screen = 'ending'; S.endPage = 0; }
        else { S.pi++; savePi(); S.screen = 'yard'; }
        if (SND) SND.cue('ok');
      }
      return;
    }
    // REVIEW (defect 5): a loss card had no road back to the parishes except a new run. X from the reveal goes there.
    if (S.screen === 'reveal') { if (k === 'ok') { S.screen = 'result'; if (SND) SND.cue('ok'); } else if (k === 'back') { S.screen = 'yard'; if (SND) SND.cue('ok'); } return; }
    if (S.screen === 'ending') {
      if (k === 'ok') { if (S.endPage < endingPages().length - 1) { S.endPage++; if (SND) SND.cue('page'); } else S.screen = 'credits'; }
      return;
    }
    if (S.screen === 'credits') { if (k === 'back' || k === 'ok') S.screen = 'title'; }
  }
  function drawGaveUp() { card('LEFT UNBUILT', ['THE PARISH WAITS FOR ITS MILLS.', '', 'THE NUMBER AT YOUR FEET IS HONEST, BUT IT ONLY KNOWS THE MILLS ALREADY UP.'], 'Z RETRY  X PARISHES'); }

  var HELD = {};
  function holdKey(k, down) {
    HELD[k] = down;
    S.dirOrder = S.dirOrder.filter(function (d) { return d !== k; });
    if (down) S.dirOrder.push(k);
  }
  var KEYMAP = {
    ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down',
    a: 'left', d: 'right', w: 'up', s: 'down', A: 'left', D: 'right', W: 'up', S: 'down',
    z: 'ok', Z: 'ok', Enter: 'ok', ' ': 'ok', x: 'back', X: 'back', Escape: 'back', Backspace: 'back',
    p: 'pause', P: 'pause', m: 'mute', M: 'mute',
  };

  function cellAt(px, py) {
    if (py < ART.FIELD_Y) return -1;
    var x = Math.floor(px / ART.CELL), y = Math.floor((py - ART.FIELD_Y) / ART.CELL);
    if (x < 0 || y < 0 || x >= GW || y >= GH) return -1;
    return y * GW + x;
  }
  /** The pointer vocabulary, shared by the page's real events and the harness (§6b-64: the harness sends the same
   *  CELLS a finger lands on). A finger on the field sets where the millwright walks; he walks there cell by cell
   *  at his own pace, round anything blocked, and the number updates every step. A tap ON him asks to raise. */
  function pointerDown(cell) {
    S.pointer = { down: true, cell: cell, t0: S.frames, moved: false, onCursor: false };
    var r = S.run;
    if (S.screen !== 'play' || !r || S.paused || r.confirm || r.raising > 0 || r.done > 0 || cell < 0) return;
    if (cell === r.cursor) { S.pointer.onCursor = true; return; }
    var path = walkPath(r.P, r.cursor, cell);
    if (path) r.trace = path;
    else if (r.P.block[cell]) refuse(r, 'kind' + r.P.kind[cell], BLOCK_WORD[r.P.kind[cell]] || 'NO WAY');
    else refuse(r, 'fenced', 'NO WAY THROUGH');
  }
  function pointerMove(cell) {
    var P = S.pointer;
    if (!P || !P.down || cell === P.cell) return;
    P.moved = true; P.cell = cell;
    var r = S.run;
    if (cell < 0 || S.screen !== 'play' || !r || S.paused || r.confirm || r.raising > 0 || r.done > 0) return;
    // the walk re-aims at the finger from where he stands NOW (or from the cell he is stepping into)
    var from = r.cursor, path = walkPath(r.P, from, cell);
    if (path) r.trace = path;
  }
  function pointerUp() {
    var P = S.pointer; S.pointer = null;
    if (P && P.onCursor && !P.moved && S.screen === 'play' && S.run && !S.paused) press('ok');
    return P;
  }

  /* ------------------------------------------------------------------------------- loop */
  var draw = true;
  function step(n) {
    n = n === undefined ? 1 : n;
    for (var i = 0; i < n; i++) {
      S.frames++;
      if (S.screen === 'play' && !S.paused) stepPlay();
    }
    if (!draw) return;
    if (S.screen === 'title') drawTitle();
    else if (S.screen === 'yard') drawYard();
    else if (S.screen === 'play') drawPlayScreen();
    else if (S.screen === 'result') drawResult();
    else if (S.screen === 'reveal') drawReveal();
    else if (S.screen === 'ledger') drawLedger();
    else if (S.screen === 'ending') drawEnding();
    else if (S.screen === 'credits') drawCredits();
    else if (S.screen === 'rules') drawRules();
    else if (S.screen === 'gaveup') drawGaveUp();
    if (ctx) paint();
  }
  var STEP_MS = 1000 / 60, acc = 0, lastT = null;
  function frame(t) {
    if (lastT === null) lastT = t;
    acc += Math.min(250, t - lastT); lastT = t;
    var n = 0;
    while (acc >= STEP_MS && n < 4) { acc -= STEP_MS; n++; }
    if (n) step(n);
    root.requestAnimationFrame(frame);
  }

  function boot() {
    cv = root.document.getElementById('screen');
    ctx = cv.getContext('2d'); ctx.imageSmoothingEnabled = false;
    img = ctx.createImageData(W, H); data = img.data;
    loadTitle();
    root.addEventListener('keydown', function (e) {
      var k = KEYMAP[e.key]; if (!k) return;
      e.preventDefault();
      if (k === 'left' || k === 'right' || k === 'up' || k === 'down') {
        var was = HELD[k]; holdKey(k, true);
        if (!was && S.screen !== 'play') press(k);
        if (!was && S.screen === 'play' && S.run && S.run.cooldown > 0 && S.run.lastDir !== k) S.run.cooldown = Math.min(S.run.cooldown, 2);
      } else if (!e.repeat) press(k);
    });
    root.addEventListener('keyup', function (e) { var k = KEYMAP[e.key]; if (k && HELD[k]) holdKey(k, false); });
    root.addEventListener('blur', function () { HELD = {}; S.dirOrder = []; S.pointer = null; });
    function gamePt(e) { var b = cv.getBoundingClientRect(); return { x: (e.clientX - b.left) * W / b.width, y: (e.clientY - b.top) * H / b.height }; }
    var swipe = null;
    cv.addEventListener('pointerdown', function (e) {
      e.preventDefault(); if (SND) SND.unlock();
      try { cv.setPointerCapture(e.pointerId); } catch (err) { /* not capturable */ }
      var g = gamePt(e);
      swipe = { x: g.x, y: g.y, t: Date.now(), moved: false };
      if (S.screen === 'play') pointerDown(cellAt(g.x, g.y));
    });
    cv.addEventListener('pointermove', function (e) {
      if (!swipe) return;
      var g = gamePt(e);
      if (S.screen === 'play') { pointerMove(cellAt(g.x, g.y)); return; }
      var dx = g.x - swipe.x, dy = g.y - swipe.y;
      if (Math.hypot(dx, dy) < 10) return;
      swipe.moved = true;
      press(Math.abs(dx) > Math.abs(dy) ? (dx < 0 ? 'left' : 'right') : (dy < 0 ? 'up' : 'down'));
      swipe.x = g.x; swipe.y = g.y;
    });
    function up() {
      if (!swipe) return;
      var quick = !swipe.moved && Date.now() - swipe.t < 300;
      var wasPlay = S.screen === 'play';
      if (wasPlay) pointerUp();
      swipe = null;
      if (quick && !wasPlay) press('ok');
    }
    cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
    root.__mwPress = function (k) { press(k); };
    if (/[?&]harness=1\b/.test(root.location.search)) { step(1); return; }
    step(1);
    root.requestAnimationFrame(frame);
  }

  root.MILLWRIGHT = {
    step: step, setDraw: function (v) { draw = !!v; }, press: press,
    hold: function (dir, down) { holdKey(dir, down !== false); },
    releaseAll: function () { HELD = {}; S.dirOrder = []; S.pointer = null; },
    pointerDown: pointerDown, pointerMove: pointerMove, pointerUp: pointerUp, cellAt: cellAt,
    state: S, plane: plane, beginRun: beginRun, parish: parish, par: par, endingPages: endingPages, medalFor: medalFor, unlocked: unlocked, revealIsClue: revealIsClue,
    titleState: function () { return titleState; },
    get frames() { return S.frames; }, version: '1.0.0',
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.MILLWRIGHT;
  else if (root.document) { if (root.document.readyState === 'loading') root.addEventListener('DOMContentLoaded', boot); else boot(); }
}(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this)));
