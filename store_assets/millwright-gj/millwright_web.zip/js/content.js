/**
 * content.js — MILLWRIGHT, the FREE EDITION's content: the first ten parishes.
 * ⛔ wing §1-DEMO: the other thirty parish SPECS and the ending live in content_full.js, which the free
 *    index.html has no <script> tag for and the free package does not contain.
 * A spec is { id, seed, name }; parish.js turns `seed` into the parish. `seed` is the SCREENED parish index
 * (Internal_Ops/screen2.js, _screen2_rows.json), so every number in the candidate screen describes these parishes.
 * The forty were chosen by Internal_Ops/select_parishes.js (rule and yield printed there) and ordered as a ramp.
 * ⛔ The demo-end line is STORE-NEUTRAL from day one (ROOTWORK/NIGHT PLOUGH 1.0.1: "on this page" was false on Game Jolt).
 */
(function (root) {
  'use strict';
  root.CONTENT = {
    edition: 'free',
    // ⛔ REVIEW 2026-09-23 (defect 1): seed 11 opened the game and the obvious play missed BRONZE there by ONE cart-step,
    // with GOLD one cell away — it taught "nudge and retry". Seed 5, where the obvious play is 44% over par, opens it now
    // (select_parishes.js ordering amendment 2). Same ten free seeds; only the order moved.
    parishes: [
      { id: 1,  seed: 5,  name: 'ASHCOMBE' },
      { id: 2,  seed: 11, name: 'BRAMBLEY' },
      { id: 3,  seed: 48, name: 'COLDHARBOUR' },
      { id: 4,  seed: 10, name: 'DUNSMORE' },
      { id: 5,  seed: 49, name: 'ELMSTEAD' },
      { id: 6,  seed: 47, name: 'FERNHILL' },
      { id: 7,  seed: 27, name: 'GOSFORD' },
      { id: 8,  seed: 23, name: 'HOLLINS' },
      { id: 9,  seed: 9,  name: 'KEYSTOW' },
      { id: 10, seed: 21, name: 'LYNWICK' },
    ],
    endingTitle: 'THE SAILS TURN',
    ending: null,
    // ⛔ SCREENS ROUND 1: "longer rivers" was FALSE (Internal_Ops/_measure_ramp.js: river cells 11.6 free -> 8.4 paid)
    // and the line orphaned "DOWNLOAD." onto a second card. What rises, measured: farms 12.5 -> 16.3, carts 30 -> 40.
    demoEnd: ['TEN PARISHES GRIND THEIR OWN GRAIN.', 'THIRTY MORE WAIT, WITH MORE FARMS AND MORE CARTS ON THE ROAD. THE FULL GAME IS A PAID WINDOWS DOWNLOAD.'],
  };
}(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this)));
