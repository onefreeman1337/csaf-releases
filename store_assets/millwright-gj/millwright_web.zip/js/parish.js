/**
 * parish.js — MILLWRIGHT. The parish generator, the proved-least hauling, and the one preview number.
 *
 * ⛔ THE GENERATOR IS THE CANDIDATE SCREEN'S, VERBATIM (Internal_Ops/screen.js, run 2 = PREREG_2's run 3): same
 *    RNG, same draws in the same order, so every number in the screen describes these parishes. The ONLY
 *    addition is `kind[]` (river / bridge / wall / pond, for the picture), which consumes no random draw.
 *    Internal_Ops/verify_parish.js REQUIRES all 200 screened parishes to reproduce the screen's rows exactly.
 * ⛔ PREREG_2 binds the design: the game shows ONE number — the parish's total hauling if a mill were raised on
 *    this cell, given the mills already raised — and never a preview of a multi-mill set, never reversible stakes.
 *
 * A parish: 20x15 cells; blocked cells (a river with 1-2 bridges, wall runs, ponds); 12-18 farms in 3 clusters
 * plus strays, each farm 1-4 cottages. Every cottage carts its grain to the NEAREST mill, walking 4-way around
 * anything blocked. Hauling = sum over farms of cottages x walking steps. Three mills; the least hauling any
 * three mills could give (exhaustive over every passable cell) is the par.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.PARISH = api;
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const W = 20, H = 15, K = 3, N = W * H;
  const GROUND = 0, RIVER = 1, BRIDGE = 2, WALL = 3, POND = 4;

  function rng(seed) { let a = (seed + 0x9e3779b9) >>> 0; return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

  function generate(seed) {
    const r = rng(seed * 2654435761 % 4294967291 + 11), ri = (lo, hi) => lo + Math.floor(r() * (hi - lo + 1));
    for (let attempt = 0; attempt < 200; attempt++) {
      const block = new Uint8Array(N), kind = new Uint8Array(N);
      if (r() < 0.75) { let x = ri(6, W - 7); const path = []; for (let y = 0; y < H; y++) { path.push(y * W + x); const d = r(); if (d < 0.3 && x > 3) { x--; path.push(y * W + x); } else if (d > 0.7 && x < W - 4) { x++; path.push(y * W + x); } }
        for (const c of path) { block[c] = 1; kind[c] = RIVER; } for (let b = ri(1, 2); b-- > 0;) { const c = path[ri(2, path.length - 3)]; block[c] = 0; kind[c] = BRIDGE; } }
      for (let w = ri(2, 4); w-- > 0;) { const horiz = r() < 0.5; let x = ri(1, W - 2), y = ri(1, H - 2); for (let k = ri(3, 7); k-- > 0;) { if (x >= W || y >= H) break; if (r() > 0.1) { block[y * W + x] = 1; kind[y * W + x] = WALL; } if (horiz) x++; else y++; } }
      for (let p = ri(0, 2); p-- > 0;) { const cx = ri(2, W - 3), cy = ri(2, H - 3); for (let y = cy - 1; y <= cy + 1; y++) for (let x = cx - 1; x <= cx + 1; x++) if (r() < 0.8) { block[y * W + x] = 1; kind[y * W + x] = POND; } }
      const hamlets = K, homes = [], taken = new Set();
      const centres = []; for (let h = 0; h < hamlets; h++) centres.push([ri(1, W - 2), ri(1, H - 2)]);
      const target = ri(12, 18); let guard = 0;
      while (homes.length < target && guard++ < 4000) {
        const outlier = r() < 0.15; const [cx, cy] = outlier ? [ri(0, W - 1), ri(0, H - 1)] : centres[ri(0, hamlets - 1)];
        const x = Math.max(0, Math.min(W - 1, cx + (outlier ? 0 : ri(-2, 2)))), y = Math.max(0, Math.min(H - 1, cy + (outlier ? 0 : ri(-2, 2)))), c = y * W + x;
        if (!block[c] && !taken.has(c)) { taken.add(c); homes.push({ c, w: ri(1, 4) }); } }
      const dist = homes.map((h) => { const d = new Int16Array(N).fill(-1); d[h.c] = 0; const q = [h.c]; for (let i = 0; i < q.length; i++) { const u = q[i], x = u % W, y = (u / W) | 0; for (const v of [x > 0 ? u - 1 : -1, x < W - 1 ? u + 1 : -1, y > 0 ? u - W : -1, y < H - 1 ? u + W : -1]) if (v >= 0 && !block[v] && d[v] < 0) { d[v] = d[u] + 1; q.push(v); } } return d; });
      if (homes.some((h, i) => homes.some((g) => dist[i][g.c] < 0))) continue;
      const cand = []; for (let c = 0; c < N; c++) if (!block[c] && dist[0][c] >= 0) cand.push(c);
      // a stray passable cell NOT reachable from the farms (walled off) stays passable ground in the picture but can
      // never hold a mill: `reach` is what the millwright may walk on.
      const reach = new Uint8Array(N); for (const c of cand) reach[c] = 1;
      const farmAt = new Int16Array(N).fill(-1); homes.forEach((h, i) => { farmAt[h.c] = i; });
      return { seed, block, kind, homes, dist, cand, reach, farmAt };
    }
    throw new Error('no parish for seed ' + seed);
  }

  /** Total hauling with the given mills (each farm to its nearest). Infinity with no mills. */
  function cost(P, wells) { let s = 0; P.homes.forEach((h, i) => { let m = Infinity; for (const w of wells) m = Math.min(m, P.dist[i][w]); s += h.w * m; }); return s; }

  /** THE ONE PREVIEW NUMBER (PREREG_2): the hauling if a mill were raised on `cell`, given the mills already raised. */
  function preview(P, raised, cell) { return cost(P, raised.concat([cell])); }

  /** The proved-least hauling over EVERY choice of three passable cells — the screen's optimum(), verbatim. */
  const solveCache = new Map();
  function solve(P) {
    if (solveCache.has(P.seed)) return solveCache.get(P.seed);
    const C = P.cand, H2 = P.homes.length, best = { c: Infinity, set: null };
    const d = P.homes.map((h, i) => C.map((c) => P.dist[i][c] * h.w));
    const m2 = new Float64Array(H2);
    for (let a = 0; a < C.length; a++) for (let b = a + 1; b < C.length; b++) {
      for (let i = 0; i < H2; i++) m2[i] = Math.min(d[i][a], d[i][b]);
      for (let c = b + 1; c < C.length; c++) { let s = 0; for (let i = 0; i < H2 && s < best.c; i++) s += Math.min(m2[i], d[i][c]); if (s < best.c) { best.c = s; best.set = [C[a], C[b], C[c]]; } }
    }
    const out = { cost: best.c, mills: best.set };
    solveCache.set(P.seed, out);
    return out;
  }

  /** Which mill (index into `wells`) each farm carts to: the nearest; a tie goes to the mill raised first. */
  function assign(P, wells) { return P.homes.map((h, i) => { let bi = -1, bd = Infinity; wells.forEach((w, j) => { if (P.dist[i][w] < bd) { bd = P.dist[i][w]; bi = j; } }); return bi; }); }

  /** The cart track from farm i to `cell`: walked back from the mill down the farm's own distance field. */
  function track(P, i, cell) {
    const d = P.dist[i]; if (d[cell] < 0) return [];
    const out = [cell]; let u = cell, guard = 0;
    while (d[u] > 0 && guard++ < N) {
      const x = u % W, y = (u / W) | 0;
      const ns = [x > 0 ? u - 1 : -1, x < W - 1 ? u + 1 : -1, y > 0 ? u - W : -1, y < H - 1 ? u + W : -1];
      let nx = -1; for (const v of ns) if (v >= 0 && d[v] === d[u] - 1) { nx = v; break; }
      if (nx < 0) break; u = nx; out.push(u);
    }
    return out.reverse();
  }

  /** Where the millwright stands at the start: the reachable cell nearest the middle of the parish (not a farm). */
  function startCell(P) {
    let best = -1, bd = Infinity;
    for (const c of P.cand) { if (P.farmAt[c] >= 0) continue; const x = c % W, y = (c / W) | 0, dd = (x - 9.5) ** 2 + (y - 7) ** 2; if (dd < bd) { bd = dd; best = c; } }
    return best >= 0 ? best : P.cand[0];
  }

  return { W, H, K, N, GROUND, RIVER, BRIDGE, WALL, POND, generate, cost, preview, solve, assign, track, startCell };
}));
