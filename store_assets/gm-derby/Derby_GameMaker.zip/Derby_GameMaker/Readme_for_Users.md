# Derby - A Snail-Racing Betting Minigame, for GameMaker

**GameMaker 2024.14 or newer · pure GML · no sprites, no shaders, no extensions**
Core Systems Asset Factory · <https://csaf.itch.io>

A race meeting your players can bet on, for a fairground, a tavern garden or a noble's lawn. The player reads
a race card (every runner's form, the going it likes, its silks and its price), backs a runner to Win or Place,
and watches the race run on a garden course drawn by this package: moss, slate, sand, puddles, leaf litter and
gravel, each suiting some runners more than others. Close finishes go to the judge's photograph. The winners'
enclosure hands out rosettes, and the purse is paid in whatever your game calls gold.

Everything is GENERATED from a seed: the stable of runners (names, shells, body colours, shell patterns,
silks, saddle cloths), every race's field, course, going and prices. **Nothing here is an image file.**

---

## Quick start

1. **Tools > Import Local Package**, choose `Derby.yymps`, import everything.
2. Open `rm_dby_demo` and press Play. A three-race meeting opens with 500 gold.
3. In your own game, one meeting per visit to the course:

```gml
// when the player walks up to the course
my_meeting = dby_meeting_create({ seed: 2026, races: 3, purse: my_gold, record: my_form });

// Step
if (is_struct(my_meeting) && dby_meeting_step(my_meeting) == "done") {
    my_gold = my_meeting.purse;        // the purse comes back when they leave
    my_form = my_meeting.record;       // every runner's form, for the next visit (save it with your game)
    dby_meeting_free(my_meeting);
    my_meeting = undefined;
}

// Draw GUI
if (is_struct(my_meeting)) dby_meeting_draw(my_meeting, 0, 0, display_get_gui_width(), display_get_gui_height());

// Clean Up
if (is_struct(my_meeting)) dby_meeting_free(my_meeting);
```

The meeting draws its own 1280 x 720 frame and fits it, uniformly scaled and centred, into the rectangle you
give `dby_meeting_draw`. Mouse clicks are mapped back through the same fit.

---

## What the player sees

| Screen | What is on it |
| --- | --- |
| The race card | The meeting and race, the going, a row per runner (number cloth, the runner, its name, the going it likes, its silks, its last five placings with wins in red, its Win and Place prices chalked on a slate), a map of the course, the bet slip and the controls |
| The bet slip | The chosen runner, Win and Place, the stake stepper, what the bet returns, the purse, **Off they go!** and **Leave the course** |
| The race | The course scrolling under the field, the lane board, a progress strip with every runner's silks, and a commentary line: new leaders, a burst of speed, a stop for a nibble, the leaders reaching a new surface, first past the post |
| The photograph | When the first two finish within a head, the judge's print of the line, in sepia, with up to three runners |
| The winners' enclosure | Rosettes for the first three, starting prices and margins ("won by three-quarters of a shell"), and how the bet went |

Controls: **up / down** choose a runner, **left / right** change the stake, **Shift** (or Q / W) switches Win
and Place, **Enter** (or Space, Z) starts the race and, held, runs it at triple speed, **Escape** (or X,
Backspace, the right mouse button) leaves. Everything can also be clicked. A connected gamepad works too:
d-pad or left stick, A, B and the shoulder buttons.

---

## Options

Every option is optional. `dby_meeting_create(opts)`:

| Option | Meaning |
| --- | --- |
| `seed` | The meeting's stable and races (default 2026). The same seed is the same stable of twelve runners. |
| `races` | 1 to 5 races per visit (default 3). With more than one, the last is always a Derby. |
| `field_size` | 5 to 8 runners a race (default: each card decides, 6 to 8). |
| `course` | `"kitchen"`, `"rockery"`, `"greenhouse"`, `"orchard"` or `"mossbank"` (default: each card decides). |
| `going` | `"dewy"`, `"damp"` or `"dry"` (default: each card decides). |
| `purse` | The gold the player brings (default 500). Stakes come out of it, winnings go into it. |
| `min_stake`, `max_stake`, `stake_step` | Default 10, 100 and 10. A stake never passes the purse; below the smallest it is "no bet". |
| `payback` | 0.5 to 1.0 (default 0.85): what a bet returns on average over many races. |
| `title` | The meeting's name on the card (default: named after the course, "Rockery Races"). |
| `record` | A previous meeting's `record`, so the runners' form carries on between visits. |
| `fresh` | `true` (default) mixes `visit` into every race, so reloading a save cannot replay a race whose winner the player already knows. |
| `visit` | What `fresh` mixes in (default: the clock). Pass the same number to get the same races (the demo shots do). |
| `book_ms` | Milliseconds a frame spent pricing a card (default 10). |
| `work_ms` | Milliseconds a frame spent drawing ahead (default 6). |
| `on_event` | `function(name, meeting)`, called on `"cursor"`, `"stake"`, `"off"`, `"lead"`, `"finish"`, `"photo"`, `"win"`, `"lose"`, `"leave"` and `"done"`. Derby ships no sounds: play yours here. |
| `prompt_next`, `prompt_leave`, `currency`, `currency_short`, `hints` | The few words the screens print, for your own wording or language. `hints` is an array of four lines. |

While a meeting runs you can read `my_meeting.mode` (`"card"`, `"race"`, `"photo"`, `"result"`, `"leaving"`,
`"done"`), `my_meeting.purse`, `my_meeting.net` (winnings this visit), `my_meeting.race_idx` and
`my_meeting.record`.

`dby_meeting_step(meeting, input)` reads the keyboard, mouse and gamepad itself; pass your own input struct
instead to drive it from your game's input system. `dby_meeting_input()` returns the struct it would have read:
`up`, `down`, `left`, `right`, `ok_held` and `click_held` are HELD this frame; `toggle`, `ok`, `cancel` and
`click` are PRESSED this frame; `mx` and `my` are the pointer in the coordinates you draw in (GUI coordinates
by default).

---

## The prices are measured

A card's prices are not guessed. Every runner is raced alone 400 times over that card's course and going by
the same race model the player watches, the crossing times are combined exactly to give each runner's chance of
winning and of placing, and every bet is priced on the upper bound of that chance and rounded DOWN a ladder of
traditional prices (5/2, 7/4, Evens...). Checked against 20,000 simulated races on 20 cards (249 bets), no
bet's true return passed 0.857 at the default payback of 0.85. The form figures are real results from the same
model, so reading the card pays.

The race on screen IS the race the book priced: `dby_run_race` on the card's own seed finishes in exactly the
order the player watched.

---

## Frame cost

Measured on the GameMaker VM (runtime 2024.14.4.268, Windows):

- Pricing one card is about 3 seconds of work. The meeting does it `book_ms` (10 ms) a frame, so the first card
  is chalked a few seconds after the meeting opens (the slip counts the percentage up), and every later card is
  priced while the race before it runs.
- The course, the runners and the papers are baked while the player reads the card, one job a frame: the
  largest single job measured 83 ms. The photograph and the result board are drawn while the field crawls home
  after the finish, in jobs of 60 ms or less.
- Call `dby_meeting_prepare(my_meeting)` behind your own loading screen if you would rather have none of that
  spread over frames: it finishes every bake and prices the card at once.

---

## Building blocks

The meeting is built from these, and you can build your own screens from them.

| Function | Returns |
| --- | --- |
| `dby_meeting_create([opts])` | a meeting |
| `dby_meeting_step(meeting, [input])` | the mode after this frame |
| `dby_meeting_draw(meeting, x, y, w, h)` | draws the meeting fitted into the rectangle |
| `dby_meeting_input()` | the input struct `dby_meeting_step` reads by default |
| `dby_meeting_prepare(meeting)` | `true` once everything is baked and priced |
| `dby_meeting_frame(meeting)` | the 1280 x 720 surface the last draw composed, for screenshots (-1 before) |
| `dby_meeting_free(meeting)` | frees its surfaces and sprites |
| `dby_make_stable(seed, [size])` | an array of 5 to 16 runners (default 12), each with a name, a `look` and four hidden ratings |
| `dby_make_course(seed, [theme])` | a course: a theme and 4 to 6 sections of surface |
| `dby_open_book(stable, [opts])` | a card for one race, unpriced. `opts`: `seed`, `race_no`, `field_size`, `course`, `going`, `payback`, `kind` |
| `dby_work_book(card, [ms])` | prices a card for up to `ms` milliseconds; `true` once priced |
| `dby_make_card(stable, [opts])` | a card, fully priced in one call |
| `dby_make_race(field, course, going)` | a race for a card's field (`undefined` for anything else) |
| `dby_reset_race(race, seed)` / `dby_tick(race)` / `dby_run_race(race, seed)` | run a race a tick at a time, or to the finish |
| `dby_margin_at(race, place)` | the margin behind a placing, in shells |
| `dby_margin_words(shells)` | "a whisker", "a head", "3.5 shells"... |
| `dby_price_text(rung)` / `dby_dec(rung)` | a price as "5/2" or "Evens", and its decimal return |
| `dby_settle(card, race, bet)` | what a bet `{runner, type, stake}` returns once the race is run |
| `dby_place_terms(field_size)` | how many places a Place bet pays |
| `dby_initial_form(stable, seed)` | the form a stable brings: six earlier races, and each runner's placings in the ones it ran |
| `dby_art_snail(look, num, x, y, scale)` | draws a runner: body, stalks, numbered saddle cloth and shell |
| `dby_art_shell(look, x, y, scale)` / `dby_art_cloth(look, num, x, y, w, h, [rot])` | its shell, or its cloth |
| `dby_art_silk(i)` / `dby_art_silk_name(i)` | one of the twelve silk colours, and its name |
| `dby_course_texture(name, [k], [seed])` | draws a seamless 250 x 250 tile of a surface's marks (`DBY_TEX`) |
| `dby_course_surface(name, x, y, w, h, rng, [k])` | fills a rectangle with a surface, mark by mark; `rng` from `dby_rng(seed)` |
| `dby_course_strip_part(card, geo, x0, x1, [textures], [scenery])` | draws part of a card's course: scenery, lanes, posts, lettuces |
| `dby_course_scenery_layout(theme, x0, w, top, h, rng)` / `dby_course_scenery_draw(layout, x0, x1)` | the scenery band, laid out once and drawn a window at a time |
| `dby_course_theme(theme)` / `dby_course_lettuce(x, y, scale)` | a course's colours, and the prize |

A course strip's `geo` is `{ w, h, top, lane_h, start_x, px }`: the strip's width and height, the scenery
band's height above the lanes, one lane's height, where the start line sits, and pixels per race unit (a race
is `DBY_LEN`, 1000 units, long). The meeting uses `{ w: 3900, h: 572, top: 70, lane_h: 60, start_x: 200, px: 3.4 }`
for eight runners. `textures` is a struct of surface name to a sprite you made from `dby_course_texture`
(drawn at supersample `k`, the sprite `DBY_TEX * k` square); without it every section is drawn mark by mark.

A bad argument is a refusal (`undefined`, `false`, `0` or nothing drawn), never a crash inside your Draw event.

---

## Fonts and licences

The card, the slip, the commentary, the photograph and the result board are set in IM Fell DW Pica (SIL Open
Font License 1.1), bundled as three font resources under the name "Derby Plate Serif", and Open Sans (Apache
2.0). Both licence texts and the notices ship in `Derby/fonts/`. See `LICENSE.txt` for the package licence.

This package was written with AI assistance, disclosed on every store listing.
