/// @description Derby demo: a three-race meeting you can bet on, and the headless -selftest / -sheet entries.
/// ⛔ The crash handler is installed FIRST, and every variable a later event reads is declared ABOVE the early exits:
/// Clean Up always runs, even when Create leaves early.
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("dby_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.dby_stage) + ": " + string(_ex.message) + " | " + string(_ex.stacktrace));
    file_text_close(_f);
    game_end();
});
global.dby_stage = 0;
meeting = undefined;
sheet_pending = false;
gif_pending = false;
gold = 500;
record = undefined;
visits = 0;
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";
if (string_pos("-selftest", _args) > 0) { global.dby_stage = 1; dby_selftest_write(dby_selftest_run()); game_end(); exit; }
if (string_pos("-sheet", _args) > 0) { global.dby_stage = 2; sheet_pending = true; exit; }
if (string_pos("-gif", _args) > 0) { global.dby_stage = 3; gif_pending = true; exit; }

// A meeting is one visit to the course: it takes the player's gold in and gives the purse back when they leave.
// `record` carries every runner's form from one visit to the next (save it with your game to keep it across sessions).
meeting = dby_meeting_create({ seed: 2026, races: 3, purse: gold });
