/// @description Run the meeting; when the player leaves, take the purse back and offer another visit.
if (sheet_pending) { sheet_pending = false; dby_bake_sheet(); dby_bake_meeting(); game_end(); exit; }
if (gif_pending) { gif_pending = false; dby_bake_gif(); game_end(); exit; }
if (is_struct(meeting)) {
    if (dby_meeting_step(meeting) == "done") {
        gold = meeting.purse;
        record = meeting.record;
        visits += 1;
        dby_meeting_free(meeting);
        meeting = undefined;
    }
} else if (keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space) || mouse_check_button_pressed(mb_left)) {
    meeting = dby_meeting_create({ seed: 2026, races: 3, purse: gold, record: record });
}
