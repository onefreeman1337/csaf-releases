/// @description Free the meeting's surfaces and sprites.
if (is_struct(meeting)) dby_meeting_free(meeting);
meeting = undefined;
