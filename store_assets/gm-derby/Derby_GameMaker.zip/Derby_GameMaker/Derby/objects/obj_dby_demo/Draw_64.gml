/// @description The meeting fills the GUI layer; between visits, the purse the player walked away with.
var _w = display_get_gui_width(), _h = display_get_gui_height();
if (is_struct(meeting)) { dby_meeting_draw(meeting, 0, 0, _w, _h); exit; }
draw_clear(make_colour_rgb(23, 13, 7));
dby_k_text(_w / 2, _h / 2 - 30, "You leave the course with " + string(gold) + " gold.", 40, make_colour_rgb(246, 227, 180), fa_center, fa_middle, fnt_derby);
dby_k_text(_w / 2, _h / 2 + 30, "Enter or click for another visit (the runners keep their form)", 20, make_colour_rgb(201, 168, 120), fa_center, fa_middle, fnt_derby);
