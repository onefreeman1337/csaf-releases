/// dby_bake.gml - the store-asset bake (`Derby.exe -sheet`): sheets rendered by the product's own drawing code, written
/// as dby_render_*.png beside a dby_sheet.json receipt. Not needed at runtime: delete it with the -sheet branch of the
/// demo object's Create and Step events.
///
/// Derby - A Snail-Racing Betting Minigame, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function dby_bake__ground(surface)
/// @description The first three raw bytes of a surface's first pixel, in whatever channel order the runtime uses. Internal.
/// ⛔ The first sheet's counter assumed BGRA and its own blank control read 806,400 of 806,400 pixels as ink: the bytes
/// of #efe6d2 did not sit where BGRA puts them. The ground is now read off the blank surface and compared byte for byte,
/// and the receipt records the bytes, so the order is a measurement rather than an assumption.
/// ⛔ And the buffer must hold the WHOLE surface: buffer_get_surface into a 4-byte buffer writes nothing, and the second
/// sheet's receipt read ground_bytes [0,0,0,0] (MEASURED 2026-09-27).
function dby_bake__ground(_surf) {
    var _buf = buffer_create(surface_get_width(_surf) * surface_get_height(_surf) * 4, buffer_fixed, 1);
    buffer_get_surface(_buf, _surf, 0);
    var _g = [buffer_peek(_buf, 0, buffer_u8), buffer_peek(_buf, 1, buffer_u8), buffer_peek(_buf, 2, buffer_u8), buffer_peek(_buf, 3, buffer_u8)];
    buffer_delete(_buf);
    return _g;
}

/// @function dby_bake__ink(surface, w, h, ground)
/// @description Pixels on a surface further than 24 (summed over three raw bytes) from the ground's raw bytes. Internal.
function dby_bake__ink(_surf, _w, _h, _gb) {
    var _buf = buffer_create(_w * _h * 4, buffer_fixed, 1), _ink = 0;
    buffer_get_surface(_buf, _surf, 0);
    for (var _p = 0; _p < _w * _h; _p++) {
        var _o = _p * 4;
        if (abs(buffer_peek(_buf, _o, buffer_u8) - _gb[0]) + abs(buffer_peek(_buf, _o + 1, buffer_u8) - _gb[1]) + abs(buffer_peek(_buf, _o + 2, buffer_u8) - _gb[2]) > 24) _ink++;
    }
    buffer_delete(_buf);
    return _ink;
}

/// @function dby_bake_surfaces()
/// @description The six race surfaces as labelled swatches, drawn at 2x and filtered down: dby_render_surfaces.png.
/// Returns the number of swatches drawn (the picture is judged by LOOKING at it).
function dby_bake_surfaces() {
    var _names = ["moss", "slate", "sand", "puddle", "leaf", "gravel"], _cols = 3, _sw = 380, _sh = 200, _gap = 20, _lab = 30, _ss = 2;
    var _W = _cols * _sw + (_cols + 1) * _gap, _H = 2 * (_sh + _lab) + 3 * _gap;
    var _big = surface_create(_W * _ss, _H * _ss), _small = surface_create(_W, _H), _paper = dby_art__hex("#efe6d2");
    surface_set_target(_big);
    draw_clear_alpha(_paper, 1);
    for (var _i = 0; _i < 6; _i++) {
        var _x = _gap + (_i mod _cols) * (_sw + _gap), _y = _gap + (_i div _cols) * (_sh + _lab + _gap);
        dby_course_surface(_names[_i], _x * _ss, _y * _ss, _sw * _ss, _sh * _ss, dby_rng($C0 + _i), _ss);
        dby_k_text((_x + _sw / 2) * _ss, (_y + _sh + _lab / 2 + 2) * _ss, _names[_i], 14 * _ss, dby_art__hex("#3a2414"), fa_center, fa_middle, fnt_derby_ui);
    }
    surface_reset_target();
    surface_set_target(_small);
    draw_clear_alpha(_paper, 1);
    gpu_set_tex_filter(true);
    draw_surface_ext(_big, 0, 0, 1 / _ss, 1 / _ss, 0, c_white, 1);
    gpu_set_tex_filter(false);
    surface_reset_target();
    surface_save(_small, "dby_render_surfaces.png");
    surface_free(_big); surface_free(_small);
    return 6;
}

/// @function dby_bake__textures(k)
/// @description All six surfaces' seamless textures as sprites (what the race view tiles from). Internal to the bake.
function dby_bake__textures(_k) {
    var _names = dby_surfaces(), _out = {};
    for (var _i = 0; _i < array_length(_names); _i++) {
        var _s2 = surface_create(DBY_TEX * _k, DBY_TEX * _k);
        surface_set_target(_s2); draw_clear_alpha(c_black, 0);
        dby_course_texture(_names[_i], _k, 2026);
        surface_reset_target();
        _out[$ _names[_i]] = sprite_create_from_surface(_s2, 0, 0, DBY_TEX * _k, DBY_TEX * _k, false, false, 0, 0);
        surface_free(_s2);
    }
    return _out;
}

/// @function dby_bake_courses()
/// @description One course strip per theme with a real race 200 ticks in (runners where the model has them), drawn at
/// 2x under a world-matrix scale FROM THE SAME TEXTURES THE RACE VIEW TILES, and filtered down: dby_render_courses.png.
/// Returns the number of strips.
function dby_bake_courses() {
    var _themes = ["kitchen", "rockery", "greenhouse", "orchard", "mossbank"], _n = 6, _lh = 26, _top = 64, _W = 1200, _gap = 10;
    var _sh = _top + _n * _lh + 10, _H = array_length(_themes) * (_sh + _gap) + _gap, _ss = 2;
    var _tex = dby_bake__textures(_ss);
    var _big = surface_create(_W * _ss, _H * _ss), _small = surface_create(_W, _H), _paper = dby_art__hex("#efe6d2");
    var _stable = dby_make_stable(2026, 12), _m0 = matrix_get(matrix_world);
    surface_set_target(_big);
    draw_clear_alpha(_paper, 1);
    for (var _t = 0; _t < array_length(_themes); _t++) {
        var _card = dby_open_book(_stable, { seed: 77 + _t, race_no: _t, field_size: _n, course: _themes[_t] });
        var _geo = { w: _W, h: _sh, top: _top, lane_h: _lh, start_x: 60, px: (_W - 60 - 110) / DBY_LEN };
        matrix_set(matrix_world, matrix_build(0, (_gap + _t * (_sh + _gap)) * _ss, 0, 0, 0, 0, _ss, _ss, 1));
        dby_course_strip_part(_card, _geo, 0, _W, _tex);
        var _race = dby_reset_race(dby_make_race(_card.field, _card.course, _card.going), _card.race_seed);
        for (var _k = 0; _k < 200; _k++) dby_tick(_race);
        for (var _i = 0; _i < _race.n; _i++) dby_art_snail(_card.field[_i].look, _i + 1, _geo.start_x + _race.runners[_i].x * _geo.px, _top + (_i + 0.62) * _lh, _lh / 62);
    }
    matrix_set(matrix_world, _m0);
    surface_reset_target();
    surface_set_target(_small);
    draw_clear_alpha(_paper, 1);
    gpu_set_tex_filter(true);
    draw_surface_ext(_big, 0, 0, 1 / _ss, 1 / _ss, 0, c_white, 1);
    gpu_set_tex_filter(false);
    surface_reset_target();
    surface_save(_small, "dby_render_courses.png");
    surface_free(_big); surface_free(_small);
    var _tn = variable_struct_get_names(_tex);
    for (var _d = 0; _d < array_length(_tn); _d++) sprite_delete(_tex[$ _tn[_d]]);
    return array_length(_themes);
}

/// @function dby_bake__press(meeting, key)
/// @description One scripted key press: a frame with it held, then a frame with it released. Internal to the bake.
function dby_bake__press(_m, _key) { var _in = {}; _in[$ _key] = true; dby_meeting_step(_m, _in); dby_meeting_step(_m, {}); }

/// @function dby_bake__save(meeting, file)
/// @description Draw the meeting's frame and save it. Internal to the bake.
function dby_bake__save(_m, _file) {
    var _cap = surface_create(DBY_MT_W, DBY_MT_H);
    surface_set_target(_cap); draw_clear_alpha(c_black, 1);
    dby_meeting_draw(_m, 0, 0, DBY_MT_W, DBY_MT_H);
    surface_reset_target();
    surface_save(_cap, _file);
    surface_free(_cap);
}

/// @function dby_bake__photo_visit(seed, field, [from])
/// @description The first `visit` (counting from `from`) whose FIRST race is a photo finish, the way dby_meeting_create
/// would draw it: [visit, the winner's index on the card, the race]. Internal to the bake.
function dby_bake__photo_visit(_seed, _field, _from = 1) {
    var _stable = dby_make_stable(_seed, 12), _kinds = dby__race_kinds();
    for (var _v = _from; _v < _from + 600; _v++) {
        var _c = dby_open_book(_stable, { seed: dby_mix(_seed, _v), race_no: 0, field_size: _field, payback: 0.85, kind: _kinds[0] });
        var _r = dby_run_race(dby_make_race(_c.field, _c.course, _c.going), _c.race_seed);
        if (dby_margin_at(_r, 0) < 0.25 && dby_margin_at(_r, 1) < 0.25) return [_v, _r.order[0], _r];
    }
    return [_from, 0, undefined];
}

/// @function dby_bake__meeting_to_card(visit, winner)
/// @description A meeting on the photo-finish visit, fully prepared, with the eventual winner chosen and 30 staked.
function dby_bake__meeting_to_card(_v, _w) {
    var _m = dby_meeting_create({ seed: 2026, visit: _v, races: 3, field_size: 8, purse: 500 });
    dby_meeting_prepare(_m);
    for (var _i = 0; _i < _w; _i++) dby_bake__press(_m, "down");
    dby_bake__press(_m, "right"); dby_bake__press(_m, "right");
    dby_meeting_prepare(_m);
    return _m;
}

/// @function dby_bake_meeting()
/// @description The store frames, rendered by driving a real meeting with scripted input: the card, the race, the
/// post, the photograph and the winners' enclosure (dby_render_*.png) and a receipt, dby_meeting_bake.json.
function dby_bake_meeting() {
    var _rec = { visit: 0, winner: -1, modes: [], shots: [], prepare_ms: 0, purse_before: 0, purse_after: 0, photo_runners: 0 };
    var _pv = dby_bake__photo_visit(2026, 8, 1);
    _rec.visit = _pv[0]; _rec.winner = _pv[1];
    var _t0 = get_timer();
    var _m = dby_bake__meeting_to_card(_pv[0], _pv[1]);
    _rec.prepare_ms = (get_timer() - _t0) / 1000;
    _rec.purse_before = _m.purse;
    dby_bake__save(_m, "dby_render_card.png"); array_push(_rec.shots, "card");
    dby_bake__press(_m, "ok");
    array_push(_rec.modes, _m.mode);
    var _mid = false, _post = false, _guard = 0;
    while (_m.mode == "race" && _guard < 4000) {
        dby_meeting_step(_m, {});
        _guard++;
        if (_m.mode != "race") break;
        if (!_mid && _m.race.t >= 170) { dby_bake__save(_m, "dby_render_race.png"); array_push(_rec.shots, "race"); _mid = true; }
        var _lx = _m.race.runners[max(0, _m.race.leader)].x;
        if (!_post && _m.race.n_fin == 0 && _lx >= DBY_LEN - 24) { dby_bake__save(_m, "dby_render_post.png"); array_push(_rec.shots, "post"); _post = true; }
    }
    array_push(_rec.modes, _m.mode);
    if (_m.mode == "photo") {
        _rec.photo_runners = array_length(_m.photo_shown);
        for (var _k = 0; _k < 8; _k++) dby_meeting_step(_m, {});
        dby_bake__save(_m, "dby_render_photo.png"); array_push(_rec.shots, "photo");
        _guard = 0;
        while (_m.mode == "photo" && _guard < 400) { dby_meeting_step(_m, {}); _guard++; }
    }
    array_push(_rec.modes, _m.mode);
    if (_m.mode == "result") {
        for (var _q = 0; _q < 4; _q++) dby_meeting_step(_m, {});
        dby_bake__save(_m, "dby_render_result.png"); array_push(_rec.shots, "result");
    }
    _rec.purse_after = _m.purse;
    _rec.net = _m.net;
    _rec.stats = _m.stats;
    var _f = file_text_open_write("dby_meeting_bake.json");
    file_text_write_string(_f, json_stringify(_rec));
    file_text_close(_f);
    dby_meeting_free(_m);
}

/// @function dby_bake__pad(n)
/// @description n as four digits, padded by arithmetic (string_replace on a formatted string once named frames
/// "frame_0 0.png" and ffmpeg found no sequence - wing CLAUDE.md section 3). Internal to the bake.
function dby_bake__pad(_n) { var _s = string(floor(_n)); while (string_length(_s) < 4) _s = "0" + _s; return _s; }

/// @function dby_bake_gif()
/// @description The listing GIF's frames (dby_gif_NNNN.png): the card, the race at triple speed (OK held, as a player
/// can), the photograph and the result - one real meeting, scripted input only.
function dby_bake_gif() {
    var _pv = dby_bake__photo_visit(2026, 8, 1), _m = dby_bake__meeting_to_card(_pv[0], _pv[1]), _n = 0, _k;
    for (_k = 0; _k < 18; _k++) { dby_bake__save(_m, "dby_gif_" + dby_bake__pad(_n) + ".png"); _n++; }
    dby_bake__press(_m, "ok");
    var _fr = 0, _guard = 0;
    while (_m.mode == "race" && _guard < 3000) {
        dby_meeting_step(_m, { ok_held: true });
        _guard++; _fr++;
        if ((_fr mod 2) == 0) { dby_bake__save(_m, "dby_gif_" + dby_bake__pad(_n) + ".png"); _n++; }
    }
    if (_m.mode == "photo") {
        for (_k = 0; _k < 60; _k++) { dby_meeting_step(_m, {}); if ((_k mod 2) == 0) { dby_bake__save(_m, "dby_gif_" + dby_bake__pad(_n) + ".png"); _n++; } }
        _guard = 0;
        while (_m.mode == "photo" && _guard < 400) { dby_meeting_step(_m, {}); _guard++; }
    }
    if (_m.mode == "result") for (_k = 0; _k < 50; _k++) { dby_meeting_step(_m, {}); if ((_k mod 2) == 0) { dby_bake__save(_m, "dby_gif_" + dby_bake__pad(_n) + ".png"); _n++; } }
    var _f = file_text_open_write("dby_gif.json");
    file_text_write_string(_f, json_stringify({ frames: _n, visit: _pv[0] }));
    file_text_close(_f);
    dby_meeting_free(_m);
}

/// @function dby_bake_timing()
/// @description What the drawing costs on this runtime, so the race view's baking plan is a measurement: one full course
/// strip at race-view size drawn into one 2x tile, one runner at race scale, one card-row runner, one paper. Returns a
/// struct of milliseconds.
function dby_bake_timing() {
    var _out = {}, _stable = dby_make_stable(2026, 12), _t0, _m0 = matrix_get(matrix_world);
    var _surf = surface_create(2048, 1144);
    var _card = dby_open_book(_stable, { seed: 91, race_no: 1, field_size: 8, course: "rockery" });
    var _geo = { w: 3900, h: 572, top: 70, lane_h: 60, start_x: 200, px: 3.4 };
    surface_set_target(_surf);
    draw_clear_alpha(c_black, 0);
    matrix_set(matrix_world, matrix_build(0, 0, 0, 0, 0, 0, 2, 2, 1));
    _t0 = get_timer();
    dby_course_strip(_card, _geo);
    _out.strip_full_ms = (get_timer() - _t0) / 1000;
    matrix_set(matrix_world, _m0);
    _t0 = get_timer();
    for (var _i = 0; _i < 8; _i++) dby_art_snail(_card.field[_i].look, _i + 1, 200 + _i * 200, 200, 0.88 * 2);
    _out.snail_race_ms = (get_timer() - _t0) / 1000 / 8;
    _t0 = get_timer();
    for (var _j = 0; _j < 8; _j++) dby_art_snail(_card.field[_j].look, undefined, 200 + _j * 200, 600, 0.61 * 2);
    _out.snail_card_ms = (get_timer() - _t0) / 1000 / 8;
    _t0 = get_timer();
    dby_art_shell(_card.field[0].look, 300, 900, 0.88 * 2);
    _out.shell_ms = (get_timer() - _t0) / 1000;
    _t0 = get_timer();
    var _r = dby_rng(5);
    dby_course_surface("gravel", 0, 0, 2048, 960, _r, 2);
    _out.gravel_1024x480_ms = (get_timer() - _t0) / 1000;
    _t0 = get_timer();
    dby_course_surface("moss", 0, 0, 2048, 960, _r, 2);
    _out.moss_1024x480_ms = (get_timer() - _t0) / 1000;
    _t0 = get_timer();
    dby_course_scenery("rockery", 0, 3900, 0, 70, dby_rng(9));
    _out.scenery_rockery_ms = (get_timer() - _t0) / 1000;
    surface_reset_target();
    _t0 = get_timer();
    var _spr = sprite_create_from_surface(_surf, 0, 0, 1024, 572, false, false, 0, 0);
    _out.sprite_from_surface_ms = (get_timer() - _t0) / 1000;
    surface_free(_surf);
    sprite_delete(_spr);
    return _out;
}

/// @function dby_bake_sheet()
/// @description 48 runners from three stables, drawn at 2x and filtered down, labelled with their names; writes
/// dby_render_runners.png and dby_sheet.json {runners, distinct_looks, ink, ink_blank}.
function dby_bake_sheet() {
    var _cols = 8, _rows = 6, _cw = 150, _ch = 112, _ss = 2, _W = _cols * _cw, _H = _rows * _ch;
    var _paper = dby_art__hex("#efe6d2");
    var _big = surface_create(_W * _ss, _H * _ss), _small = surface_create(_W, _H);
    var _rec = { runners: 0, distinct_looks: 0, distinct_names: 0, ink: 0, ink_blank: -1, ground_bytes: [], file: "dby_render_runners.png" };
    // control first: the blank ground must read 0 ink against its own bytes, and the bytes are recorded
    surface_set_target(_small); draw_clear_alpha(_paper, 1); surface_reset_target();
    var _gb = dby_bake__ground(_small);
    _rec.ground_bytes = _gb;
    _rec.ink_blank = dby_bake__ink(_small, _W, _H, _gb);
    surface_set_target(_big);
    draw_clear_alpha(_paper, 1);
    var _looks = {}, _names = {}, _n = 0;
    // stables share one name pool, so a sheet drawn from several repeats names: draw each name once
    for (var _sd = 0; _sd < 12 && _n < _cols * _rows; _sd++) {
        var _stable = dby_make_stable(101 + _sd * 17, 16);
        for (var _i = 0; _i < 16 && _n < _cols * _rows; _i++) {
            var _ru = _stable[_i], _col = _n mod _cols, _row = _n div _cols;
            if (variable_struct_exists(_names, _ru.name)) continue;
            _names[$ _ru.name] = 1;
            dby_art_snail(_ru.look, _i + 1, (_col * _cw + _cw * 0.52) * _ss, (_row * _ch + 50) * _ss, 1.25 * _ss);
            dby_k_text((_col * _cw + _cw / 2) * _ss, (_row * _ch + 97) * _ss, _ru.name, 11 * _ss, dby_art__hex("#3a2414"), fa_center, fa_middle, fnt_derby_ui);
            var _L = _ru.look;
            _looks[$ string(_L.shell) + "/" + _L.pattern + "/" + string(_L.bands) + "/" + _L.cloth + "/" + string(_L.silk[0]) + "/" + string(_L.silk[1])] = 1;
            _n++;
        }
    }
    surface_reset_target();
    surface_set_target(_small);
    draw_clear_alpha(_paper, 1);
    gpu_set_tex_filter(true);
    draw_surface_ext(_big, 0, 0, 1 / _ss, 1 / _ss, 0, c_white, 1);
    gpu_set_tex_filter(false);
    surface_reset_target();
    surface_save(_small, _rec.file);
    _rec.ink = dby_bake__ink(_small, _W, _H, _gb);
    _rec.runners = _n;
    _rec.distinct_looks = variable_struct_names_count(_looks);
    _rec.distinct_names = variable_struct_names_count(_names);
    surface_free(_big); surface_free(_small);
    _rec.timing = dby_bake_timing();
    _rec.surfaces = dby_bake_surfaces();
    _rec.courses = dby_bake_courses();
    var _f = file_text_open_write("dby_sheet.json");
    file_text_write_string(_f, json_stringify(_rec));
    file_text_close(_f);
}
