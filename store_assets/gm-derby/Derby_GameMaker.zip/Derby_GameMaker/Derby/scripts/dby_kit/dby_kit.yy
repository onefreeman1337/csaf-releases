{
  "$GMScript": "v1",
  "%Name": "dby_kit",
  "name": "dby_kit",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}