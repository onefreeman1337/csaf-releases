/// dby_core.gml - the race model and the bookmaker for Derby. Pure logic: nothing here draws and nothing uses random().
/// A race is a seed. The same card run from the same seed finishes in the same order on every machine, and the odds on
/// the board are MEASURED from the same race model the player watches.
///
/// Derby - A Snail-Racing Betting Minigame, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// PUBLIC
///   dby_make_stable(seed, [size])          -> an array of runners (5..16; default 12), each with a look and four hidden ratings
///   dby_make_course(seed, [theme])         -> {theme, name, len, sections[{from, to, surface}]}
///   dby_open_book(stable, opts)            -> a card for one race, UNPRICED; opts {seed, race_no, field_size, course, going, payback, kind}
///   dby_work_book(card, [ms])              -> price for up to `ms` milliseconds this frame; true once the card is priced
///   dby_make_card(stable, opts)            -> open and fully price a card in one call (7 runners: about 3 s on the VM)
///   dby_solo_times(card, samples, [salt]) / dby_combine_times(times, place_terms) -> the pricer's two halves, exposed
///   dby_make_race(field, course, going) / dby_reset_race(race, seed) / dby_tick(race) / dby_run_race(race, seed)
///   dby_margin_at(race, place) / dby_margin_words(shells) / dby_price_text(rung) / dby_settle(card, race, bet)
///   dby_initial_form(stable, seed)         -> {runner id: [placings]}: six earlier races, so the form is informative
///
/// ⛔ THE RACE IS PORTED LINE FOR LINE FROM THE RPG MAKER MZ DerbyCore.js AND PROVEN EXACT AGAINST IT: the suite compares
/// finishing orders, crossing times and lead changes with values the MZ core computed (dby_oracle).
/// ⛔ THE BOOK IS NOT THE MZ BOOK, ON PURPOSE. MZ prices a card from 2 x 2,000 joint races; on the GML VM one race costs
/// ~10-13 ms, so that book took 52 s a card (MEASURED 2026-09-27). Each runner draws only from its own generator, and the
/// only coupling in a race is the late chase, so here every runner is raced ALONE 400 times and the crossing times are
/// combined exactly (dby_combine_times). Measured in Node against 20,000-race truth on 20 cards (249 bets): no bet's true
/// return exceeded 0.857 at payback 0.85, against 0.911 for the MZ book; the price of that is a more cautious board. On
/// the VM it prices a 7-runner card in ~3 s (17x faster). Its own oracle arm pins every chance and rung against a Node
/// reference running the MZ tick. Two things make the exactness possible, and removing either breaks it silently:
///   1. All 32-bit integer arithmetic goes through dby_mul32 (a GML real holds 53 bits; a 32x32 product needs 64).
///   2. GML compares numbers with a default EPSILON of 0.00001, so `u < p_surge` would flip about once in 50,000 draws
///      against JavaScript and re-price a card. Every public entry point here runs with math_set_epsilon(0) and
///      restores your value on the way out.

#macro DBY_LEN 1000
#macro DBY_BODY 14
#macro DBY_BASE 3.2
#macro DBY_MAX_TICKS 1400
#macro DBY_SOLO_N 400
#macro DBY_Z 1.64
#macro DBY_CHASE 1.03
#macro DBY_SHELLS 10
#macro DBY_BODIES 5
#macro DBY_SILKS 12

/// @function dby__eps0()
/// @description Set the comparison epsilon to 0 and return the old value (restore it with math_set_epsilon). Internal.
function dby__eps0() { var _e = math_get_epsilon(); math_set_epsilon(0); return _e; }

/// @function dby_mul32(a, b)
/// @description The low 32 bits of a * b for two unsigned 32-bit numbers (JavaScript's Math.imul, unsigned). Pure.
function dby_mul32(_a, _b) {
    _a = _a & $FFFFFFFF;
    _b = _b & $FFFFFFFF;
    var _lo = (_a & $FFFF) * _b;
    var _hi = (((_a >> 16) & $FFFF) * _b) & $FFFF;
    return (_lo + (_hi << 16)) & $FFFFFFFF;
}

/// @function dby_hash(text)
/// @description FNV-1a 32 of a string (the MZ core's hashString). Pure.
function dby_hash(_s) {
    _s = string(_s);
    var _h = $811C9DC5;
    for (var _i = 1; _i <= string_length(_s); _i++) _h = dby_mul32((_h ^ (ord(string_char_at(_s, _i)) & $FFFF)) & $FFFFFFFF, $01000193);
    return _h;
}

/// @function dby_mix(a, b)
/// @description Mix two 32-bit numbers into one (the MZ core's mix). Pure.
function dby_mix(_a, _b) {
    var _h = dby_mul32((floor(_a) & $FFFFFFFF) ^ dby_mul32(floor(_b) & $FFFFFFFF, $9E3779B1), $85EBCA6B);
    _h = (_h ^ (_h >> 13)) & $FFFFFFFF;
    _h = dby_mul32(_h, $C2B2AE35);
    return (_h ^ (_h >> 16)) & $FFFFFFFF;
}

/// @function dby_rng(seed)
/// @description A generator state {a} (mulberry32); draw with dby_rnd(). Pure.
function dby_rng(_seed) { return { a: is_numeric(_seed) ? (floor(_seed) & $FFFFFFFF) : dby_hash(_seed) }; }

/// @function dby_rnd(state)
/// @description The next number in [0, 1) from a generator state (the MZ core's rnd / rng()). Any struct with a
/// numeric `a` works: a runner carries its own. Pure but for the state it advances.
function dby_rnd(_s) {
    _s.a = (_s.a + $6D2B79F5) & $FFFFFFFF;
    var _t = dby_mul32(_s.a ^ (_s.a >> 15), 1 | _s.a);
    _t = ((_t + dby_mul32(_t ^ (_t >> 7), 61 | _t)) & $FFFFFFFF) ^ _t;
    return ((_t ^ (_t >> 14)) & $FFFFFFFF) / 4294967296;
}

/// @function dby__round(x)
/// @description JavaScript's Math.round: floor(x + 0.5). Internal, pure.
function dby__round(_x) { return floor(_x + 0.5); }

/// @function dby__pick(state, array)
function dby__pick(_r, _a) { var _n = array_length(_a); return _a[floor(dby_rnd(_r) * _n) mod _n]; }

/// @function dby__shuffle(state, array)
/// @description Shuffle an array in place (Fisher-Yates, the MZ order) and return it. Internal.
function dby__shuffle(_r, _a) {
    for (var _i = array_length(_a) - 1; _i > 0; _i--) { var _j = floor(dby_rnd(_r) * (_i + 1)); var _t = _a[_i]; _a[_i] = _a[_j]; _a[_j] = _t; }
    return _a;
}

// ---------------------------------------------------------------------------------------------------------------
// Tables, as the MZ core has them. Snails are faster where it is wet; a preference is worth a few per cent.
// ---------------------------------------------------------------------------------------------------------------

/// @function dby_courses()
function dby_courses() { static _c = ["kitchen", "rockery", "greenhouse", "orchard", "mossbank"]; return _c; }
/// @function dby_surfaces()
function dby_surfaces() { static _c = ["moss", "slate", "sand", "puddle", "leaf", "gravel"]; return _c; }
/// @function dby_goings()
function dby_goings() { static _c = ["dewy", "damp", "dry"]; return _c; }
/// @function dby_patterns()
function dby_patterns() { static _c = ["bands", "spots", "flames", "rays"]; return _c; }
/// @function dby_cloths()
function dby_cloths() { static _c = ["plain", "hoops", "halves", "sash", "quarters", "chevron"]; return _c; }
/// @function dby__prefs()
function dby__prefs() { static _c = ["damp", "dry", "any"]; return _c; }
/// @function dby__race_kinds()
function dby__race_kinds() { static _c = ["Maiden Plate", "Handicap", "Stakes", "Cup", "Derby"]; return _c; }

/// @function dby__course_name(theme)
function dby__course_name(_t) {
    switch (_t) { case "kitchen": return "Kitchen Garden"; case "rockery": return "Rockery"; case "greenhouse": return "Greenhouse"; case "orchard": return "Orchard"; case "mossbank": return "Moss Bank"; }
    return "Garden";
}

/// @function dby__course_mix(theme)
function dby__course_mix(_t) {
    switch (_t) {
        case "kitchen": return ["slate", "sand", "moss", "leaf", "puddle", "slate"];
        case "rockery": return ["gravel", "slate", "moss", "sand", "gravel"];
        case "greenhouse": return ["slate", "puddle", "moss", "sand", "leaf"];
        case "orchard": return ["leaf", "moss", "gravel", "slate", "puddle", "leaf"];
    }
    return ["moss", "puddle", "leaf", "slate", "moss"];
}

/// @function dby__surf_f(surface)
function dby__surf_f(_s) { switch (_s) { case "moss": return 1.07; case "slate": return 1.0; case "sand": return 0.86; case "puddle": return 0.9; case "leaf": return 0.95; case "gravel": return 0.9; } return 1.0; }

/// @function dby__pref_f(pref, surface)
function dby__pref_f(_p, _s) {
    if (_p == "damp") { switch (_s) { case "moss": return 0.03; case "puddle": return 0.06; case "sand": return -0.03; } return 0; }
    if (_p == "dry") { switch (_s) { case "sand": return 0.05; case "slate": return 0.02; case "gravel": return 0.03; case "puddle": return -0.05; } return 0; }
    return 0;
}

/// @function dby__going_f(going, pref)
function dby__going_f(_g, _p) {
    if (_g == "dewy") { if (_p == "damp") return 0.015; if (_p == "dry") return -0.01; return 0; }
    if (_g == "damp") { if (_p == "damp") return 0.008; return 0; }
    if (_g == "dry") { if (_p == "dry") return 0.015; if (_p == "damp") return -0.01; return 0; }
    return 0;
}

/// @function dby__ladder()
/// @description Fractional odds, shortest to longest. A price is always rounded DOWN this ladder, never up. Internal.
function dby__ladder() {
    static _l = [[1, 10], [1, 8], [1, 6], [1, 5], [2, 9], [1, 4], [2, 7], [1, 3], [4, 11], [2, 5], [4, 9], [1, 2], [8, 15], [4, 7], [8, 13],
        [4, 6], [8, 11], [4, 5], [5, 6], [10, 11], [1, 1], [11, 10], [6, 5], [5, 4], [11, 8], [6, 4], [13, 8], [7, 4], [15, 8], [2, 1], [9, 4],
        [5, 2], [11, 4], [3, 1], [10, 3], [7, 2], [4, 1], [9, 2], [5, 1], [11, 2], [6, 1], [13, 2], [7, 1], [15, 2], [8, 1], [9, 1], [10, 1],
        [11, 1], [12, 1], [14, 1], [16, 1], [20, 1], [25, 1], [33, 1], [40, 1], [50, 1]];
    return _l;
}

/// @function dby__names()
function dby__names() {
    static _n = {
        first: ["Morning", "Silver", "Garden", "Midnight", "Copper", "Velvet", "Thunder", "Lazy", "Dapper", "Mossy", "Rainy", "Lucky",
            "Old", "Little", "Brave", "Gentle", "Sir", "Lady", "Captain", "Duchess", "Humble", "Royal", "Quiet", "Wild", "Sunday", "Amber"],
        second: ["Dew", "Trail", "Spiral", "Lettuce", "Clover", "Pebble", "Drizzle", "Comet", "Thistle", "Button", "Bramble", "Nettle",
            "Glimmer", "Fern", "Puddle", "Marigold", "Cabbage", "Acorn", "Buttercup", "Hailstone", "Whistle", "Parsley", "Rhubarb", "Snowdrop"],
        whole: ["Slow Gin", "Shell Shock", "Lettuce Pray", "Escargot", "Snailblazer", "Slime Time", "Hot Trail", "Spiral Arm", "Leaf It Out",
            "Dew Or Die", "Slow Burn", "Trailblazer", "Home Shell", "Full Spiral", "Nibbler", "Soft Shoe", "Damp Squib", "Quicksilver"]
    };
    return _n;
}

// ---------------------------------------------------------------------------------------------------------------
// Stables and courses
// ---------------------------------------------------------------------------------------------------------------

/// @function dby_make_stable(seed, [size])
/// @description A stable of runners (5..16, default 12). Each: {id, name, look {shell 0-9, body 0-4, pattern, tight, bands 2-5,
/// silk [a, b] 0-11, cloth, seed}, speed, stamina, surge, temper, pref}. The same seed always gives the same stable. Pure.
function dby_make_stable(_seed, _size = 12) {
    // a seed that is not a number is hashed (the adversarial pass found dby_mix(undefined) thrown from the look seed);
    // a number goes through unchanged, so every numeric stable is still bit-identical to the MZ core's
    _seed = is_numeric(_seed) ? (floor(_seed) & $FFFFFFFF) : dby_hash(_seed);
    var _e = dby__eps0();
    var _n = clamp(floor(is_numeric(_size) ? _size : 12), 5, 16);
    var _r = dby_rng(dby_mix(floor(is_numeric(_seed) ? _seed : 0) & $FFFFFFFF, $57AB1E)), _used = {}, _out = [], _nm = dby__names();
    for (var _i = 0; _i < _n; _i++) {
        var _name = "", _tries = 0;
        do {
            if (dby_rnd(_r) < 0.3) _name = dby__pick(_r, _nm.whole);
            else { var _f = dby__pick(_r, _nm.first); var _g = dby__pick(_r, _nm.second); _name = _f + " " + _g; }
            var _again = variable_struct_exists(_used, _name);
            if (_again) _tries++;
        } until (!(_again && _tries < 40));
        _used[$ _name] = true;
        var _s1 = floor(dby_rnd(_r) * DBY_SILKS);
        var _s2 = (_s1 + 1 + floor(dby_rnd(_r) * (DBY_SILKS - 1))) mod DBY_SILKS;
        var _shell = floor(dby_rnd(_r) * DBY_SHELLS);
        var _body = floor(dby_rnd(_r) * DBY_BODIES);
        var _pat = dby__pick(_r, dby_patterns());
        var _tight = dby__round((0.16 + dby_rnd(_r) * 0.1) * 1000) / 1000;
        var _bands = 2 + floor(dby_rnd(_r) * 4);
        var _cloth = dby__pick(_r, dby_cloths());
        var _look = { shell: _shell, body: _body, pattern: _pat, tight: _tight, bands: _bands, silk: [_s1, _s2], cloth: _cloth, seed: dby_mix(_seed, $100 + _i) };
        var _speed = dby__round((0.98 + dby_rnd(_r) * 0.04) * 1000) / 1000;
        var _stamina = dby__round(dby_rnd(_r) * 1000) / 1000;
        var _surge = dby__round(dby_rnd(_r) * 1000) / 1000;
        var _temper = dby__round(dby_rnd(_r) * 1000) / 1000;
        var _pref = dby__pick(_r, dby__prefs());
        array_push(_out, { id: _i, name: _name, look: _look, speed: _speed, stamina: _stamina, surge: _surge, temper: _temper, pref: _pref });
    }
    math_set_epsilon(_e);
    return _out;
}

/// @function dby_make_course(seed, [theme])
/// @description A course: a garden theme (one of dby_courses(); anything else is chosen by the seed) and 4-6 sections of
/// surface along DBY_LEN race units, none shorter than 6% of it. Pure.
function dby_make_course(_seed, _theme = undefined) {
    var _e = dby__eps0();
    var _r = dby_rng(dby_mix(floor(is_numeric(_seed) ? _seed : 0) & $FFFFFFFF, $C0053));
    var _th = (is_string(_theme) && array_get_index(dby_courses(), _theme) >= 0) ? _theme : dby__pick(_r, dby_courses());
    var _mix = dby__course_mix(_th), _k = 4 + floor(dby_rnd(_r) * 3), _cuts = [], _i;
    for (_i = 0; _i < _k - 1; _i++) array_push(_cuts, 0.12 + dby_rnd(_r) * 0.76);
    array_sort(_cuts, true);
    var _clean = [];
    for (_i = 0; _i < array_length(_cuts); _i++) if (array_length(_clean) == 0 || _cuts[_i] - _clean[array_length(_clean) - 1] > 0.06) array_push(_clean, _cuts[_i]);
    var _sections = [], _from = 0, _last = "";
    for (var _s = 0; _s <= array_length(_clean); _s++) {
        var _to = (_s < array_length(_clean)) ? dby__round(_clean[_s] * DBY_LEN) : DBY_LEN, _surf = "", _t = 0;
        do { _surf = dby__pick(_r, _mix); _t++; } until (!(_surf == _last && _t < 10));
        array_push(_sections, { from: _from, to: _to, surface: _surf }); _from = _to; _last = _surf;
    }
    math_set_epsilon(_e);
    return { theme: _th, name: dby__course_name(_th), len: DBY_LEN, sections: _sections };
}

// ---------------------------------------------------------------------------------------------------------------
// The race. dby_tick() is the ONLY race model: the race you draw calls it, the bookmaker calls it thousands of times to
// price the card, and the suite calls it; all three agree by construction.
// ---------------------------------------------------------------------------------------------------------------

/// @function dby_terrain_factor(runner, surface, going)
/// @description How fast a runner goes on a surface in a going, as a multiplier. Pure.
function dby_terrain_factor(_ru, _surf, _going) { return dby__surf_f(_surf) + dby__pref_f(_ru.pref, _surf) + dby__going_f(_going, _ru.pref); }

/// @function dby_make_race(field, course, going)
/// @description Allocate a race for a field (runners from a stable) on a course. Everything the step needs is made here.
function dby_make_race(_field, _course, _going) {
    // a refusal, never a crash: a field of runners (structs from dby_make_stable) and a course (dby_make_course)
    if (!is_array(_field) || array_length(_field) < 1 || !is_struct(_course) || !variable_struct_exists(_course, "sections") || !is_array(_course.sections) || array_length(_course.sections) < 1) return undefined;
    for (var _c = 0; _c < array_length(_field); _c++) if (!is_struct(_field[_c]) || !variable_struct_exists(_field[_c], "speed") || !variable_struct_exists(_field[_c], "pref")) return undefined;
    var _n = array_length(_field), _rs = [], _order = [];
    for (var _i = 0; _i < _n; _i++) {
        var _f = _field[_i], _tf = [];
        for (var _s = 0; _s < array_length(_course.sections); _s++) array_push(_tf, dby_terrain_factor(_f, _course.sections[_s].surface, _going));
        array_push(_rs, { id: _f.id, speed: _f.speed, stamina: _f.stamina, p_surge: 0.004 + 0.01 * _f.surge, p_stall: 0.002 + 0.008 * _f.temper, tf: _tf,
            x: 0, prev_x: 0, v: 0, v_fin: 0, st: 0, st_t: 0, n: 0, fin: -1, a: 0, sec: 0 });
        array_push(_order, -1);
    }
    return { n: _n, course: _course, going: _going, runners: _rs, order: _order, n_fin: 0, t: 0, leader: -1, lead_changes: 0, lead_x: 0, done: false, capped: false, seed: 0 };
}

/// @function dby_reset_race(race, seed)
/// @description Reset a race to the start under a new seed.
function dby_reset_race(_race, _seed) {
    if (!is_struct(_race) || !variable_struct_exists(_race, "runners")) return undefined;
    _seed = is_numeric(_seed) ? _seed : dby_hash(_seed);
    _race.t = 0; _race.n_fin = 0; _race.leader = -1; _race.lead_changes = 0; _race.done = false; _race.seed = floor(_seed) & $FFFFFFFF; _race.lead_x = 0; _race.capped = false;
    for (var _i = 0; _i < _race.n; _i++) {
        var _s = _race.runners[_i];
        _s.x = 0; _s.prev_x = 0; _s.v = 0; _s.v_fin = 0; _s.st = 0; _s.st_t = 0; _s.n = 0; _s.fin = -1; _s.sec = 0; _s.a = dby_mix(_seed, $A11 + _s.id);
        _race.order[_i] = -1;
    }
    return _race;
}

/// @function dby_tick(race)
/// @description Advance the race one tick; true once every runner has crossed the line. State per runner: 0 running,
/// 1 surging (x1.22 for 18-39 ticks), 2 stopped to nibble (x0.35 for 8-23 ticks).
/// ⛔ SPEED: the bookmaker runs this ~1.5 million times a card. The first port called dby_rnd (and dby_mul32 twice inside
/// it) up to three times per runner per tick and read every field through the struct: MEASURED 12.5 ms a race and 67 s
/// to price one card. The generator is therefore INLINED below (the same mulberry32 as dby_rnd, split multiply and all)
/// and each runner's fields are read into locals once and written back once. The suite's oracle arms (crossing times,
/// every price) prove the inlined copy is bit-identical to dby_rnd.
function dby_tick(_race) {
    if (!is_struct(_race) || !variable_struct_exists(_race, "runners")) return true;
    if (_race.done) return true;
    var _e = math_get_epsilon(); math_set_epsilon(0);
    var _rs = _race.runners, _secs = _race.course.sections, _n = _race.n, _i, _ns = array_length(_secs);
    var _lead_x = _race.lead_x;
    _race.t++;
    var _tnow = _race.t;
    for (_i = 0; _i < _n; _i++) {
        var _s = _rs[_i];
        if (_s.fin >= 0) { _s.prev_x = _s.x; if (_s.x < DBY_LEN + 70) _s.x += _s.v * 0.35; continue; }
        var _x = _s.x, _sec = _s.sec, _st = _s.st, _a = _s.a, _t, _hi, _u;
        while (_sec < _ns - 1 && _x >= _secs[_sec].to) _sec++;
        var _leafy = (_secs[_sec].surface == "leaf");
        if (_st == 0) {
            // --- inline dby_rnd(_s) -> _u
            _a = (_a + $6D2B79F5) & $FFFFFFFF;
            _t = _a ^ (_a >> 15); _hi = (((_t >> 16) & $FFFF) * (1 | _a)) & $FFFF; _t = (((_t & $FFFF) * (1 | _a)) + (_hi << 16)) & $FFFFFFFF;
            var _m2 = _t ^ (_t >> 7); _hi = (((_m2 >> 16) & $FFFF) * (61 | _t)) & $FFFF; _m2 = (((_m2 & $FFFF) * (61 | _t)) + (_hi << 16)) & $FFFFFFFF;
            _t = ((_t + _m2) & $FFFFFFFF) ^ _t;
            _u = ((_t ^ (_t >> 14)) & $FFFFFFFF) / 4294967296;
            if (_u < _s.p_surge || _u < _s.p_surge + _s.p_stall * (_leafy ? 2 : 1)) {
                var _surging = (_u < _s.p_surge);
                // --- inline dby_rnd(_s) -> _u (the duration)
                _a = (_a + $6D2B79F5) & $FFFFFFFF;
                _t = _a ^ (_a >> 15); _hi = (((_t >> 16) & $FFFF) * (1 | _a)) & $FFFF; _t = (((_t & $FFFF) * (1 | _a)) + (_hi << 16)) & $FFFFFFFF;
                _m2 = _t ^ (_t >> 7); _hi = (((_m2 >> 16) & $FFFF) * (61 | _t)) & $FFFF; _m2 = (((_m2 & $FFFF) * (61 | _t)) + (_hi << 16)) & $FFFFFFFF;
                _t = ((_t + _m2) & $FFFFFFFF) ^ _t;
                _u = ((_t ^ (_t >> 14)) & $FFFFFFFF) / 4294967296;
                if (_surging) { _st = 1; _s.st_t = 18 + floor(_u * 22); } else { _st = 2; _s.st_t = 8 + floor(_u * 16); }
            }
        } else { _s.st_t -= 1; if (_s.st_t <= 0) _st = 0; }
        var _m = (_st == 1) ? 1.22 : ((_st == 2) ? 0.35 : 1);
        var _prog = _x / DBY_LEN;
        var _fat = (_prog > 0.55) ? 1 - (1 - _s.stamina) * 0.1 * (_prog - 0.55) / 0.45 : 1;
        var _gap = _lead_x - _x;
        if (_prog > 0.75 && _gap > 0.5 && _gap < 3 * DBY_BODY) _m *= DBY_CHASE;
        // --- inline dby_rnd(_s) -> _u (the noise)
        _a = (_a + $6D2B79F5) & $FFFFFFFF;
        _t = _a ^ (_a >> 15); _hi = (((_t >> 16) & $FFFF) * (1 | _a)) & $FFFF; _t = (((_t & $FFFF) * (1 | _a)) + (_hi << 16)) & $FFFFFFFF;
        var _m3 = _t ^ (_t >> 7); _hi = (((_m3 >> 16) & $FFFF) * (61 | _t)) & $FFFF; _m3 = (((_m3 & $FFFF) * (61 | _t)) + (_hi << 16)) & $FFFFFFFF;
        _t = ((_t + _m3) & $FFFFFFFF) ^ _t;
        _u = ((_t ^ (_t >> 14)) & $FFFFFFFF) / 4294967296;
        var _noise = _s.n * 0.92 + (_u - 0.5) * 0.05;
        var _v = DBY_BASE * _s.speed * _s.tf[_sec] * _m * _fat * (1 + _noise);
        _s.n = _noise; _s.v = _v; _s.prev_x = _x; _s.sec = _sec; _s.st = _st; _s.a = _a;
        _x += _v; _s.x = _x;
        if (_x >= DBY_LEN) {
            _s.fin = _tnow - 1 + (DBY_LEN - _s.prev_x) / _v; _s.v_fin = _v;
            var _k = _race.n_fin; _race.n_fin++;
            while (_k > 0 && _rs[_race.order[_k - 1]].fin > _s.fin) { _race.order[_k] = _race.order[_k - 1]; _k--; }
            _race.order[_k] = _i;
        }
    }
    var _lead = (_race.n_fin > 0) ? _race.order[0] : 0;
    if (_race.n_fin == 0) for (_i = 1; _i < _n; _i++) if (_rs[_i].x > _rs[_lead].x) _lead = _i;
    if (_lead != _race.leader) { if (_race.leader >= 0 && _tnow > 20 && _race.n_fin == 0) _race.lead_changes++; _race.leader = _lead; }
    _race.lead_x = _rs[_lead].x;
    if (_race.n_fin == _n || _tnow >= DBY_MAX_TICKS) {
        if (_race.n_fin < _n) {
            for (_i = 0; _i < _n; _i++) if (_rs[_i].fin < 0) {
                _rs[_i].fin = _tnow + (DBY_LEN - _rs[_i].x) / max(0.01, (_rs[_i].v != 0) ? _rs[_i].v : 0.01); _rs[_i].v_fin = _rs[_i].v;
                var _q = _race.n_fin; _race.n_fin++;
                while (_q > 0 && _rs[_race.order[_q - 1]].fin > _rs[_i].fin) { _race.order[_q] = _race.order[_q - 1]; _q--; }
                _race.order[_q] = _i;
            }
            _race.capped = true;
        }
        _race.done = true;
    }
    math_set_epsilon(_e);
    return _race.done;
}

/// @function dby_run_race(race, seed)
/// @description Run a race to the end from a seed; returns the race (read .order and .runners[i].fin).
function dby_run_race(_race, _seed) { if (is_undefined(dby_reset_race(_race, _seed))) return undefined; while (!dby_tick(_race)) { } return _race; }

/// @function dby__solo_fin(speed, stamina, p_surge, p_stall, tf, to, leafy, sections, a0)
/// @description One runner raced ALONE to the line from generator state a0; returns its crossing time. Internal.
/// Bit-identical to dby_run_race on a one-runner field (a lone runner is always its own leader, so the chase never
/// fires): the suite proves it. Every value lives in a local, because this is the bookmaker's inner loop.
function dby__solo_fin(_speed, _stamina, _ps, _pl, _tf, _to, _lf, _ns, _a) {
    var _x = 0, _px = 0, _v = 0, _st = 0, _stt = 0, _nz = 0, _sec = 0, _tk = 0, _t, _hi, _m2, _u, _m, _prog, _fat;
    while (true) {
        _tk++;
        while (_sec < _ns - 1 && _x >= _to[_sec]) _sec++;
        if (_st == 0) {
            _a = (_a + $6D2B79F5) & $FFFFFFFF;
            _t = _a ^ (_a >> 15); _hi = (((_t >> 16) & $FFFF) * (1 | _a)) & $FFFF; _t = (((_t & $FFFF) * (1 | _a)) + (_hi << 16)) & $FFFFFFFF;
            _m2 = _t ^ (_t >> 7); _hi = (((_m2 >> 16) & $FFFF) * (61 | _t)) & $FFFF; _m2 = (((_m2 & $FFFF) * (61 | _t)) + (_hi << 16)) & $FFFFFFFF;
            _t = ((_t + _m2) & $FFFFFFFF) ^ _t;
            _u = ((_t ^ (_t >> 14)) & $FFFFFFFF) / 4294967296;
            if (_u < _ps || _u < _ps + _pl * (_lf[_sec] ? 2 : 1)) {
                var _surging = (_u < _ps);
                _a = (_a + $6D2B79F5) & $FFFFFFFF;
                _t = _a ^ (_a >> 15); _hi = (((_t >> 16) & $FFFF) * (1 | _a)) & $FFFF; _t = (((_t & $FFFF) * (1 | _a)) + (_hi << 16)) & $FFFFFFFF;
                _m2 = _t ^ (_t >> 7); _hi = (((_m2 >> 16) & $FFFF) * (61 | _t)) & $FFFF; _m2 = (((_m2 & $FFFF) * (61 | _t)) + (_hi << 16)) & $FFFFFFFF;
                _t = ((_t + _m2) & $FFFFFFFF) ^ _t;
                _u = ((_t ^ (_t >> 14)) & $FFFFFFFF) / 4294967296;
                if (_surging) { _st = 1; _stt = 18 + floor(_u * 22); } else { _st = 2; _stt = 8 + floor(_u * 16); }
            }
        } else { _stt -= 1; if (_stt <= 0) _st = 0; }
        _m = (_st == 1) ? 1.22 : ((_st == 2) ? 0.35 : 1);
        _prog = _x / DBY_LEN;
        _fat = (_prog > 0.55) ? 1 - (1 - _stamina) * 0.1 * (_prog - 0.55) / 0.45 : 1;
        _a = (_a + $6D2B79F5) & $FFFFFFFF;
        _t = _a ^ (_a >> 15); _hi = (((_t >> 16) & $FFFF) * (1 | _a)) & $FFFF; _t = (((_t & $FFFF) * (1 | _a)) + (_hi << 16)) & $FFFFFFFF;
        _m2 = _t ^ (_t >> 7); _hi = (((_m2 >> 16) & $FFFF) * (61 | _t)) & $FFFF; _m2 = (((_m2 & $FFFF) * (61 | _t)) + (_hi << 16)) & $FFFFFFFF;
        _t = ((_t + _m2) & $FFFFFFFF) ^ _t;
        _u = ((_t ^ (_t >> 14)) & $FFFFFFFF) / 4294967296;
        _nz = _nz * 0.92 + (_u - 0.5) * 0.05;
        _v = DBY_BASE * _speed * _tf[_sec] * _m * _fat * (1 + _nz);
        _px = _x; _x += _v;
        if (_x >= DBY_LEN) return _tk - 1 + (DBY_LEN - _px) / _v;
        if (_tk >= DBY_MAX_TICKS) return _tk + (DBY_LEN - _x) / max(0.01, (_v != 0) ? _v : 0.01);
    }
}

/// @function dby_solo_times(card, samples, [salt])
/// @description Race every runner on a card ALONE `samples` times over the card's course and going; returns an array (one
/// per runner, card order) of crossing-time arrays. Deterministic in the card's race seed and `salt`.
function dby_solo_times(_card, _M, _salt = $5010) {
    var _e = dby__eps0();
    var _secs = _card.course.sections, _ns = array_length(_secs), _to = array_create(_ns), _lf = array_create(_ns), _k, _out = [];
    for (_k = 0; _k < _ns; _k++) { _to[_k] = _secs[_k].to; _lf[_k] = (_secs[_k].surface == "leaf"); }
    for (var _i = 0; _i < array_length(_card.field); _i++) {
        var _f = _card.field[_i], _tf = array_create(_ns), _ts = array_create(_M), _base = dby_mix(_card.race_seed, _salt + _i);
        for (_k = 0; _k < _ns; _k++) _tf[_k] = dby_terrain_factor(_f, _secs[_k].surface, _card.going);
        var _ps = 0.004 + 0.01 * _f.surge, _pl = 0.002 + 0.008 * _f.temper;
        for (var _s = 0; _s < _M; _s++) _ts[_s] = dby__solo_fin(_f.speed, _f.stamina, _ps, _pl, _tf, _to, _lf, _ns, dby_mix(dby_mix(_base, _s), $A11 + _f.id));
        array_push(_out, _ts);
    }
    math_set_epsilon(_e);
    return _out;
}

/// @function dby_combine_times(times, place_terms)
/// @description Win and place chances from independent crossing-time samples, combined EXACTLY: every sample of a runner
/// is set against every sample of every rival (P(win) = mean over its samples of the product of each rival's chance of
/// crossing later; P(place) by a Poisson-binomial count). Returns {win: [], place: []}. Pure.
function dby_combine_times(_T, _k) {
    var _e = dby__eps0();
    var _n = array_length(_T), _S = dby__sorted(_T), _dp = array_create(max(1, floor(_k)), 0), _win = array_create(_n, 0), _place = array_create(_n, 0);
    for (var _i = 0; _i < _n; _i++) { var _r = dby__combine_one(_S, _T, _i, _k, _dp); _win[_i] = _r[0]; _place[_i] = _r[1]; }
    math_set_epsilon(_e);
    return { win: _win, place: _place };
}

/// @function dby__sorted(times)
/// @description A sorted copy of every runner's crossing times. Internal.
function dby__sorted(_T) {
    var _n = array_length(_T), _S = array_create(_n);
    for (var _i = 0; _i < _n; _i++) { var _c = array_create(array_length(_T[_i])); array_copy(_c, 0, _T[_i], 0, array_length(_T[_i])); array_sort(_c, true); _S[_i] = _c; }
    return _S;
}

/// @function dby__combine_one(sorted, times, i, place_terms, scratch)
/// @description [P(win), P(place)] for runner i. dby_combine_times and the sliced book both call this, so they agree by
/// construction. The caller holds the comparison epsilon at 0. Internal.
function dby__combine_one(_S, _T, _i, _k, _dp) {
    _k = max(1, floor(_k));
    var _n = array_length(_T), _Ti = _T[_i], _M = array_length(_Ti), _sw = 0, _sp = 0, _s, _j, _m;
    for (_s = 0; _s < _M; _s++) {
        var _t = _Ti[_s], _pw = 1;
        _dp[0] = 1; for (_m = 1; _m < _k; _m++) _dp[_m] = 0;
        for (_j = 0; _j < _n; _j++) {
            if (_j == _i) continue;
            var _Sj = _S[_j], _lo = 0, _hi = array_length(_Sj);
            while (_lo < _hi) { var _mid = (_lo + _hi) >> 1; if (_Sj[_mid] < _t) _lo = _mid + 1; else _hi = _mid; }
            var _q = _lo / array_length(_Sj);
            _pw *= (1 - _q);
            for (_m = _k - 1; _m >= 1; _m--) _dp[_m] = _dp[_m] * (1 - _q) + _dp[_m - 1] * _q;
            _dp[0] *= (1 - _q);
        }
        _sw += _pw;
        var _acc = 0; for (_m = 0; _m < _k; _m++) _acc += _dp[_m];
        _sp += _acc;
    }
    return [_sw / _M, _sp / _M];
}

/// @function dby_margin_at(race, place)
/// @description The winning margin between two placings, in snail lengths ("shells"). Pure.
function dby_margin_at(_race, _place) {
    if (!is_struct(_race) || !variable_struct_exists(_race, "order") || !is_numeric(_place) || _place < 0) return 0;
    _place = floor(_place);
    if (_place + 1 >= _race.n || _race.order[_place] < 0 || _race.order[_place + 1] < 0) return 0;
    var _a = _race.runners[_race.order[_place]], _b = _race.runners[_race.order[_place + 1]];
    return max(0, (_b.fin - _a.fin) * ((_b.v_fin != 0) ? _b.v_fin : DBY_BASE)) / DBY_BODY;
}

/// @function dby_margin_words(shells)
/// @description Words for a margin: "a whisker", "a head", "3.5 shells", "a distance". Pure.
function dby_margin_words(_m) {
    var _e = dby__eps0(), _w;
    if (!is_numeric(_m)) _w = "a distance";
    else if (_m < 0.05) _w = "a whisker";
    else if (_m < 0.12) _w = "a stalk";
    else if (_m < 0.25) _w = "a head";
    else if (_m < 0.5) _w = "half a shell";
    else if (_m < 0.8) _w = "three-quarters of a shell";
    else if (_m < 1.5) _w = "a shell";
    else if (_m < 12) { var _h = dby__round(_m * 2) / 2; _w = ((_h == floor(_h)) ? string(floor(_h)) : string_format(_h, 1, 1)) + " shells"; }
    else _w = "a distance";
    math_set_epsilon(_e);
    return _w;
}

// ---------------------------------------------------------------------------------------------------------------
// The bookmaker
// ---------------------------------------------------------------------------------------------------------------

/// @function dby_place_terms(n)
/// @description How many places a Place bet pays on a field of n. Pure.
function dby_place_terms(_n) { if (!is_numeric(_n)) return 1; return (_n >= 8) ? 3 : ((_n >= 5) ? 2 : 1); }

/// @function dby__price_for(p_upper, payback)
/// @description The longest ladder rung whose return does not beat `payback` at chance p_upper; -1 = no price. Internal.
function dby__price_for(_pu, _payback) {
    var _l = dby__ladder();
    if (!(_pu > 0)) return array_length(_l) - 1;
    var _want = _payback / _pu, _best = -1;
    for (var _i = 0; _i < array_length(_l); _i++) { var _d = 1 + _l[_i][0] / _l[_i][1]; if (_d <= _want + 0.000000001) _best = _i; else break; }
    return _best;
}

/// @function dby_dec(rung)
/// @description The decimal return of a ladder rung (stake included); 0 for no price. Pure.
function dby_dec(_rung) { var _l = dby__ladder(); if (!is_numeric(_rung) || _rung < 0 || _rung >= array_length(_l)) return 0; _rung = floor(_rung); return 1 + _l[_rung][0] / _l[_rung][1]; }

/// @function dby_open_book(stable, [opts])
/// @description Draw a card for one race and open its book, UNPRICED. opts: {seed, race_no, field_size 5..8, course, going,
/// payback 0.5..1.0 (default 0.85), kind}. Price it with dby_work_book() over several frames, or dby_make_card().
/// Returns {seed, race_no, kind, name, field, course, going, payback, place_terms, win[], place[], chance_win[],
/// chance_place[], race_seed, solo_runs, priced}, or undefined for a stable that is not an array of runners.
function dby_open_book(_stable, _o = undefined) {
    if (!is_array(_stable) || array_length(_stable) < 1 || !is_struct(_stable[0])) return undefined;
    var _e = dby__eps0();
    var _num = function(_s, _k, _d) { return (is_struct(_s) && variable_struct_exists(_s, _k) && is_numeric(_s[$ _k])) ? _s[$ _k] : _d; };
    var _str = function(_s, _k) { return (is_struct(_s) && variable_struct_exists(_s, _k) && is_string(_s[$ _k])) ? _s[$ _k] : undefined; };
    var _seed = floor(_num(_o, "seed", 0)) & $FFFFFFFF, _race_no = max(0, floor(_num(_o, "race_no", 0)));
    var _cs = dby_mix(_seed, $CA2D + _race_no), _r = dby_rng(_cs);
    var _fs = _num(_o, "field_size", -1);
    var _n_want = (_fs == 5 || _fs == 6 || _fs == 7 || _fs == 8) ? _fs : 6 + floor(dby_rnd(_r) * 3);
    var _n = min(_n_want, array_length(_stable)), _idx = [], _i;
    for (_i = 0; _i < array_length(_stable); _i++) array_push(_idx, _i);
    dby__shuffle(_r, _idx);
    var _field = [];
    for (_i = 0; _i < _n; _i++) array_push(_field, _stable[_idx[_i]]);
    var _cn = _str(_o, "course");
    var _course = dby_make_course(_cs, (!is_undefined(_cn) && array_get_index(dby_courses(), _cn) >= 0) ? _cn : undefined);
    var _gn = _str(_o, "going");
    var _going = (!is_undefined(_gn) && array_get_index(dby_goings(), _gn) >= 0) ? _gn : dby__pick(_r, dby_goings());
    var _pb = _num(_o, "payback", 0.85);
    var _payback = max(0.5, min(1.0, (_pb != 0) ? _pb : 0.85));
    var _kn = _str(_o, "kind"), _kinds = dby__race_kinds();
    var _kind = (!is_undefined(_kn) && _kn != "") ? _kn : _kinds[_race_no mod array_length(_kinds)];
    var _secs = _course.sections, _ns = array_length(_secs), _to = array_create(_ns), _lf = array_create(_ns), _T = array_create(_n);
    for (_i = 0; _i < _ns; _i++) { _to[_i] = _secs[_i].to; _lf[_i] = (_secs[_i].surface == "leaf"); }
    for (_i = 0; _i < _n; _i++) _T[_i] = array_create(DBY_SOLO_N, 0);
    var _card = { v: 1, seed: _seed, race_no: _race_no, kind: _kind, name: "The " + _course.name + " " + _kind, field: _field, course: _course, going: _going,
        payback: _payback, place_terms: dby_place_terms(_n), win: array_create(_n, -1), place: array_create(_n, -1),
        chance_win: array_create(_n, 0), chance_place: array_create(_n, 0), race_seed: dby_mix(_cs, $5EED), solo_runs: DBY_SOLO_N, priced: false,
        book: { i: 0, s: 0, T: _T, to: _to, lf: _lf, ns: _ns, tf: undefined, ps: 0, pl: 0, base: 0, S: undefined, c: 0, dp: undefined } };
    math_set_epsilon(_e);
    return _card;
}

/// @function dby_work_book(card, [ms])
/// @description Price a card for up to `ms` milliseconds of this frame (default: finish it now). Every runner is raced
/// ALONE DBY_SOLO_N times over the card's course and going (dby_solo_times' seeds), the crossing times are combined exactly
/// (dby_combine_times), and every bet is priced on the UPPER bound of its chance, rounded DOWN the ladder. True once priced.
function dby_work_book(_card, _ms = undefined) {
    if (!is_struct(_card) || !variable_struct_exists(_card, "book")) return false;
    if (_card.priced || !is_struct(_card.book)) return true;
    var _e = dby__eps0();
    var _bk = _card.book, _n = array_length(_card.field), _i;
    var _stop = (is_numeric(_ms) && _ms > 0) ? get_timer() + _ms * 1000 : -1;
    while (_bk.i < _n) {
        var _f = _card.field[_bk.i];
        if (_bk.s == 0) {
            _bk.tf = array_create(_bk.ns);
            for (_i = 0; _i < _bk.ns; _i++) _bk.tf[_i] = dby_terrain_factor(_f, _card.course.sections[_i].surface, _card.going);
            _bk.ps = 0.004 + 0.01 * _f.surge; _bk.pl = 0.002 + 0.008 * _f.temper; _bk.base = dby_mix(_card.race_seed, $5010 + _bk.i);
        }
        array_set(_bk.T[_bk.i], _bk.s, dby__solo_fin(_f.speed, _f.stamina, _bk.ps, _bk.pl, _bk.tf, _bk.to, _bk.lf, _bk.ns, dby_mix(dby_mix(_bk.base, _bk.s), $A11 + _f.id)));
        _bk.s++;
        if (_bk.s >= DBY_SOLO_N) { _bk.i++; _bk.s = 0; }
        if (_stop >= 0 && get_timer() >= _stop && _bk.i < _n) { math_set_epsilon(_e); return false; }
    }
    // combining is resumable runner by runner too: in one piece it was a 56 ms slice (MEASURED 2026-09-27, 7 runners)
    if (is_undefined(_bk.S)) {
        _bk.S = dby__sorted(_bk.T); _bk.c = 0; _bk.dp = array_create(max(1, _card.place_terms), 0);
        if (_stop >= 0 && get_timer() >= _stop) { math_set_epsilon(_e); return false; }
    }
    while (_bk.c < _n) {
        var _cw = dby__combine_one(_bk.S, _bk.T, _bk.c, _card.place_terms, _bk.dp);
        _card.chance_win[_bk.c] = _cw[0]; _card.chance_place[_bk.c] = _cw[1]; _bk.c++;
        if (_stop >= 0 && get_timer() >= _stop && _bk.c < _n) { math_set_epsilon(_e); return false; }
    }
    for (_i = 0; _i < _n; _i++) {
        var _pw = _card.chance_win[_i], _pp = _card.chance_place[_i];
        _card.win[_i] = dby__price_for(_pw + DBY_Z * sqrt(max(_pw * (1 - _pw), 1 / DBY_SOLO_N) / DBY_SOLO_N), _card.payback);
        _card.place[_i] = (_card.place_terms >= 2) ? dby__price_for(_pp + DBY_Z * sqrt(max(_pp * (1 - _pp), 1 / DBY_SOLO_N) / DBY_SOLO_N), _card.payback) : -1;
    }
    _card.priced = true; _card.book = undefined;
    math_set_epsilon(_e);
    return true;
}

/// @function dby_make_card(stable, [opts])
/// @description Draw and fully price a card in one call (DBY_SOLO_N solo runs per runner: seconds, not a frame - in a
/// game use dby_open_book + dby_work_book(card, ms) over frames, e.g. pricing the next race while this one is run).
/// undefined for a stable that is not an array of runners.
function dby_make_card(_stable, _o = undefined) {
    var _c = dby_open_book(_stable, _o);
    if (is_undefined(_c)) return undefined;
    dby_work_book(_c);
    return _c;
}

/// @function dby_price_text(rung)
/// @description A fractional price, e.g. "5/2", "Evens", or "-" when no price is offered. Pure.
function dby_price_text(_rung) {
    var _l = dby__ladder();
    if (!is_numeric(_rung) || _rung < 0 || _rung >= array_length(_l)) return "-";
    var _f = _l[_rung];
    return (_f[0] == 1 && _f[1] == 1) ? "Evens" : string(_f[0]) + "/" + string(_f[1]);
}

/// @function dby_settle(card, race, bet)
/// @description What a bet returns (stake included) once the race is run; a losing bet returns 0. bet: {runner (the
/// runner's INDEX in card.field), type "win" or "place", stake}. Pure.
function dby_settle(_card, _race, _bet) {
    if (!is_struct(_card) || !is_struct(_race) || !is_struct(_bet)) return 0;
    if (!variable_struct_exists(_bet, "stake") || !is_numeric(_bet.stake) || !(_bet.stake > 0)) return 0;
    var _who = variable_struct_exists(_bet, "runner") ? _bet.runner : -1, _pos = -1;
    if (!is_numeric(_who) || _who < 0 || _who >= array_length(_card.win)) return 0;
    for (var _i = 0; _i < _race.n; _i++) if (_race.order[_i] == _who) _pos = _i;
    var _type = variable_struct_exists(_bet, "type") ? _bet.type : "win";
    if (_type == "place") return (_pos >= 0 && _pos < _card.place_terms && _card.place[_who] >= 0) ? floor(_bet.stake * dby_dec(_card.place[_who])) : 0;
    return (_pos == 0 && _card.win[_who] >= 0) ? floor(_bet.stake * dby_dec(_card.win[_who])) : 0;
}

/// @function dby_initial_form(stable, seed)
/// @description The form a stable brings to its first meeting: each runner's placings in six earlier races, run by this
/// same model on generated courses (so form figures are informative, not decoration). Most recent last. Returns a
/// struct keyed by runner id as a string: {"0": [3, 1, ...], ...}.
function dby_initial_form(_stable, _seed) {
    var _form = {};
    if (!is_array(_stable)) return _form;
    for (var _c = 0; _c < array_length(_stable); _c++) if (!is_struct(_stable[_c]) || !variable_struct_exists(_stable[_c], "id")) return _form;
    _seed = is_numeric(_seed) ? _seed : dby_hash(_seed);
    var _e = dby__eps0();
    var _r = dby_rng(dby_mix(floor(is_numeric(_seed) ? _seed : 0) & $FFFFFFFF, $F0F0)), _i;
    for (_i = 0; _i < array_length(_stable); _i++) _form[$ string(_stable[_i].id)] = [];
    for (var _k = 0; _k < 6; _k++) {
        var _n = min(array_length(_stable), 6 + floor(dby_rnd(_r) * 3));
        var _copy = [];
        for (_i = 0; _i < array_length(_stable); _i++) array_push(_copy, _stable[_i]);
        dby__shuffle(_r, _copy);
        var _field = [];
        for (_i = 0; _i < _n; _i++) array_push(_field, _copy[_i]);
        var _course = dby_make_course(dby_mix(_seed, $F000 + _k), undefined);
        var _going = dby__pick(_r, dby_goings());
        var _race = dby_run_race(dby_make_race(_field, _course, _going), dby_mix(_seed, $F100 + _k));
        for (var _p = 0; _p < _n; _p++) array_push(_form[$ string(_field[_race.order[_p]].id)], _p + 1);
    }
    math_set_epsilon(_e);
    return _form;
}
