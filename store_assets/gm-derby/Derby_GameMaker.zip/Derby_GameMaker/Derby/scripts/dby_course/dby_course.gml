/// dby_course.gml - the ground a race is run on: six surfaces (moss, slate, sand, puddle, leaf, gravel), each drawn in
/// code from a seeded generator so a course draws the same every time.
///
/// Derby - A Snail-Racing Betting Minigame, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// PUBLIC
///   dby_course_surface(name, x, y, w, h, rng, [k]) -> one surface filling a rectangle; k = supersample factor (mark
///                                                     sizes scale by k, densities stay per 1x pixel)
///   dby_course_texture(name, [k], [seed])            -> the same surface's marks as a SEAMLESS DBY_TEX-square tile
///   dby_course_scenery_layout(...) / dby_course_scenery_draw(layout, x0, x1) -> the scenery band, laid out once, drawn
///                                                     a window at a time
///   dby_course_strip(card, geo)                      -> a whole course strip, drawn mark by mark (slow; for sheets)
///   dby_course_strip_part(card, geo, x0, x1, [textures], [scenery]) -> the strip over one x window, from textures
///   dby_course_theme(theme) / dby_course_lettuce(x, y, s)
/// Ported from the RPG Maker MZ DerbyDraw.js drawSurface: same marks, same densities, the generator drawn in the same
/// order statement by statement (GML evaluates an array literal of calls right to left, so every draw is its own line).

/// @function dby_course__base(name)
/// @description The two ground colours of a surface (top, bottom). Pure.
function dby_course__base(_n) {
    switch (_n) {
        case "moss": return [dby_art__hex("#5f8a3a"), dby_art__hex("#3f6a24")];
        case "slate": return [dby_art__hex("#8a8e94"), dby_art__hex("#5f646c")];
        case "sand": return [dby_art__hex("#dcc08a"), dby_art__hex("#c4a46a")];
        case "puddle": return [dby_art__hex("#6f8ea0"), dby_art__hex("#44657a")];
        case "leaf": return [dby_art__hex("#6a4a2a"), dby_art__hex("#4a3018")];
        case "gravel": return [dby_art__hex("#a0937e"), dby_art__hex("#7a6e5c")];
    }
    return [make_colour_rgb(136, 136, 136), make_colour_rgb(102, 102, 102)];
}

/// @function dby_course__ring(cx, cy, rx, ry, w, colour, alpha)
/// @description An ellipse OUTLINE `w` wide as batch segments (inside dby_k_batch_begin/end). Internal.
function dby_course__ring(_cx, _cy, _rx, _ry, _w, _col, _alpha) {
    var _n = 16, _px = _cx + _rx, _py = _cy;
    for (var _i = 1; _i <= _n; _i++) {
        var _t = _i / _n * DBY_ART_TAU, _nx = _cx + cos(_t) * _rx, _ny = _cy + sin(_t) * _ry;
        dby_k_batch_seg(_px, _py, _nx, _ny, _w, _col, _alpha);
        _px = _nx; _py = _ny;
    }
}

/// @function dby_course__scissor(x, y, w, h)
/// @description Clip to a rectangle given in DRAWING coordinates: the scissor is in render-target pixels and the world
/// matrix is not applied to it, so the rectangle's corners are mapped through matrix_world first. Internal.
function dby_course__scissor(_x, _y, _w, _h) {
    var _m = matrix_get(matrix_world);
    var _ax = _x * _m[0] + _y * _m[4] + _m[12], _ay = _x * _m[1] + _y * _m[5] + _m[13];
    var _bx = (_x + _w) * _m[0] + (_y + _h) * _m[4] + _m[12], _by = (_x + _w) * _m[1] + (_y + _h) * _m[5] + _m[13];
    var _x0 = floor(min(_ax, _bx)), _y0 = floor(min(_ay, _by));
    gpu_set_scissor(_x0, _y0, ceil(max(_ax, _bx)) - _x0, ceil(max(_ay, _by)) - _y0);
}

/// @function dby_course_surface(name, x, y, w, h, rng, [k])
/// @description Fill a rectangle with one surface. `rng` is a generator state (dby_rng) and is advanced. Everything is
/// clipped to the rectangle (a scissor, restored on the way out).
function dby_course_surface(_name, _x, _y, _w, _h, _r, _k = 1) {
    if (!is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_h) || !is_numeric(_k) || _k <= 0 || _k > 8) return;
    if (_w <= 0 || _h <= 0 || _w > 16384 || _h > 16384 || !is_struct(_r) || !variable_struct_exists(_r, "a")) return;
    var _c = dby_course__base(_name), _i, _n, _A = (_w / _k) * (_h / _k), _W1 = _w / _k;
    var _sc = gpu_get_scissor(), _bm = dby_art__blend_begin();
    dby_course__scissor(_x, _y, _w, _h);
    dby_k_rect_grad(_x, _y, _w, _h, _x, _y, _x, _y + _h, [[0, _c[0], 1], [1, _c[1], 1]]);
    dby_k_batch_begin();
    if (_name == "moss") {
        var _lite = make_colour_rgb(170, 210, 110), _dark = make_colour_rgb(20, 50, 10);
        _n = _A / 40;
        for (_i = 0; _i < _n; _i++) {
            var _light = dby_rnd(_r) < 0.5;
            var _mx = _x + dby_rnd(_r) * _w;
            var _my = _y + dby_rnd(_r) * _h;
            var _mr = (0.8 + dby_rnd(_r) * 1.8) * _k;
            dby_k_batch_ellipse(_mx, _my, _mr, _mr, 0, _light ? _lite : _dark, _light ? 0.35 : 0.3);
        }
        var _tuft = make_colour_rgb(190, 230, 120);
        for (_i = 0; _i < _W1 / 18; _i++) {
            var _tx = _x + dby_rnd(_r) * _w;
            var _ty = _y + dby_rnd(_r) * _h;
            for (var _q = -2; _q <= 2; _q++) { var _tl = (4 + dby_rnd(_r) * 3) * _k; dby_k_batch_seg(_tx, _ty, _tx + _q * 1.5 * _k, _ty - _tl, _k, _tuft, 0.5); }
        }
    } else if (_name == "slate") {
        // flags are a fixed size, every one its own width, so the paving reads as laid stone rather than brick
        var _fh = 25 * _k, _rows = ceil(_h / _fh), _fw = 50 * _k, _edge = make_colour_rgb(30, 32, 38);
        for (var _row = 0; _row < _rows; _row++) {
            var _fx = _x - dby_rnd(_r) * 30 * _k;
            while (_fx < _x + _w) {
                _fw = (34 + dby_rnd(_r) * 34) * _k;
                var _shade = 0.85 + dby_rnd(_r) * 0.3, _fy = _y + _row * _fh;
                dby_k_batch_rect(_fx + 1.5 * _k, _fy + 1.5 * _k, _fw - 3 * _k, _fh - 3 * _k, make_colour_rgb(round(130 * _shade), round(136 * _shade), round(146 * _shade)), 0.55);
                var _e0 = 0.75 * _k, _lw = 1.5 * _k;
                dby_k_batch_rect(_fx + _e0 - _lw / 2, _fy + _e0 - _lw / 2, _fw - 1.5 * _k + _lw, _lw, _edge, 0.55);
                dby_k_batch_rect(_fx + _e0 - _lw / 2, _fy + _fh - _e0 - _lw / 2, _fw - 1.5 * _k + _lw, _lw, _edge, 0.55);
                dby_k_batch_rect(_fx + _e0 - _lw / 2, _fy + _e0 + _lw / 2, _lw, _fh - 1.5 * _k - _lw, _edge, 0.55);
                dby_k_batch_rect(_fx + _fw - _e0 - _lw / 2, _fy + _e0 + _lw / 2, _lw, _fh - 1.5 * _k - _lw, _edge, 0.55);
                dby_k_batch_seg(_fx + 2 * _k, _fy + 2.5 * _k, _fx + _fw - 3 * _k, _fy + 2.5 * _k, _k, c_white, 0.18);
                _fx += _fw;
            }
        }
    } else if (_name == "sand") {
        var _pale = make_colour_rgb(255, 240, 200), _brown = make_colour_rgb(120, 90, 40);
        _n = _A / 25;
        for (_i = 0; _i < _n; _i++) {
            var _p = dby_rnd(_r) < 0.5;
            var _sx = _x + dby_rnd(_r) * _w;
            var _sy = _y + dby_rnd(_r) * _h;
            dby_k_batch_rect(_sx, _sy, _k, _k, _p ? _pale : _brown, _p ? 0.4 : 0.25);
        }
        var _rip = make_colour_rgb(150, 115, 60);
        for (var _yy = _y + 6 * _k; _yy < _y + _h; _yy += 9 * _k) {
            var _ox = _x, _oy = _yy + sin((_x / _k) / 13 + _yy / _k) * 1.6 * _k;
            for (var _xx = _x + 6 * _k; _xx <= _x + _w + 6 * _k; _xx += 6 * _k) { var _ny2 = _yy + sin((_xx / _k) / 13 + _yy / _k) * 1.6 * _k; dby_k_batch_seg(_ox, _oy, _xx, _ny2, _k, _rip, 0.35); _ox = _xx; _oy = _ny2; }
        }
    } else if (_name == "puddle") {
        dby_k_batch_end();
        // sky caught in the surface, a muddy rim, rings, petals: a flat blue band did not read as water
        var _skyc = make_colour_rgb(200, 225, 240);
        dby_k_rect_grad(_x, _y, _w, _h, _x, _y, _x + _w, _y, [[0, _skyc, 0], [0.5, _skyc, 0.22], [1, _skyc, 0]]);
        dby_k_batch_begin();
        var _mud = make_colour_rgb(70, 52, 30), _ringc = make_colour_rgb(235, 245, 255);
        dby_k_batch_rect(_x, _y, 6 * _k, _h, _mud, 0.55); dby_k_batch_rect(_x + _w - 6 * _k, _y, 6 * _k, _h, _mud, 0.55);
        for (_i = 0; _i < _A / 900; _i++) {
            var _cx2 = _x + 10 * _k + dby_rnd(_r) * (_w - 20 * _k);
            var _cy2 = _y + dby_rnd(_r) * _h;
            for (var _ring = 1; _ring <= 3; _ring++) dby_course__ring(_cx2, _cy2, _ring * 5 * _k, _ring * 1.8 * _k, _k, _ringc, 0.4 / _ring);
        }
        var _pink = make_colour_rgb(240, 160, 190), _cream = make_colour_rgb(255, 240, 200);
        for (_i = 0; _i < _A / 2500; _i++) {
            var _pk = dby_rnd(_r) < 0.5;
            var _px2 = _x + 8 * _k + dby_rnd(_r) * (_w - 16 * _k);
            var _py2 = _y + dby_rnd(_r) * _h;
            var _pa = dby_rnd(_r) * DBY_ART_TAU;
            dby_k_batch_ellipse(_px2, _py2, 3 * _k, 1.6 * _k, _pa, _pk ? _pink : _cream, 0.85);
        }
        dby_k_batch_rect(_x, _y, _w, 3 * _k, make_colour_rgb(40, 60, 70), 0.35);
        var _glint = make_colour_rgb(220, 240, 255);
        for (_i = 0; _i < _W1 / 30; _i++) {
            var _gx = _x + dby_rnd(_r) * _w;
            var _gy = _y + 6 * _k + dby_rnd(_r) * (_h - 12 * _k);
            var _ga = 0.25 + dby_rnd(_r) * 0.35;
            var _grx = (5 + dby_rnd(_r) * 10) * _k;
            var _gry = (1.5 + dby_rnd(_r) * 2) * _k;
            dby_course__ring(_gx, _gy, _grx, _gry, _k, _glint, _ga);
        }
        for (_i = 0; _i < _W1 / 12; _i++) {
            var _lx = _x + dby_rnd(_r) * _w;
            var _ly = _y + 4 * _k + dby_rnd(_r) * (_h - 8 * _k);
            var _ll = (6 + dby_rnd(_r) * 12) * _k;
            dby_k_batch_rect(_lx, _ly, _ll, _k, c_white, 0.35);
        }
    } else if (_name == "leaf") {
        var _hues = [dby_art__hex("#b8742a"), dby_art__hex("#d49a3a"), dby_art__hex("#8a4a1a"), dby_art__hex("#a8a03a"), dby_art__hex("#c0582a")], _rib = make_colour_rgb(60, 30, 10);
        for (_i = 0; _i < _A / 180; _i++) {
            var _fx2 = _x + dby_rnd(_r) * _w;
            var _fy2 = _y + dby_rnd(_r) * _h;
            var _fa = dby_rnd(_r) * DBY_ART_TAU;
            var _fs = (4 + dby_rnd(_r) * 5) * _k;
            var _hue = _hues[floor(dby_rnd(_r) * 5) mod 5];
            dby_k_batch_ellipse(_fx2, _fy2, _fs, _fs * 0.45, _fa, _hue, 1);
            dby_k_batch_seg(_fx2 - cos(_fa) * _fs, _fy2 - sin(_fa) * _fs, _fx2 + cos(_fa) * _fs, _fy2 + sin(_fa) * _fs, 0.7 * _k, _rib, 0.6);
        }
    } else {
        for (_i = 0; _i < _A / 22; _i++) {
            var _sx2 = _x + dby_rnd(_r) * _w;
            var _sy2 = _y + dby_rnd(_r) * _h;
            var _sr = (0.8 + dby_rnd(_r) * 2.2) * _k;
            var _v = round(110 + dby_rnd(_r) * 90);
            dby_k_batch_ellipse(_sx2, _sy2, _sr, _sr, 0, make_colour_rgb(_v, round(_v * 0.95), round(_v * 0.86)), 1);
            dby_k_batch_ellipse(_sx2 - _sr * 0.3, _sy2 - _sr * 0.3, _sr * 0.35, _sr * 0.35, 0, c_white, 0.25);
        }
    }
    dby_k_batch_end();
    gpu_set_scissor(_sc);
    dby_art__blend_end(_bm);
}

// ---- scenery and the course strip ----------------------------------------------------------------------------------

/// @function dby_course_theme(theme)
/// @description A course theme's colours: {sky: [top, bottom], back, edge, ink} (kitchen, rockery, greenhouse, orchard,
/// mossbank; anything else reads as kitchen). Pure.
function dby_course_theme(_t) {
    switch (_t) {
        case "rockery": return { sky: [dby_art__hex("#cfe0ea"), dby_art__hex("#9fbccc")], back: dby_art__hex("#6f8a6a"), edge: dby_art__hex("#4a4a40"), ink: dby_art__hex("#26302a") };
        case "greenhouse": return { sky: [dby_art__hex("#f6f0c8"), dby_art__hex("#dfe8b0")], back: dby_art__hex("#b8c898"), edge: dby_art__hex("#5a4a34"), ink: dby_art__hex("#2e3a1c") };
        case "orchard": return { sky: [dby_art__hex("#bfe0f4"), dby_art__hex("#e6f0d0")], back: dby_art__hex("#7aa04a"), edge: dby_art__hex("#4a3a1e"), ink: dby_art__hex("#24300f") };
        case "mossbank": return { sky: [dby_art__hex("#a8c8a0"), dby_art__hex("#6f9a70")], back: dby_art__hex("#2f5a34"), edge: dby_art__hex("#1e2e1a"), ink: dby_art__hex("#12200f") };
    }
    return { sky: [dby_art__hex("#f4dcb0"), dby_art__hex("#e8b98a")], back: dby_art__hex("#9a4a2c"), edge: dby_art__hex("#5a3a22"), ink: dby_art__hex("#3a2414") };
}

/// @function dby_course__radial_ellipse(cx, cy, rx, ry, fx, fy, r0, gx, gy, r1, c0, c1)
/// @description A filled ellipse lit by the canvas two-circle radial gradient (c0 at the focus circle, c1 at the outer). Internal.
function dby_course__radial_ellipse(_cx, _cy, _rx, _ry, _fx, _fy, _r0, _gx, _gy, _r1, _c0, _c1) {
    var _st = [[0, _c0, 1], [1, _c1, 1]], _K = 5, _A = 24;
    draw_primitive_begin(pr_trianglelist);
    for (var _k = 0; _k < _K; _k++) for (var _j = 0; _j < _A; _j++) {
        var _a0 = _j / _A * DBY_ART_TAU, _a1 = (_j + 1) / _A * DBY_ART_TAU, _p0 = _k / _K, _p1 = (_k + 1) / _K;
        var _q = [[_cx + cos(_a0) * _rx * _p0, _cy + sin(_a0) * _ry * _p0], [_cx + cos(_a1) * _rx * _p0, _cy + sin(_a1) * _ry * _p0], [_cx + cos(_a0) * _rx * _p1, _cy + sin(_a0) * _ry * _p1], [_cx + cos(_a1) * _rx * _p1, _cy + sin(_a1) * _ry * _p1]];
        var _g = array_create(4);
        for (var _m = 0; _m < 4; _m++) _g[_m] = dby_k_grad_at(_st, dby_art__radial_t(_q[_m][0], _q[_m][1], _fx, _fy, _r0, _gx, _gy, _r1));
        draw_vertex_colour(_q[0][0], _q[0][1], _g[0][0], 1); draw_vertex_colour(_q[1][0], _q[1][1], _g[1][0], 1); draw_vertex_colour(_q[2][0], _q[2][1], _g[2][0], 1);
        draw_vertex_colour(_q[1][0], _q[1][1], _g[1][0], 1); draw_vertex_colour(_q[3][0], _q[3][1], _g[3][0], 1); draw_vertex_colour(_q[2][0], _q[2][1], _g[2][0], 1);
    }
    draw_primitive_end();
}

/// @function dby_course_scenery(theme, x0, w, top, h, rng)
/// @description The scenery band above the lanes, one picture per theme repeated along the strip: a kitchen-garden wall
/// with potted herbs, a rockery with flowering stones, a greenhouse bench of tomatoes, an orchard, a mossy bank of ferns.
/// Draws the whole band now; it is dby_course_scenery_layout + dby_course_scenery_draw over its full width.
function dby_course_scenery(_theme, _x0, _w, _top, _h, _r) {
    dby_course_scenery_draw(dby_course_scenery_layout(_theme, _x0, _w, _top, _h, _r), _x0, _x0 + _w);
}

/// @function dby_course_scenery_layout(theme, x0, w, top, h, rng)
/// @description Every random choice the scenery band makes, drawn from `rng` in the order the whole-band draw makes them,
/// and nothing drawn. A layout draws in pieces (dby_course_scenery_draw over any x window) and the pieces meet exactly,
/// because every piece reads the same choices: what lets a long course be baked a tile at a time.
/// ⛔ MEASURED 2026-09-27 (2024.14.4.268, VM): the rockery band of a 3,900 px course cost 305 ms in one call.
function dby_course_scenery_layout(_theme, _x0, _w, _top, _h, _r) {
    // a refusal is an EMPTY layout (it draws the sky and nothing else), never a crash
    if (!is_numeric(_x0) || !is_numeric(_w) || !is_numeric(_top) || !is_numeric(_h) || _w < 0 || _w > 100000 || !is_struct(_r) || !variable_struct_exists(_r, "a"))
        return { theme: is_string(_theme) ? _theme : "kitchen", x0: is_numeric(_x0) ? _x0 : 0, w: 0, top: is_numeric(_top) ? _top : 0, h: is_numeric(_h) ? _h : 0, base: 0, a: [], b: [], c: [] };
    var _L = { theme: _theme, x0: _x0, w: _w, top: _top, h: _h, base: _top + _h, a: [], b: [], c: [] }, _x, _i;
    var _base = _L.base;
    if (_theme == "kitchen") {
        // a: brick rows [y, x0 of the row, [light?...]]; b: pots [x, labelled?]
        for (var _by = _top + _h - 34; _by < _base; _by += 8) {
            var _row = [_by, _x0 + ((_by / 8) mod 2) * 9, []];
            _x = _row[1];
            while (_x < _x0 + _w) { array_push(_row[2], dby_rnd(_r) < 0.5); _x += 18; }
            array_push(_L.a, _row);
        }
        _x = _x0 + 40;
        while (_x < _x0 + _w) { var _lab = dby_rnd(_r) < 0.5; array_push(_L.b, [_x, _lab]); _x += 110 + dby_rnd(_r) * 60; }
    } else if (_theme == "rockery") {
        // a: the hill's points; b: stones [x, radius, value, [[pink?, fx, fy] x5]]
        for (_x = _x0; _x <= _x0 + _w; _x += 20) { var _hy = _base - 30 - sin(_x / 70) * 8 - dby_rnd(_r) * 4; array_push(_L.a, [_x, _hy]); }
        _x = _x0 + 20;
        while (_x < _x0 + _w) {
            var _sr = 10 + dby_rnd(_r) * 14;
            var _sv = round(130 + dby_rnd(_r) * 50);
            var _fl = [];
            for (_i = 0; _i < 5; _i++) {
                var _pk = dby_rnd(_r) < 0.5;
                var _fxp = _x + (dby_rnd(_r) - 0.5) * _sr * 2;
                var _fyp = _base - _sr * 1.2 - dby_rnd(_r) * 6;
                array_push(_fl, [_pk, _fxp, _fyp]);
            }
            array_push(_L.b, [_x, _sr, _sv, _fl]);
            _x += 26 + dby_rnd(_r) * 30;
        }
    } else if (_theme == "greenhouse") {
        _x = _x0 + 30;
        while (_x < _x0 + _w) { array_push(_L.b, _x); _x += 90 + dby_rnd(_r) * 40; }
    } else if (_theme == "orchard") {
        // b: trees [x, [[ax, ay] x6], [wx x3]]; c: grass blades [x, dark?, dx, h]
        _x = _x0 + 50;
        while (_x < _x0 + _w) {
            var _ap = [], _wf = [];
            for (_i = 0; _i < 6; _i++) { var _ax = _x + (dby_rnd(_r) - 0.5) * 100; var _ay = _top + 4 + dby_rnd(_r) * 18; array_push(_ap, [_ax, _ay]); }
            for (_i = 0; _i < 3; _i++) array_push(_wf, _x + 20 + _i * 14 + dby_rnd(_r) * 8);
            array_push(_L.b, [_x, _ap, _wf]);
            _x += 170 + dby_rnd(_r) * 60;
        }
        for (_x = _x0; _x < _x0 + _w; _x += 7) {
            var _gc = dby_rnd(_r) < 0.5;
            var _gdx = (dby_rnd(_r) - 0.5) * 4;
            var _gh = 5 + dby_rnd(_r) * 7;
            array_push(_L.c, [_x, _gc, _gdx, _gh]);
        }
    } else {
        // a: the bank's points; b: fern clumps [x, mushroom?]
        for (_x = _x0; _x <= _x0 + _w; _x += 16) { var _ky = _base - 24 - sin(_x / 40) * 6 - dby_rnd(_r) * 5; array_push(_L.a, [_x, _ky]); }
        _x = _x0 + 20;
        while (_x < _x0 + _w) { var _mu = dby_rnd(_r) < 0.55; array_push(_L.b, [_x, _mu]); _x += 60 + dby_rnd(_r) * 50; }
    }
    return _L;
}

/// @function dby_course__band(pts, wx0, wx1, base)
/// @description The part of a hill or bank outline over [wx0, wx1], closed down to the base line. Internal.
function dby_course__band(_pts, _wx0, _wx1, _base) {
    var _o = [], _n = array_length(_pts);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _pts[_i], _prev = (_i > 0) ? _pts[_i - 1][0] : -1000000, _next = (_i < _n - 1) ? _pts[_i + 1][0] : 1000000;
        if (_next >= _wx0 && _prev <= _wx1) array_push(_o, _p);
    }
    if (array_length(_o) < 2) return [];
    array_push(_o, [_o[array_length(_o) - 1][0], _base]); array_push(_o, [_o[0][0], _base]);
    return _o;
}

/// @function dby_course_scenery_draw(layout, wx0, wx1)
/// @description Draw the part of a scenery layout that falls over [wx0, wx1] (anything reaching into the window is drawn
/// whole: the target's own edge clips it, and the neighbouring piece draws the rest from the same choices).
function dby_course_scenery_draw(_L, _wx0, _wx1) {
    if (!is_struct(_L) || !variable_struct_exists(_L, "b") || !is_array(_L.b) || !is_numeric(_wx0) || !is_numeric(_wx1)) return;
    var _theme = _L.theme, _top = _L.top, _h = _L.h, _base = _L.base, _T = dby_course_theme(_theme), _i, _j, _x, _bm = dby_art__blend_begin();
    var _a = max(_L.x0, _wx0), _b = min(_L.x0 + _L.w, _wx1);
    if (_b <= _a) { dby_art__blend_end(_bm); return; }
    dby_k_rect_grad(_a, _top, _b - _a, _h, _a, _top, _a, _top + _h, [[0, _T.sky[0], 1], [1, _T.sky[1], 1]]);
    if (_theme == "kitchen") {
        var _b1 = dby_art__hex("#a8543a"), _b2 = dby_art__hex("#94452e");
        dby_k_batch_begin();
        for (_i = 0; _i < array_length(_L.a); _i++) {
            var _row = _L.a[_i], _cols = _row[2];
            var _j0 = max(0, floor((_a - 18 - _row[1]) / 18)), _j1 = min(array_length(_cols) - 1, ceil((_b - _row[1]) / 18));
            for (_j = _j0; _j <= _j1; _j++) dby_k_batch_rect(_row[1] + _j * 18, _row[0], 16, 6, _cols[_j] ? _b1 : _b2, 1);
        }
        dby_k_batch_end();
        var _leafc = [dby_art__hex("#6fae3a"), dby_art__hex("#8ac84a"), dby_art__hex("#4f8a2a")];
        for (_i = 0; _i < array_length(_L.b); _i++) {
            _x = _L.b[_i][0];
            if (_x + 40 < _a || _x - 40 > _b) continue;
            dby_k_fill_rings([[[_x - 16, _base - 26], [_x + 16, _base - 26], [_x + 11, _base], [_x - 11, _base]]], dby_art__hex("#c0643a"), 1);
            dby_k_rect(_x - 18, _base - 30, 36, 6, dby_art__hex("#d8784a"));
            for (_j = 0; _j < 7; _j++) dby_k_ellipse(_x + (_j - 3) * 5, _base - 34 - (_j mod 2) * 6, 7, 10, (_j - 3) * 0.3, _leafc[_j mod 3], 1);
            if (_L.b[_i][1]) { dby_k_rect(_x + 20, _base - 40, 12, 22, dby_art__hex("#e8d8b0")); dby_k_rect(_x + 25, _base - 18, 2, 18, dby_art__hex("#5a3a22")); }
        }
    } else if (_theme == "rockery") {
        var _hill = dby_course__band(_L.a, _a, _b, _base);
        if (array_length(_hill) >= 3) dby_k_fill_rings([_hill], dby_art__hex("#5f7a58"), 1);
        for (_i = 0; _i < array_length(_L.b); _i++) {
            var _st = _L.b[_i], _sr = _st[1], _sv = _st[2];
            _x = _st[0];
            if (_x + _sr * 2.5 < _a || _x - _sr * 2.5 > _b) continue;
            dby_course__radial_ellipse(_x, _base - _sr * 0.55, _sr * 1.3, _sr * 0.8, _x - _sr * 0.4, _base - _sr * 0.9, 2, _x, _base - _sr * 0.5, _sr * 1.2,
                make_colour_rgb(_sv + 50, _sv + 50, _sv + 45), make_colour_rgb(_sv - 60, _sv - 60, _sv - 55));
            for (_j = 0; _j < 5; _j++) { var _f = _st[3][_j]; dby_k_ellipse(_f[1], _f[2], 1.8, 1.8, 0, _f[0] ? dby_art__hex("#f08ab0") : dby_art__hex("#fff4f8"), 1); }
        }
    } else if (_theme == "greenhouse") {
        dby_k_rect(_a, _top, _b - _a, _h - 22, make_colour_rgb(255, 255, 240), 0.35);
        var _mull = dby_art__hex("#f6f4ea");
        for (_x = _L.x0 + ceil((_a - 2 - _L.x0) / 64) * 64; _x < min(_b + 2, _L.x0 + _L.w); _x += 64) dby_k_seg(_x, _top, _x, _base - 22, 3, _mull, 1);
        dby_k_seg(_a, _top + (_h - 22) / 2, _b, _top + (_h - 22) / 2, 2, _mull, 1);
        dby_k_rect(_a, _base - 22, _b - _a, 22, dby_art__hex("#8a6a44")); dby_k_rect(_a, _base - 22, _b - _a, 3, dby_art__hex("#6a4e30"));
        for (_i = 0; _i < array_length(_L.b); _i++) {
            _x = _L.b[_i];
            if (_x + 20 < _a || _x - 20 > _b) continue;
            dby_k_rect(_x - 10, _base - 34, 20, 13, dby_art__hex("#b8603a"));
            var _stem = [[_x, _base - 34]];
            dby_art__quad(_stem, _x, _base - 34, _x - 8, _base - 50, _x + 2, _base - 62, 10);
            dby_k_polyline(_stem, 2, dby_art__hex("#4a7a2a"), 1);
            for (_j = 0; _j < 4; _j++) dby_k_ellipse(_x - 6 + _j * 4, _base - 44 - _j * 4, 3.4, 3.4, 0, (_j mod 2) ? dby_art__hex("#d8402a") : dby_art__hex("#e86a3a"), 1);
            for (_j = 0; _j < 4; _j++) dby_k_ellipse(_x + ((_j mod 2) ? 7 : -7), _base - 40 - _j * 5, 5, 2.4, (_j mod 2) ? 0.5 : -0.5, dby_art__hex("#5a9a3a"), 1);
        }
    } else if (_theme == "orchard") {
        dby_k_rect(_a, _base - 18, _b - _a, 18, dby_art__hex("#6f9a3a"));
        for (_i = 0; _i < array_length(_L.b); _i++) {
            var _tr = _L.b[_i];
            _x = _tr[0];
            if (_x + 110 < _a || _x - 110 > _b) continue;
            dby_k_rect(_x - 7, _top + 10, 14, _h - 16, dby_art__hex("#5a3a1e")); dby_k_rect(_x - 7, _top + 10, 4, _h - 16, dby_art__hex("#4a2e16"));
            dby_k_ellipse(_x, _top + 6, 60, 22, 0, dby_art__hex("#4f7a2a"), 1);
            for (_j = 0; _j < 6; _j++) dby_k_ellipse(_tr[1][_j][0], _tr[1][_j][1], 3.5, 3.5, 0, dby_art__hex("#c8302a"), 1);
            for (_j = 0; _j < 3; _j++) {
                dby_k_ellipse(_tr[2][_j], _base - 6, 4, 4, 0, dby_art__hex("#b8282a"), 1);
                dby_k_ellipse(_x + 19 + _j * 14, _base - 7.5, 1.2, 1.2, 0, c_white, 0.5);
            }
        }
        var _g1 = dby_art__hex("#86b04a"), _g2 = dby_art__hex("#5a8a2a");
        dby_k_batch_begin();
        for (_i = 0; _i < array_length(_L.c); _i++) {
            var _gb = _L.c[_i];
            if (_gb[0] + 4 < _a || _gb[0] - 4 > _b) continue;
            dby_k_batch_seg(_gb[0], _base, _gb[0] + _gb[2], _base - _gb[3], 1, _gb[1] ? _g1 : _g2, 1);
        }
        dby_k_batch_end();
    } else {
        var _bank = dby_course__band(_L.a, _a, _b, _base);
        if (array_length(_bank) >= 3) dby_k_fill_rings([_bank], dby_art__hex("#23462a"), 1);
        var _fern = dby_art__hex("#4f8a3a");
        for (_i = 0; _i < array_length(_L.b); _i++) {
            _x = _L.b[_i][0];
            if (_x + 50 < _a || _x - 50 > _b) continue;
            for (var _fr = -3; _fr <= 3; _fr++) { var _fp = [[_x, _base - 10]]; dby_art__quad(_fp, _x, _base - 10, _x + _fr * 8, _base - 36, _x + _fr * 14, _base - 30 + abs(_fr) * 4, 10); dby_k_polyline(_fp, 1.6, _fern, 1); }
            if (_L.b[_i][1]) {
                var _mx = _x + 26, _cap = [];
                dby_k_rect(_mx - 2, _base - 16, 4, 12, dby_art__hex("#efe6d0"));
                for (_j = 0; _j <= 12; _j++) { var _ca = pi + _j / 12 * pi; array_push(_cap, [_mx + cos(_ca) * 9, _base - 16 + sin(_ca) * 6]); }
                dby_k_fill_rings([_cap], dby_art__hex("#c8282a"), 1);
                for (_j = 0; _j < 3; _j++) dby_k_ellipse(_mx - 4 + _j * 4, _base - 19 + (_j mod 2), 1.2, 1.2, 0, c_white, 1);
            }
        }
    }
    dby_k_rect(_a, _base - 3, _b - _a, 3, c_black, 0.25);
    dby_art__blend_end(_bm);
}

/// @function dby_course_lettuce(x, y, s)
/// @description The prize: a lettuce past the winning post, at scale s.
function dby_course_lettuce(_x, _y, _s) {
    if (!is_numeric(_x) || !is_numeric(_y) || !is_numeric(_s) || _s <= 0 || _s > 100) return;
    for (var _i = 0; _i < 7; _i++) { var _a = _i / 7 * DBY_ART_TAU; dby_k_ellipse(_x + cos(_a) * 8 * _s, _y + sin(_a) * 4 * _s, 11 * _s, 6 * _s, _a, (_i mod 2) ? dby_art__hex("#8ac84a") : dby_art__hex("#6fae3a"), 1); }
    dby_k_ellipse(_x, _y - _s, 7 * _s, 4 * _s, 0, dby_art__hex("#c8ec8a"), 1);
    dby_k_seg(_x - 6 * _s, _y, _x + 6 * _s, _y - _s, 0.8, make_colour_rgb(40, 80, 20), 0.5);
}

/// @function dby_course__fraction(x, y, num, den, colour)
/// @description A small vulgar fraction centred on (x, y) (the fonts carry ASCII only, so no fraction glyphs). Internal.
/// ⚠️ At 8 px single-struck the first strips' fractions were barely legible (LOOKED AT 2026-09-27): 10 px, double-struck.
function dby_course__fraction(_x, _y, _n, _d, _col) {
    for (var _b = -0.3; _b <= 0.3; _b += 0.6) {
        dby_k_text(_x - 3.2 + _b, _y - 2.6, string(_n), 10, _col, fa_center, fa_middle, fnt_derby);
        dby_k_text(_x + 3.4 + _b, _y + 3.2, string(_d), 10, _col, fa_center, fa_middle, fnt_derby);
    }
    dby_k_seg(_x - 4, _y + 4.5, _x + 4, _y - 4.5, 1.3, _col, 1);
}

/// @function dby_course_strip(card, geo)
/// @description Draw a card's course as one long strip: the scenery band, one lane per runner over each section's
/// surface, lane strings and pegs, distance posts, the start, the winning post and a lettuce in every lane.
/// geo = {w, h, top (scenery height), lane_h, start_x, px (pixels per race unit)}. Draw it ONCE into a surface.
function dby_course_strip(_card, _g) {
    if (!is_struct(_card) || !variable_struct_exists(_card, "course") || !variable_struct_exists(_card, "field") || !is_struct(_g) || !variable_struct_exists(_g, "lane_h")) return;
    var _c = _card.course, _n = array_length(_card.field), _T = dby_course_theme(_c.theme), _r = dby_rng((_card.race_seed ^ $C0) & $FFFFFFFF), _i, _s;
    var _bm = dby_art__blend_begin();
    dby_k_rect(0, 0, _g.w, _g.h, _T.edge);
    dby_course_scenery(_c.theme, 0, _g.w, 0, _g.top, _r);
    var _lt = _g.top, _lb = _g.top + _n * _g.lane_h, _secs = _c.sections, _ns = array_length(_secs);
    for (_s = 0; _s < _ns; _s++) {
        var _sx = (_s == 0) ? 0 : _g.start_x + _secs[_s].from * _g.px, _ex = (_s == _ns - 1) ? _g.w : _g.start_x + _secs[_s].to * _g.px;
        dby_course_surface(_secs[_s].surface, _sx, _lt, _ex - _sx, _lb - _lt, _r, 1);
        if (_s > 0) dby_k_rect(_sx - 1, _lt, 2, _lb - _lt, c_black, 0.18);
    }
    var _peg = dby_art__hex("#6a4a2a"), _pegt = dby_art__hex("#a8804a");
    for (_i = 0; _i <= _n; _i++) {
        var _ly = _lt + _i * _g.lane_h;
        dby_k_seg(0, _ly + 0.5, _g.w, _ly + 0.5, 1.2, make_colour_rgb(250, 246, 230), 0.8);
        for (var _px = _g.start_x mod 120; _px < _g.w; _px += 120) { dby_k_rect(_px - 1.5, _ly - 4, 3, 7, _peg); dby_k_rect(_px - 1.5, _ly - 4, 3, 2, _pegt); }
    }
    var _cream = dby_art__hex("#f4efe2"), _red = dby_art__hex("#c8202a"), _dark = dby_art__hex("#1a1208");
    for (var _k = 0; _k < 3; _k++) {
        var _dx = _g.start_x + (_k + 1) * 0.25 * DBY_LEN * _g.px;
        dby_k_rect(_dx - 2, _lt - 30, 4, 30, _cream); dby_k_rect(_dx - 2, _lt - 30, 4, 6, _red);
        dby_k_ellipse(_dx, _lt - 36, 10, 10, 0, _cream, 1); dby_k_polyline(dby_k_ellipse_ring(_dx, _lt - 36, 10, 10, 0, 32), 1, _dark, 1, true);
        dby_course__fraction(_dx, _lt - 35, 3 - _k, 4, _dark);
    }
    dby_k_rect(_g.start_x - 2, _lt, 3, _lb - _lt, make_colour_rgb(255, 255, 250), 0.9);
    dby_k_rect(_g.start_x - 3, _lt - 44, 3, 44, dby_art__hex("#5a3a1e"));
    dby_k_fill_rings([[[_g.start_x, _lt - 44], [_g.start_x + 20, _lt - 38], [_g.start_x, _lt - 32]]], _red, 1);
    var _fx = _g.start_x + DBY_LEN * _g.px, _light = dby_art__hex("#fbf8f0");
    for (var _q = 0; _q < ceil((_lb - _lt) / 6); _q++) { dby_k_rect(_fx - 3, _lt + _q * 6, 3, 6, (_q mod 2) ? _dark : _light); dby_k_rect(_fx, _lt + _q * 6, 3, 6, (_q mod 2) ? _light : _dark); }
    // a fixed 66 px post ran its disc under the header when 8 lanes left a short scenery band (MZ, found by looking)
    var _ph = max(30, min(60, _lt - 30)), _dy = _lt - _ph - 6;
    for (var _pq = 0; _pq < 6; _pq++) dby_k_rect(_fx - 3, _lt - _ph + _pq * _ph / 6, 6, _ph / 6 + 0.5, (_pq mod 2) ? _red : _light);
    dby_k_ellipse(_fx, _dy, 13, 13, 0, _light, 1); dby_k_ellipse(_fx, _dy, 8, 8, 0, _red, 1);
    dby_k_polyline(dby_k_ellipse_ring(_fx, _dy, 13, 13, 0, 40), 1.2, _dark, 1, true);
    for (_i = 0; _i < _n; _i++) dby_course_lettuce(_fx + 46, _lt + (_i + 0.55) * _g.lane_h, _g.lane_h * 0.018 + 0.2);
    dby_k_rect(0, _lb, _g.w, _g.h - _lb, _T.edge); dby_k_rect(0, _lb, _g.w, 2, c_white, 0.12);
    dby_art__blend_end(_bm);
}

// ---- seamless surface textures and the course strip in pieces -----------------------------------------------------
// ⛔ MEASURED 2026-09-27 (2024.14.4.268, VM): one 3,900 px course strip drawn mark by mark cost 1,352 ms, gravel alone
// 623 ms per 1024 x 480 px. The cost is the NUMBER OF MARKS (tens of thousands), not the pixels, so a race view cannot
// draw its ground per race. Each surface is drawn ONCE as a seamless DBY_TEX-square tile of marks (~1/8 of that area)
// and a course is tiled from those; the scenery is laid out once and drawn a window at a time.

#macro DBY_TEX 250

/// @function dby_course__wrap_ellipse(cx, cy, rx, ry, rot, colour, alpha, T, k)
/// @description A batch ellipse on a T-square tile at supersample k, drawn again across every edge it crosses. Internal.
function dby_course__wrap_ellipse(_cx, _cy, _rx, _ry, _rot, _col, _a, _T, _k) {
    var _e = max(_rx, _ry);
    for (var _wy = -1; _wy <= 1; _wy++) {
        var _yy = _cy + _wy * _T;
        if (_yy + _e < 0 || _yy - _e > _T) continue;
        for (var _wx = -1; _wx <= 1; _wx++) {
            var _xx = _cx + _wx * _T;
            if (_xx + _e < 0 || _xx - _e > _T) continue;
            dby_k_batch_ellipse(_xx * _k, _yy * _k, _rx * _k, _ry * _k, _rot, _col, _a);
        }
    }
}

/// @function dby_course__wrap_seg(x1, y1, x2, y2, w, colour, alpha, T, k)
/// @description A batch stroke on a T-square tile, drawn again across every edge it crosses. Internal.
function dby_course__wrap_seg(_x1, _y1, _x2, _y2, _w, _col, _a, _T, _k) {
    var _lx = min(_x1, _x2) - _w, _hx = max(_x1, _x2) + _w, _ly = min(_y1, _y2) - _w, _hy = max(_y1, _y2) + _w;
    for (var _wy = -1; _wy <= 1; _wy++) {
        var _oy = _wy * _T;
        if (_hy + _oy < 0 || _ly + _oy > _T) continue;
        for (var _wx = -1; _wx <= 1; _wx++) {
            var _ox = _wx * _T;
            if (_hx + _ox < 0 || _lx + _ox > _T) continue;
            dby_k_batch_seg((_x1 + _ox) * _k, (_y1 + _oy) * _k, (_x2 + _ox) * _k, (_y2 + _oy) * _k, _w * _k, _col, _a);
        }
    }
}

/// @function dby_course__wrap_ring(cx, cy, rx, ry, colour, alpha, T, k)
/// @description An ellipse OUTLINE one unit wide on a T-square tile, drawn again across every edge it crosses. Internal.
function dby_course__wrap_ring(_cx, _cy, _rx, _ry, _col, _a, _T, _k) {
    var _e = max(_rx, _ry) + 1;
    for (var _wy = -1; _wy <= 1; _wy++) {
        var _yy = _cy + _wy * _T;
        if (_yy + _e < 0 || _yy - _e > _T) continue;
        for (var _wx = -1; _wx <= 1; _wx++) {
            var _xx = _cx + _wx * _T;
            if (_xx + _e < 0 || _xx - _e > _T) continue;
            dby_course__ring(_xx * _k, _yy * _k, _rx * _k, _ry * _k, _k, _col, _a);
        }
    }
}

/// @function dby_course_texture(name, [k], [seed])
/// @description Draw one SEAMLESS DBY_TEX-square tile of a surface's marks (moss, slate, sand, puddle, leaf, gravel) at
/// (0, 0) at supersample k, on a TRANSPARENT target: a mark that crosses an edge is drawn again on the opposite side,
/// slate rows close on the tile and sand ripples run whole periods, so the tile repeats with no seam in either direction.
/// The ground gradient is NOT in the tile (it spans a section's whole height, dby_course__base); the result is
/// PREMULTIPLIED alpha, so draw it with gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha). Densities are the per-pixel
/// densities of dby_course_surface (its per-WIDTH counts are taken over a 400 px lane block).
function dby_course_texture(_name, _k = 2, _seed = 0) {
    if (!is_numeric(_k) || _k <= 0 || _k > 8) return;
    var _T = DBY_TEX, _A = _T * _T, _HR = 400, _i;
    var _r = dby_rng(dby_mix(floor(is_numeric(_seed) ? _seed : 0) & $FFFFFFFF, dby_hash(string(_name))));
    var _bm = dby_art__blend_begin();
    dby_k_batch_begin();
    if (_name == "moss") {
        var _lite = make_colour_rgb(170, 210, 110), _dark = make_colour_rgb(20, 50, 10);
        for (_i = 0; _i < _A / 40; _i++) {
            var _light = dby_rnd(_r) < 0.5;
            var _mx = dby_rnd(_r) * _T;
            var _my = dby_rnd(_r) * _T;
            var _mr = 0.8 + dby_rnd(_r) * 1.8;
            dby_course__wrap_ellipse(_mx, _my, _mr, _mr, 0, _light ? _lite : _dark, _light ? 0.35 : 0.3, _T, _k);
        }
        var _tuft = make_colour_rgb(190, 230, 120);
        for (_i = 0; _i < _A / (18 * _HR); _i++) {
            var _tx = dby_rnd(_r) * _T;
            var _ty = dby_rnd(_r) * _T;
            for (var _q = -2; _q <= 2; _q++) { var _tl = 4 + dby_rnd(_r) * 3; dby_course__wrap_seg(_tx, _ty, _tx + _q * 1.5, _ty - _tl, 1, _tuft, 0.5, _T, _k); }
        }
    } else if (_name == "slate") {
        // ten rows of 25: each row's flags are laid from a random offset and the last flag CLOSES the row on the tile,
        // and the first (which starts left of the edge) is drawn again one tile to the right, so every row wraps
        var _fh = _T / 10, _edge = make_colour_rgb(30, 32, 38);
        for (var _row = 0; _row < 10; _row++) {
            var _off = -dby_rnd(_r) * 30, _fx = _off, _fy = _row * _fh;
            while (_fx < _off + _T - 0.5) {
                var _fw = 34 + dby_rnd(_r) * 34;
                var _rest = _off + _T - _fx;
                if (_rest - _fw < 30) _fw = _rest;
                var _shade = 0.85 + dby_rnd(_r) * 0.3;
                var _fc = make_colour_rgb(round(130 * _shade), round(136 * _shade), round(146 * _shade));
                for (var _cp = 0; _cp <= 1; _cp++) {
                    if (_cp == 1 && _fx >= 0) break;
                    var _gx = _fx + _cp * _T, _e0 = 0.75, _lw = 1.5;
                    dby_k_batch_rect((_gx + 1.5) * _k, (_fy + 1.5) * _k, (_fw - 3) * _k, (_fh - 3) * _k, _fc, 0.55);
                    dby_k_batch_rect((_gx + _e0 - _lw / 2) * _k, (_fy + _e0 - _lw / 2) * _k, (_fw - 1.5 + _lw) * _k, _lw * _k, _edge, 0.55);
                    dby_k_batch_rect((_gx + _e0 - _lw / 2) * _k, (_fy + _fh - _e0 - _lw / 2) * _k, (_fw - 1.5 + _lw) * _k, _lw * _k, _edge, 0.55);
                    dby_k_batch_rect((_gx + _e0 - _lw / 2) * _k, (_fy + _e0 + _lw / 2) * _k, _lw * _k, (_fh - 1.5 - _lw) * _k, _edge, 0.55);
                    dby_k_batch_rect((_gx + _fw - _e0 - _lw / 2) * _k, (_fy + _e0 + _lw / 2) * _k, _lw * _k, (_fh - 1.5 - _lw) * _k, _edge, 0.55);
                    dby_k_batch_seg((_gx + 2) * _k, (_fy + 2.5) * _k, (_gx + _fw - 3) * _k, (_fy + 2.5) * _k, _k, c_white, 0.18);
                }
                _fx += _fw;
            }
        }
    } else if (_name == "sand") {
        var _pale = make_colour_rgb(255, 240, 200), _brown = make_colour_rgb(120, 90, 40);
        for (_i = 0; _i < _A / 25; _i++) {
            var _p = dby_rnd(_r) < 0.5;
            var _sx = dby_rnd(_r) * _T;
            var _sy = dby_rnd(_r) * _T;
            dby_k_batch_rect(_sx * _k, _sy * _k, _k, _k, _p ? _pale : _brown, _p ? 0.4 : 0.25);
        }
        // ripples every T/28 (~9) in y, periodic in x with period T/3 (~83; the surface's own is 2 pi x 13 = 82), sampled
        // T/42 (~6) apart, so a row meets its own start across the edge
        var _rip = make_colour_rgb(150, 115, 60), _per = _T / 3, _stp = _T / 42;
        for (var _j = 0; _j < 28; _j++) {
            var _yy = 6 + _j * _T / 28, _ox = -_stp, _oy = _yy + sin(2 * pi * _ox / _per + _yy) * 1.6;
            for (var _xx = 0; _xx <= _T + _stp + 0.001; _xx += _stp) {
                var _ny2 = _yy + sin(2 * pi * _xx / _per + _yy) * 1.6;
                dby_k_batch_seg(_ox * _k, _oy * _k, _xx * _k, _ny2 * _k, _k, _rip, 0.35);
                _ox = _xx; _oy = _ny2;
            }
        }
    } else if (_name == "puddle") {
        var _ringc = make_colour_rgb(235, 245, 255);
        for (_i = 0; _i < _A / 900; _i++) {
            var _cx2 = dby_rnd(_r) * _T;
            var _cy2 = dby_rnd(_r) * _T;
            for (var _ring = 1; _ring <= 3; _ring++) dby_course__wrap_ring(_cx2, _cy2, _ring * 5, _ring * 1.8, _ringc, 0.4 / _ring, _T, _k);
        }
        var _pink = make_colour_rgb(240, 160, 190), _cream = make_colour_rgb(255, 240, 200);
        for (_i = 0; _i < _A / 2500; _i++) {
            var _pk = dby_rnd(_r) < 0.5;
            var _px2 = dby_rnd(_r) * _T;
            var _py2 = dby_rnd(_r) * _T;
            var _pa = dby_rnd(_r) * DBY_ART_TAU;
            dby_course__wrap_ellipse(_px2, _py2, 3, 1.6, _pa, _pk ? _pink : _cream, 0.85, _T, _k);
        }
        var _glint = make_colour_rgb(220, 240, 255);
        for (_i = 0; _i < _A / (30 * _HR); _i++) {
            var _gx2 = dby_rnd(_r) * _T;
            var _gy2 = dby_rnd(_r) * _T;
            var _ga = 0.25 + dby_rnd(_r) * 0.35;
            var _grx = 5 + dby_rnd(_r) * 10;
            var _gry = 1.5 + dby_rnd(_r) * 2;
            dby_course__wrap_ring(_gx2, _gy2, _grx, _gry, _glint, _ga, _T, _k);
        }
        for (_i = 0; _i < _A / (12 * _HR); _i++) {
            var _lx = dby_rnd(_r) * _T;
            var _ly = dby_rnd(_r) * _T;
            var _ll = 6 + dby_rnd(_r) * 12;
            dby_course__wrap_seg(_lx, _ly + 0.5, _lx + _ll, _ly + 0.5, 1, c_white, 0.35, _T, _k);
        }
    } else if (_name == "leaf") {
        var _hues = [dby_art__hex("#b8742a"), dby_art__hex("#d49a3a"), dby_art__hex("#8a4a1a"), dby_art__hex("#a8a03a"), dby_art__hex("#c0582a")], _rib = make_colour_rgb(60, 30, 10);
        for (_i = 0; _i < _A / 180; _i++) {
            var _fx2 = dby_rnd(_r) * _T;
            var _fy2 = dby_rnd(_r) * _T;
            var _fa = dby_rnd(_r) * DBY_ART_TAU;
            var _fs = 4 + dby_rnd(_r) * 5;
            var _hue = _hues[floor(dby_rnd(_r) * 5) mod 5];
            dby_course__wrap_ellipse(_fx2, _fy2, _fs, _fs * 0.45, _fa, _hue, 1, _T, _k);
            dby_course__wrap_seg(_fx2 - cos(_fa) * _fs, _fy2 - sin(_fa) * _fs, _fx2 + cos(_fa) * _fs, _fy2 + sin(_fa) * _fs, 0.7, _rib, 0.6, _T, _k);
        }
    } else if (_name == "gravel") {
        for (_i = 0; _i < _A / 22; _i++) {
            var _sx3 = dby_rnd(_r) * _T;
            var _sy3 = dby_rnd(_r) * _T;
            var _sr = 0.8 + dby_rnd(_r) * 2.2;
            var _v = round(110 + dby_rnd(_r) * 90);
            dby_course__wrap_ellipse(_sx3, _sy3, _sr, _sr, 0, make_colour_rgb(_v, round(_v * 0.95), round(_v * 0.86)), 1, _T, _k);
            dby_course__wrap_ellipse(_sx3 - _sr * 0.3, _sy3 - _sr * 0.3, _sr * 0.35, _sr * 0.35, 0, c_white, 0.25, _T, _k);
        }
    }
    dby_k_batch_end();
    dby_art__blend_end(_bm);
}

/// @function dby_course__tile_sprite(sprite, x0, y0, x1, y1)
/// @description Tile a dby_course_texture sprite (drawn at any supersample) over a rectangle, the tiles aligned to x = 0
/// and to y0, clipped exactly to the rectangle, with premultiplied blending. Internal.
function dby_course__tile_sprite(_spr, _x0, _y0, _x1, _y1) {
    var _T = DBY_TEX, _k = sprite_get_width(_spr) / _T, _pb = gpu_get_blendmode_ext_sepalpha();
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    for (var _ty = _y0; _ty < _y1 - 0.001; _ty += _T) {
        var _ph = min(_T, _y1 - _ty);
        for (var _tx = floor(_x0 / _T) * _T; _tx < _x1; _tx += _T) {
            var _pa = max(_tx, _x0), _pe = min(_tx + _T, _x1);
            if (_pe - _pa <= 0.001) continue;
            draw_sprite_part_ext(_spr, 0, (_pa - _tx) * _k, 0, (_pe - _pa) * _k, _ph * _k, _pa, _ty, 1 / _k, 1 / _k, c_white, 1);
        }
    }
    gpu_set_blendmode_ext_sepalpha(_pb[0], _pb[1], _pb[2], _pb[3]);
}

/// @function dby_course_strip_part(card, geo, x0, x1, [textures], [scenery])
/// @description Draw the part of a card's course strip that falls over [x0, x1) (the whole strip spans 0..geo.w), for a
/// long course baked a tile at a time. `textures` is a struct of surface name -> a dby_course_texture sprite: each
/// section is its ground gradient with its texture tiled over it (fast). Without it every section is drawn mark by mark
/// (dby_course_surface, slow, and only seamless when the window is the whole strip). `scenery` is this strip's
/// dby_course_scenery_layout (made here if omitted: pass one in when drawing several windows). Everything else - lane
/// strings, pegs, distance posts, the start, the winning post, a lettuce in every lane - is drawn where it falls.
function dby_course_strip_part(_card, _g, _x0, _x1, _tex = undefined, _scen = undefined) {
    if (!is_struct(_card) || !variable_struct_exists(_card, "course") || !variable_struct_exists(_card, "field") || !is_struct(_g) || !is_numeric(_x0) || !is_numeric(_x1)) return;
    if (!variable_struct_exists(_g, "w") || !variable_struct_exists(_g, "lane_h") || !variable_struct_exists(_g, "px")) return;
    var _c = _card.course, _n = array_length(_card.field), _T = dby_course_theme(_c.theme), _i, _s;
    _x0 = max(0, _x0); _x1 = min(_g.w, _x1);
    if (_x1 <= _x0) return;
    // ⛔ CLIPPED TO THE WINDOW: drawn window by window into ONE target, the second window's scenery (a stone reaching
    // back over the join) painted over the first window's lanes (LOOKED AT, buyer harness strip 2026-09-27)
    var _bm = dby_art__blend_begin(), _sc = gpu_get_scissor();
    dby_course__scissor(_x0, 0, _x1 - _x0, _g.h);
    dby_k_rect(_x0, 0, _x1 - _x0, _g.h, _T.edge);
    if (!is_struct(_scen)) _scen = dby_course_scenery_layout(_c.theme, 0, _g.w, 0, _g.top, dby_rng((_card.race_seed ^ $C0) & $FFFFFFFF));
    dby_course_scenery_draw(_scen, _x0, _x1);
    var _lt = _g.top, _lb = _g.top + _n * _g.lane_h, _secs = _c.sections, _ns = array_length(_secs);
    for (_s = 0; _s < _ns; _s++) {
        var _sx = (_s == 0) ? 0 : _g.start_x + _secs[_s].from * _g.px, _ex = (_s == _ns - 1) ? _g.w : _g.start_x + _secs[_s].to * _g.px;
        var _a = max(_sx, _x0), _b = min(_ex, _x1);
        if (_b <= _a) continue;
        var _name = _secs[_s].surface, _base = dby_course__base(_name);
        if (is_struct(_tex) && variable_struct_exists(_tex, _name) && sprite_exists(_tex[$ _name])) {
            dby_k_rect_grad(_a, _lt, _b - _a, _lb - _lt, _a, _lt, _a, _lb, [[0, _base[0], 1], [1, _base[1], 1]]);
            if (_name == "puddle") {
                var _skyc = make_colour_rgb(200, 225, 240);
                dby_k_rect_grad(_a, _lt, _b - _a, _lb - _lt, _sx, _lt, _ex, _lt, [[0, _skyc, 0], [0.5, _skyc, 0.22], [1, _skyc, 0]]);
            }
            dby_course__tile_sprite(_tex[$ _name], _a, _lt, _b, _lb);
            if (_name == "puddle") {
                var _mud = make_colour_rgb(70, 52, 30);
                if (_sx + 6 > _x0) dby_k_rect(_sx, _lt, 6, _lb - _lt, _mud, 0.55);
                if (_ex - 6 < _x1) dby_k_rect(_ex - 6, _lt, 6, _lb - _lt, _mud, 0.55);
                dby_k_rect(_a, _lt, _b - _a, 3, make_colour_rgb(40, 60, 70), 0.35);
            }
        } else dby_course_surface(_name, _a, _lt, _b - _a, _lb - _lt, dby_rng(dby_mix(_card.race_seed, $5EC + _s)), 1);
        if (_s > 0 && _sx >= _x0 - 2 && _sx <= _x1 + 2) dby_k_rect(_sx - 1, _lt, 2, _lb - _lt, c_black, 0.18);
    }
    var _peg = dby_art__hex("#6a4a2a"), _pegt = dby_art__hex("#a8804a"), _p0 = _g.start_x mod 120;
    for (_i = 0; _i <= _n; _i++) {
        var _ly = _lt + _i * _g.lane_h;
        dby_k_seg(_x0, _ly + 0.5, _x1, _ly + 0.5, 1.2, make_colour_rgb(250, 246, 230), 0.8);
        for (var _px = _p0 + max(0, ceil((_x0 - 4 - _p0) / 120)) * 120; _px < _x1 + 4; _px += 120) { dby_k_rect(_px - 1.5, _ly - 4, 3, 7, _peg); dby_k_rect(_px - 1.5, _ly - 4, 3, 2, _pegt); }
    }
    var _cream = dby_art__hex("#f4efe2"), _red = dby_art__hex("#c8202a"), _dark = dby_art__hex("#1a1208");
    for (var _k = 0; _k < 3; _k++) {
        var _dx = _g.start_x + (_k + 1) * 0.25 * DBY_LEN * _g.px;
        if (_dx < _x0 - 14 || _dx > _x1 + 14) continue;
        dby_k_rect(_dx - 2, _lt - 30, 4, 30, _cream); dby_k_rect(_dx - 2, _lt - 30, 4, 6, _red);
        dby_k_ellipse(_dx, _lt - 36, 10, 10, 0, _cream, 1); dby_k_polyline(dby_k_ellipse_ring(_dx, _lt - 36, 10, 10, 0, 32), 1, _dark, 1, true);
        dby_course__fraction(_dx, _lt - 35, 3 - _k, 4, _dark);
    }
    if (_g.start_x > _x0 - 24 && _g.start_x < _x1 + 4) {
        dby_k_rect(_g.start_x - 2, _lt, 3, _lb - _lt, make_colour_rgb(255, 255, 250), 0.9);
        dby_k_rect(_g.start_x - 3, _lt - 44, 3, 44, dby_art__hex("#5a3a1e"));
        dby_k_fill_rings([[[_g.start_x, _lt - 44], [_g.start_x + 20, _lt - 38], [_g.start_x, _lt - 32]]], _red, 1);
    }
    var _fx = _g.start_x + DBY_LEN * _g.px, _light = dby_art__hex("#fbf8f0");
    if (_fx > _x0 - 80 && _fx < _x1 + 16) {
        for (var _q = 0; _q < ceil((_lb - _lt) / 6); _q++) { dby_k_rect(_fx - 3, _lt + _q * 6, 3, 6, (_q mod 2) ? _dark : _light); dby_k_rect(_fx, _lt + _q * 6, 3, 6, (_q mod 2) ? _light : _dark); }
        var _ph = max(30, min(60, _lt - 30)), _dy = _lt - _ph - 6;
        for (var _pq = 0; _pq < 6; _pq++) dby_k_rect(_fx - 3, _lt - _ph + _pq * _ph / 6, 6, _ph / 6 + 0.5, (_pq mod 2) ? _red : _light);
        dby_k_ellipse(_fx, _dy, 13, 13, 0, _light, 1); dby_k_ellipse(_fx, _dy, 8, 8, 0, _red, 1);
        dby_k_polyline(dby_k_ellipse_ring(_fx, _dy, 13, 13, 0, 40), 1.2, _dark, 1, true);
        for (_i = 0; _i < _n; _i++) dby_course_lettuce(_fx + 46, _lt + (_i + 0.55) * _g.lane_h, _g.lane_h * 0.018 + 0.2);
    }
    dby_k_rect(_x0, _lb, _x1 - _x0, _g.h - _lb, _T.edge); dby_k_rect(_x0, _lb, _x1 - _x0, 2, c_white, 0.12);
    gpu_set_scissor(_sc);
    dby_art__blend_end(_bm);
}
