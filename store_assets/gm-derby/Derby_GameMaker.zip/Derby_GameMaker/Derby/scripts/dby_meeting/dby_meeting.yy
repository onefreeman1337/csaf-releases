{
  "$GMScript": "v1",
  "%Name": "dby_meeting",
  "name": "dby_meeting",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}