/// dby_meeting.gml - a whole race meeting to drop into a game: the race card with measured prices and real form, the bet
/// slip, the race run on a drawn garden course with a lane board and commentary, the judge's photograph when it is
/// close, and the winners' enclosure with rosettes and the payout. Everything is drawn by this package; nothing is
/// loaded from an image file.
///
/// Derby - A Snail-Racing Betting Minigame, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// PUBLIC
///   dby_meeting_create([opts])          -> a meeting (a struct). opts, all optional:
///       seed        number   the meeting's stable, courses and races (default 2026)
///       races       1..5     races per visit (default 3; with more than one, the last is always a Derby)
///       field_size  5..8     runners per race (default: the card decides, 6-8)
///       course      string   "kitchen" "rockery" "greenhouse" "orchard" "mossbank" (default: the card decides)
///       going       string   "dewy" "damp" "dry" (default: the card decides)
///       purse       number   the gold the player brings (default 500); read m.purse back when the meeting is done
///       min_stake / max_stake / stake_step   default 10 / 100 / 10
///       payback     0.5..1.0 what a bet returns on average over many races (default 0.85)
///       title       string   the meeting's name on the card (default: named after the course)
///       record      struct   a previous m.record (races, net, form) so the runners' form carries on between visits
///       fresh       bool     true (default): mix `visit` into every race, so reloading a save cannot replay a race
///       visit       number   what `fresh` mixes in (default: the clock). Pass the same number to get the same races.
///       book_ms     number   milliseconds a frame spent pricing a card (default 10)
///       work_ms     number   milliseconds a frame spent drawing ahead (course, runners, photograph; default 6)
///       on_event    function(name, meeting): "cursor" "stake" "off" "lead" "finish" "photo" "win" "lose" "leave" "done"
///                            - play your own sounds here (Derby ships none)
///       prompt_next / prompt_leave / currency / currency_short / hints   the few words the screens print
///   dby_meeting_step(meeting, [input]) -> advance one frame (call it in a Step event); returns the mode:
///       "card", "race", "photo", "result", "leaving" or "done"
///   dby_meeting_draw(meeting, x, y, w, h) -> draw the meeting fitted into a rectangle (Draw GUI, or Draw)
///   dby_meeting_input()                  -> the input step reads when you pass none: keyboard, mouse, gamepad 0
///   dby_meeting_prepare(meeting)         -> finish every pending bake and price the card NOW (for a loading screen)
///   dby_meeting_frame(meeting)           -> the 1280 x 720 surface the last draw composed (for screenshots)
///   dby_meeting_free(meeting)            -> free its surfaces and sprites (call it in Clean Up)
/// Read while it runs: m.mode, m.purse, m.net (winnings this visit), m.race_idx, m.record (save it to carry the form).
///
/// ⛔ HOW IT STAYS SMOOTH ON THE VM, MEASURED 2026-09-27 (2024.14.4.268): pricing a card is ~3 s of work, a course strip
/// drawn mark by mark 1.35 s, one runner ~43 ms. So the card is priced in book_ms slices (and the NEXT race's card while
/// this race runs), the ground comes from seamless textures baked once (dby_course_texture), the course is baked in tiles
/// and every runner into two sprites while the player reads the card, and the photograph and result are drawn during
/// the seconds after the finish. dby_meeting_prepare() does all of it at once if you would rather show a loading screen.

#macro DBY_MT_W 1280
#macro DBY_MT_H 720
#macro DBY_MT_SS 2
#macro DBY_MT_HEAD_H 84
#macro DBY_MT_VIEW_Y 84
#macro DBY_MT_VIEW_H 572
#macro DBY_MT_EDGE_H 22
#macro DBY_MT_BOARD_W 60
#macro DBY_MT_START_X 200
#macro DBY_MT_PX 3.4
#macro DBY_MT_TILE_W 640
#macro DBY_MT_TICK_FRAMES 2
#macro DBY_MT_CX 24
#macro DBY_MT_CY 16
#macro DBY_MT_CW 808
#macro DBY_MT_CH 688
#macro DBY_MT_RX 852
#macro DBY_MT_RW 404
#macro DBY_MT_MAP_Y 16
#macro DBY_MT_SLIP_Y 178
#macro DBY_MT_SLIP_H 412

// ---------------------------------------------------------------------------------------------------------------
// Palette and type
// ---------------------------------------------------------------------------------------------------------------

/// @function dby_mt__pal()
/// @description The screens' colours, as GameMaker colours. Internal.
function dby_mt__pal() {
    static _p = {
        red: dby_art__hex("#a8232a"), ink: dby_art__hex("#1e140c"), muted: dby_art__hex("#5a4430"), sub: dby_art__hex("#6a5038"),
        colh: dby_art__hex("#8a6a44"), cream: dby_art__hex("#fbf5e6"), gold: dby_art__hex("#c9a25a"), goldt: dby_art__hex("#f6e3b4"),
        goldm: dby_art__hex("#c9a878"), green: dby_art__hex("#2f6a2a"), dark: dby_art__hex("#1a1208"), brown: make_colour_rgb(160, 120, 60)
    };
    return _p;
}

/// @function dby_mt__t(x, y, text, px, colour, halign, valign, k, [bold], [alpha], [font])
/// @description Type at logical (x, y), px tall, on a surface supersampled k times; `bold` double-strikes it (the serif
/// ships one weight). Internal.
function dby_mt__t(_x, _y, _s, _px, _col, _ha, _va, _k, _bold = false, _alpha = 1, _font = fnt_derby) {
    if (_bold) {
        var _b = max(0.35, _px * 0.03) * _k;
        dby_k_text(_x * _k - _b * 0.5, _y * _k, _s, _px * _k, _col, _ha, _va, _font, _alpha);
        dby_k_text(_x * _k + _b * 0.5, _y * _k, _s, _px * _k, _col, _ha, _va, _font, _alpha);
    } else dby_k_text(_x * _k, _y * _k, _s, _px * _k, _col, _ha, _va, _font, _alpha);
}

/// @function dby_mt__tw(text, px, [bold], [font])
/// @description The logical width dby_mt__t draws a string at (measured at the supersampled size it is drawn at). Internal.
function dby_mt__tw(_s, _px, _bold = false, _font = fnt_derby) { return dby_k_text_w(_s, _px * DBY_MT_SS, _font) / DBY_MT_SS + (_bold ? max(0.35, _px * 0.03) : 0); }

/// @function dby_mt__fit(text, px, minpx, maxw, [bold])
/// @description The largest size from px down to minpx at which a string fits maxw. Internal.
function dby_mt__fit(_s, _px, _min, _maxw, _bold = false) { while (_px > _min && dby_mt__tw(_s, _px, _bold) > _maxw) _px -= 1; return _px; }

/// @function dby_mt__dots(x, y, parts, px, colour, halign, k, [bold])
/// @description Words separated by a DRAWN middle dot (the fonts carry ASCII only, and a missing glyph draws nothing at
/// all), vertically centred on y. Internal.
function dby_mt__dots(_x, _y, _parts, _px, _col, _ha, _k, _bold = false) {
    var _n = array_length(_parts), _gap = _px * 1.2, _ws = array_create(_n), _tw = 0, _i;
    for (_i = 0; _i < _n; _i++) { _ws[_i] = dby_mt__tw(_parts[_i], _px, _bold); _tw += _ws[_i]; }
    _tw += _gap * max(0, _n - 1);
    var _cx = (_ha == fa_center) ? _x - _tw / 2 : ((_ha == fa_right) ? _x - _tw : _x);
    for (_i = 0; _i < _n; _i++) {
        dby_mt__t(_cx, _y, _parts[_i], _px, _col, fa_left, fa_middle, _k, _bold);
        _cx += _ws[_i];
        if (_i < _n - 1) { dby_k_ellipse((_cx + _gap / 2) * _k, (_y + _px * 0.06) * _k, _px * 0.09 * _k, _px * 0.09 * _k, 0, _col, 1); _cx += _gap; }
    }
    return _tw;
}

/// @function dby_mt__rrect(x, y, w, h, r, colour, alpha, k, [grad_top], [grad_bottom])
/// @description A filled rounded rectangle at logical coordinates (optionally a top-to-bottom gradient). Internal.
function dby_mt__rrect(_x, _y, _w, _h, _r, _col, _a, _k, _g0 = undefined, _g1 = undefined) {
    var _ring = dby_art__rrect(_x * _k, _y * _k, _w * _k, _h * _k, _r * _k);
    if (is_undefined(_g0)) dby_k_fill_rings([_ring], _col, _a);
    else dby_k_fill_rings([_ring], c_white, _a, { x0: 0, y0: _y * _k, x1: 0, y1: (_y + _h) * _k, stops: [[0, _g0, 1], [1, _g1, 1]] });
}

/// @function dby_mt__rrect_line(x, y, w, h, r, lw, colour, alpha, k)
/// @description A rounded rectangle's outline, lw wide, at logical coordinates. Internal.
function dby_mt__rrect_line(_x, _y, _w, _h, _r, _lw, _col, _a, _k) { dby_k_polyline(dby_art__rrect(_x * _k, _y * _k, _w * _k, _h * _k, _r * _k), _lw * _k, _col, _a, true); }

// ---------------------------------------------------------------------------------------------------------------
// Layers: supersampled surfaces painted by jobs, drawn into the frame at 1x
// ---------------------------------------------------------------------------------------------------------------

/// @function dby_mt__layer(w, h, [ss])
function dby_mt__layer(_w, _h, _ss = DBY_MT_SS) { return { w: _w, h: _h, ss: _ss, surf: -1, ok: false, bm: undefined }; }

/// @function dby_mt__begin(layer, [clear])
/// @description Target a layer's surface (made, re-made if lost, or re-made at a new size) for painting at its
/// supersample. Internal.
function dby_mt__begin(_L, _clear = true) {
    var _sw = ceil(_L.w * _L.ss), _sh = ceil(_L.h * _L.ss);
    if (surface_exists(_L.surf) && (surface_get_width(_L.surf) != _sw || surface_get_height(_L.surf) != _sh)) surface_free(_L.surf);
    if (!surface_exists(_L.surf)) { _L.surf = surface_create(_sw, _sh); _clear = true; }
    surface_set_target(_L.surf);
    if (_clear) draw_clear_alpha(c_black, 0);
    _L.bm = dby_art__blend_begin();
}

/// @function dby_mt__end(layer)
function dby_mt__end(_L) { dby_art__blend_end(_L.bm); surface_reset_target(); _L.ok = true; }

/// @function dby_mt__put(layer, x, y)
/// @description Draw a painted layer into the current target at logical (x, y), 1x, premultiplied. False if it has none.
function dby_mt__put(_L, _x, _y) {
    if (!_L.ok || !surface_exists(_L.surf)) return false;
    var _pb = gpu_get_blendmode_ext_sepalpha(), _tf = gpu_get_texfilter();
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); gpu_set_texfilter(true);
    draw_surface_ext(_L.surf, _x, _y, 1 / _L.ss, 1 / _L.ss, 0, c_white, 1);
    gpu_set_texfilter(_tf); gpu_set_blendmode_ext_sepalpha(_pb[0], _pb[1], _pb[2], _pb[3]);
    return true;
}

/// @function dby_mt__sprite_from(surf2, w, h, xo, yo)
/// @description Filter a supersampled surface down to w x h and make a sprite of it (premultiplied), origin (xo, yo).
/// Internal. A sprite survives what a surface does not (a lost device), so everything a race only READS is a sprite.
function dby_mt__sprite_from(_s2, _w, _h, _xo, _yo) {
    var _s1 = surface_create(_w, _h), _pb = gpu_get_blendmode_ext_sepalpha(), _tf = gpu_get_texfilter();
    surface_set_target(_s1);
    draw_clear_alpha(c_black, 0);
    gpu_set_blendmode_ext(bm_one, bm_zero); gpu_set_texfilter(true);
    draw_surface_ext(_s2, 0, 0, _w / surface_get_width(_s2), _h / surface_get_height(_s2), 0, c_white, 1);
    gpu_set_texfilter(_tf); gpu_set_blendmode_ext_sepalpha(_pb[0], _pb[1], _pb[2], _pb[3]);
    surface_reset_target();
    var _spr = sprite_create_from_surface(_s1, 0, 0, _w, _h, false, false, _xo, _yo);
    surface_free(_s1);
    return _spr;
}

/// @function dby_mt__spr(sprite, x, y, xs, ys, rot_deg, [alpha])
/// @description Draw one of the meeting's premultiplied sprites. Internal.
function dby_mt__spr(_spr, _x, _y, _xs, _ys, _rot, _alpha = 1) {
    if (!sprite_exists(_spr)) return;
    var _pb = gpu_get_blendmode_ext_sepalpha(), _tf = gpu_get_texfilter();
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); gpu_set_texfilter(true);
    draw_sprite_ext(_spr, 0, _x, _y, _xs, _ys, _rot, c_white, _alpha);
    gpu_set_texfilter(_tf); gpu_set_blendmode_ext_sepalpha(_pb[0], _pb[1], _pb[2], _pb[3]);
}

// ---------------------------------------------------------------------------------------------------------------
// Jobs: drawing work spread over frames
// ---------------------------------------------------------------------------------------------------------------

/// @function dby_mt__queue(meeting, name, fn, [arg], [front])
function dby_mt__queue(_m, _name, _fn, _arg = undefined, _front = false) {
    if (_front) array_insert(_m.jobs, 0, [_name, _fn, _arg]); else array_push(_m.jobs, [_name, _fn, _arg]);
}

/// @function dby_mt__work(meeting, ms)
/// @description Run queued jobs until `ms` milliseconds have gone (always at least one). Returns the number run. Every
/// job's time is recorded in m.stats (worst job and its name), so a hitch is a measurement, not a guess. Internal.
function dby_mt__work(_m, _ms) {
    var _t0 = get_timer(), _ran = 0;
    while (array_length(_m.jobs) > 0) {
        var _j = _m.jobs[0], _fn = _j[1], _ts = get_timer();
        var _done = _fn(_m, _j[2]);
        var _dt = (get_timer() - _ts) / 1000;
        _m.stats.jobs++;
        if (_dt > _m.stats.worst_job_ms) { _m.stats.worst_job_ms = _dt; _m.stats.worst_job = _j[0]; }
        if (!variable_struct_exists(_m.stats.by, _j[0])) _m.stats.by[$ _j[0]] = [0, 0, 0];
        var _b = _m.stats.by[$ _j[0]];
        _b[0] += 1; _b[1] += _dt; _b[2] = max(_b[2], _dt);
        if (_done) array_delete(_m.jobs, 0, 1);
        _ran++;
        if ((get_timer() - _t0) / 1000 >= _ms) break;
    }
    return _ran;
}

/// @function dby_mt__work_all(meeting)
function dby_mt__work_all(_m) { var _guard = 0; while (array_length(_m.jobs) > 0 && _guard < 10000) { dby_mt__work(_m, 1000000); _guard++; } }

/// @function dby_mt__event(meeting, name)
function dby_mt__event(_m, _name) { if (!is_undefined(_m.on_event)) { var _f = _m.on_event; _f(_name, _m); } }

// ---------------------------------------------------------------------------------------------------------------
// Creating, preparing and freeing a meeting
// ---------------------------------------------------------------------------------------------------------------

/// @function dby_meeting_create([opts])
/// @description A race meeting (see the file header for opts). Draws its first card and starts pricing it; the first
/// frames bake the card, the runners and the course.
function dby_meeting_create(_o = undefined) {
    var _num = function(_s, _k, _d) { return (is_struct(_s) && variable_struct_exists(_s, _k) && is_numeric(_s[$ _k])) ? _s[$ _k] : _d; };
    var _str = function(_s, _k, _d) { return (is_struct(_s) && variable_struct_exists(_s, _k) && is_string(_s[$ _k])) ? _s[$ _k] : _d; };
    var _seed = floor(_num(_o, "seed", 2026)) & $FFFFFFFF;
    var _fs = floor(_num(_o, "field_size", -1));
    var _min = max(1, floor(_num(_o, "min_stake", 10))), _max = max(_min, floor(_num(_o, "max_stake", 100)));
    var _fresh = !(is_struct(_o) && variable_struct_exists(_o, "fresh") && (_o.fresh == false));
    var _visit = floor(_num(_o, "visit", floor(date_current_datetime() * 86400))) & $FFFFFFFF;
    var _ev = (is_struct(_o) && variable_struct_exists(_o, "on_event") && is_callable(_o.on_event)) ? _o.on_event : undefined;
    var _hints = (is_struct(_o) && variable_struct_exists(_o, "hints") && is_array(_o.hints)) ? _o.hints
        : ["up / down  choose a runner", "left / right  change the stake", "Shift  Win or Place", "Enter  off they go     Esc  leave"];
    var _m = {
        v: 1, seed: _seed, races: clamp(floor(_num(_o, "races", 3)), 1, 5), field_size: (_fs >= 5 && _fs <= 8) ? _fs : -1,
        course: _str(_o, "course", undefined), going: _str(_o, "going", undefined), min_stake: _min, max_stake: _max,
        stake_step: max(1, floor(_num(_o, "stake_step", 10))), payback: clamp(_num(_o, "payback", 0.85), 0.5, 1.0),
        title: _str(_o, "title", ""), book_ms: max(0.5, _num(_o, "book_ms", 10)), work_ms: max(0.5, _num(_o, "work_ms", 6)),
        purse: max(0, floor(_num(_o, "purse", 500))), net: 0, race_idx: 0, mode: "card", wait: 0, frame_no: 0,
        card_seed: _fresh ? dby_mix(_seed, _visit) : _seed, on_event: _ev,
        prompt_next: _str(_o, "prompt_next", "Enter or click for the next race"), prompt_leave: _str(_o, "prompt_leave", "Enter or click to leave"),
        currency: _str(_o, "currency", "gold"), currency_short: _str(_o, "currency_short", "G"), hints: _hints,
        record: undefined, stable: undefined, card: undefined, next_card: undefined, next_idx: -1,
        sel: 0, type: "win", stake: 0, bet: undefined, row_top: 170, row_h: 60, slip_boxes: {},
        layers: { table: dby_mt__layer(DBY_MT_W, DBY_MT_H, 1), card: dby_mt__layer(DBY_MT_CW + 8, DBY_MT_CH + 10),
            map: dby_mt__layer(DBY_MT_RW, 156), slip: dby_mt__layer(DBY_MT_RW, DBY_MT_SLIP_H + 8),
            head: dby_mt__layer(DBY_MT_W, DBY_MT_HEAD_H), board: dby_mt__layer(DBY_MT_BOARD_W, 480),
            comment: dby_mt__layer(DBY_MT_W, DBY_MT_H - DBY_MT_VIEW_Y - DBY_MT_VIEW_H), result: dby_mt__layer(DBY_MT_W, DBY_MT_H) },
        jobs: [], tex: {}, grain_paper: -1, grain_print: -1, body: [], shell: [], dot: [], tiles: [], trail: -1, scen: undefined, geo: undefined, s: 1, prep_for: -1,
        race: undefined, run: [], acc: 0, cam_x: 0, prev_st: [], prev_sec: [], prev_leader: -1, finish_seen: false, done_wait: 0,
        comment_text: "", comment_cool: 0, photo: -1, photo2: -1, photo_geo: undefined, photo_shown: [], photo_boxes: [],
        res: undefined, rep: { up: 0, down: 0, left: 0, right: 0 }, view: { x: 0, y: 0, k: 1 }, frame: -1, fade: 0,
        slip_tick: 0, stats: { jobs: 0, worst_job_ms: 0, worst_job: "", book_ms_total: 0, book_frames: 0, cards_priced: 0, by: {} }
    };
    var _rec = (is_struct(_o) && variable_struct_exists(_o, "record")) ? _o.record : undefined;
    _m.stable = dby_make_stable(_seed, 12);
    if (is_struct(_rec) && variable_struct_exists(_rec, "races") && is_numeric(_rec.races) && variable_struct_exists(_rec, "form") && is_struct(_rec.form))
        _m.record = { races: max(0, floor(_rec.races)), net: (variable_struct_exists(_rec, "net") && is_numeric(_rec.net)) ? _rec.net : 0, form: _rec.form };
    else _m.record = { races: 0, net: 0, form: dby_initial_form(_m.stable, _seed) };
    dby_mt__queue(_m, "table", dby_mt__job_table);
    dby_mt__new_card(_m);
    return _m;
}

/// @function dby_meeting_prepare(meeting)
/// @description Finish every pending bake and price the current card now (a few seconds on the VM): call it behind your
/// own loading screen if you would rather have no work spread over the first frames. True when done.
function dby_meeting_prepare(_m) {
    if (!is_struct(_m) || !variable_struct_exists(_m, "jobs")) return false;
    dby_mt__work_all(_m);
    if (is_struct(_m.card) && !_m.card.priced) { dby_work_book(_m.card); dby_mt__priced(_m); dby_mt__work_all(_m); }
    return true;
}

/// @function dby_meeting_frame(meeting)
/// @description The 1280 x 720 surface the last dby_meeting_draw composed (-1 before the first draw). For screenshots.
function dby_meeting_frame(_m) { return (is_struct(_m) && variable_struct_exists(_m, "frame") && surface_exists(_m.frame)) ? _m.frame : -1; }

/// @function dby_mt__free_race(meeting)
/// @description Free the sprites one race uses (runners, dots, trail, course tiles). Called from Step only: a sprite
/// deleted after a draw was queued draws as a white box (Doctrine_Craft section 10). Internal.
function dby_mt__free_race(_m) {
    var _i;
    for (_i = 0; _i < array_length(_m.body); _i++) if (sprite_exists(_m.body[_i])) sprite_delete(_m.body[_i]);
    for (_i = 0; _i < array_length(_m.shell); _i++) if (sprite_exists(_m.shell[_i])) sprite_delete(_m.shell[_i]);
    for (_i = 0; _i < array_length(_m.dot); _i++) if (sprite_exists(_m.dot[_i])) sprite_delete(_m.dot[_i]);
    for (_i = 0; _i < array_length(_m.tiles); _i++) if (sprite_exists(_m.tiles[_i])) sprite_delete(_m.tiles[_i]);
    if (sprite_exists(_m.trail)) sprite_delete(_m.trail);
    _m.body = []; _m.shell = []; _m.dot = []; _m.tiles = []; _m.trail = -1; _m.prep_for = -1;
}

/// @function dby_meeting_free(meeting)
/// @description Free every surface and sprite a meeting holds (call it in Clean Up). The meeting is unusable after.
function dby_meeting_free(_m) {
    if (!is_struct(_m) || !variable_struct_exists(_m, "layers")) return;
    dby_mt__free_race(_m);
    var _names = variable_struct_get_names(_m.layers);
    for (var _i = 0; _i < array_length(_names); _i++) { var _L = _m.layers[$ _names[_i]]; if (surface_exists(_L.surf)) surface_free(_L.surf); _L.ok = false; }
    var _tn = variable_struct_get_names(_m.tex);
    for (var _t = 0; _t < array_length(_tn); _t++) if (sprite_exists(_m.tex[$ _tn[_t]])) sprite_delete(_m.tex[$ _tn[_t]]);
    _m.tex = {};
    if (sprite_exists(_m.grain_paper)) sprite_delete(_m.grain_paper);
    if (sprite_exists(_m.grain_print)) sprite_delete(_m.grain_print);
    _m.grain_paper = -1; _m.grain_print = -1;
    if (surface_exists(_m.photo)) surface_free(_m.photo);
    if (surface_exists(_m.photo2)) surface_free(_m.photo2);
    if (surface_exists(_m.frame)) surface_free(_m.frame);
    _m.jobs = []; _m.mode = "done";
}

// ---------------------------------------------------------------------------------------------------------------
// The card
// ---------------------------------------------------------------------------------------------------------------

/// @function dby_mt__open(meeting, race_idx)
/// @description Open (unpriced) the card for race race_idx of this visit. Internal.
function dby_mt__open(_m, _idx) {
    var _last = (_idx == _m.races - 1 && _m.races > 1), _kinds = dby__race_kinds();
    var _o = { seed: _m.card_seed, race_no: _m.record.races, payback: _m.payback, kind: _last ? "Derby" : _kinds[_m.record.races mod 4] };
    if (_m.field_size > 0) _o.field_size = _m.field_size;
    if (is_string(_m.course)) _o.course = _m.course;
    if (is_string(_m.going)) _o.going = _m.going;
    return dby_open_book(_m.stable, _o);
}

/// @function dby_mt__new_card(meeting)
/// @description Show the next race's card: take the one priced during the last race or open one, reset the slip, and
/// queue everything the card and the race need drawing. Internal.
function dby_mt__new_card(_m) {
    dby_mt__free_race(_m);
    _m.card = (is_struct(_m.next_card) && _m.next_idx == _m.race_idx) ? _m.next_card : dby_mt__open(_m, _m.race_idx);
    _m.next_card = undefined; _m.next_idx = -1;
    _m.sel = 0; _m.type = "win"; _m.bet = undefined; _m.res = undefined;
    _m.stake = (_m.purse >= _m.min_stake) ? min(_m.min_stake, _m.max_stake) : 0;
    var _n = array_length(_m.card.field);
    _m.row_top = 170; _m.row_h = min(84, floor((DBY_MT_CH - _m.row_top - 26) / _n));
    // the race view's geometry is fixed by the field, so the runners are baked at race scale now and the card draws
    // those same sprites smaller
    var _lh = min(72, floor(480 / _n)), _top = DBY_MT_VIEW_H - DBY_MT_EDGE_H - _n * _lh;
    _m.geo = { w: DBY_MT_START_X + DBY_LEN * DBY_MT_PX + 300, h: DBY_MT_VIEW_H, top: _top, lane_h: _lh, start_x: DBY_MT_START_X, px: DBY_MT_PX };
    _m.s = _lh / 68;
    _m.layers.board.h = _n * _lh;
    _m.mode = "card"; _m.slip_tick = 0;
    _m.layers.card.ok = false; _m.layers.slip.ok = false; _m.layers.map.ok = false;
    // ⛔ -1, never an empty array: GML fills the gap below an assigned index with 0, and sprite 0 is a real sprite in a
    // buyer's project - a runner not yet baked would draw THEIR first sprite
    _m.body = array_create(_n, -1); _m.shell = array_create(_n, -1); _m.dot = array_create(_n, -1);
    dby_mt__queue(_m, "card", dby_mt__job_card, "base");
    dby_mt__queue(_m, "card rows", dby_mt__job_card, "rows");
    dby_mt__queue(_m, "slip", dby_mt__job_slip);
    dby_mt__queue(_m, "map", dby_mt__job_map);
    for (var _i = 0; _i < _n; _i++) dby_mt__queue(_m, "runner", dby_mt__job_runner, _i);
    var _secs = _m.card.course.sections;
    for (var _s = 0; _s < array_length(_secs); _s++) if (!variable_struct_exists(_m.tex, _secs[_s].surface)) { _m.tex[$ _secs[_s].surface] = -1; dby_mt__queue(_m, "texture", dby_mt__job_tex, _secs[_s].surface); }
    dby_mt__queue(_m, "scenery", dby_mt__job_scen);
    var _nt = ceil(_m.geo.w / DBY_MT_TILE_W);
    _m.tiles = array_create(_nt, -1);
    for (var _t = 0; _t < _nt; _t++) dby_mt__queue(_m, "tile", dby_mt__job_tile, _t);
    dby_mt__queue(_m, "race furniture", dby_mt__job_furniture);
    _m.prep_for = _m.card;
}

/// @function dby_mt__form(meeting, runner)
function dby_mt__form(_m, _ru) { var _k = string(_ru.id); return variable_struct_exists(_m.record.form, _k) ? _m.record.form[$ _k] : []; }

/// @function dby_mt__returns(meeting)
/// @description What the slip's bet returns if it comes in (0 for no bet or no price). Internal.
function dby_mt__returns(_m) {
    var _c = _m.card, _rung = (_m.type == "win") ? _c.win[_m.sel] : _c.place[_m.sel];
    return (_c.priced && _rung >= 0 && _m.stake > 0) ? floor(_m.stake * dby_dec(_rung)) : 0;
}

/// @function dby_mt__grain(kind, k)
/// @description A seamless DBY_TEX-square tile of grain at supersample k, as a premultiplied sprite: "paper" (the card's
/// fleck, one mark per 90 px) or "print" (the photograph's, one per 30). ⛔ MEASURED 2026-09-27: drawn mark by mark the
/// grain was most of three frames of 130-170 ms (the card, the result board, the print); tiled, it is one draw. Internal.
function dby_mt__grain(_kind, _k) {
    var _T = DBY_TEX, _s2 = surface_create(_T * _k, _T * _k), _paper = (_kind == "paper");
    var _r = dby_rng(_paper ? $9A9E2 : $F070), _n = _T * _T / (_paper ? 90 : 30);
    var _c0 = _paper ? make_colour_rgb(160, 120, 60) : make_colour_rgb(60, 40, 20), _c1 = _paper ? c_white : make_colour_rgb(255, 240, 210);
    var _a0 = _paper ? 0.06 : 0.12, _a1 = _paper ? 0.25 : 0.12;
    surface_set_target(_s2); draw_clear_alpha(c_black, 0);
    var _bm = dby_art__blend_begin();
    dby_k_batch_begin();
    for (var _i = 0; _i < _n; _i++) {
        var _p = dby_rnd(_r) < 0.5;
        var _sx = dby_rnd(_r) * _T;
        var _sy = floor(dby_rnd(_r) * _T);
        var _sw = 1 + dby_rnd(_r) * 2;
        dby_k_batch_rect(_sx * _k, _sy * _k, _sw * _k, _k, _p ? _c0 : _c1, _p ? _a0 : _a1);
        if (_sx + _sw > _T) dby_k_batch_rect((_sx - _T) * _k, _sy * _k, _sw * _k, _k, _p ? _c0 : _c1, _p ? _a0 : _a1);
    }
    dby_k_batch_end();
    dby_art__blend_end(_bm);
    surface_reset_target();
    var _spr = sprite_create_from_surface(_s2, 0, 0, _T * _k, _T * _k, false, false, 0, 0);
    surface_free(_s2);
    return _spr;
}

/// @function dby_mt__tile(sprite, x0, y0, x1, y1, [ox], [oy])
/// @description Tile a premultiplied sprite over [x0, x1) x [y0, y1) in the CURRENT target's units (one texel a unit),
/// the grid shifted by (ox, oy) so two papers do not share a pattern. Internal.
function dby_mt__tile(_spr, _x0, _y0, _x1, _y1, _ox = 0, _oy = 0) {
    if (!sprite_exists(_spr)) return;
    var _P = sprite_get_width(_spr), _Q = sprite_get_height(_spr), _pb = gpu_get_blendmode_ext_sepalpha();
    _ox = ((_ox mod _P) + _P) mod _P; _oy = ((_oy mod _Q) + _Q) mod _Q;
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    for (var _ty = _y0 - _oy; _ty < _y1; _ty += _Q) {
        var _a = max(_ty, _y0), _b = min(_ty + _Q, _y1);
        if (_b <= _a) continue;
        for (var _tx = _x0 - _ox; _tx < _x1; _tx += _P) {
            var _c = max(_tx, _x0), _d = min(_tx + _P, _x1);
            if (_d <= _c) continue;
            draw_sprite_part(_spr, 0, _c - _tx, _a - _ty, _d - _c, _b - _a, _c, _a);
        }
    }
    gpu_set_blendmode_ext_sepalpha(_pb[0], _pb[1], _pb[2], _pb[3]);
}

/// @function dby_mt__paper(x, y, w, h, seed, k, [grain])
/// @description Card paper: a shadow, a cream sheet with a fine grain (the tiled `grain` sprite, else mark by mark), a
/// double red rule. Internal.
function dby_mt__paper(_x, _y, _w, _h, _seed, _k, _grain = -1) {
    var _P = dby_mt__pal();
    dby_mt__rrect(_x + 4, _y + 6, _w, _h, 4, c_black, 0.5, _k);
    dby_mt__rrect(_x, _y, _w, _h, 3, c_white, 1, _k, dby_art__hex("#fbf5e6"), dby_art__hex("#efe3c6"));
    if (sprite_exists(_grain)) dby_mt__tile(_grain, (_x + 3) * _k, (_y + 3) * _k, (_x + _w - 3) * _k, (_y + _h - 3) * _k, (floor(_seed) mod 97) * 7, (floor(_seed) mod 89) * 5);
    else {
        var _r = dby_rng(floor(_seed) & $FFFFFFFF), _n = _w * _h / 90;
        dby_k_batch_begin();
        for (var _i = 0; _i < _n; _i++) {
            var _p = dby_rnd(_r) < 0.5;
            var _sx = _x + dby_rnd(_r) * _w;
            var _sy = _y + dby_rnd(_r) * _h;
            var _sw = 1 + dby_rnd(_r) * 2;
            dby_k_batch_rect(_sx * _k, _sy * _k, _sw * _k, _k, _p ? _P.brown : c_white, _p ? 0.06 : 0.25);
        }
        dby_k_batch_end();
    }
    dby_k_rect_stroke((_x + 8) * _k, (_y + 8) * _k, (_w - 16) * _k, (_h - 16) * _k, 2 * _k, _P.red, 1);
    dby_k_rect_stroke((_x + 12) * _k, (_y + 12) * _k, (_w - 24) * _k, (_h - 24) * _k, 0.8 * _k, _P.red, 1);
}

/// @function dby_mt__table(w, h)
/// @description The dark wooden table the papers lie on (1x). Internal.
function dby_mt__table(_W, _H) {
    dby_k_rect_grad(0, 0, _W, _H, 0, 0, _W, _H, [[0, dby_art__hex("#3a2414"), 1], [1, dby_art__hex("#1e1208"), 1]]);
    var _r = dby_rng($7AB1E), _lite = make_colour_rgb(255, 210, 160);
    dby_k_batch_begin();
    for (var _y = 0; _y < _H; _y += 3) {
        var _l = dby_rnd(_r) < 0.5;
        var _lw = 1 + dby_rnd(_r) * 2;
        var _px = 0, _py = _y;
        for (var _x = 0; _x <= _W + 40; _x += 40) { var _ny = _y + sin(_x / 90 + _y / 30) * 2; if (_x > 0) dby_k_batch_seg(_px, _py, _x, _ny, _lw, _l ? _lite : c_black, _l ? 0.035 : 0.12); _px = _x; _py = _ny; }
    }
    dby_k_batch_end();
}

/// @function dby_mt__job_table(meeting)
function dby_mt__job_table(_m, _a) {
    if (!sprite_exists(_m.grain_paper)) _m.grain_paper = dby_mt__grain("paper", DBY_MT_SS);
    if (!sprite_exists(_m.grain_print)) _m.grain_print = dby_mt__grain("print", DBY_MT_SS);
    var _L = _m.layers.table;
    dby_mt__begin(_L);
    draw_clear_alpha(c_black, 1);
    dby_mt__table(DBY_MT_W, DBY_MT_H);
    dby_mt__end(_L);
    return true;
}

/// @function dby_mt__pref_glyph(x, y, pref, s, k)
/// @description The going a runner likes: a raindrop, a sun, or one of each for "any". Internal.
function dby_mt__pref_glyph(_x, _y, _pref, _s, _k) {
    if (_pref == "damp" || _pref == "any") {
        var _d = [[_x * _k, (_y - 7 * _s) * _k]];
        dby_art__quad(_d, _x * _k, (_y - 7 * _s) * _k, (_x + 6 * _s) * _k, (_y + _s) * _k, _x * _k, (_y + 5 * _s) * _k, 8);
        dby_art__quad(_d, _x * _k, (_y + 5 * _s) * _k, (_x - 6 * _s) * _k, (_y + _s) * _k, _x * _k, (_y - 7 * _s) * _k, 8);
        array_pop(_d);
        dby_k_fill_rings([_d], dby_art__hex("#3a78b8"), 1);
    }
    if (_pref == "dry" || _pref == "any") {
        var _ox = (_pref == "any") ? 14 * _s : 0, _sun = dby_art__hex("#e0a020");
        dby_k_ellipse((_x + _ox) * _k, _y * _k, 4 * _s * _k, 4 * _s * _k, 0, _sun, 1);
        for (var _i = 0; _i < 8; _i++) { var _a = _i / 8 * DBY_ART_TAU; dby_k_seg((_x + _ox + cos(_a) * 5.5 * _s) * _k, (_y + sin(_a) * 5.5 * _s) * _k, (_x + _ox + cos(_a) * 8 * _s) * _k, (_y + sin(_a) * 8 * _s) * _k, 1.2 * _s * _k, _sun, 1); }
    }
}

/// @function dby_mt__chalk(x, y, w, h, big, small, k)
/// @description A price chalked on a slate tablet. Internal.
function dby_mt__chalk(_x, _y, _w, _h, _big, _small, _k) {
    dby_mt__rrect(_x, _y, _w, _h, 4, c_white, 1, _k, dby_art__hex("#34383c"), dby_art__hex("#1e2226"));
    dby_mt__rrect_line(_x + 1, _y + 1, _w - 2, _h - 2, 4, 2, dby_art__hex("#8a6a44"), 1, _k);
    var _bp = clamp(round(_h * 0.42), 16, 26), _sp = clamp(round(_h * 0.25), 11, 14);
    dby_mt__t(_x + _w / 2, _y + _h * 0.4, _big, _bp, make_colour_rgb(245, 245, 235), fa_center, fa_middle, _k, true, 1);
    dby_mt__t(_x + _w / 2, _y + _h * 0.78, _small, _sp, make_colour_rgb(220, 225, 215), fa_center, fa_middle, _k, false, 0.8);
}

/// @function dby_mt__chalk_rect(meeting, i)
/// @description Where runner i's price tablet sits on the card layer: [x, y, w, h]. Internal.
function dby_mt__chalk_rect(_m, _i) { var _y = _m.row_top + _i * _m.row_h; return [DBY_MT_CW - 28 - 124, _y + 6, 116, _m.row_h - 12]; }

/// @function dby_mt__paint_chalk(meeting, i, k)
function dby_mt__paint_chalk(_m, _i, _k) {
    var _c = _m.card, _r = dby_mt__chalk_rect(_m, _i);
    var _big = _c.priced ? dby_price_text(_c.win[_i]) : "...", _small = _c.priced ? ((_c.place[_i] < 0) ? "win only" : "place " + dby_price_text(_c.place[_i])) : "chalking";
    dby_mt__chalk(_r[0], _r[1], _r[2], _r[3], _big, _small, _k);
}

/// @function dby_mt__job_card(meeting)
/// @description Paint the race card: paper, the meeting and race, conditions, the columns, and a row per runner (number
/// cloth, name, going and silks, form, price). The runners themselves are the race sprites, drawn over it per frame.
function dby_mt__job_card(_m, _part) {
    var _L = _m.layers.card, _k = DBY_MT_SS, _c = _m.card, _W = DBY_MT_CW, _P = dby_mt__pal(), _n = array_length(_c.field), _i;
    var _x0 = 28, _rw = _W - 56, _h = _m.row_h;
    // in two parts so no one frame carries the whole card: "base" (paper, heading, columns) then "rows"
    var _do_base = (_part != "rows"), _do_rows = (_part != "base");
    if (!_do_base && !surface_exists(_L.surf)) { _do_base = true; _do_rows = true; }
    dby_mt__begin(_L, _do_base);
    if (_do_base) {
    dby_mt__paper(0, 0, _W, DBY_MT_CH, _c.race_seed, _k, _m.grain_paper);
    var _meet = (_m.title != "") ? _m.title : _c.course.name + " Races";
    dby_mt__dots(_W / 2, 38, [string_upper(_meet), "RACE " + string(_m.race_idx + 1) + " OF " + string(_m.races)], 15, _P.red, fa_center, _k, true);
    var _np = dby_mt__fit(_c.name, 46, 26, _W - 90, true);
    dby_mt__t(_W / 2, 78, _c.name, _np, _P.ink, fa_center, fa_middle, _k, true);
    var _going = string_upper(string_char_at(_c.going, 1)) + string_delete(_c.going, 1, 1);
    dby_mt__dots(_W / 2, 116, ["Going: " + _going, string(_n) + " runners", (_c.place_terms >= 2) ? "Place pays the first " + string(_c.place_terms) : "Place pays the winner only"], 17, _P.muted, fa_center, _k);
    dby_k_rect(36 * _k, 134 * _k, (_W - 72) * _k, 1.5 * _k, _P.ink, 1);
    dby_k_rect(36 * _k, 138 * _k, (_W - 72) * _k, 0.6 * _k, _P.ink, 1);
    var _cy = _m.row_top - 13;
    dby_mt__t(_x0 + 32, _cy, "NO.", 12, _P.colh, fa_center, fa_middle, _k, true);
    dby_mt__t(_x0 + 116, _cy, "RUNNER", 12, _P.colh, fa_center, fa_middle, _k, true);
    dby_mt__t(_x0 + 170, _cy, "NAME", 12, _P.colh, fa_left, fa_middle, _k, true);
    dby_mt__t(_x0 + _rw - 214, _cy, "FORM", 12, _P.colh, fa_center, fa_middle, _k, true);
    dby_mt__t(_x0 + _rw - 66, _cy, "PRICE", 12, _P.colh, fa_center, fa_middle, _k, true);
    }
    if (_do_rows) for (_i = 0; _i < _n; _i++) {
        var _y = _m.row_top + _i * _h, _ru = _c.field[_i], _look = _ru.look, _mid = _y + _h / 2;
        if (_i mod 2) dby_k_rect(_x0 * _k, _y * _k, _rw * _k, _h * _k, _P.brown, 0.07);
        var _cw = min(46, _h * 0.66);
        dby_art_cloth(_look, _i + 1, (_x0 + 32) * _k, _mid * _k, _cw * _k, _cw * 0.74 * _k);
        var _nx = _x0 + 170, _fx0 = _x0 + _rw - 262;
        var _npx = dby_mt__fit(_ru.name, clamp(round(_h * 0.36), 18, 27), 14, _fx0 - 24 - _nx, true);
        dby_mt__t(_nx, _y + _h * 0.36, _ru.name, _npx, _P.ink, fa_left, fa_middle, _k, true);
        var _likes = (_ru.pref == "damp") ? "likes it damp" : ((_ru.pref == "dry") ? "likes it dry" : "any going");
        var _gs = clamp(_h / 64, 0.8, 1.15), _sub = clamp(round(_h * 0.23), 13, 17), _tx = _nx + ((_ru.pref == "any") ? 30 : 16) * _gs;
        dby_mt__pref_glyph(_nx + 6 * _gs, _y + _h * 0.72, _ru.pref, _gs, _k);
        var _silks = dby_art_silk_name(_look.silk[0]) + " and " + dby_art_silk_name(_look.silk[1]);
        while (_sub > 11 && dby_mt__tw(_likes, _sub) + _sub * 1.2 + dby_mt__tw(_silks, _sub) > _fx0 - 16 - _tx) _sub -= 1;
        dby_mt__dots(_tx, _y + _h * 0.72, [_likes, _silks], _sub, _P.sub, fa_left, _k);
        var _form = dby_mt__form(_m, _ru), _nf = array_length(_form), _fp = clamp(round(_h * 0.3), 16, 22);
        for (var _f = 0; _f < 5; _f++) {
            var _idx = _nf - 5 + _f, _v = (_idx >= 0) ? _form[_idx] : undefined;
            dby_mt__t(_fx0 + _f * 24, _mid, is_undefined(_v) ? "-" : string((_v > 9) ? 0 : _v), _fp, (!is_undefined(_v) && _v == 1) ? _P.red : dby_art__hex("#2a1e14"), fa_center, fa_middle, _k, true);
        }
        dby_mt__paint_chalk(_m, _i, _k);
    }
    dby_mt__end(_L);
    return true;
}

/// @function dby_mt__job_chalks(meeting)
/// @description Re-chalk every price on the painted card (called once the book is priced). Internal.
function dby_mt__job_chalks(_m, _a) {
    if (!_m.layers.card.ok || !surface_exists(_m.layers.card.surf)) return dby_mt__job_card(_m, undefined);
    dby_mt__begin(_m.layers.card, false);
    for (var _i = 0; _i < array_length(_m.card.field); _i++) dby_mt__paint_chalk(_m, _i, DBY_MT_SS);
    dby_mt__end(_m.layers.card);
    return true;
}

/// @function dby_mt__job_map(meeting)
/// @description The little course map: a bar per section in its own surface, the start and the post. Internal.
function dby_mt__job_map(_m, _a) {
    var _L = _m.layers.map, _k = DBY_MT_SS, _c = _m.card.course, _P = dby_mt__pal(), _W = DBY_MT_RW - 6, _s;
    dby_mt__begin(_L);
    dby_mt__paper(0, 0, _W, 146, $C0A5, _k, _m.grain_paper);
    dby_mt__t(_W / 2, 32, string_upper(_c.name) + " COURSE", 15, _P.red, fa_center, fa_middle, _k, true);
    var _bx = 28, _bw = _W - 56, _by = 50, _bh = 40, _seen = {}, _names = [];
    for (_s = 0; _s < array_length(_c.sections); _s++) {
        var _q = _c.sections[_s], _sx = _bx + _q.from / DBY_LEN * _bw, _sw = (_q.to - _q.from) / DBY_LEN * _bw;
        dby_course_surface(_q.surface, _sx * _k, _by * _k, _sw * _k, _bh * _k, dby_rng($5EC + _s), _k);
        dby_k_rect_stroke((_sx + 0.5) * _k, (_by + 0.5) * _k, (_sw - 1) * _k, (_bh - 1) * _k, _k, make_colour_rgb(30, 20, 12), 0.6);
        if (!variable_struct_exists(_seen, _q.surface)) { _seen[$ _q.surface] = 1; array_push(_names, _q.surface); }
    }
    dby_k_rect((_bx - 2) * _k, (_by - 6) * _k, 2 * _k, (_bh + 12) * _k, _P.ink, 1);
    dby_k_rect((_bx + _bw) * _k, (_by - 6) * _k, 3 * _k, (_bh + 12) * _k, dby_art__hex("#c8202a"), 1);
    dby_mt__dots(_W / 2, _by + _bh + 22, _names, 15, _P.muted, fa_center, _k);
    dby_mt__end(_L);
    return true;
}

/// @function dby_mt__job_slip(meeting)
/// @description The bet slip: the runner, Win / Place, the stake stepper, what it returns, the purse, and the two
/// buttons. Its hit boxes (logical, relative to the slip) go to m.slip_boxes. Internal.
function dby_mt__job_slip(_m, _a) {
    var _L = _m.layers.slip, _k = DBY_MT_SS, _c = _m.card, _P = dby_mt__pal(), _W = DBY_MT_RW - 6, _i = _m.sel, _ru = _c.field[_i];
    dby_mt__begin(_L);
    dby_mt__paper(0, 0, _W, DBY_MT_SLIP_H, $511B, _k, _m.grain_paper);
    dby_mt__t(_W / 2, 36, "BET SLIP", 16, _P.red, fa_center, fa_middle, _k, true);
    dby_k_rect(32 * _k, 51 * _k, (_W - 64) * _k, 0.9 * _k, _P.red, 1);
    dby_art_cloth(_ru.look, _i + 1, 52 * _k, 86 * _k, 40 * _k, 30 * _k);
    var _np = dby_mt__fit(_ru.name, 24, 15, _W - 84 - 26, true);
    dby_mt__t(84, 86, _ru.name, _np, _P.ink, fa_left, fa_middle, _k, true);
    var _no_place = (_c.place_terms < 2) || (_c.priced && _c.place[_i] < 0);
    var _wt = _c.priced ? dby_price_text(_c.win[_i]) : "...", _pt = (_c.place_terms < 2) ? "-" : (_c.priced ? dby_price_text(_c.place[_i]) : "...");
    var _tabs = [["win", "WIN " + _wt], ["place", "PLACE " + _pt]], _tw = (_W - 48 - 12) / 2, _boxes = {};
    for (var _t = 0; _t < 2; _t++) {
        var _bx = 24 + _t * (_tw + 12), _on = (_m.type == _tabs[_t][0]), _dis = (_t == 1 && _no_place);
        dby_mt__rrect(_bx, 116, _tw, 40, 6, _on ? _P.ink : make_colour_rgb(30, 20, 12), _on ? 1 : 0.08, _k);
        dby_mt__rrect_line(_bx, 116, _tw, 40, 6, 1, _P.ink, 1, _k);
        dby_mt__t(_bx + _tw / 2, 136, _tabs[_t][1], 16, _on ? _P.cream : _P.ink, fa_center, fa_middle, _k, true, _dis ? 0.35 : 1);
        _boxes[$ _tabs[_t][0]] = [_bx, 116, _tw, 40];
    }
    dby_mt__t(_W / 2, 182, "Stake", 15, _P.sub, fa_center, fa_middle, _k);
    var _cyb = 220;
    dby_k_ellipse(60 * _k, _cyb * _k, 21 * _k, 21 * _k, 0, _P.red, 1);
    dby_k_ellipse((_W - 60) * _k, _cyb * _k, 21 * _k, 21 * _k, 0, _P.red, 1);
    dby_k_rect(51 * _k, (_cyb - 1.6) * _k, 18 * _k, 3.2 * _k, _P.cream, 1);
    dby_k_rect((_W - 69) * _k, (_cyb - 1.6) * _k, 18 * _k, 3.2 * _k, _P.cream, 1);
    dby_k_rect((_W - 61.6) * _k, (_cyb - 9) * _k, 3.2 * _k, 18 * _k, _P.cream, 1);
    _boxes.minus = [36, _cyb - 24, 48, 48]; _boxes.plus = [_W - 84, _cyb - 24, 48, 48];
    dby_mt__t(_W / 2, _cyb, (_m.stake > 0) ? string(_m.stake) + " " + _m.currency_short : "No bet", 34, _P.ink, fa_center, fa_middle, _k, true);
    var _ret = dby_mt__returns(_m);
    var _l1 = (_m.stake > 0) ? ((_ret > 0) ? "Returns " + string(_ret) + " " + _m.currency + " if it " + ((_m.type == "win") ? "wins" : "places") : (_c.priced ? "No price offered" : "Waiting for the prices")) : "Just watching this one";
    dby_mt__t(_W / 2, 262, _l1, 15, _P.sub, fa_center, fa_middle, _k);
    dby_mt__t(_W / 2, 286, "Purse: " + string(_m.purse) + " " + _m.currency, 15, _P.sub, fa_center, fa_middle, _k);
    var _ready = _c.priced;
    dby_mt__rrect(24, 308, _W - 48, 52, 6, _P.green, _ready ? 1 : 0.35, _k);
    var _go = "Off they go!";
    if (!_ready) {
        var _bk = _c.book, _pct = 0;
        if (is_struct(_bk)) _pct = floor(100 * (_bk.i * DBY_SOLO_N + _bk.s) / max(1, array_length(_c.field) * DBY_SOLO_N));
        _go = "Chalking the prices... " + string(min(99, _pct)) + "%";
    }
    dby_mt__t(_W / 2, 334, _go, _ready ? 23 : 18, _P.cream, fa_center, fa_middle, _k, true);
    dby_mt__rrect_line(24, 368, _W - 48, 30, 6, 1, _P.sub, 1, _k);
    dby_mt__t(_W / 2, 383, "Leave the course", 15, _P.sub, fa_center, fa_middle, _k);
    _boxes.go = [24, 308, _W - 48, 52]; _boxes.leave = [24, 368, _W - 48, 30];
    _m.slip_boxes = _boxes;
    dby_mt__end(_L);
    return true;
}

/// @function dby_mt__priced(meeting)
/// @description The book just finished: chalk the prices and redraw the slip. Internal.
function dby_mt__priced(_m) {
    _m.stats.cards_priced++;
    dby_mt__clamp_type(_m);
    dby_mt__queue(_m, "chalks", dby_mt__job_chalks, undefined, true);
    dby_mt__queue(_m, "slip", dby_mt__job_slip, undefined, true);
}

/// @function dby_mt__clamp_type(meeting)
function dby_mt__clamp_type(_m) { if (_m.type == "place" && (_m.card.place_terms < 2 || (_m.card.priced && _m.card.place[_m.sel] < 0))) _m.type = "win"; }

/// @function dby_mt__slip_now(meeting)
/// @description Redraw the slip THIS frame (a slip is small; the player sees the change at once). Internal.
function dby_mt__slip_now(_m) { dby_mt__job_slip(_m, undefined); }

// ---------------------------------------------------------------------------------------------------------------
// The race's sprites and furniture, baked while the card is read
// ---------------------------------------------------------------------------------------------------------------

/// @function dby_mt__job_runner(meeting, i)
/// @description Bake runner i's body (with its numbered cloth) and shell into two sprites at race scale. Internal.
function dby_mt__job_runner(_m, _i) {
    if (_i >= array_length(_m.card.field)) return true;
    var _s = _m.s, _look = _m.card.field[_i].look, _k = DBY_MT_SS;
    var _bw = ceil(100 * _s), _bh = ceil(64 * _s), _s2 = surface_create(_bw * _k, _bh * _k);
    surface_set_target(_s2); draw_clear_alpha(c_black, 0);
    var _bm = dby_art__blend_begin();
    dby_art__body(_look, _i + 1, 48 * _s * _k, 36 * _s * _k, _s * _k);
    dby_art__blend_end(_bm);
    surface_reset_target();
    _m.body[_i] = dby_mt__sprite_from(_s2, _bw, _bh, 48 * _s, 36 * _s);
    surface_free(_s2);
    var _sw = ceil(54 * _s), _s3 = surface_create(_sw * _k, _sw * _k);
    surface_set_target(_s3); draw_clear_alpha(c_black, 0);
    dby_art_shell(_look, _sw / 2 * _k, _sw / 2 * _k, _s * _k);
    surface_reset_target();
    _m.shell[_i] = dby_mt__sprite_from(_s3, _sw, _sw, _sw / 2, _sw / 2);
    surface_free(_s3);
    return true;
}

/// @function dby_mt__job_tex(meeting, name)
/// @description Bake one surface's seamless texture (kept for the whole meeting: courses share surfaces). Internal.
function dby_mt__job_tex(_m, _name) {
    var _k = DBY_MT_SS, _s2 = surface_create(DBY_TEX * _k, DBY_TEX * _k);
    surface_set_target(_s2); draw_clear_alpha(c_black, 0);
    dby_course_texture(_name, _k, _m.seed);
    surface_reset_target();
    _m.tex[$ _name] = sprite_create_from_surface(_s2, 0, 0, DBY_TEX * _k, DBY_TEX * _k, false, false, 0, 0);
    surface_free(_s2);
    return true;
}

/// @function dby_mt__job_scen(meeting)
function dby_mt__job_scen(_m, _a) {
    _m.scen = dby_course_scenery_layout(_m.card.course.theme, 0, _m.geo.w, 0, _m.geo.top, dby_rng((_m.card.race_seed ^ $C0) & $FFFFFFFF));
    return true;
}

/// @function dby_mt__job_tile(meeting, t)
/// @description Bake tile t of the course strip (DBY_MT_TILE_W wide) at 2x and keep it as a 1x sprite. Internal.
function dby_mt__job_tile(_m, _t) {
    var _g = _m.geo, _x0 = _t * DBY_MT_TILE_W, _x1 = min(_g.w, _x0 + DBY_MT_TILE_W), _tw = ceil(_x1 - _x0), _k = DBY_MT_SS;
    var _s2 = surface_create(_tw * _k, _g.h * _k), _m0 = matrix_get(matrix_world);
    surface_set_target(_s2); draw_clear_alpha(c_black, 0);
    matrix_set(matrix_world, matrix_build(-_x0 * _k, 0, 0, 0, 0, 0, _k, _k, 1));
    dby_course_strip_part(_m.card, _g, _x0, _x1, _m.tex, _m.scen);
    matrix_set(matrix_world, _m0);
    surface_reset_target();
    _m.tiles[_t] = dby_mt__sprite_from(_s2, _tw, _g.h, 0, 0);
    surface_free(_s2);
    return true;
}

/// @function dby_mt__job_furniture(meeting)
/// @description The race view's fixed furniture: the header with the progress strip, the lane board, each runner's dot
/// and the trail band. Internal.
function dby_mt__job_furniture(_m, _a) {
    dby_mt__paint_head_board(_m);
    var _c = _m.card, _k = DBY_MT_SS, _P = dby_mt__pal(), _n = array_length(_c.field), _i, _lh = _m.geo.lane_h;
    // dots: the first silk with the second at its heart and a dark rim
    for (_i = 0; _i < _n; _i++) {
        if (sprite_exists(_m.dot[_i])) continue;
        var _look = _c.field[_i].look, _d2 = surface_create(16 * _k, 16 * _k);
        surface_set_target(_d2); draw_clear_alpha(c_black, 0);
        var _bm = dby_art__blend_begin();
        dby_k_ellipse(8 * _k, 8 * _k, 6 * _k, 6 * _k, 0, dby_art_silk(_look.silk[0]), 1);
        dby_k_ellipse(8 * _k, 8 * _k, 2.7 * _k, 2.7 * _k, 0, dby_art_silk(_look.silk[1]), 1);
        dby_k_polyline(dby_k_ellipse_ring(8 * _k, 8 * _k, 6 * _k, 6 * _k, 0, 32), 1.2 * _k, _P.dark, 1, true);
        dby_art__blend_end(_bm);
        surface_reset_target();
        _m.dot[_i] = dby_mt__sprite_from(_d2, 16, 16, 8, 8);
        surface_free(_d2);
    }
    // the trail: a thin wet sheen with glints (a 0.55 band read as fog across every lane in the MZ product)
    if (!sprite_exists(_m.trail)) {
        var _th = max(6, round(_lh * 0.34)), _tr = surface_create(64, _th), _sheen = make_colour_rgb(225, 238, 250);
        surface_set_target(_tr); draw_clear_alpha(c_black, 0);
        var _bm2 = dby_art__blend_begin();
        dby_k_rect_grad(0, 0, 64, _th, 0, 0, 0, _th, [[0, c_white, 0], [0.5, _sheen, 0.26], [1, c_white, 0]]);
        for (var _gx = 3; _gx < 64; _gx += 16) dby_k_rect(_gx, _th * 0.45, 3, 1, c_white, 0.5);
        dby_art__blend_end(_bm2);
        surface_reset_target();
        _m.trail = sprite_create_from_surface(_tr, 0, 0, 64, _th, false, false, 0, _th / 2);
        surface_free(_tr);
    }
    return true;
}

/// @function dby_mt__paint_head_board(meeting)
/// @description Paint the race header (name, going, the progress strip) and the lane board. Internal.
function dby_mt__paint_head_board(_m) {
    var _c = _m.card, _k = DBY_MT_SS, _P = dby_mt__pal(), _n = array_length(_c.field), _W = DBY_MT_W, _i;
    // the header
    var _L = _m.layers.head;
    dby_mt__begin(_L);
    dby_k_rect_grad(0, 0, _W * _k, DBY_MT_HEAD_H * _k, 0, 0, 0, DBY_MT_HEAD_H * _k, [[0, dby_art__hex("#2a1a10"), 1], [1, dby_art__hex("#170d07"), 1]]);
    dby_k_rect(0, (DBY_MT_HEAD_H - 2) * _k, _W * _k, 2 * _k, _P.gold, 1);
    dby_mt__t(24, 26, _c.name, dby_mt__fit(_c.name, 26, 16, _W * 0.6, true), _P.goldt, fa_left, fa_middle, _k, true);
    var _going = string_upper(string_char_at(_c.going, 1)) + string_delete(_c.going, 1, 1);
    dby_mt__dots(_W - 24, 26, ["Going: " + _going, string(_n) + " ran"], 16, _P.goldm, fa_right, _k);
    var _sx = 80, _sw = _W - 160, _sy = 54, _sh = 14, _secs = _c.course.sections;
    dby_mt__rrect(_sx - 4, _sy - 4, _sw + 8, _sh + 8, 5, c_black, 0.5, _k);
    for (var _s = 0; _s < array_length(_secs); _s++) {
        var _qx = _sx + _secs[_s].from / DBY_LEN * _sw, _qw = (_secs[_s].to - _secs[_s].from) / DBY_LEN * _sw;
        dby_k_rect(_qx * _k, _sy * _k, _qw * _k, _sh * _k, dby_course__base(_secs[_s].surface)[0], 1);
        dby_k_rect(_qx * _k, _sy * _k, _qw * _k, 2 * _k, c_white, 0.18);
    }
    dby_k_rect((_sx - 1) * _k, (_sy - 3) * _k, 2 * _k, (_sh + 6) * _k, dby_art__hex("#fbf8f0"), 1);
    dby_k_rect((_sx + _sw - 1) * _k, (_sy - 3) * _k, 3 * _k, (_sh + 6) * _k, dby_art__hex("#c8202a"), 1);
    dby_mt__end(_L);
    // the lane board
    var _B = _m.layers.board, _lh = _m.geo.lane_h;
    _B.h = _n * _lh;
    dby_mt__begin(_B);
    for (_i = 0; _i < _n; _i++) {
        var _y = _i * _lh;
        dby_k_rect(0, (_y + 1) * _k, (DBY_MT_BOARD_W - 4) * _k, (_lh - 2) * _k, make_colour_rgb(20, 12, 6), 0.72);
        var _cw = min(40, DBY_MT_BOARD_W - 16);
        dby_art_cloth(_c.field[_i].look, _i + 1, (DBY_MT_BOARD_W / 2 - 2) * _k, (_y + _lh / 2) * _k, _cw * _k, min(29, _lh - 14) * _k);
    }
    dby_mt__end(_B);
}

/// @function dby_mt__paint_comment(meeting, text)
function dby_mt__paint_comment(_m, _text) {
    var _L = _m.layers.comment, _k = DBY_MT_SS, _W = DBY_MT_W, _H = _L.h, _P = dby_mt__pal();
    dby_mt__begin(_L);
    dby_k_rect_grad(0, 0, _W * _k, _H * _k, 0, 0, 0, _H * _k, [[0, make_colour_rgb(23, 13, 7), 0.94], [1, make_colour_rgb(10, 6, 3), 0.97]]);
    dby_k_rect(0, 0, _W * _k, 2 * _k, _P.gold, 1);
    dby_mt__t(_W / 2, _H / 2 + 1, _text, dby_mt__fit(_text, 24, 14, _W - 60), _P.goldt, fa_center, fa_middle, _k);
    dby_mt__end(_L);
}

/// @function dby_mt__say(meeting, text)
function dby_mt__say(_m, _text) {
    if (_text == _m.comment_text) return;
    _m.comment_text = _text;
    dby_mt__paint_comment(_m, _text);
    _m.comment_cool = 50;
}

// ---------------------------------------------------------------------------------------------------------------
// Input
// ---------------------------------------------------------------------------------------------------------------

/// @function dby_meeting_input()
/// @description The input dby_meeting_step reads when given none: arrows (or a gamepad's d-pad / left stick) move,
/// Shift, Q or W (or a shoulder button) switches Win / Place, Enter, Space or Z (or face button A) is OK and held it
/// speeds the race, Escape, X or Backspace (or B, or the right mouse button) leaves; the left mouse button clicks.
/// Pointer position is in GUI coordinates (draw the meeting in Draw GUI), and every field is a plain value, so you can
/// build this struct from your own input system instead:
///   {up, down, left, right, ok_held, click_held: HELD this frame; toggle, ok, cancel, click: PRESSED this frame; mx, my}
function dby_meeting_input() {
    var _gp = gamepad_is_connected(0), _ax = _gp ? gamepad_axis_value(0, gp_axislh) : 0, _ay = _gp ? gamepad_axis_value(0, gp_axislv) : 0;
    return {
        up: keyboard_check(vk_up) || (_gp && (gamepad_button_check(0, gp_padu) || _ay < -0.6)),
        down: keyboard_check(vk_down) || (_gp && (gamepad_button_check(0, gp_padd) || _ay > 0.6)),
        left: keyboard_check(vk_left) || (_gp && (gamepad_button_check(0, gp_padl) || _ax < -0.6)),
        right: keyboard_check(vk_right) || (_gp && (gamepad_button_check(0, gp_padr) || _ax > 0.6)),
        toggle: keyboard_check_pressed(vk_shift) || keyboard_check_pressed(ord("Q")) || keyboard_check_pressed(ord("W")) || (_gp && (gamepad_button_check_pressed(0, gp_shoulderl) || gamepad_button_check_pressed(0, gp_shoulderr))),
        ok: keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("Z")) || (_gp && gamepad_button_check_pressed(0, gp_face1)),
        ok_held: keyboard_check(vk_enter) || keyboard_check(vk_space) || keyboard_check(ord("Z")) || (_gp && gamepad_button_check(0, gp_face1)),
        cancel: keyboard_check_pressed(vk_escape) || keyboard_check_pressed(ord("X")) || keyboard_check_pressed(vk_backspace) || mouse_check_button_pressed(mb_right) || (_gp && gamepad_button_check_pressed(0, gp_face2)),
        click: mouse_check_button_pressed(mb_left), click_held: mouse_check_button(mb_left),
        mx: device_mouse_x_to_gui(0), my: device_mouse_y_to_gui(0)
    };
}

/// @function dby_mt__in(input, key)
/// @description A field of an input struct as a bool (a missing field is false). Internal.
function dby_mt__in(_in, _k) { return is_struct(_in) && variable_struct_exists(_in, _k) && (_in[$ _k] == true); }

/// @function dby_mt__rep(meeting, input, key)
/// @description A held direction that fires on press, then after 24 frames every 6 (a list cursor). Internal.
function dby_mt__rep(_m, _in, _k) {
    if (!dby_mt__in(_in, _k)) { _m.rep[$ _k] = 0; return false; }
    var _t = _m.rep[$ _k] + 1;
    _m.rep[$ _k] = _t;
    return (_t == 1) || (_t > 24 && ((_t - 24) mod 6) == 0);
}

/// @function dby_mt__pointer(meeting, input)
/// @description The pointer in the meeting's own 1280 x 720 coordinates, from where the last draw put it: [x, y]. Internal.
function dby_mt__pointer(_m, _in) {
    var _mx = (is_struct(_in) && variable_struct_exists(_in, "mx") && is_numeric(_in.mx)) ? _in.mx : -100000;
    var _my = (is_struct(_in) && variable_struct_exists(_in, "my") && is_numeric(_in.my)) ? _in.my : -100000;
    return [(_mx - _m.view.x) / _m.view.k, (_my - _m.view.y) / _m.view.k];
}

// ---------------------------------------------------------------------------------------------------------------
// Step
// ---------------------------------------------------------------------------------------------------------------

/// @function dby_meeting_step(meeting, [input])
/// @description Advance the meeting one frame; call it in a Step event. Returns the mode ("card", "race", "photo",
/// "result", "leaving", "done"). When it returns "done", read m.purse and m.net, then dby_meeting_free it.
function dby_meeting_step(_m, _in = undefined) {
    if (!is_struct(_m) || !variable_struct_exists(_m, "mode")) return "done";
    if (_m.mode == "done") return "done";
    if (is_undefined(_in)) _in = dby_meeting_input();
    _m.frame_no++;
    dby_mt__lost(_m);
    switch (_m.mode) {
        case "card": dby_mt__step_card(_m, _in); break;
        case "race": dby_mt__work(_m, _m.work_ms); dby_mt__step_race(_m, _in); break;
        case "photo":
            dby_mt__work(_m, _m.work_ms);
            _m.wait--;
            if (_m.wait <= 0 || (_m.wait < 110 && (dby_mt__in(_in, "ok") || dby_mt__in(_in, "click")))) dby_mt__show_result(_m);
            break;
        case "result":
            dby_mt__work(_m, _m.work_ms);
            if (_m.wait > 0) _m.wait--;
            else if (dby_mt__in(_in, "ok") || dby_mt__in(_in, "click")) dby_mt__next_race(_m);
            else if (dby_mt__in(_in, "cancel")) dby_mt__leave(_m);
            break;
        case "leaving":
            _m.fade++;
            if (_m.fade >= 20) { _m.mode = "done"; dby_mt__event(_m, "done"); }
            break;
    }
    // the next race's card is priced in the spare time of this one
    if (_m.mode != "card" && is_struct(_m.next_card) && !_m.next_card.priced) {
        var _t0 = get_timer();
        if (dby_work_book(_m.next_card, _m.book_ms)) _m.stats.cards_priced++;
        _m.stats.book_ms_total += (get_timer() - _t0) / 1000;
    }
    return _m.mode;
}

/// @function dby_mt__lost(meeting)
/// @description A surface can be lost (a device reset); repaint any layer this mode shows. Internal.
function dby_mt__lost(_m) {
    var _L = _m.layers;
    if (_L.table.ok && !surface_exists(_L.table.surf)) { _L.table.ok = false; dby_mt__queue(_m, "table", dby_mt__job_table, undefined, true); }
    if (_m.mode == "card") {
        if (_L.card.ok && !surface_exists(_L.card.surf)) { _L.card.ok = false; dby_mt__queue(_m, "card", dby_mt__job_card, undefined, true); }
        if (_L.map.ok && !surface_exists(_L.map.surf)) { _L.map.ok = false; dby_mt__queue(_m, "map", dby_mt__job_map, undefined, true); }
        if (_L.slip.ok && !surface_exists(_L.slip.surf)) { _L.slip.ok = false; dby_mt__queue(_m, "slip", dby_mt__job_slip, undefined, true); }
    } else if (_m.mode == "race" || _m.mode == "photo") {
        if ((_L.head.ok && !surface_exists(_L.head.surf)) || (_L.board.ok && !surface_exists(_L.board.surf))) { _L.head.ok = false; _L.board.ok = false; dby_mt__paint_head_board(_m); }
        if (_L.comment.ok && !surface_exists(_L.comment.surf)) dby_mt__paint_comment(_m, _m.comment_text);
        if (_m.mode == "photo" && !surface_exists(_m.photo)) { dby_mt__photo_jobs(_m); dby_mt__work_all(_m); }
    } else if (_m.mode == "result") {
        if (_L.result.ok && !surface_exists(_L.result.surf)) { _L.result.ok = false; dby_mt__result_jobs(_m); dby_mt__work_all(_m); }
    }
}

/// @function dby_mt__step_card(meeting, input)
function dby_mt__step_card(_m, _in) {
    var _c = _m.card, _n = array_length(_c.field);
    dby_mt__work(_m, _m.work_ms);
    if (!_c.priced) {
        var _t0 = get_timer(), _done = dby_work_book(_c, _m.book_ms);
        _m.stats.book_ms_total += (get_timer() - _t0) / 1000; _m.stats.book_frames++;
        if (_done) dby_mt__priced(_m);
        else {
            _m.slip_tick += 1;
            if (_m.slip_tick >= 20 && _m.layers.slip.ok) { _m.slip_tick = 0; dby_mt__slip_now(_m); }
        }
    }
    if (dby_mt__rep(_m, _in, "down")) { _m.sel = (_m.sel + 1) mod _n; dby_mt__cursor(_m); }
    else if (dby_mt__rep(_m, _in, "up")) { _m.sel = (_m.sel + _n - 1) mod _n; dby_mt__cursor(_m); }
    else if (dby_mt__rep(_m, _in, "right")) dby_mt__stake(_m, 1);
    else if (dby_mt__rep(_m, _in, "left")) dby_mt__stake(_m, -1);
    else if (dby_mt__in(_in, "toggle")) dby_mt__toggle(_m);
    else if (dby_mt__in(_in, "ok")) dby_mt__go(_m);
    else if (dby_mt__in(_in, "cancel")) dby_mt__leave(_m);
    else if (dby_mt__in(_in, "click")) { var _p = dby_mt__pointer(_m, _in); dby_mt__card_click(_m, _p[0], _p[1]); }
}

/// @function dby_mt__cursor(meeting)
function dby_mt__cursor(_m) { dby_mt__clamp_type(_m); dby_mt__slip_now(_m); dby_mt__event(_m, "cursor"); }

/// @function dby_mt__toggle(meeting)
function dby_mt__toggle(_m) { _m.type = (_m.type == "win") ? "place" : "win"; dby_mt__clamp_type(_m); dby_mt__slip_now(_m); dby_mt__event(_m, "cursor"); }

/// @function dby_mt__stake(meeting, dir)
/// @description Step the stake up or down, never past the purse; below the smallest stake it is "no bet". Internal.
function dby_mt__stake(_m, _dir) {
    var _s = _m.stake;
    if (_dir > 0) _s = (_s <= 0) ? _m.min_stake : min(_m.max_stake, _s + _m.stake_step);
    else _s = (_s - _m.stake_step < _m.min_stake) ? 0 : _s - _m.stake_step;
    if (_s > _m.purse) _s = (_m.purse >= _m.min_stake) ? max(_m.min_stake, floor(_m.purse / _m.stake_step) * _m.stake_step) : 0;
    if (_s > _m.purse) _s = 0;
    if (_s != _m.stake) { _m.stake = _s; dby_mt__slip_now(_m); dby_mt__event(_m, "stake"); }
}

/// @function dby_mt__card_click(meeting, x, y)
/// @description A click on the card screen at logical (x, y): a runner's row, the tabs, the stepper, the buttons. Internal.
function dby_mt__card_click(_m, _x, _y) {
    var _n = array_length(_m.card.field), _ry = _y - DBY_MT_CY - _m.row_top;
    if (_x >= DBY_MT_CX + 16 && _x <= DBY_MT_CX + DBY_MT_CW - 16 && _ry >= 0 && _ry < _n * _m.row_h) {
        var _i = floor(_ry / _m.row_h);
        if (_i != _m.sel) { _m.sel = _i; dby_mt__cursor(_m); }
        return;
    }
    var _B = _m.slip_boxes, _ox = DBY_MT_RX, _oy = DBY_MT_SLIP_Y;
    var _hit = function(_b, _x2, _y2, _ox2, _oy2) { return is_array(_b) && _x2 >= _ox2 + _b[0] && _x2 <= _ox2 + _b[0] + _b[2] && _y2 >= _oy2 + _b[1] && _y2 <= _oy2 + _b[1] + _b[3]; };
    if (_hit(_B[$ "win"], _x, _y, _ox, _oy)) { if (_m.type != "win") dby_mt__toggle(_m); }
    else if (_hit(_B[$ "place"], _x, _y, _ox, _oy)) { if (_m.type != "place") dby_mt__toggle(_m); }
    else if (_hit(_B[$ "minus"], _x, _y, _ox, _oy)) dby_mt__stake(_m, -1);
    else if (_hit(_B[$ "plus"], _x, _y, _ox, _oy)) dby_mt__stake(_m, 1);
    else if (_hit(_B[$ "go"], _x, _y, _ox, _oy)) dby_mt__go(_m);
    else if (_hit(_B[$ "leave"], _x, _y, _ox, _oy)) dby_mt__leave(_m);
}

/// @function dby_mt__leave(meeting)
function dby_mt__leave(_m) { if (_m.mode == "leaving" || _m.mode == "done") return; _m.mode = "leaving"; _m.fade = 0; dby_mt__event(_m, "leave"); }

// ---------------------------------------------------------------------------------------------------------------
// The race
// ---------------------------------------------------------------------------------------------------------------

/// @function dby_mt__go(meeting)
/// @description Place the bet (if any) and start the race: the same dby_tick the book priced the card with. Internal.
function dby_mt__go(_m) {
    var _c = _m.card;
    if (!_c.priced) return;
    dby_mt__work_all(_m);
    var _stake = min(_m.stake, _m.purse);
    if (dby_mt__returns(_m) <= 0) _stake = 0;
    _m.bet = (_stake > 0) ? { runner: _m.sel, type: _m.type, stake: _stake, rung: (_m.type == "win") ? _c.win[_m.sel] : _c.place[_m.sel] } : undefined;
    if (is_struct(_m.bet)) { _m.purse -= _stake; _m.net -= _stake; }
    _m.record.races++;
    var _n = array_length(_c.field), _i;
    _m.race = dby_reset_race(dby_make_race(_c.field, _c.course, _c.going), _c.race_seed);
    _m.run = []; _m.prev_st = array_create(_n, 0); _m.prev_sec = array_create(_n, 0);
    for (_i = 0; _i < _n; _i++) array_push(_m.run, { phase: _i * 1.7, bx: 0, sx: 1, sy: 1, hx: 0, hy: 0, rot: 0, tr: 0, lane_y: _m.geo.top + (_i + 0.62) * _m.geo.lane_h, dx: 0 });
    _m.acc = 0; _m.cam_x = 0; _m.prev_leader = -1; _m.finish_seen = false; _m.done_wait = 0; _m.comment_text = ""; _m.comment_cool = 0;
    _m.photo_shown = []; _m.res = undefined;
    dby_mt__say(_m, "They're under starter's orders... and they're off!");
    if (_m.race_idx + 1 < _m.races) { _m.next_card = dby_mt__open(_m, _m.race_idx + 1); _m.next_idx = _m.race_idx + 1; }
    _m.mode = "race";
    dby_mt__place(_m, 0);
    dby_mt__event(_m, "off");
}

/// @function dby_mt__words(surface)
function dby_mt__words(_s) {
    switch (_s) { case "moss": return "onto the moss, and it's quick"; case "slate": return "onto the slate"; case "sand": return "into the sand, heavy going";
        case "puddle": return "into the puddle!"; case "leaf": return "into the leaf litter"; case "gravel": return "over the gravel"; }
    return "on";
}

/// @function dby_mt__comment(meeting)
/// @description After each tick, find the one thing worth saying (a finish, a new leader, a stop for a nibble, a burst,
/// the leaders reaching a new surface). Internal.
function dby_mt__comment(_m) {
    var _race = _m.race, _c = _m.card, _rs = _race.runners, _i;
    if (_race.n_fin > 0 && !_m.finish_seen) {
        _m.finish_seen = true; var _w = _race.order[0]; _m.comment_cool = 0;
        dby_mt__say(_m, "No. " + string(_w + 1) + " " + _c.field[_w].name + " is first past the post!");
        dby_mt__event(_m, "finish"); return;
    }
    if (_race.n_fin > 0) return;
    var _said = false;
    if (_race.leader != _m.prev_leader && _race.t > 20 && _m.comment_cool <= 0) { _said = true; dby_mt__say(_m, "No. " + string(_race.leader + 1) + " " + _c.field[_race.leader].name + " takes the lead!"); dby_mt__event(_m, "lead"); }
    for (_i = 0; _i < _race.n; _i++) {
        var _st = _rs[_i].st;
        if (!_said && _m.comment_cool <= 0 && _st != _m.prev_st[_i]) {
            if (_st == 2) { _said = true; dby_mt__say(_m, _c.field[_i].name + " has stopped for a nibble!"); }
            else if (_st == 1 && _rs[_i].x > 120) { _said = true; dby_mt__say(_m, _c.field[_i].name + " finds a burst of speed!"); }
        }
        _m.prev_st[_i] = _st;
    }
    var _L = (_race.leader >= 0) ? _race.leader : 0;
    if (!_said && _m.comment_cool <= 0 && _rs[_L].sec != _m.prev_sec[_L]) dby_mt__say(_m, "The leaders go " + dby_mt__words(_c.course.sections[_rs[_L].sec].surface));
    for (_i = 0; _i < _race.n; _i++) _m.prev_sec[_i] = _rs[_i].sec;
    _m.prev_leader = _race.leader;
}

/// @function dby_mt__place(meeting, alpha)
/// @description Numbers only: where every runner's sprites go this frame, interpolated inside the tick, and the camera.
function dby_mt__place(_m, _alpha) {
    var _race = _m.race, _rs = _race.runners, _px = DBY_MT_PX, _s = _m.s, _best = 0;
    for (var _i = 0; _i < _race.n; _i++) {
        var _st = _rs[_i], _R = _m.run[_i];
        var _x = _st.prev_x + (_st.x - _st.prev_x) * _alpha, _nose = DBY_MT_START_X + _x * _px;
        if (_st.st != 2) _R.phase += 0.12 + _st.v * 0.05;
        var _wig = sin(_R.phase);
        // the sprite origin is the snail's own origin; its front (the stalk roots) is 40 units ahead of it
        _R.bx = _nose - 40 * _s; _R.sx = 1 + 0.035 * _wig; _R.sy = 1 - 0.02 * _wig;
        _R.hx = _R.bx - 6 * _s + 2 * _s * _wig; _R.hy = _R.lane_y - 8 * _s - abs(_wig) * 1.2 * _s;
        _R.rot = (_st.st == 2) ? -0.12 : 0.04 * _wig;
        _R.tr = max(0, (_R.bx - 36 * _s - DBY_MT_START_X) / 64);
        _R.dx = 80 + min(1, _x / DBY_LEN) * (DBY_MT_W - 160);
        if (_nose > _best) _best = _nose;
    }
    var _target = max(0, min(_m.geo.w - DBY_MT_W, _best - DBY_MT_W * 0.62));
    _m.cam_x += (_target - _m.cam_x) * 0.12;
}

/// @function dby_mt__step_race(meeting, input)
function dby_mt__step_race(_m, _in) {
    var _fast = dby_mt__in(_in, "ok_held") || dby_mt__in(_in, "click_held");
    _m.acc += _fast ? 3 : 1;
    while (_m.acc >= DBY_MT_TICK_FRAMES && !_m.race.done) {
        _m.acc -= DBY_MT_TICK_FRAMES;
        dby_tick(_m.race);
        dby_mt__comment(_m);
        if (_m.race.done) dby_mt__finish_jobs(_m);
    }
    if (_m.race.done) _m.acc = min(_m.acc, DBY_MT_TICK_FRAMES);
    if (_m.comment_cool > 0) _m.comment_cool--;
    dby_mt__place(_m, _m.race.done ? 1 : _m.acc / DBY_MT_TICK_FRAMES);
    if (_m.race.done) _m.done_wait += 1;
    if (_m.race.done && _m.done_wait > 40) {
        if (array_length(_m.photo_shown) > 0) {
            dby_mt__work_all(_m);
            _m.mode = "photo"; _m.wait = 150;
            dby_mt__say(_m, "Photograph! The judge is studying the print...");
            dby_mt__event(_m, "photo");
        } else dby_mt__show_result(_m);
    }
}

/// @function dby_mt__finish_jobs(meeting)
/// @description The race is over: work out the photograph (a close finish) and the result, and queue their drawing for
/// the frames while the field crawls home. Internal.
function dby_mt__finish_jobs(_m) {
    var _race = _m.race, _c = _m.card, _w = _race.runners[_race.order[0]], _k;
    _m.photo_shown = [];
    if (dby_margin_at(_race, 0) < 0.25) {
        for (_k = 0; _k < min(3, _race.n); _k++) {
            if (_k > 0 && dby_margin_at(_race, _k - 1) >= 0.25) break;
            var _r = _race.runners[_race.order[_k]];
            array_push(_m.photo_shown, { look: _c.field[_race.order[_k]].look, num: _race.order[_k] + 1, x: DBY_LEN - (_r.fin - _w.fin) * ((_r.v_fin != 0) ? _r.v_fin : DBY_BASE) });
        }
        dby_mt__photo_jobs(_m);
    }
    // the result, settled now so the board can be drawn ahead; it is APPLIED when the board is shown
    var _rows = [];
    for (_k = 0; _k < min(3, _race.n); _k++) {
        var _mg = dby_margin_at(_race, _k);
        array_push(_rows, { num: _race.order[_k] + 1, runner: _c.field[_race.order[_k]], sp: dby_price_text(_c.win[_race.order[_k]]),
            margin: (_k < 2 && _k + 1 < _race.n) ? ((_k == 0) ? "won by " : "beat the third by ") + dby_margin_words(_mg) : "" });
    }
    var _ret = is_struct(_m.bet) ? dby_settle(_c, _race, _m.bet) : 0, _won = _ret > 0, _bet = "", _detail = "";
    var _after = _m.purse + _ret, _more = (_m.race_idx + 1 < _m.races);
    if (is_struct(_m.bet)) {
        var _nm = _c.field[_m.bet.runner].name, _pr = dby_price_text(_m.bet.rung);
        _bet = _won ? "Your " + string(_m.bet.stake) + " " + _m.currency + ((_m.bet.type == "win") ? " to win" : " to place") + " on " + _nm + " returns " + string(_ret) + " " + _m.currency + "!"
            : "Your " + string(_m.bet.stake) + " " + _m.currency + " on " + _nm + " is lost.";
        _detail = [((_m.bet.type == "win") ? "Win" : "Place") + " at " + _pr, "purse now " + string(_after) + " " + _m.currency, _more ? _m.prompt_next : _m.prompt_leave];
    } else { _bet = "No bet on this one."; _detail = ["Purse " + string(_after) + " " + _m.currency, _more ? _m.prompt_next : _m.prompt_leave]; }
    _m.res = { rows: _rows, ret: _ret, won: _won, bet: _bet, detail: _detail, headline: "No. " + string(_rows[0].num) + " " + _rows[0].runner.name, applied: false };
    dby_mt__result_jobs(_m);
}

// ---------------------------------------------------------------------------------------------------------------
// The photograph
// ---------------------------------------------------------------------------------------------------------------

/// @function dby_mt__photo_jobs(meeting)
function dby_mt__photo_jobs(_m) {
    var _pw = 940, _ph = 400, _n = array_length(_m.photo_shown);
    var _lh = _ph / (_n + 0.3), _s = min(2.6, _lh / 58);
    _m.photo_geo = { pw: _pw, ph: _ph, x: (DBY_MT_W - _pw) / 2, y: 150, lh: _lh, s: _s, line: _pw * 0.64, scale: 3.2 * _s };
    dby_mt__queue(_m, "photo print", dby_mt__job_photo_base);
    for (var _i = 0; _i < _n; _i++) dby_mt__queue(_m, "photo runner", dby_mt__job_photo_runner, _i);
    dby_mt__queue(_m, "photo develop", dby_mt__job_photo_develop);
    for (var _j = 0; _j < _n; _j++) dby_mt__queue(_m, "photo tone", dby_mt__job_photo_tone, _j);
    dby_mt__queue(_m, "photo stamp", dby_mt__job_photo_stamp);
}

/// @function dby_mt__job_photo_base(meeting)
/// @description The print at 2x: the frame, the sepia ground, the grain, the strip camera's time lines, the line. Internal.
function dby_mt__job_photo_base(_m, _a) {
    var _G = _m.photo_geo, _k = DBY_MT_SS, _fw = _G.pw + 28, _fh = _G.ph + 64, _P = dby_mt__pal();
    if (surface_exists(_m.photo2)) surface_free(_m.photo2);
    _m.photo2 = surface_create(_fw * _k, _fh * _k);
    surface_set_target(_m.photo2); draw_clear_alpha(c_black, 0);
    var _bm = dby_art__blend_begin();
    dby_k_rect(0, 0, _fw * _k, (_fh - 6) * _k, dby_art__hex("#f4ecd8"), 1);
    dby_k_rect(4 * _k, (_fh - 6) * _k, _fw * _k, 6 * _k, c_black, 0.4);
    var _px = 14, _py = 14, _pw = _G.pw, _ph = _G.ph;
    dby_k_rect_grad(_px * _k, _py * _k, _pw * _k, _ph * _k, 0, _py * _k, 0, (_py + _ph) * _k, [[0, dby_art__hex("#d8c49a"), 1], [1, dby_art__hex("#8a7048"), 1]]);
    var _sd = _m.card.race_seed;
    if (!sprite_exists(_m.grain_print)) _m.grain_print = dby_mt__grain("print", _k);
    dby_mt__tile(_m.grain_print, _px * _k, _py * _k, (_px + _pw) * _k, (_py + _ph) * _k, (_sd mod 97) * 7, (_sd mod 89) * 5);
    dby_k_batch_begin();
    for (var _tx = _px + 20; _tx < _px + _pw; _tx += 40) dby_k_batch_rect(_tx * _k, _py * _k, _k, _ph * _k, make_colour_rgb(50, 34, 18), 0.25);
    dby_k_batch_end();
    dby_k_rect((_px + _G.line - 1.5) * _k, _py * _k, 3 * _k, _ph * _k, make_colour_rgb(250, 244, 228), 0.85);
    dby_art__blend_end(_bm);
    surface_reset_target();
    return true;
}

/// @function dby_mt__photo_box(meeting, i)
/// @description Where shown runner i sits on the print (1x, relative to the print frame): [nose x, y, box x0, y0, x1, y1].
function dby_mt__photo_box(_m, _i) {
    var _G = _m.photo_geo, _sh = _m.photo_shown[_i], _s = _G.s;
    var _y = 14 + (_i + 0.72) * _G.lh, _ox = 14 + _G.line + (_sh.x - DBY_LEN) * _G.scale - 40 * _s;
    return [_ox, _y, max(14, floor(_ox - 44 * _s)), max(14, floor(_y - 34 * _s)), min(14 + _G.pw, ceil(_ox + 50 * _s)), min(14 + _G.ph, ceil(_y + 28 * _s))];
}

/// @function dby_mt__job_photo_runner(meeting, i)
function dby_mt__job_photo_runner(_m, _i) {
    if (!surface_exists(_m.photo2)) return true;
    var _G = _m.photo_geo, _k = DBY_MT_SS, _b = dby_mt__photo_box(_m, _i), _sh = _m.photo_shown[_i], _sc = gpu_get_scissor();
    surface_set_target(_m.photo2);
    gpu_set_scissor(14 * _k, 14 * _k, _G.pw * _k, _G.ph * _k);
    dby_art_snail(_sh.look, _sh.num, _b[0] * _k, _b[1] * _k, _G.s * _k);
    gpu_set_scissor(_sc);
    surface_reset_target();
    return true;
}

/// @function dby_mt__job_photo_develop(meeting)
/// @description Filter the 2x print down to the 1x photograph and write its caption. Internal.
function dby_mt__job_photo_develop(_m, _a) {
    var _G = _m.photo_geo, _fw = _G.pw + 28, _fh = _G.ph + 64, _k = DBY_MT_SS, _P = dby_mt__pal();
    if (!surface_exists(_m.photo2)) { dby_mt__job_photo_base(_m, undefined); for (var _i = 0; _i < array_length(_m.photo_shown); _i++) dby_mt__job_photo_runner(_m, _i); }
    surface_set_target(_m.photo2);
    var _bm = dby_art__blend_begin();
    dby_mt__t(14, _G.ph + 14 + 24, "PHOTOGRAPH", 15, dby_art__hex("#3a2410"), fa_left, fa_middle, _k, true);
    var _w0 = dby_mt__tw("PHOTOGRAPH", 15, true);
    dby_k_ellipse((14 + _w0 + 12) * _k, (_G.ph + 14 + 25) * _k, 1.5 * _k, 1.5 * _k, 0, dby_art__hex("#3a2410"), 1);
    dby_mt__t(14 + _w0 + 24, _G.ph + 14 + 24, string_upper(_m.card.name), 15, dby_art__hex("#3a2410"), fa_left, fa_middle, _k, true);
    dby_mt__t(14 + _G.pw, _G.ph + 14 + 24, "the judge's print", 15, dby_art__hex("#3a2410"), fa_right, fa_middle, _k);
    dby_art__blend_end(_bm);
    surface_reset_target();
    if (surface_exists(_m.photo)) surface_free(_m.photo);
    _m.photo = surface_create(_fw, _fh);
    surface_set_target(_m.photo); draw_clear_alpha(c_black, 0);
    var _pb = gpu_get_blendmode_ext_sepalpha(), _tf = gpu_get_texfilter();
    gpu_set_blendmode_ext(bm_one, bm_zero); gpu_set_texfilter(true);
    draw_surface_ext(_m.photo2, 0, 0, 1 / _k, 1 / _k, 0, c_white, 1);
    gpu_set_texfilter(_tf); gpu_set_blendmode_ext_sepalpha(_pb[0], _pb[1], _pb[2], _pb[3]);
    surface_reset_target();
    surface_free(_m.photo2); _m.photo2 = -1;
    return true;
}

/// @function dby_mt__sepia_lut()
/// @description Luminance (0-255) -> a sepia colour as a little-endian RGBA u32. The ramp passes through the print's own
/// two ground colours at their own luminances (and the line's cream), so the ground is a FIXED POINT: toning a box of the
/// print round a runner leaves no edge where the box ends. Internal.
function dby_mt__sepia_lut() {
    static _lut = undefined;
    if (!is_undefined(_lut)) return _lut;
    _lut = array_create(256);
    var _st = [[0, 18, 12, 6], [115.3, 138, 112, 72], [197.3, 216, 196, 154], [244.2, 250, 244, 228], [255, 255, 252, 244]];
    for (var _l = 0; _l < 256; _l++) {
        var _j = 0;
        while (_j < array_length(_st) - 2 && _l > _st[_j + 1][0]) _j++;
        var _a = _st[_j], _b = _st[_j + 1], _t = clamp((_l - _a[0]) / max(0.001, _b[0] - _a[0]), 0, 1);
        var _r = round(_a[1] + (_b[1] - _a[1]) * _t), _g = round(_a[2] + (_b[2] - _a[2]) * _t), _bb = round(_a[3] + (_b[3] - _a[3]) * _t);
        _lut[_l] = _r | (_g << 8) | (_bb << 16) | ($FF << 24);
    }
    return _lut;
}

/// @function dby_mt__job_photo_tone(meeting, i)
/// @description Tone the box round shown runner i to sepia by luminance (the print's ground passes through unchanged).
/// ⛔ buffer_get_surface bytes are R, G, B, A and the buffer must hold the WHOLE surface (Doctrine_Craft section 13).
function dby_mt__job_photo_tone(_m, _i) {
    if (!surface_exists(_m.photo)) return true;
    var _b = dby_mt__photo_box(_m, _i), _w = surface_get_width(_m.photo), _h = surface_get_height(_m.photo), _lut = dby_mt__sepia_lut();
    var _buf = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_buf, _m.photo, 0);
    for (var _y = _b[3]; _y < _b[5]; _y++) {
        var _o = (_y * _w + _b[2]) * 4;
        for (var _x = _b[2]; _x < _b[4]; _x++) {
            var _v = buffer_peek(_buf, _o, buffer_u32);
            buffer_poke(_buf, _o, buffer_u32, _lut[(((_v & $FF) * 77 + ((_v >> 8) & $FF) * 150 + ((_v >> 16) & $FF) * 29) >> 8)]);
            _o += 4;
        }
    }
    buffer_set_surface(_buf, _m.photo, 0);
    buffer_delete(_buf);
    return true;
}

/// @function dby_mt__job_photo_stamp(meeting)
/// @description The judge's red stamp, over the toned print (ink is not sepia). Internal.
function dby_mt__job_photo_stamp(_m, _a) {
    if (!surface_exists(_m.photo)) return true;
    var _G = _m.photo_geo, _cx = 14 + _G.pw - 110, _cy = 14 + 52, _rot = -0.18, _c = cos(_rot), _s = sin(_rot), _red = dby_art__hex("#a8232a");
    surface_set_target(_m.photo);
    var _bm = dby_art__blend_begin();
    var _ring = dby_art__rrect(-88, -24, 176, 48, 6), _o = [];
    for (var _i = 0; _i < array_length(_ring); _i++) array_push(_o, [_cx + _ring[_i][0] * _c - _ring[_i][1] * _s, _cy + _ring[_i][0] * _s + _ring[_i][1] * _c]);
    dby_k_polyline(_o, 3, _red, 0.85, true);
    var _pf = draw_get_font(), _ph = draw_get_halign(), _pv = draw_get_valign(), _pc = draw_get_colour(), _pa = draw_get_alpha(), _tf = gpu_get_texfilter();
    draw_set_font(fnt_derby_title); draw_set_halign(fa_center); draw_set_valign(fa_middle); draw_set_colour(_red); draw_set_alpha(0.85); gpu_set_texfilter(true);
    var _sc = 24 / dby_k_font_px(fnt_derby_title);
    for (var _d = -0.4; _d <= 0.4; _d += 0.8) draw_text_transformed(_cx + _d, _cy + 1, "PHOTOGRAPH", _sc, _sc, -radtodeg(_rot));
    draw_set_font(_pf); draw_set_halign(_ph); draw_set_valign(_pv); draw_set_colour(_pc); draw_set_alpha(_pa); gpu_set_texfilter(_tf);
    dby_art__blend_end(_bm);
    surface_reset_target();
    return true;
}

// ---------------------------------------------------------------------------------------------------------------
// The winners' enclosure
// ---------------------------------------------------------------------------------------------------------------

/// @function dby_mt__rosette(cx, cy, R, place, k)
/// @description A rosette: ribbon tails, a pleated ring of twenty wedges and a centre disc with the placing. Internal.
function dby_mt__rosette(_cx, _cy, _R, _place, _k) {
    var _cols = ["#c8202a", "#1f4fb8", "#e0b020"], _col = dby_art__hex((_place >= 0 && _place < 3) ? _cols[_place] : "#6a6a6a"), _cream = dby_art__hex("#fbf5e6");
    for (var _t = -1; _t <= 1; _t += 2) {
        var _tail = [[_t * _R * 0.25, _R * 0.4], [_t * _R * 0.55, _R * 2.1], [_t * _R * 0.3, _R * 1.85], [_t * _R * 0.12, _R * 2.1], [_t * _R * 0.05, _R * 0.4]];
        for (var _q = 0; _q < 5; _q++) _tail[_q] = [(_cx + _tail[_q][0]) * _k, (_cy + _tail[_q][1]) * _k];
        dby_k_fill_rings([_tail], _col, 1);
    }
    for (var _i = 0; _i < 20; _i++) {
        var _a0 = _i / 20 * DBY_ART_TAU, _a1 = (_i + 1) / 20 * DBY_ART_TAU, _w = [[_cx * _k, _cy * _k]];
        for (var _j = 0; _j <= 4; _j++) { var _a = _a0 + (_a1 - _a0) * _j / 4; array_push(_w, [(_cx + cos(_a) * _R) * _k, (_cy + sin(_a) * _R) * _k]); }
        dby_k_fill_rings([_w], (_i mod 2) ? _col : _cream, 1);
    }
    dby_k_ellipse(_cx * _k, _cy * _k, _R * 0.62 * _k, _R * 0.62 * _k, 0, _col, 1);
    dby_k_polyline(dby_k_ellipse_ring(_cx * _k, _cy * _k, _R * 0.55 * _k, _R * 0.55 * _k, 0, 48), 1.4 * _k, dby_art__hex("#f6e3b4"), 1, true);
    var _lab = ["1st", "2nd", "3rd"];
    if (_place >= 0 && _place < 3) dby_mt__t(_cx, _cy + 1, _lab[_place], round(_R * 0.6), _cream, fa_center, fa_middle, _k, true);
}

/// @function dby_mt__result_jobs(meeting)
function dby_mt__result_jobs(_m) {
    dby_mt__queue(_m, "result board", dby_mt__job_result_base);
    for (var _i = 0; _i < array_length(_m.res.rows); _i++) dby_mt__queue(_m, "result runner", dby_mt__job_result_runner, _i);
}

/// @function dby_mt__job_result_base(meeting)
/// @description The result board: paper, the race, the headline, a row per placed runner with its rosette, starting
/// price and margin, and how the player's bet went. The runners themselves follow, one a frame. Internal.
function dby_mt__job_result_base(_m, _a) {
    var _L = _m.layers.result, _k = DBY_MT_SS, _c = _m.card, _R = _m.res, _P = dby_mt__pal(), _W = DBY_MT_W;
    var _x = 60, _y = 30, _w = _W - 120, _h = DBY_MT_H - 60, _i;
    dby_mt__begin(_L);
    dby_mt__paper(_x, _y, _w, _h, $2E5, _k, _m.grain_paper);
    dby_mt__dots(_W / 2, _y + 40, ["RESULT", string_upper(_c.name)], 16, _P.red, fa_center, _k, true);
    dby_mt__t(_W / 2, _y + 80, _R.headline, dby_mt__fit(_R.headline, 38, 22, _w - 120, true), _P.ink, fa_center, fa_middle, _k, true);
    dby_mt__dots(_W / 2, _y + 114, [_c.course.name + " course", "going " + _c.going, string(array_length(_c.field)) + " ran"], 17, _P.muted, fa_center, _k);
    var _sy = _y + _h - 100;
    dby_mt__rrect(_x + 50, _sy, _w - 100, 66, 6, _R.won ? _P.green : make_colour_rgb(30, 20, 12), _R.won ? 0.12 : 0.06, _k);
    dby_mt__t(_W / 2, _sy + 23, _R.bet, dby_mt__fit(_R.bet, 23, 15, _w - 140, true), _R.won ? _P.green : _P.ink, fa_center, fa_middle, _k, true);
    dby_mt__dots(_W / 2, _sy + 49, _R.detail, 16, _P.muted, fa_center, _k);
    dby_mt__end(_L);
    return true;
}

/// @function dby_mt__job_result_runner(meeting, i)
/// @description Placed runner i on the result board: its rosette, the runner, its name, number, starting price and
/// margin. Internal.
function dby_mt__job_result_runner(_m, _i) {
    var _L = _m.layers.result, _k = DBY_MT_SS, _R = _m.res, _row = _R.rows[_i], _P = dby_mt__pal(), _x = 60, _w = DBY_MT_W - 120, _ry = 30 + 138 + _i * 140;
    if (!_L.ok || !surface_exists(_L.surf)) { dby_mt__job_result_base(_m, undefined); return false; }
    dby_mt__begin(_L, false);
    dby_mt__rosette(_x + 96, _ry + 40, 34, _i, _k);
    dby_art_snail(_row.runner.look, _row.num, (_x + 250) * _k, (_ry + 62) * _k, 1.45 * _k);
    dby_mt__t(_x + 400, _ry + 44, _row.runner.name, 30, _P.ink, fa_left, fa_middle, _k, true);
    var _parts = ["No. " + string(_row.num), "starting price " + _row.sp];
    if (_row.margin != "") array_push(_parts, _row.margin);
    dby_mt__dots(_x + 400, _ry + 80, _parts, 17, _P.muted, fa_left, _k);
    if (_i < array_length(_R.rows) - 1) dby_k_rect((_x + 50) * _k, (_ry + 128) * _k, (_w - 100) * _k, _k, make_colour_rgb(30, 20, 12), 0.25);
    dby_mt__end(_L);
    return true;
}

/// @function dby_mt__show_result(meeting)
/// @description Pay the bet, write the form, and show the winners' enclosure. Internal.
function dby_mt__show_result(_m) {
    var _race = _m.race, _c = _m.card, _R = _m.res, _i;
    if (is_undefined(_R)) { dby_mt__finish_jobs(_m); _R = _m.res; }
    dby_mt__work_all(_m);
    if (!_R.applied) {
        _R.applied = true;
        for (_i = 0; _i < _race.n; _i++) {
            var _id = string(_c.field[_race.order[_i]].id);
            if (!variable_struct_exists(_m.record.form, _id)) _m.record.form[$ _id] = [];
            var _f = _m.record.form[$ _id];
            array_push(_f, _i + 1);
            if (array_length(_f) > 8) array_delete(_f, 0, array_length(_f) - 8);
        }
        _m.purse += _R.ret; _m.net += _R.ret;
        _m.record.net += _R.ret - (is_struct(_m.bet) ? _m.bet.stake : 0);
        if (is_struct(_m.bet)) dby_mt__event(_m, _R.won ? "win" : "lose");
    }
    _m.mode = "result"; _m.wait = 20;
}

/// @function dby_mt__next_race(meeting)
function dby_mt__next_race(_m) {
    _m.race_idx++;
    if (_m.race_idx >= _m.races) { _m.race_idx = _m.races - 1; dby_mt__leave(_m); return; }
    _m.layers.result.ok = false;
    dby_mt__new_card(_m);
}

// ---------------------------------------------------------------------------------------------------------------
// Drawing
// ---------------------------------------------------------------------------------------------------------------

/// @function dby_meeting_draw(meeting, x, y, w, h)
/// @description Compose the meeting's 1280 x 720 frame and draw it fitted (uniformly scaled, centred) into the
/// rectangle. Mouse clicks are mapped back through the same fit.
function dby_meeting_draw(_m, _x, _y, _w, _h) {
    if (!is_struct(_m) || !variable_struct_exists(_m, "frame") || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_h) || _w <= 0 || _h <= 0) return;
    if (_m.mode == "done") return;
    if (!surface_exists(_m.frame)) _m.frame = surface_create(DBY_MT_W, DBY_MT_H);
    surface_set_target(_m.frame);
    draw_clear_alpha(dby_art__hex("#170d07"), 1);
    var _mode = _m.mode;
    if (_mode == "leaving") _mode = is_struct(_m.race) && is_struct(_m.res) && _m.res.applied ? "result" : "card";
    if (_mode == "card") dby_mt__draw_card(_m);
    else if (_mode == "race" || _mode == "photo") dby_mt__draw_race(_m, _mode == "photo");
    else if (_mode == "result") { dby_mt__put(_m.layers.table, 0, 0); dby_mt__put(_m.layers.result, 0, 0); }
    if (_m.mode == "leaving") dby_k_rect(0, 0, DBY_MT_W, DBY_MT_H, c_black, clamp(_m.fade / 20, 0, 1));
    surface_reset_target();
    var _k = min(_w / DBY_MT_W, _h / DBY_MT_H), _ox = _x + (_w - DBY_MT_W * _k) / 2, _oy = _y + (_h - DBY_MT_H * _k) / 2;
    _m.view.x = _ox; _m.view.y = _oy; _m.view.k = _k;
    var _tf = gpu_get_texfilter();
    gpu_set_texfilter(true);
    draw_surface_ext(_m.frame, _ox, _oy, _k, _k, 0, c_white, 1);
    gpu_set_texfilter(_tf);
}

/// @function dby_mt__runner_at(meeting, i, x, y, scale)
/// @description Runner i at rest (body, then shell over it) at logical (x, y), `scale` times race size. Internal.
function dby_mt__runner_at(_m, _i, _x, _y, _sc) {
    if (_i >= array_length(_m.body) || _i >= array_length(_m.shell)) return;
    var _s = _m.s * _sc;
    dby_mt__spr(_m.body[_i], _x, _y, _sc, _sc, 0);
    dby_mt__spr(_m.shell[_i], _x - 6 * _s, _y - 8 * _s, _sc, _sc, 0);
}

/// @function dby_mt__draw_card(meeting)
function dby_mt__draw_card(_m) {
    var _P = dby_mt__pal(), _n = array_length(_m.card.field), _i;
    dby_mt__put(_m.layers.table, 0, 0);
    if (dby_mt__put(_m.layers.card, DBY_MT_CX, DBY_MT_CY)) {
        var _sc = (_m.row_h / 100) / _m.s;
        for (_i = 0; _i < _n; _i++) dby_mt__runner_at(_m, _i, DBY_MT_CX + 28 + 116 - 3 * (_m.row_h / 100), DBY_MT_CY + _m.row_top + _i * _m.row_h + _m.row_h * 0.58, _sc);
        var _px = DBY_MT_CX + 18, _pw = DBY_MT_CW - 36, _py = DBY_MT_CY + _m.row_top + _m.sel * _m.row_h, _ph = _m.row_h;
        // a MULTIPLY highlight, like a highlighter pen: the paper warms and the ink stays black. A 22% yellow laid OVER
        // the painted row washed the name, the runner and the price out (LOOKED AT, first card bake 2026-09-27)
        var _pbm = gpu_get_blendmode_ext_sepalpha();
        gpu_set_blendmode_ext(bm_dest_colour, bm_zero);
        dby_k_rect(_px, _py + 1, _pw, _ph - 2, make_colour_rgb(255, 234, 168), 1);
        gpu_set_blendmode_ext_sepalpha(_pbm[0], _pbm[1], _pbm[2], _pbm[3]);
        dby_k_rect_stroke(_px + 1, _py + 2, _pw - 2, _ph - 4, 2, _P.red, 0.85);
        dby_k_fill_rings([[[_px - 2, _py + _ph / 2 - 9], [_px + 9, _py + _ph / 2], [_px - 2, _py + _ph / 2 + 9]]], _P.red, 1);
    }
    dby_mt__put(_m.layers.map, DBY_MT_RX, DBY_MT_MAP_Y);
    dby_mt__put(_m.layers.slip, DBY_MT_RX, DBY_MT_SLIP_Y);
    var _hy = DBY_MT_SLIP_Y + DBY_MT_SLIP_H + 18;
    for (_i = 0; _i < array_length(_m.hints); _i++) dby_k_text(DBY_MT_RX + DBY_MT_RW / 2, _hy + _i * 23, _m.hints[_i], 15, _P.goldm, fa_center, fa_middle, fnt_derby);
}

/// @function dby_mt__draw_race(meeting, photo)
function dby_mt__draw_race(_m, _photo) {
    var _cam = round(_m.cam_x), _vy = DBY_MT_VIEW_Y, _g = _m.geo, _i, _n = array_length(_m.card.field);
    var _pb = gpu_get_blendmode_ext_sepalpha(), _tf = gpu_get_texfilter();
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); gpu_set_texfilter(false);
    for (var _t = 0; _t < array_length(_m.tiles); _t++) {
        var _spr = _m.tiles[_t];
        if (!sprite_exists(_spr)) continue;
        var _tx = _t * DBY_MT_TILE_W, _tw = sprite_get_width(_spr), _a = max(_tx, _cam), _b = min(_tx + _tw, _cam + DBY_MT_W);
        if (_b <= _a) continue;
        draw_sprite_part(_spr, 0, _a - _tx, 0, _b - _a, _g.h, _a - _cam, _vy);
    }
    gpu_set_texfilter(true);
    for (_i = 0; _i < _n; _i++) {
        var _R = _m.run[_i];
        if (sprite_exists(_m.trail) && _R.tr > 0) draw_sprite_ext(_m.trail, 0, DBY_MT_START_X - _cam, _vy + _R.lane_y + 12 * _m.s, _R.tr, 1, 0, c_white, 1);
        if (_i < array_length(_m.body) && sprite_exists(_m.body[_i])) draw_sprite_ext(_m.body[_i], 0, _R.bx - _cam, _vy + _R.lane_y, _R.sx, _R.sy, 0, c_white, 1);
        if (_i < array_length(_m.shell) && sprite_exists(_m.shell[_i])) draw_sprite_ext(_m.shell[_i], 0, _R.hx - _cam, _vy + _R.hy, 1, 1, -radtodeg(_R.rot), c_white, 1);
    }
    gpu_set_texfilter(_tf); gpu_set_blendmode_ext_sepalpha(_pb[0], _pb[1], _pb[2], _pb[3]);
    dby_mt__put(_m.layers.board, 0, _vy + _g.top);
    dby_mt__put(_m.layers.head, 0, 0);
    for (_i = 0; _i < _n; _i++) if (_i < array_length(_m.dot)) dby_mt__spr(_m.dot[_i], _m.run[_i].dx, 61, 1, 1, 0);
    dby_mt__put(_m.layers.comment, 0, DBY_MT_VIEW_Y + DBY_MT_VIEW_H);
    if (_photo && surface_exists(_m.photo)) {
        dby_k_rect(0, 0, DBY_MT_W, DBY_MT_H, c_black, 0.55);
        dby_mt__put(_m.layers.comment, 0, DBY_MT_VIEW_Y + DBY_MT_VIEW_H);
        var _G = _m.photo_geo, _pb2 = gpu_get_blendmode_ext_sepalpha();
        gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
        draw_surface(_m.photo, _G.x - 14, _G.y - 14);
        gpu_set_blendmode_ext_sepalpha(_pb2[0], _pb2[1], _pb2[2], _pb2[3]);
    }
}
