/// dby_art.gml - the runners: a racing snail's body, stalks, saddle cloth in its silks, and a logarithmic-spiral shell
/// with its own pattern, all drawn in code from the runner's `look` (dby_make_stable). No image file is loaded.
///
/// Derby - A Snail-Racing Betting Minigame, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// PUBLIC
///   dby_art_snail(look, num, x, y, s)    -> draw a whole runner (body, stalks, cloth, shell) around (x, y) at scale s
///   dby_art_shell(look, cx, cy, s)       -> the shell alone, centred on (cx, cy)
///   dby_art_cloth(look, num, cx, cy, w, h, [rot]) -> a saddle cloth in the runner's silks, its number on a white disc
///   dby_art_silk(i) / dby_art_silk_name(i) -> a silk colour and its name (12)
/// Every function draws into whatever target is set; draw a runner into a surface at 2x and filter it down for the
/// store look (GameMaker primitives are not antialiased: dby_draw's scanline fill carries edge coverage as alpha).
/// Ported from the RPG Maker MZ DerbyDraw.js (the same product family): same construction, same palette, same generator.

#macro DBY_ART_TAU 6.283185307179586

/// @function dby_art__blend_begin()
/// @description Switch to SEPARATE-ALPHA blending and return the caller's blend for dby_art__blend_end. Internal.
/// ⛔ Under the default blend a 35%-alpha mark also writes ALPHA (0.35 x 0.35 + 1 x 0.65 = 0.77), so a surface you draw
/// a runner or a course into turns partly transparent under every translucent mark, and when that surface is drawn out
/// the ground behind it shows through: dark sand ripples came out PALE on the first surfaces sheet (LOOKED AT, zoomed
/// 4x, 2026-09-27). Colour blends normally; alpha is src x 1 + dest x (1 - src), so an opaque ground stays opaque.
function dby_art__blend_begin() {
    var _b = gpu_get_blendmode_ext_sepalpha();
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    return _b;
}

/// @function dby_art__blend_end(blend)
/// @description Restore the blend dby_art__blend_begin returned. Internal.
function dby_art__blend_end(_b) { gpu_set_blendmode_ext_sepalpha(_b[0], _b[1], _b[2], _b[3]); }

/// @function dby_art__hex(str)
/// @description "#rrggbb" -> a GameMaker colour. Pure.
function dby_art__hex(_s) {
    var _d = "0123456789abcdef", _v = [0, 0, 0];
    _s = string_lower(_s);
    for (var _i = 0; _i < 3; _i++) _v[_i] = (string_pos(string_char_at(_s, 2 + _i * 2), _d) - 1) * 16 + (string_pos(string_char_at(_s, 3 + _i * 2), _d) - 1);
    return make_colour_rgb(max(0, _v[0]), max(0, _v[1]), max(0, _v[2]));
}

/// @function dby_art__shells()
function dby_art__shells() { return [["#e8b04a", "#8a4a12"], ["#c9d6e8", "#4a5a78"], ["#e37a5a", "#6b1f10"], ["#9ad07a", "#2f5a1c"], ["#d9c2f0", "#5a3a8a"],
    ["#f2e6c8", "#8a6a3a"], ["#8fd6cf", "#1f5a5a"], ["#f0b0c8", "#8a2f55"], ["#d8a878", "#5a3418"], ["#b8b8c0", "#2a2a36"]]; }
/// @function dby_art__bodies()
function dby_art__bodies() { return ["#c8a988", "#a8b8a0", "#d8b0a0", "#b0a0c0", "#c0b890"]; }
/// @function dby_art__silks()
function dby_art__silks() { return ["#c8202a", "#1f4fb8", "#1f8a4a", "#f0c020", "#f4f0e6", "#1a1a1e", "#6a2a9a", "#e8701a", "#5ab0e8", "#e86aa8", "#6a1420", "#9ad02a"]; }

/// @function dby_art_silk(i)
/// @description The colour of silk i (any integer; wraps). Pure.
function dby_art_silk(_i) { var _a = dby_art__silks(), _n = array_length(_a); _i = is_numeric(_i) ? floor(_i) : 0; return dby_art__hex(_a[((_i mod _n) + _n) mod _n]); }

/// @function dby_art_silk_name(i)
/// @description The name of silk i ("red", "royal blue", ...). Pure.
function dby_art_silk_name(_i) { var _a = ["red", "royal blue", "emerald", "gold", "white", "black", "purple", "orange", "sky blue", "pink", "maroon", "lime"]; _i = is_numeric(_i) ? floor(_i) : 0; return _a[((_i mod 12) + 12) mod 12]; }

// ---- geometry ------------------------------------------------------------------------------------------------------

/// @function dby_art__cubic(pts, x0, y0, x1, y1, x2, y2, x3, y3, n)
/// @description Append n points of a cubic Bezier (excluding its start) to pts. Internal.
function dby_art__cubic(_p, _x0, _y0, _x1, _y1, _x2, _y2, _x3, _y3, _n) {
    for (var _i = 1; _i <= _n; _i++) {
        var _t = _i / _n, _u = 1 - _t;
        array_push(_p, [_u * _u * _u * _x0 + 3 * _u * _u * _t * _x1 + 3 * _u * _t * _t * _x2 + _t * _t * _t * _x3, _u * _u * _u * _y0 + 3 * _u * _u * _t * _y1 + 3 * _u * _t * _t * _y2 + _t * _t * _t * _y3]);
    }
}

/// @function dby_art__quad(pts, x0, y0, x1, y1, x2, y2, n)
/// @description Append n points of a quadratic Bezier (excluding its start) to pts. Internal.
function dby_art__quad(_p, _x0, _y0, _x1, _y1, _x2, _y2, _n) {
    for (var _i = 1; _i <= _n; _i++) { var _t = _i / _n, _u = 1 - _t; array_push(_p, [_u * _u * _x0 + 2 * _u * _t * _x1 + _t * _t * _x2, _u * _u * _y0 + 2 * _u * _t * _y1 + _t * _t * _y2]); }
}

/// @function dby_art__rrect(x, y, w, h, r)
/// @description A rounded rectangle as a ring (the canvas path: straight edges, quadratic corners). Pure.
function dby_art__rrect(_x, _y, _w, _h, _r) {
    _r = max(0, min(_r, _w / 2, _h / 2));
    var _p = [[_x + _r, _y]];
    array_push(_p, [_x + _w - _r, _y]); dby_art__quad(_p, _x + _w - _r, _y, _x + _w, _y, _x + _w, _y + _r, 5);
    array_push(_p, [_x + _w, _y + _h - _r]); dby_art__quad(_p, _x + _w, _y + _h - _r, _x + _w, _y + _h, _x + _w - _r, _y + _h, 5);
    array_push(_p, [_x + _r, _y + _h]); dby_art__quad(_p, _x + _r, _y + _h, _x, _y + _h, _x, _y + _h - _r, 5);
    array_push(_p, [_x, _y + _r]); dby_art__quad(_p, _x, _y + _r, _x, _y, _x + _r, _y, 4);
    return _p;
}

/// @function dby_art__clip(ring, clip)
/// @description A ring clipped to a CONVEX ring (Sutherland-Hodgman); either winding. Pure.
function dby_art__clip(_ring, _clip) {
    var _n = array_length(_clip), _area = 0, _i;
    for (_i = 0; _i < _n; _i++) { var _a = _clip[_i], _b = _clip[(_i + 1) mod _n]; _area += _a[0] * _b[1] - _b[0] * _a[1]; }
    var _sg = (_area >= 0) ? 1 : -1, _out = _ring;
    for (_i = 0; _i < _n && array_length(_out) > 0; _i++) {
        var _e0 = _clip[_i], _e1 = _clip[(_i + 1) mod _n], _in = _out, _m = array_length(_in);
        _out = [];
        for (var _j = 0; _j < _m; _j++) {
            var _p = _in[_j], _q = _in[(_j + 1) mod _m];
            var _dp = _sg * ((_e1[0] - _e0[0]) * (_p[1] - _e0[1]) - (_e1[1] - _e0[1]) * (_p[0] - _e0[0]));
            var _dq = _sg * ((_e1[0] - _e0[0]) * (_q[1] - _e0[1]) - (_e1[1] - _e0[1]) * (_q[0] - _e0[0]));
            if (_dp >= 0) array_push(_out, _p);
            if ((_dp >= 0) != (_dq >= 0)) { var _t = _dp / (_dp - _dq); array_push(_out, [_p[0] + (_q[0] - _p[0]) * _t, _p[1] + (_q[1] - _p[1]) * _t]); }
        }
    }
    return _out;
}

/// @function dby_art__seg_ring(x1, y1, x2, y2, w)
/// @description A straight stroke `w` wide as a ring (butt ends). Pure.
function dby_art__seg_ring(_x1, _y1, _x2, _y2, _w) {
    var _dx = _x2 - _x1, _dy = _y2 - _y1, _l = max(0.0001, sqrt(_dx * _dx + _dy * _dy)), _nx = -_dy / _l * _w * 0.5, _ny = _dx / _l * _w * 0.5;
    return [[_x1 + _nx, _y1 + _ny], [_x2 + _nx, _y2 + _ny], [_x2 - _nx, _y2 - _ny], [_x1 - _nx, _y1 - _ny]];
}

/// @function dby_art__fill_clipped(ring, clip, colour, alpha)
function dby_art__fill_clipped(_ring, _clip, _col, _alpha) { var _c = dby_art__clip(_ring, _clip); if (array_length(_c) >= 3) dby_k_fill_rings([_c], _col, _alpha); }

// ---- the saddle cloth ----------------------------------------------------------------------------------------------

/// @function dby_art_cloth(look, num, cx, cy, w, h, [rot])
/// @description A saddle cloth in the runner's silks and cloth pattern (plain, hoops, halves, sash, quarters, chevron),
/// its number on a white disc (num undefined = no number), centred on (cx, cy) and turned by rot radians.
function dby_art_cloth(_look, _num, _cx, _cy, _w, _h, _rot = 0) {
    if (!is_struct(_look) || !variable_struct_exists(_look, "silk") || !is_numeric(_cx) || !is_numeric(_cy) || !is_numeric(_w) || !is_numeric(_h) || _w <= 0 || _h <= 0 || _w > 4000 || _h > 4000) return;
    if (!is_numeric(_rot)) _rot = 0;
    var _bm = dby_art__blend_begin();
    var _a = dby_art_silk(_look.silk[0]), _b = dby_art_silk(_look.silk[1]), _x = -_w / 2, _y = -_h / 2, _c = cos(_rot), _s = sin(_rot);
    var _tr = function(_ring, _cx2, _cy2, _c2, _s2) { var _o = array_create(array_length(_ring)); for (var _k = 0; _k < array_length(_ring); _k++) _o[_k] = [_cx2 + _ring[_k][0] * _c2 - _ring[_k][1] * _s2, _cy2 + _ring[_k][0] * _s2 + _ring[_k][1] * _c2]; return _o; };
    var _box = dby_art__rrect(_x, _y, _w, _h, max(1, _h * 0.18)), _shape = _tr(_box, _cx, _cy, _c, _s);
    dby_k_fill_rings([_shape], _a, 1);
    var _parts = [], _cl = _look.cloth;
    if (_cl == "hoops") { for (var _i = 1; _i < 4; _i += 2) array_push(_parts, [[_x, _y + _i * _h / 4], [_x + _w, _y + _i * _h / 4], [_x + _w, _y + (_i + 1) * _h / 4], [_x, _y + (_i + 1) * _h / 4]]); }
    else if (_cl == "halves") array_push(_parts, [[_x + _w / 2, _y], [_x + _w, _y], [_x + _w, _y + _h], [_x + _w / 2, _y + _h]]);
    else if (_cl == "sash") array_push(_parts, [[_x, _y + _h * 0.1], [_x + _w * 0.3, _y], [_x + _w, _y + _h * 0.9], [_x + _w * 0.7, _y + _h]]);
    else if (_cl == "quarters") { array_push(_parts, [[_x + _w / 2, _y], [_x + _w, _y], [_x + _w, _y + _h / 2], [_x + _w / 2, _y + _h / 2]]); array_push(_parts, [[_x, _y + _h / 2], [_x + _w / 2, _y + _h / 2], [_x + _w / 2, _y + _h], [_x, _y + _h]]); }
    else if (_cl == "chevron") array_push(_parts, [[_x, _y + _h * 0.2], [_x + _w / 2, _y + _h * 0.7], [_x + _w, _y + _h * 0.2], [_x + _w, _y + _h * 0.55], [_x + _w / 2, _y + _h], [_x, _y + _h * 0.55]]);
    for (var _p = 0; _p < array_length(_parts); _p++) {
        // a chevron is concave: clip the SHAPE (convex) to it by clipping the part to the shape, part by part is exact
        // for the convex parts; the chevron is split into its two convex halves first
        var _pr = _parts[_p];
        if (_cl == "chevron") {
            dby_art__fill_clipped(_tr([_pr[0], _pr[1], _pr[4], _pr[5]], _cx, _cy, _c, _s), _shape, _b, 1);
            dby_art__fill_clipped(_tr([_pr[1], _pr[2], _pr[3], _pr[4]], _cx, _cy, _c, _s), _shape, _b, 1);
        } else dby_art__fill_clipped(_tr(_pr, _cx, _cy, _c, _s), _shape, _b, 1);
    }
    dby_k_polyline(_shape, max(0.8, _h * 0.06), make_colour_rgb(30, 18, 8), 0.8, true);
    if (!is_undefined(_num)) {
        var _R = _h * 0.36;
        dby_k_ellipse(_cx, _cy, _R * 1.25, _R, _rot, make_colour_rgb(251, 248, 240), 1);
        dby_k_polyline(dby_k_ellipse_ring(_cx, _cy, _R * 1.25, _R, _rot), max(0.6, _h * 0.04), make_colour_rgb(30, 18, 8), 0.7, true);
        // the number is double-struck from the 26 px face: the 120 px display face shrunk to ~9 px read thin beside the
        // MZ product's bold numerals (LOOKED AT, first runner sheet 2026-09-27)
        var _px = max(6, round(_h * 0.56)), _bx = max(0.5, _px * 0.06), _tx = _cx - _s * _h * 0.03, _ty = _cy + _c * _h * 0.03;
        dby_k_text(_tx - _bx * 0.5, _ty, string(_num), _px, make_colour_rgb(26, 18, 8), fa_center, fa_middle, fnt_derby);
        dby_k_text(_tx + _bx * 0.5, _ty, string(_num), _px, make_colour_rgb(26, 18, 8), fa_center, fa_middle, fnt_derby);
    }
    dby_art__blend_end(_bm);
}

// ---- the body ------------------------------------------------------------------------------------------------------

/// @function dby_art__body(look, num, ox, oy, s)
/// @description The body, stalks and saddle cloth (no shell) around (ox, oy) at scale s. Internal.
function dby_art__body(_look, _num, _ox, _oy, _s) {
    var _bodies = dby_art__bodies(), _body = dby_art__hex(_bodies[((_look.body mod 5) + 5) mod 5]);
    dby_k_ellipse(_ox + 2 * _s, _oy + 20 * _s, 44 * _s, 5.5 * _s, 0, c_black, 0.28);
    var _p = [[_ox - 40 * _s, _oy + 18 * _s]];
    dby_art__cubic(_p, _ox - 40 * _s, _oy + 18 * _s, _ox - 34 * _s, _oy + 6 * _s, _ox + 10 * _s, _oy + 6 * _s, _ox + 26 * _s, _oy + 2 * _s, 16);
    dby_art__cubic(_p, _ox + 26 * _s, _oy + 2 * _s, _ox + 36 * _s, _oy - 2 * _s, _ox + 42 * _s, _oy + 8 * _s, _ox + 38 * _s, _oy + 16 * _s, 12);
    dby_art__cubic(_p, _ox + 38 * _s, _oy + 16 * _s, _ox + 30 * _s, _oy + 22 * _s, _ox - 10 * _s, _oy + 23 * _s, _ox - 40 * _s, _oy + 18 * _s, 16);
    array_pop(_p);
    dby_k_fill_rings([_p], c_white, 1, { x0: _ox, y0: _oy, x1: _ox, y1: _oy + 24 * _s, stops: [[0, dby_art__hex("#fff6ea"), 1], [0.3, _body, 1], [1, dby_art__hex("#3a2c20"), 1]] });
    dby_k_polyline(_p, max(0.7, _s), make_colour_rgb(40, 28, 18), 0.6, true);
    var _ridge = [[_ox - 28 * _s, _oy + 11 * _s]];
    dby_art__quad(_ridge, _ox - 28 * _s, _oy + 11 * _s, _ox + 8 * _s, _oy + 7 * _s, _ox + 30 * _s, _oy + 4 * _s, 12);
    dby_k_polyline(_ridge, 1.4 * _s, c_white, 0.55);
    var _roots = [[26, -5], [33, 7]];
    for (var _k = 0; _k < 2; _k++) {
        var _rx = _roots[_k][0], _dx = _roots[_k][1], _st = [[_ox + _rx * _s, _oy + 4 * _s]];
        dby_art__quad(_st, _ox + _rx * _s, _oy + 4 * _s, _ox + (_rx + _dx * 0.3) * _s, _oy - 8 * _s, _ox + (_rx + _dx) * _s, _oy - 18 * _s, 10);
        dby_k_polyline(_st, 3.2 * _s, _body, 1);
        dby_k_ellipse(_st[0][0], _st[0][1], 1.6 * _s, 1.6 * _s, 0, _body, 1);
        dby_k_ellipse(_ox + (_rx + _dx) * _s, _oy - 19 * _s, 3 * _s, 3 * _s, 0, make_colour_rgb(26, 18, 8), 1);
        dby_k_ellipse(_ox + (_rx + _dx - 1) * _s, _oy - 20 * _s, 0.9 * _s, 0.9 * _s, 0, c_white, 1);
    }
    dby_art_cloth(_look, _num, _ox + 14 * _s, _oy + 13 * _s, 22 * _s, 13 * _s, -0.08);
}

// ---- the shell -----------------------------------------------------------------------------------------------------

/// @function dby_art__radial_t(px, py, x0, y0, r0, x1, y1, r1)
/// @description The canvas two-circle radial gradient's t at a point (the largest t whose circle passes through it). Pure.
function dby_art__radial_t(_px, _py, _x0, _y0, _r0, _x1, _y1, _r1) {
    var _cdx = _x1 - _x0, _cdy = _y1 - _y0, _dr = _r1 - _r0, _pdx = _px - _x0, _pdy = _py - _y0;
    var _a = _cdx * _cdx + _cdy * _cdy - _dr * _dr, _b = _pdx * _cdx + _pdy * _cdy + _r0 * _dr, _c = _pdx * _pdx + _pdy * _pdy - _r0 * _r0;
    if (abs(_a) < 0.0001) return (abs(_b) < 0.0001) ? 0 : _c / (2 * _b);
    var _disc = _b * _b - _a * _c;
    if (_disc < 0) return 0;
    var _sq = sqrt(_disc), _t1 = (_b + _sq) / _a, _t2 = (_b - _sq) / _a, _t = max(_t1, _t2);
    if (_r0 + _t * _dr < 0) _t = min(_t1, _t2);
    return _t;
}

/// @function dby_art_shell(look, cx, cy, s)
/// @description A runner's shell centred on (cx, cy) at scale s: a radial-lit disc, its pattern (bands, spots, flames or
/// rays) at 55% clipped to the disc, a logarithmic spiral of the runner's tightness, a highlight and a rim.
function dby_art_shell(_look, _cx, _cy, _s) {
    if (!is_struct(_look) || !variable_struct_exists(_look, "shell") || !is_numeric(_cx) || !is_numeric(_cy) || !is_numeric(_s) || _s <= 0 || _s > 100) return;
    var _bm = dby_art__blend_begin();
    var _shells = dby_art__shells(), _sh =_shells[((_look.shell mod 10) + 10) mod 10], _R = 22 * _s, _r = dby_rng(_look.seed);
    var _c0 = dby_art__hex(_sh[0]), _c1 = dby_art__hex(_sh[1]);
    var _stops = [[0, dby_art__hex("#fffaf0"), 1], [0.3, _c0, 1], [1, _c1, 1]];
    var _fx = _cx - _R * 0.35, _fy = _cy - _R * 0.4, _K = 10, _A = 48, _k, _j, _v = 0;
    // the lit disc: a polar mesh whose every vertex takes the canvas gradient's colour at its own point. Each GRID vertex
    // is lit once and shared by its four quads (it was lit once per quad corner: 1,920 gradient solves a shell instead
    // of 528, and the shell was most of a runner's ~40 ms on the VM - MEASURED, Derby suite 2026-09-27)
    var _gx = array_create((_K + 1) * _A), _gy = array_create((_K + 1) * _A), _gc = array_create((_K + 1) * _A);
    for (_k = 0; _k <= _K; _k++) for (_j = 0; _j < _A; _j++) {
        var _ra = _R * _k / _K, _aa = _j / _A * DBY_ART_TAU, _ix = _k * _A + _j;
        _gx[_ix] = _cx + cos(_aa) * _ra; _gy[_ix] = _cy + sin(_aa) * _ra;
        _gc[_ix] = dby_k_grad_at(_stops, dby_art__radial_t(_gx[_ix], _gy[_ix], _fx, _fy, 1, _cx, _cy, _R))[0];
    }
    draw_primitive_begin(pr_trianglelist);
    for (_k = 0; _k < _K; _k++) for (_j = 0; _j < _A; _j++) {
        if (_v >= 900) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); _v = 0; }
        var _i0 = _k * _A + _j, _i1 = _k * _A + ((_j + 1) mod _A), _i2 = _i0 + _A, _i3 = _i1 + _A;
        draw_vertex_colour(_gx[_i0], _gy[_i0], _gc[_i0], 1); draw_vertex_colour(_gx[_i1], _gy[_i1], _gc[_i1], 1); draw_vertex_colour(_gx[_i2], _gy[_i2], _gc[_i2], 1);
        draw_vertex_colour(_gx[_i1], _gy[_i1], _gc[_i1], 1); draw_vertex_colour(_gx[_i3], _gy[_i3], _gc[_i3], 1); draw_vertex_colour(_gx[_i2], _gy[_i2], _gc[_i2], 1);
        _v += 6;
    }
    draw_primitive_end();
    var _disc = dby_k_ellipse_ring(_cx, _cy, _R - 0.5, _R - 0.5, 0, 64), _pat = _look.pattern, _cream = dby_art__hex("#fff6e0");
    if (_pat == "bands") {
        for (var _b = 0; _b < _look.bands; _b++) {
            var _rr0 = _R * (0.35 + _b * 0.6 / _look.bands), _col = (_b mod 2) ? c_white : _c1;
            var _o = dby_art__clip(dby_k_ellipse_ring(_cx, _cy, _rr0 + 1.5 * _s, _rr0 + 1.5 * _s, 0, 64), _disc), _i2 = dby_art__clip(dby_k_ellipse_ring(_cx, _cy, _rr0 - 1.5 * _s, _rr0 - 1.5 * _s, 0, 64), _disc);
            dby_k_fill_rings([_o, _i2], _col, 0.55);
        }
    } else if (_pat == "spots") {
        for (var _sp = 0; _sp < 9; _sp++) {
            // ⛔ three draws in three statements, in the MZ order (an array literal of stateful calls runs right to left)
            var _an = dby_rnd(_r) * DBY_ART_TAU;
            var _d = _R * (0.3 + dby_rnd(_r) * 0.6);
            var _rad = (2 + dby_rnd(_r) * 2.5) * _s;
            dby_art__fill_clipped(dby_k_ellipse_ring(_cx + cos(_an) * _d, _cy + sin(_an) * _d, _rad, _rad, 0), _disc, (_sp mod 2) ? _c1 : _cream, 0.55);
        }
    } else if (_pat == "flames") {
        for (var _f = 0; _f < 7; _f++) {
            var _a0 = _f / 7 * DBY_ART_TAU, _px = 0, _py = 0;
            for (var _qq = 0; _qq <= 6; _qq++) {
                var _dd = _R * (0.2 + _qq * 0.13), _ang = _a0 + ((_qq mod 2) ? 0.18 : -0.18), _nx = _cx + cos(_ang) * _dd, _ny = _cy + sin(_ang) * _dd;
                if (_qq > 0) dby_art__fill_clipped(dby_art__seg_ring(_px, _py, _nx, _ny, 2 * _s), _disc, _c1, 0.55);
                _px = _nx; _py = _ny;
            }
        }
    } else {
        for (var _ry = 0; _ry < 10; _ry++) {
            var _rn = _ry / 10 * DBY_ART_TAU + 0.2;
            dby_art__fill_clipped(dby_art__seg_ring(_cx + cos(_rn) * _R * 0.25, _cy + sin(_rn) * _R * 0.25, _cx + cos(_rn + 0.35) * _R, _cy + sin(_rn + 0.35) * _R, 2.4 * _s), _disc, (_ry mod 2) ? dby_art__hex("#fff8e8") : _c1, 0.55);
        }
    }
    var _spiral = [], _t = 0;
    while (_t <= 3.4 * DBY_ART_TAU) { var _r0 = _R * exp(-_look.tight * _t); array_push(_spiral, [_cx + _r0 * cos(_t + 2.2), _cy + _r0 * sin(_t + 2.2)]); _t += 0.06; }
    dby_k_polyline(_spiral, 1.8 * _s, make_colour_rgb(40, 20, 5), 0.6);
    dby_k_ellipse(_cx - _R * 0.42, _cy - _R * 0.45, _R * 0.22, _R * 0.12, -0.6, c_white, 0.45);
    dby_k_polyline(dby_k_ellipse_ring(_cx, _cy, _R, _R, 0, 72), max(0.7, _s), make_colour_rgb(30, 14, 4), 0.55, true);
    dby_art__blend_end(_bm);
}

/// @function dby_art_snail(look, num, x, y, s)
/// @description A whole runner around (x, y) at scale s (about 90 x 50 px at s = 1): body, stalks, saddle cloth with
/// number `num` (undefined = none) and the shell. `look` is a runner's .look from dby_make_stable.
function dby_art_snail(_look, _num, _x, _y, _s) {
    if (!is_struct(_look) || !variable_struct_exists(_look, "shell") || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_s) || _s <= 0 || _s > 100) return;
    var _bm = dby_art__blend_begin();
    dby_art__body(_look, _num, _x, _y, _s);
    dby_art_shell(_look, _x - 6 * _s, _y - 8 * _s, _s);
    dby_art__blend_end(_bm);
}
