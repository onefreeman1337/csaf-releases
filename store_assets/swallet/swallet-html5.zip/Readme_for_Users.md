# SWALLET

*A hole in the hill. They keep coming down.*

Free, plays in your browser, saves itself, and nothing in it ever resets.

---

## What it is

You are the cave.

Cut chambers into a hill, put things in them, and decide what happens to the people who come
looking for whatever they think is down there. It is an incremental — numbers go up, the board
gets bigger, you leave it running — but the thing being optimised is a **route**, and the thing
walking that route is somebody else's run.

## The two things that fight

This is the whole game and it is worth reading once before you start.

- **A delver who DIES** leaves remains. Your sinks render remains into **spoil**, and the deeper
  the chamber, the more **marrow** comes out with it. Marrow is the permanent currency.
- **A delver who GETS OUT ALIVE** raises your **renown** — the only thing that makes the next
  cohort bigger, and the only thing that brings the richer kinds of delver down at all. They also
  strip your workings on the way through, so every survivor costs you real spoil.

Kill everyone and nobody comes. Kill nobody and you render nothing. The answer is a long route
that bleeds them slowly and kills most of them **deep, beside a sink**, while a few crawl back out
to tell everyone about it.

## The second thing that fights

**Every row you cut raises the water table.**

Under the water, wards lose most of their bite and moss drowns. But sinks render half again as
fast, and springs only work at all. Sumps and the CHANNEL vein push the water back down — and they
cost the same spoil as everything else, so going deep is both the goal and the tax.

## How to play

| | |
| --- | --- |
| **Click a square** | select it |
| **Solid rock** | CUT it, if something already open touches it |
| **An open chamber** | put one fixture in it, or deepen the one that is there |
| **VEINS** | permanent upgrades, bought with marrow |
| **M** | mute |
| **Escape** | back out of a screen |

There are twelve fixtures in four families, four bands of rock that each behave differently, five
kinds of delver, and eight veins. The last vein ends the story; the hollow keeps working afterwards.

## Saving

It saves to your browser's local storage every ten seconds and whenever something important
happens. Close the tab whenever you like. While you are away the roots keep working at a reduced
rate, capped at eight hours, and it tells you what it earned when you come back.

**There is no reset button and no prestige wipe.** The map only ever grows. If a delver reaches the
heartstone at the bottom you lose a fifth of your marrow and the deep floods for a minute — that is
the worst thing that can happen to you, and it is answerable with drainage.

## Requirements

Any current browser. Nothing to install, no account, no network calls after the page loads.

## Made by

**Core Systems Asset Factory.** Free, and it stays free.

More free browser games, and the tools these are built with, at <https://csaf.itch.io>.

---

### Honest disclosure

- **Code:** AI-written.
- **Graphics:** AI-assisted. Every plate, emblem and figure in the game is *generated at build
  time* by our own palette-locked pixel engine — no diffusion model, no stock art, no asset packs.
  The cover illustration was made with an image model.
- **Sounds:** no. Every sound effect is synthesised in the browser from oscillators, and the music
  is rendered offline from an authored score by our own tool. No samples, no soundfonts, no
  generative audio model.
- **Text:** AI-written.
