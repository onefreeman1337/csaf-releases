/**
 * delvers.js — the people who come down. This is the file that makes SWALLET a roguelike-LIKE
 * rather than an idle clicker with a grid: every delver is a RUN, with a build, a route, a nerve
 * threshold and an ending, and none of those runs are the player's.
 *
 * ⭐ THE ONE RULE THAT MAKES THE GAME: a delver who dies pays you REMAINS; a delver who gets out
 * alive pays you RENOWN and steals your spoil. You need both currencies, they come from opposite
 * outcomes, and the only lever that produces both is the SHAPE of the hollow — a long route that
 * bleeds slowly, kills most of them beside a sink, and lets a few crawl back out to talk.
 */
(function (root) {
  'use strict';

  const isNode = (typeof module === 'object' && module.exports);
  const D = isNode ? require('./data.js') : root.DATA;
  const H = isNode ? require('./hollow.js') : root.HOLLOW;

  function archetypeFor(renown, rnd) {
    const open = D.ARCHETYPES.filter((a) => renown >= a.renown);
    /* Weighted toward the newest kind the hollow has earned, but never only that kind — a board
     * that has stopped seeing scroungers has stopped teaching the player what changed. */
    const weights = open.map((a, i) => (i === open.length - 1 ? 3 : 1));
    let total = 0;
    for (const w of weights) total += w;
    let r = rnd() * total;
    for (let i = 0; i < open.length; i++) { r -= weights[i]; if (r <= 0) return open[i]; }
    return open[open.length - 1];
  }

  function spawnCohort(s, rnd, log) {
    const n = Math.min(D.TUNE.cohortMax, 1 + Math.floor(s.renown / D.TUNE.renownPerCohort));
    for (let i = 0; i < n; i++) {
      const a = archetypeFor(s.renown, rnd);
      const jitter = 0.85 + rnd() * 0.3;
      /* ⭐ WHAT A DELVER CAN CARRY OUT SCALES WITH THE HOLLOW, and that is the whole reason
       * letting them live stays a real cost instead of becoming free by hour three. A flat
       * `a.carry` meant a surviving adept cost 98 spoil against a treasury of millions — the
       * central tension of the design quietly switching itself off as the game got bigger. It is
       * a fixed floor PLUS a slice of the treasury, so the tax is always felt and never fatal. */
      const capacity = a.carry * (1 + 0.5 * s.deepest) + s.spoil * 0.06 * a.greed;
      s.delvers.push({
        id: s.nextDelverId++,
        kind: a.id,
        sheet: a.sheet,
        x: D.MOUTH_X, y: 0,
        px: D.MOUTH_X, py: -1,      // where it is being drawn from, for the walk tween
        t: i * 0.55,                // stagger so a cohort arrives as people, not as a block
        maxGrit: a.grit,
        grit: a.grit,
        greed: a.greed, wit: a.wit, pace: a.pace * jitter,
        carry: 0, capacity, remains: a.remains,
        deepest: 0,
        leaving: false,
        hurtT: 0,
        state: 'walk',
      });
    }
    if (log) log(n === 1 ? 'A ' + D.ARCHETYPES.find((a) => a.id === s.delvers[s.delvers.length - 1].kind).name + ' comes down.'
      : n + ' delvers come down.');
  }

  /** One delver arrives in a chamber: wards bite, loose spoil is pocketed, nerve is tested. */
  function enter(s, d, log) {
    const c = H.cellAt(s, d.x, d.y);
    if (!c) return;
    if (d.y > d.deepest) d.deepest = d.y;

    let toll = H.tollAt(s, c, d.wit);
    /* COLD DRAUGHT reaches into the four chambers around it, which is what its price buys and the
     * only ward that can punish a delver for a route you did not put it on. */
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const n = H.cellAt(s, d.x + dx, d.y + dy);
      if (n && n.fixture && n.fixture.id === 'chill') toll += H.tollAt(s, n, d.wit) * 0.5;
    }
    /* ⭐ WARDS ARE THE EARLY ECONOMY, AND THAT IS THE FIX THE PROBE FORCED. A ward that only
     * subtracted grit paid nothing until you also owned a sink AND could kill outright, so the
     * first hour of the game had no working income and the probe sat at row 2 for ninety minutes.
     * Hurting someone shakes things loose: the bleed is a share of the toll, so it scales with the
     * ward, its level and the BITE vein all at once, and building the thing the game is about is
     * finally the thing that pays for the next one. */
    if (toll > 0) {
      d.grit -= toll;
      d.hurtT = 0.45;
      s.spoil += toll * D.TUNE.bleed;
    }

    /* ⭐ LOOTING, AND IT IS THE PRICE OF RENOWN. A delver strips the workings it walks through:
     * the take comes straight out of the player's spoil, so every chamber a survivor crosses is
     * money leaving. Loose rubble on the floor (dropped by someone who died carrying) is taken
     * first because it is easier than digging it out of the walls. */
    if (d.carry < d.capacity) {
      const room = d.capacity - d.carry;
      const fromFloor = Math.min(c.rubble, room);
      c.rubble -= fromFloor; d.carry += fromFloor;
      /* ⛔ THIS WAS `d.capacity * 0.34` AND IT KILLED THE GAME STONE DEAD. The campaign probe found
       * it in one run: at 90 simulated minutes the player was still on row 3 with a treasury
       * oscillating between 0 and 34, one kind of fixture ever built and the ending unreachable —
       * because a scrounger's capacity is an ABSOLUTE number and the early treasury is smaller
       * than it, so every delver stripped the hollow to nothing and the economy never started.
       *
       * ⭐ A TAX HAS TO BE A FRACTION, NOT A FIGURE. Taking a slice of the treasury per chamber is
       * self-scaling: it is pennies when you are poor and it genuinely hurts when you are rich,
       * which is the behaviour the design wanted at both ends. Six chambers at 1.8% x greed
       * compounds to roughly 5% of everything you own, which is a survivor worth being annoyed
       * about. ⚠️ Every unit test in test_sim.js passed with the broken version. */
      const fromWalls = Math.min(room - fromFloor, s.spoil * 0.018 * d.greed);
      if (fromWalls > 0) { s.spoil -= fromWalls; d.carry += fromWalls; }
    }

    if (d.grit <= 0) {
      d.state = 'dead';
      c.remains += d.remains;
      /* ⚠️ Everything they had taken comes straight back. A body is worth its remains AND the
       * refund — which is exactly why killing them deep, after a long walk, is worth more than
       * killing them at the door, and why the routing puzzle has an answer worth finding. */
      s.spoil += d.carry;
      d.carry = 0;
      s.killed++;
      s.renown = Math.max(0, s.renown + D.TUNE.renownDeath + d.deepest * D.TUNE.renownDeathDepth);
      if (log) log('A ' + d.kind + ' dies at row ' + (d.y + 1) + '.');
      return;
    }
    if (!d.leaving && d.grit < d.maxGrit * D.TUNE.nerve) {
      d.leaving = true;
      if (log) log('A ' + d.kind + ' loses its nerve and turns back.');
    }
    /* The heartstone. Reaching it is the one thing that costs the player something real, and it
     * is answerable: marrow is spent, the bottom floods for a minute, nothing is destroyed. */
    if (!d.leaving && d.y >= D.ROWS - 1) {
      s.shardsLost++;
      s.marrow *= (1 - D.TUNE.shardMarrowLoss);
      s.floodT = D.TUNE.shardFloodSecs;
      s.renown += D.TUNE.renownVault * H.veinMul(s, 'whisper');
      d.leaving = true;
      d.carry = d.capacity;
      if (log) log('A ' + d.kind + ' reaches the heartstone. The deep floods.');
    }
  }

  function tick(s, dt, rnd, log) {
    s.cohortT += dt;
    if (s.cohortT >= D.TUNE.cohortSecs) {
      s.cohortT -= D.TUNE.cohortSecs;
      spawnCohort(s, rnd, log);
    }

    const pull = H.pullMap(s);
    for (const d of s.delvers) {
      if (d.state === 'dead') continue;
      if (d.hurtT > 0) d.hurtT = Math.max(0, d.hurtT - dt);
      d.t += dt;
      const step = D.TUNE.stepSecs / d.pace;
      while (d.t >= step) {
        d.t -= step;
        d.px = d.x; d.py = d.y;

        if (d.leaving) {
          if (d.y === 0 && d.x === D.MOUTH_X) { d.state = 'out'; break; }
          const nx = H.stepToward(s, d.x, d.y, D.MOUTH_X, 0);
          if (!nx) { d.state = 'out'; break; }
          d.x = nx.x; d.y = nx.y;
          enter(s, d, log);
          if (d.state === 'dead') break;
          continue;
        }

        /* Choose a destination: the best-pulling open chamber, discounted by how far it is. A
         * greedy delver walks further for the same gleam than a timid one. */
        let best = null, bestScore = -Infinity;
        for (const c of s.cells) {
          if (!c.dug) continue;
          const dist = Math.abs(c.x - d.x) + Math.abs(c.y - d.y);
          const score = pull[c.y * D.COLS + c.x] * (0.6 + d.greed) - dist * (0.45 - d.greed * 0.25);
          if (score > bestScore) { bestScore = score; best = c; }
        }
        if (!best || (best.x === d.x && best.y === d.y)) {
          /* ⛔ NOBODY WALKS TO A CAVE MOUTH AND GOES HOME. Without this a timid delver standing on
           * the entrance could score its own square highest and leave having entered nothing,
           * which read in the numbers as an "escape" and paid full renown for doing nothing. If it
           * has been nowhere, it goes to the deepest open chamber it can reach. */
          if (d.deepest === 0) {
            let deepest = null;
            for (const c of s.cells) if (c.dug && (!deepest || c.y > deepest.y)) deepest = c;
            if (deepest && deepest.y > 0) { best = deepest; } else { d.leaving = true; continue; }
          } else { d.leaving = true; continue; }
        }
        const nx = H.stepToward(s, d.x, d.y, best.x, best.y);
        if (!nx) { d.leaving = true; continue; }
        d.x = nx.x; d.y = nx.y;
        enter(s, d, log);
        if (d.state === 'dead') break;
      }
    }

    /* Resolve everyone who left the hollow this tick. */
    for (const d of s.delvers) {
      if (d.state !== 'out') continue;
      d.state = 'gone';
      s.escaped++;
      /* ⛔ NOT `s.spoil -= d.carry` — that would charge twice. The spoil left the treasury chamber
       * by chamber as they took it (see `enter`), so escaping only makes the loss permanent. The
       * first version of this line double-billed and the tell would have been a treasury that
       * drained twice as fast as the log said it should. */
      s.spoilStolen += d.carry;
      /* ⚠️ DIMINISHING, and it has to be. Flat gains ran renown to 5,087 in ninety probe minutes —
       * every archetype unlocked inside the first ten, cohorts pinned at the cap forever, and the
       * whole reputation ladder collapsed into a single number that only went up. Halving at 120
       * makes renown settle in the low hundreds, which is where the archetype thresholds live. */
      const gain = (D.TUNE.renownEscape + d.deepest * D.TUNE.renownPerDepth)
        * H.veinMul(s, 'whisper') / (1 + s.renown / D.TUNE.renownHalf);
      s.renown += gain;
      if (log) log('A ' + d.kind + ' gets out with ' + Math.round(d.carry) + ' spoil. Word spreads.');
    }
    /* A body stays visible for a while so the player can SEE where the sinks should have been. */
    s.delvers = s.delvers.filter((d) => {
      if (d.state === 'gone') return false;
      if (d.state === 'dead') { d.t += 0; return (d.deadT = (d.deadT || 0) + dt) < 6; }
      return true;
    });
  }

  const API = { spawnCohort, tick, archetypeFor, enter };
  if (isNode) module.exports = API;
  else root.DELVERS = API;
})(typeof self !== 'undefined' ? self : this);
