/**
 * sound.js — self-contained procedural audio. No samples, no files, no licence.
 *
 * ⚠️ THIS IS WHY THE LISTING'S AI DISCLOSURE READS "Sounds: no" (master §4.1, Playbook_itch §15f):
 * itch's own guidance is explicit that self-contained procedural synthesis is not generative AI.
 * The AI-written CODE is covered by "Code: yes". ⛔ If a single rendered sample or a generative
 * audio model is ever added to this game, that checkbox flips the same day — the carve-out is
 * about the METHOD, not about how the result sounds.
 *
 * The theme is the one file, and it is OUR OWN IP too: rendered by Kernel/capture/make_audio.js
 * from Internal_Ops/theme.json, oscillators only, no soundfont and no sample bank.
 */
(function (root) {
  'use strict';

  let ctx = null;
  let master = null;
  let enabled = true;
  let started = false;

  function ensure() {
    if (ctx) return ctx;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = 0.30;
    master.connect(ctx.destination);
    return ctx;
  }

  let music = null;
  function ensureMusic() {
    if (music) return music;
    music = new Audio('audio/swallet_theme.ogg');
    music.loop = true;
    music.volume = 0.40;
    music.addEventListener('error', () => console.warn('[SWALLET] theme failed to load'));
    return music;
  }

  /** Call from a real input handler. Browsers suspend contexts created without a gesture. */
  function unlock() {
    const c = ensure();
    if (c && c.state === 'suspended') c.resume();
    started = true;
    if (enabled) { const m = ensureMusic(); if (m.paused) m.play().catch(() => { /* autoplay refused; the toggle still works */ }); }
  }

  function noiseBuffer(seconds) {
    const n = Math.floor(ctx.sampleRate * seconds);
    const buf = ctx.createBuffer(1, n, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    return buf;
  }

  function blip(freq, dur, type, gain, sweepTo) {
    if (!enabled || !started) return;
    const c = ensure();
    if (!c) return;
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(freq, c.currentTime);
    if (sweepTo) o.frequency.exponentialRampToValueAtTime(sweepTo, c.currentTime + dur);
    g.gain.setValueAtTime(0.0001, c.currentTime);
    g.gain.exponentialRampToValueAtTime(gain || 0.20, c.currentTime + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + dur);
    o.connect(g); g.connect(master);
    o.start();
    o.stop(c.currentTime + dur + 0.02);
  }

  function rush(dur, cutoff, gain, q) {
    if (!enabled || !started) return;
    const c = ensure();
    if (!c) return;
    const src = c.createBufferSource();
    src.buffer = noiseBuffer(dur);
    const f = c.createBiquadFilter();
    f.type = 'bandpass';
    f.frequency.value = cutoff;
    f.Q.value = q || 0.8;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, c.currentTime);
    g.gain.exponentialRampToValueAtTime(gain || 0.14, c.currentTime + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + dur);
    src.connect(f); f.connect(g); g.connect(master);
    src.start();
    src.stop(c.currentTime + dur + 0.02);
  }

  /* Each cue is a different GESTURE rather than a different pitch of the same beep. Cutting rock
   * is a low crumble; a ward firing is a hard snap; a delver getting out is a receding sigh. */
  const API = {
    unlock,
    setEnabled(v) {
      enabled = !!v;
      const m = ensureMusic();
      if (enabled) { if (started) m.play().catch(() => {}); } else { m.pause(); }
    },
    isEnabled() { return enabled; },
    dig() { rush(0.28, 220 + Math.random() * 160, 0.16, 0.6); blip(74, 0.16, 'sine', 0.10, 52); },
    place() { blip(320, 0.10, 'triangle', 0.11); setTimeout(() => blip(430, 0.14, 'triangle', 0.09), 55); },
    ward() { blip(880, 0.06, 'square', 0.09, 180); rush(0.10, 2600, 0.08, 2.2); },
    die() { blip(150, 0.34, 'sawtooth', 0.10, 60); rush(0.40, 420, 0.10, 0.5); },
    escape() { blip(392, 0.30, 'sine', 0.08); setTimeout(() => blip(294, 0.42, 'sine', 0.06), 130); },
    marrow() { [330, 440, 587].forEach((f, i) => setTimeout(() => blip(f, 0.40, 'triangle', 0.10), i * 90)); },
    unlockThing() { [262, 330, 392, 523].forEach((f, i) => setTimeout(() => blip(f, 0.55, 'triangle', 0.11), i * 110)); rush(0.7, 620, 0.05); },
    shard() { blip(110, 0.7, 'sawtooth', 0.13, 44); rush(0.9, 300, 0.13, 0.4); },
    deny() { blip(104, 0.11, 'sawtooth', 0.06, 76); },
  };

  if (typeof module === 'object' && module.exports) module.exports = API;
  else root.SOUND = API;
})(typeof self !== 'undefined' ? self : this);
