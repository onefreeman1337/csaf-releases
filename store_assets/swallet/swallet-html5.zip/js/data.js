/**
 * data.js — every tunable number in SWALLET, in one place, with the reason beside it.
 *
 * ⭐ THE DESIGN IN ONE PARAGRAPH, because a balance table is unreadable without it. You are a
 * cave system. Delvers come down looking for what you have. KILLING them yields REMAINS, which
 * your sinks render into spoil and marrow — your whole economy. LETTING THEM OUT ALIVE yields
 * RENOWN, which is the only thing that makes the next cohort bigger and richer, and costs you
 * whatever spoil they carry out. So neither "maximum lethality" nor "let them wander" is a
 * strategy: you want a LONG route that bleeds them slowly and kills most of them next to a sink,
 * while a few crawl back into the daylight to tell everyone about it.
 *
 * The second system is DEPTH vs DAMP. Every row you cut raises the water table. Below it your
 * wards lose most of their bite and your moss drowns — but your sinks render far better and
 * springs only work at all. Sumps push the water back down and compete for the same spoil as
 * everything else. Going deep is both the goal and the tax.
 *
 * ⛔ EVERY PERMANENT PENALTY HAS AN ANSWER THE PLAYER CAN BUY (wing §3f, measured on PERIGEE:
 * "erosion lowered a farm's sill permanently and nothing could raise it ... that is not
 * difficulty, it is a wall with a date on it"). Flooding is answered by sumps and by the
 * `channel` vein; a lost heartstone shard costs marrow and time, never board state.
 *
 * ⛔ AND THERE IS NO RESET, EVER (ledger B4/B5). The runs in this roguelike-like belong to the
 * DELVERS, not to the player; the hollow only ever grows. That is the inversion the whole game
 * is built on and it is also, exactly, the save/resume rule honoured rather than bolted on.
 */
(function (root) {
  'use strict';

  const COLS = 9;
  const ROWS = 12;
  const MOUTH_X = 4;

  /* Four strata, three rows each. Dig cost rises with depth INSIDE a band as well as between
   * bands, so the last row of loam is a real decision rather than a formality. */
  const STRATA = [
    { id: 'loam', name: 'LOAM', plate: 'loam', from: 0, to: 2, dig: 9, blurb: 'Soft, wet, full of roots. Cheap to open and it holds nothing.' },
    { id: 'chalk', name: 'CHALK', plate: 'chalk', from: 3, to: 5, dig: 38, blurb: 'Nodular, dry, flint-shot. A ward set in chalk stays where you put it.' },
    { id: 'shale', name: 'SHALE', plate: 'shale', from: 6, to: 8, dig: 150, blurb: 'Laminated and leaking. The water table lives here and it is coming up.' },
    { id: 'granite', name: 'GRANITE', plate: 'granite', from: 9, to: 11, dig: 520, blurb: 'Dear to cut, dry as bone, and it renders what dies in it twice over.' },
  ];

  function stratumAt(y) {
    for (const s of STRATA) if (y >= s.from && y <= s.to) return s;
    return STRATA[STRATA.length - 1];
  }

  /**
   * Fixtures. `family` decides what the tick does with it; `unlock` is the deepest row that must
   * be dug before it can be bought — a new fixture every two rows, so a band is never a wall of
   * five new buttons (§3e: the screens that sell the next unlock are where this wing loses Gate 1,
   * and a screen with twelve unfamiliar things on it is the same failure by another route).
   *
   * `sheet` is the column index in art/sheet_fixtures.png. It must match sprites.js FIXTURES order
   * exactly, and `--self-test` in test_sim.js asserts that rather than trusting this comment.
   */
  const FIXTURES = [
    { id: 'moss', sheet: 0, name: 'MOSS BED', family: 'root', unlock: 0, cost: 12, yield: 0.55,
      blurb: 'Grows on damp rock and turns it slowly into spoil. Drowns below the water table.' },
    { id: 'snare', sheet: 5, name: 'SNARE', family: 'ward', unlock: 0, cost: 22, toll: 4.2,
      blurb: 'A jaw in the floor. Cheap, quiet, and it takes a little from everyone who passes.' },
    { id: 'glim', sheet: 3, name: 'GLIM', family: 'lure', unlock: 2, cost: 48, draw: 3.2,
      blurb: 'A false gleam. Delvers will walk one chamber further to look at it.' },
    /* ⭐ REACH IS THE SINK UPGRADE AXIS, and it exists because the campaign probe produced ZERO
     * marrow across 815 kills: every body lay at row 1 where the first ward was, every sink sat at
     * row 5 where there was space, and a radius of one meant they never met. A press that only
     * reaches its neighbours makes placement a real decision; the later sinks buy their way out of
     * that problem, which is a far better feeling upgrade than a bigger number. */
    { id: 'press', sheet: 8, name: 'BONE PRESS', family: 'sink', unlock: 2, cost: 85, rate: 1.7, marrow: 0, radius: 1,
      blurb: 'Renders what dies within one chamber of it into spoil. It has to be NEXT to the dying.' },
    { id: 'spike', sheet: 6, name: 'SPIKE PIT', family: 'ward', unlock: 4, cost: 150, toll: 12,
      blurb: 'Loud and effective. Loses most of its bite once the water is over it.' },
    { id: 'spring', sheet: 1, name: 'SPRING', family: 'root', unlock: 4, cost: 170, yield: 2.6, needsWet: true,
      blurb: 'Only yields where the rock is wet, and yields more the deeper it drowns.' },
    { id: 'sump', sheet: 11, name: 'SUMP', family: 'drain', unlock: 6, cost: 900, drain: 1,
      blurb: 'Pushes the water table down one row for every level. The answer to the deep.' },
    { id: 'mouldbed', sheet: 9, name: 'MOULD BED', family: 'sink', unlock: 6, cost: 420, rate: 5.5, marrow: 0.022, radius: 2,
      blurb: 'Reaches two chambers in every direction, and yields real marrow on top of the spoil.' },
    { id: 'chill', sheet: 7, name: 'COLD DRAUGHT', family: 'ward', unlock: 8, cost: 1400, toll: 33,
      blurb: 'Takes from every delver in the chamber and the four around it. Water does not stop cold.' },
    { id: 'lodestone', sheet: 4, name: 'LODESTONE', family: 'lure', unlock: 8, cost: 2600, draw: 15,
      blurb: 'They can feel it from the surface. Nothing pulls a delver deeper.' },
    /* ⛔ PRICED AT 9,000 AND 14,000 ON THE FIRST PASS AND THE CAMPAIGN PROBE PROVED BOTH WERE DEAD
     * CONTENT: across 150 simulated minutes, with the ending reached at 72, the treasury never once
     * held enough to buy either. §3f's second failure exactly — "a player who never sees the
     * deepest thing you built has not played an easy game, they have played a different and
     * smaller one." ⚠️ The tell was NOT "the probe never built them"; a probe has a shopping list
     * and can skip things. It was a separate measurement of when each fixture first became
     * AFFORDABLE, which is a fact about the game rather than about the policy. */
    { id: 'slagpool', sheet: 10, name: 'SLAG POOL', family: 'sink', unlock: 10, cost: 3200, rate: 20, marrow: 0.13, radius: 4,
      blurb: 'Reaches four chambers in every direction and renders everything. Works far better wet, which is the one time the flood is a gift.' },
    { id: 'lichen', sheet: 2, name: 'LICHEN', family: 'root', unlock: 10, cost: 3600, yield: 11, everWet: true,
      blurb: 'Eats the stone itself. Never depletes, never drowns, never stops.' },
  ];

  const FIXTURE_BY_ID = {};
  for (const f of FIXTURES) FIXTURE_BY_ID[f.id] = f;

  /** Level cost curve: buying the third level of a thing should hurt as much as a new thing. */
  function fixtureCost(f, level) { return Math.ceil(f.cost * Math.pow(2.7, level)); }
  const MAX_FIXTURE_LEVEL = 3;

  /**
   * Veins — the permanent layer, bought with marrow. ⭐ `seal` is the ENDING, and it is a purchase
   * rather than a milestone on purpose (§3f: "MAKE THE GAME FINITE IF THE CURVE SAYS SO ... an
   * endless rising quota against a settlement that stops growing is a wall dressed as
   * replayability"). It is reachable, it is expensive, and the game continues afterwards.
   */
  const VEINS = [
    { id: 'bite', name: 'BITE', max: 5, cost: 3, per: 0.25, blurb: 'Every ward takes +25% more from each delver.' },
    { id: 'render', name: 'RENDER', max: 5, cost: 4, per: 0.30, blurb: 'Every sink renders +30% faster.' },
    { id: 'taproot', name: 'TAPROOT', max: 5, cost: 3, per: 0.30, blurb: 'Every root yields +30% more spoil.' },
    { id: 'beacon', name: 'BEACON', max: 4, cost: 6, per: 0.35, blurb: 'Every lure pulls +35% harder.' },
    { id: 'whisper', name: 'WHISPER', max: 4, cost: 8, per: 0.25, blurb: 'Survivors tell it better. +25% renown from everyone who gets out.' },
    { id: 'quarry', name: 'QUARRY', max: 5, cost: 5, per: 0.12, blurb: 'Cutting new rock costs 12% less per level.' },
    { id: 'channel', name: 'CHANNEL', max: 3, cost: 25, per: 1, blurb: 'Holds the water table one row lower, permanently.' },
    { id: 'seal', name: 'THE SEAL', max: 1, cost: 900, per: 0, endgame: true,
      blurb: 'Close the heartstone for good. Needs the granite opened to the floor. This ends the story; the hollow keeps working.' },
  ];
  const VEIN_BY_ID = {};
  for (const v of VEINS) VEIN_BY_ID[v.id] = v;
  function veinCost(v, level) { return Math.ceil(v.cost * Math.pow(2.2, level)); }

  /**
   * Delver archetypes. `sheet` is the ROW in art/sheet_delvers.png and must match sprites.js
   * ARCHETYPES order. `renown` is the reputation at which this kind starts coming down.
   *
   * ⚠️ `remains` climbs far faster than `grit` does, which is the whole reason the renown dial is
   * interesting: a reaver is worth seventeen scroungers dead, and you only ever see one by letting
   * enough delvers walk back out alive to be talked about.
   */
  const ARCHETYPES = [
    { id: 'scrounger', sheet: 0, name: 'scrounger', renown: 0, grit: 11, greed: 0.35, wit: 0.05, pace: 1.00, carry: 14, remains: 26 },
    { id: 'pilgrim', sheet: 1, name: 'pilgrim', renown: 16, grit: 17, greed: 0.50, wit: 0.15, pace: 0.85, carry: 22, remains: 64 },
    { id: 'surveyor', sheet: 2, name: 'surveyor', renown: 36, grit: 26, greed: 0.70, wit: 0.35, pace: 1.10, carry: 38, remains: 165 },
    { id: 'reaver', sheet: 3, name: 'reaver', renown: 62, grit: 48, greed: 0.85, wit: 0.20, pace: 1.25, carry: 66, remains: 450 },
    { id: 'adept', sheet: 4, name: 'adept', renown: 84, grit: 37, greed: 0.95, wit: 0.60, pace: 0.90, carry: 98, remains: 980 },
  ];

  const TUNE = {
    startSpoil: 45,
    startRenown: 12,
    cohortSecs: 26,          // one cohort every 26s at any renown
    cohortMax: 5,
    renownPerCohort: 21,     // renown needed per extra body in a cohort
    nerve: 0.30,             // a delver turns back below this fraction of its grit
    bleed: 0.9,              // spoil shaken loose per point of toll — the early economy
    renownEscape: 4,         // renown for getting out alive
    renownPerDepth: 0.5,     // ...plus this much per row it reached
    renownHalf: 120,         // ...all of it halved at this much renown, and halved again at 3x it
    /* ⭐ DYING DEEP IS ITS OWN LEGEND, and this line is the fix for the flattest failure the
     * campaign probe found: with a flat -3, a lethal hollow drove renown to ZERO by minute 35 and
     * held it there for the remaining fifty-five, cohorts collapsed to one delver, and the game
     * simply went quiet. A shallow slaughter should still frighten people off — but a delver who
     * gets nine rows down before anything kills them is a story that brings the next one. Net
     * positive from row 7, which is precisely where the design wants the killing to happen. */
    renownDeath: -3,         // renown for dying in the hollow...
    renownDeathDepth: 0.45,  // ...plus this much per row it got to first
    renownVault: 9,          // renown for reaching the heartstone (they tell EVERYONE)
    stepSecs: 0.62,          // seconds per board step at pace 1.0
    sinkRadius: 1,           // chebyshev radius a sink renders within
    waterFrom: 5,            // digging past this row starts raising the water
    waterFloor: 3,           // the table can never rise above this row
    offlineCapHours: 8,
    offlineRate: 0.45,       // away income is worth this fraction of live root income
    shardMarrowLoss: 0.20,   // a delver reaching the heartstone costs this share of marrow
    shardFloodSecs: 60,      // ...and floods the bottom rows for this long
    autosaveSecs: 10,
  };

  const API = { COLS, ROWS, MOUTH_X, STRATA, stratumAt, FIXTURES, FIXTURE_BY_ID, fixtureCost, MAX_FIXTURE_LEVEL, VEINS, VEIN_BY_ID, veinCost, ARCHETYPES, TUNE };

  if (typeof module === 'object' && module.exports) module.exports = API;
  else root.DATA = API;
})(typeof self !== 'undefined' ? self : this);
