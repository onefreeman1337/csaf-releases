/**
 * hollow.js — the board: what is cut, what is in it, where the water is, and how a delver gets
 * from one chamber to another. No rendering and no input; `test_sim.js` and `balance.js` both
 * drive this file headlessly, which is only possible because it draws nothing.
 */
(function (root) {
  'use strict';

  const D = (typeof module === 'object' && module.exports) ? require('./data.js') : root.DATA;

  function makeState() {
    const cells = [];
    for (let y = 0; y < D.ROWS; y++) {
      for (let x = 0; x < D.COLS; x++) {
        cells.push({
          x, y,
          dug: false,
          fixture: null,      // { id, level }
          remains: 0,         // unrendered bodies, in spoil-equivalent
          rubble: 0,          // loose spoil a passing delver can steal
          wet: 0,             // derived every tick; never saved
        });
      }
    }
    const s = {
      cells,
      spoil: D.TUNE.startSpoil,
      marrow: 0,
      renown: D.TUNE.startRenown,
      veins: {},
      delvers: [],
      log: [],
      elapsed: 0,
      cohortT: 0,
      nextDelverId: 1,
      deepest: 0,
      shardsLost: 0,
      floodT: 0,
      escaped: 0,
      killed: 0,
      spoilStolen: 0,
      sealed: false,
      seenEnding: false,
      unlockedSeen: {},       // fixture ids the player has been told about
    };
    for (const v of D.VEINS) s.veins[v.id] = 0;
    /* The mouth is already open — a hollow with no way in has no game in it, and a first click
     * that spends the whole starting purse on the entrance is a bad first thirty seconds. */
    cellAt(s, D.MOUTH_X, 0).dug = true;
    recompute(s);
    return s;
  }

  function cellAt(s, x, y) {
    if (x < 0 || y < 0 || x >= D.COLS || y >= D.ROWS) return null;
    return s.cells[y * D.COLS + x];
  }

  function vein(s, id) { return s.veins[id] || 0; }
  function veinMul(s, id) { return 1 + vein(s, id) * D.VEIN_BY_ID[id].per; }

  /**
   * THE WATER TABLE. Every row cut past `waterFrom` brings it up one; sumps and the `channel`
   * vein push it back down. A shard loss floods the bottom for a while — temporary, and answerable
   * by exactly the same two things, which is the §3f rule (a penalty needs something to buy).
   */
  function waterRow(s) {
    let wt = D.ROWS - 1 - Math.max(0, s.deepest - D.TUNE.waterFrom);
    let drain = vein(s, 'channel');
    for (const c of s.cells) if (c.fixture && D.FIXTURE_BY_ID[c.fixture.id].family === 'drain') drain += c.fixture.level + 1;
    wt += drain;
    if (s.floodT > 0) wt -= 2;
    return Math.max(D.TUNE.waterFloor, Math.min(D.ROWS + 2, wt));
  }

  /**
   * Derived per tick, never serialised — a saved derived field is a saved bug (see save.js).
   *
   * ⛔ ORDER IS LOAD-BEARING AND IT WAS WRONG FIRST TIME. `waterRow()` reads `s.deepest`, so
   * refreshing `deepest` after computing the table left the water ONE DIG BEHIND the board,
   * permanently. Nothing threw; the number was simply always stale by one row, and the only reason
   * it surfaced is that `test_sim.js` asserts a sump MOVES the table and the stale baseline made
   * the sump look like a no-op. Deepest first, then water, then wetness.
   */
  function recompute(s) {
    s.deepest = 0;
    for (const c of s.cells) if (c.dug && c.y > s.deepest) s.deepest = c.y;
    const wt = waterRow(s);
    s.waterRow = wt;
    for (const c of s.cells) c.wet = Math.max(0, Math.min(1, (c.y - wt + 1) / 2));
  }

  function digCost(s, x, y) {
    const st = D.stratumAt(y);
    const raw = st.dig * (1 + 0.34 * (y - st.from)) * (1 + 0.06 * y);
    return Math.ceil(raw * Math.max(0.25, 1 - vein(s, 'quarry') * D.VEIN_BY_ID.quarry.per));
  }

  /** A cell may be cut only from a neighbour that is already open. The hollow grows, it never
   *  teleports — which is what makes the SHAPE of it a decision. */
  function canDig(s, x, y) {
    const c = cellAt(s, x, y);
    if (!c || c.dug) return false;
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const n = cellAt(s, x + dx, y + dy);
      if (n && n.dug) return true;
    }
    return false;
  }

  function dig(s, x, y) {
    if (!canDig(s, x, y)) return { ok: false, why: 'nothing open next to it' };
    const cost = digCost(s, x, y);
    if (s.spoil < cost) return { ok: false, why: 'not enough spoil' };
    s.spoil -= cost;
    const c = cellAt(s, x, y);
    c.dug = true;
    recompute(s);
    return { ok: true, cost };
  }

  function fixtureUnlocked(s, f) { return s.deepest >= f.unlock; }

  function place(s, x, y, id) {
    const c = cellAt(s, x, y);
    const f = D.FIXTURE_BY_ID[id];
    if (!c || !c.dug) return { ok: false, why: 'that chamber is not open' };
    if (!f) return { ok: false, why: 'no such fixture' };
    if (!fixtureUnlocked(s, f)) return { ok: false, why: 'not found yet' };
    if (c.fixture) return { ok: false, why: 'that chamber is taken' };
    const cost = D.fixtureCost(f, 0);
    if (s.spoil < cost) return { ok: false, why: 'not enough spoil' };
    s.spoil -= cost;
    c.fixture = { id, level: 0 };
    recompute(s);
    return { ok: true, cost };
  }

  function upgrade(s, x, y) {
    const c = cellAt(s, x, y);
    if (!c || !c.fixture) return { ok: false, why: 'nothing there' };
    if (c.fixture.level >= D.MAX_FIXTURE_LEVEL - 1) return { ok: false, why: 'already at its best' };
    const f = D.FIXTURE_BY_ID[c.fixture.id];
    const cost = D.fixtureCost(f, c.fixture.level + 1);
    if (s.spoil < cost) return { ok: false, why: 'not enough spoil' };
    s.spoil -= cost;
    c.fixture.level++;
    recompute(s);
    return { ok: true, cost };
  }

  function buyVein(s, id) {
    const v = D.VEIN_BY_ID[id];
    if (!v) return { ok: false, why: 'no such vein' };
    const lv = vein(s, id);
    if (lv >= v.max) return { ok: false, why: 'already run out' };
    if (v.endgame && s.deepest < D.ROWS - 1) return { ok: false, why: 'the granite is not open to the floor' };
    const cost = D.veinCost(v, lv);
    if (s.marrow < cost) return { ok: false, why: 'not enough marrow' };
    s.marrow -= cost;
    s.veins[id] = lv + 1;
    if (v.endgame) s.sealed = true;
    recompute(s);
    return { ok: true, cost };
  }

  /* ── per-tick economy ─────────────────────────────────────────────────────────────────────── */

  /**
   * ⛔ THE SEEP, AND IT EXISTS BECAUSE THE GAME HAD NO BOOTSTRAP AT ALL. The campaign probe's
   * second run: treasury pinned at ZERO from minute eleven to minute ninety, one fixture ever
   * built, row 2 of 12. Every income source in the design needed a prior purchase — roots need a
   * root, sinks need a body, bodies need a ward strong enough to kill — so a player who spent
   * their opening 45 spoil slightly wrong had no way back and no way forward. That is not
   * difficulty, it is the wall §3f names, arriving in the first two minutes.
   *
   * The hill always brings a little down on its own, and it brings more the more of it is open.
   * It is deliberately too small to play on: it is the floor that stops a dead start.
   */
  function seep(s) { return 0.25 + 0.06 * s.deepest; }

  /** Spoil per second from the seep and the roots. Exported because the offline catch-up uses
   *  exactly this number and nothing else — an away bonus computed from a different formula than
   *  the live one is a second economy nobody balanced. */
  function rootIncome(s) {
    const mul = veinMul(s, 'taproot');
    let n = 0;
    for (const c of s.cells) {
      if (!c.fixture) continue;
      const f = D.FIXTURE_BY_ID[c.fixture.id];
      if (f.family !== 'root') continue;
      const lv = c.fixture.level + 1;
      if (f.everWet) n += f.yield * lv;
      else if (f.needsWet) n += f.yield * lv * c.wet;
      else n += f.yield * lv * (1 - c.wet);
    }
    return n * mul + seep(s);
  }

  /** What a sink pulls out of the bodies around it, this second. */
  function sinkTick(s, dt) {
    const mul = veinMul(s, 'render');
    for (const c of s.cells) {
      if (!c.fixture) continue;
      const f = D.FIXTURE_BY_ID[c.fixture.id];
      if (f.family !== 'sink') continue;
      const lv = c.fixture.level + 1;
      const wetBonus = 1 + 0.8 * c.wet;
      let want = f.rate * lv * mul * wetBonus * dt;
      const rad = f.radius || D.TUNE.sinkRadius;
      for (let dy = -rad; dy <= rad && want > 0; dy++) {
        for (let dx = -rad; dx <= rad && want > 0; dx++) {
          const n = cellAt(s, c.x + dx, c.y + dy);
          if (!n || n.remains <= 0) continue;
          const take = Math.min(n.remains, want);
          n.remains -= take;
          want -= take;
          s.spoil += take;
          /* ⭐ MARROW COMES OUT OF DEPTH, not only out of the fancy sinks. The probe rendered 286
           * bodies over ninety minutes and produced ZERO marrow, so the entire vein layer and the
           * ending were dead content: presses (marrow 0) sat nearer the killing than the one
           * mould bed did and ate everything first. Every sink now yields marrow scaled by the row
           * the body is being rendered ON, which puts the meta-currency behind the same decision
           * the whole game is about — kill them deep, beside something that can use it. */
          s.marrow += take * (f.marrow + n.y * 0.0022);
        }
      }
    }
  }

  function lureAt(s, c) {
    if (!c.fixture) return 0;
    const f = D.FIXTURE_BY_ID[c.fixture.id];
    if (f.family !== 'lure') return 0;
    return f.draw * (c.fixture.level + 1) * veinMul(s, 'beacon');
  }

  /** Toll a ward in this cell applies to one delver, after water and the delver's own wit. */
  function tollAt(s, c, wit) {
    if (!c.fixture) return 0;
    const f = D.FIXTURE_BY_ID[c.fixture.id];
    if (f.family !== 'ward') return 0;
    const base = f.toll * (c.fixture.level + 1) * veinMul(s, 'bite');
    /* Cold does not care about water; a jaw or a pit very much does. That single exception is
     * what makes the deep-and-flooded board playable at all, and it is why `chill` is expensive. */
    const damp = f.id === 'chill' ? 1 : (1 - 0.62 * c.wet);
    return base * damp * (1 - wit * 0.5);
  }

  /**
   * PATHING. `pull` is what a delver is walking toward: raw depth (they came here to go down) plus
   * every lure in the hollow, felt through the rock. Movement itself is a breadth-first step
   * toward the best-scoring open cell they have not already given up on.
   *
   * ⚠️ BFS over open cells and not "walk downhill", because a hollow that forks is the entire
   * point of the game — a greedy stepper would ignore the long bleeding corridor you built and
   * wander into whichever neighbour happened to be lower.
   */
  function pullMap(s) {
    const pull = new Float64Array(s.cells.length);
    for (const c of s.cells) {
      if (!c.dug) continue;
      /* ⚠️ THE DEPTH WEIGHT WAS 1.0 AND TIMID DELVERS NEVER WENT IN AT ALL. With the distance
       * penalty at (1.4 - greed), a scrounger scored its own square at the mouth HIGHER than a
       * chamber six rows down, so it turned around before taking a single step and left with
       * nothing — six of twelve "escapes" in the lethal test were delvers that never entered the
       * hollow. Nobody walks to a cave mouth and goes home; depth has to outweigh the walk. */
      pull[c.y * D.COLS + c.x] += c.y * 2.2 + c.rubble * 0.05;
    }
    for (const c of s.cells) {
      const l = lureAt(s, c);
      if (l <= 0) continue;
      for (const o of s.cells) {
        if (!o.dug) continue;
        const d = Math.abs(o.x - c.x) + Math.abs(o.y - c.y);
        pull[o.y * D.COLS + o.x] += l / (1 + d * 0.9);
      }
    }
    return pull;
  }

  /** Shortest step from (x,y) toward `tx,ty` across open cells. null when there is no route. */
  function stepToward(s, x, y, tx, ty) {
    if (x === tx && y === ty) return null;
    const prev = new Int32Array(s.cells.length).fill(-1);
    const seen = new Uint8Array(s.cells.length);
    const q = [y * D.COLS + x];
    seen[y * D.COLS + x] = 1;
    const goal = ty * D.COLS + tx;
    let found = false;
    for (let head = 0; head < q.length && !found; head++) {
      const cur = q[head];
      const cx = cur % D.COLS, cy = (cur - cx) / D.COLS;
      for (const [dx, dy] of [[0, 1], [1, 0], [-1, 0], [0, -1]]) {
        const n = cellAt(s, cx + dx, cy + dy);
        if (!n || !n.dug) continue;
        const ni = n.y * D.COLS + n.x;
        if (seen[ni]) continue;
        seen[ni] = 1; prev[ni] = cur;
        if (ni === goal) { found = true; break; }
        q.push(ni);
      }
    }
    if (!found) return null;
    let cur = goal;
    while (prev[cur] !== y * D.COLS + x) {
      cur = prev[cur];
      if (cur < 0) return null;
    }
    return { x: cur % D.COLS, y: (cur - (cur % D.COLS)) / D.COLS };
  }

  const API = {
    makeState, cellAt, recompute, waterRow, digCost, canDig, dig, place, upgrade, buyVein,
    fixtureUnlocked, rootIncome, seep, sinkTick, lureAt, tollAt, pullMap, stepToward, vein, veinMul,
  };

  if (typeof module === 'object' && module.exports) module.exports = API;
  else root.HOLLOW = API;
})(typeof self !== 'undefined' ? self : this);
