/**
 * game.js — state, loop, input and every screen. Wires data + hollow + delvers + art + sound + save.
 *
 * ⛔ WHAT THIS FILE MAY NOT DO: draw a string with `ctx.fillText`, or a control with `ctx.fillRect`
 * plus a label. Everything goes through `ART.text` / `ART.paragraph` / `ART.button`, because
 * `Internal_Ops/test_layout.js` replaces exactly those three to record what was drawn. A helper
 * that bypasses them is invisible to the gate, and §3e-1 measured that the invisible lines are
 * precisely the ones that overflow.
 *
 * ⛔ AND THE SIMULATION MUST BE DRIVABLE WITH THE CLOCK OFF. `setRenderPaused` and an explicit
 * `draw()` exist because a capture harness and the game's own rAF loop are two drivers on one
 * clock (§3c-7, measured on ANNEAL: the store GIF came out as half a static result screen and
 * every check was green).
 */
(function (root) {
  'use strict';

  const D = root.DATA, H = root.HOLLOW, DV = root.DELVERS, ART = root.ART, SOUND = root.SOUND, SAVE = root.SAVE;

  const CW = 960, CH = 620;
  const CELL = 44;
  const BX = 22, BY = 52;                       // board origin
  const BW = D.COLS * CELL, BH = D.ROWS * CELL; // 396 x 528
  const PX = BX + BW + 16;                      // panel origin
  const PW = CW - PX - 20;                      // 526

  const canvas = document.getElementById('c');
  const ctx = canvas.getContext('2d');

  let s = H.makeState();
  let mode = 'welcome';
  let sel = null;                 // {x,y} selected chamber
  let hover = null;
  let mouse = { x: -1, y: -1 };
  let hits = [];                  // hit-test rects rebuilt every draw
  let renderPaused = false;
  let last = 0;
  let saveT = 0;
  let awayReport = null;
  let toast = null, toastT = 0;
  let flashT = 0;
  let unrottedT = 0;
  const nagged = {};

  /* A tiny deterministic PRNG so `balance.js` and `test_sim.js` can replay a session exactly. The
   * live game seeds it from the clock; the harnesses seed it from a constant. */
  let rngState = (Date.now() ^ 0x9e3779b9) >>> 0;
  function rnd() {
    rngState = (Math.imul(rngState ^ (rngState >>> 15), rngState | 1) + 0x6d2b79f5) >>> 0;
    return (rngState >>> 8) / 16777216;
  }

  function log(msg) {
    s.log.push({ t: s.elapsed, msg });
    if (s.log.length > 40) s.log.shift();
  }
  function say(msg) { toast = msg; toastT = 2.6; }

  function fmt(n) {
    if (n < 1000) return String(Math.floor(n));
    if (n < 1e6) return (n / 1000).toFixed(n < 1e4 ? 2 : 1) + 'k';
    if (n < 1e9) return (n / 1e6).toFixed(2) + 'M';
    return (n / 1e9).toFixed(2) + 'B';
  }

  /* ── simulation ───────────────────────────────────────────────────────────────────────────── */

  function step(dt) {
    s.elapsed += dt;
    if (s.floodT > 0) s.floodT = Math.max(0, s.floodT - dt);
    H.recompute(s);
    s.spoil += H.rootIncome(s) * dt;
    const marrowBefore = s.marrow;
    H.sinkTick(s, dt);
    if (s.marrow - marrowBefore > 0.5) SOUND.marrow();
    const killedBefore = s.killed, escapedBefore = s.escaped, shardBefore = s.shardsLost;
    DV.tick(s, dt, rnd, log);
    if (s.killed > killedBefore) SOUND.die();
    if (s.escaped > escapedBefore) SOUND.escape();
    if (s.shardsLost > shardBefore) { SOUND.shard(); flashT = 1.2; }

    /* Announce a newly reachable fixture once, and only once — a silent unlock is an unlock the
     * player never finds, and §3e names the unlock screens as where this wing loses Gate 1. */
    for (const f of D.FIXTURES) {
      if (s.deepest >= f.unlock && !s.unlockedSeen[f.id]) {
        s.unlockedSeen[f.id] = 1;
        if (s.elapsed > 1) { log('You have cut deep enough for a ' + f.name + '.'); SOUND.unlockThing(); }
      }
    }
    if (s.sealed && !s.seenEnding) { s.seenEnding = true; mode = 'ending'; }

    /* ⛔ THE ONE HINT THE GAME REFUSES TO LEAVE IMPLICIT. A sink only reaches a few chambers, so
     * a player who kills at the mouth and builds presses at the bottom gets no marrow at all and
     * nothing on screen says why — the campaign probe made exactly that mistake and produced ZERO
     * marrow across 815 kills, which would have shipped as "the meta layer is broken". Said once
     * per pile, not every tick, because a warning that repeats is a warning nobody reads. */
    unrottedT += dt;
    if (unrottedT > 12) {
      unrottedT = 0;
      let worst = null;
      for (const c of s.cells) if (c.remains > 40 && (!worst || c.remains > worst.remains)) worst = c;
      if (worst && !nagged[worst.y * D.COLS + worst.x]) {
        nagged[worst.y * D.COLS + worst.x] = 1;
        log('Bodies are piling up at row ' + (worst.y + 1) + ' with nothing near enough to render them.');
      }
    }

    saveT += dt;
    if (saveT >= D.TUNE.autosaveSecs) { saveT = 0; SAVE.save(s); }
  }

  /* ── input ────────────────────────────────────────────────────────────────────────────────── */

  function hit(id, x, y, w, h, fn) { hits.push({ id, x, y, w, h, fn }); }

  function cellFromPoint(mx, my) {
    if (mx < BX || my < BY || mx >= BX + BW || my >= BY + BH) return null;
    return { x: Math.floor((mx - BX) / CELL), y: Math.floor((my - BY) / CELL) };
  }

  function onClick(mx, my) {
    SOUND.unlock();
    for (let i = hits.length - 1; i >= 0; i--) {
      const r = hits[i];
      if (mx >= r.x && my >= r.y && mx < r.x + r.w && my < r.y + r.h) { r.fn(); return; }
    }
    if (mode === 'play') {
      const c = cellFromPoint(mx, my);
      if (c) sel = c;
    }
  }

  canvas.addEventListener('mousemove', (e) => {
    const r = canvas.getBoundingClientRect();
    mouse.x = (e.clientX - r.left) * (CW / r.width);
    mouse.y = (e.clientY - r.top) * (CH / r.height);
    hover = mode === 'play' ? cellFromPoint(mouse.x, mouse.y) : null;
  });
  canvas.addEventListener('mouseleave', () => { mouse.x = -1; mouse.y = -1; hover = null; });
  canvas.addEventListener('click', (e) => {
    const r = canvas.getBoundingClientRect();
    onClick((e.clientX - r.left) * (CW / r.width), (e.clientY - r.top) * (CH / r.height));
  });
  canvas.addEventListener('touchstart', (e) => {
    const r = canvas.getBoundingClientRect();
    const t = e.changedTouches[0];
    onClick((t.clientX - r.left) * (CW / r.width), (t.clientY - r.top) * (CH / r.height));
    e.preventDefault();
  }, { passive: false });
  window.addEventListener('keydown', (e) => {
    if (e.key === 'm' || e.key === 'M') { SOUND.setEnabled(!SOUND.isEnabled()); }
    if (e.key === 'Escape' && (mode === 'help' || mode === 'veins' || mode === 'ending')) mode = 'play';
  });

  /* ── drawing ──────────────────────────────────────────────────────────────────────────────── */

  const GOLD = '#d8b95e', PALE = '#e2dcc6', DIM = '#8f8b7c', RED = '#c9695f', BLUE = '#79bcd2', GREEN = '#8bbb6a';

  function drawTopBar() {
    ART.panel(ctx, 0, 0, CW, 44, 0.5);
    ART.text(ctx, 'SWALLET', 18, 30, { size: 24, weight: 700, colour: GOLD });
    const stats = [
      ['spoil', fmt(s.spoil), PALE],
      ['marrow', fmt(s.marrow), '#c9a3d8'],
      ['renown', Math.floor(s.renown) + '', GREEN],
      ['depth', (s.deepest + 1) + '/' + D.ROWS, PALE],
      ['water at', 'row ' + Math.max(1, Math.min(D.ROWS, s.waterRow + 1)), BLUE],
    ];
    let x = 150;
    for (const [label, val, col] of stats) {
      ART.text(ctx, label, x, 18, { size: 11, colour: DIM, sans: true });
      const w = ART.text(ctx, val, x, 35, { size: 17, weight: 600, colour: col });
      x += Math.max(74, w + 30);
    }
    const rate = H.rootIncome(s);
    ART.text(ctx, '+' + rate.toFixed(1) + '/s from roots', CW - 250, 28, { size: 12, colour: DIM, align: 'right' });

    const b1 = ART.button(ctx, 'VEINS', CW - 236, 9, 74, 26, { hot: inRect(CW - 236, 9, 74, 26), size: 12 });
    hit('veins', b1.x, b1.y, b1.w, b1.h, () => { mode = 'veins'; });
    const b2 = ART.button(ctx, 'HOW IT WORKS', CW - 154, 9, 106, 26, { hot: inRect(CW - 154, 9, 106, 26), size: 12 });
    hit('help', b2.x, b2.y, b2.w, b2.h, () => { mode = 'help'; });
    const b3 = ART.button(ctx, SOUND.isEnabled() ? '♪' : '·', CW - 40, 9, 26, 26, { hot: inRect(CW - 40, 9, 26, 26), size: 13 });
    hit('mute', b3.x, b3.y, b3.w, b3.h, () => SOUND.setEnabled(!SOUND.isEnabled()));
  }

  function inRect(x, y, w, h) { return mouse.x >= x && mouse.y >= y && mouse.x < x + w && mouse.y < y + h; }

  function drawBoard(t) {
    for (const c of s.cells) {
      const x = BX + c.x * CELL, y = BY + c.y * CELL;
      const plate = D.stratumAt(c.y).plate;
      if (!c.dug) ART.rock(ctx, plate, x, y, CELL, CELL);
      else {
        ART.chamber(ctx, plate, x, y, CELL, CELL, c.wet, t);
        ART.rubble(ctx, x, y, CELL, CELL, c.rubble);
        ART.remains(ctx, x, y, CELL, CELL, c.remains);
        if (c.fixture) {
          const f = D.FIXTURE_BY_ID[c.fixture.id];
          ART.fixture(ctx, f.sheet, c.fixture.level, x + 1, y + 1, CELL - 2);
        }
      }
    }

    // the mouth, so the entrance reads as an entrance rather than as the first empty square
    ctx.save();
    ctx.strokeStyle = 'rgba(216,185,94,0.55)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(BX + D.MOUTH_X * CELL + 6, BY - 1);
    ctx.lineTo(BX + D.MOUTH_X * CELL + CELL - 6, BY - 1);
    ctx.stroke();
    ctx.restore();

    // the water table, drawn as a line across the whole hill — the second system, made visible
    const wt = s.waterRow;
    if (wt < D.ROWS) {
      const y = BY + wt * CELL;
      ctx.save();
      ctx.strokeStyle = 'rgba(121,188,210,0.42)';
      ctx.setLineDash([5, 5]);
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(BX, y + 0.5); ctx.lineTo(BX + BW, y + 0.5); ctx.stroke();
      ctx.restore();
    }

    // delvers, tweened between the cell they left and the cell they are in
    for (const d of s.delvers) {
      const stepSecs = D.TUNE.stepSecs / d.pace;
      const k = d.state === 'dead' ? 1 : Math.max(0, Math.min(1, d.t / stepSecs));
      const gx = BX + (d.px + (d.x - d.px) * k) * CELL;
      const gy = BY + (d.py + (d.y - d.py) * k) * CELL;
      const scale = 2;
      const px0 = gx + (CELL - 14 * scale) / 2;
      const py0 = gy + CELL - 20 * scale - 2;
      let pose = 3;
      if (d.state !== 'dead') pose = d.hurtT > 0 ? 2 : (Math.floor(s.elapsed * 4 + d.id) % 2);
      ART.delver(ctx, d.sheet, pose, px0, py0, scale);
      if (d.state !== 'dead') {
        const w = 22, frac = Math.max(0, d.grit / d.maxGrit);
        ctx.save();
        ctx.fillStyle = 'rgba(0,0,0,0.65)';
        ctx.fillRect(gx + (CELL - w) / 2, gy + 3, w, 3);
        ctx.fillStyle = frac > 0.55 ? GREEN : (frac > 0.3 ? GOLD : RED);
        ctx.fillRect(gx + (CELL - w) / 2, gy + 3, w * frac, 3);
        ctx.restore();
      }
    }

    // hover and selection
    if (hover) {
      const x = BX + hover.x * CELL, y = BY + hover.y * CELL;
      ctx.save();
      ctx.strokeStyle = 'rgba(226,220,198,0.42)';
      ctx.lineWidth = 1;
      ctx.strokeRect(x + 0.5, y + 0.5, CELL - 1, CELL - 1);
      ctx.restore();
    }
    if (sel) {
      const x = BX + sel.x * CELL, y = BY + sel.y * CELL;
      ctx.save();
      ctx.strokeStyle = GOLD;
      ctx.lineWidth = 2;
      ctx.strokeRect(x + 1, y + 1, CELL - 2, CELL - 2);
      ctx.restore();
    }

    // stratum names down the left gutter
    for (const st of D.STRATA) {
      const y = BY + st.from * CELL + (st.to - st.from + 1) * CELL / 2;
      ctx.save();
      ctx.translate(BX - 8, y);
      ctx.rotate(-Math.PI / 2);
      ART.text(ctx, st.name, 0, 0, { size: 11, align: 'center', colour: DIM, sans: true });
      ctx.restore();
    }
  }

  /**
   * The right-hand column. Everything you can DO is here, and it is always about the SELECTED
   * chamber — one noun, then its verbs, rather than a palette of tools with modes.
   *
   * ⛔ THE LAYOUT IS BANDED, AND THAT IS A GATE 1 FIX RATHER THAN A PREFERENCE. The first version
   * let the selection block flow and put the log at the bottom, which left SIXTY PERCENT of a
   * 526x528 panel as flat black in the store frames — §1.1a's dead-space failure, and the largest
   * single thing wrong with the game when I first opened the captures. The bands below are fixed,
   * the fixture list is two columns so it fits its band, and THE HOLLOW always fills the middle
   * with the five numbers a player actually wants: when the next cohort lands, where the income
   * comes from, what renown is about to buy them, and what the water is doing.
   */
  /* ⚠️ THESE NUMBERS WERE GUESSED ONCE AND THE LAYOUT GATE REPORTED FOUR REAL COLLISIONS —
   * "HEARTSTONE" printing through "WHAT HAPPENED", the fixture grid starting ABOVE its own header
   * so two title strings sat inside buttons, and a fixture's effect line landing on the contents
   * line. The panel is 528px and the bands below add up to less than that, deliberately, with the
   * arithmetic written down so the next person changing one can check it:
   *   header   52..142   (title, contents, damp, blurb)
   *   effect  198..238   (fixtures only)
   *   action  250..286   (one button)  ·  grid 148..304 (six rows of 26, two columns)
   *   hollow  352..462   (heading, cohort bar, four rows)
   *   log     492..569   (heading, four wrapped lines)   panel bottom 580 */
  const SEL_BLURB = BY + 90, SEL_EFFECT = BY + 146, BAND_ACTION = BY + 198;
  const GRID_TOP = BY + 96, GRID_ROW = 26;
  const BAND_HOLLOW = BY + 300, BAND_LOG = BY + 440;

  function drawPanel() {
    ART.panel(ctx, PX, BY, PW, BH, 0.42);
    const ix = PX + 16, iw = PW - 32;
    let y = BY + 28;

    /* A selection that does not resolve to a cell is the same thing as no selection. Belt and
     * braces with the guard in `select` — the renderer must never be the thing that throws. */
    if (sel && !H.cellAt(s, sel.x, sel.y)) sel = null;

    if (!sel) {
      ART.text(ctx, 'NOTHING SELECTED', ix, y, { size: 17, weight: 700, colour: GOLD });
      y += 24;
      ART.paragraph(ctx, 'Pick a square on the hill. Solid rock can be CUT if something open touches it; an open chamber holds one fixture.', ix, y, iw, { size: 13, colour: PALE });
      drawHollowBlock();
      drawLog(BAND_LOG);
      return;
    }

    const c = H.cellAt(s, sel.x, sel.y);
    const st = D.stratumAt(sel.y);
    ART.text(ctx, st.name + ' · ROW ' + (sel.y + 1), ix, y, { size: 17, weight: 700, colour: GOLD });
    y += 22;
    ART.text(ctx, c.dug ? (c.fixture ? D.FIXTURE_BY_ID[c.fixture.id].name + ' · level ' + (c.fixture.level + 1) : 'an empty chamber') : 'solid rock',
      ix, y, { size: 13, colour: PALE });
    y += 18;
    const wetWord = c.wet <= 0 ? 'dry' : (c.wet >= 0.99 ? 'drowned' : 'seeping');
    ART.text(ctx, wetWord + (c.remains > 0.5 ? ' · ' + fmt(c.remains) + ' unrendered' : '') + (c.rubble > 0.5 ? ' · ' + fmt(c.rubble) + ' loose spoil' : ''),
      ix, y, { size: 12, colour: c.wet > 0 ? BLUE : DIM, sans: true });
    y += 22;

    if (!c.dug) {
      const can = H.canDig(s, sel.x, sel.y);
      const cost = H.digCost(s, sel.x, sel.y);
      ART.paragraph(ctx, st.blurb, ix, SEL_BLURB, iw, { size: 12, colour: DIM });
      y = BAND_ACTION;
      const afford = s.spoil >= cost;
      const b = ART.button(ctx, can ? 'CUT — ' + fmt(cost) + ' spoil' : 'nothing open touches this', ix, y, iw, 36,
        { hot: inRect(ix, y, iw, 36) && can && afford, disabled: !can || !afford, size: 15 });
      if (can && afford) hit('dig', b.x, b.y, b.w, b.h, () => {
        const r = H.dig(s, sel.x, sel.y);
        if (r.ok) { SOUND.dig(); log('Cut a new chamber at row ' + (sel.y + 1) + '.'); } else { SOUND.deny(); say(r.why); }
      });
      y += 46;
      if (can && !afford) ART.text(ctx, 'You need ' + fmt(cost - s.spoil) + ' more spoil.', ix, y, { size: 13, colour: RED });
      else if (can) ART.text(ctx, 'Cutting here opens the way to ' + (sel.y + 1 < D.ROWS ? 'row ' + (sel.y + 2) : 'the heartstone') + '.', ix, y, { size: 13, colour: DIM });
      drawHollowBlock();
      drawLog(BAND_LOG);
      return;
    }

    if (c.fixture) {
      const f = D.FIXTURE_BY_ID[c.fixture.id];
      ART.paragraph(ctx, f.blurb, ix, SEL_BLURB, iw, { size: 12, colour: DIM });
      ART.paragraph(ctx, effectLine(c, f), ix, SEL_EFFECT, iw, { size: 14, colour: PALE });
      y = BAND_ACTION;
      if (c.fixture.level < D.MAX_FIXTURE_LEVEL - 1) {
        const cost = D.fixtureCost(f, c.fixture.level + 1);
        const afford = s.spoil >= cost;
        const b = ART.button(ctx, 'DEEPEN TO LEVEL ' + (c.fixture.level + 2) + ' — ' + fmt(cost), ix, y, iw, 36,
          { hot: inRect(ix, y, iw, 36) && afford, disabled: !afford, size: 15 });
        if (afford) hit('up', b.x, b.y, b.w, b.h, () => {
          const r = H.upgrade(s, sel.x, sel.y);
          if (r.ok) SOUND.place(); else { SOUND.deny(); say(r.why); }
        });
      } else {
        ART.text(ctx, 'At its best. Nothing more goes into this chamber.', ix, y + 24, { size: 14, colour: GREEN });
      }
      drawHollowBlock();
      drawLog(BAND_LOG);
      return;
    }

    /* An empty chamber: everything you have found, priced, in TWO COLUMNS. One column of twelve
     * was 360px of a 230px band — it either overflowed into the log or silently truncated the
     * list, and a fixture you cannot see is a fixture you do not own. */
    ART.text(ctx, 'PUT SOMETHING HERE', ix, y, { size: 12, colour: DIM, sans: true, weight: 600 });
    const list = D.FIXTURES.filter((f) => H.fixtureUnlocked(s, f));
    const colW = (iw - 12) / 2, rowH = GRID_ROW;
    for (let i = 0; i < list.length; i++) {
      const f = list[i];
      const col = i % 2, row = Math.floor(i / 2);
      const bx = ix + col * (colW + 12), by = GRID_TOP + row * rowH;
      if (by + rowH - 4 > BAND_HOLLOW - 30) break;
      const cost = D.fixtureCost(f, 0);
      const afford = s.spoil >= cost;
      const b = ART.button(ctx, f.name + ' · ' + fmt(cost), bx, by, colW, rowH - 4,
        { hot: inRect(bx, by, colW, rowH - 4) && afford, disabled: !afford, size: 12 });
      if (afford) hit('place-' + f.id, b.x, b.y, b.w, b.h, () => {
        const r = H.place(s, sel.x, sel.y, f.id);
        if (r.ok) { SOUND.place(); } else { SOUND.deny(); say(r.why); }
      });
    }
    const rows = Math.ceil(list.length / 2);
    const nextLocked = D.FIXTURES.find((f) => !H.fixtureUnlocked(s, f));
    if (nextLocked) {
      ART.text(ctx, 'Cut to row ' + (nextLocked.unlock + 1) + ' to find the ' + nextLocked.name + '.',
        ix, GRID_TOP + rows * rowH + 16, { size: 12, colour: DIM });
    }
    drawHollowBlock();
    drawLog(BAND_LOG);
  }

  /**
   * ⭐ THE BLOCK THAT FILLS THE PANEL AND EARNS ITS SPACE. Five readouts a player wants every few
   * seconds and previously had to infer: when the next lot arrive and how many, where the income
   * is really coming from, what renown is about to change, what the water is doing to the
   * workings, and the running tally of the dead. It is also the answer to the dead-space failure
   * in the first store captures — the fix for empty is CONTENT, not a bigger font.
   */
  function drawHollowBlock() {
    const ix = PX + 16, iw = PW - 32;
    let y = BAND_HOLLOW;
    ctx.save();
    ctx.strokeStyle = 'rgba(150,150,170,0.14)';
    ctx.beginPath(); ctx.moveTo(ix, y - 18.5); ctx.lineTo(ix + iw, y - 18.5); ctx.stroke();
    ctx.restore();

    ART.text(ctx, 'THE HOLLOW', ix, y, { size: 11, colour: DIM, sans: true, weight: 600 });
    y += 20;

    // next cohort, with a bar — the clock the whole game runs on
    const left = Math.max(0, D.TUNE.cohortSecs - s.cohortT);
    const n = Math.min(D.TUNE.cohortMax, 1 + Math.floor(s.renown / D.TUNE.renownPerCohort));
    const kinds = D.ARCHETYPES.filter((a) => s.renown >= a.renown);
    ART.text(ctx, 'NEXT COHORT', ix, y, { size: 12, colour: DIM, sans: true });
    ART.text(ctx, Math.ceil(left) + 's · ' + n + ' delver' + (n > 1 ? 's' : '') + ' · up to ' + kinds[kinds.length - 1].name + 's',
      ix + 150, y, { size: 13, colour: PALE });
    y += 8;
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.55)'; ctx.fillRect(ix, y, iw, 4);
    ctx.fillStyle = GOLD; ctx.fillRect(ix, y, iw * (1 - left / D.TUNE.cohortSecs), 4);
    ctx.restore();
    y += 22;

    const seepRate = H.seep(s), total = H.rootIncome(s);
    const rowsOut = [
      ['INCOME', (total).toFixed(1) + '/s — ' + seepRate.toFixed(1) + ' seeps in, ' + (total - seepRate).toFixed(1) + ' from roots', PALE],
      ['RENOWN', Math.floor(s.renown) + (nextKind() ? ' · ' + nextKind().name + 's start coming at ' + nextKind().renown : ' · every kind is coming down now'), GREEN],
      ['WATER', 'row ' + Math.max(1, Math.min(D.ROWS, s.waterRow + 1)) + ' · ' + drownedCount() + ' chamber' + (drownedCount() === 1 ? '' : 's') + ' under it', BLUE],
      ['THE DEAD', s.killed + ' died · ' + s.escaped + ' out with ' + fmt(s.spoilStolen) + ' · ' + s.shardsLost + ' shard' + (s.shardsLost === 1 ? '' : 's'), '#c8a0a0'],
    ];
    for (const [label, val, col] of rowsOut) {
      ART.text(ctx, label, ix, y, { size: 12, colour: DIM, sans: true });
      ART.text(ctx, val, ix + 150, y, { size: 13, colour: col });
      y += 21;
    }
  }

  function nextKind() { return D.ARCHETYPES.find((a) => s.renown < a.renown) || null; }
  function drownedCount() { let n = 0; for (const c of s.cells) if (c.dug && c.wet > 0) n++; return n; }

  function effectLine(c, f) {
    const lv = c.fixture.level + 1;
    if (f.family === 'root') {
      let v = f.yield * lv * H.veinMul(s, 'taproot');
      if (f.everWet) return 'Yields ' + v.toFixed(2) + ' spoil a second, wet or dry.';
      if (f.needsWet) return 'Yields ' + (v * c.wet).toFixed(2) + ' spoil a second here (needs water; this chamber is ' + Math.round(c.wet * 100) + '% drowned).';
      return 'Yields ' + (v * (1 - c.wet)).toFixed(2) + ' spoil a second here' + (c.wet > 0 ? ' — the water is taking ' + Math.round(c.wet * 100) + '% of it.' : '.');
    }
    if (f.family === 'ward') {
      const dry = f.toll * lv * H.veinMul(s, 'bite');
      const here = H.tollAt(s, c, 0);
      return 'Takes ' + here.toFixed(1) + ' from each delver here' + (here < dry * 0.95 ? ' — ' + Math.round((1 - here / dry) * 100) + '% is lost to the water.' : '.');
    }
    if (f.family === 'lure') return 'Pulls at ' + (f.draw * lv * H.veinMul(s, 'beacon')).toFixed(1) + ', felt right through the rock.';
    if (f.family === 'sink') {
      const r = f.rate * lv * H.veinMul(s, 'render') * (1 + 0.8 * c.wet);
      return 'Renders ' + r.toFixed(1) + ' a second' + (f.marrow ? ', and ' + (r * f.marrow).toFixed(3) + ' of that comes out as marrow.' : '.') + ' Reaches one chamber in every direction.';
    }
    if (f.family === 'drain') return 'Holds the water table ' + lv + ' row' + (lv > 1 ? 's' : '') + ' lower across the whole hill.';
    return '';
  }

  function drawLog(y) {
    const ix = PX + 16, iw = PW - 32;
    ctx.save();
    ctx.strokeStyle = 'rgba(150,150,170,0.14)';
    ctx.beginPath(); ctx.moveTo(ix, y - 18.5); ctx.lineTo(ix + iw, y - 18.5); ctx.stroke();
    ctx.restore();
    ART.text(ctx, 'WHAT HAPPENED', ix, y, { size: 11, colour: DIM, sans: true, weight: 600 });
    const lines = s.log.slice(-5);
    for (let i = 0; i < lines.length; i++) {
      /* ⛔ WRAPPED, not drawn raw. Canvas text does not clip, and the longest line this game emits
       * ("A surveyor gets out with 128456 spoil...") is comfortably wider than the panel — which is
       * exactly the FLOODMARK failure §3e-1 was written for. Only the last line is allowed two
       * rows; the rest are single lines so the band cannot grow into the panel's edge. */
      const opts = { size: 12, colour: i === lines.length - 1 ? PALE : DIM };
      const wrapped = ART.wrap(ctx, lines[i].msg, iw, opts);
      ART.text(ctx, wrapped.length > 1 ? wrapped[0] + '…' : wrapped[0], ix, y + 20 + i * 19, opts);
    }
  }

  /**
   * The strip under the board. ⚠️ It used to repeat the kill/escape tally that THE HOLLOW block
   * now carries — the same numbers twice on one screen, which is worse than either alone because
   * it makes the reader check whether they disagree. It says the one thing the panel cannot: what
   * just went wrong, or what the hill is doing right now.
   */
  function drawStatus() {
    const y = BY + BH + 10;
    if (s.floodT > 0) ART.text(ctx, 'THE DEEP IS FLOODED — ' + Math.ceil(s.floodT) + 's left', BX, y + 20, { size: 14, colour: BLUE, weight: 600 });
    else if (toast && toastT > 0) ART.text(ctx, toast, BX, y + 20, { size: 14, colour: RED });
    else if (s.sealed) ART.text(ctx, 'The seal is set. Nothing is coming for the heartstone now.', BX, y + 20, { size: 13, colour: GOLD });
    else ART.text(ctx, hint(), BX, y + 20, { size: 13, colour: DIM });
  }

  /** One sentence of guidance keyed to the actual board state, not to a tutorial step counter. */
  function hint() {
    if (s.cells.filter((c) => c.dug).length <= 1) return 'Click the rock under the mouth, then CUT it. Everything starts with a hole.';
    if (!s.cells.some((c) => c.fixture)) return 'An open chamber does nothing on its own. Put a MOSS BED or a SNARE in one.';
    if (!s.cells.some((c) => c.fixture && D.FIXTURE_BY_ID[c.fixture.id].family === 'ward')) return 'Nothing here is taking a toll yet. A ward is what turns a delver into income.';
    if (s.killed > 0 && !s.cells.some((c) => c.fixture && D.FIXTURE_BY_ID[c.fixture.id].family === 'sink')) return 'Bodies are worth more than the toll was. You need a sink beside where they die.';
    if (s.marrow < 1 && s.killed > 6) return 'Marrow comes out of bodies rendered DEEP. Kill them further down, next to something that can use them.';
    return 'Cut deeper. Every band changes what works, and the water is coming up behind you.';
  }

  /* ── full-screen screens ──────────────────────────────────────────────────────────────────── */

  /**
   * ⛔ THE FIRST VERSION OF THIS SCREEN WAS A TITLE ON A BLACK RECTANGLE and 60% of it was empty —
   * §1.1a's dead-space failure on the one image every player and every browse thumbnail sees
   * first. §3e names the fix and it is not a bigger font or a stock illustration: "compose the mark
   * from the game's OWN renderer at the real data ... the §1.1 shape, and it cannot drift from the
   * mechanic." So the bottom half is a real cutaway drawn with the real plates, the real chamber
   * vocabulary, the real fixture sheet and the real delver sprites. It is the game, small.
   */
  const DIORAMA = [
    // [col, row, fixtureSheetCol, level] — a small hollow, hand-composed to read at a glance
    [3, 0, -1, 0], [3, 1, 5, 1], [2, 1, 0, 2], [3, 2, 3, 1], [4, 2, 8, 1],
    [3, 3, 6, 2], [2, 3, 1, 1], [3, 4, 9, 1], [4, 4, 4, 0], [3, 5, 10, 1], [2, 5, 2, 2],
  ];

  function drawDiorama(top) {
    const cell = 46;
    const rows = 6;
    /* ⚠️ THE BANDS RUN EDGE TO EDGE. The first version drew nine columns centred, which left black
     * bars down both sides and made the hill look like a screenshot pasted onto the title rather
     * than a section through the ground. The hollow itself stays centred; the rock just keeps
     * going, because rock does. */
    const ox = Math.round(CW / 2 - 3.5 * cell);
    const c0 = Math.floor(-ox / cell) - 1, c1 = Math.ceil((CW - ox) / cell) + 1;
    const bandOf = (r) => (r < 2 ? 'loam' : r < 3 ? 'chalk' : r < 5 ? 'shale' : 'granite');
    const open = new Set(DIORAMA.map(([c, r]) => c + ',' + r));
    for (let r = 0; r < rows; r++) {
      for (let c = c0; c <= c1; c++) {
        const x = ox + c * cell, y = top + r * cell;
        if (!open.has(c + ',' + r)) ART.rock(ctx, bandOf(r), x, y, cell, cell);
        else ART.chamber(ctx, bandOf(r), x, y, cell, cell, r >= 5 ? 0.8 : 0, s.elapsed);
      }
    }
    for (const [c, r, f, lv] of DIORAMA) {
      if (f < 0) continue;
      ART.fixture(ctx, f, lv, ox + c * cell + 1, top + r * cell + 1, cell - 2);
    }
    // three delvers on their way down, one already fallen
    ART.delver(ctx, 0, 0, ox + 3 * cell + 9, top + 0 * cell + cell - 42, 2);
    ART.delver(ctx, 2, 1, ox + 3 * cell + 9, top + 2 * cell + cell - 42, 2);
    ART.delver(ctx, 3, 3, ox + 3 * cell + 9, top + 4 * cell + cell - 42, 2);
    // the mouth
    ctx.save();
    ctx.strokeStyle = 'rgba(216,185,94,0.6)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(ox + 3 * cell + 6, top - 1); ctx.lineTo(ox + 4 * cell - 6, top - 1);
    ctx.stroke();
    ctx.restore();
    /* Fade the TOP EDGE of the rock into the dark, so the section starts rather than begins with a
     * ruled line. ⚠️ The first attempt started the gradient 40px ABOVE the rock at full opacity,
     * which painted a solid band over the background and produced exactly the hard horizontal line
     * it was meant to hide. It has to start ON the rock. */
    const g = ctx.createLinearGradient(0, top, 0, top + 56);
    g.addColorStop(0, 'rgba(7,8,10,0.96)');
    g.addColorStop(1, 'rgba(7,8,10,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, top, CW, 56);
  }

  /**
   * ⭐ NO FULL-SCREEN MODE SITS ON FLAT BLACK. `visual_density.js` measured the veins screen at
   * 0.194 ink / 236 colours and the help screen at 0.138 / 337 — the lowest numbers in the whole
   * gallery — and opening them confirmed what the numbers were pointing at: text floating on a void.
   * The game has four beautiful generated rock plates and was showing them on exactly one screen.
   * A deep, heavily dimmed section of the real strata behind every menu costs nothing, cannot drift
   * from the product, and makes the whole thing feel like one place instead of a game plus some
   * dialogs. §3e's point exactly: the fix for a flat screen is the game's OWN renderer, not a
   * decoration bought in from somewhere else.
   */
  function drawBackdrop() {
    const band = CH / 4;
    for (let i = 0; i < 4; i++) ART.rock(ctx, D.STRATA[i].plate, 0, i * band, CW, band + 1);
    ctx.save();
    ctx.fillStyle = 'rgba(6,7,10,0.80)';
    ctx.fillRect(0, 0, CW, CH);
    ctx.restore();
  }

  function drawWelcome() {
    drawBackdrop();
    ART.panel(ctx, 0, 0, CW, CH, 0.20);
    drawDiorama(344);
    const x = 150, w = CW - 300;
    let y = 76;
    ART.text(ctx, 'SWALLET', CW / 2, y, { size: 58, weight: 700, align: 'center', colour: GOLD });
    y += 30;
    ART.text(ctx, 'a hole in the hill · they keep coming down', CW / 2, y, { size: 16, align: 'center', colour: DIM });
    y += 42;
    y += ART.paragraph(ctx, 'You are the cave. Cut chambers, put things in them, and decide what happens to the people who come looking.', x, y, w, { size: 16, align: 'left' });
    y += 10;
    y += ART.paragraph(ctx, 'Kill them and your sinks render what is left into spoil and marrow. Let them out alive and word spreads, and the next lot are richer. You need both, and they come from opposite outcomes.', x, y, w, { size: 15, colour: PALE });
    y += 18;
    const bw = 250;
    const b = ART.button(ctx, awayReport ? 'BACK TO THE HOLLOW' : 'OPEN THE MOUTH', CW / 2 - bw / 2, y, bw, 42, { hot: inRect(CW / 2 - bw / 2, y, bw, 42), size: 16 });
    hit('start', b.x, b.y, b.w, b.h, () => { mode = 'play'; SOUND.unlock(); });
    const b2 = ART.button(ctx, 'HOW IT WORKS', CW / 2 + bw / 2 + 12, y + 5, 150, 32, { hot: inRect(CW / 2 + bw / 2 + 12, y + 5, 150, 32), size: 13 });
    hit('help2', b2.x, b2.y, b2.w, b2.h, () => { mode = 'help'; });
    y += 62;
    if (awayReport) ART.text(ctx, awayReport, CW / 2, y, { size: 13, align: 'center', colour: GREEN });
    else ART.text(ctx, 'Free, in the browser. It saves itself, and nothing here ever resets.', CW / 2, y, { size: 13, align: 'center', colour: DIM });
  }

  function drawHelp() {
    drawBackdrop();
    ART.panel(ctx, 0, 0, CW, CH, 0.22);
    const colW = 400, lx = 84, rx = 500;
    let y = 76;
    ART.text(ctx, 'HOW IT WORKS', lx, y, { size: 26, weight: 700, colour: GOLD });
    y += 34;
    let ly = y;
    ly += ART.paragraph(ctx, 'CUT. Click solid rock next to an open chamber and pay the spoil. Rock gets dearer with every band and every row.', lx, ly, colW, { size: 14 });
    ly += 12;
    ly += ART.paragraph(ctx, 'FURNISH. One fixture per chamber. Roots make spoil on their own. Wards take a toll from anyone passing. Lures pull delvers deeper than they meant to go. Sinks render the dead into spoil, and the better ones into marrow.', lx, ly, colW, { size: 14 });
    ly += 12;
    ly += ART.paragraph(ctx, 'MARROW buys veins: permanent upgrades that never go away. The last of them ends the story.', lx, ly, colW, { size: 14, colour: '#c9a3d8' });

    /* ⚠️ THE BOTTOM-LEFT QUADRANT WAS EMPTY — about a third of this screen, on the page a new
     * player reads before touching anything. §1.1a asks "is any composite >20% empty"; this was.
     * The fix is content that belongs here anyway: the four bands, drawn from the SAME plate files
     * the board uses, so the legend cannot drift from the game. */
    ly += 22;
    ART.text(ctx, 'THE FOUR BANDS', lx, ly, { size: 15, weight: 700, colour: PALE });
    ly += 18;
    for (const st of D.STRATA) {
      ART.rock(ctx, st.plate, lx, ly, 38, 38);
      ctx.save();
      ctx.strokeStyle = 'rgba(150,150,170,0.22)';
      ctx.strokeRect(lx + 0.5, ly + 0.5, 37, 37);
      ctx.restore();
      ART.text(ctx, st.name + '  ·  rows ' + (st.from + 1) + '-' + (st.to + 1), lx + 50, ly + 14, { size: 13, weight: 600, colour: GOLD });
      /* ⚠️ ADVANCE BY WHAT WAS DRAWN, not by a constant. A fixed 46px step left the two-line
       * blurbs (chalk, shale) two pixels clear of the next band's title — legal to the gate,
       * cramped to a reader, and it would have broken outright the first time anyone lengthened a
       * sentence. `paragraph` already returns its height; use it. */
      const h = ART.paragraph(ctx, st.blurb, lx + 50, ly + 30, colW - 50, { size: 12, colour: DIM, lineHeight: 15 });
      ly += Math.max(46, 24 + h);
    }

    let ry = y;
    ART.text(ctx, 'THE TWO THINGS THAT FIGHT', rx, ry, { size: 15, weight: 700, colour: PALE });
    ry += 24;
    ry += ART.paragraph(ctx, 'A delver who DIES leaves remains for your sinks. A delver who GETS OUT ALIVE raises your renown, which is the only thing that makes the next cohort bigger and richer — and they carry off your spoil on the way. Kill everyone and nobody comes; kill nobody and you render nothing.', rx, ry, colW, { size: 14, colour: PALE });
    ry += 14;
    ry += ART.paragraph(ctx, 'Every row you cut RAISES THE WATER. Under it, wards lose most of their bite and moss drowns — but sinks render far better and springs only work at all. Sumps and the CHANNEL vein push it back down, and they cost the same spoil as everything else.', rx, ry, colW, { size: 14, colour: BLUE });
    ry += 14;
    ART.paragraph(ctx, 'If a delver reaches the bottom row alive they take a heartstone shard: you lose a fifth of your marrow and the deep floods for a minute. Nothing is destroyed and no progress is lost.', rx, ry, colW, { size: 14, colour: DIM });

    const b = ART.button(ctx, 'BACK', CW / 2 - 70, CH - 68, 140, 34, { hot: inRect(CW / 2 - 70, CH - 68, 140, 34) });
    hit('back', b.x, b.y, b.w, b.h, () => { mode = s.elapsed > 0.1 || awayReport ? 'play' : 'welcome'; });
    ART.text(ctx, 'M mutes · Escape goes back · it saves itself every ' + D.TUNE.autosaveSecs + ' seconds', CW / 2, CH - 24, { size: 12, align: 'center', colour: DIM });
  }

  function drawVeins() {
    drawBackdrop();
    ART.panel(ctx, 0, 0, CW, CH, 0.22);
    ART.text(ctx, 'VEINS', 84, 68, { size: 26, weight: 700, colour: '#c9a3d8' });
    ART.text(ctx, 'permanent, bought with marrow · you hold ' + fmt(s.marrow), 84, 92, { size: 14, colour: DIM });
    ART.text(ctx, 'Marrow comes out of bodies rendered by a sink, and the deeper the chamber the more of it there is.',
      84, 112, { size: 13, colour: PALE });
    /* ⚠️ Blocks were 40px apart measured from the BUTTON TOP, which left a 12px gap and made every
     * button look like it belonged to the vein NAMED BELOW IT. The layout gate cannot see that —
     * nothing overlaps — but a reader can, and a mis-attributed purchase button on a permanent
     * upgrade is a genuinely expensive misread. */
    const colW = 380;
    let y = 148, x = 84, col = 0;
    for (const v of D.VEINS) {
      const lv = s.veins[v.id] || 0;
      const maxed = lv >= v.max;
      const cost = D.veinCost(v, lv);
      const blocked = v.endgame && s.deepest < D.ROWS - 1;
      const afford = s.marrow >= cost && !maxed && !blocked;
      ART.text(ctx, v.name + '  ' + (maxed ? '(run out)' : lv + '/' + v.max), x, y, { size: 16, weight: 700, colour: v.endgame ? GOLD : PALE });
      const hgt = ART.paragraph(ctx, v.blurb, x, y + 20, colW, { size: 13, colour: DIM });
      const by = y + 20 + hgt + 2;
      const label = maxed ? 'RUN OUT' : (blocked ? 'THE GRANITE IS NOT OPEN TO THE FLOOR' : 'TAKE IT — ' + fmt(cost) + ' marrow');
      const b = ART.button(ctx, label, x, by, colW, 28, { hot: inRect(x, by, colW, 28) && afford, disabled: !afford, size: 13 });
      if (afford) hit('vein-' + v.id, b.x, b.y, b.w, b.h, () => {
        const r = H.buyVein(s, v.id);
        if (r.ok) { SOUND.marrow(); log('Opened a vein: ' + v.name + '.'); } else { SOUND.deny(); say(r.why); }
      });
      y = by + 54;
      if (y > CH - 150 && col === 0) { col = 1; x = 500; y = 148; }
    }
    const b = ART.button(ctx, 'BACK', CW / 2 - 70, CH - 56, 140, 34, { hot: inRect(CW / 2 - 70, CH - 56, 140, 34) });
    hit('back', b.x, b.y, b.w, b.h, () => { mode = 'play'; });
  }

  function drawEnding() {
    drawBackdrop();
    ART.panel(ctx, 0, 0, CW, CH, 0.14);
    let y = 150;
    ART.text(ctx, 'THE HILL CLOSES', CW / 2, y, { size: 48, weight: 700, align: 'center', colour: GOLD });
    y += 46;
    const x = 190, w = CW - 380;
    y += ART.paragraph(ctx, 'The seal is set. Whatever the heartstone was, nobody is going to reach it now, and in a season or two the mouth will be a dip in the turf that sheep walk over.', x, y, w, { size: 16, align: 'left' });
    y += 22;
    y += ART.paragraph(ctx, s.killed + ' delvers died in you. ' + s.escaped + ' walked back out, carrying ' + fmt(s.spoilStolen) + ' spoil and the story between them. ' + s.shardsLost + ' got all the way down.', x, y, w, { size: 15, colour: PALE });
    y += 26;
    ART.text(ctx, 'The hollow keeps working. Nothing resets, and there is still rock down there.', CW / 2, y, { size: 14, align: 'center', colour: DIM });
    y += 40;
    const b = ART.button(ctx, 'GO BACK DOWN', CW / 2 - 110, y, 220, 40, { hot: inRect(CW / 2 - 110, y, 220, 40), size: 15 });
    hit('back', b.x, b.y, b.w, b.h, () => { mode = 'play'; });
  }

  function draw() {
    hits = [];
    const t = s.elapsed;
    ctx.fillStyle = '#07080a';
    ctx.fillRect(0, 0, CW, CH);

    if (mode === 'welcome') { drawWelcome(); return; }
    if (mode === 'help') { drawHelp(); return; }
    if (mode === 'veins') { drawVeins(); return; }
    if (mode === 'ending') { drawEnding(); return; }

    drawTopBar();
    drawBoard(t);
    drawPanel();
    drawStatus();

    if (flashT > 0) {
      ctx.save();
      ctx.fillStyle = `rgba(121,188,210,${flashT * 0.20})`;
      ctx.fillRect(0, 0, CW, CH);
      ctx.restore();
    }
  }

  /* ── loop ─────────────────────────────────────────────────────────────────────────────────── */

  function frame(now) {
    requestAnimationFrame(frame);
    if (renderPaused) return;
    const dt = Math.min(0.25, (now - last) / 1000 || 0);
    last = now;
    if (mode === 'play' || mode === 'veins') step(dt);
    if (toastT > 0) toastT -= dt;
    if (flashT > 0) flashT -= dt;
    draw();
  }

  /* ── boot ─────────────────────────────────────────────────────────────────────────────────── */

  const loadRes = SAVE.load(s);
  if (loadRes.ok) {
    H.recompute(s);
    /* Away catch-up, computed from the LIVE root income and nothing else — an away bonus derived
     * from a second formula is a second economy nobody balanced. */
    const away = Math.min(D.TUNE.offlineCapHours * 3600, Math.max(0, (Date.now() - loadRes.savedAt) / 1000));
    if (away > 60) {
      const gain = H.rootIncome(s) * away * D.TUNE.offlineRate;
      s.spoil += gain;
      awayReport = 'You were away ' + (away < 3600 ? Math.round(away / 60) + ' minutes' : (away / 3600).toFixed(1) + ' hours') +
        '. The roots made ' + fmt(gain) + ' spoil while the hollow sat empty.';
      log('Away ' + Math.round(away / 60) + ' minutes: +' + fmt(gain) + ' spoil from roots.');
    } else {
      awayReport = 'Your hollow is where you left it.';
    }
  }

  ART.load(() => { /* nothing to do; artLoaded() is the signal the harnesses wait on */ });
  requestAnimationFrame((t) => { last = t; frame(t); });

  /* The harness surface. `draw` and `setRenderPaused` exist so a capture can advance the clock by
   * hand without the rAF loop advancing it too (§3c-7). `setSeed` makes a session replayable. */
  root.SWALLET = {
    state: () => s,
    draw,
    setRenderPaused: (v) => { renderPaused = !!v; },
    setMode: (m) => { mode = m; },
    getMode: () => mode,
    /* ⛔ GUARDED, because the layout gate found the crash: `select(-1,-1)` used to store an
     * off-board coordinate, `drawPanel` then read `cellAt(...)` as null and dereferenced `.dug`,
     * and the whole frame threw. The live game never produced it — `cellFromPoint` returns null
     * outside the board — but a public entry point that a harness can call has to be as safe as
     * the private path, and the panel below now treats a missing cell as no selection anyway. */
    select: (x, y) => { sel = (x == null || y == null || x < 0 || y < 0 || x >= D.COLS || y >= D.ROWS) ? null : { x, y }; },
    hitIds: () => hits.map((h) => h.id),
    click: (x, y) => onClick(x, y),
    step,
    setSeed: (n) => { rngState = n >>> 0; },
    artLoaded: () => ART.artLoaded(),
    version: '1.0.0',
  };
})(typeof self !== 'undefined' ? self : this);
