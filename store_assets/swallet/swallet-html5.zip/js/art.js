/**
 * art.js — asset loading, text layout, and the hollow's drawing vocabulary.
 *
 * ⛔ EVERY STRING THIS GAME DRAWS GOES THROUGH `API.text`, AND EVERY BUTTON THROUGH `API.button`.
 * That is a gate requirement, not a style preference (wing §3e-1/§3e-3, both measured):
 *
 *   "Canvas text does not wrap, does not reflow and does not clip. FLOODMARK passed 133 assertions
 *    across four suites while HOW IT WORKS drew four body lines to 1035px on a 960px canvas."
 *   "PERIGEE's controls line wrapped and orphaned the word 'mutes' onto a row sitting on the BACK
 *    button's top border ... nothing in the gate modelled controls at all."
 *
 * The layout gate replaces both functions with recorders, so anything that draws text or a control
 * by another route is INVISIBLE to it — which is exactly the line most likely to overflow.
 * `paragraph` and `wrap` therefore call `API.text`, never a closure-local helper.
 *
 * ⛔ AND LAYOUT IS DERIVED FROM `measureText` AT DRAW TIME, NEVER HARD-CODED. This game ships a
 * system font stack, so the same string is a different width on Windows, on a Mac and in headless
 * capture. "Measure once, hard-code the x" is wrong by construction, not by sloppiness.
 */
(function (root) {
  'use strict';

  const FONT = "'Iowan Old Style', 'Palatino Linotype', Palatino, Georgia, serif";
  const SANS = "'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif";

  const PLATES = ['loam', 'chalk', 'shale', 'granite', 'gloam'];
  const SHEETS = ['delvers', 'fixtures'];
  const images = {};
  const patterns = {};
  let loaded = 0;
  const TOTAL = PLATES.length + SHEETS.length;

  /** ⭐ The only honest proof an asset DECODED, exported because the capture harness must wait on
   *  it (wing §3d rule 3). A capture that starts before the art lands photographs an empty game. */
  function artLoaded() { return loaded === TOTAL; }
  function loadedCount() { return loaded; }

  function load(onDone) {
    const bump = () => { loaded++; if (loaded === TOTAL && onDone) onDone(); };
    const fail = (src) => {
      /* ⚠️ A missing asset must be LOUD. This wing has shipped a build whose art 404'd while every
       * check stayed green (§3b-2a), so a failure is never counted as a load: `artLoaded()` stays
       * false forever, the game renders flat colour, and the console says which file. */
      console.error('[SWALLET] asset failed to load: ' + src);
    };
    for (const name of PLATES) {
      const img = new Image();
      img.onload = () => { images[name] = img; bump(); };
      img.onerror = () => fail('art/plate_' + name + '.png');
      img.src = 'art/plate_' + name + '.png';
    }
    for (const name of SHEETS) {
      const img = new Image();
      img.onload = () => { images[name] = img; bump(); };
      img.onerror = () => fail('art/sheet_' + name + '.png');
      img.src = 'art/sheet_' + name + '.png';
    }
  }

  function pattern(ctx, name) {
    if (patterns[name]) return patterns[name];
    if (!images[name]) return null;
    patterns[name] = ctx.createPattern(images[name], 'repeat');   // 1:1, never resampled (§3g)
    return patterns[name];
  }

  const API = {};

  /* ── text ─────────────────────────────────────────────────────────────────────────────────── */

  /** THE single text entry point. The layout gate swaps this out to record every string drawn. */
  API.text = function (ctx, str, x, y, opts) {
    const o = opts || {};
    ctx.save();
    ctx.font = `${o.weight || 400} ${o.size || 14}px ${o.sans ? SANS : FONT}`;
    ctx.textAlign = o.align || 'left';
    ctx.textBaseline = o.baseline || 'alphabetic';
    if (o.shadow !== false) {
      ctx.fillStyle = 'rgba(0,0,0,0.8)';
      ctx.fillText(str, x + 1, y + 1);
    }
    ctx.fillStyle = o.colour || '#ddd6c2';
    if (o.alpha !== undefined) ctx.globalAlpha = o.alpha;
    ctx.fillText(str, x, y);
    ctx.restore();
    return ctx.measureText(str).width;
  };

  /** Measure a string under the same font rules `text` will use. */
  API.width = function (ctx, str, opts) {
    const o = opts || {};
    ctx.save();
    ctx.font = `${o.weight || 400} ${o.size || 14}px ${o.sans ? SANS : FONT}`;
    const w = ctx.measureText(str).width;
    ctx.restore();
    return w;
  };

  /** Break `str` into lines that each fit `maxW`. Derived at draw time, on the player's machine. */
  API.wrap = function (ctx, str, maxW, opts) {
    const words = String(str).split(/\s+/).filter(Boolean);
    const lines = [];
    let line = '';
    for (const word of words) {
      const candidate = line ? line + ' ' + word : word;
      if (API.width(ctx, candidate, opts) <= maxW || !line) line = candidate;
      else { lines.push(line); line = word; }
    }
    if (line) lines.push(line);
    return lines;
  };

  /** Draw wrapped text. ⛔ Routes through API.text so the layout recorder can see every line. */
  API.paragraph = function (ctx, str, x, y, maxW, opts) {
    const o = opts || {};
    const lh = o.lineHeight || (o.size || 14) * 1.45;
    const lines = API.wrap(ctx, str, maxW, o);
    for (let i = 0; i < lines.length; i++) API.text(ctx, lines[i], x, y + i * lh, o);
    return lines.length * lh;
  };

  /* ── chrome ───────────────────────────────────────────────────────────────────────────────── */

  /** A panel: gloam plate, darkened, with a hairline edge. Chrome that stays quiet (§3e). */
  API.panel = function (ctx, x, y, w, h, alpha) {
    const p = pattern(ctx, 'gloam');
    ctx.save();
    ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
    if (p) { ctx.fillStyle = p; ctx.fillRect(x, y, w, h); }
    else { ctx.fillStyle = '#15181d'; ctx.fillRect(x, y, w, h); }
    ctx.fillStyle = `rgba(4,5,7,${alpha === undefined ? 0.38 : alpha})`;
    ctx.fillRect(x, y, w, h);
    ctx.restore();
    ctx.strokeStyle = 'rgba(150,150,170,0.16)';
    ctx.lineWidth = 1;
    ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
  };

  /**
   * A control. Registered with the layout gate so a stray string sitting inside a button is a
   * finding rather than a thing nobody modelled (§3e-3, measured on PERIGEE).
   * Returns its own rect so callers never re-derive the geometry they just drew.
   */
  API.button = function (ctx, label, x, y, w, h, opts) {
    const o = opts || {};
    ctx.save();
    ctx.fillStyle = o.disabled ? 'rgba(20,22,26,0.72)' : (o.hot ? 'rgba(78,66,40,0.92)' : 'rgba(30,34,40,0.92)');
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = o.disabled ? 'rgba(120,120,130,0.20)' : (o.hot ? 'rgba(214,178,92,0.85)' : 'rgba(160,164,178,0.34)');
    ctx.lineWidth = 1;
    ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
    ctx.restore();
    API.text(ctx, label, x + w / 2, y + h / 2 + (o.size || 14) * 0.35, {
      size: o.size || 14, align: 'center',
      colour: o.disabled ? '#6d7079' : (o.colour || '#e6dfc9'), weight: o.weight || 600,
    });
    return { x, y, w, h };
  };

  /* ── the board ────────────────────────────────────────────────────────────────────────────── */

  /** Solid rock, drawn from its stratum's plate at 1:1 with no scaling (§3g). */
  API.rock = function (ctx, plateName, x, y, w, h) {
    const p = pattern(ctx, plateName);
    ctx.save();
    ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
    if (p) { ctx.fillStyle = p; ctx.fillRect(x, y, w, h); }
    else { ctx.fillStyle = '#2a2620'; ctx.fillRect(x, y, w, h); }
    ctx.restore();
  };

  /**
   * A CUT CHAMBER — the void. This is the picture the whole game turns on: the hollow is the
   * NEGATIVE space, so an open cell shows its own stratum darkened almost to nothing plus a floor
   * and a ceiling line. Drawing it as flat black would throw away every plate below the surface.
   */
  API.chamber = function (ctx, plateName, x, y, w, h, wet, t) {
    const p = pattern(ctx, plateName);
    ctx.save();
    ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
    if (p) { ctx.fillStyle = p; ctx.fillRect(x, y, w, h); }
    ctx.fillStyle = 'rgba(3,4,6,0.80)';
    ctx.fillRect(x, y, w, h);
    // the floor catches what little light there is; the ceiling stays black
    const g = ctx.createLinearGradient(0, y, 0, y + h);
    g.addColorStop(0, 'rgba(0,0,0,0.55)');
    g.addColorStop(0.72, 'rgba(0,0,0,0)');
    ctx.fillStyle = g; ctx.fillRect(x, y, w, h);
    ctx.fillStyle = 'rgba(120,110,92,0.13)';
    ctx.fillRect(x, y + h - 3, w, 3);
    if (wet > 0) {
      /* ⚠️ THE FIRST VERSION FILLED 80% OF THE CELL AT 64% ALPHA and the flooded rows read as
       * SOLID TEAL BOXES in the store captures — a colour block, not water, and it buried the
       * shale and granite plates underneath exactly the way UNDERSTORY's first hyphae buried its
       * substrates. Water is a SURFACE: a bright meniscus, a much weaker body under it, and the
       * rock still visible through the whole thing. */
      const level = y + h - h * (0.14 + wet * 0.48);
      const g2 = ctx.createLinearGradient(0, level, 0, y + h);
      g2.addColorStop(0, `rgba(72,140,166,${0.30 + wet * 0.16})`);
      g2.addColorStop(1, `rgba(24,62,86,${0.34 + wet * 0.20})`);
      ctx.fillStyle = g2;
      ctx.fillRect(x, level, w, y + h - level);
      ctx.strokeStyle = `rgba(170,224,240,${0.42 + wet * 0.34})`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let i = 0; i <= w; i += 2) {
        const yy = level + Math.sin((i / 11) + (t || 0) * 1.7 + x) * 1.1;
        if (i === 0) ctx.moveTo(x + i, yy); else ctx.lineTo(x + i, yy);
      }
      ctx.stroke();
    }
    ctx.restore();
  };

  /** One fixture emblem, blitted x2 from the sheet with smoothing off. */
  API.fixture = function (ctx, col, level, x, y, size) {
    const img = images.fixtures;
    if (!img) return;
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(img, col * 22, level * 22, 22, 22, Math.round(x), Math.round(y), size, size);
    ctx.restore();
  };

  /** One delver, blitted x2 from the sheet with smoothing off. `pose` 0/1 walk, 2 hurt, 3 fallen. */
  API.delver = function (ctx, row, pose, x, y, scale) {
    const img = images.delvers;
    if (!img) return;
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(img, pose * 14, row * 20, 14, 20, Math.round(x), Math.round(y), 14 * scale, 20 * scale);
    ctx.restore();
  };

  /** Loose spoil heaped on a chamber floor — the thing a passing delver steals. */
  API.rubble = function (ctx, x, y, w, h, amount) {
    if (amount <= 0.5) return;
    const n = Math.min(9, 1 + Math.floor(Math.log2(1 + amount)));
    ctx.save();
    for (let i = 0; i < n; i++) {
      const px = x + 5 + ((i * 37) % Math.max(1, w - 12));
      const r = 1.4 + ((i * 13) % 3) * 0.6;
      ctx.fillStyle = i % 3 === 0 ? '#a89268' : '#6d6152';
      ctx.beginPath();
      ctx.ellipse(px, y + h - 5 - ((i * 7) % 4), r, r * 0.72, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  };

  /** Remains awaiting a sink. Deliberately a cold, wrong colour — you are meant to want it gone. */
  API.remains = function (ctx, x, y, w, h, amount) {
    if (amount <= 0.5) return;
    ctx.save();
    ctx.globalAlpha = Math.min(0.85, 0.25 + Math.log2(1 + amount) / 12);
    ctx.fillStyle = '#7d2f31';
    ctx.beginPath();
    ctx.ellipse(x + w / 2, y + h - 6, w * 0.32, 3.2, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  };

  API.FONT = FONT;
  API.SANS = SANS;
  API.load = load;
  API.artLoaded = artLoaded;
  API.loadedCount = loadedCount;
  API.pattern = pattern;
  API.PLATES = PLATES;
  API.TOTAL_ASSETS = TOTAL;

  if (typeof module === 'object' && module.exports) module.exports = API;
  else root.ART = API;
})(typeof self !== 'undefined' ? self : this);
