/**
 * save.js — localStorage persistence and the away catch-up.
 *
 * ⛔ THE STANDING WING RULE (ledger B4/B5): save and resume, NEVER a full restart. SWALLET has no
 * run and no death of the player's own — the runs belong to the delvers — so this file's whole job
 * is that closing the tab costs you nothing and reopening it tells you honestly what happened.
 *
 * ⚠️ SERIALISATION IS EXPLICIT, FIELD BY FIELD, ON PURPOSE. A blind JSON round-trip would persist
 * DERIVED state (`wet`, `waterRow`) and resurrect stale fields whenever the schema changed. The
 * wetness field is recomputed on load, never restored, so there is exactly one place it is decided.
 *
 * ⛔ AND THE DELVERS ARE NOT SAVED. That is a design decision, not an omission: a delver is a run
 * in progress, and restoring one mid-corridor would mean saving a pathfinding state that the board
 * may no longer support. The hollow persists; the people in it went home while you were away.
 */
(function (root) {
  'use strict';

  const isNode = (typeof module === 'object' && module.exports);
  const D = isNode ? require('./data.js') : root.DATA;

  const KEY = 'swallet.save.v1';

  function serialise(s) {
    return {
      v: 1,
      spoil: s.spoil,
      marrow: s.marrow,
      renown: s.renown,
      veins: s.veins,
      elapsed: s.elapsed,
      escaped: s.escaped,
      killed: s.killed,
      spoilStolen: s.spoilStolen,
      shardsLost: s.shardsLost,
      sealed: s.sealed,
      seenEnding: s.seenEnding,
      unlockedSeen: s.unlockedSeen,
      savedAt: Date.now(),
      // one compact row per cell; only what is not derivable from position
      cells: s.cells.map((c) => [
        c.dug ? 1 : 0,
        c.fixture ? c.fixture.id : '',
        c.fixture ? c.fixture.level : 0,
        Math.round(c.remains * 100) / 100,
        Math.round(c.rubble * 100) / 100,
      ]),
    };
  }

  function apply(s, data) {
    if (!data || data.v !== 1 || !Array.isArray(data.cells) || data.cells.length !== s.cells.length) {
      return { ok: false, why: 'save is missing, from another version, or the wrong board size' };
    }
    s.spoil = data.spoil || 0;
    s.marrow = data.marrow || 0;
    s.renown = data.renown || 0;
    s.elapsed = data.elapsed || 0;
    s.escaped = data.escaped || 0;
    s.killed = data.killed || 0;
    s.spoilStolen = data.spoilStolen || 0;
    s.shardsLost = data.shardsLost || 0;
    s.sealed = !!data.sealed;
    s.seenEnding = !!data.seenEnding;
    s.unlockedSeen = data.unlockedSeen || {};
    /* Merge rather than replace, so a save written before a vein existed still loads and simply
     * reads level 0 for it — an old save must never be rejected for being old. */
    for (const k of Object.keys(s.veins)) if (data.veins && data.veins[k] !== undefined) s.veins[k] = data.veins[k];

    for (let i = 0; i < s.cells.length; i++) {
      const c = s.cells[i], d = data.cells[i];
      c.dug = !!d[0];
      c.fixture = d[1] && D.FIXTURE_BY_ID[d[1]] ? { id: d[1], level: d[2] || 0 } : null;
      c.remains = d[3] || 0;
      c.rubble = d[4] || 0;
    }
    return { ok: true, savedAt: data.savedAt || Date.now() };
  }

  function save(s) {
    try {
      localStorage.setItem(KEY, JSON.stringify(serialise(s)));
      return true;
    } catch (e) {
      /* Private browsing and full quotas both throw here. Losing a save is bad; crashing the game
       * over it is worse, and a silent catch would be worse still — so it is reported once. */
      console.warn('[SWALLET] could not save:', e && e.message);
      return false;
    }
  }

  function load(s) {
    let raw = null;
    try { raw = localStorage.getItem(KEY); } catch (e) { return { ok: false, why: 'storage unavailable' }; }
    if (!raw) return { ok: false, why: 'no save yet' };
    let data;
    try { data = JSON.parse(raw); } catch (e) { return { ok: false, why: 'save is corrupt' }; }
    return apply(s, data);
  }

  function clear() {
    try { localStorage.removeItem(KEY); return true; } catch (e) { return false; }
  }

  const API = { KEY, save, load, clear, serialise, apply };

  if (isNode) module.exports = API;
  else root.SAVE = API;
})(typeof self !== 'undefined' ? self : this);
