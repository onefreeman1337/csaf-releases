# BRANCHWORK - A Story Flowchart Your Game Draws, for GameMaker

**Your branching story already has a shape. This draws it.** Branchwork records what the player reached, which
ways they took, and which endings they earned, then draws that as a chart: a struck plate for every scene,
notched corners where a choice was made, inked connectors that are gold where the player walked and dashed where
a road is known but untaken, and fog over everything they have never seen.

And every ending earns a **mark** - a medallion composed from the route that reached it:

- **the field and rim** take one of eight palettes, hashed from the route
- **the device** is a star whose point count comes from the ending's motif and whose depth and twist come from its
  family, named by the ending's own `tone` (dawn, ember, tide, thorn, crown, ash)
- **the ring** encodes the journey - plain, double, beaded, ticked, dashed or roped, by how long the road was and
  how much of it was choice
- **one orbiting mark per decision** on the way, struck into the field

So two players who reach the same ending by different roads earn **different marks**, and the chart is a record
of their story rather than a checklist. One twenty-two node sample story yields **48 distinct marks**, and the
package draws all 48 on request (`bwk_demo_marks`).

Pure GML. No extension, no shader, no sprite, no surface kept. Built and tested on GameMaker runtime
**2024.14.4.268**.

---

## Quickstart

1. **Tools > Import Local Package**, pick `Branchwork.yymps`, import everything.
2. Describe your story once, as plain structs (Create event):

```gml
my_story = bwk_create([
    { id: "wake",  label: "The Last Train",   act: 0, kind: "event" },
    { id: "stay",  label: "Stay Aboard",      act: 1, kind: "decision", from: ["wake"] },
    { id: "leave", label: "Step Off",         act: 1, kind: "decision", from: ["wake"] },
    { id: "home",  label: "Home Before Dawn", act: 2, kind: "ending",   from: ["stay"], tone: "dawn" },
    { id: "tide",  label: "Where the Rails Go Under", act: 2, kind: "ending", from: ["leave"], tone: "tide" }
]);
```

`act` is the chapter, and it decides the chart column; rows follow declaration order. `kind` is `"event"`,
`"decision"` or `"ending"`. `from` is who leads here, as an array or a comma-separated string. Add
`secret: true` and an unreached node shows `"???"` instead of its label. **Nothing throws**: a duplicate id or a
link from a node that does not exist is kept out of the graph and reported in `bwk_problems(my_story)`, so a
half-written story still runs.

3. Tell it where the player goes, wherever your game already knows:

```gml
bwk_reach(my_story, "wake");                 // the opening scene - reach it like any other
bwk_reach(my_story, "stay");                 // the player stayed aboard
var _earned = bwk_reach_ending(my_story, "home");   // an ending: collected, and its mark struck
```

**Reach the opening node too.** Branchwork does not assume where your story begins, and an edge is recorded
only between two nodes the player actually walked between - so if you skip the first `bwk_reach`, the chart is
right to show your opening scene as one nobody has visited.

4. Draw the chart (Draw GUI event):

```gml
bwk_chart_draw(my_story, 0, 0, display_get_gui_width(), display_get_gui_height(), "brass");
```

That is the whole integration. Three styles ship - `"brass"`, `"ink"` and `"night"` - and `bwk_chart_styles()`
lists them.

**Give the chart room.** It solves every plate, seal and label from the rect you hand it, so it cannot overflow
at any size, but a five-chapter story wants about **1000 px of width or more** to keep the longest ending label
comfortably readable. Measured on the sample story: at 1600x900 the tightest label draws at 0.74 of its natural
size, at 1280x584 at 0.55, and at 640x360 at 0.20 - legible only for short labels. Below that, draw the chart
on a scrolling surface rather than squeezing it.

## Jumping back

A flowchart that shows an untaken road invites the player to go and take it. Branchwork holds the **jump point**
and lets your own save system do the restoring, so it works with any save format you already have:

```gml
bwk_jump_store(my_story, "stay", my_own_save_string);   // ANY value: a string, a struct, a buffer id
...
if (bwk_can_jump(my_story, "stay")) {
    var _snapshot = bwk_jump(my_story, "stay");         // the path is cut back; everything reached is KEPT
    my_restore(_snapshot);                               // your game restores it
}
```

At most `max_jumps` are held (8 by default, set it in the options struct); storing past that recycles the
oldest, because a player who has filled them wants their newest decisions, not an error.

## New Game plus

`bwk_reset_path(my_story)` clears the current run and keeps everything ever reached and every mark ever earned.
That is what makes the chart fill in across playthroughs instead of resetting with them.

## Every route in the story

```gml
var _all = bwk_routes(my_story);                 // every distinct route, first node to ending
var _walked = bwk_route_taken(my_story, _all[0]);
```

A completion screen is made of these: how many roads exist, which ones this player has walked, and what each one
would earn (`bwk_emblem(my_story, _all[0], _all[0][array_length(_all[0]) - 1])`). A node is never entered twice
on one route, so a story that loops back still terminates.

## Saving

```gml
var _json = bwk_save(my_story);                  // the RECORD only - your graph is your own data
bwk_load(my_story, _json);                       // into a state built from the same graph
```

Anything unreadable is refused and leaves the state untouched, and ids that no longer exist in the graph are
dropped, so an old save loads into an edited story instead of crashing on it.

## The demo room

`rm_bwk_demo` is a playable demo of the whole thing: **1**, **2**, **3** take a choice, **J** jumps back to the
last decision with a snapshot, **R** starts a new run, **S** changes the chart style. The bar along the bottom -
the endings tally, the choice plates, the key caps - is drawn from this package's own plate and emblem code, so
it doubles as a worked example of building UI out of it.

## Every function

**The record**

| Function | What it does |
| --- | --- |
| `bwk_create(nodes, [options])` | Build a story state from an array of node structs |
| `bwk_is_state(value)` | True for a state made by `bwk_create` |
| `bwk_problems(state)` | Authoring problems found while building (never thrown) |
| `bwk_node(state, id)` | One node record, or `undefined` |
| `bwk_reach(state, id)` | Mark a node reached and record the edge walked into it |
| `bwk_reach_ending(state, id)` | Reach an ending and collect it; returns its record |
| `bwk_reset_path(state)` | Clear this run, keep everything reached and collected |
| `bwk_has_reached(state, id)` | Has the player ever been here |
| `bwk_has_ending(state, id)` | Has this ending been collected |
| `bwk_ending(state, id)` | The collected ending record, or `undefined` |
| `bwk_ending_count(state)` | How many endings are collected |
| `bwk_ending_total(state)` | How many the story declares |
| `bwk_current_node(state)` | Where the player stands |
| `bwk_current_path(state)` | A copy of this run's path, oldest first |
| `bwk_has_edge(state, from, to)` | Has this road been walked |
| `bwk_node_state(state, id)` | `unseen`, `current`, `ending`, `converge` or `reached` |
| `bwk_label(state, id)` | The label to show, honouring `secret` |
| `bwk_routes(state, [limit], [max_steps])` | Every distinct route through the story |
| `bwk_route_taken(state, route)` | Has this run walked that route end to end |
| `bwk_save(state)` | The run record as JSON |
| `bwk_load(state, json)` | Install a record; refuses anything unreadable |

**Jump points**

| Function | What it does |
| --- | --- |
| `bwk_jump_store(state, id, snapshot)` | Keep YOUR snapshot as the way back to a reached node |
| `bwk_can_jump(state, id)` | Should the chart offer a jump back here |
| `bwk_jump(state, id)` | Cut the path back and return the snapshot you stored |

**Marks**

| Function | What it does |
| --- | --- |
| `bwk_emblem(state, path, ending_id)` | The mark a route earns, as indices the chart draws |
| `bwk_emblem_families()` | The six families, in index order |
| `bwk_emblem_colours(palette)` | `[field, rim, device]` for one of the eight palettes |
| `bwk_signature(path, ending_id)` | The route's signature string |

**Drawing**

| Function | What it does |
| --- | --- |
| `bwk_chart_draw(state, x, y, width, height, [style])` | Draw the whole chart into a rect |
| `bwk_draw_emblem(x, y, radius, emblem, [alpha])` | Draw one mark anywhere, at any size |
| `bwk_chart_styles()` | The style ids |
| `bwk_chart_style(id)` | A style's colour struct |
| `bwk_chart_geometry(layout, x, y, width, height)` | Where the chart puts things in a rect |
| `bwk_chart_node_xy(geometry, layout_node)` | The centre of one node's plate |
| `bwk_chart_plate_box(geometry, kind)` | A plate's notch, rivet, seal and label box |
| `bwk_chart_numeral(n)` | A chapter number as a Roman numeral |
| `bwk_layout(state)` | The chart as data: columns, rows, nodes, edge states |

**The samples**

| Function | What it does |
| --- | --- |
| `bwk_demo_graph()` | "The Last Train", the small sample story |
| `bwk_demo_long_graph()` | "The Hollow Road", the larger one |
| `bwk_demo_marks(limit)` | The distinct marks that story can earn |
| `bwk_demo_state()` | A fresh playable demo |
| `bwk_demo_choices(demo)` | What can be chosen from where the player stands |
| `bwk_demo_choose(demo, index)` | Take one of them |
| `bwk_demo_draw(demo, width, height)` | Draw the demo screen, chart and bar |

**Helpers** - `bwk_num(value, fallback)`, `bwk_hash(text, [salt])`, `bwk_pick(key, stream, n)`.

## Notes

- **Everything is namespaced `bwk_`**, including the macros (`BWK_VERSION`, `BWK_SCHEMA`, `BWK_EMBLEM_FAMILIES`,
  `BWK_EMBLEM_MOTIFS`, `BWK_EMBLEM_RINGS`, `BWK_EMBLEM_ORBITS`, `BWK_EMBLEM_PALETTES`). GML's global namespace
  is flat, so nothing here can collide with your own code.
- **Every public function refuses bad input rather than crashing.** Hand one `undefined`, a negative number or a
  string where a struct belongs and it returns `undefined`, `false`, `""` or an empty array - never an error
  inside your draw event.
- **The record is deterministic.** The same route always earns the same mark, on every machine, before and after
  a save and load.
- No absolute paths, no hardcoded room or layer indices, no `global` variables. The chart draws only inside the
  rect you give it.
- The source ships raw and readable, with a header block on every public script.

## Licence

One commercial licence, unlimited games. See `LICENSE.txt`.

Made by Core Systems Asset Factory.
