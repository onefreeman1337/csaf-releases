/// bwk_chart.gml - the route chart DRAWN: chapter columns on a board, a struck plate for every node (notched
/// corners for a decision, a medallion for an ending), inked connectors (solid where travelled, dashed where a way
/// is known but not taken, absent where nothing is known), fog over the unreached, and each collected ending's
/// emblem composed from the route that earned it.
///
/// Branchwork - A Story Flowchart the Game Draws, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Pure GML drawing: no sprite, no shader, no surface kept.

/// @function bwk_chart_styles()
/// @description The chart styles, in catalogue order. Pure.
function bwk_chart_styles() { return ["brass", "ink", "night"]; }

/// @function bwk_chart_style(id)
/// @description { board, board_edge, plate, plate_hi, plate_lo, engrave, line, gold, fog, glow } for a style id
/// ("brass" for anything unknown). Pure.
function bwk_chart_style(_id) {
    switch (_id) {
        case "ink":   return { board: make_colour_rgb(232, 222, 198), board_edge: make_colour_rgb(196, 180, 146), plate: make_colour_rgb(246, 240, 224), plate_hi: c_white, plate_lo: make_colour_rgb(170, 156, 128), engrave: make_colour_rgb(40, 30, 24), line: make_colour_rgb(60, 46, 36), gold: make_colour_rgb(150, 40, 36), fog: make_colour_rgb(214, 204, 180), glow: make_colour_rgb(190, 60, 40) };
        case "night": return { board: make_colour_rgb(16, 22, 36), board_edge: make_colour_rgb(6, 8, 16), plate: make_colour_rgb(40, 54, 78), plate_hi: make_colour_rgb(96, 120, 160), plate_lo: make_colour_rgb(14, 18, 30), engrave: make_colour_rgb(220, 226, 240), line: make_colour_rgb(110, 130, 170), gold: make_colour_rgb(120, 200, 230), fog: make_colour_rgb(70, 88, 120), glow: make_colour_rgb(140, 220, 255) };
    }
    // (the fog was the board's own colour on the first bake and could not be seen on a dark board - it is a
    // pale mist now, lighter than the ground it lies on)
    return { board: make_colour_rgb(34, 26, 20), board_edge: make_colour_rgb(14, 10, 8), plate: make_colour_rgb(176, 136, 72), plate_hi: make_colour_rgb(236, 206, 140), plate_lo: make_colour_rgb(92, 64, 30), engrave: make_colour_rgb(44, 28, 14), line: make_colour_rgb(120, 96, 64), gold: make_colour_rgb(236, 190, 90), fog: make_colour_rgb(96, 84, 70), glow: make_colour_rgb(255, 210, 120) };
}

/// @function bwk_chart_numeral(n)
/// @description A chapter number as a Roman numeral (1..39), for the column heads. Pure.
function bwk_chart_numeral(_n) {
    _n = clamp(floor(bwk_num(_n, 1)), 1, 39);
    var _s = "";
    while (_n >= 10) { _s += "X"; _n -= 10; }
    var _u = ["", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"];
    return _s + _u[_n];
}

/// @function bwk_chart_geometry(layout, x, y, width, height)
/// @description Where everything goes for a layout from bwk_layout in a rect: { x, y, w, h, head, colw, rowh,
/// pw, ph } - plate size derived from the cell, never typed. Pure.
function bwk_chart_geometry(_L, _x, _y, _w, _h) {
    // ⛔ undefined for anything that is not a layout. GML resolves a field access on a non-struct against the
    // CALLING INSTANCE, so without this a buyer's typo surfaces in their game as "Variable obj_theirs.cols not
    // set" - our bug reported against their object, in a file they cannot read.
    if (!is_struct(_L) || !is_real(_L[$ "cols"]) || !is_real(_L[$ "rows"])) return undefined;
    _x = bwk_num(_x, 0); _y = bwk_num(_y, 0); _w = bwk_num(_w, 640); _h = bwk_num(_h, 360);
    var _cols = max(1, _L.cols), _rows = max(1, _L.rows), _head = clamp(_h * 0.09, 28, 64), _m = clamp(_w * 0.02, 8, 32);
    var _colw = (_w - 2 * _m) / _cols, _rowh = (_h - _head - 2 * _m) / _rows;
    return { x: _x + _m, y: _y + _m + _head, w: _w - 2 * _m, h: _h - _head - 2 * _m, head: _head, colw: _colw, rowh: _rowh,
        pw: min(_colw * 0.80, 260), ph: clamp(_rowh * 0.46, 18, 64) };
}

/// @function bwk_chart_node_xy(geometry, layout_node)
/// @description The centre of a node's plate; a column with fewer nodes is centred vertically. Pure.
function bwk_chart_node_xy(_G, _n) {
    if (!is_struct(_G) || !is_real(_G[$ "rowh"]) || _G.rowh == 0 || !is_struct(_n)) return undefined;
    var _rows = max(1, round(_G.h / _G.rowh)), _off = (_rows - bwk_num(_n[$ "rows_in_col"], 1)) * _G.rowh * 0.5;
    return [_G.x + (bwk_num(_n[$ "col"], 0) + 0.5) * _G.colw, _G.y + _off + (bwk_num(_n[$ "row"], 0) + 0.5) * _G.rowh];
}

/// @function bwk_chart_plate_box(geometry, kind)
/// @description Where a plate's furniture goes, as offsets from the plate CENTRE: { notch, rivet_x, rivet_r,
/// seal_x, seal_r, text_x, text_w }. The label's box is SOLVED from the seal and the rivet rather than taken as a
/// fraction of the plate - the second bake centred every ending label on the plate and drew it THROUGH the right
/// rivet and into the chevron ("Home Before Dawn" read "Home Before Dawr"). The rivet is also pulled inside the
/// notch here, so it can never land on the chevron's slope. Pure: the suite asserts this, since no assertion can
/// see the picture.
function bwk_chart_plate_box(_G, _kind) {
    if (!is_struct(_G) || !is_real(_G[$ "pw"]) || !is_real(_G[$ "ph"])) return undefined;
    var _rv = max(2, _G.ph * 0.07), _hw = _G.pw / 2;
    // ⛔ The notch and the seal EAT HORIZONTAL SPACE and are sized from `ph`, a vertical quantity - correct on a
    // wide plate and ruinous on a narrow one, where a tall cell gave an ending a notch half its own width and
    // collapsed the label to nothing. Both are bounded by the PLATE'S WIDTH as well.
    var _notch = (_kind == "decision") ? min(_G.ph * 0.28, _G.pw * 0.10) : ((_kind == "ending") ? min(_G.ph * 0.5, _G.pw * 0.16) : 3);
    var _rx = _hw - ((_kind == "decision") ? _notch + _rv + 4 : ((_kind == "ending") ? _notch + _rv + 4 : 9));
    if (_kind != "ending") return { notch: _notch, rivet_x: _rx, rivet_r: _rv, seal_x: 0, seal_r: 0, text_x: 0, text_w: max(24, _G.pw - 16) };
    // the seal is struck ON the plate's left point, so it eats half its own width instead of all of it, and the
    // route's line runs into it
    var _sr = min(_G.ph * 0.62, _G.pw * 0.24), _sx = -_hw, _l = _sx + _sr + 6, _r = _rx - _rv - 6;
    return { notch: _notch, rivet_x: _rx, rivet_r: _rv, seal_x: _sx, seal_r: _sr, text_x: (_l + _r) * 0.5, text_w: max(24, _r - _l) };
}

/// @function bwk__mist(x, y, radius, colour, alpha)
/// @description One puff of fog: a fan whose RIM IS FULLY TRANSPARENT, so it has no edge. A flat disc at low alpha
/// still shows its own boundary wherever it overlaps another, and the second bake's fog read as stacked bubbles.
/// ⛔ `draw_vertex_colour` carries its own alpha and ignores `draw_set_alpha` - the alpha is passed per vertex here
/// on purpose. Internal.
function bwk__mist(_x, _y, _r, _c, _a) {
    // two nested fans rather than one: a single linear falloff still turns a corner at the rim, and the eye reads
    // that change of slope as a faint ring. Halving the outer fan's strength halves the step at the edge.
    for (var _p = 0; _p < 2; _p++) {
        var _rad = _r * ((_p == 0) ? 1 : 0.55), _al = _a * ((_p == 0) ? 0.45 : 0.55);
        draw_primitive_begin(pr_trianglefan);
        draw_vertex_colour(_x, _y, _c, _al);
        for (var _i = 0; _i <= 32; _i++) { var _an = 2 * pi * _i / 32; draw_vertex_colour(_x + cos(_an) * _rad, _y - sin(_an) * _rad, _c, 0); }
        draw_primitive_end();
    }
}

/// @function bwk__bezier(x1, y1, x2, y2, width, colour, alpha, dashed)
/// @description A horizontal S-curve connector, sampled in 28 straight pieces (every other one when dashed). Internal.
function bwk__bezier(_x1, _y1, _x2, _y2, _wd, _c, _a, _dash) {
    draw_set_colour(_c); draw_set_alpha(_a);
    var _dx = (_x2 - _x1) * 0.5, _px = _x1, _py = _y1;
    for (var _i = 1; _i <= 28; _i++) {
        var _t = _i / 28, _u = 1 - _t;
        var _qx = _u * _u * _u * _x1 + 3 * _u * _u * _t * (_x1 + _dx) + 3 * _u * _t * _t * (_x2 - _dx) + _t * _t * _t * _x2;
        var _qy = _u * _u * _u * _y1 + 3 * _u * _u * _t * _y1 + 3 * _u * _t * _t * _y2 + _t * _t * _t * _y2;
        if (!_dash || (_i mod 2 == 0)) draw_line_width(_px, _py, _qx, _qy, _wd);
        _px = _qx; _py = _qy;
    }
    draw_set_alpha(1);
}

/// @function bwk__plate(cx, cy, w, h, notch, style, lit)
/// @description A struck plate: a dark rim, the face, a lit upper-left edge and a shadowed lower-right, corners cut
/// by `notch` (a decision). `lit` 0..1 dims an unreached plate. Internal.
function bwk__plate(_cx, _cy, _w, _h, _notch, _S, _lit) {
    var _x0 = _cx - _w / 2, _y0 = _cy - _h / 2, _x1 = _cx + _w / 2, _y1 = _cy + _h / 2, _k = _notch;
    var _P = [[_x0 + _k, _y0], [_x1 - _k, _y0], [_x1, _y0 + _k], [_x1, _y1 - _k], [_x1 - _k, _y1], [_x0 + _k, _y1], [_x0, _y1 - _k], [_x0, _y0 + _k]];
    var _face = merge_colour(_S.board, _S.plate, _lit), _hi = merge_colour(_S.board, _S.plate_hi, _lit), _lo = merge_colour(_S.board_edge, _S.plate_lo, _lit);
    // a drop shadow, the rim, the face
    draw_set_alpha(0.45); draw_set_colour(_S.board_edge);
    draw_primitive_begin(pr_trianglefan); draw_vertex(_cx + 3, _cy + 4); for (var _i = 0; _i <= 8; _i++) draw_vertex(_P[_i mod 8][0] + 3, _P[_i mod 8][1] + 4); draw_primitive_end();
    draw_set_alpha(1);
    draw_primitive_begin(pr_trianglefan); draw_vertex_colour(_cx, _cy, _lo, 1); for (var _i = 0; _i <= 8; _i++) draw_vertex_colour(_P[_i mod 8][0], _P[_i mod 8][1], _lo, 1); draw_primitive_end();
    var _in = 3;
    draw_primitive_begin(pr_trianglefan); draw_vertex_colour(_cx, _cy - _h * 0.1, _face, 1);
    for (var _i = 0; _i <= 8; _i++) { var _q = _P[_i mod 8], _sx = sign(_cx - _q[0]), _sy = sign(_cy - _q[1]); draw_vertex_colour(_q[0] + _sx * _in, _q[1] + _sy * _in, merge_colour(_face, _lo, 0.18 * (_q[1] > _cy)), 1); }
    draw_primitive_end();
    // lit top and left edges, shadowed bottom and right (the light from the upper left)
    draw_set_colour(_hi);
    draw_line_width(_x0 + _k + 2, _y0 + _in, _x1 - _k - 2, _y0 + _in, 1.5); draw_line_width(_x0 + _in, _y0 + _k + 2, _x0 + _in, _y1 - _k - 2, 1.5);
    draw_set_colour(merge_colour(_lo, _S.board_edge, 0.5));
    draw_line_width(_x0 + _k + 2, _y1 - _in, _x1 - _k - 2, _y1 - _in, 1.5); draw_line_width(_x1 - _in, _y0 + _k + 2, _x1 - _in, _y1 - _k - 2, 1.5);
}

/// @function bwk__text_fit(x, y, text, max_width, max_scale, colour, alpha)
/// @description Centred text scaled down to fit a width (texture filtering on for the downscale). Internal.
function bwk__text_fit(_x, _y, _s, _mw, _ms, _c, _a) {
    var _tf = gpu_get_texfilter(); gpu_set_texfilter(true);
    draw_set_halign(fa_center); draw_set_valign(fa_middle);
    var _sc = min(_ms, _mw / max(1, string_width(_s)));
    draw_text_transformed_colour(_x, _y, _s, _sc, _sc, 0, _c, _c, _c, _c, _a);
    draw_set_halign(fa_left); draw_set_valign(fa_top);
    gpu_set_texfilter(_tf);
}

/// @function bwk_emblem_colours(palette)
/// @description [field, rim, device] for one of the eight emblem palettes. Pure.
function bwk_emblem_colours(_p) {
    var _T = [
        [make_colour_rgb(160, 44, 40), make_colour_rgb(236, 196, 110), make_colour_rgb(250, 236, 200)],
        [make_colour_rgb(30, 70, 120), make_colour_rgb(210, 214, 226), make_colour_rgb(236, 240, 250)],
        [make_colour_rgb(34, 96, 64), make_colour_rgb(228, 190, 100), make_colour_rgb(240, 230, 190)],
        [make_colour_rgb(70, 36, 92), make_colour_rgb(220, 180, 220), make_colour_rgb(250, 230, 250)],
        [make_colour_rgb(24, 24, 28), make_colour_rgb(236, 190, 90), make_colour_rgb(236, 190, 90)],
        [make_colour_rgb(200, 150, 40), make_colour_rgb(90, 50, 20), make_colour_rgb(60, 30, 10)],
        // (steel: the field was 120,130,140 and its white device had almost nothing to stand against - the
        // weakest of the eight on the corpus sheet, and the only one a reader had to look twice at)
        [make_colour_rgb(84, 95, 108), make_colour_rgb(198, 206, 216), make_colour_rgb(250, 250, 250)],
        [make_colour_rgb(150, 70, 30), make_colour_rgb(250, 220, 170), make_colour_rgb(40, 20, 10)]
    ];
    return _T[clamp(floor(bwk_num(_p, 0)), 0, 7)];
}

/// @function bwk_draw_emblem(x, y, radius, emblem, [alpha])
/// @description An ending's mark from bwk_emblem: a field in the route's palette, a device whose shape comes from
/// the family and motif (a star of 3 to 10 points, its depth and twist per family), a ring in one of six styles,
/// and one orbiting mark per decision on the route. Returns true when drawn.
function bwk_draw_emblem(_x, _y, _r, _em, _a = 1) {
    if (!is_struct(_em) || !is_string(_em[$ "sig"])) return false;
    _x = bwk_num(_x, 0); _y = bwk_num(_y, 0); _r = bwk_num(_r, 0); _a = clamp(bwk_num(_a, 1), 0, 1);
    if (_r < 6 || _r > 2048) return false;
    var _C = bwk_emblem_colours(_em.palette), _fam = clamp(floor(bwk_num(_em.family, 0)), 0, 5), _mot = clamp(floor(bwk_num(_em.motif, 0)), 0, 7);
    // the field, lit from the upper left
    draw_set_alpha(_a);
    draw_primitive_begin(pr_trianglefan); draw_vertex_colour(_x - _r * 0.25, _y - _r * 0.25, merge_colour(_C[0], c_white, 0.25), _a);
    for (var _i = 0; _i <= 48; _i++) { var _an = 2 * pi * _i / 48; draw_vertex_colour(_x + cos(_an) * _r * 0.78, _y - sin(_an) * _r * 0.78, merge_colour(_C[0], c_black, 0.25), _a); }
    draw_primitive_end();
    // the device: a star whose point count comes from the motif, depth and twist from the family
    var _DEPTH = [0.42, 0.30, 0.55, 0.22, 0.62, 0.36], _TWIST = [0, 0.5, 0.25, 0, 0.5, 0.15];
    var _pts = 3 + _mot, _depth = _DEPTH[_fam], _tw = _TWIST[_fam] * pi / _pts, _R = _r * 0.56;
    draw_primitive_begin(pr_trianglefan); draw_vertex_colour(_x, _y, _C[2], _a);
    for (var _i = 0; _i <= _pts * 2; _i++) { var _an = pi / 2 + pi * _i / _pts + ((_i mod 2) ? _tw : 0), _rr = (_i mod 2) ? _R * _depth : _R; draw_vertex_colour(_x + cos(_an) * _rr, _y - sin(_an) * _rr, _C[2], _a); }
    draw_primitive_end();
    draw_set_colour(_C[0]); draw_circle(_x, _y, _r * 0.08, false);
    // the ring: plain, double, beaded, ticked, dashed or roped.
    // ⛔ The COUNT of beads, ticks and ropes rises with the radius and each one is sized from the PITCH between
    // them, never from the radius alone. A fixed 24 beads is right on a 60px chart mark and draws a ring of
    // boulders on a 290px hero one - a detail bounded only as a proportion is wrong on the largest thing you
    // draw. A real medal puts MORE and FINER beads on a bigger blank, which is what this now does.
    var _ring = clamp(floor(bwk_num(_em.ring, 0)), 0, 5), _rr = _r * 0.86;
    var _nb = clamp(round(_rr * 0.55), 16, 72), _nt = clamp(round(_rr * 0.80), 24, 108);
    var _nd = clamp(round(_rr * 0.36), 12, 48), _np = clamp(round(_rr * 0.70), 20, 84);
    draw_set_colour(_C[1]);
    if (_ring == 0 || _ring == 1) { draw_circle(_x, _y, _rr, true); draw_circle(_x, _y, _rr - 1, true); if (_ring == 1) draw_circle(_x, _y, _rr * 0.9, true); }
    if (_ring == 2) for (var _i = 0; _i < _nb; _i++) { var _an = 2 * pi * _i / _nb; draw_circle(_x + cos(_an) * _rr, _y - sin(_an) * _rr, max(1, _rr * pi / _nb * 0.52), false); }
    if (_ring == 3) { draw_circle(_x, _y, _rr, true); for (var _i = 0; _i < _nt; _i++) { var _an = 2 * pi * _i / _nt; draw_line(_x + cos(_an) * _rr, _y - sin(_an) * _rr, _x + cos(_an) * _rr * 0.9, _y - sin(_an) * _rr * 0.9); } }
    if (_ring == 4) for (var _i = 0; _i < _nd; _i++) { var _a0 = 2 * pi * _i / _nd, _a1 = _a0 + pi / (_nd * 1.35); draw_line_width(_x + cos(_a0) * _rr, _y - sin(_a0) * _rr, _x + cos(_a1) * _rr, _y - sin(_a1) * _rr, max(1, _rr * pi / _nd * 0.42)); }
    if (_ring == 5) for (var _i = 0; _i < _np; _i++) { var _an = 2 * pi * _i / _np; draw_line_width(_x + cos(_an) * _rr * 0.93, _y - sin(_an) * _rr * 0.93, _x + cos(_an + 2.2 / _np) * _rr * 1.02, _y - sin(_an + 2.2 / _np) * _rr * 1.02, max(1, _rr * pi / _np * 0.62)); }
    // one orbiting mark per decision: a dot, a diamond, a bar or a crescent-like pair by the orbit index.
    // ⛔ They ride INSIDE the ring (0.69r, between the device's points at 0.56r and the field edge at 0.78r).
    // At 1.0r they sat outside the ring and over the name plate, where all but one were hidden behind it and the
    // survivor read as a stray tick hanging off the medallion - a glitch, not a mark.
    // ⛔ Each mark is STRUCK, not stuck on: a darker copy offset down-right first, then the mark itself. Drawn
    // flat in one colour they read at hero size as a plain rectangle and a plain disc lying on the field, the
    // only elements on the sheet with no relief - and a sticker beside struck metal reads as a rendering fault.
    var _O = is_array(_em[$ "orbits"]) ? _em.orbits : [];
    for (var _i = 0; _i < array_length(_O); _i++) {
        var _an = pi / 2 - 2 * pi * (_i + 0.5) / max(1, array_length(_O)), _s = _r * 0.07, _k = floor(bwk_num(_O[_i], 0)) mod 4;
        for (var _z = 0; _z < 2; _z++) {
            var _d = (_z == 0) ? max(1, _s * 0.30) : 0;
            var _ox = _x + cos(_an) * _r * 0.70 + _d, _oy = _y - sin(_an) * _r * 0.70 + _d;
            draw_set_colour((_z == 0) ? merge_colour(_C[0], c_black, 0.6) : _C[1]);
            if (_k == 0) draw_circle(_ox, _oy, _s, false);
            else if (_k == 1) { draw_triangle(_ox - _s, _oy, _ox, _oy - _s * 1.4, _ox + _s, _oy, false); draw_triangle(_ox - _s, _oy, _ox, _oy + _s * 1.4, _ox + _s, _oy, false); }
            else if (_k == 2) draw_line_width(_ox - cos(_an) * _s, _oy + sin(_an) * _s, _ox + cos(_an) * _s, _oy - sin(_an) * _s, _s * 0.85);
            else { draw_circle(_ox + sin(_an) * _s * 0.8, _oy + cos(_an) * _s * 0.8, _s * 0.6, false); draw_circle(_ox - sin(_an) * _s * 0.8, _oy - cos(_an) * _s * 0.8, _s * 0.6, false); }
        }
    }
    draw_set_alpha(1);
    return true;
}

/// @function bwk_chart_draw(state, x, y, width, height, [style])
/// @description Draw the whole route chart into a rect: the board, chapter heads, connectors, fog over the
/// unreached, every node's plate or medallion, and collected endings' emblems. Returns the geometry
/// { x, y, w, h, head, colw, rowh, pw, ph } for anything drawn on top, or undefined for a refusal.
function bwk_chart_draw(_st, _x, _y, _w, _h, _sid = "brass") {
    if (!bwk_is_state(_st)) return undefined;
    _x = bwk_num(_x, 0); _y = bwk_num(_y, 0); _w = bwk_num(_w, 0); _h = bwk_num(_h, 0);
    if (_w < 160 || _h < 120 || _w > 16384 || _h > 16384) return undefined;
    var _S = bwk_chart_style(_sid), _L = bwk_layout(_st), _G = bwk_chart_geometry(_L, _x, _y, _w, _h);
    // the board: the ground darkening to the edges, and a faint rule between chapters
    draw_rectangle_colour(_x, _y, _x + _w, _y + _h, _S.board, _S.board, merge_colour(_S.board, _S.board_edge, 0.5), merge_colour(_S.board, _S.board_edge, 0.5), false);
    draw_set_colour(_S.line); draw_set_alpha(0.35);
    for (var _c = 1; _c < _L.cols; _c++) draw_line(_G.x + _c * _G.colw, _y + _G.head * 0.4, _G.x + _c * _G.colw, _y + _h - 8);
    draw_set_alpha(1);
    draw_set_font(fnt_branchwork_title);
    for (var _c = 0; _c < _L.cols; _c++) bwk__text_fit(_G.x + (_c + 0.5) * _G.colw, _y + _G.head * 0.55, "CHAPTER " + bwk_chart_numeral(_c + 1), _G.colw * 0.8, 0.7, _S.line, 1);
    // connectors under the plates, in two passes so a travelled route is never crossed by a merely known one:
    // open (a way known, not taken) dashed first, then travelled solid and lit; hidden is not drawn. (The first bake
    // drew them in declaration order at 1.5 px / 0.8 alpha and the open ones read as scratches.)
    var _pos = {};
    for (var _i = 0; _i < array_length(_L.nodes); _i++) _pos[$ _L.nodes[_i].id] = bwk_chart_node_xy(_G, _L.nodes[_i]);
    for (var _pass = 0; _pass < 2; _pass++) for (var _i = 0; _i < array_length(_L.edges); _i++) {
        var _e = _L.edges[_i]; if (_e.state == "hidden") continue;
        var _a = _pos[$ _e.from], _b = _pos[$ _e.to];
        if (_pass == 1 && _e.state == "travelled") { bwk__bezier(_a[0] + _G.pw / 2, _a[1] + 2, _b[0] - _G.pw / 2, _b[1] + 2, 5, _S.board_edge, 0.5, false); bwk__bezier(_a[0] + _G.pw / 2, _a[1], _b[0] - _G.pw / 2, _b[1], 3, _S.gold, 1, false); }
        if (_pass == 0 && _e.state == "open") bwk__bezier(_a[0] + _G.pw / 2, _a[1], _b[0] - _G.pw / 2, _b[1], 2, merge_colour(_S.line, _S.gold, 0.35), 1, true);
    }
    // the plates
    draw_set_font(fnt_branchwork);
    for (var _i = 0; _i < array_length(_L.nodes); _i++) {
        var _n = _L.nodes[_i], _p = _pos[$ _n.id], _lit = _n.reached ? 1 : 0.28, _B = bwk_chart_plate_box(_G, _n.kind);
        // the lit halo on the node the player stands on, largest and faintest first so it reads as a glow and not
        // as four stacked boxes (every ring was the same alpha on the second bake)
        if (_n.current) for (var _g = 4; _g >= 1; _g--) { draw_set_alpha(0.16 - _g * 0.028); draw_set_colour(_S.glow); draw_roundrect_ext(_p[0] - _G.pw / 2 - _g * 3, _p[1] - _G.ph / 2 - _g * 3, _p[0] + _G.pw / 2 + _g * 3, _p[1] + _G.ph / 2 + _g * 3, 12, 12, false); draw_set_alpha(1); }
        bwk__plate(_p[0], _p[1], _G.pw, _G.ph, _B.notch, _S, _lit);
        if (_n.kind == "ending") {
            var _end = bwk_ending(_st, _n.id), _mx = _p[0] + _B.seal_x, _r = _B.seal_r;
            if (is_struct(_end)) bwk_draw_emblem(_mx, _p[1], _r, _end.emblem);
            else {
                // an ending not yet earned keeps a BLANK: the plate's own metal, sunk and rimmed, never struck.
                // (an outline circle let the board show through and cut across the plate's corner)
                var _bl = merge_colour(_S.board, _S.plate_lo, _lit), _bh = merge_colour(_S.board, _S.plate, _lit);
                draw_set_colour(_bl); draw_circle(_mx, _p[1], _r * 0.88, false);
                draw_primitive_begin(pr_trianglefan); draw_vertex_colour(_mx, _p[1] - _r * 0.25, merge_colour(_bh, _bl, 0.35), 1);
                for (var _q = 0; _q <= 32; _q++) { var _an = 2 * pi * _q / 32; draw_vertex_colour(_mx + cos(_an) * _r * 0.78, _p[1] - sin(_an) * _r * 0.78, merge_colour(_bl, _S.board_edge, 0.35), 1); }
                draw_primitive_end();
            }
        }
        // (a three-dot "converge" marker read as a rendering glitch on the first bake - two connectors arriving
        // already say it - so it was removed)
        bwk__text_fit(_p[0] + _B.text_x, _p[1], _n.label, _B.text_w, 0.8, merge_colour(_S.board, _S.engrave, _lit), 1);
        // rivets, lit on the upper left: struck metal, not a flat panel (an ending carries only the right one -
        // its left end is the seal)
        for (var _q = -1; _q <= 1; _q += 2) if (!(_n.kind == "ending" && _q < 0)) {
            var _vx = _p[0] + _q * _B.rivet_x, _rv = _B.rivet_r;
            draw_set_colour(merge_colour(_S.board, _S.plate_lo, _lit)); draw_circle(_vx, _p[1], _rv, false);
            draw_set_colour(merge_colour(_S.board, _S.plate_hi, _lit)); draw_circle(_vx - _rv * 0.3, _p[1] - _rv * 0.3, _rv * 0.45, false);
        }
    }
    // fog OVER what has never been seen, drawn last so it lies on the dimmed plates: overlapping puffs of a mist
    // lighter than the board (under the plates, the first bake's fog was covered and could not be seen).
    // ⛔ Every puff is a transparent-rimmed fan, WIDEST FIRST. The second bake drew flat discs at alpha 0.07 and
    // each one showed its own hard boundary through the others - six countable bubbles per node, not fog.
    for (var _i = 0; _i < array_length(_L.nodes); _i++) {
        var _n = _L.nodes[_i]; if (_n.reached) continue;
        var _p = _pos[$ _n.id];
        for (var _q = 5; _q >= 0; _q--) {
            var _ox = (bwk_pick(_n.id, "fx" + string(_q), 100) / 100 - 0.5) * _G.pw * 0.9, _oy = (bwk_pick(_n.id, "fy" + string(_q), 100) / 100 - 0.5) * _G.ph * 1.2;
            bwk__mist(_p[0] + _ox, _p[1] + _oy, _G.ph * (0.7 + 0.12 * _q), _S.fog, 0.13);
        }
    }
    draw_set_alpha(1);
    return _G;
}
