{
  "$GMScript": "v1",
  "%Name": "bwk_bake",
  "name": "bwk_bake",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}