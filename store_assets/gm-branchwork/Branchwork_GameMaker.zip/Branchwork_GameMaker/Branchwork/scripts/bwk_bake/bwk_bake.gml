/// bwk_bake.gml - renders the store sheets THROUGH THE PRODUCT'S OWN DRAW CODE (`Branchwork.exe -bake`), so the
/// listing can say every image on the page was drawn by the thing being sold.
///
/// Branchwork - A Story Flowchart the Game Draws, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory.
/// ⛔ The catalogue sheets are laid on a FLAT ground on purpose: the ink scan below compares against one colour,
/// and a gradient ground would read as ink everywhere. The chart sheets are full-bleed boards by design, so their
/// containment is asserted from GEOMETRY in the suite instead (nothing here can see a picture).

function bwk_bake_opaque(_w, _h) {
    gpu_set_colorwriteenable(false, false, false, true); draw_set_alpha(1);
    draw_rectangle_colour(0, 0, _w, _h, c_white, c_white, c_white, c_white, false);
    gpu_set_colorwriteenable(true, true, true, true);
}

/// @function bwk_bake_ink(surface, w, h, ground)
/// @description The ink bounding box and pixel count of a finished sheet, scanning every row (a clipped hairline
/// lands on ONE row) and every second column. { x0, y0, x1, y1, px, fill_x, fill_y }.
function bwk_bake_ink(_sf, _w, _h, _ground) {
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    var _x0 = _w, _y0 = _h, _x1 = -1, _y1 = -1, _n = 0;
    var _gr = colour_get_red(_ground), _gg = colour_get_green(_ground), _gb = colour_get_blue(_ground);
    for (var _y = 0; _y < _h; _y++) for (var _x = 0; _x < _w; _x += 2) {
        var _o = (_y * _w + _x) * 4;
        if (abs(buffer_peek(_b, _o, buffer_u8) - _gr) > 10 || abs(buffer_peek(_b, _o + 1, buffer_u8) - _gg) > 10 || abs(buffer_peek(_b, _o + 2, buffer_u8) - _gb) > 10) {
            _n++;
            if (_x < _x0) _x0 = _x; if (_x > _x1) _x1 = _x;
            if (_y < _y0) _y0 = _y; if (_y > _y1) _y1 = _y;
        }
    }
    buffer_delete(_b);
    return { x0: _x0, y0: _y0, x1: _x1, y1: _y1, px: _n, fill_x: (_x1 - _x0) / _w, fill_y: (_y1 - _y0) / _h };
}

function bwk_bake_sheet(_name, _w, _h, _fn, _ground = -1) {
    var _sf = surface_create(_w, _h);
    surface_set_target(_sf); draw_clear(make_colour_rgb(18, 16, 14)); gpu_set_texfilter(true);
    var _end = _fn(_w, _h);
    gpu_set_texfilter(false);
    var _ink = (_ground >= 0) ? bwk_bake_ink(_sf, _w, _h, _ground) : undefined;
    bwk_bake_opaque(_w, _h); surface_reset_target();
    surface_save(_sf, _name + ".png"); surface_free(_sf);
    array_push(global.bwk_bake_log, { sheet: _name, w: _w, h: _h, drew_to: is_real(_end) ? _end : -1, ink: _ink });
}

/// @function bwk_bake_route()
/// @description The demo story after two runs and a third in progress: two endings collected by different roads
/// and the player standing mid-way down a third. Pure (no drawing).
function bwk_bake_route() {
    var _r = bwk_create(bwk_demo_graph());
    var _A = ["wake", "stay", "conductor", "bargain"];
    for (var _i = 0; _i < array_length(_A); _i++) bwk_reach(_r, _A[_i]);
    bwk_reach_ending(_r, "home");
    bwk_reset_path(_r);
    var _B = ["wake", "leave", "letter", "walk"];
    for (var _i = 0; _i < array_length(_B); _i++) bwk_reach(_r, _B[_i]);
    bwk_reach_ending(_r, "tide");
    bwk_reset_path(_r);
    var _C = ["wake", "leave", "platform"];
    for (var _i = 0; _i < array_length(_C); _i++) bwk_reach(_r, _C[_i]);
    return _r;
}

/// @function bwk_bake_walk(state, ids)
/// @description Walk a list of ids, collecting any ending among them. Internal to the bake.
function bwk_bake_walk(_r, _ids) {
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _n = bwk_node(_r, _ids[_i]);
        if (is_struct(_n) && _n.kind == "ending") bwk_reach_ending(_r, _ids[_i]); else bwk_reach(_r, _ids[_i]);
    }
    return _r;
}

/// @function bwk_bake_caption(x, y, w, text, sub, style)
/// @description A caption strip above a band: a rule, a title, a sentence. Internal to the bake.
function bwk_bake_caption(_x, _y, _w, _t, _sub, _S) {
    draw_set_font(fnt_branchwork_title);
    bwk__text_fit(_x + _w * 0.5, _y + 18, _t, _w * 0.62, 0.8, merge_colour(_S.line, _S.gold, 0.75), 1);
    draw_set_font(fnt_branchwork);
    bwk__text_fit(_x + _w * 0.5, _y + 38, _sub, _w * 0.72, 0.62, merge_colour(_S.line, _S.gold, 0.25), 1);
}

/// @function bwk__plural(n, one, many)
/// @description "1 CHOICE", "3 CHOICES". A caption a buyer reads has to be written in English, and the first bake
/// of the corpus sheet said "1 CHOICES" on every short route. Internal to the bake.
function bwk__plural(_n, _one, _many) { return string(_n) + " " + ((_n == 1) ? _one : _many); }

/// @function bwk_bake_corpus(w, h)
/// @description Every mark "The Hollow Road" can earn, one per distinct route. Returns the y it finished at.
function bwk_bake_corpus(_w, _h) {
    var _S = bwk_chart_style("brass"), _bg = _S.board;
    draw_set_colour(_bg); draw_rectangle(0, 0, _w, _h, false);
    var _M = bwk_demo_marks(48), _cols = 8, _rows = ceil(max(1, array_length(_M)) / _cols);
    var _head = 112, _cw = _w / _cols, _ch = (_h - _head - 16) / _rows, _r = min(_cw, _ch) * 0.375;
    draw_set_font(fnt_branchwork_title);
    bwk__text_fit(_w * 0.5, 44, "EVERY ROUTE EARNS ITS OWN MARK", _w * 0.74, 1.05, merge_colour(_S.line, _S.gold, 0.8), 1);
    draw_set_font(fnt_branchwork);
    // ⛔ the node count is DERIVED from the graph, never typed - it was "TWENTY" for one bake and the story grew
    bwk__text_fit(_w * 0.5, 82, string(array_length(_M)) + " OF THEM, FROM ONE " + string(array_length(bwk_demo_long_graph())) + " NODE STORY, COMPOSED AND DRAWN IN GML", _w * 0.66, 0.72, merge_colour(_S.line, _S.gold, 0.34), 1);
    for (var _i = 0; _i < array_length(_M); _i++) {
        var _cx = (_i mod _cols + 0.5) * _cw, _cy = _head + (floor(_i / _cols) + 0.5) * _ch;
        bwk_draw_emblem(_cx, _cy - _ch * 0.09, _r, _M[_i].emblem);
        draw_set_font(fnt_branchwork);
        bwk__text_fit(_cx, _cy + _ch * 0.37, string_upper(_M[_i].label) + "   " + bwk__plural(_M[_i].steps, "STEP", "STEPS") + "   " + bwk__plural(_M[_i].decisions, "CHOICE", "CHOICES"), _cw * 0.92, 0.60, merge_colour(_S.line, _S.gold, 0.42), 1);
    }
    return _head + _rows * _ch;
}

/// @function bwk_bake_anatomy(w, h)
/// @description One mark at hero size, with every part named from the route that made it. Returns the finish y.
function bwk_bake_anatomy(_w, _h) {
    var _S = bwk_chart_style("brass"), _bg = _S.board;
    draw_set_colour(_bg); draw_rectangle(0, 0, _w, _h, false);
    // a route whose ending is NOT secret: a secret node reports its label as "???" until it is reached, and a
    // hero caption reading "to ???" looks like a defect even though it is telling the truth
    var _st = bwk_create(bwk_demo_long_graph()), _R = bwk_routes(_st), _route = _R[0], _best = -1;
    for (var _i = 0; _i < array_length(_R); _i++) {
        var _cand = _R[_i], _e = bwk_node(_st, _cand[array_length(_cand) - 1]);
        if (is_struct(_e) && !_e.secret && array_length(_cand) > _best) { _best = array_length(_cand); _route = _cand; }
    }
    var _endid = _route[array_length(_route) - 1], _em = bwk_emblem(_st, _route, _endid);
    draw_set_font(fnt_branchwork_title);
    bwk__text_fit(_w * 0.5, 52, "THE MARK IS THE ROUTE", _w * 0.7, 1.15, merge_colour(_S.line, _S.gold, 0.8), 1);
    draw_set_font(fnt_branchwork);
    bwk__text_fit(_w * 0.5, 92, "NOTHING HERE IS ART IN A FOLDER - IT IS COMPOSED FROM THE CHOICES THE PLAYER MADE", _w * 0.68, 0.68, merge_colour(_S.line, _S.gold, 0.3), 1);
    var _cx = _w * 0.24, _cy = _h * 0.44, _r = min(_w * 0.115, _h * 0.20);
    bwk_draw_emblem(_cx, _cy, _r, _em);
    // the same ENDING reached by three other roads - the product's whole claim in one row, and what turns the
    // empty band under the hero into the argument the sheet is making
    var _same = [];
    for (var _i = 0; _i < array_length(_R) && array_length(_same) < 3; _i++) {
        var _c2 = _R[_i];
        if (_c2[array_length(_c2) - 1] != _endid) continue;
        if (bwk_signature(_c2, _endid) == _em.sig) continue;
        array_push(_same, bwk_emblem(_st, _c2, _endid));
    }
    if (array_length(_same) > 0) {
        draw_set_font(fnt_branchwork);
        bwk__text_fit(_cx, _cy + _r + 44, "THE SAME ENDING, REACHED BY OTHER ROADS", _w * 0.42, 0.66, merge_colour(_S.line, _S.gold, 0.45), 1);
        var _sr2 = min(_w * 0.045, _h * 0.075);
        for (var _i = 0; _i < array_length(_same); _i++) {
            var _sx2 = _cx + (_i - (array_length(_same) - 1) * 0.5) * (_sr2 * 2.7);
            bwk_draw_emblem(_sx2, _cy + _r + 44 + 26 + _sr2, _sr2, _same[_i]);
        }
    }
    // what each part came from, derived from this emblem and this route
    var _ringnames = ["a plain band", "a double band", "a beaded band", "a ticked band", "a dashed band", "a roped band"];
    var _L = [
        ["FIELD AND RIM", "palette " + string(_em.palette + 1) + " of 8, hashed from the route"],
        ["DEVICE", "family " + string_upper(bwk_emblem_families()[_em.family]) + " from the ending's tone, " + string(3 + _em.motif) + " points from its motif"],
        ["RING", _ringnames[clamp(_em.ring, 0, 5)] + " - " + bwk__plural(_em.steps, "step", "steps") + ", " + string(_em.decisions) + " of them choices"],
        ["ORBITS", bwk__plural(array_length(_em.orbits), "mark", "marks") + ", one for every decision on the way"],
        ["THE ROUTE", string_upper(bwk_label(_st, _route[0])) + " to " + string_upper(bwk_label(_st, _endid))]
    ];
    // ⛔ The rule goes BELOW each entry, not through it. The first bake ran a hairline at y+26 across a sub-line
    // whose middle sat at y+22 and struck it out - the same defect this wing has shipped as a type band drawn
    // through its own subtitle.
    var _lx = _w * 0.50, _ly = _cy - 168, _pitch = 84;
    for (var _i = 0; _i < array_length(_L); _i++) {
        var _y = _ly + _i * _pitch;
        draw_set_colour(merge_colour(_S.line, _S.gold, 0.55)); draw_line_width(_lx - 34, _y + 2, _lx - 12, _y + 2, 2);
        draw_set_font(fnt_branchwork_title); draw_set_halign(fa_left); draw_set_valign(fa_middle);
        draw_set_colour(merge_colour(_S.line, _S.gold, 0.85)); draw_text_transformed(_lx, _y, _L[_i][0], 0.78, 0.78, 0);
        draw_set_font(fnt_branchwork); draw_set_colour(merge_colour(_S.line, _S.gold, 0.34));
        draw_text_transformed(_lx, _y + 26, _L[_i][1], 0.70, 0.70, 0);
        draw_set_colour(merge_colour(_S.line, _S.board, 0.55)); draw_line_width(_lx - 12, _y + 50, _w - 96, _y + 50, 1);
        draw_set_halign(fa_left); draw_set_valign(fa_top);
    }
    // the route itself along the foot, so the page shows the road as well as the mark it earned
    var _ry = _h - 74, _n = array_length(_route), _pw = min(190, (_w - 160) / _n - 14);
    draw_set_font(fnt_branchwork_title);
    bwk__text_fit(_w * 0.5, _ry - 46, "THE ROAD THAT STRUCK IT", _w * 0.5, 0.66, merge_colour(_S.line, _S.gold, 0.45), 1);
    var _Gf = { pw: _pw, ph: 30 };
    for (var _i = 0; _i < _n; _i++) {
        var _px = 80 + (_i + 0.5) * ((_w - 160) / _n), _nd = bwk_node(_st, _route[_i]);
        if (_i > 0) { draw_set_colour(_S.gold); draw_line_width(_px - (_w - 160) / _n * 0.5 - 2, _ry, _px - _pw / 2 - 2, _ry, 2); }
        var _Bf = bwk_chart_plate_box(_Gf, _nd.kind);
        bwk__plate(_px, _ry, _pw, 30, _Bf.notch, _S, 1);
        // the chain ends in the mark itself, at chart size beside its hero
        if (_nd.kind == "ending") bwk_draw_emblem(_px + _Bf.seal_x, _ry, _Bf.seal_r, _em);
        draw_set_font(fnt_branchwork);
        bwk__text_fit(_px + _Bf.text_x, _ry, _nd.label, _Bf.text_w, 0.60, _S.engrave, 1);
    }
    return _ry + 20;
}

/// @function bwk_bake_runs(w, h)
/// @description One story at three moments: a first run, the same chart after a jump back, and a New Game+ with
/// two endings collected by different roads. Returns the finish y.
function bwk_bake_runs(_w, _h) {
    var _S = bwk_chart_style("brass"), _band = _h / 3, _cap = 58;
    var _A = bwk_bake_walk(bwk_create(bwk_demo_graph()), ["wake", "stay", "conductor"]);
    var _B = bwk_bake_walk(bwk_create(bwk_demo_graph()), ["wake", "stay", "conductor", "bargain", "home"]);
    bwk_jump_store(_B, "stay", "save@stay"); bwk_jump(_B, "stay");
    var _C = bwk_bake_route();
    var _T = [[_A, "A FIRST RUN", "the chart knows only what this player has walked - a way out is dashed, the unknown is fog"],
              [_B, "AFTER A JUMP BACK", "an ending is collected, the path is cut back to a decision, and everything reached is kept"],
              [_C, "TWO ENDINGS, TWO ROADS", "every route travelled stays gold; the marks are the two endings this player earned"]];
    for (var _i = 0; _i < 3; _i++) {
        var _y = _i * _band;
        draw_set_colour(_S.board_edge); draw_rectangle(0, _y, _w, _y + _cap, false);
        bwk_bake_caption(0, _y + 4, _w, _T[_i][1], _T[_i][2], _S);
        bwk_chart_draw(_T[_i][0], 0, _y + _cap, _w, _band - _cap - 6, "brass");
    }
    return _h - 6;
}

/// @function bwk__pad3(n)
/// @description A frame number padded to three digits BY ARITHMETIC. ⛔ Never by replacing spaces in a formatted
/// string - `string_replace` replaces ONE occurrence, and that shipped frames named "frame_0 0.png" once. Internal.
function bwk__pad3(_n) { var _s = string(floor(_n)); while (string_length(_s) < 3) _s = "0" + _s; return _s; }

/// @function bwk_gif_all()
/// @description The GIF: the DEMO ITSELF being played - choices taken, an ending struck, a jump back, a new run,
/// a second ending by another road. Rendered through `bwk_demo_draw`, so what a buyer watches is what a buyer runs.
function bwk_gif_all() {
    var _w = 900, _h = 506, _d = bwk_demo_state(), _n = 0;
    // [what to do, how many frames to hold it]
    var _SCRIPT = [["", 8], ["stay", 5], ["conductor", 5], ["bargain", 5], ["home", 12], ["jump", 8],
                   ["reset", 5], ["leave", 5], ["letter", 5], ["walk", 5], ["tide", 12], ["style", 10]];
    var _sf = surface_create(_w, _h);
    for (var _s = 0; _s < array_length(_SCRIPT); _s++) {
        var _act = _SCRIPT[_s][0];
        if (_act == "jump") { var _p = bwk_current_path(_d.route); for (var _i = array_length(_p) - 2; _i >= 0; _i--) if (bwk_can_jump(_d.route, _p[_i])) { bwk_jump(_d.route, _p[_i]); break; } }
        else if (_act == "reset") { bwk_reset_path(_d.route); bwk_reach(_d.route, "wake"); }
        else if (_act == "style") { _d.style = "night"; }
        else if (_act != "") {
            var _C = bwk_demo_choices(_d);
            for (var _i = 0; _i < array_length(_C); _i++) if (_C[_i] == _act) bwk_demo_choose(_d, _i);
        }
        repeat (_SCRIPT[_s][1]) {
            surface_set_target(_sf); draw_clear(make_colour_rgb(18, 16, 14)); gpu_set_texfilter(true);
            bwk_demo_draw(_d, _w, _h);
            gpu_set_texfilter(false); bwk_bake_opaque(_w, _h); surface_reset_target();
            surface_save(_sf, "gif_" + bwk__pad3(_n) + ".png");
            _n++;
        }
    }
    surface_free(_sf);
}

function bwk_bake_all() {
    global.bwk_bake_log = [];
    var _brass = bwk_chart_style("brass");
    bwk_bake_sheet("sheet_1_the_chart", 1600, 900, function(_w, _h) {
        return bwk_chart_draw(bwk_bake_route(), 0, 0, _w, _h, "brass") != undefined ? _h : -1;
    });
    bwk_bake_sheet("sheet_2_three_styles", 1600, 1380, function(_w, _h) {
        var _S = bwk_chart_styles(), _r = bwk_bake_route();
        for (var _i = 0; _i < 3; _i++) bwk_chart_draw(_r, 0, _i * 460, _w, 450, _S[_i]);
        return 1380;
    });
    bwk_bake_sheet("sheet_3_every_mark", 1600, 1240, bwk_bake_corpus, _brass.board);
    bwk_bake_sheet("sheet_4_across_runs", 1600, 1440, bwk_bake_runs);
    bwk_bake_sheet("sheet_5_the_mark_is_the_route", 1600, 900, bwk_bake_anatomy, _brass.board);
    // the log is the only thing that can report a clipped or empty sheet after the fact
    var _f = file_text_open_write("bwk_bake.json");
    file_text_write_string(_f, "[");
    for (var _i = 0; _i < array_length(global.bwk_bake_log); _i++) {
        var _e = global.bwk_bake_log[_i];
        if (_i > 0) file_text_write_string(_f, ",");
        file_text_write_string(_f, "{\"sheet\":\"" + _e.sheet + "\",\"w\":" + string(_e.w) + ",\"h\":" + string(_e.h) + ",\"drewTo\":" + string(_e.drew_to));
        if (is_struct(_e.ink)) file_text_write_string(_f, ",\"ink\":{\"x0\":" + string(_e.ink.x0) + ",\"y0\":" + string(_e.ink.y0) + ",\"x1\":" + string(_e.ink.x1) + ",\"y1\":" + string(_e.ink.y1) + ",\"px\":" + string(_e.ink.px) + ",\"fillX\":" + string(_e.ink.fill_x) + ",\"fillY\":" + string(_e.ink.fill_y) + "}");
        file_text_write_string(_f, "}");
    }
    file_text_write_string(_f, "]");
    file_text_close(_f);
}
