/// bwk_selftest.gml - the in-engine suite (`Branchwork.exe -selftest` writes bwk_selftest.json).
///
/// Branchwork - A Story Flowchart the Game Draws, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Stage 99 = the suite reached its end.
/// SCOPE: the pure core (graph building and its reported problems, reach and edges, endings and their emblems,
/// layout, node states, secret labels, jump points, save/load, route enumeration) AND the chart's LAYOUT
/// CONTRACT, swept at three sizes - because nothing mechanical in this wing can see a picture, so the geometry
/// a picture is built from is the only thing an assertion can hold.

function bwk_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 60) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
function bwk_st_stage(_st, _n) { _st.stage = _n; global.bwk_stage = _n; }
function bwk_st_note(_st, _s) { array_push(_st.notes, _s); }

function bwk_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, failures: [], stage: 0, notes: [] };

    bwk_st_stage(_st, 1);    // building the graph: problems REPORTED, never thrown
    var _g = bwk_create(bwk_demo_graph());
    bwk_st_assert(_st, bwk_is_state(_g) && array_length(_g.nodes) == 14 && array_length(bwk_problems(_g)) == 0 && bwk_ending_total(_g) == 4, "the demo graph: " + string(array_length(_g.nodes)) + " nodes, problems " + string(bwk_problems(_g)));
    var _bad = bwk_create([{ id: "a" }, { id: "a", label: "dup" }, { id: "b", from: "a, ghost" }, { label: "no id" }, 7]);
    bwk_st_assert(_st, array_length(_bad.nodes) == 2 && array_length(bwk_problems(_bad)) == 4 && array_length(bwk_node(_bad, "b").from) == 1, "problems: duplicate, unknown link, missing id, non-struct: " + string(bwk_problems(_bad)));
    bwk_st_assert(_st, bwk_node(_bad, "b").from[0] == "a" && bwk_node(_bad, "a").label == "a" && bwk_node(_bad, "a").kind == "event", "defaults: label = id, kind = event, `from` parsed from a comma string");
    bwk_st_assert(_st, !bwk_is_state(bwk_create(undefined).record) && array_length(bwk_create("x").problems) == 1, "a non-array graph is a reported problem");

    bwk_st_stage(_st, 2);    // reaching, edges, the path
    var _r = bwk_create(bwk_demo_graph());
    bwk_st_assert(_st, bwk_reach(_r, "wake") && bwk_reach(_r, "stay") && !bwk_reach(_r, "stay") && !bwk_reach(_r, "nowhere"), "reach: true when it changes, false on a repeat or an unknown id");
    bwk_st_assert(_st, bwk_has_edge(_r, "wake", "stay") && !bwk_has_edge(_r, "stay", "wake") && bwk_current_node(_r) == "stay" && array_length(bwk_current_path(_r)) == 2, "edges are directed; the path is the run");
    var _p = bwk_current_path(_r); array_push(_p, "junk");
    bwk_st_assert(_st, array_length(bwk_current_path(_r)) == 2, "bwk_current_path returns a COPY");

    bwk_st_stage(_st, 3);    // endings and emblems
    bwk_reach(_r, "conductor"); bwk_reach(_r, "bargain");
    var _e = bwk_reach_ending(_r, "home");
    bwk_st_assert(_st, is_struct(_e) && _e.count == 1 && bwk_has_ending(_r, "home") && bwk_ending_count(_r) == 1 && _e.emblem.family == 0, "the ending is collected and its declared tone (dawn) fixes the family");
    bwk_st_assert(_st, _e.emblem.decisions == 2 && _e.emblem.steps == 5 && array_length(_e.emblem.orbits) == 2 && _e.emblem.sig == "wake>stay>conductor>bargain>home#home", "the emblem counts the route: " + string(_e.emblem));
    // the same ending by another route: counted, the route recorded, the first emblem KEPT
    var _first = _e.emblem.sig;
    bwk_reset_path(_r); bwk_reach(_r, "wake"); bwk_reach(_r, "leave"); bwk_reach(_r, "letter"); bwk_reach(_r, "bargain");
    var _e2 = bwk_reach_ending(_r, "home");
    bwk_st_assert(_st, _e2.count == 2 && array_length(_e2.routes) == 2 && _e2.emblem.sig == _first, "a second route counts and records, never overwrites the first mark");
    // determinism and spread: every route to every ending over 200 random walks, emblems re-derived identically
    var _sigs = {}, _marks = {}, _walks = 0, _same = true;
    for (var _s = 1; _s <= 200; _s++) {
        var _w = bwk_create(bwk_demo_graph()), _cur = "wake", _k = 0;
        bwk_reach(_w, "wake");
        while (_k++ < 20) {
            var _C = []; for (var _i = 0; _i < array_length(_w.nodes); _i++) { var _n = _w.nodes[_i]; for (var _j = 0; _j < array_length(_n.from); _j++) if (_n.from[_j] == _cur) array_push(_C, _n.id); }
            if (array_length(_C) == 0) break;
            _cur = _C[bwk_pick(string(_s) + ":" + string(_k), "walk", array_length(_C))];
            if (bwk_node(_w, _cur).kind == "ending") { var _en = bwk_reach_ending(_w, _cur); _walks++; _sigs[$ _en.emblem.sig] = true;
                var _mk = string(_en.emblem.family) + "/" + string(_en.emblem.motif) + "/" + string(_en.emblem.ring) + "/" + string(_en.emblem.orbits) + "/" + string(_en.emblem.palette); _marks[$ _mk] = true;
                var _again = bwk_emblem(_w, _en.path, _cur); if (_again.sig != _en.emblem.sig || _again.motif != _en.emblem.motif || _again.palette != _en.emblem.palette) _same = false; break; }
            bwk_reach(_w, _cur);
        }
    }
    var _nr = array_length(variable_struct_get_names(_sigs)), _nm = array_length(variable_struct_get_names(_marks));
    bwk_st_note(_st, "200 random walks: " + string(_walks) + " endings reached, " + string(_nr) + " distinct routes, " + string(_nm) + " distinct emblems");
    bwk_st_assert(_st, _walks >= 150 && _same && _nr >= 5 && _nm == _nr, "emblems must be deterministic and one per distinct route: routes " + string(_nr) + " marks " + string(_nm));

    bwk_st_stage(_st, 4);    // layout, node states, secret labels
    var _L = bwk_layout(_r);
    bwk_st_assert(_st, _L.cols == 5 && _L.rows == 4 && array_length(_L.nodes) == 14 && array_length(_L.edges) == 17, "layout: " + string(_L.cols) + " cols, " + string(_L.rows) + " rows, " + string(array_length(_L.edges)) + " edges");
    var _hid = 0, _open = 0, _trav = 0;
    for (var _i = 0; _i < array_length(_L.edges); _i++) { var _ed = _L.edges[_i]; if (_ed.state == "hidden") _hid++; else if (_ed.state == "open") _open++; else _trav++; }
    bwk_st_note(_st, "layout after two runs: edges travelled " + string(_trav) + ", open " + string(_open) + ", hidden " + string(_hid));
    bwk_st_assert(_st, _trav == 7 && _open > 0 && _hid > 0 && _trav + _open + _hid == 17, "edge states: travelled " + string(_trav) + " open " + string(_open) + " hidden " + string(_hid));
    bwk_st_assert(_st, bwk_node_state(_r, "home") == "current" && bwk_node_state(_r, "letter") == "converge" && bwk_node_state(_r, "wake") == "reached" && bwk_node_state(_r, "tide") == "unseen" && bwk_node_state(_r, "nope") == "", "node states");
    bwk_st_assert(_st, bwk_label(_r, "stationmaster") == "???" && bwk_label(_r, "tide") == "Where the Rails Go Under", "a secret node hides its label until reached, an ordinary one does not");

    bwk_st_stage(_st, 5);    // jump points
    var _j = bwk_create(bwk_demo_graph(), { max_jumps: 2 });
    bwk_reach(_j, "wake"); bwk_reach(_j, "stay"); bwk_reach(_j, "conductor");
    bwk_st_assert(_st, !bwk_jump_store(_j, "tide", "x") && bwk_jump_store(_j, "wake", "S0") && bwk_jump_store(_j, "stay", "S1") && bwk_jump_store(_j, "conductor", "S2"), "jump points are kept only for reached nodes");
    bwk_st_assert(_st, !bwk_can_jump(_j, "wake") && bwk_can_jump(_j, "stay") && bwk_can_jump(_j, "conductor"), "past max_jumps the OLDEST is recycled");
    var _snap = bwk_jump(_j, "stay");
    bwk_st_assert(_st, _snap == "S1" && bwk_current_node(_j) == "stay" && array_length(bwk_current_path(_j)) == 2 && bwk_has_reached(_j, "conductor"), "a jump returns the stored snapshot, cuts the path back and keeps everything reached");
    bwk_st_assert(_st, bwk_jump(_j, "tide") == undefined && !bwk_can_jump(bwk_create(bwk_demo_graph(), { allow_jump: false }), "wake"), "jump refusals");

    bwk_st_stage(_st, 6);    // save and load
    var _sv = bwk_save(_r), _l = bwk_create(bwk_demo_graph());
    bwk_st_assert(_st, bwk_load(_l, _sv) && bwk_ending_count(_l) == 1 && bwk_ending(_l, "home").count == 2 && bwk_current_node(_l) == "home" && bwk_has_edge(_l, "leave", "letter"), "a save loads into a fresh state of the same graph");
    var _small = bwk_create([{ id: "wake" }, { id: "stay", from: "wake" }]);
    bwk_st_assert(_st, bwk_load(_small, _sv) && array_length(_small.record.reached) == 2 && bwk_ending_count(_small) == 0, "an old save into a smaller graph drops unknown ids");
    bwk_st_assert(_st, !bwk_load(_l, "{bad") && !bwk_load(_l, "") && !bwk_load(undefined, _sv) && bwk_save(undefined) == "" && bwk_ending_count(_l) == 1, "unreadable saves are refused and leave the state untouched");

    bwk_st_stage(_st, 7);    // the plate box - no assertion can see a picture, so the LAYOUT is the contract.
    // ⛔ Swept at THREE sizes, because a layout defect is invisible at store-sheet size and obvious small: the
    // store sheet, the demo room's own chart rect, and a deliberately cramped one.
    draw_set_font(fnt_branchwork);
    var _SZ = [[1600, 900, 0.45, "store sheet"], [1280, 584, 0.45, "the demo room"], [640, 360, 0, "cramped"]];
    var _kinds = ["event", "decision", "ending"];
    for (var _s = 0; _s < array_length(_SZ); _s++) {
        var _G7 = bwk_chart_geometry(bwk_layout(_g), 0, 0, _SZ[_s][0], _SZ[_s][1]), _riv = true, _in = true;
        for (var _i = 0; _i < 3; _i++) {
            var _Bk = bwk_chart_plate_box(_G7, _kinds[_i]);
            if (_Bk.rivet_x + _Bk.rivet_r > _G7.pw / 2 - _Bk.notch) _riv = false;
            if (_Bk.text_x - _Bk.text_w / 2 < -_G7.pw / 2 - _Bk.seal_r || _Bk.text_x + _Bk.text_w / 2 > _G7.pw / 2) _in = false;
        }
        var _BE = bwk_chart_plate_box(_G7, "ending");
        bwk_st_assert(_st, _riv, _SZ[_s][3] + ": no rivet lands on a plate's cut corner (an ending's sat on the chevron's slope)");
        bwk_st_assert(_st, _in, _SZ[_s][3] + ": every label box stays within its own plate");
        bwk_st_assert(_st, (_BE.text_x - _BE.text_w / 2 >= _BE.seal_x + _BE.seal_r) && (_BE.text_x + _BE.text_w / 2 <= _BE.rivet_x - _BE.rivet_r), _SZ[_s][3] + ": an ending's label box clears its seal and its rivet");
        var _worst = 1, _longest = "";
        for (var _i = 0; _i < array_length(_g.nodes); _i++) if (_g.nodes[_i].kind == "ending") {
            var _lb = _g.nodes[_i].label, _sc = min(0.8, _BE.text_w / max(1, string_width(_lb)));
            if (_sc < _worst) { _worst = _sc; _longest = _lb; }
        }
        bwk_st_note(_st, _SZ[_s][3] + " " + string(_SZ[_s][0]) + "x" + string(_SZ[_s][1]) + ": plate " + string(round(_G7.pw)) + "px, ending label box " + string(round(_BE.text_w)) + "px, tightest label \"" + _longest + "\" at scale " + string(_worst));
        if (_SZ[_s][2] > 0) bwk_st_assert(_st, _worst >= _SZ[_s][2], _SZ[_s][3] + ": the longest ending label still draws at half size or better: \"" + _longest + "\" at " + string(_worst));
        // the CONTROL, at every size: the box this replaced - the whole plate less the seal, centred at
        // seal_r * 0.9 - DOES overrun the rivet. Without it the checks above could be satisfiable by anything.
        var _oldx = _BE.seal_r * 0.9, _oldw = _G7.pw - _BE.seal_r * 2 - 18;
        bwk_st_assert(_st, _oldx + _oldw / 2 > _BE.rivet_x - _BE.rivet_r, _SZ[_s][3] + ": control - the second bake's label box DOES overrun the rivet, so the check above can fail");
    }

    bwk_st_stage(_st, 8);    // routes, the mark corpus, and the chart staying inside the rect it was given
    var _RT = bwk_routes(_g), _wellformed = true, _norepeat = true;
    for (var _i = 0; _i < array_length(_RT); _i++) {
        var _rt = _RT[_i];
        if (_rt[0] != "wake" || bwk_node(_g, _rt[array_length(_rt) - 1]).kind != "ending") _wellformed = false;
        for (var _a = 0; _a < array_length(_rt); _a++) for (var _b = _a + 1; _b < array_length(_rt); _b++) if (_rt[_a] == _rt[_b]) _norepeat = false;
    }
    bwk_st_note(_st, "the demo story has " + string(array_length(_RT)) + " routes; The Hollow Road has " + string(array_length(bwk_routes(bwk_create(bwk_demo_long_graph())))));
    bwk_st_assert(_st, array_length(_RT) >= 6 && _wellformed && _norepeat, "every route runs from the first node to an ending and enters no node twice: " + string(array_length(_RT)) + " routes");
    bwk_st_assert(_st, array_length(bwk_routes(undefined)) == 0 && array_length(bwk_routes(_g, 1)) == 1 && array_length(bwk_routes(_g, "x")) >= 6, "bwk_routes refuses a non-state, honours a limit and falls back on a bad one");
    bwk_st_assert(_st, bwk_route_taken(_r, ["wake", "leave"]) && !bwk_route_taken(_r, ["wake", "stay", "conductor"]) && !bwk_route_taken(_r, []), "bwk_route_taken matches this run's path from its start");
    // the VOLUME claim the listing makes, counted rather than asserted in prose (master §1.1: 40+ entities)
    var _MK = bwk_demo_marks(48), _keys = {}, _dup = 0;
    for (var _i = 0; _i < array_length(_MK); _i++) {
        var _e8 = _MK[_i].emblem, _k8 = string(_e8.family) + "/" + string(_e8.motif) + "/" + string(_e8.ring) + "/" + string(_e8.palette) + "/" + string(_e8.orbits);
        if (variable_struct_exists(_keys, _k8)) _dup++; else _keys[$ _k8] = true;
    }
    bwk_st_note(_st, "the corpus sheet draws " + string(array_length(_MK)) + " marks, " + string(array_length(variable_struct_get_names(_keys))) + " of them distinct");
    bwk_st_assert(_st, array_length(_MK) >= 48 && _dup == 0, "48 pairwise-distinct marks from one story: " + string(array_length(_MK)) + " drawn, " + string(_dup) + " duplicates");
    // ⛔ The marks were 48 and distinct on the first bake AND every caption read "6 STEPS 2 CHOICES", because a
    // strictly layered story gives every route the same shape - so the ring index, which is derived from those
    // two numbers, was the same on all 48 too. Distinctness of the KEY does not imply variety of the JOURNEY:
    // count how many different journeys and how many different rings the corpus actually contains.
    var _jour = {}, _rings = {};
    for (var _i = 0; _i < array_length(_MK); _i++) { _jour[$ string(_MK[_i].steps) + ":" + string(_MK[_i].decisions)] = true; _rings[$ string(_MK[_i].emblem.ring)] = true; }
    var _nj = array_length(variable_struct_get_names(_jour)), _nr2 = array_length(variable_struct_get_names(_rings));
    bwk_st_note(_st, "the corpus spans " + string(_nj) + " distinct journeys (steps:choices) and " + string(_nr2) + " of the 6 ring styles");
    bwk_st_assert(_st, _nj >= 3 && _nr2 >= 3, "the corpus must vary in journey and in ring, not only in key: journeys " + string(_nj) + ", rings " + string(_nr2));
    // the control: the routes OUTNUMBER the marks, so the dedupe genuinely had to reject collisions
    bwk_st_assert(_st, array_length(bwk_routes(bwk_create(bwk_demo_long_graph()))) > array_length(_MK), "control: there are more routes than marks, so distinctness was not free");
    // containment - a public draw call that takes a rect must stay inside it, at every size
    var _outside = 0;
    for (var _s = 0; _s < array_length(_SZ); _s++) {
        var _Lc = bwk_layout(_r), _Gc = bwk_chart_geometry(_Lc, 0, 0, _SZ[_s][0], _SZ[_s][1]);
        for (var _i = 0; _i < array_length(_Lc.nodes); _i++) {
            var _nc = _Lc.nodes[_i], _pc = bwk_chart_node_xy(_Gc, _nc), _Bc = bwk_chart_plate_box(_Gc, _nc.kind);
            var _l8 = _pc[0] - _Gc.pw / 2 - _Bc.seal_r - 12, _r8 = _pc[0] + _Gc.pw / 2 + 12, _t8 = _pc[1] - _Gc.ph / 2 - 12, _b8 = _pc[1] + _Gc.ph / 2 + 12;
            if (_l8 < 0 || _r8 > _SZ[_s][0] || _t8 < 0 || _b8 > _SZ[_s][1]) _outside++;
        }
    }
    bwk_st_assert(_st, _outside == 0, "every plate, seal and halo stays inside the rect the chart was given, at all three sizes: " + string(_outside) + " outside");

    bwk_st_stage(_st, 99);
    return _st;
}

function bwk_selftest_write(_st) {
    var _f = file_text_open_write("bwk_selftest.json");
    file_text_write_string(_f, "{\"total\":" + string(_st.total) + ",\"pass\":" + string(_st.pass) + ",\"fail\":" + string(_st.fail) + ",\"stage\":" + string(_st.stage) + ",\"notes\":[");
    for (var _i = 0; _i < array_length(_st.notes); _i++) { if (_i > 0) file_text_write_string(_f, ","); file_text_write_string(_f, "\"" + string_replace_all(_st.notes[_i], "\"", "'") + "\""); }
    file_text_write_string(_f, "],\"failures\":[");
    for (var _i = 0; _i < array_length(_st.failures); _i++) { if (_i > 0) file_text_write_string(_f, ","); file_text_write_string(_f, "\"" + string_replace_all(_st.failures[_i], "\"", "'") + "\""); }
    file_text_write_string(_f, "]}");
    file_text_close(_f);
}
