/// bwk_demo.gml - two sample stories and the playable demo. "The Last Train" is fourteen nodes over five
/// chapters, three decisions, two converging routes and four endings (one secret). "The Hollow Road" is the
/// larger one, with an early ending and a shortcut, and it is what the mark corpus is drawn from.
///
/// Branchwork - A Story Flowchart the Game Draws, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory.
/// The demo's whole screen - chart and bar - is drawn from this package's own plate, rivet and emblem code.

/// @function bwk_demo_graph()
/// @description The demo story as bwk_create takes it: an array of node structs. Pure.
function bwk_demo_graph() {
    return [
        { id: "wake", label: "The Last Train", act: 0, kind: "event" },
        { id: "stay", label: "Stay Aboard", act: 1, kind: "decision", from: ["wake"] },
        { id: "leave", label: "Step Off", act: 1, kind: "decision", from: ["wake"] },
        { id: "conductor", label: "The Conductor", act: 2, kind: "event", from: ["stay"] },
        { id: "platform", label: "An Empty Platform", act: 2, kind: "event", from: ["leave"] },
        { id: "letter", label: "The Unsent Letter", act: 2, kind: "event", from: ["stay", "leave"] },
        { id: "bargain", label: "Strike a Bargain", act: 3, kind: "decision", from: ["conductor", "letter"] },
        { id: "refuse", label: "Refuse", act: 3, kind: "decision", from: ["conductor"] },
        { id: "walk", label: "Walk the Line", act: 3, kind: "event", from: ["platform", "letter"] },
        { id: "home", label: "Home Before Dawn", act: 4, kind: "ending", from: ["bargain"], tone: "dawn" },
        { id: "terminus", label: "Terminus", act: 4, kind: "ending", from: ["refuse"], tone: "ash" },
        { id: "tide", label: "Where the Rails Go Under", act: 4, kind: "ending", from: ["walk"], tone: "tide" },
        { id: "stationmaster", label: "The Stationmaster", act: 4, kind: "ending", from: ["walk", "bargain"], tone: "crown", secret: true },
        { id: "junction", label: "The Junction", act: 3, kind: "event", from: ["platform"] }
    ];
}

/// @function bwk_demo_long_graph()
/// @description A second, larger sample story - "The Hollow Road", over six chapters, with an early ending, a
/// shortcut past a chapter and three tiers of decision, so routes differ in LENGTH and in how many choices they
/// cost. For authors who want to see the chart and the marks at real story size. Every route through it earns its
/// own emblem; `bwk_routes` enumerates them. Pure.
function bwk_demo_long_graph() {
    return [
        { id: "road", label: "The Hollow Road", act: 0, kind: "event" },
        { id: "lantern", label: "Light the Lantern", act: 1, kind: "decision", from: ["road"] },
        { id: "dark", label: "Walk in the Dark", act: 1, kind: "decision", from: ["road"] },
        { id: "turn", label: "Turn Back", act: 1, kind: "decision", from: ["road"] },
        { id: "mire", label: "The Mire", act: 2, kind: "event", from: ["lantern", "dark"] },
        { id: "chapel", label: "The Roadside Chapel", act: 2, kind: "event", from: ["lantern", "turn"] },
        { id: "crows", label: "A Parliament of Crows", act: 2, kind: "event", from: ["dark", "turn"] },
        { id: "inn", label: "The Sign of the Ox", act: 2, kind: "event", from: ["lantern", "dark"] },
        { id: "shrine", label: "The Wayside Shrine", act: 2, kind: "event", from: ["turn"] },
        // ⛔ A story whose chapters are a strict ladder gives EVERY route the same length and the same number of
        // choices, so every mark takes the same ring and every caption reads alike. An early ending and a
        // shortcut past a chapter are what make the corpus vary - the marks are only as varied as the ROUTES.
        { id: "lost", label: "Lost on the Moor", act: 3, kind: "ending", from: ["mire", "crows"], tone: "ash" },
        { id: "bargain2", label: "Strike the Bargain", act: 3, kind: "decision", from: ["mire", "chapel", "inn"] },
        { id: "refuse2", label: "Refuse the Offer", act: 3, kind: "decision", from: ["chapel", "crows"] },
        { id: "follow", label: "Follow the Lights", act: 3, kind: "decision", from: ["mire", "crows", "inn"] },
        { id: "bridge", label: "The Broken Bridge", act: 4, kind: "event", from: ["bargain2", "follow", "shrine"] },
        { id: "ford", label: "The Ford", act: 4, kind: "event", from: ["refuse2", "follow", "shrine"] },
        { id: "vigil", label: "The Long Vigil", act: 4, kind: "decision", from: ["bargain2", "refuse2"] },
        { id: "dawnroad", label: "The Road at Dawn", act: 5, kind: "ending", from: ["bridge", "ford"], tone: "dawn" },
        { id: "ashfall", label: "Ashfall", act: 5, kind: "ending", from: ["vigil", "bridge"], tone: "ash" },
        { id: "tidewrack", label: "The Tide Comes In", act: 5, kind: "ending", from: ["ford"], tone: "tide" },
        { id: "thornking", label: "The Thorn King", act: 5, kind: "ending", from: ["vigil", "ford"], tone: "thorn" },
        { id: "emberhall", label: "The Ember Hall", act: 5, kind: "ending", from: ["bridge", "vigil"], tone: "ember" },
        { id: "crownless", label: "Crownless", act: 5, kind: "ending", from: ["vigil"], tone: "crown", secret: true }
    ];
}

/// @function bwk_demo_marks(limit)
/// @description The distinct emblems "The Hollow Road" can earn, one per distinct route, in route order:
/// [{ emblem, label, steps, decisions }]. What the corpus sheet draws, and what the suite counts. Pure.
function bwk_demo_marks(_limit) {
    _limit = clamp(floor(bwk_num(_limit, 48)), 1, 512);
    var _st = bwk_create(bwk_demo_long_graph()), _R = bwk_routes(_st), _seen = {}, _out = [];
    // ⛔ SAMPLED ACROSS the route list, not taken from the front of it. A depth-first enumeration walks one
    // subtree to the bottom before it touches the next, so the first 48 routes all came from under one opening
    // choice and the sheet showed 48 marks off a single branch of the story.
    var _n = array_length(_R), _stride = max(1, floor(_n / max(1, _limit)));
    for (var _pass = 0; _pass < 2 && array_length(_out) < _limit; _pass++) {
        for (var _i = 0; _i < _n && array_length(_out) < _limit; _i++) {
            if (_pass == 0 && (_i mod _stride) != 0) continue;
            var _route = _R[_i], _end = _route[array_length(_route) - 1], _em = bwk_emblem(_st, _route, _end);
            var _key = string(_em.family) + "/" + string(_em.motif) + "/" + string(_em.ring) + "/" + string(_em.palette) + "/" + string(_em.orbits);
            if (variable_struct_exists(_seen, _key)) continue;
            _seen[$ _key] = true;
            array_push(_out, { emblem: _em, label: bwk_emblem_families()[_em.family], steps: _em.steps, decisions: _em.decisions });
        }
    }
    return _out;
}

/// @function bwk_demo_state()
/// @description A fresh demo: the graph built and the player standing at the first node.
function bwk_demo_state() {
    var _d = { route: bwk_create(bwk_demo_graph()), style: "brass", note: "1 2 3 choose   J jump back   R new run   S style" };
    bwk_reach(_d.route, "wake");
    bwk_jump_store(_d.route, "wake", "save@wake");
    return _d;
}

/// @function bwk_demo_choices(demo)
/// @description The nodes reachable from where the player stands: every node whose `from` includes it. Pure.
function bwk_demo_choices(_d) {
    // every public entry point refuses what it cannot use: a field read on a non-struct resolves against the
    // CALLING INSTANCE in GML and surfaces as "Variable obj_theirs.route not set" inside the buyer's own object
    if (!is_struct(_d) || !bwk_is_state(_d[$ "route"])) return [];
    var _cur = bwk_current_node(_d.route), _out = [];
    for (var _i = 0; _i < array_length(_d.route.nodes); _i++) { var _n = _d.route.nodes[_i]; for (var _j = 0; _j < array_length(_n.from); _j++) if (_n.from[_j] == _cur) array_push(_out, _n.id); }
    return _out;
}

/// @function bwk_demo_choose(demo, index)
/// @description Take choice `index` (0-based); endings are collected. Returns the id taken, or "".
function bwk_demo_choose(_d, _k) {
    if (!is_struct(_d) || !bwk_is_state(_d[$ "route"])) return "";
    _k = floor(bwk_num(_k, -1));
    var _C = bwk_demo_choices(_d);
    if (_k < 0 || _k >= array_length(_C)) return "";
    var _id = _C[_k], _n = bwk_node(_d.route, _id);
    if (_n.kind == "ending") bwk_reach_ending(_d.route, _id); else bwk_reach(_d.route, _id);
    if (_n.kind == "decision") bwk_jump_store(_d.route, _id, "save@" + _id);
    return _id;
}

/// @function bwk__keycap(x, y, size, key, style)
/// @description A struck key cap: the plate's metal, a lit upper-left edge, the key letter engraved. Internal.
function bwk__keycap(_x, _y, _s, _k, _S) {
    draw_set_colour(_S.plate_lo); draw_roundrect_ext(_x - _s, _y - _s, _x + _s, _y + _s, 4, 4, false);
    draw_set_colour(_S.plate); draw_roundrect_ext(_x - _s + 2, _y - _s + 2, _x + _s - 2, _y + _s - 2, 3, 3, false);
    draw_set_colour(_S.plate_hi); draw_line_width(_x - _s + 3, _y - _s + 2, _x + _s - 4, _y - _s + 2, 1.5);
    draw_set_font(fnt_branchwork_title);
    bwk__text_fit(_x, _y, _k, _s * 1.5, 0.62, _S.engrave, 1);
}

/// @function bwk_demo_draw(demo, width, height)
/// @description The demo: the chart above, and below it a STRUCK BAR - the endings collected as their own
/// medallions (a blank for one not yet earned), the choices as key caps on small plates, and the controls. The bar
/// is drawn from the same plate, rivet and emblem vocabulary as the chart, so nothing on screen is engine default.
function bwk_demo_draw(_d, _w, _h) {
    if (!is_struct(_d) || !bwk_is_state(_d[$ "route"])) return false;
    _w = bwk_num(_w, 0); _h = bwk_num(_h, 0);
    if (_w < 320 || _h < 260) return false;
    var _S = bwk_chart_style(_d[$ "style"]), _bar = 136, _top = _h - _bar;
    draw_clear(_S.board_edge);
    bwk_chart_draw(_d.route, 0, 0, _w, _top, _d.style);
    // the bar: its own ground, a lit lip along the top, a shadow under it
    draw_rectangle_colour(0, _top, _w, _h, merge_colour(_S.board, _S.board_edge, 0.55), merge_colour(_S.board, _S.board_edge, 0.55), _S.board_edge, _S.board_edge, false);
    draw_set_colour(_S.plate_lo); draw_line_width(0, _top + 1, _w, _top + 1, 2);
    draw_set_colour(merge_colour(_S.plate_hi, _S.board, 0.35)); draw_line_width(0, _top + 3, _w, _top + 3, 1);
    // the endings collected, each as the mark its route earned; a blank for one still to find.
    // ⛔ These headings are drawn LEFT-ALIGNED. bwk__text_fit centres on the x it is given, so "ENDINGS" at x=24
    // hung half of itself off the left edge of the screen and read "NDINGS" in the first GIF.
    draw_set_font(fnt_branchwork_title); draw_set_halign(fa_left); draw_set_valign(fa_middle);
    draw_set_colour(merge_colour(_S.line, _S.gold, 0.5)); draw_text_transformed(24, _top + 26, "ENDINGS", 0.58, 0.58, 0);
    draw_set_halign(fa_left); draw_set_valign(fa_top);
    var _total = bwk_ending_total(_d.route), _r = 21, _ex = 30;
    for (var _i = 0; _i < _total; _i++) {
        var _nid = "", _seen = 0;
        for (var _j = 0; _j < array_length(_d.route.nodes); _j++) if (_d.route.nodes[_j].kind == "ending") { if (_seen == _i) { _nid = _d.route.nodes[_j].id; break; } _seen++; }
        var _end = bwk_ending(_d.route, _nid), _cx = _ex + _i * (_r * 2 + 12) + _r;
        if (is_struct(_end)) bwk_draw_emblem(_cx, _top + 78, _r, _end.emblem);
        else {
            // the same struck blank the chart uses, so a tally slot reads as an unearned medal and not a hole
            var _bl = merge_colour(_S.board, _S.plate_lo, 0.75), _bh = merge_colour(_S.board, _S.plate, 0.75);
            draw_set_colour(_bl); draw_circle(_cx, _top + 78, _r * 0.88, false);
            draw_primitive_begin(pr_trianglefan); draw_vertex_colour(_cx, _top + 78 - _r * 0.25, merge_colour(_bh, _bl, 0.35), 1);
            for (var _q = 0; _q <= 28; _q++) { var _an = 2 * pi * _q / 28; draw_vertex_colour(_cx + cos(_an) * _r * 0.78, _top + 78 - sin(_an) * _r * 0.78, merge_colour(_bl, _S.board_edge, 0.35), 1); }
            draw_primitive_end();
        }
    }
    // the choices where the player stands, as key caps on plates
    var _C = bwk_demo_choices(_d), _px = _ex + _total * (_r * 2 + 12) + 46, _pw = min(300, _w - _px - 210);
    draw_set_font(fnt_branchwork_title); draw_set_halign(fa_left); draw_set_valign(fa_middle);
    draw_set_colour(merge_colour(_S.line, _S.gold, 0.5)); draw_text_transformed(_px, _top + 26, "FROM HERE", 0.58, 0.58, 0);
    draw_set_halign(fa_left); draw_set_valign(fa_top);
    for (var _i = 0; _i < array_length(_C) && _i < 3; _i++) {
        var _cy = _top + 50 + _i * 28;
        bwk__plate(_px + 14 + _pw / 2, _cy, _pw, 24, 3, _S, 1);
        bwk__keycap(_px + 14, _cy, 11, string(_i + 1), _S);
        draw_set_font(fnt_branchwork);
        bwk__text_fit(_px + 34 + _pw / 2, _cy, bwk_label(_d.route, _C[_i]), _pw - 34, 0.62, _S.engrave, 1);
    }
    if (array_length(_C) == 0) { draw_set_font(fnt_branchwork); bwk__text_fit(_px + 90, _top + 62, "an ending - press R", 200, 0.62, merge_colour(_S.line, _S.gold, 0.4), 1); }
    // the controls
    var _kx = _w - 196, _KEY = [["J", "jump back"], ["R", "new run"], ["S", "style"]];
    for (var _i = 0; _i < 3; _i++) {
        bwk__keycap(_kx, _top + 34 + _i * 30, 11, _KEY[_i][0], _S);
        draw_set_font(fnt_branchwork);
        draw_set_halign(fa_left); draw_set_valign(fa_middle); draw_set_colour(merge_colour(_S.line, _S.gold, 0.45));
        draw_text_transformed(_kx + 20, _top + 34 + _i * 30, _KEY[_i][1], 0.62, 0.62, 0);
        draw_set_halign(fa_left); draw_set_valign(fa_top);
    }
}
