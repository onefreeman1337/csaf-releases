{
  "$GMScript": "v1",
  "%Name": "bwk_core",
  "name": "bwk_core",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}