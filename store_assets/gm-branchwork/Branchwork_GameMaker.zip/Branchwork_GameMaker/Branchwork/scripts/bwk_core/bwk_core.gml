/// bwk_core.gml - the route record: a story's node graph, what the player has reached, the edges travelled, the
/// endings collected, the jump points back to earlier decisions, and the chart's layout.
///
/// Branchwork - A Story Flowchart the Game Draws, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory.
/// Every function in this file is PURE GML: no drawing, no surfaces, no instances, no globals. A port of this
/// factory's RPG Maker MZ plugin Threads (route-flowchart): the same model, re-shaped for GML - the graph is
/// authored as an array of structs, ids live in ARRAYS of records (never as struct keys), and a jump point holds
/// whatever snapshot of THEIR game the buyer hands it, so it works with any save system.

#macro BWK_VERSION 1
#macro BWK_SCHEMA 1
#macro BWK_EMBLEM_FAMILIES 6
#macro BWK_EMBLEM_MOTIFS 8
#macro BWK_EMBLEM_RINGS 6
#macro BWK_EMBLEM_ORBITS 8
#macro BWK_EMBLEM_PALETTES 8

/// @function bwk_num(value, fallback)
/// @description `value` if it is a real number (not NaN), else `fallback`. Pure.
function bwk_num(_v, _def) {
    if (is_real(_v) || is_int32(_v) || is_int64(_v)) { if (_v == _v) return _v; }
    return _def;
}

/// @function bwk_hash(text, [salt])
/// @description A stable non-negative integer from a string: multiply by 48271 modulo 2^31 - 1 per character,
/// so every product stays under 2^53 and is exact in a double. Pure.
function bwk_hash(_s, _salt = 0) {
    if (!is_string(_s)) _s = string(_s);
    var _M = 2147483647, _h = (1234567 + floor(bwk_num(_salt, 0)) * 7919) mod _M;
    if (_h < 0) _h += _M;
    for (var _i = 1; _i <= string_length(_s); _i++) { _h = ((_h ^ ord(string_char_at(_s, _i))) * 48271 + 11) mod _M; if (_h < 0) _h += _M; }
    // avalanche: three more rounds so the low digits of `mod n` do not follow the last character
    repeat (3) { _h = (_h * 48271 + 12345) mod _M; _h = _h ^ (_h >> 13); }
    return _h;
}

/// @function bwk_pick(key, stream, n)
/// @description An independent value in [0, n) from a key and a stream label - different labels give uncorrelated
/// choices from the same route. Pure.
function bwk_pick(_key, _stream, _n) {
    _n = floor(bwk_num(_n, 1));
    if (_n <= 1) return 0;
    return bwk_hash(string(_key) + "|" + string(_stream)) mod _n;
}

/// @function bwk__has(array, value)
/// @description Whether an array of strings contains a value. Internal.
function bwk__has(_a, _v) {
    if (!is_array(_a) || !is_string(_v)) return false;
    for (var _i = 0; _i < array_length(_a); _i++) if (is_string(_a[_i]) && _a[_i] == _v) return true;
    return false;
}

/// @function bwk__find(list, id)
/// @description Index of the record whose `id` equals `id`, or -1. Ids are strings; records must be structs. Internal.
function bwk__find(_l, _id) {
    if (!is_array(_l) || !is_string(_id)) return -1;
    for (var _i = 0; _i < array_length(_l); _i++) if (is_struct(_l[_i]) && is_string(_l[_i][$ "id"]) && _l[_i].id == _id) return _i;
    return -1;
}

/// @function bwk__split(value)
/// @description `from` as an array of trimmed ids: an array of strings, or one comma-separated string. Internal.
function bwk__split(_v) {
    var _out = [];
    if (is_array(_v)) { for (var _i = 0; _i < array_length(_v); _i++) if (is_string(_v[_i]) && string_trim(_v[_i]) != "") array_push(_out, string_trim(_v[_i])); return _out; }
    if (!is_string(_v)) return _out;
    var _parts = string_split(_v, ",");
    for (var _i = 0; _i < array_length(_parts); _i++) { var _t = string_trim(_parts[_i]); if (_t != "") array_push(_out, _t); }
    return _out;
}

/// @function bwk__new_record()
/// @description A fresh, empty run record - the part that is saved. Internal.
function bwk__new_record() {
    return { v: BWK_SCHEMA, reached: [], edges: [], path: [], endings: [], jumps: [] };
}

/// @function bwk_create(nodes, [options])
/// @description A route state from an array of node structs:
///   { id, label, act, kind: "event" | "decision" | "ending", from: ["id", ...] or "a,b", tone, secret }
/// `act` is the chart column (chapter); rows follow declaration order. Options (all optional): `secret_label`
/// ("???", shown for an unreached secret node), `max_jumps` (8), `allow_jump` (true). Duplicate ids and links from
/// unknown nodes are kept out and REPORTED in `.problems`, never thrown. Pure.
function bwk_create(_nodes, _o = undefined) {
    if (!is_struct(_o)) _o = {};
    var _cfg = {
        secret_label: is_string(_o[$ "secret_label"]) ? _o.secret_label : "???",
        max_jumps: clamp(floor(bwk_num(_o[$ "max_jumps"], 8)), 1, 64),
        allow_jump: is_bool(_o[$ "allow_jump"]) ? _o.allow_jump : true
    };
    var _st = { version: BWK_VERSION, cfg: _cfg, nodes: [], problems: [], record: bwk__new_record() };
    if (!is_array(_nodes)) { array_push(_st.problems, "nodes is not an array"); return _st; }
    for (var _i = 0; _i < array_length(_nodes); _i++) {
        var _n = _nodes[_i];
        if (!is_struct(_n) || !is_string(_n[$ "id"]) || string_trim(_n.id) == "") { array_push(_st.problems, "node " + string(_i) + " has no id - skipped"); continue; }
        var _id = string_trim(_n.id);
        if (bwk__find(_st.nodes, _id) >= 0) { array_push(_st.problems, "duplicate node id \"" + _id + "\" - the later one was ignored"); continue; }
        var _k = is_string(_n[$ "kind"]) ? _n.kind : "event";
        if (_k != "decision" && _k != "event" && _k != "ending") _k = "event";
        array_push(_st.nodes, { id: _id, label: is_string(_n[$ "label"]) ? _n.label : _id, act: floor(bwk_num(_n[$ "act"], 0)), kind: _k,
            from: bwk__split(_n[$ "from"]), tone: is_string(_n[$ "tone"]) ? _n.tone : "", secret: is_bool(_n[$ "secret"]) ? _n.secret : false });
    }
    for (var _i = 0; _i < array_length(_st.nodes); _i++) {
        var _f = _st.nodes[_i].from;
        for (var _j = array_length(_f) - 1; _j >= 0; _j--) if (bwk__find(_st.nodes, _f[_j]) < 0) { array_push(_st.problems, "node \"" + _st.nodes[_i].id + "\" leads from unknown node \"" + _f[_j] + "\" - link dropped"); array_delete(_f, _j, 1); }
    }
    return _st;
}

/// @function bwk_is_state(value)
/// @description True for a record made by bwk_create. Every public function refuses anything else.
function bwk_is_state(_s) { return is_struct(_s) && is_struct(_s[$ "cfg"]) && is_array(_s[$ "nodes"]) && is_struct(_s[$ "record"]); }

/// @function bwk_node(state, id)
/// @description The node record for an id, or undefined.
function bwk_node(_st, _id) { if (!bwk_is_state(_st)) return undefined; var _i = bwk__find(_st.nodes, _id); return (_i >= 0) ? _st.nodes[_i] : undefined; }

/// @function bwk_problems(state)
/// @description Authoring problems found when the graph was built (duplicate ids, links from unknown nodes).
function bwk_problems(_st) { return bwk_is_state(_st) ? _st.problems : []; }

/// @function bwk_reach(state, id)
/// @description Mark a node reached and record the edge from wherever the player was. Re-reaching the node the
/// player stands on is a no-op, never an error (events fire twice in practice). Returns true if anything changed.
function bwk_reach(_st, _id) {
    if (bwk_node(_st, _id) == undefined) return false;
    var _r = _st.record, _changed = false;
    if (!bwk__has(_r.reached, _id)) { array_push(_r.reached, _id); _changed = true; }
    var _n = array_length(_r.path), _prev = (_n > 0) ? _r.path[_n - 1] : "";
    if (_prev == _id) return _changed;
    if (_prev != "") { var _key = _prev + ">" + _id; if (!bwk__has(_r.edges, _key)) { array_push(_r.edges, _key); _changed = true; } }
    array_push(_r.path, _id);
    return true;
}

/// @function bwk_signature(path, ending_id)
/// @description The ordered route joined - reaching an ending in a different order IS a different route. Pure.
function bwk_signature(_path, _end_id) {
    var _s = "";
    if (is_array(_path)) for (var _i = 0; _i < array_length(_path); _i++) _s += ((_i > 0) ? ">" : "") + string(_path[_i]);
    return _s + "#" + string(_end_id);
}

/// @function bwk_emblem(state, path, ending_id)
/// @description The mark an ending earns on a route, as indices the chart draws: { sig, family, motif, ring,
/// orbits[], palette, decisions, steps }. The FAMILY comes from the ending's declared `tone` when it names one
/// (0..5 or a family name), so the author keeps what an ending FEELS like; the motif is hashed within the family;
/// the RING encodes the journey (its length and how much it branched), so two players reaching one ending by
/// different roads get different marks; one ORBIT per decision on the path, capped at 8. Pure.
function bwk_emblem(_st, _path, _end_id) {
    if (!bwk_is_state(_st) || !is_array(_path)) return undefined;
    var _sig = bwk_signature(_path, _end_id), _node = bwk_node(_st, _end_id), _fam = -1;
    var _names = bwk_emblem_families();
    if (is_struct(_node) && _node.tone != "") for (var _i = 0; _i < array_length(_names); _i++) if (_names[_i] == string_lower(_node.tone)) _fam = _i;
    if (_fam < 0) _fam = bwk_pick(_sig, "family", BWK_EMBLEM_FAMILIES);
    var _dec = [];
    for (var _i = 0; _i < array_length(_path); _i++) { var _n = bwk_node(_st, _path[_i]); if (is_struct(_n) && _n.kind == "decision") array_push(_dec, _n.id); }
    var _orb = [];
    for (var _j = 0; _j < min(array_length(_dec), 8); _j++) array_push(_orb, bwk_pick(_dec[_j], "orbit", BWK_EMBLEM_ORBITS));
    return { sig: _sig, family: _fam, motif: bwk_pick(_sig, "motif", BWK_EMBLEM_MOTIFS), ring: (array_length(_dec) + min(array_length(_path), 12)) mod BWK_EMBLEM_RINGS,
        orbits: _orb, palette: bwk_pick(_sig, "palette", BWK_EMBLEM_PALETTES), decisions: array_length(_dec), steps: array_length(_path) };
}

/// @function bwk_emblem_families()
/// @description The six emblem families, in index order - a node's `tone` may name one. Pure.
function bwk_emblem_families() { return ["dawn", "ember", "tide", "thorn", "crown", "ash"]; }

/// @function bwk_reach_ending(state, id)
/// @description Reach an ending and collect it. The first collection stores its emblem and route and is never
/// overwritten; a later collection by another route counts it and records the route. Returns the ending record
/// { id, emblem, path, count, routes }, or undefined for an unknown id.
function bwk_reach_ending(_st, _id) {
    var _node = bwk_node(_st, _id);
    if (_node == undefined) return undefined;
    bwk_reach(_st, _id);
    var _r = _st.record, _path = array_create(array_length(_r.path));
    array_copy(_path, 0, _r.path, 0, array_length(_r.path));
    var _i = bwk__find(_r.endings, _id);
    if (_i >= 0) {
        var _e = _r.endings[_i], _sig = bwk_signature(_path, _id);
        _e.count += 1;
        if (!bwk__has(_e.routes, _sig)) array_push(_e.routes, _sig);
        return _e;
    }
    var _em = bwk_emblem(_st, _path, _id);
    var _rec = { id: _id, emblem: _em, path: _path, count: 1, routes: [_em.sig] };
    array_push(_r.endings, _rec);
    return _rec;
}

/// @function bwk_reset_path(state)
/// @description Clear the current run's path and keep everything ever reached and collected (New Game+).
function bwk_reset_path(_st) { if (bwk_is_state(_st)) _st.record.path = []; }

/// @function bwk_has_reached(state, id)
function bwk_has_reached(_st, _id) { return bwk_is_state(_st) && bwk__has(_st.record.reached, _id); }

/// @function bwk_has_ending(state, id)
function bwk_has_ending(_st, _id) { return bwk_is_state(_st) && bwk__find(_st.record.endings, _id) >= 0; }

/// @function bwk_ending(state, id)
/// @description The collected ending record for an id, or undefined.
function bwk_ending(_st, _id) { if (!bwk_is_state(_st)) return undefined; var _i = bwk__find(_st.record.endings, _id); return (_i >= 0) ? _st.record.endings[_i] : undefined; }

/// @function bwk_ending_count(state)
function bwk_ending_count(_st) { return bwk_is_state(_st) ? array_length(_st.record.endings) : 0; }

/// @function bwk_ending_total(state)
/// @description How many endings the graph declares.
function bwk_ending_total(_st) {
    if (!bwk_is_state(_st)) return 0;
    var _n = 0;
    for (var _i = 0; _i < array_length(_st.nodes); _i++) if (_st.nodes[_i].kind == "ending") _n++;
    return _n;
}

/// @function bwk_current_path(state)
/// @description A copy of this run's path, oldest first.
function bwk_current_path(_st) {
    if (!bwk_is_state(_st)) return [];
    var _p = _st.record.path, _out = array_create(array_length(_p));
    array_copy(_out, 0, _p, 0, array_length(_p));
    return _out;
}

/// @function bwk_current_node(state)
/// @description The id the player stands on, or "" at the start.
function bwk_current_node(_st) {
    if (!bwk_is_state(_st)) return "";
    var _p = _st.record.path;
    return (array_length(_p) > 0) ? _p[array_length(_p) - 1] : "";
}

/// @function bwk_has_edge(state, from, to)
function bwk_has_edge(_st, _from, _to) { return bwk_is_state(_st) && is_string(_from) && is_string(_to) && bwk__has(_st.record.edges, _from + ">" + _to); }

/// @function bwk_node_state(state, id)
/// @description Which glyph the chart draws for a node: "unseen", "current", "ending", "converge" (more than
/// one way in) or "reached"; "" for an unknown id.
function bwk_node_state(_st, _id) {
    var _n = bwk_node(_st, _id);
    if (_n == undefined) return "";
    if (!bwk_has_reached(_st, _id)) return "unseen";
    if (bwk_current_node(_st) == _id) return "current";
    if (_n.kind == "ending") return "ending";
    if (array_length(_n.from) > 1) return "converge";
    return "reached";
}

/// @function bwk_label(state, id)
/// @description The label to show, honouring `secret` (an unreached secret node shows cfg.secret_label).
function bwk_label(_st, _id) {
    var _n = bwk_node(_st, _id);
    if (_n == undefined) return "";
    if (_n.secret && !bwk_has_reached(_st, _id)) return _st.cfg.secret_label;
    return _n.label;
}

/// @function bwk_layout(state)
/// @description The chart, COMPUTED never authored: columns from `act` (ascending), rows in declaration order.
/// { cols, rows, nodes: [{ id, col, row, rows_in_col, reached, current, state, label, kind }], edges: [{ from, to,
/// travelled, visible, state }] }. An edge is VISIBLE once its source is reached - "there is another way out of
/// here" without saying where it goes. Pure.
function bwk_layout(_st) {
    var _out = { cols: 0, rows: 0, nodes: [], edges: [] };
    if (!bwk_is_state(_st)) return _out;
    var _acts = [];
    for (var _i = 0; _i < array_length(_st.nodes); _i++) { var _a = _st.nodes[_i].act, _seen = false; for (var _j = 0; _j < array_length(_acts); _j++) if (_acts[_j] == _a) _seen = true; if (!_seen) array_push(_acts, _a); }
    array_sort(_acts, true);
    _out.cols = array_length(_acts);
    var _cur = bwk_current_node(_st);
    for (var _c = 0; _c < array_length(_acts); _c++) {
        var _col = [];
        for (var _i = 0; _i < array_length(_st.nodes); _i++) if (_st.nodes[_i].act == _acts[_c]) array_push(_col, _st.nodes[_i]);
        _out.rows = max(_out.rows, array_length(_col));
        for (var _r = 0; _r < array_length(_col); _r++) {
            var _n = _col[_r], _reached = bwk__has(_st.record.reached, _n.id);
            array_push(_out.nodes, { id: _n.id, col: _c, row: _r, rows_in_col: array_length(_col), reached: _reached, current: (_cur == _n.id),
                state: bwk_node_state(_st, _n.id), label: bwk_label(_st, _n.id), kind: _n.kind });
        }
    }
    for (var _i = 0; _i < array_length(_st.nodes); _i++) {
        var _to = _st.nodes[_i];
        for (var _f = 0; _f < array_length(_to.from); _f++) {
            var _fr = _to.from[_f], _tr = bwk__has(_st.record.edges, _fr + ">" + _to.id), _vis = bwk__has(_st.record.reached, _fr);
            array_push(_out.edges, { from: _fr, to: _to.id, travelled: _tr, visible: _vis, state: _tr ? "travelled" : (_vis ? "open" : "hidden") });
        }
    }
    return _out;
}

/// @function bwk_routes(state, [limit], [max_steps])
/// @description EVERY distinct route through the story, as arrays of ids running from the first node to an ending,
/// depth-first in declaration order. This is what a completion screen is made of: how many roads exist, which ones
/// the player has walked, and what each one would earn. A node is never entered twice on one route, so a graph
/// that loops back terminates; `limit` (default 512) and `max_steps` (default 24) bound the search on a large
/// story. Returns [] for anything that is not a state. Pure.
function bwk_routes(_st, _limit = 512, _max = 24) {
    if (!bwk_is_state(_st) || array_length(_st.nodes) == 0) return [];
    _limit = clamp(floor(bwk_num(_limit, 512)), 1, 4096);
    _max = clamp(floor(bwk_num(_max, 24)), 2, 64);
    var _out = [], _stack = [[_st.nodes[0].id]], _guard = 0;
    while (array_length(_stack) > 0 && array_length(_out) < _limit && _guard++ < 200000) {
        var _k = array_length(_stack) - 1, _path = _stack[_k];
        array_delete(_stack, _k, 1);
        var _cur = _path[array_length(_path) - 1], _node = bwk_node(_st, _cur);
        if (!is_struct(_node)) continue;
        if (_node.kind == "ending") { array_push(_out, _path); continue; }
        if (array_length(_path) >= _max) continue;
        var _ch = [];
        for (var _i = 0; _i < array_length(_st.nodes); _i++) { var _n = _st.nodes[_i]; for (var _j = 0; _j < array_length(_n.from); _j++) if (_n.from[_j] == _cur) array_push(_ch, _n.id); }
        // pushed in reverse so the stack pops them in declaration order
        for (var _i = array_length(_ch) - 1; _i >= 0; _i--) {
            if (bwk__has(_path, _ch[_i])) continue;
            var _np = array_create(array_length(_path) + 1);
            array_copy(_np, 0, _path, 0, array_length(_path));
            _np[array_length(_path)] = _ch[_i];
            array_push(_stack, _np);
        }
    }
    return _out;
}

/// @function bwk_route_taken(state, route)
/// @description Whether this run's path has walked a route end to end (every step in order). Pure.
function bwk_route_taken(_st, _route) {
    if (!bwk_is_state(_st) || !is_array(_route) || array_length(_route) == 0) return false;
    var _p = _st.record.path;
    if (array_length(_p) < array_length(_route)) return false;
    for (var _i = 0; _i < array_length(_route); _i++) if (_p[_i] != _route[_i]) return false;
    return true;
}

/// @function bwk_jump_store(state, id, snapshot)
/// @description Keep a snapshot of YOUR game (any value: a save string, a struct) as the way back to a reached
/// node. At most cfg.max_jumps are kept; storing past that recycles the OLDEST (a player who has filled them wants
/// the newest decisions, not an error). Returns true when stored.
function bwk_jump_store(_st, _id, _snap) {
    if (!bwk_has_reached(_st, _id) || is_undefined(_snap)) return false;
    var _J = _st.record.jumps, _i = bwk__find(_J, _id);
    if (_i >= 0) array_delete(_J, _i, 1);
    array_push(_J, { id: _id, snapshot: _snap });
    while (array_length(_J) > _st.cfg.max_jumps) array_delete(_J, 0, 1);
    return true;
}

/// @function bwk_can_jump(state, id)
/// @description Whether the chart should offer a jump back to this node (allowed, reached, snapshot kept).
function bwk_can_jump(_st, _id) { return bwk_is_state(_st) && _st.cfg.allow_jump && bwk_has_reached(_st, _id) && bwk__find(_st.record.jumps, _id) >= 0; }

/// @function bwk_jump(state, id)
/// @description Jump back: cut this run's path back to the node's last visit and return the snapshot you stored
/// there, for YOUR game to restore. Everything reached and collected is kept (the chart is a record of all runs).
/// undefined when no jump is possible.
function bwk_jump(_st, _id) {
    if (!bwk_can_jump(_st, _id)) return undefined;
    var _p = _st.record.path, _k = -1;
    for (var _i = array_length(_p) - 1; _i >= 0; _i--) if (_p[_i] == _id) { _k = _i; break; }
    if (_k >= 0) array_resize(_p, _k + 1); else _st.record.path = [_id];
    return _st.record.jumps[bwk__find(_st.record.jumps, _id)].snapshot;
}

/// @function bwk_save(state)
/// @description The run record as a JSON string (the graph is your authored data, so it is not saved). "" on refusal.
function bwk_save(_st) { if (!bwk_is_state(_st)) return ""; return json_stringify(_st.record); }

/// @function bwk_load(state, json)
/// @description Install a record from bwk_save into a state built from the same graph. Anything unreadable leaves
/// the state untouched and returns false (never a crash); unknown ids in an old save are dropped.
function bwk_load(_st, _s) {
    if (!bwk_is_state(_st) || !is_string(_s) || _s == "") return false;
    var _r = undefined;
    try { _r = json_parse(_s); } catch (_e) { return false; }
    if (!is_struct(_r)) return false;
    var _rec = bwk__new_record(), _ids = ["reached", "path"];
    for (var _q = 0; _q < 2; _q++) { var _src = _r[$ _ids[_q]]; if (is_array(_src)) for (var _i = 0; _i < array_length(_src); _i++) if (bwk_node(_st, _src[_i]) != undefined) array_push(_rec[$ _ids[_q]], _src[_i]); }
    if (is_array(_r[$ "edges"])) for (var _i = 0; _i < array_length(_r.edges); _i++) if (is_string(_r.edges[_i])) array_push(_rec.edges, _r.edges[_i]);
    if (is_array(_r[$ "endings"])) for (var _i = 0; _i < array_length(_r.endings); _i++) { var _e = _r.endings[_i]; if (is_struct(_e) && bwk_node(_st, _e[$ "id"]) != undefined && is_struct(_e[$ "emblem"])) array_push(_rec.endings, _e); }
    if (is_array(_r[$ "jumps"])) for (var _i = 0; _i < array_length(_r.jumps); _i++) { var _j = _r.jumps[_i]; if (is_struct(_j) && bwk_node(_st, _j[$ "id"]) != undefined) array_push(_rec.jumps, _j); }
    _st.record = _rec;
    return true;
}
