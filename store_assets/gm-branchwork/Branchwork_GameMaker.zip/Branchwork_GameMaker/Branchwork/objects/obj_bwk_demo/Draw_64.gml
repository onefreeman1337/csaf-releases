/// @description The demo readout (session 1; the drawn chart replaces it).
if (!is_struct(demo)) exit;
bwk_demo_draw(demo, display_get_gui_width(), display_get_gui_height());
