/// @description Keys: 1-3 take a choice, J jumps back to the last decision with a snapshot, R starts a new run.
if (!is_struct(demo)) exit;
for (var _k = 0; _k < 3; _k++) if (keyboard_check_pressed(ord(string(_k + 1)))) bwk_demo_choose(demo, _k);
if (keyboard_check_pressed(ord("J"))) {
    var _p = bwk_current_path(demo.route);
    for (var _i = array_length(_p) - 2; _i >= 0; _i--) if (bwk_can_jump(demo.route, _p[_i])) { bwk_jump(demo.route, _p[_i]); break; }
}
if (keyboard_check_pressed(ord("R"))) { bwk_reset_path(demo.route); bwk_reach(demo.route, "wake"); }
if (keyboard_check_pressed(ord("S"))) {
    var _ST = bwk_chart_styles(), _k = 0;
    for (var _i = 0; _i < array_length(_ST); _i++) if (_ST[_i] == demo.style) _k = _i;
    demo.style = _ST[(_k + 1) mod array_length(_ST)];
}
