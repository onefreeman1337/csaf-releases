/// @description Branchwork demo - and the headless entry point (-selftest).
/// ⛔ The crash handler is installed first; every variable a later event reads is declared above the early exits.
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("bwk_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.bwk_stage) + ": " + string(_ex.message) + " | " + string(_ex.stacktrace));
    file_text_close(_f);
    game_end();
});
global.bwk_stage = 0;
demo = undefined;
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";
if (string_pos("-selftest", _args) > 0) { global.bwk_stage = 1; bwk_selftest_write(bwk_selftest_run()); game_end(); exit; }
if (string_pos("-bake", _args) > 0) { global.bwk_stage = 200; bwk_bake_all(); game_end(); exit; }
if (string_pos("-gif", _args) > 0) { global.bwk_stage = 300; bwk_gif_all(); game_end(); exit; }
demo = bwk_demo_state();
