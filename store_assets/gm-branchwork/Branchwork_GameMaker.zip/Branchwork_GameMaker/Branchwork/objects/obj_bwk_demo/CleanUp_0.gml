/// @description Nothing to free: the route state is plain structs and arrays, and no surface is cached.
demo = undefined;
