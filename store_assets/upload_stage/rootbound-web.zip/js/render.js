/**
 * render.js — ROOTBOUND's whole picture: the garden, the panels and every screen.
 *
 * ⛔ IT DRAWS THROUGH `ART.*` (the exported object) SO THE LAYOUT GATE CAN SEE EVERY STRING.
 * Wing §3e-1: a helper that calls a closure-local `text` is invisible to the recorder, and the
 * gate then reports a clean screen while a paragraph runs off the canvas.
 *
 * ⛔ AND IT RETURNS ITS HIT RECTS. Every clickable thing is drawn and hit-tested from the SAME
 * geometry — `LAST_HITS` is filled by the draw and read by input. A second, hand-written table of
 * coordinates is how a button ends up two pixels from where it is painted.
 */
(function (root, factory) {
  const deps = (typeof module !== 'undefined' && module.exports)
    ? { ART: require('./art.js'), SIM: require('./sim.js'), SPECIES: require('./species.js') }
    : { ART: root.ART, SIM: root.SIM, SPECIES: root.SPECIES };
  const api = factory(deps.ART, deps.SIM, deps.SPECIES);
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.RENDER = api;
})(typeof self !== 'undefined' ? self : this, function (ART, SIM, SPECIES) {
  'use strict';

  const VIEW_W = 960, VIEW_H = 600;
  const CELL = 40;
  const GX = 16, GY = 52;                       // garden origin
  const PANEL_X = 664, PANEL_W = 288;
  const LOG_Y = 460;

  const OVERLAYS = [
    { id: 'none', name: 'Plants', key: 'baseNone' },
    { id: 'light', name: 'Light', field: 'light', lo: '#101820', hi: '#f2e4a8' },
    { id: 'moisture', name: 'Water', field: 'moisture', lo: '#3a3226', hi: '#4f8fb5' },
    { id: 'ph', name: 'Soil pH', field: 'ph', lo: '#8a5a2a', hi: '#b9b2d6' },
    { id: 'nutrient', name: 'Feed', field: 'nutrient', lo: '#2c2a22', hi: '#7fae4e' },
  ];

  /** Rects the last draw produced. Input reads THIS, never its own copy. */
  let LAST_HITS = [];
  const hit = (r) => { if (r) LAST_HITS.push(r); return r; };
  const hits = () => LAST_HITS;

  const cellRect = (x, y) => ({ x: GX + x * CELL, y: GY + y * CELL, w: CELL, h: CELL });

  function mix(a, b, t) {
    const p = (h) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
    const A = p(a), B = p(b);
    const c = A.map((v, i) => Math.round(v + (B[i] - v) * Math.max(0, Math.min(1, t))));
    return 'rgb(' + c[0] + ',' + c[1] + ',' + c[2] + ')';
  }

  /* ── the garden ────────────────────────────────────────────────────────────────────────── */

  function drawGarden(ctx, s, ui) {
    const ov = OVERLAYS.find((o) => o.id === ui.overlay) || OVERLAYS[0];

    /* ground first, as one continuous tiled surface — tiling per cell would show the cell grid
     * as a texture seam, which is not the same thing as a readable grid line. */
    for (const c of s.cells) {
      const r = cellRect(c.x, c.y);
      if (c.kind === 'wall') { ART.tile('plate_wall', r.x, r.y, r.w, r.h); continue; }
      ART.tile(c.kind === 'bed' ? 'plate_bed' : 'plate_rough', r.x, r.y, r.w, r.h);
      if (!SIM.owned(s, c.x, c.y)) {
        /* ⛔ THIS WAS rgba(8,10,8,0.62) AND IT TURNED TWO THIRDS OF THE GARDEN INTO A BLACK VOID.
         * At day 0 only one plot of three is owned, so the very first thing a new player sees was
         * a small lit strip beside a hole — which reads as a broken game rather than as land you
         * have not opened yet. Lighter, and cooled rather than blackened, so it reads as ground
         * under a haze. Found by opening the first screenshot of the real game. */
        ctx.fillStyle = 'rgba(16,22,26,0.42)';
        ctx.fillRect(r.x, r.y, r.w, r.h);
        /* a quiet hatch, so "not yours yet" is a STATE rather than just a darker tile */
        ctx.strokeStyle = 'rgba(90,110,120,0.10)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(r.x, r.y + r.h); ctx.lineTo(r.x + r.w, r.y);
        ctx.stroke();
      }
    }

    /* SHADE, drawn as actual darkness on the ground. This is the game's central mechanic and it
     * must be VISIBLE without opening an overlay — a player should see the shadow creep. */
    for (const c of s.cells) {
      if (c.kind === 'wall') continue;
      const dark = 1 - c.light;
      if (dark > 0.03) {
        const r = cellRect(c.x, c.y);
        ctx.fillStyle = 'rgba(10,18,14,' + (dark * 0.62).toFixed(3) + ')';
        ctx.fillRect(r.x, r.y, r.w, r.h);
      }
    }

    /* A data overlay, when asked for.
     *
     * ⛔ THE VALUE IS STRETCHED ACROSS THE RANGE ACTUALLY PRESENT, not shown on an absolute 0..1
     * scale. An independent review measured MOISTURE as having the WIDEST spread of the four axes
     * (0.760 against light's 0.420) and rendering as a FLAT WASH, while light — with the narrower
     * spread — was instantly readable. The cause is that light happens to occupy most of its 0..1
     * scale while moisture sits in a band in the middle, so a fixed ramp spent most of its colour
     * range on values no cell has. Stretching to the observed min..max means every overlay uses its
     * whole ramp and the player can always SEE which corner is wettest, which is the entire point
     * of the control. The store page sells four overlays, so three of them being unreadable was
     * selling something the game did not do.
     * ⚠️ A floor on the range stops a genuinely uniform field being amplified into noise. */
    if (ov.field) {
      let lo = Infinity, hi = -Infinity;
      for (const c of s.cells) {
        if (c.kind === 'wall') continue;
        const v = c[ov.field];
        if (v < lo) lo = v;
        if (v > hi) hi = v;
      }
      const span = Math.max(0.12, hi - lo);       // never stretch a flat field into false detail
      for (const c of s.cells) {
        if (c.kind === 'wall') continue;
        const r = cellRect(c.x, c.y);
        const t = Math.max(0, Math.min(1, (c[ov.field] - lo) / span));
        ctx.fillStyle = mix(ov.lo, ov.hi, t);
        ctx.globalAlpha = 0.82;
        ctx.fillRect(r.x, r.y, r.w, r.h);
        ctx.globalAlpha = 1;
      }
      /* say what the two ends mean, so a stretched scale is not a lie by omission */
      const legend = ov.id === 'light' ? 'dark = shaded   pale = open sun'
        : ov.id === 'moisture' ? 'brown = driest here   blue = wettest here'
        : ov.id === 'ph' ? 'brown = most acid here   violet = most limy here'
        : 'dark = poorest here   green = richest here';
      ctx.fillStyle = 'rgba(10,13,11,0.78)';
      ctx.fillRect(GX, GY, 320, 18);
      ART.text(legend, GX + 6, GY + 13, { font: ART.FONT_TINY, colour: ART.C.pap1 });
    }

    /* grid lines, quiet */
    ctx.strokeStyle = 'rgba(0,0,0,0.22)';
    ctx.lineWidth = 1;
    for (let x = 1; x < SIM.W; x++) {
      ctx.beginPath(); ctx.moveTo(GX + x * CELL + 0.5, GY); ctx.lineTo(GX + x * CELL + 0.5, GY + SIM.H * CELL); ctx.stroke();
    }
    for (let y = 1; y < SIM.H; y++) {
      ctx.beginPath(); ctx.moveTo(GX, GY + y * CELL + 0.5); ctx.lineTo(GX + SIM.W * CELL, GY + y * CELL + 0.5); ctx.stroke();
    }

    /* PLANTS, painter's order: north first so southern plants overlap them. A birch that
     * overhangs the cell in front of it has to be drawn after it. */
    const order = s.plants.slice().sort((a, b) => a.y - b.y);
    for (const p of order) {
      const sp = SPECIES.BY_ID[p.sp];
      const im = ART.img('plants/' + sp.id + '_' + p.stage);
      const r = cellRect(p.x, p.y);
      const cx = r.x + CELL / 2, cy = r.y + CELL - 4;
      /* contact shadow, so the plant sits ON the ground rather than floating over it */
      ctx.fillStyle = 'rgba(0,0,0,0.34)';
      ctx.beginPath();
      ctx.ellipse(cx, cy + 1, 9 + p.stage * 2.5, 3.5 + p.stage, 0, 0, Math.PI * 2);
      ctx.fill();
      if (im) {
        /* sprites are 88x104 anchored bottom-centre at (44,96); they deliberately overflow the
         * cell so a mature specimen has real presence */
        ctx.save();
        if (p.health < 0.5) ctx.globalAlpha = 0.45 + p.health;    // a sick plant looks sick
        ctx.drawImage(im, Math.round(cx - 44), Math.round(cy - 96));
        ctx.restore();
      }
      if (p.shock > 0) {
        ART.text('!', cx, r.y + 12, { font: ART.FONT_SMALL, colour: '#e8b45a', align: 'center' });
      }
      if (p.health < 0.35) {
        ART.text('▼', cx, r.y + 12, { font: ART.FONT_TINY, colour: ART.C.bad, align: 'center' });
      }
    }

    /* selection + mode cursor */
    if (ui.sel) {
      const r = cellRect(ui.sel.x, ui.sel.y);
      ctx.strokeStyle = ART.C.brass;
      ctx.lineWidth = 2;
      ctx.strokeRect(r.x + 1, r.y + 1, r.w - 2, r.h - 2);
    }
    if (ui.hover && ui.mode !== 'inspect') {
      const r = cellRect(ui.hover.x, ui.hover.y);
      const legal = ui.hoverLegal;
      ctx.strokeStyle = legal ? '#8fd06a' : ART.C.bad;
      ctx.lineWidth = 2;
      ctx.strokeRect(r.x + 1, r.y + 1, r.w - 2, r.h - 2);
    }

    /* the whole grid is one hit target set */
    for (const c of s.cells) {
      if (c.kind === 'wall') continue;
      const r = cellRect(c.x, c.y);
      hit({ x: r.x, y: r.y, w: r.w, h: r.h, kind: 'cell', cx: c.x, cy: c.y });
    }
  }

  /* ── top bar ───────────────────────────────────────────────────────────────────────────── */

  function drawTopBar(ctx, s, ui) {
    ctx.fillStyle = '#15171a';
    ctx.fillRect(0, 0, VIEW_W, GY - 4);
    ART.text('ROOTBOUND', 16, 30, { font: ART.FONT_HEAD, colour: ART.C.brass });

    const season = SPECIES.SEASONS[s.season];
    ART.text(season + ' · year ' + s.year, 170, 30, { font: ART.FONT_BODY, colour: ART.C.pap1 });
    ART.text('day ' + s.day, 300, 30, { font: ART.FONT_SMALL, colour: ART.C.iron });

    ART.text('❀ ' + s.seeds + ' seed', 380, 30, { font: ART.FONT_BODY, colour: ART.C.pap2 });
    ART.text(SIM.TOOLS[s.tool].name, 500, 30, { font: ART.FONT_SMALL, colour: ART.C.pap0 });

    /* herbarium progress, which is the win condition and should always be on screen */
    ART.text(s.herbarium.length + '/' + SPECIES.LIST.length + ' pressed', 660, 30,
      { font: ART.FONT_SMALL, colour: ART.C.good });

    const speeds = [0, 1, 3];
    speeds.forEach((sp, i) => {
      hit(Object.assign(ART.button(sp === 0 ? '▮▮' : sp + '×', 782 + i * 42, 12, 38, 26,
        { active: ui.speed === sp }), { kind: 'speed', speed: sp }));
    });
    hit(Object.assign(ART.button('?', 916, 12, 28, 26, { active: false }), { kind: 'help' }));
  }

  /* ── right panel ───────────────────────────────────────────────────────────────────────── */

  function drawPanel(ctx, s, ui) {
    ART.panel(PANEL_X, GY, PANEL_W, VIEW_H - GY - 16);
    const x = PANEL_X + 12;
    let y = GY + 26;
    const w = PANEL_W - 24;

    const tabs = [['garden', 'Garden'], ['seeds', 'Seed'], ['herb', 'Herbarium']];
    tabs.forEach((t, i) => {
      hit(Object.assign(ART.button(t[1], x + i * (w / 3), GY + 8, w / 3 - 4, 24,
        { active: ui.tab === t[0] }), { kind: 'tab', tab: t[0] }));
    });
    y = GY + 46;

    if (ui.tab === 'garden') y = drawGardenTab(ctx, s, ui, x, y, w);
    else if (ui.tab === 'seeds') y = drawSeedTab(ctx, s, ui, x, y, w);
    else y = drawHerbTab(ctx, s, ui, x, y, w);
  }

  function drawGardenTab(ctx, s, ui, x, y, w) {
    ART.text('SHOVEL', x, y, { font: ART.FONT_SMALL, colour: ART.C.brass });
    y += 8;
    hit(Object.assign(ART.button('Dig a bed', x, y, w / 2 - 3, 26, { active: ui.mode === 'dig' }),
      { kind: 'mode', mode: 'dig' }));
    hit(Object.assign(ART.button('Lift & move', x + w / 2 + 3, y, w / 2 - 3, 26,
      { active: ui.mode === 'move', disabled: false }), { kind: 'mode', mode: 'move' }));
    y += 34;

    /* the tool ladder */
    const next = s.tool + 1;
    if (next < SIM.TOOLS.length) {
      const t = SIM.TOOLS[next];
      const can = s.seeds >= t.cost;
      hit(Object.assign(ART.button('Buy ' + t.name + '  ❀' + t.cost, x, y, w, 26,
        { disabled: !can }), { kind: 'buyTool', tier: next }));
      /* ⚠️ +38 rather than +30: `paragraph`'s y is the first line's BASELINE, so its box reaches
       * one font-size ABOVE that. At +34 the blurb's box started 2px inside the button and the
       * layout gate caught it — invisible by eye, certain in arithmetic (wing §3e-2). */
      y += 38;
      y = ART.paragraph(t.blurb + ' Shock ' + Math.round(SIM.TOOLS[s.tool].shock * 100) + '% → '
        + Math.round(t.shock * 100) + '%.', x, y, w, { font: ART.FONT_TINY, colour: ART.C.iron });
    } else {
      y = ART.paragraph('Every spade in the shed is yours.', x, y + 10, w,
        { font: ART.FONT_TINY, colour: ART.C.iron });
    }
    y += 10;

    ART.text('DIG IN', x, y, { font: ART.FONT_SMALL, colour: ART.C.brass });
    y += 8;
    for (let i = 0; i < SIM.AMENDMENTS.length; i++) {
      const a = SIM.AMENDMENTS[i];
      const can = s.seeds >= a.cost && s.tool >= 1;
      hit(Object.assign(ART.button(a.name + '  ❀' + a.cost, x + (i % 2) * (w / 2 + 3),
        y + Math.floor(i / 2) * 30, w / 2 - 3, 26,
        { active: ui.mode === 'amend' && ui.amend === a.id, disabled: !can }),
      { kind: 'amend', amend: a.id }));
    }
    /* two rows of 26 end at y+56; the baseline must clear that by a full font size */
    y += 72;
    if (s.tool < 1) {
      y = ART.paragraph('Amendments need a Border Spade.', x, y, w,
        { font: ART.FONT_TINY, colour: ART.C.iron });
      y += 4;
    }

    if (s.plotsOwned < SIM.PLOTS.length) {
      const cost = SIM.PLOTS[s.plotsOwned].cost;
      hit(Object.assign(ART.button('Open the next plot  ❀' + cost, x, y, w, 26,
        { disabled: s.seeds < cost }), { kind: 'buyPlot' }));
      y += 34;
    }

    y += 6;
    ART.text('SHOW', x, y, { font: ART.FONT_SMALL, colour: ART.C.brass });
    y += 8;
    OVERLAYS.forEach((o, i) => {
      hit(Object.assign(ART.button(o.name, x + (i % 3) * (w / 3), y + Math.floor(i / 3) * 28,
        w / 3 - 4, 24, { active: ui.overlay === o.id }), { kind: 'overlay', overlay: o.id }));
    });
    return y + 60;
  }

  function drawSeedTab(ctx, s, ui, x, y, w) {
    let yy = y;
    for (const sp of SPECIES.LIST) {
      const unlocked = SIM.isUnlocked(s, sp);
      const pressed = s.herbarium.indexOf(sp.id) >= 0;
      const can = unlocked && s.seeds >= sp.cost;
      const label = unlocked
        ? sp.name + '  ❀' + sp.cost + (pressed ? '  ✓' : '')
        : 'locked · press ' + sp.unlockAt + ' specimens';
      hit(Object.assign(ART.button(label, x, yy, w, 24,
        { active: ui.mode === 'plant' && ui.species === sp.id, disabled: !can }),
      { kind: 'species', species: sp.id }));
      yy += 27;
    }
    yy += 4;
    const sel = ui.species && SPECIES.BY_ID[ui.species];
    if (sel && SIM.isUnlocked(s, sel)) {
      ART.text(sel.latin, x, yy + 8, { font: ART.FONT_TINY, colour: ART.C.iron });
      yy = ART.paragraph(sel.blurb, x, yy + 24, w, { font: ART.FONT_TINY, colour: ART.C.pap0 });
      yy += 6;
      yy = drawNiche(ctx, sel, x, yy, w);
    }
    return yy;
  }

  const AXES = [
    ['light', 'light', 'shade', 'sun'],
    ['moisture', 'water', 'dry', 'wet'],
    ['ph', 'soil', 'acid', 'limy'],
    ['nutrient', 'feed', 'poor', 'rich'],
  ];

  /** The niche bands. This is the game's manual and it has to be legible at a glance. */
  function drawNiche(ctx, sp, x, y, w) {
    let yy = y;
    for (const a of AXES) {
      ART.text(a[1], x, yy + 9, { font: ART.FONT_TINY, colour: ART.C.iron });
      const bx = x + 42, bw = w - 42;
      ctx.fillStyle = '#20221d';
      ctx.fillRect(bx, yy, bw, 10);
      const n = sp.niche[a[0]];
      ctx.fillStyle = 'rgba(143,208,106,0.55)';
      ctx.fillRect(bx + bw * n[0], yy, bw * (n[1] - n[0]), 10);
      ctx.strokeStyle = ART.C.iron;
      ctx.strokeRect(bx + 0.5, yy + 0.5, bw - 1, 9);
      yy += 15;
    }
    return yy;
  }

  function drawHerbTab(ctx, s, ui, x, y, w) {
    let yy = y;
    yy = ART.paragraph('Every plant you bring to flower is pressed here, once, and kept. '
      + 'Twelve finishes the garden.', x, yy, w, { font: ART.FONT_TINY, colour: ART.C.pap0 });
    yy += 8;
    for (const sp of SPECIES.LIST) {
      const got = s.herbarium.indexOf(sp.id) >= 0;
      const im = got ? ART.img('plants/' + sp.id + '_3') : null;
      ART.card(x, yy, w, 30, { fill: got ? 'rgba(40,44,36,0.9)' : 'rgba(20,22,20,0.6)',
        stroke: got ? ART.C.good : '#2a2b26' });
      if (im) ctx.drawImage(im, 44 - 15, 96 - 26, 30, 28, x + 3, yy + 1, 30, 28);
      ART.text(got ? sp.name : '—', x + 40, yy + 20,
        { font: ART.FONT_SMALL, colour: got ? ART.C.pap2 : ART.C.iron });
      if (got) {
        ART.text(SPECIES.SEASONS[sp.flowersIn], x + w - 8, yy + 20,
          { font: ART.FONT_TINY, colour: ART.C.iron, align: 'right' });
      }
      yy += 33;
    }
    return yy;
  }

  /* ── bottom strip: what is under the cursor, and why it is unhappy ─────────────────────── */

  function drawInspector(ctx, s, ui) {
    const x = GX, y = LOG_Y, w = 640, h = VIEW_H - LOG_Y - 16;
    ART.panel(x, y, w, h);
    const c = ui.sel ? SIM.cellAt(s, ui.sel.x, ui.sel.y) : null;

    if (!c) {
      ART.paragraph('Click a square to look at the ground. Everything in this garden is done with '
        + 'the shovel: dig a bed, put a plant in it, or lift one that has stopped being happy '
        + 'where it is.', x + 12, y + 26, w - 24, { font: ART.FONT_SMALL, colour: ART.C.pap0 });
      return;
    }

    const env = SIM.envAt(s, c.x, c.y);
    const p = c.plant;
    if (p) {
      const sp = SPECIES.BY_ID[p.sp];
      ART.text(sp.name, x + 12, y + 24, { font: ART.FONT_HEAD, colour: ART.C.pap2 });
      ART.text(SPECIES.STAGES[p.stage] + ' · ' + sp.latin, x + 12, y + 42,
        { font: ART.FONT_TINY, colour: ART.C.iron });
      const comp = SPECIES.complaint(sp, env);
      ART.text('health', x + 12, y + 66, { font: ART.FONT_TINY, colour: ART.C.iron });
      ART.meter(x + 56, y + 57, 140, 11, p.health,
        p.health > 0.6 ? '#6f9e4a' : p.health > 0.3 ? '#c08f36' : ART.C.bad);
      ART.text(comp ? comp.text : 'thriving here', x + 206, y + 66,
        { font: ART.FONT_SMALL, colour: comp ? ART.C.bad : ART.C.good });
      ART.text('moving it costs ' + Math.round(SIM.shockCost(s, p) * 100) + '% health',
        x + 12, y + 88, { font: ART.FONT_TINY, colour: ART.C.pap0 });
    } else {
      ART.text(c.kind === 'bed' ? 'A dug bed' : 'Rough ground', x + 12, y + 24,
        { font: ART.FONT_HEAD, colour: ART.C.pap2 });
      ART.text(c.kind === 'bed' ? 'ready to plant' : 'dig it before anything will grow here',
        x + 12, y + 42, { font: ART.FONT_TINY, colour: ART.C.iron });
    }

    /* the four numbers, always, as bars — a management sim has to show its state */
    const bx = x + 330;
    AXES.forEach((a, i) => {
      const yy = y + 20 + i * 22;
      ART.text(a[1], bx, yy + 9, { font: ART.FONT_TINY, colour: ART.C.iron });
      ART.meter(bx + 40, yy, 190, 10, env[a[0]], ART.C.pap0,
        p ? SPECIES.BY_ID[p.sp].niche[a[0]] : null);
      /* ONE string, not two. A left-aligned "shade" at x+236 and a right-aligned "sun" at x+270
       * overlapped by a few pixels at this font size — and two labels for one axis was clutter
       * anyway, so the honest fix made the panel better rather than just legal. */
      ART.text(a[2] + ' → ' + a[3], bx + 236, yy + 9, { font: ART.FONT_TINY, colour: ART.C.iron });
    });
  }

  function drawLog(ctx, s) {
    const lines = s.log.slice(-3);
    if (!lines.length) return;
    /* a scrim, because the log sits over the bottom of the garden and was unreadable against
     * soil — visible in the very first GIF frame that was opened */
    ctx.fillStyle = 'rgba(10,13,11,0.72)';
    ctx.fillRect(GX, LOG_Y - 12 - lines.length * 13, 640, lines.length * 13 + 14);
    let yy = LOG_Y - 10;
    for (let i = lines.length - 1; i >= 0; i--) {
      const l = lines[i];
      ART.text(l.text, GX + 4, yy,
        { font: ART.FONT_TINY, colour: l.kind === 'bad' ? ART.C.bad : l.kind === 'good' ? ART.C.good : ART.C.iron });
      yy -= 13;
    }
  }

  /* ── full screens ──────────────────────────────────────────────────────────────────────── */

  /**
   * ⛔ REBUILT. The first title screen was a row of six sprites floating in a black field: about
   * 60% of it was empty, the plants sat on six different baselines because each was drawn at a
   * fixed y regardless of its own height, and the background plate was scrimmed at 72% until it
   * was invisible. Master §1b asks outright whether a composite is more than 20% empty, and this
   * was — it is also the ONE image a browsing player is guaranteed to see.
   * It is now an actual garden: a wall, ground, a row of specimens standing on ONE baseline with
   * real contact shadows, and the birch dominating as it does in play.
   */
  function drawTitle(ctx, ui) {
    const HORIZON = 262, BASE = 468;

    /* dusk sky */
    const g = ctx.createLinearGradient(0, 0, 0, HORIZON);
    g.addColorStop(0, '#171d26');
    g.addColorStop(1, '#2c3038');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, VIEW_W, HORIZON);

    /* the wall behind, then the ground it encloses */
    ART.tile('plate_wall', 0, HORIZON - 46, VIEW_W, 46);
    ctx.fillStyle = 'rgba(10,14,12,0.45)';
    ctx.fillRect(0, HORIZON - 46, VIEW_W, 46);
    ART.tile('plate_bed', 0, HORIZON, VIEW_W, VIEW_H - HORIZON);
    /* THE GROUND IS A BACKDROP, NOT THE SUBJECT. At full brightness across 340px the bed plate's
     * clod lattice read as a ploughed field and pulled the eye off the plants, so it is darkened
     * hard at the back AND the front, leaving a lit band exactly where the specimens stand. */
    const gg = ctx.createLinearGradient(0, HORIZON, 0, VIEW_H);
    gg.addColorStop(0, 'rgba(6,9,7,0.62)');
    gg.addColorStop(0.42, 'rgba(6,9,7,0.18)');
    gg.addColorStop(1, 'rgba(5,7,6,0.86)');
    ctx.fillStyle = gg;
    ctx.fillRect(0, HORIZON, VIEW_W, VIEW_H - HORIZON);

    /**
     * THREE ROWS AT THREE SCALES. One row of same-sized sprites is a sticker sheet; a garden has
     * depth. Nearest-neighbour scaling is safe here because `imageSmoothingEnabled` is false, so
     * the pixels stay crisp instead of turning to mush.
     */
    const plant = (id, x, y, scale, dim) => {
      const im = ART.img('plants/' + id + '_3');
      const sc = scale || 1;
      ctx.fillStyle = 'rgba(0,0,0,' + (0.34 * sc).toFixed(2) + ')';
      ctx.beginPath();
      ctx.ellipse(x, y, 15 * sc, 4.5 * sc, 0, 0, Math.PI * 2);
      ctx.fill();
      if (!im) return;
      ctx.save();
      if (dim) ctx.globalAlpha = dim;
      ctx.drawImage(im, x - 44 * sc, y - 96 * sc, 88 * sc, 104 * sc);
      ctx.restore();
    };
    /* far: small, dimmed, tucked under the wall */
    const far = [['heather', 70], ['thyme', 190], ['rosemary', 330], ['fern', 560],
      ['bluebell', 700], ['heather', 840], ['thyme', 930]];
    /* middle */
    const mid = [['foxglove', 140], ['birch', 300], ['rhubarb', 620], ['ramsons', 880]];
    /* near: full size, the specimens the eye should land on */
    const near = [['lavender', 210], ['sunflower', 400], ['birch', 520], ['hosta', 700], ['fern', 810]];
    for (const [id, x] of far) plant(id, x, BASE - 66, 0.62, 0.7);
    for (const [id, x] of mid) plant(id, x, BASE - 34, 0.82, 0.9);
    for (const [id, x] of near) plant(id, x, BASE, 1.06);

    /* a scrim ONLY behind the type, so the words stay legible without flattening the picture */
    const tg = ctx.createLinearGradient(0, 24, 0, 190);
    tg.addColorStop(0, 'rgba(10,13,11,0.0)');
    tg.addColorStop(0.35, 'rgba(10,13,11,0.55)');
    tg.addColorStop(1, 'rgba(10,13,11,0.0)');
    ctx.fillStyle = tg;
    ctx.fillRect(0, 24, VIEW_W, 166);

    ART.text('ROOTBOUND', VIEW_W / 2, 110, { font: ART.FONT_TITLE, colour: ART.C.pap2, align: 'center' });
    ART.text('Your only enemy is how well the garden grew.', VIEW_W / 2, 144,
      { font: ART.FONT_BODY, colour: ART.C.brass, align: 'center' });

    const bx = VIEW_W / 2 - 90;
    hit(Object.assign(ART.button(ui.hasSave ? 'Continue' : 'Begin', bx, 516, 180, 34,
      { active: true, font: ART.FONT_BODY }), { kind: 'start' }));
    if (ui.hasSave) {
      hit(Object.assign(ART.button('New garden', bx - 96, 516, 88, 34, {}), { kind: 'restart' }));
    }
    hit(Object.assign(ART.button('How it works', bx + 186, 516, 96, 34, {}), { kind: 'help' }));
    ART.text('Free · plays in your browser · Core Systems Asset Factory', VIEW_W / 2, 578,
      { font: ART.FONT_TINY, colour: ART.C.iron, align: 'center' });
  }

  const HELP = [
    ['The shovel is the only verb.',
      'Dig a bed, put a plant in it, or lift a plant and carry it somewhere better. There is '
      + 'nothing else to click. Everything you buy is a better shovel or more ground to use it on.'],
    ['Four things decide whether a plant is happy.',
      'Light, water, soil pH and feed. Every square has its own. Open Light or Water from the '
      + 'Garden tab and you can read the whole plot at a glance; the green band on a plant\'s bars '
      + 'is the range it wants.'],
    ['Your successes are the problem.',
      'A plant that thrives gets big, and a big plant shades, drains and sours the ground around '
      + 'it. The bed you laid out perfectly in spring stops working in August because it worked. '
      + 'A birch will ruin your lavender and make a hosta possible.'],
    ['Moving costs the plant, and it costs more the bigger it got.',
      'So move things while they are small, or buy a kinder spade. A mature tree cannot be lifted '
      + 'with the starting spade at all.'],
    ['Seasons move the shade on their own.',
      'The winter sun is low, so shadows stretch. Each plant flowers in exactly one season, and '
      + 'that is the only time it pays you.'],
    ['Nothing is ever lost.',
      'The first time a plant flowers it is pressed into the herbarium and kept for good, even if '
      + 'that plant later dies. Twelve pressed specimens finishes the garden. The game saves itself '
      + 'every day.'],
  ];

  function drawHelp(ctx) {
    ctx.fillStyle = '#0f1210';
    ctx.fillRect(0, 0, VIEW_W, VIEW_H);
    ART.text('HOW IT WORKS', 40, 52, { font: ART.FONT_HEAD, colour: ART.C.brass });
    let y = 84;
    const colW = 420;
    HELP.forEach((h, i) => {
      const x = i < 3 ? 40 : 500;
      if (i === 3) y = 84;
      ART.text(h[0], x, y, { font: ART.FONT_SMALL, colour: ART.C.pap2 });
      y = ART.paragraph(h[1], x, y + 18, colW, { font: ART.FONT_TINY, colour: ART.C.pap0 });
      y += 16;
    });
    /* ⛔ THE LOWER THIRD OF THIS SCREEN WAS EMPTY BLACK — about 35% of it, against master §1b's
     * own question "is any composite more than 20% empty". Filling it with the CONTROLS fixes two
     * things at once: the dead space, and the fact that the keyboard shortcuts existed in the code
     * and in the downloadable Readme but were written down NOWHERE a browser player could see. */
    ART.text('CONTROLS', 40, 330, { font: ART.FONT_SMALL, colour: ART.C.brass });
    const KEYS = [
      ['mouse', 'everything'], ['space', 'pause'], ['1  3', 'speed'],
      ['D', 'dig a bed'], ['M', 'lift and move'], ['L', 'show the light map'],
      ['W', 'show the water map'], ['H', 'this screen'], ['S', 'sound on and off'],
      ['esc', 'put the tool down'],
    ];
    KEYS.forEach((k, i) => {
      const col = Math.floor(i / 5), row = i % 5;
      const x = 40 + col * 230, y = 356 + row * 22;
      ctx.fillStyle = '#2a2b26';
      ctx.fillRect(x, y - 12, 62, 18);
      ctx.strokeStyle = ART.C.iron;
      ctx.strokeRect(x + 0.5, y - 11.5, 61, 17);
      ART.text(k[0], x + 31, y + 1, { font: ART.FONT_TINY, colour: ART.C.pap2, align: 'center' });
      ART.text(k[1], x + 72, y + 1, { font: ART.FONT_TINY, colour: ART.C.pap0 });
    });

    ART.text('THE TWELVE', 520, 330, { font: ART.FONT_SMALL, colour: ART.C.brass });
    SPECIES.LIST.forEach((sp, i) => {
      const col = i % 6, row = Math.floor(i / 6);
      const x = 556 + col * 68, y = 420 + row * 92;
      const im = ART.img('plants/' + sp.id + '_3');
      /* ⚠️ 0.7 SCALE, and the reason is a defect the layout gate structurally cannot see: at 1:1
       * the mature BIRCH is 83px tall, so its canopy reached up over the name labels of the row
       * above it. The gate compares text to text and text to controls; a sprite is neither, so it
       * reported clean. Found by opening the screenshot — which is why that step is mandatory. */
      const S = 0.7;
      if (im) ctx.drawImage(im, x - 44 * S, y - 96 * S, 88 * S, 104 * S);
      ART.text(sp.name.split(' ').pop(), x, y + 12,
        { font: ART.FONT_TINY, colour: ART.C.pap0, align: 'center' });
    });

    ART.paragraph('Made by Core Systems Asset Factory. Written with AI assistance: code yes, '
      + 'graphics yes and generated by this game\'s own procedural code with no image model '
      + 'involved, sound synthesised by our own tools, text yes.',
    40, 508, 460, { font: ART.FONT_TINY, colour: ART.C.iron });
    hit(Object.assign(ART.button('Back', 40, 556, 120, 26, { active: true }), { kind: 'back' }));
  }

  /**
   * ⛔ THE WIN SCREEN IS A WHOLE SCREEN, NOT AN OVERLAY. It was first drawn as a 90%-opaque scrim
   * over the live play screen, which left every panel label faintly readable UNDER the ending —
   * the layout gate reported "Compost ❀8 >< Bluebell" and it was right: two sentences sharing one
   * baseline is the §3a-1d defect, self-inflicted. It is also just better this way; an ending
   * should not have a shop showing through it.
   */
  function drawWin(ctx, s) {
    ctx.fillStyle = '#0b0e0b';
    ctx.fillRect(0, 0, VIEW_W, VIEW_H);
    ART.text('THE GARDEN IS FINISHED', VIEW_W / 2, 96,
      { font: ART.FONT_HEAD, colour: ART.C.brass, align: 'center' });
    /* ⚠️ With align:'center' every line is centred AT x, so x must be the CENTRE, not the left
     * edge. Passing VIEW_W/2 - 300 put the first line's box at x = -96. */
    ART.paragraph('Twelve specimens pressed. You built the shade that made the last of them '
      + 'possible, and then you moved everything that could not live in it.',
    VIEW_W / 2, 130, 600, { font: ART.FONT_SMALL, colour: ART.C.pap1, align: 'center' });

    SPECIES.LIST.forEach((sp, i) => {
      const im = ART.img('plants/' + sp.id + '_3');
      /* ⚠️ 262, not 210. At 210 the card panels began at y=114 and the two line intro paragraph
       * sat at 130..152, so the sentence ran straight THROUGH the first row of specimens. The
       * layout gate did not see it because a card is a fillRect and the gate compares text to text
       * and text to controls — the same blind spot as the birch on the help screen, in a different
       * place. Both were found by opening the PNG. */
      const x = 90 + (i % 6) * 130, y = 262 + Math.floor(i / 6) * 150;
      ART.card(x - 44, y - 96, 88, 104);
      if (im) ctx.drawImage(im, x - 44, y - 96);
      ART.text(sp.name, x, y + 20, { font: ART.FONT_TINY, colour: ART.C.pap1, align: 'center' });
    });

    ART.text('year ' + s.year + ' · ' + s.day + ' days · ' + s.stats.moved
      + ' transplants · ' + s.stats.died + ' lost', VIEW_W / 2, 550,
    { font: ART.FONT_SMALL, colour: ART.C.iron, align: 'center' });
    hit(Object.assign(ART.button('Keep gardening', VIEW_W / 2 - 80, 562, 160, 26, { active: true }),
      { kind: 'back' }));
  }

  /** A real loading state, rather than a black rectangle while 63 files decode. (§4c) */
  function drawLoading(ctx, t) {
    ctx.fillStyle = '#0f1210';
    ctx.fillRect(0, 0, VIEW_W, VIEW_H);
    ART.text('ROOTBOUND', VIEW_W / 2, VIEW_H / 2 - 20,
      { font: ART.FONT_TITLE, colour: ART.C.pap2, align: 'center' });
    ART.text('turning the ground over', VIEW_W / 2, VIEW_H / 2 + 14,
      { font: ART.FONT_SMALL, colour: ART.C.iron, align: 'center' });
    const w = 240, x = (VIEW_W - w) / 2, y = VIEW_H / 2 + 40;
    ART.meter(x, y, w, 6, Math.max(0.04, t), ART.C.brass);
  }

  /**
   * A short flourish when a specimen is pressed — the one moment the game rewards you, so it
   * gets a mark rather than only a log line. (§4c "hit and feedback juice".)
   * `f` counts 1 -> 0.
   */
  function drawFlourish(ctx, fl) {
    if (!fl || fl.t <= 0) return;
    const r = cellRect(fl.x, fl.y);
    const cx = r.x + CELL / 2, cy = r.y + CELL / 2;
    const k = 1 - fl.t;
    ctx.save();
    ctx.globalAlpha = Math.min(1, fl.t * 1.4);
    ctx.strokeStyle = ART.C.brass;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(cx, cy, 8 + k * 34, 0, Math.PI * 2);
    ctx.stroke();
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2 + k * 1.2;
      const rr = 10 + k * 30;
      ctx.fillStyle = ART.C.pap2;
      ctx.fillRect(cx + Math.cos(a) * rr - 1, cy + Math.sin(a) * rr - 1, 2, 2);
    }
    ctx.restore();
    if (fl.label) {
      ctx.save();
      ctx.globalAlpha = Math.min(1, fl.t * 1.6);
      ART.text(fl.label, cx, r.y - 6 - k * 16,
        { font: ART.FONT_SMALL, colour: ART.C.brass, align: 'center' });
      ctx.restore();
    }
  }

  /** The one entry point. Clears the hit list, draws, and hands the rects back. */
  function draw(ctx, s, ui) {
    LAST_HITS = [];
    ctx.fillStyle = '#0f1210';
    ctx.fillRect(0, 0, VIEW_W, VIEW_H);
    if (ui.screen === 'loading') { drawLoading(ctx, ui.loadT || 0); return LAST_HITS; }
    if (ui.screen === 'title') { drawTitle(ctx, ui); }
    else if (ui.screen === 'help') { drawHelp(ctx); }
    else if (ui.screen === 'win') { drawWin(ctx, s); }
    else {
      drawGarden(ctx, s, ui);
      drawFlourish(ctx, ui.flourish);
      drawTopBar(ctx, s, ui);
      drawPanel(ctx, s, ui);
      drawInspector(ctx, s, ui);
      drawLog(ctx, s);
    }
    /* a short cross-fade between screens, so nothing snaps (§4c "scene transitions") */
    if (ui.fade > 0) {
      ctx.fillStyle = 'rgba(11,14,11,' + Math.min(1, ui.fade).toFixed(3) + ')';
      ctx.fillRect(0, 0, VIEW_W, VIEW_H);
    }
    return LAST_HITS;
  }

  return {
    VIEW_W, VIEW_H, CELL, GX, GY, PANEL_X, PANEL_W, LOG_Y, OVERLAYS, HELP, AXES,
    draw, drawTitle, drawHelp, drawWin, drawGarden, drawPanel, drawInspector, drawTopBar, drawLog,
    drawLoading, drawFlourish,
    cellRect, hits, drawNiche,
  };
});
