/**
 * main.js — boot, the frame loop, input, and the save hook.
 *
 * ⛔ THE PAUSE RETURNS BEFORE draw(). Wing §3c-13: a paused game that keeps painting means a
 * capture harness photographs whatever the loop painted a millisecond later, and a store plate of
 * the wrong screen ships with its own caption on top. A paused game is a still canvas and whoever
 * paused it owns what is on it.
 *
 * ⛔ INPUT HIT-TESTS THE RECTS THE RENDERER RETURNED, never its own copy of the layout. A second
 * table of coordinates is how a control ends up two pixels from where it is painted.
 */
(function (root) {
  'use strict';

  const ART = root.ART, SIM = root.SIM, SPECIES = root.SPECIES,
    RENDER = root.RENDER, AUDIO = root.AUDIO;

  let canvas, ctx, state, ui, lastT = 0, hitRects = [];

  ui = {
    screen: 'loading',      // loading | title | play | help | win
    prevScreen: 'title',
    fade: 0,                // 1 -> 0 cross-fade after any screen change
    loadT: 0,
    flourish: null,         // {x,y,t,label} — the press reward mark
    tab: 'garden',
    mode: 'inspect',        // inspect | dig | plant | move | amend
    species: null,
    amend: null,
    moving: null,           // the plant being carried
    overlay: 'none',
    sel: null,
    hover: null,
    hoverLegal: false,
    speed: 1,
    hasSave: false,
    booted: false,
  };

  /* ── the shovel: one place that decides what a click on a cell does ─────────────────────── */

  function actOnCell(cx, cy) {
    const c = SIM.cellAt(state, cx, cy);
    if (!c || c.kind === 'wall') return;
    ui.sel = { x: cx, y: cy };

    let r = null;
    if (ui.mode === 'dig') {
      r = SIM.dig(state, cx, cy);
      if (r.ok) AUDIO.play('sfx_dig');
    } else if (ui.mode === 'plant' && ui.species) {
      r = SIM.plant(state, ui.species, cx, cy);
      if (r.ok) AUDIO.play('sfx_plant');
    } else if (ui.mode === 'amend' && ui.amend) {
      r = SIM.amend(state, ui.amend, cx, cy);
      if (r.ok) AUDIO.play('sfx_water');
    } else if (ui.mode === 'move') {
      if (!ui.moving) {
        if (c.plant) { ui.moving = c.plant; AUDIO.play('sfx_lift'); return; }
        r = { ok: false, why: 'nothing there to lift' };
      } else {
        r = SIM.move(state, ui.moving, cx, cy);
        if (r.ok) { AUDIO.play('sfx_plant'); ui.moving = null; }
      }
    } else {
      return;                                   // inspect: selecting is the whole action
    }
    if (r && !r.ok) {
      AUDIO.play('sfx_deny', 0.7);
      SIM.log(state, r.why, 'warn');
    }
    if (r && r.ok) save();
  }

  function onHit(h) {
    switch (h.kind) {
      case 'cell': actOnCell(h.cx, h.cy); break;
      case 'speed': ui.speed = h.speed; break;
      case 'tab': ui.tab = h.tab; break;
      case 'overlay': ui.overlay = h.overlay; break;
      case 'mode':
        ui.mode = (ui.mode === h.mode) ? 'inspect' : h.mode;
        ui.moving = null;
        break;
      case 'species':
        if (!SIM.isUnlocked(state, SPECIES.BY_ID[h.species])) { AUDIO.play('sfx_deny', 0.7); break; }
        ui.species = h.species; ui.mode = 'plant'; ui.moving = null;
        break;
      case 'amend': ui.amend = h.amend; ui.mode = 'amend'; ui.moving = null; break;
      case 'buyTool':
        if (SIM.buyTool(state, h.tier).ok) { AUDIO.play('sfx_buy'); save(); }
        else AUDIO.play('sfx_deny', 0.7);
        break;
      case 'buyPlot':
        if (SIM.buyPlot(state).ok) { AUDIO.play('sfx_buy'); save(); }
        else AUDIO.play('sfx_deny', 0.7);
        break;
      case 'start': go('play'); break;
      case 'restart':
        SIM.clearSave();
        state = SIM.newGame(Math.floor(Date.now() / 1000) % 100000);
        go('play'); ui.sel = null; ui.moving = null;
        save();
        break;
      case 'help': ui.prevScreen = ui.screen; go('help'); break;
      case 'back': go(ui.prevScreen === 'help' ? 'play' : (ui.prevScreen || 'play')); break;
      default: break;
    }
  }

  function pointFromEvent(e) {
    const r = canvas.getBoundingClientRect();
    const src = (e.touches && e.touches[0]) || (e.changedTouches && e.changedTouches[0]) || e;
    return {
      x: (src.clientX - r.left) * (RENDER.VIEW_W / r.width),
      y: (src.clientY - r.top) * (RENDER.VIEW_H / r.height),
    };
  }

  function pick(p) {
    /* last drawn wins, so a panel over the garden takes the click rather than the cell under it */
    for (let i = hitRects.length - 1; i >= 0; i--) {
      const h = hitRects[i];
      if (p.x >= h.x && p.y >= h.y && p.x < h.x + h.w && p.y < h.y + h.h) return h;
    }
    return null;
  }

  function onDown(e) {
    e.preventDefault();
    AUDIO.unlock();
    const h = pick(pointFromEvent(e));
    if (h) onHit(h);
  }

  function onMove(e) {
    const p = pointFromEvent(e);
    const h = pick(p);
    ui.hover = (h && h.kind === 'cell') ? { x: h.cx, y: h.cy } : null;
    if (ui.hover) {
      const c = SIM.cellAt(state, ui.hover.x, ui.hover.y);
      const own = SIM.owned(state, ui.hover.x, ui.hover.y);
      if (ui.mode === 'dig') ui.hoverLegal = own && c.kind === 'rough' && !c.plant;
      else if (ui.mode === 'plant') ui.hoverLegal = own && c.kind === 'bed' && !c.plant;
      else if (ui.mode === 'amend') ui.hoverLegal = own && state.tool >= 1;
      else if (ui.mode === 'move') ui.hoverLegal = ui.moving ? (own && c.kind === 'bed' && !c.plant) : !!c.plant;
      else ui.hoverLegal = true;
    }
  }

  function onKey(e) {
    AUDIO.unlock();
    const k = e.key.toLowerCase();
    if (k === 'escape') { ui.mode = 'inspect'; ui.moving = null; }
    else if (k === ' ') { ui.speed = ui.speed === 0 ? 1 : 0; e.preventDefault(); }
    else if (k === '1') ui.speed = 1;
    else if (k === '3') ui.speed = 3;
    else if (k === 'd') ui.mode = ui.mode === 'dig' ? 'inspect' : 'dig';
    else if (k === 'm') ui.mode = ui.mode === 'move' ? 'inspect' : 'move';
    else if (k === 'l') ui.overlay = ui.overlay === 'light' ? 'none' : 'light';
    else if (k === 'w') ui.overlay = ui.overlay === 'moisture' ? 'none' : 'moisture';
    else if (k === 'h') { const back = ui.screen === 'help'; if (!back) ui.prevScreen = ui.screen; go(back ? (ui.prevScreen || 'play') : 'help'); }
    else if (k === 's') AUDIO.setEnabled(!AUDIO.isEnabled());
  }

  function save() { SIM.save(state); ui.hasSave = true; }

  /** Change screen through here, so every transition gets the same fade. */
  function go(screen) {
    if (ui.screen === screen) return;
    ui.screen = screen;
    ui.fade = 0.85;
  }

  function handleEvents(events) {
    for (const ev of events) {
      if (ev.type === 'pressed') {
        AUDIO.play('sfx_press');
        ui.flourish = { x: ev.plant.x, y: ev.plant.y, t: 1, label: ev.species.name + ' pressed' };
      } else if (ev.type === 'died') AUDIO.play('sfx_die');
      else if (ev.type === 'season') AUDIO.play('sfx_season', 0.8);
      else if (ev.type === 'won') { go('win'); ui.speed = 0; AUDIO.play('sfx_bloom'); }
    }
  }

  function frame(t) {
    const dt = Math.min(0.25, (t - lastT) / 1000 || 0);
    lastT = t;
    if (ui.screen === 'loading') {
      ui.loadT = Math.min(0.97, ui.loadT + dt * 0.9);
      if (ui.booted) { ui.loadT = 1; go(state.won ? 'title' : 'title'); }
    } else if (ui.screen === 'play') {
      const before = state.day;
      handleEvents(SIM.advance(state, dt, ui.speed));
      if (state.day !== before) save();
    }
    if (ui.fade > 0) ui.fade = Math.max(0, ui.fade - dt * 2.6);
    if (ui.flourish) {
      ui.flourish.t -= dt * 0.9;
      if (ui.flourish.t <= 0) ui.flourish = null;
    }
    hitRects = RENDER.draw(ctx, state, ui);
    requestAnimationFrame(frame);
  }

  function boot() {
    canvas = document.getElementById('game');
    ctx = canvas.getContext('2d');
    ctx.imageSmoothingEnabled = false;
    ART.init(ctx);

    const loaded = SIM.load();
    state = loaded || SIM.newGame(Math.floor(Date.now() / 1000) % 100000);
    ui.hasSave = !!loaded;
    /* the loading screen owns the first frames; boot() never sets a screen directly */

    const plateNames = ['plate_bed', 'plate_rough', 'plate_path', 'plate_wall'];
    const plantNames = [];
    for (const sp of SPECIES.LIST) {
      for (let st = 0; st < SPECIES.STAGES.length; st++) plantNames.push('plants/' + sp.id + '_' + st);
    }

    Promise.all([ART.load(plateNames.concat(plantNames)), AUDIO.load()]).then((res) => {
      const failed = res[0].filter((r) => !r.ok);
      if (failed.length) {
        /* NAME the missing asset. A silent fallback is how a game ships with no art (§3c-12). */
        console.warn('[ROOTBOUND] assets failed to load:', failed.map((f) => f.name).join(', '));
      }
      root.__ROOTBOUND_READY = {
        images: res[0].length - failed.length, imagesFailed: failed.map((f) => f.name),
        audio: res[1],
      };
      ui.booted = true;
    });

    canvas.addEventListener('mousedown', onDown);
    canvas.addEventListener('touchstart', onDown, { passive: false });
    canvas.addEventListener('mousemove', onMove);
    window.addEventListener('keydown', onKey);
    /* save on the way out, so closing the tab mid-day loses at most part of one day */
    window.addEventListener('pagehide', save);
    window.addEventListener('blur', () => { if (ui.speed > 0) save(); });

    /**
     * THE WING'S STANDARD GATE SURFACE (`Kernel/engines/html5_gate.js`).
     * `elapsed` is REAL simulated time in seconds, derived from the game's own clock — days
     * completed plus the fraction of the current day — so the gate observes the actual simulation
     * advancing rather than a counter that exists to satisfy it. `inputProbe` declares the events
     * that genuinely drive this game and a `read()` the gate can diff across them.
     */
    root.__game = {
      get elapsed() { return (state.day + state.dayFrac) * SIM.DAY_SECONDS; },
      /* begin(): put the game into the state where its clock actually runs. On the title screen
       * nothing advances, so a gate that only read `elapsed` would correctly report a frozen
       * simulation. This starts a real run rather than faking a counter. */
      begin() { go('play'); ui.speed = 3; ui.screen = 'play'; ui.fade = 0; },
      inputProbe: {
        /* ⛔ THE KEY GOES IN `init`, NOT AT THE TOP LEVEL. The gate builds
         * `new KeyboardEvent(e.type, Object.assign({bubbles:true}, e.init))` — a top-level `key`
         * is silently dropped, the event arrives with key "", and the probe then reports "input
         * produced no state change" over perfectly wired handlers. Read the gate, do not guess it. */
        events: [
          { type: 'keydown', init: { key: 'd' } },   // pick up the shovel
          { type: 'keydown', init: { key: 'l' } },   // toggle the light overlay
        ],
        settleMs: 400,
        /* ⛔ AND IT MUST RETURN A NUMBER THAT INCREASES: the gate asserts
         * `typeof during === 'number' && during > before`. A descriptive string can never pass.
         * This counts real UI state changes, so it only moves if the events actually landed. */
        read() {
          return (ui.mode === 'dig' ? 1 : 0)
            + (ui.overlay === 'light' ? 1 : 0)
            + (ui.screen === 'play' ? 1 : 0);
        },
      },
    };

    /* Expose the pieces a harness needs. This is the ONLY reason these are on window: an
     * automated playthrough has to drive the shipped build, not a copy of it. */
    root.__ROOTBOUND = {
      get state() { return state; },
      set state(v) { state = v; },
      get ui() { return ui; },
      act: onHit,
      hits: () => hitRects,
      render: () => { hitRects = RENDER.draw(ctx, state, ui); return hitRects; },
      tick: (days) => { for (let i = 0; i < days; i++) handleEvents(SIM.tickDay(state)); },
      save,
    };

    requestAnimationFrame(frame);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})(typeof self !== 'undefined' ? self : this);
