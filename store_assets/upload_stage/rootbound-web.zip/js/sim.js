/**
 * sim.js — ROOTBOUND's simulation. Pure logic: no canvas, no DOM, no audio.
 *
 * Dual-mode (browser global + CommonJS) so `Internal_Ops/` probes drive THE SHIPPED CODE rather
 * than a copy of it.
 *
 * ── THE ONE IDEA ────────────────────────────────────────────────────────────────────────────
 * A plant that thrives grows big. A big plant shades, drinks and sours the ground around it. So
 * the bed you laid out perfectly stops working BECAUSE IT WORKED. Every system below exists to
 * make that loop turn, and `recompute()` is where it closes: plants edit the environment, the
 * environment decides the plants.
 *
 * ── THE SIX SYSTEMS (the wing's Gate 4 record) ──────────────────────────────────────────────
 *   1 MICROCLIMATE   light / moisture / ph / nutrient, per cell, recomputed every day
 *   2 LIFECYCLE      seed -> seedling -> young -> mature -> flowering, footprint grows with stage
 *   3 COMPETITION    the coupling: shade, moisture draw, leaf litter, feeding
 *   4 SHOCK          transplanting costs health, scaled by how big the plant got
 *   5 SEASONS        four, swinging the sun angle so SHADOWS MOVE on their own
 *   6 HERBARIUM      permanent record, and the win condition
 *
 * ── SOIL HAS MEMORY, AND THAT IS DELIBERATE ─────────────────────────────────────────────────
 * `phShift` and `nutShift` are PERSISTENT per-cell accumulations. A birch does not merely shade
 * its patch while it stands there — it acidifies the ground, and that acidity outlives it. Move
 * the birch and the heather you plant in its place is happy for a reason the player earned.
 * This is what stops the game being a pure placement puzzle with an undo button.
 */
(function (root, factory) {
  const SP = (typeof module !== 'undefined' && module.exports)
    ? require('./species.js')
    : root.SPECIES;
  const api = factory(SP);
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.SIM = api;
})(typeof self !== 'undefined' ? self : this, function (SPECIES) {
  'use strict';

  /* ── constants ─────────────────────────────────────────────────────────────────────────── */
  const W = 16, H = 10;                 // including the wall ring
  const DAY_SECONDS = 3.0;              // one in-game day at 1x speed
  const DAYS_PER_SEASON = 12;
  const START_SEEDS = 14;

  /** Sun height per season. Summer high, winter low — and the LOW sun is what throws the long
   *  shadows that break a layout you built in July. */
  const SUN = [0.78, 1.00, 0.58, 0.32];
  /** Rain per season, 0..1. Autumn is the wettest, summer the driest. */
  const RAIN = [0.62, 0.30, 0.72, 0.58];
  /** Growth rate per season. Nothing much grows in winter, which is when you get to rearrange. */
  const VIGOUR = [1.15, 1.00, 0.62, 0.18];

  const STAGE_SEEDLING = 0, STAGE_YOUNG = 1, STAGE_MATURE = 2, STAGE_FLOWERING = 3;
  /** How much of its full influence a plant exerts at each stage. A seedling shades nothing. */
  const STAGE_WEIGHT = [0.12, 0.42, 1.00, 1.00];

  /**
   * ⛔ THESE SHOCK FIGURES WERE MEASURED DOWN FROM 0.55/0.40/0.27/0.13, and the reason is a real
   * playability finding rather than a softening. At 0.55 the STARTER spade cost a mature plant
   * more health than a struggling one has left, so the game's core verb was unusable at exactly
   * the moment the design wants it used: you could only move a plant that did not need moving.
   * `sim_probe.js`'s shovel arm caught it (health 0.254 -> 0.000 on the move).
   * At 0.42 a mature specimen at full health survives a move and is set back hard, one at half
   * health barely survives, and one already dying does not — which is the intended lesson (ACT
   * EARLY) rather than an arbitrary wall. A mature BIRCH still cannot be moved with the starter
   * spade at all (0.42 x 2.4 bulk = 1.008), and that is deliberate: a tree needs the barrow.
   */
  const TOOLS = [
    { id: 'spade', name: 'Garden Spade', shock: 0.42, cost: 0, blurb: 'Lifts a plant, and it feels it.' },
    { id: 'border', name: 'Border Spade', shock: 0.30, cost: 70, blurb: 'A longer blade. Less root torn.' },
    { id: 'grafting', name: 'Grafting Spade', shock: 0.20, cost: 160, blurb: 'Narrow, deep, and kind to a rootball.' },
    { id: 'barrow', name: 'Root-ball Barrow', shock: 0.10, cost: 340, blurb: 'Move a tree and it barely notices.' },
  ];

  const AMENDMENTS = [
    { id: 'compost', name: 'Compost', cost: 8, nut: +0.30, ph: 0, moist: +0.05, blurb: 'Feeds the ground.' },
    { id: 'grit', name: 'Sharp Grit', cost: 8, nut: -0.05, ph: 0, moist: -0.28, blurb: 'Drains a wet bed.' },
    { id: 'lime', name: 'Garden Lime', cost: 10, nut: 0, ph: +0.26, moist: 0, blurb: 'Sweetens sour soil.' },
    { id: 'leafmould', name: 'Leafmould', cost: 10, nut: +0.10, ph: -0.26, moist: +0.12, blurb: 'Sours a limy bed.' },
  ];

  /** Three plots, unlocked left to right. Column ranges are INCLUSIVE and exclude the wall ring. */
  const PLOTS = [
    { cols: [1, 5], cost: 0 },
    { cols: [6, 10], cost: 90 },
    { cols: [11, 14], cost: 240 },
  ];

  const idx = (x, y) => y * W + x;
  const clamp = (v, lo, hi) => (v < lo ? lo : v > hi ? hi : v);

  /** Deterministic hash — no Math.random anywhere, so a seed reproduces a garden exactly. */
  function hash2(i, j, seed) {
    let h = (i | 0) * 374761393 + (j | 0) * 668265263 + (seed | 0) * 2147483647;
    h = (h ^ (h >>> 13)) >>> 0;
    h = Math.imul(h, 1274126177) >>> 0;
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  }

  /** Smooth value noise on the grid, used to give the garden its inherent character. */
  function terrainField(seed, scale) {
    const out = new Float64Array(W * H);
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        let v = 0, amp = 1, norm = 0, f = scale;
        for (let o = 0; o < 2; o++) {
          const gx = x / f, gy = y / f;
          const x0 = Math.floor(gx), y0 = Math.floor(gy);
          const tx = gx - x0, ty = gy - y0;
          const s = (t) => t * t * (3 - 2 * t);
          const a = hash2(x0, y0, seed + o * 991), b = hash2(x0 + 1, y0, seed + o * 991);
          const c = hash2(x0, y0 + 1, seed + o * 991), d = hash2(x0 + 1, y0 + 1, seed + o * 991);
          const ab = a + (b - a) * s(tx), cd = c + (d - c) * s(tx);
          v += (ab + (cd - ab) * s(ty)) * amp;
          norm += amp; amp *= 0.5; f *= 0.5;
        }
        out[idx(x, y)] = v / norm;
      }
    }
    return out;
  }

  const isWall = (x, y) => x === 0 || y === 0 || x === W - 1 || y === H - 1;

  /* ── construction ──────────────────────────────────────────────────────────────────────── */

  function newGame(seed) {
    const s = {
      seed: seed === undefined ? 7 : seed,
      version: 1,
      day: 0, season: 0, year: 1,
      dayFrac: 0,
      seeds: START_SEEDS,
      tool: 0,
      plotsOwned: 1,
      cells: [],
      plants: [],
      herbarium: [],          // species ids, permanently pressed
      log: [],
      nextPlantId: 1,
      won: false,
      stats: { planted: 0, moved: 0, died: 0, flowered: 0, dug: 0, amended: 0 },
    };

    const mo = terrainField(s.seed + 1, 4.5);
    const ph = terrainField(s.seed + 2, 5.5);
    const nu = terrainField(s.seed + 3, 3.5);

    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const wall = isWall(x, y);
        /* the garden's inherent character. A damp corner and a chalk streak are what make one
         * bed different from another before the player has done anything at all. */
        /* ⛔ THESE RANGES WERE MEASURED, NOT CHOSEN. The first pass used narrower bands
         * (moisture 0.22+0.56x, ph 0.18+0.64x, nutrient 0.16+0.40x) and
         * `_probe_niche_coverage.js` showed the consequence: across SEVEN gardens the reachable
         * ranges were moisture 0.42-0.68 and nutrient 0.21-0.50, so FOUR of twelve species had no
         * home anywhere on any board — thyme wants moisture under 0.30, sunflower and rhubarb want
         * nutrient over 0.55, ramsons wants it damp. Three separate campaign arms were failing for
         * that one reason, and tuning the win condition would have papered over it.
         * Widened so the terrain SPANS the niche space, which is what makes site selection a real
         * decision instead of a search for the least-bad cell. */
        const baseMoist = wall ? 0 : clamp(0.10 + mo[idx(x, y)] * 0.78, 0, 1);
        const basePh = wall ? 0 : clamp(0.08 + ph[idx(x, y)] * 0.84, 0, 1);
        const baseNut = wall ? 0 : clamp(0.08 + nu[idx(x, y)] * 0.66, 0, 1);
        s.cells.push({
          x, y,
          kind: wall ? 'wall' : 'rough',   // rough -> bed once dug
          baseMoist, basePh, baseNut,
          phShift: 0, nutShift: 0, moistShift: 0,   // PERSISTENT, from litter and amendments
          light: 1, moisture: baseMoist, ph: basePh, nutrient: baseNut,
          plant: null,
        });
      }
    }
    recompute(s);
    return s;
  }

  const cellAt = (s, x, y) => (x < 0 || y < 0 || x >= W || y >= H ? null : s.cells[idx(x, y)]);

  /** Is this column inside a plot the player has bought? */
  function plotOf(x) {
    for (let i = 0; i < PLOTS.length; i++) {
      if (x >= PLOTS[i].cols[0] && x <= PLOTS[i].cols[1]) return i;
    }
    return -1;
  }
  const owned = (s, x, y) => {
    if (isWall(x, y)) return false;
    const p = plotOf(x);
    return p >= 0 && p < s.plotsOwned;
  };

  /* ── system 1 + 3: the microclimate, and the coupling that edits it ────────────────────── */

  /**
   * Recompute every cell's four environment values from terrain + season + what is growing.
   *
   * ⛔ THIS IS THE WHOLE GAME AND IT MUST BE CALLED AFTER ANY CHANGE TO A PLANT OR A CELL.
   * Forgetting it anywhere makes the board lie to the player about why something is dying.
   */
  function recompute(s) {
    const sun = SUN[s.season];
    /* A low sun throws long shadows. Summer 0.55 cells, winter 1.85 — so the SAME garden is a
     * different light map in December, with nothing planted or moved. */
    const shadowLen = 0.55 + 1.6 * (1 - sun);
    const rain = RAIN[s.season];

    for (const c of s.cells) {
      if (c.kind === 'wall') continue;
      c.light = 1;
      /* The north wall shades the row below it, and further in winter. A real walled garden's
       * best beds are the ones against the south-facing wall. */
      const wallDist = c.y - 1;
      if (wallDist < shadowLen) c.light -= 0.42 * (1 - wallDist / Math.max(0.001, shadowLen));
      /* TERRAIN WEIGHTED OVER WEATHER. At 0.58/0.42 the season's rain swamped the ground's own
       * character and every cell converged on the same damp middle; at 0.72/0.28 a dry bank stays
       * a dry bank in April and a boggy corner stays boggy in July, which is what makes a
       * particular cell worth choosing. Season still moves every cell, just not past its nature. */
      c.moisture = clamp(c.baseMoist * 0.72 + rain * 0.28 + c.moistShift, 0, 1);
      c.nutrient = clamp(c.baseNut + c.nutShift, 0, 1);
      c.ph = clamp(c.basePh + c.phShift, 0, 1);
    }

    /* SYSTEM 3 — COMPETITION. Every plant writes into its neighbourhood. This is the coupling:
     * system 2 (what has grown) EDITS system 1 (the environment), which then decides system 2. */
    for (const p of s.plants) {
      const sp = SPECIES.BY_ID[p.sp];
      const w = STAGE_WEIGHT[p.stage];
      if (w <= 0) continue;
      const inf = sp.influence;
      const r = Math.max(1, inf.radius);
      /* the shadow falls UP-SCREEN (north), away from the sun, and lengthens as the sun drops */
      const offY = -shadowLen * (inf.radius * 0.55);
      for (let dy = -r - 2; dy <= r + 2; dy++) {
        for (let dx = -r - 1; dx <= r + 1; dx++) {
          const c = cellAt(s, p.x + dx, p.y + dy);
          if (!c || c.kind === 'wall') continue;

          /* SHADE — measured from the shadow's centre, which is offset from the plant */
          const sdx = dx, sdy = dy - offY;
          const sd = Math.hypot(sdx, sdy * 1.25);
          if (sd <= r + 0.9) {
            const fall = clamp(1 - sd / (r + 0.9), 0, 1);
            c.light -= inf.shade * w * fall;
          }
          /* DRAW and FEED work on the ROOTS, which are centred on the plant itself */
          const rd = Math.hypot(dx, dy);
          if (rd <= r + 0.5) {
            const fall = clamp(1 - rd / (r + 0.5), 0, 1);
            c.moisture -= inf.draw * w * fall;
            c.nutrient -= inf.feed * w * fall;
          }
        }
      }
    }
    for (const c of s.cells) {
      if (c.kind === 'wall') continue;
      c.light = clamp(c.light, 0, 1);
      /* ⭐ SHADE KEEPS THE GROUND DAMP, and adding this resolved a real design knot rather than
       * being a tuning nudge. RAMSONS wants deep shade AND wet ground, but the only thing that
       * makes deep shade is a tree, and a tree DRAWS moisture — so the one species that needs
       * both was unreachable by construction (measured: best fit 0.70 under three mature birches).
       * A woodland floor is damp precisely BECAUSE it is shaded: less sun on it, less evaporation.
       * Modelling that is botanically right and it makes the deepest niche in the game reachable
       * by the exact action the design wants the player to take. Applied AFTER the shade pass,
       * because it depends on the final light value. */
      c.moisture = clamp(c.moisture + (1 - c.light) * 0.16, 0, 1);
      c.nutrient = clamp(c.nutrient, 0, 1);
    }
  }

  /** The environment a plant at (x,y) actually experiences. */
  function envAt(s, x, y) {
    const c = cellAt(s, x, y);
    if (!c) return { light: 0, moisture: 0, ph: 0.5, nutrient: 0 };
    return { light: c.light, moisture: c.moisture, ph: c.ph, nutrient: c.nutrient };
  }

  /* ── actions. EVERY ONE OF THEM IS A DIG — the shovel is the only verb. ─────────────────── */

  function log(s, text, kind) {
    s.log.push({ day: s.day, text, kind: kind || 'info' });
    if (s.log.length > 60) s.log.shift();
  }

  /** Turn rough ground into a workable bed. Free — the constraint in this game is the plants. */
  function dig(s, x, y) {
    const c = cellAt(s, x, y);
    if (!c) return { ok: false, why: 'outside the garden' };
    if (c.kind === 'wall') return { ok: false, why: 'that is the wall' };
    if (!owned(s, x, y)) return { ok: false, why: 'that plot is not yours yet' };
    if (c.kind === 'bed') return { ok: false, why: 'already dug' };
    if (c.plant) return { ok: false, why: 'something is growing there' };
    c.kind = 'bed';
    s.stats.dug++;
    recompute(s);
    return { ok: true };
  }

  function plant(s, speciesId, x, y) {
    const sp = SPECIES.BY_ID[speciesId];
    if (!sp) return { ok: false, why: 'no such plant' };
    const c = cellAt(s, x, y);
    if (!c) return { ok: false, why: 'outside the garden' };
    if (!owned(s, x, y)) return { ok: false, why: 'that plot is not yours yet' };
    if (c.kind !== 'bed') return { ok: false, why: 'dig the bed first' };
    if (c.plant) return { ok: false, why: 'something is already there' };
    if (!isUnlocked(s, sp)) return { ok: false, why: 'not unlocked yet' };
    if (s.seeds < sp.cost) return { ok: false, why: 'not enough seed' };
    s.seeds -= sp.cost;
    const p = {
      id: s.nextPlantId++, sp: sp.id, x, y,
      age: 0, health: 0.85, stage: STAGE_SEEDLING, everFlowered: false, shock: 0,
    };
    s.plants.push(p);
    c.plant = p;
    s.stats.planted++;
    recompute(s);
    return { ok: true, plant: p };
  }

  /** What a transplant would cost this plant, before doing it. The UI shows this. */
  function shockCost(s, p) {
    const sp = SPECIES.BY_ID[p.sp];
    /* The stage term is steep on purpose (0.20 -> 1.00 rather than 0.35 -> 1.00): a seedling
     * should be almost free to reposition, so early experimenting is encouraged, while a mature
     * specimen is the thing you have to think hard about. That IS the sentence the store page
     * makes — "the plants you are proudest of are the ones you can least afford to move". */
    return TOOLS[s.tool].shock * sp.bulk * (0.20 + 0.80 * STAGE_WEIGHT[p.stage]);
  }

  /**
   * SYSTEM 4 — LIFT AND MOVE. The answer to everything, and it is never free.
   * The cost scales with how big the plant has grown, so the specimens you are proudest of are
   * the ones you can least afford to move. That is the tension the whole design rests on.
   */
  function move(s, p, nx, ny) {
    const dst = cellAt(s, nx, ny);
    if (!dst) return { ok: false, why: 'outside the garden' };
    if (!owned(s, nx, ny)) return { ok: false, why: 'that plot is not yours yet' };
    if (dst.kind !== 'bed') return { ok: false, why: 'dig that bed first' };
    if (dst.plant) return { ok: false, why: 'something is already there' };
    if (nx === p.x && ny === p.y) return { ok: false, why: 'it is already there' };
    const src = cellAt(s, p.x, p.y);
    const cost = shockCost(s, p);
    src.plant = null;
    p.x = nx; p.y = ny;
    dst.plant = p;
    p.health = clamp(p.health - cost, 0, 1);
    p.shock = 3;                       // days of visible wilt
    s.stats.moved++;
    recompute(s);
    const sp = SPECIES.BY_ID[p.sp];
    if (p.health <= 0) {
      removePlant(s, p);
      log(s, sp.name + ' did not survive the move.', 'bad');
      s.stats.died++;
      return { ok: true, killed: true, cost };
    }
    log(s, sp.name + ' moved. Transplant shock ' + Math.round(cost * 100) + '%.', 'warn');
    return { ok: true, cost };
  }

  function removePlant(s, p) {
    const c = cellAt(s, p.x, p.y);
    if (c && c.plant === p) c.plant = null;
    const i = s.plants.indexOf(p);
    if (i >= 0) s.plants.splice(i, 1);
    recompute(s);
  }

  /** Dig something INTO the soil. A permanent change, which is why it competes with moving. */
  function amend(s, amendmentId, x, y) {
    const a = AMENDMENTS.find((z) => z.id === amendmentId);
    if (!a) return { ok: false, why: 'no such amendment' };
    if (s.tool < 1) return { ok: false, why: 'needs a Border Spade or better' };
    const c = cellAt(s, x, y);
    if (!c || c.kind === 'wall') return { ok: false, why: 'not soil' };
    if (!owned(s, x, y)) return { ok: false, why: 'that plot is not yours yet' };
    if (s.seeds < a.cost) return { ok: false, why: 'not enough seed' };
    s.seeds -= a.cost;
    c.nutShift = clamp(c.nutShift + a.nut, -0.6, 0.8);
    c.phShift = clamp(c.phShift + a.ph, -0.6, 0.6);
    c.moistShift = clamp(c.moistShift + a.moist, -0.5, 0.5);
    s.stats.amended++;
    recompute(s);
    return { ok: true };
  }

  function buyTool(s, tier) {
    if (tier <= s.tool) return { ok: false, why: 'already have it' };
    if (tier !== s.tool + 1) return { ok: false, why: 'buy them in order' };
    if (s.seeds < TOOLS[tier].cost) return { ok: false, why: 'not enough seed' };
    s.seeds -= TOOLS[tier].cost;
    s.tool = tier;
    log(s, 'Bought the ' + TOOLS[tier].name + '.', 'good');
    return { ok: true };
  }

  function buyPlot(s) {
    if (s.plotsOwned >= PLOTS.length) return { ok: false, why: 'the garden ends here' };
    const cost = PLOTS[s.plotsOwned].cost;
    if (s.seeds < cost) return { ok: false, why: 'not enough seed' };
    s.seeds -= cost;
    s.plotsOwned++;
    log(s, 'Opened up more of the garden.', 'good');
    recompute(s);
    return { ok: true };
  }

  /** A species appears in the shop once enough specimens are in the herbarium. */
  function isUnlocked(s, sp) {
    return s.herbarium.length >= sp.unlockAt;
  }

  /* ── systems 2, 5, 6: the day tick ─────────────────────────────────────────────────────── */

  function stageFor(sp, p) {
    const t = p.age / sp.days;
    if (t < 0.26) return STAGE_SEEDLING;
    if (t < 0.62) return STAGE_YOUNG;
    return STAGE_MATURE;
  }

  /**
   * Advance one day. Returns a list of events the presentation layer may want to react to.
   * ⚠️ Deterministic: given the same state and the same day, this always does the same thing.
   */
  function tickDay(s) {
    const events = [];
    const vig = VIGOUR[s.season];

    for (const p of s.plants.slice()) {
      const sp = SPECIES.BY_ID[p.sp];
      const env = envAt(s, p.x, p.y);
      const f = SPECIES.fit(sp, env).fit;

      /* Health drifts toward fit, but a shocked plant recovers slowly whatever the conditions.
       *
       * ⛔ DECLINE IS DELIBERATELY SLOWER THAN RECOVERY (0.09 vs 0.22), and that asymmetry is a
       * design requirement rather than a kindness. THE WHOLE GAME IS "notice that a bed has gone
       * wrong, and answer it with the shovel" — so the player has to be given time to notice. At a
       * symmetric 0.20 a shaded lavender fell from 0.85 to 0.004 in 25 days, which is roughly two
       * in-game seasons of a plant that was already unsaveable by the time it looked ill. The
       * shovel arm of `sim_probe.js` caught it by running at that floor and measuring nothing.
       * Now a badly-sited plant visibly sulks for a long while before it is beyond help. */
      if (p.shock > 0) p.shock--;
      const shocked = p.shock > 0 ? 0.35 : 1;
      const rate = (f > p.health ? 0.22 : 0.09) * shocked;
      p.health = clamp(p.health + (f - p.health) * rate, 0, 1);

      /* SYSTEM 2 — growth. A plant only advances while it is reasonably happy, so a badly-sited
       * specimen does not merely score less, it STOPS, which the player can see. */
      if (f > 0.42 && p.health > 0.25) p.age += vig * (0.55 + 0.45 * f);

      const st = stageFor(sp, p);
      if (st !== p.stage && st > p.stage) {
        p.stage = st;
        if (st === STAGE_MATURE) events.push({ type: 'mature', plant: p });
      }

      /* SYSTEM 3, the persistent half — LITTER. A mature plant permanently changes its patch,
       * and that memory outlives the plant. This is what makes the soil a record of your garden. */
      if (p.stage >= STAGE_MATURE && p.health > 0.4) {
        const c = cellAt(s, p.x, p.y);
        const inf = sp.influence;
        for (let dy = -inf.radius; dy <= inf.radius; dy++) {
          for (let dx = -inf.radius; dx <= inf.radius; dx++) {
            const n = cellAt(s, p.x + dx, p.y + dy);
            if (!n || n.kind === 'wall') continue;
            const fall = clamp(1 - Math.hypot(dx, dy) / (inf.radius + 0.5), 0, 1);
            n.phShift = clamp(n.phShift + inf.litter * 0.045 * fall, -0.6, 0.6);
            n.nutShift = clamp(n.nutShift - inf.feed * 0.012 * fall, -0.6, 0.8);
          }
        }
        if (c) c.nutShift = clamp(c.nutShift + 0.004, -0.6, 0.8);   // its own leaf fall feeds back
      }

      /* SYSTEM 5+6 — flowering is season-gated, and the FIRST flowering presses the specimen */
      const flowering = p.stage >= STAGE_MATURE && s.season === sp.flowersIn && p.health > 0.55;
      p.stage = flowering ? STAGE_FLOWERING : Math.min(p.stage, STAGE_MATURE);
      if (flowering) {
        s.seeds += Math.round(sp.yieldSeeds * p.health);
        if (!p.everFlowered) {
          p.everFlowered = true;
          s.stats.flowered++;
          if (s.herbarium.indexOf(sp.id) < 0) {
            s.herbarium.push(sp.id);
            events.push({ type: 'pressed', plant: p, species: sp });
            log(s, sp.name + ' pressed into the herbarium. ' + s.herbarium.length + ' of '
              + SPECIES.LIST.length + '.', 'good');
          }
        }
      }

      if (p.health <= 0.001) {
        removePlant(s, p);
        s.stats.died++;
        events.push({ type: 'died', plant: p, species: sp });
        log(s, sp.name + ' died. ' + (SPECIES.complaint(sp, env) || { text: 'it gave out' }).text + '.', 'bad');
      }
    }

    s.day++;
    s.dayFrac = 0;
    if (s.day % DAYS_PER_SEASON === 0) {
      s.season = (s.season + 1) % 4;
      if (s.season === 0) s.year++;
      events.push({ type: 'season', season: s.season });
      log(s, SPECIES.SEASONS[s.season] + ', year ' + s.year + '.', 'info');
    }
    recompute(s);

    if (!s.won && s.herbarium.length >= SPECIES.LIST.length) {
      s.won = true;
      events.push({ type: 'won' });
    }
    return events;
  }

  /** Advance real time. Returns the events from any day boundaries crossed. */
  function advance(s, dtSeconds, speed) {
    let events = [];
    if (speed <= 0 || s.won) return events;
    s.dayFrac += (dtSeconds * speed) / DAY_SECONDS;
    let guard = 0;
    while (s.dayFrac >= 1 && guard++ < 40) {
      s.dayFrac -= 1;
      events = events.concat(tickDay(s));
    }
    return events;
  }

  /* ── save / resume. Ledger B4: death is never a restart. ───────────────────────────────── */

  const SAVE_KEY = 'ROOTBOUND_SAVE_V1';

  function serialise(s) {
    return JSON.stringify({
      v: 1, seed: s.seed, day: s.day, season: s.season, year: s.year, seeds: s.seeds,
      tool: s.tool, plotsOwned: s.plotsOwned, herbarium: s.herbarium, won: s.won,
      stats: s.stats, nextPlantId: s.nextPlantId,
      cells: s.cells.map((c) => [c.kind === 'bed' ? 1 : 0,
        Math.round(c.phShift * 1000), Math.round(c.nutShift * 1000), Math.round(c.moistShift * 1000)]),
      plants: s.plants.map((p) => [p.id, p.sp, p.x, p.y, Math.round(p.age * 100),
        Math.round(p.health * 1000), p.stage, p.everFlowered ? 1 : 0, p.shock]),
    });
  }

  function deserialise(text) {
    const d = JSON.parse(text);
    if (!d || d.v !== 1) return null;
    const s = newGame(d.seed);
    s.day = d.day; s.season = d.season; s.year = d.year; s.seeds = d.seeds;
    s.tool = d.tool; s.plotsOwned = d.plotsOwned; s.herbarium = d.herbarium.slice();
    s.won = !!d.won; s.stats = d.stats || s.stats; s.nextPlantId = d.nextPlantId || 1;
    for (let i = 0; i < d.cells.length && i < s.cells.length; i++) {
      const c = s.cells[i], r = d.cells[i];
      if (c.kind === 'wall') continue;
      c.kind = r[0] ? 'bed' : 'rough';
      c.phShift = r[1] / 1000; c.nutShift = r[2] / 1000; c.moistShift = r[3] / 1000;
    }
    s.plants = [];
    for (const r of d.plants) {
      const sp = SPECIES.BY_ID[r[1]];
      if (!sp) continue;                            // a save from a build with a species we lost
      const c = cellAt(s, r[2], r[3]);
      if (!c || c.kind === 'wall') continue;
      const p = { id: r[0], sp: r[1], x: r[2], y: r[3], age: r[4] / 100,
        health: r[5] / 1000, stage: r[6], everFlowered: !!r[7], shock: r[8] || 0 };
      s.plants.push(p);
      c.plant = p;
    }
    recompute(s);
    return s;
  }

  function save(s, storage) {
    const st = storage || (typeof localStorage !== 'undefined' ? localStorage : null);
    if (!st) return false;
    try { st.setItem(SAVE_KEY, serialise(s)); return true; } catch (e) { return false; }
  }

  function load(storage) {
    const st = storage || (typeof localStorage !== 'undefined' ? localStorage : null);
    if (!st) return null;
    try {
      const t = st.getItem(SAVE_KEY);
      if (!t) return null;
      return deserialise(t);
    } catch (e) { return null; }
  }

  function clearSave(storage) {
    const st = storage || (typeof localStorage !== 'undefined' ? localStorage : null);
    if (st) { try { st.removeItem(SAVE_KEY); } catch (e) { /* nothing to do */ } }
  }

  return {
    W, H, DAY_SECONDS, DAYS_PER_SEASON, SUN, RAIN, VIGOUR, STAGE_WEIGHT, TOOLS, AMENDMENTS, PLOTS,
    SAVE_KEY, START_SEEDS,
    STAGE_SEEDLING, STAGE_YOUNG, STAGE_MATURE, STAGE_FLOWERING,
    newGame, cellAt, idx, isWall, owned, plotOf, recompute, envAt,
    dig, plant, move, amend, buyTool, buyPlot, isUnlocked, shockCost, removePlant,
    tickDay, advance, log,
    serialise, deserialise, save, load, clearSave,
    hash2, clamp,
  };
});
