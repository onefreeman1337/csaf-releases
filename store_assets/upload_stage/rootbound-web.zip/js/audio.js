/**
 * audio.js — ROOTBOUND's sound. Web Audio, deliberately.
 *
 * ⛔ THE LOOP GOES THROUGH `AudioBufferSourceNode`, NOT `HTMLAudioElement.loop`. The cue set was
 * built and measured by a dedicated pass which reported the file's own loop-seam discontinuity at
 * 0.015 (bar 0.05) — but also flagged, honestly, that a FILE with no seam can still loop with an
 * audible gap because `HTMLAudioElement.loop` on Vorbis commonly inserts one, while a decoded
 * `AudioBuffer` played through a source node does not. Using the element would have thrown away
 * the seam work in the last five lines of the project.
 *
 * ⚠️ AUTOPLAY: browsers refuse to start an AudioContext without a gesture, and an itch embed opens
 * behind a click-to-play frame. So the context is created lazily and `resume()`d on the first real
 * input; a refusal is caught and the game stays completely playable in silence.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.AUDIO = api;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const CUES = ['sfx_dig', 'sfx_plant', 'sfx_lift', 'sfx_water', 'sfx_bloom',
    'sfx_press', 'sfx_buy', 'sfx_deny', 'sfx_season', 'sfx_die'];
  const MUSIC = 'garden_loop';

  let actx = null;
  const buffers = {};
  let musicSrc = null, musicGain = null, sfxGain = null;
  let enabled = true;
  let started = false;
  let loadReport = { requested: 0, decoded: 0, failed: [] };

  function ctxOrNull() {
    if (actx) return actx;
    const AC = (typeof window !== 'undefined') && (window.AudioContext || window.webkitAudioContext);
    if (!AC) return null;
    try {
      actx = new AC();
      musicGain = actx.createGain(); musicGain.gain.value = 0.34; musicGain.connect(actx.destination);
      sfxGain = actx.createGain(); sfxGain.gain.value = 0.55; sfxGain.connect(actx.destination);
    } catch (e) { actx = null; }
    return actx;
  }

  /** Fetch and decode every cue. Resolves with a COUNT, so a caller can assert work happened. */
  function load(base) {
    const a = ctxOrNull();
    const names = CUES.concat([MUSIC]);
    loadReport = { requested: names.length, decoded: 0, failed: [] };
    if (!a) return Promise.resolve(loadReport);
    return Promise.all(names.map((n) => fetch((base || 'audio/') + n + '.ogg')
      .then((r) => (r.ok ? r.arrayBuffer() : Promise.reject(new Error('http ' + r.status))))
      .then((buf) => new Promise((res, rej) => a.decodeAudioData(buf, res, rej)))
      .then((dec) => { buffers[n] = dec; loadReport.decoded++; })
      .catch(() => { loadReport.failed.push(n); })))
      .then(() => loadReport);
  }

  /** Call from a real user gesture. Safe to call repeatedly. */
  function unlock() {
    const a = ctxOrNull();
    if (!a) return false;
    if (a.state === 'suspended') { try { a.resume(); } catch (e) { /* refused; stay silent */ } }
    if (!started && enabled) startMusic();
    return a.state === 'running';
  }

  function startMusic() {
    const a = ctxOrNull();
    if (!a || !buffers[MUSIC] || musicSrc) return;
    try {
      musicSrc = a.createBufferSource();
      musicSrc.buffer = buffers[MUSIC];
      musicSrc.loop = true;                 // sample-accurate on a source node
      musicSrc.connect(musicGain);
      musicSrc.start(0);
      started = true;
    } catch (e) { musicSrc = null; }
  }

  function stopMusic() {
    if (musicSrc) { try { musicSrc.stop(); } catch (e) { /* already stopped */ } musicSrc = null; }
    started = false;
  }

  function play(name, vol) {
    const a = ctxOrNull();
    if (!a || !enabled || !buffers[name]) return false;
    try {
      const s = a.createBufferSource();
      s.buffer = buffers[name];
      const g = a.createGain();
      g.gain.value = vol === undefined ? 1 : vol;
      s.connect(g); g.connect(sfxGain);
      s.start(0);
      return true;
    } catch (e) { return false; }
  }

  function setEnabled(on) {
    enabled = !!on;
    if (!enabled) stopMusic();
    else startMusic();
    if (musicGain) musicGain.gain.value = enabled ? 0.34 : 0;
    if (sfxGain) sfxGain.gain.value = enabled ? 0.55 : 0;
    return enabled;
  }

  return { CUES, MUSIC, load, unlock, play, setEnabled, startMusic, stopMusic,
    isEnabled: () => enabled, report: () => loadReport };
});
