/**
 * art.js — ROOTBOUND's drawing surface: asset loading, colours, and every text primitive.
 *
 * ⛔ EVERY STRING IN THIS GAME IS DRAWN THROUGH `API.text`, `API.wrap`, `API.paragraph` OR
 * `API.button`, AND INTERNAL CALLERS GO THROUGH THE EXPORTED OBJECT RATHER THAN THE CLOSURE-LOCAL
 * FUNCTION. That looks like a pointless indirection and it is not: wing §3e-1 records a layout
 * gate that reported "help — 12 strings" for a screen drawing thirty, because `paragraph` called
 * the closure-local `text` and the recorder — which replaces the EXPORTED symbol — could not see
 * it. The gate was blind to exactly the lines most likely to overflow.
 *
 * ⛔ CANVAS TEXT DOES NOT WRAP, DOES NOT REFLOW AND DOES NOT CLIP. A string that is too long runs
 * off the edge of the world with every check green (§3e-1, FLOODMARK: 133 assertions passing while
 * four body lines drew to 1035px on a 960px canvas). So layout is DERIVED from `ctx.measureText`
 * at draw time, never from a width somebody measured once and typed in — this game ships a system
 * font stack, so the same string is a different width on every machine.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.ART = api;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* Kept in step with Internal_Ops/palette.js by eye and by the `ui-palette-match` suite arm,
   * which reads THAT file and compares — two structures holding one fact, so one derives. */
  const C = {
    ink: '#1b1a16', pap0: '#c9c0a6', pap1: '#ddd5bd', pap2: '#efe8d4',
    brass: '#b98d3c', iron: '#5d5c56', bad: '#a8402f', good: '#4d7a3a',
    night: '#111318', shade: '#0d1a14',
    sky: [ '#5c7c8a', '#7fa3b0', '#8a7f63', '#4a5a68' ],   // per season, for the frame
  };

  const FONT_BODY = "14px 'Iowan Old Style', 'Palatino Linotype', Palatino, Georgia, serif";
  const FONT_SMALL = "12px 'Iowan Old Style', 'Palatino Linotype', Palatino, Georgia, serif";
  const FONT_TINY = "10px 'Iowan Old Style', 'Palatino Linotype', Palatino, Georgia, serif";
  const FONT_HEAD = "600 18px 'Iowan Old Style', 'Palatino Linotype', Palatino, Georgia, serif";
  const FONT_TITLE = "600 46px 'Iowan Old Style', 'Palatino Linotype', Palatino, Georgia, serif";

  let ctx = null;
  const images = {};

  function init(context) { ctx = context; }
  function getCtx() { return ctx; }

  /** Load every asset the game needs. Resolves with a manifest so a caller can COUNT them. */
  function load(names, base) {
    return Promise.all(names.map((n) => new Promise((res) => {
      const im = new Image();
      im.onload = () => { images[n] = im; res({ name: n, ok: true, w: im.width, h: im.height }); };
      im.onerror = () => { res({ name: n, ok: false }); };
      im.src = (base || 'art/') + n + '.png';
    })));
  }
  const img = (n) => images[n] || null;

  /* ── text ────────────────────────────────────────────────────────────────────────────────
   * `font` is a font STRING. ⚠️ Never parse a size out of it with parseInt: this game's heading
   * font starts with a WEIGHT ("600 18px ..."), and wing §3e-2 records a layout gate that read
   * every box as 612px tall for exactly that reason. Match /(\d+(?:\.\d+)?)px/. */
  function fontSize(font) {
    const m = String(font).match(/(\d+(?:\.\d+)?)px/);
    return m ? parseFloat(m[1]) : 14;
  }

  function text(str, x, y, opts) {
    opts = opts || {};
    const f = opts.font || FONT_BODY;
    ctx.font = f;
    ctx.fillStyle = opts.colour || C.ink;
    ctx.textAlign = opts.align || 'left';
    ctx.textBaseline = opts.baseline || 'alphabetic';
    ctx.fillText(str, x, y);
    return ctx.measureText(str).width;
  }

  /** Break `str` into lines no wider than `maxW`, measured on THIS machine at draw time. */
  function wrap(str, maxW, font) {
    ctx.font = font || FONT_BODY;
    const words = String(str).split(/\s+/).filter(Boolean);
    const lines = [];
    let cur = '';
    for (const w of words) {
      const t = cur ? cur + ' ' + w : w;
      if (ctx.measureText(t).width <= maxW || !cur) cur = t;
      else { lines.push(cur); cur = w; }
    }
    if (cur) lines.push(cur);
    return lines;
  }

  /** Draw wrapped body copy. Returns the y BELOW the last line, so callers can stack. */
  function paragraph(str, x, y, maxW, opts) {
    opts = opts || {};
    const f = opts.font || FONT_BODY;
    const lh = opts.lineHeight || Math.round(fontSize(f) * 1.45);
    const lines = API.wrap(str, maxW, f);
    let yy = y;
    for (const ln of lines) {
      API.text(ln, x, yy, { font: f, colour: opts.colour, align: opts.align });
      yy += lh;
    }
    return yy;
  }

  /** A framed control. Returns its rect so input can hit-test the SAME geometry that was drawn. */
  function button(label, x, y, w, h, opts) {
    opts = opts || {};
    const on = !!opts.active, dis = !!opts.disabled;
    ctx.fillStyle = dis ? '#2a2b26' : on ? C.brass : '#3a3b34';
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = dis ? '#3a3b34' : on ? '#e0bd6c' : C.iron;
    ctx.lineWidth = 1;
    ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
    API.text(label, x + w / 2, y + h / 2 + 4, {
      font: opts.font || FONT_SMALL,
      colour: dis ? '#6a6b63' : on ? '#1b1a16' : C.pap1,
      align: 'center',
    });
    return { x, y, w, h, label };
  }

  /**
   * A filled CARD — a specimen tile, a herbarium row, anything that is a solid block of graphics
   * a string must not be drawn on top of.
   *
   * ⛔ IT EXISTS SO THE LAYOUT GATE CAN SEE IT. Twice in one session a paragraph was drawn straight
   * through a block of art (the win screen's specimen cards, the help screen's plant thumbnails)
   * and the gate reported CLEAN both times, because it compares text to text and text to BUTTONS,
   * and a raw `ctx.fillRect` is neither. Routing every such block through one recordable helper
   * turns an invisible class into a checkable one — the fix belongs at the class, not at the two
   * places it happened to bite.
   */
  function card(x, y, w, h, opts) {
    opts = opts || {};
    ctx.fillStyle = opts.fill || 'rgba(30,34,28,0.85)';
    ctx.fillRect(x, y, w, h);
    if (opts.stroke) {
      ctx.strokeStyle = opts.stroke;
      ctx.lineWidth = 1;
      ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
    }
    return { x, y, w, h, card: true };
  }

  function panel(x, y, w, h, opts) {
    opts = opts || {};
    ctx.fillStyle = opts.fill || 'rgba(14,16,13,0.86)';
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = opts.stroke || C.iron;
    ctx.lineWidth = 1;
    ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
  }

  /** A tiled fill from one of the baked plates. */
  function tile(name, x, y, w, h) {
    const im = img(name);
    if (!im) { ctx.fillStyle = '#332619'; ctx.fillRect(x, y, w, h); return; }
    const p = ctx.createPattern(im, 'repeat');
    ctx.save();
    ctx.translate(x, y);
    ctx.fillStyle = p;
    ctx.fillRect(0, 0, w, h);
    ctx.restore();
  }

  /** A horizontal meter — the one way this game shows a 0..1 number. */
  function meter(x, y, w, h, v, colour, band) {
    ctx.fillStyle = '#20221d';
    ctx.fillRect(x, y, w, h);
    if (band) {
      ctx.fillStyle = 'rgba(185,141,60,0.28)';
      ctx.fillRect(x + w * band[0], y, w * (band[1] - band[0]), h);
    }
    ctx.fillStyle = colour || C.pap1;
    ctx.fillRect(x, y, Math.max(0, Math.min(1, v)) * w, h);
    ctx.strokeStyle = C.iron;
    ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
  }

  const API = {
    C, FONT_BODY, FONT_SMALL, FONT_TINY, FONT_HEAD, FONT_TITLE,
    init, getCtx, load, img, text, wrap, paragraph, button, card, panel, tile, meter, fontSize,
  };
  return API;
});
