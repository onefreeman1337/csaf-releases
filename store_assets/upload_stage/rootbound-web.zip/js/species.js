/**
 * species.js — ROOTBOUND's twelve plants. THE SINGLE SOURCE OF TRUTH.
 *
 * ⛔ THIS FILE IS READ BY BOTH THE GAME AND THE ART BAKER. That is deliberate. Wing §3h item 4 and
 * master §2b's sixth family both record the same defect: when two structures hold the same fact
 * they drift, and a read-back of the field you wrote cannot detect it. So the sprite generator
 * (Internal_Ops/plants.js) does NOT keep its own list of species, colours or stages — it requires
 * this file. A species cannot be added to the game without the baker seeing it.
 *
 * ── HOW TO READ A NICHE ──────────────────────────────────────────────────────────────────────
 * Every environment value in this game is 0..1:
 *   light     0 = deep shade under a canopy      1 = open sun all day
 *   moisture  0 = parched free-draining          1 = waterlogged
 *   ph        0 = strongly acid (peat)           1 = strongly alkaline (chalk)
 *   nutrient  0 = poor, starved                  1 = rich, heavily fed
 * A species is HAPPY inside its band, and its health drifts toward the worst-fitting axis. The
 * bands overlap deliberately: no cell is right for everything, and a few cells are right for
 * nothing yet.
 *
 * ── THE SUCCESSION, WHICH IS THE WHOLE GAME ──────────────────────────────────────────────────
 * Read the `light` bands together and the arc falls out. You begin with sun plants because an
 * empty garden is all sun. The only way to reach HOSTA, FERN and RAMSONS is to grow shade, and
 * the only things that make shade are BIRCH, SUNFLOWER and RHUBARB — which then wreck the
 * lavender you started with. That is ecological succession, it is botanically true, and it is why
 * the shovel exists.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.SPECIES = api;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* Seasons are indices everywhere in this codebase. Named once, here. */
  const SEASONS = ['Spring', 'Summer', 'Autumn', 'Winter'];

  /* Growth stages. The sprite baker bakes one image per species per stage, so this array's
   * LENGTH is the sprite count per species — never type 4 anywhere else. */
  const STAGES = ['seedling', 'young', 'mature', 'flowering'];

  /**
   * @typedef Species
   * @property {string} id        stable key, used for sprite filenames and save data
   * @property {string} name      what the player reads
   * @property {string} latin     flavour, and it keeps the botany honest
   * @property {object} niche     {light,moisture,ph,nutrient} each [min,max] in 0..1
   * @property {number} cost      seeds to buy one
   * @property {number} unlockAt  herbarium specimens required before it appears in the shop
   * @property {number} days      in-game days from planting to MATURE
   * @property {number} flowersIn season index it flowers in (its only yield window)
   * @property {number} yieldSeeds seeds paid per flowering day while healthy
   * @property {object} influence what a MATURE one does to its neighbourhood
   * @property {number} influence.radius   in cells
   * @property {number} influence.shade    light removed at the centre of its shadow
   * @property {number} influence.draw     moisture removed
   * @property {number} influence.litter   pH shift (negative = acidifies)
   * @property {number} influence.feed     nutrient consumed
   * @property {number} bulk      transplant shock multiplier — big plants hate being moved
   * @property {object} art       drives Internal_Ops/plants.js. See ARCHETYPES there.
   */
  const LIST = [
    {
      id: 'thyme', name: 'Creeping Thyme', latin: 'Thymus serpyllum',
      niche: { light: [0.60, 1.00], moisture: [0.00, 0.30], ph: [0.55, 1.00], nutrient: [0.00, 0.40] },
      cost: 0, unlockAt: 0, days: 6, flowersIn: 1, yieldSeeds: 2,
      influence: { radius: 1, shade: 0.03, draw: 0.04, litter: 0.01, feed: 0.03 },
      bulk: 0.5,
      blurb: 'Wants it hot, dry, poor and limy. Nothing else in the garden wants all four.',
      art: { form: 'mat', foliage: 'grey', flower: 'pink', h: [5, 8, 11, 12], spread: [10, 20, 30, 32] },
    },
    {
      id: 'lavender', name: 'Lavender', latin: 'Lavandula angustifolia',
      niche: { light: [0.62, 1.00], moisture: [0.05, 0.40], ph: [0.50, 1.00], nutrient: [0.05, 0.55] },
      cost: 6, unlockAt: 0, days: 9, flowersIn: 1, yieldSeeds: 4,
      influence: { radius: 1, shade: 0.10, draw: 0.07, litter: 0.02, feed: 0.06 },
      bulk: 1.0,
      blurb: 'The first thing that ever grew here. It will be the first thing the shade kills.',
      art: { form: 'subshrub', foliage: 'grey', flower: 'violet', spike: true, h: [9, 18, 30, 33], spread: [8, 16, 24, 26] },
    },
    {
      id: 'rosemary', name: 'Rosemary', latin: 'Salvia rosmarinus',
      niche: { light: [0.58, 1.00], moisture: [0.05, 0.42], ph: [0.45, 0.95], nutrient: [0.10, 0.60] },
      cost: 10, unlockAt: 1, days: 12, flowersIn: 0, yieldSeeds: 5,
      influence: { radius: 1, shade: 0.16, draw: 0.09, litter: 0.02, feed: 0.08 },
      bulk: 1.3,
      blurb: 'Woody, upright, and it flowers in spring when almost nothing else does.',
      art: { form: 'subshrub', foliage: 'dark', flower: 'paleblue', needle: true, h: [10, 22, 38, 41], spread: [7, 14, 22, 24] },
    },
    {
      id: 'heather', name: 'Ling Heather', latin: 'Calluna vulgaris',
      niche: { light: [0.55, 1.00], moisture: [0.15, 0.55], ph: [0.00, 0.30], nutrient: [0.00, 0.30] },
      cost: 12, unlockAt: 2, days: 11, flowersIn: 2, yieldSeeds: 5,
      influence: { radius: 1, shade: 0.07, draw: 0.05, litter: -0.03, feed: 0.04 },
      bulk: 0.8,
      blurb: 'Sun and acid and hungry ground. It will not forgive a limed bed.',
      /* `alongStem` puts the flowers up the SHOOTS rather than in a tuft at the tip. That is what
       * ling actually does, and it is also what separates this silhouette from ROSEMARY — the two
       * baked as near-identical fans on the first contact sheet and had to be told apart. */
      art: { form: 'subshrub', foliage: 'bronze', flower: 'magenta', needle: true, alongStem: true, h: [8, 15, 24, 26], spread: [9, 17, 26, 28] },
    },
    {
      id: 'sunflower', name: 'Sunflower', latin: 'Helianthus annuus',
      niche: { light: [0.72, 1.00], moisture: [0.35, 0.75], ph: [0.35, 0.75], nutrient: [0.55, 1.00] },
      cost: 14, unlockAt: 2, days: 8, flowersIn: 1, yieldSeeds: 9,
      influence: { radius: 2, shade: 0.34, draw: 0.16, litter: 0.00, feed: 0.22 },
      bulk: 1.4,
      blurb: 'Pays best and eats most. The first real shade you can grow on purpose.',
      art: { form: 'stalkhead', foliage: 'mid', flower: 'gold', h: [12, 30, 58, 62], spread: [8, 14, 20, 22] },
    },
    {
      id: 'bluebell', name: 'Bluebell', latin: 'Hyacinthoides non-scripta',
      niche: { light: [0.20, 0.62], moisture: [0.35, 0.75], ph: [0.10, 0.55], nutrient: [0.20, 0.70] },
      cost: 16, unlockAt: 3, days: 10, flowersIn: 0, yieldSeeds: 6,
      influence: { radius: 1, shade: 0.05, draw: 0.05, litter: -0.01, feed: 0.05 },
      bulk: 0.7,
      blurb: 'Dappled light under something taller. It wants a neighbour, not an open bed.',
      art: { form: 'nodding', foliage: 'light', flower: 'blue', h: [8, 16, 25, 27], spread: [7, 13, 19, 21] },
    },
    {
      id: 'foxglove', name: 'Foxglove', latin: 'Digitalis purpurea',
      niche: { light: [0.22, 0.66], moisture: [0.38, 0.80], ph: [0.05, 0.50], nutrient: [0.25, 0.75] },
      cost: 18, unlockAt: 3, days: 12, flowersIn: 1, yieldSeeds: 8,
      influence: { radius: 1, shade: 0.14, draw: 0.08, litter: -0.02, feed: 0.09 },
      bulk: 1.1,
      blurb: 'A spire of bells at the edge of the shade. It marks where the wood begins.',
      art: { form: 'spire', foliage: 'mid', flower: 'purple', h: [11, 26, 52, 56], spread: [9, 15, 20, 22] },
    },
    {
      id: 'rhubarb', name: 'Rhubarb', latin: 'Rheum rhabarbarum',
      niche: { light: [0.40, 0.90], moisture: [0.45, 0.88], ph: [0.30, 0.70], nutrient: [0.60, 1.00] },
      cost: 22, unlockAt: 4, days: 13, flowersIn: 0, yieldSeeds: 10,
      influence: { radius: 2, shade: 0.26, draw: 0.19, litter: 0.03, feed: 0.26 },
      bulk: 1.6,
      blurb: 'Enormous leaves and a gross appetite. It shades and starves everything it touches.',
      art: { form: 'bigleaf', foliage: 'mid', flower: 'cream', stem: 'red', h: [11, 24, 42, 46], spread: [12, 24, 38, 40] },
    },
    {
      id: 'birch', name: 'Silver Birch', latin: 'Betula pendula',
      niche: { light: [0.50, 1.00], moisture: [0.25, 0.70], ph: [0.05, 0.55], nutrient: [0.15, 0.70] },
      cost: 30, unlockAt: 5, days: 18, flowersIn: 0, yieldSeeds: 7,
      influence: { radius: 3, shade: 0.52, draw: 0.22, litter: -0.05, feed: 0.14 },
      bulk: 2.4,
      blurb: 'The shade engine. Everything in the second half of this garden lives in its shadow.',
      art: { form: 'tree', foliage: 'light', flower: 'catkin', bark: 'birch', h: [14, 38, 78, 82], spread: [10, 26, 54, 56] },
    },
    {
      id: 'fern', name: 'Lady Fern', latin: 'Athyrium filix-femina',
      niche: { light: [0.00, 0.42], moisture: [0.50, 0.92], ph: [0.00, 0.45], nutrient: [0.20, 0.70] },
      cost: 26, unlockAt: 6, days: 12, flowersIn: 2, yieldSeeds: 9,
      influence: { radius: 1, shade: 0.15, draw: 0.09, litter: -0.03, feed: 0.08 },
      bulk: 1.1,
      blurb: 'No flower, only spores, and it will not tolerate an hour of open sun.',
      art: { form: 'frond', foliage: 'dark', flower: 'spore', h: [10, 24, 42, 45], spread: [12, 24, 38, 40] },
    },
    {
      id: 'hosta', name: 'Hosta', latin: 'Hosta sieboldiana',
      niche: { light: [0.00, 0.38], moisture: [0.48, 0.90], ph: [0.25, 0.70], nutrient: [0.35, 0.85] },
      cost: 28, unlockAt: 7, days: 13, flowersIn: 1, yieldSeeds: 10,
      influence: { radius: 1, shade: 0.17, draw: 0.10, litter: 0.00, feed: 0.11 },
      bulk: 1.2,
      blurb: 'Blue ribbed plates of leaf. A single hour of midday sun scorches it brown.',
      art: { form: 'mound', foliage: 'glaucous', flower: 'lilac', h: [9, 20, 34, 37], spread: [13, 26, 40, 42] },
    },
    {
      id: 'ramsons', name: 'Wild Garlic', latin: 'Allium ursinum',
      niche: { light: [0.00, 0.26], moisture: [0.55, 0.95], ph: [0.35, 0.80], nutrient: [0.30, 0.80] },
      cost: 34, unlockAt: 9, days: 14, flowersIn: 0, yieldSeeds: 12,
      influence: { radius: 1, shade: 0.09, draw: 0.07, litter: 0.01, feed: 0.07 },
      bulk: 0.9,
      blurb: 'The deepest shade in the garden, and the last thing you will ever press.',
      art: { form: 'strap', foliage: 'light', flower: 'white', h: [9, 19, 31, 34], spread: [12, 23, 35, 37] },
    },
  ];

  const BY_ID = Object.create(null);
  for (const s of LIST) {
    if (BY_ID[s.id]) throw new Error('species: duplicate id ' + s.id);
    BY_ID[s.id] = s;
  }

  /**
   * How well a species fits an environment, 0..1, as the WORST-FITTING AXIS rather than an
   * average. A plant in perfect light and bone-dry soil is a dying plant, and an average would
   * report it as merely mediocre — which is exactly the kind of softening that makes a simulation
   * unreadable to the player.
   */
  function fit(sp, env) {
    let worst = 1;
    let worstAxis = null;
    for (const axis of ['light', 'moisture', 'ph', 'nutrient']) {
      const [lo, hi] = sp.niche[axis];
      const v = env[axis];
      let f;
      if (v >= lo && v <= hi) f = 1;
      else {
        /* Distance outside the band, scaled by a tolerance so falling just outside is survivable
         * and falling far outside is not. TOL is deliberately generous: this game is about slow
         * decline you can see coming and answer with the shovel, not sudden death. */
        const TOL = 0.28;
        const d = v < lo ? lo - v : v - hi;
        f = Math.max(0, 1 - d / TOL);
      }
      if (f < worst) { worst = f; worstAxis = axis; }
    }
    return { fit: worst, axis: worstAxis };
  }

  /** The axis a struggling plant is struggling ON, in words the player can act upon. */
  function complaint(sp, env) {
    const r = fit(sp, env);
    if (r.fit >= 0.999) return null;
    const [lo, hi] = sp.niche[r.axis];
    const v = env[r.axis];
    const tooLow = v < lo;
    const WORDS = {
      light: ['too shaded here', 'scorching here'],
      moisture: ['too dry here', 'waterlogged here'],
      ph: ['soil too acid here', 'soil too limy here'],
      nutrient: ['ground too poor here', 'ground too rich here'],
    };
    return { axis: r.axis, tooLow, text: WORDS[r.axis][tooLow ? 0 : 1], fit: r.fit };
  }

  return { LIST, BY_ID, SEASONS, STAGES, fit, complaint };
});
