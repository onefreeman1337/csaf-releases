# ANNEAL

**Pour it big. Pour it right. You rarely get both.**

A free browser game. Nothing to install, nothing to buy, no account.

---

## What it is

You steer a stream of glowing motes up a foundry shaft.

The pour has two things, and they are not the same thing:

- a **COUNT** — how many motes you are carrying
- a **TEMPER** — what those motes are made of: **EMBER**, **FROST** or **IRON**

Set into the shaft are **crucibles**. Every crucible changes your count, and some change your
temper as well. A crucible reading `×4 EMBER` multiplies you by four **and** makes you ember. You
pass through exactly one crucible per row, so every row is a choice.

The shaft is also **flawed**, and each flaw only yields to one temper:

| flaw | yields to | looks like |
| --- | --- | --- |
| **SEAL** | EMBER | a wax disc with a struck stamp |
| **RACE** | FROST | a torrent of horizontal streaks |
| **SLAGWALL** | IRON | courses of rough blocks |

Each flaw also wants a **minimum** number of motes, and passing one **costs** you some.

**That is the whole game:** the crucible that gives you the count you need is frequently the one
that gives you the wrong temper for the flaw two rows later. **Arriving big and wrong is a loss.**

## Controls

| | |
| --- | --- |
| **Mouse** or **A** / **D** or **←** / **→** | steer the pour |
| **Space** or **R** | Reheat — turn the pour to the next temper (costs a charge) |
| **Esc** | leave a pour |

The spout slides sideways at a finite speed, so a last-instant change of mind does not always
arrive in time. That limit is the game, not a nuisance.

## The kiln

Clearing a channel earns **slag**. Slag buys permanent upgrades, and they never go away:

- **SECOND SPOUT** — start every pour with more motes
- **EMBER / FROST / IRON AFFINITY** — that temper's flaws demand fewer motes
- **REHEAT** — mid-pour changes of temper. The scarcest thing in the foundry.
- **FARSIGHT** — read the crucibles further up the shaft before you must commit
- **DRAW** — every flaw costs fewer motes to pass
- **BELLOWS** — the shaft comes at you with less hurry

## If you lose

**A shattered pour costs you that pour and nothing else.** The kiln, your slag and every channel
you have already cleared are untouched. You start that channel again from the mouth. There is no
run to lose and nothing to grind back.

## It ends

Twelve channels, and then it is over. It is meant to be finished, not farmed.

## Saving

Progress is saved in your browser automatically, after every pour. Clearing your browser's site
data for itch.io will clear it.

---

## Credits and disclosure

Made by **Core Systems Asset Factory**.

This game is AI-assisted and the listing says so, in full:

- **Code — yes.** Written with AI assistance.
- **Graphics — yes.** The cover illustration is AI-generated. Everything inside the game is not:
  the crucible and flaw marks are generated procedurally by the game itself from each gate's own
  numbers, and the four stone surfaces are made by our own procedural tile forge.
- **Sounds — no.** Every sound effect and the music loop are procedurally synthesised from
  oscillators. No generative-audio model was used and no third-party audio was licensed.
- **Text — yes.** The writing is AI-assisted.

More free browser games and the rest of the catalogue: **https://csaf.itch.io**

Licence: see `LICENSE.txt`. Third-party components and their licences: see `CREDITS.txt`.
