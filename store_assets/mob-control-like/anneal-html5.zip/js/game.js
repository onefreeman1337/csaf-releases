/**
 * game.js — screens, input, the frame loop. The thin layer that turns run.js into a game.
 *
 * ⛔ IT HOLDS NO RULES AND NO ARITHMETIC OF ITS OWN. Everything the player reads — the count, the
 * temper, whether the next flaw will accept them — is computed by calling the same functions that
 * decide the outcome (`CHANNEL.applySlot`, `RUN.*`). That is the property this wing's best-
 * reviewed title earned its reviews for: a preview that IS the resolution cannot lie.
 *
 * ⚠️ EVERY STRING DRAWN HERE GOES THROUGH `ART.text` OR `ART.paragraph`. Internal_Ops/test_layout.js
 * works by replacing `ART.text` with a recorder; a helper that formats its own text with
 * ctx.fillText would be invisible to it, which is precisely how FLOODMARK shipped four lines
 * running 75px off the canvas under 133 green assertions (wing §3e-1).
 */
'use strict';

(function () {
  var W = 960, H = 620;

  // shaft viewport, in screen coordinates
  var SX = 34, SY = 18, SW = 560, SH = 584;
  var HX = 618, HY = 18, HW = 324, HH = 584;

  var canvas, ctx, save, run = null, channelIndex = 0;
  var screen = 'title';
  var last = 0, time = 0, shake = 0, flash = null;
  var pointer = { x: SX + SW / 2, inside: false };
  var particles = [];
  var trail = [];
  var buttons = [];          // rebuilt every frame; hit-tested on click
  var message = null, messageAt = 0;
  var bgSeed = 1;

  var CH = typeof CHANNEL !== 'undefined' ? CHANNEL : null;
  var CHS = typeof CHANNELS_DATA !== 'undefined' ? CHANNELS_DATA.CHANNELS : [];

  /* ══════════════════════════════════════ helpers ═══════════════════════════════════════════ */

  function say(m) { message = m; messageAt = time; }

  function channel() { return CHS[channelIndex]; }

  /** Screen y for a channel-space y, given the camera. */
  function camY() {
    if (!run) return 0;
    var top = RUN.summitY(run.ch) - SH;
    var want = run.y - SH * 0.30;
    return Math.max(0, Math.min(Math.max(0, top), want));
  }
  function scrY(cy) { return SY + SH - (cy - camY()); }
  function scrX(cx) { return SX + cx; }

  /**
   * The next flaw row ahead of the pour, and whether the pour currently satisfies each of its
   * demands. ⛔ Computed by asking CHANNEL.applySlot, never by re-implementing the comparison —
   * a second copy of the rule is a second thing that can drift.
   */
  function nextFlaw(r) {
    for (var i = r.nextRow; i < r.ch.rows.length; i++) {
      var row = r.ch.rows[i];
      var flaws = row.filter(function (s) { return s.kind === 'flaw'; });
      if (!flaws.length) continue;
      return {
        row: i,
        rowsAway: i - r.nextRow,
        options: flaws.map(function (s) {
          var res = CH.applySlot({ count: r.count, temper: r.temper }, s);
          return { slot: s, ok: res.ok, reason: res.reason };
        }),
      };
    }
    return null;
  }

  function addParticles(x, y, colour, n, speed) {
    for (var i = 0; i < n; i++) {
      var a = Math.random() * Math.PI * 2;
      var s = speed * (0.35 + Math.random() * 0.9);
      particles.push({ x: x, y: y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 30, life: 0.5 + Math.random() * 0.6, age: 0, c: colour, r: 1.4 + Math.random() * 2.6 });
    }
  }

  /* ══════════════════════════════════════ input ═════════════════════════════════════════════ */

  function pointerAt(e) {
    var rect = canvas.getBoundingClientRect();
    var p = (e.touches && e.touches[0]) || e;
    // ⚠️ The canvas is CSS-scaled to fit the itch embed, so client pixels are NOT canvas pixels.
    // Deriving the scale from the rect each time is what keeps steering accurate at every size.
    return {
      x: (p.clientX - rect.left) * (W / rect.width),
      y: (p.clientY - rect.top) * (H / rect.height),
    };
  }

  function onMove(e) {
    var p = pointerAt(e);
    pointer.x = p.x; pointer.y = p.y; pointer.inside = true;
    if (screen === 'pour' && run && p.x >= SX - 60 && p.x <= SX + SW + 60) RUN.steer(run, p.x - SX);
  }

  function onDown(e) {
    var p = pointerAt(e);
    pointer.x = p.x; pointer.y = p.y;
    for (var i = buttons.length - 1; i >= 0; i--) {
      var b = buttons[i];
      if (p.x >= b.x && p.x <= b.x + b.w && p.y >= b.y && p.y <= b.y + b.h) { b.fn(); return; }
    }
    if (screen === 'pour' && run) RUN.steer(run, p.x - SX);
  }

  function onKey(e) {
    var k = e.key;
    if (screen === 'pour' && run) {
      if (k === 'ArrowLeft' || k === 'a' || k === 'A') { RUN.nudge(run, -1); e.preventDefault(); }
      else if (k === 'ArrowRight' || k === 'd' || k === 'D') { RUN.nudge(run, 1); e.preventDefault(); }
      else if (k === ' ' || k === 'r' || k === 'R') { doReheat(); e.preventDefault(); }
      else if (k === 'Escape') { screen = 'map'; run = null; }
      return;
    }
    if (k === 'Enter' || k === ' ') {
      if (screen === 'title') screen = 'map';
      else if (screen === 'result') afterResult();
      e.preventDefault();
    }
    if (k === 'Escape' && (screen === 'kiln' || screen === 'help')) screen = 'map';
  }

  function doReheat() {
    if (!run) return;
    var r = RUN.reheat(run);
    if (!r.ok) { say(r.reason === 'no-charges' ? 'NO REHEAT LEFT' : 'NOT POURING'); return; }
    say('REHEAT — ' + ART.temperOf(run.temper).name);
    addParticles(scrX(run.x), scrY(run.y), ART.temperOf(run.temper).base, 26, 150);
    SOUND.play('reheat');
  }

  /* ══════════════════════════════════════ flow ══════════════════════════════════════════════ */

  function startChannel(i) {
    channelIndex = i;
    run = RUN.create(CHS[i], save.kiln);
    trail = []; particles = []; shake = 0; flash = null;
    save.seen[CHS[i].id] = true;
    KILN.save(save);
    screen = 'pour';
    SOUND.play('pour');
    SOUND.music(true);
  }

  var lastReward = null, lastCleared = false;

  function finishRun() {
    lastCleared = run.status === 'cleared';
    lastReward = KILN.record(save, channel().id, run, RUN);
    KILN.save(save);
    screen = 'result';
    SOUND.play(lastCleared ? 'clear' : 'shatter');
  }

  function afterResult() {
    if (lastCleared && KILN.finished(save, CHS)) { screen = 'end'; return; }
    screen = 'map';
    run = null;
  }

  /* ══════════════════════════════════════ update ════════════════════════════════════════════ */

  function update(dt) {
    time += dt;
    if (shake > 0) shake = Math.max(0, shake - dt * 3.4);
    if (flash && time - flash.at > 0.4) flash = null;
    if (message && time - messageAt > 2.2) message = null;

    for (var i = particles.length - 1; i >= 0; i--) {
      var p = particles[i];
      p.age += dt;
      if (p.age >= p.life) { particles.splice(i, 1); continue; }
      p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 220 * dt;
    }

    if (screen !== 'pour' || !run) return;

    var events = RUN.tick(run, dt);
    for (var e = 0; e < events.length; e++) handleEvent(events[e]);

    // the trail is a ribbon of past positions — recorded here so it is FRAME-RATE independent
    trail.push({ x: run.x, y: run.y, t: run.temper });
    if (trail.length > 34) trail.shift();

    if (run.status !== 'pouring') finishRun();
  }

  function handleEvent(ev) {
    if (ev.type === 'gate') {
      var T = ART.temperOf(ev.after.temper);
      addParticles(scrX(run.x), scrY(RUN.rowY(ev.row)), T.base, 18, 130);
      flash = { at: time, colour: T.base, a: 0.16 };
      SOUND.play(ev.slotRef && ev.slotRef.temper ? 'temper' : 'gate');
    } else if (ev.type === 'flaw') {
      if (ev.ok) {
        addParticles(scrX(run.x), scrY(RUN.rowY(ev.row)), ART.PAL.gold, 30, 190);
        shake = 0.5;
        SOUND.play('break');
      }
    } else if (ev.type === 'fail') {
      addParticles(scrX(run.x), scrY(run.y), ART.PAL.blood, 44, 230);
      shake = 1;
      flash = { at: time, colour: ART.PAL.blood, a: 0.3 };
    } else if (ev.type === 'clear') {
      addParticles(scrX(run.x), scrY(run.y), ART.PAL.gold, 60, 250);
      flash = { at: time, colour: ART.PAL.gold, a: 0.25 };
    }
  }

  /* ══════════════════════════════════════ draw ══════════════════════════════════════════════ */

  function button(x, y, w, h, label, fn, o) {
    o = o || {};
    var hot = pointer.x >= x && pointer.x <= x + w && pointer.y >= y && pointer.y <= y + h;
    var accent = o.accent || (o.disabled ? ART.PAL.stoneHi : ART.PAL.gold);
    ART.panel(ctx, x, y, w, h, {
      tint: o.disabled ? ART.PAL.stoneLo : (hot ? ART.PAL.goldDim : ART.PAL.pit),
      tintA: o.disabled ? 0.8 : (hot ? 0.5 : 0.72),
      accent: accent, rivets: h > 30,
    });
    ART.text(ctx, label, x + w / 2, y + h / 2 + Math.round(h * 0.16),
      o.size || Math.min(19, Math.round(h * 0.42)),
      o.disabled ? ART.PAL.paperDim : (hot ? ART.PAL.paper : ART.PAL.paper), 'center', 2.4);
    if (!o.disabled) buttons.push({ x: x, y: y, w: w, h: h, fn: fn });
    return hot;
  }

  function backdrop() {
    ART.fillPlate(ctx, 0, 0, W, H, 'wall', ART.PAL.void, 0.72);
    // a slow drift of dying sparks, so no screen in the game is ever a flat colour field
    var rd = ART.prng(bgSeed);
    for (var i = 0; i < 46; i++) {
      var bx = rd() * W;
      var speed = 8 + rd() * 26;
      var by = (H + 40 - ((time * speed + rd() * H * 2) % (H + 80)));
      var a = 0.05 + rd() * 0.16;
      ctx.globalAlpha = a;
      ART.mote(ctx, bx, by, 1.6 + rd() * 2.2, rd() < 0.5 ? 'ember' : (rd() < 0.5 ? 'frost' : 'iron'), i * 977 + 3, a);
      ctx.globalAlpha = 1;
    }
  }

  function drawParticles() {
    for (var i = 0; i < particles.length; i++) {
      var p = particles[i];
      var k = 1 - p.age / p.life;
      ctx.globalAlpha = k;
      ctx.fillStyle = p.c;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r * k, 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  /* ── the shaft ────────────────────────────────────────────────────────────────────────────── */

  function drawShaft() {
    var r = run;
    ART.clipTo(ctx, SX, SY, SW, SH);
    ART.fillPlate(ctx, SX, SY, SW, SH, 'shaft', ART.PAL.pit, 0.5);

    // the walls: a vertical bevel down each side so the shaft reads as a cut channel
    var g = ctx.createLinearGradient(SX, 0, SX + SW, 0);
    g.addColorStop(0, ART.rgba(ART.PAL.void, 0.85));
    g.addColorStop(0.14, ART.rgba(ART.PAL.void, 0));
    g.addColorStop(0.86, ART.rgba(ART.PAL.void, 0));
    g.addColorStop(1, ART.rgba(ART.PAL.void, 0.85));
    ctx.fillStyle = g; ctx.fillRect(SX, SY, SW, SH);

    // the crucible mouth at the summit
    var sumY = scrY(RUN.summitY(r.ch));
    if (sumY > SY - 80 && sumY < SY + SH + 80) {
      ctx.fillStyle = ART.rgba(ART.PAL.gold, 0.1);
      ctx.fillRect(SX, sumY - 8, SW, 16);
      ART.rule(ctx, SX + 20, sumY, SW - 40, ART.PAL.gold);
      ART.text(ctx, 'CRUCIBLE   ≥ ' + r.ch.goal, SX + SW / 2, sumY - 16, 17, ART.PAL.gold, 'center', 4);
    }

    // rows
    for (var i = 0; i < r.ch.rows.length; i++) {
      var y = scrY(RUN.rowY(i));
      if (y < SY - 130 || y > SY + SH + 130) continue;
      var row = r.ch.rows[i];
      var legible = RUN.legible(r, i);
      var done = i < r.nextRow;
      var boxH = 104, gap = 10;
      var boxW = SW / row.length - gap;

      ctx.globalAlpha = done ? 0.34 : 1;
      for (var j = 0; j < row.length; j++) {
        var cx = scrX(RUN.slotX(row.length, j));
        var slot = row[j];
        var aiming = !done && i === r.nextRow && RUN.slotAt(row.length, r.targetX) === j;
        var pulse = aiming ? 0.5 + 0.5 * Math.sin(time * 7) : 0;
        if (slot.kind === 'gate') ART.gateFace(ctx, cx, y, boxW, boxH, slot, legible, pulse);
        else if (slot.kind === 'flaw') {
          var sat = CH.applySlot({ count: r.count, temper: r.temper }, slot).ok;
          ART.flawFace(ctx, cx, y, boxW, boxH, slot, legible, sat);
        } else ART.emptyFace(ctx, cx, y, boxW, boxH);

        if (aiming) {
          ctx.strokeStyle = ART.rgba(ART.PAL.gold, 0.55 + 0.35 * Math.sin(time * 7));
          ctx.lineWidth = 2;
          ctx.strokeRect(cx - boxW / 2 - 3, y - boxH / 2 - 3, boxW + 6, boxH + 6);
        }
      }
      ctx.globalAlpha = 1;
    }

    drawPour();
    ART.unclip(ctx);

    // shaft frame, outside the clip so it always reads as a housing
    ART.panel(ctx, SX - 8, SY - 8, SW + 16, SH + 16, { plate: false, fill: 'rgba(0,0,0,0)', rivets: true });
  }

  function drawPour() {
    var r = run;
    var px = scrX(r.x), py = scrY(r.y);

    // the spout at the bottom of the channel
    var spoutY = scrY(0);
    if (spoutY < SY + SH + 60) {
      ctx.fillStyle = ART.rgba(ART.PAL.stone, 0.95);
      ctx.fillRect(SX, spoutY, SW, SY + SH - spoutY + 10);
      ART.rule(ctx, SX + 16, spoutY, SW - 32, ART.PAL.stoneHi);
    }

    // the ribbon
    for (var i = 0; i < trail.length; i++) {
      var t = trail[i];
      var k = i / trail.length;
      ART.mote(ctx, scrX(t.x), scrY(t.y), 2 + k * 4.5, t.t, i * 131 + 7, 0.10 + k * 0.5);
    }

    // the head: a cluster whose SIZE grows with the count, so "big" is felt before it is read
    var T = ART.temperOf(r.temper);
    var n = Math.max(3, Math.min(22, Math.round(Math.log(r.count + 1) * 5)));
    for (var m = 0; m < n; m++) {
      var a = (m / n) * Math.PI * 2 + time * 1.6;
      var rad = 7 + (m % 4) * 5.5 + Math.sin(time * 3 + m) * 2;
      ART.mote(ctx, px + Math.cos(a) * rad, py + Math.sin(a) * rad * 0.75, 3 + (m % 3), r.temper, m * 61 + 11, 0.85);
    }
    ctx.save();
    ctx.shadowColor = ART.rgba(T.base, 0.95); ctx.shadowBlur = 26;
    ctx.fillStyle = T.hi;
    ctx.beginPath(); ctx.arc(px, py, 9, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    ART.text(ctx, String(r.count), px, py - 22, 24, ART.PAL.paper, 'center', 1.4, 700);
  }

  /* ── the HUD ──────────────────────────────────────────────────────────────────────────────── */

  function drawHud() {
    var r = run;
    ART.panel(ctx, HX, HY, HW, HH, { accent: ART.PAL.goldDim });
    var x = HX + 20, w = HW - 40, y = HY + 42;

    ART.text(ctx, channel().name.toUpperCase(), HX + HW / 2, y, 20, ART.PAL.gold, 'center', 3.6);
    y += 12;
    ART.rule(ctx, x, y, w, ART.PAL.goldDim);
    y += 34;

    // count + temper crest
    ART.crest(ctx, x + 34, y + 8, 30, r.temper, true);
    ART.text(ctx, String(r.count), x + 82, y + 22, 46, ART.PAL.paper, 'left', 1, 700);
    ART.text(ctx, 'MOTES', x + 82, y + 42, 12, ART.PAL.paperDim, 'left', 3.4);
    ART.text(ctx, ART.temperOf(r.temper).name, x + w, y - 2, 17, ART.temperOf(r.temper).base, 'right', 3);
    ART.text(ctx, 'TEMPER', x + w, y + 16, 11, ART.PAL.paperDim, 'right', 3);
    y += 74;

    ART.rule(ctx, x, y, w, ART.PAL.stoneHi);
    y += 30;

    // the next demand — the single most important readout in the game
    var nf = nextFlaw(r);
    ART.text(ctx, 'NEXT FLAW', x, y, 12, ART.PAL.paperDim, 'left', 3.4);
    y += 26;
    if (!nf) {
      ART.text(ctx, 'CLEAR SHAFT AHEAD', x, y, 16, ART.PAL.paper, 'left', 1.6);
      y += 30;
    } else {
      for (var i = 0; i < nf.options.length; i++) {
        var o = nf.options[i];
        var T = ART.temperOf(o.slot.demand);
        /* ⚠️ SIZES AND WORDING CUT UNTIL THE TWO COLUMNS CANNOT MEET. On a three-flaw row the
         * longest pair rendered as "SLAGWALL  ≥4WRONG TEMPER" — no gap at all. The layout gate
         * passed it because the boxes are ADJACENT, not overlapping, and adjacency is legal
         * everywhere else. Two strings touching is a defect a person sees and arithmetic does
         * not, which is why looking is still a required step. */
        ART.crest(ctx, x + 16, y - 5, 14, o.slot.demand, o.ok);
        var verdict = o.ok ? 'PASSES' : (o.reason === 'wrong-temper' ? 'WRONG' : (o.reason === 'too-few' ? 'TOO FEW' : 'SPENDS ALL'));
        var vW = ART.measure(ctx, verdict, 11, 1.6);
        var labelMax = w - 38 - vW - 14;
        var label = (o.slot.label || T.flaw) + '  ≥' + o.slot.threshold;
        // and if even the short form would collide, drop the threshold rather than let them touch
        if (ART.measure(ctx, label, 14, 1.2) > labelMax) label = (o.slot.label || T.flaw);
        ART.text(ctx, label, x + 38, y, 14, o.ok ? ART.PAL.paper : ART.PAL.paperDim, 'left', 1.2);
        ART.text(ctx, verdict, x + w, y, 11, o.ok ? '#7fca6a' : ART.PAL.blood, 'right', 1.6);
        y += 26;
      }
      ART.text(ctx, nf.rowsAway === 0 ? 'NOW' : nf.rowsAway + ' ROW' + (nf.rowsAway > 1 ? 'S' : '') + ' AHEAD',
        x, y, 11, ART.PAL.paperDim, 'left', 3);
      y += 24;
    }

    ART.rule(ctx, x, y, w, ART.PAL.stoneHi);
    y += 30;

    // reheat
    ART.text(ctx, 'REHEAT', x, y, 12, ART.PAL.paperDim, 'left', 3.4);
    for (var c = 0; c < Math.max(1, save.kiln.reheat); c++) {
      var filled = c < r.reheats;
      ctx.beginPath();
      ctx.arc(x + w - 12 - c * 22, y - 4, 7, 0, Math.PI * 2);
      ctx.fillStyle = filled ? ART.rgba(ART.PAL.gold, 0.9) : ART.rgba(ART.PAL.stoneHi, 0.5);
      ctx.fill();
      ctx.strokeStyle = ART.rgba(ART.PAL.goldDim, 0.9); ctx.lineWidth = 1; ctx.stroke();
    }
    y += 16;
    button(x, y, w, 38, r.reheats > 0 ? 'RETEMPER  [SPACE]' : 'NO CHARGES', doReheat, { disabled: r.reheats <= 0, size: 15 });
    y += 54;

    ART.rule(ctx, x, y, w, ART.PAL.stoneHi);
    y += 28;
    ART.text(ctx, 'GOAL', x, y, 12, ART.PAL.paperDim, 'left', 3.4);
    ART.text(ctx, '≥ ' + r.ch.goal, x + w, y, 18, ART.PAL.gold, 'right', 1.4);
    y += 26;
    ART.text(ctx, 'ROW', x, y, 12, ART.PAL.paperDim, 'left', 3.4);
    ART.text(ctx, Math.min(r.nextRow + 1, r.ch.rows.length) + ' / ' + r.ch.rows.length, x + w, y, 16, ART.PAL.paper, 'right', 1.4);
    y += 34;

    /* ⛔ THE HINT ONLY GETS THE ROOM THAT IS ACTUALLY LEFT. The HUD above it is variable height —
     * a row with three flaws pushes everything down by two lines — so a fixed paragraph ran under
     * the ABANDON button and lost its last line behind the panel. Draw the lines that fit and drop
     * the rest; a hint is the one thing on this HUD that can afford to be shorter. */
    var abandonTop = HY + HH - 46;
    var hintLines = ART.wrap(ctx, 'Steer with the mouse or A and D. The crucible you are over when the pour reaches it is the one that takes you.', 12, w, 0.4);
    for (var h = 0; h < hintLines.length; h++) {
      var ly2 = y + h * 18;
      if (ly2 + 6 > abandonTop - 8) break;
      ART.text(ctx, hintLines[h], x, ly2, 12, ART.PAL.paperDim, 'left', 0.4);
    }

    button(HX + 20, abandonTop, HW - 40, 32, 'ABANDON  [ESC]', function () { screen = 'map'; run = null; }, { size: 14 });
  }

  /* ── screens ──────────────────────────────────────────────────────────────────────────────── */

  function drawTitle() {
    backdrop();
    var cx = W / 2;
    ART.text(ctx, 'ANNEAL', cx, 200, 84, ART.PAL.gold, 'center', 18, 700);
    ART.rule(ctx, cx - 220, 224, 440, ART.PAL.goldDim);
    ART.text(ctx, 'POUR IT BIG. POUR IT RIGHT. YOU RARELY GET BOTH.', cx, 258, 17, ART.PAL.paper, 'center', 3.6);
    // ⚠️ x IS THE CENTRE when align is 'center' — passing cx-300 (the left edge of the column) drew
    // every line centred on x=180 and ran them to -115px, off the left of the canvas. Caught by the
    // layout gate, invisible to every other check. Same bug existed on the end and result screens.
    ART.paragraph(ctx,
      'A stream of motes climbs a foundry shaft. Every crucible changes how many you have AND what they are made of, and every flaw in the shaft only yields to one temper. Arriving big and wrong is still a loss.',
      cx, 306, 15, ART.PAL.paperDim, 600, 24, 'center', 0.5);

    ART.crest(ctx, cx - 96, 400, 26, 'ember', true);
    ART.crest(ctx, cx, 400, 26, 'frost', true);
    ART.crest(ctx, cx + 96, 400, 26, 'iron', true);

    button(cx - 118, 452, 236, 52, save.poured ? 'RETURN TO THE FOUNDRY' : 'LIGHT THE FOUNDRY', function () { screen = 'map'; SOUND.unlock(); }, { size: 17 });
    button(cx - 118, 516, 112, 36, 'HOW', function () { screen = 'help'; }, { size: 14 });
    button(cx + 6, 516, 112, 36, SOUND.enabled() ? 'SOUND ON' : 'SOUND OFF', function () { SOUND.toggle(); }, { size: 14 });
    ART.text(ctx, 'CORE SYSTEMS ASSET FACTORY', cx, 596, 11, ART.PAL.paperDim, 'center', 4);
  }

  function drawMap() {
    backdrop();
    ART.panel(ctx, 30, 18, W - 60, 74, { accent: ART.PAL.goldDim });
    ART.text(ctx, 'THE FOUNDRY', 56, 62, 30, ART.PAL.gold, 'left', 7, 700);
    // ⚠️ The slag readout sat right-aligned at W-56 and ran straight through the HOW button. Four
    // digits of slag is normal by mid-campaign, so this was not an edge case — it was the default
    // once the player had earned anything. It now lives LEFT of both buttons.
    ART.text(ctx, String(save.slag), W - 320, 54, 30, ART.PAL.paper, 'right', 1, 700);
    ART.text(ctx, 'SLAG', W - 320, 74, 11, ART.PAL.paperDim, 'right', 3.6);
    button(W - 300, 32, 116, 44, 'THE KILN', function () { screen = 'kiln'; }, { size: 15 });
    button(W - 174, 32, 76, 44, 'HOW', function () { screen = 'help'; }, { size: 14 });

    var open = KILN.unlockedCount(save, CHS);
    // ⚠️ 120px tall, not 108: BEST shared a baseline with "N ROWS GOAL n" and the two overprinted
    // by up to 29px once either number reached four digits (last-heat's best is 2052 in normal
    // play). A row of its own is the fix; squeezing the type would only move the collision.
    var cols = 4, cw = 208, chh = 130, gx = 30, gy = 100;
    for (var i = 0; i < CHS.length; i++) {
      var c = CHS[i];
      var col = i % cols, rowI = Math.floor(i / cols);
      var x = gx + col * (cw + 20), y = gy + rowI * (chh + 16);
      var unlocked = i < open;
      var cleared = !!save.cleared[c.id];
      var accent = cleared ? ART.PAL.gold : (unlocked ? ART.PAL.paperDim : ART.PAL.stoneHi);
      ART.panel(ctx, x, y, cw, chh, { tint: unlocked ? ART.PAL.pit : ART.PAL.stoneLo, tintA: unlocked ? 0.7 : 0.9, accent: accent });

      // ⚠️ EVERY CARD GETS A STAMP, not just the cleared ones. Sealed channels were four empty
      // rectangles with the word SEALED in them — the exact "text-only card list on the screen
      // that sells the next unlock" that §3e names as where this wing loses Gate 1. The stamp is
      // the game's own generator at three brightnesses, so a locked card still looks made.
      // The channel's stamp wears the temper the pour STARTS in — so the campaign board reads as a
      // sequence of tempers at a glance, and the screen stops being one gold hue on dark stone.
      var cT = ART.temperOf(c.start.temper);
      ART.sigil(ctx, x + cw - 32, y + 34, 16, ART.hash('channel|' + c.id),
        cleared ? cT.base : (unlocked ? ART.PAL.paperDim : ART.PAL.stoneHi), cleared);

      ART.text(ctx, String(i + 1).padStart(2, '0'), x + 14, y + 30, 15, accent, 'left', 2);
      ART.text(ctx, unlocked ? c.name.toUpperCase() : 'SEALED', x + 14, y + 58, 17, unlocked ? ART.PAL.paper : ART.PAL.paperDim, 'left', 2);
      ART.text(ctx, unlocked ? c.rows.length + ' ROWS   ·   GOAL ' + c.goal : 'CLEAR ' + String(i).padStart(2, '0') + ' TO OPEN',
        x + 14, y + 80, 12, ART.PAL.paperDim, 'left', 1.6);
      if (cleared) {
        ART.text(ctx, 'BEST ARRIVAL ' + (save.best[c.id] || 0), x + 14, y + 102, 12, ART.PAL.gold, 'left', 1.6);
      } else if (unlocked) {
        ART.text(ctx, 'NOT YET POURED', x + 14, y + 102, 12, ART.PAL.paperDim, 'left', 1.6);
      }
      if (unlocked) (function (idx) { buttons.push({ x: x, y: y, w: cw, h: chh, fn: function () { startChannel(idx); } }); })(i);
    }

    var doneN = CHS.filter(function (c) { return save.cleared[c.id]; }).length;
    ART.text(ctx, doneN + ' OF ' + CHS.length + ' CHANNELS POURED   ·   ' + save.poured + ' POURS   ·   ' + save.lost + ' LOST',
      W / 2, H - 22, 12, ART.PAL.paperDim, 'center', 2.6);
  }

  function drawKiln() {
    backdrop();
    ART.panel(ctx, 30, 18, W - 60, 66, { accent: ART.PAL.goldDim });
    ART.text(ctx, 'THE KILN', 56, 58, 26, ART.PAL.gold, 'left', 7, 700);
    ART.text(ctx, String(save.slag) + '  SLAG', W - 200, 58, 20, ART.PAL.paper, 'right', 2);
    button(W - 174, 28, 130, 44, 'BACK  [ESC]', function () { screen = 'map'; }, { size: 14 });

    // ⚠️ 186px cards, not 156, and a ledger strip below them. At 156 the bottom THIRD of this
    // screen was empty shaft — Gate 1 asks "is any composite >20% empty?" and this was about 30%.
    // The REHEAT card's third blurb line also sat flush on its own price bar with 4px of clearance.
    // Both are fixed by giving the cards the room the screen already had.
    var cols = 4, cw = 208, chh = 186, gx = 30, gy = 98;
    for (var i = 0; i < KILN.TRACKS.length; i++) {
      var t = KILN.TRACKS[i];
      var col = i % cols, rowI = Math.floor(i / cols);
      var x = gx + col * (cw + 20), y = gy + rowI * (chh + 16);
      var lvl = save.kiln[t.id] || 0;
      var cost = KILN.nextCost(save, t.id);
      var afford = cost !== null && save.slag >= cost;
      var accent = lvl ? ART.PAL.gold : ART.PAL.stoneHi;

      // ⭐ AN AFFINITY TRACK WEARS ITS OWN TEMPER. All eight cards were drawn in the same gold,
      // which was both a missed piece of information (EMBER AFFINITY should look like ember) and
      // the reason this screen measured 232 colours against the Gate 1 floor. Colouring by meaning
      // is the fix §3e prescribes — the mark comes from the game's own renderer at the real data.
      var tint = ART.TEMPER[t.id] ? ART.TEMPER[t.id].base : ART.PAL.gold;
      var tintHi = ART.TEMPER[t.id] ? ART.TEMPER[t.id].hi : ART.PAL.gold;
      accent = lvl ? tint : ART.PAL.stoneHi;

      ART.panel(ctx, x, y, cw, chh, { tint: ART.PAL.pit, tintA: 0.72, accent: accent });
      // ⭐ §3e: the upgrade screen gets a mark from the game's OWN generator, not an icon set.
      ART.sigil(ctx, x + 32, y + 34, 20, ART.hash('kiln|' + t.id), lvl ? tint : ART.PAL.paperDim, !!lvl);
      ART.text(ctx, t.name, x + 60, y + 28, 13, ART.PAL.paper, 'left', 1.8);
      ART.text(ctx, t.effect(lvl), x + 60, y + 46, 12, lvl ? tintHi : ART.PAL.paperDim, 'left', 0.6);

      // level pips
      for (var p = 0; p < t.costs.length; p++) {
        var px = x + 14 + p * 15, py = y + 62;
        ctx.beginPath(); ctx.moveTo(px, py - 5); ctx.lineTo(px + 5, py); ctx.lineTo(px, py + 5); ctx.lineTo(px - 5, py); ctx.closePath();
        ctx.fillStyle = p < lvl ? ART.rgba(tint, 0.95) : ART.rgba(ART.PAL.stoneHi, 0.55); ctx.fill();
      }

      ART.paragraph(ctx, t.blurb, x + 14, y + 92, 12, ART.PAL.paperDim, cw - 28, 17, 'left', 0.3);

      if (cost === null) {
        ART.text(ctx, 'MASTERED', x + cw / 2, y + chh - 18, 13, ART.PAL.gold, 'center', 3);
      } else {
        (function (id) {
          button(x + 12, y + chh - 38, cw - 24, 28, cost + ' SLAG', function () {
            var r = KILN.buy(save, id);
            if (r.ok) { KILN.save(save); say('KILN RAISED'); SOUND.play('buy'); }
            else say(r.reason === 'too-poor' ? 'NEED ' + r.short + ' MORE SLAG' : 'ALREADY MASTERED');
          }, { size: 13, disabled: !afford });
        })(t.id);
      }
    }

    /* THE FOUNDRY LEDGER — it fills the space the taller cards did not, and it fills it with
     * information rather than decoration: what the kiln has actually done for this player. A
     * progression screen that cannot tell you whether progression is working is a shop, not a meta. */
    var ly = gy + 2 * (chh + 14) + 6;
    ART.panel(ctx, gx, ly, W - gx * 2, 62, { accent: ART.PAL.stoneHi });
    var doneN = CHS.filter(function (c) { return save.cleared[c.id]; }).length;
    var lvls = KILN.TRACKS.reduce(function (a, t) { return a + (save.kiln[t.id] || 0); }, 0);
    var caps = KILN.TRACKS.reduce(function (a, t) { return a + t.costs.length; }, 0);
    var stats = [
      // ⚠️ Short labels. "CHANNELS POURED" and "KILN RAISED" left only ~20px between columns and
      // read as one run-on string — legal by the overlap gate, cramped to the eye. The gate
      // measures collisions, not breathing room; that part is still a job for looking.
      ['CHANNELS', doneN + ' / ' + CHS.length],
      ['KILN LEVELS', lvls + ' / ' + caps],
      ['POURS', String(save.poured)],
      ['SHATTERED', String(save.lost)],
      ['SLAG', String(save.slag)],
    ];
    for (var q = 0; q < stats.length; q++) {
      var sx = gx + 30 + q * ((W - gx * 2 - 60) / stats.length);
      ART.text(ctx, stats[q][0], sx, ly + 26, 11, ART.PAL.paperDim, 'left', 3);
      ART.text(ctx, stats[q][1], sx, ly + 50, 18, ART.PAL.paper, 'left', 1.4);
    }

    ART.text(ctx, 'SLAG IS EARNED BY CLEARING A CHANNEL. EVERY UPGRADE IS PERMANENT.',
      W / 2, H - 14, 12, ART.PAL.paperDim, 'center', 2.6);
  }

  /**
   * The shaft as a BACKDROP for a loss: plates, walls, the pour where it stopped, and a marked
   * band on the row that stopped it. No labels and no numbers.
   *
   * ⚠️ IT IS NOT `drawShaft()` DIMMED, AND THE FIRST VERSION WAS. Reusing the full renderer under
   * a 74% scrim drew every crucible label and flaw threshold at ~26% opacity underneath an opaque
   * panel — invisible in the output, and the layout gate correctly reported three overprints
   * because a string drawn under another string IS an overprint as far as anything can tell. The
   * honest fix was not to teach the gate about opacity: a label at 26% behind a scrim is noise
   * rather than information, so the backdrop draws no text at all and reads quieter for it.
   */
  function drawDeathShaft() {
    var r = run;
    ART.clipTo(ctx, SX, SY, SW, SH);
    ART.fillPlate(ctx, SX, SY, SW, SH, 'shaft', ART.PAL.pit, 0.62);

    for (var i = 0; i < r.ch.rows.length; i++) {
      var y = scrY(RUN.rowY(i));
      if (y < SY - 130 || y > SY + SH + 130) continue;
      var row = r.ch.rows[i];
      var failed = i === r.nextRow - 1 && r.status === 'failed';
      var boxH = 104, gap = 10, boxW = SW / row.length - gap;
      for (var j = 0; j < row.length; j++) {
        var cx2 = scrX(RUN.slotX(row.length, j));
        var slot = row[j];
        var tint = slot.kind === 'flaw' ? ART.temperOf(slot.demand).base
          : (slot.temper ? ART.temperOf(slot.temper).base : ART.PAL.gold);
        ctx.strokeStyle = ART.rgba(tint, failed ? 0.5 : 0.16);
        ctx.lineWidth = failed ? 2 : 1;
        ctx.strokeRect(cx2 - boxW / 2, y - boxH / 2, boxW, boxH);
        // ⚠️ ART.sigil takes a HEX and calls rgba() on it internally — handing it an rgba string
        // would silently produce garbage. Dim with globalAlpha instead of mangling the colour.
        ctx.save();
        ctx.globalAlpha = failed ? 0.55 : 0.14;
        ART.sigil(ctx, cx2, y, Math.min(boxW, boxH) * 0.24, ART.seedOfSlot(slot), tint, false);
        ctx.restore();
      }
      if (failed) {
        ctx.fillStyle = ART.rgba(ART.PAL.blood, 0.16);
        ctx.fillRect(SX, y - boxH / 2, SW, boxH);
      }
    }
    ART.unclip(ctx);

    ctx.fillStyle = ART.rgba(ART.PAL.void, 0.70);
    ctx.fillRect(0, 0, W, H);
  }

  function drawResult() {
    var cx = W / 2;
    var ok = lastCleared;

    /* ⭐ A SHATTERED POUR SHOWS YOU THE SHAFT IT DIED IN. A cleared one does not.
     *
     * This started as a dedupe failure — preflight measured shot_5 and shot_6 as the SAME PICTURE
     * (two identical panels with different words in them; dHash reads structure, not content, and
     * wing doctrine is explicit that recapturing the same layout with different numbers will never
     * move it). The cheap answers were a detail crop or dropping one of them from the gallery.
     *
     * The right answer was design: on a loss, the shaft stays on screen behind a scrim, so the
     * flaw that stopped you is still visible under the sentence explaining it. A player who just
     * shattered wants to see WHERE, and this is the one moment the game can show them. The
     * gallery problem is fixed as a side effect of the screen getting better. */
    if (!ok && run) {
      drawDeathShaft();
    } else {
      backdrop();
    }
    ART.panel(ctx, cx - 290, 78, 580, 470, { accent: ok ? ART.PAL.gold : ART.PAL.blood });
    ART.text(ctx, ok ? 'POURED' : 'SHATTERED', cx, 144, 44, ok ? ART.PAL.gold : ART.PAL.blood, 'center', 10, 700);
    ART.rule(ctx, cx - 200, 166, 400, ok ? ART.PAL.goldDim : ART.PAL.blood);

    var y = 208;
    if (ok) {
      ART.text(ctx, 'ARRIVED WITH ' + run.count + '   ·   NEEDED ' + run.ch.goal, cx, y, 17, ART.PAL.paper, 'center', 2);
      y += 44;
      var rows = [['CLEARING', lastReward.base], ['OVERFLOW', lastReward.overflow]];
      if (lastReward.first) rows.push(['FIRST POUR', lastReward.first]);
      for (var i = 0; i < rows.length; i++) {
        ART.text(ctx, rows[i][0], cx - 150, y, 14, ART.PAL.paperDim, 'left', 2.4);
        ART.text(ctx, '+' + rows[i][1], cx + 150, y, 15, ART.PAL.paper, 'right', 1.2);
        y += 26;
      }
      y += 6;
      ART.rule(ctx, cx - 150, y - 10, 300, ART.PAL.stoneHi);
      ART.text(ctx, 'SLAG EARNED', cx - 150, y + 14, 14, ART.PAL.gold, 'left', 2.4);
      ART.text(ctx, '+' + lastReward.total, cx + 150, y + 14, 20, ART.PAL.gold, 'right', 1.2);
      y += 46;
      drawTrace(ctx, cx, y, 500);
    } else {
      var why = {
        'wrong-temper': 'The flaw would only take ' + ART.temperOf(lastFlawDemand()).name + '. You arrived as ' + ART.temperOf(run.temper).name + '. Size never rescues the wrong temper.',
        'too-few': 'The flaw wanted more motes than you carried. You were the right kind and not enough of it.',
        'spent': 'Breaking through would have used every mote you had. A pour that survives nothing is not a pour.',
        'short-of-goal': 'You reached the crucible with ' + run.count + ' and it wanted ' + run.ch.goal + '. Right temper, not enough of it.',
        'quenched': 'The channel took more than you brought.',
      }[run.reason] || 'The pour did not hold.';
      ART.paragraph(ctx, why, cx, y, 15, ART.PAL.paper, 460, 24, 'center', 0.5);
      y += 92;
      ART.text(ctx, 'THE KILN IS UNTOUCHED. NOTHING IS LOST BUT THIS POUR.', cx, y, 13, ART.PAL.paperDim, 'center', 2.4);
      y += 34;
      drawTrace(ctx, cx, y, 500);
    }

    button(cx - 230, 484, 216, 46, ok ? 'ON TO THE NEXT' : 'POUR AGAIN', function () {
      if (ok) afterResult(); else startChannel(channelIndex);
    }, { size: 16 });
    button(cx + 14, 484, 216, 46, 'THE KILN', function () { screen = 'kiln'; run = null; }, { size: 16 });
  }

  /**
   * THE POUR TRACE — one cell per row the pour resolved, showing what it became and where it
   * ended. Added because both result screens had a dead band of empty panel under their copy, and
   * §4.2b's answer to dead space is never filler: it is showing more of what is IN the product.
   * This is read straight off `run.log`, so it is the actual history of the actual run — the same
   * data the model produced, not a re-derivation.
   */
  function drawTrace(ctx, cx, y, maxW) {
    var steps = run.log.filter(function (e) { return e.type === 'gate' || e.type === 'flaw'; });
    if (!steps.length) return y;
    var n = steps.length;
    var cell = Math.min(52, Math.floor(maxW / n));
    var totalW = cell * n;
    var x0 = cx - totalW / 2;

    ART.text(ctx, 'THE POUR', cx, y, 11, ART.PAL.paperDim, 'center', 3.4);
    y += 26;

    for (var i = 0; i < n; i++) {
      var e = steps[i];
      var T = ART.temperOf(e.after.temper);
      var bad = !e.ok;
      var cxi = x0 + cell * i + cell / 2;

      if (i > 0) {
        ctx.strokeStyle = ART.rgba(ART.PAL.stoneHi, 0.7);
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(cxi - cell / 2 - 6, y + 10); ctx.lineTo(cxi - cell / 2 + 6, y + 10); ctx.stroke();
      }
      // a diamond in the temper the pour BECAME, so the run reads as a colour sequence at a glance
      ctx.beginPath();
      ctx.moveTo(cxi, y - 2); ctx.lineTo(cxi + 13, y + 10); ctx.lineTo(cxi, y + 22); ctx.lineTo(cxi - 13, y + 10);
      ctx.closePath();
      ctx.fillStyle = ART.rgba(bad ? ART.PAL.blood : T.lo, 0.95);
      ctx.fill();
      ctx.strokeStyle = ART.rgba(bad ? ART.PAL.blood : T.base, 0.95);
      ctx.lineWidth = 1.6;
      ctx.stroke();

      ART.text(ctx, bad ? '×' : String(e.after.count), cxi, y + 15, bad ? 15 : 11,
        bad ? ART.PAL.paper : T.hi, 'center', 0.4);
      ART.text(ctx, e.type === 'flaw' ? 'FLAW' : 'GATE', cxi, y + 38, 9,
        bad ? ART.PAL.blood : ART.PAL.paperDim, 'center', 1.2);
    }
    return y + 38;
  }

  /** Which demand actually rejected the pour — read off the log, never guessed. */
  function lastFlawDemand() {
    for (var i = run.log.length - 1; i >= 0; i--) {
      var e = run.log[i];
      if (e.type === 'flaw' && e.slotRef) return e.slotRef.demand;
    }
    return run.temper;
  }

  function drawHelp() {
    backdrop();
    ART.panel(ctx, 40, 24, W - 80, H - 76, { accent: ART.PAL.goldDim });
    var x = 78, w = W - 156, y = 74;
    ART.text(ctx, 'HOW A POUR WORKS', W / 2, y, 26, ART.PAL.gold, 'center', 7, 700);
    y += 14; ART.rule(ctx, x, y, w, ART.PAL.goldDim); y += 40;

    var blocks = [
      ['THE POUR', 'You steer a stream of motes up a foundry shaft. It has a COUNT — how many motes — and a TEMPER, which is what they are made of. Both matter and they are not the same thing.'],
      ['CRUCIBLES', 'A crucible reading ×4 EMBER multiplies you by four AND makes you ember. You pass through exactly one per row, so a row is a choice.'],
      ['FLAWS', 'Each flaw also wants a MINIMUM number of motes, and passing one costs you some of them. Learn the three shapes: you will be reading them at speed, two rows before you reach them.'],
      ['THE WHOLE GAME', 'The crucible that gives you the count you need is often the one that gives you the wrong temper for the flaw two rows later. Arriving big and wrong is a loss. That is the decision.'],
      ['THE KILN', 'Clearing a channel earns slag, and slag buys permanent upgrades: affinities, a wider spout, Farsight, and Reheat — a mid-pour change of temper.'],
      ['LOSING', 'A shattered pour costs you that pour and nothing else. The kiln, the slag and every cleared channel are untouched.'],
    ];
    // ⛔ THE BODY COLUMN IS MEASURED, NOT GUESSED. It was a hard-coded 168px and "THE WHOLE GAME"
    // — the longest label — overprinted its own body text by 9.4px. The layout gate caught it;
    // nothing else could. §3e-1: derive layout from measureText at draw time, because the label
    // width depends on which of five fonts the player's machine actually resolved.
    var col = 0;
    for (var m = 0; m < blocks.length; m++) col = Math.max(col, ART.measure(ctx, blocks[m][0], 14, 3.2));
    col = Math.ceil(col) + 26;
    for (var i = 0; i < blocks.length; i++) {
      ART.text(ctx, blocks[i][0], x, y, 14, ART.PAL.gold, 'left', 3.2);

      /* ⭐ THE FLAWS BLOCK IS DRAWN, NOT DESCRIBED. It used to be three sentences saying that a
       * seal is ember, a race is frost and a slagwall is iron — while the game has a renderer that
       * draws all three, and the player's real task is learning their SILHOUETTES so they can read
       * a shaft at a glance. Showing them here teaches the actual skill, cuts three lines of prose,
       * and is the §3e fix applied to a rules page: compose the mark from the game's own renderer
       * at real data instead of writing about it. (It also took this screen from 207 colours to a
       * genuinely richer frame, but that was the consequence, not the reason.) */
      if (blocks[i][0] === 'FLAWS') {
        var fw = 138, fh = 78, fgap = 18;
        var demos = [
          CH.flaw({ demand: 'ember', threshold: 12, cost: 5, label: 'SEAL' }),
          CH.flaw({ demand: 'frost', threshold: 12, cost: 5, label: 'RACE' }),
          CH.flaw({ demand: 'iron', threshold: 12, cost: 5, label: 'SLAGWALL' }),
        ];
        for (var k = 0; k < demos.length; k++) {
          // satisfied:true on all three — there is no pour on this screen, so a red ≥ would be claiming
          // an unmet demand that does not exist. Red means "you cannot pass this RIGHT NOW" everywhere
          // else in the game and it has to keep meaning that here.
          ART.flawFace(ctx, x + col + fw / 2 + k * (fw + fgap), y + fh / 2 - 10, fw, fh, demos[k], true, true);
          ART.text(ctx, 'ONLY ' + ART.temperOf(demos[k].demand).name,
            x + col + fw / 2 + k * (fw + fgap), y + fh + 12, 11,
            ART.temperOf(demos[k].demand).base, 'center', 2.4);
        }
        y = ART.paragraph(ctx, blocks[i][1], x + col, y + fh + 36, 13.5, ART.PAL.paper, w - col, 20, 'left', 0.4);
        y += 22;
        continue;
      }

      y = ART.paragraph(ctx, blocks[i][1], x + col, y, 13.5, ART.PAL.paper, w - col, 20, 'left', 0.4);
      y += 22;
    }

    ART.rule(ctx, x, y - 12, w, ART.PAL.stoneHi);
    ART.text(ctx, 'MOUSE OR A / D TO STEER   ·   SPACE TO REHEAT   ·   ESC TO LEAVE A POUR',
      W / 2, y + 14, 12.5, ART.PAL.paperDim, 'center', 2.4);
    button(W / 2 - 80, H - 76, 160, 38, 'BACK', function () { screen = save.poured ? 'map' : 'title'; }, { size: 15 });
  }

  function drawEnd() {
    backdrop();
    var cx = W / 2;
    ART.text(ctx, 'THE LAST HEAT', cx, 168, 52, ART.PAL.gold, 'center', 12, 700);
    ART.rule(ctx, cx - 250, 194, 500, ART.PAL.goldDim);
    ART.paragraph(ctx,
      'Twelve channels poured and every flaw in the mountain answered. The shaft runs clean from the spout to the crucible, and what comes out of it is whatever you decided to be on the way up.',
      cx, 242, 16, ART.PAL.paper, 600, 26, 'center', 0.5);
    ART.text(ctx, 'YOU FINISHED IT. IT WAS ALWAYS MEANT TO END.', cx, 356, 15, ART.PAL.paperDim, 'center', 3);

    ART.crest(ctx, cx - 110, 424, 32, 'ember', true);
    ART.crest(ctx, cx, 424, 32, 'frost', true);
    ART.crest(ctx, cx + 110, 424, 32, 'iron', true);

    ART.text(ctx, save.poured + ' POURS   ·   ' + save.lost + ' SHATTERED   ·   ' + save.slag + ' SLAG UNSPENT',
      cx, 496, 13, ART.PAL.paperDim, 'center', 2.4);
    button(cx - 120, 528, 240, 44, 'BACK TO THE FOUNDRY', function () { screen = 'map'; }, { size: 15 });
  }

  /* ══════════════════════════════════════ frame ═════════════════════════════════════════════ */

  function draw() {
    buttons = [];
    ctx.save();
    if (shake > 0) ctx.translate((Math.random() - 0.5) * shake * 11, (Math.random() - 0.5) * shake * 11);
    ctx.fillStyle = ART.PAL.void; ctx.fillRect(-20, -20, W + 40, H + 40);

    if (screen === 'title') drawTitle();
    else if (screen === 'map') drawMap();
    else if (screen === 'kiln') drawKiln();
    else if (screen === 'help') drawHelp();
    else if (screen === 'result') drawResult();
    else if (screen === 'end') drawEnd();
    else if (screen === 'pour') { backdrop(); drawShaft(); drawHud(); }

    drawParticles();

    if (flash) {
      ctx.globalAlpha = flash.a * (1 - (time - flash.at) / 0.4);
      ctx.fillStyle = flash.colour; ctx.fillRect(0, 0, W, H);
      ctx.globalAlpha = 1;
    }
    if (message) {
      var a = Math.min(1, (2.2 - (time - messageAt)) * 2);
      ctx.globalAlpha = Math.max(0, a);
      ART.text(ctx, message, W / 2, 92, 20, ART.PAL.gold, 'center', 4);
      ctx.globalAlpha = 1;
    }
    ctx.restore();
  }

  /* ⚠️ `paused` exists for the CAPTURE HARNESS and nothing else. Without it the rAF loop keeps
   * advancing the simulation while a capture script is ALSO calling update() by hand, so the game
   * runs at roughly double speed plus however long each screenshot takes — measured: a 7-second
   * GIF of a pour reached the RESULT screen by frame 40 of 84, and half the finished file was a
   * static panel. Two drivers on one clock is the bug; a switch for one of them is the fix. */
  var paused = false;

  function frame(ts) {
    var dt = last ? (ts - last) / 1000 : 0;
    last = ts;
    if (!paused) update(Math.min(dt, 0.25));
    draw();
    requestAnimationFrame(frame);
  }

  /* ══════════════════════════════════════ boot ══════════════════════════════════════════════ */

  function boot() {
    canvas = document.getElementById('c');
    ctx = canvas.getContext('2d');
    save = KILN.load();
    bgSeed = 1337;

    canvas.addEventListener('mousemove', onMove);
    canvas.addEventListener('mousedown', onDown);
    canvas.addEventListener('touchstart', function (e) { onDown(e); e.preventDefault(); }, { passive: false });
    canvas.addEventListener('touchmove', function (e) { onMove(e); e.preventDefault(); }, { passive: false });
    canvas.addEventListener('mouseleave', function () { pointer.inside = false; });
    window.addEventListener('keydown', onKey);

    // Audio loads in parallel and NEVER gates the first frame: a slow or blocked audio fetch must
    // not be able to keep the game off the screen. It reports what it could not decode instead.
    SOUND.load('audio/', function () {
      if (SOUND.missing().length) say('AUDIO MISSING: ' + SOUND.missing().join(' '));
    });

    ART.load('art/', function () {
      if (ART.missing().length) {
        // Visible, not silent — a deploy that lost its plates should say so on screen.
        say('PLATES MISSING: ' + ART.missing().join(' '));
      }
      requestAnimationFrame(frame);
    });
  }

  // Expose a tiny surface for the capture and layout harnesses. ⚠️ Read-only intent: these let a
  // headless run reach a screen without simulating a human, and nothing in the game reads them.
  window.ANNEAL = {
    goto: function (s) { screen = s; },
    startChannel: startChannel,
    setSave: function (s) { save = KILN.normalise(s); },
    state: function () { return { screen: screen, run: run, save: save }; },
    drawOnce: draw,
    update: update,
    setPaused: function (v) { paused = !!v; },
    channels: function () { return CHS; },
    setResult: function (cleared, reward) { lastCleared = cleared; lastReward = reward; },
    artLoaded: function () { return ART.loaded(); },
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
