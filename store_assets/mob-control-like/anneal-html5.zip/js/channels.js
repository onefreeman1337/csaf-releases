/**
 * channels.js — the authored channels.
 *
 * ⛔ EVERY channel here is proven by Internal_Ops/solve.js before it ships: solvable at all, NOT
 * solvable by most paths (that would mean there is no decision), and not solvable by exactly one
 * path in a long channel (that is a memory test, not a puzzle).
 *
 * The design intent per channel is written down, because a number tuned until the solver went green
 * is a number nobody can safely change later.
 */
'use strict';

(function (root, factory) {
  const api = factory(typeof require === 'function' ? require('./channel.js') : root.CHANNEL);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.CHANNELS_DATA = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (C) {
  const { gate, flaw, empty, channel } = C;

  const CHANNELS = [

    /* 1 ─ Teaches the whole game in three rows: a gate sets your TEMPER as well as your count, and
       the flaw does not care how big you are if you are the wrong kind. Both openings look
       identical (×5); only one survives row 1. */
    channel({
      id: 'first-pour',
      name: 'First Pour',
      start: { count: 1, temper: 'iron' },
      goal: 6,
      rows: [
        [gate({ mul: 5, temper: 'ember', label: '×5 EMBER' }), gate({ mul: 5, temper: 'frost', label: '×5 FROST' })],
        [flaw({ demand: 'ember', threshold: 4, cost: 2, label: 'SEAL' })],
        [gate({ mul: 2, label: '×2' })],
      ],
    }),

    /* 2 ─ THE TRAP THE WHOLE GAME IS BUILT ON: the biggest multiplier on screen (×8) is the wrong
       temper for the wall two rows later. Taking the smaller ×4 IRON is correct, which is the exact
       decision the reference collapses away by having no tempers at all. */
    channel({
      id: 'slagwall',
      name: 'The Slagwall',
      start: { count: 1, temper: 'iron' },
      goal: 8,
      rows: [
        [gate({ mul: 8, temper: 'frost', label: '×8 FROST' }), gate({ mul: 4, temper: 'iron', label: '×4 IRON' })],
        [gate({ mul: 2, label: '×2' }), gate({ add: 6, label: '+6' })],
        [flaw({ demand: 'iron', threshold: 8, cost: 5, label: 'SLAGWALL' })],
        [gate({ mul: 4, temper: 'ember', label: '×4 EMBER' }), gate({ mul: 3, temper: 'ember', label: '×3 EMBER' })],
        [flaw({ demand: 'ember', threshold: 9, cost: 5, label: 'SEAL' })],
      ],
    }),

    /* 3 ─ Two flaws in a row force a COMMITMENT: you cannot dodge, you can only be the right kind
       for one of them, and the two demand different tempers. The row before it is where the real
       choice happens, one step earlier than it feels. */
    channel({
      id: 'the-fork',
      name: 'The Fork',
      start: { count: 2, temper: 'iron' },
      goal: 12,
      rows: [
        [gate({ mul: 3, temper: 'ember', label: '×3 EMBER' }), gate({ mul: 3, temper: 'frost', label: '×3 FROST' })],
        [gate({ mul: 2, label: '×2' }), gate({ add: 8, label: '+8' })],
        [flaw({ demand: 'ember', threshold: 8, cost: 4, label: 'SEAL' }), flaw({ demand: 'frost', threshold: 12, cost: 5, label: 'RACE' })],
        [gate({ mul: 3, label: '×3' }), gate({ add: 10, label: '+10' })],
      ],
    }),

    /* 4 ─ Retemper economics: an EMBER run has to pass back through IRON to survive the wall, and
       the only iron gate on the board is a shrinking one (+0 ×1 would be illegal, so it is a real
       cost in tempo rather than count). Teaches that temper is a resource you SPEND. */
    channel({
      id: 'the-return',
      name: 'The Return',
      start: { count: 3, temper: 'ember' },
      goal: 20,
      rows: [
        // ⚠️ +11 not +9: from a start of 3, ×4 and +9 BOTH give exactly 12, so the row asked a
        // question with one answer. The solver's dead-row check caught it; the eye never would.
        [gate({ mul: 4, label: '×4' }), gate({ add: 11, label: '+11' })],
        [flaw({ demand: 'ember', threshold: 10, cost: 6, label: 'SEAL' }), empty()],
        [gate({ mul: 2, temper: 'iron', label: '×2 IRON' }), gate({ mul: 5, temper: 'ember', label: '×5 EMBER' })],
        [flaw({ demand: 'iron', threshold: 12, cost: 8, label: 'SLAGWALL' })],
        [gate({ mul: 4, label: '×4' }), gate({ add: 14, label: '+14' })],
      ],
    }),

    /* 5 ─ A long one. Three flaws, three tempers, and the +N gates matter more than the ×N ones
       once the flaws have taken their cost — the arithmetic inverts late, which is the thing a
       player discovers rather than is told. */
    channel({
      id: 'three-fires',
      name: 'Three Fires',
      start: { count: 2, temper: 'iron' },
      goal: 24,
      rows: [
        [gate({ mul: 5, temper: 'iron', label: '×5 IRON' }), gate({ mul: 3, temper: 'frost', label: '×3 FROST' })],
        [gate({ add: 6, label: '+6' }), gate({ mul: 2, label: '×2' })],
        [flaw({ demand: 'iron', threshold: 12, cost: 7, label: 'SLAGWALL' }), flaw({ demand: 'frost', threshold: 6, cost: 3, label: 'RACE' })],
        [gate({ mul: 3, temper: 'ember', label: '×3 EMBER' }), gate({ mul: 4, temper: 'frost', label: '×4 FROST' })],
        [flaw({ demand: 'ember', threshold: 14, cost: 6, label: 'SEAL' }), flaw({ demand: 'frost', threshold: 20, cost: 9, label: 'RACE' })],
        [gate({ add: 12, label: '+12' }), gate({ mul: 2, label: '×2' })],
      ],
    }),

    /* 6 ─ THE NARROWS. First three-slot rows, and the first row where the flaw you must survive is
       the one you CHOSE one row earlier: three openings, three demands, and they line up one to
       one. The lesson is that a temper is a commitment made before you can see what it costs. */
    channel({
      id: 'the-narrows',
      name: 'The Narrows',
      start: { count: 2, temper: 'iron' },
      goal: 32,
      rows: [
        [gate({ mul: 4, temper: 'ember', label: '×4 EMBER' }), gate({ mul: 3, temper: 'iron', label: '×3 IRON' }), gate({ add: 9, temper: 'frost', label: '+9 FROST' })],
        [flaw({ demand: 'ember', threshold: 8, cost: 4, label: 'SEAL' }), flaw({ demand: 'iron', threshold: 6, cost: 3, label: 'SLAGWALL' }), flaw({ demand: 'frost', threshold: 11, cost: 6, label: 'RACE' })],
        [gate({ mul: 3, label: '×3' }), gate({ add: 8, label: '+8' })],
        [gate({ mul: 2, temper: 'iron', label: '×2 IRON' }), gate({ mul: 2, temper: 'ember', label: '×2 EMBER' })],
        [flaw({ demand: 'iron', threshold: 20, cost: 8, label: 'SLAGWALL' }), flaw({ demand: 'ember', threshold: 22, cost: 9, label: 'SEAL' })],
        [gate({ add: 14, label: '+14' }), gate({ mul: 2, label: '×2' })],
      ],
    }),

    /* 7 ─ COLD FORGE. Frost is the cheap temper here and the channel knows it: two races in a row
       are survivable on frost alone, but the goal is out of reach without leaving frost for a
       multiplier that costs you the second race. Tempo, not size. */
    channel({
      id: 'cold-forge',
      name: 'Cold Forge',
      start: { count: 4, temper: 'frost' },
      goal: 44,
      rows: [
        [gate({ mul: 3, label: '×3' }), gate({ add: 7, label: '+7' })],
        [flaw({ demand: 'frost', threshold: 11, cost: 5, label: 'RACE' }), empty()],
        [gate({ mul: 4, temper: 'ember', label: '×4 EMBER' }), gate({ mul: 2, label: '×2' }), gate({ add: 13, label: '+13' })],
        [flaw({ demand: 'frost', threshold: 18, cost: 7, label: 'RACE' }), flaw({ demand: 'ember', threshold: 30, cost: 12, label: 'SEAL' })],
        [gate({ mul: 3, temper: 'iron', label: '×3 IRON' }), gate({ add: 16, label: '+16' })],
        [flaw({ demand: 'iron', threshold: 33, cost: 14, label: 'SLAGWALL' }), empty()],
        [gate({ mul: 2, label: '×2' }), gate({ add: 18, label: '+18' })],
      ],
    }),

    /* 8 ─ THE DOUBLE BACK. Two slagwalls with a temper detour between them. Staying iron is easy
       and arrives far too small; the detour is where the size comes from and it has to be paid
       back before the second wall. This is the channel that teaches the game's real rhythm. */
    channel({
      id: 'the-double-back',
      name: 'The Double Back',
      start: { count: 3, temper: 'iron' },
      // ⚠️ 150, not the 60 this was authored at. At 60 the solver measured 69% of ALL paths winning
      // — the channel had a shape and no decision, because almost anything cleared the bar. The
      // goal is the difficulty dial on a channel like this one, not the thresholds.
      goal: 150,
      rows: [
        [gate({ mul: 5, label: '×5' }), gate({ add: 9, label: '+9' })],
        [flaw({ demand: 'iron', threshold: 12, cost: 6, label: 'SLAGWALL' })],
        [gate({ mul: 4, temper: 'ember', label: '×4 EMBER' }), gate({ mul: 2, temper: 'frost', label: '×2 FROST' })],
        [gate({ add: 15, label: '+15' }), gate({ mul: 2, label: '×2' })],
        [gate({ mul: 2, temper: 'iron', label: '×2 IRON' }), gate({ add: 11, temper: 'iron', label: '+11 IRON' })],
        [flaw({ demand: 'iron', threshold: 40, cost: 18, label: 'SLAGWALL' })],
        [gate({ mul: 2, label: '×2' }), gate({ add: 26, label: '+26' })],
      ],
    }),

    /* 9 ─ EMBERFALL. Big multipliers everywhere, and the row-0 choice is between the huge ×6 that
       keeps your ember and a modest ×4 that turns you frost.
       ⚠️ THE COMMENT THAT USED TO SIT HERE WAS A DESIGN INTENTION THE NUMBERS DID NOT SHARE, and
       the solver is what caught it. It claimed "the small gate is usually wrong"; measured, the
       small FROST opening reaches 108 and the big ember one caps at 96 — the smaller gate is the
       better one, which is a sharper lesson and the exact blind spot of the reference this game
       answers (there, bigger is always simply better). The channel keeps the numbers and the
       comment now describes them.
       ⛔ Its first authoring also had a DEAD row 0: both openings topped out at exactly 96, so the
       game's opening question had one answer. Widening the frost branch is what made it a choice. */
    channel({
      id: 'emberfall',
      name: 'Emberfall',
      start: { count: 2, temper: 'ember' },
      goal: 72,
      rows: [
        [gate({ mul: 6, label: '×6' }), gate({ mul: 4, temper: 'frost', label: '×4 FROST' })],
        [gate({ add: 10, label: '+10' }), gate({ mul: 2, label: '×2' })],
        [flaw({ demand: 'ember', threshold: 22, cost: 11, label: 'SEAL' }), flaw({ demand: 'frost', threshold: 14, cost: 6, label: 'RACE' })],
        [gate({ mul: 4, label: '×4' }), gate({ add: 19, label: '+19' }), gate({ mul: 2, temper: 'iron', label: '×2 IRON' })],
        [flaw({ demand: 'ember', threshold: 44, cost: 20, label: 'SEAL' }), flaw({ demand: 'iron', threshold: 20, cost: 9, label: 'SLAGWALL' }), flaw({ demand: 'frost', threshold: 26, cost: 12, label: 'RACE' })],
        [gate({ mul: 3, label: '×3' }), gate({ add: 34, label: '+34' })],
      ],
    }),

    /* 10 ─ THE LATTICE. Seven rows, three tempers, and every flaw sits directly after a row that
       can change your temper — so the channel is read backwards, from the demand to the gate that
       satisfies it. The point where the game stops being about the next row. */
    channel({
      id: 'the-lattice',
      name: 'The Lattice',
      start: { count: 3, temper: 'frost' },
      goal: 130,
      rows: [
        [gate({ mul: 4, label: '×4' }), gate({ add: 11, label: '+11' })],
        [gate({ mul: 2, temper: 'ember', label: '×2 EMBER' }), gate({ mul: 3, temper: 'iron', label: '×3 IRON' })],
        [flaw({ demand: 'ember', threshold: 24, cost: 10, label: 'SEAL' }), flaw({ demand: 'iron', threshold: 30, cost: 13, label: 'SLAGWALL' })],
        [gate({ mul: 3, label: '×3' }), gate({ add: 22, label: '+22' })],
        [gate({ mul: 2, temper: 'frost', label: '×2 FROST' }), gate({ add: 17, temper: 'frost', label: '+17 FROST' }), gate({ mul: 2, temper: 'ember', label: '×2 EMBER' })],
        [flaw({ demand: 'frost', threshold: 60, cost: 26, label: 'RACE' }), flaw({ demand: 'ember', threshold: 72, cost: 31, label: 'SEAL' })],
        [gate({ mul: 2, label: '×2' }), gate({ add: 48, label: '+48' })],
      ],
    }),

    /* 11 ─ THE CRUCIBLE. Eight rows and three flaws, each demanding a different temper, in an
       order that no single opening satisfies. Every route through it has to spend a temper change
       at a moment that costs count, which is the whole game stated once. */
    channel({
      id: 'the-crucible',
      name: 'The Crucible',
      start: { count: 4, temper: 'iron' },
      goal: 200,
      rows: [
        [gate({ mul: 5, label: '×5' }), gate({ add: 14, label: '+14' })],
        [flaw({ demand: 'iron', threshold: 17, cost: 8, label: 'SLAGWALL' }), empty()],
        [gate({ mul: 3, temper: 'ember', label: '×3 EMBER' }), gate({ mul: 4, temper: 'frost', label: '×4 FROST' })],
        [gate({ add: 21, label: '+21' }), gate({ mul: 2, label: '×2' })],
        [flaw({ demand: 'ember', threshold: 48, cost: 21, label: 'SEAL' }), flaw({ demand: 'frost', threshold: 60, cost: 27, label: 'RACE' })],
        [gate({ mul: 3, temper: 'frost', label: '×3 FROST' }), gate({ mul: 2, temper: 'iron', label: '×2 IRON' }), gate({ add: 40, label: '+40' })],
        [flaw({ demand: 'frost', threshold: 96, cost: 42, label: 'RACE' }), flaw({ demand: 'iron', threshold: 70, cost: 30, label: 'SLAGWALL' })],
        [gate({ mul: 2, label: '×2' }), gate({ add: 84, label: '+84' })],
      ],
    }),

    /* 12 ─ LAST HEAT. The ending. Nine rows, four flaws, and the last one demands the temper the
       row before it takes away from you unless you read three rows ahead — which is exactly what
       the kiln's Farsight and Reheat were sold to you for. A finale should ask for the thing the
       whole campaign taught, and this one asks for all of it at once.

       ⛔ IT MUST STAY SOLVABLE WITHOUT ANY KILN AT ALL (solve.js proves this on base numbers). A
       finale gated behind purchases would make the campaign unwinnable for a player who spent
       their slag differently, and nothing in the game would tell them why. */
    channel({
      id: 'last-heat',
      name: 'Last Heat',
      start: { count: 5, temper: 'ember' },
      goal: 400,
      rows: [
        [gate({ mul: 4, label: '×4' }), gate({ add: 17, label: '+17' })],
        [flaw({ demand: 'ember', threshold: 20, cost: 9, label: 'SEAL' }), empty()],
        [gate({ mul: 3, temper: 'iron', label: '×3 IRON' }), gate({ mul: 4, temper: 'frost', label: '×4 FROST' })],
        [flaw({ demand: 'iron', threshold: 40, cost: 17, label: 'SLAGWALL' }), flaw({ demand: 'frost', threshold: 52, cost: 23, label: 'RACE' })],
        [gate({ mul: 3, label: '×3' }), gate({ add: 36, label: '+36' })],
        [gate({ mul: 2, temper: 'ember', label: '×2 EMBER' }), gate({ add: 29, temper: 'ember', label: '+29 EMBER' }), gate({ mul: 2, temper: 'frost', label: '×2 FROST' })],
        [flaw({ demand: 'ember', threshold: 110, cost: 48, label: 'SEAL' }), flaw({ demand: 'frost', threshold: 130, cost: 56, label: 'RACE' })],
        [gate({ mul: 3, label: '×3' }), gate({ add: 96, label: '+96' })],
        [gate({ mul: 2, label: '×2' }), gate({ add: 130, label: '+130' })],
      ],
    }),

  ];

  return { CHANNELS };
});
