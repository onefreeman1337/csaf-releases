/**
 * channel.js — ANNEAL's rules model. Pure, deterministic, no DOM, no canvas.
 *
 * THE ONE IDEA. Your pour has a COUNT and a TEMPER. Crucible gates change both at once, and the
 * channel's flaws each demand a specific temper. The gate that gives you the count you need is
 * frequently the gate that gives you the wrong temper for the next flaw, so ARRIVING BIG AND WRONG
 * IS A LOSS. The reference this answers (Mob Control) has an undifferentiated crowd, which collapses
 * every decision to "aim at the biggest multiplier" — see
 * Wings/GamesLite/Research/MobControl_Reference_2026-08-28.md for why that is the root cause of its
 * own measured repetitiveness.
 *
 * ⛔ This file is the ONLY place the rules live. The renderer and the solver both call it, so a
 * preview can never disagree with what actually happens — the property BANNERET earned its best
 * reviews for (the hover preview IS the resolution function).
 *
 * Everything here is integer arithmetic and total functions: no randomness, no floats, no throwing
 * on ordinary play. A channel either resolves or it reports exactly why it did not.
 */
'use strict';

(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.CHANNEL = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {

  /** The three tempers. Deliberately three: two is a coin-flip, four stops being readable in 30s. */
  const TEMPERS = ['ember', 'frost', 'iron'];

  const SLOT_KINDS = ['empty', 'gate', 'flaw'];

  /* ── constructors, so a malformed channel fails HERE and not three systems later ───────────── */

  function gate({ mul = 1, add = 0, temper = null, label = null } = {}) {
    if (!Number.isInteger(mul) || mul < 1) throw new Error(`gate.mul must be a positive integer, got ${mul}`);
    if (!Number.isInteger(add)) throw new Error(`gate.add must be an integer, got ${add}`);
    if (temper !== null && !TEMPERS.includes(temper)) throw new Error(`gate.temper unknown: ${temper}`);
    if (mul === 1 && add === 0 && temper === null) throw new Error('gate does nothing — that is a design error, not a slot');
    return { kind: 'gate', mul, add, temper, label };
  }

  function flaw({ demand, threshold, cost = null, label = null } = {}) {
    if (!TEMPERS.includes(demand)) throw new Error(`flaw.demand unknown: ${demand}`);
    if (!Number.isInteger(threshold) || threshold < 1) throw new Error(`flaw.threshold must be a positive integer, got ${threshold}`);
    const c = cost === null ? threshold : cost;
    if (!Number.isInteger(c) || c < 0) throw new Error(`flaw.cost must be a non-negative integer, got ${cost}`);
    return { kind: 'flaw', demand, threshold, cost: c, label };
  }

  function empty() { return { kind: 'empty' }; }

  /**
   * A channel is rows of slots. The pour occupies ONE slot per row and cannot be in two at once —
   * that exclusivity is the whole decision.
   */
  function channel({ id, name = null, rows, start = { count: 1, temper: 'iron' }, goal }) {
    if (!Array.isArray(rows) || rows.length === 0) throw new Error('channel.rows must be a non-empty array');
    rows.forEach((row, i) => {
      if (!Array.isArray(row) || row.length === 0) throw new Error(`row ${i} must be a non-empty array of slots`);
      row.forEach((s, j) => {
        if (!s || !SLOT_KINDS.includes(s.kind)) throw new Error(`row ${i} slot ${j} is not a slot`);
      });
    });
    if (!TEMPERS.includes(start.temper)) throw new Error(`start.temper unknown: ${start.temper}`);
    if (!Number.isInteger(start.count) || start.count < 1) throw new Error('start.count must be a positive integer');
    if (!Number.isInteger(goal) || goal < 1) throw new Error('channel.goal must be a positive integer');
    return { id, name, rows, start, goal };
  }

  /* ── resolution ────────────────────────────────────────────────────────────────────────────── */

  /**
   * Apply ONE slot to a stream state. Total: never throws for ordinary play, and reports failure
   * as data so the renderer and the solver read the identical verdict.
   *
   * @returns {{ok:boolean, count:number, temper:string, reason:string|null}}
   */
  function applySlot(state, slot) {
    if (slot.kind === 'empty') {
      return { ok: true, count: state.count, temper: state.temper, reason: null };
    }
    if (slot.kind === 'gate') {
      // Multiply THEN add — stated once, here, so no caller has to guess the order.
      const count = state.count * slot.mul + slot.add;
      const temper = slot.temper === null ? state.temper : slot.temper;
      if (count < 1) return { ok: false, count: 0, temper, reason: 'quenched' };
      return { ok: true, count, temper, reason: null };
    }
    if (slot.kind === 'flaw') {
      if (state.temper !== slot.demand) {
        // THE POINT OF THE GAME: size does not rescue the wrong temper.
        return { ok: false, count: state.count, temper: state.temper, reason: 'wrong-temper' };
      }
      if (state.count < slot.threshold) {
        return { ok: false, count: state.count, temper: state.temper, reason: 'too-few' };
      }
      const count = state.count - slot.cost;
      if (count < 1) return { ok: false, count: 0, temper: state.temper, reason: 'spent' };
      return { ok: true, count, temper: state.temper, reason: null };
    }
    return { ok: false, count: state.count, temper: state.temper, reason: 'unknown-slot' };
  }

  /**
   * Run a whole path. `path[i]` is the slot index chosen in row i.
   * @returns {{ok:boolean, count:number, temper:string, failedAt:number|null, reason:string|null, trace:Array}}
   */
  function runPath(ch, path) {
    if (!Array.isArray(path) || path.length !== ch.rows.length) {
      throw new Error(`path length ${path && path.length} does not match ${ch.rows.length} rows`);
    }
    let state = { count: ch.start.count, temper: ch.start.temper };
    const trace = [{ row: -1, count: state.count, temper: state.temper }];
    for (let i = 0; i < ch.rows.length; i++) {
      const row = ch.rows[i];
      const j = path[i];
      if (!Number.isInteger(j) || j < 0 || j >= row.length) {
        throw new Error(`path[${i}] = ${j} is not a slot index in a row of ${row.length}`);
      }
      const r = applySlot(state, row[j]);
      trace.push({ row: i, slot: j, count: r.count, temper: r.temper, ok: r.ok, reason: r.reason });
      if (!r.ok) {
        return { ok: false, count: r.count, temper: r.temper, failedAt: i, reason: r.reason, trace };
      }
      state = { count: r.count, temper: r.temper };
    }
    if (state.count < ch.goal) {
      return { ok: false, count: state.count, temper: state.temper, failedAt: null, reason: 'short-of-goal', trace };
    }
    return { ok: true, count: state.count, temper: state.temper, failedAt: null, reason: null, trace };
  }

  return { TEMPERS, gate, flaw, empty, channel, applySlot, runPath };
});
