/**
 * run.js — ANNEAL's REAL-TIME layer. The pour, the steering, the crossing of rows.
 *
 * ⛔ IT OWNS NO RULES. Every slot in this file resolves through `CHANNEL.applySlot`, which is the
 * one place ANNEAL's arithmetic lives. That is deliberate and it is the property BANNERET earned
 * its best reviews for: the preview a player reads and the thing that actually happens are the
 * same function, so they cannot drift. What this file adds is TIME — where the pour is, how fast
 * it rises, how far it can steer before the next row arrives, and when a row is committed.
 *
 * There is NO DOM and NO canvas here, so the whole game is simulable headless in node — which is
 * how Internal_Ops/test_run.js can play thousands of runs and assert properties no playtest could
 * reach (master §2: a deterministic proxy beats a noisy stopwatch).
 *
 * ─────────────────────────────────────────────────────────────────────────────────────────────
 * THE MONOTONICITY PROPERTY, and it is the reason the kiln is safe.
 *
 * Internal_Ops/solve.js proves each channel solvable on its BASE numbers. The kiln then makes
 * runs easier: more starting motes, lower flaw thresholds, lower flaw costs, extra retempers.
 * Every one of those changes is MONOTONE — it can never turn a winnable run into a lost one —
 * so the solver's proof on base values is a LOWER BOUND that every upgraded run inherits. If a
 * kiln upgrade were ever allowed to be non-monotone (a penalty, an overshoot, a cap) the solver
 * would silently stop proving anything about real play. `test_run.js` asserts the property by
 * fuzz rather than trusting this paragraph.
 * ─────────────────────────────────────────────────────────────────────────────────────────────
 */
'use strict';

(function (root, factory) {
  const api = factory(typeof require === 'function' ? require('./channel.js') : root.CHANNEL);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.RUN = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (C) {

  /* ── geometry, in channel-space pixels ────────────────────────────────────────────────────── */

  const SHAFT_W = 560;   // usable width of the channel shaft
  const ROW_GAP = 158;   // vertical distance between rows
  const MOUTH = 120;     // distance from the spout to the first row
  const CROWN = 150;     // distance from the last row to the crucible at the top

  const RISE = 96;       // px per second the pour climbs, before Bellows
  const STEER = 470;     // px per second the spout can slide sideways

  /** The temper cycle a Reheat walks. Order is fixed so the control is learnable. */
  const CYCLE = ['ember', 'frost', 'iron'];

  /* ── kiln → effective channel ─────────────────────────────────────────────────────────────── */

  /**
   * The kiln's shape. Every field is a LEVEL, never a multiplier, so progression is countable and
   * an upgrade is never a fraction of a mote.
   */
  function emptyKiln() {
    return { ember: 0, frost: 0, iron: 0, spout: 0, farsight: 0, reheat: 0, draw: 0, bellows: 0 };
  }

  function kilnOf(k) {
    const base = emptyKiln();
    if (!k) return base;
    for (const key of Object.keys(base)) {
      const v = k[key];
      base[key] = Number.isInteger(v) && v > 0 ? v : 0;
    }
    return base;
  }

  /**
   * Apply the kiln to a channel, producing the channel the player actually pours into.
   *
   * ⚠️ It REBUILDS every slot through `CHANNEL.flaw` / `CHANNEL.gate` rather than mutating, so a
   * malformed effective channel fails in the constructor the same way an authored one does. A
   * previous shape of this function spread `{...slot, threshold: n}` and would have happily
   * produced a threshold of 0 — legal-looking, and outside what the constructor permits.
   */
  function effective(ch, kiln) {
    const k = kilnOf(kiln);
    const rows = ch.rows.map((row) => row.map((slot) => {
      if (slot.kind !== 'flaw') return slot;
      const affinity = k[slot.demand] || 0;
      const threshold = Math.max(1, slot.threshold - affinity);
      const cost = Math.max(0, slot.cost - k.draw);
      return C.flaw({ demand: slot.demand, threshold, cost, label: slot.label });
    }));
    return C.channel({
      id: ch.id,
      name: ch.name,
      rows,
      start: { count: ch.start.count + k.spout, temper: ch.start.temper },
      goal: ch.goal,
    });
  }

  /** How many rows ahead the player can read a gate's temper. Base 1; Farsight buys more. */
  function sightOf(kiln) { return 1 + (kilnOf(kiln).farsight || 0); }

  /** Rise speed after Bellows. Integer-free but deterministic, and never below a floor. */
  function riseOf(kiln) {
    const b = kilnOf(kiln).bellows || 0;
    return Math.max(40, RISE * Math.pow(0.88, b));
  }

  /* ── layout helpers, shared by the sim and the renderer so they cannot disagree ───────────── */

  /** y of row i in channel space, measured up from the spout. */
  function rowY(i) { return MOUTH + i * ROW_GAP; }

  /** Total climb of a channel, spout to crucible. */
  function summitY(ch) { return MOUTH + (ch.rows.length - 1) * ROW_GAP + CROWN; }

  /** The x centre of slot j in a row of n, in channel space. */
  function slotX(n, j) { return SHAFT_W * (j + 0.5) / n; }

  /** Which slot of an n-slot row contains x. Total: clamps, never returns undefined. */
  function slotAt(n, x) {
    const j = Math.floor((x / SHAFT_W) * n);
    return j < 0 ? 0 : (j >= n ? n - 1 : j);
  }

  /* ── the run ──────────────────────────────────────────────────────────────────────────────── */

  /**
   * @param ch    an authored channel (base numbers — the kiln is applied here, not by the caller)
   * @param kiln  the player's kiln levels
   */
  function create(ch, kiln) {
    const eff = effective(ch, kiln);
    const k = kilnOf(kiln);
    return {
      base: ch,
      ch: eff,
      kiln: k,
      // where the pour is
      x: SHAFT_W / 2,
      targetX: SHAFT_W / 2,
      y: 0,
      rise: riseOf(k),
      sight: sightOf(k),
      // what the pour is
      count: eff.start.count,
      temper: eff.start.temper,
      // progress
      nextRow: 0,
      reheats: k.reheat,
      status: 'pouring',      // pouring | cleared | failed
      reason: null,
      // a full record of what happened, for the result screen and for tests
      path: [],
      log: [],
      elapsed: 0,
    };
  }

  /** Steer toward a channel-space x. Clamped; the pour cannot leave the shaft. */
  function steer(run, x) {
    run.targetX = x < 0 ? 0 : (x > SHAFT_W ? SHAFT_W : x);
  }

  /** Steer to the centre of a slot in the row the pour is about to cross — the keyboard route. */
  function steerToSlot(run, j) {
    const row = run.ch.rows[Math.min(run.nextRow, run.ch.rows.length - 1)];
    if (!row) return;
    const jj = j < 0 ? 0 : (j >= row.length ? row.length - 1 : j);
    steer(run, slotX(row.length, jj));
  }

  /** Nudge one slot left/right of whichever slot the pour is currently over. */
  function nudge(run, dir) {
    const row = run.ch.rows[Math.min(run.nextRow, run.ch.rows.length - 1)];
    if (!row) return;
    steerToSlot(run, slotAt(row.length, run.targetX) + dir);
  }

  /**
   * Spend a Reheat: advance the temper one step around the cycle.
   * ⚠️ This is the ONE place the pour's temper changes without a slot, and it is why the solver's
   * proof stays valid — see the monotonicity note at the head of this file. Refused when spent or
   * when the run is over, and it reports which.
   */
  function reheat(run) {
    if (run.status !== 'pouring') return { ok: false, reason: 'not-pouring' };
    if (run.reheats <= 0) return { ok: false, reason: 'no-charges' };
    run.reheats--;
    run.temper = CYCLE[(CYCLE.indexOf(run.temper) + 1) % CYCLE.length];
    run.log.push({ t: run.elapsed, type: 'reheat', temper: run.temper, left: run.reheats });
    return { ok: true, temper: run.temper, left: run.reheats };
  }

  /**
   * Advance the simulation by dt seconds. Returns the events that happened, so the renderer can
   * throw sparks and the sound layer can play a chime without either of them re-deriving state.
   *
   * ⛔ dt IS CLAMPED. A backgrounded tab hands rAF a multi-second dt on return, and an unclamped
   * step would teleport the pour through two rows without ever testing the one between — the
   * classic tunnelling bug, and here it would silently skip a flaw. The loop below also steps
   * ROW BY ROW rather than by dt, for the same reason.
   */
  function tick(run, dt) {
    const events = [];
    if (run.status !== 'pouring') return events;
    const step = Math.max(0, Math.min(0.1, dt));
    run.elapsed += step;

    // horizontal: move toward the target at a finite rate. The finite rate IS the decision —
    // an instant snap would make every row a last-millisecond choice with no commitment.
    const x0 = run.x;
    const dx = run.targetX - run.x;
    const maxDx = STEER * step;
    run.x += Math.abs(dx) <= maxDx ? dx : Math.sign(dx) * maxDx;
    const x1 = run.x;

    // vertical: climb, testing every row line we pass rather than only the one we land on
    const y0 = run.y;
    const y1 = y0 + run.rise * step;
    const climbed = y1 - y0;

    while (run.nextRow < run.ch.rows.length && rowY(run.nextRow) <= y1) {
      const i = run.nextRow;
      const row = run.ch.rows[i];

      // ⛔ THE POUR'S x AT THE MOMENT IT CROSSES THE LINE, not at the end of the frame. At 96 px/s
      // and 60 Hz the two differ by under 2px and it looks like pedantry; at 10 fps — a mid-range
      // phone, or a tab that just came back — the spout travels up to 47px within one frame and
      // the end-of-frame x decides rows the player never steered into. Interpolate, always.
      const t = climbed <= 0 ? 1 : Math.max(0, Math.min(1, (rowY(i) - y0) / climbed));
      const j = slotAt(row.length, x0 + (x1 - x0) * t);

      const before = { count: run.count, temper: run.temper };
      const r = C.applySlot({ count: run.count, temper: run.temper }, row[j]);
      run.path.push(j);
      run.count = r.count;
      run.temper = r.temper;
      run.nextRow++;

      const ev = {
        type: row[j].kind, row: i, slot: j, ok: r.ok, reason: r.reason,
        before, after: { count: r.count, temper: r.temper }, slotRef: row[j],
      };
      run.log.push(Object.assign({ t: run.elapsed }, ev));
      events.push(ev);

      if (!r.ok) {
        run.status = 'failed';
        run.reason = r.reason;
        run.y = rowY(i);
        events.push({ type: 'fail', reason: r.reason, row: i });
        return events;
      }
    }

    run.y = y1;

    if (run.nextRow >= run.ch.rows.length && run.y >= summitY(run.ch)) {
      run.y = summitY(run.ch);
      if (run.count >= run.ch.goal) {
        run.status = 'cleared';
        events.push({ type: 'clear', count: run.count, temper: run.temper });
      } else {
        run.status = 'failed';
        run.reason = 'short-of-goal';
        events.push({ type: 'fail', reason: 'short-of-goal', row: null });
      }
    }
    return events;
  }

  /* ── reward ───────────────────────────────────────────────────────────────────────────────── */

  /**
   * Slag earned for a cleared channel. Deliberately readable arithmetic — a player should be able
   * to see WHY they earned what they earned, because the kiln is the thing that keeps them here.
   *
   * `firstClear` is worth a lot, so the campaign always pays forward; overflow is worth a little,
   * so pouring big is rewarded without making replays a better income than progress.
   */
  function reward(run, firstClear) {
    if (run.status !== 'cleared') return { total: 0, base: 0, overflow: 0, first: 0 };
    const base = Math.max(1, Math.round(run.ch.goal / 2));
    const overflow = Math.min(40, Math.max(0, run.count - run.ch.goal));
    const first = firstClear ? run.ch.goal : 0;
    return { total: base + overflow + first, base, overflow, first };
  }

  /* ── what the player is allowed to SEE (the Farsight upgrade is an information upgrade) ────── */

  /**
   * Is row i legible from the pour's current position? Rows at or before the next crossing are
   * always legible; Farsight extends how far past that the temper labels resolve.
   * ⚠️ The row is always DRAWN — what this gates is whether its numbers and demand are readable,
   * which is the actual scarce resource in a game about planning a temper two rows ahead.
   */
  function legible(run, i) { return i < run.nextRow + run.sight; }

  return {
    SHAFT_W, ROW_GAP, MOUTH, CROWN, RISE, STEER, CYCLE,
    emptyKiln, kilnOf, effective, sightOf, riseOf,
    rowY, summitY, slotX, slotAt,
    create, steer, steerToSlot, nudge, reheat, tick, reward, legible,
  };
});
