/**
 * sound.js — cues and the theme loop.
 *
 * Everything it plays was rendered by `Kernel/capture/make_audio.js` from oscillators and noise:
 * OUR OWN IP, no licence, no attribution, and — decisively for the listing — **no generative-AI
 * audio tag**, because itch is explicit that self-contained procedural synthesis is not generative
 * AI (master §4.1). The wing's AI disclosure therefore stays Code=yes, Graphics=yes, Sounds=NO,
 * and that is a truthful answer rather than a convenient one.
 *
 * ⛔ AUTOPLAY IS BLOCKED UNTIL A GESTURE, IN EVERY MODERN BROWSER. An AudioContext created at load
 * starts `suspended`, and a game that "plays music" into a suspended context is silent on the
 * store page while every check passes. `unlock()` is called from the first real click, and
 * `enabled()` reports what is actually true rather than what was intended.
 */
'use strict';

var SOUND = (function () {
  var ctx = null, buffers = {}, ready = false, on = true, musicNode = null, musicBuf = null, musicGain = null;
  var CUES = ['gate', 'temper', 'break', 'shatter', 'clear', 'reheat', 'buy', 'pour'];
  var pending = 0, failed = [];

  function ac() {
    if (ctx) return ctx;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
    return ctx;
  }

  function fetchBuf(url, done) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = 'arraybuffer';
    xhr.onload = function () {
      if (xhr.status >= 400 || !xhr.response) { done(null); return; }
      var c = ac();
      if (!c) { done(null); return; }
      // ⚠️ decodeAudioData has BOTH a callback and a promise form depending on the browser, and
      // the callback form is the one Safari has always had. Use it and treat a throw as a miss.
      try { c.decodeAudioData(xhr.response, function (b) { done(b); }, function () { done(null); }); }
      catch (e) { done(null); }
    };
    xhr.onerror = function () { done(null); };
    xhr.send();
  }

  function load(base, done) {
    if (!ac()) { ready = true; done && done(); return; }
    pending = CUES.length + 1;
    var finish = function () { if (--pending <= 0) { ready = true; done && done(); } };
    CUES.forEach(function (n) {
      fetchBuf(base + 'sfx_' + n + '.wav', function (b) { if (b) buffers[n] = b; else failed.push(n); finish(); });
    });
    fetchBuf(base + 'anneal_theme.ogg', function (b) { if (b) musicBuf = b; else failed.push('theme'); finish(); });
  }

  function unlock() {
    var c = ac();
    if (c && c.state === 'suspended') c.resume();
  }

  function play(name, gain) {
    if (!on || !ctx || !buffers[name]) return false;
    unlock();
    var src = ctx.createBufferSource();
    var g = ctx.createGain();
    src.buffer = buffers[name];
    g.gain.value = gain === undefined ? 0.55 : gain;
    src.connect(g); g.connect(ctx.destination);
    src.start(0);
    return true;
  }

  function music(want) {
    if (!ctx || !musicBuf) return;
    if (want && !musicNode && on) {
      unlock();
      musicNode = ctx.createBufferSource();
      musicGain = ctx.createGain();
      musicGain.gain.value = 0.30;
      musicNode.buffer = musicBuf;
      musicNode.loop = true;
      musicNode.connect(musicGain); musicGain.connect(ctx.destination);
      musicNode.start(0);
    } else if (!want && musicNode) {
      try { musicNode.stop(0); } catch (e) { /* already stopped */ }
      musicNode = null;
    }
  }

  function toggle() {
    on = !on;
    if (!on) music(false);
    else unlock();
    try { localStorage.setItem('anneal.sound.v1', on ? '1' : '0'); } catch (e) { /* storage off */ }
    return on;
  }

  try { on = localStorage.getItem('anneal.sound.v1') !== '0'; } catch (e) { on = true; }

  return {
    load: load, play: play, music: music, unlock: unlock, toggle: toggle,
    enabled: function () { return on; },
    isReady: function () { return ready; },
    missing: function () { return failed.slice(); },
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = SOUND;
