/**
 * kiln.js — the meta layer: what you keep between pours, and the save that keeps it.
 *
 * THE STANDING DESIGN RULE THIS FILE EXISTS FOR (wing constitution §2): **save/resume, never a
 * full restart.** A failed pour costs you the channel you were in and nothing else — the kiln,
 * the slag and every channel already cleared survive. This is the rule the whole track ships
 * under and it is not negotiable per title.
 *
 * ⚠️ THE UPGRADES ARE ALL MONOTONE ON PURPOSE. See the header of run.js: Internal_Ops/solve.js
 * proves each channel solvable on base numbers, and that proof only carries into real play while
 * every kiln effect can be described as "the same channel, but easier". Adding an upgrade with a
 * downside — an overshoot penalty, a cap, a curse — would quietly void the solver for every
 * channel in the campaign, which is the kind of defect that looks like bad level design for
 * weeks. If a future session wants one, it has to teach the solver about it first.
 *
 * Storage is `localStorage` under a namespaced key. ⛔ Never `localStorage.clear()` and never an
 * unprefixed key: this wing ships to itch and to js13k, and both put several games on one origin.
 */
'use strict';

(function (root, factory) {
  const api = factory(typeof require === 'function' ? require('./run.js') : root.RUN);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.KILN = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (RUN) {

  const KEY = 'anneal.save.v1';
  const VERSION = 1;

  /**
   * The eight tracks. `cost` is the price of the NEXT level, indexed by the level you already own,
   * so the array length is also the cap — one number, not two that can disagree.
   *
   * The blurb is what the kiln screen prints. It is written here rather than in the renderer so
   * the text and the effect cannot drift apart; `effect()` returns the same fact as a sentence.
   */
  const TRACKS = [
    {
      id: 'spout', name: 'SECOND SPOUT', costs: [14, 34, 70],
      blurb: 'A wider mouth. Every pour begins with one more mote.',
      effect: (l) => l ? `Start +${l}` : 'Start +0',
    },
    {
      id: 'ember', name: 'EMBER AFFINITY', costs: [12, 30, 62],
      blurb: 'Seals yield sooner to a fire that knows them. Ember flaws need fewer motes.',
      effect: (l) => l ? `Seal threshold -${l}` : 'No affinity',
    },
    {
      id: 'frost', name: 'FROST AFFINITY', costs: [12, 30, 62],
      blurb: 'A colder pour bridges a race with less of itself. Frost flaws need fewer motes.',
      effect: (l) => l ? `Race threshold -${l}` : 'No affinity',
    },
    {
      id: 'iron', name: 'IRON AFFINITY', costs: [12, 30, 62],
      blurb: 'Iron remembers being struck. Slagwalls need fewer motes.',
      effect: (l) => l ? `Slagwall threshold -${l}` : 'No affinity',
    },
    {
      id: 'reheat', name: 'REHEAT', costs: [26, 60, 130],
      blurb: 'Turn the pour to the next temper mid-channel. The scarcest thing in the foundry.',
      effect: (l) => l ? `${l} charge${l > 1 ? 's' : ''} per pour` : 'None',
    },
    {
      id: 'farsight', name: 'FARSIGHT', costs: [20, 48],
      blurb: 'Read the crucibles further up the shaft before you must commit to them.',
      effect: (l) => `See ${1 + l} row${1 + l > 1 ? 's' : ''} ahead`,
    },
    {
      id: 'draw', name: 'DRAW', costs: [22, 52],
      blurb: 'Break a flaw more cleanly. Every flaw costs fewer motes to pass.',
      effect: (l) => l ? `Flaw cost -${l}` : 'Full cost',
    },
    {
      id: 'bellows', name: 'BELLOWS', costs: [18, 44],
      blurb: 'A slower, steadier draught. The shaft comes at you with less hurry.',
      effect: (l) => l ? `Rise -${Math.round((1 - Math.pow(0.88, l)) * 100)}%` : 'Full speed',
    },
  ];

  const TRACK_BY_ID = {};
  for (const t of TRACKS) TRACK_BY_ID[t.id] = t;

  /* ── the save ─────────────────────────────────────────────────────────────────────────────── */

  function fresh() {
    return {
      version: VERSION,
      slag: 0,
      kiln: RUN.emptyKiln(),
      cleared: {},   // channelId -> true
      best: {},      // channelId -> best arrival count
      seen: {},      // channelId -> true, for "new channel" marking
      poured: 0,     // total pours, cleared or not
      lost: 0,
    };
  }

  /**
   * Rebuild a save from untrusted JSON. ⛔ Never trust the shape of anything that came out of
   * storage: a half-written save, a save from an older build, or a user poking at devtools must
   * all produce a PLAYABLE game rather than a crash on the title screen. Unknown fields are
   * dropped, bad types are replaced, and levels are clamped to the track caps.
   */
  function normalise(raw) {
    const s = fresh();
    if (!raw || typeof raw !== 'object') return s;
    if (Number.isFinite(raw.slag) && raw.slag > 0) s.slag = Math.floor(raw.slag);
    if (Number.isFinite(raw.poured) && raw.poured > 0) s.poured = Math.floor(raw.poured);
    if (Number.isFinite(raw.lost) && raw.lost > 0) s.lost = Math.floor(raw.lost);
    if (raw.kiln && typeof raw.kiln === 'object') {
      for (const t of TRACKS) {
        const v = raw.kiln[t.id];
        if (Number.isInteger(v) && v > 0) s.kiln[t.id] = Math.min(v, t.costs.length);
      }
    }
    for (const key of ['cleared', 'seen']) {
      if (raw[key] && typeof raw[key] === 'object') {
        for (const k of Object.keys(raw[key])) if (raw[key][k]) s[key][k] = true;
      }
    }
    if (raw.best && typeof raw.best === 'object') {
      for (const k of Object.keys(raw.best)) {
        const v = raw.best[k];
        if (Number.isFinite(v) && v > 0) s.best[k] = Math.floor(v);
      }
    }
    return s;
  }

  function load(storage) {
    const st = storage || (typeof localStorage !== 'undefined' ? localStorage : null);
    if (!st) return fresh();
    try {
      return normalise(JSON.parse(st.getItem(KEY)));
    } catch (e) {
      // A corrupt save is a fresh save, not an error dialog. Never let storage end a session.
      return fresh();
    }
  }

  function save(s, storage) {
    const st = storage || (typeof localStorage !== 'undefined' ? localStorage : null);
    if (!st) return false;
    try { st.setItem(KEY, JSON.stringify(s)); return true; } catch (e) { return false; }
  }

  /* ── shop arithmetic ──────────────────────────────────────────────────────────────────────── */

  /** Price of the next level of a track, or null when it is maxed. */
  function nextCost(s, id) {
    const t = TRACK_BY_ID[id];
    if (!t) return null;
    const lvl = s.kiln[id] || 0;
    return lvl >= t.costs.length ? null : t.costs[lvl];
  }

  function canBuy(s, id) {
    const c = nextCost(s, id);
    return c !== null && s.slag >= c;
  }

  /**
   * Buy one level. Returns a result rather than throwing — the kiln screen shows a refusal as a
   * message, and a refusal must never be able to take the game down with it.
   */
  function buy(s, id) {
    const t = TRACK_BY_ID[id];
    if (!t) return { ok: false, reason: 'unknown-track' };
    const c = nextCost(s, id);
    if (c === null) return { ok: false, reason: 'maxed' };
    if (s.slag < c) return { ok: false, reason: 'too-poor', short: c - s.slag };
    s.slag -= c;
    s.kiln[id] = (s.kiln[id] || 0) + 1;
    return { ok: true, level: s.kiln[id], spent: c };
  }

  /** Record the outcome of a pour. Returns the reward breakdown so the result screen can show it. */
  function record(s, channelId, run, RUNAPI) {
    const R = RUNAPI || RUN;
    s.poured++;
    if (run.status !== 'cleared') { s.lost++; return { total: 0, base: 0, overflow: 0, first: 0 }; }
    const firstClear = !s.cleared[channelId];
    const rw = R.reward(run, firstClear);
    s.slag += rw.total;
    s.cleared[channelId] = true;
    if (!s.best[channelId] || run.count > s.best[channelId]) s.best[channelId] = run.count;
    return rw;
  }

  /**
   * How far the campaign is unlocked. A channel is playable when the one before it is cleared, so
   * the campaign is a line rather than a menu — and the LAST cleared channel is the ending.
   * ⚠️ Index-based, not id-based, so reordering `channels.js` never strands a save.
   */
  function unlockedCount(s, channels) {
    let n = 1;
    for (let i = 0; i < channels.length; i++) {
      if (s.cleared[channels[i].id]) n = Math.min(channels.length, i + 2);
      else break;
    }
    return n;
  }

  function finished(s, channels) {
    return channels.length > 0 && channels.every((c) => s.cleared[c.id]);
  }

  return {
    KEY, VERSION, TRACKS, TRACK_BY_ID,
    fresh, normalise, load, save,
    nextCost, canBuy, buy, record, unlockedCount, finished,
  };
});
