/**
 * kittens.js — STRAYWOOD. Every lost kitten is GENERATED: a genome (coat, markings, ears, tail, pose, eyes, face shape
 * and a name), an 8x8 field sprite the witch finds at the edge of a thicket, and a 24x24 portrait for the book of the
 * kittens brought home. THE SINGLE SOURCE OF TRUTH for both (the contact sheet, the store captures and the game all
 * require this file).
 *
 * ⛔ wing §0-ART-f: the volume must be a property of the ENTITY. A kitten is a limbed creature, so its picture has many
 *    independent parameters that survive at the shipped size (coat x markings x ears x tail x pose on the field; head
 *    shape, ear set, eye shape, markings and coat on the portrait). Judged on a CONTACT SHEET, never a statistic.
 * ⛔ PALETTE LAW (§0-ART-g): shade 0 next to 1 is worth nothing. The wood floor is shade 0/1, so every kitten carries a
 *    dark (shade 3) ring on its silhouette, and a black kitten reads by silhouette with lit eyes.
 * ⛔ Within one wood the field designs are forced distinct on (coat, pose) — 8 coats x 4 poses = 32 pairs for at most 12
 *    kittens — and the names are forced distinct.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.KITTENS = api;
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const LIT = 0, FACE = 1, MID = 2, SHADOW = 3, NONE = 255;

  function hash2(x, y) { let n = (x | 0) * 374761393 + (y | 0) * 668265263; n = Math.imul(n ^ (n >>> 13), 1274126177); return ((n ^ (n >>> 16)) >>> 0) / 4294967296; }

  // coats: `fill` is the base shade; the painters below add the pattern. Order = how common they are in a wood.
  const COATS = ['tabby', 'black', 'white', 'tuxedo', 'ginger', 'calico', 'grey', 'point'];
  const COAT_WORD = { tabby: 'TABBY', black: 'BLACK', white: 'WHITE', tuxedo: 'TUXEDO', ginger: 'GINGER', calico: 'CALICO', grey: 'GREY', point: 'POINTED' };
  const POSES = ['sit', 'loaf', 'side', 'curl'];

  // ⛔ NAMES: short (<= 5 letters, so a name fits a 36 px portrait slot at 6 px a glyph) and forced distinct in a wood.
  const NAMES = ('PIP MOTH SOOT FIG WREN BEAN TANSY NIB MOTE PLUM SAGE ASH BURR TWIG FERN ACORN HAZEL MOSS POPPY ' +
    'CLOVE MINT BASIL THYME ROWAN ELDER BRAM SLOE HOLLY IVY JUNE MAPLE PINE CONE DUSK DAWN STAR MOON COMET PEBBLE ' +
    'FLINT SLATE CLAY OAT BARLEY RYE WHEAT MILLET CRUMB BUN SCONE TOAST TOFFEE FUDGE MOCHA COCOA HONEY TEA CHAI ' +
    'BISCUIT MUFFIN PUDDING TRUFFLE PEPPER NUTMEG GINGER SAFFRON INK QUILL PAGE BOOK RUNE CHARM SPELL WAND BROOM ' +
    'KETTLE LADLE THIMBLE BUTTON BOBBIN SPOOL YARN TASSEL LACE VELVET TWEED FELT SILK WOOL LINT FLUFF TUFT WISP ' +
    'PUFF SMOKE EMBER SPARK CINDER FLARE GLOW GLINT BEACON LAMP CANDLE WICK TAPER MOUSE VOLE SHREW OWL ROBIN FINCH ' +
    'LARK DOVE CROW ROOK JAY TOAD NEWT MIDGE GNAT BUG BEETLE MOTHLET TICK TOCK DOT DASH ZIG ZAG BIP BOP PIM POM ' +
    'TIM TAM LUNA SOL ORBIT PIXEL NOVA COSMO OLIVE OLLIE MILO OTIS PERCY PENNY POLLY MOLLY DOLLY TILLY LILY ROSY ' +
    'NELL BELL BEA MAE IDA ADA EVIE ELSIE FLO GUS HUGO IGGY JACK KIT LOU MAX NED OSSIE REX SID TED VIC WALT ZED')
    .split(/\s+/).filter((n) => n && n.length <= 5);

  /** The kittens of one wood. `seed` = the wood's seed, `k` = how many. Deterministic; no random draw leaks into the
   *  wood's generator (this uses its own hash). */
  function litter(seed, k) {
    const used = new Set(), names = new Set(), faces = new Set(), out = [];
    for (let i = 0; i < k; i++) {
      const h = (n) => hash2(seed * 977 + i * 31 + n * 7, seed * 13 + n * 101 + i);
      let coat = Math.floor(h(1) * COATS.length), pose = Math.floor(h(2) * POSES.length), guard = 0;
      while (used.has(coat + ':' + pose) && guard++ < 64) { pose = (pose + 1) % POSES.length; if (guard % POSES.length === 0) coat = (coat + 1) % COATS.length; }
      used.add(coat + ':' + pose);
      let ni = Math.floor(h(3) * NAMES.length), g2 = 0;
      while (names.has(NAMES[ni]) && g2++ < NAMES.length) ni = (ni + 1) % NAMES.length;
      names.add(NAMES[ni]);
      // ⛔ REVIEW 2026-09-28 (defect 4): distinctness was forced on (coat, pose), but the PORTRAIT does not show the pose,
      // so HOME TONIGHT showed three plain white heads side by side. The portrait's own features — coat, ears, eyes — are
      // now forced distinct within a litter too (8 x 3 x 3 = 72 combinations for at most 12 kittens).
      const EARS = ['fold', 'tall', 'point'], EYES = ['sleepy', 'round', 'almond'];
      let ears = h(4) < 0.18 ? 0 : h(4) < 0.55 ? 1 : 2, eyes = h(7) < 0.2 ? 0 : h(7) < 0.6 ? 1 : 2, g3 = 0;
      while (faces.has(coat + ':' + ears + ':' + eyes) && g3++ < 9) { eyes = (eyes + 1) % 3; if (g3 % 3 === 0) ears = (ears + 1) % 3; }
      faces.add(coat + ':' + ears + ':' + eyes);
      out.push({
        coat: COATS[coat], pose: POSES[pose], name: NAMES[ni],
        ears: EARS[ears],                                                 // folded, tall, ordinary
        tail: h(5) < 0.35 ? 'up' : h(5) < 0.7 ? 'curl' : 'wrap',
        face: h(6) < 0.5 ? 1 : -1,                                        // which way she looks / her tail falls
        eyes: EYES[eyes],
        head: h(8),                                                       // 0..1: narrow .. wide (portrait)
        earW: h(9), earH: h(10),                                          // portrait ear proportions
        mark: h(11),                                                      // which markings a coat carries (blaze, socks, patches)
        patchSeed: Math.floor(h(12) * 1e6),
        whisk: h(13) < 0.5,
      });
    }
    return out;
  }

  /* ============================================================ the FIELD sprite (8x8, one cell) */
  // '#' body · 'e' eye · 'n' nose · 't' tail · 'c' closed eye (sleeping) · '.' nothing. Drawn facing RIGHT when mirrored.
  // ⛔ ART ROUND 1 (LOOKED AT art/kittens_field_6x.png): a head 5 px wide put both eyes against the dark ring (every
  // light kitten read as an OWL), a pixel above each ear read as HORNS, the side-on stand read as a TABLE and the curl as
  // a BUN. Now: a big 7 px kitten head whose face has coat between the eyes and the ring, a small body, and no pose that
  // needs more than 8 px to read.
  // '#' outline (always dark) · ':' coat · 'e' eye · 'c' shut eye · 'n' nose · 't' tail · '.' nothing
  const POSE_ROWS = {
    // sitting up, looking at you, tail round to one side
    sit:   ['#.....#.', '##...##.', '#######.', '#:e:e:#.', '#::n::#.', '.#####..', '.#:::#.t', '.##.##tt'],
    // a loaf: the same big head sunk onto a wide low body, paws tucked
    loaf:  ['........', '#.....#.', '##...##.', '#######.', '#:e:e:#.', '#::n::##', '#::::::#', '########'],
    // sitting side-on, facing left: ears up, one eye, a long back and the tail up behind
    // ⛔ ART ROUND 2: the first side-on kitten (head, then a gap, then a tail line) read as the digit 2. Now one solid
    // profile: ears, a round head with its nose at the front, the back running down into a sitting body, tail at the rear.
    // ⛔ ART ROUND 3: a nose pixel at the very front of the profile read as a BEAK (a duck). The muzzle is plain ring now.
    side:  ['.#.#....', '.###....', '#e::#...', '#:::#...', '.#::##..', '.#:::#.t', '.#::::#t', '.######.'],
    // lying asleep with her eyes shut: the big head on its paws
    curl:  ['........', '........', '#.....#.', '##...##.', '#######.', '#:c:c:##', '#::n:::#', '########'],
  };
  /** Draw kitten `d` with her 8x8 cell's top-left at (X, Y). mode: 'wait' (lost, looking about) · 'ride' (on the
   *  broom) · 'ghost' (dotted outline, for the lesson) · 'home'. `blink` closes open eyes for one frame. */
  // ⛔ REVIEW 2026-09-28 (defect 11): a RIDING kitten was drawn with the same full sprite as a waiting one, so nothing but
  // the HUD said who was on the broom, and three riders in the three cells behind the witch fused into one dark band.
  // A rider is now her HEAD only (7x6: ears, face, chin), floating 1 px up over a 5-px shade-1 shadow — a shape no waiting
  // kitten has, with 1 px of floor between neighbouring riders.
  const RIDE_ROWS = ['#.....#', '##...##', '#######', '#:e:e:#', '#::n::#', '.#####.'];
  function drawKitten(p, X, Y, d, mode, blink) {
    X = Math.round(X); Y = Math.round(Y);
    if (mode === 'ride') {
      const ox = X, oy = Y;
      // RE-CHECK (defect 11 residue): a shade-1 shadow on shade-0 floor was invisible (§0-ART-g), and the head alone was
      // the sit sprite minus its legs. A rider now SITS ON A BROOM HANDLE: a full-width dark line one row under her chin
      // (the broom stretching back behind the witch), a silhouette no waiting kitten has.
      for (let i = 0; i <= 7; i++) p.set(ox + i, oy + 7, SHADOW);
      for (let j = 0; j < RIDE_ROWS.length; j++) for (let i = 0; i < 7; i++) {
        const c = RIDE_ROWS[j][i]; if (c === '.') continue;
        if (d.ears === 'fold' && j === 0) continue;
        const x = ox + i, y = oy + j;
        if (c === '#') { p.set(x, y, SHADOW); continue; }
        if (c === 'e') { p.set(x, y, eyeShade(d, blink)); continue; }
        if (c === 'n') { p.set(x, y, dark(d) ? MID : (d.coat === 'grey' ? SHADOW : MID)); continue; }
        p.set(x, y, coatPixel(Object.assign({}, d, { pose: 'sit' }), i, j));
      }
      return;
    }
    const R = POSE_ROWS[d.pose];
    const ghost = mode === 'ghost';
    const mirror = d.face < 0;
    const col = (i) => mirror ? X + 7 - i : X + i;
    for (let j = 0; j < 8; j++) for (let i = 0; i < 8; i++) {
      const c = R[j][i]; if (c === '.') continue;
      if (d.ears === 'fold' && isEarTip(d.pose, i, j)) continue;       // a folded ear has no tip
      const x = col(i), y = Y + j;
      if (ghost) { if ((c === '#' || c === 't' || c === 'n') && (x + y) % 2 === 0) p.set(x, y, SHADOW); continue; }
      if (c === '#' || c === 't') { p.set(x, y, SHADOW); continue; }
      if (c === 'e') { p.set(x, y, eyeShade(d, blink)); continue; }
      if (c === 'c') { p.set(x, y, dark(d) ? MID : SHADOW); continue; }
      if (c === 'n') { p.set(x, y, dark(d) ? MID : (d.coat === 'grey' ? SHADOW : MID)); continue; }
      p.set(x, y, coatPixel(d, i, j));
    }
  }
  const EAR_TIPS = { sit: [[0, 0], [6, 0]], loaf: [[0, 1], [6, 1]], side: [[1, 0], [3, 0]], curl: [[0, 2], [6, 2]] };
  function isEarTip(pose, i, j) { return EAR_TIPS[pose].some(([a, b]) => a === i && b === j); }
  const dark = (d) => d.coat === 'black' || d.coat === 'tuxedo' || d.coat === 'grey';
  function eyeShade(d, blink) {
    if (blink) return dark(d) ? MID : SHADOW;
    return dark(d) ? LIT : SHADOW;               // dark and grey kittens' eyes shine; pale kittens' eyes are dark
  }
  /** The field coat at template pixel (i, j) — a CLASS the eye can read at 1x, never a texture. */
  function coatPixel(d, i, j) {
    switch (d.coat) {
      case 'black': return SHADOW;
      case 'white': return LIT;
      case 'grey': return MID;
      case 'ginger': return FACE;
      case 'tabby': return (i + j) % 2 === 0 && j >= 5 ? MID : FACE;               // pale, with a barred body
      case 'tuxedo': { const face = R_TUX[d.pose]; return face(i, j) ? LIT : SHADOW; }   // dark, white muzzle and bib
      case 'calico': return (i <= 2 && j <= 4) ? SHADOW : (i >= 4 && j >= 5) ? MID : LIT; // pale, a dark cap and a mid patch
      case 'point': return j <= 4 && (d.pose !== 'side') ? (i >= 2 && i <= 4 && j >= 4 ? MID : LIT) : LIT;  // pale with a mid mask
      default: return MID;
    }
  }
  const R_TUX = {
    sit: (i, j) => (j === 4) || (j === 6),
    loaf: (i, j) => (j === 5) || (j === 6 && i >= 2 && i <= 5),
    side: (i, j) => (j === 3 && i <= 2) || (j >= 5 && i <= 3),
    curl: (i, j) => (j === 6),
  };

  /* ============================================================ the PORTRAIT (24x24, head and shoulders) */
  // ⛔ ART ROUND 1 (LOOKED AT art/kittens_portrait_3x.png): the head sat small in its frame, the POINTED coat's mask read
  // as a GAG over the mouth, folded ears read as MOUSE ears, and the eyes were a scatter of pixels. Now: a head that
  // fills the frame, big simple eyes (a dark 3x3 with one lit catch-light, or a shut happy arc), a two-pixel nose and a
  // small mouth, whiskers past the cheek, and every marking a SHAPE (a forehead M, cheek bars, a muzzle, a cap, a mask
  // round the eyes), never a texture.
  function drawPortrait(p, X, Y, d, bg) {
    const S = 24, buf = new Uint8Array(S * S).fill(NONE);
    const set = (x, y, s) => { x = Math.round(x); y = Math.round(y); if (x >= 0 && y >= 0 && x < S && y < S && s !== NONE) buf[y * S + x] = s; };
    const mask = new Uint8Array(S * S);
    const cx = 11.5, cy = 14.5, rx = 8.6 + d.head * 1.6, ry = 7.0 + (1 - d.head) * 0.8;
    const inHead = (x, y) => ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 <= 1;
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
      const tuft = y >= cy + 1 && y <= cy + 3 && Math.abs(x - cx) <= rx + 0.8 && Math.abs(x - cx) >= rx - 1.5 && (y + x) % 2 === 0;
      const shoulders = y >= 21 && Math.abs(x - cx) <= 7 + (y - 21) * 1.5;
      if (inHead(x, y) || tuft || shoulders) mask[y * S + x] = 1;
    }
    // ears: a triangle each side standing on the head's upper curve
    const fold = d.ears === 'fold';
    const earH = fold ? 3 : 5 + Math.round(d.earH * 2) + (d.ears === 'tall' ? 1 : 0);
    const earHalf = 2.5 + d.earW * 1.5, earX = 3.8 + d.earW * 1.2;
    // ⛔ ART ROUND 2: a folded ear drawn as a wide block pushed OUTWARD read as bat horns on a black kitten and bear ears
    // on a grey one. A fold is a small low cap tipped INWARD, lying along the head.
    const ears = [-1, 1].map((sgn) => { const bx = cx + sgn * earX, by = cy - ry * Math.sqrt(Math.max(0, 1 - (earX / rx) ** 2)) + 1; return { sgn, bx, by, tx: bx - sgn * (fold ? 1 : -1), ty: by - earH }; });
    for (const E of ears) for (let y = Math.floor(E.ty); y <= Math.ceil(E.by); y++) {
      const t = (y - E.ty) / Math.max(1, E.by - E.ty), half = fold ? earHalf * (0.35 + 0.35 * t) : earHalf * t, mid = E.tx + (E.bx - E.tx) * t;
      for (let x = Math.floor(mid - half - 0.5); x <= Math.ceil(mid + half + 0.5); x++) if (Math.abs(x - mid) <= half + 0.25 && x >= 0 && x < S && y >= 0) mask[y * S + x] = 1;
    }
    const inM = (x, y) => x >= 0 && y >= 0 && x < S && y < S && mask[y * S + x] === 1;
    const coat = COAT_PAL[d.coat] || COAT_PAL.grey;
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
      if (!inM(x, y)) continue;
      const edge = !inM(x - 1, y) || !inM(x + 1, y) || !inM(x, y - 1) || !inM(x, y + 1);
      set(x, y, edge ? SHADOW : markAt(d, coat, x, y, cx, cy, rx, ry));
    }
    // inner ears: a lighter wedge down the middle of a standing ear
    if (!fold) for (const E of ears) for (let y = Math.ceil(E.ty) + 2; y <= Math.floor(E.by) - 1; y++) {
      const t = (y - E.ty) / Math.max(1, E.by - E.ty), mid = Math.round(E.tx + (E.bx - E.tx) * t), half = Math.max(0, Math.round(earHalf * t * 0.4));
      for (let x = mid - half; x <= mid + half; x++) if (inM(x - 1, y) && inM(x + 1, y) && inM(x, y - 1)) set(x, y, coat.inner);
    }
    // eyes
    const ey = Math.round(cy - 0.5), es = 3.6 + d.head * 0.8;
    for (const sgn of [-1, 1]) {
      const ex = Math.round(cx + sgn * es);
      if (d.eyes === 'sleepy') {             // shut, content: a little arc
        set(ex - 1, ey + 1, coat.eyeLine); set(ex, ey, coat.eyeLine); set(ex + 1, ey + 1, coat.eyeLine);
      } else if (d.eyes === 'round') {       // wide kitten eyes with one catch-light
        for (let j = -1; j <= 1; j++) for (let i = -1; i <= 1; i++) set(ex + i, ey + j, coat.eye);
        set(ex - 1, ey - 1, coat.glint);
        set(ex, ey - 2, NONE);
      } else {                              // almond: wider than tall, a slit pupil
        for (let i = -1; i <= 1; i++) { set(ex + i, ey, coat.eyeIris); set(ex + i, ey - 1, coat.eye); set(ex + i, ey + 1, coat.eye); }
        set(ex - 2 * sgn, ey, coat.eye); set(ex, ey, coat.eye); set(ex, ey - 1, coat.eye);
      }
    }
    // nose and mouth
    const nx = Math.round(cx), ny = ey + 3;
    set(nx, ny, coat.nose); set(nx + 1, ny, coat.nose);
    set(nx - 1, ny + 1, coat.eyeLine); set(nx + 2, ny + 1, coat.eyeLine);
    set(nx, ny + 2, coat.eyeLine); set(nx + 1, ny + 2, coat.eyeLine);
    // whiskers: two short lines each side, drawn out past the cheek onto the background
    if (d.whisk) for (const sgn of [-1, 1]) for (const [dy, slope] of [[0, -0.34], [2, 0.2]]) for (let k = 0; k < 5; k++) {
      const x = Math.round(cx + sgn * (rx - 3.5 + k)), y = Math.round(ny + dy + k * slope);
      set(x, y, inM(x, y) ? coat.whiskIn : SHADOW);
    }
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) { const s = buf[y * S + x]; if (s !== NONE) p.set(X + x, Y + y, s); else if (bg !== undefined && bg !== NONE) p.set(X + x, Y + y, bg); }
  }
  // per coat: base fill, inner ear, eye (the dark of a round eye), the lit catch-light, the line shade for shut eyes and
  // mouth, the nose, and the whisker shade where it crosses fur
  const COAT_PAL = {
    black:  { base: SHADOW, inner: MID, eye: LIT, eyeIris: FACE, glint: SHADOW, eyeLine: FACE, nose: MID, whiskIn: FACE },
    white:  { base: LIT, inner: FACE, eye: SHADOW, eyeIris: MID, glint: LIT, eyeLine: SHADOW, nose: MID, whiskIn: MID },
    grey:   { base: MID, inner: FACE, eye: SHADOW, eyeIris: LIT, glint: LIT, eyeLine: SHADOW, nose: SHADOW, whiskIn: LIT },
    ginger: { base: FACE, inner: LIT, eye: SHADOW, eyeIris: MID, glint: LIT, eyeLine: SHADOW, nose: MID, whiskIn: LIT },
    tabby:  { base: FACE, inner: LIT, eye: SHADOW, eyeIris: MID, glint: LIT, eyeLine: SHADOW, nose: MID, whiskIn: LIT },
    tuxedo: { base: SHADOW, inner: MID, eye: LIT, eyeIris: FACE, glint: SHADOW, eyeLine: SHADOW, nose: MID, whiskIn: FACE },
    calico: { base: LIT, inner: FACE, eye: SHADOW, eyeIris: MID, glint: LIT, eyeLine: SHADOW, nose: MID, whiskIn: MID },
    point:  { base: LIT, inner: FACE, eye: SHADOW, eyeIris: MID, glint: LIT, eyeLine: SHADOW, nose: SHADOW, whiskIn: MID },
  };
  /** The coat at portrait pixel (x, y): the base fill plus the coat's markings, each a SHAPE. */
  function markAt(d, coat, x, y, cx, cy, rx, ry) {
    const dx = x - cx, dy = y - cy, ax = Math.abs(dx);
    const muzzle = ((dx / 3.4) ** 2 + ((dy - 3.2) / 2.6) ** 2) <= 1;
    const chest = y >= 21 && ax <= 3.5;
    switch (d.coat) {
      case 'black': return (d.mark > 0.6 && chest) ? LIT : SHADOW;                    // some black kittens wear a white locket
      case 'white': {                                                                   // plain, a pale cap over one ear, or a grey eye patch
        if (d.mark > 0.6 && dx < -1.5 && dy < -1.5) return FACE;
        if (d.mark > 0.3 && d.mark <= 0.6 && ((dx - 3.5) ** 2 + (dy + 0.5) ** 2) <= 7) return MID;
        return LIT;
      }
      case 'grey': return (d.mark > 0.45 && (muzzle || chest)) ? LIT : MID;            // grey, often with a white muzzle
      case 'ginger':
      case 'tabby': {
        const dark = d.coat === 'tabby' ? SHADOW : MID;
        if (muzzle && d.mark > 0.35) return LIT;
        // the forehead M: three short vertical bars between the ears
        if (dy <= -2.5 && dy >= -6 && (Math.round(dx) === 0 || Math.round(ax) === 2)) return dark;
        // cheek bars: two horizontal strokes on each cheek
        if (ax >= rx - 3.5 && ax <= rx - 1 && (Math.round(dy) === 1 || Math.round(dy) === 3)) return dark;
        if (y >= 21 && (x + Math.round(y / 2)) % 4 === 0) return dark;                  // barred shoulders
        return coat.base;
      }
      case 'tuxedo': return (muzzle || chest || (d.mark > 0.55 && ax <= 1 && dy < 1 && dy > -ry + 1)) ? LIT : SHADOW;
      case 'calico': {
        if (muzzle || chest) return LIT;
        const side = (d.patchSeed & 1) ? 1 : -1;
        if (dx * side > 1 && dy < 1) return SHADOW;                                     // a dark patch over one eye and ear
        if (dx * side < -2 && dy > -2 && dy < 5) return FACE;                            // a pale-orange patch on the other cheek
        return LIT;
      }
      case 'point': {                                                                   // pale, with a soft darker mask
        const mask = ((dx / 5.5) ** 2 + ((dy - 1.5) / 4.2) ** 2) <= 1;
        return mask ? FACE : (y >= 21 ? FACE : LIT);
      }
      default: return coat.base;
    }
  }

  return { COATS, COAT_WORD, POSES, NAMES, litter, drawKitten, drawPortrait, hash2 };
}));
