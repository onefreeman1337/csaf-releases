/**
 * content.js — STRAYWOOD, the FREE EDITION's content: the first ten woods.
 * ⛔ wing §1-DEMO: the other thirty wood SPECS and the ending live in content_full.js, which the free index.html has no
 *    <script> tag for and the free package does not contain.
 * A spec is { id, seed, name }; wood.js turns `seed` into the wood and kittens.js into its litter. `seed` is a SCREENED
 * seed (the run-3 screen's generator, reproduced exactly by Internal_Ops/verify_wood.js), chosen and ordered by
 * Internal_Ops/select_woods_v2.js under SELECTION_2026-09-28_v2.md (written before its first run, after the independent
 * review showed v1's naive arm was a straw man): no human rule in the reviewer's family (nearest-first, farthest-first,
 * group-by-eye, clusters at any threshold) reaches GOLD on any shipped wood, and the screen's insight arm reaches SILVER
 * or better on all of them. Wood 1 is the lesson: the obvious play flies 36 steps over par there.
 * ⛔ The demo-end line is STORE-NEUTRAL (ROOTWORK/NIGHT PLOUGH 1.0.1: "on this page" was false on Game Jolt) and names
 *    only what select_woods_v2.js measures as rising: free 10 are all litters of ten; the paid 30 are 29 of eleven or twelve.
 */
(function (root) {
  'use strict';
  root.CONTENT = {
    edition: 'free',
    woods: [
      { id: 1,  seed: 12,  name: 'BRAMBLE END' },
      { id: 2,  seed: 7,   name: 'OWL HOLLOW' },
      { id: 3,  seed: 40,  name: 'FERN DELL' },
      { id: 4,  seed: 59,  name: 'MOSSY BANK' },
      { id: 5,  seed: 75,  name: 'HAZEL COPSE' },
      { id: 6,  seed: 76,  name: 'FOXGLOVES' },
      { id: 7,  seed: 108, name: 'ACORN RISE' },
      { id: 8,  seed: 111, name: 'TOADSTOOLS' },
      { id: 9,  seed: 145, name: 'BLUEBELLS' },
      { id: 10, seed: 167, name: 'NETTLE LANE' },
    ],
    endingTitle: 'EVERY WINDOW LIT',
    ending: null,
    demoEnd: ['TEN LITTERS ARE HOME.', 'THIRTY MORE WOODS WAIT, MOST OF THEM WITH ELEVEN OR TWELVE KITTENS. THE FULL GAME IS A PAID WINDOWS DOWNLOAD.'],
  };
}(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this)));
