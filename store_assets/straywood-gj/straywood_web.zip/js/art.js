/**
 * art.js — STRAYWOOD. The wood picture, the thickets, the garden and its gate, the witch on her broom, the flight lines,
 * the HUD glyphs, the sky and the title art — THE SINGLE SOURCE OF TRUTH for them (the contact sheets, the store
 * captures and the game all require this file). The kittens live in kittens.js.
 *
 * ⛔ PALETTE LAW (wing §0-ART-g): DMG luma is 158 / 144 / 77 / 39 — shade 0 next to shade 3 is the only strong edge;
 *    0 next to 1 is worth nothing. So the FLOOR (the ground the player reads routes across) is shade 0 with shade-1
 *    leaf litter (texture, never an edge), and everything the player must READ is dark on it: every thicket's rim, every
 *    kitten's ring, the witch, every flight line.
 * ⛔ THE PICTURE MUST NEVER CONTRADICT THE COLLISION (§0z-1): a thicket cell is canopy with a dark rim exactly on the
 *    cell edges that meet the floor; a floor cell is floor. Corners are rounded only where BOTH neighbours are floor, at
 *    most 2 px, inside the thicket cell. Trunks are drawn inside thicket cells, never on the floor.
 * ⛔ §0-ART-b: nothing tiles on a fixed period — litter, leaf clumps and flowers are hashed per PIXEL / per cell.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.ART = api;
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const LIT = 0, FACE = 1, MID = 2, SHADOW = 3, NONE = 255;
  const W = 160, H = 144, FIELD_Y = 24, CELL = 8, GW = 20, GH = 15;
  const FLOOR = 0, GARDEN = 1, THICKET = 2;

  function Plane(w, h, fill) { this.w = w; this.h = h; this.px = new Uint8Array(w * h).fill(fill === undefined ? NONE : fill); }
  Plane.prototype.set = function (x, y, s) { if (s === NONE) return; x = Math.round(x); y = Math.round(y); if (x < 0 || y < 0 || x >= this.w || y >= this.h) return; this.px[y * this.w + x] = s; };
  Plane.prototype.get = function (x, y) { return (x < 0 || y < 0 || x >= this.w || y >= this.h) ? NONE : this.px[y * this.w + x]; };
  Plane.prototype.rect = function (x, y, w, h, s) { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) this.set(x + i, y + j, s); };
  Plane.prototype.hline = function (x0, x1, y, s) { for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) this.set(x, y, s); };
  Plane.prototype.vline = function (x, y0, y1, s) { for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++) this.set(x, y, s); };

  function hash2(x, y) { let n = (x | 0) * 374761393 + (y | 0) * 668265263; n = Math.imul(n ^ (n >>> 13), 1274126177); return ((n ^ (n >>> 16)) >>> 0) / 4294967296; }
  const cellX = (i) => (i % GW) * CELL, cellY = (i) => FIELD_Y + ((i / GW) | 0) * CELL;
  const centre = (i) => ({ x: cellX(i) + 3.5, y: cellY(i) + 3.5 });
  function line(p, x0, y0, x1, y1, s) {
    const n = Math.max(1, Math.ceil(Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0))));
    for (let k = 0; k <= n; k++) p.set(Math.round(x0 + (x1 - x0) * k / n), Math.round(y0 + (y1 - y0) * k / n), s);
  }

  /* ------------------------------------------------------------------ the floor */
  /** Smooth value noise in [0,1] at a cell size of `s` px (bilinear over hashed lattice corners). */
  function vnoise(x, y, s, seed) {
    const gx = Math.floor(x / s), gy = Math.floor(y / s), fx = x / s - gx, fy = y / s - gy;
    const a = hash2(gx + seed, gy), b = hash2(gx + 1 + seed, gy), c = hash2(gx + seed, gy + 1), d = hash2(gx + 1 + seed, gy + 1);
    const u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy);
    return (a * (1 - u) + b * u) * (1 - v) + (c * (1 - u) + d * u) * v;
  }
  /** The wood floor: shade 0 with shade-1 leaf litter and grass tufts, hashed per pixel, over soft moss patches.
   *  ⛔ STORE-SHOT ROUND 1 (LOOKED AT shot_9 at 2x): the floor was a flat lime plain between the thickets and the
   *  gallery read BARE. Now low-frequency moss patches (a shade-1 dither where smooth noise runs high) break the plain up
   *  at the scale of several cells, so the eye reads a meadow; it stays shade 0/1, which is TEXTURE (0 next to 1 is worth
   *  nothing as an edge, §0-ART-g), so it can never be mistaken for a thicket's dark rim. */
  function floorPixel(px, py) {
    const h = hash2(px, py * 3 + 11);
    if (h < 0.05) return FACE;                                          // fallen leaves
    if (py % 4 === 2 && hash2(px >> 1, py) < 0.08 && hash2(px, py - 1) < 0.5) return FACE;   // grass tufts
    const m = vnoise(px, py, 11, 17) * 0.65 + vnoise(px, py, 5, 41) * 0.35;
    if (m > 0.62 && ((px + py) % 2 === 0 || m > 0.74)) return FACE;     // moss
    return LIT;
  }

  /* ------------------------------------------------------------------ the wood */
  /** The static picture of a wood. `G` from WOOD.generate. */
  function woodPlane(G) {
    const p = new Plane(W, H, LIT);
    // ⛔ REVIEW 2026-09-28 (defect 6, MAJOR): the picture showed passages the collision does not have. (a) Floor the witch
    // can never reach (a pocket sealed by thickets, 312 cells over 40 woods) looked like open wood behind a doorway, so it
    // is DRAWN AS THICKET: `vis` = land OR unreachable. (b) Where two thicket cells touch only at a CORNER, both corners were
    // rounded and a diagonal slit of floor ran between them — a short-cut up to 32 steps shorter than the real way. A
    // corner is now rounded only if its DIAGONAL neighbour is floor too, and a diagonal-only joint is BRIDGED with a 2-px
    // canopy wedge in each of the two floor cells beside it (inside their outer corner; both stay open floor and the
    // witch never moves diagonally), so the eye reads one wall.
    const visC = (c) => !!G.land[c] || !G.reach[c];
    const landC = (x, y) => (x < 0 || y < 0 || x >= GW) ? false : (y >= GH ? true : visC(y * GW + x));
    const FH = GH * CELL, mask = new Uint8Array(W * FH);
    for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
      if (!visC(y * GW + x)) continue;
      const L = landC(x - 1, y), R = landC(x + 1, y), U = landC(x, y - 1), D = landC(x, y + 1);
      const ul = !L && !U && !landC(x - 1, y - 1), ur = !R && !U && !landC(x + 1, y - 1), dl = !L && !D && !landC(x - 1, y + 1), dr = !R && !D && !landC(x + 1, y + 1);
      for (let j = 0; j < CELL; j++) for (let i = 0; i < CELL; i++) {
        const cut = (ul && i + j < 3) || (ur && (7 - i) + j < 3) || (dl && i + (7 - j) < 3) || (dr && (7 - i) + (7 - j) < 3);
        if (!cut) mask[(y * CELL + j) * W + x * CELL + i] = 1;
      }
    }
    // the diagonal bridges: for every pair of vis cells touching only at a corner, fill a 2-px wedge in both floor cells
    for (let y = 0; y < GH - 1; y++) for (let x = 0; x < GW; x++) {
      for (const dx of [-1, 1]) {
        const x2 = x + dx; if (x2 < 0 || x2 >= GW) continue;
        if (!landC(x, y) || !landC(x2, y + 1) || landC(x2, y) || landC(x, y + 1)) continue;
        // floor cell A = (x2, y) and floor cell B = (x, y + 1); the joint is at the shared corner point
        const jx = dx > 0 ? (x + 1) * CELL : x * CELL, jy = (y + 1) * CELL;   // pixel corner (field coords)
        for (let a = 0; a < 3; a++) for (let b = 0; b < 3 - a; b++) {
          // wedge in A: just right (dx>0) / left (dx<0) of the joint, above it; wedge in B: the mirror, below it
          const ax = dx > 0 ? jx + a : jx - 1 - a, ay = jy - 1 - b, bx = dx > 0 ? jx - 1 - a : jx + a, by = jy + b;
          if (ax >= 0 && ax < W && ay >= 0) mask[ay * W + ax] = 1;
          if (bx >= 0 && bx < W && by < FH) mask[by * W + bx] = 1;
        }
      }
    }
    const isLand = (px, fy) => (px < 0 || px >= W || fy < 0) ? false : (fy >= FH ? true : !!mask[fy * W + px]);
    for (let fy = 0; fy < FH; fy++) for (let px = 0; px < W; px++) {
      const py = FIELD_Y + fy;
      if (!isLand(px, fy)) {
        // the canopy's soft shadow on the floor just below and right of a thicket (texture, shade 1)
        const shade = (isLand(px, fy - 1) || isLand(px, fy - 2) || isLand(px - 1, fy - 1)) && hash2(px, fy) < 0.7;
        p.set(px, py, shade ? FACE : floorPixel(px, py));
        continue;
      }
      const cy = (fy / CELL) | 0, cx = (px / CELL) | 0, kind = G.kind[cy * GW + cx];
      if (kind === GARDEN) { p.set(px, py, hedgePixel(px, fy - (GH - 1) * CELL, !isLand(px, fy - 1), G.seed)); continue; }
      const rim = !isLand(px - 1, fy) || !isLand(px + 1, fy) || !isLand(px, fy - 1) || !isLand(px, fy + 1);
      if (rim) { p.set(px, py, SHADOW); continue; }
      p.set(px, py, canopyPixel(px, fy, G.seed));
    }
    // trunks: where a thicket's bottom edge meets the floor, a dark trunk stub with a lit side, inside the thicket cell
    for (let y = 0; y < GH - 1; y++) for (let x = 0; x < GW; x++) {
      const c = y * GW + x; if (G.kind[c] !== THICKET || landC(x, y + 1)) continue;
      const h = hash2(x * 7 + G.seed, y * 13);
      if (h < 0.55) { const tx = x * CELL + 2 + Math.floor(h * 7) % 4, ty = FIELD_Y + y * CELL + 5; p.rect(tx, ty, 2, 2, SHADOW); p.set(tx - 1, ty + 1, SHADOW); p.set(tx + 2, ty + 1, SHADOW); p.set(tx, ty, MID); }
    }
    // mushrooms and flowers on the floor, hashed per cell, never on a kitten's cell or the gate
    for (let c = 0; c < GW * GH; c++) {
      if (visC(c) || c === G.jetty || G.kitAt[c] >= 0) continue;
      const h = hash2(c * 31 + G.seed, 7), X = cellX(c), Y = cellY(c), j1 = Math.floor(hash2(c, G.seed + 3) * 4), j2 = Math.floor(hash2(G.seed + 5, c) * 3);
      if (h < 0.035) { const mx = X + 2 + j1, my = Y + 3; p.hline(mx - 1, mx + 1, my, SHADOW); p.set(mx, my - 1, SHADOW); p.set(mx, my + 1, MID); p.set(mx - 1, my - 1, MID); }        // a toadstool
      else if (h < 0.09) { const fx = X + 2 + j1, fy2 = Y + 2 + j2; p.set(fx, fy2, MID); p.set(fx - 1, fy2, FACE); p.set(fx + 1, fy2, FACE); p.set(fx, fy2 - 1, FACE); p.set(fx, fy2 + 1, FACE); }   // a flower
      else if (h < 0.14) { const fx = X + 2 + j1, fy2 = Y + 3 + j2; p.set(fx, fy2, MID); p.set(fx - 1, fy2 - 1, MID); p.set(fx + 1, fy2 - 1, MID); p.set(fx - 2, fy2 - 2, MID); p.set(fx + 2, fy2 - 2, MID); p.set(fx, fy2 - 1, MID); }   // a fern sprig
      else if (h < 0.17) { const sx = X + 2 + j1, sy = Y + 4 + (j2 % 2); p.hline(sx, sx + 2, sy, FACE); p.hline(sx, sx + 2, sy + 1, MID); }          // a flat stone
    }
    drawGate(p, G);
    return p;
  }
  /** Canopy: overlapping leaf clumps (shade 2), each lit on its upper-left (shade 1, a few lit tips) and dark beneath. */
  function canopyPixel(px, fy, seed) {
    // a 5-px clump lattice, offset every other row, jittered by hash so no two thickets repeat
    const row = Math.floor(fy / 5), off = (row % 2) * 2, col = Math.floor((px + off) / 5);
    const cxp = col * 5 - off + 2 + Math.floor(hash2(col + seed, row) * 2) - 0.5, cyp = row * 5 + 2 + Math.floor(hash2(row, col + seed) * 2) - 0.5;
    const dx = px - cxp, dy = fy - cyp, r2 = dx * dx + dy * dy;
    if (r2 <= 1.2 && dx < 0.5 && dy < 0.5) return hash2(px, fy) < 0.25 ? LIT : FACE;
    if (dx + dy > 2.4 && r2 < 7) return SHADOW;
    if (hash2(px * 3, fy * 5 + seed) < 0.05) return SHADOW;
    return MID;
  }
  /** The garden along the bottom: a low dry-stone wall seen from above.
   *  ⛔ REVIEW 2026-09-28 (defect 7, MAJOR): it was a dark-rimmed hedge, and a kitten waiting against it put her own
   *  dark bottom outline straight onto the hedge's dark rim — a third of the litter read as bumps on the hedge. The wall
   *  top is now LIT capstones (shade 0) with a shade-1 course under them, so a kitten's dark outline always sits on light;
   *  below that, coursed stones (shade 2) with dark joints. It is still a wall: the dark joints and the shade-2 courses
   *  never read as floor. */
  function hedgePixel(px, j, edge, seed) {
    if (j <= 1) return ((px + (seed & 3)) % 5 === 0 && j === 1) ? FACE : LIT;   // capstones, split every 5 px
    if (j === 2) return FACE;
    const row = Math.floor((j - 3) / 3), off = (row % 2) * 3, joint = ((px + off + (seed & 3)) % 6 === 0) || ((j - 3) % 3 === 2);
    if (joint) return SHADOW;
    return hash2(px, j + seed) < 0.12 ? FACE : MID;
  }
  /** The cottage gate in the garden row under the gate cell, a lamp post either side, and stepping stones on the gate
   *  cell itself (the doorstep the kittens are brought to). */
  function drawGate(p, G) {
    const gx = G.jetty % GW, X = gx * CELL, Y = FIELD_Y + (GH - 1) * CELL, TY = cellY(G.jetty);
    // the gate: two posts and a lit picket gate between
    p.rect(X, Y, 8, 8, LIT);
    p.vline(X, Y, Y + 7, SHADOW); p.vline(X + 7, Y, Y + 7, SHADOW);
    for (let i = 1; i <= 6; i++) { p.set(X + i, Y + 2, SHADOW); p.set(X + i, Y + 6, SHADOW); if (i % 2 === 1) p.vline(X + i, Y + 1, Y + 7, MID); }
    p.set(X, Y - 1, SHADOW); p.set(X + 7, Y - 1, SHADOW);
    // lamps on the posts either side (in the hedge cells, which are garden = land)
    for (const lx of [X - 3, X + 10]) { if (lx < 1 || lx > W - 3) continue; p.vline(lx, Y + 1, Y + 7, SHADOW); p.rect(lx - 1, Y - 1, 3, 3, SHADOW); p.set(lx, Y, LIT); }
    // stepping stones on the doorstep cell (floor): three flat lit stones ringed dark
    for (const [sx, sy] of [[1, 5], [4, 2], [4, 6]]) { p.rect(TY === undefined ? 0 : X + sx, TY + sy, 3, 2, LIT); p.hline(X + sx, X + sx + 2, TY + sy + 2, MID); p.set(X + sx - 1, TY + sy + 1, MID); p.set(X + sx + 3, TY + sy + 1, MID); }
  }

  /* ------------------------------------------------------------------ the witch */
  // ⛔ ART ROUND 1 (LOOKED AT art/sprites_6x.png): a symmetric stacked cone over a triangular body read as a CHRISTMAS
  // TREE. Now: the hat's tip BENDS BACK, the brim is wide and flat, a lit face sits under it, a dark cloak, and a long
  // horizontal broom whose straw fans out behind her.
  // 11 wide x 12 tall: her hat rises 4 px above her cell; she faces RIGHT (mirrored for left).
  // 3 = dark · 0 = lit (face) · 2 = mid (the broom's straw) · . = nothing. Row 0 = 4 px above the cell top.
  const WITCH = [
    '..33.......',
    '...33......',
    '....33.....',
    '....333....',
    '.3333333...',
    '...300.....',
    '...3000....',
    '...333.....',
    '..33333....',
    '22333333333',
    '222.3.3....',
    '.2.........',
  ];
  /** Draw the witch with her cell's top-left at (X, Y). `face` +1 right / -1 left; `frame` bobs her 1 px while flying;
   *  `moving` draws a little swirl of leaves behind her. She carries a 1-px LIT halo so she reads on the dark canopy. */
  function drawWitch(p, X, Y, face, frame, moving) {
    X = Math.round(X); Y = Math.round(Y) - 4 + (frame ? 1 : 0);
    const f = face < 0 ? -1 : 1, ox = X - 1;
    const WW = WITCH[0].length;
    const col = (i) => f > 0 ? ox + i : ox + 9 - i;
    for (let j = 0; j < WITCH.length; j++) for (let i = 0; i < WW; i++) if (WITCH[j][i] !== '.') for (const [dx, dy] of [[1, 0], [-1, 0], [0, -1], [0, 1]]) {
      const ni = i + dx, nj = j + dy; if (ni < 0 || nj < 0 || ni >= WW || nj >= WITCH.length || WITCH[nj][ni] === '.') p.set(col(ni), Y + nj, LIT);
    }
    for (let j = 0; j < WITCH.length; j++) for (let i = 0; i < WW; i++) {
      const ch = WITCH[j][i]; if (ch === '.') continue;
      p.set(col(i), Y + j, ch === '3' ? SHADOW : ch === '0' ? LIT : MID);
    }
    if (moving) { p.set(col(-1), Y + 8, FACE); p.set(col(-2), Y + 9, FACE); p.set(col(-1), Y + 10, FACE); }
  }

  /** A flight line along a list of cells (dotted through the cell centres). `phase` animates the dots. */
  function drawLine(p, cells, s, phase, gap) {
    gap = gap || 3;
    for (let k = 1; k < cells.length; k++) {
      const a = centre(cells[k - 1]), b = centre(cells[k]);
      const n = 8;
      for (let t = 0; t < n; t++) { if ((t + k * n + (phase || 0)) % gap === 0) continue; p.set(Math.round(a.x + (b.x - a.x) * t / n), Math.round(a.y + (b.y - a.y) * t / n) + 1, s); }
    }
  }

  /** The HUD's kitten head (7x6): lit = a free seat / a kitten home, dark = a kitten riding / still out. */
  function kitGlyph(p, x, y, lit) {
    const G = ['3.....3', '33...33', '3333333', '3.3.3.3', '3333333', '.33333.'];
    for (let j = 0; j < G.length; j++) for (let i = 0; i < 7; i++) {
      const ch = G[j][i]; if (ch === '.' && !(j === 3 && lit)) continue;
      if (ch === '3') p.set(x + i, y + j, lit ? LIT : SHADOW); else if (j === 3) p.set(x + i, y + j, lit ? SHADOW : LIT);
    }
  }

  /** The sky band (24 rows): dusk over the wood. Shade-2 sky with shade-1 cloud bars, a lit moon rising, the first stars,
   *  and the dark saw-edge of the far treeline along the bottom. */
  function skyBand(p, seedVar) {
    for (let y = 0; y < FIELD_Y; y++) for (let x = 0; x < W; x++) p.set(x, y, MID);
    // ⛔ SCREENS ROUND 1 (LOOKED AT 05_broom_loaded / 12_reveal_least at 3x): a moon at x 126-140 sat under the HUD's
    // right-hand text on every screen. ⛔ REVIEW 2026-09-28 (defect 5, MAJOR): the two shade-1 CLOUD BARS that stayed sat
    // in the gap between "FLOWN" and its number at glyph mid-height, and the score read "FLOWN-2" on every screen and in
    // every store image. Both HUD lines are full width, so the play sky carries NOTHING in the text rows: plain shade 2,
    // no clouds, no stars — the title carries the moon and the sky's detail.
    // the far treeline: pointed crowns, hashed per column, ending 2 px above the field
    for (let x = 0; x < W; x++) {
      const crown = Math.floor(hash2(Math.floor(x / 5) + seedVar * 17, 3) * 5), tip = (x % 5 === 2) ? 1 : 0;
      const top = FIELD_Y - 6 - crown - tip;
      for (let y = top; y < FIELD_Y - 2; y++) p.set(x, y, SHADOW);
    }
    // ⛔ REVIEW 2026-09-28 (defect 16): kittens in the top row joined the solid dark band above them and lost their
    // silhouette. The band now ends in a dark rule and a LIT strip, so a row-0 kitten's dark ears sit on shade 0.
    p.hline(0, W - 1, FIELD_Y - 2, SHADOW);
    p.hline(0, W - 1, FIELD_Y - 1, LIT);
  }

  /* ============================================================================ THE TITLE ART
   * Baked to art/title.png by Internal_Ops/build_art.js (a REAL shipped file, drawn with drawImage — never read back, so
   * it works on the paid build's file:// origin). A big moon over the treetops, the witch on her broom crossing it with
   * three kittens riding behind, the cottage below with its windows lit and smoke from the chimney, the wood's dark
   * crowns either side, the lettering in a dark band at the top. */
  function titlePlane(font, K) {
    const p = new Plane(W, H, MID);
    // sky: shade 2, cloud bars, stars
    [[28, 40, 22], [130, 58, 20]].forEach(([cx, cy, L]) => { for (let i = -L; i <= L; i++) { p.set(cx + i, cy, FACE); if (Math.abs(i) < L - 7) p.set(cx + i + 3, cy - 1, FACE); } });
    for (let s = 0; s < 22; s++) { const sx = Math.floor(hash2(s, 91) * W), sy = 26 + Math.floor(hash2(91, s) * 50); p.set(sx, sy, LIT); if (s % 5 === 0) { p.set(sx - 1, sy, FACE); p.set(sx + 1, sy, FACE); } }
    // the moon: large, lit, a clean disc with soft craters
    const mx = 86, my = 58, mr = 28;
    for (let j = -mr; j <= mr; j++) for (let i = -mr; i <= mr; i++) if (i * i + j * j <= mr * mr) p.set(mx + i, my + j, LIT);
    for (const [cx, cy, r] of [[-8, -6, 4], [7, 5, 5], [-2, 12, 3], [10, -10, 2]]) for (let j = -r; j <= r; j++) for (let i = -r; i <= r; i++) if (i * i + j * j <= r * r) p.set(mx + cx + i, my + cy + j, FACE);
    // ⛔ TITLE ROUND 1 (LOOKED AT art/zoom_title_4x.png): the witch was a small smudge on the moon with no readable
    // kittens, and the wood was one flat speckled mass (read as TV static). Now: the witch drawn at 2x in silhouette
    // across the moon, three kittens with pricked ears riding the broom behind her; the wood is rows of round tree crowns.
    // TITLE ROUND 2: with the witch at the moon's left edge her kittens sat on the dark sky and read as a FENCE. She
    // rides the moon's right half now, so the three kittens behind her are silhouetted on the moon itself.
    // TITLE ROUND 3: at wy 36 her hat stood off the moon's top and the kittens (4 rows high) read as a row of SPIKES. She
    // sits inside the disc now, and each kitten is a 6x6 sitting cat (ears, head, neck, body) at 2x.
    const wx = 86, wy = 44;
    const SIL = [
      '...33.............',
      '....33............',
      '.....33...........',
      '.....333..........',
      '..33333333........',
      '.....3333.........',
      '.....33333........',
      '.....3333.........',
      '....333333........',
      '3333333333333333..',
      '333.33.33.........',
      '.3................',
    ];
    const KS = ['3...3.', '33333.', '33333.', '.333..', '33333.', '333333'];
    const sil = (px, py) => { for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) p.set(px + dx, py + dy, SHADOW); };
    for (let j = 0; j < SIL.length; j++) for (let i = 0; i < SIL[j].length; i++) if (SIL[j][i] === '3') sil(wx + i * 2, wy + j * 2);
    // three kitten silhouettes sitting along the handle BEHIND her (she faces right, so they sit to her left)
    for (const kx of [wx - 11, wx - 23, wx - 35]) {
      for (let j = 0; j < KS.length; j++) for (let i = 0; i < KS[j].length; i++) if (KS[j][i] === '3') sil(kx + i * 2, wy + 18 - 12 + j * 2);
      sil(kx - 2, wy + 12); sil(kx - 3, wy + 10);                               // a tail curling up
    }
    for (let i = -44; i < 0; i++) { p.set(wx + i, wy + 18, SHADOW); p.set(wx + i, wy + 19, SHADOW); }   // the handle runs back under them
    for (let i = 0; i < 6; i++) { p.set(wx - 46 - i, wy + 16 + (i % 3), SHADOW); p.set(wx - 46 - i, wy + 18 + (i % 2), SHADOW); p.set(wx - 46 - i, wy + 20 + (i % 3), SHADOW); }   // the straw
    // the wood: three rows of round tree crowns, the back row darkest, running down either side to the clearing
    const crown = (x0, y0, r, fill) => {
      for (let j = -r; j <= r; j++) for (let i = -r; i <= r; i++) {
        const d = i * i + j * j; if (d > r * r) continue;
        const rim = d > (r - 1) * (r - 1);
        const lit = !rim && i + j < -r * 0.5 && d < (r - 1) * (r - 1) * 0.7 && hash2(x0 + i, y0 + j) < 0.6;
        p.set(x0 + i, y0 + j, rim ? SHADOW : lit ? (fill === SHADOW ? MID : FACE) : fill);
      }
    };
    for (const [row, fill, base, r] of [[0, SHADOW, 84, 7], [1, MID, 98, 8], [2, MID, 116, 9]]) {
      for (let x = -6; x < W + 10; x += r + 3 + Math.floor(hash2(row, x) * 4)) {
        const edge = Math.min(x, W - 1 - x), dip = Math.max(0, 46 - edge) * (row === 0 ? 0.3 : 0.9);
        if (row > 0 && x > 50 && x < 110) continue;                              // the clearing
        crown(x, base + Math.round(dip * 0.2) - Math.floor(hash2(x, row + 9) * 5), r, fill);
      }
    }
    for (let y = 104; y < H; y++) for (let x = 0; x < W; x++) if (p.get(x, y) === MID && hash2(x, y) < 0.02) p.set(x, y, SHADOW);
    // the clearing and the cottage in the middle foreground.
    // ⛔ TITLE ROUND 3: the game draws a FREE EDITION band (y 118-128) and a press band (y 131-142) over the bottom of
    // this picture (PILOTAGE review defect 10: a band cut a hull and hid two buoys). The cottage sits 8 px higher, so both
    // bands fall on the clearing's grass and the stepping stones, never on the door or the windows.
    // ⛔ REVIEW 2026-09-28 (defect 10): at oy -8 the walls ran y 113-124, the windows 115-119 and the door 115-124, and the
    // FREE band (y 118-128) still cut the bottom of both windows and six rows of the door — the comment above was false by
    // six rows. The cottage sits 18 px higher: walls 103-114, all clear of y 118.
    const oy = -18;
    for (let y = 86; y < H; y++) for (let x = 36; x < 124; x++) { const e = ((x - 80) / 44) ** 2 + ((y - 138) / 50) ** 2; if (e <= 1) p.set(x, y, floorPixel(x, y)); }
    // cottage: a thatched roof (shade 2 with dark courses), a lit gable wall, two lit windows, a door, a chimney with smoke
    const cx = 80, cyb = 132 + oy;
    for (let y = 108 + oy; y <= 120 + oy; y++) { const half = (y - 106 - oy) * 1.9; for (let x = Math.round(cx - half); x <= Math.round(cx + half); x++) { const edge = x === Math.round(cx - half) || x === Math.round(cx + half) || y === 120 + oy; p.set(x, y, edge ? SHADOW : ((y - 108 - oy) % 3 === 2 ? SHADOW : MID)); } }
    p.rect(cx - 20, 121 + oy, 41, cyb - 121 - oy + 1, LIT); p.vline(cx - 20, 121 + oy, cyb, SHADOW); p.vline(cx + 20, 121 + oy, cyb, SHADOW); p.hline(cx - 20, cx + 20, cyb, SHADOW);
    for (const wxx of [cx - 15, cx + 8]) { const wy2 = 123 + oy; p.rect(wxx, wy2, 7, 5, SHADOW); p.rect(wxx + 1, wy2 + 1, 5, 3, FACE); p.vline(wxx + 3, wy2 + 1, wy2 + 3, SHADOW); p.hline(wxx + 1, wxx + 5, wy2 + 2, SHADOW); }
    p.rect(cx - 3, 123 + oy, 7, 10, SHADOW); p.set(cx + 2, 128 + oy, LIT);
    p.rect(cx + 10, 104 + oy, 5, 9, SHADOW); p.rect(cx + 9, 103 + oy, 7, 2, SHADOW);
    for (let k = 0; k < 12; k++) { const sx = cx + 12 + Math.round(Math.sin(k * 0.7) * 3) - Math.floor(k / 3), sy = 101 + oy - k * 2; p.set(sx, sy, FACE); p.set(sx + 1, sy, FACE); if (k % 2) p.set(sx - 1, sy + 1, FACE); }
    // a path of stepping stones from the door toward the viewer
    for (const [sx, sy] of [[78, 117], [82, 121], [77, 126], [81, 131]]) { p.rect(sx, sy, 5, 2, LIT); p.hline(sx, sx + 4, sy + 2, MID); }
    // two kittens waiting in the clearing (field sprites), lit by the windows, beside the cottage and above both bands
    if (K) { const L = K.litter(7, 2); K.drawKitten(p, 48, 104, L[0], 'wait'); K.drawKitten(p, 105, 106, L[1], 'wait'); }
    if (font) {
      p.rect(0, 2, W, 20, SHADOW); p.hline(0, W - 1, 1, MID); p.hline(0, W - 1, 22, MID);
      font.textPlane(p, 'STRAYWOOD', W / 2, 6, { align: 'center', face: 'display', shade: LIT });
    }
    return p;
  }

  return { LIT, FACE, MID, SHADOW, NONE, W, H, FIELD_Y, CELL, GW, GH, FLOOR, GARDEN, THICKET, Plane, hash2, cellX, cellY, centre, line, floorPixel, woodPlane, canopyPixel, drawWitch, drawLine, kitGlyph, skyBand, titlePlane };
}));
