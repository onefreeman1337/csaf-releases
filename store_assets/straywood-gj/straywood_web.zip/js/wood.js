/**
 * wood.js — STRAYWOOD. The wood generator, the proved-least flying, the log a player's plan is charged, and the clue.
 *
 * ⛔ THE GENERATOR IS THE CANDIDATE SCREEN'S, VERBATIM (Projects/Ferryman/Internal_Ops/screen_run3.js = screen.js run 2,
 *    grouped lakes, Q = 3): same RNG, same draws in the same order, same refusals, so every number in the screen
 *    (P2 9.0% · P3 8.3% · P4 94.0% over seeds 0..199, PREREG_2026-09-28_run3.md) describes these woods.
 *    Internal_Ops/verify_wood.js REQUIRES all 200 screened rows to reproduce exactly (k, optimum, and every arm's cost),
 *    with a shifted-seed red arm. The ONLY additions draw no random number: `kind[]` (garden / thicket, for the
 *    picture), `reach[]` (the floor the witch can fly over) and the flight routes.
 * ⛔ A re-skin changes no arithmetic: the screen's "lake" is the wood floor, its "land" the thickets (and the garden
 *    along the bottom), its "jetty" the cottage gate, its "passengers" the lost kittens, its boat of three the broom.
 *
 * A wood: 20x15 cells. The bottom row is the cottage garden; 3-6 thickets. 10-12 kittens wait on floor cells that
 * touch a thicket, in 3-5 little groups. The broom carries three. A flight is charged the SHORTEST way over the floor
 * (4-way, round every thicket) between one stop and the next (the gate, a kitten, the gate...), so the witch's own
 * steering is free and the puzzle is WHO RIDES TOGETHER and in what order. The least flying any plan could give
 * (exact: every trip of <= 3 kittens routed by its best order, then a set-partition DP over trips) is the par.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.WOOD = api;
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const W = 20, H = 15, N = W * H, Q = 3;
  const FLOOR = 0, GARDEN = 1, THICKET = 2;

  // ---- verbatim from the screen (screen_run3.js lines 8-38; GROUPED = true) ---------------------------------------
  function rng(seed) { let a = (seed + 0x9e3779b9) >>> 0; return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  const nbrs = (u) => { const x = u % W, y = (u / W) | 0; return [x > 0 ? u - 1 : -1, x < W - 1 ? u + 1 : -1, y > 0 ? u - W : -1, y < H - 1 ? u + W : -1].filter((v) => v >= 0); };
  const bfs = (land, s) => { const d = new Int16Array(N).fill(-1); d[s] = 0; const q = [s]; for (let i = 0; i < q.length; i++) { const u = q[i]; for (const v of nbrs(u)) if (!land[v] && d[v] < 0) { d[v] = d[u] + 1; q.push(v); } } return d; };

  function generate(seed) {
    const r = rng(seed * 2654435761 % 4294967291 + 23), ri = (lo, hi) => lo + Math.floor(r() * (hi - lo + 1));
    for (let attempt = 0; attempt < 200; attempt++) {
      const land = new Uint8Array(N);
      for (let x = 0; x < W; x++) land[(H - 1) * W + x] = 1;
      for (let b = ri(3, 6); b-- > 0;) { const cx = ri(1, W - 2), cy = ri(1, H - 4), rw = ri(1, 3), rh = ri(1, 2);
        for (let y = cy - rh; y <= cy + rh; y++) for (let x = cx - rw; x <= cx + rw; x++) if (x >= 0 && y >= 0 && x < W && y < H - 1 && r() < 0.85) land[y * W + x] = 1; }
      const jx = ri(6, W - 7), jetty = (H - 2) * W + jx; if (land[jetty]) continue;
      const dj = bfs(land, jetty);
      const spots = []; for (let c = 0; c < N; c++) if (!land[c] && dj[c] > 2 && nbrs(c).some((v) => land[v])) spots.push(c);
      const k = ri(10, 12); if (spots.length < k + 4) continue;
      const pick = []; const used = new Set(); let guard = 0;
      const nc = ri(3, 5), centres = []; for (let c = 0; c < nc; c++) centres.push(spots[ri(0, spots.length - 1)]);
      while (pick.length < k && guard++ < 8000) { const ce = centres[ri(0, nc - 1)], cx = ce % W, cy = (ce / W) | 0;
        const near = spots.filter((c) => !used.has(c) && Math.abs(c % W - cx) + Math.abs(((c / W) | 0) - cy) <= 2);
        const inCluster = pick.filter((p) => Math.abs(p % W - cx) + Math.abs(((p / W) | 0) - cy) <= 2).length;
        if (!near.length || inCluster >= 4) continue; const c = near[ri(0, near.length - 1)]; used.add(c); pick.push(c); }
      if (pick.length < k) continue;
      const nodes = [jetty].concat(pick), f = nodes.map((c) => bfs(land, c));
      if (nodes.some((a, i) => nodes.some((b) => f[i][b] < 0))) continue;
      const D = nodes.map((a, i) => nodes.map((b) => f[i][b]));
      // ---- additions: no random draw below this line ----------------------------------------------------------
      const kind = new Uint8Array(N); for (let c = 0; c < N; c++) kind[c] = !land[c] ? FLOOR : (((c / W) | 0) === H - 1 ? GARDEN : THICKET);
      const reach = new Uint8Array(N); for (let c = 0; c < N; c++) if (f[0][c] >= 0) reach[c] = 1;   // the floor connected to the gate
      const kitAt = new Int16Array(N).fill(-1); pick.forEach((c, i) => { kitAt[c] = i; });
      return { seed, land, jetty, gate: jetty, pts: pick, k, D, nodes, field: f, kind, reach, kitAt };
    }
    throw new Error('no wood for seed ' + seed);
  }
  // ---- verbatim from the screen (screen_run3.js lines 39-54): the trip table, the optimum, the arms ---------------
  const perms = (a) => a.length <= 1 ? [a] : a.flatMap((x, i) => perms(a.slice(0, i).concat(a.slice(i + 1))).map((p) => [x].concat(p)));
  function tripCosts(G) {
    const M = 1 << G.k, trip = new Float64Array(M).fill(Infinity); trip[0] = 0;
    for (let m = 1; m < M; m++) { const mem = []; for (let i = 0; i < G.k; i++) if (m & (1 << i)) mem.push(i); if (mem.length > Q) continue;
      let best = Infinity; for (const p of perms(mem)) { let s = 0, prev = 0; for (const j of p) { s += G.D[prev][j + 1]; prev = j + 1; } s += G.D[prev][0]; if (s < best) best = s; } trip[m] = best; }
    return trip;
  }
  function optimumTable(G, trip) { const M = 1 << G.k, best = new Float64Array(M).fill(Infinity); best[0] = 0;
    for (let m = 1; m < M; m++) { const low = m & -m, rest = m ^ low;
      for (let s = rest; ; s = (s - 1) & rest) { const t = s | low; if (trip[t] < Infinity) { const v = best[m ^ t] + trip[t]; if (v < best[m]) best[m] = v; } if (s === 0) break; } }
    return best; }
  function hand(G) { const left = new Set(G.pts.map((_, i) => i)); let cost = 0, cur = 0, load = 0;
    while (left.size) { let bj = -1, bd = Infinity; for (const j of left) { const d = G.D[cur][j + 1]; if (d < bd) { bd = d; bj = j; } }
      cost += bd; cur = bj + 1; load++; left.delete(bj); if (load === Q || !left.size) { cost += G.D[cur][0]; cur = 0; load = 0; } }
    return cost; }
  function weak(G) { return G.pts.reduce((s, _, j) => s + 2 * G.D[0][j + 1], 0); }
  // ---- end verbatim ------------------------------------------------------------------------------------------------

  /** Per-wood tables, cached: trip[mask] (best-order tour of that company), best[mask] (least flying for that set). */
  const tables = new Map();
  function tablesFor(G) {
    if (tables.has(G.seed)) return tables.get(G.seed);
    const trip = tripCosts(G), best = optimumTable(G, trip);
    const out = { trip, best, full: (1 << G.k) - 1 };
    tables.set(G.seed, out);
    return out;
  }
  /** The best ORDER for one company (a mask): the permutation achieving trip[mask]. */
  function bestOrder(G, m) {
    const mem = []; for (let i = 0; i < G.k; i++) if (m & (1 << i)) mem.push(i);
    let best = Infinity, bo = mem;
    for (const p of perms(mem)) { const c = orderCost(G, p); if (c < best) { best = c; bo = p; } }
    return bo;
  }
  /** One trip flown in a given order: gate -> kittens in order -> gate. */
  function orderCost(G, order) { let s = 0, prev = 0; for (const j of order) { s += G.D[prev][j + 1]; prev = j + 1; } return s + G.D[prev][0]; }

  /** THE PAR: the least flying, with one least plan (trips as ordered kitten lists), reconstructed from the DP. */
  const solveCache = new Map();
  function solve(G) {
    if (solveCache.has(G.seed)) return solveCache.get(G.seed);
    const T = tablesFor(G), trips = [];
    let m = T.full;
    while (m) { const low = m & -m, rest = m ^ low; let pick = -1;
      for (let s = rest; ; s = (s - 1) & rest) { const t = s | low; if (T.trip[t] < Infinity && T.best[m ^ t] + T.trip[t] === T.best[m]) { pick = t; break; } if (s === 0) break; }
      if (pick < 0) throw new Error('solve: no trip reconstructs best[' + m + '] for seed ' + G.seed);
      trips.push(bestOrder(G, pick)); m ^= pick; }
    const cost = trips.reduce((a, o) => a + orderCost(G, o), 0);
    if (cost !== T.best[T.full]) throw new Error('solve: reconstructed ' + cost + ' != best ' + T.best[T.full] + ' seed ' + G.seed);
    const out = { cost, trips };
    solveCache.set(G.seed, out);
    return out;
  }
  /** A player's plan's flying: `trips` = arrays of kitten indices in the order they climbed on (the last may be open). */
  function planCost(G, trips) { return trips.reduce((a, o) => a + orderCost(G, o), 0); }

  /** The least flying for the whole wood GIVEN kittens i and j ride together (some trip holds both). */
  function bestTogether(G, i, j) {
    const T = tablesFor(G), both = (1 << i) | (1 << j); let v = Infinity;
    for (let t = 1; t <= T.full; t++) if ((t & both) === both && T.trip[t] < Infinity) { const c = T.trip[t] + T.best[T.full ^ t]; if (c < v) v = c; }
    return v;
  }
  /** The least flying GIVEN kittens i and j ride in different trips (the trip carrying i excludes j). */
  function bestApart(G, i, j) {
    const T = tablesFor(G); let v = Infinity;
    for (let t = 1; t <= T.full; t++) if ((t & (1 << i)) && !(t & (1 << j)) && T.trip[t] < Infinity) { const c = T.trip[t] + T.best[T.full ^ t]; if (c < v) v = c; }
    return v;
  }
  /** THE CLUE after a loss. `trips` = the player's plan. Returns ONE provable statement, never the answer:
   *  - kind 'apart'   : a pair the player flew TOGETHER that EVERY least plan flies apart (bestTogether > par);
   *  - kind 'together': a pair the player flew APART that EVERY least plan flies together (bestApart > par);
   *  - kind 'order'   : the company was right but a trip's ORDER was not (its best order is shorter);
   *  - kind 'none'    : nothing above is provable (should not happen on a loss; the harness counts it).
   *  Plus `trips` = how many trips the least plan uses. Every statement is proved by the DP, so it is true of EVERY least
   *  plan, never of just one. */
  /** Every TRIP-SIZE SHAPE a least night can have, as sorted strings ("3,3,2,2"). Exact: an optimal partition minus the
   *  trip holding the lowest kitten is an optimal partition of the rest, so the shapes are built back down the DP. */
  const shapeCache = new Map();
  function leastShapes(G) {
    if (shapeCache.has(G.seed)) return shapeCache.get(G.seed);
    const T = tablesFor(G), memo = new Map();
    const shapes = (m) => {
      if (m === 0) return new Set(['']);
      if (memo.has(m)) return memo.get(m);
      const out = new Set(), low = m & -m, rest = m ^ low;
      for (let s = rest; ; s = (s - 1) & rest) { const t = s | low;
        if (T.trip[t] < Infinity && T.best[m ^ t] + T.trip[t] === T.best[m]) {
          let n = 0; for (let q = t; q; q &= q - 1) n++;
          for (const sh of shapes(m ^ t)) out.add((sh ? sh.split(',').map(Number) : []).concat([n]).sort((a, b) => b - a).join(','));
        }
        if (s === 0) break; }
      memo.set(m, out); return out;
    };
    const res = [...shapes(T.full)];
    shapeCache.set(G.seed, res);
    return res;
  }
  /** The trip sizes kitten i can have in SOME least night (a trip t holding her is in a least night iff
   *  trip[t] + best[everything else] == par). */
  function possibleSizes(G, i) {
    const T = tablesFor(G), par = T.best[T.full], out = new Set();
    for (let t = 1; t <= T.full; t++) if ((t & (1 << i)) && T.trip[t] < Infinity && T.trip[t] + T.best[T.full ^ t] === par) { let n = 0; for (let q = t; q; q &= q - 1) n++; out.add(n); }
    return out;
  }
  function clue(G, trips) {
    const par = solve(G).cost, tripOf = new Array(G.k).fill(-1);
    trips.forEach((o, t) => o.forEach((i) => { tripOf[i] = t; }));
    // ⛔ REVIEW 2026-09-28 (defect 9): the headline "THE LEAST, N TRIPS" was ceil(k/3) on 40/40 woods — decoration. It
    // is now the least night's TRIP SIZES when every least night shares them (defect 15: the lesson wood needs two
    // half-empty trips and nothing in the game could say so), else the trip count when that is shared, else nothing.
    const shapes = leastShapes(G), counts = new Set(shapes.map((s) => s.split(',').length));
    const shape = shapes.length === 1 ? shapes[0] : null, nTrips = counts.size === 1 ? [...counts][0] : null;
    let bestPair = null;
    for (let i = 0; i < G.k; i++) for (let j = i + 1; j < G.k; j++) if (tripOf[i] === tripOf[j] && bestTogether(G, i, j) > par) {
      const gap = bestTogether(G, i, j) - par; if (!bestPair || gap > bestPair.gap) bestPair = { kind: 'apart', i, j, gap };
    }
    if (!bestPair) for (let i = 0; i < G.k; i++) for (let j = i + 1; j < G.k; j++) if (tripOf[i] !== tripOf[j] && bestApart(G, i, j) > par && bestApart(G, j, i) > par) {
      const gap = Math.min(bestApart(G, i, j), bestApart(G, j, i)) - par; if (!bestPair || gap > bestPair.gap) bestPair = { kind: 'together', i, j, gap };
    }
    // 'size': a kitten whose trip SIZE in the player's night is one no least night gives her (REVIEW defect 9: 6 of 12,710
    // near-miss losses had no provable pair and no order fault, and got no clue at all)
    if (!bestPair) for (let i = 0; i < G.k; i++) {
      const s = trips[tripOf[i]].length, P = possibleSizes(G, i);
      if (!P.has(s)) { bestPair = { kind: 'size', i, j: -1, gap: 0, sizes: [...P].sort(), was: s }; break; }
    }
    if (!bestPair) for (let t = 0; t < trips.length; t++) {
      const m = trips[t].reduce((a, i) => a | (1 << i), 0), T = tablesFor(G);
      if (orderCost(G, trips[t]) > T.trip[m]) { bestPair = { kind: 'order', trip: t, i: trips[t][0], j: -1, gap: orderCost(G, trips[t]) - T.trip[m] }; break; }
    }
    return Object.assign({ kind: 'none', i: -1, j: -1, gap: 0 }, bestPair || {}, { nTrips, shape });
  }

  /** The flight route between two nodes (0 = the gate, i+1 = kitten i) or from node a to any `cell`: walked back down the
   *  node's own distance field. */
  function route(G, a, cell) {
    const d = G.field[a]; if (d[cell] < 0) return [];
    const out = [cell]; let u = cell, guard = 0;
    while (d[u] > 0 && guard++ < N) { let nx = -1; for (const v of nbrs(u)) if (d[v] === d[u] - 1) { nx = v; break; } if (nx < 0) break; u = nx; out.push(u); }
    return out.reverse();
  }
  /** The shortest way from node a to `cell` (-1 = none). */
  function flyTo(G, a, cell) { return G.field[a][cell]; }

  return { W, H, N, Q, FLOOR, GARDEN, THICKET, rng, nbrs, generate, tripCosts, optimumTable, hand, weak, tablesFor, bestOrder, orderCost, solve, planCost, bestTogether, bestApart, leastShapes, possibleSizes, clue, route, flyTo };
}));
