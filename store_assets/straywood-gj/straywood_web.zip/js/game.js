/**
 * game.js — STRAYWOOD. Carry every lost kitten home through a generated wood, three on the witch's broom at a time.
 *
 * ONE SENTENCE OF DESIGN: the broom holds three, so the night is several trips, and the nearest kitten is the wrong next
 * one — the obvious witch (fetch the nearest, go home when the broom is full) leaves a far kitten for a long trip of its
 * own. The proved-least flying for the whole wood (wood.js solve(): every company of <= 3 routed by its best order, then
 * an exact set-partition DP) is the par. The insight, which the game never prints until a pass: choose WHO RIDES
 * TOGETHER by where they wait, not by who is nearest.
 *
 * ⛔ THE PRIMARY INPUT IS A HOLD / DRAG (wing §0a-2): hold a direction and the witch flies over the wood floor one cell
 *    at a time while FLOWN updates every step; on touch or with a mouse she flies to where the finger is. Z is the one
 *    press: take the kitten she is over onto the broom. At the gate every rider hops off by herself.
 * ⛔ THE ONE NUMBER (the screen's model, which is what the par measures): each leg of a night is charged the SHORTEST
 *    way over the floor from one stop to the next (the gate, a kitten, the gate...). The witch's own steering is free, so
 *    the puzzle is WHO rides together and in what ORDER, never how neatly she flies. FLOWN = the legs so far plus the
 *    shortest way from her last stop to where she is now.
 * ⛔ §1a: the automation tab is hidden and rAF is throttled to zero there, so every harness drives the game through the
 *    synchronous `window.STRAYWOOD.step(n)` and reads `window.STRAYWOOD.frames`.
 * ⛔ §6b-64: every device the listing claims is driven with its REAL vocabulary by the harness — keyboard holds (4-way),
 *    pointer cells under a finger — never an exact vector no device produces.
 * ⛔ §0z-1c: every refusal names its reason (run.refusals), so a harness can read WHY.
 */
(function (root) {
  'use strict';

  var ART = root.ART, FONT = root.DW_FONT, C = root.CONTENT, SND = root.PSOUND, WOOD = root.WOOD, K = root.KITTENS;
  var W = ART.W, H = ART.H, LIT = ART.LIT, FACE = ART.FACE, MID = ART.MID, SHADOW = ART.SHADOW;
  var GW = ART.GW, GH = ART.GH, N = GW * GH, Q = WOOD.Q;
  var DMG = ['#9bbc0f', '#8bac0f', '#306230', '#0f380f'];
  var WALK_FRAMES = 5, DAS_FRAMES = 12, HOP_FRAMES = 48, DONE_FRAMES = 110;

  if (!C || !C.woods || !C.woods.length) throw new Error('content: no woods');

  var S = {
    screen: 'title', frames: 0, wi: 0, run: null, result: null,
    dirOrder: [], muted: false, paused: false, endPage: 0, ledgerPage: 0, toast: null,
    best: {}, pointer: null,
  };

  var ED = C.edition === 'full' ? 'full' : 'free';
  var BEST_KEY = 'STRAYWOOD_BEST_' + ED, WI_KEY = 'STRAYWOOD_WOOD_' + ED;
  try { S.best = JSON.parse(root.localStorage.getItem(BEST_KEY) || '{}') || {}; } catch (e) { S.best = {}; }
  function saveBest() { try { root.localStorage.setItem(BEST_KEY, JSON.stringify(S.best)); } catch (e) { /* private mode */ } }
  function saveWi() { try { root.localStorage.setItem(WI_KEY, String(S.wi)); } catch (e) { /* private mode */ } }
  function bestFor(id) { var b = S.best[String(id)]; return typeof b === 'number' ? b : null; }

  var cache = {};
  function wood(ix) { var sd = C.woods[ix].seed; if (!cache[sd]) cache[sd] = WOOD.generate(sd); return cache[sd]; }
  function par(ix) { return WOOD.solve(wood(ix)).cost; }
  var litCache = {};
  function litterOf(G) { if (!litCache[G.seed]) litCache[G.seed] = K.litter(G.seed, G.k); return litCache[G.seed]; }

  /* ⛔ THE MEDAL LINES ARE IN STEPS, NOT PERCENT. The wood floor is a square grid, which is bipartite, so every trip from
   * the gate back to the gate has EVEN length and every plan totals par, par+2, par+4... (select_woods.js: 0 odd excesses
   * over 8,000 random plans on the shipped 40). GOLD = par (the least flying there is), SILVER = 2 over, BRONZE = 4 over,
   * LATE HOME beyond. MEASURED on the shipped 40 (select_woods.js): the insight arm (the screen's sweep + move/swap
   * re-plan) reaches GOLD on 40/40; the obvious HAND passes BRONZE on 8/40 and on 0 of the free 10. */
  var MEDALS = [
    { name: 'GOLD', over: 0, line: 'THE LEAST THERE IS' },
    { name: 'SILVER', over: 2, line: 'TWO STEPS OVER THE LEAST' },
    { name: 'BRONZE', over: 4, line: 'EVERY KITTEN IS HOME' },
    { name: 'LATE HOME', over: Infinity, line: 'THE KITTENS CAME HOME LATE' },
  ];
  function medalFor(flown, least) { var e = flown - least; for (var i = 0; i < MEDALS.length; i++) if (e <= MEDALS[i].over) return MEDALS[i]; return MEDALS[3]; }
  /** The next wood opens on BRONZE or better; LATE HOME is the loss (retry, or look at a clue). */
  function passed(ix) { var b = bestFor(C.woods[ix].id); return b !== null && medalFor(b, par(ix)).name !== 'LATE HOME'; }
  function unlocked(ix) { return ix === 0 || passed(ix - 1) || bestFor(C.woods[ix].id) !== null; }
  function kittensHome() { var n = 0; for (var i = 0; i < C.woods.length; i++) if (passed(i)) n += wood(i).k; return n; }
  function kittensAll() { var n = 0; for (var i = 0; i < C.woods.length; i++) n += wood(i).k; return n; }
  (function restoreWi() {
    var v = 0;
    try { v = parseInt(root.localStorage.getItem(WI_KEY) || '0', 10) || 0; } catch (e) { v = 0; }
    v = Math.max(0, Math.min(C.woods.length - 1, v));
    while (v > 0 && !unlocked(v)) v--;
    S.wi = v;
  }());

  /* ------------------------------------------------------------------------ the flying */
  function beginRun() {
    var G = wood(S.wi), opt = WOOD.solve(G);
    S.run = {
      G: G, opt: opt, litter: litterOf(G), cursor: G.jetty, cooldown: 0, lastDir: null, face: 1,
      home: new Array(G.k).fill(false), riding: [], trips: [], lastStop: 0, logged: 0,
      trail: [], hopping: null, done: 0, steps: 0, bumps: 0, refusals: {}, trace: [], moving: 0,
    };
    S.screen = 'play'; S.paused = false; S.toast = null; S.pointer = null;
    if (SND) SND.cue('start');
  }
  function homeCount(r) { var n = 0; for (var i = 0; i < r.home.length; i++) if (r.home[i]) n++; return n; }
  function onBroom(r, i) { return r.riding.indexOf(i) >= 0; }
  /** THE ONE NUMBER: the legs so far plus the shortest way from the last stop to where she is now. */
  function flownHere(r) { var d = WOOD.flyTo(r.G, r.lastStop, r.cursor); return r.logged + (d > 0 ? d : 0); }

  var DIRS = { left: [-1, 0], right: [1, 0], up: [0, -1], down: [0, 1] };
  function neighbour(i, d) {
    var x = i % GW, y = (i / GW) | 0, nx = x + DIRS[d][0], ny = y + DIRS[d][1];
    if (nx < 0 || ny < 0 || nx >= GW || ny >= GH) return -1;
    return ny * GW + nx;
  }
  function toast(msg) { S.toast = { msg: msg, until: S.frames + 70 }; }

  var LAND_WORD = {}; LAND_WORD[WOOD.GARDEN] = 'THE GARDEN WALL'; LAND_WORD[WOOD.THICKET] = 'A THICKET';
  function refuse(r, why, msg) {
    r.refusals[why] = (r.refusals[why] || 0) + 1; r.bumps++;
    if (r.lastRefusal !== why || S.frames - (r.lastRefusalAt || 0) > 20) { if (SND) SND.cue('bump'); if (msg) toast(msg); }
    r.lastRefusal = why; r.lastRefusalAt = S.frames;
    return false;
  }
  function tryMove(d) {
    var r = S.run, G = r.G, t = neighbour(r.cursor, d);
    if (t < 0) return refuse(r, 'edge', null);
    if (!G.reach[t]) {
      if (G.land[t]) return refuse(r, 'land' + G.kind[t], LAND_WORD[G.kind[t]] || 'A THICKET');
      // REVIEW 2026-09-28 (defect 6): a sealed pocket of floor is DRAWN as thicket (art.js woodPlane), so it is named one
      return refuse(r, 'noway', 'A THICKET');
    }
    if (d === 'left') r.face = -1; else if (d === 'right') r.face = 1;
    if (r.trail[0] !== r.cursor) { r.trail.unshift(r.cursor); if (r.trail.length > Q) r.trail.length = Q; }
    r.cursor = t; r.cooldown = WALK_FRAMES; r.steps++; r.moving = 8;
    if (SND) SND.cue('step');
    if (t === G.jetty && r.riding.length) arriveHome();
    return true;
  }
  function heldDir() { return S.dirOrder.length ? S.dirOrder[S.dirOrder.length - 1] : null; }

  /** A flight to a touched cell: the shortest way over the floor (BFS over the reachable floor).
   *  ⛔ REVIEW 2026-09-28 (defect 8): with kittens on the broom, a finger on the NEXT kitten could be routed across the
   *  doorstep, and every rider hopped off mid-trip. With riders aboard the flight now keeps OFF the gate unless the gate
   *  is where the finger is (or no other way exists). The charge is unchanged either way: only stops are charged. */
  function steerPath(G, a, b, avoid) {
    if (a === b) return [];
    if (!G.reach[b]) return null;
    var prev = new Int16Array(N).fill(-1), seen = new Uint8Array(N), q = [a]; seen[a] = 1;
    for (var h = 0; h < q.length; h++) { var u = q[h]; if (u === b) break;
      for (var k = 0; k < 4; k++) { var d = ['left', 'right', 'up', 'down'][k], v = neighbour(u, d); if (v >= 0 && G.reach[v] && !seen[v] && (v !== avoid || v === b)) { seen[v] = 1; prev[v] = u; q.push(v); } } }
    if (!seen[b]) return avoid !== undefined ? steerPath(G, a, b) : null;
    var out = []; for (var c = b; c !== a; c = prev[c]) out.push(c); return out.reverse();
  }
  /** Where a finger lands, as the game reads it. ⛔ REVIEW 2026-09-28 (defect 12, MAJOR): the gate is DRAWN in the
   *  garden wall one row below the doorstep cell that takes the kittens home, and a finger on the drawn gate was refused
   *  as "THE GARDEN HEDGE" on every trip. A finger on the gate picture now means the doorstep. */
  function fingerCell(r, cell) { return (r && cell === r.G.jetty + GW) ? r.G.jetty : cell; }
  function flightTo(r, cell) { return steerPath(r.G, r.cursor, cell, r.riding.length ? r.G.jetty : undefined); }
  function dirTo(a, b) {
    var ax = a % GW, ay = (a / GW) | 0, bx = b % GW, by = (b / GW) | 0;
    if (ay === by && bx === ax - 1) return 'left'; if (ay === by && bx === ax + 1) return 'right';
    if (ax === bx && by === ay - 1) return 'up'; if (ax === bx && by === ay + 1) return 'down';
    return null;
  }

  function stepPlay() {
    var r = S.run;
    if (r.moving > 0) r.moving--;
    if (r.hopping) { r.hopping.t++; if (r.hopping.t >= HOP_FRAMES) landHop(); return; }
    if (r.done > 0) { r.done--; if (r.done === 0) finish(); return; }
    if (r.cooldown > 0) { r.cooldown--; return; }
    if (r.trace.length) {
      var next = r.trace[0], d0 = dirTo(r.cursor, next);
      if (!d0) { r.trace.length = 0; return; }
      if (tryMove(d0)) r.trace.shift(); else r.trace.length = 0;
      return;
    }
    var d = heldDir();
    if (!d) { r.lastDir = null; return; }
    var fresh = d !== r.lastDir, moved = tryMove(d);
    if (fresh && moved) r.cooldown = Math.max(r.cooldown, DAS_FRAMES);
    r.lastDir = d;
  }

  /** Z during play: take the kitten she is over onto the broom. */
  function act() {
    var r = S.run, G = r.G, c = r.cursor, ki = G.kitAt[c];
    if (ki >= 0 && !r.home[ki] && !onBroom(r, ki)) {
      if (r.riding.length >= Q) return refuse(r, 'full', 'THE BROOM HOLDS THREE');
      r.logged += G.D[r.lastStop][ki + 1];
      r.lastStop = ki + 1;
      r.riding.push(ki);
      if (SND) SND.cue('mew');
      return true;
    }
    if (ki >= 0 && onBroom(r, ki)) return refuse(r, 'riding', 'SHE IS ON THE BROOM');
    if (c === G.jetty) return refuse(r, 'gateempty', r.riding.length ? null : 'BRING THEM TO THE GATE');
    return refuse(r, 'nokitten', 'NO KITTEN HERE');
  }
  /** At the gate: every rider hops off into the garden. The last leg is charged; the trip is logged. */
  function arriveHome() {
    var r = S.run, G = r.G;
    r.logged += G.D[r.lastStop][0];
    r.lastStop = 0;
    r.trips.push(r.riding.slice());
    r.hopping = { kits: r.riding.slice(), t: 0, from: r.trail.slice() };
    r.riding.forEach(function (i) { r.home[i] = true; });
    r.riding = [];
    // ⛔ FOUND BY play_through full (paid wood 26, 2026-09-28): the trace used to be cleared here, so a finger flight
    // whose ONLY way to a kitten crosses the doorstep stopped dead at the gate. The riders still hop off (the geometry
    // forces it; the charge is unchanged because the gate lies on that shortest way) and, after the hop, she flies on to
    // where the finger is — as a held key already did.
    if (SND) SND.cue('home');
  }
  function landHop() {
    var r = S.run; r.hopping = null;
    if (homeCount(r) === r.G.k) { r.done = DONE_FRAMES; if (SND) SND.cue('allhome'); }
  }

  function finish() {
    var r = S.run, c = C.woods[S.wi], flown = WOOD.planCost(r.G, r.trips), prev = bestFor(c.id);
    if (flown !== r.logged) throw new Error('the log ' + r.logged + ' disagrees with the plan ' + flown);
    var isBest = prev === null || flown < prev;
    if (isBest) { S.best[String(c.id)] = flown; saveBest(); }
    var m = medalFor(flown, r.opt.cost);
    S.result = { ok: true, flown: flown, par: r.opt.cost, medal: m, late: m.name === 'LATE HOME', newBest: isBest, hadBest: prev !== null, prev: prev, trips: r.trips.length };
    if (SND) SND.cue(m.name === 'LATE HOME' ? 'late' : 'done');
    S.screen = 'result';
  }

  /* ----------------------------------------------------------------------------- drawing */
  var plane = new ART.Plane(W, H, LIT);
  var baseCache = { key: '', plane: null };
  var CARDCH = Math.floor((W - 12 - 8) / FONT.FACES.body.adv);
  function wrap(str, max) {
    var words = String(str).split(' '), lines = [], cur = '';
    for (var i = 0; i < words.length; i++) { var nx = cur ? cur + ' ' + words[i] : words[i]; if (nx.length > max && cur) { lines.push(cur); cur = words[i]; } else cur = nx; }
    if (cur) lines.push(cur); return lines;
  }
  function baseFor(G) {
    if (baseCache.key !== G.seed) { var b = ART.woodPlane(G); ART.skyBand(b, G.seed % 7); baseCache.plane = b; baseCache.key = G.seed; }
    plane.px.set(baseCache.plane.px);
  }
  function text(str, x, y, o) { o = o || {}; if (o.halo === undefined && o.shade === LIT) o.halo = SHADOW; FONT.textPlane(plane, str, x, y, o); }

  /** The witch, with four blinking corner brackets round her cell — the cell Z acts on. Dark <-> shade 2 (PILOTAGE
   *  screens round 1: a LIT phase is invisible on the lit floor). */
  function drawCursor(r) {
    var on = (S.frames >> 3) % 2 === 0, X = ART.cellX(r.cursor), Y = ART.cellY(r.cursor), s = on ? SHADOW : MID;
    [[-1, -1, 1, 1], [8, -1, -1, 1], [-1, 8, 1, -1], [8, 8, -1, -1]].forEach(function (b) { for (var k = 0; k < 3; k++) { plane.set(X + b[0] + b[2] * k, Y + b[1], s); plane.set(X + b[0], Y + b[1] + b[3] * k, s); } });
  }
  /** Everything in the wood for a run's CURRENT state: this trip's legs (dark, dotted), the live leg to the witch,
   *  kittens still waiting, the riders trailing behind her, and the witch. */
  function drawWood(r, opts) {
    opts = opts || {};
    var G = r.G;
    // this trip's legs so far: gate -> each rider in the order they climbed on
    var prev = 0;
    for (var t = 0; t < r.riding.length; t++) { var ki = r.riding[t]; ART.drawLine(plane, WOOD.route(G, prev, G.pts[ki]), MID, 0, 3); prev = ki + 1; }
    if (!opts.noCursor && !r.hopping && r.done === 0 && r.cursor !== G.nodes[r.lastStop]) ART.drawLine(plane, WOOD.route(G, r.lastStop, r.cursor), SHADOW, (S.frames >> 2) % 3, 3);
    for (var i = 0; i < G.k; i++) {
      if (r.home[i] || onBroom(r, i)) continue;
      if (opts.ring && opts.ring.indexOf(i) >= 0 && (S.frames >> 4) % 2) { K.drawKitten(plane, ART.cellX(G.pts[i]), ART.cellY(G.pts[i]), r.litter[i], 'ghost'); continue; }
      K.drawKitten(plane, ART.cellX(G.pts[i]), ART.cellY(G.pts[i]), r.litter[i], 'wait', ((S.frames + i * 37) % 180) < 6);
    }
    // riders trail behind her in the cells she just left (the most recent first)
    for (var q = 0; q < r.riding.length; q++) {
      var cell = r.trail[q] !== undefined ? r.trail[q] : r.cursor;
      K.drawKitten(plane, ART.cellX(cell), ART.cellY(cell) + ((S.frames >> 3) + q) % 2, r.litter[r.riding[q]], 'ride');
    }
    // the hop: riders run from the trail to the gate and through it
    if (r.hopping) {
      var Hp = r.hopping, f = Hp.t / HOP_FRAMES, gx = ART.cellX(G.jetty), gy = ART.cellY(G.jetty);
      Hp.kits.forEach(function (ki2, n) {
        var from = Hp.from[n] !== undefined ? Hp.from[n] : G.jetty, fx = ART.cellX(from), fy = ART.cellY(from);
        var k2 = Math.max(0, Math.min(1, f * 1.6 - n * 0.2)), x = fx + (gx - fx) * k2, y = fy + (gy + 10 - fy) * k2 - Math.sin(k2 * Math.PI) * 6;
        if (k2 < 1) K.drawKitten(plane, x, y, r.litter[ki2], 'ride');
      });
    }
    if (!opts.noWitch) ART.drawWitch(plane, ART.cellX(r.cursor), ART.cellY(r.cursor), r.face, (S.frames >> 4) & 1, r.moving > 0);
  }

  function hud(r) {
    // ⛔ THE ONE NUMBER at the top left: FLOWN (the legs so far) and, while a leg is open, "+n" = the shortest way from
    // her last stop to here. ⛔ REVIEW 2026-09-28 (defect 13): one number that fell while she flew back contradicted its
    // own name; FLOWN now only ever rises (at a stop) and the part that can fall is the "+n" beside it.
    var leg = flownHere(r) - r.logged;
    text('FLOWN ' + r.logged + (leg > 0 ? ' +' + leg : ''), 3, 3, { shade: LIT });
    text('PAR ' + r.opt.cost + ' FOR ALL', 3, 13, { shade: LIT });
    text('HOME ' + homeCount(r) + '/' + r.G.k, W - 3, 3, { align: 'right', shade: LIT });
    // the broom's three seats, on a shade-2 plaque (PILOTAGE review defect 8: lit glyphs on shade-1 cloud read nothing)
    var gx = W - 3 - Q * 9 - 2;
    plane.rect(gx, 12, W - gx - 1, 10, MID); plane.hline(gx, W - 2, 22, SHADOW);
    for (var i = 0; i < Q; i++) ART.kitGlyph(plane, W - 3 - (Q - i) * 9, 14, i >= r.riding.length);
  }

  function drawPlayScreen() {
    var r = S.run;
    baseFor(r.G);
    drawWood(r);
    if (!r.hopping && r.done === 0) drawCursor(r);
    hud(r);
    if (S.toast && S.frames < S.toast.until) {
      var w = S.toast.msg.length * 6 + 8, x = Math.round((W - w) / 2), low = ((r.cursor / GW) | 0) >= GH / 2, ty = low ? ART.FIELD_Y + 2 : 128;
      plane.rect(x, ty, w, 11, SHADOW); plane.hline(x, x + w - 1, low ? ty + 11 : ty - 1, LIT);
      text(S.toast.msg, W / 2, ty + 2, { align: 'center', shade: LIT, halo: undefined });
    }
    if (S.paused) {
      plane.rect(29, 53, 102, 40, LIT); plane.rect(30, 54, 100, 38, SHADOW);
      text('PAUSED', W / 2, 60, { align: 'center', shade: LIT });
      FONT.textPlane(plane, 'P RESUME', W / 2, 72, { align: 'center', shade: FACE });
      FONT.textPlane(plane, 'X GIVE UP', W / 2, 81, { align: 'center', shade: FACE });
    }
  }

  function cardFrame(title) {
    plane.px.fill(MID);
    for (var i = 0; i < 10; i++) plane.hline(0, W - 1, 7 + i * 15, SHADOW);
    plane.rect(6, 14, W - 12, H - 34, SHADOW);
    plane.hline(6, W - 7, 14, LIT);
    FONT.textPlane(plane, title, W / 2, 20, { align: 'center', shade: LIT });
    plane.hline(30, W - 31, 30, MID);
  }
  function card(title, lines, footer) {
    cardFrame(title);
    var flat = [];
    for (var j = 0; j < lines.length; j++) { if (!lines[j]) { flat.push(''); continue; } wrap(lines[j], CARDCH).forEach(function (l) { flat.push(l); }); }
    for (var k = 0; k < flat.length && 36 + k * 9 <= H - 22; k++) FONT.textPlane(plane, flat[k], W / 2, 36 + k * 9, { align: 'center', shade: FACE });
    if (footer) FONT.textPlane(plane, footer, W / 2, H - 12, FOOT);
  }
  var FOOT = { align: 'center', shade: LIT, halo: SHADOW };

  var titleBase = null, titleImg = null, titleState = 'none';
  // ⛔ the title art keeps its cottage above y 118 so neither band covers the door or the windows (art.js TITLE ROUND 3)
  var FREE_BAND = { x: 36, y: H - 26, w: 88, h: 11 }, PRESS_BAND = { x: 44, y: H - 13, w: 72, h: 11 };
  function loadTitle() {
    if (titleState !== 'none' || !root.Image) return;
    titleState = 'loading';
    titleImg = new root.Image();
    titleImg.onload = function () { titleState = 'ready'; };
    titleImg.onerror = function () { titleState = 'failed'; };
    titleImg.src = 'art/title.png';
  }
  function drawTitle() {
    if (!titleBase) titleBase = ART.titlePlane(FONT, K);
    plane.px.set(titleBase.px);
    if (C.edition !== 'full') { plane.rect(FREE_BAND.x, FREE_BAND.y, FREE_BAND.w, FREE_BAND.h, SHADOW); FONT.textPlane(plane, 'FREE EDITION', W / 2, FREE_BAND.y + 2, { align: 'center', shade: LIT }); }
    if (S.frames % 48 < 32) { plane.rect(PRESS_BAND.x, PRESS_BAND.y, PRESS_BAND.w, PRESS_BAND.h, SHADOW); FONT.textPlane(plane, 'Z OR TAP', W / 2, PRESS_BAND.y + 2, { align: 'center', shade: LIT }); }
  }

  /** The wood before the run: every kitten out, the witch at the gate. */
  function startState(G) { return { G: G, litter: litterOf(G), home: new Array(G.k).fill(false), riding: [], trail: [], hopping: null, done: 0, cursor: G.jetty, lastStop: 0, face: 1, moving: 0 }; }
  function drawYard() {
    var G = wood(S.wi), c = C.woods[S.wi], b = bestFor(c.id);
    baseFor(G);
    var st = startState(G); drawWood(st, { noCursor: true });
    text(c.name, 3, 3, { shade: LIT });
    text('Z START', W - 3, 3, { align: 'right', shade: LIT });
    text((S.wi + 1) + '/' + C.woods.length, 3, 13, { shade: LIT });
    // ⛔ REVIEW 2026-09-28 (defect 18): in a short embed the page hint is hidden and nothing on the canvas said the cat
    // book, the rules or the other woods exist. ⛔ RE-CHECK defect 19: a footer drawn on the garden wall hid the gate and
    // re-merged the wall-row kittens on the planning screen. The hint lives in the HUD instead: the right of line 2
    // cycles the litter (or medal), UP CAT BOOK, DOWN RULES and LEFT RIGHT WOODS, about a second each.
    var hints = [b === null ? G.k + ' KITTENS' : medalFor(b, par(S.wi)).name, 'UP CAT BOOK', 'DOWN RULES', 'LEFT RIGHT WOODS'];
    text(hints[((S.frames / 72) | 0) % hints.length], W - 3, 13, { align: 'right', shade: LIT });
    if (S.toast && S.frames < S.toast.until) {
      var w = S.toast.msg.length * 6 + 8, x = Math.round((W - w) / 2);
      plane.rect(x, 128, w, 11, SHADOW); plane.hline(x, x + w - 1, 127, LIT);
      text(S.toast.msg, W / 2, 130, { align: 'center', shade: LIT, halo: undefined });
    }
  }

  function drawResult() {
    var R = S.result, c = C.woods[S.wi];
    cardFrame(R.medal.name);
    var G = S.run.G, ox = 9, oy = 36;
    plane.rect(ox - 2, oy - 2, 64, 49, LIT);
    thumb(G, ox, oy, 3, S.run.trips);
    var tx = 113;
    FONT.textPlane(plane, c.name.length > 12 ? c.name.split(' ')[0] : c.name, tx, 34, { align: 'center', shade: LIT });
    FONT.textPlane(plane, 'YOUR FLYING', tx, 48, { align: 'center', shade: FACE });
    FONT.textPlane(plane, String(R.flown), tx, 57, { align: 'center', shade: LIT });
    FONT.textPlane(plane, 'THE LEAST', tx, 70, { align: 'center', shade: FACE });
    FONT.textPlane(plane, String(R.par), tx, 79, { align: 'center', shade: LIT });
    // ⛔ REVIEW 2026-09-28 (defect 1): a LATE run that was itself a new best printed the OLD best. The note now follows the
    // record: a new best says so, medal or not.
    var note = R.newBest ? (R.hadBest ? 'A NEW BEST' : (R.late ? 'NO MEDAL YET' : 'FIRST PASS')) : 'YOUR BEST ' + R.prev;
    FONT.textPlane(plane, note, tx, 92, { align: 'center', shade: FACE });
    // ⛔ REVIEW 2026-09-28 (defect 2): "BRONZE OPENS THE NEXT WOOD" was printed on a wood whose medal already stands.
    var held = R.late && passed(S.wi), last = S.wi >= C.woods.length - 1;
    var line = !R.late ? R.medal.line : held ? 'LATE HOME. YOUR MEDAL HERE STANDS.' : last ? 'LATE HOME. BRONZE ENDS THE NIGHT.' : 'LATE HOME. BRONZE OPENS THE NEXT WOOD.';
    wrap(line, 24).slice(0, 2).forEach(function (l, i) { FONT.textPlane(plane, l, W / 2, 106 + i * 8, { align: 'center', shade: FACE }); });
    FONT.textPlane(plane, R.late ? 'Z RETRY  X A CLUE' : 'Z NEXT  X THE LEAST', W / 2, H - 12, FOOT);
  }
  /** A wood thumbnail at `sc` px per cell: floor lit, thickets shade 2 and — if `trips` is given — every trip as a dark
   *  loop from the gate through its kittens, each kitten a dark block and the gate a ring. */
  function thumb(G, ox, oy, sc, trips) {
    for (var c = 0; c < N; c++) plane.rect(ox + (c % GW) * sc, oy + ((c / GW) | 0) * sc, sc, sc, G.land[c] ? MID : LIT);
    var mid = function (cell) { return { x: ox + (cell % GW) * sc + (sc >> 1), y: oy + ((cell / GW) | 0) * sc + (sc >> 1) }; };
    var seg = function (a, cell) { var rt = WOOD.route(G, a, cell); for (var k = 1; k < rt.length; k++) { var p = mid(rt[k - 1]), q = mid(rt[k]); ART.line(plane, p.x, p.y, q.x, q.y, SHADOW); } };
    if (trips) trips.forEach(function (o) { var prev = 0; o.forEach(function (i) { seg(prev, G.pts[i]); prev = i + 1; }); seg(prev, G.jetty); });
    G.pts.forEach(function (cell) { var m = mid(cell); if (sc >= 3) plane.rect(m.x - 1, m.y - 1, 3, 3, SHADOW); else plane.set(m.x, m.y, SHADOW); });
    var g = mid(G.jetty); if (sc >= 3) { plane.rect(g.x - 1, g.y - 1, 3, 3, SHADOW); plane.set(g.x, g.y, LIT); } else plane.set(g.x, g.y, FACE);
  }

  /** HOME TONIGHT — after a pass, the portraits of every kitten brought home, with their names (the cat book's page). */
  function drawHomeCard() {
    var G = S.run.G, L = litterOf(G), c = C.woods[S.wi];
    plane.px.fill(MID);
    plane.rect(0, 0, W, 12, SHADOW);
    FONT.textPlane(plane, 'HOME TONIGHT', 3, 3, { shade: LIT });
    FONT.textPlane(plane, c.name.length > 12 ? c.name.split(' ')[0] : c.name, W - 3, 3, { align: 'right', shade: FACE });
    // ⛔ SCREENS ROUND 1 (LOOKED AT 13_home_tonight at 3x): the name sat directly on the portrait's shoulders and their
    // dark outline ran into its letters. The name has its own lit strip under the portrait now, 1 px clear of it.
    var cols = 4, sw = 38, sh = 34, x0 = Math.round((W - cols * sw) / 2) + 1;
    for (var i = 0; i < G.k; i++) {
      var x = x0 + (i % cols) * sw, y = 14 + Math.floor(i / cols) * sh;
      plane.rect(x, y, sw - 2, sh - 2, FACE);
      K.drawPortrait(plane, x + 6, y, L[i], FACE);
      plane.rect(x, y + 24, sw - 2, 8, LIT);
      FONT.textPlane(plane, L[i].name, x + (sw - 2) / 2, y + 25, { align: 'center', shade: SHADOW });
    }
    FONT.textPlane(plane, 'Z NEXT WOOD', W / 2, H - 9, FOOT);
  }

  /** THE LESSON after a PASS, or ONE CLUE after a LOSS. After a pass: the proved-least trips as SOLID dark loops, your
   *  own differing legs as sparse shade-2 dots. ⛔ MILLWRIGHT review defect 10, carried: after a loss the answer would
   *  be copied (lose, look, retry = GOLD), so a loss shows a CLUE instead — ONE provable statement (wood.js clue():
   *  a pair EVERY least plan flies apart, or together, or a trip whose order is not the shortest), never the plan. */
  function revealIsClue() { return !!(S.result && S.result.late); }
  function clueFor(r) { var key = JSON.stringify(r.trips); if (!r.clue || r.clueKey !== key) { r.clue = WOOD.clue(r.G, r.trips); r.clueKey = key; } return r.clue; }
  var CLUE_LINE = { apart: 'RINGED: NEVER TOGETHER', together: 'RINGED: ALWAYS TOGETHER', order: 'RINGED: A SHORTER ORDER', none: 'NO SINGLE CLUE' };
  function clueLine(cl) {
    if (cl.kind !== 'size') return CLUE_LINE[cl.kind];
    return cl.sizes.length === 1 ? 'RINGED: IN A TRIP OF ' + cl.sizes[0] : 'RINGED: NOT IN A TRIP OF ' + cl.was;
  }
  function clueHead(cl) { return cl.shape ? 'A CLUE: TRIPS OF ' + cl.shape : cl.nTrips ? 'A CLUE: THE LEAST, ' + cl.nTrips + ' TRIPS' : 'A CLUE'; }
  function drawReveal() {
    var r = S.run, G = r.G, clue = revealIsClue(), foot = (S.frames % 192) < 96;
    baseFor(G);
    var st = startState(G);
    if (clue) {
      var cl = clueFor(r), ring = [];
      if (cl.kind === 'order') ring = r.trips[cl.trip].slice(); else if (cl.i >= 0) ring = [cl.i, cl.j].filter(function (v) { return v >= 0; });   // 'size' rings one
      drawWood(st, { noCursor: true, noWitch: true, ring: ring });
      ring.forEach(function (i) {
        var bx = ART.cellX(G.pts[i]), by = ART.cellY(G.pts[i]), sh = (S.frames >> 3) % 2 ? MID : SHADOW;
        // ⛔ SCREENS ROUND 1 (LOOKED AT 18_clue_after_loss at 3x): a ringed kitten in the TOP row had its bracket drawn
        // at y 22-23, on the treeline's dark band, so a two-kitten clue showed one ring. Every corner is clamped INSIDE
        // the field now (it may overlap the kitten's own ear pixels, which is legible; the dark band is not).
        var X0 = Math.max(0, bx - 2), X1 = Math.min(W - 1, bx + 9), Y0 = Math.max(ART.FIELD_Y, by - 2), Y1 = Math.min(H - 1, by + 9);
        [[X0, Y0, 1, 1], [X1, Y0, -1, 1], [X0, Y1, 1, -1], [X1, Y1, -1, -1]].forEach(function (b) { for (var q = 0; q < 4; q++) { plane.set(b[0] + b[2] * q, b[1], sh); plane.set(b[0], b[1] + b[3] * q, sh); } });
      });
      text(clueHead(cl), 3, 3, { shade: LIT });
      text(foot ? clueLine(cl) : 'Z BACK  X WOODS', 3, 13, { shade: LIT });
      return;
    }
    // your legs that the least plan does not fly (sparse, shade 2), then the least trips SOLID dark, kittens as ghosts
    r.trips.forEach(function (o) { var prev = 0; o.forEach(function (i) { ART.drawLine(plane, WOOD.route(G, prev, G.pts[i]), MID, 1, 2); prev = i + 1; }); ART.drawLine(plane, WOOD.route(G, prev, G.jetty), MID, 1, 2); });
    r.opt.trips.forEach(function (o) { var prev = 0; o.forEach(function (i) { ART.drawLine(plane, WOOD.route(G, prev, G.pts[i]), SHADOW, 0, 99); prev = i + 1; }); ART.drawLine(plane, WOOD.route(G, prev, G.jetty), SHADOW, 0, 99); });
    for (var i5 = 0; i5 < G.k; i5++) K.drawKitten(plane, ART.cellX(G.pts[i5]), ART.cellY(G.pts[i5]), st.litter[i5], 'wait');
    ART.drawWitch(plane, ART.cellX(G.jetty), ART.cellY(G.jetty), 1, 0, false);
    // RE-CHECK (defect 8 residue): on a wood where the only way between two kittens of one least trip crosses the
    // doorstep, the riders hop off there, so "IN 4" could not be flown in 4 trips. The header names the cost only.
    text('LEAST ' + r.opt.cost, 3, 3, { shade: LIT });
    text('YOURS ' + WOOD.planCost(G, r.trips), W - 3, 3, { align: 'right', shade: LIT });
    text(foot ? 'SOLID: THE LEAST' : 'Z BACK  X WOODS', 3, 13, { shade: LIT });
  }

  /** THE CAT BOOK: every wood in miniature, ten to a page, with its medal, and the count of kittens home. */
  function drawLedger() {
    plane.px.fill(MID);
    plane.rect(0, 0, W, 12, SHADOW);
    var pages = Math.ceil(C.woods.length / 10), pg = Math.max(0, Math.min(S.ledgerPage, pages - 1));
    FONT.textPlane(plane, 'CAT BOOK ' + kittensHome() + '/' + kittensAll(), 3, 3, { shade: LIT });
    FONT.textPlane(plane, (pg + 1) + '/' + pages, W - 3, 3, { align: 'right', shade: LIT });
    for (var i = 0; i < 10; i++) {
      var ix = pg * 10 + i; if (ix >= C.woods.length) break;
      var c = C.woods[ix], cx = 3 + (i % 5) * 31, cy = 16 + Math.floor(i / 5) * 58;
      plane.rect(cx, cy, 29, 54, SHADOW);
      var b = bestFor(c.id);
      if (b !== null || unlocked(ix)) thumb(wood(ix), cx + 4, cy + 4, 1, null);
      // ⛔ STORE-SHOT ROUND 1 (LOOKED AT shot_8 at 4x): a "CAT BOOK" of wood thumbnails and letters had no cat in it.
      // A wood whose litter is home (bronze or better) shows three of its kittens on a lit strip under its thumbnail.
      if (passed(ix)) { plane.rect(cx + 1, cy + 21, 27, 10, LIT); var Lx = litterOf(wood(ix)); for (var q = 0; q < 3; q++) K.drawKitten(plane, cx + 1 + q * 9, cy + 22, Lx[q], 'wait'); }
      if (b !== null) { var med = medalFor(b, par(ix)).name; FONT.textPlane(plane, med === 'LATE HOME' ? '-' : med.charAt(0), cx + 14, cy + 34, { align: 'center', shade: LIT }); }
      else FONT.textPlane(plane, '?', cx + 14, cy + 28, { align: 'center', shade: MID });
      FONT.textPlane(plane, String(ix + 1), cx + 14, cy + 44, { align: 'center', shade: b !== null ? FACE : MID });
    }
    FONT.textPlane(plane, pages > 1 ? 'LEFT RIGHT: PAGE  X BACK' : 'X BACK', W / 2, H - 9, FOOT);
  }

  var LINES_PER_PAGE = 9;
  function endingPages() {
    var raw = C.ending || [].concat(C.demoEnd || ''), paras = [];
    for (var i = 0; i < raw.length; i++) if (raw[i]) paras.push(wrap(raw[i], CARDCH));
    var pages = [], cur = [];
    paras.forEach(function (p) {
      if (cur.length && (LINES_PER_PAGE - cur.length < 3 || (cur.length + 1 + p.length > LINES_PER_PAGE && p.length <= LINES_PER_PAGE))) { pages.push(cur); cur = []; }
      if (cur.length) cur.push('');
      for (var k = 0; k < p.length; k++) { if (cur.length >= LINES_PER_PAGE) { pages.push(cur); cur = []; } cur.push(p[k]); }
    });
    if (cur.length) pages.push(cur);
    return pages.length ? pages : [['']];
  }
  function drawEnding() {
    var pages = endingPages(), page = Math.max(0, Math.min(S.endPage, pages.length - 1));
    cardFrame(C.ending ? C.endingTitle : 'END OF THE FREE EDITION');
    for (var k = 0; k < pages[page].length; k++) FONT.textPlane(plane, pages[page][k], W / 2, 38 + k * 9, { align: 'center', shade: FACE });
    var more = page < pages.length - 1;
    FONT.textPlane(plane, more ? 'Z MORE ' + (page + 1) + '/' + pages.length : 'Z CREDITS', W / 2, H - 12, FOOT);
  }
  // nine lines, each rule one line, grouped: the hands, the broom, the numbers
  var RULES = ['HOLD A WAY TO FLY.', 'Z: TAKE THE KITTEN.', 'THE BROOM HOLDS THREE.', 'THE GATE: ALL HOP OFF.', '',
    'FLOWN: SHORTEST WAYS', 'BETWEEN YOUR STOPS.', '+N: THIS LEG SO FAR.', 'PAR +4 OR LESS PASSES.'];
  var RULES_KEY = 'STRAYWOOD_RULES_SEEN', rulesSeen = false;
  try { rulesSeen = root.localStorage.getItem(RULES_KEY) === '1'; } catch (e) { rulesSeen = false; }
  function markRulesSeen() { rulesSeen = true; try { root.localStorage.setItem(RULES_KEY, '1'); } catch (e) { /* private mode */ } }
  function drawRules() { card('THE WOOD', RULES, S.rulesThenRun ? 'Z START  X BACK' : 'Z OR X BACK'); }
  function drawCredits() {
    card('STRAYWOOD', ['CORE SYSTEMS', 'ASSET FACTORY', '', 'CODE, ART AND TEXT MADE', 'WITH AI ASSISTANCE.', 'MUSIC AND SOUND ARE', 'SYNTHESISED FROM NOTES.'], 'X BACK');
  }
  // REVIEW 2026-09-28 (defects 7, 15): the card said the kittens wait "BY THE THICKETS" (some wait by the wall), and
  // nothing in the game said a half-empty broom can be the shortest night.
  function drawGaveUp() { card('LEFT IN THE WOOD', ['THE KITTENS WAIT IN THE WOOD.', '', 'THE NEAREST KITTEN IS NOT ALWAYS THE NEXT ONE, AND A FULL BROOM IS NOT ALWAYS THE SHORTEST.'], 'Z RETRY  X WOODS'); }

  /* ------------------------------------------------------------------------------ paint */
  var cv, ctx, img, data;
  var PAL = DMG.map(function (h) { return [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)]; });
  function paint() {
    for (var i = 0, p = 0; i < plane.px.length; i++, p += 4) { var c = PAL[plane.px[i]] || PAL[0]; data[p] = c[0]; data[p + 1] = c[1]; data[p + 2] = c[2]; data[p + 3] = 255; }
    ctx.putImageData(img, 0, 0);
    if (S.screen === 'title' && titleState === 'ready') {
      ctx.drawImage(titleImg, 0, 0, W, H);
      if (C.edition !== 'full') ctx.putImageData(img, 0, 0, FREE_BAND.x, FREE_BAND.y, FREE_BAND.w, FREE_BAND.h);
      ctx.putImageData(img, 0, 0, PRESS_BAND.x, PRESS_BAND.y, PRESS_BAND.w, PRESS_BAND.h);
    }
  }

  /* ------------------------------------------------------------------------------ input */
  function press(k) {
    if (SND) SND.unlock();
    if (k === 'mute') { S.muted = !S.muted; if (SND) SND.setMuted(S.muted); return; }
    if (S.screen === 'title') { if (k === 'ok') { S.screen = 'yard'; if (SND) SND.cue('ok'); } else if (k === 'back') S.screen = 'credits'; return; }
    if (S.screen === 'yard') {
      if (k === 'left' && S.wi > 0) { S.wi--; saveWi(); if (SND) SND.cue('page'); }
      else if (k === 'right' && S.wi < C.woods.length - 1 && unlocked(S.wi + 1)) { S.wi++; saveWi(); if (SND) SND.cue('page'); }
      else if (k === 'right' && S.wi < C.woods.length - 1) { if (SND) SND.cue('bump'); toast('BRONZE OPENS THE NEXT'); }
      else if (k === 'up') { S.screen = 'ledger'; S.ledgerPage = Math.floor(S.wi / 10); if (SND) SND.cue('ok'); }
      else if (k === 'down') { S.screen = 'rules'; S.rulesThenRun = false; if (SND) SND.cue('ok'); }
      else if (k === 'ok' && !rulesSeen) { S.screen = 'rules'; S.rulesThenRun = true; if (SND) SND.cue('ok'); }
      else if (k === 'ok') beginRun();
      else if (k === 'back') S.screen = 'title';
      return;
    }
    if (S.screen === 'rules') {
      if (k === 'ok' && S.rulesThenRun) { markRulesSeen(); beginRun(); }
      else if (k === 'ok' || k === 'back') { markRulesSeen(); S.screen = 'yard'; if (SND) SND.cue('ok'); }
      return;
    }
    if (S.screen === 'ledger') {
      var pages = Math.ceil(C.woods.length / 10);
      if (k === 'left' && S.ledgerPage > 0) { S.ledgerPage--; if (SND) SND.cue('page'); }
      else if (k === 'right' && S.ledgerPage < pages - 1) { S.ledgerPage++; if (SND) SND.cue('page'); }
      else if (k === 'back' || k === 'ok' || k === 'down') { S.screen = 'yard'; if (SND) SND.cue('ok'); }
      return;
    }
    if (S.screen === 'play') {
      var r = S.run;
      if (r.hopping || r.done > 0) return;
      if (k === 'pause' || (k === 'back' && !S.paused)) { S.paused = !S.paused; if (SND) SND.cue('ok'); }
      else if (k === 'back' && S.paused) { S.paused = false; S.result = { ok: false, gaveUp: true, home: homeCount(r) }; S.screen = 'gaveup'; }
      else if (k === 'ok' && S.paused) { S.paused = false; }
      else if (k === 'ok') act();
      return;
    }
    if (S.screen === 'gaveup') { if (k === 'ok') beginRun(); else if (k === 'back') { S.screen = 'yard'; if (SND) SND.cue('ok'); } return; }
    if (S.screen === 'result') {
      if (k === 'back') { S.screen = 'reveal'; if (SND) SND.cue('ok'); return; }
      if (k === 'ok') {
        if (S.result.late) { beginRun(); return; }
        S.screen = 'homecard'; if (SND) SND.cue('ok');
      }
      return;
    }
    if (S.screen === 'homecard') {
      if (k === 'ok' || k === 'back') {
        if (S.wi >= C.woods.length - 1) { S.screen = 'ending'; S.endPage = 0; }
        else { S.wi++; saveWi(); S.screen = 'yard'; }
        if (SND) SND.cue('ok');
      }
      return;
    }
    if (S.screen === 'reveal') { if (k === 'ok') { S.screen = 'result'; if (SND) SND.cue('ok'); } else if (k === 'back') { S.screen = 'yard'; if (SND) SND.cue('ok'); } return; }
    if (S.screen === 'ending') {
      if (k === 'ok') { if (S.endPage < endingPages().length - 1) { S.endPage++; if (SND) SND.cue('page'); } else S.screen = 'credits'; }
      return;
    }
    if (S.screen === 'credits') { if (k === 'back' || k === 'ok') S.screen = 'title'; }
  }

  var HELD = {};
  function holdKey(k, down) {
    HELD[k] = down;
    S.dirOrder = S.dirOrder.filter(function (d) { return d !== k; });
    if (down) S.dirOrder.push(k);
  }
  var KEYMAP = {
    ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down',
    a: 'left', d: 'right', w: 'up', s: 'down', A: 'left', D: 'right', W: 'up', S: 'down',
    z: 'ok', Z: 'ok', Enter: 'ok', ' ': 'ok', x: 'back', X: 'back', Escape: 'back', Backspace: 'back',
    p: 'pause', P: 'pause', m: 'mute', M: 'mute',
  };

  function cellAt(px, py) {
    if (py < ART.FIELD_Y) return -1;
    var x = Math.floor(px / ART.CELL), y = Math.floor((py - ART.FIELD_Y) / ART.CELL);
    if (x < 0 || y < 0 || x >= GW || y >= GH) return -1;
    return y * GW + x;
  }
  /** The pointer vocabulary, shared by the page's real events and the harness (§6b-64: the harness sends the same CELLS a
   *  finger lands on). A finger on the floor sets where the witch flies; she goes there cell by cell at her own pace,
   *  round every thicket, and FLOWN updates every step. A tap ON her is Z, and stops her where she is. */
  function pointerDown(cell) {
    S.pointer = { down: true, cell: cell, t0: S.frames, moved: false, onCursor: false };
    var r = S.run;
    // ⛔ FOUND BY play_through full (paid wood 26): a finger placed while the riders were hopping through the gate was
    // DROPPED, so she sat at the gate with the finger held beyond it. A flight set during the hop now waits for it
    // (stepPlay does not advance a trace while hopping) and then flies on.
    if (S.screen !== 'play' || !r || S.paused || r.done > 0 || cell < 0) return;
    cell = fingerCell(r, cell); S.pointer.cell = cell;
    if (cell === r.cursor) { S.pointer.onCursor = true; r.trace.length = 0; return; }
    var path = flightTo(r, cell);
    if (path) r.trace = path;
    else if (r.G.land[cell]) refuse(r, 'land' + r.G.kind[cell], LAND_WORD[r.G.kind[cell]] || 'A THICKET');
    else refuse(r, 'noway', 'A THICKET');   // a sealed pocket, drawn as thicket (REVIEW defect 6)
  }
  function pointerMove(cell) {
    var P = S.pointer, r = S.run;
    cell = fingerCell(r, cell);
    if (!P || !P.down || cell === P.cell) return;
    P.moved = true; P.cell = cell;
    if (cell < 0 || S.screen !== 'play' || !r || S.paused || r.done > 0) return;
    var path = flightTo(r, cell);
    if (path) r.trace = path;
  }
  function pointerUp() {
    var P = S.pointer; S.pointer = null;
    if (P && P.onCursor && !P.moved && S.screen === 'play' && S.run && !S.paused) press('ok');
    return P;
  }

  /* ------------------------------------------------------------------------------- loop */
  var draw = true;
  function step(n) {
    n = n === undefined ? 1 : n;
    for (var i = 0; i < n; i++) {
      S.frames++;
      if (S.screen === 'play' && !S.paused) stepPlay();
    }
    if (!draw) return;
    if (S.screen === 'title') drawTitle();
    else if (S.screen === 'yard') drawYard();
    else if (S.screen === 'play') drawPlayScreen();
    else if (S.screen === 'result') drawResult();
    else if (S.screen === 'homecard') drawHomeCard();
    else if (S.screen === 'reveal') drawReveal();
    else if (S.screen === 'ledger') drawLedger();
    else if (S.screen === 'ending') drawEnding();
    else if (S.screen === 'credits') drawCredits();
    else if (S.screen === 'rules') drawRules();
    else if (S.screen === 'gaveup') drawGaveUp();
    if (ctx) paint();
  }
  var STEP_MS = 1000 / 60, acc = 0, lastT = null;
  function frame(t) {
    if (lastT === null) lastT = t;
    acc += Math.min(250, t - lastT); lastT = t;
    var n = 0;
    while (acc >= STEP_MS && n < 4) { acc -= STEP_MS; n++; }
    if (n) step(n);
    root.requestAnimationFrame(frame);
  }

  function boot() {
    cv = root.document.getElementById('screen');
    ctx = cv.getContext('2d'); ctx.imageSmoothingEnabled = false;
    img = ctx.createImageData(W, H); data = img.data;
    loadTitle();
    root.addEventListener('keydown', function (e) {
      var k = KEYMAP[e.key]; if (!k) return;
      e.preventDefault();
      if (k === 'left' || k === 'right' || k === 'up' || k === 'down') {
        var was = HELD[k]; holdKey(k, true);
        if (!was && S.screen !== 'play') press(k);
        if (!was && S.screen === 'play' && S.run && S.run.cooldown > 0 && S.run.lastDir !== k) S.run.cooldown = Math.min(S.run.cooldown, 2);
      } else if (!e.repeat) press(k);
    });
    root.addEventListener('keyup', function (e) { var k = KEYMAP[e.key]; if (k && HELD[k]) holdKey(k, false); });
    root.addEventListener('blur', function () { HELD = {}; S.dirOrder = []; S.pointer = null; });
    function gamePt(e) { var b = cv.getBoundingClientRect(); return { x: (e.clientX - b.left) * W / b.width, y: (e.clientY - b.top) * H / b.height }; }
    var swipe = null;
    cv.addEventListener('pointerdown', function (e) {
      e.preventDefault(); if (SND) SND.unlock();
      try { cv.setPointerCapture(e.pointerId); } catch (err) { /* not capturable */ }
      var g = gamePt(e);
      swipe = { x: g.x, y: g.y, t: Date.now(), moved: false };
      if (S.screen === 'play') pointerDown(cellAt(g.x, g.y));
    });
    cv.addEventListener('pointermove', function (e) {
      if (!swipe) return;
      var g = gamePt(e);
      if (S.screen === 'play') { pointerMove(cellAt(g.x, g.y)); return; }
      // ⛔ PILOTAGE (found by its swipe arm): one long swipe fired several presses; one gesture is one press.
      if (swipe.fired) return;
      var dx = g.x - swipe.x, dy = g.y - swipe.y;
      if (Math.hypot(dx, dy) < 10) return;
      swipe.moved = true; swipe.fired = true;
      press(Math.abs(dx) > Math.abs(dy) ? (dx < 0 ? 'left' : 'right') : (dy < 0 ? 'up' : 'down'));
    });
    function up() {
      if (!swipe) return;
      var quick = !swipe.moved && Date.now() - swipe.t < 300;
      var wasPlay = S.screen === 'play';
      if (wasPlay) pointerUp();
      swipe = null;
      if (quick && !wasPlay) press('ok');
    }
    cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
    root.__swPress = function (k) { press(k); };
    if (/[?&]harness=1\b/.test(root.location.search)) { step(1); return; }
    step(1);
    root.requestAnimationFrame(frame);
  }

  root.STRAYWOOD = {
    step: step, setDraw: function (v) { draw = !!v; }, press: press,
    hold: function (dir, down) { holdKey(dir, down !== false); },
    releaseAll: function () { HELD = {}; S.dirOrder = []; S.pointer = null; },
    pointerDown: pointerDown, pointerMove: pointerMove, pointerUp: pointerUp, cellAt: cellAt,
    state: S, plane: plane, beginRun: beginRun, wood: wood, par: par, endingPages: endingPages, medalFor: medalFor, unlocked: unlocked,
    revealIsClue: revealIsClue, clueFor: clueFor, flownHere: flownHere, kittensHome: kittensHome, kittensAll: kittensAll,
    titleState: function () { return titleState; },
    get frames() { return S.frames; }, version: '1.0.0',
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.STRAYWOOD;
  else if (root.document) { if (root.document.readyState === 'loading') root.addEventListener('DOMContentLoaded', boot); else boot(); }
}(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this)));
