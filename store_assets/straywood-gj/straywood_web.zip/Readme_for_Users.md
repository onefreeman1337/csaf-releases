# STRAYWOOD

**Carry every lost kitten home to the cottage, three on the broom at a time. Who rides together is the puzzle.**

At moonrise the kittens have wandered off into the wood, and each one is waiting at the edge of a thicket or along the
garden wall. You are the witch: you fly low over the wood floor on your broom, take kittens on board and bring them home to the cottage gate.
The broom holds three, so a night is several trips. Every leg is charged the shortest way over the floor, round every
thicket, and the whole night's flying is scored against the least it could possibly be.

---

## How to play

| | |
| --- | --- |
| **Arrow keys** or **WASD** | **HOLD** a direction to fly the witch over the wood floor. |
| **Mouse** or **touchscreen** | **Hold a finger (or the mouse button) where you want to go**: she flies there, round any thicket in the way. Move your finger and she changes course. **Tap the witch** to act where she is (the same as Z). A finger on the garden gate takes her to its doorstep, and with kittens aboard a flight you steer by finger keeps off the doorstep until you point at it. |
| **Z** / **Enter** / **Space** | over a waiting kitten: take her onto the broom. On the cards: start, next wood, retry |
| **X** / **Esc** | back; while flying it pauses (press it again to give up); on a result it shows the least flying (after bronze or better) or a clue (after LATE HOME); from there, X again goes back to the woods |
| **P** | pause |
| **M** | mute (remembered between sessions) |
| **Left / Right**, on the wood screen | the previous or next wood (the next opens on bronze or better) |
| **Up**, on the wood screen | the cat book: every wood, with its medal, and how many kittens are home |
| **Down**, on the wood screen | the rules card (also shown before your first wood) |
| **Swipe**, on a touchscreen | on the wood screen and the cards, a swipe is the arrow key in its direction |
| **Buttons under the screen** | Z (take a kitten; OK on the cards), X, P and M, for touch and mouse players |

There is nothing to press at the gate: when the witch flies onto the doorstep with kittens on the broom, they all hop
off into the garden by themselves (even in the middle of a trip, if you fly her across it with the arrow keys, or if
the only way to the next kitten passes through it; that costs nothing, because the gate lies on that shortest way). A
kitten on the broom stays on it until the gate. Riding kittens are drawn as little heads floating behind the witch.

## The numbers

- **FLOWN** is the night's flying so far: every leg you have finished. It only ever goes up, when you reach a stop.
  Beside it, **+n** is the leg you are on: the shortest way from your last stop to where the witch is now, so it grows
  and shrinks as she flies. A leg is always charged the SHORTEST way over the floor between one stop and the next (the
  gate, a kitten, the next kitten, the gate), so where you actually fly does not matter. Only who rides together, and in
  which order you pick them up, changes the number.
- **PAR** (shown as `PAR n FOR ALL`) is the least flying the whole wood could possibly need. It is computed exactly, by
  the game's own code: every group of up to three kittens routed in its best order, then every way of splitting the
  litter into trips. It is not guessed.
- **HOME** counts the kittens in the garden; the three seats under it are the broom (dark = a kitten is riding).

The nearest kitten is honest, but it only knows where you are standing. Fetching the closest kitten, again and again,
and going home when the broom is full, leaves a far kitten out on her own and costs a whole trip to fetch her. Look at
where the kittens wait before you choose who rides together, and remember that a half-empty broom is sometimes the
shortest night.

## Medals

When the last kitten is home the wood is scored against its par, in steps of flying:

- **GOLD**: the par itself, the least flying there is.
- **SILVER**: two steps over par.
- **BRONZE**: four steps over par.
- **LATE HOME**: more than four over. The next wood opens on bronze or better, so try again.

Why steps of two? The wood floor is a grid, so every trip from the gate and back is an even number of steps, and a
night's flying can only ever differ from par by an even number: par, par plus two, par plus four, and so on.

## Seeing the least flying

After a wood of **bronze or better**, **X** shows the least flying: every trip of the best night drawn as a dark loop,
with your own legs drawn pale beneath. After **LATE HOME**, **X** shows ONE clue instead. Its first line gives the sizes
of the least night's trips (for example `TRIPS OF 3,3,2,2`) when every least night shares them. Then it rings kittens and
says one of four things, each true of EVERY least night, never just one of them: two kittens that rode together and
**never** do in the least night; two that rode apart and **always** ride together in it; one kitten who rode in a trip of
a size no least night gives her; or the kittens of one trip that could have been flown in a **shorter order**.
Everything else is still yours to find.

## The kittens

Every kitten is drawn by the game from her own design: her coat (black, white, grey, ginger, tabby, tuxedo, calico or
pointed), her ears, her face, how she sits while she waits, and her name. No two in a litter are alike. After every wood
you pass, **HOME TONIGHT** shows the portraits of the kittens you brought home, and the cat book counts them all.

---

## Editions

**The free edition** (playable in your browser) is ten woods.

**The full game** (the download) is forty woods, over four hundred kittens, a cat book for all of them, and an ending.

## Running the download

The download is a single portable `.exe`: there is no installer, you just double-click it. Like any portable app
built this way, it unpacks itself into your temporary folder while it runs, and it keeps your best flying and your
mute setting in your user profile's app-data folder (`%APPDATA%\Straywood`).

---

## Credits

Made by **Core Systems Asset Factory**.

**AI disclosure.** The code, art and text of this game were produced with generative AI assistance. The music and
sound effects are **procedural synthesis from note data** (oscillators and envelopes, written out as notes) and are
not the output of a generative audio model.

Every wood and every kitten is generated by the game's own code (`js/wood.js`, `js/kittens.js`, drawn by `js/art.js`),
and the least flying for each wood is computed by that same code. The browser edition's source is unminified in its
`js/` folder; the Windows download packs the same files inside the app.
