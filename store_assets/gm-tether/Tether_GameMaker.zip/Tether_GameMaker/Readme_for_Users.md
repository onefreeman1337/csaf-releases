# Tether - Every Bond Drawn as a Cord, for GameMaker

The visual layer above your game's relationship system. Tether draws a chart page where every character is a medallion
(your own face sprite in a gilt frame) and every bond between two of them is DRAWN as a cord whose material is the kind
of bond, whose weight is how strong it is, and whose knots are the events that changed it. Nothing is an image file:
every cord, frame, plate and rule is drawn by the package.

- **Five materials, five structures:** love is round red silk with a sheen, friendship a three-strand laid rope, an oath
  an interlocking steel chain, a rivalry barbed wire, family a ribbon that turns over as it runs.
- **Six weights each:** the value your system reports picks the tier (0 to 5), and the cord grows heavier with it.
- **Strain is a state any bond can enter:** a strained cord frays (silk, rope, ribbon), a chain link hangs open, a wire
  snaps and curls back.
- **Knots for the events that shaped a bond:** a loop of the same cord thrown over itself, a brass padlock on a chain, a
  bow on a ribbon, each with its label placed clear of every frame.
- **Medallions:** four frame forms (plain, beaded, studded, laurel) and one to three rings by how many bonds a character
  holds; your face sprite is clipped to the round, or a monogram is struck on a field of the character's own colour.
- **The ledger:** a summary of every kind, or one character's bonds as swatches of their own cord, with tier pips and
  knots.

Ported from our RPG Maker MZ plugin Tether and held to it: the in-engine suite draws every cord case and every medallion
through both and checks the drawing operations match.

## Install

1. In GameMaker, **Tools > Import Local Package**, choose `Tether.yymps`, and import everything.
2. Run the project with `rm_tth_demo` first in the room order: arrows focus each character, Space shows the whole
   company, K ties a knot on the focused character's strongest bond, S strains or mends it.

Requires GameMaker 2024.14 or later. Built and tested on runtime 2024.14.4.268 (the VM, Windows). Pure GML, no extension;
nothing here depends on GMRT.

## Quickstart

```gml
// Create - once
my_chart = tth_chart_create({ title: "The Company" });
tth_member(my_chart, "aldric", "Aldric", { face: spr_aldric_face, form: "studded" });
tth_member(my_chart, "isolde", "Isolde", { classHue: 190 });

// whenever your relationship system changes a value
tth_bond(my_chart, "aldric", "isolde", 80, { kind: "love" });
tth_knot(my_chart, "aldric", "isolde", "Mother's Letter");

// Draw GUI - baked once per change, one sprite a frame otherwise
tth_chart_draw(my_chart, 0, 0, 1280, 720);
tth_chart_draw(my_chart, 0, 0, 1280, 720, "aldric");   // the same page with Aldric's ledger

// Clean Up
tth_chart_free();
```

## Values, tiers and kinds

`tth_bond(chart, a, b, value, [{kind, strained}])` takes your system's own number. Its size picks the tier: 0, 10, 25, 50,
75 and 100 reach tiers 0 to 5 (pass `thresholds` to `tth_chart_create` to use your own six). A negative value strains any
kind but rivalry. `kind` is `"love"`, `"friendship"`, `"oath"`, `"rivalry"` or `"family"`; leave it out and a negative value
reads as rivalry, anything else as friendship. A pair you never call `tth_bond` for draws no cord: a relationship is never
invented.

A knot's place on the cord is a hash of the pair and its label, so it never moves between saves; the same label twice is
one knot, and knots on one cord are spaced so two never sit on top of each other.

## Functions

| function | what it does |
| --- | --- |
| `tth_chart_create([opts])` | a chart: `{title, kindNames, thresholds}`; `kindNames` puts your own words for the kinds on the page |
| `tth_member(chart, id, name, [opts])` | add or replace a character: `{face (a sprite), classHue (0..359), form, subtitle}`; up to 16 |
| `tth_bond(chart, a, b, value, [opts])` | set a relationship value between two characters |
| `tth_knot(chart, a, b, label)` | tie a knot on a pair's cord for an event |
| `tth_chart_bonds(chart)` | the resolved bonds: kind, material, tier, strained, knots with their positions |
| `tth_chart_draw(chart, x, y, w, h, [focus], [alpha])` | draw the page (bakes on first use and after any change) |
| `tth_chart_sprite(chart, w, h, [focus])` | the page as a cached sprite, or -1 |
| `tth_chart_compose(chart, w, h, [focus], [supersample])` | draw the page straight onto the current surface target at 0, 0 |
| `tth_chart_free()` | free every cached chart sprite |

Pages are 320 x 240 to 2048 x 2048, but a full cast of twelve wants a page of at least 1280 x 720: below that the
medallions crowd each other and the short cords between neighbours hide under their frames (a party of four or five
reads well at 800 x 450). The cast is ordered round the ring to cross as few cords as possible (exactly for up
to eight characters, by improvement above that), on one ring up to twelve and two rings up to sixteen.

**The sprites are premultiplied.** `tth_chart_draw` blends them correctly; if you draw a sprite from `tth_chart_sprite`
yourself, use `gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha)`. Do not `sprite_delete` a cached sprite; call
`tth_chart_free()`. The cache holds the 16 most recent pages.

## Performance

A chart page is thousands of drawing operations, so it is baked once into a sprite and drawn from it until the chart
changes. Measured in the suite: a 960 x 540 page in 444 to 630 ms over 3 runs on a shared Windows machine (the first bake in a session also loads the font atlases). Change bonds between frames as freely as you like; the bake happens at the next
draw.

## Removing the demo

Delete `obj_tth_demo`, `rm_tth_demo`, `tth_demo`, `tth_selftest` and `tth_oracle`. Nothing else refers to them.

## Namespacing

Every function and macro is prefixed `tth_` / `TTH_`; the only globals are `global.tth__*` caches and `global.tth_stage`
(the demo's crash reporter). The fonts are `fnt_tether_display`, `fnt_tether_title`, `fnt_tether_label` and
`fnt_tether_ui`. Nothing here touches your rooms, layers or objects.

## Fonts

The display face is Marcellus SC and the label face Sorts Mill Goudy Italic, both under the SIL Open Font License 1.1,
rasterised into GameMaker atlases under the names "Tether Display" and "Tether Label"; the demo's help line is Open Sans
(Apache 2.0). Licence texts and notices are in `Tether/fonts/`. You may use them in your game freely.

## Verification

The in-engine suite (16 assertions, all passing on the shipped source) holds this port to the original RPG Maker MZ plugin: 240 cords + 24 medallions, 53834 ops drawn through both - every cord case (five materials, six tiers, strained, knotted, both bows) and every medallion form - with exactly the original's paths, fills, strokes and rectangles. It also renders and checks a whole chart page, the reader and the API, the bake and its cache, and the refusals. A fresh import into a blank project runs this Readme's own code (15 checks, all passing), and an adversarial pass makes 36 bad calls into the documented functions with 0 crashes.

## AI disclosure

This package was written with AI assistance: the code and the generated graphics. It contains no AI-generated audio.

Core Systems Asset Factory - https://csaf.itch.io
