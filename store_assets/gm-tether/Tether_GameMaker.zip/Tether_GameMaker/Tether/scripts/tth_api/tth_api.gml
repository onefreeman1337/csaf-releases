/// tth_api.gml - the public API: a chart holds the cast and the bonds your own relationship system reports; Tether draws
/// the page. FIRST CUT (2026-10-03): create, members, bonds, knots, compose onto a surface; the sprite bake, cache and the
/// demo come next (see Internal_Ops/PORT_PLAN.md).
///
/// Tether - Every Bond Drawn as a Cord, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
///   tth_chart_create([opts])                    -> a chart {title, kindNames, thresholds}
///   tth_member(chart, id, name, [opts])         -> add/replace a character {face (sprite), classHue, form, subtitle}
///   tth_bond(chart, a, b, value, [opts])        -> set a relationship value {kind, strained}
///   tth_knot(chart, a, b, label)                -> tie a knot on a pair's cord for an event that changed it
///   tth_chart_bonds(chart)                      -> the resolved bonds [{key, a, b, value, kind, material, tier, strained, knots}]
///   tth_chart_compose(chart, w, h, [focus], [ss]) -> draw the page onto the CURRENT surface target at 0,0

/// @function tth_chart_create([opts])
function tth_chart_create(_o = undefined) {
    var _s = is_struct(_o) ? _o : {};
    return {
        title: is_string(_s[$ "title"]) ? _s.title : "Bonds",
        kindNames: is_struct(_s[$ "kindNames"]) ? _s.kindNames : {},
        thresholds: is_array(_s[$ "thresholds"]) ? _s.thresholds : tth_default_thresholds(),
        members: [], pairs: {}, uid: tth__next_uid(), version: 0
    };
}

/// @function tth__valid_chart(c)
function tth__valid_chart(_c) { return is_struct(_c) && is_array(_c[$ "members"]) && is_struct(_c[$ "pairs"]); }

/// @function tth_member(chart, id, name, [opts])
/// @description Add (or replace) a character. opts: {face: a sprite (clipped to the round), classHue: 0..359 (the
/// monogram field when there is no face), form: "plain"|"beaded"|"studded"|"laurel", subtitle}. Returns true when added.
function tth_member(_c, _id, _name, _o = undefined) {
    if (!tth__valid_chart(_c) || !(is_string(_id) || is_numeric(_id))) return false;
    _id = string(_id);
    var _s = is_struct(_o) ? _o : {};
    var _nm = is_string(_name) ? _name : _id;
    var _m = { id: _id, name: _nm, initial: string_upper(string_char_at(_nm, 1)), face: _s[$ "face"],
        classHue: is_numeric(_s[$ "classHue"]) ? _s.classHue : (tth_hash(_id) mod 360), form: is_string(_s[$ "form"]) ? _s.form : "plain",
        subtitle: is_string(_s[$ "subtitle"]) ? _s.subtitle : "" };
    _c.version += 1;
    for (var _i = 0; _i < array_length(_c.members); _i++) if (_c.members[_i].id == _id) { _c.members[_i] = _m; return true; }
    if (array_length(_c.members) >= TTH_MAX_CAST) return false;
    array_push(_c.members, _m);
    return true;
}

/// @function tth_bond(chart, a, b, value, [opts])
/// @description Set the relationship between two characters. value: your system's number (|value| picks the tier; a
/// negative value strains any kind but rivalry). opts: {kind: "love"|"friendship"|"oath"|"rivalry"|"family", strained}.
function tth_bond(_c, _a, _b, _v, _o = undefined) {
    if (!tth__valid_chart(_c) || !(is_string(_a) || is_numeric(_a)) || !(is_string(_b) || is_numeric(_b))) return false;
    _a = string(_a); _b = string(_b);
    if (_a == _b) return false;
    var _s = is_struct(_o) ? _o : {}, _key = tth_pair_key(_a, _b);
    var _e = _c.pairs[$ _key];
    if (!is_struct(_e)) { _e = { knots: [] }; _c.pairs[$ _key] = _e; }
    _e.value = is_numeric(_v) ? _v : 0;
    _e.kind = _s[$ "kind"];
    _e.strained = (_s[$ "strained"] == true);
    _c.version += 1;
    return true;
}

/// @function tth_knot(chart, a, b, label)
/// @description Tie a knot on a pair's cord for an event that shaped the bond (the same label twice is one knot).
function tth_knot(_c, _a, _b, _label) {
    if (!tth__valid_chart(_c) || !is_string(_label) || string_length(_label) == 0) return false;
    var _e = _c.pairs[$ tth_pair_key(_a, _b)];
    if (!is_struct(_e)) return false;
    array_push(_e.knots, _label);
    _c.version += 1;
    return true;
}

/// @function tth_chart_bonds(chart)
/// @description Every bond to draw, resolved: [{key, a, b, value, kind, material, tier, strained, knots}].
function tth_chart_bonds(_c) {
    if (!tth__valid_chart(_c)) return [];
    var _keys = variable_struct_get_names(_c.pairs);
    array_sort(_keys, true);
    var _out = [];
    for (var _i = 0; _i < array_length(_keys); _i++) {
        var _key = _keys[_i], _e = _c.pairs[$ _key], _dash = string_pos("-", _key);
        if (_dash <= 0) continue;
        var _kind = tth_kind_for(_e.kind, _e.value);
        array_push(_out, { key: _key, a: string_copy(_key, 1, _dash - 1), b: string_delete(_key, 1, _dash), value: _e.value, kind: _kind,
            material: tth_material_of(_kind), tier: tth_tier_for(_e.value, _c.thresholds), strained: tth_is_strained(_kind, _e.value, _e.strained),
            knots: tth_knots_for(_key, _e.knots) });
    }
    return _out;
}

/// @function tth_chart_compose(chart, w, h, [focus], [ss])
/// @description Draw the whole page onto the CURRENT surface target at 0,0: ground, cords, members (ordered round the
/// ring to cross as few cords as possible), labels, and the ledger (the summary, or `focus`'s own bonds). Returns
/// {cords, knots, labels, overlaps, crossings} or undefined.
function tth_chart_compose(_c, _w, _h, _focus = undefined, _ss = 1) {
    if (!tth__valid_chart(_c) || !is_numeric(_w) || !is_numeric(_h) || _w < 320 || _h < 240 || _w > 2048 || _h > 2048) return undefined;
    var _L = tth_page_layout(_w, _h), _ms = _c.members, _n = array_length(_ms);
    var _bonds = tth_chart_bonds(_c);
    var _pos = tth_layout_positions(_n, _L.cx, _L.cy, _L.radius, _L.chart.h / 2);
    var _index = {};
    for (var _i = 0; _i < _n; _i++) _index[$ _ms[_i].id] = _i;
    var _edges = [], _count = {};
    for (var _b = 0; _b < array_length(_bonds); _b++) {
        var _ia = _index[$ _bonds[_b].a], _ib = _index[$ _bonds[_b].b];
        if (is_undefined(_ia) || is_undefined(_ib)) continue;
        array_push(_edges, [_ia, _ib]);
        _count[$ _bonds[_b].a] = (is_undefined(_count[$ _bonds[_b].a]) ? 0 : _count[$ _bonds[_b].a]) + 1;
        _count[$ _bonds[_b].b] = (is_undefined(_count[$ _bonds[_b].b]) ? 0 : _count[$ _bonds[_b].b]) + 1;
    }
    var _order = tth_solve_order(_n, _edges, _pos);
    // ⚠️ DEVIATION FROM THE ORIGINAL, by measurement (2026-10-03, tth_render_api_focus.png): the original's face radius
    // lets neighbouring FRAMES almost touch, and the crossing solver puts bonded characters side by side - so at
    // 1280 x 720 the short cords between neighbours were buried under the frames. The face is capped so two
    // neighbouring frames keep TTH_NEIGHBOUR_GAP px of visible cord between them.
    var _face = (array_length(_pos) > 0) ? _pos[0].r : 30;
    var _plateW = tth_medallion_box(_face).w;
    if (array_length(_pos) > 1) {
        var _sp = point_distance(_pos[0].x, _pos[0].y, _pos[1].x, _pos[1].y);
        _face = max(TTH_MIN_FACE, min(_face, (_sp - TTH_NEIGHBOUR_GAP) / 2 - TTH_FRAME_EXTENT));
        // ⚠️ a name plate is never wider than the spacing to the next medallion (MEASURED 2026-10-03 on a 12-member
        // chart at 800 x 450: fixed-width plates ran across the neighbours' frames); its type shrinks, then condenses
        _plateW = min(tth_medallion_box(_face).w, max(48, _sp - 8));
    }
    var _slots = {}, _discs = [], _names = {};
    for (var _s = 0; _s < array_length(_order); _s++) {
        var _m = _ms[_order[_s]], _p = _pos[_s];
        var _rings = max(1, min(3, is_undefined(_count[$ _m.id]) ? 1 : _count[$ _m.id]));
        _slots[$ _m.id] = { x: _p.x, y: _p.y, r: _face + 9, face: _face, rings: _rings };
        array_push(_discs, { x: _p.x, y: _p.y, R: tth_outer_radius(_face, _rings) });
        _names[$ _m.id] = _m.name;
    }
    var _pf = draw_get_font(), _ph = draw_get_halign(), _pv = draw_get_valign(), _pc = draw_get_colour(), _pa = draw_get_alpha();
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_texfilter(true); gpu_set_ztestenable(false); gpu_set_zwriteenable(false);
    var _ctx = tth_cx_create(is_numeric(_ss) ? clamp(_ss, 0.25, 4) : 1);
    tth_draw_ground(_ctx, _L, { title: _c.title, kindNames: _c.kindNames });
    var _cr = tth_draw_cords(_ctx, _bonds, _slots, _L.cx, _L.cy, _focus);
    for (var _s2 = 0; _s2 < array_length(_order); _s2++) {
        var _m2 = _ms[_order[_s2]], _sl = _slots[$ _m2.id];
        if (!is_undefined(_focus) && _m2.id == _focus) tth_draw_focus_ring(_ctx, _sl.x, _sl.y, tth_outer_radius(_sl.face, _sl.rings));
        tth_draw_member(_ctx, _sl.x, _sl.y, _sl.face, { name: _m2.name, initial: _m2.initial, classHue: _m2.classHue, form: _m2.form, rings: _sl.rings, face: _m2.face }, _plateW);
    }
    var _placed = tth_place_labels(_ctx, _cr.knotLabels, _discs, _L.chart);
    tth_draw_labels(_ctx, _placed, _focus);
    if (is_undefined(_focus) || is_undefined(_index[$ _focus])) {
        tth_draw_summary(_ctx, _L.ledger, { title: _c.title, castLine: string(_n) + " characters, " + string(array_length(_bonds)) + " bonds", bonds: _bonds, names: _names, kindNames: _c.kindNames, hint: "Choose a face to see their bonds." });
    } else {
        var _rows = [];
        for (var _r = 0; _r < array_length(_bonds); _r++) {
            var _bd = _bonds[_r];
            if (_bd.a != _focus && _bd.b != _focus) continue;
            array_push(_rows, { other: (_bd.a == _focus) ? _bd.b : _bd.a, kind: _bd.kind, material: _bd.material, tier: _bd.tier, strained: _bd.strained, knots: _bd.knots, key: _bd.key });
        }
        array_sort(_rows, function(_p1, _q1) { return (_p1.tier > _q1.tier) ? -1 : ((_p1.tier < _q1.tier) ? 1 : 0); });
        var _who = _ms[_index[$ _focus]];
        tth_draw_ledger(_ctx, _L.ledger, { name: _who.name, subtitle: _who.subtitle }, _rows, _names, { kindNames: _c.kindNames });
    }
    gpu_pop_state();
    draw_set_font(_pf); draw_set_halign(_ph); draw_set_valign(_pv); draw_set_colour(_pc); draw_set_alpha(_pa);
    var _ov = 0;
    for (var _k = 0; _k < array_length(_placed); _k++) if (_placed[_k].overlap > 0) _ov++;
    return { cords: _cr.drawn, knots: _cr.knots, labels: array_length(_placed), overlaps: _ov, crossings: tth_crossings(_order, _edges, _pos) };
}
