/// tth_render.gml - the painter. Each bond is drawn as a cord of real MATERIAL - round silk with a sheen, a three-strand
/// laid rope, interlocking chain links, two strands of barbed wire, a ribbon that turns over as it runs - its weight from
/// the bond's tier, frayed / opened / snapped where it is strained, knotted at the events that shaped it; each character
/// is a medallion in a generated gilt frame. Draws through a tth_cx context; knows nothing about the rest of the game.
///
/// Tether - Every Bond Drawn as a Cord, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ THIS FILE IS A PORT HELD TO ITS ORIGINAL (the published RPG Maker MZ Tether, TetherRender.js), line for line.
/// Two GameMaker facts shape it: a GML anonymous function does NOT capture the enclosing locals, so the original's
/// `every(s, pitch, gaps, fn)` callbacks are written as plain loops over tth__every(); and GML may evaluate one
/// expression's parts right to left, so every random draw is taken into a local in the original's order.
/// The five materials differ in STRUCTURE, not colour (a palette is not a composition).

/// @function tth_ink()
/// @description The five materials' colours, [r, g, b]. Built once. (MZ: INK; wire blued iron with barbs, ribbon a lit
/// cornflower with a pale reverse - both measured on the original's contact sheet.)
function tth_ink() {
    if (variable_global_exists("tth__ink") && is_struct(global.tth__ink)) return global.tth__ink;
    global.tth__ink = {
        silk: { base: [194, 38, 63], dark: [74, 10, 23], light: [255, 208, 216], mid: [224, 84, 104] },
        rope: { base: [199, 154, 92], dark: [78, 51, 19], light: [243, 220, 170] },
        chain: { base: [163, 172, 182], dark: [42, 47, 53], light: [244, 248, 251] },
        wire: { base: [111, 127, 143], dark: [22, 27, 33], light: [223, 233, 242], rust: [160, 82, 45] },
        ribbon: { base: [79, 142, 214], dark: [23, 58, 99], light: [213, 232, 255], back: [47, 100, 163] }
    };
    return global.tth__ink;
}

/// @function tth_materials()
/// @description The five materials in the original's order.
function tth_materials() { return ["silk", "rope", "chain", "wire", "ribbon"]; }

// ---------------------------------------------------------------------------------------------------------------
// Curves and samples
// ---------------------------------------------------------------------------------------------------------------

/// @function tth_curve(p0, p1, bow)
/// @description A quadratic curve from p0 to p1 ([x, y]) bowed perpendicular to the chord by `bow` px; carries its length.
function tth_curve(_p0, _p1, _bow) {
    var _mx = (_p0[0] + _p1[0]) / 2, _my = (_p0[1] + _p1[1]) / 2;
    var _dx = _p1[0] - _p0[0], _dy = _p1[1] - _p0[1], _L = sqrt(_dx * _dx + _dy * _dy);
    if (_L == 0) _L = 1;
    var _cv = { kind: 0, p0: _p0, c: [_mx - _dy / _L * _bow, _my + _dx / _L * _bow], p1: _p1, len: 0 };
    var _len = 0, _prev = tth_curve_pt(_cv, 0);
    for (var _i = 1; _i <= 32; _i++) { var _q = tth_curve_pt(_cv, _i / 32); _len += point_distance(_prev[0], _prev[1], _q[0], _q[1]); _prev = _q; }
    _cv.len = _len;
    return _cv;
}

/// @function tth_cubic(P0, P1, P2, P3)
/// @description A cubic Bezier with the same face as tth_curve, so every painter can run along it.
function tth_cubic(_a, _b, _c, _d) {
    var _cv = { kind: 1, P0: _a, P1: _b, P2: _c, P3: _d, len: 0 };
    var _len = 0, _prev = tth_curve_pt(_cv, 0);
    for (var _i = 1; _i <= 48; _i++) { var _q = tth_curve_pt(_cv, _i / 48); _len += point_distance(_prev[0], _prev[1], _q[0], _q[1]); _prev = _q; }
    _cv.len = _len;
    return _cv;
}

/// @function tth_curve_pt(cv, t)
function tth_curve_pt(_cv, _t) {
    var _u = 1 - _t;
    if (_cv.kind == 0) return [_u * _u * _cv.p0[0] + 2 * _u * _t * _cv.c[0] + _t * _t * _cv.p1[0], _u * _u * _cv.p0[1] + 2 * _u * _t * _cv.c[1] + _t * _t * _cv.p1[1]];
    var _a = _u * _u * _u, _b = 3 * _u * _u * _t, _c = 3 * _u * _t * _t, _d = _t * _t * _t;
    return [_a * _cv.P0[0] + _b * _cv.P1[0] + _c * _cv.P2[0] + _d * _cv.P3[0], _a * _cv.P0[1] + _b * _cv.P1[1] + _c * _cv.P2[1] + _d * _cv.P3[1]];
}

/// @function tth_curve_tan(cv, t)
/// @description The unit tangent at t.
function tth_curve_tan(_cv, _t) {
    var _x, _y;
    if (_cv.kind == 0) {
        _x = 2 * (1 - _t) * (_cv.c[0] - _cv.p0[0]) + 2 * _t * (_cv.p1[0] - _cv.c[0]);
        _y = 2 * (1 - _t) * (_cv.c[1] - _cv.p0[1]) + 2 * _t * (_cv.p1[1] - _cv.c[1]);
    } else {
        var _u = 1 - _t;
        _x = 3 * _u * _u * (_cv.P1[0] - _cv.P0[0]) + 6 * _u * _t * (_cv.P2[0] - _cv.P1[0]) + 3 * _t * _t * (_cv.P3[0] - _cv.P2[0]);
        _y = 3 * _u * _u * (_cv.P1[1] - _cv.P0[1]) + 6 * _u * _t * (_cv.P2[1] - _cv.P1[1]) + 3 * _t * _t * (_cv.P3[1] - _cv.P2[1]);
    }
    var _l = sqrt(_x * _x + _y * _y);
    if (_l == 0) _l = 1;
    return [_x / _l, _y / _l];
}

/// @function tth_samples(cv, step)
/// @description Samples at (roughly) even arc spacing: {x, y, tx, ty, nx, ny, t, d}.
function tth_samples(_cv, _step) {
    var _n = max(2, ceil(_cv.len / max(0.5, _step))), _out = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n, _p = tth_curve_pt(_cv, _t), _g = tth_curve_tan(_cv, _t);
        _out[_i] = { x: _p[0], y: _p[1], tx: _g[0], ty: _g[1], nx: -_g[1], ny: _g[0], t: _t, d: _t * _cv.len };
    }
    return _out;
}

/// @function tth__in_gap(t, gaps)
function tth__in_gap(_t, _gaps) { for (var _i = 0; _i < array_length(_gaps); _i++) if (_t >= _gaps[_i][0] && _t <= _gaps[_i][1]) return true; return false; }

/// @function tth__every(s, pitch, gaps)
/// @description Every `pitch` px of arc, outside the gaps: [[sample, k], ...] (a PITCH, never a typed count). The
/// original passes a callback; GML closures cannot see the caller's locals, so the caller loops over this list.
function tth__every(_s, _pitch, _gaps) {
    var _next = _pitch / 2, _k = 0, _o = [];
    for (var _i = 0; _i < array_length(_s); _i++) {
        if (_s[_i].d >= _next) { if (!tth__in_gap(_s[_i].t, _gaps)) array_push(_o, [_s[_i], _k]); _k++; _next += _pitch; }
    }
    return _o;
}

/// @function tth__run(ctx, s, off, width, rgb, gaps, [alpha])
/// @description Stroke the sample polyline at a normal offset, breaking at the gaps (round caps).
function tth__run(_c, _s, _off, _width, _rgb, _gaps, _alpha = undefined) {
    tth_cx_save(_c);
    _c.stroke = tth_cx_solid(_rgb); _c.lw = _width; _c.cap = 1;
    if (!is_undefined(_alpha)) _c.alpha = _alpha;
    var _open = false;
    tth_cx_begin(_c);
    for (var _i = 0; _i < array_length(_s); _i++) {
        var _p = _s[_i], _gx = _p.x + _p.nx * _off, _gy = _p.y + _p.ny * _off;
        if (tth__in_gap(_p.t, _gaps)) { _open = false; continue; }
        if (!_open) { tth_cx_move(_c, _gx, _gy); _open = true; } else tth_cx_line(_c, _gx, _gy);
    }
    tth_cx_stroke(_c);
    tth_cx_restore(_c);
}

/// @function tth_width_for(material, tier)
/// @description A cord's width from its material and tier (0..5). (MZ: the floor rose after tier-0 silk and wire read
/// as hairlines at chart scale.)
function tth_width_for(_m, _tier) {
    var _t = max(0, min(5, floor(is_numeric(_tier) ? _tier : 0)));
    switch (_m) {
        case "silk": return 3.4 + _t * 1.0;
        case "rope": return 3.8 + _t * 1.25;
        case "chain": return 1.6 + _t * 0.34;
        case "wire": return 1.4 + _t * 0.22;
        case "ribbon": return 6 + _t * 1.6;
    }
    return 3;
}

/// @function tth__line(ctx, x0, y0, x1, y1)
/// @description beginPath + moveTo + lineTo + stroke with the current stroke state. Internal.
function tth__line(_c, _x0, _y0, _x1, _y1) { tth_cx_begin(_c); tth_cx_move(_c, _x0, _y0); tth_cx_line(_c, _x1, _y1); tth_cx_stroke(_c); }

// ---------------------------------------------------------------------------------------------------------------
// The five materials
// ---------------------------------------------------------------------------------------------------------------

/// @function tth_draw_silk(ctx, s, w, gaps, C)
/// @description Silk is SMOOTH: one glossy round cord, shaded under and lit by a continuous sheen, a faint long twist.
function tth_draw_silk(_c, _s, _w, _gaps, _C) {
    tth__run(_c, _s, 0, _w + 2.2, _C.dark, _gaps);
    tth__run(_c, _s, 0, _w, _C.base, _gaps);
    tth__run(_c, _s, _w * 0.24, max(0.8, _w * 0.42), _C.dark, _gaps, 0.32);
    tth__run(_c, _s, -_w * 0.12, max(0.8, _w * 0.46), _C.mid, _gaps, 0.9);
    tth__run(_c, _s, -_w * 0.24, max(0.8, _w * 0.2), _C.light, _gaps, 0.9);
    var _ev = tth__every(_s, max(10, _w * 4.2), _gaps);
    for (var _i = 0; _i < array_length(_ev); _i++) {
        var _p = _ev[_i][0];
        tth_cx_save(_c); _c.stroke = tth_cx_solid(_C.dark); _c.alpha = 0.22; _c.lw = max(0.7, _w * 0.16); _c.cap = 1;
        tth_cx_begin(_c);
        tth_cx_move(_c, _p.x - _p.nx * _w * 0.45 - _p.tx * _w * 0.9, _p.y - _p.ny * _w * 0.45 - _p.ty * _w * 0.9);
        tth_cx_quad(_c, _p.x, _p.y, _p.x + _p.nx * _w * 0.45 + _p.tx * _w * 0.9, _p.y + _p.ny * _w * 0.45 + _p.ty * _w * 0.9);
        tth_cx_stroke(_c); tth_cx_restore(_c);
    }
}

/// @function tth_draw_rope(ctx, s, w, gaps, C)
/// @description A three-strand laid rope: a strand crosses the rope at the lay angle every pitch, lit on its upper flank.
function tth_draw_rope(_c, _s, _w, _gaps, _C) {
    tth__run(_c, _s, 0, _w + 2, _C.dark, _gaps);
    tth__run(_c, _s, 0, _w, _C.base, _gaps);
    var _pitch = max(3, _w * 0.95);
    var _ev = tth__every(_s, _pitch, _gaps);
    for (var _i = 0; _i < array_length(_ev); _i++) {
        var _p = _ev[_i][0], _k = _ev[_i][1];
        var _ax = _p.x + _p.nx * _w * 0.5 - _p.tx * _pitch * 0.45, _ay = _p.y + _p.ny * _w * 0.5 - _p.ty * _pitch * 0.45;
        var _bx = _p.x - _p.nx * _w * 0.5 + _p.tx * _pitch * 0.45, _by = _p.y - _p.ny * _w * 0.5 + _p.ty * _pitch * 0.45;
        tth_cx_save(_c); _c.cap = 1;
        _c.stroke = tth_cx_solid((_k mod 3 == 2) ? _C.base : _C.light); _c.lw = max(1, _pitch * 0.5);
        tth__line(_c, _ax, _ay, _bx, _by);
        _c.stroke = tth_cx_solid(_C.dark); _c.lw = max(0.6, _pitch * 0.14); _c.alpha = 0.8;
        tth__line(_c, _ax + _p.tx * _pitch * 0.42, _ay + _p.ty * _pitch * 0.42, _bx + _p.tx * _pitch * 0.42, _by + _p.ty * _pitch * 0.42);
        tth_cx_restore(_c);
    }
}

/// @function tth_draw_chain(ctx, s, w, gaps, C, tier)
/// @description Interlocking links: a flat oval ring seen face-on, then the next link edge-on as a bar, alternating.
function tth_draw_chain(_c, _s, _w, _gaps, _C, _tier) {
    var _L = 7 + _tier * 1.9, _g = _w;
    var _ev = tth__every(_s, _L * 0.82, _gaps);
    for (var _i = 0; _i < array_length(_ev); _i++) {
        var _p = _ev[_i][0], _k = _ev[_i][1];
        tth_cx_save(_c); tth_cx_translate(_c, _p.x, _p.y); tth_cx_rotate(_c, arctan2(_p.ty, _p.tx));
        if (_k mod 2 == 0) {
            _c.lw = _g + 1.2; _c.stroke = tth_cx_solid(_C.dark);
            tth_cx_begin(_c); tth_cx_ellipse(_c, 0, 0, _L * 0.56, _L * 0.34, 0, 0, pi * 2); tth_cx_stroke(_c);
            _c.lw = _g; _c.stroke = tth_cx_solid(_C.base);
            tth_cx_begin(_c); tth_cx_ellipse(_c, 0, 0, _L * 0.56, _L * 0.34, 0, 0, pi * 2); tth_cx_stroke(_c);
            _c.lw = max(0.6, _g * 0.35); _c.stroke = tth_cx_solid(_C.light);
            tth_cx_begin(_c); tth_cx_ellipse(_c, 0, 0, _L * 0.56, _L * 0.34, 0, pi * 1.1, pi * 1.7); tth_cx_stroke(_c);
        } else {
            _c.cap = 1;
            _c.lw = _g * 1.6 + 1.2; _c.stroke = tth_cx_solid(_C.dark); tth__line(_c, -_L * 0.55, 0, _L * 0.55, 0);
            _c.lw = _g * 1.6; _c.stroke = tth_cx_solid(_C.base); tth__line(_c, -_L * 0.55, 0, _L * 0.55, 0);
            _c.lw = max(0.6, _g * 0.4); _c.stroke = tth_cx_solid(_C.light); tth__line(_c, -_L * 0.4, -_g * 0.3, _L * 0.4, -_g * 0.3);
        }
        tth_cx_restore(_c);
    }
}

/// @function tth__strands(ctx, s, w, gaps, C, amp, period)
/// @description Two twisted strands, each in three passes (shadow, body, glint).
function tth__strands(_c, _s, _w, _gaps, _C, _amp, _period) {
    for (var _st = 0; _st < 2; _st++) {
        var _phase = _st * pi;
        tth_cx_save(_c); _c.cap = 1;
        for (var _pass = 0; _pass < 3; _pass++) {
            _c.stroke = tth_cx_solid((_pass == 0) ? _C.dark : ((_pass == 1) ? _C.base : _C.light));
            _c.lw = (_pass == 0) ? _w + 1.1 : ((_pass == 1) ? _w : max(0.5, _w * 0.35));
            _c.alpha = (_pass == 2) ? 0.85 : 1;
            tth_cx_begin(_c);
            var _open = false;
            for (var _i = 0; _i < array_length(_s); _i++) {
                var _p = _s[_i];
                if (tth__in_gap(_p.t, _gaps)) { _open = false; continue; }
                var _o = sin(_p.d / _period * pi * 2 + _phase) * _amp - ((_pass == 2) ? _w * 0.2 : 0);
                var _x = _p.x + _p.nx * _o, _y = _p.y + _p.ny * _o;
                if (!_open) { tth_cx_move(_c, _x, _y); _open = true; } else tth_cx_line(_c, _x, _y);
            }
            tth_cx_stroke(_c);
        }
        tth_cx_restore(_c);
    }
}

/// @function tth_draw_wire(ctx, s, w, gaps, C, tier)
/// @description Rivalry is BARBED wire: two twisted iron strands and a barb every pitch - a coil round the strands and
/// two spikes crossing them. The barbs are what a stranger names; the twist alone read as cord.
function tth_draw_wire(_c, _s, _w, _gaps, _C, _tier) {
    var _amp = 0.8 + _tier * 0.35, _period = 6 + _tier * 1.2;
    tth__strands(_c, _s, _w, _gaps, _C, _amp, _period);
    var _pitch = 15 + _tier * 2.2, _sp = 3.2 + _tier * 0.9;
    var _ev = tth__every(_s, _pitch, _gaps);
    for (var _i = 0; _i < array_length(_ev); _i++) {
        var _p = _ev[_i][0];
        tth_cx_save(_c); tth_cx_translate(_c, _p.x, _p.y); tth_cx_rotate(_c, arctan2(_p.ty, _p.tx)); _c.cap = 1;
        for (var _pass = 0; _pass < 2; _pass++) {
            _c.stroke = tth_cx_solid(_pass ? _C.base : _C.dark); _c.lw = _pass ? max(0.9, _w * 0.8) : max(0.9, _w * 0.8) + 1.2;
            tth__line(_c, -_sp * 0.7, -_sp, _sp * 0.7, _sp);
            tth__line(_c, _sp * 0.7, -_sp, -_sp * 0.7, _sp);
        }
        _c.fill = tth_cx_solid(_C.dark); tth_cx_fill_rect(_c, -_w * 1.1, -_amp - _w * 0.9, _w * 2.2, (_amp + _w * 0.9) * 2);
        _c.fill = tth_cx_solid(_C.base); tth_cx_fill_rect(_c, -_w * 0.8, -_amp - _w * 0.6, _w * 1.6, (_amp + _w * 0.6) * 2);
        _c.fill = tth_cx_solid(_C.light); _c.alpha = 0.8; tth_cx_fill_rect(_c, -_w * 0.8, -_amp - _w * 0.6, _w * 1.6, max(0.8, _w * 0.35));
        tth_cx_restore(_c);
    }
}

/// @function tth_draw_ribbon(ctx, s, w, gaps, C, tier)
/// @description A flat band that turns over as it runs: its width follows the cosine of the twist, the reverse is paler,
/// both edges are inked and the face catches a highlight.
function tth_draw_ribbon(_c, _s, _w, _gaps, _C, _tier) {
    var _twist = 46 + _tier * 5;
    tth_cx_save(_c);
    for (var _i = 1; _i < array_length(_s); _i++) {
        var _a = _s[_i - 1], _b = _s[_i];
        if (tth__in_gap(_a.t, _gaps) || tth__in_gap(_b.t, _gaps)) continue;
        var _fa = cos(_a.d / _twist * pi), _fb = cos(_b.d / _twist * pi);
        var _ha = (_w / 2) * (0.18 + 0.82 * abs(_fa)), _hb = (_w / 2) * (0.18 + 0.82 * abs(_fb));
        _c.fill = tth_cx_solid((_fa >= 0) ? _C.base : _C.back);
        tth_cx_begin(_c);
        tth_cx_move(_c, _a.x + _a.nx * _ha, _a.y + _a.ny * _ha); tth_cx_line(_c, _b.x + _b.nx * _hb, _b.y + _b.ny * _hb);
        tth_cx_line(_c, _b.x - _b.nx * _hb, _b.y - _b.ny * _hb); tth_cx_line(_c, _a.x - _a.nx * _ha, _a.y - _a.ny * _ha);
        tth_cx_close(_c); tth_cx_fill(_c);
        _c.stroke = tth_cx_solid(_C.dark); _c.lw = 0.9;
        tth__line(_c, _a.x + _a.nx * _ha, _a.y + _a.ny * _ha, _b.x + _b.nx * _hb, _b.y + _b.ny * _hb);
        tth__line(_c, _a.x - _a.nx * _ha, _a.y - _a.ny * _ha, _b.x - _b.nx * _hb, _b.y - _b.ny * _hb);
        if (_fa >= 0.55) {
            _c.stroke = tth_cx_solid(_C.light); _c.alpha = 0.6; _c.lw = max(0.7, _w * 0.12);
            tth__line(_c, _a.x + _a.nx * _ha * 0.45, _a.y + _a.ny * _ha * 0.45, _b.x + _b.nx * _hb * 0.45, _b.y + _b.ny * _hb * 0.45);
            _c.alpha = 1;
        }
    }
    tth_cx_restore(_c);
}

/// @function tth_paint(ctx, material, s, w, gaps, C, tier)
/// @description Dispatch to a material's painter (MZ: PAINT[material]).
function tth_paint(_c, _m, _s, _w, _gaps, _C, _tier) {
    switch (_m) {
        case "silk": tth_draw_silk(_c, _s, _w, _gaps, _C); break;
        case "rope": tth_draw_rope(_c, _s, _w, _gaps, _C); break;
        case "chain": tth_draw_chain(_c, _s, _w, _gaps, _C, _tier); break;
        case "wire": tth_draw_wire(_c, _s, _w, _gaps, _C, _tier); break;
        case "ribbon": tth_draw_ribbon(_c, _s, _w, _gaps, _C, _tier); break;
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Strain: a STATE any kind can enter
// ---------------------------------------------------------------------------------------------------------------

/// @function tth_draw_strain(ctx, material, cv, gaps, w, C, seed)
/// @description Fibre (silk, rope, ribbon): loose fibres splay out of each break. Chain: the link at the break is OPENED
/// and hangs askew. Wire: both strands snap and curl back.
function tth_draw_strain(_c, _m, _cv, _gaps, _w, _C, _seed) {
    if (_m == "chain") { tth__open_link(_c, _cv, _gaps, _w, _C); return; }
    if (_m == "wire") { tth__snapped(_c, _cv, _gaps, _w, _C); return; }
    tth__fray(_c, _cv, _gaps, min(_w, 5.5), _C, _seed);
}

function tth__open_link(_c, _cv, _gaps, _w, _C) {
    for (var _g = 0; _g < array_length(_gaps); _g++) {
        var _t = (_gaps[_g][0] + _gaps[_g][1]) / 2, _p = tth_curve_pt(_cv, _t), _tg = tth_curve_tan(_cv, _t), _L = 7 + _w * 3.8;
        tth_cx_save(_c); tth_cx_translate(_c, _p[0], _p[1]); tth_cx_rotate(_c, arctan2(_tg[1], _tg[0]) + 1.1);
        for (var _pass = 0; _pass < 3; _pass++) {
            _c.stroke = tth_cx_solid((_pass == 0) ? _C.dark : ((_pass == 1) ? _C.base : _C.light));
            _c.lw = (_pass == 0) ? _w + 1.4 : ((_pass == 1) ? _w : max(0.6, _w * 0.35));
            _c.cap = 1;
            tth_cx_begin(_c);
            tth_cx_ellipse(_c, 0, 0, _L * 0.56, _L * 0.34, 0, (_pass == 2) ? pi * 1.15 : pi * 0.32, (_pass == 2) ? pi * 1.6 : pi * 1.68);
            tth_cx_stroke(_c);
        }
        tth_cx_restore(_c);
    }
}

function tth__snapped(_c, _cv, _gaps, _w, _C) {
    for (var _g = 0; _g < array_length(_gaps); _g++) {
        for (var _end = 0; _end < 2; _end++) {
            var _t = _gaps[_g][_end], _p = tth_curve_pt(_cv, _t), _tg = tth_curve_tan(_cv, _t), _dir = (_end == 0) ? 1 : -1;
            for (var _strand = -1; _strand <= 1; _strand += 2) {
                var _r = 2.4 + _w * 1.3;
                var _cx = _p[0] + _tg[0] * _dir * _r * 0.6 - _tg[1] * _strand * _r, _cy = _p[1] + _tg[1] * _dir * _r * 0.6 + _tg[0] * _strand * _r;
                var _a0 = arctan2(_p[1] - _cy, _p[0] - _cx);
                for (var _pass = 0; _pass < 2; _pass++) {
                    tth_cx_save(_c); _c.stroke = tth_cx_solid(_pass ? _C.base : _C.dark); _c.lw = _pass ? _w : _w + 1.1; _c.cap = 1;
                    tth_cx_begin(_c); tth_cx_arc(_c, _cx, _cy, _r, _a0, _a0 + _strand * _dir * pi * 1.35, _strand * _dir < 0); tth_cx_stroke(_c);
                    tth_cx_restore(_c);
                }
            }
        }
    }
}

/// @function tth__fray_rnd(gen)
/// @description The original's fray generator (xorshift-multiply), bit for bit. Internal.
function tth__fray_rnd(_g) {
    var _h = _g.h;
    _h = tth_mul32(_h ^ (_h >> 15), 2246822507);
    _h = tth_mul32(_h ^ (_h >> 13), 3266489909);
    _h = (_h ^ (_h >> 16)) & $FFFFFFFF;
    _g.h = _h;
    return _h / 4294967296;
}

function tth__fray(_c, _cv, _gaps, _w, _C, _seed) {
    var _g0 = { h: tth_u32(_seed) };
    if (_g0.h == 0) _g0.h = 1;
    for (var _g = 0; _g < array_length(_gaps); _g++) {
        for (var _end = 0; _end < 2; _end++) {
            var _t = _gaps[_g][_end], _p = tth_curve_pt(_cv, _t), _tg = tth_curve_tan(_cv, _t), _dir = (_end == 0) ? 1 : -1;
            for (var _f = 0; _f < 6; _f++) {
                var _r1 = tth__fray_rnd(_g0);
                var _spread = (_r1 - 0.5) * 2.6;
                var _r2 = tth__fray_rnd(_g0);
                var _len = _w * (1.5 + _r2 * 2.0);
                var _ex = _p[0] + (_tg[0] * _dir + -_tg[1] * _spread) * _len, _ey = _p[1] + (_tg[1] * _dir + _tg[0] * _spread) * _len;
                tth_cx_save(_c); _c.stroke = tth_cx_solid((_f mod 2 == 1) ? _C.light : _C.base); _c.lw = max(0.6, _w * 0.16); _c.cap = 1;
                tth_cx_begin(_c);
                var _r3 = tth__fray_rnd(_g0);
                var _r4 = tth__fray_rnd(_g0);
                tth_cx_move(_c, _p[0] + -_tg[1] * (_r3 - 0.5) * _w * 0.8, _p[1] + _tg[0] * (_r4 - 0.5) * _w * 0.8);
                tth_cx_quad(_c, _p[0] + _tg[0] * _dir * _len * 0.5, _p[1] + _tg[1] * _dir * _len * 0.5, _ex, _ey);
                tth_cx_stroke(_c); tth_cx_restore(_c);
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Knots, the padlock, the bond
// ---------------------------------------------------------------------------------------------------------------

/// @function tth__rounded(ctx, x, y, w, h, r)
/// @description A rounded-rectangle path with quadratic corners (the original's own corner shape). Internal.
function tth__rounded(_c, _x, _y, _w, _h, _r) {
    tth_cx_begin(_c); tth_cx_move(_c, _x + _r, _y); tth_cx_line(_c, _x + _w - _r, _y); tth_cx_quad(_c, _x + _w, _y, _x + _w, _y + _r);
    tth_cx_line(_c, _x + _w, _y + _h - _r); tth_cx_quad(_c, _x + _w, _y + _h, _x + _w - _r, _y + _h); tth_cx_line(_c, _x + _r, _y + _h);
    tth_cx_quad(_c, _x, _y + _h, _x, _y + _h - _r); tth_cx_line(_c, _x, _y + _r); tth_cx_quad(_c, _x, _y, _x + _r, _y); tth_cx_close(_c);
}

/// @function tth_draw_padlock(ctx, p, w)
/// @description An oath is LOCKED, not tied: a brass padlock hanging straight down (gravity, not the chain's angle).
function tth_draw_padlock(_c, _p, _w) {
    var _rS = 3.2 + _w * 1.3, _bw = 8 + _w * 3.4, _bh = 7 + _w * 2.8, _top = _p[1] + _rS * 0.35;
    var _BD = [79, 58, 16], _BB = [201, 162, 74], _BL = [248, 231, 173];
    tth_cx_save(_c); _c.cap = 1;
    _c.lw = _w * 1.1 + 2.4; _c.stroke = tth_cx_solid(_BD);
    tth_cx_begin(_c); tth_cx_arc(_c, _p[0], _top, _rS, pi, pi * 2); tth_cx_stroke(_c);
    _c.lw = _w * 1.1 + 1; _c.stroke = tth_cx_solid([185, 193, 201]);
    tth_cx_begin(_c); tth_cx_arc(_c, _p[0], _top, _rS, pi, pi * 2); tth_cx_stroke(_c);
    _c.fill = tth_cx_solid([0, 0, 0], 0.35);
    tth__rounded(_c, _p[0] - _bw / 2 + 1.5, _top + 2, _bw, _bh, _bh * 0.22); tth_cx_fill(_c);
    _c.fill = tth_cx_solid(_BB); _c.stroke = tth_cx_solid(_BD); _c.lw = 1.3;
    tth__rounded(_c, _p[0] - _bw / 2, _top, _bw, _bh, _bh * 0.22); tth_cx_fill(_c); tth_cx_stroke(_c);
    _c.fill = tth_cx_solid(_BL); _c.alpha = 0.85; tth_cx_fill_rect(_c, _p[0] - _bw / 2 + 1.5, _top + 1.5, _bw - 3, max(1, _bh * 0.14));
    _c.alpha = 1; _c.fill = tth_cx_solid(_BD);
    tth_cx_begin(_c); tth_cx_arc(_c, _p[0], _top + _bh * 0.45, max(1, _bh * 0.12), 0, pi * 2); tth_cx_fill(_c);
    tth_cx_fill_rect(_c, _p[0] - max(0.5, _bh * 0.05), _top + _bh * 0.45, max(1, _bh * 0.1), _bh * 0.3);
    tth_cx_restore(_c);
}

/// @function tth_draw_knot(ctx, p, g, w, material, C, tier, side)
/// @description A knot is the cord TIED: a round loop of the same material thrown over itself to one side and cinched
/// at a small core; a chain is padlocked instead and a ribbon tied in a bow. (MZ: the first knots read as beads.)
function tth_draw_knot(_c, _p, _g, _w, _m, _C, _tier, _side) {
    if (_m == "chain") { tth_draw_padlock(_c, _p, _w); return; }
    if (_m != "ribbon") {
        var _sd = (_side == 1) ? 1 : -1, _nx = -_g[1] * _sd, _ny = _g[0] * _sd;
        var _h = 6 + _w * 2.3, _a = 1.2 + _w * 0.7;
        var _P0 = [_p[0] - _g[0] * _a * 1.2, _p[1] - _g[1] * _a * 1.2], _P3 = [_p[0] + _g[0] * _a * 1.2, _p[1] + _g[1] * _a * 1.2];
        var _P1 = [_p[0] + _g[0] * _h * 1.7 + _nx * _h * 2.3, _p[1] + _g[1] * _h * 1.7 + _ny * _h * 2.3];
        var _P2 = [_p[0] - _g[0] * _h * 1.7 + _nx * _h * 2.3, _p[1] - _g[1] * _h * 1.7 + _ny * _h * 2.3];
        var _loop = tth_cubic(_P0, _P1, _P2, _P3), _ls = tth_samples(_loop, 1.2), _lw = max(1.4, _w * 0.82);
        if (_m == "wire") tth__strands(_c, _ls, _lw, [], _C, 0.8, 6); else tth_paint(_c, _m, _ls, _lw, [], _C, _tier);
        tth_cx_save(_c); tth_cx_translate(_c, _p[0], _p[1]); tth_cx_rotate(_c, arctan2(_g[1], _g[0]));
        var _rx = _a * 1.25, _ry = _w * 0.6 + 1.2;
        _c.fill = tth_cx_solid(_C.base); _c.stroke = tth_cx_solid(_C.dark); _c.lw = 1.3;
        tth_cx_begin(_c); tth_cx_ellipse(_c, 0, 0, _rx, _ry, 0, 0, pi * 2); tth_cx_fill(_c); tth_cx_stroke(_c);
        _c.stroke = tth_cx_solid(_C.dark); _c.alpha = 0.75; _c.lw = max(0.8, _w * 0.22);
        tth__line(_c, -_rx * 0.35, -_ry, _rx * 0.1, _ry);
        tth__line(_c, _rx * 0.25, -_ry, _rx * 0.65, _ry * 0.8);
        _c.stroke = tth_cx_solid(_C.light); _c.alpha = 0.85; _c.lw = max(0.7, _w * 0.18);
        tth__line(_c, -_rx * 0.8, -_ry * 0.35, -_rx * 0.45, -_ry * 0.6);
        tth_cx_restore(_c);
        return;
    }
    tth_cx_save(_c); tth_cx_translate(_c, _p[0], _p[1]); tth_cx_rotate(_c, arctan2(_g[1], _g[0]));
    _c.fill = tth_cx_solid(_C.base); _c.stroke = tth_cx_solid(_C.dark); _c.lw = 1;
    for (var _s2 = -1; _s2 <= 1; _s2 += 2) {
        tth_cx_begin(_c); tth_cx_ellipse(_c, _s2 * _w * 0.9, -_w * 0.2, _w * 0.95, _w * 0.55, _s2 * 0.5, 0, pi * 2); tth_cx_fill(_c); tth_cx_stroke(_c);
        tth_cx_begin(_c); tth_cx_move(_c, 0, 0); tth_cx_line(_c, _s2 * _w * 0.7, _w * 1.6); tth_cx_line(_c, _s2 * _w * 0.25, _w * 1.5); tth_cx_close(_c); tth_cx_fill(_c); tth_cx_stroke(_c);
    }
    tth_cx_begin(_c); tth_cx_arc(_c, 0, 0, _w * 0.42, 0, pi * 2); _c.fill = tth_cx_solid(_C.light); tth_cx_fill(_c); tth_cx_stroke(_c);
    tth_cx_restore(_c);
}

/// @function tth__hash_str(s)
/// @description FNV-1a of a string, unsigned (the original's hashStr). Internal.
function tth__hash_str(_s) { return tth_hash(_s); }

/// @function tth_draw_bond(ctx, bond, A, B, bow)
/// @description Draw one bond between two medallion rims. bond: {material, tier 0..5, strained, knots: [{t, label}],
/// key}; A, B: {x, y, r}; bow: perpendicular bow in px. Returns what was drawn: {material, width, knots, gaps, length,
/// knotsAt, mid}.
function tth_draw_bond(_c, _bond, _A, _B, _bow) {
    var _b = is_struct(_bond) ? _bond : {};
    var _m = _b[$ "material"];
    if (!is_string(_m) || array_get_index(tth_materials(), _m) < 0) _m = "rope";
    var _ink = tth_ink(), _C = _ink[$ _m];
    var _tr = _b[$ "tier"];
    var _tier = max(0, min(5, floor(is_numeric(_tr) ? _tr : 0))), _w = tth_width_for(_m, _tier);
    var _dx = _B.x - _A.x, _dy = _B.y - _A.y, _L = sqrt(_dx * _dx + _dy * _dy);
    if (_L == 0) _L = 1;
    var _ar = is_numeric(_A[$ "r"]) ? _A.r : 0, _br = is_numeric(_B[$ "r"]) ? _B.r : 0;
    var _p0 = [_A.x + _dx / _L * _ar, _A.y + _dy / _L * _ar], _p1 = [_B.x - _dx / _L * _br, _B.y - _dy / _L * _br];
    _bow = is_numeric(_bow) ? _bow : 0;
    var _cv = tth_curve(_p0, _p1, _bow);
    var _fibre = (_m == "silk" || _m == "rope" || _m == "ribbon");
    var _gw = (_m == "chain") ? 10 + _w * 3 : 8 + _w;
    var _gaps = [];
    if (_b[$ "strained"] == true) {
        if (_fibre) _gaps = [[0.6, 0.6 + min(0.08, 10 / _cv.len)], [0.74, 0.74 + min(0.05, 7 / _cv.len)]];
        else _gaps = [[0.62, 0.62 + min(0.14, _gw / _cv.len)]];
    }
    var _s = tth_samples(_cv, 1.5);
    tth_paint(_c, _m, _s, _w, _gaps, _C, _tier);
    var _key = _b[$ "key"];
    if (array_length(_gaps) > 0) tth_draw_strain(_c, _m, _cv, _gaps, max(_w, 2.5), _C, ((is_string(_key) && string_length(_key) > 0) ? tth__hash_str(_key) : 1) + _tier);
    var _kn = is_array(_b[$ "knots"]) ? _b.knots : [], _at = [];
    var _side = (_bow >= 0) ? -1 : 1;
    for (var _i = 0; _i < array_length(_kn); _i++) {
        var _kt = _kn[_i].t;
        var _kp = tth_curve_pt(_cv, _kt);
        tth_draw_knot(_c, _kp, tth_curve_tan(_cv, _kt), max(_w, 2.2), _m, _C, _tier, _side);
        array_push(_at, { x: _kp[0], y: _kp[1], label: is_string(_kn[_i][$ "label"]) ? _kn[_i].label : "" });
    }
    return { material: _m, width: _w, knots: array_length(_kn), gaps: array_length(_gaps), length: _cv.len, knotsAt: _at, mid: tth_curve_pt(_cv, 0.5) };
}

// ---------------------------------------------------------------------------------------------------------------
// The medallion
// ---------------------------------------------------------------------------------------------------------------

/// @function tth_frames()
/// @description The four frame forms (MZ: 'notched' read as a COG and became 'studded').
function tth_frames() { return ["plain", "beaded", "studded", "laurel"]; }

/// @function tth_outer_radius(r, rings)
/// @description The outermost pixel a framed medallion reaches: rings to r + 4 + 3n, ornament 4 beyond.
function tth_outer_radius(_r, _rings) { var _n = max(1, min(3, floor(is_numeric(_rings) ? _rings : 1))); return _r + 4 + _n * 3 + 4; }

/// @function tth_draw_medallion(ctx, x, y, r, form, rings)
/// @description A gilt medallion frame round (x, y) of radius r: a cast shadow, 1..3 rings, a glint, and the form's
/// ornament (beads, studs or laurel) at a 9 px pitch round the outer ring. The face is drawn INSIDE by the caller.
function tth_draw_medallion(_c, _x, _y, _r, _form, _rings) {
    var _f = (is_string(_form) && array_get_index(tth_frames(), _form) >= 0) ? _form : "plain";
    var _n = max(1, min(3, floor(is_numeric(_rings) ? _rings : 1)));
    tth_cx_save(_c);
    _c.fill = tth_cx_solid([0, 0, 0], 0.35); tth_cx_begin(_c); tth_cx_arc(_c, _x + 2, _y + 3, _r + 4 + _n * 3, 0, pi * 2); tth_cx_fill(_c);
    for (var _i = _n; _i >= 1; _i--) {
        _c.lw = 3; _c.stroke = tth_cx_solid((_i == 1) ? [202, 164, 90] : [138, 106, 44]);
        tth_cx_begin(_c); tth_cx_arc(_c, _x, _y, _r + 1 + _i * 3, 0, pi * 2); tth_cx_stroke(_c);
    }
    _c.lw = 1; _c.stroke = tth_cx_solid([243, 220, 156]); tth_cx_begin(_c); tth_cx_arc(_c, _x, _y, _r + 2.5, pi * 1.1, pi * 1.6); tth_cx_stroke(_c);
    var _R = _r + 4 + _n * 3;
    var _count = max(8, tth_jsround(2 * pi * _R / 9));
    for (var _k = 0; _k < _count; _k++) {
        var _a = _k / _count * pi * 2, _cx = _x + cos(_a) * _R, _cy = _y + sin(_a) * _R;
        if (_f == "beaded") { _c.fill = tth_cx_solid([217, 182, 102]); tth_cx_begin(_c); tth_cx_arc(_c, _cx, _cy, 2.1, 0, pi * 2); tth_cx_fill(_c); }
        else if (_f == "studded" && _k mod 3 == 0) {
            _c.fill = tth_cx_solid([90, 66, 20]); tth_cx_begin(_c); tth_cx_arc(_c, _cx, _cy, 3.2, 0, pi * 2); tth_cx_fill(_c);
            _c.fill = tth_cx_solid([217, 182, 102]); tth_cx_begin(_c); tth_cx_arc(_c, _cx, _cy, 2.4, 0, pi * 2); tth_cx_fill(_c);
            _c.fill = tth_cx_solid([251, 238, 192]); tth_cx_begin(_c); tth_cx_arc(_c, _cx - 0.7, _cy - 0.8, 0.9, 0, pi * 2); tth_cx_fill(_c);
        }
        else if (_f == "laurel" && _k mod 2 == 0) {
            _c.fill = tth_cx_solid([125, 143, 60]); tth_cx_save(_c); tth_cx_translate(_c, _cx, _cy); tth_cx_rotate(_c, _a + pi / 2);
            tth_cx_begin(_c); tth_cx_ellipse(_c, 0, 0, 3.9, 1.8, 0.5, 0, pi * 2); tth_cx_fill(_c); tth_cx_restore(_c);
        }
    }
    tth_cx_restore(_c);
}
