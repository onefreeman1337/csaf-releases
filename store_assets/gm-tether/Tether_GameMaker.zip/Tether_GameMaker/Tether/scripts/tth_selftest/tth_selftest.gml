/// tth_selftest.gml - the in-engine suite (`Tether.exe -selftest` writes tth_selftest.json). Stage 99 = the suite reached
/// its end. Not needed at runtime: delete it with the -selftest branch of the demo object's Create event.
///
/// Tether - Every Bond Drawn as a Cord, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// FIRST CUT (2026-10-03): the contact sheet of every material x tier, the strain states, the knots and the medallion
/// frames, saved for LOOKING (the suite cannot judge a picture), plus ink per cell against a blank control. The oracle
/// arms (a counting stub context over the MZ painter) come next; see Internal_Ops/PORT_PLAN.md.

function tth_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 80) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
function tth_st_stage(_st, _n) { _st.stage = _n; global.tth_stage = _n; }

/// @function tth_st_ink(grab, x0, y0, x1, y1, ground)
/// @description Pixels in a rect that differ from the ground colour by more than 30 summed (bytes R, G, B, A).
function tth_st_ink(_g, _x0, _y0, _x1, _y1, _gr) {
    var _n = 0;
    for (var _y = max(0, floor(_y0)); _y < min(_g.h, _y1); _y++) for (var _x = max(0, floor(_x0)); _x < min(_g.w, _x1); _x++) {
        var _o = (_y * _g.w + _x) * 4;
        if (abs(buffer_peek(_g.b, _o, buffer_u8) - _gr[0]) + abs(buffer_peek(_g.b, _o + 1, buffer_u8) - _gr[1]) + abs(buffer_peek(_g.b, _o + 2, buffer_u8) - _gr[2]) > 30) _n++;
    }
    return _n;
}

/// @function tth_selftest_run()
function tth_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, stage: 0, notes: [], failures: [], metrics: {} };
    var _gr = [44, 33, 54];   // the original's velvet mid tone
    var _mats = tth_materials(), _ink = tth_ink();
    var _cw = 160, _ch = 96, _cols = 8, _rows = 6;
    var _W = _cw * _cols, _H = _ch * _rows;
    tth_st_stage(_st, 1);
    var _sf = surface_create(_W * 2, _H * 2);
    surface_set_target(_sf);
    draw_clear(make_colour_rgb(_gr[0], _gr[1], _gr[2]));
    gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha); gpu_set_ztestenable(false);
    var _c = tth_cx_create(2);
    var _cells = [];
    for (var _m = 0; _m < 5; _m++) {
        for (var _col = 0; _col < _cols; _col++) {
            var _x = _col * _cw, _y = _m * _ch;
            var _bond = { material: _mats[_m], tier: min(5, _col), strained: (_col == 6), knots: (_col == 7) ? [{ t: 0.5, label: "" }] : [], key: _mats[_m] + string(_col) };
            if (_col >= 6) _bond.tier = 3;
            var _bow = (_col == 7) ? -12 : 10;
            var _res = tth_draw_bond(_c, _bond, { x: _x + 16, y: _y + _ch * 0.55, r: 0 }, { x: _x + _cw - 16, y: _y + _ch * 0.55, r: 0 }, _bow);
            array_push(_cells, [_x, _y, _mats[_m] + " t" + string(_bond.tier) + ((_col == 6) ? " strained" : ((_col == 7) ? " knot" : ""))]);
        }
    }
    var _forms = tth_frames();
    for (var _f = 0; _f < 4; _f++) for (var _rg = 1; _rg <= 2; _rg++) {
        var _i = _f * 2 + (_rg - 1);
        var _mx = _i * _cw + _cw / 2, _my = 5 * _ch + _ch / 2;
        tth_draw_medallion(_c, _mx, _my, 26, _forms[_f], (_rg == 1) ? 1 : 3);
        array_push(_cells, [_i * _cw, 5 * _ch, _forms[_f] + " x" + string((_rg == 1) ? 1 : 3)]);
    }
    gpu_pop_state();
    surface_reset_target();
    // labels at 2x in the interface face, then the sheet saved
    surface_set_target(_sf);
    for (var _k = 0; _k < array_length(_cells); _k++) tth_text(_cells[_k][0] * 2 + 8, _cells[_k][1] * 2 + 6, _cells[_k][2], 22, make_colour_rgb(220, 205, 170), fa_left, fa_top, fnt_tether_ui);
    surface_reset_target();
    var _g = { w: _W * 2, h: _H * 2, b: buffer_create(_W * 2 * _H * 2 * 4, buffer_fixed, 1) };
    buffer_get_surface(_g.b, _sf, 0);
    var _thin = 0;
    for (var _m2 = 0; _m2 < 5; _m2++) for (var _col2 = 0; _col2 < _cols; _col2++) {
        var _n = tth_st_ink(_g, _col2 * _cw * 2, (_m2 * _ch + 30) * 2, (_col2 + 1) * _cw * 2, (_m2 + 1) * _ch * 2, _gr);
        if (_n < 400) { _thin++; array_push(_st.notes, "thin cell " + _mats[_m2] + " col " + string(_col2) + ": " + string(_n)); }
    }
    tth_st_assert(_st, _thin == 0, string(_thin) + " cord cells drew under 400 ink pixels");
    _st.metrics.ops = _c.counts;
    surface_save(_sf, "tth_render_contact.png");
    buffer_delete(_g.b);
    surface_free(_sf);
    // ---- 2: a whole chart page - twelve members on a ring, nineteen bonds, knots with labels, the summary ledger ----
    tth_st_stage(_st, 2);
    var _PW = 1280, _PH = 720;
    var _L = tth_page_layout(_PW, _PH);
    var _cast = [["aldric", "Aldric", 210, "studded"], ["aurelian", "Aurelian", 45, "laurel"], ["hild", "Hild", 120, "beaded"], ["brannoc", "Brannoc", 15, "plain"],
        ["lorcan", "Lorcan", 280, "beaded"], ["wren", "Wren", 95, "laurel"], ["corvin", "Corvin", 300, "studded"], ["elowen", "Elowen", 160, "laurel"],
        ["oswin", "Oswin", 30, "plain"], ["seraphine", "Seraphine", 250, "beaded"], ["morwen", "Morwen", 330, "studded"], ["isolde", "Isolde", 190, "plain"]];
    var _bonds = [["aldric", "isolde", "love", 4, false, "Mother's Letter"], ["aldric", "aurelian", "oath", 5, true, "Sworn at Dawn"], ["hild", "brannoc", "friendship", 3, false, ""],
        ["lorcan", "wren", "love", 3, false, "A Song for Wren"], ["wren", "corvin", "friendship", 4, false, "Back to Back"], ["corvin", "elowen", "love", 2, true, "The Stolen Ring"],
        ["elowen", "aurelian", "family", 5, false, "Her Coronation"], ["oswin", "seraphine", "friendship", 2, true, ""], ["seraphine", "morwen", "rivalry", 4, false, ""],
        ["morwen", "isolde", "family", 3, false, ""], ["aldric", "hild", "friendship", 3, false, "The Siege of Harrowgate"], ["brannoc", "lorcan", "oath", 2, false, ""],
        ["oswin", "aurelian", "oath", 3, false, "The Duel at Fenmoor"], ["isolde", "seraphine", "friendship", 1, false, ""], ["morwen", "corvin", "rivalry", 2, false, ""],
        ["hild", "elowen", "friendship", 2, false, ""], ["brannoc", "wren", "friendship", 4, false, ""], ["aurelian", "seraphine", "rivalry", 1, false, ""], ["lorcan", "oswin", "family", 2, false, ""]];
    var _slots = {}, _members = [], _discs = [], _rr = 30;
    for (var _ci = 0; _ci < array_length(_cast); _ci++) {
        var _ang = _ci / array_length(_cast) * pi * 2 - pi / 2;
        var _sx = _L.cx + cos(_ang) * _L.radius, _sy = _L.cy + sin(_ang) * _L.radius;
        _slots[$ _cast[_ci][0]] = { x: _sx, y: _sy, r: _rr + 9 };
        array_push(_discs, { x: _sx, y: _sy, R: tth_outer_radius(_rr, 2) });
    }
    var _blist = [];
    for (var _bi = 0; _bi < array_length(_bonds); _bi++) {
        var _bd = _bonds[_bi];
        array_push(_blist, { a: _bd[0], b: _bd[1], kind: _bd[2], material: tth_material_of(_bd[2]), tier: _bd[3], strained: _bd[4], knots: (_bd[5] != "") ? [{ t: 0.42, label: _bd[5] }] : [], key: _bd[0] + "|" + _bd[1] });
    }
    var _pg = surface_create(_PW * 2, _PH * 2);
    surface_set_target(_pg); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha); gpu_set_ztestenable(false); gpu_set_texfilter(true);
    var _pc = tth_cx_create(2);
    tth_draw_ground(_pc, _L, { title: "The Company" });
    var _cr = tth_draw_cords(_pc, _blist, _slots, _L.cx, _L.cy);
    var _names = {};
    for (var _ci2 = 0; _ci2 < array_length(_cast); _ci2++) {
        var _cm = _cast[_ci2], _sl = _slots[$ _cm[0]];
        _names[$ _cm[0]] = _cm[1];
        tth_draw_member(_pc, _sl.x, _sl.y, _rr, { name: _cm[1], initial: string_char_at(_cm[1], 1), classHue: _cm[2], form: _cm[3], rings: 1 + (_ci2 mod 3) }, 120);
    }
    var _placed = tth_place_labels(_pc, _cr.knotLabels, _discs, _L.chart);
    tth_draw_labels(_pc, _placed);
    tth_draw_summary(_pc, _L.ledger, { title: "The Company", castLine: string(array_length(_cast)) + " characters, " + string(array_length(_blist)) + " bonds", bonds: _blist, names: _names, hint: "Choose a face to see their bonds." });
    gpu_pop_state();
    surface_reset_target();
    surface_save(_pg, "tth_render_chart.png");
    var _overl = 0;
    for (var _pi2 = 0; _pi2 < array_length(_placed); _pi2++) if (_placed[_pi2].overlap > 0) _overl++;
    tth_st_assert(_st, _cr.drawn == array_length(_blist), "chart drew " + string(_cr.drawn) + " of " + string(array_length(_blist)) + " cords");
    array_push(_st.notes, "chart: " + string(_cr.drawn) + " cords, " + string(_cr.knots) + " knots, " + string(array_length(_placed)) + " labels (" + string(_overl) + " with any overlap)");
    surface_free(_pg);

    // ---- 3: the same company through the PUBLIC API, one member with a sprite face, summary and focus pages ----
    tth_st_stage(_st, 3);
    var _fs = surface_create(96, 96);
    surface_set_target(_fs); draw_clear(make_colour_rgb(120, 70, 50));
    draw_set_colour(make_colour_rgb(230, 190, 150)); draw_circle(48, 44, 26, false);
    draw_set_colour(make_colour_rgb(60, 40, 30)); draw_circle(38, 40, 4, false); draw_circle(58, 40, 4, false);
    draw_set_colour(make_colour_rgb(80, 50, 30)); draw_rectangle(18, 74, 78, 96, false);
    surface_reset_target();
    var _face = sprite_create_from_surface(_fs, 0, 0, 96, 96, false, false, 0, 0);
    surface_free(_fs);
    var _ch2 = tth_chart_create({ title: "The Company" });
    for (var _q = 0; _q < array_length(_cast); _q++) tth_member(_ch2, _cast[_q][0], _cast[_q][1], { classHue: _cast[_q][2], form: _cast[_q][3], face: (_q == 0) ? _face : undefined, subtitle: "of the Company" });
    for (var _q2 = 0; _q2 < array_length(_bonds); _q2++) {
        var _bq = _bonds[_q2];
        tth_bond(_ch2, _bq[0], _bq[1], [0, 12, 30, 55, 80, 100][_bq[3]] * (_bq[4] ? -1 : 1), { kind: _bq[2] });
        if (_bq[5] != "") tth_knot(_ch2, _bq[0], _bq[1], _bq[5]);
    }
    var _rb = tth_chart_bonds(_ch2);
    tth_st_assert(_st, array_length(_rb) == array_length(_bonds), "resolved " + string(array_length(_rb)) + " bonds");
    var _ap = surface_create(_PW * 2, _PH * 2);
    surface_set_target(_ap); draw_clear_alpha(c_black, 0);
    var _res1 = tth_chart_compose(_ch2, _PW, _PH, undefined, 2);
    surface_reset_target();
    surface_save(_ap, "tth_render_api_summary.png");
    surface_set_target(_ap); draw_clear_alpha(c_black, 0);
    var _res2 = tth_chart_compose(_ch2, _PW, _PH, "aldric", 2);
    surface_reset_target();
    surface_save(_ap, "tth_render_api_focus.png");
    surface_free(_ap);
    // the small page a GIF or a pause menu uses: twelve members at 800 x 450 (the case that overlapped its plates)
    var _apS = surface_create(1600, 900);
    surface_set_target(_apS); draw_clear_alpha(c_black, 0);
    var _resS = tth_chart_compose(_ch2, 800, 450, "morwen", 2);
    surface_reset_target();
    surface_save(_apS, "tth_render_api_small.png");
    surface_free(_apS);
    tth_st_assert(_st, is_struct(_resS) && _resS.cords >= 3, "the 800 x 450 focus page drew");
    tth_st_assert(_st, is_struct(_res1) && _res1.cords == array_length(_bonds), "API summary page drew " + (is_struct(_res1) ? string(_res1.cords) : "nothing"));
    tth_st_assert(_st, is_struct(_res2) && _res2.cords >= 3, "API focus page drew " + (is_struct(_res2) ? string(_res2.cords) : "nothing"));
    array_push(_st.notes, "api: summary " + json_stringify(_res1) + " focus " + json_stringify(_res2));
    // ---- 4: the bake and the cache ----
    tth_st_stage(_st, 4);
    var _grab = function(_spr) {
        var _w = sprite_get_width(_spr), _h = sprite_get_height(_spr), _sf = surface_create(_w, _h);
        surface_set_target(_sf); draw_clear_alpha(c_black, 0); gpu_set_blendenable(false); draw_sprite(_spr, 0, 0, 0); gpu_set_blendenable(true); surface_reset_target();
        var _b = buffer_create(_w * _h * 4, buffer_fixed, 1); buffer_get_surface(_b, _sf, 0); surface_free(_sf);
        return _b;
    };
    var _diffb = function(_a, _b) { var _n = 0; for (var _o = 0; _o < buffer_get_size(_a); _o += 4) if (buffer_peek(_a, _o, buffer_u32) != buffer_peek(_b, _o, buffer_u32)) _n++; return _n; };
    var _tb = get_timer();
    var _s1 = tth_chart_sprite(_ch2, 960, 540);
    _st.metrics.bakeMs960 = (get_timer() - _tb) / 1000;
    var _s1b = tth_chart_sprite(_ch2, 960, 540);
    tth_st_assert(_st, _s1 >= 0 && sprite_exists(_s1) && _s1 == _s1b, "an unchanged chart is not served from the cache");
    var _B1 = _grab(_s1);
    var _opq = 0; for (var _o2 = 3; _o2 < buffer_get_size(_B1); _o2 += 4) if (buffer_peek(_B1, _o2, buffer_u8) > 247) _opq++;
    tth_st_assert(_st, _opq > 960 * 540 * 0.95, "the baked page is not opaque (" + string(_opq) + " of " + string(960 * 540) + ")");
    tth_chart_free();
    var _s2 = tth_chart_sprite(_ch2, 960, 540), _B2 = _grab(_s2);
    var _dd = _diffb(_B1, _B2);
    tth_st_assert(_st, _dd == 0, "the same chart baked twice differs in " + string(_dd) + " pixels");
    tth_knot(_ch2, "hild", "brannoc", "The Long Winter");
    var _s3 = tth_chart_sprite(_ch2, 960, 540);
    tth_st_assert(_st, _s3 != _s2, "a new knot did not re-bake the page");
    var _B3 = _grab(_s3);
    tth_st_assert(_st, _diffb(_B2, _B3) > 200, "a new knot changed too little of the page");
    tth_chart_free();
    matrix_set(matrix_world, matrix_build(0, 0, 0, 0, 0, 0, 2, 2, 1));
    var _s4 = tth_chart_sprite(_ch2, 960, 540);
    var _mm = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_build_identity());
    var _B4 = _grab(_s4);
    tth_st_assert(_st, _diffb(_B3, _B4) == 0 && _mm[0] == 2, "a bake under a caller's 2x matrix differs, or the matrix was not handed back");
    tth_st_assert(_st, tth_chart_sprite(undefined, 960, 540) == -1 && tth_chart_sprite(_ch2, 100, 540) == -1 && !tth_chart_draw(_ch2, "x", 0, 960, 540) && is_undefined(tth_chart_compose({}, 960, 540)), "refusals");
    tth_st_assert(_st, !tth_member(undefined, "a", "A") && !tth_bond(_ch2, "a", "a", 10) && !tth_knot(_ch2, "nobody", "else", "x") && array_length(tth_chart_bonds(undefined)) == 0, "API refusals");
    buffer_delete(_B1); buffer_delete(_B2); buffer_delete(_B3); buffer_delete(_B4);
    tth_chart_free();
    sprite_delete(_face);

    // ---- 5: held to the original - every cord case and every medallion draws EXACTLY the MZ painter's operations ----
    tth_st_stage(_st, 5);
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _sc = surface_create(400, 160);
    surface_set_target(_sc);
    gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    var _OC = tth_oracle_cords(), _bad = 0, _ops = 0;
    for (var _oi = 0; _oi < array_length(_OC); _oi++) {
        var _e = _OC[_oi], _cx = tth_cx_create(1);
        tth_draw_bond(_cx, { material: _e.material, tier: _e.tier, strained: _e.strained, knots: _e.knots, key: _e.key }, { x: _e.ax, y: _e.ay, r: 0 }, { x: _e.bx, y: _e.by, r: 0 }, _e.bow);
        var _n = _cx.counts;
        _ops += _n.path + _n.fill + _n.stroke + _n.rect;
        if (_n.path != _e.n.path || _n.fill != _e.n.fill || _n.stroke != _e.n.stroke || _n.rect != _e.n.rect) {
            _bad++;
            if (_bad <= 6) array_push(_st.notes, "cord " + _e.material + " t" + string(_e.tier) + (_e.strained ? " strained" : "") + " knots " + string(array_length(_e.knots)) + " bow " + string(_e.bow) + ": " + string(_n.path) + "/" + string(_n.fill) + "/" + string(_n.stroke) + "/" + string(_n.rect) + " vs original " + string(_e.n.path) + "/" + string(_e.n.fill) + "/" + string(_e.n.stroke) + "/" + string(_e.n.rect));
        }
    }
    var _OM = tth_oracle_medallions(), _badm = 0;
    for (var _mi = 0; _mi < array_length(_OM); _mi++) {
        var _me = _OM[_mi], _cm = tth_cx_create(1);
        tth_draw_medallion(_cm, 100, 80, _me.r, _me.form, _me.rings);
        var _nm2 = _cm.counts;
        _ops += _nm2.path + _nm2.fill + _nm2.stroke + _nm2.rect;
        if (_nm2.path != _me.n.path || _nm2.fill != _me.n.fill || _nm2.stroke != _me.n.stroke || _nm2.rect != _me.n.rect) { _badm++; if (_badm <= 3) array_push(_st.notes, "medallion " + _me.form + " x" + string(_me.rings) + " r" + string(_me.r) + ": " + string(_nm2.path) + "/" + string(_nm2.fill) + "/" + string(_nm2.stroke) + " vs original " + string(_me.n.path) + "/" + string(_me.n.fill) + "/" + string(_me.n.stroke)); }
    }
    gpu_pop_state();
    surface_reset_target();
    surface_free(_sc);
    math_set_epsilon(_eps);
    tth_st_assert(_st, _bad == 0, string(_bad) + " of " + string(array_length(_OC)) + " cord cases differ from the original's operation counts");
    tth_st_assert(_st, _badm == 0, string(_badm) + " of " + string(array_length(_OM)) + " medallions differ from the original");
    _st.metrics.oracleOps = _ops;
    array_push(_st.notes, "oracle: " + string(array_length(_OC)) + " cords + " + string(array_length(_OM)) + " medallions, " + string(_ops) + " ops; bad " + string(_bad) + " / " + string(_badm));

    tth_st_stage(_st, 99);
    return _st;
}

/// @function tth_selftest_write(st)
function tth_selftest_write(_st) {
    var _f = file_text_open_write("tth_selftest.json");
    file_text_write_string(_f, json_stringify(_st));
    file_text_close(_f);
}
