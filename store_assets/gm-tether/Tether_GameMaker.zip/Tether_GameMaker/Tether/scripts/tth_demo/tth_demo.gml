/// tth_demo.gml - the demo room's logic: a company of twelve on a chart page. Arrows focus each character in turn (their
/// ledger), Space returns to the summary, K ties a knot on the focused character's strongest bond, S strains or mends it.
/// Not needed at runtime: delete it with obj_tth_demo and rm_tth_demo.
///
/// Tether - Every Bond Drawn as a Cord, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// Read this file as the quickstart: tth_chart_create() once, tth_member() per character, tth_bond() whenever your
/// relationship system changes a value, tth_knot() for the events that changed it, tth_chart_draw() to show the page,
/// tth_chart_free() in Clean Up.

/// @function tth_demo_state()
function tth_demo_state() {
    var _c = tth_chart_create({ title: "The Company", kindNames: { love: "Love", friendship: "Friendship", oath: "Oath", rivalry: "Rivalry", family: "Family" } });
    var _cast = [["aldric", "Aldric", 210, "studded", "the knight"], ["aurelian", "Aurelian", 45, "laurel", "the old king"], ["hild", "Hild", 120, "beaded", "the scout"],
        ["brannoc", "Brannoc", 15, "plain", "the smith"], ["lorcan", "Lorcan", 280, "beaded", "the bard"], ["wren", "Wren", 95, "laurel", "the thief"],
        ["corvin", "Corvin", 300, "studded", "the rogue"], ["elowen", "Elowen", 160, "laurel", "the queen"], ["oswin", "Oswin", 30, "plain", "the monk"],
        ["seraphine", "Seraphine", 250, "beaded", "the mage"], ["morwen", "Morwen", 330, "studded", "the witch"], ["isolde", "Isolde", 190, "plain", "the healer"]];
    var _ids = [];
    for (var _i = 0; _i < array_length(_cast); _i++) { tth_member(_c, _cast[_i][0], _cast[_i][1], { classHue: _cast[_i][2], form: _cast[_i][3], subtitle: _cast[_i][4] }); array_push(_ids, _cast[_i][0]); }
    var _b = [["aldric", "isolde", "love", 80, "Mother's Letter"], ["aldric", "aurelian", "oath", -100, "Sworn at Dawn"], ["hild", "brannoc", "friendship", 55, ""],
        ["lorcan", "wren", "love", 55, "A Song for Wren"], ["wren", "corvin", "friendship", 80, "Back to Back"], ["corvin", "elowen", "love", -30, "The Stolen Ring"],
        ["elowen", "aurelian", "family", 100, "Her Coronation"], ["oswin", "seraphine", "friendship", -30, ""], ["seraphine", "morwen", "rivalry", -80, ""],
        ["morwen", "isolde", "family", 55, ""], ["aldric", "hild", "friendship", 55, "The Siege of Harrowgate"], ["brannoc", "lorcan", "oath", 30, ""],
        ["oswin", "aurelian", "oath", 55, "The Duel at Fenmoor"], ["isolde", "seraphine", "friendship", 12, ""], ["morwen", "corvin", "rivalry", -30, ""],
        ["hild", "elowen", "friendship", 30, ""], ["brannoc", "wren", "friendship", 80, ""], ["aurelian", "seraphine", "rivalry", -12, ""], ["lorcan", "oswin", "family", 30, ""]];
    for (var _j = 0; _j < array_length(_b); _j++) {
        tth_bond(_c, _b[_j][0], _b[_j][1], _b[_j][3], { kind: _b[_j][2] });
        if (_b[_j][4] != "") tth_knot(_c, _b[_j][0], _b[_j][1], _b[_j][4]);
    }
    return { chart: _c, ids: _ids, focus: -1, events: ["The Long Winter", "A Debt Repaid", "The Broken Vow", "Midsummer Fair", "The Ambush", "A Secret Kept"], next: 0,
        note: "Arrows: focus a character   Space: the whole company   K: tie a knot   S: strain or mend" };
}

/// @function tth_demo_strongest(d)
/// @description The focused character's heaviest bond, or undefined.
function tth_demo_strongest(_d) {
    if (_d.focus < 0) return undefined;
    var _id = _d.ids[_d.focus], _bs = tth_chart_bonds(_d.chart), _best = undefined;
    for (var _i = 0; _i < array_length(_bs); _i++) if ((_bs[_i].a == _id || _bs[_i].b == _id) && (is_undefined(_best) || _bs[_i].tier > _best.tier)) _best = _bs[_i];
    return _best;
}

/// @function tth_demo_step(d)
function tth_demo_step(_d) {
    var _n = array_length(_d.ids);
    if (keyboard_check_pressed(vk_right) || keyboard_check_pressed(vk_down)) _d.focus = (_d.focus + 1) mod _n;
    if (keyboard_check_pressed(vk_left) || keyboard_check_pressed(vk_up)) _d.focus = (_d.focus <= 0) ? _n - 1 : _d.focus - 1;
    if (keyboard_check_pressed(vk_space)) _d.focus = -1;
    var _b = tth_demo_strongest(_d);
    if (!is_undefined(_b) && keyboard_check_pressed(ord("K"))) {
        var _ev = _d.events[_d.next mod array_length(_d.events)];
        _d.next += 1;
        tth_knot(_d.chart, _b.a, _b.b, _ev);
        _d.note = "Knot tied on " + _b.a + " & " + _b.b + ": " + _ev;
    }
    if (!is_undefined(_b) && keyboard_check_pressed(ord("S"))) {
        tth_bond(_d.chart, _b.a, _b.b, -_b.value, { kind: _b.kind });
        _d.note = (_b.value > 0) ? "Strained: the cord frays, the chain link opens, the wire snaps." : "Mended.";
    }
}

/// @function tth_demo_draw(d)
function tth_demo_draw(_d) {
    draw_clear(make_colour_rgb(12, 9, 15));
    var _w = display_get_gui_width(), _h = display_get_gui_height();
    tth_chart_draw(_d.chart, 0, 0, _w, _h - 28, (_d.focus >= 0) ? _d.ids[_d.focus] : undefined);
    tth_text(16, _h - 24, _d.note, 17, make_colour_rgb(220, 205, 170), fa_left, fa_top, fnt_tether_ui);
}
