{
  "$GMScript": "v1",
  "%Name": "tth_canvas",
  "name": "tth_canvas",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}