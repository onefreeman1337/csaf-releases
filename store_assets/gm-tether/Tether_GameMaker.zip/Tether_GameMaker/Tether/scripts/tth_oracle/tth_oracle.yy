{
  "$GMScript": "v1",
  "%Name": "tth_oracle",
  "name": "tth_oracle",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}