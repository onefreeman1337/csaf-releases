/// tth_bake.gml - the chart page as a sprite: baked once at 2x and filtered down, cached by the chart's own version, the
/// size and the focus, so a chart that has not changed costs one sprite draw a frame.
///
/// Tether - Every Bond Drawn as a Cord, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
///   tth_chart_sprite(chart, w, h, [focus])           -> a cached sprite of the page (premultiplied), or -1
///   tth_chart_draw(chart, x, y, w, h, [focus], [a])  -> draw it (bakes on first use and after any change)
///   tth_chart_free()                                 -> free every cached chart sprite

/// @function tth__next_uid()
/// @description A per-run counter so two charts never share a cache key. Internal.
function tth__next_uid() {
    if (!variable_global_exists("tth__uid")) global.tth__uid = 0;
    global.tth__uid += 1;
    return global.tth__uid;
}

/// @function tth__cache()
function tth__cache() {
    if (!variable_global_exists("tth__chart_cache") || !is_struct(global.tth__chart_cache)) global.tth__chart_cache = { map: {}, order: [], limit: 16 };
    return global.tth__chart_cache;
}

/// @function tth_chart_sprite(chart, w, h, [focus])
/// @description The page as a sprite w x h (origin top-left), baked at 2x and filtered down, cached until the chart
/// changes. ⚠️ PREMULTIPLIED: tth_chart_draw draws it correctly; to draw it yourself use
/// gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha). Bake outside a hot path - a chart is thousands of marks. -1 for a
/// bad chart or a size outside 320..2048 x 240..2048. Do not delete it yourself; call tth_chart_free().
function tth_chart_sprite(_c, _w, _h, _focus = undefined) {
    if (!tth__valid_chart(_c) || !is_numeric(_w) || !is_numeric(_h) || _w < 320 || _h < 240 || _w > 2048 || _h > 2048) return -1;
    _w = floor(_w); _h = floor(_h);
    var _fk = (is_string(_focus) || is_numeric(_focus)) ? string(_focus) : "";
    var _cache = tth__cache(), _key = string(_c.uid) + "|" + string(_c.version) + "|" + string(_w) + "x" + string(_h) + "|" + _fk;
    var _hit = _cache.map[$ _key];
    if (!is_undefined(_hit) && sprite_exists(_hit)) return _hit;
    // ⛔ a bake inside a draw pass inherits the caller's matrix: identity for every internal pass, handed back after
    var _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_build_identity());
    var _big = surface_create(_w * 2, _h * 2);
    surface_set_target(_big); draw_clear_alpha(c_black, 0);
    tth_chart_compose(_c, _w, _h, (_fk == "") ? undefined : _fk, 2);
    surface_reset_target();
    var _small = surface_create(_w, _h);
    surface_set_target(_small); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_zero); gpu_set_texfilter(true);
    draw_surface_ext(_big, 0, 0, 0.5, 0.5, 0, c_white, 1);
    gpu_pop_state();
    surface_reset_target();
    var _spr = sprite_create_from_surface(_small, 0, 0, _w, _h, false, false, 0, 0);
    surface_free(_big); surface_free(_small);
    matrix_set(matrix_world, _mw);
    _cache.map[$ _key] = _spr;
    array_push(_cache.order, _key);
    // the oldest is freed only AFTER a surface target was set and reset above (that flushes this frame's queued draws;
    // a sprite deleted right after it is drawn draws as a white box)
    while (array_length(_cache.order) > _cache.limit) {
        var _old = _cache.order[0];
        array_delete(_cache.order, 0, 1);
        var _os = _cache.map[$ _old];
        if (!is_undefined(_os) && sprite_exists(_os)) sprite_delete(_os);
        variable_struct_remove(_cache.map, _old);
    }
    return _spr;
}

/// @function tth_chart_draw(chart, x, y, w, h, [focus], [alpha])
/// @description Draw the chart page with its top-left at (x, y). Returns true when something was drawn.
function tth_chart_draw(_c, _x, _y, _w, _h, _focus = undefined, _alpha = 1) {
    if (!is_numeric(_x) || !is_numeric(_y)) return false;
    var _spr = tth_chart_sprite(_c, _w, _h, _focus);
    if (_spr < 0) return false;
    _alpha = is_numeric(_alpha) ? clamp(_alpha, 0, 1) : 1;
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); gpu_set_texfilter(true);
    var _k = round(255 * _alpha);
    draw_sprite_ext(_spr, 0, _x, _y, 1, 1, 0, make_colour_rgb(_k, _k, _k), _alpha);
    gpu_pop_state();
    return true;
}

/// @function tth_chart_free()
/// @description Free every cached chart sprite (Clean Up, or when the page closes for good).
function tth_chart_free() {
    var _c = tth__cache();
    for (var _i = 0; _i < array_length(_c.order); _i++) { var _s = _c.map[$ _c.order[_i]]; if (!is_undefined(_s) && sprite_exists(_s)) sprite_delete(_s); }
    _c.map = {};
    _c.order = [];
}
