/// tth_chart.gml - the chart page: a velvet ground under a gilt double rule, the brass title plate, the ring of
/// medallions (each the buyer's own face sprite clipped to the round, or a monogram struck on the character's class hue),
/// the cords between them heaviest-last, every knot's words placed clear of every frame, a key of the five cords, and the
/// ledger - a summary of every kind, or one character's bonds as swatches of their own cord with pips and knots.
///
/// Tether - Every Bond Drawn as a Cord, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ A PORT HELD TO ITS ORIGINAL (TetherRender.js, the chart page), line for line. Type is set in the product's own
/// atlases: the display face (Marcellus SC, as "Tether Display") and the italic label face (Sorts Mill Goudy, as
/// "Tether Label"). Every size is a canvas pixel size at the context's user scale.

#macro TTH_FACE_DISPLAY 0
#macro TTH_FACE_LABEL 1

/// @function tth_gilt()
function tth_gilt() { return { base: [201, 164, 90], dark: [107, 82, 32], light: [242, 220, 156] }; }

/// @function tth_kind_order()
/// @description The five kinds in the original's order.
function tth_kind_order() { return ["love", "friendship", "oath", "rivalry", "family"]; }

/// @function tth_material_of(kind)
/// @description The cord a kind of bond is drawn in: love silk, friendship rope, oath chain, rivalry wire, family ribbon.
function tth_material_of(_k) {
    switch (_k) { case "love": return "silk"; case "friendship": return "rope"; case "oath": return "chain"; case "rivalry": return "wire"; case "family": return "ribbon"; }
    return "rope";
}

// ---------------------------------------------------------------------------------------------------------------
// Type at a user-space point
// ---------------------------------------------------------------------------------------------------------------

/// @function tth__font(face, devpx)
function tth__font(_face, _dpx) { return (_face == TTH_FACE_LABEL) ? tth_font_label(_dpx) : tth_font_for(_dpx); }

/// @function tth__measure(ctx, s, px, face)
/// @description A string's width in user pixels, measured from the atlas it will be drawn from.
function tth__measure(_c, _s, _px, _face) {
    var _k = tth_cx__scale(_c), _font = tth__font(_face, _px * _k);
    var _pf = draw_get_font(); draw_set_font(_font);
    var _w = string_width(string(_s)) * _px / tth_font_px(_font);
    draw_set_font(_pf);
    return _w;
}

/// @function tth__text(ctx, s, x, y, px, face, rgb, alpha, halign, baseline, [maxw])
/// @description Type at a user point under the context's transform. halign: fa_left / fa_center / fa_right; baseline:
/// "alphabetic", "middle" or "top" (the canvas meanings). maxw condenses the line to fit, as canvas fillText does.
function tth__text(_c, _s, _x, _y, _px, _face, _rgb, _alpha, _ha, _base, _maxw = undefined) {
    _s = string(_s);
    if (string_length(_s) == 0 || !(_alpha > 0)) return 0;
    var _k = tth_cx__scale(_c), _font = tth__font(_face, _px * _k), _em = tth_font_px(_font), _sc = _px / _em;
    var _pf = draw_get_font(); draw_set_font(_font);
    var _w = string_width(_s) * _sc, _sx = 1;
    if (is_numeric(_maxw) && _maxw > 0 && _w > _maxw) _sx = _maxw / _w;
    var _x0 = _x;
    if (_ha == fa_center) _x0 = _x - _w * _sx / 2; else if (_ha == fa_right) _x0 = _x - _w * _sx;
    var _top = _y;
    if (_base == "alphabetic") _top = _y - tth_font_ascent(_font) * _sc;
    else if (_base == "middle") _top = _y - (tth_font_ascent(_font) * 0.62) * _sc;
    var _p = tth_cx__pt(_c, _x0, _top);
    draw_set_halign(fa_left); draw_set_valign(fa_top); draw_set_colour(tth_col(_rgb)); draw_set_alpha(_alpha * _c.alpha);
    draw_text_transformed(_p[0], _p[1], _s, _sc * _sx * _k, _sc * _k, 0);
    draw_set_font(_pf);
    return _w * _sx;
}

/// @function tth__hsl(h, s, l)
/// @description An [r, g, b] colour from CSS hsl (h degrees, s and l 0..100). Pure.
function tth__hsl(_h, _s, _l) {
    _h = ((_h mod 360) + 360) mod 360; _s /= 100; _l /= 100;
    var _c = (1 - abs(2 * _l - 1)) * _s, _x = _c * (1 - abs(((_h / 60) mod 2) - 1)), _m = _l - _c / 2, _r = 0, _g = 0, _b = 0;
    if (_h < 60) { _r = _c; _g = _x; } else if (_h < 120) { _r = _x; _g = _c; } else if (_h < 180) { _g = _c; _b = _x; }
    else if (_h < 240) { _g = _x; _b = _c; } else if (_h < 300) { _r = _x; _b = _c; } else { _r = _c; _b = _x; }
    return [(_r + _m) * 255, (_g + _m) * 255, (_b + _m) * 255];
}

// ---------------------------------------------------------------------------------------------------------------
// The page
// ---------------------------------------------------------------------------------------------------------------

/// @function tth_page_layout(W, H)
/// @description The column split: the ring on the left, the ledger on the right. Derived from the page, never typed per
/// size. Returns {W, H, pad, chart, cx, cy, radius, ledger, title, legend, close}.
function tth_page_layout(_W, _H) {
    var _pad = 14, _lw = tth_jsround(_W * 0.285), _top = 58, _foot = 54;
    var _chart = { x: _pad, y: _top, w: _W - _lw - _pad * 2, h: _H - _top - _foot };
    return {
        W: _W, H: _H, pad: _pad, chart: _chart, cx: _chart.x + _chart.w / 2, cy: _chart.y + _chart.h / 2,
        radius: min(_chart.w / 2 - 58, _chart.h / 2 - 50),
        ledger: { x: _W - _lw - _pad, y: _pad + 4, w: _lw, h: _H - _pad * 2 - 8 },
        title: { x: _chart.x + _chart.w / 2, y: 34 },
        legend: { x: _chart.x, y: _H - _foot + 4, w: _chart.w, h: _foot - 14 },
        close: { x: _W - _pad - 30, y: _pad + 8, w: 24, h: 24 }
    };
}

/// @function tth_velvet(ctx, W, H)
/// @description The velvet ground alone: a radial ramp from plum to near-black and a fine diagonal weave.
function tth_velvet(_c, _W, _H) {
    var _g = tth_cx_radial(_c, _W / 2, _H / 2, 40, _W / 2, _H / 2, max(_W, _H) * 0.72);
    tth_cx_stop(_g, 0, [44, 33, 54]); tth_cx_stop(_g, 1, [17, 12, 22]);
    _c.fill = _g;
    // the rectangle as a many-pointed ring, so the radial mesh has spokes enough to stay round
    tth_cx_begin(_c);
    var _n = 24;
    for (var _e = 0; _e < 4; _e++) for (var _i = 0; _i < _n; _i++) {
        var _t = _i / _n, _x, _y;
        if (_e == 0) { _x = _W * _t; _y = 0; } else if (_e == 1) { _x = _W; _y = _H * _t; } else if (_e == 2) { _x = _W * (1 - _t); _y = _H; } else { _x = 0; _y = _H * (1 - _t); }
        if (_e == 0 && _i == 0) tth_cx_move(_c, _x, _y); else tth_cx_line(_c, _x, _y);
    }
    tth_cx_close(_c);
    tth_cx_fill(_c);
    tth_cx_save(_c); _c.stroke = tth_cx_solid([255, 255, 255]); _c.lw = 1; _c.alpha = 0.028; tth_cx_begin(_c);
    for (var _d = -_H; _d < _W; _d += 3) { tth_cx_move(_c, _d, 0); tth_cx_line(_c, _d + _H, _H); }
    tth_cx_stroke(_c); tth_cx_restore(_c);
}

/// @function tth_gilt_rule(ctx, x, y, w, h)
/// @description A gilt double rule with lozenge fleurons at the corners.
function tth_gilt_rule(_c, _x, _y, _w, _h) {
    var _G = tth_gilt();
    tth_cx_save(_c);
    _c.stroke = tth_cx_solid(_G.dark); _c.lw = 3; tth_cx_stroke_rect(_c, _x + 0.5, _y + 0.5, _w - 1, _h - 1);
    _c.stroke = tth_cx_solid(_G.base); _c.lw = 1.4; tth_cx_stroke_rect(_c, _x + 0.5, _y + 0.5, _w - 1, _h - 1);
    _c.alpha = 0.55; _c.lw = 1; tth_cx_stroke_rect(_c, _x + 5.5, _y + 5.5, _w - 11, _h - 11);
    _c.alpha = 1;
    var _cs = [[_x, _y], [_x + _w, _y], [_x, _y + _h], [_x + _w, _y + _h]];
    for (var _i = 0; _i < 4; _i++) {
        var _cx = _cs[_i][0], _cy = _cs[_i][1];
        _c.fill = tth_cx_solid(_G.dark); tth_cx_begin(_c); tth_cx_move(_c, _cx, _cy - 9); tth_cx_line(_c, _cx + 9, _cy); tth_cx_line(_c, _cx, _cy + 9); tth_cx_line(_c, _cx - 9, _cy); tth_cx_close(_c); tth_cx_fill(_c);
        _c.fill = tth_cx_solid(_G.base); tth_cx_begin(_c); tth_cx_move(_c, _cx, _cy - 6.5); tth_cx_line(_c, _cx + 6.5, _cy); tth_cx_line(_c, _cx, _cy + 6.5); tth_cx_line(_c, _cx - 6.5, _cy); tth_cx_close(_c); tth_cx_fill(_c);
        _c.fill = tth_cx_solid(_G.light); tth_cx_begin(_c); tth_cx_arc(_c, _cx, _cy, 2, 0, pi * 2); tth_cx_fill(_c);
    }
    tth_cx_restore(_c);
}

/// @function tth_title_plate(ctx, x, y, text)
/// @description A brass plate sized to its words, two rivets, the title struck in relief.
function tth_title_plate(_c, _x, _y, _text) {
    tth_cx_save(_c);
    var _tw = tth__measure(_c, _text, 26, TTH_FACE_DISPLAY), _w = max(160, _tw + 70), _h = 38;
    _c.fill = tth_cx_solid([0, 0, 0], 0.45); tth__rounded(_c, _x - _w / 2 + 2, _y - _h / 2 + 3, _w, _h, 6); tth_cx_fill(_c);
    var _g = tth_cx_linear(_c, 0, _y - _h / 2, 0, _y + _h / 2);
    tth_cx_stop(_g, 0, [230, 201, 131]); tth_cx_stop(_g, 0.5, [184, 143, 69]); tth_cx_stop(_g, 1, [124, 91, 34]);
    _c.fill = _g; tth__rounded(_c, _x - _w / 2, _y - _h / 2, _w, _h, 6); tth_cx_fill(_c);
    _c.stroke = tth_cx_solid([74, 52, 16]); _c.lw = 1.5; tth__rounded(_c, _x - _w / 2, _y - _h / 2, _w, _h, 6); tth_cx_stroke(_c);
    for (var _s = -1; _s <= 1; _s += 2) {
        _c.fill = tth_cx_solid([90, 66, 20]); tth_cx_begin(_c); tth_cx_arc(_c, _x + _s * (_w / 2 - 12), _y, 3, 0, pi * 2); tth_cx_fill(_c);
        _c.fill = tth_cx_solid([245, 226, 174]); tth_cx_begin(_c); tth_cx_arc(_c, _x + _s * (_w / 2 - 12) - 0.8, _y - 0.8, 1.1, 0, pi * 2); tth_cx_fill(_c);
    }
    tth__text(_c, _text, _x, _y + 2, 26, TTH_FACE_DISPLAY, [247, 232, 192], 1, fa_center, "middle");
    tth__text(_c, _text, _x, _y + 1, 26, TTH_FACE_DISPLAY, [43, 29, 8], 1, fa_center, "middle");
    tth_cx_restore(_c);
}

/// @function tth_draw_key(ctx, r, names)
/// @description The key: a short length of each cord with the buyer's own word for the kind beneath it.
function tth_draw_key(_c, _r, _names) {
    var _ko = tth_kind_order(), _n = array_length(_ko), _cell = _r.w / _n;
    tth_cx_save(_c);
    for (var _i = 0; _i < _n; _i++) {
        var _k = _ko[_i], _x0 = _r.x + _i * _cell + 14, _x1 = _r.x + (_i + 1) * _cell - 14, _y = _r.y + 10;
        tth_draw_bond(_c, { material: tth_material_of(_k), tier: 3, strained: false, knots: [], key: "key-" + _k }, { x: _x0, y: _y, r: 0 }, { x: _x1, y: _y, r: 0 }, 0);
        var _nm = is_struct(_names) ? _names[$ _k] : undefined;
        tth__text(_c, is_string(_nm) ? _nm : _k, (_x0 + _x1) / 2, _y + 12, 15, TTH_FACE_LABEL, [233, 217, 180], 1, fa_center, "top");
    }
    tth_cx_restore(_c);
}

/// @function tth_draw_ground(ctx, layout, opts)
/// @description Velvet, a woven nap, a gilt double rule with corner fleurons, the ledger's bay, the title plate, the key.
/// opts: {title, kindNames}.
function tth_draw_ground(_c, _L, _o) {
    var _W = _L.W, _H = _L.H, _G = tth_gilt();
    tth_velvet(_c, _W, _H);
    tth_cx_save(_c); _c.stroke = tth_cx_solid([255, 255, 255]); _c.lw = 1; _c.alpha = 0.018; tth_cx_begin(_c);
    for (var _e = 0; _e < _W + _H; _e += 5) { tth_cx_move(_c, _e, 0); tth_cx_line(_c, _e - _H, _H); }
    tth_cx_stroke(_c); tth_cx_restore(_c);
    tth_gilt_rule(_c, 6, 6, _W - 12, _H - 12);
    var _lg = _L.ledger;
    tth_cx_save(_c); _c.fill = tth_cx_solid([8, 5, 11], 0.55); tth__rounded(_c, _lg.x, _lg.y, _lg.w, _lg.h, 10); tth_cx_fill(_c);
    _c.stroke = tth_cx_solid(_G.dark); _c.lw = 1.5; tth__rounded(_c, _lg.x, _lg.y, _lg.w, _lg.h, 10); tth_cx_stroke(_c);
    _c.stroke = tth_cx_solid(_G.base); _c.alpha = 0.6; _c.lw = 1; tth__rounded(_c, _lg.x + 4, _lg.y + 4, _lg.w - 8, _lg.h - 8, 8); tth_cx_stroke(_c);
    tth_cx_restore(_c);
    var _t = is_struct(_o) ? _o[$ "title"] : undefined;
    tth_title_plate(_c, _L.title.x, _L.title.y, is_string(_t) ? _t : "Bonds");
    tth_draw_key(_c, _L.legend, is_struct(_o) ? _o[$ "kindNames"] : undefined);
}

// ---------------------------------------------------------------------------------------------------------------
// Members
// ---------------------------------------------------------------------------------------------------------------

/// @function tth__face(ctx, sprite, x, y, r)
/// @description The buyer's face sprite drawn into the round as a TEXTURED FAN: the round is the clip, exactly, with no
/// stencil and no surface. The sprite is centred and scaled to cover the disc. Returns true when it drew.
function tth__face(_c, _spr, _x, _y, _r) {
    if (!is_numeric(_spr) || !sprite_exists(_spr)) return false;
    var _uv = sprite_get_uvs(_spr, 0), _tex = sprite_get_texture(_spr, 0);
    var _sw = sprite_get_width(_spr), _sh = sprite_get_height(_spr), _side = min(_sw, _sh);
    var _n = 48, _cxs = _sw / 2, _cys = _sh / 2;
    var _p0 = tth_cx__pt(_c, _x, _y);
    draw_primitive_begin_texture(pr_trianglelist, _tex);
    for (var _i = 0; _i < _n; _i++) {
        var _a0 = _i / _n * pi * 2, _a1 = (_i + 1) / _n * pi * 2;
        var _pa = tth_cx__pt(_c, _x + cos(_a0) * _r, _y + sin(_a0) * _r), _pb = tth_cx__pt(_c, _x + cos(_a1) * _r, _y + sin(_a1) * _r);
        var _ua = [_cxs + cos(_a0) * _side / 2, _cys + sin(_a0) * _side / 2], _ub = [_cxs + cos(_a1) * _side / 2, _cys + sin(_a1) * _side / 2];
        draw_vertex_texture_colour(_p0[0], _p0[1], lerp(_uv[0], _uv[2], _cxs / _sw), lerp(_uv[1], _uv[3], _cys / _sh), c_white, _c.alpha);
        draw_vertex_texture_colour(_pa[0], _pa[1], lerp(_uv[0], _uv[2], _ua[0] / _sw), lerp(_uv[1], _uv[3], _ua[1] / _sh), c_white, _c.alpha);
        draw_vertex_texture_colour(_pb[0], _pb[1], lerp(_uv[0], _uv[2], _ub[0] / _sw), lerp(_uv[1], _uv[3], _ub[1] / _sh), c_white, _c.alpha);
    }
    draw_primitive_end();
    return true;
}

/// @function tth_medallion_box(r)
/// @description A member's footprint for a face of radius r (frame, shadow, name plate): {w, h, cx, cy}.
function tth_medallion_box(_r) { var _w = ceil(max(_r * 2 + 40, 148)); return { w: _w, h: ceil(_r * 2 + 48), cx: ceil(_w / 2), cy: ceil(_r + 20) }; }

/// @function tth_name_plate(ctx, x, y, text, maxw)
/// @description A dark pill banner across the frame's foot, the name shrunk to fit (16 px down to 10).
function tth_name_plate(_c, _x, _y, _text, _maxw) {
    var _G = tth_gilt();
    tth_cx_save(_c);
    var _size = 16;
    while (tth__measure(_c, _text, _size, TTH_FACE_DISPLAY) > _maxw - 16 && _size > 10) _size--;
    var _tw = min(_maxw - 16, tth__measure(_c, _text, _size, TTH_FACE_DISPLAY)), _w = _tw + 16, _h = _size + 8;
    _c.fill = tth_cx_solid([10, 6, 14], 0.82); tth__rounded(_c, _x - _w / 2, _y - _h / 2, _w, _h, _h / 2); tth_cx_fill(_c);
    _c.stroke = tth_cx_solid(_G.dark); _c.lw = 1; tth__rounded(_c, _x - _w / 2, _y - _h / 2, _w, _h, _h / 2); tth_cx_stroke(_c);
    tth__text(_c, _text, _x, _y + 1, _size, TTH_FACE_DISPLAY, [240, 223, 182], 1, fa_center, "middle", _maxw - 16);
    tth_cx_restore(_c);
}

/// @function tth_draw_member(ctx, x, y, r, member, boxw)
/// @description One character at (x, y): the face sprite clipped to the round (or a monogram struck on a radial field of
/// the class hue), a glaze, the medallion frame and the name plate. member: {name, initial, classHue, form, rings, face}.
/// Returns {drewFace}.
function tth_draw_member(_c, _x, _y, _r, _m, _boxw) {
    var _G = tth_gilt();
    tth_cx_save(_c);
    var _hue = floor(is_numeric(_m[$ "classHue"]) ? _m.classHue : 0) mod 360;
    var _g = tth_cx_radial(_c, _x - _r * 0.3, _y - _r * 0.4, _r * 0.1, _x, _y, _r);
    tth_cx_stop(_g, 0, tth__hsl(_hue, 32, 42)); tth_cx_stop(_g, 1, tth__hsl(_hue, 38, 16));
    _c.fill = _g; tth_cx_begin(_c); tth_cx_arc(_c, _x, _y, _r, 0, pi * 2); tth_cx_fill(_c);
    var _drew = tth__face(_c, _m[$ "face"], _x, _y, _r);
    if (!_drew) {
        var _ini = is_string(_m[$ "initial"]) ? _m.initial : "?";
        tth__text(_c, _ini, _x + 1.5, _y + 3, tth_jsround(_r * 1.05), TTH_FACE_DISPLAY, [0, 0, 0], 0.5, fa_center, "middle");
        tth__text(_c, _ini, _x, _y + 1.5, tth_jsround(_r * 1.05), TTH_FACE_DISPLAY, _G.light, 1, fa_center, "middle");
    }
    var _gl = tth_cx_radial(_c, _x - _r * 0.45, _y - _r * 0.5, 0, _x, _y, _r * 1.05);
    tth_cx_stop(_gl, 0, [255, 255, 255], 0.10); tth_cx_stop(_gl, 0.7, [0, 0, 0], 0); tth_cx_stop(_gl, 1, [0, 0, 0], 0.45);
    _c.fill = _gl; tth_cx_begin(_c); tth_cx_arc(_c, _x, _y, _r, 0, pi * 2); tth_cx_fill(_c);
    tth_cx_restore(_c);
    tth_draw_medallion(_c, _x, _y, _r, _m[$ "form"], _m[$ "rings"]);
    var _nm = is_string(_m[$ "name"]) ? _m.name : "";
    tth_name_plate(_c, _x, _y + _r + 8, _nm, (is_numeric(_boxw) ? _boxw : tth_medallion_box(_r).w) - 4);
    return { drewFace: _drew };
}

// ---------------------------------------------------------------------------------------------------------------
// Cords, labels, ledger
// ---------------------------------------------------------------------------------------------------------------

/// @function tth_bow_for(A, B, cx, cy)
/// @description Which way a cord bows: its midpoint moves AWAY from the chart centre, so neighbours never overlap.
function tth_bow_for(_A, _B, _cx, _cy) {
    var _dx = _B.x - _A.x, _dy = _B.y - _A.y, _L = sqrt(_dx * _dx + _dy * _dy);
    if (_L == 0) _L = 1;
    var _qx = -_dy / _L, _qy = _dx / _L, _mx = (_A.x + _B.x) / 2 - _cx, _my = (_A.y + _B.y) / 2 - _cy;
    var _mag = min(34, _L * 0.12);
    return (_qx * _mx + _qy * _my >= 0) ? _mag : -_mag;
}

/// @function tth_draw_cords(ctx, bonds, slots, cx, cy, [only])
/// @description Every cord of the chart, HEAVIEST LAST (a weak thread never paints over a chain), and every knot's label
/// collected. slots: struct id -> {x, y, r}. bonds: [{a, b, material, tier, strained, knots, key}]. Returns {drawn,
/// knots, labels, knotLabels}.
function tth_draw_cords(_c, _bonds, _slots, _cx, _cy, _only = undefined) {
    var _list = [];
    for (var _i = 0; _i < array_length(_bonds); _i++) array_push(_list, _bonds[_i]);
    array_sort(_list, function(_p, _q) { if (_p.tier != _q.tier) return (_p.tier < _q.tier) ? -1 : 1; return (_p.key < _q.key) ? -1 : 1; });
    var _labels = [], _drawn = 0, _knots = 0;
    for (var _j = 0; _j < array_length(_list); _j++) {
        var _b = _list[_j], _A = _slots[$ _b.a], _B = _slots[$ _b.b];
        if (is_undefined(_A) || is_undefined(_B)) continue;
        if (!is_undefined(_only) && _b.a != _only && _b.b != _only) continue;
        var _res = tth_draw_bond(_c, _b, _A, _B, tth_bow_for(_A, _B, _cx, _cy));
        _drawn++; _knots += array_length(_res.knotsAt);
        for (var _k = 0; _k < array_length(_res.knotsAt); _k++) {
            var _ka = _res.knotsAt[_k];
            _ka.a = _b.a; _ka.b = _b.b;
            if (_ka.label != "") array_push(_labels, _ka);
        }
    }
    return { drawn: _drawn, knots: _knots, labels: array_length(_labels), knotLabels: _labels };
}

/// @function tth__label_hit(x, y, w, h, discs, placed, bounds)
/// @description How badly a label rectangle (centre x, y) overlaps the frames, the placed labels and the bounds. Internal.
function tth__label_hit(_x, _y, _w, _h, _discs, _placed, _bounds) {
    var _area = 0, _l = _x - _w / 2, _t = _y - _h / 2;
    for (var _d = 0; _d < array_length(_discs); _d++) {
        var _cd = _discs[_d], _nx = max(_l, min(_cd.x, _l + _w)), _ny = max(_t, min(_cd.y, _t + _h));
        var _dd = point_distance(_cd.x, _cd.y, _nx, _ny);
        if (_dd < _cd.R) _area += (_cd.R - _dd) * 40;
    }
    for (var _p = 0; _p < array_length(_placed); _p++) {
        var _q = _placed[_p];
        var _ox = min(_l + _w, _q.x + _q.w / 2) - max(_l, _q.x - _q.w / 2), _oy = min(_t + _h, _q.y + _q.h / 2) - max(_t, _q.y - _q.h / 2);
        if (_ox > -3 && _oy > -3) _area += (_ox + 3) * (_oy + 3);
    }
    if (_l < _bounds.x || _t < _bounds.y || _l + _w > _bounds.x + _bounds.w || _t + _h > _bounds.y + _bounds.h) _area += 5000;
    return _area;
}

/// @function tth_place_labels(ctx, labels, discs, bounds)
/// @description Where each knot's words go: candidate spots round the knot, nearest first, the first clear of every
/// frame, every placed label and the bounds; failing all, the least bad. Deterministic (input order).
function tth_place_labels(_c, _labels, _discs, _bounds) {
    var _placed = [], _H = 20;
    for (var _i = 0; _i < array_length(_labels); _i++) {
        var _lb = _labels[_i], _w = ceil(tth__measure(_c, _lb.label, 14, TTH_FACE_LABEL)) + 14, _best = undefined;
        for (var _ring = 0; _ring < 7 && !(!is_undefined(_best) && _best.area == 0); _ring++) {
            var _dist = 22 + _ring * 14;
            for (var _s = 0; _s < 16; _s++) {
                var _a = _s * pi / 8, _x = _lb.x + cos(_a) * (_dist + _w * 0.35 * abs(cos(_a))), _y = _lb.y + sin(_a) * _dist;
                var _area = tth__label_hit(_x, _y, _w, _H, _discs, _placed, _bounds);
                if (is_undefined(_best) || _area < _best.area) _best = { x: _x, y: _y, area: _area };
                if (_area == 0) break;
            }
        }
        array_push(_placed, { x: tth_jsround(_best.x), y: tth_jsround(_best.y), w: _w, h: _H, label: _lb.label, kx: _lb.x, ky: _lb.y, a: _lb.a, b: _lb.b, overlap: _best.area });
    }
    return _placed;
}

/// @function tth_draw_labels(ctx, placed, [focus])
/// @description Paint placed labels: a gilt hairline back to the knot, a dark pill, the words. A focus dims the rest.
function tth_draw_labels(_c, _placed, _focus = undefined) {
    var _G = tth_gilt();
    tth_cx_save(_c);
    for (var _i = 0; _i < array_length(_placed); _i++) {
        var _p = _placed[_i];
        _c.alpha = (!is_undefined(_focus) && _p.a != _focus && _p.b != _focus) ? 0.3 : 1;
        var _dx = _p.x - _p.kx, _dy = _p.y - _p.ky, _d = sqrt(_dx * _dx + _dy * _dy);
        if (_d == 0) _d = 1;
        var _reach = min(_d, _p.w / 2 * abs(_dx / _d) + _p.h / 2 * abs(_dy / _d));
        _c.stroke = tth_cx_solid(_G.base); _c.lw = 1;
        tth__line(_c, _p.kx, _p.ky, _p.x - _dx / _d * _reach, _p.y - _dy / _d * _reach);
        _c.fill = tth_cx_solid([12, 8, 16], 0.86); tth__rounded(_c, _p.x - _p.w / 2, _p.y - _p.h / 2, _p.w, _p.h, _p.h / 2); tth_cx_fill(_c);
        _c.stroke = tth_cx_solid(_G.dark); tth__rounded(_c, _p.x - _p.w / 2, _p.y - _p.h / 2, _p.w, _p.h, _p.h / 2); tth_cx_stroke(_c);
        tth__text(_c, _p.label, _p.x, _p.y + 1, 14, TTH_FACE_LABEL, [243, 230, 198], 1, fa_center, "middle");
    }
    tth_cx_restore(_c);
    return array_length(_placed);
}

/// @function tth_pips(ctx, x, y, tier, count, rgb)
/// @description Struck lozenges: the tier, filled to its level.
function tth_pips(_c, _x, _y, _tier, _max, _rgb) {
    var _G = tth_gilt();
    for (var _i = 0; _i < _max; _i++) {
        var _px = _x + _i * 11;
        tth_cx_begin(_c); tth_cx_move(_c, _px, _y - 4.5); tth_cx_line(_c, _px + 4.5, _y); tth_cx_line(_c, _px, _y + 4.5); tth_cx_line(_c, _px - 4.5, _y); tth_cx_close(_c);
        if (_i <= _tier) { _c.fill = tth_cx_solid(_rgb); tth_cx_fill(_c); }
        _c.stroke = tth_cx_solid(_G.base); _c.lw = 1; tth_cx_stroke(_c);
    }
}

/// @function tth_draw_focus_ring(ctx, x, y, r)
/// @description A ring of light round the chosen medallion.
function tth_draw_focus_ring(_c, _x, _y, _r) {
    tth_cx_save(_c);
    for (var _i = 0; _i < 6; _i++) { _c.stroke = tth_cx_solid([255, 226, 150], 0.22 - _i * 0.035); _c.lw = 3; tth_cx_begin(_c); tth_cx_arc(_c, _x, _y, _r + 3 + _i * 3, 0, pi * 2); tth_cx_stroke(_c); }
    _c.stroke = tth_cx_solid([255, 231, 163]); _c.lw = 2; tth_cx_begin(_c); tth_cx_arc(_c, _x, _y, _r + 1, 0, pi * 2); tth_cx_stroke(_c);
    tth_cx_restore(_c);
}

/// @function tth_draw_summary(ctx, r, s)
/// @description The ledger before anyone is chosen: the title, a cast line, and every kind counted beside a length of
/// its own cord, its strongest bond named. s: {title, castLine, bonds, names, kindNames, hint, strainedText}.
function tth_draw_summary(_c, _r, _s) {
    var _G = tth_gilt(), _ko = tth_kind_order();
    var _kn = is_struct(_s[$ "kindNames"]) ? _s.kindNames : {}, _bonds = is_array(_s[$ "bonds"]) ? _s.bonds : [], _names = is_struct(_s[$ "names"]) ? _s.names : {};
    tth_cx_save(_c);
    var _x = _r.x + 16, _w = _r.w - 32, _y = _r.y + 40;
    var _title = is_string(_s[$ "title"]) ? _s.title : "", _size = 24;
    while (tth__measure(_c, _title, _size, TTH_FACE_DISPLAY) > _w && _size > 13) _size--;
    tth__text(_c, _title, _x, _y, _size, TTH_FACE_DISPLAY, _G.light, 1, fa_left, "alphabetic");
    tth__text(_c, is_string(_s[$ "castLine"]) ? _s.castLine : "", _x, _y + 20, 15, TTH_FACE_LABEL, [191, 174, 140], 1, fa_left, "alphabetic", _w);
    _c.stroke = tth_cx_solid(_G.base); _c.alpha = 0.7; _c.lw = 1; tth__line(_c, _x, _y + 32, _x + _w, _y + 32); _c.alpha = 1;
    var _cy = _y + 58, _rows = 0;
    for (var _i = 0; _i < array_length(_ko); _i++) {
        var _k = _ko[_i], _n = 0, _best = undefined, _strained = 0;
        for (var _j = 0; _j < array_length(_bonds); _j++) if (_bonds[_j].kind == _k) { _n++; if (_bonds[_j].strained) _strained++; if (is_undefined(_best) || _bonds[_j].tier > _best.tier) _best = _bonds[_j]; }
        tth_draw_bond(_c, { material: tth_material_of(_k), tier: is_undefined(_best) ? 1 : _best.tier, strained: false, knots: [], key: "sum-" + _k }, { x: _x + 2, y: _cy, r: 0 }, { x: _x + 56, y: _cy, r: 0 }, 0);
        var _col = (_n > 0) ? [240, 223, 182] : [140, 127, 105];
        tth__text(_c, is_string(_kn[$ _k]) ? _kn[$ _k] : _k, _x + 66, _cy + 5, 17, TTH_FACE_DISPLAY, _col, 1, fa_left, "alphabetic", _w - 100);
        tth__text(_c, string(_n), _x + _w, _cy + 5, 17, TTH_FACE_DISPLAY, _col, 1, fa_right, "alphabetic");
        if (!is_undefined(_best)) {
            var _na = _names[$ _best.a], _nb = _names[$ _best.b];
            var _line = (is_string(_na) ? _na : "") + " & " + (is_string(_nb) ? _nb : "") + ((_strained > 0) ? "  - " + string(_strained) + " " + (is_string(_s[$ "strainedText"]) ? _s.strainedText : "strained") : "");
            tth__text(_c, _line, _x + 66, _cy + 23, 14, TTH_FACE_LABEL, [203, 185, 148], 1, fa_left, "alphabetic", _w - 66);
        }
        _cy += 58; _rows++;
    }
    tth__text(_c, is_string(_s[$ "hint"]) ? _s.hint : "", _x, _r.y + _r.h - 14, 14, TTH_FACE_LABEL, [157, 143, 116], 1, fa_left, "alphabetic", _w);
    tth_cx_restore(_c);
    return { rows: _rows };
}

/// @function tth_draw_ledger(ctx, r, who, rows, names, opts)
/// @description One character's ledger: their name and subtitle, then each bond as a swatch of its own cord, the other
/// character's name, the kind in the buyer's words (and "strained"), the tier as pips and up to two knots. rows: [{other,
/// kind, material, tier, strained, knots: [{label}], key}]. opts: {kindNames, maxTier, emptyText, strainedText}.
/// Returns {rows, hidden}.
function tth_draw_ledger(_c, _r, _who, _rows, _names, _o) {
    var _G = tth_gilt(), _ink = tth_ink();
    var _kn = (is_struct(_o) && is_struct(_o[$ "kindNames"])) ? _o.kindNames : {}, _maxT = (is_struct(_o) && is_numeric(_o[$ "maxTier"])) ? _o.maxTier : 5;
    tth_cx_save(_c);
    var _x = _r.x + 16, _w = _r.w - 32, _y = _r.y + 40;
    var _nm = is_string(_who[$ "name"]) ? _who.name : "", _size = 24;
    while (tth__measure(_c, _nm, _size, TTH_FACE_DISPLAY) > _w && _size > 13) _size--;
    tth__text(_c, _nm, _x, _y, _size, TTH_FACE_DISPLAY, _G.light, 1, fa_left, "alphabetic");
    tth__text(_c, is_string(_who[$ "subtitle"]) ? _who.subtitle : "", _x, _y + 20, 15, TTH_FACE_LABEL, [191, 174, 140], 1, fa_left, "alphabetic", _w);
    _c.stroke = tth_cx_solid(_G.base); _c.alpha = 0.7; _c.lw = 1; tth__line(_c, _x, _y + 32, _x + _w, _y + 32); _c.alpha = 1;
    var _cy = _y + 50, _shown = 0;
    if (array_length(_rows) == 0) tth__text(_c, (is_struct(_o) && is_string(_o[$ "emptyText"])) ? _o.emptyText : "No bonds yet.", _x, _cy + 10, 16, TTH_FACE_LABEL, [191, 174, 140], 1, fa_left, "alphabetic", _w);
    for (var _i = 0; _i < array_length(_rows); _i++) {
        var _b = _rows[_i], _rowH = 50 + min(2, array_length(_b.knots)) * 17;
        if (_cy + _rowH > _r.y + _r.h - 26) break;
        tth_draw_bond(_c, { material: _b.material, tier: _b.tier, strained: _b.strained, knots: [], key: _b.key }, { x: _x + 2, y: _cy + 6, r: 0 }, { x: _x + 62, y: _cy + 6, r: 0 }, 0);
        var _on = _names[$ _b.other];
        tth__text(_c, is_string(_on) ? _on : "", _x + 72, _cy + 10, 17, TTH_FACE_DISPLAY, [240, 223, 182], 1, fa_left, "alphabetic", _w - 72);
        var _kword = is_string(_kn[$ _b.kind]) ? _kn[$ _b.kind] : _b.kind;
        tth__text(_c, _kword + (_b.strained ? " - " + ((is_struct(_o) && is_string(_o[$ "strainedText"])) ? _o.strainedText : "strained") : ""), _x + 72, _cy + 28, 14, TTH_FACE_LABEL, _b.strained ? [224, 164, 137] : [203, 185, 148], 1, fa_left, "alphabetic", _w - 72);
        var _mi = _ink[$ _b.material];
        tth_pips(_c, _x + 6, _cy + 27, _b.tier, _maxT + 1, is_struct(_mi) ? _mi.light : _G.light);
        for (var _k = 0; _k < min(2, array_length(_b.knots)); _k++) tth__text(_c, "~ " + _b.knots[_k].label, _x + 10, _cy + 47 + _k * 17, 14, TTH_FACE_LABEL, [231, 215, 174], 1, fa_left, "alphabetic", _w - 10);
        _cy += _rowH; _shown++;
    }
    var _hidden = array_length(_rows) - _shown;
    if (_hidden > 0) tth__text(_c, "+ " + string(_hidden), _x, _r.y + _r.h - 12, 14, TTH_FACE_LABEL, [191, 174, 140], 1, fa_left, "alphabetic");
    tth_cx_restore(_c);
    return { rows: _shown, hidden: _hidden };
}
