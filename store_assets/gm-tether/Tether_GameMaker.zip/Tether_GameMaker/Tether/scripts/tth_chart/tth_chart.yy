{
  "$GMScript": "v1",
  "%Name": "tth_chart",
  "name": "tth_chart",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}