/// tth_read.gml - the reader and the layout solver. Turns relationship VALUES into bonds - for every pair, whether a
/// cord is drawn, of what material, how heavy, whether it is strained, where its knots sit - and orders the cast round the
/// chart so as few cords cross as possible. Pure: no drawing, no engine state.
///
/// Tether - Every Bond Drawn as a Cord, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ A PORT HELD TO ITS ORIGINAL (TetherRead.js). Character ids are the buyer's own STRINGS here (the original used MZ
/// actor numbers); a pair key is the two ids in sorted order joined by "-". Nothing is random: a knot's position is a
/// hash of the pair and its label, so the same save always draws the same chart.

/// @function tth_kinds()
function tth_kinds() { return ["love", "friendship", "oath", "rivalry", "family"]; }

/// @function tth_default_thresholds()
/// @description Tier thresholds on |value|: tier n is the highest threshold the value reaches (0, 10, 25, 50, 75, 100).
function tth_default_thresholds() { return [0, 10, 25, 50, 75, 100]; }

#macro TTH_MAX_CAST 16
#macro TTH_KNOT_LO 0.18
#macro TTH_KNOT_HI 0.82
#macro TTH_KNOT_GAP 0.14
#macro TTH_FRAME_EXTENT 17
#macro TTH_MAX_FACE 46
#macro TTH_MIN_FACE 14
#macro TTH_PLATE_DROP 23
#macro TTH_NEIGHBOUR_GAP 44

/// @function tth__num(v)
function tth__num(_v) { if (is_numeric(_v)) return _v; if (is_string(_v)) { var _r = real(string_digits(_v)); return is_numeric(_r) ? _r : 0; } return 0; }

/// @function tth_kind_for(declared, value)
/// @description One of the five kinds: the declared word if it is one, else rivalry for a negative value, friendship
/// for anything else. Pure.
function tth_kind_for(_d, _v) {
    var _k = is_string(_d) ? string_lower(string_trim(_d)) : "";
    if (array_get_index(tth_kinds(), _k) >= 0) return _k;
    return (is_numeric(_v) && _v < 0) ? "rivalry" : "friendship";
}

/// @function tth_tier_for(value, [thresholds])
/// @description The tier (0..5 with the defaults) a value reaches on |value|. Pure.
function tth_tier_for(_v, _t = undefined) {
    if (!is_array(_t) || array_length(_t) == 0) _t = tth_default_thresholds();
    var _m = abs(is_numeric(_v) ? _v : 0), _tier = 0;
    for (var _i = 0; _i < array_length(_t); _i++) if (_m >= _t[_i]) _tier = _i;
    return max(0, min(array_length(_t) - 1, _tier));
}

/// @function tth_is_strained(kind, value, flagged)
/// @description A bond is strained when its value runs AGAINST its kind (negative and not a rivalry) or it is flagged.
function tth_is_strained(_k, _v, _f) { if (_f == true) return true; return _k != "rivalry" && is_numeric(_v) && _v < 0; }

/// @function tth_pair_key(a, b)
/// @description The two ids in sorted order joined by "-". Pure.
function tth_pair_key(_a, _b) { _a = string(_a); _b = string(_b); return (_a < _b) ? _a + "-" + _b : _b + "-" + _a; }

/// @function tth__space_knots(list)
/// @description Knots keep their hashed ORDER and as much of their position as they can, but never sit closer than the
/// gap (or an even share of the run when too many must fit). (MZ: two labels hashed 0.02 apart drew as one knot.)
function tth__space_knots(_l) {
    var _n = array_length(_l);
    if (_n < 2) return _l;
    var _gap = min(TTH_KNOT_GAP, (TTH_KNOT_HI - TTH_KNOT_LO) / (_n - 1));
    for (var _i = 1; _i < _n; _i++) if (_l[_i].t < _l[_i - 1].t + _gap) _l[_i].t = _l[_i - 1].t + _gap;
    if (_l[_n - 1].t > TTH_KNOT_HI) {
        _l[_n - 1].t = TTH_KNOT_HI;
        for (var _j = _n - 2; _j >= 0; _j--) if (_l[_j].t > _l[_j + 1].t - _gap) _l[_j].t = _l[_j + 1].t - _gap;
    }
    for (var _k = 0; _k < _n; _k++) _l[_k].t = max(TTH_KNOT_LO, min(TTH_KNOT_HI, _l[_k].t));
    return _l;
}

/// @function tth_knots_for(key, labels)
/// @description Knot records [{label, t}] for a list of event labels on one pair: t is a hash of the pair and the
/// label (so it never moves between saves), the same label twice is one knot, then spaced. Pure.
function tth_knots_for(_key, _labels) {
    var _out = [], _seen = {};
    if (!is_array(_labels)) return _out;
    for (var _i = 0; _i < array_length(_labels); _i++) {
        var _lab = is_string(_labels[_i]) ? string_trim(_labels[_i]) : (is_numeric(_labels[_i]) ? string(_labels[_i]) : "");
        if (_lab == "" || variable_struct_exists(_seen, _lab)) continue;
        _seen[$ _lab] = true;
        var _h = tth_hash(_key + "@" + _lab);
        array_push(_out, { label: _lab, t: TTH_KNOT_LO + (_h mod 1000) / 1000 * 0.64 });
    }
    array_sort(_out, function(_x, _y) { if (_x.t != _y.t) return (_x.t < _y.t) ? -1 : 1; return (_x.label < _y.label) ? -1 : 1; });
    return tth__space_knots(_out);
}

/// @function tth_face_for(spacing)
/// @description The largest face radius whose FRAMED medallion clears a neighbour at centre distance `spacing`.
function tth_face_for(_s) { return max(TTH_MIN_FACE, min(TTH_MAX_FACE, _s / 2 - TTH_FRAME_EXTENT - 1)); }

/// @function tth_ring_positions(n, cx, cy, radius, [start])
/// @description n slots on one ring from the top, clockwise: [{x, y, r, ux, uy}] with r the face radius.
function tth_ring_positions(_n, _cx, _cy, _radius, _a0 = -pi / 2) {
    var _out = [], _sp = (_n > 1) ? 2 * _radius * sin(pi / _n) : _radius * 2, _r = tth_face_for(_sp);
    for (var _i = 0; _i < _n; _i++) {
        var _a = _a0 + _i * 2 * pi / _n;
        array_push(_out, { x: _cx + _radius * cos(_a), y: _cy + _radius * sin(_a), r: _r, ux: cos(_a), uy: sin(_a) });
    }
    return _out;
}

/// @function tth_layout_rings(n, cx, cy, radius)
/// @description One ring up to 12 (every cord a chord of the circle), two concentric rings from 13 to 16, the face
/// radius derived from the tightest spacing and the gap between rings.
function tth_layout_rings(_n, _cx, _cy, _radius) {
    var _count = max(0, min(TTH_MAX_CAST, floor(_n)));
    if (_count <= 12) return tth_ring_positions(_count, _cx, _cy, _radius);
    var _inner = tth_jsround(_count / 3), _outer = _count - _inner, _rin = _radius * 0.5;
    var _so = 2 * _radius * sin(pi / _outer), _si = 2 * _rin * sin(pi / _inner);
    var _r = min(tth_face_for(_so), tth_face_for(_si), tth_face_for(_radius - _rin));
    var _pts = tth_ring_positions(_outer, _cx, _cy, _radius);
    var _in = tth_ring_positions(_inner, _cx, _cy, _rin, -pi / 2 + pi / _inner);
    for (var _j = 0; _j < array_length(_in); _j++) array_push(_pts, _in[_j]);
    for (var _i = 0; _i < array_length(_pts); _i++) _pts[_i].r = _r;
    return _pts;
}

/// @function tth_layout_positions(n, cx, cy, radius, [halfH])
/// @description The chart's slots; with halfH the ring shrinks until every framed medallion AND its name plate fit
/// (MZ: a cast of four grew to the largest face and hit the title plate).
function tth_layout_positions(_n, _cx, _cy, _radius, _halfH = 0) {
    var _R = _radius;
    if (_halfH > 0) {
        for (var _pass = 0; _pass < 3; _pass++) {
            var _probe = tth_layout_rings(_n, _cx, _cy, _R);
            if (array_length(_probe) == 0) break;
            var _need = _probe[0].r + max(TTH_FRAME_EXTENT, TTH_PLATE_DROP) + 2;
            if (_R + _need <= _halfH) return _probe;
            _R = max(10, _halfH - _need);
        }
    }
    return tth_layout_rings(_n, _cx, _cy, _R);
}

/// @function tth__orient(a, b, c)
function tth__orient(_a, _b, _c) { var _v = (_b.x - _a.x) * (_c.y - _a.y) - (_b.y - _a.y) * (_c.x - _a.x); return (_v > 0.000000001) ? 1 : ((_v < -0.000000001) ? -1 : 0); }

/// @function tth_crossings(order, edges, pos)
/// @description How many pairs of cords cross when node order[i] sits in slot i (cords sharing a medallion never count).
function tth_crossings(_order, _edges, _pos) {
    var _slot = array_create(array_length(_order));
    for (var _i = 0; _i < array_length(_order); _i++) _slot[_order[_i]] = _i;
    var _c = 0;
    for (var _a = 0; _a < array_length(_edges); _a++) for (var _b = _a + 1; _b < array_length(_edges); _b++) {
        var _e = _edges[_a], _f = _edges[_b];
        if (_e[0] == _f[0] || _e[0] == _f[1] || _e[1] == _f[0] || _e[1] == _f[1]) continue;
        var _p = _pos[_slot[_e[0]]], _q = _pos[_slot[_e[1]]], _r = _pos[_slot[_f[0]]], _s = _pos[_slot[_f[1]]];
        if (tth__orient(_p, _q, _r) * tth__orient(_p, _q, _s) < 0 && tth__orient(_r, _s, _p) * tth__orient(_r, _s, _q) < 0) _c++;
    }
    return _c;
}

/// @function tth__perm(state, k)
/// @description Every order of state.rest from position k (node 0 fixed in slot 0); keeps the fewest crossings. Internal.
function tth__perm(_st, _k) {
    if (_st.bestC == 0) return;
    var _rest = _st.rest;
    if (_k == array_length(_rest)) {
        var _ord = [0];
        for (var _i = 0; _i < array_length(_rest); _i++) array_push(_ord, _rest[_i]);
        var _c = tth_crossings(_ord, _st.edges, _st.pos);
        if (_c < _st.bestC) { _st.bestC = _c; _st.best = _ord; }
        return;
    }
    // ⛔ swaps are written through the STRUCT field, never a local alias: a buyer's project may run the legacy array
    // copy-on-write option, under which `var r = st.rest; r[k] = x` edits a private copy
    for (var _j = _k; _j < array_length(_st.rest); _j++) {
        var _t = _st.rest[_k]; _st.rest[_k] = _st.rest[_j]; _st.rest[_j] = _t;
        tth__perm(_st, _k + 1);
        _t = _st.rest[_k]; _st.rest[_k] = _st.rest[_j]; _st.rest[_j] = _t;
    }
}

/// @function tth_solve_order(n, edges, pos)
/// @description An order of nodes 0..n-1 crossing as few cords as it can find: exact for n <= 8 (node 0 fixed - one ring
/// is rotation-symmetric), pairwise-swap descent from the INPUT order above that, so never worse than doing nothing.
function tth_solve_order(_n, _edges, _pos) {
    var _count = min(TTH_MAX_CAST, max(0, floor(_n))), _base = [];
    for (var _i = 0; _i < _count; _i++) array_push(_base, _i);
    var _best = [];
    for (var _b = 0; _b < _count; _b++) array_push(_best, _base[_b]);
    var _bestC = tth_crossings(_best, _edges, _pos);
    if (_bestC == 0 || _count < 4) return _best;
    if (_count <= 8) {
        var _rest = [];
        for (var _r = 1; _r < _count; _r++) array_push(_rest, _r);
        var _st = { rest: _rest, edges: _edges, pos: _pos, best: _best, bestC: _bestC };
        tth__perm(_st, 0);
        return _st.best;
    }
    var _improved = true, _guard = 0;
    while (_improved && _guard < 50) {
        _guard++; _improved = false;
        for (var _x = 0; _x < _count; _x++) for (var _y = _x + 1; _y < _count; _y++) {
            var _cand = [];
            for (var _q = 0; _q < _count; _q++) array_push(_cand, _best[_q]);
            var _tt = _cand[_x]; _cand[_x] = _cand[_y]; _cand[_y] = _tt;
            var _cc = tth_crossings(_cand, _edges, _pos);
            if (_cc < _bestC) { _bestC = _cc; _best = _cand; _improved = true; }
        }
    }
    return _best;
}
