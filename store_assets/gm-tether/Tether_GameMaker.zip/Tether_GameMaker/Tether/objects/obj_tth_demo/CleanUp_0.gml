/// @description Free every cached chart sprite.
tth_chart_free();
