/// @description Focus, knot and strain keys.
tth_demo_step(demo);
