/// @description The chart page (baked on change, one sprite a frame otherwise) and the help line.
tth_demo_draw(demo);
