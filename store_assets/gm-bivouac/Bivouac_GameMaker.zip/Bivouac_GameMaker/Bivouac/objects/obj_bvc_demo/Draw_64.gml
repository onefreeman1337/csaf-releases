/// @description The battle field fitted to the window: a plain dusk battleback, the baked ground BEHIND the battlers, the
/// stand-in battlers, and what the band was read as.
if (is_undefined(program)) exit;
var _gw = display_get_gui_width(), _gh = display_get_gui_height(), _fw = program.reading.field.w, _fh = program.reading.field.h;
var _k = min(_gw / _fw, _gh / _fh), _ox = (_gw - _fw * _k) / 2, _oy = (_gh - _fh * _k) / 2;
draw_clear(make_colour_rgb(18, 17, 21));
draw_rectangle_colour(_ox, _oy, _ox + _fw * _k, _oy + _fh * _k * 0.55, make_colour_rgb(58, 60, 72), make_colour_rgb(58, 60, 72), make_colour_rgb(92, 86, 84), make_colour_rgb(92, 86, 84), false);
draw_rectangle_colour(_ox, _oy + _fh * _k * 0.55, _ox + _fw * _k, _oy + _fh * _k, make_colour_rgb(40, 42, 50), make_colour_rgb(40, 42, 50), make_colour_rgb(28, 30, 36), make_colour_rgb(28, 30, 36), false);
bvc_ground_draw(ground, _ox, _oy, _k);
var _v = program.reading.visible;
for (var _i = 0; _i < array_length(_v); _i++) standin(_ox + _v[_i].x * _k, _oy + _v[_i].y * _k, _k * _v[_i].weight * 1.1);
var _m = program.meta, _pf = draw_get_font();
draw_set_font(fnt_bivouac);
draw_set_colour(make_colour_rgb(236, 226, 204));
draw_text(_ox + 16, _oy + 12, _m.name);
draw_set_font(fnt_bivouac_ui);
draw_set_colour(make_colour_rgb(201, 188, 160));
draw_text(_ox + 16, _oy + 46, _m.nature + "  -  " + _m.standing + "  -  " + _m.ground + " ground");
draw_text(_ox + 16, _oy + 68, "Enter or click for the next band (" + string(which + 1) + " of " + string(array_length(encounters)) + ")");
draw_set_font(_pf);
draw_set_colour(c_white);
