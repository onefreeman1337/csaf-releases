/// @description Enter, Space or a click: the next band's ground.
if (is_undefined(program)) exit;
if (keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space) || mouse_check_button_pressed(mb_left)) {
    which = (which + 1) mod array_length(encounters);
    deal();
}
