/// @description Bivouac demo: each encounter's ground, composed from the band and baked once, under stand-in battlers.
/// Enter or click for the next band. Also the headless -selftest entry.
/// ⛔ The crash handler is installed FIRST, and every variable a later event reads is declared ABOVE the early exits:
/// Clean Up always runs, even when Create leaves early.
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("bvc_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.bvc_stage) + ": " + string(_ex.message) + " | " + string(_ex.stacktrace));
    file_text_close(_f);
    game_end();
});
global.bvc_stage = 0;
program = undefined;
ground = -1;
which = 0;
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";
if (string_pos("-selftest", _args) > 0) { global.bvc_stage = 1; bvc_selftest_write(bvc_selftest_run()); game_end(); exit; }

// Your bestiary is every enemy in your game; an encounter is who is in the band and where their feet are.
// (The demo borrows the suite's invented bestiary and seventeen encounters.)
bestiary = bvc_oracle_bestiary();
encounters = bvc_oracle_encounters();

/// compose the band's ground and bake it once (a whole ground is hundreds of fills: never draw it every frame)
deal = function() {
    if (sprite_exists(ground)) sprite_delete(ground);
    var _e = encounters[which];
    program = bvc_compose(_e, bestiary, _e.opts);
    ground = bvc_bake(program);
};

/// a hooded stand-in where one of YOUR battlers stands (feet at x, y)
standin = function(_x, _y, _s) {
    var _c = make_colour_rgb(30, 28, 34), _e = make_colour_rgb(236, 200, 96);
    draw_primitive_begin(pr_trianglefan);
    draw_vertex_colour(_x, _y - 50 * _s, _c, 1);
    draw_vertex_colour(_x - 26 * _s, _y, _c, 1); draw_vertex_colour(_x - 18 * _s, _y - 60 * _s, _c, 1);
    draw_vertex_colour(_x, _y - 88 * _s, _c, 1); draw_vertex_colour(_x + 18 * _s, _y - 60 * _s, _c, 1);
    draw_vertex_colour(_x + 26 * _s, _y, _c, 1); draw_vertex_colour(_x - 26 * _s, _y, _c, 1);
    draw_primitive_end();
    draw_circle_colour(_x - 6 * _s, _y - 64 * _s, 2.2 * _s, _e, _e, false);
    draw_circle_colour(_x + 6 * _s, _y - 64 * _s, 2.2 * _s, _e, _e, false);
};

deal();
