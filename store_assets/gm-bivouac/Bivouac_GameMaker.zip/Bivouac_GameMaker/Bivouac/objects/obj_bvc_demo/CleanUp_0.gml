/// @description Free the baked ground.
if (variable_instance_exists(id, "ground") && is_numeric(ground) && sprite_exists(ground)) sprite_delete(ground);
ground = -1;
