/// bvc_draw.gml - Bivouac's constructions: turns a program (bvc_plan / bvc_compose) into the drawn ground - the worked
/// earth in one of ten treatments, the marks the band left, the furniture it set down, the cast shadows that seat its
/// battlers. Every drawn thing has its own construction; nothing is a recolour of its neighbour. No image files.
///
/// Bivouac - Every Enemy Band Stages Its Own Ground, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// PUBLIC
///   bvc_bake(program, [opts])            -> a sprite of the whole ground at field size (draw it BEHIND your battlers with
///                                            bvc_ground_draw); opts {supersample 1..3 (2), shadow_strength 0..1 (0.40)}
///   bvc_ground_draw(sprite, x, y, [scale]) -> draw a baked ground (it is premultiplied: this sets the right blend)
///   bvc_draw(program, [opts])            -> draw a program into the CURRENT target, which must have a stencil buffer
///                                            (a bvc_k_surface); returns {drawn, skipped}
///   bvc_draw_piece(key, x, y, scale, rng) -> draw one piece of furniture (true if a construction exists)
///   bvc_corpus()                          -> {grounds, marks, furniture}: every key this file can draw
/// ⛔ PORTED FROM THE RPG MAKER MZ BivouacDraw.js, construction for construction and draw for draw from the same seeded
/// streams, in the JavaScript order. One light, fixed, travelling toward the lower right: every solid form gets a lit lip,
/// a darkened side and a cast shadow on the ground beside it.

#macro BVC_LX 0.52
#macro BVC_LY 0.85

// ================================================================================================ colour

/// @function bvc__rgb(c)
/// @description A GameMaker colour from [r, g, b] (rounded and clamped, the MZ rgb()). Internal.
function bvc__rgb(_c) { return make_colour_rgb(bvc__round(bvc__clamp(_c[0], 0, 255)), bvc__round(bvc__clamp(_c[1], 0, 255)), bvc__round(bvc__clamp(_c[2], 0, 255))); }

/// @function bvc__mix(a, b, t)
function bvc__mix(_a, _b, _t) { var _k = bvc__clamp(_t, 0, 1); return [_a[0] + (_b[0] - _a[0]) * _k, _a[1] + (_b[1] - _a[1]) * _k, _a[2] + (_b[2] - _a[2]) * _k]; }

/// @function bvc__shade(c, t)
/// @description Lighten toward warm white (t > 0) or darken toward a cool black (t < 0). Internal.
function bvc__shade(_c, _t) { return (_t >= 0) ? bvc__mix(_c, [255, 252, 238], _t) : bvc__mix(_c, [16, 14, 20], -_t); }

/// @function bvc__mat(key)
/// @description {base, grain, rough} of a material; unknown reads as stone. Internal.
function bvc__mat(_k) {
    switch (_k) {
        case "timber": return { base: [104, 78, 50], grain: "lengthwise", rough: 0.5 };
        case "darkwood": return { base: [72, 54, 38], grain: "lengthwise", rough: 0.6 };
        case "darkstone": return { base: [78, 76, 78], grain: "chip", rough: 0.8 };
        case "metal": return { base: [126, 130, 138], grain: "sheen", rough: 0.15 };
        case "rust": return { base: [124, 78, 48], grain: "pit", rough: 0.8 };
        case "cloth": return { base: [126, 54, 48], grain: "weave", rough: 0.4 };
        case "palecloth": return { base: [176, 160, 132], grain: "weave", rough: 0.4 };
        case "bone": return { base: [206, 198, 176], grain: "pit", rough: 0.35 };
        case "hide": return { base: [128, 100, 70], grain: "pore", rough: 0.55 };
        case "rope": return { base: [152, 132, 92], grain: "twist", rough: 0.5 };
        case "ember": return { base: [214, 98, 34], grain: "flicker", rough: 0.3 };
        case "ice": return { base: [176, 200, 214], grain: "facet", rough: 0.25 };
        case "fungus": return { base: [150, 138, 160], grain: "spot", rough: 0.45 };
        case "reed": return { base: [158, 150, 96], grain: "lengthwise", rough: 0.45 };
        case "gold": return { base: [190, 154, 62], grain: "sheen", rough: 0.2 };
    }
    return { base: [122, 120, 114], grain: "chip", rough: 0.7 };
}

// ================================================================================================ geometry helpers

/// @function bvc__shift(points, dx, dy)
/// @description A copy of a flat point array moved by (dx, dy). Internal.
function bvc__shift(_p, _dx, _dy) { var _o = array_create(array_length(_p)); for (var _i = 0; _i < array_length(_p); _i += 2) { _o[_i] = _p[_i] + _dx; _o[_i + 1] = _p[_i + 1] + _dy; } return _o; }

/// @function bvc__arc(cx, cy, rx, ry, a0, a1, out, [seg])
/// @description Append points along an elliptical arc from angle a0 to a1 (either direction). Internal.
function bvc__arc(_cx, _cy, _rx, _ry, _a0, _a1, _out, _seg = 0) {
    var _n = (_seg > 0) ? _seg : clamp(ceil(abs(_a1 - _a0) * max(_rx, _ry) / 3), 4, 64);
    for (var _i = 0; _i <= _n; _i++) { var _a = lerp(_a0, _a1, _i / _n); array_push(_out, _cx + cos(_a) * _rx, _cy + sin(_a) * _ry); }
    return _out;
}

/// @function bvc__smooth(outline)
/// @description The apron path as the MZ draws it: from point 0, a quadratic curve through each point to the midpoint of
/// the next edge, closed back to point 0 - as a flat point array. Internal.
function bvc__smooth(_ol) {
    var _n = array_length(_ol), _out = [];
    if (_n < 3) return _out;
    array_push(_out, _ol[0].x, _ol[0].y);
    var _px = _ol[0].x, _py = _ol[0].y;
    for (var _i = 1; _i < _n; _i++) {
        var _p = _ol[_i], _q = _ol[(_i + 1) mod _n], _mx = (_p.x + _q.x) / 2, _my = (_p.y + _q.y) / 2;
        bvc_k_quad(_px, _py, _p.x, _p.y, _mx, _my, 6, _out);
        _px = _mx; _py = _my;
    }
    return _out;
}

/// @function bvc__bbox(outline)
/// @description {x, y, w, h} of an outline of {x, y} points, w and h at least 1. Internal.
function bvc__bbox(_ol) {
    var _x0 = infinity, _y0 = infinity, _x1 = -infinity, _y1 = -infinity;
    for (var _i = 0; _i < array_length(_ol); _i++) { _x0 = min(_x0, _ol[_i].x); _x1 = max(_x1, _ol[_i].x); _y0 = min(_y0, _ol[_i].y); _y1 = max(_y1, _ol[_i].y); }
    return { x: _x0, y: _y0, w: max(1, _x1 - _x0), h: max(1, _y1 - _y0) };
}

/// @function bvc__stroke(points, width, colour, alpha, closed)
/// @description Stroke a polyline with round joins and caps (a disc at every vertex: butt-ended segments leave notches
/// on a turn - Doctrine_Craft s3), inside the current clip. Internal.
function bvc__stroke(_p, _w, _col, _al, _closed = false) {
    var _n = array_length(_p) div 2;
    if (_n < 2) return;
    bvc_k_clipped_begin();
    var _a0 = draw_get_alpha();
    draw_set_alpha(bvc__clamp(_al, 0, 1));
    var _last = _closed ? _n : _n - 1;
    for (var _i = 0; _i < _last; _i++) {
        var _j = (_i + 1) mod _n;
        draw_line_width_colour(_p[_i * 2], _p[_i * 2 + 1], _p[_j * 2], _p[_j * 2 + 1], _w, _col, _col);
    }
    if (_w > 2) for (var _k = 0; _k < _n; _k++) draw_circle_colour(_p[_k * 2], _p[_k * 2 + 1], _w / 2, _col, _col, false);
    draw_set_alpha(_a0);
    bvc_k_clipped_end();
}

/// @function bvc__stroke_fade(points, width, colour, alpha)
/// @description Stroke a polyline as ONE triangle strip whose alpha rises from 0 at the first point to `alpha` at the last
/// (t^0.85 along the line), inside the current clip. One strip, not segments: separate translucent segments stack their
/// round joints into darker beads. A track leading in fades away from the band. Internal.
function bvc__stroke_fade(_p, _w, _col, _al) {
    var _n = array_length(_p) div 2;
    if (_n < 2) return;
    bvc_k_clipped_begin();
    draw_primitive_begin(pr_trianglestrip);
    for (var _i = 0; _i < _n; _i++) {
        var _a = max(0, _i - 1), _b = min(_n - 1, _i + 1);
        var _tx = _p[_b * 2] - _p[_a * 2], _ty = _p[_b * 2 + 1] - _p[_a * 2 + 1], _L = point_distance(0, 0, _tx, _ty);
        if (_L == 0) _L = 1;
        var _nx = -_ty / _L * _w / 2, _ny = _tx / _L * _w / 2, _va = _al * power(_i / (_n - 1), 0.85);
        draw_vertex_colour(_p[_i * 2] + _nx, _p[_i * 2 + 1] + _ny, _col, _va);
        draw_vertex_colour(_p[_i * 2] - _nx, _p[_i * 2 + 1] - _ny, _col, _va);
    }
    draw_primitive_end();
    bvc_k_clipped_end();
}

// ================================================================================================ primitives

/// @function bvc__form(points, mat, [o])
/// @description A solid form with relief: the body, a darkened side pushed away from the light, then a lit lip, all
/// clipped to the form (the MZ form(), whose canvas clip + translate is a stencil clip + shifted fills here).
/// o {lip (2.0), tint [r, g, b], tintAmt (0.25), alpha (1)}. Internal.
function bvc__form(_p, _mat, _o = undefined) {
    if (bvc__k_ok(_p) == 0) return;
    var _m = bvc__mat(_mat), _base = _m.base;
    var _tint = bvc__get(_o, "tint", undefined);
    if (is_array(_tint)) _base = bvc__mix(_base, _tint, bvc__clamp(bvc__get(_o, "tintAmt", 0.25), 0, 1));
    var _lip = bvc__get(_o, "lip", 2.0), _al = bvc__clamp(bvc__get(_o, "alpha", 1), 0, 1);
    bvc_k_fill(_p, bvc__rgb(_base), _al);
    if (!bvc_k_clip_push(_p)) return;
    bvc_k_fill(bvc__shift(_p, BVC_LX * _lip * 1.9, BVC_LY * _lip * 1.9), bvc__rgb(bvc__shade(_base, -0.34)), _al);
    bvc_k_fill(bvc__shift(_p, -BVC_LX * _lip, -BVC_LY * _lip), bvc__rgb(bvc__shade(_base, 0.30)), _al);
    bvc_k_fill(bvc__shift(_p, -BVC_LX * _lip * 1.9, -BVC_LY * _lip * 1.9), bvc__rgb(_base), _al);
    bvc_k_clip_pop();
}

/// @function bvc__cast(x, y, w, h, [strength])
/// @description The cast shadow an object throws beside it: nested falloff rings (a single ellipse read as a CRATER -
/// MZ, measured) and a hard contact patch. Internal.
function bvc__cast(_x, _y, _w, _h, _strength = 0.42) {
    var _s = bvc__clamp(_strength, 0, 1), _cx = _x + BVC_LX * _h * 0.42, _cy = _y + 2;
    var _rx = max(4, _w * (1 + _h / 220)), _ry = max(3, _w * 0.30), _col = make_colour_rgb(16, 12, 20);
    for (var _i = 5; _i >= 1; _i--) {
        var _t = _i / 5;
        bvc_k_fill(bvc_k_ellipse(_cx, _cy, _rx * (0.62 + _t * 0.66), _ry * (0.62 + _t * 0.66)), _col, _s * 0.34 * (1 - _t * 0.72));
    }
    bvc_k_fill(bvc_k_ellipse(_cx - BVC_LX * 2, _cy - 1, _rx * 0.44, _ry * 0.42), _col, _s * 0.55);
}

/// @function bvc__mass(x, y, rx, ry, mat, [o])
function bvc__mass(_x, _y, _rx, _ry, _mat, _o = undefined) { bvc__form(bvc_k_ellipse(_x, _y, max(0.6, _rx), max(0.6, _ry)), _mat, _o); }

/// @function bvc__post(x, ytop, ybase, w, mat, [o])
/// @description An upright member (post, pole, trunk, leg), splayed a little at the base; o.lean shifts the top. Internal.
function bvc__post(_x, _yt, _yb, _w, _mat, _o = undefined) {
    var _ln = bvc__get(_o, "lean", 0);
    bvc__form([_x - _w / 2 + _ln, _yt, _x + _w / 2 + _ln, _yt, _x + _w * 0.62, _yb, _x - _w * 0.62, _yb], _mat, _o);
}

/// @function bvc__beam(x0, y0, x1, y1, w, mat, [o])
/// @description An angled member (strut, spar, rafter, bone). Internal.
function bvc__beam(_x0, _y0, _x1, _y1, _w, _mat, _o = undefined) {
    var _dx = _x1 - _x0, _dy = _y1 - _y0, _L = point_distance(0, 0, _dx, _dy);
    if (_L == 0) _L = 1;
    var _nx = -_dy / _L * _w / 2, _ny = _dx / _L * _w / 2;
    bvc__form([_x0 + _nx, _y0 + _ny, _x1 + _nx, _y1 + _ny, _x1 - _nx, _y1 - _ny, _x0 - _nx, _y0 - _ny], _mat, _o);
}

/// @function bvc__sheet(x0, y0, x1, y1, drop, sag, mat, [o])
/// @description A hanging or stretched sheet with a real sag. Internal.
function bvc__sheet(_x0, _y0, _x1, _y1, _drop, _sag, _mat, _o = undefined) {
    var _p = [_x0, _y0];
    bvc_k_quad(_x0, _y0, (_x0 + _x1) / 2, (_y0 + _y1) / 2 + _sag, _x1, _y1, 8, _p);
    array_push(_p, _x1 + 2, _y1 + _drop);
    bvc_k_quad(_x1 + 2, _y1 + _drop, (_x0 + _x1) / 2, (_y0 + _y1) / 2 + _drop + _sag * 1.25, _x0 - 2, _y0 + _drop, 8, _p);
    bvc__form(_p, _mat, _o);
}

/// @function bvc__cord(x0, y0, x1, y1, sag, mat)
/// @description A cord as a sagging curve, a dark body and a lit line along its top. Internal.
function bvc__cord(_x0, _y0, _x1, _y1, _sag, _mat) {
    var _m = bvc__mat(_mat);
    var _p = bvc_k_quad(_x0, _y0, (_x0 + _x1) / 2, (_y0 + _y1) / 2 + _sag, _x1, _y1, 10, [_x0, _y0]);
    bvc__stroke(_p, 1.7, bvc__rgb(bvc__shade(_m.base, -0.15)), 1);
    bvc__stroke(bvc__shift(_p, 0, -0.7), 0.8, bvc__rgb(bvc__shade(_m.base, 0.28)), 1);
}

// ================================================================================================ the ground

/// @function bvc__ground_marks(key, box, rng, chroma)
/// @description One of the ten ground treatments, drawn inside the apron clip across its box. Internal.
function bvc__ground_marks(_g, _b, _r, _col) {
    var _i, _k, _x, _y, _al, _c;
    // ⛔ LOOKED AT (2026-09-28, 1x): the MZ counts are fixed, sized for an 816 x 624 field, and on an apron three times
    // that area hardpan, ashbed and rime read nearly bare. Counts now scale with the apron's own area (1x to 3x).
    var _d = bvc__clamp(_b.w * _b.h / 160000, 1, 3);
    switch (_g) {
        case "hardpan":
            _c = bvc__rgb(bvc__shade(_col, -0.42));
            for (_i = 0; _i < round(22 * _d); _i++) {
                _x = _b.x + bvc_rnd(_r) * _b.w; _y = _b.y + bvc_rnd(_r) * _b.h;
                _al = 0.30 + bvc_rnd(_r) * 0.25;
                var _pl = [_x, _y];
                for (_k = 0; _k < 4; _k++) { _x += (bvc_rnd(_r) - 0.5) * 34; _y += (bvc_rnd(_r) - 0.5) * 20; array_push(_pl, _x, _y); }
                bvc__stroke(_pl, 1.1, _c, _al);
            }
            break;
        case "ashbed":
            // ⛔ LOOKED AT (2026-09-28, 1x): flakes alone read as a bare grey floor. Ash lies in pale soft drifts first,
            // with the flakes on top of them, a little larger than the MZ original's
            for (_i = 0; _i < round(10 * _d); _i++) {
                _x = _b.x + bvc_rnd(_r) * _b.w; _y = _b.y + bvc_rnd(_r) * _b.h;
                _al = 0.10 + bvc_rnd(_r) * 0.12;
                var _arx = 14 + bvc_rnd(_r) * 30;
                var _ary = 5 + bvc_rnd(_r) * 9;
                var _arot = bvc_rnd(_r) * 0.6;
                // three nested rings, so a drift has no edge (a single flat oval reads as a stamp)
                for (_k = 0; _k < 3; _k++) bvc_k_fill(bvc_k_ellipse(_x, _y, _arx * (1 - _k * 0.28), _ary * (1 - _k * 0.28), _arot), bvc__rgb(bvc__shade(_col, 0.28)), _al * 0.45);
            }
            for (_i = 0; _i < round(44 * _d); _i++) {
                _x = _b.x + bvc_rnd(_r) * _b.w; _y = _b.y + bvc_rnd(_r) * _b.h;
                var _s = 3 + bvc_rnd(_r) * 7;
                _al = 0.16 + bvc_rnd(_r) * 0.30;
                _c = bvc__rgb(bvc__shade(_col, (bvc_rnd(_r) < 0.3) ? 0.42 : -0.30));
                bvc_k_fill([_x, _y, _x + _s, _y + _s * 0.4, _x + _s * 0.5, _y + _s], _c, _al);
            }
            break;
        case "rime":
            _c = bvc__rgb(bvc__shade(_col, 0.5));
            for (_i = 0; _i < round(30 * _d); _i++) {
                _x = _b.x + bvc_rnd(_r) * _b.w; _y = _b.y + bvc_rnd(_r) * _b.h;
                var _L = 4 + bvc_rnd(_r) * 11;
                _al = 0.24 + bvc_rnd(_r) * 0.34;
                for (_k = 0; _k < 3; _k++) { var _a = (_k / 3) * pi + bvc_rnd(_r) * 0.4; bvc__stroke([_x, _y, _x + cos(_a) * _L, _y + sin(_a) * _L * 0.5], 0.9, _c, _al); }
            }
            break;
        case "mire":
            for (_i = 0; _i < round(26 * _d); _i++) {
                _x = _b.x + bvc_rnd(_r) * _b.w; _y = _b.y + bvc_rnd(_r) * _b.h;
                _al = 0.22 + bvc_rnd(_r) * 0.26;
                var _mrx = 6 + bvc_rnd(_r) * 15, _mry = 3 + bvc_rnd(_r) * 6;
                var _mrot = bvc_rnd(_r) * 1.2;
                bvc_k_fill(bvc_k_ellipse(_x, _y, _mrx, _mry, _mrot), bvc__rgb(bvc__shade(_col, -0.40)), _al);
                var _hrx = 4 + bvc_rnd(_r) * 8;
                var _hry = 1.6 + bvc_rnd(_r) * 2.6;
                bvc_k_fill(bvc_k_ellipse(_x - 2, _y - 2, _hrx, _hry), bvc__rgb(bvc__shade(_col, 0.34)), 0.20);
            }
            break;
        case "scorch":
            for (_i = 0; _i < round(22 * _d); _i++) {
                _x = _b.x + bvc_rnd(_r) * _b.w; _y = _b.y + bvc_rnd(_r) * _b.h;
                _al = 0.20 + bvc_rnd(_r) * 0.30;
                var _srx = 8 + bvc_rnd(_r) * 18;
                var _sry = 4 + bvc_rnd(_r) * 8;
                bvc_k_fill(bvc_k_ellipse(_x, _y, _srx, _sry), bvc__rgb(bvc__shade(_col, -0.45)), _al);
            }
            for (_i = 0; _i < round(16 * _d); _i++) {
                _x = _b.x + bvc_rnd(_r) * _b.w; _y = _b.y + bvc_rnd(_r) * _b.h;
                _al = 0.28 + bvc_rnd(_r) * 0.34;
                var _er = 190 + bvc_rnd(_r) * 50;
                var _eg = 80 + bvc_rnd(_r) * 60;
                var _erx = 0.9 + bvc_rnd(_r) * 1.8;
                var _ery = 0.7 + bvc_rnd(_r) * 1.2;
                bvc_k_fill(bvc_k_ellipse(_x, _y, _erx, _ery, 0, 10), bvc__rgb([_er, _eg, 30]), _al);
            }
            break;
        case "blight":
            // ⛔ blotches run BOTH ways from the ground, a pallor and a rot (MZ, measured: one-way blotches were invisible)
            for (_i = 0; _i < round(26 * _d); _i++) {
                _x = _b.x + bvc_rnd(_r) * _b.w; _y = _b.y + bvc_rnd(_r) * _b.h;
                var _R = 5 + bvc_rnd(_r) * 13;
                var _pale = bvc_rnd(_r) < 0.45;
                _al = 0.22 + bvc_rnd(_r) * 0.26;
                var _bp = [];
                for (_k = 0; _k <= 9; _k++) { var _ba = (_k / 9) * 6.283, _rr = _R * (0.7 + (((_k mod 2) != 0) ? 0.34 : 0)); array_push(_bp, _x + cos(_ba) * _rr, _y + sin(_ba) * _rr * 0.55); }
                bvc_k_fill(_bp, bvc__rgb(_pale ? bvc__mix(_col, [188, 196, 150], 0.72) : bvc__mix(_col, [38, 44, 26], 0.74)), _al);
            }
            break;
        case "drift":
            var _rows = round(20 * _d);
            for (_i = 0; _i < _rows; _i++) {
                _y = _b.y + (_i / _rows) * _b.h + (bvc_rnd(_r) - 0.5) * 6;
                _al = 0.14 + bvc_rnd(_r) * 0.18;
                _c = bvc__rgb(bvc__shade(_col, (bvc_rnd(_r) < 0.5) ? 0.30 : -0.22));
                var _dp = [_b.x, _y];
                for (_x = _b.x; _x < _b.x + _b.w; _x += 24) bvc_k_quad(_x, _y, _x + 12, _y - 4 - bvc_rnd(_r) * 4, _x + 24, _y, 5, _dp);
                bvc__stroke(_dp, 1.6, _c, _al);
            }
            break;
        case "flagstone":
            var _cell = 46;
            for (var _gy = _b.y; _gy < _b.y + _b.h + _cell; _gy += _cell) {
                var _q = _gy / _cell, _qi = (_q >= 0) ? floor(_q) : ceil(_q);
                var _off = ((_qi mod 2) != 0) ? _cell / 2 : 0;
                for (var _gx = _b.x - _cell; _gx < _b.x + _b.w + _cell; _gx += _cell) {
                    _x = _gx + _off + (bvc_rnd(_r) - 0.5) * 3; _y = _gy + (bvc_rnd(_r) - 0.5) * 3;
                    var _fp = [_x + 2, _y, _x + _cell - 3, _y + 1, _x + _cell - 2, _y + _cell - 3, _x + 1, _y + _cell - 2];
                    bvc_k_fill(_fp, bvc__rgb(bvc__shade(_col, (bvc_rnd(_r) - 0.5) * 0.30)), 0.30);
                    bvc__stroke(_fp, 1.5, bvc__rgb(bvc__shade(_col, -0.45)), 0.34, true);
                }
            }
            break;
        case "sward":
            // ⛔ turf is patchy before it is bladed (MZ, measured: blades on a flat fill read as one green blob)
            for (_i = 0; _i < round(20 * _d); _i++) {
                _x = _b.x + bvc_rnd(_r) * _b.w; _y = _b.y + bvc_rnd(_r) * _b.h;
                _al = 0.16 + bvc_rnd(_r) * 0.18;
                var _tint = (bvc_rnd(_r) < 0.5) ? [132, 150, 86] : [58, 74, 44];
                var _mt = 0.55 + bvc_rnd(_r) * 0.3;
                var _wrx = 22 + bvc_rnd(_r) * 46;
                var _wry = 10 + bvc_rnd(_r) * 20;
                var _wrot = bvc_rnd(_r) * 1.2;
                bvc_k_fill(bvc_k_ellipse(_x, _y, _wrx, _wry, _wrot), bvc__rgb(bvc__mix(_col, _tint, _mt)), _al);
            }
            for (_i = 0; _i < round(130 * _d); _i++) {
                _x = _b.x + bvc_rnd(_r) * _b.w; _y = _b.y + bvc_rnd(_r) * _b.h;
                var _bl = 3 + bvc_rnd(_r) * 8;
                _al = 0.24 + bvc_rnd(_r) * 0.30;
                var _bm = bvc__mix(_col, [118, 142, 78], bvc_rnd(_r) * 0.7);
                _c = bvc__rgb(bvc__shade(_bm, (bvc_rnd(_r) - 0.4) * 0.5));
                var _cxq = _x + (bvc_rnd(_r) - 0.5) * 4;
                var _exq = _x + (bvc_rnd(_r) - 0.5) * 7;
                bvc__stroke(bvc_k_quad(_x, _y, _cxq, _y - _bl * 0.6, _exq, _y - _bl, 4, [_x, _y]), 1.0, _c, _al);
            }
            break;
        default: // trodden
            for (_i = 0; _i < round(34 * _d); _i++) {
                _x = _b.x + bvc_rnd(_r) * _b.w; _y = _b.y + bvc_rnd(_r) * _b.h;
                _al = 0.10 + bvc_rnd(_r) * 0.14;
                _c = bvc__rgb(bvc__shade(_col, (bvc_rnd(_r) < 0.5) ? -0.28 : 0.20));
                var _trx = 7 + bvc_rnd(_r) * 16;
                var _try = 3 + bvc_rnd(_r) * 5;
                var _trot = bvc_rnd(_r) * 0.7;
                bvc_k_fill(bvc_k_ellipse(_x, _y, _trx, _try, _trot), _c, _al);
            }
            break;
    }
}

/// @function bvc__apron(op)
/// @description The worked earth: the body, a worn centre in falloff rings (a flat oval read as a stamp), the ground's
/// own treatment, and a rim that thins out rather than a cut edge, with a lit lip. Internal.
function bvc__apron(_op) {
    var _b = bvc__bbox(_op.outline), _r = bvc_rng((bvc_hash(_op.ground) ^ $1B873593) & $FFFFFFFF), _col = _op.chroma;
    var _path = bvc__smooth(_op.outline);
    if (bvc__k_ok(_path) == 0) return;
    bvc_k_fill(_path, bvc__rgb(_col), 1);
    if (!bvc_k_clip_push(_path)) return;
    var _cx = _b.x + _b.w / 2, _cy = _b.y + _b.h * 0.62, _worn = bvc__rgb(bvc__shade(_col, -0.30));
    // ⛔ LOOKED AT (2026-09-28, 1x): six rings stepped into visible contour bands. Eighteen rings over the same span, each
    // a third of the alpha, lay the same darkening as a smooth falloff.
    for (var _i = 18; _i >= 1; _i--) {
        var _t = _i / 18;
        bvc_k_fill(bvc_k_ellipse(_cx, _cy, _b.w * 0.40 * (0.44 + _t * 0.62), _b.h * 0.34 * (0.44 + _t * 0.62)), _worn, (0.13 + _op.wear * 0.10) * (1 - _t * 0.62) / 3);
    }
    bvc__ground_marks(_op.ground, _b, _r, _col);
    var _rim = bvc__rgb(bvc__shade(_col, -0.30));
    for (var _k = 0; _k < 6; _k++) bvc__stroke(_path, 3 + _k * 5, _rim, 0.30 * (1 - _k / 6), true);
    bvc__stroke(bvc__shift(_path, -BVC_LX * 2.6, -BVC_LY * 2.6), 2.2, bvc__rgb(bvc__shade(_col, 0.32)), 0.34, true);
    bvc_k_clip_pop();
}

// ================================================================================================ the marks

/// @function bvc__trail(op, kind, gap, wobble)
/// @description A line of prints walking in from one side toward the band (boot, claw or hoof). Internal.
function bvc__trail(_op, _kind, _gap, _wob) {
    var _r = bvc_rng(_op.seed), _y0 = _op.seat.y + 26, _x0 = _op.seat.x + _op.from * (_op.spread * 0.55 + 190);
    for (var _i = 0; _i < 9; _i++) {
        var _t = _i / 9;
        var _x = _x0 + (_op.seat.x - _x0) * _t + (bvc_rnd(_r) - 0.5) * _wob;
        var _y = _y0 - _t * 26 + (bvc_rnd(_r) - 0.5) * _wob * 0.6;
        var _side = ((_i mod 2) != 0) ? 1 : -1;
        var _al = (0.16 + bvc_rnd(_r) * 0.24) * (1 - _t * 0.35);
        var _sy = _y + _side * _gap;
        switch (_kind) {
            case "boot":
                bvc_k_fill(bvc_k_ellipse(_x, _sy, 4.4, 2.6, 0.2, 14), make_colour_rgb(28, 22, 16), _al);
                bvc_k_fill(bvc_k_ellipse(_x - 4.6, _sy - 0.6, 2.0, 1.7, 0.2, 10), make_colour_rgb(28, 22, 16), _al);
                break;
            case "claw":
                // ⛔ toes AROUND A PAD (MZ, measured: three strokes from one point read as an arrowhead)
                bvc_k_fill(bvc_k_ellipse(_x + 1.6, _sy, 2.6, 2.0, 0, 12), make_colour_rgb(26, 20, 14), _al);
                for (var _k = -1; _k <= 1; _k++) { var _tx = _x - 3.4 - bvc_rnd(_r) * 0.8; bvc_k_fill(bvc_k_ellipse(_tx, _sy + _k * 3.0, 1.5, 1.0, -0.3 + _k * 0.3, 8), make_colour_rgb(26, 20, 14), _al); }
                break;
            default:
                // ⛔ a FILLED CRESCENT, open at the back (MZ, measured: a stroked arc printed the letter C)
                var _cr = bvc__arc(_x, _sy, 4.4, 4.0, pi * 0.10, pi * 1.90, [], 14);
                bvc__arc(_x, _sy + 0.6, 2.5, 2.3, pi * 1.90, pi * 0.10, _cr, 10);
                bvc_k_fill(_cr, make_colour_rgb(24, 18, 14), _al);
                bvc_k_fill(bvc__arc(_x - 0.4, _sy - 0.6, 4.0, 3.5, pi * 1.06, pi * 1.94, [], 10), make_colour_rgb(24, 18, 14), _al);
                break;
        }
    }
}

/// @function bvc__mark(op)
/// @description One mark op in its own construction. Internal.
function bvc__mark(_op) {
    var _r = bvc_rng(_op.seed), _sx = _op.seat.x, _sy = _op.seat.y, _i, _k, _x, _y, _R, _al;
    switch (_op.mark) {
        case "boottrack": bvc__trail(_op, "boot", 5, 12); break;
        case "clawtrack": bvc__trail(_op, "claw", 6, 14); break;
        case "hooftrack": bvc__trail(_op, "hoof", 7, 11); break;
        case "dragtrack":
            var _dx0 = _sx + _op.from * (_op.spread * 0.6 + 200);
            var _dp = bvc_k_quad(_dx0, _sy + 30, (_dx0 + _sx) / 2, _sy + 38 + (bvc_rnd(_r) - 0.5) * 18, _sx, _sy + 14, 12, [_dx0, _sy + 30]);
            // ⛔ LOOKED AT (2026-09-28, 1x): at a flat alpha the drag read as a rope laid across the battleback. A drag
            // fades out where the ground stops being disturbed, as the MZ cart rut already does: alpha by t^0.85
            bvc__stroke_fade(_dp, 9, make_colour_rgb(30, 24, 18), 0.24);
            bvc__stroke_fade(_dp, 2.4, make_colour_rgb(210, 198, 176), 0.20);
            break;
        case "slithertrack":
            var _lx0 = _sx + _op.from * (_op.spread * 0.6 + 200), _lp = [_lx0, _sy + 30], _px = _lx0, _py = _sy + 30;
            for (_i = 1; _i <= 6; _i++) {
                var _t = _i / 6, _ex = _lx0 + (_sx - _lx0) * _t, _ey = _sy + 30 - _t * 16;
                bvc_k_quad(_px, _py, _lx0 + (_sx - _lx0) * (_t - 0.08), _sy + 30 + (((_i mod 2) != 0) ? 22 : -14), _ex, _ey, 6, _lp);
                _px = _ex; _py = _ey;
            }
            bvc__stroke_fade(_lp, 6, make_colour_rgb(32, 26, 20), 0.26);
            break;
        case "cartrut":
            // ⛔ each rut fades away from the band (MZ, measured: at a flat alpha the ruts read as two stray wires)
            var _cx0 = _sx + _op.from * (_op.spread * 0.7 + 230), _offs = [-11, 11];
            for (var _o = 0; _o < 2; _o++) {
                var _jit = (bvc_rnd(_r) - 0.5) * 12;
                for (_i = 0; _i < 12; _i++) {
                    var _t0 = _i / 12, _t1 = (_i + 1) / 12;
                    var _ax = _cx0 + (_sx - _cx0) * _t0, _ay = _sy + 34 + _offs[_o] + (16 - 34) * _t0 * 0.6 + _jit * sin(_t0 * 3);
                    var _bx = _cx0 + (_sx - _cx0) * _t1, _by = _sy + 34 + _offs[_o] + (16 - 34) * _t1 * 0.6 + _jit * sin(_t1 * 3);
                    bvc__stroke([_ax, _ay, _bx, _by], 3.0 + _t0 * 2.0, make_colour_rgb(28, 22, 16), 0.26 * power(_t0, 0.85));
                }
            }
            break;
        case "bloodslick":
            // ⛔ a pool has a smooth wandering edge and runs downhill (MZ, measured: a star polygon read as confetti)
            for (_i = 0; _i < 6; _i++) {
                _x = _sx + (bvc_rnd(_r) - 0.5) * _op.spread; _y = _sy + (bvc_rnd(_r) - 0.4) * 46;
                _R = 9 + bvc_rnd(_r) * 15;
                _al = 0.26 + bvc_rnd(_r) * 0.22;
                var _br = 84 + bvc_rnd(_r) * 30;
                var _bg = 18 + bvc_rnd(_r) * 10;
                var _bc = bvc__rgb([_br, _bg, 20]), _pp = [];
                for (_k = 0; _k <= 12; _k++) { var _a = (_k / 12) * 6.283, _rr = _R * (0.78 + 0.22 * sin(_a * 3 + _i) + bvc_rnd(_r) * 0.10); array_push(_pp, _x + cos(_a) * _rr, _y + sin(_a) * _rr * 0.46); }
                bvc_k_fill(_pp, _bc, _al);
                for (_k = 0; _k < 4; _k++) {
                    var _dal = 0.18 + bvc_rnd(_r) * 0.2;
                    var _ddx = _x + (bvc_rnd(_r) - 0.5) * _R * 2.4;
                    var _ddy = _y + (bvc_rnd(_r) - 0.2) * _R * 0.9;
                    var _drx = 1.0 + bvc_rnd(_r) * 2.0;
                    var _dry = 0.8 + bvc_rnd(_r) * 1.3;
                    bvc_k_fill(bvc_k_ellipse(_ddx, _ddy, _drx, _dry, 0, 10), _bc, _dal);
                }
            }
            break;
        case "scorchlick":
            // ⛔ char is irregular and glows at its EDGES (MZ, measured: a centred bright core read as a fried egg)
            for (_i = 0; _i < 8; _i++) {
                _x = _sx + (bvc_rnd(_r) - 0.5) * _op.spread; _y = _sy + (bvc_rnd(_r) - 0.35) * 40;
                _R = 9 + bvc_rnd(_r) * 15;
                _al = 0.24 + bvc_rnd(_r) * 0.26;
                var _sp = [];
                for (_k = 0; _k <= 11; _k++) { var _sa = (_k / 11) * 6.283, _srr = _R * (0.72 + 0.30 * sin(_sa * 2.4 + _i * 1.7)); array_push(_sp, _x + cos(_sa) * _srr, _y + sin(_sa) * _srr * 0.48); }
                bvc_k_fill(_sp, make_colour_rgb(26, 18, 14), _al);
                for (_k = 0; _k < 5; _k++) {
                    var _ga = bvc_rnd(_r) * 6.283;
                    var _gal = 0.30 + bvc_rnd(_r) * 0.34;
                    var _gr = 200 + bvc_rnd(_r) * 50;
                    var _gg = 90 + bvc_rnd(_r) * 50;
                    var _grx = 0.8 + bvc_rnd(_r) * 1.4;
                    var _gry = 0.6 + bvc_rnd(_r) * 1.0;
                    bvc_k_fill(bvc_k_ellipse(_x + cos(_ga) * _R * 0.82, _y + sin(_ga) * _R * 0.40, _grx, _gry, 0, 10), bvc__rgb([_gr, _gg, 30]), _gal);
                }
            }
            break;
        case "webstrand":
            for (_i = 0; _i < 9; _i++) {
                var _wx0 = _sx - _op.spread * 0.5 + bvc_rnd(_r) * _op.spread;
                var _wy0 = _sy - 10 - bvc_rnd(_r) * 40;
                var _wx1 = _wx0 + (bvc_rnd(_r) - 0.5) * 90;
                var _wy1 = _sy + bvc_rnd(_r) * 22;
                _al = 0.16 + bvc_rnd(_r) * 0.22;
                bvc__stroke(bvc_k_quad(_wx0, _wy0, (_wx0 + _wx1) / 2, (_wy0 + _wy1) / 2 + 12, _wx1, _wy1, 10, [_wx0, _wy0]), 0.9, make_colour_rgb(232, 230, 224), _al);
            }
            break;
        case "frostcreep":
            for (_i = 0; _i < 12; _i++) {
                _x = _sx + (bvc_rnd(_r) - 0.5) * _op.spread; _y = _sy + (bvc_rnd(_r) - 0.3) * 38;
                _al = 0.20 + bvc_rnd(_r) * 0.30;
                for (_k = 0; _k < 5; _k++) {
                    var _fa = bvc_rnd(_r) * 6.283, _fl = 5 + bvc_rnd(_r) * 12;
                    var _nx = _x + cos(_fa) * _fl, _ny = _y + sin(_fa) * _fl * 0.5;
                    bvc__stroke([_x, _y, _nx, _ny], 1.2, make_colour_rgb(214, 236, 246), _al);
                    _x = _nx; _y = _ny;
                }
            }
            break;
        case "sporebloom":
            for (_i = 0; _i < 26; _i++) {
                _x = _sx + (bvc_rnd(_r) - 0.5) * _op.spread; _y = _sy + (bvc_rnd(_r) - 0.3) * 44;
                _R = 1.4 + bvc_rnd(_r) * 3.4;
                _al = 0.28 + bvc_rnd(_r) * 0.34;
                var _pr = 148 + bvc_rnd(_r) * 50;
                var _pg = 128 + bvc_rnd(_r) * 40;
                var _pb = 168 + bvc_rnd(_r) * 40;
                bvc_k_fill(bvc_k_ellipse(_x, _y, _R, _R * 0.8, 0, 12), bvc__rgb([_pr, _pg, _pb]), _al);
                bvc_k_fill(bvc_k_ellipse(_x - _R * 0.3, _y - _R * 0.3, _R * 0.4, _R * 0.32, 0, 8), make_colour_rgb(248, 244, 252), 0.24);
            }
            break;
        case "bonescatter":
            for (_i = 0; _i < 11; _i++) {
                _x = _sx + (bvc_rnd(_r) - 0.5) * _op.spread * 1.1; _y = _sy + (bvc_rnd(_r) - 0.25) * 46;
                var _bL = 5 + bvc_rnd(_r) * 12, _ba = bvc_rnd(_r) * 3.14;
                _al = 0.42 + bvc_rnd(_r) * 0.3;
                var _bw = 2.2 + bvc_rnd(_r) * 1.6;
                bvc__beam(_x, _y, _x + cos(_ba) * _bL, _y + sin(_ba) * _bL * 0.5, _bw, "bone", { lip: 1.0, alpha: _al });
            }
            break;
        case "gouge":
            for (_i = 0; _i < 6; _i++) {
                _x = _sx + (bvc_rnd(_r) - 0.5) * _op.spread; _y = _sy + (bvc_rnd(_r) - 0.3) * 36;
                var _oa = -0.5 + bvc_rnd(_r) * 1.0, _oL = 22 + bvc_rnd(_r) * 40;
                bvc__stroke([_x, _y, _x + cos(_oa) * _oL, _y + sin(_oa) * _oL * 0.5], 3.4, make_colour_rgb(24, 18, 14), 0.34);
                bvc__stroke([_x, _y - 1.6, _x + cos(_oa) * _oL, _y + sin(_oa) * _oL * 0.5 - 1.6], 1.3, make_colour_rgb(190, 172, 140), 0.26);
            }
            break;
        case "wardring":
            var _wR = max(54, _op.spread * 0.52);
            bvc__stroke(bvc__arc(_sx, _sy + 8, _wR, _wR * 0.38, 0, 6.3, []), 2.0, make_colour_rgb(226, 216, 190), 0.34);
            bvc__stroke(bvc__arc(_sx, _sy + 8, _wR * 0.82, _wR * 0.31, 0, 6.3, []), 1.1, make_colour_rgb(226, 216, 190), 0.24);
            // the charges round it, at a declared pitch
            var _n = max(6, bvc__round((2 * pi * _wR) / 34));
            for (_i = 0; _i < _n; _i++) {
                var _wa = (_i / _n) * 6.283, _qx = _sx + cos(_wa) * _wR * 0.91, _qy = _sy + 8 + sin(_wa) * _wR * 0.345;
                _al = 0.30 + bvc_rnd(_r) * 0.2;
                bvc__stroke([_qx - 3, _qy - 3, _qx + 3, _qy + 3], 1.5, make_colour_rgb(232, 222, 198), _al);
                bvc__stroke([_qx + 3, _qy - 3, _qx - 3, _qy + 3], 1.5, make_colour_rgb(232, 222, 198), _al);
            }
            break;
        default: return false;
    }
    return true;
}

// ================================================================================================ furniture

/// @function bvc__q(points, cx, cy, x, y)
/// @description Append a quadratic curve from the last point of a flat point array. Internal.
function bvc__q(_p, _cx, _cy, _x, _y) { var _n = array_length(_p); return bvc_k_quad(_p[_n - 2], _p[_n - 1], _cx, _cy, _x, _y, 8, _p); }

/// @function bvc__flame(x, y, h, rng, scale)
/// @description A flame: a stack of round masses, hottest at the base. Internal.
function bvc__flame(_x, _y, _h, _r, _k) {
    for (var _i = 0; _i < 9; _i++) {
        var _t = _i / 9, _yy = _y - _t * _h;
        var _w = (7 - _t * 5) * _k * (0.8 + bvc_rnd(_r) * 0.5);
        var _fx = _x + (bvc_rnd(_r) - 0.5) * 5 * _k;
        bvc_k_fill(bvc_k_ellipse(_fx, _yy, max(1, _w), max(1.4, _w * 1.5)), bvc__rgb(bvc__mix([255, 226, 150], [214, 76, 26], _t)), 0.34 + (1 - _t) * 0.42);
    }
}

/// @function bvc__firelight(x, y, R)
/// @description The warm pool a fire throws on the ground under it. Internal.
function bvc__firelight(_x, _y, _R) {
    var _c = make_colour_rgb(240, 170, 84);
    bvc_k_fill(bvc_k_ellipse(_x, _y + 3, _R, _R * 0.36), _c, 0.20);
    bvc_k_fill(bvc_k_ellipse(_x, _y + 3, _R * 1.5, _R * 0.55), _c, 0.13);
}

/// @function bvc__lip3(lip, [tint], [amount], [alpha])
/// @description The options struct bvc__form reads. Internal.
function bvc__lip3(_lip, _tint = undefined, _amt = 0.25, _al = 1) { return { lip: _lip, tint: _tint, tintAmt: _amt, alpha: _al }; }

/// @function bvc_draw_piece(key, x, y, scale, rng)
/// @description Draw one piece of furniture standing with its foot at (x, y), `scale` 1 nominal (clamped 0.2..4), from a
/// seeded bvc_rng stream. Returns whether a construction exists for that key.
function bvc_draw_piece(_key, _x, _y, _scale, _r) {
    if (!bvc__piece_known(_key) || !bvc__fin(_x) || !bvc__fin(_y)) return false;
    if (!is_struct(_r)) _r = bvc_rng(1);
    var _s = bvc__clamp(_scale, 0.2, 4), _i, _k, _p;
    switch (_key) {
        case "campfire":
            bvc__firelight(_x, _y, 38 * _s);
            bvc__cast(_x, _y, 16 * _s, 16 * _s, 0.30);
            for (_i = 0; _i < 5; _i++) { var _a = (_i / 5) * pi + 0.25; bvc__beam(_x - cos(_a) * 17 * _s, _y + 2, _x + cos(_a) * 13 * _s, _y - 13 * _s, 4.6 * _s, "darkwood"); }
            for (_i = 0; _i < 6; _i++) { var _ex = _x + (bvc_rnd(_r) - 0.5) * 20 * _s; var _ey = _y + (bvc_rnd(_r) - 0.5) * 5 * _s; bvc__mass(_ex, _ey, 3.4 * _s, 2.2 * _s, "ember", bvc__lip3(0.8, undefined, 0.25, 0.75)); }
            bvc__flame(_x, _y - 8 * _s, 34 * _s, _r, _s);
            break;
        case "cookpot":
            bvc__cast(_x, _y, 13 * _s, 22 * _s, 0.34);
            for (_k = -1; _k <= 1; _k++) bvc__beam(_x + _k * 12 * _s, _y + 1, _x + _k * 2.4 * _s, _y - 30 * _s, 2.4 * _s, "timber");
            bvc__cord(_x - 6 * _s, _y - 27 * _s, _x + 6 * _s, _y - 27 * _s, 3 * _s, "rope");
            _p = [_x - 11 * _s, _y - 24 * _s, _x + 11 * _s, _y - 24 * _s];
            bvc__q(_p, _x + 13 * _s, _y - 10 * _s, _x, _y - 7 * _s); bvc__q(_p, _x - 13 * _s, _y - 10 * _s, _x - 11 * _s, _y - 24 * _s);
            bvc__form(_p, "metal", { lip: 2.2 });
            bvc__firelight(_x, _y, 20 * _s);
            break;
        case "spit":
            bvc__cast(_x, _y, 26 * _s, 26 * _s, 0.30);
            for (_k = -1; _k <= 1; _k += 2) { bvc__beam(_x + _k * 22 * _s, _y + 2, _x + _k * 15 * _s, _y - 30 * _s, 3.2 * _s, "timber"); bvc__beam(_x + _k * 12 * _s, _y + 2, _x + _k * 15 * _s, _y - 30 * _s, 2.6 * _s, "timber"); }
            bvc__beam(_x - 24 * _s, _y - 29 * _s, _x + 24 * _s, _y - 29 * _s, 2.0 * _s, "metal", { lip: 1.2 });
            // ⛔ a body threaded ON the spit - trunk, haunch, shank (MZ, measured: one flat ellipse read as a swing)
            _p = [_x - 15 * _s, _y - 27 * _s];
            bvc__q(_p, _x - 4 * _s, _y - 15 * _s, _x + 9 * _s, _y - 20 * _s); bvc__q(_p, _x + 17 * _s, _y - 24 * _s, _x + 14 * _s, _y - 29 * _s); bvc__q(_p, _x, _y - 33 * _s, _x - 15 * _s, _y - 27 * _s);
            bvc__form(_p, "hide", bvc__lip3(2.4, [148, 92, 58], 0.42));
            bvc__beam(_x + 8 * _s, _y - 21 * _s, _x + 15 * _s, _y - 13 * _s, 2.6 * _s, "hide", { lip: 1.2 });
            bvc__mass(_x + 15 * _s, _y - 12 * _s, 2.2 * _s, 2.6 * _s, "bone", { lip: 1.0 });
            bvc__beam(_x - 11 * _s, _y - 24 * _s, _x - 17 * _s, _y - 16 * _s, 2.2 * _s, "hide", { lip: 1.1 });
            bvc_k_fill(bvc_k_ellipse(_x - 2 * _s, _y - 22 * _s, 7 * _s, 3 * _s, -0.2), make_colour_rgb(42, 28, 20), 0.30);
            for (_i = 0; _i < 4; _i++) { var _sx2 = _x + (bvc_rnd(_r) - 0.5) * 26 * _s; bvc__mass(_sx2, _y + 1, 3 * _s, 1.8 * _s, "ember", bvc__lip3(0.7, undefined, 0.25, 0.7)); }
            bvc__firelight(_x, _y, 26 * _s);
            break;
        case "bedroll":
            // ⛔ a rolled cylinder: a flat end with the spiral, straps, a groundsheet (MZ, measured: a tapered lump read as a FISH)
            bvc__cast(_x, _y, 26 * _s, 10 * _s, 0.28);
            bvc_k_fill(bvc_k_ellipse(_x, _y + 2, 30 * _s, 7 * _s), make_colour_rgb(84, 76, 60), 0.28);
            _p = [_x - 24 * _s, _y - 1 * _s, _x + 20 * _s, _y - 1 * _s];
            bvc__q(_p, _x + 26 * _s, _y - 7 * _s, _x + 20 * _s, _y - 13 * _s); array_push(_p, _x - 24 * _s, _y - 13 * _s); bvc__q(_p, _x - 30 * _s, _y - 7 * _s, _x - 24 * _s, _y - 1 * _s);
            bvc__form(_p, "palecloth", { lip: 2.2 });
            bvc__form(bvc_k_ellipse(_x - 24 * _s, _y - 7 * _s, 5.4 * _s, 6.4 * _s), "palecloth", bvc__lip3(1.8, [140, 126, 100], 0.35));
            _p = [];
            for (_k = 0; _k < 22; _k++) { var _st = _k / 21, _sa = _st * 5.6, _rr = (1 + _st * 4.2) * _s; array_push(_p, _x - 24 * _s + cos(_sa) * _rr * 0.85, _y - 7 * _s + sin(_sa) * _rr); }
            bvc__stroke(_p, 1.1, make_colour_rgb(96, 86, 68), 0.45);
            for (_k = -8; _k <= 8; _k += 16) { bvc__beam(_x + _k * _s, _y - 14 * _s, _x + _k * _s, _y - 0.5 * _s, 2.4 * _s, "hide", { lip: 1.0 }); bvc__mass(_x + _k * _s, _y - 7 * _s, 1.8 * _s, 1.5 * _s, "metal", { lip: 0.8 }); }
            break;
        case "leanto":
            bvc__cast(_x, _y, 34 * _s, 40 * _s, 0.34);
            bvc__beam(_x - 30 * _s, _y + 2, _x + 24 * _s, _y - 40 * _s, 4.0 * _s, "timber");
            bvc__beam(_x + 30 * _s, _y + 2, _x + 24 * _s, _y - 40 * _s, 4.0 * _s, "timber");
            bvc__sheet(_x + 24 * _s, _y - 38 * _s, _x - 28 * _s, _y - 2 * _s, 7 * _s, 8 * _s, "hide", { lip: 2.4 });
            bvc__cord(_x + 24 * _s, _y - 40 * _s, _x + 44 * _s, _y + 2, 5 * _s, "rope");
            bvc__post(_x + 44 * _s, _y - 6 * _s, _y + 3, 3 * _s, "timber");
            break;
        case "stackedarms":
            bvc__cast(_x, _y, 20 * _s, 46 * _s, 0.34);
            for (_i = -2; _i <= 2; _i++) {
                var _ln = _i * 7 * _s;
                bvc__beam(_x + _ln * 1.9, _y + 2, _x + _ln * 0.3, _y - 48 * _s, 2.6 * _s, "timber");
                var _hx = _x + _ln * 0.3, _hy = _y - 48 * _s;
                _p = [_hx, _hy - 11 * _s]; bvc__q(_p, _hx + 3.4 * _s, _hy - 4 * _s, _hx, _hy + 2 * _s); bvc__q(_p, _hx - 3.4 * _s, _hy - 4 * _s, _hx, _hy - 11 * _s);
                bvc__form(_p, "metal", { lip: 1.4 });
            }
            bvc__cord(_x - 12 * _s, _y - 32 * _s, _x + 12 * _s, _y - 32 * _s, 3.4 * _s, "rope");
            break;
        case "shieldrest":
            // ⛔ a shield reads from its RIM and its device (MZ, measured: a plain heater with a boss read as a stone egg)
            bvc__cast(_x, _y, 26 * _s, 28 * _s, 0.32);
            bvc__post(_x - 22 * _s, _y - 14 * _s, _y + 2, 3.2 * _s, "timber", { lean: -2 * _s });
            bvc__post(_x + 22 * _s, _y - 24 * _s, _y + 2, 3.2 * _s, "timber", { lean: 2 * _s });
            bvc__beam(_x - 23 * _s, _y - 14 * _s, _x + 23 * _s, _y - 24 * _s, 3.4 * _s, "timber");
            for (_k = -1; _k <= 1; _k += 2) {
                var _shx = _x + _k * 13 * _s, _shy = _y - 16 * _s - _k * 6 * _s;
                var _body = [_shx, _shy - 15 * _s];
                bvc__q(_body, _shx + 12 * _s, _shy - 10 * _s, _shx + 10 * _s, _shy + 4 * _s); bvc__q(_body, _shx, _shy + 16 * _s, _shx - 10 * _s, _shy + 4 * _s); bvc__q(_body, _shx - 12 * _s, _shy - 10 * _s, _shx, _shy - 15 * _s);
                bvc__form(_body, (_k > 0) ? "timber" : "metal", bvc__lip3(2.4, (_k > 0) ? [128, 48, 42] : [72, 84, 110], 0.46));
                bvc__stroke(_body, 2.2 * _s, bvc__rgb(bvc__mat("metal").base), 0.75, true);
                for (_i = -1; _i <= 1; _i++) {
                    var _cx5 = _shx + _i * 5 * _s, _cp = [_cx5, _shy - 5 * _s];
                    bvc__q(_cp, _cx5 + 3 * _s, _shy, _cx5, _shy + 5 * _s); bvc__q(_cp, _cx5 - 3 * _s, _shy, _cx5, _shy - 5 * _s);
                    bvc_k_fill(_cp, bvc__rgb((_k > 0) ? [216, 198, 140] : [196, 206, 224]), 0.62);
                }
                bvc__mass(_shx, _shy - 10 * _s, 2.6 * _s, 2.4 * _s, "metal", { lip: 1.0 });
            }
            break;
        case "wardrum":
            bvc__cast(_x, _y, 20 * _s, 30 * _s, 0.34);
            for (_k = -1; _k <= 1; _k += 2) bvc__beam(_x + _k * 15 * _s, _y + 2, _x + _k * 5 * _s, _y - 20 * _s, 2.6 * _s, "timber");
            bvc__form([_x - 17 * _s, _y - 34 * _s, _x + 17 * _s, _y - 34 * _s, _x + 14 * _s, _y - 14 * _s, _x - 14 * _s, _y - 14 * _s], "darkwood", { lip: 2.2 });
            bvc__form(bvc_k_ellipse(_x, _y - 34 * _s, 17 * _s, 6.4 * _s), "hide", { lip: 2.0 });
            for (_i = 0; _i < 8; _i++) { var _da = (_i / 8) * 6.283; bvc__stroke([_x + cos(_da) * 16 * _s, _y - 34 * _s + sin(_da) * 6 * _s, _x + cos(_da) * 13 * _s, _y - 15 * _s], 1.2, make_colour_rgb(70, 56, 40), 0.5); }
            break;
        case "standard":
            bvc__cast(_x, _y, 9 * _s, 80 * _s, 0.40);
            bvc__post(_x, _y - 82 * _s, _y + 2, 3.6 * _s, "timber");
            for (_i = 0; _i < 3; _i++) bvc__mass(_x, _y - 84 * _s - _i * 5 * _s, (4.6 - _i * 1.1) * _s, (4.6 - _i * 1.1) * _s, "gold", { lip: 1.3 });
            bvc__sheet(_x + 2 * _s, _y - 78 * _s, _x + 34 * _s, _y - 70 * _s, 34 * _s, 5 * _s, "cloth", { lip: 2.6 });
            for (_i = 0; _i < 3; _i++) {
                var _cx2 = _x + 12 * _s + _i * 8 * _s, _cy2 = _y - 60 * _s + _i * 3 * _s, _ch = [_cx2, _cy2 - 5 * _s];
                bvc__q(_ch, _cx2 + 4 * _s, _cy2, _cx2, _cy2 + 5 * _s); bvc__q(_ch, _cx2 - 4 * _s, _cy2, _cx2, _cy2 - 5 * _s);
                bvc_k_fill(_ch, make_colour_rgb(224, 206, 150), 0.62);
            }
            for (_i = 0; _i < 3; _i++) bvc__cord(_x + 30 * _s, _y - 42 * _s + _i * 4 * _s, _x + 40 * _s, _y - 28 * _s + _i * 6 * _s, 4 * _s, "rope");
            break;
        case "palisade":
            bvc__cast(_x, _y, 46 * _s, 34 * _s, 0.34);
            bvc_k_fill(bvc_k_ellipse(_x, _y + 8 * _s, 52 * _s, 8 * _s), make_colour_rgb(30, 24, 18), 0.30);
            for (_i = -3; _i <= 3; _i++) {
                var _px = _x + _i * 15 * _s + (bvc_rnd(_r) - 0.5) * 4 * _s;
                var _ph = (30 + bvc_rnd(_r) * 16) * _s;
                var _pl = (bvc_rnd(_r) - 0.5) * 3 * _s;
                bvc__post(_px, _y - _ph, _y + 2, 5.2 * _s, "timber", { lean: _pl });
                bvc__form([_px - 2.6 * _s, _y - _ph, _px + 2.6 * _s, _y - _ph, _px, _y - _ph - 7 * _s], "timber", { lip: 1.2 });
            }
            bvc__cord(_x - 44 * _s, _y - 20 * _s, _x + 44 * _s, _y - 22 * _s, 6 * _s, "rope");
            break;
        case "chevaux":
            bvc__cast(_x, _y, 30 * _s, 24 * _s, 0.30);
            for (_i = -1; _i <= 1; _i++) {
                var _vx = _x + _i * 24 * _s;
                bvc__beam(_vx - 15 * _s, _y + 3, _vx + 15 * _s, _y - 28 * _s, 3.4 * _s, "timber");
                bvc__beam(_vx + 15 * _s, _y + 3, _vx - 15 * _s, _y - 28 * _s, 3.4 * _s, "timber");
                bvc__cord(_vx - 6 * _s, _y - 15 * _s, _vx + 6 * _s, _y - 15 * _s, 2.4 * _s, "rope");
            }
            break;
        case "totem":
            bvc__cast(_x, _y, 13 * _s, 66 * _s, 0.40);
            bvc__post(_x, _y - 70 * _s, _y + 2, 13 * _s, "darkwood");
            for (_k = 0; _k < 3; _k++) {
                var _ty = _y - 18 * _s - _k * 21 * _s;
                for (_i = -2; _i <= 2; _i++) bvc__mass(_x + _i * 3.1 * _s, _ty, 2.5 * _s, 3.4 * _s, "darkwood", { lip: 1.1 });
                bvc_k_fill(bvc_k_ellipse(_x, _ty - 6 * _s, 4.6 * _s, 2.4 * _s), bvc__rgb(((_k mod 2) != 0) ? [168, 82, 46] : [196, 176, 118]), 0.5);
            }
            bvc__form([_x - 14 * _s, _y - 70 * _s, _x + 14 * _s, _y - 70 * _s, _x + 8 * _s, _y - 82 * _s, _x - 8 * _s, _y - 82 * _s], "darkwood", { lip: 2.0 });
            break;
        case "altar":
            bvc__cast(_x, _y, 30 * _s, 26 * _s, 0.38);
            for (_k = -1; _k <= 1; _k += 2) bvc__post(_x + _k * 20 * _s, _y - 22 * _s, _y + 2, 11 * _s, "stone");
            bvc__form([_x - 32 * _s, _y - 24 * _s, _x + 32 * _s, _y - 24 * _s, _x + 28 * _s, _y - 31 * _s, _x - 28 * _s, _y - 31 * _s], "stone", { lip: 2.6 });
            bvc__mass(_x - 12 * _s, _y - 34 * _s, 4 * _s, 3.4 * _s, "gold", { lip: 1.3 });
            bvc__mass(_x + 12 * _s, _y - 34 * _s, 4 * _s, 3.4 * _s, "gold", { lip: 1.3 });
            _p = [_x - 5 * _s, _y - 33 * _s, _x + 5 * _s, _y - 33 * _s]; bvc__q(_p, _x, _y - 44 * _s, _x - 5 * _s, _y - 33 * _s);
            bvc__form(_p, "bone", { lip: 1.6 });
            bvc_k_fill(bvc_k_ellipse(_x, _y - 36 * _s, 26 * _s, 6 * _s), make_colour_rgb(210, 186, 120), 0.22);
            break;
        case "brazier":
            bvc__firelight(_x, _y, 30 * _s);
            bvc__cast(_x, _y, 13 * _s, 34 * _s, 0.34);
            for (_i = 0; _i < 3; _i++) { var _ba = (_i / 3) * 6.283 + 0.5; bvc__beam(_x + cos(_ba) * 11 * _s, _y + 2, _x, _y - 30 * _s, 2.6 * _s, "metal"); }
            _p = [_x - 15 * _s, _y - 30 * _s, _x + 15 * _s, _y - 30 * _s]; bvc__q(_p, _x + 11 * _s, _y - 19 * _s, _x, _y - 18 * _s); bvc__q(_p, _x - 11 * _s, _y - 19 * _s, _x - 15 * _s, _y - 30 * _s);
            bvc__form(_p, "rust", { lip: 2.2 });
            bvc__form(bvc_k_ellipse(_x, _y - 30 * _s, 15 * _s, 4.2 * _s), "rust", { lip: 1.6 });
            for (_i = 0; _i < 5; _i++) { var _bx2 = _x + (bvc_rnd(_r) - 0.5) * 20 * _s; bvc__mass(_bx2, _y - 31 * _s, 2.6 * _s, 1.5 * _s, "ember", bvc__lip3(0.6, undefined, 0.25, 0.8)); }
            bvc__flame(_x, _y - 32 * _s, 24 * _s, _r, _s * 0.8);
            break;
        case "carrionpost":
            bvc__cast(_x, _y, 8 * _s, 62 * _s, 0.38);
            bvc__post(_x, _y - 64 * _s, _y + 2, 4.6 * _s, "darkwood", { lean: 2 * _s });
            bvc__cord(_x - 9 * _s, _y - 60 * _s, _x + 9 * _s, _y - 58 * _s, 4 * _s, "rope");
            bvc__mass(_x + 1 * _s, _y - 52 * _s, 8 * _s, 7 * _s, "bone", { lip: 1.8 });
            bvc__mass(_x + 3 * _s, _y - 45 * _s, 5 * _s, 4.4 * _s, "bone", { lip: 1.5 });
            bvc_k_fill(bvc_k_ellipse(_x - 2 * _s, _y - 53 * _s, 2.3 * _s, 2.0 * _s), make_colour_rgb(24, 20, 18), 0.8);
            bvc_k_fill(bvc_k_ellipse(_x + 4.4 * _s, _y - 53 * _s, 2.3 * _s, 2.0 * _s), make_colour_rgb(24, 20, 18), 0.8);
            for (_i = 0; _i < 3; _i++) { var _hx2 = _x + (bvc_rnd(_r) - 0.5) * 16 * _s; bvc__cord(_x + 2 * _s, _y - 40 * _s, _hx2, _y - 24 * _s + _i * 5 * _s, 4 * _s, "rope"); }
            break;
        case "bonemidden":
            // ⛔ a PILE: a mound, bones ON it with knuckles, and one skull that names it (MZ, measured twice)
            bvc__cast(_x, _y, 26 * _s, 18 * _s, 0.32);
            _p = [_x - 30 * _s, _y + 2]; bvc__q(_p, _x - 14 * _s, _y - 15 * _s, _x + 4 * _s, _y - 14 * _s); bvc__q(_p, _x + 22 * _s, _y - 13 * _s, _x + 30 * _s, _y + 2);
            bvc__form(_p, "darkstone", { lip: 2.0 });
            for (_i = 0; _i < 15; _i++) {
                var _mx = _x + (bvc_rnd(_r) - 0.5) * 62 * _s;
                var _my = _y - 2 * _s - bvc_rnd(_r) * 14 * _s;
                var _ma = (bvc_rnd(_r) - 0.5) * 2.4;
                var _mL = (12 + bvc_rnd(_r) * 20) * _s;
                var _mw = (1.7 + bvc_rnd(_r) * 1.2) * _s;
                var _mex = _mx + cos(_ma) * _mL, _mey = _my + sin(_ma) * _mL * 0.38;
                var _age = 0.2 + bvc_rnd(_r) * 0.5, _mo = bvc__lip3(1.1, [128, 112, 86], _age);
                bvc__beam(_mx, _my, _mex, _mey, _mw, "bone", _mo);
                bvc__mass(_mx, _my, _mw * 1.5, _mw * 1.15, "bone", _mo);
                bvc__mass(_mex, _mey, _mw * 1.5, _mw * 1.15, "bone", _mo);
            }
            var _kx = _x + 14 * _s, _ky = _y - 24 * _s;
            bvc__mass(_kx, _ky, 11 * _s, 9 * _s, "bone", { lip: 2.2 });
            _p = [_kx + 4 * _s, _ky + 2 * _s]; bvc__q(_p, _kx + 17 * _s, _ky + 3 * _s, _kx + 15 * _s, _ky + 9 * _s); bvc__q(_p, _kx + 9 * _s, _ky + 12 * _s, _kx + 3 * _s, _ky + 8 * _s);
            bvc__form(_p, "bone", { lip: 1.7 });
            bvc_k_fill(bvc_k_ellipse(_kx - 1 * _s, _ky - 1 * _s, 3.0 * _s, 2.7 * _s, -0.2), make_colour_rgb(20, 16, 14), 0.88);
            bvc_k_fill(bvc_k_ellipse(_kx + 7.5 * _s, _ky + 0.5 * _s, 2.6 * _s, 2.4 * _s, -0.2), make_colour_rgb(20, 16, 14), 0.88);
            bvc_k_fill(bvc_k_ellipse(_kx + 9 * _s, _ky + 8 * _s, 4.5 * _s, 1.5 * _s, 0.1), make_colour_rgb(20, 16, 14), 0.88 * 0.55);
            break;
        case "cage":
            // ⛔ no panel: a dark void, bars over it, a gap between every pair, an occupant (MZ, measured: a crate)
            bvc__cast(_x, _y, 22 * _s, 36 * _s, 0.34);
            bvc_k_fill([_x - 18 * _s, _y + 1, _x + 18 * _s, _y + 1, _x + 15 * _s, _y - 35 * _s, _x - 15 * _s, _y - 35 * _s], make_colour_rgb(14, 11, 16), 0.72);
            bvc__mass(_x - 3 * _s, _y - 9 * _s, 8 * _s, 7 * _s, "hide", bvc__lip3(1.4, undefined, 0.25, 0.85));
            bvc__mass(_x + 5 * _s, _y - 15 * _s, 4.6 * _s, 4.2 * _s, "hide", bvc__lip3(1.2, undefined, 0.25, 0.85));
            var _n = max(4, bvc__round((36 * _s) / (7.5 * _s)));
            for (_i = 0; _i <= _n; _i++) { var _ct = _i / _n; bvc__beam(_x - 18 * _s + _ct * 36 * _s, _y + 1, _x - 15 * _s + _ct * 30 * _s, _y - 35 * _s, 1.9 * _s, "rust", { lip: 1.0 }); }
            var _rails = [-35, -22, -10, 1];
            for (_i = 0; _i < 4; _i++) { var _rk = 1 - abs(_rails[_i] + 17) / 52; bvc__beam(_x - (15 + 3 * _rk) * _s, _y + _rails[_i] * _s, _x + (15 + 3 * _rk) * _s, _y + _rails[_i] * _s, 2.6 * _s, "rust", { lip: 1.2 }); }
            bvc__mass(_x + 15 * _s, _y - 18 * _s, 2.8 * _s, 3.6 * _s, "metal", { lip: 1.1 });
            break;
        case "spoilpile":
            bvc__cast(_x, _y, 22 * _s, 14 * _s, 0.32);
            _p = [_x - 26 * _s, _y + 2]; bvc__q(_p, _x - 14 * _s, _y - 18 * _s, _x + 2 * _s, _y - 16 * _s); bvc__q(_p, _x + 20 * _s, _y - 14 * _s, _x + 26 * _s, _y + 2);
            bvc__form(_p, "hide", { lip: 2.2 });
            for (_i = 0; _i < 14; _i++) {
                var _gx = _x + (bvc_rnd(_r) - 0.5) * 42 * _s;
                var _gy = _y - bvc_rnd(_r) * 15 * _s;
                var _grx = (2.0 + bvc_rnd(_r) * 2.4) * _s;
                var _gry = (1.6 + bvc_rnd(_r) * 1.6) * _s;
                bvc__mass(_gx, _gy, _grx, _gry, "gold", { lip: 0.9 });
            }
            _p = [_x + 10 * _s, _y - 14 * _s, _x + 18 * _s, _y - 14 * _s]; bvc__q(_p, _x + 14 * _s, _y - 26 * _s, _x + 10 * _s, _y - 14 * _s);
            bvc__form(_p, "gold", { lip: 1.4 });
            break;
        case "crates":
            bvc__cast(_x, _y, 24 * _s, 28 * _s, 0.32);
            var _bxs = [_x - 13 * _s, _x + 15 * _s, _x - 10 * _s], _bys = [_y + 2, _y + 2, _y - 18 * _s], _bws = [15 * _s, 12 * _s, 11 * _s], _bhs = [19 * _s, 15 * _s, 14 * _s], _bms = ["timber", "timber", "darkwood"];
            for (_i = 0; _i < 3; _i++) {
                var _cbx = _bxs[_i], _cby = _bys[_i], _cw = _bws[_i], _chh = _bhs[_i];
                bvc__form([_cbx - _cw, _cby, _cbx + _cw, _cby, _cbx + _cw * 0.92, _cby - _chh, _cbx - _cw * 0.92, _cby - _chh], _bms[_i], { lip: 2.2 });
                bvc__stroke([_cbx - _cw, _cby, _cbx + _cw * 0.92, _cby - _chh], 1.3, make_colour_rgb(62, 46, 32), 0.4);
                bvc__stroke([_cbx + _cw, _cby, _cbx - _cw * 0.92, _cby - _chh], 1.3, make_colour_rgb(62, 46, 32), 0.4);
            }
            // a barrel is not a crate: a bellied form and hoops
            _p = [_x + 28 * _s, _y + 2]; bvc__q(_p, _x + 36 * _s, _y - 11 * _s, _x + 28 * _s, _y - 22 * _s); array_push(_p, _x + 16 * _s, _y - 22 * _s); bvc__q(_p, _x + 9 * _s, _y - 11 * _s, _x + 16 * _s, _y + 2);
            bvc__form(_p, "timber", { lip: 2.0 });
            bvc__stroke([_x + 16 * _s, _y - 6 * _s, _x + 28 * _s, _y - 6 * _s], 1.6, make_colour_rgb(84, 70, 56), 0.5);
            bvc__stroke([_x + 16 * _s, _y - 16 * _s, _x + 28 * _s, _y - 16 * _s], 1.6, make_colour_rgb(84, 70, 56), 0.5);
            break;
        case "dais":
            bvc__cast(_x, _y, 46 * _s, 30 * _s, 0.42);
            for (_k = 2; _k >= 0; _k--) {
                var _dw = (52 - _k * 10) * _s, _dh = 9 * _s, _dy = _y + 2 - _k * _dh;
                bvc__form([_x - _dw, _dy, _x + _dw, _dy, _x + _dw * 0.94, _dy - _dh, _x - _dw * 0.94, _dy - _dh], (_k == 2) ? "stone" : "darkstone", { lip: 2.4 });
            }
            var _sy = _y + 2 - 27 * _s;
            bvc__form([_x - 15 * _s, _sy, _x + 15 * _s, _sy, _x + 12 * _s, _sy - 34 * _s, _x - 12 * _s, _sy - 34 * _s], "darkstone", { lip: 2.4 });
            for (_k = -1; _k <= 1; _k += 2) bvc__form([_x + _k * 15 * _s, _sy, _x + _k * 19 * _s, _sy, _x + _k * 17 * _s, _sy - 16 * _s, _x + _k * 13 * _s, _sy - 16 * _s], "stone", { lip: 1.8 });
            bvc__form(bvc_k_ellipse(_x, _sy - 2 * _s, 14 * _s, 4.6 * _s), "cloth", { lip: 1.8 });
            for (_i = 0; _i < 3; _i++) bvc__mass(_x - 8 * _s + _i * 8 * _s, _sy - 36 * _s, 2.8 * _s, 3.4 * _s, "gold", { lip: 1.1 });
            break;
        case "hidedryer":
            bvc__cast(_x, _y, 28 * _s, 44 * _s, 0.32);
            for (_k = -1; _k <= 1; _k += 2) bvc__post(_x + _k * 26 * _s, _y - 46 * _s, _y + 2, 3.6 * _s, "timber");
            bvc__beam(_x - 28 * _s, _y - 46 * _s, _x + 28 * _s, _y - 47 * _s, 2.8 * _s, "timber");
            for (_i = -1; _i <= 1; _i++) {
                var _dx = _x + _i * 19 * _s, _hp = [_dx - 8 * _s, _y - 45 * _s, _dx + 8 * _s, _y - 45 * _s];
                bvc__q(_hp, _dx + 11 * _s, _y - 26 * _s, _dx + 5 * _s, _y - 16 * _s); bvc__q(_hp, _dx, _y - 12 * _s, _dx - 5 * _s, _y - 16 * _s); bvc__q(_hp, _dx - 11 * _s, _y - 26 * _s, _dx - 8 * _s, _y - 45 * _s);
                bvc__form(_hp, "hide", bvc__lip3(2.2, [150, 120, 82], (_i == 0) ? 0.4 : 0.1));
            }
            break;
        case "anvilstone":
            bvc__cast(_x, _y, 18 * _s, 22 * _s, 0.36);
            bvc__post(_x, _y - 14 * _s, _y + 2, 17 * _s, "darkwood");
            _p = [_x - 17 * _s, _y - 16 * _s, _x + 13 * _s, _y - 16 * _s]; bvc__q(_p, _x + 25 * _s, _y - 20 * _s, _x + 13 * _s, _y - 24 * _s); array_push(_p, _x - 15 * _s, _y - 24 * _s);
            bvc__form(_p, "metal", { lip: 2.4 });
            bvc__form([_x - 12 * _s, _y - 24 * _s, _x + 8 * _s, _y - 24 * _s, _x + 6 * _s, _y - 15 * _s, _x - 10 * _s, _y - 15 * _s], "metal", { lip: 1.6 });
            bvc__beam(_x + 18 * _s, _y + 2, _x + 24 * _s, _y - 20 * _s, 2.6 * _s, "timber");
            bvc__mass(_x + 24 * _s, _y - 22 * _s, 4.4 * _s, 3.2 * _s, "metal", { lip: 1.3 });
            break;
        case "cocoon":
            bvc__cast(_x, _y, 14 * _s, 40 * _s, 0.28);
            bvc__cord(_x - 20 * _s, _y - 62 * _s, _x + 2 * _s, _y - 48 * _s, 3 * _s, "rope");
            bvc__cord(_x + 22 * _s, _y - 60 * _s, _x + 2 * _s, _y - 48 * _s, 3 * _s, "rope");
            _p = [_x, _y - 50 * _s]; bvc__q(_p, _x + 15 * _s, _y - 34 * _s, _x + 7 * _s, _y - 6 * _s); bvc__q(_p, _x, _y + 4 * _s, _x - 7 * _s, _y - 6 * _s); bvc__q(_p, _x - 15 * _s, _y - 34 * _s, _x, _y - 50 * _s);
            bvc__form(_p, "palecloth", { lip: 2.4 });
            for (_i = 0; _i < 9; _i++) { var _wy = _y - 46 * _s + (_i / 9) * 44 * _s; bvc__stroke(bvc_k_quad(_x - 9 * _s, _wy, _x, _wy + 3 * _s, _x + 9 * _s, _wy - 1 * _s, 6, [_x - 9 * _s, _wy]), 1.0, make_colour_rgb(248, 246, 240), 0.36); }
            break;
        case "fungalcluster":
            bvc__cast(_x, _y, 20 * _s, 16 * _s, 0.26);
            for (_i = 0; _i < 7; _i++) {
                var _fx = _x + (bvc_rnd(_r) - 0.5) * 42 * _s;
                var _fh = (10 + bvc_rnd(_r) * 24) * _s;
                var _fw = (3.2 + bvc_rnd(_r) * 2) * _s;
                var _fl = (bvc_rnd(_r) - 0.5) * 2 * _s;
                bvc__post(_fx, _y - _fh, _y + 2, _fw, "fungus", { lean: _fl });
                var _cap = (6 + bvc_rnd(_r) * 9) * _s, _cp2 = [_fx - _cap, _y - _fh];
                bvc__q(_cp2, _fx, _y - _fh - _cap * 1.05, _fx + _cap, _y - _fh); bvc__q(_cp2, _fx, _y - _fh + _cap * 0.28, _fx - _cap, _y - _fh);
                var _tamt = 0.28 + bvc_rnd(_r) * 0.3;
                bvc__form(_cp2, "fungus", bvc__lip3(1.8, [186, 108, 142], _tamt));
                for (_k = 0; _k < 3; _k++) { var _spx = _fx + (bvc_rnd(_r) - 0.5) * _cap * 1.2; bvc_k_fill(bvc_k_ellipse(_spx, _y - _fh - _cap * 0.36, 1.2 * _s, 1.0 * _s, 0, 10), make_colour_rgb(252, 248, 254), 0.34); }
            }
            break;
        case "icecairn":
            bvc__cast(_x, _y, 18 * _s, 44 * _s, 0.24);
            for (_i = 0; _i < 6; _i++) {
                var _it = _i / 6;
                var _ix = _x + (bvc_rnd(_r) - 0.5) * 22 * _s * (1 - _it);
                var _ih = (34 - _it * 22) * _s, _iy = _y + 2 - _it * 26 * _s;
                bvc__form([_ix - 7 * _s * (1 - _it * 0.5), _iy, _ix + 7 * _s * (1 - _it * 0.5), _iy, _ix + 2 * _s, _iy - _ih, _ix - 3 * _s, _iy - _ih * 0.92], "ice", bvc__lip3(2.0, undefined, 0.25, 0.88));
            }
            bvc_k_fill(bvc_k_ellipse(_x, _y + 3, 30 * _s, 8 * _s), make_colour_rgb(206, 238, 250), 0.24);
            break;
        case "cindervent":
            bvc__firelight(_x, _y, 26 * _s);
            bvc__cast(_x, _y, 24 * _s, 12 * _s, 0.30);
            _p = [_x - 30 * _s, _y + 3]; bvc__q(_p, _x - 12 * _s, _y - 16 * _s, _x - 4 * _s, _y - 15 * _s); array_push(_p, _x + 6 * _s, _y - 15 * _s); bvc__q(_p, _x + 14 * _s, _y - 16 * _s, _x + 30 * _s, _y + 3);
            bvc__form(_p, "darkstone", { lip: 2.4 });
            bvc_k_fill(bvc_k_ellipse(_x + 1 * _s, _y - 14 * _s, 6 * _s, 2.4 * _s), make_colour_rgb(212, 92, 28), 0.8);
            for (_i = 0; _i < 7; _i++) { var _ctt = _i / 7, _cvx = _x + (bvc_rnd(_r) - 0.5) * 14 * _s; bvc_k_fill(bvc_k_ellipse(_cvx, _y - 18 * _s - _ctt * 30 * _s, (2.4 - _ctt * 1.4) * _s, (2.4 - _ctt * 1.4) * _s, 0, 12), bvc__rgb(bvc__mix([255, 208, 130], [140, 60, 30], _ctt)), 0.5 - _ctt * 0.42); }
            break;
        case "reedbundle":
            bvc__cast(_x, _y, 13 * _s, 40 * _s, 0.26);
            for (_i = 0; _i < 11; _i++) {
                var _rl = (bvc_rnd(_r) - 0.5) * 16 * _s;
                var _rh = (28 + bvc_rnd(_r) * 22) * _s;
                var _rw = (1.8 + bvc_rnd(_r)) * _s;
                bvc__beam(_x + _rl * 0.3, _y + 2, _x + _rl, _y - _rh, _rw, "reed", { lip: 0.9 });
                var _rp = [_x + _rl, _y - _rh]; bvc__q(_rp, _x + _rl + 2.4 * _s, _y - _rh - 5 * _s, _x + _rl, _y - _rh - 9 * _s); bvc__q(_rp, _x + _rl - 2.4 * _s, _y - _rh - 5 * _s, _x + _rl, _y - _rh);
                bvc__form(_rp, "reed", bvc__lip3(0.9, [124, 96, 52], 0.4));
            }
            bvc__cord(_x - 9 * _s, _y - 20 * _s, _x + 9 * _s, _y - 20 * _s, 2.6 * _s, "rope");
            break;
        case "rootknot":
            bvc__cast(_x, _y, 30 * _s, 20 * _s, 0.34);
            bvc__mass(_x, _y - 12 * _s, 20 * _s, 13 * _s, "darkwood", { lip: 2.4 });
            for (_i = 0; _i < 8; _i++) {
                var _ra = (_i / 8) * 6.283, _rL = (18 + bvc_rnd(_r) * 24) * _s;
                var _rex = _x + cos(_ra) * _rL, _rey = _y - 6 * _s + sin(_ra) * _rL * 0.42;
                bvc__beam(_x, _y - 10 * _s, _rex, _rey, (4.4 - abs(sin(_ra)) * 1.6) * _s, "darkwood", { lip: 1.4 });
                bvc__mass(_rex, _rey, 2.6 * _s, 2.0 * _s, "darkwood", { lip: 1.0 });
            }
            for (_i = 0; _i < 9; _i++) {
                var _mox = _x + (bvc_rnd(_r) - 0.5) * 42 * _s;
                var _moy = _y - 14 * _s - bvc_rnd(_r) * 12 * _s;
                var _mor = bvc_rnd(_r);
                bvc_k_fill(bvc_k_ellipse(_mox, _moy, 2.8 * _s, 1.8 * _s, _mor, 12), make_colour_rgb(96, 118, 74), 0.30);
            }
            break;
    }
    return true;
}

// ================================================================================================ the whole program

/// @function bvc_corpus()
/// @description {grounds, marks, furniture}: every key this file can draw, read from the constructions (a probe compares
/// it with the vocabulary tables rather than with a typed number).
function bvc_corpus() {
    var _g = bvc_grounds(), _m = [], _f = [], _i, _k = bvc_marks();
    for (_i = 0; _i < array_length(_k); _i++) if (bvc__mark_known(_k[_i])) array_push(_m, _k[_i]);
    var _fk = bvc_furniture();
    for (_i = 0; _i < array_length(_fk); _i++) if (bvc__piece_known(_fk[_i])) array_push(_f, _fk[_i]);
    return { grounds: _g, marks: _m, furniture: _f };
}

/// @function bvc__mark_known(key)
function bvc__mark_known(_k) { switch (_k) { case "boottrack": case "clawtrack": case "hooftrack": case "dragtrack": case "slithertrack": case "cartrut": case "bloodslick": case "scorchlick": case "webstrand": case "frostcreep": case "sporebloom": case "bonescatter": case "gouge": case "wardring": return true; } return false; }

/// @function bvc__piece_known(key)
function bvc__piece_known(_k) { return is_string(_k) && bvc__index(bvc_furniture(), _k) >= 0; }

/// @function bvc_draw(program, [opts])
/// @description Draw a whole program into the current target in program order (apron, marks, furniture, shadows). The
/// target must have a stencil buffer (bvc_k_surface); call bvc_k_begin first. opts {shadow_strength (0.40)}.
/// Returns {drawn, skipped}.
function bvc_draw(_p, _o = undefined) {
    var _drawn = 0, _skipped = [];
    if (!is_struct(_p) || !variable_struct_exists(_p, "ops") || !is_array(_p.ops)) return { drawn: 0, skipped: ["not a program"] };
    var _ss = bvc__clamp(bvc__get(_o, "shadow_strength", 0.40), 0, 1);
    for (var _i = 0; _i < array_length(_p.ops); _i++) {
        var _op = _p.ops[_i];
        if (!is_struct(_op) || !variable_struct_exists(_op, "op")) { array_push(_skipped, "op:?"); continue; }
        switch (_op.op) {
            case "apron": bvc__apron(_op); _drawn++; break;
            case "mark":
                // ⛔ a scatter mark off the worked ground reads as litter; tracks carry no clip on purpose
                var _clipped = is_array(_op.clip) && array_length(_op.clip) >= 3 && bvc_k_clip_push(bvc__smooth(_op.clip));
                if (bvc__mark(_op)) _drawn++; else array_push(_skipped, "mark:" + string(_op.mark));
                if (_clipped) bvc_k_clip_pop();
                break;
            case "furniture":
                if (bvc_draw_piece(_op.piece, _op.x, _op.y, _op.scale, bvc_rng(_op.seed))) _drawn++; else array_push(_skipped, "furniture:" + string(_op.piece));
                break;
            case "shadow": bvc__cast(_op.x, _op.y, 20 * _op.weight, 46 * _op.weight, _ss); _drawn++; break;
            default: array_push(_skipped, "op:" + string(_op.op));
        }
    }
    return { drawn: _drawn, skipped: _skipped };
}

/// @function bvc_bake(program, [opts])
/// @description Draw a program once into a sprite the size of its field (the reading's width x height), drawn at
/// `supersample` x and filtered down. Returns the sprite (sprite_delete it when the battle ends), or -1 for a
/// non-program. The sprite is PREMULTIPLIED: draw it with bvc_ground_draw. opts {supersample (2), shadow_strength}.
/// ⛔ Baked, not drawn per frame: a whole ground is hundreds of fills (MEASURED cost in the suite's notes).
function bvc_bake(_p, _o = undefined) {
    if (!is_struct(_p) || !variable_struct_exists(_p, "ops")) return -1;
    var _rd = bvc__get(_p, "reading", undefined);
    var _fw = is_struct(_rd) ? _rd.field.w : BVC_FIELD_W, _fh = is_struct(_rd) ? _rd.field.h : BVC_FIELD_H;
    var _k = clamp(floor(bvc__n(bvc__get(_o, "supersample", 2), 2)), 1, 3);
    var _big = bvc_k_surface(_fw * _k, _fh * _k), _m0 = matrix_get(matrix_world);
    surface_set_target(_big);
    draw_clear_alpha(c_black, 0);
    bvc_k_begin();
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    matrix_set(matrix_world, matrix_build(0, 0, 0, 0, 0, 0, _k, _k, 1));
    var _res = bvc_draw(_p, _o);
    // ⛔ FOUND BY LOOKING (2026-09-28, the store bake): the caller's world matrix was restored HERE, before the
    // downsample below, so a bake called under any transform (the store sheets' 2x; a buyer's camera or scaled Draw)
    // drew its 2x surface at full size and kept only the empty top-left quarter. The suite and the buyer harness baked
    // under an identity matrix and could not see it. Every internal pass runs under identity; the caller's matrix is
    // restored once, at the end.
    matrix_set(matrix_world, matrix_build_identity());
    gpu_pop_state();
    surface_reset_target();
    var _small = surface_create(_fw, _fh);
    surface_set_target(_small);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    gpu_set_blendmode_ext(bm_one, bm_zero);
    gpu_set_texfilter(true);
    draw_surface_ext(_big, 0, 0, 1 / _k, 1 / _k, 0, c_white, 1);
    gpu_pop_state();
    surface_reset_target();
    var _spr = sprite_create_from_surface(_small, 0, 0, _fw, _fh, false, false, 0, 0);
    surface_free(_big);
    surface_free(_small);
    matrix_set(matrix_world, _m0);
    global.bvc_last_bake = _res;
    return _spr;
}

/// @function bvc_ground_draw(sprite, x, y, [scale])
/// @description Draw a baked ground with its top-left at (x, y): premultiplied, so blended one / inverse-source-alpha.
function bvc_ground_draw(_spr, _x, _y, _scale = 1) {
    if (!is_numeric(_spr) || !sprite_exists(_spr)) return;
    gpu_push_state();
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    draw_sprite_ext(_spr, 0, bvc__n(_x, 0), bvc__n(_y, 0), bvc__n(_scale, 1), bvc__n(_scale, 1), 0, c_white, 1);
    gpu_pop_state();
}
