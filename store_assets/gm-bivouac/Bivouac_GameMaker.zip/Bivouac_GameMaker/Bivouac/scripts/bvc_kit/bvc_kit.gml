/// bvc_kit.gml - Bivouac's drawing kit: fill ANY polygon (concave or self-crossing, even-odd rule) and clip drawing to
/// ANY polygon, through the stencil buffer ("stencil, then cover"). This is what a canvas does with fill() and clip(),
/// and what a triangle fan cannot do: a fan fills a concave outline's notches (Doctrine_Craft s3 - a crescent drawn as a
/// quarter). Used by bvc_draw; you only need it if you draw your own shapes into a Bivouac surface.
///
/// Bivouac - Every Enemy Band Stages Its Own Ground, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// PUBLIC
///   bvc_k_surface(w, h)                 -> a surface WITH a stencil buffer (the kit draws only into one of these)
///   bvc_k_begin()                       -> clear the current target's stencil and the clip stack (once per target)
///   bvc_k_fill(points, colour, alpha)   -> fill a polygon given as a flat array [x0, y0, x1, y1, ...]
///   bvc_k_clip_push(points) / bvc_k_clip_pop() -> restrict every kit fill (and bvc_k_clipped_begin draws) to a polygon;
///                                          clips nest (up to 6) and intersect
///   bvc_k_clipped_begin() / bvc_k_clipped_end() -> let ordinary draw_* calls respect the current clip
///   bvc_k_ellipse(cx, cy, rx, ry, [rot], [seg]) / bvc_k_quad(x0, y0, cx, cy, x1, y1, [seg], [out]) -> flat point arrays
/// ⛔ The target must have a stencil buffer: a surface made by bvc_k_surface (depth enabled at creation). The fan that
/// writes the stencil is flushed every 900 vertices (one primitive batch silently drops vertices past its limit -
/// Doctrine_Craft s7b).

global.bvc_k_clipmask = 0;
global.bvc_k_clips = [];

/// @function bvc_k_surface(w, h)
/// @description A surface with a depth-stencil buffer, whatever the game's own surface_depth_disable setting is (it is
/// restored). Free it with surface_free.
function bvc_k_surface(_w, _h) {
    var _prev = surface_get_depth_disable();
    surface_depth_disable(false);
    var _s = surface_create(max(1, floor(bvc__n(_w, 1))), max(1, floor(bvc__n(_h, 1))));
    surface_depth_disable(_prev);
    return _s;
}

/// @function bvc_k_begin()
/// @description Clear the current target's stencil to 0 and forget every clip. Call once after surface_set_target.
function bvc_k_begin() {
    draw_clear_stencil(0);
    global.bvc_k_clipmask = 0;
    global.bvc_k_clips = [];
}

/// @function bvc__k_fan(points, n)
/// @description The triangles from point 0 to every edge (colour is irrelevant: colour writes are off). Internal.
function bvc__k_fan(_p, _n) {
    var _v = 0;
    draw_primitive_begin(pr_trianglelist);
    for (var _i = 1; _i < _n - 1; _i++) {
        draw_vertex(_p[0], _p[1]);
        draw_vertex(_p[_i * 2], _p[_i * 2 + 1]);
        draw_vertex(_p[_i * 2 + 2], _p[_i * 2 + 3]);
        _v += 3;
        if (_v >= 900) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); _v = 0; }
    }
    draw_primitive_end();
}

/// @function bvc__k_ok(points)
/// @description The point count of a usable flat point array (>= 3 finite points), else 0. Internal.
function bvc__k_ok(_p) {
    if (!is_array(_p)) return 0;
    var _n = array_length(_p) div 2;
    if (_n < 3) return 0;
    for (var _i = 0; _i < _n * 2; _i++) if (!bvc__fin(_p[_i])) return 0;
    return _n;
}

/// @function bvc__k_stencil_write(points, n, bits)
/// @description Invert `bits` of the stencil over the polygon (even-odd), with colour writes off. Internal.
function bvc__k_stencil_write(_p, _n, _bits) {
    gpu_set_ztestenable(false);
    gpu_set_zwriteenable(false);
    gpu_set_stencil_enable(true);
    gpu_set_colourwriteenable(false, false, false, false);
    gpu_set_stencil_func(cmpfunc_always);
    gpu_set_stencil_read_mask(255);
    gpu_set_stencil_write_mask(_bits);
    gpu_set_stencil_pass(stencilop_invert);
    gpu_set_stencil_fail(stencilop_keep);
    gpu_set_stencil_depth_fail(stencilop_invert);
    bvc__k_fan(_p, _n);
    gpu_set_colourwriteenable(true, true, true, true);
}

/// @function bvc_k_fill(points, colour, alpha)
/// @description Fill a polygon (flat array [x0, y0, x1, y1, ...]; concave and self-crossing are fine, even-odd rule)
/// with a colour at an alpha, inside the current clip. Blending is the caller's. Refuses (draws nothing) on bad input.
function bvc_k_fill(_p, _col, _al = 1) {
    var _n = bvc__k_ok(_p);
    if (_n == 0) return;
    var _x0 = infinity, _y0 = infinity, _x1 = -infinity, _y1 = -infinity, _i;
    for (_i = 0; _i < _n; _i++) { _x0 = min(_x0, _p[_i * 2]); _x1 = max(_x1, _p[_i * 2]); _y0 = min(_y0, _p[_i * 2 + 1]); _y1 = max(_y1, _p[_i * 2 + 1]); }
    var _m = global.bvc_k_clipmask, _c = is_numeric(_col) ? _col : c_white, _a = bvc__clamp(_al, 0, 1);
    gpu_push_state();
    bvc__k_stencil_write(_p, _n, 1);
    // cover the box: where bit 1 AND every clip bit is set, paint; bit 1 is cleared everywhere either way
    gpu_set_stencil_ref(1 | _m);
    gpu_set_stencil_read_mask(1 | _m);
    gpu_set_stencil_func(cmpfunc_equal);
    gpu_set_stencil_write_mask(1);
    gpu_set_stencil_pass(stencilop_zero);
    gpu_set_stencil_fail(stencilop_zero);
    draw_primitive_begin(pr_trianglestrip);
    draw_vertex_colour(_x0 - 1, _y0 - 1, _c, _a); draw_vertex_colour(_x1 + 1, _y0 - 1, _c, _a);
    draw_vertex_colour(_x0 - 1, _y1 + 1, _c, _a); draw_vertex_colour(_x1 + 1, _y1 + 1, _c, _a);
    draw_primitive_end();
    gpu_pop_state();
}

/// @function bvc_k_clip_push(points)
/// @description Restrict every kit fill (and ordinary draws between bvc_k_clipped_begin/end) to the polygon, intersected
/// with any clip already pushed. Returns false (and clips nothing) when 6 clips are already pushed or the points are bad.
function bvc_k_clip_push(_p) {
    var _n = bvc__k_ok(_p);
    if (_n == 0 || array_length(global.bvc_k_clips) >= 6) return false;
    var _bit = 2 << array_length(global.bvc_k_clips);
    gpu_push_state();
    bvc__k_stencil_write(_p, _n, _bit);
    gpu_pop_state();
    array_push(global.bvc_k_clips, { p: _p, n: _n, bit: _bit });
    global.bvc_k_clipmask = global.bvc_k_clipmask | _bit;
    return true;
}

/// @function bvc_k_clip_pop()
/// @description Remove the last clip (its polygon is written again, which restores its stencil bit exactly).
function bvc_k_clip_pop() {
    if (array_length(global.bvc_k_clips) == 0) return;
    var _c = array_pop(global.bvc_k_clips);
    gpu_push_state();
    bvc__k_stencil_write(_c.p, _c.n, _c.bit);
    gpu_pop_state();
    global.bvc_k_clipmask = global.bvc_k_clipmask & ~_c.bit;
}

/// @function bvc_k_clipped_begin()
/// @description Make ordinary draw_* calls respect the current clip until bvc_k_clipped_end (pushes the GPU state).
function bvc_k_clipped_begin() {
    gpu_push_state();
    var _m = global.bvc_k_clipmask;
    if (_m == 0) return;
    gpu_set_stencil_enable(true);
    gpu_set_stencil_ref(_m);
    gpu_set_stencil_read_mask(_m);
    gpu_set_stencil_write_mask(0);
    gpu_set_stencil_func(cmpfunc_equal);
    gpu_set_stencil_pass(stencilop_keep);
    gpu_set_stencil_fail(stencilop_keep);
    gpu_set_stencil_depth_fail(stencilop_keep);
}

/// @function bvc_k_clipped_end()
function bvc_k_clipped_end() { gpu_pop_state(); }

/// @function bvc_k_ellipse(cx, cy, rx, ry, [rot], [seg])
/// @description A flat point array round an ellipse (rot in radians); seg defaults to one point per ~4 px of rim.
function bvc_k_ellipse(_cx, _cy, _rx, _ry, _rot = 0, _seg = 0) {
    if (!bvc__fin(_cx) || !bvc__fin(_cy) || !bvc__fin(_rx) || !bvc__fin(_ry)) return [];
    _rx = max(0.3, abs(_rx)); _ry = max(0.3, abs(_ry));
    var _n = (bvc__fin(_seg) && _seg >= 3) ? floor(_seg) : clamp(ceil(pi * (_rx + _ry) / 4), 12, 96);
    var _cr = cos(bvc__n(_rot, 0)), _sr = sin(bvc__n(_rot, 0)), _out = array_create(_n * 2);
    for (var _i = 0; _i < _n; _i++) {
        var _t = _i / _n * 2 * pi, _ex = cos(_t) * _rx, _ey = sin(_t) * _ry;
        _out[_i * 2] = _cx + _ex * _cr - _ey * _sr;
        _out[_i * 2 + 1] = _cy + _ex * _sr + _ey * _cr;
    }
    return _out;
}

/// @function bvc_k_quad(x0, y0, cx, cy, x1, y1, [seg], [out])
/// @description Points along a quadratic curve (excluding the start point), appended to `out` (or a new array).
function bvc_k_quad(_x0, _y0, _cx, _cy, _x1, _y1, _seg = 8, _out = undefined) {
    if (!is_array(_out)) _out = [];
    // ⛔ found by the adversarial pass: arithmetic on undefined THREW inside the caller's draw; a curve with a
    // coordinate that is not a number adds nothing
    if (!bvc__fin(_x0) || !bvc__fin(_y0) || !bvc__fin(_cx) || !bvc__fin(_cy) || !bvc__fin(_x1) || !bvc__fin(_y1)) return _out;
    var _n = max(1, floor(bvc__n(_seg, 8)));
    for (var _i = 1; _i <= _n; _i++) {
        var _t = _i / _n, _u = 1 - _t;
        array_push(_out, _u * _u * _x0 + 2 * _u * _t * _cx + _t * _t * _x1, _u * _u * _y0 + 2 * _u * _t * _cy + _t * _t * _y1);
    }
    return _out;
}
