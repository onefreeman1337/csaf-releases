{
  "$GMScript": "v1",
  "%Name": "bvc_kit",
  "name": "bvc_kit",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}