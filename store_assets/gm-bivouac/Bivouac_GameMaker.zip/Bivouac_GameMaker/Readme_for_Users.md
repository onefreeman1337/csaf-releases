# Bivouac - Every Enemy Band Stages Its Own Ground, for GameMaker

**GameMaker 2024.14 or newer · pure GML · no sprites, no shaders, no extensions**
Core Systems Asset Factory · <https://csaf.itch.io>

Most battle screens give every enemy the same nothing to stand on. A goblin rabble and a demon lord float at the
same height over the same backdrop, casting no shadow and leaving no trace.

Bivouac reads the band a battle starts with and draws the ground that band holds:

- **the worked earth** beneath them, shaped by where the members of that band actually stand
- **cast shadows** that seat every battler on it
- **the things the band brought and set down**: a fire and a spit for a rabble, a standard for a host, a dais for
  a champion
- **the marks it leaves**: tracks leading in from the direction it came, and whatever that band does to the ground

Everything is decided by the band and your own bestiary, and everything is drawn in code.
**Nothing here is an image file.** It is for front-view and side-view battle screens; grid tactics, cover, line of
sight and elevation are out of scope.

---

## Quick start

1. **Tools > Import Local Package**, choose `Bivouac.yymps`, import everything.
2. Open `rm_bvc_demo` and press Play: seventeen bands, each on its own ground. Enter or click for the next one.
3. In your own battle, bake the ground once when the battle starts and draw it BEHIND your battlers:

```gml
// Create (when the battle starts)
my_program = bvc_compose(my_encounter, my_bestiary, { width: 816, height: 624, times_fought: my_fights });
my_ground = bvc_bake(my_program);

// Draw, BEFORE your battlers (the ground's top-left sits at the battle field's top-left)
bvc_ground_draw(my_ground, my_field_x, my_field_y);

// Clean Up (when the battle ends)
if (sprite_exists(my_ground)) sprite_delete(my_ground);
```

`bvc_bake` draws the whole ground once into a sprite the size of your battle field. Draw it with
`bvc_ground_draw`, which sets the right blend for it (the sprite is premultiplied).

### What you pass in

**Your bestiary** is every enemy in your game, as an array or a struct of structs. Standing is measured against
it, so "strong" means strong for YOUR game:

```gml
my_bestiary = [
    { name: "Hedge Bandit", hp: 180, mp: 0, atk: 26, def: 14, mat: 6, mdf: 10, agi: 18, luk: 10, exp: 18, gold: 30 },
    { name: "Cinder Adept", hp: 150, mp: 60, atk: 8, def: 10, mat: 38, mdf: 20, agi: 12, luk: 10, exp: 34, gold: 40,
      strikes: ["fire"], weak: ["ice"], resists: [] },
];
```

**An encounter** is who is in the band and where each battler's FEET are, in battle-field pixels. `enemy` is the
enemy's index (or key) in your bestiary, or the enemy struct itself:

```gml
my_encounter = { id: 5, name: "Cinder coven", members: [
    { enemy: 1, x: 360, y: 410 }, { enemy: 1, x: 460, y: 420 }, { enemy: 0, x: 560, y: 400, hidden: true } ] };
```

The encounter's name and id seed every choice, so the same band always stages the same ground.

---

## What it reads, and what it decides

| It reads | It decides |
| --- | --- |
| Where the members stand | The shape of the worked ground, and where the furniture stands |
| Each enemy's `atk`, `def`, `mat`, `mdf`, `agi`, `hp`, `mp` | Its *nature*: raider (attack-led), warded (defence-led), quick (agility-led), adept (magic-led) or great (vitality-led) |
| The band's `exp`, against your whole bestiary | Its *standing*: rabble, band, warband, host or champion |
| The elements its members strike with | What the earth looks like (fire scorch, ice rime, water mire, earth hardpan, dark blight, wind drift) |
| `times_fought` | How worn the ground is |

**Standing is relative to your game.** A band's place on the ladder is its place in YOUR bestiary, so rebalancing
your numbers rebalances the staging with them. **Nature is read from the shape of a creature's numbers, not their
size**: a bestiary where every number is ten times larger stages identically (the test suite checks this).

Element names are `physical`, `fire`, `ice`, `thunder`, `water`, `earth`, `wind`, `light`, `dark` (case does not
matter), or RPG Maker style ids 1 to 9. Any other name is kept and simply does not choose a ground.

## What gets drawn

**10 grounds**: trodden, hardpan, ashbed, rime, mire, scorch, blight, drift, flagstone, sward.

**14 marks**: boot, claw and hoof tracks, drag and slither tracks, cart ruts, a blood slick, scorch licks, web strands,
frost creep, a spore bloom, bone scatter, gouges and a ward ring.

**28 pieces of furniture**, each its own construction: campfire, cook pot, spit, bedroll, lean-to, stacked arms,
shield rest, war drum, standard, palisade, chevaux-de-frise, totem, altar, brazier, carrion post, bone midden, cage,
spoil pile, crates, dais, hide dryer, anvil stone, cocoon, fungal cluster, ice cairn, cinder vent, reed bundle and
root knot. Which pieces a band fields depends on what its members are and where it sits on your ladder: a rabble
gets crates and a spit, and only a champion gets a dais.

---

## The functions

### Composing (pure logic, nothing drawn)

| Function | Returns |
| --- | --- |
| `bvc_compose(encounter, bestiary, [opts])` | A program `{ops, meta, reading}`: the whole job in one call. `opts`: `width`, `height` (the battle field, default 816 x 624), `times_fought` |
| `bvc_read(encounter, bestiary, [opts])` | A reading: `nature`, `standing`, `standingTier`, `hull`, `elements`, `members`, `visible`, `lead`, `seed` |
| `bvc_plan(reading, [opts])` | A program `{ops, meta}` in draw order: `apron`, `mark`, `furniture`, `shadow` ops. `opts`: `apron`, `marks`, `furniture`, `shadows` (set any to `false` to leave that layer out) |
| `bvc_profile(program)` | A short stable description of what a program draws (ground, nature, standing, size, marks, furniture) |
| `bvc_nature_of(enemy)` · `bvc_elements_of(enemy)` · `bvc_percentile(ladder, value)` | The reading's building blocks |
| `bvc_ground_for(reading)` · `bvc_marks_for(reading)` · `bvc_furniture_for(reading)` | What a band stands on, leaves and fields |
| `bvc_apron_outline(reading)` · `bvc_apron_box(reading)` · `bvc_anchors(reading)` · `bvc_span_at(points, y)` | The worked ground's outline and where furniture prefers to stand |
| `bvc_grounds()` · `bvc_ground(key)` · `bvc_marks()` · `bvc_mark(key)` · `bvc_furniture()` · `bvc_furniture_info(key)` | The vocabulary |
| `bvc_natures()` · `bvc_standings()` · `bvc_volume()` · `bvc_footprint_half(piece, scale)` · `bvc_element_id(element)` | More of it |
| `bvc_hash(text)` · `bvc_rng(seed)` · `bvc_rnd(state)` | The string hash and the seeded generator every choice comes from |

### Drawing

| Function | Does |
| --- | --- |
| `bvc_bake(program, [opts])` | Draws the program once into a new sprite the size of its battle field. `opts`: `supersample` (1 to 3, default 2), `shadow_strength` (0 to 1, default 0.4) |
| `bvc_ground_draw(sprite, x, y, [scale])` | Draws a baked ground with its top-left at (x, y) |
| `bvc_draw(program, [opts])` | Draws a program into the current target, which must have a stencil buffer (see below). Returns `{drawn, skipped}` |
| `bvc_draw_piece(key, x, y, scale, rng)` | Draws one piece of furniture with its foot at (x, y) |
| `bvc_corpus()` | Every ground, mark and piece this package can draw |

### The drawing kit

Every shape in Bivouac is filled through the stencil buffer, so concave outlines fill correctly and marks can be
clipped to the worked ground. You only need these if you draw your own shapes into a Bivouac surface:

| Function | Does |
| --- | --- |
| `bvc_k_surface(w, h)` | A surface with a stencil buffer |
| `bvc_k_begin()` | Clears the current target's stencil; call once after `surface_set_target` |
| `bvc_k_fill(points, colour, alpha)` | Fills any polygon (a flat array `[x0, y0, x1, y1, ...]`), concave or not |
| `bvc_k_clip_push(points)` · `bvc_k_clip_pop()` | Restrict fills to a polygon (clips nest and intersect) |
| `bvc_k_clipped_begin()` · `bvc_k_clipped_end()` | Let ordinary `draw_*` calls respect the current clip |
| `bvc_k_ellipse(cx, cy, rx, ry, [rot], [seg])` · `bvc_k_quad(x0, y0, cx, cy, x1, y1, [seg], [out])` | Point arrays for an ellipse and a curve |

---

## Notes

* **Bake once, not every frame.** A whole ground is hundreds of filled shapes. Measured on the test machine, one
  bake at the default 2x supersample took 34 to 38 milliseconds (the median over seventeen bands, on two runs; the
  slowest band under 50), which is fine when the battle starts and far too much every frame.
* `bvc_bake` makes its own surfaces with a stencil buffer, whatever your game's `surface_depth_disable` setting is,
  and restores that setting.
* The baked sprite is the size of the battle field you passed (`width` x `height`). If your battle view is drawn
  scaled, pass the same scale to `bvc_ground_draw`.
* The ground is one layer, drawn behind the battlers. Furniture is placed clear of every battler's feet.
* Bivouac makes no sound.
* The composing core is a port of this studio's RPG Maker MZ Bivouac and is held to it by the in-engine suite
  (`Bivouac.exe -selftest` writes `bvc_selftest.json`): for an invented bestiary of eighteen enemies and seventeen
  encounters, every reading, choice, outline point and furniture seat must match what the MZ original computes.
* Built and tested against the GameMaker runtime 2024.14.4.268 (VM). Not yet tested on GMRT.
* The fonts (used only by the demo room's captions) are IM Fell DW Pica (SIL OFL 1.1, as "Bivouac Plate Serif") and
  Open Sans (Apache 2.0); both licences and the notices are in `Bivouac/fonts/`.
* This package was written with AI assistance.
