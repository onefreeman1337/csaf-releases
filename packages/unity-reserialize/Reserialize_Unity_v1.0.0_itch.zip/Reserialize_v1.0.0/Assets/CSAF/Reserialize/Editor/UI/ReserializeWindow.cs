// Copyright (c) 2026 CSAF (Corey Gallant and Stephanie Thomason). All rights reserved.
#nullable enable
// CSAF Reserialize - the migration ledger.
//
// This window is the product's claim made visible. Every design decision below serves one rule:
// AN UNPROVEN ROW MUST BE IMPOSSIBLE TO MISS. A migration tool whose failures look like its
// successes is worse than no tool, because the buyer then deletes the [FormerlySerializedAs]
// attribute that was the only thing keeping their data reachable.
//
// So: unproven rows sort to the top, carry a coloured edge, and the verdict banner refuses to go
// green while any of them exist. There is no "n warnings" summary line to skim past.

using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace CSAF.Reserialize.UI
{
    /// <summary>The migration ledger window.</summary>
    public sealed class ReserializeWindow : EditorWindow
    {
        const string OnlyUnprovenKey = "CSAF.Reserialize.OnlyUnproven";
        const string LastScanKey     = "CSAF.Reserialize.LastScanSummary";

        MigrationReport? _report;
        ScanStats _stats = new ScanStats();

        VisualElement? _verdict;
        VisualElement? _statsStrip;
        ScrollView? _list;
        Button? _migrateButton;

        [MenuItem("Window/CSAF/Reserialize", false, 2200)]
        public static void OpenWindow() { Open(); }

        /// <summary>Opens the ledger and returns it, so it can be driven from an editor script.</summary>
        public static ReserializeWindow Open()
        {
            var w = GetWindow<ReserializeWindow>();
            w.titleContent = new GUIContent("Reserialize");
            w.minSize = new Vector2(620, 420);
            w.Show();
            return w;
        }

        /// <summary>The ledger from the last scan, or null if none has run.</summary>
        public MigrationReport? Report { get { return _report; } }

        /// <summary>What the last scan actually examined.</summary>
        public ScanStats Stats { get { return _stats; } }

        /// <summary>Runs a scan, exactly as the toolbar button does.</summary>
        public void ScanProject() { Scan(); }

        /// <summary>
        /// Re-renders every panel from the current report.
        /// </summary>
        /// <remarks>
        /// Public because a caller that mutates the report through <see cref="MigrationSession"/>
        /// directly - a build script, a custom pipeline step - otherwise has no way to make the
        /// window agree with it, and a ledger showing a stale verdict is the one thing this product
        /// must never do.
        /// </remarks>
        public void Refresh()
        {
            RenderVerdict();
            RenderStats();
            RenderList();
        }

        void CreateGUI()
        {
            var root = rootVisualElement;
            root.style.backgroundColor = Theme.Backdrop;
            root.style.paddingTop = Theme.Gutter;
            root.style.paddingBottom = Theme.Gutter;
            root.style.paddingLeft = Theme.Gutter;
            root.style.paddingRight = Theme.Gutter;

            root.Add(BuildHeader());

            _verdict = new VisualElement();
            root.Add(_verdict);

            root.Add(BuildToolbar());

            _statsStrip = Theme.Row();
            _statsStrip.style.marginBottom = Theme.Step;
            _statsStrip.style.flexWrap = Wrap.Wrap;
            root.Add(_statsStrip);

            _list = new ScrollView(ScrollViewMode.Vertical);
            _list.style.flexGrow = 1f;
            root.Add(_list);

            RenderVerdict();
            RenderStats();
            RenderList();
        }

        // ---- chrome ----------------------------------------------------------------------------

        VisualElement BuildHeader()
        {
            var header = new VisualElement();
            header.style.marginBottom = Theme.Gutter;

            var top = Theme.Row();

            var mark = new VisualElement();
            mark.style.width = 4;
            mark.style.height = 22;
            mark.style.backgroundColor = Theme.Accent;
            mark.style.marginRight = Theme.Step + 2;
            Theme.SetBorderRadius(mark, 2);
            top.Add(mark);

            var title = Theme.Text("RESERIALIZE", 17, Theme.TextHigh, FontStyle.Bold);
            title.style.letterSpacing = 2.5f;
            top.Add(title);

            top.Add(Theme.Spacer());
            header.Add(top);

            var sub = Theme.Text(
                "Rename a serialized field, then prove the data actually moved - before you remove [FormerlySerializedAs].",
                11, Theme.TextMid);
            sub.style.marginTop = 3;
            sub.style.marginLeft = 4 + Theme.Step + 2;
            sub.style.whiteSpace = WhiteSpace.Normal;
            header.Add(sub);

            return header;
        }

        VisualElement BuildToolbar()
        {
            var bar = Theme.Row();
            bar.style.marginBottom = Theme.Gutter;

            var scan = Theme.FlatButton("SCAN PROJECT", Theme.Accent, true);
            scan.clicked += Scan;
            bar.Add(scan);

            _migrateButton = Theme.FlatButton("MIGRATE & PROVE", Theme.Proven, false);
            _migrateButton.clicked += Migrate;
            _migrateButton.SetEnabled(false);
            bar.Add(_migrateButton);

            bar.Add(Theme.Spacer());

            var only = new Toggle("Only unproven");
            only.value = EditorPrefs.GetBool(OnlyUnprovenKey, false);
            only.style.marginRight = Theme.Step;
            only.style.fontSize = 11;
            only.Q<Label>().style.color = Theme.TextMid;
            only.RegisterValueChangedCallback(evt =>
            {
                EditorPrefs.SetBool(OnlyUnprovenKey, evt.newValue);
                RenderList();
            });
            bar.Add(only);

            var export = Theme.FlatButton("EXPORT", Theme.TextMid, false);
            export.clicked += Export;
            bar.Add(export);

            return bar;
        }

        // ---- actions ---------------------------------------------------------------------------

        void Scan()
        {
            _stats = new ScanStats();

            if (!MigrationSession.ProjectIsForceText())
            {
                EditorUtility.DisplayDialog(
                    "Force Text Serialization required",
                    "This project is not set to Force Text serialization, so its assets cannot be " +
                    "read as YAML and NOTHING here could be proven.\n\n" +
                    "Edit > Project Settings > Editor > Asset Serialization > Mode: Force Text",
                    "OK");
                return;
            }

            try
            {
                List<RenamePair> renames = RenameIndex.Discover();
                _report = MigrationSession.Plan(renames, _stats, ReportProgress);
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }

            SessionState.SetString(LastScanKey, DateTime.Now.ToString("HH:mm:ss"));
            RenderVerdict();
            RenderStats();
            RenderList();
        }

        void Migrate()
        {
            if (_report == null || _report.Rows.Count == 0) { return; }

            bool go = EditorUtility.DisplayDialog(
                "Rewrite " + CountDistinctAssets(_report) + " asset(s)?",
                "Reserialize will force-reserialize every affected asset, which REWRITES those files " +
                "on disk. This cannot be undone from the Edit menu.\n\n" +
                "Commit or stash your work first. Every file that will be touched is listed in the " +
                "ledger behind this dialog.",
                "Rewrite and prove", "Cancel");

            if (!go) { return; }

            try
            {
                MigrationSession.Execute(_report, step => EditorUtility.DisplayProgressBar("Reserialize", step, 0.5f));
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }

            RenderVerdict();
            RenderStats();
            RenderList();
        }

        void Export()
        {
            if (_report == null)
            {
                EditorUtility.DisplayDialog("Nothing to export", "Run a scan first.", "OK");
                return;
            }

            string path = EditorUtility.SaveFilePanel(
                "Export migration ledger", "", "reserialize-ledger.json", "json");
            if (path == null || path.Length == 0) { return; }

            System.IO.File.WriteAllText(path, MigrationReportJson.Write(_report, _stats));
            EditorUtility.RevealInFinder(path);
        }

        bool ReportProgress(int done, int total)
        {
            if (total <= 0) { return true; }

            // Only pump the progress bar every 25 assets: DisplayCancelableProgressBar is not cheap,
            // and a scan that spends its time drawing a bar is a scan that looks slow because it is.
            if ((done % 25) != 0) { return true; }

            return !EditorUtility.DisplayCancelableProgressBar(
                "Reserialize",
                "Indexing assets  " + done + " / " + total,
                (float)done / total);
        }

        // ---- rendering -------------------------------------------------------------------------

        void RenderVerdict()
        {
            if (_verdict == null) { return; }
            _verdict.Clear();

            var card = Theme.Card();
            card.style.marginBottom = Theme.Gutter;

            string headline;
            string detail;
            Color color;

            if (_report == null)
            {
                color = Theme.TextLow;
                headline = "NOT SCANNED";
                detail = "Scan the project to find every [FormerlySerializedAs] and the assets still holding the old key.";
            }
            else if (_report.Rows.Count == 0)
            {
                // Deliberately NOT green. Zero rows means either nothing needs migrating or nothing
                // was found - and those look identical from here.
                color = Theme.Amber;
                headline = "NOTHING TO MIGRATE";
                detail = _report.Renames.Count == 0
                    ? "No [FormerlySerializedAs] attributes exist in this project, so there is nothing to prove."
                    : _report.Renames.Count + " rename(s) found, but no asset still holds an old key. " +
                      "That is either already-migrated data or a scan that reached nothing - check the counts below before trusting it.";
            }
            else if (_report.DryRun)
            {
                color = Theme.Accent;
                headline = _report.Rows.Count + " ASSET ROW(S) TO MIGRATE";
                detail = "Nothing has been written. Review the ledger, then Migrate & Prove.";
            }
            else if (_report.SafeToRemoveAttributes)
            {
                color = Theme.Proven;
                headline = "SAFE TO REMOVE [FormerlySerializedAs]";
                detail = "Every affected asset was re-read from disk after the rewrite: the old key is gone and the value is unchanged.";
            }
            else
            {
                color = Theme.Failed;
                headline = "DO NOT REMOVE [FormerlySerializedAs]";
                detail = _report.FailedCount + " at risk, " + _report.UnverifiableCount +
                         " unproven. Those rows are pinned to the top of the ledger.";
            }

            Theme.SetBorderColor(card, Theme.Tint(color, 0.55f));
            card.style.backgroundColor = Theme.Tint(color, 0.08f);

            var row = Theme.Row();
            var bar = new VisualElement();
            bar.style.width = 3;
            bar.style.height = 30;
            bar.style.backgroundColor = color;
            bar.style.marginRight = Theme.Gutter;
            Theme.SetBorderRadius(bar, 2);
            row.Add(bar);

            var col = new VisualElement();
            col.style.flexGrow = 1f;
            var h = Theme.Text(headline, 14, color, FontStyle.Bold);
            h.style.letterSpacing = 0.6f;
            col.Add(h);
            var d = Theme.Text(detail, 11, Theme.TextMid);
            d.style.whiteSpace = WhiteSpace.Normal;
            d.style.marginTop = 2;
            col.Add(d);
            row.Add(col);

            card.Add(row);
            _verdict.Add(card);

            if (_migrateButton != null)
            {
                _migrateButton.SetEnabled(_report != null && _report.DryRun && _report.Rows.Count > 0);
            }
        }

        void RenderStats()
        {
            if (_statsStrip == null) { return; }
            _statsStrip.Clear();

            if (_report == null) { return; }

            // COUNT THE WORK, NOT THE VERDICT. These are shown always, including when everything
            // passed, because "0 failures" over 0 files examined is not a pass.
            AddStat("assets indexed", _stats.FilesRead.ToString(), Theme.TextMid);
            AddStat("renames found", _report.Renames.ToString2(), Theme.TextMid);
            AddStat("rows", _report.Rows.Count.ToString(), Theme.TextMid);

            if (_stats.ReachedByClosureOnly.Count > 0)
            {
                AddStat("found via variant closure", _stats.ReachedByClosureOnly.Count.ToString(), Theme.Accent);
            }
            if (!_report.DryRun)
            {
                AddStat("proven", _report.ProvenCount.ToString(), Theme.Proven);
                if (_report.FailedCount > 0) { AddStat("at risk", _report.FailedCount.ToString(), Theme.Failed); }
                if (_report.UnverifiableCount > 0) { AddStat("unproven", _report.UnverifiableCount.ToString(), Theme.Amber); }
            }
            if (_stats.UnreadableFiles.Count > 0)
            {
                AddStat("unreadable", _stats.UnreadableFiles.Count.ToString(), Theme.Amber);
            }
        }

        void AddStat(string label, string value, Color color)
        {
            if (_statsStrip == null) { return; }

            var e = Theme.Row();
            e.style.marginRight = Theme.Gutter;
            e.style.marginBottom = 2;

            var v = Theme.Text(value, 12, color, FontStyle.Bold);
            e.Add(v);

            var l = Theme.Text(" " + label, 10, Theme.TextLow);
            e.Add(l);

            _statsStrip.Add(e);
        }

        void RenderList()
        {
            if (_list == null) { return; }
            _list.Clear();

            if (_report == null) { return; }

            bool onlyUnproven = EditorPrefs.GetBool(OnlyUnprovenKey, false);

            // Renames with no rows are reported too - a rename we found nothing for is information,
            // not silence.
            var byRename = new List<KeyValuePair<RenamePair, List<MigrationRow>>>();
            for (int i = 0; i < _report.Renames.Count; i++)
            {
                RenamePair rename = _report.Renames[i];
                var rows = new List<MigrationRow>();
                for (int r = 0; r < _report.Rows.Count; r++)
                {
                    if (ReferenceEquals(_report.Rows[r].Rename, rename)) { rows.Add(_report.Rows[r]); }
                }

                // Unproven first, then at-risk, then the rest. The buyer's eye lands on trouble.
                rows.Sort((a, b) => Severity(b.Proof).CompareTo(Severity(a.Proof)));
                byRename.Add(new KeyValuePair<RenamePair, List<MigrationRow>>(rename, rows));
            }

            byRename.Sort((a, b) =>
            {
                int sa = WorstSeverity(a.Value), sb = WorstSeverity(b.Value);
                if (sa != sb) { return sb.CompareTo(sa); }
                return string.CompareOrdinal(a.Key.DeclaringType, b.Key.DeclaringType);
            });

            for (int i = 0; i < byRename.Count; i++)
            {
                RenamePair rename = byRename[i].Key;
                List<MigrationRow> rows = byRename[i].Value;

                if (onlyUnproven && WorstSeverity(rows) < 2) { continue; }
                _list.Add(BuildRenameCard(rename, rows));
            }
        }

        static int Severity(ProofState s)
        {
            switch (s)
            {
                case ProofState.Failed:       return 3;
                case ProofState.Unverifiable: return 2;
                case ProofState.Unknown:      return 2;
                case ProofState.Proven:       return 1;
                default:                      return 0;
            }
        }

        static int WorstSeverity(List<MigrationRow> rows)
        {
            int worst = 0;
            for (int i = 0; i < rows.Count; i++)
            {
                int s = Severity(rows[i].Proof);
                if (s > worst) { worst = s; }
            }
            return worst;
        }

        VisualElement BuildRenameCard(RenamePair rename, List<MigrationRow> rows)
        {
            var card = Theme.Card();

            var head = Theme.Row();
            head.Add(Theme.Key(rename.OldName, Theme.Failed));
            var arrow = Theme.Text("  →  ", 12, Theme.TextLow);
            head.Add(arrow);
            head.Add(Theme.Key(rename.NewName, Theme.Proven));

            var type = Theme.Text("   " + rename.DeclaringType, 10, Theme.TextLow);
            head.Add(type);

            head.Add(Theme.Spacer());

            if (rename.IsNestedSerializable)
            {
                head.Add(Theme.Chip("NO SCRIPT ANCHOR", Theme.Amber));
            }
            head.Add(Theme.Chip(rows.Count + (rows.Count == 1 ? " ASSET" : " ASSETS"),
                                rows.Count == 0 ? Theme.TextLow : Theme.Accent));
            card.Add(head);

            if (rows.Count == 0)
            {
                var none = Theme.Text(
                    "No asset in this project still holds this key. Nothing to migrate - and nothing was hidden.",
                    10, Theme.TextLow);
                none.style.marginTop = Theme.Step;
                none.style.whiteSpace = WhiteSpace.Normal;
                card.Add(none);
                return card;
            }

            card.Add(Theme.Divider());

            for (int i = 0; i < rows.Count; i++)
            {
                card.Add(BuildAssetRow(rows[i]));
            }

            return card;
        }

        VisualElement BuildAssetRow(MigrationRow row)
        {
            Color color = Theme.ColorFor(row.Proof);
            bool trouble = Severity(row.Proof) >= 2;

            var wrap = new VisualElement();
            wrap.style.flexDirection = FlexDirection.Row;
            wrap.style.marginBottom = 3;
            wrap.style.paddingTop = 3;
            wrap.style.paddingBottom = 3;
            wrap.style.paddingLeft = Theme.Step;
            wrap.style.backgroundColor = trouble ? Theme.Tint(color, 0.07f) : Theme.PanelRaised;
            Theme.SetBorderRadius(wrap, 3);

            // The coloured edge is the thing the eye catches. Only trouble gets one.
            wrap.style.borderLeftWidth = 3;
            wrap.style.borderLeftColor = trouble ? color : Theme.Tint(Theme.Line, 0f);

            var col = new VisualElement();
            col.style.flexGrow = 1f;

            var line1 = Theme.Row();
            var path = Theme.Text(row.AssetPath, 11, Theme.TextHigh);
            path.style.overflow = Overflow.Hidden;
            line1.Add(path);

            if (row.IsPrefabVariant)
            {
                var chip = Theme.Chip("VARIANT", Theme.Accent);
                chip.style.marginLeft = Theme.Step;
                line1.Add(chip);
            }
            if (row.OccurrenceCount > 1)
            {
                var chip = Theme.Chip(row.OccurrenceCount + "×", Theme.TextMid);
                chip.style.marginLeft = 4;
                line1.Add(chip);
            }

            line1.Add(Theme.Spacer());
            line1.Add(Theme.Chip(Theme.LabelFor(row.Proof), color));
            col.Add(line1);

            var line2 = Theme.Row();
            line2.style.marginTop = 2;
            line2.Add(Theme.Text("value  ", 10, Theme.TextLow));
            line2.Add(Theme.Text(Show(row.ValueBefore), 10, Theme.TextMid, FontStyle.Bold));
            line2.Add(Theme.Text("  →  ", 10, Theme.TextLow));
            line2.Add(Theme.Text(Show(row.ValueAfter), 10,
                                 row.Proof == ProofState.Proven ? Theme.Proven : Theme.TextMid,
                                 FontStyle.Bold));
            col.Add(line2);

            if (row.Reason != null && row.Reason.Length > 0)
            {
                var reason = Theme.Text(row.Reason, 10, color);
                reason.style.whiteSpace = WhiteSpace.Normal;
                reason.style.marginTop = 2;
                col.Add(reason);
            }

            wrap.Add(col);

            wrap.RegisterCallback<MouseDownEvent>(_ =>
            {
                var obj = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(row.AssetPath);
                if (obj != null) { EditorGUIUtility.PingObject(obj); Selection.activeObject = obj; }
            });

            return wrap;
        }

        static string Show(string? v)
        {
            if (v == null) { return "-"; }
            if (v.Length == 0) { return "(empty)"; }
            if (v == YamlProbe.BlockValueSentinel) { return "(nested block)"; }
            return v.Length > 48 ? v.Substring(0, 45) + "..." : v;
        }

        static int CountDistinctAssets(MigrationReport report)
        {
            var seen = new HashSet<string>(StringComparer.Ordinal);
            for (int i = 0; i < report.Rows.Count; i++) { seen.Add(report.Rows[i].AssetPath); }
            return seen.Count;
        }
    }

    static class ListCountExtensions
    {
        /// <summary>Count as a string, so the stats strip never has to reach into a collection inline.</summary>
        public static string ToString2<T>(this List<T> list) { return list.Count.ToString(); }
    }
}
