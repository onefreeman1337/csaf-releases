// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.
#nullable enable
// CSAF Reserialize - the batch-mode entry points.
//
// A rename that has not fully migrated is invisible in a code review and invisible in a build: the
// project compiles, the game runs, and [FormerlySerializedAs] silently carries the value. It only
// becomes a bug the day somebody deletes the attribute. That is exactly the shape of defect a CI
// gate exists for, so the ledger ships with one.
//
// Usage:
//   Unity.exe -batchmode -quit -projectPath <p> -executeMethod CSAF.Reserialize.ReserializeCI.Verify
//   Unity.exe -batchmode -quit -projectPath <p> -executeMethod CSAF.Reserialize.ReserializeCI.Migrate
//             [-reserializeReport <path-to-write-json>]
//
// Exit codes: 0 clean - 1 work outstanding or a row could not be proven - 2 the project cannot be
// analysed at all (binary serialization). 2 is deliberately distinct: "we could not measure" must
// never share an exit code with "we measured and it was fine".

using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace CSAF.Reserialize
{
    /// <summary>Batch-mode gates for continuous integration.</summary>
    public static class ReserializeCI
    {
        const string ReportArg = "-reserializeReport";
        const string IgnoreArg = "-reserializeIgnore";

        /// <summary>
        /// Fails the build when any asset still holds a renamed field's OLD key.
        /// </summary>
        /// <remarks>Read-only. Verify never writes to the project.</remarks>
        public static void Verify()
        {
            Run(false);
        }

        /// <summary>
        /// Migrates every affected asset and fails the build unless every row is proven.
        /// </summary>
        public static void Migrate()
        {
            Run(true);
        }

        static void Run(bool apply)
        {
            int exit;
            try
            {
                exit = Execute(apply);
            }
            catch (Exception e)
            {
                // An exception is not a pass. Say what happened and fail.
                Debug.LogError("[Reserialize] CI run threw: " + e);
                exit = 2;
            }

            if (Application.isBatchMode) { EditorApplication.Exit(exit); }
        }

        static int Execute(bool apply)
        {
            if (!MigrationSession.ProjectIsForceText())
            {
                Debug.LogError(
                    "[Reserialize] This project is not set to Force Text serialization, so no asset " +
                    "can be read as YAML and NOTHING can be proven. Set Project Settings > Editor > " +
                    "Asset Serialization > Mode to Force Text.");
                return 2;
            }

            var stats = new ScanStats();
            List<RenamePair> renames = RenameIndex.Discover();
            MigrationReport report = MigrationSession.Plan(renames, stats, null);

            int ignored = ApplyIgnores(report);
            if (ignored > 0)
            {
                // Say what was dropped. A gate that silently narrows its own scope reads exactly
                // like a gate that found nothing wrong.
                Debug.Log("[Reserialize] " + ignored + " row(s) excluded by " + IgnoreArg + ".");
            }

            if (apply && report.Rows.Count > 0)
            {
                MigrationSession.Execute(report, step => Debug.Log("[Reserialize] " + step));
            }

            WriteReportIfAsked(report, stats);
            LogSummary(report, stats, apply);

            if (stats.UnreadableFiles.Count > 0)
            {
                // Present on disk, not readable as text. Refusing to grade the run is the honest
                // answer; passing it would be a verdict about files nobody looked inside.
                Debug.LogError("[Reserialize] " + stats.UnreadableFiles.Count +
                               " asset(s) could not be read as text YAML. Nothing can be proven about them.");
                return 2;
            }

            if (!apply)
            {
                if (report.Rows.Count == 0) { return 0; }

                Debug.LogError("[Reserialize] " + report.Rows.Count +
                               " asset row(s) still hold a renamed field's OLD key. Run the Migrate " +
                               "gate, or open Window > CSAF > Reserialize.");
                return 1;
            }

            if (report.Rows.Count == 0)
            {
                // Nothing to migrate is a clean CI result, but it is NOT "safe to remove the
                // attributes" - there is no evidence either way, and the log says so.
                Debug.Log("[Reserialize] No asset holds an old key. Nothing was migrated and nothing was proven.");
                return 0;
            }

            if (!report.SafeToRemoveAttributes)
            {
                Debug.LogError("[Reserialize] " + report.FailedCount + " at risk and " +
                               report.UnverifiableCount + " unproven after migration. " +
                               "DO NOT remove [FormerlySerializedAs].");
                return 1;
            }

            return 0;
        }

        /// <summary>
        /// Drops rows whose asset path contains any comma-separated substring passed to
        /// <c>-reserializeIgnore</c>.
        /// </summary>
        /// <returns>How many rows were removed, so the caller can say so out loud.</returns>
        static int ApplyIgnores(MigrationReport report)
        {
            string? raw = ArgValue(IgnoreArg);
            if (raw == null || raw.Length == 0) { return 0; }

            string[] parts = raw.Split(',');
            var needles = new List<string>();
            for (int i = 0; i < parts.Length; i++)
            {
                string s = parts[i].Trim().Replace('\\', '/');
                if (s.Length > 0) { needles.Add(s); }
            }
            if (needles.Count == 0) { return 0; }

            int before = report.Rows.Count;
            var kept = new List<MigrationRow>(before);

            for (int i = 0; i < report.Rows.Count; i++)
            {
                string path = report.Rows[i].AssetPath.Replace('\\', '/');
                bool drop = false;
                for (int n = 0; n < needles.Count; n++)
                {
                    if (path.IndexOf(needles[n], StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        drop = true;
                        break;
                    }
                }
                if (!drop) { kept.Add(report.Rows[i]); }
            }

            report.Rows.Clear();
            report.Rows.AddRange(kept);
            return before - kept.Count;
        }

        static void LogSummary(MigrationReport report, ScanStats stats, bool applied)
        {
            // Count the work, not the verdict.
            Debug.Log(
                "[Reserialize] " + (applied ? "migrate" : "verify") + ": " +
                stats.FilesRead + " asset(s) indexed in " + stats.ClosureRounds + " closure round(s), " +
                stats.ReachedByClosureOnly.Count + " reached only via variant closure, " +
                report.Renames.Count + " rename(s) discovered, " +
                report.Rows.Count + " row(s), " +
                report.ProvenCount + " proven / " + report.FailedCount + " at risk / " +
                report.UnverifiableCount + " unproven. safeToRemoveAttributes=" +
                report.SafeToRemoveAttributes);

            for (int i = 0; i < report.Rows.Count; i++)
            {
                MigrationRow row = report.Rows[i];
                if (row.Proof == ProofState.Proven) { continue; }

                Debug.LogWarning("[Reserialize] " + row.Proof + "  " + row.AssetPath +
                                 "  [" + row.Rename.OldName + " -> " + row.Rename.NewName + "]  " +
                                 (row.Reason ?? ""));
            }
        }

        static void WriteReportIfAsked(MigrationReport report, ScanStats stats)
        {
            string? path = ArgValue(ReportArg);
            if (path == null || path.Length == 0) { return; }

            try
            {
                string dir = Path.GetDirectoryName(path) ?? "";
                if (dir.Length > 0 && !Directory.Exists(dir)) { Directory.CreateDirectory(dir); }

                File.WriteAllText(path, MigrationReportJson.Write(report, stats));
                Debug.Log("[Reserialize] ledger written to " + path);
            }
            catch (Exception e)
            {
                Debug.LogError("[Reserialize] could not write the ledger to " + path + ": " + e.Message);
            }
        }

        static string? ArgValue(string name)
        {
            string[] args = Environment.GetCommandLineArgs();
            for (int i = 0; i < args.Length - 1; i++)
            {
                if (string.Equals(args[i], name, StringComparison.OrdinalIgnoreCase))
                {
                    return args[i + 1];
                }
            }
            return null;
        }
    }
}
