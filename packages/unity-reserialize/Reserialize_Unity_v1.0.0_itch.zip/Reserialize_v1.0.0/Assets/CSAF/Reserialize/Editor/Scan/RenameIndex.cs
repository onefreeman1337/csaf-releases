// Copyright (c) 2026 CSAF (Corey Gallant and Stephanie Thomason). All rights reserved.
#nullable enable
// CSAF Reserialize - discovery.
//
// Finds every serialized-field rename in the project by reading the [FormerlySerializedAs]
// attributes the developer already wrote. Nobody types a rename into this tool: the attribute IS
// the declaration of intent, and asking the buyer to restate it is how a migration tool ends up
// migrating something the compiler disagrees with.

using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using UnityEngine.Serialization;

namespace CSAF.Reserialize
{
    /// <summary>Discovers renames, and resolves each to the MonoScript GUID that anchors the scan.</summary>
    public static class RenameIndex
    {
        /// <summary>
        /// Scans every loaded assembly for <c>[FormerlySerializedAs]</c>.
        /// </summary>
        /// <param name="includeReadOnlyPackages">
        /// When false (the default) renames declared inside immutable packages are skipped: their
        /// assets are not the buyer's to rewrite, and reporting them as actionable is noise.
        /// </param>
        public static List<RenamePair> Discover(bool includeReadOnlyPackages = false)
        {
            var pairs = new List<RenamePair>();
            Dictionary<Type, string> scriptGuidByType = BuildScriptGuidMap();

            foreach (FieldInfo field in TypeCache.GetFieldsWithAttribute<FormerlySerializedAsAttribute>())
            {
                Type? declaring = field.DeclaringType;
                if (declaring == null) { continue; }

                // The rename must belong to code COMPILED FROM THIS PROJECT. Anything else is the
                // engine's own, and reporting it is worse than useless - see IsProjectType.
                if (!IsProjectType(declaring)) { continue; }

                if (!includeReadOnlyPackages && IsImmutablePackageType(declaring, scriptGuidByType))
                {
                    continue;
                }

                // A field may carry SEVERAL [FormerlySerializedAs] - a chain of renames over the
                // years. Each old name is its own migration and gets its own row.
                object[] attrs = field.GetCustomAttributes(typeof(FormerlySerializedAsAttribute), false);
                for (int i = 0; i < attrs.Length; i++)
                {
                    var fsa = attrs[i] as FormerlySerializedAsAttribute;
                    if (fsa == null) { continue; }

                    string oldName = fsa.oldName;
                    if (oldName == null || oldName.Length == 0) { continue; }

                    // A no-op attribute. Report nothing rather than manufacture a migration whose
                    // "old key" and "new key" are the same string - it would always look Proven.
                    if (string.Equals(oldName, field.Name, StringComparison.Ordinal)) { continue; }

                    string guid;
                    bool hasGuid = scriptGuidByType.TryGetValue(declaring, out guid);

                    pairs.Add(new RenamePair
                    {
                        DeclaringType = declaring.FullName ?? declaring.Name,
                        OldName = oldName,
                        NewName = field.Name,
                        ScriptGuid = hasGuid ? guid : string.Empty,

                        // No MonoScript means a nested [Serializable] class, a generic, or a type
                        // whose file name does not match (Unity itself cannot resolve those). Such
                        // renames cannot be anchored to a script GUID and must be scanned by key.
                        IsNestedSerializable = !hasGuid,
                    });
                }
            }

            pairs.Sort((a, b) =>
            {
                int t = string.CompareOrdinal(a.DeclaringType, b.DeclaringType);
                return t != 0 ? t : string.CompareOrdinal(a.OldName, b.OldName);
            });

            return pairs;
        }

        /// <summary>
        /// Maps every type that has a <c>MonoScript</c> asset to that asset's GUID.
        /// </summary>
        /// <remarks>
        /// One pass over all MonoScripts, not one <c>FindAssets</c> per rename. On a large project
        /// the difference is a second against a minute, and the map is what makes the asset scan
        /// cheap enough to run without a progress bar of its own.
        /// </remarks>
        static Dictionary<Type, string> BuildScriptGuidMap()
        {
            var map = new Dictionary<Type, string>();
            string[] guids = AssetDatabase.FindAssets("t:MonoScript");

            // Pass 1 - the authoritative route. MonoScript.GetClass() is what Unity itself uses.
            var unresolved = new List<KeyValuePair<string, string>>();   // guid -> file name

            for (int i = 0; i < guids.Length; i++)
            {
                string path = AssetDatabase.GUIDToAssetPath(guids[i]);
                if (path == null || path.Length == 0) { continue; }

                var ms = AssetDatabase.LoadAssetAtPath<MonoScript>(path);
                if (ms == null) { continue; }

                Type? cls = ms.GetClass();
                if (cls == null)
                {
                    unresolved.Add(new KeyValuePair<string, string>(
                        guids[i], System.IO.Path.GetFileNameWithoutExtension(path)));
                    continue;
                }

                // First writer wins; duplicates are a broken project, not our problem to resolve.
                if (!map.ContainsKey(cls)) { map[cls] = guids[i]; }
            }

            // ---- Pass 2 - the fallback, and it is NOT belt-and-braces ---------------------------
            //
            // MEASURED 2026-08-16: GetClass() returns null for EVERY script in the project whenever
            // the domain has not rebound since the last script import - which includes any batch run
            // that reimports assets before calling us. Without this pass the index silently resolves
            // ZERO script GUIDs, every rename looks unanchored, and the scan degrades to a full
            // project sweep that still reports success. A pass with a zero next to it.
            //
            // The fallback applies Unity's OWN binding rule - the type name must equal the file name
            // - so it agrees with pass 1 by construction rather than guessing. It only ever fills
            // gaps: an entry resolved by GetClass() is never overwritten.
            if (unresolved.Count > 0)
            {
                var wanted = new Dictionary<string, List<Type>>(StringComparer.Ordinal);
                foreach (FieldInfo f in TypeCache.GetFieldsWithAttribute<FormerlySerializedAsAttribute>())
                {
                    Type? d = f.DeclaringType;
                    if (d == null || map.ContainsKey(d)) { continue; }

                    List<Type> list;
                    if (!wanted.TryGetValue(d.Name, out list))
                    {
                        list = new List<Type>();
                        wanted[d.Name] = list;
                    }
                    if (!list.Contains(d)) { list.Add(d); }
                }

                for (int i = 0; i < unresolved.Count; i++)
                {
                    List<Type> candidates;
                    if (!wanted.TryGetValue(unresolved[i].Value, out candidates)) { continue; }

                    // Exactly one type of that name, or we refuse: binding the wrong script GUID
                    // would scan the wrong assets and report a confident, wrong answer.
                    if (candidates.Count != 1) { continue; }

                    Type t = candidates[0];
                    if (!map.ContainsKey(t)) { map[t] = unresolved[i].Key; }
                }
            }

            return map;
        }

        /// <summary>
        /// True when <paramref name="type"/> was compiled from scripts in THIS project (Assets or a
        /// package), rather than shipped inside the engine.
        /// </summary>
        /// <remarks>
        /// WHY THIS EXISTS. <c>TypeCache.GetFieldsWithAttribute</c> sweeps EVERY loaded assembly,
        /// including Unity's own precompiled ones, and Unity uses <c>[FormerlySerializedAs]</c>
        /// internally. Measured on a near-empty 6000.5.7f1 project: <b>93 renames discovered, of
        /// which 90 were the engine's.</b>
        ///
        /// Those rows are not merely noise. The worst is
        /// <c>UnityEngine.Events.PersistentCall.m_Enabled -> m_CallState</c>: the type is
        /// precompiled, so it has no MonoScript and therefore no script anchor, which forces the
        /// prover to fall back to scanning documents for the raw key <c>m_Enabled</c> - and
        /// <c>m_Enabled</c> appears on virtually every component in every scene and prefab for
        /// completely unrelated reasons. The prover found it, concluded "the OLD key is still on
        /// disk", and rendered a red <b>AT RISK</b> row with the banner
        /// <b>"DO NOT REMOVE [FormerlySerializedAs]"</b>.
        ///
        /// So on ANY real project the headline verdict was permanently unsafe, for renames inside
        /// Unity's own code that the buyer cannot see, cannot fix, and must not act on. That is a
        /// false RED, which costs exactly as much as a false green (CLAUDE.md 4.4 rule 5).
        ///
        /// <c>IsImmutablePackageType</c> did not catch it: that guard resolves a type through its
        /// MonoScript GUID and returns <c>false</c> - "keep it" - when there is no GUID. A
        /// precompiled engine type has no GUID, so the filter written to drop non-actionable
        /// renames FAILED OPEN on the most non-actionable category of all.
        ///
        /// The test is the assembly, because that is the fact that actually decides it.
        /// <c>CompilationPipeline.GetAssemblies</c> enumerates exactly the assemblies built from
        /// this project's own scripts; the engine's precompiled modules are not among them.
        /// </remarks>
        static bool IsProjectType(Type type)
        {
            var asm = type.Assembly;
            if (asm == null) { return false; }
            string name = asm.GetName().Name;
            if (name == null || name.Length == 0) { return false; }
            return ProjectAssemblyNames().Contains(name);
        }

        static HashSet<string>? _projectAssemblyNames;

        /// <summary>Names of every assembly compiled from this project's scripts, cached per domain.</summary>
        static HashSet<string> ProjectAssemblyNames()
        {
            if (_projectAssemblyNames != null) { return _projectAssemblyNames; }

            var names = new HashSet<string>(StringComparer.Ordinal);
            var all = UnityEditor.Compilation.CompilationPipeline.GetAssemblies(
                UnityEditor.Compilation.AssembliesType.Editor);
            for (int i = 0; i < all.Length; i++)
            {
                if (all[i] != null && all[i].name != null) { names.Add(all[i].name); }
            }
            var player = UnityEditor.Compilation.CompilationPipeline.GetAssemblies(
                UnityEditor.Compilation.AssembliesType.Player);
            for (int i = 0; i < player.Length; i++)
            {
                if (player[i] != null && player[i].name != null) { names.Add(player[i].name); }
            }

            _projectAssemblyNames = names;
            return names;
        }

        static bool IsImmutablePackageType(Type type, Dictionary<Type, string> scriptGuidByType)
        {
            string guid;
            if (!scriptGuidByType.TryGetValue(type, out guid)) { return false; }

            string path = AssetDatabase.GUIDToAssetPath(guid);
            if (path == null || !path.StartsWith("Packages/", StringComparison.Ordinal)) { return false; }

            var info = UnityEditor.PackageManager.PackageInfo.FindForAssetPath(path);
            return info != null && info.source != UnityEditor.PackageManager.PackageSource.Embedded
                                && info.source != UnityEditor.PackageManager.PackageSource.Local;
        }

        /// <summary>
        /// Groups renames by the script GUID that anchors them, so the asset scan can seed its
        /// reference closure from a small set.
        /// </summary>
        public static HashSet<string> SeedGuids(IList<RenamePair> renames)
        {
            var seeds = new HashSet<string>(StringComparer.Ordinal);
            for (int i = 0; i < renames.Count; i++)
            {
                string g = renames[i].ScriptGuid;
                if (g != null && g.Length > 0) { seeds.Add(g); }
            }
            return seeds;
        }
    }
}
