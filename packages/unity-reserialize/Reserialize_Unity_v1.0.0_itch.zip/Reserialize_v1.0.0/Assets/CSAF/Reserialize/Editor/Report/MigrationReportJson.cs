// Copyright (c) 2026 CSAF (Corey Gallant and Stephanie Thomason). All rights reserved.
#nullable enable
// CSAF Reserialize - the ledger as machine-readable evidence.
//
// Written by hand rather than through JsonUtility. JsonUtility cannot serialize a nullable string
// distinctly from an empty one, and the difference between "no value was found" (null) and "the
// value is the empty string" (Unity writes "m_Name: " for that) is load-bearing in this product -
// conflating them is how a migration tool reports a value as lost when it merely became empty.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace CSAF.Reserialize
{
    /// <summary>Serializes a <see cref="MigrationReport"/> for CI, diffing, or an audit trail.</summary>
    public static class MigrationReportJson
    {
        public static string Write(MigrationReport report, ScanStats stats)
        {
            if (report == null) { throw new ArgumentNullException(nameof(report)); }

            var sb = new StringBuilder(4096);
            sb.Append("{\n");

            sb.Append("  \"tool\": \"CSAF Reserialize\",\n");
            sb.Append("  \"startedUtc\": ").Append(Str(Iso(report.StartedUtc))).Append(",\n");
            sb.Append("  \"finishedUtc\": ").Append(Str(Iso(report.FinishedUtc))).Append(",\n");
            sb.Append("  \"dryRun\": ").Append(Bool(report.DryRun)).Append(",\n");

            // The single question the product answers goes near the top, where a CI script that
            // greps for one key will find it.
            sb.Append("  \"safeToRemoveAttributes\": ").Append(Bool(report.SafeToRemoveAttributes)).Append(",\n");

            sb.Append("  \"counts\": {\n");
            sb.Append("    \"renames\": ").Append(report.Renames.Count).Append(",\n");
            sb.Append("    \"rows\": ").Append(report.Rows.Count).Append(",\n");
            sb.Append("    \"proven\": ").Append(report.ProvenCount).Append(",\n");
            sb.Append("    \"failed\": ").Append(report.FailedCount).Append(",\n");
            sb.Append("    \"unverifiable\": ").Append(report.UnverifiableCount).Append("\n");
            sb.Append("  },\n");

            // COUNT THE WORK, NOT THE VERDICT. A consumer that only reads safeToRemoveAttributes
            // can still be handed the size of the thing that was examined.
            sb.Append("  \"scan\": {\n");
            sb.Append("    \"filesEnumerated\": ").Append(stats.FilesEnumerated).Append(",\n");
            sb.Append("    \"filesRead\": ").Append(stats.FilesRead).Append(",\n");
            sb.Append("    \"closureRounds\": ").Append(stats.ClosureRounds).Append(",\n");
            sb.Append("    \"reachedByClosureOnly\": ").Append(Arr(stats.ReachedByClosureOnly)).Append(",\n");
            sb.Append("    \"unreadableFiles\": ").Append(Arr(stats.UnreadableFiles)).Append("\n");
            sb.Append("  },\n");

            sb.Append("  \"renames\": [\n");
            for (int i = 0; i < report.Renames.Count; i++)
            {
                RenamePair r = report.Renames[i];
                sb.Append("    {\"declaringType\": ").Append(Str(r.DeclaringType));
                sb.Append(", \"oldName\": ").Append(Str(r.OldName));
                sb.Append(", \"newName\": ").Append(Str(r.NewName));
                sb.Append(", \"scriptGuid\": ").Append(Str(r.ScriptGuid));
                sb.Append(", \"anchored\": ").Append(Bool(!r.IsNestedSerializable));
                sb.Append("}").Append(i + 1 < report.Renames.Count ? "," : "").Append("\n");
            }
            sb.Append("  ],\n");

            sb.Append("  \"rows\": [\n");
            for (int i = 0; i < report.Rows.Count; i++)
            {
                MigrationRow row = report.Rows[i];
                sb.Append("    {\"assetPath\": ").Append(Str(row.AssetPath));
                sb.Append(", \"oldName\": ").Append(Str(row.Rename.OldName));
                sb.Append(", \"newName\": ").Append(Str(row.Rename.NewName));
                sb.Append(", \"proof\": ").Append(Str(row.Proof.ToString()));
                sb.Append(", \"valueBefore\": ").Append(Str(row.ValueBefore));
                sb.Append(", \"valueAfter\": ").Append(Str(row.ValueAfter));
                sb.Append(", \"oldKeyStillPresent\": ").Append(Bool(row.OldKeyStillPresent));
                sb.Append(", \"occurrences\": ").Append(row.OccurrenceCount);
                sb.Append(", \"isPrefabVariant\": ").Append(Bool(row.IsPrefabVariant));
                sb.Append(", \"reason\": ").Append(Str(row.Reason));
                sb.Append("}").Append(i + 1 < report.Rows.Count ? "," : "").Append("\n");
            }
            sb.Append("  ]\n");

            sb.Append("}\n");
            return sb.ToString();
        }

        static string Iso(DateTime t)
        {
            return t == default(DateTime) ? "" : t.ToString("o", CultureInfo.InvariantCulture);
        }

        static string Bool(bool b) { return b ? "true" : "false"; }

        static string Arr(List<string> items)
        {
            if (items == null || items.Count == 0) { return "[]"; }

            var sb = new StringBuilder();
            sb.Append('[');
            for (int i = 0; i < items.Count; i++)
            {
                if (i > 0) { sb.Append(", "); }
                sb.Append(Str(items[i]));
            }
            sb.Append(']');
            return sb.ToString();
        }

        /// <summary>JSON string literal, or a bare <c>null</c> - the distinction is deliberate.</summary>
        static string Str(string? s)
        {
            if (s == null) { return "null"; }

            var sb = new StringBuilder(s.Length + 8);
            sb.Append('"');
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                switch (c)
                {
                    case '"':  sb.Append("\\\""); break;
                    case '\\': sb.Append("\\\\"); break;
                    case '\n': sb.Append("\\n"); break;
                    case '\r': sb.Append("\\r"); break;
                    case '\t': sb.Append("\\t"); break;
                    default:
                        if (c < ' ') { sb.Append("\\u").Append(((int)c).ToString("x4", CultureInfo.InvariantCulture)); }
                        else { sb.Append(c); }
                        break;
                }
            }
            sb.Append('"');
            return sb.ToString();
        }
    }
}
