// Copyright (c) 2026 CSAF (Corey Gallant and Stephanie Thomason). All rights reserved.
#nullable enable
// CSAF Reserialize - plan, act, then PROVE.
//
// Three phases, in this order, and the order is the product:
//
//   Plan     read the YAML off disk and record what the old key holds, per asset, BEFORE anything
//            is written. Without a before-value there is nothing to compare an after-value to, and
//            "the new key exists" is not evidence the value survived.
//   Act      AssetDatabase.ForceReserializeAssets - the buyer's files are rewritten.
//   Prove    re-read the SAME files off disk and answer, per asset: is the old key gone, and is the
//            value under the new key the one we recorded?
//
// Only Prove decides anything. Act reports nothing, because a write that reports its own success is
// the green lie this whole product exists to replace: [FormerlySerializedAs] means a freshly loaded
// object shows the right value whether or not the migration happened.

using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;

namespace CSAF.Reserialize
{
    /// <summary>Runs a migration and proves it, or explains precisely which asset it could not prove.</summary>
    public static class MigrationSession
    {
        /// <summary>
        /// Builds the ledger without writing anything.
        /// </summary>
        public static MigrationReport Plan(
            IList<RenamePair> renames,
            ScanStats stats,
            Func<int, int, bool>? onProgress = null)
        {
            if (renames == null) { throw new ArgumentNullException(nameof(renames)); }
            if (stats == null) { throw new ArgumentNullException(nameof(stats)); }

            var report = new MigrationReport();
            report.StartedUtc = DateTime.UtcNow;
            report.DryRun = true;
            report.Renames.AddRange(renames);

            HashSet<string> seeds = RenameIndex.SeedGuids(renames);

            // A rename with no MonoScript (nested [Serializable], generic, mismatched file name)
            // cannot be anchored to a GUID, so its assets cannot be found by closure. Those are
            // scanned across every text asset instead - slower, and reported as such.
            bool anyUnanchored = false;
            for (int i = 0; i < renames.Count; i++)
            {
                if (renames[i].IsNestedSerializable) { anyUnanchored = true; break; }
            }

            List<string> paths = anyUnanchored
                ? AssetIndex.EnumerateCandidatePaths()
                : AssetIndex.Closure(seeds, stats, onProgress);

            if (anyUnanchored)
            {
                stats.FilesEnumerated = paths.Count;
                stats.ClosureRounds = 0;
            }

            for (int i = 0; i < paths.Count; i++)
            {
                if (onProgress != null && !onProgress(i, paths.Count)) { break; }

                string path = paths[i];
                string? text = TryRead(path);
                if (text == null) { continue; }

                if (anyUnanchored) { stats.FilesRead++; }

                var docs = YamlProbe.SplitDocuments(text);
                if (docs.Count == 0)
                {
                    // Present on disk but not text YAML: Force Binary or Mixed. We must not pass it.
                    if (!stats.UnreadableFiles.Contains(path)) { stats.UnreadableFiles.Add(path); }
                    continue;
                }

                bool isVariant = IsPrefabVariant(path);

                for (int r = 0; r < renames.Count; r++)
                {
                    MigrationRow? row = ProbeBefore(path, docs, renames[r], isVariant);
                    if (row != null) { report.Rows.Add(row); }
                }
            }

            report.FinishedUtc = DateTime.UtcNow;
            return report;
        }

        /// <summary>
        /// Rewrites every asset in the plan, then re-reads them and fills in the proof.
        /// </summary>
        /// <remarks>
        /// The report is mutated in place and <see cref="MigrationReport.DryRun"/> becomes false, so
        /// a caller cannot accidentally show a pre-write ledger as though it were a result.
        /// </remarks>
        public static void Execute(MigrationReport report, Action<string>? onStep = null)
        {
            if (report == null) { throw new ArgumentNullException(nameof(report)); }
            if (report.Rows.Count == 0)
            {
                // Nothing to do is NOT success. Leave DryRun set so SafeToRemoveAttributes stays
                // false and the caller has to say out loud that it found nothing.
                return;
            }

            var paths = new List<string>();
            var seen = new HashSet<string>(StringComparer.Ordinal);
            for (int i = 0; i < report.Rows.Count; i++)
            {
                if (seen.Add(report.Rows[i].AssetPath)) { paths.Add(report.Rows[i].AssetPath); }
            }

            if (onStep != null) { onStep("Reserializing " + paths.Count + " asset(s)"); }

            // ForceReserializeAssets takes the whole collection and does its own import batching -
            // this IS the batched form. Wrapping it in StartAssetEditing/StopAssetEditing would
            // defer the very imports whose output we are about to read back.
            AssetDatabase.ForceReserializeAssets(paths);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            report.DryRun = false;

            if (onStep != null) { onStep("Re-reading " + paths.Count + " asset(s) to prove the migration"); }

            for (int i = 0; i < report.Rows.Count; i++)
            {
                ProveAfter(report.Rows[i]);
            }

            // ---- second pass: the override paths Unity will not migrate ------------------------
            //
            // MEASURED: ForceReserializeAssets does NOT remap an m_Modifications propertyPath through
            // [FormerlySerializedAs] - a prefab variant comes back still naming the old key. So any
            // row that is still Failed for that specific reason gets the narrow YAML rewrite, and is
            // then RE-PROVEN from disk exactly like everything else. No row is ever marked Proven
            // because we rewrote it; it is marked Proven because re-reading the file said so.
            int repaired = RepairOverridePaths(report, onStep);
            if (repaired > 0)
            {
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();

                for (int i = 0; i < report.Rows.Count; i++)
                {
                    if (report.Rows[i].OverridePathsRewritten > 0) { ProveAfter(report.Rows[i]); }
                }
            }

            report.FinishedUtc = DateTime.UtcNow;
        }

        /// <summary>
        /// Rewrites stranded <c>m_Modifications</c> override paths, one asset at a time.
        /// </summary>
        /// <returns>How many assets were edited.</returns>
        static int RepairOverridePaths(MigrationReport report, Action<string>? onStep)
        {
            // Group by asset: one file may carry override rows for several renames, and it must be
            // read and written once, not once per row.
            var byAsset = new Dictionary<string, List<MigrationRow>>(StringComparer.Ordinal);

            for (int i = 0; i < report.Rows.Count; i++)
            {
                MigrationRow row = report.Rows[i];

                // Only rows that survived the rewrite still naming the old key, and only where the
                // old key survives as an OVERRIDE PATH. A plain field that is still present is a
                // different failure and must NOT be quietly patched - that would be editing the
                // buyer's data rather than a path Unity forgot to remap.
                if (row.Proof != ProofState.Failed || !row.OldKeyStillPresent) { continue; }

                string? text = TryRead(row.AssetPath);
                if (text == null) { continue; }

                var docs = YamlProbe.SplitDocuments(text);
                bool onlyAsOverride = true;
                bool anyOverride = false;

                for (int d = 0; d < docs.Count; d++)
                {
                    if (YamlProbe.ReadFieldValue(docs[d].Text, row.Rename.OldName) != null)
                    {
                        onlyAsOverride = false;
                    }
                    if (YamlProbe.CountVariantOverridesFor(docs[d].Text, row.Rename.OldName) > 0)
                    {
                        anyOverride = true;
                    }
                }

                if (!anyOverride || !onlyAsOverride) { continue; }

                List<MigrationRow> list;
                if (!byAsset.TryGetValue(row.AssetPath, out list))
                {
                    list = new List<MigrationRow>();
                    byAsset[row.AssetPath] = list;
                }
                list.Add(row);
            }

            if (byAsset.Count == 0) { return 0; }

            if (onStep != null)
            {
                onStep("Repairing override paths Unity does not migrate, in " + byAsset.Count + " asset(s)");
            }

            int edited = 0;
            foreach (var kv in byAsset)
            {
                string? text = TryRead(kv.Key);
                if (text == null) { continue; }

                int totalForAsset = 0;
                for (int i = 0; i < kv.Value.Count; i++)
                {
                    MigrationRow row = kv.Value[i];
                    int n;
                    text = YamlProbe.RewriteVariantOverridePaths(text, row.Rename.OldName, row.Rename.NewName, out n);
                    row.OverridePathsRewritten = n;
                    totalForAsset += n;
                }

                if (totalForAsset == 0) { continue; }

                try
                {
                    File.WriteAllText(AssetIndex.ToFullPath(kv.Key), text);
                    AssetDatabase.ImportAsset(kv.Key, ImportAssetOptions.ForceUpdate);
                    edited++;
                }
                catch (IOException e)
                {
                    for (int i = 0; i < kv.Value.Count; i++)
                    {
                        kv.Value[i].OverridePathsRewritten = 0;
                        kv.Value[i].Reason = "Could not write the override-path repair: " + e.Message;
                    }
                }
            }

            return edited;
        }

        // ---- phase 1: what is there now -------------------------------------------------------

        static MigrationRow? ProbeBefore(
            string path,
            List<YamlProbe.YamlDocument> docs,
            RenamePair rename,
            bool isVariant)
        {
            int occurrences = 0;
            string? valueBefore = null;
            bool sawBlock = false;

            for (int d = 0; d < docs.Count; d++)
            {
                var doc = docs[d];

                // Plain field occurrence. When the rename is anchored to a script GUID, only look
                // inside documents that actually use that script - otherwise an unrelated component
                // that happens to serialize a field of the same name would be counted.
                bool documentMatches =
                    rename.ScriptGuid.Length == 0 ||
                    (doc.ScriptGuid != null && string.Equals(doc.ScriptGuid, rename.ScriptGuid, StringComparison.Ordinal));

                if (documentMatches)
                {
                    string? v = YamlProbe.ReadFieldValue(doc.Text, rename.OldName);
                    if (v != null)
                    {
                        occurrences++;
                        if (ReferenceEquals(v, YamlProbe.BlockValueSentinel) || v == YamlProbe.BlockValueSentinel)
                        {
                            sawBlock = true;
                        }
                        else if (valueBefore == null) { valueBefore = v; }
                    }
                }

                // Variant / instance override occurrence. Deliberately NOT gated on the script GUID:
                // a PrefabInstance document has no m_Script at all, which is the entire reason the
                // GUID filter cannot be trusted here.
                if (doc.IsPrefabInstance)
                {
                    int overrides = YamlProbe.CountVariantOverridesFor(doc.Text, rename.OldName);
                    if (overrides > 0)
                    {
                        occurrences += overrides;
                        string? ov = YamlProbe.ReadVariantOverrideValue(doc.Text, rename.OldName);
                        if (ov == YamlProbe.BlockValueSentinel) { sawBlock = true; }
                        else if (valueBefore == null) { valueBefore = ov; }
                    }
                }
            }

            if (occurrences == 0) { return null; }

            var row = new MigrationRow
            {
                AssetPath = path,
                Rename = rename,
                OccurrenceCount = occurrences,
                ValueBefore = valueBefore,
                IsPrefabVariant = isVariant,
                Proof = ProofState.Unknown,
            };

            if (sawBlock && valueBefore == null)
            {
                row.Reason = "The old key holds a nested block, so its value cannot be compared verbatim. " +
                             "The migration may still be correct - this tool will not claim it is.";
            }

            return row;
        }

        // ---- phase 3: did it actually happen --------------------------------------------------

        static void ProveAfter(MigrationRow row)
        {
            string? text = TryRead(row.AssetPath);
            if (text == null)
            {
                row.Proof = ProofState.Unverifiable;
                row.Reason = "The asset could not be read back after reserialization.";
                return;
            }

            var docs = YamlProbe.SplitDocuments(text);
            if (docs.Count == 0)
            {
                row.Proof = ProofState.Unverifiable;
                row.Reason = "After reserialization the asset is not text YAML. Force Text Serialization " +
                             "must be enabled for this tool to prove anything.";
                return;
            }

            bool oldPresent = false;
            string? valueAfter = null;
            bool sawBlock = false;

            for (int d = 0; d < docs.Count; d++)
            {
                var doc = docs[d];

                if (YamlProbe.ReadFieldValue(doc.Text, row.Rename.OldName) != null) { oldPresent = true; }
                if (doc.IsPrefabInstance && YamlProbe.CountVariantOverridesFor(doc.Text, row.Rename.OldName) > 0)
                {
                    oldPresent = true;
                }

                if (valueAfter == null)
                {
                    string? v = YamlProbe.ReadFieldValue(doc.Text, row.Rename.NewName);
                    if (v == YamlProbe.BlockValueSentinel) { sawBlock = true; }
                    else if (v != null) { valueAfter = v; }
                }

                if (valueAfter == null && doc.IsPrefabInstance)
                {
                    string? ov = YamlProbe.ReadVariantOverrideValue(doc.Text, row.Rename.NewName);
                    if (ov == YamlProbe.BlockValueSentinel) { sawBlock = true; }
                    else if (ov != null) { valueAfter = ov; }
                }
            }

            row.OldKeyStillPresent = oldPresent;
            row.ValueAfter = valueAfter;

            if (oldPresent)
            {
                // AN UNANCHORED RENAME MAY NOT RETURN "Failed" FROM A RAW KEY MATCH.
                //
                // Without a script GUID there is no MonoScript to tie the rename to a specific
                // object, so ReadFieldValue searches the WHOLE document for "  <oldName>:". A hit
                // therefore proves only that SOMETHING in this asset serialises a field of that
                // name - not that it is the field this rename is about. Common Unity field names
                // (m_Enabled, m_Name, m_Size ...) collide constantly.
                //
                // Failed means MEASURED BAD. Unverifiable means COULD NOT MEASURE. Blurring them is
                // the one thing this product sells against, and blurring them HERE produced a red
                // "AT RISK / DO NOT REMOVE [FormerlySerializedAs]" banner on a clean project.
                if (row.Rename.IsNestedSerializable)
                {
                    row.Proof = ProofState.Unverifiable;
                    row.Reason = "A field named '" + row.Rename.OldName + "' is still in this asset, but " +
                                 "this rename has no script anchor, so it cannot be told apart from an " +
                                 "unrelated field of the same name on another object. Check this asset by hand.";
                    return;
                }

                row.Proof = ProofState.Failed;
                row.Reason = "The OLD key is still on disk after reserialization. Removing " +
                             "[FormerlySerializedAs] now would strand this data.";
                return;
            }

            if (sawBlock && valueAfter == null)
            {
                row.Proof = ProofState.Unverifiable;
                row.Reason = "The old key is gone, but the new key holds a nested block this version " +
                             "does not compare verbatim. Verify this asset by hand before removing the attribute.";
                return;
            }

            if (valueAfter == null)
            {
                row.Proof = ProofState.Failed;
                row.Reason = "The old key is gone and NO value was found under the new key. " +
                             "Treat this asset as data loss and restore it from version control.";
                return;
            }

            if (row.ValueBefore == null)
            {
                row.Proof = ProofState.Unverifiable;
                row.Reason = "No before-value was recorded, so the after-value cannot be compared to anything.";
                return;
            }

            if (!string.Equals(row.ValueBefore, valueAfter, StringComparison.Ordinal))
            {
                row.Proof = ProofState.Failed;
                row.Reason = "The value CHANGED during migration: '" + row.ValueBefore + "' -> '" + valueAfter + "'.";
                return;
            }

            row.Proof = ProofState.Proven;
            row.Reason = null;
        }

        // ---- helpers --------------------------------------------------------------------------

        static bool IsPrefabVariant(string path)
        {
            if (!path.EndsWith(".prefab", StringComparison.OrdinalIgnoreCase)) { return false; }

            var go = AssetDatabase.LoadAssetAtPath<UnityEngine.GameObject>(path);
            if (go == null) { return false; }
            return PrefabUtility.GetPrefabAssetType(go) == PrefabAssetType.Variant;
        }

        static string? TryRead(string assetPath)
        {
            try
            {
                string full = AssetIndex.ToFullPath(assetPath);
                if (!File.Exists(full)) { return null; }
                return File.ReadAllText(full);
            }
            catch (IOException) { return null; }
            catch (UnauthorizedAccessException) { return null; }
        }

        /// <summary>
        /// True when the project is serializing assets as text, which everything here depends on.
        /// </summary>
        public static bool ProjectIsForceText()
        {
            return EditorSettings.serializationMode == SerializationMode.ForceText;
        }
    }
}
