// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.
#nullable enable
// CSAF Reserialize - data model.
//
// #nullable enable is per FILE, deliberately (wing rule): a buyer whose project does NOT enable
// nullable would otherwise get CS8632 on every annotation here, and their -warnaserror would turn
// that into a build failure in code they did not write.

using System;
using System.Collections.Generic;

namespace CSAF.Reserialize
{
    /// <summary>
    /// How confident we are that a single asset's data actually migrated.
    /// <para>
    /// The whole product is this enum. Anything that is not <see cref="Proven"/> must be visually
    /// impossible to miss in the ledger - a migration tool that quietly reports success it did not
    /// verify is worse than no tool, because the buyer then deletes the
    /// <c>[FormerlySerializedAs]</c> attribute that was the only thing keeping their data reachable.
    /// </para>
    /// </summary>
    public enum ProofState
    {
        /// <summary>Not yet examined.</summary>
        Unknown = 0,

        /// <summary>
        /// Old key gone AND the value is present under the new key AND it compares equal to the
        /// value read before the rewrite. This is the only state that authorises removing the
        /// <c>[FormerlySerializedAs]</c> attribute.
        /// </summary>
        Proven = 1,

        /// <summary>
        /// The asset was reserialized but the proof could not be established - typically because the
        /// value could not be located under either key after the rewrite. Treat as DATA AT RISK.
        /// </summary>
        Failed = 2,

        /// <summary>
        /// Nothing to do: the old key was never present in this asset, so no migration was required.
        /// Reported rather than hidden, because "0 affected" and "not scanned" look identical in a
        /// summary and only one of them is good news.
        /// </summary>
        NotAffected = 3,

        /// <summary>
        /// We can see the old key but deliberately cannot assert on the value - a shape this version
        /// does not parse (deeply nested generic collection, custom formatter). Honest amber. The
        /// buyer is told which asset and why, and the attribute must NOT be removed.
        /// </summary>
        Unverifiable = 4,
    }

    /// <summary>
    /// One serialized-field rename, discovered from a <c>[FormerlySerializedAs]</c> attribute.
    /// </summary>
    public sealed class RenamePair
    {
        /// <summary>Declaring type's full name, e.g. <c>MyGame.Player</c>.</summary>
        public string DeclaringType = string.Empty;

        /// <summary>The name the field used to serialize under.</summary>
        public string OldName = string.Empty;

        /// <summary>The name the field serializes under now.</summary>
        public string NewName = string.Empty;

        /// <summary>
        /// GUID of the <c>MonoScript</c> that declares this type. This is the index key that makes
        /// the scan cheap: an asset can only be affected if its YAML references this GUID, so we
        /// never have to parse every asset in the project.
        /// </summary>
        public string ScriptGuid = string.Empty;

        /// <summary>True when the declaring type is a nested <c>[Serializable]</c> rather than a
        /// <c>MonoBehaviour</c>/<c>ScriptableObject</c>. These are found by key, not by script GUID,
        /// so they are scanned more broadly and reported separately.</summary>
        public bool IsNestedSerializable;

        public override string ToString()
        {
            return DeclaringType + ": " + OldName + " -> " + NewName;
        }
    }

    /// <summary>One row of the migration ledger: what happened to one asset, for one rename.</summary>
    public sealed class MigrationRow
    {
        /// <summary>Project-relative asset path.</summary>
        public string AssetPath = string.Empty;

        /// <summary>The rename this row is about.</summary>
        public RenamePair Rename = new RenamePair();

        /// <summary>Value found under the OLD key before the rewrite, verbatim from the YAML.</summary>
        public string? ValueBefore;

        /// <summary>Value found under the NEW key after the rewrite, verbatim from the YAML.</summary>
        public string? ValueAfter;

        /// <summary>Whether the old key was still present after the rewrite. Must be false to pass.</summary>
        public bool OldKeyStillPresent;

        /// <summary>How many serialized objects inside this asset carried the old key.</summary>
        public int OccurrenceCount;

        /// <summary>Verdict.</summary>
        public ProofState Proof = ProofState.Unknown;

        /// <summary>Plain-language reason, always set when <see cref="Proof"/> is not Proven.</summary>
        public string? Reason;

        /// <summary>True when the asset is a prefab VARIANT. Called out separately because variant
        /// override blocks are where this class of migration breaks worst, and where three of the
        /// cited demand threads say people actually lost data.</summary>
        public bool IsPrefabVariant;

        /// <summary>
        /// How many <c>m_Modifications</c> override paths this tool had to rewrite itself.
        /// </summary>
        /// <remarks>
        /// Non-zero means Unity's own reserialization left the old path stranded and Reserialize
        /// repaired it. Surfaced in the ledger and the JSON rather than hidden, because it is a
        /// change to the buyer's file that reserialization alone would not have made - and because
        /// it is the measured thing this product does that nothing else does.
        /// </remarks>
        public int OverridePathsRewritten;
    }

    /// <summary>The result of one migration run - the object the ledger UI and the CI gate both read.</summary>
    public sealed class MigrationReport
    {
        public DateTime StartedUtc;
        public DateTime FinishedUtc;

        /// <summary>Every rename discovered in the project, whether or not anything used it.</summary>
        public List<RenamePair> Renames = new List<RenamePair>();

        /// <summary>One row per (asset, rename) pair that had something to migrate.</summary>
        public List<MigrationRow> Rows = new List<MigrationRow>();

        /// <summary>True when the run only inspected and wrote nothing.</summary>
        public bool DryRun;

        public int ProvenCount { get { return CountOf(ProofState.Proven); } }
        public int FailedCount { get { return CountOf(ProofState.Failed); } }
        public int UnverifiableCount { get { return CountOf(ProofState.Unverifiable); } }

        /// <summary>
        /// True only when every row that needed migrating is <see cref="ProofState.Proven"/>.
        /// <para>
        /// Note what this deliberately does NOT do: it does not treat "no rows" as success. A run
        /// that found nothing is reported as such by <see cref="Rows"/> being empty, and the caller
        /// decides whether that is good news. A pass with a zero next to it is a failure wearing a
        /// pass.
        /// </para>
        /// </summary>
        public bool AllProven
        {
            get
            {
                for (int i = 0; i < Rows.Count; i++)
                {
                    ProofState s = Rows[i].Proof;
                    if (s == ProofState.Failed || s == ProofState.Unverifiable || s == ProofState.Unknown)
                    {
                        return false;
                    }
                }
                return true;
            }
        }

        /// <summary>
        /// True when it is safe to remove the <c>[FormerlySerializedAs]</c> attributes covered by this
        /// run. This is the single question the product exists to answer, so it is one property and
        /// it is conservative: any unproven or unverifiable row makes it false.
        /// </summary>
        public bool SafeToRemoveAttributes
        {
            get { return !DryRun && Rows.Count > 0 && AllProven; }
        }

        int CountOf(ProofState s)
        {
            int n = 0;
            for (int i = 0; i < Rows.Count; i++)
            {
                if (Rows[i].Proof == s) { n++; }
            }
            return n;
        }
    }
}
