// Copyright (c) 2026 CSAF (Corey Gallant and Stephanie Thomason). All rights reserved.
#nullable enable
// CSAF Reserialize - the visual language of the ledger.
//
// The ledger IS the product's claim, so it is not allowed to look like a default inspector. Every
// value here is deliberate: one accent, three verdict colours, four text weights, and a single
// spacing step that everything is a multiple of.
//
// Colours are set on elements directly rather than through a StyleSheet asset. That is not a
// shortcut - it means the package has no .uss to find at runtime, so a buyer who moves or renames
// the folder still gets a correctly styled window. An AssetDatabase path lookup would be one more
// thing that can silently degrade to "unstyled but no error".

using UnityEngine;
using UnityEngine.UIElements;

namespace CSAF.Reserialize.UI
{
    /// <summary>Palette, spacing and the small set of element factories the ledger is built from.</summary>
    internal static class Theme
    {
        // ---- palette -------------------------------------------------------------------------
        public static readonly Color Backdrop   = Hex(0x16181D);
        public static readonly Color Panel      = Hex(0x1E222A);
        public static readonly Color PanelRaised= Hex(0x242933);
        public static readonly Color Line       = Hex(0x2F3542);

        public static readonly Color TextHigh   = Hex(0xE8ECF4);
        public static readonly Color TextMid    = Hex(0xA6AEC0);
        public static readonly Color TextLow    = Hex(0x6E7787);

        public static readonly Color Accent     = Hex(0x6C8CFF);
        public static readonly Color Proven     = Hex(0x35D399);
        public static readonly Color Failed     = Hex(0xFF6B6B);
        public static readonly Color Amber      = Hex(0xFFC145);

        // ---- spacing -------------------------------------------------------------------------
        public const int Step = 6;
        public const int Gutter = Step * 2;

        public static Color Hex(int rgb)
        {
            return new Color(
                ((rgb >> 16) & 0xFF) / 255f,
                ((rgb >> 8) & 0xFF) / 255f,
                (rgb & 0xFF) / 255f,
                1f);
        }

        public static Color Tint(Color c, float alpha)
        {
            return new Color(c.r, c.g, c.b, alpha);
        }

        /// <summary>The colour that stands for a proof state, everywhere in the UI.</summary>
        public static Color ColorFor(ProofState state)
        {
            switch (state)
            {
                case ProofState.Proven:       return Proven;
                case ProofState.Failed:       return Failed;
                case ProofState.Unverifiable: return Amber;
                case ProofState.NotAffected:  return TextLow;
                default:                      return Amber;
            }
        }

        /// <summary>The word shown to the buyer. Deliberately plain English, never the enum name.</summary>
        public static string LabelFor(ProofState state)
        {
            switch (state)
            {
                case ProofState.Proven:       return "PROVEN";
                case ProofState.Failed:       return "AT RISK";
                case ProofState.Unverifiable: return "UNPROVEN";
                case ProofState.NotAffected:  return "NO CHANGE";
                default:                      return "NOT RUN";
            }
        }

        // ---- element factories ----------------------------------------------------------------

        public static VisualElement Row()
        {
            var e = new VisualElement();
            e.style.flexDirection = FlexDirection.Row;
            e.style.alignItems = Align.Center;
            return e;
        }

        public static VisualElement Spacer()
        {
            var e = new VisualElement();
            e.style.flexGrow = 1f;
            return e;
        }

        public static Label Text(string value, int size, Color color, FontStyle style = FontStyle.Normal)
        {
            var l = new Label(value);
            l.style.fontSize = size;
            l.style.color = color;
            l.style.unityFontStyleAndWeight = style;
            l.style.marginLeft = 0;
            l.style.marginRight = 0;
            l.style.marginTop = 0;
            l.style.marginBottom = 0;
            l.style.paddingLeft = 0;
            l.style.paddingRight = 0;
            return l;
        }

        /// <summary>A serialized key. Monospaced, because these are compared character by character.</summary>
        public static Label Key(string value, Color color)
        {
            var l = Text(value, 12, color);
            l.style.unityFontStyleAndWeight = FontStyle.Bold;
            l.style.letterSpacing = 0.4f;
            return l;
        }

        public static VisualElement Card()
        {
            var e = new VisualElement();
            e.style.backgroundColor = Panel;
            SetBorderRadius(e, 6);
            SetBorderWidth(e, 1);
            SetBorderColor(e, Line);
            e.style.paddingTop = Step;
            e.style.paddingBottom = Step;
            e.style.paddingLeft = Gutter;
            e.style.paddingRight = Gutter;
            e.style.marginBottom = Step;
            return e;
        }

        /// <summary>A small colour-coded pill. The only place a verdict is allowed to be shown.</summary>
        public static VisualElement Chip(string text, Color color)
        {
            var chip = new VisualElement();
            chip.style.flexDirection = FlexDirection.Row;
            chip.style.alignItems = Align.Center;
            chip.style.backgroundColor = Tint(color, 0.14f);
            SetBorderRadius(chip, 3);
            SetBorderWidth(chip, 1);
            SetBorderColor(chip, Tint(color, 0.45f));
            chip.style.paddingLeft = Step;
            chip.style.paddingRight = Step;
            chip.style.paddingTop = 1;
            chip.style.paddingBottom = 1;

            var l = Text(text, 10, color, FontStyle.Bold);
            l.style.letterSpacing = 0.8f;
            chip.Add(l);
            return chip;
        }

        public static VisualElement Divider()
        {
            var e = new VisualElement();
            e.style.height = 1;
            e.style.backgroundColor = Line;
            e.style.marginTop = Step;
            e.style.marginBottom = Step;
            return e;
        }

        public static void SetBorderRadius(VisualElement e, int r)
        {
            e.style.borderTopLeftRadius = r;
            e.style.borderTopRightRadius = r;
            e.style.borderBottomLeftRadius = r;
            e.style.borderBottomRightRadius = r;
        }

        public static void SetBorderWidth(VisualElement e, int w)
        {
            e.style.borderTopWidth = w;
            e.style.borderBottomWidth = w;
            e.style.borderLeftWidth = w;
            e.style.borderRightWidth = w;
        }

        public static void SetBorderColor(VisualElement e, Color c)
        {
            e.style.borderTopColor = c;
            e.style.borderBottomColor = c;
            e.style.borderLeftColor = c;
            e.style.borderRightColor = c;
        }

        public static Button FlatButton(string text, Color accent, bool filled)
        {
            var b = new Button();
            b.text = text;
            b.style.height = 24;
            b.style.paddingLeft = Gutter;
            b.style.paddingRight = Gutter;
            b.style.marginLeft = 0;
            b.style.marginRight = Step;
            b.style.marginTop = 0;
            b.style.marginBottom = 0;
            b.style.backgroundColor = filled ? accent : Tint(accent, 0.10f);
            b.style.color = filled ? Hex(0x11131A) : accent;
            b.style.unityFontStyleAndWeight = FontStyle.Bold;
            b.style.fontSize = 11;
            SetBorderRadius(b, 4);
            SetBorderWidth(b, 1);
            SetBorderColor(b, Tint(accent, filled ? 1f : 0.5f));
            return b;
        }
    }
}
