// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.
#nullable enable
// CSAF Reserialize - which assets can possibly be affected.
//
// THE DESIGN DECISION THIS FILE EXISTS FOR.
//
// The obvious index is "an asset is affected if its YAML references the MonoScript GUID". It is
// cheap, it is correct for scenes and plain prefabs, and IT MISSES EVERY PREFAB VARIANT. A variant
// stores nothing about the script: its PrefabInstance document carries no m_Script line, and its
// override rows target the BASE PREFAB's GUID. So a GUID filter looks straight past the single
// place this class of migration is most likely to lose data - which is exactly where the demand
// threads say people lost it.
//
// So the index is a CLOSURE, not a filter. Seed with the script GUIDs, take every asset that
// references them, then take every asset that references THOSE assets, and repeat until nothing
// new appears. That catches variants, variants of variants, nested prefabs, and scenes holding any
// of them, without ever having to load an object.
//
// Cost: one text read per prefab/scene/asset file, once. Everything after that is set arithmetic.

using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;

namespace CSAF.Reserialize
{
    /// <summary>What the scan actually looked at. Reported so a zero can never pass for a pass.</summary>
    public sealed class ScanStats
    {
        /// <summary>Asset files enumerated as candidates.</summary>
        public int FilesEnumerated;

        /// <summary>Asset files whose text was read and indexed.</summary>
        public int FilesRead;

        /// <summary>Files that could not be read as Unity text YAML (binary/mixed serialization).</summary>
        public List<string> UnreadableFiles = new List<string>();

        /// <summary>How many closure rounds ran. More than one means variants or nesting were found.</summary>
        public int ClosureRounds;

        /// <summary>Assets reached only in round 2 or later - i.e. found ONLY by the closure.</summary>
        public List<string> ReachedByClosureOnly = new List<string>();
    }

    /// <summary>Builds the set of assets that could hold a renamed field's data.</summary>
    public static class AssetIndex
    {
        /// <summary>Asset extensions Unity serializes as text YAML and that can hold script data.</summary>
        static readonly string[] Extensions = { ".prefab", ".unity", ".asset" };

        /// <summary>
        /// Every asset that transitively references one of <paramref name="seedGuids"/>.
        /// </summary>
        /// <param name="seedGuids">MonoScript GUIDs from <see cref="RenameIndex.SeedGuids"/>.</param>
        /// <param name="stats">Filled with what was actually examined.</param>
        /// <param name="onProgress">
        /// Called as <c>(done, total)</c>. Return false to cancel - the caller gets whatever was
        /// indexed so far and MUST treat the result as incomplete.
        /// </param>
        public static List<string> Closure(
            ICollection<string> seedGuids,
            ScanStats stats,
            Func<int, int, bool>? onProgress = null)
        {
            if (stats == null) { throw new ArgumentNullException(nameof(stats)); }

            List<string> candidates = EnumerateCandidatePaths();
            stats.FilesEnumerated = candidates.Count;

            // path -> the GUIDs its text mentions.  path -> its own GUID.
            var referencesByPath = new Dictionary<string, HashSet<string>>(StringComparer.Ordinal);
            var guidByPath = new Dictionary<string, string>(StringComparer.Ordinal);

            for (int i = 0; i < candidates.Count; i++)
            {
                string path = candidates[i];

                if (onProgress != null && !onProgress(i, candidates.Count))
                {
                    break;
                }

                string? text = TryReadText(path);
                if (text == null || !text.StartsWith("%YAML", StringComparison.Ordinal))
                {
                    stats.UnreadableFiles.Add(path);
                    continue;
                }

                stats.FilesRead++;
                referencesByPath[path] = ExtractGuids(text);
                guidByPath[path] = AssetDatabase.AssetPathToGUID(path);
            }

            // ---- the closure ----------------------------------------------------------------
            var reached = new HashSet<string>(StringComparer.Ordinal);   // asset paths
            var frontier = new HashSet<string>(seedGuids, StringComparer.Ordinal);
            int round = 0;

            while (frontier.Count > 0)
            {
                round++;
                var nextFrontier = new HashSet<string>(StringComparer.Ordinal);

                foreach (var kv in referencesByPath)
                {
                    if (reached.Contains(kv.Key)) { continue; }

                    if (!Intersects(kv.Value, frontier)) { continue; }

                    reached.Add(kv.Key);
                    if (round > 1) { stats.ReachedByClosureOnly.Add(kv.Key); }

                    string ownGuid;
                    if (guidByPath.TryGetValue(kv.Key, out ownGuid) && ownGuid.Length > 0)
                    {
                        nextFrontier.Add(ownGuid);
                    }
                }

                frontier = nextFrontier;

                // A project can always be malformed; refuse to spin.
                if (round > 64) { break; }
            }

            stats.ClosureRounds = round;

            var result = new List<string>(reached);
            result.Sort(StringComparer.Ordinal);
            return result;
        }

        static bool Intersects(HashSet<string> set, HashSet<string> other)
        {
            // Walk the smaller side.
            if (set.Count > other.Count)
            {
                foreach (string s in other) { if (set.Contains(s)) { return true; } }
                return false;
            }
            foreach (string s in set) { if (other.Contains(s)) { return true; } }
            return false;
        }

        /// <summary>Every project asset that Unity serializes as text and that can carry script data.</summary>
        public static List<string> EnumerateCandidatePaths()
        {
            var paths = new List<string>();
            var seen = new HashSet<string>(StringComparer.Ordinal);

            string[] all = AssetDatabase.GetAllAssetPaths();
            for (int i = 0; i < all.Length; i++)
            {
                string p = all[i];

                // Only the buyer's own assets. Package contents are not ours to rewrite.
                if (!p.StartsWith("Assets/", StringComparison.Ordinal)) { continue; }

                string ext = Path.GetExtension(p);
                bool wanted = false;
                for (int e = 0; e < Extensions.Length; e++)
                {
                    if (string.Equals(ext, Extensions[e], StringComparison.OrdinalIgnoreCase))
                    {
                        wanted = true;
                        break;
                    }
                }
                if (!wanted) { continue; }

                if (seen.Add(p)) { paths.Add(p); }
            }

            paths.Sort(StringComparer.Ordinal);
            return paths;
        }

        /// <summary>
        /// Pulls every 32-character hex GUID out of an asset's text.
        /// </summary>
        /// <remarks>
        /// Scans for the literal <c>guid:</c> rather than regexing the whole file. Unity writes every
        /// cross-asset reference that way - <c>{fileID: N, guid: ..., type: 3}</c> - and a general hex
        /// scan would also match fileIDs and hashes, which would widen the closure to the whole
        /// project and quietly turn a targeted scan into a full rescan.
        /// </remarks>
        public static HashSet<string> ExtractGuids(string text)
        {
            var guids = new HashSet<string>(StringComparer.Ordinal);
            const string Needle = "guid:";
            int idx = 0;

            while (idx < text.Length)
            {
                int at = text.IndexOf(Needle, idx, StringComparison.Ordinal);
                if (at < 0) { break; }

                int start = at + Needle.Length;
                while (start < text.Length && text[start] == ' ') { start++; }

                int end = start;
                while (end < text.Length && IsHex(text[end])) { end++; }

                if (end - start == 32) { guids.Add(text.Substring(start, 32)); }
                idx = end > at ? end : at + Needle.Length;
            }
            return guids;
        }

        static bool IsHex(char c)
        {
            return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
        }

        static string? TryReadText(string assetPath)
        {
            try
            {
                string full = ToFullPath(assetPath);
                if (!File.Exists(full)) { return null; }
                return File.ReadAllText(full);
            }
            catch (IOException) { return null; }
            catch (UnauthorizedAccessException) { return null; }
        }

        /// <summary>Project-relative asset path to an absolute path on disk.</summary>
        public static string ToFullPath(string assetPath)
        {
            string dataPath = UnityEngine.Application.dataPath;          // <project>/Assets
            var parent = Directory.GetParent(dataPath);
            string projectRoot = parent != null ? parent.FullName : dataPath;
            return Path.Combine(projectRoot, assetPath.Replace('/', Path.DirectorySeparatorChar));
        }
    }
}
