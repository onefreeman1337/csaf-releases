// Copyright (c) 2026 CSAF (Corey Gallant and Stephanie Thomason). All rights reserved.
#nullable enable
// CSAF Reserialize - demo component.
//
// This component is deliberately shipped in the state your own project is in the moment after a
// rename: the C# field has its NEW name and carries [FormerlySerializedAs], while the demo assets
// on disk still hold the OLD key.
//
// That is why the ledger has something real to show the moment you open it - the demo is not a
// mock-up, it is three genuinely un-migrated assets.
//
// DELETE Assets/CSAF/Reserialize/Demo/ once you have seen it. If you wire the CI gate up while the
// demo folder is still present, Verify will correctly report these assets as outstanding work - or
// pass -reserializeIgnore Assets/CSAF/Reserialize/Demo.

using UnityEngine;
using UnityEngine.Serialization;

namespace CSAF.Reserialize.Demo
{
    /// <summary>A component whose serialized fields have been renamed.</summary>
    [AddComponentMenu("CSAF/Reserialize Demo/Renamed Component")]
    public class RenamedComponent : MonoBehaviour
    {
        [Tooltip("Serialized as 'moveSpeed' until the rename. The demo assets still say 'moveSpeed'.")]
        [FormerlySerializedAs("moveSpeed")]
        public float speed = 5f;

        [Tooltip("Serialized as 'displayName' until the rename.")]
        [FormerlySerializedAs("displayName")]
        public string title = "Base";
    }
}
