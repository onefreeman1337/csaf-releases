// Copyright (c) 2026 CSAF (Corey Gallant and Stephanie Thomason). All rights reserved.
// CSAF CoreCLR Migration Scanner

// Nullable is enabled per file, not per project - see Model/MigrationModel.cs for why.
#nullable enable

using System;
using System.Globalization;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace CSAF.CoreCLRScanner
{
    /// <summary>
    /// Batch-mode entry point, so the scan can run as a build step.
    /// </summary>
    /// <remarks>
    /// <para>
    /// The CI gate is the half of this product that changes behaviour rather than producing a
    /// document. A migration that is only ever measured by hand regresses between measurements;
    /// one that fails the build when the breaking count rises cannot.
    /// </para>
    /// <para>
    /// Invoke with:
    /// </para>
    /// <code>
    /// Unity.exe -batchmode -quit -nographics -projectPath &lt;project&gt; \
    ///   -executeMethod CSAF.CoreCLRScanner.BatchMode.Run \
    ///   -csafOutDir CoreCLRReports -csafMaxBreaking 0 \
    ///   -csafBaseline CoreCLRReports/baseline.json -csafFailOnNew \
    ///   -csafFixPlan coreclr-fixplan.json
    /// </code>
    /// <para>
    /// <c>-csafFailOnNew</c> is the ratchet: with a committed baseline, the build fails only on
    /// findings that are NOT in it - so a team adopts the gate on day one, before the legacy debt
    /// is paid down, and the debt can only shrink. <c>-csafFixPlan</c> writes what the mechanical
    /// fixers would do as reviewable JSON; batch mode never edits source.
    /// </para>
    /// </remarks>
    public static class BatchMode
    {
        private const string OutDirArg = "-csafOutDir";
        private const string MaxBreakingArg = "-csafMaxBreaking";
        private const string BaselineArg = "-csafBaseline";
        private const string FailOnNewArg = "-csafFailOnNew";
        private const string FixPlanArg = "-csafFixPlan";

        /// <summary>
        /// Runs a scan, writes JSON and Markdown, and exits non-zero when the budget is exceeded.
        /// </summary>
        public static void Run()
        {
            int exitCode = 0;

            try
            {
                string outDir = ReadArg(OutDirArg, "CoreCLRReports") ?? "CoreCLRReports";
                string? baselinePath = ReadArg(BaselineArg, null);
                int maxBreaking = ReadIntArg(MaxBreakingArg, -1);

                ScanReport report = CoreClrScanner.ScanProject(true);

                string projectRoot = Directory.GetParent(Application.dataPath).FullName;
                string resolvedOutDir = Path.IsPathRooted(outDir) ? outDir : Path.Combine(projectRoot, outDir);

                string jsonPath = Path.Combine(resolvedOutDir, "coreclr-report.json");
                string mdPath = Path.Combine(resolvedOutDir, "coreclr-report.md");

                // Narrowed through a local rather than by relying on string.IsNullOrEmpty. That
                // method carries [NotNullWhen(false)] in current .NET, but Unity's reference
                // assemblies do not always expose the annotation, so the compiler will not always
                // infer non-nullness from it. A plain length test needs no annotation to be true.
                string baselineFile = baselinePath ?? string.Empty;
                ScanReport? baseline = null;
                if (baselineFile.Length > 0)
                {
                    baseline = ReportExporter.ReadJson(baselineFile);
                }

                ReportExporter.WriteJson(report, jsonPath);
                ReportExporter.WriteMarkdown(report, baseline, mdPath);

                Debug.Log(ReportExporter.BuildConsoleSummary(report));
                Debug.Log("[CSAF CoreCLR Scanner] Wrote " + jsonPath + " and " + mdPath);

                // The burndown: classify against the baseline and persist the delta, so a CI run
                // leaves behind the three numbers a producer reports upward rather than a raw list.
                BurndownDelta? delta = null;
                if (baseline != null)
                {
                    delta = Burndown.Delta(report, baseline);
                    string burndownPath = Path.Combine(resolvedOutDir, "coreclr-burndown.json");
                    File.WriteAllText(burndownPath, JsonUtility.ToJson(delta, true));
                    Debug.Log("[CSAF CoreCLR Scanner] " + Burndown.Summarize(delta) +
                              " - wrote " + burndownPath);
                }

                // The fix plan: what the mechanical fixers WOULD do, written for review. Batch mode
                // never edits source - a fix belongs in a commit a human made on purpose, so the
                // apply step lives in the Editor window only.
                string fixPlanPath = ReadArg(FixPlanArg, null) ?? string.Empty;
                if (fixPlanPath.Length > 0)
                {
                    string resolvedPlanPath = Path.IsPathRooted(fixPlanPath)
                        ? fixPlanPath
                        : Path.Combine(resolvedOutDir, fixPlanPath);
                    FixPlan plan = FixEngine.BuildPlan(report, projectRoot);
                    Directory.CreateDirectory(Path.GetDirectoryName(resolvedPlanPath) ?? resolvedOutDir);
                    File.WriteAllText(resolvedPlanPath, JsonUtility.ToJson(plan, true));
                    Debug.Log("[CSAF CoreCLR Scanner] Fix plan: " + plan.edits.Count + " mechanical edit(s), " +
                              plan.skips.Count + " assisted - wrote " + resolvedPlanPath);
                }

                bool failOnNew = HasFlag(FailOnNewArg);

                // A cancelled scan cannot gate anything: its counts are a lower bound, so passing a
                // budget check would be meaningless. Batch mode has no user to cancel it, which
                // makes this a should-never-happen - and should-never-happen is exactly the class
                // of thing that silently reports success.
                if (report.cancelled)
                {
                    Debug.LogError("[CSAF CoreCLR Scanner] Scan did not complete. Refusing to report a pass.");
                    exitCode = 2;
                }
                else if (failOnNew && baseline == null)
                {
                    // Fail closed. A ratchet with nothing to ratchet against would pass every build
                    // while appearing to protect it - the most expensive kind of green.
                    Debug.LogError("[CSAF CoreCLR Scanner] " + FailOnNewArg + " requires " + BaselineArg +
                                   " <coreclr-report.json>. Refusing to pretend a ratchet is in force.");
                    exitCode = 2;
                }
                else if (failOnNew && delta != null && delta.newFindings.Count > 0)
                {
                    for (int i = 0; i < delta.newFindings.Count; i++)
                    {
                        MigrationFinding nf = delta.newFindings[i];
                        Debug.LogError("[CSAF CoreCLR Scanner] NEW: " + nf.ruleId + " " + nf.path +
                                       (nf.line > 0 ? ":" + nf.line : string.Empty) + " - " + nf.title);
                    }

                    Debug.LogError("[CSAF CoreCLR Scanner] " + delta.newFindings.Count +
                                   " finding(s) not in the baseline. The ratchet holds: fix them or " +
                                   "re-baseline deliberately.");
                    exitCode = 1;
                }
                else if (maxBreaking >= 0 && report.BreakingCount > maxBreaking)
                {
                    Debug.LogError("[CSAF CoreCLR Scanner] " + report.BreakingCount +
                                   " breaking finding(s) exceeds the budget of " + maxBreaking + ".");
                    exitCode = 1;
                }
            }
            catch (Exception ex)
            {
                Debug.LogError("[CSAF CoreCLR Scanner] Batch scan failed: " + ex);
                exitCode = 3;
            }

            EditorApplication.Exit(exitCode);
        }

        private static bool HasFlag(string name)
        {
            string[] args = Environment.GetCommandLineArgs();
            for (int i = 0; i < args.Length; i++)
            {
                if (string.Equals(args[i], name, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }

        private static string? ReadArg(string name, string? fallback)
        {
            string[] args = Environment.GetCommandLineArgs();
            for (int i = 0; i < args.Length - 1; i++)
            {
                if (string.Equals(args[i], name, StringComparison.OrdinalIgnoreCase))
                {
                    return args[i + 1];
                }
            }

            return fallback;
        }

        private static int ReadIntArg(string name, int fallback)
        {
            string? raw = ReadArg(name, null);
            int parsed;
            if (!string.IsNullOrEmpty(raw) &&
                int.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out parsed))
            {
                return parsed;
            }

            return fallback;
        }
    }
}
