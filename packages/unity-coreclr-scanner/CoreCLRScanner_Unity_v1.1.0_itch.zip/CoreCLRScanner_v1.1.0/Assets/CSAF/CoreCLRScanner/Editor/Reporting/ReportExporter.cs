// Copyright (c) 2026 CSAF (Corey Gallant and Stephanie Thomason). All rights reserved.
// CSAF CoreCLR Migration Scanner

// Nullable is enabled per file, not per project - see Model/MigrationModel.cs for why.
#nullable enable

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using UnityEngine;

namespace CSAF.CoreCLRScanner
{
    /// <summary>
    /// Writes a <see cref="ScanReport"/> to disk in the formats a migration actually needs.
    /// </summary>
    /// <remarks>
    /// Three formats, three different readers. JSON is for the next build to diff against - that
    /// diff is the burndown. Markdown is for the producer who has to show progress upward and will
    /// not open a JSON file. The console summary is for the CI log, where a failure has about two
    /// lines of attention before someone scrolls past it.
    /// </remarks>
    public static class ReportExporter
    {
        /// <summary>Writes the report as indented JSON.</summary>
        /// <param name="report">Report to write.</param>
        /// <param name="absolutePath">Destination file. Parent directories are created.</param>
        public static void WriteJson(ScanReport report, string absolutePath)
        {
            if (report == null || string.IsNullOrEmpty(absolutePath))
            {
                return;
            }

            EnsureDirectory(absolutePath);
            File.WriteAllText(absolutePath, JsonUtility.ToJson(report, true), Encoding.UTF8);
        }

        /// <summary>
        /// Reads a previously written JSON report, for burndown comparison.
        /// </summary>
        /// <param name="absolutePath">File to read.</param>
        /// <returns>The report, or null when the file is absent or unreadable.</returns>
        public static ScanReport? ReadJson(string absolutePath)
        {
            if (string.IsNullOrEmpty(absolutePath) || !File.Exists(absolutePath))
            {
                return null;
            }

            try
            {
                return JsonUtility.FromJson<ScanReport>(File.ReadAllText(absolutePath));
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>Writes a human-readable Markdown summary, optionally with a burndown delta.</summary>
        /// <param name="report">The current report.</param>
        /// <param name="baseline">An earlier report to compare against, or null.</param>
        /// <param name="absolutePath">Destination file.</param>
        public static void WriteMarkdown(ScanReport report, ScanReport? baseline, string absolutePath)
        {
            if (report == null || string.IsNullOrEmpty(absolutePath))
            {
                return;
            }

            EnsureDirectory(absolutePath);
            File.WriteAllText(absolutePath, BuildMarkdown(report, baseline), Encoding.UTF8);
        }

        /// <summary>Builds the Markdown body.</summary>
        /// <param name="report">The current report.</param>
        /// <param name="baseline">An earlier report to compare against, or null.</param>
        /// <returns>Markdown text.</returns>
        public static string BuildMarkdown(ScanReport report, ScanReport? baseline)
        {
            var sb = new StringBuilder();

            sb.AppendLine("# CoreCLR Migration Report");
            sb.AppendLine();
            sb.AppendLine("Scanned " + report.scannedAtUtc + " on Unity " + report.unityVersion +
                          " using rule corpus " + report.corpusVersion + ".");
            sb.AppendLine();
            sb.AppendLine("| Severity | Count | Change |");
            sb.AppendLine("| --- | ---: | ---: |");
            AppendSeverityRow(sb, "Breaking", report.BreakingCount, baseline == null ? (int?)null : baseline.BreakingCount);
            AppendSeverityRow(sb, "Behavioural", report.BehaviouralCount, baseline == null ? (int?)null : baseline.BehaviouralCount);
            AppendSeverityRow(sb, "Info", report.InfoCount, baseline == null ? (int?)null : baseline.InfoCount);
            sb.AppendLine();
            sb.AppendLine("Scanned " + report.filesScanned.ToString(CultureInfo.InvariantCulture) +
                          " source files and " + report.assembliesScanned.ToString(CultureInfo.InvariantCulture) +
                          " compiled assemblies.");

            if (report.cancelled)
            {
                sb.AppendLine();
                sb.AppendLine("> **This scan was cancelled before it finished.** The counts above are a " +
                              "lower bound, not a result. Re-run before acting on them.");
            }

            sb.AppendLine();
            AppendGrouped(sb, report);

            return sb.ToString();
        }

        /// <summary>Builds the terse multi-line summary written to the CI log.</summary>
        /// <param name="report">Report to summarise.</param>
        /// <returns>Console text.</returns>
        public static string BuildConsoleSummary(ScanReport report)
        {
            if (report == null)
            {
                return "CoreCLR Migration Scanner: no report.";
            }

            var sb = new StringBuilder();
            sb.Append("CoreCLR Migration Scanner: ");
            sb.Append(report.BreakingCount.ToString(CultureInfo.InvariantCulture)).Append(" breaking, ");
            sb.Append(report.BehaviouralCount.ToString(CultureInfo.InvariantCulture)).Append(" behavioural, ");
            sb.Append(report.InfoCount.ToString(CultureInfo.InvariantCulture)).Append(" info");
            sb.Append(" across ").Append(report.filesScanned.ToString(CultureInfo.InvariantCulture)).Append(" files");
            sb.Append(" and ").Append(report.assembliesScanned.ToString(CultureInfo.InvariantCulture)).Append(" assemblies.");

            // Counting the work, not just the verdict. A scan that reads zero files and reports zero
            // problems is a failure wearing a pass, and a CI log is exactly where that goes unnoticed.
            if (report.filesScanned == 0 && report.assembliesScanned == 0)
            {
                sb.AppendLine();
                sb.Append("WARNING: nothing was scanned. A clean result here means the scan did not run, ");
                sb.Append("not that the project is clean. Check the scan path and the rule corpus.");
            }

            return sb.ToString();
        }

        private static void AppendSeverityRow(StringBuilder sb, string label, int count, int? baselineCount)
        {
            sb.Append("| ").Append(label).Append(" | ").Append(count.ToString(CultureInfo.InvariantCulture)).Append(" | ");

            if (baselineCount.HasValue)
            {
                int delta = count - baselineCount.Value;
                if (delta > 0)
                {
                    sb.Append('+').Append(delta.ToString(CultureInfo.InvariantCulture));
                }
                else if (delta < 0)
                {
                    sb.Append(delta.ToString(CultureInfo.InvariantCulture));
                }
                else
                {
                    sb.Append('0');
                }
            }
            else
            {
                sb.Append('-');
            }

            sb.AppendLine(" |");
        }

        private static void AppendGrouped(StringBuilder sb, ScanReport report)
        {
            var byCategory = new Dictionary<string, List<MigrationFinding>>(StringComparer.Ordinal);

            for (int i = 0; i < report.findings.Count; i++)
            {
                MigrationFinding finding = report.findings[i];
                string category = string.IsNullOrEmpty(finding.category) ? "Uncategorised" : finding.category;

                List<MigrationFinding> bucket;
                if (!byCategory.TryGetValue(category, out bucket))
                {
                    bucket = new List<MigrationFinding>();
                    byCategory[category] = bucket;
                }

                bucket.Add(finding);
            }

            foreach (KeyValuePair<string, List<MigrationFinding>> pair in byCategory)
            {
                sb.AppendLine("## " + pair.Key + " (" + pair.Value.Count.ToString(CultureInfo.InvariantCulture) + ")");
                sb.AppendLine();

                for (int i = 0; i < pair.Value.Count; i++)
                {
                    MigrationFinding f = pair.Value[i];
                    sb.Append("- **").Append(f.ruleId).Append("** ").Append(f.title).Append(" - `").Append(f.path).Append('`');

                    if (f.line > 0)
                    {
                        sb.Append(':').Append(f.line.ToString(CultureInfo.InvariantCulture));
                    }

                    if (!string.IsNullOrEmpty(f.context))
                    {
                        sb.Append(" - ").Append(f.context);
                    }

                    sb.AppendLine();
                }

                sb.AppendLine();
            }
        }

        private static void EnsureDirectory(string absolutePath)
        {
            string directory = Path.GetDirectoryName(absolutePath);
            if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }
        }
    }
}
