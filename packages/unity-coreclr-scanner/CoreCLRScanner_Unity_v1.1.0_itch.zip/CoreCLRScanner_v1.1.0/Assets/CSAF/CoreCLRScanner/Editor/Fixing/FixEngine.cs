// Copyright (c) 2026 CSAF (Corey Gallant and Stephanie Thomason). All rights reserved.
// CSAF CoreCLR Migration Scanner
//
// The fix pass. Scanning tells a team what Mono removal breaks; this file is the half that ACTS
// on it. Three of the corpus's P/Invoke rules have a remediation that is mechanical - the edit is
// unambiguous, behaviour-preserving, and checkable - and those are applied here, preview-first.
// Everything else is deliberately NOT auto-fixed: a fix that requires judgement (which calling
// convention, which string encoding crosses this boundary) is presented as an assisted step with
// the rule's own remedy text, never guessed at. An auto-fixer that guesses is worse than a
// scanner, because it converts a visible hazard into an invisible one.

// Nullable is enabled per file, not per project - see Model/MigrationModel.cs for why.
#nullable enable

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace CSAF.CoreCLRScanner
{
    /// <summary>How one <see cref="FixEdit"/> changes the file.</summary>
    public enum FixEditKind
    {
        /// <summary>Replace the line named by <see cref="FixEdit.line"/> with <see cref="FixEdit.after"/>.</summary>
        ReplaceLine = 0,

        /// <summary>Insert <see cref="FixEdit.after"/> as a new line above <see cref="FixEdit.line"/>.</summary>
        InsertAbove = 1
    }

    /// <summary>One concrete, previewable edit to one line of one file.</summary>
    [Serializable]
    public sealed class FixEdit
    {
        /// <summary>Rule id(s) this edit remediates, comma-joined when one line carried several.</summary>
        public string ruleId = string.Empty;

        /// <summary>Project-relative path, as reported by the scanner.</summary>
        public string path = string.Empty;

        /// <summary>1-based line number the edit anchors to.</summary>
        public int line;

        /// <summary>What kind of edit this is. Serialized as an int by JsonUtility.</summary>
        public FixEditKind kind;

        /// <summary>
        /// The exact current content of the anchor line. Re-checked at apply time: if the file
        /// changed since the plan was built, the edit is refused rather than applied blind.
        /// </summary>
        public string before = string.Empty;

        /// <summary>The replacement line (<see cref="FixEditKind.ReplaceLine"/>) or the inserted line.</summary>
        public string after = string.Empty;

        /// <summary>Why this edit is safe, shown in the preview beside the diff.</summary>
        public string note = string.Empty;
    }

    /// <summary>A finding the engine deliberately did not auto-fix, and the reason.</summary>
    [Serializable]
    public sealed class FixSkip
    {
        /// <summary>Rule id of the finding.</summary>
        public string ruleId = string.Empty;

        /// <summary>Project-relative path.</summary>
        public string path = string.Empty;

        /// <summary>1-based line, zero for assembly findings.</summary>
        public int line;

        /// <summary>Why the engine refused, phrased as the next manual step.</summary>
        public string reason = string.Empty;
    }

    /// <summary>Everything the fix pass intends to do, built for preview before a byte is written.</summary>
    [Serializable]
    public sealed class FixPlan
    {
        /// <summary>Round-trip ISO-8601 timestamp of plan construction.</summary>
        public string builtAtUtc = string.Empty;

        /// <summary>Corpus version the findings came from.</summary>
        public string corpusVersion = string.Empty;

        /// <summary>Edits the engine will apply, in file order.</summary>
        public List<FixEdit> edits = new List<FixEdit>();

        /// <summary>Findings that need a human, each with its reason and remedy.</summary>
        public List<FixSkip> skips = new List<FixSkip>();
    }

    /// <summary>What actually happened when a plan was applied.</summary>
    [Serializable]
    public sealed class FixResult
    {
        /// <summary>Edits written to disk.</summary>
        public int applied;

        /// <summary>Edits refused because the file changed between plan and apply.</summary>
        public int stale;

        /// <summary>Files that received at least one edit.</summary>
        public int filesTouched;

        /// <summary>Files that could not be written, with the exception message.</summary>
        public List<string> failures = new List<string>();
    }

    /// <summary>
    /// Builds and applies mechanical fixes for the rules whose remediation needs no judgement.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Covered: <c>CSAF5003</c> (LPStr to LPUTF8Str - preserves Mono's actual UTF-8 marshalling,
    /// which CoreCLR would otherwise replace with the system code page), <c>CSAF5004</c> (missing
    /// <c>[UnmanagedFunctionPointer]</c> on a native callback delegate - inserted as Cdecl, the
    /// near-universal convention for Unity native plugins, and named in the note for review), and
    /// <c>CSAF5001</c> (DllImport without an explicit CharSet - made explicit ONLY when no string
    /// crosses the boundary, because then the edit records the decision and cannot change behaviour;
    /// when a string does cross, the choice of encoding is real work and is refused with the remedy).
    /// </para>
    /// <para>
    /// Every edit carries the exact line it expects to replace, and apply refuses any edit whose
    /// line has changed since the plan was built. The engine never writes without a plan the user
    /// has been able to read.
    /// </para>
    /// </remarks>
    public static class FixEngine
    {
        /// <summary>Rule ids the engine can act on. Public so the UI can say "N of M are mechanical".</summary>
        public static readonly string[] FixableRuleIds = { "CSAF5001", "CSAF5003", "CSAF5004" };

        private static readonly Regex DllImportAttr =
            new Regex(@"\[\s*DllImport\s*\((?![^)]*CharSet)[^)]*\)\s*\]", RegexOptions.CultureInvariant);

        private static readonly Regex LpStrToken =
            new Regex(@"\bUnmanagedType\.LPStr\b", RegexOptions.CultureInvariant);

        private static readonly Regex LpTStrToken =
            new Regex(@"\bUnmanagedType\.LPTStr\b", RegexOptions.CultureInvariant);

        private static readonly Regex StringishParam =
            new Regex(@"\b(string|String|StringBuilder)\b", RegexOptions.CultureInvariant);

        private static readonly Regex UsingInterop =
            new Regex(@"^\s*using\s+System\.Runtime\.InteropServices\s*;", RegexOptions.CultureInvariant);

        private static readonly Regex AnyUsing =
            new Regex(@"^\s*using\s+[A-Za-z_][\w.]*\s*;", RegexOptions.CultureInvariant);

        /// <summary>True when a finding's rule has a mechanical fixer at all.</summary>
        /// <param name="ruleId">The rule id to test.</param>
        /// <returns>Whether <see cref="BuildPlan"/> will consider findings of this rule.</returns>
        public static bool IsFixableRule(string ruleId)
        {
            for (int i = 0; i < FixableRuleIds.Length; i++)
            {
                if (string.Equals(FixableRuleIds[i], ruleId, StringComparison.Ordinal))
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Reads every file named by the report's fixable source findings and builds the edit plan.
        /// </summary>
        /// <param name="report">A scan report. Assembly findings are ignored - there is no source to edit.</param>
        /// <param name="projectRoot">Absolute project root that <c>Assets/</c> paths resolve against.</param>
        /// <returns>The plan. Never null; an empty plan means nothing mechanical was found.</returns>
        public static FixPlan BuildPlan(ScanReport report, string projectRoot)
        {
            var plan = new FixPlan
            {
                builtAtUtc = DateTime.UtcNow.ToString("o"),
                corpusVersion = report != null ? report.corpusVersion : string.Empty
            };

            if (report == null || report.findings == null)
            {
                return plan;
            }

            // Findings grouped by file so each file is read exactly once.
            var byFile = new Dictionary<string, List<MigrationFinding>>(StringComparer.Ordinal);
            for (int i = 0; i < report.findings.Count; i++)
            {
                MigrationFinding f = report.findings[i];
                if (f.origin != FindingOrigin.Source || f.line <= 0 || !IsFixableRule(f.ruleId))
                {
                    continue;
                }

                List<MigrationFinding>? list;
                if (!byFile.TryGetValue(f.path, out list))
                {
                    list = new List<MigrationFinding>();
                    byFile[f.path] = list;
                }

                list.Add(f);
            }

            foreach (KeyValuePair<string, List<MigrationFinding>> entry in byFile)
            {
                string absolute = ResolvePath(entry.Key, projectRoot);
                string[]? lines = TryReadLines(absolute);
                if (lines == null)
                {
                    for (int i = 0; i < entry.Value.Count; i++)
                    {
                        plan.skips.Add(Skip(entry.Value[i], "File could not be read - it may have moved since the scan. Re-scan and rebuild the plan."));
                    }

                    continue;
                }

                PlanFile(entry.Key, lines, entry.Value, plan);
            }

            // Deterministic order for the preview: by path, then by line.
            plan.edits.Sort(CompareEdits);
            plan.skips.Sort(CompareSkips);
            return plan;
        }

        /// <summary>
        /// Applies a plan, one file at a time, refusing any edit whose anchor line changed.
        /// </summary>
        /// <param name="plan">The plan to apply.</param>
        /// <param name="projectRoot">Absolute project root that <c>Assets/</c> paths resolve against.</param>
        /// <returns>Counts of what was actually done - read them, do not assume.</returns>
        /// <remarks>
        /// Line endings, a trailing final newline and a UTF-8 BOM are all preserved as found, so an
        /// applied fix diffs as exactly the changed lines and nothing else. A fixer that reformats
        /// the buyer's file has destroyed their diff and their trust in the same second.
        /// </remarks>
        public static FixResult Apply(FixPlan plan, string projectRoot)
        {
            var result = new FixResult();
            if (plan == null || plan.edits == null || plan.edits.Count == 0)
            {
                return result;
            }

            var byFile = new Dictionary<string, List<FixEdit>>(StringComparer.Ordinal);
            for (int i = 0; i < plan.edits.Count; i++)
            {
                FixEdit edit = plan.edits[i];
                List<FixEdit>? list;
                if (!byFile.TryGetValue(edit.path, out list))
                {
                    list = new List<FixEdit>();
                    byFile[edit.path] = list;
                }

                list.Add(edit);
            }

            foreach (KeyValuePair<string, List<FixEdit>> entry in byFile)
            {
                string absolute = ResolvePath(entry.Key, projectRoot);
                ApplyToFile(absolute, entry.Value, result);
            }

            return result;
        }

        // ---------------------------------------------------------------- planning, per file

        private static void PlanFile(string relativePath, string[] lines, List<MigrationFinding> findings, FixPlan plan)
        {
            // Edits that rewrite a line are composed per line, so two rules matching one line
            // produce ONE ReplaceLine whose after-text carries both fixes - a second edit whose
            // before-guard no longer matches would otherwise be refused as stale at apply time.
            var lineRewrites = new Dictionary<int, FixEdit>();
            bool needsInteropUsing = false;
            var insertions = new List<FixEdit>();

            for (int i = 0; i < findings.Count; i++)
            {
                MigrationFinding f = findings[i];
                if (f.line > lines.Length)
                {
                    plan.skips.Add(Skip(f, "File is shorter than the finding's line - it changed since the scan. Re-scan and rebuild the plan."));
                    continue;
                }

                string current;
                FixEdit? existing;
                if (lineRewrites.TryGetValue(f.line, out existing))
                {
                    current = existing.after;
                }
                else
                {
                    current = lines[f.line - 1];
                }

                switch (f.ruleId)
                {
                    case "CSAF5003":
                        PlanLpStr(f, current, lines, lineRewrites, plan);
                        break;

                    case "CSAF5004":
                        if (PlanCallbackAttribute(f, lines, insertions, plan) && !HasInteropUsing(lines))
                        {
                            needsInteropUsing = true;
                        }

                        break;

                    case "CSAF5001":
                        PlanCharSet(f, current, lines, lineRewrites, plan);
                        break;
                }
            }

            if (needsInteropUsing)
            {
                FixEdit? usingEdit = BuildUsingInsertion(relativePath, lines);
                if (usingEdit != null)
                {
                    insertions.Add(usingEdit);
                }
            }

            foreach (KeyValuePair<int, FixEdit> rewrite in lineRewrites)
            {
                plan.edits.Add(rewrite.Value);
            }

            plan.edits.AddRange(insertions);
        }

        private static void PlanLpStr(
            MigrationFinding f, string current, string[] lines, Dictionary<int, FixEdit> rewrites, FixPlan plan)
        {
            bool hadLpStr = LpStrToken.IsMatch(current);
            bool hadLpTStr = LpTStrToken.IsMatch(current);

            if (hadLpTStr)
            {
                plan.skips.Add(Skip(f,
                    "UnmanagedType.LPTStr is platform-dependent and the right replacement is a decision: "
                    + "LPWStr for UTF-16 APIs, LPUTF8Str for UTF-8. Choose against the native header."));
            }

            if (!hadLpStr)
            {
                return;
            }

            string after = LpStrToken.Replace(current, "UnmanagedType.LPUTF8Str");
            UpsertRewrite(rewrites, f, lines, after,
                "Mono marshals LPStr as UTF-8; CoreCLR marshals it as the system code page. LPUTF8Str "
                + "pins the behaviour your code already has, so nothing changes when the runtime does.");
        }

        private static bool PlanCallbackAttribute(
            MigrationFinding f, string[] lines, List<FixEdit> insertions, FixPlan plan)
        {
            // Walk upward over blank lines and other attributes; if UnmanagedFunctionPointer is
            // already among them the scanner over-matched and the honest move is to do nothing.
            for (int i = f.line - 2; i >= 0; i--)
            {
                string trimmed = lines[i].TrimStart();
                if (trimmed.Length == 0 || trimmed.StartsWith("[", StringComparison.Ordinal))
                {
                    if (trimmed.IndexOf("UnmanagedFunctionPointer", StringComparison.Ordinal) >= 0)
                    {
                        plan.skips.Add(Skip(f, "Already annotated with [UnmanagedFunctionPointer] on a preceding line - nothing to do."));
                        return false;
                    }

                    continue;
                }

                break;
            }

            string declLine = lines[f.line - 1];
            string indent = declLine.Substring(0, declLine.Length - declLine.TrimStart().Length);

            insertions.Add(new FixEdit
            {
                ruleId = f.ruleId,
                path = f.path,
                line = f.line,
                kind = FixEditKind.InsertAbove,
                before = declLine,
                after = indent + "[UnmanagedFunctionPointer(CallingConvention.Cdecl)]",
                note = "Cdecl is the near-universal convention for Unity native plugins. Verify it against "
                     + "the native header - if the library declares stdcall, change the argument, not the attribute."
            });

            return true;
        }

        private static void PlanCharSet(
            MigrationFinding f, string current, string[] lines, Dictionary<int, FixEdit> rewrites, FixPlan plan)
        {
            Match attr = DllImportAttr.Match(current);
            if (!attr.Success)
            {
                plan.skips.Add(Skip(f, "The DllImport attribute is not on a single line the engine can edit safely. Add CharSet by hand."));
                return;
            }

            string? declaration = FindExternDeclaration(lines, f.line);
            if (declaration == null)
            {
                plan.skips.Add(Skip(f, "Could not locate the extern declaration under the attribute. Add CharSet by hand."));
                return;
            }

            if (StringishParam.IsMatch(declaration))
            {
                plan.skips.Add(Skip(f,
                    "A string crosses this native boundary, so the encoding is a real decision: per-parameter "
                    + "[MarshalAs(UnmanagedType.LPUTF8Str)] preserves Mono's UTF-8 behaviour, or CharSet.Unicode "
                    + "with the W entry point where the native API offers one. Too consequential to auto-apply."));
                return;
            }

            int closeParen = attr.Index + attr.Value.LastIndexOf(')');
            string after = current.Substring(0, closeParen) + ", CharSet = CharSet.Ansi" + current.Substring(closeParen);
            UpsertRewrite(rewrites, f, lines, after,
                "No string crosses this boundary, so CharSet cannot change behaviour here - making it "
                + "explicit records the decision and retires the finding.");
        }

        private static FixEdit? BuildUsingInsertion(string relativePath, string[] lines)
        {
            int lastUsing = -1;
            for (int i = 0; i < lines.Length; i++)
            {
                string trimmed = lines[i].TrimStart();
                if (trimmed.StartsWith("namespace ", StringComparison.Ordinal))
                {
                    break;
                }

                if (AnyUsing.IsMatch(lines[i]))
                {
                    lastUsing = i;
                }
            }

            if (lastUsing < 0 || lastUsing + 1 >= lines.Length)
            {
                // No using block to extend. The attribute insertion still compiles if the file
                // qualifies names fully; otherwise the compiler names the missing using precisely.
                return null;
            }

            return new FixEdit
            {
                ruleId = "CSAF5004",
                path = relativePath,
                line = lastUsing + 2, // 1-based: insert above the line after the last using
                kind = FixEditKind.InsertAbove,
                before = lines[lastUsing + 1],
                after = "using System.Runtime.InteropServices;",
                note = "UnmanagedFunctionPointer and CallingConvention live in System.Runtime.InteropServices."
            };
        }

        // ---------------------------------------------------------------- application

        private static void ApplyToFile(string absolutePath, List<FixEdit> edits, FixResult result)
        {
            byte[] raw;
            try
            {
                raw = File.ReadAllBytes(absolutePath);
            }
            catch (Exception ex)
            {
                result.failures.Add(absolutePath + " - " + ex.Message);
                return;
            }

            bool hasBom = raw.Length >= 3 && raw[0] == 0xEF && raw[1] == 0xBB && raw[2] == 0xBF;
            string text = new UTF8Encoding(false).GetString(raw, hasBom ? 3 : 0, raw.Length - (hasBom ? 3 : 0));
            bool crlf = text.IndexOf("\r\n", StringComparison.Ordinal) >= 0;
            bool trailingNewline = text.EndsWith("\n", StringComparison.Ordinal);

            var lines = new List<string>(text.Replace("\r\n", "\n").Split('\n'));
            if (trailingNewline && lines.Count > 0 && lines[lines.Count - 1].Length == 0)
            {
                lines.RemoveAt(lines.Count - 1);
            }

            // Descending by line so earlier indices stay valid as edits land.
            edits.Sort((a, b) => b.line.CompareTo(a.line));

            bool touched = false;
            for (int i = 0; i < edits.Count; i++)
            {
                FixEdit edit = edits[i];
                int index = edit.line - 1;
                if (index < 0 || index >= lines.Count || !string.Equals(lines[index], edit.before, StringComparison.Ordinal))
                {
                    result.stale++;
                    continue;
                }

                if (edit.kind == FixEditKind.ReplaceLine)
                {
                    lines[index] = edit.after;
                }
                else
                {
                    lines.Insert(index, edit.after);
                }

                result.applied++;
                touched = true;
            }

            if (!touched)
            {
                return;
            }

            string eol = crlf ? "\r\n" : "\n";
            string rebuilt = string.Join(eol, lines.ToArray()) + (trailingNewline ? eol : string.Empty);

            try
            {
                File.WriteAllText(absolutePath, rebuilt, new UTF8Encoding(hasBom));
                result.filesTouched++;
            }
            catch (Exception ex)
            {
                result.failures.Add(absolutePath + " - " + ex.Message);
            }
        }

        // ---------------------------------------------------------------- helpers

        private static void UpsertRewrite(
            Dictionary<int, FixEdit> rewrites, MigrationFinding f, string[] lines, string after, string note)
        {
            FixEdit? existing;
            if (rewrites.TryGetValue(f.line, out existing))
            {
                existing.after = after;
                existing.ruleId = existing.ruleId + "," + f.ruleId;
                existing.note = existing.note + " Also: " + note;
                return;
            }

            rewrites[f.line] = new FixEdit
            {
                ruleId = f.ruleId,
                path = f.path,
                line = f.line,
                kind = FixEditKind.ReplaceLine,
                before = lines[f.line - 1],
                after = after,
                note = note
            };
        }

        private static string? FindExternDeclaration(string[] lines, int attributeLine)
        {
            // The extern declaration follows the attribute, possibly after further attributes.
            // Collect up to 8 lines until one closes with ';'.
            var sb = new StringBuilder();
            for (int i = attributeLine; i < lines.Length && i < attributeLine + 8; i++)
            {
                string trimmed = lines[i].Trim();
                if (trimmed.StartsWith("[", StringComparison.Ordinal))
                {
                    continue;
                }

                sb.Append(' ').Append(trimmed);
                if (trimmed.EndsWith(";", StringComparison.Ordinal))
                {
                    return sb.ToString();
                }
            }

            return null;
        }

        private static bool HasInteropUsing(string[] lines)
        {
            for (int i = 0; i < lines.Length; i++)
            {
                if (UsingInterop.IsMatch(lines[i]))
                {
                    return true;
                }
            }

            return false;
        }

        private static string ResolvePath(string reportedPath, string projectRoot)
        {
            if (Path.IsPathRooted(reportedPath))
            {
                return reportedPath;
            }

            return Path.Combine(projectRoot, reportedPath.Replace('/', Path.DirectorySeparatorChar));
        }

        private static string[]? TryReadLines(string absolutePath)
        {
            try
            {
                return File.ReadAllLines(absolutePath);
            }
            catch (Exception)
            {
                return null;
            }
        }

        private static FixSkip Skip(MigrationFinding f, string reason)
        {
            return new FixSkip { ruleId = f.ruleId, path = f.path, line = f.line, reason = reason };
        }

        private static int CompareEdits(FixEdit a, FixEdit b)
        {
            int byPath = string.CompareOrdinal(a.path, b.path);
            return byPath != 0 ? byPath : a.line.CompareTo(b.line);
        }

        private static int CompareSkips(FixSkip a, FixSkip b)
        {
            int byPath = string.CompareOrdinal(a.path, b.path);
            return byPath != 0 ? byPath : a.line.CompareTo(b.line);
        }
    }
}
