// Copyright (c) 2026 CSAF (Corey Gallant and Stephanie Thomason). All rights reserved.
// CSAF CoreCLR Migration Scanner
//
// The burndown. A scan is a snapshot; a migration is a trend. This file turns two snapshots into
// the three numbers a producer actually reports upward - fixed, open, new - and gives CI the one
// gate a team can adopt on day one: fail on NEW findings only, so four hundred legacy findings do
// not have to be fixed before the ratchet starts protecting the codebase.

// Nullable is enabled per file, not per project - see Model/MigrationModel.cs for why.
#nullable enable

using System;
using System.Collections.Generic;
using System.Text;

namespace CSAF.CoreCLRScanner
{
    /// <summary>The classified difference between a current scan and a baseline.</summary>
    [Serializable]
    public sealed class BurndownDelta
    {
        /// <summary>Findings present now that have no counterpart in the baseline. The ratchet fails on these.</summary>
        public List<MigrationFinding> newFindings = new List<MigrationFinding>();

        /// <summary>Baseline findings no longer present - the work actually done.</summary>
        public List<MigrationFinding> fixedFindings = new List<MigrationFinding>();

        /// <summary>Findings present in both - the remaining debt.</summary>
        public List<MigrationFinding> openFindings = new List<MigrationFinding>();
    }

    /// <summary>Computes finding identity and scan-over-scan deltas.</summary>
    /// <remarks>
    /// Identity deliberately excludes the line number: editing an unrelated part of a file moves
    /// every finding below the edit, and a burndown that counted each moved finding as one fixed
    /// plus one new would be noise wearing a trend. Identity is rule + file + the offending text
    /// itself (whitespace-collapsed), plus the assembly context for reflection findings.
    /// </remarks>
    public static class Burndown
    {
        /// <summary>Stable identity of one finding, line-drift-proof.</summary>
        /// <param name="f">The finding.</param>
        /// <returns>An opaque key string; equal keys mean the same problem.</returns>
        public static string KeyOf(MigrationFinding f)
        {
            if (f == null)
            {
                return string.Empty;
            }

            return f.ruleId + "|" + f.path + "|" + Normalize(f.snippet) + "|" + Normalize(f.context);
        }

        /// <summary>
        /// Classifies every current finding against the baseline.
        /// </summary>
        /// <param name="current">The scan just run.</param>
        /// <param name="baseline">The committed reference scan.</param>
        /// <returns>The delta. With a null baseline every current finding is open, none new -
        /// a missing baseline must not make a first adoption look like a regression.</returns>
        /// <remarks>
        /// Keys are counted, not set-tested: two identical offending lines in one file are two
        /// findings, and fixing one of them is progress the delta must show.
        /// </remarks>
        public static BurndownDelta Delta(ScanReport current, ScanReport? baseline)
        {
            var delta = new BurndownDelta();
            if (current == null || current.findings == null)
            {
                return delta;
            }

            if (baseline == null || baseline.findings == null)
            {
                delta.openFindings.AddRange(current.findings);
                return delta;
            }

            // Multiset of baseline keys, each key holding the queue of its finding objects so a
            // fixed finding is reported with its original text rather than as a bare key.
            var remaining = new Dictionary<string, Queue<MigrationFinding>>(StringComparer.Ordinal);
            for (int i = 0; i < baseline.findings.Count; i++)
            {
                MigrationFinding b = baseline.findings[i];
                string key = KeyOf(b);
                Queue<MigrationFinding>? queue;
                if (!remaining.TryGetValue(key, out queue))
                {
                    queue = new Queue<MigrationFinding>();
                    remaining[key] = queue;
                }

                queue.Enqueue(b);
            }

            for (int i = 0; i < current.findings.Count; i++)
            {
                MigrationFinding c = current.findings[i];
                Queue<MigrationFinding>? queue;
                if (remaining.TryGetValue(KeyOf(c), out queue) && queue.Count > 0)
                {
                    queue.Dequeue();
                    delta.openFindings.Add(c);
                }
                else
                {
                    delta.newFindings.Add(c);
                }
            }

            foreach (KeyValuePair<string, Queue<MigrationFinding>> entry in remaining)
            {
                while (entry.Value.Count > 0)
                {
                    delta.fixedFindings.Add(entry.Value.Dequeue());
                }
            }

            return delta;
        }

        /// <summary>One-line summary for logs and the window header.</summary>
        /// <param name="delta">A computed delta.</param>
        /// <returns>e.g. <c>burndown: 12 fixed, 30 open, 2 NEW</c>.</returns>
        public static string Summarize(BurndownDelta delta)
        {
            if (delta == null)
            {
                return "burndown: (no delta)";
            }

            var sb = new StringBuilder("burndown: ");
            sb.Append(delta.fixedFindings.Count).Append(" fixed, ");
            sb.Append(delta.openFindings.Count).Append(" open, ");
            sb.Append(delta.newFindings.Count).Append(delta.newFindings.Count > 0 ? " NEW" : " new");
            return sb.ToString();
        }

        private static string Normalize(string value)
        {
            if (value == null || value.Length == 0)
            {
                return string.Empty;
            }

            var sb = new StringBuilder(value.Length);
            bool pendingSpace = false;
            for (int i = 0; i < value.Length; i++)
            {
                char c = value[i];
                if (char.IsWhiteSpace(c))
                {
                    pendingSpace = sb.Length > 0;
                    continue;
                }

                if (pendingSpace)
                {
                    sb.Append(' ');
                    pendingSpace = false;
                }

                sb.Append(c);
            }

            return sb.ToString();
        }
    }
}
