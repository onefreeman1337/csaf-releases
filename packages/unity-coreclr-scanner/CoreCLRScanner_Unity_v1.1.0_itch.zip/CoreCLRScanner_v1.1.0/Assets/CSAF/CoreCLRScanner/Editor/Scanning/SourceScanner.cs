// Copyright (c) 2026 CSAF (Corey Gallant and Stephanie Thomason). All rights reserved.
// CSAF CoreCLR Migration Scanner

// Nullable is enabled per file, not per project - see Model/MigrationModel.cs for why.
#nullable enable

using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace CSAF.CoreCLRScanner
{
    /// <summary>
    /// Scans C# source files for constructs the CoreCLR runtime change breaks.
    /// </summary>
    /// <remarks>
    /// Source scanning answers "what does my own code do". It is line-oriented on purpose: a buyer
    /// needs a file and a line number they can click, and a whole-file match tells them nothing
    /// actionable. Its blind spot is precompiled third-party code, which is what
    /// <see cref="AssemblyScanner"/> exists to cover.
    /// </remarks>
    public static class SourceScanner
    {
        /// <summary>Delegate for progress reporting. Return false to cancel the scan.</summary>
        /// <param name="fraction">Completion in the range 0..1.</param>
        /// <param name="currentPath">The file being read, for display.</param>
        /// <returns>False to cancel.</returns>
        public delegate bool ProgressCallback(float fraction, string currentPath);

        /// <summary>
        /// Reads every matching file under <paramref name="rootDirectory"/> and appends findings.
        /// </summary>
        /// <param name="rootDirectory">Absolute directory to walk.</param>
        /// <param name="searchExtensions">Extensions to read, e.g. <c>.cs</c>. Case-insensitive.</param>
        /// <param name="excludeSubstrings">
        /// Path fragments that disqualify a file. The scanner's own folder belongs here - without
        /// it the corpus's own pattern strings match themselves and every scan reports the scanner.
        /// </param>
        /// <param name="rules">Rules to apply.</param>
        /// <param name="report">Report to append to. Also receives the file count.</param>
        /// <param name="progress">Optional progress and cancellation hook.</param>
        /// <returns>True if the scan completed, false if it was cancelled.</returns>
        public static bool Scan(
            string rootDirectory,
            IReadOnlyList<string> searchExtensions,
            IReadOnlyList<string> excludeSubstrings,
            IReadOnlyList<CoreClrRule> rules,
            ScanReport report,
            ProgressCallback progress)
        {
            if (report == null)
            {
                throw new ArgumentNullException(nameof(report));
            }

            if (string.IsNullOrEmpty(rootDirectory) || !Directory.Exists(rootDirectory))
            {
                return true;
            }

            List<string> files = CollectFiles(rootDirectory, searchExtensions, excludeSubstrings);

            for (int i = 0; i < files.Count; i++)
            {
                string file = files[i];

                if (progress != null && !progress((float)i / Math.Max(1, files.Count), file))
                {
                    return false;
                }

                string[] lines;
                try
                {
                    lines = File.ReadAllLines(file);
                }
                catch (IOException)
                {
                    // A file locked by another process is skipped rather than aborting the scan.
                    // It is counted as unscanned so the totals stay honest.
                    continue;
                }

                report.filesScanned++;
                ScanLines(file, lines, rules, report);
            }

            return true;
        }

        /// <summary>
        /// Applies every rule to every line of one already-read file.
        /// </summary>
        /// <param name="path">Path recorded on findings.</param>
        /// <param name="lines">The file's lines.</param>
        /// <param name="rules">Rules to apply.</param>
        /// <param name="report">Report to append to.</param>
        public static void ScanLines(
            string path,
            IReadOnlyList<string> lines,
            IReadOnlyList<CoreClrRule> rules,
            ScanReport report)
        {
            if (lines == null || rules == null || report == null)
            {
                return;
            }

            string relative = ToProjectRelative(path);

            for (int lineIndex = 0; lineIndex < lines.Count; lineIndex++)
            {
                string line = lines[lineIndex];
                if (string.IsNullOrEmpty(line))
                {
                    continue;
                }

                // A line that is purely a comment is skipped. Commented-out code is not a runtime
                // hazard, and reporting it trains the buyer to ignore the report - which is the
                // single fastest way to make a static analysis product worthless.
                if (IsCommentOnly(line))
                {
                    continue;
                }

                for (int r = 0; r < rules.Count; r++)
                {
                    CoreClrRule rule = rules[r];
                    if (rule == null || rule.patterns == null)
                    {
                        continue;
                    }

                    if (MatchesAny(rule.patterns, line))
                    {
                        report.findings.Add(new MigrationFinding
                        {
                            ruleId = rule.id,
                            category = rule.category,
                            severity = rule.ParsedSeverity,
                            title = rule.title,
                            path = relative,
                            line = lineIndex + 1,
                            snippet = Truncate(line.Trim(), 220),
                            context = string.Empty,
                            origin = FindingOrigin.Source
                        });

                        // One finding per rule per line. A line matching two patterns of the same
                        // rule is still one problem to fix.
                        break;
                    }
                }
            }
        }

        private static bool MatchesAny(string[] patterns, string line)
        {
            for (int p = 0; p < patterns.Length; p++)
            {
                Regex? regex = RuleCorpus.GetRegex(patterns[p]);
                if (regex != null && regex.IsMatch(line))
                {
                    return true;
                }
            }

            return false;
        }

        private static List<string> CollectFiles(
            string rootDirectory,
            IReadOnlyList<string> searchExtensions,
            IReadOnlyList<string> excludeSubstrings)
        {
            var results = new List<string>();
            string[] all;

            try
            {
                all = Directory.GetFiles(rootDirectory, "*", SearchOption.AllDirectories);
            }
            catch (UnauthorizedAccessException)
            {
                return results;
            }

            for (int i = 0; i < all.Length; i++)
            {
                string file = all[i];

                if (!HasWantedExtension(file, searchExtensions))
                {
                    continue;
                }

                if (IsExcluded(file, excludeSubstrings))
                {
                    continue;
                }

                results.Add(file);
            }

            return results;
        }

        private static bool HasWantedExtension(string file, IReadOnlyList<string> searchExtensions)
        {
            if (searchExtensions == null || searchExtensions.Count == 0)
            {
                return file.EndsWith(".cs", StringComparison.OrdinalIgnoreCase);
            }

            for (int e = 0; e < searchExtensions.Count; e++)
            {
                if (file.EndsWith(searchExtensions[e], StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }

        private static bool IsExcluded(string file, IReadOnlyList<string> excludeSubstrings)
        {
            if (excludeSubstrings == null)
            {
                return false;
            }

            string normalised = file.Replace('\\', '/');
            for (int x = 0; x < excludeSubstrings.Count; x++)
            {
                string fragment = excludeSubstrings[x];
                if (!string.IsNullOrEmpty(fragment) &&
                    normalised.IndexOf(fragment, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return true;
                }
            }

            return false;
        }

        private static bool IsCommentOnly(string line)
        {
            string trimmed = line.TrimStart();
            return trimmed.StartsWith("//", StringComparison.Ordinal) ||
                   trimmed.StartsWith("*", StringComparison.Ordinal) ||
                   trimmed.StartsWith("/*", StringComparison.Ordinal);
        }

        private static string Truncate(string value, int max)
        {
            if (string.IsNullOrEmpty(value) || value.Length <= max)
            {
                return value;
            }

            return value.Substring(0, max) + "...";
        }

        /// <summary>
        /// Converts an absolute path to one rooted at <c>Assets/</c> where possible, so a report
        /// generated on a build agent is still readable on a developer's machine.
        /// </summary>
        /// <param name="absolutePath">Path to convert.</param>
        /// <returns>A project-relative path, or the input unchanged when it lies outside the project.</returns>
        public static string ToProjectRelative(string absolutePath)
        {
            if (string.IsNullOrEmpty(absolutePath))
            {
                return string.Empty;
            }

            string normalised = absolutePath.Replace('\\', '/');
            int assetsIndex = normalised.LastIndexOf("/Assets/", StringComparison.OrdinalIgnoreCase);
            if (assetsIndex >= 0)
            {
                return normalised.Substring(assetsIndex + 1);
            }

            return normalised;
        }
    }
}
