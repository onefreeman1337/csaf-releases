// Copyright (c) 2026 CSAF (Corey Gallant and Stephanie Thomason). All rights reserved.
// CSAF CoreCLR Migration Scanner

// Nullable is enabled per file, not per project - see Model/MigrationModel.cs for why.
#nullable enable

using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;

namespace CSAF.CoreCLRScanner
{
    /// <summary>
    /// Loads and owns the rule corpus.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Rules are data, never code. The whole corpus is a JSON document, which means adding a rule,
    /// correcting a regex or softening a severity is a content edit that cannot break the scanner -
    /// and it means a studio can maintain its own house rules alongside the shipped ones without
    /// forking anything.
    /// </para>
    /// <para>
    /// <b>Scope, stated deliberately.</b> This corpus covers five categories: P/Invoke,
    /// serialization, assembly loading, reflection and threading. It does <i>not</i> cover static
    /// state and domain reload, which Unity's own Project Auditor already analyses, and it does not
    /// duplicate the Obsolete API view that Project Auditor 2.0.0 added. Ceding those slices is what
    /// makes the positioning honest: this finds what the first-party tool does not.
    /// </para>
    /// </remarks>
    public static class RuleCorpus
    {
        /// <summary>File name of the shipped corpus, located through the AssetDatabase.</summary>
        public const string DefaultCorpusFileName = "coreclr-rules";

        /// <summary>
        /// EditorPrefs key for a buyer-supplied corpus path. Namespaced to this product so it can
        /// never collide with a key in the buyer's own tooling.
        /// </summary>
        public const string OverridePathPrefKey = "CSAF.CoreCLRScanner.CorpusOverridePath";

        private static CoreClrRule[]? s_cachedRules;
        private static string? s_cachedCorpusVersion;
        private static readonly Dictionary<string, Regex?> s_regexCache = new Dictionary<string, Regex?>(StringComparer.Ordinal);

        /// <summary>Corpus version string from the loaded document, for stamping into reports.</summary>
        public static string CorpusVersion
        {
            get
            {
                EnsureLoaded();
                return s_cachedCorpusVersion ?? "unknown";
            }
        }

        /// <summary>Every loaded rule. Never null; an empty array means the corpus failed to load.</summary>
        /// <returns>The rule array.</returns>
        public static CoreClrRule[] GetRules()
        {
            EnsureLoaded();
            return s_cachedRules ?? Array.Empty<CoreClrRule>();
        }

        /// <summary>
        /// Drops the cached corpus so the next access re-reads it from disk. Call after editing the
        /// JSON, so a rule author sees their change without restarting the Editor.
        /// </summary>
        public static void Invalidate()
        {
            s_cachedRules = null;
            s_cachedCorpusVersion = null;
            s_regexCache.Clear();
        }

        /// <summary>
        /// Returns a compiled, cached regex for a pattern.
        /// </summary>
        /// <param name="pattern">The .NET regular expression source.</param>
        /// <returns>A compiled regex, or null when the pattern does not compile.</returns>
        /// <remarks>
        /// A bad pattern in the corpus must degrade to "this one rule does nothing", never to a
        /// scan that dies halfway and reports a partial result as though it were complete. The
        /// failure is logged once, with the rule's own text, so it is fixable.
        /// </remarks>
        public static Regex? GetRegex(string pattern)
        {
            if (string.IsNullOrEmpty(pattern))
            {
                return null;
            }

            Regex? cached;
            if (s_regexCache.TryGetValue(pattern, out cached))
            {
                return cached;
            }

            Regex? compiled = null;
            try
            {
                compiled = new Regex(pattern, RegexOptions.Compiled | RegexOptions.CultureInvariant);
            }
            catch (ArgumentException ex)
            {
                Debug.LogWarning("[CSAF CoreCLR Scanner] Rule pattern did not compile and was skipped: " +
                                 pattern + " - " + ex.Message);
            }

            s_regexCache[pattern] = compiled;
            return compiled;
        }

        private static void EnsureLoaded()
        {
            if (s_cachedRules != null)
            {
                return;
            }

            string? json = ReadCorpusJson();
            if (string.IsNullOrEmpty(json))
            {
                Debug.LogError("[CSAF CoreCLR Scanner] Could not locate " + DefaultCorpusFileName +
                               ".json. The scanner has no rules and will report nothing. " +
                               "Reimport the package, or set an explicit corpus path in the scanner window.");
                s_cachedRules = Array.Empty<CoreClrRule>();
                s_cachedCorpusVersion = "missing";
                return;
            }

            CoreClrRuleSet? parsed = null;
            try
            {
                parsed = JsonUtility.FromJson<CoreClrRuleSet>(json);
            }
            catch (Exception ex)
            {
                Debug.LogError("[CSAF CoreCLR Scanner] Rule corpus failed to parse: " + ex.Message);
            }

            if (parsed == null || parsed.rules == null)
            {
                s_cachedRules = Array.Empty<CoreClrRule>();
                s_cachedCorpusVersion = "unparsable";
                return;
            }

            s_cachedRules = parsed.rules;
            s_cachedCorpusVersion = string.IsNullOrEmpty(parsed.corpusVersion) ? "unversioned" : parsed.corpusVersion;
        }

        private static string? ReadCorpusJson()
        {
            string overridePath = EditorPrefs.GetString(OverridePathPrefKey, string.Empty);
            if (!string.IsNullOrEmpty(overridePath) && File.Exists(overridePath))
            {
                return File.ReadAllText(overridePath);
            }

            // Located by name rather than by a hardcoded path, so the buyer can move the package
            // anywhere under Assets - which they will, because everyone reorganises third-party
            // folders on import.
            string[] guids = AssetDatabase.FindAssets(DefaultCorpusFileName + " t:TextAsset");
            for (int i = 0; i < guids.Length; i++)
            {
                string assetPath = AssetDatabase.GUIDToAssetPath(guids[i]);
                if (assetPath.EndsWith(DefaultCorpusFileName + ".json", StringComparison.OrdinalIgnoreCase))
                {
                    TextAsset asset = AssetDatabase.LoadAssetAtPath<TextAsset>(assetPath);
                    if (asset != null)
                    {
                        return asset.text;
                    }
                }
            }

            return null;
        }
    }
}
