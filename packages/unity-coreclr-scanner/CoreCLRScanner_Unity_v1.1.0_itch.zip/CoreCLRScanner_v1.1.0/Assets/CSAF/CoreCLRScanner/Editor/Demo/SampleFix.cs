// Copyright (c) 2026 CSAF (Corey Gallant and Stephanie Thomason). All rights reserved.
// CSAF CoreCLR Migration Scanner - bundled sample fix pass.

// Nullable is enabled per file, not per project - see Model/MigrationModel.cs for why.
#nullable enable

using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace CSAF.CoreCLRScanner
{
    /// <summary>
    /// Runs the whole fix loop - scan, preview, apply, re-scan - against a sandbox copy of the
    /// bundled samples, so the loop can be exercised end to end without touching a single project
    /// file.
    /// </summary>
    /// <remarks>
    /// The samples are copied to <c>Temp/CSAF_FixDemo</c> as real <c>.cs</c> files first. Fixing
    /// the shipped samples in place would make the demo single-use and would modify this package's
    /// own content; fixing copies in <c>Temp</c> is repeatable forever and survives nothing it
    /// should not - Unity clears <c>Temp</c> routinely, which is the point.
    /// </remarks>
    public static class SampleFix
    {
        private const string SampleFolderName = "SampleLegacyCode";
        private const string SandboxFolderName = "CSAF_FixDemo";

        /// <summary>Copies the samples to a sandbox, scans them, and opens the fix preview.</summary>
        [MenuItem("Tools/CSAF/Fix Bundled Sample (Sandbox)")]
        public static void Run()
        {
            string sandbox = PrepareSandbox();
            if (sandbox.Length == 0)
            {
                EditorUtility.DisplayDialog(
                    "CoreCLR Migration Scanner",
                    "Could not find the bundled sample files. Expected a folder named '" +
                    SampleFolderName + "' containing .cs.txt files inside the package.",
                    "OK");
                return;
            }

            ScanAndPreview(sandbox);
        }

        private static void ScanAndPreview(string sandbox)
        {
            List<string> files = CollectSandboxFiles(sandbox);
            ScanReport report = CoreClrScanner.ScanFiles(files);
            Debug.Log(ReportExporter.BuildConsoleSummary(report));

            FixPlan plan = FixEngine.BuildPlan(report, sandbox);
            ScannerWindow.ShowReport(report);
            FixPreviewWindow.Open(plan, sandbox, () =>
            {
                // Re-scan the sandbox after the apply, so the report window shows the findings
                // actually falling - the whole loop, demonstrated on disk rather than asserted.
                List<string> after = CollectSandboxFiles(sandbox);
                ScanReport rescanned = CoreClrScanner.ScanFiles(after);
                Debug.Log("[CSAF CoreCLR Scanner] Sandbox after fix pass: " +
                          ReportExporter.BuildConsoleSummary(rescanned));
                ScannerWindow.ShowReport(rescanned);
            });
        }

        private static string PrepareSandbox()
        {
            string projectRoot = Directory.GetParent(Application.dataPath).FullName;
            string sandbox = Path.Combine(projectRoot, "Temp", SandboxFolderName);

            var sources = new List<string>();
            string[] guids = AssetDatabase.FindAssets("t:TextAsset");
            for (int i = 0; i < guids.Length; i++)
            {
                string assetPath = AssetDatabase.GUIDToAssetPath(guids[i]);
                if (assetPath.IndexOf(SampleFolderName, System.StringComparison.OrdinalIgnoreCase) >= 0 &&
                    assetPath.EndsWith(".cs.txt", System.StringComparison.OrdinalIgnoreCase))
                {
                    sources.Add(assetPath);
                }
            }

            if (sources.Count == 0)
            {
                return string.Empty;
            }

            Directory.CreateDirectory(sandbox);
            for (int i = 0; i < sources.Count; i++)
            {
                string full = Path.GetFullPath(sources[i]);
                string name = Path.GetFileNameWithoutExtension(sources[i]); // strips only .txt, leaving Name.cs
                File.Copy(full, Path.Combine(sandbox, name), true);
            }

            return sandbox;
        }

        private static List<string> CollectSandboxFiles(string sandbox)
        {
            var files = new List<string>();
            if (Directory.Exists(sandbox))
            {
                files.AddRange(Directory.GetFiles(sandbox, "*.cs", SearchOption.TopDirectoryOnly));
            }

            return files;
        }
    }
}
