// Copyright (c) 2026 CSAF (Corey Gallant and Stephanie Thomason). All rights reserved.
// CSAF CoreCLR Migration Scanner

// Nullable is enabled per file, not per project - see Model/MigrationModel.cs for why.
#nullable enable

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace CSAF.CoreCLRScanner
{
    /// <summary>
    /// The scanner's report window.
    /// </summary>
    /// <remarks>
    /// Drawn deliberately rather than assembled from default controls. A migration report is read
    /// by someone deciding how much work is left, so the first thing on screen is three counts and
    /// a change against the last run - not a list. The list is what you read second, once you have
    /// decided to care.
    /// </remarks>
    public sealed class ScannerWindow : EditorWindow
    {
        private const string BaselinePrefKey = "CSAF.CoreCLRScanner.BaselinePath";
        private const float HeaderHeight = 84f;
        private const float TileHeight = 62f;

        /// <summary>
        /// Upper bound on how wide a single summary tile may grow.
        /// </summary>
        /// <remarks>
        /// The tiles used to divide the full window width between them. On a maximised editor that
        /// gave each one about 500px of empty panel around a two-character number, which reads as an
        /// unfinished layout rather than a designed one. Found by photographing the window and
        /// looking at it, which is the only way this class of defect is ever found.
        /// </remarks>
        private const float TileMaxWidth = 290f;

        /// <summary>Width of the label column in the expanded detail panel.</summary>
        /// <remarks>
        /// Explicit because <c>EditorGUILayout.LabelField(label, value)</c> sizes its label column
        /// from <c>EditorGUIUtility.labelWidth</c>, which scales with the window. On a wide window
        /// the code snippet started roughly 200px from its own label and looked like a bug.
        /// </remarks>
        private const float DetailLabelWidth = 76f;

        /// <summary>
        /// How many rows are laid out before paging kicks in.
        /// </summary>
        /// <remarks>
        /// IMGUI lays out every row it is asked for, whether or not the row is on screen, so a
        /// 6,000-finding report on a large project would build six thousand rects per repaint and
        /// the window would stop being usable at exactly the size where this tool matters most.
        /// </remarks>
        private const int PageSize = 200;

        private static readonly Color BreakingColor = new Color(0.90f, 0.29f, 0.31f);
        private static readonly Color BehaviouralColor = new Color(0.95f, 0.68f, 0.23f);
        private static readonly Color InfoColor = new Color(0.36f, 0.65f, 0.86f);
        private static readonly Color AssemblyColor = new Color(0.63f, 0.55f, 0.90f);
        private static readonly Color WorseColor = new Color(0.90f, 0.29f, 0.31f);
        private static readonly Color BetterColor = new Color(0.40f, 0.78f, 0.45f);
        private static readonly Color UnchangedColor = new Color(0.60f, 0.60f, 0.60f);

        private ScanReport? _report;
        private ScanReport? _baseline;
        private Vector2 _scroll;
        private string _categoryFilter = "All";
        private MigrationSeverity _minSeverity = MigrationSeverity.Info;
        private readonly HashSet<int> _expanded = new HashSet<int>();

        // ---- filter cache -------------------------------------------------------------------
        // OnGUI runs on every repaint, and the filter used to be applied by walking every finding
        // and allocating a fresh List<string> plus a ToArray() for the category popup EACH TIME.
        // That is O(findings) work and two allocations per frame, on a window whose whole purpose is
        // displaying a large result set. The wing checklist bans exactly this. These caches are
        // rebuilt only when the report or a filter actually changes.
        private readonly List<string> _categories = new List<string> { "All" };
        private string[] _categoryNames = { "All" };
        private readonly List<int> _visible = new List<int>();
        private ScanReport? _cacheKeyReport;
        private string _cacheKeyCategory = string.Empty;
        private MigrationSeverity _cacheKeySeverity = MigrationSeverity.Info;
        private int _cacheKeyFindingCount = -1;
        private int _pagesShown = 1;
        private ScanReport? _deltaCacheReport;
        private ScanReport? _deltaCacheBaseline;
        private string _deltaSummary = string.Empty;

        private GUIStyle _titleStyle = null!;
        private GUIStyle _subtitleStyle = null!;
        private GUIStyle _tileNumberStyle = null!;
        private GUIStyle _tileLabelStyle = null!;
        private GUIStyle _tileDeltaStyle = null!;
        private GUIStyle _rowTitleStyle = null!;
        private GUIStyle _rowPathStyle = null!;
        private GUIStyle _bodyStyle = null!;
        private GUIStyle _centredBodyStyle = null!;
        private GUIStyle _monoStyle = null!;
        private GUIStyle _detailLabelStyle = null!;
        private GUIStyle _detailHeadingStyle = null!;

        /// <summary>Opens the window from the Unity menu.</summary>
        [MenuItem("Window/CSAF/CoreCLR Migration Scanner")]
        public static void Open()
        {
            ScannerWindow window = GetWindow<ScannerWindow>(false, "CoreCLR Scanner", true);
            window.minSize = new Vector2(720f, 460f);
            window.Show();
        }

        /// <summary>
        /// Opens the window showing an already-computed report.
        /// </summary>
        /// <param name="report">The report to display.</param>
        /// <remarks>
        /// The seam the demo uses, and the one anyone wiring the scanner into their own tooling
        /// needs: it keeps the window a presenter of a report rather than the only thing that can
        /// produce one.
        /// </remarks>
        public static void ShowReport(ScanReport report)
        {
            ScannerWindow window = GetWindow<ScannerWindow>(false, "CoreCLR Scanner", true);
            window.minSize = new Vector2(720f, 460f);
            window._report = report;
            window._expanded.Clear();
            window.Show();
            window.Repaint();
        }

        private void OnEnable()
        {
            string baselinePath = EditorPrefs.GetString(BaselinePrefKey, string.Empty);
            if (!string.IsNullOrEmpty(baselinePath))
            {
                _baseline = ReportExporter.ReadJson(baselinePath);
            }
        }

        private void OnGUI()
        {
            EnsureStyles();

            DrawHeader();
            DrawToolbar();

            if (_report == null)
            {
                DrawEmptyState();
                return;
            }

            DrawTiles(_report);

            // Called on both sides of the filter controls, and neither call is redundant. The first
            // makes sure the category popup is offering categories from THIS report; the second
            // picks up a filter the user just changed, so the list below matches the control above
            // in the same frame rather than one frame late. When nothing has changed the second call
            // is four comparisons and returns.
            RefreshCaches(_report);
            DrawFilters(_report);
            RefreshCaches(_report);

            DrawFindings(_report);
        }

        private void DrawHeader()
        {
            Rect rect = new Rect(0f, 0f, position.width, HeaderHeight);
            EditorGUI.DrawRect(rect, new Color(0.11f, 0.12f, 0.15f));

            // A single accent rule under the header. Cheap, and it is most of what separates a
            // designed panel from a default one.
            EditorGUI.DrawRect(new Rect(0f, HeaderHeight - 2f, position.width, 2f), new Color(0.36f, 0.65f, 0.86f));

            GUI.Label(new Rect(18f, 14f, position.width - 36f, 24f), "CoreCLR Migration Scanner", _titleStyle);

            string corpus = RuleCorpus.CorpusVersion;
            string subtitle = "Finds what Project Auditor does not: P/Invoke, serialization, assembly loading, reflection, threading.";
            GUI.Label(new Rect(18f, 40f, position.width - 36f, 18f), subtitle, _subtitleStyle);
            GUI.Label(new Rect(18f, 58f, position.width - 36f, 18f), "Rule corpus " + corpus, _subtitleStyle);

            GUILayout.Space(HeaderHeight + 6f);
        }

        private void DrawToolbar()
        {
            EditorGUILayout.BeginHorizontal();

            if (GUILayout.Button("Scan Project", GUILayout.Height(24f), GUILayout.Width(120f)))
            {
                RuleCorpus.Invalidate();
                _report = CoreClrScanner.ScanProject(true);
                _expanded.Clear();
            }

            using (new EditorGUI.DisabledScope(_report == null))
            {
                if (GUILayout.Button("Preview Fixes", GUILayout.Height(24f), GUILayout.Width(120f)))
                {
                    PreviewFixes();
                }

                if (GUILayout.Button("Export Report", GUILayout.Height(24f), GUILayout.Width(120f)))
                {
                    ExportReport();
                }

                if (GUILayout.Button("Set As Baseline", GUILayout.Height(24f), GUILayout.Width(130f)))
                {
                    SetBaseline();
                }
            }

            GUILayout.FlexibleSpace();

            if (_baseline != null)
            {
                // Computed only when the report or baseline object changes - OnGUI runs every
                // frame and a delta over thousands of findings is not a per-frame cost.
                if (!ReferenceEquals(_deltaCacheReport, _report) || !ReferenceEquals(_deltaCacheBaseline, _baseline))
                {
                    _deltaCacheReport = _report;
                    _deltaCacheBaseline = _baseline;
                    _deltaSummary = _report != null
                        ? Burndown.Summarize(Burndown.Delta(_report, _baseline))
                        : string.Empty;
                }

                string label = _deltaSummary.Length > 0
                    ? _deltaSummary + "   |   Baseline: " + _baseline.scannedAtUtc
                    : "Baseline: " + _baseline.scannedAtUtc;
                GUILayout.Label(label, _bodyStyle, GUILayout.Height(24f));
            }

            EditorGUILayout.EndHorizontal();
            GUILayout.Space(6f);
        }

        private void DrawEmptyState()
        {
            GUILayout.Space(40f);
            GUILayout.Label(
                "No scan yet.\n\nPress Scan Project to read every C# file and reflect over every compiled\n" +
                "assembly in this project, including precompiled third-party DLLs.",
                _centredBodyStyle);
        }

        private void DrawTiles(ScanReport report)
        {
            Rect row = GUILayoutUtility.GetRect(0f, TileHeight, GUILayout.ExpandWidth(true));
            const float gap = 8f;
            float tileWidth = Mathf.Min(TileMaxWidth, (row.width - (gap * 3f)) / 4f);

            DrawTile(new Rect(row.x, row.y, tileWidth, row.height), "BREAKING", report.BreakingCount,
                _baseline == null ? (int?)null : _baseline.BreakingCount, BreakingColor, null);

            DrawTile(new Rect(row.x + tileWidth + gap, row.y, tileWidth, row.height), "BEHAVIOURAL",
                report.BehaviouralCount, _baseline == null ? (int?)null : _baseline.BehaviouralCount,
                BehaviouralColor, null);

            DrawTile(new Rect(row.x + ((tileWidth + gap) * 2f), row.y, tileWidth, row.height), "INFO",
                report.InfoCount, _baseline == null ? (int?)null : _baseline.InfoCount, InfoColor, null);

            // The fourth tile is the differentiator, promoted out of the grey caption line it used to
            // sit in. A text search over your own C# is not the hard part of a migration audit; the
            // number of COMPILED assemblies reflected over is what separates this from a grep, and a
            // buyer should not have to hunt for it under the tiles.
            DrawTile(new Rect(row.x + ((tileWidth + gap) * 3f), row.y, tileWidth, row.height),
                "COMPILED ASSEMBLIES", report.assembliesScanned, null, AssemblyColor,
                report.filesScanned.ToString(CultureInfo.InvariantCulture) + " source files scanned");

            GUILayout.Space(8f);

            if (report.cancelled)
            {
                EditorGUILayout.HelpBox(
                    "This scan was cancelled before it finished. These counts are a lower bound, not a result - " +
                    "a partial scan always looks like progress. Re-run before acting on them.",
                    MessageType.Warning);
            }
        }

        /// <param name="subText">
        /// Optional line drawn where the baseline delta would go, for a tile that has no baseline.
        /// Nullable because this file enables nullable reference types per-file (see
        /// Model/MigrationModel.cs for why it is per-file and not per-project), so a plain
        /// <c>string</c> here makes every <c>null</c> call site a CS8625 error under -warnaserror.
        /// </param>
        private void DrawTile(Rect rect, string label, int count, int? baselineCount, Color accent, string? subText)
        {
            EditorGUI.DrawRect(rect, new Color(0.17f, 0.18f, 0.21f));
            EditorGUI.DrawRect(new Rect(rect.x, rect.y, 3f, rect.height), accent);

            GUI.Label(new Rect(rect.x + 14f, rect.y + 6f, rect.width - 20f, 18f), label, _tileLabelStyle);
            GUI.Label(new Rect(rect.x + 14f, rect.y + 22f, rect.width - 20f, 30f),
                count.ToString(CultureInfo.InvariantCulture), _tileNumberStyle);

            if (!baselineCount.HasValue)
            {
                if (!string.IsNullOrEmpty(subText))
                {
                    _tileDeltaStyle.normal.textColor = UnchangedColor;
                    GUI.Label(new Rect(rect.x + 14f, rect.y + rect.height - 18f, rect.width - 20f, 16f),
                        subText, _tileDeltaStyle);
                }

                return;
            }

            int delta = count - baselineCount.Value;
            string deltaText;
            Color deltaColor;

            if (delta > 0)
            {
                deltaText = "+" + delta.ToString(CultureInfo.InvariantCulture) + " since baseline";
                deltaColor = WorseColor;
            }
            else if (delta < 0)
            {
                deltaText = delta.ToString(CultureInfo.InvariantCulture) + " since baseline";
                deltaColor = BetterColor;
            }
            else
            {
                deltaText = "no change";
                deltaColor = UnchangedColor;
            }

            // Re-colouring a cached style costs nothing. Cloning one per tile per repaint, which is
            // what this used to do, allocates three GUIStyles every frame the window is visible.
            _tileDeltaStyle.normal.textColor = deltaColor;
            GUI.Label(new Rect(rect.x + 14f, rect.y + rect.height - 18f, rect.width - 20f, 16f), deltaText, _tileDeltaStyle);
        }

        private void DrawFilters(ScanReport report)
        {
            EditorGUILayout.BeginHorizontal();

            int currentIndex = Mathf.Max(0, _categories.IndexOf(_categoryFilter));
            int newIndex = EditorGUILayout.Popup("Category", currentIndex, _categoryNames, GUILayout.Width(280f));
            _categoryFilter = _categories[newIndex];

            _minSeverity = (MigrationSeverity)EditorGUILayout.EnumPopup("Minimum severity", _minSeverity, GUILayout.Width(280f));

            EditorGUILayout.EndHorizontal();
            GUILayout.Space(4f);
        }

        private void DrawFindings(ScanReport report)
        {
            _scroll = EditorGUILayout.BeginScrollView(_scroll);

            if (_visible.Count == 0)
            {
                GUILayout.Space(20f);
                GUILayout.Label("Nothing matches the current filter.", _bodyStyle);
                EditorGUILayout.EndScrollView();
                return;
            }

            int limit = Mathf.Min(_visible.Count, _pagesShown * PageSize);
            for (int v = 0; v < limit; v++)
            {
                int index = _visible[v];
                DrawFindingRow(report.findings[index], index, v);
            }

            if (limit < _visible.Count)
            {
                GUILayout.Space(8f);
                GUILayout.Label(
                    "Showing " + limit.ToString(CultureInfo.InvariantCulture) + " of " +
                    _visible.Count.ToString(CultureInfo.InvariantCulture) + " matching findings.",
                    _bodyStyle);

                if (GUILayout.Button("Show " + PageSize.ToString(CultureInfo.InvariantCulture) + " more", GUILayout.Width(180f)))
                {
                    _pagesShown++;
                }

                GUILayout.Label(
                    "Every finding is in the exported JSON and Markdown regardless of what is shown here.",
                    _bodyStyle);
            }

            EditorGUILayout.EndScrollView();
        }

        /// <summary>
        /// Rebuilds the category list and the filtered index list, but only when something they
        /// depend on has changed.
        /// </summary>
        /// <remarks>
        /// The finding count is part of the cache key as well as the report reference, because the
        /// scanner appends to an existing report's list - so a stale cache is possible even when the
        /// object identity has not changed.
        /// </remarks>
        private void RefreshCaches(ScanReport report)
        {
            bool reportChanged = !ReferenceEquals(_cacheKeyReport, report) ||
                                 _cacheKeyFindingCount != report.findings.Count;

            if (reportChanged)
            {
                _categories.Clear();
                _categories.Add("All");

                for (int i = 0; i < report.findings.Count; i++)
                {
                    string category = report.findings[i].category;
                    if (!string.IsNullOrEmpty(category) && !_categories.Contains(category))
                    {
                        _categories.Add(category);
                    }
                }

                _categoryNames = _categories.ToArray();

                if (!_categories.Contains(_categoryFilter))
                {
                    _categoryFilter = "All";
                }
            }

            if (!reportChanged &&
                string.Equals(_cacheKeyCategory, _categoryFilter, StringComparison.Ordinal) &&
                _cacheKeySeverity == _minSeverity)
            {
                return;
            }

            _visible.Clear();
            bool allCategories = string.Equals(_categoryFilter, "All", StringComparison.Ordinal);

            for (int i = 0; i < report.findings.Count; i++)
            {
                MigrationFinding finding = report.findings[i];

                if (finding.severity < _minSeverity)
                {
                    continue;
                }

                if (!allCategories && !string.Equals(finding.category, _categoryFilter, StringComparison.Ordinal))
                {
                    continue;
                }

                _visible.Add(i);
            }

            _cacheKeyReport = report;
            _cacheKeyFindingCount = report.findings.Count;
            _cacheKeyCategory = _categoryFilter;
            _cacheKeySeverity = _minSeverity;
            _pagesShown = 1;
        }

        private void DrawFindingRow(MigrationFinding finding, int index, int stripeIndex)
        {
            // Keyed by index rather than by a composed string. The old key concatenated the rule id
            // and the index on every visible row on every repaint - one string allocation per row
            // per frame, for a value that is thrown away immediately.
            bool isExpanded = _expanded.Contains(index);

            // ExpandWidth rather than an explicit position.width. Asking for exactly the window
            // width inside a scroll view whose viewport is narrower by the vertical scrollbar made
            // the content permanently wider than the viewport, so the list carried a horizontal
            // scrollbar it never needed - on every window size, for every report.
            Rect row = GUILayoutUtility.GetRect(0f, 40f, GUILayout.ExpandWidth(true));

            // Striped by POSITION IN THE VISIBLE LIST, not by index in the report. Striping by the
            // report index meant that filtering out a run of odd-numbered findings produced several
            // same-coloured rows in a row, so the zebra stopped doing the one thing it is for.
            EditorGUI.DrawRect(row, stripeIndex % 2 == 0 ? new Color(0.20f, 0.21f, 0.24f) : new Color(0.18f, 0.19f, 0.22f));
            EditorGUI.DrawRect(new Rect(row.x, row.y, 4f, row.height), SeverityColor(finding.severity));

            GUI.Label(new Rect(row.x + 14f, row.y + 4f, row.width - 120f, 18f),
                finding.ruleId + "  " + finding.title, _rowTitleStyle);

            string location = finding.path + (finding.line > 0 ? ":" + finding.line.ToString(CultureInfo.InvariantCulture) : string.Empty);
            string originTag = finding.origin == FindingOrigin.Assembly ? "  [compiled assembly]" : string.Empty;
            GUI.Label(new Rect(row.x + 14f, row.y + 21f, row.width - 120f, 16f), location + originTag, _rowPathStyle);

            if (GUI.Button(new Rect(row.xMax - 96f, row.y + 9f, 80f, 22f), isExpanded ? "Hide" : "Details"))
            {
                if (isExpanded)
                {
                    _expanded.Remove(index);
                }
                else
                {
                    _expanded.Add(index);
                }
            }

            if (!isExpanded)
            {
                return;
            }

            CoreClrRule? rule = FindRule(finding.ruleId);

            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            GUILayout.Space(2f);

            DrawDetailRow("Code", finding.snippet, _monoStyle);
            DrawDetailRow("Context", finding.context, _bodyStyle);

            if (rule != null)
            {
                GUILayout.Space(6f);
                GUILayout.Label("Why this breaks", _detailHeadingStyle);
                GUILayout.Label(rule.why, _bodyStyle);
                GUILayout.Space(6f);
                GUILayout.Label("How to fix it", _detailHeadingStyle);
                GUILayout.Label(rule.remedy, _bodyStyle);
            }

            GUILayout.Space(8f);

            // One horizontal row. Stacked vertically these two 140px buttons sat in a narrow column
            // against a very wide panel and looked like a layout that had given up.
            EditorGUILayout.BeginHorizontal();

            if (rule != null && !string.IsNullOrEmpty(rule.docUrl) &&
                GUILayout.Button("Open reference", GUILayout.Width(140f), GUILayout.Height(22f)))
            {
                Application.OpenURL(rule.docUrl);
            }

            if (finding.origin == FindingOrigin.Source &&
                GUILayout.Button("Open file", GUILayout.Width(140f), GUILayout.Height(22f)))
            {
                var asset = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(finding.path);
                if (asset != null)
                {
                    AssetDatabase.OpenAsset(asset, Mathf.Max(1, finding.line));
                }
            }

            GUILayout.FlexibleSpace();
            EditorGUILayout.EndHorizontal();
            GUILayout.Space(2f);

            EditorGUILayout.EndVertical();
        }

        /// <summary>
        /// One labelled line in the expanded detail panel, with a fixed-width label column.
        /// </summary>
        /// <param name="label">The column heading.</param>
        /// <param name="value">The value; the row is skipped entirely when this is empty.</param>
        /// <param name="valueStyle">Style for the value - monospace for code, body text otherwise.</param>
        private void DrawDetailRow(string label, string value, GUIStyle valueStyle)
        {
            if (string.IsNullOrEmpty(value))
            {
                return;
            }

            EditorGUILayout.BeginHorizontal();
            GUILayout.Label(label, _detailLabelStyle, GUILayout.Width(DetailLabelWidth));
            GUILayout.Label(value, valueStyle);
            EditorGUILayout.EndHorizontal();
        }

        private static CoreClrRule? FindRule(string ruleId)
        {
            CoreClrRule[] rules = RuleCorpus.GetRules();
            for (int i = 0; i < rules.Length; i++)
            {
                if (string.Equals(rules[i].id, ruleId, StringComparison.Ordinal))
                {
                    return rules[i];
                }
            }

            return null;
        }

        private static Color SeverityColor(MigrationSeverity severity)
        {
            switch (severity)
            {
                case MigrationSeverity.Breaking:
                    return BreakingColor;
                case MigrationSeverity.Behavioural:
                    return BehaviouralColor;
                default:
                    return InfoColor;
            }
        }

        private void PreviewFixes()
        {
            if (_report == null)
            {
                return;
            }

            string projectRoot = Directory.GetParent(Application.dataPath).FullName;
            FixPlan plan = FixEngine.BuildPlan(_report, projectRoot);
            FixPreviewWindow.Open(plan, projectRoot, () =>
            {
                // After an apply the report on screen describes a project that no longer exists.
                // Re-scan immediately so the window never shows fixed findings as open.
                RuleCorpus.Invalidate();
                _report = CoreClrScanner.ScanProject(true);
                _expanded.Clear();
                Repaint();
            });
        }

        private void ExportReport()
        {
            if (_report == null)
            {
                return;
            }

            string directory = EditorUtility.SaveFolderPanel("Export CoreCLR migration report", string.Empty, string.Empty);
            if (string.IsNullOrEmpty(directory))
            {
                return;
            }

            ReportExporter.WriteJson(_report, Path.Combine(directory, "coreclr-report.json"));
            ReportExporter.WriteMarkdown(_report, _baseline, Path.Combine(directory, "coreclr-report.md"));
            Debug.Log("[CSAF CoreCLR Scanner] Exported report to " + directory);
        }

        private void SetBaseline()
        {
            if (_report == null)
            {
                return;
            }

            string path = EditorUtility.SaveFilePanel("Save baseline", string.Empty, "coreclr-baseline.json", "json");
            if (string.IsNullOrEmpty(path))
            {
                return;
            }

            ReportExporter.WriteJson(_report, path);
            EditorPrefs.SetString(BaselinePrefKey, path);
            _baseline = ReportExporter.ReadJson(path);
        }

        private void EnsureStyles()
        {
            if (_titleStyle != null)
            {
                return;
            }

            _titleStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 17,
                normal = { textColor = new Color(0.94f, 0.95f, 0.97f) }
            };

            _subtitleStyle = new GUIStyle(EditorStyles.label)
            {
                fontSize = 11,
                normal = { textColor = new Color(0.66f, 0.70f, 0.76f) }
            };

            _tileNumberStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 24,
                normal = { textColor = new Color(0.95f, 0.96f, 0.98f) }
            };

            _tileLabelStyle = new GUIStyle(EditorStyles.miniLabel)
            {
                normal = { textColor = new Color(0.62f, 0.66f, 0.72f) }
            };

            // A separate instance from _tileLabelStyle because DrawTile recolours it per tile.
            _tileDeltaStyle = new GUIStyle(EditorStyles.miniLabel);

            _rowTitleStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                normal = { textColor = new Color(0.92f, 0.93f, 0.95f) }
            };

            _rowPathStyle = new GUIStyle(EditorStyles.miniLabel)
            {
                normal = { textColor = new Color(0.60f, 0.64f, 0.70f) }
            };

            _bodyStyle = new GUIStyle(EditorStyles.label) { wordWrap = true };

            _centredBodyStyle = new GUIStyle(_bodyStyle)
            {
                alignment = TextAnchor.MiddleCenter,
                wordWrap = true
            };

            // The offending line is code, so it is set in a font code is read in - a snippet in the
            // proportional UI font is harder to match against the file it came from. Unity exposes
            // no monospace face in EditorStyles, so this asks the OS for one by preference order and
            // silently accepts the platform fallback if none of them exist. Cosmetic either way:
            // nothing here can fail in a way that costs the reader the snippet.
            _monoStyle = new GUIStyle(EditorStyles.label)
            {
                font = Font.CreateDynamicFontFromOSFont(
                    new[] { "Consolas", "Cascadia Mono", "Menlo", "DejaVu Sans Mono", "Courier New" }, 11),
                wordWrap = true,
                normal = { textColor = new Color(0.80f, 0.86f, 0.94f) }
            };

            _detailLabelStyle = new GUIStyle(EditorStyles.miniLabel)
            {
                alignment = TextAnchor.UpperLeft,
                normal = { textColor = new Color(0.58f, 0.62f, 0.69f) }
            };

            _detailHeadingStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                normal = { textColor = new Color(0.55f, 0.78f, 0.96f) }
            };
        }
    }
}
