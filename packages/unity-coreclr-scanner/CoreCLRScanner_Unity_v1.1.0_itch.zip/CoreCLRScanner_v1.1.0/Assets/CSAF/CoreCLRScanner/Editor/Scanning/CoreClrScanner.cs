// Copyright (c) 2026 CSAF (Corey Gallant and Stephanie Thomason). All rights reserved.
// CSAF CoreCLR Migration Scanner

// Nullable is enabled per file, not per project - see Model/MigrationModel.cs for why.
#nullable enable

using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace CSAF.CoreCLRScanner
{
    /// <summary>
    /// Runs a full scan: source first, then compiled assemblies, into one report.
    /// </summary>
    public static class CoreClrScanner
    {
        /// <summary>
        /// Folder fragments never scanned as source.
        /// </summary>
        /// <remarks>
        /// The scanner's own folder is excluded for a concrete reason, not for tidiness: the rule
        /// corpus contains the literal strings the rules search for, so a scan that includes this
        /// package reports the package. Test fixtures are excluded because a test that deliberately
        /// exercises a dead API is not a migration hazard - it is a test.
        /// </remarks>
        private static readonly string[] DefaultExclusions =
        {
            "/CSAF/CoreCLRScanner/",
            "/Library/",
            "/Temp/",
            "/obj/",
            "~/"
        };

        private static readonly string[] SourceExtensions = { ".cs" };

        /// <summary>Runs a scan over the whole project with a cancellable progress bar.</summary>
        /// <param name="includeAssemblies">Whether to reflect over compiled assemblies as well as source.</param>
        /// <returns>The report. Never null; a cancelled scan returns what it had gathered so far.</returns>
        public static ScanReport ScanProject(bool includeAssemblies = true)
        {
            string projectRoot = Directory.GetParent(Application.dataPath).FullName;
            var report = NewReport();

            try
            {
                bool completed = SourceScanner.Scan(
                    Application.dataPath,
                    SourceExtensions,
                    DefaultExclusions,
                    RuleCorpus.GetRules(),
                    report,
                    (fraction, path) => !EditorUtility.DisplayCancelableProgressBar(
                        "CoreCLR Migration Scanner",
                        "Scanning source: " + Path.GetFileName(path),
                        fraction));

                if (completed && includeAssemblies)
                {
                    EditorUtility.DisplayProgressBar(
                        "CoreCLR Migration Scanner",
                        "Reflecting over compiled assemblies...",
                        0.95f);

                    AssemblyScanner.Scan(projectRoot, RuleCorpus.GetRules(), report);
                }

                report.cancelled = !completed;
            }
            finally
            {
                // Always cleared. A progress bar left up by an exception locks the Editor and looks
                // exactly like a hang, which is a support ticket for a bug that did not happen.
                EditorUtility.ClearProgressBar();
            }

            return report;
        }

        /// <summary>
        /// Scans an explicit set of files. Used by the demo, and by anyone wiring the scanner into
        /// their own tooling over a subset of the project.
        /// </summary>
        /// <param name="absolutePaths">Files to read.</param>
        /// <returns>The report.</returns>
        public static ScanReport ScanFiles(IReadOnlyList<string> absolutePaths)
        {
            var report = NewReport();
            if (absolutePaths == null)
            {
                return report;
            }

            IReadOnlyList<CoreClrRule> rules = RuleCorpus.GetRules();

            for (int i = 0; i < absolutePaths.Count; i++)
            {
                string path = absolutePaths[i];
                if (string.IsNullOrEmpty(path) || !File.Exists(path))
                {
                    continue;
                }

                string[] lines;
                try
                {
                    lines = File.ReadAllLines(path);
                }
                catch (IOException)
                {
                    continue;
                }

                report.filesScanned++;
                SourceScanner.ScanLines(path, lines, rules, report);
            }

            return report;
        }

        private static ScanReport NewReport()
        {
            return new ScanReport
            {
                scannedAtUtc = DateTime.UtcNow.ToString("o"),
                unityVersion = Application.unityVersion,
                corpusVersion = RuleCorpus.CorpusVersion
            };
        }
    }
}
