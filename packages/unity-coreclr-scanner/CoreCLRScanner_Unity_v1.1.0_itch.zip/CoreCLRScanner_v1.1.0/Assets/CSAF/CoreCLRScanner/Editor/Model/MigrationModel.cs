// Copyright (c) 2026 CSAF (Corey Gallant and Stephanie Thomason). All rights reserved.
// CSAF CoreCLR Migration Scanner
//
// Data model for the scanner. Everything here is plain serializable data so that a report can be
// written to JSON by a CI job and read back by a human days later without the Editor in the loop.

// Nullable is enabled per file rather than per project on purpose. A buyer's project may have
// nullable disabled, and a bare `string?` annotation outside an annotation context raises CS8632 -
// which, in a project that also builds with warnings-as-errors, would break THEIR build on import.
// Per-file context makes this package's analysis independent of the settings around it.
#nullable enable

using System;
using System.Collections.Generic;

namespace CSAF.CoreCLRScanner
{
    /// <summary>
    /// How badly a finding breaks under CoreCLR. Ordered so that a numeric sort puts the worst first.
    /// </summary>
    /// <remarks>
    /// The distinction that matters to a producer planning a migration is <see cref="Breaking"/>
    /// versus <see cref="Behavioural"/>. A breaking finding throws or fails to compile the moment
    /// Mono is gone, so it is schedulable work with a hard deadline. A behavioural finding still
    /// runs and returns a different answer, which is far more expensive to find later because it
    /// surfaces as a bug report rather than as a stack trace.
    /// </remarks>
    public enum MigrationSeverity
    {
        /// <summary>Informational. Worth knowing during the port; nothing is required.</summary>
        Info = 0,

        /// <summary>Still works, but semantics, timing or performance change measurably.</summary>
        Behavioural = 1,

        /// <summary>Throws, is removed, or does not compile once Mono is gone. Must be fixed.</summary>
        Breaking = 2
    }

    /// <summary>
    /// Where a finding came from. Source and assembly scanning answer genuinely different
    /// questions, and a buyer needs to be able to tell them apart in the report.
    /// </summary>
    public enum FindingOrigin
    {
        /// <summary>Matched in first-party C# the buyer can edit.</summary>
        Source = 0,

        /// <summary>
        /// Found by reflecting over a compiled assembly. This is the important one: it catches
        /// precompiled third-party DLLs where no source exists to grep, which is exactly where a
        /// studio's real migration risk hides.
        /// </summary>
        Assembly = 1
    }

    /// <summary>
    /// One rule in the corpus. Rules are DATA, loaded from JSON, never hardcoded logic - so a rule
    /// change is a content change and cannot break the scanner.
    /// </summary>
    [Serializable]
    public sealed class CoreClrRule
    {
        /// <summary>Stable identifier, e.g. <c>CSAF1001</c>. Never reused once published.</summary>
        public string id = string.Empty;

        /// <summary>One of the five categories this product covers. See <see cref="RuleCorpus"/>.</summary>
        public string category = string.Empty;

        /// <summary>Severity name matching <see cref="MigrationSeverity"/>. Parsed leniently.</summary>
        public string severity = string.Empty;

        /// <summary>Short human title, shown as the row heading in the report.</summary>
        public string title = string.Empty;

        /// <summary>Why CoreCLR breaks this. The part a buyer cannot get from a grep.</summary>
        public string why = string.Empty;

        /// <summary>Concrete remediation, phrased as an instruction rather than a description.</summary>
        public string remedy = string.Empty;

        /// <summary>Optional reference URL for the buyer to read further.</summary>
        public string docUrl = string.Empty;

        /// <summary>
        /// .NET regular expressions matched against source lines. Any match raises the finding.
        /// </summary>
        public string[] patterns = Array.Empty<string>();

        /// <summary>
        /// Fully-qualified attribute or type names looked for during assembly reflection. Optional;
        /// a rule may be source-only or assembly-only.
        /// </summary>
        public string[] assemblyMarkers = Array.Empty<string>();

        /// <summary>Parsed <see cref="severity"/>, defaulting to <see cref="MigrationSeverity.Behavioural"/>.</summary>
        public MigrationSeverity ParsedSeverity
        {
            get
            {
                if (Enum.TryParse(severity, true, out MigrationSeverity parsed))
                {
                    return parsed;
                }

                return MigrationSeverity.Behavioural;
            }
        }
    }

    /// <summary>Serialization envelope so <c>JsonUtility</c> can read a top-level array of rules.</summary>
    [Serializable]
    public sealed class CoreClrRuleSet
    {
        /// <summary>Corpus version, surfaced in the report so a result can be reproduced later.</summary>
        public string corpusVersion = string.Empty;

        /// <summary>The rules themselves.</summary>
        public CoreClrRule[] rules = Array.Empty<CoreClrRule>();
    }

    /// <summary>A single located problem: one rule, one place.</summary>
    [Serializable]
    public sealed class MigrationFinding
    {
        /// <summary>The <see cref="CoreClrRule.id"/> that produced this finding.</summary>
        public string ruleId = string.Empty;

        /// <summary>Category copied from the rule, so a report is readable without the corpus.</summary>
        public string category = string.Empty;

        /// <summary>Severity copied from the rule, for the same reason.</summary>
        public MigrationSeverity severity;

        /// <summary>Rule title, copied for standalone readability.</summary>
        public string title = string.Empty;

        /// <summary>Project-relative file path, or the assembly name for assembly findings.</summary>
        public string path = string.Empty;

        /// <summary>1-based line number. Zero for assembly findings, which have no line.</summary>
        public int line;

        /// <summary>The offending source line, trimmed. Empty for assembly findings.</summary>
        public string snippet = string.Empty;

        /// <summary>Extra context, e.g. the declaring type and method for an assembly finding.</summary>
        public string context = string.Empty;

        /// <summary>Whether this came from source or from a compiled assembly.</summary>
        public FindingOrigin origin;
    }

    /// <summary>
    /// The whole result of one scan. This is the CI artefact: serialize it, commit it, diff it, and
    /// the delta between two of these is the burndown a producer reports upward.
    /// </summary>
    [Serializable]
    public sealed class ScanReport
    {
        /// <summary>Round-trip ISO-8601 timestamp of the scan.</summary>
        public string scannedAtUtc = string.Empty;

        /// <summary>Unity version the scan ran under.</summary>
        public string unityVersion = string.Empty;

        /// <summary>Corpus version used, so an old report stays interpretable.</summary>
        public string corpusVersion = string.Empty;

        /// <summary>How many C# files were read.</summary>
        public int filesScanned;

        /// <summary>How many assemblies were reflected over.</summary>
        public int assembliesScanned;

        /// <summary>
        /// True when the user cancelled before the scan finished.
        /// </summary>
        /// <remarks>
        /// This flag is why the report can be trusted. A cancelled scan produces a LOWER count than
        /// a complete one, so without it a half-finished run reads as an improvement - the burndown
        /// would show progress that consists entirely of work not done. Every consumer must treat a
        /// cancelled report as a lower bound and say so.
        /// </remarks>
        public bool cancelled;

        /// <summary>Every finding, unsorted. Presentation decides ordering.</summary>
        public List<MigrationFinding> findings = new List<MigrationFinding>();

        /// <summary>Count of findings at <see cref="MigrationSeverity.Breaking"/>.</summary>
        public int BreakingCount
        {
            get { return CountOf(MigrationSeverity.Breaking); }
        }

        /// <summary>Count of findings at <see cref="MigrationSeverity.Behavioural"/>.</summary>
        public int BehaviouralCount
        {
            get { return CountOf(MigrationSeverity.Behavioural); }
        }

        /// <summary>Count of findings at <see cref="MigrationSeverity.Info"/>.</summary>
        public int InfoCount
        {
            get { return CountOf(MigrationSeverity.Info); }
        }

        /// <summary>Counts findings at one severity without allocating an enumerator chain.</summary>
        /// <param name="severity">Severity to count.</param>
        /// <returns>Number of findings at that severity.</returns>
        public int CountOf(MigrationSeverity severity)
        {
            int total = 0;
            for (int i = 0; i < findings.Count; i++)
            {
                if (findings[i].severity == severity)
                {
                    total++;
                }
            }

            return total;
        }
    }
}
