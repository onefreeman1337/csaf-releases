// Copyright (c) 2026 CSAF (Corey Gallant and Stephanie Thomason). All rights reserved.
// CSAF CoreCLR Migration Scanner - bundled sample scan.

// Nullable is enabled per file, not per project - see Model/MigrationModel.cs for why.
#nullable enable

using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace CSAF.CoreCLRScanner
{
    /// <summary>
    /// Scans the sample files shipped in <c>Demo/SampleLegacyCode</c>.
    /// </summary>
    /// <remarks>
    /// <para>
    /// A demo that finds nothing demonstrates nothing, and a freshly-imported project is usually
    /// clean - so "Scan Project" on a reviewer's empty test project would show an empty list and
    /// look broken. This scans deliberately non-compliant sample code instead, so the result is the
    /// same on every machine.
    /// </para>
    /// <para>
    /// The samples ship as <c>.cs.txt</c> on purpose. As <c>.cs</c> they would be compiled into the
    /// buyer's project, and code that calls BinaryFormatter and Thread.Abort would raise obsolete
    /// and deprecation warnings - which in a project building with warnings-as-errors would break
    /// the buyer's build with our own demo content.
    /// </para>
    /// </remarks>
    public static class SampleScan
    {
        private const string SampleFolderName = "SampleLegacyCode";

        /// <summary>Finds the bundled samples, scans them, and shows the report window.</summary>
        [MenuItem("Tools/CSAF/Scan Bundled Sample")]
        public static void Run()
        {
            List<string> samples = FindSampleFiles();

            if (samples.Count == 0)
            {
                EditorUtility.DisplayDialog(
                    "CoreCLR Migration Scanner",
                    "Could not find the bundled sample files. Expected a folder named '" +
                    SampleFolderName + "' containing .cs.txt files inside the package.",
                    "OK");
                return;
            }

            ScanReport report = CoreClrScanner.ScanFiles(samples);
            Debug.Log(ReportExporter.BuildConsoleSummary(report));
            ScannerWindow.ShowReport(report);
        }

        private static List<string> FindSampleFiles()
        {
            var results = new List<string>();

            // Located by asset search rather than a fixed path, for the same reason the corpus is:
            // buyers move third-party folders, and a hardcoded path turns that into a bug report.
            string[] guids = AssetDatabase.FindAssets("t:TextAsset");
            for (int i = 0; i < guids.Length; i++)
            {
                string assetPath = AssetDatabase.GUIDToAssetPath(guids[i]);
                if (assetPath.IndexOf(SampleFolderName, System.StringComparison.OrdinalIgnoreCase) < 0)
                {
                    continue;
                }

                if (!assetPath.EndsWith(".cs.txt", System.StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                string full = Path.GetFullPath(assetPath);
                if (File.Exists(full))
                {
                    results.Add(full);
                }
            }

            return results;
        }
    }
}
