// Copyright (c) 2026 CSAF (Corey Gallant and Stephanie Thomason). All rights reserved.
// CSAF CoreCLR Migration Scanner

// Nullable is enabled per file, not per project - see Model/MigrationModel.cs for why.
#nullable enable

using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;

namespace CSAF.CoreCLRScanner
{
    /// <summary>
    /// Reflects over compiled assemblies to find migration hazards that source scanning cannot see.
    /// </summary>
    /// <remarks>
    /// <para>
    /// <b>This is the half that matters most, and the half nothing else does.</b> A studio's real
    /// CoreCLR exposure is rarely in the code they wrote - it is in the twelve Asset Store plugins
    /// they bought, shipped as DLLs, whose vendors may be inactive. There is no source to grep, so a
    /// text-based migration audit reports a clean project and the studio finds out at runtime.
    /// </para>
    /// <para>
    /// P/Invoke is detectable here with certainty rather than by pattern: the CLR marks every
    /// platform-invoke method with <see cref="MethodAttributes.PinvokeImpl"/>, so the check is a
    /// metadata flag, not a guess about text. Method <i>bodies</i> are not reachable through
    /// reflection, so body-level facts stay the source scanner's job. Saying which half found what
    /// is why <see cref="MigrationFinding.origin"/> exists.
    /// </para>
    /// </remarks>
    public static class AssemblyScanner
    {
        /// <summary>Rule raised when a compiled assembly references a legacy serialization assembly.</summary>
        private const string ReferencedAssemblyRuleId = "CSAF1005";

        /// <summary>Rule raised for a P/Invoke method whose CharSet is unspecified or ANSI.</summary>
        private const string CharSetRuleId = "CSAF5001";

        /// <summary>
        /// Scans every project assembly currently loaded in the Editor.
        /// </summary>
        /// <param name="projectRoot">Absolute path to the project folder, used to filter out engine assemblies.</param>
        /// <param name="rules">Rules to apply. Only those with assembly markers participate.</param>
        /// <param name="report">Report to append to.</param>
        public static void Scan(string projectRoot, IReadOnlyList<CoreClrRule> rules, ScanReport report)
        {
            if (report == null)
            {
                throw new ArgumentNullException(nameof(report));
            }

            // Both checks are driven by a corpus rule rather than by constants in this file. A rule
            // the buyer deleted is a rule the buyer disabled, and that has to hold for the assembly
            // half as much as for the source half.
            CoreClrRule? referencedRule = FindRule(rules, ReferencedAssemblyRuleId);
            CoreClrRule? charSetRule = FindRule(rules, CharSetRuleId);

            if (referencedRule == null && charSetRule == null)
            {
                return;
            }

            Assembly[] loaded = AppDomain.CurrentDomain.GetAssemblies();

            for (int i = 0; i < loaded.Length; i++)
            {
                Assembly assembly = loaded[i];
                if (!IsProjectAssembly(assembly, projectRoot))
                {
                    continue;
                }

                report.assembliesScanned++;

                if (referencedRule != null)
                {
                    ScanReferencedAssemblies(assembly, referencedRule, report);
                }

                if (charSetRule != null)
                {
                    ScanPlatformInvokeMethods(assembly, charSetRule, report);
                }
            }
        }

        private static bool IsProjectAssembly(Assembly assembly, string projectRoot)
        {
            if (assembly == null || assembly.IsDynamic)
            {
                // A dynamic assembly has no file and throws on Location. Skipping it is correct:
                // it did not come from the project, it was emitted at runtime.
                return false;
            }

            string location;
            try
            {
                location = assembly.Location;
            }
            catch (NotSupportedException)
            {
                return false;
            }

            if (string.IsNullOrEmpty(location))
            {
                return false;
            }

            if (string.IsNullOrEmpty(projectRoot))
            {
                return false;
            }

            string normalisedLocation = location.Replace('\\', '/');
            string normalisedRoot = projectRoot.Replace('\\', '/').TrimEnd('/');

            if (normalisedLocation.IndexOf(normalisedRoot, StringComparison.OrdinalIgnoreCase) < 0)
            {
                return false;
            }

            // Everything under the project root that is not the Editor's own managed folder counts:
            // Library/ScriptAssemblies holds the buyer's compiled code, and Assets holds precompiled
            // third-party DLLs, which is exactly the population this scanner exists to reach.
            return normalisedLocation.IndexOf("/Library/ScriptAssemblies/", StringComparison.OrdinalIgnoreCase) >= 0 ||
                   normalisedLocation.IndexOf("/Assets/", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static void ScanReferencedAssemblies(Assembly assembly, CoreClrRule rule, ScanReport report)
        {
            // The suspect list is the rule's own assemblyMarkers, so adding one is a content edit.
            string[] suspects = rule.assemblyMarkers;
            if (suspects == null || suspects.Length == 0)
            {
                return;
            }

            AssemblyName[] referenced;
            try
            {
                referenced = assembly.GetReferencedAssemblies();
            }
            catch (Exception)
            {
                return;
            }

            for (int i = 0; i < referenced.Length; i++)
            {
                string? name = referenced[i].Name;
                if (string.IsNullOrEmpty(name))
                {
                    continue;
                }

                for (int s = 0; s < suspects.Length; s++)
                {
                    if (string.IsNullOrEmpty(suspects[s]) ||
                        name.IndexOf(suspects[s], StringComparison.OrdinalIgnoreCase) < 0)
                    {
                        continue;
                    }

                    report.findings.Add(NewFinding(
                        rule,
                        SafeAssemblyName(assembly),
                        "references " + name +
                        " - if this is a third-party DLL you cannot rebuild, the vendor must ship a CoreCLR-compatible version or it has to be replaced."));

                    // One finding per assembly per rule. A DLL referencing two dead serialization
                    // assemblies is still one DLL to replace.
                    return;
                }
            }
        }

        private static void ScanPlatformInvokeMethods(Assembly assembly, CoreClrRule rule, ScanReport report)
        {
            Type[] types = SafeGetTypes(assembly);

            for (int t = 0; t < types.Length; t++)
            {
                Type type = types[t];
                if (type == null)
                {
                    continue;
                }

                MethodInfo[] methods;
                try
                {
                    methods = type.GetMethods(BindingFlags.Public | BindingFlags.NonPublic |
                                              BindingFlags.Static | BindingFlags.Instance |
                                              BindingFlags.DeclaredOnly);
                }
                catch (Exception)
                {
                    continue;
                }

                for (int m = 0; m < methods.Length; m++)
                {
                    MethodInfo method = methods[m];

                    // The authoritative test. Not a naming convention, not a text match - the CLR
                    // sets this flag on every platform-invoke method, including in a DLL whose
                    // source no longer exists anywhere.
                    if ((method.Attributes & MethodAttributes.PinvokeImpl) == 0)
                    {
                        continue;
                    }

                    DllImportAttribute? import = null;
                    try
                    {
                        import = method.GetCustomAttribute<DllImportAttribute>();
                    }
                    catch (Exception)
                    {
                        // Some obfuscated or trimmed assemblies throw while materialising custom
                        // attributes. The PinvokeImpl flag already told us the important part.
                    }

                    bool charSetUnspecified = import == null ||
                                              import.CharSet == CharSet.None ||
                                              import.CharSet == CharSet.Ansi;

                    if (charSetUnspecified)
                    {
                        report.findings.Add(NewFinding(
                            rule,
                            SafeAssemblyName(assembly),
                            type.FullName + "." + method.Name +
                            (import != null ? " -> " + import.Value : string.Empty) +
                            " (CharSet " + (import != null ? import.CharSet.ToString() : "unavailable") + ")"));
                    }
                }
            }
        }

        /// <summary>
        /// Builds an assembly-origin finding whose id, category, severity and title all come from the
        /// corpus rule.
        /// </summary>
        /// <remarks>
        /// <b>This exists because of a real defect.</b> The assembly scanner used to hand-write those
        /// four fields, and it reused id <c>CSAF1003</c> - which the corpus defines as the
        /// <i>IFormatter</i> rule - for a completely different problem. The report window looks the
        /// rule up by id to render "why this breaks" and "how to fix it", so a buyer clicking Details
        /// on a legacy-assembly-reference finding was shown the remediation for an unrelated rule.
        /// Copying from the rule makes that class of drift impossible rather than merely fixed.
        /// </remarks>
        private static MigrationFinding NewFinding(CoreClrRule rule, string path, string context)
        {
            return new MigrationFinding
            {
                ruleId = rule.id,
                category = rule.category,
                severity = rule.ParsedSeverity,
                title = rule.title,
                path = path,
                line = 0,
                snippet = string.Empty,
                context = context,
                origin = FindingOrigin.Assembly
            };
        }

        private static CoreClrRule? FindRule(IReadOnlyList<CoreClrRule> rules, string id)
        {
            if (rules == null)
            {
                return null;
            }

            for (int i = 0; i < rules.Count; i++)
            {
                if (rules[i] != null && string.Equals(rules[i].id, id, StringComparison.Ordinal))
                {
                    return rules[i];
                }
            }

            return null;
        }

        private static Type[] SafeGetTypes(Assembly assembly)
        {
            try
            {
                return assembly.GetTypes();
            }
            catch (ReflectionTypeLoadException ex)
            {
                // Routine, not exceptional: an assembly referencing something unavailable still
                // yields every type that DID load. Returning the partial set is strictly better
                // than reporting the assembly as clean, which is how a scanner lies.
                var loadedTypes = new List<Type>();
                Type[] partial = ex.Types;
                for (int i = 0; i < partial.Length; i++)
                {
                    if (partial[i] != null)
                    {
                        loadedTypes.Add(partial[i]);
                    }
                }

                return loadedTypes.ToArray();
            }
            catch (Exception)
            {
                return Array.Empty<Type>();
            }
        }

        private static string SafeAssemblyName(Assembly assembly)
        {
            try
            {
                string location = assembly.Location;
                if (!string.IsNullOrEmpty(location))
                {
                    return Path.GetFileName(location);
                }
            }
            catch (NotSupportedException)
            {
                // Fall through to the simple name.
            }

            return assembly.GetName().Name;
        }
    }
}
