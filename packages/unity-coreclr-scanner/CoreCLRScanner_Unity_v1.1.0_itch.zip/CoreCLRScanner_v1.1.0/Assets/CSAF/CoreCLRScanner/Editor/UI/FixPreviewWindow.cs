// Copyright (c) 2026 CSAF (Corey Gallant and Stephanie Thomason). All rights reserved.
// CSAF CoreCLR Migration Scanner

// Nullable is enabled per file, not per project - see Model/MigrationModel.cs for why.
#nullable enable

using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace CSAF.CoreCLRScanner
{
    /// <summary>
    /// The fix pass's preview: every edit shown as a before/after diff, every refusal shown with
    /// its reason, and one Apply button that does exactly what the preview says and nothing else.
    /// </summary>
    /// <remarks>
    /// Nothing is written until Apply is pressed, and Apply re-checks every line against the text
    /// the plan captured - an edit whose file changed underneath it is refused, counted, and named.
    /// The window says plainly that fixes are file edits reviewed through version control; that is
    /// the honest contract, not a limitation to hide.
    /// </remarks>
    public sealed class FixPreviewWindow : EditorWindow
    {
        private const float HeaderHeight = 84f;

        private static readonly Color HeaderColor = new Color(0.11f, 0.12f, 0.15f);
        private static readonly Color AccentColor = new Color(0.36f, 0.65f, 0.86f);
        private static readonly Color BeforeColor = new Color(0.32f, 0.15f, 0.16f);
        private static readonly Color AfterColor = new Color(0.13f, 0.24f, 0.16f);
        private static readonly Color CardColor = new Color(0.14f, 0.15f, 0.19f);
        private static readonly Color SkipColor = new Color(0.19f, 0.17f, 0.13f);

        private FixPlan? _plan;
        private string _projectRoot = string.Empty;
        private Action? _onApplied;
        private Vector2 _scroll;

        private GUIStyle _titleStyle = null!;
        private GUIStyle _subtitleStyle = null!;
        private GUIStyle _fileStyle = null!;
        private GUIStyle _monoStyle = null!;
        private GUIStyle _noteStyle = null!;
        private GUIStyle _reasonStyle = null!;

        /// <summary>Opens the preview for a plan.</summary>
        /// <param name="plan">The plan to preview and, on confirmation, apply.</param>
        /// <param name="projectRoot">Absolute project root the plan's paths resolve against.</param>
        /// <param name="onApplied">Invoked after a successful apply, so the caller can re-scan.</param>
        public static void Open(FixPlan plan, string projectRoot, Action onApplied)
        {
            // Any existing instance is closed first. GetWindow would hand back the old instance
            // with the OLD plan captured in its fields - the saved-layout trap in this wing's own
            // §4b, arriving through a window that outlived its data.
            FixPreviewWindow[] existing = Resources.FindObjectsOfTypeAll<FixPreviewWindow>();
            for (int i = 0; i < existing.Length; i++)
            {
                existing[i].Close();
            }

            FixPreviewWindow window = CreateInstance<FixPreviewWindow>();
            window.titleContent = new GUIContent("CoreCLR Fixes");
            window.minSize = new Vector2(760f, 420f);
            window._plan = plan;
            window._projectRoot = projectRoot;
            window._onApplied = onApplied;
            window.Show();
        }

        private void OnGUI()
        {
            EnsureStyles();
            DrawHeader();

            if (_plan == null || (_plan.edits.Count == 0 && _plan.skips.Count == 0))
            {
                GUILayout.Space(40f);
                GUILayout.Label("Nothing mechanical to fix in this report.\n\n" +
                                "Findings outside the P/Invoke fixers need a decision - each one carries its remedy in the scanner window.",
                                _noteStyle);
                return;
            }

            DrawToolbar();

            _scroll = EditorGUILayout.BeginScrollView(_scroll);
            DrawEdits();
            DrawSkips();
            EditorGUILayout.EndScrollView();
        }

        private void DrawHeader()
        {
            Rect rect = new Rect(0f, 0f, position.width, HeaderHeight);
            EditorGUI.DrawRect(rect, HeaderColor);
            EditorGUI.DrawRect(new Rect(0f, HeaderHeight - 2f, position.width, 2f), AccentColor);

            int edits = _plan != null ? _plan.edits.Count : 0;
            int skips = _plan != null ? _plan.skips.Count : 0;

            GUI.Label(new Rect(18f, 14f, position.width - 36f, 24f), "Fix pass - preview", _titleStyle);
            GUI.Label(new Rect(18f, 40f, position.width - 36f, 18f),
                edits + " mechanical edit(s) ready. " + skips + " finding(s) need a decision and are listed with their remedy.",
                _subtitleStyle);
            GUI.Label(new Rect(18f, 58f, position.width - 36f, 18f),
                "Nothing is written until Apply. Review the diff below; review the commit after.",
                _subtitleStyle);

            GUILayout.Space(HeaderHeight + 6f);
        }

        private void DrawToolbar()
        {
            EditorGUILayout.BeginHorizontal();

            int edits = _plan != null ? _plan.edits.Count : 0;
            using (new EditorGUI.DisabledScope(edits == 0))
            {
                if (GUILayout.Button("Apply " + edits + " edit(s)", GUILayout.Height(26f), GUILayout.Width(160f)))
                {
                    ApplyPlan();
                }
            }

            if (GUILayout.Button("Close", GUILayout.Height(26f), GUILayout.Width(80f)))
            {
                Close();
            }

            GUILayout.FlexibleSpace();
            EditorGUILayout.EndHorizontal();
            GUILayout.Space(6f);
        }

        private void DrawEdits()
        {
            if (_plan == null || _plan.edits.Count == 0)
            {
                return;
            }

            string currentFile = string.Empty;
            for (int i = 0; i < _plan.edits.Count; i++)
            {
                FixEdit edit = _plan.edits[i];
                if (!string.Equals(edit.path, currentFile, StringComparison.Ordinal))
                {
                    currentFile = edit.path;
                    GUILayout.Space(8f);
                    GUILayout.Label(DisplayPath(currentFile), _fileStyle);
                }

                Rect card = EditorGUILayout.BeginVertical();
                EditorGUI.DrawRect(card, CardColor);
                GUILayout.Space(4f);

                GUILayout.Label("  " + edit.ruleId + "  ·  line " + edit.line +
                                (edit.kind == FixEditKind.InsertAbove ? "  ·  insert" : "  ·  replace"), _noteStyle);

                if (edit.kind == FixEditKind.ReplaceLine)
                {
                    DrawCodeLine("- " + edit.before.TrimStart(), BeforeColor);
                    DrawCodeLine("+ " + edit.after.TrimStart(), AfterColor);
                }
                else
                {
                    DrawCodeLine("+ " + edit.after.TrimStart(), AfterColor);
                    DrawCodeLine("  " + edit.before.TrimStart(), CardColor);
                }

                GUILayout.Label("  " + edit.note, _noteStyle);
                GUILayout.Space(4f);
                EditorGUILayout.EndVertical();
                GUILayout.Space(2f);
            }
        }

        private void DrawSkips()
        {
            if (_plan == null || _plan.skips.Count == 0)
            {
                return;
            }

            GUILayout.Space(14f);
            GUILayout.Label("Needs a decision - the remedy is the work, not the typing", _fileStyle);
            GUILayout.Space(2f);

            for (int i = 0; i < _plan.skips.Count; i++)
            {
                FixSkip skip = _plan.skips[i];
                Rect card = EditorGUILayout.BeginVertical();
                EditorGUI.DrawRect(card, SkipColor);
                GUILayout.Space(4f);
                GUILayout.Label("  " + skip.ruleId + "  ·  " + DisplayPath(skip.path) +
                                (skip.line > 0 ? ":" + skip.line : string.Empty), _noteStyle);
                GUILayout.Label("  " + skip.reason, _reasonStyle);
                GUILayout.Space(4f);
                EditorGUILayout.EndVertical();
                GUILayout.Space(2f);
            }
        }

        /// <summary>
        /// Shortens a path for display: rooted at <c>Assets/</c> when the file is in the project,
        /// otherwise the last two segments. The full path stays in the plan - this only trims what
        /// the row shows, because an absolute path wider than the window reads as noise.
        /// </summary>
        /// <param name="path">The plan's recorded path.</param>
        /// <returns>The display form.</returns>
        private static string DisplayPath(string path)
        {
            if (path == null || path.Length == 0)
            {
                return string.Empty;
            }

            string normalised = path.Replace('\\', '/');
            int assets = normalised.LastIndexOf("/Assets/", StringComparison.OrdinalIgnoreCase);
            if (assets >= 0)
            {
                return normalised.Substring(assets + 1);
            }

            int last = normalised.LastIndexOf('/');
            if (last <= 0)
            {
                return normalised;
            }

            int prev = normalised.LastIndexOf('/', last - 1);
            return normalised.Substring(prev + 1);
        }

        private void DrawCodeLine(string text, Color background)
        {
            Rect rect = GUILayoutUtility.GetRect(new GUIContent(text), _monoStyle, GUILayout.ExpandWidth(true));
            EditorGUI.DrawRect(rect, background);
            GUI.Label(rect, text, _monoStyle);
        }

        private void ApplyPlan()
        {
            if (_plan == null)
            {
                return;
            }

            FixResult result = FixEngine.Apply(_plan, _projectRoot);

            // The refresh is what makes the edit real inside the Editor - without it the imported
            // scripts and the files on disk disagree until something else triggers an import.
            AssetDatabase.Refresh();

            string summary = result.applied + " edit(s) applied across " + result.filesTouched + " file(s).";
            if (result.stale > 0)
            {
                summary += "\n" + result.stale + " edit(s) refused - the file changed since the plan was built. Re-scan and preview again.";
            }

            if (result.failures.Count > 0)
            {
                summary += "\n" + result.failures.Count + " file(s) could not be written:";
                for (int i = 0; i < result.failures.Count && i < 5; i++)
                {
                    summary += "\n  " + result.failures[i];
                }
            }

            EditorUtility.DisplayDialog("CoreCLR fix pass", summary, "OK");
            Debug.Log("[CSAF CoreCLR Scanner] Fix pass: " + summary.Replace("\n", " "));

            Action? callback = _onApplied;
            Close();
            if (callback != null)
            {
                callback();
            }
        }

        private void EnsureStyles()
        {
            if (_titleStyle != null)
            {
                return;
            }

            _titleStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 17,
                normal = { textColor = new Color(0.94f, 0.95f, 0.97f) }
            };

            _subtitleStyle = new GUIStyle(EditorStyles.label)
            {
                fontSize = 11,
                normal = { textColor = new Color(0.66f, 0.70f, 0.76f) }
            };

            _fileStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 12,
                normal = { textColor = new Color(0.62f, 0.78f, 0.94f) }
            };

            _monoStyle = new GUIStyle(EditorStyles.label)
            {
                font = EditorStyles.standardFont,
                fontSize = 11,
                normal = { textColor = new Color(0.88f, 0.90f, 0.93f) },
                padding = new RectOffset(10, 6, 1, 1)
            };

            _noteStyle = new GUIStyle(EditorStyles.label)
            {
                fontSize = 10,
                wordWrap = true,
                normal = { textColor = new Color(0.66f, 0.70f, 0.76f) }
            };

            _reasonStyle = new GUIStyle(EditorStyles.label)
            {
                fontSize = 10,
                wordWrap = true,
                normal = { textColor = new Color(0.85f, 0.76f, 0.55f) }
            };
        }
    }
}
