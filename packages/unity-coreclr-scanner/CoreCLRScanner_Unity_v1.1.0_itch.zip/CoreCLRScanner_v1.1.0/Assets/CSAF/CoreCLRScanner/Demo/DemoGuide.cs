// Copyright (c) 2026 CSAF (Corey Gallant and Stephanie Thomason). All rights reserved.
// CSAF CoreCLR Migration Scanner - demo scene guide.

// Nullable is enabled per file, not per project - see Editor/Model/MigrationModel.cs for why.
#nullable enable

using UnityEngine;

namespace CSAF.CoreCLRScanner.Demo
{
    /// <summary>
    /// On-screen instructions for the demo scene.
    /// </summary>
    /// <remarks>
    /// This exists because the product is an Editor tool with no runtime behaviour, and an Asset
    /// Store reviewer opens the demo scene and presses Play. A scene that does visibly nothing reads
    /// as a broken sample, so this draws the three steps that show what the tool does.
    /// </remarks>
    [AddComponentMenu("CSAF/CoreCLR Scanner Demo Guide")]
    public sealed class DemoGuide : MonoBehaviour
    {
        private const int Margin = 24;

        private static readonly string[] Steps =
        {
            "1.  Window  >  CSAF  >  CoreCLR Migration Scanner",
            "2.  Press 'Scan Project' to read every C# file and reflect over every compiled assembly,",
            "     including precompiled third-party DLLs that have no source to search.",
            "3.  Or run Tools > CSAF > Scan Bundled Sample to see findings from the sample files",
            "     shipped in Demo/SampleLegacyCode, which is deterministic even in a clean project.",
            string.Empty,
            "This tool covers what Unity's own Project Auditor does not: P/Invoke, serialization,",
            "assembly loading, reflection and threading. It deliberately does not duplicate Project",
            "Auditor's domain-reload or obsolete-API analysis - run both."
        };

        // Built lazily in EnsureStyles, which OnGUI calls before anything is drawn. Declared
        // non-nullable with `null!` so call sites do not each need a null check for a field that is
        // never observed null.
        private GUIStyle _headingStyle = null!;
        private GUIStyle _bodyStyle = null!;

        private void OnGUI()
        {
            EnsureStyles();

            GUI.Label(new Rect(Margin, Margin, Screen.width - (Margin * 2), 32),
                "CoreCLR Migration Scanner", _headingStyle);

            for (int i = 0; i < Steps.Length; i++)
            {
                GUI.Label(
                    new Rect(Margin, Margin + 44 + (i * 22), Screen.width - (Margin * 2), 22),
                    Steps[i],
                    _bodyStyle);
            }
        }

        private void EnsureStyles()
        {
            if (_headingStyle != null)
            {
                return;
            }

            _headingStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = 22,
                fontStyle = FontStyle.Bold
            };
            _headingStyle.normal.textColor = new Color(0.95f, 0.96f, 0.98f);

            _bodyStyle = new GUIStyle(GUI.skin.label) { fontSize = 13 };
            _bodyStyle.normal.textColor = new Color(0.78f, 0.82f, 0.88f);
        }
    }
}
