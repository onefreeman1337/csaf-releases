// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

using UnityEngine;

namespace CSAF.Ballast.Demo
{
    /// <summary>
    /// The demo specimen: a script that carries one of each kind of <c>Resources.Load</c> call site,
    /// so Ballast has something real to read the moment the package is imported.
    /// </summary>
    /// <remarks>
    /// <para>
    /// ⭐ <b>THIS FILE IS THE DEMO.</b> Ballast is an editor tool, so the useful thing a demo scene
    /// can do is give it real input. Press Play to read the summary below, then open
    /// <b>Window ▸ CSAF ▸ Ballast</b> and press <b>Survey</b>: the three call sites in THIS file are
    /// found, classified and cited back to you by file and line. That loop is the whole product.
    /// </para>
    /// <para>
    /// ⚠️ <b>IT IS ALSO THE ONLY RUNTIME SCRIPT IN THE PACKAGE, AND IT IS YOURS TO DELETE.</b> Every
    /// other line of Ballast compiles into an Editor-only assembly and adds nothing whatever to your
    /// build — which matters more here than in most packages, because a tool sold on removing build
    /// weight has no business adding any.
    /// </para>
    /// <para>
    /// ⚠️ The loads below are guarded and tolerate a null result, because this package deliberately
    /// ships NO <c>Resources</c> folder of its own. A build-size tool that shipped one would be
    /// contradicting itself on the buyer's disk.
    /// </para>
    /// </remarks>
    [AddComponentMenu("CSAF/Ballast Demo Specimen")]
    public sealed class BallastDemoSpecimen : MonoBehaviour
    {
        [Tooltip("Set at runtime by the demo, and used to build a PREFIXED load site below.")]
        [SerializeField] private string variantName = "sword";

        private string _note = string.Empty;

        private void Start()
        {
            // ── 1. A LITERAL site. Ballast resolves this to exactly one resource path, so the asset
            //       "demo/icons/anchor" would be reported IN USE and cited back to this line.
            Object literal = Resources.Load("demo/icons/anchor");

            // ── 2. A PREFIXED site. The constant part is known and the rest is not, so Ballast taints
            //       the folder "demo/icons" and reports everything in it WITHHELD -- it will not move
            //       an asset that a name computed at runtime could ask for.
            Object prefixed = Resources.Load("demo/icons/" + variantName);

            // ── 3. A LoadAll site, which claims a whole folder by design.
            Object[] all = Resources.LoadAll("demo/audio");

            _note = "literal " + (literal == null ? "miss" : "hit")
                  + ", prefixed " + (prefixed == null ? "miss" : "hit")
                  + ", loadAll " + (all == null ? 0 : all.Length);
        }

        private void OnGUI()
        {
            const float w = 560f, h = 232f;
            var r = new Rect(24f, 24f, w, h);
            GUI.Box(r, GUIContent.none);

            GUILayout.BeginArea(new Rect(r.x + 16f, r.y + 12f, r.width - 32f, r.height - 24f));
            GUILayout.Label("BALLAST — demo specimen");
            GUILayout.Space(6f);
            GUILayout.Label(
                "Unity strips unused assets from your build everywhere except one place: the "
                + "Resources folder. It cannot reason about that folder, because scripts ask for "
                + "those assets by name at runtime.");
            GUILayout.Space(6f);
            GUILayout.Label(
                "This script carries one of each kind of call site Ballast reads:\n"
                + "   1. a literal path            -> IN USE, cited by file and line\n"
                + "   2. a computed path           -> WITHHELD, never touched\n"
                + "   3. a LoadAll on a folder     -> WITHHELD, the whole subtree");
            GUILayout.Space(6f);
            GUILayout.Label("Open Window > CSAF > Ballast and press Survey to see it read this file.");
            if (_note.Length > 0) GUILayout.Label("Runtime load result: " + _note);
            GUILayout.EndArea();
        }
    }
}
