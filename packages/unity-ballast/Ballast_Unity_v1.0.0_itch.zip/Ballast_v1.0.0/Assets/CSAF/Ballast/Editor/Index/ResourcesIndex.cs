#nullable enable
// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

using System;
using System.Collections.Generic;
using System.IO;

namespace CSAF.Ballast
{
    /// <summary>One asset found under a <c>Resources</c> folder.</summary>
    public readonly struct ResourceEntry
    {
        /// <summary>Project-relative asset path, e.g. <c>Assets/Art/Resources/icons/sword.png</c>.</summary>
        public readonly string AssetPath;

        /// <summary>
        /// The path <c>Resources.Load</c> would be given, e.g. <c>icons/sword</c> — normalised, with
        /// no extension.
        /// </summary>
        public readonly string ResourcePath;

        /// <summary>The Resources folder that owns it, e.g. <c>Assets/Art/Resources</c>.</summary>
        public readonly string ResourcesFolder;

        /// <summary>Size on disk in bytes.</summary>
        public readonly long Bytes;

        public ResourceEntry(string? assetPath, string? resourcePath, string? folder, long bytes)
        {
            AssetPath = assetPath ?? string.Empty;
            ResourcePath = resourcePath ?? string.Empty;
            ResourcesFolder = folder ?? string.Empty;
            Bytes = bytes;
        }
    }

    /// <summary>
    /// Enumerates every <c>Resources</c> folder in a project and every asset in it, with real bytes.
    /// </summary>
    /// <remarks>
    /// <para>
    /// ⛔ <b>THE FOLDER TEST IS SEGMENT-WISE AND THAT IS NOT PEDANTRY.</b> Unity treats a directory
    /// named exactly <c>Resources</c> as special at ANY depth, and treats <c>ResourcesOld</c>,
    /// <c>MyResources</c> and <c>Resources_backup</c> as ordinary folders. A substring test would
    /// pull all three into the index, and every asset in them would then be classified against load
    /// sites that can never name them — producing a confident "unreached" verdict on assets that are
    /// not resources at all, and offering to migrate them. This wing has paid for the
    /// substring-versus-whole-token distinction twice before; here it decides whether the product
    /// moves the right files.
    /// </para>
    /// <para>
    /// ⚠️ <b>A NESTED <c>Resources</c> INSIDE A <c>Resources</c> IS NOT A SECOND ROOT.</b> Unity
    /// keys the resource path off the FIRST <c>Resources</c> segment, so
    /// <c>Assets/A/Resources/Resources/x.png</c> loads as <c>Resources/x</c>, not as <c>x</c>. Taking
    /// the last segment instead would compute a resource path no load site can match and report the
    /// asset unreached. The index therefore splits on the first occurrence, and a test fixes it.
    /// </para>
    /// <para>
    /// ⚠️ <b>EDITOR AND PLUGIN SUBTREES ARE EXCLUDED BECAUSE UNITY EXCLUDES THEM.</b> A
    /// <c>Resources</c> folder under an <c>Editor</c> folder is editor-only content and is not in the
    /// player build at all, so listing its bytes as displaceable build weight would inflate the one
    /// figure this product is sold on.
    /// </para>
    /// </remarks>
    public static class ResourcesIndex
    {
        /// <summary>The folder name Unity treats as special.</summary>
        public const string FolderName = "Resources";

        /// <summary>
        /// Files that are project metadata rather than shipped content, and are never counted.
        /// </summary>
        private static readonly string[] IgnoredExtensions = { ".meta", ".ds_store", ".gitkeep", ".gitignore" };

        /// <summary>
        /// Walks a project's Assets tree and returns every resource asset.
        /// </summary>
        /// <param name="assetsRoot">Absolute path of the project's <c>Assets</c> folder.</param>
        /// <returns>Every asset under every player-facing Resources folder.</returns>
        /// <remarks>
        /// Takes a root rather than calling <c>AssetDatabase</c> so the whole indexer is testable in
        /// EditMode against a temporary directory. This wing has measured that a component reachable
        /// only through the engine gets asserted about instead of exercised.
        /// </remarks>
        public static List<ResourceEntry> Build(string? assetsRoot)
        {
            var results = new List<ResourceEntry>();
            if (assetsRoot == null || assetsRoot.Length == 0) return results;
            if (!Directory.Exists(assetsRoot)) return results;

            string root = assetsRoot.Replace('\\', '/').TrimEnd('/');
            string projectRoot = ParentOf(root);

            foreach (string dir in Directory.GetDirectories(root, FolderName, SearchOption.AllDirectories))
            {
                string folder = dir.Replace('\\', '/');
                string rel = Relative(projectRoot, folder);
                if (!IsPlayerFacingResourcesFolder(rel)) continue;
                if (IsNestedInsideAnotherResources(rel)) continue;

                foreach (string file in Directory.GetFiles(folder, "*", SearchOption.AllDirectories))
                {
                    string f = file.Replace('\\', '/');
                    if (IsIgnored(f)) continue;

                    string assetRel = Relative(projectRoot, f);
                    string inFolder = assetRel.Substring(rel.Length).TrimStart('/');
                    string resourcePath = LoadSiteScanner.NormalisePath(inFolder);

                    long bytes;
                    try { bytes = new FileInfo(f).Length; }
                    catch (IOException) { continue; }
                    catch (UnauthorizedAccessException) { continue; }

                    results.Add(new ResourceEntry(assetRel, resourcePath, rel, bytes));
                }
            }

            results.Sort((a, b) => string.CompareOrdinal(a.AssetPath, b.AssetPath));
            return results;
        }

        /// <summary>
        /// True when a project-relative folder path is a <c>Resources</c> folder whose contents go
        /// into the player build.
        /// </summary>
        /// <param name="relativeFolder">Project-relative folder path, forward slashes.</param>
        /// <returns>Whether the folder is player-facing resources.</returns>
        public static bool IsPlayerFacingResourcesFolder(string? relativeFolder)
        {
            if (relativeFolder == null || relativeFolder.Length == 0) return false;
            string[] parts = relativeFolder.Split('/');
            if (parts.Length == 0) return false;

            // The LAST segment must be exactly "Resources" -- segment-wise, never a substring.
            if (!string.Equals(parts[parts.Length - 1], FolderName, StringComparison.Ordinal)) return false;

            // ⛔ NEVER SURVEY BALLAST'S OWN QUARANTINE. This is defence in depth behind
            // Migrator.QuarantinedResourcesName, which already renames the Resources segment so
            // Unity itself stops shipping a migrated asset. Without that rename the tool re-indexed
            // everything it had just moved and reported the project's tonnage UNCHANGED after a
            // migration -- measured on the first fresh install. Both guards are kept: the rename is
            // what makes the migration WORK, and this is what keeps the tool's own bookkeeping out
            // of the buyer's figures if anything is ever placed there by hand.
            if (relativeFolder.StartsWith(Migrator.QuarantineRoot + "/", StringComparison.OrdinalIgnoreCase)
                || string.Equals(relativeFolder, Migrator.QuarantineRoot, StringComparison.OrdinalIgnoreCase))
                return false;

            // Anything under an Editor or a plugin-local editor folder is not in the player build.
            for (int i = 0; i < parts.Length - 1; i++)
            {
                if (string.Equals(parts[i], "Editor", StringComparison.Ordinal)) return false;
                if (string.Equals(parts[i], "Editor Default Resources", StringComparison.Ordinal)) return false;
            }
            return true;
        }

        /// <summary>
        /// True when this Resources folder is itself inside another Resources folder, in which case
        /// it is not a root and its assets belong to the outer one.
        /// </summary>
        /// <param name="relativeFolder">Project-relative folder path, forward slashes.</param>
        /// <returns>Whether an outer Resources folder already owns it.</returns>
        public static bool IsNestedInsideAnotherResources(string? relativeFolder)
        {
            if (relativeFolder == null) return false;
            string[] parts = relativeFolder.Split('/');
            int seen = 0;
            foreach (string s in parts)
                if (string.Equals(s, FolderName, StringComparison.Ordinal)) seen++;
            return seen > 1;
        }

        /// <summary>
        /// The Resources folder that owns an asset path, or empty when none does.
        /// </summary>
        /// <param name="assetPath">Project-relative asset path.</param>
        /// <returns>The owning folder path.</returns>
        /// <remarks>
        /// Splits on the FIRST <c>Resources</c> segment, matching Unity's own rule. Injected into
        /// <see cref="Lading.GroupRows"/> so the certificate's grouping and the index agree by
        /// construction rather than by care.
        /// </remarks>
        public static string FolderOf(string? assetPath)
        {
            if (assetPath == null || assetPath.Length == 0) return string.Empty;
            string[] parts = assetPath.Replace('\\', '/').Split('/');
            for (int i = 0; i < parts.Length; i++)
            {
                if (!string.Equals(parts[i], FolderName, StringComparison.Ordinal)) continue;
                return string.Join("/", parts, 0, i + 1);
            }
            return string.Empty;
        }

        private static bool IsIgnored(string file)
        {
            string lower = file.ToLowerInvariant();
            foreach (string ext in IgnoredExtensions)
                if (lower.EndsWith(ext, StringComparison.Ordinal)) return true;
            return false;
        }

        private static string ParentOf(string dir)
        {
            int i = dir.LastIndexOf('/');
            return i < 0 ? dir : dir.Substring(0, i);
        }

        private static string Relative(string root, string full)
        {
            if (full.Length > root.Length && full.StartsWith(root, StringComparison.OrdinalIgnoreCase))
                return full.Substring(root.Length).TrimStart('/');
            return full;
        }
    }
}
