// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.
#nullable enable

using UnityEngine;

namespace CSAF.Ballast
{
    /// <summary>Where a struck line sits relative to the point it is struck at.</summary>
    public enum Align
    {
        /// <summary>The point is the left end of the line.</summary>
        Left = 0,

        /// <summary>The point is the centre of the line.</summary>
        Centre = 1,

        /// <summary>The point is the right end of the line.</summary>
        Right = 2,
    }

    /// <summary>
    /// Sets a line of <see cref="Letterforms"/> onto an <see cref="Ink"/> surface.
    /// </summary>
    /// <remarks>
    /// <para>
    /// ⛔ <b>EVERY STRIKE PASSES A BOUNDS RECTANGLE, AND THAT IS NOT AN OPTIMISATION.</b>
    /// <see cref="Ink.Fill"/> with no bounds walks the WHOLE surface, so a 1100x1500 certificate at
    /// 2x supersampling costs 6.6 million samples per call — per LETTER. A certificate carries well
    /// over a thousand characters once the folder rows and their tonnages are set, so unbounded
    /// strikes would evaluate billions of spine distances and the plate would never finish. With
    /// per-letter bounds each letter touches only the pixels it can reach. The wing has already
    /// shipped a six-second page to exactly this cause.
    /// </para>
    /// <para>
    /// ⚠️ <b>THE ORIGIN IS RESTORED HERE AND NOWHERE ELSE.</b> <see cref="Ink.SetOrigin"/> is
    /// sticky and has no getter, so a caller that forgets to reset it silently displaces every later
    /// primitive on the plate — a defect that looks like a layout bug in a completely different file.
    /// Every method in this class that moves the origin restores it before returning, and no other
    /// file in the package touches the origin at all.
    /// </para>
    /// <para>
    /// ⭐ <b>REFUSAL IS A FEATURE.</b> <see cref="CanStrike"/> is checked BEFORE anything is drawn, so
    /// a title the face cannot set leaves an empty rect the buyer can draw into rather than a row of
    /// placeholder boxes on an image a player is about to post. See <see cref="Letterforms"/> for why
    /// the two alternatives are both worse.
    /// </para>
    /// </remarks>
    public static class TypeSetter
    {
        /// <summary>Extra space between glyphs, as a fraction of the em.</summary>
        /// <remarks>
        /// Positive by default because this is a DISPLAY face used at small sizes on a busy plate,
        /// and the first thing that fails there is letters touching. It is a parameter on every entry
        /// point so a title can be tracked wider than a stat label.
        /// </remarks>
        public const float DefaultTracking = 0.06f;

        /// <summary>Whether every character of a string can be struck, after folding.</summary>
        /// <param name="s">The string.</param>
        /// <returns>True when the whole string is strikeable. An empty or null string is NOT.</returns>
        /// <remarks>
        /// ⚠️ Null and empty return FALSE rather than true. "Vacuously strikeable" is the reading that
        /// makes a caller draw nothing and record a success, which is the shape master §2b calls a
        /// green from work that never happened — an absent title and a Cyrillic one should both leave
        /// the rect to the buyer.
        /// </remarks>
        public static bool CanStrike(string? s)
        {
            if (string.IsNullOrEmpty(s)) return false;
            for (int i = 0; i < s!.Length; i++)
                if (Letterforms.Get(Letterforms.Fold(s[i])) == null) return false;
            return true;
        }

        /// <summary>The first character of a string the face cannot strike, or nul.</summary>
        /// <param name="s">The string.</param>
        /// <returns>The offending character, or '\0'.</returns>
        /// <remarks>Exists so the Editor window can say WHICH character refused a field.</remarks>
        public static char FirstUnstrikeable(string? s)
        {
            if (string.IsNullOrEmpty(s)) return '\0';
            for (int i = 0; i < s!.Length; i++)
            {
                char f = Letterforms.Fold(s[i]);
                if (Letterforms.Get(f) == null) return s[i];
            }
            return '\0';
        }

        /// <summary>The width one line would occupy, in normalised surface units.</summary>
        /// <param name="s">The string.</param>
        /// <param name="em">Cap height in normalised units.</param>
        /// <param name="tracking">Extra space between glyphs, as a fraction of the em.</param>
        /// <returns>The width, or 0 when nothing would be struck.</returns>
        public static float Measure(string? s, float em, float tracking = DefaultTracking)
        {
            if (string.IsNullOrEmpty(s)) return 0f;
            float w = 0f;
            int struck = 0;
            for (int i = 0; i < s!.Length; i++)
            {
                Letterforms.Glyph? g = Letterforms.Get(Letterforms.Fold(s[i]));
                if (g == null) continue;
                w += g.Advance + tracking;
                struck++;
            }
            // The trailing tracking is not part of the line: leaving it in would make a centred line
            // sit half a tracking unit to the left of where it should, on every plate.
            return struck == 0 ? 0f : (w - tracking) * em;
        }

        /// <summary>
        /// Shortens a line until it fits, marking the cut with an ellipsis.
        /// </summary>
        /// <param name="s">The string.</param>
        /// <param name="maxWidth">The width available, in normalised units.</param>
        /// <param name="em">Cap height.</param>
        /// <param name="tracking">Tracking.</param>
        /// <returns>The original string when it fits, a shortened one when it does not.</returns>
        /// <remarks>
        /// <para>
        /// ⛔ <b>A FOLDER PATH IS BUYER DATA AND CAN BE ANY LENGTH.</b> Left alone, a deeply nested
        /// <c>Assets/Vendor/ThirdParty/Kits/UI/Resources/atlases</c> set at the row size is wider
        /// than the certificate — it does not wrap, it does not error, it runs straight through the
        /// tonnage column and off the edge, and the only sign is that the plate looks wrong. Callers
        /// shrink the em first, because a slightly smaller path is better than a cut one; this is the
        /// floor under that.
        /// </para>
        /// <para>
        /// ⚠️ The ellipsis is three PERIODS, not U+2026. The face carries a period; it does not carry
        /// the typographic ellipsis, so appending one would make the very function that exists to
        /// keep a title strikeable return a string that <see cref="CanStrike"/> refuses.
        /// </para>
        /// </remarks>
        public static string? Shorten(string? s, float maxWidth, float em, float tracking = DefaultTracking)
        {
            if (string.IsNullOrEmpty(s) || maxWidth <= 0f) return s;
            if (Measure(s, em, tracking) <= maxWidth) return s;

            const string tail = "...";
            float tailWidth = Measure(tail, em, tracking);
            for (int keep = s!.Length - 1; keep > 0; keep--)
            {
                string head = s.Substring(0, keep).TrimEnd();
                if (Measure(head, em, tracking) + tailWidth <= maxWidth) return head + tail;
            }
            return tail;
        }

        /// <summary>
        /// The largest cap height at or below <paramref name="em"/> at which a line fits.
        /// </summary>
        /// <param name="s">The string.</param>
        /// <param name="maxWidth">The width available.</param>
        /// <param name="em">The preferred cap height.</param>
        /// <param name="minEm">The smallest acceptable cap height.</param>
        /// <param name="tracking">Tracking.</param>
        /// <returns>A cap height in [minEm, em].</returns>
        /// <remarks>
        /// Closed form rather than a search: width is exactly linear in the em, so the ratio IS the
        /// answer and a loop would only add a way to be off by one step.
        /// </remarks>
        public static float FitEm(string? s, float maxWidth, float em, float minEm,
                                  float tracking = DefaultTracking)
        {
            if (string.IsNullOrEmpty(s) || maxWidth <= 0f) return em;
            float w = Measure(s, em, tracking);
            if (w <= maxWidth || w <= 0f) return em;
            return Mathf.Max(minEm, em * (maxWidth / w));
        }

        /// <summary>
        /// Strikes one line onto the surface, with its BASELINE at <paramref name="y"/>.
        /// </summary>
        /// <param name="ink">The surface.</param>
        /// <param name="s">The string.</param>
        /// <param name="x">Anchor U, interpreted per <paramref name="align"/>.</param>
        /// <param name="y">Baseline V.</param>
        /// <param name="em">Cap height in normalised units.</param>
        /// <param name="colour">Ink colour.</param>
        /// <param name="align">Where the anchor sits on the line.</param>
        /// <param name="tracking">Extra space between glyphs, as a fraction of the em.</param>
        /// <returns>The width struck, or 0 when the string was refused.</returns>
        /// <remarks>
        /// ⛔ THE WHOLE LINE IS REFUSED OR THE WHOLE LINE IS STRUCK. Striking the strikeable
        /// characters and skipping the rest would print a misspelling — "TOKYO RUN" losing a
        /// character is worse than printing nothing, because nothing is visibly missing and a
        /// misspelling is not.
        /// </remarks>
        public static float Strike(Ink ink, string? s, float x, float y, float em, in Color colour,
                                   Align align = Align.Left, float tracking = DefaultTracking)
        {
            if (ink == null || !CanStrike(s)) return 0f;

            float width = Measure(s, em, tracking);
            float pen = align switch
            {
                Align.Centre => x - width * 0.5f,
                Align.Right => x - width,
                _ => x,
            };

            for (int i = 0; i < s!.Length; i++)
            {
                Letterforms.Glyph g = Letterforms.Get(Letterforms.Fold(s[i]))!;
                if (g.Strokes.Length > 0)
                {
                    // The glyph is authored in a unit em with its baseline at v = 0. Dividing the
                    // sample by `em` maps the surface into that frame; multiplying the returned
                    // distance by `em` maps it back, which keeps the result a true signed distance in
                    // surface units so the antialiasing width is right at every size.
                    Letterforms.Glyph gg = g;
                    float e = em;
                    ink.SetOrigin(pen, y);
                    Vector4 x0 = gg.Extents;
                    ink.Fill((u, v) => gg.Distance(u / e, v / e) * e, colour,
                             new Vector4(x0.x * e, x0.y * e, x0.z * e, x0.w * e));
                    ink.SetOrigin(0f, 0f);
                }
                pen += (g.Advance + tracking) * em;
            }

            return width;
        }
    }
}
