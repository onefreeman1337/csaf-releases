#nullable enable
// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

using System;

namespace CSAF.Ballast
{
    /// <summary>
    /// How precisely a single <c>Resources.Load</c> call site names what it loads.
    /// </summary>
    /// <remarks>
    /// This enum is the whole safety model of the product, so it is ordered by how much of the
    /// Resources tree a site can reach: <see cref="Literal"/> reaches exactly one path,
    /// <see cref="Prefixed"/> reaches a subtree, <see cref="Opaque"/> reaches everything.
    /// <para>
    /// ⛔ THE ASYMMETRY THAT GOVERNS EVERY DECISION IN THIS FILE. Classifying a site as reaching
    /// MORE than it really does costs the buyer some unmigrated bytes. Classifying it as reaching
    /// LESS than it really does moves a live asset out of the buyer's build, and they find out when
    /// a player reaches that code path. Those costs are not comparable, so every ambiguity in the
    /// scanner resolves toward <see cref="Opaque"/>. A parse this scanner is unsure about is not a
    /// parse it guesses at.
    /// </para>
    /// </remarks>
    public enum LoadPrecision
    {
        /// <summary>
        /// The argument is a compile-time string constant, so the site reaches exactly one resource
        /// path. Example: <c>Resources.Load("icons/sword")</c>.
        /// </summary>
        Literal = 0,

        /// <summary>
        /// The argument begins with a known constant prefix and continues with something this
        /// scanner cannot evaluate, so the site reaches an unknown member of a known subtree.
        /// Examples: <c>Resources.Load("icons/" + slug)</c>, <c>Resources.Load($"icons/{slug}")</c>,
        /// and <c>Resources.LoadAll("icons")</c> — which names a folder by design.
        /// </summary>
        Prefixed = 1,

        /// <summary>
        /// The argument carries no evaluable prefix, so the site can reach ANY resource path.
        /// Example: <c>Resources.Load(pathFromConfig)</c>.
        /// </summary>
        /// <remarks>
        /// One opaque site anywhere in the project makes the entire Resources tree indeterminate and
        /// Ballast will migrate nothing until the buyer narrows it. That is a correct answer, and
        /// the window presents it as one rather than as a failure.
        /// </remarks>
        Opaque = 2,
    }

    /// <summary>
    /// One <c>Resources.Load*</c> call found in the project's own C#, with the evidence needed to
    /// show the buyer why a verdict was reached.
    /// </summary>
    /// <remarks>
    /// ⚠️ The citation fields (<see cref="File"/>, <see cref="Line"/>, <see cref="Snippet"/>) are
    /// not decoration. A verdict with no citation is a reporter's output — the buyer cannot audit it,
    /// and this product asks them to let it move files. Every `Reached` verdict in the UI names the
    /// file and line that reached it.
    /// </remarks>
    public readonly struct LoadSite
    {
        /// <summary>Project-relative path of the C# file containing the call.</summary>
        public readonly string File;

        /// <summary>1-based line number of the call.</summary>
        public readonly int Line;

        /// <summary>
        /// The resource path for a <see cref="LoadPrecision.Literal"/> site, or the known leading
        /// portion for a <see cref="LoadPrecision.Prefixed"/> site. Empty for
        /// <see cref="LoadPrecision.Opaque"/>.
        /// </summary>
        /// <remarks>
        /// Always normalised the way <c>Resources.Load</c> itself treats paths: forward slashes, no
        /// leading slash, no file extension. Unity ignores the extension in a resource path, so
        /// "icons/sword.png" and "icons/sword" are the same request and must compare equal here.
        /// </remarks>
        public readonly string Path;

        /// <summary>How precisely <see cref="Path"/> names what this site loads.</summary>
        public readonly LoadPrecision Precision;

        /// <summary>
        /// True when the call is a <c>LoadAll</c>, which claims a whole folder rather than one
        /// asset even though its argument is a plain literal.
        /// </summary>
        public readonly bool IsLoadAll;

        /// <summary>The source text of the call, trimmed, for display in the ledger.</summary>
        public readonly string Snippet;

        // Parameters are nullable-annotated because they are defensively defaulted below. Declaring
        // them non-nullable and then writing `?? string.Empty` is the shape that reads as a null
        // check while the compiler treats it as dead code.
        public LoadSite(string? file, int line, string? path, LoadPrecision precision, bool isLoadAll, string? snippet)
        {
            File = file ?? string.Empty;
            Line = line;
            Path = path ?? string.Empty;
            Precision = precision;
            IsLoadAll = isLoadAll;
            Snippet = snippet ?? string.Empty;
        }

        /// <summary>
        /// True when this site could load the resource at <paramref name="resourcePath"/>.
        /// </summary>
        /// <remarks>
        /// ⚠️ Deliberately answers TRUE whenever it is not certain of the answer, per the asymmetry
        /// documented on <see cref="LoadPrecision"/>.
        /// <para>
        /// ⛔ The prefix test is on a PATH-SEGMENT boundary, not a raw string prefix. A raw
        /// <c>StartsWith("icons")</c> would let the folder "icons" claim the sibling folder
        /// "icons_old", quietly protecting assets nobody can reach — and, far worse, the same bug in
        /// a subtraction elsewhere would expose ones somebody can. This wing has paid for the
        /// substring-versus-whole-word distinction twice (`charcoal` claiming `coal`, and
        /// `ifont-star` prefixing `ifont-star-outline`), so it is written explicitly here.
        /// </para>
        /// </remarks>
        public bool CouldReach(string? resourcePath)
        {
            if (resourcePath == null) return true;   // unknown input -> assume reachable

            switch (Precision)
            {
                case LoadPrecision.Opaque:
                    return true;

                case LoadPrecision.Literal:
                    if (IsLoadAll) return IsWithinFolder(resourcePath, Path);
                    return string.Equals(resourcePath, Path, StringComparison.OrdinalIgnoreCase);

                case LoadPrecision.Prefixed:
                    // An empty known prefix means we learned nothing; treat as opaque.
                    if (Path.Length == 0) return true;
                    return IsWithinFolder(resourcePath, Path)
                           || string.Equals(resourcePath, Path, StringComparison.OrdinalIgnoreCase);

                default:
                    return true;
            }
        }

        /// <summary>
        /// True when <paramref name="candidate"/> lies inside the folder <paramref name="folder"/>,
        /// compared segment-wise. An empty folder means the Resources root, which contains
        /// everything.
        /// </summary>
        public static bool IsWithinFolder(string? candidate, string? folder)
        {
            // ⚠️ Written as an explicit null test rather than string.IsNullOrEmpty, because Unity's
            // runtime does not carry the [NotNullWhen(false)] annotation that would let the compiler
            // narrow through it — so `folder.Length` below would be CS8602 under -warnaserror. This
            // wing's checklist states the rule; it is repeated here because the tempting spelling is
            // the one that fails, and it fails a long way from where it is written.
            if (folder == null || folder.Length == 0) return true;
            if (candidate == null) return true;
            if (candidate.Length <= folder.Length) return false;
            if (!candidate.StartsWith(folder, StringComparison.OrdinalIgnoreCase)) return false;

            // The character after the prefix must be a separator, or "icons" would claim
            // "icons_old". This single check is the whole-word rule for paths.
            return candidate[folder.Length] == '/';
        }
    }
}
