#nullable enable
// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

using System;
using UnityEngine;

namespace CSAF.Ballast
{
    /// <summary>How a primitive combines with what is already on the surface.</summary>
    public enum InkBlend
    {
        /// <summary>Ordinary source-over alpha compositing.</summary>
        Over = 0,

        /// <summary>Adds light. This is what makes an ember aura read as emitted rather than painted.</summary>
        Add = 1,

        /// <summary>Keeps the brighter of the two. Used to lay a corona under a core without a seam.</summary>
        Max = 2,
    }

    /// <summary>
    /// A supersampled software rasteriser for one tile. Every attribute glyph, crest charge, shield
    /// field, sheet frame and rule in this product is drawn through this class —
    /// there is no sprite atlas, no imported texture and no shader anywhere in the art path.
    /// </summary>
    /// <remarks>
    /// <para>
    /// WHY SOFTWARE AND NOT A SHADER. Three product properties, not preferences. It is
    /// <b>render-pipeline agnostic</b>, so one package is correct on Built-in, URP, HDRP and any
    /// custom pipeline with no variants to maintain. It is <b>deterministic</b>, so the same stat
    /// block yields byte-identical art on every machine and the test suite can assert on pixels. And
    /// it runs <b>headlessly with no graphics device</b>, which is what lets the whole art path be
    /// verified in batch mode rather than eyeballed.
    /// </para>
    /// <para>
    /// WHY A TILE AND NOT THE WHOLE PAGE. Supersampling costs memory quadratically: a full sheet
    /// at 4x would allocate hundreds of megabytes of float accumulators. Glyphs are therefore
    /// drawn into small tiles at full supersample and stamped into <c>SheetCanvas</c>, which
    /// composites at 1:1 and antialiases its own long rules analytically. That split is also what
    /// lets one glyph render at 48 px in a trait strip and at 320 px on a hero plate from the same
    /// code path.
    /// </para>
    /// <para>
    /// Coordinates are normalised with +Y up. Y always spans [-1,1]; X spans [-<see cref="Aspect"/>,
    /// <see cref="Aspect"/>], which is [-1,1] for the square tiles the glyph corpus uses. The
    /// mapping is exactly isotropic in both axes, so a circle is a circle on a wide rank bar.
    /// </para>
    /// </remarks>
    public sealed class Ink
    {
        /// <summary>Default linear supersampling factor. 4 gives 16 samples per output pixel.</summary>
        public const int SuperSample = 4;

        private readonly int _w;
        private readonly int _h;
        private readonly float[] _r;
        private readonly float[] _g;
        private readonly float[] _b;
        private readonly float[] _a;

        /// <summary>Width of the final (downsampled) tile in pixels.</summary>
        public int Width { get; }

        /// <summary>Height of the final (downsampled) tile in pixels.</summary>
        public int Height { get; }

        /// <summary>Edge length of a square tile. Equal to <see cref="Height"/>.</summary>
        public int Size => Height;

        /// <summary>
        /// Half-width of the normalised X domain. 1 for a square tile, greater than 1 for a wide one.
        /// </summary>
        public float Aspect { get; }

        /// <summary>
        /// This surface's own linear supersampling factor.
        /// </summary>
        /// <remarks>
        /// ⛔ THIS IS PER-SURFACE BECAUSE THE PAGE CANNOT AFFORD THE TILE'S SETTING, AND THE FIGURE IS
        /// ARITHMETIC RATHER THAN TASTE. The buffer is four <c>float</c> channels per SUBSAMPLE, so
        /// one output pixel costs <c>16 × s²</c> bytes. At <c>s = 4</c> that is <b>256 bytes per
        /// pixel</b>: a 1200×900 chart page would allocate <b>276 MB</b> before a single line is
        /// drawn, and a buyer composing two charts would be looking at half a gigabyte of managed
        /// float arrays. At <c>s = 2</c> the same page costs 69 MB, and at <c>s = 1</c>, 17 MB.
        /// <para>
        /// ✅ Dropping it costs far less quality than it looks like it should, because
        /// <see cref="Fill"/> computes coverage ANALYTICALLY from the signed distance — supersampling
        /// refines that estimate, it is not what produces the antialiasing. It matters most where a
        /// shape's distance field is not unit-gradient (an implicit surface rather than a true SDF)
        /// or where many edges cross one pixel, which is the small dense glyph case. Hence the split:
        /// <b>glyph tiles keep 4; the page ground, its bands and its border take 2.</b>
        /// </para>
        /// <para>
        /// ⚠️ It is a property, not a constant, so a caller that reasons about cost reads the real
        /// number off the surface it holds. <see cref="SuperSample"/> remains the default so every
        /// existing call site is unchanged.
        /// </para>
        /// </remarks>
        public int Samples { get; }

        /// <summary>Creates a square drawing surface that resolves to <paramref name="size"/> pixels.</summary>
        /// <param name="size">Output edge length in pixels. Must be positive.</param>
        public Ink(int size) : this(size, size) { }

        /// <summary>Creates a drawing surface of the given pixel dimensions.</summary>
        /// <param name="width">Output width in pixels. Must be positive.</param>
        /// <param name="height">Output height in pixels. Must be positive.</param>
        /// <param name="superSample">Linear supersampling factor; must be at least 1.</param>
        public Ink(int width, int height, int superSample = SuperSample)
        {
            if (width <= 0) throw new ArgumentOutOfRangeException(nameof(width), "width must be positive");
            if (height <= 0) throw new ArgumentOutOfRangeException(nameof(height), "height must be positive");
            if (superSample < 1)
                throw new ArgumentOutOfRangeException(nameof(superSample), "superSample must be at least 1");
            Width = width;
            Height = height;
            Samples = superSample;
            _w = width * superSample;
            _h = height * superSample;
            // Defined off (n-1) rather than n so that the per-unit scale in X is exactly the per-unit
            // scale in Y. Using the raw pixel ratio leaves a sub-pixel anisotropy that is invisible on
            // a square tile and visibly ovals a roundel on a 6:1 rank bar.
            Aspect = _h <= superSample ? 1f : (_w - 1) / (float)(_h - 1);
            int n = _w * _h;
            _r = new float[n];
            _g = new float[n];
            _b = new float[n];
            _a = new float[n];
        }

        // ---------------------------------------------------------------- coordinate mapping

        private float _originX;
        private float _originY;

        /// <summary>Shifts every subsequent primitive by this offset, in normalised units.</summary>
        /// <remarks>
        /// This exists for exactly one reason: drawing a form twice, once displaced, is what seats a
        /// drop shadow or a paired horn. Without an origin the second pass lands under the first and
        /// is completely covered — a full rasterisation that changes no pixel, which is a
        /// green-looking no-op of precisely the kind this factory keeps paying for.
        /// </remarks>
        /// <param name="x">Normalised X offset.</param>
        /// <param name="y">Normalised Y offset.</param>
        public void SetOrigin(float x, float y)
        {
            _originX = x;
            _originY = y;
        }

        /// <summary>
        /// The tile's own edges (minX, minY, maxX, maxY), expressed in the coordinate frame the
        /// current origin defines.
        /// </summary>
        /// <remarks>
        /// ⚠️ IT IS ORIGIN-RELATIVE ON PURPOSE, because everything that reads it is working in that
        /// same shifted frame. In this package that is <see cref="Certificate"/>, which moves the
        /// origin per band and then bounds its fills — comparing a shifted rectangle against the
        /// unshifted tile is the mistake this property exists to make impossible, since it would
        /// clip a bar purely because the composer had moved to the row that draws it.
        /// </remarks>
        public Vector4 TileBounds =>
            new Vector4(-Aspect - _originX, -1f - _originY, Aspect - _originX, 1f - _originY);

        private float Px(float x) => (x / Aspect + 1f) * 0.5f * (_w - 1);

        /// <summary>Maps a normalised Y in [-1,1] to a supersampled row. +Y is up, so this flips.</summary>
        private float Py(float y) => (1f - (y + 1f) * 0.5f) * (_h - 1);

        private float Scale => (_h - 1) * 0.5f;

        // ---------------------------------------------------------------- compositing

        private void Blend(int ix, int iy, in Color c, float coverage, InkBlend mode)
        {
            if (coverage <= 0f) return;
            if (ix < 0 || iy < 0 || ix >= _w || iy >= _h) return;
            float sa = c.a * coverage;
            if (sa <= 0f) return;
            int i = iy * _w + ix;

            switch (mode)
            {
                case InkBlend.Add:
                    _r[i] += c.r * sa;
                    _g[i] += c.g * sa;
                    _b[i] += c.b * sa;
                    _a[i] = sa + _a[i] * (1f - sa);
                    break;

                case InkBlend.Max:
                    if (c.r * sa > _r[i]) _r[i] = c.r * sa;
                    if (c.g * sa > _g[i]) _g[i] = c.g * sa;
                    if (c.b * sa > _b[i]) _b[i] = c.b * sa;
                    if (sa > _a[i]) _a[i] = sa;
                    break;

                default:
                    float inv = 1f - sa;
                    _r[i] = c.r * sa + _r[i] * inv;
                    _g[i] = c.g * sa + _g[i] * inv;
                    _b[i] = c.b * sa + _b[i] * inv;
                    _a[i] = sa + _a[i] * inv;
                    break;
            }
        }

        // ---------------------------------------------------------------- primitives

        /// <summary>Fills the entire surface with a colour.</summary>
        /// <param name="c">The colour to write. Replaces, it does not composite.</param>
        public void Clear(in Color c)
        {
            for (int i = 0; i < _r.Length; i++)
            {
                _r[i] = c.r; _g[i] = c.g; _b[i] = c.b; _a[i] = c.a;
            }
        }

        /// <summary>
        /// Fills the region where <paramref name="signedDistance"/> is negative, in normalised space.
        /// Every hard-edged shape in the corpus is written in terms of this one primitive.
        /// </summary>
        /// <param name="signedDistance">Negative inside, positive outside, in normalised units.</param>
        /// <param name="c">Colour to composite.</param>
        /// <param name="bounds">Optional normalised bounds (minX, minY, maxX, maxY) to limit work.</param>
        /// <param name="mode">Blend mode.</param>
        public void Fill(Func<float, float, float> signedDistance, in Color c,
                         Vector4? bounds = null, InkBlend mode = InkBlend.Over)
        {
            if (signedDistance == null) throw new ArgumentNullException(nameof(signedDistance));

            int x0 = 0, y0 = 0, x1 = _w - 1, y1 = _h - 1;
            if (bounds.HasValue)
            {
                Vector4 bb = bounds.Value;
                // Pad by two supersampled pixels so an antialiased edge is never clipped.
                x0 = Mathf.Max(0, Mathf.FloorToInt(Px(bb.x + _originX)) - 2);
                x1 = Mathf.Min(_w - 1, Mathf.CeilToInt(Px(bb.z + _originX)) + 2);
                // Y flips in Py, so the normalised max maps to the smaller row index.
                y0 = Mathf.Max(0, Mathf.FloorToInt(Py(bb.w + _originY)) - 2);
                y1 = Mathf.Min(_h - 1, Mathf.CeilToInt(Py(bb.y + _originY)) + 2);
            }

            float invScale = 1f / Scale;
            for (int iy = y0; iy <= y1; iy++)
            {
                float ny = 1f - 2f * (iy / (float)(_h - 1)) - _originY;
                for (int ix = x0; ix <= x1; ix++)
                {
                    float nx = (2f * (ix / (float)(_w - 1)) - 1f) * Aspect - _originX;
                    float d = signedDistance(nx, ny);
                    if (d >= invScale) continue;
                    float cov = d <= -invScale ? 1f : Mathf.Clamp01(0.5f - d * Scale * 0.5f);
                    Blend(ix, iy, c, cov, mode);
                }
            }
        }

        /// <summary>
        /// Fills a region with a colour that varies per pixel — the primitive the shield field and
        /// the parchment ground are written in.
        /// </summary>
        /// <remarks>
        /// ⚠️ THIS IS NOT A CONVENIENCE OVER <see cref="Fill"/> AND THE DIFFERENCE MATTERS. A shield
        /// field is a tincture, a raking light across the boss and a shadow in the chief, and every
        /// one of those is a colour GRADIENT rather than a filled silhouette. Composing them out of
        /// flat <see cref="Fill"/> calls needs dozens of stacked bands and the banding is visible on
        /// a dark page — this factory has shipped that mistake on a vignette. Returning null from the callback leaves the pixel
        /// untouched, which is how the shape and the shading are expressed in one pass.
        /// </remarks>
        /// <param name="shader">Returns the colour at a normalised point, or null to skip it.</param>
        /// <param name="bounds">Optional normalised bounds (minX, minY, maxX, maxY) to limit work.</param>
        /// <param name="mode">Blend mode.</param>
        public void Shade(Func<float, float, Color?> shader, Vector4? bounds = null,
                          InkBlend mode = InkBlend.Over)
        {
            if (shader == null) throw new ArgumentNullException(nameof(shader));

            int x0 = 0, y0 = 0, x1 = _w - 1, y1 = _h - 1;
            if (bounds.HasValue)
            {
                Vector4 bb = bounds.Value;
                x0 = Mathf.Max(0, Mathf.FloorToInt(Px(bb.x + _originX)) - 2);
                x1 = Mathf.Min(_w - 1, Mathf.CeilToInt(Px(bb.z + _originX)) + 2);
                y0 = Mathf.Max(0, Mathf.FloorToInt(Py(bb.w + _originY)) - 2);
                y1 = Mathf.Min(_h - 1, Mathf.CeilToInt(Py(bb.y + _originY)) + 2);
            }

            for (int iy = y0; iy <= y1; iy++)
            {
                float ny = 1f - 2f * (iy / (float)(_h - 1)) - _originY;
                for (int ix = x0; ix <= x1; ix++)
                {
                    float nx = (2f * (ix / (float)(_w - 1)) - 1f) * Aspect - _originX;
                    Color? c = shader(nx, ny);
                    if (!c.HasValue) continue;
                    Blend(ix, iy, c.Value, 1f, mode);
                }
            }
        }

        /// <summary>
        /// Adds a smooth radial falloff — the halo an ember aura throws. This is deliberately NOT an
        /// SDF fill: a halo has no edge, so rasterising it through <see cref="Fill"/> would spend the
        /// antialiasing budget on a boundary that should not exist.
        /// </summary>
        /// <param name="cx">Centre X, normalised.</param>
        /// <param name="cy">Centre Y, normalised.</param>
        /// <param name="radius">Radius at which the falloff reaches zero.</param>
        /// <param name="c">Colour. Its alpha scales the peak intensity.</param>
        /// <param name="power">Falloff exponent. 1 is linear; 2–4 give a tight core with a long skirt.</param>
        /// <param name="mode">Blend mode. <see cref="InkBlend.Add"/> is almost always what you want.</param>
        public void Glow(float cx, float cy, float radius, in Color c,
                         float power = 2.5f, InkBlend mode = InkBlend.Add)
        {
            if (radius <= 0f) return;
            int x0 = Mathf.Max(0, Mathf.FloorToInt(Px(cx - radius + _originX)));
            int x1 = Mathf.Min(_w - 1, Mathf.CeilToInt(Px(cx + radius + _originX)));
            int y0 = Mathf.Max(0, Mathf.FloorToInt(Py(cy + radius + _originY)));
            int y1 = Mathf.Min(_h - 1, Mathf.CeilToInt(Py(cy - radius + _originY)));

            float invR = 1f / radius;
            for (int iy = y0; iy <= y1; iy++)
            {
                float ny = 1f - 2f * (iy / (float)(_h - 1)) - _originY;
                for (int ix = x0; ix <= x1; ix++)
                {
                    float nx = (2f * (ix / (float)(_w - 1)) - 1f) * Aspect - _originX;
                    float dx = nx - cx, dy = ny - cy;
                    float t = Mathf.Sqrt(dx * dx + dy * dy) * invR;
                    if (t >= 1f) continue;
                    Blend(ix, iy, c, Mathf.Pow(1f - t, power), mode);
                }
            }
        }

        /// <summary>Fills a disc.</summary>
        /// <param name="cx">Centre X.</param>
        /// <param name="cy">Centre Y.</param>
        /// <param name="radius">Radius in normalised units.</param>
        /// <param name="c">Colour.</param>
        /// <param name="mode">Blend mode.</param>
        public void Disc(float cx, float cy, float radius, in Color c, InkBlend mode = InkBlend.Over)
        {
            Fill((x, y) => Mathf.Sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy)) - radius, c,
                 new Vector4(cx - radius, cy - radius, cx + radius, cy + radius), mode);
        }

        /// <summary>Strokes a circle of the given radius and stroke width.</summary>
        /// <param name="cx">Centre X.</param>
        /// <param name="cy">Centre Y.</param>
        /// <param name="radius">Radius of the centre line of the stroke.</param>
        /// <param name="width">Stroke width.</param>
        /// <param name="c">Colour.</param>
        /// <param name="mode">Blend mode.</param>
        public void Ring(float cx, float cy, float radius, float width, in Color c,
                         InkBlend mode = InkBlend.Over)
        {
            float half = width * 0.5f;
            Fill((x, y) => Mathf.Abs(Mathf.Sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy)) - radius) - half, c,
                 new Vector4(cx - radius - half, cy - radius - half, cx + radius + half, cy + radius + half), mode);
        }

        /// <summary>Fills an ellipse. Used for bodies, egg sacs and edge-on fins.</summary>
        /// <param name="cx">Centre X.</param>
        /// <param name="cy">Centre Y.</param>
        /// <param name="rx">Semi-axis along local X before rotation.</param>
        /// <param name="ry">Semi-axis along local Y before rotation.</param>
        /// <param name="rotDeg">Rotation, degrees counter-clockwise.</param>
        /// <param name="c">Colour.</param>
        /// <param name="mode">Blend mode.</param>
        public void Ellipse(float cx, float cy, float rx, float ry, float rotDeg, in Color c,
                            InkBlend mode = InkBlend.Over)
        {
            if (rx <= 0f || ry <= 0f) return;
            float s = Mathf.Sin(-rotDeg * Mathf.Deg2Rad), co = Mathf.Cos(-rotDeg * Mathf.Deg2Rad);
            float rr = Mathf.Max(rx, ry);
            float minR = Mathf.Min(rx, ry);
            Fill((x, y) =>
            {
                float px = x - cx, py = y - cy;
                float ux = px * co - py * s, uy = px * s + py * co;
                // Normalised implicit ellipse, scaled back toward a distance by the smaller radius.
                float k = Mathf.Sqrt((ux / rx) * (ux / rx) + (uy / ry) * (uy / ry));
                return (k - 1f) * minR;
            }, c, new Vector4(cx - rr, cy - rr, cx + rr, cy + rr), mode);
        }

        /// <summary>Strokes an ellipse outline of the given width.</summary>
        /// <remarks>
        /// ⚠️ This exists to replace a hack, and the hack is worth naming because it is tempting and
        /// it looks fine until it does not: an outline can be faked by filling a big ellipse in the
        /// rim colour and then filling a smaller one in the PAGE colour. That works on an empty
        /// background and punches a hard dark hole through anything already drawn — here, straight
        /// through the charge already laid on the field. A real band has no interior to fill, so it composites
        /// correctly over whatever is underneath.
        /// </remarks>
        /// <param name="cx">Centre X.</param>
        /// <param name="cy">Centre Y.</param>
        /// <param name="rx">Semi-axis along local X before rotation.</param>
        /// <param name="ry">Semi-axis along local Y before rotation.</param>
        /// <param name="rotDeg">Rotation, degrees counter-clockwise.</param>
        /// <param name="width">Stroke width.</param>
        /// <param name="c">Colour.</param>
        /// <param name="mode">Blend mode.</param>
        public void EllipseRing(float cx, float cy, float rx, float ry, float rotDeg, float width,
                                in Color c, InkBlend mode = InkBlend.Over)
        {
            if (rx <= 0f || ry <= 0f) return;
            float s = Mathf.Sin(-rotDeg * Mathf.Deg2Rad), co = Mathf.Cos(-rotDeg * Mathf.Deg2Rad);
            float half = width * 0.5f;
            float rr = Mathf.Max(rx, ry) + half;
            float minR = Mathf.Min(rx, ry);
            Fill((x, y) =>
            {
                float px = x - cx, py = y - cy;
                float ux = px * co - py * s, uy = px * s + py * co;
                float k = Mathf.Sqrt((ux / rx) * (ux / rx) + (uy / ry) * (uy / ry));
                // (k-1) scaled by the smaller radius approximates distance to the curve well enough
                // for a stroke; the approximation only degrades at extreme eccentricity.
                return Mathf.Abs(k - 1f) * minR - half;
            }, c, new Vector4(cx - rr, cy - rr, cx + rr, cy + rr), mode);
        }

        /// <summary>Strokes a line segment with round caps.</summary>
        /// <param name="ax">Start X.</param>
        /// <param name="ay">Start Y.</param>
        /// <param name="bx">End X.</param>
        /// <param name="by">End Y.</param>
        /// <param name="width">Stroke width.</param>
        /// <param name="c">Colour.</param>
        /// <param name="mode">Blend mode.</param>
        public void Line(float ax, float ay, float bx, float by, float width, in Color c,
                         InkBlend mode = InkBlend.Over)
        {
            Needle(ax, ay, bx, by, width, width, c, mode);
        }

        /// <summary>
        /// Strokes a segment whose width tapers from <paramref name="wA"/> to <paramref name="wB"/>.
        /// </summary>
        /// <remarks>
        /// This is the single most load-bearing primitive in the corpus. A horn drawn with a constant
        /// width reads as a wire; the same horn tapered to a point reads as bone. The wing has already
        /// paid once for the general version of this lesson — a corpus of thin constant-width strokes
        /// rendered as "bent wires" and had to be rebuilt around large filled shapes.
        /// </remarks>
        /// <param name="ax">Start X.</param>
        /// <param name="ay">Start Y.</param>
        /// <param name="bx">End X.</param>
        /// <param name="by">End Y.</param>
        /// <param name="wA">Width at the start.</param>
        /// <param name="wB">Width at the end.</param>
        /// <param name="c">Colour.</param>
        /// <param name="mode">Blend mode.</param>
        public void Needle(float ax, float ay, float bx, float by, float wA, float wB, in Color c,
                           InkBlend mode = InkBlend.Over)
        {
            float dx = bx - ax, dy = by - ay;
            float len2 = dx * dx + dy * dy;
            float hA = wA * 0.5f, hB = wB * 0.5f;
            float maxH = Mathf.Max(hA, hB);
            Fill((x, y) =>
            {
                float px = x - ax, py = y - ay;
                float t = len2 <= 1e-9f ? 0f : Mathf.Clamp01((px * dx + py * dy) / len2);
                float qx = px - dx * t, qy = py - dy * t;
                return Mathf.Sqrt(qx * qx + qy * qy) - Mathf.Lerp(hA, hB, t);
            }, c, new Vector4(Mathf.Min(ax, bx) - maxH, Mathf.Min(ay, by) - maxH,
                              Mathf.Max(ax, bx) + maxH, Mathf.Max(ay, by) + maxH), mode);
        }

        /// <summary>
        /// Draws <paramref name="count"/> tapered rays radiating from a point — the arms of an
        /// elemental rose and the lash of a static corona.
        /// </summary>
        /// <param name="cx">Centre X.</param>
        /// <param name="cy">Centre Y.</param>
        /// <param name="count">Number of rays.</param>
        /// <param name="length">Ray length in normalised units.</param>
        /// <param name="rootWidth">Width at the centre, tapering to a point at the tip.</param>
        /// <param name="rotDeg">Rotation of the first ray, degrees counter-clockwise from +X.</param>
        /// <param name="c">Colour.</param>
        /// <param name="alternate">When set, every other ray is shortened by this factor.</param>
        /// <param name="mode">Blend mode.</param>
        public void Rays(float cx, float cy, int count, float length, float rootWidth,
                         float rotDeg, in Color c, float alternate = 1f,
                         InkBlend mode = InkBlend.Add)
        {
            if (count <= 0) return;
            for (int i = 0; i < count; i++)
            {
                float a = (rotDeg + i * 360f / count) * Mathf.Deg2Rad;
                float len = length * ((i & 1) == 1 ? alternate : 1f);
                Needle(cx, cy, cx + Mathf.Cos(a) * len, cy + Mathf.Sin(a) * len,
                       rootWidth, 0f, c, mode);
            }
        }

        /// <summary>
        /// Strokes a smoothly tapering ribbon through <paramref name="pts"/> in ONE rasterisation
        /// pass, with a half-width supplied per point.
        /// </summary>
        /// <remarks>
        /// ⚠️ THIS EXISTS BECAUSE DRAWING A CURVE AS A CHAIN OF <see cref="Needle"/> CALLS IS VISIBLY
        /// WRONG, and the sibling product's corpus sheet showed it plainly. Each needle has round
        /// caps, so consecutive segments overlap at every joint; under <see cref="InkBlend.Add"/>
        /// that overlap is brighter than the rest of the stroke and a tail renders as a string of
        /// beads. Under <see cref="InkBlend.Over"/> it is subtler but still scalloped where the
        /// width changes.
        /// <para>
        /// Taking the minimum distance across every segment before compositing once removes both:
        /// the ribbon is a single shape, so there are no joints to double up. The cost is that the
        /// signed-distance lambda loops the segment list per pixel, which is why the per-segment
        /// bounds below matter and why this is not the primitive for a straight line.
        /// </para>
        /// </remarks>
        /// <param name="pts">Ribbon spine, in normalised units. Fewer than two points draws nothing.</param>
        /// <param name="halfWidths">Half-width at each point. Must be the same length as <paramref name="pts"/>.</param>
        /// <param name="c">Colour.</param>
        /// <param name="mode">Blend mode.</param>
        public void Ribbon(Vector2[] pts, float[] halfWidths, in Color c, InkBlend mode = InkBlend.Over)
        {
            if (pts == null) throw new ArgumentNullException(nameof(pts));
            if (halfWidths == null) throw new ArgumentNullException(nameof(halfWidths));
            if (halfWidths.Length != pts.Length)
                throw new ArgumentException("halfWidths must match pts in length", nameof(halfWidths));
            if (pts.Length < 2) return;

            float minX = float.MaxValue, minY = float.MaxValue, maxX = float.MinValue, maxY = float.MinValue;
            float maxHalf = 0f;
            for (int i = 0; i < pts.Length; i++)
            {
                if (pts[i].x < minX) minX = pts[i].x;
                if (pts[i].y < minY) minY = pts[i].y;
                if (pts[i].x > maxX) maxX = pts[i].x;
                if (pts[i].y > maxY) maxY = pts[i].y;
                if (halfWidths[i] > maxHalf) maxHalf = halfWidths[i];
            }

            // Per-segment bounds, padded so rejection can never discard a segment that could still
            // land inside Fill's one-pixel feather. Without this the lambda walks every segment for
            // every pixel of the whole ribbon's bounding box, and a coiled tail's box is mostly
            // empty — measured on the sibling, it made a bake 4.5x slower than the chained-needle
            // version it replaced.
            int n = pts.Length;
            float pad = 2f / Scale;
            var bx0 = new float[n - 1];
            var bx1 = new float[n - 1];
            var by0 = new float[n - 1];
            var by1 = new float[n - 1];
            for (int i = 0; i < n - 1; i++)
            {
                float h = Mathf.Max(halfWidths[i], halfWidths[i + 1]) + pad;
                bx0[i] = Mathf.Min(pts[i].x, pts[i + 1].x) - h;
                bx1[i] = Mathf.Max(pts[i].x, pts[i + 1].x) + h;
                by0[i] = Mathf.Min(pts[i].y, pts[i + 1].y) - h;
                by1[i] = Mathf.Max(pts[i].y, pts[i + 1].y) + h;
            }

            Fill((x, y) =>
            {
                float best = float.MaxValue;
                for (int i = 0; i < n - 1; i++)
                {
                    if (x < bx0[i] || x > bx1[i] || y < by0[i] || y > by1[i]) continue;
                    float ax = pts[i].x, ay = pts[i].y;
                    float dx = pts[i + 1].x - ax, dy = pts[i + 1].y - ay;
                    float len2 = dx * dx + dy * dy;
                    float px = x - ax, py = y - ay;
                    float t = len2 <= 1e-9f ? 0f : Mathf.Clamp01((px * dx + py * dy) / len2);
                    float qx = px - dx * t, qy = py - dy * t;
                    float d = Mathf.Sqrt(qx * qx + qy * qy)
                            - Mathf.Lerp(halfWidths[i], halfWidths[i + 1], t);
                    if (d < best) best = d;
                }
                return best;
            }, c, new Vector4(minX - maxHalf, minY - maxHalf, maxX + maxHalf, maxY + maxHalf), mode);
        }

        /// <summary>Strokes a polyline, optionally closing it.</summary>
        /// <param name="pts">The polyline points.</param>
        /// <param name="width">Stroke width.</param>
        /// <param name="c">Colour.</param>
        /// <param name="close">When true, joins the last point back to the first.</param>
        /// <param name="mode">Blend mode.</param>
        public void Path(Vector2[] pts, float width, in Color c, bool close = false,
                         InkBlend mode = InkBlend.Over)
        {
            if (pts == null) throw new ArgumentNullException(nameof(pts));
            if (pts.Length < 2) return;
            for (int i = 0; i < pts.Length - 1; i++)
                Line(pts[i].x, pts[i].y, pts[i + 1].x, pts[i + 1].y, width, c, mode);
            if (close)
                Line(pts[pts.Length - 1].x, pts[pts.Length - 1].y, pts[0].x, pts[0].y, width, c, mode);
        }

        /// <summary>Fills a simple polygon using an even-odd winding test.</summary>
        /// <param name="pts">Polygon vertices. Fewer than three draws nothing.</param>
        /// <param name="c">Colour.</param>
        /// <param name="mode">Blend mode.</param>
        public void Polygon(Vector2[] pts, in Color c, InkBlend mode = InkBlend.Over)
        {
            if (pts == null) throw new ArgumentNullException(nameof(pts));
            if (pts.Length < 3) return;

            float minX = float.MaxValue, minY = float.MaxValue, maxX = float.MinValue, maxY = float.MinValue;
            for (int i = 0; i < pts.Length; i++)
            {
                if (pts[i].x < minX) minX = pts[i].x;
                if (pts[i].y < minY) minY = pts[i].y;
                if (pts[i].x > maxX) maxX = pts[i].x;
                if (pts[i].y > maxY) maxY = pts[i].y;
            }

            Fill((x, y) =>
            {
                float best = float.MaxValue;
                bool inside = false;
                for (int i = 0, j = pts.Length - 1; i < pts.Length; j = i++)
                {
                    float ex = pts[j].x - pts[i].x, ey = pts[j].y - pts[i].y;
                    float px = x - pts[i].x, py = y - pts[i].y;
                    float len2 = ex * ex + ey * ey;
                    float t = len2 <= 1e-9f ? 0f : Mathf.Clamp01((px * ex + py * ey) / len2);
                    float qx = px - ex * t, qy = py - ey * t;
                    float d2 = qx * qx + qy * qy;
                    if (d2 < best) best = d2;

                    bool crosses = (pts[i].y > y) != (pts[j].y > y);
                    if (crosses && px < ex * (y - pts[i].y) / (ey == 0f ? 1e-9f : ey))
                        inside = !inside;
                }
                float d = Mathf.Sqrt(best);
                return inside ? -d : d;
            }, c, new Vector4(minX, minY, maxX, maxY), mode);
        }

        /// <summary>
        /// Fills the annular sector between two radii and two angles, in degrees counter-clockwise
        /// from +X. In this package it draws the verdict stamp's broken outer ring.
        /// </summary>
        /// <param name="cx">Centre X.</param>
        /// <param name="cy">Centre Y.</param>
        /// <param name="rInner">Inner radius.</param>
        /// <param name="rOuter">Outer radius.</param>
        /// <param name="degFrom">Start angle, degrees.</param>
        /// <param name="degTo">End angle, degrees.</param>
        /// <param name="c">Colour.</param>
        /// <param name="mode">Blend mode.</param>
        public void ArcBand(float cx, float cy, float rInner, float rOuter,
                            float degFrom, float degTo, in Color c, InkBlend mode = InkBlend.Over)
        {
            float a0 = degFrom * Mathf.Deg2Rad;
            float a1 = degTo * Mathf.Deg2Rad;
            float mid = (a0 + a1) * 0.5f;
            float halfSweep = Mathf.Abs(a1 - a0) * 0.5f;
            float rMid = (rInner + rOuter) * 0.5f;
            float rHalf = (rOuter - rInner) * 0.5f;

            Fill((x, y) =>
            {
                float px = x - cx, py = y - cy;
                float r = Mathf.Sqrt(px * px + py * py);
                float dRadial = Mathf.Abs(r - rMid) - rHalf;
                float ang = Mathf.Atan2(py, px) - mid;
                while (ang > Mathf.PI) ang -= 2f * Mathf.PI;
                while (ang < -Mathf.PI) ang += 2f * Mathf.PI;
                float dAngular = (Mathf.Abs(ang) - halfSweep) * Mathf.Max(r, 1e-4f);
                return Mathf.Max(dRadial, dAngular);
            }, c, new Vector4(cx - rOuter, cy - rOuter, cx + rOuter, cy + rOuter), mode);
        }

        // ---------------------------------------------------------------- resolve

        /// <summary>
        /// Resolves the supersampled buffer to <b>premultiplied</b> pixels, top-down.
        /// </summary>
        /// <remarks>
        /// <para>
        /// The box downsample here IS the antialiasing. Sixteen samples per output pixel is enough
        /// that a tapered horn at 48 px reads as a clean point rather than a staircase, which is the
        /// size the buyer sees most often in a trait strip.
        /// </para>
        /// <para>
        /// ⚠️ THE RGB IS PREMULTIPLIED BY COVERAGE and the channels are NOT clamped, which is
        /// deliberate and is what makes <see cref="InkBlend.Add"/> work: an additive aura leaves rgb
        /// above its own alpha, and clamping here would throw that light away before it reaches the
        /// page. Anything that hands the tile to Unity as a texture must un-premultiply first — see
        /// <see cref="Resolve"/>.
        /// </para>
        /// </remarks>
        public Color[] ResolvePixels()
        {
            var px = new Color[Width * Height];
            // ⛔ Samples, NOT the SuperSample constant. Reading the constant here while the buffer
            // was allocated from the instance value indexes off the end of the array on any surface
            // that is not at the default 4 — MEASURED 2026-08-29, and it took out every composition
            // test at once with an IndexOutOfRangeException. Master doctrine: when a value becomes
            // configurable, the bug is never in the writer, it is in the READER that still assumes
            // the old constant.
            float inv = 1f / (Samples * Samples);

            for (int y = 0; y < Height; y++)
            {
                for (int x = 0; x < Width; x++)
                {
                    float sr = 0f, sg = 0f, sb = 0f, sa = 0f;
                    int bx = x * Samples, by = y * Samples;
                    for (int oy = 0; oy < Samples; oy++)
                    {
                        int row = (by + oy) * _w;
                        for (int ox = 0; ox < Samples; ox++)
                        {
                            int i = row + bx + ox;
                            sr += _r[i]; sg += _g[i]; sb += _b[i]; sa += _a[i];
                        }
                    }
                    px[y * Width + x] = new Color(sr * inv, sg * inv, sb * inv, Mathf.Clamp01(sa * inv));
                }
            }
            return px;
        }

        /// <summary>
        /// Resolves to a <see cref="Texture2D"/> with STRAIGHT alpha, ready to hand to a UI element
        /// under Unity's ordinary alpha blending.
        /// </summary>
        /// <remarks>
        /// ⚠️ THE UN-PREMULTIPLY HERE IS NOT COSMETIC. <see cref="ResolvePixels"/> leaves rgb scaled
        /// by coverage; handing that straight to a UI Image blends it a second time, so every soft
        /// edge comes out roughly twice as dark as drawn. On a corpus that is mostly opaque glyphs
        /// the error is invisible; on an aura, which is mostly soft halo, it is the difference
        /// between a light source and a grey smudge — and it would pass every mechanical check this
        /// factory has, because the image is the right size, the right format and full of distinct
        /// colours.
        /// <para>
        /// One honest limitation: an additive glow can hold more light than its own coverage, so
        /// dividing it back out can exceed 1 and is then clamped. That is correct for an emissive
        /// read at low alpha, and it is the reason the page itself composites in premultiplied space
        /// instead of going through here.
        /// </para>
        /// </remarks>
        /// <param name="name">Texture name, which is what a buyer sees in the inspector.</param>
        public Texture2D Resolve(string name)
        {
            var tex = new Texture2D(Width, Height, TextureFormat.RGBA32, false, false)
            {
                name = name,
                filterMode = FilterMode.Bilinear,
                wrapMode = TextureWrapMode.Clamp,
            };
            Color[] src = ResolvePixels();
            var px = new Color32[Width * Height];
            for (int y = 0; y < Height; y++)
            {
                for (int x = 0; x < Width; x++)
                {
                    Color c = src[y * Width + x];
                    float a = Mathf.Clamp01(c.a);
                    float inv = a > 0.0001f ? 1f / a : 0f;
                    // Texture2D rows run bottom-up; our buffer runs top-down.
                    px[(Height - 1 - y) * Width + x] = new Color(
                        Mathf.Clamp01(c.r * inv), Mathf.Clamp01(c.g * inv), Mathf.Clamp01(c.b * inv), a);
                }
            }
            tex.SetPixels32(px);
            tex.Apply(false, false);
            return tex;
        }

        // ---------------------------------------------------------------- self-measurement

        /// <summary>
        /// Fraction of samples inside <paramref name="radius"/> carrying real ink (alpha &gt;= 0.5).
        /// </summary>
        /// <remarks>
        /// ⚠️ THIS EXISTS BECAUSE OF A MEASURED DEFECT ON A SIBLING PRODUCT, and it is the mechanical
        /// floor under a judgement no script can make. A corpus rendered from thin strokes produces
        /// perfectly valid images — correct size, hundreds of distinct colours, no error anywhere —
        /// that read as bent wire. A distinct-colour count cannot tell those apart from real art.
        /// Ink coverage can.
        /// <para>
        /// ⛔ MEASURE IT ON A GLYPH DRAWN ALONE ON AN EMPTY SURFACE. Measuring it on a composed page
        /// measures the page's backdrop, which is opaque everywhere and scores a perfect 1.0 while
        /// telling you nothing at all about the glyph.
        /// </para>
        /// <para>
        /// It is NECESSARY AND NEVER SUFFICIENT. A solid disc scores beautifully and is not a
        /// crest. Gate 1 still means opening the sheet and looking at it.
        /// </para>
        /// </remarks>
        /// <param name="radius">Normalised radius of the measured region.</param>
        public float AlphaCoverage(float radius = 0.62f)
        {
            int inside = 0, inked = 0;
            // Samples, NOT the constant — same reason as ResolvePixels.
            float inv = 1f / (Samples * Samples);
            for (int y = 0; y < Height; y++)
            {
                float ny = Height <= 1 ? 0f : 1f - 2f * (y / (float)(Height - 1));
                for (int x = 0; x < Width; x++)
                {
                    float nx = Width <= 1 ? 0f : (2f * (x / (float)(Width - 1)) - 1f) * Aspect;
                    if (nx * nx + ny * ny > radius * radius) continue;
                    inside++;
                    float sa = 0f;
                    int bx = x * Samples, by = y * Samples;
                    for (int oy = 0; oy < Samples; oy++)
                    {
                        int row = (by + oy) * _w;
                        for (int ox = 0; ox < Samples; ox++) sa += _a[row + bx + ox];
                    }
                    if (sa * inv >= 0.5f) inked++;
                }
            }
            return inside == 0 ? 0f : inked / (float)inside;
        }

        /// <summary>
        /// Counts distinct quantised colours in the resolved tile. A form that draws nothing still
        /// returns a valid texture; only a colour count tells the two apart.
        /// </summary>
        public int DistinctColourCount()
        {
            var seen = new System.Collections.Generic.HashSet<int>();
            Color[] px = ResolvePixels();
            for (int i = 0; i < px.Length; i++)
            {
                int key = (Mathf.RoundToInt(Mathf.Clamp01(px[i].r) * 31) << 15)
                        | (Mathf.RoundToInt(Mathf.Clamp01(px[i].g) * 31) << 10)
                        | (Mathf.RoundToInt(Mathf.Clamp01(px[i].b) * 31) << 5)
                        | Mathf.RoundToInt(Mathf.Clamp01(px[i].a) * 31);
                seen.Add(key);
            }
            return seen.Count;
        }
    }
}
