#nullable enable
// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

using System.Collections.Generic;

namespace CSAF.Ballast
{
    /// <summary>
    /// A worked example of a certificate, for a buyer whose own project has no Resources folder yet.
    /// </summary>
    /// <remarks>
    /// <para>
    /// ⛔ <b>EVERY SURFACE THAT SHOWS THIS MUST SAY IT IS A SAMPLE, AND THE PLATE ITSELF SAYS SO IN
    /// ITS OWN CONSIGNEE LINE.</b> A drawn document is persuasive precisely because it looks like a
    /// measurement, so an example that could be mistaken for one is a fabricated figure with good
    /// typography. The project name struck on it reads <c>SAMPLE PROJECT</c>, which appears in the
    /// largest type on the plate and travels with any screenshot of it.
    /// </para>
    /// <para>
    /// ⚠️ The numbers are a plausible mid-size project rather than a flattering one: the displacement
    /// is a little under a fifth of the Resources weight, and a real folder is left almost entirely
    /// withheld. A sample that showed 90% displaceable would be selling a result this product cannot
    /// promise, since what it finds depends entirely on how the buyer's code is written.
    /// </para>
    /// </remarks>
    public static class SampleLading
    {
        /// <summary>Builds the example.</summary>
        /// <param name="stock">Paper.</param>
        /// <param name="dateline">Dateline to strike.</param>
        /// <returns>A lading that is clearly labelled as an example.</returns>
        public static Lading Build(Stock stock, string dateline)
        {
            var rows = new List<LadingRow>
            {
                //                folder                              reached    unreached  withheld   R   U   I
                new LadingRow("Assets/Art/Resources",              18_874_368,  9_961_472, 2_306_867,  41, 63, 12),
                new LadingRow("Assets/Audio/Resources",             6_291_456,  2_097_152, 1_048_576,   9, 14,  5),
                new LadingRow("Assets/UI_Kit/Resources",            3_355_443,    786_432, 7_340_032,  22,  8, 37),
                new LadingRow("Assets/Vendor/Dialogue/Resources",     524_288,    262_144,   131_072,   6,  4,  2),
            };

            return new Lading(rows, "SAMPLE PROJECT", dateline,
                              sitesRead: 214, filesScanned: 318, refusedBecause: null, stock: stock);
        }
    }
}
