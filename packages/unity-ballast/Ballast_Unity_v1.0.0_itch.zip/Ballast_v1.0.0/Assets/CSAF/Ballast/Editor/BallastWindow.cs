#nullable enable
// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace CSAF.Ballast
{
    /// <summary>
    /// The buyer's surface: survey the project, read the certificate, and move what is provably
    /// unreached out of the build.
    /// </summary>
    /// <remarks>
    /// <para>
    /// ⛔ <b>NOTHING IN THIS WINDOW RUNS ON ITS OWN.</b> No import hook, no build callback, no
    /// scheduled pass. The survey runs when the buyer presses Survey, and the migration runs when
    /// they confirm a dialog that names the count and the tonnage. A build-weight tool that acted on
    /// import would eventually move an asset during someone else's build.
    /// </para>
    /// <para>
    /// ⚠️ <b>THE CERTIFICATE IS COMPOSED ON DEMAND AND CACHED, NEVER ON WINDOW OPEN.</b> It is a CPU
    /// rasterisation of a 1100x1500 plate and costs seconds, not milliseconds. This wing has shipped
    /// a demo scene that composed eight plates synchronously before the first frame and froze the
    /// editor; the rule that came out of it is compose one thing, lazily.
    /// </para>
    /// <para>
    /// ⚠️ <b>EVERY VERDICT IN THE LIST CARRIES ITS CITATION.</b> A reached asset names the file and
    /// line that reached it, and a withheld one names the site that could. A verdict with no citation
    /// is a reporter's output, and this product is asking the buyer to let it move files.
    /// </para>
    /// </remarks>
    public sealed class BallastWindow : EditorWindow
    {
        private const string PrefStock = "CSAF.Ballast.Stock";
        private const string PrefFilter = "CSAF.Ballast.Filter";

        private Survey? _survey;
        private Texture2D? _plate;
        private Vector2 _scroll;
        private Stock _stock = Stock.Manifest;
        private Verdict _filter = Verdict.Unreached;
        private bool _showList = true;
        private double _lastSurveySeconds;
        private double _lastComposeSeconds;
        private string _status = "Press Survey to read this project.";

        [MenuItem("Window/CSAF/Ballast", false, 2200)]
        private static void Open()
        {
            var w = GetWindow<BallastWindow>(false, "Ballast", true);
            w.minSize = new Vector2(520f, 480f);
            w.Show();
        }

        private void OnEnable()
        {
            // ⚠️ Namespaced keys. An EditorPrefs key without a product prefix is a collision waiting
            // for the buyer to install a second tool that thought of the same short name.
            _stock = (Stock)EditorPrefs.GetInt(PrefStock, (int)Stock.Manifest);
            _filter = (Verdict)EditorPrefs.GetInt(PrefFilter, (int)Verdict.Unreached);
        }

        private void OnDisable()
        {
            EditorPrefs.SetInt(PrefStock, (int)_stock);
            EditorPrefs.SetInt(PrefFilter, (int)_filter);
            DisposePlate();
        }

        private void OnGUI()
        {
            DrawToolbar();
            EditorGUILayout.Space(4f);

            _scroll = EditorGUILayout.BeginScrollView(_scroll);

            if (_survey == null)
            {
                EditorGUILayout.HelpBox(_status, MessageType.Info);
                // ⚠️ The plate is drawn here too, because "Sample certificate" produces one with no
                // survey behind it. An earlier arrangement returned before this point, so pressing
                // that button composed a texture nothing ever displayed -- a button that did real
                // work and appeared to do nothing.
                DrawPlate();
                DrawExplainer();
            }
            else
            {
                DrawSummary(_survey);
                DrawPlate();
                DrawActions(_survey);
                if (_showList) DrawList(_survey);
            }

            EditorGUILayout.EndScrollView();
        }

        private void DrawToolbar()
        {
            using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
            {
                if (GUILayout.Button("Survey", EditorStyles.toolbarButton, GUILayout.Width(70f)))
                    RunSurvey();

                using (new EditorGUI.DisabledScope(_survey == null))
                {
                    if (GUILayout.Button("Compose certificate", EditorStyles.toolbarButton, GUILayout.Width(150f)))
                        Compose();
                }

                // ⚠️ Export is gated on there being a PLATE, not on there being a survey. Gating it
                // on the survey would grey it out over a sample certificate that is plainly on
                // screen, which reads as a broken button rather than as a deliberate refusal.
                using (new EditorGUI.DisabledScope(_plate == null && _survey == null))
                {
                    if (GUILayout.Button("Export PNG", EditorStyles.toolbarButton, GUILayout.Width(90f)))
                        ExportPlate();
                }

                if (GUILayout.Button("Sample certificate", EditorStyles.toolbarButton, GUILayout.Width(130f)))
                    ComposeSample();

                GUILayout.FlexibleSpace();

                EditorGUI.BeginChangeCheck();
                _stock = (Stock)EditorGUILayout.EnumPopup(_stock, EditorStyles.toolbarPopup, GUILayout.Width(100f));
                if (EditorGUI.EndChangeCheck())
                {
                    EditorPrefs.SetInt(PrefStock, (int)_stock);
                    // The plate is stale the moment the stock changes, and a stale plate beside a new
                    // selection is a picture that argues with its own control.
                    DisposePlate();
                }
            }
        }

        private void DrawExplainer()
        {
            EditorGUILayout.LabelField("What Ballast does", EditorStyles.boldLabel);
            EditorGUILayout.LabelField(
                "Unity strips unused assets from your build everywhere except one place: the "
                + "Resources folder, which it cannot reason about because scripts ask for those "
                + "assets by name at runtime. Ballast reads those call sites and decides.",
                EditorStyles.wordWrappedLabel);
            EditorGUILayout.Space(6f);
            EditorGUILayout.LabelField("The three answers", EditorStyles.boldLabel);
            EditorGUILayout.LabelField(
                "IN USE - a literal call site names this asset. Kept, and the file and line are shown.\n"
                + "UNREACHED - nothing in your scripts can name it. Offered for migration.\n"
                + "WITHHELD - a dynamic call site could reach it. Never touched, and the site is named.",
                EditorStyles.wordWrappedLabel);
            EditorGUILayout.Space(6f);
            EditorGUILayout.LabelField(
                "Ballast never deletes. Assets are moved to a quarantine folder with their .meta "
                + "files, so every existing reference in your project keeps working, and one button "
                + "puts them back.", EditorStyles.wordWrappedLabel);
        }

        private void DrawSummary(Survey s)
        {
            Lading l = s.Lading;
            EditorGUILayout.LabelField("Survey", EditorStyles.boldLabel);
            EditorGUILayout.LabelField(
                l.TotalCount.ToString(CultureInfo.InvariantCulture) + " assets under "
                + l.Rows.Count.ToString(CultureInfo.InvariantCulture) + " Resources folder(s), "
                + Lading.FormatBytes(l.TotalBytes) + " total, from "
                + s.FilesScanned.ToString(CultureInfo.InvariantCulture) + " scripts and "
                + s.Sites.Count.ToString(CultureInfo.InvariantCulture) + " load sites. "
                + "Survey took " + _lastSurveySeconds.ToString("0.00", CultureInfo.InvariantCulture) + " s.",
                EditorStyles.wordWrappedLabel);

            if (l.RefusedBecause != null && l.RefusedBecause.Length > 0)
            {
                EditorGUILayout.HelpBox(
                    "Ballast will move nothing in this project. " + l.RefusedBecause + "\n\n"
                    + "This is the correct answer, not a failure: a load site with no constant prefix "
                    + "can ask for any resource path at runtime, so no asset here can be shown to be "
                    + "unreachable. Narrow that call site and survey again.", MessageType.Warning);
                return;
            }

            EditorGUILayout.LabelField(
                "In use " + Lading.FormatBytes(l.ReachedBytes)
                + "   |   Unreached " + Lading.FormatBytes(l.DisplacementBytes)
                + "   |   Withheld " + Lading.FormatBytes(l.IndeterminateBytes));
        }

        private void DrawPlate()
        {
            if (_plate == null)
            {
                EditorGUILayout.HelpBox(
                    "Press \"Compose certificate\" to draw the lading certificate. It is a software "
                    + "rasterisation and takes a few seconds, so it is never composed automatically.",
                    MessageType.None);
                return;
            }

            // ⚠️ Previewed at the width it is DISPLAYED, never at the width it was composed. A plate
            // drawn at 1100 px and shown at 380 px pays for pixels nobody sees; here the composed
            // texture is reused, but the rect is derived from the window so the aspect is honest.
            float w = Mathf.Min(position.width - 30f, 460f);
            float h = w * (_plate.height / (float)_plate.width);
            Rect r = GUILayoutUtility.GetRect(w, h, GUILayout.ExpandWidth(false));
            GUI.DrawTexture(r, _plate, ScaleMode.ScaleToFit);
            EditorGUILayout.LabelField(
                "Composed in " + _lastComposeSeconds.ToString("0.00", CultureInfo.InvariantCulture)
                + " s at " + _plate.width + "x" + _plate.height + ".", EditorStyles.miniLabel);
        }

        private void DrawActions(Survey s)
        {
            EditorGUILayout.Space(6f);
            Lading l = s.Lading;
            bool refused = l.RefusedBecause != null && l.RefusedBecause.Length > 0;
            int n = l.DisplacementCount;

            using (new EditorGUI.DisabledScope(refused || n == 0))
            {
                if (GUILayout.Button("Migrate " + n.ToString(CultureInfo.InvariantCulture)
                                     + " unreached assets out of the build ("
                                     + Lading.FormatBytes(l.DisplacementBytes) + ")"))
                    DoMigrate(s);
            }

            var batches = ExistingBatches();
            if (batches.Count > 0)
            {
                EditorGUILayout.Space(2f);
                EditorGUILayout.LabelField("Quarantine", EditorStyles.boldLabel);
                foreach (string b in batches)
                {
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        EditorGUILayout.LabelField(b);
                        if (GUILayout.Button("Put back", GUILayout.Width(80f))) DoRevert(b);
                    }
                }
            }

            EditorGUILayout.Space(4f);
            using (new EditorGUILayout.HorizontalScope())
            {
                _showList = EditorGUILayout.ToggleLeft("Show assets", _showList, GUILayout.Width(110f));
                _filter = (Verdict)EditorGUILayout.EnumPopup(_filter, GUILayout.Width(120f));
            }
        }

        private void DrawList(Survey s)
        {
            int shown = 0;
            foreach (var v in s.Verdicts)
            {
                if (v.Verdict != _filter) continue;
                if (++shown > 400)
                {
                    EditorGUILayout.LabelField("... and more. Filter or export to see the rest.",
                                               EditorStyles.miniLabel);
                    break;
                }

                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(v.AssetPath, GUILayout.MinWidth(200f));
                    EditorGUILayout.LabelField(Lading.FormatBytes(v.Bytes), GUILayout.Width(80f));
                    if (GUILayout.Button("Ping", GUILayout.Width(46f)))
                    {
                        var o = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(v.AssetPath);
                        if (o != null) EditorGUIUtility.PingObject(o);
                    }
                }

                // The citation. This is the difference between a verdict and an assertion.
                if (v.Because.Count > 0)
                {
                    LoadSite site = v.Because[0];
                    string extra = v.Because.Count > 1
                        ? "  (+" + (v.Because.Count - 1).ToString(CultureInfo.InvariantCulture) + " more)"
                        : string.Empty;
                    EditorGUILayout.LabelField("      " + site.File + ":"
                        + site.Line.ToString(CultureInfo.InvariantCulture) + "  " + site.Snippet + extra,
                        EditorStyles.miniLabel);
                }
            }
            if (shown == 0) EditorGUILayout.LabelField("No assets with that verdict.", EditorStyles.miniLabel);
        }

        // ------------------------------------------------------------------ actions

        private void RunSurvey()
        {
            string root = ProjectRoot();
            double t0 = EditorApplication.timeSinceStartup;
            try
            {
                _survey = SurveyRunner.Run(root, Application.productName, _stock, DateTime.UtcNow);
                _status = "Surveyed.";
            }
            catch (Exception e)
            {
                _survey = null;
                _status = "The survey failed: " + e.Message;
                Debug.LogException(e);
            }
            _lastSurveySeconds = EditorApplication.timeSinceStartup - t0;
            DisposePlate();
            Repaint();
        }

        private void Compose()
        {
            if (_survey == null) return;
            DisposePlate();
            double t0 = EditorApplication.timeSinceStartup;
            _plate = Certificate.Compose(_survey.Lading);
            _lastComposeSeconds = EditorApplication.timeSinceStartup - t0;
            Repaint();
        }

        /// <summary>
        /// Draws the worked example, so a buyer can see the artefact before they have a project that
        /// produces one.
        /// </summary>
        /// <remarks>
        /// ⚠️ It deliberately does NOT populate <see cref="_survey"/>. A sample that filled the
        /// summary, the asset list and the Migrate button would put a fabricated tonnage behind a
        /// control that moves real files, and the two states would be indistinguishable at a glance.
        /// The plate says SAMPLE PROJECT on its own face and the status line says so too.
        /// </remarks>
        private void ComposeSample()
        {
            DisposePlate();
            double t0 = EditorApplication.timeSinceStartup;
            _plate = Certificate.Compose(
                SampleLading.Build(_stock, SurveyRunner.Dateline(DateTime.UtcNow)));
            _lastComposeSeconds = EditorApplication.timeSinceStartup - t0;
            _status = "This is a SAMPLE certificate drawn from example figures, not from your "
                      + "project. Press Survey to read your own.";
            Repaint();
        }

        private void ExportPlate()
        {
            // Whatever is on screen is what gets exported, sample or survey — the plate itself
            // carries its own consignee line, so an exported sample is self-identifying.
            if (_plate == null && _survey != null) Compose();
            if (_plate == null) return;

            string path = EditorUtility.SaveFilePanel("Export the lading certificate",
                ProjectRoot(), "ballast_certificate.png", "png");
            if (path == null || path.Length == 0) return;

            File.WriteAllBytes(path, _plate.EncodeToPNG());
            // ⛔ Report the file, not the intention. A caller asks "did the buyer get the certificate
            // I named", and only reading the path back answers that.
            if (File.Exists(path))
                _status = "Exported " + new FileInfo(path).Length.ToString(CultureInfo.InvariantCulture)
                          + " bytes to " + path;
            else
                _status = "The export did not land at " + path;
            Debug.Log("[Ballast] " + _status);
        }

        private void DoMigrate(Survey s)
        {
            var paths = s.UnreachedAssetPaths();
            if (paths.Count == 0) return;

            bool ok = EditorUtility.DisplayDialog(
                "Migrate " + paths.Count.ToString(CultureInfo.InvariantCulture) + " assets",
                "Ballast will MOVE " + paths.Count.ToString(CultureInfo.InvariantCulture)
                + " assets (" + Lading.FormatBytes(s.Lading.DisplacementBytes)
                + ") out of Resources and into " + Migrator.QuarantineRoot + ".\n\n"
                + "Nothing is deleted. Each asset keeps its .meta file, so every existing reference "
                + "in your project keeps working. One button puts them all back.\n\n"
                + "Close the editor's Resources-dependent windows first if any are open.",
                "Migrate", "Cancel");
            if (!ok) return;

            string root = ProjectRoot();
            string stamp = Migrator.StampFor(DateTime.UtcNow);

            MigrationManifest manifest;
            try
            {
                AssetDatabase.StartAssetEditing();
                manifest = Migrator.Migrate(root, paths, stamp);
            }
            finally
            {
                AssetDatabase.StopAssetEditing();
            }

            string dir = root + "/" + Migrator.QuarantineRoot + "/" + stamp;
            Directory.CreateDirectory(dir);
            File.WriteAllText(dir + "/" + Migrator.ManifestName, JsonUtility.ToJson(manifest, true));

            AssetDatabase.Refresh();

            // ⚠️ Count what happened, never what was asked for. A migration that moved 37 of 40 is a
            // different event from one that moved 40, and the buyer needs to be told which they got.
            _status = "Migrated " + manifest.Entries.Count.ToString(CultureInfo.InvariantCulture)
                      + " of " + paths.Count.ToString(CultureInfo.InvariantCulture) + " assets ("
                      + Lading.FormatBytes(manifest.TotalBytes) + ") into " + stamp + ".";
            Debug.Log("[Ballast] " + _status);
            RunSurvey();
        }

        private void DoRevert(string stamp)
        {
            string root = ProjectRoot();
            string file = root + "/" + Migrator.QuarantineRoot + "/" + stamp + "/" + Migrator.ManifestName;
            if (!File.Exists(file))
            {
                _status = "No manifest in " + stamp + ", so Ballast will not guess what to put back.";
                return;
            }

            // ⚠️ JsonUtility returns null on malformed input rather than throwing, so a hand-edited
            // or truncated manifest arrives here as a null the compiler cannot see past. Refusing is
            // the only safe branch: Ballast must never guess what to put back.
            MigrationManifest? manifest = JsonUtility.FromJson<MigrationManifest>(File.ReadAllText(file));
            if (manifest == null || manifest.Entries == null)
            {
                _status = "The manifest in " + stamp + " could not be read, so nothing was moved. "
                          + "The assets are still in quarantine and can be moved back by hand.";
                Debug.LogWarning("[Ballast] " + _status);
                return;
            }

            int restored;
            try
            {
                AssetDatabase.StartAssetEditing();
                restored = Migrator.Revert(root, manifest);
            }
            finally
            {
                AssetDatabase.StopAssetEditing();
            }

            AssetDatabase.Refresh();
            _status = "Put back " + restored.ToString(CultureInfo.InvariantCulture) + " of "
                      + manifest.Entries.Count.ToString(CultureInfo.InvariantCulture) + " assets from " + stamp + ".";
            Debug.Log("[Ballast] " + _status);
            RunSurvey();
        }

        // ------------------------------------------------------------------ helpers

        private List<string> ExistingBatches()
        {
            var list = new List<string>();
            string dir = ProjectRoot() + "/" + Migrator.QuarantineRoot;
            if (!Directory.Exists(dir)) return list;
            foreach (string d in Directory.GetDirectories(dir))
                list.Add(Path.GetFileName(d));
            list.Sort(StringComparer.Ordinal);
            return list;
        }

        /// <summary>The project root, i.e. the parent of <c>Assets</c>.</summary>
        private static string ProjectRoot()
        {
            string dataPath = Application.dataPath.Replace('\\', '/');
            int i = dataPath.LastIndexOf('/');
            return i < 0 ? dataPath : dataPath.Substring(0, i);
        }

        private void DisposePlate()
        {
            if (_plate == null) return;
            DestroyImmediate(_plate);
            _plate = null;
        }
    }
}
