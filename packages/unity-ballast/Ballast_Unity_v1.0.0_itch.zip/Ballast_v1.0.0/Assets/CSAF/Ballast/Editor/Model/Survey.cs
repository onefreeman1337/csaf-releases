#nullable enable
// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace CSAF.Ballast
{
    /// <summary>
    /// A whole pass over a project: the load sites read, the resources found, the verdicts reached
    /// and the certificate those add up to.
    /// </summary>
    /// <remarks>
    /// ⚠️ Every field here is DERIVED, never remembered. A survey is a photograph of the project at
    /// one moment and goes stale the instant a script or an asset changes, so the window re-runs it
    /// rather than caching it across a domain reload.
    /// </remarks>
    public sealed class Survey
    {
        /// <summary>Every <c>Resources.Load*</c> call site found.</summary>
        public IReadOnlyList<LoadSite> Sites { get; }

        /// <summary>Every asset under a player-facing Resources folder.</summary>
        public IReadOnlyList<ResourceEntry> Resources { get; }

        /// <summary>One verdict per resource asset.</summary>
        public IReadOnlyList<AssetVerdict> Verdicts { get; }

        /// <summary>The certificate this survey states.</summary>
        public Lading Lading { get; }

        /// <summary>How many C# files were read.</summary>
        public int FilesScanned { get; }

        public Survey(IReadOnlyList<LoadSite> sites, IReadOnlyList<ResourceEntry> resources,
                      IReadOnlyList<AssetVerdict> verdicts, Lading lading, int filesScanned)
        {
            Sites = sites;
            Resources = resources;
            Verdicts = verdicts;
            Lading = lading;
            FilesScanned = filesScanned;
        }

        /// <summary>Project-relative paths of every asset Ballast offers to migrate.</summary>
        /// <returns>The paths, in index order.</returns>
        public List<string> UnreachedAssetPaths()
        {
            var list = new List<string>();
            foreach (var v in Verdicts)
                if (v.Verdict == Verdict.Unreached) list.Add(v.AssetPath);
            return list;
        }
    }

    /// <summary>
    /// Runs a whole survey: walks the scripts, walks the resources, joins them and composes the
    /// lading.
    /// </summary>
    /// <remarks>
    /// <para>
    /// ⛔ <b>THIS TAKES A DIRECTORY AND NOT AN <c>AssetDatabase</c>, ON PURPOSE.</b> Everything the
    /// product decides — which sites were found, what they can reach, which assets are therefore
    /// unreached, and what the certificate says — is then exercisable in EditMode against a
    /// temporary directory, with no project, no import and no engine state. This wing has measured
    /// that a component reachable only through the engine gets ASSERTED about rather than run.
    /// </para>
    /// <para>
    /// ⚠️ <b>THE SCAN DELIBERATELY INCLUDES THE PROJECT'S OWN EDITOR SCRIPTS.</b> An editor script
    /// calling <c>Resources.Load</c> does not put the asset in the player build, but it does mean a
    /// human wrote that path for a reason, and migrating it out from under an editor tool would break
    /// the buyer's workflow rather than their game. Ballast counts it as reached and says so. Erring
    /// toward "someone wants this" is the same asymmetry the scanner is built on.
    /// </para>
    /// </remarks>
    public static class SurveyRunner
    {
        /// <summary>Directories never scanned for scripts, because nothing in them is buyer code.</summary>
        private static readonly string[] SkipDirs = { "/Library/", "/Temp/", "/obj/", "/Build/", "/Builds/", "/.git/" };

        /// <summary>Runs a survey over a project.</summary>
        /// <param name="projectRoot">Absolute path of the project root (the parent of Assets).</param>
        /// <param name="projectName">Name struck on the certificate.</param>
        /// <param name="stock">Paper.</param>
        /// <param name="utcNow">The moment used for the dateline.</param>
        /// <returns>The survey.</returns>
        public static Survey Run(string? projectRoot, string? projectName, Stock stock, DateTime utcNow)
        {
            string root = (projectRoot ?? string.Empty).Replace('\\', '/').TrimEnd('/');
            string assets = root + "/Assets";

            var sites = new List<LoadSite>();
            int files = 0;

            if (Directory.Exists(assets))
            {
                foreach (string file in Directory.GetFiles(assets, "*.cs", SearchOption.AllDirectories))
                {
                    string f = file.Replace('\\', '/');
                    if (IsSkipped(f)) continue;
                    string rel = f.Length > root.Length ? f.Substring(root.Length).TrimStart('/') : f;

                    string text;
                    try { text = File.ReadAllText(f); }
                    catch (IOException) { continue; }
                    catch (UnauthorizedAccessException) { continue; }

                    files++;
                    sites.AddRange(LoadSiteScanner.Scan(text, rel));
                }
            }

            var resources = ResourcesIndex.Build(assets);

            var tuples = new List<(string resourcePath, string assetPath, long bytes)>(resources.Count);
            foreach (var r in resources) tuples.Add((r.ResourcePath, r.AssetPath, r.Bytes));

            var verdicts = Reachability.Classify(tuples, sites);

            string? refused = null;
            if (Reachability.HasOpaqueSite(sites, out LoadSite first) && resources.Count > 0)
            {
                refused = "A LOAD SITE NAMES NO CONSTANT PREFIX: "
                    + first.File.ToUpperInvariant()
                    + " LINE " + first.Line.ToString(CultureInfo.InvariantCulture)
                    + ". NARROW IT AND RE-SURVEY.";
            }

            var rows = Lading.GroupRows(verdicts, ResourcesIndex.FolderOf);
            var lading = new Lading(rows, projectName, Dateline(utcNow), sites.Count, files, refused, stock);

            return new Survey(sites, resources, verdicts, lading, files);
        }

        /// <summary>Formats the dateline the certificate strikes.</summary>
        /// <param name="utcNow">The moment.</param>
        /// <returns>A string every character of which the face can strike.</returns>
        /// <remarks>
        /// ⚠️ Invariant culture and an explicit format, because a machine-local long date can emit a
        /// character the face has no glyph for — and <see cref="TypeSetter"/> then refuses the whole
        /// line, leaving the certificate with no date on it and nothing to say why.
        /// </remarks>
        public static string Dateline(DateTime utcNow)
            => utcNow.ToString("dd MMM yyyy", CultureInfo.InvariantCulture).ToUpperInvariant() + " UTC";

        private static bool IsSkipped(string forwardSlashPath)
        {
            foreach (string d in SkipDirs)
                if (forwardSlashPath.IndexOf(d, StringComparison.OrdinalIgnoreCase) >= 0) return true;
            return false;
        }
    }
}
