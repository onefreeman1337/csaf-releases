#nullable enable
// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

using System.Collections.Generic;

namespace CSAF.Ballast
{
    /// <summary>What Ballast can honestly say about one asset in a <c>Resources</c> folder.</summary>
    public enum Verdict
    {
        /// <summary>
        /// A literal load site names exactly this path. It is loaded; keep it, and the ledger cites
        /// the file and line.
        /// </summary>
        Reached = 0,

        /// <summary>
        /// No literal site names it, and no dynamic site could reach it. Ballast offers to migrate
        /// it out of the build.
        /// </summary>
        /// <remarks>
        /// ⛔ READ THE NAME LITERALLY. It is <c>Unreached</c>, never <c>Unused</c>. Ballast has
        /// proven that nothing in the scanned C# asks for this path; it has NOT proven the asset is
        /// dead. An AssetBundle, a scripted build step, a native plugin or code this scanner never
        /// saw could still want it — which is why the action offered is a reversible MIGRATION and
        /// never a delete.
        /// </remarks>
        Unreached = 1,

        /// <summary>
        /// A dynamic load site could reach this path, so the question is undecidable and Ballast
        /// will not touch it.
        /// </summary>
        /// <remarks>
        /// This is the verdict that earns the price. Anyone can hide a folder the buyer points at;
        /// the value here is saying precisely WHICH assets cannot be reasoned about and why.
        /// </remarks>
        Indeterminate = 2,
    }

    /// <summary>One asset in a Resources folder, with its verdict and the evidence for it.</summary>
    public readonly struct AssetVerdict
    {
        /// <summary>Resource path, normalised (no extension, forward slashes).</summary>
        public readonly string ResourcePath;

        /// <summary>Project-relative asset path, e.g. <c>Assets/Art/Resources/icons/sword.png</c>.</summary>
        public readonly string AssetPath;

        /// <summary>Size on disk in bytes. This is what the tonnage figures are built from.</summary>
        public readonly long Bytes;

        public readonly Verdict Verdict;

        /// <summary>
        /// The load sites responsible for the verdict — the exact match for
        /// <see cref="Verdict.Reached"/>, or every site that could reach it for
        /// <see cref="Verdict.Indeterminate"/>. Empty for <see cref="Verdict.Unreached"/>.
        /// </summary>
        /// <remarks>
        /// A verdict with no citation is a reporter's output. This product asks the buyer to let it
        /// move files, so every non-trivial verdict has to be auditable back to a line of their code.
        /// </remarks>
        public readonly IReadOnlyList<LoadSite> Because;

        public AssetVerdict(string? resourcePath, string? assetPath, long bytes, Verdict verdict, IReadOnlyList<LoadSite>? because)
        {
            ResourcePath = resourcePath ?? string.Empty;
            AssetPath = assetPath ?? string.Empty;
            Bytes = bytes;
            Verdict = verdict;
            Because = because ?? new List<LoadSite>();
        }
    }

    /// <summary>
    /// Joins the Resources inventory to the scanned load sites and produces one verdict per asset.
    /// </summary>
    public static class Reachability
    {
        /// <summary>
        /// Classifies every asset.
        /// </summary>
        /// <param name="assets">
        /// (resourcePath, assetPath, bytes) for every asset under every <c>Resources</c> folder.
        /// </param>
        /// <param name="sites">Every load site found in the project's C#.</param>
        /// <remarks>
        /// ⛔ THE ORDER OF THE TESTS IS THE SAFETY MODEL AND MUST NOT BE REARRANGED. An exact
        /// literal match wins first, so an asset that is genuinely loaded reads <c>Reached</c> with a
        /// citation rather than being lumped in with the untouchable ones. Everything a dynamic site
        /// could reach is <c>Indeterminate</c>. Only what NOTHING can reach is offered for
        /// migration, so <c>Unreached</c> is the narrowest of the three sets by construction.
        /// <para>
        /// ⚠️ A single <see cref="LoadPrecision.Opaque"/> site anywhere in the project makes every
        /// asset <c>Indeterminate</c> and Ballast will migrate nothing. That is not a bug and it is
        /// not a failure — it is the correct answer to "which assets are unreachable when the code
        /// can ask for any of them by a name computed at runtime". The window says so in those
        /// terms, and names the call site to narrow.
        /// </para>
        /// </remarks>
        public static List<AssetVerdict> Classify(
            IEnumerable<(string resourcePath, string assetPath, long bytes)>? assets,
            IReadOnlyList<LoadSite>? sites)
        {
            var results = new List<AssetVerdict>();
            if (assets == null) return results;
            var all = sites ?? new List<LoadSite>();

            foreach (var (resourcePath, assetPath, bytes) in assets)
            {
                string path = LoadSiteScanner.NormalisePath(resourcePath);

                LoadSite? exact = null;
                var reaching = new List<LoadSite>();

                foreach (var s in all)
                {
                    if (!s.CouldReach(path)) continue;
                    reaching.Add(s);

                    if (exact == null && s.Precision == LoadPrecision.Literal && !s.IsLoadAll)
                        exact = s;
                }

                if (exact.HasValue)
                {
                    results.Add(new AssetVerdict(path, assetPath, bytes, Verdict.Reached,
                        new List<LoadSite> { exact.Value }));
                }
                else if (reaching.Count > 0)
                {
                    results.Add(new AssetVerdict(path, assetPath, bytes, Verdict.Indeterminate, reaching));
                }
                else
                {
                    results.Add(new AssetVerdict(path, assetPath, bytes, Verdict.Unreached,
                        new List<LoadSite>()));
                }
            }

            return results;
        }

        /// <summary>
        /// True when at least one site is fully opaque, i.e. nothing in Resources can be reasoned
        /// about until the buyer narrows that call site.
        /// </summary>
        /// <remarks>
        /// Exposed separately because the window must lead with this rather than showing a table of
        /// identical Indeterminate rows and letting the buyer work out why.
        /// </remarks>
        public static bool HasOpaqueSite(IReadOnlyList<LoadSite>? sites, out LoadSite first)
        {
            first = default;
            if (sites == null) return false;
            foreach (var s in sites)
            {
                if (s.Precision == LoadPrecision.Opaque) { first = s; return true; }
            }
            return false;
        }

        /// <summary>Total bytes carried by the assets holding a given verdict.</summary>
        public static long BytesWith(IReadOnlyList<AssetVerdict>? verdicts, Verdict verdict)
        {
            long sum = 0;
            if (verdicts == null) return 0;
            foreach (var v in verdicts)
                if (v.Verdict == verdict) sum += v.Bytes;
            return sum;
        }

        /// <summary>Number of assets holding a given verdict.</summary>
        public static int CountWith(IReadOnlyList<AssetVerdict>? verdicts, Verdict verdict)
        {
            int n = 0;
            if (verdicts == null) return 0;
            foreach (var v in verdicts)
                if (v.Verdict == verdict) n++;
            return n;
        }
    }
}
