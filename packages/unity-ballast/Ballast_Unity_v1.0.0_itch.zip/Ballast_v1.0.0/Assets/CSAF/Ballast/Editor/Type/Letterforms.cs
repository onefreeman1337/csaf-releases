// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.
#nullable enable

using System.Collections.Generic;
using UnityEngine;

namespace CSAF.Ballast
{
    /// <summary>
    /// The struck alphabet: hand-authored Roman capitals, tabular figures and the marks a lading
    /// certificate prints, every one drawn as geometry rather than set in a font.
    /// </summary>
    /// <remarks>
    /// <para>
    /// ⭐ <b>A CERTIFICATE IS FOLDER NAMES AND BYTE FIGURES, SO WITHOUT TYPE THERE IS NO PRODUCT.</b>
    /// Ballast's whole visible output is a document that states what was weighed and what was moved:
    /// <c>Assets/Art/Resources/icons</c> against <c>4.7 MB</c>, and a displacement figure a buyer
    /// screenshots. A plate that cannot cut those words and those digits into its own face is not a
    /// certificate, it is a blank form — and this product would be back to the default
    /// <c>EditorWindow</c> with an IMGUI list that its own Gate 1 risk names.
    /// </para>
    /// <para>
    /// ⚠️ Note the figures here are TABULAR — every digit advances by the same width — because a
    /// tonnage column whose rows do not align reads as sloppy arithmetic even when the arithmetic is
    /// right. That property matters more on a ledger than it did on the donor face this was ported
    /// from, where the numbers stood alone rather than in a column.
    /// </para>
    /// <para>
    /// ⛔ <b>AND THAT IS WHY THE LETTERS ARE DRAWN AND NOT SET.</b> Shipping a font would inherit a
    /// licence this package cannot grant; using the buyer's font would drag in the dynamic-font atlas,
    /// which this wing has already been bitten by — a runtime bake in a single synchronous frame
    /// renders NOTHING because the atlas has not been asked for the characters yet, and the result is
    /// a perfectly clean plate with no words on it and no error anywhere. Geometry has no atlas, no
    /// frame dependency and no licence.
    /// </para>
    /// <para>
    /// ⚠️ <b>COVERAGE IS THE HONEST LIMIT AND IT IS HANDLED VISIBLY, NOT SILENTLY.</b> This is a
    /// Latin display face: A–Z, 0–9 and the marks below. A Japanese or Cyrillic title cannot be
    /// struck, and the two obvious behaviours are both wrong — dropping the characters prints a
    /// mangled word, and drawing a placeholder box per character posts a row of tofu to a social
    /// feed. <see cref="TypeSetter"/> therefore refuses the WHOLE field, names it in the plan, and
    /// leaves the rect for the buyer to draw into with their own text. Accented Latin folds to its
    /// base letter first, so "CAFÉ" strikes rather than being refused.
    /// </para>
    /// <para>
    /// ⚠️ <b>SKELETONS, NOT OUTLINES.</b> Every letter is a short list of polylines stroked to one
    /// weight. Outlines would be prettier per glyph, take five times the authoring, drift in weight
    /// between letters, and could not be re-weighted; with skeletons, "strike the title heavier than
    /// the date band" is one multiplier. The sibling Errantry product records the same reasoning for
    /// its illuminated initials, and this face is the same technique carrying a different job.
    /// </para>
    /// <para>
    /// ⛔ <b>THE POLYLINES ARE BUILT ONCE AND CACHED, AND THAT IS A CORRECTNESS PROPERTY RATHER THAN
    /// AN OPTIMISATION.</b> <see cref="Shapes.SdSpine"/> takes arrays; building them inside the
    /// fill lambda would allocate two arrays PER SAMPLED PIXEL, which on a 1100x1500 certificate at
    /// 2x supersampling is millions of allocations per plate and a garbage collection in the middle
    /// of the compose the buyer pressed a button to start.
    /// </para>
    /// </remarks>
    public static class Letterforms
    {
        /// <summary>Cap height. Every letter sits on v = 0 and reaches v = 1.</summary>
        public const float CapHeight = 1f;

        /// <summary>Half the stroke weight, in em units.</summary>
        /// <remarks>
        /// 0.075 against a cap height of 1 is a stroke of 15% — a display weight. Lighter reads as a
        /// hairline and disappears at the size a date band strikes; heavier closes the counters of
        /// B, 8 and 0, which is the failure that makes small type read as smudges.
        /// </remarks>
        public const float Weight = 0.075f;

        /// <summary>Side bearing added to each glyph's ink width to give its advance.</summary>
        private const float Bearing = 0.20f;

        /// <summary>One struck character: its strokes, and how far the pen moves after it.</summary>
        public sealed class Glyph
        {
            /// <summary>The stroke skeletons, in em units with the baseline at v = 0.</summary>
            public readonly Vector2[][] Strokes;

            /// <summary>Per-point half-widths, one array per stroke, matching <see cref="Strokes"/>.</summary>
            public readonly float[][] Widths;

            /// <summary>How far the pen advances after striking this glyph, in em units.</summary>
            public readonly float Advance;

            /// <summary>Ink extents (minU, minV, maxU, maxV) BEFORE the stroke weight is added.</summary>
            public readonly Vector4 Extents;

            /// <summary>Builds a glyph from its strokes.</summary>
            /// <param name="inkWidth">Width of the drawn skeleton, before side bearings.</param>
            /// <param name="strokes">The stroke skeletons.</param>
            public Glyph(float inkWidth, Vector2[][] strokes)
            {
                Strokes = strokes;
                Advance = inkWidth + Bearing;

                Widths = new float[strokes.Length][];
                float minU = float.MaxValue, minV = float.MaxValue;
                float maxU = float.MinValue, maxV = float.MinValue;
                for (int i = 0; i < strokes.Length; i++)
                {
                    var w = new float[strokes[i].Length];
                    for (int j = 0; j < w.Length; j++)
                    {
                        w[j] = Weight;
                        Vector2 p = strokes[i][j];
                        if (p.x < minU) minU = p.x;
                        if (p.x > maxU) maxU = p.x;
                        if (p.y < minV) minV = p.y;
                        if (p.y > maxV) maxV = p.y;
                    }
                    Widths[i] = w;
                }

                // A glyph with no strokes (the space) has no ink, and an extent of ±MaxValue would
                // make every bounds rectangle derived from it cover the whole surface — which is
                // §22o's "Fill with no bounds walks the whole surface" arriving through the back door.
                if (strokes.Length == 0) { minU = minV = maxU = maxV = 0f; }

                Extents = new Vector4(minU - Weight, minV - Weight, maxU + Weight, maxV + Weight);
            }

            /// <summary>Signed distance to this glyph, in em units with the origin at its left baseline.</summary>
            /// <param name="u">Sample U.</param>
            /// <param name="v">Sample V.</param>
            /// <returns>Negative inside the strokes.</returns>
            public float Distance(float u, float v)
            {
                float best = 1e9f;
                for (int i = 0; i < Strokes.Length; i++)
                {
                    float d = Shapes.SdSpine(u, v, Strokes[i], Widths[i]);
                    if (d < best) best = d;
                }
                return best;
            }
        }

        private static Dictionary<char, Glyph>? _table;

        /// <summary>The struck glyph for a character, or null when the face cannot strike it.</summary>
        /// <param name="ch">The character, already folded and upper-cased by <see cref="Fold"/>.</param>
        /// <returns>The glyph, or null.</returns>
        public static Glyph? Get(char ch)
        {
            _table ??= Build();
            return _table.TryGetValue(ch, out Glyph g) ? g : null;
        }

        /// <summary>Every character this face can strike, for tests and for the Editor window.</summary>
        /// <returns>The supported characters.</returns>
        public static IEnumerable<char> Supported()
        {
            _table ??= Build();
            return _table.Keys;
        }

        /// <summary>
        /// Folds a character toward something the face can strike: upper-cases it, and reduces the
        /// common accented Latin letters to their base.
        /// </summary>
        /// <param name="ch">The character.</param>
        /// <returns>The folded character, which may still be unsupported.</returns>
        /// <remarks>
        /// ⚠️ Deliberately a SMALL, EXPLICIT table rather than Unicode normalisation. A run through
        /// <c>Normalize(NormalizationForm.FormD)</c> plus a category filter would fold far more, and
        /// would also silently fold Greek and Cyrillic letters that merely LOOK Latin into the wrong
        /// letter — "РУС" would strike as "PYC". Refusing a field is recoverable; misspelling one on
        /// an image a player posts is not.
        /// </remarks>
        public static char Fold(char ch)
        {
            switch (ch)
            {
                case 'á': case 'à': case 'â': case 'ä': case 'ã': case 'å':
                case 'Á': case 'À': case 'Â': case 'Ä': case 'Ã': case 'Å': return 'A';
                case 'é': case 'è': case 'ê': case 'ë':
                case 'É': case 'È': case 'Ê': case 'Ë': return 'E';
                case 'í': case 'ì': case 'î': case 'ï':
                case 'Í': case 'Ì': case 'Î': case 'Ï': return 'I';
                case 'ó': case 'ò': case 'ô': case 'ö': case 'õ': case 'ø':
                case 'Ó': case 'Ò': case 'Ô': case 'Ö': case 'Õ': case 'Ø': return 'O';
                case 'ú': case 'ù': case 'û': case 'ü':
                case 'Ú': case 'Ù': case 'Û': case 'Ü': return 'U';
                case 'ç': case 'Ç': return 'C';
                case 'ñ': case 'Ñ': return 'N';
                case 'ý': case 'ÿ': case 'Ý': return 'Y';
                case '–': case '—': return '-';   // en and em dash
                case '’': case '‘': return '\'';  // curly quotes
                default: return char.ToUpperInvariant(ch);
            }
        }

        // ── construction helpers ────────────────────────────────────────────────────────────────

        /// <summary>A straight stroke.</summary>
        /// <param name="x0">Start U.</param>
        /// <param name="y0">Start V.</param>
        /// <param name="x1">End U.</param>
        /// <param name="y1">End V.</param>
        /// <returns>A two-point spine.</returns>
        private static Vector2[] L(float x0, float y0, float x1, float y1)
            => new[] { new Vector2(x0, y0), new Vector2(x1, y1) };

        /// <summary>A free polyline, from flat x,y pairs.</summary>
        /// <param name="xy">Alternating U and V.</param>
        /// <returns>A spine.</returns>
        private static Vector2[] P(params float[] xy)
        {
            var pts = new Vector2[xy.Length / 2];
            for (int i = 0; i < pts.Length; i++) pts[i] = new Vector2(xy[i * 2], xy[i * 2 + 1]);
            return pts;
        }

        /// <summary>
        /// An elliptical arc, sampled into a spine.
        /// </summary>
        /// <param name="cx">Centre U.</param>
        /// <param name="cy">Centre V.</param>
        /// <param name="rx">Half-width.</param>
        /// <param name="ry">Half-height.</param>
        /// <param name="fromDeg">Start angle, degrees, 0 = +U, counter-clockwise.</param>
        /// <param name="toDeg">End angle, degrees.</param>
        /// <returns>A spine.</returns>
        /// <remarks>
        /// ⭐ <b>ELLIPTICAL, WHICH IS WHY THE FACE HOLDS TOGETHER.</b> A circular arc primitive only
        /// knows circles, and a circular O that reaches both the baseline and the cap height is
        /// necessarily one em WIDE — which would force every round letter to be 60% wider than every
        /// straight one and make the alphabet read as two different faces. Sampling the ellipse into
        /// a polyline costs nothing and lets O sit at 0.62 beside H at 0.56.
        /// ⚠️ Sample count is deliberately modest: <see cref="Shapes.SdSpine"/> is linear in
        /// segments and runs per sampled pixel, so an over-sampled ellipse is paid for on every pixel
        /// of every letter of every certificate.
        /// </remarks>
        private static Vector2[] E(float cx, float cy, float rx, float ry, float fromDeg, float toDeg)
        {
            float sweep = Mathf.Abs(toDeg - fromDeg);
            int n = Mathf.Max(4, Mathf.CeilToInt(sweep / 22.5f)) + 1;
            var pts = new Vector2[n];
            for (int i = 0; i < n; i++)
            {
                float t = fromDeg + (toDeg - fromDeg) * (i / (float)(n - 1));
                float r = t * Mathf.Deg2Rad;
                pts[i] = new Vector2(cx + rx * Mathf.Cos(r), cy + ry * Mathf.Sin(r));
            }
            return pts;
        }

        /// <summary>A round dot, as a degenerate stroke.</summary>
        /// <param name="x">Centre U.</param>
        /// <param name="y">Centre V.</param>
        /// <returns>A spine of two nearly-coincident points.</returns>
        /// <remarks>
        /// <see cref="Shapes.SdSpine"/> returns "outside" for fewer than two points, so a dot is a
        /// segment short enough to be a disc of the stroke weight. Its length is not zero because a
        /// zero-length capsule is a degenerate case in the distance function rather than a circle.
        /// </remarks>
        private static Vector2[] Dot(float x, float y)
            => new[] { new Vector2(x, y), new Vector2(x + 0.004f, y) };

        /// <summary>Builds the table once.</summary>
        /// <returns>The face.</returns>
        private static Dictionary<char, Glyph> Build()
        {
            var t = new Dictionary<char, Glyph>(64);

            // ── capitals ────────────────────────────────────────────────────────────────────────
            t['A'] = new Glyph(0.60f, new[] { L(0f, 0f, 0.30f, 1f), L(0.30f, 1f, 0.60f, 0f), L(0.09f, 0.30f, 0.51f, 0.30f) });
            t['B'] = new Glyph(0.56f, new[]
            {
                L(0f, 0f, 0f, 1f), L(0f, 1f, 0.26f, 1f), E(0.26f, 0.75f, 0.26f, 0.25f, 90f, -90f),
                L(0.26f, 0.50f, 0f, 0.50f), E(0.28f, 0.25f, 0.28f, 0.25f, 90f, -90f), L(0.28f, 0f, 0f, 0f),
            });
            t['C'] = new Glyph(0.62f, new[] { E(0.32f, 0.50f, 0.30f, 0.50f, 55f, 305f) });
            t['D'] = new Glyph(0.58f, new[]
            {
                L(0f, 0f, 0f, 1f), L(0f, 1f, 0.24f, 1f), E(0.24f, 0.50f, 0.34f, 0.50f, 90f, -90f), L(0.24f, 0f, 0f, 0f),
            });
            t['E'] = new Glyph(0.54f, new[] { L(0f, 0f, 0f, 1f), L(0f, 1f, 0.54f, 1f), L(0f, 0.50f, 0.44f, 0.50f), L(0f, 0f, 0.54f, 0f) });
            t['F'] = new Glyph(0.54f, new[] { L(0f, 0f, 0f, 1f), L(0f, 1f, 0.54f, 1f), L(0f, 0.50f, 0.44f, 0.50f) });
            // ⛔ THE BAR WAS A DETACHED TICK FLOATING IN THE MOUTH OF A C. Measured 2026-09-02 on the
            // first specimen: the bowl ran 55° to 300°, which ENDS AT THE BOTTOM of the ellipse at
            // (0.47, 0.07), while the bar and its stem were authored at x = 0.62 — the ellipse's
            // rightmost sample, reached only at 0°, an angle the sweep deliberately excludes because
            // that is what makes a G open on the right. So the two pieces could never have touched.
            // The bowl now runs to 330°, which lands exactly on (0.58, 0.25) where the stem begins.
            // ⭐ Nothing numeric could see it: the letter drew, filled its tile, matched its declared
            // extents and passed the bounds comparison. It is a LOOKING defect, and it was found by
            // reading the word "LONG" on the specimen line.
            t['G'] = new Glyph(0.60f, new[]
            {
                E(0.32f, 0.50f, 0.30f, 0.50f, 55f, 330f), L(0.58f, 0.25f, 0.58f, 0.47f), L(0.36f, 0.47f, 0.58f, 0.47f),
            });
            t['H'] = new Glyph(0.56f, new[] { L(0f, 0f, 0f, 1f), L(0.56f, 0f, 0.56f, 1f), L(0f, 0.50f, 0.56f, 0.50f) });
            t['I'] = new Glyph(0.00f, new[] { L(0f, 0f, 0f, 1f) });
            t['J'] = new Glyph(0.36f, new[] { L(0.36f, 1f, 0.36f, 0.26f), E(0.18f, 0.26f, 0.18f, 0.26f, 0f, -180f) });
            t['K'] = new Glyph(0.54f, new[] { L(0f, 0f, 0f, 1f), L(0.52f, 1f, 0.02f, 0.44f), L(0.14f, 0.55f, 0.54f, 0f) });
            t['L'] = new Glyph(0.50f, new[] { L(0f, 1f, 0f, 0f), L(0f, 0f, 0.50f, 0f) });
            t['M'] = new Glyph(0.68f, new[] { L(0f, 0f, 0f, 1f), L(0f, 1f, 0.34f, 0.30f), L(0.34f, 0.30f, 0.68f, 1f), L(0.68f, 1f, 0.68f, 0f) });
            t['N'] = new Glyph(0.58f, new[] { L(0f, 0f, 0f, 1f), L(0f, 1f, 0.58f, 0f), L(0.58f, 0f, 0.58f, 1f) });
            t['O'] = new Glyph(0.62f, new[] { E(0.31f, 0.50f, 0.31f, 0.50f, 0f, 360f) });
            t['P'] = new Glyph(0.56f, new[]
            {
                L(0f, 0f, 0f, 1f), L(0f, 1f, 0.28f, 1f), E(0.28f, 0.745f, 0.28f, 0.255f, 90f, -90f), L(0.28f, 0.49f, 0f, 0.49f),
            });
            t['Q'] = new Glyph(0.62f, new[] { E(0.31f, 0.50f, 0.31f, 0.50f, 0f, 360f), L(0.38f, 0.22f, 0.62f, -0.06f) });
            t['R'] = new Glyph(0.58f, new[]
            {
                L(0f, 0f, 0f, 1f), L(0f, 1f, 0.28f, 1f), E(0.28f, 0.745f, 0.28f, 0.255f, 90f, -90f),
                L(0.28f, 0.49f, 0f, 0.49f), L(0.26f, 0.49f, 0.58f, 0f),
            });
            t['S'] = new Glyph(0.58f, new[]
            {
                P(0.56f, 0.84f, 0.46f, 0.97f, 0.28f, 1.00f, 0.10f, 0.96f, 0.02f, 0.83f, 0.04f, 0.70f,
                  0.16f, 0.60f, 0.34f, 0.53f, 0.50f, 0.45f, 0.58f, 0.33f, 0.56f, 0.18f, 0.44f, 0.05f,
                  0.26f, 0.01f, 0.10f, 0.05f, 0.02f, 0.16f),
            });
            t['T'] = new Glyph(0.56f, new[] { L(0f, 1f, 0.56f, 1f), L(0.28f, 1f, 0.28f, 0f) });
            t['U'] = new Glyph(0.58f, new[] { L(0f, 1f, 0f, 0.28f), E(0.29f, 0.28f, 0.29f, 0.28f, 180f, 360f), L(0.58f, 0.28f, 0.58f, 1f) });
            t['V'] = new Glyph(0.58f, new[] { L(0f, 1f, 0.29f, 0f), L(0.29f, 0f, 0.58f, 1f) });
            t['W'] = new Glyph(0.76f, new[] { L(0f, 1f, 0.18f, 0f), L(0.18f, 0f, 0.38f, 0.72f), L(0.38f, 0.72f, 0.58f, 0f), L(0.58f, 0f, 0.76f, 1f) });
            t['X'] = new Glyph(0.56f, new[] { L(0f, 1f, 0.56f, 0f), L(0f, 0f, 0.56f, 1f) });
            t['Y'] = new Glyph(0.56f, new[] { L(0f, 1f, 0.28f, 0.50f), L(0.56f, 1f, 0.28f, 0.50f), L(0.28f, 0.50f, 0.28f, 0f) });
            t['Z'] = new Glyph(0.56f, new[] { L(0f, 1f, 0.56f, 1f), L(0.56f, 1f, 0f, 0f), L(0f, 0f, 0.56f, 0f) });

            // ── figures ─────────────────────────────────────────────────────────────────────────
            // ⛔ TABULAR. Every digit carries the SAME advance whatever its ink width, so a column of
            // values lines up. Proportional figures would set "1,240" narrower than "8,888" and the
            // right-aligned TONNAGE column would visibly stagger — the one place on the certificate
            // where the eye is explicitly comparing one folder's weight against another's.
            AddFigure(t, '0', new[] { E(0.28f, 0.50f, 0.28f, 0.50f, 0f, 360f) });
            AddFigure(t, '1', new[] { L(0.08f, 0.80f, 0.28f, 1.00f), L(0.28f, 1.00f, 0.28f, 0f), L(0.06f, 0f, 0.50f, 0f) });
            AddFigure(t, '2', new[]
            {
                P(0.02f, 0.78f, 0.08f, 0.93f, 0.22f, 1.00f, 0.38f, 0.98f, 0.50f, 0.88f, 0.52f, 0.74f,
                  0.44f, 0.58f, 0.26f, 0.38f, 0.02f, 0.03f),
                L(0.02f, 0.03f, 0.54f, 0.03f),
            });
            AddFigure(t, '3', new[]
            {
                P(0.03f, 0.86f, 0.11f, 0.97f, 0.27f, 1.00f, 0.43f, 0.95f, 0.50f, 0.84f, 0.46f, 0.71f, 0.30f, 0.62f, 0.18f, 0.60f),
                P(0.18f, 0.60f, 0.36f, 0.58f, 0.50f, 0.48f, 0.54f, 0.32f, 0.48f, 0.14f, 0.32f, 0.02f, 0.14f, 0.02f, 0.03f, 0.12f),
            });
            AddFigure(t, '4', new[] { L(0.42f, 0f, 0.42f, 1f), L(0.42f, 1f, 0.02f, 0.28f), L(0.02f, 0.28f, 0.56f, 0.28f) });
            AddFigure(t, '5', new[]
            {
                L(0.50f, 1f, 0.10f, 1f), L(0.10f, 1f, 0.06f, 0.62f),
                P(0.06f, 0.62f, 0.20f, 0.69f, 0.36f, 0.67f, 0.48f, 0.57f, 0.54f, 0.40f, 0.50f, 0.20f, 0.36f, 0.06f, 0.18f, 0.03f, 0.04f, 0.10f),
            });
            AddFigure(t, '6', new[]
            {
                P(0.50f, 0.90f, 0.40f, 0.99f, 0.26f, 1.00f, 0.14f, 0.92f, 0.05f, 0.72f, 0.02f, 0.46f),
                E(0.28f, 0.27f, 0.26f, 0.27f, 0f, 360f),
            });
            AddFigure(t, '7', new[] { L(0.02f, 1f, 0.56f, 1f), L(0.56f, 1f, 0.22f, 0f) });
            AddFigure(t, '8', new[] { E(0.28f, 0.745f, 0.24f, 0.255f, 0f, 360f), E(0.28f, 0.265f, 0.27f, 0.265f, 0f, 360f) });
            AddFigure(t, '9', new[]
            {
                E(0.28f, 0.73f, 0.26f, 0.27f, 0f, 360f),
                P(0.06f, 0.10f, 0.16f, 0.01f, 0.30f, 0.00f, 0.42f, 0.08f, 0.51f, 0.28f, 0.54f, 0.54f),
            });

            // ── marks a lading certificate prints ───────────────────────────────────────────────
            t[' '] = new Glyph(0.10f, new Vector2[0][]);
            // ⛔ THE UNDERSCORE IS NOT DECORATION, IT IS A CORRECTNESS FIX FOR THIS PRODUCT AND IT
            // WAS ABSENT FROM THE FACE THIS WAS PORTED FROM. The donor set player names and scores,
            // which never contain one. Ballast sets FILE PATHS, where "Assets/UI_Icons/Resources" is
            // completely ordinary — and TypeSetter refuses a line containing any character the face
            // cannot strike, deliberately and correctly, so without this glyph that row would print
            // NOTHING AT ALL. A blank row on a manifest is the worst available failure here: it does
            // not look broken, it looks like the folder was not found.
            // ⚠️ It sits BELOW the baseline (v = -0.14) like a real underscore. Drawing it on the
            // baseline would make "A_B" read as "A-B", which is a different path.
            t['_'] = new Glyph(0.52f, new[] { L(0.02f, -0.14f, 0.52f, -0.14f) });
            t['.'] = new Glyph(0.06f, new[] { Dot(0.06f, 0.05f) });
            t[','] = new Glyph(0.06f, new[] { L(0.08f, 0.06f, 0.02f, -0.16f) });
            t[':'] = new Glyph(0.06f, new[] { Dot(0.06f, 0.08f), Dot(0.06f, 0.62f) });
            t['-'] = new Glyph(0.34f, new[] { L(0.02f, 0.46f, 0.34f, 0.46f) });
            t['/'] = new Glyph(0.42f, new[] { L(0.02f, -0.04f, 0.42f, 1.04f) });
            t['+'] = new Glyph(0.44f, new[] { L(0.02f, 0.48f, 0.44f, 0.48f), L(0.23f, 0.27f, 0.23f, 0.69f) });
            t['\''] = new Glyph(0.06f, new[] { L(0.06f, 1.00f, 0.03f, 0.76f) });
            t['!'] = new Glyph(0.08f, new[] { L(0.06f, 1f, 0.06f, 0.28f), Dot(0.06f, 0.05f) });
            t['?'] = new Glyph(0.50f, new[]
            {
                P(0.03f, 0.80f, 0.09f, 0.94f, 0.24f, 1.00f, 0.40f, 0.95f, 0.48f, 0.82f, 0.45f, 0.68f, 0.30f, 0.56f, 0.25f, 0.44f, 0.25f, 0.32f),
                Dot(0.25f, 0.05f),
            });
            t['%'] = new Glyph(0.66f, new[]
            {
                E(0.15f, 0.81f, 0.13f, 0.15f, 0f, 360f), E(0.51f, 0.19f, 0.13f, 0.15f, 0f, 360f), L(0.02f, 0.04f, 0.64f, 0.96f),
            });
            t['×'] = new Glyph(0.34f, new[] { L(0.02f, 0.20f, 0.34f, 0.60f), L(0.02f, 0.60f, 0.34f, 0.20f) });
            // ⛔ THESE WERE TICKS, NOT PARENTHESES. A 60° sweep of a radius that large is very nearly
            // a straight line and only 0.56 tall, so "(NO DEATHS)" set with two commas beside it. A
            // paren is read from its CURVATURE and its HEIGHT, so both went up: a 100° sweep of a
            // smaller radius, spanning 0.10 to 0.90 of the cap.
            t['('] = new Glyph(0.16f, new[] { E(0.30f, 0.50f, 0.26f, 0.52f, 130f, 230f) });
            t[')'] = new Glyph(0.14f, new[] { E(-0.14f, 0.50f, 0.26f, 0.52f, 50f, -50f) });

            return t;
        }

        /// <summary>Adds a figure with the shared tabular advance.</summary>
        /// <param name="t">The face under construction.</param>
        /// <param name="ch">The digit.</param>
        /// <param name="strokes">Its strokes.</param>
        private static void AddFigure(Dictionary<char, Glyph> t, char ch, Vector2[][] strokes)
            => t[ch] = new Glyph(0.56f, strokes);
    }
}
