#nullable enable
// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

using System;
using System.Collections.Generic;
using UnityEngine;

namespace CSAF.Ballast
{
    /// <summary>
    /// Composes the lading certificate — the drawn document that is this product's entire visible
    /// output.
    /// </summary>
    /// <remarks>
    /// <para>
    /// ⛔ <b>WHY THIS IS A DRAWN DOCUMENT AND NOT AN IMGUI LIST.</b> The record that authorised this
    /// build names the risk in terms: a build-weight ledger plus a byte delta is "the exact shape
    /// that reads as a default EditorWindow with an IMGUI list if nobody designs it". A table of
    /// numbers is what every auditor on this shelf already ships, and the shelf read that cleared
    /// this product found that the only listing with proven purchases is the one that ACTS. So the
    /// certificate is the artefact: something a technical director attaches to a build ticket, and
    /// something a buyer screenshots.
    /// </para>
    /// <para>
    /// ⛔ <b>THREE DRAWING LANGUAGES, NEVER THREE COLOURS.</b> Reached tonnage is struck SOLID,
    /// unreached is an OPEN OUTLINE, indeterminate is HATCHED. A store screenshot is met at thumbnail
    /// size, is often rendered greyscale by a feed, and roughly one man in twelve cannot separate two
    /// arbitrary hues — so the one distinction a buyer must never misread, which bytes Ballast
    /// refused to touch, is carried by texture and not by tint.
    /// </para>
    /// <para>
    /// ⚠️ <b>SUPERSAMPLED AT 2, NOT 4, AND THAT IS A MEASURED DECISION.</b> A surface costs about
    /// 16 × s² × 4 bytes of managed float per output pixel, so this plate at s=4 would hold roughly
    /// 420 MB before a line is drawn — on a machine where every wing now starts at every wave. At
    /// s=2 it is about 105 MB. Nothing here is a fine radial detail: the plate is rules, bars,
    /// hatching and type, and 4 samples per pixel is ample for all four.
    /// </para>
    /// <para>
    /// ⚠️ <b>COMPOSE COST IS LINEAR IN PIXELS AND IS PUBLISHED RATHER THAN GUESSED.</b> This wing has
    /// shipped a Readme claiming "tens of milliseconds" for work that measured 16.7 seconds. The
    /// window composes ON DEMAND and caches; nothing here runs on window open, on import or on build.
    /// </para>
    /// </remarks>
    public static class Certificate
    {
        /// <summary>Default plate width in pixels.</summary>
        public const int DefaultWidth = 1100;

        /// <summary>Default plate height in pixels.</summary>
        public const int DefaultHeight = 1500;

        /// <summary>Supersampling factor for the plate. See the remarks on this class.</summary>
        public const int PlateSuperSample = 2;

        // ⛔⛔ TRACKING IS PART OF A WIDTH, SO THE TRACKING USED TO MEASURE MUST BE THE TRACKING USED
        // TO STRIKE. Every fit in this file previously measured at TypeSetter's DEFAULT tracking and
        // then struck the same string at 0.13-0.16, which is a WIDER line than the one that was
        // fitted -- so a caption could clear its budget by arithmetic and still run into the frame.
        // The failure is silent, it is worse the longer the string, and it looks like a layout bug
        // in the layout file rather than an inconsistency between two arguments. Naming the values
        // once and passing them to BOTH calls is what makes the two impossible to separate.
        private const float TrackWord = 0.10f;   // the wordmark
        private const float TrackFigure = 0.04f; // the hero figure
        private const float TrackCaption = 0.22f;// small caps captions
        private const float TrackFine = 0.16f;   // fine print, counts, wrapped reasons
        private const float TrackFoot = 0.13f;   // the footer line

        /// <summary>Composes the certificate and resolves it to a texture.</summary>
        /// <param name="lading">What the certificate states.</param>
        /// <param name="width">Plate width in pixels.</param>
        /// <param name="height">Plate height in pixels.</param>
        /// <returns>The composed plate.</returns>
        public static Texture2D Compose(Lading lading, int width = DefaultWidth, int height = DefaultHeight)
            => Draw(lading, width, height).Resolve("Ballast Certificate");

        /// <summary>
        /// Composes the certificate onto a surface and returns it undrawn to a texture, so tests and
        /// the store renderer can measure the pixels directly.
        /// </summary>
        /// <param name="lading">What the certificate states.</param>
        /// <param name="width">Plate width in pixels.</param>
        /// <param name="height">Plate height in pixels.</param>
        /// <returns>The surface.</returns>
        public static Ink Draw(Lading lading, int width = DefaultWidth, int height = DefaultHeight)
        {
            if (lading == null) throw new ArgumentNullException(nameof(lading));

            var ink = new Ink(width, height, PlateSuperSample);
            var p = LadingPalette.Of(lading.Stock);
            var L = CertificateLayout.For(ink.Aspect);

            Ground(ink, p);
            Frame(ink, p, L);
            Header(ink, p, L, lading);

            if (lading.RefusedBecause != null && lading.RefusedBecause.Length > 0)
                Withheld(ink, p, L, lading);
            else
                Displacement(ink, p, L, lading);

            // ⛔ The chart RETURNS where it ended and the legend is struck there. Anchoring the
            // legend to a constant while the chart's height depends on the row count is two opinions
            // about one piece of geometry, and it left a blank band of up to 45% of the page between
            // the last bar and the legend — measured on the first bake, on every plate.
            float chartBottom = Chart(ink, p, L, lading);
            Legend(ink, p, L, lading, chartBottom);
            Stamp(ink, p, L, lading);
            Footer(ink, p, L, lading);

            return ink;
        }

        // ------------------------------------------------------------------ paper and furniture

        private static void Ground(Ink ink, in LadingPalette p)
        {
            ink.Clear(p.Ground);

            // A very slight vertical settle so the paper is not a flat fill. Written straight into
            // the surface as a gradient at one sample per pixel would be ideal, but Shade is the
            // available route and a smooth ramp has no edges to alias, so the cost is the cost.
            Color well = p.Well;
            Color ground = p.Ground;
            ink.Shade((x, y) =>
            {
                float t = Mathf.Clamp01((1f - y) * 0.5f);
                return Color.Lerp(ground, well, t * 0.35f);
            });
        }

        private static void Frame(Ink ink, in LadingPalette p, in CertificateLayout L)
        {
            float x0 = -L.A + L.Margin, x1 = L.A - L.Margin;
            float y0 = -1f + L.Margin, y1 = 1f - L.Margin;

            // ⚠️ Four EDGE STRIPS rather than one rectangle outline. An unbounded fill walks the whole
            // surface, and a single ribbon around the frame bounds to the whole page and then tests
            // every pixel against every segment. The strips overlap at the corners deliberately:
            // double-covering an antialiased edge with the same colour writes the same value twice,
            // so it is free.
            Rule(ink, p.Rule, x0, y1, x1, y1, 0.0055f);
            Rule(ink, p.Rule, x0, y0, x1, y0, 0.0055f);
            Rule(ink, p.Rule, x0, y0, x0, y1, 0.0055f);
            Rule(ink, p.Rule, x1, y0, x1, y1, 0.0055f);

            // The inner hairline, inset, which is what makes it read as a printed form rather than a
            // box drawn round a screenshot.
            float i = 0.012f;
            Rule(ink, p.Rule, x0 + i, y1 - i, x1 - i, y1 - i, 0.0018f);
            Rule(ink, p.Rule, x0 + i, y0 + i, x1 - i, y0 + i, 0.0018f);
            Rule(ink, p.Rule, x0 + i, y0 + i, x0 + i, y1 - i, 0.0018f);
            Rule(ink, p.Rule, x1 - i, y0 + i, x1 - i, y1 - i, 0.0018f);
        }

        private static void Rule(Ink ink, in Color c, float ax, float ay, float bx, float by, float w)
            => ink.Line(ax, ay, bx, by, w, c);

        // ------------------------------------------------------------------ header

        private static void Header(Ink ink, in LadingPalette p, in CertificateLayout L, Lading lading)
        {
            TypeSetter.Strike(ink, "BALLAST", L.ContentLeft, L.WordmarkBaseline, L.WordmarkEm,
                              p.Ink, Align.Left, TrackWord);

            TypeSetter.Strike(ink, "CERTIFICATE OF LADING", L.ContentLeft, L.WordmarkBaseline - 0.052f,
                              L.FineEm, p.Faint, Align.Left, TrackCaption);

            // Consignee block, right aligned against the same content rail every other column uses.
            string project = Safe(lading.Project, "UNTITLED PROJECT");
            float projEm = TypeSetter.FitEm(project, (L.ContentRight - L.ContentLeft) * 0.52f,
                                            0.026f, 0.016f);
            project = TypeSetter.Shorten(project, (L.ContentRight - L.ContentLeft) * 0.52f, projEm)
                      ?? project;
            TypeSetter.Strike(ink, project, L.ContentRight, L.WordmarkBaseline, projEm,
                              p.Ink, Align.Right);

            TypeSetter.Strike(ink, Safe(lading.Dateline, ""), L.ContentRight,
                              L.WordmarkBaseline - 0.045f, L.FineEm, p.Faint, Align.Right, 0.14f);

            Rule(ink, p.Rule, L.ContentLeft, L.HeaderRuleY, L.ContentRight, L.HeaderRuleY, 0.0030f);
        }

        // ------------------------------------------------------------------ the hero figure

        private static void Displacement(Ink ink, in LadingPalette p, in CertificateLayout L, Lading lading)
        {
            TypeSetter.Strike(ink, "DISPLACEMENT AVAILABLE", L.ContentLeft, L.DisplacementCaptionY,
                              L.FineEm, p.Faint, Align.Left, 0.22f);

            string figure = Lading.FormatBytes(lading.DisplacementBytes);
            float avail = L.ContentRight - L.ContentLeft;
            float em = TypeSetter.FitEm(figure, avail, L.DisplacementEm, 0.050f, TrackFigure);
            TypeSetter.Strike(ink, figure, L.ContentLeft, L.DisplacementFigureY, em,
                              p.Ink, Align.Left, TrackFigure);

            // ⚠️ The foot line is what stops the hero figure being a number without a denominator. A
            // build-weight tool that prints "9.4 MB" and nothing else is asking to be quoted out of
            // context, including by us.
            string foot = lading.DisplacementCount.ToString(System.Globalization.CultureInfo.InvariantCulture)
                + " OF " + lading.TotalCount.ToString(System.Globalization.CultureInfo.InvariantCulture)
                + " ASSETS, OUT OF " + Lading.FormatBytes(lading.TotalBytes).ToUpperInvariant()
                + " UNDER RESOURCES";
            float footEm = TypeSetter.FitEm(foot, avail, L.FineEm, 0.012f, TrackFine);
            TypeSetter.Strike(ink, foot, L.ContentLeft, L.DisplacementFootY, footEm,
                              p.Faint, Align.Left, TrackFine);
        }

        /// <summary>
        /// The refusal state: drawn as a designed alternative, never as an error.
        /// </summary>
        /// <remarks>
        /// ⭐ One opaque call site anywhere in the project makes every asset under Resources
        /// indeterminate, and the correct answer is that Ballast will move nothing. That answer is
        /// worth as much as a chart — it tells the buyer exactly which line of their own code is
        /// costing them the whole analysis — so it is composed with the same care rather than being
        /// dropped out as a warning box.
        /// </remarks>
        private static void Withheld(Ink ink, in LadingPalette p, in CertificateLayout L, Lading lading)
        {
            TypeSetter.Strike(ink, "DISPLACEMENT WITHHELD", L.ContentLeft, L.DisplacementCaptionY,
                              L.FineEm, p.Faint, Align.Left, 0.22f);

            float avail = L.ContentRight - L.ContentLeft;
            float em = TypeSetter.FitEm("NOTHING MAY MOVE", avail, L.DisplacementEm * 0.62f, 0.040f, TrackFigure);
            TypeSetter.Strike(ink, "NOTHING MAY MOVE", L.ContentLeft, L.DisplacementFigureY, em,
                              p.Unreached, Align.Left, TrackFigure);

            // ⛔ THE REASON IS SET ON UP TO TWO LINES, NOT SHRUNK ONTO ONE. On the first bake this was
            // a single FitEm'd line: it reached the floor em, filled the whole measure, and ran into
            // the frame rule — a caption about a file and a line number, set too small to read, at
            // the exact moment the buyer most needs to read it. Wrapping keeps it at a legible size.
            string why = Safe(lading.RefusedBecause, "");
            float whyEm = L.FineEm;
            List<string> lines = Wrap(why, avail, whyEm, 3, TrackFine);
            for (int i = 0; i < lines.Count; i++)
                TypeSetter.Strike(ink, lines[i], L.ContentLeft, L.DisplacementFootY - 0.048f * i,
                                  whyEm, p.Faint, Align.Left, TrackFine);
        }

        // ------------------------------------------------------------------ the tonnage chart

        /// <summary>
        /// The height of one chart row for a given lading — published so anything cropping this
        /// plate can cut on a REAL row boundary.
        /// </summary>
        /// <param name="lading">The lading whose row count decides the height.</param>
        /// <param name="L">The layout.</param>
        /// <returns>Row height in normalised units, or 0 when there are no rows.</returns>
        /// <remarks>
        /// ⛔ <b>EXISTS BECAUSE A CROP WINDOW CHOSEN AS A FRACTION CUTS ROWS IN HALF.</b> A store
        /// plate cropped at "the chart top minus 0.235" sliced the second folder's name and its
        /// tonnage clean through the middle — a picture of a document with half a line of the
        /// buyer's own data in it. The composer is the only thing that knows where a row ends, so it
        /// is the only thing that may be asked. Callers derive their window from THIS, never from a
        /// number that happens to look right at one plate size.
        /// </remarks>
        public static float RowHeightFor(Lading lading, in CertificateLayout L)
        {
            if (lading == null || lading.Rows.Count == 0) return 0f;
            float span = L.ChartTop - L.ChartBottom;
            int shown = Mathf.Min(lading.Rows.Count,
                                  Mathf.Max(1, Mathf.FloorToInt(span / L.MinRowHeight)));
            return Mathf.Clamp(span / shown, L.MinRowHeight, L.MaxRowHeight);
        }

        /// <summary>Draws the tonnage chart and returns the V the last row ended at.</summary>
        private static float Chart(Ink ink, in LadingPalette p, in CertificateLayout L, Lading lading)
        {
            var rows = lading.Rows;
            if (rows.Count == 0)
            {
                TypeSetter.Strike(ink, "NO RESOURCES FOLDER IN THIS PROJECT", L.ContentLeft,
                                  L.ChartTop - 0.070f, L.PathEm, p.Ink, Align.Left, 0.14f);
                TypeSetter.Strike(ink, "NOTHING IN THIS PROJECT IS EXEMPT FROM UNITY'S OWN STRIPPING.",
                                  L.ContentLeft, L.ChartTop - 0.125f, L.FineEm, p.Faint, Align.Left, 0.16f);
                return L.ChartTop - 0.170f;
            }

            float span = L.ChartTop - L.ChartBottom;
            int shown = Mathf.Min(rows.Count, Mathf.Max(1, Mathf.FloorToInt(span / L.MinRowHeight)));
            // ⛔ The SAME function the store renderer crops against. Two places computing a row
            // height independently is how a crop window and a composer disagree about where a row
            // ends, which is the defect RowHeightFor was extracted to prevent.
            float rowH = RowHeightFor(lading, L);
            bool counts = rowH >= L.RowCountsThreshold;

            long heaviest = 1;
            for (int i = 0; i < shown; i++) heaviest = Math.Max(heaviest, rows[i].TotalBytes);

            // ⛔ ONE CAP HEIGHT FOR THE WHOLE COLUMN, measured over the longest path in the band
            // BEFORE anything is struck. Fitting each row independently sets some paths at full size
            // and others at 60% of it in the same column, which reads as ragged typography rather
            // than as a bug and which no numeric check in this package can express. A compositor sets
            // a column once, at the size its longest entry needs.
            float pathAvail = (L.BarRight - L.BarLeft) * 0.62f;
            float pathEm = L.PathEm;
            for (int i = 0; i < shown; i++)
            {
                float fit = TypeSetter.FitEm(Tidy(rows[i].Folder), pathAvail, L.PathEm, L.PathMinEm);
                if (fit < pathEm) pathEm = fit;
            }

            for (int i = 0; i < shown; i++)
            {
                float top = L.ChartTop - i * rowH;
                Row(ink, p, L, rows[i], heaviest, top, rowH, pathEm, counts);
            }

            float bottom = L.ChartTop - shown * rowH;

            // Honesty about truncation: a chart that silently shows the top eight of forty folders is
            // a chart that understates the problem it was drawn to describe.
            if (rows.Count > shown)
            {
                long rest = 0;
                for (int i = shown; i < rows.Count; i++) rest += rows[i].TotalBytes;
                string more = "AND " + (rows.Count - shown).ToString(System.Globalization.CultureInfo.InvariantCulture)
                    + " FURTHER FOLDERS CARRYING " + Lading.FormatBytes(rest).ToUpperInvariant();
                TypeSetter.Strike(ink, more, L.ContentLeft, bottom - 0.030f,
                                  L.FineEm * 0.95f, p.Faint, Align.Left, 0.16f);
                bottom -= 0.048f;
            }

            return bottom;
        }

        private static void Row(Ink ink, in LadingPalette p, in CertificateLayout L,
                                in LadingRow row, long heaviest, float top, float rowH, float pathEm,
                                bool counts)
        {
            // ⚠️ The three baselines are FRACTIONS of the row, so a row that grows to fill a short
            // chart stays proportioned instead of leaving its bar stranded at the top of a tall band.
            float textY = top - rowH * (counts ? 0.235f : 0.300f);
            float barY = top - rowH * (counts ? 0.520f : 0.700f);
            float countY = top - rowH * 0.760f;

            // Column A: the path. Column C: the tonnage, right aligned at the content rail. The two
            // are struck from ONE declared pair of edges so they cannot overlap.
            string tonnage = Lading.FormatBytes(row.TotalBytes).ToUpperInvariant();
            float tonWidth = TypeSetter.Measure(tonnage, pathEm);
            float pathRight = L.ContentRight - tonWidth - 0.030f;
            float pathAvail = Mathf.Max(0.05f, pathRight - L.ContentLeft);

            string path = Tidy(row.Folder);
            path = TypeSetter.Shorten(path, pathAvail, pathEm) ?? path;
            TypeSetter.Strike(ink, path, L.ContentLeft, textY, pathEm, p.Ink, Align.Left);
            TypeSetter.Strike(ink, tonnage, L.ContentRight, textY, pathEm, p.Ink, Align.Right);

            // The bar. Its full width is proportional to this folder's share of the heaviest folder,
            // so the chart reads as a comparison rather than as a set of unrelated percentages.
            float full = L.BarRight - L.BarLeft;
            float w = full * Mathf.Clamp01(row.TotalBytes / (float)heaviest);
            if (w < 0.006f) w = 0.006f;

            float x = L.BarLeft;
            float total = Mathf.Max(1f, row.TotalBytes);
            float wReached = w * (row.ReachedBytes / total);
            float wUnreached = w * (row.UnreachedBytes / total);
            float wIndet = w * (row.IndeterminateBytes / total);

            float h = L.BarHalfHeight;

            // 1. REACHED — struck solid. In use, and the heaviest mark on the chart.
            if (wReached > 0.0004f)
            {
                Segment(ink, p.Reached, x, barY, wReached, h, fill: true, hatch: false);
                x += wReached;
            }
            // 2. UNREACHED — an open outline. Hollow reads as removable, which is what it is.
            if (wUnreached > 0.0004f)
            {
                Segment(ink, p.Unreached, x, barY, wUnreached, h, fill: false, hatch: false);
                x += wUnreached;
            }
            // 3. INDETERMINATE — hatched. A different drawing language for the one class of bytes
            //    Ballast refuses to touch, so it survives greyscale and a thumbnail.
            if (wIndet > 0.0004f)
            {
                Segment(ink, p.Indeterminate, x, barY, wIndet, h, fill: false, hatch: true);
            }

            // The baseline the bars sit on, which is what makes their lengths comparable by eye.
            Rule(ink, p.Rule, L.BarLeft, barY - h - 0.006f, L.BarRight, barY - h - 0.006f, 0.0012f);

            // A tall row earns a third line of INFORMATION rather than a third line of air.
            if (!counts) return;
            var ci = System.Globalization.CultureInfo.InvariantCulture;
            string line = row.ReachedCount.ToString(ci) + " IN USE   "
                + row.UnreachedCount.ToString(ci) + " UNREACHED   "
                + row.IndeterminateCount.ToString(ci) + " WITHHELD";
            string share = row.TotalBytes <= 0 ? string.Empty :
                Mathf.RoundToInt(100f * row.UnreachedBytes / row.TotalBytes).ToString(ci)
                + "% OF THIS FOLDER CAN MOVE";

            // ⛔ Two strings on ONE baseline, one left and one right, so they share a span and have
            // to be budgeted against each other. The right-hand string is measured FIRST and the
            // left gets what remains — the same order the path/tonnage row above uses, and for the
            // same reason: the string whose width is fixed by its content claims its space first.
            float countEm = L.FineEm * 0.86f;
            float shareW = share.Length == 0 ? 0f : TypeSetter.Measure(share, countEm, TrackFine);
            float countAvail = Mathf.Max(0.05f, (L.ContentRight - shareW - 0.030f) - L.ContentLeft);
            line = TypeSetter.Shorten(line, countAvail, countEm, TrackFine) ?? line;

            TypeSetter.Strike(ink, line, L.ContentLeft, countY, countEm, p.Faint, Align.Left, TrackFine);
            if (share.Length > 0)
                TypeSetter.Strike(ink, share, L.ContentRight, countY, countEm, p.Faint,
                                  Align.Right, TrackFine);
        }

        private static void Segment(Ink ink, in Color c, float x, float cy, float w, float h,
                                    bool fill, bool hatch)
        {
            float cx = x + w * 0.5f;
            float hx = w * 0.5f;
            var bounds = new Vector4(cx - hx - 0.01f, cy - h - 0.01f, cx + hx + 0.01f, cy + h + 0.01f);

            if (fill)
            {
                ink.Fill((sx, sy) => Shapes.SdBox(sx, sy, cx, cy, hx, h, 0.004f), c, bounds);
                return;
            }

            if (hatch)
            {
                // Hatching CLIPPED to the segment: the max of the two distances is the intersection,
                // which is the whole reason both primitives return a distance rather than a boolean.
                // ⚠️ The pitch is chosen against the BAR HEIGHT, not once for the plate. Hatching
                // finer than a few output pixels aliases into a flat wash, which would collapse this
                // band back into a colour-only distinction — exactly what it exists to avoid.
                float pitch = h * 0.62f;
                float halfW = h * 0.13f;
                ink.Fill((sx, sy) => Mathf.Max(
                             Shapes.SdBox(sx, sy, cx, cy, hx, h, 0.004f),
                             Shapes.SdHatch45(sx, sy, pitch, halfW)), c, bounds);
            }

            // Both the outline and the hatched segment carry an edge, so a segment is never a floating
            // texture with no boundary.
            ink.Fill((sx, sy) => Mathf.Abs(Shapes.SdBox(sx, sy, cx, cy, hx, h, 0.004f)) - 0.0016f,
                     c, bounds);
        }

        // ------------------------------------------------------------------ legend, stamp, footer

        private static void Legend(Ink ink, in LadingPalette p, in CertificateLayout L, Lading lading,
                                   float chartBottom)
        {
            // Follows the chart, and never drops below the anchor the stamp is composed against.
            float y = Mathf.Max(L.LegendY, chartBottom - L.LegendGap);
            float h = L.BarHalfHeight * 0.85f;
            float swatch = 0.055f;
            float gap = 0.030f;

            // ⛔ The legend is struck from the SAME Segment routine the chart uses, so a swatch can
            // never drift from the thing it explains. A legend drawn by its own code is a second
            // opinion about the product's own visual language, and the two would disagree the first
            // time either moved.
            float x = L.ContentLeft;
            x = LegendItem(ink, p, L, x, y, swatch, h, gap, p.Reached, true, false,
                           "IN USE " + Lading.FormatBytes(lading.ReachedBytes).ToUpperInvariant());
            x = LegendItem(ink, p, L, x, y, swatch, h, gap, p.Unreached, false, false,
                           "UNREACHED " + Lading.FormatBytes(lading.DisplacementBytes).ToUpperInvariant());
            LegendItem(ink, p, L, x, y, swatch, h, gap, p.Indeterminate, false, true,
                       "WITHHELD " + Lading.FormatBytes(lading.IndeterminateBytes).ToUpperInvariant());
        }

        private static float LegendItem(Ink ink, in LadingPalette p, in CertificateLayout L,
                                        float x, float y, float swatch, float h, float gap,
                                        in Color c, bool fill, bool hatch, string label)
        {
            Segment(ink, c, x, y, swatch, h, fill, hatch);
            TypeSetter.Strike(ink, label, x + swatch + 0.014f, y - L.FineEm * 0.36f,
                              L.FineEm * 0.86f, p.Faint, Align.Left, 0.14f);
            return x + swatch + 0.014f + TypeSetter.Measure(label, L.FineEm * 0.86f, 0.14f) + gap;
        }

        /// <summary>
        /// The surveyor's stamp: a broken outer ring, a solid inner ring and the count it certifies.
        /// </summary>
        /// <remarks>
        /// ⚠️ The outer ring is BROKEN — four arcs with gaps — because a perfect circle reads as a UI
        /// affordance and a broken one reads as ink pressed onto paper by hand. It is the one piece
        /// of the plate whose job is purely to say "a person signed this".
        /// </remarks>
        private static void Stamp(Ink ink, in LadingPalette p, in CertificateLayout L, Lading lading)
        {
            float cx = L.StampCentre.x, cy = L.StampCentre.y, r = L.StampRadius;
            Color c = lading.RefusedBecause != null && lading.RefusedBecause.Length > 0
                ? p.Unreached : p.Reached;

            for (int i = 0; i < 4; i++)
            {
                float from = i * 90f + 7f;
                ink.ArcBand(cx, cy, r - 0.006f, r + 0.006f, from, from + 76f, c);
            }
            ink.Ring(cx, cy, r * 0.80f, 0.0085f, c);

            TypeSetter.Strike(ink, "SURVEYED", cx, cy + 0.014f, 0.021f, c, Align.Centre, 0.16f);
            string n = lading.SitesRead.ToString(System.Globalization.CultureInfo.InvariantCulture)
                       + " SITES";
            TypeSetter.Strike(ink, n, cx, cy - 0.030f, 0.016f, c, Align.Centre, 0.14f);
        }

        private static void Footer(Ink ink, in LadingPalette p, in CertificateLayout L, Lading lading)
        {
            Rule(ink, p.Rule, L.ContentLeft, L.FooterRuleY, L.ContentRight, L.FooterRuleY, 0.0022f);

            var ci = System.Globalization.CultureInfo.InvariantCulture;
            string line = lading.FilesScanned.ToString(ci) + " SCRIPTS READ, "
                + lading.SitesRead.ToString(ci) + " LOAD SITES RESOLVED. "
                + "FIGURES ARE MEASURED FILE SIZES, NOT ESTIMATES.";
            float em = TypeSetter.FitEm(line, L.ContentRight - L.ContentLeft, L.FineEm * 0.82f, 0.010f, TrackFoot);
            TypeSetter.Strike(ink, line, L.ContentLeft, L.FooterY, em, p.Faint, Align.Left, TrackFoot);
        }

        // ------------------------------------------------------------------ helpers

        /// <summary>
        /// Prepares a buyer string for the face: upper-cases it and folds what it can.
        /// </summary>
        /// <remarks>
        /// ⚠️ It does NOT strip characters the face cannot strike. <see cref="TypeSetter"/> refuses
        /// the whole line in that case, on purpose — dropping characters from a FILE PATH would print
        /// a path that does not exist, which on a document about which files are being moved is the
        /// worst possible kind of wrong.
        /// </remarks>
        private static string Tidy(string? s)
            => (s ?? string.Empty).ToUpperInvariant();

        /// <summary>
        /// Breaks a string into at most <paramref name="maxLines"/> lines that each fit
        /// <paramref name="maxWidth"/>, shortening the last one if the text still will not fit.
        /// </summary>
        /// <param name="s">The string.</param>
        /// <param name="maxWidth">Width available, in normalised units.</param>
        /// <param name="em">Cap height the lines will be struck at.</param>
        /// <param name="maxLines">How many lines the caller has room for.</param>
        /// <returns>The lines.</returns>
        /// <remarks>
        /// ⚠️ Breaks on SPACES only, so a single unbroken token longer than the measure is handled by
        /// <see cref="TypeSetter.Shorten"/> rather than being split mid-path. A file path cut in the
        /// middle and continued on the next line reads as two different files, which on this document
        /// is worse than an ellipsis.
        /// </remarks>
        private static List<string> Wrap(string s, float maxWidth, float em, int maxLines, float tracking)
        {
            var lines = new List<string>();
            if (s.Length == 0 || maxWidth <= 0f || maxLines < 1) return lines;

            string[] words = s.Split(' ');
            string current = string.Empty;

            for (int i = 0; i < words.Length; i++)
            {
                string w = words[i];
                if (w.Length == 0) continue;

                string candidate = current.Length == 0 ? w : current + " " + w;
                if (TypeSetter.Measure(candidate, em, tracking) <= maxWidth)
                {
                    current = candidate;
                    continue;
                }

                // This word does not fit. If there is room for another line, break here; if this is
                // already the last line, put EVERYTHING that remains on it and let Shorten cut once,
                // so the text ends in a visible ellipsis rather than simply stopping.
                if (lines.Count == maxLines - 1)
                {
                    current = current.Length == 0 ? w : current + " " + w;
                    for (int j = i + 1; j < words.Length; j++)
                        if (words[j].Length > 0) current += " " + words[j];
                    break;
                }

                if (current.Length > 0) lines.Add(current);
                current = w;
            }

            if (current.Length > 0)
                lines.Add(TypeSetter.Shorten(current, maxWidth, em, tracking) ?? current);

            return lines;
        }

        private static string Safe(string? s, string fallback)
            => s == null || s.Length == 0 ? fallback : s.ToUpperInvariant();
    }
}
