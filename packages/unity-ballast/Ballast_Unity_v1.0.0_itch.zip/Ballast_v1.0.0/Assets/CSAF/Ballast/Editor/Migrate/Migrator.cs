#nullable enable
// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace CSAF.Ballast
{
    /// <summary>One asset moved out of a Resources folder, and where it came from.</summary>
    [Serializable]
    public sealed class MigrationEntry
    {
        /// <summary>Where the asset was before the migration.</summary>
        public string From = string.Empty;

        /// <summary>Where it is now.</summary>
        public string To = string.Empty;

        /// <summary>Its size in bytes, recorded so a revert can verify what it restored.</summary>
        public long Bytes;
    }

    /// <summary>One migration: every asset it moved, so it can be undone exactly.</summary>
    [Serializable]
    public sealed class MigrationManifest
    {
        /// <summary>Quarantine folder name, which is also its identity.</summary>
        public string Stamp = string.Empty;

        /// <summary>The moves, in the order they were made.</summary>
        public List<MigrationEntry> Entries = new List<MigrationEntry>();

        /// <summary>Total bytes displaced.</summary>
        public long TotalBytes { get { long n = 0; foreach (var e in Entries) n += e.Bytes; return n; } }
    }

    /// <summary>
    /// Moves unreached assets out of <c>Resources</c> and puts them back on request.
    /// </summary>
    /// <remarks>
    /// <para>
    /// ⛔⛔ <b>THIS CLASS NEVER DELETES ANYTHING, AND THAT IS THE PRODUCT'S CENTRAL SAFETY PROMISE
    /// RATHER THAN A CONVENIENCE.</b> Ballast proves an asset is UNREACHED — that nothing in the C#
    /// it scanned asks for it. It has NOT proven the asset is dead: an AssetBundle, a scripted build
    /// step, a native plugin or code the scanner never saw could still want it. A tool that resolved
    /// that gap by deleting would be wrong occasionally and unrecoverably, and the buyer would find
    /// out when a player reached the code path. Moving is wrong occasionally and reversibly.
    /// </para>
    /// <para>
    /// ⛔ <b>THE <c>.meta</c> FILE MOVES WITH THE ASSET, AND THAT IS WHAT MAKES THIS SAFE AT ALL.</b>
    /// A Unity <c>.meta</c> carries the asset's GUID, and every reference anywhere in the project —
    /// scenes, prefabs, ScriptableObjects, materials — is stored as that GUID and not as a path. Move
    /// the pair and every existing reference keeps resolving; the asset simply stops being loadable
    /// BY NAME from <c>Resources.Load</c>, which is exactly and only the thing being removed. Move
    /// the asset without its meta and Unity mints a fresh GUID on import, silently breaking every
    /// reference to it in the project. There is no error and no warning; the references just become
    /// missing. That single line of behaviour is the difference between this product and a disaster.
    /// </para>
    /// <para>
    /// ⚠️ <b>NOTHING HERE RUNS AUTOMATICALLY.</b> No import hook, no build callback, no menu item
    /// that acts without a confirmation naming the count. The buyer opens a window and presses a
    /// button, and the pass is read-only until they do.
    /// </para>
    /// </remarks>
    public static class Migrator
    {
        /// <summary>Where quarantined assets are kept, relative to the project root.</summary>
        public const string QuarantineRoot = "Assets/CSAF/Ballast/Quarantine";

        /// <summary>The manifest file written beside each quarantine batch.</summary>
        public const string ManifestName = "ballast_migration.json";

        /// <summary>Builds the timestamped folder name for a new migration.</summary>
        /// <param name="utcNow">The moment the migration is made.</param>
        /// <returns>A folder name, safe on every filesystem this ships to.</returns>
        /// <remarks>
        /// ⚠️ Colons are illegal in Windows paths and a naive round-trip of an ISO timestamp produces
        /// one. The format here is deliberately hyphenated throughout.
        /// </remarks>
        public static string StampFor(DateTime utcNow)
            => utcNow.ToString("yyyy-MM-dd-HHmmss", CultureInfo.InvariantCulture);

        /// <summary>
        /// Moves every named asset into a new quarantine folder, preserving its <c>.meta</c> and the
        /// folder structure it came from.
        /// </summary>
        /// <param name="projectRoot">Absolute path of the project root (the parent of Assets).</param>
        /// <param name="assetPaths">Project-relative paths of the assets to move.</param>
        /// <param name="stamp">Quarantine folder name, from <see cref="StampFor"/>.</param>
        /// <returns>The manifest describing exactly what moved.</returns>
        /// <remarks>
        /// ⛔ <b>REFUSES TO OVERWRITE.</b> If a destination already exists the asset is skipped rather
        /// than clobbered, because the one thing worse than failing to migrate is destroying the
        /// buyer's copy of something while reporting success.
        /// </remarks>
        public static MigrationManifest Migrate(string? projectRoot, IReadOnlyList<string>? assetPaths,
                                                string? stamp)
        {
            var manifest = new MigrationManifest();
            if (projectRoot == null || projectRoot.Length == 0) return manifest;
            if (assetPaths == null || assetPaths.Count == 0) return manifest;

            string s = stamp == null || stamp.Length == 0 ? StampFor(DateTime.UtcNow) : stamp;
            manifest.Stamp = s;

            string root = projectRoot.Replace('\\', '/').TrimEnd('/');
            string batchRel = QuarantineRoot + "/" + s;

            foreach (string rel in assetPaths)
            {
                if (rel == null || rel.Length == 0) continue;
                string src = root + "/" + rel;
                if (!File.Exists(src)) continue;

                // The asset keeps its position relative to the Resources folder that held it, so a
                // revert is a pure inverse and a buyer browsing the quarantine can see the shape of
                // what left.
                string destRel = batchRel + "/" + Flatten(rel);
                string dest = root + "/" + destRel;
                if (File.Exists(dest)) continue;

                Directory.CreateDirectory(Path.GetDirectoryName(dest) ?? root);

                long bytes;
                try { bytes = new FileInfo(src).Length; }
                catch (IOException) { continue; }

                try
                {
                    File.Move(src, dest);
                    // ⛔ The meta moves too. See the class remarks: without it Unity mints a new GUID
                    // and every reference in the project to this asset silently becomes missing.
                    if (File.Exists(src + ".meta") && !File.Exists(dest + ".meta"))
                        File.Move(src + ".meta", dest + ".meta");
                }
                catch (IOException) { continue; }
                catch (UnauthorizedAccessException) { continue; }

                manifest.Entries.Add(new MigrationEntry { From = rel, To = destRel, Bytes = bytes });
            }

            return manifest;
        }

        /// <summary>
        /// Puts every asset in a manifest back where it came from.
        /// </summary>
        /// <param name="projectRoot">Absolute path of the project root.</param>
        /// <param name="manifest">The manifest written by <see cref="Migrate"/>.</param>
        /// <returns>How many assets were restored.</returns>
        /// <remarks>
        /// ⚠️ Returns a COUNT rather than a boolean, so a caller can compare it against the manifest
        /// and notice a partial restore. A revert that reports success while leaving three of forty
        /// assets in quarantine is the shape this factory keeps paying for.
        /// </remarks>
        public static int Revert(string? projectRoot, MigrationManifest? manifest)
        {
            if (projectRoot == null || projectRoot.Length == 0) return 0;
            if (manifest == null || manifest.Entries.Count == 0) return 0;

            string root = projectRoot.Replace('\\', '/').TrimEnd('/');
            int restored = 0;

            foreach (var e in manifest.Entries)
            {
                string from = root + "/" + e.To;
                string to = root + "/" + e.From;
                if (!File.Exists(from)) continue;
                if (File.Exists(to)) continue;

                Directory.CreateDirectory(Path.GetDirectoryName(to) ?? root);
                try
                {
                    File.Move(from, to);
                    if (File.Exists(from + ".meta") && !File.Exists(to + ".meta"))
                        File.Move(from + ".meta", to + ".meta");
                    restored++;
                }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }

            return restored;
        }

        /// <summary>
        /// The name a <c>Resources</c> segment is rewritten to inside the quarantine.
        /// </summary>
        /// <remarks>
        /// ⛔⛔ <b>THIS ONE RENAME IS WHY THE MIGRATION DOES ANYTHING AT ALL.</b> Unity decides what
        /// goes into the build by looking for a folder named exactly <c>Resources</c> at ANY depth.
        /// The quarantine preserves the folder shape an asset came from, so without this rewrite the
        /// destination is
        /// <c>Assets/CSAF/Ballast/Quarantine/&lt;stamp&gt;/Game/Resources/icons/sword.png</c> — which
        /// is STILL INSIDE A RESOURCES FOLDER. Unity would go on shipping every quarantined byte, the
        /// certificate would go on reporting them, and the product's entire headline claim would be
        /// false while every file visibly moved.
        /// <para>
        /// ⚠️ MEASURED, not theorised: the first fresh-install run reported the project's tonnage
        /// UNCHANGED at 31,000 bytes after a migration that had demonstrably moved both files. Every
        /// EditMode test passed through it, because they assert that <see cref="Migrate"/> moves files
        /// and never re-survey afterwards — the move was real and its EFFECT was nil.
        /// </para>
        /// <para>
        /// ⭐ It is a RENAME rather than a <c>~</c> suffix on purpose. Unity ignores a <c>~</c> folder
        /// completely, which would take the assets out of the AssetDatabase and break every GUID
        /// reference to them — exactly what this product promises not to do. A renamed folder is an
        /// ordinary folder: the assets stay imported, keep their GUIDs, keep every existing
        /// reference, and are simply no longer loadable by name and no longer forced into the build.
        /// </para>
        /// </remarks>
        public const string QuarantinedResourcesName = "_Resources";

        /// <summary>
        /// Turns a project-relative asset path into a single quarantine-relative path.
        /// </summary>
        /// <param name="assetPath">Project-relative asset path.</param>
        /// <returns>The path under the quarantine batch folder.</returns>
        /// <remarks>
        /// ⛔ <b>THE LEADING <c>Assets/</c> IS DROPPED, EVERY <c>Resources</c> SEGMENT IS RENAMED, AND
        /// NOTHING ELSE CHANGES.</b> Keeping <c>Assets/</c> would nest an <c>Assets</c> folder inside
        /// <c>Assets</c>; flattening further would collide two assets that share a file name in
        /// different folders — quarantining <c>icons/sword.png</c> and <c>props/sword.png</c> into one
        /// <c>sword.png</c> loses one of them. The full remaining path is what makes the revert a true
        /// inverse. See <see cref="QuarantinedResourcesName"/> for why the rename is load-bearing.
        /// </remarks>
        public static string Flatten(string? assetPath)
        {
            string p = (assetPath ?? string.Empty).Replace('\\', '/').TrimStart('/');
            const string prefix = "Assets/";
            if (p.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                p = p.Substring(prefix.Length);

            string[] parts = p.Split('/');
            for (int i = 0; i < parts.Length; i++)
            {
                // Segment-wise and exact, matching Unity's own rule. "ResourcesOld" is an ordinary
                // folder to Unity and must stay an ordinary folder here.
                if (string.Equals(parts[i], ResourcesIndex.FolderName, StringComparison.Ordinal))
                    parts[i] = QuarantinedResourcesName;
            }
            return string.Join("/", parts);
        }
    }
}
