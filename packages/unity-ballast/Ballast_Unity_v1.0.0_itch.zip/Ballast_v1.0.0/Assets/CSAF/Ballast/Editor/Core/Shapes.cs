#nullable enable
// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

using System;
using UnityEngine;

namespace CSAF.Ballast
{
    /// <summary>
    /// The signed-distance primitives this package composes its certificate from.
    /// </summary>
    /// <remarks>
    /// <para>
    /// ⚠️ <b>THIS IS A DELIBERATELY SMALL FILE AND THE SMALLNESS IS THE POINT.</b> The sibling
    /// products in this line carry a ~700-line shape kit whose bulk is mark-plating machinery —
    /// outline derivation, rim light, form shade, contact shadow — for corpora of hand-authored
    /// emblems. Ballast has no emblem corpus. Its face is a DOCUMENT: rules, bars, hatching, a stamp
    /// and a great deal of type. Copying the whole kit would have shipped several hundred lines of
    /// unreachable code into a package whose Readme claims every file is auditable, so only the four
    /// primitives that are genuinely called live here.
    /// </para>
    /// <para>
    /// ⛔ <b>EVERY FUNCTION RETURNS A DISTANCE, NEGATIVE INSIDE.</b> <see cref="Ink.Fill"/> reads the
    /// sign to decide coverage and reads the MAGNITUDE to antialias the edge, so a function that
    /// returns a bare boolean cast to 0/1 draws a correct shape with a staircase on it. That failure
    /// is invisible at plate scale and obvious the moment anyone crops and enlarges a tile, which
    /// this wing's own doctrine requires after every change.
    /// </para>
    /// </remarks>
    public static class Shapes
    {
        /// <summary>Signed distance to an axis-aligned rounded box.</summary>
        /// <param name="x">Sample X.</param>
        /// <param name="y">Sample Y.</param>
        /// <param name="cx">Centre X.</param>
        /// <param name="cy">Centre Y.</param>
        /// <param name="hx">Half extent in X.</param>
        /// <param name="hy">Half extent in Y.</param>
        /// <param name="round">Corner radius, subtracted from the extents.</param>
        /// <returns>Negative inside the box.</returns>
        /// <remarks>
        /// ⚠️ <paramref name="round"/> is subtracted from the half extents rather than added, so a
        /// rounded box occupies exactly the rectangle its extents describe. The other convention —
        /// growing the box by the radius — would make a tonnage bar wider than the span it was
        /// measured against, which on a chart whose whole job is proportion is a lie in the art.
        /// </remarks>
        public static float SdBox(float x, float y, float cx, float cy, float hx, float hy,
                                  float round = 0f)
        {
            float r = Mathf.Min(round, Mathf.Min(hx, hy));
            float dx = Mathf.Abs(x - cx) - (hx - r);
            float dy = Mathf.Abs(y - cy) - (hy - r);
            float ox = Mathf.Max(dx, 0f), oy = Mathf.Max(dy, 0f);
            return Mathf.Sqrt(ox * ox + oy * oy) + Mathf.Min(Mathf.Max(dx, dy), 0f) - r;
        }

        /// <summary>
        /// Signed distance to a capsule — a segment with a radius, tapering from
        /// <paramref name="rA"/> at the start to <paramref name="rB"/> at the end.
        /// </summary>
        /// <param name="x">Sample X.</param>
        /// <param name="y">Sample Y.</param>
        /// <param name="ax">Start X.</param>
        /// <param name="ay">Start Y.</param>
        /// <param name="bx">End X.</param>
        /// <param name="by">End Y.</param>
        /// <param name="rA">Half-width at the start.</param>
        /// <param name="rB">Half-width at the end.</param>
        /// <returns>Negative inside the capsule.</returns>
        public static float SdCapsule(float x, float y, float ax, float ay, float bx, float by,
                                      float rA, float rB)
        {
            float ex = bx - ax, ey = by - ay;
            float len2 = ex * ex + ey * ey;
            float px = x - ax, py = y - ay;
            float t = len2 <= 1e-9f ? 0f : Mathf.Clamp01((px * ex + py * ey) / len2);
            float qx = px - ex * t, qy = py - ey * t;
            return Mathf.Sqrt(qx * qx + qy * qy) - Mathf.Lerp(rA, rB, t);
        }

        /// <summary>
        /// Signed distance to a tapering polyline solid — the primitive every letterform is built
        /// from.
        /// </summary>
        /// <param name="x">Sample X.</param>
        /// <param name="y">Sample Y.</param>
        /// <param name="pts">The spine. Fewer than two points is empty.</param>
        /// <param name="halfWidths">Half-width at each spine point; must match <paramref name="pts"/>.</param>
        /// <returns>Negative inside the stroke.</returns>
        /// <remarks>
        /// ⚠️ Returns a large POSITIVE number for a degenerate spine rather than throwing, because a
        /// throw here fires from inside a fill lambda on some sampled pixel deep in a compose, where
        /// the stack says nothing about which glyph was being struck. "Outside everywhere" draws
        /// nothing, which is the visible, diagnosable failure.
        /// </remarks>
        public static float SdSpine(float x, float y, Vector2[] pts, float[] halfWidths)
        {
            if (pts == null) throw new ArgumentNullException(nameof(pts));
            if (halfWidths == null) throw new ArgumentNullException(nameof(halfWidths));
            if (halfWidths.Length != pts.Length)
                throw new ArgumentException("halfWidths must match pts in length", nameof(halfWidths));
            if (pts.Length < 2) return 1f;

            float best = float.MaxValue;
            for (int i = 0; i < pts.Length - 1; i++)
            {
                float d = SdCapsule(x, y, pts[i].x, pts[i].y, pts[i + 1].x, pts[i + 1].y,
                                    halfWidths[i], halfWidths[i + 1]);
                if (d < best) best = d;
            }
            return best;
        }

        /// <summary>
        /// Signed distance to a field of parallel 45° hatching — the visual language this product
        /// reserves for <see cref="Verdict.Indeterminate"/>.
        /// </summary>
        /// <param name="x">Sample X.</param>
        /// <param name="y">Sample Y.</param>
        /// <param name="pitch">Distance between stroke centres.</param>
        /// <param name="halfWidth">Half the stroke weight.</param>
        /// <returns>Negative inside a hatch stroke.</returns>
        /// <remarks>
        /// <para>
        /// ⛔ <b>HATCHING RATHER THAN A COLOUR IS A CORRECTNESS REQUIREMENT, NOT A STYLE CHOICE.</b>
        /// The one thing a buyer must never misread on this certificate is which bytes Ballast
        /// refused to touch. A store screenshot is viewed at thumbnail size, is frequently rendered
        /// greyscale by a feed, and roughly one man in twelve cannot separate the two hues a chart
        /// would naturally reach for. A different DRAWING LANGUAGE survives all three.
        /// </para>
        /// <para>
        /// ⚠️ The pitch is a distance in surface units and must be chosen against the height of the
        /// band being filled, never once for the whole plate. This wing has measured the failure in
        /// the other direction — a texture authored on a small specimen tile that became blocks
        /// reading as compression artefacts when the same mark covered a large area — and the same
        /// arithmetic runs backwards here: hatching at a pitch finer than a few pixels aliases into
        /// a flat grey wash, which is precisely the colour-only band this file exists to avoid.
        /// </para>
        /// </remarks>
        public static float SdHatch45(float x, float y, float pitch, float halfWidth)
        {
            if (pitch <= 1e-6f) return 1f;
            // Distance along the axis perpendicular to a 45-degree stroke.
            float u = (x + y) * 0.70710678f;
            float m = u - Mathf.Floor(u / pitch) * pitch;   // always in [0, pitch)
            float d = Mathf.Abs(m - pitch * 0.5f);
            return d - halfWidth;
        }
    }
}
