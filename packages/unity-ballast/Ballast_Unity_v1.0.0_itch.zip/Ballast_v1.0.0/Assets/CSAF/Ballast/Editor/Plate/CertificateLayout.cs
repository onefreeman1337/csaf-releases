#nullable enable
// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

using UnityEngine;

namespace CSAF.Ballast
{
    /// <summary>
    /// Every position and size the certificate is composed from, derived once from the plate's own
    /// aspect and read by BOTH the drawing pass and the tests.
    /// </summary>
    /// <remarks>
    /// <para>
    /// ⛔ <b>THIS TYPE EXISTS BECAUSE TWO PASSES THAT DERIVE THEIR OWN GEOMETRY WILL EVENTUALLY
    /// DISAGREE.</b> This wing has shipped a plate where the mark pass placed a device at a fraction
    /// of the field while the type pass right-aligned a number at the field edge with no reserved
    /// width, so every device landed on its own number on every row. Neither pass was wrong about
    /// itself and no instrument could see it. The remedy recorded there is to declare the columns
    /// ONCE and have both passes read them, which is this file.
    /// </para>
    /// <para>
    /// ⛔ <b>AND THE TESTS READ IT TOO, RATHER THAN RESTATING IT.</b> A test carrying its own copy of
    /// a geometric constant is asserting about a box the composer may not be drawing — the same
    /// family as verifying against a field you wrote. Every assertion about this layout imports these
    /// members.
    /// </para>
    /// </remarks>
    public readonly struct CertificateLayout
    {
        /// <summary>Half-width of the surface in normalised units (Y is always ±1).</summary>
        public readonly float A;

        /// <summary>Distance from the surface edge to the frame.</summary>
        public readonly float Margin;

        /// <summary>Left edge of every column of content.</summary>
        public readonly float ContentLeft;

        /// <summary>Right edge of every column of content.</summary>
        public readonly float ContentRight;

        /// <summary>Baseline of the wordmark.</summary>
        public readonly float WordmarkBaseline;

        /// <summary>Cap height of the wordmark.</summary>
        public readonly float WordmarkEm;

        /// <summary>The rule under the header block.</summary>
        public readonly float HeaderRuleY;

        /// <summary>Baseline of the displacement caption.</summary>
        public readonly float DisplacementCaptionY;

        /// <summary>Baseline of the hero displacement figure.</summary>
        public readonly float DisplacementFigureY;

        /// <summary>Preferred cap height of the hero figure.</summary>
        public readonly float DisplacementEm;

        /// <summary>Baseline of the line under the hero figure.</summary>
        public readonly float DisplacementFootY;

        /// <summary>Top of the tonnage chart.</summary>
        public readonly float ChartTop;

        /// <summary>Bottom of the tonnage chart.</summary>
        public readonly float ChartBottom;

        /// <summary>Tallest a single chart row may be, however few rows there are.</summary>
        /// <remarks>
        /// ⛔ <b>THIS NUMBER IS WHAT DECIDES WHETHER THE CERTIFICATE HAS A HOLE IN IT.</b> The chart
        /// is anchored to <see cref="ChartTop"/> and grows downward, so a cap that is too small
        /// leaves the difference between the rows' real height and <see cref="ChartBottom"/> as blank
        /// paper in the MIDDLE of the page — measured at roughly a fifth of the plate on four rows
        /// and nearly half of it on two, which is a straight failure of the ">20% empty" bar. Set so
        /// that four rows fill the span exactly and two rows fill most of it.
        /// </remarks>
        public readonly float MaxRowHeight;

        /// <summary>Shortest a chart row may be, so a long list stays legible rather than fitting.</summary>
        public readonly float MinRowHeight;

        /// <summary>
        /// A row taller than this carries a third line naming its per-verdict asset counts.
        /// </summary>
        /// <remarks>
        /// ⭐ The honest way to fill a tall row is to put more INFORMATION in it, not more air. A
        /// certificate with four folders has room to say "41 IN USE, 63 UNREACHED, 12 WITHHELD" per
        /// folder; one with forty does not, and padding those rows would be decoration.
        /// </remarks>
        public readonly float RowCountsThreshold;

        /// <summary>Gap between the last chart row and the legend.</summary>
        public readonly float LegendGap;

        /// <summary>Left edge of the tonnage bars.</summary>
        public readonly float BarLeft;

        /// <summary>Right edge of a bar at full tonnage.</summary>
        public readonly float BarRight;

        /// <summary>Half-height of a tonnage bar.</summary>
        public readonly float BarHalfHeight;

        /// <summary>Cap height a folder path is struck at when it fits.</summary>
        public readonly float PathEm;

        /// <summary>
        /// Smallest cap height a folder path may be shrunk to before it is shortened instead.
        /// </summary>
        /// <remarks>
        /// ⚠️ An ABSOLUTE floor, not a fraction of <see cref="PathEm"/>. This wing has measured that
        /// a floor expressed as a fraction of the size a string WANTED scales with the plate, so on a
        /// narrow one the fitter cannot reach a size that fits, takes the space anyway, and the
        /// neighbouring column pays for it. An absolute floor lets the fitter return the em that
        /// actually fits.
        /// </remarks>
        public readonly float PathMinEm;

        /// <summary>
        /// Where the legend sits when the chart is full. A short chart pulls it UP to follow the
        /// last row — see <see cref="LegendGap"/>.
        /// </summary>
        public readonly float LegendY;

        /// <summary>Cap height of legend and footer type.</summary>
        public readonly float FineEm;

        /// <summary>The rule above the footer.</summary>
        public readonly float FooterRuleY;

        /// <summary>Baseline of the footer line.</summary>
        public readonly float FooterY;

        /// <summary>Centre of the survey stamp.</summary>
        public readonly Vector2 StampCentre;

        /// <summary>Outer radius of the survey stamp.</summary>
        public readonly float StampRadius;

        /// <summary>Builds the layout for a surface of the given aspect.</summary>
        /// <param name="aspect">Half-width of the surface, i.e. <see cref="Ink.Aspect"/>.</param>
        /// <returns>The layout.</returns>
        public static CertificateLayout For(float aspect) => new CertificateLayout(aspect);

        private CertificateLayout(float aspect)
        {
            A = aspect;
            Margin = 0.052f;
            ContentLeft = -A + Margin + 0.045f;
            ContentRight = A - Margin - 0.045f;

            WordmarkEm = 0.058f;
            WordmarkBaseline = 0.845f;
            HeaderRuleY = 0.700f;

            DisplacementCaptionY = 0.605f;
            DisplacementFigureY = 0.455f;
            DisplacementEm = 0.125f;
            DisplacementFootY = 0.385f;

            ChartTop = 0.290f;
            ChartBottom = -0.520f;
            // Four rows x 0.2025 is exactly the 0.810 span, which is the commonest shape and the one
            // the gallery is composed from; two rows reach 0.520 of it and then the legend follows.
            MaxRowHeight = 0.2600f;
            MinRowHeight = 0.0700f;
            RowCountsThreshold = 0.1300f;
            LegendGap = 0.0850f;

            // The bars start clear of the left rail and stop clear of the tonnage column, which is
            // right-aligned at ContentRight. Both passes read these two numbers.
            BarLeft = -A + Margin + 0.055f;
            BarRight = A - Margin - 0.055f;
            BarHalfHeight = 0.0165f;

            PathEm = 0.0255f;
            PathMinEm = 0.0150f;

            LegendY = -0.610f;
            FineEm = 0.0180f;

            FooterRuleY = -0.845f;
            FooterY = -0.895f;

            StampCentre = new Vector2(A - Margin - 0.175f, -0.700f);
            StampRadius = 0.115f;
        }
    }
}
