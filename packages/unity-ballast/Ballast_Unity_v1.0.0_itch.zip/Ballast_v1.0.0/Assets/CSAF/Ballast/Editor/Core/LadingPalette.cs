#nullable enable
// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

using UnityEngine;

namespace CSAF.Ballast
{
    /// <summary>
    /// The paper stock a certificate is struck on.
    /// </summary>
    /// <remarks>
    /// ⚠️ This is the ONLY decorative axis in the product and it is deliberately short. A sibling
    /// product in this line offers seven stocks because its output is an ornament the player sees;
    /// Ballast's output is a document an engineer reads and attaches to a build ticket, so the
    /// choice on offer is "does this print" and not "which of seven marbles do you like".
    /// </remarks>
    public enum Stock
    {
        /// <summary>Aged manifest paper. The default, and what the store plates are struck on.</summary>
        Manifest = 0,

        /// <summary>Blue engineering paper, for a certificate pasted into a dark-themed document.</summary>
        Draughting = 1,

        /// <summary>Pure black on white, for printing and for pasting into an issue tracker.</summary>
        Plain = 2,
    }

    /// <summary>
    /// Every colour the certificate is drawn with, and the three verdict inks that carry its
    /// meaning.
    /// </summary>
    /// <remarks>
    /// <para>
    /// ⛔ <b>THE VERDICT INKS ARE THE PRODUCT'S PRIMARY AXIS, WHICH IS WHY THIS TYPE IS AUTHORED AND
    /// NOT INHERITED.</b> This wing has measured that porting a sibling's palette carries the
    /// sibling's axis with it — an eight-hour clock, a four-season year — and the result is a plate
    /// that is beautifully drawn and about the wrong subject. Ballast's axis is
    /// <see cref="Verdict"/>: reached, unreached, indeterminate. Three inks, chosen for those three
    /// meanings, and nothing else in the file may be read as an ornament.
    /// </para>
    /// <para>
    /// ⛔ <b>AND COLOUR IS NEVER THE ONLY CARRIER.</b> <see cref="Indeterminate"/> is drawn as
    /// HATCHING (see <see cref="Shapes.SdHatch45"/>) and <see cref="Unreached"/> as an open outline;
    /// only <see cref="Reached"/> is struck solid. That means the chart still reads correctly in
    /// greyscale, at thumbnail size, and to a colour-blind buyer — three conditions that all hold
    /// for a store screenshot, which is where most people will meet this picture.
    /// </para>
    /// <para>
    /// ⚠️ <b>THE LUMINANCE ORDER IS ALSO DELIBERATE AND IS ASSERTED BY A TEST.</b> Solid reached ink
    /// is the darkest, the unreached outline is mid, the hatch is lightest — so the three bands stack
    /// in the same order whether a reader is going by hue, by texture or by tone. A palette whose
    /// tones crossed would put the "safe to move" band visually heavier than the "in use" band, and
    /// a chart that argues against its own caption is worse than no chart.
    /// </para>
    /// </remarks>
    public readonly struct LadingPalette
    {
        /// <summary>The paper.</summary>
        public readonly Color Ground;

        /// <summary>A slightly deeper wash used for panel wells and the header block.</summary>
        public readonly Color Well;

        /// <summary>Rules, frames and hairlines.</summary>
        public readonly Color Rule;

        /// <summary>Body type.</summary>
        public readonly Color Ink;

        /// <summary>Secondary type: captions, units, the dateline.</summary>
        public readonly Color Faint;

        /// <summary>Struck solid. An asset a literal load site names.</summary>
        public readonly Color Reached;

        /// <summary>Drawn as an open outline. An asset nothing can reach.</summary>
        public readonly Color Unreached;

        /// <summary>Drawn as hatching. An asset a dynamic load site could reach.</summary>
        public readonly Color Indeterminate;

        /// <summary>The stock this palette was built for.</summary>
        public readonly Stock Stock;

        private LadingPalette(Stock stock, Color ground, Color well, Color rule, Color ink,
                              Color faint, Color reached, Color unreached, Color indeterminate)
        {
            Stock = stock;
            Ground = ground;
            Well = well;
            Rule = rule;
            Ink = ink;
            Faint = faint;
            Reached = reached;
            Unreached = unreached;
            Indeterminate = indeterminate;
        }

        /// <summary>The ink a verdict is drawn in.</summary>
        /// <param name="verdict">The verdict.</param>
        /// <returns>The colour.</returns>
        public Color For(Verdict verdict)
        {
            switch (verdict)
            {
                case Verdict.Reached: return Reached;
                case Verdict.Unreached: return Unreached;
                default: return Indeterminate;
            }
        }

        /// <summary>Builds the palette for a stock.</summary>
        /// <param name="stock">The stock.</param>
        /// <returns>The palette.</returns>
        public static LadingPalette Of(Stock stock)
        {
            switch (stock)
            {
                case Stock.Draughting:
                    return new LadingPalette(stock,
                        ground: Rgb(0x16, 0x22, 0x2E),
                        well: Rgb(0x10, 0x1A, 0x24),
                        rule: Rgb(0x4C, 0x6B, 0x84),
                        ink: Rgb(0xDC, 0xE8, 0xF2),
                        faint: Rgb(0x8A, 0xA4, 0xBA),
                        reached: Rgb(0x74, 0xC2, 0xE8),
                        unreached: Rgb(0xE8, 0xC0, 0x6A),
                        indeterminate: Rgb(0xC9, 0xD8, 0xE6));

                case Stock.Plain:
                    return new LadingPalette(stock,
                        ground: Rgb(0xFF, 0xFF, 0xFF),
                        well: Rgb(0xF0, 0xF0, 0xF0),
                        rule: Rgb(0x88, 0x88, 0x88),
                        ink: Rgb(0x11, 0x11, 0x11),
                        faint: Rgb(0x66, 0x66, 0x66),
                        reached: Rgb(0x1A, 0x1A, 0x1A),
                        unreached: Rgb(0x59, 0x59, 0x59),
                        indeterminate: Rgb(0x9B, 0x9B, 0x9B));

                default:
                    // Manifest. Warm aged paper, iron-gall body ink, a rust stamp.
                    return new LadingPalette(Stock.Manifest,
                        ground: Rgb(0xE7, 0xDC, 0xC4),
                        well: Rgb(0xD8, 0xCA, 0xAC),
                        rule: Rgb(0x8C, 0x7A, 0x5C),
                        ink: Rgb(0x2A, 0x24, 0x1C),
                        faint: Rgb(0x6E, 0x60, 0x4A),
                        reached: Rgb(0x2E, 0x3D, 0x33),
                        unreached: Rgb(0x8A, 0x4A, 0x2A),
                        indeterminate: Rgb(0x77, 0x6B, 0x55));
            }
        }

        /// <summary>Relative luminance, used by the palette's own ordering test.</summary>
        /// <param name="c">The colour.</param>
        /// <returns>Luminance in [0,1].</returns>
        /// <remarks>
        /// Rec. 709 coefficients on the raw channel values. This is a RELATIVE ordering instrument,
        /// so the sRGB transfer function is deliberately not applied — it is monotone, and leaving it
        /// out keeps the number the test asserts on trivially re-derivable by hand.
        /// </remarks>
        public static float Luminance(in Color c) => 0.2126f * c.r + 0.7152f * c.g + 0.0722f * c.b;

        private static Color Rgb(int r, int g, int b) => new Color(r / 255f, g / 255f, b / 255f, 1f);
    }
}
