#nullable enable
// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

using System;
using System.Collections.Generic;

namespace CSAF.Ballast
{
    /// <summary>
    /// One row of the certificate: a top-level <c>Resources</c> folder and the tonnage it carries,
    /// split by verdict.
    /// </summary>
    public readonly struct LadingRow
    {
        /// <summary>Project-relative path of the Resources folder, e.g. <c>Assets/Art/Resources</c>.</summary>
        public readonly string Folder;

        /// <summary>Bytes a literal load site names.</summary>
        public readonly long ReachedBytes;

        /// <summary>Bytes nothing can reach — what Ballast offers to migrate.</summary>
        public readonly long UnreachedBytes;

        /// <summary>Bytes a dynamic load site could reach, which Ballast will not touch.</summary>
        public readonly long IndeterminateBytes;

        /// <summary>Asset counts, in the same order as the byte figures.</summary>
        public readonly int ReachedCount, UnreachedCount, IndeterminateCount;

        public LadingRow(string? folder, long reached, long unreached, long indeterminate,
                         int reachedCount, int unreachedCount, int indeterminateCount)
        {
            Folder = folder ?? string.Empty;
            ReachedBytes = reached;
            UnreachedBytes = unreached;
            IndeterminateBytes = indeterminate;
            ReachedCount = reachedCount;
            UnreachedCount = unreachedCount;
            IndeterminateCount = indeterminateCount;
        }

        /// <summary>Every byte in this folder, whatever its verdict.</summary>
        public long TotalBytes => ReachedBytes + UnreachedBytes + IndeterminateBytes;

        /// <summary>Every asset in this folder.</summary>
        public int TotalCount => ReachedCount + UnreachedCount + IndeterminateCount;
    }

    /// <summary>
    /// Everything the certificate states: the rows, the totals, the displacement figure and the one
    /// condition under which Ballast refuses to act at all.
    /// </summary>
    /// <remarks>
    /// <para>
    /// ⛔ <b>THIS TYPE IS PURE DATA AND KNOWS NOTHING ABOUT UNITY.</b> That is what lets the whole
    /// certificate be composed and asserted in EditMode tests without an asset database, a project
    /// or a scene — and this wing has measured that a product whose picture can only be produced by
    /// a three-minute engine bake gets its layout tuned by eye instead of by arithmetic.
    /// </para>
    /// <para>
    /// ⚠️ <b>EVERY FIGURE HERE IS A SUM OF REAL FILE SIZES.</b> None of it is estimated, and the
    /// certificate says so, because the one thing a build-weight document cannot do is quote a guess
    /// as a measurement.
    /// </para>
    /// </remarks>
    public sealed class Lading
    {
        /// <summary>Rows, one per top-level Resources folder, heaviest first.</summary>
        public IReadOnlyList<LadingRow> Rows { get; }

        /// <summary>The project name, struck as the certificate's consignee.</summary>
        public string Project { get; }

        /// <summary>The dateline, already formatted.</summary>
        public string Dateline { get; }

        /// <summary>
        /// The call site that makes the whole tree indeterminate, or null when there is none.
        /// </summary>
        /// <remarks>
        /// ⭐ When this is set the certificate does not draw a tonnage chart at all — it draws a
        /// REFUSAL, names the file and line, and states that nothing can be migrated until that site
        /// is narrowed. That is the honest answer and the product presents it as one. A tool that
        /// showed a confident chart here would be inviting the buyer to delete assets their game
        /// loads.
        /// </remarks>
        public string? RefusedBecause { get; }

        /// <summary>How many <c>Resources.Load</c> call sites were read to produce this.</summary>
        public int SitesRead { get; }

        /// <summary>How many C# files were scanned.</summary>
        public int FilesScanned { get; }

        /// <summary>The paper.</summary>
        public Stock Stock { get; }

        public Lading(IReadOnlyList<LadingRow>? rows, string? project, string? dateline,
                      int sitesRead, int filesScanned, string? refusedBecause = null,
                      Stock stock = Stock.Manifest)
        {
            Rows = rows ?? new List<LadingRow>();
            Project = project ?? string.Empty;
            Dateline = dateline ?? string.Empty;
            SitesRead = sitesRead;
            FilesScanned = filesScanned;
            RefusedBecause = refusedBecause;
            Stock = stock;
        }

        /// <summary>Total bytes under every Resources folder.</summary>
        public long TotalBytes { get { long n = 0; foreach (var r in Rows) n += r.TotalBytes; return n; } }

        /// <summary>Bytes a literal load site names.</summary>
        public long ReachedBytes { get { long n = 0; foreach (var r in Rows) n += r.ReachedBytes; return n; } }

        /// <summary>
        /// Bytes Ballast can move out of the build — the number a buyer screenshots.
        /// </summary>
        public long DisplacementBytes { get { long n = 0; foreach (var r in Rows) n += r.UnreachedBytes; return n; } }

        /// <summary>Bytes Ballast will not touch.</summary>
        public long IndeterminateBytes { get { long n = 0; foreach (var r in Rows) n += r.IndeterminateBytes; return n; } }

        /// <summary>Assets under every Resources folder.</summary>
        public int TotalCount { get { int n = 0; foreach (var r in Rows) n += r.TotalCount; return n; } }

        /// <summary>Assets Ballast can move.</summary>
        public int DisplacementCount { get { int n = 0; foreach (var r in Rows) n += r.UnreachedCount; return n; } }

        /// <summary>Assets Ballast will not touch.</summary>
        public int IndeterminateCount { get { int n = 0; foreach (var r in Rows) n += r.IndeterminateCount; return n; } }

        /// <summary>Assets a literal load site names.</summary>
        public int ReachedCount { get { int n = 0; foreach (var r in Rows) n += r.ReachedCount; return n; } }

        /// <summary>
        /// Formats a byte count the way the certificate strikes it.
        /// </summary>
        /// <param name="bytes">The count.</param>
        /// <returns>A string the type face can strike.</returns>
        /// <remarks>
        /// <para>
        /// ⛔ <b>EVERY CHARACTER THIS CAN EMIT MUST BE STRIKEABLE, AND THAT IS ASSERTED BY A TEST.</b>
        /// <see cref="TypeSetter"/> refuses a whole line containing one character the face lacks —
        /// correctly, because striking the rest would print a different number. So a formatter that
        /// reached for a non-breaking space, a thin space or a multiplication sign would silently
        /// blank the tonnage column, and the certificate would look finished with no figures on it.
        /// </para>
        /// <para>
        /// ⚠️ Binary units, and the suffix says <c>KB</c>/<c>MB</c> rather than <c>KiB</c>/<c>MiB</c>
        /// because that is what the Unity build report and the editor's own inspectors print, and a
        /// certificate a buyer cannot reconcile against their build log is a certificate they do not
        /// trust. The divisor is 1024 either way; only the label differs.
        /// </para>
        /// </remarks>
        public static string FormatBytes(long bytes)
        {
            if (bytes < 0) return "0 B";
            if (bytes < 1024) return bytes.ToString(System.Globalization.CultureInfo.InvariantCulture) + " B";

            double v = bytes / 1024.0;
            if (v < 1024.0) return Round(v) + " KB";
            v /= 1024.0;
            if (v < 1024.0) return Round(v) + " MB";
            v /= 1024.0;
            return Round(v) + " GB";
        }

        private static string Round(double v)
        {
            // One decimal below 100, none above: "9.4 MB" and "412 MB" both read at a glance, while
            // "412.3 MB" adds a digit of false precision to a figure nobody compares that finely.
            string s = v < 100.0
                ? v.ToString("0.0", System.Globalization.CultureInfo.InvariantCulture)
                : v.ToString("0", System.Globalization.CultureInfo.InvariantCulture);
            return s;
        }

        /// <summary>
        /// Groups per-asset verdicts into certificate rows, one per top-level Resources folder.
        /// </summary>
        /// <param name="verdicts">Every classified asset.</param>
        /// <param name="folderOf">
        /// Maps an asset path to the Resources folder that owns it. Injected rather than derived here
        /// so this type stays free of path policy, which lives with the indexer that established it.
        /// </param>
        /// <returns>Rows, heaviest first.</returns>
        /// <remarks>
        /// ⚠️ Sorted by TOTAL tonnage rather than by displacement, because the chart's job is to show
        /// where the weight IS before it shows what can be moved. Sorting by displacement would put a
        /// tiny folder that happens to be fully unreached above the 400 MB folder that is the actual
        /// subject, and the buyer would read the chart as saying the big folder is fine.
        /// </remarks>
        public static List<LadingRow> GroupRows(
            IReadOnlyList<AssetVerdict>? verdicts,
            Func<string, string>? folderOf)
        {
            var rows = new List<LadingRow>();
            if (verdicts == null || folderOf == null) return rows;

            var reached = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);
            var unreached = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);
            var indet = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);
            var nR = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            var nU = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            var nI = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            var order = new List<string>();

            foreach (var v in verdicts)
            {
                string folder = folderOf(v.AssetPath) ?? string.Empty;
                if (!reached.ContainsKey(folder))
                {
                    order.Add(folder);
                    reached[folder] = 0; unreached[folder] = 0; indet[folder] = 0;
                    nR[folder] = 0; nU[folder] = 0; nI[folder] = 0;
                }
                switch (v.Verdict)
                {
                    case Verdict.Reached: reached[folder] += v.Bytes; nR[folder]++; break;
                    case Verdict.Unreached: unreached[folder] += v.Bytes; nU[folder]++; break;
                    default: indet[folder] += v.Bytes; nI[folder]++; break;
                }
            }

            foreach (string f in order)
                rows.Add(new LadingRow(f, reached[f], unreached[f], indet[f], nR[f], nU[f], nI[f]));

            rows.Sort((a, b) => b.TotalBytes.CompareTo(a.TotalBytes));
            return rows;
        }
    }
}
