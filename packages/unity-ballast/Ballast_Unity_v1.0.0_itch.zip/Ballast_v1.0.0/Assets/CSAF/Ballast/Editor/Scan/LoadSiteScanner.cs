#nullable enable
// Copyright (c) 2026 Core Systems Asset Factory. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;

namespace CSAF.Ballast
{
    /// <summary>
    /// Finds every <c>Resources.Load*</c> call site in C# source text and classifies how precisely
    /// each one names what it loads.
    /// </summary>
    /// <remarks>
    /// <para>
    /// This is the product. Everything else in the package presents or acts on what this class
    /// returns, so its failure modes are the package's failure modes.
    /// </para>
    /// <para>
    /// ⛔ IT IS A LEXER, NOT A REGEX, AND THAT IS NOT GOLD-PLATING. A regex for
    /// <c>Resources\.Load</c> matches the text inside <c>// Resources.Load("x")</c> and inside the
    /// string <c>"call Resources.Load(name)"</c>. Over-matching a comment is harmless here (it only
    /// adds reachability). Under-matching is not, and the case that bites is the opposite one: a
    /// regex that tries to be clever about skipping comments will eventually skip a real call.
    /// Reading the source properly costs one pass and removes the whole class.
    /// </para>
    /// <para>
    /// ⚠️ IT DELIBERATELY DOES NOT EVALUATE PREPROCESSOR DIRECTIVES. Code inside <c>#if UNITY_EDITOR</c>
    /// or even <c>#if FALSE</c> is scanned as live. Ballast cannot know the buyer's define symbols
    /// for every build target, and a call site skipped because of a define that turns out to be set
    /// is exactly the mistake that moves a live asset out of a build. Scanning dead code costs a few
    /// unmigrated bytes; skipping live code costs the buyer a broken build.
    /// </para>
    /// </remarks>
    public static class LoadSiteScanner
    {
        /// <summary>The Resources API members that take a resource path.</summary>
        /// <remarks>
        /// ⚠️ Kept as an explicit list rather than a "starts with Load" test, because
        /// <c>Resources.LoadAll</c> and <c>Resources.Load</c> have different REACH (a folder versus
        /// one asset) and <c>Resources.UnloadAsset</c> takes an object rather than a path. Matching
        /// by prefix would have silently swept a non-path overload into the path scanner.
        /// </remarks>
        private static readonly string[] Members = { "LoadAll", "LoadAsync", "Load" };

        /// <summary>
        /// Scans one C# file's text.
        /// </summary>
        /// <param name="source">The full source text.</param>
        /// <param name="file">Project-relative path, recorded on each site for the citation.</param>
        public static List<LoadSite> Scan(string? source, string file)
        {
            var found = new List<LoadSite>();
            if (source == null || source.Length == 0) return found;

            int i = 0;
            int line = 1;
            int n = source.Length;

            while (i < n)
            {
                char c = source[i];

                // ---- newline bookkeeping -------------------------------------------------
                if (c == '\n') { line++; i++; continue; }

                // ---- comments ------------------------------------------------------------
                if (c == '/' && i + 1 < n)
                {
                    if (source[i + 1] == '/')
                    {
                        while (i < n && source[i] != '\n') i++;
                        continue;
                    }
                    if (source[i + 1] == '*')
                    {
                        i += 2;
                        while (i + 1 < n && !(source[i] == '*' && source[i + 1] == '/'))
                        {
                            if (source[i] == '\n') line++;
                            i++;
                        }
                        i = Math.Min(i + 2, n);
                        continue;
                    }
                }

                // ---- character literal ---------------------------------------------------
                if (c == '\'')
                {
                    i++;
                    while (i < n && source[i] != '\'')
                    {
                        if (source[i] == '\\') i++;
                        if (i < n && source[i] == '\n') line++;
                        i++;
                    }
                    i = Math.Min(i + 1, n);
                    continue;
                }

                // ---- string literals -----------------------------------------------------
                // Skipped wholesale: a Resources.Load written inside a string is text, not a call.
                // ⚠️ The prefix run is matched by IsStringStart rather than by hand, because C#
                // allows BOTH orders — $@"..." and @$"..." are the same verbatim interpolated
                // string. An earlier hand-written condition here accepted $@ and missed @$, which
                // would leave the scanner parsing the string's CONTENTS as code. That direction is
                // not merely untidy: mis-locating a string's end can hide a later real call site,
                // and a missed call site is the one error this product cannot afford.
                if (IsStringStart(source, i))
                {
                    int startLine = line;
                    i = SkipStringLike(source, i, ref line);
                    if (i < 0) { i = n; line = startLine; }
                    continue;
                }

                // ---- the call we are looking for -----------------------------------------
                if (c == 'R' && Matches(source, i, "Resources"))
                {
                    // Must be a whole identifier: "MyResources.Load" is not Resources.Load.
                    if (i > 0 && IsIdentChar(source[i - 1])) { i++; continue; }

                    int j = SkipTrivia(source, i + "Resources".Length, ref line);
                    if (j < n && source[j] == '.')
                    {
                        j = SkipTrivia(source, j + 1, ref line);
                        foreach (var member in Members)
                        {
                            if (!Matches(source, j, member)) continue;
                            int after = j + member.Length;
                            // Reject a longer identifier that merely starts with the member name.
                            if (after < n && IsIdentChar(source[after])) continue;

                            int k = SkipTrivia(source, after, ref line);
                            k = SkipGenericArgs(source, k, ref line);
                            k = SkipTrivia(source, k, ref line);
                            if (k < n && source[k] == '(')
                            {
                                string arg = ReadFirstArgument(source, k, out int endOfCall);
                                var site = Classify(arg, file, line, member == "LoadAll");
                                found.Add(site);
                                i = Math.Max(endOfCall, k + 1);
                                goto continueOuter;
                            }
                        }
                    }
                    i++;
                    continue;
                }

                i++;
                continueOuter: ;
            }

            return found;
        }

        // ------------------------------------------------------------------ classification

        /// <summary>
        /// Turns the raw text of the first argument into a <see cref="LoadSite"/>.
        /// </summary>
        /// <remarks>
        /// ⛔ Every path out of this method that is not certain returns
        /// <see cref="LoadPrecision.Opaque"/>. There is deliberately no "probably fine" branch.
        /// </remarks>
        internal static LoadSite Classify(string? arg, string file, int line, bool isLoadAll)
        {
            // ⚠️ Narrowed into a local non-nullable rather than tested with
            // string.IsNullOrWhiteSpace: this wing's own checklist says in terms "never rely on
            // string.IsNullOrEmpty to narrow a string?", because the compiler's flow analysis does
            // not treat it as a null test and -warnaserror then turns CS8604 into a failed gate.
            // Written this way it is both correct and unarguable.
            string a = arg ?? string.Empty;
            string snippet = a.Trim();
            if (snippet.Length == 0)
                return new LoadSite(file, line, string.Empty, LoadPrecision.Opaque, isLoadAll, snippet);

            if (TryEvaluateConstantPrefix(a, out string prefix, out bool complete))
            {
                if (complete)
                    return new LoadSite(file, line, NormalisePath(prefix), LoadPrecision.Literal, isLoadAll, snippet);

                // ⛔ ORDER MATTERS HERE AND GETTING IT WRONG COST THREE FAILING TESTS.
                // The prefix must be trimmed to its last COMPLETE folder BEFORE any normalising,
                // because NormalisePath strips a trailing slash — and for `Load("icons/" + x)` that
                // slash IS the evidence that the known text ended on a folder boundary. Normalising
                // first turned "icons/" into "icons", after which TrimToFolder found no separator
                // and returned "", i.e. "we learned nothing", i.e. every asset Indeterminate.
                // ⚠️ The failure was in the SAFE direction (the product would simply have found
                // nothing to migrate), which is exactly why it needed a test to catch it rather
                // than a bug report — nothing would have looked broken.
                string folder = TrimToFolder(prefix.Replace('\\', '/'));
                while (folder.StartsWith("/", System.StringComparison.Ordinal)) folder = folder.Substring(1);

                // ⚠️ Deliberately NOT NormalisePath: that strips a trailing extension, and a FOLDER
                // may legitimately contain a dot ("assets/v1.2" would become "assets/v1").
                if (folder.Length == 0)
                    return new LoadSite(file, line, string.Empty, LoadPrecision.Opaque, isLoadAll, snippet);

                return new LoadSite(file, line, folder, LoadPrecision.Prefixed, isLoadAll, snippet);
            }

            return new LoadSite(file, line, string.Empty, LoadPrecision.Opaque, isLoadAll, snippet);
        }

        /// <summary>
        /// Reads as much of a constant string as the argument expression begins with.
        /// </summary>
        /// <param name="complete">
        /// True when the ENTIRE expression was constant, so the resulting string is the exact path.
        /// </param>
        /// <remarks>
        /// Handles the four shapes that appear in real projects: a plain literal, a verbatim
        /// literal, concatenation with <c>+</c>, and interpolation. ⚠️ An interpolated string with
        /// no holes (<c>$"icons/sword"</c>) is COMPLETE — it is just a literal wearing a dollar
        /// sign — and treating it as prefixed would protect a whole folder for no reason.
        /// </remarks>
        internal static bool TryEvaluateConstantPrefix(string arg, out string prefix, out bool complete)
        {
            prefix = string.Empty;
            complete = false;

            var sb = new StringBuilder();
            int i = 0;
            int n = arg.Length;
            bool sawAny = false;

            while (true)
            {
                i = SkipWhitespace(arg, i);
                if (i >= n) break;

                if (arg[i] == '"' || arg[i] == '@' || arg[i] == '$')
                {
                    if (!TryReadStringPiece(arg, ref i, sb, out bool pieceComplete))
                        return sawAny && Finish(sb, out prefix, out complete, false);

                    sawAny = true;
                    if (!pieceComplete)
                        return Finish(sb, out prefix, out complete, false);   // hole -> prefix only
                }
                else
                {
                    // A non-literal term. Anything already accumulated is a usable prefix.
                    return sawAny && Finish(sb, out prefix, out complete, false);
                }

                i = SkipWhitespace(arg, i);
                if (i < n && arg[i] == '+') { i++; continue; }   // concatenation continues
                break;
            }

            if (!sawAny) return false;
            return Finish(sb, out prefix, out complete, true);
        }

        private static bool Finish(StringBuilder sb, out string prefix, out bool complete, bool isComplete)
        {
            prefix = sb.ToString();
            complete = isComplete;
            return true;
        }

        /// <summary>
        /// Reads one string literal (plain, verbatim, or interpolated) starting at
        /// <paramref name="i"/>, appending its constant leading text to <paramref name="sb"/>.
        /// </summary>
        /// <param name="pieceComplete">
        /// False when the literal contained an interpolation hole, so only a prefix was recovered.
        /// </param>
        private static bool TryReadStringPiece(string s, ref int i, StringBuilder sb, out bool pieceComplete)
        {
            pieceComplete = false;
            bool interpolated = false;
            bool verbatim = false;
            int n = s.Length;

            while (i < n && (s[i] == '$' || s[i] == '@'))
            {
                if (s[i] == '$') interpolated = true;
                if (s[i] == '@') verbatim = true;
                i++;
            }
            if (i >= n || s[i] != '"') return false;
            i++;

            while (i < n)
            {
                char c = s[i];

                if (verbatim)
                {
                    if (c == '"')
                    {
                        if (i + 1 < n && s[i + 1] == '"') { sb.Append('"'); i += 2; continue; }
                        i++; pieceComplete = true; return true;
                    }
                }
                else
                {
                    if (c == '\\' && i + 1 < n)
                    {
                        // Only the escapes that can legally appear in a resource path are decoded;
                        // anything else makes the value uncertain, so we stop and keep the prefix.
                        char e = s[i + 1];
                        if (e == '\\') { sb.Append('/'); i += 2; continue; }  // "a\\b" is a path sep
                        if (e == '"') { sb.Append('"'); i += 2; continue; }
                        return true;   // unknown escape -> prefix only, pieceComplete stays false
                    }
                    if (c == '"') { i++; pieceComplete = true; return true; }
                }

                if (interpolated && c == '{')
                {
                    if (i + 1 < n && s[i + 1] == '{') { sb.Append('{'); i += 2; continue; }
                    return true;   // a real hole -> everything before it is the prefix
                }

                sb.Append(c);
                i++;
            }

            return true;   // unterminated -> treat what we have as a prefix
        }

        // ------------------------------------------------------------------ path helpers

        /// <summary>
        /// Normalises a resource path the way <c>Resources.Load</c> itself does.
        /// </summary>
        /// <remarks>
        /// ⚠️ The extension strip is required for correctness, not tidiness: Unity ignores the
        /// extension in a resource path, so a call site written "icons/sword.png" and the asset
        /// "icons/sword" are the same resource. Comparing them without stripping would report the
        /// asset UNREACHED and offer to migrate something the game loads.
        /// </remarks>
        public static string NormalisePath(string? raw)
        {
            if (raw == null || raw.Length == 0) return string.Empty;
            string p = raw.Replace('\\', '/').Trim();
            while (p.StartsWith("/", StringComparison.Ordinal)) p = p.Substring(1);
            while (p.EndsWith("/", StringComparison.Ordinal)) p = p.Substring(0, p.Length - 1);

            int slash = p.LastIndexOf('/');
            int dot = p.LastIndexOf('.');
            if (dot > slash && dot >= 0) p = p.Substring(0, dot);
            return p;
        }

        /// <summary>
        /// Reduces a partial path to the last complete FOLDER it names.
        /// </summary>
        /// <remarks>
        /// ⛔ This is the subtle one. For <c>Resources.Load("icons/" + slug)</c> the known prefix is
        /// "icons/" and the reachable set is the "icons" folder. But for
        /// <c>Resources.Load("icons/sw" + rest)</c> the known prefix is "icons/sw", which is NOT a
        /// folder — the reachable set is still the whole "icons" folder, because "sw" is a partial
        /// FILE name. Keeping "icons/sw" as the prefix would protect only assets whose path happens
        /// to start with those letters and quietly expose "icons/axe". Trimming back to the last
        /// separator is what makes the taint correct.
        /// </remarks>
        public static string TrimToFolder(string? partial)
        {
            if (partial == null || partial.Length == 0) return string.Empty;
            int slash = partial.LastIndexOf('/');
            return slash < 0 ? string.Empty : partial.Substring(0, slash);
        }

        // ------------------------------------------------------------------ lexing helpers

        /// <summary>
        /// True when a string-like token starts at <paramref name="i"/>: a plain <c>"</c>, or any
        /// run of <c>$</c> and <c>@</c> prefixes followed by a quote.
        /// </summary>
        /// <remarks>
        /// Accepts both <c>$@"..."</c> and <c>@$"..."</c>, which C# treats as identical. Written as
        /// one predicate used by BOTH the main scan loop and the argument reader, so the two cannot
        /// disagree about where a string begins — two places deciding the same thing independently
        /// is how they drift.
        /// </remarks>
        private static bool IsStringStart(string s, int i)
        {
            int k = i;
            while (k < s.Length && (s[k] == '$' || s[k] == '@')) k++;
            return k < s.Length && s[k] == '"';
        }

        private static bool Matches(string s, int i, string word)
        {
            if (i < 0 || i + word.Length > s.Length) return false;
            for (int k = 0; k < word.Length; k++)
                if (s[i + k] != word[k]) return false;
            return true;
        }

        private static bool IsIdentChar(char c) => char.IsLetterOrDigit(c) || c == '_';

        private static int SkipWhitespace(string s, int i)
        {
            while (i < s.Length && char.IsWhiteSpace(s[i])) i++;
            return i;
        }

        /// <summary>Skips whitespace and comments, keeping the line counter honest.</summary>
        private static int SkipTrivia(string s, int i, ref int line)
        {
            while (i < s.Length)
            {
                char c = s[i];
                if (c == '\n') { line++; i++; continue; }
                if (char.IsWhiteSpace(c)) { i++; continue; }
                if (c == '/' && i + 1 < s.Length && s[i + 1] == '/')
                {
                    while (i < s.Length && s[i] != '\n') i++;
                    continue;
                }
                if (c == '/' && i + 1 < s.Length && s[i + 1] == '*')
                {
                    i += 2;
                    while (i + 1 < s.Length && !(s[i] == '*' && s[i + 1] == '/'))
                    {
                        if (s[i] == '\n') line++;
                        i++;
                    }
                    i = Math.Min(i + 2, s.Length);
                    continue;
                }
                break;
            }
            return i;
        }

        /// <summary>Skips a generic argument list such as <c>&lt;Sprite&gt;</c> if present.</summary>
        private static int SkipGenericArgs(string s, int i, ref int line)
        {
            if (i >= s.Length || s[i] != '<') return i;
            int depth = 0;
            int start = i;
            while (i < s.Length)
            {
                char c = s[i];
                if (c == '\n') line++;
                if (c == '<') depth++;
                else if (c == '>') { depth--; if (depth == 0) return i + 1; }
                // A generic argument list cannot contain these; if we see one we mis-read a
                // comparison operator, so rewind rather than swallow the rest of the file.
                else if (c == ';' || c == '{' || c == '}') return start;
                i++;
            }
            return start;
        }

        /// <summary>
        /// Skips a whole string-like token (plain, verbatim, interpolated) starting at
        /// <paramref name="i"/>. Returns the index just past it, or -1 if unterminated.
        /// </summary>
        private static int SkipStringLike(string s, int i, ref int line)
        {
            bool verbatim = false;
            int n = s.Length;
            while (i < n && (s[i] == '$' || s[i] == '@'))
            {
                if (s[i] == '@') verbatim = true;
                i++;
            }
            if (i >= n || s[i] != '"') return i;
            i++;

            int braceDepth = 0;
            while (i < n)
            {
                char c = s[i];
                if (c == '\n') line++;

                if (verbatim)
                {
                    if (c == '"')
                    {
                        if (i + 1 < n && s[i + 1] == '"') { i += 2; continue; }
                        return i + 1;
                    }
                    i++;
                    continue;
                }

                if (c == '\\') { i += 2; continue; }
                if (c == '{') { braceDepth++; i++; continue; }
                if (c == '}') { if (braceDepth > 0) braceDepth--; i++; continue; }
                if (c == '"' && braceDepth == 0) return i + 1;
                i++;
            }
            return -1;
        }

        /// <summary>
        /// Reads the text of the first argument of a call whose '(' is at <paramref name="open"/>.
        /// </summary>
        private static string ReadFirstArgument(string s, int open, out int endOfCall)
        {
            int i = open + 1;
            int depth = 0;
            var sb = new StringBuilder();
            int n = s.Length;
            int dummyLine = 0;

            while (i < n)
            {
                char c = s[i];

                if (IsStringStart(s, i))
                {
                    int next = SkipStringLike(s, i, ref dummyLine);
                    if (next <= i) { sb.Append(c); i++; continue; }
                    sb.Append(s, i, next - i);
                    i = next;
                    continue;
                }

                if (c == '(' || c == '[') { depth++; sb.Append(c); i++; continue; }
                if (c == ')' && depth == 0) { endOfCall = i + 1; return sb.ToString(); }
                if (c == ')' || c == ']') { depth--; sb.Append(c); i++; continue; }
                if (c == ',' && depth == 0) { endOfCall = i; return sb.ToString(); }

                sb.Append(c);
                i++;
            }

            endOfCall = n;
            return sb.ToString();
        }
    }
}
