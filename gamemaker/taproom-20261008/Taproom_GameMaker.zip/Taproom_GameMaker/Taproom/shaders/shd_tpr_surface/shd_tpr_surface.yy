{
  "$GMShader": "",
  "%Name": "shd_tpr_surface",
  "name": "shd_tpr_surface",
  "parent": {
    "name": "Shaders",
    "path": "folders/Shaders.yy"
  },
  "resourceType": "GMShader",
  "resourceVersion": "2.0",
  "type": 1
}