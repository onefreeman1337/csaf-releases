//
// shd_tpr_surface (fragment) - Taproom's eight board materials and the tavern table, painted per pixel on the GPU.
// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
//
// The formulas are the RPG Maker MZ edition's (TaproomDraw.js surfaceAt / fillSurface / drawTable), line for line. ONE
// deliberate difference: the integer hash under the value noise. GLSL ES 1.00 has no integer arithmetic to run the MZ's
// Math.imul hash, so the hash is two permutation polynomials, (34v + 1) v mod 289 and mod 283, whose every intermediate
// is an integer below 2^24 - EXACT in a 32-bit float and in a double alike - mixed into one value (period 289 x 283 in each
// axis). tpr_surface_lt / tpr_table_lt are the CPU twins of this file; the self-test holds every material to them pixel by
// pixel.
// ⛔ No texture is read here, on purpose: an earlier version read the hash from a lattice TEXTURE inside the noise loops,
// and GameMaker's shader compiler (FXC) unrolled every loop round the texture reads - the asset compile took 5.8 minutes
// (MEASURED 2026-10-08, GMA Elapsed 347,361 ms), a cost every buyer's build would have paid.
// Why on the GPU: painted per pixel on the GameMaker VM these materials cost 54-119 microseconds a pixel (MEASURED), i.e.
// 37 seconds for one board.
//
precision highp float;

varying vec2 v_vTexcoord;   // the CANVAS point of this fragment
varying vec4 v_vColour;

uniform float u_mode;       // 0 slate, 1 marble, 2 knifed, 3 lacquer, 4 linen, 5 leather, 6 walnut, 7 soapstone, 8 table
uniform vec4 u_seed;        // the seed's offsets: (s mod 289, floor(s / 289) mod 289, s mod 283, floor(s / 283) mod 283)
uniform vec4 u_rect;        // the painted rectangle (x, y, w, h); the lamp falls across it
uniform vec4 u_clip;        // the rounded clip rectangle (x, y, w, h)
uniform vec2 u_clipr;       // (corner radius, canvas pixels per device pixel)
uniform float u_half;       // the MZ samples a pixel at its top-left corner: half a device pixel, in canvas units
uniform vec2 u_table;       // the table's W and H (mode 8)

float p289(float v) { return mod((34.0 * v + 1.0) * v, 289.0); }
float p283(float v) { return mod((34.0 * v + 1.0) * v, 283.0); }

// the hash of lattice cell (ix, iy) at seed delta k: in [0, 1)
float lhash(float ix, float iy, float k) {
    float a = p289(mod(p289(mod(ix + u_seed.x + 37.0 * k, 289.0)) + mod(iy + u_seed.y + 19.0 * k, 289.0), 289.0));
    float b = p283(mod(p283(mod(ix + u_seed.z + 41.0 * k, 283.0)) + mod(iy + u_seed.w + 23.0 * k, 283.0), 283.0));
    return fract(a / 289.0 + b / 283.0);
}

float vnoise(float x, float y, float k) {
    float xi = floor(x);
    float yi = floor(y);
    float xf = x - xi;
    float yf = y - yi;
    float u = xf * xf * (3.0 - 2.0 * xf);
    float v = yf * yf * (3.0 - 2.0 * yf);
    float a = lhash(xi, yi, k);
    float b = lhash(xi + 1.0, yi, k);
    float c = lhash(xi, yi + 1.0, k);
    float d = lhash(xi + 1.0, yi + 1.0, k);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}

float fbm(float x, float y, float k, float oct) {
    float t = 0.0;
    float amp = 0.5;
    float f = 1.0;
    float n = 0.0;
    for (int i = 0; i < 5; i++) {
        if (float(i) >= oct) break;
        t += amp * vnoise(x * f, y * f, k + float(i) * 17.0);
        n += amp;
        amp *= 0.5;
        f *= 2.03;
    }
    return t / n;
}

vec3 material(float id, float x, float y) {
    float n = fbm(x / 60.0, y / 60.0, 0.0, 4.0);
    float f = vnoise(x / 3.2, y / 3.2, 99.0);
    float t;
    if (id < 0.5) {   // slate
        t = (n - 0.5) * 22.0 + (f - 0.5) * 8.0 + sin((y + n * 26.0) * 0.22) * 3.0;
        return vec3(60.0 + t, 66.0 + t, 76.0 + t * 1.1);
    }
    if (id < 1.5) {   // marble
        float vv = abs(sin(x * 0.012 + y * 0.018 + fbm(x / 90.0, y / 90.0, 5.0, 5.0) * 9.0));
        float vein = pow(1.0 - vv, 14.0);
        float v2 = pow(1.0 - abs(sin(x * 0.03 - y * 0.011 + n * 7.0)), 30.0);
        t = (n - 0.5) * 12.0;
        vec3 c = vec3(222.0 + t, 216.0 + t, 204.0 + t);
        c = c + (vec3(120.0, 134.0, 124.0) - c) * (vein * 0.7);
        return c + (vec3(150.0, 156.0, 150.0) - c) * (v2 * 0.45);
    }
    if (id < 2.5 || (id > 5.5 && id < 6.5)) {   // knifed tabletop, walnut
        float g = fbm(x / 400.0, y / 16.0, 3.0, 3.0);
        float g2 = fbm(x / 120.0, y / 120.0, 0.0, 2.0);
        float gr = sin((y + g * 40.0 + g2 * 30.0) * ((id > 5.5) ? 0.6 : 0.42));
        float k = gr * 0.5 + 0.5;
        t = (n - 0.5) * 18.0 - pow(k, 6.0) * 26.0 + (f - 0.5) * 6.0;
        vec3 b = (id > 5.5) ? vec3(96.0, 60.0, 38.0) : vec3(132.0, 90.0, 52.0);
        return vec3(b.x + t, b.y + t * 0.8, b.z + t * 0.6);
    }
    if (id < 3.5) {   // black lacquer
        t = (n - 0.5) * 8.0 + (f - 0.5) * 3.0;
        float dx = x - 120.0;
        float dy = y - 90.0;
        float sheen = max(0.0, 1.0 - sqrt(dx * dx + dy * dy) / 420.0) * 22.0;
        return vec3(26.0 + t + sheen, 20.0 + t + sheen * 0.9, 22.0 + t + sheen * 0.9);
    }
    if (id < 4.5) {   // linen
        float w = (sin(x * 2.1) * sin(y * 2.1)) * 7.0;
        float s1 = pow(vnoise(x / 2.0, y / 40.0, 7.0), 8.0) * 26.0;
        float s2 = pow(vnoise(x / 40.0, y / 2.0, 8.0), 8.0) * 20.0;
        t = w - (s1 + s2) + (n - 0.5) * 14.0;
        return vec3(212.0 + t, 196.0 + t, 162.0 + t * 0.9);
    }
    if (id < 5.5) {   // tooled leather
        float peb = pow(vnoise(x / 2.4, y / 2.4, 11.0), 3.0) * 16.0;
        t = (n - 0.5) * 26.0 - peb + (f - 0.5) * 4.0;
        return vec3(118.0 + t, 66.0 + t * 0.8, 38.0 + t * 0.7);
    }
    // soapstone
    float sp = (lhash(floor(x), floor(y), 13.0) > 0.985) ? -30.0 : 0.0;
    t = (n - 0.5) * 20.0 + (f - 0.5) * 6.0 + sp;
    return vec3(150.0 + t, 160.0 + t, 142.0 + t);
}

vec3 table(float x, float y) {
    float plank = 104.0;
    // + 0.0001: (y + 30) / 104 at a seam is an exact integer that a GPU's reciprocal division can land one ulp under; every
    // other sample's fraction is at least 1/208, so the nudge never moves a row (the CPU twin carries the same nudge)
    float row = floor((y + 30.0) / plank + 0.0001);
    float py = (y + 30.0) - row * plank;
    float off = lhash(row, 1.0, 0.0) * 900.0;
    float g = fbm((x + off) / 500.0, py / 14.0, row, 3.0);
    float gr = sin((py + g * 36.0) * 0.5) * 0.5 + 0.5;
    float knot = 0.0;
    float kx = lhash(row, 2.0, 0.0) * u_table.x;
    float ky = row * plank + plank * 0.5 - 30.0;
    float kdx = (x - kx) / 2.2;
    float kdy = y - ky;
    float kd = sqrt(kdx * kdx + kdy * kdy);
    if (kd < 26.0) knot = pow(1.0 - kd / 26.0, 2.0) * 38.0 * (0.6 + 0.4 * sin(kd * 1.3));
    float t = (fbm(x / 70.0, y / 70.0, 5.0, 3.0) - 0.5) * 22.0 - pow(gr, 5.0) * 22.0 - knot;
    vec3 base = vec3(98.0 + t, 62.0 + t * 0.8, 36.0 + t * 0.6);
    if (py < 3.0 || py > plank - 2.0) {
        float m = (py < 3.0) ? (0.75 - py * 0.2) : 0.55;
        base = base + (vec3(22.0, 12.0, 6.0) - base) * m;
    }
    float lx = x - u_table.x * 0.32;
    float ly = y - u_table.y * 0.28;
    float lamp = max(0.22, 1.12 - sqrt(lx * lx + ly * ly) / (u_table.x * 0.78));
    return base * lamp;
}

void main()
{
    // the sample point snapped to the device-pixel grid: an interpolated coordinate is off by ~1e-5, and the table's plank
    // rows and the soapstone's speckle FLOOR it, so an unsnapped point lands a seam or a speck one pixel away now and then
    float k = 1.0 / u_clipr.y;
    vec2 p = floor((v_vTexcoord - u_half) * k + 0.5) / k;
    vec3 col;
    if (u_mode > 7.5) {
        col = table(p.x, p.y);
    } else {
        vec3 v = material(u_mode, p.x, p.y);
        float lamp = 1.08 - 0.26 * (((p.x - u_rect.x) / u_rect.z) * 0.55 + ((p.y - u_rect.y) / u_rect.w) * 0.45);
        col = v * lamp;
    }
    col = clamp(col, 0.0, 255.0);
    // coverage of the rounded clip, measured at the fragment's own centre
    vec2 hc = u_clip.zw * 0.5;
    vec2 q = abs(v_vTexcoord - (u_clip.xy + hc)) - (hc - u_clipr.x);
    float sd = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - u_clipr.x;
    float cov = clamp(0.5 - sd / u_clipr.y, 0.0, 1.0);
    gl_FragColor = vec4(col / 255.0, cov * v_vColour.a);
}
