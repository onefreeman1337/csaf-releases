/// @description THE TAPROOM - one frame: the room, or the table while a game is on.
if (is_struct(demo)) tpr_demo_step(demo);
