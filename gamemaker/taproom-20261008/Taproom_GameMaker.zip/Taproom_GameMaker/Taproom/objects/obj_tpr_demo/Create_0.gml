/// @description THE TAPROOM - Taproom's demo room. Six regulars round the table; click one to sit down and play. Run with
/// -selftest it is the headless test suite instead (writes tpr_selftest.json and exits).
/// ⛔ The crash handler is installed FIRST, and every variable a later event reads is declared ABOVE the early exits:
/// Clean Up always runs, even when Create leaves early.
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("tpr_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.tpr_stage) + ": " + string(_ex.message) + " | " + string(_ex.stacktrace));
    file_text_close(_f);
    game_end();
});
global.tpr_stage = 0;
demo = undefined;
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";
if (string_pos("-selftest", _args) > 0) { global.tpr_stage = 1; tpr_selftest_write(tpr_selftest_run()); game_end(); exit; }
demo = tpr_demo_create(display_get_gui_width(), display_get_gui_height());
