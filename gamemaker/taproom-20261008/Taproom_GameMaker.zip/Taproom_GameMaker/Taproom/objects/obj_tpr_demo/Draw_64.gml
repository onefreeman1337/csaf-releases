/// @description THE TAPROOM - drawn in the GUI layer (the table reads the mouse in GUI coordinates).
if (is_struct(demo)) tpr_demo_draw(demo);
