/// tpr_selftest.gml - Taproom's in-engine self-test, run headless by the demo object with -selftest. Holds the GML port to the
/// RPG Maker MZ edition's TaproomCore run in Node (tpr_oracle_core): hashes and generator draws EXACT, 16 playouts with every
/// move list, result and evaluation EXACT, the opponent's move / score / node count EXACT at every grade checked, and the
/// search giving the same answer however it is sliced. Writes tpr_selftest.json. FIRST CUT: the rules and the opponent.

/// @function tpr_st_assert(state, condition, message)
function tpr_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 60) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
/// @function tpr_st_stage(state, n)
function tpr_st_stage(_st, _n) { _st.stage = _n; global.tpr_stage = _n; }

/// @function tpr__st_hash2_ref(x, y, s)
/// @description Internal (test). The board hash as first ported - every Math.imul a tpr__imul call - kept as the reference
/// the inlined tpr__hash2 is compared and timed against.
function tpr__st_hash2_ref(_x, _y, _s) {
    var _m = int64($FFFFFFFF);
    var _h = (tpr__imul(int64(_x) & _m, 374761393) ^ tpr__imul(int64(_y) & _m, 668265263)) ^ tpr__imul(int64(_s) & _m, 1274126177);
    _h = tpr__imul(_h ^ (_h >> 13), 1103515245);
    _h = _h ^ (_h >> 16);
    return real(_h & _m) / 4294967296;
}

/// @function tpr__st_draw_case(ctx, row, oracle, gids, bids, sids)
/// @description Internal (test). Draw one oracle case through the GML painter (the same call the MZ recorder made) and
/// return "" or a description of a returned count that differs from the MZ's.
function tpr__st_draw_case(_c, _row, _O, _gids, _bids, _sids) {
    var _k = _row[0];
    switch (_k) {
        case 0: {
            var _gi = _row[1], _bi = _row[2], _L = tpr_layout(_gids[_gi], 816, 624), _wear = 0.5 + ((_gi * 8 + _bi) mod 10) / 10;
            var _o = tpr_draw_board(_c, _L, { board: _bids[_bi], set: "stones", seed: _row[3], wear: _wear });
            var _a = _o.lines * 1000 + _o.points, _b = _o.border * 1000 + _o.pits + _o.wear.scratches * 100000 + _o.wear.chips * 10000000;
            return (_a == _row[5] && _b == _row[6] && floor(_wear * 100 + 0.5) == _row[4]) ? "" : "counts " + string(_a) + "/" + string(_row[5]) + " " + string(_b) + "/" + string(_row[6]);
        }
        case 1: tpr_draw_table(_c, _row[1], _row[2], _row[3]); return "";
        case 2: { var _lifts = [0, 0.5, 1]; tpr_draw_man(_c, 60, 60, _row[4], _sids[_row[1]], (_row[2] == 2) ? "fox" : _row[2], _row[5], _lifts[_row[3]]); return ""; }
        case 3: { var _pl = tpr_draw_seeds(_c, 50, 50, 40, _row[2], _sids[_row[1]], _row[4]); return (_pl == _row[3]) ? "" : "placed " + string(_pl) + "/" + string(_row[3]); }
        case 4: tpr_draw_count(_c, 40, 40, _row[2], tpr_board_info(_bids[_row[1]]), _row[3]); return "";
        case 5: {
            var _labs = ["Rules", "Stop", "Concede"], _sts = ["idle", "on", "off"], _sz = [[66, 36], [174, 38]];
            var _fs = tpr_draw_plaque(_c, 10, 10, _sz[_row[3]][0], _sz[_row[3]][1], _labs[_row[1]], _sts[_row[2]]);
            return (_fs == _row[4]) ? "" : "fitted size " + string(_fs) + "/" + string(_row[4]);
        }
        case 6: tpr_draw_placard(_c, 20, 20, _row[2], _row[3], _O.placards[_row[1]]); return "";
        case 7: { var _n = tpr_draw_status(_c, _row[2], _row[3], _O.status_texts[_row[1]]); return (_n == _row[4]) ? "" : "lines " + string(_n) + "/" + string(_row[4]); }
        case 8: { var _kinds = ["target", "sel", "take", "last"]; tpr_draw_marker(_c, 50, 50, 23, _kinds[_row[1]]); return ""; }
        case 9: tpr_draw_verdict(_c, 816, 624, _O.verdict, 294, 294); return "";
    }
    return "unknown case kind " + string(_k);
}

/// @function tpr_selftest_run()
/// @returns {Struct} { total, pass, fail, stage, failures, notes, metrics }
function tpr_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, stage: 0, notes: [], failures: [], metrics: {} };
    var _O = tpr_oracle_core(), _T = tpr__t();
    var _eps0 = math_get_epsilon();
    _st.metrics.epsilonAtStart = _eps0;
    // exact comparisons: the floor (1e-11) instead of the default 1e-5, under which near values compare EQUAL
    math_set_epsilon(0);
    // ---- 1: the hash and the generator, EXACT ----
    tpr_st_stage(_st, 1);
    var _hb = 0, _hf = "";
    for (var _i = 0; _i < array_length(_O.hashes); _i++) { var _h = tpr_hash(_O.hashes[_i][0]); if (_h != _O.hashes[_i][1]) { _hb++; if (_hf == "") _hf = "'" + _O.hashes[_i][0] + "' got " + string(_h) + " want " + string(_O.hashes[_i][1]); } }
    var _rb = 0, _rf = "";
    for (var _k = 0; _k < array_length(_O.streams); _k++) {
        var _r = tpr__rng(_O.streams[_k][0]), _w = _O.streams[_k][1];
        for (var _j = 0; _j < array_length(_w); _j++) { var _v = tpr__rng_next(_r); if (_v != _w[_j]) { _rb++; if (_rf == "") _rf = "seed " + string(_O.streams[_k][0]) + " draw " + string(_j) + " got " + string_format(_v, 1, 12) + " want " + string_format(_w[_j], 1, 12); } }
    }
    tpr_st_assert(_st, _hb == 0 && _rb == 0, "FNV hash on " + string(array_length(_O.hashes)) + " strings (" + string(_hb) + " differ " + _hf + ") and 3 generator streams x 20 (" + string(_rb) + " differ " + _rf + ")");
    // ---- 2: 16 playouts, every step: move count, every move's tokens, result, both evaluations ----
    tpr_st_stage(_st, 2);
    var _ids = _T.game_ids, _steps = 0, _pb = 0, _pf = "", _thinkAt = [];
    for (var _g = 0; _g < 4; _g++) {
        var _gid = _ids[_g], _rows = _O.games[$ _gid], _ri = 0, _bad = 0;
        var _cap = (_gid == "foxgeese") ? 170 : 70;
        for (var _pl = 0; _pl < 4; _pl++) {
            var _s = tpr_game_init(_gid, {});
            for (var _step = 0; _step < _cap; _step++) {
                var _ms = tpr_moves(_gid, _s), _res = tpr_result(_gid, _s);
                var _tk = "";
                for (var _m = 0; _m < array_length(_ms); _m++) _tk += ((_m > 0) ? "|" : "") + tpr__join(tpr_tokens(_gid, _ms[_m]), " ");
                var _want = _rows[_ri], _win = is_struct(_res) ? _res.winner : 9;
                var _e0 = tpr_evaluate(_gid, _s, 0), _e1 = tpr_evaluate(_gid, _s, 1);
                if (_want[0] != _pl || _want[1] != _step || _want[2] != array_length(_ms) || _want[3] != tpr_hash(_tk) || _want[4] != _win || _want[5] != _e0 || _want[6] != _e1) {
                    _bad++;
                    if (_pf == "") _pf = _gid + " playout " + string(_pl) + " step " + string(_step) + ": moves " + string(array_length(_ms)) + "/" + string(_want[2]) + " hash " + string(tpr_hash(_tk)) + "/" + string(_want[3]) + " result " + string(_win) + "/" + string(_want[4]) + " eval " + string(_e0) + "," + string(_e1) + "/" + string(_want[5]) + "," + string(_want[6]);
                }
                if (_pl < 2 && (_step mod 6) == 0 && !is_struct(_res) && array_length(_ms) > 1) array_push(_thinkAt, { g: _gid, pl: _pl, step: _step, s: _s });
                _ri++; _steps++;
                if (is_struct(_res) || array_length(_ms) == 0) break;
                _s = tpr_apply(_gid, _s, _ms[(_step * 7 + _pl * 13 + 3) mod array_length(_ms)]);
            }
        }
        if (_ri != array_length(_rows)) { _bad++; if (_pf == "") _pf = _gid + ": " + string(_ri) + " steps played, the oracle has " + string(array_length(_rows)); }
        _pb += _bad;
    }
    _st.metrics.playoutSteps = _steps;
    tpr_st_assert(_st, _pb == 0 && _steps >= 1000, string(_steps) + " playout steps over 4 games x 4 playouts against the MZ rules, " + string(_pb) + " differ " + _pf);
    // ---- 3: the opponent - move, score and nodes EXACT at every grade checked; and its cost on this runtime ----
    tpr_st_stage(_st, 3);
    var _tb = 0, _tf = "", _ti = 0, _exact3 = 0, _capped3 = 0, _nodes = { morris: 0, foxgeese: 0, oware: 0, fanorona: 0 }, _us = { morris: 0, foxgeese: 0, oware: 0, fanorona: 0 };
    for (var _a = 0; _a < array_length(_thinkAt); _a++) {
        var _at = _thinkAt[_a];
        var _top = (_T.depth[$ _at.g][4] <= 4) ? 4 : 3;
        for (var _gr = 1; _gr <= _top; _gr++) {
            var _row = _O.thinks[_ti]; _ti++;
            var _t0 = get_timer();
            var _th = tpr_best_move(_at.g, _at.s, _gr, _row[4]);
            // the rate counts EVERY node expanded (all the depths the search deepened through), against the time it took
            _us[$ _at.g] += get_timer() - _t0; _nodes[$ _at.g] += (_th[$ "tpr_id"] == true) ? _th.nodes_total : _th.nodes;
            if (_th[$ "tpr_id"] != true) { _tb++; if (_tf == "") _tf = _at.g + " step " + string(_at.step) + ": not a budgeted search"; continue; }
            var _mh = tpr_hash(tpr__join(tpr_tokens(_at.g, _th.move), " "));
            var _bad3 = (_row[0] != _at.g || _row[1] != _at.pl || _row[2] != _at.step || _row[3] != _gr);
            if (!_th.capped) {
                // the full depth completed inside the node budget: EXACTLY the MZ search
                _exact3++;
                if (_mh != _row[5] || _th.score != _row[6] || _th.nodes != _row[7] || _th.depth_done != _th.depth || _th.nodes_total != _th.completed_nodes) _bad3 = true;
            } else {
                // capped: the budget held, the move is the deepest COMPLETED search's, and the NEXT depth really would
                // have overrun (its fixed search, counted here, plus the depths before it, exceed the budget)
                _capped3++;
                var _fx = tpr__thinker_fixed(_at.g, _at.s, _gr, _row[4]); _fx.depth = _th.depth_done; tpr__fixed_step(_fx, infinity);
                var _nx = tpr__thinker_fixed(_at.g, _at.s, _gr, _row[4]); _nx.depth = _th.depth_done + 1; tpr__fixed_step(_nx, infinity);
                if (_th.nodes_total > _th.budget || _th.depth_done < 1 || _th.depth_done >= _th.depth || _th.completed_nodes + _nx.nodes <= _th.budget
                    || _fx.score != _th.score || _fx.nodes != _th.nodes || tpr_hash(tpr__join(tpr_tokens(_at.g, _fx.move), " ")) != _mh) _bad3 = true;
            }
            if (_bad3) {
                _tb++;
                if (_tf == "") _tf = _at.g + " playout " + string(_at.pl) + " step " + string(_at.step) + " grade " + string(_gr) + (_th.capped ? " CAPPED at depth " + string(_th.depth_done) + " of " + string(_th.depth) + ", " + string(_th.nodes_total) + " nodes" : "") + ": move " + string(_mh) + "/" + string(_row[5]) + " score " + string(_th.score) + "/" + string(_row[6]) + " nodes " + string(_th.nodes) + "/" + string(_row[7]);
            }
        }
    }
    _st.metrics.thinkCompared = _ti; _st.metrics.thinkExact = _exact3; _st.metrics.thinkCapped = _capped3;
    for (var _q = 0; _q < 4; _q++) { var _qg = _ids[_q]; _st.metrics[$ "nodesPerMs_" + _qg] = (_us[$ _qg] > 0) ? _nodes[$ _qg] / (_us[$ _qg] / 1000) : 0; _st.metrics[$ "nodes_" + _qg] = _nodes[$ _qg]; }
    tpr_st_assert(_st, _tb == 0 && _ti == array_length(_O.thinks) && _ti >= 300 && _capped3 >= 1 && _exact3 >= 300, string(_ti) + " opponent searches against the MZ Thinker: " + string(_exact3) + " completed their full depth inside the node budget and match it EXACTLY (move, score, node count); " + string(_capped3) + " were capped and played the deepest completed search, each checked against that depth's fixed search and against the next depth really overrunning the budget; " + string(_tb) + " differ " + _tf);
    // ---- 3b: the Master at every game - the node budget is the bound on how long the opponent can think ----
    var _wm = { morris: 0, foxgeese: 0, oware: 0, fanorona: 0 }, _wn = { morris: 0, foxgeese: 0, oware: 0, fanorona: 0 }, _over = 0, _per = { morris: 0, foxgeese: 0, oware: 0, fanorona: 0 }, _m5 = 0;
    for (var _a5 = 0; _a5 < array_length(_thinkAt); _a5++) {
        var _at5 = _thinkAt[_a5];
        if (_per[$ _at5.g] >= 4) continue;
        _per[$ _at5.g] += 1;
        var _t50 = get_timer(), _th5 = tpr_best_move(_at5.g, _at5.s, 5, 11 + _a5), _ms5 = (get_timer() - _t50) / 1000;
        _m5++;
        if (_th5.nodes_total > _th5.budget || is_undefined(_th5.move)) _over++;
        _wm[$ _at5.g] = max(_wm[$ _at5.g], _ms5); _wn[$ _at5.g] = max(_wn[$ _at5.g], _th5.nodes_total);
    }
    for (var _q5 = 0; _q5 < 4; _q5++) { _st.metrics[$ "masterMsWorst_" + _ids[_q5]] = _wm[$ _ids[_q5]]; _st.metrics[$ "masterNodesWorst_" + _ids[_q5]] = _wn[$ _ids[_q5]]; }
    tpr_st_assert(_st, _m5 >= 12 && _over == 0, string(_m5) + " Master searches (4 positions a game): every one chose a move inside its node budget (" + string(_over) + " over); worst " + string(round(_wm.morris)) + " / " + string(round(_wm.foxgeese)) + " / " + string(round(_wm.oware)) + " / " + string(round(_wm.fanorona)) + " ms of CPU (morris / fox and geese / oware / fanorona)");
    // ---- 4: slicing never changes the answer (budget 1 and 7 against one call) ----
    tpr_st_stage(_st, 4);
    var _sb = 0, _sf = "", _checked = 0;
    for (var _b = 0; _b < min(10, array_length(_thinkAt)); _b++) {
        var _bt = _thinkAt[_b], _whole = tpr_best_move(_bt.g, _bt.s, 3, 7 + _b);
        var _budgets = [1, 7];
        for (var _u = 0; _u < 2; _u++) {
            var _sl = tpr_thinker(_bt.g, _bt.s, 3, 7 + _b), _calls = 0;
            while (!tpr_thinker_step(_sl, _budgets[_u]) && _calls < 1000000) _calls++;
            if (_sl.score != _whole.score || _sl.nodes != _whole.nodes || tpr__join(tpr_tokens(_bt.g, _sl.move), " ") != tpr__join(tpr_tokens(_bt.g, _whole.move), " ")) { _sb++; if (_sf == "") _sf = _bt.g + " step " + string(_bt.step) + " budget " + string(_budgets[_u]); }
            _checked++;
        }
    }
    tpr_st_assert(_st, _sb == 0 && _checked == 20, string(_checked) + " sliced searches (budget 1 and 7) give the one-call move, score and nodes, " + string(_sb) + " differ " + _sf);
    // ---- 5: the eight board materials against the MZ functions (to 1e-9: sin and pow may differ in the last place), and
    //         their per-pixel cost on this runtime - the number that decides how the boards are painted ----
    tpr_st_stage(_st, 5);
    var _SO = tpr_oracle_surface(), _mx = 0, _mf = "", _sids = _SO.ids;
    for (var _r5 = 0; _r5 < array_length(_SO.rows); _r5++) {
        var _row5 = _SO.rows[_r5], _got = tpr_surface_at(_sids[_row5[0]], _row5[1], _row5[2], _row5[3]);
        for (var _c5 = 0; _c5 < 3; _c5++) { var _e5 = abs(_got[_c5] - _row5[4 + _c5]) / max(1, abs(_row5[4 + _c5])); if (_e5 > _mx) { _mx = _e5; _mf = _sids[_row5[0]] + " at " + string(_row5[1]) + "," + string(_row5[2]) + " channel " + string(_c5) + " got " + string_format(_got[_c5], 1, 9) + " want " + string_format(_row5[4 + _c5], 1, 9); } }
    }
    for (var _f5 = 0; _f5 < array_length(_SO.fbm); _f5++) { var _fr = _SO.fbm[_f5], _fv = tpr_fbm(_fr[0], _fr[1], _fr[2], 1 + (_f5 mod 5)); var _fe = abs(_fv - _fr[3]); if (_fe > _mx) { _mx = _fe; _mf = "fbm " + string(_f5) + " got " + string_format(_fv, 1, 12) + " want " + string_format(_fr[3], 1, 12); } }
    _st.metrics.surfaceMaxRelErr = _mx;
    tpr_st_assert(_st, _mx < 0.000000001 && array_length(_SO.rows) == 384 && array_length(_SO.fbm) == 24, "8 board materials x 48 pixels and 24 fbm samples against the MZ TaproomDraw (max rel error " + string_format(_mx, 1, 14) + ") " + ((_mx < 0.000000001) ? "" : _mf));
    var _patch = 48, _worst = 0;
    for (var _m5 = 0; _m5 < array_length(_sids); _m5++) {
        var _t5 = get_timer();
        for (var _py = 0; _py < _patch; _py++) for (var _px = 0; _px < _patch; _px++) tpr_surface_at(_sids[_m5], _px, _py, 7);
        var _usPx = (get_timer() - _t5) / (_patch * _patch);
        _st.metrics[$ "surfaceUsPerPx_" + _sids[_m5]] = _usPx;
        _worst = max(_worst, _usPx);
    }
    // a PAIRED A/B inside one run (load on a shared machine moves both arms alike): the inlined hash against the reference
    // built from tpr__imul calls, alternating rounds; equal on every input, and the time RATIO is what is quoted
    var _abSame = 0, _abN = 0, _usRef = 0, _usNew = 0;
    for (var _ab = 0; _ab < 6; _ab++) {
        var _ta = get_timer();
        for (var _q1 = 0; _q1 < 4000; _q1++) tpr__st_hash2_ref(_q1 * 7 - 3000, _q1 * 13, _ab * 31);
        _usRef += get_timer() - _ta;
        var _tb = get_timer();
        for (var _q2 = 0; _q2 < 4000; _q2++) tpr__hash2(_q2 * 7 - 3000, _q2 * 13, _ab * 31);
        _usNew += get_timer() - _tb;
    }
    for (var _q3 = 0; _q3 < 2000; _q3++) { _abN++; if (tpr__hash2(_q3 * 11 - 7000, _q3 * 5 - 900, _q3) == tpr__st_hash2_ref(_q3 * 11 - 7000, _q3 * 5 - 900, _q3)) _abSame++; }
    _st.metrics.hashInlineSpeedup = (_usNew > 0) ? _usRef / _usNew : 0;
    tpr_st_assert(_st, _abSame == _abN && _abN == 2000, "the inlined hash equals the reference on " + string(_abSame) + " of " + string(_abN) + " inputs (negative and positive); paired A/B speed-up x" + string_format(_st.metrics.hashInlineSpeedup, 1, 2));
    // a 560 x 560 board (the MZ size) at the worst material's rate, in ms - the cost of painting one board per pixel
    _st.metrics.boardMsAtWorst = _worst * 560 * 560 / 1000;
    array_push(_st.notes, "per-pixel material cost on this runtime: worst " + string_format(_worst, 1, 1) + " us/px = " + string_format(_st.metrics.boardMsAtWorst, 1, 0) + " ms for one 560 x 560 board");
    // ---- 6: the surface hash the shader computes - spread over [0, 1), its period, and its seeds and deltas apart ----
    tpr_st_stage(_st, 6);
    var _hist = array_create(16, 0), _n6 = 0;
    for (var _y6 = 0; _y6 < 256; _y6++) for (var _x6 = 0; _x6 < 256; _x6++) { var _hv = tpr__lhash(_x6, _y6, 2654435761, 0); _hist[floor(_hv * 16)] += 1; _n6++; }
    var _hmin = 1000000000, _hmax = 0;
    for (var _h6 = 0; _h6 < 16; _h6++) { _hmin = min(_hmin, _hist[_h6]); _hmax = max(_hmax, _hist[_h6]); }
    _st.metrics.hashHistMin = _hmin; _st.metrics.hashHistMax = _hmax;
    // 65,536 cells put 4,096 in each sixteenth when uniform; a stuck or biased hash falls outside these bounds
    var _per = 0, _shift = 0, _seedDiff = 0, _kDiff = 0;
    for (var _q6 = 0; _q6 < 200; _q6++) {
        if (tpr__lhash(_q6 * 7, _q6 * 3, 99, 5) == tpr__lhash(_q6 * 7 + 289 * 283, _q6 * 3, 99, 5)) _per++;
        if (tpr__lhash(_q6 * 7, _q6 * 3, 99, 5) != tpr__lhash(_q6 * 7 + 289, _q6 * 3, 99, 5)) _shift++;
        if (tpr__lhash(_q6, _q6 * 5, 12345, 0) != tpr__lhash(_q6, _q6 * 5, 12346, 0)) _seedDiff++;
        if (tpr__lhash(_q6, _q6 * 5, 12345, 0) != tpr__lhash(_q6, _q6 * 5, 12345, 17)) _kDiff++;
    }
    tpr_st_assert(_st, _n6 == 65536 && _hmin > 3700 && _hmax < 4500 && _per == 200 && _shift > 180 && _seedDiff > 180 && _kDiff > 180, "the surface hash: 65,536 cells, each sixteenth " + string(_hmin) + ".." + string(_hmax) + "; period 289 x 283 exact (" + string(_per) + "/200), not 289 alone (" + string(_shift) + "/200 differ); another seed " + string(_seedDiff) + "/200 and another delta " + string(_kDiff) + "/200 differ");
    // ---- 7: the GPU paints what the CPU twin computes - every material and the table, pixel by pixel ----
    tpr_st_stage(_st, 7);
    tpr_st_assert(_st, tpr_shader_ok(), "shd_tpr_surface compiled on this platform");
    var _S7 = 2654435761, _S7b = 1234567, _pw = 96, _ph = 72, _ox = 21, _oy = 21;
    var _mats = tpr_board_ids(), _worst7 = 0, _over7 = 0, _cmp7 = 0, _wf7 = "";
    var _ps = surface_create(_pw, _ph), _pb = buffer_create(_pw * _ph * 4, buffer_fixed, 1);
    for (var _m7 = 0; _m7 < 9; _m7++) {
        surface_set_target(_ps); draw_clear_alpha(c_black, 0);
        if (_m7 < 8) tpr_paint_surface(_mats[_m7], _ox, _oy, _pw, _ph, _S7, undefined, [1, 0, 0, 1, -_ox, -_oy]);
        else tpr_paint_table(_pw, _ph, _S7);
        surface_reset_target();
        buffer_get_surface(_pb, _ps, 0);
        for (var _yy = 0; _yy < _ph; _yy += 3) for (var _xx = (_yy mod 2); _xx < _pw; _xx += 2) {
            var _v7, _cx7, _cy7;
            if (_m7 < 8) {
                _cx7 = _ox + _xx; _cy7 = _oy + _yy;
                var _sv = tpr_surface_lt(_mats[_m7], _cx7, _cy7, _S7), _lp = 1.08 - 0.26 * ((_xx / _pw) * 0.55 + (_yy / _ph) * 0.45);
                _v7 = [_sv[0] * _lp, _sv[1] * _lp, _sv[2] * _lp];
            } else { _cx7 = _xx; _cy7 = _yy; _v7 = tpr_table_lt(_xx, _yy, _pw, _ph, _S7); }
            var _o7 = (_yy * _pw + _xx) * 4;
            for (var _c7 = 0; _c7 < 3; _c7++) {
                var _want = clamp(round(_v7[_c7]), 0, 255), _got7 = buffer_peek(_pb, _o7 + _c7, buffer_u8), _d7 = abs(_got7 - _want);
                if (_d7 > _worst7) { _worst7 = _d7; _wf7 = ((_m7 < 8) ? _mats[_m7] : "table") + " at " + string(_cx7) + "," + string(_cy7) + " ch " + string(_c7) + " gpu " + string(_got7) + " cpu " + string(_want); }
                if (_d7 > 2) _over7++;
            }
            if (buffer_peek(_pb, _o7 + 3, buffer_u8) != 255) _over7++;
            _cmp7++;
        }
    }
    _st.metrics.gpuVsCpuWorst = _worst7; _st.metrics.gpuVsCpuCompared = _cmp7;
    tpr_st_assert(_st, _over7 == 0 && _cmp7 >= 9 * 1100, "8 materials and the table painted by the shader against the CPU twin: " + string(_cmp7) + " pixels x 3 channels, worst " + string(_worst7) + " level(s), " + string(_over7) + " over 2 (and every one opaque) " + _wf7);
    // the control: the same comparison against the twin at ANOTHER seed must fail broadly, or the comparison above could not
    surface_set_target(_ps); draw_clear_alpha(c_black, 0);
    tpr_paint_surface("walnut", _ox, _oy, _pw, _ph, _S7b, undefined, [1, 0, 0, 1, -_ox, -_oy]);
    surface_reset_target();
    buffer_get_surface(_pb, _ps, 0);
    var _cn = 0, _cd = 0;
    for (var _y8 = 0; _y8 < _ph; _y8 += 3) for (var _x8 = 0; _x8 < _pw; _x8 += 3) {
        var _s8 = tpr_surface_lt("walnut", _ox + _x8, _oy + _y8, _S7), _l8 = 1.08 - 0.26 * ((_x8 / _pw) * 0.55 + (_y8 / _ph) * 0.45);
        _cn++; if (abs(buffer_peek(_pb, (_y8 * _pw + _x8) * 4, buffer_u8) - clamp(round(_s8[0] * _l8), 0, 255)) > 2) _cd++;
    }
    tpr_st_assert(_st, _cd > _cn * 0.3, "control: walnut painted at another seed differs from the twin on " + string(_cd) + " of " + string(_cn) + " pixels (the comparison can fail)");
    // the rounded clip: transparent outside the corner, opaque in the middle, a partial edge in between
    surface_set_target(_ps); draw_clear_alpha(c_black, 0);
    tpr_paint_surface("slate", 0, 0, _pw, _ph, _S7, [10, 10, 60, 40, 8]);
    surface_reset_target();
    buffer_get_surface(_pb, _ps, 0);
    var _aOut = buffer_peek(_pb, (11 * _pw + 11) * 4 + 3, buffer_u8), _aIn = buffer_peek(_pb, (30 * _pw + 40) * 4 + 3, buffer_u8), _aFar = buffer_peek(_pb, (60 * _pw + 80) * 4 + 3, buffer_u8);
    tpr_st_assert(_st, _aOut < 40 && _aIn == 255 && _aFar == 0, "rounded clip: alpha " + string(_aOut) + " in the cut corner, " + string(_aIn) + " inside, " + string(_aFar) + " outside the box");
    surface_free(_ps); buffer_delete(_pb);
    // the cost of a whole 560 x 560 board on the GPU, a readback forcing the work to finish inside the timing
    var _bs = surface_create(560, 560), _bb = buffer_create(4, buffer_fixed, 1), _tb7 = 0;
    for (var _r7 = 0; _r7 < 3; _r7++) {
        var _tt = get_timer();
        surface_set_target(_bs); draw_clear_alpha(c_black, 0);
        tpr_paint_surface(_mats[_r7 * 3 mod 8], 0, 0, 560, 560, _S7 + _r7);
        surface_reset_target();
        var _bf = buffer_create(560 * 560 * 4, buffer_fixed, 1); buffer_get_surface(_bf, _bs, 0); buffer_delete(_bf);
        _tb7 = max(_tb7, (get_timer() - _tt) / 1000);
    }
    surface_free(_bs); buffer_delete(_bb);
    _st.metrics.gpuBoardMsWorst = _tb7;
    array_push(_st.notes, "a 560 x 560 board on the GPU: worst of 3 = " + string_format(_tb7, 1, 1) + " ms (with a full readback)");
    tpr_st_assert(_st, _tb7 < 250, "a 560 x 560 board paints on the GPU in " + string_format(_tb7, 1, 1) + " ms (worst of 3, readback included; per pixel on the VM it was " + string_format(_st.metrics.boardMsAtWorst, 1, 0) + " ms)");
    // renders for LOOKING: every material at 280 x 280 and the table at 480 x 320
    var _rs = surface_create(280, 280), _saved = 0;
    for (var _m8 = 0; _m8 < 8; _m8++) {
        surface_set_target(_rs); draw_clear(c_black);
        tpr_paint_surface(_mats[_m8], 21, 21, 280, 280, 3003, [21, 21, 280, 280, 6], [1, 0, 0, 1, -21, -21]);
        surface_reset_target();
        surface_save(_rs, "tpr_render_mat_" + _mats[_m8] + ".png"); if (file_exists("tpr_render_mat_" + _mats[_m8] + ".png")) _saved++;
    }
    surface_free(_rs);
    var _ts = surface_create(480, 320);
    surface_set_target(_ts); draw_clear(c_black); tpr_paint_table(480, 320, 3003 ^ 502558); surface_reset_target();
    surface_save(_ts, "tpr_render_table.png"); if (file_exists("tpr_render_table.png")) _saved++;
    surface_free(_ts);
    tpr_st_assert(_st, _saved == 9, string(_saved) + " of 9 surface renders saved for looking");
    // ---- 8: the drawing, held to the MZ TaproomDraw drawn over a recording canvas - every event of 179 drawings ----
    tpr_st_stage(_st, 8);
    var _OD = tpr_oracle_draw(), _gids = ["morris", "foxgeese", "oware", "fanorona"], _bids = tpr_board_ids(), _sids = tpr_set_ids();
    var _ds = surface_create(1024, 704), _dbad = 0, _df = "", _devents = 0, _kindMs = array_create(10, 0), _firstBad = -1;
    for (var _ci = 0; _ci < array_length(_OD.cases); _ci++) {
        var _row8 = _OD.cases[_ci], _k8 = _row8[0], _cx8 = tpr_cx_create(1), _got8 = "", _t8 = get_timer();
        surface_set_target(_ds); draw_clear_alpha(c_black, 0);
        tpr_log_begin(_cx8, (_firstBad < 0) ? 0 : 0);
        _got8 = tpr__st_draw_case(_cx8, _row8, _OD, _gids, _bids, _sids);
        var _lg8 = tpr_log_end(_cx8);
        surface_reset_target();
        _kindMs[_k8] += (get_timer() - _t8) / 1000;
        _devents += _lg8.events;
        if (_lg8.events != _row8[7] || _lg8.len != _row8[8] || _lg8.hash != _row8[9] || _got8 != "") {
            _dbad++;
            if (_firstBad < 0) {
                _firstBad = _ci;
                // the first failure's whole log, for diffing offline against Internal_Ops/oracle_draw_logs.json
                surface_set_target(_ds); var _cx9 = tpr_cx_create(1); tpr_log_begin(_cx9, 400000); tpr__st_draw_case(_cx9, _row8, _OD, _gids, _bids, _sids); var _lg9 = tpr_log_end(_cx9); surface_reset_target();
                var _fh = file_text_open_write("tpr_draw_firstfail.txt"); file_text_write_string(_fh, string(_ci) + "\n" + _lg9.text); file_text_close(_fh);
                _df = "case " + string(_ci) + " kind " + string(_k8) + " events " + string(_lg8.events) + "/" + string(_row8[7]) + " len " + string(_lg8.len) + "/" + string(_row8[8]) + " " + _got8;
            }
        }
    }
    surface_free(_ds);
    for (var _km = 0; _km < 10; _km++) _st.metrics[$ "drawMs_kind" + string(_km)] = _kindMs[_km];
    _st.metrics.drawEvents = _devents;
    tpr_st_assert(_st, _dbad == 0 && array_length(_OD.cases) == 179 && _devents > 10000, string(array_length(_OD.cases)) + " drawings against the MZ TaproomDraw, " + string(_devents) + " paint events: " + string(_dbad) + " differ " + _df);
    // the layouts and the styles, as numbers
    var _lb2 = 0, _lf2 = "";
    for (var _li = 0; _li < 4; _li++) {
        var _OL = _OD.layouts[_li], _GL = tpr_layout(_gids[_li], 816, 624);
        var _same = _GL.board.x == _OL.board[0] && _GL.board.y == _OL.board[1] && _GL.board.w == _OL.board[2] && _GL.board.h == _OL.board[3]
            && _GL.panel.x == _OL.panel[0] && _GL.panel.y == _OL.panel[1] && _GL.panel.w == _OL.panel[2] && _GL.panel.h == _OL.panel[3]
            && _GL.r == _OL.r && _GL.cell == _OL.cell && (is_undefined(_GL[$ "pitR"]) ? 0 : _GL.pitR) == _OL.pitR && _GL.side == _OL.side && array_length(_GL.pts) == array_length(_OL.pts);
        if (_same) for (var _pi = 0; _pi < array_length(_OL.pts); _pi++) if (_GL.pts[_pi].x != _OL.pts[_pi][0] || _GL.pts[_pi].y != _OL.pts[_pi][1]) _same = false;
        if (_same && array_length(_OL.stores) > 0) for (var _si2 = 0; _si2 < 2; _si2++) { var _gs = _GL.stores[_si2], _os = _OL.stores[_si2]; if (_gs.x != _os[0] || _gs.y != _os[1] || _gs.w != _os[2] || _gs.h != _os[3]) _same = false; }
        if (!_same) { _lb2++; if (_lf2 == "") _lf2 = _gids[_li]; }
    }
    var _sb2 = 0, _sf2 = "";
    for (var _yi = 0; _yi < array_length(_OD.styles); _yi++) {
        var _y2 = _OD.styles[_yi], _sty = tpr_style_for(_OD.names[_y2[0]], _gids[_y2[1]], (_y2[0] == 5) ? "linen" : "", (_y2[0] == 6) ? "glass" : "");
        if (tpr__index_of(_bids, _sty.board) != _y2[2] || tpr__index_of(_sids, _sty.set) != _y2[3] || _sty.seed != _y2[4] || floor(_sty.wear * 100 + 0.5) != _y2[5]) { _sb2++; if (_sf2 == "") _sf2 = "name " + string(_y2[0]) + " game " + string(_y2[1]) + " got " + _sty.board + "/" + _sty.set + "/" + string(_sty.seed); }
    }
    tpr_st_assert(_st, _lb2 == 0 && _sb2 == 0 && array_length(_OD.styles) == 24, "4 layouts (every point, pit and store) and 24 styleFor picks against the MZ: " + string(_lb2) + " + " + string(_sb2) + " differ " + _lf2 + _sf2);
    math_set_epsilon(_eps0);
    // ---- 9: whole games through THE TABLE (tpr_table_*), both sides played by the search, every game, start to verdict;
    //         drawn as it plays (every 20th frame) and photographed at the start, the middle and the verdict ----
    tpr_st_stage(_st, 9);
    var _g9 = ["morris", "foxgeese", "oware", "fanorona"], _ok9 = 0, _f9 = "", _ts9 = surface_create(816, 624), _shots9 = 0, _worst9 = 0, _frames9 = 0, _plies9 = 0;
    for (var _gi9 = 0; _gi9 < 4; _gi9++) {
        var _to9 = get_timer();
        var _T9 = tpr_table_open({ game: _g9[_gi9], opponent: "Old Brannoc", grade: 1, watch: true, watch_grade: 2, auto_close: true, seed: 77 + _gi9, key: "st9|" + string(_gi9), stake: 20 });
        _st.metrics[$ "openMs_" + _g9[_gi9]] = (get_timer() - _to9) / 1000;
        _T9.thinkMs = 3; _T9.minThink = 2;
        var _fr9 = 0, _midShot = false, _endShot = false;
        while (!tpr_table_closed(_T9) && _fr9 < 40000) {
            var _t9 = get_timer();
            tpr_table_step(_T9, -1000, -1000);
            _worst9 = max(_worst9, (get_timer() - _t9) / 1000);
            _fr9++;
            var _shoot = (_fr9 == 3) || (!_midShot && _T9.m.state.ply >= 12 && _T9.mode == "think") || (!_endShot && _T9.mode == "done");
            if (_shoot || (_fr9 mod 20) == 0) {
                surface_set_target(_ts9); draw_clear(c_black); tpr_table_draw(_T9, 0, 0, 1); surface_reset_target();
                if (_shoot) {
                    var _nm9 = (_fr9 == 3) ? "open" : ((_T9.mode == "done") ? "verdict" : "mid");
                    surface_save(_ts9, "tpr_render_table_" + _g9[_gi9] + "_" + _nm9 + ".png"); _shots9++;
                    if (_nm9 == "mid") _midShot = true;
                    if (_nm9 == "verdict") _endShot = true;
                }
            }
        }
        _frames9 += _fr9;
        var _r9 = _T9.result;
        if (tpr_table_closed(_T9) && is_struct(_r9) && (_r9.result == 0 || _r9.result == 1 || _r9.result == 2) && _r9.plies > 0 && _r9.game == _g9[_gi9]) { _ok9++; _plies9 += _r9.plies; _st.metrics[$ "watch_" + _g9[_gi9]] = string(_r9.result) + " by " + string(_r9.margin) + " (" + _r9.reason + ") in " + string(_r9.plies) + " plies, " + string(_fr9) + " frames"; }
        else if (_f9 == "") _f9 = _g9[_gi9] + " closed " + string(tpr_table_closed(_T9)) + " after " + string(_fr9) + " frames, mode " + _T9.mode + ", ply " + string(_T9.m.state.ply);
        tpr_table_free(_T9);
    }
    surface_free(_ts9);
    _st.metrics.tableWorstStepMs = _worst9; _st.metrics.tableFrames = _frames9;
    var _recW = tpr_record("Old Brannoc", "morris");
    tpr_st_assert(_st, _ok9 == 4 && _shots9 >= 10 && _plies9 > 40 && (_recW.w + _recW.l + _recW.d) >= 1, "4 whole games through the table (watch mode), each to a verdict and closed: " + string(_ok9) + " of 4, " + string(_plies9) + " plies, " + string(_frames9) + " frames, " + string(_shots9) + " screens saved; worst step " + string_format(_worst9, 1, 1) + " ms " + _f9);
    // ---- 10: a PLAYER's game, driven by clicks injected at the rings the table offers (the hit test, the prompts, the
    //          mills, the trays), plus the rules card by Shift, a refused click, and a concession by two clicks ----
    tpr_st_stage(_st, 10);
    var _T10 = tpr_table_open({ game: "morris", opponent: "Hob", grade: 1, side: "first", seed: 5, key: "st10" });
    _T10.thinkMs = 3; _T10.minThink = 2;
    var _fr10 = 0, _clicks = 0, _refused = 0, _rulesSeen = false, _shot10 = false, _ts10 = surface_create(816, 624);
    while (!tpr_table_closed(_T10) && _fr10 < 40000) {
        if (_T10.mode == "human" && array_length(_T10.targets) > 0) {
            if (_clicks == 3 && !_rulesSeen) { _T10.inject = { shift: true }; tpr_table_step(_T10); _rulesSeen = _T10.rules; _T10.inject = { ok: true }; }
            else if (_clicks == 5 && _refused == 0) { _T10.inject = { x: 5, y: 5, click: true }; _refused = (_T10.mode == "human") ? 1 : 0; }
            else { var _tg = _T10.targets[0]; _T10.inject = { x: _tg.x, y: _tg.y, click: true }; _clicks++; }
        } else if (_T10.mode == "done") _T10.inject = { ok: true };
        if (!_shot10 && _T10.mode == "human" && _clicks >= 7) { surface_set_target(_ts10); draw_clear(c_black); tpr_table_draw(_T10, 0, 0, 1); surface_reset_target(); surface_save(_ts10, "tpr_render_table_player.png"); _shot10 = true; }
        tpr_table_step(_T10, -1000, -1000);
        _fr10++;
    }
    var _r10 = _T10.result;
    tpr_table_free(_T10);
    var _T11 = tpr_table_open({ game: "fanorona", opponent: "Pell", grade: 1, seed: 9, key: "st11" });
    var _fr11 = 0; while (_T11.mode != "human" && _fr11 < 200) { tpr_table_step(_T11, -1000, -1000); _fr11++; }
    var _p2 = _T11.pr[2];
    _T11.inject = { x: _p2.x + 5, y: _p2.y + 5, click: true }; tpr_table_step(_T11, -1000, -1000);
    var _armed = _T11.concede;
    _T11.inject = { x: _p2.x + 5, y: _p2.y + 5, click: true }; tpr_table_step(_T11, -1000, -1000);
    var _r11 = _T11.result;
    tpr_table_free(_T11); surface_free(_ts10);
    tpr_st_assert(_st, tpr_table_closed(_T10) && is_struct(_r10) && _r10.plies > 10 && _clicks >= 10 && _rulesSeen && _refused == 1 && _armed == 1 && is_struct(_r11) && _r11.result == 0 && _r11.reason == "you conceded",
        "a player's Morris by " + string(_clicks) + " injected clicks to a verdict (" + (is_struct(_r10) ? string(_r10.result) + ", " + _r10.reason + ", " + string(_r10.plies) + " plies" : "no result") + "); rules by Shift " + string(_rulesSeen) + "; a click on nothing refused " + string(_refused) + "; concede armed " + string(_armed) + " then " + (is_struct(_r11) ? _r11.reason : "no result"));
    // ---- 11: THE TAPROOM demo - the room is built, a regular chosen shows the "setting the board" frame first, and the
    //          table opens on a LATER step (never on the frame of the click), with that regular's game ----
    tpr_st_stage(_st, 11);
    var _D11 = tpr_demo_create(960, 640), _ds11 = surface_create(960, 640);
    tpr_demo_step(_D11);
    var _built = (!_D11.dirty && sprite_exists(_D11.bg) && array_length(_D11.cards) == 6);
    _D11.pending = 2; _D11.pendingFrames = 0;
    tpr_demo_step(_D11);
    var _noTableYet = !is_struct(_D11.table);
    surface_set_target(_ds11); draw_clear(c_black); tpr_demo_draw(_D11); surface_reset_target();
    surface_save(_ds11, "tpr_render_demo_setting.png");
    var _t11 = get_timer();
    tpr_demo_step(_D11);
    var _openMs11 = (get_timer() - _t11) / 1000;
    var _opened = is_struct(_D11.table) && _D11.table.g == "oware" && _D11.table.req.opponent == "Captain Dray" && _D11.pending == -1;
    surface_set_target(_ds11); draw_clear(c_black); tpr_demo_draw(_D11); surface_reset_target();
    surface_save(_ds11, "tpr_render_demo_table.png");
    tpr_demo_free(_D11); surface_free(_ds11);
    _st.metrics.demoOpenMs = _openMs11;
    tpr_st_assert(_st, _built && _noTableYet && _opened, "the demo room builds its 6 cards; a chosen regular shows the setting frame first (no table yet: " + string(_noTableYet) + ") and the table opens on the next step with Captain Dray's oware (" + string(_opened) + ", " + string_format(_openMs11, 1, 0) + " ms)");
    tpr_st_stage(_st, 99);
    return _st;
}

/// @function tpr_selftest_write(state)
function tpr_selftest_write(_st) {
    var _f = file_text_open_write("tpr_selftest.json");
    file_text_write_string(_f, json_stringify(_st));
    file_text_close(_f);
}
