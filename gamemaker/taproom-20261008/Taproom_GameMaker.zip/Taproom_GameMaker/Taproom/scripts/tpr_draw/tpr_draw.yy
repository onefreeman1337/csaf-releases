{
  "$GMScript": "v1",
  "%Name": "tpr_draw",
  "name": "tpr_draw",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}