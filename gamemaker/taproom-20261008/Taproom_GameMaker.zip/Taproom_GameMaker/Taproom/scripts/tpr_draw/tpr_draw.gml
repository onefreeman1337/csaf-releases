/// tpr_draw.gml - Taproom's drawing: the tavern table, the board for each game in each material (its slab, border worked at a
/// steady pitch, lines or pits, and the wear of use), the men of six sets and the fox, oware seeds, the counts cut beside the
/// pits, the brass plaques, the parchment card, the status strip, the rings and crosses of the cursor and the verdict slip.
/// Nothing here is an image file: every picture is drawn when it is asked for.
///
/// Taproom - Tavern Board Games Against an Opponent Who Thinks, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// This is the RPG Maker MZ edition's TaproomDraw.js, ported op for op onto the tpr_canvas kit and HELD to it: the self-test
/// runs the MZ drawing in Node over a recording canvas and compares every fill, stroke, rectangle, clip, line of text, blur,
/// shadow and painted surface - colour, alpha, line width, caps, dash, the path it paints and the transform it paints under -
/// against what this file asks the kit to do (tpr_oracle_draw). Text is measured from the faces' own advance table
/// (tpr_text_width), the table the oracle measures with, so every fitted size is the original's.
/// The per-pixel surfaces (each board's material, the table's oak, the card's linen) are painted by shd_tpr_surface
/// (tpr_surface.gml) where the MZ fills an ImageData.
///
/// ⛔ GameMaker evaluates a function call's ARGUMENTS RIGHT TO LEFT (and an array literal's elements too). Wherever the MZ
/// code draws several numbers from a generator inside one expression, this file draws them into variables first, in the
/// original's order.
///
/// Public functions (each documented below): tpr_layout, tpr_style_for, tpr_set_ids, tpr_set_info, tpr_draw_table,
/// tpr_draw_board, tpr_draw_man, tpr_draw_seeds, tpr_draw_count, tpr_draw_plaque, tpr_draw_placard, tpr_draw_status,
/// tpr_draw_marker, tpr_draw_verdict.

#macro TPR_TAU (pi * 2)

// ---------------------------------------------------------------------------------------------------------------
// Colour, ink and the logged verbs this file adds to tpr_paint's (shadow, dash, text, surfaces)
// ---------------------------------------------------------------------------------------------------------------

/// JS (v | 0) for the channel values this file passes (well inside 32 bits)
function tpr__trunc(_v) { return (_v < 0) ? ceil(_v) : floor(_v); }
/// the MZ rgb(c, a): a solid paint, channels truncated as `c[i] | 0` does
function tpr__rgb(_c, _a = 1) { return tpr_cx_solid([tpr__trunc(_c[0]), tpr__trunc(_c[1]), tpr__trunc(_c[2])], _a); }
/// a gradient stop in the MZ's rgb(c, a)
function tpr__stop(_g, _t, _c, _a = 1) { tpr_cx_stop(_g, _t, [tpr__trunc(_c[0]), tpr__trunc(_c[1]), tpr__trunc(_c[2])], _a); }
/// the WCAG relative luminance of an [r, g, b]
function tpr__lum(_c) {
    var _o = 0, _k = [0.2126, 0.7152, 0.0722];
    for (var _i = 0; _i < 3; _i++) { var _v = _c[_i] / 255; _o += _k[_i] * ((_v <= 0.03928) ? _v / 12.92 : power((_v + 0.055) / 1.055, 2.4)); }
    return _o;
}
function tpr__contrast(_a, _b) { var _la = tpr__lum(_a), _lb = tpr__lum(_b); return (max(_la, _lb) + 0.05) / (min(_la, _lb) + 0.05); }
/// the first candidate ink that clears `want` against `bg`, else the one that contrasts most
function tpr__pick_ink(_bg, _cands, _want) {
    var _best = _cands[0], _bc = 0;
    for (var _i = 0; _i < array_length(_cands); _i++) { var _c = tpr__contrast(_bg, _cands[_i]); if (_c >= _want) return _cands[_i]; if (_c > _bc) { _bc = _c; _best = _cands[_i]; } }
    return _best;
}
/// integer to its decimal string (a hash or a size in the log)
function tpr__istr(_v) { return string(int64(_v)); }

/// the canvas shadow (shadowColor/Blur/OffsetX/Y), part of the saved state: undefined clears it
function tpr__shadow_set(_c, _rgb, _a, _blur, _dx, _dy) { _c.sh = { col: _rgb, a: _a, blur: _blur, dx: _dx, dy: _dy }; }
/// emit and draw the shadow of what is about to be painted (the current path, or a rectangle when rect is given)
function tpr__q_shadow(_c, _rect = undefined) {
    var _s = _c[$ "sh"];
    if (!is_struct(_s) || !(_s.a > 0) || !(_s.blur > 0 || _s.dx != 0 || _s.dy != 0)) return;
    if (tpr__logging(_c)) tpr__lg_emit(_c, "H" + tpr__lg_paint(tpr_cx_solid(_s.col, _s.a)) + ":" + string(tpr__r100(_s.blur)) + ":" + string(tpr__r100(_s.dx)) + "," + string(tpr__r100(_s.dy)) + ";");
    if (is_array(_rect)) {
        var _subs = _c.subs, _cur = _c.cur;
        tpr_cx_begin(_c); tpr_cx_rect(_c, _rect[0], _rect[1], _rect[2], _rect[3]);
        tpr_cx_shadow(_c, _s.col, _s.a, _s.blur, _s.dx, _s.dy);
        _c.subs = _subs; _c.cur = _cur;
    } else tpr_cx_shadow(_c, _s.col, _s.a, _s.blur, _s.dx, _s.dy);
}
function tpr__q_fill(_c) { tpr__q_shadow(_c); tpr__p_fill(_c); }
function tpr__q_stroke(_c) {
    tpr__q_shadow(_c);
    if (tpr__logging(_c) && array_length(_c.dash) > 0) { var _d = ""; for (var _i = 0; _i < array_length(_c.dash); _i++) _d += ((_i > 0) ? "," : "") + string(_c.dash[_i]); tpr__lg_emit(_c, "L" + _d + ";"); }
    tpr__p_stroke(_c);
}
function tpr__q_fill_rect(_c, _x, _y, _w, _h) { tpr__q_shadow(_c, [_x, _y, _w, _h]); tpr__p_fill_rect(_c, _x, _y, _w, _h); }
function tpr__q_stroke_rect(_c, _x, _y, _w, _h) {
    tpr__q_shadow(_c, [_x, _y, _w, _h]);
    if (tpr__logging(_c)) tpr__lg_emit(_c, "K" + tpr__lg_paint(_c.stroke) + ":" + string(tpr__r100(_c.lw)) + ":" + string(tpr__r100(_x + _y + _w + _h)) + ":" + tpr__lg_t(_c) + tpr__lg_a(_c) + ";");
    tpr_cx_stroke_rect(_c, _x, _y, _w, _h);
}
/// the canvas rect(x, y, w, h) path verb (the sum is added term by term, as the recorder adds it)
function tpr__q_rect(_c, _x, _y, _w, _h) {
    if (tpr__logging(_c)) { _c.tpr_lg.n += 1; _c.tpr_lg.s += _x; _c.tpr_lg.s += _y; _c.tpr_lg.s += _w; _c.tpr_lg.s += _h; }
    tpr_cx_rect(_c, _x, _y, _w, _h);
}
/// a clip that is LOGGED but left to the shader (the surface paints carry their own clip)
function tpr__q_clip_logged(_c) {
    if (tpr__logging(_c)) tpr__lg_emit(_c, "C:" + string(_c.tpr_lg.n) + ":" + string(tpr__r100(_c.tpr_lg.s)) + ":" + tpr__lg_t(_c) + ";");
}
/// the per-pixel surface the MZ pastes with drawImage: logged, then painted by the shader under the context's transform
function tpr__q_surface(_c, _mode, _x, _y, _w, _h, _seed, _clip, _tw = 0, _th = 0) {
    if (tpr__logging(_c)) tpr__lg_emit(_c, "I" + string(tpr__r100(_x)) + "," + string(tpr__r100(_y)) + "," + tpr__istr(max(1, ceil(_w))) + "," + tpr__istr(max(1, ceil(_h))) + ":" + tpr__lg_t(_c) + tpr__lg_a(_c) + ";");
    if (_mode == "table") return tpr_paint_table(_w, _h, _seed, _c.m);
    return tpr_paint_surface(_mode, _x, _y, _w, _h, _seed, _clip, _c.m);
}

/// the canvas font: px and face (TPR_FACE_DISPLAY for the MZ's bold lines, TPR_FACE_BODY for the rest)
function tpr__font(_c, _px, _face) { _c.tf = { px: _px, face: _face }; }
/// align 0 = left/start, 1 = centre; base 0 = alphabetic, 1 = middle
function tpr__text_align(_c, _align, _base) { _c.ta = _align; _c.tb = _base; }
function tpr__measure(_c, _t) { var _f = _c[$ "tf"]; if (!is_struct(_f)) return 0; return tpr_text_width(_t, _f.px, _f.face); }
/// the canvas fillText of a whole line: logged as one event, struck glyph by glyph under the transform
function tpr__q_text(_c, _t, _x, _y) {
    var _f = _c[$ "tf"], _al = _c[$ "ta"], _bl = _c[$ "tb"];
    if (!is_struct(_f)) _f = { px: 10, face: TPR_FACE_BODY };
    if (is_undefined(_al)) _al = 0;
    if (is_undefined(_bl)) _bl = 0;
    var _s = string(_t);
    tpr__q_shadow(_c);
    if (tpr__logging(_c)) tpr__lg_emit(_c, "T" + tpr__lg_paint(_c.fill) + ":" + tpr__istr(tpr_hash(_s)) + ":" + string(tpr__r100(_x + _y)) + ":" + string(tpr__r100(_f.px)) + ":" + string(_f.face) + ":" + ((_al == 1) ? "c" : "l") + ((_bl == 1) ? "m" : "a") + ":" + tpr__lg_t(_c) + tpr__lg_a(_c) + ";");
    var _w = tpr_text_width(_s, _f.px, _f.face), _xx = (_al == 1) ? _x - _w / 2 : _x;
    // a canvas "middle" baseline sits about a third of the em below the point (the em box's middle)
    var _yy = (_bl == 1) ? _y + _f.px * ((_f.face == TPR_FACE_BODY) ? 0.32 : 0.34) : _y;
    var _adv = tpr_text_advance(_f.face);
    for (var _i = 1; _i <= string_length(_s); _i++) {
        var _ch = string_char_at(_s, _i), _o = ord(_ch);
        tpr_cx_glyph(_c, _ch, _xx, _yy, _f.px, _f.face);
        if (_o >= 32 && _o <= 126) _xx += _adv[_o - 32] * _f.px;
    }
}

/// the MZ rrect(ctx, x, y, w, h, r): a rounded rectangle path with quadratic corners
function tpr__rrect(_c, _x, _y, _w, _h, _r) {
    tpr__p_begin(_c);
    tpr__p_move(_c, _x + _r, _y); tpr__p_line(_c, _x + _w - _r, _y); tpr__p_quad(_c, _x + _w, _y, _x + _w, _y + _r);
    tpr__p_line(_c, _x + _w, _y + _h - _r); tpr__p_quad(_c, _x + _w, _y + _h, _x + _w - _r, _y + _h);
    tpr__p_line(_c, _x + _r, _y + _h); tpr__p_quad(_c, _x, _y + _h, _x, _y + _h - _r);
    tpr__p_line(_c, _x, _y + _r); tpr__p_quad(_c, _x, _y, _x + _r, _y);
    tpr__p_close(_c);
}
/// the MZ seg(ctx, a, b, c, d): one straight line, stroked
function tpr__seg(_c, _a, _b, _cc, _d) { tpr__p_begin(_c); tpr__p_move(_c, _a, _b); tpr__p_line(_c, _cc, _d); tpr__q_stroke(_c); }

// ---------------------------------------------------------------------------------------------------------------
// The men's sets
// ---------------------------------------------------------------------------------------------------------------

/// @function tpr_set_ids()
/// @description The six sets of men, in the MZ edition's order.
/// @returns {Array<String>}
function tpr_set_ids() { return ["stones", "bone", "glass", "coins", "clay", "boxwood"]; }

/// @function tpr_set_info(id)
/// @description A set's record: { name, light, dark, kind, seed } (colours [r, g, b]; kind stone|turned|glass|coin|clay; seed
/// the shape of its oware seeds: pebble|cowrie|bead|coin|clay|bean), or undefined.
/// @returns {Struct|Undefined}
function tpr_set_info(_id) {
    static _S = {
        stones: { name: "River stones", light: [214, 206, 188], dark: [58, 60, 66], kind: "stone", seed: "pebble" },
        bone: { name: "Bone and horn", light: [232, 220, 188], dark: [92, 56, 34], kind: "turned", seed: "cowrie" },
        glass: { name: "Glass", light: [214, 232, 236], dark: [34, 62, 150], kind: "glass", seed: "bead" },
        coins: { name: "Silver and copper", light: [196, 200, 204], dark: [172, 98, 58], kind: "coin", seed: "coin" },
        clay: { name: "Fired clay", light: [196, 104, 62], dark: [36, 30, 30], kind: "clay", seed: "clay" },
        boxwood: { name: "Boxwood and ebony", light: [222, 184, 112], dark: [40, 28, 24], kind: "turned", seed: "bean" }
    };
    return is_string(_id) ? _S[$ _id] : undefined;
}

/// @function tpr_style_for(name, game, [board], [set])
/// @description The board and men an opponent plays with, from their name (so the same person always sets out the same
/// board) unless a board or set id is given: { board, set, seed, wear }. Oware is never played on a mat or slate.
/// @returns {Struct}
function tpr_style_for(_name, _game, _board = "", _set = "") {
    var _nm = (is_string(_name) && _name != "") ? _name : "stranger";
    var _h = int64(tpr_hash(_nm + "|" + string(_game)));
    var _bIds = (_game == "oware") ? ["walnut", "soapstone", "knifed", "lacquer", "marble", "leather"] : tpr_board_ids(), _sIds = tpr_set_ids();
    var _b = (is_string(_board) && is_struct(tpr_board_info(_board))) ? _board : _bIds[real(_h mod array_length(_bIds))];
    var _s = (is_string(_set) && is_struct(tpr_set_info(_set))) ? _set : _sIds[real((_h >> 8) mod 6)];
    return { board: _b, set: _s, seed: real(_h), wear: 0.5 + real((_h >> 16) mod 100) / 100 };
}

// ---------------------------------------------------------------------------------------------------------------
// The table, the layout and the board
// ---------------------------------------------------------------------------------------------------------------

/// @function tpr_draw_table(ctx, W, H, seed)
/// @description The tavern table over (0, 0, W, H): oak planks under a hanging lamp (the shader), then four old mug rings.
function tpr_draw_table(_c, _W, _H, _seed) {
    if (!is_struct(_c) || !is_numeric(_W) || !is_numeric(_H) || !(_W > 0) || !(_H > 0)) return;
    var _s = real(int64(is_numeric(_seed) ? floor(abs(_seed)) : 0) & int64($FFFFFFFF));
    tpr__q_surface(_c, "table", 0, 0, _W, _H, _s, undefined, _W, _H);
    var _r = tpr__rng(int64(_s) ^ int64($A11E));
    for (var _k = 0; _k < 4; _k++) {
        var _rx = _W * (0.55 + tpr__rng_next(_r) * 0.42);
        var _ry = _H * (0.08 + tpr__rng_next(_r) * 0.84);
        var _rr = 26 + tpr__rng_next(_r) * 12;
        _c.stroke = tpr__rgb([28, 14, 6], 0.18 + tpr__rng_next(_r) * 0.12); _c.lw = 2.2;
        var _a0 = tpr__rng_next(_r) * TPR_TAU;
        var _a1 = tpr__rng_next(_r) * TPR_TAU + 4.4;
        tpr__p_begin(_c); tpr__p_arc(_c, _rx, _ry, _rr, _a0, _a1); tpr__q_stroke(_c);
    }
}

/// @function tpr_layout(game, W, H)
/// @description Where the board and the panel go on a W x H screen: square boards (morris, foxgeese) at the left with the
/// panel at the right, wide ones (fanorona, oware) across the top with the panel below. Returns { game, board {x,y,w,h},
/// side, panel {x,y,w,h}, cell, pts [{x,y}], r (a man's radius), and for oware pitR, countGap and stores [{x,y,w,h}] }.
/// @returns {Struct}
function tpr_layout(_game, _W, _H) {
    // an unknown game lays out Morris; a size that is not a positive number is the design size, 816 x 624
    if (!is_string(_game) || (_game != "morris" && _game != "foxgeese" && _game != "oware" && _game != "fanorona")) _game = "morris";
    if (!is_numeric(_W) || !(_W > 0)) _W = 816;
    if (!is_numeric(_H) || !(_H > 0)) _H = 624;
    var _T = tpr__t(), _L = { game: _game, pts: [] }, _i;
    if (_game == "morris" || _game == "foxgeese") {
        var _xy = (_game == "morris") ? _T.mxy : _T.fxy;
        _L.board = { x: 14, y: 14, w: 560, h: 560 }; _L.side = "right";
        _L.panel = { x: 588, y: 14, w: _W - 602, h: _H - 28 };
        var _inner = 560 - 2 * 58, _cell = _inner / 6; _L.cell = _cell;
        for (_i = 0; _i < array_length(_xy); _i++) array_push(_L.pts, { x: _L.board.x + 58 + _xy[_i][0] * _cell, y: _L.board.y + 58 + _xy[_i][1] * _cell });
        _L.r = _cell * ((_game == "morris") ? 0.33 : 0.34);
    } else if (_game == "fanorona") {
        _L.board = { x: 14, y: 14, w: _W - 28, h: 404 }; _L.side = "below";
        var _cw = (_L.board.w - 2 * 52) / 8, _ch = (_L.board.h - 2 * 52) / 4, _c2 = min(_cw, _ch); _L.cell = _c2;
        var _ox = _L.board.x + (_L.board.w - 8 * _c2) / 2, _oy = _L.board.y + (_L.board.h - 4 * _c2) / 2;
        for (_i = 0; _i < 45; _i++) array_push(_L.pts, { x: _ox + _T.zxy[_i][0] * _c2, y: _oy + _T.zxy[_i][1] * _c2 });
        _L.r = _c2 * 0.3; _L.panel = { x: 14, y: 432, w: _W - 28, h: _H - 446 };
    } else {
        // oware: two rows of six pits and a store at each end; a count clears the border band's inner edge and its own pit
        _L.board = { x: 20, y: 30, w: _W - 40, h: 318 }; _L.side = "below";
        var _pitW = (_L.board.w - 2 * 108) / 6; _L.cell = _pitW; _L.pitR = _pitW * 0.42; _L.countGap = 13;
        var _inset = 34 + 12 + _L.countGap + _L.pitR;
        for (_i = 0; _i < 12; _i++) { var _col = (_i < 6) ? _i : 11 - _i, _row = (_i < 6) ? 1 : 0; array_push(_L.pts, { x: _L.board.x + 108 + (_col + 0.5) * _pitW, y: (_row == 1) ? _L.board.y + _L.board.h - _inset : _L.board.y + _inset }); }
        _L.stores = [{ x: _L.board.x + _L.board.w - 56, y: _L.board.y + _L.board.h / 2, w: 72, h: 232 }, { x: _L.board.x + 56, y: _L.board.y + _L.board.h / 2, w: 72, h: 232 }];
        _L.r = _L.pitR * 0.19; _L.panel = { x: 14, y: 362, w: _W - 28, h: _H - 376 };
    }
    return _L;
}

/// the MZ strokeLine: one line in the material's own treatment (a groove, a chalk scribe, an inlay, a stitch, a burn)
function tpr__stroke_line(_c, _B, _x1, _y1, _x2, _y2, _wgt) {
    var _ink = _B.ink, _w = (_wgt > 0) ? _wgt : 1;
    _c.cap = 1;
    switch (_B.line) {
        case "groove":
            _c.stroke = tpr__rgb(tpr__mix(_B.base, [255, 236, 200], 0.35), 0.55); _c.lw = 3.2 * _w; tpr__seg(_c, _x1 + 1.2, _y1 + 1.4, _x2 + 1.2, _y2 + 1.4);
            _c.stroke = tpr__rgb(_ink, 0.9); _c.lw = 3.4 * _w; tpr__seg(_c, _x1, _y1, _x2, _y2);
            _c.stroke = tpr__rgb([16, 8, 4], 0.55); _c.lw = 1.2 * _w; tpr__seg(_c, _x1 - 0.6, _y1 - 0.6, _x2 - 0.6, _y2 - 0.6);
            break;
        case "scribe":
            _c.stroke = tpr__rgb(_ink, 0.18); _c.lw = 4.2 * _w; tpr__seg(_c, _x1, _y1, _x2, _y2);
            _c.stroke = tpr__rgb(_ink, 0.78); _c.lw = 1.8 * _w; tpr__seg(_c, _x1, _y1, _x2, _y2);
            break;
        case "inlay": case "brass": case "gilt":
            _c.stroke = tpr__rgb([10, 8, 6], 0.45); _c.lw = 4.4 * _w; tpr__seg(_c, _x1 + 0.8, _y1 + 1, _x2 + 0.8, _y2 + 1);
            _c.stroke = tpr__rgb(_ink); _c.lw = 3 * _w; tpr__seg(_c, _x1, _y1, _x2, _y2);
            _c.stroke = tpr__rgb(tpr__mix(_ink, [255, 250, 230], 0.55), 0.8); _c.lw = 1 * _w; tpr__seg(_c, _x1 - 0.7, _y1 - 0.7, _x2 - 0.7, _y2 - 0.7);
            break;
        case "stitch":
            _c.stroke = tpr__rgb(_ink); _c.lw = 2.6 * _w; tpr_cx_set_dash(_c, [6, 4]); tpr__seg(_c, _x1, _y1, _x2, _y2); tpr_cx_set_dash(_c, []);
            break;
        case "burn":
            _c.stroke = tpr__rgb(_ink, 0.35); _c.lw = 6 * _w; tpr__seg(_c, _x1, _y1, _x2, _y2);
            _c.stroke = tpr__rgb(_ink, 0.9); _c.lw = 2.4 * _w; tpr__seg(_c, _x1, _y1, _x2, _y2);
            break;
    }
}

/// one run of the border: marks at a steady pitch along (x1, y1) -> (x2, y2), each in the material's motif; returns the count
function tpr__border_run(_c, _B, _x1, _y1, _x2, _y2, _nx, _ny, _band) {
    var _pitch = _band * 1.05, _ink = _B.ink, _marks = 0;
    var _dx = _x2 - _x1, _dy = _y2 - _y1, _len = sqrt(_dx * _dx + _dy * _dy), _n = max(1, floor(_len / _pitch)), _step = _len / _n, _ux = _dx / _len, _uy = _dy / _len;
    for (var _k = 0; _k < _n; _k++) {
        var _cx = _x1 + _ux * (_k + 0.5) * _step, _cy = _y1 + _uy * (_k + 0.5) * _step, _a = _band * 0.34;
        tpr_cx_save(_c); tpr_cx_translate(_c, _cx, _cy);
        switch (_B.motif) {
            case "chevron":
                _c.stroke = tpr__rgb(_ink, 0.7); _c.lw = 1.6; tpr__p_begin(_c);
                tpr__p_move(_c, -_ux * _a - _nx * _a, -_uy * _a - _ny * _a); tpr__p_line(_c, _nx * _a * 0.2, _ny * _a * 0.2); tpr__p_line(_c, _ux * _a - _nx * _a, _uy * _a - _ny * _a);
                tpr__q_stroke(_c); break;
            case "key":
                _c.stroke = tpr__rgb(_ink, 0.8); _c.lw = 1.8; tpr__p_begin(_c);
                tpr__p_move(_c, -_ux * _a - _nx * _a, -_uy * _a - _ny * _a); tpr__p_line(_c, -_ux * _a + _nx * _a, -_uy * _a + _ny * _a); tpr__p_line(_c, _ux * _a + _nx * _a, _uy * _a + _ny * _a);
                tpr__p_line(_c, _ux * _a - _nx * _a * 0.2, _uy * _a - _ny * _a * 0.2); tpr__p_line(_c, -_ux * _a * 0.2 - _nx * _a * 0.2, -_uy * _a * 0.2 - _ny * _a * 0.2);
                tpr__q_stroke(_c); break;
            case "notch":
                _c.fill = tpr__rgb(_B.ink, 0.75); tpr__p_begin(_c);
                tpr__p_move(_c, -_ux * _a, -_uy * _a); tpr__p_line(_c, _ux * _a, _uy * _a); tpr__p_line(_c, _nx * _a * 0.9, _ny * _a * 0.9); tpr__p_close(_c); tpr__q_fill(_c);
                _c.stroke = tpr__rgb(tpr__mix(_B.base, [255, 240, 210], 0.4), 0.5); _c.lw = 1; tpr__p_begin(_c);
                tpr__p_move(_c, _ux * _a, _uy * _a); tpr__p_line(_c, _nx * _a * 0.9, _ny * _a * 0.9); tpr__q_stroke(_c); break;
            case "lozenge":
                _c.fill = tpr__rgb(_ink); tpr__p_begin(_c);
                tpr__p_move(_c, -_ux * _a, -_uy * _a); tpr__p_line(_c, _nx * _a * 0.55, _ny * _a * 0.55); tpr__p_line(_c, _ux * _a, _uy * _a); tpr__p_line(_c, -_nx * _a * 0.55, -_ny * _a * 0.55); tpr__p_close(_c);
                tpr__q_fill(_c); break;
            case "stitch":
                _c.stroke = tpr__rgb(_ink); _c.lw = 2.2; tpr__p_begin(_c);
                tpr__p_move(_c, -_ux * _a - _nx * _a * 0.6, -_uy * _a - _ny * _a * 0.6); tpr__p_line(_c, _ux * _a + _nx * _a * 0.6, _uy * _a + _ny * _a * 0.6);
                tpr__q_stroke(_c); break;
            case "rope": {
                // a rope is filled strands, each LONGER than the pitch so it overlaps the next, slanted, lit on its upper edge
                var _ang = arctan2(_uy, _ux) + 0.75;
                _c.fill = tpr__rgb(_ink, 0.9); tpr__p_begin(_c); tpr__p_ellipse(_c, 0, 0, _a * 1.75, _a * 0.62, _ang, 0, TPR_TAU); tpr__q_fill(_c);
                _c.stroke = tpr__rgb(tpr__mix(_B.base, [255, 236, 200], 0.45), 0.7); _c.lw = 1.2; tpr__p_begin(_c); tpr__p_ellipse(_c, 0, 0, _a * 1.75, _a * 0.62, _ang, pi * 1.1, pi * 1.8); tpr__q_stroke(_c);
                break;
            }
            case "bead":
                _c.fill = tpr__rgb(_ink); tpr__p_begin(_c); tpr__p_arc(_c, 0, 0, _a * 0.42, 0, TPR_TAU); tpr__q_fill(_c);
                _c.fill = tpr__rgb([255, 244, 210], 0.7); tpr__p_begin(_c); tpr__p_arc(_c, -_a * 0.13, -_a * 0.13, _a * 0.14, 0, TPR_TAU); tpr__q_fill(_c);
                break;
        }
        tpr_cx_restore(_c); _marks++;
    }
    return _marks;
}

/// the MZ drawBorder: a border band worked at a steady PITCH round (x, y, w, h); returns how many marks it made
function tpr__draw_border(_c, _B, _x, _y, _w, _h, _band) {
    var _o = _band / 2, _m = 0;
    _m += tpr__border_run(_c, _B, _x + _o, _y + _o, _x + _w - _o, _y + _o, 0, 1, _band);
    _m += tpr__border_run(_c, _B, _x + _w - _o, _y + _o, _x + _w - _o, _y + _h - _o, -1, 0, _band);
    _m += tpr__border_run(_c, _B, _x + _w - _o, _y + _h - _o, _x + _o, _y + _h - _o, 0, -1, _band);
    _m += tpr__border_run(_c, _B, _x + _o, _y + _h - _o, _x + _o, _y + _o, 1, 0, _band);
    return _m;
}

/// the MZ drawSlab: a drop shadow on the table, the bevelled edge lit upper left, the material, an inner line
function tpr__draw_slab(_c, _B, _id, _x, _y, _w, _h, _seed) {
    tpr_cx_save(_c); tpr__shadow_set(_c, [0, 0, 0], 0.6, 22, 9, 12); _c.fill = tpr__rgb(_B.edge); tpr__rrect(_c, _x, _y, _w, _h, 10); tpr__q_fill(_c); tpr_cx_restore(_c);
    var _eg = tpr_cx_linear(_c, _x, _y, _x + _w, _y + _h);
    tpr__stop(_eg, 0, tpr__mix(_B.edge, [255, 240, 210], 0.28)); tpr__stop(_eg, 1, tpr__mix(_B.edge, [0, 0, 0], 0.35));
    _c.fill = _eg; tpr__rrect(_c, _x, _y, _w, _h, 10); tpr__q_fill(_c);
    tpr_cx_save(_c); tpr__rrect(_c, _x + 7, _y + 7, _w - 14, _h - 14, 6); tpr__q_clip_logged(_c);
    tpr__q_surface(_c, _id, _x + 7, _y + 7, _w - 14, _h - 14, _seed, [_x + 7, _y + 7, _w - 14, _h - 14, 6]);
    tpr_cx_restore(_c);
    _c.stroke = tpr__rgb([0, 0, 0], 0.35); _c.lw = 1.5; tpr__rrect(_c, _x + 7, _y + 7, _w - 14, _h - 14, 6); tpr__q_stroke(_c);
}

/// the MZ drawWear: scratches and chipped edges; returns { scratches, chips }
function tpr__draw_wear(_c, _B, _x, _y, _w, _h, _seed, _amount) {
    var _r = tpr__rng(int64(_seed) ^ int64($3EA5)), _n = { scratches: 0, chips: 0 }, _a = is_numeric(_amount) ? _amount : 1, _k;
    var _dark = tpr__lum(_B.base) > 0.2;
    for (_k = 0; _k < floor(14 * _a + 0.5); _k++) {
        var _sx = _x + 12 + tpr__rng_next(_r) * (_w - 24);
        var _sy = _y + 12 + tpr__rng_next(_r) * (_h - 24);
        var _an = tpr__rng_next(_r) * TPR_TAU;
        var _l = 6 + tpr__rng_next(_r) * 26;
        _c.stroke = tpr__rgb(_dark ? [255, 244, 224] : [60, 50, 40], 0.16 + tpr__rng_next(_r) * 0.14);
        _c.lw = 0.8 + tpr__rng_next(_r) * 0.6;
        tpr__seg(_c, _sx, _sy, _sx + cos(_an) * _l, _sy + sin(_an) * _l); _n.scratches++;
    }
    for (_k = 0; _k < floor(5 * _a + 0.5); _k++) {
        var _side = floor(tpr__rng_next(_r) * 4);
        var _t = 0.08 + tpr__rng_next(_r) * 0.84;
        var _cxp = ((_side mod 2) == 0) ? _x + _t * _w : ((_side == 1) ? _x + _w - 3 : _x + 3);
        var _cyp = ((_side mod 2) == 1) ? _y + _t * _h : ((_side == 0) ? _y + 3 : _y + _h - 3);
        _c.fill = tpr__rgb(tpr__mix(_B.edge, [0, 0, 0], 0.45), 0.85);
        var _cr = 2 + tpr__rng_next(_r) * 3.5;
        tpr__p_begin(_c); tpr__p_arc(_c, _cxp, _cyp, _cr, 0, TPR_TAU); tpr__q_fill(_c); _n.chips++;
    }
    return _n;
}

/// the MZ drawPoint: a point where lines meet
function tpr__draw_point(_c, _B, _x, _y, _r) {
    if (_B.line == "groove" || _B.line == "burn") {
        _c.fill = tpr__rgb(_B.ink); tpr__p_begin(_c); tpr__p_arc(_c, _x, _y, _r, 0, TPR_TAU); tpr__q_fill(_c);
        _c.stroke = tpr__rgb(tpr__mix(_B.base, [255, 236, 200], 0.4), 0.6); _c.lw = 1.2; tpr__p_begin(_c); tpr__p_arc(_c, _x, _y, _r, 0.2, 1.9); tpr__q_stroke(_c);
    } else {
        _c.fill = tpr__rgb(_B.ink); tpr__p_begin(_c); tpr__p_arc(_c, _x, _y, _r, 0, TPR_TAU); tpr__q_fill(_c);
        _c.fill = tpr__rgb([255, 250, 236], 0.45); tpr__p_begin(_c); tpr__p_arc(_c, _x - _r * 0.3, _y - _r * 0.3, _r * 0.4, 0, TPR_TAU); tpr__q_fill(_c);
    }
}

/// the MZ drawPit: a carved cup, shadowed on the side nearer the lamp and lit on the far side
function tpr__draw_pit(_c, _B, _x, _y, _rx, _ry) {
    var _g = tpr_cx_radial(_c, _x + _rx * 0.28, _y + _ry * 0.3, _rx * 0.1, _x, _y, max(_rx, _ry));
    tpr__stop(_g, 0, tpr__mix(_B.base, [255, 240, 214], 0.18)); tpr__stop(_g, 0.62, tpr__mix(_B.base, [0, 0, 0], 0.28)); tpr__stop(_g, 1, tpr__mix(_B.base, [0, 0, 0], 0.62));
    _c.fill = _g; tpr__p_begin(_c); tpr__p_ellipse(_c, _x, _y, _rx, _ry, 0, 0, TPR_TAU); tpr__q_fill(_c);
    _c.stroke = tpr__rgb(tpr__mix(_B.base, [255, 240, 214], 0.45), 0.75); _c.lw = 2; tpr__p_begin(_c); tpr__p_ellipse(_c, _x, _y, _rx, _ry, 0, 0.1, pi - 0.1); tpr__q_stroke(_c);
    _c.stroke = tpr__rgb([0, 0, 0], 0.5); _c.lw = 2; tpr__p_begin(_c); tpr__p_ellipse(_c, _x, _y, _rx, _ry, 0, pi + 0.1, TPR_TAU - 0.1); tpr__q_stroke(_c);
}

/// @function tpr_draw_board(ctx, layout, style)
/// @description The whole board for a game, drawn once when it opens: the slab and its material, the border band, the
/// game's lines and points (or oware's pits and stores) and the wear of use. style = tpr_style_for(...). Returns
/// { lines, points, border, pits, wear: { scratches, chips } }.
/// @returns {Struct}
function tpr_draw_board(_c, _L, _style) {
    var _out = { lines: 0, points: 0, border: 0, wear: { scratches: 0, chips: 0 }, pits: 0 };
    if (!is_struct(_c) || !is_struct(_L) || !is_struct(_style) || !is_struct(_L[$ "board"]) || !is_array(_L[$ "pts"]) || !is_string(_L[$ "game"])) return _out;
    var _B = tpr_board_info(_style[$ "board"]), _b = _L.board, _T = tpr__t(), _band = 22, _i;
    if (!is_struct(_B) || !is_numeric(_style[$ "seed"])) return _out;
    tpr__draw_slab(_c, _B, _style.board, _b.x, _b.y, _b.w, _b.h, _style.seed);
    _out.border = tpr__draw_border(_c, _B, _b.x + 12, _b.y + 12, _b.w - 24, _b.h - 24, _band);
    _c.stroke = tpr__rgb(_B.ink, 0.55); _c.lw = 1.4; tpr__q_stroke_rect(_c, _b.x + 12 + _band + 3, _b.y + 12 + _band + 3, _b.w - 24 - 2 * _band - 6, _b.h - 24 - 2 * _band - 6);
    if (_L.game == "oware") {
        for (_i = 0; _i < 12; _i++) { tpr__draw_pit(_c, _B, _L.pts[_i].x, _L.pts[_i].y, _L.pitR, _L.pitR * 0.86); _out.pits++; }
        for (_i = 0; _i < 2; _i++) { var _st = _L.stores[_i]; tpr__draw_pit(_c, _B, _st.x, _st.y, _st.w / 2, _st.h / 2); _out.pits++; }
    } else {
        var _edges = (_L.game == "morris") ? _T.medges : ((_L.game == "foxgeese") ? _T.fedges : _T.zedges);
        for (_i = 0; _i < array_length(_edges); _i++) { var _p = _L.pts[_edges[_i][0]], _q = _L.pts[_edges[_i][1]]; tpr__stroke_line(_c, _B, _p.x, _p.y, _q.x, _q.y, (_L.game == "fanorona") ? 0.85 : 1); _out.lines++; }
        for (_i = 0; _i < array_length(_L.pts); _i++) { var _pt = _L.pts[_i]; tpr__draw_point(_c, _B, _pt.x, _pt.y, (_L.game == "fanorona") ? 3.2 : 5); _out.points++; }
    }
    _out.wear = tpr__draw_wear(_c, _B, _b.x + 10, _b.y + 10, _b.w - 20, _b.h - 20, _style.seed, _style.wear);
    return _out;
}

// ---------------------------------------------------------------------------------------------------------------
// The men, the seeds and the counts
// ---------------------------------------------------------------------------------------------------------------

/// @function tpr_draw_man(ctx, x, y, r, set, side, seed, lift)
/// @description One man centred at (x, y), radius r, lit from the upper left. side 0 = light, 1 = dark, "fox" = the fox.
/// lift 0..1 raises it off the board (a longer, softer shadow). seed varies stones and grain.
function tpr_draw_man(_c, _x, _y, _r, _setId, _side, _seed, _lift = 0) {
    var _S = tpr_set_info(_setId);
    if (!is_struct(_c) || !is_struct(_S) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_r) || !(_r > 0)) return;
    var _fox = is_string(_side) && _side == "fox";
    var _col = _fox ? [204, 92, 40] : ((is_numeric(_side) && _side == 1) ? _S.dark : _S.light), _kind = _fox ? "fox" : _S.kind;
    var _rr = tpr__rng((is_numeric(_seed) && _seed != 0) ? _seed : 1), _L = is_numeric(_lift) ? _lift : 0;
    var _sx = 3 + _L * 9, _sy = 4 + _L * 12;
    tpr_cx_save(_c); _c.fill = tpr__rgb([0, 0, 0], 0.42 - _L * 0.12); tpr__p_blur_begin(_c, 2 + _L * 4);
    tpr__p_begin(_c); tpr__p_ellipse(_c, _x + _sx, _y + _sy, _r * 1.02, _r * 0.94, 0, 0, TPR_TAU); tpr__q_fill(_c);
    tpr__p_blur_end(_c); tpr_cx_restore(_c);
    var _hi = tpr__mix(_col, [255, 252, 244], 0.55), _lo = tpr__mix(_col, [0, 0, 0], 0.45), _g, _k;
    if (_kind == "stone" || _kind == "fox") {
        tpr__p_begin(_c);
        var _n = 28, _ph = tpr__rng_next(_rr) * 10;
        for (_k = 0; _k <= _n; _k++) {
            var _a = _k / _n * TPR_TAU, _rad = _r * (1 + 0.07 * sin(_a * 2 + _ph) + 0.04 * sin(_a * 3 + _ph * 2));
            var _px = _x + cos(_a) * _rad * (_fox ? 1 : 1.06), _py = _y + sin(_a) * _rad * 0.94;
            if (_k > 0) tpr__p_line(_c, _px, _py); else tpr__p_move(_c, _px, _py);
        }
        tpr__p_close(_c);
        _g = tpr_cx_radial(_c, _x - _r * 0.35, _y - _r * 0.4, _r * 0.1, _x, _y, _r * 1.1); tpr__stop(_g, 0, _hi); tpr__stop(_g, 0.55, _col); tpr__stop(_g, 1, _lo); _c.fill = _g; tpr__q_fill(_c);
        tpr_cx_save(_c); tpr__p_clip(_c);
        for (_k = 0; _k < 40; _k++) {
            var _dk = tpr__rng_next(_rr) < 0.5;
            _c.fill = tpr__rgb(_dk ? tpr__mix(_col, [0, 0, 0], 0.4) : tpr__mix(_col, [255, 255, 255], 0.35), 0.35);
            var _fx = _x - _r + tpr__rng_next(_rr) * 2 * _r;
            var _fy = _y - _r + tpr__rng_next(_rr) * 2 * _r;
            tpr__q_fill_rect(_c, _fx, _fy, 1.2, 1.2);
        }
        if (_fox) {
            _c.stroke = tpr__rgb([232, 196, 104]); _c.lw = max(2, _r * 0.12); tpr__p_begin(_c); tpr__p_arc(_c, _x, _y, _r * 0.8, 0, TPR_TAU); tpr__q_stroke(_c);
            _c.fill = tpr__rgb([250, 232, 200], 0.9); tpr__p_begin(_c); tpr__p_arc(_c, _x, _y, _r * 0.22, 0, TPR_TAU); tpr__q_fill(_c);
        }
        tpr_cx_restore(_c);
    } else if (_kind == "turned") {
        _g = tpr_cx_radial(_c, _x - _r * 0.3, _y - _r * 0.35, _r * 0.1, _x, _y, _r); tpr__stop(_g, 0, _hi); tpr__stop(_g, 0.6, _col); tpr__stop(_g, 1, _lo);
        _c.fill = _g; tpr__p_begin(_c); tpr__p_arc(_c, _x, _y, _r, 0, TPR_TAU); tpr__q_fill(_c);
        for (var _q = 1; _q <= 3; _q++) {
            _c.stroke = tpr__rgb(tpr__mix(_col, [0, 0, 0], 0.4), 0.55); _c.lw = 1.2; tpr__p_begin(_c); tpr__p_arc(_c, _x, _y, _r * (0.25 * _q + 0.08), 0, TPR_TAU); tpr__q_stroke(_c);
            _c.stroke = tpr__rgb(_hi, 0.45); _c.lw = 0.8; tpr__p_begin(_c); tpr__p_arc(_c, _x, _y, _r * (0.25 * _q + 0.08) + 1, pi * 1.05, pi * 1.7); tpr__q_stroke(_c);
        }
    } else if (_kind == "glass") {
        _g = tpr_cx_radial(_c, _x + _r * 0.2, _y + _r * 0.25, _r * 0.1, _x, _y, _r);
        tpr__stop(_g, 0, tpr__mix(_col, [255, 255, 255], 0.35), 0.95); tpr__stop(_g, 0.7, _col, 0.9); tpr__stop(_g, 1, _lo, 0.95);
        _c.fill = _g; tpr__p_begin(_c); tpr__p_arc(_c, _x, _y, _r, 0, TPR_TAU); tpr__q_fill(_c);
        _c.fill = tpr__rgb([255, 255, 255], 0.85); tpr__p_begin(_c); tpr__p_ellipse(_c, _x - _r * 0.38, _y - _r * 0.42, _r * 0.26, _r * 0.15, -0.7, 0, TPR_TAU); tpr__q_fill(_c);
        _c.stroke = tpr__rgb(tpr__mix(_col, [255, 255, 255], 0.6), 0.55); _c.lw = 1.6; tpr__p_begin(_c); tpr__p_arc(_c, _x, _y, _r * 0.8, 0.3, 1.6); tpr__q_stroke(_c);
    } else if (_kind == "coin") {
        _g = tpr_cx_linear(_c, _x - _r, _y - _r, _x + _r, _y + _r); tpr__stop(_g, 0, _hi); tpr__stop(_g, 0.5, _col); tpr__stop(_g, 1, _lo);
        _c.fill = _g; tpr__p_begin(_c); tpr__p_arc(_c, _x, _y, _r, 0, TPR_TAU); tpr__q_fill(_c);
        _c.stroke = tpr__rgb(_lo); _c.lw = max(1.5, _r * 0.1); tpr__p_begin(_c); tpr__p_arc(_c, _x, _y, _r * 0.82, 0, TPR_TAU); tpr__q_stroke(_c);
        _c.fill = tpr__rgb(_lo, 0.8);
        for (var _p = 0; _p < 7; _p++) { var _an = _p / 7 * TPR_TAU - pi / 2; tpr__p_begin(_c); tpr__p_ellipse(_c, _x + cos(_an) * _r * 0.38, _y + sin(_an) * _r * 0.38, _r * 0.16, _r * 0.07, _an, 0, TPR_TAU); tpr__q_fill(_c); }
        tpr__p_begin(_c); tpr__p_arc(_c, _x, _y, _r * 0.13, 0, TPR_TAU); tpr__q_fill(_c);
    } else if (_kind == "clay") {
        _g = tpr_cx_radial(_c, _x - _r * 0.3, _y - _r * 0.35, _r * 0.1, _x, _y, _r); tpr__stop(_g, 0, _hi); tpr__stop(_g, 0.65, _col); tpr__stop(_g, 1, _lo);
        _c.fill = _g; tpr__p_begin(_c); tpr__p_arc(_c, _x, _y, _r, 0, TPR_TAU); tpr__q_fill(_c);
        _c.fill = tpr__rgb(_lo, 0.55); tpr__p_begin(_c); tpr__p_ellipse(_c, _x + _r * 0.1, _y + _r * 0.05, _r * 0.3, _r * 0.24, 0.4, 0, TPR_TAU); tpr__q_fill(_c);
        _c.stroke = tpr__rgb(_hi, 0.4); _c.lw = 1; tpr__p_begin(_c); tpr__p_ellipse(_c, _x + _r * 0.1, _y + _r * 0.05, _r * 0.3, _r * 0.24, 0.4, 2.2, 4.6); tpr__q_stroke(_c);
    }
    _c.stroke = tpr__rgb([0, 0, 0], 0.35); _c.lw = 1; tpr__p_begin(_c); tpr__p_arc(_c, _x, _y, _r, 0.2, 2.9); tpr__q_stroke(_c);
}

/// @function tpr_draw_count(ctx, x, y, n, board, [size])
/// @description The count of a pit or store, cut into the board beside it: a figure with a lit or dark lip, its ink solved
/// against the board's own colour. board = a tpr_board_info record.
function tpr_draw_count(_c, _x, _y, _n, _B, _size = 20) {
    if (!is_struct(_c) || !is_numeric(_x) || !is_numeric(_y) || !is_struct(_B) || !is_array(_B[$ "base"]) || !is_array(_B[$ "ink"])) return;
    var _s = (is_numeric(_size) && _size > 0) ? _size : 20, _ink = tpr__pick_ink(_B.base, [_B.ink, [32, 20, 12], [244, 234, 210]], 4.5);
    tpr__font(_c, _s, TPR_FACE_DISPLAY); tpr__text_align(_c, 1, 1);
    _c.fill = tpr__rgb((tpr__lum(_ink) < tpr__lum(_B.base)) ? tpr__mix(_B.base, [255, 244, 220], 0.5) : [0, 0, 0], 0.55); tpr__q_text(_c, string(_n), _x + 1, _y + 1.5);
    _c.fill = tpr__rgb(_ink); tpr__q_text(_c, string(_n), _x, _y);
}

/// @function tpr_draw_seeds(ctx, x, y, pitR, n, set, seed)
/// @description Oware: n seeds of the set's kind heaped in a pit (a packed spiral). Returns how many were drawn (capped at 30).
/// @returns {Real}
function tpr_draw_seeds(_c, _x, _y, _pitR, _n, _setId, _seed) {
    var _S = tpr_set_info(_setId);
    if (!is_struct(_c) || !is_struct(_S) || !is_numeric(_n) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_pitR)) return 0;
    var _r = tpr__rng((is_numeric(_seed) && _seed != 0) ? _seed : 3), _sr = _pitR * 0.19, _placed = min(_n, 30);
    for (var _k = 0; _k < _placed; _k++) {
        var _a = _k * 2.39996 + tpr__rng_next(_r) * 0.4, _d = sqrt(_k + 0.5) * _sr * 1.05 * ((_placed > 18) ? 0.86 : 1);
        var _px = _x + cos(_a) * min(_d, _pitR * 0.72), _py = _y + sin(_a) * min(_d, _pitR * 0.62);
        var _col = tpr__mix(_S.light, _S.dark, ((_k * 37) mod 11) / 22), _rot = tpr__rng_next(_r) * TPR_TAU;
        _c.fill = tpr__rgb([0, 0, 0], 0.35); tpr__p_begin(_c); tpr__p_ellipse(_c, _px + 1.5, _py + 2, _sr, _sr * 0.8, _rot, 0, TPR_TAU); tpr__q_fill(_c);
        var _g = tpr_cx_radial(_c, _px - _sr * 0.4, _py - _sr * 0.4, 0.5, _px, _py, _sr * 1.2);
        tpr__stop(_g, 0, tpr__mix(_col, [255, 255, 255], 0.5)); tpr__stop(_g, 1, tpr__mix(_col, [0, 0, 0], 0.35));
        _c.fill = _g; tpr__p_begin(_c);
        if (_S.seed == "cowrie" || _S.seed == "bean") tpr__p_ellipse(_c, _px, _py, _sr * 1.1, _sr * 0.72, _rot, 0, TPR_TAU);
        else { var _rad = _sr * ((_S.seed == "pebble") ? 0.95 + tpr__rng_next(_r) * 0.2 : 0.9); tpr__p_arc(_c, _px, _py, _rad, 0, TPR_TAU); }
        tpr__q_fill(_c);
        if (_S.seed == "cowrie") { _c.stroke = tpr__rgb([90, 60, 30], 0.8); _c.lw = 1; tpr__p_begin(_c); tpr__p_move(_c, _px - cos(_rot) * _sr * 0.7, _py - sin(_rot) * _sr * 0.7); tpr__p_line(_c, _px + cos(_rot) * _sr * 0.7, _py + sin(_rot) * _sr * 0.7); tpr__q_stroke(_c); }
        if (_S.seed == "bean") { _c.stroke = tpr__rgb([255, 240, 220], 0.5); _c.lw = 1; tpr__p_begin(_c); tpr__p_ellipse(_c, _px, _py, _sr * 0.6, _sr * 0.3, _rot, 3.6, 5.8); tpr__q_stroke(_c); }
        if (_S.seed == "coin") { _c.stroke = tpr__rgb(tpr__mix(_col, [0, 0, 0], 0.5), 0.8); _c.lw = 1; tpr__p_begin(_c); tpr__p_arc(_c, _px, _py, _sr * 0.6, 0, TPR_TAU); tpr__q_stroke(_c); }
    }
    return _placed;
}

// ---------------------------------------------------------------------------------------------------------------
// The panel: plaques, the card, the status strip, the cursor's rings and the verdict
// ---------------------------------------------------------------------------------------------------------------

/// @function tpr_draw_plaque(ctx, x, y, w, h, label, state)
/// @description A worked-brass plaque; state "idle" | "on" | "off". The label's size steps down until it fits inside the
/// plaque's inner rule. Returns the size the label was set at.
/// @returns {Real}
function tpr_draw_plaque(_c, _x, _y, _w, _h, _label, _state) {
    if (!is_struct(_c) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_h) || !(_w > 0) || !(_h > 0)) return 0;
    _label = string(_label);
    var _base = (_state == "off") ? [96, 84, 66] : ((_state == "on") ? [232, 196, 116] : [196, 156, 84]);
    var _g = tpr_cx_linear(_c, _x, _y, _x, _y + _h); tpr__stop(_g, 0, tpr__mix(_base, [255, 250, 230], 0.35)); tpr__stop(_g, 1, tpr__mix(_base, [0, 0, 0], 0.3));
    _c.fill = tpr__rgb([0, 0, 0], 0.45); tpr__rrect(_c, _x + 2, _y + 3, _w, _h, 6); tpr__q_fill(_c);
    _c.fill = _g; tpr__rrect(_c, _x, _y, _w, _h, 6); tpr__q_fill(_c);
    _c.stroke = tpr__rgb(tpr__mix(_base, [0, 0, 0], 0.55)); _c.lw = 1.5; tpr__rrect(_c, _x + 3, _y + 3, _w - 6, _h - 6, 4); tpr__q_stroke(_c);
    var _fs = floor(_h * 0.46 + 0.5); tpr__font(_c, _fs, TPR_FACE_DISPLAY);
    while (_fs > 10 && tpr__measure(_c, _label) > _w - 14) { _fs--; tpr__font(_c, _fs, TPR_FACE_DISPLAY); }
    tpr__text_align(_c, 1, 1);
    _c.fill = tpr__rgb(tpr__pick_ink(_base, [[44, 26, 10], [250, 240, 214]], 4.5)); tpr__q_text(_c, _label, _x + _w / 2, _y + _h / 2 + 1);
    return _fs;
}

/// the MZ fitSize: the largest bold size (max down to min) at which text fits w
function tpr__fit_size(_c, _text, _w, _max, _min) {
    for (var _s = _max; _s > _min; _s--) { tpr__font(_c, _s, TPR_FACE_DISPLAY); if (tpr__measure(_c, _text) <= _w) return _s; }
    return _min;
}

/// @function tpr_draw_placard(ctx, x, y, w, h, info)
/// @description A parchment slip pinned to the table: the game, a name, a grade line and up to four lines.
/// info = { game, name, grade, lines: [] }.
function tpr_draw_placard(_c, _x, _y, _w, _h, _info) {
    if (!is_struct(_c) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_h) || !(_w > 0) || !(_h > 0) || !is_struct(_info)) return;
    _info = { game: is_undefined(_info[$ "game"]) ? "" : _info.game, name: is_undefined(_info[$ "name"]) ? "" : _info.name, grade: is_undefined(_info[$ "grade"]) ? "" : _info.grade, lines: _info[$ "lines"] };
    var _paper = [230, 214, 178];
    tpr_cx_save(_c); tpr__shadow_set(_c, [0, 0, 0], 0.55, 12, 5, 7); _c.fill = tpr__rgb(_paper); tpr__q_fill_rect(_c, _x, _y, _w, _h); tpr_cx_restore(_c);
    tpr_cx_save(_c); tpr__p_begin(_c); tpr__q_rect(_c, _x, _y, _w, _h); tpr__q_clip_logged(_c);
    tpr__q_surface(_c, "linen", _x, _y, _w, _h, 77, [_x, _y, _w, _h, 0]);
    _c.fill = tpr__rgb([236, 222, 186], 0.72); tpr__q_fill_rect(_c, _x, _y, _w, _h); tpr_cx_restore(_c);
    _c.stroke = tpr__rgb([90, 60, 30], 0.6); _c.lw = 1; tpr__q_stroke_rect(_c, _x + 5.5, _y + 5.5, _w - 11, _h - 11);
    var _ink = [52, 30, 16];
    _c.fill = tpr__rgb(_ink); tpr__text_align(_c, 1, 0);
    tpr__font(_c, 15, TPR_FACE_BODY); tpr__q_text(_c, _info.game, _x + _w / 2, _y + 28);
    var _ns = tpr__fit_size(_c, _info.name, _w - 24, 26, 14);
    tpr__font(_c, _ns, TPR_FACE_DISPLAY); tpr__q_text(_c, _info.name, _x + _w / 2, _y + 60);
    tpr__font(_c, 14, TPR_FACE_BODY); _c.fill = tpr__rgb([110, 60, 30]); tpr__q_text(_c, _info.grade, _x + _w / 2, _y + 80);
    _c.fill = tpr__rgb(_ink); tpr__font(_c, 14, TPR_FACE_BODY);
    var _lines = is_array(_info[$ "lines"]) ? _info.lines : [];
    for (var _i = 0; _i < array_length(_lines); _i++) tpr__q_text(_c, _lines[_i], _x + _w / 2, _y + 108 + _i * 20);
}

/// @function tpr_draw_status(ctx, w, h, text)
/// @description A one-line status strip in lamp-lit letters on a dark band over (0, 0, w, h); a line too long for one row
/// breaks into two at the word nearest the middle. Returns the number of lines set.
/// @returns {Real}
function tpr_draw_status(_c, _w, _h, _text) {
    if (!is_struct(_c) || !is_numeric(_w) || !is_numeric(_h) || !(_w > 0) || !(_h > 0)) return 0;
    tpr_cx_clear_rect(_c, 0, 0, _w, _h);
    var _g = tpr_cx_linear(_c, 0, 0, 0, _h); tpr_cx_stop(_g, 0, [20, 12, 6], 0.78); tpr_cx_stop(_g, 1, [12, 6, 2], 0.86);
    _c.fill = _g; tpr__rrect(_c, 0, 0, _w, _h, 8); tpr__q_fill(_c);
    _c.stroke = tpr__rgb([200, 160, 90], 0.5); _c.lw = 1; tpr__rrect(_c, 1.5, 1.5, _w - 3, _h - 3, 7); tpr__q_stroke(_c);
    _c.fill = tpr__rgb([241, 223, 180]); tpr__text_align(_c, 1, 1);
    var _t = string(_text), _s = 18; tpr__font(_c, _s, TPR_FACE_BODY);
    while (_s > 14 && tpr__measure(_c, _t) > _w - 20) { _s--; tpr__font(_c, _s, TPR_FACE_BODY); }
    if (tpr__measure(_c, _t) <= _w - 20) { tpr__q_text(_c, _t, _w / 2, _h / 2 + 1); return 1; }
    var _words = string_split(_t, " "), _best = 1, _bd = infinity;
    for (var _i = 1; _i < array_length(_words); _i++) {
        var _a = tpr__join_words(_words, 0, _i), _b = tpr__join_words(_words, _i, array_length(_words)), _d = abs(tpr__measure(_c, _a) - tpr__measure(_c, _b));
        if (_d < _bd) { _bd = _d; _best = _i; }
    }
    var _l1 = tpr__join_words(_words, 0, _best), _l2 = tpr__join_words(_words, _best, array_length(_words));
    _s = min(16, floor((_h - 8) / 2.3)); tpr__font(_c, _s, TPR_FACE_BODY);
    while (_s > 10 && max(tpr__measure(_c, _l1), tpr__measure(_c, _l2)) > _w - 16) { _s--; tpr__font(_c, _s, TPR_FACE_BODY); }
    tpr__q_text(_c, _l1, _w / 2, _h / 2 - _s * 0.6); tpr__q_text(_c, _l2, _w / 2, _h / 2 + _s * 0.65);
    return 2;
}
/// words[i0 .. i1) joined by single spaces (the JS slice(i0, i1).join(' '))
function tpr__join_words(_w, _i0, _i1) { var _o = ""; for (var _i = _i0; _i < _i1; _i++) _o += ((_i > _i0) ? " " : "") + _w[_i]; return _o; }

/// @function tpr_draw_marker(ctx, x, y, r, kind)
/// @description A ring round a point: "target" (a legal next click, dashed), "sel" (the man picked up), "take" (a man that
/// can be taken, with a cross), "last" (where the last move went).
function tpr_draw_marker(_c, _x, _y, _r, _kind) {
    if (!is_struct(_c) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_r) || !(_r > 0)) return;
    var _col = (_kind == "take") ? [236, 84, 60] : ((_kind == "sel") ? [255, 226, 130] : ((_kind == "last") ? [140, 200, 255] : [250, 214, 120]));
    _c.stroke = tpr__rgb([0, 0, 0], 0.5); _c.lw = 5; tpr__p_begin(_c); tpr__p_arc(_c, _x, _y, _r, 0, TPR_TAU); tpr__q_stroke(_c);
    _c.stroke = tpr__rgb(_col, (_kind == "target") ? 0.8 : 1); _c.lw = (_kind == "target") ? 2.4 : 3.2; tpr_cx_set_dash(_c, (_kind == "target") ? [5, 4] : []);
    tpr__p_begin(_c); tpr__p_arc(_c, _x, _y, _r, 0, TPR_TAU); tpr__q_stroke(_c); tpr_cx_set_dash(_c, []);
    if (_kind == "take") { _c.lw = 3; tpr__seg(_c, _x - _r * 0.45, _y - _r * 0.45, _x + _r * 0.45, _y + _r * 0.45); tpr__seg(_c, _x + _r * 0.45, _y - _r * 0.45, _x - _r * 0.45, _y + _r * 0.45); }
}

/// @function tpr_draw_verdict(ctx, W, H, info, cx, cy)
/// @description The end of the game: a slip with the verdict over a dimmed table, centred on (cx, cy) - the BOARD's centre,
/// never the panel. info = { game, title, sub, lines: [] }.
function tpr_draw_verdict(_c, _W, _H, _info, _cx, _cy) {
    if (!is_struct(_c) || !is_numeric(_W) || !is_numeric(_H) || !(_W > 0) || !(_H > 0) || !is_struct(_info)) return;
    _info = { game: _info[$ "game"], title: _info[$ "title"], sub: _info[$ "sub"], lines: _info[$ "lines"] };
    tpr_cx_clear_rect(_c, 0, 0, _W, _H);
    _c.fill = tpr__rgb([6, 3, 1], 0.55); tpr__q_fill_rect(_c, 0, 0, _W, _H);
    var _w = 440, _h = 190, _x = (is_numeric(_cx) ? _cx : _W / 2) - _w / 2, _y = (is_numeric(_cy) ? _cy : _H / 2) - _h / 2;
    tpr_draw_placard(_c, _x, _y, _w, _h, { game: _info.game, name: _info.title, grade: _info.sub, lines: _info.lines });
}
