{
  "$GMScript": "v1",
  "%Name": "tpr_oracle_core",
  "name": "tpr_oracle_core",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}