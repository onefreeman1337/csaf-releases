/// tpr_table.gml - THE TABLE: sit the player across from an opponent and play one game, start to verdict. One struct, three
/// calls: tpr_table_open (once), tpr_table_step (every Step), tpr_table_draw (every Draw or Draw GUI); then read the result
/// and tpr_table_free. Mouse and keyboard are read for you; the opponent thinks a slice of each frame, so the game never
/// stalls; every picture is drawn by the package (tpr_draw) and cached as sprites.
///
/// Taproom - Tavern Board Games Against an Opponent Who Thinks, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// The RPG Maker MZ edition's Scene_Taproom (Taproom.js), ported: the same turns, prompts, motions, plaques and verdict.
/// Differences, on purpose: the gold, variables and switches an MZ event sets are YOUR game's business here - read
/// T.result when the table closes; sounds are optional asset ids you assign (T.sounds); the table is drawn at any position
/// and scale (tpr_table_draw), and the input is read relative to that.
///
/// Public functions (each documented below): tpr_table_open, tpr_table_step, tpr_table_draw, tpr_table_closed,
/// tpr_table_free, tpr_record, tpr_records_save, tpr_records_load, tpr_grade_name, tpr_game_name.

#macro TPR_W 816
#macro TPR_H 624
#macro TPR_SS 2
#macro TPR_MIN_THINK 34

// ---------------------------------------------------------------------------------------------------------------
// Records and names
// ---------------------------------------------------------------------------------------------------------------

/// @function tpr__records()
function tpr__records() { static _R = { v: 1, rec: {}, played: {} }; return _R; }

/// @function tpr_record(name, game)
/// @description The player's record against an opponent at a game: { w, l, d } (created on first ask).
/// @returns {Struct}
function tpr_record(_name, _game) {
    var _r = tpr__records().rec, _k = string(_name) + "|" + string(_game);
    if (!is_struct(_r[$ _k])) _r[$ _k] = { w: 0, l: 0, d: 0 };
    return _r[$ _k];
}

/// @function tpr_records_save()
/// @description Every record and play count as a JSON string, for your save file.
/// @returns {String}
function tpr_records_save() { return json_stringify(tpr__records()); }

/// @function tpr_records_load(json)
/// @description Restore what tpr_records_save wrote. A string that is not a Taproom record is refused (returns false).
/// @returns {Bool}
function tpr_records_load(_json) {
    if (!is_string(_json)) return false;
    var _d = undefined;
    try { _d = json_parse(_json); } catch (_e) { return false; }
    if (!is_struct(_d) || !is_struct(_d[$ "rec"]) || !is_struct(_d[$ "played"])) return false;
    var _R = tpr__records(); _R.rec = _d.rec; _R.played = _d.played;
    return true;
}

/// @function tpr_game_name(game)
/// @returns {String}
function tpr_game_name(_g) { switch (_g) { case "morris": return "Nine Men's Morris"; case "foxgeese": return "Fox and Geese"; case "oware": return "Oware"; case "fanorona": return "Fanorona"; } return ""; }
/// @function tpr_grade_name(grade)
/// @description "Novice", "Regular", "Sharp", "Hustler" or "Master" for grade 1..5.
/// @returns {String}
function tpr_grade_name(_gr) { var _n = tpr__t().grade_names; return _n[clamp(floor(is_numeric(_gr) ? _gr : 3), 1, 5)]; }
function tpr__side_name(_g, _side) { switch (_g) { case "morris": return (_side == 0) ? "light" : "dark"; case "foxgeese": return (_side == 0) ? "fox" : "geese"; case "oware": return (_side == 0) ? "south" : "north"; } return (_side == 0) ? "white" : "black"; }
function tpr__rules(_g) {
    switch (_g) {
        case "morris": return ["Take turns placing your nine men on the points.", "Three in a row along a line is a mill: take one of their men", "(not one standing in a mill, unless all of them are).", "Then move a man along a line to an empty neighbour.", "Down to three men, you may fly to any empty point.", "Leave them two men, or no move, and you win."];
        case "foxgeese": return ["The geese move first, one step forward or sideways.", "The fox steps any way along the lines,", "or jumps a goose to an empty point beyond to take it,", "and may keep jumping.", "Trap the fox and the geese win.", "Take enough geese that they cannot, and the fox wins."];
        case "oware": return ["Take every seed from a pit on your row and sow them", "one by one round the board, anticlockwise.", "If your last seed makes two or three in their pit,", "take them, and any twos and threes just behind it.", "Never leave their row empty if you can feed it.", "More than twenty-four seeds wins."];
    }
    return ["Move a man along a line to the next empty point.", "Moving TOWARD their line takes it (approach);", "moving AWAY from an adjacent one takes it (withdrawal).", "After a capture the same man may go on taking,", "never twice in one direction or back to a point it left.", "Taking is compulsory. Take every man to win."];
}

// ---------------------------------------------------------------------------------------------------------------
// Baking pictures: drawn through the kit at 2x, filtered down, kept as sprites
// ---------------------------------------------------------------------------------------------------------------

/// @function tpr__bake(w, h, ox, oy, painter, args)
/// @description Internal. A w x h sprite (origin ox, oy) of what painter(ctx, args) draws, supersampled 2x and filtered
/// down. The sprite is PREMULTIPLIED (drawn on a transparent target "over"); tpr__draw_spr composites it as such. Every
/// internal pass runs under identity and the caller's world matrix is handed back.
function tpr__bake(_w, _h, _ox, _oy, _painter, _args) {
    var _W = max(1, ceil(_w)), _H = max(1, ceil(_h));
    var _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_build_identity());
    var _s2 = surface_create(_W * TPR_SS, _H * TPR_SS), _s1 = surface_create(_W, _H);
    surface_set_target(_s2);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false);
    var _c = tpr_cx_create(TPR_SS);
    _painter(_c, _args);
    gpu_pop_state();
    surface_reset_target();
    surface_set_target(_s1);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    gpu_set_blendmode_ext(bm_one, bm_zero); gpu_set_texfilter(true);
    draw_surface_ext(_s2, 0, 0, 1 / TPR_SS, 1 / TPR_SS, 0, c_white, 1);
    gpu_pop_state();
    surface_reset_target();
    var _spr = sprite_create_from_surface(_s1, 0, 0, _W, _H, false, false, _ox, _oy);
    surface_free(_s2); surface_free(_s1);
    matrix_set(matrix_world, _mw);
    return _spr;
}
/// draw a baked (premultiplied) sprite at table point (x, y), scale s, opacity a
function tpr__draw_spr(_spr, _x, _y, _s, _a) {
    if (!sprite_exists(_spr)) return;
    draw_sprite_ext(_spr, 0, _x, _y, _s, _s, 0, merge_colour(c_black, c_white, _a), _a);
}
/// a cached baked sprite by key (made on first ask); the cache is trimmed in step, never while drawing
function tpr__cached(_T, _key, _w, _h, _ox, _oy, _painter, _args) {
    var _e = _T.cache[$ _key];
    if (is_struct(_e) && sprite_exists(_e.spr)) { _e.used = _T.frame; return _e.spr; }
    var _spr = tpr__bake(_w, _h, _ox, _oy, _painter, _args);
    _T.cache[$ _key] = { spr: _spr, used: _T.frame, keep: string_pos("keep:", _key) == 1 };
    return _spr;
}

// painters (ctx, args) - each draws one picture through tpr_draw
function tpr__pnt_background(_c, _a) {
    var _T = _a.T;
    tpr_draw_table(_c, TPR_W, TPR_H, real((int64(_T.style.seed) ^ int64($7AB1E)) & int64($FFFFFFFF)));
    _T.boardInfo = tpr_draw_board(_c, _T.L, _T.style);
    var _ks = ["theirs", "mine"];
    for (var _i = 0; _i < 2; _i++) {
        var _b = _T.R[$ _ks[_i]];
        tpr_cx_save(_c); tpr__shadow_set(_c, [0, 0, 0], 0.5, 10, 4, 6); _c.fill = tpr__rgb([74, 44, 22]); tpr__rrect(_c, _b.x, _b.y, _b.w, _b.h, 8); tpr__q_fill(_c); tpr_cx_restore(_c);
        var _g = tpr_cx_linear(_c, _b.x, _b.y, _b.x, _b.y + _b.h); tpr__stop(_g, 0, [42, 58, 38]); tpr__stop(_g, 1, [26, 38, 24]);
        _c.fill = _g; tpr__rrect(_c, _b.x + 6, _b.y + 6, _b.w - 12, _b.h - 12, 5); tpr__q_fill(_c);
        _c.stroke = tpr__rgb([0, 0, 0], 0.6); _c.lw = 2; tpr__rrect(_c, _b.x + 6, _b.y + 6, _b.w - 12, _b.h - 12, 5); tpr__q_stroke(_c);
        _c.stroke = tpr__rgb([214, 170, 96], 0.55); _c.lw = 1; tpr__rrect(_c, _b.x + 1.5, _b.y + 1.5, _b.w - 3, _b.h - 3, 7); tpr__q_stroke(_c);
    }
}
function tpr__pnt_man(_c, _a) { tpr_draw_man(_c, _a.sz / 2 - 3, _a.sz / 2 - 3, _a.r, _a.set, _a.side, _a.seed, 0); }
function tpr__pnt_card(_c, _a) { tpr_draw_placard(_c, 0, 0, _a.w, _a.h, _a.info); }
function tpr__pnt_status(_c, _a) { tpr_draw_status(_c, _a.w, _a.h, _a.text); }
function tpr__pnt_plaque(_c, _a) { tpr_draw_plaque(_c, 4, 4, _a.w, _a.h, _a.label, _a.state); }
function tpr__pnt_marker(_c, _a) { tpr_draw_marker(_c, _a.r + 6, _a.r + 6, _a.r, _a.kind); }
function tpr__pnt_label(_c, _a) {
    _c.fill = tpr__rgb([232, 211, 162]); tpr__text_align(_c, 0, 1);
    var _px = 14; tpr__font(_c, _px, TPR_FACE_BODY);
    // the MZ fillText(label, x, y, maxWidth) squeezes a long label; here the size steps down until it fits
    while (_px > 10 && tpr__measure(_c, _a.text) > _a.w) { _px--; tpr__font(_c, _px, TPR_FACE_BODY); }
    tpr__q_text(_c, _a.text, 0, 15);
}
function tpr__pnt_cardover(_c, _a) {
    _c.fill = tpr__rgb([6, 3, 1], 0.55); tpr__q_fill_rect(_c, 0, 0, TPR_W, TPR_H);
    tpr_draw_placard(_c, _a.x, _a.y, _a.w, _a.h, _a.info);
}
function tpr__pnt_pit(_c, _a) {
    tpr_draw_seeds(_c, _a.w / 2, _a.h / 2, _a.pitR, _a.n, _a.set, _a.seed);
    tpr_draw_count(_c, _a.w / 2, (_a.i >= 6) ? _a.h / 2 - _a.pitR - _a.gap : _a.h / 2 + _a.pitR + _a.gap, _a.n, tpr_board_info(_a.board), 19);
}
function tpr__pnt_store(_c, _a) {
    var _r = tpr__rng(_a.seed), _shown = min(_a.n, 48), _sr = _a.pitR * 0.19, _cx = _a.w / 2, _cy = _a.h / 2 + ((_a.k == 0) ? -14 : 14);
    // seeds heap in a tall spiral round the store's middle; the count is cut INSIDE its far end
    for (var _j = 0; _j < _shown; _j++) {
        var _an = _j * 2.39996 + tpr__rng_next(_r) * 0.3, _d = sqrt(_j + 0.5) * _sr * 1.15;
        tpr_draw_seeds(_c, _cx + cos(_an) * min(_d, _a.sw * 0.3), _cy + sin(_an) * min(_d * 2.3, _a.sh * 0.3), _sr * 5.2, 1, _a.set, _j + 7);
    }
    tpr_draw_count(_c, _cx, (_a.k == 0) ? _a.h - 50 : 50, _a.n, tpr_board_info(_a.board), 22);
}
function tpr__pnt_hand(_c, _a) { tpr_draw_seeds(_c, 30, 30, 26, 5, _a.set, 3); }

// ---------------------------------------------------------------------------------------------------------------
// Opening the table
// ---------------------------------------------------------------------------------------------------------------

/// @function tpr_table_open(request)
/// @description Sit the player down. request = { game ("morris" | "foxgeese" | "oware" | "fanorona"), opponent (their
/// name, shown on the card; it also chooses their board and men), grade (1..5: Novice, Regular, Sharp, Hustler, Master),
/// side ("first" | "second" | "random"; in Fox and Geese "fox" | "geese" - the geese move first), stake (a number shown on
/// the card and in the verdict; moving gold is your game's business), seed (optional: the same seed gives the same
/// opponent choices), board / set (optional: a tpr_board_ids / tpr_set_ids id instead of the opponent's own), key (optional:
/// where they sit, for the play count), watch (optional: true = the player's side is played by the search too, at
/// watch_grade - an attract mode, or two NPCs at a table), auto_close (optional: true = close by itself after the verdict)
/// }. Everything is drawn here, once: the table, the board and every man, supersampled. That is an OPENING cost - MEASURED
/// 2.6 to 3.6 s on our (shared, busy) test machine, runtime 2024.14.4.268 - so open a table behind your own transition: draw
/// a "setting the board" frame first and call this on the next Step (tpr_demo_step does exactly that). Returns the table.
/// @returns {Struct}
function tpr_table_open(_req) {
    var _q = is_struct(_req) ? _req : {};
    var _game = _q[$ "game"]; if (!is_string(_game) || tpr_game_name(_game) == "") _game = "morris";
    var _opp = _q[$ "opponent"]; if (!is_string(_opp) || _opp == "") _opp = "The Stranger";
    var _key = is_string(_q[$ "key"]) ? _q.key : "table|" + _opp;
    var _played = tpr__records().played[$ _key]; if (!is_numeric(_played)) _played = 0;
    var _seed = is_numeric(_q[$ "seed"]) ? real(int64(abs(floor(_q.seed))) & int64($FFFFFFFF)) : tpr_hash(_key + "|" + string(_played));
    var _sideArg = is_string(_q[$ "side"]) ? _q.side : "first", _human;
    if (_game == "foxgeese") _human = (_sideArg == "fox" || _sideArg == "second") ? 0 : ((_sideArg == "random") ? real(int64(_seed) & 1) : 1);
    else _human = (_sideArg == "second" || _sideArg == "geese") ? 1 : ((_sideArg == "random") ? real(int64(_seed) & 1) : 0);
    var _grade = clamp(floor(is_numeric(_q[$ "grade"]) ? _q.grade : 3), 1, 5);
    var _stake = max(0, floor(is_numeric(_q[$ "stake"]) ? _q.stake : 0));
    var _T = {
        req: { key: _key, seed: _seed, game: _game, human: _human, grade: _grade, opponent: _opp, stake: _stake },
        style: tpr_style_for(_opp, _game, is_string(_q[$ "board"]) ? _q.board : "", is_string(_q[$ "set"]) ? _q.set : ""),
        g: _game, human: _human, m: tpr_match_new(_game, { human: _human }), L: tpr_layout(_game, TPR_W, TPR_H),
        prefix: [], opts: undefined, targets: [], cur: 0, q: [], mode: "start", anim: 0, concede: 0, hover: -1, rules: false,
        thinker: undefined, thinkFrames: 0, dots: 0, last: [], aiMove: undefined, aiTokens: [], aiI: 0, statusText: "", aiMark: undefined,
        men: [], occ: [], hand: [[], []], tray: [[], []], animMan: -1, vis: [], visStore: [0, 0], hand1: { x: 0, y: 0, on: false }, pendingStore: 0,
        legal: undefined, legalFor: undefined, cache: {}, frame: 0, result: undefined, closed: false, verdictA: 0, verdictInfo: undefined,
        thinkMs: 6.0, minThink: TPR_MIN_THINK, x: 0, y: 0, scale: 1, rep: { left: 0, right: 0, up: 0, down: 0 }, thinkText: "",
        watch: (_q[$ "watch"] == true), watchGrade: clamp(floor(is_numeric(_q[$ "watch_grade"]) ? _q.watch_grade : _grade), 1, 5), autoClose: (_q[$ "auto_close"] == true),
        sounds: { move: -1, take: -1, sow: -1, pick: -1, refuse: -1, win: -1, lose: -1 }, boardInfo: undefined
    };
    _T.R = tpr__layout_panel(_T.L);
    // the background (table, board, trays) and the opponent's card, drawn once
    _T.bg = tpr__bake(TPR_W, TPR_H, 0, 0, tpr__pnt_background, { T: _T });
    _T.card = tpr__bake(_T.R.card.w + 24, _T.R.card.h + 24, 0, 0, tpr__pnt_card, { w: _T.R.card.w, h: _T.R.card.h, info: tpr__card_info(_T) });
    var _P = _T.R.plaques, _pw = (_P.cols == 3) ? floor((_P.w - _P.gap * 2) / 3) : _P.w;
    _T.pr = [];
    for (var _k = 0; _k < 3; _k++) array_push(_T.pr, (_P.cols == 3) ? { x: _P.x + _k * (_pw + _P.gap), y: _P.y, w: _pw, h: _P.h } : { x: _P.x, y: _P.y + _k * (_P.h + _P.gap), w: _P.w, h: _P.h });
    tpr__create_men(_T);
    return _T;
}

/// panel rectangles: board left + panel right, or board on top + panel below
function tpr__layout_panel(_L) {
    var _P = _L.panel, _R = {};
    if (_L.side == "right") {
        _R.card = { x: _P.x, y: _P.y, w: _P.w, h: 172 }; _R.theirs = { x: _P.x, y: _P.y + 180, w: _P.w, h: 124 }; _R.mine = { x: _P.x, y: _P.y + 312, w: _P.w, h: 124 };
        _R.status = { x: _P.x, y: _P.y + 444, w: _P.w, h: 60 }; _R.plaques = { x: _P.x, y: _P.y + 514, w: _P.w, h: 36, cols: 3, gap: 4 };
    } else {
        _R.card = { x: _P.x, y: _P.y, w: 224, h: _P.h }; var _bx = _P.x + 234, _bw = _P.w - 234 - 184, _hh = floor((_P.h - 56) / 2);
        _R.theirs = { x: _bx, y: _P.y, w: _bw, h: _hh }; _R.mine = { x: _bx, y: _P.y + _hh + 6, w: _bw, h: _hh };
        _R.status = { x: _bx, y: _P.y + _P.h - 44, w: _P.w - 234, h: 44 }; _R.plaques = { x: _P.x + _P.w - 174, y: _P.y, w: 174, h: 38, cols: 1, gap: 8 };
    }
    return _R;
}

/// the opponent's card: the game, the name, the grade, the stake, who moves first, the record before tonight
function tpr__card_info(_T) {
    var _g = _T.g, _me = _T.human, _you;
    if (_g == "foxgeese") _you = (_me == 0) ? "You play the fox" : "You play the geese";
    else _you = (_me == 0) ? "You move first (" + tpr__side_name(_g, 0) + ")" : "You move second (" + tpr__side_name(_g, 1) + ")";
    var _lines = [(_T.req.stake > 0) ? "Stake: " + string(_T.req.stake) + " gold" : "A friendly game", _you];
    var _rec = tpr_record(_T.req.opponent, _g);
    if (_rec.w + _rec.l + _rec.d > 0) array_push(_lines, "Before tonight: " + string(_rec.w) + " won, " + string(_rec.l) + " lost" + ((_rec.d > 0) ? ", " + string(_rec.d) + " drawn" : ""));
    return { game: tpr_game_name(_g), name: _T.req.opponent, grade: "a " + tpr_grade_name(_T.req.grade) + " (" + string(_T.req.grade) + " of 5)", lines: _lines };
}

// ---------------------------------------------------------------------------------------------------------------
// The men, the trays and the pits
// ---------------------------------------------------------------------------------------------------------------

function tpr__man_sprite(_T, _side, _seed) {
    var _r = _T.L.r, _fox = (_T.g == "foxgeese" && _side == 0), _rr = _fox ? _r * 1.22 : _r, _pad = ceil(_rr * 0.7) + 6, _sz = ceil(_rr * 2 + _pad * 2);
    return tpr__bake(_sz, _sz, _sz / 2, _sz / 2, tpr__pnt_man, { sz: _sz, r: _rr, set: _T.style.set, side: _fox ? "fox" : _side, seed: real(int64(_seed) & int64($FFFFFFFF)) });
}
function tpr__new_man(_T, _side, _seed, _x, _y) { array_push(_T.men, { spr: tpr__man_sprite(_T, _side, _seed), x: _x, y: _y, s: 1, side: _side }); return array_length(_T.men) - 1; }

function tpr__create_men(_T) {
    var _s = _T.m.state, _L = _T.L, _i;
    if (_T.g == "oware") {
        _T.vis = tpr__copy(_s.pits); _T.visStore = [0, 0];
        _T.handSpr = tpr__bake(60, 60, 30, 30, tpr__pnt_hand, { set: _T.style.set });
        return;
    }
    _T.occ = array_create(array_length(_L.pts), -1);
    for (_i = 0; _i < array_length(_s.cells); _i++) if (_s.cells[_i] >= 0) _T.occ[_i] = tpr__new_man(_T, _s.cells[_i], _T.style.seed + _i * 31, _L.pts[_i].x, _L.pts[_i].y);
    if (_T.g == "morris") for (var _side = 0; _side < 2; _side++) for (_i = 0; _i < 9; _i++) array_push(_T.hand[_side], tpr__new_man(_T, _side, _T.style.seed + 900 + _side * 50 + _i * 7, 0, 0));
    tpr__place_boxes(_T);
}
function tpr__box_of(_T, _side) { return (_side == _T.human) ? _T.R.mine : _T.R.theirs; }
/// where slot i of a box row sits. Row 0: men in hand (Morris); after it, the men that side has TAKEN
function tpr__slot(_T, _side, _kind, _i) {
    var _b = tpr__box_of(_T, _side), _r = _T.L.r;
    var _rows = 2, _per = 7, _handRows = 0;
    switch (_T.g) { case "morris": _rows = 3; _per = 7; _handRows = 2; break; case "foxgeese": _rows = 2; _per = 7; break; case "fanorona": _rows = 2; _per = 11; break; default: _rows = 1; _per = 1; }
    // a row of `per` men at pitch 2rs + 4 must fit the box's inner width
    var _sc = min(0.62, (_b.h - 30) / (_rows * 2 * _r + (_rows - 1) * 3), ((_b.w - 26) / _per - 4) / (2 * _r)), _step = _r * 2 * _sc + 4;
    var _row = (_kind == "hand") ? floor(_i / _per) : _handRows + floor(_i / _per), _col = _i mod _per;
    return { x: _b.x + 12 + _step / 2 + _col * _step, y: _b.y + 28 + _r * _sc + _row * (_r * 2 * _sc + 3), s: _sc };
}
function tpr__place_boxes(_T) {
    for (var _side = 0; _side < 2; _side++) {
        var _k, _sl;
        for (_k = 0; _k < array_length(_T.hand[_side]); _k++) { _sl = tpr__slot(_T, _side, "hand", _k); var _mh = _T.men[_T.hand[_side][_k]]; _mh.x = _sl.x; _mh.y = _sl.y; _mh.s = _sl.s; }
        for (_k = 0; _k < array_length(_T.tray[_side]); _k++) { _sl = tpr__slot(_T, _side, "tray", _k); var _mt = _T.men[_T.tray[_side][_k]]; _mt.x = _sl.x; _mt.y = _sl.y; _mt.s = _sl.s; }
    }
}
function tpr__pit_sprite(_T, _i) {
    var _L = _T.L, _n = _T.vis[_i], _padY = _L.countGap + 14, _w = ceil(_L.pitR * 2 + 12), _h = ceil((_L.pitR + _padY) * 2);
    return tpr__cached(_T, "pit:" + string(_i) + ":" + string(_n), _w, _h, _w / 2, _L.pitR + _padY, tpr__pnt_pit,
        { w: _w, h: _h, pitR: _L.pitR, n: _n, set: _T.style.set, seed: real((int64(_T.style.seed) + _i * 13 + _n) & int64($FFFFFFFF)), i: _i, gap: _L.countGap, board: _T.style.board });
}
function tpr__store_sprite(_T, _k) {
    var _st = _T.L.stores[_k], _n = _T.visStore[_k], _w = _st.w + 20, _h = _st.h + 40;
    return tpr__cached(_T, "store:" + string(_k) + ":" + string(_n), _w, _h, _w / 2, _h / 2, tpr__pnt_store,
        { w: _w, h: _h, sw: _st.w, sh: _st.h, k: _k, n: _n, pitR: _T.L.pitR, set: _T.style.set, seed: real((int64(_T.style.seed) + _k) & int64($FFFFFFFF)), board: _T.style.board });
}

// ---------------------------------------------------------------------------------------------------------------
// Turns
// ---------------------------------------------------------------------------------------------------------------

function tpr__legal(_T) { var _s = _T.m.state; if (_T.legalFor != _s) { _T.legalFor = _s; _T.legal = tpr_moves(_T.g, _s); } return _T.legal; }
function tpr__play_se(_T, _which) { var _id = _T.sounds[$ _which]; if (is_numeric(_id) && _id >= 0 && audio_exists(_id)) audio_play_sound(_id, 1, false); }

function tpr__next_turn(_T) {
    var _m = _T.m; _T.prefix = []; _T.concede = 0;
    if (is_struct(_m.over)) { tpr__finish(_T); return; }
    if (_m.state.turn == _T.human && !_T.watch) {
        _T.mode = "human"; _T.opts = tpr_options(_T.g, tpr__legal(_T), _T.prefix); tpr__build_targets(_T);
        _T.statusText = tpr__prompt(_T);
    } else {
        var _mine = (_m.state.turn == _T.human);
        _T.mode = "think"; _T.thinkFrames = 0; _T.dots = 0;
        var _ts = real((int64(_T.req.seed) ^ int64(_m.state.ply * 2654435761)) & int64($FFFFFFFF));
        _T.thinker = tpr_thinker(_T.g, _m.state, _mine ? _T.watchGrade : _T.req.grade, _ts); _T.targets = [];
        _T.thinkText = _mine ? "You study the board" : _T.req.opponent + " studies the board";
        _T.statusText = _T.thinkText;
    }
}
function tpr__prompt(_T) {
    var _g = _T.g, _p = _T.prefix, _s = _T.m.state, _o = _T.opts;
    if (is_struct(_o) && array_length(_o.next) > 0 && string_char_at(_o.next[0], 1) == "t") return "A mill! Take one of their men.";
    if (is_struct(_o) && array_length(_o.next) > 0 && string_char_at(_o.next[0], 1) == "x") return "Take which line? Click the first man of it.";
    if (is_struct(_o) && !is_undefined(_o.complete) && array_length(_o.next) > 0) return "You may take again, or Stop.";
    if (_g == "oware") return "Choose a pit on your row to sow.";
    if (_g == "morris" && array_length(_p) == 0 && _s.hand[_T.human] > 0) return "Place a man on an empty point (" + string(_s.hand[_T.human]) + " in hand).";
    if (array_length(_p) == 0) {
        if (_g == "fanorona" && is_struct(_o)) { var _lg = tpr__legal(_T); if (array_length(_lg) > 0 && _lg[0].steps[0].kind != "p") return "Your move. Taking is compulsory: pick a man that can take."; }
        return "Your move: pick up a man.";
    }
    return "Now choose where it goes (Cancel puts it back).";
}
/// rings for every click the player may make next; the keyboard cursor walks these (sorted top to bottom, left to right)
function tpr__build_targets(_T) {
    var _o = _T.opts, _L = _T.L, _t = [];
    for (var _i = 0; _i < array_length(_o.next); _i++) {
        var _tk = _o.next[_i], _p = real(string_delete(_tk, 1, 1)), _pt = _L.pts[_p];
        array_push(_t, { tk: _tk, x: _pt.x, y: _pt.y, kind: (string_char_at(_tk, 1) == "p") ? "target" : "take" });
    }
    array_sort(_t, function(_a, _b) { return (_a.y != _b.y) ? sign(_a.y - _b.y) : sign(_a.x - _b.x); });
    _T.targets = _t; if (_T.cur >= array_length(_t)) _T.cur = 0;
}
/// the point of the man currently picked up (a chain's current square), or -1
function tpr__sel_point(_T) {
    var _p = _T.prefix; if (array_length(_p) == 0 || _T.g == "oware") return -1;
    for (var _i = array_length(_p) - 1; _i >= 0; _i--) if (string_char_at(_p[_i], 1) == "p") {
        if (_T.g == "morris" && array_length(_p) == 1 && _T.m.state.hand[_T.m.state.turn] > 0) return -1;
        return real(string_delete(_p[_i], 1, 1));
    }
    return -1;
}

/// enter one click of the current move and queue its motion; false if the click is not on offer
function tpr__enter(_T, _tk) {
    var _legal = tpr__legal(_T), _o = tpr_options(_T.g, _legal, _T.prefix);
    if (tpr__index_of(_o.next, _tk) < 0) return false;
    var _before = tpr__copy(_T.prefix); array_push(_T.prefix, _tk); tpr__queue_ops(_T, _before, _tk, _legal);
    return true;
}
function tpr__queue_ops(_T, _before, _tk, _legal) {
    var _g = _T.g, _s = _T.m.state, _side = _s.turn, _L = _T.L, _p = real(string_delete(_tk, 1, 1)), _ref = undefined, _pre = _T.prefix, _i, _k;
    for (_i = 0; _i < array_length(_legal) && is_undefined(_ref); _i++) {
        var _t = tpr_tokens(_g, _legal[_i]), _ok = array_length(_t) >= array_length(_pre);
        for (_k = 0; _ok && _k < array_length(_pre); _k++) if (_t[_k] != _pre[_k]) _ok = false;
        if (_ok) _ref = _legal[_i];
    }
    if (_g == "oware") { tpr__queue_sow(_T, _p, _side); return; }
    var _isPick = (array_length(_before) == 0) && !(_g == "morris" && _s.hand[_side] > 0);
    if (_isPick) { tpr__play_se(_T, "pick"); array_push(_T.q, { kind: "wait", frames: 4 }); return; }
    var _c0 = string_char_at(_tk, 1);
    if (_c0 == "p") {
        if (_g == "morris" && array_length(_before) == 0) { var _mi = array_pop(_T.hand[_side]); tpr__slide(_T, _mi, _L.pts[_p].x, _L.pts[_p].y, 1, 16); _T.occ[_p] = _mi; return; }
        var _cur = tpr__chain_point(_before), _mm = _T.occ[_cur]; _T.occ[_cur] = -1; _T.occ[_p] = _mm; tpr__slide(_T, _mm, _L.pts[_p].x, _L.pts[_p].y, 1, 12);
        if (_g == "foxgeese") { var _T0 = tpr__t(), _a = _T0.fxy[_cur], _b = _T0.fxy[_p]; if (abs(_a[0] - _b[0]) + abs(_a[1] - _b[1]) == 2) tpr__take(_T, tpr__fat((_a[0] + _b[0]) / 2, (_a[1] + _b[1]) / 2), _side, 0); }
        return;
    }
    if (_c0 == "t") { tpr__take(_T, _p, _side, 0); return; }
    // "x": the Fanorona step just made takes the line starting at p
    var _step = _ref.steps[tpr__step_index(_pre)];
    for (_k = 0; _k < array_length(_step.take); _k++) tpr__take(_T, _step.take[_k], _side, _k * 3);
}
function tpr__step_index(_pre) { var _n = 0; for (var _i = 1; _i < array_length(_pre); _i++) if (string_char_at(_pre[_i], 1) == "p") _n++; return _n - 1; }
function tpr__chain_point(_before) { for (var _i = array_length(_before) - 1; _i >= 0; _i--) if (string_char_at(_before[_i], 1) == "p") return real(string_delete(_before[_i], 1, 1)); return -1; }
/// a man taken: lifted off the board and laid in the taker's box
function tpr__take(_T, _p, _taker, _delay) {
    var _mi = _T.occ[_p]; if (_mi < 0) return;
    _T.occ[_p] = -1; array_push(_T.tray[_taker], _mi);
    var _sl = tpr__slot(_T, _taker, "tray", array_length(_T.tray[_taker]) - 1);
    if (_delay > 0) array_push(_T.q, { kind: "wait", frames: _delay });
    array_push(_T.q, { kind: "move", man: _mi, x: _sl.x, y: _sl.y, s: _sl.s, frames: 16, lift: 1, se: "take", seAtEnd: false });
}
function tpr__slide(_T, _mi, _x, _y, _s, _frames) { array_push(_T.q, { kind: "move", man: _mi, x: _x, y: _y, s: _s, frames: _frames, lift: 1, se: "move", seAtEnd: true }); }
/// Oware: lift the pit's seeds and sow them round, one pit at a time; then the captures fly to the store
function tpr__queue_sow(_T, _pit, _side) {
    var _r = tpr__ow_sow(_T.m.state.pits, _side, _pit), _i;
    array_push(_T.q, { kind: "sow_lift", pit: _pit });
    for (_i = 0; _i < array_length(_r.path); _i++) array_push(_T.q, { kind: "sow_to", pit: _r.path[_i], frames: 6 });
    array_push(_T.q, { kind: "hand_off" });
    for (_i = 0; _i < array_length(_r.caps); _i++) { array_push(_T.q, { kind: "cap_lift", pit: _r.caps[_i], frames: 6 }); array_push(_T.q, { kind: "cap_store", side: _side, frames: 14 }); }
}

// ---------------------------------------------------------------------------------------------------------------
// Per frame
// ---------------------------------------------------------------------------------------------------------------

/// @function tpr_table_step(table, [mouse_x], [mouse_y])
/// @description Run one frame: read the input (mouse in GUI coordinates unless you pass your own, relative to where you
/// draw the table), think, animate. Call it every Step until tpr_table_closed.
function tpr_table_step(_T, _mx = undefined, _my = undefined) {
    if (!is_struct(_T) || _T.closed) return;
    _T.frame++;
    tpr__trim_cache(_T);
    var _gx = is_numeric(_mx) ? _mx : device_mouse_x_to_gui(0), _gy = is_numeric(_my) ? _my : device_mouse_y_to_gui(0), _k = (_T.scale > 0) ? _T.scale : 1;
    _T.inp = tpr__input(_T, (_gx - _T.x) / _k, (_gy - _T.y) / _k);
    // scripted input (a tutorial, a replay, a test): table.inject = { x, y, click, ok, ... } in TABLE coordinates, used once
    var _ij = _T[$ "inject"];
    if (is_struct(_ij)) {
        var _f = ["x", "y", "click", "rclick", "ok", "cancel", "shift", "pagedown", "left", "right", "up", "down"];
        for (var _i = 0; _i < array_length(_f); _i++) _T.inp[$ _f[_i]] = is_undefined(_ij[$ _f[_i]]) ? ((_i < 2) ? -1000 : false) : _ij[$ _f[_i]];
        _T.inject = undefined;
    }
    if (_T.mode == "start") { tpr__next_turn(_T); return; }
    if (array_length(_T.q) > 0) { tpr__update_queue(_T); return; }
    switch (_T.mode) {
        case "anim": tpr__after_token(_T); break;
        case "human": tpr__update_human(_T); break;
        case "think": tpr__update_think(_T); break;
        case "ai": tpr__ai_next(_T); break;
        case "reveal": _T.anim++; _T.verdictA = min(1, _T.anim * 11 / 255); if (_T.anim >= 24) _T.mode = "done"; break;
        case "done": _T.anim++; if (_T.inp.ok || _T.inp.cancel || _T.inp.click || _T.inp.rclick || (_T.autoClose && _T.anim >= 90)) { _T.mode = "gone"; _T.closed = true; } break;
    }
}
/// the input this frame, in table coordinates; arrows repeat after 24 frames, every 6
function tpr__input(_T, _x, _y) {
    var _in = { x: _x, y: _y, click: mouse_check_button_pressed(mb_left), rclick: mouse_check_button_pressed(mb_right),
        ok: keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("Z")),
        cancel: keyboard_check_pressed(vk_escape) || keyboard_check_pressed(vk_backspace) || keyboard_check_pressed(ord("X")),
        shift: keyboard_check_pressed(vk_shift), pagedown: keyboard_check_pressed(vk_pagedown) || keyboard_check_pressed(ord("W")) };
    var _keys = [["left", vk_left], ["right", vk_right], ["up", vk_up], ["down", vk_down]];
    for (var _i = 0; _i < 4; _i++) {
        var _nm = _keys[_i][0], _held = keyboard_check(_keys[_i][1]);
        _T.rep[$ _nm] = _held ? _T.rep[$ _nm] + 1 : 0;
        var _n = _T.rep[$ _nm];
        _in[$ _nm] = (_n == 1) || (_n > 24 && ((_n - 24) mod 6) == 0);
    }
    return _in;
}
function tpr__trim_cache(_T) {
    var _keys = variable_struct_get_names(_T.cache);
    if (array_length(_keys) < 96) return;
    // drop the entries not drawn for the longest; deleting in Step, never in Draw (a queued draw of a deleted sprite is white)
    for (var _i = 0; _i < array_length(_keys); _i++) { var _e = _T.cache[$ _keys[_i]]; if (!_e.keep && _T.frame - _e.used > 120) { if (sprite_exists(_e.spr)) sprite_delete(_e.spr); variable_struct_remove(_T.cache, _keys[_i]); } }
}
function tpr__ease(_k) { return (_k < 0.5) ? 2 * _k * _k : 1 - power(-2 * _k + 2, 2) / 2; }
function tpr__update_queue(_T) {
    var _op = _T.q[0];
    if (!variable_struct_exists(_op, "t")) {
        _op.t = 0;
        if (_op.kind == "move") { var _m0 = _T.men[_op.man]; _op.x0 = _m0.x; _op.y0 = _m0.y; _op.s0 = _m0.s; _T.animMan = _op.man; if (!_op.seAtEnd) tpr__play_se(_T, _op.se); }
        if (_op.kind == "sow_lift") { _T.vis[_op.pit] = 0; tpr__show_hand(_T, true, _T.L.pts[_op.pit].x, _T.L.pts[_op.pit].y - 8); }
        if (_op.kind == "sow_to" || _op.kind == "cap_store") { _op.x0 = _T.hand1.x; _op.y0 = _T.hand1.y; }
        if (_op.kind == "hand_off") _T.hand1.on = false;
    }
    _op.t++;
    var _f = variable_struct_exists(_op, "frames") ? _op.frames : 0, _k = (_f > 0) ? min(1, _op.t / _f) : 1, _e = tpr__ease(_k);
    if (_op.kind == "move") {
        var _mm = _T.men[_op.man], _lift = sin(pi * _k) * 10 * _op.lift;
        _mm.x = _op.x0 + (_op.x - _op.x0) * _e; _mm.y = _op.y0 + (_op.y - _op.y0) * _e - _lift;
        _mm.s = (_op.s0 + (_op.s - _op.s0) * _e) * (1 + 0.08 * sin(pi * _k) * _op.lift);
    }
    if (_op.kind == "sow_to") { var _pt = _T.L.pts[_op.pit]; _T.hand1.x = _op.x0 + (_pt.x - _op.x0) * _e; _T.hand1.y = _op.y0 + (_pt.y - 8 - _op.y0) * _e - sin(pi * _k) * 10; }
    if (_op.kind == "cap_store") { var _st = _T.L.stores[_op.side]; _T.hand1.x = _op.x0 + (_st.x - _op.x0) * _e; _T.hand1.y = _op.y0 + (_st.y - _op.y0) * _e - sin(pi * _k) * 16; }
    if (_k >= 1) {
        array_delete(_T.q, 0, 1);
        switch (_op.kind) {
            case "move": { var _mf = _T.men[_op.man]; _mf.x = _op.x; _mf.y = _op.y; _mf.s = _op.s; _T.animMan = -1; if (_op.seAtEnd) tpr__play_se(_T, _op.se); break; }
            case "sow_to": _T.vis[_op.pit]++; tpr__play_se(_T, "sow"); break;
            case "cap_lift": { var _n = _T.vis[_op.pit]; _T.vis[_op.pit] = 0; tpr__show_hand(_T, true, _T.L.pts[_op.pit].x, _T.L.pts[_op.pit].y - 8); _T.pendingStore = _n; break; }
            case "cap_store": _T.visStore[_op.side] += _T.pendingStore; _T.hand1.on = false; tpr__play_se(_T, "take"); break;
        }
    }
}
function tpr__show_hand(_T, _on, _x, _y) { _T.hand1.on = _on; if (_on) { _T.hand1.x = _x; _T.hand1.y = _y; } }

/// after a click's motion: finish the move, wait for the next click, or take a forced line automatically
function tpr__after_token(_T) {
    var _o = tpr_options(_T.g, tpr__legal(_T), _T.prefix);
    if (!is_undefined(_o.complete) && array_length(_o.next) == 0) { tpr__commit(_T, _o.complete); return; }
    if (!is_undefined(_T.aiMove)) { _T.mode = "ai"; return; }
    if (is_undefined(_o.complete) && array_length(_o.next) == 1 && string_char_at(_o.next[0], 1) == "x") { tpr__enter(_T, _o.next[0]); _T.mode = "anim"; return; }
    _T.mode = "human"; _T.opts = _o; _T.cur = 0; tpr__build_targets(_T); _T.statusText = tpr__prompt(_T);
}
function tpr__commit(_T, _move) {
    tpr_match_play(_T.m, _move); _T.aiMove = undefined; _T.aiMark = undefined;
    var _tk = tpr_tokens(_T.g, _move); _T.last = [];
    for (var _i = 0; _i < array_length(_tk); _i++) if (string_char_at(_tk[_i], 1) == "p") array_push(_T.last, real(string_delete(_tk[_i], 1, 1)));
    if (_T.g == "oware") { _T.last = [_move.pit]; _T.vis = tpr__copy(_T.m.state.pits); _T.visStore = [_T.m.state.store[0], _T.m.state.store[1]]; }
    if (_T.g == "morris") tpr__place_boxes(_T);
    tpr__next_turn(_T);
}
function tpr__update_think(_T) {
    var _t = _T.thinker, _t0 = get_timer(), _budget = max(200, _T.thinkMs * 1000);
    _T.thinkFrames++;
    // one node at a time against the clock; the node sequence, and so the move, does not depend on this
    while (!_t.done && get_timer() - _t0 < _budget) tpr_thinker_step(_t, 1);
    var _dots = floor(_T.thinkFrames / 20) mod 4;
    if (_dots != _T.dots) { _T.dots = _dots; _T.statusText = _T.thinkText + string_copy("....", 1, _dots); }
    tpr__common_input(_T);
    if (_t.done && _T.thinkFrames >= _T.minThink) { _T.aiMove = _t.move; _T.aiTokens = tpr_tokens(_T.g, _t.move); _T.aiI = 0; _T.mode = "ai"; }
}
/// play the opponent's chosen move one click at a time, through the same motions a player's clicks make
function tpr__ai_next(_T) {
    if (_T.aiI >= array_length(_T.aiTokens)) { var _o = tpr_options(_T.g, tpr__legal(_T), _T.prefix); if (!is_undefined(_o.complete)) tpr__commit(_T, _T.aiMove); return; }
    var _tk = _T.aiTokens[_T.aiI]; _T.aiI++;
    if (array_length(_T.prefix) == 0 && _T.g != "oware" && !(_T.g == "morris" && _T.m.state.hand[_T.m.state.turn] > 0)) { _T.aiMark = real(string_delete(_tk, 1, 1)); array_push(_T.q, { kind: "wait", frames: 14 }); }
    tpr__enter(_T, _tk); _T.mode = "anim";
}
function tpr__update_human(_T) {
    var _t = _T.targets, _n = array_length(_t), _in = _T.inp;
    if (tpr__common_input(_T)) return;
    if (_T.rules) return;
    if (_n > 0) {
        var _dir = _in.left ? [-1, 0] : (_in.right ? [1, 0] : (_in.up ? [0, -1] : (_in.down ? [0, 1] : undefined)));
        if (is_array(_dir)) { _T.cur = tpr__nearest(_T, _T.cur, _dir); tpr__play_se(_T, "pick"); }
        if (_in.ok) { tpr__choose(_T, _t[_T.cur].tk); return; }
    }
    if (_in.pagedown) { tpr__press_plaque(_T, 1); return; }
    if (_in.cancel || _in.rclick) { tpr__back(_T); return; }
    if (_in.click) {
        var _rr = (_T.g == "oware") ? _T.L.pitR + 6 : _T.L.r + 8;
        for (var _k = 0; _k < _n; _k++) { var _dx = _t[_k].x - _in.x, _dy = _t[_k].y - _in.y; if (sqrt(_dx * _dx + _dy * _dy) <= _rr) { _T.cur = _k; tpr__choose(_T, _t[_k].tk); return; } }
        var _sel = tpr__sel_point(_T);
        if (_sel >= 0 && array_length(_T.prefix) == 1) { var _sx = _T.L.pts[_sel].x - _in.x, _sy = _T.L.pts[_sel].y - _in.y; if (sqrt(_sx * _sx + _sy * _sy) <= _rr) { tpr__back(_T); return; } }
    }
}
/// Rules, Stop, Concede: plaques by mouse, Shift for the rules. True if it used the frame
function tpr__common_input(_T) {
    var _in = _T.inp, _hover = -1;
    for (var _k = 0; _k < 3; _k++) { var _r = _T.pr[_k]; if (_in.x >= _r.x && _in.x < _r.x + _r.w && _in.y >= _r.y && _in.y < _r.y + _r.h) _hover = _k; }
    _T.hover = _hover;
    if (_in.shift) { tpr__toggle_rules(_T); return true; }
    if (_T.rules && (_in.ok || _in.cancel || (_in.click && _hover != 0))) { tpr__toggle_rules(_T); return true; }
    if (_in.click && _hover >= 0) { tpr__press_plaque(_T, _hover); return true; }
    return false;
}
function tpr__plaque_states(_T) {
    var _human = _T.mode == "human", _canStop = _human && is_struct(_T.opts) && !is_undefined(_T.opts.complete) && array_length(_T.opts.next) > 0 && array_length(_T.prefix) > 1;
    var _s0 = (_T.mode == "over" || _T.mode == "reveal" || _T.mode == "done" || _T.mode == "gone") ? "off" : (_T.rules ? "on" : "idle");
    return [_s0, _canStop ? "idle" : "off", (_human || _T.mode == "think") ? ((_T.concede > 0) ? "on" : "idle") : "off"];
}
function tpr__toggle_rules(_T) { _T.rules = !_T.rules; }
function tpr__press_plaque(_T, _k) {
    var _st = tpr__plaque_states(_T); if (_st[_k] == "off") { tpr__play_se(_T, "refuse"); return; }
    if (_k == 0) tpr__toggle_rules(_T);
    else if (_k == 1) { var _o = _T.opts; if (is_struct(_o) && !is_undefined(_o.complete)) tpr__commit(_T, _o.complete); }
    else { if (_T.concede > 0) { tpr__concede(_T); return; } _T.concede = 1; _T.statusText = "Click Concede again to give up the game" + ((_T.req.stake > 0) ? " and the stake." : "."); }
}
/// arrow keys: the nearest ringed point in that direction (by angle-weighted distance)
function tpr__nearest(_T, _from, _dir) {
    var _t = _T.targets, _a = _t[_from], _best = _from, _bd = infinity;
    for (var _i = 0; _i < array_length(_t); _i++) {
        if (_i == _from) continue;
        var _dx = _t[_i].x - _a.x, _dy = _t[_i].y - _a.y, _along = _dx * _dir[0] + _dy * _dir[1];
        if (_along <= 2) continue;
        var _across = abs(_dx * _dir[1] - _dy * _dir[0]), _d = _along + _across * 2.2;
        if (_d < _bd) { _bd = _d; _best = _i; }
    }
    return _best;
}
function tpr__choose(_T, _tk) {
    if (!tpr__enter(_T, _tk)) { tpr__play_se(_T, "refuse"); return; }
    _T.concede = 0; _T.mode = "anim"; _T.targets = [];
}
/// Cancel: put a picked-up man back (before it has moved). Once a man has moved, the move must be finished
function tpr__back(_T) {
    if (array_length(_T.prefix) == 1 && tpr__sel_point(_T) >= 0) { _T.prefix = []; _T.opts = tpr_options(_T.g, tpr__legal(_T), []); tpr__build_targets(_T); _T.statusText = tpr__prompt(_T); tpr__play_se(_T, "pick"); return; }
    if (is_struct(_T.opts) && !is_undefined(_T.opts.complete) && array_length(_T.opts.next) > 0) { tpr__commit(_T, _T.opts.complete); return; }
    tpr__play_se(_T, "refuse");
}
function tpr__concede(_T) { _T.m.over = { winner: 1 - _T.human, reason: "you conceded" }; _T.q = []; tpr__finish(_T); }

/// the end: the verdict, the record, the result for your game to read
function tpr__finish(_T) {
    var _m = _T.m, _me = _T.human, _w = _m.over.winner, _out = (_w == -1) ? 2 : ((_w == _me) ? 1 : 0), _margin = tpr_margin(_m, _me);
    if (_T.g == "foxgeese" && _out == 0) _margin = -abs((_me == 0) ? tpr__fg_geese(_m.state) : _m.state.taken);
    if (_out == 0 && _margin > 0) _margin = -_margin;
    var _rec = tpr_record(_T.req.opponent, _T.g); if (_out == 1) _rec.w++; else if (_out == 0) _rec.l++; else _rec.d++;
    var _pl = tpr__records().played; _pl[$ _T.req.key] = (is_numeric(_pl[$ _T.req.key]) ? _pl[$ _T.req.key] : 0) + 1;
    _T.result = { game: _T.g, opponent: _T.req.opponent, grade: _T.req.grade, result: _out, margin: _margin, reason: _m.over.reason, plies: _m.state.ply, stake: _T.req.stake };
    var _title = (_out == 1) ? "You win" : ((_out == 0) ? _T.req.opponent + " wins" : "A draw");
    var _unit = (_T.g == "oware") ? "seeds" : ((_T.g == "foxgeese") ? "geese" : "men");
    var _l0 = (_out == 2) ? "Honours even." : ((_T.g == "foxgeese") ? ((_me == 0) ? string(_m.state.taken) + " geese taken" : string(tpr__fg_geese(_m.state)) + " geese left") : "By " + string(abs(_margin)) + " " + _unit + ".");
    var _l1 = (_T.req.stake > 0) ? ((_out == 1) ? "You take " + string(_T.req.stake) + " gold." : ((_out == 0) ? "You pay " + string(_T.req.stake) + " gold." : "The stake goes back.")) : "No stake.";
    var _reason = string_upper(string_char_at(_m.over.reason, 1)) + string_delete(_m.over.reason, 1, 1);
    _T.verdictInfo = { game: tpr_game_name(_T.g), title: _title, sub: _reason, lines: [_l0, _l1, "Press OK to leave the table."] };
    _T.mode = "reveal"; _T.anim = 0; _T.verdictA = 0; _T.targets = []; _T.statusText = "";
    tpr__play_se(_T, (_out == 1) ? "win" : ((_out == 0) ? "lose" : "move"));
}

/// @function tpr_table_closed(table)
/// @description True once the game is over and the player has dismissed the verdict. Then read table.result:
/// { game, opponent, grade, result (1 won, 0 lost or conceded, 2 drawn), margin (in the game's own unit, negative when the
/// player lost), reason, plies, stake } - and call tpr_table_free.
/// @returns {Bool}
function tpr_table_closed(_T) { return is_struct(_T) && _T.closed; }

/// @function tpr_table_free(table)
/// @description Free every sprite the table made. Call it in Step or Clean Up (never in a Draw event).
function tpr_table_free(_T) {
    if (!is_struct(_T)) return;
    var _del = function(_s) { if (is_numeric(_s) && sprite_exists(_s)) sprite_delete(_s); };
    _del(_T[$ "bg"]); _del(_T[$ "card"]); _del(_T[$ "handSpr"]);
    for (var _i = 0; _i < array_length(_T.men); _i++) _del(_T.men[_i].spr);
    var _keys = variable_struct_get_names(_T.cache);
    for (var _k = 0; _k < array_length(_keys); _k++) _del(_T.cache[$ _keys[_k]].spr);
    _T.cache = {}; _T.men = []; _T.bg = -1; _T.card = -1; _T.handSpr = -1; _T.closed = true;
}

// ---------------------------------------------------------------------------------------------------------------
// Drawing
// ---------------------------------------------------------------------------------------------------------------

/// @function tpr_table_draw(table, [x], [y], [scale])
/// @description Draw the table with its top-left at (x, y) (default table.x, table.y) at scale (default table.scale; the
/// table is 816 x 624 at scale 1). Call in Draw or Draw GUI. The input is read relative to the same place.
function tpr_table_draw(_T, _x = undefined, _y = undefined, _scale = undefined) {
    if (!is_struct(_T) || _T.closed) return;
    if (is_numeric(_x)) _T.x = _x;
    if (is_numeric(_y)) _T.y = _y;
    if (is_numeric(_scale) && _scale > 0) _T.scale = _scale;
    var _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_multiply(matrix_build(_T.x, _T.y, 0, 0, 0, 0, _T.scale, _T.scale, 1), _mw));
    gpu_push_state();
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); gpu_set_texfilter(true);
    tpr__draw_spr(_T.bg, 0, 0, 1, 1);
    var _L = _T.L, _i;
    if (_T.g == "oware") {
        for (_i = 0; _i < 12; _i++) tpr__draw_spr(tpr__pit_sprite(_T, _i), _L.pts[_i].x, _L.pts[_i].y, 1, 1);
        for (_i = 0; _i < 2; _i++) tpr__draw_spr(tpr__store_sprite(_T, _i), _L.stores[_i].x, _L.stores[_i].y, 1, 1);
    } else {
        for (_i = 0; _i < array_length(_T.men); _i++) if (_i != _T.animMan) { var _mn = _T.men[_i]; tpr__draw_spr(_mn.spr, _mn.x, _mn.y, _mn.s, 1); }
    }
    tpr__draw_marks(_T);
    if (_T.animMan >= 0) { var _ma = _T.men[_T.animMan]; tpr__draw_spr(_ma.spr, _ma.x, _ma.y, _ma.s, 1); }
    if (_T.g == "oware" && _T.hand1.on) tpr__draw_spr(_T.handSpr, _T.hand1.x, _T.hand1.y, 1, 1);
    tpr__draw_spr(_T.card, _T.R.card.x, _T.R.card.y, 1, 1);
    tpr__draw_panel(_T);
    if (_T.rules) tpr__draw_spr(tpr__rules_sprite(_T), 0, 0, 1, 1);
    if (_T.mode == "reveal" || _T.mode == "done") tpr__draw_spr(tpr__verdict_sprite(_T), 0, 0, 1, _T.verdictA);
    gpu_pop_state();
    matrix_set(matrix_world, _mw);
}
function tpr__marker_sprite(_T, _r, _kind) {
    var _rr = floor(_r * 2 + 0.5) / 2, _sz = ceil(_rr * 2 + 12);
    return tpr__cached(_T, "keep:mark:" + _kind + ":" + string(_rr), _sz, _sz, _rr + 6, _rr + 6, tpr__pnt_marker, { r: _rr, kind: _kind });
}
function tpr__draw_marks(_T) {
    var _L = _T.L, _rr = (_T.g == "oware") ? _L.pitR + 4 : _L.r + 6, _i;
    // while the opponent lifts a man, its ring is the only mark on the board (the MZ replaces the marks with it)
    if (is_numeric(_T.aiMark) && _T.mode != "human") { tpr__draw_spr(tpr__marker_sprite(_T, _L.r + 9, "sel"), _L.pts[_T.aiMark].x, _L.pts[_T.aiMark].y, 1, 1); return; }
    if (_T.mode == "human") {
        for (_i = 0; _i < array_length(_T.targets); _i++) { var _t = _T.targets[_i]; tpr__draw_spr(tpr__marker_sprite(_T, _rr, (_i == _T.cur) ? ((_t.kind == "take") ? "take" : "sel") : _t.kind), _t.x, _t.y, 1, 1); }
        var _sel = tpr__sel_point(_T); if (_sel >= 0) tpr__draw_spr(tpr__marker_sprite(_T, _rr + 3, "sel"), _L.pts[_sel].x, _L.pts[_sel].y, 1, 1);
    }
    if (is_array(_T.last) && _T.mode != "reveal" && _T.mode != "done") for (_i = 0; _i < array_length(_T.last); _i++) { var _pl = _L.pts[_T.last[_i]]; tpr__draw_spr(tpr__marker_sprite(_T, _rr - 2, "last"), _pl.x, _pl.y, 1, 0.55); }
}
function tpr__box_label(_T, _side) {
    var _s = _T.m.state, _g = _T.g, _who = (_side == _T.human) ? "Yours" : _T.req.opponent + "'s";
    if (_g == "oware") return _who + ": " + string(_s.store[_side]) + " seeds in store";
    if (_g == "morris") return _who + ": " + string(_s.hand[_side]) + " in hand, " + string(array_length(_T.tray[_side])) + " taken";
    if (_g == "foxgeese") return (_side == 0) ? _who + " (fox): " + string(_s.taken) + " geese taken" : _who + " (geese): " + string(tpr__fg_geese(_s)) + " left, " + string(tpr__t().flock_min) + " needed";
    return _who + ": " + string(array_length(_T.tray[_side])) + " taken";
}
function tpr__draw_panel(_T) {
    var _R = _T.R, _ks = ["theirs", "mine"], _sides = [1 - _T.human, _T.human];
    for (var _i = 0; _i < 2; _i++) {
        var _b = _R[$ _ks[_i]], _txt = tpr__box_label(_T, _sides[_i]), _w = _b.w - 24;
        tpr__draw_spr(tpr__cached(_T, "label:" + string(_w) + ":" + _txt, _w + 4, 30, 0, 0, tpr__pnt_label, { w: _w, text: _txt }), _b.x + 14, _b.y + 2, 1, 1);
    }
    var _S = _R.status;
    if (_T.statusText != "") tpr__draw_spr(tpr__cached(_T, "status:" + _T.statusText, _S.w, _S.h, 0, 0, tpr__pnt_status, { w: _S.w, h: _S.h, text: _T.statusText }), _S.x, _S.y, 1, 1);
    var _st = tpr__plaque_states(_T), _labs = ["Rules", "Stop", "Concede"];
    for (var _k = 0; _k < 3; _k++) {
        var _r = _T.pr[_k], _state = (_st[_k] == "idle" && _T.hover == _k) ? "on" : _st[_k];
        tpr__draw_spr(tpr__cached(_T, "keep:plaque:" + string(_k) + ":" + _state + ":" + string(_r.w) + "x" + string(_r.h), _r.w + 10, _r.h + 10, 4, 4, tpr__pnt_plaque, { w: _r.w, h: _r.h, label: _labs[_k], state: _state }), _r.x, _r.y, 1, 1);
    }
}
function tpr__rules_sprite(_T) {
    var _bd = _T.L.board, _w = min(520, _bd.w - 20), _h = 250, _x = _bd.x + (_bd.w - _w) / 2, _y = max(8, _bd.y + (_bd.h - _h) / 2);
    return tpr__cached(_T, "keep:rules", TPR_W, TPR_H, 0, 0, tpr__pnt_cardover, { x: _x, y: _y, w: _w, h: _h, info: { game: "How to play", name: tpr_game_name(_T.g), grade: "press Shift or Rules to close", lines: tpr__rules(_T.g) } });
}
function tpr__verdict_sprite(_T) {
    var _bd = _T.L.board, _w = 440, _h = 190;
    // the verdict's { game, title, sub, lines } is set on the card as name and grade (the MZ drawVerdict maps them so)
    var _vi = _T.verdictInfo;
    return tpr__cached(_T, "keep:verdict", TPR_W, TPR_H, 0, 0, tpr__pnt_cardover, { x: _bd.x + _bd.w / 2 - _w / 2, y: _bd.y + _bd.h / 2 - _h / 2, w: _w, h: _h, info: { game: _vi.game, name: _vi.title, grade: _vi.sub, lines: _vi.lines } });
}
