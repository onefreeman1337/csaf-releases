{
  "$GMScript": "v1",
  "%Name": "tpr_table",
  "name": "tpr_table",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}