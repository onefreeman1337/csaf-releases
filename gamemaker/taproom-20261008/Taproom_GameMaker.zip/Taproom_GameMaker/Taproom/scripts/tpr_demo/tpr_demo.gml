/// tpr_demo.gml - THE TAPROOM, the demo room's logic: six regulars sit round the table, each with a game and a strength; click
/// one (or walk the arrows and press Enter) to sit down across from them. When the game ends the room comes back with your
/// record against them. Everything on screen is drawn by the package. Run by obj_tpr_demo; read it as the worked example of
/// tpr_table_open / tpr_table_step / tpr_table_draw / tpr_table_closed / tpr_table_free.
///
/// Taproom - Tavern Board Games Against an Opponent Who Thinks, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// Public functions: tpr_demo_create, tpr_demo_step, tpr_demo_draw, tpr_demo_free.

/// @function tpr_demo_regulars()
/// @description The six people in the demo's taproom: { name, game, grade, side }. Their names choose their tables: six
/// different boards and six different sets of men (marble and glass, linen and clay, lacquer and boxwood, slate and stones,
/// leather and coins, the knifed tabletop and bone - MEASURED with the MZ styleFor, Internal_Ops/_demo_names.js).
/// @returns {Array<Struct>}
function tpr_demo_regulars() {
    return [
        { name: "Old Brannoc", game: "morris", grade: 3, side: "first" },
        { name: "Rook", game: "foxgeese", grade: 2, side: "geese" },
        { name: "Captain Dray", game: "oware", grade: 4, side: "first" },
        { name: "Quintus", game: "fanorona", grade: 1, side: "first" },
        { name: "Mistress Abernathy", game: "morris", grade: 5, side: "second" },
        { name: "Master Quill", game: "foxgeese", grade: 3, side: "fox" }
    ];
}

/// @function tpr_demo_create(width, height)
/// @description The demo's state for a width x height GUI.
/// @returns {Struct}
function tpr_demo_create(_w, _h) {
    var _D = { w: _w, h: _h, regs: tpr_demo_regulars(), cur: 0, table: undefined, cards: [], bg: -1, rep: { left: 0, right: 0, up: 0, down: 0 }, dirty: true, played: 0, pending: -1, pendingFrames: 0 };
    _D.cells = [];
    var _cw = 268, _ch = 186, _gx = 22, _gy = 18, _x0 = (_w - (_cw * 3 + _gx * 2)) / 2, _y0 = 150;
    for (var _i = 0; _i < 6; _i++) array_push(_D.cells, { x: _x0 + (_i mod 3) * (_cw + _gx), y: _y0 + (_i div 3) * (_ch + _gy), w: _cw, h: _ch });
    return _D;
}

function tpr__demo_pnt_room(_c, _a) {
    tpr_draw_table(_c, _a.w, _a.h, 20261008);
    tpr__text_align(_c, 1, 0);
    _c.fill = tpr__rgb([0, 0, 0], 0.45); tpr__font(_c, 52, TPR_FACE_DISPLAY); tpr__q_text(_c, "THE TAPROOM", _a.w / 2 + 2, 84);
    _c.fill = tpr__rgb([241, 223, 180]); tpr__q_text(_c, "THE TAPROOM", _a.w / 2, 82);
    _c.fill = tpr__rgb([232, 211, 162]); tpr__font(_c, 18, TPR_FACE_BODY);
    tpr__q_text(_c, "Sit down across from someone. Every board and every man is drawn by the package.", _a.w / 2, 116);
    tpr__font(_c, 15, TPR_FACE_BODY); _c.fill = tpr__rgb([214, 190, 140]);
    tpr__q_text(_c, "Click a card, or walk the arrows and press Enter. In a game: Shift shows the rules, Esc puts a man back.", _a.w / 2, _a.h - 22);
}
function tpr__demo_pnt_card(_c, _a) { tpr_draw_placard(_c, 0, 0, _a.w, _a.h, _a.info); }

function tpr__demo_info(_r) {
    var _st = tpr_style_for(_r.name, _r.game), _rec = tpr_record(_r.name, _r.game);
    var _you = (_r.game == "foxgeese") ? ((_r.side == "fox") ? "You play the fox" : "You play the geese") : ((_r.side == "second") ? "They move first" : "You move first");
    var _l2 = (_rec.w + _rec.l + _rec.d > 0) ? "Your record: " + string(_rec.w) + " won, " + string(_rec.l) + " lost" + ((_rec.d > 0) ? ", " + string(_rec.d) + " drawn" : "") : "You have not played them yet";
    return { game: tpr_game_name(_r.game), name: _r.name, grade: "a " + tpr_grade_name(_r.grade) + ", on " + string_lower(tpr_board_info(_st.board).name), lines: [_you, _l2, "Men: " + string_lower(tpr_set_info(_st.set).name)] };
}

/// @function tpr_demo_step(demo)
/// @description One frame of the demo: the table while a game is on, the room otherwise.
function tpr_demo_step(_D) {
    if (!is_struct(_D) || !is_array(_D[$ "regs"])) return;   // not a demo: nothing to step (never a throw in the buyer's Step)
    if (is_struct(_D.table)) {
        tpr_table_step(_D.table);
        if (tpr_table_closed(_D.table)) { tpr_table_free(_D.table); _D.table = undefined; _D.dirty = true; _D.played++; }
        return;
    }
    // a regular was chosen: the "setting the board" frame has been on screen for a frame, so the table opens now (opening
    // draws every picture once and takes a few seconds - see tpr_table_open - so the player sees why the room paused)
    if (_D.pending >= 0) {
        _D.pendingFrames++;
        if (_D.pendingFrames < 2) return;
        var _r = _D.regs[_D.pending];
        _D.table = tpr_table_open({ game: _r.game, opponent: _r.name, grade: _r.grade, side: _r.side, stake: 10 * _r.grade, key: "demo|" + _r.name });
        _D.table.x = (_D.w - TPR_W) / 2; _D.table.y = (_D.h - TPR_H) / 2;
        _D.pending = -1;
        return;
    }
    if (_D.dirty) tpr__demo_rebuild(_D);
    var _mx = device_mouse_x_to_gui(0), _my = device_mouse_y_to_gui(0), _hit = -1;
    for (var _i = 0; _i < 6; _i++) { var _c = _D.cells[_i]; if (_mx >= _c.x && _mx < _c.x + _c.w && _my >= _c.y && _my < _c.y + _c.h) _hit = _i; }
    if (_hit >= 0) _D.cur = _hit;
    var _keys = [["left", vk_left, -1, 0], ["right", vk_right, 1, 0], ["up", vk_up, 0, -1], ["down", vk_down, 0, 1]];
    for (var _k = 0; _k < 4; _k++) {
        var _nm = _keys[_k][0]; _D.rep[$ _nm] = keyboard_check(_keys[_k][1]) ? _D.rep[$ _nm] + 1 : 0;
        var _n = _D.rep[$ _nm];
        if (_n == 1 || (_n > 24 && ((_n - 24) mod 6) == 0)) { var _col = (_D.cur mod 3) + _keys[_k][2], _row = (_D.cur div 3) + _keys[_k][3]; _D.cur = clamp(_row, 0, 1) * 3 + clamp(_col, 0, 2); }
    }
    if ((mouse_check_button_pressed(mb_left) && _hit >= 0) || keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space)) {
        _D.pending = _D.cur; _D.pendingFrames = 0;
    }
}
function tpr__demo_rebuild(_D) {
    // rebuilt in Step, never in Draw: deleting a sprite drawn in the same frame leaves a white box
    if (sprite_exists(_D.bg)) sprite_delete(_D.bg);
    for (var _i = 0; _i < array_length(_D.cards); _i++) if (sprite_exists(_D.cards[_i])) sprite_delete(_D.cards[_i]);
    _D.bg = tpr__bake(_D.w, _D.h, 0, 0, tpr__demo_pnt_room, { w: _D.w, h: _D.h });
    _D.cards = [];
    for (var _j = 0; _j < 6; _j++) { var _c = _D.cells[_j]; array_push(_D.cards, tpr__bake(_c.w + 24, _c.h + 24, 0, 0, tpr__demo_pnt_card, { w: _c.w, h: _c.h, info: tpr__demo_info(_D.regs[_j]) })); }
    _D.dirty = false;
}

/// @function tpr_demo_draw(demo)
/// @description Draw the demo (call in Draw GUI).
function tpr_demo_draw(_D) {
    if (!is_struct(_D) || !is_array(_D[$ "regs"])) return;
    if (is_struct(_D.table)) {
        // the room stays behind the table, dimmed, where the GUI is wider or taller than the table
        draw_clear(c_black);
        if (sprite_exists(_D.bg)) {
            gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); gpu_set_texfilter(true);
            tpr__draw_spr(_D.bg, 0, 0, 1, 1);
            gpu_pop_state();
            draw_set_alpha(0.7); draw_set_colour(c_black); draw_rectangle(0, 0, _D.w, _D.h, false); draw_set_alpha(1); draw_set_colour(c_white);
        }
        tpr_table_draw(_D.table);
        return;
    }
    if (_D.dirty) return;
    gpu_push_state();
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); gpu_set_texfilter(true);
    tpr__draw_spr(_D.bg, 0, 0, 1, 1);
    for (var _i = 0; _i < 6; _i++) {
        var _c = _D.cells[_i], _lift = (_i == _D.cur) ? -4 : 0;
        tpr__draw_spr(_D.cards[_i], _c.x, _c.y + _lift, 1, 1);
    }
    gpu_pop_state();
    var _s = _D.cells[_D.cur];
    draw_set_alpha(0.9); draw_set_colour(make_colour_rgb(250, 214, 120));
    draw_rectangle(_s.x - 3, _s.y - 7, _s.x + _s.w + 2, _s.y + _s.h - 2, true); draw_rectangle(_s.x - 4, _s.y - 8, _s.x + _s.w + 3, _s.y + _s.h - 1, true);
    draw_set_alpha(1); draw_set_colour(c_white);
    if (_D.pending >= 0) {
        // the "setting the board" frame, on screen while the table is drawn
        var _rg = _D.regs[_D.pending];
        draw_set_alpha(0.62); draw_set_colour(c_black); draw_rectangle(0, 0, _D.w, _D.h, false);
        // a solid band under the words, so the cards beneath never show through the lettering
        draw_set_alpha(0.94); draw_set_colour(make_colour_rgb(20, 12, 7)); draw_rectangle(0, _D.h / 2 - 66, _D.w, _D.h / 2 + 58, false);
        draw_set_alpha(1); draw_set_colour(make_colour_rgb(214, 170, 96));
        draw_line_width(0, _D.h / 2 - 66, _D.w, _D.h / 2 - 66, 2); draw_line_width(0, _D.h / 2 + 58, _D.w, _D.h / 2 + 58, 2);
        gpu_push_state(); gpu_set_texfilter(true);
        draw_set_halign(fa_center); draw_set_valign(fa_middle);
        draw_set_font(fnt_taproom_display_l); draw_set_colour(make_colour_rgb(241, 223, 180));
        draw_text_transformed(_D.w / 2, _D.h / 2 - 22, "SETTING THE BOARD", 0.7, 0.7, 0);
        draw_set_font(fnt_taproom_body_s); draw_set_colour(make_colour_rgb(214, 190, 140));
        draw_text(_D.w / 2, _D.h / 2 + 26, _rg.name + " sets out the men for " + tpr_game_name(_rg.game) + ".");
        draw_set_halign(fa_left); draw_set_valign(fa_top); draw_set_colour(c_white);
        gpu_pop_state();
    }
}

/// @function tpr_demo_free(demo)
function tpr_demo_free(_D) {
    if (!is_struct(_D)) return;
    if (is_struct(_D.table)) tpr_table_free(_D.table);
    if (sprite_exists(_D.bg)) sprite_delete(_D.bg);
    for (var _i = 0; _i < array_length(_D.cards); _i++) if (sprite_exists(_D.cards[_i])) sprite_delete(_D.cards[_i]);
}
