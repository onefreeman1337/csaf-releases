{
  "$GMScript": "v1",
  "%Name": "tpr_paint",
  "name": "tpr_paint",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}