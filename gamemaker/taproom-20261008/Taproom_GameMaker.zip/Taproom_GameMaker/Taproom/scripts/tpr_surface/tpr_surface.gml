/// tpr_surface.gml - Taproom's board materials as pure functions of a pixel: slate, marble, a knifed tabletop, black lacquer,
/// a linen mat, tooled leather, walnut and soapstone, each a colour field built from value noise. PURE - no engine calls.
///
/// Taproom - Tavern Board Games Against an Opponent Who Thinks, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// A port, line for line, of the RPG Maker MZ edition's TaproomDraw.js material functions (hash2, vnoise, fbm, surfaceAt),
/// held to that code by the self-test (tpr_oracle_surface).
///
/// ⛔ HOW THE BOARDS ARE PAINTED, AND WHY: on the GameMaker VM these functions cost 54-397 microseconds a pixel (MEASURED,
/// several runs) - 37 to 90 seconds for one 560 x 560 board, which the MZ edition paints per pixel. So the boards and the
/// table are painted on the GPU by shd_tpr_surface (tpr_paint_surface, tpr_paint_table): the same formulas, with ONE
/// deliberate difference - the integer hash under the noise (tpr__lhash: two permutation polynomials mod 289 and 283, every
/// step an integer below 2^24, so a 32-bit float and a double compute it identically), because GLSL ES has no integer
/// arithmetic for the MZ's Math.imul hash. tpr_surface_lt and tpr_table_lt are the CPU twins of the shader, and the
/// self-test holds the shader to them pixel by pixel; tpr_surface_at (the MZ hash) stays as the reference for the formulas.
///
/// Public functions: tpr_board_ids, tpr_board_info, tpr_surface_at, tpr_fbm, tpr_paint_surface, tpr_paint_table,
/// tpr_shader_ok.

/// @function tpr__hash2(x, y, s)
/// @description Internal. The MZ hash2: a 2-D integer hash to [0, 1) (Math.imul and >>> emulated on int64).
function tpr__hash2(_x, _y, _s) {
    // ⛔ the hot path of every material (four calls per noise sample): the four Math.imul are written out inline on int64
    // halves - the same arithmetic as tpr__imul, without four function calls (a call is most of the VM's cost per pixel)
    var _m = int64($FFFFFFFF), _l16 = int64($FFFF);
    var _a = int64(_x) & _m, _b = int64(374761393);
    var _p1 = (((_a * (_b & _l16)) & _m) + (((_a * (_b >> 16)) & _l16) << 16)) & _m;
    _a = int64(_y) & _m; _b = int64(668265263);
    var _p2 = (((_a * (_b & _l16)) & _m) + (((_a * (_b >> 16)) & _l16) << 16)) & _m;
    _a = int64(_s) & _m; _b = int64(1274126177);
    var _p3 = (((_a * (_b & _l16)) & _m) + (((_a * (_b >> 16)) & _l16) << 16)) & _m;
    var _h = (_p1 ^ _p2) ^ _p3;
    _a = _h ^ (_h >> 13); _b = int64(1103515245);
    _h = (((_a * (_b & _l16)) & _m) + (((_a * (_b >> 16)) & _l16) << 16)) & _m;
    _h = _h ^ (_h >> 16);
    return real(_h) / 4294967296;
}

/// @function tpr__vnoise(x, y, s)
/// @description Internal. Smoothed value noise at (x, y).
function tpr__vnoise(_x, _y, _s) {
    var _xi = floor(_x), _yi = floor(_y), _xf = _x - _xi, _yf = _y - _yi;
    var _u = _xf * _xf * (3 - 2 * _xf), _v = _yf * _yf * (3 - 2 * _yf);
    var _a = tpr__hash2(_xi, _yi, _s), _b = tpr__hash2(_xi + 1, _yi, _s), _c = tpr__hash2(_xi, _yi + 1, _s), _d = tpr__hash2(_xi + 1, _yi + 1, _s);
    return _a + (_b - _a) * _u + (_c - _a) * _v + (_a - _b - _c + _d) * _u * _v;
}

/// @function tpr_fbm(x, y, seed, octaves)
/// @description Fractal value noise in [0, 1]: octaves (default 4) of vnoise, each at half the weight and 2.03 times the
/// frequency of the one before.
/// @returns {Real}
function tpr_fbm(_x, _y, _s, _oct = 4) {
    if (!is_numeric(_x) || !is_numeric(_y) || !is_numeric(_s)) return 0;
    var _o = (is_numeric(_oct) && _oct >= 1) ? min(8, floor(_oct)) : 4;
    var _t = 0, _amp = 0.5, _f = 1, _n = 0;
    for (var _i = 0; _i < _o; _i++) { _t += _amp * tpr__vnoise(_x * _f, _y * _f, _s + _i * 17); _n += _amp; _amp *= 0.5; _f *= 2.03; }
    return _t / _n;
}

/// @function tpr_board_ids()
/// @description The eight board materials, in the MZ edition's order.
/// @returns {Array<String>}
function tpr_board_ids() { return ["slate", "marble", "knifed", "lacquer", "linen", "leather", "walnut", "soapstone"]; }

/// @function tpr_board_info(id)
/// @description A material's record: { name, base, line, ink, motif, edge } (colours as [r, g, b]), or undefined.
/// @returns {Struct|Undefined}
function tpr_board_info(_id) {
    static _B = {
        slate:     { name: "Slate", base: [60, 66, 76], line: "scribe", ink: [214, 218, 212], motif: "chevron", edge: [38, 42, 50] },
        marble:    { name: "Marble", base: [222, 216, 204], line: "inlay", ink: [58, 66, 62], motif: "key", edge: [176, 168, 154] },
        knifed:    { name: "Knifed tabletop", base: [132, 90, 52], line: "groove", ink: [52, 30, 16], motif: "notch", edge: [96, 62, 34] },
        lacquer:   { name: "Black lacquer", base: [26, 20, 22], line: "gilt", ink: [214, 172, 84], motif: "lozenge", edge: [120, 24, 22] },
        linen:     { name: "Linen mat", base: [212, 196, 162], line: "stitch", ink: [120, 40, 34], motif: "stitch", edge: [170, 150, 112] },
        leather:   { name: "Tooled leather", base: [118, 66, 38], line: "burn", ink: [44, 22, 12], motif: "rope", edge: [80, 42, 22] },
        walnut:    { name: "Walnut and brass", base: [96, 60, 38], line: "brass", ink: [206, 166, 92], motif: "bead", edge: [62, 38, 22] },
        soapstone: { name: "Carved soapstone", base: [150, 160, 142], line: "groove", ink: [70, 78, 66], motif: "notch", edge: [110, 120, 104] }
    };
    return is_string(_id) ? _B[$ _id] : undefined;
}

/// @function tpr__mix(a, b, t)
function tpr__mix(_a, _b, _t) { return [_a[0] + (_b[0] - _a[0]) * _t, _a[1] + (_b[1] - _a[1]) * _t, _a[2] + (_b[2] - _a[2]) * _t]; }

/// @function tpr_surface_at(id, x, y, seed)
/// @description The material's colour [r, g, b] (unclamped, unlit) at pixel (x, y). Unknown ids give [0, 0, 0].
/// @returns {Array<Real>}
function tpr_surface_at(_id, _x, _y, _s) {
    var _B = tpr_board_info(_id);
    if (!is_struct(_B) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_s)) return [0, 0, 0];
    var _b = _B.base, _n = tpr_fbm(_x / 60, _y / 60, _s, 4), _f = tpr__vnoise(_x / 3.2, _y / 3.2, _s + 99), _t, _k;
    switch (_id) {
        case "slate": _t = (_n - 0.5) * 22 + (_f - 0.5) * 8 + sin((_y + _n * 26) * 0.22) * 3; return [_b[0] + _t, _b[1] + _t, _b[2] + _t * 1.1];
        case "marble": {
            var _vv = abs(sin(_x * 0.012 + _y * 0.018 + tpr_fbm(_x / 90, _y / 90, _s + 5, 5) * 9));
            var _vein = power(1 - _vv, 14);
            var _v2 = power(1 - abs(sin(_x * 0.03 - _y * 0.011 + _n * 7)), 30);
            _t = (_n - 0.5) * 12;
            var _c = [_b[0] + _t, _b[1] + _t, _b[2] + _t];
            _c = tpr__mix(_c, [120, 134, 124], _vein * 0.7);
            return tpr__mix(_c, [150, 156, 150], _v2 * 0.45);
        }
        case "knifed": case "walnut": {
            var _g = tpr_fbm(_x / 400, _y / 16, _s + 3, 3);
            var _g2 = tpr_fbm(_x / 120, _y / 120, _s, 2);
            var _gr = sin((_y + _g * 40 + _g2 * 30) * ((_id == "walnut") ? 0.6 : 0.42));
            _k = _gr * 0.5 + 0.5;
            _t = (_n - 0.5) * 18 - power(_k, 6) * 26 + (_f - 0.5) * 6;
            return [_b[0] + _t, _b[1] + _t * 0.8, _b[2] + _t * 0.6];
        }
        case "lacquer": {
            _t = (_n - 0.5) * 8 + (_f - 0.5) * 3;
            // ⛔ an explicit double sqrt, not point_distance: point_distance differed from JavaScript's Math.hypot by 1.4e-5 px
            // here (lacquer read 21.241259653 against 21.241260368, MEASURED 2026-10-07) - far more than a last-place difference
            var _ldx = _x - 120, _ldy = _y - 90;
            var _sheen = max(0, 1 - sqrt(_ldx * _ldx + _ldy * _ldy) / 420) * 22;
            return [_b[0] + _t + _sheen, _b[1] + _t + _sheen * 0.9, _b[2] + _t + _sheen * 0.9];
        }
        case "linen": {
            var _w = (sin(_x * 2.1) * sin(_y * 2.1)) * 7;
            var _s1 = power(tpr__vnoise(_x / 2, _y / 40, _s + 7), 8) * 26;
            var _s2 = power(tpr__vnoise(_x / 40, _y / 2, _s + 8), 8) * 20;
            _t = _w - (_s1 + _s2) + (_n - 0.5) * 14;
            return [_b[0] + _t, _b[1] + _t, _b[2] + _t * 0.9];
        }
        case "leather": {
            var _peb = power(tpr__vnoise(_x / 2.4, _y / 2.4, _s + 11), 3) * 16;
            _t = (_n - 0.5) * 26 - _peb + (_f - 0.5) * 4;
            return [_b[0] + _t, _b[1] + _t * 0.8, _b[2] + _t * 0.7];
        }
        case "soapstone": {
            var _sp = (tpr__hash2(floor(_x), floor(_y), _s + 13) > 0.985) ? -30 : 0;
            _t = (_n - 0.5) * 20 + (_f - 0.5) * 6 + _sp;
            return [_b[0] + _t, _b[1] + _t, _b[2] + _t];
        }
    }
    return _b;
}

// ---------------------------------------------------------------------------------------------------------------
// The surface hash: what shd_tpr_surface computes, computed here the same way
// ---------------------------------------------------------------------------------------------------------------

/// @function tpr__lhash(ix, iy, s, k)
/// @description Internal. The hash of lattice cell (ix, iy) for seed s (a non-negative integer) at the MZ's seed delta k, in
/// [0, 1): two permutation polynomials (34v + 1) v, mod 289 and mod 283, each applied as p(p(x) + y), their results mixed
/// as fract(a / 289 + b / 283). Every intermediate is an integer below 2^24, so the shader's 32-bit floats and these doubles
/// agree exactly; only the final division differs in its last bits.
function tpr__lhash(_ix, _iy, _s, _k) {
    var _x = ((_ix + (_s mod 289) + 37 * _k) mod 289 + 289) mod 289, _y = ((_iy + ((_s div 289) mod 289) + 19 * _k) mod 289 + 289) mod 289;
    var _a = ((34 * _x + 1) * _x) mod 289;
    _a = ((_a + _y) mod 289);
    _a = ((34 * _a + 1) * _a) mod 289;
    var _x2 = ((_ix + (_s mod 283) + 41 * _k) mod 283 + 283) mod 283, _y2 = ((_iy + ((_s div 283) mod 283) + 23 * _k) mod 283 + 283) mod 283;
    var _b = ((34 * _x2 + 1) * _x2) mod 283;
    _b = ((_b + _y2) mod 283);
    _b = ((34 * _b + 1) * _b) mod 283;
    var _v = _a / 289 + _b / 283;
    return _v - floor(_v);
}

/// @function tpr__lvnoise(x, y, s, k)
function tpr__lvnoise(_x, _y, _s, _k) {
    var _xi = floor(_x), _yi = floor(_y), _xf = _x - _xi, _yf = _y - _yi;
    var _u = _xf * _xf * (3 - 2 * _xf), _v = _yf * _yf * (3 - 2 * _yf);
    var _a = tpr__lhash(_xi, _yi, _s, _k), _b = tpr__lhash(_xi + 1, _yi, _s, _k), _c = tpr__lhash(_xi, _yi + 1, _s, _k), _d = tpr__lhash(_xi + 1, _yi + 1, _s, _k);
    return _a + (_b - _a) * _u + (_c - _a) * _v + (_a - _b - _c + _d) * _u * _v;
}

/// @function tpr__lfbm(x, y, s, k, octaves)
function tpr__lfbm(_x, _y, _s, _k, _oct) {
    var _t = 0, _amp = 0.5, _f = 1, _n = 0;
    for (var _i = 0; _i < _oct; _i++) { _t += _amp * tpr__lvnoise(_x * _f, _y * _f, _s, _k + _i * 17); _n += _amp; _amp *= 0.5; _f *= 2.03; }
    return _t / _n;
}

/// @function tpr_surface_lt(id, x, y, seed)
/// @description The material's colour [r, g, b] (unclamped, unlit) at canvas point (x, y), on the LATTICE hash - the CPU
/// twin of what shd_tpr_surface paints. The formulas are tpr_surface_at's (the MZ edition's). Unknown ids give [0, 0, 0].
/// @returns {Array<Real>}
function tpr_surface_lt(_id, _x, _y, _s) {
    var _B = tpr_board_info(_id);
    if (!is_struct(_B) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_s)) return [0, 0, 0];
    var _b = _B.base, _n = tpr__lfbm(_x / 60, _y / 60, _s, 0, 4), _f = tpr__lvnoise(_x / 3.2, _y / 3.2, _s, 99), _t, _k;
    switch (_id) {
        case "slate": _t = (_n - 0.5) * 22 + (_f - 0.5) * 8 + sin((_y + _n * 26) * 0.22) * 3; return [_b[0] + _t, _b[1] + _t, _b[2] + _t * 1.1];
        case "marble": {
            var _vv = abs(sin(_x * 0.012 + _y * 0.018 + tpr__lfbm(_x / 90, _y / 90, _s, 5, 5) * 9));
            var _vein = power(1 - _vv, 14);
            var _v2 = power(1 - abs(sin(_x * 0.03 - _y * 0.011 + _n * 7)), 30);
            _t = (_n - 0.5) * 12;
            var _c = [_b[0] + _t, _b[1] + _t, _b[2] + _t];
            _c = tpr__mix(_c, [120, 134, 124], _vein * 0.7);
            return tpr__mix(_c, [150, 156, 150], _v2 * 0.45);
        }
        case "knifed": case "walnut": {
            var _g = tpr__lfbm(_x / 400, _y / 16, _s, 3, 3);
            var _g2 = tpr__lfbm(_x / 120, _y / 120, _s, 0, 2);
            var _gr = sin((_y + _g * 40 + _g2 * 30) * ((_id == "walnut") ? 0.6 : 0.42));
            _k = _gr * 0.5 + 0.5;
            _t = (_n - 0.5) * 18 - power(_k, 6) * 26 + (_f - 0.5) * 6;
            return [_b[0] + _t, _b[1] + _t * 0.8, _b[2] + _t * 0.6];
        }
        case "lacquer": {
            _t = (_n - 0.5) * 8 + (_f - 0.5) * 3;
            var _ldx = _x - 120, _ldy = _y - 90;
            var _sheen = max(0, 1 - sqrt(_ldx * _ldx + _ldy * _ldy) / 420) * 22;
            return [_b[0] + _t + _sheen, _b[1] + _t + _sheen * 0.9, _b[2] + _t + _sheen * 0.9];
        }
        case "linen": {
            var _w = (sin(_x * 2.1) * sin(_y * 2.1)) * 7;
            var _s1 = power(tpr__lvnoise(_x / 2, _y / 40, _s, 7), 8) * 26;
            var _s2 = power(tpr__lvnoise(_x / 40, _y / 2, _s, 8), 8) * 20;
            _t = _w - (_s1 + _s2) + (_n - 0.5) * 14;
            return [_b[0] + _t, _b[1] + _t, _b[2] + _t * 0.9];
        }
        case "leather": {
            var _peb = power(tpr__lvnoise(_x / 2.4, _y / 2.4, _s, 11), 3) * 16;
            _t = (_n - 0.5) * 26 - _peb + (_f - 0.5) * 4;
            return [_b[0] + _t, _b[1] + _t * 0.8, _b[2] + _t * 0.7];
        }
        case "soapstone": {
            var _sp = (tpr__lhash(floor(_x), floor(_y), _s, 13) > 0.985) ? -30 : 0;
            _t = (_n - 0.5) * 20 + (_f - 0.5) * 6 + _sp;
            return [_b[0] + _t, _b[1] + _t, _b[2] + _t];
        }
    }
    return _b;
}

/// @function tpr_table_lt(x, y, W, H, seed)
/// @description The tavern table's colour [r, g, b] (lit, unclamped) at canvas point (x, y) of a W x H table, on the
/// LATTICE hash - the CPU twin of shd_tpr_surface's table (the MZ drawTable's per-pixel part: oak planks 104 px deep, grain,
/// one knot a plank, dark seams, a warm pool of lamplight at the upper left).
/// @returns {Array<Real>}
function tpr_table_lt(_x, _y, _W, _H, _s) {
    // + 0.0001 as in the shader: never moves a row for a sample on the pixel or half-pixel grid (fractions >= 1/208)
    var _plank = 104, _row = floor((_y + 30) / _plank + 0.0001), _py = (_y + 30) - _row * _plank;
    var _off = tpr__lhash(_row, 1, _s, 0) * 900;
    var _g = tpr__lfbm((_x + _off) / 500, _py / 14, _s, _row, 3);
    var _gr = sin((_py + _g * 36) * 0.5) * 0.5 + 0.5, _knot = 0;
    var _kx = tpr__lhash(_row, 2, _s, 0) * _W, _ky = _row * _plank + _plank * 0.5 - 30;
    var _kdx = (_x - _kx) / 2.2, _kdy = _y - _ky, _kd = sqrt(_kdx * _kdx + _kdy * _kdy);
    if (_kd < 26) _knot = power(1 - _kd / 26, 2) * 38 * (0.6 + 0.4 * sin(_kd * 1.3));
    var _t = (tpr__lfbm(_x / 70, _y / 70, _s, 5, 3) - 0.5) * 22 - power(_gr, 5) * 22 - _knot;
    var _base = [98 + _t, 62 + _t * 0.8, 36 + _t * 0.6];
    if (_py < 3 || _py > _plank - 2) _base = tpr__mix(_base, [22, 12, 6], (_py < 3) ? 0.75 - _py * 0.2 : 0.55);
    var _lx = _x - _W * 0.32, _ly = _y - _H * 0.28;
    var _lamp = max(0.22, 1.12 - sqrt(_lx * _lx + _ly * _ly) / (_W * 0.78));
    return [_base[0] * _lamp, _base[1] * _lamp, _base[2] * _lamp];
}

// ---------------------------------------------------------------------------------------------------------------
// Painting on the GPU
// ---------------------------------------------------------------------------------------------------------------

/// @function tpr_shader_ok()
/// @description True when shd_tpr_surface compiled on this platform. When it did not, the boards are painted flat in their
/// base colour under the same lamp (tpr_paint_surface returns false) - the game still plays.
/// @returns {Bool}
function tpr_shader_ok() { return shader_is_compiled(shd_tpr_surface); }

/// @function tpr__paint_quad(mode, x, y, w, h, seed, clip, m, table_w, table_h)
/// @description Internal. One shader quad over canvas rect (x, y, w, h), mapped to the current target through the affine
/// m = [a, b, c, d, e, f] (canvas -> target, a canvas's matrix order); clip = [x, y, w, h, r] or undefined.
function tpr__paint_quad(_mode, _x, _y, _w, _h, _s, _clip, _m, _tw, _th) {
    static _u = undefined;
    if (is_undefined(_u)) _u = { mode: shader_get_uniform(shd_tpr_surface, "u_mode"), seed: shader_get_uniform(shd_tpr_surface, "u_seed"),
        rect: shader_get_uniform(shd_tpr_surface, "u_rect"), clip: shader_get_uniform(shd_tpr_surface, "u_clip"), clipr: shader_get_uniform(shd_tpr_surface, "u_clipr"),
        half: shader_get_uniform(shd_tpr_surface, "u_half"), table: shader_get_uniform(shd_tpr_surface, "u_table") };
    var _mm = is_array(_m) ? _m : [1, 0, 0, 1, 0, 0];
    var _k = sqrt(abs(_mm[0] * _mm[3] - _mm[1] * _mm[2]));
    if (!(_k > 0)) return false;
    var _cl = is_array(_clip) ? _clip : [_x - 4, _y - 4, _w + 8, _h + 8, 0];
    // the shader samples NO texture: the canvas point rides in the texture coordinate, so the quad is drawn with texture -1.
    // ⛔ Never bind a texture-PAGE texture here (a font's, a sprite's): MEASURED 2026-10-08 on runtime 2024.14.4.268, a
    // font's page texture (which the runtime reported as 1 x 1) made the primitive's texcoords arrive with y about 12x too
    // small, so every material was sampled at the wrong point and the clip covered only a band at the bottom. Texture -1 and
    // a standalone surface's texture both pass the coordinate through exactly (the same diagnostic, read back per pixel).
    var _tex = -1;
    gpu_push_state();
    gpu_set_texfilter(false);
    gpu_set_texrepeat(false);
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    shader_set(shd_tpr_surface);
    shader_set_uniform_f(_u.mode, _mode);
    shader_set_uniform_f(_u.seed, _s mod 289, (_s div 289) mod 289, _s mod 283, (_s div 283) mod 283);
    shader_set_uniform_f(_u.rect, _x, _y, max(1, ceil(_w)), max(1, ceil(_h)));
    shader_set_uniform_f(_u.clip, _cl[0], _cl[1], _cl[2], _cl[3]);
    shader_set_uniform_f(_u.clipr, max(0, _cl[4]), 1 / _k);
    shader_set_uniform_f(_u.half, 0.5 / _k);
    shader_set_uniform_f(_u.table, _tw, _th);
    // the quad covers the clip's box (or the rect), widened by a device pixel so the antialiased edge is inside it
    var _pad = 1 / _k, _x0 = min(_x, _cl[0]) - _pad, _y0 = min(_y, _cl[1]) - _pad, _x1 = max(_x + _w, _cl[0] + _cl[2]) + _pad, _y1 = max(_y + _h, _cl[1] + _cl[3]) + _pad;
    if (is_array(_clip)) { _x0 = _cl[0] - _pad; _y0 = _cl[1] - _pad; _x1 = _cl[0] + _cl[2] + _pad; _y1 = _cl[1] + _cl[3] + _pad; }
    draw_primitive_begin_texture(pr_trianglestrip, _tex);
    draw_vertex_texture_colour(_mm[0] * _x0 + _mm[2] * _y0 + _mm[4], _mm[1] * _x0 + _mm[3] * _y0 + _mm[5], _x0, _y0, c_white, 1);
    draw_vertex_texture_colour(_mm[0] * _x1 + _mm[2] * _y0 + _mm[4], _mm[1] * _x1 + _mm[3] * _y0 + _mm[5], _x1, _y0, c_white, 1);
    draw_vertex_texture_colour(_mm[0] * _x0 + _mm[2] * _y1 + _mm[4], _mm[1] * _x0 + _mm[3] * _y1 + _mm[5], _x0, _y1, c_white, 1);
    draw_vertex_texture_colour(_mm[0] * _x1 + _mm[2] * _y1 + _mm[4], _mm[1] * _x1 + _mm[3] * _y1 + _mm[5], _x1, _y1, c_white, 1);
    draw_primitive_end();
    shader_reset();
    gpu_pop_state();
    return true;
}

/// @function tpr_paint_surface(id, x, y, w, h, seed, [clip], [m])
/// @description Paint a board material into canvas rect (x, y, w, h) of the current target, lit by the lamp at the upper
/// left (the MZ fillSurface): the material's colour times 1.08 - 0.26 * (0.55 x/w + 0.45 y/h). clip = [x, y, w, h, radius]
/// limits it to a rounded rectangle (antialiased); m = [a, b, c, d, e, f] maps canvas to target (default identity).
/// Returns true when painted by the shader, false when the shader did not compile here (painted flat in the base colour).
/// @returns {Bool}
function tpr_paint_surface(_id, _x, _y, _w, _h, _seed, _clip = undefined, _m = undefined) {
    var _ids = tpr_board_ids(), _mode = -1;
    for (var _i = 0; _i < array_length(_ids); _i++) if (_ids[_i] == _id) _mode = _i;
    if (_mode < 0 || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_h) || !(_w > 0) || !(_h > 0)) return false;
    var _s = is_numeric(_seed) ? abs(floor(_seed)) : 0;
    if (tpr_shader_ok()) return tpr__paint_quad(_mode, _x, _y, _w, _h, _s, _clip, _m, 0, 0);
    tpr__paint_flat(tpr_board_info(_id).base, _x, _y, _w, _h, _m);
    return false;
}

/// @function tpr_paint_table(W, H, seed, [m])
/// @description Paint the tavern table over canvas rect (0, 0, W, H) of the current target: oak planks under a hanging lamp
/// (the MZ drawTable's per-pixel part; the mug rings are drawn separately). Returns as tpr_paint_surface.
/// @returns {Bool}
function tpr_paint_table(_W, _H, _seed, _m = undefined) {
    // is_numeric FIRST: comparing a string with a number throws in GML (the adversarial pass found it: "xyzzy" > 0)
    if (!is_numeric(_W) || !is_numeric(_H) || !(_W > 0) || !(_H > 0)) return false;
    var _s = is_numeric(_seed) ? abs(floor(_seed)) : 0;
    if (tpr_shader_ok()) return tpr__paint_quad(8, 0, 0, _W, _H, _s, [0, 0, _W, _H, 0], _m, _W, _H);
    tpr__paint_flat([60, 38, 22], 0, 0, _W, _H, _m);
    return false;
}

/// @function tpr__paint_flat(rgb, x, y, w, h, m)
/// @description Internal. The fallback when the shader is missing: the base colour under the lamp's two-corner gradient.
function tpr__paint_flat(_rgb, _x, _y, _w, _h, _m) {
    var _mm = is_array(_m) ? _m : [1, 0, 0, 1, 0, 0];
    var _hi = make_colour_rgb(clamp(_rgb[0] * 1.08, 0, 255), clamp(_rgb[1] * 1.08, 0, 255), clamp(_rgb[2] * 1.08, 0, 255));
    var _lo = make_colour_rgb(clamp(_rgb[0] * 0.82, 0, 255), clamp(_rgb[1] * 0.82, 0, 255), clamp(_rgb[2] * 0.82, 0, 255));
    var _mid = merge_colour(_hi, _lo, 0.5);
    draw_primitive_begin(pr_trianglestrip);
    draw_vertex_colour(_mm[0] * _x + _mm[2] * _y + _mm[4], _mm[1] * _x + _mm[3] * _y + _mm[5], _hi, 1);
    draw_vertex_colour(_mm[0] * (_x + _w) + _mm[2] * _y + _mm[4], _mm[1] * (_x + _w) + _mm[3] * _y + _mm[5], _mid, 1);
    draw_vertex_colour(_mm[0] * _x + _mm[2] * (_y + _h) + _mm[4], _mm[1] * _x + _mm[3] * (_y + _h) + _mm[5], _mid, 1);
    draw_vertex_colour(_mm[0] * (_x + _w) + _mm[2] * (_y + _h) + _mm[4], _mm[1] * (_x + _w) + _mm[3] * (_y + _h) + _mm[5], _lo, 1);
    draw_primitive_end();
}
