{
  "$GMScript": "v1",
  "%Name": "tpr_surface",
  "name": "tpr_surface",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}