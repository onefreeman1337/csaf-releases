/// tpr_core.gml - Taproom's rules and the opponent who plays them: four historic tavern board games and an alpha-beta
/// search that runs a slice at a time. PURE GML - no rooms, layers, sprites, surfaces or instances are touched.
///
/// Taproom - Tavern Board Games Against an Opponent Who Thinks, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// A port, line for line, of the RPG Maker MZ edition's TaproomCore.js, held to that code by the self-test (tpr_oracle_core):
/// every move list, every applied move, every result and evaluation along 16 playouts, and the opponent's chosen move,
/// score and node count at every grade it is checked at.
///
/// THE GAMES ("morris", "foxgeese", "oware", "fanorona")
///   morris    Nine Men's Morris: place nine men each, make a row of three (a mill) to take one of the other side's men,
///             then move along the lines; down to three men you may fly. Win by leaving the other side two men or no move.
///   foxgeese  Fox and Geese: one fox (side 0) against thirteen geese (side 1) on the cross board.
///   oware     Oware (abapa): twelve pits, forty-eight seeds; first to 25.
///   fanorona  Fanorona: 22 men each on a 5 x 9 board; capture by approach or withdrawal, chains, taking is compulsory.
///
/// Public functions (each documented below): tpr_game_init, tpr_moves, tpr_apply, tpr_result, tpr_evaluate, tpr_tokens,
/// tpr_options, tpr_thinker, tpr_thinker_step, tpr_best_move, tpr_match_new, tpr_match_play, tpr_margin, tpr_hash.
///
/// ⛔ PORTING NOTES (the JS this must equal): Math.imul is emulated on int64 halves (a full 32 x 32 product overflows
/// int64); every 32-bit value is kept UNSIGNED in an int64 and masked; Math.round is floor(x + 0.5); the move order is a
/// STABLE sort on (key, index), done here as one numeric sort on key * 100000 + index (unique, so stability is moot).

#macro TPR_WIN 100000

// ---------------------------------------------------------------------------------------------------------------
// Hash and generator (bit-exact with the MZ edition)
// ---------------------------------------------------------------------------------------------------------------

/// @function tpr__imul(a, b)
/// @description Internal. JS Math.imul(a, b) >>> 0 on unsigned 32-bit values held in int64.
function tpr__imul(_a, _b) {
    var _m = int64($FFFFFFFF);
    _a = int64(_a) & _m; _b = int64(_b) & _m;
    var _lo = (_a * (_b & int64($FFFF))) & _m;
    var _hi = ((_a * (_b >> 16)) & int64($FFFF)) << 16;
    return (_lo + _hi) & _m;
}

/// @function tpr_hash(text)
/// @description A stable unsigned 32-bit FNV-1a hash of a string (as the MZ edition). Seeds and test digests use it.
/// @param {String} text
/// @returns {Real} 0 .. 4294967295
function tpr_hash(_s) {
    var _t = is_string(_s) ? _s : string(_s);
    var _h = int64(2166136261);
    var _n = string_byte_length(_t);
    for (var _i = 1; _i <= _n; _i++) { _h = _h ^ int64(string_byte_at(_t, _i)); _h = tpr__imul(_h, 16777619); }
    return real(_h);
}

/// @function tpr__rng(seed)
/// @description Internal. The MZ edition's generator (a mulberry32 variant) as a struct { a }; draw with tpr__rng_next.
function tpr__rng(_seed) { return { a: int64(_seed) & int64($FFFFFFFF) }; }

/// @function tpr__rng_next(rng)
/// @description Internal. The next draw in [0, 1).
function tpr__rng_next(_r) {
    var _m = int64($FFFFFFFF);
    _r.a = (_r.a + int64($6D2B79F5)) & _m;
    var _t = _r.a;
    _t = tpr__imul(_t ^ (_t >> 15), _t | 1);
    var _x = tpr__imul(_t ^ (_t >> 7), _t | 61);
    _t = _t ^ ((_t + _x) & _m);
    return real((_t ^ (_t >> 14)) & _m) / 4294967296;
}

// ---------------------------------------------------------------------------------------------------------------
// The boards' fixed tables
// ---------------------------------------------------------------------------------------------------------------

/// @function tpr__t()
/// @description Internal. Every fixed table of the four boards and the opponent's grades, built once.
function tpr__t() {
    static _T = undefined;
    if (!is_undefined(_T)) return _T;
    _T = {};
    // Nine Men's Morris: points 0..23 on three nested squares, XY on a 7 x 7 lattice
    _T.mxy = [[0, 0], [3, 0], [6, 0], [1, 1], [3, 1], [5, 1], [2, 2], [3, 2], [4, 2], [0, 3], [1, 3], [2, 3], [4, 3], [5, 3], [6, 3], [2, 4], [3, 4], [4, 4], [1, 5], [3, 5], [5, 5], [0, 6], [3, 6], [6, 6]];
    _T.medges = [[0, 1], [1, 2], [0, 9], [9, 21], [21, 22], [22, 23], [2, 14], [14, 23], [3, 4], [4, 5], [3, 10], [10, 18], [18, 19], [19, 20], [5, 13], [13, 20], [6, 7], [7, 8], [6, 11], [11, 15], [15, 16], [16, 17], [8, 12], [12, 17], [1, 4], [4, 7], [9, 10], [10, 11], [12, 13], [13, 14], [16, 19], [19, 22]];
    _T.mmills = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9, 10, 11], [12, 13, 14], [15, 16, 17], [18, 19, 20], [21, 22, 23], [0, 9, 21], [3, 10, 18], [6, 11, 15], [1, 4, 7], [16, 19, 22], [8, 12, 17], [5, 13, 20], [2, 14, 23]];
    _T.madj = array_create(24); _T.mmillof = array_create(24);
    for (var _i = 0; _i < 24; _i++) { _T.madj[_i] = []; _T.mmillof[_i] = []; }
    for (var _e = 0; _e < array_length(_T.medges); _e++) { var _ed = _T.medges[_e]; array_push(_T.madj[_ed[0]], _ed[1]); array_push(_T.madj[_ed[1]], _ed[0]); }
    for (var _k = 0; _k < array_length(_T.mmills); _k++) for (var _q = 0; _q < 3; _q++) array_push(_T.mmillof[_T.mmills[_k][_q]], _k);
    // Fox and Geese: the 33 points of the cross board on a 7 x 7 lattice
    _T.fxy = []; _T.fidx = array_create(49, -1);
    for (var _y = 0; _y < 7; _y++) for (var _x = 0; _x < 7; _x++) { if ((_x < 2 || _x > 4) && (_y < 2 || _y > 4)) continue; _T.fidx[_y * 7 + _x] = array_length(_T.fxy); array_push(_T.fxy, [_x, _y]); }
    _T.fdirs = [[1, 0], [-1, 0], [0, 1], [0, -1]];
    _T.fedges = [];
    for (var _f = 0; _f < array_length(_T.fxy); _f++) {
        var _a = _T.fxy[_f];
        var _r = tpr__fat_in(_T, _a[0] + 1, _a[1]), _d = tpr__fat_in(_T, _a[0], _a[1] + 1);
        if (_r >= 0) array_push(_T.fedges, [_f, _r]);
        if (_d >= 0) array_push(_T.fedges, [_f, _d]);
    }
    _T.geese_start = [];
    for (var _g = 0; _g < array_length(_T.fxy); _g++) if (_T.fxy[_g][1] <= 2) array_push(_T.geese_start, _g);
    _T.fox_start = tpr__fat_in(_T, 3, 5);
    _T.flock_min = 9;
    _T.fseen = array_create(33, 0); _T.fstack = array_create(33, 0);
    // Fanorona: 5 rows x 9 columns
    _T.zxy = [];
    for (var _zy = 0; _zy < 5; _zy++) for (var _zx = 0; _zx < 9; _zx++) array_push(_T.zxy, [_zx, _zy]);
    _T.zdirs = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1], [1, -1], [-1, 1]];
    _T.zedges = [];
    for (var _p = 0; _p < 45; _p++) for (var _zd = 0; _zd < 8; _zd += 2) {
        if (!(_zd < 4 || ((_T.zxy[_p][0] + _T.zxy[_p][1]) mod 2) == 0)) continue;
        var _zq = tpr__zat(_T.zxy[_p][0] + _T.zdirs[_zd][0], _T.zxy[_p][1] + _T.zdirs[_zd][1]);
        if (_zq >= 0) array_push(_T.zedges, [_p, _zq]);
    }
    _T.zmid = [1, 0, 1, 0, -1, 1, 0, 1, 0];
    // the opponent's grades (set in the MZ edition by its balance probe: each grade beats the one below)
    _T.grade_names = ["", "Novice", "Regular", "Sharp", "Hustler", "Master"];
    _T.depth = { morris: [0, 1, 2, 3, 4, 5], foxgeese: [0, 1, 2, 3, 4, 5], oware: [0, 1, 2, 4, 6, 8], fanorona: [0, 1, 2, 2, 3, 3] };
    _T.noise = [0, 260, 120, 40, 12, 0];
    _T.noise_for = { fanorona: [0, 260, 120, 40, 40, 0] };
    _T.game_ids = ["morris", "foxgeese", "oware", "fanorona"];
    return _T;
}

/// @function tpr__fat_in(tables, x, y)
/// @description Internal. The fox board point at (x, y), or -1 (used while the tables are being built).
function tpr__fat_in(_T, _x, _y) { if (_x < 0 || _y < 0 || _x > 6 || _y > 6) return -1; return _T.fidx[_y * 7 + _x]; }
/// @function tpr__fat(x, y)
function tpr__fat(_x, _y) { return tpr__fat_in(tpr__t(), _x, _y); }
/// @function tpr__zat(x, y)
function tpr__zat(_x, _y) { return (_x < 0 || _y < 0 || _x > 8 || _y > 4) ? -1 : _y * 9 + _x; }
/// @function tpr__zdir_ok(p, d)
function tpr__zdir_ok(_p, _d) { if (_d < 4) return true; var _z = tpr__t().zxy[_p]; return ((_z[0] + _z[1]) mod 2) == 0; }

/// @function tpr__copy(array)
/// @description Internal. A shallow copy of an array (JS slice()).
function tpr__copy(_a) { var _n = array_length(_a), _o = array_create(_n); array_copy(_o, 0, _a, 0, _n); return _o; }

/// @function tpr__concat1(array, value)
/// @description Internal. JS a.concat([v]): a new array with one more element.
function tpr__concat1(_a, _v) { var _n = array_length(_a), _o = array_create(_n + 1); array_copy(_o, 0, _a, 0, _n); _o[_n] = _v; return _o; }

/// @function tpr__index_of(array, value)
function tpr__index_of(_a, _v) { for (var _i = 0; _i < array_length(_a); _i++) if (_a[_i] == _v) return _i; return -1; }

// ---------------------------------------------------------------------------------------------------------------
// Nine Men's Morris (sides: 0 light, 1 dark)
// ---------------------------------------------------------------------------------------------------------------

function tpr__mo_init(_o) {
    var _fly = true;
    if (is_struct(_o) && is_bool(_o[$ "flying"]) && _o.flying == false) _fly = false;
    return { g: "morris", cells: array_create(24, -1), hand: [9, 9], turn: 0, ply: 0, quiet: 0, flying: _fly };
}
function tpr__mo_clone(_s) { return { g: "morris", cells: tpr__copy(_s.cells), hand: [_s.hand[0], _s.hand[1]], turn: _s.turn, ply: _s.ply, quiet: _s.quiet, flying: _s.flying }; }
function tpr__mo_count(_s, _side) { var _n = 0, _c = _s.cells; for (var _i = 0; _i < 24; _i++) if (_c[_i] == _side) _n++; return _n; }
function tpr__mo_in_mill(_c, _p) {
    var _T = tpr__t(), _ms = _T.mmillof[_p], _v = _c[_p];
    if (_v < 0) return false;
    for (var _k = 0; _k < array_length(_ms); _k++) { var _m = _T.mmills[_ms[_k]]; if (_c[_m[0]] == _v && _c[_m[1]] == _v && _c[_m[2]] == _v) return true; }
    return false;
}
/// men of `side` the mover may take: any not in a mill, or any at all if every one is in a mill
function tpr__mo_removable(_c, _side) {
    var _free = [], _all = [];
    for (var _i = 0; _i < 24; _i++) if (_c[_i] == _side) { array_push(_all, _i); if (!tpr__mo_in_mill(_c, _i)) array_push(_free, _i); }
    return (array_length(_free) > 0) ? _free : _all;
}
function tpr__mo_phase(_s, _side) { if (_s.hand[_side] > 0) return "place"; return (_s.flying && tpr__mo_count(_s, _side) == 3) ? "fly" : "move"; }
function tpr__mo_add(_c, _side, _opp, _from, _to, _out) {
    _c[@ _to] = _side; if (_from >= 0) _c[@ _from] = -1;
    if (tpr__mo_in_mill(_c, _to)) {
        var _rm = tpr__mo_removable(_c, _opp);
        for (var _k = 0; _k < array_length(_rm); _k++) array_push(_out, { from: _from, to: _to, take: _rm[_k] });
        if (array_length(_rm) == 0) array_push(_out, { from: _from, to: _to, take: -1 });
    } else array_push(_out, { from: _from, to: _to, take: -1 });
    _c[@ _to] = -1; if (_from >= 0) _c[@ _from] = _side;
}
function tpr__mo_moves(_s) {
    var _side = _s.turn, _opp = 1 - _side, _out = [], _ph = tpr__mo_phase(_s, _side), _c = _s.cells, _adj = tpr__t().madj;
    if (_ph == "place") { for (var _i = 0; _i < 24; _i++) if (_c[_i] < 0) tpr__mo_add(_c, _side, _opp, -1, _i, _out); }
    else for (var _i2 = 0; _i2 < 24; _i2++) {
        if (_c[_i2] != _side) continue;
        if (_ph == "fly") { for (var _j = 0; _j < 24; _j++) if (_c[_j] < 0) tpr__mo_add(_c, _side, _opp, _i2, _j, _out); }
        else for (var _t = 0; _t < array_length(_adj[_i2]); _t++) { var _j2 = _adj[_i2][_t]; if (_c[_j2] < 0) tpr__mo_add(_c, _side, _opp, _i2, _j2, _out); }
    }
    return _out;
}
function tpr__mo_apply(_s, _m) {
    var _n = tpr__mo_clone(_s), _side = _s.turn;
    if (_m.from < 0) _n.hand[_side]--; else _n.cells[_m.from] = -1;
    _n.cells[_m.to] = _side;
    if (_m.take >= 0) { _n.cells[_m.take] = -1; _n.quiet = 0; } else _n.quiet++;
    _n.turn = 1 - _side; _n.ply++;
    return _n;
}
function tpr__mo_result(_s) {
    var _side = _s.turn, _opp = 1 - _side;
    if (_s.hand[_side] == 0 && tpr__mo_count(_s, _side) < 3) return { winner: _opp, reason: "two men left" };
    if (_s.hand[_opp] == 0 && tpr__mo_count(_s, _opp) < 3) return { winner: _side, reason: "two men left" };
    if (array_length(tpr__moves_c("morris", _s)) == 0) return { winner: _opp, reason: "no move" };
    if (_s.quiet >= 60 && _s.hand[0] == 0 && _s.hand[1] == 0) return { winner: -1, reason: "thirty moves without a mill" };
    if (_s.ply >= 300) return { winner: -1, reason: "the candle burned down" };
    return undefined;
}
function tpr__mo_evaluate(_s, _side) {
    var _T = tpr__t(), _opp = 1 - _side, _c = _s.cells, _v = 0;
    _v += 120 * ((tpr__mo_count(_s, _side) + _s.hand[_side]) - (tpr__mo_count(_s, _opp) + _s.hand[_opp]));
    for (var _k = 0; _k < array_length(_T.mmills); _k++) {
        var _m = _T.mmills[_k], _a = 0, _b = 0, _e = 0;
        for (var _q = 0; _q < 3; _q++) { if (_c[_m[_q]] == _side) _a++; else if (_c[_m[_q]] == _opp) _b++; else _e++; }
        if (_a == 2 && _e == 1) _v += 14;
        if (_b == 2 && _e == 1) _v -= 16;
        if (_a == 3) _v += 6;
        if (_b == 3) _v -= 6;
    }
    var _mob = [0, 0];
    for (var _i = 0; _i < 24; _i++) { if (_c[_i] < 0) continue; var _ad = _T.madj[_i]; for (var _t = 0; _t < array_length(_ad); _t++) if (_c[_ad[_t]] < 0) _mob[_c[_i]]++; }
    if (_s.hand[_side] == 0) _v += 3 * _mob[_side];
    if (_s.hand[_opp] == 0) _v -= 3 * _mob[_opp];
    if (_s.hand[_opp] == 0 && _mob[_opp] == 0 && tpr__mo_count(_s, _opp) > 3) _v += 400;
    return _v;
}

// ---------------------------------------------------------------------------------------------------------------
// Fox and Geese (side 0 = the fox, side 1 = the geese)
// ---------------------------------------------------------------------------------------------------------------

function tpr__fg_init() {
    var _T = tpr__t(), _c = array_create(array_length(_T.fxy), -1);
    for (var _i = 0; _i < array_length(_T.geese_start); _i++) _c[_T.geese_start[_i]] = 1;
    _c[_T.fox_start] = 0;
    return { g: "foxgeese", cells: _c, turn: 1, ply: 0, taken: 0 };
}
function tpr__fg_clone(_s) { return { g: "foxgeese", cells: tpr__copy(_s.cells), turn: _s.turn, ply: _s.ply, taken: _s.taken }; }
function tpr__fg_fox(_s) { var _c = _s.cells; for (var _i = 0; _i < array_length(_c); _i++) if (_c[_i] == 0) return _i; return -1; }
function tpr__fg_geese(_s) { var _n = 0, _c = _s.cells; for (var _i = 0; _i < array_length(_c); _i++) if (_c[_i] == 1) _n++; return _n; }
/// the fox's jump chains from p (each a full path + the geese taken), depth-first; a chain may stop after any jump
function tpr__fg_jumps(_c, _p, _path, _caps, _out) {
    var _T = tpr__t(), _a = _T.fxy[_p];
    for (var _d = 0; _d < 4; _d++) {
        var _dx = _T.fdirs[_d][0], _dy = _T.fdirs[_d][1];
        var _mid = tpr__fat(_a[0] + _dx, _a[1] + _dy), _to = tpr__fat(_a[0] + 2 * _dx, _a[1] + 2 * _dy);
        if (_mid < 0 || _to < 0 || _c[_mid] != 1 || _c[_to] >= 0) continue;
        _c[@ _mid] = -1; _c[@ _p] = -1; _c[@ _to] = 0;
        var _np = tpr__concat1(_path, _to), _nc = tpr__concat1(_caps, _mid);
        array_push(_out, { path: _np, take: _nc });
        tpr__fg_jumps(_c, _to, _np, _nc, _out);
        _c[@ _to] = -1; _c[@ _p] = 0; _c[@ _mid] = 1;
    }
}
function tpr__fg_moves(_s) {
    var _T = tpr__t(), _c = _s.cells, _out = [];
    if (_s.turn == 0) {
        var _f = tpr__fg_fox(_s), _a = _T.fxy[_f];
        tpr__fg_jumps(_c, _f, [_f], [], _out);
        for (var _d = 0; _d < 4; _d++) { var _t = tpr__fat(_a[0] + _T.fdirs[_d][0], _a[1] + _T.fdirs[_d][1]); if (_t >= 0 && _c[_t] < 0) array_push(_out, { path: [_f, _t], take: [] }); }
    } else {
        for (var _i = 0; _i < array_length(_c); _i++) {
            if (_c[_i] != 1) continue;
            var _ga = _T.fxy[_i];
            for (var _gd = 0; _gd < 4; _gd++) {
                if (_T.fdirs[_gd][1] < 0) continue;   // geese never step back toward their own side
                var _gt = tpr__fat(_ga[0] + _T.fdirs[_gd][0], _ga[1] + _T.fdirs[_gd][1]);
                if (_gt >= 0 && _c[_gt] < 0) array_push(_out, { path: [_i, _gt], take: [] });
            }
        }
    }
    return _out;
}
function tpr__fg_apply(_s, _m) {
    var _n = tpr__fg_clone(_s), _from = _m.path[0], _to = _m.path[array_length(_m.path) - 1], _who = _n.cells[_from];
    _n.cells[_from] = -1; _n.cells[_to] = _who;
    for (var _k = 0; _k < array_length(_m.take); _k++) _n.cells[_m.take[_k]] = -1;
    _n.taken += array_length(_m.take); _n.turn = 1 - _s.turn; _n.ply++;
    return _n;
}
function tpr__fg_result(_s) {
    if (tpr__fg_geese(_s) < tpr__t().flock_min) return { winner: 0, reason: "too few geese to trap the fox" };
    if (array_length(tpr__moves_c("foxgeese", _s)) == 0) return (_s.turn == 0) ? { winner: 1, reason: "the fox is trapped" } : { winner: 0, reason: "the geese cannot move" };
    if (_s.ply >= 160) return { winner: 0, reason: "the geese never closed the trap" };
    return undefined;
}
function tpr__fg_evaluate(_s, _side) {
    var _T = tpr__t(), _c = _s.cells, _f = tpr__fg_fox(_s), _a = _T.fxy[_f], _g = tpr__fg_geese(_s), _mob = 0, _jumpy = 0, _adv = 0;
    for (var _d = 0; _d < 4; _d++) {
        var _t = tpr__fat(_a[0] + _T.fdirs[_d][0], _a[1] + _T.fdirs[_d][1]);
        if (_t >= 0 && _c[_t] < 0) _mob++;
        var _t2 = tpr__fat(_a[0] + 2 * _T.fdirs[_d][0], _a[1] + 2 * _T.fdirs[_d][1]);
        if (_t >= 0 && _t2 >= 0 && _c[_t] == 1 && _c[_t2] < 0) _jumpy++;
    }
    for (var _i = 0; _i < array_length(_c); _i++) if (_c[_i] == 1) { _adv += _T.fxy[_i][1]; var _back = tpr__fat(_T.fxy[_i][0], _T.fxy[_i][1] - 1); if (_back >= 0 && _c[_back] == 1) _adv += 1; }
    // the room the fox has: points it can reach over empty ground
    var _seen = _T.fseen, _stack = _T.fstack, _sp = 0, _room = 0;
    for (var _k = 0; _k < array_length(_c); _k++) _seen[@ _k] = 0;
    _stack[@ _sp] = _f; _sp += 1; _seen[@ _f] = 1;
    while (_sp > 0) {
        _sp -= 1;
        var _q = _stack[_sp]; _room++;
        var _qa = _T.fxy[_q];
        for (var _qd = 0; _qd < 4; _qd++) { var _qt = tpr__fat(_qa[0] + _T.fdirs[_qd][0], _qa[1] + _T.fdirs[_qd][1]); if (_qt >= 0 && !_seen[_qt] && _c[_qt] < 0) { _seen[@ _qt] = 1; _stack[@ _sp] = _qt; _sp += 1; } }
    }
    var _foxScore = 260 * (13 - _g) + 22 * _mob + 70 * _jumpy - 5 * _adv + 8 * _a[1] + 9 * _room;
    return (_side == 0) ? _foxScore : -_foxScore;
}

// ---------------------------------------------------------------------------------------------------------------
// Oware (pits 0..5 side 0, 6..11 side 1; sowing runs 0 -> 11 -> 0)
// ---------------------------------------------------------------------------------------------------------------

function tpr__ow_init() { return { g: "oware", pits: array_create(12, 4), store: [0, 0], turn: 0, ply: 0, quiet: 0 }; }
function tpr__ow_clone(_s) { return { g: "oware", pits: tpr__copy(_s.pits), store: [_s.store[0], _s.store[1]], turn: _s.turn, ply: _s.ply, quiet: _s.quiet }; }
function tpr__ow_own(_side, _i) { return (_side == 0) ? (_i < 6) : (_i >= 6); }
function tpr__ow_seeds_on(_pits, _side) { var _n = 0, _b = _side * 6; for (var _i = _b; _i < _b + 6; _i++) _n += _pits[_i]; return _n; }
/// sow pit `from` for `side` into a copy: { pits, taken, last, path, caps }. Skips the emptied pit on laps; a grand slam takes nothing
function tpr__ow_sow(_pits, _side, _from) {
    var _p = tpr__copy(_pits), _n = _p[_from], _i = _from, _path = [];
    _p[_from] = 0;
    while (_n > 0) { _i = (_i + 1) mod 12; if (_i == _from) continue; _p[_i]++; _n--; array_push(_path, _i); }
    var _take = 0, _j = _i, _before = tpr__copy(_p), _caps = [];
    while (!tpr__ow_own(_side, _j) && (_p[_j] == 2 || _p[_j] == 3)) { _take += _p[_j]; array_push(_caps, _j); _p[_j] = 0; _j = (_j + 11) mod 12; }
    if (_take > 0 && tpr__ow_seeds_on(_p, 1 - _side) == 0) { _p = _before; _take = 0; _caps = []; }
    return { pits: _p, taken: _take, last: _i, path: _path, caps: _caps };
}
function tpr__ow_moves(_s) {
    var _side = _s.turn, _b = _side * 6, _out = [], _starve = tpr__ow_seeds_on(_s.pits, 1 - _side) == 0;
    for (var _i = _b; _i < _b + 6; _i++) {
        if (_s.pits[_i] == 0) continue;
        if (_starve) { var _r = tpr__ow_sow(_s.pits, _side, _i); if (tpr__ow_seeds_on(_r.pits, 1 - _side) == 0) continue; }
        array_push(_out, { pit: _i });
    }
    return _out;
}
function tpr__ow_apply(_s, _m) {
    var _n = tpr__ow_clone(_s), _r = tpr__ow_sow(_s.pits, _s.turn, _m.pit);
    _n.pits = _r.pits; _n.store[_s.turn] += _r.taken; _n.quiet = (_r.taken > 0) ? 0 : _n.quiet + 1; _n.turn = 1 - _s.turn; _n.ply++;
    return _n;
}
function tpr__ow_final_stores(_s) { return [_s.store[0] + tpr__ow_seeds_on(_s.pits, 0), _s.store[1] + tpr__ow_seeds_on(_s.pits, 1)]; }
function tpr__ow_result(_s) {
    if (_s.store[0] > 24) return { winner: 0, reason: "more than half the seeds" };
    if (_s.store[1] > 24) return { winner: 1, reason: "more than half the seeds" };
    if (_s.store[0] == 24 && _s.store[1] == 24) return { winner: -1, reason: "twenty-four each" };
    var _ended = (array_length(tpr__moves_c("oware", _s)) == 0) ? "no move can feed the other row" : ((_s.quiet >= 80) ? "the seeds went round and round" : "");
    if (_ended == "") return undefined;
    var _f = tpr__ow_final_stores(_s);
    return { winner: (_f[0] > _f[1]) ? 0 : ((_f[1] > _f[0]) ? 1 : -1), reason: _ended, stores: _f };
}
function tpr__ow_evaluate(_s, _side) {
    var _opp = 1 - _side, _v = 100 * (_s.store[_side] - _s.store[_opp]), _p = _s.pits, _b = _side * 6, _o = _opp * 6;
    for (var _i = _o; _i < _o + 6; _i++) if (_p[_i] == 1 || _p[_i] == 2) _v += 12;
    for (var _j = _b; _j < _b + 6; _j++) if (_p[_j] == 1 || _p[_j] == 2) _v -= 14;
    for (var _k = _b; _k < _b + 6; _k++) if (_p[_k] >= 12) _v += 18;
    _v += 2 * (tpr__ow_seeds_on(_p, _side) - tpr__ow_seeds_on(_p, _opp));
    return _v;
}

// ---------------------------------------------------------------------------------------------------------------
// Fanorona (side 0 white on rows 3-4, side 1 black on rows 0-1)
// ---------------------------------------------------------------------------------------------------------------

function tpr__fa_init() {
    var _T = tpr__t(), _c = array_create(45, -1);
    for (var _p = 0; _p < 45; _p++) { var _y = _T.zxy[_p][1]; _c[_p] = (_y < 2) ? 1 : ((_y > 2) ? 0 : _T.zmid[_T.zxy[_p][0]]); }
    return { g: "fanorona", cells: _c, turn: 0, ply: 0, quiet: 0 };
}
function tpr__fa_clone(_s) { return { g: "fanorona", cells: tpr__copy(_s.cells), turn: _s.turn, ply: _s.ply, quiet: _s.quiet }; }
function tpr__fa_count(_s, _side) { var _n = 0, _c = _s.cells; for (var _i = 0; _i < 45; _i++) if (_c[_i] == _side) _n++; return _n; }
/// the enemy line taken by a step p -> q in direction d, by approach ("a") or withdrawal ("w")
function tpr__fa_line(_c, _p, _q, _d, _kind, _side) {
    // ⛔ hot path (the evaluation calls it for every man): the board lookup is inlined - same arithmetic as tpr__zat
    var _T = tpr__t(), _dir = _T.zdirs[_d], _dx = _dir[0], _dy = _dir[1], _x, _y, _out = [], _opp = 1 - _side;
    if (_kind == "a") { var _zq = _T.zxy[_q]; _x = _zq[0] + _dx; _y = _zq[1] + _dy; } else { var _zp = _T.zxy[_p]; _x = _zp[0] - _dx; _y = _zp[1] - _dy; _dx = -_dx; _dy = -_dy; }
    while (_x >= 0 && _y >= 0 && _x <= 8 && _y <= 4) { var _k = _y * 9 + _x; if (_c[_k] != _opp) break; array_push(_out, _k); _x += _dx; _y += _dy; }
    return _out;
}
/// capturing steps from p (one entry per approach/withdrawal choice), honouring a chain's constraints
function tpr__fa_capture_steps(_c, _p, _side, _lastDir, _visited) {
    var _T = tpr__t(), _out = [], _zp = _T.zxy[_p], _px = _zp[0], _py = _zp[1], _strong = ((_px + _py) mod 2) == 0, _dirs = _T.zdirs;
    for (var _d = 0; _d < 8; _d++) {
        if ((_d >= 4 && !_strong) || _d == _lastDir) continue;
        var _qx = _px + _dirs[_d][0], _qy = _py + _dirs[_d][1];
        if (_qx < 0 || _qy < 0 || _qx > 8 || _qy > 4) continue;
        var _q = _qy * 9 + _qx;
        if (_c[_q] >= 0 || (is_array(_visited) && tpr__index_of(_visited, _q) >= 0)) continue;
        var _ap = tpr__fa_line(_c, _p, _q, _d, "a", _side), _wd = tpr__fa_line(_c, _p, _q, _d, "w", _side);
        if (array_length(_ap) > 0) array_push(_out, { to: _q, dir: _d, kind: "a", take: _ap, from: -1 });
        if (array_length(_wd) > 0) array_push(_out, { to: _q, dir: _d, kind: "w", take: _wd, from: -1 });
    }
    return _out;
}
function tpr__fa_chains(_c, _p, _side, _lastDir, _visited, _steps, _out, _first) {
    var _st = tpr__fa_capture_steps(_c, _p, _side, _lastDir, _visited);
    for (var _k = 0; _k < array_length(_st); _k++) {
        var _s = _st[_k];
        _c[@ _p] = -1; _c[@ _s.to] = _side;
        for (var _t = 0; _t < array_length(_s.take); _t++) _c[@ _s.take[_t]] = -1;
        var _ns = tpr__concat1(_steps, _s);
        array_push(_out, { from: (array_length(_steps) > 0) ? _steps[0].from : _p, steps: _ns });
        _ns[array_length(_ns) - 1].from = _p;
        if (!_first) tpr__fa_chains(_c, _s.to, _side, _s.dir, tpr__concat1(_visited, _p), _ns, _out, false);
        for (var _t2 = 0; _t2 < array_length(_s.take); _t2++) _c[@ _s.take[_t2]] = 1 - _side;
        _c[@ _s.to] = -1; _c[@ _p] = _side;
    }
}
function tpr__fa_moves(_s) {
    var _T = tpr__t(), _c = _s.cells, _side = _s.turn, _out = [];
    for (var _p = 0; _p < 45; _p++) if (_c[_p] == _side) tpr__fa_chains(_c, _p, _side, -1, [], [], _out, _s.ply == 0);
    if (array_length(_out) > 0) return _out;   // taking is compulsory
    for (var _p2 = 0; _p2 < 45; _p2++) {
        if (_c[_p2] != _side) continue;
        for (var _d = 0; _d < 8; _d++) {
            if (!tpr__zdir_ok(_p2, _d)) continue;
            var _q = tpr__zat(_T.zxy[_p2][0] + _T.zdirs[_d][0], _T.zxy[_p2][1] + _T.zdirs[_d][1]);
            if (_q >= 0 && _c[_q] < 0) array_push(_out, { from: _p2, steps: [{ from: _p2, to: _q, dir: _d, kind: "p", take: [] }] });
        }
    }
    return _out;
}
function tpr__fa_apply(_s, _m) {
    var _n = tpr__fa_clone(_s), _c = _n.cells, _side = _s.turn, _took = 0;
    for (var _k = 0; _k < array_length(_m.steps); _k++) {
        var _st = _m.steps[_k];
        _c[_st.from] = -1; _c[_st.to] = _side;
        for (var _t = 0; _t < array_length(_st.take); _t++) { _c[_st.take[_t]] = -1; _took++; }
    }
    _n.quiet = (_took > 0) ? 0 : _n.quiet + 1; _n.turn = 1 - _side; _n.ply++;
    return _n;
}
function tpr__fa_taken(_m) { var _n = 0; for (var _k = 0; _k < array_length(_m.steps); _k++) _n += array_length(_m.steps[_k].take); return _n; }
function tpr__fa_has_move(_s) {
    var _T = tpr__t(), _c = _s.cells, _side = _s.turn;
    for (var _p = 0; _p < 45; _p++) {
        if (_c[_p] != _side) continue;
        for (var _d = 0; _d < 8; _d++) { if (!tpr__zdir_ok(_p, _d)) continue; var _q = tpr__zat(_T.zxy[_p][0] + _T.zdirs[_d][0], _T.zxy[_p][1] + _T.zdirs[_d][1]); if (_q >= 0 && _c[_q] < 0) return true; }
    }
    return false;
}
function tpr__fa_result(_s) {
    var _side = _s.turn, _opp = 1 - _side;
    if (tpr__fa_count(_s, _side) == 0) return { winner: _opp, reason: "every man taken" };
    if (tpr__fa_count(_s, _opp) == 0) return { winner: _side, reason: "every man taken" };
    if (!tpr__fa_has_move(_s)) return { winner: _opp, reason: "no move" };
    if (_s.quiet >= 50) return { winner: -1, reason: "twenty-five moves without a capture" };
    if (_s.ply >= 240) return { winner: -1, reason: "the candle burned down" };
    return undefined;
}
function tpr__fa_evaluate(_s, _side) {
    var _T = tpr__t(), _opp = 1 - _side, _c = _s.cells, _v = 100 * (tpr__fa_count(_s, _side) - tpr__fa_count(_s, _opp)), _best = [0, 0];
    for (var _p = 0; _p < 45; _p++) if (_c[_p] >= 0 && ((_T.zxy[_p][0] + _T.zxy[_p][1]) mod 2) == 0) _v += (_c[_p] == _side) ? 3 : -3;
    for (var _p2 = 0; _p2 < 45; _p2++) {
        if (_c[_p2] < 0) continue;
        var _st = tpr__fa_capture_steps(_c, _p2, _c[_p2], -1, undefined);
        for (var _k = 0; _k < array_length(_st); _k++) if (array_length(_st[_k].take) > _best[_c[_p2]]) _best[_c[_p2]] = array_length(_st[_k].take);
    }
    if (_s.turn == _side) _v += 70 * _best[_side] - 35 * _best[_opp]; else _v += 35 * _best[_side] - 70 * _best[_opp];
    return _v;
}

// ---------------------------------------------------------------------------------------------------------------
// The four games behind one door
// ---------------------------------------------------------------------------------------------------------------

/// @function tpr_game_init(game, [options])
/// @description A new game's starting state: "morris", "foxgeese", "oware" or "fanorona" (options: { flying } for morris).
/// Returns undefined for an unknown game.
/// @param {String} game
/// @param {Struct} [options]
/// @returns {Struct|Undefined}
function tpr_game_init(_g, _o = undefined) {
    switch (_g) { case "morris": return tpr__mo_init(_o); case "foxgeese": return tpr__fg_init(); case "oware": return tpr__ow_init(); case "fanorona": return tpr__fa_init(); }
    return undefined;
}
/// @function tpr_moves(game, state)
/// @description Every legal move for the side to move (an empty array for a bad call).
/// @returns {Array<Struct>}
function tpr_moves(_g, _s) {
    if (!is_struct(_s)) return [];
    switch (_g) { case "morris": return tpr__mo_moves(_s); case "foxgeese": return tpr__fg_moves(_s); case "oware": return tpr__ow_moves(_s); case "fanorona": return tpr__fa_moves(_s); }
    return [];
}
/// @function tpr_apply(game, state, move)
/// @description The state after a move (the state is never changed in place).
/// @returns {Struct}
function tpr_apply(_g, _s, _m) {
    if (!is_struct(_s) || !is_struct(_m)) return _s;
    switch (_g) { case "morris": return tpr__mo_apply(_s, _m); case "foxgeese": return tpr__fg_apply(_s, _m); case "oware": return tpr__ow_apply(_s, _m); case "fanorona": return tpr__fa_apply(_s, _m); }
    return _s;
}
/// @function tpr_result(game, state)
/// @description undefined while the game runs; { winner (0, 1 or -1 for a draw), reason } when it is over.
/// @returns {Struct|Undefined}
function tpr_result(_g, _s) {
    if (!is_struct(_s)) return undefined;
    switch (_g) { case "morris": return tpr__mo_result(_s); case "foxgeese": return tpr__fg_result(_s); case "oware": return tpr__ow_result(_s); case "fanorona": return tpr__fa_result(_s); }
    return undefined;
}
/// @function tpr_evaluate(game, state, side)
/// @description How good the position is for `side` (the opponent's own judgement).
/// @returns {Real}
function tpr_evaluate(_g, _s, _side) {
    if (!is_struct(_s) || !is_numeric(_side)) return 0;
    switch (_g) { case "morris": return tpr__mo_evaluate(_s, _side); case "foxgeese": return tpr__fg_evaluate(_s, _side); case "oware": return tpr__ow_evaluate(_s, _side); case "fanorona": return tpr__fa_evaluate(_s, _side); }
    return 0;
}
/// @function tpr__moves_c(game, state)
/// @description Internal. The state's move list, generated ONCE and kept on the state (a state is never changed after it is
/// made - tpr_apply always returns a new one), so the game-over check, the search frame and a leaf share one list.
/// ⛔ Internal only: the array is shared, so nothing may change it (tpr_moves hands a buyer a fresh one).
function tpr__moves_c(_g, _s) {
    var _mv = _s[$ "tpr_mv"];
    if (is_undefined(_mv)) {
        switch (_g) { case "morris": _mv = tpr__mo_moves(_s); break; case "foxgeese": _mv = tpr__fg_moves(_s); break; case "oware": _mv = tpr__ow_moves(_s); break; case "fanorona": _mv = tpr__fa_moves(_s); break; default: _mv = []; }
        _s.tpr_mv = _mv;
    }
    return _mv;
}

/// @function tpr__result_c(game, state)
/// @description Internal. tpr_result, computed once per state and kept on it (0 = "still running", else the result struct).
function tpr__result_c(_g, _s) {
    var _r = _s[$ "tpr_res"];
    if (is_undefined(_r)) { _r = tpr_result(_g, _s); if (is_undefined(_r)) _r = 0; _s.tpr_res = _r; }
    return is_struct(_r) ? _r : undefined;
}

/// @function tpr__order_key(game, move)
function tpr__order_key(_g, _m) {
    switch (_g) { case "morris": return (_m.take >= 0) ? 0 : 1; case "foxgeese": return -array_length(_m.take); case "fanorona": return -tpr__fa_taken(_m); }
    return 0;
}
/// @function tpr__ordered(game, moves)
/// @description Internal. The moves in search order: a stable sort on (key, index).
function tpr__ordered(_g, _list) {
    var _n = array_length(_list), _keys = array_create(_n);
    for (var _i = 0; _i < _n; _i++) _keys[_i] = (tpr__order_key(_g, _list[_i]) + 100) * 100000 + _i;
    array_sort(_keys, true);
    var _out = array_create(_n);
    for (var _j = 0; _j < _n; _j++) _out[_j] = _list[_keys[_j] mod 100000];
    return _out;
}

/// @function tpr_tokens(game, move)
/// @description A move as the clicks that make it: "p<point>" a point (or pit), "t<point>" the man taken after a mill,
/// "x<point>" the first man of the line a Fanorona step takes.
/// @returns {Array<String>}
function tpr_tokens(_g, _m) {
    var _t = [];
    if (!is_struct(_m)) return _t;
    if (_g == "morris") { if (_m.from >= 0) array_push(_t, "p" + string(_m.from)); array_push(_t, "p" + string(_m.to)); if (_m.take >= 0) array_push(_t, "t" + string(_m.take)); return _t; }
    if (_g == "foxgeese") { for (var _k = 0; _k < array_length(_m.path); _k++) array_push(_t, "p" + string(_m.path[_k])); return _t; }
    if (_g == "oware") return ["p" + string(_m.pit)];
    array_push(_t, "p" + string(_m.from));
    for (var _k2 = 0; _k2 < array_length(_m.steps); _k2++) { array_push(_t, "p" + string(_m.steps[_k2].to)); if (_m.steps[_k2].kind != "p") array_push(_t, "x" + string(_m.steps[_k2].take[0])); }
    return _t;
}

/// @function tpr__join(tokens, sep)
function tpr__join(_a, _sep) { var _s = ""; for (var _i = 0; _i < array_length(_a); _i++) _s += ((_i > 0) ? _sep : "") + _a[_i]; return _s; }

/// @function tpr_options(game, legal, prefix)
/// @description What the player may click next, given the clicks so far: { next (distinct tokens), complete (the legal move
/// those clicks already make, or undefined), matches }.
/// @returns {Struct}
function tpr_options(_g, _legal, _prefix) {
    var _next = [], _complete = undefined, _matches = 0;
    var _pre = is_array(_prefix) ? _prefix : [];
    if (!is_array(_legal)) return { next: _next, complete: _complete, matches: 0 };
    for (var _i = 0; _i < array_length(_legal); _i++) {
        var _tk = tpr_tokens(_g, _legal[_i]), _ok = array_length(_tk) >= array_length(_pre);
        for (var _k = 0; _ok && _k < array_length(_pre); _k++) if (_tk[_k] != _pre[_k]) _ok = false;
        if (!_ok) continue;
        _matches++;
        if (array_length(_tk) == array_length(_pre)) _complete = _legal[_i];
        else if (tpr__index_of(_next, _tk[array_length(_pre)]) < 0) array_push(_next, _tk[array_length(_pre)]);
    }
    return { next: _next, complete: _complete, matches: _matches };
}

// ---------------------------------------------------------------------------------------------------------------
// The opponent: alpha-beta, a slice at a time
// ---------------------------------------------------------------------------------------------------------------

/// @function tpr_thinker(game, state, grade, seed)
/// @description A search that runs a slice at a time: call tpr_thinker_step(thinker, nodes) until it returns true, then
/// read .move, .score and .nodes. The node sequence does not depend on how it is sliced, so the move is the same whether it
/// runs in one call or a thousand. grade 1..5 (Novice, Regular, Sharp, Hustler, Master) sets how far it looks and how
/// often it misjudges.
/// It deepens one ply at a time (1, 2, ... up to the grade's depth) under a NODE BUDGET per game (tpr_node_budget): when the
/// next depth would overrun it, the move of the deepest search completed is played (.capped true, .depth_done < .depth).
/// The budget counts nodes, never time, so the same position and seed always give the same move. Why: GameMaker's VM
/// searches about 2 to 20 nodes a millisecond (MEASURED), and a full-depth Master search in Morris reaches 159,564 nodes
/// (MEASURED on the MZ edition's search, node for node the same as this one) - minutes of thinking. When the full depth
/// completes, .move, .score and .nodes are exactly the MZ edition's (.nodes counts that last search; .nodes_total all).
/// @returns {Struct}
function tpr_thinker(_g, _state, _grade, _seed) {
    var _f = tpr__thinker_fixed(_g, _state, _grade, _seed);
    if (_f.done) return _f;   // a bad call, or one move or none: finished already
    return { g: _g, root: _state, side: _f.side, grade: _f.grade, seed: _seed, depth: _f.depth, d: 1, cur: undefined, nodes: 0, nodes_total: 0,
        completed_nodes: 0, depth_done: 0, capped: false, budget: tpr_node_budget(_g), done: false, move: undefined, score: 0, tpr_id: true };
}

/// @function tpr_node_budget(game)
/// @description The node budget one search may spend in this game before it stops deepening (see tpr_thinker). Chosen so
/// the worst search costs about 2.5 s of CPU on the VM at the MEASURED rates (Morris 5, Fox and Geese 4.7, Oware 18,
/// Fanorona 2.2 nodes/ms); grades 1 to 3 never reach it.
/// @returns {Real}
function tpr_node_budget(_g) {
    switch (_g) { case "morris": return 12000; case "foxgeese": return 12000; case "oware": return 40000; case "fanorona": return 5000; }
    return 12000;
}

/// @function tpr__thinker_fixed(game, state, grade, seed)
/// @description Internal. The MZ edition's search at the grade's full depth, unbudgeted (set .depth to search shallower:
/// the root moves and the misjudgement noise depend only on the grade and the seed, so every depth shares them).
function tpr__thinker_fixed(_g, _state, _grade, _seed) {
    // a bad call is a finished search with no move (never a throw in the buyer's step event)
    if (!is_string(_g) || (_g != "morris" && _g != "foxgeese" && _g != "oware" && _g != "fanorona") || !is_struct(_state) || !is_numeric(_state[$ "turn"]))
        return { g: _g, root: _state, side: 0, grade: 3, depth: 0, nodes: 0, done: true, move: undefined, score: 0, noise: [], root_moves: [], ri: 0, best: 0, best_i: 0, stack: undefined };
    var _T = tpr__t();
    var _gr = clamp(floor(is_numeric(_grade) && !is_nan(_grade) ? _grade : 3), 1, 5);
    var _th = { g: _g, root: _state, side: _state.turn, grade: _gr, depth: _T.depth[$ _g][_gr], nodes: 0, done: false, move: undefined, score: 0,
        noise: [], root_moves: [], ri: 0, best: -infinity, best_i: 0, stack: undefined };
    var _sd = int64(is_numeric(_seed) ? _seed : 0) & int64($FFFFFFFF);
    var _r = tpr__rng(_sd ^ tpr__imul(_state.ply + 1, $9E3779B1));
    _th.root_moves = tpr__ordered(_g, tpr_moves(_g, _state));
    var _nf = _T.noise_for[$ _g];
    var _nz = is_array(_nf) ? _nf[_gr] : _T.noise[_gr];
    for (var _i = 0; _i < array_length(_th.root_moves); _i++) { var _d = tpr__rng_next(_r); array_push(_th.noise, floor((_d * 2 - 1) * _nz + 0.5)); }
    if (array_length(_th.root_moves) <= 1) { _th.done = true; _th.move = (array_length(_th.root_moves) > 0) ? _th.root_moves[0] : undefined; }
    return _th;
}
function tpr__th_leaf(_th, _st, _ply) {
    var _res = tpr__result_c(_th.g, _st);
    if (is_struct(_res)) return (_res.winner < 0) ? 0 : ((_res.winner == _st.turn) ? TPR_WIN - _ply : -(TPR_WIN - _ply));
    return tpr_evaluate(_th.g, _st, _st.turn);
}
/// push a frame, or return { leaf } when the node is a leaf (the game-over check and the frame share one move list)
function tpr__th_push(_th, _st, _depth, _alpha, _beta, _ply) {
    if (_depth <= 0 || is_struct(tpr__result_c(_th.g, _st))) return { leaf: tpr__th_leaf(_th, _st, _ply) };
    array_push(_th.stack, { st: _st, ms: tpr__ordered(_th.g, tpr__moves_c(_th.g, _st)), i: 0, depth: _depth, alpha: _alpha, beta: _beta, best: -infinity, ply: _ply });
    return undefined;
}
function tpr__th_absorb(_f, _v) { if (_v > _f.best) _f.best = _v; if (_v > _f.alpha) _f.alpha = _v; }
function tpr__th_finish_root(_th, _v) {
    var _sc = _v + _th.noise[_th.ri];
    if (_sc > _th.best) { _th.best = _sc; _th.best_i = _th.ri; }
    _th.ri++; _th.stack = undefined;
}

/// @function tpr_thinker_step(thinker, budget)
/// @description Expand at most `budget` nodes; true when the move is chosen (.move, .score, .nodes).
/// @returns {Bool}
function tpr_thinker_step(_th, _budget) {
    if (!is_struct(_th)) return true;
    if (_th.done) return true;
    var _bud = (is_numeric(_budget) && _budget > 0) ? _budget : 1;
    if (_th[$ "tpr_id"] != true) return tpr__fixed_step(_th, _bud);
    // deepening under the node budget: each depth is the fixed search; depth 1 always completes (one node a root move)
    var _used = 0;
    while (_used < _bud && !_th.done) {
        if (is_undefined(_th.cur)) { _th.cur = tpr__thinker_fixed(_th.g, _th.root, _th.grade, _th.seed); _th.cur.depth = _th.d; }
        var _fin = false, _dn = 0;
        if (_th.d > 1 && _th.nodes_total >= _th.budget) {
            // the budget is spent: this depth still counts if it needs no further NODE to finish (only frames to close);
            // a probe that expands one more node means it would overrun - stop deepening, the node is not counted
            var _nb = _th.cur.nodes;
            if (tpr__fixed_step(_th.cur, 1) && _th.cur.nodes == _nb) _fin = true;
            else { _th.capped = true; _th.done = true; _th.cur = undefined; break; }
        } else {
            var _left = (_th.d == 1) ? (_bud - _used) : min(_bud - _used, _th.budget - _th.nodes_total);
            var _n0 = _th.cur.nodes;
            _fin = tpr__fixed_step(_th.cur, _left);
            _dn = _th.cur.nodes - _n0;
            _used += _dn; _th.nodes_total += _dn;
        }
        if (_fin) {
            _th.move = _th.cur.move; _th.score = _th.cur.score; _th.nodes = _th.cur.nodes; _th.depth_done = _th.d;
            _th.completed_nodes += _th.cur.nodes;
            _th.cur = undefined;
            if (_th.d >= _th.depth) { _th.done = true; break; }
            _th.d++;
        } else if (_dn <= 0) break;   // never spin: a step that expanded nothing and did not finish
    }
    return _th.done;
}

/// @function tpr__fixed_step(thinker, budget)
/// @description Internal. One slice of the fixed-depth search.
function tpr__fixed_step(_th, _bud) {
    if (_th.done) return true;
    var _n = 0;
    while (_n < _bud) {
        if (is_undefined(_th.stack)) {
            if (_th.ri >= array_length(_th.root_moves)) { _th.move = _th.root_moves[_th.best_i]; _th.score = _th.best; _th.done = true; return true; }
            _th.stack = []; _th.nodes++; _n++;
            var _child = tpr_apply(_th.g, _th.root, _th.root_moves[_th.ri]);
            var _lead = tpr__th_push(_th, _child, _th.depth - 1, -infinity, infinity, 1);
            if (is_struct(_lead)) tpr__th_finish_root(_th, -_lead.leaf);
            continue;
        }
        var _top = _th.stack[array_length(_th.stack) - 1];
        if (_top.i >= array_length(_top.ms) || _top.alpha >= _top.beta) {
            var _v = (_top.best == -infinity) ? _top.alpha : _top.best;
            array_pop(_th.stack);
            if (array_length(_th.stack) == 0) { tpr__th_finish_root(_th, -_v); continue; }
            tpr__th_absorb(_th.stack[array_length(_th.stack) - 1], -_v);
            continue;
        }
        var _m = _top.ms[_top.i]; _top.i++;
        var _ch = tpr_apply(_th.g, _top.st, _m); _th.nodes++; _n++;
        var _r = tpr__th_push(_th, _ch, _top.depth - 1, -_top.beta, -_top.alpha, _top.ply + 1);
        if (is_struct(_r)) tpr__th_absorb(_top, -_r.leaf);
    }
    return false;
}

/// @function tpr_best_move(game, state, grade, seed)
/// @description Run a search to the end in one call (for a loading screen or a test - in play, slice it with
/// tpr_thinker_step). Returns the finished thinker.
/// @returns {Struct}
function tpr_best_move(_g, _state, _grade, _seed) { var _t = tpr_thinker(_g, _state, _grade, _seed); tpr_thinker_step(_t, infinity); return _t; }

// ---------------------------------------------------------------------------------------------------------------
// A match
// ---------------------------------------------------------------------------------------------------------------

/// @function tpr_match_new(game, [options])
/// @description A match: { game, state, human (the side the player plays: options.human 1, else 0), history, over }.
/// Returns undefined for an unknown game.
/// @returns {Struct|Undefined}
function tpr_match_new(_g, _o = undefined) {
    var _s = tpr_game_init(_g, _o);
    if (!is_struct(_s)) return undefined;
    var _h = (is_struct(_o) && _o[$ "human"] == 1) ? 1 : 0;
    return { game: _g, state: _s, human: _h, history: [], over: undefined };
}

/// @function tpr_match_play(match, move)
/// @description Play a move if it is legal (matched by its click tokens): true when played, false (never a throw) for a
/// malformed or illegal move or a finished match.
/// @returns {Bool}
function tpr_match_play(_match, _move) {
    if (!is_struct(_match) || !is_struct(_move) || is_struct(_match[$ "over"]) || !is_struct(_match[$ "state"])) return false;
    var _g = _match.game, _legal = tpr_moves(_g, _match.state), _ok = undefined, _want = "";
    try { _want = tpr__join(tpr_tokens(_g, _move), " "); } catch (_e) { return false; }
    for (var _i = 0; _i < array_length(_legal); _i++) if (tpr__join(tpr_tokens(_g, _legal[_i]), " ") == _want) { _ok = _legal[_i]; break; }
    if (is_undefined(_ok)) return false;
    array_push(_match.history, _ok);
    _match.state = tpr_apply(_g, _match.state, _ok);
    _match.over = tpr_result(_g, _match.state);
    return true;
}

/// @function tpr_margin(match, side)
/// @description The margin in the game's own unit (men, geese, seeds) from `side`'s point of view.
/// @returns {Real}
function tpr_margin(_match, _side) {
    if (!is_struct(_match) || !is_struct(_match[$ "state"])) return 0;
    var _s = _match.state, _sd = (is_numeric(_side) && _side == 1) ? 1 : 0;
    switch (_match.game) {
        case "morris": return (tpr__mo_count(_s, _sd) + _s.hand[_sd]) - (tpr__mo_count(_s, 1 - _sd) + _s.hand[1 - _sd]);
        case "fanorona": return tpr__fa_count(_s, _sd) - tpr__fa_count(_s, 1 - _sd);
        case "oware": var _f = (is_struct(_match.over) && is_array(_match.over[$ "stores"])) ? _match.over.stores : _s.store; return _f[_sd] - _f[1 - _sd];
        case "foxgeese": return (_sd == 0) ? _s.taken : tpr__fg_geese(_s);
    }
    return 0;
}
