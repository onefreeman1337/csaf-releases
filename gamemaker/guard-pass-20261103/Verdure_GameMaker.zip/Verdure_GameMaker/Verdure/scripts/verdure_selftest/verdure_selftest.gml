/// ============================================================================================
/// VERDURE - vrd_selftest: RUN THE WHOLE CORPUS THROUGH THE WHOLE PIPELINE, IN THE ENGINE.
///
/// ⛔ WHY THIS SHIPS. GML cannot be unit-tested outside GameMaker - there is no headless GML
/// runner, no assertion library, and the compiler cannot see a type error. That is not a small
/// inconvenience; it is the structural verification gap in this whole engine, and it has now been
/// paid for twice IN ONE EVENING on this product alone:
///
///   1. Every plant colour in the corpus was emitted as the STRING "#ac8b3e" instead of a
///      { r, g, b } struct. The compile passed 913 resources. The first draw call died with
///      "Unable to use string as struct". 295 of 298 colours were wrong and nothing was red.
///   2. `vrd_bounds` read `.pts` off the root op, which does not have one:
///      "Variable <unknown_object>.pts(100037, -2147483648) not set before reading it."
///      Again a clean compile, again a crash on a page nobody had opened yet.
///
/// Both are the same shape: a clean gate, a beautiful contact sheet, and a product that dies the
/// moment it runs. The only instrument that can catch them is the engine itself, so this walks
/// EVERY species at EVERY stage through evaluate -> build -> bounds and checks the results.
///
/// ⚠️ IT IS ALSO FOR THE BUYER, AND THAT IS NOT A CONSOLATION PRIZE. The registry is an extension
/// point: `vrd_registry_add` lets anyone append their own species with their own stroke programs
/// and their own palette roles. The failure they will hit is EXACTLY the one above - a role that
/// no palette defines, a program that emits nothing, a bloom whose geometry is degenerate. Running
/// `vrd_selftest(reg)` after adding a species turns all of that into a line of text.
///
///   var _r = vrd_selftest(reg);
///   show_debug_message(_r.summary);        // "48 species x 6 stages - 1728 checks, 0 failed"
///
/// Pass `true` as the second argument to also write `verdure_selftest.txt` beside the executable,
/// which is how the factory's unattended capture reads the result.
/// ============================================================================================

/// One species at one growth value. Returns an array of failure strings - empty means clean.
function vrd_check_species(_sp, _t) {
    var _fail = [];
    var _where = _sp.id + " t=" + string(_t);

    /// ── the palette resolves, and resolves to COMPONENTS ─────────────────────────────────────
    /// This is check #1 above, generalised. A role whose value is a string, a number, or a struct
    /// missing a channel is the defect; `vrd_role_colour` would either crash or silently return
    /// fuchsia, and fuchsia in one leaf of one stage of one species is not something anyone spots.
    var _pal = vrd_palette_for(_sp);
    var _roles = variable_struct_get_names(_pal);
    for (var i = 0; i < array_length(_roles); i++) {
        var _v = _pal[$ _roles[i]];
        if (!is_struct(_v)) {
            array_push(_fail, _where + ": role '" + _roles[i] + "' is "
                + typeof(_v) + " (" + string(_v) + "), not a {r,g,b} struct");
            continue;
        }
        var _ch = ["r", "g", "b"];
        for (var c = 0; c < 3; c++) {
            if (!variable_struct_exists(_v, _ch[c])) {
                array_push(_fail, _where + ": role '" + _roles[i] + "' has no ." + _ch[c]);
                continue;
            }
            var _n = _v[$ _ch[c]];
            if (!is_real(_n) || _n < 0 || _n > 255) {
                array_push(_fail, _where + ": role '" + _roles[i] + "'." + _ch[c]
                    + " = " + string(_n) + ", outside 0..255");
            }
        }
    }
    if (array_length(_fail) > 0) return _fail;   // building on a bad palette only adds noise

    /// ── build, which is where a bad struct read surfaces ──────────────────────────────────────
    var _list = vrd_build(_sp, _t, 1234);
    if (!is_array(_list)) { array_push(_fail, _where + ": vrd_build did not return an array"); return _fail; }

    /// A mature plant that draws NOTHING is a silent failure, and the loudest kind: the screen just
    /// looks empty and every gate still passes. Seeds legitimately draw very little, so the floor
    /// only applies once the plant is past sprouting.
    if (_t >= 0.45 && array_length(_list) == 0) {
        array_push(_fail, _where + ": built list is EMPTY at a mature stage - nothing would draw");
    }

    /// ── bounds, which is check #2 above ───────────────────────────────────────────────────────
    var _b = vrd_bounds(_list);
    if (!is_struct(_b)) { array_push(_fail, _where + ": vrd_bounds did not return a struct"); return _fail; }
    if (!_b.empty) {
        var _nums = [_b.x1, _b.y1, _b.x2, _b.y2, _b.w, _b.h];
        var _name = ["x1", "y1", "x2", "y2", "w", "h"];
        for (var k = 0; k < 6; k++) {
            /// is_nan is not enough on its own - infinity passes it. The sentinel test catches a
            /// box that was never folded into, which is what an unhandled op would produce.
            if (!is_real(_nums[k]) || is_nan(_nums[k]) || abs(_nums[k]) >= 999999) {
                array_push(_fail, _where + ": bounds." + _name[k] + " = " + string(_nums[k]));
            }
        }
        if (_b.w < 0 || _b.h < 0) array_push(_fail, _where + ": bounds inverted, w=" + string(_b.w) + " h=" + string(_b.h));
        if (_t >= 0.45 && _b.h <= 0) array_push(_fail, _where + ": mature plant has zero height");

        /// `lift` must be non-negative and must not exceed the plant. A lift larger than the whole
        /// height would push the drawing clean off its own soil line - and since every view now
        /// draws at `soil - lift * scale`, a wrong sign here silently buries or launches the plant
        /// rather than erroring. That is the class of bug that only a captured frame catches, which
        /// is exactly why it is asserted here instead.
        if (!is_real(_b.lift) || is_nan(_b.lift)) {
            array_push(_fail, _where + ": bounds.lift = " + string(_b.lift));
        } else if (_b.lift < 0) {
            array_push(_fail, _where + ": bounds.lift is NEGATIVE (" + string(_b.lift) + ") - would bury the plant");
        } else if (_b.lift > _b.h + 0.001 && _b.h > 0) {
            array_push(_fail, _where + ": bounds.lift " + string(_b.lift)
                + " exceeds the plant's own height " + string(_b.h));
        }
    } else if (_t >= 0.45) {
        array_push(_fail, _where + ": bounds reports EMPTY at a mature stage");
    }
    return _fail;
}

/// The whole corpus, every stage. `_reg` is your registry, so your own species are included.
function vrd_selftest(_reg, _write_file = false) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_reg)) _reg = vrd_registry_create(); if (!is_numeric(_write_file)) _write_file = false;
    var _corpus = vrd_corpus(_reg);
    var _stages = [0.05, 0.25, 0.45, 0.68, 0.86, 1.0];
    var _fails = [];
    var _checks = 0;

    for (var s = 0; s < array_length(_corpus); s++) {
        for (var g = 0; g < array_length(_stages); g++) {
            _checks++;
            var _f = vrd_check_species(_corpus[s], _stages[g]);
            for (var i = 0; i < array_length(_f); i++) array_push(_fails, _f[i]);
        }
    }

    var _summary = string(array_length(_corpus)) + " species x " + string(array_length(_stages))
        + " stages - " + string(_checks) + " checks, " + string(array_length(_fails)) + " failed";

    if (_write_file) {
        var _fh = file_text_open_write("verdure_selftest.txt");
        file_text_write_string(_fh, _summary);
        file_text_writeln(_fh);
        for (var i = 0; i < array_length(_fails); i++) {
            file_text_write_string(_fh, _fails[i]);
            file_text_writeln(_fh);
        }
        file_text_close(_fh);
    }

    return { ok: array_length(_fails) == 0, checks: _checks, failures: _fails, summary: _summary };
}
