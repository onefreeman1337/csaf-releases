/// ============================================================================================
/// VERDURE - verdure_preset: THE CORPUS. 48 species, the form vocabulary, and the palettes.
///
/// *** GENERATED FILE - DO NOT EDIT BY HAND. ***
///   source : Internal_Ops/species.js + Internal_Ops/palette.js
///   build  : node Internal_Ops/gen_preset.js
///   verify : node Internal_Ops/gen_preset.js --check
///   mirror : sha256:e5b62509e733a17f
///
/// WHY GENERATED. Every one of the 288 drawn states in this corpus was reviewed by rendering it
/// and LOOKING at it, and that review was done against the JS mirror. A hand-typed copy would be
/// a SECOND corpus that merely resembles the reviewed one, and the first divergence would be
/// silent - the contact sheet still beautiful, the engine drawing something else, no error
/// anywhere. One source, one build step, one check command.
///
/// ZERO ENGINE CALLS. This file is pure data; `verdure_render` interprets it. That separation is
/// what lets one geometry serve 48 species, six growth stages and every cross-bred child.
///
/// APPEND-ONLY, AND THIS IS THE ONE SHARP EDGE IN THE PRODUCT. A saved plant stores a SEED, and
/// a seed resolves into indices in these tables. Adding a species at the END is always safe.
/// Reordering or removing one silently rewrites every plant a player has already grown - no
/// error, no warning, their prize specimen quietly becomes a different plant.
/// ============================================================================================

#macro VRD_CORPUS_VERSION 1
#macro VRD_CORPUS_SPECIES 48

/// The form-name tables. Indices are referenced by every species program above and are the
/// numbers a buyer reads when authoring their own. Names are for tooling and documentation;
/// `verdure_render` switches on the INDEX, never on the string.
function vrd_leaf_forms() {
    static _t = ["blade", "ovate", "lance", "lobed", "needle", "heart", "fan", "spatulate", "toothed", "strap", "palmate", "trifoliate", "pinnate", "oaklobe", "scale"];
    return _t;
}
function vrd_bloom_forms() {
    static _t = ["disc", "cup", "bell", "star", "ray", "spike", "plume"];
    return _t;
}
function vrd_crown_forms() {
    static _t = ["ear", "panicle", "rosette", "cluster", "raceme", "digitate", "nod", "awned", "cap", "bracket", "coral", "puffball", "morel", "inkcap", "canopy", "conifer", "weeping", "spread"];
    return _t;
}
function vrd_root_forms() {
    static _t = ["taproot", "globe", "fusiform", "tuber", "bulb", "forked"];
    return _t;
}

/// FAMILY: GRAIN - 6 species: Wheat, Barley, Rye, Millet, Oat, Sorghum.
function vrd_species_grain() {
    static _s = [
        {
            id: "wheat", name: "Wheat", family: "grain",
            program: [
                {
                    kind: "stem",
                    w0: 2.6,
                    w1: 1,
                    len: 46,
                    curve: 0.05,
                    lean: 0.02,
                    emerge: [0, 0.55],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.3,
                            angle: 0.62,
                            form: 0,
                            size: 27,
                            emerge: [0.18, 0.5]
                        },
                        {
                            kind: "leaf",
                            at: 0.46,
                            angle: -0.68,
                            form: 0,
                            size: 24,
                            emerge: [0.24, 0.56]
                        },
                        {
                            kind: "leaf",
                            at: 0.62,
                            angle: 0.56,
                            form: 0,
                            size: 19,
                            emerge: [0.32, 0.62]
                        },
                        {
                            kind: "crown",
                            at: 1,
                            form: 0,
                            size: 15,
                            emerge: [0.6, 0.95]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 7,
                    depth: 9,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 3.105,
                    form: 0,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 0.22,
                    form: 0,
                    size: 14.95,
                    emerge: [0.03, 0.17],
                    wither: [0.3, 0.54]
                }
            ]
        },
        {
            id: "barley", name: "Barley", family: "grain",
            program: [
                {
                    kind: "stem",
                    w0: 2.6,
                    w1: 1,
                    len: 42,
                    curve: 0.1,
                    lean: -0.04,
                    emerge: [0, 0.55],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.26,
                            angle: -0.66,
                            form: 0,
                            size: 29,
                            emerge: [0.16, 0.48]
                        },
                        {
                            kind: "leaf",
                            at: 0.44,
                            angle: 0.7,
                            form: 0,
                            size: 25,
                            emerge: [0.22, 0.54]
                        },
                        {
                            kind: "leaf",
                            at: 0.6,
                            angle: -0.56,
                            form: 0,
                            size: 18,
                            emerge: [0.3, 0.6]
                        },
                        {
                            kind: "crown",
                            at: 1,
                            form: 7,
                            size: 16,
                            emerge: [0.58, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 7,
                    depth: 8,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 3.24,
                    form: 0,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 0.22,
                    form: 0,
                    size: 15.6,
                    emerge: [0.03, 0.17],
                    wither: [0.3, 0.54]
                }
            ]
        },
        {
            id: "rye", name: "Rye", family: "grain",
            program: [
                {
                    kind: "stem",
                    w0: 2.2,
                    w1: 0.8,
                    len: 54,
                    curve: 0.03,
                    lean: 0.05,
                    emerge: [0, 0.6],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.34,
                            angle: 0.56,
                            form: 0,
                            size: 25,
                            emerge: [0.2, 0.52]
                        },
                        {
                            kind: "leaf",
                            at: 0.52,
                            angle: -0.58,
                            form: 0,
                            size: 21,
                            emerge: [0.26, 0.58]
                        },
                        {
                            kind: "crown",
                            at: 1,
                            form: 4,
                            size: 16,
                            emerge: [0.62, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 6,
                    depth: 10,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 2.565,
                    form: 0,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 0.22,
                    form: 0,
                    size: 12.35,
                    emerge: [0.03, 0.17],
                    wither: [0.3, 0.54]
                }
            ]
        },
        {
            id: "millet", name: "Millet", family: "grain",
            program: [
                {
                    kind: "stem",
                    w0: 2.6,
                    w1: 1,
                    len: 38,
                    curve: 0.14,
                    lean: -0.02,
                    emerge: [0, 0.5],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.24,
                            angle: -0.76,
                            form: 0,
                            size: 29,
                            emerge: [0.14, 0.46]
                        },
                        {
                            kind: "leaf",
                            at: 0.42,
                            angle: 0.72,
                            form: 0,
                            size: 26,
                            emerge: [0.2, 0.52]
                        },
                        {
                            kind: "leaf",
                            at: 0.58,
                            angle: -0.6,
                            form: 0,
                            size: 20,
                            emerge: [0.28, 0.58]
                        },
                        {
                            kind: "crown",
                            at: 1,
                            form: 5,
                            size: 17,
                            emerge: [0.55, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 8,
                    depth: 7,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 2.025,
                    form: 0,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 0.22,
                    form: 0,
                    size: 9.75,
                    emerge: [0.03, 0.17],
                    wither: [0.3, 0.54]
                }
            ]
        },
        {
            id: "oat", name: "Oat", family: "grain",
            program: [
                {
                    kind: "stem",
                    w0: 2.6,
                    w1: 1,
                    len: 48,
                    curve: 0.08,
                    lean: 0.03,
                    emerge: [0, 0.58],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.3,
                            angle: 0.64,
                            form: 0,
                            size: 26,
                            emerge: [0.18, 0.5]
                        },
                        {
                            kind: "leaf",
                            at: 0.5,
                            angle: -0.64,
                            form: 0,
                            size: 23,
                            emerge: [0.24, 0.56]
                        },
                        {
                            kind: "crown",
                            at: 1,
                            form: 1,
                            size: 19,
                            emerge: [0.6, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 7,
                    depth: 9,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 2.97,
                    form: 0,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 0.22,
                    form: 0,
                    size: 14.3,
                    emerge: [0.03, 0.17],
                    wither: [0.3, 0.54]
                }
            ]
        },
        {
            id: "sorghum", name: "Sorghum", family: "grain",
            program: [
                {
                    kind: "stem",
                    w0: 3.4,
                    w1: 1.4,
                    len: 58,
                    curve: 0.02,
                    lean: -0.03,
                    emerge: [0, 0.62],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.22,
                            angle: -0.8,
                            form: 0,
                            size: 33,
                            emerge: [0.12, 0.44]
                        },
                        {
                            kind: "leaf",
                            at: 0.4,
                            angle: 0.78,
                            form: 0,
                            size: 29,
                            emerge: [0.18, 0.5]
                        },
                        {
                            kind: "leaf",
                            at: 0.58,
                            angle: -0.66,
                            form: 0,
                            size: 23,
                            emerge: [0.26, 0.56]
                        },
                        {
                            kind: "crown",
                            at: 1,
                            form: 3,
                            size: 17,
                            emerge: [0.66, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 9,
                    depth: 11,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 4.05,
                    form: 0,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 0.22,
                    form: 0,
                    size: 19.5,
                    emerge: [0.03, 0.17],
                    wither: [0.3, 0.54]
                }
            ]
        },
    ];
    return _s;
}

/// FAMILY: BLOOM - 6 species: Poppy, Aster, Iris, Foxglove, Thistle, Campanula.
function vrd_species_bloom() {
    static _s = [
        {
            id: "poppy", name: "Poppy", family: "bloom",
            program: [
                {
                    kind: "stem",
                    w0: 1.8,
                    w1: 1,
                    len: 34,
                    curve: 0.12,
                    lean: 0.04,
                    emerge: [0, 0.5],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.18,
                            angle: -1.18,
                            form: 3,
                            size: 12,
                            emerge: [0.12, 0.42]
                        },
                        {
                            kind: "leaf",
                            at: 0.36,
                            angle: 1.12,
                            form: 3,
                            size: 11,
                            emerge: [0.18, 0.48]
                        },
                        {
                            kind: "bloom",
                            at: 1,
                            petals: 5,
                            form: 1,
                            size: 13,
                            emerge: [0.6, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 6,
                    depth: 6,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 1.89,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 3.92,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 3.92,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "aster", name: "Aster", family: "bloom",
            program: [
                {
                    kind: "stem",
                    w0: 1.6,
                    w1: 0.9,
                    len: 30,
                    curve: 0.06,
                    lean: -0.05,
                    emerge: [0, 0.48],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.22,
                            angle: 1.16,
                            form: 2,
                            size: 12,
                            emerge: [0.14, 0.44]
                        },
                        {
                            kind: "leaf",
                            at: 0.44,
                            angle: -1.1,
                            form: 2,
                            size: 11,
                            emerge: [0.2, 0.5]
                        },
                        {
                            kind: "leaf",
                            at: 0.62,
                            angle: 1.02,
                            form: 2,
                            size: 8,
                            emerge: [0.28, 0.56]
                        },
                        {
                            kind: "bloom",
                            at: 1,
                            petals: 16,
                            form: 4,
                            size: 11,
                            emerge: [0.58, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 6,
                    depth: 6,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 2.295,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 4.76,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 4.76,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "iris", name: "Iris", family: "bloom",
            program: [
                {
                    kind: "stem",
                    w0: 2,
                    w1: 1.1,
                    len: 40,
                    curve: 0.03,
                    lean: 0.02,
                    emerge: [0, 0.55],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.1,
                            angle: -0.28,
                            form: 0,
                            size: 22,
                            emerge: [0.08, 0.45]
                        },
                        {
                            kind: "leaf",
                            at: 0.14,
                            angle: 0.3,
                            form: 0,
                            size: 20,
                            emerge: [0.1, 0.47]
                        },
                        {
                            kind: "bloom",
                            at: 1,
                            petals: 6,
                            form: 3,
                            size: 12,
                            emerge: [0.62, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 7,
                    depth: 7,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 3.375,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 7,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 7,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "foxglove", name: "Foxglove", family: "bloom",
            program: [
                {
                    kind: "stem",
                    w0: 2.2,
                    w1: 1,
                    len: 50,
                    curve: 0.05,
                    lean: -0.03,
                    emerge: [0, 0.6],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.14,
                            angle: -1.2,
                            form: 8,
                            size: 14,
                            emerge: [0.1, 0.42]
                        },
                        {
                            kind: "leaf",
                            at: 0.28,
                            angle: 1.14,
                            form: 8,
                            size: 12,
                            emerge: [0.16, 0.48]
                        },
                        {
                            kind: "bloom",
                            at: 0.6,
                            petals: 3,
                            form: 2,
                            size: 11,
                            emerge: [0.66, 1]
                        },
                        {
                            kind: "bloom",
                            at: 0.76,
                            petals: 3,
                            form: 2,
                            size: 10,
                            emerge: [0.72, 1]
                        },
                        {
                            kind: "bloom",
                            at: 0.92,
                            petals: 3,
                            form: 2,
                            size: 8.5,
                            emerge: [0.78, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 6,
                    depth: 8,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 1.89,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 3.92,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 3.92,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "thistle", name: "Thistle", family: "bloom",
            program: [
                {
                    kind: "stem",
                    w0: 2.4,
                    w1: 1.2,
                    len: 38,
                    curve: 0.08,
                    lean: 0.05,
                    emerge: [0, 0.55],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.2,
                            angle: -1.22,
                            form: 8,
                            size: 15,
                            emerge: [0.12, 0.44]
                        },
                        {
                            kind: "leaf",
                            at: 0.4,
                            angle: 1.16,
                            form: 8,
                            size: 13,
                            emerge: [0.18, 0.5]
                        },
                        {
                            kind: "leaf",
                            at: 0.58,
                            angle: -1.04,
                            form: 8,
                            size: 10,
                            emerge: [0.26, 0.56]
                        },
                        {
                            kind: "bloom",
                            at: 1,
                            petals: 20,
                            form: 6,
                            size: 10,
                            emerge: [0.62, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 7,
                    depth: 9,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 2.7,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 5.6,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 5.6,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "campanula", name: "Campanula", family: "bloom",
            program: [
                {
                    kind: "stem",
                    w0: 1.5,
                    w1: 0.8,
                    len: 32,
                    curve: 0.16,
                    lean: -0.06,
                    emerge: [0, 0.5],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.24,
                            angle: 1.16,
                            form: 5,
                            size: 11,
                            emerge: [0.14, 0.44]
                        },
                        {
                            kind: "leaf",
                            at: 0.46,
                            angle: -1.1,
                            form: 5,
                            size: 10,
                            emerge: [0.2, 0.5]
                        },
                        {
                            kind: "bloom",
                            at: 0.7,
                            petals: 5,
                            form: 2,
                            size: 11,
                            emerge: [0.6, 1]
                        },
                        {
                            kind: "bloom",
                            at: 1,
                            petals: 5,
                            form: 2,
                            size: 13,
                            emerge: [0.66, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 6,
                    depth: 6,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 1.755,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 3.64,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 3.64,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
    ];
    return _s;
}

/// FAMILY: SUCCULENT - 6 species: Aloe, Agave, Sedum, Echeveria, Haworthia, Crassula.
function vrd_species_succulent() {
    static _s = [
        {
            id: "aloe", name: "Aloe", family: "succulent",
            program: [
                {
                    kind: "stem",
                    w0: 4,
                    w1: 4,
                    len: 3,
                    emerge: [0, 0.1],
                    children: [
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -0.55,
                            form: 9,
                            size: 22,
                            emerge: [0.1, 0.75]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -0.4125,
                            form: 9,
                            size: 26.5,
                            emerge: [0.12, 0.75]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -0.275,
                            form: 9,
                            size: 31,
                            emerge: [0.14, 0.75]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -0.1375,
                            form: 9,
                            size: 35.5,
                            emerge: [0.16, 0.75]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0,
                            form: 9,
                            size: 40,
                            emerge: [0.18, 0.75]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0.1375,
                            form: 9,
                            size: 35.5,
                            emerge: [0.2, 0.75]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0.275,
                            form: 9,
                            size: 31,
                            emerge: [0.22, 0.75]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0.4125,
                            form: 9,
                            size: 26.5,
                            emerge: [0.24, 0.75]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0.55,
                            form: 9,
                            size: 22,
                            emerge: [0.26, 0.75]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 9,
                    depth: 5,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 2.7,
                    form: 2,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 7,
                    size: 4.6,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 7,
                    size: 4.6,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "agave", name: "Agave", family: "succulent",
            program: [
                {
                    kind: "stem",
                    w0: 5,
                    w1: 5,
                    len: 3,
                    emerge: [0, 0.1],
                    children: [
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -1.45,
                            form: 9,
                            size: 32.3,
                            emerge: [0.12, 0.8]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -1.2083,
                            form: 9,
                            size: 33.25,
                            emerge: [0.1333, 0.8]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -0.9667,
                            form: 9,
                            size: 34.2,
                            emerge: [0.1467, 0.8]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -0.725,
                            form: 9,
                            size: 35.15,
                            emerge: [0.16, 0.8]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -0.4833,
                            form: 9,
                            size: 36.1,
                            emerge: [0.1733, 0.8]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -0.2417,
                            form: 9,
                            size: 37.05,
                            emerge: [0.1867, 0.8]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0,
                            form: 9,
                            size: 38,
                            emerge: [0.2, 0.8]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0.2417,
                            form: 9,
                            size: 37.05,
                            emerge: [0.2133, 0.8]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0.4833,
                            form: 9,
                            size: 36.1,
                            emerge: [0.2267, 0.8]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0.725,
                            form: 9,
                            size: 35.15,
                            emerge: [0.24, 0.8]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0.9667,
                            form: 9,
                            size: 34.2,
                            emerge: [0.2533, 0.8]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 1.2083,
                            form: 9,
                            size: 33.25,
                            emerge: [0.2667, 0.8]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 1.45,
                            form: 9,
                            size: 32.3,
                            emerge: [0.28, 0.8]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 12,
                    depth: 5,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 3.24,
                    form: 2,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 7,
                    size: 5.52,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 7,
                    size: 5.52,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "sedum", name: "Sedum", family: "succulent",
            program: [
                {
                    kind: "stem",
                    w0: 3,
                    w1: 2.4,
                    len: 5,
                    emerge: [0, 0.15],
                    children: [
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -1.35,
                            form: 7,
                            size: 11.7,
                            emerge: [0.12, 0.7]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -1.08,
                            form: 7,
                            size: 11.96,
                            emerge: [0.136, 0.7]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -0.81,
                            form: 7,
                            size: 12.22,
                            emerge: [0.152, 0.7]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -0.54,
                            form: 7,
                            size: 12.48,
                            emerge: [0.168, 0.7]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -0.27,
                            form: 7,
                            size: 12.74,
                            emerge: [0.184, 0.7]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0,
                            form: 7,
                            size: 13,
                            emerge: [0.2, 0.7]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0.27,
                            form: 7,
                            size: 12.74,
                            emerge: [0.216, 0.7]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0.54,
                            form: 7,
                            size: 12.48,
                            emerge: [0.232, 0.7]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0.81,
                            form: 7,
                            size: 12.22,
                            emerge: [0.248, 0.7]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 1.08,
                            form: 7,
                            size: 11.96,
                            emerge: [0.264, 0.7]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 1.35,
                            form: 7,
                            size: 11.7,
                            emerge: [0.28, 0.7]
                        },
                        {
                            kind: "branch",
                            at: 1,
                            angle: 1.35,
                            scale: 0.5,
                            len: 20,
                            w0: 1.8,
                            w1: 1.2,
                            curve: 0.3,
                            emerge: [0.5, 0.95],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0,
                                    angle: -0.9,
                                    form: 7,
                                    size: 5.6,
                                    emerge: [0.6, 1]
                                },
                                {
                                    kind: "leaf",
                                    at: 0,
                                    angle: -0.3,
                                    form: 7,
                                    size: 6.5333,
                                    emerge: [0.6533, 1]
                                },
                                {
                                    kind: "leaf",
                                    at: 0,
                                    angle: 0.3,
                                    form: 7,
                                    size: 6.5333,
                                    emerge: [0.7067, 1]
                                },
                                {
                                    kind: "leaf",
                                    at: 0,
                                    angle: 0.9,
                                    form: 7,
                                    size: 5.6,
                                    emerge: [0.76, 1]
                                }
                            ]
                        },
                        {
                            kind: "branch",
                            at: 1,
                            angle: -1.35,
                            scale: 0.5,
                            len: 18,
                            w0: 1.8,
                            w1: 1.2,
                            curve: -0.3,
                            emerge: [0.55, 1],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0,
                                    angle: -0.9,
                                    form: 7,
                                    size: 5.6,
                                    emerge: [0.65, 1]
                                },
                                {
                                    kind: "leaf",
                                    at: 0,
                                    angle: -0.3,
                                    form: 7,
                                    size: 6.5333,
                                    emerge: [0.7033, 1]
                                },
                                {
                                    kind: "leaf",
                                    at: 0,
                                    angle: 0.3,
                                    form: 7,
                                    size: 6.5333,
                                    emerge: [0.7567, 1]
                                },
                                {
                                    kind: "leaf",
                                    at: 0,
                                    angle: 0.9,
                                    form: 7,
                                    size: 5.6,
                                    emerge: [0.81, 1]
                                }
                            ]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 8,
                    depth: 4,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 1.755,
                    form: 2,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 7,
                    size: 2.99,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 7,
                    size: 2.99,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "echeveria", name: "Echeveria", family: "succulent",
            program: [
                {
                    kind: "stem",
                    w0: 4,
                    w1: 3.4,
                    len: 2,
                    emerge: [0, 0.12],
                    children: [
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -2.2,
                            form: 7,
                            size: 14.4,
                            emerge: [0.1, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -1.8615,
                            form: 7,
                            size: 14.9538,
                            emerge: [0.1123, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -1.5231,
                            form: 7,
                            size: 15.5077,
                            emerge: [0.1246, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -1.1846,
                            form: 7,
                            size: 16.0615,
                            emerge: [0.1369, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -0.8462,
                            form: 7,
                            size: 16.6154,
                            emerge: [0.1492, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -0.5077,
                            form: 7,
                            size: 17.1692,
                            emerge: [0.1615, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -0.1692,
                            form: 7,
                            size: 17.7231,
                            emerge: [0.1738, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0.1692,
                            form: 7,
                            size: 17.7231,
                            emerge: [0.1862, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0.5077,
                            form: 7,
                            size: 17.1692,
                            emerge: [0.1985, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0.8462,
                            form: 7,
                            size: 16.6154,
                            emerge: [0.2108, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 1.1846,
                            form: 7,
                            size: 16.0615,
                            emerge: [0.2231, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 1.5231,
                            form: 7,
                            size: 15.5077,
                            emerge: [0.2354, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 1.8615,
                            form: 7,
                            size: 14.9538,
                            emerge: [0.2477, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 2.2,
                            form: 7,
                            size: 14.4,
                            emerge: [0.26, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -1.05,
                            form: 7,
                            size: 8.075,
                            emerge: [0.3, 0.86]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -0.75,
                            form: 7,
                            size: 8.4821,
                            emerge: [0.3229, 0.86]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -0.45,
                            form: 7,
                            size: 8.8893,
                            emerge: [0.3457, 0.86]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -0.15,
                            form: 7,
                            size: 9.2964,
                            emerge: [0.3686, 0.86]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0.15,
                            form: 7,
                            size: 9.2964,
                            emerge: [0.3914, 0.86]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0.45,
                            form: 7,
                            size: 8.8893,
                            emerge: [0.4143, 0.86]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0.75,
                            form: 7,
                            size: 8.4821,
                            emerge: [0.4371, 0.86]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 1.05,
                            form: 7,
                            size: 8.075,
                            emerge: [0.46, 0.86]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 8,
                    depth: 4,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 1.89,
                    form: 2,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 7,
                    size: 3.22,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 7,
                    size: 3.22,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "haworthia", name: "Haworthia", family: "succulent",
            program: [
                {
                    kind: "stem",
                    w0: 3.4,
                    w1: 3,
                    len: 3,
                    emerge: [0, 0.1],
                    children: [
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -1.25,
                            form: 2,
                            size: 21,
                            emerge: [0.12, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -0.8333,
                            form: 2,
                            size: 24,
                            emerge: [0.1467, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -0.4167,
                            form: 2,
                            size: 27,
                            emerge: [0.1733, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0,
                            form: 2,
                            size: 30,
                            emerge: [0.2, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0.4167,
                            form: 2,
                            size: 27,
                            emerge: [0.2267, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0.8333,
                            form: 2,
                            size: 24,
                            emerge: [0.2533, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 1.25,
                            form: 2,
                            size: 21,
                            emerge: [0.28, 0.72]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 7,
                    depth: 5,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 2.025,
                    form: 2,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 7,
                    size: 3.45,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 7,
                    size: 3.45,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "crassula", name: "Crassula", family: "succulent",
            program: [
                {
                    kind: "stem",
                    w0: 4.2,
                    w1: 2.6,
                    len: 19,
                    curve: 0.04,
                    emerge: [0, 0.42],
                    children: [
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -1.05,
                            form: 7,
                            size: 13.5,
                            emerge: [0.3, 0.7]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -0.35,
                            form: 7,
                            size: 14.5,
                            emerge: [0.3533, 0.7]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0.35,
                            form: 7,
                            size: 14.5,
                            emerge: [0.4067, 0.7]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 1.05,
                            form: 7,
                            size: 13.5,
                            emerge: [0.46, 0.7]
                        },
                        {
                            kind: "branch",
                            at: 0.38,
                            angle: 1.16,
                            scale: 0.72,
                            len: 24,
                            w0: 2.8,
                            w1: 1.6,
                            curve: -0.18,
                            emerge: [0.42, 0.82],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0,
                                    angle: -1.25,
                                    form: 7,
                                    size: 14.45,
                                    emerge: [0.52, 0.94]
                                },
                                {
                                    kind: "leaf",
                                    at: 0,
                                    angle: -0.625,
                                    form: 7,
                                    size: 15.725,
                                    emerge: [0.56, 0.94]
                                },
                                {
                                    kind: "leaf",
                                    at: 0,
                                    angle: 0,
                                    form: 7,
                                    size: 17,
                                    emerge: [0.6, 0.94]
                                },
                                {
                                    kind: "leaf",
                                    at: 0,
                                    angle: 0.625,
                                    form: 7,
                                    size: 15.725,
                                    emerge: [0.64, 0.94]
                                },
                                {
                                    kind: "leaf",
                                    at: 0,
                                    angle: 1.25,
                                    form: 7,
                                    size: 14.45,
                                    emerge: [0.68, 0.94]
                                }
                            ]
                        },
                        {
                            kind: "branch",
                            at: 0.62,
                            angle: -1.24,
                            scale: 0.68,
                            len: 22,
                            w0: 2.6,
                            w1: 1.5,
                            curve: 0.2,
                            emerge: [0.5, 0.88],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0,
                                    angle: -1.25,
                                    form: 7,
                                    size: 13.6,
                                    emerge: [0.58, 0.98]
                                },
                                {
                                    kind: "leaf",
                                    at: 0,
                                    angle: -0.625,
                                    form: 7,
                                    size: 14.8,
                                    emerge: [0.62, 0.98]
                                },
                                {
                                    kind: "leaf",
                                    at: 0,
                                    angle: 0,
                                    form: 7,
                                    size: 16,
                                    emerge: [0.66, 0.98]
                                },
                                {
                                    kind: "leaf",
                                    at: 0,
                                    angle: 0.625,
                                    form: 7,
                                    size: 14.8,
                                    emerge: [0.7, 0.98]
                                },
                                {
                                    kind: "leaf",
                                    at: 0,
                                    angle: 1.25,
                                    form: 7,
                                    size: 13.6,
                                    emerge: [0.74, 0.98]
                                }
                            ]
                        },
                        {
                            kind: "branch",
                            at: 0.86,
                            angle: 0.42,
                            scale: 0.55,
                            len: 15,
                            w0: 2.2,
                            w1: 1.3,
                            emerge: [0.6, 0.94],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0,
                                    angle: -1.15,
                                    form: 7,
                                    size: 12.32,
                                    emerge: [0.66, 1]
                                },
                                {
                                    kind: "leaf",
                                    at: 0,
                                    angle: -0.3833,
                                    form: 7,
                                    size: 13.44,
                                    emerge: [0.7133, 1]
                                },
                                {
                                    kind: "leaf",
                                    at: 0,
                                    angle: 0.3833,
                                    form: 7,
                                    size: 13.44,
                                    emerge: [0.7667, 1]
                                },
                                {
                                    kind: "leaf",
                                    at: 0,
                                    angle: 1.15,
                                    form: 7,
                                    size: 12.32,
                                    emerge: [0.82, 1]
                                }
                            ]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 10,
                    depth: 6,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 2.16,
                    form: 2,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 7,
                    size: 3.68,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 7,
                    size: 3.68,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
    ];
    return _s;
}

/// FAMILY: ROOT - 6 species: Carrot, Turnip, Parsnip, Potato, Onion, Mandrake.
function vrd_species_root() {
    static _s = [
        {
            id: "carrot", name: "Carrot", family: "root",
            program: [
                {
                    kind: "taproot",
                    form: 0,
                    len: 28,
                    girth: 4.8,
                    emerge: [0.1, 0.92]
                },
                {
                    kind: "stem",
                    w0: 1.7,
                    w1: 1.1,
                    len: 8,
                    emerge: [0, 0.3],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.5,
                            angle: -0.95,
                            form: 2,
                            size: 15,
                            emerge: [0.16, 0.62]
                        },
                        {
                            kind: "leaf",
                            at: 0.68,
                            angle: 0.9,
                            form: 2,
                            size: 14,
                            emerge: [0.2, 0.68]
                        },
                        {
                            kind: "leaf",
                            at: 0.84,
                            angle: -0.55,
                            form: 2,
                            size: 13,
                            emerge: [0.26, 0.74]
                        },
                        {
                            kind: "leaf",
                            at: 0.96,
                            angle: 0.5,
                            form: 2,
                            size: 12,
                            emerge: [0.32, 0.8]
                        },
                        {
                            kind: "leaf",
                            at: 1,
                            angle: -0.12,
                            form: 2,
                            size: 11,
                            emerge: [0.38, 0.86]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 6,
                    depth: 5,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 1.62,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 3.36,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 3.36,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "turnip", name: "Turnip", family: "root",
            program: [
                {
                    kind: "taproot",
                    form: 1,
                    len: 17,
                    girth: 9.5,
                    emerge: [0.1, 0.9]
                },
                {
                    kind: "stem",
                    w0: 2.2,
                    w1: 1.6,
                    len: 6,
                    emerge: [0, 0.28],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.6,
                            angle: -1.02,
                            form: 8,
                            size: 21,
                            emerge: [0.18, 0.64]
                        },
                        {
                            kind: "leaf",
                            at: 0.8,
                            angle: 0.96,
                            form: 8,
                            size: 20,
                            emerge: [0.22, 0.7]
                        },
                        {
                            kind: "leaf",
                            at: 1,
                            angle: -0.34,
                            form: 8,
                            size: 17,
                            emerge: [0.3, 0.78]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 7,
                    depth: 6,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 2.16,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 4.48,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 4.48,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "parsnip", name: "Parsnip", family: "root",
            program: [
                {
                    kind: "taproot",
                    form: 2,
                    len: 19,
                    girth: 10.5,
                    emerge: [0.1, 0.94]
                },
                {
                    kind: "stem",
                    w0: 2.6,
                    w1: 1.6,
                    len: 11,
                    emerge: [0, 0.32],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.42,
                            angle: -0.62,
                            form: 8,
                            size: 24,
                            emerge: [0.18, 0.64]
                        },
                        {
                            kind: "leaf",
                            at: 0.66,
                            angle: 0.58,
                            form: 8,
                            size: 23,
                            emerge: [0.22, 0.7]
                        },
                        {
                            kind: "leaf",
                            at: 0.88,
                            angle: -0.3,
                            form: 8,
                            size: 20,
                            emerge: [0.28, 0.76]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 6,
                    depth: 6,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 1.89,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 3.92,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 3.92,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "potato", name: "Potato", family: "root",
            program: [
                {
                    kind: "taproot",
                    form: 3,
                    len: 22,
                    girth: 7.5,
                    emerge: [0.14, 0.96]
                },
                {
                    kind: "stem",
                    w0: 2.4,
                    w1: 1.4,
                    len: 22,
                    curve: 0.06,
                    emerge: [0, 0.46],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.3,
                            angle: -1.1,
                            form: 1,
                            size: 13,
                            emerge: [0.16, 0.56]
                        },
                        {
                            kind: "leaf",
                            at: 0.52,
                            angle: 1.05,
                            form: 1,
                            size: 12,
                            emerge: [0.22, 0.62]
                        },
                        {
                            kind: "leaf",
                            at: 0.74,
                            angle: -0.95,
                            form: 1,
                            size: 11,
                            emerge: [0.28, 0.68]
                        },
                        {
                            kind: "leaf",
                            at: 0.94,
                            angle: 0.6,
                            form: 1,
                            size: 10,
                            emerge: [0.34, 0.74]
                        },
                        {
                            kind: "bloom",
                            at: 1,
                            petals: 5,
                            form: 0,
                            size: 8,
                            emerge: [0.7, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 7,
                    depth: 5,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 3.645,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 7.56,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 7.56,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "onion", name: "Onion", family: "root",
            program: [
                {
                    kind: "taproot",
                    form: 4,
                    len: 15,
                    girth: 8.5,
                    emerge: [0.12, 0.9]
                },
                {
                    kind: "stem",
                    w0: 2.6,
                    w1: 2,
                    len: 5,
                    emerge: [0, 0.24],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.8,
                            angle: -0.42,
                            form: 4,
                            size: 30,
                            emerge: [0.16, 0.66]
                        },
                        {
                            kind: "leaf",
                            at: 0.9,
                            angle: 0.3,
                            form: 4,
                            size: 28,
                            emerge: [0.2, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 1,
                            angle: -0.14,
                            form: 4,
                            size: 25,
                            emerge: [0.26, 0.78]
                        },
                        {
                            kind: "leaf",
                            at: 1,
                            angle: 0.52,
                            form: 4,
                            size: 23,
                            emerge: [0.32, 0.84]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 8,
                    depth: 4,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 2.295,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 0.22,
                    form: 0,
                    size: 11.05,
                    emerge: [0.03, 0.17],
                    wither: [0.3, 0.54]
                }
            ]
        },
        {
            id: "mandrake", name: "Mandrake", family: "root",
            program: [
                {
                    kind: "taproot",
                    form: 5,
                    len: 28,
                    girth: 7.4,
                    emerge: [0.12, 0.94]
                },
                {
                    kind: "stem",
                    w0: 2.4,
                    w1: 1.8,
                    len: 4,
                    emerge: [0, 0.22],
                    children: [
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -1.46,
                            form: 1,
                            size: 12.6,
                            emerge: [0.18, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -0.9733,
                            form: 1,
                            size: 15.4,
                            emerge: [0.2067, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: -0.4867,
                            form: 1,
                            size: 18.2,
                            emerge: [0.2333, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0,
                            form: 1,
                            size: 21,
                            emerge: [0.26, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0.4867,
                            form: 1,
                            size: 18.2,
                            emerge: [0.2867, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 0.9733,
                            form: 1,
                            size: 15.4,
                            emerge: [0.3133, 0.72]
                        },
                        {
                            kind: "leaf",
                            at: 0,
                            angle: 1.46,
                            form: 1,
                            size: 12.6,
                            emerge: [0.34, 0.72]
                        },
                        {
                            kind: "bloom",
                            at: 1,
                            petals: 5,
                            form: 2,
                            size: 9,
                            emerge: [0.74, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 7,
                    depth: 5,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 3.51,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 7.28,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 7.28,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
    ];
    return _s;
}

/// FAMILY: VINE - 6 species: Bean, Pea, Grape, Gourd, Melon, Hop.
function vrd_species_vine() {
    static _s = [
        {
            id: "bean", name: "Bean", family: "vine",
            program: [
                {
                    kind: "stem",
                    w0: 2.2,
                    w1: 1.1,
                    len: 50,
                    curve: 0.09,
                    lean: 0.1,
                    emerge: [0, 0.55],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.24,
                            angle: -0.95,
                            form: 11,
                            size: 20,
                            emerge: [0.14, 0.46]
                        },
                        {
                            kind: "leaf",
                            at: 0.44,
                            angle: 0.98,
                            form: 11,
                            size: 22,
                            emerge: [0.2, 0.52]
                        },
                        {
                            kind: "leaf",
                            at: 0.66,
                            angle: -0.88,
                            form: 11,
                            size: 19,
                            emerge: [0.28, 0.6]
                        },
                        {
                            kind: "tendril",
                            at: 0.8,
                            angle: 0.85,
                            size: 13,
                            turns: 2.6,
                            emerge: [0.42, 0.8]
                        },
                        {
                            kind: "tendril",
                            at: 0.95,
                            angle: -0.6,
                            size: 11,
                            turns: 2.2,
                            emerge: [0.55, 0.92]
                        },
                        {
                            kind: "fruit",
                            at: 0.5,
                            form: 1,
                            size: 8.5,
                            hang: 5,
                            emerge: [0.68, 1]
                        },
                        {
                            kind: "fruit",
                            at: 0.68,
                            form: 1,
                            size: 9.5,
                            hang: 7,
                            emerge: [0.74, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 7,
                    depth: 9,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 4.32,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 8.96,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 8.96,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "pea", name: "Pea", family: "vine",
            program: [
                {
                    kind: "stem",
                    w0: 1.8,
                    w1: 0.9,
                    len: 30,
                    curve: 0.2,
                    lean: -0.14,
                    emerge: [0, 0.45],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.2,
                            angle: -1.15,
                            form: 1,
                            size: 11,
                            emerge: [0.12, 0.4]
                        },
                        {
                            kind: "leaf",
                            at: 0.2,
                            angle: 1.15,
                            form: 1,
                            size: 11,
                            emerge: [0.12, 0.4]
                        },
                        {
                            kind: "leaf",
                            at: 0.52,
                            angle: -1.05,
                            form: 1,
                            size: 10,
                            emerge: [0.2, 0.48]
                        },
                        {
                            kind: "leaf",
                            at: 0.52,
                            angle: 1.05,
                            form: 1,
                            size: 10,
                            emerge: [0.2, 0.48]
                        },
                        {
                            kind: "tendril",
                            at: 0.62,
                            angle: 1.05,
                            size: 15,
                            turns: 3,
                            emerge: [0.3, 0.7]
                        },
                        {
                            kind: "tendril",
                            at: 0.84,
                            angle: -1.1,
                            size: 14,
                            turns: 2.8,
                            emerge: [0.36, 0.76]
                        },
                        {
                            kind: "tendril",
                            at: 1,
                            angle: 0.28,
                            size: 16,
                            turns: 3.4,
                            emerge: [0.44, 0.84]
                        },
                        {
                            kind: "fruit",
                            at: 0.42,
                            form: 1,
                            size: 6.6,
                            hang: 4,
                            emerge: [0.66, 1]
                        },
                        {
                            kind: "fruit",
                            at: 0.76,
                            form: 1,
                            size: 6,
                            hang: 4,
                            emerge: [0.74, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 6,
                    depth: 7,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 3.645,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 7.56,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 7.56,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "grape", name: "Grape", family: "vine",
            program: [
                {
                    kind: "stem",
                    w0: 3,
                    w1: 1.4,
                    len: 44,
                    curve: -0.14,
                    lean: 0.42,
                    emerge: [0, 0.52],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.26,
                            angle: -1.05,
                            form: 10,
                            size: 17,
                            emerge: [0.16, 0.48]
                        },
                        {
                            kind: "leaf",
                            at: 0.5,
                            angle: 0.92,
                            form: 10,
                            size: 19,
                            emerge: [0.22, 0.54]
                        },
                        {
                            kind: "leaf",
                            at: 0.76,
                            angle: -0.98,
                            form: 10,
                            size: 16,
                            emerge: [0.3, 0.62]
                        },
                        {
                            kind: "tendril",
                            at: 0.66,
                            angle: -1.25,
                            size: 12,
                            turns: 2.8,
                            emerge: [0.4, 0.78]
                        },
                        {
                            kind: "tendril",
                            at: 0.92,
                            angle: 0.75,
                            size: 11,
                            turns: 2.4,
                            emerge: [0.5, 0.88]
                        },
                        {
                            kind: "fruit",
                            at: 0.42,
                            form: 5,
                            size: 5,
                            hang: 6,
                            emerge: [0.74, 1]
                        },
                        {
                            kind: "fruit",
                            at: 0.72,
                            form: 5,
                            size: 5.6,
                            hang: 7,
                            emerge: [0.8, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 8,
                    depth: 8,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 1.89,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 3.92,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 3.92,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "gourd", name: "Gourd", family: "vine",
            program: [
                {
                    kind: "stem",
                    w0: 3.4,
                    w1: 1.8,
                    len: 38,
                    curve: 0.34,
                    lean: 0.3,
                    emerge: [0, 0.5],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.22,
                            angle: -0.85,
                            form: 3,
                            size: 20,
                            emerge: [0.14, 0.44]
                        },
                        {
                            kind: "leaf",
                            at: 0.48,
                            angle: 0.8,
                            form: 3,
                            size: 22,
                            emerge: [0.2, 0.5]
                        },
                        {
                            kind: "leaf",
                            at: 0.74,
                            angle: -0.72,
                            form: 3,
                            size: 18,
                            emerge: [0.28, 0.58]
                        },
                        {
                            kind: "tendril",
                            at: 0.58,
                            angle: -1.3,
                            size: 14,
                            turns: 2.6,
                            emerge: [0.38, 0.76]
                        },
                        {
                            kind: "fruit",
                            at: 0.88,
                            form: 4,
                            size: 9,
                            hang: 9,
                            emerge: [0.7, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 9,
                    depth: 8,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 3.78,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 7.84,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 7.84,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "melon", name: "Melon", family: "vine",
            program: [
                {
                    kind: "stem",
                    w0: 2.8,
                    w1: 1.4,
                    len: 44,
                    curve: 0.16,
                    lean: 1.16,
                    emerge: [0, 0.48],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.2,
                            angle: -1.05,
                            form: 3,
                            size: 16,
                            emerge: [0.12, 0.42]
                        },
                        {
                            kind: "leaf",
                            at: 0.44,
                            angle: -1.2,
                            form: 3,
                            size: 17,
                            emerge: [0.18, 0.48]
                        },
                        {
                            kind: "leaf",
                            at: 0.68,
                            angle: -1.1,
                            form: 3,
                            size: 15,
                            emerge: [0.26, 0.56]
                        },
                        {
                            kind: "leaf",
                            at: 0.9,
                            angle: -0.95,
                            form: 3,
                            size: 13,
                            emerge: [0.34, 0.64]
                        },
                        {
                            kind: "tendril",
                            at: 0.56,
                            angle: -1.5,
                            size: 11,
                            turns: 2.4,
                            emerge: [0.4, 0.78]
                        },
                        {
                            kind: "fruit",
                            at: 0.7,
                            form: 6,
                            size: 7,
                            hang: -1,
                            emerge: [0.72, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 10,
                    depth: 7,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 3.375,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 7,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 7,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "hop", name: "Hop", family: "vine",
            program: [
                {
                    kind: "stem",
                    w0: 2.4,
                    w1: 1,
                    len: 62,
                    curve: 0.05,
                    lean: -0.06,
                    emerge: [0, 0.62],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.24,
                            angle: 0.88,
                            form: 5,
                            size: 15,
                            emerge: [0.14, 0.46]
                        },
                        {
                            kind: "leaf",
                            at: 0.44,
                            angle: -0.92,
                            form: 5,
                            size: 16,
                            emerge: [0.2, 0.52]
                        },
                        {
                            kind: "leaf",
                            at: 0.64,
                            angle: 0.85,
                            form: 5,
                            size: 14,
                            emerge: [0.26, 0.58]
                        },
                        {
                            kind: "leaf",
                            at: 0.84,
                            angle: -0.8,
                            form: 5,
                            size: 12,
                            emerge: [0.34, 0.66]
                        },
                        {
                            kind: "tendril",
                            at: 1,
                            angle: 0.55,
                            size: 12,
                            turns: 2.6,
                            emerge: [0.48, 0.86]
                        },
                        {
                            kind: "fruit",
                            at: 0.34,
                            form: 7,
                            size: 4.4,
                            hang: 7,
                            emerge: [0.74, 1]
                        },
                        {
                            kind: "fruit",
                            at: 0.58,
                            form: 7,
                            size: 4.6,
                            hang: 8,
                            emerge: [0.78, 1]
                        },
                        {
                            kind: "fruit",
                            at: 0.82,
                            form: 7,
                            size: 4.2,
                            hang: 7,
                            emerge: [0.82, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 7,
                    depth: 10,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 1.485,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 3.08,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 3.08,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
    ];
    return _s;
}

/// FAMILY: BRAMBLE - 6 species: Raspberry, Blackberry, Briar Rose, Gooseberry, Sloe, Hawthorn.
function vrd_species_bramble() {
    static _s = [
        {
            id: "raspberry", name: "Raspberry", family: "bramble",
            program: [
                {
                    kind: "stem",
                    w0: 2.8,
                    w1: 1.2,
                    len: 50,
                    curve: 1.95,
                    lean: -0.16,
                    thorns: 9,
                    thornSize: 3,
                    emerge: [0, 0.55],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.26,
                            angle: -1.1,
                            form: 12,
                            size: 17,
                            emerge: [0.18, 0.5]
                        },
                        {
                            kind: "leaf",
                            at: 0.5,
                            angle: -1.15,
                            form: 12,
                            size: 16,
                            emerge: [0.24, 0.56]
                        },
                        {
                            kind: "leaf",
                            at: 0.74,
                            angle: -1.05,
                            form: 12,
                            size: 14,
                            emerge: [0.32, 0.64]
                        },
                        {
                            kind: "fruit",
                            at: 0.88,
                            form: 8,
                            size: 5.4,
                            hang: 5,
                            emerge: [0.74, 1]
                        },
                        {
                            kind: "fruit",
                            at: 1,
                            form: 8,
                            size: 5,
                            hang: 6,
                            emerge: [0.8, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 8,
                    depth: 9,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 1.62,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 3.36,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 3.36,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "blackberry", name: "Blackberry", family: "bramble",
            program: [
                {
                    kind: "stem",
                    w0: 3.4,
                    w1: 2.4,
                    len: 22,
                    curve: 0.1,
                    thorns: 3,
                    emerge: [0, 0.35],
                    children: [
                        {
                            kind: "branch",
                            at: 0.9,
                            angle: -1.22,
                            scale: 0.95,
                            len: 38,
                            curve: 1.55,
                            w0: 2.4,
                            w1: 1,
                            thorns: 7,
                            thornSize: 2.8,
                            emerge: [0.3, 0.8],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0.34,
                                    angle: 0.95,
                                    form: 12,
                                    size: 14,
                                    emerge: [0.4, 0.76]
                                },
                                {
                                    kind: "leaf",
                                    at: 0.7,
                                    angle: -0.85,
                                    form: 12,
                                    size: 12,
                                    emerge: [0.48, 0.84]
                                },
                                {
                                    kind: "fruit",
                                    at: 0.92,
                                    form: 8,
                                    size: 4.6,
                                    hang: 4,
                                    emerge: [0.76, 1]
                                }
                            ]
                        },
                        {
                            kind: "branch",
                            at: 1,
                            angle: 0.14,
                            scale: 1,
                            len: 34,
                            curve: -1.3,
                            w0: 2.4,
                            w1: 1,
                            thorns: 6,
                            thornSize: 2.8,
                            emerge: [0.26, 0.76],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0.4,
                                    angle: -0.98,
                                    form: 12,
                                    size: 15,
                                    emerge: [0.38, 0.74]
                                },
                                {
                                    kind: "leaf",
                                    at: 0.76,
                                    angle: 0.88,
                                    form: 12,
                                    size: 13,
                                    emerge: [0.46, 0.82]
                                },
                                {
                                    kind: "fruit",
                                    at: 0.94,
                                    form: 8,
                                    size: 5,
                                    hang: 4,
                                    emerge: [0.74, 1]
                                }
                            ]
                        },
                        {
                            kind: "branch",
                            at: 0.8,
                            angle: 1.3,
                            scale: 0.9,
                            len: 36,
                            curve: -1.7,
                            w0: 2.2,
                            w1: 1,
                            thorns: 6,
                            thornSize: 2.8,
                            emerge: [0.34, 0.84],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0.38,
                                    angle: -0.9,
                                    form: 12,
                                    size: 13,
                                    emerge: [0.44, 0.8]
                                },
                                {
                                    kind: "fruit",
                                    at: 0.9,
                                    form: 8,
                                    size: 4.4,
                                    hang: 4,
                                    emerge: [0.8, 1]
                                }
                            ]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 11,
                    depth: 8,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 1.755,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 3.64,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 3.64,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "briar", name: "Briar Rose", family: "bramble",
            program: [
                {
                    kind: "stem",
                    w0: 2.6,
                    w1: 1.2,
                    len: 42,
                    curve: -0.06,
                    lean: 0.06,
                    thorns: 9,
                    thornSize: 3.2,
                    emerge: [0, 0.55],
                    children: [
                        {
                            kind: "leaf",
                            at: 0.28,
                            angle: -1.02,
                            form: 12,
                            size: 15,
                            emerge: [0.16, 0.48]
                        },
                        {
                            kind: "leaf",
                            at: 0.52,
                            angle: 0.96,
                            form: 12,
                            size: 14,
                            emerge: [0.22, 0.54]
                        },
                        {
                            kind: "bloom",
                            at: 1,
                            petals: 5,
                            form: 0,
                            size: 12,
                            emerge: [0.6, 0.86]
                        },
                        {
                            kind: "fruit",
                            at: 0.66,
                            form: 3,
                            size: 5,
                            hang: 3,
                            emerge: [0.86, 1]
                        },
                        {
                            kind: "fruit",
                            at: 0.84,
                            form: 3,
                            size: 4.6,
                            hang: 3,
                            emerge: [0.9, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 7,
                    depth: 9,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 2.295,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 4.76,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 4.76,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "gooseberry", name: "Gooseberry", family: "bramble",
            program: [
                {
                    kind: "stem",
                    w0: 3.2,
                    w1: 2.4,
                    len: 14,
                    thorns: 2,
                    emerge: [0, 0.3],
                    children: [
                        {
                            kind: "branch",
                            at: 1,
                            angle: -1.05,
                            scale: 0.8,
                            len: 24,
                            curve: -0.3,
                            w0: 2,
                            w1: 0.9,
                            thorns: 5,
                            thornSize: 2.4,
                            emerge: [0.24, 0.7],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0.44,
                                    angle: 0.9,
                                    form: 8,
                                    size: 11,
                                    emerge: [0.34, 0.7]
                                },
                                {
                                    kind: "leaf",
                                    at: 0.82,
                                    angle: -0.86,
                                    form: 8,
                                    size: 10,
                                    emerge: [0.42, 0.78]
                                },
                                {
                                    kind: "fruit",
                                    at: 0.7,
                                    form: 0,
                                    size: 5,
                                    hang: 5,
                                    emerge: [0.72, 1]
                                },
                                {
                                    kind: "fruit",
                                    at: 0.94,
                                    form: 0,
                                    size: 4.6,
                                    hang: 5,
                                    emerge: [0.78, 1]
                                }
                            ]
                        },
                        {
                            kind: "branch",
                            at: 1,
                            angle: -0.34,
                            scale: 0.9,
                            len: 26,
                            curve: -0.12,
                            w0: 2,
                            w1: 0.9,
                            thorns: 5,
                            thornSize: 2.4,
                            emerge: [0.2, 0.66],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0.42,
                                    angle: -0.94,
                                    form: 8,
                                    size: 12,
                                    emerge: [0.3, 0.66]
                                },
                                {
                                    kind: "leaf",
                                    at: 0.8,
                                    angle: 0.88,
                                    form: 8,
                                    size: 10,
                                    emerge: [0.4, 0.76]
                                },
                                {
                                    kind: "fruit",
                                    at: 0.72,
                                    form: 0,
                                    size: 5.2,
                                    hang: 5,
                                    emerge: [0.7, 1]
                                }
                            ]
                        },
                        {
                            kind: "branch",
                            at: 1,
                            angle: 0.36,
                            scale: 0.9,
                            len: 25,
                            curve: 0.14,
                            w0: 2,
                            w1: 0.9,
                            thorns: 5,
                            thornSize: 2.4,
                            emerge: [0.22, 0.68],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0.46,
                                    angle: 0.92,
                                    form: 8,
                                    size: 11,
                                    emerge: [0.32, 0.68]
                                },
                                {
                                    kind: "leaf",
                                    at: 0.84,
                                    angle: -0.84,
                                    form: 8,
                                    size: 10,
                                    emerge: [0.42, 0.78]
                                },
                                {
                                    kind: "fruit",
                                    at: 0.76,
                                    form: 0,
                                    size: 4.8,
                                    hang: 5,
                                    emerge: [0.74, 1]
                                }
                            ]
                        },
                        {
                            kind: "branch",
                            at: 1,
                            angle: 1.08,
                            scale: 0.8,
                            len: 23,
                            curve: 0.32,
                            w0: 2,
                            w1: 0.9,
                            thorns: 4,
                            thornSize: 2.4,
                            emerge: [0.26, 0.72],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0.48,
                                    angle: -0.9,
                                    form: 8,
                                    size: 10,
                                    emerge: [0.36, 0.72]
                                },
                                {
                                    kind: "fruit",
                                    at: 0.86,
                                    form: 0,
                                    size: 4.4,
                                    hang: 5,
                                    emerge: [0.78, 1]
                                }
                            ]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 11,
                    depth: 7,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 1.62,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 3.36,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 3.36,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "sloe", name: "Sloe", family: "bramble",
            program: [
                {
                    kind: "stem",
                    w0: 4,
                    w1: 2.2,
                    len: 26,
                    curve: 0.04,
                    thorns: 4,
                    thornSize: 3.6,
                    emerge: [0, 0.42],
                    children: [
                        {
                            kind: "branch",
                            at: 0.62,
                            angle: -0.86,
                            scale: 0.7,
                            len: 24,
                            curve: -0.16,
                            w0: 2.4,
                            w1: 1,
                            thorns: 5,
                            thornSize: 3.4,
                            emerge: [0.34, 0.78],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0.5,
                                    angle: 0.98,
                                    form: 2,
                                    size: 11,
                                    emerge: [0.44, 0.8]
                                },
                                {
                                    kind: "leaf",
                                    at: 0.86,
                                    angle: -0.92,
                                    form: 2,
                                    size: 10,
                                    emerge: [0.52, 0.86]
                                },
                                {
                                    kind: "fruit",
                                    at: 0.72,
                                    form: 2,
                                    size: 4.6,
                                    hang: 3,
                                    emerge: [0.76, 1]
                                }
                            ]
                        },
                        {
                            kind: "branch",
                            at: 0.88,
                            angle: 0.78,
                            scale: 0.78,
                            len: 26,
                            curve: 0.18,
                            w0: 2.4,
                            w1: 1,
                            thorns: 5,
                            thornSize: 3.4,
                            emerge: [0.3, 0.74],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0.46,
                                    angle: -1.02,
                                    form: 2,
                                    size: 12,
                                    emerge: [0.4, 0.76]
                                },
                                {
                                    kind: "leaf",
                                    at: 0.84,
                                    angle: 0.94,
                                    form: 2,
                                    size: 10,
                                    emerge: [0.5, 0.84]
                                },
                                {
                                    kind: "fruit",
                                    at: 0.7,
                                    form: 2,
                                    size: 4.8,
                                    hang: 3,
                                    emerge: [0.74, 1]
                                },
                                {
                                    kind: "fruit",
                                    at: 0.96,
                                    form: 2,
                                    size: 4.2,
                                    hang: 3,
                                    emerge: [0.82, 1]
                                }
                            ]
                        },
                        {
                            kind: "branch",
                            at: 1,
                            angle: -0.1,
                            scale: 0.6,
                            len: 20,
                            w0: 2.2,
                            w1: 1,
                            thorns: 4,
                            thornSize: 3.2,
                            emerge: [0.4, 0.84],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0.6,
                                    angle: 0.9,
                                    form: 2,
                                    size: 10,
                                    emerge: [0.5, 0.86]
                                },
                                {
                                    kind: "fruit",
                                    at: 0.9,
                                    form: 2,
                                    size: 4.4,
                                    hang: 3,
                                    emerge: [0.8, 1]
                                }
                            ]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 9,
                    depth: 10,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 2.7,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 5.6,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 5.6,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "hawthorn", name: "Hawthorn", family: "bramble",
            program: [
                {
                    kind: "stem",
                    w0: 4.6,
                    w1: 2.6,
                    len: 24,
                    curve: -0.03,
                    thorns: 3,
                    thornSize: 3.8,
                    emerge: [0, 0.4],
                    children: [
                        {
                            kind: "branch",
                            at: 0.7,
                            angle: -1.02,
                            scale: 0.72,
                            len: 28,
                            curve: -0.34,
                            w0: 2.6,
                            w1: 1.1,
                            thorns: 5,
                            thornSize: 3,
                            emerge: [0.3, 0.76],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0.48,
                                    angle: 0.92,
                                    form: 13,
                                    size: 13,
                                    emerge: [0.4, 0.78]
                                },
                                {
                                    kind: "leaf",
                                    at: 0.86,
                                    angle: -0.88,
                                    form: 13,
                                    size: 12,
                                    emerge: [0.48, 0.84]
                                },
                                {
                                    kind: "fruit",
                                    at: 0.7,
                                    form: 0,
                                    size: 3.8,
                                    hang: 2,
                                    emerge: [0.78, 1]
                                },
                                {
                                    kind: "fruit",
                                    at: 0.86,
                                    form: 0,
                                    size: 3.6,
                                    hang: 2,
                                    emerge: [0.82, 1]
                                }
                            ]
                        },
                        {
                            kind: "branch",
                            at: 0.9,
                            angle: 0.94,
                            scale: 0.76,
                            len: 30,
                            curve: 0.3,
                            w0: 2.6,
                            w1: 1.1,
                            thorns: 5,
                            thornSize: 3,
                            emerge: [0.26, 0.72],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0.44,
                                    angle: -0.96,
                                    form: 13,
                                    size: 14,
                                    emerge: [0.36, 0.74]
                                },
                                {
                                    kind: "leaf",
                                    at: 0.82,
                                    angle: 0.9,
                                    form: 13,
                                    size: 12,
                                    emerge: [0.46, 0.82]
                                },
                                {
                                    kind: "fruit",
                                    at: 0.72,
                                    form: 0,
                                    size: 4,
                                    hang: 2,
                                    emerge: [0.76, 1]
                                },
                                {
                                    kind: "fruit",
                                    at: 0.9,
                                    form: 0,
                                    size: 3.6,
                                    hang: 2,
                                    emerge: [0.8, 1]
                                }
                            ]
                        },
                        {
                            kind: "branch",
                            at: 1,
                            angle: -0.06,
                            scale: 0.66,
                            len: 26,
                            w0: 2.4,
                            w1: 1,
                            thorns: 4,
                            thornSize: 3,
                            emerge: [0.34, 0.8],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0.56,
                                    angle: 0.94,
                                    form: 13,
                                    size: 12,
                                    emerge: [0.44, 0.82]
                                },
                                {
                                    kind: "leaf",
                                    at: 0.9,
                                    angle: -0.9,
                                    form: 13,
                                    size: 11,
                                    emerge: [0.52, 0.88]
                                },
                                {
                                    kind: "fruit",
                                    at: 0.94,
                                    form: 0,
                                    size: 3.8,
                                    hang: 2,
                                    emerge: [0.8, 1]
                                }
                            ]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 10,
                    depth: 10,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 2.43,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 5.04,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 5.04,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
    ];
    return _s;
}

/// FAMILY: FUNGUS - 6 species: Toadstool, Bracket, Coral Fungus, Puffball, Morel, Inkcap.
function vrd_species_fungus() {
    static _s = [
        {
            id: "toadstool", name: "Toadstool", family: "fungus",
            program: [
                {
                    kind: "stem",
                    w0: 6,
                    w1: 4.2,
                    len: 19,
                    curve: -0.04,
                    emerge: [0, 0.42],
                    children: [
                        {
                            kind: "crown",
                            at: 1,
                            form: 8,
                            size: 19,
                            emerge: [0, 0.92]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 13,
                    depth: 5,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 5.28,
                    form: 2,
                    emerge: [0, 0.03],
                    wither: [0.22, 0.52]
                }
            ]
        },
        {
            id: "bracket", name: "Bracket", family: "fungus",
            program: [
                {
                    kind: "stem",
                    w0: 6,
                    w1: 5,
                    len: 6,
                    emerge: [0, 0.2],
                    children: [
                        {
                            kind: "crown",
                            at: 1,
                            form: 9,
                            size: 24,
                            emerge: [0, 0.92]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 9,
                    depth: 4,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 4.4,
                    form: 2,
                    emerge: [0, 0.03],
                    wither: [0.22, 0.52]
                }
            ]
        },
        {
            id: "coral", name: "Coral Fungus", family: "fungus",
            program: [
                {
                    kind: "stem",
                    w0: 3.6,
                    w1: 3,
                    len: 5,
                    emerge: [0, 0.18],
                    children: [
                        {
                            kind: "crown",
                            at: 1,
                            form: 10,
                            size: 34,
                            emerge: [0, 0.92]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 8,
                    depth: 5,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 3.74,
                    form: 2,
                    emerge: [0, 0.03],
                    wither: [0.22, 0.52]
                }
            ]
        },
        {
            id: "puffball", name: "Puffball", family: "fungus",
            program: [
                {
                    kind: "stem",
                    w0: 7,
                    w1: 6.4,
                    len: 5,
                    emerge: [0, 0.16],
                    children: [
                        {
                            kind: "crown",
                            at: 1,
                            form: 11,
                            size: 21,
                            emerge: [0, 0.92]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 12,
                    depth: 4,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 6.38,
                    form: 2,
                    emerge: [0, 0.03],
                    wither: [0.22, 0.52]
                }
            ]
        },
        {
            id: "morel", name: "Morel", family: "fungus",
            program: [
                {
                    kind: "stem",
                    w0: 7.6,
                    w1: 6.8,
                    len: 7,
                    emerge: [0, 0.26],
                    children: [
                        {
                            kind: "crown",
                            at: 1,
                            form: 12,
                            size: 26,
                            emerge: [0, 0.92]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 9,
                    depth: 5,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 4.84,
                    form: 2,
                    emerge: [0, 0.03],
                    wither: [0.22, 0.52]
                }
            ]
        },
        {
            id: "inkcap", name: "Inkcap", family: "fungus",
            program: [
                {
                    kind: "stem",
                    w0: 2.6,
                    w1: 1.8,
                    len: 30,
                    curve: 0.05,
                    emerge: [0, 0.48],
                    children: [
                        {
                            kind: "crown",
                            at: 1,
                            form: 13,
                            size: 22,
                            emerge: [0, 0.92]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 7,
                    depth: 6,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 3.52,
                    form: 2,
                    emerge: [0, 0.03],
                    wither: [0.22, 0.52]
                }
            ]
        },
    ];
    return _s;
}

/// FAMILY: ARBOR - 6 species: Sapling, Oak, Fig, Olive, Pine, Willow.
function vrd_species_arbor() {
    static _s = [
        {
            id: "sapling", name: "Sapling", family: "arbor",
            program: [
                {
                    kind: "stem",
                    w0: 3.4,
                    w1: 1.6,
                    len: 30,
                    curve: 0.05,
                    emerge: [0, 0.55],
                    children: [
                        {
                            kind: "branch",
                            at: 0.58,
                            angle: -0.8,
                            scale: 0.6,
                            len: 14,
                            curve: -0.14,
                            w0: 1.8,
                            w1: 0.9,
                            emerge: [0.42, 0.86]
                        },
                        {
                            kind: "branch",
                            at: 0.78,
                            angle: 0.72,
                            scale: 0.6,
                            len: 12,
                            curve: 0.16,
                            w0: 1.8,
                            w1: 0.9,
                            emerge: [0.48, 0.9]
                        },
                        {
                            kind: "crown",
                            at: 1,
                            form: 18,
                            size: 15,
                            emerge: [0.3, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 9,
                    depth: 11,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 2.97,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 6.16,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 6.16,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "oak", name: "Oak", family: "arbor",
            program: [
                {
                    kind: "stem",
                    w0: 7,
                    w1: 3.4,
                    len: 26,
                    curve: -0.02,
                    emerge: [0, 0.5],
                    children: [
                        {
                            kind: "branch",
                            at: 0.55,
                            angle: -0.92,
                            scale: 0.75,
                            len: 20,
                            curve: -0.24,
                            w0: 3.4,
                            w1: 1.4,
                            emerge: [0.36, 0.8],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0.9,
                                    angle: 0.9,
                                    form: 13,
                                    size: 9,
                                    emerge: [0.66, 1]
                                }
                            ]
                        },
                        {
                            kind: "branch",
                            at: 0.78,
                            angle: 0.86,
                            scale: 0.78,
                            len: 21,
                            curve: 0.22,
                            w0: 3.4,
                            w1: 1.4,
                            emerge: [0.34, 0.78],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0.9,
                                    angle: -0.9,
                                    form: 13,
                                    size: 9,
                                    emerge: [0.64, 1]
                                }
                            ]
                        },
                        {
                            kind: "branch",
                            at: 1,
                            angle: -0.08,
                            scale: 0.7,
                            len: 17,
                            w0: 3,
                            w1: 1.3,
                            emerge: [0.4, 0.84]
                        },
                        {
                            kind: "crown",
                            at: 1,
                            form: 14,
                            size: 22,
                            emerge: [0.3, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 15,
                    depth: 13,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 4.725,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 9.8,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 9.8,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "fig", name: "Fig", family: "arbor",
            program: [
                {
                    kind: "stem",
                    w0: 5.4,
                    w1: 3,
                    len: 20,
                    curve: 0.06,
                    emerge: [0, 0.45],
                    children: [
                        {
                            kind: "branch",
                            at: 0.7,
                            angle: -1.1,
                            scale: 0.62,
                            len: 18,
                            curve: -0.3,
                            w0: 2.6,
                            w1: 1.2,
                            emerge: [0.34, 0.78],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0.95,
                                    angle: 0.85,
                                    form: 10,
                                    size: 13,
                                    emerge: [0.58, 1]
                                }
                            ]
                        },
                        {
                            kind: "branch",
                            at: 0.92,
                            angle: 1.06,
                            scale: 0.66,
                            len: 19,
                            curve: 0.28,
                            w0: 2.6,
                            w1: 1.2,
                            emerge: [0.32, 0.76],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0.95,
                                    angle: -0.85,
                                    form: 10,
                                    size: 14,
                                    emerge: [0.56, 1]
                                }
                            ]
                        },
                        {
                            kind: "crown",
                            at: 1,
                            form: 14,
                            size: 16,
                            emerge: [0.32, 1]
                        },
                        {
                            kind: "fruit",
                            at: 0.66,
                            form: 0,
                            size: 6,
                            hang: 2,
                            emerge: [0.76, 1]
                        },
                        {
                            kind: "fruit",
                            at: 0.86,
                            form: 0,
                            size: 5.4,
                            hang: 2,
                            emerge: [0.82, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 11,
                    depth: 10,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 2.16,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 4.48,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 4.48,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "olive", name: "Olive", family: "arbor",
            program: [
                {
                    kind: "stem",
                    w0: 5.8,
                    w1: 3,
                    len: 22,
                    curve: 0.16,
                    lean: -0.12,
                    emerge: [0, 0.48],
                    children: [
                        {
                            kind: "branch",
                            at: 0.6,
                            angle: -1.2,
                            scale: 0.6,
                            len: 16,
                            curve: -0.34,
                            w0: 2.6,
                            w1: 1.2,
                            emerge: [0.36, 0.8],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0.9,
                                    angle: 0.95,
                                    form: 2,
                                    size: 10,
                                    emerge: [0.6, 1]
                                }
                            ]
                        },
                        {
                            kind: "branch",
                            at: 0.88,
                            angle: 1.14,
                            scale: 0.62,
                            len: 17,
                            curve: 0.3,
                            w0: 2.6,
                            w1: 1.2,
                            emerge: [0.34, 0.78],
                            children: [
                                {
                                    kind: "leaf",
                                    at: 0.9,
                                    angle: -0.95,
                                    form: 2,
                                    size: 10,
                                    emerge: [0.58, 1]
                                }
                            ]
                        },
                        {
                            kind: "crown",
                            at: 1,
                            form: 17,
                            size: 17,
                            emerge: [0.32, 1]
                        },
                        {
                            kind: "fruit",
                            at: 0.74,
                            form: 2,
                            size: 3.6,
                            hang: 2,
                            emerge: [0.8, 1]
                        },
                        {
                            kind: "fruit",
                            at: 0.92,
                            form: 2,
                            size: 3.4,
                            hang: 2,
                            emerge: [0.84, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 13,
                    depth: 11,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 3.51,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 7.28,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 7.28,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "pine", name: "Pine", family: "arbor",
            program: [
                {
                    kind: "stem",
                    w0: 4.6,
                    w1: 1.8,
                    len: 32,
                    curve: 0.01,
                    emerge: [0, 0.55],
                    children: [
                        {
                            kind: "branch",
                            at: 0.42,
                            angle: -1.24,
                            scale: 0.5,
                            len: 11,
                            w0: 1.8,
                            w1: 0.8,
                            emerge: [0.46, 0.88]
                        },
                        {
                            kind: "branch",
                            at: 0.6,
                            angle: 1.2,
                            scale: 0.5,
                            len: 10,
                            w0: 1.8,
                            w1: 0.8,
                            emerge: [0.5, 0.92]
                        },
                        {
                            kind: "crown",
                            at: 1,
                            form: 15,
                            size: 17,
                            emerge: [0.28, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 12,
                    depth: 14,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 3.105,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 6.44,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 6.44,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
        {
            id: "willow", name: "Willow", family: "arbor",
            program: [
                {
                    kind: "stem",
                    w0: 5,
                    w1: 2.2,
                    len: 30,
                    curve: -0.14,
                    lean: 0.16,
                    emerge: [0, 0.52],
                    children: [
                        {
                            kind: "branch",
                            at: 0.66,
                            angle: -0.96,
                            scale: 0.56,
                            len: 15,
                            curve: -0.26,
                            w0: 2.2,
                            w1: 1,
                            emerge: [0.38, 0.82]
                        },
                        {
                            kind: "branch",
                            at: 0.9,
                            angle: 0.9,
                            scale: 0.58,
                            len: 16,
                            curve: 0.24,
                            w0: 2.2,
                            w1: 1,
                            emerge: [0.36, 0.8]
                        },
                        {
                            kind: "crown",
                            at: 1,
                            form: 16,
                            size: 18,
                            emerge: [0.3, 1]
                        }
                    ]
                },
                {
                    kind: "root",
                    spread: 13,
                    depth: 12,
                    emerge: [0, 0.35]
                },
                {
                    kind: "seed",
                    size: 1.35,
                    form: 1,
                    emerge: [0, 0.02],
                    wither: [0.16, 0.44]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: -1.3,
                    form: 1,
                    size: 2.8,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                },
                {
                    kind: "leaf",
                    at: 0,
                    angle: 1.3,
                    form: 1,
                    size: 2.8,
                    emerge: [0.03, 0.16],
                    wither: [0.34, 0.58]
                }
            ]
        },
    ];
    return _s;
}

/// THE CORPUS: every family in authored order. This order IS the save format - see the
/// append-only warning in the header.
function vrd_species_corpus() {
    static _c = undefined;
    if (_c == undefined) {
        _c = [];
        array_copy(_c, array_length(_c), vrd_species_grain(), 0, array_length(vrd_species_grain()));
        array_copy(_c, array_length(_c), vrd_species_bloom(), 0, array_length(vrd_species_bloom()));
        array_copy(_c, array_length(_c), vrd_species_succulent(), 0, array_length(vrd_species_succulent()));
        array_copy(_c, array_length(_c), vrd_species_root(), 0, array_length(vrd_species_root()));
        array_copy(_c, array_length(_c), vrd_species_vine(), 0, array_length(vrd_species_vine()));
        array_copy(_c, array_length(_c), vrd_species_bramble(), 0, array_length(vrd_species_bramble()));
        array_copy(_c, array_length(_c), vrd_species_fungus(), 0, array_length(vrd_species_fungus()));
        array_copy(_c, array_length(_c), vrd_species_arbor(), 0, array_length(vrd_species_arbor()));
    }
    return _c;
}

/// Look a species up by its id. Linear, and deliberately so: 48 entries is nothing, and a cached
/// map would be one more thing that can disagree with the array the save format indexes into.
function vrd_species_by_id(_id) {
    var _c = vrd_species_corpus();
    for (var i = 0; i < array_length(_c); i++) if (_c[i].id == _id) return _c[i];
    return undefined;
}

/// ── PALETTES ────────────────────────────────────────────────────────────────────────────────
/// role -> colour, as {r,g,b} COMPONENTS, never a hex literal: GML's `$` hex constants are ABGR,
/// so `$7d9147` is not the colour that string means anywhere else and the inversion is silent.
/// `verdure_render` calls make_colour_rgb on these immediately before drawing.
///
/// A PALETTE MAY NEVER BE HOW TWO SPECIES BECOME DISTINCT. The shape gate runs on geometry with
/// no palette applied at all, precisely because recolouring is the cheap way to fake variety.
/// Colour here is for beauty and for making a PART legible against its own plant.
function vrd_palette_family() {
    static _p = {
        grain: {
            stem: { r: 125, g: 145, b: 71 },
            stemDark: { r: 92, g: 109, b: 51 },
            leafLight: { r: 156, g: 178, b: 87 },
            leafDark: { r: 108, g: 128, b: 56 },
            vein: { r: 135, g: 160, b: 76 },
            ink: { r: 59, g: 74, b: 36 },
            crown: { r: 217, g: 189, b: 106 },
            crownDark: { r: 168, g: 134, b: 60 },
            bloom: { r: 230, g: 215, b: 154 },
            bloomDark: { r: 179, g: 154, b: 85 },
            centre: { r: 243, g: 232, b: 189 },
            fruit: { r: 201, g: 164, b: 94 },
            fruitLight: { r: 226, g: 200, b: 135 },
            root: { r: 107, g: 90, b: 68 },
            seed: { r: 185, g: 160, b: 119 },
            seedDark: { r: 111, g: 92, b: 63 },
            crownLight: { r: 217, g: 189, b: 106 },
            thorn: { r: 92, g: 109, b: 51 }
        },
        bloom: {
            stem: { r: 111, g: 143, b: 74 },
            stemDark: { r: 79, g: 106, b: 51 },
            leafLight: { r: 143, g: 184, b: 92 },
            leafDark: { r: 94, g: 128, b: 56 },
            vein: { r: 123, g: 162, b: 78 },
            ink: { r: 51, g: 70, b: 31 },
            crown: { r: 217, g: 189, b: 106 },
            crownDark: { r: 168, g: 134, b: 60 },
            bloom: { r: 226, g: 154, b: 196 },
            bloomDark: { r: 176, g: 107, b: 147 },
            centre: { r: 246, g: 224, b: 138 },
            fruit: { r: 196, g: 89, b: 63 },
            fruitLight: { r: 224, g: 138, b: 106 },
            root: { r: 107, g: 90, b: 68 },
            seed: { r: 185, g: 160, b: 119 },
            seedDark: { r: 111, g: 92, b: 63 },
            crownLight: { r: 217, g: 189, b: 106 },
            thorn: { r: 79, g: 106, b: 51 }
        },
        root: {
            stem: { r: 111, g: 143, b: 74 },
            stemDark: { r: 79, g: 106, b: 51 },
            leafLight: { r: 140, g: 181, b: 86 },
            leafDark: { r: 92, g: 125, b: 52 },
            vein: { r: 121, g: 160, b: 71 },
            ink: { r: 47, g: 66, b: 29 },
            crown: { r: 217, g: 189, b: 106 },
            crownDark: { r: 168, g: 134, b: 60 },
            bloom: { r: 232, g: 224, b: 240 },
            bloomDark: { r: 176, g: 166, b: 192 },
            centre: { r: 242, g: 228, b: 168 },
            fruit: { r: 196, g: 89, b: 63 },
            fruitLight: { r: 224, g: 138, b: 106 },
            tuber: { r: 217, g: 138, b: 68 },
            tuberLight: { r: 240, g: 176, b: 106 },
            tuberDark: { r: 156, g: 90, b: 38 },
            root: { r: 107, g: 90, b: 68 },
            seed: { r: 185, g: 160, b: 119 },
            seedDark: { r: 111, g: 92, b: 63 },
            crownLight: { r: 217, g: 189, b: 106 },
            thorn: { r: 79, g: 106, b: 51 }
        },
        succulent: {
            stem: { r: 127, g: 160, b: 106 },
            stemDark: { r: 92, g: 122, b: 76 },
            leafLight: { r: 168, g: 201, b: 138 },
            leafDark: { r: 111, g: 148, b: 99 },
            vein: { r: 147, g: 180, b: 120 },
            ink: { r: 58, g: 81, b: 54 },
            crown: { r: 207, g: 224, b: 168 },
            crownDark: { r: 154, g: 178, b: 120 },
            bloom: { r: 232, g: 165, b: 106 },
            bloomDark: { r: 184, g: 118, b: 63 },
            centre: { r: 247, g: 223, b: 168 },
            fruit: { r: 212, g: 116, b: 74 },
            fruitLight: { r: 237, g: 163, b: 123 },
            root: { r: 107, g: 90, b: 68 },
            seed: { r: 185, g: 160, b: 119 },
            seedDark: { r: 111, g: 92, b: 63 },
            crownLight: { r: 207, g: 224, b: 168 },
            thorn: { r: 92, g: 122, b: 76 }
        },
        vine: {
            stem: { r: 107, g: 143, b: 78 },
            stemDark: { r: 74, g: 106, b: 53 },
            leafLight: { r: 143, g: 184, b: 95 },
            leafDark: { r: 91, g: 128, b: 56 },
            vein: { r: 121, g: 162, b: 78 },
            ink: { r: 47, g: 70, b: 32 },
            crown: { r: 207, g: 217, b: 138 },
            crownLight: { r: 228, g: 236, b: 180 },
            crownDark: { r: 150, g: 163, b: 85 },
            bloom: { r: 239, g: 231, b: 192 },
            bloomDark: { r: 185, g: 174, b: 134 },
            centre: { r: 244, g: 233, b: 168 },
            fruit: { r: 125, g: 91, b: 156 },
            fruitLight: { r: 168, g: 135, b: 196 },
            thorn: { r: 143, g: 156, b: 94 },
            root: { r: 107, g: 90, b: 68 },
            seed: { r: 192, g: 168, b: 124 },
            seedDark: { r: 117, g: 96, b: 63 }
        },
        bramble: {
            stem: { r: 138, g: 154, b: 82 },
            stemDark: { r: 74, g: 87, b: 48 },
            leafLight: { r: 127, g: 166, b: 79 },
            leafDark: { r: 79, g: 112, b: 48 },
            vein: { r: 107, g: 144, b: 66 },
            ink: { r: 42, g: 58, b: 28 },
            crown: { r: 207, g: 217, b: 138 },
            crownLight: { r: 228, g: 236, b: 180 },
            crownDark: { r: 150, g: 163, b: 85 },
            bloom: { r: 240, g: 200, b: 216 },
            bloomDark: { r: 185, g: 139, b: 160 },
            centre: { r: 244, g: 224, b: 138 },
            fruit: { r: 140, g: 47, b: 70 },
            fruitLight: { r: 196, g: 103, b: 124 },
            thorn: { r: 217, g: 201, b: 160 },
            root: { r: 107, g: 90, b: 68 },
            seed: { r: 168, g: 144, b: 112 },
            seedDark: { r: 102, g: 83, b: 56 }
        },
        fungus: {
            stem: { r: 224, g: 214, b: 196 },
            stemDark: { r: 176, g: 164, b: 142 },
            leafLight: { r: 216, g: 204, b: 184 },
            leafDark: { r: 168, g: 152, b: 128 },
            vein: { r: 196, g: 182, b: 158 },
            ink: { r: 61, g: 50, b: 38 },
            crown: { r: 196, g: 86, b: 47 },
            crownLight: { r: 224, g: 138, b: 90 },
            crownDark: { r: 138, g: 54, b: 28 },
            bloom: { r: 232, g: 216, b: 192 },
            bloomDark: { r: 176, g: 160, b: 134 },
            centre: { r: 240, g: 228, b: 204 },
            fruit: { r: 196, g: 86, b: 47 },
            fruitLight: { r: 224, g: 138, b: 90 },
            thorn: { r: 176, g: 164, b: 142 },
            root: { r: 122, g: 106, b: 82 },
            seed: { r: 216, g: 204, b: 176 },
            seedDark: { r: 138, g: 122, b: 94 }
        },
        arbor: {
            stem: { r: 173, g: 139, b: 94 },
            stemDark: { r: 92, g: 70, b: 48 },
            leafLight: { r: 126, g: 168, b: 85 },
            leafDark: { r: 78, g: 114, b: 51 },
            vein: { r: 106, g: 146, b: 71 },
            ink: { r: 43, g: 61, b: 30 },
            crown: { r: 93, g: 138, b: 62 },
            crownLight: { r: 132, g: 176, b: 92 },
            crownDark: { r: 60, g: 95, b: 40 },
            bloom: { r: 240, g: 228, b: 192 },
            bloomDark: { r: 184, g: 169, b: 134 },
            centre: { r: 244, g: 224, b: 138 },
            fruit: { r: 122, g: 74, b: 108 },
            fruitLight: { r: 168, g: 122, b: 156 },
            thorn: { r: 168, g: 144, b: 112 },
            root: { r: 107, g: 90, b: 68 },
            seed: { r: 176, g: 140, b: 88 },
            seedDark: { r: 107, g: 83, b: 48 }
        }
    };
    return _p;
}

/// Per-species accent overrides - the head, the flower, the harvest. Authored content.
function vrd_palette_accent() {
    static _p = {
        wheat: {
            crown: { r: 227, g: 197, b: 116 },
            crownDark: { r: 172, g: 139, b: 62 }
        },
        barley: {
            crown: { r: 216, g: 201, b: 141 },
            crownDark: { r: 162, g: 146, b: 85 }
        },
        rye: {
            crown: { r: 185, g: 172, b: 122 },
            crownDark: { r: 135, g: 124, b: 79 },
            leafLight: { r: 147, g: 173, b: 99 }
        },
        millet: {
            crown: { r: 224, g: 180, b: 90 },
            crownDark: { r: 168, g: 128, b: 47 }
        },
        oat: {
            crown: { r: 220, g: 201, b: 143 },
            crownDark: { r: 164, g: 145, b: 90 }
        },
        sorghum: {
            crown: { r: 196, g: 106, b: 74 },
            crownDark: { r: 141, g: 69, b: 44 },
            stem: { r: 135, g: 149, b: 74 }
        },
        poppy: {
            bloom: { r: 217, g: 79, b: 74 },
            bloomDark: { r: 150, g: 47, b: 44 },
            centre: { r: 46, g: 42, b: 36 }
        },
        aster: {
            bloom: { r: 167, g: 154, b: 214 },
            bloomDark: { r: 111, g: 98, b: 159 },
            centre: { r: 242, g: 217, b: 138 }
        },
        iris: {
            bloom: { r: 143, g: 127, b: 209 },
            bloomDark: { r: 91, g: 77, b: 150 },
            centre: { r: 240, g: 201, b: 94 }
        },
        foxglove: {
            bloom: { r: 217, g: 142, b: 196 },
            bloomDark: { r: 156, g: 92, b: 140 }
        },
        thistle: {
            bloom: { r: 180, g: 135, b: 210 },
            bloomDark: { r: 111, g: 79, b: 140 }
        },
        campanula: {
            bloom: { r: 123, g: 168, b: 222 },
            bloomDark: { r: 75, g: 113, b: 164 }
        },
        aloe: {
            leafLight: { r: 143, g: 184, b: 126 },
            leafDark: { r: 93, g: 128, b: 85 },
            bloom: { r: 224, g: 122, b: 74 }
        },
        agave: {
            leafLight: { r: 157, g: 191, b: 154 },
            leafDark: { r: 100, g: 127, b: 102 },
            ink: { r: 61, g: 81, b: 64 }
        },
        sedum: {
            leafLight: { r: 195, g: 176, b: 106 },
            leafDark: { r: 143, g: 124, b: 69 },
            ink: { r: 74, g: 66, b: 38 }
        },
        echeveria: {
            leafLight: { r: 196, g: 182, b: 207 },
            leafDark: { r: 139, g: 127, b: 155 },
            ink: { r: 74, g: 65, b: 85 }
        },
        haworthia: {
            leafLight: { r: 127, g: 174, b: 114 },
            leafDark: { r: 78, g: 112, b: 73 },
            ink: { r: 47, g: 69, b: 48 }
        },
        crassula: {
            leafLight: { r: 169, g: 196, b: 122 },
            leafDark: { r: 109, g: 138, b: 76 },
            ink: { r: 58, g: 74, b: 38 }
        },
        carrot: {
            tuber: { r: 226, g: 130, b: 47 },
            tuberLight: { r: 245, g: 170, b: 92 },
            tuberDark: { r: 163, g: 82, b: 26 }
        },
        turnip: {
            tuber: { r: 230, g: 223, b: 232 },
            tuberLight: { r: 247, g: 243, b: 248 },
            tuberDark: { r: 143, g: 127, b: 160 }
        },
        parsnip: {
            tuber: { r: 232, g: 220, b: 180 },
            tuberLight: { r: 246, g: 239, b: 210 },
            tuberDark: { r: 168, g: 148, b: 95 }
        },
        potato: {
            tuber: { r: 201, g: 160, b: 106 },
            tuberLight: { r: 224, g: 189, b: 140 },
            tuberDark: { r: 138, g: 100, b: 56 }
        },
        onion: {
            tuber: { r: 217, g: 174, b: 98 },
            tuberLight: { r: 240, g: 207, b: 150 },
            tuberDark: { r: 156, g: 116, b: 52 }
        },
        mandrake: {
            tuber: { r: 205, g: 191, b: 160 },
            tuberLight: { r: 230, g: 220, b: 196 },
            tuberDark: { r: 138, g: 122, b: 92 },
            bloom: { r: 232, g: 224, b: 240 }
        },
        bean: {
            fruit: { r: 200, g: 212, b: 136 },
            fruitLight: { r: 232, g: 240, b: 184 }
        },
        pea: {
            fruit: { r: 188, g: 220, b: 132 },
            fruitLight: { r: 224, g: 242, b: 176 },
            leafLight: { r: 158, g: 196, b: 111 }
        },
        grape: {
            fruit: { r: 94, g: 61, b: 122 },
            fruitLight: { r: 143, g: 106, b: 168 }
        },
        gourd: {
            fruit: { r: 217, g: 160, b: 58 },
            fruitLight: { r: 240, g: 196, b: 112 },
            leafLight: { r: 132, g: 168, b: 78 }
        },
        melon: {
            fruit: { r: 122, g: 168, b: 78 },
            fruitLight: { r: 168, g: 200, b: 119 },
            ink: { r: 38, g: 64, b: 28 }
        },
        hop: {
            fruit: { r: 196, g: 207, b: 122 },
            fruitLight: { r: 226, g: 234, b: 168 },
            stem: { r: 125, g: 148, b: 85 }
        },
        raspberry: {
            fruit: { r: 196, g: 64, b: 94 },
            fruitLight: { r: 232, g: 128, b: 152 },
            thorn: { r: 224, g: 207, b: 168 }
        },
        blackberry: {
            fruit: { r: 58, g: 42, b: 74 },
            fruitLight: { r: 111, g: 90, b: 134 },
            thorn: { r: 212, g: 196, b: 156 }
        },
        briar: {
            bloom: { r: 240, g: 168, b: 188 },
            bloomDark: { r: 176, g: 111, b: 136 },
            fruit: { r: 196, g: 68, b: 42 },
            fruitLight: { r: 232, g: 132, b: 106 }
        },
        gooseberry: {
            fruit: { r: 184, g: 196, b: 106 },
            fruitLight: { r: 220, g: 232, b: 148 },
            thorn: { r: 239, g: 226, b: 192 }
        },
        sloe: {
            fruit: { r: 63, g: 74, b: 112 },
            fruitLight: { r: 114, g: 128, b: 168 },
            stem: { r: 138, g: 122, b: 86 },
            stemDark: { r: 63, g: 53, b: 36 }
        },
        hawthorn: {
            fruit: { r: 184, g: 48, b: 42 },
            fruitLight: { r: 224, g: 112, b: 94 },
            leafLight: { r: 132, g: 168, b: 84 },
            stem: { r: 150, g: 130, b: 92 },
            stemDark: { r: 68, g: 58, b: 38 }
        },
        toadstool: {
            crown: { r: 204, g: 58, b: 42 },
            crownLight: { r: 240, g: 240, b: 228 },
            crownDark: { r: 138, g: 36, b: 24 }
        },
        bracket: {
            crown: { r: 168, g: 106, b: 52 },
            crownLight: { r: 224, g: 196, b: 138 },
            crownDark: { r: 107, g: 63, b: 24 }
        },
        coral: {
            crown: { r: 224, g: 168, b: 58 },
            crownLight: { r: 244, g: 212, b: 132 },
            crownDark: { r: 168, g: 116, b: 42 }
        },
        puffball: {
            crown: { r: 221, g: 212, b: 192 },
            crownLight: { r: 244, g: 239, b: 224 },
            crownDark: { r: 160, g: 150, b: 128 }
        },
        morel: {
            crown: { r: 138, g: 106, b: 68 },
            crownLight: { r: 184, g: 148, b: 104 },
            crownDark: { r: 79, g: 58, b: 34 }
        },
        inkcap: {
            crown: { r: 200, g: 191, b: 174 },
            crownLight: { r: 234, g: 228, b: 214 },
            crownDark: { r: 87, g: 73, b: 58 }
        },
        sapling: {
            crown: { r: 122, g: 176, b: 78 },
            crownLight: { r: 160, g: 204, b: 120 },
            crownDark: { r: 79, g: 125, b: 48 }
        },
        oak: {
            crown: { r: 78, g: 122, b: 52 },
            crownLight: { r: 113, g: 156, b: 82 },
            crownDark: { r: 50, g: 82, b: 31 },
            stem: { r: 156, g: 124, b: 82 },
            stemDark: { r: 84, g: 64, b: 42 }
        },
        fig: {
            crown: { r: 107, g: 148, b: 64 },
            crownLight: { r: 148, g: 184, b: 104 },
            crownDark: { r: 68, g: 102, b: 42 },
            fruit: { r: 122, g: 58, b: 94 },
            fruitLight: { r: 168, g: 106, b: 140 }
        },
        olive: {
            crown: { r: 147, g: 165, b: 120 },
            crownLight: { r: 188, g: 201, b: 164 },
            crownDark: { r: 94, g: 109, b: 74 },
            fruit: { r: 63, g: 74, b: 42 },
            fruitLight: { r: 107, g: 122, b: 80 }
        },
        pine: {
            crown: { r: 56, g: 96, b: 60 },
            crownLight: { r: 84, g: 128, b: 87 },
            crownDark: { r: 34, g: 64, b: 31 },
            stem: { r: 125, g: 92, b: 58 }
        },
        willow: {
            crown: { r: 143, g: 176, b: 94 },
            crownLight: { r: 180, g: 204, b: 136 },
            crownDark: { r: 94, g: 125, b: 58 },
            stem: { r: 125, g: 106, b: 78 }
        }
    };
    return _p;
}

/// Soil and paper. Deliberately almost black: the cutaway wants the earth to RECEDE so a carrot
/// is the brightest thing in the cell.
function vrd_palette_ground() {
    static _g = {
        soil: { r: 27, g: 22, b: 16 },
        soilLine: { r: 78, g: 61, b: 41 },
        paper: { r: 21, g: 29, b: 23 }
    };
    return _g;
}

/// The resolved role->colour map for one species: its family base, with its own accents over it.
function vrd_palette_for(_species) {
    var _fam = vrd_palette_family();
    var _base = variable_struct_exists(_fam, _species.family) ? _fam[$ _species.family] : _fam.grain;
    var _out = {};
    var _k = variable_struct_get_names(_base);
    for (var i = 0; i < array_length(_k); i++) _out[$ _k[i]] = _base[$ _k[i]];
    var _acc = vrd_palette_accent();
    if (variable_struct_exists(_acc, _species.id)) {
        var _a = _acc[$ _species.id];
        var _ak = variable_struct_get_names(_a);
        for (var j = 0; j < array_length(_ak); j++) _out[$ _ak[j]] = _a[$ _ak[j]];
    }
    return _out;
}

