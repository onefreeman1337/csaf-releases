/// ============================================================================================
/// VERDURE - verdure_bind: the engine binding.
///
/// Everything impure lives here: the clock, the buyer's registered content, the plot/garden
/// wrapper, the draw-list cache, and the save/load round-trip. `verdure_core` stays a pure
/// function library so it can be mirrored and reasoned about outside GameMaker; this file is where
/// Verdure meets a running game.
///
/// ⛔ THE delta_time CONVERSION HAPPENS IN EXACTLY ONE PLACE - `vrd_dt()`.
///   GameMaker's `delta_time` is MICROSECONDS. Dividing by 1000 instead of 1,000,000 gives
///   animations that run 1000x fast, which reads as "the effect just pops" rather than as a bug,
///   so it survives review. One conversion, one place, never inline.
///
/// ⛔ THE DRAW-LIST CACHE IS NOT AN OPTIMISATION, IT IS THE DIFFERENCE BETWEEN SHIPPABLE AND NOT.
///   Filling a polygon correctly means ear clipping (see verdure_render), which is O(n^2) on a
///   59-point outline. A plant at full growth is ~40 polygons. Re-triangulating 50 plants every
///   frame is not affordable and does not need to be: geometry is a pure function of
///   (species, t, seed), so it only changes when the plant's growth STAGE changes. `vrd_plot_*`
///   rebuilds on a quantised t and redraws the cached list otherwise.
///
/// SAVE FORMAT - versioned from day one, and tiny by design.
///   A plant persists as { v, s, at, lin }: a species seed, a planting time, and a lineage tree if
///   it was bred. Derivation IS the load path, so a save cannot disagree with the generator -
///   there is nothing else stored to disagree with.
///   ⛔ APPEND, NEVER REORDER. A seed resolves into corpus indices. Appending a species is always
///   safe; reordering or removing one silently rewrites every plant a player has grown. Stated
///   here, in verdure_core, and in the Readme - never left as folklore.
///
/// Public API:
///   vrd_dt()                                     -> seconds since the last step
///   vrd_registry_create()                        -> a registry for the buyer's own species
///   vrd_registry_add(reg, species)               -> append one (APPEND ONLY)
///   vrd_corpus(reg)                              -> shipped corpus + registered, cached
///   vrd_garden_create(reg)                       -> a garden: a clock and a list of plots
///   vrd_garden_plant(g, plot, species_seed)      -> sow
///   vrd_garden_step(g)                           -> advance the clock, rebuild what changed
///   vrd_garden_draw(g, x, y, cell, scale)        -> draw every plot in a row
///   vrd_garden_save(g) / vrd_garden_load(reg, s) -> round-trip through a plain struct
/// ============================================================================================

/// Seconds elapsed since the previous step. THE ONLY PLACE `delta_time` IS TOUCHED.
function vrd_dt() { return delta_time / 1000000; }

/// ── CONTENT REGISTRY ────────────────────────────────────────────────────────────────────────
/// The buyer's own species, appended after the shipped corpus so every existing save keeps its
/// identity. Build them with the same struct shape `verdure_preset` uses - a registered species
/// founds, grows and renders exactly like a shipped one.
function vrd_registry_create() {
    return { extra: [], cache: undefined };
}

/// ⚠️ APPEND ONLY, and the guard is here rather than in a comment because this is the one mistake
/// that cannot be undone from a player's save.
function vrd_registry_add(_reg, _species) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_reg) || !is_struct(_species)) return -1;
    array_push(_reg.extra, _species);
    _reg.cache = undefined;                 // the merged corpus must be rebuilt
    return array_length(vrd_species_corpus()) + array_length(_reg.extra) - 1;
}

/// Shipped corpus followed by registered content. Cached, because it is read per plant per rebuild.
function vrd_corpus(_reg) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_reg)) _reg = vrd_registry_create();
    if (_reg == undefined) return vrd_species_corpus();
    if (_reg.cache != undefined) return _reg.cache;
    var _base = vrd_species_corpus();
    var _all = [];
    for (var i = 0; i < array_length(_base); i++) array_push(_all, _base[i]);
    for (var j = 0; j < array_length(_reg.extra); j++) array_push(_all, _reg.extra[j]);
    _reg.cache = _all;
    return _all;
}

/// ── GARDEN ──────────────────────────────────────────────────────────────────────────────────
/// A plot is one growing space. `built` is its cached draw list and `builtStage` is the quantised
/// growth it was built at.
///
/// `VRD_STAGES` is how finely growth is re-rendered. It is 24 rather than 6 so growth reads as
/// continuous rather than as six jumps, while still rebuilding only ~24 times over a plant's whole
/// life instead of 3,600 times a minute.
#macro VRD_STAGES 24

function vrd_garden_create(_reg) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_reg)) _reg = vrd_registry_create();
    return { reg: _reg, now: 0, plots: [] };
}

/// Sow a seed in a plot. `_span` is how long this plant takes to reach full growth, in seconds.
function vrd_garden_plant(_g, _plot, _species_seed, _span) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_g) || !is_numeric(_plot) || !is_numeric(_species_seed) || _plot < 0) return; if (!is_numeric(_span)) _span = 12;
    while (array_length(_g.plots) <= _plot) array_push(_g.plots, undefined);
    _g.plots[_plot] = {
        plant: vrd_plant_create(_species_seed, _g.now),
        span: _span,
        built: undefined,
        builtStage: -1,
    };
}

/// Which corpus entry a plot's seed resolves to, honouring the registry.
function vrd_plot_species(_g, _p) {
    var _c = vrd_corpus(_g.reg);
    return _c[abs(floor(_p.plant.s)) mod array_length(_c)];
}

/// Advance the clock and rebuild only the plots whose STAGE actually changed.
function vrd_garden_step(_g) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_g)) return;
    _g.now += vrd_dt();
    for (var i = 0; i < array_length(_g.plots); i++) {
        var _p = _g.plots[i];
        if (_p == undefined) continue;
        var _t = vrd_plant_t(_p.plant, _g.now, _p.span);
        var _stage = floor(_t * VRD_STAGES);
        if (_stage == _p.builtStage) continue;          // nothing to do: the picture is unchanged
        _p.builtStage = _stage;
        _p.built = vrd_build(vrd_plot_species(_g, _p), _stage / VRD_STAGES, _p.plant.s);
    }
}

/// Draw every plot in a row. `_cell` is the horizontal spacing in pixels, `_scale` pixels per plant
/// unit. `_x, _y` is the SOIL LINE of the first plot - plant space is +y up and the flip happens
/// inside `vrd_draw_built`, so a caller never converts coordinates.
/// ⚠️ THE `lift` IS NOT OPTIONAL AND THIS IS THE RIGHT PLACE FOR IT. Some species - every Succulent,
/// and any plant with a drooping basal leaf - are authored with geometry radiating below their own
/// soil origin, so drawn raw they appear half-buried in the soil band. `vrd_bounds().lift` is how
/// far to raise the drawing so that ONLY root sits underground, and applying it here means a buyer
/// using the garden API gets it for free rather than discovering the problem on their own screen.
function vrd_garden_draw(_g, _x, _y, _cell, _scale) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_g) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_cell) || !is_numeric(_scale)) return;
    for (var i = 0; i < array_length(_g.plots); i++) {
        var _p = _g.plots[i];
        if (_p == undefined || _p.built == undefined) continue;
        var _lift = vrd_bounds(_p.built).lift;
        vrd_draw_built(_p.built, _x + i * _cell, _y - _lift * _scale, _scale);
    }
}

/// ── SAVE / LOAD ─────────────────────────────────────────────────────────────────────────────
/// Plain structs, so a buyer can json_stringify the result or fold it into their own save.
/// Nothing derived is stored: no cached stage, no baked picture, no stroke list.
function vrd_garden_save(_g) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_g)) return undefined;
    var _out = { v: VRD_VERSION, now: _g.now, plots: [] };
    for (var i = 0; i < array_length(_g.plots); i++) {
        var _p = _g.plots[i];
        if (_p == undefined) { array_push(_out.plots, undefined); continue; }
        array_push(_out.plots, { plant: _p.plant, span: _p.span });
    }
    return _out;
}

/// ⚠️ A LOAD FROM A NEWER VERSION IS REFUSED RATHER THAN GUESSED. `v` exists so a deliberate break
/// is migratable; silently loading a format you do not understand is how a player's garden turns
/// into a different garden with no error.
function vrd_garden_load(_reg, _saved) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_reg)) _reg = vrd_registry_create(); if (!is_undefined(_saved) && !is_struct(_saved)) return undefined;
    if (_saved == undefined) return vrd_garden_create(_reg);
    if (_saved.v > VRD_VERSION) {
        show_debug_message("verdure: save version " + string(_saved.v)
            + " is newer than this build (" + string(VRD_VERSION) + ") - refusing to load.");
        return undefined;
    }
    var _g = vrd_garden_create(_reg);
    _g.now = _saved.now;
    for (var i = 0; i < array_length(_saved.plots); i++) {
        var _s = _saved.plots[i];
        if (_s == undefined) { array_push(_g.plots, undefined); continue; }
        array_push(_g.plots, { plant: _s.plant, span: _s.span, built: undefined, builtStage: -1 });
    }
    return _g;
}
