/// ============================================================================================
/// VERDURE - verdure_render: THE FORM VOCABULARY AND THE DRAW LAYER.
///
/// This is where the plants stop being silhouettes. `verdure_core` decides WHERE a part sits and
/// HOW BIG it is at growth t; this file decides WHAT THAT PART LOOKS LIKE, and then draws it.
///
/// ── THE CONTRACT ────────────────────────────────────────────────────────────────────────────
/// Every `vrd_*_parts` function returns a flat array of PRIMITIVES in part-local space:
///
///     { t: "poly", pts: [{x,y}...], role }          filled polygon
///     { t: "line", pts: [{x,y}...], w, role }       polyline, round caps and joins
///     { t: "disc", cx, cy, r, role }                filled circle
///
/// `role` is a STRING, never a colour. The palette maps role -> colour, which is what lets ONE
/// geometry serve 48 species, six growth stages and every cross-bred child. Keeping colour out of
/// geometry is also what keeps the shape gate honest: a pair of species that only separates once it
/// is painted has not separated.
///
/// ⛔ TWO THINGS IN THIS FILE WERE PROVEN BEFORE THEY WERE WRITTEN, because this wing cannot
/// unit-test GML and both fail SILENTLY as "the picture is subtly wrong":
///
///   1. POLYGON FILL IS EAR CLIPPING, NOT A TRIANGLE FAN. A fan is only correct for a polygon that
///      is star-shaped about its centre, and most outlines here are not - a leaf is two arcs
///      meeting at a point, a bell has a scalloped rim, a canopy lobe re-enters. The neighbouring
///      shipped product solves this with a hand-authored fan centre per shape; that cannot work
///      here, because 46 forms are generated and cross-bred shapes do not exist until a player
///      makes one. `Internal_Ops/_probe/probe_earclip.js` ran this exact algorithm over all 3,933
///      polygons the real corpus draws and checked each against its shoelace area: 0 fallbacks,
///      0 mismatches, with a concave control that the naive fan gets wrong.
///   2. THE DE-DUPLICATION IN `__vrd_earclip` IS LOad-BEARING. Without it the probe measured
///      3,059 of 3,933 polygons failing - every leaf, because its outline meets itself at the base
///      and the tip.
/// ============================================================================================

/// ── primitive constructors ──────────────────────────────────────────────────────────────────
function vrd_poly(_pts, _role)            { return { t: "poly", pts: _pts, role: _role }; }
function vrd_line(_pts, _w, _role)        { return { t: "line", pts: _pts, w: _w, role: _role }; }
function vrd_disc(_cx, _cy, _r, _role)    { return { t: "disc", cx: _cx, cy: _cy, r: _r, role: _role }; }

/// Close a point list back onto its first point, for outlining a filled shape.
function __vrd_closed(_pts) {
    var _o = [];
    for (var i = 0; i < array_length(_pts); i++) array_push(_o, _pts[i]);
    if (array_length(_pts) > 0) array_push(_o, _pts[0]);
    return _o;
}

/// Smooth 0->1 over [0, e] - a shoulder, so a leaf base is not a chisel cut.
function vrd_ramp(_f, _e) { return (_f <= 0) ? 0 : ((_f >= _e) ? 1 : sin((_f / _e) * pi * 0.5)); }
/// Smooth 1->0 over [1-e, 1] - a tip. Small e is a sharp point, large e a long taper.
function vrd_fall(_f, _e) { return (_f >= 1) ? 0 : ((_f <= 1 - _e) ? 1 : sin(((1 - _f) / _e) * pi * 0.5)); }

/// ── LEAF PROFILES ───────────────────────────────────────────────────────────────────────────
/// Half-width at parametric position f (0 = base, 1 = tip), as a FRACTION OF LENGTH.
///
/// This function is the difference between fifteen leaf forms and one. Expressing a form as a
/// single width constant fed through a fixed lens curve - which is what the first renderer did -
/// makes `blade`, `lance`, `spatulate` and `strap` the same shape at four thicknesses. A profile
/// FUNCTION can say "widest near the tip", "three lobes", "serrated margin", which a constant
/// cannot say at all.
///
/// ⚠️ INDICES ARE APPEND-ONLY and must match `vrd_leaf_forms()`. A saved plant resolves its seed
/// into these indices, so reordering silently rewrites every plant a buyer has grown.
///
/// Forms 10-12 are COMPOUND - several blades on a shared petiole - and are not expressible as a
/// half-width function at all. They are built in `__vrd_compound_leaf` and never reach this switch.
function vrd_leaf_profile(_form, _f) {
    var _t = clamp(_f, 0, 1);
    switch (_form) {
        case 0:  // blade - grass and grain: parallel sided, long, arching, drawn-out point
            return 0.055 * vrd_ramp(_t, 0.09) * vrd_fall(_t, 0.40);
        case 1:  return 0.30 * sin(pi * power(_t, 0.62));                        // ovate
        case 2:  return 0.155 * sin(pi * _t);                                    // lance
        case 3:  return 0.27 * sin(pi * power(_t, 0.70)) * (1 + 0.30 * cos(3 * pi * _t));   // lobed
        case 4:  return 0.045 * vrd_ramp(_t, 0.06) * vrd_fall(_t, 0.22);         // needle
        case 5:  return 0.34 * sin(pi * power(_t, 0.45));                        // heart (cordate)
        case 6:  return 0.34 * power(_t, 0.85) * vrd_fall(_t, 0.05);             // fan
        case 7:  return 0.26 * (0.20 + 0.80 * sin(pi * power(_t, 1.75))) * vrd_ramp(_t, 0.14); // spatulate
        case 8:  return 0.26 * sin(pi * power(_t, 0.66)) * (1 + 0.20 * abs(sin(7 * pi * _t))); // toothed
        case 9:  return 0.105 * vrd_ramp(_t, 0.05) * vrd_fall(_t, 0.30) * (1 - 0.25 * _t);    // strap
        case 13: // oaklobe - five DEEP rounded lobes on a narrow body
            return 0.32 * sin(pi * power(_t, 0.55)) * (0.62 + 0.38 * cos(5 * pi * _t));
        case 14: return 0.075 * vrd_ramp(_t, 0.10) * vrd_fall(_t, 0.55);         // scale
        default: return 0.20 * sin(pi * _t);
    }
}

/// How far a leaf's AXIS bends away from straight, as a fraction of its length at the tip. A grass
/// blade arches over under its own weight and that arc is most of what makes it read as a leaf
/// rather than a spike - widening the profile alone does not fix a straight sliver.
function vrd_leaf_droop(_form) {
    switch (_form) {
        case 0:  return 0.34;   // blade - grain arches hard; this is the family's whole silhouette
        case 9:  return 0.20;   // strap - thick agave/aloe leaves bend under their own weight
        case 2:  return 0.12;   // lance
        case 4:  return 0.07;   // needle
        case 12: return 0.10;   // pinnate - a long rachis sags; the arc stops it reading as a comb
        case 14: return 0.05;   // scale
        default: return 0;      // ovate/lobed/heart/fan/spatulate/toothed sit flat on their stalk
    }
}

/// Rotate a part list about the local origin, then translate. Used to hang leaflets off a rachis.
function __vrd_moved_parts(_parts, _dx, _dy, _ang) {
    var _c = cos(_ang), _s = sin(_ang);
    var _out = [];
    for (var i = 0; i < array_length(_parts); i++) {
        var _p = _parts[i];
        if (_p.t == "disc") {
            array_push(_out, { t: "disc", role: _p.role, r: _p.r,
                cx: _dx + _p.cx * _c - _p.cy * _s, cy: _dy + _p.cx * _s + _p.cy * _c });
        } else {
            var _np = [];
            for (var k = 0; k < array_length(_p.pts); k++) {
                var _q = _p.pts[k];
                array_push(_np, { x: _dx + _q.x * _c - _q.y * _s, y: _dy + _q.x * _s + _q.y * _c });
            }
            var _n = { t: _p.t, pts: _np, role: _p.role };
            if (variable_struct_exists(_p, "w")) _n.w = _p.w;
            array_push(_out, _n);
        }
    }
    return _out;
}

/// One blade: the shadowed whole, the lit upper half, an ink margin and a midrib. Four parts, and
/// the second is what stops it reading as a sticker - a midrib line falls where the two values meet.
/// The value split is a fixed SIDE rather than a light direction on purpose: it survives the leaf
/// being rotated to any angle, and 288 states cannot each be lit by hand.
function __vrd_simple_leaf(_form, _len, _seg) {
    var _upper = [], _lower = [], _axis = [];
    var _droop = vrd_leaf_droop(_form) * _len;
    /// CORDATE (form 5): the blade sweeps BACK past its own attachment, so the basal lobes sit
    /// behind the petiole and the notch between them is where the stalk meets.
    /// ⛔ The mirror's earlier version dragged the two seam points FORWARD instead, which put them
    /// ahead of the first sample and made the outline CROSS ITSELF. SVG fills by nonzero winding so
    /// it looked correct and passed review; it was found only when the corpus was run through the
    /// triangulator this file needs. A polygon that looks right under one fill rule is not a valid
    /// polygon. `back` keeps x monotonic in f, so the outline cannot cross.
    var _back = (_form == 5) ? 0.10 : 0;
    for (var i = 0; i <= _seg; i++) {
        var _f = i / _seg;
        var _w = vrd_leaf_profile(_form, _f) * _len;
        var _ax = -_droop * _f * _f;
        var _px = (_f * (1 + _back) - _back) * _len;
        array_push(_upper, { x: _px, y: _ax + _w });
        array_push(_lower, { x: _px, y: _ax - _w });
        array_push(_axis,  { x: _px, y: _ax });
    }
    var _blade = [];
    for (var a = 0; a < array_length(_upper); a++) array_push(_blade, _upper[a]);
    for (var b = array_length(_lower) - 1; b >= 0; b--) array_push(_blade, _lower[b]);

    /// The lit half closes back along the AXIS, not along y = 0 - with the arc added those are no
    /// longer the same line, and closing on the old one put the highlight outside the blade.
    var _lit = [];
    for (var c = 0; c < array_length(_upper); c++) array_push(_lit, _upper[c]);
    for (var d = array_length(_axis) - 1; d >= 0; d--) array_push(_lit, _axis[d]);

    return [
        vrd_poly(_blade, "leafDark"),
        vrd_poly(_lit, "leafLight"),
        vrd_line(__vrd_closed(_blade), _len * 0.020, "ink"),
        vrd_line(_axis, _len * 0.016, "vein"),
    ];
}

/// COMPOUND LEAVES - forms 10, 11, 12. The Vine, Bramble and Arbor families all want "a leaf that
/// is not one blade": a grape's palm, a bean's three leaflets, a bramble's toothed row along a
/// rachis. Every one of those could have been faked with an existing form at a different size, and
/// that is precisely the permutation the corpus rules ban.
function __vrd_compound_leaf(_form, _len) {
    var _out = [];

    if (_form == 10) {
        /// PALMATE - grape, fig: ONE blade cut into five lobes radiating from the petiole junction.
        /// Built as a radial outline rather than a half-width profile, because the lobes are
        /// arranged around a POINT and a profile can only vary along an axis.
        var _pts = [{ x: 0, y: 0 }];
        var _A = 1.24, _lobes = 5, _seg = 56;
        for (var i = 0; i <= _seg; i++) {
            var _u = i / _seg;
            var _th = -_A + 2 * _A * _u;
            var _lobe = power(abs(cos((_lobes / 2) * _th)), 0.55);
            var _r = _len * (0.34 + 0.66 * _lobe) * (1 - 0.16 * power(abs(_th / _A), 2.2));
            array_push(_pts, { x: _r * cos(_th), y: _r * sin(_th) });
        }
        array_push(_pts, { x: 0, y: 0 });
        array_push(_out, vrd_poly(_pts, "leafDark"));
        var _upper = [];
        for (var j = 0; j < array_length(_pts); j++) {
            if (_pts[j].y >= -_len * 0.02) array_push(_upper, _pts[j]);
        }
        array_push(_out, vrd_poly(_upper, "leafLight"));
        for (var k = 0; k < _lobes; k++) {
            var _tv = -_A + (2 * _A) * ((k + 0.5) / _lobes);
            array_push(_out, vrd_line([{ x: 0, y: 0 },
                { x: _len * 0.82 * cos(_tv), y: _len * 0.82 * sin(_tv) }], _len * 0.020, "vein"));
        }
        array_push(_out, vrd_line(_pts, _len * 0.024, "ink"));
        return _out;
    }

    if (_form == 11) {
        /// TRIFOLIATE - bean, clover: a bare petiole, then TWO lateral leaflets and one terminal.
        var _stalk = _len * 0.40;
        array_push(_out, vrd_line([{ x: 0, y: 0 }, { x: _stalk, y: 0 }], _len * 0.030, "stemDark"));
        var _term = __vrd_moved_parts(__vrd_simple_leaf(1, _len * 0.60, 12), _stalk, 0, 0);
        for (var t1 = 0; t1 < array_length(_term); t1++) array_push(_out, _term[t1]);
        var _sides = [-1, 1];
        for (var s1 = 0; s1 < 2; s1++) {
            var _lat = __vrd_moved_parts(__vrd_simple_leaf(1, _len * 0.50, 12), _stalk, 0, _sides[s1] * 0.88);
            for (var t2 = 0; t2 < array_length(_lat); t2++) array_push(_out, _lat[t2]);
        }
        return _out;
    }

    /// PINNATE - bramble, rose: leaflets in opposite pairs up a rachis, plus a terminal one.
    var _rachis = [];
    var _sag = _len * 0.10;
    for (var r = 0; r <= 10; r++) {
        var _rf = r / 10;
        array_push(_rachis, { x: _rf * _len, y: -_sag * _rf * _rf });
    }
    array_push(_out, vrd_line(_rachis, _len * 0.028, "stemDark"));
    var _at = [0.30, 0.56, 0.80];
    var _sd = [-1, 1];
    for (var m = 0; m < 3; m++) {
        var _mf = _at[m];
        var _ax2 = _mf * _len, _ay2 = -_sag * _mf * _mf;
        var _L2 = _len * (0.34 - 0.05 * m);
        for (var n = 0; n < 2; n++) {
            var _lf = __vrd_moved_parts(__vrd_simple_leaf(8, _L2, 12), _ax2, _ay2, _sd[n] * 1.12);
            for (var q = 0; q < array_length(_lf); q++) array_push(_out, _lf[q]);
        }
    }
    var _tip = _rachis[array_length(_rachis) - 1];
    var _tl = __vrd_moved_parts(__vrd_simple_leaf(8, _len * 0.30, 12), _tip.x, _tip.y, -0.20);
    for (var z = 0; z < array_length(_tl); z++) array_push(_out, _tl[z]);
    return _out;
}

/// The public leaf entry. Simple blades go through the profile machinery; 10-12 are compound.
function vrd_leaf_parts(_form, _len) {
    if (_form >= 10 && _form <= 12) return __vrd_compound_leaf(_form, _len);
    return __vrd_simple_leaf(_form, _len, 18);
}

/// ── CROWN FORMS ─────────────────────────────────────────────────────────────────────────────
/// A single grain/floret: a tiny lance leaf, so the vocabulary reuses itself instead of growing.
function __vrd_grain(_cx, _cy, _ang, _len, _role) {
    var _pts = [];
    var _seg = 8;
    var _c = cos(_ang), _s = sin(_ang);
    for (var i = 0; i <= _seg; i++) {
        var _f = i / _seg;
        var _x = _f * _len, _y = vrd_leaf_profile(2, _f) * _len * 1.45;
        array_push(_pts, { x: _cx + _x * _c - _y * _s, y: _cy + _x * _s + _y * _c });
    }
    for (var j = _seg; j >= 0; j--) {
        var _f2 = j / _seg;
        var _x2 = _f2 * _len, _y2 = -vrd_leaf_profile(2, _f2) * _len * 1.45;
        array_push(_pts, { x: _cx + _x2 * _c - _y2 * _s, y: _cy + _x2 * _s + _y2 * _c });
    }
    return vrd_poly(_pts, _role);
}

/// A lobed blob outline. TWO LOW HARMONICS ONLY (3 and 5) - higher ones alias into corners at any
/// practical point count, and the first canopy used the 7th and 11th and rendered as a jagged star.
function __vrd_blob_pts(_cx, _cy, _rx, _ry, _phase, _amp, _seg) {
    var _pts = [];
    for (var i = 0; i <= _seg; i++) {
        var _a = (i / _seg) * pi * 2;
        var _lobe = 1 + _amp * sin(3 * _a + _phase) + _amp * 0.55 * sin(5 * _a - _phase * 1.7);
        array_push(_pts, { x: _cx + cos(_a) * _rx * _lobe, y: _cy + sin(_a) * _ry * _lobe });
    }
    return _pts;
}

/// One foliage lump: filled, then outlined.
///
/// ⚠️ DEPTH COMES FROM STACKING LUMPS, NEVER FROM A MARK DRAWN INSIDE A FLAT FILL. The canopy's
/// interior shadow was first seven discs on a circle (read as polka dots), then two scalloped bands
/// (read as curly worms floating in the oak). A mark that does not touch the silhouette will be
/// read as an OBJECT. Overlapping dark -> mid -> light masses is also what makes the trunk look
/// like it goes INTO the tree rather than holding a hat up.
function __vrd_foliage_lump(_out, _cx, _cy, _rx, _ry, _phase, _role, _amp, _inkW) {
    var _pts = __vrd_blob_pts(_cx, _cy, _rx, _ry, _phase, _amp, 30);
    array_push(_out, vrd_poly(_pts, _role));
    array_push(_out, vrd_line(__vrd_closed(_pts), _inkW, "ink"));
    return _pts;
}

/// A crown as drawable parts, in PLANT space, origin at the attach point, +y up.
///
/// 19 forms. That count is not decoration: three grain species once shared ONE crown and genuinely
/// read as one plant, and the shape gate passed them because a defect shared by several species
/// still separates each of them from everything else. The remedy is always to EXTEND THE
/// VOCABULARY, never to resize.
function vrd_crown_parts(_form, _size) {
    var _out = [];
    var _s = _size;
    switch (_form) {
        case 0: { // ear - WHEAT: stiff vertical axis, paired plump grains, SHORT awns
            array_push(_out, vrd_line([{ x: 0, y: 0 }, { x: 0, y: _s }], _s * 0.055, "crownDark"));
            var _rows = 7;
            for (var i = 0; i < _rows; i++) {
                var _f = i / (_rows - 1);
                var _y = _f * _s * 0.94;
                var _g = _s * 0.30 * (1 - 0.30 * _f);
                var _sd = [-1, 1];
                for (var k = 0; k < 2; k++) {
                    var _side = _sd[k];
                    array_push(_out, __vrd_grain(_side * _s * 0.055, _y, _side * 0.62, _g, "crown"));
                    array_push(_out, vrd_line([{ x: _side * _g * 0.55, y: _y + _g * 0.45 },
                        { x: _side * _g * 0.80, y: _y + _g * 1.25 }], _s * 0.022, "crownDark"));
                }
            }
            break;
        }
        case 1: { // panicle - OAT: open two-level branching with spikelets HANGING at the tips
            /// The arms sit on a short central RACHIS. Without it they sprang straight off the stem
            /// tip and the whole head rendered detached, floating above the stalk.
            var _rise = _s * 0.34;
            array_push(_out, vrd_line([{ x: 0, y: 0 }, { x: 0, y: _rise }], _s * 0.045, "crownDark"));
            var _arms = 5;
            for (var a = 0; a < _arms; a++) {
                var _af = a / (_arms - 1);
                var _ang = -0.95 + _af * 1.90;
                var _L = _s * (0.52 + 0.44 * cos(_ang));
                var _ex = sin(_ang) * _L, _ey = _rise + cos(_ang) * _L * 0.92;
                array_push(_out, vrd_line([{ x: 0, y: _rise },
                    { x: _ex * 0.55, y: _rise + (_ey - _rise) * 0.62 }, { x: _ex, y: _ey }],
                    _s * 0.030, "crownDark"));
                var _dd = [-1, 1];
                for (var d = 0; d < 2; d++) {
                    var _tx = _ex + _dd[d] * _s * 0.07, _ty = _ey - _s * 0.05;
                    array_push(_out, vrd_line([{ x: _ex, y: _ey }, { x: _tx, y: _ty }], _s * 0.022, "crownDark"));
                    array_push(_out, __vrd_grain(_tx, _ty, -pi * 0.5 + _dd[d] * 0.22, _s * 0.26, "crown"));
                }
            }
            break;
        }
        case 2: { // rosette - tight radial leaves from a single point
            var _n = 9;
            for (var r = 0; r < _n; r++) {
                var _ra = (r / _n) * pi * 2;
                var _rc = cos(_ra + pi * 0.5), _rs = sin(_ra + pi * 0.5);
                var _lp = __vrd_simple_leaf(7, _s * 0.62, 10);
                for (var p = 0; p < array_length(_lp); p++) {
                    var _pp = _lp[p];
                    var _np = [];
                    for (var q = 0; q < array_length(_pp.pts); q++) {
                        var _v = _pp.pts[q];
                        array_push(_np, { x: _v.x * _rs + _v.y * _rc, y: _v.x * _rc - _v.y * _rs });
                    }
                    var _nn = { t: _pp.t, pts: _np, role: _pp.role };
                    if (variable_struct_exists(_pp, "w")) _nn.w = _pp.w;
                    array_push(_out, _nn);
                }
            }
            break;
        }
        case 3: { // cluster - SORGHUM: an upright ovoid mass of individually visible seeds
            /// ⚠️ FIXED TWICE. First it was 12 circles on one radius - a DONUT, the outline of a
            /// bundle. Filling it with concentric rings over-corrected into a solid disc and
            /// sorghum rendered as a tomato. Both are the same mistake: drawing the bundle's SHAPE
            /// instead of the grains it is made of. A golden-angle spiral has no ring artefacts at
            /// any count, and the ovoid envelope is TALLER than wide so it cannot collide with
            /// millet's round finger tips.
            var _n3 = 46, _gold = 2.39996;
            array_push(_out, vrd_line([{ x: 0, y: 0 }, { x: 0, y: _s * 0.30 }], _s * 0.09, "crownDark"));
            for (var g3 = 0; g3 < _n3; g3++) {
                var _f3 = (g3 + 0.5) / _n3;
                var _r3 = sqrt(_f3);
                var _a3 = g3 * _gold;
                array_push(_out, vrd_disc(cos(_a3) * _r3 * _s * 0.46,
                    _s * 0.78 + sin(_a3) * _r3 * _s * 0.66,
                    _s * 0.105 * (1.1 - 0.3 * _r3),
                    ((g3 mod 3) == 0) ? "crownDark" : "crown"));
            }
            break;
        }
        case 4: { // raceme - RYE: narrow, one-sided, NODDING
            var _seg4 = 9;
            var _axis4 = [];
            for (var i4 = 0; i4 <= _seg4; i4++) {
                var _f4 = i4 / _seg4;
                array_push(_axis4, { x: -power(_f4, 2.2) * _s * 0.52,
                    y: _f4 * _s * 0.98 - power(_f4, 3) * _s * 0.16 });
            }
            array_push(_out, vrd_line(_axis4, _s * 0.045, "crownDark"));
            for (var j4 = 1; j4 <= _seg4; j4++) {
                var _p4 = _axis4[j4], _ff4 = j4 / _seg4;
                array_push(_out, __vrd_grain(_p4.x, _p4.y, -pi * 0.30 - _ff4 * 0.55,
                    _s * 0.30 * (1 - 0.25 * _ff4), "crown"));
            }
            break;
        }
        case 5: { // digitate - MILLET: finger spikes radiating from one point
            var _fing = 4;
            for (var i5 = 0; i5 < _fing; i5++) {
                var _a5 = -0.78 + (i5 / (_fing - 1)) * 1.56;
                var _L5 = _s * (0.80 + 0.20 * cos(_a5 * 1.6));
                var _dx5 = sin(_a5), _dy5 = cos(_a5);
                array_push(_out, vrd_line([{ x: 0, y: 0 }, { x: _dx5 * _L5, y: _dy5 * _L5 }],
                    _s * 0.075, "crownDark"));
                for (var k5 = 1; k5 <= 6; k5++) {
                    var _f5 = k5 / 6;
                    array_push(_out, vrd_disc(_dx5 * _L5 * _f5, _dy5 * _L5 * _f5,
                        _s * 0.10 * (1.15 - 0.4 * _f5), "crown"));
                }
            }
            break;
        }
        case 6: { // nod - a single heavy head on a bent neck
            array_push(_out, vrd_line([{ x: 0, y: 0 }, { x: -_s * 0.14, y: _s * 0.42 },
                { x: -_s * 0.44, y: _s * 0.56 }], _s * 0.055, "crownDark"));
            var _pts6 = [];
            for (var i6 = 0; i6 < 13; i6++) {
                var _a6 = (i6 / 13) * pi * 2;
                array_push(_pts6, { x: -_s * 0.44 + cos(_a6) * _s * 0.34,
                    y: _s * 0.56 + sin(_a6) * _s * 0.27 });
            }
            array_push(_out, vrd_poly(_pts6, "crown"));
            array_push(_out, vrd_line(__vrd_closed(_pts6), _s * 0.035, "crownDark"));
            break;
        }
        case 7: { // awned ear - BARLEY: a wheat ear whose awns are 3x longer
            /// Barley's whole silhouette IS its awns; sharing wheat's `ear` threw away the one
            /// feature a player would use to tell the two apart.
            array_push(_out, vrd_line([{ x: 0, y: 0 }, { x: 0, y: _s * 0.82 }], _s * 0.050, "crownDark"));
            var _rows7 = 6;
            for (var i7 = 0; i7 < _rows7; i7++) {
                var _f7 = i7 / (_rows7 - 1);
                var _y7 = _f7 * _s * 0.78;
                var _g7 = _s * 0.26 * (1 - 0.22 * _f7);
                var _sd7 = [-1, 1];
                for (var k7 = 0; k7 < 2; k7++) {
                    var _s7 = _sd7[k7];
                    array_push(_out, __vrd_grain(_s7 * _s * 0.050, _y7, _s7 * 0.50, _g7, "crown"));
                    array_push(_out, vrd_line([{ x: _s7 * _g7 * 0.5, y: _y7 + _g7 * 0.5 },
                        { x: _s7 * (_g7 * 0.9 + _s * 0.16), y: _y7 + _s * 0.95 }], _s * 0.020, "crownDark"));
                }
            }
            break;
        }
        // ── THE FUNGUS VOCABULARY (8-13). Six forms for six species, no sharing: this family has
        //    NO leaf op at all, so its crown is not an ornament on a plant, it IS the plant.
        case 8: { // cap - the archetypal gilled toadstool
            /// ⚠️ 0.92 x 0.56 rendered as a flat parasol. A toadstool's dome is nearly as tall as it
            /// is half-wide; flattening it turns the mushroom into an umbrella.
            var _cw = _s * 0.80, _ch = _s * 0.78, _y08 = _s * 0.58;
            var _dome = [];
            for (var i8 = 0; i8 <= 24; i8++) {
                var _a8 = pi - (i8 / 24) * pi;
                array_push(_dome, { x: cos(_a8) * _cw, y: _y08 + sin(_a8) * _ch });
            }
            var _shell = [];
            for (var d8 = 0; d8 < array_length(_dome); d8++) array_push(_shell, _dome[d8]);
            for (var u8 = 0; u8 <= 12; u8++) {   // underside: a shallow reverse arc, so it has thickness
                var _uf = 1 - u8 / 12;
                array_push(_shell, { x: (_uf * 2 - 1) * _cw, y: _y08 + sin(pi * _uf) * _ch * 0.14 });
            }
            array_push(_out, vrd_poly(_shell, "crown"));
            var _lit8 = [];
            for (var l8 = 0; l8 < 13; l8++) array_push(_lit8, _dome[l8]);
            array_push(_lit8, { x: 0, y: _y08 });
            array_push(_out, vrd_poly(_lit8, "crownLight"));
            for (var gi = 1; gi < 11; gi++) {    // gills under the rim
                var _gf = gi / 11;
                var _gx = (_gf * 2 - 1) * _cw * 0.88;
                array_push(_out, vrd_line([{ x: _gx, y: _y08 + sin(pi * _gf) * _ch * 0.12 },
                    { x: _gx, y: _y08 - _s * 0.10 }], _s * 0.030, "crownDark"));
            }
            array_push(_out, vrd_line(__vrd_closed(_shell), _s * 0.040, "ink"));
            array_push(_out, vrd_line([{ x: -_s * 0.26, y: _y08 - _s * 0.30 },
                { x: _s * 0.26, y: _y08 - _s * 0.30 }], _s * 0.075, "crownLight"));   // the annulus
            for (var w8 = 0; w8 < 5; w8++) {     // warts
                var _wa = pi * 0.18 + (w8 / 4) * pi * 0.64;
                array_push(_out, vrd_disc(cos(_wa) * _cw * 0.66, _y08 + sin(_wa) * _ch * 0.72,
                    _s * 0.070, "crownLight"));
            }
            break;
        }
        case 9: { // bracket - shelves stacked up ONE side of the axis. Radically asymmetric.
            for (var k9 = 0; k9 < 3; k9++) {
                var _y9 = _s * (0.22 + k9 * 0.30);
                var _w9 = _s * (0.98 - k9 * 0.20), _h9 = _s * 0.20;
                var _p9 = [];
                for (var i9 = 0; i9 <= 18; i9++) {
                    var _a9 = -pi * 0.5 + (i9 / 18) * pi;
                    array_push(_p9, { x: max(0, cos(_a9)) * _w9, y: _y9 + sin(_a9) * _h9 });
                }
                array_push(_p9, { x: 0, y: _y9 - _h9 });
                array_push(_out, vrd_poly(_p9, ((k9 mod 2) != 0) ? "crown" : "crownLight"));
                array_push(_out, vrd_line(__vrd_closed(_p9), _s * 0.035, "ink"));
                for (var r9 = 1; r9 <= 2; r9++) {
                    var _arc9 = [];
                    for (var j9 = 0; j9 <= 12; j9++) {
                        var _b9 = -pi * 0.5 + (j9 / 12) * pi;
                        array_push(_arc9, { x: max(0, cos(_b9)) * _w9 * (0.4 + r9 * 0.24),
                            y: _y9 + sin(_b9) * _h9 * (0.4 + r9 * 0.24) });
                    }
                    array_push(_out, vrd_line(_arc9, _s * 0.022, "crownDark"));
                }
            }
            array_push(_out, vrd_line([{ x: 0, y: 0 }, { x: 0, y: _s * 1.02 }], _s * 0.10, "crownDark"));
            break;
        }
        case 10: { // coral - antler fungus: recursive Y forking, all line, no cap
            __vrd_coral_fork(_out, _s, 0, 0, -0.10, _s * 0.42, 3);
            __vrd_coral_fork(_out, _s, -_s * 0.06, 0, -0.46, _s * 0.32, 2);
            __vrd_coral_fork(_out, _s, _s * 0.07, 0, 0.44, _s * 0.34, 2);
            break;
        }
        case 11: { // puffball - a warted sphere on a squat base. Wide, low, closed.
            var _r11 = _s * 0.66;
            var _ball = [];
            for (var i11 = 0; i11 <= 26; i11++) {
                var _a11 = (i11 / 26) * pi * 2;
                array_push(_ball, { x: cos(_a11) * _r11 * 1.08, y: _s * 0.60 + sin(_a11) * _r11 * 0.92 });
            }
            array_push(_out, vrd_poly(_ball, "crown"));
            var _lit11 = [];
            for (var l11 = 6; l11 < 20; l11++) array_push(_lit11, _ball[l11]);
            array_push(_out, vrd_poly(_lit11, "crownLight"));
            array_push(_out, vrd_line(__vrd_closed(_ball), _s * 0.042, "ink"));
            var _gold11 = 2.39996;
            for (var w11 = 0; w11 < 22; w11++) {
                var _f11 = (w11 + 0.5) / 22, _rr11 = sqrt(_f11), _aa11 = w11 * _gold11;
                array_push(_out, vrd_disc(cos(_aa11) * _rr11 * _r11 * 0.86,
                    _s * 0.60 + sin(_aa11) * _rr11 * _r11 * 0.74, _s * 0.052, "crownDark"));
            }
            break;
        }
        case 12: { // morel - a pitted honeycomb ovoid on a short fat stipe
            var _w12 = _s * 0.46, _h12 = _s * 0.86, _y12 = _s * 0.58;
            var _body12 = [];
            for (var i12 = 0; i12 <= 26; i12++) {
                var _a12 = (i12 / 26) * pi * 2;
                array_push(_body12, { x: cos(_a12) * _w12 * (1 + 0.10 * cos(3 * _a12)),
                    y: _y12 + sin(_a12) * _h12 });
            }
            array_push(_out, vrd_poly(_body12, "crown"));
            array_push(_out, vrd_line(__vrd_closed(_body12), _s * 0.038, "ink"));
            for (var r12 = 0; r12 < 6; r12++) {
                for (var c12 = 0; c12 < 3; c12++) {
                    var _yy12 = _y12 - _h12 * 0.74 + (r12 / 5) * _h12 * 1.48;
                    var _xx12 = (-1 + (c12 + (r12 mod 2) * 0.5) / 1.25) * _w12 * 0.62;
                    if (abs(_xx12) > _w12 * 0.82) continue;
                    array_push(_out, vrd_disc(_xx12, _yy12, _s * 0.078, "crownDark"));
                }
            }
            array_push(_out, vrd_line([{ x: 0, y: 0 }, { x: 0, y: _y12 - _h12 * 0.5 }],
                _s * 0.30, "crownLight"));
            break;
        }
        case 13: { // inkcap - a narrow furrowed bell with a deliquescing ragged margin
            var _w13 = _s * 0.34, _h13 = _s * 0.92, _y13 = _s * 0.42;
            var _bell = [];
            for (var i13 = 0; i13 <= 20; i13++) {
                var _f13 = i13 / 20;
                var _a13 = pi - _f13 * pi;
                array_push(_bell, { x: cos(_a13) * _w13 * (1 - 0.25 * power(sin(_a13), 2)),
                    y: _y13 + sin(_a13) * _h13 });
            }
            var _shell13 = [];
            for (var b13 = 0; b13 < array_length(_bell); b13++) array_push(_shell13, _bell[b13]);
            for (var g13 = 8; g13 >= 0; g13--) {   // the torn skirt: alternate points dropped
                array_push(_shell13, { x: (g13 / 8 * 2 - 1) * _w13,
                    y: _y13 - (((g13 mod 2) != 0) ? _s * 0.20 : _s * 0.05) });
            }
            array_push(_out, vrd_poly(_shell13, "crown"));
            var _lit13 = [];
            for (var l13 = 0; l13 < 11; l13++) array_push(_lit13, _bell[l13]);
            array_push(_lit13, { x: 0, y: _y13 });
            array_push(_out, vrd_poly(_lit13, "crownLight"));
            array_push(_out, vrd_line(__vrd_closed(_shell13), _s * 0.034, "ink"));
            for (var f13b = 1; f13b < 11; f13b++) {
                var _ff13 = f13b / 11;
                var _aa13 = pi - _ff13 * pi;
                array_push(_out, vrd_line([
                    { x: cos(_aa13) * _w13 * 0.86, y: _y13 + sin(_aa13) * _h13 * 0.92 },
                    { x: cos(_aa13) * _w13 * 0.96, y: _y13 - _s * 0.02 }], _s * 0.022, "crownDark"));
            }
            break;
        }
        // ── THE ARBOR CANOPIES (14-18). A tree is read by its OUTLINE, which is the one thing none
        //    of the eighteen forms above is the right shape for.
        case 14: { // canopy - a broad deciduous crown: three overlapping masses, dark to light
            var _R14 = _s * 1.06, _ink14 = _s * 0.028;
            __vrd_foliage_lump(_out, 0, _s * 0.74, _R14, _R14 * 0.80, 0.0, "crownDark", 0.17, _ink14);
            __vrd_foliage_lump(_out, -_s * 0.16, _s * 0.94, _R14 * 0.86, _R14 * 0.70, 2.3, "crown", 0.15, _ink14);
            __vrd_foliage_lump(_out, _s * 0.30, _s * 1.06, _R14 * 0.58, _R14 * 0.48, 4.4, "crownLight", 0.18, _ink14);
            break;
        }
        case 15: { // conifer - four stacked whorls narrowing to a spire
            /// The only triangle in the corpus, which is the point: unmistakable at any size.
            var _tiers = 4;
            for (var k15 = 0; k15 < _tiers; k15++) {
                var _f15 = k15 / (_tiers - 1);
                var _y15 = _s * (0.10 + _f15 * 1.28);
                var _w15 = _s * (0.92 - _f15 * 0.62);
                var _h15 = _s * (0.62 - _f15 * 0.16);
                var _p15 = [{ x: -_w15, y: _y15 }, { x: -_w15 * 0.55, y: _y15 + _h15 * 0.22 },
                    { x: 0, y: _y15 + _h15 }, { x: _w15 * 0.55, y: _y15 + _h15 * 0.22 },
                    { x: _w15, y: _y15 }, { x: _w15 * 0.42, y: _y15 - _h15 * 0.18 },
                    { x: -_w15 * 0.42, y: _y15 - _h15 * 0.18 }];
                array_push(_out, vrd_poly(_p15, ((k15 mod 2) != 0) ? "crown" : "crownLight"));
                array_push(_out, vrd_line([{ x: -_w15 * 0.90, y: _y15 - _h15 * 0.04 },
                    { x: 0, y: _y15 - _h15 * 0.20 }, { x: _w15 * 0.90, y: _y15 - _h15 * 0.04 }],
                    _s * 0.055, "crownDark"));
                array_push(_out, vrd_line(__vrd_closed(_p15), _s * 0.028, "ink"));
            }
            break;
        }
        case 16: { // weeping - willow
            /// ⚠️ THE FIRST VERSION WAS A JELLYFISH, and none of the three causes showed up in any
            /// number the gate produces: a smooth elliptical lid (a bell, not foliage), STRAIGHT
            /// strands all starting on its rim at one weight, and nothing overlapping them. A
            /// willow's fronds spring from INSIDE the crown, curve outward as they fall, and vary.
            var _R16 = _s * 1.06, _ink16 = _s * 0.026;
            __vrd_foliage_lump(_out, 0, _s * 0.72, _R16, _R16 * 0.58, 0.0, "crownDark", 0.15, _ink16);
            __vrd_foliage_lump(_out, -_s * 0.14, _s * 0.86, _R16 * 0.84, _R16 * 0.50, 2.6, "crown", 0.14, _ink16);
            var _str = 15;
            for (var i16 = 0; i16 < _str; i16++) {
                var _f16 = (i16 + 0.5) / _str;
                var _x016 = (_f16 * 2 - 1) * _R16 * 0.92;
                var _drop = _s * (0.34 + 0.92 * power(sin(pi * _f16), 0.7) * (0.78 + 0.22 * sin(i16 * 2.4)));
                var _drift = sign((_x016 == 0) ? 1 : _x016) * _s * (0.16 + 0.14 * sin(i16 * 1.7));
                var _p16 = [];
                for (var k16 = 0; k16 <= 8; k16++) {
                    var _u16 = k16 / 8;
                    array_push(_p16, { x: _x016 + _drift * _u16 * _u16, y: _s * 0.70 - _drop * _u16 });
                }
                array_push(_out, vrd_line(_p16, _s * (0.052 - 0.018 * (i16 mod 3)),
                    ((i16 mod 3) != 0) ? "crown" : "crownLight"));
            }
            /// A final LIT lump OVER the strand roots, so the fronds emerge from inside the crown
            /// instead of being pinned to the underside of a lid. This is the whole difference.
            __vrd_foliage_lump(_out, _s * 0.22, _s * 0.94, _R16 * 0.62, _R16 * 0.38, 4.8, "crownLight", 0.17, _ink16);
            break;
        }
        case 17: { // spread - olive / acacia: a broad, low, flat-topped crown
            /// ⚠️ THE FIRST VERSION WAS A FLYING SAUCER: a smooth lens plus five evenly spaced dark
            /// discs, which read as PORTHOLES. A spreading crown is several overlapping masses at
            /// slightly different heights that happen to have a flat top.
            var _R17 = _s * 1.40, _H17 = _s * 0.46, _ink17 = _s * 0.024;
            __vrd_foliage_lump(_out, 0, _s * 0.52, _R17 * 0.94, _H17 * 0.92, 0.0, "crownDark", 0.13, _ink17);
            __vrd_foliage_lump(_out, -_R17 * 0.44, _s * 0.62, _R17 * 0.52, _H17 * 0.78, 2.2, "crown", 0.16, _ink17);
            __vrd_foliage_lump(_out, _R17 * 0.42, _s * 0.66, _R17 * 0.50, _H17 * 0.74, 4.3, "crown", 0.16, _ink17);
            __vrd_foliage_lump(_out, _s * 0.06, _s * 0.76, _R17 * 0.40, _H17 * 0.60, 5.6, "crownLight", 0.18, _ink17);
            break;
        }
        case 18: { // sparse - a YOUNG tree's open crown: tufts you can see daylight between
            /// Added because sapling, oak and fig all used `canopy` and read as the same lumpy mass
            /// at three sizes - the grain-crown defect exactly.
            var _tufts = 6;
            for (var i18 = 0; i18 < _tufts; i18++) {
                var _a18 = -1.15 + (i18 / (_tufts - 1)) * 2.30;
                var _L18 = _s * (0.62 + 0.30 * cos(_a18 * 1.4));
                var _ex18 = sin(_a18) * _L18, _ey18 = cos(_a18) * _L18 + _s * 0.20;
                array_push(_out, vrd_line([{ x: 0, y: 0 },
                    { x: _ex18 * 0.55, y: _ey18 * 0.55 }, { x: _ex18, y: _ey18 }], _s * 0.045, "crownDark"));
                var _blob = [];
                for (var k18 = 0; k18 <= 14; k18++) {
                    var _b18 = (k18 / 14) * pi * 2;
                    var _lobe18 = 1 + 0.24 * sin(5 * _b18 + i18);
                    array_push(_blob, { x: _ex18 + cos(_b18) * _s * 0.30 * _lobe18,
                        y: _ey18 + sin(_b18) * _s * 0.26 * _lobe18 });
                }
                array_push(_out, vrd_poly(_blob, ((i18 mod 2) != 0) ? "crown" : "crownLight"));
                array_push(_out, vrd_line(__vrd_closed(_blob), _s * 0.026, "ink"));
            }
            break;
        }
        default:
            array_push(_out, vrd_disc(0, _s * 0.4, _s * 0.35, "crown"));
    }
    return _out;
}

/// Coral's recursive fork, hoisted out of the switch because GML has no local recursion.
/// Drawn twice per segment - a heavy ink stroke, then the body - because an all-line form has no
/// polygon to carry an outline and without one it reads as a wire diagram rather than as flesh.
function __vrd_coral_fork(_out, _s, _x, _y, _ang, _len, _depth) {
    var _ex = _x + sin(_ang) * _len, _ey = _y + cos(_ang) * _len;
    var _w = _s * 0.11 * power(0.72, 3 - _depth);
    array_push(_out, vrd_line([{ x: _x, y: _y }, { x: _ex, y: _ey }], _w * 1.55, "ink"));
    array_push(_out, vrd_line([{ x: _x, y: _y }, { x: _ex, y: _ey }], _w,
        (_depth > 1) ? "crownDark" : "crown"));
    if (_depth <= 0) { array_push(_out, vrd_disc(_ex, _ey, _s * 0.045, "crownLight")); return; }
    __vrd_coral_fork(_out, _s, _ex, _ey, _ang - 0.42 - _depth * 0.05, _len * 0.70, _depth - 1);
    __vrd_coral_fork(_out, _s, _ex, _ey, _ang + 0.40 + _depth * 0.06, _len * 0.66, _depth - 1);
}

/// ── BLOOM FORMS ─────────────────────────────────────────────────────────────────────────────
/// One petal, using the leaf profile machinery so petal shape is authored rather than ad hoc.
function __vrd_petal(_ang, _len, _wid, _form, _cx, _cy) {
    var _pts = [];
    var _seg = 10;
    var _c = cos(_ang), _s = sin(_ang);
    for (var i = 0; i <= _seg; i++) {
        var _f = i / _seg;
        var _p = __vrd_petal_profile(_form, _f);
        var _x = _f * _len, _y = _p * _len * (_wid / 0.30);
        array_push(_pts, { x: _cx + _x * _c - _y * _s, y: _cy + _x * _s + _y * _c });
    }
    for (var j = _seg; j >= 0; j--) {
        var _f2 = j / _seg;
        var _p2 = __vrd_petal_profile(_form, _f2);
        var _x2 = _f2 * _len, _y2 = -_p2 * _len * (_wid / 0.30);
        array_push(_pts, { x: _cx + _x2 * _c - _y2 * _s, y: _cy + _x2 * _s + _y2 * _c });
    }
    return _pts;
}
function __vrd_petal_profile(_form, _f) {
    switch (_form) {
        case 3:  return 0.16 * sin(pi * power(_f, 0.9));                    // star - narrow, pointed
        case 4:  return 0.085 * vrd_fall(_f, 0.30) * vrd_ramp(_f, 0.08);    // ray  - thin strap
        case 1:  return 0.34 * sin(pi * power(_f, 1.25));                   // cup  - broad, blunt
        default: return 0.30 * sin(pi * power(_f, 0.75));                   // disc - rounded
    }
}

/// A bloom as drawable parts, in PLANT space, origin at the attach point, +y up.
///
/// ⚠️ SEVEN FORMS WERE DECLARED AND TWO WERE IMPLEMENTED once: `cup`, `bell`, `spike` and `plume`
/// all fell through to the same radial petal ring, so foxglove's hanging bells and thistle's
/// feathery head rendered as small daisies. A declared vocabulary the renderer ignores is worse
/// than a small one, because the corpus is then authored believing the distinction exists.
function vrd_bloom_parts(_form, _petals, _size, _ang) {
    var _out = [];
    var _s = _size;
    switch (_form) {
        case 2: { // bell - one fused corolla HANGING from its stalk (foxglove, campanula)
            /// ⚠️ The first attempt swept a half circle and closed it back to the stalk, producing
            /// a pointed DART - campanula rendered as a row of blue arrowheads. A bell is a goblet:
            /// narrow where it joins the stalk, flaring downward, scalloped rim at the BOTTOM.
            var _seg = 16, _lobes = 5;
            var _pts = [];
            for (var i = 0; i <= _seg; i++) {
                var _u = i / _seg;
                array_push(_pts, { x: -(_s * (0.20 + 0.52 * power(_u, 0.72))), y: -_s * 1.30 * _u });
            }
            var _hw1 = _s * (0.20 + 0.52);
            for (var j = 0; j <= _lobes * 4; j++) {
                var _f = j / (_lobes * 4);
                array_push(_pts, { x: -_hw1 + _f * _hw1 * 2,
                    y: -_s * 1.30 - _s * 0.16 * abs(sin(_lobes * _f * pi)) });
            }
            for (var k = _seg; k >= 0; k--) {
                var _u2 = k / _seg;
                array_push(_pts, { x: _s * (0.20 + 0.52 * power(_u2, 0.72)), y: -_s * 1.30 * _u2 });
            }
            array_push(_out, vrd_poly(_pts, "bloom"));
            array_push(_out, vrd_line(__vrd_closed(_pts), _s * 0.075, "bloomDark"));
            var _lit = [];
            for (var m = 0; m <= _seg; m++) {
                var _u3 = m / _seg;
                array_push(_lit, { x: -(_s * (0.20 + 0.52 * power(_u3, 0.72))) * 0.45, y: -_s * 1.30 * _u3 });
            }
            array_push(_out, vrd_line(_lit, _s * 0.16, "centre"));
            array_push(_out, vrd_disc(0, -_s * 0.04, _s * 0.19, "bloomDark"));       // calyx
            break;
        }
        case 5: { // spike - florets stacked up a vertical axis
            var _n5 = max(5, _petals);
            array_push(_out, vrd_line([{ x: 0, y: 0 }, { x: 0, y: _s * 1.5 }], _s * 0.09, "bloomDark"));
            for (var i5 = 0; i5 < _n5; i5++) {
                var _f5 = i5 / (_n5 - 1);
                var _r5 = _s * 0.34 * (1 - 0.55 * _f5);
                array_push(_out, vrd_disc(-_r5 * 0.85, _f5 * _s * 1.45, _r5, "bloom"));
                array_push(_out, vrd_disc(_r5 * 0.85, _f5 * _s * 1.45, _r5, "bloom"));
            }
            break;
        }
        case 6: { // plume - feathery filaments over a bract cup (thistle)
            var _br = [];
            for (var i6 = 0; i6 <= 14; i6++) {
                var _a6 = pi + (i6 / 14) * pi;
                array_push(_br, { x: cos(_a6) * _s * 0.52, y: _s * 0.16 + sin(_a6) * _s * 0.40 });
            }
            array_push(_out, vrd_poly(_br, "bloomDark"));
            var _n6 = max(14, _petals);
            for (var j6 = 0; j6 < _n6; j6++) {
                var _aa = _ang - pi * 0.5 + ((j6 + 0.5) / _n6) * pi * 1.9 - pi * 0.45;
                var _L6 = _s * (0.95 + 0.35 * sin(j6 * 2.399));
                array_push(_out, vrd_line([{ x: 0, y: _s * 0.20 },
                    { x: cos(_aa) * _L6 * 0.6, y: _s * 0.20 + sin(_aa) * _L6 * 0.6 },
                    { x: cos(_aa + 0.12) * _L6, y: _s * 0.20 + sin(_aa + 0.12) * _L6 }],
                    _s * 0.075, "bloom"));
            }
            break;
        }
        case 1: { // cup - fewer, broader petals curled inward, over a dark throat
            var _n1 = max(4, _petals);
            for (var i1 = 0; i1 < _n1; i1++) {
                var _a1 = _ang + (i1 / _n1) * pi * 2;
                array_push(_out, vrd_poly(__vrd_petal(_a1, _s * 0.92, 0.34, 1, 0, 0),
                    ((i1 mod 2) != 0) ? "bloom" : "bloomDark"));
            }
            array_push(_out, vrd_disc(0, 0, _s * 0.30, "bloomDark"));
            array_push(_out, vrd_disc(0, 0, _s * 0.19, "centre"));
            break;
        }
        default: { // disc (0) - star (3) - ray (4): a radial ring, each with its own petal profile
            var _n = max(3, _petals);
            var _len = (_form == 4) ? _s * 1.20 : ((_form == 3) ? _s * 1.10 : _s * 0.86);
            var _wid = (_form == 4) ? 0.085 : ((_form == 3) ? 0.16 : 0.30);
            for (var i = 0; i < _n; i++) {
                var _a = _ang + (i / _n) * pi * 2;
                array_push(_out, vrd_poly(__vrd_petal(_a, _len, _wid, _form, 0, 0), "bloom"));
            }
            if (_form == 4) {                       // composite centre: many small florets
                array_push(_out, vrd_disc(0, 0, _s * 0.30, "bloomDark"));
                for (var c = 0; c < 9; c++) {
                    var _ac = (c / 9) * pi * 2;
                    array_push(_out, vrd_disc(cos(_ac) * _s * 0.16, sin(_ac) * _s * 0.16, _s * 0.075, "centre"));
                }
            } else {
                array_push(_out, vrd_disc(0, 0, _s * 0.27, "bloomDark"));
                array_push(_out, vrd_disc(0, 0, _s * 0.17, "centre"));
            }
            break;
        }
    }
    return _out;
}

/// ── TAPROOTS ────────────────────────────────────────────────────────────────────────────────
/// The ROOT family's storage organ, drawn BELOW the soil line. Nothing else in the corpus puts its
/// identity underground, which is what makes this the strongest family separation available.
///
/// `_prof` selects the half-width formula. It is an integer rather than a callback because GML
/// closures capture `self`, not locals, so the mirror's `halfW` lambda has no direct equivalent.
function __vrd_tap_w(_prof, _f, _girth, _k) {
    switch (_prof) {
        case 1: return _girth * sin(pi * power(_f, 0.62)) * (1 - 0.15 * _f);                 // globe
        case 2: return _girth * power(sin(pi * power(_f, 0.42)), 1.3) * (1 - 0.55 * _f);     // fusiform
        case 4: return _girth * _k * sin(pi * power(_f, 0.55));                              // bulb coat
        case 5: return _girth * (1 - 0.55 * _f) * vrd_fall(_f, 0.10);                        // forked trunk
        default: return _girth * power(1 - _f, 0.62) * vrd_ramp(_f, 0.06);                   // taproot
    }
}
function __vrd_tap_body(_prof, _girth, _depth, _k, _xoff, _skew) {
    var _seg = 16;
    var _L = [], _R = [];
    for (var i = 0; i <= _seg; i++) {
        var _f = i / _seg;
        var _w = __vrd_tap_w(_prof, _f, _girth, _k);
        var _x = _xoff + _skew * _f * _depth;
        array_push(_L, { x: _x - _w, y: -_f * _depth });
        array_insert(_R, 0, { x: _x + _w, y: -_f * _depth });
    }
    for (var j = 0; j < array_length(_R); j++) array_push(_L, _R[j]);
    return _L;
}
function __vrd_tap_shade(_out, _pts, _role, _girth) {
    array_push(_out, vrd_poly(_pts, _role));
    array_push(_out, vrd_line(__vrd_closed(_pts), _girth * 0.14, "ink"));
}

function vrd_taproot_parts(_form, _len, _girth) {
    var _out = [];
    switch (_form) {
        case 1: { // globe - turnip/beetroot: a sphere sitting mostly proud of the soil
            __vrd_tap_shade(_out, __vrd_tap_body(1, _girth, _len * 1.05, 1, 0, 0), "tuber", _girth);
            array_push(_out, vrd_line([{ x: -_girth * 0.42, y: -_len * 0.22 },
                { x: -_girth * 0.52, y: -_len * 0.52 }], _girth * 0.16, "tuberLight"));
            for (var i = 1; i <= 3; i++) {                       // growth rings across the shoulder
                var _f = 0.18 + i * 0.12;
                var _w = _girth * sin(pi * power(_f, 0.62)) * 0.72;
                array_push(_out, vrd_line([{ x: -_w, y: -_f * _len },
                    { x: _w, y: -_f * _len - _girth * 0.10 }], _girth * 0.07, "tuberDark"));
            }
            break;
        }
        case 2: { // fusiform - parsnip: widest a third down, long slow taper to a thread
            __vrd_tap_shade(_out, __vrd_tap_body(2, _girth, _len * 1.25, 1, 0, 0), "tuber", _girth);
            array_push(_out, vrd_line([{ x: -_girth * 0.34, y: -_len * 0.18 },
                { x: -_girth * 0.20, y: -_len * 0.62 }], _girth * 0.13, "tuberLight"));
            break;
        }
        case 3: { // tuber cluster - potato: several oval tubers hung off thin stolons
            var _sx = [-0.85, 0.78, -0.30, 0.42, 0.02];
            var _sy = [0.34, 0.52, 0.74, 0.88, 0.30];
            var _sc = [0.86, 0.95, 0.78, 0.66, 0.52];
            for (var s = 0; s < 5; s++) {
                array_push(_out, vrd_line([{ x: 0, y: 0 },
                    { x: _sx[s] * _girth * 0.9, y: -_sy[s] * _len * 0.85 }], _girth * 0.09, "root"));
            }
            for (var t = 0; t < 5; t++) {
                var _cx = _sx[t] * _girth * 1.05, _cy = -_sy[t] * _len;
                var _ring = [];
                for (var i3 = 0; i3 <= 14; i3++) {
                    var _a3 = (i3 / 14) * pi * 2;
                    array_push(_ring, { x: _cx + cos(_a3) * _girth * 0.62 * _sc[t],
                        y: _cy + sin(_a3) * _girth * 0.48 * _sc[t] });
                }
                __vrd_tap_shade(_out, _ring, "tuber", _girth);
                array_push(_out, vrd_disc(_cx - _girth * 0.2 * _sc[t], _cy + _girth * 0.14 * _sc[t],
                    _girth * 0.09 * _sc[t], "tuberDark"));
            }
            break;
        }
        case 4: { // layered bulb - onion: concentric coats over a flat basal plate
            var _ks = [1.0, 0.72, 0.46];
            for (var k = 0; k < 3; k++) {
                var _pts4 = __vrd_tap_body(4, _girth, _len * (0.95 * _ks[k] + 0.15), _ks[k], 0, 0);
                array_push(_out, vrd_poly(_pts4, (_ks[k] == 1.0) ? "tuber" : "tuberLight"));
                array_push(_out, vrd_line(__vrd_closed(_pts4), _girth * 0.10, "tuberDark"));
            }
            array_push(_out, vrd_line([{ x: -_girth * 0.42, y: -_len * 0.02 },
                { x: _girth * 0.42, y: -_len * 0.02 }], _girth * 0.20, "root"));   // basal plate
            break;
        }
        case 5: { // forked - mandrake: one trunk that splits into two diverging legs
            __vrd_tap_shade(_out, __vrd_tap_body(5, _girth, _len * 0.46, 1, 0, 0), "tuber", _girth);
            var _dd = [-1, 1];
            for (var d = 0; d < 2; d++) {
                var _legs = [];
                var _seg5 = 16;
                for (var i5 = 0; i5 <= _seg5; i5++) {
                    var _f5 = i5 / _seg5;
                    var _w5 = _girth * 0.52 * (1 - _f5) * vrd_ramp(_f5, 0.10);
                    array_push(_legs, { x: _dd[d] * (_girth * 0.20 + _f5 * _girth * 0.85) - _w5,
                        y: -_len * (0.40 + _f5 * 0.62) });
                }
                for (var j5 = _seg5; j5 >= 0; j5--) {
                    var _f6 = j5 / _seg5;
                    var _w6 = _girth * 0.52 * (1 - _f6) * vrd_ramp(_f6, 0.10);
                    array_push(_legs, { x: _dd[d] * (_girth * 0.20 + _f6 * _girth * 0.85) + _w6,
                        y: -_len * (0.40 + _f6 * 0.62) });
                }
                __vrd_tap_shade(_out, _legs, "tuber", _girth);
            }
            break;
        }
        default: { // 0 taproot - carrot: a long cone with lateral rootlets and cross ridges
            __vrd_tap_shade(_out, __vrd_tap_body(0, _girth, _len, 1, 0, 0), "tuber", _girth);
            for (var i0 = 1; i0 <= 5; i0++) {         // ridges - reads as a carrot, not a cone
                var _f0 = i0 / 6.5;
                var _w0 = _girth * power(1 - _f0, 0.62) * 0.82;
                array_push(_out, vrd_line([{ x: -_w0, y: -_f0 * _len },
                    { x: _w0, y: -_f0 * _len - _girth * 0.14 }], _girth * 0.07, "tuberDark"));
            }
            for (var j0 = 0; j0 < 6; j0++) {          // lateral rootlets
                var _f1 = 0.22 + (j0 / 6) * 0.62;
                var _d1 = ((j0 mod 2) != 0) ? 1 : -1;
                var _w1 = _girth * power(1 - _f1, 0.62);
                array_push(_out, vrd_line([{ x: _d1 * _w1, y: -_f1 * _len },
                    { x: _d1 * (_w1 + _girth * 0.75), y: -_f1 * _len - _len * 0.10 }],
                    _girth * 0.06, "root"));
            }
            array_push(_out, vrd_line([{ x: -_girth * 0.36, y: -_len * 0.10 },
                { x: -_girth * 0.14, y: -_len * 0.58 }], _girth * 0.12, "tuberLight"));
            break;
        }
    }
    return _out;
}

/// ── SEED ────────────────────────────────────────────────────────────────────────────────────
/// The husk, in two halves that tilt apart as the shoot leaves. `_open` is 0 closed, 1 fully split;
/// the caller applies `fade` as alpha.
function vrd_seed_parts(_form, _size, _open) {
    var _s = _size;
    var _gap = _open * _s * 0.42;
    var _tilt = _open * 0.55;
    var _r0 = (_form == 0) ? 0.52 : ((_form == 2) ? 1.15 : 0.92);
    var _r1 = (_form == 0) ? 1.25 : ((_form == 2) ? 0.62 : 0.98);
    var _out = [];
    var _dd = [-1, 1];
    for (var d = 0; d < 2; d++) {
        var _dir = _dd[d];
        var _pts = [];
        var _seg = 12;
        var _c = cos(_tilt * _dir), _sn = sin(_tilt * _dir);
        for (var i = 0; i <= _seg; i++) {
            var _a = -pi * 0.5 + (i / _seg) * pi;
            var _px = cos(_a) * _s * _r0 * _dir;
            var _py = sin(_a) * _s * _r1;
            array_push(_pts, { x: _dir * _gap + _px * _c - _py * _sn,
                y: _s * _r1 * 0.55 + _px * _sn + _py * _c });
        }
        array_push(_out, vrd_poly(_pts, "seed"));
        array_push(_out, vrd_line(__vrd_closed(_pts), _s * 0.16, "seedDark"));
    }
    return _out;
}

/// ── FRUIT ───────────────────────────────────────────────────────────────────────────────────
/// 0 berry - 1 pod - 2 drupe - 3 hip - 4 gourd - 5 bunch - 6 melon - 7 strobile - 8 aggregate.
///
/// ⚠️ The first four are all ROUGHLY ONE CIRCLE with a cleft or a calyx added. That was fine while
/// fruit was a garnish on a flower and wrong the moment the fruit IS the product - a hanging grape
/// bunch and a single berry are not the same picture at any size, and the player is looking at the
/// harvest.
function vrd_fruit_parts(_form, _size) {
    var _r = _size * 0.5;
    var _out = [];

    if (_form == 4) {                                  // gourd - a long pear body with ribs
        var _pts = [];
        for (var i = 0; i <= 14; i++) {
            var _f = i / 14;
            array_push(_pts, { x: _size * 0.62 * (0.34 + 0.66 * sin(pi * power(_f, 1.55))),
                y: -_f * _size * 1.9 });
        }
        for (var j = 14; j >= 0; j--) {
            var _f2 = j / 14;
            array_push(_pts, { x: -_size * 0.62 * (0.34 + 0.66 * sin(pi * power(_f2, 1.55))),
                y: -_f2 * _size * 1.9 });
        }
        array_push(_out, vrd_poly(_pts, "fruit"));
        var _ribs = [-0.5, 0, 0.5];
        for (var k = 0; k < 3; k++) {
            var _rib = [];
            for (var m = 0; m <= 10; m++) {
                var _f3 = m / 10;
                array_push(_rib, { x: _size * 0.62 * (0.34 + 0.66 * sin(pi * power(_f3, 1.55))) * _ribs[k],
                    y: -_f3 * _size * 1.9 });
            }
            array_push(_out, vrd_line(_rib, _size * 0.09, "ink"));
        }
        return _out;
    }

    if (_form == 5) {                                  // bunch - a hanging grape cluster
        var _rows = [4, 4, 3, 2, 1];
        var _y = 0;
        for (var r5 = 0; r5 < 5; r5++) {
            var _n = _rows[r5];
            for (var i5 = 0; i5 < _n; i5++) {
                var _x = ((_n == 1) ? 0 : (i5 / (_n - 1) - 0.5)) * _size * 0.92 * (1 - r5 * 0.09);
                array_push(_out, vrd_disc(_x, _y, _size * 0.30, "fruit"));
                array_push(_out, vrd_disc(_x - _size * 0.09, _y + _size * 0.09, _size * 0.11, "fruitLight"));
            }
            _y -= _size * 0.46;
        }
        return _out;
    }

    if (_form == 6) {                                  // melon - a big ribbed sphere
        var _R = _size * 1.15;
        var _ball = [];
        for (var i6 = 0; i6 <= 24; i6++) {
            var _a6 = (i6 / 24) * pi * 2;
            array_push(_ball, { x: cos(_a6) * _R, y: sin(_a6) * _R * 0.86 });
        }
        array_push(_out, vrd_poly(_ball, "fruit"));
        array_push(_out, vrd_disc(-_R * 0.34, _R * 0.30, _R * 0.26, "fruitLight"));
        var _st = [-0.62, -0.21, 0.21, 0.62];
        for (var k6 = 0; k6 < 4; k6++) {
            var _arc = [];
            for (var m6 = 0; m6 <= 10; m6++) {
                var _f6 = m6 / 10;
                array_push(_arc, { x: _st[k6] * _R * sin(pi * _f6) * 1.28, y: -_R * 0.86 + _f6 * _R * 1.72 });
            }
            array_push(_out, vrd_line(_arc, _R * 0.10, "ink"));
        }
        array_push(_out, vrd_line(__vrd_closed(_ball), _R * 0.07, "ink"));
        return _out;
    }

    if (_form == 7) {                                  // strobile - a hop cone of overlapping bracts
        for (var k7 = 0; k7 < 5; k7++) {
            var _f7 = k7 / 4;
            var _y7 = -_f7 * _size * 1.5;
            var _w7 = _size * 0.62 * (1 - 0.62 * _f7);
            var _d7 = [-1, 1];
            for (var d = 0; d < 2; d++) {
                array_push(_out, vrd_poly([{ x: 0, y: _y7 + _size * 0.24 },
                    { x: _d7[d] * _w7, y: _y7 + _size * 0.06 },
                    { x: _d7[d] * _w7 * 0.62, y: _y7 - _size * 0.26 },
                    { x: 0, y: _y7 - _size * 0.10 }],
                    ((k7 mod 2) != 0) ? "fruit" : "fruitLight"));
            }
        }
        array_push(_out, vrd_line([{ x: 0, y: _size * 0.30 }, { x: 0, y: -_size * 1.62 }],
            _size * 0.08, "ink"));
        return _out;
    }

    if (_form == 8) {                                  // aggregate - raspberry: a dome of druplets
        var _gold = 2.39996;
        var _R8 = _size * 0.66;
        for (var i8 = 0; i8 < 14; i8++) {
            var _f8 = (i8 + 0.5) / 14, _rr8 = sqrt(_f8), _a8 = i8 * _gold;
            array_push(_out, vrd_disc(cos(_a8) * _rr8 * _R8, sin(_a8) * _rr8 * _R8 * 0.88,
                _size * 0.24, "fruit"));
        }
        for (var j8 = 0; j8 < 5; j8++) {
            var _b8 = j8 * _gold;
            array_push(_out, vrd_disc(cos(_b8) * _R8 * 0.42 - _size * 0.05,
                sin(_b8) * _R8 * 0.36 + _size * 0.06, _size * 0.08, "fruitLight"));
        }
        for (var k8 = 0; k8 < 5; k8++) {               // the calyx left behind on the stalk
            var _c8 = -pi * 0.5 + (k8 / 4 - 0.5) * 1.8;
            array_push(_out, vrd_line([{ x: 0, y: _R8 * 0.86 },
                { x: cos(_c8) * _R8 * 0.8, y: _R8 * 0.86 + sin(_c8) * _R8 * 0.8 }],
                _size * 0.09, "leafDark"));
        }
        return _out;
    }

    if (_form == 1) {                                  // pod - a long curved capsule
        var _pp = [];
        for (var i1 = 0; i1 <= 12; i1++) {
            var _f1 = i1 / 12;
            array_push(_pp, { x: vrd_leaf_profile(2, _f1) * _size * 2.6, y: -_f1 * _size * 1.7 });
        }
        for (var j1 = 12; j1 >= 0; j1--) {
            var _f2b = j1 / 12;
            array_push(_pp, { x: -vrd_leaf_profile(2, _f2b) * _size * 2.6, y: -_f2b * _size * 1.7 });
        }
        array_push(_out, vrd_poly(_pp, "fruit"));
        array_push(_out, vrd_line(__vrd_closed(_pp), _size * 0.10, "ink"));
        return _out;
    }

    array_push(_out, vrd_disc(0, 0, _r, "fruit"));
    array_push(_out, vrd_disc(-_r * 0.28, _r * 0.28, _r * 0.30, "fruitLight"));
    if (_form == 2) array_push(_out, vrd_line([{ x: 0, y: _r * 0.9 }, { x: 0, y: -_r * 0.9 }],
        _r * 0.16, "ink"));
    if (_form == 3) {
        for (var i9 = 0; i9 < 5; i9++) {
            var _a9 = (i9 / 5) * pi * 2;
            array_push(_out, vrd_line([{ x: 0, y: -_r * 0.8 },
                { x: cos(_a9) * _r * 0.75, y: -_r * 0.8 + sin(_a9) * _r * 0.75 }], _r * 0.14, "ink"));
        }
    }
    return _out;
}

/// ── TENDRIL AND THORN ───────────────────────────────────────────────────────────────────────
/// A tendril is a SPRING: it runs out straight, then coils, and the coil TIGHTENS. A stem's `curve`
/// is a constant turn rate and can only ever make an arc, which is why this is its own op.
function vrd_tendril_parts(_size, _turns) {
    var _pts = [];
    var _seg = 42;
    var _runOut = 0.34;
    for (var i = 0; i <= _seg; i++) {
        var _f = i / _seg;
        if (_f <= _runOut) { array_push(_pts, { x: (_f / _runOut) * _size * 0.52, y: 0 }); continue; }
        var _u = (_f - _runOut) / (1 - _runOut);
        var _a = _u * _turns * pi * 2;
        var _r = _size * 0.30 * (1 - 0.72 * _u);
        array_push(_pts, { x: _size * 0.52 + sin(_a) * _r, y: _r - cos(_a) * _r });
    }
    return [vrd_line(_pts, _size * 0.075, "ink"), vrd_line(_pts, _size * 0.045, "stem")];
}

/// A small RECURVED triangle riding the stem. The hooked back edge matters: a straight triangle
/// reads as a bud.
function vrd_thorn_parts(_size, _side) {
    var _d = (_side < 0) ? -1 : 1;
    var _pts = [{ x: 0, y: -_size * 0.30 }, { x: _d * _size * 1.00, y: _size * 0.34 },
        { x: _d * _size * 0.22, y: _size * 0.26 }, { x: 0, y: _size * 0.34 }];
    return [vrd_poly(_pts, "thorn"), vrd_line(__vrd_closed(_pts), _size * 0.16, "ink")];
}

/// Dispatch: geometry item -> drawable parts. Mirrors the mirror's `primitivesFor`.
/// ⚠️ Returning `undefined` for an unhandled kind is SILENT - the part simply is not measured or
/// drawn - so any new op must be added here in the SAME edit that adds the op.
function vrd_parts_for(_g) {
    switch (_g.kind) {
        case "leaf":    return vrd_leaf_parts(_g.form, _g.size);
        case "crown":   return vrd_crown_parts(_g.form, _g.size);
        case "bloom":   return vrd_bloom_parts(_g.form, _g.petals, _g.size, _g.ang);
        case "fruit":   return vrd_fruit_parts(_g.form, _g.size);
        case "seed":    return vrd_seed_parts(_g.form, _g.size, _g.open);
        case "taproot": return vrd_taproot_parts(_g.form, _g.len, _g.girth);
        case "tendril": return vrd_tendril_parts(_g.size, _g.turns);
        case "thorn":   return vrd_thorn_parts(_g.size, _g.side);
        default:        return undefined;
    }
}

/// ============================================================================================
/// THE DRAW LAYER
/// ============================================================================================

/// Signed area x2 (shoelace). Positive = counter-clockwise.
function __vrd_area2(_p) {
    var _a = 0;
    var _n = array_length(_p);
    for (var i = 0, j = _n - 1; i < _n; j = i++) _a += (_p[j].x * _p[i].y - _p[i].x * _p[j].y);
    return _a;
}
function __vrd_tri_area2(_a, _b, _c) {
    return (_b.x - _a.x) * (_c.y - _a.y) - (_c.x - _a.x) * (_b.y - _a.y);
}
function __vrd_same_pt(_a, _b) { return abs(_a.x - _b.x) <= 0.000000001 && abs(_a.y - _b.y) <= 0.000000001; }
function __vrd_pt_in_tri(_p, _a, _b, _c) {
    var _d1 = __vrd_tri_area2(_a, _b, _p), _d2 = __vrd_tri_area2(_b, _c, _p), _d3 = __vrd_tri_area2(_c, _a, _p);
    var _neg = (_d1 < 0) || (_d2 < 0) || (_d3 < 0);
    var _pos = (_d1 > 0) || (_d2 > 0) || (_d3 > 0);
    return !(_neg && _pos);
}

/// EAR CLIPPING - correct for any simple polygon, which a triangle fan is not.
///
/// ⛔ THE DE-DUPLICATION BLOCK IS NOT TIDYING. Measured on the mirror over the real corpus: without
/// it, 3,059 of 3,933 polygons have no valid triangulation. A leaf's outline is `upper` followed by
/// reversed `lower`, and the half-width is ZERO at both the base and the tip, so the two chains
/// share those vertices. Repeated points are zero-area corners that can never be an ear, and they
/// sit exactly on every candidate triangle's edge so the containment test rejects the other ears
/// too. Every leaf in the product has this property by construction.
///
/// The guard is not decoration either: a self-intersecting outline has NO ear, and without a bound
/// this loop never terminates - which in a Draw event is a hung game. It falls back to a fan, which
/// is exactly what a naive implementation would have drawn anyway.
function vrd_earclip(_poly) {
    var _clean = [];
    for (var c = 0; c < array_length(_poly); c++) {
        var _q = _poly[c];
        var _nc = array_length(_clean);
        if (_nc == 0 || !__vrd_same_pt(_clean[_nc - 1], _q)) array_push(_clean, _q);
    }
    while (array_length(_clean) > 1
        && __vrd_same_pt(_clean[0], _clean[array_length(_clean) - 1])) {
        array_delete(_clean, array_length(_clean) - 1, 1);
    }
    var _n = array_length(_clean);
    if (_n < 3) return [];

    var _p = [];
    if (__vrd_area2(_clean) < 0) {
        for (var r = _n - 1; r >= 0; r--) array_push(_p, _clean[r]);
    } else {
        for (var f = 0; f < _n; f++) array_push(_p, _clean[f]);
    }

    var _idx = [];
    for (var k = 0; k < _n; k++) array_push(_idx, k);
    var _tris = [];
    var _guard = 0;
    var _maxGuard = _n * _n + 16;

    while (array_length(_idx) > 3) {
        if (_guard++ > _maxGuard) return __vrd_fan(_p);
        var _clipped = false;
        var _m = array_length(_idx);
        for (var i = 0; i < _m; i++) {
            var _a = _p[_idx[(i + _m - 1) mod _m]];
            var _b = _p[_idx[i]];
            var _cc = _p[_idx[(i + 1) mod _m]];
            if (__vrd_tri_area2(_a, _b, _cc) <= 0) continue;      // reflex or degenerate
            var _contains = false;
            for (var z = 0; z < _m; z++) {
                var _qq = _p[_idx[z]];
                // Compare by POSITION, not identity: two distinct vertices can share coordinates.
                if (__vrd_same_pt(_qq, _a) || __vrd_same_pt(_qq, _b) || __vrd_same_pt(_qq, _cc)) continue;
                if (__vrd_pt_in_tri(_qq, _a, _b, _cc)) { _contains = true; break; }
            }
            if (_contains) continue;
            array_push(_tris, [_a, _b, _cc]);
            array_delete(_idx, i, 1);
            _clipped = true;
            break;
        }
        if (!_clipped) return __vrd_fan(_p);
    }
    if (array_length(_idx) == 3) array_push(_tris, [_p[_idx[0]], _p[_idx[1]], _p[_idx[2]]]);
    return _tris;
}

/// The fallback. Only reachable on a degenerate outline; kept so a bad polygon draws something
/// imperfect rather than freezing a frame.
function __vrd_fan(_p) {
    var _tris = [];
    for (var i = 1; i < array_length(_p) - 1; i++) array_push(_tris, [_p[0], _p[i], _p[i + 1]]);
    return _tris;
}

/// Resolve a role to a GML colour. Components, never a hex literal: GML's `$` hex is ABGR and would
/// invert every colour in the product silently.
function vrd_role_colour(_pal, _role) {
    if (!variable_struct_exists(_pal, _role)) return c_fuchsia;   // loud, so a gap is obvious
    var _c = _pal[$ _role];
    return make_colour_rgb(_c.r, _c.g, _c.b);
}

/// ── BUILD ONCE, DRAW MANY ───────────────────────────────────────────────────────────────────
/// A plant's geometry is a pure function of (species, t, seed), and ear clipping a 59-point outline
/// is O(n^2). A field of 50 plants re-triangulated every frame is not affordable, and it does not
/// need to be: build a draw list when the plant's STAGE changes and redraw it until it changes
/// again. `vrd_draw_plant` is the convenience path and is documented as the slow one.
function vrd_build(_species, _t, _seed) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_species)) return []; if (!is_numeric(_t)) _t = 1; if (!is_numeric(_seed)) _seed = 0;
    var _geom = vrd_evaluate(_species, _t, _seed);
    var _pal = vrd_palette_for(_species);
    var _list = [];
    for (var i = 0; i < array_length(_geom); i++) {
        var _g = _geom[i];
        var _alpha = variable_struct_exists(_g, "fade") ? _g.fade : 1;

        /*
         * `sub` marks the parts that belong UNDER the soil BY DESIGN - the fibrous root fan and the
         * taproot itself. Everything else is above-ground growth, and a caller needs to tell them
         * apart: a carrot's whole product is meant to be buried, an agave's rosette is not.
         *
         * ⚠️ Without this the hero view drew AGAVE with the earth band straight through the middle
         * of its rosette, because the leaves radiate a full 360 degrees from an origin that sits on
         * the soil line - so half of them were, quite literally, underground. Foxglove's basal leaf
         * had the same problem more subtly. Found by looking at a captured frame; nothing else can
         * see it, since the geometry is exactly what the species program asked for.
         */
        var _sub = (_g.kind == "root" || _g.kind == "taproot");

        if (_g.kind == "root") { array_push(_list, { op: "root", g: _g, pal: _pal, sub: true }); continue; }
        if (_g.kind == "stem") { array_push(_list, { op: "stem", g: _g, pal: _pal, sub: false }); continue; }

        var _parts = vrd_parts_for(_g);
        if (_parts == undefined) continue;
        var _ang = (_g.kind == "leaf" || _g.kind == "tendril" || _g.kind == "thorn") ? _g.ang : 0;
        var _c = cos(_ang), _s = sin(_ang);
        for (var p = 0; p < array_length(_parts); p++) {
            var _prim = _parts[p];
            var _col = vrd_role_colour(_pal, _prim.role);
            if (_prim.t == "disc") {
                var _px = _g.x + _prim.cx * _c - _prim.cy * _s;
                var _py = _g.y + _prim.cx * _s + _prim.cy * _c;
                array_push(_list, { op: "disc", x: _px, y: _py, r: _prim.r, col: _col, a: _alpha, sub: _sub });
                continue;
            }
            var _pts = [];
            for (var q = 0; q < array_length(_prim.pts); q++) {
                var _v = _prim.pts[q];
                array_push(_pts, { x: _g.x + _v.x * _c - _v.y * _s, y: _g.y + _v.x * _s + _v.y * _c });
            }
            if (_prim.t == "poly") {
                array_push(_list, { op: "tris", tris: vrd_earclip(_pts), col: _col, a: _alpha, sub: _sub });
            } else {
                array_push(_list, { op: "line", pts: _pts, w: _prim.w, col: _col, a: _alpha, sub: _sub });
            }
        }
    }
    return _list;
}

/// A stem as a tapering ribbon with an ink margin and a lit edge. The lit edge is one offset
/// polyline rather than a gradient, because GML draws it the same way and a gradient would not have
/// survived the port from the mirror.
function __vrd_draw_stem(_g, _pal, _x, _y, _sc) {
    var _n = array_length(_g.pts);
    var _left = [], _right = [], _lit = [];
    for (var i = 0; i < _n; i++) {
        var _p = _g.pts[i];
        var _q = _g.pts[min(i + 1, _n - 1)];
        var _dx = _q.x - _p.x, _dy = _q.y - _p.y;
        var _L = max(0.0001, sqrt(_dx * _dx + _dy * _dy));
        var _nx = -_dy / _L * (_p.w / 2), _ny = _dx / _L * (_p.w / 2);
        array_push(_left, { x: _p.x + _nx, y: _p.y + _ny });
        array_insert(_right, 0, { x: _p.x - _nx, y: _p.y - _ny });
        array_push(_lit, { x: _p.x + _nx * 0.45, y: _p.y + _ny * 0.45 });
    }
    var _body = [];
    for (var a = 0; a < array_length(_left); a++) array_push(_body, _left[a]);
    for (var b = 0; b < array_length(_right); b++) array_push(_body, _right[b]);

    var _w = max(0.35, (_g.pts[0].w) * 0.18);
    __vrd_draw_tris(vrd_earclip(_body), vrd_role_colour(_pal, "stemDark"), 1, _x, _y, _sc);
    __vrd_draw_line(_lit, _w * 2.1, vrd_role_colour(_pal, "stem"), 1, _x, _y, _sc);
    __vrd_draw_line(__vrd_closed(_body), _w, vrd_role_colour(_pal, "ink"), 1, _x, _y, _sc);
}

/// Roots. A tapering forked system rather than five hairlines - a CULTIVATION product whose soil is
/// the mechanic should show what is under it.
function __vrd_draw_root(_g, _pal, _x, _y, _sc) {
    var _col = vrd_role_colour(_pal, "root");
    var _forks = 5;
    for (var i = 0; i < _forks; i++) {
        var _f = i / (_forks - 1);
        var _side = (_f - 0.5) * 2;
        var _spread = _side * _g.spread;
        var _depth = _g.depth * (1 - 0.45 * abs(_side));
        var _pts = [];
        for (var k = 0; k <= 6; k++) {
            var _u = k / 6;
            array_push(_pts, { x: _spread * power(_u, 1.6), y: _depth * _u });
        }
        __vrd_draw_line(_pts, max(0.5, _g.spread * 0.13 * (1 - 0.4 * abs(_side))), _col, 0.95, _x, _y, _sc);
    }
}

/// Plant space -> screen. THE Y FLIP HAPPENS HERE AND NOWHERE ELSE: authoring in +y-up is why no
/// species has to think in screen coordinates.
function __vrd_draw_tris(_tris, _col, _a, _x, _y, _sc) {
    if (array_length(_tris) == 0) return;
    draw_set_colour(_col);
    draw_set_alpha(_a);
    draw_primitive_begin(pr_trianglelist);
    for (var i = 0; i < array_length(_tris); i++) {
        var _t = _tris[i];
        for (var k = 0; k < 3; k++) draw_vertex(_x + _t[k].x * _sc, _y - _t[k].y * _sc);
    }
    draw_primitive_end();
}

/// A polyline with ROUND caps and joins. GML's `draw_line_width` is a rectangle, so a disc at each
/// vertex is what reproduces the mirror's `stroke-linejoin: round` - without it every ink outline
/// shows notches at the corners.
function __vrd_draw_line(_pts, _w, _col, _a, _x, _y, _sc) {
    var _n = array_length(_pts);
    if (_n < 2) return;
    draw_set_colour(_col);
    draw_set_alpha(_a);
    var _pw = max(1, _w * _sc);
    for (var i = 0; i < _n - 1; i++) {
        draw_line_width(_x + _pts[i].x * _sc, _y - _pts[i].y * _sc,
            _x + _pts[i + 1].x * _sc, _y - _pts[i + 1].y * _sc, _pw);
    }
    if (_pw > 2) {
        for (var k = 0; k < _n; k++) {
            draw_circle(_x + _pts[k].x * _sc, _y - _pts[k].y * _sc, _pw * 0.5, false);
        }
    }
}

/// Draw a built list at a screen position. `_sc` is pixels per plant unit.
function vrd_draw_built(_list, _x, _y, _sc) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_array(_list) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_sc)) return;
    var _oldc = draw_get_colour();
    var _olda = draw_get_alpha();
    for (var i = 0; i < array_length(_list); i++) {
        var _e = _list[i];
        switch (_e.op) {
            case "stem": __vrd_draw_stem(_e.g, _e.pal, _x, _y, _sc); break;
            case "root": __vrd_draw_root(_e.g, _e.pal, _x, _y, _sc); break;
            case "tris": __vrd_draw_tris(_e.tris, _e.col, _e.a, _x, _y, _sc); break;
            case "line": __vrd_draw_line(_e.pts, _e.w, _e.col, _e.a, _x, _y, _sc); break;
            case "disc":
                draw_set_colour(_e.col);
                draw_set_alpha(_e.a);
                draw_circle(_x + _e.x * _sc, _y - _e.y * _sc, max(1, _e.r * _sc), false);
                break;
        }
    }
    draw_set_colour(_oldc);
    draw_set_alpha(_olda);
}

/// ── HOW MUCH ROOM DOES THIS PLANT TAKE? ──────────────────────────────────────────────────────
/// The bounding box of a BUILT list, in PLANT UNITS, with +y still up and the origin still at the
/// soil point - the same space `vrd_build` works in. Multiply by the scale you will pass to
/// `vrd_draw_built` to get pixels.
///
/// ⚠️ THIS EXISTS BECAUSE A PLANT IS NOT A RECTANGLE ABOVE THE LINE, AND ASSUMING IT IS PUT TEXT
/// THROUGH EIGHTEEN SPECIES. The demo captioned each specimen at a fixed offset below the soil
/// mark. That is correct for a grain, whose whole body is above ground - and wrong for every
/// Succulent, whose rosette is centred ON the soil point so half of it hangs below, and wrong for
/// every Root, whose entire product (the carrot) is BELOW the line by design. Measured by
/// capturing the corpus page and looking at it: AGAVE's rosette covered its own name completely.
///
/// A buyer hits the identical problem the first time they put a name, a price or a harvest icon
/// under a plant, so this is public API and not a demo helper. `y1` is the lowest point - negative
/// for anything with a taproot - and `-y1 * scale` is exactly the clearance a caption needs.
function vrd_bounds(_list) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_array(_list)) return { x1: 0, y1: 0, x2: 0, y2: 0, w: 0, h: 0, lift: 0, empty: true };
    var _x1 = 999999, _y1 = 999999, _x2 = -999999, _y2 = -999999;
    var _hit = false;
    /// The lowest point of the ABOVE-GROUND parts only. If it is negative, this plant's foliage is
    /// drawn below its own soil origin, and `lift` is how far to raise it so nothing but root is
    /// buried. See the `sub` note in vrd_build.
    var _ay1 = 0;
    /// Fold one point in. Written out rather than closured: GML method calls in a per-vertex loop
    /// over a 48-species page are not free, and this runs once per build, not per frame.
    for (var i = 0; i < array_length(_list); i++) {
        var _e = _list[i];
        var _pts = undefined;
        switch (_e.op) {
            case "stem": _pts = _e.g.pts; break;
            case "line": _pts = _e.pts;   break;
            /*
             * ⚠️ THE ROOT OP CARRIES NO `pts` AND ASSUMING IT DID CRASHED THE DEMO.
             *     Variable <unknown_object>.pts(100037, -2147483648) not set before reading it.
             * `__vrd_draw_root` GENERATES its five forks at draw time from `{ spread, depth }`, so
             * there is no vertex list to fold - the extreme is simply the widest fork's spread and
             * the deepest fork's depth. `depth` is NEGATIVE (plant space is +y up), which is
             * exactly why a caption placed at a fixed offset landed on the carrot.
             */
            case "root":
                _hit = true;
                _x1 = min(_x1, -abs(_e.g.spread)); _x2 = max(_x2, abs(_e.g.spread));
                _y1 = min(_y1, min(0, _e.g.depth)); _y2 = max(_y2, max(0, _e.g.depth));
                break;
            case "tris":
                for (var t = 0; t < array_length(_e.tris); t++) {
                    var _tri = _e.tris[t];
                    for (var v = 0; v < 3; v++) {
                        _hit = true;
                        _x1 = min(_x1, _tri[v].x); _x2 = max(_x2, _tri[v].x);
                        _y1 = min(_y1, _tri[v].y); _y2 = max(_y2, _tri[v].y);
                        if (!_e.sub) _ay1 = min(_ay1, _tri[v].y);
                    }
                }
                break;
            case "disc":
                _hit = true;
                _x1 = min(_x1, _e.x - _e.r); _x2 = max(_x2, _e.x + _e.r);
                _y1 = min(_y1, _e.y - _e.r); _y2 = max(_y2, _e.y + _e.r);
                if (!_e.sub) _ay1 = min(_ay1, _e.y - _e.r);
                break;
        }
        if (_pts != undefined) {
            for (var p = 0; p < array_length(_pts); p++) {
                _hit = true;
                _x1 = min(_x1, _pts[p].x); _x2 = max(_x2, _pts[p].x);
                _y1 = min(_y1, _pts[p].y); _y2 = max(_y2, _pts[p].y);
                if (!_e.sub) _ay1 = min(_ay1, _pts[p].y);
            }
        }
    }
    /// An empty list is a real case - a seed at t=0 before anything emerges - and returning a box
    /// of +/-999999 would silently push a caption off the screen instead of failing.
    if (!_hit) return { x1: 0, y1: 0, x2: 0, y2: 0, w: 0, h: 0, lift: 0, empty: true };
    return {
        x1: _x1, y1: _y1, x2: _x2, y2: _y2, w: _x2 - _x1, h: _y2 - _y1, empty: false,
        /// Raise the drawing by this many plant units and nothing but root sits below the soil.
        /// Draw with `vrd_draw_built(list, x, soilY - bounds.lift * scale, scale)`.
        lift: -_ay1,
    };
}

/// Convenience: build and draw in one call.
/// ⚠️ THIS IS THE SLOW PATH AND IT SAYS SO. It re-triangulates every polygon on every call. Fine
/// for one hero plant on an inspect panel; for a field, call `vrd_build` when the growth stage
/// changes and `vrd_draw_built` every frame.
function vrd_draw_plant(_x, _y, _species, _t, _seed, _sc) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_species) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_sc)) return; if (!is_numeric(_t)) _t = 1; if (!is_numeric(_seed)) _seed = 0;
    vrd_draw_built(vrd_build(_species, _t, _seed), _x, _y, _sc);
}
