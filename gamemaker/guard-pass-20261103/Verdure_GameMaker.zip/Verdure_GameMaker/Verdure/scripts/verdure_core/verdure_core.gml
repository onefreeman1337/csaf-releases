/// ============================================================================================
/// VERDURE - verdure_core: THE GROWTH MODEL. Pure, and ZERO engine calls.
///
/// Nothing in this file reads an instance, a room, a sprite, the clock or the renderer. The only
/// built-ins used are pure maths (sin/cos/floor/abs/sign/power) and array/struct functions. That is
/// deliberate and it is the wing's main verification lever: GML cannot be unit-tested outside
/// GameMaker, so every algorithm that CAN live where it is reviewable is put there.
///
/// This file is the GML side of `Internal_Ops/stroke.js`. The two must agree exactly, because the
/// 288-state contact sheet that was reviewed by eye was rendered by the JS one.
///
/// ── THE ONE IDEA ────────────────────────────────────────────────────────────────────────────
/// A species is a PROGRAM, not a picture, and a growth stage is that same program evaluated at a
/// different `t`. `vrd_evaluate(species, t, seed)` walks it and returns flat geometry. So a species
/// has ONE definition and six rendered states, adding a stage costs nothing, and a buyer who
/// authors one new species gets six new pictures for free.
///
/// Every op carries an `emerge: [start, full]` window - before `start` it does not exist, after
/// `full` it is complete, between it extends - and optionally a `wither: [start, gone]`, which is
/// the mirror image. Wither exists because with emergence alone every op is monotonic, so a plant
/// could only ever ACCUMULATE, and the first two of six stages were near-empty stubs. Real early
/// growth is the opposite: a husk and two cotyledons dominate, then go away.
///
/// ⛔ THREE PORTING TRAPS, EACH OF WHICH FAILS SILENTLY. Read before editing anything here.
///
///   1. THE RNG IS NOT THE ONE IN THE PRODUCT NEXT DOOR. GML has no `>>>`, so the stream is held
///      as an explicitly masked UNSIGNED 32-bit value. Proven bit-exact against the JS mirror over
///      4,500 draws by `Internal_Ops/_probe/probe_rng_port.js`, WITH a negative control - because a
///      different-but-perfectly-good xorshift draws a different plant and every gate still passes.
///   2. `a ^ b` MEANS DIFFERENT THINGS IN THE TWO LANGUAGES. JS's `^` is 32-bit SIGNED and returns
///      negatives; GML's is unsigned over int64. Reading the two files side by side would show
///      identical-looking lines. That is what the probe is for.
///   3. THE PAINTER SORT MUST BE STABLE. See `vrd_evaluate`.
/// ============================================================================================

#macro VRD_VERSION 1
#macro VRD_SEG 10          // spline segments per stem - MUST match stroke.js's SEG
#macro VRD_MAX_DEPTH 4     // recursion guard: a corrupt program cannot hang the game

/// ── SEEDED RNG ──────────────────────────────────────────────────────────────────────────────
/// xorshift32. Shifts and xors stay exact in both JS numbers and GML's, which is why this
/// generator was chosen over anything cheaper.
///
/// ⚠️ DO NOT "TIDY" THIS INTO THE SHAPE USED ELSEWHERE IN THIS CATALOGUE. A neighbouring product
/// XORs the seed with 0x9E3779B9 unconditionally and runs three warm-up steps; adopting that -
/// the obvious move, since it is proven, local and works - produces a stream that diverges from
/// the reviewed corpus at the very first draw.
function vrd_rng(_seed) {
    var _s = floor(abs(_seed)) & 0xFFFFFFFF;
    if (_s == 0) { _s = 0x9E3779B9; }      // only when the seed is zero, matching the mirror
    return { s: _s };
}

/// Advance the stream and return a float in [0, 1). 5 decimal places, exactly as the mirror:
/// the modulus is part of the contract, not an implementation detail.
function vrd_rng_next(_r) {
    var _s = _r.s;
    _s = (_s ^ ((_s << 13) & 0xFFFFFFFF)) & 0xFFFFFFFF;
    _s = (_s ^ (_s >> 17)) & 0xFFFFFFFF;   // `>>` is safe: _s is never negative here
    _s = (_s ^ ((_s << 5) & 0xFFFFFFFF)) & 0xFFFFFFFF;
    _r.s = _s;
    return (_s mod 100000) / 100000;
}

/// A symmetric jitter in [-amt, +amt]. Every call consumes exactly one draw, so the ORDER of
/// jitter calls is part of the picture - reordering two of them re-rolls every plant downstream.
function vrd_jitter(_r, _amt) {
    return (vrd_rng_next(_r) - 0.5) * 2 * _amt;
}

function vrd_lerp(_a, _b, _t) { return _a + (_b - _a) * _t; }
function vrd_clamp01(_t) { return (_t < 0) ? 0 : ((_t > 1) ? 1 : _t); }

/// Read an optional struct field with a default. GML structs have no `??` for missing keys.
function vrd_get(_s, _key, _default) {
    if (!variable_struct_exists(_s, _key)) return _default;
    var _v = _s[$ _key];
    return (_v == undefined) ? _default : _v;
}

/// ── GROWTH ──────────────────────────────────────────────────────────────────────────────────
/// An op's visibility at growth `t`, in [0, 1]. This is what turns ONE species definition into six
/// rendered states.
function vrd_op_growth(_op, _t) {
    var _e = vrd_get(_op, "emerge", undefined);
    var _a = (_e == undefined) ? 0 : _e[0];
    var _b = (_e == undefined) ? 1 : _e[1];
    var _g;
    if (_t <= _a) { _g = 0; }
    else if (_t >= _b) { _g = 1; }
    else { _g = (_t - _a) / (_b - _a); }

    var _w = vrd_get(_op, "wither", undefined);
    if (_w != undefined) {
        var _c = _w[0], _d = _w[1];
        if (_t >= _d) return 0;
        if (_t > _c) { _g *= 1 - (_t - _c) / (_d - _c); }
    }
    return _g;
}

/// ── EVALUATION ──────────────────────────────────────────────────────────────────────────────
/// Walk a species program at growth `t` and return flat geometry in PLANT SPACE: x right, y UP,
/// 0 = the soil line. Authoring in plant space is why no species has to think in screen
/// coordinates; `verdure_render` flips y exactly once, at the draw call.

/// A tapering spline from `_bx,_by`, plus everything hanging off it. Returns the tip.
function __vrd_stem(_c, _op, _bx, _by, _dir, _scale, _depth) {
    var _g = vrd_op_growth(_op, _c.t);
    if (_g <= 0) return undefined;

    var _len   = vrd_get(_op, "len", 0) * _scale * _g;
    // ⚠️ ORDER IS LOAD-BEARING: curve's jitter is drawn BEFORE lean's. Swapping these two lines
    // re-rolls every plant in the corpus and nothing would report an error.
    var _curve = vrd_get(_op, "curve", 0) + vrd_jitter(_c.r, 0.04);
    var _lean  = vrd_get(_op, "lean", 0)  + vrd_jitter(_c.r, 0.03);

    var _w0 = vrd_get(_op, "w0", 3);
    var _w1 = vrd_get(_op, "w1", 1);

    var _pts = [];
    var _x = _bx, _y = _by, _ang = _dir + _lean;
    for (var i = 0; i <= VRD_SEG; i++) {
        var _f = i / VRD_SEG;
        array_push(_pts, { x: _x, y: _y, w: vrd_lerp(_w0, _w1, _f) * _scale });
        _ang += _curve / VRD_SEG;
        _x += sin(_ang) * (_len / VRD_SEG);
        _y += cos(_ang) * (_len / VRD_SEG);
    }
    array_push(_c.out, { kind: "stem", pts: _pts, palette: vrd_get(_op, "palette", "stem") });

    /// THORNS - the bramble family's exclusive mark. A stem PROPERTY rather than a child op:
    /// `thorns: 7` says what a botanist would say, where seven authored structs per cane would
    /// bury the plant in declarations. They inherit the stem's growth exactly as its width does,
    /// which is also correct - a cane does not sprout its thorns later.
    var _n = floor(vrd_get(_op, "thorns", 0));
    if (_n > 0) {
        var _tsz = vrd_get(_op, "thornSize", 3.2);
        for (var k = 0; k < _n; k++) {
            var _ff = 0.12 + (k / max(1, _n)) * 0.82;
            var _idx = min(array_length(_pts) - 2, floor(_ff * VRD_SEG));
            var _pa = _pts[_idx], _pb = _pts[_idx + 1];
            var _side = ((k mod 2) != 0) ? -1 : 1;
            array_push(_c.out, {
                kind: "thorn", x: _pa.x, y: _pa.y,
                ang: arctan2(_pb.y - _pa.y, _pb.x - _pa.x) + _side * 1.15,
                size: _tsz * _scale, side: _side, palette: "thorn",
            });
        }
    }

    var _tip = _pts[array_length(_pts) - 1];
    var _kids = vrd_get(_op, "children", []);
    for (var j = 0; j < array_length(_kids); j++) {
        var _child = _kids[j];
        var _at = vrd_clamp01(vrd_get(_child, "at", 1));
        var _ai = min(round(_at * VRD_SEG), array_length(_pts) - 1);
        var _anchor = _pts[_ai];
        var _cang = _dir + _lean + (_curve * _at) + vrd_get(_child, "angle", 0);
        __vrd_place(_c, _child, _anchor, _cang, _scale * vrd_get(_child, "scale", 1), _depth + 1);
    }
    return _tip;
}

/// Place one op at an anchor. Unknown kinds THROW rather than draw nothing: a silently ignored op
/// is a species that renders and is quietly missing a part.
function __vrd_place(_c, _op, _anchor, _ang, _scale, _depth) {
    if (_depth > VRD_MAX_DEPTH) return;
    var _g = vrd_op_growth(_op, _c.t);
    if (_g <= 0) return;
    var _kind = _op.kind;
    var _pal = vrd_get(_op, "palette", undefined);

    switch (_kind) {
        case "stem":
        case "branch":
            __vrd_stem(_c, _op, _anchor.x, _anchor.y, _ang, _scale * _g, _depth);
            break;

        case "leaf":
            array_push(_c.out, { kind: "leaf", x: _anchor.x, y: _anchor.y,
                ang: _ang + vrd_get(_op, "angle", 0) + vrd_jitter(_c.r, 0.08),
                size: vrd_get(_op, "size", 8) * _scale * _g,
                form: vrd_get(_op, "form", 0),
                palette: (_pal == undefined) ? "leaf" : _pal });
            break;

        case "bloom":
            array_push(_c.out, { kind: "bloom", x: _anchor.x, y: _anchor.y,
                ang: _ang + vrd_jitter(_c.r, 0.1),
                size: vrd_get(_op, "size", 6) * _scale * _g,
                petals: vrd_get(_op, "petals", 5), form: vrd_get(_op, "form", 0),
                palette: (_pal == undefined) ? "bloom" : _pal });
            break;

        case "fruit":
            array_push(_c.out, { kind: "fruit", x: _anchor.x,
                y: _anchor.y - vrd_get(_op, "hang", 0) * _scale * _g,
                size: vrd_get(_op, "size", 4) * _scale * _g,
                form: vrd_get(_op, "form", 0),
                palette: (_pal == undefined) ? "fruit" : _pal });
            break;

        case "crown":
            array_push(_c.out, { kind: "crown", x: _anchor.x, y: _anchor.y,
                size: vrd_get(_op, "size", 10) * _scale * _g,
                form: vrd_get(_op, "form", 0), ang: _ang,
                palette: (_pal == undefined) ? "crown" : _pal });
            break;

        case "root":
            array_push(_c.out, { kind: "root", x: _anchor.x, y: _anchor.y,
                spread: vrd_get(_op, "spread", 8) * _scale,
                depth: vrd_get(_op, "depth", 8) * _scale * _g,
                palette: (_pal == undefined) ? "root" : _pal });
            break;

        case "taproot":
            /// The ROOT family's storage organ. Unlike `root` - fibrous hair, near-identical on
            /// every species - this IS the species, so it swells on BOTH axes with growth.
            array_push(_c.out, { kind: "taproot", x: _anchor.x, y: _anchor.y,
                len: vrd_get(_op, "len", 20) * _scale * _g,
                girth: vrd_get(_op, "girth", 6) * _scale * _g,
                form: vrd_get(_op, "form", 0),
                palette: (_pal == undefined) ? "tuber" : _pal });
            break;

        case "tendril":
            /// The VINE family's exclusive op, and the reason it is an op rather than a curved
            /// stem: a stem's `curve` is a constant turn rate, so it can only ever produce an arc.
            /// A tendril runs out straight and then coils TIGHTER as it goes. It emerges late and
            /// never withers - a vine that has grabbed does not let go.
            array_push(_c.out, { kind: "tendril", x: _anchor.x, y: _anchor.y,
                ang: _ang + vrd_get(_op, "angle", 0) + vrd_jitter(_c.r, 0.12),
                size: vrd_get(_op, "size", 10) * _scale * _g,
                turns: vrd_get(_op, "turns", 2.4),
                palette: (_pal == undefined) ? "stem" : _pal });
            break;

        case "seed":
            /// The husk the plant came out of. It sits at the soil line, splits wider as the shoot
            /// leaves it, and is gone by the juvenile stage - so it is authored with `wither`.
            /// ⚠️ Size does NOT scale with growth: a husk does not GROW, it is left behind. `_g` is
            /// carried as `fade` and the renderer drops alpha with it.
            array_push(_c.out, { kind: "seed", x: _anchor.x, y: _anchor.y,
                size: vrd_get(_op, "size", 5) * _scale,
                form: vrd_get(_op, "form", 0), open: 1 - _g, fade: _g,
                palette: (_pal == undefined) ? "seed" : _pal });
            break;

        default:
            show_error("verdure: unknown stroke op \"" + string(_kind) + "\"", true);
    }
}

/// Painter order. Roots and the husk go down first, then stems and their furniture, then the
/// things that sit on top.
function __vrd_rank(_kind) {
    switch (_kind) {
        case "root":    return 0;
        case "taproot": return 1;
        case "seed":    return 2;
        case "stem":    return 3;
        case "thorn":   return 4;
        case "tendril": return 5;
        case "crown":   return 6;
        case "leaf":    return 7;
        case "bloom":   return 8;
        case "fruit":   return 9;
        default:        return 10;
    }
}

/// Evaluate a species at growth `t` with jitter seed `_seed`. Returns an array of geometry structs
/// in painter order.
///
/// ⛔ THE SORT IS A STABLE BUCKET PASS, NOT `array_sort`, AND THAT IS DELIBERATE. Two ops of the
/// same kind must stay in AUTHORED order - a bloom declared after another bloom overlaps it, and a
/// comparison sort with equal keys is free to swap them. GML does not document `array_sort` as
/// stable, and JS's is, so the reviewed contact sheet was produced under stable ordering. Swapping
/// two same-rank items changes which one is on top: a real visual difference, from a data
/// structure detail, with nothing to report it.
function vrd_evaluate(_species, _t, _seed) {
    var _ctx = { t: _t, r: vrd_rng(_seed), out: [] };
    var _prog = _species.program;
    var _origin = { x: 0, y: 0, w: 3 };
    for (var i = 0; i < array_length(_prog); i++) {
        __vrd_place(_ctx, _prog[i], _origin, 0, 1, 0);
    }

    var _sorted = [];
    for (var _rank = 0; _rank <= 10; _rank++) {
        for (var j = 0; j < array_length(_ctx.out); j++) {
            if (__vrd_rank(_ctx.out[j].kind) == _rank) array_push(_sorted, _ctx.out[j]);
        }
    }
    return _sorted;
}

/// ── SAVE FORMAT ─────────────────────────────────────────────────────────────────────────────
/// A plant is a SEED and a planting time, nothing else:
///
///     { v, s, at, lin }     s = species seed, at = planted time, lin = parent tree if bred
///
/// Derivation IS the load path, so a save cannot disagree with the generator - there is nothing
/// else stored to disagree with. No cached stroke list, no baked picture, no stored stage.
///
/// ⛔ THE ONE SHARP EDGE, STATED HERE AND IN THE README RATHER THAN LEFT AS FOLKLORE: a seed
/// resolves into corpus INDICES. Appending a species is always safe. Reordering or removing one
/// silently rewrites every plant a player has grown - no error, no warning, their prize specimen
/// quietly becomes a different plant. `v` is versioned from day one so a deliberate break can be
/// migrated rather than merely regretted.
function vrd_plant_create(_species_seed, _now) {
    return { v: VRD_VERSION, s: _species_seed, at: _now, lin: undefined };
}

/// Growth `t` in [0,1] for a plant at time `_now`, given how long this species takes to mature.
function vrd_plant_t(_plant, _now, _span) {
    if (_span <= 0) return 1;
    return vrd_clamp01((_now - _plant.at) / _span);
}

/// Resolve a plant's seed to a corpus entry. See the append-only warning above.
function vrd_plant_species(_plant) {
    var _c = vrd_species_corpus();
    return _c[abs(floor(_plant.s)) mod array_length(_c)];
}
