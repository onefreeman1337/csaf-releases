/// VERDURE demo - Step.

/// -quit N from the command line. An unattended capture must be able to end the process it
/// started; leaving a headless GameMaker window running is how a capture box accumulates a dozen
/// invisible copies of the demo, each still drawing.
if (is_selftest) exit;   // Create built nothing - see its note on game_end() being a flag

frame_count += 1;
if (quit_after > 0 && frame_count >= quit_after) game_end();

/// The garden advances itself and rebuilds only the plots whose growth STAGE changed.
vrd_garden_step(garden);

/// When a plot reaches full growth, replant it with a different species so the row keeps moving.
/// This is also the demo's own long-running smoke test: leave it open and every species in the
/// corpus eventually draws itself, unattended.
for (var i = 0; i < array_length(garden.plots); i++) {
    var _p = garden.plots[i];
    if (_p == undefined) continue;
    if (vrd_plant_t(_p.plant, garden.now, _p.span) >= 1) {
        /// Replant with a species NOT currently in the row, for the same reason the initial pick
        /// is distinct: leave the demo running for ten minutes and it must never show the same
        /// plant twice side by side.
        garden_species[i] = -1;
        var _next = vrd_demo_pick_unused(garden_species);
        garden_species[i] = _next;
        vrd_garden_plant(garden, i, _next, 9 + irandom(8));
    }
}

if (keyboard_check_pressed(vk_tab)) {
    view_mode = (view_mode + 1) mod 4;
}

if (view_mode == 1) {
    if (keyboard_check_pressed(vk_space)) {
        hero_index = (hero_index + 1) mod array_length(corpus);
        vrd_demo_rebuild_hero();
        vrd_demo_refit_hero();   // the frame is per-SPECIES, so it moves here and nowhere else
    }
    /// Scrub growth. Held, not tapped, so a buyer can watch the plant BUILD ITSELF - which is the
    /// thing being sold, and the thing a static screenshot cannot show.
    var _move = (keyboard_check(vk_right) ? 1 : 0) - (keyboard_check(vk_left) ? 1 : 0);
    if (_move != 0) {
        hero_t = clamp(hero_t + _move * vrd_dt() * 0.55, 0, 1);
        var _st = floor(hero_t * VRD_STAGES);
        if (_st != hero_stage) { hero_stage = _st; vrd_demo_rebuild_hero(); }
    }
}

if (view_mode == 3) {
    if (keyboard_check_pressed(vk_space)) hero_index = (hero_index + 1) mod array_length(corpus);
    if (keyboard_check_pressed(vk_right)) hero_index = (hero_index + 1) mod array_length(corpus);
    if (keyboard_check_pressed(vk_left))  hero_index = (hero_index + array_length(corpus) - 1) mod array_length(corpus);
    /// Six builds is real work - only redo it when the species actually changes.
    if (stage_built_for != hero_index) {
        stage_built = [];
        for (var s = 0; s < 6; s++) {
            var _sl = vrd_build(corpus[hero_index], stage_t[s], 1234);
            array_push(stage_built, { t: stage_t[s], list: _sl, bounds: vrd_bounds(_sl) });
        }
        stage_built_for = hero_index;
    }
}

if (view_mode == 2) {
    var _pages = ceil(array_length(corpus) / 12);
    if (keyboard_check_pressed(vk_right)) grid_page = (grid_page + 1) mod _pages;
    if (keyboard_check_pressed(vk_left))  grid_page = (grid_page + _pages - 1) mod _pages;
    if (grid_page != grid_page_built) {
        grid_built = [];
        var _from = grid_page * 12;
        for (var g = _from; g < min(_from + 12, array_length(corpus)); g++) {
            /// Bounds are cached with the build, never recomputed per frame: vrd_bounds walks every
            /// vertex of every triangle, and twelve fully-grown specimens is real work to repeat 60
            /// times a second for a number that cannot change until the build does.
            var _l = vrd_build(corpus[g], 1.0, 1234);
            array_push(grid_built, { sp: corpus[g], list: _l, bounds: vrd_bounds(_l) });
        }
        grid_page_built = grid_page;
    }
}
