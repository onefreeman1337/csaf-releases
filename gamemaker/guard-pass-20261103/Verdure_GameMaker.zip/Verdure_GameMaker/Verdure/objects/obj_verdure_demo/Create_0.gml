/// VERDURE demo - Create.
///
/// ⛔ THE DEMO ROOM IS MANDATORY IN THIS PRODUCT, AND IT IS NOT A FORMALITY. GML cannot be
/// unit-tested outside GameMaker, so this room is simultaneously the buyer's quickstart, the source
/// of every store GIF, and the ONLY real smoke test the engine allows. If it opens and the garden
/// grows, the whole chain - corpus data, growth model, geometry, triangulation, palette, draw - is
/// working. If it does not, the failure is visible in one glance rather than buried in a log.
///
/// It is also deliberately SMALL: one screen, no menus, no assets. Everything on it is generated.
///
/// WHAT IT SHOWS, in the order a buyer will read it:
///   1. a row of plots growing in real time, each a different species
///   2. one HERO plant, large, that you can step through the six named growth stages
///   3. the whole 48-species corpus as a browsable grid
/// Press SPACE to cycle the hero species, LEFT/RIGHT to scrub its growth, TAB to switch view.
///
/// COMMAND LINE. Every view can also be opened directly, which is why these exist:
///   -view N   0 garden · 1 one plant · 2 corpus grid       -hero N  species index for view 1
///   -t F      growth 0..1 for view 1                       -page N  corpus page for view 2
///   -seed N   fix the RNG (omit for a different garden every launch)
///   -quit N   exit after N frames
/// ⚠️ THE CAPTURE PATH DEPENDS ON THESE AND SO DOES ANY BUG REPORT. An UNFOCUSED GameMaker window
/// stops repainting, so keystrokes cannot drive an unattended screenshot - this wing measured that
/// on Athanor and Menagerie and both ship the same switch. One process per view is the only thing
/// that works. They are equally the honest way for a buyer to reproduce a screen from the listing.

window_set_caption("Verdure - a cultivation system that draws its own plants");

/// The registry is where a buyer appends their OWN species. Empty here on purpose - the demo runs
/// entirely on the shipped corpus, so nothing on screen depends on demo-only content.
reg = vrd_registry_create();
corpus = vrd_corpus(reg);

view_mode   = 0;              // 0 = garden · 1 = one plant · 2 = corpus grid · 3 = growth stages
hero_index  = 0;
hero_t      = 1.0;
hero_built  = undefined;
hero_stage  = -1;
grid_page   = 0;
frame_count = 0;
quit_after  = -1;

/// View 3 caches one species at all six named stages. This is the view that ANSWERS the question a
/// buyer actually has - "are these six drawings, or one program at six values of t?" - so it is
/// worth its own screen rather than being something you infer from scrubbing the hero.
stage_built     = [];
stage_built_for = -1;

/// --- command line ---------------------------------------------------------------------------
/// Parsed BEFORE the garden is planted, because -seed has to reach the irandom() calls below or it
/// fixes nothing. Values are read raw here and clamped against the corpus after it exists.
var _cli_seed = undefined;
var _cli_selftest = false;
var _cli_warm = 0;
var _pc = parameter_count();
for (var _i = 1; _i < _pc; _i++) {
    var _p = parameter_string(_i);
    if      (_p == "-selftest") { _cli_selftest = true; }
    else if (_p == "-view" && _i + 1 < _pc) { view_mode  = clamp(real(parameter_string(_i + 1)), 0, 3); _i++; }
    else if (_p == "-hero" && _i + 1 < _pc) { hero_index = max(0, real(parameter_string(_i + 1))); _i++; }
    else if (_p == "-t"    && _i + 1 < _pc) { hero_t     = clamp(real(parameter_string(_i + 1)), 0, 1); _i++; }
    else if (_p == "-page" && _i + 1 < _pc) { grid_page  = max(0, real(parameter_string(_i + 1))); _i++; }
    else if (_p == "-seed" && _i + 1 < _pc) { _cli_seed  = real(parameter_string(_i + 1)); _i++; }
    else if (_p == "-warm" && _i + 1 < _pc) { _cli_warm  = max(0, real(parameter_string(_i + 1))); _i++; }
    else if (_p == "-quit" && _i + 1 < _pc) { quit_after = real(parameter_string(_i + 1)); _i++; }
}
hero_index = hero_index mod array_length(corpus);
grid_page  = grid_page mod ceil(array_length(corpus) / 12);

/// -selftest: run the whole corpus through the whole pipeline IN THE ENGINE, write the result
/// beside the executable, and exit. This is the only real test GML allows (see verdure_selftest),
/// and it is what the unattended capture runs before it photographs anything - a screenshot of a
/// product that is about to crash on the next page is worse than no screenshot.
is_selftest = _cli_selftest;
if (_cli_selftest) {
    var _r = vrd_selftest(reg, true);
    show_debug_message("VERDURE SELFTEST: " + _r.summary);
    game_end();
    /// game_end() only FLAGS the shutdown - Create finishes and Step still runs at least once.
    /// Leaving here without building the garden is therefore only safe because Step and Draw both
    /// check `is_selftest` first; forgetting that guard would replace a clean test run with a
    /// null-struct crash, and the test would "fail" for reasons that have nothing to do with it.
    exit;
}

if (_cli_seed == undefined) randomise(); else random_set_seed(_cli_seed);

/// ── the garden row: six plots, six different species, each on its own growth span ────────────
/// Spans differ so the row is never uniform - a rank of identical plants at identical growth is
/// the single most artificial thing a cultivation demo can show.
garden = vrd_garden_create(reg);
demo_slots = 6;

/// Pick DISTINCT species. A plain irandom per plot duplicated one on the very first capture
/// (CAMPANULA twice in six plots), and a row that repeats itself is the exact thing this view is
/// meant to disprove - six different species at six different points of one program.
function vrd_demo_pick_unused(_used) {
    var _n = array_length(corpus);
    for (var _try = 0; _try < 64; _try++) {
        var _c = irandom(_n - 1);
        var _seen = false;
        for (var _u = 0; _u < array_length(_used); _u++) if (_used[_u] == _c) { _seen = true; break; }
        if (!_seen) return _c;
    }
    return irandom(_n - 1);   // 48 species and 6 plots, so this is unreachable in practice
}

garden_species = [];
for (var i = 0; i < demo_slots; i++) {
    var _seed = vrd_demo_pick_unused(garden_species);
    array_push(garden_species, _seed);
    vrd_garden_plant(garden, i, _seed, 9 + i * 2.5);
}

/// -warm N: advance the garden clock N seconds before the first frame. Spans run 9-21.5 s, so a
/// cold open shows six seedlings between 20% and 48% - honest, and the least interesting moment in
/// the product's life. This is what an unattended capture uses to photograph a row that has
/// actually grown, and what a buyer uses to see the end state without waiting for it.
/// It is a jump in the SAME clock the demo already runs on, not a separate code path: the row that
/// appears is the row that would have appeared if you had left it open that long.
if (_cli_warm > 0) {
    garden.now += _cli_warm;
    vrd_garden_step(garden);
}

/// Stage names, for the hero readout. These are the six the corpus was authored and reviewed
/// against, so a buyer reading the sheet and a buyer reading this screen see the same words.
stage_names = ["SEED", "SPROUT", "JUVENILE", "MATURE", "FLOWERING", "FRUITING"];
stage_t     = [0.05, 0.25, 0.45, 0.68, 0.86, 1.0];

/// Rebuild the hero's draw list. Called on any change, never per frame - see verdure_bind's note
/// on why the cache exists.
/// ⛔ THE FRAME IS FITTED TO THE SPECIES AT FULL GROWTH, NOT TO THE CURRENT t.
/// Found by building the growth GIF and looking at consecutive frames: fitting each value of t to
/// the band independently means the scale and the soil line are RECOMPUTED as the plant grows, so
/// the horizon slides up the screen and the plant barely changes size. On a GIF that is a jitter;
/// in the demo, holding RIGHT slides the ground under a plant that is supposed to be growing out of
/// it, which reads as a rendering bug even to someone who could not say why.
///
/// Fitting to the t=1 bounds instead pins both for the whole scrub, so growth is the ONLY thing
/// that moves - which is the entire point of the view. Recomputed only when the species changes.
function vrd_demo_rebuild_hero() {
    hero_built = vrd_build(corpus[hero_index], hero_t, 1234);
}
function vrd_demo_refit_hero() {
    hero_frame = vrd_bounds(vrd_build(corpus[hero_index], 1.0, 1234));
}
vrd_demo_rebuild_hero();
vrd_demo_refit_hero();

/// The corpus grid is built lazily, one page at a time: 48 species x a full triangulation is real
/// work and there is no reason to pay for pages nobody opens.
grid_built = [];
grid_page_built = -1;
