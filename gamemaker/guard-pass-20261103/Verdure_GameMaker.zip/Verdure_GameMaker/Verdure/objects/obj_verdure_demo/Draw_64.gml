/// VERDURE demo - Draw GUI.
///
/// ⛔ NOTHING HERE USES A GAMEMAKER DEFAULT. No stock font, no `draw_text` at the default size on a
/// grey background, no built-in window skin. Master CLAUDE.md §1.1a is explicit about why: a buyer
/// is choosing what THEIR game will look like, and a screen rendered in the engine's own chrome
/// says "you could have made this" in the two seconds someone spends on a thumbnail. The panel, the
/// rules, the soil band and the type are all drawn here.
///
/// ⛔ THE HORIZON AND THE SCALE ARE DERIVED FROM THE PLANT, NOT TYPED. Rewritten 2026-08-18 after
/// capturing the built exe three times and looking at the frames.
///
/// The first version put one horizon at 0.74H and one scale on every view, and it was wrong in
/// every direction at once: the garden was 55% empty, the corpus grid's top row floated in mid-air
/// while the horizon sliced through its bottom row, and every species drew at 1.15x - a page
/// selling "48 hand-authored species" on which not one of them was legible.
///
/// The second version tuned those constants by eye until the page in front of me looked right. It
/// then broke on the pages I had not opened: an ARBOR is the tallest thing in the corpus and needs
/// the ground low; a ROOT draws its entire product BELOW the line and needs it high. At a fixed
/// 7.6x the mature CARROT ran off the bottom of the screen and its name was printed across it.
///
/// A constant cannot serve both, so nothing here is a constant. `vrd_bounds` reports how far this
/// plant rises above the soil and how far it descends below it, and the layout is FITTED to that.
/// The rule generalises past this demo: any buyer drawing a plant into a panel needs exactly this
/// arithmetic, which is why `vrd_bounds` is public API rather than a demo helper.

if (is_selftest) exit;   // Create built nothing - see its note on game_end() being a flag

var _W = display_get_gui_width();
var _H = display_get_gui_height();
var _g = vrd_palette_ground();

/// Fit a plant of `_rise` above and `_drop` below the soil into the vertical band `_top.._bottom`,
/// never magnifying past `_maxsc` (a seedling blown up to fill the screen is just a blurry seedling)
/// and never wider than `_maxw`. Returns the scale to draw at and where the soil line lands.
///
/// ⚠️ `_align` MATTERS AND TOP-ALIGNING WAS WRONG. Measured on the six-stage view: because the cap
/// at `_maxsc` binds for short species, the fitted block was much smaller than the band, and
/// top-aligning it left a 240 px empty stripe between the ground line and the captions - Gate 1's
/// dead-space failure, reintroduced by the very function written to prevent it.
///   0 CENTRE the block in the band  - right for a specimen study, where the plant is the subject.
///   1 BOTTOM-align it               - right for the garden, where the point is a low horizon with
///                                     the row standing on it; centring floats the earth mid-screen.
function vrd_demo_fit(_rise, _drop, _wide, _top, _bottom, _maxsc, _maxw, _align = 0) {
    var _h  = max(0.001, _rise + _drop);
    var _sc = min(_maxsc, (_bottom - _top) / _h);
    if (_wide > 0) _sc = min(_sc, _maxw / _wide);
    if (_align == 1) return { sc: _sc, soil: _bottom - _drop * _sc };
    var _slack = (_bottom - _top) - _h * _sc;
    return { sc: _sc, soil: _top + _slack * 0.5 + _rise * _sc };
}

/// Each view earns its own horizon. The garden and the hero are ELEVATIONS - one ground plane, the
/// plant standing on it. The corpus is a PLATE - many specimens, each on its own short ground mark,
/// the way a herbarium sheet is set. Forcing a single full-width horizon across the plate is what
/// put a line through the middle of a row.
var _plate = (view_mode == 2 || view_mode == 3);
var _soil  = _H * 0.80;
var _fit   = undefined;

if (view_mode == 0) {
    /// The row is fitted to its DEEPEST and TALLEST current occupants together, so a carrot at full
    /// growth beside a sapling still has its taproot on screen.
    var _r = 0.001, _d = 0;
    for (var i = 0; i < array_length(garden.plots); i++) {
        var _p = garden.plots[i];
        if (_p == undefined || _p.built == undefined) continue;
        var _b = vrd_bounds(_p.built);
        if (_b.empty) continue;
        /// Measured AFTER the lift, because that is what will actually be on screen.
        _r = max(_r, _b.y2 + _b.lift); _d = max(_d, max(0, -_b.y1 - _b.lift));
    }
    _fit  = vrd_demo_fit(_r, _d, 0, 142, _H - 152, 4.6, _W, 1);   // bottom-aligned: a low horizon
    _soil = _fit.soil;
}
if (view_mode == 1 && hero_built != undefined) {
    /// `hero_frame` is the species at FULL growth, cached when the species changes - see the note on
    /// vrd_demo_refit_hero. Fitting to `hero_built` (the CURRENT t) instead re-derives the scale and
    /// the horizon on every frame of a scrub, which slides the ground under the plant.
    var _hb = hero_frame;
    _fit  = vrd_demo_fit(max(0.001, _hb.y2 + _hb.lift), max(0, -_hb.y1 - _hb.lift),
                         _hb.w, 142, _H - 172, 9.5, _W - 320);
    _soil = _fit.soil;
}

/// ── the plate ────────────────────────────────────────────────────────────────────────────────
/// Near-black earth with one warm horizon line. The soil is deliberately almost black: a cutaway
/// wants the ground to RECEDE so the plant is the brightest thing on screen. A mid-brown band was
/// tried and it swallowed every pale root.
draw_set_colour(make_colour_rgb(_g.paper.r, _g.paper.g, _g.paper.b));
draw_rectangle(0, 0, _W, _H, false);

if (!_plate) {
    draw_set_colour(make_colour_rgb(_g.soil.r, _g.soil.g, _g.soil.b));
    draw_rectangle(0, _soil, _W, _H, false);
    draw_set_colour(make_colour_rgb(_g.soilLine.r, _g.soilLine.g, _g.soilLine.b));
    draw_rectangle(0, _soil, _W, _soil + 2, false);
}

draw_set_font(fnt_verdure);
draw_set_valign(fa_top);

/// ── title ────────────────────────────────────────────────────────────────────────────────────
draw_set_font(fnt_verdure_title);
draw_set_halign(fa_left);
draw_set_colour(make_colour_rgb(214, 226, 196));
draw_text(38, 30, "VERDURE");
draw_set_font(fnt_verdure);
draw_set_colour(make_colour_rgb(122, 142, 112));
draw_text(38, 66, "every plant is drawn by the product - no sprites, no texture pages, no PNG");

/// a hairline rule under the title, because a heading with nothing under it reads as placeholder
draw_set_colour(make_colour_rgb(52, 66, 48));
draw_rectangle(38, 92, _W - 38, 93, false);

/// ── views ────────────────────────────────────────────────────────────────────────────────────
if (view_mode == 0) {
    draw_set_colour(make_colour_rgb(160, 182, 148));
    draw_text(38, 106, "THE GARDEN - six plots growing in real time. Each replants itself when ripe.");
    /// The garden draws at the soil line; plant space is +y up and the flip happens inside the
    /// renderer, so nothing here converts coordinates.
    var _gsc = (_fit == undefined) ? 4.0 : _fit.sc;
    vrd_garden_draw(garden, 145, _soil, 200, _gsc);

    /// The caption block sits at a FIXED height, because the fit above already guarantees the whole
    /// row - taproots included - finishes above it. Letting it chase the deepest plant made it jump
    /// every few seconds as the garden replanted itself, which reads as a bug even when it is not.
    var _gly = _H - 142;

    for (var i = 0; i < array_length(garden.plots); i++) {
        var _p = garden.plots[i];
        if (_p == undefined) continue;
        var _sp = vrd_plot_species(garden, _p);
        var _t  = vrd_plant_t(_p.plant, garden.now, _p.span);
        var _cx = 145 + i * 200;
        draw_set_halign(fa_center);

        /// A per-plot growth bar under the name. The row's whole point is that six plants are at
        /// six different points of one program, and a bare percentage does not show that at a
        /// glance the way six bars of different lengths do.
        draw_set_colour(make_colour_rgb(38, 50, 36));
        draw_rectangle(_cx - 52, _gly + 28, _cx + 52, _gly + 32, false);
        draw_set_colour(make_colour_rgb(124, 168, 92));
        draw_rectangle(_cx - 52, _gly + 28, _cx - 52 + 104 * _t, _gly + 32, false);

        draw_set_colour(make_colour_rgb(150, 172, 140));
        draw_text(_cx, _gly, string_upper(_sp.name));
        draw_set_colour(make_colour_rgb(100, 120, 94));
        draw_text(_cx, _gly + 40, string(floor(_t * 100)) + "%");
    }
}

if (view_mode == 1) {
    var _sp = corpus[hero_index];
    draw_set_halign(fa_left);
    draw_set_colour(make_colour_rgb(160, 182, 148));
    draw_text(38, 106, "ONE PLANT - hold LEFT/RIGHT to grow it. SPACE for the next species.");

    /// The hero fills the plate - the fit above scales it to the band and puts the soil line where
    /// this particular species needs it. A mature ARBOR ends up with its crown just under the rule
    /// and a mature CARROT with its taproot just above the readout; the same two numbers do both.
    var _hsc = (_fit == undefined) ? 7.6 : _fit.sc;
    /// `lift` keeps foliage out of the earth. AGAVE's rosette radiates a full 360 degrees from an
    /// origin ON the soil line, so without this the opaque earth band ran through the middle of it
    /// and the plant read as half-buried; FOXGLOVE's basal leaf had the same fault, smaller.
    if (hero_built != undefined) {
        var _hlift = vrd_bounds(hero_built).lift;
        vrd_draw_built(hero_built, _W * 0.5, _soil - _hlift * _hsc, _hsc);
    }

    /// the readout: species, family, and which of the six named stages this t falls in
    var _label = stage_names[0];
    for (var s = 0; s < 6; s++) if (hero_t >= stage_t[s]) _label = stage_names[s];

    /// Fixed, for the same reason as the garden's: the fit guarantees the plant is above it, and a
    /// readout that slides up and down as you scrub growth is worse than one that stays put.
    var _hy = _H - 162;

    draw_set_halign(fa_center);
    draw_set_font(fnt_verdure_title);
    draw_set_colour(make_colour_rgb(222, 234, 204));
    draw_text(_W * 0.5, _hy, string_upper(_sp.name));
    draw_set_font(fnt_verdure);
    draw_set_colour(make_colour_rgb(126, 148, 116));
    draw_text(_W * 0.5, _hy + 32, string_upper(_sp.family) + "   /   " +_label
        + "   /   " +string(floor(hero_t * 100)) + "%");

    /// A growth bar with the six stage ticks marked on it - so the buyer can SEE that the six
    /// states on the store page are the same program at six values of t, not six drawings.
    var _bx = _W * 0.5 - 220, _bw = 440, _by = _hy + 62;
    draw_set_colour(make_colour_rgb(40, 52, 38));
    draw_rectangle(_bx, _by, _bx + _bw, _by + 6, false);
    draw_set_colour(make_colour_rgb(124, 168, 92));
    draw_rectangle(_bx, _by, _bx + _bw * hero_t, _by + 6, false);
    draw_set_colour(make_colour_rgb(76, 96, 68));
    for (var k = 0; k < 6; k++) {
        var _tx = _bx + _bw * stage_t[k];
        draw_rectangle(_tx, _by - 5, _tx + 1, _by + 11, false);
    }
}

if (view_mode == 2) {
    draw_set_halign(fa_left);
    draw_set_colour(make_colour_rgb(160, 182, 148));
    draw_text(38, 106, "THE CORPUS - " + string(array_length(corpus))
        + " hand-authored species, 6 growth stages each. LEFT/RIGHT to page.");

    /// A PLATE, not a screen with a horizon across it. Each specimen stands on its own short
    /// ground mark; the marks together read as a set, and no line ever crosses a plant that is not
    /// standing on it. Twelve per page at 2.5x - the previous 1.15x made the page selling "48
    /// hand-authored species" the page on which none of them was legible.
    /// ⚠️ A FIXED LABEL OFFSET CANNOT WORK HERE, AND TWO ATTEMPTS AT ONE PROVED IT. At +10 the name
    /// was struck through by MILLET's and SORGHUM's basal leaves; at +26 that page was clean and the
    /// NEXT page was worse than the first - AGAVE's rosette is centred ON the soil point so half of
    /// it hangs below, and every Root species draws its entire product (the carrot) underground by
    /// design. Both were found by capturing the page and looking at it.
    ///
    /// So the caption clears the PLANT, not the line: `vrd_bounds` reports the built list's lowest
    /// point and the row takes the deepest of its twelve, so the labels still align as a row.
    ///
    /// AND THE ROW BASELINES ARE DERIVED, NOT TYPED. Fixed fractions of the height cannot serve
    /// both pages: the Arbor page's specimens are the tallest in the corpus and the Root page's are
    /// the deepest, so any pair of constants that clears one page collides on the other. Each row
    /// is measured, then the two blocks are distributed down the space the header and footer leave.
    var _cols = 6;
    var _cw   = (_W - 120) / _cols;
    var _sc   = 2.15;
    var _rows = ceil(array_length(grid_built) / _cols);

    var _drop = [0, 0];     // deepest descent below the ground mark, per row, in pixels
    var _rise = [0, 0];     // tallest ascent above it
    for (var i = 0; i < array_length(grid_built); i++) {
        var _r = i div _cols;
        var _gb = grid_built[i].bounds;
        _drop[_r] = max(_drop[_r], max(0, -_gb.y1 - _gb.lift) * _sc);
        _rise[_r] = max(_rise[_r],  (_gb.y2 + _gb.lift) * _sc);
    }

    var _top = 142, _bot = _H - 48;
    var _cap = 36;                                                  // two caption lines
    var _blk = [0, 0];
    for (var r = 0; r < _rows; r++) _blk[r] = _rise[r] + max(24, _drop[r] + 14) + _cap;
    var _slack = (_bot - _top) - (_blk[0] + (_rows > 1 ? _blk[1] : 0));
    var _pad   = max(6, _slack / (_rows + 1));

    var _base = [0, 0];
    _base[0] = _top + _pad + _rise[0];
    if (_rows > 1) _base[1] = _top + _pad + _blk[0] + _pad + _rise[1];

    for (var i = 0; i < array_length(grid_built); i++) {
        var _e  = grid_built[i];
        var _row = i div _cols;
        var _cx = 60 + _cw * 0.5 + (i mod _cols) * _cw;
        var _cy = _base[_row];
        var _ly = _cy + max(24, _drop[_row] + 14);

        /// the ground mark: a short warm rule under this specimen only
        draw_set_colour(make_colour_rgb(_g.soilLine.r, _g.soilLine.g, _g.soilLine.b));
        draw_rectangle(_cx - _cw * 0.36, _cy, _cx + _cw * 0.36, _cy + 1, false);

        vrd_draw_built(_e.list, _cx, _cy - _e.bounds.lift * _sc, _sc);

        draw_set_halign(fa_center);
        draw_set_colour(make_colour_rgb(132, 152, 122));
        draw_text(_cx, _ly, string_upper(_e.sp.name));
        draw_set_colour(make_colour_rgb(84, 100, 78));
        draw_text(_cx, _ly + 20, string_upper(_e.sp.family));
    }

    /// page pips, so 48 reads as a corpus with a position in it rather than an unbounded list
    var _pages = ceil(array_length(corpus) / 12);
    for (var p = 0; p < _pages; p++) {
        draw_set_colour(p == grid_page ? make_colour_rgb(124, 168, 92) : make_colour_rgb(52, 66, 48));
        draw_rectangle(_W - 38 - (_pages - p) * 16, 112, _W - 38 - (_pages - p) * 16 + 10, 116, false);
    }
}

if (view_mode == 3) {
    /// ⛔ THE VIEW THAT ANSWERS THE ONLY QUESTION THAT MATTERS. A buyer looking at six pictures of a
    /// plant has no way to know whether they are six DRAWINGS or one program evaluated at six values
    /// of t - and the whole product is the second thing. Six panels of the same species, same seed,
    /// same code path, differing only in t, on one screen, is the proof. It is also the single most
    /// convincing image this product can put on a store page.
    var _sp3 = corpus[hero_index];
    draw_set_halign(fa_left);
    draw_set_colour(make_colour_rgb(160, 182, 148));
    draw_text(38, 106, "SIX STAGES, ONE PROGRAM - " + string_upper(_sp3.name)
        + " at t = 0.05 / 0.25 / 0.45 / 0.68 / 0.86 / 1.00. SPACE for the next species.");

    /// One fit for all six panels, so the plant visibly GROWS across the row. Fitting each panel
    /// to itself would scale the seedling up to the same size as the mature plant and destroy the
    /// entire point of the screen - which is exactly the mistake a per-cell layout invites.
    var _r3 = 0.001, _d3 = 0, _w3 = 0.001;
    for (var i = 0; i < array_length(stage_built); i++) {
        var _b3 = stage_built[i].bounds;
        if (_b3.empty) continue;
        _r3 = max(_r3, _b3.y2 + _b3.lift);
        _d3 = max(_d3, max(0, -_b3.y1 - _b3.lift));
        _w3 = max(_w3, _b3.w);
    }
    var _cw3 = (_W - 100) / 6;
    var _f3  = vrd_demo_fit(_r3, _d3, _w3, 150, _H - 150, 6.0, _cw3 * 0.92);

    for (var i = 0; i < array_length(stage_built); i++) {
        var _e3 = stage_built[i];
        var _cx = 50 + _cw3 * 0.5 + i * _cw3;

        draw_set_colour(make_colour_rgb(_g.soilLine.r, _g.soilLine.g, _g.soilLine.b));
        draw_rectangle(_cx - _cw3 * 0.38, _f3.soil, _cx + _cw3 * 0.38, _f3.soil + 1, false);

        vrd_draw_built(_e3.list, _cx, _f3.soil - _e3.bounds.lift * _f3.sc, _f3.sc);

        draw_set_halign(fa_center);
        draw_set_colour(i == 5 ? make_colour_rgb(180, 200, 164) : make_colour_rgb(120, 140, 112));
        draw_text(_cx, _H - 132, stage_names[i]);
        draw_set_colour(make_colour_rgb(78, 94, 72));
        draw_text(_cx, _H - 112, "t = " + string(_e3.t));
    }

    draw_set_halign(fa_center);
    draw_set_font(fnt_verdure_title);
    draw_set_colour(make_colour_rgb(222, 234, 204));
    draw_text(_W * 0.5, _H - 82, string_upper(_sp3.name) + "   /   " +string_upper(_sp3.family));
    draw_set_font(fnt_verdure);
}

/// ── footer ───────────────────────────────────────────────────────────────────────────────────
draw_set_halign(fa_left);
draw_set_colour(make_colour_rgb(84, 100, 78));
/// ⚠️ ASCII ONLY IN EVERY draw_text IN THIS FILE, AND IT IS MEASURED, NOT STYLE.
/// `fnt_verdure` and `fnt_verdure_title` are imported over the standard Latin range and carry NO
/// glyph for U+00B7 - `grep -c '"character":183' fnt_verdure.glyphs.txt` returns 0. Every "·" this
/// screen printed rendered as NOTHING: "ROOT · FRUITING · 100%" reached the store capture as
/// "ROOT    FRUITING    100%" with two unexplained gaps, and it survived review because a missing
/// glyph looks like deliberate spacing. There is no error, no warning and no log line for this.
/// If you want a separator, check the glyph file first - "/" (47) is present in both fonts.
draw_text(38, _H - 32, "TAB  switch view     SPACE  next species     LEFT/RIGHT  grow / page");
draw_set_halign(fa_right);
draw_text(_W - 38, _H - 32, "Core Systems Asset Factory");
draw_set_halign(fa_left);
