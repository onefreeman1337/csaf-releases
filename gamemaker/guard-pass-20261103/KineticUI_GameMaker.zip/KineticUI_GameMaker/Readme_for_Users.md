# Kinetic UI for GameMaker

**Version 0.5.1** · GameMaker Studio 2 (built and verified against runtime `2024.14.4.268`)

Every panel, border, bar, gauge, glyph and highlight in this package is generated from primitives
and colour maths at draw time. There are no sprites, no nine-slice PNGs, no font resources and no
texture pages. Dropping Kinetic UI into an existing project cannot disturb that project's atlas
packing, and the whole interface stays crisp from 480p to 4K from one code path.

Motion is driven by a **spring integrator**, not a tween. A spring holds a position and a velocity
and can be retargeted on any frame; it has no duration and no schedule to restart. That is the
difference you can see: change the selection while the highlight is still travelling and it simply
curves toward the new row, instead of snapping back and starting again.

---

## 1. Install

1. In the GameMaker IDE: **Tools → Import Local Package**, choose `KineticUI.yymps`.
2. Tick everything, or tick only what you want (see §2 — the scripts have a strict dependency order,
   the demo does not).
3. Press **F5** and open `rm_kui_demo`.

The demo room is the quickstart. It is the shortest complete example of how the package is meant to
be used, and it is deliberately written the way you would write it in your own project.

### What is in the package

| Resource | What it is | Do you need it |
| --- | --- | --- |
| `kui_ease` | Easing curves, the spring integrator, the stagger helper | **Yes** |
| `kui_theme` | Palette system and the four shipped themes | **Yes** |
| `kui_font` | The stroke typeface and text measurement | **Yes** |
| `kui_draw` | 14 drawing primitives | **Yes** |
| `kui_widget` | `KuiContext` plus the eight widgets | **Yes** |
| `obj_kui_demo` | The demo driver | No — example only |
| `rm_kui_demo` | The demo room | No — example only |

`kui_draw` depends on `kui_theme`; `kui_widget` depends on all four. Import them together.

---

## 2. The five-minute version

There is no framework to initialise, no manager object to place in a room, and nothing to clean up.
You construct the widgets you want, keep them in instance variables, and call them from **Draw GUI**.

```gml
// Create
ui   = new KuiContext();
menu = new KuiMenu(["CONTINUE", "NEW GAME", "OPTIONS", "QUIT"]);
kui_theme_set(kui_theme_violet());

// Draw GUI
ui.poll(delta_time / 1000000);          // once per frame, before any widget

kui_draw_backdrop(0, 0, display_get_gui_width(), display_get_gui_height());

var _chosen = menu.draw(ui, 120, 160, 420, 56);
if (_chosen == 3) game_end();
```

That is the whole shape of the API: **one call per widget, from Draw GUI, returning what the player
did.** There is no retained tree, no layout pass and no callback registration.

### `ui.poll(dt)` and why `dt` is in seconds

`delta_time` is **microseconds**. Springs want seconds, so divide by 1,000,000. Every example in
the package does this and it is the single most common mistake when wiring the library up — pass
microseconds and every animation completes in a millionth of the intended time, which looks exactly
like no animation at all.

If you already have an input manager, set `KuiContext`'s fields yourself and never call `poll()`.

---

## 3. The widgets

All eight take `(ctx, ...)` as their first argument and are drawn with one call.

| Widget | Constructor | `draw` returns |
| --- | --- | --- |
| `KuiButton` | `new KuiButton(label)` | `true` on the frame it is clicked |
| `KuiToggle` | `new KuiToggle(label, on)` | `true` on the frame it changes |
| `KuiSlider` | `new KuiSlider(value, min, max)` | `true` while being dragged |
| `KuiBar` | `new KuiBar(value)` | nothing — call `set(v)` |
| `KuiMenu` | `new KuiMenu(array_of_strings)` | index of the confirmed row, or `-1` |
| `KuiTabs` | `new KuiTabs(array_of_labels)` | the active page index |
| `KuiGauge` | `new KuiGauge(value)` | nothing — call `set(v)` |
| `KuiDialog` | `new KuiDialog(title)` | `true` on confirm. `open()` / `close()` |

Behaviour worth knowing:

- **`KuiBar` leaves a ghost.** A falling bar leaves a trailing block behind it for a third of a
  second so a hit reads at a glance. Healing does not — a bar that grows has nothing to explain.
- **`KuiMenu` staggers its entrance.** `replay()` re-runs it; `snap()` puts it in its final state
  with no animation, which is what you want when restoring a menu the player has already seen.
- **`KuiDialog` drives its scrim from the same spring as its scale**, so the dim and the panel are
  never out of step. Animating them separately is the usual mistake and it produces a dialog that
  arrives before its own shadow.
- **Long strings shrink to fit.** `KuiDialog`'s title and body, and `KuiButton`'s label, are sized
  against the box they are drawn into. A label longer than the button does not spill.

---

## 4. Theming — six colours in, an entire interface out

```gml
kui_theme_set(kui_theme_make(
    make_colour_rgb( 10,  8, 18),   // backdrop
    make_colour_rgb( 34, 26, 52),   // surface
    make_colour_rgb(178,120,255),   // accent
    make_colour_rgb(120,200,255),   // accent alt
    make_colour_rgb(238,234,250),   // text
    make_colour_rgb(150,140,175)    // text dim
));
```

Those six seeds derive roughly twenty further roles by colour maths — panel edges, gradient stops,
slider tracks, hover states, knob fills, the leading edge on a bar, and three status colours built
at a role-fixed hue that borrow the accent's saturation and value so they can never clash with your
palette. **No widget holds a colour of its own**, so a single `kui_theme_set` restyles everything on
screen, including the type.

Four themes ship: `kui_theme_violet()`, `kui_theme_ember()`, `kui_theme_terminal()`,
`kui_theme_frost()`. Press **T** in the demo to cycle them.

> ⚠️ **A GML hex literal is BGR, not RGB.** `$FF0000` is blue. Build colours with
> `make_colour_rgb(r, g, b)` — every colour in this package does, for exactly that reason.

---

## 5. Motion

```gml
s = kui_spring_make(180, 22, 0);     // stiffness, damping, initial value
s.target = 240;                      // retarget whenever you like, including mid-flight
kui_spring_step(s, dt);              // once per frame
x = s.value;
```

- `kui_spring_settled(s)` — true once it has stopped meaningfully moving.
- `kui_stagger(index, count, elapsed, duration, overlap)` — normalised progress for item `index` in
  a cascading entrance.
- `kui_ease(t, KUI_EASE_*)` — 13 named curves for the cases where a fixed schedule *is* what you
  want.

**Springs and easing curves are not competitors.** Use a curve when the motion has a known start,
end and duration. Use a spring when the target can change while the motion is still running — a
selection highlight, a value readout, a panel that follows something. GameMaker's built-in Animation
Curves cover the first case well and cannot express the second, because a curve is a fixed schedule
evaluated over a known duration: retargeting it means restarting it.

`kui_ease.gml` is **pure** — no engine calls, no globals, no side effects. Every function in it can
be reasoned about, and changed, in isolation.

---

## 6. Drawing primitives

`kui_draw` is usable on its own, without any widget:

`kui_draw_round_rect` · `kui_draw_round_rect_outline` · `kui_draw_gradient_v` · `kui_draw_glow` ·
`kui_draw_arc` · `kui_draw_backdrop` · `kui_draw_panel` · `kui_draw_highlight` ·
`kui_draw_scanlines` · `kui_draw_corner_ticks` · `kui_draw_chevron` · `kui_draw_check` ·
`kui_draw_cross` · `kui_round_rect_points`

The fill and the outline of a rounded rectangle share one point-generation path, so the two can
never disagree about where the corner is.

### The typeface

`kui_font` is a geometric stroke typeface: **60 glyphs** — the full uppercase alphabet, the ten
digits and 24 symbols — each a short list of polylines on a 5×7 grid. Lowercase folds to uppercase.

- `kui_draw_text(x, y, text, size, ...)` — `y` is the **cap top**, not the baseline.
- `kui_draw_text_centred`, `kui_draw_text_right`
- `kui_text_width(text, size, tracking)`
- `kui_text_fit_size(text, size, maxWidth, tracking)` — the largest cap height at which a string
  fits a width budget. Use it any time the string comes from outside your layout.

Joints are capped with a dot above about two pixels of stroke weight, because `draw_line_width`
produces butt caps and an unfilled corner on an `A` or an `M` reads as a chip out of the glyph.

---

## 7. Performance and conventions

- **Everything is immediate-mode.** Nothing is retained between frames except the small structs you
  hold yourself, so there is nothing to leak and nothing to free.
- **Every global and macro is namespaced** to the package — `kui_`, `Kui`, `KUI_`, and one global
  named `__kui_theme`. GML's global namespace is flat and shared with your code; a collision would
  be a support ticket nobody can debug remotely.
- **No absolute paths, no hardcoded room or layer indices.**
- **Raw, readable, uncompressed GML** with a documented header block on every public function.
  Nothing is minified. You are expected to read and extend it.
- Drawing is primitive-based, so cost scales with the number of shapes rather than texture swaps.
  The glow primitive is the most expensive thing here — it draws concentric rings — so keep
  `_rings` low on anything you draw many of.

> **Not measured:** no frame-time figure is quoted anywhere in this package. GML cannot be profiled
> outside the engine, and a number produced any other way would be a guess with a decimal point on
> it. Profile it in your own project, on your own target.

---

## 8. Delete the demo scaffolding

`obj_kui_demo` contains two blocks that exist **only** so the package can be demonstrated and
photographed, and both are marked in the source:

1. **A self-drive block** that animates the interface after three seconds of no input.
2. **A `--page` / `--theme` / `--still` / `--dialog` command-line parser** used by the screenshot
   harness.

Neither is part of Kinetic UI, and the first one is actively harmful if copied: you will ship a menu
that navigates itself. Use the object as a reference and delete it, or delete the two blocks.

---

## 9. Compatibility, and one honest limitation

- Built and package-verified against GameMaker runtime **2024.14.4.268** (the stable GMS2 runtime).
- Pure GML with no extensions, no shaders and no platform-specific calls, so it is not tied to a
  target. **It has been built and run on Windows only** — nothing here should be platform-sensitive,
  but that is reasoning, not a test result, and it is stated as such.
- GMRT is not required and is not claimed to be supported.
- **GML has no unit-test harness outside the engine.** Verification for this package is: a real
  headless Igor build that compiles and packages it clean, plus a runnable demo room you can press
  Play on. Behaviour claims in this Readme describe what the demo does when you run it — run it.

---

## 10. Licence

See `LICENSE.txt`. Short version: use it in as many commercial and non-commercial games as you like,
modify it freely, and do not resell or redistribute the package itself as an asset.

## 11. Support

Questions, bugs and feature requests: use the itch.io project page for Kinetic UI. Include your
GameMaker version and runtime, and the smallest snippet that reproduces the problem.

---

*Kinetic UI is built by CSAF — Core Systems Asset Factory. The code in this package is
AI-written and that is disclosed on the store listing.*

## Changes in 0.5.1

- Every documented function now refuses a wrong-typed argument with a usable value, instead of stopping your game with a runtime error. Anything you already call with valid arguments behaves as before, and no save format changed. That includes the constructors and draw methods of all eight widgets.
- The licence now names the copyright holder, Core Systems Asset Factory.
