/// @file    obj_kui_demo :: Create
/// @package Kinetic UI for GameMaker
///
/// The demo room driver. This object exists to be READ as much as to be run — it is the shortest
/// complete example of how Kinetic UI is meant to be used, and it is deliberately written the way
/// a buyer would write it in their own project.
///
/// Everything below is ordinary GameMaker. There is no framework to initialise, no manager object
/// to place in the room and nothing to clean up: you construct the widgets you want, keep them in
/// instance variables, and call them from Draw GUI.

// One input context, shared by every widget on screen. If you already have an input manager, set
// its fields yourself and never call poll() — see kui_widget.gml.
ui = new KuiContext();

// --- Page 1: the menu ---------------------------------------------------------------------
menu = new KuiMenu(["CONTINUE", "NEW GAME", "LOAD SLOT", "SETTINGS", "EXTRAS", "QUIT"]);

// --- Page 2: settings -------------------------------------------------------------------------
tog_fullscreen = new KuiToggle("FULLSCREEN",     true);
tog_vsync      = new KuiToggle("VERTICAL SYNC",  false);
tog_shake      = new KuiToggle("SCREEN SHAKE",   true);

sld_master = new KuiSlider(0.78, 0, 1);
sld_music  = new KuiSlider(0.55, 0, 1);
sld_sfx    = new KuiSlider(0.90, 0, 1);

// --- Page 3: the HUD --------------------------------------------------------------------------
bar_health = new KuiBar(1.0);
bar_shield = new KuiBar(0.72);
gauge_speed = new KuiGauge(0.34);
gauge_heat  = new KuiGauge(0.61);
btn_damage  = new KuiButton("TAKE 18 DAMAGE");
btn_heal    = new KuiButton("REPAIR");

// --- Chrome -----------------------------------------------------------------------------------
tabs      = new KuiTabs(["MENU", "SETTINGS", "HUD", "TYPE"]);
dialog    = new KuiDialog("ABANDON RUN");
btn_modal = new KuiButton("OPEN MODAL");

// --- Theme ------------------------------------------------------------------------------------
// Four themes ship with the package. Press T to cycle. Every widget above restyles at once
// because none of them holds a colour of its own.
theme_index = 0;
kui_theme_set(kui_theme_by_index(theme_index));

// --- Demo self-drive --------------------------------------------------------------------------
// The demo animates itself when nobody is touching it, so that a screen recording shows the
// motion without anyone having to drive it. Any real input suspends this immediately.
// None of this is part of the package — it is demo scaffolding, and it is the only code in the
// project you should delete rather than copy.
demo_time      = 0;
idle_time      = 0;
demo_still     = false;
next_damage_at = 2.4;
next_nav_at    = 1.6;
next_theme_at  = 9.0;
next_page_at   = 5.0;

// --- Capture parameters -----------------------------------------------------------------------
// A screenshot harness needs the demo in an EXACT state, and driving it with synthetic keystrokes
// is neither reliable nor repeatable. These put it there directly:
//
//     KineticUI.exe --page=2 --theme=3 --still
//
// --still freezes the self-drive, settles the entrance animations and hides the cursor, so the
// same command always produces the same pixels. --dialog additionally opens the modal, which is
// the only screen state no combination of page and theme can reach. Demo scaffolding, not
// product API.
var _argc = parameter_count();
for (var _a = 1; _a <= _argc; _a++) {
    var _arg = parameter_string(_a);

    if (string_copy(_arg, 1, 7) == "--page=") {
        tabs.index = clamp(real(string_delete(_arg, 1, 7)), 0, tabs.count - 1);
    } else if (string_copy(_arg, 1, 8) == "--theme=") {
        theme_index = real(string_delete(_arg, 1, 8));
        kui_theme_set(kui_theme_by_index(theme_index));
    } else if (_arg == "--still") {
        demo_still = true;
    } else if (_arg == "--dialog") {
        dialog.open();
    } else if (_arg == "--auto") {
        // Skip the three-second idle wait so a screen recording starts moving on frame one.
        idle_time = 99;
        window_set_cursor(cr_none);
    }
}

if (demo_still) {
    menu.index = 1;
    menu.snap();
    gauge_speed.set(0.34);
    gauge_heat.set(0.61);
    bar_health.set(0.62);
    window_set_cursor(cr_none);
}
