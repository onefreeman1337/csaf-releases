/// @file    obj_kui_demo :: Step
/// @package Kinetic UI for GameMaker
///
/// Demo scaffolding only. Kinetic UI itself needs no Step event — every widget animates and
/// draws in one call from Draw GUI. This event exists purely so the demo has something to show.

var _dt = delta_time / 1000000;   // delta_time is microseconds; springs want seconds.

demo_time += _dt;

// --- Manual controls ---------------------------------------------------------------------
if (keyboard_check_pressed(ord("T"))) {
    theme_index += 1;
    kui_theme_set(kui_theme_by_index(theme_index));
    idle_time = 0;
}
if (keyboard_check_pressed(vk_tab)) {
    tabs.index = (tabs.index + 1) mod tabs.count;
    if (tabs.index == 0) menu.replay();
    idle_time = 0;
}

// Any input at all suspends the self-drive below.
if (keyboard_check_pressed(vk_anykey) || mouse_check_button_pressed(mb_any)) idle_time = 0;
else                                                                          idle_time += _dt;

// --- Self-drive, so a screen recording has something to record -----------------------------
// Kicks in after three seconds of no input. See the note in Create. --still disables all of it.
if (demo_still) exit;

gauge_speed.set(0.5 + sin(demo_time * 0.9)  * 0.42);
gauge_heat.set (0.5 + sin(demo_time * 0.55 + 2) * 0.38);

if (idle_time > 3) {
    if (demo_time > next_damage_at) {
        // Alternate a hit and a repair so the ghost trail on the health bar is visible in a
        // capture. The trail is the whole reason KuiBar exists.
        if (bar_health.value > 0.30) {
            bar_health.set(bar_health.value - 0.18);
            bar_shield.set(max(0, bar_shield.value - 0.11));
        } else {
            bar_health.set(1.0);
            bar_shield.set(0.72);
        }
        next_damage_at = demo_time + 2.4;
    }

    if (demo_time > next_nav_at) {
        // Retarget the menu highlight while it may still be in flight. A tween would restart
        // here and hitch; the spring simply changes where it is heading.
        menu.index  = (menu.index + 1) mod menu.count;
        next_nav_at = demo_time + 1.6;
    }

    if (demo_time > next_theme_at) {
        theme_index  += 1;
        kui_theme_set(kui_theme_by_index(theme_index));
        next_theme_at = demo_time + 9.0;
    }

    // Walk the pages, so an unattended recording sees the whole product rather than one screen.
    // The tab underline is spring-tracked, so the page change is itself something to watch.
    if (demo_time > next_page_at) {
        tabs.index = (tabs.index + 1) mod tabs.count;
        if (tabs.index == 0) menu.replay();
        next_page_at = demo_time + 3.2;
    }
}
