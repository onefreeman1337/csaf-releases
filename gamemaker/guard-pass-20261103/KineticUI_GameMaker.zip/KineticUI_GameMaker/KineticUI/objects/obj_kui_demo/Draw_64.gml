/// @file    obj_kui_demo :: Draw GUI
/// @package Kinetic UI for GameMaker
///
/// Everything on this screen is drawn with primitives and colour maths. No sprites, no font
/// resources, no texture pages — including the type, which is a stroke typeface generated from
/// line segments (see kui_font.gml). That is why the whole interface stays crisp at any
/// resolution and why dropping this package into an existing project cannot disturb its atlas.
///
/// Note the shape of the calls below: one line per widget, from Draw GUI, returning what the
/// user did. There is no retained tree and no layout pass.

var _gw = display_get_gui_width();
var _gh = display_get_gui_height();
var _t  = kui_theme_get();

// One poll per frame, before any widget.
ui.poll(delta_time / 1000000);

// --- Backdrop ---------------------------------------------------------------------------------
kui_draw_backdrop(0, 0, _gw, _gh);
kui_draw_scanlines(0, 0, _gw, _gh, 4, _t.scanlineAlpha * 0.7);

// --- Masthead ---------------------------------------------------------------------------------
kui_draw_text(64, 44, "KINETIC UI", 40, _t.text, 1, 7);
kui_draw_text(66, 96, "PROCEDURALLY DRAWN / SPRING ANIMATED", 12, _t.textDim, 1, 3);

draw_set_alpha(0.5);
draw_set_colour(_t.accent);
draw_line(64, 88, 64 + kui_text_width("KINETIC UI", 40, 7), 88);
draw_set_alpha(1);
draw_set_colour(c_white);

// --- Main panel -------------------------------------------------------------------------------
var _px = 64, _py = 132, _pw = _gw - 128, _ph = _gh - 132 - 74;

kui_draw_panel(_px, _py, _pw, _ph);
kui_draw_scanlines(_px + 3, _py + 3, _pw - 6, _ph - 6, 3);
kui_draw_corner_ticks(_px + 12, _py + 12, _pw - 24, _ph - 24, 16, undefined, 0.45, 2);

// --- Tabs -------------------------------------------------------------------------------------
var _page = tabs.draw(ui, _px + 40, _py + 24, _pw - 80, 50);

var _cx = _px + 44;                 // content left
var _cy = _py + 100;                // content top
var _cw = _pw - 88;                 // content width

switch (_page) {

// =============================================================================================
case 0:  // MENU — the spring-tracked selection highlight and the staggered entrance
// =============================================================================================
    menu.draw(ui, _cx, _cy + 8, 430, 56);

    // A decorative status card, to show the same primitives composing into something that is
    // not a menu.
    var _kx = _cx + 500, _ky = _cy + 8, _kw = _cw - 500, _kh = 300;

    kui_draw_round_rect(_kx, _ky, _kw, _kh, _t.radius, _t.surfaceLo, 0.55);
    kui_draw_round_rect_outline(_kx, _ky, _kw, _kh, _t.radius, _t.edge, 0.35, 1);
    kui_draw_corner_ticks(_kx + 10, _ky + 10, _kw - 20, _kh - 20, 12, undefined, 0.5, 2);

    kui_draw_text(_kx + 26, _ky + 26, "SAVE SLOT 03", 17, _t.text, 1, 3);
    kui_draw_text(_kx + 26, _ky + 54, "THE DROWNED CAUSEWAY", 11, _t.textDim, 1, 2);

    gauge_speed.draw(ui, _kx + _kw * 0.30, _ky + 140, 58, "SYNC");
    gauge_heat.draw (ui, _kx + _kw * 0.70, _ky + 140, 58, "DRIFT");

    kui_draw_text(_kx + 26, _ky + 250, "INTEGRITY", 11, _t.textDim, 1, 2);
    bar_health.draw(ui, _kx + 26, _ky + 268, _kw - 52, 16);

    if (btn_modal.draw(ui, _kx + 26, _ky + _kh + 22, _kw - 52, 52)) dialog.open();
    break;

// =============================================================================================
case 1:  // SETTINGS — toggles with a springing knob, sliders whose fill trails the knob
// =============================================================================================
    kui_draw_text(_cx, _cy + 6, "DISPLAY", 13, _t.accent, 1, 3);

    tog_fullscreen.draw(ui, _cx, _cy + 34, 440, 46);
    tog_vsync.draw     (ui, _cx, _cy + 88, 440, 46);
    tog_shake.draw     (ui, _cx, _cy + 142, 440, 46);

    kui_draw_text(_cx + 520, _cy + 6, "AUDIO", 13, _t.accent, 1, 3);

    var _sx = _cx + 520, _sw = _cw - 520;
    var _labels = ["MASTER", "MUSIC", "EFFECTS"];
    var _slds   = [sld_master, sld_music, sld_sfx];

    for (var _i = 0; _i < 3; _i++) {
        var _sy = _cy + 38 + _i * 64;
        kui_draw_text(_sx, _sy, _labels[_i], 12, _t.textDim, 1, 2);
        kui_draw_text_right(_sx + _sw, _sy,
                            string(round(_slds[_i].value * 100)), 12, _t.text, 1, 2);
        _slds[_i].draw(ui, _sx, _sy + 22, _sw, 18);
    }

    // Theme picker. Six colours in, an entire restyle out.
    kui_draw_text(_cx, _cy + 224, "PALETTE", 13, _t.accent, 1, 3);
    kui_draw_text(_cx, _cy + 252, kui_theme_name(theme_index), 26, _t.text, 1, 5);
    kui_draw_text(_cx, _cy + 292, "PRESS T TO CYCLE ALL FOUR SHIPPED THEMES", 11, _t.textDim, 1, 2);

    for (var _s = 0; _s < kui_theme_count(); _s++) {
        var _sw2 = kui_theme_by_index(_s);
        var _swx = _cx + 300 + _s * 44;
        kui_draw_round_rect(_swx, _cy + 250, 34, 34, 8, _sw2.surface, 1);
        kui_draw_round_rect(_swx + 6, _cy + 256, 22, 22, 5, _sw2.accent, 1);
        kui_draw_round_rect_outline(_swx, _cy + 250, 34, 34, 8, _sw2.edge,
                                    (_s == (((theme_index mod 4) + 4) mod 4)) ? 1 : 0.3, 2);
    }
    break;

// =============================================================================================
case 2:  // HUD — the ghost trail on a falling bar, and radial gauges
// =============================================================================================
    kui_draw_text(_cx, _cy + 6, "HULL", 12, _t.textDim, 1, 2);
    kui_draw_text_right(_cx + 520, _cy + 6,
                        string(round(bar_health.value * 100)) + " / 100", 12, _t.text, 1, 2);
    bar_health.draw(ui, _cx, _cy + 28, 520, 26);

    kui_draw_text(_cx, _cy + 78, "SHIELD", 12, _t.textDim, 1, 2);
    kui_draw_text_right(_cx + 520, _cy + 78,
                        string(round(bar_shield.value * 100)) + " / 100", 12, _t.text, 1, 2);
    bar_shield.draw(ui, _cx, _cy + 100, 520, 26);

    if (btn_damage.draw(ui, _cx,       _cy + 150, 250, 54)) {
        bar_health.set(bar_health.value - 0.18);
        bar_shield.set(max(0, bar_shield.value - 0.11));
    }
    if (btn_heal.draw  (ui, _cx + 270, _cy + 150, 250, 54)) {
        bar_health.set(1.0);
        bar_shield.set(0.72);
    }

    // Caption sits UNDER the buttons and inside the left column. It used to run across the full
    // content width at y+152 and straight through both gauges.
    kui_draw_text(_cx, _cy + 226, "A FALLING BAR LEAVES A GHOST BEHIND IT",     10, _t.textDim, 1, 2);
    kui_draw_text(_cx, _cy + 248, "FOR A THIRD OF A SECOND. HEALING DOES NOT.", 10, _t.textDim, 1, 2);

    // Status strip — the three DERIVED status colours, side by side and named, because the fact
    // that they are computed from the accent rather than hardcoded is easy to miss otherwise.
    kui_draw_text(_cx, _cy + 292, "DERIVED STATUS COLOURS", 10, _t.accent, 1, 2);
    var _pips  = ["CRITICAL", "CAUTION", "NOMINAL"];
    var _pipsc = [_t.danger, _t.warning, _t.success];
    for (var _p = 0; _p < 3; _p++) {
        var _ppx = _cx + _p * 176;
        kui_draw_round_rect(_ppx, _cy + 316, 18, 18, 5, _pipsc[_p], 0.95);
        kui_draw_glow(_ppx, _cy + 316, 18, 18, 5, _pipsc[_p], _t.glowAlpha * 2, 4, 2);
        kui_draw_text(_ppx + 28, _cy + 320, _pips[_p], 10, _t.textDim, 1, 2);
    }

    // Gauges: two columns in the right half with real separation, labels below the rings.
    gauge_speed.draw(ui, _cx + 680, _cy + 130, 76, "VELOCITY");
    gauge_heat.draw (ui, _cx + 936, _cy + 130, 76, "CORE HEAT");
    break;

// =============================================================================================
default:  // TYPE — the typeface and the primitives at a size where the drawing is legible
// =============================================================================================
    // Every glyph on this page is a short list of polylines on a 5x7 grid, stroked at draw time.
    // Shown large on purpose: a vector typeface has no "native size", and the only way to say that
    // convincingly is to draw it big enough that a raster one would be showing its pixels.
    kui_draw_text(_cx, _cy + 2, "TYPE SPECIMEN", 13, _t.accent, 1, 3);

    kui_draw_text(_cx, _cy + 34,  "ABCDEFGHIJKLM", 38, _t.text, 1, 6);
    kui_draw_text(_cx, _cy + 92,  "NOPQRSTUVWXYZ", 38, _t.text, 1, 6);
    kui_draw_text(_cx, _cy + 150, "0123456789",    38, _t.accent, 1, 6);
    kui_draw_text(_cx, _cy + 208, "!?.,:;'()[]<>+-=/%#*", 22, _t.textDim, 1, 4);

    // A size ramp, sat on a common BASELINE rather than a common top - kui_draw_text takes the cap
    // top, so three different sizes at one y read as three misaligned rows. The x positions were
    // measured with kui_text_width; at 130px apart the 12 and the 18 ran into each other.
    kui_draw_text(_cx, _cy + 258, "THE SAME OUTLINES AT EVERY SIZE", 11, _t.textDim, 1, 2);

    var _ramp = _cy + 312;   // shared baseline
    kui_draw_text(_cx,       _ramp - 12, "KINETIC UI", 12, _t.textDim, 1, 2);
    kui_draw_text(_cx + 165, _ramp - 18, "KINETIC UI", 18, _t.text,    1, 3);
    kui_draw_text(_cx + 375, _ramp - 28, "KINETIC UI", 28, _t.text,    1, 4);

    // Primitives at a size where the joins, caps and falloff are visible.
    var _rx = _cx + 700;

    kui_draw_text(_rx, _cy + 2, "PRIMITIVES", 13, _t.accent, 1, 3);

    gauge_heat.draw(ui, _rx + 130, _cy + 130, 96, "KUI_DRAW_ARC");

    var _iy = _cy + 268;
    kui_draw_round_rect(_rx, _iy, 320, 76, _t.radius, _t.surfaceLo, 0.55);
    kui_draw_round_rect_outline(_rx, _iy, 320, 76, _t.radius, _t.edge, 0.45, 1);
    kui_draw_corner_ticks(_rx + 8, _iy + 8, 304, 60, 14, undefined, 0.5, 2);

    kui_draw_check  (_rx +  56, _iy + 38, 34, _t.success, 1, 3);
    kui_draw_cross  (_rx + 138, _iy + 38, 30, _t.danger,  1, 3);
    kui_draw_chevron(_rx + 218, _iy + 38, 26, 0, _t.accent, 1, 3);
    kui_draw_round_rect(_rx + 262, _iy + 26, 24, 24, 7, _t.warning, 0.95);
    kui_draw_glow      (_rx + 262, _iy + 26, 24, 24, 7, _t.warning, _t.glowAlpha * 2.2, 5, 2);
    break;
}

// --- Footer -----------------------------------------------------------------------------------
// Both strings are measured against the same budget: at size 10 with 2px tracking the left run
// ends near x=520 and the right run starts near x=630. They used to be longer and they overlapped
// in the middle of the screen, which nothing caught because the gate only proves it compiles.
kui_draw_text(64, _gh - 52,
              "TAB PAGE / T PALETTE / ARROWS NAVIGATE",
              10, _t.textDim, 1, 2);

kui_draw_text_right(_gw - 64, _gh - 52,
                    "NO SPRITES / NO TEXTURE PAGES / NO FONT RESOURCES",
                    10, _t.accent, 0.85, 2);

// --- Modal, last, because it dims everything behind it ---------------------------------------
// It is opened by the OPEN MODAL button on page 0 and closes itself on confirm.
dialog.draw(ui, _gw * 0.5, _gh * 0.5, 520, 300,
            "UNSAVED PROGRESS WILL BE LOST.", "CONFIRM");
