/// @file    kui_widget.gml
/// @package Kinetic UI for GameMaker
/// @author  CSAF
/// @licence See LICENSE.txt shipped alongside this package.
///
/// @summary The widget set. Buttons, toggles, sliders, bars, menus, tabs, gauges and modals —
///          every one of them drawn from primitives and moved by springs.
///
/// @remarks HOW THESE ARE MEANT TO BE USED.
///
///          Kinetic UI widgets are IMMEDIATE MODE. You keep one instance of a widget for its
///          state, and you call a single method from your Draw GUI event which hit-tests,
///          advances the animation and draws, then returns what the user did:
///
///              // Create
///              ui   = new KuiContext();
///              play = new KuiButton("NEW GAME");
///
///              // Draw GUI
///              ui.poll(delta_time / 1000000);
///              if (play.draw(ui, 100, 100, 260, 56)) start_the_game();
///
///          That is the whole API. There is no retained tree to build, no parent/child wiring, no
///          layout pass and nothing to destroy — which is deliberate, because retained-mode UI
///          trees are exactly what the free GameMaker UI libraries already give you and they are
///          not what makes an interface feel good.
///
///          WHY A SPRING AND NOT A TWEEN, stated once here because it is the reason the package
///          exists. A tween needs a duration and a destination up front. Move the destination
///          mid-flight — which is what happens every time a player changes their mind halfway
///          through a menu transition — and the tween must be torn down and restarted from a
///          standing start. That discontinuity is the small "hitch" you see in almost all
///          hand-rolled GameMaker menu code, and GameMaker's own built-in Animation Curves cannot
///          avoid it either, because a curve IS a fixed schedule over a known duration. A spring
///          has neither. It carries position and velocity and is retargeted every single frame,
///          so a target that moves is simply a target that moves.
///
///          INPUT IS INJECTABLE. KuiContext.poll() reads mouse and keyboard, but every field it
///          sets is public. If you have your own input manager, or a gamepad, or a remapping
///          layer, set the fields yourself and never call poll. Kinetic UI ships no input system
///          on purpose — Complete Control is free and does it better.

/// @func   kui_point_in_rect(_px, _py, _x, _y, _w, _h)
/// @desc   Axis-aligned point test. Used by every interactive widget.
/// @param  {Real} _px  Point x.
/// @param  {Real} _py  Point y.
/// @param  {Real} _x   Rect left.
/// @param  {Real} _y   Rect top.
/// @param  {Real} _w   Rect width.
/// @param  {Real} _h   Rect height.
/// @return {Bool} True if the point is inside.
/// @pure
function kui_point_in_rect(_px, _py, _x, _y, _w, _h) {
    return (_px >= _x) && (_px <= _x + _w) && (_py >= _y) && (_py <= _y + _h);
}

/// @func   KuiContext()
/// @desc   One frame of input, gathered once and handed to every widget.
///
/// @remarks Exists so that widgets never touch the engine's input functions themselves. That is
///          what makes them testable by inspection, usable with any input library, and safe to
///          drive from a replay or a cutscene: set the fields and the UI cannot tell the
///          difference.
///
/// @return {Struct.KuiContext} A new context.
function KuiContext() constructor {
    mx       = 0;      // pointer x in GUI coordinates
    my       = 0;      // pointer y in GUI coordinates
    pressed  = false;  // primary button went down this frame
    held     = false;  // primary button is down
    released = false;  // primary button came up this frame
    dt       = 1 / 60; // seconds since the last frame

    navUp    = false;
    navDown  = false;
    navLeft  = false;
    navRight = false;
    confirm  = false;
    cancel   = false;

    /// @func   poll(_dt)
    /// @desc   Fills every field from the mouse and keyboard. Call once per frame, before any
    ///         widget. Skip it entirely if you are driving the fields yourself.
    /// @param  {Real} _dt  Seconds since the last frame. Usually delta_time / 1000000.
    static poll = function(_dt) {
        // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
        if (!is_numeric(_dt)) _dt = 1 / 60;
        mx       = device_mouse_x_to_gui(0);
        my       = device_mouse_y_to_gui(0);
        pressed  = mouse_check_button_pressed(mb_left);
        held     = mouse_check_button(mb_left);
        released = mouse_check_button_released(mb_left);
        dt       = _dt;

        navUp    = keyboard_check_pressed(vk_up);
        navDown  = keyboard_check_pressed(vk_down);
        navLeft  = keyboard_check_pressed(vk_left);
        navRight = keyboard_check_pressed(vk_right);
        confirm  = keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space);
        cancel   = keyboard_check_pressed(vk_escape);
    };
}

/// @func   KuiButton(_label)
/// @desc   A button. Hover swells it and brightens the glow; a press compresses it and it springs
///         back past its resting size on release.
///
/// @remarks The overshoot on release is the entire trick and it is two lines of tuning. A button
///          that returns exactly to rest reads as a state change; one that passes rest and settles
///          reads as a physical object that was pushed. Nothing else about the widget matters as
///          much.
///
/// @param  {String} _label  The caption. Rendered in the stroke typeface, so it is uppercase.
/// @return {Struct.KuiButton} A new button.
function KuiButton(_label) constructor {
    label   = _label;
    enabled = true;

    hoverS = kui_spring_make(220, 20, 0);   // 0 rest, 1 hovered
    pressS = kui_spring_make(340, 16, 0);   // 0 rest, 1 fully pressed
    armed  = false;                          // pointer went down inside us

    /// @func   draw(_ctx, _x, _y, _w, _h)
    /// @desc   Hit-tests, animates and draws. Call from Draw GUI.
    /// @param  {Struct.KuiContext} _ctx  This frame's input.
    /// @param  {Real} _x  Left edge.
    /// @param  {Real} _y  Top edge.
    /// @param  {Real} _w  Width.
    /// @param  {Real} _h  Height.
    /// @return {Bool} True on the frame the button is released inside its own bounds.
    static draw = function(_ctx, _x, _y, _w, _h) {
        // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
        if (!is_struct(_ctx) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_h)) return false;
        var _t     = kui_theme_get();
        var _over  = enabled && kui_point_in_rect(_ctx.mx, _ctx.my, _x, _y, _w, _h);
        var _click = false;

        if (_over && _ctx.pressed) armed = true;
        if (_ctx.released) {
            if (armed && _over) _click = true;
            armed = false;
        }

        hoverS.target = _over ? 1 : 0;
        pressS.target = (armed && _over) ? 1 : 0;
        kui_spring_step(hoverS, _ctx.dt);
        kui_spring_step(pressS, _ctx.dt);

        var _hv = clamp(hoverS.value, 0, 1.4);
        var _pr = clamp(pressS.value, -0.4, 1.4);

        // Hover grows the button a little; press shrinks it more.
        var _grow = _hv * 2 - _pr * 3;
        var _bx = _x - _grow, _by = _y - _grow;
        var _bw = _w + _grow * 2, _bh = _h + _grow * 2;
        var _dim = enabled ? 1 : 0.4;

        kui_draw_glow(_bx, _by, _bw, _bh, _t.radiusSmall, _t.glow,
                      (_t.glowAlpha * 0.7 + _hv * 0.05) * _dim, 5, 2);
        kui_draw_round_rect(_bx, _by, _bw, _bh, _t.radiusSmall,
                            kui_colour_mix(_t.surface, _t.hover, _hv), (0.90 + _pr * 0.08) * _dim);
        kui_draw_gradient_v(_bx + _t.radiusSmall, _by, _bw - _t.radiusSmall * 2, _bh,
                            _t.accent, _t.accent, 0.10 * _hv * _dim, 0);
        kui_draw_round_rect_outline(_bx, _by, _bw, _bh, _t.radiusSmall, _t.edge,
                                    (0.45 + _hv * 0.45) * _dim, 1);

        // Sized on the button height, then fitted to its width. A caller-supplied label is the
        // most likely string in the whole package to be longer than the box it was designed for.
        var _size = kui_text_fit_size(label, _bh * 0.30, _bw - _bw * 0.14);
        var _col  = kui_colour_mix(_t.textDim, _t.text, clamp(_hv, 0, 1));
        kui_draw_text_centred(_bx + _bw * 0.5, _by + (_bh - _size) * 0.5,
                              label, _size, _col, _dim);

        return _click;
    };
}

/// @func   KuiToggle(_label, _on)
/// @desc   A switch. The knob glides across on a spring and the tick draws itself on rather than
///         appearing.
/// @param  {String} _label  Caption drawn to the left of the switch.
/// @param  {Bool}   _on     Initial state.
/// @return {Struct.KuiToggle} A new toggle.
function KuiToggle(_label, _on = false) constructor {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_numeric(_on)) _on = false;
    label = _label;
    on    = _on;

    knobS  = kui_spring_make(300, 22, _on ? 1 : 0);
    checkS = kui_spring_make(260, 26, _on ? 1 : 0);
    hoverS = kui_spring_make(220, 20, 0);

    /// @func   draw(_ctx, _x, _y, _w, _h)
    /// @desc   Hit-tests, animates and draws. Call from Draw GUI.
    /// @param  {Struct.KuiContext} _ctx  This frame's input.
    /// @param  {Real} _x  Left edge of the whole row, label included.
    /// @param  {Real} _y  Top edge.
    /// @param  {Real} _w  Row width. The switch is right-aligned within it.
    /// @param  {Real} _h  Row height.
    /// @return {Bool} True on the frame the state changed.
    static draw = function(_ctx, _x, _y, _w, _h) {
        // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
        if (!is_struct(_ctx) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_h)) return false;
        var _t       = kui_theme_get();
        var _over    = kui_point_in_rect(_ctx.mx, _ctx.my, _x, _y, _w, _h);
        var _changed = false;

        if (_over && _ctx.pressed) {
            on = !on;
            _changed = true;
        }

        hoverS.target = _over ? 1 : 0;
        knobS.target  = on ? 1 : 0;
        checkS.target = on ? 1 : 0;
        kui_spring_step(hoverS, _ctx.dt);
        kui_spring_step(knobS,  _ctx.dt);
        kui_spring_step(checkS, _ctx.dt);

        var _hv = clamp(hoverS.value, 0, 1);
        var _k  = clamp(knobS.value, -0.15, 1.15);

        // Label.
        var _size = _h * 0.34;
        kui_draw_text(_x, _y + (_h - _size) * 0.5, label, _size,
                      kui_colour_mix(_t.textDim, _t.text, _hv), 1);

        // Track, right-aligned.
        var _tw = _h * 1.85;
        var _th = _h * 0.62;
        var _tx = _x + _w - _tw;
        var _ty = _y + (_h - _th) * 0.5;

        kui_draw_round_rect(_tx, _ty, _tw, _th, _th * 0.5, _t.track, 0.95);
        kui_draw_round_rect(_tx, _ty, _tw, _th, _th * 0.5, _t.accent, 0.55 * clamp(_k, 0, 1));
        kui_draw_round_rect_outline(_tx, _ty, _tw, _th, _th * 0.5, _t.edge, 0.5 + _hv * 0.4, 1);

        // Knob.
        var _kr = _th * 0.40;
        var _kx = lerp(_tx + _kr + 3, _tx + _tw - _kr - 3, _k);
        var _ky = _ty + _th * 0.5;

        kui_draw_glow(_kx - _kr, _ky - _kr, _kr * 2, _kr * 2, _kr,
                      _t.glow, _t.glowAlpha * clamp(_k, 0, 1), 4, 2);
        draw_set_alpha(1);
        draw_set_colour(_t.knob);
        draw_circle(_kx, _ky, _kr, false);
        draw_set_colour(c_white);

        kui_draw_check(_kx, _ky, _kr * 0.62, _t.surface, 1,
                       max(1.5, _kr * 0.28), clamp(checkS.value, 0, 1));

        return _changed;
    };
}

/// @func   KuiSlider(_value, _min, _max)
/// @desc   A slider whose fill and knob both track the value on springs, so dragging it fast
///         leaves the fill trailing slightly behind the pointer and catching up.
///
/// @remarks The trailing fill is not a bug being papered over, it is the point. A fill locked
///          rigidly to the pointer reads as a chart; one with a little inertia reads as a
///          physical control. The knob is stiffer than the fill so they separate visibly during a
///          fast drag and re-converge at rest.
///
/// @param  {Real} _value  Initial value.
/// @param  {Real} _min    Lower bound.
/// @param  {Real} _max    Upper bound.
/// @return {Struct.KuiSlider} A new slider.
function KuiSlider(_value, _min = 0, _max = 1) constructor {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_numeric(_min)) _min = 0; if (!is_numeric(_max)) _max = 1; if (!is_numeric(_value)) _value = _min;
    value    = _value;
    minValue = _min;
    maxValue = _max;
    dragging = false;

    fillS  = kui_spring_make(180, 20, 0);
    knobS  = kui_spring_make(420, 26, 0);
    hoverS = kui_spring_make(220, 20, 0);

    /// @func   normalised()
    /// @desc   The value mapped to 0..1, guarded against a zero-width range.
    /// @return {Real} 0 to 1.
    static normalised = function() {
        var _span = maxValue - minValue;
        if (_span == 0) return 0;
        return clamp((value - minValue) / _span, 0, 1);
    };

    /// @func   draw(_ctx, _x, _y, _w, _h)
    /// @desc   Hit-tests, animates and draws. Call from Draw GUI.
    /// @param  {Struct.KuiContext} _ctx  This frame's input.
    /// @param  {Real} _x  Left edge.
    /// @param  {Real} _y  Top edge.
    /// @param  {Real} _w  Width.
    /// @param  {Real} _h  Height.
    /// @return {Bool} True on any frame the value changed.
    static draw = function(_ctx, _x, _y, _w, _h) {
        // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
        if (!is_struct(_ctx) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_h)) return false;
        var _t       = kui_theme_get();
        var _over    = kui_point_in_rect(_ctx.mx, _ctx.my, _x, _y - 6, _w, _h + 12);
        var _changed = false;

        if (_over && _ctx.pressed) dragging = true;
        if (!_ctx.held)            dragging = false;

        if (dragging) {
            var _n   = clamp((_ctx.mx - _x) / max(_w, 1), 0, 1);
            var _new = minValue + _n * (maxValue - minValue);
            if (_new != value) { value = _new; _changed = true; }
        }

        var _target = normalised();
        fillS.target = _target;
        knobS.target = _target;
        hoverS.target = (_over || dragging) ? 1 : 0;
        kui_spring_step(fillS,  _ctx.dt);
        kui_spring_step(knobS,  _ctx.dt);
        kui_spring_step(hoverS, _ctx.dt);

        var _hv = clamp(hoverS.value, 0, 1);
        var _cy = _y + _h * 0.5;
        var _th = max(4, _h * 0.28);

        // Track.
        kui_draw_round_rect(_x, _cy - _th * 0.5, _w, _th, _th * 0.5, _t.track, 0.95);

        // Fill, on the softer spring.
        var _fw = clamp(fillS.value, 0, 1) * _w;
        if (_fw > 1) {
            kui_draw_round_rect(_x, _cy - _th * 0.5, _fw, _th, _th * 0.5, _t.accent, 0.85);
            kui_draw_glow(_x, _cy - _th * 0.5, _fw, _th, _th * 0.5,
                          _t.glow, _t.glowAlpha * (0.6 + _hv), 4, 2);
        }

        // Knob, on the stiffer spring. See @remarks.
        var _kx = _x + clamp(knobS.value, 0, 1) * _w;
        var _kr = _h * 0.42 + _hv * 2;
        draw_set_alpha(1);
        draw_set_colour(_t.knob);
        draw_circle(_kx, _cy, _kr, false);
        draw_set_colour(_t.surfaceLo);
        draw_circle(_kx, _cy, _kr * 0.45, false);
        draw_set_colour(c_white);

        return _changed;
    };
}

/// @func   KuiBar(_value)
/// @desc   A health or progress bar with a delayed ghost trail behind it.
///
/// @remarks THE GHOST IS THE WHOLE WIDGET. When a value drops, the main fill moves immediately
///          and a second fill hangs at the old value for a third of a second before sliding down
///          to meet it. That is how fighting games and action RPGs communicate the SIZE of a hit —
///          the player reads the gap, not the bar. Healing skips the ghost entirely, because a
///          trail behind a rising bar reads as damage and is actively confusing.
///
///          The bar also recolours through the theme's derived status colours as it empties, so a
///          low bar is urgent without any code in the buyer's game deciding that.
///
/// @param  {Real} _value  Initial value, 0 to 1.
/// @return {Struct.KuiBar} A new bar.
function KuiBar(_value = 1) constructor {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_numeric(_value)) _value = 1;
    value      = clamp(_value, 0, 1);
    ghostDelay = 0;

    mainS  = kui_spring_make(260, 24, value);
    ghostS = kui_spring_make(90,  16, value);

    /// @func   set(_v)
    /// @desc   Sets the value. Falling values leave a ghost trail; rising values do not.
    /// @param  {Real} _v  New value, 0 to 1.
    static set = function(_v) {
        // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
        if (!is_numeric(_v)) return;
        var _new = clamp(_v, 0, 1);
        if (_new >= value) {
            // Healing: bring the ghost with us so no trail is drawn.
            ghostS.value    = _new;
            ghostS.target   = _new;
            ghostS.velocity = 0;
        } else {
            ghostDelay = 0.35;
        }
        value = _new;
    };

    /// @func   draw(_ctx, _x, _y, _w, _h)
    /// @desc   Animates and draws. Non-interactive, but takes the context for its timestep.
    /// @param  {Struct.KuiContext} _ctx  This frame's input, for dt.
    /// @param  {Real} _x  Left edge.
    /// @param  {Real} _y  Top edge.
    /// @param  {Real} _w  Width.
    /// @param  {Real} _h  Height.
    static draw = function(_ctx, _x, _y, _w, _h) {
        // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
        if (!is_struct(_ctx) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_h)) return;
        var _t = kui_theme_get();

        mainS.target = value;
        kui_spring_step(mainS, _ctx.dt);

        if (ghostDelay > 0) {
            ghostDelay -= _ctx.dt;
        } else {
            ghostS.target = value;
            kui_spring_step(ghostS, _ctx.dt);
        }

        var _r = _h * 0.5;
        kui_draw_round_rect(_x, _y, _w, _h, _r, _t.track, 0.95);

        // Ghost first, so the main fill sits on top of it.
        var _gw = clamp(ghostS.value, 0, 1) * _w;
        if (_gw > 1) kui_draw_round_rect(_x, _y, _gw, _h, _r, _t.danger, 0.55);

        // Main fill, recoloured through the derived status ramp.
        var _mv = clamp(mainS.value, 0, 1);
        var _mw = _mv * _w;
        var _col = (_mv > 0.5) ? kui_colour_mix(_t.warning, _t.success, (_mv - 0.5) * 2)
                               : kui_colour_mix(_t.danger,  _t.warning, _mv * 2);
        if (_mw > 1) {
            kui_draw_round_rect(_x, _y, _mw, _h, _r, _col, 0.95);
            kui_draw_gradient_v(_x + _r, _y, max(0, _mw - _r * 2), _h * 0.5,
                                c_white, c_white, 0.22, 0);
            kui_draw_glow(_x, _y, _mw, _h, _r, _col, _t.glowAlpha * 1.2, 4, 2);
        }

        kui_draw_round_rect_outline(_x, _y, _w, _h, _r, _t.edge, 0.5, 1);
    };
}

/// @func   KuiMenu(_items)
/// @desc   A vertical menu. Rows cascade in on a stagger, and the selection highlight glides
///         between them on a spring that is retargeted every frame.
///
/// @remarks The retarget is what makes a fast double-tap read correctly. Tap down twice quickly
///          and the highlight travels continuously through the middle row instead of teleporting
///          to it and restarting — which is what a tween does, and what looks wrong.
///
/// @param  {Array<String>} _items  Row captions.
/// @return {Struct.KuiMenu} A new menu.
function KuiMenu(_items) constructor {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_array(_items)) _items = [];
    items   = _items;
    count   = array_length(_items);
    index   = 0;
    elapsed = 0;

    highlightS = kui_spring_make(260, 22, 0);
    rowSprings = [];
    for (var _i = 0; _i < count; _i++) {
        // Slightly softer damping further down the list so the stagger reads as a cascade.
        array_push(rowSprings, kui_spring_make(220, 18 - _i * 0.6, 0));
    }

    /// @func   replay()
    /// @desc   Restarts the entrance cascade. Call when the menu is shown again.
    static replay = function() {
        elapsed = 0;
        for (var _i = 0; _i < count; _i++) {
            rowSprings[_i].value    = 0;
            rowSprings[_i].velocity = 0;
        }
    };

    /// @func   snap()
    /// @desc   Jumps straight to the settled state with no entrance animation.
    ///
    /// @remarks For menus that are shown every frame — a persistent HUD list, a pause menu that
    ///          should feel instant — and for screenshots, where a half-played cascade just looks
    ///          like a rendering bug.
    static snap = function() {
        elapsed = 999;
        for (var _i = 0; _i < count; _i++) {
            rowSprings[_i].value    = 1;
            rowSprings[_i].target   = 1;
            rowSprings[_i].velocity = 0;
        }
        highlightS.value    = index;
        highlightS.target   = index;
        highlightS.velocity = 0;
    };

    /// @func   draw(_ctx, _x, _y, _w, _row_h)
    /// @desc   Handles navigation, animates and draws. Call from Draw GUI.
    /// @param  {Struct.KuiContext} _ctx    This frame's input.
    /// @param  {Real} _x      Left edge.
    /// @param  {Real} _y      Top edge of the first row.
    /// @param  {Real} _w      Width.
    /// @param  {Real} _row_h  Row height.
    /// @return {Real} The index activated this frame, or -1.
    static draw = function(_ctx, _x, _y, _w, _row_h) {
        // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
        if (!is_struct(_ctx) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_row_h)) return -1;
        var _t        = kui_theme_get();
        var _activated = -1;

        elapsed += _ctx.dt;

        if (_ctx.navDown) index = (index + 1) mod count;
        if (_ctx.navUp)   index = (index - 1 + count) mod count;

        // Pointer selection, so mouse and keyboard drive the same single highlight.
        for (var _i = 0; _i < count; _i++) {
            var _ry = _y + _i * _row_h;
            if (kui_point_in_rect(_ctx.mx, _ctx.my, _x, _ry, _w, _row_h)) {
                index = _i;
                if (_ctx.pressed) _activated = _i;
            }
        }
        if (_ctx.confirm) _activated = index;

        // Retarget every frame. Nothing is torn down and restarted. See @remarks.
        highlightS.target = index;
        kui_spring_step(highlightS, _ctx.dt);

        var _hy = _y + highlightS.value * _row_h;
        kui_draw_highlight(_x, _hy + 3, _w, _row_h - 6, 1);

        for (var _r = 0; _r < count; _r++) {
            var _p = kui_stagger(_r, count, elapsed, 0.45, 0.72);
            var _e = kui_ease(_p, KUI_EASE_OUT_BACK);

            var _s = rowSprings[_r];
            _s.target = _e;
            kui_spring_step(_s, _ctx.dt);

            var _prog  = _s.value;
            var _slide = (1 - _prog) * -46;
            var _alpha = clamp(_prog, 0, 1);
            var _size  = _row_h * 0.36;
            var _sel   = (_r == index);

            kui_draw_text(_x + 22 + _slide,
                          _y + _r * _row_h + (_row_h - _size) * 0.5,
                          items[_r], _size,
                          _sel ? _t.text : _t.textDim, _alpha);
        }

        return _activated;
    };
}

/// @func   KuiTabs(_labels)
/// @desc   A tab strip with an underline that both slides AND resizes on springs, so it stretches
///         between tabs of different widths instead of jumping.
/// @param  {Array<String>} _labels  Tab captions.
/// @return {Struct.KuiTabs} A new tab strip.
function KuiTabs(_labels) constructor {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_array(_labels) || array_length(_labels) == 0) _labels = [""];
    labels = _labels;
    count  = array_length(_labels);
    index  = 0;

    posS   = kui_spring_make(240, 22, 0);
    sizeS  = kui_spring_make(240, 22, 0);
    primed = false;

    /// @func   draw(_ctx, _x, _y, _w, _h)
    /// @desc   Hit-tests, animates and draws. Call from Draw GUI.
    /// @param  {Struct.KuiContext} _ctx  This frame's input.
    /// @param  {Real} _x  Left edge.
    /// @param  {Real} _y  Top edge.
    /// @param  {Real} _w  Total width, divided equally between tabs.
    /// @param  {Real} _h  Height.
    /// @return {Real} The currently selected index.
    static draw = function(_ctx, _x, _y, _w, _h) {
        // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
        if (!is_struct(_ctx) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_h)) return index;
        var _t    = kui_theme_get();
        var _tabw = _w / max(count, 1);
        var _size = _h * 0.32;

        for (var _i = 0; _i < count; _i++) {
            var _tx = _x + _i * _tabw;
            if (kui_point_in_rect(_ctx.mx, _ctx.my, _tx, _y, _tabw, _h) && _ctx.pressed) {
                index = _i;
            }
        }

        // Underline hugs the label, not the tab cell, so it looks measured rather than gridded.
        var _lw = kui_text_width(labels[index], _size) + 16;
        var _lx = _x + index * _tabw + (_tabw - _lw) * 0.5;

        if (!primed) {
            // Snap on the first frame; springing in from zero looks like a glitch, not an entrance.
            posS.value  = _lx;  posS.target  = _lx;
            sizeS.value = _lw;  sizeS.target = _lw;
            primed = true;
        }
        posS.target  = _lx;
        sizeS.target = _lw;
        kui_spring_step(posS,  _ctx.dt);
        kui_spring_step(sizeS, _ctx.dt);

        // Baseline rule.
        draw_set_alpha(0.30);
        draw_set_colour(_t.edge);
        draw_line(_x, _y + _h, _x + _w, _y + _h);
        draw_set_alpha(1);
        draw_set_colour(c_white);

        for (var _j = 0; _j < count; _j++) {
            var _cx = _x + _j * _tabw + _tabw * 0.5;
            kui_draw_text_centred(_cx, _y + (_h - _size) * 0.5, labels[_j], _size,
                                  (_j == index) ? _t.text : _t.textDim, 1);
        }

        var _uw = max(sizeS.value, 4);
        kui_draw_round_rect(posS.value, _y + _h - 2, _uw, 3, 1.5, _t.accent, 1);
        kui_draw_glow(posS.value, _y + _h - 2, _uw, 3, 1.5, _t.glow, _t.glowAlpha * 2, 4, 2);

        return index;
    };
}

/// @func   KuiGauge(_value)
/// @desc   A radial meter. The arc sweeps on a spring and the needle tip carries a glow.
/// @param  {Real} _value  Initial value, 0 to 1.
/// @return {Struct.KuiGauge} A new gauge.
function KuiGauge(_value = 0) constructor {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_numeric(_value)) _value = 0;
    value  = clamp(_value, 0, 1);
    valueS = kui_spring_make(140, 18, value);

    /// @func   set(_v)
    /// @desc   Sets the target value. The arc springs toward it.
    /// @param  {Real} _v  New value, 0 to 1.
    static set = function(_v) { if (is_numeric(_v)) value = clamp(_v, 0, 1); };

    /// @func   draw(_ctx, _cx, _cy, _radius, _label)
    /// @desc   Animates and draws. Non-interactive.
    /// @param  {Struct.KuiContext} _ctx     This frame's input, for dt.
    /// @param  {Real}   _cx      Centre x.
    /// @param  {Real}   _cy      Centre y.
    /// @param  {Real}   _radius  Radius in pixels.
    /// @param  {String} _label   Caption under the readout. Pass "" for none.
    static draw = function(_ctx, _cx, _cy, _radius, _label = "") {
        // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
        if (!is_struct(_ctx) || !is_numeric(_cx) || !is_numeric(_cy) || !is_numeric(_radius)) return;
        var _t = kui_theme_get();

        valueS.target = value;
        kui_spring_step(valueS, _ctx.dt);
        var _v = clamp(valueS.value, 0, 1.08);

        // A 270 degree sweep with the gap at the bottom, GameMaker angles being counter-clockwise.
        var _from = 225;
        var _to   = 225 - 270 * _v;
        var _w    = max(3, _radius * 0.16);

        kui_draw_arc(_cx, _cy, _radius, 225, -45, _t.track, 0.9, _w, 64);
        kui_draw_arc(_cx, _cy, _radius, _from, _to, _t.accent, 0.95, _w, 64);

        // Tip glow.
        var _tx = _cx + lengthdir_x(_radius, _to);
        var _ty = _cy + lengthdir_y(_radius, _to);
        kui_draw_glow(_tx - _w * 0.5, _ty - _w * 0.5, _w, _w, _w * 0.5,
                      _t.glow, _t.glowAlpha * 3, 5, 2);
        draw_set_alpha(1);
        draw_set_colour(_t.accentAlt);
        draw_circle(_tx, _ty, _w * 0.5, false);
        draw_set_colour(c_white);

        // Readout, optically centred inside the ring.
        var _size = _radius * 0.44;
        kui_draw_text_centred(_cx, _cy - _size * 0.5,
                              string(round(clamp(_v, 0, 1) * 100)), _size, _t.text, 1);

        // Label BELOW the ring, never inside it. A caption placed within the ring collides with
        // the arc on any gauge whose label is longer than about six characters, and the collision
        // is invisible until you render a real word — "CORE HEAT" was the one that found it.
        if (_label != "") {
            var _ls = _radius * 0.20;
            kui_draw_text_centred(_cx, _cy + _radius + _radius * 0.16, _label, _ls, _t.textDim, 1);
        }
    };
}

/// @func   KuiDialog(_title)
/// @desc   A modal. It scales in from 88% with an overshoot and dims everything behind it.
///
/// @remarks The scrim alpha is driven by the SAME spring as the scale, so the dim and the panel
///          are never out of step. Animating them separately is the usual mistake and it produces
///          a dialog that arrives before its own shadow.
///
/// @param  {String} _title  Heading text.
/// @return {Struct.KuiDialog} A new dialog.
function KuiDialog(_title) constructor {
    title  = _title;
    isOpen = false;
    openS  = kui_spring_make(200, 20, 0);

    // The confirm button is owned by the dialog so that a modal is genuinely one call.
    __btn = new KuiButton("OK");

    /// @func   open()
    /// @desc   Shows the dialog.
    static open = function() { isOpen = true; };

    /// @func   close()
    /// @desc   Hides the dialog. It springs back out rather than vanishing.
    static close = function() { isOpen = false; };

    /// @func   draw(_ctx, _cx, _cy, _w, _h, _body, _confirm_label)
    /// @desc   Animates and draws the modal, its scrim and a single confirm button.
    /// @param  {Struct.KuiContext} _ctx  This frame's input.
    /// @param  {Real}   _cx             Centre x of the screen region to cover.
    /// @param  {Real}   _cy             Centre y.
    /// @param  {Real}   _w              Dialog width.
    /// @param  {Real}   _h              Dialog height.
    /// @param  {String} _body           One line of body text.
    /// @param  {String} _confirm_label  Caption for the confirm button.
    /// @return {Bool} True on the frame the confirm button is clicked.
    static draw = function(_ctx, _cx, _cy, _w, _h, _body = "", _confirm_label = "OK") {
        // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
        if (!is_struct(_ctx) || !is_numeric(_cx) || !is_numeric(_cy) || !is_numeric(_w) || !is_numeric(_h)) return false;
        var _t = kui_theme_get();

        openS.target = isOpen ? 1 : 0;
        kui_spring_step(openS, _ctx.dt);

        var _o = openS.value;
        if (_o <= 0.005 && !isOpen) return false;

        // Scrim, driven by the same spring. See @remarks.
        draw_set_alpha(clamp(_o, 0, 1) * 0.62);
        draw_set_colour(_t.backdropTop);
        draw_rectangle(_cx - 4000, _cy - 4000, _cx + 4000, _cy + 4000, false);
        draw_set_alpha(1);
        draw_set_colour(c_white);

        var _s  = 0.88 + 0.12 * clamp(_o, 0, 1.3);
        var _dw = _w * _s;
        var _dh = _h * _s;
        var _dx = _cx - _dw * 0.5;
        var _dy = _cy - _dh * 0.5;
        var _a  = clamp(_o, 0, 1);

        kui_draw_panel(_dx, _dy, _dw, _dh, _a);
        kui_draw_scanlines(_dx + 2, _dy + 2, _dw - 4, _dh - 4, 3, _t.scanlineAlpha * _a);
        kui_draw_corner_ticks(_dx + 8, _dy + 8, _dw - 16, _dh - 16, 14, undefined, 0.55 * _a, 2);

        // Both strings are sized against the dialog HEIGHT and then fitted to its WIDTH. Sizing on
        // height alone is what put "UNSAVED PROGRESS WILL BE LOST." through both side walls of the
        // panel in the store capture - see kui_text_fit_size.
        var _inner = _dw - _dw * 0.16;

        var _ts = kui_text_fit_size(title, _dh * 0.13, _inner);
        kui_draw_text_centred(_cx, _dy + _dh * 0.16, title, _ts, _t.text, _a);

        if (_body != "") {
            var _bs = kui_text_fit_size(_body, _dh * 0.085, _inner);
            kui_draw_text_centred(_cx, _dy + _dh * 0.42, _body, _bs, _t.textDim, _a);
        }

        __btn.label = _confirm_label;

        var _bw = _dw * 0.42;
        var _bh = _dh * 0.20;
        var _clicked = __btn.draw(_ctx, _cx - _bw * 0.5, _dy + _dh - _bh - _dh * 0.12, _bw, _bh);

        if (_clicked) close();
        return _clicked;
    };
}
