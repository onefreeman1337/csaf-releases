/// @module  pli_mesh
/// @product Pliant - Real-Time Sprite Deformation for GameMaker
/// @version 0.1.0
///
/// ============================================================================================
/// THE IMPURE HALF. Everything that touches the engine lives here and NOWHERE else.
/// ============================================================================================
///
/// pli_deform.gml and pli_spring.gml contain no engine calls at all. This file contains all of
/// them: vertex buffers, texture pages, matrices, blend state. The split is the product's answer
/// to the fact that GML cannot be unit-tested outside the engine - if the maths and the rendering
/// were interleaved, NEITHER could be reasoned about, and this is a wing where a clean build says
/// nothing about whether the picture is right.
///
/// WHY A MESH AT ALL, which is also the answer to "why can't I just write a shader?":
/// GameMaker draws a sprite as TWO TRIANGLES - four vertices, one at each corner. A vertex shader
/// can only move vertices that exist, so on a default sprite quad it can move exactly four
/// corners. Bending, waving and twisting all need interior points to move independently, and
/// there are none. You have to build the subdivided geometry first. That is what this file does,
/// and it is the reason this product exists rather than being a fifteen-line shader.

/// @func pli_vertex_format()
/// @desc The one vertex format Pliant uses: position, colour, texcoord.
///
///       Vertex formats are a global engine resource and leak if created repeatedly, so this is
///       built once on first use and cached. Namespaced with the product prefix because GML's
///       global namespace is flat and a collision inside a buyer's project is a support ticket
///       that cannot be debugged remotely.
/// @return {Id.VertexFormat}
function pli_vertex_format() {
    if (!variable_global_exists("__pli_vertex_format")) {
        vertex_format_begin();
        vertex_format_add_position();
        vertex_format_add_colour();
        vertex_format_add_texcoord();
        global.__pli_vertex_format = vertex_format_end();
    }
    return global.__pli_vertex_format;
}

/// @func PliantMesh(_sprite, _cols, _rows, _subimg)
/// @desc A deformable sprite. Construct once, step it, draw it.
///
///       var _m = new PliantMesh(spr_flag, 20, 12);
///       _m.add(PLI_WAVE, { amp: 7, freq: 2, taper: 1 });
///       // step event:  _m.step(delta_time / 1000000);
///       // draw event:  _m.draw(x, y);
///
///       DENSITY. cols/rows are CELLS, not vertices. 16x16 is a good default: smooth enough for
///       a bend, and 1,536 triangles, which is nothing for a GPU. Density costs CPU (the deformer
///       stack is evaluated per grid point) far more than it costs GPU, so raise it only until
///       the curve stops looking faceted and no further.
///
/// @param {Asset.GMSprite} _sprite
/// @param {Real} [_cols]
/// @param {Real} [_rows]
/// @param {Real} [_subimg]
function PliantMesh(_sprite, _cols = 16, _rows = 16, _subimg = 0) constructor {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_numeric(_cols)) _cols = 16; if (!is_numeric(_rows)) _rows = 16; if (!is_numeric(_subimg)) _subimg = 0;
    sprite = _sprite;
    subimg = _subimg;
    cols   = max(1, floor(_cols));
    rows   = max(1, floor(_rows));

    stack  = [];        // array of {kind, params, enabled}
    time   = 0;         // seconds; advanced by step()
    dirty  = true;      // does the buffer need rebuilding?

    vbuf   = undefined;
    springs = {};       // named PliantSpring instances, driven into deformer params by step()

    // Tint baked into the vertices at build time. draw_set_colour/draw_set_alpha do NOT apply
    // to vertex_submit - a submitted buffer takes its colour from the vertex data, full stop -
    // so the only honest way for draw(x, y, colour, alpha) to work is to bake the tint in and
    // rebuild when it changes. (The first shipped draw() set draw state around the submit and
    // its colour/alpha parameters silently did nothing. Found while fixing shatter.)
    tint   = c_white;
    talpha = 1;

    // Reused per-vertex scratch. Allocating these inside the build loop would allocate roughly
    // (cols+1)*(rows+1)*2 arrays per frame and hand the garbage collector a job it does not need.
    __out     = [0, 0];
    __scratch = [0, 0];
    __gx = [];          // deformed grid positions, flat: [x0,y0, x1,y1, ...]
    __gu = [];          // matching texture coords

    // Shatter working set, reused per rebuild. Shatter deformers are pulled out of the shared-
    // point pass and evaluated per CELL at emit time - see rebuild() for the topology argument.
    __shatter = [];
    __s00 = [0, 0]; __s10 = [0, 0]; __s01 = [0, 0]; __s11 = [0, 0];

    /// @func add(_kind, _params)
    /// @desc Append a deformer. Returns self, so calls chain.
    static add = function(_kind, _params = {}) {
        // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
        if (!is_string(_kind)) return self; if (!is_struct(_params)) _params = {};
        array_push(stack, { kind: _kind, params: _params, enabled: true });
        dirty = true;
        return self;
    };

    /// @func get(_index)
    /// @desc The deformer struct at _index, so its params can be mutated live.
    static get = function(_index) {
        // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
        if (!is_numeric(_index) || _index < 0 || _index >= array_length(stack)) return undefined;
        return stack[_index];
    };

    /// @func set_enabled(_index, _on)
    static set_enabled = function(_index, _on) {
        // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
        if (!is_numeric(_index) || _index < 0 || _index >= array_length(stack)) return self;
        stack[_index].enabled = _on;
        dirty = true;
        return self;
    };

    /// @func clear()
    static clear = function() {
        stack = [];
        dirty = true;
        return self;
    };

    /// @func spring(_name, _stiffness, _damping)
    /// @desc Create a named spring on this mesh. Its `value` is pushed into any deformer whose
    ///       params carry `spring: "<name>"`, every step. That is how PLI_JELLY gets driven
    ///       without the deformer itself knowing what a spring is.
    static spring = function(_name, _stiffness = 160, _damping = 9) {
        // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
        if (!is_string(_name)) return undefined; if (!is_numeric(_stiffness)) _stiffness = 160; if (!is_numeric(_damping)) _damping = 9;
        var _s = new PliantSpring(_stiffness, _damping);
        variable_struct_set(springs, _name, _s);
        return _s;
    };

    /// @func hit(_name, _impulse)
    /// @desc Kick a named spring. The "something struck this sprite" call.
    static hit = function(_name, _impulse) {
        // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
        if (!is_string(_name) || !is_numeric(_impulse)) return self;
        if (variable_struct_exists(springs, _name)) {
            variable_struct_get(springs, _name).impulse(_impulse);
            dirty = true;
        }
        return self;
    };

    /// @func step(_dt)
    /// @desc Advance time and springs. _dt in SECONDS - pass delta_time / 1000000.
    ///
    ///       Marks the mesh dirty only when something actually moved. A stack of purely static
    ///       deformers (a taper, a fixed bend) is built once and then costs nothing per frame,
    ///       which is what makes it reasonable to use Pliant for non-animated shaping too.
    static step = function(_dt) {
        // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
        if (!is_numeric(_dt)) return self;
        var _moved = false;

        var _names = variable_struct_get_names(springs);
        for (var _i = 0; _i < array_length(_names); _i++) {
            var _s = variable_struct_get(springs, _names[_i]);
            if (!_s.is_settled()) { _s.step(_dt); _moved = true; }
        }

        // Push spring values into any deformer that asked for one by name.
        for (var _j = 0; _j < array_length(stack); _j++) {
            var _d = stack[_j];
            if (!is_struct(_d.params)) continue;
            if (!variable_struct_exists(_d.params, "spring")) continue;
            var _nm = _d.params.spring;
            if (variable_struct_exists(springs, _nm)) {
                _d.params.value = variable_struct_get(springs, _nm).value;
            }
        }

        // Any time-varying deformer keeps the mesh dirty. Static ones do not.
        //
        // PLI_SQUASH is conditional: it is a static shape UNLESS it was given a `speed`, in which
        // case it self-oscillates and must rebuild. Getting this wrong in the cheap direction -
        // listing squash as always-static - would freeze pli_preset_breathe() on its first frame,
        // and it would look like the preset simply did not work.
        for (var _k = 0; _k < array_length(stack); _k++) {
            var _dd = stack[_k];
            if (!_dd.enabled) continue;
            var _kind = _dd.kind;
            if (_kind == PLI_WAVE || _kind == PLI_SWAY || _kind == PLI_TURBULENCE
             || _kind == PLI_RIPPLE) { _moved = true; break; }
            if (_kind == PLI_SQUASH && pli_param(_dd.params, "speed", 0) != 0) { _moved = true; break; }
        }

        if (_moved) { time += _dt; dirty = true; }
        return self;
    };

    /// @func rebuild()
    /// @desc Regenerate the vertex buffer. Called automatically by draw() when dirty.
    static rebuild = function() {
        // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
        if (is_string(sprite) || is_undefined(sprite) || is_struct(sprite) || is_array(sprite) || !sprite_exists(sprite)) return;
        var _w = sprite_get_width(sprite);
        var _h = sprite_get_height(sprite);
        var _uv = sprite_get_uvs(sprite, subimg);

        /*
         * TEXTURE-PAGE TRIM. This is the part that silently produces a garbled mesh if it is
         * guessed, so it is written against the manual rather than from memory:
         *   _uv[0..3] = left, top, right, bottom in texture-page UV space
         *   _uv[4]    = pixels the asset compiler TRIMMED from the sprite's left
         *   _uv[5]    = pixels trimmed from the top
         *   _uv[6]    = normalised fraction of the ORIGINAL width that survived to the page
         *   _uv[7]    = the same for height
         *
         * GameMaker crops transparent borders by default. So the rectangle that actually has
         * pixels in it is NOT (0,0)-(w,h); it starts at (_uv[4], _uv[5]) and is
         * (w*_uv[6]) x (h*_uv[7]) in size. The mesh is built over THAT rectangle and the UVs
         * map linearly across it.
         *
         * Building over the full untrimmed rect instead would stretch the UVs outside their own
         * sub-rect and sample whatever sprite happens to sit next to this one on the texture
         * page - which renders as a thin smear of an unrelated image along the edges, looks like
         * a filtering artefact, and is nearly impossible to diagnose from a screenshot.
         */
        var _ox = _uv[4];
        var _oy = _uv[5];
        var _rw = _w * _uv[6];
        var _rh = _h * _uv[7];

        var _xoff = sprite_get_xoffset(sprite);
        var _yoff = sprite_get_yoffset(sprite);

        // --- pass 0: pull any shatter deformers out of the shared-point path ----------------
        //
        // A rigid break-up is not expressible on a shared vertex grid: a vertex on the boundary
        // between two shards exists exactly once and can move only one way, so every triangle
        // straddling the boundary stretches and smears its UVs instead of separating. That was
        // a real shipped defect - through a clean gate - in 0.1.0. So shatter is evaluated PER
        // CELL at emit time in pass 2, where every quad owns its own six buffer vertices and
        // pieces genuinely come apart along duplicated boundary vertices.
        array_resize(__shatter, 0);
        for (var _sc = 0; _sc < array_length(stack); _sc++) {
            var _scd = stack[_sc];
            if (_scd.enabled && _scd.kind == PLI_SHATTER) array_push(__shatter, _scd);
        }
        var _ns = array_length(__shatter);

        // --- pass 1: evaluate the deformed grid ONCE per shared point -----------------------
        //
        // Every interior grid point is shared by up to four cells. Evaluating it once and
        // reusing it is not only faster, it is what makes the mesh WATERTIGHT: evaluating the
        // same point twice could differ in the last floating-point bit and open a hairline seam
        // that shows up as a visible crack when the sprite is scaled up. (Shatter is the one
        // deformer that WANTS the seams - which is exactly why it is not in this pass.)
        var _nx = cols + 1;
        var _ny = rows + 1;

        for (var _j = 0; _j < _ny; _j++) {
            var _v = _j / rows;
            for (var _i = 0; _i < _nx; _i++) {
                var _u = _i / cols;

                pli_deform_eval(stack, _u, _v, time, _rw, _rh, __out, __scratch,
                                (_ns > 0) ? PLI_SHATTER : undefined);

                var _idx = (_j * _nx + _i) * 2;
                __gx[_idx]     = (_ox + _u * _rw) - _xoff + __out[0];
                __gx[_idx + 1] = (_oy + _v * _rh) - _yoff + __out[1];
                __gu[_idx]     = lerp(_uv[0], _uv[2], _u);
                __gu[_idx + 1] = lerp(_uv[1], _uv[3], _v);
            }
        }

        // --- pass 2: emit two triangles per cell -------------------------------------------
        if (vbuf == undefined) vbuf = vertex_create_buffer();
        vertex_begin(vbuf, pli_vertex_format());

        if (_ns == 0) {
            for (var _cy = 0; _cy < rows; _cy++) {
                for (var _cx = 0; _cx < cols; _cx++) {
                    var _i00 = ((_cy)     * _nx + _cx)     * 2;
                    var _i10 = ((_cy)     * _nx + _cx + 1) * 2;
                    var _i01 = ((_cy + 1) * _nx + _cx)     * 2;
                    var _i11 = ((_cy + 1) * _nx + _cx + 1) * 2;

                    // Triangle A: top-left, top-right, bottom-left
                    vertex_position(vbuf, __gx[_i00], __gx[_i00 + 1]);
                    vertex_colour(vbuf, tint, talpha); vertex_texcoord(vbuf, __gu[_i00], __gu[_i00 + 1]);
                    vertex_position(vbuf, __gx[_i10], __gx[_i10 + 1]);
                    vertex_colour(vbuf, tint, talpha); vertex_texcoord(vbuf, __gu[_i10], __gu[_i10 + 1]);
                    vertex_position(vbuf, __gx[_i01], __gx[_i01 + 1]);
                    vertex_colour(vbuf, tint, talpha); vertex_texcoord(vbuf, __gu[_i01], __gu[_i01 + 1]);

                    // Triangle B: top-right, bottom-right, bottom-left
                    vertex_position(vbuf, __gx[_i10], __gx[_i10 + 1]);
                    vertex_colour(vbuf, tint, talpha); vertex_texcoord(vbuf, __gu[_i10], __gu[_i10 + 1]);
                    vertex_position(vbuf, __gx[_i11], __gx[_i11 + 1]);
                    vertex_colour(vbuf, tint, talpha); vertex_texcoord(vbuf, __gu[_i11], __gu[_i11 + 1]);
                    vertex_position(vbuf, __gx[_i01], __gx[_i01 + 1]);
                    vertex_colour(vbuf, tint, talpha); vertex_texcoord(vbuf, __gu[_i01], __gu[_i01 + 1]);
                }
            }
        } else {
            // SHATTER PATH. Same two triangles per cell, one decisive difference: the shard
            // transform is decided ONCE per cell - the CELL CENTRE picks the shard, never the
            // corner, because a corner on a shard boundary quantises into the neighbouring
            // shard - and pli_shatter_vertex is then evaluated for each corner AGAINST THAT
            // SHARD. All six emitted vertices agree on the shard, so the piece is rigid;
            // neighbouring cells in other shards disagree at the shared boundary position,
            // so the mesh tears there. The tear is the feature.
            for (var _cy = 0; _cy < rows; _cy++) {
                var _v0 = _cy / rows;
                var _v1 = (_cy + 1) / rows;
                var _vcen = (_cy + 0.5) / rows;
                for (var _cx = 0; _cx < cols; _cx++) {
                    var _u0 = _cx / cols;
                    var _u1 = (_cx + 1) / cols;
                    var _ucen = (_cx + 0.5) / cols;

                    __s00[0] = 0; __s00[1] = 0;   __s10[0] = 0; __s10[1] = 0;
                    __s01[0] = 0; __s01[1] = 0;   __s11[0] = 0; __s11[1] = 0;
                    var _sa = talpha;

                    for (var _sk = 0; _sk < _ns; _sk++) {
                        var _sd = __shatter[_sk];
                        var _scells = pli_param(_sd.params, "cells", 8);
                        var _scu = floor(clamp(_ucen, 0, 0.999999) * _scells);
                        var _scv = floor(clamp(_vcen, 0, 0.999999) * _scells);

                        pli_shatter_vertex(_sd.params, _scu, _scv, _u0, _v0, time, _rw, _rh, __scratch);
                        __s00[0] += __scratch[0]; __s00[1] += __scratch[1];
                        pli_shatter_vertex(_sd.params, _scu, _scv, _u1, _v0, time, _rw, _rh, __scratch);
                        __s10[0] += __scratch[0]; __s10[1] += __scratch[1];
                        pli_shatter_vertex(_sd.params, _scu, _scv, _u0, _v1, time, _rw, _rh, __scratch);
                        __s01[0] += __scratch[0]; __s01[1] += __scratch[1];
                        pli_shatter_vertex(_sd.params, _scu, _scv, _u1, _v1, time, _rw, _rh, __scratch);
                        __s11[0] += __scratch[0]; __s11[1] += __scratch[1];

                        _sa *= pli_shatter_cell_alpha(_sd.params, _scu, _scv);
                    }

                    var _i00 = ((_cy)     * _nx + _cx)     * 2;
                    var _i10 = ((_cy)     * _nx + _cx + 1) * 2;
                    var _i01 = ((_cy + 1) * _nx + _cx)     * 2;
                    var _i11 = ((_cy + 1) * _nx + _cx + 1) * 2;

                    // Triangle A: top-left, top-right, bottom-left
                    vertex_position(vbuf, __gx[_i00] + __s00[0], __gx[_i00 + 1] + __s00[1]);
                    vertex_colour(vbuf, tint, _sa); vertex_texcoord(vbuf, __gu[_i00], __gu[_i00 + 1]);
                    vertex_position(vbuf, __gx[_i10] + __s10[0], __gx[_i10 + 1] + __s10[1]);
                    vertex_colour(vbuf, tint, _sa); vertex_texcoord(vbuf, __gu[_i10], __gu[_i10 + 1]);
                    vertex_position(vbuf, __gx[_i01] + __s01[0], __gx[_i01 + 1] + __s01[1]);
                    vertex_colour(vbuf, tint, _sa); vertex_texcoord(vbuf, __gu[_i01], __gu[_i01 + 1]);

                    // Triangle B: top-right, bottom-right, bottom-left
                    vertex_position(vbuf, __gx[_i10] + __s10[0], __gx[_i10 + 1] + __s10[1]);
                    vertex_colour(vbuf, tint, _sa); vertex_texcoord(vbuf, __gu[_i10], __gu[_i10 + 1]);
                    vertex_position(vbuf, __gx[_i11] + __s11[0], __gx[_i11 + 1] + __s11[1]);
                    vertex_colour(vbuf, tint, _sa); vertex_texcoord(vbuf, __gu[_i11], __gu[_i11 + 1]);
                    vertex_position(vbuf, __gx[_i01] + __s01[0], __gx[_i01 + 1] + __s01[1]);
                    vertex_colour(vbuf, tint, _sa); vertex_texcoord(vbuf, __gu[_i01], __gu[_i01 + 1]);
                }
            }
        }

        vertex_end(vbuf);
        dirty = false;
        return self;
    };

    /// @func draw(_x, _y, _colour, _alpha)
    /// @desc Draw the deformed sprite at a room position.
    ///
    ///       The mesh is built in sprite-local pixels, so the world transform is a matrix rather
    ///       than being baked into every vertex. That keeps the vertex data valid when the object
    ///       only MOVES, and it means scale and rotation compose correctly with the deformation
    ///       instead of fighting it.
    ///
    ///       COLOUR AND ALPHA are baked into the vertices, because that is the only place a
    ///       submitted vertex buffer takes them from - draw_set_colour/draw_set_alpha around a
    ///       vertex_submit do NOTHING, the buffer's own vertex colours win. (The first shipped
    ///       draw() did exactly that dance, and its colour and alpha parameters silently did
    ///       nothing at all.) The honest consequence: CHANGING the tint dirties the mesh and
    ///       costs one rebuild that frame. A constant tint - even a non-white one - costs
    ///       nothing after its first frame. Fading a mesh out per-frame costs a rebuild
    ///       per-frame; that is the real price of per-vertex colour, stated rather than hidden.
    static draw = function(_x, _y, _colour = c_white, _alpha = 1) {
        // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
        if (!is_numeric(_x) || !is_numeric(_y)) return self; if (!is_numeric(_colour)) _colour = c_white; if (!is_numeric(_alpha)) _alpha = 1;
        if (_colour != tint || _alpha != talpha) {
            tint   = _colour;
            talpha = _alpha;
            dirty  = true;
        }
        if (dirty) rebuild();
        if (vbuf == undefined || !sprite_exists(sprite)) return self;

        var _old = matrix_get(matrix_world);
        matrix_set(matrix_world, matrix_build(_x, _y, 0, 0, 0, 0, 1, 1, 1));
        vertex_submit(vbuf, pr_trianglelist, sprite_get_texture(sprite, subimg));
        matrix_set(matrix_world, _old);
        return self;
    };

    /// @func draw_ext(_x, _y, _xscale, _yscale, _rot, _colour, _alpha)
    /// @desc As draw(), with scale and rotation applied around the sprite's origin.
    ///       Colour and alpha are baked exactly as in draw(), with the same rebuild cost when
    ///       they change between frames.
    static draw_ext = function(_x, _y, _xscale = 1, _yscale = 1, _rot = 0, _colour = c_white, _alpha = 1) {
        // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
        if (!is_numeric(_x) || !is_numeric(_y)) return self; if (!is_numeric(_xscale)) _xscale = 1; if (!is_numeric(_yscale)) _yscale = 1; if (!is_numeric(_rot)) _rot = 0; if (!is_numeric(_colour)) _colour = c_white; if (!is_numeric(_alpha)) _alpha = 1;
        if (_colour != tint || _alpha != talpha) {
            tint   = _colour;
            talpha = _alpha;
            dirty  = true;
        }
        if (dirty) rebuild();
        if (vbuf == undefined || !sprite_exists(sprite)) return self;

        var _old = matrix_get(matrix_world);
        matrix_set(matrix_world, matrix_build(_x, _y, 0, 0, 0, _rot, _xscale, _yscale, 1));
        vertex_submit(vbuf, pr_trianglelist, sprite_get_texture(sprite, subimg));
        matrix_set(matrix_world, _old);
        return self;
    };

    /// @func triangle_count()
    /// @desc Two per cell. Exposed so a buyer can measure rather than guess what density costs.
    static triangle_count = function() {
        return cols * rows * 2;
    };

    /// @func destroy()
    /// @desc Free the vertex buffer. GameMaker does NOT collect these when the struct is
    ///       collected - a vertex buffer is an engine resource with its own lifetime, and a mesh
    ///       created per-enemy and never destroyed is a genuine leak. Call this in Clean Up.
    static destroy = function() {
        if (vbuf != undefined) {
            vertex_delete_buffer(vbuf);
            vbuf = undefined;
        }
    };
}
