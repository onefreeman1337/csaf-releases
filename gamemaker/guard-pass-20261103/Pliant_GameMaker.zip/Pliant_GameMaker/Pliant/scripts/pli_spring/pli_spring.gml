/// @module  pli_spring
/// @product Pliant - Real-Time Sprite Deformation for GameMaker
/// @version 0.1.0
///
/// ============================================================================================
/// SECOND PURE FILE. No engine calls, no globals, no draw. Motion, not rendering.
/// ============================================================================================
///
/// WHY A SPRING AND NOT AN ANIMATION CURVE. GameMaker ships Animation Curves and a buyer will
/// reasonably ask why they should pay for easing they already have. The honest answer is the one
/// this wing already had to write for Kinetic UI, and it is a real difference rather than a
/// marketing line:
///
///   A curve is a fixed schedule over a known duration. To retarget it mid-flight you restart it,
///   and the restart is visible as a hitch. A spring holds POSITION AND VELOCITY and has no
///   schedule at all - hit it again while it is still moving and the new impulse simply adds to
///   the velocity it already had. That is the difference between a character who gets hit twice
///   and wobbles harder, and a character whose wobble visibly resets.
///
/// A curve cannot express that, because "where it is going" is baked into the curve and "how fast
/// it is currently moving" is not part of its state.
///
/// INTEGRATION. Semi-implicit (symplectic) Euler: velocity is updated first, then position is
/// updated using the NEW velocity. Explicit Euler - position first - injects energy every step
/// and a lightly damped spring under it grows without bound instead of settling. The two differ
/// by one line and one of them is a bug that only shows up after ten seconds of wobbling.

/// @func PliantSpring(_stiffness, _damping)
/// @desc A one-dimensional damped spring. Construct with `new PliantSpring(120, 12)`.
///
///       Sensible ranges, from tuning the demo room by eye:
///         stiffness  40  slow and heavy   ..  400 snappy and tight
///         damping     6  loose and ringy  ..   40 dead, one overshoot at most
///
///       Leave damping at -1 for CRITICAL damping, computed as 2*sqrt(stiffness). That is the
///       fastest possible settle with no overshoot at all, and it is the right default for UI-ish
///       motion. For jelly you usually want LESS than critical, so it rings.
///
/// @param  {Real} _stiffness
/// @param  {Real} [_damping]  -1 for critical
function PliantSpring(_stiffness = 120, _damping = -1) constructor {
    stiffness = _stiffness;
    damping   = (_damping < 0) ? (2.0 * sqrt(_stiffness)) : _damping;

    value    = 0;    // current displacement
    velocity = 0;
    target   = 0;

    /// @func impulse(_v)
    /// @desc Add velocity directly. This is the "something hit it" entry point.
    ///       ADDS rather than sets, so a second hit during a wobble compounds. That is the whole
    ///       point of using a spring; setting it would reproduce the curve behaviour we rejected.
    static impulse = function(_v) {
        velocity += _v;
        return self;
    };

    /// @func nudge(_target)
    /// @desc Move the rest position. The spring chases it; it does not jump.
    static nudge = function(_target) {
        target = _target;
        return self;
    };

    /// @func reset(_value)
    /// @desc Hard stop. Position set, velocity zeroed. For scene changes and object reuse.
    static reset = function(_value = 0) {
        value = _value;
        velocity = 0;
        target = _value;
        return self;
    };

    /// @func step(_dt)
    /// @desc Advance by _dt SECONDS.
    ///
    ///       SUB-STEPPING IS NOT OPTIONAL AND THIS IS THE ONE PLACE IT MATTERS. Explicit
    ///       integrators are only stable while dt < ~2/sqrt(stiffness). At stiffness 400 that is
    ///       0.1 s, which is fine at 60fps - until the player alt-tabs, or a room transition
    ///       stalls a frame, and one 0.4 s delta arrives. Without sub-stepping the spring does not
    ///       wobble oddly; it produces infinity, the mesh vertices become NaN, and the sprite
    ///       vanishes with no error message anywhere.
    ///
    ///       So the step is split into pieces no larger than a stable bound, and the count is
    ///       capped so a pathological delta costs bounded time instead of freezing the game.
    static step = function(_dt) {
        if (_dt <= 0) return self;

        var _maxStep = 1.0 / 240.0;
        var _steps = ceil(_dt / _maxStep);
        if (_steps > 16) _steps = 16;              // bounded work, never a freeze
        var _h = _dt / _steps;

        for (var _i = 0; _i < _steps; _i++) {
            var _force = -stiffness * (value - target) - damping * velocity;
            velocity += _force * _h;               // velocity FIRST - see the header note
            value    += velocity * _h;
        }

        // Deadzone: below this the motion is invisible but still costs a mesh rebuild every
        // frame forever. Snapping lets the mesh cache go idle, which is a real saving when a
        // scene holds fifty wobbling sprites.
        if (abs(velocity) < 0.0005 && abs(value - target) < 0.0005) {
            value = target;
            velocity = 0;
        }
        return self;
    };

    /// @func is_settled()
    /// @desc True when the spring has stopped contributing motion. Callers use this to skip a
    ///       mesh rebuild entirely - see PliantMesh.step().
    static is_settled = function() {
        return (velocity == 0) && (value == target);
    };
}

/// @func pli_spring_stable_stiffness(_dt)
/// @desc The largest stiffness that is stable at a given timestep WITHOUT sub-stepping.
///
///       Exposed because a buyer tuning by eye will eventually pick a stiffness that looks
///       perfect at 60fps and explodes on a 30fps machine. Sub-stepping in step() already makes
///       that safe, but this lets the honest answer be printed rather than discovered.
/// @param  {Real} _dt seconds
/// @return {Real}
function pli_spring_stable_stiffness(_dt) {
    if (_dt <= 0) return infinity;
    return 4.0 / (_dt * _dt);
}
