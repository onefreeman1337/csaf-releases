/// @module  pli_preset
/// @product Pliant - Real-Time Sprite Deformation for GameMaker
/// @version 0.1.0
///
/// ============================================================================================
/// PRESETS - the difference between a library and a product.
/// ============================================================================================
///
/// Twelve deformers with eight parameters each is a large space, and most of it looks wrong. A
/// buyer who has to discover by trial that a flag needs `taper: 1` on the wave - or that jelly
/// needs damping BELOW critical or it does not ring at all - has bought a parts bin, not a tool.
///
/// Each preset below is a tuned starting point that looks right immediately and can then be
/// edited, because add() returns the mesh and every deformer stays reachable through get().
/// The numbers are not defaults repeated; they were tuned by eye in the demo room.

/// @func pli_preset_flag(_mesh, _amp)
/// @desc A banner or cape fixed at its LEFT edge. Two waves at different frequencies so the
///       cloth reads as fabric rather than as a sine curve, both tapered to zero at the pole.
function pli_preset_flag(_mesh, _amp = 8) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_mesh)) return undefined; if (!is_numeric(_amp)) _amp = 8;
    _mesh.add(PLI_WAVE, { amp: _amp,       freq: 1.5, speed: 3.4, taper: 1, axis: PLI_AXIS_Y });
    _mesh.add(PLI_WAVE, { amp: _amp * 0.4, freq: 3.1, speed: 5.1, taper: 1, axis: PLI_AXIS_Y, phase: 1.7 });
    return _mesh;
}

/// @func pli_preset_grass(_mesh, _amp, _phase)
/// @desc Foliage rooted at the BOTTOM. Pass a per-instance phase - the whole point of a field of
///       grass is that the blades are out of step, and a field built from one phase looks like a
///       single object being scaled.
function pli_preset_grass(_mesh, _amp = 9, _phase = 0) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_mesh)) return undefined; if (!is_numeric(_amp)) _amp = 9; if (!is_numeric(_phase)) _phase = 0;
    _mesh.add(PLI_SWAY, { amp: _amp, speed: 1.1, stiffness: 2.2, anchor: 1.0, phase: _phase, gust: 0.4 });
    return _mesh;
}

/// @func pli_preset_jelly(_mesh, _amp)
/// @desc Wobble on impact, planted at the bottom. Creates the spring itself and wires it up.
///       Damping is deliberately WELL below critical (critical for 190 would be ~27) because the
///       ringing IS the effect - a critically damped jelly does not wobble, it just returns.
///
///       Kick it with mesh.hit("wobble", 14).
///
///       HOW TO SIZE AN IMPULSE, so the number is understood rather than cargo-culted: an impulse
///       is added VELOCITY, and a damped spring's peak deflection is roughly
///           impulse / sqrt(stiffness), times a damping loss (~0.65 here)
///       so 14 against stiffness 190 peaks near 0.65 - a full, visible wobble at this amp.
///       The first shipped default said 2.5, which peaks near 0.12 - about TWO PIXELS of motion
///       on a 128px sprite. It compiled, it ran, and on screen it read as "nothing happened";
///       that was only caught by photographing a real run and looking. If your jelly seems dead,
///       your impulse is too small for your stiffness - this line is the tuning law.
function pli_preset_jelly(_mesh, _amp = 24) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_mesh)) return undefined; if (!is_numeric(_amp)) _amp = 24;
    _mesh.spring("wobble", 190, 7);
    _mesh.add(PLI_JELLY, { spring: "wobble", amp: _amp, lobes: 1, anchor: 1.0 });
    return _mesh;
}

/// @func pli_preset_breathe(_mesh, _amount)
/// @desc An idle. A slow self-oscillating volume-preserving squash, anchored at the feet, so a
///       static sprite looks alive without an animator drawing a single extra frame. This is the
///       cheapest visible win in the whole library and the one to show a buyer first.
///
///       ⚠️ This preset was WRONG in its first draft and it is worth recording why, because the
///       mistake is invisible from the outside: it added PLI_SQUASH with `amount: 0` - which
///       contributes exactly nothing on every vertex of every frame - and let a PLI_WAVE with
///       `freq: 0` produce the motion instead. It looked plausible, it would have animated, and
///       the squash it advertised was not happening at all, so the motion was NOT volume
///       preserving and the sprite gained and lost mass as it breathed. Found by reading, not by
///       running: no compiler and no gate can see a parameter that means "do nothing".
function pli_preset_breathe(_mesh, _amount = 0.05) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_mesh)) return undefined; if (!is_numeric(_amount)) _amount = 0.05;
    _mesh.add(PLI_SQUASH, { amount: _amount, anchor: 1.0, speed: 1.6 });
    return _mesh;
}

/// @func pli_preset_underwater(_mesh, _amp)
/// @desc Refraction. Turbulence plus a slow lateral wave - either alone reads as a glitch; the
///       pair reads as water.
function pli_preset_underwater(_mesh, _amp = 4) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_mesh)) return undefined; if (!is_numeric(_amp)) _amp = 4;
    _mesh.add(PLI_TURBULENCE, { amp: _amp, scale: 2.5, speed: 0.5 });
    _mesh.add(PLI_WAVE, { amp: _amp * 0.7, freq: 1.2, speed: 1.4, axis: PLI_AXIS_X, along: PLI_AXIS_Y });
    return _mesh;
}

/// @func pli_preset_shockwave(_mesh)
/// @desc A ripple from the centre, ready to be driven. Advance params.time_offset or simply let
///       the mesh's own clock run; decay makes it fade toward the edges.
function pli_preset_shockwave(_mesh, _amp = 7) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_mesh)) return undefined; if (!is_numeric(_amp)) _amp = 7;
    _mesh.add(PLI_RIPPLE, { amp: _amp, freq: 3.5, speed: 5.0, decay: 2.0 });
    return _mesh;
}
