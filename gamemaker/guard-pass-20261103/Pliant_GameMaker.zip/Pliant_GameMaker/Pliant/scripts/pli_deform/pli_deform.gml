/// @module  pli_deform
/// @product Pliant - Real-Time Sprite Deformation for GameMaker
/// @version 0.1.0
///
/// ============================================================================================
/// THE PURE CORE. THERE IS NOT ONE ENGINE CALL IN THIS FILE, AND THAT IS DELIBERATE.
/// ============================================================================================
///
/// GML cannot be unit-tested outside the engine. There is no headless runner, no assertion
/// library that runs in CI, and no way to import a .gml file into anything else. So the only
/// defence available is to make the part that can be WRONG also be the part that can be READ:
/// every deformer below is a total function of (u, v, t, params) with no state, no globals, no
/// randomness, no draw calls and no dependency on anything GameMaker provides.
///
/// That has three consequences worth stating, because they are the product's quality argument:
///
///   1. A deformer cannot break another deformer. Composition is vector addition in
///      pli_deform_eval(), so an incorrect wave cannot corrupt a bend - it can only add a wrong
///      offset to its own contribution.
///   2. Every frame is reproducible. Nothing here calls random(). Turbulence and shatter use a
///      hash of their own inputs, so the same (u,v,t) always yields the same offset. A capture
///      that cannot be reproduced cannot be a store GIF, and a bug that cannot be reproduced
///      cannot be fixed remotely for a buyer.
///   3. You can reason about a deformer by reading twenty lines, which is the whole reason this
///      product ships raw source. Minification would destroy the only verification story it has.
///
/// UNITS. Every deformer returns an offset in PIXELS, not in normalised units. A buyer setting
/// "amplitude 12" means twelve pixels and gets twelve pixels regardless of sprite size or mesh
/// density. Deformers that are inherently proportional (bend, twist, taper, pinch) take the
/// sprite's width and height and do that conversion themselves.
///
/// COORDINATES. u runs 0..1 left to right, v runs 0..1 top to bottom - the same orientation as
/// GameMaker's own texture coordinates, so there is never a flip to remember. t is seconds.

#macro PLI_WAVE       "wave"
#macro PLI_BEND       "bend"
#macro PLI_TWIST      "twist"
#macro PLI_TAPER      "taper"
#macro PLI_SQUASH     "squash"
#macro PLI_SWAY       "sway"
#macro PLI_TURBULENCE "turbulence"
#macro PLI_PINCH      "pinch"
#macro PLI_RIPPLE     "ripple"
#macro PLI_JELLY      "jelly"
#macro PLI_LATTICE    "lattice"
#macro PLI_SHATTER    "shatter"

#macro PLI_AXIS_X 0
#macro PLI_AXIS_Y 1

/// @func pli_hash01(_a, _b, _c)
/// @desc Deterministic hash of three reals into [0,1). The ONLY source of "randomness" in Pliant.
///
///       Why not random()? Because a deformation driven by random() is different on every run,
///       which makes a capture non-reproducible and a buyer's bug report unreproducible. This is
///       a scrambler, not a cryptographic hash: it needs to decorrelate neighbouring cells and
///       be cheap enough to call per-vertex per-frame, and nothing more.
///
///       The frac(sin(dot)) construction is the classic GPU one. It is used here because it has
///       exactly the property required - visually uncorrelated output for inputs that differ in
///       the last decimal place - and because it is branch-free.
/// @param  {Real} _a
/// @param  {Real} _b
/// @param  {Real} _c
/// @return {Real} in [0,1)
function pli_hash01(_a, _b, _c) {
    var _d = _a * 127.1 + _b * 311.7 + _c * 74.7;
    var _s = sin(_d) * 43758.5453123;
    return _s - floor(_s);
}

/// @func pli_value_noise(_x, _y)
/// @desc Smooth 2D value noise on the unit lattice, built from pli_hash01. Deterministic.
///
///       Bilinear interpolation of four hashed lattice corners, with a smoothstep fade so the
///       result is C1-continuous rather than visibly faceted. Faceting is the failure mode that
///       makes cheap noise look like a chequerboard when it drives a large amplitude.
/// @param  {Real} _x
/// @param  {Real} _y
/// @return {Real} in [0,1)
function pli_value_noise(_x, _y) {
    var _xi = floor(_x), _yi = floor(_y);
    var _xf = _x - _xi,  _yf = _y - _yi;

    // Smoothstep fade: 3f^2 - 2f^3. Cheaper than the quintic and adequate at these amplitudes.
    var _fx = _xf * _xf * (3.0 - 2.0 * _xf);
    var _fy = _yf * _yf * (3.0 - 2.0 * _yf);

    var _c00 = pli_hash01(_xi,       _yi,       0);
    var _c10 = pli_hash01(_xi + 1.0, _yi,       0);
    var _c01 = pli_hash01(_xi,       _yi + 1.0, 0);
    var _c11 = pli_hash01(_xi + 1.0, _yi + 1.0, 0);

    var _a = _c00 + (_c10 - _c00) * _fx;
    var _b = _c01 + (_c11 - _c01) * _fx;
    return _a + (_b - _a) * _fy;
}

/// @func pli_param(_params, _key, _default)
/// @desc Read an optional parameter from a deformer struct.
///
///       Every deformer parameter is optional and every one has a documented default, so a buyer
///       can write `add(PLI_WAVE, {})` and see something move. A system that requires eleven
///       correct parameters before it renders anything is a system nobody evaluates.
/// @param  {Struct} _params
/// @param  {String} _key
/// @param  {Any}    _default
/// @return {Any}
function pli_param(_params, _key, _default) {
    if (!is_struct(_params)) return _default;
    if (!variable_struct_exists(_params, _key)) return _default;
    var _v = variable_struct_get(_params, _key);
    return is_undefined(_v) ? _default : _v;
}

/// @func pli_deform_one(_kind, _params, _u, _v, _t, _w, _h, _out)
/// @desc Evaluate ONE deformer at one mesh point. Pure: no engine calls, no state, no allocation.
///
///       Writes into _out (a two-element array) instead of returning a struct, because this runs
///       once per vertex per frame - a 24x24 mesh with four deformers is 2,500 calls a frame, and
///       allocating a struct in each of them is the difference between a system a buyer ships and
///       one they profile out. _out is reused by the caller.
///
/// @param  {String} _kind    one of the PLI_* deformer macros
/// @param  {Struct} _params  deformer parameters; every key optional
/// @param  {Real}   _u       0..1 across the sprite, left to right
/// @param  {Real}   _v       0..1 down the sprite, top to bottom
/// @param  {Real}   _t       time in seconds
/// @param  {Real}   _w       sprite width in pixels
/// @param  {Real}   _h       sprite height in pixels
/// @param  {Array}  _out     [dx, dy] written in place, in PIXELS
function pli_deform_one(_kind, _params, _u, _v, _t, _w, _h, _out) {
    _out[0] = 0;
    _out[1] = 0;

    switch (_kind) {

        // ------------------------------------------------------------------ wave
        // A travelling sine along one axis. The workhorse: flags, water, hair, banners.
        case PLI_WAVE: {
            var _amp   = pli_param(_params, "amp",   8);
            var _freq  = pli_param(_params, "freq",  2);
            var _speed = pli_param(_params, "speed", 3);
            var _phase = pli_param(_params, "phase", 0);
            var _axis  = pli_param(_params, "axis",  PLI_AXIS_Y);
            // "along" selects which coordinate drives the phase; the wave DISPLACES on _axis.
            var _along = pli_param(_params, "along", PLI_AXIS_X);

            var _drive = (_along == PLI_AXIS_X) ? _u : _v;
            var _s = sin(_drive * _freq * 2.0 * pi + _t * _speed + _phase);

            // Optional taper so the wave can be anchored at one end - a flag on a pole does not
            // flap at the pole. taper 0 = uniform, 1 = fully anchored at the drive origin.
            var _tap = pli_param(_params, "taper", 0);
            if (_tap != 0) _s *= lerp(1.0, _drive, clamp(_tap, 0, 1));

            if (_axis == PLI_AXIS_X) _out[0] = _amp * _s; else _out[1] = _amp * _s;
        } break;

        // ------------------------------------------------------------------ bend
        // Rotate each column progressively about a pivot, so the sprite arcs like a bow.
        // This is the one GameMaker cannot fake: image_angle rotates the WHOLE sprite rigidly.
        case PLI_BEND: {
            var _angle = pli_param(_params, "angle", 30);   // degrees at the far end
            var _pivot = pli_param(_params, "pivot", 0);    // 0 = bend about the left/top edge
            var _axis  = pli_param(_params, "axis",  PLI_AXIS_X);

            var _d   = ((_axis == PLI_AXIS_X) ? _u : _v) - _pivot;
            var _rad = degtorad(_angle) * _d;
            var _c = cos(_rad), _sn = sin(_rad);

            // Offset of this point from the pivot, in pixels, before rotation.
            var _px = (_axis == PLI_AXIS_X) ? (_d * _w) : ((_u - 0.5) * _w);
            var _py = (_axis == PLI_AXIS_X) ? ((_v - 0.5) * _h) : (_d * _h);

            _out[0] = (_px * _c - _py * _sn) - _px;
            _out[1] = (_px * _sn + _py * _c) - _py;
        } break;

        // ------------------------------------------------------------------ twist
        // Rotation about the centre whose ANGLE grows with distance from it. Wringing a cloth.
        case PLI_TWIST: {
            var _angle  = pli_param(_params, "angle",  90);
            var _radius = pli_param(_params, "radius", 0.5);
            var _cx = pli_param(_params, "cx", 0.5), _cy = pli_param(_params, "cy", 0.5);

            var _px = (_u - _cx) * _w, _py = (_v - _cy) * _h;
            var _dist = sqrt(_px * _px + _py * _py);
            var _max  = _radius * max(_w, _h);

            // Falloff to zero at the radius, so the deformation is local and does not smear the
            // whole sprite when the caller only wanted a twist in the middle.
            var _k = (_max <= 0) ? 0 : clamp(1.0 - _dist / _max, 0, 1);
            var _rad = degtorad(_angle) * _k * _k;

            var _c = cos(_rad), _sn = sin(_rad);
            _out[0] = (_px * _c - _py * _sn) - _px;
            _out[1] = (_px * _sn + _py * _c) - _py;
        } break;

        // ------------------------------------------------------------------ taper
        // Linear width scale down one axis - a trapezoid. Perspective, blades, tails.
        case PLI_TAPER: {
            var _top  = pli_param(_params, "top",  1.0);
            var _base = pli_param(_params, "base", 0.6);
            var _axis = pli_param(_params, "axis", PLI_AXIS_Y);

            if (_axis == PLI_AXIS_Y) {
                var _scale = lerp(_top, _base, _v);
                _out[0] = (_u - 0.5) * _w * (_scale - 1.0);
            } else {
                var _scale2 = lerp(_top, _base, _u);
                _out[1] = (_v - 0.5) * _h * (_scale2 - 1.0);
            }
        } break;

        // ------------------------------------------------------------------ squash
        // Volume-preserving squash and stretch. The animation principle, done properly:
        // scaling y by k REQUIRES scaling x by 1/k or the shape visibly gains and loses mass.
        // GameMaker's image_xscale/image_yscale will happily let you break that; this will not.
        case PLI_SQUASH: {
            var _k = pli_param(_params, "amount", 0.25);   // >0 squash (wide+short), <0 stretch
            var _anchor = pli_param(_params, "anchor", 1.0); // 1 = feet planted, 0.5 = centred

            // Optional self-oscillation. Without this, squash is a STATIC shape and the only way
            // to breathe with it is for the caller to write amount every step - which is exactly
            // what pli_preset_breathe() originally did wrong: it added a squash with amount 0,
            // contributing literally nothing, and let a separate wave do the work under a name
            // that claimed otherwise. A preset that names a deformer contributing zero is a lie
            // in the shape of an example, so the capability moved here where it belongs.
            var _speed = pli_param(_params, "speed", 0);
            if (_speed != 0) {
                _k *= sin(_t * _speed + pli_param(_params, "phase", 0));
            }

            var _sy = 1.0 - _k;
            var _sx = (_sy == 0) ? 1.0 : (1.0 / _sy);       // exact area preservation

            _out[0] = (_u - 0.5)     * _w * (_sx - 1.0);
            _out[1] = (_v - _anchor) * _h * (_sy - 1.0);
        } break;

        // ------------------------------------------------------------------ sway
        // Wind. Displacement grows with height above the anchor, raised to a stiffness power,
        // and is driven by two incommensurate sines so it never visibly loops.
        case PLI_SWAY: {
            var _amp   = pli_param(_params, "amp",   10);
            var _speed = pli_param(_params, "speed", 1.2);
            var _stiff = pli_param(_params, "stiffness", 2.0);
            var _anchor = pli_param(_params, "anchor", 1.0);  // 1 = rooted at the bottom
            var _phase = pli_param(_params, "phase", 0);
            var _gust  = pli_param(_params, "gust", 0.35);

            // Distance from the anchored edge, 0 at the anchor and 1 at the free end.
            var _d = abs(_v - _anchor);
            var _lever = power(_d, _stiff);

            // 1.0 and 0.61803 are incommensurate, so the sum has no short period. A wind that
            // visibly repeats every two seconds reads as an animation, not as weather.
            var _s = sin(_t * _speed + _phase) + _gust * sin(_t * _speed * 0.61803 + _phase * 1.7);
            _out[0] = _amp * _lever * _s;
        } break;

        // ------------------------------------------------------------------ turbulence
        // Smooth noise scrolling in time. Heat haze, underwater, corruption, dream sequences.
        case PLI_TURBULENCE: {
            var _amp   = pli_param(_params, "amp",   4);
            var _scale = pli_param(_params, "scale", 3);
            var _speed = pli_param(_params, "speed", 0.6);

            // Two lookups offset by a large constant so x and y are decorrelated. Sampling the
            // same noise for both axes makes everything slide along the 45-degree diagonal.
            var _nx = pli_value_noise(_u * _scale + _t * _speed,          _v * _scale);
            var _ny = pli_value_noise(_u * _scale + 31.4,  _v * _scale + _t * _speed + 17.2);

            _out[0] = (_nx - 0.5) * 2.0 * _amp;
            _out[1] = (_ny - 0.5) * 2.0 * _amp;
        } break;

        // ------------------------------------------------------------------ pinch
        // Radial pull toward or push away from a point. Black holes, impacts, magnifiers.
        case PLI_PINCH: {
            var _amount = pli_param(_params, "amount", 0.3);   // >0 pinch in, <0 bulge out
            var _radius = pli_param(_params, "radius", 0.5);
            var _cx = pli_param(_params, "cx", 0.5), _cy = pli_param(_params, "cy", 0.5);

            var _px = (_u - _cx) * _w, _py = (_v - _cy) * _h;
            var _dist = sqrt(_px * _px + _py * _py);
            var _max  = _radius * max(_w, _h);
            if (_dist <= 0.0001 || _max <= 0) break;

            var _k = clamp(1.0 - _dist / _max, 0, 1);
            var _pull = _amount * _k * _k * _dist;
            _out[0] = -(_px / _dist) * _pull;
            _out[1] = -(_py / _dist) * _pull;
        } break;

        // ------------------------------------------------------------------ ripple
        // A radial travelling wave from a point. Impact shockwaves, raindrops, sonar.
        case PLI_RIPPLE: {
            var _amp    = pli_param(_params, "amp",    6);
            var _freq   = pli_param(_params, "freq",   4);
            var _speed  = pli_param(_params, "speed",  4);
            var _cx = pli_param(_params, "cx", 0.5), _cy = pli_param(_params, "cy", 0.5);
            var _decay  = pli_param(_params, "decay",  1.5);

            var _px = (_u - _cx) * _w, _py = (_v - _cy) * _h;
            var _dist = sqrt(_px * _px + _py * _py);
            if (_dist <= 0.0001) break;

            var _norm = _dist / max(_w, _h);
            var _s = sin(_norm * _freq * 2.0 * pi - _t * _speed);
            var _fall = exp(-_norm * _decay);

            _out[0] = (_px / _dist) * _amp * _s * _fall;
            _out[1] = (_py / _dist) * _amp * _s * _fall;
        } break;

        // ------------------------------------------------------------------ jelly
        // Wobble driven by an EXTERNAL spring value, supplied by the caller each frame in
        // params.value. The deformer stays pure - it is a shape function, and pli_spring.gml
        // owns the integration. Keeping those apart is what lets one spring drive several
        // deformers, and lets a deformer be driven by something that is not a spring at all.
        case PLI_JELLY: {
            var _value = pli_param(_params, "value", 0);     // typically -1..1 from a spring
            var _amp   = pli_param(_params, "amp",   14);
            var _lobes = pli_param(_params, "lobes", 1);
            var _anchor = pli_param(_params, "anchor", 1.0);

            var _d = abs(_v - _anchor);
            var _shape = sin(_d * _lobes * pi);
            _out[0] = _value * _amp * _shape * (_u - 0.5) * 2.0;
            _out[1] = _value * _amp * _shape * 0.5;
        } break;

        // ------------------------------------------------------------------ lattice
        // Free-form deformation: a coarse grid of control-point offsets, bilinearly interpolated
        // across the sprite. The escape hatch - anything the eleven named deformers cannot say.
        //
        // params.points is a flat array of 2*cols*rows pixel offsets, row-major:
        //   [x0,y0, x1,y1, ...]
        case PLI_LATTICE: {
            var _pts  = pli_param(_params, "points", undefined);
            if (is_undefined(_pts) || !is_array(_pts)) break;
            var _cols = pli_param(_params, "cols", 3);
            var _rows = pli_param(_params, "rows", 3);
            if (_cols < 2 || _rows < 2) break;
            if (array_length(_pts) < _cols * _rows * 2) break;

            var _gx = clamp(_u, 0, 0.999999) * (_cols - 1);
            var _gy = clamp(_v, 0, 0.999999) * (_rows - 1);
            var _x0 = floor(_gx), _y0 = floor(_gy);
            var _fx = _gx - _x0,  _fy = _gy - _y0;
            var _x1 = min(_x0 + 1, _cols - 1), _y1 = min(_y0 + 1, _rows - 1);

            var _i00 = (_y0 * _cols + _x0) * 2, _i10 = (_y0 * _cols + _x1) * 2;
            var _i01 = (_y1 * _cols + _x0) * 2, _i11 = (_y1 * _cols + _x1) * 2;

            var _tx0 = lerp(_pts[_i00],     _pts[_i10],     _fx);
            var _tx1 = lerp(_pts[_i01],     _pts[_i11],     _fx);
            var _ty0 = lerp(_pts[_i00 + 1], _pts[_i10 + 1], _fx);
            var _ty1 = lerp(_pts[_i01 + 1], _pts[_i11 + 1], _fx);

            _out[0] = lerp(_tx0, _tx1, _fy);
            _out[1] = lerp(_ty0, _ty1, _fy);
        } break;

        // ------------------------------------------------------------------ shatter
        // Rigid per-shard break-up: hashed fly-off direction, arcing gravity, and per-shard
        // spin about the shard's own centre. Deterministic, so the same shatter replays
        // identically - usable in a cutscene, capturable for a store GIF.
        //
        // TOPOLOGY WARNING. Evaluated per POINT - which is this function's contract - a rigid
        // break-up is IMPOSSIBLE on a shared vertex grid: a vertex on the boundary between two
        // shards exists once and can move only one way, so every triangle straddling the
        // boundary stretches and smears its UVs instead of separating. That was a real shipped
        // defect in 0.1.0, present through a completely clean build. PliantMesh therefore
        // special-cases shatter: it skips it in the shared-point pass and evaluates it PER CELL
        // at emit time via pli_shatter_vertex(), where every quad owns its own six buffer
        // vertices and the pieces genuinely come apart. If you call pli_deform_one directly on
        // your own shared grid, you will reproduce the smear - use pli_shatter_vertex and
        // decide each vertex's shard yourself, the way pli_mesh.gml does.
        case PLI_SHATTER: {
            var _cells = pli_param(_params, "cells", 8);
            var _scu = floor(clamp(_u, 0, 0.999999) * _cells);
            var _scv = floor(clamp(_v, 0, 0.999999) * _cells);
            pli_shatter_vertex(_params, _scu, _scv, _u, _v, _t, _w, _h, _out);
        } break;
    }
}

/// @func pli_shatter_vertex(_params, _scu, _scv, _u, _v, _t, _w, _h, _out)
/// @desc Evaluate one SHATTER deformer for a vertex KNOWN to belong to shatter cell
///       (_scu, _scv). Pure, allocation-free, deterministic - like everything in this file.
///
///       The cell index is an ARGUMENT rather than being quantised from (u, v), and that is
///       the entire fix for the 0.1.0 boundary smear: the CALLER decides which shard a vertex
///       belongs to (PliantMesh uses the centre of the mesh cell being emitted), so the same
///       boundary position can be evaluated once for the shard on its left and once for the
///       shard on its right - and the two answers legitimately differ. Duplicated vertices,
///       duplicated on purpose.
///
///       Displacement = translation (hashed direction + quadratic gravity arc, so shards fall
///       away rather than travelling straight) + rotation about the shard's own centre
///       (params.spin, degrees at full progress, hashed sign and rate per shard). Rotation IS
///       expressible in the (u,v) -> (dx,dy) contract because the lever arm from the shard
///       centre is itself a pure function of the vertex position.
///
///       Params: amount 0..1 (0 intact, 1 dispersed) · distance px · cells · gravity ·
///       spin degrees · seed · fade 0..1 (see pli_shatter_cell_alpha).
/// @param  {Struct} _params
/// @param  {Real}   _scu     integer shatter-cell column, decided by the caller
/// @param  {Real}   _scv     integer shatter-cell row, decided by the caller
/// @param  {Real}   _u
/// @param  {Real}   _v
/// @param  {Real}   _t
/// @param  {Real}   _w
/// @param  {Real}   _h
/// @param  {Array}  _out     [dx, dy] written in place, in PIXELS
function pli_shatter_vertex(_params, _scu, _scv, _u, _v, _t, _w, _h, _out) {
    _out[0] = 0;
    _out[1] = 0;
    var _amount = pli_param(_params, "amount", 0);    // 0 = intact, 1 = fully dispersed
    if (_amount <= 0) return;

    var _dist  = pli_param(_params, "distance", 120);
    var _cells = pli_param(_params, "cells", 8);
    var _grav  = pli_param(_params, "gravity", 0.8);
    var _seed  = pli_param(_params, "seed", 1);
    var _spin  = pli_param(_params, "spin", 70);

    var _ang = pli_hash01(_scu, _scv, _seed) * 2.0 * pi;
    var _mag = 0.35 + 0.65 * pli_hash01(_scu, _scv, _seed + 7.0);

    var _p = _amount * _mag;
    _out[0] = cos(_ang) * _dist * _p;
    // Gravity is quadratic in the progress, so shards arc instead of travelling straight.
    _out[1] = sin(_ang) * _dist * _p + _grav * _dist * _p * _p;

    if (_spin != 0) {
        // Signed spin per shard, growing with progress: displace by R(theta)*(p-c) - (p-c),
        // where p is this vertex and c the shard centre. All vertices given the same
        // (_scu,_scv) share theta and c, so the shard rotates as one rigid piece.
        var _theta = degtorad(_spin) * (pli_hash01(_scu, _scv, _seed + 13.0) * 2.0 - 1.0) * _amount;
        var _ccu = (_scu + 0.5) / _cells;
        var _ccv = (_scv + 0.5) / _cells;
        var _px = (_u - _ccu) * _w;
        var _py = (_v - _ccv) * _h;
        var _c = cos(_theta), _sn = sin(_theta);
        _out[0] += (_px * _c - _py * _sn) - _px;
        _out[1] += (_px * _sn + _py * _c) - _py;
    }
}

/// @func pli_shatter_cell_alpha(_params, _scu, _scv)
/// @desc Per-shard opacity for one SHATTER deformer, in [0,1]. Returns 1 unless params.fade > 0.
///
///       fade makes shards dissolve as they disperse, staggered per shard by hash so the
///       break-up reads as debris burning out at different moments rather than the whole
///       sprite fading as one curtain. Quadratic in progress: shards hold solid early in the
///       dispersal and dissolve late. Pure and deterministic, like the displacement.
/// @param  {Struct} _params
/// @param  {Real}   _scu
/// @param  {Real}   _scv
/// @return {Real} alpha in [0,1]
function pli_shatter_cell_alpha(_params, _scu, _scv) {
    var _fade = pli_param(_params, "fade", 0);
    if (_fade <= 0) return 1;
    var _amount = clamp(pli_param(_params, "amount", 0), 0, 1);
    var _seed = pli_param(_params, "seed", 1);
    // Stagger in [0.55, 1): every shard fades, no shard fades identically.
    var _st = 0.55 + 0.45 * pli_hash01(_scu, _scv, _seed + 29.0);
    return clamp(1.0 - _fade * _amount * _amount * _st, 0, 1);
}

/// @func pli_deform_eval(_stack, _u, _v, _t, _w, _h, _out, _scratch, _skip_kind)
/// @desc Compose the whole deformer stack at one point. Offsets ADD.
///
///       Addition is chosen over sequential re-evaluation deliberately. Feeding each deformer the
///       previous one's displaced coordinates would be "more correct" for nested rotations, but it
///       makes every deformer's effect depend on the ORDER of the ones before it - so a buyer who
///       reorders their stack sees all their tuning change. Additive composition is predictable,
///       commutative, and it is what a buyer expects when they type amp:8 and want eight pixels.
///
/// @param  {Array} _stack   array of {kind, params, enabled}
/// @param  {Real}  _u
/// @param  {Real}  _v
/// @param  {Real}  _t
/// @param  {Real}  _w
/// @param  {Real}  _h
/// @param  {Array} _out     [dx, dy] written in place
/// @param  {Array} _scratch a reusable two-element array, to avoid per-vertex allocation
/// @param  {String} [_skip_kind] a PLI_* kind to leave out. PliantMesh passes PLI_SHATTER
///                  here, because shatter cannot be composed through a shared-point pass -
///                  see the topology warning on PLI_SHATTER above.
function pli_deform_eval(_stack, _u, _v, _t, _w, _h, _out, _scratch, _skip_kind = undefined) {
    _out[0] = 0;
    _out[1] = 0;
    var _n = array_length(_stack);
    for (var _i = 0; _i < _n; _i++) {
        var _d = _stack[_i];
        if (!_d.enabled) continue;
        if (!is_undefined(_skip_kind) && _d.kind == _skip_kind) continue;
        pli_deform_one(_d.kind, _d.params, _u, _v, _t, _w, _h, _scratch);
        _out[0] += _scratch[0];
        _out[1] += _scratch[1];
    }
}
