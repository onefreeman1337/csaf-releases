/// obj_pliant_demo :: Clean Up
///
/// A vertex buffer is an ENGINE resource, not a GML struct. GameMaker does not free it when the
/// struct that holds it is collected, so a mesh created per enemy and never destroyed leaks for
/// the lifetime of the process. The demo does the right thing here so the pattern a buyer copies
/// is the correct one - shipping a demo that leaks teaches every buyer to leak.

for (var _i = 0; _i < array_length(demos); _i++) {
    demos[_i].mesh.destroy();
}

// Bench meshes are engine resources exactly like the demo's.
for (var _b = 0; _b < array_length(bench_meshes); _b++) {
    bench_meshes[_b].destroy();
}

// The demo builds its sprite at runtime, so it owns it and must free it too.
if (sprite_exists(spr_test)) sprite_delete(spr_test);
