/// obj_pliant_demo :: Draw GUI
///
/// Drawn on the GUI layer so the demo is resolution-independent and the capture harness gets a
/// stable layout regardless of window size.
///
/// GATE 1 NOTE (master §1.1a): this must not look like stock GameMaker. No default font colour on
/// a black room, no draw_text at 0,0. The palette is deliberate, the type is laid out on a grid,
/// and the comparison strip is the thing a buyer actually wants to see.

var _gw = display_get_gui_width();
var _gh = display_get_gui_height();

// Set the font EVERY frame rather than once in Create. draw_set_font is global renderer state, so a
// buyer dropping this demo into a project alongside their own drawing code would otherwise inherit
// whichever font happened to be set last - and it would look like Pliant was broken.
draw_set_font(fnt_pliant);

// --- benchmark mode: draw every mesh for real, then the numbers ---------------------------------
// The meshes are DRAWN, not just stepped: a benchmark that skips vertex_submit measures half the
// cost and quietly flatters the product. Scale lives in the draw matrix, so it forces no rebuild.
if (bench > 0) {
    draw_set_colour(make_colour_rgb(18, 14, 28));
    draw_rectangle(0, 0, _gw, _gh, false);

    var _n     = array_length(bench_meshes);
    var _gcols = ceil(sqrt(_n * (_gw / max(_gh, 1))));
    var _grows = ceil(_n / max(_gcols, 1));
    var _sc    = min((_gw / max(_gcols, 1)) / 132, ((_gh - 120) / max(_grows, 1)) / 164);
    for (var _bi = 0; _bi < _n; _bi++) {
        var _bx = (_bi mod _gcols + 0.5) * (_gw / _gcols);
        var _by = 100 + (_bi div _gcols + 0.5) * ((_gh - 120) / _grows);
        bench_meshes[_bi].draw_ext(_bx, _by, _sc, _sc, 0);
    }

    draw_set_halign(fa_left);
    draw_set_font(fnt_pliant_title);
    draw_set_colour(make_colour_rgb(238, 196, 122));
    draw_text(40, 20, "PLIANT BENCH");
    draw_set_font(fnt_pliant);
    draw_set_colour(make_colour_rgb(232, 214, 255));
    draw_text(40, 62, string(bench) + " meshes, " + string(bench_cols) + "x" + string(bench_rows)
        + " cells each, " + string(bench * bench_cols * bench_rows * 2)
        + " triangles - every mesh re-deformed and its buffer rewritten EVERY frame");

    draw_set_halign(fa_right);
    if (bench_done) {
        draw_set_colour(make_colour_rgb(238, 196, 122));
        draw_text(_gw - 40, 20, "DONE " + string(bench_frames) + " frames"
            + "   wall " + string_format(bench_frames / (bench_wall_us / 1000000), 1, 1) + " fps"
            + "   compute " + string_format(bench_work_ms / bench_frames, 1, 2) + " ms/frame"
            + "   min fps_real " + string_format(bench_min_fpsr, 1, 0));
    } else {
        draw_set_colour(make_colour_rgb(150, 132, 186));
        draw_text(_gw - 40, 20, (bench_warm > 0 ? "warmup" : ("frame " + string(bench_frames) + "/" + string(bench_target)))
            + "   fps_real " + string_format(fps_real, 1, 0));
    }
    draw_set_halign(fa_left);
    draw_set_colour(c_white);
    exit;
}

// --- background -------------------------------------------------------------------------------
draw_set_colour(make_colour_rgb(18, 14, 28));
draw_rectangle(0, 0, _gw, _gh, false);

// A soft horizon band, so the sprites sit on something instead of floating in a void.
for (var _i = 0; _i < 90; _i++) {
    var _a = 0.05 * (1 - _i / 90);
    draw_set_colour(make_colour_rgb(120, 88, 190));
    draw_set_alpha(_a);
    draw_rectangle(0, _gh * 0.72 + _i, _gw, _gh * 0.72 + _i + 1, false);
}
draw_set_alpha(1);

// --- the focused demo, large ------------------------------------------------------------------
var _d = demos[page];
var _cx = _gw * 0.5;
var _cy = _gh * 0.48;

// Baseline, so an anchored deformer (sway, squash, jelly) is visibly ANCHORED. Without it a
// viewer cannot tell a rooted sway from a whole-sprite translation.
draw_set_colour(make_colour_rgb(70, 54, 104));
draw_line(_cx - 170, _cy + 80, _cx + 170, _cy + 80);

_d.mesh.draw(_cx, _cy);

// --- the undeformed reference, small, beside it ------------------------------------------------
// The single most persuasive thing in the demo: the same sprite, same frame, no deformers. It is
// what turns "that looks nice" into "the engine cannot do that".
draw_sprite_ext(spr_test, 0, _gw * 0.16, _cy, 0.55, 0.55, 0, c_white, 0.75);
draw_set_halign(fa_center);
draw_set_colour(make_colour_rgb(128, 112, 160));
draw_text(_gw * 0.16, _cy + 62, "draw_sprite\n(unchanged)");

// --- header ------------------------------------------------------------------------------------
draw_set_halign(fa_left);
draw_set_font(fnt_pliant_title);
draw_set_colour(make_colour_rgb(238, 196, 122));
draw_text(40, 28, "PLIANT");
draw_set_font(fnt_pliant);
draw_set_colour(make_colour_rgb(150, 132, 186));
draw_text(40, 66, "real-time sprite mesh deformation for GameMaker");

// --- current page label -------------------------------------------------------------------------
draw_set_halign(fa_center);
draw_set_colour(make_colour_rgb(232, 214, 255));
draw_text(_cx, _gh - 118, string(page + 1) + " / " + string(array_length(demos)) + "   " + _d.label);
draw_set_colour(make_colour_rgb(150, 132, 186));
draw_text(_cx, _gh - 98, _d.note);

// --- footer ------------------------------------------------------------------------------------
// Two separate draw calls at two separate anchors. On the previous product in this wing the two
// footer strings were drawn from one halign and overlapped in the middle of the screen through a
// completely clean Igor build - the gate compiled 133 scripts, 0 errors, and the screen was wrong.
draw_set_halign(fa_left);
draw_set_colour(make_colour_rgb(110, 96, 142));
draw_text(40, _gh - 44, "LEFT / RIGHT  change deformer     SPACE  hit the jelly");

draw_set_halign(fa_right);
draw_text(_gw - 40, _gh - 44, string(_d.mesh.triangle_count()) + " triangles   " + string(_d.mesh.cols) + "x" + string(_d.mesh.rows) + " cells");

draw_set_halign(fa_left);
draw_set_alpha(1);
draw_set_colour(c_white);
