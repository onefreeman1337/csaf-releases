/// obj_pliant_demo :: Step

// delta_time is MICROseconds. Every step() and spring in Pliant takes SECONDS, so the conversion
// happens exactly once, here, at the boundary. Getting this wrong by 1e6 is the classic GameMaker
// mistake and it presents as "nothing moves" rather than as an error.
var _dt = delta_time / 1000000;

// --- benchmark mode: measure, and do nothing else -----------------------------------------------
if (bench > 0) {
    for (var _bi = 0; _bi < array_length(bench_meshes); _bi++) {
        bench_meshes[_bi].step(_dt);
    }
    if (!bench_done) {
        if (bench_warm > 0) {
            bench_warm -= 1;
        } else if (bench_frames < bench_target) {
            bench_frames  += 1;
            bench_wall_us += delta_time;
            bench_work_ms += 1000 / max(fps_real, 1);
            bench_min_fpsr = min(bench_min_fpsr, fps_real);
            if (bench_frames >= bench_target) {
                bench_done = true;
                // One line per fact, machine-readable, written into the GameMaker save sandbox.
                var _f = file_text_open_write("pliant_bench.txt");
                file_text_write_string(_f, "meshes=" + string(bench));
                file_text_writeln(_f);
                file_text_write_string(_f, "cells_per_mesh=" + string(bench_cols) + "x" + string(bench_rows));
                file_text_writeln(_f);
                file_text_write_string(_f, "triangles_total=" + string(bench * bench_cols * bench_rows * 2));
                file_text_writeln(_f);
                file_text_write_string(_f, "frames_measured=" + string(bench_frames));
                file_text_writeln(_f);
                file_text_write_string(_f, "avg_wall_fps=" + string(bench_frames / (bench_wall_us / 1000000)));
                file_text_writeln(_f);
                file_text_write_string(_f, "avg_compute_ms_per_frame=" + string(bench_work_ms / bench_frames));
                file_text_writeln(_f);
                file_text_write_string(_f, "min_fps_real=" + string(bench_min_fpsr));
                file_text_writeln(_f);
                file_text_close(_f);
            }
        }
    }
    exit;   // bench mode never runs the demo pages
}

for (var _i = 0; _i < array_length(demos); _i++) {
    demos[_i].mesh.step(_dt);
}

// --- input --------------------------------------------------------------------------------
// The demo takes a command-line argument as well as keys, because an unfocused GameMaker window
// stops repainting and synthetic keystrokes therefore cannot drive an unattended capture. That
// was measured on this wing's previous product: two captures three seconds apart came back
// byte-identical while the harness believed it had changed pages.
// The parsing lives in Create (`-page N`). Until 2026-08-11 this comment described it and NO such
// code existed anywhere in the project - a shipped source file asserting a feature it did not have.
if (keyboard_check_pressed(vk_right) || keyboard_check_pressed(ord("D"))) page = (page + 1) mod array_length(demos);
if (keyboard_check_pressed(vk_left)  || keyboard_check_pressed(ord("A"))) page = (page - 1 + array_length(demos)) mod array_length(demos);

// Hit the jelly. Impulses ADD, so mashing the key compounds the wobble instead of restarting it -
// which is the entire argument for a spring over an animation curve, made touchable.
if (keyboard_check_pressed(vk_space)) {
    for (var _j = 0; _j < array_length(demos); _j++) {
        demos[_j].mesh.hit("wobble", 14);
    }
}

// Capture scaffolding: `-autohit` presses SPACE on a schedule, in pairs, so a recording shows the
// second impulse landing while the first is still in flight - compounding, not restarting.
if (autohit) {
    autohit_t -= _dt;
    if (autohit_t <= 0) {
        for (var _ah = 0; _ah < array_length(demos); _ah++) {
            demos[_ah].mesh.hit("wobble", 14);
        }
        autohit_n = (autohit_n + 1) mod 2;
        autohit_t = (autohit_n == 1) ? 0.3 : 1.6;
    }
}

// Drive the shatter demo's progress on a loop so the page is self-demonstrating.
shatter_t += _dt * 0.55;
if (shatter_t > 1.6) shatter_t = 0;
for (var _k = 0; _k < array_length(demos); _k++) {
    if (demos[_k].label != "SHATTER") continue;
    var _def = demos[_k].mesh.get(0);
    _def.params.amount = clamp(shatter_t, 0, 1);
    demos[_k].mesh.dirty = true;
}
