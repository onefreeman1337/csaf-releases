/// obj_pliant_demo :: Create
///
/// The runnable demo, and - because GML cannot be unit-tested outside the engine - this wing's
/// only real smoke test. It builds its own sprite at runtime so the package carries no binary
/// art, which also means every deformer below is provably operating on an ordinary GameMaker
/// sprite rather than on something special-cased.

// NO randomise() CALL, DELIBERATELY. Removed 2026-08-11.
//
// Nothing in Pliant consumes GameMaker's RNG: pli_deform.gml's turbulence and shatter are driven by
// pli_hash01(), a deterministic hash of their own inputs, precisely so a capture is reproducible and
// a buyer's bug report is too. Seeding an RNG that is never read did nothing except quietly
// contradict the product's own central claim.
//
// (An earlier draft of this note also called `randomise()` a spelling risk against `randomize()`.
// That was wrong and is retracted: the runtime's own GmlSpec.xml carries BOTH, `randomise` tagged
// Locale="GB" and `randomize` Locale="US". The removal stands on the dead-code argument alone.)
//
// The demo is therefore frame-for-frame identical on every run given the same input.

// ---------------------------------------------------------------------------------------------
// A procedural test sprite.
//
// Deliberately NOT a flat colour block. A deformation is invisible on a solid rectangle - you
// need internal structure to see that the interior is actually moving rather than the quad being
// scaled. So: a checker underlay for interior motion, a bright border to read the silhouette, and
// a diagonal so twist and shear are unambiguous.
// ---------------------------------------------------------------------------------------------
var _w = 128, _h = 160;
var _surf = surface_create(_w, _h);
surface_set_target(_surf);
draw_clear_alpha(c_black, 0);

// Checkerboard body, two close violets so it reads as one material with visible cells.
var _cell = 16;
for (var _yy = 0; _yy < _h; _yy += _cell) {
    for (var _xx = 0; _xx < _w; _xx += _cell) {
        var _on = ((_xx div _cell) + (_yy div _cell)) % 2 == 0;
        draw_set_colour(_on ? make_colour_rgb(78, 52, 122) : make_colour_rgb(96, 66, 148));
        draw_rectangle(_xx, _yy, _xx + _cell - 1, _yy + _cell - 1, false);
    }
}

// A diagonal band: the clearest possible read on twist, shear and bend.
draw_set_colour(make_colour_rgb(238, 196, 122));
draw_triangle(0, _h, _w, 0, _w, 40, false);

// Bright border, drawn last so the silhouette stays legible under any deformation.
draw_set_colour(make_colour_rgb(232, 214, 255));
draw_rectangle(0, 0, _w - 1, _h - 1, true);
draw_rectangle(1, 1, _w - 2, _h - 2, true);

surface_reset_target();

// removeback=false, smooth=false: no cropping, so sprite_get_uvs returns an untrimmed rect and
// the demo exercises the SIMPLE path. The trimmed path is exercised by any imported sprite.
spr_test = sprite_create_from_surface(_surf, 0, 0, _w, _h, false, false, _w / 2, _h / 2);
surface_free(_surf);

// ---------------------------------------------------------------------------------------------
// One page per deformer family. Every mesh is built the same way so the comparison is honest.
// ---------------------------------------------------------------------------------------------
demos = [];

var _mk = function(_spr, _label, _note) {
    var _m = new PliantMesh(_spr, 18, 22);
    return { mesh: _m, label: _label, note: _note };
};

var _d;

_d = _mk(spr_test, "WAVE", "travelling sine, tapered to the anchor");
_d.mesh.add(PLI_WAVE, { amp: 10, freq: 1.6, speed: 3.2, taper: 1, axis: PLI_AXIS_X, along: PLI_AXIS_Y });
array_push(demos, _d);

_d = _mk(spr_test, "BEND", "columns rotate progressively - image_angle cannot do this");
_d.mesh.add(PLI_BEND, { angle: 46, pivot: 1.0, axis: PLI_AXIS_Y });
array_push(demos, _d);

_d = _mk(spr_test, "TWIST", "rotation that grows toward the centre");
_d.mesh.add(PLI_TWIST, { angle: 120, radius: 0.75 });
array_push(demos, _d);

_d = _mk(spr_test, "SQUASH", "volume preserving: y*k forces x*(1/k)");
_d.mesh.add(PLI_SQUASH, { amount: 0.28, anchor: 1.0 });
array_push(demos, _d);

_d = _mk(spr_test, "SWAY", "wind, rooted at the base");
pli_preset_grass(_d.mesh, 16, 0.4);
array_push(demos, _d);

_d = _mk(spr_test, "TURBULENCE", "deterministic value noise - no random()");
_d.mesh.add(PLI_TURBULENCE, { amp: 6, scale: 3, speed: 0.7 });
array_push(demos, _d);

_d = _mk(spr_test, "RIPPLE", "radial travelling wave with distance decay");
_d.mesh.add(PLI_RIPPLE, { amp: 9, freq: 3.5, speed: 4.5, decay: 1.6 });
array_push(demos, _d);

_d = _mk(spr_test, "JELLY", "SPACE to hit it - impulses COMPOUND");
pli_preset_jelly(_d.mesh, 24);
array_push(demos, _d);

_d = _mk(spr_test, "PINCH", "radial pull toward a point");
_d.mesh.add(PLI_PINCH, { amount: 0.45, radius: 0.6 });
array_push(demos, _d);

_d = _mk(spr_test, "SHATTER", "rigid per-cell dispersal, deterministic");
_d.mesh.add(PLI_SHATTER, { amount: 0, distance: 90, cells: 7, gravity: 0.9 });
array_push(demos, _d);

_d = _mk(spr_test, "LATTICE", "free-form control grid, bilinear");
var _pts = [];
for (var _r = 0; _r < 3; _r++) {
    for (var _c = 0; _c < 3; _c++) {
        // A fixed, hand-set warp: pull the middle row right and the corners in.
        array_push(_pts, (_r == 1) ? 22 : ((_c == 1) ? 0 : -10));
        array_push(_pts, (_c == 1) ? -14 : 6);
    }
}
_d.mesh.add(PLI_LATTICE, { points: _pts, cols: 3, rows: 3 });
array_push(demos, _d);

_d = _mk(spr_test, "STACKED", "four deformers at once - offsets simply add");
_d.mesh.add(PLI_TAPER, { top: 1.0, base: 0.55 });
_d.mesh.add(PLI_WAVE,  { amp: 5, freq: 2.0, speed: 2.6, taper: 1, axis: PLI_AXIS_X, along: PLI_AXIS_Y });
_d.mesh.add(PLI_SWAY,  { amp: 7, speed: 0.9, stiffness: 2.0 });
_d.mesh.add(PLI_TURBULENCE, { amp: 2, scale: 4, speed: 0.4 });
array_push(demos, _d);

// The project ships no options/ folder, so GameMaker leaves the window caption as the literal
// unsubstituted macro "${project_name}" - which is what a buyer sees in their taskbar the first
// time they press Run. Setting it here fixes it without adding a platform options file that would
// then have to be maintained per target.
window_set_caption("Pliant - real-time sprite mesh deformation");

page = 0;
shatter_t = 0;

// --- unattended capture -------------------------------------------------------------------------
// Select the starting page from the command line: Pliant.exe -page 7
//
// This exists because an UNFOCUSED GameMaker window stops repainting, so synthetic keystrokes
// cannot reliably drive a capture - measured on this wing twice, most recently 2026-08-11, when
// three consecutive recordings came back byte-identical while the harness believed it had changed
// pages. Launching one process per page sidesteps focus entirely.
//
// NOTE: Step_0 previously CLAIMED this feature in a comment while no argument parsing existed
// anywhere in the project. The claim came first and the code did not follow. Implemented rather
// than deleted because it is the fix for a real capture problem.
for (var _i = 0; _i < parameter_count(); _i++) {
    if (parameter_string(_i) != "-page") continue;
    var _p = real(parameter_string(_i + 1)) - 1;
    page = clamp(_p, 0, array_length(demos) - 1);
}

// Reported in the HUD rather than asserted anywhere. A claim about cost belongs next to the thing
// that produces it, so it cannot drift away from the truth in a readme.
tri_total = demos[0].mesh.triangle_count();

// --- benchmark mode (CAPTURE/VERIFICATION SCAFFOLDING - delete freely in your project) ----------
// Pliant.exe -bench N  spawns N meshes, each with its own TIME-VARYING wave so every one of them
// re-evaluates its full 18x22 grid and rewrites its vertex buffer EVERY frame - the worst case,
// deliberately. After a warmup it measures a fixed window and reports on screen and to
// pliant_bench.txt (in the GameMaker save directory, %LOCALAPPDATA%\Pliant\). This exists because
// the wing may not publish a performance number that did not come from a real run - the number has
// to be produced by the engine, on the record, in pixels.
// -autohit: kick the jelly spring on a fixed schedule - two hits 0.3s apart, then a rest - so an
// unattended recording shows impulses COMPOUNDING, which is the product's central claim and is
// otherwise reachable only by a human pressing SPACE (an unfocused window cannot take keys).
autohit   = false;
autohit_t = 0.6;   // first hit shortly after boot
autohit_n = 0;

bench = 0;
bench_cols = 18;
bench_rows = 22;
for (var _i = 0; _i < parameter_count(); _i++) {
    if (parameter_string(_i) == "-autohit") autohit = true;
    if (parameter_string(_i) == "-bench") bench = max(1, floor(real(parameter_string(_i + 1))));
    if (parameter_string(_i) == "-cells") {
        // "-cells 8x8" - mesh density for the bench, so the cost of DENSITY is measurable too.
        var _spec = parameter_string(_i + 1);
        var _xp = string_pos("x", _spec);
        if (_xp > 0) {
            bench_cols = max(1, floor(real(string_copy(_spec, 1, _xp - 1))));
            bench_rows = max(1, floor(real(string_delete(_spec, 1, _xp))));
        }
    }
}
bench_meshes   = [];
bench_warm     = 60;      // frames ignored before measuring (loader hitching, first-draw costs)
bench_target   = 300;     // frames measured
bench_frames   = 0;
bench_wall_us  = 0;       // sum of delta_time over the measured window (wall clock, vsync included)
bench_work_ms  = 0;       // sum of 1000/fps_real (engine-reported compute time per frame)
bench_min_fpsr = 1000000; // worst instantaneous fps_real seen in the window
bench_done     = false;
if (bench > 0) {
    for (var _b = 0; _b < bench; _b++) {
        var _bm = new PliantMesh(spr_test, bench_cols, bench_rows);
        // Slightly different speed per mesh so no two buffers are identical work.
        _bm.add(PLI_WAVE, { amp: 8, freq: 1.8, speed: 2.2 + (_b mod 7) * 0.17, taper: 0.6, axis: PLI_AXIS_X, along: PLI_AXIS_Y });
        array_push(bench_meshes, _bm);
    }
}
