# Pliant — Real-Time Sprite Deformation for GameMaker

**Version 0.1.1 · GameMaker 2024.x (legacy runtime) · pure GML, no native extension**

GameMaker can scale a sprite and rotate it. It cannot **bend** one.

Pliant turns any sprite into a subdivided vertex-buffer mesh and deforms it every frame through a
stack of composable deformers — wave, bend, twist, taper, squash, sway, turbulence, pinch, ripple,
jelly, a free-form lattice and shatter — driven by a spring integrator so a struck sprite wobbles
and settles instead of snapping.

---

## Why this cannot be done with a shader

This is the first question a technical buyer asks, and it deserves a straight answer.

**GameMaker draws a sprite as two triangles — four vertices, one per corner.** A vertex shader can
only move vertices that already exist, so on a default sprite quad it can move exactly four points.
Bending, waving, twisting and rippling all require *interior* points to move independently of the
corners, and on a sprite quad there are none.

You have to build the subdivided geometry first. That is what Pliant does. The deformation itself
is the easy half; the mesh, the texture-page UV mapping and the watertight seams are the work.

## Why a spring and not an Animation Curve

GameMaker ships Animation Curves, and for scheduled motion they are the right tool.

A curve is **a fixed schedule over a known duration**. To retarget one mid-flight you restart it,
and the restart is visible as a hitch. A spring holds **position and velocity** and has no schedule
at all — hit it again while it is still moving and the new impulse adds to the velocity it already
has. That is the difference between a character who is hit twice and wobbles harder, and one whose
wobble visibly resets.

A curve cannot express that, because "where it is going" is baked in and "how fast it is currently
moving" is not part of its state.

---

## Quick start

```gml
// Create
mesh = new PliantMesh(spr_banner, 20, 12);
mesh.add(PLI_WAVE, { amp: 8, freq: 1.6, speed: 3.2, taper: 1 });

// Step
mesh.step(delta_time / 1000000);       // delta_time is MICROseconds; Pliant works in SECONDS

// Draw
mesh.draw(x, y);

// Clean Up  — a vertex buffer is an engine resource and is NOT freed with the struct
mesh.destroy();
```

Presets do the tuning for you:

```gml
pli_preset_flag(mesh);                  // banner fixed at its left edge
pli_preset_grass(mesh, 9, random(6));   // foliage rooted at the bottom, per-instance phase
pli_preset_jelly(mesh);                 // then: mesh.hit("wobble", 14);
                                        // impulse is added VELOCITY - peak deflection is about
                                        // impulse/sqrt(stiffness), so small numbers do nothing
pli_preset_breathe(mesh);               // volume-preserving idle
pli_preset_underwater(mesh);
pli_preset_shockwave(mesh);
```

## The demo room

`rm_pliant_demo` is the quickstart, the smoke test and the GIF source. Twelve pages, one per
deformer, each shown **beside the same sprite drawn with `draw_sprite`** so the difference is not a
matter of opinion. LEFT/RIGHT change page, SPACE hits the jelly — press it repeatedly and watch the
impulses compound rather than restart.

The demo builds its own test sprite at runtime, so the package ships no binary art and every
deformer is provably operating on an ordinary GameMaker sprite.

---

## What ships

| File | Engine calls | What it is |
| --- | --- | --- |
| `pli_deform.gml` | **none** | 12 deformers + deterministic value noise. Pure functions of `(u,v,t)`. |
| `pli_spring.gml` | **none** | Sub-stepped semi-implicit Euler spring. |
| `pli_mesh.gml` | all of them | `PliantMesh`: mesh build, UV mapping, vertex buffer, draw. |
| `pli_preset.gml` | none directly | Six tuned starting points. |
| `obj_pliant_demo` + `rm_pliant_demo` | — | The runnable demo. |

**Two of the four files contain no engine calls at all, and that is deliberate.** GML cannot be
unit-tested outside the engine — there is no headless runner and no way to import a `.gml` file into
anything else. So the defence available is to make the half that can be *wrong* also be the half
that can be *read*. Every deformer is a total function with no state, no globals and no `random()`.

**Nothing is minified and nothing is obfuscated.** You bought a system you will need to extend.

### Determinism

Nothing in Pliant calls `random()`. Turbulence and shatter hash their own inputs, so the same
`(u, v, t)` always produces the same offset. A shatter replays identically every time — which is
what makes it usable in a cutscene, and capturable for a trailer.

### Namespacing

Every function is prefixed `pli_`, every macro `PLI_`, every constructor `Pliant*`, and the single
cached global is `global.__pli_vertex_format`. GML's global namespace is flat and a collision inside
your project is a bug neither of us can debug remotely.

---

## Performance, measured rather than promised

Numbers from a real run of the demo's benchmark mode (`Pliant.exe -bench N [-cells CxR]`), 300
frames measured after 60 warmup frames, **VM (interpreted) runtime**, one mid-range Windows desktop.
Every benched mesh carries a time-varying wave, so every mesh re-evaluates its full grid and
rewrites its vertex buffer **every frame — the worst case, deliberately**:

| Meshes | Density | Triangles | Compute / frame | Wall fps |
| ---: | :---: | ---: | ---: | ---: |
| 1 | 18×22 | 792 | 6.6 ms | 58 |
| 2 | 18×22 | 1,584 | 14.6 ms | 53 |
| 4 | 18×22 | 3,168 | 28.3 ms | 31 |
| 10 | 8×8 | 1,280 | 12.6 ms | 55 |
| 20 | 8×8 | 2,560 | 24.9 ms | 36 |

What that means in practice:

- **Use Pliant on the sprites the player is looking at** — the boss that wobbles when it is hit,
  the flag, the jelly, the shatter moment. It is not built for two hundred background sprites at
  full density, and the table says so plainly.
- **A static stack is free after its first frame.** `step()` marks the mesh dirty only when
  something is actually time-varying, so a fixed bend, taper or lattice costs nothing per frame.
  Static shaping is the hidden second product in here — use it everywhere.
- **Density is the price dial.** The cost is CPU-side grid evaluation + vertex writing, so it
  scales with `cells × meshes`, not with sprite pixel size. Grass reads perfectly well at 6×8.
- YYC (the C++ compiler target) will be faster than the VM numbers above; it was not measured, so
  no figure is claimed for it.

## Notes and limits, stated plainly

- **Cost is CPU, not GPU.** The deformer stack is evaluated once per grid point per frame. A 16×16
  mesh is 289 grid points and 512 triangles; the triangles are nothing, the 289 evaluations are the
  real cost. Raise density only until the curve stops looking faceted.
- **`step()` skips work when nothing moved.** A purely static stack (a fixed taper, a fixed bend) is
  built once and then costs nothing per frame, so Pliant is reasonable for non-animated shaping too.
- **The demo object carries capture scaffolding you should delete.** `obj_pliant_demo` parses
  `-page N`, `-bench N` and `-cells CxR` command-line arguments and contains a benchmark mode.
  Both blocks are commented as scaffolding. They exist so this product's store footage and its
  performance table could be produced by unattended real runs. Nothing in the four `pli_*` library
  scripts knows the scaffolding exists — copy the library, not the demo driver.
- **Trimmed sprites are handled.** GameMaker crops transparent borders by default; the mesh is built
  over the region that actually has pixels, using `sprite_get_uvs`'s trim fields. If it were built
  over the untrimmed rect, the UVs would sample outside their own sub-rect and smear whatever sprite
  sits next to yours on the texture page.
- **Springs are sub-stepped**, so a stiff spring cannot explode when one long frame arrives after an
  alt-tab. Without that, the failure is not a wobble — it is NaN vertices and a sprite that silently
  disappears.
- **Deformer offsets add.** Feeding each deformer the previous one's displaced coordinates would be
  more "correct" for nested rotations, but it would make every deformer depend on the order of the
  ones before it, so reordering your stack would change all your tuning. Addition is predictable.
- **Legacy runtime.** Built and intended for the stable 2024.x runtime. GMRT is not a dependency and
  is not claimed.

## AI disclosure

This product was written with AI assistance. Code: yes. Store graphics: yes. Sounds: no.

---

© 2026 Core Systems Asset Factory — CSAF. See `LICENSE.txt`.

## Changes in 0.1.1

- Every documented function now refuses a wrong-typed argument with a usable value, instead of stopping your game with a runtime error. Anything you already call with valid arguments behaves as before, and no save format changed. That includes `PliantMesh` and all of its methods; a mesh built on a sprite that no longer exists now draws nothing.
- The licence now names the copyright holder, Core Systems Asset Factory. It also no longer carries a stale pre-release note: this package has passed a real GameMaker build.
