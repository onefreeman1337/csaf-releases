/// ============================================================================================
/// MENAGERIE - menagerie_render: the draw layer.
///
/// ONE renderer draws every mark in the product: a species mark, a trait glyph and a full
/// ancestry emblem all route through men_draw_glyph / men_draw_emblem, so 24 species, 20 traits
/// and every bred emblem read as one heraldic language instead of a thousand doodles.
///
/// NO SPRITES. Nothing here reads a sprite, a texture page or an atlas. Every mark is stroked
/// from primitives at draw time, which is why a buyer can recolour, rescale and generate
/// emblems for companions that did not exist when the product shipped - a bred companion's
/// emblem is drawn from its lineage, never looked up in art.
///
/// BLEND-STATE HYGIENE - the rule this wing does not break.
///   Every public draw here SAVES and RESTORES blend mode, colour, alpha and text alignment.
///   A renderer that leaks bm_add into a buyer's pipeline produces a bug they will report as
///   "your asset broke my game's lighting", and you cannot debug it remotely. Every function
///   below is safe to call from anywhere in a buyer's draw event, in any order.
///
/// TEXT: this layer draws NO text at all. Companion names, trait labels and bond numbers are
/// UI, and they render in the demo (or the buyer's game) in whatever font is set there.
///
/// Public API:
///   men_colour(rgb)                                   -> GameMaker colour from {r,g,b}
///   men_draw_polyline(pts, x, y, size, w)             -> one unit-space polyline
///   men_draw_polyline_partial(pts, x, y, size, w, t)  -> the first t (0..1) of a polyline
///   men_style(tables, tincture_index)                 -> cached draw style for a tincture
///   men_draw_glyph(glyph, x, y, size, style, alpha, t)-> any MenGlyph, staged reveal at t<1
///   men_draw_emblem(plan, tables, x, y, size, time, alpha, t) -> the full ancestry emblem
///   men_draw_panel(x1, y1, x2, y2, fill, edge, alpha) -> chrome panel (tooltips, lists)
/// ============================================================================================

/// GameMaker packs colour as BGR, which is exactly the kind of detail that belongs in the
/// render layer and nowhere else - menagerie_core stays free of colour built-ins for that reason.
function men_colour(_rgb) {
    return make_colour_rgb(_rgb.r, _rgb.g, _rgb.b);
}

/// Draw a flat [x0,y0,x1,y1,...] polyline in UNIT SPACE, mapped to a box of `_size` at `_x,_y`.
function men_draw_polyline(_pts, _x, _y, _size, _w) {
    var _n = array_length(_pts);
    if (_n < 4) { return; }
    var _h = _size * 0.5;
    for (var _i = 0; _i < _n - 2; _i += 2) {
        draw_line_width(
            _x + _pts[_i]     * _h, _y + _pts[_i + 1] * _h,
            _x + _pts[_i + 2] * _h, _y + _pts[_i + 3] * _h,
            _w);
    }
}

/// Draw only the first `_t` (0..1) of a polyline - the stroke-in of the breeding reveal.
/// The partial final segment is interpolated so the line END moves smoothly, not per-vertex.
function men_draw_polyline_partial(_pts, _x, _y, _size, _w, _t) {
    var _n = array_length(_pts);
    if (_n < 4) { return; }
    var _t01 = clamp(_t, 0, 1);
    if (_t01 >= 1) { men_draw_polyline(_pts, _x, _y, _size, _w); return; }
    var _segs = (_n - 2) / 2;
    var _reach = _segs * _t01;
    var _full = floor(_reach);
    var _frac = _reach - _full;
    var _h = _size * 0.5;
    for (var _i = 0; _i < _full; _i++) {
        var _j = _i * 2;
        draw_line_width(
            _x + _pts[_j]     * _h, _y + _pts[_j + 1] * _h,
            _x + _pts[_j + 2] * _h, _y + _pts[_j + 3] * _h,
            _w);
    }
    if (_frac > 0 && _full < _segs) {
        var _j = _full * 2;
        var _ex = lerp(_pts[_j],     _pts[_j + 2], _frac);
        var _ey = lerp(_pts[_j + 1], _pts[_j + 3], _frac);
        draw_line_width(_x + _pts[_j] * _h, _y + _pts[_j + 1] * _h,
                        _x + _ex * _h, _y + _ey * _h, _w);
    }
}

/// Mix two {r,g,b} structs. Allocates - call it only when building caches, never per frame.
function __men_mix_rgb(_a, _b, _t) {
    return { r: round(lerp(_a.r, _b.r, _t)),
             g: round(lerp(_a.g, _b.g, _t)),
             b: round(lerp(_a.b, _b.b, _t)) };
}

/// Draw style for a tincture: the role mapping men_draw_glyph consumes.
///   edge   <- charge   (the mark itself)
///   body   <- charge sunk toward the field (the soft under-stroke)
///   detail <- accent   (pips and highlights)
///   glow   <- glow
/// Cached per tincture index - per-frame callers allocate NOTHING here.
function men_style(_tables, _tincture) {
    static _cache = [];
    // ⛔ THE PREDICATE MUST BE is_struct, NOT !is_undefined. MEASURED 2026-08-17, and it crashed
    // the demo on frame 1 with a CLEAN gate behind it (exit 0, 0 errors, 126 scripts compiled).
    // Assigning _cache[4] to an empty array does not leave holes - GML back-fills indices 0..3
    // with the NUMBER 0. `is_undefined(0)` is false, so the next call for tincture 2 sailed
    // through this guard and returned 0, and the caller then read `.glow_amt` off a number:
    //   "Variable obj_menagerie_demo.glow_amt(100055, -2147483648) not set before reading it."
    // The corpus page asks for tinctures in the order [4, 2, 1], which is what exposed it; a
    // caller that happened to warm the cache 0,1,2,... in order would never have seen it, and
    // that is exactly how this would have reached a buyer instead of me.
    if (_tincture < array_length(_cache) && is_struct(_cache[_tincture])) {
        return _cache[_tincture];
    }
    var _tn = _tables.tinctures[_tincture];
    var _st = {
        glow_amt: _tn.glow_amt,
        glow:     _tn.glow,
        body:     __men_mix_rgb(_tn.charge, _tn.field, 0.55),
        edge:     _tn.charge,
        detail:   _tn.accent,
        field:    _tn.field,
    };
    _cache[_tincture] = _st;
    return _st;
}

/// Draw one MenGlyph centred at (_x,_y) inside a box of _size px, in draw style `_style`
/// (from men_style, or any struct carrying glow_amt/glow/body/edge/detail as {r,g,b}).
///
/// Four passes, by palette ROLE - which is what makes eight bloodlines read as eight HOUSES
/// rather than eight hues:
///   1. GLOW  - wide, additive, scaled by the style's glow_amt (ashen carries none).
///   2. BODY  - a broad soft under-stroke that gives the mark physical weight.
///   3. EDGE  - the mark itself at full weight.
///   4. DETAIL- accent points as bright pips, additive.
/// `_t` stages the reveal: strokes draw in over 0..0.7, accents pop after 0.7. Pass 1 for the
/// finished mark.
function men_draw_glyph(_glyph, _x, _y, _size, _style, _alpha, _t) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_glyph) || !is_struct(_style) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_size)) return; if (!is_numeric(_alpha)) _alpha = 1; if (!is_numeric(_t)) _t = 1;
    // -- save GPU state --
    var _old_blend = gpu_get_blendmode();
    var _old_col   = draw_get_colour();
    var _old_alpha = draw_get_alpha();

    var _t01    = clamp(_t, 0, 1);
    var _lines  = men_glyph_flatten(_glyph);
    var _n      = array_length(_lines);
    var _wCore  = max(1, _size * 0.032);
    var _wBody  = max(2, _size * 0.070);
    var _wGlow  = max(3, _size * 0.110);
    var _strokeT = (_t01 >= 1) ? 1 : clamp(_t01 / 0.7, 0, 1);

    // strokes reveal one after another: stroke i owns its slice of _strokeT
    var _per = 1 / max(1, _n);

    // 1. glow
    if (_style.glow_amt > 0) {
        gpu_set_blendmode(bm_add);
        draw_set_colour(men_colour(_style.glow));
        draw_set_alpha(_alpha * 0.22 * _style.glow_amt);
        for (var _i = 0; _i < _n; _i++) {
            var _st = clamp((_strokeT - _i * _per) / _per, 0, 1);
            if (_st > 0) { men_draw_polyline_partial(_lines[_i], _x, _y, _size, _wGlow, _st); }
        }
    }

    // 2. body under-stroke
    gpu_set_blendmode(bm_normal);
    draw_set_colour(men_colour(_style.body));
    draw_set_alpha(_alpha * 0.55);
    for (var _i = 0; _i < _n; _i++) {
        var _st = clamp((_strokeT - _i * _per) / _per, 0, 1);
        if (_st > 0) { men_draw_polyline_partial(_lines[_i], _x, _y, _size, _wBody, _st); }
    }

    // 3. edge
    draw_set_colour(men_colour(_style.edge));
    draw_set_alpha(_alpha);
    for (var _i = 0; _i < _n; _i++) {
        var _st = clamp((_strokeT - _i * _per) / _per, 0, 1);
        if (_st > 0) { men_draw_polyline_partial(_lines[_i], _x, _y, _size, _wCore, _st); }
    }

    // 4. detail pips - after the strokes have landed.
    // ⚠️ `accents` is OPTIONAL on a glyph and the check must be variable_struct_exists, not
    // is_undefined. Species marks carry the field; TRAIT glyphs (__men_trait) and MUTATION
    // ACCENT glyphs (__men_accent) do not, and both are drawn through this same function by the
    // corpus page. Reading a struct member that was never set is a RUNTIME error in GML, which a
    // package build cannot see - the gate compiles this file clean either way. This wing's whole
    // §3 caveat is that a green compile is not a green run, so the optional field is probed
    // rather than assumed.
    var _acc = variable_struct_exists(_glyph, "accents") ? _glyph.accents : undefined;
    var _an  = is_undefined(_acc) ? 0 : array_length(_acc);
    if (_an >= 2 && _t01 > 0.7) {
        var _pt = clamp((_t01 - 0.7) / 0.3, 0, 1);
        gpu_set_blendmode(bm_add);
        draw_set_colour(men_colour(_style.detail));
        draw_set_alpha(_alpha * _pt);
        var _r = max(1.5, _size * 0.038) * (1.6 - 0.6 * _pt);   // pips settle as they land
        var _h = _size * 0.5;
        for (var _i = 0; _i < _an - 1; _i += 2) {
            draw_circle(_x + _acc[_i] * _h, _y + _acc[_i + 1] * _h, _r, false);
        }
    }

    // -- restore GPU state --
    gpu_set_blendmode(_old_blend);
    draw_set_colour(_old_col);
    draw_set_alpha(_old_alpha);
}

/// Chrome panel: fill, edge, and four corner ticks. The product's UI language - used by the
/// demo for lists and tooltips, and offered to buyers so their companion UI matches the emblems.
function men_draw_panel(_x1, _y1, _x2, _y2, _fill, _edge, _alpha) {
    var _old_col   = draw_get_colour();
    var _old_alpha = draw_get_alpha();

    draw_set_colour(men_colour(_fill));
    draw_set_alpha(_alpha);
    draw_rectangle(_x1, _y1, _x2, _y2, false);
    draw_set_colour(men_colour(_edge));
    draw_set_alpha(_alpha * 0.9);
    draw_rectangle(_x1, _y1, _x2, _y2, true);
    var _tick = min(10, (_x2 - _x1) * 0.08);
    draw_line_width(_x1, _y1, _x1 + _tick, _y1, 2);
    draw_line_width(_x1, _y1, _x1, _y1 + _tick, 2);
    draw_line_width(_x2, _y1, _x2 - _tick, _y1, 2);
    draw_line_width(_x2, _y1, _x2, _y1 + _tick, 2);
    draw_line_width(_x1, _y2, _x1 + _tick, _y2, 2);
    draw_line_width(_x1, _y2, _x1, _y2 - _tick, 2);
    draw_line_width(_x2, _y2, _x2 - _tick, _y2, 2);
    draw_line_width(_x2, _y2, _x2, _y2 - _tick, 2);

    draw_set_colour(_old_col);
    draw_set_alpha(_old_alpha);
}

// ── the emblem ───────────────────────────────────────────────────────────────────────────────

/// Fan centres per field index - every shipped field outline is star-shaped from this point,
/// so a triangle fan from here fills it exactly. Banner's tail notch is why this is per-field
/// rather than always the origin (a fan from (0,0) would bridge the notch). Split into two
/// scalar lookups so a per-frame caller allocates nothing.
function __men_field_fan_cx(_field) {
    static _cx = [0, 0, 0, 0, 0, 0];
    return _cx[_field];
}
function __men_field_fan_cy(_field) {
    static _cy = [-0.10, 0, 0, -0.30, 0.10, 0];
    return _cy[_field];
}

/// The flattened MAIN outline (stroke 0) of a field, cached per field index.
function __men_field_outline(_tables, _field) {
    static _cache = [];
    // Same sparse-write trap as men_style above, one type along: a back-filled slot is the NUMBER
    // 0, and `array_length(0)` on the returned value is the crash. The cached value here is an
    // ARRAY of flattened points, so the predicate is is_array.
    if (_field < array_length(_cache) && is_array(_cache[_field])) {
        return _cache[_field];
    }
    var _pts = __men_flatten_prim(_tables.fields[_field].strokes[0]);
    _cache[_field] = _pts;
    return _pts;
}

/// Draw a companion's full ancestry emblem from a compose plan (men_emblem_compose).
/// `_size` is the emblem's bounding box in px. `_time` drives the living glow; `_t` is the
/// breeding reveal:
///   0.00-0.12  field ground fades in
///   0.08-0.35  field outline strokes in
///   0.30-0.45  quartering dividers draw
///   0.40-0.80  charges stamp per panel, eldest first
///   0.80-0.92  the mutation accent pops at the chief
///   0.88-1.00  the bond ring sweeps closed to ring_t
/// Pass _t = 1 for the finished emblem. Draws NO text.
function men_draw_emblem(_plan, _tables, _x, _y, _size, _time, _alpha, _t) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_plan) || !is_struct(_tables) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_size)) return; if (!is_numeric(_time)) _time = 0; if (!is_numeric(_alpha)) _alpha = 1; if (!is_numeric(_t)) _t = 1;
    // -- save state --
    var _old_blend = gpu_get_blendmode();
    var _old_col   = draw_get_colour();
    var _old_alpha = draw_get_alpha();

    var _t01   = clamp(_t, 0, 1);
    var _style = men_style(_tables, _plan.tincture);
    var _tinc  = _tables.tinctures[_plan.tincture];
    var _fld   = _tables.fields[_plan.field];
    var _h     = _size * 0.5;

    // -- 1. field ground: triangle fan of the main outline in the field colour --
    var _groundA = _alpha * clamp(_t01 / 0.12, 0, 1);
    var _pts = __men_field_outline(_tables, _plan.field);
    var _np  = array_length(_pts);
    draw_set_colour(men_colour(_tinc.field));
    draw_set_alpha(_groundA);
    draw_primitive_begin(pr_trianglefan);
    draw_vertex(_x + __men_field_fan_cx(_plan.field) * _h, _y + __men_field_fan_cy(_plan.field) * _h);
    for (var _i = 0; _i < _np - 1; _i += 2) {
        draw_vertex(_x + _pts[_i] * _h, _y + _pts[_i + 1] * _h);
    }
    draw_primitive_end();

    // -- 2. field outline strokes in --
    var _outT = (_t01 >= 1) ? 1 : clamp((_t01 - 0.08) / 0.27, 0, 1);
    if (_outT > 0) {
        draw_set_colour(men_colour(_tinc.charge));
        draw_set_alpha(_alpha * 0.9);
        var _ns = array_length(_fld.strokes);
        var _per = 1 / max(1, _ns);
        for (var _i = 0; _i < _ns; _i++) {
            var _st = clamp((_outT - _i * _per) / _per, 0, 1);
            if (_st > 0) {
                men_draw_polyline_partial(__men_flatten_prim(_fld.strokes[_i]), _x, _y, _size,
                    max(1.5, _size * 0.014), _st);
            }
        }
        // gen bordure: an inset second outline whose weight carries the dynasty's age
        if (_plan.gen > 0 && _outT >= 1) {
            draw_set_alpha(_alpha * 0.45);
            men_draw_polyline(_pts, _x, _y, _size * 0.93,
                max(1, _size * 0.006 * min(_plan.gen, MEN_PANEL_MAX)));
        }
    }

    // -- 3. quartering dividers --
    var _qT = (_t01 >= 1) ? 1 : clamp((_t01 - 0.30) / 0.15, 0, 1);
    if (_qT > 0 && _plan.quarter > 1) {
        draw_set_colour(men_colour(_tinc.charge));
        draw_set_alpha(_alpha * 0.55 * _qT);
        var _ext = _h * 0.72;
        draw_line_width(_x, _y - _ext * _qT, _x, _y + _ext * _qT, max(1, _size * 0.008));
        if (_plan.quarter == 4) {
            draw_line_width(_x - _ext * _qT, _y, _x + _ext * _qT, _y, max(1, _size * 0.008));
        }
    }

    // -- 4. charges stamp per panel --
    var _pn = array_length(_plan.panels);
    for (var _i = 0; _i < _pn; _i++) {
        var _ct = (_t01 >= 1) ? 1 : clamp((_t01 - 0.40 - _i * (0.32 / max(1, _pn))) / 0.14, 0, 1);
        if (_ct <= 0) { continue; }
        var _px = _x; var _py = _y; var _ps = _size * 0.52;
        if (_plan.quarter == 2) {
            _px = _x + ((_i == 0) ? -1 : 1) * _size * 0.185;
            _ps = _size * 0.335;
        } else if (_plan.quarter == 4) {
            // clockwise from chief-dexter (viewer's top-left)
            var _qx = (_i == 0 || _i == 3) ? -1 : 1;
            var _qy = (_i <= 1) ? -1 : 1;
            _px = _x + _qx * _size * 0.185;
            _py = _y + _qy * _size * 0.170;
            _ps = _size * 0.295;
        }
        men_draw_glyph(_tables.species[_plan.panels[_i].species], _px, _py, _ps, _style,
            _alpha * _ct, (_t01 >= 1) ? 1 : _ct);
    }

    // -- 5. the mutation accent at the chief --
    var _aT = (_t01 >= 1) ? 1 : clamp((_t01 - 0.80) / 0.12, 0, 1);
    if (_aT > 0) {
        gpu_set_blendmode(bm_add);
        draw_set_colour(men_colour(_tinc.accent));
        draw_set_alpha(_alpha * _aT);
        var _ag = _tables.accents[_plan.accent];
        var _asz = _size * 0.16 * (1.35 - 0.35 * _aT);   // pops in large, settles
        var _ay = _y - _h * 0.56;
        var _ns2 = array_length(_ag.strokes);
        for (var _i = 0; _i < _ns2; _i++) {
            men_draw_polyline(__men_flatten_prim(_ag.strokes[_i]), _x, _ay, _asz,
                max(1, _size * 0.010));
        }
        gpu_set_blendmode(bm_normal);
    }

    // -- 6. the bond ring: two-pass (wide soft + thin bright - one mid pass reads dull) --
    var _rT = (_t01 >= 1) ? 1 : clamp((_t01 - 0.88) / 0.12, 0, 1);
    if (_rT > 0 && _plan.ring_t > 0) {
        gpu_set_blendmode(bm_add);
        var _sweep = 360 * _plan.ring_t * _rT;
        var _steps = max(4, round(40 * _plan.ring_t));
        var _rr = _h * 0.96;
        var _pulse = (_plan.ring_t >= 1) ? (0.80 + 0.20 * sin(_time * 2.0)) : 1.0;
        // ashen has no glow (0,0,0): its ring draws in the accent tone instead of vanishing
        var _ringCol = men_colour((_tinc.glow.r + _tinc.glow.g + _tinc.glow.b > 0) ? _tinc.glow : _tinc.accent);
        draw_set_colour(_ringCol);
        for (var _i = 0; _i < _steps; _i++) {
            var _a0 = degtorad(-90 + _sweep * (_i / _steps));
            var _a1 = degtorad(-90 + _sweep * ((_i + 1) / _steps));
            var _ax0 = _x + cos(_a0) * _rr;  var _ay0 = _y + sin(_a0) * _rr;
            var _ax1 = _x + cos(_a1) * _rr;  var _ay1 = _y + sin(_a1) * _rr;
            draw_set_alpha(_alpha * _rT * 0.28 * _pulse);
            draw_line_width(_ax0, _ay0, _ax1, _ay1, max(3, _size * 0.022));
            draw_set_alpha(_alpha * _rT * 0.9 * _pulse);
            draw_line_width(_ax0, _ay0, _ax1, _ay1, max(1, _size * 0.005));
        }
        // at full bond: three small rays at the crown of the ring
        if (_plan.ring_t >= 1) {
            draw_set_alpha(_alpha * _rT * 0.9);
            var _ry = _y - _rr;
            draw_line_width(_x, _ry - _size * 0.010, _x, _ry - _size * 0.050, max(1, _size * 0.006));
            draw_line_width(_x - _size * 0.030, _ry - _size * 0.004, _x - _size * 0.058, _ry - _size * 0.030, max(1, _size * 0.006));
            draw_line_width(_x + _size * 0.030, _ry - _size * 0.004, _x + _size * 0.058, _ry - _size * 0.030, max(1, _size * 0.006));
        }
        gpu_set_blendmode(bm_normal);
    }

    // -- restore state --
    gpu_set_blendmode(_old_blend);
    draw_set_colour(_old_col);
    draw_set_alpha(_old_alpha);
}
