/// ============================================================================================
/// MENAGERIE - menagerie_preset: content and taste.
///
/// The UI theme, a deterministic naming book, and one copy-me registry example, as plain data.
/// Everything here is meant to be copied, retuned or replaced wholesale - none of it is
/// load-bearing for the system, and the demo scaffolding is commented as delete-me.
///
/// This file is deliberately the SMALLEST of the four. The product's value is the generator in
/// menagerie_core; your species roster and your naming voice are your own, and Menagerie draws
/// emblems for content that did not exist when this shipped.
/// ============================================================================================

/// The UI theme. Custom throughout - GameMaker draws none of this, which is the point (a
/// product that looks like the engine gets dismissed on the thumbnail).
function men_theme() {
    static _t = {
        bg:        { r:  13, g:  14, b:  19 },
        panel:     { r:  21, g:  24, b:  33 },
        rule:      { r:  52, g:  58, b:  76 },
        text:      { r: 216, g: 222, b: 235 },
        text_dim:  { r: 126, g: 136, b: 158 },
        good:      { r: 132, g: 210, b: 148 },
        pad:       28,
        rowH:      42,
    };
    return _t;
}

/// The naming book: two pools, both drawn from the companion's own seed, so a companion is
/// NAMED deterministically - the same lineage produces the same name on every machine, and a
/// name never has to be saved. Replace both pools with your game's voice; sizes are free.
function men_name_pool_fore() {
    static _p = ["Ash", "Briar", "Cinder", "Dune", "Ember", "Fen", "Gale", "Hollow",
                 "Iris", "Juniper", "Kestrel", "Larch", "Moss", "North", "Oath", "Pyre",
                 "Quill", "Rook", "Sable", "Thorn", "Umber", "Vale", "Wren", "Yarrow"];
    return _p;
}
function men_name_pool_hind() {
    static _p = ["bane", "brook", "claw", "crest", "dancer", "down", "fang", "gaze",
                 "heart", "hide", "howl", "mane", "mark", "shade", "song", "step",
                 "sworn", "tail", "watch", "wing"];
    return _p;
}

/// A companion's deterministic name, from its seed: a fore+hind compound, so the name space is
/// 24 x 20 = 480 rather than the bare 24 of the fore pool.
///
/// ⚠️ FOUNDERS USED TO GET A BARE FORE NAME, AND IT COLLIDED CONSTANTLY. A name here is a pure
/// function of ONE seed, so nothing can consult the rest of the roster to keep names unique - and
/// 17 founders drawing from 24 fore names is the birthday problem with a bad answer. MEASURED
/// 2026-08-17 by capturing the paddock page and reading it: THREE companions named "Fen", plus two
/// "Wren", two "Quill" and two "Dune" on one wall. On the page whose entire claim is "no two
/// alike", duplicate names argue against the product in the one image most buyers ever see.
/// Compounding costs the generation signal nothing, because every companion already renders its
/// generation beside its name (and its emblem's quartering shows it at a glance).
function men_name_for(_comp) {
    var _fore = men_name_pool_fore();
    var _hind = men_name_pool_hind();
    var _r = __men_rng(_comp.seed + 101);   // offset stream: never the identity roll's draws
    var _f = _fore[__men_rng_range(_r, array_length(_fore))];
    return _f + _hind[__men_rng_range(_r, array_length(_hind))];
}

/// COPY-ME: registering your own species. Build it with the same constructors the corpus uses;
/// it founds, breeds and renders exactly like a shipped one. DELETE-ME in your project.
///
///   var reg = men_registry_create();
///   men_registry_add_species(reg, __men_species("fox", "Fox", "beast", 7, 11, 8,
///       [men_poly([-0.50, -0.26, -0.36, -0.62, -0.20, -0.30, -0.04, -0.62, 0.12, -0.26]),
///        men_line(-0.42, -0.06, 0.58, 0.26),
///        men_poly([-0.60, 0.42, -0.30, 0.22, -0.44, 0.52, -0.60, 0.42])],   // the brush tail
///       [-0.14, 0.02]));
///
/// APPEND-ONLY, as the Readme states: registered content appends after the corpus, so every
/// existing save keeps its identity. Never remove or reorder between builds.
function men_preset_notes() {
    // exists so the doc block above ships inside the asset browser; returns nothing useful
    return "see comments";
}
