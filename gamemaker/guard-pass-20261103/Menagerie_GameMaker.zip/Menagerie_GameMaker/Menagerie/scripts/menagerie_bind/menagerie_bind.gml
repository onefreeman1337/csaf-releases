/// ============================================================================================
/// MENAGERIE - menagerie_bind: the engine binding.
///
/// Everything impure lives here: the clock, the buyer's registered content, the hatch reveal's
/// animation state, the runtime companion wrapper, and the save/load round-trip. menagerie_core
/// stays a pure function library so it can be mirrored and reasoned about; this file is where
/// Menagerie meets a running game.
///
/// ⛔ THE delta_time CONVERSION HAPPENS IN EXACTLY ONE PLACE - `__men_dt()`.
///   GameMaker's delta_time is MICROSECONDS. Dividing by 1000 instead of 1,000,000 yields
///   animations that run 1000x fast, which reads as "the effect just pops" rather than as a
///   bug. This wing has hit that trap before. One conversion, one place, never inline.
///
/// SAVE FORMAT - versioned from day one, and tiny by design.
///   A companion persists as { v, name, xp, lin } where `lin` is the lineage tree of seeds
///   (men_lineage_pack). Founding and breeding are pure functions of those seeds, so the tree
///   IS the companion - species, traits, tincture, field, accent and the whole emblem re-derive
///   identically at load. If you APPEND content (the supported path), old seeds keep their
///   identity; if you REORDER or REMOVE corpus entries between builds, derived companions
///   change - append, never reorder, is the compatibility contract and it is stated in the
///   Readme.
///
/// Public API:
///   men_registry_create()                        -> a content registry (buyer's own additions)
///   men_registry_add_species(reg, sp)            -> register a custom species mark
///   men_registry_add_trait(reg, trait)           -> register a custom trait glyph
///   men_registry_add_tincture(reg, tinc)         -> register a custom bloodline tincture
///   men_tables(reg)                              -> merged corpus + custom tables (cached)
///   men_hatch_create()                           -> hatch state for the breeding reveal
///   men_hatch_founder(h, reg, seed)              -> derive a founder, start the reveal
///   men_hatch_breed(h, reg, sire, dam, seed)     -> breed, start the reveal
///   men_hatch_step(h)                            -> advance the reveal (call once per step)
///   men_companion_wrap(comp, name)               -> runtime wrapper { comp, name, xp }
///   men_companion_award(w, xp)                   -> add bond XP (clamped at the curve's top)
///   men_companion_bond(w)                        -> men_bond_level of the wrapper's xp
///   men_companion_pack(w) / men_companion_unpack(reg, data)
/// ============================================================================================

/// The ONLY microseconds -> seconds conversion in Menagerie.
function __men_dt() {
    return delta_time / 1000000;
}

// ── the registry: the buyer's content, merged over the corpus ────────────────────────────────

function men_registry_create() {
    return {
        species:   [],
        traits:    [],
        tinctures: [],
        _cache:    undefined,   // merged tables, invalidated by every add
    };
}

/// Register a custom species (build it with __men_species / men_line / men_arc / men_poly - the
/// same constructors the corpus uses). It founds, breeds and renders exactly like a shipped one.
/// APPEND-ONLY: never remove or reorder registered content between builds - seeds index into
/// these tables, and that stability is the save-compatibility contract.
function men_registry_add_species(_reg, _sp) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_reg) || !is_struct(_sp)) return;
    array_push(_reg.species, _sp);
    _reg._cache = undefined;
}

/// Register a custom trait glyph (__men_trait). Appears in founder and breeding picks at its
/// stated weight, and on every emblem trait rail it is rolled onto.
function men_registry_add_trait(_reg, _trait) {
    array_push(_reg.traits, _trait);
    _reg._cache = undefined;
}

/// Register a custom bloodline tincture (__men_tincture). Fourteen numbers, a whole house.
function men_registry_add_tincture(_reg, _tinc) {
    array_push(_reg.tinctures, _tinc);
    _reg._cache = undefined;
}

/// The merged tables: corpus first (stable indices), registered content appended after.
/// Cached until the registry changes; per-frame callers pay an is_undefined check.
function men_tables(_reg) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_reg)) _reg = men_registry_create();
    if (!is_undefined(_reg._cache)) { return _reg._cache; }
    var _t = men_tables_default();
    var _m = {
        species:   __men_concat(_t.species, _reg.species),
        traits:    __men_concat(_t.traits, _reg.traits),
        tinctures: __men_concat(_t.tinctures, _reg.tinctures),
        fields:    _t.fields,
        accents:   _t.accents,
    };
    _reg._cache = _m;
    return _m;
}

/// Concatenate two arrays into a fresh one (registry merge only - never per frame).
function __men_concat(_a, _b) {
    var _out = [];
    var _n = array_length(_a);
    for (var _i = 0; _i < _n; _i++) { array_push(_out, _a[_i]); }
    _n = array_length(_b);
    for (var _i = 0; _i < _n; _i++) { array_push(_out, _b[_i]); }
    return _out;
}

// ── the hatch: the breeding reveal's animation state ─────────────────────────────────────────

/// Reveal timing. The hold at the end is the Athanor lesson: the payoff must LAST - a reveal
/// that re-rolls on the next frame gives the finished emblem ~16 ms on screen.
#macro MEN_HATCH_SECONDS 2.6
#macro MEN_HATCH_HOLD    1.35

function men_hatch_create() {
    return { comp: undefined, t: 0, hold: 0, active: false };
}

/// Derive a founder from a seed and start the reveal.
function men_hatch_founder(_h, _reg, _seed) {
    _h.comp   = men_founder(_seed, men_tables(_reg));
    _h.t      = 0;
    _h.hold   = 0;
    _h.active = true;
    return _h.comp;
}

/// Breed two companions and start the reveal.
function men_hatch_breed(_h, _reg, _sire, _dam, _seed) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_h) || !is_struct(_reg) || !is_struct(_sire) || !is_struct(_dam)) return undefined; if (!is_numeric(_seed)) _seed = 0;
    _h.comp   = men_breed(_sire, _dam, _seed, men_tables(_reg));
    _h.t      = 0;
    _h.hold   = 0;
    _h.active = true;
    return _h.comp;
}

/// Advance the reveal. Call once per step. Returns the current reveal t in 0..1; the hold
/// keeps `active` true for MEN_HATCH_HOLD seconds after t reaches 1 so a driving state machine
/// does not snatch the finished emblem off the screen.
function men_hatch_step(_h) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_h)) return 0;
    if (!_h.active) { return (is_undefined(_h.comp)) ? 0 : 1; }
    if (_h.t < 1) {
        _h.t = min(1, _h.t + __men_dt() / MEN_HATCH_SECONDS);
    } else {
        _h.hold += __men_dt();
        if (_h.hold >= MEN_HATCH_HOLD) { _h.active = false; }
    }
    return _h.t;
}

// ── the runtime companion wrapper: identity + the mutable bits ───────────────────────────────

/// Wrap a pure companion in runtime state. The wrapper owns what CHANGES (name, bond XP);
/// the companion inside never mutates - it is identity, derived from seeds.
function men_companion_wrap(_comp, _name) {
    return { comp: _comp, name: _name, xp: 0 };
}

/// Award bond XP. Clamped at the top of the curve so the ring cannot overshoot.
function men_companion_award(_w, _xp) {
    _w.xp = min(_w.xp + max(0, _xp), 480);
    return _w.xp;
}

/// The wrapper's bond, via the core curve.
function men_companion_bond(_w) {
    return men_bond_level(_w.xp);
}

// ── persistence ──────────────────────────────────────────────────────────────────────────────

/// Pack a wrapped companion to pure data. { v, name, xp, lin } - the lineage tree of seeds is
/// the whole identity; nothing derived is stored, so nothing derived can go stale.
function men_companion_pack(_w) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_w)) return undefined;
    return { v: MEN_VERSION, name: _w.name, xp: _w.xp, lin: men_lineage_pack(_w.comp) };
}

/// Rebuild a wrapped companion from packed data against the CURRENT registry. A version field
/// travels with every save; today there is one version, and the field exists so a future
/// migration has something to dispatch on.
function men_companion_unpack(_reg, _data) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_reg) || !is_struct(_data)) return undefined;
    var _comp = men_lineage_unpack(_data.lin, men_tables(_reg));
    var _w = men_companion_wrap(_comp, _data.name);
    _w.xp = _data.xp;
    return _w;
}
