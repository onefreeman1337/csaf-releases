/// ============================================================================================
/// MENAGERIE - menagerie_core: the pure generator core.
///
/// ZERO engine calls. Nothing in this file reads an instance, a room, a sprite, the clock or the
/// renderer; the only built-ins used are pure maths (sin/cos/floor/min/max/abs/clamp/lerp/pi/
/// degtorad) and array/struct functions. That is deliberate: GML cannot be unit-tested outside
/// GameMaker, so every algorithm in Menagerie lives where it can be read, reasoned about and
/// mirrored numerically in isolation. `Internal_Ops/sim_mirror.js` is that mirror - and unlike
/// earlier products it does not transliterate this corpus: it EXTRACTS the tables between the
/// MIRROR markers below and evaluates the exact shipped data, so the two cannot drift.
///
/// THE ONE IDEA - a companion is a lineage of seeds, and the emblem is a pure function of it.
///   men_breed(sire, dam, seed, tables) -> a new companion whose species, traits and tincture
///   are drawn from a deterministic 32-bit xorshift stream seeded by the birth seed. NEVER
///   random(). men_emblem_compose(companion, tables, bond_t) turns ancestry into a draw plan -
///   field from the eldest founder line, quartering from generation depth, charges from the sire
///   and dam lines, one rolled mutation accent - and menagerie_render turns the plan into a
///   picture. Same lineage -> same emblem, in any session, on any machine. Breeding produces NEW
///   pictures, which is the discovery loop, and a companion persists as its lineage tree of
///   seeds plus a version - a save cannot bloat and cannot rot.
///
/// THE VOLUME IS THE MOAT (master 1.1 rule 3 - authored in Motif_Corpus.md BEFORE any code).
///   24 species marks x 6 field shapes x 8 bloodline tinctures = 1,152 founder emblems before
///   quartering, charges and the 8 mutation accents even start. Rules are cheap; a corpus that
///   coheres into one heraldic language is not.
///
/// Public API (everything else is internal and prefixed __men_):
///   men_species_table()                  -> array of 24 species marks (cached)
///   men_trait_table()                    -> array of 20 trait glyphs (cached)
///   men_tincture_table()                 -> array of 8 bloodline tinctures (cached)
///   men_field_table()                    -> array of 6 field shapes (cached)
///   men_accent_table()                   -> array of 8 mutation accents (cached)
///   men_tables_default()                 -> { species, traits, tinctures, fields, accents }
///   men_species_find(tables, id)         -> index of a species by string id, or -1
///   men_trait_find(tables, id)           -> index of a trait by string id, or -1
///   men_glyph_flatten(glyph)             -> array of polylines, each a flat [x0,y0,x1,y1,...]
///   men_founder(seed, tables)            -> deterministic founder companion (generation 0)
///   men_breed(sire, dam, seed, tables)   -> deterministic offspring companion
///   men_emblem_compose(comp, tbl, bond)  -> the emblem draw plan (field, panels, charges, ring)
///   men_bond_level(xp)                   -> { level, progress, t } from the bond curve
///   men_lineage_depth(comp)              -> generations behind this companion (founder = 0)
///   men_lineage_pack(comp)               -> pure-data save form (seeds only)
///   men_lineage_unpack(packed, tables)   -> rebuild the identical companion from seeds
/// ============================================================================================

#macro MEN_VERSION        "1.0.0"
#macro MEN_SPECIES_COUNT  24
#macro MEN_TRAIT_COUNT    20
#macro MEN_TINCTURE_COUNT 8
#macro MEN_FIELD_COUNT    6
#macro MEN_ACCENT_COUNT   8
#macro MEN_ARC_SEGS       24      // flattening resolution for a full 360 degree arc
#macro MEN_PANEL_MAX      4       // quartering cap: older ancestry collapses into the bordure
#macro MEN_BOND_MAX       5       // bond levels; the ring closes across them

// ── stroke primitive constructors ────────────────────────────────────────────────────────────
// Kept as tiny structs so the corpus below reads as authored geometry rather than as maths.
// Unit space is [-1..1] on both axes; the renderer maps it to the draw box. y is screen-down,
// so NEGATIVE y is UP: an arc from 180 to 360 sweeps the TOP of its circle.

function men_line(_ax, _ay, _bx, _by) {
    return { k: "line", ax: _ax, ay: _ay, bx: _bx, by: _by };
}
function men_arc(_cx, _cy, _r, _a0, _a1) {
    return { k: "arc", cx: _cx, cy: _cy, r: _r, a0: _a0, a1: _a1 };
}
function men_circle(_cx, _cy, _r) {
    return { k: "arc", cx: _cx, cy: _cy, r: _r, a0: 0, a1: 360 };
}
function men_poly(_pts) {
    return { k: "poly", pts: _pts };          // flat [x0,y0,x1,y1,...]
}
function men_spiral(_cx, _cy, _r0, _r1, _a0, _a1) {
    return { k: "spiral", cx: _cx, cy: _cy, r0: _r0, r1: _r1, a0: _a0, a1: _a1 };
}

/// Flatten one primitive to a flat polyline [x0,y0,x1,y1,...]. Deterministic.
function __men_flatten_prim(_p) {
    var _out = [];
    switch (_p.k) {
        case "line":
            _out = [_p.ax, _p.ay, _p.bx, _p.by];
        break;

        case "poly": {
            // copy so a caller cannot mutate the cached corpus
            var _n = array_length(_p.pts);
            for (var _i = 0; _i < _n; _i++) { array_push(_out, _p.pts[_i]); }
        } break;

        case "arc": {
            var _span = _p.a1 - _p.a0;
            var _steps = max(2, round(MEN_ARC_SEGS * abs(_span) / 360));
            for (var _i = 0; _i <= _steps; _i++) {
                var _a = degtorad(_p.a0 + _span * (_i / _steps));
                array_push(_out, _p.cx + cos(_a) * _p.r);
                array_push(_out, _p.cy + sin(_a) * _p.r);
            }
        } break;

        case "spiral": {
            var _span = _p.a1 - _p.a0;
            var _steps = max(2, round(MEN_ARC_SEGS * abs(_span) / 360));
            for (var _i = 0; _i <= _steps; _i++) {
                var _t = _i / _steps;
                var _a = degtorad(_p.a0 + _span * _t);
                var _r = lerp(_p.r0, _p.r1, _t);
                array_push(_out, _p.cx + cos(_a) * _r);
                array_push(_out, _p.cy + sin(_a) * _r);
            }
        } break;
    }
    return _out;
}

/// Flatten a whole MenGlyph -> array of flat polylines.
function men_glyph_flatten(_glyph) {
    var _out = [];
    var _n = array_length(_glyph.strokes);
    for (var _i = 0; _i < _n; _i++) {
        array_push(_out, __men_flatten_prim(_glyph.strokes[_i]));
    }
    return _out;
}

// ── authored helpers used by the corpus ──────────────────────────────────────────────────────

/// closed regular n-gon
function __men_ngon(_cx, _cy, _r, _n, _rot) {
    var _pts = [];
    for (var _i = 0; _i <= _n; _i++) {
        var _a = degtorad(_rot + (360 / _n) * _i);
        array_push(_pts, _cx + cos(_a) * _r);
        array_push(_pts, _cy + sin(_a) * _r);
    }
    return _pts;
}

/// closed n-point star
function __men_star(_cx, _cy, _ro, _ri, _points, _rot) {
    var _pts = [];
    var _tot = _points * 2;
    for (var _i = 0; _i <= _tot; _i++) {
        var _r = (_i % 2 == 0) ? _ro : _ri;
        var _a = degtorad(_rot + (180 / _points) * _i);
        array_push(_pts, _cx + cos(_a) * _r);
        array_push(_pts, _cy + sin(_a) * _r);
    }
    return _pts;
}

/// sine wave polyline
function __men_wave(_x0, _x1, _y, _amp, _cycles) {
    var _pts = [];
    for (var _i = 0; _i <= 32; _i++) {
        var _t = _i / 32;
        array_push(_pts, lerp(_x0, _x1, _t));
        array_push(_pts, _y + sin(_t * _cycles * 2 * pi) * _amp);
    }
    return _pts;
}

/// axis-aligned ellipse polyline
function __men_ellipse(_cx, _cy, _rx, _ry) {
    var _pts = [];
    for (var _i = 0; _i <= 24; _i++) {
        var _a = degtorad((360 / 24) * _i);
        array_push(_pts, _cx + cos(_a) * _rx);
        array_push(_pts, _cy + sin(_a) * _ry);
    }
    return _pts;
}

/// species mark: id, display name, family (beast/bird/scale/mythic), base disposition block
/// (strength / wit / heart), geometry. Disposition seeds the trait-weighting at breeding time.
function __men_species(_id, _name, _family, _str, _wit, _hrt, _strokes, _accents) {
    return { id: _id, name: _name, family: _family,
             str: _str, wit: _wit, hrt: _hrt,
             strokes: _strokes, accents: _accents };
}

/// trait glyph: id, display name, kind (temperament/aptitude), inherit weight, geometry
function __men_trait(_id, _name, _kind, _w, _strokes) {
    return { id: _id, name: _name, kind: _kind, w: _w, strokes: _strokes };
}

/// bloodline tincture: id, name, glow strength, then field / charge / accent / glow r,g,b
function __men_tincture(_id, _name, _glow_amt,
                        _fr, _fg, _fb, _cr, _cg, _cb, _ar, _ag, _ab, _gr, _gg, _gb) {
    return {
        id: _id, name: _name, glow_amt: _glow_amt,
        field:  { r: _fr, g: _fg, b: _fb },
        charge: { r: _cr, g: _cg, b: _cb },
        accent: { r: _ar, g: _ag, b: _ab },
        glow:   { r: _gr, g: _gg, b: _gb },
    };
}

/// field shape: id, name, closed outline strokes in unit space (the emblem ground)
function __men_field(_id, _name, _strokes) {
    return { id: _id, name: _name, strokes: _strokes };
}

/// mutation accent: id, name, tiny geometry placed at the chief centre
function __men_accent(_id, _name, _strokes) {
    return { id: _id, name: _name, strokes: _strokes };
}

// ── THE 24 SPECIES MARKS ─────────────────────────────────────────────────────────────────────
// Per Internal_Ops/Motif_Corpus.md. Heads face RIGHT where a species has a face. Every mark is
// 2-4 strokes in unit space; accents are marked points (eyes), stored flat as x,y pairs.
// `static` caches the table after the first call - the corpus is immutable.

function men_species_table() {
    static _tbl =
    // >>> MIRROR SPECIES
    [
        // ---- beasts (6) ----
        __men_species("wolf", "Wolf", "beast", 12, 8, 6,
            [men_poly([-0.52, -0.28, -0.36, -0.68, -0.20, -0.32, -0.02, -0.68, 0.14, -0.28]),
             men_line(-0.44, -0.10, 0.62, 0.30),
             men_line(-0.36, 0.42, 0.62, 0.30)],
            [-0.16, 0.02]),
        __men_species("bear", "Bear", "beast", 14, 5, 8,
            [men_arc(0, 0.12, 0.72, 180, 360),
             men_line(-0.72, 0.12, 0.72, 0.12),
             men_arc(-0.28, -0.58, 0.11, 180, 360)],
            [0.34, -0.06]),
        __men_species("stag", "Stag", "beast", 9, 8, 10,
            [men_poly([-0.56, -0.70, -0.36, -0.46, -0.16, -0.64, -0.36, -0.46, -0.26, -0.06]),
             men_poly([0.56, -0.70, 0.36, -0.46, 0.16, -0.64, 0.36, -0.46, 0.26, -0.06]),
             men_poly([-0.26, -0.06, 0, 0.52, 0.26, -0.06])],
            []),
        __men_species("boar", "Boar", "beast", 13, 4, 6,
            [men_poly([-0.62, 0.10, 0.55, -0.10, 0.62, 0.24, -0.42, 0.38, -0.62, 0.10]),
             men_arc(0.48, 0.02, 0.20, 60, 200)],
            [-0.20, 0.16]),
        __men_species("hare", "Hare", "beast", 5, 10, 9,
            [men_line(-0.10, -0.10, -0.30, -0.76),
             men_line(0.04, -0.10, 0.30, -0.72),
             men_arc(0.0, 0.32, 0.42, 270, 450),
             men_circle(-0.06, -0.02, 0.16)],
            []),
        __men_species("ox", "Ox", "beast", 14, 4, 8,
            [men_line(-0.44, -0.22, 0.44, -0.22),
             men_arc(-0.60, -0.06, 0.20, 270, 450),
             men_arc(0.60, -0.06, 0.20, 90, 270),
             men_poly([-0.24, -0.22, -0.20, 0.34, 0.20, 0.34, 0.24, -0.22])],
            [-0.08, 0.20, 0.08, 0.20]),

        // ---- birds (6) ----
        __men_species("hawk", "Hawk", "bird", 10, 11, 5,
            [men_poly([-0.72, -0.02, -0.16, -0.46, 0.40, -0.02]),
             men_poly([0.44, 0.02, 0.66, 0.14, 0.52, 0.26])],
            [0.28, 0.06]),
        __men_species("owl", "Owl", "bird", 6, 14, 7,
            [men_arc(-0.22, -0.12, 0.24, 180, 360),
             men_arc(0.22, -0.12, 0.24, 180, 360),
             men_poly([-0.46, -0.12, 0, 0.44, 0.46, -0.12])],
            [-0.22, 0.02, 0.22, 0.02]),
        __men_species("crane", "Crane", "bird", 5, 9, 12,
            [men_arc(-0.10, 0.28, 0.34, 90, 270),
             men_arc(0.10, -0.22, 0.28, 270, 450),
             men_line(0.10, -0.50, 0.54, -0.58)],
            [0.16, -0.42]),
        __men_species("raven", "Raven", "bird", 7, 13, 5,
            [men_poly([-0.30, 0.0, 0.0, -0.30, 0.30, 0.0, 0.0, 0.30, -0.30, 0.0]),
             men_poly([0.26, -0.06, 0.72, 0.10, 0.26, 0.16])],
            [-0.04, -0.02]),
        __men_species("swift", "Swift", "bird", 4, 10, 8,
            [men_arc(-0.20, 0.16, 0.60, 290, 420),
             men_arc(0.20, 0.16, 0.60, 120, 250)],
            []),
        __men_species("heron", "Heron-crest", "bird", 5, 8, 11,
            [men_line(0, 0.35, -0.34, -0.55),
             men_line(0, 0.35, 0.02, -0.66),
             men_line(0, 0.35, 0.38, -0.50)],
            []),

        // ---- scales (6) ----
        __men_species("serpent", "Serpent", "scale", 8, 12, 3,
            [men_arc(-0.16, 0.30, 0.34, 90, 270),
             men_arc(0.16, -0.25, 0.30, 270, 450),
             men_poly([0.12, -0.52, 0.30, -0.72, 0.42, -0.50])],
            []),
        __men_species("tortoise", "Tortoise", "scale", 6, 7, 12,
            [men_arc(0, 0.10, 0.55, 180, 360),
             men_line(-0.62, 0.10, 0.62, 0.10),
             men_line(-0.18, -0.42, -0.10, 0.10),
             men_line(0.18, -0.40, 0.10, 0.10)],
            []),
        __men_species("newt", "Newt", "scale", 4, 9, 8,
            [men_poly(__men_wave(-0.70, 0.10, 0.25, 0.12, 1.5)),
             men_line(0.10, 0.25, 0.42, -0.12),
             men_poly([0.62, -0.30, 0.42, -0.12, 0.66, -0.10, 0.42, -0.12, 0.56, 0.08])],
            []),
        __men_species("pike", "Pike", "scale", 11, 6, 4,
            [men_poly([-0.58, 0.0, -0.72, -0.14, -0.66, 0.0, -0.72, 0.14, -0.58, 0.0,
                       -0.20, -0.16, 0.34, -0.13, 0.68, 0.0, 0.34, 0.13, -0.20, 0.16, -0.58, 0.0]),
             men_arc(0.38, 0, 0.14, 90, 270)],
            [0.52, -0.03]),
        __men_species("crab", "Crab", "scale", 9, 5, 7,
            [men_arc(0, 0.05, 0.42, 160, 380),
             men_arc(-0.55, -0.05, 0.22, 30, 200),
             men_arc(0.55, -0.05, 0.22, -20, 150)],
            [-0.10, -0.18, 0.10, -0.18]),
        __men_species("moth", "Moth-scale", "scale", 3, 11, 9,
            [men_poly([-0.62, -0.35, -0.08, 0.0, -0.62, 0.30, -0.62, -0.35]),
             men_poly([0.62, -0.35, 0.08, 0.0, 0.62, 0.30, 0.62, -0.35]),
             men_line(0, -0.15, 0, 0.35),
             men_poly([-0.14, -0.38, 0, -0.15, 0.14, -0.38])],
            []),

        // ---- mythics (6) ----
        __men_species("drake", "Drake", "mythic", 13, 9, 5,
            [men_arc(-0.12, 0.34, 0.28, 90, 270),
             men_arc(0.12, -0.10, 0.26, 270, 450),
             men_line(0.06, -0.30, 0.44, -0.66),
             men_line(0.06, -0.30, 0.60, -0.34)],
            []),
        __men_species("gryph", "Gryph", "mythic", 12, 10, 7,
            [men_poly([-0.66, -0.14, -0.22, -0.52, 0.20, -0.14]),
             men_arc(0.24, 0.22, 0.38, 270, 450)],
            [0.02, -0.20]),
        __men_species("kirin", "Kirin", "mythic", 8, 12, 11,
            [men_poly([-0.42, -0.68, -0.26, -0.40, -0.06, -0.60, -0.26, -0.40, -0.18, -0.06]),
             men_spiral(0.22, -0.38, 0.02, 0.26, 0, 540),
             men_poly([-0.18, -0.06, 0.06, 0.44, 0.30, -0.02])],
            []),
        __men_species("wisp", "Wisp", "mythic", 3, 13, 10,
            [men_circle(0, 0.05, 0.14),
             men_line(0.20, -0.10, 0.38, -0.36),
             men_line(-0.24, -0.16, -0.36, -0.44),
             men_line(0.02, -0.24, -0.02, -0.54)],
            []),
        __men_species("sphinx", "Sphinx", "mythic", 9, 14, 8,
            [men_poly(__men_ellipse(-0.12, -0.15, 0.26, 0.32)),
             men_line(-0.34, -0.28, 0.10, -0.28),
             men_line(-0.38, 0.42, 0.60, 0.42)],
            [-0.06, -0.10]),
        __men_species("leviathan", "Leviathan", "mythic", 14, 7, 6,
            [men_poly(__men_wave(-0.66, 0.50, -0.10, 0.16, 1.0)),
             men_poly(__men_wave(-0.58, 0.42, 0.14, 0.13, 1.0)),
             men_poly([0.50, -0.10, 0.72, -0.30, 0.62, -0.06, 0.78, 0.06, 0.50, -0.10])],
            []),
    ];
    // <<< MIRROR SPECIES
    return _tbl;
}

// ── THE 20 TRAIT GLYPHS ──────────────────────────────────────────────────────────────────────
// Temperament (8) then aptitude (12). Each 1-4 strokes, rendered small on the bond page and the
// emblem card's trait rail. Weights drive inheritance picks.

function men_trait_table() {
    static _tbl =
    // >>> MIRROR TRAITS
    [
        // ---- temperament (8) ----
        __men_trait("loyal",    "Loyal",     "temperament", 12,
            [men_circle(0, 0, 0.44), men_line(0.44, 0, 0.16, 0)]),
        __men_trait("fierce",   "Fierce",    "temperament", 10,
            [men_poly([-0.45, 0.5, -0.30, -0.30, -0.05, 0.25, 0.15, -0.50, 0.32, 0.20, 0.48, -0.15])]),
        __men_trait("timid",    "Timid",     "temperament", 8,
            [men_arc(0, 0.10, 0.46, 180, 360), men_circle(0, 0.16, 0.08)]),
        __men_trait("proud",    "Proud",     "temperament", 9,
            [men_line(0, 0.5, 0, -0.46), men_line(-0.18, 0.5, 0.18, 0.5)]),
        __men_trait("cunning",  "Cunning",   "temperament", 10,
            [men_poly([-0.5, -0.05, -0.15, -0.35, 0.2, -0.05]),
             men_poly([-0.3, 0.35, 0.05, 0.05, 0.4, 0.35])]),
        __men_trait("gentle",   "Gentle",    "temperament", 11,
            [men_poly(__men_wave(-0.5, 0.34, 0, 0.18, 1)), men_circle(0.44, 0, 0.07)]),
        __men_trait("stubborn", "Stubborn",  "temperament", 9,
            [men_poly([-0.35, -0.4, -0.35, 0.34, 0.35, 0.34, 0.35, -0.4]),
             men_line(-0.5, 0.5, 0.5, 0.5)]),
        __men_trait("wild",     "Wild",      "temperament", 7,
            [men_line(0, 0.5, 0, 0.05),
             men_poly([-0.4, -0.3, 0, 0.05, -0.12, -0.45, 0, 0.05, 0.2, -0.42, 0, 0.05, 0.45, -0.2])]),

        // ---- aptitude (12) ----
        __men_trait("hunter",    "Hunter",     "aptitude", 10,
            [men_poly([-0.3, 0.0, 0, -0.42, 0.3, 0.0, -0.3, 0.0]), men_line(-0.45, 0.35, 0.45, 0.35)]),
        __men_trait("guardian",  "Guardian",   "aptitude", 10,
            [men_poly([-0.35, -0.4, 0.35, -0.4, 0.35, 0.05, 0, 0.45, -0.35, 0.05, -0.35, -0.4]),
             men_line(-0.35, -0.2, 0.35, -0.2)]),
        __men_trait("forager",   "Forager",    "aptitude", 9,
            [men_line(0, 0.45, 0, -0.05),
             men_circle(-0.16, -0.22, 0.09), men_circle(0.14, -0.26, 0.09), men_circle(0, -0.44, 0.09)]),
        __men_trait("scout",     "Scout",      "aptitude", 9,
            [men_poly([-0.45, 0, 0, -0.22, 0.45, 0, 0, 0.22, -0.45, 0]),
             men_line(-0.5, 0.32, 0.5, 0.32), men_circle(0, 0, 0.08)]),
        __men_trait("packheart", "Pack-heart", "aptitude", 8,
            [men_circle(-0.15, 0, 0.22), men_circle(0.15, 0, 0.22)]),
        __men_trait("swiftfoot", "Swift-foot", "aptitude", 9,
            [men_line(-0.45, -0.2, 0.05, -0.2), men_line(-0.3, 0, 0.2, 0), men_line(-0.45, 0.2, 0.05, 0.2)]),
        __men_trait("ironhide",  "Iron-hide",  "aptitude", 8,
            [men_line(-0.4, -0.14, 0.4, -0.14), men_line(-0.4, 0.14, 0.4, 0.14),
             men_poly([-0.25, -0.14, -0.15, 0.14, 0.0, -0.14, 0.10, 0.14, 0.25, -0.14])]),
        __men_trait("keennose",  "Keen-nose",  "aptitude", 7,
            [men_spiral(0, 0, 0.06, 0.44, 0, 720)]),
        __men_trait("nighteye",  "Night-eye",  "aptitude", 7,
            [men_arc(0, 0, 0.40, 60, 300), men_line(0.28, -0.28, 0.48, -0.48)]),
        __men_trait("deeplung",  "Deep-lung",  "aptitude", 6,
            [men_poly(__men_wave(-0.45, 0.45, -0.12, 0.10, 1)), men_poly(__men_wave(-0.45, 0.45, 0.18, 0.10, 1))]),
        __men_trait("stonegrip", "Stone-grip", "aptitude", 6,
            [men_poly([-0.3, -0.4, 0, 0.1, 0.3, -0.4]), men_line(0, -0.45, 0, 0.1),
             men_poly(__men_ngon(0, 0.32, 0.12, 4, 45))]),
        __men_trait("skyborn",   "Sky-born",   "aptitude", 6,
            [men_arc(0, 0.15, 0.44, 200, 340), men_line(-0.2, 0.36, 0.2, 0.36)]),
    ];
    // <<< MIRROR TRAITS
    return _tbl;
}

// ── THE 8 BLOODLINE TINCTURES ────────────────────────────────────────────────────────────────
// Palette by ROLE (field / charge / accent / glow), never per-emblem hand colouring. Adding a
// ninth bloodline is fourteen numbers.

function men_tincture_table() {
    static _tbl =
    // >>> MIRROR TINCTURES
    [
        __men_tincture("ashen",   "Ashen",   0.00,  70,  74,  82,  188, 192, 200,  226, 220, 204,    0,   0,   0),
        __men_tincture("ember",   "Ember",   0.35,  66,  40,  30,  198, 140,  72,  255, 140,  60,  255, 120,  40),
        __men_tincture("frost",   "Frost",   0.30,  52,  66,  84,  224, 238, 248,  120, 200, 235,  140, 200, 255),
        __men_tincture("verdant", "Verdant", 0.25,  44,  66,  44,  150, 180, 140,  170, 220,  90,  120, 200,  90),
        __men_tincture("regal",   "Regal",   0.40,  56,  38,  80,  228, 186,  90,  240, 230, 205,  240, 200, 110),
        __men_tincture("umbral",  "Umbral",  0.30,  28,  24,  36,  120,  95, 160,  210,  90, 200,  150,  70, 180),
        __men_tincture("tidal",   "Tidal",   0.30,  24,  52,  70,  210, 232, 235,   90, 210, 205,   80, 190, 210),
        __men_tincture("dawn",    "Dawn",    0.35, 120,  62,  70,  240, 180, 100,  248, 225, 170,  255, 190, 130),
    ];
    // <<< MIRROR TINCTURES
    return _tbl;
}

// ── THE 6 FIELD SHAPES ───────────────────────────────────────────────────────────────────────
// The emblem ground. A dynasty reads as a dynasty because the field follows the eldest line.

function men_field_table() {
    static _tbl =
    // >>> MIRROR FIELDS
    [
        __men_field("shield", "Shield",
            [men_poly([-0.72, -0.85, 0.72, -0.85, 0.72, 0.05, 0.0, 0.85, -0.72, 0.05, -0.72, -0.85])]),
        __men_field("roundel", "Roundel",
            [men_circle(0, 0, 0.85), men_circle(0, 0, 0.74)]),
        __men_field("lozenge", "Lozenge",
            [men_poly([0, -0.88, 0.66, 0, 0, 0.88, -0.66, 0, 0, -0.88])]),
        __men_field("banner", "Banner",
            [men_poly([-0.62, -0.85, 0.62, -0.85, 0.62, 0.55, 0.31, 0.85, 0.0, 0.55,
                       -0.31, 0.85, -0.62, 0.55, -0.62, -0.85])]),
        __men_field("totem", "Totem",
            [men_arc(0, -0.45, 0.55, 180, 360),
             men_line(-0.55, -0.45, -0.55, 0.85),
             men_line(0.55, -0.45, 0.55, 0.85),
             men_line(-0.55, 0.85, 0.55, 0.85)]),
        __men_field("knot", "Knot",
            [men_circle(0, 0, 0.80),
             men_arc(0, -0.80, 0.28, 20, 160),
             men_arc(0.80, 0, 0.28, 110, 250),
             men_arc(0, 0.80, 0.28, 200, 340),
             men_arc(-0.80, 0, 0.28, 290, 430)]),
    ];
    // <<< MIRROR FIELDS
    return _tbl;
}

// ── THE 8 MUTATION ACCENTS ───────────────────────────────────────────────────────────────────
// Rolled per birth from the birth seed; placed at the chief centre. Siblings from the same
// parents usually differ here (measured, not guaranteed - see sim_mirror's sibling assertion).

function men_accent_table() {
    static _tbl =
    // >>> MIRROR ACCENTS
    [
        __men_accent("star",    "Star",     [men_poly(__men_star(0, 0, 0.5, 0.15, 4, -90))]),
        __men_accent("notch",   "Notch",    [men_poly([-0.15, -0.5, 0, -0.26, 0.15, -0.5])]),
        __men_accent("halo",    "Halo",     [men_arc(0, -0.12, 0.42, 200, 340)]),
        __men_accent("twindot", "Twin-dot", [men_circle(-0.14, 0, 0.10), men_circle(0.14, 0, 0.10)]),
        __men_accent("bar",     "Bar",      [men_line(-0.35, 0, 0.35, 0)]),
        __men_accent("sprout",  "Sprout",   [men_line(0, 0.4, 0, -0.15), men_poly([0, -0.15, 0.28, -0.35, 0.05, -0.05])]),
        __men_accent("spark",   "Spark",    [men_poly([0.1, -0.5, -0.12, -0.05, 0.12, -0.05, -0.1, 0.5])]),
        __men_accent("void",    "Void",     [men_circle(0, 0, 0.22)]),
    ];
    // <<< MIRROR ACCENTS
    return _tbl;
}

/// Bundle the default corpus. Buyers who register content build their own tables struct and
/// pass it everywhere the default would go - nothing below reads the statics directly.
function men_tables_default() {
    return {
        species:   men_species_table(),
        traits:    men_trait_table(),
        tinctures: men_tincture_table(),
        fields:    men_field_table(),
        accents:   men_accent_table(),
    };
}

/// Index of a species by string id, or -1.
function men_species_find(_tables, _id) {
    var _n = array_length(_tables.species);
    for (var _i = 0; _i < _n; _i++) {
        if (_tables.species[_i].id == _id) { return _i; }
    }
    return -1;
}

/// Index of a trait by string id, or -1.
function men_trait_find(_tables, _id) {
    var _n = array_length(_tables.traits);
    for (var _i = 0; _i < _n; _i++) {
        if (_tables.traits[_i].id == _id) { return _i; }
    }
    return -1;
}

// ── THE DETERMINISTIC STREAM ─────────────────────────────────────────────────────────────────
// xorshift32 over a seed. NEVER random(): the same lineage yields the same companion on every
// machine, so companions persist in a save as a tree of {seed} plus a version and re-derive
// losslessly on load. Chosen over a multiplicative hash deliberately - shifts and xors stay
// exact in GML's number model AND in the JS mirror's, so the two streams cannot diverge on
// precision.

/// Make a rng state from a seed. Mixed so that adjacent small seeds decorrelate.
function __men_rng(_seed) {
    var _x = (floor(abs(_seed))) & 0xFFFFFFFF;
    _x = (_x ^ 0x9E3779B9) & 0xFFFFFFFF;
    if (_x == 0) { _x = 0x1F123BB5; }
    var _r = { s: _x };
    // three warm-up steps: seeds 1,2,3 must not produce near-identical first draws
    __men_rng_next(_r); __men_rng_next(_r); __men_rng_next(_r);
    return _r;
}

/// Advance the stream, return an integer in [0, 2^32).
function __men_rng_next(_r) {
    var _x = _r.s;
    _x = (_x ^ (_x << 13)) & 0xFFFFFFFF;
    _x = _x ^ (_x >> 17);
    _x = (_x ^ (_x << 5)) & 0xFFFFFFFF;
    _r.s = _x;
    return _x;
}

/// Integer in [0, n).
function __men_rng_range(_r, _n) {
    return __men_rng_next(_r) % _n;
}

/// Weighted index over an array of structs carrying `w`. `_live` marks which entries are still
/// eligible (trait picks are WITHOUT replacement - a duplicate trait on one companion is
/// forbidden).
function __men_rng_weighted(_r, _arr, _live) {
    var _total = 0;
    var _n = array_length(_arr);
    for (var _i = 0; _i < _n; _i++) {
        if (_live[_i]) { _total += _arr[_i].w; }
    }
    var _pick = __men_rng_range(_r, _total);
    for (var _i = 0; _i < _n; _i++) {
        if (!_live[_i]) { continue; }
        _pick -= _arr[_i].w;
        if (_pick < 0) { return _i; }
    }
    return _n - 1;   // unreachable when weights are positive; kept as a guard
}

// ── FOUNDERS AND BREEDING ────────────────────────────────────────────────────────────────────

/// Pick one temperament and one aptitude, weighted, from the trait table. `_bias` nudges the
/// weights by the species' disposition: strong species lean fierce/iron-hide, wise ones lean
/// cunning/scout, warm ones lean loyal/pack-heart. The nudge is a multiplier, never a mask -
/// any trait can appear on any species.
function __men_pick_traits(_r, _tables, _sp) {
    var _tr = _tables.traits;
    var _n = array_length(_tr);
    var _live = array_create(_n, true);

    // disposition bias: build a temporary weighted view without mutating the corpus
    var _view = array_create(_n, 0);
    for (var _i = 0; _i < _n; _i++) {
        var _w = _tr[_i].w;
        // str biases the "hard" traits, wit the "sharp" ones, hrt the "warm" ones
        var _k = _tr[_i].id;
        if (_k == "fierce" || _k == "ironhide" || _k == "stonegrip" || _k == "hunter")   { _w += _sp.str; }
        if (_k == "cunning" || _k == "scout" || _k == "keennose" || _k == "nighteye")    { _w += _sp.wit; }
        if (_k == "loyal" || _k == "gentle" || _k == "packheart" || _k == "guardian")    { _w += _sp.hrt; }
        _view[_i] = { w: _w, kind: _tr[_i].kind };
    }

    // one temperament
    for (var _i = 0; _i < _n; _i++) { _live[_i] = (_view[_i].kind == "temperament"); }
    var _t0 = __men_rng_weighted(_r, _view, _live);
    // one aptitude
    for (var _i = 0; _i < _n; _i++) { _live[_i] = (_view[_i].kind == "aptitude"); }
    var _t1 = __men_rng_weighted(_r, _view, _live);
    return [_t0, _t1];
}

/// A founder companion (generation 0), wholly derived from one seed. Order is fixed and
/// documented because it IS the save format: species -> tincture -> field -> traits -> accent.
function men_founder(_seed, _tables) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_tables)) return undefined; if (!is_numeric(_seed)) _seed = 0;
    var _r = __men_rng(_seed);
    var _species  = __men_rng_range(_r, array_length(_tables.species));
    var _tincture = __men_rng_range(_r, array_length(_tables.tinctures));
    var _field    = __men_rng_range(_r, array_length(_tables.fields));
    var _traits   = __men_pick_traits(_r, _tables, _tables.species[_species]);
    var _accent   = __men_rng_range(_r, array_length(_tables.accents));
    return { seed: _seed, gen: 0, species: _species, tincture: _tincture, field: _field,
             traits: _traits, accent: _accent, sire: undefined, dam: undefined };
}

/// Breed two companions. Deterministic in (sire, dam, seed). Order fixed: species side ->
/// trait picks -> accent. The tincture and field follow the ELDEST line (the parent of greater
/// generation; tie goes to the sire) - that continuity is what makes a dynasty's emblems read
/// as one house across a whole playthrough.
function men_breed(_sire, _dam, _seed, _tables) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_sire) || !is_struct(_dam) || !is_struct(_tables)) return undefined; if (!is_numeric(_seed)) _seed = 0;
    var _r = __men_rng(_seed);

    var _species = (__men_rng_range(_r, 2) == 0) ? _sire.species : _dam.species;
    var _eldest  = (_sire.gen >= _dam.gen) ? _sire : _dam;
    var _gen     = max(_sire.gen, _dam.gen) + 1;

    // traits: two picks. Each pick is 3-in-4 from the parents' pooled traits (weighted by the
    // corpus weights), 1-in-4 a fresh roll from the whole table - the mutation that keeps a
    // long dynasty from converging. No duplicates.
    var _pool = [];
    for (var _i = 0; _i < array_length(_sire.traits); _i++) { array_push(_pool, _sire.traits[_i]); }
    for (var _i = 0; _i < array_length(_dam.traits); _i++) {
        var _t = _dam.traits[_i];
        var _dup = false;
        for (var _j = 0; _j < array_length(_pool); _j++) { if (_pool[_j] == _t) { _dup = true; break; } }
        if (!_dup) { array_push(_pool, _t); }
    }
    var _traits = [];
    var _tr = _tables.traits;
    var _n_tr = array_length(_tr);
    repeat (2) {
        var _pick = -1;
        if (__men_rng_range(_r, 4) < 3 && array_length(_pool) > 0) {
            _pick = _pool[__men_rng_range(_r, array_length(_pool))];
        } else {
            _pick = __men_rng_range(_r, _n_tr);
        }
        var _dup = false;
        for (var _j = 0; _j < array_length(_traits); _j++) { if (_traits[_j] == _pick) { _dup = true; break; } }
        if (!_dup) { array_push(_traits, _pick); }
    }
    // guarantee two distinct traits: if the second collided, take the next free index
    if (array_length(_traits) < 2) {
        var _alt = (_traits[0] + 1 + __men_rng_range(_r, _n_tr - 1)) % _n_tr;
        array_push(_traits, _alt);
    }

    var _accent = __men_rng_range(_r, array_length(_tables.accents));

    return { seed: _seed, gen: _gen, species: _species,
             tincture: _eldest.tincture, field: _eldest.field,
             traits: _traits, accent: _accent, sire: _sire, dam: _dam };
}

/// Generations behind this companion. A founder is 0.
function men_lineage_depth(_comp) {
    return _comp.gen;
}

// ── PERSISTENCE - the lineage tree of seeds IS the save format ───────────────────────────────

/// Pack a companion to pure data: seeds and structure only, nothing derived. A founder packs to
/// { v, s }; a bred companion to { v, s, a, b } where a/b are the packed sire/dam.
function men_lineage_pack(_comp) {
    if (_comp.gen == 0 || is_undefined(_comp.sire)) {
        return { v: MEN_VERSION, s: _comp.seed };
    }
    return { v: MEN_VERSION, s: _comp.seed,
             a: men_lineage_pack(_comp.sire), b: men_lineage_pack(_comp.dam) };
}

/// Rebuild the identical companion from packed data. Derivation is the load path, so a save
/// can never disagree with the generator - there is nothing else stored to disagree WITH.
function men_lineage_unpack(_packed, _tables) {
    if (!variable_struct_exists(_packed, "a")) {
        return men_founder(_packed.s, _tables);
    }
    var _sire = men_lineage_unpack(_packed.a, _tables);
    var _dam  = men_lineage_unpack(_packed.b, _tables);
    return men_breed(_sire, _dam, _packed.s, _tables);
}

// ── THE BOND CURVE ───────────────────────────────────────────────────────────────────────────

/// Level thresholds: 0, 50, 140, 280, 480 XP. Returns { level, progress, t } where progress is
/// 0..1 toward the next level and t is overall ring closure 0..1 across all levels.
function men_bond_level(_xp) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_numeric(_xp)) _xp = 0;
    static _thr = [0, 50, 140, 280, 480];   // static: this runs per frame under the bond ring
    var _lv = 0;
    for (var _i = MEN_BOND_MAX - 1; _i >= 0; _i--) {
        if (_xp >= _thr[_i]) { _lv = _i; break; }
    }
    var _prog = 1.0;
    if (_lv < MEN_BOND_MAX - 1) {
        _prog = clamp((_xp - _thr[_lv]) / (_thr[_lv + 1] - _thr[_lv]), 0, 1);
    }
    var _t = clamp((_lv + _prog) / (MEN_BOND_MAX - 1), 0, 1);
    return { level: _lv, progress: _prog, t: _t };
}

// ── EMBLEM COMPOSITION ───────────────────────────────────────────────────────────────────────

/// The eldest ancestor's species one generation up a line, or the companion's own species when
/// the line ends. Used to fill the third and fourth quarters.
function __men_line_species(_comp) {
    if (is_undefined(_comp.sire)) { return _comp.species; }
    var _eld = (_comp.sire.gen >= _comp.dam.gen) ? _comp.sire : _comp.dam;
    return _eld.species;
}

/// Compose a companion's emblem into a draw plan. Pure data out:
/// {
///   field, tincture, accent   - indices into the tables
///   quarter                   - 1, 2 or 4 panels
///   panels                    - array of { species } in panel order
///                               (1: centre; 2: dexter, sinister; 4: clockwise from chief-dexter)
///   ring_t                    - 0..1 bond ring closure (from _bond_t)
///   gen                       - generation, for the renderer's bordure weight
/// }
function men_emblem_compose(_comp, _tables, _bond_t) {
    // GUARD (guard pass 2026-11-03): refuse a wrong-typed argument with a chosen value.
    if (!is_struct(_comp) || !is_struct(_tables)) return undefined; if (!is_numeric(_bond_t)) _bond_t = 0;
    var _panels = [];
    var _quarter = 1;

    if (_comp.gen == 0 || is_undefined(_comp.sire)) {
        array_push(_panels, { species: _comp.species });
    } else if (_comp.gen == 1) {
        _quarter = 2;
        array_push(_panels, { species: _comp.sire.species });   // dexter
        array_push(_panels, { species: _comp.dam.species });    // sinister
    } else {
        _quarter = 4;
        array_push(_panels, { species: _comp.sire.species });            // chief dexter
        array_push(_panels, { species: _comp.dam.species });             // chief sinister
        array_push(_panels, { species: __men_line_species(_comp.dam) }); // base sinister
        array_push(_panels, { species: __men_line_species(_comp.sire) });// base dexter
    }

    return {
        field:    _comp.field,
        tincture: _comp.tincture,
        accent:   _comp.accent,
        quarter:  _quarter,
        panels:   _panels,
        ring_t:   clamp(_bond_t, 0, 1),
        gen:      _comp.gen,
    };
}
