/// MENAGERIE demo - Step.  DEMO SCAFFOLDING, NOT PRODUCT.

// Deterministic demo clock. A fixed increment rather than delta_time so an unattended capture
// produces stable frames on a slow machine and a fast one.
if (!still_mode) { sim_t += 1 / 60; }
frame_count++;

// Advance the product's own animation (the one delta_time consumer, inside menagerie_bind).
men_hatch_step(hatch);

// HATCHERY page loops its reveal so the GIF has no dead frames. men_hatch_step already HOLDS
// the completed emblem for MEN_HATCH_HOLD seconds (the Athanor lesson lives in the bind layer
// now, not the demo) - when the hold expires, advance to the next curated pair.
if (page == 1 && !hatch.active && !still_mode) {
    // remember the finished offspring, newest first, capped at 4 (the hatchery sidebar strip)
    array_insert(hatch_history, 0, men_emblem_compose(hatch.comp, tables, 1));
    if (array_length(hatch_history) > 4) { array_pop(hatch_history); }
    hatch_ix = (hatch_ix + 1) % array_length(hatch_seq);
    var _pair = hatch_seq[hatch_ix];
    men_hatch_breed(hatch, registry, _pair.sire, _pair.dam, _pair.seed);
    sire_plan  = men_emblem_compose(_pair.sire, tables, 1);
    dam_plan   = men_emblem_compose(_pair.dam, tables, 1);
    hatch_plan = men_emblem_compose(hatch.comp, tables, 1);
}

// --- page keys -------------------------------------------------------------------------------
if (keyboard_check_pressed(ord("1"))) { page = 0; }
if (keyboard_check_pressed(ord("2"))) { page = 1; }
if (keyboard_check_pressed(ord("3"))) { page = 2; }
if (keyboard_check_pressed(ord("4"))) { page = 3; }
if (keyboard_check_pressed(ord("5"))) { page = 4; }
if (keyboard_check_pressed(vk_escape)) { game_end(); }

// Unattended capture: exit cleanly after N frames.
if (quit_after > 0 && frame_count >= quit_after) { game_end(); }
