/// MENAGERIE demo - Draw GUI.  DEMO SCAFFOLDING, NOT PRODUCT.
/// Every mark on screen is drawn by menagerie_render from menagerie_core data. No sprites anywhere.

var _W = display_get_gui_width();
var _H = display_get_gui_height();
var _th = theme;

// --- background + chrome (custom, deliberately nothing like stock GameMaker) -----------------
draw_set_colour(men_colour(_th.bg));
draw_set_alpha(1);
draw_rectangle(0, 0, _W, _H, false);

draw_set_font(fnt_menagerie_title);
draw_set_colour(men_colour(_th.text));
draw_set_halign(fa_left);
draw_set_valign(fa_top);

var _titles = ["THE PADDOCK", "THE HATCHERY", "LINEAGE", "THE CORPUS", "BLOODLINES"];
var _subs = [
    "A whole roster on one wall - founders through generation 3. Every emblem drawn from its lineage. No two alike, no PNG anywhere.",
    "Two parents in, a new emblem out: the field fades, the outline strokes, charges stamp, the accent pops, the bond ring sweeps.",
    "One dynasty as a tree. The field and tincture follow the eldest line; quartering deepens each generation.",
    "24 species marks, 20 trait glyphs, 8 mutation accents - every one hand-authored strokes, legible at 20 px.",
    "The same companion under all 8 bloodline tinctures. Fourteen numbers restyle every pixel - no art was re-authored.",
];
draw_text(_th.pad, _th.pad - 6, _titles[page]);

draw_set_font(fnt_menagerie);
draw_set_colour(men_colour(_th.text_dim));
draw_text(_th.pad, _th.pad + 30, _subs[page]);

draw_set_colour(men_colour(_th.rule));
draw_line(_th.pad, _th.pad + 58, _W - _th.pad, _th.pad + 58);

var _top = _th.pad + 82;

switch (page) {

// -- 0 - PADDOCK: the volume shot --------------------------------------------------------------
case 0: {
    var _n    = array_length(roster);
    var _cols = 8;
    var _rows = 3;
    var _cw   = (_W - _th.pad * 2) / _cols;
    // Reserve the footer strip: each cell carries TWO label lines under the emblem, and without
    // this the bottom row's "gen N - <tincture>" line overprinted "1-5 pages - esc quits".
    // Measured by capturing the page and looking at it, not by reasoning about the numbers.
    var _chh  = (_H - _top - _th.pad * 0.6 - 34) / _rows;
    var _es   = min(_cw, _chh) * 0.62;
    for (var _i = 0; _i < min(_n, _cols * _rows); _i++) {
        var _c = _i % _cols;
        var _r = _i div _cols;
        var _ex = _th.pad + _cw * (_c + 0.5);
        var _ey = _top + _chh * (_r + 0.42);
        men_draw_emblem(roster_plans[_i], tables, _ex, _ey, _es, sim_t, 1, 1);
        draw_set_halign(fa_center);
        draw_set_colour(men_colour(_th.text));
        draw_text(_ex, _ey + _chh * 0.34, roster[_i].name);
        draw_set_colour(men_colour(_th.text_dim));
        draw_text(_ex, _ey + _chh * 0.34 + 22,
            "gen " + string(roster[_i].comp.gen) + " - " + tables.tinctures[roster[_i].comp.tincture].name);
        draw_set_halign(fa_left);
    }
} break;

// -- 1 - HATCHERY: the money shot --------------------------------------------------------------
case 1: {
    var _cy = _top + (_H - _th.pad - _top) * 0.40;
    var _pair = hatch_seq[hatch_ix];

    // parents, finished, either side
    men_draw_emblem(sire_plan, tables, _W * 0.17, _cy, 235, sim_t, 1, 1);
    men_draw_emblem(dam_plan,  tables, _W * 0.83, _cy, 235, sim_t, 1, 1);
    draw_set_halign(fa_center);
    draw_set_colour(men_colour(_th.text_dim));
    draw_text(_W * 0.17, _cy + 140, men_name_for(_pair.sire) + "  (sire)");
    draw_text(_W * 0.83, _cy + 140, men_name_for(_pair.dam) + "  (dam)");

    // descent lines from each parent toward the offspring, drawn simply and always
    draw_set_colour(men_colour(_th.rule));
    draw_line_width(_W * 0.17 + 130, _cy, _W * 0.5 - 205, _cy, 2);
    draw_line_width(_W * 0.83 - 130, _cy, _W * 0.5 + 205, _cy, 2);

    // the offspring, revealing (plan cached at breed time - composing per frame allocates)
    men_draw_emblem(hatch_plan, tables, _W * 0.5, _cy, 385, sim_t, 1, hatch.t);

    // the readout arrives WITH the reveal, not before it - a fully-described companion beside
    // an empty field read as broken (the Panoply lesson, kept)
    var _pa = clamp((hatch.t - 0.15) / 0.55, 0, 1);
    var _py = _H - _th.pad - 150;
    men_draw_panel(_th.pad, _py, _W - _th.pad, _H - _th.pad, _th.panel, _th.rule, 1);
    draw_set_alpha(_pa);
    var _c  = hatch.comp;
    var _sp = tables.species[_c.species];
    var _tn = tables.tinctures[_c.tincture];
    var _lx = _th.pad + 24;
    var _ly = _py + 16;

    draw_set_halign(fa_left);
    draw_set_font(fnt_menagerie_title);
    draw_set_colour(men_colour(_tn.accent));
    draw_text(_lx, _ly, men_name_for(_c));
    draw_set_font(fnt_menagerie);
    draw_set_colour(men_colour(_th.text_dim));
    draw_text(_lx + 300, _ly + 6, _sp.name + " - " + _tn.name + " line - generation " + string(_c.gen)
        + " - seed " + string(_c.seed));
    _ly += 46;

    // inherited traits, each with its glyph
    var _style = men_style(tables, _c.tincture);
    for (var _i = 0; _i < array_length(_c.traits); _i++) {
        var _tr = tables.traits[_c.traits[_i]];
        men_draw_glyph(_tr, _lx + 14 + _i * 250, _ly + 12, 28, _style, _pa, 1);
        draw_set_colour(men_colour(_th.text));
        draw_text(_lx + 38 + _i * 250, _ly, _tr.name);
        draw_set_colour(men_colour(_th.text_dim));
        draw_text(_lx + 38 + _i * 250, _ly + 22, _tr.kind);
    }
    // the accent that makes this birth ITSELF
    var _ac = tables.accents[_c.accent];
    draw_set_colour(men_colour(_th.text_dim));
    draw_text(_lx + 540, _ly, "birth accent:");
    men_draw_glyph(_ac, _lx + 668, _ly + 12, 26, _style, _pa, 1);
    draw_text(_lx + 700, _ly, _ac.name);

    // previous offspring, newest first - every one a different emblem, drawn from its lineage.
    // History does NOT fade with the new reveal - restore full alpha first.
    draw_set_alpha(1);
    if (array_length(hatch_history) > 0) {
        var _hx = _W - _th.pad - 60;
        draw_set_halign(fa_right);
        draw_set_colour(men_colour(_th.text_dim));
        draw_text(_hx + 40, _py - 26, "previous births - a lineage always draws the same emblem");
        draw_set_halign(fa_left);
        for (var _i = 0; _i < array_length(hatch_history); _i++) {
            men_draw_emblem(hatch_history[_i], tables, _hx - _i * 96, _py - 84, 84,
                sim_t, 1 - _i * 0.16, 1);
        }
    }
} break;

// -- 2 - LINEAGE: the dynasty tree -------------------------------------------------------------
case 2: {
    var _fy = _top + 90;
    var _gy = _top + (_H - _th.pad - _top) * 0.47;
    var _ry = _H - _th.pad - 130;
    var _fx = [_W * 0.155, _W * 0.385, _W * 0.615, _W * 0.845];
    var _gx = [_W * 0.27, _W * 0.73];
    var _rx = _W * 0.5;

    // connectors first, under the emblems
    draw_set_colour(men_colour(_th.rule));
    // Start the descent BELOW the founder caption, not at the emblem's edge. The founder emblems
    // are 118 px centred on _fy (so they end at _fy+59) and their caption sits at _fy+68 — a
    // connector leaving at _fy+60 travels down-and-inward straight THROUGH the caption text.
    // Caught by opening the shipped store image and reading it, not by any gate.
    for (var _i = 0; _i < 2; _i++) {
        draw_line_width(_fx[_i * 2], _fy + 94, _gx[_i], _gy - 78, 2);
        draw_line_width(_fx[_i * 2 + 1], _fy + 94, _gx[_i], _gy - 78, 2);
    }
    draw_line_width(_gx[0], _gy + 78, _rx, _ry - 100, 2);
    draw_line_width(_gx[1], _gy + 78, _rx, _ry - 100, 2);

    draw_set_halign(fa_center);
    for (var _i = 0; _i < 4; _i++) {
        men_draw_emblem(lineage_plans.f[_i], tables, _fx[_i], _fy, 118, sim_t, 1, 1);
        draw_set_colour(men_colour(_th.text_dim));
        draw_text(_fx[_i], _fy + 68, men_name_for(founders[_i]) + " - founder");
    }
    for (var _i = 0; _i < 2; _i++) {
        men_draw_emblem(lineage_plans.g1[_i], tables, _gx[_i], _gy, 150, sim_t, 1, 1);
        draw_set_colour(men_colour(_th.text_dim));
        draw_text(_gx[_i], _gy + 84, men_name_for(gen1[_i]) + " - gen 1, per-pale");
    }
    men_draw_emblem(lineage_plans.g2, tables, _rx, _ry, 195, sim_t, 1, 1);
    draw_set_colour(men_colour(_th.text));
    draw_text(_rx, _ry + 106, men_name_for(gen2[0]) + " - gen 2, quartered");
    draw_set_halign(fa_left);
} break;

// -- 3 - CORPUS: the moat, named ---------------------------------------------------------------
case 3: {
    // species: 8 x 3
    var _cols = 8;
    var _cw   = (_W - _th.pad * 2) / _cols;
    var _band = (_H - _top - _th.pad) * 0.62;
    var _chh  = _band / 3;
    var _size = min(_cw, _chh) * 0.66;
    // Tincture cycles PER MARK, not per row. Three rows in three tinctures showed 3 of the 8
    // bloodlines and left the sheet reading as one flat colour; cycling all 8 puts the whole
    // palette on the page that exists to show the whole corpus. Measured effect on the shipped
    // store image: colours 403 -> see Devlog, and the marks now carry the product's real range.
    for (var _i = 0; _i < 24; _i++) {
        var _c = _i % _cols;
        var _r = _i div _cols;
        var _gx = _th.pad + _cw * (_c + 0.5);
        var _gy = _top + _chh * (_r + 0.40);
        men_draw_glyph(tables.species[_i], _gx, _gy, _size,
            men_style(tables, _i % array_length(tables.tinctures)), 1, 1);
        draw_set_halign(fa_center);
        draw_set_colour(men_colour(_th.text_dim));
        draw_text(_gx, _gy + _chh * 0.36, tables.species[_i].name);
        draw_set_halign(fa_left);
    }
    // traits: 20 across one strip
    var _ty = _top + _band + 30;
    draw_set_colour(men_colour(_th.text));
    draw_text(_th.pad, _ty - 24, "20 trait glyphs");
    var _tw = (_W - _th.pad * 2) / 20;
    for (var _i = 0; _i < 20; _i++) {
        men_draw_glyph(tables.traits[_i], _th.pad + _tw * (_i + 0.5), _ty + 22, _tw * 0.70,
            men_style(tables, (_i + 3) % array_length(tables.tinctures)), 1, 1);
    }
    // accents: 8 across a second strip
    var _ay = _ty + 74;
    draw_set_colour(men_colour(_th.text));
    draw_text(_th.pad, _ay - 12, "8 mutation accents");
    var _aw = (_W - _th.pad * 2) / 8;
    for (var _i = 0; _i < 8; _i++) {
        var _ax = _th.pad + _aw * (_i + 0.5);
        men_draw_glyph(tables.accents[_i], _ax, _ay + 30, 42, men_style(tables, _i), 1, 1);
        draw_set_halign(fa_center);
        draw_set_colour(men_colour(_th.text_dim));
        draw_text(_ax, _ay + 52, tables.accents[_i].name);
        draw_set_halign(fa_left);
    }
} break;

// -- 4 - BLOODLINES: one companion, eight houses -----------------------------------------------
case 4: {
    var _cols = 4;
    var _rows = 2;
    var _cw   = (_W - _th.pad * 2) / _cols;
    var _chh  = (_H - _top - _th.pad * 0.6) / _rows;
    var _es   = min(_cw, _chh) * 0.66;
    for (var _i = 0; _i < 8; _i++) {
        var _c = _i % _cols;
        var _r = _i div _cols;
        var _ex = _th.pad + _cw * (_c + 0.5);
        var _ey = _top + _chh * (_r + 0.42);
        men_draw_emblem(blood_plans[_i], tables, _ex, _ey, _es, sim_t, 1, 1);
        var _tn = tables.tinctures[_i];
        draw_set_halign(fa_center);
        draw_set_colour(men_colour(_tn.accent));
        draw_text(_ex, _ey + _chh * 0.36, _tn.name);
        draw_set_halign(fa_left);
    }
} break;

}

// --- footer ----------------------------------------------------------------------------------
draw_set_colour(men_colour(_th.text_dim));
draw_text(_th.pad, _H - 26, "1-5 pages - esc quits");
draw_set_halign(fa_right);
draw_text(_W - _th.pad - 70, _H - 26, "NO SPRITES / NO TEXTURE PAGES - every mark drawn from lineage data");
draw_set_halign(fa_left);

// --- blend-state leak probe ------------------------------------------------------------------
// Drawn LAST and stock-plain on purpose. If menagerie_render ever leaked bm_add or an alpha,
// this bar renders wrong - it is the visual assertion for the restore-state rule, and it is the
// kind of bug that only shows up in a buyer's project.
draw_set_colour(c_white);
draw_set_alpha(1);
draw_rectangle(_W - _th.pad - 60, _H - 18, _W - _th.pad, _H - 10, false);
