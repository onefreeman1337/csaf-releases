/// MENAGERIE demo - Create.
/// ============================================================================================
/// DEMO SCAFFOLDING, NOT PRODUCT. Everything in obj_menagerie_demo exists so the product can be
/// seen: five showcase pages, deterministic motion (every position is a pure function of the
/// demo clock), and a command-line parser so unattended captures are reproducible. Copy the
/// men_* CALLS into your game; delete the rest.
///
/// Pages (keys 1-5, or launch with -page N):
///   0 PADDOCK    the volume shot: a whole roster of emblems on one wall, founders through
///                generation 3, every one drawn from its lineage - no two alike
///   1 HATCHERY   the money shot: two parents in, and the offspring's emblem DRAWS ITSELF -
///                field fades in, outline strokes, charges stamp, the accent pops, the ring
///                sweeps. Readout panel arrives with it.
///   2 LINEAGE    one dynasty as a tree: field and tincture follow the eldest line, quartering
///                deepens per generation
///   3 CORPUS     24 species marks, 20 trait glyphs and 8 mutation accents, named
///   4 BLOODLINES the same emblem under all 8 tinctures - six seed colours restyle everything
/// Other args: -still (freeze the demo clock for stills), -quit N (exit after N frames).
/// ============================================================================================

window_set_caption("Menagerie - companions, breeding & ancestry emblems for GameMaker");

// --- command line ---------------------------------------------------------------------------
page = 0;
still_mode = false;
quit_after = -1;
var _pc = parameter_count();
for (var _i = 1; _i < _pc; _i++) {
    var _p = parameter_string(_i);
    if (_p == "-page" && _i + 1 < _pc) { page = clamp(real(parameter_string(_i + 1)), 0, 4); _i++; }
    else if (_p == "-still") { still_mode = true; }
    else if (_p == "-quit" && _i + 1 < _pc) { quit_after = real(parameter_string(_i + 1)); _i++; }
}

frame_count = 0;
sim_t = 0;               // demo clock, seconds - every moving thing below is a function of it

// --- the product ----------------------------------------------------------------------------
// The whole integration surface for a buyer: a registry, a hatch, and draw calls.
registry = men_registry_create();
tables   = men_tables(registry);
theme    = men_theme();
hatch    = men_hatch_create();

/// Deterministic demo seed sequence - NOT part of the product, just reproducible captures.
function __demo_seed(_i) {
    return 20260817 + _i * 7777;
}

// --- FOUNDERS: curate 17 with distinct species (raw sequential seeds repeat species and the
// paddock wall reads samey - walk the seed space and keep the first founder per species).
//
// WHY 17 AND NOT A ROUND NUMBER: the paddock draws an 8 x 3 grid = 24 cells, and the roster is
// founders + 4 gen1 + 2 gen2 + 1 gen3. 17 + 7 = 24 fills the wall EXACTLY. At 12 it rendered 19
// emblems and left 5 empty cells in the bottom row - measured by capturing the page and looking
// at it. That is the volume shot, and a wall with a hole in it argues the opposite of volume.
founders = [];
var _seen_species = array_create(array_length(tables.species), false);
for (var _i = 0; _i < 600 && array_length(founders) < 17; _i++) {
    var _f = men_founder(__demo_seed(_i), tables);
    if (!_seen_species[_f.species]) {
        _seen_species[_f.species] = true;
        array_push(founders, _f);
    }
}
// belt+braces: if the walk somehow found fewer than 17 distinct species, top up sequentially
for (var _i = 0; array_length(founders) < 17; _i++) {
    array_push(founders, men_founder(__demo_seed(9000 + _i), tables));
}

// --- THE DYNASTY: founders breed into gen1, gen1 into gen2, gen2 into gen3. All pure data.
gen1 = [];
for (var _i = 0; _i < 4; _i++) {
    array_push(gen1, men_breed(founders[_i * 2], founders[_i * 2 + 1], __demo_seed(100 + _i), tables));
}
gen2 = [];
array_push(gen2, men_breed(gen1[0], gen1[1], __demo_seed(200), tables));
array_push(gen2, men_breed(gen1[2], gen1[3], __demo_seed(201), tables));
gen3 = men_breed(gen2[0], gen2[1], __demo_seed(300), tables);

// --- PADDOCK roster: founders + the dynasty, wrapped with names and staggered bond XP so the
// wall shows rings at every stage of closure. XP is a pure function of the index.
roster = [];
for (var _i = 0; _i < array_length(founders); _i++) { array_push(roster, men_companion_wrap(founders[_i], men_name_for(founders[_i]))); }
for (var _i = 0; _i < array_length(gen1); _i++) { array_push(roster, men_companion_wrap(gen1[_i], men_name_for(gen1[_i]))); }
for (var _i = 0; _i < array_length(gen2); _i++) { array_push(roster, men_companion_wrap(gen2[_i], men_name_for(gen2[_i]))); }
array_push(roster, men_companion_wrap(gen3, men_name_for(gen3)));
for (var _i = 0; _i < array_length(roster); _i++) {
    men_companion_award(roster[_i], (_i * 97) % 520);
}

// Pre-composed paddock plans (emblems are static at t=1; composing per frame would allocate).
roster_plans = [];
for (var _i = 0; _i < array_length(roster); _i++) {
    roster_plans[_i] = men_emblem_compose(roster[_i].comp, tables, men_companion_bond(roster[_i]).t);
}

// --- HATCHERY: a curated breeding sequence - parents chosen with DIFFERENT species and
// tinctures so every reveal visibly inherits from both sides.
hatch_seq = [];
array_push(hatch_seq, { sire: founders[0], dam: founders[5],  seed: __demo_seed(400) });
array_push(hatch_seq, { sire: founders[2], dam: founders[9],  seed: __demo_seed(401) });
array_push(hatch_seq, { sire: gen1[0],     dam: founders[7],  seed: __demo_seed(402) });
array_push(hatch_seq, { sire: gen1[1],     dam: gen1[2],      seed: __demo_seed(403) });
array_push(hatch_seq, { sire: gen2[0],     dam: founders[10], seed: __demo_seed(404) });
array_push(hatch_seq, { sire: gen2[1],     dam: gen1[3],      seed: __demo_seed(405) });
hatch_ix = 0;
hatch_history = [];   // plans of previous offspring, newest first, capped at 4
men_hatch_breed(hatch, registry, hatch_seq[0].sire, hatch_seq[0].dam, hatch_seq[0].seed);
// plans for the current pair + offspring (recomposed on advance in Step - never per frame)
sire_plan  = men_emblem_compose(hatch_seq[0].sire, tables, 1);
dam_plan   = men_emblem_compose(hatch_seq[0].dam, tables, 1);
hatch_plan = men_emblem_compose(hatch.comp, tables, 1);

// --- LINEAGE page: the tree of gen3 - four founders, two gen1, one gen2... shown as the
// three-generation ancestry of gen2[0] plus gen3 at the root for depth-4 quartering.
lineage_plans = {
    f: [men_emblem_compose(founders[0], tables, 1), men_emblem_compose(founders[1], tables, 1),
        men_emblem_compose(founders[2], tables, 1), men_emblem_compose(founders[3], tables, 1)],
    g1: [men_emblem_compose(gen1[0], tables, 1), men_emblem_compose(gen1[1], tables, 1)],
    g2: men_emblem_compose(gen2[0], tables, 1),
};

// --- BLOODLINES page: the same companion under all 8 tinctures. Variant companions share the
// whole lineage; only the tincture index differs, which is exactly the claim the page makes.
blood_plans = [];
for (var _i = 0; _i < array_length(tables.tinctures); _i++) {
    var _v = {
        seed: gen3.seed, gen: gen3.gen, species: gen3.species,
        tincture: _i, field: gen3.field,
        traits: gen3.traits, accent: gen3.accent, sire: gen3.sire, dam: gen3.dam,
    };
    blood_plans[_i] = men_emblem_compose(_v, tables, 0.8);
}
