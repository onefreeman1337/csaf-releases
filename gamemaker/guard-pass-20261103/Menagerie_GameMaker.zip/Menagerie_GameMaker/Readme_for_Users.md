# Menagerie — Companions, Breeding & Ancestry Emblems for GameMaker

**Version 1.0.1 · GameMaker 2024.x (legacy runtime) · pure GML, no native extension**

A complete companion system whose art is drawn by the product: **24 hand-authored species marks**,
**20 trait glyphs**, **8 mutation accents**, **6 field grounds** and **8 bloodline tinctures** — and
every companion's emblem is **composed from its own ancestry**, so breeding produces a picture that
did not exist before and can never be looked up in an atlas. No PNG, no sprite, no texture page
anywhere in the package.

---

## Why generated art

A companion system normally ships as logic plus a folder of creature portraits — and the portraits
are the part that never fits your game, never covers the creature the player just bred, and never
recolours. Menagerie has no portraits. Every mark is line-work stroked from primitives at runtime:

- **A bred companion gets its own emblem, for free.** The emblem is a pure function of the lineage:
  the field and tincture follow the eldest line, quartering deepens with each generation, each
  ancestral panel carries that ancestor's species mark, and one mutation accent is rolled at birth.
  Breed two companions and the offspring's emblem draws itself — from data the product has never
  seen before.
- **It recolours from data.** Eight bloodlines ship. Add a ninth by writing **fourteen numbers** and
  every emblem in your game restyles, because the palette is applied by ROLE (field / charge /
  accent / glow), never by hand-colouring each mark.
- **It scales without pixelation.** Draw the same emblem at 20 px on a roster row and at 385 px in a
  breeding reveal from one definition.

## Quick start

Three calls to have working companions, one more to draw:

```gml
// Create event
registry = men_registry_create();          // your content goes here; empty is fine
tables   = men_tables(registry);           // corpus + your additions, cached
hatch    = men_hatch_create();             // reveal animation state

// A founder from any seed — deterministic, never random()
var _comp = men_founder(20260817, tables);

// Step event — advances the reveal
men_hatch_step(hatch);
```

Draw an emblem anywhere:

```gml
// Compose once (NOT per frame — composing allocates), then draw every frame.
var _plan = men_emblem_compose(_comp, tables, men_bond_level(xp).t);
men_draw_emblem(_plan, tables, x, y, 240, current_time / 1000, 1, 1);
```

## Breeding

```gml
var _child = men_breed(sire, dam, seed, tables);
men_hatch_breed(hatch, registry, sire, dam, seed);   // same thing, with the reveal animation
```

The child's species comes from one parent or the other; its field and tincture follow the **eldest**
line, which is what makes a dynasty read as one house across a whole playthrough; its two traits are
drawn 3-in-4 from the parents' pooled traits and 1-in-4 fresh, which is the mutation that stops a
long dynasty converging; and its accent is rolled from the birth seed.

## Saving — the lineage tree of seeds IS the save format

```gml
var _data = men_companion_pack(wrapped);              // { v, name, xp, lin }
var _same = men_companion_unpack(registry, _data);    // rebuilt, identical
```

Founding and breeding are pure functions of seeds, so the tree of seeds **is** the companion.
Nothing derived is stored, so nothing derived can go stale, and a save cannot bloat: a
three-generation companion persists as seven integers and a version field.

**The compatibility contract is APPEND-ONLY.** Registered content appends after the shipped corpus,
so existing saves keep their identity. If you REORDER or REMOVE corpus entries between builds,
derived companions change — seeds index into these tables.

## Register your own content

```gml
men_registry_add_species(registry, __men_species("fox", "Fox", "beast", 7, 11, 8,
    [men_poly([-0.50, -0.26, -0.36, -0.62, -0.20, -0.30, -0.04, -0.62, 0.12, -0.26]),
     men_line(-0.42, -0.06, 0.58, 0.26),
     men_poly([-0.60, 0.42, -0.30, 0.22, -0.44, 0.52, -0.60, 0.42])],
    [-0.14, 0.02]));
```

A species is a name, a family, a three-number disposition block, a list of strokes in unit space
(`men_line`, `men_arc`, `men_circle`, `men_poly`, `men_spiral`) and optional accent points. It
founds, breeds and renders exactly like a shipped one. Traits and tinctures register the same way.

## The demo room

Open `rm_menagerie_demo` and press Play. Five pages, keys **1–5**:

| | Page | What it shows |
| --- | --- | --- |
| 1 | **The Paddock** | 24 companions on one wall, founders through generation 3 — no two alike |
| 2 | **The Hatchery** | two parents in, and the offspring's emblem draws itself |
| 3 | **Lineage** | one dynasty as a tree; quartering deepens each generation |
| 4 | **The Corpus** | all 24 species marks, 20 trait glyphs and 8 accents, named |
| 5 | **Bloodlines** | one identical companion under all 8 tinctures |

Everything in `obj_menagerie_demo` is demo scaffolding, commented as such. Copy the `men_*` calls
into your game and delete the rest.

## What ships

| File | What it is |
| --- | --- |
| `menagerie_core` | the pure generator — **zero engine calls**, so it can be reasoned about and mirrored |
| `menagerie_render` | the draw layer — one renderer for every mark in the product |
| `menagerie_bind` | the engine binding — clock, registry, reveal state, save/load |
| `menagerie_preset` | theme, naming book, and a copy-me registry example |

## Notes for integrators

- **Every global and macro is namespaced `men_` / `MEN_`.** GML's global namespace is flat and a
  collision in your project is a support ticket nobody can debug remotely.
- **Blend-state hygiene.** Every public draw saves and restores blend mode, colour, alpha and text
  alignment, so it is safe to call from anywhere in your draw event, in any order. The demo's
  bottom-right white bar is a deliberate leak probe: if it ever renders wrong, the renderer leaked.
- **`men_draw_emblem` and `men_draw_glyph` draw NO text.** Names and numbers are your UI, in your
  font.
- **Compose outside the frame loop.** `men_emblem_compose` allocates; the draw calls do not.
- **Never `random()`.** The stream is xorshift32 over the seed, so the same lineage yields the same
  companion and the same emblem on every machine and in every session.

## Verification, stated honestly

GML cannot be unit-tested outside the engine, so this product is verified three ways and none of
them is a claim about the others:

1. **The engine gate** — a real headless `Igor.exe` package build on runtime `2024.14.4.268`:
   exit 0, 0 errors, 0 warnings, 128 resources compiled.
2. **A numerical mirror** (`sim_mirror`) that EXTRACTS the shipped corpus tables and evaluates the
   real data — 37/37 assertions, including pairwise distinctness of all 24 species marks and all 20
   trait glyphs, unit-space containment, save round-trip identity, and distribution checks over
   20,000 three-generation breedings. The suite is proven to FIRE: a sabotage mode injects a
   duplicate mark and an out-of-space point and it drops to 35/37, naming both.
3. **The demo room, actually run**, and its frames looked at. This is the one that matters most
   here: a package build is a COMPILE, and it reported CLEAN while the demo crashed on its first
   drawn frame. Nothing but running it would have caught that.

## Licence

See `LICENSE.txt`. Use in commercial and non-commercial games; do not resell the source as an asset.

---

*Built by CSAF — Core Systems Asset Factory. AI-assisted: code and store graphics.*

## Changes in 1.0.1

- Every documented function now refuses a wrong-typed argument with a usable value, instead of stopping your game with a runtime error. Anything you already call with valid arguments behaves as before, and no save format changed.
- The licence now names the copyright holder, Core Systems Asset Factory. Clause 3.5 now describes this product; it named a different one.
