# Jackpot - Generated Slot Machines for GameMaker

Slot machines for a game corner, a casino level, a festival minigame or a whole slots game. Every machine is generated
from a seed and a theme, drawn by the package, playable out of the box, and its payback is not a guess: the package
computes each machine's return to player EXACTLY and can tune its pay table to any figure you choose.

- **Eight themes of ten symbols, all drawn by the package:** Fruit (cherry, lemon, orange, plum, grapes, melon, bell,
  seven), Gems (amethyst, topaz, emerald, sapphire, ruby, pearl, opal, diamond), Royals (10, J, Q, K, A on card tiles,
  ring, chalice, crown), Runes (eight Elder Futhark runes, each carved in its own stone), Sea (shell, starfish, fish, crab,
  turtle, anchor, ship's wheel, clam with pearl), Desert Relics (scarab, ankh, eye, urn, cobra, pyramid, mask, winged sun),
  Candy (gumdrop, wrapped sweet, lollipop, ice cream, donut, cupcake, candy cane, heart) and Space (moon, comet, ringed
  planet, star, rocket, saucer, helmet, galaxy). Each theme also has its own WILD plaque and SCATTER medallion: 80 symbols.
  No image file is loaded.
- **Three cabinets in four liveries:** an upright with a marquee of chasing bulbs and a pull lever, a slant-top, and a
  bar-top, in lacquer, chrome, wood grain or black and gold. The marquee carries the machine's generated name.
- **A machine that plays:** the reels run with motion smear, stop one after another and settle with a bounce; wins light
  their payline and the winning symbols pulse; the WIN and CREDIT meters roll up in LED digits; coins fountain into the
  tray; a big win gets a banner. Every press and every result is posted as an event, so your own sounds hook in.
- **Mathematics you can state:** reel strips and pay tables are plain data. `jkp_rtp` computes the exact return to player
  from each reel's symbol counts; `jkp_tune` re-tunes the pay table to a target (92%, 96%, whatever your game corner
  should pay); `jkp_exhaust3` plays every stop combination of a 3-reel machine; `jkp_simulate` gives the hit rate and
  swing of any machine. The pay table page the package draws prints the exact figure.

**Play money only.** Nothing here takes, holds or pays real money. If you ship slot machines in a game for a mobile or
console store, that store's rules on simulated gambling apply to your game.

## Install

1. In GameMaker, **Tools > Import Local Package**, choose `Jackpot.yymps`, and import everything.
2. Run the project with `rm_jkp_demo` first in the room order. The demo is THE GAME CORNER: eight machines, one per
   theme, on all three cabinets and both reel counts, sharing one purse of play money. Beside each machine: its pay table
   and its figures. SPACE spins (or click SPIN, or pull the lever), UP and DOWN change the line bet, L the lines played,
   1 to 8 or LEFT and RIGHT choose a machine, and T re-tunes the pay table to 85, 90, 92, 95 or 98% and re-prints it.

Requires GameMaker 2024.14 or later. Built and tested on runtime 2024.14.4.268 (the VM, Windows). Pure GML, no shader, no
extension; nothing here depends on GMRT.

## Quickstart

```gml
// Create - a machine from a word (the same word always builds the same machine), and a playable slot for it
my_machine = jkp_machine_create({ seed: "Lucky Sevens", theme: "fruit", reels: 5, cabinet: "upright", rtp: 0.94 });
my_slot = jkp_slot_create(my_machine, { credits: 500, lineBet: 1 });

// Step - run it, spin on SPACE, and listen for what happened
jkp_slot_step(my_slot);
if (keyboard_check_pressed(vk_space)) jkp_slot_press(my_slot, "spin");
var my_events = jkp_slot_events(my_slot);
for (var i = 0; i < array_length(my_events); i++) {
    if (my_events[i].type == "win") show_debug_message("won " + string(my_events[i].amount));
}

// Draw GUI - the machine is jkp_cabinet_layout(my_machine).w x .h at scale 1; draw it anywhere, at any scale
jkp_slot_draw(my_slot, 40, 20, 0.9);

// Clean Up
jkp_slot_free(my_slot);
```

The cabinet and the theme's symbols are baked the first time the slot is drawn (a fraction of a second; see
Performance). Call `jkp_slot_prepare(my_slot)` on a loading screen to bake them there instead.

## The rules (tell your players)

- A machine has 3 or 5 reels and 3 rows. A spin stops each reel at a random position of its strip.
- Symbols 0 to 7 of a theme are its pay symbols, lowest to highest. The WILD stands in for any pay symbol. The SCATTER pays
  wherever it lands.
- A line pays from the left. Its symbol is the first symbol on it that is not a wild; the run is how many positions in a
  row, from the left, are that symbol or a wild. A run of 3 or more pays the pay table's figure times the line bet. A line
  of wilds only pays as the top symbol.
- Scatters pay their figure times the TOTAL bet (line bet times lines played), anywhere in view.
- A 3-reel machine has 5 paylines, a 5-reel machine 20. The total bet is the line bet (1 to 10) times the lines played.

## The machine: generate, measure, tune

```gml
var m = jkp_machine_create({ seed: 12345 });              // theme, reels, cabinet and target all from the seed
var r = jkp_rtp(m);                                        // { rtp, line, scat, lineHit } - exact
show_debug_message(m.name + " returns " + string(r.rtp * 100) + "%");
jkp_tune(m, 0.92);                                         // re-tune its pay table: returns the exact rtp reached
var x3 = jkp_exhaust3(jkp_machine_create({ seed: 7, reels: 3 }));   // { spins, hitRate, rtp, sd, maxWin } over every stop combination
var sim = jkp_simulate(m, 5000, 1);                        // the same figures from 5,000 seeded spins (any machine)
var lt = jkp_line_table(m);                                // lt[symbol][run]: the exact chance one line pays that run
var st = jkp_scatter_table(m);                             // st[n]: the exact chance of n scatters in view
```

`jkp_machine_create` options (all optional): `seed` (a number or any string), `theme` (`"fruit"`, `"gems"`, `"royals"`,
`"runes"`, `"sea"`, `"desert"`, `"candy"`, `"space"`, or 0 to 7), `reels` (3 or 5), `cabinet` (`"upright"`, `"slant"`,
`"bartop"`), `rtp` (a target from 0.5 to 1.2; by default the seed picks one from 0.900 to 0.960). An option never changes
what the seed decides for the others.

A machine is a plain struct you can read and edit: `name`, `theme`, `themeIndex`, `reels`, `stops` (24 for 3 reels, 32 for
5), `cabinet`, `livery` (0 to 3), `lines` (the payline patterns, one row per reel), `strips` (one array of symbol ids per
reel), `pays` (for each pay symbol, what runs of 3, 4 and 5 pay, in line bets), `scatterPays` (indexed by the number of
scatters, in total bets), `rtp`, `lineHit`, `target`. If you edit `strips` or `pays` yourself, call `jkp_rtp` for the new
exact figure.

**How exact is exact.** A spin's line wins depend only on which symbol each reel shows on that line, and every reel stops
uniformly at random, so the probability of every run of every symbol on one line is a product of each reel's symbol
counts. `jkp_line_table` computes those probabilities, `jkp_scatter_table` the distribution of scatters in view, and
`jkp_rtp` the sum. The package's own tests check this against brute force: playing all 13,824 stop combinations of 3-reel
machines returns the same figure, and so do 32,768-combination 5-reel machines in the reference tests. Because every line
has the same distribution, the return does not depend on how many lines are played.

**Tuning.** `jkp_tune` keeps every pay a whole number, keeps the table sensible (no lower symbol pays more than a higher
one; a longer run always pays more), and moves it one step at a time while each step brings the return closer to the
target. Measured: 5-reel machines land within 0.00001 of the target, 3-reel machines within 0.0006 (fewer pays to move).
Scatter pays are left as they are.

Other functions: `jkp_themes()`, `jkp_cabinets()`, `jkp_paylines(reels)`, `jkp_symbol_name(theme, id)`,
`jkp_pay(machine, symbol, run)`, `jkp_window(machine, stops)`, `jkp_evaluate(machine, window, lines)`,
`jkp_spin(machine, generator, lines)`, `jkp_hash_string(text)`, `jkp_rng(seed)`, `jkp_rand(generator)`. Constants:
`JKP_WILD` (8), `JKP_SCATTER` (9), `JKP_TOP` (7), `JKP_ROWS` (3).

```gml
var g = jkp_rng(42);
var spin = jkp_spin(m, g, 20);          // { stops, window, wins, total, lines, scatters } - total in line bets
for (var i = 0; i < array_length(spin.wins); i++) {
    var w = spin.wins[i];               // { line, sym, count, pay }; line -1 is the scatter win
    show_debug_message(jkp_symbol_name(m.theme, w.sym) + " x" + string(w.count) + " pays " + string(w.pay));
}
```

## The playable slot

`jkp_slot_create(machine, options)` - options: `credits` (default 1000), `lineBet` (1 to 10, default 1), `lines` (default
all), `seed` (the stops' generator; default the machine's seed + 1), `res` (bake resolution: 2 if you draw the machine at
scale 2). Then:

- `jkp_slot_press(slot, id)` with `"spin"`, `"lever"`, `"betup"`, `"betdown"` or `"lines"`. A spin is refused (false, and a
  `"refused"` event) while the reels move or when the credits do not cover the bet. The outcome is decided by `jkp_spin`
  the moment the spin starts; the reels only show it.
- `jkp_slot_step(slot)` once a Step; `jkp_slot_draw(slot, x, y, scale)` in any Draw event or into a surface.
- `jkp_slot_events(slot)` returns and clears what happened: `"spin"` (`bet`, `stops`), `"reel_stop"` (`reel`), `"win"` or
  `"big_win"` (`amount`, `wins`), `"no_win"`, `"refused"` (`reason`). Hook your sounds and your purse here.
- `jkp_slot_hit(slot, x, y, scale, mouse_x, mouse_y)` names the control under a point (`"spin"`, `"betup"`, `"betdown"`,
  `"lines"`, `"lever"` or `""`), for a mouse or a touch.
- `jkp_slot_bet(slot)` is the total bet; `jkp_slot_window(slot)` what the reels show; `slot.credits` the credits (read or set
  them to share one purse between machines, as the demo does).
- `jkp_slot_prepare(slot)` bakes now; `jkp_slot_free(slot)` frees the slot's cabinet and reel surface.

```gml
var mx = device_mouse_x_to_gui(0), my = device_mouse_y_to_gui(0);
var hit = jkp_slot_hit(my_slot, 40, 20, 0.9, mx, my);
if (mouse_check_button_pressed(mb_left) && hit != "") jkp_slot_press(my_slot, hit);
```

## Drawing directly

Everything the slot draws is yours to use on its own. These bakes are PREMULTIPLIED sprites: draw them with
`jkp_draw_premul` (or `gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha)`).

```gml
var atlas = jkp_symbol_atlas("gems", 96);       // the theme's ten symbols side by side, 96 x 96 each (cached)
jkp_draw_premul(atlas, 0, 7 * 96, 0, 96, 96, 100, 100, 1, 1, 1);   // the diamond
var cab = jkp_cabinet_bake(m, 1);                // the machine's cabinet (no reels), w x h of jkp_cabinet_layout(m)
var page = jkp_paytable_bake(m, 400, 430, 1);   // its pay table page, with the exact rtp
var coin = jkp_coin_sprite(24);                  // a gold coin (cached)
jkp_draw_led(300, 40, 24, "1250", c_red);        // seven-segment LED digits, right-aligned to x
```

`jkp_cabinet_layout(machine)` gives every rectangle of the cabinet at scale 1 (`window`, `meters`, `buttons`, `tray`,
`marquee`, `belly`, `lever`), so you can put your own art or input on top. `jkp_theme_colours(theme)` gives a theme's
`accent`, `deep`, `metal` and `glow` colours. With a canvas context you can paint one symbol at any size into a surface:

```gml
var s = surface_create(256, 256);
surface_set_target(s);
draw_clear_alpha(c_black, 0);
var cx = jkp_cx_create(1);
jkp_symbol_paint(cx, "space", 4, 128, 128, 240);   // the rocket, 240 px
surface_reset_target();
```

Free the cached atlases with `jkp_symbol_atlas_free()` when the last machine goes (the slot never frees them itself:
they are shared between machines of the same theme).

## Performance

Measured on the VM (runtime 2024.14.4.268, Windows), on a shared machine, so read these as ranges:

- `jkp_machine_create`: under 5 ms (the generator and the tuner together).
- First draw of a slot (the cabinet bake, the symbol atlas and its motion-blur copy): 0.29 to 0.71 s over three suite
  runs. Do it on a loading screen with `jkp_slot_prepare`. A symbol atlas alone: 0.10 to 0.31 s per theme at 96 px.
- Every frame after that: the reels, the meters and the lights are a few hundred ordinary draw calls.
- `jkp_exhaust3`: 0.36 to 0.37 s (13,824 spins). `jkp_simulate`: 0.079 to 0.084 ms a spin.

## Verification

GML cannot be unit-tested outside the engine, so every test here runs in a real Igor-built executable. The suite (run the
demo with `-selftest`) holds the GML core to a reference implementation run in Node, bit for bit: hashes, generator
draws, 24 generated machines (every strip, pay, name and exact figure), the line and scatter tables, the tuner at ten
targets, 240 scripted spins with every win, and the exhaustive and simulated statistics. It then checks, inside the
engine, that playing every stop combination returns exactly what `jkp_rtp` computes; that every symbol is drawn with real
ink, fits its cell, and differs from every other symbol of its theme (with a control proving the check catches two
symbols that differ only in a carved detail); that all three cabinets play to a win with the reels showing exactly the
outcome decided and the credit ledger closing; and that the game corner opens, pays, re-tunes and switches machines.

Not built or tested: HTML5, mobile and YYC exports.

## Licence

See `LICENSE.txt`: use it in any number of your games, commercial or not; do not resell or redistribute the package
itself. The fonts are under the SIL Open Font License; see `Jackpot/fonts/THIRD-PARTY-NOTICES.txt`.

Jackpot - Generated Slot Machines for GameMaker. Copyright (c) 2026 Core Systems Asset Factory.
