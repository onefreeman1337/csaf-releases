/// @description Run the game corner.
if (is_undefined(demo)) exit;
jkp_demo_step(demo);
