/// @description Free what the game corner made (guarded: Clean Up runs even when Create left early for -selftest).
if (variable_instance_exists(id, "demo") && !is_undefined(demo)) { jkp_demo_free(demo); demo = undefined; }
