/// @description Draw the game corner, scaled to fit the GUI.
if (is_undefined(demo)) exit;
jkp_demo_draw(demo);
