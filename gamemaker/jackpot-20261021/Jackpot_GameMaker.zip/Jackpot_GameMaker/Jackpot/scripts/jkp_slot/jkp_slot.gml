/// jkp_slot.gml - a PLAYABLE machine: credits and bets, a spin whose reels run with motion smear and settle with a bounce
/// one after another, the wins lit line by line with the winning symbols pulsing, the WIN and CREDIT meters rolling up in
/// LED digits, the marquee bulbs chasing, the lever, and a coin shower into the tray. Play money only.
///
/// Jackpot - Generated Slot Machines for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// THE LOOP A GAME WRITES (see the Readme):
///   Create:   machine = jkp_machine_create({ seed: "Lucky Sevens" }); slot = jkp_slot_create(machine, { credits: 500 });
///   Step:     jkp_slot_step(slot); if (keyboard_check_pressed(vk_space)) jkp_slot_press(slot, "spin");
///             var _ev = jkp_slot_events(slot);   // { type: "spin" | "reel_stop" | "win" | "big_win" | "no_win" | "refused", ... }
///   Draw GUI: jkp_slot_draw(slot, x, y, scale);
///   Clean Up: jkp_slot_free(slot);
/// The outcome of every spin is decided by jkp_spin (the exact core) the moment the spin starts; the reels only show it.

/// @function jkp_slot_create(machine, [options])
/// @description A playable machine. Options (all optional): credits (default 1000), lineBet (1..10, default 1), lines (1..all,
/// default all), seed (the stops' generator; default the machine's seed + 1), res (bake resolution, default 1 - use 2 if
/// you draw the machine at scale 2). The cabinet and the symbol atlases are baked on the FIRST jkp_slot_draw, or now with
/// jkp_slot_prepare. Not a machine -> undefined.
/// @returns {Struct}
function jkp_slot_create(_m, _opt = undefined) {
    if (!jkp__is_machine(_m)) return undefined;
    var _o = is_struct(_opt) ? _opt : {};
    var _L = jkp_cabinet_layout(_m);
    var _cr = _o[$ "credits"], _lb = _o[$ "lineBet"], _ln = _o[$ "lines"], _sd = _o[$ "seed"], _rs = _o[$ "res"];
    var _s = {
        m: _m, L: _L, res: (is_numeric(_rs) && _rs >= 0.5 && _rs <= 4) ? _rs : 1,
        credits: (is_numeric(_cr) && _cr >= 0) ? floor(_cr) : 1000,
        lineBet: (is_numeric(_lb) && _lb >= 1) ? clamp(floor(_lb), 1, 10) : 1,
        lines: (is_numeric(_ln) && _ln >= 1) ? clamp(floor(_ln), 1, array_length(_m.lines)) : array_length(_m.lines),
        g: jkp_rng(is_numeric(_sd) ? _sd : (_m.seed + 1)),
        state: "idle", t: 0, spinT: 0, reels: [], result: undefined, win: 0, shownCredits: 0, shownWin: 0,
        winIndex: -1, winT: 0, coins: [], events: [], lever: 0, leverV: 0, press: "", pressT: 0, spins: 0,
        cab: -1, atlas: -1, blur: -1, rs: -1, cellPx: 0, coinsToPour: 0, bigWin: false
    };
    _s.shownCredits = _s.credits;
    // how high a coin may jump out of the tray: the gap between the tray and whatever sits above it (buttons, belly), so
    // the fountain never covers a control or the belly's writing (looked at: a fixed 45 px jump covered both)
    var _above = 0, _tr = _L.tray;
    for (var _b = 0; _b < array_length(_L.buttons); _b++) { var _bb = _L.buttons[_b]; if (_bb.y + _bb.h <= _tr.y + 1) _above = max(_above, _bb.y + _bb.h); }
    if (!is_undefined(_L.belly) && _L.belly.y + _L.belly.h <= _tr.y + 1) _above = max(_above, _L.belly.y + _L.belly.h);
    // SOLVED from where a coin starts (mid-tray) to the element above, never a constant: the highest coin's top edge stays 1 px
    // under that element (10 = its 9 px radius + 1). A cabinet with no room above its tray keeps its coins tumbling inside it.
    // MEASURED: a floor of 6 px rose 1.5 to 7.5 px over the upright's belly and the bar-top's buttons, and a floor of 0 still
    // rose 1.8 px over the bar-top's SPIN (its tray is 26 px deep) - both red in the suite's coin assertion.
    _s.coinY = _tr.y + _tr.h * 0.55;
    _s.coinRise = clamp(_s.coinY - _above - 10, 0, 46);
    for (var _r = 0; _r < _m.reels; _r++) array_push(_s.reels, { pos: jkp__below(jkp_rng(_m.seed + 7 + _r), _m.stops), speed: 0, phase: "idle", stopAt: 0, from: 0, to: 0, k: 0 });
    return _s;
}

/// @function jkp_slot_prepare(slot)
/// @description Bake the cabinet and the symbol atlases now (a loading screen), instead of on the first draw. Returns true.
function jkp_slot_prepare(_s) {
    if (!is_struct(_s)) return false;
    if (!sprite_exists(_s.cab)) _s.cab = jkp_cabinet_bake(_s.m, _s.res);
    _s.cellPx = ceil(_s.L.window.cell * _s.res);
    if (!sprite_exists(_s.atlas)) _s.atlas = jkp_symbol_atlas(_s.m.themeIndex, _s.cellPx);
    if (!sprite_exists(_s.blur)) _s.blur = jkp__blur_atlas(_s.atlas, _s.cellPx);
    return true;
}

/// @function jkp__blur_atlas(atlas, px)
/// @description Internal. The atlas smeared vertically (seven premultiplied copies over 0.7 of a cell), for reels in motion.
/// Cached with the atlas key.
function jkp__blur_atlas(_atlas, _px) {
    if (!sprite_exists(_atlas)) return -1;
    if (!variable_global_exists("jkp_blur_cache")) global.jkp_blur_cache = {};
    var _key = string(_atlas) + "_" + string(_px), _hit = global.jkp_blur_cache[$ _key];
    if (!is_undefined(_hit) && sprite_exists(_hit)) return _hit;
    var _w = sprite_get_width(_atlas), _h = sprite_get_height(_atlas);
    var _s = surface_create(_w, _h);
    var _pm = matrix_get(matrix_world); matrix_set(matrix_world, matrix_build_identity());
    surface_set_target(_s); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_one); gpu_set_texfilter(true);
    var _n = 7;
    for (var _i = 0; _i < _n; _i++) { var _dy = (_i / (_n - 1) - 0.5) * _px * 0.7; draw_sprite_ext(_atlas, 0, 0, _dy, 1, 1, 0, merge_colour(c_black, c_white, 1 / _n), 1 / _n); }
    gpu_pop_state(); surface_reset_target();
    var _spr = sprite_create_from_surface(_s, 0, 0, _w, _h, false, false, 0, 0);
    surface_free(_s);
    matrix_set(matrix_world, _pm);
    global.jkp_blur_cache[$ _key] = _spr;
    return _spr;
}

/// @function jkp_slot_bet(slot)
/// @description The total bet of one spin: line bet x lines played.
/// @returns {Real}
function jkp_slot_bet(_s) { return is_struct(_s) ? _s.lineBet * _s.lines : 0; }

/// @function jkp_slot_press(slot, id)
/// @description Press a control: "spin" (or "lever"), "betup", "betdown", "lines" (cycles 1 .. all). Bets and lines only change
/// while the reels are still. Returns true when the press did something; a refused spin (reels moving, too few credits)
/// returns false and posts a "refused" event.
/// @returns {Bool}
function jkp_slot_press(_s, _id) {
    if (!is_struct(_s) || !is_string(_id)) return false;
    _s.press = _id; _s.pressT = 10;
    var _idle = (_s.state == "idle" || _s.state == "paying");
    switch (_id) {
        case "spin": case "lever":
            if (!_idle) { array_push(_s.events, { type: "refused", reason: "reels moving" }); return false; }
            var _bet = jkp_slot_bet(_s);
            if (_s.credits < _bet) { array_push(_s.events, { type: "refused", reason: "credits" }); return false; }
            jkp__slot_settle_win(_s);
            _s.credits -= _bet; _s.shownCredits = _s.credits;
            _s.result = jkp_spin(_s.m, _s.g, _s.lines);
            _s.state = "spinning"; _s.spinT = 0; _s.win = 0; _s.shownWin = 0; _s.winIndex = -1; _s.bigWin = false; _s.spins++;
            if (_id == "lever" || !is_undefined(_s.L.lever)) _s.leverV = 0.16;
            for (var _r = 0; _r < _s.m.reels; _r++) { var _R = _s.reels[_r]; _R.phase = "spin"; _R.speed = 0; _R.stopAt = 22 + _r * 9; }
            array_push(_s.events, { type: "spin", bet: _bet, stops: _s.result.stops });
            return true;
        case "betup": if (!_idle) return false; _s.lineBet = min(10, _s.lineBet + 1); return true;
        case "betdown": if (!_idle) return false; _s.lineBet = max(1, _s.lineBet - 1); return true;
        case "lines": if (!_idle) return false; _s.lines = (_s.lines >= array_length(_s.m.lines)) ? 1 : _s.lines + 1; return true;
    }
    return false;
}

/// @function jkp__slot_settle_win(slot)
/// @description Internal. Finish a win presentation at once (the next spin starts): meters to their final values.
function jkp__slot_settle_win(_s) { _s.shownCredits = _s.credits; _s.shownWin = _s.win; }

/// @function jkp__ease_back(u)
/// @description Internal. Ease out with a small overshoot (about 4 percent of the travel): the reel's settle bounce.
function jkp__ease_back(_u) { var _c1 = 0.9, _c3 = _c1 + 1, _v = _u - 1; return 1 + _c3 * _v * _v * _v + _c1 * _v * _v; }

/// @function jkp_slot_step(slot)
/// @description Advance the machine one frame: reels, settle, win presentation, meters, coins, bulbs, lever. Call once a
/// Step. Never decides an outcome (jkp_slot_press did).
function jkp_slot_step(_s) {
    if (!is_struct(_s)) return;
    _s.t++;
    if (_s.pressT > 0) _s.pressT--;
    // the lever: pulled down fast, springs back
    _s.lever = clamp(_s.lever + _s.leverV, 0, 1);
    if (_s.lever >= 1) _s.leverV = -0.06;
    if (_s.lever <= 0 && _s.leverV < 0) _s.leverV = 0;
    var _n = _s.m.stops;
    if (_s.state == "spinning") {
        _s.spinT++;
        var _still = 0;
        for (var _r = 0; _r < _s.m.reels; _r++) {
            var _R = _s.reels[_r];
            if (_R.phase == "spin") {
                _R.speed = min(0.42, _R.speed + 0.05);
                _R.pos -= _R.speed;
                if (_s.spinT >= _R.stopAt) {
                    var _stop = _s.result.stops[_r];
                    var _lead = _R.pos - 3 - _stop;
                    _R.from = _R.pos; _R.to = _R.pos - 3 - (((_lead mod _n) + _n) mod _n);
                    _R.phase = "stop"; _R.k = 0;
                }
            } else if (_R.phase == "stop") {
                _R.k++;
                var _u = min(1, _R.k / 16);
                _R.pos = _R.from + (_R.to - _R.from) * jkp__ease_back(_u);
                _R.speed = (_u < 0.6) ? 0.3 * (1 - _u) : 0;
                if (_u >= 1) { _R.pos = ((round(_R.to) mod _n) + _n) mod _n; _R.phase = "idle"; _R.speed = 0; array_push(_s.events, { type: "reel_stop", reel: _r }); }
            }
            if (_R.phase == "idle") _still++;
        }
        if (_still == _s.m.reels) {
            var _res = _s.result;
            _s.win = _res.total * _s.lineBet;
            if (_s.win > 0) {
                _s.credits += _s.win;
                _s.state = "paying"; _s.winIndex = 0; _s.winT = 0;
                _s.bigWin = (_res.total >= 15 * _s.lines);
                _s.coinsToPour = min(160, 6 + floor(_res.total / max(1, _s.lines) * 10));
                array_push(_s.events, { type: _s.bigWin ? "big_win" : "win", amount: _s.win, wins: _res.wins });
            } else { _s.state = "idle"; array_push(_s.events, { type: "no_win" }); }
        }
    }
    // win presentation: meters roll, lines cycle, coins pour
    if (_s.state == "paying") {
        _s.winT++;
        var _step = max(1, ceil(_s.win / 60));
        _s.shownWin = min(_s.win, _s.shownWin + _step);
        _s.shownCredits = min(_s.credits, _s.shownCredits + _step);
        var _nw = array_length(_s.result.wins);
        if (_nw > 0 && (_s.winT mod 54) == 0) _s.winIndex = (_s.winIndex + 1) mod (_nw + 1);
        if (_s.coinsToPour > 0 && (_s.t mod 2) == 0) {
            var _tr = _s.L.tray;
            for (var _k = 0; _k < 2 && _s.coinsToPour > 0; _k++) {
                // cosmetic only, so it draws NOTHING from the outcome generator (that would shift every later spin): the
                // coins are scattered by the frame count
                var _a = _s.t * 0.37 + _k * 1.7 + _s.coinsToPour;
                // a fountain from mid-tray, no higher than slot.coinRise above its start (v = sqrt(2 g h), g = 0.3)
                var _v0 = sqrt(2 * 0.3 * _s.coinRise) * (0.7 + 0.3 * abs(cos(_a * 0.7)));
                array_push(_s.coins, { x: _tr.x + _tr.w * (0.5 + 0.3 * sin(_a)), y: _s.coinY, vx: 1.4 * sin(_a * 1.3), vy: -_v0, spin: _a, spinV: 0.18 + 0.1 * abs(sin(_a)), landed: false });
                _s.coinsToPour--;
            }
        }
    } else { _s.shownCredits = _s.credits; }
    // coins: up, over, back down into the tray
    for (var _c = array_length(_s.coins) - 1; _c >= 0; _c--) {
        var _q = _s.coins[_c];
        _q.vy += 0.3; _q.x += _q.vx; _q.y += _q.vy; _q.spin += _q.spinV;
        if (_q.y > _s.L.tray.y + _s.L.tray.h - 10 && _q.vy > 0) array_delete(_s.coins, _c, 1);
    }
}

/// @function jkp_slot_events(slot)
/// @description Everything that happened since the last call, oldest first, and clears the list: { type: "spin" (bet, stops),
/// "reel_stop" (reel), "win" / "big_win" (amount, wins), "no_win", "refused" (reason) }. Hook your sounds here.
/// @returns {Array<Struct>}
function jkp_slot_events(_s) { if (!is_struct(_s)) return []; var _e = _s.events; _s.events = []; return _e; }

/// @function jkp_slot_window(slot)
/// @description What the reels show right now, window[reel][row] (row 0 at the top) - while moving, the nearest symbols.
/// @returns {Array<Array<Real>>}
function jkp_slot_window(_s) {
    if (!is_struct(_s)) return [];
    var _w = [], _n = _s.m.stops;
    for (var _r = 0; _r < _s.m.reels; _r++) { var _p = ((round(_s.reels[_r].pos) mod _n) + _n) mod _n, _col = []; for (var _k = 0; _k < 3; _k++) array_push(_col, _s.m.strips[_r][(_p + _k) mod _n]); array_push(_w, _col); }
    return _w;
}

/// @function jkp_slot_hit(slot, x, y, scale, mx, my)
/// @description Which control a point is over when the machine is drawn at (x, y) and scale: "spin", "betup", "betdown",
/// "lines", "lever", or "" for none.
/// @returns {String}
function jkp_slot_hit(_s, _x, _y, _sc, _mx, _my) {
    if (!is_struct(_s) || !(_sc > 0)) return "";
    var _px = (_mx - _x) / _sc, _py = (_my - _y) / _sc, _L = _s.L;
    for (var _i = 0; _i < array_length(_L.buttons); _i++) { var _b = _L.buttons[_i]; if (_px >= _b.x && _px < _b.x + _b.w && _py >= _b.y && _py < _b.y + _b.h) return _b.id; }
    if (!is_undefined(_L.lever)) {
        var _th = _s.lever * pi * 0.75, _bx = _L.lever.x + 4 + sin(_th) * _L.lever.len * 0.12, _by = _L.lever.y - cos(_th) * _L.lever.len;
        if (point_distance(_px, _py, _bx, _by) < 24) return "lever";
    }
    return "";
}

/// @function jkp_slot_draw(slot, x, y, [scale])
/// @description Draw the whole machine with its top-left at (x, y): the cabinet, the reels, the glass, the meters, the bulbs,
/// the win lines and pulsing winners, the lever and the coins. The machine is jkp_cabinet_layout(machine).w x .h at scale 1.
/// Draws into whatever target is set (the GUI layer, a surface); the caller's blend mode and alpha are restored.
function jkp_slot_draw(_s, _x, _y, _sc = 1) {
    if (!is_struct(_s) || !(_sc > 0)) return;
    jkp_slot_prepare(_s);
    var _L = _s.L, _m = _s.m, _W = _L.window, _cell = _W.cell, _n = _m.stops, _tc = jkp_theme_colours(_m.themeIndex);
    var _pa = draw_get_alpha(), _pc = draw_get_colour();
    gpu_push_state();
    // the lever goes BEHIND the cabinet's edge (its mount is part of the bake)
    if (!is_undefined(_L.lever)) jkp__slot_lever(_s, _x, _y, _sc);
    jkp_draw_premul(_s.cab, 0, 0, 0, sprite_get_width(_s.cab), sprite_get_height(_s.cab), _x, _y, _sc / _s.res, _sc / _s.res, 1);
    // the reels are drawn into their OWN surface (the window's size at this scale) and that surface is drawn in place: no
    // scissor, so the window clips correctly under any GUI scaling, camera or world matrix the game has set
    var _sx = _x + _W.x * _sc, _sy0 = _y + _W.y * _sc;
    var _rw = max(1, ceil(_W.w * _sc)), _rh = max(1, ceil(_W.h * _sc));
    if (!surface_exists(_s.rs) || surface_get_width(_s.rs) != _rw || surface_get_height(_s.rs) != _rh) { if (surface_exists(_s.rs)) surface_free(_s.rs); _s.rs = surface_create(_rw, _rh); }
    var _pmw = matrix_get(matrix_world);
    surface_set_target(_s.rs);
    matrix_set(matrix_world, matrix_build_identity());
    draw_clear_alpha(c_black, 1);
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    var _wx = 0, _wy = 0, _ww = _W.w * _sc, _wh = _W.h * _sc, _cs = _cell * _sc;
    var _winCells = jkp__slot_win_cells(_s);
    for (var _r = 0; _r < _m.reels; _r++) {
        var _R = _s.reels[_r], _rx = _wx + _r * _cs;
        draw_primitive_begin(pr_trianglestrip);
        draw_vertex_colour(_rx, _wy, make_colour_rgb(214, 204, 186), 1); draw_vertex_colour(_rx + _cs, _wy, make_colour_rgb(214, 204, 186), 1);
        draw_vertex_colour(_rx, _wy + _wh * 0.5, make_colour_rgb(252, 248, 238), 1); draw_vertex_colour(_rx + _cs, _wy + _wh * 0.5, make_colour_rgb(252, 248, 238), 1);
        draw_vertex_colour(_rx, _wy + _wh, make_colour_rgb(214, 204, 186), 1); draw_vertex_colour(_rx + _cs, _wy + _wh, make_colour_rgb(214, 204, 186), 1);
        draw_primitive_end();
        var _base = floor(_R.pos), _f = _R.pos - _base, _blurA = clamp((abs(_R.speed) - 0.12) / 0.25, 0, 1);
        for (var _k = -1; _k <= 3; _k++) {
            var _idx = (((_base + _k) mod _n) + _n) mod _n, _sym = _m.strips[_r][_idx];
            var _sy = _wy + (_k - _f) * _cs;
            var _pulse = 1;
            if (_R.phase == "idle" && _k >= 0 && _k < 3 && _f < 0.001 && _winCells[_r * 3 + _k]) _pulse = 1 + 0.07 * sin(_s.t * 0.22);
            var _ds = _cs * _pulse / _s.cellPx, _dx = _rx + (_cs - _cs * _pulse) / 2, _dy = _sy + (_cs - _cs * _pulse) / 2;
            if (_blurA < 1) jkp_draw_premul(_s.atlas, 0, _sym * _s.cellPx, 0, _s.cellPx, _s.cellPx, _dx, _dy, _ds, _ds, 1 - _blurA);
            if (_blurA > 0) jkp_draw_premul(_s.blur, 0, _sym * _s.cellPx, 0, _s.cellPx, _s.cellPx, _dx, _dy, _ds, _ds, _blurA);
        }
    }
    // the cylinder: shadowed top and bottom, separators, a sheen on the glass
    draw_primitive_begin(pr_trianglelist);
    var _sh = _wh * 0.24;
    draw_vertex_colour(_wx, _wy, c_black, 0.5); draw_vertex_colour(_wx + _ww, _wy, c_black, 0.5); draw_vertex_colour(_wx, _wy + _sh, c_black, 0);
    draw_vertex_colour(_wx + _ww, _wy, c_black, 0.5); draw_vertex_colour(_wx + _ww, _wy + _sh, c_black, 0); draw_vertex_colour(_wx, _wy + _sh, c_black, 0);
    draw_vertex_colour(_wx, _wy + _wh - _sh, c_black, 0); draw_vertex_colour(_wx + _ww, _wy + _wh - _sh, c_black, 0); draw_vertex_colour(_wx, _wy + _wh, c_black, 0.5);
    draw_vertex_colour(_wx + _ww, _wy + _wh - _sh, c_black, 0); draw_vertex_colour(_wx + _ww, _wy + _wh, c_black, 0.5); draw_vertex_colour(_wx, _wy + _wh, c_black, 0.5);
    draw_primitive_end();
    draw_set_alpha(0.55); draw_set_colour(make_colour_rgb(30, 22, 18));
    for (var _r2 = 1; _r2 < _m.reels; _r2++) draw_rectangle(_wx + _r2 * _cs - max(1, _sc), _wy, _wx + _r2 * _cs + max(1, _sc) - 1, _wy + _wh, false);
    draw_set_alpha(0.07); draw_set_colour(c_white);
    draw_primitive_begin(pr_trianglelist);
    draw_vertex(_wx + _ww * 0.1, _wy); draw_vertex(_wx + _ww * 0.32, _wy); draw_vertex(_wx - _ww * 0.05, _wy + _wh);
    draw_vertex(_wx + _ww * 0.32, _wy); draw_vertex(_wx + _ww * 0.17, _wy + _wh); draw_vertex(_wx - _ww * 0.05, _wy + _wh);
    draw_primitive_end();
    // the win lines
    if (_s.state == "paying" || (_s.state == "idle" && _s.win > 0)) jkp__slot_lines(_s, _wx, _wy, _cs, _sc);
    gpu_set_blendmode(bm_normal);
    matrix_set(matrix_world, _pmw);
    surface_reset_target();
    draw_set_alpha(1);
    draw_surface(_s.rs, _sx, _sy0);
    // the big win banner
    if (_s.bigWin && _s.state == "paying") jkp__slot_banner(_s, _sx + _W.w * _sc / 2, _sy0 + _W.h * _sc / 2, _sc);
    // the meters
    var _vals = [string(_s.shownCredits), string(jkp_slot_bet(_s)), string(_s.shownWin)];
    var _lc = [make_colour_rgb(255, 60, 50), make_colour_rgb(255, 180, 40), make_colour_rgb(80, 255, 120)];
    for (var _i = 0; _i < 3; _i++) { var _mt = _L.meters[_i]; jkp_draw_led(_x + (_mt.x + _mt.w - 7) * _sc, _y + (_mt.y + 8) * _sc, (_mt.h - 16) * _sc, _vals[_i], _lc[_i]); }
    // the bulbs
    var _bulbs = jkp__cab_bulbs(_L), _nb = array_length(_bulbs), _bc = jkp_col(jkp__lit(_tc.glow, 0.3));
    for (var _b = 0; _b < _nb; _b++) {
        var _lit = (_s.state == "paying") ? (((_b + floor(_s.t / 5)) mod 2) == 0) : (((_b + floor(_s.t / 4)) mod 3) == 0);
        var _bx = _x + _bulbs[_b][0] * _sc, _by = _y + _bulbs[_b][1] * _sc;
        if (_lit) { draw_set_alpha(0.3); draw_set_colour(_bc); draw_circle(_bx, _by, 9 * _sc, false); draw_set_alpha(1); draw_set_colour(make_colour_rgb(255, 252, 236)); draw_circle(_bx, _by, 4.2 * _sc, false); }
        else { draw_set_alpha(1); draw_set_colour(merge_colour(_bc, c_black, 0.55)); draw_circle(_bx, _by, 4.2 * _sc, false); }
    }
    // button feedback: the pressed button sinks, the spin button breathes while it can be pressed
    for (var _j = 0; _j < array_length(_L.buttons); _j++) {
        var _bt = _L.buttons[_j], _x0 = _x + _bt.x * _sc, _y0 = _y + _bt.y * _sc, _x1 = _x + (_bt.x + _bt.w) * _sc, _y1 = _y + (_bt.y + _bt.h) * _sc;
        if (_s.pressT > 0 && _s.press == _bt.id) { draw_set_alpha(0.32); draw_set_colour(c_black); draw_roundrect_ext(_x0, _y0, _x1, _y1, 12 * _sc, 12 * _sc, false); }
        else if (_bt.id == "spin" && (_s.state == "idle" || _s.state == "paying")) { draw_set_alpha(0.1 + 0.08 * sin(_s.t * 0.12)); draw_set_colour(c_white); draw_roundrect_ext(_x0, _y0, _x1, _y1, 12 * _sc, 12 * _sc, false); }
    }
    // the coins
    var _coin = jkp_coin_sprite(round(18 * _sc));
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    for (var _q = 0; _q < array_length(_s.coins); _q++) { var _cn = _s.coins[_q]; draw_sprite_ext(_coin, 0, _x + _cn.x * _sc, _y + _cn.y * _sc, max(0.08, abs(cos(_cn.spin))), 1, 0, c_white, 1); }
    gpu_pop_state();
    draw_set_alpha(_pa); draw_set_colour(_pc);
}

/// @function jkp__slot_win_cells(slot)
/// @description Internal. A reels x 3 array: true where a cell belongs to the win being shown (or any win when all show).
function jkp__slot_win_cells(_s) {
    var _o = array_create(_s.m.reels * 3, false);
    if (!(_s.win > 0) || is_undefined(_s.result)) return _o;
    var _w = _s.result.wins, _nw = array_length(_w), _all = (_s.winIndex < 0 || _s.winIndex >= _nw);
    for (var _i = 0; _i < _nw; _i++) {
        if (!_all && _i != _s.winIndex) continue;
        var _x = _w[_i];
        if (_x.line < 0) { for (var _r = 0; _r < _s.m.reels; _r++) for (var _k = 0; _k < 3; _k++) if (_s.result.window[_r][_k] == JKP_SCATTER) _o[_r * 3 + _k] = true; }
        else { var _ln = _s.m.lines[_x.line]; for (var _r2 = 0; _r2 < _x.count; _r2++) _o[_r2 * 3 + _ln[_r2]] = true; }
    }
    return _o;
}

/// @function jkp__slot_lines(slot, wx, wy, cell, scale)
/// @description Internal. The win being shown: its payline as a glowing polyline, frames round its symbols.
function jkp__slot_lines(_s, _wx, _wy, _cs, _sc) {
    var _w = _s.result.wins, _nw = array_length(_w), _all = (_s.winIndex < 0 || _s.winIndex >= _nw);
    for (var _i = 0; _i < _nw; _i++) {
        if (!_all && _i != _s.winIndex) continue;
        var _x = _w[_i];
        if (_x.line < 0) continue;
        var _ln = _s.m.lines[_x.line], _lrgb = jkp__line_colour(_x.line);
        var _col = make_colour_rgb(_lrgb[0], _lrgb[1], _lrgb[2]);
        for (var _pass = 0; _pass < 2; _pass++) {
            draw_set_alpha((_pass == 0) ? 0.35 : 1); draw_set_colour((_pass == 0) ? _col : merge_colour(_col, c_white, 0.45));
            var _wd = ((_pass == 0) ? 9 : 3.4) * _sc;
            for (var _r = 0; _r + 1 < _s.m.reels; _r++) {
                var _ax = _wx + (_r + 0.5) * _cs, _ay = _wy + (_ln[_r] + 0.5) * _cs, _bx = _wx + (_r + 1.5) * _cs, _by = _wy + (_ln[_r + 1] + 0.5) * _cs;
                draw_line_width(_ax, _ay, _bx, _by, _wd);
                draw_circle(_bx, _by, _wd / 2, false);
            }
        }
        draw_set_alpha(1); draw_set_colour(merge_colour(_col, c_white, 0.3));
        for (var _r2 = 0; _r2 < _x.count; _r2++) {
            var _cx = _wx + _r2 * _cs, _cy = _wy + _ln[_r2] * _cs;
            for (var _k = 0; _k < 3; _k++) draw_roundrect_ext(_cx + (2 + _k) * _sc, _cy + (2 + _k) * _sc, _cx + _cs - (3 + _k) * _sc, _cy + _cs - (3 + _k) * _sc, 10 * _sc, 10 * _sc, true);
        }
    }
}

/// @function jkp__slot_banner(slot, cx, cy, scale)
/// @description Internal. BIG WIN, struck over the reels in the display face, pulsing.
function jkp__slot_banner(_s, _cx, _cy, _sc) {
    var _k = _sc * (0.9 + 0.08 * sin(_s.t * 0.2)) * (_s.L.window.w / 300);
    var _pf = draw_get_font(), _ph = draw_get_halign(), _pv = draw_get_valign(), _pt = gpu_get_texfilter();
    draw_set_font(fnt_jackpot_display_l); draw_set_halign(fa_center); draw_set_valign(fa_middle); gpu_set_texfilter(true);
    // a dark ribbon behind the words so they read over any symbols
    var _bw = string_width("BIG WIN") * 0.9 * _k / 2 + 22 * _k, _bh = 40 * _k;
    draw_set_alpha(0.72); draw_set_colour(make_colour_rgb(30, 6, 14));
    draw_roundrect_ext(_cx - _bw, _cy - _bh, _cx + _bw, _cy + _bh, 24 * _k, 24 * _k, false);
    draw_set_alpha(1); draw_set_colour(make_colour_rgb(255, 200, 70));
    draw_roundrect_ext(_cx - _bw, _cy - _bh, _cx + _bw, _cy + _bh, 24 * _k, 24 * _k, true);
    draw_set_alpha(1); draw_set_colour(make_colour_rgb(40, 8, 12));
    for (var _i = 0; _i < 12; _i++) draw_text_transformed(_cx + cos(_i / 12 * 2 * pi) * 4 * _k, _cy + sin(_i / 12 * 2 * pi) * 4 * _k, "BIG WIN", 0.9 * _k, 0.9 * _k, 0);
    draw_set_colour(make_colour_rgb(255, 214, 80)); draw_text_transformed(_cx, _cy, "BIG WIN", 0.9 * _k, 0.9 * _k, 0);
    draw_set_colour(make_colour_rgb(255, 250, 220)); draw_set_alpha(0.55); draw_text_transformed(_cx, _cy - 2 * _k, "BIG WIN", 0.9 * _k, 0.9 * _k, 0);
    draw_set_alpha(1);
    gpu_set_texfilter(_pt); draw_set_font(_pf); draw_set_halign(_ph); draw_set_valign(_pv);
}

/// @function jkp__slot_lever(slot, x, y, scale)
/// @description Internal. The lever: a chrome arm on the cabinet's side with a red ball, swung down by a pull.
function jkp__slot_lever(_s, _x, _y, _sc) {
    // seen from the front the arm swings TOWARD the player: its ball travels from above the pivot to below it
    var _lv = _s.L.lever, _th = _s.lever * pi * 0.75;
    var _px = _x + (_lv.x + 4) * _sc, _py = _y + _lv.y * _sc;
    var _ex = _px + sin(_th) * _lv.len * 0.12 * _sc, _ey = _py - cos(_th) * _lv.len * _sc;
    draw_set_alpha(1);
    draw_set_colour(make_colour_rgb(70, 74, 86)); draw_line_width(_px, _py, _ex, _ey, 11 * _sc);
    draw_set_colour(make_colour_rgb(214, 220, 232)); draw_line_width(_px, _py, _ex, _ey, 7 * _sc);
    draw_set_colour(c_white); draw_set_alpha(0.7); draw_line_width(_px - 2 * _sc, _py, _ex - 2 * _sc, _ey, 2 * _sc); draw_set_alpha(1);
    draw_set_colour(make_colour_rgb(90, 10, 16)); draw_circle(_ex, _ey, 17 * _sc, false);
    draw_set_colour(make_colour_rgb(214, 30, 40)); draw_circle(_ex, _ey, 15 * _sc, false);
    draw_set_colour(make_colour_rgb(255, 150, 150)); draw_circle(_ex - 5 * _sc, _ey - 5 * _sc, 5 * _sc, false);
}

/// @function jkp_slot_free(slot)
/// @description Free the slot's cabinet sprite (the symbol atlases are shared: free them with jkp_symbol_atlas_free when the
/// last machine goes). Call from Clean Up.
function jkp_slot_free(_s) {
    if (!is_struct(_s)) return;
    if (sprite_exists(_s.cab)) sprite_delete(_s.cab);
    if (surface_exists(_s.rs)) surface_free(_s.rs);
    _s.cab = -1; _s.rs = -1;
}
