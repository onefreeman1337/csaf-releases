{
  "$GMScript": "v1",
  "%Name": "jkp_slot",
  "name": "jkp_slot",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}