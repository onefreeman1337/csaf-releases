/// jkp_selftest.gml - Jackpot's in-engine test suite: the GML core held to the reference core run in Node (jkp_oracle_core) -
/// hashes, generator draws, generated machines, exact tables, the tuner, scripted spins, exhaustive and simulated statistics -
/// then the exact mathematics proved against enumeration INSIDE the engine, the symbols (every one inked, every pair told
/// apart), the cabinets, the playable machine end to end and the demo room. Run the demo with -selftest; the result is
/// written as jkp_selftest.json in the game's save folder and the renders (jkp_render_*.png) beside it, to be LOOKED at.
///
/// Jackpot - Generated Slot Machines for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function jkp_st_assert(state, condition, message)
/// @description Count one assertion; keep the first 60 failure messages.
function jkp_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 60) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
/// @function jkp_st_stage(state, n)
/// @description Record the stage reached (the crash handler reports it).
function jkp_st_stage(_st, _n) { _st.stage = _n; global.jkp_stage = _n; }

/// @function jkp__st_n(v)
/// @description Internal. A whole number as the oracle writes it.
function jkp__st_n(_v) { return string_trim(string_format(_v, 1, 0)); }
/// @function jkp__st_join(array, sep)
function jkp__st_join(_a, _sep) { var _o = ""; for (var _i = 0; _i < array_length(_a); _i++) _o += ((_i > 0) ? _sep : "") + jkp__st_n(_a[_i]); return _o; }
/// @function jkp__st_first_diff(a, b)
function jkp__st_first_diff(_a, _b) {
    if (_a == _b) return "";
    var _n = min(string_length(_a), string_length(_b)), _i = 1;
    while (_i <= _n && string_char_at(_a, _i) == string_char_at(_b, _i)) _i++;
    return "at char " + string(_i) + ": want '" + string_copy(_a, max(1, _i - 12), 40) + "' got '" + string_copy(_b, max(1, _i - 12), 40) + "'";
}
/// @function jkp__st_close(a, b, tol)
/// @description Internal. |a - b| <= tol, under the suite's zero epsilon.
function jkp__st_close(_a, _b, _tol) { return is_numeric(_a) && is_numeric(_b) && abs(_a - _b) <= _tol; }
/// @function jkp__st_f(v)
function jkp__st_f(_v) { return is_numeric(_v) ? string_format(_v, 1, 15) : string(_v); }

/// @function jkp__st_enc_machine(m)
/// @description Internal. A machine encoded exactly as the oracle encodes it (encM in _oracle_core.js).
function jkp__st_enc_machine(_m) {
    var _s = "", _p = "";
    for (var _r = 0; _r < array_length(_m.strips); _r++) _s += ((_r > 0) ? "/" : "") + jkp__st_join(_m.strips[_r], ".");
    for (var _t = 0; _t < array_length(_m.pays); _t++) _p += ((_t > 0) ? "/" : "") + jkp__st_join(_m.pays[_t], ".");
    return jkp__st_n(_m.seed) + "|" + _m.theme + "|" + jkp__st_n(_m.reels) + "|" + jkp__st_n(_m.stops) + "|" + _m.cabinet + "|" + _m.name + "|" + jkp__st_n(_m.livery)
        + "|" + jkp__st_n(_m.tuneMoves) + "|" + _s + "|" + _p + "|" + jkp__st_join(_m.scatterPays, ".");
}
/// @function jkp__st_enc_spin(e)
function jkp__st_enc_spin(_e) {
    var _w = "";
    for (var _i = 0; _i < array_length(_e.wins); _i++) { var _x = _e.wins[_i]; _w += ((_i > 0) ? ";" : "") + jkp__st_n(_x.line) + "," + jkp__st_n(_x.sym) + "," + jkp__st_n(_x.count) + "," + jkp__st_n(_x.pay); }
    return jkp__st_join(_e.stops, ".") + "|" + jkp__st_n(_e.total) + "|" + jkp__st_n(_e.scatters) + "|" + _w;
}

/// @function jkp__st_ink(surface, x, y, w, h)
/// @description Internal. Pixels with alpha > 0 inside a rectangle of a surface (RGBA bytes, the whole surface read).
function jkp__st_ink(_s, _x, _y, _w, _h) {
    var _sw = surface_get_width(_s), _sh = surface_get_height(_s);
    var _b = buffer_create(_sw * _sh * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _s, 0);
    var _n = 0;
    for (var _yy = max(0, _y); _yy < min(_sh, _y + _h); _yy++) for (var _xx = max(0, _x); _xx < min(_sw, _x + _w); _xx++) if (buffer_peek(_b, (_yy * _sw + _xx) * 4 + 3, buffer_u8) > 0) _n++;
    buffer_delete(_b);
    return _n;
}

/// @function jkp__st_grid(buffer, sw, x, y, cell, n)
/// @description Internal. An n x n grid of mean [alpha, red, green, blue] over one square cell of a surface already read
/// into a buffer, for telling two symbols apart. PER CHANNEL: a luminance-only grid is colour-blind (Doctrine_Craft s7b).
function jkp__st_grid(_b, _sw, _x, _y, _cell, _n) {
    var _g = array_create(_n * _n * 4, 0), _step = _cell / _n;
    for (var _gy = 0; _gy < _n; _gy++) for (var _gx = 0; _gx < _n; _gx++) {
        var _sa = 0, _sr = 0, _sg = 0, _sb = 0, _k = 0;
        for (var _py = floor(_gy * _step); _py < floor((_gy + 1) * _step); _py += 2) for (var _px = floor(_gx * _step); _px < floor((_gx + 1) * _step); _px += 2) {
            var _o = ((_y + _py) * _sw + (_x + _px)) * 4;
            _sr += buffer_peek(_b, _o, buffer_u8); _sg += buffer_peek(_b, _o + 1, buffer_u8); _sb += buffer_peek(_b, _o + 2, buffer_u8); _sa += buffer_peek(_b, _o + 3, buffer_u8); _k++;
        }
        var _i = (_gy * _n + _gx) * 4, _kk = max(1, _k);
        _g[_i] = _sa / _kk; _g[_i + 1] = _sr / _kk; _g[_i + 2] = _sg / _kk; _g[_i + 3] = _sb / _kk;
    }
    return _g;
}

/// @function jkp__st_grid_dist(a, b)
/// @description Internal. The mean over cells of the LARGEST channel difference (a cell differs if any channel does).
function jkp__st_grid_dist(_a, _b) {
    var _d = 0, _n = array_length(_a) div 4;
    for (var _i = 0; _i < _n; _i++) _d += max(abs(_a[_i * 4] - _b[_i * 4]), abs(_a[_i * 4 + 1] - _b[_i * 4 + 1]), abs(_a[_i * 4 + 2] - _b[_i * 4 + 2]), abs(_a[_i * 4 + 3] - _b[_i * 4 + 3]));
    return _d / max(1, _n);
}

/// @function jkp_selftest_run()
/// @description Run the whole suite and return its state { pass, fail, total, stage, failures, ... }.
function jkp_selftest_run() {
    var _st = { pass: 0, fail: 0, total: 0, stage: 0, failures: [], runtime: GM_runtime_version, epsilon: 0, machines: 0, spins: 0, timing: {}, renders: [], notes: [] };
    var _eps = math_get_epsilon(); math_set_epsilon(0); _st.epsilon = math_get_epsilon();
    var _O = jkp_oracle_core(), _i, _j;

    // 1. the hash and the generator, exact
    jkp_st_stage(_st, 1);
    for (_i = 0; _i < array_length(_O.hashes); _i++) { var _hw = _O.hashes[_i]; var _hg = jkp_hash_string(_hw[0]); jkp_st_assert(_st, _hg == _hw[1], "hash '" + _hw[0] + "' want " + string(_hw[1]) + " got " + string(_hg)); }
    for (_i = 0; _i < array_length(_O.rng); _i++) {
        var _rw = _O.rng[_i], _g = jkp_rng(_rw[0]), _bad = "";
        for (_j = 0; _j < array_length(_rw[1]); _j++) { var _u = jkp_rand(_g); if (_u != _rw[1][_j] && _bad == "") _bad = "draw " + string(_j) + " want " + jkp__st_f(_rw[1][_j]) + " got " + jkp__st_f(_u); }
        jkp_st_assert(_st, _bad == "", "rng seed " + string(_rw[0]) + ": " + _bad);
    }

    // 2. generated machines: every strip, every pay, the name, the exact RTP and line hit after tuning
    jkp_st_stage(_st, 2);
    var _ms = [], _worst = 0;
    for (_i = 0; _i < array_length(_O.machines); _i++) {
        var _e = _O.machines[_i], _t0 = get_timer();
        var _m = jkp_machine_create(_e.opt);
        _worst = max(_worst, (get_timer() - _t0) / 1000);
        array_push(_ms, _m);
        var _enc = jkp__st_enc_machine(_m);
        jkp_st_assert(_st, _enc == _e.enc, "machine #" + string(_i) + ": " + jkp__st_first_diff(_e.enc, _enc));
        jkp_st_assert(_st, jkp__st_close(_m.rtp, _e.rtp, 0.000000000001) && jkp__st_close(_m.lineHit, _e.lineHit, 0.000000000001) && jkp__st_close(_m.target, _e.target, 0.000000000001),
            "machine #" + string(_i) + " rtp " + jkp__st_f(_m.rtp) + " want " + jkp__st_f(_e.rtp) + " / hit " + jkp__st_f(_m.lineHit) + " want " + jkp__st_f(_e.lineHit));
        _st.machines++;
    }
    _st.timing.createWorstMs = _worst;

    // 3. tables, tuning, spins, exhaustive and simulated statistics
    jkp_st_stage(_st, 3);
    for (_i = 0; _i < array_length(_O.tables); _i++) {
        var _T = _O.tables[_i], _tm = _ms[_T.machine], _P = jkp_line_table(_tm), _S = jkp_scatter_table(_tm), _k = 0, _worstP = 0;
        for (var _t = 0; _t < 8; _t++) for (var _r = 3; _r <= _tm.reels; _r++) { _worstP = max(_worstP, abs(_P[_t][_r] - _T.P[_k])); _k++; }
        var _worstS = (array_length(_S) == array_length(_T.S)) ? 0 : 1;
        for (_j = 0; _j < min(array_length(_S), array_length(_T.S)); _j++) _worstS = max(_worstS, abs(_S[_j] - _T.S[_j]));
        jkp_st_assert(_st, _k == array_length(_T.P) && _worstP <= 0.000000000000001 && _worstS <= 0.000000000000001, "tables of machine " + string(_T.machine) + ": worst line diff " + jkp__st_f(_worstP) + ", scatter " + jkp__st_f(_worstS));
        var _rp = jkp_rtp(_tm);
        jkp_st_assert(_st, jkp__st_close(_rp.line, _T.line, 0.000000000001) && jkp__st_close(_rp.scat, _T.scat, 0.000000000001), "rtp parts of machine " + string(_T.machine));
    }
    for (_i = 0; _i < array_length(_O.tunes); _i++) {
        var _U = _O.tunes[_i];
        var _um = jkp_machine_create({ seed: 4242, reels: _U.reels, rtp: _U.target });
        var _pays = ""; for (var _t2 = 0; _t2 < 8; _t2++) _pays += ((_t2 > 0) ? "/" : "") + jkp__st_join(_um.pays[_t2], ".");
        jkp_st_assert(_st, _pays == _U.pays && _um.tuneMoves == _U.moves && jkp__st_close(_um.rtp, _U.rtp, 0.000000000001), "tune " + string(_U.reels) + "-reel to " + string(_U.target) + ": " + jkp__st_first_diff(_U.pays, _pays) + " moves " + string(_um.tuneMoves) + "/" + string(_U.moves));
    }
    for (_i = 0; _i < array_length(_O.spins); _i++) {
        var _SP = _O.spins[_i], _sm = _ms[_SP.machine], _sg = jkp_rng(_SP.seed), _first = "";
        for (_j = 0; _j < array_length(_SP.steps); _j++) {
            var _ev = jkp_spin(_sm, _sg, (_SP.lines > 0) ? _SP.lines : undefined);
            var _got = jkp__st_enc_spin(_ev);
            if (_got != _SP.steps[_j] && _first == "") _first = "spin " + string(_j) + " " + jkp__st_first_diff(_SP.steps[_j], _got);
            _st.spins++;
        }
        jkp_st_assert(_st, _first == "", "spins on machine " + string(_SP.machine) + ": " + _first);
    }
    var _tx0 = get_timer();
    for (_i = 0; _i < array_length(_O.exhaust); _i++) {
        var _X = _O.exhaust[_i], _xs = jkp_exhaust3(_ms[_X.machine]);
        jkp_st_assert(_st, _xs.spins == _X.spins && jkp__st_close(_xs.hitRate, _X.hitRate, 0.000000000001) && jkp__st_close(_xs.rtp, _X.rtp, 0.000000001) && jkp__st_close(_xs.sd, _X.sd, 0.000000001) && jkp__st_close(_xs.maxWin, _X.maxWin, 0.000000001),
            "exhaustive stats of machine " + string(_X.machine) + ": hit " + jkp__st_f(_xs.hitRate) + "/" + jkp__st_f(_X.hitRate) + " rtp " + jkp__st_f(_xs.rtp) + "/" + jkp__st_f(_X.rtp));
        // the property, in the engine itself: playing every stop combination returns EXACTLY what the counts predict
        jkp_st_assert(_st, jkp__st_close(_xs.rtp, jkp_rtp(_ms[_X.machine]).rtp, 0.000000001), "enumeration rtp " + jkp__st_f(_xs.rtp) + " equals the exact rtp " + jkp__st_f(jkp_rtp(_ms[_X.machine]).rtp));
    }
    _st.timing.exhaustMs = (get_timer() - _tx0) / 1000 / max(1, array_length(_O.exhaust));
    var _sx0 = get_timer();
    var _sim = jkp_simulate(_ms[_O.sim.machine], _O.sim.spins, _O.sim.seed);
    _st.timing.simulateMsPerSpin = (get_timer() - _sx0) / 1000 / _O.sim.spins;
    jkp_st_assert(_st, jkp__st_close(_sim.hitRate, _O.sim.hitRate, 0.000000000001) && jkp__st_close(_sim.rtp, _O.sim.rtp, 0.000000001) && jkp__st_close(_sim.maxWin, _O.sim.maxWin, 0.000000001),
        "simulation: hit " + jkp__st_f(_sim.hitRate) + "/" + jkp__st_f(_O.sim.hitRate) + " rtp " + jkp__st_f(_sim.rtp) + "/" + jkp__st_f(_O.sim.rtp));

    // 4. the symbols: every one inked, every pair in a theme told apart, sheets saved to LOOK at
    jkp_st_stage(_st, 4);
    jkp__st_symbols(_st);

    // 5. the playable machine on all three cabinets: scripted spins to a win, the shown reels equal to the decided outcome,
    // credits reconciled, renders saved to LOOK at
    jkp_st_stage(_st, 5);
    jkp__st_slots(_st);

    // 6. the demo room by scripted frames: open, spin to a win, re-tune, switch machine; renders to LOOK at
    jkp_st_stage(_st, 6);
    jkp__st_demo(_st);

    math_set_epsilon(_eps);
    jkp_st_stage(_st, 99);
    return _st;
}

/// @function jkp__st_slots(state)
/// @description Internal. Three machines (upright / slant / bar-top, three themes, three liveries) played by script.
function jkp__st_slots(_st) {
    var _cases = [{ seed: 31, theme: "fruit", cabinet: "upright", reels: 3 }, { seed: 32, theme: "desert", cabinet: "slant", reels: 5 }, { seed: 33, theme: "space", cabinet: "bartop", reels: 5 }];
    for (var _i = 0; _i < array_length(_cases); _i++) {
        var _m = jkp_machine_create(_cases[_i]);
        var _t0 = get_timer();
        var _sl = jkp_slot_create(_m, { credits: 500, lineBet: 2 });
        jkp_slot_prepare(_sl);
        array_push(_st.notes, _m.cabinet + " " + _m.theme + " prepare " + string_format((get_timer() - _t0) / 1000, 1, 0) + " ms");
        var _spent = 0, _won = 0, _spins = 0, _mismatch = 0, _frames = 0;
        repeat (60) {
            var _c0 = _sl.credits;
            if (!jkp_slot_press(_sl, "spin")) break;
            _spent += jkp_slot_bet(_sl); _spins++;
            var _guard = 0;
            while (_sl.state == "spinning" && _guard < 400) { jkp_slot_step(_sl); _guard++; _frames++; }
            jkp_st_assert(_st, _sl.state != "spinning", _m.cabinet + ": the reels stop within 400 frames (" + string(_guard) + ")");
            // what the reels SHOW is what the core decided
            var _shown = jkp_slot_window(_sl), _want = _sl.result.window;
            for (var _r = 0; _r < _m.reels; _r++) for (var _k = 0; _k < 3; _k++) if (_shown[_r][_k] != _want[_r][_k]) _mismatch++;
            _won += _sl.win;
            jkp_st_assert(_st, _sl.credits == _c0 - jkp_slot_bet(_sl) + _sl.win, _m.cabinet + ": credits " + string(_sl.credits) + " = " + string(_c0) + " - bet + win " + string(_sl.win));
            if (_sl.win > 0 && array_length(_sl.result.wins) > 0) break;
        }
        jkp_st_assert(_st, _mismatch == 0, _m.cabinet + ": the reels show the decided window (" + string(_mismatch) + " cells differ over " + string(_spins) + " spins)");
        jkp_st_assert(_st, _sl.win > 0, _m.cabinet + ": a win arrived within 60 spins (" + string(_spins) + ")");
        jkp_st_assert(_st, _sl.credits == 500 - _spent + _won, _m.cabinet + ": the ledger closes (500 - " + string(_spent) + " + " + string(_won) + " = " + string(_sl.credits) + ")");
        var _ev = jkp_slot_events(_sl), _types = "";
        for (var _e = 0; _e < array_length(_ev); _e++) _types += _ev[_e].type + " ";
        jkp_st_assert(_st, string_pos("spin", _types) > 0 && string_pos("reel_stop", _types) > 0 && (string_pos("win", _types) > 0), _m.cabinet + ": events posted (" + string_copy(_types, 1, 80) + ")");
        // the coin fountain stays below whatever sits above the tray (buttons, belly): track the highest coin over the pour
        var _L = jkp_cabinet_layout(_m), _top = 100000, _nCoins = 0, _above = 0;
        for (var _bq = 0; _bq < array_length(_L.buttons); _bq++) if (_L.buttons[_bq].y + _L.buttons[_bq].h <= _L.tray.y + 1) _above = max(_above, _L.buttons[_bq].y + _L.buttons[_bq].h);
        if (!is_undefined(_L.belly)) _above = max(_above, _L.belly.y + _L.belly.h);
        repeat (120) { jkp_slot_step(_sl); for (var _cq = 0; _cq < array_length(_sl.coins); _cq++) { _top = min(_top, _sl.coins[_cq].y); _nCoins++; } }
        jkp_st_assert(_st, _nCoins > 0 && _top - 9 >= _above - 1, _m.cabinet + ": the coins (" + string(_nCoins) + " coin-frames) never rise above the tray's neighbour (highest coin top " + string_format(_top - 9, 1, 1) + ", limit " + string(_above) + ")");
        _sl.coins = []; _sl.coinsToPour = 6; repeat (10) jkp_slot_step(_sl);
        var _surf = surface_create(_L.w + 80, _L.h + 40);
        surface_set_target(_surf); draw_clear(make_colour_rgb(26, 18, 30));
        jkp_slot_draw(_sl, 30, 20, 1);
        surface_reset_target();
        var _fn = "jkp_render_cabinet_" + _m.cabinet + ".png";
        surface_save(_surf, _fn); array_push(_st.renders, _fn); surface_free(_surf);
        if (_i == 1) {
            var _pt = jkp_paytable_bake(_m, 520, 560, 1);
            jkp_st_assert(_st, sprite_exists(_pt), "pay table baked");
            var _ps = surface_create(560, 600); surface_set_target(_ps); draw_clear(make_colour_rgb(26, 18, 30));
            jkp_draw_premul(_pt, 0, 0, 0, 520, 560, 20, 20, 1, 1, 1);
            surface_reset_target(); surface_save(_ps, "jkp_render_paytable.png"); array_push(_st.renders, "jkp_render_paytable.png"); surface_free(_ps);
            sprite_delete(_pt);
        }
        jkp_slot_free(_sl);
        _st.spins += _spins;
    }
}

/// @function jkp__st_symbols(state)
/// @description Internal. Bake every theme's atlas, count ink per symbol (positive control first: an empty cell reads 0),
/// compare every pair of symbols in a theme on a 12 x 12 grid, and save the sheets.
function jkp__st_symbols(_st) {
    var _th = jkp_themes(), _px = 96;
    // control: a blank surface reads no ink
    var _blank = surface_create(64, 64); surface_set_target(_blank); draw_clear_alpha(c_black, 0); surface_reset_target();
    jkp_st_assert(_st, jkp__st_ink(_blank, 0, 0, 64, 64) == 0, "control: a blank surface reads 0 ink");
    surface_free(_blank);
    var _minInk = 1000000, _minDist = 1000000, _minPair = "", _bakeMs = [], _dists = [];
    var _sheetW = 10 * 160, _sheetH = 2 * 200;
    var _sheet = -1;
    for (var _t = 0; _t < array_length(_th); _t++) {
        var _t0 = get_timer();
        var _spr = jkp_symbol_atlas(_t, _px);
        array_push(_bakeMs, (get_timer() - _t0) / 1000);
        jkp_st_assert(_st, sprite_exists(_spr) && sprite_get_width(_spr) == _px * 10 && sprite_get_height(_spr) == _px, "atlas " + _th[_t].id + " is a " + string(_px * 10) + " x " + string(_px) + " sprite");
        var _s = surface_create(_px * 10, _px);
        surface_set_target(_s); draw_clear_alpha(c_black, 0);
        gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_zero); draw_sprite(_spr, 0, 0, 0); gpu_pop_state();
        surface_reset_target();
        var _b = buffer_create(_px * 10 * _px * 4, buffer_fixed, 1);
        buffer_get_surface(_b, _s, 0);
        var _grids = [];
        for (var _k = 0; _k < 10; _k++) {
            var _ink = jkp__st_ink(_s, _k * _px, 0, _px, _px);
            _minInk = min(_minInk, _ink);
            jkp_st_assert(_st, _ink > _px * _px * 0.18, _th[_t].id + " symbol " + jkp_symbol_name(_t, _k) + " inks " + string(_ink) + " px of " + string(_px * _px) + " (floor 18%)");
            // the edge stays clear: a symbol must not be cut by its cell
            var _edge = jkp__st_ink(_s, _k * _px, 0, _px, 1) + jkp__st_ink(_s, _k * _px, _px - 1, _px, 1) + jkp__st_ink(_s, _k * _px, 0, 1, _px) + jkp__st_ink(_s, _k * _px + _px - 1, 0, 1, _px);
            jkp_st_assert(_st, _edge == 0, _th[_t].id + " symbol " + jkp_symbol_name(_t, _k) + " touches its cell edge (" + string(_edge) + " px)");
            array_push(_grids, jkp__st_grid(_b, _px * 10, _k * _px, 0, _px, 12));
        }
        for (var _a = 0; _a < 10; _a++) for (var _c2 = _a + 1; _c2 < 10; _c2++) {
            var _d = jkp__st_grid_dist(_grids[_a], _grids[_c2]);
            array_push(_dists, [_d, _th[_t].id + ": " + jkp_symbol_name(_t, _a) + " / " + jkp_symbol_name(_t, _c2)]);
            if (_d < _minDist) { _minDist = _d; _minPair = _th[_t].id + ": " + jkp_symbol_name(_t, _a) + " / " + jkp_symbol_name(_t, _c2); }
            // the floor (16) sits in the MIDDLE of a measured gap: two runes carved on the SAME stone (the first-build defect,
            // re-made by the control below) measure 13.2; the closest pair of the fixed corpus measured 19.4 (builds 2-3, 2026-10-21)
            jkp_st_assert(_st, _d > 16, _th[_t].id + " symbols " + jkp_symbol_name(_t, _a) + " and " + jkp_symbol_name(_t, _c2) + " are too alike (" + string_format(_d, 1, 1) + ")");
        }
        buffer_delete(_b);
        surface_free(_s);
        // a sheet of two themes at 160 px, on a cream reel ground, to LOOK at
        if ((_t mod 2) == 0) { _sheet = surface_create(_sheetW, _sheetH); surface_set_target(_sheet); draw_clear(make_colour_rgb(246, 240, 226)); surface_reset_target(); }
        var _big = jkp_symbol_atlas(_t, 160);
        surface_set_target(_sheet);
        jkp_draw_premul(_big, 0, 0, 0, 1600, 160, 0, (_t mod 2) * 200 + 20, 1, 1, 1);
        draw_set_colour(make_colour_rgb(60, 40, 30)); draw_set_font(fnt_jackpot_body_s); draw_set_halign(fa_left); draw_set_valign(fa_top);
        draw_text(8, (_t mod 2) * 200 + 176, _th[_t].name);
        surface_reset_target();
        if ((_t mod 2) == 1) { var _fn = "jkp_render_symbols_" + string(_t div 2) + ".png"; surface_save(_sheet, _fn); array_push(_st.renders, _fn); surface_free(_sheet); }
    }
    _st.timing.atlasBakeMs = _bakeMs;
    // CONTROL for the distinctness floor: the defect it exists to catch - two different runes carved on the SAME stone -
    // must measure UNDER it, or the floor is passing everything
    var _px2 = 96, _cs2 = surface_create(_px2 * 4, _px2 * 2), _cs1 = surface_create(_px2 * 2, _px2);
    surface_set_target(_cs2); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    var _cc = jkp_cx_create(2);
    for (var _u = 0; _u < 2; _u++) { jkp_cx_save(_cc); jkp_cx_translate(_cc, _px2 * (_u + 0.5), _px2 * 0.5); jkp_cx_scale(_cc, _px2 * 0.45, _px2 * 0.45); _cc.u = _px2 * 0.9; jkp__p_runes(_cc, _u, 0); jkp_cx_restore(_cc); }
    gpu_pop_state(); surface_reset_target();
    surface_set_target(_cs1); draw_clear_alpha(c_black, 0); gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_zero); gpu_set_texfilter(true); draw_surface_ext(_cs2, 0, 0, 0.5, 0.5, 0, c_white, 1); gpu_pop_state(); surface_reset_target();
    var _cb = buffer_create(_px2 * 2 * _px2 * 4, buffer_fixed, 1); buffer_get_surface(_cb, _cs1, 0);
    var _cd = jkp__st_grid_dist(jkp__st_grid(_cb, _px2 * 2, 0, 0, _px2, 12), jkp__st_grid(_cb, _px2 * 2, _px2, 0, _px2, 12));
    buffer_delete(_cb); surface_free(_cs2); surface_free(_cs1);
    _st.symbolControlSameStone = _cd;
    jkp_st_assert(_st, _cd < 16, "control: Fehu and Uruz carved on the same stone measure " + string_format(_cd, 1, 1) + ", under the floor of 16");
    _st.symbolMinInk = _minInk; _st.symbolMinDistance = _minDist; _st.symbolClosestPair = _minPair;
    // the distribution the floor is read from: the 16 closest pairs of all 360
    array_sort(_dists, function(_p, _q) { return (_p[0] < _q[0]) ? -1 : ((_p[0] > _q[0]) ? 1 : 0); });
    var _low = [];
    for (var _z = 0; _z < min(16, array_length(_dists)); _z++) array_push(_low, string_format(_dists[_z][0], 1, 1) + " " + _dists[_z][1]);
    _st.symbolClosest16 = _low; _st.symbolPairs = array_length(_dists);
    array_push(_st.notes, "closest symbol pair " + _minPair + " at " + string_format(_minDist, 1, 2));
}

/// @function jkp__st_demo_shot(demo, file, state)
/// @description Internal. Draw the game corner into a 960 x 640 surface and save it.
function jkp__st_demo_shot(_d, _fn, _st) {
    var _s = surface_create(JKP_DEMO_W, JKP_DEMO_H);
    surface_set_target(_s); draw_clear(c_black); jkp_demo_draw(_d); surface_reset_target();
    surface_save(_s, _fn); array_push(_st.renders, _fn);
    var _ink = jkp__st_ink(_s, 0, 0, JKP_DEMO_W, JKP_DEMO_H);
    surface_free(_s);
    return _ink;
}

/// @function jkp__st_demo(state)
/// @description Internal. The game corner driven frame by frame as a player would, through its own functions.
function jkp__st_demo(_st) {
    var _d = jkp_demo_create();
    jkp_st_assert(_st, array_length(_d.machines) == 8, "the corner holds eight machines");
    var _themes = {}, _cabs = {}, _reels = {};
    for (var _i = 0; _i < 8; _i++) { _themes[$ _d.machines[_i].theme] = 1; _cabs[$ _d.machines[_i].cabinet] = 1; _reels[$ string(_d.machines[_i].reels)] = 1; }
    jkp_st_assert(_st, array_length(variable_struct_get_names(_themes)) == 8 && array_length(variable_struct_get_names(_cabs)) == 3 && array_length(variable_struct_get_names(_reels)) == 2, "every theme, every cabinet and both reel counts are on the floor");
    var _t0 = get_timer();
    repeat (3) jkp_demo_step(_d);
    _st.timing.demoOpenMs = (get_timer() - _t0) / 1000;
    jkp_st_assert(_st, !is_undefined(_d.slots[0]) && sprite_exists(_d.pays[0]), "machine 1 opened with its pay table");
    // spin machine 1 until a win, through the slot (the demo reads the same functions)
    var _sl = _d.slots[0], _n = 0;
    repeat (80) { jkp_slot_press(_sl, "spin"); var _g = 0; while (_sl.state == "spinning" && _g < 400) { jkp_demo_step(_d); _g++; } _n++; if (_sl.win > 0) break; }
    jkp_st_assert(_st, _sl.win > 0, "the corner paid a win within 80 spins (" + string(_n) + ")");
    repeat (20) jkp_demo_step(_d);
    var _ink = jkp__st_demo_shot(_d, "jkp_render_corner_win.png", _st);
    jkp_st_assert(_st, _ink == JKP_DEMO_W * JKP_DEMO_H, "the corner fills its screen (" + string(_ink) + " px)");
    // re-tune: the exact rtp moves to the new target
    var _m = _d.machines[0], _before = _m.rtp;
    jkp__demo_retune(_d);
    jkp_st_assert(_st, abs(_m.rtp - _m.target) < 0.01 && _m.target != _before, "re-tuned to " + string(_m.target) + ": exact rtp " + string(_m.rtp));
    jkp_st_assert(_st, abs(jkp_rtp(_m).rtp - _m.rtp) < 0.000000001, "the re-tuned rtp is the exact rtp of the new pay table");
    // switch to machine 6 and open it
    _d.loading = 2; _d.cur = 5; repeat (3) jkp_demo_step(_d);
    jkp_st_assert(_st, !is_undefined(_d.slots[5]) && _d.slots[5].credits == _d.purse, "machine 6 opened carrying the purse (" + string(_d.purse) + ")");
    jkp__st_demo_shot(_d, "jkp_render_corner_switch.png", _st);
    jkp_demo_free(_d);
}

/// @function jkp_selftest_write(state)
/// @description Write the suite's result as jkp_selftest.json in the save folder.
function jkp_selftest_write(_st) {
    var _f = file_text_open_write("jkp_selftest.json");
    file_text_write_string(_f, json_stringify(_st));
    file_text_close(_f);
}
