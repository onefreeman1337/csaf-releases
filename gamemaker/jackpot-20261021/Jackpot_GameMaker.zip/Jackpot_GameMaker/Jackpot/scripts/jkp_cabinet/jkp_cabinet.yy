{
  "$GMScript": "v1",
  "%Name": "jkp_cabinet",
  "name": "jkp_cabinet",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}