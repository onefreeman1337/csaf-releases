/// jkp_cabinet.gml - the machine's body: the three cabinets (upright with a lever, slant-top, bar-top) in four liveries,
/// their layout, the static bake (body, marquee, bezel, meter frames, buttons, belly glass, tray), the pay table page,
/// the LED meter digits and the coin. Everything is drawn by the product.
///
/// Jackpot - Generated Slot Machines for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// Sizes are in CABINET PIXELS (the size at scale 1). jkp_cabinet_layout gives every rectangle a game needs to put the
/// machine in a room or to hit-test a mouse: the reel window, the meters, the buttons, the tray, the lever.

#macro JKP_LIVERY_LACQUER 0
#macro JKP_LIVERY_CHROME 1
#macro JKP_LIVERY_WOOD 2
#macro JKP_LIVERY_NOIR 3

/// @function jkp_cabinet_layout(machine)
/// @description Every rectangle of the machine's cabinet at scale 1: { w, h, kind, window: { x, y, w, h, cell }, marquee,
/// meters[3] { x, y, w, h, label }, buttons[] { id, x, y, w, h, label }, belly, tray, lever } (marquee, belly and lever are
/// undefined where the cabinet has none). ids: "betdown" "betup" "lines" "spin". Pure.
/// @returns {Struct}
function jkp_cabinet_layout(_m) {
    if (!jkp__is_machine(_m)) return undefined;
    var _kind = is_string(_m[$ "cabinet"]) ? _m.cabinet : "upright";
    var _cell = (_m.reels == 3) ? 84 : 58;
    var _ww = _cell * _m.reels, _wh = _cell * 3;
    var _L = { kind: _kind, marquee: undefined, belly: undefined, lever: undefined };
    if (_kind == "slant") {
        _L.w = 430; _L.h = 560;
        _L.marquee = { x: 40, y: 0, w: 350, h: 76 };
        _L.window = { x: (430 - _ww) / 2, y: 100, w: _ww, h: _wh, cell: _cell };
        var _my = _L.window.y + _wh + 22;
        _L.meters = [{ x: 60, y: _my, w: 128, h: 40, label: "CREDIT" }, { x: 196, y: _my, w: 74, h: 40, label: "BET" }, { x: 278, y: _my, w: 92, h: 40, label: "WIN" }];
        var _by = _my + 62;
        _L.buttons = [{ id: "betdown", x: 56, y: _by, w: 62, h: 38, label: "BET-" }, { id: "betup", x: 126, y: _by, w: 62, h: 38, label: "BET+" },
            { id: "lines", x: 196, y: _by, w: 70, h: 38, label: "LINES" }, { id: "spin", x: 284, y: _by - 6, w: 92, h: 50, label: "SPIN" }];
        _L.tray = { x: 90, y: _L.h - 64, w: 250, h: 44 };
        var _sb0 = _by + 58;
        if (_L.tray.y - 12 - _sb0 >= 40) _L.belly = { x: 50, y: _sb0, w: 330, h: _L.tray.y - 12 - _sb0 };
    } else if (_kind == "bartop") {
        _L.w = 560; _L.h = 360;
        _L.window = { x: (560 - _ww) / 2, y: 80, w: _ww, h: _wh, cell: _cell };
        var _side = _L.window.y + _wh + 18;
        _L.marquee = { x: 110, y: 4, w: 340, h: 58 };
        _L.meters = [{ x: 70, y: _side, w: 150, h: 38, label: "CREDIT" }, { x: 236, y: _side, w: 88, h: 38, label: "BET" }, { x: 340, y: _side, w: 150, h: 38, label: "WIN" }];
        var _by2 = _side + 54;
        _L.buttons = [{ id: "betdown", x: 70, y: _by2, w: 70, h: 34, label: "BET-" }, { id: "betup", x: 150, y: _by2, w: 70, h: 34, label: "BET+" },
            { id: "lines", x: 230, y: _by2, w: 80, h: 34, label: "LINES" }, { id: "spin", x: 360, y: _by2 - 4, w: 130, h: 42, label: "SPIN" }];
        _L.tray = { x: 20, y: _L.h - 30, w: 520, h: 26 };
        _L.h = max(_L.h, _by2 + 34 + 40);
        _L.tray.y = _L.h - 30;
    } else {
        _L.w = 400; _L.h = 640;
        _L.marquee = { x: 10, y: 0, w: 360, h: 104 };
        _L.window = { x: 190 - _ww / 2, y: 132, w: _ww, h: _wh, cell: _cell };
        var _my3 = _L.window.y + _wh + 22;
        _L.meters = [{ x: 40, y: _my3, w: 124, h: 40, label: "CREDIT" }, { x: 172, y: _my3, w: 66, h: 40, label: "BET" }, { x: 246, y: _my3, w: 104, h: 40, label: "WIN" }];
        var _by3 = _my3 + 58;
        _L.buttons = [{ id: "betdown", x: 36, y: _by3, w: 58, h: 36, label: "BET-" }, { id: "betup", x: 100, y: _by3, w: 58, h: 36, label: "BET+" },
            { id: "lines", x: 164, y: _by3, w: 66, h: 36, label: "LINES" }, { id: "spin", x: 248, y: _by3 - 6, w: 106, h: 48, label: "SPIN" }];
        var _belly0 = _by3 + 56;
        _L.tray = { x: 70, y: _L.h - 66, w: 240, h: 44 };
        if (_L.tray.y - 12 - _belly0 >= 40) _L.belly = { x: 40, y: _belly0, w: 300, h: _L.tray.y - 12 - _belly0 };
        _L.lever = { x: 382, y: 250, len: 150 };
    }
    return _L;
}

/// @function jkp__livery(machine)
/// @description Internal. The cabinet's materials: { body, edge, trim, glass, panel } as [r, g, b] by livery and theme.
function jkp__livery(_m) {
    var _tc = jkp_theme_colours(_m.themeIndex);
    switch (_m.livery) {
        case JKP_LIVERY_CHROME: return { body: [176, 184, 198], edge: [60, 66, 80], trim: _tc.accent, panel: jkp__dk(_tc.deep, 0.2), glow: _tc.glow, metal: [236, 240, 248] };
        case JKP_LIVERY_WOOD: return { body: [120, 70, 36], edge: [44, 22, 10], trim: [230, 180, 80], panel: jkp__dk(_tc.deep, 0.3), glow: _tc.glow, metal: [236, 190, 90] };
        case JKP_LIVERY_NOIR: return { body: [34, 30, 40], edge: [8, 6, 10], trim: [240, 190, 70], panel: jkp__dk(_tc.deep, 0.4), glow: _tc.glow, metal: [246, 200, 90] };
    }
    return { body: _tc.accent, edge: jkp__dk(_tc.deep, 0.5), trim: [240, 196, 80], panel: jkp__dk(_tc.deep, 0.3), glow: _tc.glow, metal: [246, 206, 100] };
}

/// @function jkp__cab_fill_x(ctx, x0, x1, base, [alpha])
/// @description Internal. Fill the current path with a horizontal cylinder ramp (dark edge, lit band left of centre).
function jkp__cab_fill_x(_c, _x0, _x1, _base, _a = 1) {
    var _g = jkp_cx_linear(_c, _x0, 0, _x1, 0);
    jkp_cx_stop(_g, 0, jkp__dk(_base, 0.55), _a); jkp_cx_stop(_g, 0.18, jkp__lit(_base, 0.22), _a); jkp_cx_stop(_g, 0.32, jkp__lit(_base, 0.4), _a);
    jkp_cx_stop(_g, 0.6, _base, _a); jkp_cx_stop(_g, 0.88, jkp__dk(_base, 0.3), _a); jkp_cx_stop(_g, 1, jkp__dk(_base, 0.6), _a);
    _c.fill = _g; jkp_cx_fill(_c);
}
/// @function jkp__cab_fill_y(ctx, y0, y1, top, bottom, [alpha])
function jkp__cab_fill_y(_c, _y0, _y1, _top, _bot, _a = 1) {
    var _g = jkp_cx_linear(_c, 0, _y0, 0, _y1); jkp_cx_stop(_g, 0, _top, _a); jkp_cx_stop(_g, 1, _bot, _a); _c.fill = _g; jkp_cx_fill(_c);
}

/// @function jkp__cab_wood(ctx, x, y, w, h, base)
/// @description Internal. Wood grain over a rectangle: long wavy lines in the timber's own dark and light.
function jkp__cab_wood(_c, _x, _y, _w, _h, _base, _seed) {
    var _g = jkp_rng(_seed);
    for (var _i = 0; _i < floor(_w / 7); _i++) {
        var _gx = _x + (_i + jkp_rand(_g)) * 7, _amp = 2 + jkp_rand(_g) * 3, _ph = jkp_rand(_g) * 6;
        jkp_cx_begin(_c); jkp_cx_move(_c, _gx, _y);
        for (var _k = 1; _k <= 12; _k++) jkp_cx_line(_c, _gx + sin(_ph + _k * 0.9) * _amp, _y + _h * _k / 12);
        jkp__s_line(_c, (_i mod 2 == 0) ? jkp__dk(_base, 0.35) : jkp__lit(_base, 0.18), 1.2, 0.45);
    }
}

/// @function jkp__cab_bezel(ctx, x, y, w, h, r, metal, depth)
/// @description Internal. A raised metal frame round a rectangle: an outer lit lip, the band, an inner dark lip.
function jkp__cab_bezel(_c, _x, _y, _w, _h, _r, _metal, _t) {
    jkp_cx_begin(_c); jkp_cx_round_rect(_c, _x - _t, _y - _t, _w + _t * 2, _h + _t * 2, _r + _t);
    jkp_cx_shadow(_c, [0, 0, 0], 0.55, 10, 0, 4);
    var _g = jkp_cx_linear(_c, 0, _y - _t, 0, _y + _h + _t);
    jkp_cx_stop(_g, 0, jkp__lit(_metal, 0.55)); jkp_cx_stop(_g, 0.25, _metal); jkp_cx_stop(_g, 0.55, jkp__dk(_metal, 0.35)); jkp_cx_stop(_g, 0.8, _metal); jkp_cx_stop(_g, 1, jkp__dk(_metal, 0.5));
    _c.fill = _g; jkp_cx_fill(_c);
    jkp__s_line(_c, jkp__dk(_metal, 0.7), 1.5);
    jkp_cx_begin(_c); jkp_cx_round_rect(_c, _x - _t * 0.45, _y - _t * 0.45, _w + _t * 0.9, _h + _t * 0.9, _r + _t * 0.45); jkp__s_line(_c, jkp__lit(_metal, 0.7), 1.2, 0.8);
    jkp_cx_begin(_c); jkp_cx_round_rect(_c, _x - 1, _y - 1, _w + 2, _h + 2, _r); jkp__s_line(_c, jkp__dk(_metal, 0.75), 2.5);
}

/// @function jkp__cab_button(ctx, b, rgb, theme)
/// @description Internal. A domed push button with its label.
function jkp__cab_button(_c, _b, _rgb, _lit) {
    jkp_cx_begin(_c); jkp_cx_round_rect(_c, _b.x, _b.y, _b.w, _b.h, min(12, _b.h / 2));
    jkp_cx_shadow(_c, [0, 0, 0], 0.6, 6, 0, 3);
    var _g = jkp_cx_linear(_c, 0, _b.y, 0, _b.y + _b.h);
    jkp_cx_stop(_g, 0, jkp__lit(_rgb, 0.55)); jkp_cx_stop(_g, 0.45, _rgb); jkp_cx_stop(_g, 1, jkp__dk(_rgb, 0.45));
    _c.fill = _g; jkp_cx_fill(_c);
    jkp__s_line(_c, jkp__dk(_rgb, 0.7), 1.6);
    jkp_cx_begin(_c); jkp_cx_round_rect(_c, _b.x + 4, _b.y + 3, _b.w - 8, _b.h * 0.38, min(9, _b.h / 3)); jkp__s_flat(_c, [255, 255, 255], 0.28);
    var _px = min(_b.h * 0.42, (_b.w - 10) / max(0.01, jkp_text_width(_b.label, 1, JKP_FACE_DISPLAY)));
    jkp__s_text(_c, _b.label, _b.x + _b.w / 2, _b.y + _b.h / 2 + 1, _px, JKP_FACE_DISPLAY, _lit, jkp__dk(_rgb, 0.75), 1.2);
}

/// @function jkp__cab_paint(ctx, machine, layout)
/// @description Internal. Paint the static cabinet at scale 1 under ctx's transform.
function jkp__cab_paint(_c, _m, _L) {
    var _lv = jkp__livery(_m), _tc = jkp_theme_colours(_m.themeIndex), _kind = _L.kind, _W = _L.w, _H = _L.h;
    var _bx0, _bx1;
    // 1. the body silhouette
    jkp_cx_begin(_c);
    if (_kind == "slant") { _bx0 = 8; _bx1 = _W - 8; jkp__s_poly(_c, [40, 60, _W - 40, 60, _W - 8, _H - 6, 8, _H - 6]); }
    else if (_kind == "bartop") { _bx0 = 6; _bx1 = _W - 6; jkp__s_poly(_c, [30, 0, _W - 30, 0, _W - 6, _H - 40, _W - 6, _H - 4, 6, _H - 4, 6, _H - 40]); }
    else { _bx0 = 14; _bx1 = 366; jkp_cx_round_rect(_c, 14, 90, 352, _H - 96, 16); }
    jkp_cx_shadow(_c, [0, 0, 0], 0.6, 18, 4, 8);
    jkp__cab_fill_x(_c, _bx0, _bx1, _lv.body);
    jkp__s_line(_c, _lv.edge, 2.2);
    if (_m.livery == JKP_LIVERY_WOOD) {
        jkp_cx_save(_c);
        jkp_cx_begin(_c);
        if (_kind == "slant") jkp__s_poly(_c, [40, 60, _W - 40, 60, _W - 8, _H - 6, 8, _H - 6]);
        else if (_kind == "bartop") jkp__s_poly(_c, [30, 0, _W - 30, 0, _W - 6, _H - 40, _W - 6, _H - 4, 6, _H - 4, 6, _H - 40]);
        else jkp_cx_round_rect(_c, 14, 90, 352, _H - 96, 16);
        jkp_cx_clip(_c);
        jkp__cab_wood(_c, _bx0, 0, _bx1 - _bx0, _H, _lv.body, _m.seed);
        jkp_cx_restore(_c);
    }
    // side pillars (upright) with trim strips
    if (_kind == "upright") {
        for (var _s = 0; _s < 2; _s++) {
            var _px = (_s == 0) ? 14 : 336;
            jkp_cx_begin(_c); jkp_cx_round_rect(_c, _px, 96, 30, _H - 108, 10); jkp__cab_fill_x(_c, _px, _px + 30, jkp__dk(_lv.body, 0.25));
            jkp_cx_begin(_c); jkp_cx_rect(_c, _px + 12, 110, 6, _H - 136); jkp__cab_fill_x(_c, _px + 12, _px + 18, _lv.trim);
        }
    }
    // 2. the marquee: a lit sign box, bulb sockets, the machine's name
    if (!is_undefined(_L.marquee)) {
        var _q = _L.marquee;
        jkp_cx_begin(_c);
        if (_kind == "upright") { jkp_cx_move(_c, _q.x, _q.y + _q.h); jkp_cx_line(_c, _q.x, _q.y + 34); jkp_cx_bezier(_c, _q.x, _q.y - 6, _q.x + _q.w, _q.y - 6, _q.x + _q.w, _q.y + 34); jkp_cx_line(_c, _q.x + _q.w, _q.y + _q.h); jkp_cx_close(_c); }
        else jkp_cx_round_rect(_c, _q.x, _q.y, _q.w, _q.h, 14);
        jkp_cx_shadow(_c, [0, 0, 0], 0.5, 10, 0, 4);
        jkp__cab_fill_y(_c, _q.y, _q.y + _q.h, jkp__lit(_lv.trim, 0.3), jkp__dk(_lv.trim, 0.35));
        jkp__s_line(_c, jkp__dk(_lv.trim, 0.7), 2);
        var _ix = _q.x + 14, _iy = _q.y + ((_kind == "upright") ? 26 : 12), _iw = _q.w - 28, _ih = _q.h - ((_kind == "upright") ? 40 : 24);
        jkp_cx_begin(_c); jkp_cx_round_rect(_c, _ix, _iy, _iw, _ih, 10);
        var _gm = jkp_cx_radial(_c, _ix + _iw / 2, _iy + _ih * 0.4, 4, _ix + _iw / 2, _iy + _ih / 2, _iw * 0.6);
        jkp_cx_stop(_gm, 0, jkp__lit(_tc.accent, 0.35)); jkp_cx_stop(_gm, 0.6, _tc.accent); jkp_cx_stop(_gm, 1, _tc.deep);
        _c.fill = _gm; jkp_cx_fill(_c);
        jkp__s_line(_c, jkp__dk(_lv.trim, 0.6), 1.5);
        // rays behind the name
        for (var _r = 0; _r < 18; _r++) {
            var _a = _r / 18 * 2 * pi, _cx = _ix + _iw / 2, _cy = _iy + _ih / 2;
            jkp_cx_save(_c); jkp_cx_begin(_c); jkp_cx_round_rect(_c, _ix, _iy, _iw, _ih, 10); jkp_cx_clip(_c);
            jkp_cx_begin(_c); jkp__s_poly(_c, [_cx, _cy, _cx + cos(_a - 0.08) * _iw, _cy + sin(_a - 0.08) * _iw, _cx + cos(_a + 0.08) * _iw, _cy + sin(_a + 0.08) * _iw]);
            jkp__s_flat(_c, _tc.glow, 0.12);
            jkp_cx_restore(_c);
        }
        var _name = string_upper(_m.name);
        var _npx = min(_ih * 0.62, (_iw - 20) / max(0.01, jkp_text_width(_name, 1, JKP_FACE_DISPLAY)));
        jkp__s_text(_c, _name, _ix + _iw / 2, _iy + _ih / 2 + 1, _npx, JKP_FACE_DISPLAY, _lv.metal, jkp__dk(_tc.deep, 0.6), max(1.2, _npx * 0.07));
        jkp__s_text(_c, _name, _ix + _iw / 2, _iy + _ih / 2 - _npx * 0.04, _npx, JKP_FACE_DISPLAY, jkp__lit(_lv.metal, 0.5));
        // the bulb sockets (the bulbs themselves are drawn live, so they can chase)
        var _bulbs = jkp__cab_bulbs(_L);
        for (var _b = 0; _b < array_length(_bulbs); _b++) { jkp_cx_begin(_c); jkp__s_circle(_c, _bulbs[_b][0], _bulbs[_b][1], 5.5); jkp__s_flat(_c, jkp__dk(_lv.trim, 0.6)); }
    }
    // 3. the reel window bezel and its dark well
    var _w = _L.window;
    jkp__cab_bezel(_c, _w.x, _w.y, _w.w, _w.h, 6, _lv.metal, 14);
    jkp_cx_begin(_c); jkp_cx_rect(_c, _w.x, _w.y, _w.w, _w.h); jkp__s_flat(_c, [12, 10, 16]);
    // payline markers on both sides of the window
    var _nl = array_length(_m.lines);
    for (var _li = 0; _li < _nl; _li++) {
        var _ly = jkp__line_marker_y(_m, _L, _li);
        for (var _side = 0; _side < 2; _side++) {
            var _mx = (_side == 0) ? _w.x - 13 : _w.x + _w.w + 13;
            jkp_cx_begin(_c); jkp__s_circle(_c, _mx, _ly, (_nl > 5) ? 4.2 : 6); jkp__s_flat(_c, jkp__line_colour(_li));
            jkp__s_line(_c, [20, 16, 20], 0.8);
        }
    }
    // 4. meter frames and their labels
    for (var _k = 0; _k < 3; _k++) {
        var _mt = _L.meters[_k];
        jkp_cx_begin(_c); jkp_cx_round_rect(_c, _mt.x, _mt.y, _mt.w, _mt.h, 6); jkp_cx_shadow(_c, [0, 0, 0], 0.5, 5, 0, 2); jkp__s_flat(_c, [10, 8, 12]);
        jkp__s_line(_c, _lv.metal, 2);
        jkp__s_text(_c, _mt.label, _mt.x + _mt.w / 2, _mt.y - 7, 9, JKP_FACE_DISPLAY, _lv.metal, jkp__dk(_lv.body, 0.6), 1);
    }
    // 5. the button deck
    var _b0 = _L.buttons[0], _bl = _L.buttons[array_length(_L.buttons) - 1];
    jkp_cx_begin(_c); jkp_cx_round_rect(_c, _b0.x - 12, _bl.y - 8, _bl.x + _bl.w - _b0.x + 24, max(_b0.h, _bl.h) + 22, 10);
    jkp__cab_fill_y(_c, _bl.y - 8, _bl.y + _bl.h + 14, jkp__lit(_lv.panel, 0.2), jkp__dk(_lv.panel, 0.4));
    jkp__s_line(_c, _lv.metal, 1.6);
    for (var _bt = 0; _bt < array_length(_L.buttons); _bt++) {
        var _bb = _L.buttons[_bt];
        var _col = (_bb.id == "spin") ? [220, 40, 40] : ((_bb.id == "lines") ? [40, 140, 220] : [236, 180, 40]);
        jkp__cab_button(_c, _bb, _col, [255, 250, 236]);
    }
    // 6. the belly glass: the top symbol on a burst, and what it pays
    if (!is_undefined(_L.belly)) {
        var _bg = _L.belly;
        jkp_cx_begin(_c); jkp_cx_round_rect(_c, _bg.x, _bg.y, _bg.w, _bg.h, 8);
        jkp__cab_fill_y(_c, _bg.y, _bg.y + _bg.h, _tc.accent, _tc.deep);
        jkp__s_line(_c, _lv.metal, 2);
        var _sz = min(_bg.h - 8, 70);
        jkp_symbol_paint(_c, _m.themeIndex, 7, _bg.x + 14 + _sz / 2, _bg.y + _bg.h / 2, _sz);
        var _top = jkp_pay(_m, 7, _m.reels);
        var _t1 = "PAYS " + string(_top) + "x";
        var _tpx = min(_bg.h * 0.32, (_bg.w - _sz - 40) / max(0.01, jkp_text_width(_t1, 1, JKP_FACE_DISPLAY)));
        jkp__s_text(_c, _t1, _bg.x + 24 + _sz + (_bg.w - _sz - 30) / 2, _bg.y + _bg.h * 0.36, _tpx, JKP_FACE_DISPLAY, _lv.metal, jkp__dk(_tc.deep, 0.6), 1.2);
        var _t2 = string(_m.reels) + " x " + string_upper(jkp_symbol_name(_m.themeIndex, 7)) + " - " + string(array_length(_m.lines)) + " LINES";
        var _t2px = min(_bg.h * 0.2, (_bg.w - _sz - 40) / max(0.01, jkp_text_width(_t2, 1, JKP_FACE_BODY)));
        jkp__s_text(_c, _t2, _bg.x + 24 + _sz + (_bg.w - _sz - 30) / 2, _bg.y + _bg.h * 0.72, _t2px, JKP_FACE_BODY, jkp__lit(_tc.glow, 0.4));
    }
    // 7. the coin tray
    var _tr = _L.tray;
    jkp_cx_begin(_c); jkp_cx_round_rect(_c, _tr.x, _tr.y, _tr.w, _tr.h, 10); jkp__cab_fill_y(_c, _tr.y, _tr.y + _tr.h, [70, 70, 80], [196, 200, 214]);
    jkp__s_line(_c, _lv.metal, 2);
    jkp_cx_begin(_c); jkp_cx_round_rect(_c, _tr.x + 8, _tr.y + 6, _tr.w - 16, _tr.h - 12, 7); jkp__cab_fill_y(_c, _tr.y + 6, _tr.y + _tr.h - 6, [14, 12, 18], [60, 58, 70]);
    // 8. the lever's mount (the lever itself moves, so it is drawn live)
    if (!is_undefined(_L.lever)) {
        jkp_cx_begin(_c); jkp_cx_round_rect(_c, 362, _L.lever.y - 22, 26, 44, 8); jkp__cab_fill_x(_c, 362, 388, _lv.metal); jkp__s_line(_c, jkp__dk(_lv.metal, 0.6), 1.5);
    }
}

/// @function jkp__cab_bulbs(layout)
/// @description Internal. The marquee bulb positions [[x, y], ...] in chase order.
function jkp__cab_bulbs(_L) {
    var _o = [];
    if (is_undefined(_L.marquee)) return _o;
    var _q = _L.marquee, _n = 13, _top = (_L.kind == "upright") ? _q.y + 16 : _q.y + 6;
    for (var _i = 0; _i < _n; _i++) array_push(_o, [_q.x + 14 + (_q.w - 28) * _i / (_n - 1), _top]);
    for (var _j = 1; _j < 4; _j++) array_push(_o, [_q.x + _q.w - 7, _top + (_q.y + _q.h - 8 - _top) * _j / 4]);
    for (var _k = _n - 1; _k >= 0; _k--) array_push(_o, [_q.x + 14 + (_q.w - 28) * _k / (_n - 1), _q.y + _q.h - 6]);
    for (var _l = 3; _l >= 1; _l--) array_push(_o, [_q.x + 7, _top + (_q.y + _q.h - 8 - _top) * _l / 4]);
    return _o;
}

/// @function jkp__line_colour(line)
/// @description Internal. A payline's colour (a GameMaker colour), distinct for the first ten and cycling after.
function jkp__line_colour(_i) {
    static _p = [[255, 70, 70], [255, 200, 40], [80, 220, 100], [70, 170, 255], [230, 90, 255], [255, 140, 40], [60, 230, 220], [255, 110, 180], [180, 230, 60], [140, 140, 255]];
    return _p[_i mod 10];
}

/// @function jkp__line_marker_y(machine, layout, line)
/// @description Internal. Where a payline's side marker sits: its first row, spread so markers sharing a row do not overlap.
function jkp__line_marker_y(_m, _L, _li) {
    var _w = _L.window, _row = _m.lines[_li][0], _same = 0, _idx = 0;
    for (var _k = 0; _k < array_length(_m.lines); _k++) if (_m.lines[_k][0] == _row) { if (_k == _li) _idx = _same; _same++; }
    var _span = _w.cell * 0.8;
    return _w.y + (_row + 0.5) * _w.cell + ((_same > 1) ? (_idx / (_same - 1) - 0.5) * _span : 0);
}

/// @function jkp_cabinet_bake(machine, [res])
/// @description Bake the machine's static cabinet into a PREMULTIPLIED sprite at `res` x its size (default 1; 2 for a
/// store image), drawn at 2x that and filtered down. Costs a bake (a fraction of a second to about a second on the VM):
/// call it once, keep the sprite, sprite_delete it when the machine goes. Draw it with jkp_draw_premul. -1 for a bad machine.
/// @returns {Asset.GMSprite}
function jkp_cabinet_bake(_m, _res = 1) {
    var _L = jkp_cabinet_layout(_m);
    if (is_undefined(_L) || !is_numeric(_res) || !(_res > 0) || _res > 4) return -1;
    var _w = ceil(_L.w * _res), _h = ceil(_L.h * _res);
    var _s2 = surface_create(_w * 2, _h * 2), _s1 = surface_create(_w, _h);
    var _pm = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_build_identity());
    surface_set_target(_s2); draw_clear_alpha(c_black, 0);
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false);
    var _c = jkp_cx_create(2);
    jkp_cx_scale(_c, _res, _res);
    jkp__cab_paint(_c, _m, _L);
    gpu_pop_state();
    surface_reset_target();
    surface_set_target(_s1); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_zero); gpu_set_texfilter(true);
    draw_surface_ext(_s2, 0, 0, 0.5, 0.5, 0, c_white, 1);
    gpu_pop_state();
    surface_reset_target();
    var _spr = sprite_create_from_surface(_s1, 0, 0, _w, _h, false, false, 0, 0);
    surface_free(_s2); surface_free(_s1);
    matrix_set(matrix_world, _pm);
    return _spr;
}

/// @function jkp_paytable_bake(machine, w, h, [res])
/// @description Bake the machine's PAY TABLE page (w x h cabinet pixels): every pay symbol with what 3 / 4 / 5 pay, the
/// wild and scatter rules, the paylines as little grids, and the EXACT return-to-player and line hit rate. Premultiplied
/// sprite; re-bake after jkp_tune (the figures change). -1 for a bad machine or size.
/// @returns {Asset.GMSprite}
function jkp_paytable_bake(_m, _pw, _ph, _res = 1) {
    if (!jkp__is_machine(_m) || !is_numeric(_pw) || !is_numeric(_ph) || _pw < 160 || _ph < 160 || _pw > 2048 || _ph > 2048) return -1;
    var _w = ceil(_pw * _res), _h = ceil(_ph * _res);
    var _s2 = surface_create(_w * 2, _h * 2), _s1 = surface_create(_w, _h);
    var _pm = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_build_identity());
    surface_set_target(_s2); draw_clear_alpha(c_black, 0);
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    var _c = jkp_cx_create(2);
    jkp_cx_scale(_c, _res, _res);
    jkp__paytable_paint(_c, _m, _pw, _ph);
    gpu_pop_state();
    surface_reset_target();
    surface_set_target(_s1); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_zero); gpu_set_texfilter(true);
    draw_surface_ext(_s2, 0, 0, 0.5, 0.5, 0, c_white, 1);
    gpu_pop_state();
    surface_reset_target();
    var _spr = sprite_create_from_surface(_s1, 0, 0, _w, _h, false, false, 0, 0);
    surface_free(_s2); surface_free(_s1);
    matrix_set(matrix_world, _pm);
    return _spr;
}

/// @function jkp__paytable_paint(ctx, machine, w, h)
function jkp__paytable_paint(_c, _m, _W, _H) {
    var _tc = jkp_theme_colours(_m.themeIndex), _lv = jkp__livery(_m);
    jkp_cx_begin(_c); jkp_cx_round_rect(_c, 2, 2, _W - 4, _H - 4, 14);
    jkp__cab_fill_y(_c, 0, _H, jkp__dk(_tc.deep, 0.1), jkp__dk(_tc.deep, 0.55));
    jkp__s_line(_c, _lv.metal, 3);
    var _title = string_upper(_m.name) + "  PAYS";
    var _tpx = min(26, (_W - 40) / max(0.01, jkp_text_width(_title, 1, JKP_FACE_DISPLAY)));
    jkp__s_text(_c, _title, _W / 2, 26, _tpx, JKP_FACE_DISPLAY, _lv.metal, [0, 0, 0], 1.2);
    // rows: the eight pay symbols, highest first, two columns
    var _top = 50, _bottom = _H - 112, _rows = 4, _colW = (_W - 30) / 2, _rowH = (_bottom - _top) / _rows;
    var _sym = min(_rowH - 8, 64);
    for (var _i = 0; _i < 8; _i++) {
        var _t = 7 - _i, _cx = 15 + (_i div _rows) * _colW, _cy = _top + (_i mod _rows) * _rowH;
        jkp_cx_begin(_c); jkp_cx_round_rect(_c, _cx + 2, _cy + 3, _colW - 4, _rowH - 6, 8); jkp__s_flat(_c, [255, 255, 255], 0.06);
        jkp_symbol_paint(_c, _m.themeIndex, _t, _cx + 6 + _sym / 2, _cy + _rowH / 2, _sym);
        var _line = "";
        for (var _k = _m.reels; _k >= 3; _k--) _line += string(_k) + "x " + string(jkp_pay(_m, _t, _k)) + ((_k > 3) ? "   " : "");
        var _lpx = min(_rowH * 0.3, (_colW - _sym - 22) / max(0.01, jkp_text_width(_line, 1, JKP_FACE_BODY)));
        jkp__s_text(_c, string_upper(jkp_symbol_name(_m.themeIndex, _t)), _cx + 14 + _sym + (_colW - _sym - 18) / 2, _cy + _rowH * 0.33, min(_rowH * 0.24, 15), JKP_FACE_DISPLAY, _tc.glow);
        jkp__s_text(_c, _line, _cx + 14 + _sym + (_colW - _sym - 18) / 2, _cy + _rowH * 0.68, _lpx, JKP_FACE_BODY, [250, 246, 236]);
    }
    // wild and scatter
    // wild and scatter: each a symbol, a heading and its rule on two lines
    var _ry = _bottom + 4, _rs = 44, _colw = _W / 2 - _rs - 30;
    var _cnt = "", _pay = "";
    for (var _j = 0; _j < array_length(_m.scatterPays); _j++) if (_m.scatterPays[_j] > 0) { _cnt += ((_cnt == "") ? "" : " / ") + string(_j); _pay += ((_pay == "") ? "" : " / ") + string(_m.scatterPays[_j]); }
    var _rules = [["WILD", "Stands in for every pay symbol"], ["SCATTER", _cnt + " anywhere pay " + _pay + "x total bet"]];
    for (var _q = 0; _q < 2; _q++) {
        var _qx = 15 + _q * (_W / 2 - 5);
        jkp_symbol_paint(_c, _m.themeIndex, (_q == 0) ? JKP_WILD : JKP_SCATTER, _qx + _rs / 2, _ry + _rs / 2, _rs);
        jkp__s_text(_c, _rules[_q][0], _qx + _rs + 8 + _colw / 2, _ry + 12, 13, JKP_FACE_DISPLAY, _tc.glow);
        jkp__s_text(_c, _rules[_q][1], _qx + _rs + 8 + _colw / 2, _ry + 31, min(13, _colw / max(0.01, jkp_text_width(_rules[_q][1], 1, JKP_FACE_BODY))), JKP_FACE_BODY, [250, 246, 236]);
    }
    // the exact figures
    var _f = "RETURN TO PLAYER " + string_format(_m.rtp * 100, 1, 2) + "% (EXACT)   EACH LINE WINS 1 SPIN IN " + string_format(1 / max(0.000001, _m.lineHit), 1, 1);
    var _fpx = min(13, (_W - 30) / max(0.01, jkp_text_width(_f, 1, JKP_FACE_DISPLAY)));
    jkp__s_text(_c, _f, _W / 2, _H - 54, _fpx, JKP_FACE_DISPLAY, _lv.metal);
    // the paylines as little grids
    var _nl = array_length(_m.lines), _gw = min(26, (_W - 30) / _nl - 4), _gh = _gw * 3 / _m.reels;
    var _gx0 = (_W - _nl * (_gw + 4)) / 2;
    for (var _l = 0; _l < _nl; _l++) {
        var _gx = _gx0 + _l * (_gw + 4), _gy = _H - 36;
        jkp_cx_begin(_c); jkp_cx_rect(_c, _gx, _gy, _gw, _gh); jkp__s_flat(_c, [0, 0, 0], 0.35);
        var _rgb = jkp__line_colour(_l);
        jkp_cx_begin(_c);
        for (var _r = 0; _r < _m.reels; _r++) { var _px = _gx + (_r + 0.5) * _gw / _m.reels, _py = _gy + (_m.lines[_l][_r] + 0.5) * _gh / 3; if (_r == 0) jkp_cx_move(_c, _px, _py); else jkp_cx_line(_c, _px, _py); }
        jkp__s_line(_c, _rgb, 1.6);
    }
}

/// @function jkp_coin_sprite(px)
/// @description A gold coin, face on, px pixels across: a premultiplied sprite cached per size (drawn by the coin shower).
/// @returns {Asset.GMSprite}
function jkp_coin_sprite(_px) {
    _px = clamp(floor(is_numeric(_px) ? _px : 24), 8, 128);
    if (!variable_global_exists("jkp_coin_cache")) global.jkp_coin_cache = {};
    var _k = string(_px), _hit = global.jkp_coin_cache[$ _k];
    if (!is_undefined(_hit) && sprite_exists(_hit)) return _hit;
    var _s2 = surface_create(_px * 2, _px * 2), _s1 = surface_create(_px, _px);
    var _pm = matrix_get(matrix_world); matrix_set(matrix_world, matrix_build_identity());
    surface_set_target(_s2); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    var _c = jkp_cx_create(2);
    jkp_cx_translate(_c, _px / 2, _px / 2); jkp_cx_scale(_c, _px / 2 * 0.94, _px / 2 * 0.94); _c.u = _px;
    jkp_cx_begin(_c); jkp__s_circle(_c, 0, 0, 1); jkp__s_body(_c, [244, 190, 50], 0, 0, 1, 0.08, false);
    jkp_cx_begin(_c); jkp__s_circle(_c, 0, 0, 0.72); jkp__s_line(_c, [180, 120, 20], 0.08);
    jkp_cx_begin(_c); jkp__s_poly(_c, jkp__s_rpoly(0, 0.04, 0.48, 5, -pi / 2, 0.45)); jkp__s_flat(_c, [255, 226, 120]);
    jkp__s_shine(_c, -0.3, -0.45, 0.4, 0.18, -0.4, 0.7);
    gpu_pop_state(); surface_reset_target();
    surface_set_target(_s1); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_zero); gpu_set_texfilter(true); draw_surface_ext(_s2, 0, 0, 0.5, 0.5, 0, c_white, 1); gpu_pop_state();
    surface_reset_target();
    var _spr = sprite_create_from_surface(_s1, 0, 0, _px, _px, false, false, _px / 2, _px / 2);
    surface_free(_s2); surface_free(_s1);
    matrix_set(matrix_world, _pm);
    global.jkp_coin_cache[$ _k] = _spr;
    return _spr;
}

/// @function jkp_draw_led(x, y, h, text, colour, [alpha])
/// @description Draw text in seven-segment LED digits (0-9, space, minus), each lit segment with a glow and the unlit
/// segments faintly visible, h pixels tall, right-aligned to x. Native primitives: cheap enough for every frame.
function jkp_draw_led(_x, _y, _h, _s, _col, _a = 1) {
    static _seg = [119, 36, 93, 109, 46, 107, 123, 37, 127, 111];   // bits: a b c d e f g = 1 2 4 8 16 32 64 (a top, b upper-left, c upper-right, d middle, e lower-left, f lower-right, g bottom)
    // positions, size and colour must be numbers (a refusal draws nothing); the text may be anything string() can print
    if (!is_numeric(_x) || !is_numeric(_y) || !is_numeric(_h) || !(_h > 0) || _h > 4096 || !is_numeric(_col) || !is_numeric(_a)) return;
    var _t = string(_s), _n = min(string_length(_t), 64), _dw = _h * 0.56, _gap = _h * 0.16, _th = max(1.5, _h * 0.12);
    var _pa = draw_get_alpha();
    for (var _i = 0; _i < _n; _i++) {
        var _ch = string_char_at(_t, _n - _i), _bits = 0;
        if (_ch == "-") _bits = 8; else if (ord(_ch) >= 48 && ord(_ch) <= 57) _bits = _seg[ord(_ch) - 48];
        var _dx = _x - (_i + 1) * (_dw + _gap), _w = _dw, _hh = _h / 2;
        var _segs = [[_dx + _th, _y, _dx + _w - _th, _y + _th], [_dx, _y + _th * 0.6, _dx + _th, _y + _hh - _th * 0.4], [_dx + _w - _th, _y + _th * 0.6, _dx + _w, _y + _hh - _th * 0.4],
            [_dx + _th, _y + _hh - _th / 2, _dx + _w - _th, _y + _hh + _th / 2], [_dx, _y + _hh + _th * 0.4, _dx + _th, _y + _h - _th * 0.6], [_dx + _w - _th, _y + _hh + _th * 0.4, _dx + _w, _y + _h - _th * 0.6],
            [_dx + _th, _y + _h - _th, _dx + _w - _th, _y + _h]];
        for (var _k = 0; _k < 7; _k++) {
            var _on = (_bits & (1 << _k)) != 0, _r = _segs[_k];
            if (_on) {
                draw_set_alpha(_a * 0.28); draw_set_colour(_col);
                draw_rectangle(_r[0] - _th * 0.6, _r[1] - _th * 0.6, _r[2] + _th * 0.6, _r[3] + _th * 0.6, false);
                draw_set_alpha(_a); draw_set_colour(merge_colour(_col, c_white, 0.35));
                draw_rectangle(_r[0], _r[1], _r[2], _r[3], false);
            } else { draw_set_alpha(_a * 0.12); draw_set_colour(_col); draw_rectangle(_r[0], _r[1], _r[2], _r[3], false); }
        }
    }
    draw_set_alpha(_pa);
}
