/// jkp_core.gml - the slot machine itself, with no drawing and no engine state: a seeded generator, reel strips, pay tables,
/// the EXACT return-to-player and line hit rate by per-reel symbol counts, an integer pay-table tuner, and spins and their
/// wins. Every function here is pure (it reads and writes only what it is handed), so it runs anywhere: a Step event, a
/// server, a test.
///
/// Jackpot - Generated Slot Machines for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// THE RULES (the Readme states them for players too):
///   - A machine has 3 or 5 reels and 3 rows. Each reel is a STRIP of symbol ids; a spin picks one stop per reel uniformly and
///     shows strip[stop], strip[stop + 1], strip[stop + 2] (wrapping) from top to bottom.
///   - Ids 0..7 are the theme's pay symbols, lowest to highest. JKP_WILD (8) stands in for any pay symbol. JKP_SCATTER (9)
///     pays anywhere in view.
///   - A line pays left to right. Its symbol is the FIRST NON-WILD symbol on it; the run is the number of leading positions
///     that are that symbol or a wild. A run of 3 or more pays pays[symbol][run - 3] LINE BETS. A line of wilds only (or wilds
///     then a scatter) pays as the top symbol with the wild run. A scatter first breaks the line.
///   - Scatters pay scatter_pays[count] TOTAL BETS (total bet = lines played x line bet).
///   - RTP = E[line pay, in line bets] + E[scatter pay, in total bets]. It does not depend on how many lines are played.
///
/// ⛔ Play money only. Nothing here takes, holds or pays real money, and a game that ships slot machines to a store owns that
/// store's simulated-gambling rules.
/// ⛔ Held bit for bit to the reference core (Internal_Ops/JackpotCore.js in the factory, never shipped) by the suite's oracle
/// arms. Every public entry runs under math_set_epsilon(0) and restores the caller's epsilon: GameMaker compares numbers with
/// a 0.00001 tolerance by default, which would let the tuner see two different pay tables as equally good.

#macro JKP_WILD 8
#macro JKP_SCATTER 9
#macro JKP_TOP 7
#macro JKP_ROWS 3

// ---------------------------------------------------------------------------------------------------------------
// Tables
// ---------------------------------------------------------------------------------------------------------------

/// @function jkp_themes()
/// @description The eight themes, in id order: { id, name, symbols[8] } with the pay symbols lowest first. Do not edit the
/// returned arrays (they are shared). Pure.
/// @returns {Array<Struct>}
function jkp_themes() {
    static _t = [
        { id: "fruit", name: "Fruit", symbols: ["Cherry", "Lemon", "Orange", "Plum", "Grapes", "Melon", "Bell", "Seven"] },
        { id: "gems", name: "Gems", symbols: ["Amethyst", "Topaz", "Emerald", "Sapphire", "Ruby", "Pearl", "Opal", "Diamond"] },
        { id: "royals", name: "Royals", symbols: ["Ten", "Jack", "Queen", "King", "Ace", "Ring", "Chalice", "Crown"] },
        { id: "runes", name: "Runes", symbols: ["Fehu", "Uruz", "Thurisaz", "Ansuz", "Raido", "Kenaz", "Gebo", "Wunjo"] },
        { id: "sea", name: "Sea", symbols: ["Shell", "Starfish", "Fish", "Crab", "Turtle", "Anchor", "Wheel", "Clam"] },
        { id: "desert", name: "Desert Relics", symbols: ["Scarab", "Ankh", "Eye", "Urn", "Cobra", "Pyramid", "Mask", "Sun Disc"] },
        { id: "candy", name: "Candy", symbols: ["Gumdrop", "Wrapped Sweet", "Lollipop", "Ice Cream", "Donut", "Cupcake", "Candy Cane", "Heart"] },
        { id: "space", name: "Space", symbols: ["Moon", "Comet", "Planet", "Star", "Rocket", "Saucer", "Helmet", "Galaxy"] }
    ];
    return _t;
}

/// @function jkp_cabinets()
/// @description The three cabinet bodies, in id order: "upright", "slant", "bartop". Pure.
/// @returns {Array<String>}
function jkp_cabinets() { static _c = ["upright", "slant", "bartop"]; return _c; }

/// @function jkp_symbol_name(theme, id)
/// @description The display name of a symbol: a pay symbol's name, "Wild" or "Scatter". theme = a theme id string or index.
/// Anything not a symbol -> "". Pure.
/// @returns {String}
function jkp_symbol_name(_theme, _id) {
    var _ti = jkp__theme_index(_theme);
    if (_ti < 0 || !is_numeric(_id)) return "";
    if (_id == JKP_WILD) return "Wild";
    if (_id == JKP_SCATTER) return "Scatter";
    if (_id < 0 || _id > 7 || _id != floor(_id)) return "";
    return jkp_themes()[_ti].symbols[_id];
}

/// @function jkp__theme_index(theme)
/// @description Internal. A theme id string or index -> 0..7, anything else -> -1.
function jkp__theme_index(_t) {
    var _th = jkp_themes();
    for (var _i = 0; _i < array_length(_th); _i++) {
        if (is_string(_t) && _th[_i].id == _t) return _i;
        if (is_numeric(_t) && !is_nan(_t) && _t == _i) return _i;
    }
    return -1;
}

function jkp__names_a(_id) {
    switch (_id) {
        case "fruit": return ["Golden", "Lucky", "Sunny", "Juicy", "Classic", "Orchard"];
        case "gems": return ["Royal", "Crystal", "Glittering", "Midnight", "Brilliant", "Treasure"];
        case "royals": return ["Royal", "Palace", "High", "Grand", "Crowned", "Court"];
        case "runes": return ["Elder", "Thunder", "Iron", "Frost", "Raven", "Hall"];
        case "sea": return ["Deep", "Coral", "Tidal", "Sunken", "Azure", "Harbour"];
        case "desert": return ["Golden", "Sacred", "Pharaoh", "Sand", "Lost", "Sun"];
        case "candy": return ["Sugar", "Sweet", "Candy", "Lolly", "Frosted", "Toffee"];
    }
    return ["Cosmic", "Star", "Nova", "Orbit", "Lunar", "Astro"];
}
function jkp__names_b(_id) {
    switch (_id) {
        case "fruit": return ["Sevens", "Cherries", "Harvest", "Fruits", "Bells", "Bonanza"];
        case "gems": return ["Jewels", "Vault", "Gems", "Riches", "Facets", "Hoard"];
        case "royals": return ["Flush", "Court", "Crowns", "Aces", "Regalia", "Jewels"];
        case "runes": return ["Runes", "Saga", "Hoard", "Oath", "Stones", "Fortune"];
        case "sea": return ["Treasure", "Tides", "Pearls", "Reef", "Fortune", "Depths"];
        case "desert": return ["Tomb", "Relics", "Sands", "Dynasty", "Scarabs", "Pyramid"];
        case "candy": return ["Rush", "Shop", "Swirls", "Jar", "Hearts", "Factory"];
    }
    return ["Voyage", "Riches", "Galaxy", "Rockets", "Quest", "Jackpot"];
}

/// @function jkp_paylines(reels)
/// @description The payline patterns for a 3-reel (5 lines) or 5-reel (20 lines) machine: one row index per reel (0 = top).
/// Pure; do not edit the returned arrays.
/// @returns {Array<Array<Real>>}
function jkp_paylines(_reels) {
    static _l3 = [[1, 1, 1], [0, 0, 0], [2, 2, 2], [0, 1, 2], [2, 1, 0]];
    static _l5 = [[1, 1, 1, 1, 1], [0, 0, 0, 0, 0], [2, 2, 2, 2, 2], [0, 1, 2, 1, 0], [2, 1, 0, 1, 2], [0, 0, 1, 0, 0], [2, 2, 1, 2, 2],
        [1, 2, 2, 2, 1], [1, 0, 0, 0, 1], [1, 0, 1, 0, 1], [1, 2, 1, 2, 1], [0, 1, 0, 1, 0], [2, 1, 2, 1, 2], [1, 1, 0, 1, 1], [1, 1, 2, 1, 1],
        [0, 1, 1, 1, 0], [2, 1, 1, 1, 2], [0, 2, 0, 2, 0], [2, 0, 2, 0, 2], [0, 2, 2, 2, 0]];
    return (_reels == 3) ? _l3 : _l5;
}

// ---------------------------------------------------------------------------------------------------------------
// Hash and generator (FNV-1a and mulberry32, bit for bit the reference core's)
// ---------------------------------------------------------------------------------------------------------------

/// @function jkp__imul(a, b)
/// @description Internal. JavaScript's Math.imul on unsigned 32-bit values, as int64 halves.
function jkp__imul(_a, _b) {
    var _m = int64($FFFFFFFF);
    _a = int64(_a) & _m; _b = int64(_b) & _m;
    var _lo = (_a * (_b & int64($FFFF))) & _m;
    var _hi = ((_a * (_b >> 16)) & int64($FFFF)) << 16;
    return (_lo + _hi) & _m;
}

/// @function jkp__u32(v)
/// @description Internal. JavaScript's (v >>> 0) for a number: truncated toward zero, then modulo 2^32; not a number -> 0.
function jkp__u32(_v) {
    if (!is_numeric(_v) || is_nan(_v) || is_infinity(_v)) return int64(0);
    if (_v < 0) return (int64($100000000) - (int64(-_v) & int64($FFFFFFFF))) & int64($FFFFFFFF);
    return int64(_v) & int64($FFFFFFFF);
}

/// @function jkp_hash_string(text)
/// @description The FNV-1a hash of a word (UTF-16 code units below U+FFFF). Use it to key a machine to a name: the same word
/// always builds the same machine. Pure.
/// @param {String} text   anything; a non-string is hashed as its string form
/// @returns {Real} 0 .. 4294967295
function jkp_hash_string(_s) {
    var _t = is_string(_s) ? _s : string(_s);
    var _h = int64(2166136261), _n = string_length(_t);
    for (var _i = 1; _i <= _n; _i++) { _h = _h ^ int64(ord(string_char_at(_t, _i)) & $FFFF); _h = jkp__imul(_h, 16777619); }
    return real(_h);
}

/// @function jkp_rng(seed)
/// @description A seeded generator (mulberry32). Draw from it with jkp_rand. Pure.
/// @param {Real} seed   any number (taken as unsigned 32-bit)
/// @returns {Struct}
function jkp_rng(_seed) { return { a: jkp__u32(_seed) }; }

/// @function jkp_rand(gen)
/// @description The next draw in [0, 1) from a generator made by jkp_rng. A non-generator -> 0.
/// @param {Struct} gen
/// @returns {Real}
function jkp_rand(_g) {
    if (!is_struct(_g) || !variable_struct_exists(_g, "a")) return 0;
    var _m = int64($FFFFFFFF);
    _g.a = (int64(_g.a) + int64($6D2B79F5)) & _m;
    var _t = _g.a;
    _t = jkp__imul(_t ^ (_t >> 15), _t | 1);
    var _x = jkp__imul(_t ^ (_t >> 7), _t | 61);
    _t = _t ^ ((_t + _x) & _m);
    return real((_t ^ (_t >> 14)) & _m) / 4294967296;
}

/// @function jkp__below(gen, n)
/// @description Internal. floor(r * n) mod n.
function jkp__below(_g, _n) { var _u = jkp_rand(_g); return floor(_u * _n) mod _n; }

// ---------------------------------------------------------------------------------------------------------------
// Generation
// ---------------------------------------------------------------------------------------------------------------

/// @function jkp__apportion(weights, total)
/// @description Internal. Integer counts summing to total, proportional to weights by largest remainder, each at least 1.
function jkp__apportion(_w, _total) {
    var _n = array_length(_w), _sum = 0;
    for (var _i = 0; _i < _n; _i++) _sum += _w[_i];
    var _out = array_create(_n, 0), _rem = array_create(_n, 0), _used = 0;
    for (var _j = 0; _j < _n; _j++) { var _q = _w[_j] * _total / _sum; _out[_j] = max(1, floor(_q)); _rem[_j] = _q - floor(_q); _used += _out[_j]; }
    while (_used < _total) { var _b = 0; for (var _k = 1; _k < _n; _k++) if (_rem[_k] > _rem[_b] + 0.000000001) _b = _k; _out[_b]++; _rem[_b] = -1; _used++; }
    while (_used > _total) { var _c = -1; for (var _l = 0; _l < _n; _l++) if (_out[_l] > 1 && (_c < 0 || _out[_l] > _out[_c])) _c = _l; _out[_c]--; _used--; }
    return _out;
}

/// @function jkp__build_strip(gen, counts, n)
/// @description Internal. The counts laid out, shuffled, then no symbol left beside itself where one swap can fix it.
function jkp__build_strip(_g, _counts, _n) {
    var _s = [];
    for (var _id = 0; _id < array_length(_counts); _id++) for (var _k = 0; _k < _counts[_id]; _k++) array_push(_s, _id);
    for (var _i = _n - 1; _i > 0; _i--) { var _j = jkp__below(_g, _i + 1); var _t = _s[_i]; _s[_i] = _s[_j]; _s[_j] = _t; }
    for (var _pass = 0; _pass < 4; _pass++) {
        for (var _a = 0; _a < _n; _a++) {
            var _nx = (_a + 1) mod _n;
            if (_s[_a] != _s[_nx]) continue;
            for (var _d = 2; _d < _n; _d++) {
                var _b = (_a + _d) mod _n, _bp = (_b + _n - 1) mod _n, _bn = (_b + 1) mod _n;
                if (_b == _a || _bn == _a) continue;
                if (_s[_b] == _s[_a] || _s[_bp] == _s[_nx] || _s[_bn] == _s[_nx]) continue;
                var _sw = _s[_nx]; _s[_nx] = _s[_b]; _s[_b] = _sw; break;
            }
        }
    }
    return _s;
}

/// @function jkp_machine_create([options])
/// @description Generate a slot machine from a seed. Every option is optional:
///   seed     a number or any string (hashed); default 1
///   theme    "fruit" "gems" "royals" "runes" "sea" "desert" "candy" "space" (or 0..7); default from the seed
///   reels    3 or 5; default from the seed
///   cabinet  "upright" "slant" "bartop" (or 0..2); default from the seed
///   rtp      a target return-to-player 0.5 .. 1.2; default from the seed (0.900 .. 0.960)
/// The machine is a plain struct: name, theme, themeIndex, reels, rows, stops, cabinet, lines, strips, pays, scatterPays,
/// rtp (EXACT, after tuning), lineHit, target, livery (0..3), seed. The same options always build the same machine, and an
/// option never changes the draws behind the others. Pure.
/// @param {Struct} [options]
/// @returns {Struct}
function jkp_machine_create(_opt = undefined) {
    var _e = math_get_epsilon(); math_set_epsilon(0);
    var _o = is_struct(_opt) ? _opt : {};
    var _sv = _o[$ "seed"];
    var _seed = is_numeric(_sv) ? real(jkp__u32(_sv)) : (is_undefined(_sv) ? 1 : jkp_hash_string(_sv));
    var _g = jkp_rng(_seed);
    var _th = jkp_themes(), _cabs = jkp_cabinets();
    var _dTheme = jkp__below(_g, array_length(_th));
    var _ur = jkp_rand(_g);
    var _dReels = (_ur < 0.5) ? 3 : 5;
    var _dCab = jkp__below(_g, array_length(_cabs));
    var _ut = jkp_rand(_g);
    var _dRtp = 0.9 + floor(_ut * 13) * 0.005;
    var _na = jkp__below(_g, 6);
    var _nb = jkp__below(_g, 6);
    var _theme = _dTheme;
    var _tv = _o[$ "theme"];
    if (!is_undefined(_tv)) { var _ti = jkp__theme_index(_tv); if (_ti >= 0) _theme = _ti; }
    var _rv = _o[$ "reels"];
    var _reels = (is_numeric(_rv) && (_rv == 3 || _rv == 5)) ? real(_rv) : _dReels;
    var _cab = _dCab;
    var _cv = _o[$ "cabinet"];
    if (!is_undefined(_cv)) for (var _ci = 0; _ci < array_length(_cabs); _ci++) if ((is_string(_cv) && _cabs[_ci] == _cv) || (is_numeric(_cv) && !is_nan(_cv) && _cv == _ci)) _cab = _ci;
    var _pv = _o[$ "rtp"];
    var _target = (is_numeric(_pv) && !is_nan(_pv) && _pv >= 0.5 && _pv <= 1.2) ? real(_pv) : _dRtp;
    var _n = (_reels == 3) ? 24 : 32;
    var _w3 = [7, 6, 5, 4, 3, 2.5, 2, 1.5], _w5 = [8, 7, 6, 5, 4, 3, 2, 1.5];
    var _strips = [];
    for (var _r = 0; _r < _reels; _r++) {
        var _w = [];
        var _base = (_reels == 3) ? _w3 : _w5;
        for (var _i = 0; _i < 8; _i++) { var _j = jkp_rand(_g); array_push(_w, _base[_i] * (0.85 + 0.3 * _j)); }
        var _jw = jkp_rand(_g);
        array_push(_w, (_reels == 3) ? 0.9 + 0.4 * _jw : 1.0 + 0.5 * _jw);
        var _counts = jkp__apportion(_w, _n - 1);
        array_push(_counts, 1);
        array_push(_strips, jkp__build_strip(_g, _counts, _n));
    }
    var _tid = _th[_theme].id;
    var _liv = jkp__below(_g, 4);
    // a name never repeats its own root ("Sand Sands", "Tidal Tides"): the second word moves on while their first three letters agree
    var _naA = jkp__names_a(_tid), _naB = jkp__names_b(_tid);
    for (var _nk = 0; _nk < 6 && string_lower(string_copy(_naA[_na], 1, 3)) == string_lower(string_copy(_naB[_nb], 1, 3)); _nk++) _nb = (_nb + 1) mod 6;
    var _m = {
        seed: _seed, theme: _tid, themeIndex: _theme, reels: _reels, rows: JKP_ROWS, stops: _n, cabinet: _cabs[_cab],
        name: jkp__names_a(_tid)[_na] + " " + jkp__names_b(_tid)[_nb],
        lines: jkp_paylines(_reels), strips: _strips, pays: [],
        scatterPays: (_reels == 3) ? [0, 0, 1, 5] : [0, 0, 0, 2, 10, 50], target: _target, livery: _liv,
        rtp: 0, lineHit: 0, tuneMoves: 0
    };
    var _b3 = [[2], [3], [4], [6], [10], [15], [25], [50]];
    var _b5 = [[2, 5, 10], [2, 6, 15], [3, 8, 20], [4, 10, 30], [5, 15, 50], [8, 25, 100], [10, 40, 200], [20, 100, 500]];
    var _bp = (_reels == 3) ? _b3 : _b5;
    for (var _s = 0; _s < 8; _s++) { var _row = []; array_copy(_row, 0, _bp[_s], 0, array_length(_bp[_s])); array_push(_m.pays, _row); }
    math_set_epsilon(_e);
    jkp_tune(_m, _target);
    return _m;
}

// ---------------------------------------------------------------------------------------------------------------
// The exact mathematics
// ---------------------------------------------------------------------------------------------------------------

/// @function jkp__reel_probs(machine)
/// @description Internal. For each reel, the probability of each symbol id 0..9 at any one row (count / stops).
function jkp__reel_probs(_m) {
    var _q = [];
    for (var _r = 0; _r < _m.reels; _r++) {
        var _c = array_create(10, 0);
        for (var _i = 0; _i < _m.stops; _i++) _c[_m.strips[_r][_i]]++;
        var _p = array_create(10, 0);
        for (var _k = 0; _k < 10; _k++) _p[_k] = _c[_k] / _m.stops;
        array_push(_q, _p);
    }
    return _q;
}

/// @function jkp__walk(acc, r, t, run, pr)
/// @description Internal. The depth-first walk behind jkp_line_table, in the reference core's exact order. acc = { q, R, P }
/// with P flat (symbol * 6 + run).
function jkp__walk(_acc, _r, _t, _run, _pr) {
    if (_r == _acc.R) { var _tt = (_t < 0) ? JKP_TOP : _t; if (_run >= 3) _acc.P[_tt * 6 + _run] += _pr; return; }
    var _stop = 0, _qr = _acc.q[_r];
    for (var _s = 0; _s < 10; _s++) {
        var _ps = _qr[_s];
        if (_ps == 0) continue;
        if (_t < 0) {
            if (_s == JKP_WILD) jkp__walk(_acc, _r + 1, -1, _run + 1, _pr * _ps);
            else if (_s == JKP_SCATTER) _stop += _ps;
            else jkp__walk(_acc, _r + 1, _s, _run + 1, _pr * _ps);
        } else {
            if (_s == JKP_WILD || _s == _t) jkp__walk(_acc, _r + 1, _t, _run + 1, _pr * _ps);
            else _stop += _ps;
        }
    }
    if (_stop > 0) { var _tb = (_t < 0) ? JKP_TOP : _t; if (_run >= 3) _acc.P[_tb * 6 + _run] += _pr * _stop; }
}

/// @function jkp_line_table(machine)
/// @description The exact probability that ONE payline pays symbol s with a run of k: an array of 8 rows (s = 0..7), each
/// indexed by k (0..reels; entries below 3 are 0). Every line has the same table (each reel's row is a uniform stop). Pure.
/// @returns {Array<Array<Real>>}
function jkp_line_table(_m) {
    if (!jkp__is_machine(_m)) return [];
    var _e = math_get_epsilon(); math_set_epsilon(0);
    var _acc = { q: jkp__reel_probs(_m), R: _m.reels, P: array_create(48, 0) };
    jkp__walk(_acc, 0, -1, 0, 1);
    var _out = [];
    for (var _t = 0; _t < 8; _t++) { var _row = array_create(_m.reels + 1, 0); for (var _k = 3; _k <= _m.reels; _k++) _row[_k] = _acc.P[_t * 6 + _k]; array_push(_out, _row); }
    math_set_epsilon(_e);
    return _out;
}

/// @function jkp_scatter_table(machine)
/// @description The exact distribution of the number of scatters in view: index j = probability of exactly j. Pure.
/// @returns {Array<Real>}
function jkp_scatter_table(_m) {
    if (!jkp__is_machine(_m)) return [];
    var _e = math_get_epsilon(); math_set_epsilon(0);
    var _dist = [1];
    for (var _r = 0; _r < _m.reels; _r++) {
        var _d = [0, 0, 0, 0];
        for (var _st = 0; _st < _m.stops; _st++) {
            var _c = 0;
            for (var _row = 0; _row < 3; _row++) if (_m.strips[_r][(_st + _row) mod _m.stops] == JKP_SCATTER) _c++;
            _d[_c] += 1 / _m.stops;
        }
        var _nd = array_create(array_length(_dist) + 3, 0);
        for (var _i = 0; _i < array_length(_dist); _i++) for (var _j = 0; _j < 4; _j++) _nd[_i + _j] += _dist[_i] * _d[_j];
        _dist = _nd;
    }
    math_set_epsilon(_e);
    return _dist;
}

/// @function jkp_pay(machine, symbol, run)
/// @description The pay table entry: line bets paid by a run of `run` (3..reels) of pay symbol 0..7; anything else -> 0. Pure.
/// @returns {Real}
function jkp_pay(_m, _t, _k) {
    if (!jkp__is_machine(_m) || !is_numeric(_t) || !is_numeric(_k)) return 0;
    if (_t < 0 || _t > 7 || _t != floor(_t)) return 0;
    var _row = _m.pays[_t], _i = _k - 3;
    return (_i >= 0 && _i < array_length(_row) && _i == floor(_i)) ? _row[_i] : 0;
}

/// @function jkp__rtp_parts(machine, lineTable, scatterTable)
/// @description Internal. { line, scat, rtp, lineHit } from precomputed tables, in the reference core's summation order.
function jkp__rtp_parts(_m, _P, _S) {
    var _line = 0, _hit = 0;
    for (var _t = 0; _t < 8; _t++) for (var _k = 3; _k <= _m.reels; _k++) { var _py = jkp_pay(_m, _t, _k); _line += _py * _P[_t][_k]; if (_py > 0) _hit += _P[_t][_k]; }
    var _scat = 0, _sp = _m.scatterPays, _ns = array_length(_sp);
    for (var _j = 0; _j < array_length(_S); _j++) { var _v = (_j < _ns) ? _sp[_j] : _sp[_ns - 1]; _scat += _v * _S[_j]; }
    return { line: _line, scat: _scat, rtp: _line + _scat, lineHit: _hit };
}

/// @function jkp_rtp(machine)
/// @description The EXACT return-to-player of a machine as it stands now (after any edit to its strips or pays):
/// { rtp, line, scat, lineHit } - rtp = line + scat, lineHit = the probability ONE line pays. Exact: computed from every
/// reel's symbol counts, not simulated. Not a machine -> undefined. Pure.
/// @returns {Struct}
function jkp_rtp(_m) {
    if (!jkp__is_machine(_m)) return undefined;
    var _e = math_get_epsilon(); math_set_epsilon(0);
    var _r = jkp__rtp_parts(_m, jkp_line_table(_m), jkp_scatter_table(_m));
    math_set_epsilon(_e);
    return _r;
}

/// @function jkp__legal(machine, t, i, v)
/// @description Internal. Would pays[t][i] = v keep the table whole: at least 1, no lower symbol paying more, longer runs
/// paying strictly more.
function jkp__legal(_m, _t, _i, _v) {
    if (_v < 1) return false;
    if (_t > 0 && _v < _m.pays[_t - 1][_i]) return false;
    if (_t < 7 && _v > _m.pays[_t + 1][_i]) return false;
    if (_i > 0 && _v <= _m.pays[_t][_i - 1]) return false;
    if (_i < array_length(_m.pays[_t]) - 1 && _v >= _m.pays[_t][_i + 1]) return false;
    return true;
}

/// @function jkp_tune(machine, target)
/// @description Re-tune a machine's LINE pay table so its exact RTP lands as close to `target` as whole-number pays allow:
/// the pays are scaled, rounded, made monotone (no lower symbol pays more, longer runs pay more), then moved one step at a
/// time while each step brings the RTP closer. Scatter pays are left as they are. Writes machine.pays, .rtp, .lineHit,
/// .target, .tuneMoves; returns the exact RTP reached (typically within 0.001 of the target on 5 reels, 0.005 on 3). A target
/// outside 0.5 .. 1.2 or not a machine -> undefined, nothing changed.
/// @param {Struct} machine
/// @param {Real} target   e.g. 0.92
/// @returns {Real}
function jkp_tune(_m, _target) {
    if (!jkp__is_machine(_m) || !is_numeric(_target) || is_nan(_target) || _target < 0.5 || _target > 1.2) return undefined;
    var _e = math_get_epsilon(); math_set_epsilon(0);
    var _P = jkp_line_table(_m), _S = jkp_scatter_table(_m);
    var _parts = jkp__rtp_parts(_m, _P, _S);
    var _want = _target - _parts.scat;
    if (_parts.line > 0 && _want > 0) {
        var _f = _want / _parts.line;
        var _base = [];
        for (var _t0 = 0; _t0 < 8; _t0++) { var _cp = []; array_copy(_cp, 0, _m.pays[_t0], 0, array_length(_m.pays[_t0])); array_push(_base, _cp); }
        for (var _t1 = 0; _t1 < 8; _t1++) for (var _i1 = 0; _i1 < array_length(_base[_t1]); _i1++) _m.pays[_t1][_i1] = max(1, floor(_base[_t1][_i1] * _f + 0.5));
        for (var _t2 = 0; _t2 < 8; _t2++) for (var _i2 = 0; _i2 < array_length(_m.pays[_t2]); _i2++) {
            if (_t2 > 0 && _m.pays[_t2][_i2] < _m.pays[_t2 - 1][_i2]) _m.pays[_t2][_i2] = _m.pays[_t2 - 1][_i2];
            if (_i2 > 0 && _m.pays[_t2][_i2] <= _m.pays[_t2][_i2 - 1]) _m.pays[_t2][_i2] = _m.pays[_t2][_i2 - 1] + 1;
        }
    }
    var _moves = 0;
    for (var _guard = 0; _guard < 400; _guard++) {
        var _cur = jkp__rtp_parts(_m, _P, _S).rtp;
        var _best = abs(_cur - _target), _bt = -1, _bi = -1, _bd = 0;
        for (var _t = 0; _t < 8; _t++) for (var _i = 0; _i < array_length(_m.pays[_t]); _i++) {
            var _k = _i + 3;
            for (var _d = -1; _d <= 1; _d += 2) {
                var _v = _m.pays[_t][_i] + _d;
                if (!jkp__legal(_m, _t, _i, _v)) continue;
                var _err = abs(_cur + _d * _P[_t][_k] - _target);
                if (_err < _best - 0.000000001) { _best = _err; _bt = _t; _bi = _i; _bd = _d; }
            }
        }
        if (_bt < 0) break;
        _m.pays[_bt][_bi] += _bd; _moves++;
    }
    var _out = jkp__rtp_parts(_m, _P, _S);
    _m.rtp = _out.rtp; _m.lineHit = _out.lineHit; _m.target = _target; _m.tuneMoves = _moves;
    math_set_epsilon(_e);
    return _out.rtp;
}

// ---------------------------------------------------------------------------------------------------------------
// Spins
// ---------------------------------------------------------------------------------------------------------------

/// @function jkp__is_machine(v)
/// @description Internal. True for a struct carrying what a machine needs (reels, stops, strips, pays, lines, scatterPays).
function jkp__is_machine(_m) {
    if (!is_struct(_m)) return false;
    var _r = _m[$ "reels"], _s = _m[$ "strips"], _p = _m[$ "pays"], _l = _m[$ "lines"], _sp = _m[$ "scatterPays"], _n = _m[$ "stops"];
    if (!is_numeric(_r) || !(_r == 3 || _r == 5) || !is_numeric(_n) || !(_n >= 3)) return false;
    if (!is_array(_s) || array_length(_s) != _r || !is_array(_p) || array_length(_p) != 8 || !is_array(_l) || array_length(_l) < 1) return false;
    if (!is_array(_sp) || array_length(_sp) < 1) return false;
    for (var _i = 0; _i < _r; _i++) if (!is_array(_s[_i]) || array_length(_s[_i]) != _n) return false;
    return true;
}

/// @function jkp_window(machine, stops)
/// @description The symbols in view for one stop per reel: window[reel][row], row 0 at the top. A stop outside the strip is
/// wrapped onto it. Not a machine or a stops array of the wrong length -> undefined. Pure.
/// @returns {Array<Array<Real>>}
function jkp_window(_m, _stops) {
    if (!jkp__is_machine(_m) || !is_array(_stops) || array_length(_stops) != _m.reels) return undefined;
    var _w = [];
    for (var _r = 0; _r < _m.reels; _r++) {
        var _sv = _stops[_r];
        var _st = is_numeric(_sv) && !is_nan(_sv) ? ((floor(_sv) mod _m.stops) + _m.stops) mod _m.stops : 0;
        var _col = [];
        for (var _row = 0; _row < 3; _row++) array_push(_col, _m.strips[_r][(_st + _row) mod _m.stops]);
        array_push(_w, _col);
    }
    return _w;
}

/// @function jkp_evaluate(machine, window, [lines])
/// @description Score a window: { wins, total, lines, scatters }. wins[] = { line, sym, count, pay } in LINE BETS, line = the
/// payline index (or -1 for the scatter win, whose pay is already multiplied by the lines played). `lines` = how many
/// paylines are played (1..all; default all). Pure.
/// @returns {Struct}
function jkp_evaluate(_m, _w, _nLines = undefined) {
    if (!jkp__is_machine(_m) || !is_array(_w) || array_length(_w) != _m.reels) return { wins: [], total: 0, lines: 0, scatters: 0 };
    var _all = array_length(_m.lines);
    var _L = (is_numeric(_nLines) && !is_nan(_nLines) && _nLines >= 1 && _nLines <= _all) ? floor(_nLines) : _all;
    var _wins = [], _total = 0;
    for (var _li = 0; _li < _L; _li++) {
        var _ln = _m.lines[_li], _t = -1, _run = 0;
        for (var _r = 0; _r < _m.reels; _r++) {
            var _s = _w[_r][_ln[_r]];
            if (_t < 0) {
                if (_s == JKP_WILD) { _run++; continue; }
                if (_s == JKP_SCATTER) break;
                _t = _s; _run++; continue;
            }
            if (_s == JKP_WILD || _s == _t) _run++; else break;
        }
        var _tt = (_t < 0) ? JKP_TOP : _t;
        var _pay = (_run >= 3) ? jkp_pay(_m, _tt, _run) : 0;
        if (_pay > 0) { array_push(_wins, { line: _li, sym: _tt, count: _run, pay: _pay }); _total += _pay; }
    }
    var _sc = 0;
    for (var _r2 = 0; _r2 < _m.reels; _r2++) for (var _row = 0; _row < 3; _row++) if (_w[_r2][_row] == JKP_SCATTER) _sc++;
    var _ns = array_length(_m.scatterPays);
    var _sp = (_sc < _ns) ? _m.scatterPays[_sc] : _m.scatterPays[_ns - 1];
    if (_sp > 0) { array_push(_wins, { line: -1, sym: JKP_SCATTER, count: _sc, pay: _sp * _L }); _total += _sp * _L; }
    return { wins: _wins, total: _total, lines: _L, scatters: _sc };
}

/// @function jkp_spin(machine, gen, [lines])
/// @description One spin: a stop per reel drawn from `gen` (a jkp_rng generator; pass your own to replay a session), the
/// window, and its evaluation: { stops, window, wins, total, lines, scatters }. Pure but for advancing gen.
/// @returns {Struct}
function jkp_spin(_m, _g, _nLines = undefined) {
    if (!jkp__is_machine(_m)) return undefined;
    var _stops = [];
    for (var _r = 0; _r < _m.reels; _r++) { var _s = jkp__below(_g, _m.stops); array_push(_stops, _s); }
    var _w = jkp_window(_m, _stops);
    var _e = jkp_evaluate(_m, _w, _nLines);
    _e.stops = _stops; _e.window = _w;
    return _e;
}

/// @function jkp_exhaust3(machine)
/// @description EXACT spin statistics of a 3-reel machine by playing every stop combination (stops^3, 13,824 spins at the
/// generated 24 stops): { spins, hitRate (any win), rtp, sd (of one spin's return, in total bets), maxWin (total bets) }.
/// A one-off harness call (tens of milliseconds to a second on the VM), never a per-frame one. 5 reels -> undefined (use
/// jkp_simulate). Pure.
/// @returns {Struct}
function jkp_exhaust3(_m) {
    if (!jkp__is_machine(_m) || _m.reels != 3) return undefined;
    var _e = math_get_epsilon(); math_set_epsilon(0);
    var _hits = 0, _sum = 0, _sum2 = 0, _max = 0, _n = _m.stops, _N = _n * _n * _n, _L = array_length(_m.lines);
    var _stops = [0, 0, 0];
    for (var _a = 0; _a < _n; _a++) for (var _b = 0; _b < _n; _b++) for (var _c = 0; _c < _n; _c++) {
        _stops[0] = _a; _stops[1] = _b; _stops[2] = _c;
        var _ev = jkp_evaluate(_m, jkp_window(_m, _stops), _L);
        var _x = _ev.total / _L;
        if (_ev.total > 0) _hits++;
        _sum += _x; _sum2 += _x * _x; if (_x > _max) _max = _x;
    }
    var _mean = _sum / _N;
    var _out = { spins: _N, hitRate: _hits / _N, rtp: _mean, sd: sqrt(max(0, _sum2 / _N - _mean * _mean)), maxWin: _max };
    math_set_epsilon(_e);
    return _out;
}

/// @function jkp_simulate(machine, spins, seed)
/// @description Play `spins` seeded spins on every line: { spins, hitRate, rtp, sd, maxWin } (rtp and maxWin in total bets).
/// An ESTIMATE (its rtp sits within about 4 x sd / sqrt(spins) of jkp_rtp's exact figure); use it for the hit rate and swing of
/// a 5-reel machine. Costs roughly 0.1 to 0.3 ms a spin on the VM: run it once, off the frame. Pure.
/// @returns {Struct}
function jkp_simulate(_m, _spins, _seed) {
    if (!jkp__is_machine(_m) || !is_numeric(_spins) || is_nan(_spins) || _spins < 1) return undefined;
    _spins = min(floor(_spins), 10000000);
    var _e = math_get_epsilon(); math_set_epsilon(0);
    var _g = jkp_rng(is_numeric(_seed) ? _seed : 0), _L = array_length(_m.lines);
    var _hits = 0, _sum = 0, _sum2 = 0, _max = 0;
    for (var _i = 0; _i < _spins; _i++) {
        var _ev = jkp_spin(_m, _g, _L);
        var _x = _ev.total / _L;
        if (_ev.total > 0) _hits++;
        _sum += _x; _sum2 += _x * _x; if (_x > _max) _max = _x;
    }
    var _mean = _sum / _spins;
    var _out = { spins: _spins, hitRate: _hits / _spins, rtp: _mean, sd: sqrt(max(0, _sum2 / _spins - _mean * _mean)), maxWin: _max };
    math_set_epsilon(_e);
    return _out;
}
