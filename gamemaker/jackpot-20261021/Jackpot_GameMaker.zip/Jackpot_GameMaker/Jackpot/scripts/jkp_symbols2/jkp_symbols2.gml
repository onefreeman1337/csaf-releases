/// jkp_symbols2.gml - the symbol painters for the Sea, Desert Relics, Candy and Space themes (the shared helpers, the wild,
/// the scatter and the other four themes are in jkp_symbols). Each painter draws one symbol centred on (0, 0) in a unit box
/// (-1 .. 1, y down), lit from the upper left.
///
/// Jackpot - Generated Slot Machines for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

// ---------------------------------------------------------------------------------------------------------------
// SEA
// ---------------------------------------------------------------------------------------------------------------

function jkp__p_sea(_c, _id) {
    switch (_id) {
        case 0: // scallop shell: a scalloped fan on two ears, ribs from the hinge
            var _p = [], _hx = 0, _hy = 0.62, _ribs = 9;
            array_push(_p, -0.2, 0.74, -0.36, 0.62, -0.26, 0.52);
            for (var _i = 0; _i <= _ribs * 4; _i++) {
                var _t = _i / (_ribs * 4), _a = pi * (1.12 + 0.76 * _t);
                var _bump = 0.05 * abs(sin(_t * _ribs * pi));
                var _r = 1.0 + _bump;
                array_push(_p, _hx + cos(_a) * _r * 0.92, _hy + sin(_a) * _r * 1.1);
            }
            array_push(_p, 0.26, 0.52, 0.36, 0.62, 0.2, 0.74);
            jkp_cx_begin(_c); jkp__s_poly(_c, _p); jkp__s_body(_c, [246, 168, 140], 0, 0, 0.9);
            for (var _k = 0; _k <= _ribs; _k++) {
                var _ak = pi * (1.12 + 0.76 * (_k / _ribs));
                jkp_cx_begin(_c); jkp__s_polyline(_c, [_hx, _hy - 0.04, _hx + cos(_ak) * 0.88, _hy + sin(_ak) * 1.04]);
                jkp__s_line(_c, [176, 80, 70], 0.035, 0.55);
            }
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.66, -0.22); jkp_cx_quad(_c, 0, -0.62, 0.66, -0.22); jkp__s_line(_c, [255, 230, 210], 0.05, 0.5);
            jkp__s_shine(_c, -0.32, -0.18, 0.2, 0.1, -0.5, 0.6);
            break;
        case 1: // starfish
            var _ps = [];
            for (var _j = 0; _j < 10; _j++) { var _aj = -pi / 2 + 0.2 + _j / 10 * 2 * pi; var _rj = (_j mod 2 == 0) ? 0.92 : 0.38; array_push(_ps, cos(_aj) * _rj, sin(_aj) * _rj + 0.04); }
            jkp_cx_begin(_c); jkp__s_smooth(_c, _ps);
            jkp__s_body(_c, [246, 120, 52], 0, 0.04, 0.9);
            for (var _arm = 0; _arm < 5; _arm++) {
                var _aa = -pi / 2 + 0.2 + _arm / 5 * 2 * pi;
                for (var _d = 1; _d <= 3; _d++) { jkp_cx_begin(_c); jkp__s_circle(_c, cos(_aa) * _d * 0.18, sin(_aa) * _d * 0.18 + 0.04, 0.05 - _d * 0.008); jkp__s_flat(_c, [255, 222, 170], 0.85); }
            }
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, 0.04, 0.07); jkp__s_flat(_c, [255, 222, 170], 0.85);
            jkp__s_shine(_c, -0.2, -0.3, 0.16, 0.07, -0.8, 0.5);
            break;
        case 2: // tropical fish: a yellow body banded in blue, forked tail, fins and an eye
            jkp_cx_begin(_c); jkp__s_poly(_c, [-0.48, 0.0, -0.92, -0.42, -0.8, 0.0, -0.92, 0.42]); jkp__s_body(_c, [40, 110, 210], -0.75, 0, 0.4, 0.05);
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.2, -0.38); jkp_cx_quad(_c, 0.0, -0.86, 0.32, -0.42); jkp_cx_close(_c); jkp__s_body(_c, [40, 110, 210], 0, -0.5, 0.4, 0.045, false);
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.6, 0); jkp_cx_bezier(_c, -0.4, -0.66, 0.5, -0.66, 0.82, 0.0); jkp_cx_bezier(_c, 0.5, 0.6, -0.4, 0.6, -0.6, 0); jkp_cx_close(_c);
            jkp__s_body(_c, [252, 212, 40], 0.1, -0.05, 0.8);
            jkp_cx_save(_c);
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.6, 0); jkp_cx_bezier(_c, -0.4, -0.66, 0.5, -0.66, 0.82, 0.0); jkp_cx_bezier(_c, 0.5, 0.6, -0.4, 0.6, -0.6, 0); jkp_cx_close(_c);
            jkp_cx_clip(_c);
            var _bx = [-0.32, 0.12];
            for (var _b = 0; _b < 2; _b++) { jkp_cx_begin(_c); jkp_cx_move(_c, _bx[_b] - 0.06, -0.7); jkp_cx_quad(_c, _bx[_b] + 0.12, 0, _bx[_b] - 0.06, 0.7); jkp_cx_line(_c, _bx[_b] + 0.12, 0.7); jkp_cx_quad(_c, _bx[_b] + 0.3, 0, _bx[_b] + 0.12, -0.7); jkp_cx_close(_c); jkp__s_flat(_c, [30, 90, 200]); }
            jkp_cx_restore(_c);
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.6, 0); jkp_cx_bezier(_c, -0.4, -0.66, 0.5, -0.66, 0.82, 0.0); jkp_cx_bezier(_c, 0.5, 0.6, -0.4, 0.6, -0.6, 0); jkp_cx_close(_c);
            jkp__s_line(_c, [130, 90, 10], 0.05);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0.48, -0.1, 0.11); jkp__s_flat(_c, [255, 255, 255]); jkp__s_line(_c, [40, 30, 20], 0.03);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0.5, -0.1, 0.055); jkp__s_flat(_c, [20, 20, 30]);
            jkp_cx_begin(_c); jkp_cx_move(_c, 0.0, 0.12); jkp_cx_quad(_c, 0.1, 0.42, -0.14, 0.38); jkp__s_line(_c, [200, 140, 20], 0.05);
            jkp__s_shine(_c, 0.0, -0.3, 0.32, 0.08, -0.1, 0.55);
            break;
        case 3: // crab
            for (var _s = -1; _s <= 1; _s += 2) {
                for (var _l = 0; _l < 3; _l++) { jkp_cx_begin(_c); jkp__s_polyline(_c, [_s * 0.4, 0.2 + _l * 0.12, _s * 0.78, 0.22 + _l * 0.18, _s * 0.86, 0.5 + _l * 0.14]); jkp__s_line(_c, [120, 20, 20], 0.1); jkp__s_line(_c, [220, 60, 50], 0.055); }
                jkp_cx_begin(_c); jkp__s_polyline(_c, [_s * 0.36, -0.06, _s * 0.6, -0.32, _s * 0.62, -0.5]); jkp__s_line(_c, [120, 20, 20], 0.12); jkp__s_line(_c, [220, 60, 50], 0.07);
                // a pincer: a disc with a wedge cut from its centre, the mouth opening up and outward
                var _mouth = -pi / 2 + _s * 0.45, _half = 0.42;
                jkp_cx_begin(_c); jkp_cx_move(_c, _s * 0.62, -0.6);
                jkp_cx_arc(_c, _s * 0.62, -0.6, 0.25, _mouth + _half, _mouth - _half + 2 * pi);
                jkp_cx_close(_c);
                jkp__s_body(_c, [226, 56, 46], _s * 0.62, -0.6, 0.25, 0.045);
            }
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, 0.18, 0.58, 0.4, 0); jkp__s_body(_c, [228, 60, 48], 0, 0.18, 0.6);
            for (var _e = -1; _e <= 1; _e += 2) {
                jkp_cx_begin(_c); jkp__s_polyline(_c, [_e * 0.14, -0.12, _e * 0.18, -0.32]); jkp__s_line(_c, [120, 20, 20], 0.07);
                jkp_cx_begin(_c); jkp__s_circle(_c, _e * 0.18, -0.36, 0.085); jkp__s_flat(_c, [255, 255, 255]); jkp__s_line(_c, [60, 10, 10], 0.03);
                jkp_cx_begin(_c); jkp__s_circle(_c, _e * 0.19, -0.35, 0.04); jkp__s_flat(_c, [20, 20, 20]);
            }
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.16, 0.28); jkp_cx_quad(_c, 0, 0.38, 0.16, 0.28); jkp__s_line(_c, [110, 10, 10], 0.04);
            jkp__s_shine(_c, -0.2, 0.0, 0.26, 0.08, -0.2, 0.55);
            break;
        case 4: // turtle: a domed shell of plates over four flippers and a head
            var _fl = [[-0.52, -0.42, -0.8], [0.52, -0.42, -0.4], [-0.5, 0.42, 0.75], [0.5, 0.42, 0.4]];
            for (var _f = 0; _f < 4; _f++) { jkp_cx_begin(_c); jkp__s_ellipse(_c, _fl[_f][0], _fl[_f][1], 0.28, 0.13, _fl[_f][2] + ((_fl[_f][0] < 0) ? pi : 0)); jkp__s_body(_c, [120, 176, 90], _fl[_f][0], _fl[_f][1], 0.28, 0.045); }
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, -0.74, 0.16, 0.18, 0); jkp__s_body(_c, [128, 184, 96], 0, -0.74, 0.18, 0.045);
            jkp_cx_begin(_c); jkp__s_circle(_c, -0.06, -0.78, 0.03); jkp__s_circle(_c, 0.06, -0.78, 0.03); jkp__s_flat(_c, [20, 30, 20]);
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, 0.02, 0.6, 0.68, 0); jkp__s_body(_c, [116, 82, 40], 0, 0.02, 0.7);
            var _hex = jkp__s_rpoly(0, 0.0, 0.22, 6, pi / 6);
            jkp_cx_begin(_c); jkp__s_poly(_c, _hex); jkp__s_flat(_c, [170, 128, 60]); jkp__s_line(_c, [70, 46, 20], 0.03);
            for (var _h = 0; _h < 6; _h++) {
                var _ah = _h / 6 * 2 * pi + pi / 6;
                var _ph = jkp__s_rpoly(cos(_ah) * 0.4, sin(_ah) * 0.44, 0.18, 6, pi / 6);
                jkp_cx_begin(_c); jkp__s_poly(_c, _ph); jkp__s_flat(_c, [150, 108, 50]); jkp__s_line(_c, [70, 46, 20], 0.03);
            }
            jkp__s_shine(_c, -0.2, -0.36, 0.26, 0.12, -0.4, 0.5);
            break;
        case 5: // anchor
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, -0.72, 0.15); jkp_cx_move(_c, 0.08, -0.72); jkp_cx_arc(_c, 0, -0.72, 0.08, 0, -2 * pi, true); jkp_cx_close(_c);
            jkp__s_drop(_c); jkp__s_flat(_c, [80, 90, 104]); jkp_cx_fill_rule(_c, JKP_FILL_EVENODD);
            jkp_cx_begin(_c); jkp__s_poly(_c, [-0.08, -0.58, 0.08, -0.58, 0.08, 0.52, -0.08, 0.52]); jkp__s_body(_c, [104, 116, 132], 0, 0, 0.6, 0.05);
            jkp_cx_begin(_c); jkp_cx_round_rect(_c, -0.46, -0.48, 0.92, 0.12, 0.05); jkp__s_body(_c, [104, 116, 132], 0, -0.42, 0.46, 0.045, false);
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.74, 0.12); jkp_cx_quad(_c, -0.6, 0.78, 0, 0.8); jkp_cx_quad(_c, 0.6, 0.78, 0.74, 0.12);
            jkp_cx_line(_c, 0.6, 0.22); jkp_cx_quad(_c, 0.5, 0.62, 0, 0.62); jkp_cx_quad(_c, -0.5, 0.62, -0.6, 0.22); jkp_cx_close(_c);
            jkp__s_body(_c, [104, 116, 132], 0, 0.5, 0.75, 0.05);
            for (var _k2 = -1; _k2 <= 1; _k2 += 2) { jkp_cx_begin(_c); jkp__s_poly(_c, [_k2 * 0.86, 0.02, _k2 * 0.56, 0.12, _k2 * 0.76, 0.3]); jkp__s_body(_c, [120, 132, 148], _k2 * 0.7, 0.15, 0.2, 0.04, false); }
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.1, -0.6); jkp_cx_bezier(_c, -0.6, -0.4, 0.5, -0.1, -0.1, 0.12); jkp_cx_bezier(_c, -0.5, 0.3, 0.4, 0.4, 0.3, 0.55);
            jkp__s_line(_c, [90, 60, 30], 0.09); jkp__s_line(_c, [200, 160, 100], 0.05);
            jkp__s_shine(_c, -0.03, -0.3, 0.03, 0.25, 0, 0.5);
            break;
        case 6: // ship's wheel
            for (var _sp = 0; _sp < 8; _sp++) {
                var _as = _sp / 8 * 2 * pi;
                jkp_cx_begin(_c); jkp__s_polyline(_c, [cos(_as) * 0.12, sin(_as) * 0.12, cos(_as) * 0.84, sin(_as) * 0.84]);
                jkp__s_line(_c, [80, 46, 20], 0.15); jkp__s_line(_c, [176, 116, 60], 0.09);
                jkp_cx_begin(_c); jkp__s_ellipse(_c, cos(_as) * 0.86, sin(_as) * 0.86, 0.11, 0.075, _as); jkp__s_body(_c, [186, 124, 64], cos(_as) * 0.86, sin(_as) * 0.86, 0.11, 0.035, false);
            }
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, 0, 0.66); jkp_cx_move(_c, 0.5, 0); jkp_cx_arc(_c, 0, 0, 0.5, 0, -2 * pi, true); jkp_cx_close(_c);
            jkp__s_drop(_c);
            var _gw = jkp_cx_radial(_c, -0.3, -0.3, 0.05, 0, 0, 0.75);
            jkp_cx_stop(_gw, 0, [214, 150, 84]); jkp_cx_stop(_gw, 0.6, [150, 92, 42]); jkp_cx_stop(_gw, 1, [90, 52, 22]);
            _c.fill = _gw; jkp_cx_fill_rule(_c, JKP_FILL_EVENODD);
            jkp__s_line(_c, [60, 32, 12], 0.04);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, 0, 0.2); jkp__s_body(_c, [236, 186, 70], 0, 0, 0.2, 0.04);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, 0, 0.08); jkp__s_flat(_c, [140, 96, 20]);
            jkp__s_shine(_c, -0.35, -0.42, 0.22, 0.06, -0.7, 0.5);
            break;
        default: // clam with a pearl
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.82, 0.0); jkp_cx_quad(_c, 0, -1.06, 0.82, 0.0); jkp_cx_quad(_c, 0, -0.5, -0.82, 0.0); jkp_cx_close(_c);
            jkp__s_body(_c, [184, 150, 210], 0, -0.4, 0.8, 0.05);
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.86, 0.06); jkp_cx_quad(_c, 0, -0.1, 0.86, 0.06); jkp_cx_quad(_c, 0.7, 0.86, 0, 0.86); jkp_cx_quad(_c, -0.7, 0.86, -0.86, 0.06); jkp_cx_close(_c);
            jkp__s_body(_c, [200, 166, 226], 0, 0.4, 0.85);
            for (var _r2 = 0; _r2 < 7; _r2++) { var _rx = -0.6 + _r2 * 0.2; jkp_cx_begin(_c); jkp__s_polyline(_c, [_rx * 0.6, 0.84, _rx, 0.1]); jkp__s_line(_c, [130, 90, 160], 0.03, 0.6); }
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, 0.04, 0.62, 0.12, 0); jkp__s_flat(_c, [250, 200, 220]);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, -0.1, 0.27);
            jkp__s_drop(_c);
            var _gp = jkp_cx_radial(_c, -0.1, -0.2, 0.01, 0, -0.1, 0.3);
            jkp_cx_stop(_gp, 0, [255, 255, 255]); jkp_cx_stop(_gp, 0.6, [236, 228, 236]); jkp_cx_stop(_gp, 1, [170, 160, 190]);
            _c.fill = _gp; jkp_cx_fill(_c); jkp__s_line(_c, [120, 110, 140], 0.03);
            jkp__s_spark(_c, 0.2, -0.32, 0.14, 1);
            break;
    }
}

// ---------------------------------------------------------------------------------------------------------------
// DESERT RELICS
// ---------------------------------------------------------------------------------------------------------------

function jkp__p_desert(_c, _id) {
    switch (_id) {
        case 0: // scarab
            for (var _s = -1; _s <= 1; _s += 2) for (var _l = 0; _l < 3; _l++) {
                jkp_cx_begin(_c); jkp__s_polyline(_c, [_s * 0.3, -0.2 + _l * 0.3, _s * 0.66, -0.36 + _l * 0.38, _s * 0.8, -0.2 + _l * 0.46]);
                jkp__s_line(_c, [30, 40, 50], 0.08);
            }
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, -0.62, 0.26, 0.17, 0); jkp__s_body(_c, [40, 120, 130], 0, -0.62, 0.26, 0.045);
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, -0.4, 0.36, 0.17, 0); jkp__s_body(_c, [36, 130, 140], 0, -0.4, 0.36, 0.045);
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, 0.22, 0.48, 0.58, 0); jkp__s_body(_c, [34, 150, 156], 0, 0.22, 0.6);
            jkp_cx_begin(_c); jkp__s_polyline(_c, [0, -0.32, 0, 0.78]); jkp__s_line(_c, [12, 50, 56], 0.05);
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, 0.22, 0.48, 0.58, 0); jkp__s_line(_c, [236, 186, 60], 0.05);
            jkp__s_shine(_c, -0.22, 0.0, 0.1, 0.3, 0.1, 0.6); jkp__s_shine(_c, 0.22, 0.0, 0.06, 0.24, -0.1, 0.35);
            break;
        case 1: // ankh
            jkp_cx_begin(_c); jkp__s_poly(_c, [-0.1, -0.1, 0.1, -0.1, 0.17, 0.86, -0.17, 0.86]); jkp__s_body(_c, [240, 186, 50], 0, 0.4, 0.5);
            jkp_cx_begin(_c); jkp__s_poly(_c, [-0.7, -0.2, -0.7, 0.04, 0.7, 0.04, 0.7, -0.2]); jkp__s_body(_c, [240, 186, 50], 0, -0.08, 0.7, 0.05, false);
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, -0.52, 0.32, 0.4, 0); jkp_cx_move(_c, 0.17, -0.5); jkp_cx_ellipse(_c, 0, -0.5, 0.17, 0.24, 0, 0, -2 * pi, true); jkp_cx_close(_c);
            jkp__s_drop(_c);
            var _ga = jkp_cx_radial(_c, -0.12, -0.7, 0.02, 0, -0.52, 0.45);
            jkp_cx_stop(_ga, 0, [255, 236, 160]); jkp_cx_stop(_ga, 0.5, [238, 180, 46]); jkp_cx_stop(_ga, 1, [150, 96, 14]);
            _c.fill = _ga; jkp_cx_fill_rule(_c, JKP_FILL_EVENODD);
            jkp__s_line(_c, [120, 76, 10], 0.05);
            jkp_cx_begin(_c); jkp_cx_round_rect(_c, -0.14, 0.24, 0.28, 0.06, 0.02); jkp__s_flat(_c, [40, 70, 170]);
            jkp_cx_begin(_c); jkp_cx_round_rect(_c, -0.15, 0.44, 0.3, 0.06, 0.02); jkp__s_flat(_c, [40, 70, 170]);
            jkp__s_shine(_c, -0.04, 0.4, 0.03, 0.3, 0, 0.6);
            break;
        case 2: // eye of Horus, struck in lapis and gold
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.78, -0.08); jkp_cx_quad(_c, 0, -0.62, 0.78, -0.08); jkp_cx_quad(_c, 0, 0.36, -0.78, -0.08); jkp_cx_close(_c);
            jkp__s_drop(_c); jkp__s_flat(_c, [250, 240, 214]);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0.02, -0.1, 0.24); jkp__s_body(_c, [40, 70, 180], 0.02, -0.1, 0.24, 0, false);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0.02, -0.1, 0.11); jkp__s_flat(_c, [12, 14, 30]);
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.78, -0.08); jkp_cx_quad(_c, 0, -0.62, 0.78, -0.08); jkp_cx_quad(_c, 0, 0.36, -0.78, -0.08); jkp_cx_close(_c);
            jkp__s_line(_c, [236, 186, 60], 0.15); jkp__s_line(_c, [24, 44, 120], 0.08);
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.8, -0.56); jkp_cx_quad(_c, 0, -0.9, 0.82, -0.5);
            jkp__s_line(_c, [236, 186, 60], 0.17); jkp__s_line(_c, [24, 44, 120], 0.1);
            jkp_cx_begin(_c); jkp__s_polyline(_c, [-0.08, 0.16, -0.12, 0.74]); jkp__s_line(_c, [236, 186, 60], 0.15); jkp__s_line(_c, [24, 44, 120], 0.08);
            jkp_cx_begin(_c); jkp_cx_move(_c, 0.12, 0.12); jkp_cx_quad(_c, 0.44, 0.34, 0.52, 0.62); jkp_cx_quad(_c, 0.54, 0.82, 0.32, 0.76);
            jkp__s_line(_c, [236, 186, 60], 0.15); jkp__s_line(_c, [24, 44, 120], 0.08);
            jkp_cx_begin(_c); jkp_cx_move(_c, 0.76, -0.08); jkp_cx_line(_c, 0.92, -0.08); jkp__s_line(_c, [236, 186, 60], 0.15); jkp__s_line(_c, [24, 44, 120], 0.08);
            jkp__s_spark(_c, -0.05, -0.2, 0.08, 0.9);
            break;
        case 3: // urn: a banded terracotta jar under a lid
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.24, -0.5); jkp_cx_bezier(_c, -0.7, -0.4, -0.7, 0.3, -0.36, 0.72); jkp_cx_line(_c, 0.36, 0.72);
            jkp_cx_bezier(_c, 0.7, 0.3, 0.7, -0.4, 0.24, -0.5); jkp_cx_close(_c);
            jkp__s_body(_c, [196, 106, 58], -0.1, 0.05, 0.75);
            jkp_cx_save(_c);
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.24, -0.5); jkp_cx_bezier(_c, -0.7, -0.4, -0.7, 0.3, -0.36, 0.72); jkp_cx_line(_c, 0.36, 0.72); jkp_cx_bezier(_c, 0.7, 0.3, 0.7, -0.4, 0.24, -0.5); jkp_cx_close(_c);
            jkp_cx_clip(_c);
            jkp_cx_begin(_c); jkp_cx_rect(_c, -1, -0.24, 2, 0.1); jkp_cx_rect(_c, -1, 0.42, 2, 0.08); jkp__s_flat(_c, [40, 26, 20]);
            jkp_cx_begin(_c); jkp_cx_rect(_c, -1, -0.14, 2, 0.56); jkp__s_flat(_c, [236, 186, 60], 0.9);
            for (var _g = 0; _g < 5; _g++) { var _gx = -0.44 + _g * 0.22; jkp_cx_begin(_c); jkp__s_poly(_c, [_gx, 0.36, _gx + 0.08, -0.06, _gx + 0.16, 0.36]); jkp__s_flat(_c, [40, 70, 170]); }
            jkp_cx_restore(_c);
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.24, -0.5); jkp_cx_bezier(_c, -0.7, -0.4, -0.7, 0.3, -0.36, 0.72); jkp_cx_line(_c, 0.36, 0.72); jkp_cx_bezier(_c, 0.7, 0.3, 0.7, -0.4, 0.24, -0.5); jkp_cx_close(_c);
            jkp__s_line(_c, [90, 40, 20], 0.05);
            jkp_cx_begin(_c); jkp_cx_round_rect(_c, -0.32, -0.62, 0.64, 0.14, 0.06); jkp__s_body(_c, [210, 120, 66], 0, -0.55, 0.32, 0.045, false);
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, -0.74, 0.2, 0.14, 0); jkp__s_body(_c, [236, 186, 60], 0, -0.74, 0.2, 0.04, false);
            jkp__s_shine(_c, -0.32, -0.1, 0.07, 0.3, 0.1, 0.5);
            break;
        case 4: // cobra: a spread hood on a coiled body
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, 0.6, 0.62, 0.24, 0); jkp__s_body(_c, [60, 130, 60], 0, 0.6, 0.6);
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0.06, 0.46, 0.44, 0.17, 0); jkp__s_body(_c, [70, 146, 66], 0.06, 0.46, 0.44, 0.045, false);
            jkp_cx_begin(_c); jkp_cx_move(_c, 0, -0.84); jkp_cx_bezier(_c, -0.66, -0.7, -0.64, 0.0, -0.16, 0.44); jkp_cx_line(_c, 0.16, 0.44); jkp_cx_bezier(_c, 0.64, 0.0, 0.66, -0.7, 0, -0.84); jkp_cx_close(_c);
            jkp__s_body(_c, [70, 150, 70], 0, -0.2, 0.7);
            jkp_cx_begin(_c); jkp_cx_move(_c, 0, -0.5); jkp_cx_bezier(_c, -0.34, -0.36, -0.3, 0.06, -0.08, 0.36); jkp_cx_line(_c, 0.08, 0.36); jkp_cx_bezier(_c, 0.3, 0.06, 0.34, -0.36, 0, -0.5); jkp_cx_close(_c);
            jkp__s_flat(_c, [236, 200, 90]);
            for (var _b = 0; _b < 5; _b++) { jkp_cx_begin(_c); jkp__s_polyline(_c, [-0.16 + _b * 0.01, -0.3 + _b * 0.13, 0.16 - _b * 0.01, -0.3 + _b * 0.13]); jkp__s_line(_c, [170, 120, 40], 0.025); }
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, -0.68, 0.17, 0.13, 0); jkp__s_body(_c, [76, 160, 76], 0, -0.68, 0.17, 0.04, false);
            jkp_cx_begin(_c); jkp__s_circle(_c, -0.07, -0.7, 0.03); jkp__s_circle(_c, 0.07, -0.7, 0.03); jkp__s_flat(_c, [255, 210, 40]);
            jkp_cx_begin(_c); jkp__s_polyline(_c, [0, -0.56, 0, -0.44, -0.04, -0.4]); jkp_cx_move(_c, 0, -0.44); jkp_cx_line(_c, 0.04, -0.4); jkp__s_line(_c, [200, 30, 40], 0.025);
            jkp__s_shine(_c, -0.3, -0.36, 0.06, 0.24, 0.3, 0.5);
            break;
        case 5: // pyramid under a sun
            jkp_cx_begin(_c); jkp__s_circle(_c, 0.42, -0.5, 0.26); jkp__s_flat(_c, [255, 200, 80], 0.9);
            jkp_cx_begin(_c); jkp__s_poly(_c, [0, -0.7, -0.9, 0.6, 0.1, 0.72]); jkp__s_drop(_c); jkp__s_flat(_c, [238, 196, 120]);
            jkp_cx_begin(_c); jkp__s_poly(_c, [0, -0.7, 0.1, 0.72, 0.9, 0.6]); jkp__s_flat(_c, [180, 132, 70]);
            for (var _cr = 1; _cr < 6; _cr++) { var _y = -0.7 + _cr * 0.23, _hw = (_y + 0.7) / 1.3 * 0.9; jkp_cx_begin(_c); jkp__s_polyline(_c, [-_hw, _y + (_y + 0.7) * 0.0, 0.1 * (_y + 0.7) / 1.3, _y + 0.12 * (_y + 0.7) / 1.3, _hw, _y]); jkp__s_line(_c, [120, 80, 36], 0.02, 0.6); }
            jkp_cx_begin(_c); jkp__s_poly(_c, [0, -0.7, -0.16, -0.46, 0.02, -0.43, 0.15, -0.47]); jkp__s_flat(_c, [255, 220, 90]);
            jkp_cx_begin(_c); jkp__s_poly(_c, [0, -0.7, -0.9, 0.6, 0.1, 0.72, 0.9, 0.6]); jkp__s_line(_c, [90, 56, 20], 0.05);
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.98, 0.7); jkp_cx_quad(_c, 0, 0.6, 0.98, 0.74); jkp__s_line(_c, [214, 170, 100], 0.07);
            jkp__s_spark(_c, 0.0, -0.74, 0.2, 1);
            break;
        case 6: // pharaoh mask: nemes headdress in lapis and gold around a golden face
            jkp_cx_begin(_c); jkp_cx_move(_c, 0, -0.86); jkp_cx_bezier(_c, -0.52, -0.86, -0.62, -0.3, -0.86, 0.8); jkp_cx_line(_c, 0.86, 0.8); jkp_cx_bezier(_c, 0.62, -0.3, 0.52, -0.86, 0, -0.86); jkp_cx_close(_c);
            jkp__s_body(_c, [236, 180, 46], 0, -0.1, 0.9);
            jkp_cx_save(_c);
            jkp_cx_begin(_c); jkp_cx_move(_c, 0, -0.86); jkp_cx_bezier(_c, -0.52, -0.86, -0.62, -0.3, -0.86, 0.8); jkp_cx_line(_c, 0.86, 0.8); jkp_cx_bezier(_c, 0.62, -0.3, 0.52, -0.86, 0, -0.86); jkp_cx_close(_c);
            jkp_cx_clip(_c);
            for (var _st = 0; _st < 9; _st++) { var _sy = -0.82 + _st * 0.19; jkp_cx_begin(_c); jkp_cx_rect(_c, -1, _sy, 2, 0.085); jkp__s_flat(_c, [34, 60, 170]); }
            jkp_cx_restore(_c);
            jkp_cx_begin(_c); jkp_cx_move(_c, 0, -0.86); jkp_cx_bezier(_c, -0.52, -0.86, -0.62, -0.3, -0.86, 0.8); jkp_cx_line(_c, 0.86, 0.8); jkp_cx_bezier(_c, 0.62, -0.3, 0.52, -0.86, 0, -0.86); jkp_cx_close(_c);
            jkp__s_line(_c, [110, 70, 10], 0.05);
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.36, -0.46); jkp_cx_line(_c, 0.36, -0.46); jkp_cx_bezier(_c, 0.4, 0.2, 0.2, 0.5, 0, 0.52); jkp_cx_bezier(_c, -0.2, 0.5, -0.4, 0.2, -0.36, -0.46); jkp_cx_close(_c);
            jkp__s_body(_c, [246, 200, 80], -0.05, -0.05, 0.55);
            for (var _ey = -1; _ey <= 1; _ey += 2) {
                jkp_cx_begin(_c); jkp__s_ellipse(_c, _ey * 0.16, -0.18, 0.11, 0.05, 0); jkp__s_flat(_c, [250, 245, 230]); jkp__s_line(_c, [20, 20, 40], 0.035);
                jkp_cx_begin(_c); jkp__s_circle(_c, _ey * 0.16, -0.18, 0.035); jkp__s_flat(_c, [20, 20, 40]);
                jkp_cx_begin(_c); jkp__s_polyline(_c, [_ey * 0.06, -0.3, _ey * 0.3, -0.32]); jkp__s_line(_c, [20, 20, 60], 0.04);
            }
            jkp_cx_begin(_c); jkp__s_polyline(_c, [0, -0.12, -0.04, 0.12, 0.04, 0.14]); jkp__s_line(_c, [170, 110, 20], 0.03);
            jkp_cx_begin(_c); jkp__s_poly(_c, [-0.06, 0.52, 0.06, 0.52, 0.04, 0.8, -0.04, 0.8]); jkp__s_flat(_c, [34, 60, 170]); jkp__s_line(_c, [236, 186, 60], 0.025);
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, -0.6, 0.06, 0.12, 0); jkp__s_flat(_c, [220, 40, 40]);
            jkp__s_shine(_c, -0.18, -0.36, 0.14, 0.05, 0, 0.55);
            break;
        default: // the winged sun disc
            for (var _w = -1; _w <= 1; _w += 2) {
                for (var _f = 0; _f < 4; _f++) {
                    var _len = 0.9 - _f * 0.12, _yy = -0.12 + _f * 0.12;
                    jkp_cx_begin(_c); jkp_cx_move(_c, _w * 0.2, _yy - 0.06); jkp_cx_quad(_c, _w * 0.6, _yy - 0.14 - _f * 0.02, _w * _len, _yy - 0.1 + _f * 0.02); jkp_cx_line(_c, _w * (_len - 0.04), _yy + 0.06); jkp_cx_quad(_c, _w * 0.6, _yy + 0.02, _w * 0.2, _yy + 0.08); jkp_cx_close(_c);
                    var _fc = (_f mod 2 == 0) ? [236, 186, 60] : [40, 80, 180];
                    jkp__s_body(_c, _fc, _w * 0.5, _yy, 0.45, 0.035, _f == 0);
                }
            }
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, -0.02, 0.36); jkp__s_body(_c, [240, 186, 50], 0, -0.02, 0.36, 0.05);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, -0.02, 0.26); jkp__s_body(_c, [222, 50, 36], 0, -0.02, 0.26, 0.03, false);
            for (var _u = -1; _u <= 1; _u += 2) { jkp_cx_begin(_c); jkp_cx_move(_c, _u * 0.24, 0.24); jkp_cx_quad(_c, _u * 0.38, 0.44, _u * 0.2, 0.56); jkp__s_line(_c, [60, 130, 60], 0.09); }
            jkp__s_shine(_c, -0.1, -0.16, 0.12, 0.06, -0.4, 0.8);
            break;
    }
}

// ---------------------------------------------------------------------------------------------------------------
// CANDY
// ---------------------------------------------------------------------------------------------------------------

function jkp__p_candy(_c, _id) {
    switch (_id) {
        case 0: // gumdrop: a sugared dome
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.74, 0.62); jkp_cx_bezier(_c, -0.8, -0.2, -0.46, -0.72, 0, -0.72); jkp_cx_bezier(_c, 0.46, -0.72, 0.8, -0.2, 0.74, 0.62); jkp_cx_quad(_c, 0, 0.78, -0.74, 0.62); jkp_cx_close(_c);
            jkp__s_body(_c, [70, 200, 90], -0.05, 0.0, 0.8);
            var _g = jkp_rng(5150);
            var _sug = [];
            for (var _i = 0; _i < 60; _i++) { var _sx = (jkp_rand(_g) - 0.5) * 1.2, _sy = -0.55 + jkp_rand(_g) * 1.1; if (abs(_sx) < 0.6 * (1 - max(0, -_sy - 0.1) * 0.9)) array_push(_sug, [_sx, _sy, 0.035, 0.035, c_white, 0.65]); }
            jkp_cx_fill_rects(_c, _sug);
            jkp__s_shine(_c, -0.3, -0.38, 0.22, 0.12, -0.6, 0.7);
            break;
        case 1: // a wrapped sweet
            for (var _s = -1; _s <= 1; _s += 2) {
                jkp_cx_begin(_c); jkp__s_poly(_c, [_s * 0.36, 0, _s * 0.92, -0.42, _s * 0.84, -0.12, _s * 0.96, 0.0, _s * 0.84, 0.12, _s * 0.92, 0.42]);
                jkp__s_body(_c, [250, 120, 150], _s * 0.66, 0, 0.4, 0.045);
                jkp_cx_begin(_c); jkp__s_polyline(_c, [_s * 0.5, -0.06, _s * 0.84, -0.3]); jkp__s_line(_c, [255, 200, 220], 0.03, 0.8);
            }
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, 0, 0.46); jkp__s_body(_c, [236, 40, 70], 0, 0, 0.46);
            jkp_cx_save(_c); jkp_cx_begin(_c); jkp__s_circle(_c, 0, 0, 0.46); jkp_cx_clip(_c);
            for (var _k = 0; _k < 4; _k++) { var _a = _k / 4 * 2 * pi; jkp_cx_begin(_c); jkp_cx_move(_c, 0, 0); jkp_cx_quad(_c, cos(_a + 0.6) * 0.5, sin(_a + 0.6) * 0.5, cos(_a + 1.0) * 0.6, sin(_a + 1.0) * 0.6); jkp_cx_line(_c, cos(_a + 1.5) * 0.6, sin(_a + 1.5) * 0.6); jkp_cx_quad(_c, cos(_a + 1.0) * 0.36, sin(_a + 1.0) * 0.36, 0, 0); jkp_cx_close(_c); jkp__s_flat(_c, [255, 245, 240], 0.9); }
            jkp_cx_restore(_c);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, 0, 0.46); jkp__s_line(_c, [130, 10, 30], 0.045);
            jkp__s_shine(_c, -0.16, -0.26, 0.18, 0.08, -0.5, 0.8);
            break;
        case 2: // lollipop
            jkp_cx_begin(_c); jkp_cx_round_rect(_c, -0.06, 0.1, 0.12, 0.74, 0.05); jkp__s_body(_c, [250, 246, 236], 0, 0.5, 0.4, 0.035);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, -0.26, 0.6); jkp__s_body(_c, [250, 90, 160], 0, -0.26, 0.6);
            var _cols = [[255, 220, 60], [80, 200, 240], [120, 220, 100], [255, 250, 250]];
            for (var _arm = 0; _arm < 4; _arm++) {
                jkp_cx_begin(_c);
                for (var _t = 0; _t <= 40; _t++) { var _u = _t / 40, _ang = _arm / 4 * 2 * pi + _u * 3.4 * pi, _rr = 0.04 + 0.5 * _u; var _px = cos(_ang) * _rr, _py = -0.26 + sin(_ang) * _rr; if (_t == 0) jkp_cx_move(_c, _px, _py); else jkp_cx_line(_c, _px, _py); }
                jkp__s_line(_c, _cols[_arm], 0.075, 0.95);
            }
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, -0.26, 0.6); jkp__s_line(_c, [140, 20, 80], 0.05);
            jkp__s_shine(_c, -0.24, -0.56, 0.22, 0.1, -0.5, 0.8);
            break;
        case 3: // ice cream: a waffle cone under a mint scoop and a strawberry scoop with a drip
            jkp_cx_begin(_c); jkp__s_poly(_c, [-0.4, -0.02, 0.4, -0.02, 0.02, 0.9, -0.02, 0.9]); jkp__s_body(_c, [222, 160, 84], 0, 0.35, 0.6);
            jkp_cx_save(_c); jkp_cx_begin(_c); jkp__s_poly(_c, [-0.4, -0.02, 0.4, -0.02, 0.02, 0.9, -0.02, 0.9]); jkp_cx_clip(_c);
            for (var _w = -3; _w <= 3; _w++) {
                jkp_cx_begin(_c); jkp__s_polyline(_c, [_w * 0.16 - 0.4, -0.1, _w * 0.16 + 0.4, 1.0]); jkp__s_line(_c, [150, 96, 40], 0.035, 0.8);
                jkp_cx_begin(_c); jkp__s_polyline(_c, [_w * 0.16 + 0.4, -0.1, _w * 0.16 - 0.4, 1.0]); jkp__s_line(_c, [150, 96, 40], 0.035, 0.8);
            }
            jkp_cx_restore(_c);
            jkp_cx_begin(_c); jkp__s_poly(_c, [-0.4, -0.02, 0.4, -0.02, 0.02, 0.9, -0.02, 0.9]); jkp__s_line(_c, [120, 70, 30], 0.045);
            var _sc1 = [-0.5, 0.04, -0.56, -0.2, -0.36, -0.36, -0.1, -0.3, 0.12, -0.38, 0.38, -0.3, 0.54, -0.14, 0.5, 0.06, 0.3, 0.12, 0.12, 0.06, -0.08, 0.14, -0.3, 0.08];
            jkp_cx_begin(_c); jkp__s_smooth(_c, _sc1); jkp__s_body(_c, [150, 226, 190], 0, -0.12, 0.6);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0.02, -0.46, 0.36); jkp__s_body(_c, [250, 140, 170], 0.02, -0.46, 0.36);
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.16, -0.18); jkp_cx_quad(_c, -0.14, 0.02, -0.08, 0.04); jkp_cx_quad(_c, -0.02, 0.02, -0.02, -0.16); jkp_cx_close(_c); jkp__s_flat(_c, [250, 140, 170]);
            var _chips = [[-0.18, -0.6, 0.6], [0.14, -0.66, -0.4], [0.2, -0.4, 1.2], [-0.1, -0.44, -1.0], [0.3, -0.12, 0.3], [-0.34, -0.06, -0.6]];
            var _cc = [[120, 60, 30], [255, 240, 120], [120, 200, 255], [255, 255, 255], [120, 60, 30], [255, 120, 160]];
            for (var _k3 = 0; _k3 < 6; _k3++) { var _cx3 = _chips[_k3][0], _cy3 = _chips[_k3][1], _cr3 = _chips[_k3][2]; jkp_cx_begin(_c); jkp__s_polyline(_c, [_cx3 - cos(_cr3) * 0.045, _cy3 - sin(_cr3) * 0.045, _cx3 + cos(_cr3) * 0.045, _cy3 + sin(_cr3) * 0.045]); jkp__s_line(_c, _cc[_k3], 0.035); }
            jkp__s_shine(_c, -0.1, -0.66, 0.14, 0.07, -0.5, 0.85);
            break;
        case 4: // donut: dough ring, pink icing, sprinkles
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, 0.04, 0.84, 0.74, 0); jkp_cx_move(_c, 0.26, 0.0); jkp_cx_ellipse(_c, 0, 0.0, 0.26, 0.2, 0, 0, -2 * pi, true); jkp_cx_close(_c);
            jkp__s_drop(_c);
            var _gd = jkp_cx_radial(_c, -0.3, -0.3, 0.05, 0, 0.04, 0.9);
            jkp_cx_stop(_gd, 0, [250, 210, 150]); jkp_cx_stop(_gd, 0.6, [214, 150, 80]); jkp_cx_stop(_gd, 1, [150, 90, 40]);
            _c.fill = _gd; jkp_cx_fill_rule(_c, JKP_FILL_EVENODD); jkp__s_line(_c, [110, 60, 20], 0.045);
            var _ic = [];
            for (var _i2 = 0; _i2 < 24; _i2++) { var _a2 = _i2 / 24 * 2 * pi, _r2 = 0.7 + 0.06 * sin(_i2 * 2.7); array_push(_ic, cos(_a2) * _r2, sin(_a2) * _r2 * 0.88 - 0.02); }
            jkp_cx_begin(_c); jkp__s_smooth(_c, _ic);
            jkp_cx_move(_c, 0.34, -0.02); jkp_cx_ellipse(_c, 0, -0.02, 0.34, 0.27, 0, 0, -2 * pi, true); jkp_cx_close(_c);
            var _gi = jkp_cx_radial(_c, -0.25, -0.3, 0.05, 0, -0.02, 0.8);
            jkp_cx_stop(_gi, 0, [255, 200, 230]); jkp_cx_stop(_gi, 0.6, [246, 120, 180]); jkp_cx_stop(_gi, 1, [200, 70, 130]);
            _c.fill = _gi; jkp_cx_fill_rule(_c, JKP_FILL_EVENODD);
            var _spc = [[255, 255, 255], [90, 200, 250], [255, 220, 60], [120, 220, 110], [180, 120, 250]];
            var _gs = jkp_rng(77);
            for (var _sp = 0; _sp < 22; _sp++) {
                var _as = jkp_rand(_gs) * 2 * pi, _rs = 0.44 + jkp_rand(_gs) * 0.2, _rot = jkp_rand(_gs) * pi;
                var _sx2 = cos(_as) * _rs, _sy2 = sin(_as) * _rs * 0.88 - 0.02;
                jkp_cx_begin(_c); jkp__s_polyline(_c, [_sx2 - cos(_rot) * 0.05, _sy2 - sin(_rot) * 0.05, _sx2 + cos(_rot) * 0.05, _sy2 + sin(_rot) * 0.05]);
                jkp__s_line(_c, _spc[_sp mod 5], 0.035);
            }
            jkp__s_shine(_c, -0.3, -0.42, 0.3, 0.08, -0.35, 0.6);
            break;
        case 5: // cupcake
            jkp_cx_begin(_c); jkp__s_poly(_c, [-0.6, 0.06, 0.6, 0.06, 0.44, 0.84, -0.44, 0.84]); jkp__s_body(_c, [90, 170, 230], 0, 0.45, 0.6);
            for (var _pl = 0; _pl < 6; _pl++) { var _fx = -0.5 + _pl * 0.2; jkp_cx_begin(_c); jkp__s_polyline(_c, [_fx, 0.1, _fx * 0.76, 0.82]); jkp__s_line(_c, [40, 110, 170], 0.03, 0.7); }
            var _fr = [-0.7, 0.12, -0.74, -0.14, -0.5, -0.36, -0.42, -0.62, -0.12, -0.7, 0.12, -0.7, 0.42, -0.62, 0.5, -0.36, 0.74, -0.14, 0.7, 0.12];
            jkp_cx_begin(_c); jkp__s_smooth(_c, _fr); jkp__s_body(_c, [255, 236, 214], -0.05, -0.3, 0.75);
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.56, -0.14); jkp_cx_quad(_c, 0, -0.36, 0.56, -0.14); jkp__s_line(_c, [220, 190, 170], 0.04, 0.8);
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.36, -0.44); jkp_cx_quad(_c, 0, -0.6, 0.36, -0.44); jkp__s_line(_c, [220, 190, 170], 0.04, 0.8);
            jkp_cx_begin(_c); jkp_cx_move(_c, 0.02, -0.7); jkp_cx_quad(_c, 0.1, -0.92, 0.24, -0.94); jkp__s_line(_c, [60, 120, 40], 0.04);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0.0, -0.72, 0.15); jkp__s_body(_c, [222, 20, 50], 0, -0.72, 0.15, 0.035);
            jkp__s_shine(_c, -0.05, -0.78, 0.05, 0.03, -0.6, 0.9);
            break;
        case 6: // candy cane: a white hook banded red
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.2, 0.86); jkp_cx_line(_c, -0.2, -0.32); jkp_cx_arc(_c, 0.16, -0.32, 0.36, pi, 2 * pi); jkp_cx_line(_c, 0.52, -0.1);
            jkp__s_line(_c, [110, 20, 30], 0.36);
            jkp__s_line(_c, [250, 246, 240], 0.28);
            _c.dash = [0.14, 0.14];
            jkp__s_line(_c, [222, 30, 44], 0.28);
            _c.dash = [];
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.26, 0.8); jkp_cx_line(_c, -0.26, -0.32); jkp_cx_arc(_c, 0.16, -0.32, 0.42, pi, 1.45 * pi);
            jkp__s_line(_c, [255, 255, 255], 0.05, 0.75);
            break;
        default: // heart
            var _hp = [];
            for (var _hh = 0; _hh < 40; _hh++) { var _tt = _hh / 40 * 2 * pi; array_push(_hp, 16 * power(sin(_tt), 3) / 19, -(13 * cos(_tt) - 5 * cos(2 * _tt) - 2 * cos(3 * _tt) - cos(4 * _tt)) / 19 + 0.06); }
            jkp_cx_begin(_c); jkp__s_poly(_c, _hp); jkp__s_body(_c, [236, 30, 70], -0.1, -0.15, 0.85);
            jkp_cx_begin(_c); jkp__s_poly(_c, jkp__s_scale_pts(_hp, 0.7, 0, 0.0)); jkp__s_line(_c, [255, 150, 180], 0.035, 0.6);
            jkp__s_shine(_c, -0.36, -0.42, 0.2, 0.12, -0.6, 0.9);
            jkp__s_spark(_c, 0.5, -0.56, 0.18, 1);
            break;
    }
}

// ---------------------------------------------------------------------------------------------------------------
// SPACE
// ---------------------------------------------------------------------------------------------------------------

function jkp__p_space(_c, _id) {
    switch (_id) {
        case 0: // moon: a cratered disc with a soft terminator
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, 0, 0.78); jkp__s_body(_c, [236, 222, 170], 0, 0, 0.78);
            var _cr = [[-0.3, -0.2, 0.17], [0.28, 0.12, 0.13], [-0.08, 0.38, 0.1], [0.3, -0.38, 0.08], [-0.46, 0.22, 0.07], [0.04, -0.06, 0.06]];
            for (var _i = 0; _i < 6; _i++) {
                var _x = _cr[_i][0], _y = _cr[_i][1], _r = _cr[_i][2];
                jkp_cx_begin(_c); jkp__s_circle(_c, _x, _y, _r); jkp__s_flat(_c, [196, 176, 120]);
                jkp_cx_begin(_c); jkp_cx_arc(_c, _x, _y, _r, pi * 0.1, pi * 0.9); jkp__s_line(_c, [255, 248, 220], 0.03, 0.9);
                jkp_cx_begin(_c); jkp_cx_arc(_c, _x, _y, _r, pi * 1.1, pi * 1.9); jkp__s_line(_c, [140, 120, 76], 0.03, 0.8);
            }
            jkp_cx_save(_c); jkp_cx_begin(_c); jkp__s_circle(_c, 0, 0, 0.78); jkp_cx_clip(_c);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0.42, 0.3, 0.8); jkp__s_flat(_c, [20, 20, 50], 0.35);
            jkp_cx_restore(_c);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, 0, 0.78); jkp__s_line(_c, [90, 90, 96], 0.05);
            jkp__s_shine(_c, -0.32, -0.4, 0.22, 0.1, -0.6, 0.45);
            break;
        case 1: // comet: a glowing head and a fanned tail
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.5, 0.16); jkp_cx_quad(_c, 0.1, -0.42, 0.92, -0.86); jkp_cx_quad(_c, 0.42, 0.04, -0.06, 0.62); jkp_cx_close(_c);
            var _gt = jkp_cx_linear(_c, -0.3, 0.4, 0.8, -0.75);
            jkp_cx_stop(_gt, 0, [255, 220, 120], 1); jkp_cx_stop(_gt, 0.35, [255, 120, 60], 0.85); jkp_cx_stop(_gt, 0.75, [200, 50, 150], 0.45); jkp_cx_stop(_gt, 1, [120, 40, 200], 0);
            _c.fill = _gt; jkp_cx_fill(_c);
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.34, 0.34); jkp_cx_quad(_c, 0.24, -0.12, 0.84, -0.66); jkp__s_line(_c, [255, 255, 220], 0.05, 0.75);
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.24, 0.5); jkp_cx_quad(_c, 0.3, 0.1, 0.7, -0.3); jkp__s_line(_c, [255, 200, 120], 0.035, 0.6);
            jkp_cx_begin(_c); jkp__s_circle(_c, -0.36, 0.4, 0.42); jkp__s_flat(_c, [255, 200, 120], 0.3);
            jkp_cx_begin(_c); jkp__s_circle(_c, -0.36, 0.4, 0.3); jkp__s_flat(_c, [255, 230, 170], 0.5);
            jkp_cx_begin(_c); jkp__s_circle(_c, -0.36, 0.4, 0.22); jkp__s_body(_c, [255, 246, 214], -0.36, 0.4, 0.22, 0.035, false);
            jkp__s_spark(_c, -0.36, 0.4, 0.36, 0.95);
            jkp__s_spark(_c, 0.5, 0.4, 0.12, 0.8); jkp__s_spark(_c, -0.7, -0.5, 0.1, 0.7);
            break;
        case 2: // ringed planet: the ring's back half, the banded sphere, the ring's front half
            jkp_cx_begin(_c); jkp_cx_ellipse(_c, 0, 0.02, 0.92, 0.26, -0.3, pi, 2 * pi); jkp__s_line(_c, [120, 90, 60], 0.13); jkp__s_line(_c, [236, 200, 150], 0.08);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, 0.02, 0.56); jkp__s_body(_c, [226, 150, 80], 0, 0.02, 0.56);
            jkp_cx_save(_c); jkp_cx_begin(_c); jkp__s_circle(_c, 0, 0.02, 0.56); jkp_cx_clip(_c);
            var _bands = [-0.3, -0.08, 0.16, 0.36];
            for (var _b = 0; _b < 4; _b++) { jkp_cx_begin(_c); jkp_cx_move(_c, -0.7, _bands[_b] + 0.2); jkp_cx_line(_c, 0.7, _bands[_b] - 0.2); jkp_cx_line(_c, 0.7, _bands[_b] - 0.12); jkp_cx_line(_c, -0.7, _bands[_b] + 0.28); jkp_cx_close(_c); jkp__s_flat(_c, [170, 90, 50], 0.55); }
            jkp_cx_restore(_c);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, 0.02, 0.56); jkp__s_line(_c, [110, 56, 20], 0.045);
            jkp_cx_begin(_c); jkp_cx_ellipse(_c, 0, 0.02, 0.92, 0.26, -0.3, 0, pi); jkp__s_line(_c, [120, 90, 60], 0.13); jkp__s_line(_c, [246, 214, 168], 0.08);
            jkp__s_shine(_c, -0.2, -0.3, 0.2, 0.09, -0.6, 0.55);
            break;
        case 3: // star: a glowing five-pointed star
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, 0.02, 0.86); var _gh = jkp_cx_radial(_c, 0, 0.02, 0.1, 0, 0.02, 0.86); jkp_cx_stop(_gh, 0, [255, 240, 150], 0.7); jkp_cx_stop(_gh, 1, [255, 200, 80], 0); _c.fill = _gh; jkp_cx_fill(_c);
            var _sp = jkp__s_rpoly(0, 0.06, 0.82, 5, -pi / 2, 0.44);
            jkp_cx_begin(_c); jkp__s_poly(_c, _sp);
            jkp__s_drop(_c);
            var _gs = jkp_cx_radial(_c, -0.2, -0.25, 0.04, 0, 0.06, 0.85);
            jkp_cx_stop(_gs, 0, [255, 255, 220]); jkp_cx_stop(_gs, 0.45, [255, 214, 50]); jkp_cx_stop(_gs, 1, [214, 130, 10]);
            _c.fill = _gs; jkp_cx_fill(_c);
            _c.join = 1; jkp__s_line(_c, [150, 80, 0], 0.055); _c.join = 0;
            for (var _k = 0; _k < 5; _k++) { var _ak = -pi / 2 + _k / 5 * 2 * pi; jkp_cx_begin(_c); jkp__s_polyline(_c, [0, 0.06, cos(_ak) * 0.7, 0.06 + sin(_ak) * 0.7]); jkp__s_line(_c, [255, 250, 200], 0.025, 0.6); }
            jkp__s_spark(_c, 0.62, -0.64, 0.16, 1);
            break;
        case 4: // rocket, nose to the upper right, flame behind
            jkp_cx_save(_c); jkp_cx_rotate(_c, pi / 4);
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.14, 0.62); jkp_cx_quad(_c, 0, 1.02, 0.14, 0.62); jkp_cx_close(_c); jkp__s_flat(_c, [255, 160, 40]);
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.08, 0.62); jkp_cx_quad(_c, 0, 0.86, 0.08, 0.62); jkp_cx_close(_c); jkp__s_flat(_c, [255, 240, 160]);
            for (var _f = -1; _f <= 1; _f += 2) { jkp_cx_begin(_c); jkp__s_poly(_c, [_f * 0.2, 0.14, _f * 0.46, 0.5, _f * 0.44, 0.7, _f * 0.2, 0.52]); jkp__s_body(_c, [214, 40, 50], _f * 0.32, 0.45, 0.3, 0.045); }
            jkp_cx_begin(_c); jkp_cx_move(_c, 0, -0.86); jkp_cx_bezier(_c, 0.3, -0.6, 0.3, 0.2, 0.2, 0.6); jkp_cx_line(_c, -0.2, 0.6); jkp_cx_bezier(_c, -0.3, 0.2, -0.3, -0.6, 0, -0.86); jkp_cx_close(_c);
            jkp__s_body(_c, [236, 236, 244], -0.05, -0.1, 0.7);
            jkp_cx_save(_c);
            jkp_cx_begin(_c); jkp_cx_move(_c, 0, -0.86); jkp_cx_bezier(_c, 0.3, -0.6, 0.3, 0.2, 0.2, 0.6); jkp_cx_line(_c, -0.2, 0.6); jkp_cx_bezier(_c, -0.3, 0.2, -0.3, -0.6, 0, -0.86); jkp_cx_close(_c);
            jkp_cx_clip(_c);
            jkp_cx_begin(_c); jkp_cx_rect(_c, -0.5, -1, 1, 0.5); jkp__s_flat(_c, [214, 40, 50]);
            jkp_cx_begin(_c); jkp_cx_rect(_c, -0.5, 0.44, 1, 0.2); jkp__s_flat(_c, [214, 40, 50]);
            jkp_cx_restore(_c);
            jkp_cx_begin(_c); jkp_cx_move(_c, 0, -0.86); jkp_cx_bezier(_c, 0.3, -0.6, 0.3, 0.2, 0.2, 0.6); jkp_cx_line(_c, -0.2, 0.6); jkp_cx_bezier(_c, -0.3, 0.2, -0.3, -0.6, 0, -0.86); jkp_cx_close(_c);
            jkp__s_line(_c, [60, 60, 80], 0.05);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, -0.14, 0.13); jkp__s_flat(_c, [80, 90, 110]);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, -0.14, 0.09); jkp__s_body(_c, [90, 200, 250], 0, -0.14, 0.09, 0.02, false);
            jkp__s_shine(_c, -0.12, -0.3, 0.04, 0.3, 0, 0.7);
            jkp_cx_restore(_c);
            break;
        case 5: // saucer: a glass dome on a lit disc
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.36, -0.06); jkp_cx_bezier(_c, -0.36, -0.62, 0.36, -0.62, 0.36, -0.06); jkp_cx_close(_c);
            var _gd = jkp_cx_radial(_c, -0.12, -0.4, 0.02, 0, -0.1, 0.45);
            jkp_cx_stop(_gd, 0, [230, 255, 255], 0.95); jkp_cx_stop(_gd, 1, [60, 170, 200], 0.85);
            _c.fill = _gd; jkp_cx_fill(_c); jkp__s_line(_c, [30, 90, 110], 0.04);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, -0.18, 0.12); jkp__s_flat(_c, [120, 220, 120]);
            jkp_cx_begin(_c); jkp__s_circle(_c, -0.04, -0.2, 0.025); jkp__s_circle(_c, 0.05, -0.2, 0.025); jkp__s_flat(_c, [20, 30, 20]);
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, 0.06, 0.9, 0.26, 0); jkp__s_body(_c, [176, 184, 200], -0.1, 0.0, 0.9);
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, 0.18, 0.52, 0.1, 0); jkp__s_flat(_c, [90, 96, 112]);
            var _lc = [[255, 80, 80], [255, 220, 60], [80, 220, 120], [80, 180, 255], [255, 120, 220]];
            for (var _l = 0; _l < 5; _l++) { var _lx = -0.64 + _l * 0.32; jkp_cx_begin(_c); jkp__s_circle(_c, _lx, 0.08 + abs(_lx) * -0.06, 0.06); jkp__s_body(_c, _lc[_l], _lx, 0.08, 0.06, 0.02, false); }
            jkp__s_shine(_c, -0.16, -0.36, 0.1, 0.05, -0.5, 0.95);
            jkp__s_shine(_c, -0.3, -0.04, 0.36, 0.05, 0, 0.6);
            break;
        case 6: // helmet: white shell, gold visor with a reflection, neck ring
            jkp_cx_begin(_c); jkp_cx_round_rect(_c, -0.5, 0.52, 1.0, 0.24, 0.08); jkp__s_body(_c, [150, 156, 170], 0, 0.64, 0.5, 0.045);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, -0.06, 0.72); jkp__s_body(_c, [244, 244, 248], -0.05, -0.1, 0.75);
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0.04, -0.04, 0.5, 0.4, 0);
            var _gv = jkp_cx_linear(_c, -0.4, -0.4, 0.5, 0.36);
            jkp_cx_stop(_gv, 0, [255, 236, 150]); jkp_cx_stop(_gv, 0.45, [236, 150, 30]); jkp_cx_stop(_gv, 1, [110, 50, 10]);
            _c.fill = _gv; jkp_cx_fill(_c); jkp__s_line(_c, [80, 60, 50], 0.05);
            jkp_cx_save(_c); jkp_cx_begin(_c); jkp__s_ellipse(_c, 0.04, -0.04, 0.5, 0.4, 0); jkp_cx_clip(_c);
            jkp_cx_begin(_c); jkp__s_poly(_c, [-0.5, -0.1, 0.0, -0.5, 0.14, -0.5, -0.36, 0.0]); jkp__s_flat(_c, [255, 255, 255], 0.55);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0.26, 0.12, 0.05); jkp__s_flat(_c, [255, 255, 255], 0.7);
            jkp_cx_restore(_c);
            jkp_cx_begin(_c); jkp__s_circle(_c, -0.62, 0.0, 0.08); jkp__s_flat(_c, [220, 40, 50]);
            jkp__s_shine(_c, -0.3, -0.6, 0.28, 0.08, -0.4, 0.8);
            break;
        default: // galaxy: a bright core and two spiral arms of stars
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, 0, 0.9, 0.62, -0.4);
            var _gg = jkp_cx_radial(_c, 0, 0, 0.02, 0, 0, 0.9);
            jkp_cx_stop(_gg, 0, [255, 240, 255], 0.95); jkp_cx_stop(_gg, 0.25, [200, 120, 255], 0.7); jkp_cx_stop(_gg, 0.7, [70, 40, 170], 0.4); jkp_cx_stop(_gg, 1, [20, 10, 60], 0);
            _c.fill = _gg; jkp_cx_fill(_c);
            var _pts = [];
            var _gr = jkp_rng(4404);
            for (var _arm = 0; _arm < 2; _arm++) for (var _n = 0; _n < 70; _n++) {
                var _u = _n / 70, _th = _arm * pi + _u * 2.6 * pi, _rr = 0.08 + 0.8 * _u;
                var _jx = (jkp_rand(_gr) - 0.5) * 0.12 * (0.4 + _u), _jy = (jkp_rand(_gr) - 0.5) * 0.12 * (0.4 + _u);
                var _ex = cos(_th) * _rr, _ey = sin(_th) * _rr * 0.62;
                var _qx = _ex * cos(-0.4) - _ey * sin(-0.4) + _jx, _qy = _ex * sin(-0.4) + _ey * cos(-0.4) + _jy;
                var _sz = 0.035 * (1.2 - _u);
                array_push(_pts, [_qx - _sz / 2, _qy - _sz / 2, _sz, _sz, (_n mod 3 == 0) ? make_colour_rgb(255, 255, 255) : make_colour_rgb(200, 170, 255), 0.95]);
            }
            jkp_cx_fill_rects(_c, _pts);
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, 0, 0.16, 0.12, -0.4); jkp__s_flat(_c, [255, 250, 230]);
            jkp__s_spark(_c, 0, 0, 0.3, 1);
            jkp__s_spark(_c, 0.62, -0.5, 0.12, 0.9); jkp__s_spark(_c, -0.6, 0.46, 0.1, 0.8);
            break;
    }
}
