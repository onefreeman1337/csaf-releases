{
  "$GMScript": "v1",
  "%Name": "jkp_symbols2",
  "name": "jkp_symbols2",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}