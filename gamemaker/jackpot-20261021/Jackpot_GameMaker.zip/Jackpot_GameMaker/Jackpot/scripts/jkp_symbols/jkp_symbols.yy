{
  "$GMScript": "v1",
  "%Name": "jkp_symbols",
  "name": "jkp_symbols",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}