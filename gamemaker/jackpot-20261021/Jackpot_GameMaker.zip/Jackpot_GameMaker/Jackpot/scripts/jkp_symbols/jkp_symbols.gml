/// jkp_symbols.gml - the symbol painters: eight themes of eight pay symbols, plus each theme's WILD plaque and SCATTER
/// medallion - 80 symbols, every one drawn by the product through the canvas kit (no sprite ships). This file holds the
/// shared painting helpers, the wild and scatter, and the Fruit, Gems, Royals and Runes themes; jkp_symbols2 holds Sea,
/// Desert Relics, Candy and Space.
///
/// Jackpot - Generated Slot Machines for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// A painter draws ONE symbol centred on (0, 0) in a unit box (-1 .. 1 both ways, y down) under the context's transform,
/// lit from the upper left. jkp_symbol_paint sets that transform up; jkp_symbol_atlas bakes a theme's ten symbols into one
/// sprite (that is what the reels draw).

// ---------------------------------------------------------------------------------------------------------------
// Colour and path helpers (internal)
// ---------------------------------------------------------------------------------------------------------------

function jkp__mix(_a, _b, _t) { return [_a[0] + (_b[0] - _a[0]) * _t, _a[1] + (_b[1] - _a[1]) * _t, _a[2] + (_b[2] - _a[2]) * _t]; }
function jkp__lit(_a, _t) { return jkp__mix(_a, [255, 255, 255], _t); }
function jkp__dk(_a, _t) { return jkp__mix(_a, [0, 0, 0], _t); }

/// @function jkp__s_circle(ctx, x, y, r)
function jkp__s_circle(_c, _x, _y, _r) { jkp_cx_move(_c, _x + _r, _y); jkp_cx_arc(_c, _x, _y, _r, 0, 2 * pi); jkp_cx_close(_c); }

/// @function jkp__s_ellipse(ctx, x, y, rx, ry, rot)
function jkp__s_ellipse(_c, _x, _y, _rx, _ry, _rot) {
    jkp_cx_move(_c, _x + _rx * cos(_rot), _y + _rx * sin(_rot));
    jkp_cx_ellipse(_c, _x, _y, _rx, _ry, _rot, 0, 2 * pi);
    jkp_cx_close(_c);
}

/// @function jkp__s_poly(ctx, flat)
/// @description A closed polygon from a flat [x0, y0, x1, y1, ...] array.
function jkp__s_poly(_c, _p) {
    jkp_cx_move(_c, _p[0], _p[1]);
    for (var _i = 2; _i < array_length(_p); _i += 2) jkp_cx_line(_c, _p[_i], _p[_i + 1]);
    jkp_cx_close(_c);
}

/// @function jkp__s_smooth(ctx, flat)
/// @description A closed SMOOTH outline through the midpoints of a flat polygon (each vertex becomes a quadratic control
/// point), so a few authored points give a rounded organic shape.
function jkp__s_smooth(_c, _p) {
    var _n = array_length(_p) div 2;
    var _mx = (_p[(_n - 1) * 2] + _p[0]) / 2, _my = (_p[(_n - 1) * 2 + 1] + _p[1]) / 2;
    jkp_cx_move(_c, _mx, _my);
    for (var _i = 0; _i < _n; _i++) {
        var _j = (_i + 1) mod _n;
        jkp_cx_quad(_c, _p[_i * 2], _p[_i * 2 + 1], (_p[_i * 2] + _p[_j * 2]) / 2, (_p[_i * 2 + 1] + _p[_j * 2 + 1]) / 2);
    }
    jkp_cx_close(_c);
}

/// @function jkp__s_drop(ctx)
/// @description The soft drop shadow of the current path (under it, toward the lower right of the light).
function jkp__s_drop(_c) { jkp_cx_shadow(_c, [12, 6, 18], 0.45, _c.u * 0.06, _c.u * 0.012, _c.u * 0.028); }

/// @function jkp__s_body(ctx, base, cx, cy, r, [outline], [shadow])
/// @description Paint the CURRENT PATH as a lit body: drop shadow, a radial ramp lit from the upper left (bright, base,
/// deep), then a dark outline in the base's own shade. outline is a width in unit-box terms (0 = none).
function jkp__s_body(_c, _base, _cx, _cy, _r, _ow = 0.055, _sh = true) {
    if (_sh) jkp__s_drop(_c);
    var _g = jkp_cx_radial(_c, _cx - _r * 0.38, _cy - _r * 0.45, _r * 0.04, _cx, _cy, _r * 1.18);
    jkp_cx_stop(_g, 0, jkp__lit(_base, 0.58));
    jkp_cx_stop(_g, 0.42, _base);
    jkp_cx_stop(_g, 1, jkp__dk(_base, 0.5));
    _c.fill = _g; jkp_cx_fill(_c);
    if (_ow > 0) { _c.stroke = jkp_cx_solid(jkp__dk(_base, 0.7)); _c.lw = _ow; jkp_cx_stroke(_c); }
}

/// @function jkp__s_flat(ctx, rgb, [alpha])
/// @description Fill the current path flat.
function jkp__s_flat(_c, _rgb, _a = 1) { _c.fill = jkp_cx_solid(_rgb, _a); jkp_cx_fill(_c); }

/// @function jkp__s_line(ctx, rgb, width, [alpha])
/// @description Stroke the current path.
function jkp__s_line(_c, _rgb, _w, _a = 1) { _c.stroke = jkp_cx_solid(_rgb, _a); _c.lw = _w; jkp_cx_stroke(_c); }

/// @function jkp__s_shine(ctx, x, y, rx, ry, rot, alpha)
/// @description A specular highlight: a white ellipse fading from its top edge down.
function jkp__s_shine(_c, _x, _y, _rx, _ry, _rot, _a) {
    jkp_cx_begin(_c); jkp__s_ellipse(_c, _x, _y, _rx, _ry, _rot);
    var _g = jkp_cx_linear(_c, _x, _y - _ry, _x, _y + _ry);
    jkp_cx_stop(_g, 0, [255, 255, 255], _a); jkp_cx_stop(_g, 1, [255, 255, 255], 0);
    _c.fill = _g; jkp_cx_fill(_c);
}

/// @function jkp__s_spark(ctx, x, y, r, alpha)
/// @description A four-pointed glint.
function jkp__s_spark(_c, _x, _y, _r, _a) {
    jkp_cx_begin(_c);
    var _q = _r * 0.22;
    jkp__s_poly(_c, [_x, _y - _r, _x + _q, _y - _q, _x + _r, _y, _x + _q, _y + _q, _x, _y + _r, _x - _q, _y + _q, _x - _r, _y, _x - _q, _y - _q]);
    jkp__s_flat(_c, [255, 255, 255], _a);
}

/// @function jkp__s_text(ctx, text, x, y, px, face, rgb, [outlineRgb], [outlineW])
/// @description A line of type centred on (x, y) (the cap height centred), struck glyph by glyph; with an outline, the line
/// is first stamped in the outline colour on a ring of offsets.
function jkp__s_text(_c, _s, _x, _y, _px, _face, _rgb, _org = undefined, _ow = 0) {
    var _w = jkp_text_width(_s, _px, _face), _adv = jkp_text_advance(_face);
    var _bx = _x - _w / 2, _by = _y + _px * 0.36;
    var _passes = (is_array(_org) && _ow > 0) ? 2 : 1;
    for (var _pass = 0; _pass < _passes; _pass++) {
        var _out = (_passes == 2 && _pass == 0);
        _c.fill = jkp_cx_solid(_out ? _org : _rgb);
        var _rings = _out ? 12 : 1;
        for (var _k = 0; _k < _rings; _k++) {
            var _ox = _out ? cos(_k / _rings * 2 * pi) * _ow : 0, _oy = _out ? sin(_k / _rings * 2 * pi) * _ow : 0;
            var _cxp = _bx;
            for (var _i = 1; _i <= string_length(_s); _i++) {
                var _ch = string_char_at(_s, _i), _o = ord(_ch);
                jkp_cx_glyph(_c, _ch, _cxp + _ox, _by + _oy, _px, _face);
                if (_o >= 32 && _o <= 126) _cxp += _adv[_o - 32] * _px;
            }
        }
    }
}

/// @function jkp__s_rpoly(cx, cy, r, n, rot, [inner])
/// @description Flat points of a regular polygon (or a star when inner > 0: alternate vertices at r * inner).
function jkp__s_rpoly(_cx, _cy, _r, _n, _rot, _inner = 0) {
    var _p = [], _m = (_inner > 0) ? _n * 2 : _n;
    for (var _i = 0; _i < _m; _i++) {
        var _a = _rot + _i / _m * 2 * pi;
        var _rr = (_inner > 0 && (_i mod 2) == 1) ? _r * _inner : _r;
        array_push(_p, _cx + cos(_a) * _rr, _cy + sin(_a) * _rr);
    }
    return _p;
}

/// @function jkp__s_leaf(ctx, x, y, len, wid, ang, rgb)
/// @description A pointed leaf from its stalk end (x, y) along angle ang, with a midrib.
function jkp__s_leaf(_c, _x, _y, _len, _wid, _ang, _rgb) {
    var _ca = cos(_ang), _sa = sin(_ang), _nx = -_sa, _ny = _ca;
    var _tx = _x + _ca * _len, _ty = _y + _sa * _len;
    jkp_cx_begin(_c);
    jkp_cx_move(_c, _x, _y);
    jkp_cx_bezier(_c, _x + _ca * _len * 0.3 + _nx * _wid, _y + _sa * _len * 0.3 + _ny * _wid, _x + _ca * _len * 0.75 + _nx * _wid * 0.8, _y + _sa * _len * 0.75 + _ny * _wid * 0.8, _tx, _ty);
    jkp_cx_bezier(_c, _x + _ca * _len * 0.75 - _nx * _wid * 0.8, _y + _sa * _len * 0.75 - _ny * _wid * 0.8, _x + _ca * _len * 0.3 - _nx * _wid, _y + _sa * _len * 0.3 - _ny * _wid, _x, _y);
    jkp_cx_close(_c);
    jkp__s_body(_c, _rgb, _x + _ca * _len * 0.5, _y + _sa * _len * 0.5, _len * 0.55, 0.045, false);
    jkp_cx_begin(_c); jkp_cx_move(_c, _x, _y); jkp_cx_quad(_c, _x + _ca * _len * 0.5 + _nx * _wid * 0.15, _y + _sa * _len * 0.5 + _ny * _wid * 0.15, _tx - _ca * _len * 0.1, _ty - _sa * _len * 0.1);
    jkp__s_line(_c, jkp__dk(_rgb, 0.45), 0.03, 0.8);
}

/// @function jkp__s_polyline(ctx, flat)
/// @description An open path through a flat point array.
function jkp__s_polyline(_c, _p) { jkp_cx_move(_c, _p[0], _p[1]); for (var _i = 2; _i < array_length(_p); _i += 2) jkp_cx_line(_c, _p[_i], _p[_i + 1]); }

// ---------------------------------------------------------------------------------------------------------------
// Theme colours, the wild and the scatter
// ---------------------------------------------------------------------------------------------------------------

/// @function jkp_theme_colours(theme)
/// @description A theme's accent colours as [r, g, b] arrays: { accent, deep, metal, glow }. theme = id or index. Pure.
/// @returns {Struct}
function jkp_theme_colours(_theme) {
    switch (jkp__theme_index(_theme)) {
        case 0: return { accent: [46, 156, 70], deep: [18, 70, 34], metal: [238, 186, 54], glow: [255, 236, 140] };
        case 1: return { accent: [122, 48, 180], deep: [46, 16, 82], metal: [222, 226, 236], glow: [214, 180, 255] };
        case 2: return { accent: [168, 24, 44], deep: [70, 8, 22], metal: [238, 190, 70], glow: [255, 220, 150] };
        case 3: return { accent: [44, 86, 138], deep: [16, 30, 56], metal: [176, 186, 198], glow: [120, 230, 255] };
        case 4: return { accent: [18, 136, 156], deep: [8, 52, 72], metal: [236, 196, 110], glow: [150, 250, 240] };
        case 5: return { accent: [34, 64, 160], deep: [14, 22, 66], metal: [240, 186, 60], glow: [255, 220, 120] };
        case 6: return { accent: [232, 80, 156], deep: [110, 20, 70], metal: [255, 214, 236], glow: [255, 190, 230] };
    }
    return { accent: [62, 48, 150], deep: [16, 12, 52], metal: [196, 206, 226], glow: [160, 220, 255] };
}

/// @function jkp__p_wild(ctx, theme)
/// @description The WILD plaque: a lit lozenge in the theme's accent, a double metal rim, WILD struck in the display face.
function jkp__p_wild(_c, _ti) {
    var _tc = jkp_theme_colours(_ti);
    jkp_cx_begin(_c); jkp_cx_round_rect(_c, -0.9, -0.6, 1.8, 1.2, 0.22);
    jkp__s_drop(_c);
    var _g = jkp_cx_linear(_c, 0, -0.6, 0, 0.6);
    jkp_cx_stop(_g, 0, jkp__lit(_tc.accent, 0.35)); jkp_cx_stop(_g, 0.5, _tc.accent); jkp_cx_stop(_g, 1, _tc.deep);
    _c.fill = _g; jkp_cx_fill(_c);
    jkp__s_line(_c, jkp__dk(_tc.metal, 0.55), 0.16);
    jkp__s_line(_c, _tc.metal, 0.1);
    jkp__s_line(_c, jkp__lit(_tc.metal, 0.6), 0.03);
    jkp_cx_begin(_c); jkp_cx_round_rect(_c, -0.72, -0.43, 1.44, 0.86, 0.13);
    jkp__s_line(_c, _tc.metal, 0.025, 0.7);
    // a radiant burst behind the word
    for (var _i = 0; _i < 12; _i++) {
        var _a = _i / 12 * 2 * pi;
        jkp_cx_begin(_c); jkp__s_poly(_c, [0, 0, cos(_a - 0.1) * 0.8, sin(_a - 0.1) * 0.5, cos(_a + 0.1) * 0.8, sin(_a + 0.1) * 0.5]);
        jkp__s_flat(_c, _tc.glow, 0.13);
    }
    // the word is fitted to the plaque's inner field (1.3 units) whatever the face's advances
    var _wpx = min(0.6, 1.3 / max(0.01, jkp_text_width("WILD", 1, JKP_FACE_DISPLAY)));
    jkp__s_text(_c, "WILD", 0, 0.02, _wpx, JKP_FACE_DISPLAY, _tc.metal, jkp__dk(_tc.deep, 0.5), 0.045);
    jkp__s_shine(_c, -0.25, -0.38, 0.55, 0.12, 0, 0.45);
    jkp__s_spark(_c, 0.7, -0.5, 0.16, 0.95);
    jkp__s_spark(_c, -0.68, 0.48, 0.11, 0.8);
}

/// @function jkp__p_emblem(ctx, theme, rgb)
/// @description The theme emblem struck on the scatter medallion, in a unit of about 0.45.
function jkp__p_emblem(_c, _ti, _rgb) {
    jkp_cx_begin(_c);
    switch (_ti) {
        case 0: jkp__s_poly(_c, jkp__s_rpoly(0, 0.02, 0.46, 5, -pi / 2, 0.45)); break;                                    // star
        case 1: jkp__s_poly(_c, [-0.42, -0.12, -0.22, -0.36, 0.22, -0.36, 0.42, -0.12, 0, 0.42]); break;                // gem
        case 2: jkp__s_poly(_c, [-0.42, 0.28, -0.46, -0.24, -0.22, 0.02, 0, -0.38, 0.22, 0.02, 0.46, -0.24, 0.42, 0.28]); break; // crown
        case 3: jkp__s_poly(_c, [0, -0.44, 0.4, 0.3, -0.4, 0.3]); break;                                                    // triangle
        case 4: jkp__s_poly(_c, [-0.06, 0.42, -0.06, -0.08, -0.34, -0.08, -0.34, -0.42, -0.24, -0.42, -0.24, -0.18, -0.06, -0.18, -0.06, -0.46, 0.06, -0.46, 0.06, -0.18, 0.24, -0.18, 0.24, -0.42, 0.34, -0.42, 0.34, -0.08, 0.06, -0.08, 0.06, 0.42]); break; // trident
        case 5: jkp__s_ellipse(_c, 0, 0, 0.44, 0.22, 0); break;                                                             // eye
        case 6: jkp__s_poly(_c, [0, 0.42, -0.42, -0.04, -0.36, -0.3, -0.12, -0.36, 0, -0.18, 0.12, -0.36, 0.36, -0.3, 0.42, -0.04]); break; // heart
        default: jkp__s_circle(_c, 0, 0, 0.3); break;                                                                       // planet
    }
    jkp__s_flat(_c, _rgb);
    if (_ti == 5) { jkp_cx_begin(_c); jkp__s_circle(_c, 0, 0, 0.14); jkp__s_flat(_c, jkp__dk(_rgb, 0.7)); }
    if (_ti == 7) { jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, 0, 0.5, 0.12, -0.35); jkp__s_line(_c, _rgb, 0.07); }
}

/// @function jkp__p_scatter(ctx, theme)
/// @description The SCATTER medallion: a struck coin of the theme's metal with a beaded rim, a sunk field in the accent
/// and the theme emblem raised in metal.
function jkp__p_scatter(_c, _ti) {
    var _tc = jkp_theme_colours(_ti);
    // radiant rays behind the coin
    for (var _i = 0; _i < 16; _i++) {
        var _a = _i / 16 * 2 * pi + 0.1;
        jkp_cx_begin(_c); jkp__s_poly(_c, [cos(_a - 0.07) * 0.6, sin(_a - 0.07) * 0.6, cos(_a) * 0.98, sin(_a) * 0.98, cos(_a + 0.07) * 0.6, sin(_a + 0.07) * 0.6]);
        jkp__s_flat(_c, _tc.glow, 0.55);
    }
    jkp_cx_begin(_c); jkp__s_circle(_c, 0, 0, 0.78);
    jkp__s_body(_c, _tc.metal, 0, 0, 0.78, 0.06);
    for (var _b = 0; _b < 28; _b++) {
        var _ab = _b / 28 * 2 * pi;
        jkp_cx_begin(_c); jkp__s_circle(_c, cos(_ab) * 0.68, sin(_ab) * 0.68, 0.035);
        jkp__s_flat(_c, jkp__lit(_tc.metal, 0.5));
    }
    jkp_cx_begin(_c); jkp__s_circle(_c, 0, 0, 0.58);
    var _g = jkp_cx_radial(_c, -0.15, -0.2, 0.05, 0, 0, 0.62);
    jkp_cx_stop(_g, 0, jkp__lit(_tc.accent, 0.3)); jkp_cx_stop(_g, 1, _tc.deep);
    _c.fill = _g; jkp_cx_fill(_c);
    jkp__s_line(_c, jkp__dk(_tc.metal, 0.5), 0.04);
    jkp_cx_save(_c); jkp_cx_translate(_c, 0.025, 0.035); jkp__p_emblem(_c, _ti, jkp__dk(_tc.deep, 0.6)); jkp_cx_restore(_c);
    jkp__p_emblem(_c, _ti, _tc.metal);
    jkp__s_shine(_c, -0.22, -0.48, 0.4, 0.13, -0.35, 0.55);
    jkp__s_spark(_c, 0.55, -0.6, 0.18, 1);
}

// ---------------------------------------------------------------------------------------------------------------
// FRUIT
// ---------------------------------------------------------------------------------------------------------------

function jkp__p_fruit(_c, _id) {
    switch (_id) {
        case 0: // cherry
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.36, 0.08); jkp_cx_quad(_c, -0.2, -0.5, 0.18, -0.78);
            jkp_cx_move(_c, 0.3, 0.16); jkp_cx_quad(_c, 0.36, -0.4, 0.18, -0.78);
            jkp__s_line(_c, [70, 50, 20], 0.12); jkp__s_line(_c, [120, 150, 50], 0.06);
            jkp__s_leaf(_c, 0.18, -0.78, 0.62, 0.22, -0.25, [70, 160, 60]);
            jkp_cx_begin(_c); jkp__s_circle(_c, -0.36, 0.4, 0.38); jkp__s_body(_c, [205, 18, 44], -0.36, 0.4, 0.38);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0.32, 0.5, 0.38); jkp__s_body(_c, [190, 14, 40], 0.32, 0.5, 0.38);
            jkp__s_shine(_c, -0.48, 0.24, 0.13, 0.08, -0.6, 0.85); jkp__s_shine(_c, 0.2, 0.34, 0.13, 0.08, -0.6, 0.85);
            break;
        case 1: // lemon
            var _p = [];
            for (var _i = 0; _i < 56; _i++) {
                var _t = _i / 56 * 2 * pi, _ct = cos(_t);
                var _x = 0.78 * _ct * (1 + 0.16 * power(abs(_ct), 14)), _y = 0.55 * sin(_t) * (1 - 0.18 * power(abs(_ct), 4));
                array_push(_p, _x * cos(-0.4) - _y * sin(-0.4), _x * sin(-0.4) + _y * cos(-0.4) + 0.05);
            }
            jkp_cx_begin(_c); jkp__s_poly(_c, _p); jkp__s_body(_c, [250, 214, 40], 0, 0.05, 0.85);
            for (var _d = 0; _d < 14; _d++) { var _a = _d * 2.39, _r = 0.15 + 0.35 * frac(_d * 0.618); jkp_cx_begin(_c); jkp__s_circle(_c, cos(_a) * _r * 1.3, sin(_a) * _r * 0.8 + 0.05, 0.018); jkp__s_flat(_c, [190, 140, 10], 0.5); }
            jkp__s_leaf(_c, 0.62, -0.42, 0.46, 0.16, -1.1, [70, 160, 60]);
            jkp__s_shine(_c, -0.3, -0.12, 0.3, 0.1, -0.4, 0.8);
            break;
        case 2: // orange
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, 0.08, 0.74); jkp__s_body(_c, [248, 138, 18], 0, 0.08, 0.74);
            for (var _d2 = 0; _d2 < 22; _d2++) { var _a2 = _d2 * 2.39996, _r2 = 0.62 * sqrt((_d2 + 0.5) / 22); jkp_cx_begin(_c); jkp__s_circle(_c, cos(_a2) * _r2, sin(_a2) * _r2 + 0.08, 0.02); jkp__s_flat(_c, [190, 80, 0], 0.45); }
            jkp_cx_begin(_c); jkp__s_poly(_c, jkp__s_rpoly(0.02, -0.6, 0.12, 5, 0, 0.45)); jkp__s_flat(_c, [90, 120, 40]);
            jkp__s_leaf(_c, 0.04, -0.62, 0.5, 0.18, -0.6, [60, 150, 60]);
            jkp__s_shine(_c, -0.28, -0.28, 0.26, 0.13, -0.6, 0.75);
            break;
        case 3: // plum
            jkp_cx_begin(_c); jkp__s_smooth(_c, [0, -0.62, 0.62, -0.5, 0.78, 0.18, 0.42, 0.78, -0.42, 0.78, -0.78, 0.18, -0.62, -0.5]);
            jkp__s_body(_c, [118, 40, 150], 0, 0.1, 0.8);
            jkp_cx_begin(_c); jkp_cx_move(_c, 0.02, -0.54); jkp_cx_bezier(_c, -0.24, -0.2, -0.22, 0.3, 0.02, 0.72);
            jkp__s_line(_c, [60, 12, 80], 0.05, 0.55);
            jkp__s_shine(_c, -0.36, -0.22, 0.22, 0.32, 0.3, 0.45);
            jkp_cx_begin(_c); jkp_cx_move(_c, 0.0, -0.56); jkp_cx_quad(_c, 0.05, -0.8, 0.2, -0.86); jkp__s_line(_c, [80, 55, 25], 0.07);
            jkp__s_leaf(_c, 0.08, -0.74, 0.42, 0.15, -0.3, [80, 165, 70]);
            break;
        case 4: // grapes
            jkp_cx_begin(_c); jkp_cx_move(_c, 0, -0.5); jkp_cx_quad(_c, 0.05, -0.75, 0.22, -0.88); jkp__s_line(_c, [80, 55, 25], 0.08);
            jkp__s_leaf(_c, 0.0, -0.66, 0.6, 0.24, -2.6, [70, 160, 60]);
            var _rows = [4, 3, 2, 1], _gy = -0.36;
            for (var _rr = 0; _rr < 4; _rr++) {
                var _k = _rows[_rr];
                for (var _g = 0; _g < _k; _g++) {
                    var _gx = (_g - (_k - 1) / 2) * 0.36;
                    var _col = ((_g + _rr) mod 2 == 0) ? [128, 52, 168] : [104, 40, 148];
                    jkp_cx_begin(_c); jkp__s_circle(_c, _gx, _gy, 0.21); jkp__s_body(_c, _col, _gx, _gy, 0.21, 0.045, _rr == 0);
                    jkp__s_shine(_c, _gx - 0.07, _gy - 0.08, 0.07, 0.04, -0.6, 0.85);
                }
                _gy += 0.31;
            }
            break;
        case 5: // melon slice
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.9, -0.22); jkp_cx_arc(_c, 0, -0.22, 0.9, pi, 0, true); jkp_cx_close(_c);
            jkp__s_body(_c, [40, 140, 50], 0, 0.1, 0.9, 0.06);
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.78, -0.22); jkp_cx_arc(_c, 0, -0.22, 0.78, pi, 0, true); jkp_cx_close(_c); jkp__s_flat(_c, [236, 244, 214]);
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.7, -0.22); jkp_cx_arc(_c, 0, -0.22, 0.7, pi, 0, true); jkp_cx_close(_c);
            jkp__s_body(_c, [236, 52, 60], 0, -0.05, 0.75, 0, false);
            for (var _s = 0; _s < 7; _s++) {
                var _sa = pi * (0.16 + _s * 0.113), _sr = (_s mod 2 == 0) ? 0.42 : 0.26;
                var _sx = cos(_sa) * _sr, _sy = -0.22 + sin(_sa) * _sr;
                jkp_cx_begin(_c); jkp__s_ellipse(_c, _sx, _sy, 0.06, 0.035, _sa); jkp__s_flat(_c, [30, 20, 20]);
            }
            jkp__s_shine(_c, -0.25, -0.14, 0.38, 0.06, 0, 0.5);
            break;
        case 6: // bell
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, -0.74, 0.12); jkp__s_body(_c, [232, 176, 36], 0, -0.74, 0.12, 0.045);
            jkp_cx_begin(_c);
            jkp_cx_move(_c, -0.24, -0.62);
            jkp_cx_bezier(_c, -0.56, -0.58, -0.6, -0.1, -0.64, 0.24);
            jkp_cx_bezier(_c, -0.66, 0.42, -0.84, 0.48, -0.84, 0.58);
            jkp_cx_line(_c, 0.84, 0.58);
            jkp_cx_bezier(_c, 0.84, 0.48, 0.66, 0.42, 0.64, 0.24);
            jkp_cx_bezier(_c, 0.6, -0.1, 0.56, -0.58, 0.24, -0.62);
            jkp_cx_close(_c);
            jkp__s_body(_c, [240, 182, 34], -0.1, -0.05, 0.85);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, 0.7, 0.13); jkp__s_body(_c, [200, 140, 30], 0, 0.7, 0.13, 0.04, false);
            jkp_cx_begin(_c); jkp_cx_round_rect(_c, -0.86, 0.46, 1.72, 0.17, 0.08); jkp__s_body(_c, [214, 150, 26], 0, 0.54, 0.86, 0.045, false);
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.58, 0.18); jkp_cx_quad(_c, 0, 0.3, 0.58, 0.18); jkp__s_line(_c, [160, 100, 10], 0.05, 0.6);
            jkp__s_shine(_c, -0.32, -0.2, 0.1, 0.42, 0.15, 0.7);
            break;
        default: // seven
            var _sv = [-0.6, -0.76, 0.62, -0.76, 0.62, -0.5, 0.0, 0.82, -0.42, 0.82, 0.16, -0.44, -0.6, -0.44];
            jkp_cx_begin(_c); jkp__s_poly(_c, _sv);
            jkp__s_drop(_c);
            _c.join = 1;
            jkp__s_line(_c, [60, 10, 20], 0.26);
            jkp__s_line(_c, [248, 196, 60], 0.15);
            _c.join = 0;
            var _g7 = jkp_cx_linear(_c, 0, -0.76, 0, 0.82);
            jkp_cx_stop(_g7, 0, [255, 90, 90]); jkp_cx_stop(_g7, 0.45, [222, 20, 36]); jkp_cx_stop(_g7, 1, [130, 6, 20]);
            _c.fill = _g7; jkp_cx_fill(_c);
            jkp_cx_begin(_c); jkp__s_polyline(_c, [-0.52, -0.66, 0.5, -0.66]); jkp__s_line(_c, [255, 200, 200], 0.05, 0.75);
            jkp__s_spark(_c, 0.56, -0.62, 0.2, 1);
            break;
    }
}

// ---------------------------------------------------------------------------------------------------------------
// GEMS
// ---------------------------------------------------------------------------------------------------------------

/// @function jkp__s_gem(ctx, outline, table, base)
/// @description A faceted stone: the outline and an inner table (both flat point arrays, same count, in the same turning
/// order); each crown facet between them takes an EXPLICIT stop by which way it faces the lamp (upper left), the table is a
/// light diagonal wash, then a dark outline.
function jkp__s_gem(_c, _o, _t, _base) {
    jkp_cx_begin(_c); jkp__s_poly(_c, _o); jkp__s_drop(_c); jkp__s_flat(_c, jkp__dk(_base, 0.3));
    var _n = array_length(_o) div 2;
    var _lx = -0.6, _ly = -0.8;
    for (var _i = 0; _i < _n; _i++) {
        var _j = (_i + 1) mod _n;
        var _mx = (_o[_i * 2] + _o[_j * 2] + _t[_i * 2] + _t[_j * 2]) / 4, _my = (_o[_i * 2 + 1] + _o[_j * 2 + 1] + _t[_i * 2 + 1] + _t[_j * 2 + 1]) / 4;
        var _ex = _o[_j * 2] - _o[_i * 2], _ey = _o[_j * 2 + 1] - _o[_i * 2 + 1], _el = max(0.0001, sqrt(_ex * _ex + _ey * _ey));
        // outward normal of the edge (the outline turns clockwise on screen)
        var _nx = _ey / _el, _ny = -_ex / _el;
        if (_nx * _mx + _ny * _my < 0) { _nx = -_nx; _ny = -_ny; }
        var _f = clamp((_nx * _lx + _ny * _ly) * 0.62 + 0.5, 0, 1);
        if ((_i mod 2) == 1) _f = clamp(_f * 0.82 + 0.06, 0, 1);
        var _col = (_f > 0.5) ? jkp__lit(_base, (_f - 0.5) * 1.3) : jkp__dk(_base, (0.5 - _f) * 1.1);
        jkp_cx_begin(_c); jkp__s_poly(_c, [_o[_i * 2], _o[_i * 2 + 1], _o[_j * 2], _o[_j * 2 + 1], _t[_j * 2], _t[_j * 2 + 1], _t[_i * 2], _t[_i * 2 + 1]]);
        jkp__s_flat(_c, _col);
        jkp__s_line(_c, jkp__dk(_base, 0.55), 0.012, 0.5);
    }
    jkp_cx_begin(_c); jkp__s_poly(_c, _t);
    var _x0 = 1, _y0 = 1, _x1 = -1, _y1 = -1;
    for (var _k = 0; _k < _n; _k++) { _x0 = min(_x0, _t[_k * 2]); _x1 = max(_x1, _t[_k * 2]); _y0 = min(_y0, _t[_k * 2 + 1]); _y1 = max(_y1, _t[_k * 2 + 1]); }
    var _g = jkp_cx_linear(_c, _x0, _y0, _x1, _y1);
    jkp_cx_stop(_g, 0, jkp__lit(_base, 0.62)); jkp_cx_stop(_g, 0.55, jkp__lit(_base, 0.2)); jkp_cx_stop(_g, 1, _base);
    _c.fill = _g; jkp_cx_fill(_c);
    jkp__s_line(_c, jkp__lit(_base, 0.7), 0.018, 0.6);
    jkp_cx_begin(_c); jkp__s_poly(_c, _o); jkp__s_line(_c, jkp__dk(_base, 0.7), 0.05);
}

/// @function jkp__s_scale_pts(flat, k, dx, dy)
function jkp__s_scale_pts(_p, _k, _dx, _dy) { var _o = []; for (var _i = 0; _i < array_length(_p); _i += 2) array_push(_o, _p[_i] * _k + _dx, _p[_i + 1] * _k + _dy); return _o; }

function jkp__p_gems(_c, _id) {
    switch (_id) {
        case 0: // amethyst: an oval brilliant
            var _o0 = []; for (var _i = 0; _i < 14; _i++) { var _a = _i / 14 * 2 * pi - pi / 2; array_push(_o0, cos(_a) * 0.62, sin(_a) * 0.84); }
            jkp__s_gem(_c, _o0, jkp__s_scale_pts(_o0, 0.55, 0, -0.06), [150, 70, 205]);
            jkp__s_spark(_c, -0.3, -0.5, 0.2, 1);
            break;
        case 1: // topaz: a cushion
            var _o1 = []; for (var _i1 = 0; _i1 < 16; _i1++) { var _a1 = _i1 / 16 * 2 * pi - pi / 4, _ca = cos(_a1), _sa = sin(_a1); var _k1 = 0.8 / power(power(abs(_ca), 3.2) + power(abs(_sa), 3.2), 1 / 3.2); array_push(_o1, _ca * _k1, _sa * _k1); }
            jkp__s_gem(_c, _o1, jkp__s_scale_pts(_o1, 0.52, 0, -0.04), [244, 168, 40]);
            jkp__s_spark(_c, 0.42, -0.5, 0.18, 1);
            break;
        case 2: // emerald: the step cut - three nested octagons, lighter toward the table
            var _w = 0.6, _h = 0.84, _q = 0.2;
            var _oc = [-_w + _q, -_h, _w - _q, -_h, _w, -_h + _q, _w, _h - _q, _w - _q, _h, -_w + _q, _h, -_w, _h - _q, -_w, -_h + _q];
            jkp_cx_begin(_c); jkp__s_poly(_c, _oc); jkp__s_drop(_c); jkp__s_flat(_c, [10, 90, 50]);
            var _steps = [[1.0, [16, 110, 62]], [0.8, [30, 150, 84]], [0.6, [48, 186, 104]], [0.42, [120, 224, 160]]];
            for (var _s = 0; _s < 4; _s++) {
                var _pp = jkp__s_scale_pts(_oc, _steps[_s][0], 0, 0);
                jkp_cx_begin(_c); jkp__s_poly(_c, _pp);
                var _ge = jkp_cx_linear(_c, -_w, -_h, _w, _h);
                jkp_cx_stop(_ge, 0, jkp__lit(_steps[_s][1], 0.25)); jkp_cx_stop(_ge, 1, jkp__dk(_steps[_s][1], 0.2));
                _c.fill = _ge; jkp_cx_fill(_c);
                jkp__s_line(_c, [8, 60, 34], 0.016, 0.6);
            }
            for (var _cc = 0; _cc < 8; _cc++) { jkp_cx_begin(_c); jkp__s_polyline(_c, [_oc[_cc * 2], _oc[_cc * 2 + 1], _oc[_cc * 2] * 0.42, _oc[_cc * 2 + 1] * 0.42]); jkp__s_line(_c, [8, 60, 34], 0.016, 0.6); }
            jkp_cx_begin(_c); jkp__s_poly(_c, _oc); jkp__s_line(_c, [6, 46, 26], 0.05);
            jkp__s_shine(_c, -0.12, -0.3, 0.16, 0.26, 0.2, 0.5);
            jkp__s_spark(_c, -0.45, -0.62, 0.18, 1);
            break;
        case 3: // sapphire: a round brilliant
            var _o3 = jkp__s_rpoly(0, 0, 0.82, 16, -pi / 2);
            jkp__s_gem(_c, _o3, jkp__s_rpoly(0, -0.04, 0.44, 16, -pi / 2), [40, 80, 220]);
            jkp_cx_begin(_c); jkp__s_poly(_c, jkp__s_rpoly(0, -0.04, 0.44, 8, -pi / 2 + pi / 8, 0.72)); jkp__s_line(_c, [200, 220, 255], 0.016, 0.5);
            jkp__s_spark(_c, 0.4, -0.55, 0.2, 1);
            break;
        case 4: // ruby: a heart cut
            var _o4 = [];
            for (var _i4 = 0; _i4 < 24; _i4++) {
                var _t4 = _i4 / 24 * 2 * pi;
                var _hx = 16 * power(sin(_t4), 3), _hy = -(13 * cos(_t4) - 5 * cos(2 * _t4) - 2 * cos(3 * _t4) - cos(4 * _t4));
                array_push(_o4, _hx / 21, _hy / 21 + 0.06);
            }
            jkp__s_gem(_c, _o4, jkp__s_scale_pts(_o4, 0.5, 0, -0.03), [222, 22, 52]);
            jkp__s_spark(_c, -0.45, -0.55, 0.2, 1);
            break;
        case 5: // pearl: a lustrous sphere in a gold cup
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.46, 0.4); jkp_cx_quad(_c, 0, 0.95, 0.46, 0.4); jkp_cx_line(_c, 0.3, 0.36); jkp_cx_quad(_c, 0, 0.66, -0.3, 0.36); jkp_cx_close(_c);
            jkp__s_body(_c, [236, 186, 60], 0, 0.55, 0.5, 0.04);
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, -0.08, 0.66);
            jkp__s_drop(_c);
            var _gp = jkp_cx_radial(_c, -0.26, -0.34, 0.02, 0, -0.08, 0.7);
            jkp_cx_stop(_gp, 0, [255, 255, 255]); jkp_cx_stop(_gp, 0.35, [246, 238, 240]); jkp_cx_stop(_gp, 0.75, [214, 206, 226]); jkp_cx_stop(_gp, 1, [150, 140, 170]);
            _c.fill = _gp; jkp_cx_fill(_c);
            jkp__s_line(_c, [110, 100, 128], 0.045);
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0.18, 0.18, 0.36, 0.22, -0.6); jkp__s_flat(_c, [255, 200, 220], 0.22);
            jkp_cx_begin(_c); jkp__s_ellipse(_c, -0.1, 0.3, 0.3, 0.14, 0.2); jkp__s_flat(_c, [180, 220, 255], 0.2);
            jkp__s_shine(_c, -0.24, -0.38, 0.2, 0.12, -0.6, 0.95);
            break;
        case 6: // opal: a cabochon with play of colour
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, 0, 0.66, 0.84, 0); jkp__s_body(_c, [200, 214, 232], 0, 0, 0.84, 0.05);
            var _hues = [[90, 220, 200], [250, 120, 160], [120, 160, 255], [250, 210, 80], [140, 240, 120]];
            for (var _f = 0; _f < 22; _f++) {
                var _af = _f * 2.39996, _rf = 0.6 * sqrt((_f + 0.5) / 22);
                var _fx = cos(_af) * _rf * 0.78, _fy = sin(_af) * _rf;
                jkp_cx_begin(_c); jkp__s_ellipse(_c, _fx, _fy, 0.13, 0.07, _af); jkp__s_flat(_c, _hues[_f mod 5], 0.55);
            }
            jkp__s_shine(_c, -0.2, -0.46, 0.34, 0.18, -0.3, 0.75);
            jkp__s_spark(_c, 0.42, -0.6, 0.16, 0.9);
            break;
        default: // diamond: the classic brilliant in profile
            var _crown = [-0.86, -0.22, -0.52, -0.62, 0.52, -0.62, 0.86, -0.22, 0, 0.86];
            jkp_cx_begin(_c); jkp__s_poly(_c, _crown); jkp__s_drop(_c); jkp__s_flat(_c, [140, 200, 236]);
            var _facets = [
                [[-0.86, -0.22, -0.52, -0.62, -0.32, -0.22], [210, 240, 255]], [[-0.52, -0.62, 0, -0.62, -0.32, -0.22], [250, 254, 255]],
                [[0, -0.62, 0.52, -0.62, 0.32, -0.22], [200, 232, 250]], [[0.52, -0.62, 0.86, -0.22, 0.32, -0.22], [150, 200, 236]],
                [[-0.32, -0.22, 0, -0.62, 0.32, -0.22], [232, 248, 255]],
                [[-0.86, -0.22, -0.32, -0.22, 0, 0.86], [170, 220, 250]], [[-0.32, -0.22, 0.32, -0.22, 0, 0.86], [120, 186, 236]],
                [[0.32, -0.22, 0.86, -0.22, 0, 0.86], [70, 140, 210]]
            ];
            for (var _df = 0; _df < array_length(_facets); _df++) { jkp_cx_begin(_c); jkp__s_poly(_c, _facets[_df][0]); jkp__s_flat(_c, _facets[_df][1]); jkp__s_line(_c, [60, 110, 170], 0.014, 0.7); }
            jkp_cx_begin(_c); jkp__s_poly(_c, _crown); jkp__s_line(_c, [30, 70, 130], 0.05);
            jkp__s_spark(_c, -0.5, -0.62, 0.24, 1); jkp__s_spark(_c, 0.3, 0.1, 0.14, 0.9);
            break;
    }
}

// ---------------------------------------------------------------------------------------------------------------
// ROYALS
// ---------------------------------------------------------------------------------------------------------------

/// @function jkp__s_letter(ctx, text, rgb)
/// @description A card letter as a slot symbol: a dark outline stamped round it, the letter in a two-tone bevel (the upper
/// half struck lighter under a rectangular clip), and a suit pip beneath.
function jkp__s_letter(_c, _s, _rgb, _suit) {
    // fitted: the letter is struck at 1.45 units tall unless its width would pass 1.4 units; a narrow letter (J) is widened
    // so every letter carries a similar weight on the reel
    // the letter sits on a card tile in a pale tint of its own colour (the treasures beside them stand free, so a low symbol
    // and a high one read apart at a glance)
    jkp_cx_begin(_c); jkp_cx_round_rect(_c, -0.8, -0.86, 1.6, 1.72, 0.22);
    jkp__s_drop(_c);
    var _gt = jkp_cx_linear(_c, 0, -0.86, 0, 0.86);
    jkp_cx_stop(_gt, 0, jkp__lit(_rgb, 0.9)); jkp_cx_stop(_gt, 1, jkp__lit(_rgb, 0.62));
    _c.fill = _gt; jkp_cx_fill(_c);
    jkp__s_line(_c, jkp__dk(_rgb, 0.35), 0.06);
    jkp_cx_begin(_c); jkp_cx_round_rect(_c, -0.68, -0.74, 1.36, 1.48, 0.15); jkp__s_line(_c, _rgb, 0.025, 0.6);
    var _w1 = max(0.01, jkp_text_width(_s, 1, JKP_FACE_DISPLAY));
    var _px = min(1.05, 1.0 / _w1);
    if (_s == "Q") _px *= 0.84;   // the display face's Q carries a long tail past its advance (measured: it reached the cell edge)
    var _sx = clamp(0.8 / (_w1 * _px), 1, 1.4);
    jkp_cx_save(_c); jkp_cx_scale(_c, _sx, 1);
    jkp__s_text(_c, _s, 0.04, 0.06, _px, JKP_FACE_DISPLAY, _rgb, jkp__dk(_rgb, 0.72), 0.09 / _sx);
    jkp_cx_save(_c);
    jkp_cx_begin(_c); jkp_cx_rect(_c, -1.4, -1.2, 2.8, 1.12); jkp_cx_clip(_c);
    jkp__s_text(_c, _s, 0.04, 0.06, _px, JKP_FACE_DISPLAY, jkp__lit(_rgb, 0.42));
    jkp_cx_restore(_c);
    jkp_cx_restore(_c);
    // the suit pip, as a card's corner index
    jkp_cx_begin(_c);
    var _y = -0.56, _r = 0.12, _ox = -0.5;
    jkp_cx_save(_c); jkp_cx_translate(_c, _ox, 0);
    switch (_suit) {
        case 0: jkp__s_poly(_c, [0, _y - _r, _r, _y + _r * 0.2, 0, _y + _r * 0.9, -_r, _y + _r * 0.2]); break;        // diamond
        case 1: jkp__s_circle(_c, -_r * 0.5, _y - _r * 0.2, _r * 0.55); jkp__s_circle(_c, _r * 0.5, _y - _r * 0.2, _r * 0.55); jkp__s_poly(_c, [-_r * 1.02, _y - _r * 0.05, _r * 1.02, _y - _r * 0.05, 0, _y + _r]); break; // heart
        case 2: jkp__s_circle(_c, 0, _y - _r * 0.45, _r * 0.48); jkp__s_circle(_c, -_r * 0.5, _y + _r * 0.12, _r * 0.48); jkp__s_circle(_c, _r * 0.5, _y + _r * 0.12, _r * 0.48); jkp__s_poly(_c, [-_r * 0.15, _y, _r * 0.15, _y, _r * 0.3, _y + _r, -_r * 0.3, _y + _r]); break; // club
        default: jkp__s_poly(_c, [0, _y - _r, _r * 0.95, _y + _r * 0.25, 0, _y + _r * 0.55, -_r * 0.95, _y + _r * 0.25]); jkp__s_poly(_c, [-_r * 0.15, _y + _r * 0.2, _r * 0.15, _y + _r * 0.2, _r * 0.3, _y + _r, -_r * 0.3, _y + _r]); break; // spade
    }
    jkp_cx_restore(_c);
    var _pc = (_suit == 0 || _suit == 1) ? [214, 24, 40] : [30, 30, 40];
    jkp__s_flat(_c, _pc);
    jkp__s_line(_c, [255, 240, 210], 0.03, 0.9);
}

function jkp__p_royals(_c, _id) {
    switch (_id) {
        case 0: jkp__s_letter(_c, "10", [52, 120, 230], 0); break;
        case 1: jkp__s_letter(_c, "J", [40, 172, 84], 2); break;
        case 2: jkp__s_letter(_c, "Q", [176, 64, 206], 1); break;
        case 3: jkp__s_letter(_c, "K", [222, 40, 52], 3); break;
        case 4: jkp__s_letter(_c, "A", [244, 150, 22], 1); break;
        case 5: // ring: a gold band (even-odd) set with a sapphire
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, 0.18, 0.72, 0.6, 0); jkp_cx_move(_c, 0.52, 0.18); jkp_cx_ellipse(_c, 0, 0.18, 0.52, 0.42, 0, 0, -2 * pi, true); jkp_cx_close(_c);
            jkp__s_drop(_c);
            var _g = jkp_cx_radial(_c, -0.3, -0.1, 0.05, 0, 0.18, 0.8);
            jkp_cx_stop(_g, 0, [255, 240, 170]); jkp_cx_stop(_g, 0.5, [236, 178, 44]); jkp_cx_stop(_g, 1, [140, 90, 10]);
            _c.fill = _g; jkp_cx_fill_rule(_c, JKP_FILL_EVENODD);
            jkp__s_line(_c, [110, 70, 10], 0.045);
            jkp_cx_begin(_c); jkp__s_poly(_c, [-0.3, -0.42, -0.2, -0.62, 0.2, -0.62, 0.3, -0.42, 0, -0.22]); jkp__s_body(_c, [230, 170, 40], 0, -0.42, 0.34, 0.04, false);
            var _o = jkp__s_rpoly(0, -0.62, 0.3, 12, -pi / 2);
            jkp__s_gem(_c, _o, jkp__s_rpoly(0, -0.64, 0.16, 12, -pi / 2), [40, 90, 220]);
            jkp__s_shine(_c, -0.48, 0.0, 0.08, 0.26, 0.3, 0.6);
            break;
        case 6: // chalice
            jkp_cx_begin(_c); jkp_cx_move(_c, -0.64, -0.68); jkp_cx_line(_c, 0.64, -0.68); jkp_cx_bezier(_c, 0.64, -0.1, 0.36, 0.1, 0.1, 0.16);
            jkp_cx_line(_c, 0.1, 0.52); jkp_cx_quad(_c, 0.5, 0.62, 0.54, 0.82); jkp_cx_line(_c, -0.54, 0.82); jkp_cx_quad(_c, -0.5, 0.62, -0.1, 0.52);
            jkp_cx_line(_c, -0.1, 0.16); jkp_cx_bezier(_c, -0.36, 0.1, -0.64, -0.1, -0.64, -0.68); jkp_cx_close(_c);
            jkp__s_body(_c, [238, 184, 46], -0.1, -0.2, 0.9);
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, -0.68, 0.64, 0.12, 0); jkp__s_body(_c, [120, 20, 40], 0, -0.68, 0.64, 0.04, false);
            jkp_cx_begin(_c); jkp_cx_round_rect(_c, -0.58, -0.4, 1.16, 0.14, 0.06); jkp__s_flat(_c, [180, 120, 20]);
            var _cols = [[220, 30, 50], [40, 90, 220], [30, 170, 90]];
            for (var _j = 0; _j < 3; _j++) { jkp_cx_begin(_c); jkp__s_circle(_c, -0.36 + _j * 0.36, -0.33, 0.085); jkp__s_body(_c, _cols[_j], -0.36 + _j * 0.36, -0.33, 0.085, 0.025, false); }
            jkp_cx_begin(_c); jkp__s_ellipse(_c, 0, 0.3, 0.17, 0.08, 0); jkp__s_body(_c, [220, 160, 30], 0, 0.3, 0.17, 0.03, false);
            jkp__s_shine(_c, -0.36, -0.36, 0.08, 0.22, 0.2, 0.7);
            break;
        default: // crown
            jkp_cx_begin(_c);
            jkp__s_poly(_c, [-0.78, 0.46, -0.86, -0.34, -0.44, 0.04, -0.22, -0.56, 0, -0.04, 0.22, -0.56, 0.44, 0.04, 0.86, -0.34, 0.78, 0.46]);
            jkp__s_body(_c, [240, 186, 40], 0, -0.05, 0.9);
            jkp_cx_begin(_c); jkp_cx_round_rect(_c, -0.82, 0.36, 1.64, 0.32, 0.08); jkp__s_body(_c, [222, 160, 30], 0, 0.52, 0.82, 0.05, false);
            var _tips = [-0.86, -0.34, -0.22, -0.56, 0.22, -0.56, 0.86, -0.34];
            for (var _t = 0; _t < 4; _t++) { jkp_cx_begin(_c); jkp__s_circle(_c, _tips[_t * 2], _tips[_t * 2 + 1] - 0.08, 0.1); jkp__s_body(_c, [248, 220, 120], _tips[_t * 2], _tips[_t * 2 + 1] - 0.08, 0.1, 0.03, false); }
            jkp_cx_begin(_c); jkp__s_circle(_c, 0, -0.16, 0.11); jkp__s_body(_c, [40, 90, 220], 0, -0.16, 0.11, 0.03, false);
            var _gc = [[220, 30, 50], [30, 170, 90], [220, 30, 50]];
            for (var _k = 0; _k < 3; _k++) { jkp_cx_begin(_c); jkp__s_ellipse(_c, -0.46 + _k * 0.46, 0.52, 0.11, 0.08, 0); jkp__s_body(_c, _gc[_k], -0.46 + _k * 0.46, 0.52, 0.11, 0.025, false); }
            jkp__s_shine(_c, -0.4, 0.42, 0.3, 0.04, 0, 0.6);
            jkp__s_spark(_c, 0.6, -0.7, 0.16, 1);
            break;
    }
}

// ---------------------------------------------------------------------------------------------------------------
// RUNES
// ---------------------------------------------------------------------------------------------------------------

/// @function jkp__rune_strokes(id)
/// @description The Elder Futhark glyph of a rune symbol as polylines (flat arrays) in about -0.55 .. 0.55.
function jkp__rune_strokes(_id) {
    switch (_id) {
        case 0: return [[-0.18, 0.55, -0.18, -0.55], [-0.18, -0.05, 0.3, -0.5], [-0.18, 0.22, 0.3, -0.18]];             // fehu
        case 1: return [[-0.26, 0.55, -0.26, -0.55, 0.26, -0.18, 0.26, 0.55]];                                            // uruz
        case 2: return [[-0.18, 0.55, -0.18, -0.55], [-0.18, -0.3, 0.26, 0.0, -0.18, 0.3]];                               // thurisaz
        case 3: return [[-0.2, 0.55, -0.2, -0.55], [-0.2, -0.55, 0.3, -0.2], [-0.2, -0.22, 0.3, 0.13]];                   // ansuz
        case 4: return [[-0.2, 0.55, -0.2, -0.55, 0.26, -0.3, -0.2, -0.04, 0.28, 0.55]];                                  // raido
        case 5: return [[0.24, -0.46, -0.24, 0.0, 0.24, 0.46]];                                                           // kenaz
        case 6: return [[-0.4, -0.5, 0.4, 0.5], [0.4, -0.5, -0.4, 0.5]];                                                  // gebo
    }
    return [[-0.2, 0.55, -0.2, -0.55, 0.26, -0.3, -0.2, -0.04]];                                                         // wunjo
}

function jkp__p_runes(_c, _id, _matId = -1) {
    // the stone: a rounded irregular slab whose outline is seeded per rune; every rune has its OWN stone and its own glow
    // (a carved glyph alone is a difference drawn inside a filled shape - at reel size the stones must differ in colour)
    var _g = jkp_rng(9001 + _id * 37), _p = [];
    for (var _i = 0; _i < 9; _i++) {
        var _a = _i / 9 * 2 * pi - pi / 2 + (jkp_rand(_g) - 0.5) * 0.25;
        var _r = 0.8 + (jkp_rand(_g) - 0.5) * 0.14;
        array_push(_p, cos(_a) * _r * 0.86, sin(_a) * _r);
    }
    var _mats = [[150, 146, 140], [170, 128, 84], [84, 104, 140], [76, 130, 100], [150, 70, 60], [214, 204, 180], [60, 52, 80], [36, 34, 44]];
    var _glows = [[255, 236, 190], [255, 210, 120], [130, 220, 255], [170, 255, 170], [255, 160, 110], [120, 70, 30], [210, 150, 255], [255, 210, 80]];
    var _mi = (_matId >= 0 && _matId <= 7) ? _matId : _id;   // _matId exists for the suite's same-stone control only
    var _mat = _mats[_mi], _glow = _glows[_mi];
    jkp_cx_begin(_c); jkp__s_smooth(_c, _p); jkp__s_body(_c, _mat, 0, 0, 0.85, 0.06);
    if (_id >= 6) { jkp_cx_begin(_c); jkp__s_smooth(_c, jkp__s_scale_pts(_p, 0.9, 0, 0)); jkp__s_line(_c, (_id == 7) ? [236, 186, 60] : [190, 150, 240], 0.04, 0.85); }
    // grain: speckle in the stone's own light and dark
    var _list = [];
    for (var _s = 0; _s < 70; _s++) {
        var _sa = jkp_rand(_g) * 2 * pi, _sr = 0.68 * sqrt(jkp_rand(_g));
        var _lt = jkp_rand(_g) < 0.5;
        array_push(_list, [cos(_sa) * _sr * 0.86, sin(_sa) * _sr, 0.03, 0.03, jkp_col(_lt ? jkp__lit(_mat, 0.35) : jkp__dk(_mat, 0.35)), 0.55]);
    }
    jkp_cx_fill_rects(_c, _list);
    var _st = jkp__rune_strokes(_id);
    _c.join = 1;
    var _oxs = [0, 0.022, -0.016, 0], _oys = [0, 0.03, -0.022, 0];
    for (var _pass = 0; _pass < 4; _pass++) {
        for (var _k = 0; _k < array_length(_st); _k++) {
            jkp_cx_save(_c);
            var _ox = _oxs[_pass], _oy = _oys[_pass];
            jkp_cx_translate(_c, _ox, _oy - 0.04);
            jkp_cx_begin(_c); jkp__s_polyline(_c, _st[_k]);
            if (_pass == 0) jkp__s_line(_c, _glow, 0.34, 0.25);
            else if (_pass == 1) jkp__s_line(_c, jkp__dk(_mat, 0.75), 0.17);
            else if (_pass == 2) jkp__s_line(_c, jkp__lit(_mat, 0.45), 0.15);
            else jkp__s_line(_c, _glow, 0.12);
            jkp_cx_restore(_c);
        }
    }
    _c.join = 0;
    jkp__s_shine(_c, -0.3, -0.5, 0.3, 0.1, -0.3, 0.35);
}

// ---------------------------------------------------------------------------------------------------------------
// Dispatch and bake
// ---------------------------------------------------------------------------------------------------------------

/// @function jkp_symbol_paint(ctx, theme, id, cx, cy, px)
/// @description Paint one symbol centred on (cx, cy), px pixels square, through a canvas context (jkp_cx_create) onto the
/// current SURFACE target. theme = id or index, id = 0..7 pay symbols, JKP_WILD, JKP_SCATTER. Returns false (and draws
/// nothing) for anything else. The context's state is restored.
/// @returns {Bool}
function jkp_symbol_paint(_c, _theme, _id, _cx, _cy, _px) {
    var _ti = jkp__theme_index(_theme);
    if (_ti < 0 || !is_struct(_c) || !is_numeric(_id) || !is_numeric(_px) || !(_px > 0) || _px > 4096) return false;
    if (!(_id == floor(_id) && _id >= 0 && _id <= 9)) return false;
    jkp_cx_save(_c);
    jkp_cx_translate(_c, _cx, _cy);
    jkp_cx_scale(_c, _px / 2, _px / 2);
    _c.u = _px;
    if (_id == JKP_WILD) jkp__p_wild(_c, _ti);
    else if (_id == JKP_SCATTER) jkp__p_scatter(_c, _ti);
    else switch (_ti) {
        case 0: jkp__p_fruit(_c, _id); break;
        case 1: jkp__p_gems(_c, _id); break;
        case 2: jkp__p_royals(_c, _id); break;
        case 3: jkp__p_runes(_c, _id); break;
        case 4: jkp__p_sea(_c, _id); break;
        case 5: jkp__p_desert(_c, _id); break;
        case 6: jkp__p_candy(_c, _id); break;
        default: jkp__p_space(_c, _id); break;
    }
    jkp_cx_restore(_c);
    return true;
}

/// @function jkp_symbol_atlas(theme, px)
/// @description The theme's ten symbols baked side by side into ONE sprite (cell px x px, symbol i at x = i * px), drawn at
/// 2x and filtered down. Cached per theme and size until jkp_symbol_atlas_free: the first call per theme and size costs a
/// bake (roughly a quarter to a whole second on the VM - do it on a loading screen), later calls are free. The sprite is
/// PREMULTIPLIED: draw it with jkp_draw_premul (or gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha)). Returns -1 for a
/// bad theme or a size outside 8 .. 512.
/// @returns {Asset.GMSprite}
function jkp_symbol_atlas(_theme, _px) {
    var _ti = jkp__theme_index(_theme);
    if (_ti < 0 || !is_numeric(_px) || is_nan(_px) || _px < 8 || _px > 512) return -1;
    _px = floor(_px);
    if (!variable_global_exists("jkp_atlas_cache")) global.jkp_atlas_cache = {};
    var _key = string(_ti) + "_" + string(_px);
    var _hit = global.jkp_atlas_cache[$ _key];
    if (!is_undefined(_hit) && sprite_exists(_hit)) return _hit;
    var _w = _px * 10, _h = _px;
    var _s2 = surface_create(_w * 2, _h * 2), _s1 = surface_create(_w, _h);
    var _pm = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_build_identity());
    surface_set_target(_s2);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false);
    var _c = jkp_cx_create(2);
    for (var _i = 0; _i < 10; _i++) jkp_symbol_paint(_c, _ti, _i, _px * (_i + 0.5), _px * 0.5, _px * 0.9);
    gpu_pop_state();
    surface_reset_target();
    surface_set_target(_s1);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    gpu_set_blendmode_ext(bm_one, bm_zero); gpu_set_texfilter(true);
    draw_surface_ext(_s2, 0, 0, 0.5, 0.5, 0, c_white, 1);
    gpu_pop_state();
    surface_reset_target();
    var _spr = sprite_create_from_surface(_s1, 0, 0, _w, _h, false, false, 0, 0);
    surface_free(_s2); surface_free(_s1);
    matrix_set(matrix_world, _pm);
    global.jkp_atlas_cache[$ _key] = _spr;
    return _spr;
}

/// @function jkp_symbol_atlas_free()
/// @description Free every cached symbol atlas (call from Clean Up of whatever owns the machines, never mid-frame).
function jkp_symbol_atlas_free() {
    if (!variable_global_exists("jkp_atlas_cache")) return;
    var _k = variable_struct_get_names(global.jkp_atlas_cache);
    for (var _i = 0; _i < array_length(_k); _i++) { var _s = global.jkp_atlas_cache[$ _k[_i]]; if (!is_undefined(_s) && sprite_exists(_s)) sprite_delete(_s); }
    global.jkp_atlas_cache = {};
}

/// @function jkp_draw_premul(sprite, sub, left, top, w, h, x, y, xs, ys, alpha)
/// @description Draw part of a PREMULTIPLIED sprite (every Jackpot bake) correctly: bm_one / bm_inv_src_alpha, the colour
/// scaled by alpha. The caller's blend mode is restored.
function jkp_draw_premul(_spr, _sub, _l, _t, _w, _h, _x, _y, _xs, _ys, _a) {
    // a sprite handle may be a number or a ref; anything else (a string, a struct) is refused, never thrown on
    var _ok = false;
    try { _ok = sprite_exists(_spr); } catch (_e) { _ok = false; }
    if (!_ok || !is_numeric(_a) || !(_a > 0)) return;
    if (!is_numeric(_sub) || !is_numeric(_l) || !is_numeric(_t) || !is_numeric(_w) || !is_numeric(_h) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_xs) || !is_numeric(_ys)) return;
    gpu_push_state();
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    var _al = clamp(_a, 0, 1);
    draw_sprite_part_ext(_spr, _sub, _l, _t, _w, _h, _x, _y, _xs, _ys, merge_colour(c_black, c_white, _al), _al);
    gpu_pop_state();
}
