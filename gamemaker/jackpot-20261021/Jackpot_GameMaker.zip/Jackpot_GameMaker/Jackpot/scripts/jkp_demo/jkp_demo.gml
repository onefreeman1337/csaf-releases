/// jkp_demo.gml - THE GAME CORNER, Jackpot's demo room: eight generated machines, one per theme, on all three cabinets and
/// both reel counts, sharing one purse of play money. Beside the machine: its pay table and its exact figures. Keys:
///   SPACE / ENTER spin (or click SPIN, or pull the lever)   UP / DOWN line bet   L lines   LEFT / RIGHT or 1-8 machine
///   T re-tune the pay table (85 / 90 / 92 / 95 / 98 %) - the RTP shown is recomputed exactly, the pay table re-baked
/// Everything on screen is drawn by the package; nothing is a shipped image.
///
/// Jackpot - Generated Slot Machines for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

#macro JKP_DEMO_W 960
#macro JKP_DEMO_H 640

/// @function jkp_demo_machines()
/// @description The game corner's eight machines (the same every run).
/// @returns {Array<Struct>}
function jkp_demo_machines() {
    var _th = jkp_themes(), _cabs = ["upright", "slant", "bartop", "upright", "slant", "upright", "bartop", "slant"], _reels = [3, 5, 5, 3, 5, 5, 3, 5], _o = [];
    for (var _i = 0; _i < 8; _i++) array_push(_o, jkp_machine_create({ seed: "Game Corner " + string(_i + 1), theme: _th[_i].id, cabinet: _cabs[_i], reels: _reels[_i] }));
    return _o;
}

/// @function jkp_demo_create()
/// @description Build the game corner: the machines (cheap), the room's backdrop (baked once); each machine's cabinet and
/// figures are prepared the first time it is opened.
/// @returns {Struct}
function jkp_demo_create() {
    display_set_gui_size(JKP_DEMO_W, JKP_DEMO_H);
    var _d = { machines: jkp_demo_machines(), slots: array_create(8, undefined), stats: array_create(8, undefined), pays: array_create(8, -1),
        cur: 0, purse: 1000, t: 0, bg: -1, loading: 2, tunes: [0.85, 0.9, 0.92, 0.95, 0.98], message: "", messageT: 0, hover: "" };
    return _d;
}

/// @function jkp__demo_open(demo, i)
/// @description Internal. Prepare machine i (cabinet, atlases, pay table, figures) and carry the purse to it.
function jkp__demo_open(_d, _i) {
    var _m = _d.machines[_i];
    if (is_undefined(_d.slots[_i])) { _d.slots[_i] = jkp_slot_create(_m, { credits: _d.purse }); jkp_slot_prepare(_d.slots[_i]); }
    _d.slots[_i].credits = _d.purse; _d.slots[_i].shownCredits = _d.purse;
    if (!sprite_exists(_d.pays[_i])) _d.pays[_i] = jkp_paytable_bake(_m, 400, 430, 1);
    if (is_undefined(_d.stats[_i])) _d.stats[_i] = jkp__demo_stats(_m);
    _d.cur = _i;
}

/// @function jkp__demo_stats(machine)
/// @description Internal. The figures shown beside a machine: exact RTP and line hit always; the spin hit rate and swing exact
/// for 3 reels (every stop combination), simulated over 6,000 seeded spins for 5.
function jkp__demo_stats(_m) {
    var _r = jkp_rtp(_m);
    if (_m.reels == 3) { var _x = jkp_exhaust3(_m); return { rtp: _r.rtp, lineHit: _r.lineHit, hit: _x.hitRate, sd: _x.sd, how: "exact: all " + string(_x.spins) + " stops" }; }
    var _s = jkp_simulate(_m, 6000, 2026);
    return { rtp: _r.rtp, lineHit: _r.lineHit, hit: _s.hitRate, sd: _s.sd, how: "6,000 spins simulated" };
}

/// @function jkp_demo_step(demo)
/// @description Run the game corner one frame: input, the machine, the purse.
function jkp_demo_step(_d) {
    _d.t++;
    if (_d.messageT > 0) _d.messageT--;
    if (_d.loading > 0) { _d.loading--; if (_d.loading == 0) jkp__demo_open(_d, _d.cur); return; }
    var _sl = _d.slots[_d.cur];
    var _was = _sl.state;
    // machine choice
    var _next = -1;
    if (keyboard_check_pressed(vk_right)) _next = (_d.cur + 1) mod 8;
    if (keyboard_check_pressed(vk_left)) _next = (_d.cur + 7) mod 8;
    for (var _k = 0; _k < 8; _k++) if (keyboard_check_pressed(ord(string(_k + 1)))) _next = _k;
    var _mx = device_mouse_x_to_gui(0), _my = device_mouse_y_to_gui(0);
    if (mouse_check_button_pressed(mb_left)) for (var _t = 0; _t < 8; _t++) { var _tb = jkp__demo_tab(_t); if (_mx >= _tb.x && _mx < _tb.x + _tb.w && _my >= _tb.y && _my < _tb.y + _tb.h) _next = _t; }
    if (_next >= 0 && _next != _d.cur && (_sl.state == "idle" || _sl.state == "paying")) { _d.purse = _sl.credits; _d.cur = _next; _d.loading = 2; return; }
    // the machine's own controls
    var _box = jkp__demo_machine_box(_d);
    _d.hover = jkp_slot_hit(_sl, _box.x, _box.y, _box.s, _mx, _my);
    if (keyboard_check_pressed(vk_space) || keyboard_check_pressed(vk_enter)) jkp_slot_press(_sl, is_undefined(_sl.L.lever) ? "spin" : "lever");
    if (keyboard_check_pressed(vk_up)) jkp_slot_press(_sl, "betup");
    if (keyboard_check_pressed(vk_down)) jkp_slot_press(_sl, "betdown");
    if (keyboard_check_pressed(ord("L"))) jkp_slot_press(_sl, "lines");
    if (mouse_check_button_pressed(mb_left) && _d.hover != "") jkp_slot_press(_sl, _d.hover);
    if (keyboard_check_pressed(ord("T")) && (_sl.state == "idle" || _sl.state == "paying")) jkp__demo_retune(_d);
    jkp_slot_step(_sl);
    var _ev = jkp_slot_events(_sl);
    for (var _e = 0; _e < array_length(_ev); _e++) {
        if (_ev[_e].type == "refused" && _ev[_e].reason == "credits") { _d.message = "Out of credits - the house tops you up to 1000"; _d.messageT = 150; _sl.credits = 1000; _sl.shownCredits = 1000; }
    }
    _d.purse = _sl.credits;
}

/// @function jkp__demo_retune(demo)
/// @description Internal. T: the next target in the cycle; the pay table is re-tuned exactly, re-baked, the figures redone.
function jkp__demo_retune(_d) {
    var _m = _d.machines[_d.cur], _i = 0;
    for (var _k = 0; _k < array_length(_d.tunes); _k++) if (abs(_d.tunes[_k] - _m.target) < 0.004) _i = _k + 1;
    var _tg = _d.tunes[_i mod array_length(_d.tunes)];
    jkp_tune(_m, _tg);
    if (sprite_exists(_d.pays[_d.cur])) sprite_delete(_d.pays[_d.cur]);
    _d.pays[_d.cur] = jkp_paytable_bake(_m, 400, 430, 1);
    _d.stats[_d.cur] = jkp__demo_stats(_m);
    var _sl = _d.slots[_d.cur];
    if (sprite_exists(_sl.cab)) sprite_delete(_sl.cab);
    _sl.cab = -1; jkp_slot_prepare(_sl);
    _d.message = "Re-tuned to " + string_format(_tg * 100, 1, 0) + "%: the pay table now returns " + string_format(_m.rtp * 100, 1, 3) + "% exactly"; _d.messageT = 200;
}

/// @function jkp__demo_machine_box(demo)
/// @description Internal. Where the current machine is drawn: { x, y, s } fitting a 500 x 600 box on the left.
function jkp__demo_machine_box(_d) {
    var _L = jkp_cabinet_layout(_d.machines[_d.cur]);
    var _s = min(500 / (_L.w + 30), 548 / _L.h);
    return { x: 18 + (500 - _L.w * _s) / 2, y: 14 + (548 - _L.h * _s) / 2, s: _s };
}

/// @function jkp__demo_tab(i)
/// @description Internal. The selector tab of machine i (bottom strip).
function jkp__demo_tab(_i) { return { x: 14 + _i * 117, y: 578, w: 111, h: 52 }; }

/// @function jkp__demo_backdrop()
/// @description Internal. The room: a lacquered wall with brass pinstripes and spotlights over a patterned casino carpet.
function jkp__demo_backdrop() {
    var _s2 = surface_create(JKP_DEMO_W * 2, JKP_DEMO_H * 2), _s1 = surface_create(JKP_DEMO_W, JKP_DEMO_H);
    var _pm = matrix_get(matrix_world); matrix_set(matrix_world, matrix_build_identity());
    surface_set_target(_s2); draw_clear(make_colour_rgb(20, 8, 16));
    gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    var _c = jkp_cx_create(2), _wallH = 420;
    jkp_cx_begin(_c); jkp_cx_rect(_c, 0, 0, JKP_DEMO_W, _wallH); jkp__cab_fill_y(_c, 0, _wallH, [70, 16, 34], [34, 8, 20]);
    var _stripes = [];
    for (var _x = 12; _x < JKP_DEMO_W; _x += 36) array_push(_stripes, [_x, 0, 2, _wallH, make_colour_rgb(150, 110, 50), 0.35]);
    jkp_cx_fill_rects(_c, _stripes);
    for (var _l = 0; _l < 3; _l++) {
        var _lx = 150 + _l * 330;
        jkp_cx_begin(_c); jkp__s_poly(_c, [_lx - 30, 0, _lx + 30, 0, _lx + 170, _wallH, _lx - 170, _wallH]);
        var _g = jkp_cx_linear(_c, 0, 0, 0, _wallH); jkp_cx_stop(_g, 0, [255, 220, 170], 0.22); jkp_cx_stop(_g, 1, [255, 200, 150], 0); _c.fill = _g; jkp_cx_fill(_c);
    }
    _c.fill = jkp_cx_solid([96, 14, 30]); jkp_cx_fill_rect(_c, 0, _wallH, JKP_DEMO_W, JKP_DEMO_H - _wallH);
    // the carpet: a repeating medallion and diamond pattern
    for (var _cy = _wallH + 22; _cy < JKP_DEMO_H + 20; _cy += 44) for (var _cx = ((_cy div 44) mod 2) * 22; _cx < JKP_DEMO_W + 22; _cx += 44) {
        jkp_cx_begin(_c); jkp__s_poly(_c, [_cx, _cy - 14, _cx + 14, _cy, _cx, _cy + 14, _cx - 14, _cy]); jkp__s_flat(_c, [30, 110, 110], 0.55);
        jkp_cx_begin(_c); jkp__s_circle(_c, _cx, _cy, 5); jkp__s_flat(_c, [230, 180, 70], 0.7);
        jkp_cx_begin(_c); jkp__s_circle(_c, _cx + 22, _cy, 3); jkp__s_flat(_c, [230, 180, 70], 0.45);
    }
    jkp_cx_begin(_c); jkp_cx_rect(_c, 0, _wallH - 6, JKP_DEMO_W, 12); jkp__cab_fill_y(_c, _wallH - 6, _wallH + 6, [255, 220, 130], [130, 80, 20]);
    jkp_cx_begin(_c); jkp_cx_rect(_c, 0, _wallH + 6, JKP_DEMO_W, 60); var _gs = jkp_cx_linear(_c, 0, _wallH + 6, 0, _wallH + 66); jkp_cx_stop(_gs, 0, [0, 0, 0], 0.5); jkp_cx_stop(_gs, 1, [0, 0, 0], 0); _c.fill = _gs; jkp_cx_fill(_c);
    gpu_pop_state(); surface_reset_target();
    surface_set_target(_s1); draw_clear_alpha(c_black, 0); gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_zero); gpu_set_texfilter(true); draw_surface_ext(_s2, 0, 0, 0.5, 0.5, 0, c_white, 1); gpu_pop_state(); surface_reset_target();
    var _spr = sprite_create_from_surface(_s1, 0, 0, JKP_DEMO_W, JKP_DEMO_H, false, false, 0, 0);
    surface_free(_s2); surface_free(_s1); matrix_set(matrix_world, _pm);
    return _spr;
}

/// @function jkp_demo_draw(demo)
/// @description Draw the game corner on the GUI layer.
function jkp_demo_draw(_d) {
    if (!sprite_exists(_d.bg)) _d.bg = jkp__demo_backdrop();
    draw_sprite(_d.bg, 0, 0, 0);
    var _pf = draw_get_font(), _ph = draw_get_halign(), _pv = draw_get_valign(), _pc = draw_get_colour(), _pa = draw_get_alpha();
    draw_set_halign(fa_center); draw_set_valign(fa_middle);
    if (_d.loading > 0 || is_undefined(_d.slots[_d.cur])) {
        draw_set_font(fnt_jackpot_display_s); draw_set_colour(make_colour_rgb(255, 214, 120));
        draw_text(JKP_DEMO_W / 2, JKP_DEMO_H / 2, "Building " + _d.machines[_d.cur].name + "...");
        jkp__demo_tabs(_d);
        draw_set_font(_pf); draw_set_halign(_ph); draw_set_valign(_pv); draw_set_colour(_pc); draw_set_alpha(_pa);
        return;
    }
    var _m = _d.machines[_d.cur], _sl = _d.slots[_d.cur], _box = jkp__demo_machine_box(_d);
    // a pool of light under the machine
    draw_set_alpha(0.35); draw_set_colour(c_black);
    draw_ellipse(_box.x + 10, _box.y + jkp_cabinet_layout(_m).h * _box.s - 14, _box.x + jkp_cabinet_layout(_m).w * _box.s - 10, _box.y + jkp_cabinet_layout(_m).h * _box.s + 14, false);
    draw_set_alpha(1);
    jkp_slot_draw(_sl, _box.x, _box.y, _box.s);
    // the right-hand panel: the pay table and the figures
    jkp_draw_premul(_d.pays[_d.cur], 0, 0, 0, 400, 430, 540, 14, 1, 1, 1);
    var _st = _d.stats[_d.cur];
    draw_set_alpha(0.82); draw_set_colour(make_colour_rgb(14, 8, 16)); draw_roundrect_ext(540, 452, 940, 568, 14, 14, false);
    draw_set_alpha(1); draw_set_colour(make_colour_rgb(214, 170, 80)); draw_roundrect_ext(540, 452, 940, 568, 14, 14, true);
    draw_set_halign(fa_left); draw_set_valign(fa_top);
    draw_set_font(fnt_jackpot_display_s); draw_set_colour(make_colour_rgb(255, 214, 120));
    draw_text_transformed(556, 460, string_upper(_m.name) + "  -  " + string(_m.reels) + " REELS, " + string(array_length(_m.lines)) + " LINES", 0.52, 0.52, 0);
    draw_set_font(fnt_jackpot_body_s); draw_set_colour(make_colour_rgb(246, 236, 220));
    var _tf = gpu_get_texfilter(); gpu_set_texfilter(true);
    // every line is fitted to the panel's 370 px (measured, never assumed)
    var _lines = ["Return to player " + string_format(_st.rtp * 100, 1, 3) + "% (exact)    tuned for " + string_format(_m.target * 100, 1, 0) + "%",
        "Spins that win " + string_format(_st.hit * 100, 1, 1) + "%    swing " + string_format(_st.sd, 1, 2) + " bets  (" + _st.how + ")",
        "Each line wins once in " + string_format(1 / max(0.000001, _st.lineHit), 1, 1) + " spins    purse " + string(_sl.credits)];
    for (var _li = 0; _li < 3; _li++) { var _ls = min(0.62, 370 / max(1, string_width(_lines[_li]))); draw_text_transformed(556, 484 + _li * 20, _lines[_li], _ls, _ls, 0); }
    draw_set_colour(make_colour_rgb(200, 180, 160));
    var _keys = "SPACE spin   UP/DOWN bet   L lines   1-8 machine   T re-tune", _ks = min(0.56, 370 / max(1, string_width(_keys)));
    draw_text_transformed(556, 544, _keys, _ks, _ks, 0);
    gpu_set_texfilter(_tf);
    jkp__demo_tabs(_d);
    if (_d.messageT > 0) {
        draw_set_alpha(min(1, _d.messageT / 20) * 0.85); draw_set_colour(make_colour_rgb(14, 8, 16)); draw_roundrect_ext(120, 8, 840, 40, 12, 12, false);
        draw_set_alpha(min(1, _d.messageT / 20)); draw_set_colour(make_colour_rgb(255, 230, 160)); draw_set_halign(fa_center); draw_set_valign(fa_middle);
        draw_set_font(fnt_jackpot_body_s); gpu_set_texfilter(true); draw_text_transformed(480, 24, _d.message, 0.7, 0.7, 0); gpu_set_texfilter(_tf);
    }
    draw_set_font(_pf); draw_set_halign(_ph); draw_set_valign(_pv); draw_set_colour(_pc); draw_set_alpha(_pa);
}

/// @function jkp__demo_tabs(demo)
/// @description Internal. The eight machine tabs: the theme's top symbol and the machine's name.
function jkp__demo_tabs(_d) {
    var _tf = gpu_get_texfilter(); gpu_set_texfilter(true);
    for (var _i = 0; _i < 8; _i++) {
        var _tb = jkp__demo_tab(_i), _m = _d.machines[_i], _tc = jkp_theme_colours(_m.themeIndex), _on = (_i == _d.cur);
        draw_set_alpha(_on ? 1 : 0.8); draw_set_colour(make_colour_rgb(_tc.deep[0], _tc.deep[1], _tc.deep[2]));
        draw_roundrect_ext(_tb.x, _tb.y, _tb.x + _tb.w, _tb.y + _tb.h, 12, 12, false);
        draw_set_alpha(1); draw_set_colour(_on ? make_colour_rgb(255, 214, 120) : make_colour_rgb(120, 96, 70));
        draw_roundrect_ext(_tb.x, _tb.y, _tb.x + _tb.w, _tb.y + _tb.h, 12, 12, true);
        var _at = jkp_symbol_atlas(_m.themeIndex, 40);
        jkp_draw_premul(_at, 0, 7 * 40, 0, 40, 40, _tb.x + 4, _tb.y + 6, 1, 1, 1);
        draw_set_font(fnt_jackpot_body_s); draw_set_halign(fa_left); draw_set_valign(fa_middle); draw_set_colour(make_colour_rgb(246, 236, 220));
        var _nm = _m.name, _hd = string(_i + 1) + "  " + jkp_themes()[_m.themeIndex].name;
        var _hs = min(0.42, 60 / max(1, string_width(_hd))), _ns = min(0.46, 60 / max(1, string_width(_nm)));
        draw_text_transformed(_tb.x + 46, _tb.y + 18, _hd, _hs, _hs, 0);
        draw_set_colour(make_colour_rgb(255, 214, 120));
        draw_text_transformed(_tb.x + 46, _tb.y + 36, _nm, _ns, _ns, 0);
    }
    gpu_set_texfilter(_tf);
}

/// @function jkp_demo_free(demo)
/// @description Free everything the game corner made.
function jkp_demo_free(_d) {
    for (var _i = 0; _i < 8; _i++) { if (!is_undefined(_d.slots[_i])) jkp_slot_free(_d.slots[_i]); if (sprite_exists(_d.pays[_i])) sprite_delete(_d.pays[_i]); }
    if (sprite_exists(_d.bg)) sprite_delete(_d.bg);
    jkp_symbol_atlas_free();
}
