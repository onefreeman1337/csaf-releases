{
  "$GMScript": "v1",
  "%Name": "jkp_oracle_core",
  "name": "jkp_oracle_core",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}