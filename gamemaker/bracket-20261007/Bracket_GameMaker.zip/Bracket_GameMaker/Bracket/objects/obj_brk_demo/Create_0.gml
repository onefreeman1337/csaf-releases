/// @description Bracket demo - THE HIGH STREET (a dusk street of shop fronts, every sign composed from what its shop sells,
/// the Close Look and the Signwright's Yard), and the headless entry point (-selftest).
/// ⛔ The crash handler is installed FIRST, and every variable a later event reads is declared ABOVE the early exits:
/// Clean Up always runs, even when Create leaves early.
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("brk_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.brk_stage) + ": " + string(_ex.message) + " | " + string(_ex.stacktrace));
    file_text_close(_f);
    game_end();
});
global.brk_stage = 0;
demo = undefined;
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";
if (string_pos("-selftest", _args) > 0) { global.brk_stage = 1; brk_selftest_write(brk_selftest_run()); game_end(); exit; }
demo = brk_demo_create();
