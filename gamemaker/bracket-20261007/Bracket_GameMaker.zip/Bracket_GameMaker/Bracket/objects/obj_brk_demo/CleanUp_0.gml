/// @description Bracket demo - clean up. Runs even when Create left early (-selftest).
if (is_struct(demo)) brk_demo_free(demo);
demo = undefined;
