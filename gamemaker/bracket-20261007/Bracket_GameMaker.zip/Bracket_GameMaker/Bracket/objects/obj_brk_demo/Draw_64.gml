/// @description Bracket demo - THE HIGH STREET, drawn (and painted on demand: the street, then the signs, a few at a time).
if (is_struct(demo)) brk_demo_draw(demo);
