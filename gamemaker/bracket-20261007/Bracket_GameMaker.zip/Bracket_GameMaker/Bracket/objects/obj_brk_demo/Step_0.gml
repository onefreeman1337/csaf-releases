/// @description Bracket demo - one frame of THE HIGH STREET (the keys).
if (is_struct(demo)) brk_demo_step(demo);
