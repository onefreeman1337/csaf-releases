/// brk_sign.gml - the part of Bracket your game calls: a shop's sign baked to a SPRITE (struck at twice the size and
/// filtered down, so every edge is smooth), cached so the same sign is never drawn twice, and prepared under a per-frame
/// time budget so a town full of signs never stalls a frame. Plus the two pieces of the RPG Maker MZ edition's scenes a
/// shop screen wants: the oak NAME PLAQUE that goes under a sign, and the LINTEL band that heads a shop menu.
///
/// Bracket - Shop Signs Composed from What the Shop Sells, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
///     var shop = { name: "The Gilded Tankard", prosperity: 3,
///                  goods: [{ kind: "item", name: "Amber Ale", price: 90 }, { kind: "item", name: "Spiced Mead", price: 260 }] };
///     var prof = brk_profile(shop);                 // tavern, banner, gallows... decided by what it sells
///     brk_draw_sign_sprite(prof, x, y, 150);         // in a Draw event: bakes once, then draws the cached sprite
///
/// Public functions (each documented below): brk_sign_sprite, brk_sign_ready, brk_prepare, brk_sign_box,
/// brk_draw_sign_sprite, brk_sign_cache_clear, brk_sign_cache_count, brk_draw_plaque, brk_draw_lintel.
///
/// ⛔ Baking uses SURFACES: call brk_sign_sprite, brk_prepare and brk_draw_sign_sprite from a Draw event (or a Draw GUI
/// event), as GameMaker requires of any surface work.

#macro BRK_BAKE_SS 2

// ---------------------------------------------------------------------------------------------------------------
// The cache
// ---------------------------------------------------------------------------------------------------------------

/// @function brk__sign_cache()
/// @description Internal. The cache of baked signs: { map: { key: { sprite, counts, box } }, keys: [] }.
function brk__sign_cache() {
    static _c = { map: {}, keys: [] };
    return _c;
}

/// @function brk__flush_draws()
/// @description Internal. Force GameMaker to submit any queued draws before a texture they may use is freed.
function brk__flush_draws() { var _s = surface_create(1, 1); surface_set_target(_s); surface_reset_target(); surface_free(_s); }

/// @function brk__sign_opts(options)
/// @description Internal. The options a bake honours, cleaned: { swing (degrees, rounded to 0.1), behind ("#rrggbb") }.
function brk__sign_opts(_o) {
    var _s = 0, _b = brk_palette().dusk;
    if (is_struct(_o)) {
        var _sw = _o[$ "swing"];
        if (is_numeric(_sw) && !is_nan(_sw) && !is_infinity(_sw)) _s = clamp(floor(_sw * 10 + 0.5) / 10, -45, 45);
        var _bh = _o[$ "behind"];
        if (is_string(_bh) && !is_undefined(brk_parse_hex(_bh))) _b = _bh;
    }
    return { swing: _s, behind: _b };
}

/// @function brk__sign_height(height)
/// @description Internal. A usable sign height: a finite number, rounded, clamped to 24..1024; undefined otherwise.
function brk__sign_height(_h) {
    if (!is_numeric(_h) || is_nan(_h) || is_infinity(_h)) return undefined;
    return clamp(floor(_h + 0.5), 24, 1024);
}

/// @function brk__sign_ok(profile)
/// @description Internal. Whether a value is a profile Bracket can draw (a struct from brk_profile).
function brk__sign_ok(_p) { return is_struct(_p) && is_string(_p[$ "key"]) && is_string(_p[$ "device"]) && is_string(_p[$ "board"]); }

/// @function brk__sign_key(profile, height, opts)
/// @description Internal. The cache key: EVERY field the picture depends on (name, trade, device, board, bracket, scheme,
/// weathering, tilt), the height, the swing and the colour behind. ⛔ Not the profile's own `key` (name + device): a
/// district that grows poorer keeps that key while its signs weather, and the cache would hand back the old picture.
function brk__sign_key(_p, _h, _o) {
    return string(_p.name) + "|" + string(_p[$ "trade"]) + "|" + _p.device + "|" + _p.board + "|" + string(_p[$ "bracket"]) + "|" + string(_p[$ "scheme"]) + "|" + string(_p[$ "weathering"]) + "|" + (is_numeric(_p[$ "tilt"]) ? string_format(_p.tilt, 1, 6) : "0") + "|" + string(_h) + "|" + string(_o.swing) + "|" + _o.behind;
}

// ---------------------------------------------------------------------------------------------------------------
// Baking
// ---------------------------------------------------------------------------------------------------------------

/// @function brk_sign_box(profile, height)
/// @description The size of a baked sign and where the sign itself sits inside it, from the sign's own geometry (never a
/// typed number): { w, h, x, y } - the sprite is w x h, and brk_draw_sign would be given (x, y) inside it. The width
/// carries the bracket's whole reach plus room for the board to swing. Returns undefined for something that is not a
/// profile or a height that is not a number.
/// @param {Struct} profile A profile from brk_profile
/// @param {Real} height The sign's full height in pixels (24..1024)
/// @returns {Struct|Undefined}
function brk_sign_box(_p, _height) {
    if (!brk__sign_ok(_p)) return undefined;
    var _h = brk__sign_height(_height);
    if (is_undefined(_h)) return undefined;
    var _g = brk_geometry(_p, _h);
    var _swingRoom = _g.boardW * 0.06;
    // ⛔ the box carries swing room on EVERY side. The MZ edition's bitmap is height * 1.06 tall with no side margin, which
    // is room enough at its Close Look size and NOT at a map sign's: at 150 px the board's shadowed rim (stroked 1.1 pens
    // below the outline) and a swung board's low corner fell off the bottom of the sprite (seen in the buyer render,
    // 2026-10-07), and at 96 px swung 8 degrees a corner left by the side (the suite's edge-ink check, same day). A board
    // swung by up to 10 degrees moves a corner by under a tenth of the sign's height sideways; the rim needs a few px more.
    var _side = ceil(_h * 0.10) + 2;
    return { w: ceil(_side * 2 + max(2, _g.ironH * 0.20) + _g.reach + _swingRoom + _g.plate.w), h: ceil(_h * 1.06 + _g.boardW * 0.10 + 8),
        x: floor(_h * 0.05 + 0.5) + _side, y: floor(_h * 0.02 + 0.5) + 2 };
}

/// @function brk_sign_sprite(profile, height, [options])
/// @description The sign as a sprite (origin top-left), baked now if it is not already cached. options: { swing (degrees
/// the board hangs off plumb, on top of the profile's own tilt), behind ("#rrggbb", the colour behind the sign - it shows
/// through a split corner and decides how the iron is lit) }. Returns -1 for something that is not a profile or a height
/// that is not a number. Call from a Draw event.
/// @param {Struct} profile A profile from brk_profile
/// @param {Real} height The sign's full height in pixels (24..1024)
/// @param {Struct} [options] { swing, behind }
/// @returns {Asset.GMSprite}
function brk_sign_sprite(_p, _height, _options = undefined) {
    if (!brk__sign_ok(_p)) return -1;
    var _h = brk__sign_height(_height);
    if (is_undefined(_h)) return -1;
    var _o = brk__sign_opts(_options);
    var _C = brk__sign_cache(), _key = brk__sign_key(_p, _h, _o);
    var _e = _C.map[$ _key];
    if (is_struct(_e) && sprite_exists(_e.sprite)) return _e.sprite;
    var _box = brk_sign_box(_p, _h);
    var _k = BRK_BAKE_SS;
    var _big = surface_create(_box.w * _k, _box.h * _k);
    var _m = matrix_get(matrix_world);
    surface_set_target(_big);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    matrix_set(matrix_world, matrix_build_identity());
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false); gpu_set_alphatestenable(false);
    var _c = brk_cx_create(_k);
    var _counts = brk_draw_sign(_c, _p, _box.x, _box.y, _h, { swing: _o.swing, behind: _o.behind });
    gpu_pop_state();
    surface_reset_target();
    // halve the 2x strike to the sprite's size: an exact 2 x 2 average under bilinear filtering
    var _half = surface_create(_box.w, _box.h);
    surface_set_target(_half);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    matrix_set(matrix_world, matrix_build_identity());
    gpu_set_blendmode_ext(bm_one, bm_zero);
    gpu_set_texfilter(true);
    draw_surface_ext(_big, 0, 0, 1 / _k, 1 / _k, 0, c_white, 1);
    gpu_pop_state();
    surface_reset_target();
    matrix_set(matrix_world, _m);
    var _spr = sprite_create_from_surface(_half, 0, 0, _box.w, _box.h, false, false, 0, 0);
    surface_free(_half);
    surface_free(_big);
    _counts.geometry = undefined;               // the cache keeps the counts, not the working geometry
    _C.map[$ _key] = { sprite: _spr, counts: _counts, box: _box };
    array_push(_C.keys, _key);
    return _spr;
}

/// @function brk_sign_ready(profile, height, [options])
/// @description Whether that sign is already baked (true) or would be baked by the next brk_sign_sprite call (false).
/// Never bakes.
/// @param {Struct} profile
/// @param {Real} height
/// @param {Struct} [options] { swing, behind }
/// @returns {Bool}
function brk_sign_ready(_p, _height, _options = undefined) {
    if (!brk__sign_ok(_p)) return false;
    var _h = brk__sign_height(_height);
    if (is_undefined(_h)) return false;
    var _e = brk__sign_cache().map[$ brk__sign_key(_p, _h, brk__sign_opts(_options))];
    return is_struct(_e) && sprite_exists(_e.sprite);
}

/// @function brk_prepare(profiles, height, [max_ms], [options])
/// @description Bake the signs of a list of profiles for up to max_ms milliseconds (default 4; at least ONE sign per call
/// while any is missing), so a room full of shops is ready without a stall. Returns true once every sign in the list is
/// baked. Call it every frame from a Draw event until it returns true - on a loading screen, or while the room fades in.
/// Entries that are not profiles are skipped (they can never be baked).
/// @param {Array<Struct>} profiles Profiles from brk_profile
/// @param {Real} height The sign height in pixels (24..1024)
/// @param {Real} [max_ms] The time budget for this call
/// @param {Struct} [options] { swing, behind } for every sign
/// @returns {Bool}
function brk_prepare(_profiles, _height, _max_ms = 4, _options = undefined) {
    if (!is_array(_profiles)) return true;
    if (is_undefined(brk__sign_height(_height))) return false;
    var _budget = ((is_numeric(_max_ms) && !is_nan(_max_ms) && _max_ms > 0) ? min(_max_ms, 1000) : 4) * 1000;
    var _t0 = get_timer(), _baked = 0, _missing = 0;
    for (var _i = 0; _i < array_length(_profiles); _i++) {
        var _p = _profiles[_i];
        if (!brk__sign_ok(_p) || brk_sign_ready(_p, _height, _options)) continue;
        if (_baked == 0 || get_timer() - _t0 < _budget) { brk_sign_sprite(_p, _height, _options); _baked++; }
        else _missing++;
    }
    return _missing == 0;
}

/// @function brk_draw_sign_sprite(profile, x, y, height, [options])
/// @description Draw a sign from its cached sprite (baked on first use), placed exactly where brk_draw_sign(ctx, profile,
/// x, y, height) would draw it live: (x, y) is the top-left of the sign's own box. Returns the sprite drawn, or -1.
/// Call from a Draw event.
/// @param {Struct} profile
/// @param {Real} x
/// @param {Real} y
/// @param {Real} height
/// @param {Struct} [options] { swing, behind }
/// @returns {Asset.GMSprite}
function brk_draw_sign_sprite(_p, _x, _y, _height, _options = undefined) {
    if (!is_numeric(_x) || !is_numeric(_y) || is_nan(_x) || is_nan(_y)) return -1;
    var _spr = brk_sign_sprite(_p, _height, _options);
    if (_spr == -1) return -1;
    var _box = brk_sign_box(_p, _height);
    draw_sprite(_spr, 0, _x - _box.x, _y - _box.y);
    return _spr;
}

/// @function brk_sign_cache_count()
/// @description How many baked signs are held.
/// @returns {Real}
function brk_sign_cache_count() {
    var _C = brk__sign_cache(), _n = 0;
    for (var _i = 0; _i < array_length(_C.keys); _i++) { var _e = _C.map[$ _C.keys[_i]]; if (is_struct(_e) && sprite_exists(_e.sprite)) _n++; }
    return _n;
}

/// @function brk_sign_cache_clear()
/// @description Free every baked sign (call it when you leave a town, or after changing what a shop sells if the old sign
/// should not be kept). Returns how many sprites were freed.
/// @returns {Real}
function brk_sign_cache_clear() {
    var _C = brk__sign_cache(), _n = 0;
    brk__flush_draws();
    for (var _i = 0; _i < array_length(_C.keys); _i++) {
        var _e = _C.map[$ _C.keys[_i]];
        if (is_struct(_e) && sprite_exists(_e.sprite)) { sprite_delete(_e.sprite); _n++; }
    }
    _C.map = {}; _C.keys = [];
    return _n;
}

/// @function brk__sign_counts(profile, height, [options])
/// @description Internal. What the bake of that sign drew (device primitives, glyphs, chain links, nails...), or undefined.
function brk__sign_counts(_p, _height, _options = undefined) {
    if (!brk__sign_ok(_p)) return undefined;
    var _h = brk__sign_height(_height);
    if (is_undefined(_h)) return undefined;
    var _e = brk__sign_cache().map[$ brk__sign_key(_p, _h, brk__sign_opts(_options))];
    return is_struct(_e) ? _e.counts : undefined;
}

// ---------------------------------------------------------------------------------------------------------------
// The name plaque and the shop lintel (the MZ edition's Close Look and shop-scene header, as drawing functions)
// ---------------------------------------------------------------------------------------------------------------

/// @function brk_draw_plaque(ctx, profile, x, y, w, h, [subtitle])
/// @description The oak name plate that goes under a sign: the shop's name in the display face, fitted to the plate, and
/// a second line (subtitle, default the profile's trade - e.g. "The Gilt Quarter - SMITH") in the body face. Inked by
/// contrast, never by assumption. Draws into a brk_canvas context; returns the glyphs struck (0 for a bad call).
/// @param {Struct} ctx A brk_canvas context (brk_cx_create)
/// @param {Struct} profile A profile from brk_profile
/// @param {Real} x
/// @param {Real} y
/// @param {Real} w The plate's width in pixels
/// @param {Real} h The plate's height in pixels
/// @param {String} [subtitle]
/// @returns {Real}
function brk_draw_plaque(_c, _p, _x, _y, _w, _h, _subtitle = undefined) {
    if (!is_struct(_c) || !brk__sign_ok(_p)) return 0;
    if (!is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_h) || is_nan(_x) || is_nan(_y) || !(_w >= 8) || !(_h >= 8) || is_infinity(_w) || is_infinity(_h)) return 0;
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _P = brk_palette();
    var _oak = brk_parse_hex(_P.oakShadow);
    brk_cx_save(_c);
    brk_cx_translate(_c, _x, _y);
    _c.fill = brk__ink(_oak);
    brk__p_fill_rect(_c, 0, 0, _w, _h);
    _c.stroke = brk__ink(brk_relief(_oak, 1, 34));
    _c.lw = 2;
    brk__p_begin(_c); brk__p_move(_c, 1, 1); brk__p_line(_c, _w - 1, 1); brk__p_line(_c, _w - 1, _h - 2); brk__p_line(_c, 1, _h - 2); brk__p_close(_c); brk__p_stroke(_c);
    _c.stroke = brk__ink(brk_relief(_oak, -1, 14));
    brk__p_begin(_c); brk__p_move(_c, 1, _h - 1); brk__p_line(_c, _w - 1, _h - 1); brk__p_stroke(_c);
    var _ink = brk_pick_contrast(_oak, [brk_parse_hex(_P.chalk), brk_parse_hex(_P.giltLit)], 4.5).ink;
    _c.fill = brk__ink(_ink);
    var _line1 = string(_p.name);
    var _line2 = is_string(_subtitle) ? _subtitle : string(_p[$ "trade"] ?? "");
    var _f1 = brk_fit_line(_line1, floor(_h * 0.40 + 0.5), BRK_FACE_DISPLAY, _w * 0.88, 0.05);
    var _n = brk__strike_tracked(_c, _line1, _w / 2, floor(_h * 0.48 + 0.5), { size: _f1.size, tracking: 0 }, BRK_FACE_DISPLAY);
    if (_line2 != "") {
        _c.alpha = 0.78;
        var _f2 = brk_fit_line(_line2, floor(_h * 0.20 + 0.5), BRK_FACE_BODY, _w * 0.88, 0.12);
        _n += brk__strike_tracked(_c, _line2, _w / 2, floor(_h * 0.78 + 0.5), { size: _f2.size, tracking: 0 }, BRK_FACE_BODY);
        _c.alpha = 1;
    }
    brk_cx_restore(_c);
    math_set_epsilon(_eps);
    return _n;
}

/// @function brk_draw_lintel(ctx, w, band)
/// @description The band that heads a shop screen: plaster above, an oak beam with its own grain (pitch declared, count
/// derived and centred), a lit top arris and a shadowed soffit - every pixel drawn, so a crop of it is all product. Draws
/// into a brk_canvas context from (0, 0); returns how many grain lines were struck (0 for a bad call).
/// @param {Struct} ctx A brk_canvas context
/// @param {Real} w The band's width in pixels
/// @param {Real} band The band's height in pixels
/// @returns {Real}
function brk_draw_lintel(_c, _w, _band) {
    if (!is_struct(_c) || !is_numeric(_w) || !is_numeric(_band) || is_nan(_w) || is_nan(_band) || !(_w >= 8) || !(_band >= 8) || is_infinity(_w) || is_infinity(_band)) return 0;
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _P = brk_palette();
    var _beamH = max(6, floor(_band * 0.13 + 0.5));
    var _beamY = _band - _beamH;
    var _wall = brk_cx_linear(_c, 0, 0, _w * 0.75, _band);
    brk_cx_stop(_wall, 0, [43, 52, 68], 1);
    brk_cx_stop(_wall, 1, [26, 33, 44], 1);
    _c.fill = _wall;
    brk__p_fill_rect(_c, 0, 0, _w, _beamY);
    _c.fill = brk__ink_hex(_P.oakShadow);
    brk__p_fill_rect(_c, 0, _beamY, _w, _beamH);
    var _ink = max(1, _beamH * 0.14);
    var _run = brk_fit_repeat(_w, _ink, _ink * 5.2);
    var _runLen = (_run.count - 1) * _run.pitch + _ink;
    var _start = (_w - _runLen) / 2;
    var _struck = 0;
    _c.fill = brk_cx_solid([24, 14, 7], 0.42);
    for (var _i = 0; _i < _run.count; _i++) { brk__p_fill_rect(_c, _start + _i * _run.pitch, _beamY + _beamH * 0.28, _ink, _beamH * 0.5); _struck++; }
    _c.fill = brk_cx_solid([196, 148, 92], 0.55);
    brk__p_fill_rect(_c, 0, _beamY, _w, max(1, _beamH * 0.16));
    _c.fill = brk_cx_solid([0, 0, 0], 0.42);
    brk__p_fill_rect(_c, 0, _band - max(1, _beamH * 0.2), _w, max(1, _beamH * 0.2));
    math_set_epsilon(_eps);
    return _struck;
}
