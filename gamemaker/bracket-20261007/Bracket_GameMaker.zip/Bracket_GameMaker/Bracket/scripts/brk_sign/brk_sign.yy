{
  "$GMScript": "v1",
  "%Name": "brk_sign",
  "name": "brk_sign",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}