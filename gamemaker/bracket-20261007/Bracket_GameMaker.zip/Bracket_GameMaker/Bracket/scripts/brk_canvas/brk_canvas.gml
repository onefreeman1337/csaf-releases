/// brk_canvas.gml - a small 2D path renderer on GameMaker primitives: paths under an affine transform, a NONZERO or EVEN-ODD
/// scanline fill whose span ends carry their fractional coverage as alpha, linear and radial gradients, strokes built as the
/// UNION of their segments (so a translucent line never darkens where its pieces overlap), clip regions, and type struck
/// glyph by glyph under the transform. Every Bracket sign - the oak, the paint, the trade mark, the lettering, the iron - and
/// the demo's street and yard are drawn through it.
///
/// Bracket - Shop Signs Composed from What the Shop Sells, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ FOUR FACTS ABOUT GAMEMAKER DECIDE THE SHAPE OF THIS FILE:
///   1. Its primitives have NO antialiasing. Every fill here is a scanline fill whose span ends carry their coverage,
///      and a picture is drawn SUPERSAMPLED (the context's base transform scales by 2) then filtered down.
///   2. draw_vertex_colour carries its own alpha and IGNORES draw_set_alpha, so alpha is always passed explicitly.
///   3. One draw_primitive_begin batch SILENTLY DROPS vertices past a limit (~1000): every batch flushes at 900.
///   4. A triangle fan spans a concavity silently, so no concave path is ever fanned; the scanline fill takes any shape.
/// A context holds DEVICE coordinates: every point is transformed as it is added, as a canvas does.
/// A clip that is not an axis-aligned rectangle is a LAYER (a transparent surface the size of the target; the matching
/// restore erases everything outside the path, EVEN-ODD over the path's rings - which is the canvas clip("evenodd") and,
/// for one ring or rings that do not overlap, the nonzero clip too). A layer clip needs a SURFACE target (every Bracket
/// picture is a bake).

#macro BRK_FILL_NONZERO 1
#macro BRK_FILL_EVENODD 0
#macro BRK_MESH_CELL 12

/// @function brk_cx_create(scale)
/// @description A drawing context whose base transform scales by `scale` (the supersample factor). Draws onto
/// whatever surface is the current target. Returns a struct; nothing to free.
function brk_cx_create(_ss = 1) {
    _ss = is_numeric(_ss) ? max(0.01, _ss) : 1;
    return {
        m: [_ss, 0, 0, _ss, 0, 0], alpha: 1, lw: 1, cap: 0, dash: [],
        fill: brk_cx_solid([0, 0, 0]), stroke: brk_cx_solid([0, 0, 0]),
        stack: [], subs: [], cur: undefined, clips: [],
        counts: { path: 0, fill: 0, stroke: 0, rect: 0 }, ss: _ss, verts: 0, op: 0, join: 0
    };
}

/// @function brk_cx_solid(rgb, [a])
/// @description A flat paint from an [r, g, b] colour. Pure.
function brk_cx_solid(_rgb, _a = 1) { return { kind: 0, col: brk_col(_rgb), a: _a }; }

/// @function brk_cx_linear(ctx, x0, y0, x1, y1)
/// @description A linear gradient between two USER-space points under the current transform. Add stops with
/// brk_cx_stop. Pure but for reading ctx.
function brk_cx_linear(_ctx, _x0, _y0, _x1, _y1) {
    var _p = brk_cx__pt(_ctx, _x0, _y0), _q = brk_cx__pt(_ctx, _x1, _y1);
    return { kind: 1, x0: _p[0], y0: _p[1], x1: _q[0], y1: _q[1], stops: [] };
}

/// @function brk_cx_radial(ctx, x0, y0, r0, x1, y1, r1)
/// @description A two-circle radial gradient (the canvas definition) in USER space under the current transform.
function brk_cx_radial(_ctx, _x0, _y0, _r0, _x1, _y1, _r1) {
    var _p = brk_cx__pt(_ctx, _x0, _y0), _q = brk_cx__pt(_ctx, _x1, _y1), _s = brk_cx__scale(_ctx);
    return { kind: 2, x0: _p[0], y0: _p[1], r0: _r0 * _s, x1: _q[0], y1: _q[1], r1: _r1 * _s, stops: [] };
}

/// @function brk_cx_stop(grad, t, rgb, [a])
/// @description Add a colour stop to a gradient. Stops must be added in increasing t (every caller here does).
function brk_cx_stop(_g, _t, _rgb, _a = 1) { array_push(_g.stops, [clamp(_t, 0, 1), brk_col(_rgb), _a]); }

// ---------------------------------------------------------------------------------------------------------------
// State and transform
// ---------------------------------------------------------------------------------------------------------------

/// @function brk_cx_save(ctx)
function brk_cx_save(_c) {
    array_push(_c.stack, { m: [_c.m[0], _c.m[1], _c.m[2], _c.m[3], _c.m[4], _c.m[5]], alpha: _c.alpha, lw: _c.lw, cap: _c.cap,
        dash: _c.dash, fill: _c.fill, stroke: _c.stroke, clips: array_length(_c.clips), op: _c.op, join: _c.join });
}

/// @function brk_cx_restore(ctx)
/// @description Pop the state saved by brk_cx_save. A LAYER clip being popped is finished here: everything outside its
/// ring is erased and the layer is composited onto the surface it was opened over (innermost first).
function brk_cx_restore(_c) {
    var _n = array_length(_c.stack);
    if (_n == 0) return;
    var _s = _c.stack[_n - 1];
    array_delete(_c.stack, _n - 1, 1);
    _c.m = _s.m; _c.alpha = _s.alpha; _c.lw = _s.lw; _c.cap = _s.cap; _c.dash = _s.dash; _c.fill = _s.fill; _c.stroke = _s.stroke; _c.op = _s.op; _c.join = _s.join;
    for (var _k = array_length(_c.clips) - 1; _k >= _s.clips; _k--) {
        if (variable_struct_exists(_c.clips[_k], "layer")) brk_cx__layer_end(_c, _c.clips[_k]);
    }
    if (array_length(_c.clips) > _s.clips) array_resize(_c.clips, _s.clips);
}

/// @function brk_cx_set_dash(ctx, pattern)
/// @description The canvas setLineDash: an array of on/off lengths in user units ([] for a solid line). Saved and
/// restored with the state, as a canvas does.
function brk_cx_set_dash(_c, _pattern) {
    var _p = [];
    if (is_array(_pattern)) for (var _i = 0; _i < array_length(_pattern); _i++) if (is_numeric(_pattern[_i]) && _pattern[_i] >= 0) array_push(_p, _pattern[_i]);
    var _sum = 0;
    for (var _j = 0; _j < array_length(_p); _j++) _sum += _p[_j];
    if (!(_sum > 0)) _p = [];
    else if (array_length(_p) mod 2 == 1) { var _n = array_length(_p); for (var _q = 0; _q < _n; _q++) array_push(_p, _p[_q]); }
    _c.dash = _p;
}

/// @function brk_cx__dashed(ctx, subs)
/// @description The subpaths cut into their dash pieces (open polylines), the pattern restarting on every subpath and
/// measured in device space under the current transform, as a canvas measures it. Internal.
function brk_cx__dashed(_c, _subs) {
    var _k = brk_cx__scale(_c), _pat = _c.dash, _np = array_length(_pat), _out = [];
    for (var _s = 0; _s < array_length(_subs); _s++) {
        var _src = _subs[_s].pts, _n = array_length(_src);
        if (_n < 2) continue;
        var _pts = [];
        for (var _i = 0; _i < _n; _i++) array_push(_pts, _src[_i]);
        if (_subs[_s].closed) array_push(_pts, _src[0]);
        var _di = 0, _left = _pat[0] * _k, _on = true, _piece = [_pts[0]];
        for (var _j = 0; _j + 1 < array_length(_pts); _j++) {
            var _ax = _pts[_j][0], _ay = _pts[_j][1], _bx = _pts[_j + 1][0], _by = _pts[_j + 1][1];
            var _len = point_distance(_ax, _ay, _bx, _by), _at = 0;
            while (_len - _at > _left) {
                _at += _left;
                var _t = _at / _len, _px = _ax + (_bx - _ax) * _t, _py = _ay + (_by - _ay) * _t;
                if (_on) { array_push(_piece, [_px, _py]); if (array_length(_piece) >= 2) array_push(_out, { pts: _piece, closed: false }); }
                _on = !_on; _di = (_di + 1) mod _np; _left = max(0.0001, _pat[_di] * _k);
                _piece = [[_px, _py]];
            }
            _left -= (_len - _at);
            if (_on) array_push(_piece, [_bx, _by]);
        }
        if (_on && array_length(_piece) >= 2) array_push(_out, { pts: _piece, closed: false });
    }
    return _out;
}

// ⛔ A transform is REPLACED, never written through an alias: a buyer's project may still run GameMaker's legacy
// array copy-on-write option, under which `var m = ctx.m; m[4] += x;` edits a private copy and the context never moves.

/// @function brk_cx_translate(ctx, x, y)
function brk_cx_translate(_c, _x, _y) {
    var _m = _c.m;
    _c.m = [_m[0], _m[1], _m[2], _m[3], _m[4] + _m[0] * _x + _m[2] * _y, _m[5] + _m[1] * _x + _m[3] * _y];
}

/// @function brk_cx_rotate(ctx, radians)
function brk_cx_rotate(_c, _r) {
    var _m = _c.m, _co = cos(_r), _si = sin(_r);
    _c.m = [_m[0] * _co + _m[2] * _si, _m[1] * _co + _m[3] * _si, -_m[0] * _si + _m[2] * _co, -_m[1] * _si + _m[3] * _co, _m[4], _m[5]];
}

/// @function brk_cx_scale(ctx, sx, sy)
function brk_cx_scale(_c, _sx, _sy) {
    var _m = _c.m;
    _c.m = [_m[0] * _sx, _m[1] * _sx, _m[2] * _sy, _m[3] * _sy, _m[4], _m[5]];
}

/// @function brk_cx_transform(ctx, a, b, c, d, e, f)
/// @description Multiply the current transform by [a, b, c, d, e, f] (the canvas transform(): x' = a x + c y + e,
/// y' = b x + d y + f, applied before the current transform).
function brk_cx_transform(_c, _a, _b, _cc, _d, _e, _f) {
    var _m = _c.m;
    _c.m = [_m[0] * _a + _m[2] * _b, _m[1] * _a + _m[3] * _b, _m[0] * _cc + _m[2] * _d, _m[1] * _cc + _m[3] * _d,
        _m[0] * _e + _m[2] * _f + _m[4], _m[1] * _e + _m[3] * _f + _m[5]];
}

/// @function brk_cx__pt(ctx, x, y)
/// @description A user-space point in device space. Internal.
function brk_cx__pt(_c, _x, _y) {
    var _m = _c.m;
    return [_m[0] * _x + _m[2] * _y + _m[4], _m[1] * _x + _m[3] * _y + _m[5]];
}

/// @function brk_cx__scale(ctx)
/// @description The linear scale of the current transform (what a line width is multiplied by). Internal.
function brk_cx__scale(_c) { var _m = _c.m; return sqrt(abs(_m[0] * _m[3] - _m[1] * _m[2])); }

// ---------------------------------------------------------------------------------------------------------------
// Paths
// ---------------------------------------------------------------------------------------------------------------

/// @function brk_cx_begin(ctx)
/// @description Start a new path (counted: the draw report compares op counts with the original).
function brk_cx_begin(_c) { _c.subs = []; _c.cur = undefined; _c.counts.path++; }

/// @function brk_cx_move(ctx, x, y)
function brk_cx_move(_c, _x, _y) {
    _c.cur = { pts: [brk_cx__pt(_c, _x, _y)], closed: false };
    array_push(_c.subs, _c.cur);
}

/// @function brk_cx_line(ctx, x, y)
function brk_cx_line(_c, _x, _y) {
    if (is_undefined(_c.cur)) { brk_cx_move(_c, _x, _y); return; }
    array_push(_c.cur.pts, brk_cx__pt(_c, _x, _y));
}

/// @function brk_cx__last(ctx)
/// @description The current device point. Internal.
function brk_cx__last(_c) { var _p = _c.cur.pts; return _p[array_length(_p) - 1]; }

/// @function brk_cx_quad(ctx, cx, cy, x, y)
/// @description A quadratic curve, flattened in device space at about 3 px a segment.
function brk_cx_quad(_c, _cx, _cy, _x, _y) {
    if (is_undefined(_c.cur)) brk_cx_move(_c, _cx, _cy);
    var _p0 = brk_cx__last(_c), _p1 = brk_cx__pt(_c, _cx, _cy), _p2 = brk_cx__pt(_c, _x, _y);
    var _len = point_distance(_p0[0], _p0[1], _p1[0], _p1[1]) + point_distance(_p1[0], _p1[1], _p2[0], _p2[1]);
    var _n = clamp(ceil(_len / 3), 2, 64);
    for (var _i = 1; _i <= _n; _i++) {
        var _t = _i / _n, _u = 1 - _t;
        array_push(_c.cur.pts, [_u * _u * _p0[0] + 2 * _u * _t * _p1[0] + _t * _t * _p2[0], _u * _u * _p0[1] + 2 * _u * _t * _p1[1] + _t * _t * _p2[1]]);
    }
}

/// @function brk_cx_bezier(ctx, c1x, c1y, c2x, c2y, x, y)
/// @description A cubic curve, flattened in device space at about 3 px a segment.
function brk_cx_bezier(_c, _ax, _ay, _bx, _by, _x, _y) {
    if (is_undefined(_c.cur)) brk_cx_move(_c, _ax, _ay);
    var _p0 = brk_cx__last(_c), _p1 = brk_cx__pt(_c, _ax, _ay), _p2 = brk_cx__pt(_c, _bx, _by), _p3 = brk_cx__pt(_c, _x, _y);
    var _len = point_distance(_p0[0], _p0[1], _p1[0], _p1[1]) + point_distance(_p1[0], _p1[1], _p2[0], _p2[1]) + point_distance(_p2[0], _p2[1], _p3[0], _p3[1]);
    var _n = clamp(ceil(_len / 3), 2, 96);
    for (var _i = 1; _i <= _n; _i++) {
        var _t = _i / _n, _u = 1 - _t;
        var _a = _u * _u * _u, _b = 3 * _u * _u * _t, _cc = 3 * _u * _t * _t, _d = _t * _t * _t;
        array_push(_c.cur.pts, [_a * _p0[0] + _b * _p1[0] + _cc * _p2[0] + _d * _p3[0], _a * _p0[1] + _b * _p1[1] + _cc * _p2[1] + _d * _p3[1]]);
    }
}

/// @function brk_cx__sweep(a0, a1, ccw)
/// @description The swept angle of a canvas arc from a0 to a1 (the canvas rule: a full turn or more draws a full
/// circle; otherwise the end is brought within one turn of the start in the arc's direction). Internal.
function brk_cx__sweep(_a0, _a1, _ccw) {
    var _tau = 2 * pi;
    if (!_ccw) {
        if (_a1 - _a0 >= _tau) return _tau;
        var _s = (_a1 - _a0) - floor((_a1 - _a0) / _tau) * _tau;
        return _s;
    }
    if (_a0 - _a1 >= _tau) return -_tau;
    var _r = (_a0 - _a1) - floor((_a0 - _a1) / _tau) * _tau;
    return -_r;
}

/// @function brk_cx_ellipse(ctx, cx, cy, rx, ry, rot, a0, a1, [ccw])
/// @description An elliptical arc (a circle when rx == ry). Joins the current point to its start with a line, as a
/// canvas does. A negative radius is drawn as zero rather than thrown.
function brk_cx_ellipse(_c, _cx, _cy, _rx, _ry, _rot, _a0, _a1, _ccw = false) {
    _rx = max(0, _rx); _ry = max(0, _ry);
    var _sw = brk_cx__sweep(_a0, _a1, _ccw);
    var _cr = cos(_rot), _sr = sin(_rot), _s = brk_cx__scale(_c);
    var _n = clamp(ceil(max(_rx, _ry) * _s * abs(_sw) / 3), 2, 128);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _a0 + _sw * _i / _n;
        var _ex = cos(_t) * _rx, _ey = sin(_t) * _ry;
        var _ux = _cx + _ex * _cr - _ey * _sr, _uy = _cy + _ex * _sr + _ey * _cr;
        if (_i == 0 && is_undefined(_c.cur)) brk_cx_move(_c, _ux, _uy); else brk_cx_line(_c, _ux, _uy);
    }
}

/// @function brk_cx_arc(ctx, cx, cy, r, a0, a1, [ccw])
function brk_cx_arc(_c, _cx, _cy, _r, _a0, _a1, _ccw = false) { brk_cx_ellipse(_c, _cx, _cy, _r, _r, 0, _a0, _a1, _ccw); }

/// @function brk_cx_arc_to(ctx, x1, y1, x2, y2, r)
/// @description The canvas arcTo: a line from the current point toward (x1, y1), then the arc of radius r tangent to
/// that line and to the line on to (x2, y2); the current point ends where the arc meets the second line. A canvas's
/// degenerate cases draw a line to (x1, y1): no room (r <= 0), a point equal to the corner, or the three in a line.
/// With no current point it starts one at (x1, y1). USER space (the transforms here keep a circle a circle).
function brk_cx_arc_to(_c, _x1, _y1, _x2, _y2, _r) {
    if (is_undefined(_c.cur)) { brk_cx_move(_c, _x1, _y1); return; }
    var _m = _c.m, _det = _m[0] * _m[3] - _m[1] * _m[2], _P = brk_cx__last(_c);
    if (abs(_det) < 0.000000001) { brk_cx_line(_c, _x1, _y1); return; }
    // the current point, back in user space
    var _px = _P[0] - _m[4], _py = _P[1] - _m[5];
    var _x0 = (_m[3] * _px - _m[2] * _py) / _det, _y0 = (-_m[1] * _px + _m[0] * _py) / _det;
    var _ax = _x0 - _x1, _ay = _y0 - _y1, _bx = _x2 - _x1, _by = _y2 - _y1;
    var _la = sqrt(_ax * _ax + _ay * _ay), _lb = sqrt(_bx * _bx + _by * _by);
    if (!(_r > 0) || _la < 0.000001 || _lb < 0.000001) { brk_cx_line(_c, _x1, _y1); return; }
    _ax /= _la; _ay /= _la; _bx /= _lb; _by /= _lb;
    if (abs(_ax * _by - _ay * _bx) < 0.000001) { brk_cx_line(_c, _x1, _y1); return; }
    var _half = arccos(clamp(_ax * _bx + _ay * _by, -1, 1)) / 2;
    var _d = _r / tan(_half), _hyp = _r / sin(_half);
    var _sx = _ax + _bx, _sy = _ay + _by, _sl = sqrt(_sx * _sx + _sy * _sy);
    var _ccx = _x1 + _sx / _sl * _hyp, _ccy = _y1 + _sy / _sl * _hyp;
    var _a0 = arctan2(_y1 + _ay * _d - _ccy, _x1 + _ax * _d - _ccx), _a1 = arctan2(_y1 + _by * _d - _ccy, _x1 + _bx * _d - _ccx);
    var _sw = _a1 - _a0;
    while (_sw > pi) _sw -= 2 * pi;
    while (_sw < -pi) _sw += 2 * pi;
    // the arc's first point is the first tangent point, so the line to it is the arc's own joining line
    brk_cx_arc(_c, _ccx, _ccy, _r, _a0, _a0 + _sw, _sw < 0);
}

/// @function brk_cx_rect(ctx, x, y, w, h)
/// @description A closed rectangle subpath.
function brk_cx_rect(_c, _x, _y, _w, _h) {
    brk_cx_move(_c, _x, _y); brk_cx_line(_c, _x + _w, _y); brk_cx_line(_c, _x + _w, _y + _h); brk_cx_line(_c, _x, _y + _h);
    brk_cx_close(_c);
}

/// @function brk_cx_close(ctx)
function brk_cx_close(_c) {
    if (is_undefined(_c.cur)) return;
    _c.cur.closed = true;
    var _p0 = _c.cur.pts[0];
    _c.cur = { pts: [[_p0[0], _p0[1]]], closed: false };
    array_push(_c.subs, _c.cur);
}

/// @function brk_cx_round_rect(ctx, x, y, w, h, r)
/// @description A rounded-rectangle subpath; a negative or oversize radius is clamped rather than thrown.
function brk_cx_round_rect(_c, _x, _y, _w, _h, _r) {
    var _rr = max(0, min(_r, _w / 2, _h / 2));
    brk_cx_move(_c, _x + _rr, _y);
    brk_cx_line(_c, _x + _w - _rr, _y);
    brk_cx_arc(_c, _x + _w - _rr, _y + _rr, _rr, -pi / 2, 0);
    brk_cx_line(_c, _x + _w, _y + _h - _rr);
    brk_cx_arc(_c, _x + _w - _rr, _y + _h - _rr, _rr, 0, pi / 2);
    brk_cx_line(_c, _x + _rr, _y + _h);
    brk_cx_arc(_c, _x + _rr, _y + _h - _rr, _rr, pi / 2, pi);
    brk_cx_line(_c, _x, _y + _rr);
    brk_cx_arc(_c, _x + _rr, _y + _rr, _rr, pi, pi * 1.5);
    brk_cx_close(_c);
}

/// @function brk_cx__rings(ctx)
/// @description The current path's subpaths with at least three points, as device rings. Internal.
function brk_cx__rings(_c) {
    var _o = [];
    for (var _i = 0; _i < array_length(_c.subs); _i++) if (array_length(_c.subs[_i].pts) >= 3) array_push(_o, _c.subs[_i].pts);
    return _o;
}

// ---------------------------------------------------------------------------------------------------------------
// Painting
// ---------------------------------------------------------------------------------------------------------------

// ⛔ SPEED IS A PRODUCT PROPERTY HERE: a mark is baked the first time it is drawn, inside the buyer's frame. MEASURED on
// the first build (2026-09-28): every mark through the scanline union cost 336 ms an 816 x 240 picture at 1x and 0.7-2.7 s a bake at
// 2x - a long wavy stroke is hundreds of quads, all active on every row. So the common shapes take direct paths:
// a CONVEX fill is a fan, a RADIAL fill a mesh, an axis-aligned rectangle one quad (or one band per stop of an axis
// gradient), a SOLID stroke one miter-joined triangle strip - clipped by the GPU scissor when every clip is a
// rectangle. The exact scanline union remains for everything else (concave shapes, a shaped clip, a diagonal
// gradient). The draw report counts the same ops either way.

/// @function brk_cx_fill(ctx)
/// @description Fill the current path with the fill paint (nonzero winding) at the context's alpha.
function brk_cx_fill(_c) {
    _c.counts.fill++;
    // destination-out: the exact scanline fill (coverage-alpha edges) under dest *= 1 - src alpha
    if (_c.op == 1) { gpu_push_state(); gpu_set_blendmode_ext(bm_zero, bm_inv_src_alpha); brk_cx__fill(_c, brk_cx__rings(_c), _c.fill, _c.alpha, BRK_FILL_NONZERO); gpu_pop_state(); return; }
    var _r = brk_cx__rings(_c);
    if (array_length(_r) == 1 && _c.fill.kind != 1 && brk_cx__rect_clips(_c) && brk_cx__convex(_r[0])) { brk_cx__fan(_c, _r[0], _c.fill, _c.alpha); return; }
    if (array_length(_r) == 1 && _c.fill.kind == 1 && brk_cx__rect_clips(_c) && brk_cx__fill_layered(_c, _r[0], _c.fill, _c.alpha)) return;
    brk_cx__fill(_c, _r, _c.fill, _c.alpha, BRK_FILL_NONZERO);
}

/// @function brk_cx_fill_rule(ctx, rule)
/// @description Fill the current path with the fill paint under a fill rule: BRK_FILL_EVENODD (the canvas
/// fill("evenodd") - a ring with a hole, a frame's shadow falls only inside it) or BRK_FILL_NONZERO.
function brk_cx_fill_rule(_c, _rule) {
    if (_rule != BRK_FILL_EVENODD) { brk_cx_fill(_c); return; }
    _c.counts.fill++;
    brk_cx__fill(_c, brk_cx__rings(_c), _c.fill, _c.alpha, BRK_FILL_EVENODD);
}

/// @function brk_cx_shadow(ctx, rgb, alpha, blur, dx, dy, [rule])
/// @description The canvas shadow of the CURRENT PATH, drawn now: its silhouette offset by (dx, dy) and blurred by
/// `blur` (the canvas shadowBlur: a gaussian of sigma blur / 2), in the shadow colour at `alpha` x the context alpha.
/// Like a canvas, the offsets and blur are in canvas pixels - scaled by the context's base (supersample) scale and NOT by
/// the current transform. Call it, then fill: a canvas draws a shape's shadow under the shape. Not counted (it is a
/// property of the fill that follows). Cut to rectangular clips by the scissor and to a layer clip by its erase. The
/// silhouette is filled at a scale where sigma is about two texels, blurred there by a separable gaussian (each tap one
/// offset copy, summed additively, premultiplied) and magnified with filtering. Needs a surface target (a bake).
function brk_cx_shadow(_c, _rgb, _alpha, _blur, _dx, _dy, _rule = BRK_FILL_NONZERO) {
    var _rings = brk_cx__rings(_c);
    var _al = _alpha * _c.alpha;
    if (array_length(_rings) == 0 || !(_al > 0)) return;
    var _tgt = surface_get_target();
    if (_tgt == -1 || !surface_exists(_tgt)) return;
    var _k = _c.ss, _ox = _dx * _k, _oy = _dy * _k, _sig = max(0, _blur) * 0.5 * _k;
    var _x0 = 1000000, _y0 = 1000000, _x1 = -1000000, _y1 = -1000000;
    for (var _r = 0; _r < array_length(_rings); _r++) {
        var _ring = _rings[_r];
        for (var _i = 0; _i < array_length(_ring); _i++) { _x0 = min(_x0, _ring[_i][0]); _x1 = max(_x1, _ring[_i][0]); _y0 = min(_y0, _ring[_i][1]); _y1 = max(_y1, _ring[_i][1]); }
    }
    var _pad = ceil(_sig * 3) + 2, _tw = surface_get_width(_tgt), _th = surface_get_height(_tgt);
    _x0 = max(floor(_x0 + _ox) - _pad, -_pad); _y0 = max(floor(_y0 + _oy) - _pad, -_pad);
    _x1 = min(ceil(_x1 + _ox) + _pad, _tw + _pad); _y1 = min(ceil(_y1 + _oy) + _pad, _th + _pad);
    if (_x1 <= _x0 || _y1 <= _y0) return;
    var _q = max(1, _sig / 2), _st = _sig / _q;
    var _sw = max(1, ceil((_x1 - _x0) / _q)), _sh = max(1, ceil((_y1 - _y0) / _q));
    var _sa = surface_create(_sw, _sh), _sb = surface_create(_sw, _sh);
    // the silhouette, white and premultiplied, at 1/q
    var _lr = [];
    for (var _r2 = 0; _r2 < array_length(_rings); _r2++) {
        var _src = _rings[_r2], _dst = array_create(array_length(_src));
        for (var _j = 0; _j < array_length(_src); _j++) _dst[_j] = [(_src[_j][0] + _ox - _x0) / _q, (_src[_j][1] + _oy - _y0) / _q];
        array_push(_lr, _dst);
    }
    surface_set_target(_sa);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    brk_cx__fill(brk_cx_create(1), _lr, brk_cx_solid([255, 255, 255]), 1, _rule);
    gpu_pop_state();
    surface_reset_target();
    // the gaussian, horizontally (a -> b) then vertically (b -> a)
    var _rad = ceil(_st * 3);
    if (_rad > 0) {
        var _w = array_create(_rad * 2 + 1), _sum = 0;
        for (var _t = -_rad; _t <= _rad; _t++) { _w[_t + _rad] = exp(-(_t * _t) / (2 * _st * _st)); _sum += _w[_t + _rad]; }
        for (var _u = 0; _u < array_length(_w); _u++) _w[_u] /= _sum;
        for (var _pass = 0; _pass < 2; _pass++) {
            var _from = (_pass == 0) ? _sa : _sb, _into = (_pass == 0) ? _sb : _sa;
            surface_set_target(_into);
            draw_clear_alpha(c_black, 0);
            gpu_push_state();
            gpu_set_blendmode_ext(bm_one, bm_one); gpu_set_texfilter(false);
            for (var _v = 0; _v < array_length(_w); _v++) {
                var _o = _v - _rad;
                draw_surface_ext(_from, (_pass == 0) ? _o : 0, (_pass == 0) ? 0 : _o, 1, 1, 0, merge_colour(c_black, c_white, _w[_v]), _w[_v]);
            }
            gpu_pop_state();
            surface_reset_target();
        }
    }
    // composite, premultiplied, in the shadow colour
    var _prev = brk_cx__scissor_on(_c);
    gpu_push_state();
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); gpu_set_texfilter(true);
    draw_surface_ext(_sa, _x0, _y0, _q, _q, 0, merge_colour(c_black, brk_col(_rgb), _al), _al);
    gpu_pop_state();
    brk_cx__scissor_off(_prev);
    surface_free(_sa); surface_free(_sb);
}

/// @function brk_cx_clear_rect(ctx, x, y, w, h)
/// @description The canvas clearRect: make a rectangle transparent (inside the rectangular clips). Not counted.
function brk_cx_clear_rect(_c, _x, _y, _w, _h) {
    if (!(_w > 0) || !(_h > 0)) return;
    var _p = brk_cx__pt(_c, _x, _y), _q = brk_cx__pt(_c, _x + _w, _y + _h);
    var _prev = brk_cx__scissor_on(_c);
    gpu_push_state();
    gpu_set_blendmode_ext(bm_zero, bm_zero);
    draw_primitive_begin(pr_trianglelist);
    draw_vertex_colour(_p[0], _p[1], c_black, 1); draw_vertex_colour(_q[0], _p[1], c_black, 1); draw_vertex_colour(_p[0], _q[1], c_black, 1);
    draw_vertex_colour(_q[0], _p[1], c_black, 1); draw_vertex_colour(_q[0], _q[1], c_black, 1); draw_vertex_colour(_p[0], _q[1], c_black, 1);
    draw_primitive_end();
    gpu_pop_state();
    brk_cx__scissor_off(_prev);
}

/// @function brk_cx_fill_rects(ctx, list)
/// @description Many small flat rectangles in ONE batch, each counted as a fillRect: list entries [x, y, w, h, colour
/// (a GameMaker colour), alpha], user space under the current transform (any affine transform). A leather grain or a
/// paper tooth is thousands of these; one batch each cost ~10x less on the VM than one draw call a mark. Under a
/// layer clip or rectangular clips; anything else falls back to one exact fill a rectangle.
function brk_cx_fill_rects(_c, _list) {
    var _n = array_length(_list);
    _c.counts.rect += _n;
    if (_n == 0) return;
    var _m = _c.m, _ca = _c.alpha;
    if (!brk_cx__rect_clips(_c)) {
        for (var _i = 0; _i < _n; _i++) {
            var _e = _list[_i];
            if (!(_e[2] > 0) || !(_e[3] > 0)) continue;
            brk_cx__fill(_c, [[brk_cx__pt(_c, _e[0], _e[1]), brk_cx__pt(_c, _e[0] + _e[2], _e[1]), brk_cx__pt(_c, _e[0] + _e[2], _e[1] + _e[3]), brk_cx__pt(_c, _e[0], _e[1] + _e[3])]], { kind: 0, col: _e[4], a: 1 }, _ca * _e[5], BRK_FILL_NONZERO);
        }
        return;
    }
    var _prev = brk_cx__scissor_on(_c);
    draw_primitive_begin(pr_trianglelist);
    var _v = 0;
    for (var _j = 0; _j < _n; _j++) {
        var _q = _list[_j];
        if (!(_q[2] > 0) || !(_q[3] > 0)) continue;
        if (_v >= 900) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); _v = 0; }
        var _x0 = _q[0], _y0 = _q[1], _x1 = _q[0] + _q[2], _y1 = _q[1] + _q[3], _col = _q[4], _a = _ca * _q[5];
        var _ax = _m[0] * _x0 + _m[2] * _y0 + _m[4], _ay = _m[1] * _x0 + _m[3] * _y0 + _m[5];
        var _bx = _m[0] * _x1 + _m[2] * _y0 + _m[4], _by = _m[1] * _x1 + _m[3] * _y0 + _m[5];
        var _cx = _m[0] * _x1 + _m[2] * _y1 + _m[4], _cy = _m[1] * _x1 + _m[3] * _y1 + _m[5];
        var _dx = _m[0] * _x0 + _m[2] * _y1 + _m[4], _dy = _m[1] * _x0 + _m[3] * _y1 + _m[5];
        draw_vertex_colour(_ax, _ay, _col, _a); draw_vertex_colour(_bx, _by, _col, _a); draw_vertex_colour(_cx, _cy, _col, _a);
        draw_vertex_colour(_ax, _ay, _col, _a); draw_vertex_colour(_cx, _cy, _col, _a); draw_vertex_colour(_dx, _dy, _col, _a);
        _v += 6;
    }
    draw_primitive_end();
    brk_cx__scissor_off(_prev);
}

/// @function brk_cx__fill_layered(ctx, ring, paint, alpha)
/// @description A large shape under an AXIS-ALIGNED linear gradient (a page, a plate, a band): its box filled
/// with exact gradient bands into a layer, everything outside the ring erased (one solid even-odd pass), composited.
/// MEASURED reason (sibling kit): the scanline sampled the gradient every 4 px of every row - one large body cost ~0.9 s at 2x.
/// Returns false (the caller scanline-fills) for a diagonal gradient, a small shape, or no surface target. Internal.
function brk_cx__fill_layered(_c, _ring, _paint, _alpha) {
    if (abs(_paint.x1 - _paint.x0) > 0.0001 && abs(_paint.y1 - _paint.y0) > 0.0001) return false;
    var _x0 = 1000000, _y0 = 1000000, _x1 = -1000000, _y1 = -1000000, _n = array_length(_ring);
    for (var _i = 0; _i < _n; _i++) { _x0 = min(_x0, _ring[_i][0]); _x1 = max(_x1, _ring[_i][0]); _y0 = min(_y0, _ring[_i][1]); _y1 = max(_y1, _ring[_i][1]); }
    // ⛔ MEASURED 2026-10-04 (sibling kit): the floor was 20,000 px and a small plate (136 x 36 at 2x) fell under it, so every
    // re-bake of it sampled its gradient pixel by pixel through the scanline - four small plates cost ~200 ms, a stall a
    // player could see. A layer is cheap at any size that is
    // not a sliver.
    if ((_x1 - _x0) * (_y1 - _y0) < 1500) return false;
    var _tgt = surface_get_target();
    if (_tgt == -1 || !surface_exists(_tgt)) return false;
    var _cp = { rings: [_ring], x0: _x0 - 1, y0: _y0 - 1, x1: _x1 + 1, y1: _y1 + 1, rect: true, w: surface_get_width(_tgt), h: surface_get_height(_tgt) };
    _cp.layer = surface_create(_cp.w, _cp.h);
    surface_set_target(_cp.layer);
    draw_clear_alpha(c_black, 0);
    brk_cx__rect_fast(_c, floor(_x0) - 1, floor(_y0) - 1, ceil(_x1) + 1, ceil(_y1) + 1, _paint, _alpha);
    brk_cx__layer_end(_c, _cp);
    return true;
}

/// @function brk_cx_fill_rect(ctx, x, y, w, h)
/// @description Fill a rectangle without touching the current path.
function brk_cx_fill_rect(_c, _x, _y, _w, _h) {
    _c.counts.rect++;
    if (!(_w > 0) || !(_h > 0)) return;
    var _m = _c.m;
    // an axis-aligned device rectangle: no rotation, or a quarter turn, within a hair
    var _axis = (abs(_m[1]) < 0.0001 && abs(_m[2]) < 0.0001) || (abs(_m[0]) < 0.0001 && abs(_m[3]) < 0.0001);
    if (_axis && brk_cx__rect_clips(_c)) {
        var _p = brk_cx__pt(_c, _x, _y), _q = brk_cx__pt(_c, _x + _w, _y + _h);
        var _x0 = min(_p[0], _q[0]), _y0 = min(_p[1], _q[1]), _x1 = max(_p[0], _q[0]), _y1 = max(_p[1], _q[1]);
        if ((_c.fill.kind == 0 || _c.fill.kind == 1) && brk_cx__rect_fast(_c, _x0, _y0, _x1, _y1, _c.fill, _c.alpha)) return;
        // a radial (or diagonal) wash over a rectangle: a vertex-coloured mesh, which a smooth gradient survives exactly
        // enough to the eye; the scanline union for a full-screen light cost seconds (BRK_MESH_CELL px cells)
        brk_cx__rect_mesh(_c, _x0, _y0, _x1, _y1, _c.fill, _c.alpha);
        return;
    }
    brk_cx__fill(_c, [[brk_cx__pt(_c, _x, _y), brk_cx__pt(_c, _x + _w, _y), brk_cx__pt(_c, _x + _w, _y + _h), brk_cx__pt(_c, _x, _y + _h)]], _c.fill, _c.alpha, BRK_FILL_NONZERO);
}

/// @function brk_cx_stroke(ctx)
/// @description Stroke the current path with the stroke paint, at the line width under the current transform.
function brk_cx_stroke(_c) {
    _c.counts.stroke++;
    // destination-out: the stroke as ONE union fill, so an erase never erases twice where its segments overlap
    if (_c.op == 1) { gpu_push_state(); gpu_set_blendmode_ext(bm_zero, bm_inv_src_alpha); brk_cx__stroke_subs(_c, (array_length(_c.dash) > 0) ? brk_cx__dashed(_c, _c.subs) : _c.subs); gpu_pop_state(); return; }
    var _subs = (array_length(_c.dash) > 0) ? brk_cx__dashed(_c, _c.subs) : _c.subs;
    // a ROUND join (ctx.join = 1, the canvas lineJoin "round") takes the exact union, which puts a disc at every joint and
    // never darkens a translucent stroke where its pieces overlap; the mitred strip is for the default join
    if (_c.stroke.kind == 0 && _c.join == 0 && brk_cx__rect_clips(_c)) { brk_cx__strip_subs(_c, _subs); return; }
    brk_cx__stroke_subs(_c, _subs);
}

/// @function brk_cx_stroke_rect(ctx, x, y, w, h)
/// @description Stroke a rectangle without touching the current path (not counted, as a canvas recorder does not).
function brk_cx_stroke_rect(_c, _x, _y, _w, _h) {
    var _s = { pts: [brk_cx__pt(_c, _x, _y), brk_cx__pt(_c, _x + _w, _y), brk_cx__pt(_c, _x + _w, _y + _h), brk_cx__pt(_c, _x, _y + _h)], closed: true };
    if (_c.stroke.kind == 0 && brk_cx__rect_clips(_c)) { brk_cx__strip_subs(_c, [_s]); return; }
    brk_cx__stroke_subs(_c, [_s]);
}

/// @function brk_cx__rect_clips(ctx)
/// @description True when every clip region is an axis-aligned rectangle (the GPU scissor can apply it). Internal.
function brk_cx__rect_clips(_c) {
    for (var _k = 0; _k < array_length(_c.clips); _k++) if (!_c.clips[_k].rect) return false;
    return true;
}

/// @function brk_cx__scissor_on(ctx)
/// @description Apply the rectangular clips as the GPU scissor; returns the previous scissor (or undefined when there
/// is no clip). Internal.
function brk_cx__scissor_on(_c) {
    var _n = array_length(_c.clips);
    if (_n == 0) return undefined;
    var _x0 = -1000000, _y0 = -1000000, _x1 = 1000000, _y1 = 1000000;
    for (var _k = 0; _k < _n; _k++) { var _cp = _c.clips[_k]; _x0 = max(_x0, _cp.x0); _y0 = max(_y0, _cp.y0); _x1 = min(_x1, _cp.x1); _y1 = min(_y1, _cp.y1); }
    var _prev = gpu_get_scissor();
    var _ix0 = max(_prev.x, floor(_x0 + 0.5)), _iy0 = max(_prev.y, floor(_y0 + 0.5));
    var _ix1 = min(_prev.x + _prev.w, floor(_x1 + 0.5)), _iy1 = min(_prev.y + _prev.h, floor(_y1 + 0.5));
    gpu_set_scissor(_ix0, _iy0, max(0, _ix1 - _ix0), max(0, _iy1 - _iy0));
    return _prev;
}

/// @function brk_cx__scissor_off(prev)
/// @description Restore the scissor brk_cx__scissor_on replaced. Internal.
function brk_cx__scissor_off(_prev) { if (is_struct(_prev)) gpu_set_scissor(_prev.x, _prev.y, _prev.w, _prev.h); }

/// @function brk_cx__convex(ring)
/// @description True when a ring turns one way only (near-zero turns and repeated points ignored). Internal.
function brk_cx__convex(_r) {
    var _n = array_length(_r), _sign = 0;
    if (_n < 3) return false;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _r[_i], _b = _r[(_i + 1) mod _n], _d = _r[(_i + 2) mod _n];
        var _cr = (_b[0] - _a[0]) * (_d[1] - _b[1]) - (_b[1] - _a[1]) * (_d[0] - _b[0]);
        if (abs(_cr) < 0.0001) continue;
        var _s = (_cr > 0) ? 1 : -1;
        if (_sign == 0) _sign = _s; else if (_s != _sign) return false;
    }
    return _sign != 0;
}

/// @function brk_cx__fan(ctx, ring, paint, alpha)
/// @description A convex ring as a fan (flat paint) or a mesh of concentric rings (radial paint, every vertex coloured
/// at its own point). Internal.
function brk_cx__fan(_c, _r, _paint, _alpha) {
    var _n = array_length(_r), _cx = 0, _cy = 0, _i, _k;
    for (_i = 0; _i < _n; _i++) { _cx += _r[_i][0]; _cy += _r[_i][1]; }
    _cx /= _n; _cy /= _n;
    var _prev = brk_cx__scissor_on(_c);
    if (_paint.kind == 0) {
        var _a = _alpha * _paint.a;
        draw_primitive_begin(pr_trianglelist);
        var _v = 0;
        for (_i = 0; _i < _n; _i++) {
            if (_v >= 900) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); _v = 0; }
            var _p = _r[_i], _q = _r[(_i + 1) mod _n];
            draw_vertex_colour(_cx, _cy, _paint.col, _a); draw_vertex_colour(_p[0], _p[1], _paint.col, _a); draw_vertex_colour(_q[0], _q[1], _paint.col, _a);
            _v += 3;
        }
        draw_primitive_end();
    } else {
        // at most 48 spokes and 6 rings: a radial wash has no edge to resolve, only a ramp
        var _step = max(1, ceil(_n / 48)), _pts = [];
        for (_i = 0; _i < _n; _i += _step) array_push(_pts, _r[_i]);
        var _m = array_length(_pts), _K = 6;
        draw_primitive_begin(pr_trianglelist);
        var _vv = 0;
        for (_k = 0; _k < _K; _k++) {
            var _t0 = _k / _K, _t1 = (_k + 1) / _K;
            for (_i = 0; _i < _m; _i++) {
                if (_vv >= 894) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); _vv = 0; }
                var _a0 = _pts[_i], _b0 = _pts[(_i + 1) mod _m];
                var _p00x = _cx + (_a0[0] - _cx) * _t0, _p00y = _cy + (_a0[1] - _cy) * _t0, _p01x = _cx + (_b0[0] - _cx) * _t0, _p01y = _cy + (_b0[1] - _cy) * _t0;
                var _p10x = _cx + (_a0[0] - _cx) * _t1, _p10y = _cy + (_a0[1] - _cy) * _t1, _p11x = _cx + (_b0[0] - _cx) * _t1, _p11y = _cy + (_b0[1] - _cy) * _t1;
                var _c00 = brk_cx__paint_at(_paint, _p00x, _p00y), _c01 = brk_cx__paint_at(_paint, _p01x, _p01y);
                var _c10 = brk_cx__paint_at(_paint, _p10x, _p10y), _c11 = brk_cx__paint_at(_paint, _p11x, _p11y);
                draw_vertex_colour(_p00x, _p00y, _c00[0], _alpha * _c00[1]); draw_vertex_colour(_p10x, _p10y, _c10[0], _alpha * _c10[1]); draw_vertex_colour(_p11x, _p11y, _c11[0], _alpha * _c11[1]);
                draw_vertex_colour(_p00x, _p00y, _c00[0], _alpha * _c00[1]); draw_vertex_colour(_p11x, _p11y, _c11[0], _alpha * _c11[1]); draw_vertex_colour(_p01x, _p01y, _c01[0], _alpha * _c01[1]);
                _vv += 6;
            }
        }
        draw_primitive_end();
    }
    brk_cx__scissor_off(_prev);
}

/// @function brk_cx__rect_fast(ctx, x0, y0, x1, y1, paint, alpha)
/// @description An axis-aligned device rectangle: one quad (flat), or one band per stop of a gradient running along x
/// or y. Returns false (the caller falls back) for a diagonal gradient. Internal.
function brk_cx__rect_fast(_c, _x0, _y0, _x1, _y1, _paint, _alpha) {
    if (_paint.kind == 1) {
        var _gx = _paint.x1 - _paint.x0, _gy = _paint.y1 - _paint.y0;
        if (abs(_gx) > 0.0001 && abs(_gy) > 0.0001) return false;
    }
    var _prev = brk_cx__scissor_on(_c);
    draw_primitive_begin(pr_trianglelist);
    if (_paint.kind == 0) {
        var _a = _alpha * _paint.a;
        draw_vertex_colour(_x0, _y0, _paint.col, _a); draw_vertex_colour(_x1, _y0, _paint.col, _a); draw_vertex_colour(_x0, _y1, _paint.col, _a);
        draw_vertex_colour(_x1, _y0, _paint.col, _a); draw_vertex_colour(_x1, _y1, _paint.col, _a); draw_vertex_colour(_x0, _y1, _paint.col, _a);
    } else {
        var _alongX = abs(_paint.x1 - _paint.x0) > 0.0001;
        var _g0 = _alongX ? _paint.x0 : _paint.y0, _g1 = _alongX ? _paint.x1 : _paint.y1;
        var _lo = _alongX ? _x0 : _y0, _hi = _alongX ? _x1 : _y1;
        // cut points: the rect's own ends plus every stop that falls inside it
        var _cuts = [_lo, _hi], _s = _paint.stops;
        for (var _i = 0; _i < array_length(_s); _i++) { var _u = _g0 + (_g1 - _g0) * _s[_i][0]; if (_u > _lo && _u < _hi) array_push(_cuts, _u); }
        array_sort(_cuts, true);
        for (var _j = 0; _j + 1 < array_length(_cuts); _j++) {
            var _ua = _cuts[_j], _ub = _cuts[_j + 1];
            if (_ub - _ua < 0.0001) continue;
            var _ca = brk_cx__paint_at(_paint, _alongX ? _ua : _x0, _alongX ? _y0 : _ua), _cb = brk_cx__paint_at(_paint, _alongX ? _ub : _x0, _alongX ? _y0 : _ub);
            var _aa = _alpha * _ca[1], _ab = _alpha * _cb[1];
            if (_alongX) {
                draw_vertex_colour(_ua, _y0, _ca[0], _aa); draw_vertex_colour(_ub, _y0, _cb[0], _ab); draw_vertex_colour(_ua, _y1, _ca[0], _aa);
                draw_vertex_colour(_ub, _y0, _cb[0], _ab); draw_vertex_colour(_ub, _y1, _cb[0], _ab); draw_vertex_colour(_ua, _y1, _ca[0], _aa);
            } else {
                draw_vertex_colour(_x0, _ua, _ca[0], _aa); draw_vertex_colour(_x1, _ua, _ca[0], _aa); draw_vertex_colour(_x0, _ub, _cb[0], _ab);
                draw_vertex_colour(_x1, _ua, _ca[0], _aa); draw_vertex_colour(_x1, _ub, _cb[0], _ab); draw_vertex_colour(_x0, _ub, _cb[0], _ab);
            }
        }
    }
    draw_primitive_end();
    brk_cx__scissor_off(_prev);
    return true;
}

/// @function brk_cx__rect_mesh(ctx, x0, y0, x1, y1, paint, alpha)
/// @description An axis-aligned device rectangle as a grid of vertex-coloured cells (BRK_MESH_CELL px), every vertex
/// coloured at its own point - for a radial or diagonal gradient, under rectangular clips (the scissor). Internal.
function brk_cx__rect_mesh(_c, _x0, _y0, _x1, _y1, _paint, _alpha) {
    if (!(_x1 > _x0) || !(_y1 > _y0)) return;
    var _nx = max(1, ceil((_x1 - _x0) / BRK_MESH_CELL)), _ny = max(1, ceil((_y1 - _y0) / BRK_MESH_CELL));
    var _cols = array_create(_nx + 1), _alps = array_create(_nx + 1), _pc = array_create(_nx + 1), _pa = array_create(_nx + 1);
    var _prev = brk_cx__scissor_on(_c);
    var _i, _j, _v = 0;
    for (_i = 0; _i <= _nx; _i++) { var _q = brk_cx__paint_at(_paint, _x0 + (_x1 - _x0) * _i / _nx, _y0); _pc[_i] = _q[0]; _pa[_i] = _alpha * _q[1]; }
    draw_primitive_begin(pr_trianglelist);
    for (_j = 1; _j <= _ny; _j++) {
        var _ya = _y0 + (_y1 - _y0) * (_j - 1) / _ny, _yb = _y0 + (_y1 - _y0) * _j / _ny;
        for (_i = 0; _i <= _nx; _i++) { var _r = brk_cx__paint_at(_paint, _x0 + (_x1 - _x0) * _i / _nx, _yb); _cols[_i] = _r[0]; _alps[_i] = _alpha * _r[1]; }
        for (_i = 0; _i < _nx; _i++) {
            if (_pa[_i] <= 0 && _pa[_i + 1] <= 0 && _alps[_i] <= 0 && _alps[_i + 1] <= 0) continue;
            if (_v >= 900) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); _v = 0; }
            var _xa = _x0 + (_x1 - _x0) * _i / _nx, _xb = _x0 + (_x1 - _x0) * (_i + 1) / _nx;
            draw_vertex_colour(_xa, _ya, _pc[_i], _pa[_i]); draw_vertex_colour(_xb, _ya, _pc[_i + 1], _pa[_i + 1]); draw_vertex_colour(_xa, _yb, _cols[_i], _alps[_i]);
            draw_vertex_colour(_xb, _ya, _pc[_i + 1], _pa[_i + 1]); draw_vertex_colour(_xb, _yb, _cols[_i + 1], _alps[_i + 1]); draw_vertex_colour(_xa, _yb, _cols[_i], _alps[_i]);
            _v += 6;
        }
        for (_i = 0; _i <= _nx; _i++) { _pc[_i] = _cols[_i]; _pa[_i] = _alps[_i]; }
    }
    draw_primitive_end();
    brk_cx__scissor_off(_prev);
}

/// @function brk_cx__strip_subs(ctx, subs)
/// @description Solid strokes as one triangle strip per subpath, the vertices MITRE-joined (the offset at each vertex is
/// the bisector of its two segments' normals, capped at 4x), so consecutive segments share an edge instead of
/// overlapping - a translucent line never darkens at its joints and never gaps. Round caps are discs. Internal.
function brk_cx__strip_subs(_c, _subs) {
    var _w = _c.lw * brk_cx__scale(_c), _a = _c.alpha;
    if (!(_w > 0)) return;
    if (_w < 1) { _a *= max(0.15, _w); _w = 1; }
    var _h = _w * 0.5, _col = _c.stroke.col, _ca = _a * _c.stroke.a;
    var _prev = brk_cx__scissor_on(_c);
    for (var _s = 0; _s < array_length(_subs); _s++) {
        var _raw = _subs[_s].pts, _cl = _subs[_s].closed;
        // drop repeated points (a zero-length segment has no direction)
        var _p = [];
        for (var _i = 0; _i < array_length(_raw); _i++) {
            if (array_length(_p) > 0) { var _l = _p[array_length(_p) - 1]; if (abs(_l[0] - _raw[_i][0]) < 0.001 && abs(_l[1] - _raw[_i][1]) < 0.001) continue; }
            array_push(_p, _raw[_i]);
        }
        if (_cl && array_length(_p) > 2) { var _f = _p[0], _e = _p[array_length(_p) - 1]; if (abs(_f[0] - _e[0]) < 0.001 && abs(_f[1] - _e[1]) < 0.001) array_delete(_p, array_length(_p) - 1, 1); }
        var _n = array_length(_p);
        if (_n < 2) continue;
        if (_n == 2) _cl = false;
        // unit normals of every segment
        var _segs = _cl ? _n : _n - 1, _nx = array_create(_segs), _ny = array_create(_segs);
        for (var _k = 0; _k < _segs; _k++) {
            var _pa = _p[_k], _pb = _p[(_k + 1) mod _n];
            var _dx = _pb[0] - _pa[0], _dy = _pb[1] - _pa[1], _dl = max(0.000001, sqrt(_dx * _dx + _dy * _dy));
            _nx[_k] = -_dy / _dl; _ny[_k] = _dx / _dl;
        }
        // the mitred offset at every point: the bisector of its two segments' normals, lengthened to keep the stroke's
        // width across the turn, capped at 4x so a hairpin cannot throw a spike
        var _ox = array_create(_n), _oy = array_create(_n);
        for (var _j = 0; _j < _n; _j++) {
            if (!_cl && _j == 0) { _ox[_j] = _nx[0]; _oy[_j] = _ny[0]; continue; }
            if (!_cl && _j == _n - 1) { _ox[_j] = _nx[_segs - 1]; _oy[_j] = _ny[_segs - 1]; continue; }
            var _i0 = (_j - 1 + _segs) mod _segs, _i1 = _j mod _segs;
            var _mx = _nx[_i0] + _nx[_i1], _my = _ny[_i0] + _ny[_i1], _ml = sqrt(_mx * _mx + _my * _my);
            if (_ml < 0.001) { _ox[_j] = _nx[_i0]; _oy[_j] = _ny[_i0]; continue; }
            _mx /= _ml; _my /= _ml;
            var _k2 = 1 / max(0.25, _mx * _nx[_i0] + _my * _ny[_i0]);
            _ox[_j] = _mx * _k2; _oy[_j] = _my * _k2;
        }
        // one quad per segment; neighbours share their mitred edge exactly, so nothing overlaps and nothing gaps
        draw_primitive_begin(pr_trianglelist);
        var _v = 0;
        for (var _q = 0; _q < _segs; _q++) {
            if (_v >= 900) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); _v = 0; }
            var _ia = _q, _ib = (_q + 1) mod _n, _A = _p[_ia], _B = _p[_ib];
            var _ax1 = _A[0] + _ox[_ia] * _h, _ay1 = _A[1] + _oy[_ia] * _h, _ax2 = _A[0] - _ox[_ia] * _h, _ay2 = _A[1] - _oy[_ia] * _h;
            var _bx1 = _B[0] + _ox[_ib] * _h, _by1 = _B[1] + _oy[_ib] * _h, _bx2 = _B[0] - _ox[_ib] * _h, _by2 = _B[1] - _oy[_ib] * _h;
            draw_vertex_colour(_ax1, _ay1, _col, _ca); draw_vertex_colour(_bx1, _by1, _col, _ca); draw_vertex_colour(_ax2, _ay2, _col, _ca);
            draw_vertex_colour(_bx1, _by1, _col, _ca); draw_vertex_colour(_bx2, _by2, _col, _ca); draw_vertex_colour(_ax2, _ay2, _col, _ca);
            _v += 6;
        }
        draw_primitive_end();
        if (_c.cap == 1 && !_cl) {
            // a round cap wholly outside the clip box draws nothing: skip it (long texture lines run past both ends of
            // what they texture, so every one of their caps is hidden - MEASURED in the sibling kit, a large share of a bake)
            if (!brk_cx__hidden(_c, _p[0][0], _p[0][1], _h)) brk_cx__fan(_c, brk_cx__disc(_p[0][0], _p[0][1], _h), _c.stroke, _a);
            if (!brk_cx__hidden(_c, _p[_n - 1][0], _p[_n - 1][1], _h)) brk_cx__fan(_c, brk_cx__disc(_p[_n - 1][0], _p[_n - 1][1], _h), _c.stroke, _a);
        }
    }
    brk_cx__scissor_off(_prev);
}

/// @function brk_cx__hidden(ctx, x, y, r)
/// @description True when a disc of radius r at a device point lies wholly outside the clip boxes or the target surface
/// (nothing it drew could show). Internal.
function brk_cx__hidden(_c, _x, _y, _r) {
    var _x0 = -1000000, _y0 = -1000000, _x1 = 1000000, _y1 = 1000000;
    for (var _k = 0; _k < array_length(_c.clips); _k++) { var _cp = _c.clips[_k]; _x0 = max(_x0, _cp.x0); _y0 = max(_y0, _cp.y0); _x1 = min(_x1, _cp.x1); _y1 = min(_y1, _cp.y1); }
    var _t = surface_get_target();
    if (_t != -1 && surface_exists(_t)) { _x0 = max(_x0, 0); _y0 = max(_y0, 0); _x1 = min(_x1, surface_get_width(_t)); _y1 = min(_y1, surface_get_height(_t)); }
    return (_x + _r < _x0) || (_x - _r > _x1) || (_y + _r < _y0) || (_y - _r > _y1);
}

/// @function brk_cx__stroke_subs(ctx, subs)
/// @description The union of every segment's quad (plus round joins and caps) filled once, nonzero, so a translucent
/// stroke never doubles its alpha where segments meet. Internal.
function brk_cx__stroke_subs(_c, _subs) {
    var _w = _c.lw * brk_cx__scale(_c), _a = _c.alpha;
    if (!(_w > 0)) return;
    if (_w < 1) { _a *= max(0.15, _w); _w = 1; }
    var _h = _w * 0.5, _rings = [];
    for (var _s = 0; _s < array_length(_subs); _s++) {
        var _p = _subs[_s].pts, _cl = _subs[_s].closed, _n = array_length(_p);
        if (_n < 2) continue;
        var _m = _cl ? _n : _n - 1;
        for (var _i = 0; _i < _m; _i++) {
            var _pa = _p[_i], _pb = _p[(_i + 1) mod _n];
            var _dx = _pb[0] - _pa[0], _dy = _pb[1] - _pa[1], _l = sqrt(_dx * _dx + _dy * _dy);
            if (_l < 0.0001) continue;
            var _nx = -_dy / _l * _h, _ny = _dx / _l * _h;
            array_push(_rings, brk_cx__pos([[_pa[0] + _nx, _pa[1] + _ny], [_pb[0] + _nx, _pb[1] + _ny], [_pb[0] - _nx, _pb[1] - _ny], [_pa[0] - _nx, _pa[1] - _ny]]));
        }
        if (_w >= 2.5) {
            var _from = _cl ? 0 : 1, _to = _cl ? _n : _n - 1;
            for (var _j = _from; _j < _to; _j++) array_push(_rings, brk_cx__disc(_p[_j][0], _p[_j][1], _h));
        }
        if (_c.cap == 1 && !_cl) {
            array_push(_rings, brk_cx__disc(_p[0][0], _p[0][1], _h));
            array_push(_rings, brk_cx__disc(_p[_n - 1][0], _p[_n - 1][1], _h));
        }
    }
    brk_cx__fill(_c, _rings, _c.stroke, _a, BRK_FILL_NONZERO);
}

/// @function brk_cx__disc(x, y, r)
/// @description A small disc ring, positively wound. Internal.
function brk_cx__disc(_x, _y, _r) {
    var _n = clamp(ceil(_r * 1.6), 8, 40), _o = array_create(_n);
    for (var _i = 0; _i < _n; _i++) { var _t = _i / _n * 2 * pi; _o[_i] = [_x + cos(_t) * _r, _y + sin(_t) * _r]; }
    return _o;
}

/// @function brk_cx__pos(ring)
/// @description The ring wound positively (reversed if its signed area is negative), so a union fills. Internal.
function brk_cx__pos(_r) {
    var _a = 0, _n = array_length(_r);
    for (var _i = 0; _i < _n; _i++) { var _j = (_i + 1) mod _n; _a += _r[_i][0] * _r[_j][1] - _r[_j][0] * _r[_i][1]; }
    if (_a < 0) array_reverse_ext(_r);
    return _r;
}

/// @function brk_cx_clip(ctx)
/// @description Intersect the clip region with the current path (nonzero). An axis-aligned RECTANGLE is the GPU
/// scissor. Anything else (a rounded panel, a shaped plate, several rings at once) opens a LAYER: what is drawn
/// until the matching brk_cx_restore goes into a transparent surface, and the restore erases everything outside the path
/// before compositing it back. With no surface target a single CONVEX ring falls back to an exact span clip; otherwise
/// returns false and clips nothing.
function brk_cx_clip(_c) {
    var _r = brk_cx__rings(_c);
    if (array_length(_r) == 0) return false;
    var _y0 = 1000000, _y1 = -1000000, _x0 = 1000000, _x1 = -1000000;
    for (var _k = 0; _k < array_length(_r); _k++) {
        var _rk = _r[_k];
        for (var _i = 0; _i < array_length(_rk); _i++) { _x0 = min(_x0, _rk[_i][0]); _x1 = max(_x1, _rk[_i][0]); _y0 = min(_y0, _rk[_i][1]); _y1 = max(_y1, _rk[_i][1]); }
    }
    var _ring = _r[0], _n = array_length(_ring);
    // an axis-aligned rectangle is the GPU scissor's shape
    var _rect = (array_length(_r) == 1 && _n == 4);
    for (var _e = 0; _e < _n && _rect; _e++) {
        var _a = _ring[_e], _b = _ring[(_e + 1) mod _n];
        if (abs(_a[0] - _b[0]) > 0.0001 && abs(_a[1] - _b[1]) > 0.0001) _rect = false;
    }
    if (_rect) { array_push(_c.clips, { ring: _ring, x0: _x0, y0: _y0, x1: _x1, y1: _y1, rect: true }); return true; }
    if (brk_cx__layer_begin(_c, _r, _x0, _y0, _x1, _y1)) return true;
    if (array_length(_r) != 1 || !brk_cx__convex(_ring)) return false;
    array_push(_c.clips, { ring: _ring, x0: _x0, y0: _y0, x1: _x1, y1: _y1, rect: false });
    return true;
}

/// @function brk_cx__layer_begin(ctx, rings, x0, y0, x1, y1)
/// @description Open a layer clip for a path's rings: a transparent surface the size of the current target becomes the
/// target. The clip entry counts as a RECTANGLE (its box) for the fast paths and the scissor; the exact cut happens
/// when the layer is finished. Internal.
function brk_cx__layer_begin(_c, _rings, _x0, _y0, _x1, _y1) {
    var _tgt = surface_get_target();
    if (_tgt == -1 || !surface_exists(_tgt)) return false;
    var _w = surface_get_width(_tgt), _h = surface_get_height(_tgt);
    var _lay = surface_create(_w, _h);
    surface_set_target(_lay);
    draw_clear_alpha(c_black, 0);
    array_push(_c.clips, { rings: _rings, x0: _x0 - 1, y0: _y0 - 1, x1: _x1 + 1, y1: _y1 + 1, rect: true, layer: _lay, w: _w, h: _h });
    return true;
}

/// @function brk_cx__layer_end(ctx, clip)
/// @description Finish a layer clip: erase the layer outside its ring (the ring's box, widened, minus the ring - one
/// even-odd scanline pass whose span ends carry coverage, drawn with dest *= (1 - coverage)), then composite the
/// premultiplied layer onto the surface it was opened over and free it. Internal.
function brk_cx__layer_end(_c, _cp) {
    if (!surface_exists(_cp.layer)) return;
    var _bx0 = max(0, floor(_cp.x0) - 3), _by0 = max(0, floor(_cp.y0) - 3), _bx1 = min(_cp.w, ceil(_cp.x1) + 3), _by1 = min(_cp.h, ceil(_cp.y1) + 3);
    var _box = [[_bx0, _by0], [_bx1, _by0], [_bx1, _by1], [_bx0, _by1]];
    // the erase must not itself be clipped by the clip being finished: lift the clip list for the pass. Even-odd over
    // the box and the rings is "outside the path" for rings that do not overlap (an outline's loops never do; a hole
    // nested in its loop stays erased).
    var _keep = _c.clips, _er = [_box];
    for (var _k = 0; _k < array_length(_cp.rings); _k++) array_push(_er, _cp.rings[_k]);
    _c.clips = [];
    gpu_push_state();
    gpu_set_blendmode_ext(bm_zero, bm_inv_src_alpha);
    brk_cx__fill(_c, _er, brk_cx_solid([255, 255, 255]), 1, BRK_FILL_EVENODD);
    gpu_pop_state();
    _c.clips = _keep;
    surface_reset_target();
    gpu_push_state();
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    draw_surface_ext(_cp.layer, 0, 0, 1, 1, 0, c_white, 1);
    gpu_pop_state();
    surface_free(_cp.layer);
}

/// @function brk_cx__clip_span(ctx, y)
/// @description The clip interval [l, r] on the scanline at y, or undefined when the row is clipped away (or
/// [-inf, +inf] with no clip). Internal.
function brk_cx__clip_span(_c, _y) {
    var _l = -1000000, _r = 1000000;
    for (var _k = 0; _k < array_length(_c.clips); _k++) {
        var _cp = _c.clips[_k];
        if (_y < _cp.y0 || _y > _cp.y1) return undefined;
        // a layer clip cuts by its box here; its exact (concave) cut is the erase when the layer is finished
        if (variable_struct_exists(_cp, "layer")) { _l = max(_l, _cp.x0); _r = min(_r, _cp.x1); if (_r <= _l) return undefined; continue; }
        var _ring = _cp.ring, _n = array_length(_ring), _lo = 1000000, _hi = -1000000, _hit = false;
        for (var _i = 0; _i < _n; _i++) {
            var _a = _ring[_i], _b = _ring[(_i + 1) mod _n];
            if ((_a[1] <= _y && _b[1] > _y) || (_b[1] <= _y && _a[1] > _y)) {
                var _x = _a[0] + (_y - _a[1]) * (_b[0] - _a[0]) / (_b[1] - _a[1]);
                _lo = min(_lo, _x); _hi = max(_hi, _x); _hit = true;
            }
        }
        if (!_hit) return undefined;
        _l = max(_l, _lo); _r = min(_r, _hi);
        if (_r <= _l) return undefined;
    }
    return [_l, _r];
}

/// @function brk_cx__paint_at(paint, x, y)
/// @description The [colour, alpha] of a paint at a device point (gradients extend their end stops). Internal.
function brk_cx__paint_at(_p, _x, _y) {
    if (_p.kind == 0) return [_p.col, _p.a];
    var _t = 0;
    if (_p.kind == 1) {
        var _gx = _p.x1 - _p.x0, _gy = _p.y1 - _p.y0, _l2 = _gx * _gx + _gy * _gy;
        _t = (_l2 > 0) ? ((_x - _p.x0) * _gx + (_y - _p.y0) * _gy) / _l2 : 0;
    } else {
        _t = brk_cx__radial_t(_p, _x, _y);
        if (is_undefined(_t)) return [c_black, 0];
    }
    return brk_cx__stops_at(_p.stops, _t);
}

/// @function brk_cx__radial_t(paint, x, y)
/// @description The canvas two-circle gradient parameter at a point: the largest t whose circle passes through it with
/// a non-negative radius, or undefined. Internal.
function brk_cx__radial_t(_p, _x, _y) {
    var _cdx = _p.x1 - _p.x0, _cdy = _p.y1 - _p.y0, _dr = _p.r1 - _p.r0;
    var _pdx = _x - _p.x0, _pdy = _y - _p.y0;
    var _a = _cdx * _cdx + _cdy * _cdy - _dr * _dr;
    var _b = _pdx * _cdx + _pdy * _cdy + _p.r0 * _dr;
    var _cc = _pdx * _pdx + _pdy * _pdy - _p.r0 * _p.r0;
    var _t;
    if (abs(_a) < 0.000001) {
        if (abs(_b) < 0.000001) return undefined;
        _t = _cc / (2 * _b);
    } else {
        var _disc = _b * _b - _a * _cc;
        if (_disc < 0) return undefined;
        var _sq = sqrt(_disc), _t1 = (_b + _sq) / _a, _t2 = (_b - _sq) / _a;
        _t = max(_t1, _t2);
        if (_p.r0 + _t * _dr < 0) { _t = min(_t1, _t2); if (_p.r0 + _t * _dr < 0) return undefined; }
    }
    return _t;
}

/// @function brk_cx__stops_at(stops, t)
/// @description [colour, alpha] of a stop list at t, clamped to its ends. Internal.
function brk_cx__stops_at(_s, _t) {
    var _n = array_length(_s);
    if (_n == 0) return [c_black, 0];
    if (_t <= _s[0][0]) return [_s[0][1], _s[0][2]];
    for (var _i = 1; _i < _n; _i++) {
        if (_t <= _s[_i][0]) {
            var _a = _s[_i - 1], _b = _s[_i], _sp = _b[0] - _a[0];
            var _k = (_sp > 0.000001) ? (_t - _a[0]) / _sp : 1;
            return [merge_colour(_a[1], _b[1], _k), _a[2] + (_b[2] - _a[2]) * _k];
        }
    }
    return [_s[_n - 1][1], _s[_n - 1][2]];
}

/// @function brk_cx__room(ctx, n)
/// @description Make room for n vertices in the open triangle list, flushing at 900. Internal.
function brk_cx__room(_c, _n) {
    if (_c.verts + _n > 900) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); _c.verts = 0; }
    _c.verts += _n;
}

/// @function brk_cx__fill(ctx, rings, paint, alpha, rule)
/// @description Scanline-fill device rings (nonzero or even-odd) with a paint, cut to the clip region. Each span end
/// carries its fractional coverage as alpha. Returns the number of spans drawn. Internal.
function brk_cx__fill(_c, _rings, _paint, _alpha, _rule) {
    if (!is_array(_rings) || !(_alpha > 0)) return 0;
    var _edges = [], _y0 = 1000000, _y1 = -1000000;
    for (var _r = 0; _r < array_length(_rings); _r++) {
        var _ring = _rings[_r];
        var _n = array_length(_ring);
        if (_n < 3) continue;
        for (var _i = 0; _i < _n; _i++) {
            var _a = _ring[_i], _b = _ring[(_i + 1) mod _n];
            if (abs(_a[1] - _b[1]) < 0.00001) continue;
            var _down = (_a[1] < _b[1]);
            var _top = _down ? _a : _b, _bot = _down ? _b : _a;
            array_push(_edges, [_top[1], _bot[1], _top[0], (_bot[0] - _top[0]) / (_bot[1] - _top[1]), _down ? 1 : -1]);
            _y0 = min(_y0, _top[1]); _y1 = max(_y1, _bot[1]);
        }
    }
    var _ne = array_length(_edges);
    if (_ne < 2) return 0;
    // ⛔ The comparator returns a SIGN, never a difference: a fractional difference reads as "equal" to the sort and
    // admits edges rows late (a disc lost two thirds of its interior that way in a sibling product).
    array_sort(_edges, function(_p, _q) { return (_p[0] < _q[0]) ? -1 : ((_p[0] > _q[0]) ? 1 : 0); });
    var _active = [], _next = 0, _spans = 0;
    _c.verts = 0;
    draw_primitive_begin(pr_trianglelist);
    for (var _y = floor(_y0) + 0.5; _y < _y1; _y += 1) {
        while (_next < _ne && _edges[_next][0] <= _y) { array_push(_active, _edges[_next]); _next++; }
        var _xs = [], _keep = [];
        for (var _k = 0; _k < array_length(_active); _k++) {
            var _e = _active[_k];
            if (_e[1] <= _y) continue;
            array_push(_keep, _e);
            if (_e[0] <= _y) array_push(_xs, [_e[2] + (_y - _e[0]) * _e[3], _e[4]]);
        }
        _active = _keep;
        var _nx = array_length(_xs);
        if (_nx < 2) continue;
        var _cl = brk_cx__clip_span(_c, _y);
        if (is_undefined(_cl)) continue;
        array_sort(_xs, function(_p, _q) { return (_p[0] < _q[0]) ? -1 : ((_p[0] > _q[0]) ? 1 : 0); });
        var _w = 0, _from = 0;
        for (var _s = 0; _s < _nx; _s++) {
            var _was = (_rule == BRK_FILL_EVENODD) ? ((_w & 1) != 0) : (_w != 0);
            _w += (_rule == BRK_FILL_EVENODD) ? 1 : _xs[_s][1];
            var _in = (_rule == BRK_FILL_EVENODD) ? ((_w & 1) != 0) : (_w != 0);
            if (_in && !_was) _from = _xs[_s][0];
            if (!_in && _was) {
                var _xa = max(_from, _cl[0]), _xb = min(_xs[_s][0], _cl[1]);
                if (_xb - _xa >= 0.001) { brk_cx__span(_c, _xa, _xb, _y, _paint, _alpha); _spans++; }
            }
        }
    }
    draw_primitive_end();
    _c.verts = 0;
    return _spans;
}

/// @function brk_cx__span(ctx, xa, xb, y, paint, alpha)
/// @description One scanline span: coverage-alpha ends, a gradient sampled along it. Internal.
function brk_cx__span(_c, _xa, _xb, _y, _paint, _alpha) {
    var _L = floor(_xa), _R = floor(_xb), _ya = _y - 0.5, _yb = _y + 0.5;
    if (_L == _R) { brk_cx__piece(_c, _L, _L + 1, _ya, _yb, _y, _paint, _alpha * (_xb - _xa)); return; }
    brk_cx__piece(_c, _L, _L + 1, _ya, _yb, _y, _paint, _alpha * (_L + 1 - _xa));
    if (_R > _L + 1) {
        if (_paint.kind == 0) brk_cx__piece(_c, _L + 1, _R, _ya, _yb, _y, _paint, _alpha);
        else {
            // a gradient is sampled at most 4 px apart along the row (exact for a linear gradient between stops)
            var _k = max(1, ceil((_R - _L - 1) / 4));
            for (var _i = 0; _i < _k; _i++) brk_cx__piece(_c, _L + 1 + (_R - _L - 1) * _i / _k, _L + 1 + (_R - _L - 1) * (_i + 1) / _k, _ya, _yb, _y, _paint, _alpha);
        }
    }
    if (_xb - _R > 0.001) brk_cx__piece(_c, _R, _R + 1, _ya, _yb, _y, _paint, _alpha * (_xb - _R));
}

/// @function brk_cx__piece(ctx, xa, xb, ya, yb, yc, paint, alpha)
/// @description Two triangles of one span piece, coloured at each end from the paint. Internal.
function brk_cx__piece(_c, _xa, _xb, _ya, _yb, _yc, _paint, _alpha) {
    var _ca, _cb, _aa, _ab;
    if (_paint.kind == 0) { _ca = _paint.col; _cb = _ca; _aa = _alpha * _paint.a; _ab = _aa; }
    else {
        var _pa = brk_cx__paint_at(_paint, _xa, _yc), _pb = brk_cx__paint_at(_paint, _xb, _yc);
        _ca = _pa[0]; _cb = _pb[0]; _aa = _alpha * _pa[1]; _ab = _alpha * _pb[1];
    }
    if (_aa <= 0 && _ab <= 0) return;
    brk_cx__room(_c, 6);
    draw_vertex_colour(_xa, _ya, _ca, _aa); draw_vertex_colour(_xb, _ya, _cb, _ab); draw_vertex_colour(_xa, _yb, _ca, _aa);
    draw_vertex_colour(_xb, _ya, _cb, _ab); draw_vertex_colour(_xb, _yb, _cb, _ab); draw_vertex_colour(_xa, _yb, _ca, _aa);
}

/// @function brk_cx_composite(ctx, mode)
/// @description The canvas globalCompositeOperation: "source-over" (the default) or "destination-out" (what is filled or
/// stroked next ERASES: dest *= 1 - its alpha). Any other value is "source-over". Saved and restored with the state.
/// ⛔ Erase only inside a surface that belongs to the drawing (a bake): it punches whatever the target holds.
function brk_cx_composite(_c, _mode) { _c.op = (_mode == "destination-out") ? 1 : 0; }

/// @function brk__b255(v)
/// @description A channel as an integer 0..255 (anything not a number -> 0). Internal.
function brk__b255(_v) { return is_numeric(_v) ? clamp(floor(real(_v) + 0.5), 0, 255) : 0; }

/// @function brk_col(rgb)
/// @description An [r, g, b] colour (0..255) as a GameMaker colour. Pure.
function brk_col(_c) { if (!is_array(_c) || array_length(_c) < 3) return c_black; return make_colour_rgb(brk__b255(_c[0]), brk__b255(_c[1]), brk__b255(_c[2])); }

// ---------------------------------------------------------------------------------------------------------------
// Type
// ---------------------------------------------------------------------------------------------------------------

/// Two faces, two atlas sizes each, all rasterised from the faces the RPG Maker MZ edition draws with, under OFL-safe
/// family names: "Bracket Display" = Cinzel Bold (SIL OFL 1.1, Copyright 2020 The Cinzel Project Authors) and "Bracket
/// Body" = Alegreya (SIL OFL 1.1, Copyright 2011 The Alegreya Project Authors). See fonts/THIRD-PARTY-NOTICES.txt.
/// ⛔ A LINE IS MEASURED FROM THE FACE, NOT FROM AN ATLAS: brk_text_advance holds every printable character's advance as a
/// fraction of the em, read from the TTF, and a width is sum(advance) * px. The atlas that DRAWS a glyph (the small or the
/// large one, whichever suits the size) never changes where the next glyph goes, so a name fits the same at every size.

#macro BRK_FACE_DISPLAY 0
#macro BRK_FACE_BODY 1

/// @function brk_text_advance(face)
/// @description The advance of every character code 32..126 as a fraction of the em (an array indexed by code - 32),
/// from the face's own hmtx table. GENERATED by Internal_Ops/_port_kit.js from font_advances.json.
/// @param {Real} face BRK_FACE_DISPLAY or BRK_FACE_BODY
/// @returns {Array<Real>}
function brk_text_advance(_face) {
    static _d = [0.25, 0.269, 0.363, 0.575, 0.558, 0.74, 0.807, 0.2, 0.423, 0.423, 0.388, 0.481, 0.231, 0.38, 0.222, 0.426, 0.653, 0.393, 0.617, 0.563, 0.619, 0.554, 0.63, 0.545, 0.603, 0.63, 0.222, 0.231, 0.493, 0.481, 0.481, 0.462, 0.99, 0.717, 0.674, 0.78, 0.828, 0.632, 0.596, 0.836, 0.862, 0.387, 0.385, 0.757, 0.617, 0.953, 0.865, 0.879, 0.656, 0.883, 0.747, 0.578, 0.667, 0.821, 0.728, 0.971, 0.729, 0.702, 0.661, 0.417, 0.426, 0.417, 0.553, 0.5, 0.537, 0.644, 0.604, 0.683, 0.748, 0.564, 0.535, 0.73, 0.751, 0.352, 0.341, 0.673, 0.549, 0.863, 0.779, 0.777, 0.586, 0.767, 0.658, 0.515, 0.599, 0.705, 0.637, 0.87, 0.65, 0.636, 0.607, 0.38, 0.257, 0.38, 0.494];
    static _b = [0.198, 0.285, 0.298, 0.498, 0.459, 0.671, 0.7, 0.176, 0.275, 0.274, 0.456, 0.506, 0.294, 0.38, 0.305, 0.329, 0.533, 0.342, 0.475, 0.416, 0.453, 0.43, 0.462, 0.42, 0.485, 0.455, 0.238, 0.238, 0.506, 0.506, 0.506, 0.36, 0.832, 0.584, 0.597, 0.626, 0.703, 0.591, 0.512, 0.667, 0.754, 0.361, 0.327, 0.628, 0.507, 0.847, 0.719, 0.692, 0.551, 0.697, 0.611, 0.53, 0.546, 0.681, 0.61, 0.932, 0.656, 0.538, 0.568, 0.309, 0.329, 0.309, 0.506, 0.458, 0.398, 0.466, 0.508, 0.424, 0.537, 0.448, 0.33, 0.501, 0.534, 0.282, 0.25, 0.497, 0.244, 0.832, 0.548, 0.498, 0.528, 0.516, 0.383, 0.402, 0.33, 0.541, 0.445, 0.705, 0.475, 0.446, 0.46, 0.309, 0.372, 0.309, 0.506];
    return (_face == BRK_FACE_BODY) ? _b : _d;
}

/// @function brk_text_width(string, px, face)
/// @description The width of a line at px, as the painter measures it: sum of the characters' advances, left to right,
/// times px. A character outside 32..126 measures 0 (the atlases carry nothing else; it is not drawn).
/// @returns {Real}
function brk_text_width(_s, _px, _face) {
    var _a = brk_text_advance(_face), _t = string(_s), _sum = 0;
    for (var _i = 1; _i <= string_length(_t); _i++) { var _o = ord(string_char_at(_t, _i)); if (_o >= 32 && _o <= 126) _sum += _a[_o - 32]; }
    return _sum * _px;
}

/// @function brk_font_for(face, px)
/// @description The atlas to strike `px`-tall type of a face from: the small atlas up to its own size, the large one
/// above (a bitmap scaled UP goes soft). Returns { font, px, ascent } - the atlas, the size it was rasterised at and how
/// far below the top of a glyph cell its BASELINE sits, in the atlas's own pixels.
/// @returns {Struct}
function brk_font_for(_face, _px) {
    if (_face == BRK_FACE_BODY) return (_px <= 20) ? { font: fnt_bracket_body_s, px: 20, ascent: 20 } : { font: fnt_bracket_body_l, px: 44, ascent: 45 };
    return (_px <= 30) ? { font: fnt_bracket_display_s, px: 30, ascent: 29 } : { font: fnt_bracket_display_l, px: 76, ascent: 74 };
}

/// @function brk_cx_glyph(ctx, char, x, y, px, face)
/// @description Strike ONE character with its BASELINE-LEFT at the USER-space point (x, y), under the current transform
/// (translation, rotation and scale all apply - a name on an arc is struck glyph by glyph, rotated), in the context's
/// fill colour at the context alpha. A solid fill only (a gradient paint strikes in its first stop). Counted as a fill.
/// ⛔ Texture filtering is switched ON for the draw and RESTORED after: a scaled atlas with point sampling drops
/// one-pixel strokes. Returns 1 when something was struck.
function brk_cx_glyph(_c, _ch, _x, _y, _px, _face) {
    var _s = string(_ch);
    if (string_length(_s) == 0 || !(_px > 0)) return 0;
    var _o = ord(string_char_at(_s, 1));
    if (_o <= 32 || _o > 126) return 0;
    var _m = _c.m, _k = brk_cx__scale(_c);
    var _f = brk_font_for(_face, _px * _k);
    var _sc = _px / _f.px;
    // the cell's top-left in USER space is the baseline point lifted by the ascent; both go through the transform
    var _p = brk_cx__pt(_c, _x, _y - _f.ascent * _sc);
    var _ang = -radtodeg(arctan2(_m[1], _m[0]));
    var _col = c_black, _a = _c.alpha;
    if (_c.fill.kind == 0) { _col = _c.fill.col; _a *= _c.fill.a; }
    else if (array_length(_c.fill.stops) > 0) { _col = _c.fill.stops[0][1]; _a *= _c.fill.stops[0][2]; }
    var _pf = draw_get_font(), _ph = draw_get_halign(), _pv = draw_get_valign(), _pa = draw_get_alpha(), _pc = draw_get_colour(), _pt = gpu_get_texfilter();
    draw_set_font(_f.font); draw_set_halign(fa_left); draw_set_valign(fa_top); draw_set_colour(_col); draw_set_alpha(_a);
    gpu_set_texfilter(true);
    draw_text_transformed(_p[0], _p[1], _s, _sc * _k, _sc * _k, _ang);
    gpu_set_texfilter(_pt);
    draw_set_font(_pf); draw_set_halign(_ph); draw_set_valign(_pv); draw_set_alpha(_pa); draw_set_colour(_pc);
    _c.counts.fill++;
    return 1;
}
