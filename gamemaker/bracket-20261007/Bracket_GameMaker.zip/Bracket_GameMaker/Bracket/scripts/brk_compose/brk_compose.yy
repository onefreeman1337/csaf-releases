{
  "$GMScript": "v1",
  "%Name": "brk_compose",
  "name": "brk_compose",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}