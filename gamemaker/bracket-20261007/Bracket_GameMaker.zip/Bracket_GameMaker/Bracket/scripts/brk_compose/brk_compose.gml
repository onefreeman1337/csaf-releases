/// brk_compose.gml - Bracket's geometry kit, part 1: the ten board outlines, their hanging proportions, the lettering band
/// and each board's measured name capacity. A port, line for line, of the RPG Maker MZ edition's BracketCompose.js (the
/// outline, runAt, letterBand and capacityOf sections). Pure: no drawing, no engine state beyond a restored epsilon.
///
/// Public functions: brk_outline, brk_aspect, brk_capacity_of.
///
/// ⛔ PORTING NOTES: every outline is ONE continuous run of [x, y] points in a box x -1..1, y 0..1 (top to foot); arc()
/// samples i / n inclusive, in the JS operation order; runAt pairs scanline crossings into SOLID runs (a notched board
/// crosses four times); comparisons run with math_set_epsilon(0) and the caller's epsilon is put back.

#macro BRK_PAPER_MIN 2.6
#macro BRK_PEN_FLOOR 0.9

/// @function brk_palette()
/// @description The sign palette by role (hex strings): oakLit, oakShadow, verdigris, oxblood, indigo, mustard, giltLit,
/// giltShadow, iron, rust, chalk, dusk.
/// @returns {Struct}
function brk_palette() {
    static _p = { oakLit: "#8b5a2b", oakShadow: "#4a2c14", verdigris: "#4f8a7a", oxblood: "#7a2e2b", indigo: "#2f3d6b", mustard: "#c9a227",
        giltLit: "#e8c860", giltShadow: "#8a6d1f", iron: "#2b2b2e", rust: "#8b4a2b", chalk: "#efe6d2", dusk: "#1c2431" };
    return _p;
}

/// @function brk__scheme_field(scheme)
/// @description Internal. The field colour a scheme paints, or undefined for bare timber (oak, giltOak, unknown).
function brk__scheme_field(_scheme) {
    var _P = brk_palette();
    switch (_scheme) { case "verdigris": return _P.verdigris; case "oxblood": return _P.oxblood; case "indigo": return _P.indigo; case "mustard": return _P.mustard; }
    return undefined;
}

/// @function brk_parse_hex(hex)
/// @description "#rrggbb" (or "rrggbb") to { r, g, b } 0..255; undefined for anything else (never NaN channels).
/// @param {String} hex
/// @returns {Struct|Undefined}
function brk_parse_hex(_hex) {
    if (!is_string(_hex)) return undefined;
    var _t = string_lower(string_trim(_hex));
    if (string_char_at(_t, 1) == "#") _t = string_delete(_t, 1, 1);
    if (string_length(_t) != 6) return undefined;
    var _n = 0;
    for (var _i = 1; _i <= 6; _i++) {
        var _c = ord(string_char_at(_t, _i)), _v = -1;
        if (_c >= 48 && _c <= 57) _v = _c - 48; else if (_c >= 97 && _c <= 102) _v = _c - 87;
        if (_v < 0) return undefined;
        _n = _n * 16 + _v;
    }
    return { r: (_n div 65536) mod 256, g: (_n div 256) mod 256, b: _n mod 256 };
}

/// @function brk__rgb_of(colour)
/// @description Internal. A real { r, g, b } (from a struct with finite channels or a hex string), or undefined.
function brk__rgb_of(_c) {
    if (is_string(_c)) return brk_parse_hex(_c);
    if (!is_struct(_c)) return undefined;
    var _r = _c[$ "r"], _g = _c[$ "g"], _b = _c[$ "b"];
    if (!is_numeric(_r) || !is_numeric(_g) || !is_numeric(_b)) return undefined;
    if (is_nan(_r) || is_nan(_g) || is_nan(_b) || is_infinity(_r) || is_infinity(_g) || is_infinity(_b)) return undefined;
    return _c;
}

/// @function brk__to_hex(colour)
/// @description Internal. { r, g, b } to "#rrggbb", each channel rounded (JS Math.round) and clamped.
function brk__to_hex(_c) {
    var _s = "#", _ch = [_c.r, _c.g, _c.b], _d = "0123456789abcdef";
    for (var _i = 0; _i < 3; _i++) { var _n = max(0, min(255, floor(_ch[_i] + 0.5))); _s += string_char_at(_d, (_n div 16) + 1) + string_char_at(_d, (_n mod 16) + 1); }
    return _s;
}

/// @function brk_lum(colour)
/// @description Relative luminance 0..1, gamma-expanded (WCAG); 0 for anything that is not a colour.
/// @param {Struct|String} colour
/// @returns {Real}
function brk_lum(_c) {
    var _s = brk__rgb_of(_c);
    if (is_undefined(_s)) return 0;
    var _v = [_s.r, _s.g, _s.b], _o = [0, 0, 0];
    for (var _i = 0; _i < 3; _i++) { var _t = _v[_i] / 255; _o[_i] = (_t <= 0.03928) ? _t / 12.92 : power((_t + 0.055) / 1.055, 2.4); }
    return 0.2126 * _o[0] + 0.7152 * _o[1] + 0.0722 * _o[2];
}

/// @function brk_ground_for(scheme)
/// @description The ground a scheme paints, always a real { r, g, b } (the lit oak when the scheme leaves timber bare).
/// @param {String} scheme
/// @returns {Struct}
function brk_ground_for(_scheme) {
    var _f = brk__rgb_of(brk__scheme_field(_scheme));
    if (!is_undefined(_f)) return _f;
    var _o = brk__rgb_of(brk_palette().oakLit);
    return is_undefined(_o) ? { r: 139, g: 90, b: 43 } : _o;
}

/// @function brk_contrast(a, b)
/// @description WCAG contrast ratio 1..21 between two colours.
/// @returns {Real}
function brk_contrast(_a, _b) {
    var _la = brk_lum(_a), _lb = brk_lum(_b);
    return (max(_la, _lb) + 0.05) / (min(_la, _lb) + 0.05);
}

/// @function brk_relief(colour, dir, min_delta)
/// @description Move a colour min_delta LEVELS lighter (dir >= 0) or darker, capped by the headroom of its tightest
/// channel: { r, g, b, delta, capped }.
/// @returns {Struct}
function brk_relief(_c, _dir, _minDelta) {
    var _s = brk__rgb_of(_c);
    if (is_undefined(_s)) _s = { r: 0, g: 0, b: 0 };
    var _want = max(0, min(255, brk__fin(_minDelta, 0)));
    var _d = (is_numeric(_dir) && _dir >= 0) ? 1 : -1;
    var _head = (_d > 0) ? min(255 - _s.r, 255 - _s.g, 255 - _s.b) : min(_s.r, _s.g, _s.b);
    var _got = min(_want, _head);
    return { r: _s.r + _d * _got, g: _s.g + _d * _got, b: _s.b + _d * _got, delta: _got, capped: _got < _want - 0.0001 };
}

/// @function brk_pick_contrast(ground, candidates, [want])
/// @description The first ink (in preference order) that clears the contrast bar on the ground, else the best one:
/// { ink, ratio, cleared }. Malformed inks are skipped, never drawn.
/// @returns {Struct}
function brk_pick_contrast(_bg, _cands, _want = 4.5) {
    var _bar = brk__fin(_want, 4.5);
    if (!(_bar > 1)) _bar = 4.5;
    var _best = undefined, _bestRatio = -1;
    var _ground = brk__rgb_of(_bg);
    if (is_undefined(_ground)) _ground = brk__rgb_of(brk_palette().oakLit);
    var _list = is_array(_cands) ? _cands : [];
    for (var _i = 0; _i < array_length(_list); _i++) {
        var _cand = brk__rgb_of(_list[_i]);
        if (is_undefined(_cand)) continue;
        var _r = brk_contrast(_ground, _cand);
        if (_r > _bestRatio) { _bestRatio = _r; _best = _cand; }
        if (_r >= _bar) return { ink: _cand, ratio: _r, cleared: true };
    }
    if (is_undefined(_best)) return { ink: brk__rgb_of(brk_palette().chalk), ratio: 0, cleared: false };
    return { ink: _best, ratio: _bestRatio, cleared: false };
}

#macro BRK_NAME_Y 0.745
#macro BRK_TRADE_Y 0.885
#macro BRK_NAME_SIZE 0.155
#macro BRK_TRADE_SIZE 0.085
#macro BRK_BOARD_INSET 0.06

/// @function brk__arc(cx, cy, rx, ry, a0, a1, n)
/// @description Internal. n + 1 points round an ellipse from a0 to a1 (radians), as the MZ arc().
function brk__arc(_cx, _cy, _rx, _ry, _a0, _a1, _n) {
    var _out = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _a0 + (_a1 - _a0) * (_i / _n);
        _out[_i] = [_cx + cos(_t) * _rx, _cy + sin(_t) * _ry];
    }
    return _out;
}

/// @function brk__concat(a, b)
/// @description Internal. Append every element of b to a (in place) and return a.
function brk__concat(_a, _b) { for (var _i = 0; _i < array_length(_b); _i++) array_push(_a, _b[_i]); return _a; }

/// @function brk_outline(board)
/// @description A board's outline as an array of [x, y] points, x -1..1 and y 0 (top) .. 1 (foot). An unknown board
/// id gives the plain hanging board.
/// @param {String} board heater, oval, lozenge, hanging, arch, banner, keyhole, barrelEnd, tankardCut or scrollEnd
/// @returns {Array<Array<Real>>}
function brk_outline(_board) {
    switch (_board) {
        case "heater": {
            var _p = [[-1, 0.02], [1, 0.02], [1, 0.42]];
            brk__concat(_p, brk__arc(0, 0.42, 1, 0.58, 0, pi / 2, 14));
            brk__concat(_p, brk__arc(0, 0.42, 1, 0.58, pi / 2, pi, 14));
            array_push(_p, [-1, 0.42]);
            return _p;
        }
        case "oval": return brk__arc(0, 0.5, 1, 0.5, -pi, pi, 48);
        case "lozenge": return [[0, 0], [0.55, 0.16], [1, 0.5], [0.55, 0.84], [0, 1], [-0.55, 0.84], [-1, 0.5], [-0.55, 0.16]];
        case "arch": {
            var _a = brk__arc(0, 0.46, 1, 0.46, pi, 2 * pi, 26);
            array_push(_a, [1, 1]); array_push(_a, [-1, 1]);
            return _a;
        }
        case "banner": return [[-1, 0], [1, 0], [1, 0.80], [0.62, 0.80], [0.62, 1], [0, 0.72], [-0.62, 1], [-0.62, 0.80], [-1, 0.80]];
        case "keyhole": {
            var _k = brk__arc(0, 0.34, 0.74, 0.34, pi, 2 * pi, 24);
            array_push(_k, [0.74, 0.46]); array_push(_k, [0.52, 0.62]);
            array_push(_k, [0.66, 1]); array_push(_k, [-0.66, 1]);
            array_push(_k, [-0.52, 0.62]); array_push(_k, [-0.74, 0.46]);
            return _k;
        }
        case "barrelEnd": {
            var _flat = 0.40;
            var _b = [[-_flat, 0.07], [_flat, 0.07]];
            brk__concat(_b, brk__arc(0, 0.5, 0.98, 0.43, -pi * 0.42 + 0, pi * 0.42, 18));   // the MZ adds a0 * 0
            array_push(_b, [_flat, 0.93]); array_push(_b, [-_flat, 0.93]);
            brk__concat(_b, brk__arc(0, 0.5, 0.98, 0.43, pi * 0.58, pi * 1.42, 18));
            return _b;
        }
        case "tankardCut": return [[-0.86, 0], [0.86, 0], [0.96, 0.10], [0.80, 0.16], [0.80, 0.84], [0.98, 0.92], [0.98, 1], [-0.98, 1], [-0.98, 0.92], [-0.80, 0.84], [-0.80, 0.16], [-0.96, 0.10]];
        case "scrollEnd": {
            var _roll = 0.30, _lip = 0.13;
            var _s = [[-1 + _roll, 0.06], [1 - _roll, 0.06]];
            brk__concat(_s, brk__arc(1 - _roll, 0.06 + _lip, _roll, _lip, -pi / 2, pi / 2, 12));
            brk__concat(_s, brk__arc(1 - _roll, 0.06 + _lip, _roll * 0.46, _lip * 0.46, pi / 2, -pi / 4, 8));
            array_push(_s, [1 - _roll, 0.30]);
            array_push(_s, [1 - _roll * 0.72, 0.94]);
            array_push(_s, [-1 + _roll * 0.72, 0.94]);
            array_push(_s, [-1 + _roll, 0.30]);
            brk__concat(_s, brk__arc(-1 + _roll, 0.06 + _lip, _roll * 0.46, _lip * 0.46, pi * 1.25, pi / 2, 8));
            brk__concat(_s, brk__arc(-1 + _roll, 0.06 + _lip, _roll, _lip, pi / 2, pi * 1.5, 12));
            return _s;
        }
    }
    // hanging, and any unknown id (the MZ `OUTLINE[board] || OUTLINE.hanging`)
    var _kk = 0.10;
    return [[-1 + _kk, 0], [1 - _kk, 0], [1, _kk * 1.6], [1, 1 - _kk * 1.6], [1 - _kk, 1], [-1 + _kk, 1], [-1, 1 - _kk * 1.6], [-1, _kk * 1.6]];
}

/// @function brk_aspect(board)
/// @description How wide a board hangs, as a multiple of its height (a shield stands tall, a scroll runs long).
/// @param {String} board
/// @returns {Real|Undefined} undefined for an unknown board
function brk_aspect(_board) {
    switch (_board) {
        case "heater": return 0.85; case "oval": return 1.50; case "lozenge": return 1.30; case "hanging": return 1.70;
        case "arch": return 1.15; case "banner": return 1.45; case "keyhole": return 0.80; case "barrelEnd": return 1.05;
        case "tankardCut": return 0.90; case "scrollEnd": return 1.80;
    }
    return undefined;
}

/// @function brk__run_at(points, y)
/// @description Internal. The widest SOLID run of the outline at height y: { left, right, width, runs, outer, outer_left,
/// outer_right }; width 0 outside. Crossings pair into runs, so a notch is never counted as board.
function brk__run_at(_pts, _y) {
    var _xs = [];
    var _n = array_length(_pts);
    for (var _i = 0; _i < _n; _i++) {
        var _a = _pts[_i], _b = _pts[(_i + 1) mod _n];
        var _y0 = _a[1], _y1 = _b[1];
        if (_y0 == _y1) continue;
        if ((_y >= _y0 && _y < _y1) || (_y >= _y1 && _y < _y0)) {
            var _t = (_y - _y0) / (_y1 - _y0);
            array_push(_xs, _a[0] + (_b[0] - _a[0]) * _t);
        }
    }
    if (array_length(_xs) < 2) return { left: 0, right: 0, width: 0, runs: 0, outer: 0, outer_left: 0, outer_right: 0 };
    array_sort(_xs, true);
    var _best = { left: _xs[0], right: _xs[1], width: _xs[1] - _xs[0] };
    var _runs = 0;
    for (var _k = 0; _k + 1 < array_length(_xs); _k += 2) {
        _runs++;
        var _w = _xs[_k + 1] - _xs[_k];
        // ⛔ an EXACT greater-than (brk__gt): the banner's two swallow tails are mirror images whose widths differ only by
        // rounding - below even math_set_epsilon(0)'s 1e-11 floor - and `>` under an epsilon kept the LEFT tail where the
        // MZ edition takes the RIGHT (8 of 215 drawings painted a grain streak on the other tail, MEASURED 2026-10-07).
        if (brk__gt(_w, _best.width)) _best = { left: _xs[_k], right: _xs[_k + 1], width: _w };
    }
    var _last = array_length(_xs) - 1;
    _best.runs = _runs; _best.outer = _xs[_last] - _xs[0]; _best.outer_left = _xs[0]; _best.outer_right = _xs[_last];
    return _best;
}

/// @function brk__letter_band(points, y_min, span)
/// @description Internal. Where the lettering can go on this outline: { solid_bottom, widest, name_y, trade_y }, the two
/// heights as shares of the SOLID board (a banner's swallow-tail is not board).
function brk__letter_band(_pts, _yMin, _span) {
    var _widest = 0;
    for (var _i = 0; _i <= 24; _i++) { var _w = brk__run_at(_pts, _yMin + _span * (_i / 24)).width; if (_w > _widest) _widest = _w; }
    var _sb = 1;
    for (var _k = 24; _k >= 0; _k--) {
        var _t = _k / 24;
        var _r = brk__run_at(_pts, _yMin + _span * _t);
        if (_r.width >= _widest * 0.5 && _r.left <= 0 && _r.right >= 0) { _sb = _t; break; }
        _sb = _t;
    }
    if (!(_sb > 0.2)) _sb = 1;
    return { solid_bottom: _sb, widest: _widest, name_y: BRK_NAME_Y * _sb, trade_y: BRK_TRADE_Y * _sb };
}

/// @function brk_capacity_of(board)
/// @description How many characters of the display face a board's name line takes, measured from the outline itself
/// (the solid run at the name line over the type size the board's height allows). The reader ranks boards by it.
/// @param {String} board
/// @returns {Real} at least 1
function brk_capacity_of(_board) {
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _pts = brk_outline(_board);
    var _yMin = infinity, _yMax = -infinity, _xMax = 0;
    for (var _i = 0; _i < array_length(_pts); _i++) {
        if (_pts[_i][1] < _yMin) _yMin = _pts[_i][1];
        if (_pts[_i][1] > _yMax) _yMax = _pts[_i][1];
        if (abs(_pts[_i][0]) > _xMax) _xMax = abs(_pts[_i][0]);
    }
    var _span = max(0.0001, _yMax - _yMin);
    var _aspect = brk_aspect(_board);
    if (!is_numeric(_aspect) || !(_aspect > 0)) _aspect = 1.35;
    var _halfPx = _aspect * 0.5;
    var _run = brk__run_at(_pts, _yMin + _span * brk__letter_band(_pts, _yMin, _span).name_y);
    var _px = max(0, _run.width * (_halfPx / ((_xMax != 0) ? _xMax : 1)) - BRK_BOARD_INSET * 2);
    var _cap = max(1, _px / (BRK_NAME_SIZE * 0.58));
    math_set_epsilon(_eps);
    return _cap;
}

/// @function brk__js_num_or0(value)
/// @description Internal. JS `Number(v) || 0`: a non-number, NaN, "" or 0 all give 0.
function brk__js_num_or0(_v) { var _n = brk__fin(_v, 0); return (_n == 0) ? 0 : _n; }

/// @function brk__gt(a, b)
/// @description Internal. a > b with NO epsilon. GameMaker compares reals under math_get_epsilon(), whose floor is 1e-11
/// even after math_set_epsilon(0), so two values a rounding error apart compare EQUAL; the difference is scaled far above
/// that floor first (any non-zero difference of two doubles of this product's magnitudes survives the scale).
/// @returns {Bool}
function brk__gt(_a, _b) { return (_a - _b) * 1000000000000000 > 0; }

/// @function brk_fit_repeat(span, ink, pitch, [interlock])
/// @description How many marks of width ink fit across span at the wanted pitch, with at least BRK_PAPER_MIN px of paper
/// between them (a chain, interlock true, may overlap): { count, pitch, floored }.
/// @returns {Struct}
function brk_fit_repeat(_span, _ink, _pitch, _interlock = false) {
    var _wanted = brk__fin(_pitch, -1);
    if (!(_wanted > 0)) _wanted = _ink + BRK_PAPER_MIN;
    var _minPitch = _interlock ? max(0.25, _ink * 0.25) : _ink + BRK_PAPER_MIN;
    var _p = max(_wanted, _minPitch);
    var _floored = _p > _wanted + 0.0001;
    var _n = floor((max(0, _span) - _ink) / _p) + 1;
    if (is_nan(_n) || is_infinity(_n) || _n < 0) _n = 0;
    return { count: _n, pitch: _p, floored: _floored };
}

/// @function brk_pen_for(w, h, [k])
/// @description A pen width for outlining one shape, from that shape's own box: max(BRK_PEN_FLOOR, min(w, h) * k), k 0.16.
/// @returns {Real}
function brk_pen_for(_w, _h, _k = 0.16) {
    var _kk = brk__fin(_k, -1);
    if (!(_kk > 0)) _kk = 0.16;
    return max(BRK_PEN_FLOOR, min(_w, _h) * _kk);
}

/// @function brk_weather(level)
/// @description What a weathering level 0..4 does, as numbers: { level, grainThrough, cornerWear, giltDull, rustDrop,
/// crack, linkGone }.
/// @returns {Struct}
function brk_weather(_level) {
    var _L = max(0, min(4, floor(brk__js_num_or0(_level) + 0.5)));
    var _grain = [0.08, 0.14, 0.21, 0.28, 0.35], _corner = [0.00, 0.04, 0.09, 0.15, 0.22], _gilt = [0.00, 0.12, 0.34, 0.58, 0.80], _rust = [0.0, 0.0, 0.9, 1.8, 3.0];
    return { level: _L, grainThrough: _grain[_L], cornerWear: _corner[_L], giltDull: _gilt[_L], rustDrop: _rust[_L],
        crack: (_L >= 3) ? ((_L == 4) ? 1.0 : 0.55) : 0, linkGone: (_L >= 4) ? 1 : 0 };
}

/// @function brk_paint_inset(board_w, board_h, weathering)
/// @description How far the paint is eaten back from the board's outline, in pixels (0 on a crisp sign).
/// @returns {Real}
function brk_paint_inset(_w, _h, _weathering) { return brk_weather(_weathering).cornerWear * min(_w, _h); }

/// @function brk_inset_polygon(points, cx, cy, px)
/// @description A new polygon, every point pulled px pixels toward (cx, cy) (never past it).
/// @returns {Array<Array<Real>>}
function brk_inset_polygon(_pts, _cx, _cy, _px) {
    var _out = array_create(array_length(_pts));
    for (var _i = 0; _i < array_length(_pts); _i++) {
        var _dx = _pts[_i][0] - _cx, _dy = _pts[_i][1] - _cy;
        var _d = sqrt(_dx * _dx + _dy * _dy);
        if (_d == 0) _d = 1;
        var _k = max(0, (_d - _px)) / _d;
        _out[_i] = [_cx + _dx * _k, _cy + _dy * _k];
    }
    return _out;
}

/// @function brk_pixel_run_at(points, y, cx)
/// @description The width of the run of a pixel-space polygon at height y that CONTAINS cx (0 when absent there).
/// @returns {Real}
function brk_pixel_run_at(_pts, _y, _cx) {
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _xs = [], _n = array_length(_pts), _w = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _pts[_i], _b = _pts[(_i + 1) mod _n];
        if (_a[1] == _b[1]) continue;
        if ((_y >= _a[1] && _y < _b[1]) || (_y >= _b[1] && _y < _a[1])) array_push(_xs, _a[0] + (_b[0] - _a[0]) * ((_y - _a[1]) / (_b[1] - _a[1])));
    }
    if (array_length(_xs) >= 2) {
        array_sort(_xs, true);
        for (var _k = 0; _k + 1 < array_length(_xs); _k += 2) if (_xs[_k] <= _cx && _xs[_k + 1] >= _cx) { _w = _xs[_k + 1] - _xs[_k]; break; }
    }
    math_set_epsilon(_eps);
    return _w;
}
