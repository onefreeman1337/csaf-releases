/// brk_render.gml - WHERE THE PIXELS HAPPEN: takes a sign's geometry and lands the oak, the paint, the gilt, the iron and the
/// weather; draws the trade mark, the lettering (straight or on the board's own arc), the dusk street of the Close Look and
/// the Signwright's Yard. Nothing here decides a position - every one comes from brk_geometry, which derives it from the
/// board's own outline. Nothing here is an image file.
///
/// Bracket - Shop Signs Composed from What the Shop Sells, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// This is the RPG Maker MZ edition's BracketRender.js, ported op for op onto the brk_canvas kit and HELD to it: the test
/// suite runs the MZ painter in Node over a recording canvas and compares every fill, stroke, rectangle, clip and glyph -
/// its colour, alpha, line width, caps and joins, the path it paints and the transform it paints under - against what this
/// file asks the kit to do (brk_oracle_draw). Text is measured from the faces' own advance table (brk_text_width), the same
/// table the oracle measures with, so every fitted name size is the original's.
///
/// ⛔ GameMaker evaluates a function call's ARGUMENTS RIGHT TO LEFT. Wherever the MZ code draws several numbers from the
/// street's generator, this file draws them into variables first, in the original's order.
///
/// Public functions (each documented below): brk_draw_sign, brk_draw_device, brk_draw_street, brk_draw_yard, brk_solve_grid,
/// brk_fit_line.

#macro BRK_STROKE_ROUND 1

// ---------------------------------------------------------------------------------------------------------------
// The test log (free unless ctx.brk_lg is a struct) and the path verbs that feed it. The log is HASHED as it is written
// (FNV-1a, the MZ hash, chunk by chunk), never built whole: a yard of 36 signs logs a quarter of a million characters.
// ---------------------------------------------------------------------------------------------------------------

/// @function brk__r100(v)
/// @description Internal. floor(v * 100 + 0.5), with -0 made 0 (the oracle's rounding).
function brk__r100(_v) { return floor(_v * 100 + 0.5) + 0; }

/// @function brk_log_begin(ctx, [keep])
/// @description Switch the test log on for a context: every paint event is hashed into ctx.brk_lg { h, len, events, keep }.
/// keep = how many leading characters to retain for a diagnostic (0 by default).
function brk_log_begin(_c, _keep = 0) { _c.brk_lg = { h: int64(2166136261), len: 0, events: 0, keep: _keep, text: "", n: 0, s: 0 }; }

/// @function brk_log_end(ctx)
/// @description The log's { events, len, hash, text } and the log switched off.
function brk_log_end(_c) {
    var _l = _c[$ "brk_lg"];
    if (!is_struct(_l)) return { events: 0, len: 0, hash: 0, text: "" };
    _c.brk_lg = undefined;
    return { events: _l.events, len: _l.len, hash: real(_l.h), text: _l.text };
}

function brk__logging(_c) { return is_struct(_c[$ "brk_lg"]); }
function brk__lg_emit(_c, _ev) {
    var _l = _c.brk_lg, _h = _l.h, _m = int64($FFFFFFFF), _p = int64(16777619);
    for (var _i = 1; _i <= string_length(_ev); _i++) _h = ((_h ^ int64(ord(string_char_at(_ev, _i)))) * _p) & _m;
    _l.h = _h; _l.len += string_length(_ev); _l.events += 1;
    if (string_length(_l.text) < _l.keep) _l.text += _ev;
}
function brk__lg_add(_c, _v) { if (brk__logging(_c)) _c.brk_lg.s += _v; }
function brk__lg_n(_c) { if (brk__logging(_c)) _c.brk_lg.n += 1; }

/// @function brk__lg_paint(paint)
/// @description Internal. A paint as the oracle writes it: "r,g,b:a" or "G<L|R><stops>@<geometry>:t,r,g,b,a/...".
function brk__lg_paint(_p) {
    if (_p.kind == 0) return string(colour_get_red(_p.col)) + "," + string(colour_get_green(_p.col)) + "," + string(colour_get_blue(_p.col)) + ":" + string(brk__r100(_p.a));
    var _geo = (_p.kind == 1) ? (_p.x0 + _p.y0 + _p.x1 + _p.y1) : (_p.x0 + _p.y0 + _p.r0 + _p.x1 + _p.y1 + _p.r1);
    var _s = "G" + ((_p.kind == 1) ? "L" : "R") + string(array_length(_p.stops)) + "@" + string(brk__r100(_geo)) + ":";
    for (var _i = 0; _i < array_length(_p.stops); _i++) {
        var _st = _p.stops[_i];
        _s += ((_i > 0) ? "/" : "") + string(brk__r100(_st[0])) + "," + string(colour_get_red(_st[1])) + "," + string(colour_get_green(_st[1])) + "," + string(colour_get_blue(_st[1])) + "," + string(brk__r100(_st[2]));
    }
    return _s;
}

/// @function brk__lg_t(ctx)
/// @description Internal. The current transform and alpha as the oracle writes them.
function brk__lg_t(_c) { var _m = _c.m; return string(brk__r100(_m[0])) + "," + string(brk__r100(_m[1])) + "," + string(brk__r100(_m[2])) + "," + string(brk__r100(_m[3])) + "," + string(brk__r100(_m[4])) + "," + string(brk__r100(_m[5])); }
function brk__lg_a(_c) { return ":a" + string(brk__r100(_c.alpha)); }

function brk__p_begin(_c) { brk_cx_begin(_c); if (brk__logging(_c)) { _c.brk_lg.n = 0; _c.brk_lg.s = 0; } }
function brk__p_move(_c, _x, _y) { if (brk__logging(_c)) { _c.brk_lg.n += 1; _c.brk_lg.s += _x; _c.brk_lg.s += _y; } brk_cx_move(_c, _x, _y); }
function brk__p_line(_c, _x, _y) { if (brk__logging(_c)) { _c.brk_lg.n += 1; _c.brk_lg.s += _x; _c.brk_lg.s += _y; } brk_cx_line(_c, _x, _y); }
function brk__p_quad(_c, _a, _b, _x, _y) { if (brk__logging(_c)) { _c.brk_lg.n += 1; _c.brk_lg.s += _a; _c.brk_lg.s += _b; _c.brk_lg.s += _x; _c.brk_lg.s += _y; } brk_cx_quad(_c, _a, _b, _x, _y); }
function brk__p_bez(_c, _a, _b, _cc, _d, _x, _y) { if (brk__logging(_c)) { _c.brk_lg.n += 1; _c.brk_lg.s += _a; _c.brk_lg.s += _b; _c.brk_lg.s += _cc; _c.brk_lg.s += _d; _c.brk_lg.s += _x; _c.brk_lg.s += _y; } brk_cx_bezier(_c, _a, _b, _cc, _d, _x, _y); }
function brk__p_close(_c) { if (brk__logging(_c)) _c.brk_lg.n += 1; brk_cx_close(_c); }
/// the canvas arc(x, y, r, a0, a1, [ccw])
function brk__p_arc(_c, _x, _y, _r, _a0, _a1, _ccw = false) {
    if (brk__logging(_c)) { _c.brk_lg.n += 1; _c.brk_lg.s += _x; _c.brk_lg.s += _y; _c.brk_lg.s += _r; _c.brk_lg.s += _a0; _c.brk_lg.s += _a1; }
    brk_cx_ellipse(_c, _x, _y, _r, _r, 0, _a0, _a1, _ccw);
}
/// the canvas ellipse(x, y, rx, ry, rot, a0, a1, [ccw])
function brk__p_ellipse(_c, _x, _y, _rx, _ry, _rot, _a0, _a1, _ccw = false) {
    if (brk__logging(_c)) { _c.brk_lg.n += 1; _c.brk_lg.s += _x; _c.brk_lg.s += _y; _c.brk_lg.s += _rx; _c.brk_lg.s += _ry; _c.brk_lg.s += _rot; _c.brk_lg.s += _a0; _c.brk_lg.s += _a1; }
    brk_cx_ellipse(_c, _x, _y, _rx, _ry, _rot, _a0, _a1, _ccw);
}
function brk__p_fill(_c, _evenodd = false) {
    if (brk__logging(_c)) brk__lg_emit(_c, (_evenodd ? "E" : "F") + brk__lg_paint(_c.fill) + ":" + string(_c.brk_lg.n) + ":" + string(brk__r100(_c.brk_lg.s)) + ":" + brk__lg_t(_c) + brk__lg_a(_c) + ";");
    if (_evenodd) brk_cx_fill_rule(_c, BRK_FILL_EVENODD); else brk_cx_fill(_c);
}
function brk__p_stroke(_c) {
    if (brk__logging(_c)) brk__lg_emit(_c, "S" + brk__lg_paint(_c.stroke) + ":" + string(brk__r100(_c.lw)) + ":" + ((_c.cap == 1) ? "r" : "b") + ((_c.join == 1) ? "r" : "m") + ":" + string(_c.brk_lg.n) + ":" + string(brk__r100(_c.brk_lg.s)) + ":" + brk__lg_t(_c) + brk__lg_a(_c) + ";");
    brk_cx_stroke(_c);
}
function brk__p_fill_rect(_c, _x, _y, _w, _h) {
    if (brk__logging(_c)) brk__lg_emit(_c, "R" + brk__lg_paint(_c.fill) + ":" + string(brk__r100(_x + _y + _w + _h)) + ":" + brk__lg_t(_c) + brk__lg_a(_c) + ";");
    brk_cx_fill_rect(_c, _x, _y, _w, _h);
}
/// a clip; even-odd and nonzero coincide in the kit's layer clip for every path this painter clips by (see brk_canvas)
function brk__p_clip(_c, _evenodd = false) {
    if (brk__logging(_c)) brk__lg_emit(_c, (_evenodd ? "D:" : "C:") + string(_c.brk_lg.n) + ":" + string(brk__r100(_c.brk_lg.s)) + ":" + brk__lg_t(_c) + ";");
    brk_cx_clip(_c);
}
/// one glyph, baseline at (x, y), left-aligned (align 0) or centred on x (align 1), at an integer px, in a face
function brk__p_text(_c, _ch, _x, _y, _px, _face, _align) {
    if (brk__logging(_c)) brk__lg_emit(_c, "T" + brk__lg_paint(_c.fill) + ":" + string(ord(_ch)) + ":" + string(brk__r100(_x + _y)) + ":" + string(_px) + ":" + string(_face) + ":" + ((_align == 1) ? "c" : "l") + ":" + brk__lg_t(_c) + brk__lg_a(_c) + ";");
    var _xx = (_align == 1) ? _x - brk_text_width(_ch, _px, _face) / 2 : _x;
    return brk_cx_glyph(_c, _ch, _xx, _y, _px, _face);
}

// ---------------------------------------------------------------------------------------------------------------
// The canvas filter blur(px), as a LAYER: what is drawn until brk__p_blur_end goes into a transparent surface, which is
// then softened (taken down to 1/f size and back up, filtered) and composited, premultiplied, onto the target.
// ---------------------------------------------------------------------------------------------------------------

function brk__p_blur_begin(_c, _px) {
    if (brk__logging(_c)) brk__lg_emit(_c, "B" + string(brk__r100(_px)) + ";");
    var _tgt = surface_get_target();
    if (!variable_struct_exists(_c, "blurs")) _c.blurs = [];
    if (_tgt == -1 || !surface_exists(_tgt)) { array_push(_c.blurs, undefined); return; }
    var _w = surface_get_width(_tgt), _h = surface_get_height(_tgt);
    var _lay = surface_create(_w, _h);
    surface_set_target(_lay);
    draw_clear_alpha(c_black, 0);
    array_push(_c.blurs, { layer: _lay, w: _w, h: _h, f: max(2, round(_px * brk_cx__scale(_c) * 1.4)) });
}
function brk__p_blur_end(_c) {
    if (!variable_struct_exists(_c, "blurs") || array_length(_c.blurs) == 0) return;
    var _b = array_pop(_c.blurs);
    if (!is_struct(_b) || !surface_exists(_b.layer)) return;
    surface_reset_target();
    var _sw = max(1, ceil(_b.w / _b.f)), _sh = max(1, ceil(_b.h / _b.f));
    var _small = surface_create(_sw, _sh);
    var _pt = gpu_get_texfilter();
    gpu_push_state();
    gpu_set_texfilter(true);
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    surface_set_target(_small);
    draw_clear_alpha(c_black, 0);
    draw_surface_ext(_b.layer, 0, 0, _sw / _b.w, _sh / _b.h, 0, c_white, 1);
    surface_reset_target();
    draw_surface_ext(_small, 0, 0, _b.w / _sw, _b.h / _sh, 0, c_white, 1);
    gpu_pop_state();
    gpu_set_texfilter(_pt);
    surface_free(_small);
    surface_free(_b.layer);
}

// ---------------------------------------------------------------------------------------------------------------
// Colour and small geometry helpers
// ---------------------------------------------------------------------------------------------------------------

/// a solid paint from a { r, g, b } (channels rounded and clamped exactly as the MZ toHex rounds them), alpha a
function brk__ink(_s, _a = 1) { return brk_cx_solid([_s.r, _s.g, _s.b], _a); }
/// a solid paint from "#rrggbb"
function brk__ink_hex(_hex, _a = 1) { var _s = brk_parse_hex(_hex); if (is_undefined(_s)) _s = { r: 0, g: 0, b: 0 }; return brk_cx_solid([_s.r, _s.g, _s.b], _a); }
/// JS String(text || ''): undefined, "", 0 and false give "", anything else its string
function brk__js_text(_v) {
    if (is_undefined(_v)) return "";
    if (is_string(_v)) return _v;
    if (is_numeric(_v) && (_v == 0 || is_nan(_v))) return "";
    return string(_v);
}
/// whether a device primitive is a counter (a groove cut into the mass)
function brk__is_counter(_p) { var _k = _p[$ "ink"]; return is_string(_k) && _k == "counter"; }
/// JS Number(v.toFixed(d)) for a non-negative v
function brk__fixed(_v, _d) { var _k = power(10, _d); return floor(_v * _k + 0.5) / _k; }
/// the mix of the gilt toward its shadow by the weather's dulling
function brk__dulled(_w) {
    var _gl = brk_parse_hex(brk_palette().giltLit), _gs = brk_parse_hex(brk_palette().giltShadow), _d = _w.giltDull;
    return { r: _gl.r + (_gs.r - _gl.r) * _d, g: _gl.g + (_gs.g - _gl.g) * _d, b: _gl.b + (_gs.b - _gl.b) * _d };
}

/// trace a closed polygon (reverse = wound the other way, for an even-odd hole)
function brk__trace_poly(_c, _pts, _reverse = false) {
    var _n = array_length(_pts);
    if (_n == 0) return;
    if (_reverse) {
        brk__p_move(_c, _pts[_n - 1][0], _pts[_n - 1][1]);
        for (var _i = _n - 2; _i >= 0; _i--) brk__p_line(_c, _pts[_i][0], _pts[_i][1]);
    } else {
        brk__p_move(_c, _pts[0][0], _pts[0][1]);
        for (var _j = 1; _j < _n; _j++) brk__p_line(_c, _pts[_j][0], _pts[_j][1]);
    }
    brk__p_close(_c);
}

/// the board's outline in pixels at an origin
function brk__board_pixels(_g, _ox, _oy) {
    var _n = array_length(_g.outline), _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) _out[_i] = [_ox + brk__geo_bx(_g, _g.outline[_i][0]), _oy + brk__geo_by(_g, _g.outline[_i][1])];
    return _out;
}

/// a shifted copy of a polygon
function brk__offset_polygon(_pts, _dx, _dy) {
    var _n = array_length(_pts), _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) _out[_i] = [_pts[_i][0] + _dx, _pts[_i][1] + _dy];
    return _out;
}

/// a thick line as a quad with square ends
function brk__bar_path(_c, _x0, _y0, _x1, _y1, _w) {
    var _dx = _x1 - _x0, _dy = _y1 - _y0;
    var _len = sqrt(_dx * _dx + _dy * _dy);
    if (_len == 0 || is_nan(_len)) _len = 1;
    var _nx = -_dy / _len * (_w / 2), _ny = _dx / _len * (_w / 2);
    brk__p_move(_c, _x0 + _nx, _y0 + _ny);
    brk__p_line(_c, _x1 + _nx, _y1 + _ny);
    brk__p_line(_c, _x1 - _nx, _y1 - _ny);
    brk__p_line(_c, _x0 - _nx, _y0 - _ny);
    brk__p_close(_c);
}

/// an annulus sector (the horseshoe's stock)
function brk__ring_path(_c, _cx, _cy, _rx, _ry, _w, _a0, _a1) {
    var _n = 26;
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _a0 + (_a1 - _a0) * (_i / _n);
        var _x = _cx + cos(_t) * (_rx + _w / 2), _y = _cy + sin(_t) * (_ry + _w / 2);
        if (_i == 0) brk__p_move(_c, _x, _y); else brk__p_line(_c, _x, _y);
    }
    for (var _k = _n; _k >= 0; _k--) {
        var _t2 = _a0 + (_a1 - _a0) * (_k / _n);
        brk__p_line(_c, _cx + cos(_t2) * (_rx - _w / 2), _cy + sin(_t2) * (_ry - _w / 2));
    }
    brk__p_close(_c);
}

// ---------------------------------------------------------------------------------------------------------------
// The trade mark
// ---------------------------------------------------------------------------------------------------------------

/// @function brk_draw_device(ctx, id, cx, cy, w, h, ink, counter_ink)
/// @description Draw one trade mark as a single silhouette centred on (cx, cy), fitted to w x h by its own measured bounds.
/// The mass and its holes are ONE path filled once even-odd; the grooves cut INTO it (facets, slashes, hoops) are clipped
/// to the mass and filled in the counter ink. Inks are { r, g, b } or "#rrggbb". Returns how many primitives were drawn
/// (0 = an unknown id, which draws nothing).
/// @param {Struct} ctx A brk_canvas context (brk_cx_create)
/// @param {String} id A device id
/// @returns {Real}
function brk_draw_device(_c, _id, _cx, _cy, _w, _h, _ink, _counterInk) {
    var _prims = brk_device_prims(_id);
    if (array_length(_prims) == 0 || !is_struct(_c)) return 0;
    if (!is_numeric(_cx) || !is_numeric(_cy) || !is_numeric(_w) || !is_numeric(_h) || is_nan(_cx) || is_nan(_cy) || is_nan(_w) || is_nan(_h) || is_infinity(_w) || is_infinity(_h)) return 0;
    // an ink is "#rrggbb" or { r, g, b }; anything else falls back to the oak's own dark (never a dereference of a number)
    if (!is_string(_ink) && !(is_struct(_ink) && is_numeric(_ink[$ "r"]) && is_numeric(_ink[$ "g"]) && is_numeric(_ink[$ "b"]))) _ink = "#3a2416";
    if (!is_string(_counterInk) && !(is_struct(_counterInk) && is_numeric(_counterInk[$ "r"]) && is_numeric(_counterInk[$ "g"]) && is_numeric(_counterInk[$ "b"]))) _counterInk = "#1a120c";
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _b = brk_device_bounds(_id);
    var _sx = _w / ((_b.w != 0 && !is_nan(_b.w)) ? _b.w : 1), _sy = _h / ((_b.h != 0 && !is_nan(_b.h)) ? _b.h : 1);
    var _bcx = (_b.minX + _b.maxX) / 2, _bcy = (_b.minY + _b.maxY) / 2;
    var _sBar = min(_sx, _sy);
    var _inkP = is_string(_ink) ? brk__ink_hex(_ink) : brk__ink(_ink);
    var _ctrP = is_string(_counterInk) ? brk__ink_hex(_counterInk) : brk__ink(_counterInk);
    var _drawn = 0;
    brk_cx_save(_c);
    _c.fill = _inkP;
    brk__p_begin(_c);
    for (var _i = 0; _i < array_length(_prims); _i++) {
        var _p = _prims[_i], _t = _p.t;
        if (_t == "poly") {
            var _pts = array_create(array_length(_p.pts));
            for (var _k = 0; _k < array_length(_p.pts); _k++) _pts[_k] = [_cx + (_p.pts[_k][0] - _bcx) * _sx, _cy + (_p.pts[_k][1] - _bcy) * _sy];
            brk__trace_poly(_c, _pts); _drawn++;
        } else if (_t == "circ") {
            var _X = _cx + (_p.x - _bcx) * _sx, _Y = _cy + (_p.y - _bcy) * _sy;
            brk__p_move(_c, _X + _p.r * _sx, _Y);
            brk__p_ellipse(_c, _X, _Y, _p.r * _sx, _p.r * _sy, 0, 0, pi * 2);
            _drawn++;
        } else if (_t == "bar" && !brk__is_counter(_p)) {
            brk__bar_path(_c, _cx + (_p.a[0] - _bcx) * _sx, _cy + (_p.a[1] - _bcy) * _sy, _cx + (_p.b[0] - _bcx) * _sx, _cy + (_p.b[1] - _bcy) * _sy, _p.w * _sBar); _drawn++;
        } else if (_t == "ring") {
            brk__ring_path(_c, _cx + (_p.x - _bcx) * _sx, _cy + (_p.y - _bcy) * _sy, _p.r * _sx, _p.r * _sy, _p.w * _sBar, _p.a0, _p.a1); _drawn++;
        } else if (_t == "cut") {
            if (!is_undefined(_p[$ "circ"]) && _p.circ) {
                var _X2 = _cx + (_p.x - _bcx) * _sx, _Y2 = _cy + (_p.y - _bcy) * _sy;
                brk__p_move(_c, _X2 + _p.r * _sx, _Y2);
                brk__p_ellipse(_c, _X2, _Y2, _p.r * _sx, _p.r * _sy, 0, pi * 2, 0, true);
            } else {
                var _cpts = array_create(array_length(_p.pts));
                for (var _m = 0; _m < array_length(_p.pts); _m++) _cpts[_m] = [_cx + (_p.pts[_m][0] - _bcx) * _sx, _cy + (_p.pts[_m][1] - _bcy) * _sy];
                brk__trace_poly(_c, _cpts, true);
            }
            _drawn++;
        }
    }
    brk__p_fill(_c, true);
    // pass two: the counters - grooves cut INTO the mass, clipped to it (the path above is still current)
    var _counters = [];
    for (var _q = 0; _q < array_length(_prims); _q++) if (_prims[_q].t == "bar" && brk__is_counter(_prims[_q])) array_push(_counters, _prims[_q]);
    if (array_length(_counters) > 0) {
        brk__p_clip(_c, true);
        _c.fill = _ctrP;
        for (var _r = 0; _r < array_length(_counters); _r++) {
            var _cb = _counters[_r];
            brk__p_begin(_c);
            brk__bar_path(_c, _cx + (_cb.a[0] - _bcx) * _sx, _cy + (_cb.a[1] - _bcy) * _sy, _cx + (_cb.b[0] - _bcx) * _sx, _cy + (_cb.b[1] - _bcy) * _sy, _cb.w * _sBar);
            brk__p_fill(_c);
            _drawn++;
        }
    }
    brk_cx_restore(_c);
    math_set_epsilon(_eps);
    return _drawn;
}

// ---------------------------------------------------------------------------------------------------------------
// The board: oak, then pigment as a LAYER, then grain over the pigment, then the board's own edges and the keyline
// ---------------------------------------------------------------------------------------------------------------

function brk__paint_board(_c, _g, _p, _ox, _oy) {
    var _P = brk_palette();
    var _w = brk_weather(_p[$ "weathering"]);
    var _pts = brk__board_pixels(_g, _ox, _oy);
    var _oakLit = brk__rgb_of(_P.oakLit), _oakDark = brk__rgb_of(_P.oakShadow);
    var _counts = { grainStrokes: 0, paintBands: 0, wornCorners: 0 };

    brk_cx_save(_c);
    brk__p_begin(_c); brk__trace_poly(_c, _pts); brk__p_clip(_c);

    // the timber
    var _grad = brk_cx_linear(_c, _ox, _oy, _ox, _oy + _g.boardH);
    var _r1 = brk_relief(_oakLit, 1, 16), _r2 = brk_relief(_oakLit, -1, 22);
    brk_cx_stop(_grad, 0, [_r1.r, _r1.g, _r1.b], 1);
    brk_cx_stop(_grad, 0.62, [_oakLit.r, _oakLit.g, _oakLit.b], 1);
    brk_cx_stop(_grad, 1, [_r2.r, _r2.g, _r2.b], 1);
    _c.fill = _grad;
    brk__p_fill_rect(_c, _ox - 2, _oy - 2, _g.boardW + 4, _g.boardH + 4);

    // the pigment, as a LAYER
    var _field = brk__scheme_field(_p[$ "scheme"]);
    var _fieldRgb = brk__rgb_of(_field);
    if (!is_undefined(_fieldRgb)) {
        var _wear = brk_paint_inset(_g.boardW, _g.boardH, _p[$ "weathering"]);
        var _inner = brk_inset_polygon(_pts, _ox + _g.boardW / 2, _oy + _g.boardH / 2, _wear);
        // the cast shadow FIRST, on the bare oak beside the paint
        brk_cx_save(_c);
        brk__p_begin(_c); brk__trace_poly(_c, brk__offset_polygon(_inner, 1.5, 2.0));
        _c.fill = brk_cx_solid([20, 12, 6], 0.34);
        brk__p_fill(_c);
        brk_cx_restore(_c);

        brk_cx_save(_c);
        brk__p_begin(_c); brk__trace_poly(_c, _inner); brk__p_clip(_c);
        _c.fill = brk__ink(_fieldRgb);
        brk__p_fill_rect(_c, _ox - 2, _oy - 2, _g.boardW + 4, _g.boardH + 4);
        // the lit lip, upper-left, and the shadowed one, lower-right
        var _lip = max(1, min(_g.boardW, _g.boardH) * 0.018);
        _c.stroke = brk__ink(brk_relief(_fieldRgb, 1, 34));
        _c.lw = _lip;
        brk__p_begin(_c); brk__trace_poly(_c, brk__offset_polygon(_inner, -0.6, -0.8)); brk__p_stroke(_c);
        _c.stroke = brk__ink(brk_relief(_fieldRgb, -1, 30));
        brk__p_begin(_c); brk__trace_poly(_c, brk__offset_polygon(_inner, 0.6, 0.9)); brk__p_stroke(_c);
        brk_cx_restore(_c);
        _counts.paintBands = 1;
        _counts.wornCorners = (_wear > 0.5) ? array_length(_inner) : 0;
    }

    // the grain, LAID LAST so the timber shows THROUGH the paint; pitch declared, count derived
    var _gr = _g.grain;
    var _through = !is_undefined(_fieldRgb) ? _w.grainThrough : 0.55;
    for (var _i = 0; _i < _gr.count; _i++) {
        var _y = _oy + _i * _gr.pitch + _gr.pitch * 0.5;
        var _yb = _g.yMin + ((_y - _oy) / _g.boardH) * _g.span;
        var _run = brk__run_at(_g.outline, _yb);
        if (_run.width <= 0.01) continue;
        var _x0 = _ox + brk__geo_bx(_g, _run.left), _x1 = _ox + brk__geo_bx(_g, _run.right);
        var _dark = (_i mod 3 == 0);
        _c.stroke = _dark ? brk_cx_solid([58, 32, 14], brk__fixed(0.34 * _through + 0.10, 3)) : brk_cx_solid([196, 146, 92], brk__fixed(0.26 * _through + 0.07, 3));
        _c.lw = _g.grainInk * (_dark ? 1.0 : 0.7);
        brk__p_begin(_c);
        // a streak wanders: three segments, never a ruled line
        brk__p_move(_c, _x0, _y);
        brk__p_bez(_c, _x0 + (_x1 - _x0) * 0.33, _y + _g.grainInk * 0.9, _x0 + (_x1 - _x0) * 0.66, _y - _g.grainInk * 1.1, _x1, _y + _g.grainInk * 0.3);
        brk__p_stroke(_c);
        _counts.grainStrokes++;
    }
    brk_cx_restore(_c);

    // the board's own edges, outside the clip so they read as thickness
    var _pen = brk_pen_for(_g.boardW, _g.boardH, 0.012);
    brk_cx_save(_c);
    _c.join = BRK_STROKE_ROUND;
    _c.stroke = brk__ink(brk_relief(_oakLit, 1, 40));
    _c.lw = max(2, _pen);
    brk__p_begin(_c); brk__trace_poly(_c, brk__offset_polygon(_pts, 0, -_pen * 0.8)); brk__p_stroke(_c);
    _c.stroke = brk__ink(brk_relief(_oakDark, -1, 18));
    _c.lw = max(3, _pen * 1.5);
    brk__p_begin(_c); brk__trace_poly(_c, brk__offset_polygon(_pts, 0, _pen * 1.1)); brk__p_stroke(_c);
    brk_cx_restore(_c);

    // the chalk keyline, on painted boards only
    if (!is_undefined(_fieldRgb)) {
        brk_cx_save(_c);
        _c.stroke = brk_cx_solid([239, 230, 210], brk__fixed(0.62 - _w.level * 0.11, 2));
        _c.lw = max(1, _g.boardH * 0.006);
        var _key = brk_inset_polygon(_pts, _ox + _g.boardW / 2, _oy + _g.boardH / 2, _g.keylineInset);
        brk__p_begin(_c); brk__trace_poly(_c, _key); brk__p_stroke(_c);
        brk_cx_restore(_c);
    }
    return _counts;
}

// ---------------------------------------------------------------------------------------------------------------
// Lettering
// ---------------------------------------------------------------------------------------------------------------

/// @function brk_fit_line(text, size, face, max_w, tracking)
/// @description Set a line of type to a measured width: surrender the tracking first (it is decoration, the words are
/// not), then SOLVE the size (type width is very nearly linear in size), then a few bounded refinements. Never below 5 px.
/// Returns { size, tracking, squeeze, width, fits } - fits is false when even the floor is too wide, so a caller is told.
/// @param {String} text
/// @param {Real} size Declared size in px
/// @param {Real} face BRK_FACE_DISPLAY or BRK_FACE_BODY
/// @param {Real} max_w The measured run available, px
/// @param {Real} tracking Extra per character, as a fraction of size
/// @returns {Struct}
function brk_fit_line(_text, _size, _face, _maxW, _tracking) {
    // a size, width or tracking that is not a finite number cannot be fitted: refused as { fits: false } with zeros
    var _num = function(_v) { return is_numeric(_v) && !is_nan(_v) && !is_infinity(_v); };
    if (!_num(_size) || !_num(_maxW) || !_num(_tracking)) return { size: 0, tracking: 0, squeeze: 0, width: 0, fits: false };
    _tracking = clamp(_tracking, -1, 2);
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _t = brk__js_text(_text);
    var _n = string_length(_t);
    var _tr = _tracking, _s = _size, _FLOOR = 5;
    var _wpx = brk_text_width(_t, floor(_s + 0.5), _face) + max(0, _n - 1) * _s * _tr;
    while (_wpx > _maxW && _tr > 0) { _tr = max(0, _tr - 0.01); _wpx = brk_text_width(_t, floor(_s + 0.5), _face) + max(0, _n - 1) * _s * _tr; }
    if (_wpx > _maxW && _s > _FLOOR) {
        _s = max(_FLOOR, _s * (_maxW / _wpx));
        _wpx = brk_text_width(_t, floor(_s + 0.5), _face) + max(0, _n - 1) * _s * _tr;
        for (var _i = 0; _i < 24 && _wpx > _maxW && _s > _FLOOR; _i++) {
            // never shrink by less than a rounding step, or the rounded size stands still
            _s = max(_FLOOR, min(_s - 0.5, _s * (_maxW / _wpx)));
            _wpx = brk_text_width(_t, floor(_s + 0.5), _face) + max(0, _n - 1) * _s * _tr;
        }
    }
    var _res = { size: _s, tracking: _tr, squeeze: _s / _size, width: _wpx, fits: _wpx <= _maxW + 0.5 };
    math_set_epsilon(_eps);
    return _res;
}

/// strike a line letter by letter so the tracking is real; returns glyphs struck
function brk__strike_tracked(_c, _text, _cx, _y, _fit, _face) {
    var _t = brk__js_text(_text);
    var _px = floor(_fit.size + 0.5);
    var _extra = _fit.size * _fit.tracking;
    var _n = string_length(_t);
    var _total = brk_text_width(_t, _px, _face) + max(0, _n - 1) * _extra;
    var _x = _cx - _total / 2;
    var _k = 0;
    for (var _i = 1; _i <= _n; _i++) {
        var _ch = string_char_at(_t, _i);
        brk__p_text(_c, _ch, _x, _y, _px, _face, 0);
        _x += brk_text_width(_ch, _px, _face) + _extra;
        _k++;
    }
    return _k;
}

/// strike a line on an arc whose depth (the sagitta of the chord) is declared, so a long name arcs gently
function brk__strike_arc(_c, _text, _cx, _cy, _depth, _fit, _face) {
    var _t = brk__js_text(_text);
    var _px = floor(_fit.size + 0.5);
    var _extra = _fit.size * _fit.tracking;
    var _n = string_length(_t), _widths = array_create(_n), _total = 0;
    for (var _i = 0; _i < _n; _i++) { var _cw = brk_text_width(string_char_at(_t, _i + 1), _px, _face) + _extra; _widths[_i] = _cw; _total += _cw; }
    var _dn = brk__js_num_or0(_depth);
    var _d = max(0.5, (_dn == 0) ? 1 : _dn);
    var _r = (_total * _total / 4 + _d * _d) / (2 * _d);
    var _span = _total / _r;
    _cy = _cy + _r;
    var _a = -pi / 2 - _span / 2;
    var _k = 0;
    for (var _j = 0; _j < _n; _j++) {
        var _step = _widths[_j] / _r;
        _a += _step / 2;
        brk_cx_save(_c);
        brk_cx_translate(_c, _cx + cos(_a) * _r, _cy + sin(_a) * _r);
        brk_cx_rotate(_c, _a + pi / 2);
        brk__p_text(_c, string_char_at(_t, _j + 1), 0, 0, _px, _face, 1);
        brk_cx_restore(_c);
        _a += _step / 2;
        _k++;
    }
    return _k;
}

/// the name, straight or on the board's own arc
function brk__strike(_c, _g, _p, _cx, _y, _fit, _face) {
    if (!_g.name.arc) return brk__strike_tracked(_c, _p[$ "name"], _cx, _y, _fit, _face);
    return brk__strike_arc(_c, _p[$ "name"], _cx, _y, _g.boardH * 0.045, _fit, _face);
}

/// the lettering: carved into bare oak, or gilt on paint; the relief direction is SOLVED, not assumed
function brk__letter_board(_c, _g, _p, _ox, _oy) {
    var _P = brk_palette();
    var _w = brk_weather(_p[$ "weathering"]);
    var _field = brk__scheme_field(_p[$ "scheme"]);
    var _ground = brk_ground_for(_p[$ "scheme"]);
    var _gilt = !is_undefined(_field) || _p[$ "scheme"] == "giltOak";
    var _cx = _ox + _g.boardW / 2;
    var _nameY = _oy + brk__geo_by(_g, _g.yMin + _g.span * _g.name.y);
    var _tradeY = _oy + brk__geo_by(_g, _g.yMin + _g.span * _g.trade.y);
    var _fit = brk_fit_line(_p[$ "name"], _g.name.size, BRK_FACE_DISPLAY, _g.name.w, 0.06);
    var _glyphs = 0, _ratio = 0;
    brk_cx_save(_c);
    if (_gilt) {
        // GILT: a dulled gold, with a highlight up-left and a one-pixel drop
        var _lit = brk__dulled(_w);
        var _pick = brk_pick_contrast(_ground, [_lit, brk_parse_hex(_P.chalk), { r: 24, g: 18, b: 12 }], 3.2);
        var _drop = max(1, _g.name.size * 0.045);
        _c.fill = brk__ink(brk_relief(_ground, -1, 40));
        _glyphs += brk__strike(_c, _g, _p, _cx, _nameY + _drop, _fit, BRK_FACE_DISPLAY);
        _c.fill = brk__ink(_pick.ink);
        _glyphs += brk__strike(_c, _g, _p, _cx, _nameY, _fit, BRK_FACE_DISPLAY);
        var _hi = brk_relief(_pick.ink, 1, 46);
        _c.alpha = 0.55;
        _c.fill = brk__ink(_hi);
        _glyphs += brk__strike(_c, _g, _p, _cx - _drop * 0.7, _nameY - _drop * 0.7, _fit, BRK_FACE_DISPLAY);
        _c.alpha = 1;
        _ratio = _pick.ratio;
    } else {
        // CARVED: a dark inner shadow up-left and a light bevel down-right, the letter in the timber's own colour
        var _cut = brk_relief(_ground, -1, 52);
        var _bevel = brk_relief(_ground, 1, 44);
        var _step = max(1, _g.name.size * 0.05);
        _c.fill = brk__ink(_bevel);
        _glyphs += brk__strike(_c, _g, _p, _cx + _step, _nameY + _step, _fit, BRK_FACE_DISPLAY);
        _c.fill = brk__ink(_cut);
        _glyphs += brk__strike(_c, _g, _p, _cx - _step * 0.5, _nameY - _step * 0.5, _fit, BRK_FACE_DISPLAY);
        // the letter body's separation rises with weathering, because the grain noise does
        _c.fill = brk__ink(brk_relief(_ground, -1, 22 + _w.level * 7));
        _glyphs += brk__strike(_c, _g, _p, _cx, _nameY, _fit, BRK_FACE_DISPLAY);
        _ratio = brk_contrast(_ground, _cut);
    }
    // the trade, in the body face, quieter than the name by design
    var _trade = _p[$ "trade"];
    if (is_string(_trade) && _trade != "") {
        var _tfit = brk_fit_line(_trade, _g.trade.size, BRK_FACE_BODY, _g.trade.w, 0.14);
        var _tInk = brk_pick_contrast(_ground, [brk_parse_hex(_P.chalk), { r: 28, g: 20, b: 14 }, brk_parse_hex(_P.giltLit)], 3.0);
        _c.alpha = 0.86;
        _c.fill = brk__ink(_tInk.ink);
        _glyphs += brk__strike_tracked(_c, _trade, _cx, _tradeY, _tfit, BRK_FACE_BODY);
        _c.alpha = 1;
    }
    brk_cx_restore(_c);
    return { glyphs: _glyphs, squeeze: _fit.squeeze, ratio: _ratio, gilt: _gilt, fits: _fit.fits };
}

// ---------------------------------------------------------------------------------------------------------------
// Ironwork: the plate and its nails, the ornaments, the brace, the tapered arm and its finial, leaves, rings, chain, rust
// ---------------------------------------------------------------------------------------------------------------

/// a run of spine points (x a share of the reach, y a share of the iron height), stroked
function brk__iron_run(_c, _I, _pts, _lw, _ink, _dx, _dy) {
    if (!is_array(_pts) || array_length(_pts) < 2) return;
    _c.stroke = _ink; _c.lw = _lw;
    brk__p_begin(_c);
    for (var _i = 0; _i < array_length(_pts); _i++) {
        var _sx = _I.wallX + _pts[_i][0] * _I.reach + _dx, _sy = _I.topY + _pts[_i][1] * _I.ironH + _dy;
        if (_i == 0) brk__p_move(_c, _sx, _sy); else brk__p_line(_c, _sx, _sy);
    }
    brk__p_stroke(_c);
}
/// an ornament anchored on the arm, in IRON-HEIGHT units in BOTH axes (never stretched)
function brk__iron_unit(_c, _I, _ax, _ay, _pts, _lw, _ink, _dx, _dy) {
    if (!is_array(_pts) || array_length(_pts) < 2) return;
    _c.stroke = _ink; _c.lw = _lw;
    brk__p_begin(_c);
    for (var _i = 0; _i < array_length(_pts); _i++) {
        var _ux = _ax + _pts[_i][0] * _I.ironH + _dx, _uy = _ay + _pts[_i][1] * _I.ironH + _dy;
        if (_i == 0) brk__p_move(_c, _ux, _uy); else brk__p_line(_c, _ux, _uy);
    }
    brk__p_stroke(_c);
}

function brk__draw_iron(_c, _g, _p, _wallX, _topY, _reach, _behind) {
    var _P = brk_palette();
    var _w = brk_weather(_p[$ "weathering"]);
    // NEVER A HARD-CODED INK: the iron's VALUE is lifted until it separates from the ground it is seen against
    var _ground = brk__rgb_of(_behind);
    if (is_undefined(_ground)) _ground = brk__rgb_of(_P.dusk);
    var _base = brk__rgb_of(_P.iron);
    var _lifted = brk_relief(_base, (brk_lum(_ground) > brk_lum(_base)) ? -1 : 1, 48);
    var _iron = { r: _lifted.r, g: _lifted.g, b: _lifted.b };
    var _ironP = brk__ink(_iron);
    var _counts = { links: 0, nails: 0, leaves: 0, brace: 0, ironContrast: brk_contrast(_ground, _iron), undersides: 0, ornStrokes: 0, finial: 0, rustPatches: 0, armY: 0, chainEndY: 0 };
    var _stock = max(2.6, _g.ironH * 0.145);
    var _underP = brk__ink(brk_relief(_iron, -1, 30));
    var _litP = brk__ink(brk_relief(_iron, 1, 34));
    var _shadeDX = _stock * 0.18, _shadeDY = _stock * 0.24;
    var _I = { wallX: _wallX, topY: _topY, reach: _reach, ironH: _g.ironH };

    brk_cx_save(_c);
    _c.cap = BRK_STROKE_ROUND; _c.join = BRK_STROKE_ROUND;

    // the fixing plate: a forged plate bevelled under the light
    var _plX = _wallX - _g.plate.w * 0.5, _plW = _g.plate.w, _plH = _g.plate.h;
    var _bev = max(1, min(_plW, _plH) * 0.07);
    _c.fill = _underP; brk__p_fill_rect(_c, _plX, _topY, _plW, _plH);
    _c.fill = _litP; brk__p_fill_rect(_c, _plX, _topY, _plW - _bev, _plH - _bev);
    _c.fill = brk__ink(brk_relief(_iron, -1, 12)); brk__p_fill_rect(_c, _plX + _bev, _topY + _bev, _plW - _bev * 2, _plH - _bev * 2);

    // the nails: two columns, rows derived; DOMED heads (a shade down-right, the head, a highlight up-left)
    var _nail = _g.nails;
    for (var _col = 0; _col < _nail.cols; _col++) {
        var _nx = _wallX + ((_col == 0) ? -1 : 1) * _g.plate.w * 0.28;
        for (var _r = 0; _r < _nail.count; _r++) {
            var _ny = _topY + _g.nailInk + _r * _nail.pitch + _nail.pitch * 0.3;
            var _nr = _g.nailInk * 0.5;
            brk__p_begin(_c); brk__p_arc(_c, _nx + _nr * 0.22, _ny + _nr * 0.26, _nr, 0, pi * 2);
            _c.fill = brk__ink(brk_relief(_iron, -1, 40)); brk__p_fill(_c);
            brk__p_begin(_c); brk__p_arc(_c, _nx, _ny, _nr, 0, pi * 2);
            _c.fill = brk__ink(brk_relief(_iron, 1, 14)); brk__p_fill(_c);
            brk__p_begin(_c); brk__p_arc(_c, _nx - _nr * 0.32, _ny - _nr * 0.34, max(0.6, _nr * 0.34), 0, pi * 2);
            _c.fill = brk__ink(brk_relief(_iron, 1, 70)); brk__p_fill(_c);
            _counts.nails++;
        }
    }

    // the ornaments go down FIRST so the arm reads as being in front of them; each is a SEPARATE stroke from the arm
    var _spine = _g.spine;
    var _orn = _spine.orn;
    var _armYs = _topY + _spine.arm[0][1] * _g.ironH;
    for (var _o = 0; _o < array_length(_orn); _o++) {
        var _ax = _wallX + _orn[_o].ax * _reach;
        brk__iron_unit(_c, _I, _ax, _armYs, _orn[_o].pts, _stock * 0.78, _underP, _shadeDX, _shadeDY);
        _counts.undersides++;
        brk__iron_unit(_c, _I, _ax, _armYs, _orn[_o].pts, _stock * 0.78, _ironP, 0, 0);
        brk__iron_unit(_c, _I, _ax, _armYs, _orn[_o].pts, max(0.9, _stock * 0.30), _litP, -_stock * 0.22, -_stock * 0.26);
        _counts.ornStrokes++;
    }
    // the brace is a long straight run, so spine space costs it nothing
    var _braces = _spine.brace;
    for (var _bz = 0; _bz < array_length(_braces); _bz++) {
        brk__iron_run(_c, _I, _braces[_bz], _stock * 0.86, _underP, _shadeDX, _shadeDY);
        _counts.undersides++;
        brk__iron_run(_c, _I, _braces[_bz], _stock * 0.86, _ironP, 0, 0);
        brk__iron_run(_c, _I, _braces[_bz], max(0.8, _stock * 0.86 * 0.34), brk__ink(brk_relief(_iron, 1, 34)), -_stock * 0.22, -_stock * 0.26);
        _counts.brace++;
    }

    // the arm: a TAPERED BAR (a filled quad), its shaded underside, its lit top edge, and a finial so it ENDS
    var _armY = _armYs;
    var _armX0 = _wallX + _spine.arm[0][0] * _reach, _armX1 = _wallX + _spine.arm[array_length(_spine.arm) - 1][0] * _reach;
    var _hw0 = _stock * 0.62, _hw1 = _stock * 0.34;
    brk__p_begin(_c);
    brk__p_move(_c, _armX0, _armY - _hw0); brk__p_line(_c, _armX1, _armY - _hw1); brk__p_line(_c, _armX1, _armY + _hw1); brk__p_line(_c, _armX0, _armY + _hw0);
    brk__p_close(_c);
    _c.fill = _ironP; brk__p_fill(_c);
    brk__p_begin(_c);
    brk__p_move(_c, _armX0, _armY + _hw0 * 0.34); brk__p_line(_c, _armX1, _armY + _hw1 * 0.34); brk__p_line(_c, _armX1, _armY + _hw1); brk__p_line(_c, _armX0, _armY + _hw0);
    brk__p_close(_c);
    _c.fill = _underP; brk__p_fill(_c);
    _counts.undersides++;
    brk__p_begin(_c);
    brk__p_move(_c, _armX0, _armY - _hw0 + 0.6); brk__p_line(_c, _armX1, _armY - _hw1 + 0.6);
    _c.stroke = _litP; _c.lw = max(0.9, _stock * 0.26); brk__p_stroke(_c);
    var _finial = [[0, 0], [0.10, 0.04], [0.15, 0.16], [0.10, 0.27], [-0.01, 0.29]];
    brk__iron_unit(_c, _I, _armX1, _armY, _finial, _stock * 0.66, _underP, _shadeDX, _shadeDY);
    _counts.undersides++;
    brk__iron_unit(_c, _I, _armX1, _armY, _finial, _stock * 0.66, _ironP, 0, 0);
    _counts.finial = 1;

    // leaves on the scroll: pointed lenses that grow FROM the arm, pitch declared, count derived
    if (_g.trait.leaves > 0) {
        var _leafRun = _reach * 0.34;
        var _leafInk = max(5, _g.ironH * 0.20);
        var _lf = brk_fit_repeat(_leafRun, _leafInk, _leafInk * 1.9);
        var _want = min(_lf.count, _g.trait.leaves);
        for (var _L = 0; _L < _want; _L++) {
            var _lx = _wallX + 0.30 * _reach + _L * _lf.pitch;
            var _ly = _armYs + _stock * 0.2;
            brk__p_begin(_c);
            brk__p_move(_c, _lx, _ly);
            brk__p_quad(_c, _lx + _leafInk * 0.95, _ly + _leafInk * 0.25, _lx + _leafInk * 0.55, _ly + _leafInk * 1.25);
            brk__p_quad(_c, _lx - _leafInk * 0.18, _ly + _leafInk * 0.72, _lx, _ly);
            brk__p_close(_c);
            _c.fill = brk__ink(brk_relief(_iron, 1, 16)); brk__p_fill(_c);
            _counts.leaves++;
        }
    }

    // the two rings, HANGING FROM THE ARM
    _counts.armY = _armY;
    var _ringY = _armY + _g.ring.r;
    var _rr = _g.ring.r;
    var _rxs = [_g.ring.leftX, _g.ring.rightX];
    for (var _ri = 0; _ri < 2; _ri++) {
        var _rx = _rxs[_ri];
        var _ringW = max(1.4, _rr * 0.34);
        brk__p_begin(_c); brk__p_arc(_c, _wallX + _rx + _ringW * 0.30, _ringY + _ringW * 0.36, _rr, pi * 1.85, pi * 0.95);
        _c.stroke = _underP; _c.lw = _ringW; brk__p_stroke(_c);
        _counts.undersides++;
        brk__p_begin(_c); brk__p_arc(_c, _wallX + _rx, _ringY, _rr, 0, pi * 2);
        _c.stroke = _ironP; _c.lw = _ringW; brk__p_stroke(_c);
        brk__p_begin(_c); brk__p_arc(_c, _wallX + _rx - _rr * 0.18, _ringY - _rr * 0.2, _rr * 0.92, pi * 0.9, pi * 1.7);
        _c.stroke = brk__ink(brk_relief(_iron, 1, 36)); _c.lw = max(0.7, _rr * 0.15); brk__p_stroke(_c);
    }

    // the chain: link pitch from the ring's own diameter; each link carries the ring's light
    var _ch = _g.chain;
    _counts.chainEndY = _ringY + _rr + max(0, _ch.count - 1) * _ch.pitch + _g.linkH * 0.5;
    for (var _side = 0; _side < 2; _side++) {
        var _rx2 = _rxs[_side];
        var _missing = (_w.linkGone && _side == 1) ? 1 : 0;
        for (var _k = 0; _k < _ch.count - _missing; _k++) {
            var _ly2 = _ringY + _rr + _k * _ch.pitch;
            var _rot = (_k mod 2 == 1) ? pi / 2 : 0;
            var _linkW = max(1.1, _rr * 0.26);
            brk__p_begin(_c); brk__p_ellipse(_c, _wallX + _rx2, _ly2, _rr * 0.46, _g.linkH * 0.5, _rot, 0, pi * 2);
            _c.stroke = _ironP; _c.lw = _linkW; brk__p_stroke(_c);
            brk__p_begin(_c); brk__p_ellipse(_c, _wallX + _rx2, _ly2, _rr * 0.46, _g.linkH * 0.5, _rot, (_rot != 0) ? pi * 0.4 : pi * 0.95, (_rot != 0) ? pi * 1.15 : pi * 1.7);
            _c.stroke = _litP; _c.lw = max(0.6, _linkW * 0.45); brk__p_stroke(_c);
            _counts.links++;
        }
    }

    // rust on the IRON at weathering 2 and above, clipped to the arm's own quad; then rust bleeding from the rings
    if (_w.rustDrop > 0) {
        brk_cx_save(_c);
        brk__p_begin(_c);
        brk__p_move(_c, _armX0, _armY - _hw0); brk__p_line(_c, _armX1, _armY - _hw1); brk__p_line(_c, _armX1, _armY + _hw1); brk__p_line(_c, _armX0, _armY + _hw0);
        brk__p_close(_c);
        brk__p_clip(_c);
        for (var _ru = 0; _ru < 2; _ru++) {
            var _cx0 = _wallX + _rxs[_ru];
            var _span = _rr * (0.9 + _w.rustDrop * 0.75);
            var _rgA = brk_cx_linear(_c, _cx0 - _span, 0, _cx0 + _span, 0);
            var _ra = min(0.78, 0.30 + _w.rustDrop * 0.16);
            brk_cx_stop(_rgA, 0, [139, 74, 43], 0);
            brk_cx_stop(_rgA, 0.5, [139, 74, 43], brk__fixed(_ra, 3));
            brk_cx_stop(_rgA, 1, [139, 74, 43], 0);
            _c.fill = _rgA;
            brk__p_fill_rect(_c, _cx0 - _span, _armY - _hw0, _span * 2, _hw0 * 2);
            _counts.rustPatches++;
        }
        brk_cx_restore(_c);
        for (var _rd = 0; _rd < 2; _rd++) {
            var _dropPx = _rr * _w.rustDrop;
            var _rg = brk_cx_linear(_c, 0, _ringY, 0, _ringY + _dropPx);
            brk_cx_stop(_rg, 0, [139, 74, 43], 0.62);
            brk_cx_stop(_rg, 1, [139, 74, 43], 0);
            _c.fill = _rg;
            brk__p_fill_rect(_c, _wallX + _rxs[_rd] - _rr * 0.55, _ringY, _rr * 1.1, _dropPx);
        }
    }
    brk_cx_restore(_c);
    return _counts;
}

// ---------------------------------------------------------------------------------------------------------------
// The weather: a split corner at weathering 3 and above, cut from the board's own outline (it REMOVES material)
// ---------------------------------------------------------------------------------------------------------------

function brk__crack_corner(_c, _g, _p, _ox, _oy, _behind) {
    var _w = brk_weather(_p[$ "weathering"]);
    if (_w.crack <= 0) return 0;
    var _pts = brk__board_pixels(_g, _ox, _oy), _n = array_length(_pts);
    var _idx = 0, _best = -infinity;
    for (var _i = 0; _i < _n; _i++) { var _s = _pts[_i][0] + _pts[_i][1] * 1.4; if (_s > _best) { _best = _s; _idx = _i; } }
    var _cc = _pts[_idx];
    var _bite = min(_g.boardW, _g.boardH) * 0.10 * (0.6 + _w.crack);
    var _a = _pts[(_idx + _n - 1) mod _n], _b = _pts[(_idx + 1) mod _n];
    var _la = point_distance(_a[0], _a[1], _cc[0], _cc[1]); if (_la == 0) _la = 1;
    var _lb = point_distance(_b[0], _b[1], _cc[0], _cc[1]); if (_lb == 0) _lb = 1;
    var _ta = min(0.85, _bite / _la), _tb = min(0.85, _bite / _lb);
    var _pa = [_cc[0] + (_a[0] - _cc[0]) * _ta, _cc[1] + (_a[1] - _cc[1]) * _ta];
    var _pb = [_cc[0] + (_b[0] - _cc[0]) * _tb, _cc[1] + (_b[1] - _cc[1]) * _tb];
    // a split is jagged, its zigzag count from the bite
    var _tooth = max(2, _bite * 0.22);
    var _teeth = brk_fit_repeat(_bite, _tooth, _tooth * 1.25);
    var _path = [_pa];
    for (var _t = 1; _t < _teeth.count; _t++) {
        var _f = _t / _teeth.count;
        var _mx = _pa[0] + (_pb[0] - _pa[0]) * _f, _my = _pa[1] + (_pb[1] - _pa[1]) * _f;
        var _push = ((_t mod 2 == 1) ? 1 : -1) * _tooth * 0.55;
        array_push(_path, [_mx + _push * 0.7, _my - _push * 0.7]);
    }
    array_push(_path, _pb); array_push(_path, _cc);
    brk_cx_save(_c);
    brk__p_begin(_c); brk__trace_poly(_c, _path);
    _c.fill = is_string(_behind) ? brk__ink_hex(_behind) : brk__ink(_behind);
    brk__p_fill(_c);
    brk_cx_restore(_c);
    return _bite;
}

// ---------------------------------------------------------------------------------------------------------------
// The sign
// ---------------------------------------------------------------------------------------------------------------

/// @function brk_draw_sign(ctx, profile, x, y, height, [options])
/// @description Draw one whole sign - iron, chain, board, trade mark, lettering, weather - with the top-left of its box at
/// (x, y) and its full height (bracket to foot) `height` px. The iron hangs from the wall and does not swing; the board
/// swings under the rings by options.swing degrees plus the profile's own tilt. options: { swing, behind } where behind
/// is the colour behind the sign ("#rrggbb"; it shows through a split corner and decides the iron's value).
/// Returns { device, glyphs, grain, links, nails, crack, paintBands, leaves, brace, ornStrokes, squeeze, nameRatio,
/// deviceRatio, fits, geometry } - counts every probe reads.
/// @param {Struct} ctx A brk_canvas context (brk_cx_create); draws onto the current surface target
/// @param {Struct} profile A sign profile (brk_profile)
/// @returns {Struct}
function brk_draw_sign(_c, _p, _x, _y, _height, _opt = undefined) {
    var _out = { device: 0, glyphs: 0, grain: 0, links: 0, nails: 0, crack: 0, paintBands: 0, leaves: 0, brace: 0, ornStrokes: 0, squeeze: 1, nameRatio: 0, deviceRatio: 0, fits: true, geometry: undefined };
    if (!is_struct(_c) || !is_struct(_p)) return _out;
    if (!is_numeric(_x) || !is_numeric(_y) || is_nan(_x) || is_nan(_y) || is_infinity(_x) || is_infinity(_y)) return _out;
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _o = is_struct(_opt) ? _opt : {};
    var _P = brk_palette();
    var _g = brk_geometry(_p, _height);
    var _behind = (is_string(_o[$ "behind"]) && _o.behind != "") ? _o.behind : _P.dusk;
    var _reach = _g.reach;
    var _wallX = _x + max(2, _g.ironH * 0.20);

    var _iron = brk__draw_iron(_c, _g, _p, _wallX, _y, _reach, _behind);
    _out.links = _iron.links; _out.nails = _iron.nails; _out.leaves = _iron.leaves; _out.brace = _iron.brace; _out.ornStrokes = _iron.ornStrokes;

    // the board swings under the rings; its top is where the CHAIN ACTUALLY ENDS, reported by the iron that drew it
    var _swing = brk__js_num_or0(_o[$ "swing"]) + brk__js_num_or0(_p[$ "tilt"]) * 0.18;
    var _boardTop = _iron.chainEndY;
    var _pivotX = _wallX + (_g.ring.leftX + _g.ring.rightX) / 2;
    var _pivotY = _iron.armY;
    var _ox = _pivotX - _g.boardW / 2;

    brk_cx_save(_c);
    brk_cx_translate(_c, _pivotX, _pivotY);
    brk_cx_rotate(_c, _swing * pi / 180);
    brk_cx_translate(_c, -_pivotX, -_pivotY);

    var _bc = brk__paint_board(_c, _g, _p, _ox, _boardTop);
    _out.grain = _bc.grainStrokes; _out.paintBands = _bc.paintBands;

    // the trade mark, inked against whatever the board actually is
    var _ground = brk_ground_for(_p[$ "scheme"]);
    var _w = brk_weather(_p[$ "weathering"]);
    var _devPick = brk_pick_contrast(_ground, [brk__dulled(_w), brk_parse_hex(_P.oxblood), { r: 26, g: 18, b: 12 }, brk_parse_hex(_P.chalk)], 3.4);
    var _devCounter = brk_relief(_devPick.ink, -1, 46);
    var _devCx = _ox + _g.boardW / 2;
    var _devCy = _boardTop + brk__geo_by(_g, _g.yMin + _g.span * _g.device.y);
    _out.device = brk_draw_device(_c, _p[$ "device"], _devCx, _devCy, _g.device.w, _g.device.h, { r: _devPick.ink.r, g: _devPick.ink.g, b: _devPick.ink.b }, _devCounter);
    math_set_epsilon(0);
    _out.deviceRatio = _devPick.ratio;

    var _lt = brk__letter_board(_c, _g, _p, _ox, _boardTop);
    _out.glyphs = _lt.glyphs; _out.squeeze = _lt.squeeze; _out.nameRatio = _lt.ratio; _out.fits = _lt.fits;

    _out.crack = brk__crack_corner(_c, _g, _p, _ox, _boardTop, _behind);
    brk_cx_restore(_c);
    _out.geometry = _g;
    math_set_epsilon(_eps);
    return _out;
}

// ---------------------------------------------------------------------------------------------------------------
// The dusk street of the Close Look, and the Signwright's Yard
// ---------------------------------------------------------------------------------------------------------------

/// @function brk_draw_street(ctx, w, h, seed)
/// @description The dusk street a sign is stood against: sky, a coursed wall plane at the left, a far terrace of gables
/// with lit windows, cobbles, ONE distant sign (blurred and dimmed) and three out-of-focus lanterns. All drawn here, from
/// the seed (0 or absent = 7), so a given street is the same every time. Returns { lanterns, gables, distantSigns }.
/// @returns {Struct}
function brk_draw_street(_c, _w, _h, _seed = 7) {
    if (!is_struct(_c) || !is_numeric(_w) || !is_numeric(_h) || is_infinity(_w) || is_infinity(_h) || !(_w > 0) || !(_h > 0)) return { lanterns: 0, gables: 0, distantSigns: 0 };
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _P = brk_palette();
    var _sd = brk__js_num_or0(_seed);
    var _rnd = brk__rng((_sd == 0) ? 7 : _sd);
    var _sky = brk_cx_linear(_c, 0, 0, 0, _h);
    var _dk = brk_parse_hex(_P.dusk);
    brk_cx_stop(_sky, 0, [19, 26, 37], 1);
    brk_cx_stop(_sky, 0.55, [_dk.r, _dk.g, _dk.b], 1);
    brk_cx_stop(_sky, 1, [39, 48, 64], 1);
    _c.fill = _sky;
    brk__p_fill_rect(_c, 0, 0, _w, _h);

    // the wall plane: a coursing pitch derived from its own height
    var _wallW = _w * 0.34;
    _c.fill = brk__ink_hex("#232b38");
    brk__p_fill_rect(_c, 0, 0, _wallW, _h);
    var _courseInk = max(1, _h * 0.006);
    var _courses = brk_fit_repeat(_h, _courseInk, _h * 0.052);
    _c.stroke = brk_cx_solid([10, 14, 20], 0.55);
    _c.lw = _courseInk;
    for (var _i = 1; _i < _courses.count; _i++) {
        var _yy = _i * _courses.pitch;
        brk__p_begin(_c); brk__p_move(_c, 0, _yy); brk__p_line(_c, _wallW, _yy); brk__p_stroke(_c);
    }
    _c.fill = brk_cx_solid([255, 228, 170], 0.05);
    brk__p_fill_rect(_c, _wallW - 3, 0, 3, _h);

    // the far terrace: gables at a declared pitch, count derived; one lit window per other gable
    var _farY = _h * 0.34;
    var _runW = _w - _wallW;
    var _gableW = max(24, _runW * 0.16);
    var _gables = brk_fit_repeat(_runW, _gableW, _gableW * 1.08);
    var _far = 0;
    for (var _G = 0; _G < _gables.count; _G++) {
        var _gx = _wallW + _G * _gables.pitch;
        var _r0 = brk__rng_next(_rnd);
        var _gh = _farY * (0.62 + _r0 * 0.34);
        _c.fill = brk__ink_hex((_G mod 2 == 1) ? "#0e131b" : "#121822");
        brk__p_begin(_c);
        brk__p_move(_c, _gx, _h * 0.66);
        brk__p_line(_c, _gx, _h * 0.66 - _gh);
        brk__p_line(_c, _gx + _gableW * 0.5, _h * 0.66 - _gh - _gableW * 0.28);
        brk__p_line(_c, _gx + _gableW, _h * 0.66 - _gh);
        brk__p_line(_c, _gx + _gableW, _h * 0.66);
        brk__p_close(_c);
        brk__p_fill(_c);
        if (_G mod 2 == 0) {
            _c.fill = brk_cx_solid([255, 214, 140], 0.20);
            brk__p_fill_rect(_c, _gx + _gableW * 0.34, _h * 0.66 - _gh * 0.62, _gableW * 0.2, _gh * 0.16);
        }
        _far++;
    }

    // the ground: cobbles in shadow, with a course pitch of their own
    var _groundY = _h * 0.66;
    var _gg = brk_cx_linear(_c, 0, _groundY, 0, _h);
    brk_cx_stop(_gg, 0, [26, 33, 43], 1);
    brk_cx_stop(_gg, 1, [15, 20, 27], 1);
    _c.fill = _gg;
    brk__p_fill_rect(_c, 0, _groundY, _w, _h - _groundY);
    var _cobbleInk = max(1, _h * 0.004);
    var _rows = brk_fit_repeat(_h - _groundY, _cobbleInk, (_h - _groundY) * 0.14);
    _c.stroke = brk_cx_solid([60, 72, 92], 0.35);
    _c.lw = _cobbleInk;
    for (var _cr = 1; _cr < _rows.count; _cr++) {
        var _cy = _groundY + _cr * _rows.pitch;
        brk__p_begin(_c); brk__p_move(_c, 0, _cy); brk__p_line(_c, _w, _cy); brk__p_stroke(_c);
    }

    // ONE more sign down the row, small and soft - the product's OWN render at a distance
    var _farSign = { name: "WEIR FISH", trade: "FISHMONGER", device: "fish", board: "lozenge", bracket: "barAndRing", scheme: "verdigris", weathering: 3, tilt: 3, seed: 47 };
    brk_cx_save(_c);
    _c.alpha = 0.26;
    brk__p_blur_begin(_c, 3);
    brk_draw_sign(_c, _farSign, _wallW + _runW * 0.62, _h * 0.30, _h * 0.155, { behind: "#1c2431" });
    math_set_epsilon(0);
    brk__p_blur_end(_c);
    brk_cx_restore(_c);

    // three lanterns, well out of focus, drawn LAST so they wash over the street
    var _n = 0;
    for (var _L = 0; _L < 3; _L++) {
        var _q1 = brk__rng_next(_rnd);
        var _lx = _wallW + (0.18 + _q1 * 0.72) * (_w - _wallW);
        var _q2 = brk__rng_next(_rnd);
        var _ly = _h * (0.10 + _q2 * 0.55);
        var _q3 = brk__rng_next(_rnd);
        var _lr = _h * (0.05 + _q3 * 0.06);
        var _gd = brk_cx_radial(_c, _lx, _ly, 0, _lx, _ly, _lr * 3.4);
        brk_cx_stop(_gd, 0, [255, 226, 160], 0.55);
        brk_cx_stop(_gd, 0.34, [228, 170, 90], 0.16);
        brk_cx_stop(_gd, 1, [228, 170, 90], 0);
        _c.fill = _gd;
        brk__p_begin(_c); brk__p_arc(_c, _lx, _ly, _lr * 3.4, 0, pi * 2); brk__p_fill(_c);
        _n++;
    }
    math_set_epsilon(_eps);
    return { lanterns: _n, gables: _far, distantSigns: 1 };
}

/// @function brk_solve_grid(n, w, h)
/// @description The grid that hangs n signs as LARGE as the frame allows: every column count is tried, the largest sign
/// wins (a sign is at most 0.88 of its cell's height and 1/2.10 of its width, the widest board plus its reach), ties break
/// on fewest empty cells. Returns { cols, rows, cellW, cellH, signH, empties }, or undefined for no signs / no room.
/// @returns {Struct|Undefined}
function brk_solve_grid(_n, _w, _h) {
    if (!is_numeric(_n) || !is_numeric(_w) || !is_numeric(_h) || is_nan(_n) || is_infinity(_n) || is_nan(_w) || is_infinity(_w) || is_nan(_h) || is_infinity(_h)) return undefined;
    if (_n <= 0 || _w <= 0 || _h <= 0) return undefined;
    var _best = undefined;
    for (var _cols = 1; _cols <= _n; _cols++) {
        var _rows = ceil(_n / _cols);
        var _cellW = _w / _cols, _cellH = _h / _rows;
        var _signH = min(_cellH * 0.88, _cellW / 2.10);
        var _empties = _cols * _rows - _n;
        if (is_undefined(_best) || _signH > _best.signH + 0.001 || (abs(_signH - _best.signH) <= 0.001 && _empties < _best.empties))
            _best = { cols: _cols, rows: _rows, cellW: _cellW, cellH: _cellH, signH: _signH, empties: _empties };
    }
    return _best;
}

/// @function brk_draw_yard(ctx, profiles, w, h, [options])
/// @description The Signwright's Yard: every sign hung on oak rails, the grid SOLVED (brk_solve_grid), a partial last row
/// centred. options: { head, foot } (default 10% and 5% of h). Returns { cols, rows, signH, drawn, empties, n, w, h } - or,
/// when nothing can be hung, the same with zeros and `why` naming the refusal ("no signs to hang", "no usable width",
/// "no usable height").
/// @returns {Struct}
function brk_draw_yard(_c, _profiles, _w, _h, _opt = undefined) {
    // a size that is not a finite number is no room at all (refused by name, never a crash in the caller's Draw event)
    if (!is_numeric(_w) || is_nan(_w) || is_infinity(_w)) _w = 0;
    if (!is_numeric(_h) || is_nan(_h) || is_infinity(_h)) _h = 0;
    var _o = is_struct(_opt) ? _opt : {};
    var _hv = _o[$ "head"], _fv = _o[$ "foot"];
    var _head = (is_numeric(_hv) && !is_nan(_hv) && !is_infinity(_hv)) ? _hv : _h * 0.10;
    var _foot = (is_numeric(_fv) && !is_nan(_fv) && !is_infinity(_fv)) ? _fv : _h * 0.05;
    var _padX = _w * 0.025;
    var _list = is_array(_profiles) ? _profiles : [];
    var _n = array_length(_list);
    var _usableW = _w - _padX * 2, _usableH = _h - _head - _foot;
    var _best = brk_solve_grid(_n, _usableW, _usableH);
    if (is_undefined(_best) || !is_struct(_c)) {
        return { cols: 0, rows: 0, signH: 0, drawn: 0, empties: 0, n: _n, w: _w, h: _h, usableW: _usableW, usableH: _usableH,
            why: (_n <= 0) ? "no signs to hang" : ((_usableW <= 0) ? "no usable width" : (is_struct(_c) ? "no usable height" : "no drawing context")) };
    }
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _bg = brk_cx_linear(_c, 0, 0, 0, _h);
    brk_cx_stop(_bg, 0, [22, 29, 39], 1);
    brk_cx_stop(_bg, 1, [31, 39, 51], 1);
    _c.fill = _bg;
    brk__p_fill_rect(_c, 0, 0, _w, _h);
    var _drawn = 0;
    for (var _r = 0; _r < _best.rows; _r++) {
        var _rowY = _head + _r * _best.cellH;
        var _railH = max(3, _best.signH * 0.055);
        _c.fill = brk__ink_hex("#4a2c14");
        brk__p_fill_rect(_c, _padX * 0.4, _rowY, _w - _padX * 0.8, _railH);
        _c.fill = brk_cx_solid([180, 132, 80], 0.5);
        brk__p_fill_rect(_c, _padX * 0.4, _rowY, _w - _padX * 0.8, max(1, _railH * 0.3));
        var _inRow = min(_best.cols, _n - _r * _best.cols);
        var _rowW = _inRow * _best.cellW;
        var _startX = _padX + (_w - _padX * 2 - _rowW) / 2;   // a partial row is CENTRED
        for (var _k = 0; _k < _inRow; _k++) {
            var _p = _list[_r * _best.cols + _k];
            if (!is_struct(_p)) continue;
            var _g = brk_geometry(_p, _best.signH);
            var _cellCx = _startX + _k * _best.cellW + _best.cellW / 2;
            // drawSign puts the wall at x + max(2, ironH * 0.20): this centres the BOARD in its cell, not the bracket
            var _x = _cellCx - _g.boardW / 2 - max(2, _g.ironH * 0.20);
            brk_draw_sign(_c, _p, _x, _rowY, _best.signH, { behind: "#1b2330" });
            math_set_epsilon(0);
            _drawn++;
        }
    }
    math_set_epsilon(_eps);
    return { cols: _best.cols, rows: _best.rows, signH: _best.signH, drawn: _drawn, empties: _best.empties, n: _n, w: _w, h: _h };
}
