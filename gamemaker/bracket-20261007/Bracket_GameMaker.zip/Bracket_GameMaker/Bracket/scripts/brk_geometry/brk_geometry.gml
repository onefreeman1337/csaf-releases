/// brk_geometry.gml - Bracket's geometry kit, part 2: the wrought-iron bracket forms, the trade marks' measured bounds, and
/// brk_geometry(profile, height), which turns a sign profile into every position the painter needs, in PIXELS. A port, line
/// for line, of the RPG Maker MZ edition's BracketCompose.js (volute, spineRise, unitRing, BRACKET_SPINE, BRACKET_TRAIT,
/// deviceBounds, geometry). Pure: no drawing, no engine state beyond a restored epsilon.
///
/// Public functions: brk_bracket_spine, brk_bracket_trait, brk_device_bounds, brk_geometry.
///
/// ⛔ PORTING NOTES: a volute is authored in ONE unit (the iron's own height) in BOTH axes so a circle stays a circle; the
/// renderer never stretches it. The arm's height is DERIVED from its own ornament's rise and every brace is snapped to it.
/// The board gets what is left of the height after the iron and the chain. Every key keeps the MZ name so the painter port
/// reads the same fields.

/// @function brk__volute(R, sweep, dir, [tighten])
/// @description Internal. One scroll in iron-height units, starting on the arm at (0, 0) and curling UP and away from it,
/// tightening as it goes: 27 points.
function brk__volute(_R, _sweep, _dir, _tighten = 0.64) {
    var _pts = array_create(27);
    for (var _i = 0; _i <= 26; _i++) {
        var _t = _i / 26;
        var _a = -pi / 2 + _dir * _t * _sweep;
        var _r = _R * (1 - _t * _tighten);
        _pts[_i] = [cos(_a) * _r, -(_R + sin(_a) * _r)];
    }
    return _pts;
}

/// @function brk__spine_rise(spine)
/// @description Internal. How far a spine's ornaments rise ABOVE the arm, in iron-height units, read off their own points.
function brk__spine_rise(_spine) {
    var _rise = 0;
    var _orn = (is_struct(_spine) && is_array(_spine[$ "orn"])) ? _spine.orn : [];
    for (var _i = 0; _i < array_length(_orn); _i++) {
        var _pts = is_array(_orn[_i][$ "pts"]) ? _orn[_i].pts : [];
        for (var _k = 0; _k < array_length(_pts); _k++) if (-_pts[_k][1] > _rise) _rise = -_pts[_k][1];
    }
    return _rise;
}

/// @function brk__unit_ring(r, lift)
/// @description Internal. A closed ring in unit space, sitting ON its anchor and rising above it: 23 points.
function brk__unit_ring(_r, _lift) {
    var _pts = array_create(23);
    for (var _i = 0; _i <= 22; _i++) {
        var _a = _i / 22 * pi * 2 - pi / 2;
        _pts[_i] = [cos(_a) * _r, -(_lift + _r) + sin(_a) * _r];
    }
    return _pts;
}

/// @function brk_bracket_spine(bracket)
/// @description A bracket form as { arm, orn, brace }: arm = the straight run the board hangs from ([[x, y], [x, y]], x 0 at
/// the wall to 1 at the far end of the reach, y a share of the iron's height); orn = welded ornaments { ax, pts } (ax a
/// share of the reach, pts in iron-height units in BOTH axes); brace = straight diagonal runs in spine space. A new struct
/// every call. An unknown id gives the plain hook.
/// @param {String} bracket plainHook, barAndRing, singleScroll, doubleScroll, volute, leafScroll, gallows or crownedScroll
/// @returns {Struct}
function brk_bracket_spine(_bracket) {
    switch (_bracket) {
        case "barAndRing": return { arm: [[0, 0.13], [1, 0.13]], orn: [{ ax: 0.80, pts: brk__unit_ring(0.20, 0.06) }], brace: [] };
        case "singleScroll": return { arm: [[0, 0.12], [1, 0.12]], orn: [{ ax: 0.22, pts: brk__volute(0.40, pi * 1.7, 1) }], brace: [] };
        case "doubleScroll": return { arm: [[0, 0.11], [1, 0.11]], orn: [{ ax: 0.18, pts: brk__volute(0.40, pi * 1.7, 1) }, { ax: 0.58, pts: brk__volute(0.30, pi * 1.5, -1) }], brace: [] };
        case "volute": return { arm: [[0, 0.10], [1, 0.10]], orn: [{ ax: 0.24, pts: brk__volute(0.52, pi * 2.4, 1, 0.72) }], brace: [] };
        case "leafScroll": return { arm: [[0, 0.10], [1, 0.10]], orn: [{ ax: 0.20, pts: brk__volute(0.46, pi * 1.9, 1) }], brace: [] };
        // The brace is what a gallows IS: a diagonal from the wall to the arm.
        case "gallows": return { arm: [[0, 0.09], [1, 0.09]], orn: [{ ax: 0.70, pts: brk__volute(0.26, pi * 1.4, -1) }], brace: [[[0.015, 0.62], [0.42, 0.09]]] };
        case "crownedScroll": return { arm: [[0, 0.08], [1, 0.08]],
            orn: [{ ax: 0.16, pts: brk__volute(0.44, pi * 1.8, 1) }, { ax: 0.50, pts: brk__volute(0.34, pi * 2.2, -1, 0.70) }, { ax: 0.82, pts: brk__volute(0.26, pi * 1.5, 1) }],
            brace: [[[0.015, 0.66], [0.38, 0.08]]] };
    }
    return { arm: [[0, 0.14], [1, 0.14]], orn: [], brace: [] };
}

/// @function brk_bracket_trait(bracket)
/// @description Which forms carry a diagonal brace, how many leaves, and the fixing plate's share: { brace, leaves, plateH }.
/// An unknown id gives the plain hook's.
/// @param {String} bracket
/// @returns {Struct}
function brk_bracket_trait(_bracket) {
    switch (_bracket) {
        case "barAndRing": return { brace: false, leaves: 0, plateH: 0.26 };
        case "singleScroll": return { brace: false, leaves: 0, plateH: 0.30 };
        case "doubleScroll": return { brace: false, leaves: 0, plateH: 0.34 };
        case "volute": return { brace: false, leaves: 0, plateH: 0.36 };
        case "leafScroll": return { brace: false, leaves: 3, plateH: 0.40 };
        case "gallows": return { brace: true, leaves: 0, plateH: 0.46 };
        case "crownedScroll": return { brace: true, leaves: 2, plateH: 0.52 };
    }
    return { brace: false, leaves: 0, plateH: 0.22 };
}

/// @function brk_device_bounds(id)
/// @description The bounding box of a trade mark's primitives in device space: { minX, minY, maxX, maxY, w, h }. An unknown
/// id gives an EMPTY box (w and h negative infinity), which brk_geometry reads as aspect 1.
/// @param {String} id
/// @returns {Struct}
function brk_device_bounds(_id) {
    var _prims = brk_device_prims(_id);
    var _b = { minX: infinity, minY: infinity, maxX: -infinity, maxY: -infinity };
    var _add = function(_bb, _x, _y) {
        if (_x < _bb.minX) _bb.minX = _x; if (_x > _bb.maxX) _bb.maxX = _x;
        if (_y < _bb.minY) _bb.minY = _y; if (_y > _bb.maxY) _bb.maxY = _y;
    };
    for (var _i = 0; _i < array_length(_prims); _i++) {
        var _p = _prims[_i], _t = _p.t;
        if (_t == "poly" || (_t == "cut" && is_array(_p[$ "pts"]))) {
            for (var _k = 0; _k < array_length(_p.pts); _k++) _add(_b, _p.pts[_k][0], _p.pts[_k][1]);
        } else if (_t == "circ" || (_t == "cut" && !is_undefined(_p[$ "circ"]) && _p.circ)) {
            _add(_b, _p.x - _p.r, _p.y - _p.r); _add(_b, _p.x + _p.r, _p.y + _p.r);
        } else if (_t == "bar") {
            var _h = _p.w / 2;
            _add(_b, min(_p.a[0], _p.b[0]) - _h, min(_p.a[1], _p.b[1]) - _h);
            _add(_b, max(_p.a[0], _p.b[0]) + _h, max(_p.a[1], _p.b[1]) + _h);
        } else if (_t == "ring") {
            _add(_b, _p.x - _p.r - _p.w / 2, _p.y - _p.r - _p.w / 2);
            _add(_b, _p.x + _p.r + _p.w / 2, _p.y + _p.r + _p.w / 2);
        }
    }
    _b.w = _b.maxX - _b.minX; _b.h = _b.maxY - _b.minY;
    return _b;
}

/// @function brk__geo_bx(geometry, x)
/// @description Internal. Board space x (-1..1) to pixels, the board's left edge at 0.
function brk__geo_bx(_g, _x) { return (_x / ((_g.xMax != 0) ? _g.xMax : 1)) * _g.boardHalfPx + _g.boardHalfPx; }

/// @function brk__geo_by(geometry, y)
/// @description Internal. Board space y to pixels, the board's top at 0.
function brk__geo_by(_g, _y) { return ((_y - _g.yMin) / _g.span) * _g.boardH; }

/// @function brk_geometry(profile, height)
/// @description Everything a sign needs, in PIXELS, from its profile and the height it is drawn at (bracket to foot). The
/// height is spent in order on the fixing plate and arm, the rings and chain, and the board, which gets what is left.
/// Returns { H, boardW, boardH, boardHalfPx, ironH, chainH, outline, xMax, yMin, span, ring {r, leftX, rightX, y}, chain
/// {count, pitch, floored}, linkH, device {y, h, w, maxW, bounds, aspect}, name {y, w, arc, size}, trade {y, w, size},
/// keylineInset, grain {count, pitch, floored}, grainInk, plate {w, h}, nails {count, pitch, floored, cols, total}, nailInk,
/// trait, spine {arm, orn, brace, armShare, rise}, reach, tilt }. Board positions map to pixels with brk__geo_bx/by.
/// @param {Struct} profile A profile from brk_profile (reads board, bracket, device, scheme, weathering, tilt).
/// @param {Real} height The sign's full height in pixels (at least 24; anything that is not a positive number gives 128).
/// @returns {Struct}
function brk_geometry(_p, _height) {
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _pp = is_struct(_p) ? _p : {};
    var _board = _pp[$ "board"], _bracket = _pp[$ "bracket"];
    var _hn = brk__js_num_or0(_height);
    var _H = max(24, (_hn == 0) ? 128 : _hn);
    var _trait = brk_bracket_trait(_bracket);

    // The iron takes a fixed share of the height; a grander bracket takes more.
    var _ironH = _H * (0.20 + _trait.plateH * 0.16);
    var _chainH = _H * 0.085;
    var _boardH = _H - _ironH - _chainH;
    var _pts = brk_outline(_board);

    var _yMin = infinity, _yMax = -infinity, _xMax = 0;
    for (var _i = 0; _i < array_length(_pts); _i++) {
        if (_pts[_i][1] < _yMin) _yMin = _pts[_i][1];
        if (_pts[_i][1] > _yMax) _yMax = _pts[_i][1];
        if (abs(_pts[_i][0]) > _xMax) _xMax = abs(_pts[_i][0]);
    }
    var _span = max(0.0001, _yMax - _yMin);
    var _aspect = brk_aspect(_board);
    if (!is_numeric(_aspect) || !(_aspect > 0)) _aspect = 1.35;
    var _boardHalfPx = _boardH * _aspect * 0.5;
    var _boardW = _boardHalfPx * 2;
    var _xm = (_xMax != 0) ? _xMax : 1;
    var _g = { xMax: _xMax, boardHalfPx: _boardHalfPx, yMin: _yMin, span: _span, boardH: _boardH };

    // --- the rings hang from the board's own widest run near its top ---
    var _topRun = brk__run_at(_pts, _yMin + _span * 0.06);
    if (_topRun.width <= 0.02) _topRun = brk__run_at(_pts, _yMin + _span * 0.16);
    var _ringR = max(2, _boardH * 0.055);
    var _ringInset = max(_ringR * 1.4, _topRun.width * _xm * 0.10);
    var _ringLeftX = brk__geo_bx(_g, _topRun.left) + _ringInset;
    var _ringRightX = brk__geo_bx(_g, _topRun.right) - _ringInset;
    if (_ringRightX - _ringLeftX < _ringR * 4) {
        var _mid = (_ringLeftX + _ringRightX) / 2;
        _ringLeftX = _mid - _ringR * 2; _ringRightX = _mid + _ringR * 2;
    }

    // --- the chain: pitch from the ring, count from the real drop ---
    var _linkH = _ringR * 1.5;
    var _chain = brk_fit_repeat(_chainH + _linkH, _linkH, _linkH * 0.72, true);

    // --- where the lettering sits, FIRST: the device is fitted to what the lettering leaves ---
    var _band = brk__letter_band(_pts, _yMin, _span);
    var _nameY = _band.name_y, _tradeY = _band.trade_y;

    // --- the device: the largest box the band above the name will take, fitted by the mark's own bounds ---
    var _bandTopPx = _boardH * 0.055;
    var _nameCapPx = _boardH * _nameY - max(7, _boardH * BRK_NAME_SIZE) * 1.08;
    var _devBandH = max(8, _nameCapPx - _bandTopPx);
    var _devY = (_bandTopPx + _devBandH / 2) / _boardH;
    var _devRun = brk__run_at(_pts, _yMin + _span * _devY);
    var _devMaxW = _devRun.width * (_boardHalfPx / _xm);
    var _devH = max(8, min(_devBandH * 0.94, _devMaxW * 0.82));
    if (_devH < _boardH * 0.40) _devH = min(_boardH * 0.40, _devBandH * 0.98);
    var _devBounds = brk_device_bounds(_pp[$ "device"]);
    var _devAspect = (_devBounds.h > 0) ? (_devBounds.w / _devBounds.h) : 1;
    if (is_nan(_devAspect) || is_infinity(_devAspect) || !(_devAspect > 0)) _devAspect = 1;
    var _devW = _devH * _devAspect;
    if (_devW > _devMaxW * 0.92) { _devW = _devMaxW * 0.92; _devH = _devW / _devAspect; }

    // --- the lettering: as wide as the solid run the outline leaves at each line ---
    var _nameRun = brk__run_at(_pts, _yMin + _span * _nameY);
    var _tradeRun = brk__run_at(_pts, _yMin + _span * _tradeY);
    var _inset = max(3, _boardH * BRK_BOARD_INSET);
    var _nameW = max(8, _nameRun.width * (_boardHalfPx / _xm) - _inset * 2);
    var _tradeW = max(6, _tradeRun.width * (_boardHalfPx / _xm) - _inset * 2);
    // ...and the paint's own retreat: a painted board's type sits on the PAINT, measured on the polygon the painter fills.
    if (!is_undefined(brk__scheme_field(_pp[$ "scheme"]))) {
        var _coat = brk_paint_inset(_boardW, _boardH, _pp[$ "weathering"]);
        if (_coat > 0.5) {
            var _pxPts = array_create(array_length(_pts));
            for (var _pi = 0; _pi < array_length(_pts); _pi++) _pxPts[_pi] = [brk__geo_bx(_g, _pts[_pi][0]), brk__geo_by(_g, _pts[_pi][1])];
            var _coated = brk_inset_polygon(_pxPts, _boardHalfPx, _boardH / 2, _coat);
            var _nameRunPx = brk_pixel_run_at(_coated, brk__geo_by(_g, _yMin + _span * _nameY), _boardHalfPx);
            var _tradeRunPx = brk_pixel_run_at(_coated, brk__geo_by(_g, _yMin + _span * _tradeY), _boardHalfPx);
            math_set_epsilon(0);   // brk_pixel_run_at restores the caller's epsilon, which is OURS (0) here - kept explicit
            if (_nameRunPx > 0) _nameW = max(8, min(_nameW, _nameRunPx - _inset));
            if (_tradeRunPx > 0) _tradeW = max(6, min(_tradeW, _tradeRunPx - _inset));
        }
    }
    // An arc for the round-headed boards, straight for the rest.
    var _arcLetters = (_board == "oval" || _board == "heater" || _board == "arch");

    // --- the grain: pitch from the board's short side, count derived ---
    var _grainInk = max(1, _boardH * 0.020);
    var _grain = brk_fit_repeat(_boardH, _grainInk, _grainInk * 3.4);

    // --- where the arm sits, DERIVED from its own ornament; every brace snapped to it ---
    var _spine = brk_bracket_spine(_bracket);
    var _rise = brk__spine_rise(_spine);
    var _armShare = max(_spine.arm[0][1], _rise + 0.10);
    for (var _a = 0; _a < array_length(_spine.arm); _a++) _spine.arm[_a] = [_spine.arm[_a][0], _armShare];
    for (var _b = 0; _b < array_length(_spine.brace); _b++) {
        var _run = _spine.brace[_b], _out = array_create(array_length(_run));
        for (var _q = 0; _q < array_length(_run); _q++) _out[_q] = _run[_q];
        var _last = array_length(_out) - 1;
        _out[_last] = [_out[_last][0], _armShare];
        _spine.brace[_b] = _out;
    }
    _spine.armShare = _armShare;
    _spine.rise = _rise;

    // --- the fixing plate and its nails (a plate that does not reach the arm is not fixing anything) ---
    var _plateW = max(6, _ironH * 0.34);
    var _plateH = max(8, _ironH * (0.42 + _trait.plateH * 0.42), min(_ironH, _armShare * _ironH + _ironH * 0.12));
    var _nailInk = max(1.4, _plateW * 0.16);
    var _nails = brk_fit_repeat(_plateH - _nailInk * 2, _nailInk, _nailInk * 4.0);
    _nails.cols = 2;
    _nails.total = _nails.count * _nails.cols;

    var _res = {
        H: _H, boardW: _boardW, boardH: _boardH, boardHalfPx: _boardHalfPx,
        ironH: _ironH, chainH: _chainH,
        outline: _pts, xMax: _xMax, yMin: _yMin, span: _span,
        ring: { r: _ringR, leftX: _ringLeftX, rightX: _ringRightX, y: -_chainH * 0.10 },
        chain: _chain, linkH: _linkH,
        device: { y: _devY, h: _devH, w: _devW, maxW: _devMaxW, bounds: _devBounds, aspect: _devAspect },
        name: { y: _nameY, w: _nameW, arc: _arcLetters, size: max(7, _boardH * BRK_NAME_SIZE) },
        trade: { y: _tradeY, w: _tradeW, size: max(5, _boardH * BRK_TRADE_SIZE) },
        keylineInset: _inset * 0.7,
        grain: _grain, grainInk: _grainInk,
        plate: { w: _plateW, h: _plateH }, nails: _nails, nailInk: _nailInk,
        trait: _trait, spine: _spine,
        // The reach is derived from the board it carries plus the stand-off the fixing plate needs at the wall.
        reach: _boardW + max(2, _ironH * 0.20) + _ironH * 0.10,
        tilt: brk__fin(_pp[$ "tilt"], 0)
    };
    math_set_epsilon(_eps);
    return _res;
}
