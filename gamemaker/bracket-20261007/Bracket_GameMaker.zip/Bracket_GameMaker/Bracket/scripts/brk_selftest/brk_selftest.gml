/// brk_selftest.gml - Bracket's in-engine self-test, run headless by the demo object with -selftest. Holds the GML port to
/// the RPG Maker MZ edition run in Node (brk_oracle_read): hashes and generator states EXACT, the price ladder, standing
/// over every depth x reach x breadth corner, the ten board capacities, and 62 full sign profiles. Writes
/// brk_selftest.json. FIRST CUT: the reader and the outline capacities only; drawing stages arrive with the kit.

/// @function brk_st_assert(state, condition, message)
function brk_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 80) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
/// @function brk_st_stage(state, n)
function brk_st_stage(_st, _n) { _st.stage = _n; global.brk_stage = _n; }

/// @function brk__st_at(value, path)
/// @description A number read off a struct by a dotted path ("ring.leftX", "spine.arm.0.1", "outline.length"): booleans as
/// 1/0, anything missing or non-finite as 0 - the same flattening _oracle_geo.js applies to the MZ result.
function brk__st_at(_v, _path) {
    var _parts = string_split(_path, ".");
    for (var _i = 0; _i < array_length(_parts); _i++) {
        var _k = _parts[_i];
        if (is_undefined(_v)) return 0;
        if (_k == "length") { _v = is_array(_v) ? array_length(_v) : 0; continue; }
        if (is_array(_v)) { var _n = real(_k); _v = (_n < array_length(_v)) ? _v[_n] : undefined; continue; }
        if (is_struct(_v)) { _v = _v[$ _k]; continue; }
        return 0;
    }
    if (is_bool(_v)) return _v ? 1 : 0;
    if (!is_numeric(_v) || is_nan(_v) || is_infinity(_v)) return 0;
    return _v;
}

/// @function brk__st_sum(value, acc)
/// @description Every number in a nested value (bools skipped, as JS typeof skips them) summed into acc { s, n }.
/// A named function: a GML anonymous function cannot see itself through the enclosing function's locals.
function brk__st_sum(_v, _acc) {
    if (is_array(_v)) { for (var _i = 0; _i < array_length(_v); _i++) brk__st_sum(_v[_i], _acc); }
    else if (is_struct(_v)) { var _ks = variable_struct_get_names(_v); for (var _j = 0; _j < array_length(_ks); _j++) brk__st_sum(_v[$ _ks[_j]], _acc); }
    else if (is_numeric(_v) && !is_bool(_v)) { _acc.s += _v; _acc.n += 1; }
}

/// @function brk_selftest_run()
/// @returns {Struct} { total, pass, fail, stage, failures, notes, metrics }
function brk_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, stage: 0, notes: [], failures: [], metrics: {} };
    var _eps0 = math_get_epsilon();
    math_set_epsilon(0);
    _st.metrics.epsilonAtStart = _eps0;
    var _O = brk_oracle_read(), _T = brk_tables();
    // ---- 1: the tables (gen_tables.js printed 12 / 12 / 131 / 10 / 8 / 6) ----
    brk_st_stage(_st, 1);
    var _words = 0;
    for (var _d = 0; _d < array_length(_T.devices); _d++) _words += array_length(_T.words[$ _T.devices[_d]]);
    brk_st_assert(_st, array_length(_T.devices) == 12 && array_length(_T.boards) == 10 && array_length(_T.brackets) == 8 && array_length(_T.schemes) == 6 && _words == 131, "tables 12/10/8/6 and 131 goods words (" + string(_words) + ")");
    // ---- 2: the hash, every string EXACT ----
    brk_st_stage(_st, 2);
    var _hBad = 0, _hFirst = "";
    for (var _i = 0; _i < array_length(_O.hash); _i++) { var _got = brk_hash(_O.hash[_i].s); if (_got != _O.hash[_i].h) { _hBad++; if (_hFirst == "") _hFirst = "'" + _O.hash[_i].s + "' got " + string(_got) + " want " + string(_O.hash[_i].h); } }
    brk_st_assert(_st, _hBad == 0, "FNV hash on " + string(array_length(_O.hash)) + " strings, " + string(_hBad) + " differ " + _hFirst);
    // ---- 3: the generator, 3 seeds x 1,000 states EXACT ----
    brk_st_stage(_st, 3);
    var _rBad = 0, _rFirst = "";
    for (var _k = 0; _k < array_length(_O.rng); _k++) {
        var _r = brk__rng(_O.rng[_k].seed), _want = _O.rng[_k].s;
        for (var _j = 0; _j < array_length(_want); _j++) {
            var _v = brk__rng_next(_r);
            if (real(_r.s) != _want[_j] || _v != _want[_j] / 4294967296) { _rBad++; if (_rFirst == "") _rFirst = "seed " + string(_O.rng[_k].seed) + " draw " + string(_j) + " got " + string(real(_r.s)) + " want " + string(_want[_j]); }
        }
    }
    brk_st_assert(_st, _rBad == 0, "xorshift32 states, 3 seeds x 1000, " + string(_rBad) + " differ " + _rFirst);
    // ---- 4: the price ladder ----
    brk_st_stage(_st, 4);
    var _lBad = 0;
    for (var _l = 0; _l < array_length(_O.ladder); _l++) {
        var _g = brk_ladder_from(_O.ladder[_l].prices), _w = _O.ladder[_l].got;
        if (is_undefined(_w)) { if (!is_undefined(_g)) _lBad++; } else if (is_undefined(_g) || _g[0] != _w[0] || _g[1] != _w[1] || _g[2] != _w[2]) _lBad++;
    }
    var _dl = brk_use_price_ladder(undefined);
    brk_st_assert(_st, _lBad == 0 && _dl[0] == _O.default_ladder[0] && _dl[1] == _O.default_ladder[1] && _dl[2] == _O.default_ladder[2], "ladderFrom on " + string(array_length(_O.ladder)) + " price lists (" + string(_lBad) + " differ) and the default ladder");
    // ---- 5: standing over every depth x reach x breadth corner ----
    brk_st_stage(_st, 5);
    var _sBad = 0, _sFirst = "";
    for (var _s = 0; _s < array_length(_O.standing); _s++) {
        var _c = _O.standing[_s], _goods = [];
        for (var _q = 0; _q < _c.depth; _q++) array_push(_goods, { kind: (_c.mixed && (_q mod 2) == 1) ? "weapon" : "item", name: "Thing " + string(_q), price: (_q == 0) ? _c.best : 10, itypeId: 1, etypeId: 0, effects: [] });
        var _gs = brk_standing({ goods: _goods });
        if (_gs != _c.got) { _sBad++; if (_sFirst == "") _sFirst = "depth " + string(_c.depth) + " best " + string(_c.best) + " got " + string(_gs) + " want " + string(_c.got); }
    }
    brk_st_assert(_st, _sBad == 0, "standing on " + string(array_length(_O.standing)) + " corners, " + string(_sBad) + " differ " + _sFirst);
    // ---- 6: the ten board capacities (floats from the outline geometry, to 1e-9) ----
    brk_st_stage(_st, 6);
    var _cBad = 0, _cFirst = "", _cMax = 0;
    for (var _b = 0; _b < array_length(_T.boards); _b++) {
        var _cap = brk_capacity_of(_T.boards[_b]), _dc = abs(_cap - _O.capacities[_b]);
        _cMax = max(_cMax, _dc);
        if (!(_dc < 0.000000001)) { _cBad++; if (_cFirst == "") _cFirst = _T.boards[_b] + " got " + string_format(_cap, 1, 12) + " want " + string_format(_O.capacities[_b], 1, 12); }
    }
    _st.metrics.capacityMaxErr = _cMax;
    brk_st_assert(_st, _cBad == 0, "capacityOf on 10 boards to 1e-9, " + string(_cBad) + " differ " + _cFirst);
    // ---- 7: 62 full profiles (every field EXACT, the tilt to 1e-9 - its measured error is recorded as tiltMaxErr) ----
    brk_st_stage(_st, 7);
    var _pBad = 0, _fields = ["key", "name", "trade", "device", "board", "bracket", "scheme", "weathering", "standing", "seed"];
    var _tMax = 0;
    for (var _p0 = 0; _p0 < array_length(_O.profiles); _p0++) _tMax = max(_tMax, abs(brk_profile(_O.profiles[_p0].shop).tilt - _O.profiles[_p0].got.tilt));
    _st.metrics.tiltMaxErr = _tMax;
    // ⛔ MEASURED 2026-10-07 on 2024.14.4.268: math_set_epsilon(0) leaves math_get_epsilon() at 0.00000000001 (1e-11), so a
    // `< 1e-12` tolerance is FALSE even for equal values - the first run failed all 62 profiles on a tilt error of exactly 0.
    // Tolerances here stay at 1e-9, above that floor, and the floor is recorded every run.
    _st.metrics.epsilonFloor = math_get_epsilon();
    for (var _p = 0; _p < array_length(_O.profiles); _p++) {
        var _pr = brk_profile(_O.profiles[_p].shop), _wp = _O.profiles[_p].got, _why = "";
        for (var _f = 0; _f < array_length(_fields); _f++) if (_pr[$ _fields[_f]] != _wp[$ _fields[_f]]) { _why += _fields[_f] + " got " + string(_pr[$ _fields[_f]]) + " want " + string(_wp[$ _fields[_f]]) + "; "; }
        if (!(abs(_pr.tilt - _wp.tilt) < 0.000000001)) _why +="tilt got " + string_format(_pr.tilt, 1, 14) + " want " + string_format(_wp.tilt, 1, 14) + "; ";
        if (_pr.goods_count != _wp.goodsCount) _why += "goods_count; ";
        if (_why != "") { _pBad++; brk_st_assert(_st, false, "profile " + string(_p) + " (" + string(_wp.name) + "): " + _why); }
    }
    brk_st_assert(_st, _pBad == 0, "62 profiles field for field against the MZ reader, " + string(_pBad) + " differ");
    // ---- 8: the colour helpers (parse incl. malformed, luminance, contrast, relief at both ends, ink choice, grounds) ----
    brk_st_stage(_st, 8);
    var _C = _O.colour, _cb = "";
    var _rgbEq = function(_a, _b) { return is_struct(_a) && is_struct(_b) && _a.r == _b.r && _a.g == _b.g && _a.b == _b.b; };
    for (var _c1 = 0; _c1 < array_length(_C.parse); _c1++) { var _pg = brk_parse_hex(_C.parse[_c1].h), _pw = _C.parse[_c1].got; if (is_undefined(_pw) ? !is_undefined(_pg) : !_rgbEq(_pg, _pw)) _cb += "parse '" + _C.parse[_c1].h + "'; "; }
    var _lMax = 0;
    for (var _c2 = 0; _c2 < array_length(_C.lum); _c2++) _lMax = max(_lMax, abs(brk_lum(_C.lum[_c2].h) - _C.lum[_c2].got));
    for (var _c3 = 0; _c3 < array_length(_C.contrast); _c3++) _lMax = max(_lMax, abs(brk_contrast(_C.contrast[_c3].a, _C.contrast[_c3].b) - _C.contrast[_c3].got));
    if (!(_lMax < 0.000000001)) _cb += "lum/contrast max error " + string_format(_lMax, 1, 12) + "; ";
    _st.metrics.colourMaxErr = _lMax;
    for (var _c4 = 0; _c4 < array_length(_C.relief); _c4++) { var _rv = _C.relief[_c4], _rg = brk_relief(_rv.c, _rv.d, _rv.m); if (!_rgbEq(_rg, _rv.got) || _rg.delta != _rv.got.delta || _rg.capped != _rv.got.capped) _cb += "relief " + _rv.c + " " + string(_rv.d) + "; "; }
    for (var _c5 = 0; _c5 < array_length(_C.pick); _c5++) { var _kv = _C.pick[_c5], _kg = brk_pick_contrast(_kv.g, _kv.c, _kv.w); if (!_rgbEq(_kg.ink, _kv.got.ink) || !(abs(_kg.ratio - _kv.got.ratio) < 0.000000001) || _kg.cleared != _kv.got.cleared) _cb += "pick on " + _kv.g + "; "; }
    for (var _c6 = 0; _c6 < array_length(_C.ground); _c6++) if (!_rgbEq(brk_ground_for(_C.ground[_c6].s), _C.ground[_c6].got)) _cb += "ground " + _C.ground[_c6].s + "; ";
    for (var _c7 = 0; _c7 < array_length(_C.toHex); _c7++) if (brk__to_hex(_C.toHex[_c7].c) != _C.toHex[_c7].got) _cb += "toHex " + _C.toHex[_c7].got + " got " + brk__to_hex(_C.toHex[_c7].c) + "; ";
    brk_st_assert(_st, _cb == "", "colour helpers against the MZ kit (" + string(array_length(_C.parse)) + " hex, " + string(array_length(_C.relief)) + " reliefs, " + string(array_length(_C.pick)) + " ink choices, " + string(array_length(_C.ground)) + " grounds): " + _cb);
    // ---- 9: the small geometry helpers (repeats, pens, weathers incl. bad levels, insets, a pulled polygon, pixel runs) ----
    brk_st_stage(_st, 9);
    var _S = _O.small, _sb = "", _sMax = 0, _nz = 0;
    for (var _s1 = 0; _s1 < array_length(_S.fit); _s1++) { var _fv = _S.fit[_s1], _fg = brk_fit_repeat(_fv.s, _fv.i, _fv.p, _fv.l); if (_fg.count != _fv.got.count || _fg.pitch != _fv.got.pitch || _fg.floored != _fv.got.floored) _sb += "fit " + string(_s1) + "; "; }
    for (var _s2 = 0; _s2 < array_length(_S.pen); _s2++) _sMax = max(_sMax, abs(brk_pen_for(_S.pen[_s2].w, _S.pen[_s2].h, _S.pen[_s2].k) - _S.pen[_s2].got));
    var _wf = ["level", "grainThrough", "cornerWear", "giltDull", "rustDrop", "crack", "linkGone"];
    for (var _s3 = 0; _s3 < array_length(_S.weather); _s3++) { var _wg = brk_weather(_S.weather[_s3].l); for (var _q3 = 0; _q3 < 7; _q3++) if (_wg[$ _wf[_q3]] != _S.weather[_s3].got[$ _wf[_q3]]) { _sb += "weather " + string(_s3) + "." + _wf[_q3] + "; "; break; } }
    for (var _s4 = 0; _s4 < array_length(_S.inset); _s4++) _sMax = max(_sMax, abs(brk_paint_inset(_S.inset[_s4].w, _S.inset[_s4].h, _S.inset[_s4].l) - _S.inset[_s4].got));
    var _pulled = brk_inset_polygon(_S.heaterPx, 50, 60, 7);
    if (array_length(_pulled) != array_length(_S.pulled)) _sb += "inset polygon length; "; else for (var _s5 = 0; _s5 < array_length(_pulled); _s5++) _sMax = max(_sMax, abs(_pulled[_s5][0] - _S.pulled[_s5][0]), abs(_pulled[_s5][1] - _S.pulled[_s5][1]));
    for (var _s6 = 0; _s6 < array_length(_S.runs); _s6++) { var _rr = brk_pixel_run_at(_S.pulled, _S.runs[_s6].y, _S.runs[_s6].cx); _sMax = max(_sMax, abs(_rr - _S.runs[_s6].got)); if (_rr > 0) _nz++; }
    if (!(_sMax < 0.000000001)) _sb += "numeric max error " + string_format(_sMax, 1, 12) + "; ";
    if (_nz != 4) _sb += "non-zero pixel runs " + string(_nz) + " (the oracle has 4); ";
    _st.metrics.smallMaxErr = _sMax;
    brk_st_assert(_st, _sb == "", "fitRepeat/penFor/weather/paintInset/insetPolygon/pixelRunAt against the MZ kit (" + string(array_length(_S.weather)) + " weathers, " + string(array_length(_S.runs)) + " runs): " + _sb);
    // ---- 10: the eight bracket spines point for point (+ an unknown id) and their traits ----
    brk_st_stage(_st, 10);
    var _G = brk_oracle_geo(), _gb = "", _gMax = 0, _gPts = 0;
    for (var _g1 = 0; _g1 < array_length(_G.spines); _g1++) {
        var _sw = _G.spines[_g1].got, _sg = brk_bracket_spine(_G.spines[_g1].b);
        var _A = [[_sg.arm, _sw.arm]];
        if (array_length(_sg.orn) != array_length(_sw.orn) || array_length(_sg.brace) != array_length(_sw.brace)) { _gb += _G.spines[_g1].b + " counts; "; continue; }
        for (var _o1 = 0; _o1 < array_length(_sw.orn); _o1++) { _gMax = max(_gMax, abs(_sg.orn[_o1].ax - _sw.orn[_o1].ax)); array_push(_A, [_sg.orn[_o1].pts, _sw.orn[_o1].pts]); }
        for (var _o2 = 0; _o2 < array_length(_sw.brace); _o2++) array_push(_A, [_sg.brace[_o2], _sw.brace[_o2]]);
        for (var _o3 = 0; _o3 < array_length(_A); _o3++) {
            var _pg = _A[_o3][0], _pw = _A[_o3][1];
            if (array_length(_pg) != array_length(_pw)) { _gb += _G.spines[_g1].b + " run " + string(_o3) + " length; "; continue; }
            for (var _o4 = 0; _o4 < array_length(_pw); _o4++) { _gMax = max(_gMax, abs(_pg[_o4][0] - _pw[_o4][0]), abs(_pg[_o4][1] - _pw[_o4][1])); _gPts++; }
        }
    }
    for (var _g2 = 0; _g2 < array_length(_G.traits); _g2++) { var _tg = brk_bracket_trait(_G.traits[_g2].b), _tw = _G.traits[_g2].got; if (_tg.brace != _tw.brace || _tg.leaves != _tw.leaves || _tg.plateH != _tw.plateH) _gb += "trait " + _G.traits[_g2].b + "; "; }
    if (!(_gMax < 0.000000001)) _gb += "point max error " + string_format(_gMax, 1, 12) + "; ";
    if (_gPts < 250) _gb += "only " + string(_gPts) + " spine points compared; ";
    _st.metrics.spineMaxErr = _gMax; _st.metrics.spinePoints = _gPts;
    brk_st_assert(_st, _gb == "", "bracket spines (" + string(_gPts) + " points) and traits against the MZ kit: " + _gb);
    // ---- 11: the generated device table parses to the MZ numbers, and every mark's measured bounds ----
    brk_st_stage(_st, 11);
    var _db = "", _dMax = 0;
    for (var _d1 = 0; _d1 < array_length(_G.digest); _d1++) {
        var _dw = _G.digest[_d1], _prims = brk_device_prims(_dw.d), _acc = { s: 0, n: 0 };
        brk__st_sum(_prims, _acc);
        if (array_length(_prims) != _dw.prims || _acc.n != _dw.nums) _db += _dw.d + " prims " + string(array_length(_prims)) + "/" + string(_dw.prims) + " nums " + string(_acc.n) + "/" + string(_dw.nums) + "; ";
        _dMax = max(_dMax, abs(_acc.s - _dw.sum));
    }
    for (var _d2 = 0; _d2 < array_length(_G.bounds); _d2++) {
        var _bg = brk_device_bounds(_G.bounds[_d2].d), _bw = _G.bounds[_d2].got, _bv = [_bg.minX, _bg.minY, _bg.maxX, _bg.maxY, _bg.w, _bg.h];
        for (var _d3 = 0; _d3 < 6; _d3++) _dMax = max(_dMax, abs(_bv[_d3] - _bw[_d3]));
    }
    var _bu = brk_device_bounds("nonsense");
    if (array_length(brk_device_prims("nonsense")) != 0 || !(_bu.w < 0) || array_length(brk_device_prims(undefined)) != 0) _db += "unknown device is not empty; ";
    if (!(_dMax < 0.000000001)) _db += "max error " + string_format(_dMax, 1, 12) + "; ";
    _st.metrics.deviceMaxErr = _dMax;
    brk_st_assert(_st, _db == "", "12 devices (prims, numbers, sums) and their bounds against the MZ kit: " + _db);
    // ---- 12: geometry(p, height) over every board x bracket x 3 heights + 7 edge cases, every field ----
    brk_st_stage(_st, 12);
    var _F = _G.fields, _nf = array_length(_F), _eb = 0, _eFirst = "", _eMax = 0, _eNums = 0;
    for (var _e1 = 0; _e1 < array_length(_G.geo); _e1++) {
        var _row = _G.geo[_e1], _gg = brk_geometry(_row.p, _row.h), _w = _row.row;
        var _mine = array_create(_nf + 3);
        for (var _f1 = 0; _f1 < _nf; _f1++) _mine[_f1] = brk__st_at(_gg, _F[_f1]);
        _mine[_nf] = brk__geo_bx(_gg, -1); _mine[_nf + 1] = brk__geo_bx(_gg, 0.37); _mine[_nf + 2] = brk__geo_by(_gg, _gg.yMin + _gg.span * 0.5);
        var _why = "";
        for (var _f2 = 0; _f2 < _nf + 3; _f2++) {
            var _dd = abs(_mine[_f2] - _w[_f2]) / max(1, abs(_w[_f2]));
            _eMax = max(_eMax, _dd); _eNums++;
            if (!(_dd < 0.000000001) && _why == "") _why = ((_f2 < _nf) ? _F[_f2] : "bx/by " + string(_f2 - _nf)) + " got " + string_format(_mine[_f2], 1, 10) + " want " + string_format(_w[_f2], 1, 10);
        }
        if (_why != "") { _eb++; if (_eFirst == "") _eFirst = string(_row.p.board) + "/" + string(_row.p.bracket) + " h " + string(_row.h) + ": " + _why; }
    }
    _st.metrics.geometryMaxRelErr = _eMax; _st.metrics.geometryNumbers = _eNums;
    brk_st_assert(_st, _eb == 0 && _eNums >= 15000, string(array_length(_G.geo)) + " geometries x " + string(_nf + 3) + " numbers (" + string(_eNums) + ") against the MZ kit, " + string(_eb) + " differ " + _eFirst);
    math_set_epsilon(_eps0);
    brk_st_draw(_st, _O);
    brk_st_sign(_st);
    brk_st_demo(_st);
    brk_st_stage(_st, 99);
    return _st;
}

/// @function brk__st_ink(sprite)
/// @description Internal. How many pixels of a sprite carry ink (alpha > 16), read back off a surface - never assumed from
/// the sprite existing. Returns -1 when the sprite does not exist.
function brk__st_ink(_spr) {
    if (_spr == -1 || !sprite_exists(_spr)) return -1;
    var _w = sprite_get_width(_spr), _h = sprite_get_height(_spr);
    var _sf = surface_create(_w, _h);
    surface_set_target(_sf); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_zero); draw_sprite(_spr, 0, sprite_get_xoffset(_spr), sprite_get_yoffset(_spr)); gpu_pop_state();
    surface_reset_target();
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    var _n = 0;
    for (var _i = 3; _i < _w * _h * 4; _i += 4) if (buffer_peek(_b, _i, buffer_u8) > 16) _n++;
    buffer_delete(_b); surface_free(_sf);
    return _n;
}

/// @function brk__st_edge_ink(sprite)
/// @description Internal. How many pixels in the outermost 2-pixel frame of a sprite carry ink (alpha > 16): anything but 0
/// means the drawing ran off the sprite. -1 for a sprite that does not exist.
function brk__st_edge_ink(_spr) {
    if (_spr == -1 || !sprite_exists(_spr)) return -1;
    var _w = sprite_get_width(_spr), _h = sprite_get_height(_spr);
    var _sf = surface_create(_w, _h);
    surface_set_target(_sf); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_zero); draw_sprite(_spr, 0, sprite_get_xoffset(_spr), sprite_get_yoffset(_spr)); gpu_pop_state();
    surface_reset_target();
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    var _n = 0;
    global.brk_st_edge_sides = [0, 0, 0, 0];   // top, bottom, left, right - for the failure message
    for (var _y = 0; _y < _h; _y++) for (var _x = 0; _x < _w; _x++) {
        if (_y >= 2 && _y < _h - 2 && _x >= 2 && _x < _w - 2) continue;
        if (buffer_peek(_b, (_y * _w + _x) * 4 + 3, buffer_u8) > 16) {
            _n++;
            if (_y < 2) global.brk_st_edge_sides[0]++; else if (_y >= _h - 2) global.brk_st_edge_sides[1]++; else if (_x < 2) global.brk_st_edge_sides[2]++; else global.brk_st_edge_sides[3]++;
        }
    }
    buffer_delete(_b); surface_free(_sf);
    return _n;
}

/// @function brk_st_sign(st)
/// @description Stages 15-16. 15: the demo town's 48 shops read by the GML reader exactly as the MZ edition reads them, and
/// resolving to 48 different signs. 16: the bake - a sign sprite carries ink (positive control first), the cache returns the
/// same sprite, a weathered profile is a DIFFERENT sprite, the box is the sprite's size, a 0.1 ms budget prepares one sign
/// per call, every bad input is refused with -1 / false / undefined, and the cache clears.
function brk_st_sign(_st) {
    brk_st_stage(_st, 15);
    var _town = brk_demo_town(), _want = brk_demo_town_oracle(), _bad = 0, _first = "", _tuples = {}, _distinct = 0;
    for (var _i = 0; _i < array_length(_town); _i++) {
        var _p = brk_profile(_town[_i]), _w = _want[_i];
        if (_p.key != _w[0] || _p.device != _w[1] || _p.board != _w[2] || _p.bracket != _w[3] || _p.scheme != _w[4] || _p.weathering != _w[5] || _p.standing != _w[6]) { _bad++; if (_first == "") _first = _p.key + " got " + brk_tuple(_p) + " w" + string(_p.weathering) + " want " + _w[1] + "/" + _w[2] + "/" + _w[3] + "/" + _w[4] + " w" + string(_w[5]); }
        var _t = brk_tuple(_p);
        if (!variable_struct_exists(_tuples, _t)) { _tuples[$ _t] = 1; _distinct++; }
    }
    brk_st_assert(_st, array_length(_town) == 48 && _bad == 0 && _distinct == 48, "the demo town: 48 shops read exactly as the MZ edition reads them (" + string(_bad) + " differ) and resolving to " + string(_distinct) + " different signs " + _first);
    _st.metrics.demoDistinctSigns = _distinct;

    brk_st_stage(_st, 16);
    brk_sign_cache_clear();
    var _sb = "";
    // positive control: an empty sprite reads zero ink and a filled one reads every pixel
    var _cs = surface_create(40, 30); surface_set_target(_cs); draw_clear_alpha(c_black, 0); surface_reset_target();
    var _empty = sprite_create_from_surface(_cs, 0, 0, 40, 30, false, false, 0, 0);
    surface_set_target(_cs); draw_clear_alpha(c_red, 1); surface_reset_target();
    var _full = sprite_create_from_surface(_cs, 0, 0, 40, 30, false, false, 0, 0);
    surface_free(_cs);
    var _e0 = brk__st_ink(_empty), _e1 = brk__st_ink(_full);
    brk__flush_draws(); sprite_delete(_empty); sprite_delete(_full);
    if (_e0 != 0 || _e1 != 1200) _sb += "ink control read " + string(_e0) + " / " + string(_e1) + " (want 0 / 1200); ";
    var _prof = brk_profile(_town[0]);
    var _t0 = get_timer();
    var _spr = brk_sign_sprite(_prof, 150);
    var _bakeMs = (get_timer() - _t0) / 1000;
    var _box = brk_sign_box(_prof, 150);
    var _ink = brk__st_ink(_spr);
    if (_spr == -1 || sprite_get_width(_spr) != _box.w || sprite_get_height(_spr) != _box.h) _sb += "sprite size is not the box; ";
    if (!(_ink > _box.w * _box.h * 0.20)) _sb += "a 150 px sign inks only " + string(_ink) + " of " + string(_box.w * _box.h) + " px; ";
    var _counts = brk__sign_counts(_prof, 150);
    if (!is_struct(_counts) || _counts.device <= 0 || _counts.glyphs <= 0 || _counts.links <= 0) _sb += "the bake drew no device, glyphs or chain; ";
    if (brk_sign_sprite(_prof, 150) != _spr || !brk_sign_ready(_prof, 150)) _sb += "the cache did not return the same sprite; ";
    var _worn = brk_profile({ name: _town[0].name, goods: _town[0].goods, prosperity: 0 });
    var _sprW = brk_sign_sprite(_worn, 150);
    if (_worn.weathering == _prof.weathering) _sb += "the poor district did not weather the sign (" + string(_worn.weathering) + "); ";
    if (_sprW == _spr || _sprW == -1) _sb += "a weathered sign came back as the SAME sprite (the cache key ignored the weathering); ";
    var _swing = brk_sign_sprite(_prof, 150, { swing: 4 });
    if (_swing == _spr || brk__st_ink(_swing) <= 0) _sb += "a swung sign is not its own sprite; ";
    // nothing a sign draws may touch the edge of its own sprite: a bake that clips loses the board's rim or a swung corner
    // (MEASURED 2026-10-07 in the buyer render: the MZ box height, height * 1.06, cut both at 150 px)
    var _edgeMax = 0, _edgeWhere = "";
    // (shops 0, 7 and 9: none of them is in the budget list below, so this cannot pre-bake that test's signs)
    var _ep = [_prof, brk_profile(_town[7]), brk_profile(_town[9])], _es = [0, 8, -8], _eh = [150, 96];
    for (var _a = 0; _a < 3; _a++) for (var _b2 = 0; _b2 < 3; _b2++) for (var _c2 = 0; _c2 < 2; _c2++) {
        var _e = brk__st_edge_ink(brk_sign_sprite(_ep[_a], _eh[_c2], { swing: _es[_b2] }));
        if (_e > _edgeMax) { _edgeMax = _e; var _sd = global.brk_st_edge_sides; _edgeWhere = _ep[_a].name + " swing " + string(_es[_b2]) + " at " + string(_eh[_c2]) + ": top " + string(_sd[0]) + " bottom " + string(_sd[1]) + " left " + string(_sd[2]) + " right " + string(_sd[3]); }
    }
    if (_edgeMax > 0) _sb += "a sign touches its sprite's edge: " + string(_edgeMax) + " px (" + _edgeWhere + "); ";
    _st.metrics.edgeInkMax = _edgeMax;
    // the budget: a 0.1 ms budget still bakes ONE sign per call, and finishes after as many calls as signs
    var _list = [brk_profile(_town[1]), brk_profile(_town[2]), brk_profile(_town[3]), "not a profile", undefined];
    var _calls = 0, _done = false, _tp = get_timer();
    while (!_done && _calls < 20) { _done = brk_prepare(_list, 96, 0.1); _calls++; }
    _st.metrics.bakeMs96Mean = (get_timer() - _tp) / 1000 / 3;
    if (!_done || _calls != 3) _sb += "a 0.1 ms budget prepared 3 signs in " + string(_calls) + " calls (want 3); ";
    // refusals
    if (brk_sign_sprite(undefined, 150) != -1 || brk_sign_sprite({}, 150) != -1 || brk_sign_sprite(_prof, "tall") != -1 || brk_sign_sprite(_prof, undefined) != -1) _sb += "a bad profile or height was not refused; ";
    if (!is_undefined(brk_sign_box("x", 150)) || brk_sign_ready(_prof, -infinity) || brk_prepare(_list, "x") != false || brk_prepare("nothing", 150) != true) _sb += "a bad box/ready/prepare call was not refused; ";
    var _cx = brk_cx_create(1);
    if (brk_draw_plaque(undefined, _prof, 0, 0, 100, 40) != 0 || brk_draw_plaque(_cx, _prof, 0, 0, 2, 40) != 0 || brk_draw_lintel(_cx, "w", 40) != 0) _sb += "a bad plaque/lintel call was not refused; ";
    var _held = brk_sign_cache_count();
    var _freed = brk_sign_cache_clear();
    if (_held < 6 || _freed != _held || brk_sign_cache_count() != 0 || sprite_exists(_spr)) _sb += "the cache held " + string(_held) + ", freed " + string(_freed) + "; ";
    brk_st_assert(_st, _sb == "", "the bake: ink " + string(_ink) + " px in a " + string(_box.w) + "x" + string(_box.h) + " sprite, cache, weathering, swing, budget, refusals, clear: " + _sb);
    _st.metrics.bakeMs150 = _bakeMs;
    _st.metrics.bakeInk150 = _ink;
}

/// @function brk__st_save_view(demo, file)
/// @description Internal. Draw the demo's current view (painting everything it needs first) into a 960 x 640 surface and
/// save it. Returns the ink-variance proxy: how many of 96 sampled cells differ from the first cell's colour.
function brk__st_save_view(_d, _file) {
    var _guard = 0;
    while (!brk_demo_prepare(_d, 100000) && _guard < 400) _guard++;
    var _sf = surface_create(BRK_DEMO_W, BRK_DEMO_H);
    surface_set_target(_sf);
    draw_clear(c_black);
    brk_demo_draw(_d, 0, 0);
    surface_reset_target();
    surface_save(_sf, _file);
    var _b = buffer_create(BRK_DEMO_W * BRK_DEMO_H * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _sf, 0);
    var _o0 = 0, _r0 = buffer_peek(_b, 0, buffer_u8), _g0 = buffer_peek(_b, 1, buffer_u8), _b0 = buffer_peek(_b, 2, buffer_u8), _var = 0;
    for (var _y = 0; _y < 8; _y++) for (var _x = 0; _x < 12; _x++) {
        var _o = ((_y * 80 + 40) * BRK_DEMO_W + (_x * 80 + 40)) * 4;
        if (abs(buffer_peek(_b, _o, buffer_u8) - _r0) + abs(buffer_peek(_b, _o + 1, buffer_u8) - _g0) + abs(buffer_peek(_b, _o + 2, buffer_u8) - _b0) > 24) _var++;
    }
    buffer_delete(_b); surface_free(_sf);
    return _var;
}

/// @function brk_st_demo(st)
/// @description Stage 17: THE HIGH STREET run headless - painted in full, scripted through every key, and each view saved
/// for LOOKING (brk_render_*.png): the street in two districts, the Close Look, the Yard, a restocked shop and a weathered
/// street. Asserts that restocking changes the sign, that weathering moves every sign on the street, and that each view is
/// a picture rather than a flat fill.
function brk_st_demo(_st) {
    brk_st_stage(_st, 17);
    var _db = "", _t0 = get_timer();
    var _d = brk_demo_create();
    _d.shop = 4; _d.camx = brk__demo_cam_for(4); _d.cam_target = _d.camx;
    var _v1 = brk__st_save_view(_d, "brk_render_street_gilt.png");
    var _dev0 = _d.profiles[brk__demo_index(_d, 4)].device;
    brk_demo_step(_d, { right: true });
    if (_d.shop != 5) _db += "RIGHT did not walk the street; ";
    brk_demo_step(_d, { left: true });
    var _np = brk_demo_restock(_d);
    var _restocks = 1;
    while (_np.device == _dev0 && _restocks < 12) { _np = brk_demo_restock(_d); _restocks++; }
    if (_np.device == _dev0) _db += "twelve restocks never changed the sign's device; ";
    _d.camx = _d.cam_target;
    var _v2 = brk__st_save_view(_d, "brk_render_street_restocked.png");
    var _before = [];
    for (var _s = 0; _s < 12; _s++) array_push(_before, _d.profiles[brk__demo_index(_d, _s)].weathering);
    var _pros = brk_demo_weather(_d);
    _pros = brk_demo_weather(_d);
    _pros = brk_demo_weather(_d);
    var _moved = 0;
    for (var _s2 = 0; _s2 < 12; _s2++) if (_d.profiles[brk__demo_index(_d, _s2)].weathering != _before[_s2]) _moved++;
    if (_pros != 1 || _moved < 8) _db += "three steps down left prosperity " + string(_pros) + " and moved " + string(_moved) + " of 12 signs; ";
    var _v3 = brk__st_save_view(_d, "brk_render_street_weathered.png");
    brk_demo_step(_d, { down: true });
    brk_demo_step(_d, { down: true });
    brk_demo_step(_d, { down: true });
    if (_d.district != 3) _db += "DOWN x3 did not reach Netherbank; ";
    _d.camx = _d.cam_target;
    var _v4 = brk__st_save_view(_d, "brk_render_street_nether.png");
    brk_demo_step(_d, { down: true });
    brk_demo_step(_d, { look: true });
    if (_d.mode != "look" || _d.district != 0) _db += "ENTER did not open the Close Look in the Gilt Quarter; ";
    _d.shop = 0;
    var _v5 = brk__st_save_view(_d, "brk_render_look.png");
    brk_demo_step(_d, { yard: true });
    if (_d.mode != "yard") _db += "Y did not open the Yard from the Close Look; ";
    var _v6 = brk__st_save_view(_d, "brk_render_yard.png");
    brk_demo_step(_d, { back: true });
    if (_d.mode != "street") _db += "back did not return to the street; ";
    var _views = [_v1, _v2, _v3, _v4, _v5, _v6];
    // the floor catches a view that was never painted (a flat fill reads 0-2 of 96). It is NOT a beauty bar: the Yard is a
    // dark board by design and read 36 on its first run (2026-10-07), the streets 73-86 - and every view is LOOKED AT.
    for (var _k = 0; _k < 6; _k++) if (_views[_k] < 24) _db += "view " + string(_k) + " is nearly flat (" + string(_views[_k]) + " of 96 cells differ); ";
    brk_demo_free(_d);
    if (brk_sign_cache_count() != 0) _db += "brk_demo_free left " + string(brk_sign_cache_count()) + " signs baked; ";
    brk_st_assert(_st, _db == "", "THE HIGH STREET headless: six views saved and varied (" + string(_v1) + "/" + string(_v2) + "/" + string(_v3) + "/" + string(_v4) + "/" + string(_v5) + "/" + string(_v6) + " of 96 cells), restock changed the device after " + string(_restocks) + ", weathering moved " + string(_moved) + " of 12: " + _db);
    _st.metrics.demoMs = (get_timer() - _t0) / 1000;
}

/// @function brk__st_rel(got, want)
/// @description Internal. |got - want| / max(1, |want|) - the relative error the drawing stages bound by 1e-9.
function brk__st_rel(_g, _w) { return abs(_g - _w) / max(1, abs(_w)); }

/// @function brk_st_draw(st, oracle_read)
/// @description Stages 13-14: the painter held to the MZ edition's BracketRender run over a recording canvas
/// (brk_oracle_draw). 13: 40 line fits and 6 grid solves, every field. 14: 215 drawings - 24 devices, 186 signs (62
/// profiles x 3 heights, swing and the colour behind cycled), 2 streets, 3 yards (one the named refusal) - drawn through
/// the GML painter with the test log on, into a scratch surface; event count, log length and FNV hash compared, plus the
/// numbers each drawing returns. The first three differing logs are drawn again and kept whole in st.drawFail, for an
/// offline diff against Internal_Ops/oracle_draw_logs.json.
function brk_st_draw(_st, _O) {
    var _D = brk_oracle_draw();
    // ⛔ the comparisons below bound errors by 1e-9: under the DEFAULT epsilon (1e-5) `0 < 1e-9` is FALSE and `x > 1e-9`
    // is false for every x under 1e-5, so every fit read as differing and the grid check passed vacuously (MEASURED
    // 2026-10-07: 40 of 40 fits "differ" at max error 2.4e-17). Run at the floor and put the caller's epsilon back.
    var _eps0 = math_get_epsilon();
    math_set_epsilon(0);
    // ---- 13: line fits + grid solves ----
    brk_st_stage(_st, 13);
    var _fb = 0, _fFirst = "", _fMax = 0;
    for (var _i = 0; _i < array_length(_D.fits); _i++) {
        var _r = _D.fits[_i];
        var _f = brk_fit_line(_D.fit_names[_r[0]], _r[2], _r[5], _r[3], _r[4]);
        var _e = max(brk__st_rel(_f.size, _r[6]), brk__st_rel(_f.tracking, _r[7]), brk__st_rel(_f.squeeze, _r[8]), brk__st_rel(_f.width, _r[9]));
        _fMax = max(_fMax, _e);
        if (!(_e < 0.000000001) || (_f.fits ? 1 : 0) != _r[10]) { _fb++; if (_fFirst == "") _fFirst = "'" + _D.fit_names[_r[0]] + "' at " + string(_r[2]) + " in " + string(_r[3]) + ": size " + string_format(_f.size, 1, 6) + " want " + string_format(_r[6], 1, 6) + ", width " + string_format(_f.width, 1, 6) + " want " + string_format(_r[9], 1, 6); }
    }
    var _gb = 0, _gFirst = "";
    for (var _j = 0; _j < array_length(_D.grids); _j++) {
        var _q = _D.grids[_j], _s = brk_solve_grid(_q[0], _q[1], _q[2]);
        if (!is_struct(_s) || _s.cols != _q[3] || _s.rows != _q[4] || brk__st_rel(_s.cellW, _q[5]) > 0.000000001 || brk__st_rel(_s.cellH, _q[6]) > 0.000000001 || brk__st_rel(_s.signH, _q[7]) > 0.000000001 || _s.empties != _q[8]) { _gb++; if (_gFirst == "") _gFirst = string(_q[0]) + " in " + string(_q[1]) + "x" + string(_q[2]); }
    }
    var _gu = brk_solve_grid(0, 100, 100);
    brk_st_assert(_st, _fb == 0 && _gb == 0 && array_length(_D.fits) == 40 && array_length(_D.grids) == 6 && is_undefined(_gu), "40 line fits (" + string(_fb) + " differ, max rel error " + string_format(_fMax, 1, 12) + ") and 6 grid solves (" + string(_gb) + " differ) against the MZ painter; no signs = no grid " + _fFirst + _gFirst);
    _st.metrics.fitMaxRelErr = _fMax;
    // ---- 14: every drawing, paint event for paint event ----
    brk_st_stage(_st, 14);
    _st.drawFail = [];
    var _t0 = get_timer(), _bad = 0, _events = 0, _kinds = [0, 0, 0, 0], _first = "";
    var _profs = array_create(array_length(_O.profiles));
    for (var _p = 0; _p < array_length(_O.profiles); _p++) _profs[_p] = brk_profile(_O.profiles[_p].shop);
    var _sf = surface_create(1280, 840);
    for (var _k = 0; _k < array_length(_D.cases); _k++) {
        var _row = _D.cases[_k];
        var _res = brk__st_draw_case(_sf, _row, _profs, _D, 0);
        _events += _res.events;
        _kinds[_row[0]] += 1;
        if (_res.events != _row[7] || _res.len != _row[8] || _res.hash != _row[9] || _res.a != _row[5] || _res.b != _row[6]) {
            _bad++;
            if (_first == "") _first = "draw #" + string(_k) + " kind " + string(_row[0]) + " [" + string(_row[1]) + "," + string(_row[2]) + "," + string(_row[3]) + "]: events " + string(_res.events) + " vs " + string(_row[7]) + ", length " + string(_res.len) + " vs " + string(_row[8]) + ", returns " + string(_res.a) + "/" + string(_res.b) + " vs " + string(_row[5]) + "/" + string(_row[6]);
            if (array_length(_st.drawFail) < 3) { var _again = brk__st_draw_case(_sf, _row, _profs, _D, 2000000); array_push(_st.drawFail, { index: _k, log: _again.text }); }
        }
    }
    surface_free(_sf);
    brk_st_assert(_st, array_length(_D.cases) == 215 && _kinds[0] == 24 && _kinds[1] == 186 && _kinds[2] == 2 && _kinds[3] == 3, "draw oracle rows 215 (24/186/2/3): " + string(array_length(_D.cases)));
    brk_st_assert(_st, _bad == 0, string(_bad) + " of " + string(array_length(_D.cases)) + " drawings paint differently from the MZ edition " + _first);
    brk_st_assert(_st, _events == 30889, "paint events " + string(_events) + " (MZ 30889)");
    _st.metrics.drawCompared = array_length(_D.cases);
    _st.metrics.drawEvents = _events;
    _st.metrics.drawOracleMs = (get_timer() - _t0) / 1000;
    math_set_epsilon(_eps0);
}

/// @function brk__st_draw_case(surface, row, profiles, oracle, keep)
/// @description Internal. One oracle drawing through the GML painter with the test log on. Returns { events, len, hash,
/// text, a, b } where a and b are the two numbers the oracle row records from what the drawing returned.
function brk__st_draw_case(_sf, _row, _profs, _D, _keep) {
    surface_set_target(_sf);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    var _c = brk_cx_create(1);
    brk_log_begin(_c, _keep);
    var _a = 0, _b = 0;
    if (_row[0] == 0) {
        var _ids = brk_tables().devices;
        _a = brk_draw_device(_c, _ids[_row[1]], 120, 90, _row[3], _row[4], "#e8c860", "#5a4a20");
        _b = 0;
    } else if (_row[0] == 1) {
        var _opt = {};
        if (_row[3] != 0) _opt.swing = _row[3];
        var _bh = _D.behind[_row[4]];
        if (!is_undefined(_bh)) _opt.behind = _bh;
        var _o = brk_draw_sign(_c, _profs[_row[1]], 20, 10, _row[2], _opt);
        _a = _o.device; _b = _o.glyphs;
    } else if (_row[0] == 2) {
        var _s = brk_draw_street(_c, _row[1], _row[2], _row[3]);
        _a = _s.gables; _b = _s.distantSigns;
        // the row records lanterns in slot 4 and gables/distant in 5/6
        if (_s.lanterns != _row[4]) _a = -1;
    } else {
        var _list = [];
        for (var _i = _row[1]; _i < _row[1] + _row[2]; _i++) array_push(_list, _profs[_i]);
        var _y = brk_draw_yard(_c, _list, _row[3], _row[4]);
        _a = _y.cols * 100 + _y.rows; _b = _y.drawn;
    }
    var _l = brk_log_end(_c);
    gpu_pop_state();
    surface_reset_target();
    return { events: _l.events, len: _l.len, hash: _l.hash, text: _l.text, a: _a, b: _b };
}

/// @function brk_selftest_write(state)
function brk_selftest_write(_st) {
    var _f = file_text_open_write("brk_selftest.json");
    file_text_write_string(_f, json_stringify(_st));
    file_text_close(_f);
}
