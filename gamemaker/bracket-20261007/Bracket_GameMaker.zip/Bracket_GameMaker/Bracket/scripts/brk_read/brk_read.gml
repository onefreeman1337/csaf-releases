/// brk_read.gml - Bracket's reader: what a shop SELLS decides the sign it hangs. A port, line for line, of the RPG Maker MZ
/// edition's BracketRead.js, held to that code by Internal_Ops/oracle_read.json (hashes, rng streams, ladders, standings and
/// 62 full profiles). Pure GML: no rooms, layers, sprites or instances are touched.
///
/// A SHOP is a struct you build from your own data:
///     { name: "The Gilded Tankard", prosperity: 3,
///       goods: [ { kind: "item", name: "Ale", price: 8, effects: [] }, { kind: "weapon", name: "Iron Sword", price: 900 } ] }
/// goods rows: kind ("item" | "weapon" | "armor"), name, price, and optionally itypeId (2 = a key item), etypeId (2 shield,
/// 3 head, 4 body, 5 accessory), typeName (your own word for the type, e.g. "Staff"), effects [{ code, dataId, value1 }]
/// (11 HP / 12 MP recover, 22 remove state, 21 add state, 42 grow). The hand always wins: device, board, bracket, scheme,
/// weathering and trade set on the shop override what the reader would decide.
///
/// Public functions (each documented below): brk_profile, brk_score_devices, brk_standing, brk_ladder_from,
/// brk_use_price_ladder, brk_tuple, brk_volume, brk_default_name, brk_hash.
///
/// ⛔ PORTING NOTES (the JS this must equal): the FNV step is h * 16777619 mod 2^32 (int64 here, exact); the generator is
/// xorshift32 whose middle `>>` is a SIGNED shift (sign-extended here); Math.round is floor(x + 0.5); JS Number("") is 0;
/// two draws in one expression are split into statements (GML evaluates arguments right to left); struct key order is not
/// insertion order in GML, so every loop walks brk_tables().devices.

/// @function brk__low(value)
/// @description Internal. Lower-cased text, never undefined (JS low()).
function brk__low(_v) { return is_undefined(_v) ? "" : string_lower(string(_v)); }

/// @function brk__fin(value, default)
/// @description Internal. JS Number(v), then the default when not finite: "" and undefined-as-null are handled as JS does.
function brk__fin(_v, _d) {
    if (is_undefined(_v)) return _d;
    if (is_bool(_v)) return _v ? 1 : 0;
    if (is_numeric(_v)) { var _n = real(_v); return (is_nan(_n) || is_infinity(_n)) ? _d : _n; }
    if (is_string(_v)) {
        var _t = string_trim(_v);
        if (_t == "") return 0;                          // JS Number("") === 0
        var _ok = true, _dots = 0, _digits = 0;
        for (var _i = 1; _i <= string_length(_t); _i++) {
            var _c = string_char_at(_t, _i);
            if (_c == "." ) _dots++;
            else if ((_c == "-" || _c == "+") && _i == 1) { }
            else if (ord(_c) >= 48 && ord(_c) <= 57) _digits++;
            else { _ok = false; break; }
        }
        if (!_ok || _dots > 1 || _digits == 0) return _d;
        return real(_t);
    }
    return _d;
}

/// @function brk__words_hit(text, words)
/// @description Internal. Whether any word in the array occurs in the text (JS indexOf >= 0).
function brk__words_hit(_text, _words) {
    for (var _i = 0; _i < array_length(_words); _i++) if (string_pos(_words[_i], _text) > 0) return true;
    return false;
}

/// @function brk_hash(text)
/// @description A stable unsigned 32-bit hash of a string (FNV-1a, as the MZ edition). The same shop gets the same sign on
/// every run, so nothing in Bracket uses the engine's random functions.
/// @param {String} text
/// @returns {Real} 0 .. 4294967295
function brk_hash(_s) {
    var _str = is_undefined(_s) ? "" : string(_s);
    var _h = int64(2166136261);
    for (var _i = 1; _i <= string_length(_str); _i++) {
        _h = ((_h ^ int64(ord(string_char_at(_str, _i)))) * int64(16777619)) & int64($FFFFFFFF);
    }
    return real(_h);
}

/// @function brk__rng(seed)
/// @description Internal. A xorshift32 stream as a struct { s }; draw with brk__rng_next.
function brk__rng(_seed) {
    var _s = floor(brk__fin(_seed, 0));
    _s = ((_s mod 4294967296) + 4294967296) mod 4294967296;      // JS seed >>> 0
    if (_s == 0) _s = 1;
    return { s: int64(_s) };
}

/// @function brk__rng_next(rng)
/// @description Internal. The next value in [0, 1), exactly as the MZ rng(): s ^= s << 13; s ^= s >> 17 (signed); s ^= s << 5.
function brk__rng_next(_r) {
    var _m = int64($FFFFFFFF);
    var _s = _r.s;
    _s = (_s ^ ((_s << 13) & _m)) & _m;
    var _t = _s >> 17;                                  // logical on a non-negative int64...
    if (_s >= int64(2147483648)) _t = _t | int64($FFFF8000);   // ...sign-extended as JS's int32 >> does
    _s = (_s ^ _t) & _m;
    _s = (_s ^ ((_s << 5) & _m)) & _m;
    _r.s = _s;
    return real(_s) / 4294967296;
}

/// @function brk__num_str(value)
/// @description Internal. A number as JS String() writes it, for the integer and short-decimal prices a goods list holds.
function brk__num_str(_x) {
    if (_x == floor(_x) && abs(_x) < 1000000000000000) return string(int64(_x));
    var _s = string_trim(string_format(_x, 1, 10));
    while (string_char_at(_s, string_length(_s)) == "0") _s = string_delete(_s, string_length(_s), 1);
    if (string_char_at(_s, string_length(_s)) == ".") _s = string_delete(_s, string_length(_s), 1);
    return _s;
}

/// @function brk_score_devices(goods, shop_name)
/// @description Score the twelve trade devices against a shop's goods and name: STRUCTURE 3 points (kind, equip slot,
/// effect), the goods' NAMES 2, the shop's NAME 1. Ties break on the fixed device order.
/// @param {Array} goods
/// @param {String} shop_name
/// @returns {Struct} { scores, top, runner_up, margin }
function brk_score_devices(_goods, _shopName) {
    var _T = brk_tables(), _D = _T.devices;
    var _sc = {};
    for (var _d = 0; _d < array_length(_D); _d++) _sc[$ _D[_d]] = 0;
    var _rows = is_array(_goods) ? _goods : [];
    var _silent = 0;
    for (var _i = 0; _i < array_length(_rows); _i++) {
        var _g = is_struct(_rows[_i]) ? _rows[_i] : {};
        var _name = brk__low(_g[$ "name"]), _tn = brk__low(_g[$ "typeName"]);
        var _kind = is_string(_g[$ "kind"]) ? _g.kind : "";
        if (_kind == "weapon") {
            if (brk__words_hit(_tn, ["staff", "wand", "rod", "tome", "grimoire"])) _sc.scroll += 3; else _sc.swordAnvil += 3;
        } else if (_kind == "armor") {
            var _et = brk__fin(_g[$ "etypeId"], 0);
            if (_et == 2 || brk__words_hit(_tn, ["shield", "buckler", "targe"])) _sc.shield += 3;
            else if (_et == 5) _sc.gem += 3;
            else if (brk__words_hit(_tn, ["light", "cloth", "robe", "magic"])) _sc.shears += 3;
            else if (_et == 3 || _et == 4) { _sc.shield += 2; _sc.shears += 1; }
            else _sc.shield += 2;
        } else {
            var _fx = is_array(_g[$ "effects"]) ? _g.effects : [];
            var _spoke = false;
            for (var _e = 0; _e < array_length(_fx); _e++) {
                var _code = brk__fin(is_struct(_fx[_e]) ? _fx[_e][$ "code"] : undefined, -1);
                if (_code == BRK_EFFECT_HP || _code == BRK_EFFECT_MP) { _sc.flask += 3; _spoke = true; }
                else if (_code == BRK_EFFECT_REMOVE_STATE) { _sc.herb += 3; _spoke = true; }
                else if (_code == BRK_EFFECT_ADD_STATE || _code == BRK_EFFECT_GROW) { _sc.scroll += 3; _spoke = true; }
            }
            if (brk__fin(_g[$ "itypeId"], 1) == 2) { _sc.key += 3; _spoke = true; }
            if (!_spoke) _silent++;
        }
        for (var _k = 0; _k < array_length(_D); _k++) if (brk__words_hit(_name, _T.words[$ _D[_k]])) _sc[$ _D[_k]] += 2;
    }
    var _sn = brk__low(_shopName);
    if (_sn != "") for (var _n = 0; _n < array_length(_D); _n++) if (brk__words_hit(_sn, _T.words[$ _D[_n]])) _sc[$ _D[_n]] += 1;
    var _any = false;
    for (var _t = 0; _t < array_length(_D); _t++) if (_sc[$ _D[_t]] > 0) _any = true;
    if (!_any && _silent > 0) { _sc.flask += 1; _any = true; }
    if (!_any) _sc.key += 1;
    var _best = _D[0], _second = _D[0];
    for (var _r = 0; _r < array_length(_D); _r++) if (_sc[$ _D[_r]] > _sc[$ _best]) _best = _D[_r];
    var _ss = -1;
    for (var _r2 = 0; _r2 < array_length(_D); _r2++) {
        if (_D[_r2] == _best) continue;
        if (_sc[$ _D[_r2]] > _ss) { _ss = _sc[$ _D[_r2]]; _second = _D[_r2]; }
    }
    return { scores: _sc, top: _best, runner_up: _second, margin: _sc[$ _best] - ((_ss < 0) ? 0 : _ss) };
}

/// @function brk__index_of(array, value)
function brk__index_of(_a, _v) { for (var _i = 0; _i < array_length(_a); _i++) if (_a[_i] == _v) return _i; return -1; }

/// @function brk__device_for(shop)
function brk__device_for(_s) {
    var _dv = _s[$ "device"];
    if (is_string(_dv) && brk__index_of(brk_tables().devices, _dv) >= 0) return _dv;
    return brk_score_devices(_s[$ "goods"], _s[$ "name"]).top;
}

/// @function brk__goods_print(shop)
/// @description Internal. A shop's stock as one string: the identity of a shop never given a name.
function brk__goods_print(_s) {
    var _rows = is_array(_s[$ "goods"]) ? _s.goods : [], _out = "";
    for (var _i = 0; _i < array_length(_rows); _i++) {
        var _g = is_struct(_rows[_i]) ? _rows[_i] : {};
        var _k = _g[$ "kind"];
        _out += ((_i > 0) ? "," : "") + ((is_string(_k) && _k != "") ? _k : "?") + ":" + brk__low(_g[$ "name"]) + ":" + brk__num_str(brk__fin(_g[$ "price"], 0));
    }
    return _out;
}

/// @function brk__name_raw(shop)
/// @description Internal. JS String(s.name || ''): a missing or empty name is "".
function brk__name_raw(_s) { return brk__js_or_blank(_s[$ "name"]); }

/// @function brk__js_or_blank(value)
/// @description Internal. JS String(v || ''): undefined, "", 0 and false give "" (each tested by TYPE first, never a mixed compare).
function brk__js_or_blank(_v) {
    if (is_undefined(_v)) return "";
    if (is_string(_v)) return _v;
    if (is_bool(_v)) return _v ? "true" : "";
    if (is_numeric(_v)) return (_v == 0 || is_nan(_v)) ? "" : brk__num_str(real(_v));
    return string(_v);
}

/// @function brk__board_for(shop, device)
/// @description Internal. The board is cut to fit the name: each outline's measured capacity (brk_capacity_of) ranks the
/// ten, a trade whose object IS a shape gets a bonus, and the hash picks among the best 3 (named) or 6 (unnamed).
function brk__board_for(_s, _device) {
    var _B = brk_tables().boards;
    var _bv = _s[$ "board"];
    if (is_string(_bv) && brk__index_of(_B, _bv) >= 0) return _bv;
    var _name = brk__name_raw(_s);
    var _len = max(1, string_length(_name));
    var _h = brk_hash("board|" + ((_name != "") ? _name : brk__goods_print(_s)) + "|" + _device);
    var _own = (_device == "tankard") ? "tankardCut" : ((_device == "key") ? "keyhole" : ((_device == "scroll") ? "scrollEnd" : ""));
    var _ranked = [];
    for (var _i = 0; _i < array_length(_B); _i++) {
        var _cap = brk_capacity_of(_B[_i]);
        var _miss = (_len > _cap) ? (_len - _cap) * 2 : (_cap - _len);
        if (_own == _B[_i]) _miss -= 3.0;
        // insertion by (miss, index): stable, never key order
        var _at = array_length(_ranked);
        while (_at > 0 && _ranked[_at - 1].miss > _miss) _at--;
        array_insert(_ranked, _at, { id: _B[_i], miss: _miss });
    }
    var _named = string_length(string_trim(_name)) > 0;
    var _n = min(array_length(_ranked), _named ? 3 : 6);
    return _ranked[_h mod _n].id;
}

/// @function brk__price_ladder()
/// @description Internal. The three price thresholds in force (the stock MZ ladder until brk_use_price_ladder replaces it).
function brk__price_ladder() { static _l = [720, 1580, 3480]; return _l; }

/// @function brk_ladder_from(prices)
/// @description Three price thresholds (the 40th, 65th and 85th percentile) from your own game's prices, or undefined
/// when fewer than four are above zero.
/// @param {Array<Real>} prices
/// @returns {Array<Real>|Undefined}
function brk_ladder_from(_prices) {
    var _ok = [];
    if (is_array(_prices)) for (var _i = 0; _i < array_length(_prices); _i++) { var _v = brk__fin(_prices[_i], 0); if (_v > 0) array_push(_ok, _v); }
    if (array_length(_ok) < 4) return undefined;
    array_sort(_ok, true);
    var _n = array_length(_ok) - 1;
    return [_ok[min(_n, floor(0.40 * _n))], _ok[min(_n, floor(0.65 * _n))], _ok[min(_n, floor(0.85 * _n))]];
}

/// @function brk_use_price_ladder(ladder)
/// @description Adopt three ascending price thresholds (from brk_ladder_from); anything else keeps the current ladder.
/// @param {Array<Real>} ladder
/// @returns {Array<Real>} a copy of the ladder now in force
function brk_use_price_ladder(_lad) {
    var _l = brk__price_ladder();
    if (is_array(_lad) && array_length(_lad) == 3 && is_numeric(_lad[0]) && is_numeric(_lad[1]) && is_numeric(_lad[2])
        && !is_nan(_lad[0]) && !is_nan(_lad[1]) && !is_nan(_lad[2]) && !is_infinity(_lad[0]) && !is_infinity(_lad[1]) && !is_infinity(_lad[2])
        && _lad[0] > 0 && _lad[1] >= _lad[0] && _lad[2] >= _lad[1]) { _l[0] = real(_lad[0]); _l[1] = real(_lad[1]); _l[2] = real(_lad[2]); }
    return [_l[0], _l[1], _l[2]];
}

/// @function brk_standing(shop)
/// @description How well a shop is doing, 0..7: depth (rows) + reach (best price against the ladder) + breadth (two kinds
/// of thing, or eight rows). It picks the bracket, poorest first.
/// @param {Struct} shop
/// @returns {Real}
function brk_standing(_s) {
    var _rows = (is_struct(_s) && is_array(_s[$ "goods"])) ? _s.goods : [];
    var _best = 0;
    for (var _i = 0; _i < array_length(_rows); _i++) { var _p = brk__fin(is_struct(_rows[_i]) ? _rows[_i][$ "price"] : undefined, 0); if (_p > _best) _best = _p; }
    var _n = array_length(_rows);
    var _depth = (_n >= 5) ? 3 : ((_n >= 3) ? 2 : ((_n >= 2) ? 1 : 0));
    var _L = brk__price_ladder();
    var _reach = (_best >= _L[2]) ? 3 : ((_best >= _L[1]) ? 2 : ((_best >= _L[0]) ? 1 : 0));
    var _kinds = [];
    for (var _k = 0; _k < _n; _k++) { var _kd = is_struct(_rows[_k]) ? _rows[_k][$ "kind"] : undefined; if (is_string(_kd) && _kd != "" && brk__index_of(_kinds, _kd) < 0) array_push(_kinds, _kd); }
    var _breadth = (array_length(_kinds) >= 2 || _n >= 8) ? 1 : 0;
    return max(0, min(7, _depth + _reach + _breadth));
}

/// @function brk__scheme_for(shop, device)
function brk__scheme_for(_s, _device) {
    var _sv = _s[$ "scheme"];
    if (is_string(_sv) && brk__index_of(brk_tables().schemes, _sv) >= 0) return _sv;
    var _field = "oak";
    switch (_device) {
        case "swordAnvil": case "shield": case "horseshoe": _field = "oxblood"; break;
        case "flask": case "herb": case "fish": _field = "verdigris"; break;
        case "scroll": case "gem": case "shears": _field = "indigo"; break;
        case "loaf": case "tankard": case "key": _field = "mustard"; break;
    }
    var _st = brk_standing(_s);
    if (_st >= 7) return "giltOak";
    if (_device == "swordAnvil" || _device == "horseshoe") return "oak";
    if (_st == 0) return "oak";
    return _field;
}

/// @function brk__blank(value)
/// @description Internal. JS `v === undefined || v === null || String(v).trim() === ''`.
function brk__blank(_v) { return is_undefined(_v) || string_trim(string(_v)) == ""; }

/// @function brk__weather_for(shop)
function brk__weather_for(_s) {
    if (!brk__blank(_s[$ "weathering"])) return max(0, min(4, floor(brk__fin(_s.weathering, 0) + 0.5)));
    var _p = brk__blank(_s[$ "prosperity"]) ? 2 : brk__fin(_s.prosperity, 2);
    _p = max(0, min(4, floor(_p + 0.5)));
    var _st = brk_standing(_s);
    var _nudge = (_st >= 6) ? -1 : ((_st <= 1) ? 1 : 0);
    return max(0, min(4, 4 - _p + _nudge));
}

/// @function brk_default_name(device)
/// @description A plain name for a shop never given one ("The Smith", "The Tavern").
/// @param {String} device
/// @returns {String}
function brk_default_name(_device) {
    var _t = brk_tables().trades[$ is_string(_device) ? _device : ""];
    if (!is_string(_t)) _t = "SHOP";
    return "The " + string_char_at(_t, 1) + string_lower(string_delete(_t, 1, 1));
}

/// @function brk_profile(shop)
/// @description The whole sign, as data: { key, name, trade, device, board, bracket, scheme, weathering, standing, tilt,
/// seed, goods_count }. Everything that draws a sign reads this and nothing else.
/// @param {Struct} shop
/// @returns {Struct}
function brk_profile(_shop) {
    var _s = is_struct(_shop) ? _shop : {};
    var _T = brk_tables();
    var _device = brk__device_for(_s);
    var _board = brk__board_for(_s, _device);
    var _bv = _s[$ "bracket"];
    var _bracket = (is_string(_bv) && brk__index_of(_T.brackets, _bv) >= 0) ? _bv : _T.brackets[brk_standing(_s)];
    var _scheme = brk__scheme_for(_s, _device);
    var _weathering = brk__weather_for(_s);
    var _name = string_trim(brk__name_raw(_s));
    if (_name == "") _name = brk_default_name(_device);
    var _seed = brk_hash(_name + "|" + _device + "|" + _board + "|" + _bracket + "|" + _scheme);
    var _r = brk__rng(_seed);
    var _mag = brk__rng_next(_r);                 // two draws, two statements: the JS order
    var _sgn = brk__rng_next(_r);
    var _tilt = (3 + _mag * 4) * ((_sgn < 0.5) ? -1 : 1);
    var _tr = brk__js_or_blank(_s[$ "trade"]);
    var _trade = (_tr == "") ? (_T.trades[$ _device] ?? "") : _tr;
    return { key: _name + "#" + _device, name: _name, trade: _trade, device: _device, board: _board, bracket: _bracket,
        scheme: _scheme, weathering: _weathering, standing: brk_standing(_s), tilt: _tilt, seed: _seed,
        goods_count: is_array(_s[$ "goods"]) ? array_length(_s.goods) : 0 };
}

/// @function brk_tuple(profile)
/// @description The tuple two signs must not share: "device/board/bracket/scheme".
/// @param {Struct} profile
/// @returns {String}
function brk_tuple(_p) { return is_struct(_p) ? (string(_p.device) + "/" + string(_p.board) + "/" + string(_p.bracket) + "/" + string(_p.scheme)) : ""; }

/// @function brk_volume([shops])
/// @description How many signs Bracket COULD compose (corpus, forms), and how many your shops RESOLVE to.
/// @param {Array<Struct>} [shops]
/// @returns {Struct} { corpus, forms, resolved, distinct_tuples, collisions }
function brk_volume(_shops = undefined) {
    var _T = brk_tables();
    var _forms = array_length(_T.devices) * array_length(_T.boards) * array_length(_T.brackets) * array_length(_T.schemes);
    var _out = { corpus: _forms * 5, forms: _forms, resolved: 0, distinct_tuples: 0, collisions: [] };
    if (!is_array(_shops) || array_length(_shops) == 0) return _out;
    var _seen = {};
    for (var _i = 0; _i < array_length(_shops); _i++) {
        var _p = brk_profile(_shops[_i]), _t = brk_tuple(_p);
        _out.resolved++;
        if (variable_struct_exists(_seen, _t)) array_push(_out.collisions, { tuple: _t, a: _seen[$ _t], b: _p.name }); else { _seen[$ _t] = _p.name; _out.distinct_tuples++; }
    }
    return _out;
}
