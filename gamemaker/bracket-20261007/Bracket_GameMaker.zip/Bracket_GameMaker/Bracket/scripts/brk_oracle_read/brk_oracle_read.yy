{
  "$GMScript": "v1",
  "%Name": "brk_oracle_read",
  "name": "brk_oracle_read",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}