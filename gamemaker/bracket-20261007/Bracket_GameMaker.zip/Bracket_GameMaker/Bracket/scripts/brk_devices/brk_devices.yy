{
  "$GMScript": "v1",
  "%Name": "brk_devices",
  "name": "brk_devices",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}