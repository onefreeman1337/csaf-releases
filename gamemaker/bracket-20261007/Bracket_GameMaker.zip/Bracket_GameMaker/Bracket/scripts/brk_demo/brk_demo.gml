/// brk_demo.gml - the runnable demo: THE HIGH STREET. A dusk street of timber-framed shop fronts, every one with its sign
/// hung over the door - a sign Bracket composed from what that shop sells. LEFT / RIGHT walk the street, UP / DOWN change
/// district (four of them, richest first), ENTER takes the Close Look, Y opens the Signwright's Yard, R restocks the shop in
/// front of you with another trade's goods (its sign re-composes), W turns the district's prosperity down a step (its signs
/// weather). Delete this file, brk_demo_town and the demo object/room when you wire Bracket into your own game.
///
/// Bracket - Shop Signs Composed from What the Shop Sells, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

#macro BRK_DEMO_W 960
#macro BRK_DEMO_H 640
#macro BRK_DEMO_FRONT 300
#macro BRK_DEMO_GROUND 560
#macro BRK_DEMO_SIGN_H 150
#macro BRK_DEMO_LOOK_H 430

/// @function brk_demo_create()
/// @description The demo's state: the town, the district and shop in front of you, and what has been painted so far.
function brk_demo_create() {
    var _town = brk_demo_town(), _profs = array_create(array_length(_town));
    for (var _i = 0; _i < array_length(_town); _i++) _profs[_i] = brk_profile(_town[_i]);
    var _d = { town: _town, profiles: _profs, districts: brk_demo_districts(), district: 0, shop: 0, mode: "street",
        camx: 0, cam_target: 0, fronts: array_create(12, -1), sky: -1, cobbles: -1, glow: -1, look_back: -1, look_district: -1,
        yard: -1, yard_for: "", plaque: -1, plaque_for: "", restocks: array_create(48, 0), ticks: 0, swing_t: 0, flash: 0, version: 0 };
    _d.cam_target = brk__demo_cam_for(_d.shop);
    _d.camx = _d.cam_target;
    return _d;
}

/// @function brk_demo_free(demo)
/// @description Free every surface and sprite the demo painted, and the baked signs.
function brk_demo_free(_d) {
    if (!is_struct(_d)) return;
    brk__flush_draws();
    for (var _i = 0; _i < array_length(_d.fronts); _i++) if (_d.fronts[_i] != -1 && sprite_exists(_d.fronts[_i])) sprite_delete(_d.fronts[_i]);
    var _spr = [_d.sky, _d.cobbles, _d.glow, _d.look_back, _d.yard, _d.plaque];
    for (var _j = 0; _j < array_length(_spr); _j++) if (_spr[_j] != -1 && sprite_exists(_spr[_j])) sprite_delete(_spr[_j]);
    _d.fronts = array_create(12, -1); _d.sky = -1; _d.cobbles = -1; _d.glow = -1; _d.look_back = -1; _d.yard = -1; _d.plaque = -1;
    brk_sign_cache_clear();
}

/// @function brk__demo_cam_for(slot)
/// @description Internal. The camera x that centres a shop front.
function brk__demo_cam_for(_slot) { return clamp(_slot * BRK_DEMO_FRONT + BRK_DEMO_FRONT / 2 - BRK_DEMO_W / 2, 0, 12 * BRK_DEMO_FRONT - BRK_DEMO_W); }

/// @function brk__demo_index(demo, slot)
/// @description Internal. The town index of slot (0..11) in the current district.
function brk__demo_index(_d, _slot) { return _d.district * 12 + clamp(_slot, 0, 11); }

/// @function brk__demo_district_profiles(demo)
/// @description Internal. The current district's twelve profiles, in street order.
function brk__demo_district_profiles(_d) { var _a = array_create(12); for (var _i = 0; _i < 12; _i++) _a[_i] = _d.profiles[brk__demo_index(_d, _i)]; return _a; }

/// @function brk__demo_reprofile(demo, index)
/// @description Internal. Read a shop again after its goods or its district changed.
function brk__demo_reprofile(_d, _i) { _d.profiles[_i] = brk_profile(_d.town[_i]); }

/// @function brk_demo_restock(demo, [slot])
/// @description Give the shop at slot (default the one in front of you) the goods of the NEXT trade along the district's
/// street (and on round again), so its sign re-composes from the new stock. Returns the new profile.
function brk_demo_restock(_d, _slot = undefined) {
    var _s = is_undefined(_slot) ? _d.shop : clamp(_slot, 0, 11);
    var _i = brk__demo_index(_d, _s);
    var _base = brk_demo_town();
    _d.restocks[_i] = (_d.restocks[_i] + 1) mod 12;
    var _from = brk__demo_index(_d, (_s + _d.restocks[_i]) mod 12);
    _d.town[_i].goods = _base[_from].goods;
    brk__demo_reprofile(_d, _i);
    _d.flash = 1;
    _d.version++;
    return _d.profiles[_i];
}

/// @function brk_demo_weather(demo)
/// @description Turn the current district's prosperity down a step (4 -> 0, then back to 4): every sign on the street
/// re-weathers. Returns the district's new prosperity.
function brk_demo_weather(_d) {
    var _dist = _d.districts[_d.district];
    _dist.prosperity = (_dist.prosperity + 4) mod 5;
    for (var _s = 0; _s < 12; _s++) { var _i = brk__demo_index(_d, _s); _d.town[_i].prosperity = _dist.prosperity; brk__demo_reprofile(_d, _i); }
    _d.flash = 1;
    _d.version++;
    return _dist.prosperity;
}

/// @function brk_demo_step(demo, [input])
/// @description One frame: read the keys (or an input struct { left, right, up, down, look, yard, restock, weather } for a
/// scripted run) and move the camera.
function brk_demo_step(_d, _in = undefined) {
    if (!is_struct(_d)) return;
    var _k = is_struct(_in) ? _in : { left: keyboard_check_pressed(vk_left), right: keyboard_check_pressed(vk_right), up: keyboard_check_pressed(vk_up), down: keyboard_check_pressed(vk_down),
        look: keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space), yard: keyboard_check_pressed(ord("Y")), restock: keyboard_check_pressed(ord("R")), weather: keyboard_check_pressed(ord("W")), back: keyboard_check_pressed(vk_escape) || keyboard_check_pressed(vk_backspace) };
    _d.ticks++;
    _d.swing_t += 1;
    if (_d.flash > 0) _d.flash = max(0, _d.flash - 0.04);
    if (_d.mode == "street") {
        if (_k[$ "left"] ?? false) _d.shop = max(0, _d.shop - 1);
        if (_k[$ "right"] ?? false) _d.shop = min(11, _d.shop + 1);
        if (_k[$ "up"] ?? false) { _d.district = (_d.district + 3) mod 4; _d.flash = 1; }
        if (_k[$ "down"] ?? false) { _d.district = (_d.district + 1) mod 4; _d.flash = 1; }
        if (_k[$ "restock"] ?? false) brk_demo_restock(_d);
        if (_k[$ "weather"] ?? false) brk_demo_weather(_d);
        if (_k[$ "look"] ?? false) _d.mode = "look";
        else if (_k[$ "yard"] ?? false) _d.mode = "yard";
    } else {
        if (_d.mode == "look") {
            if (_k[$ "left"] ?? false) _d.shop = max(0, _d.shop - 1);
            if (_k[$ "right"] ?? false) _d.shop = min(11, _d.shop + 1);
            if (_k[$ "restock"] ?? false) brk_demo_restock(_d);
            if (_k[$ "weather"] ?? false) brk_demo_weather(_d);
        }
        if ((_k[$ "back"] ?? false) || (_k[$ "look"] ?? false) || ((_d.mode == "yard") && (_k[$ "yard"] ?? false))) _d.mode = "street";
        else if ((_d.mode == "look") && (_k[$ "yard"] ?? false)) _d.mode = "yard";
    }
    _d.cam_target = brk__demo_cam_for(_d.shop);
    _d.camx += (_d.cam_target - _d.camx) * 0.18;
    if (abs(_d.cam_target - _d.camx) < 0.5) _d.camx = _d.cam_target;
}

// ---------------------------------------------------------------------------------------------------------------
// Painting the street (once, through the package's own canvas kit) - every pixel drawn here, nothing is an image file
// ---------------------------------------------------------------------------------------------------------------

/// @function brk__demo_bake(w, h, painter, [ss])
/// @description Internal. Run painter(ctx) into a w x h sprite, struck at ss x and filtered down. Returns the sprite.
function brk__demo_bake(_w, _h, _painter, _ss = 2) {
    var _big = surface_create(_w * _ss, _h * _ss), _m = matrix_get(matrix_world);
    surface_set_target(_big);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    matrix_set(matrix_world, matrix_build_identity());
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    _painter(brk_cx_create(_ss));
    gpu_pop_state();
    surface_reset_target();
    var _half = surface_create(_w, _h);
    surface_set_target(_half);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    matrix_set(matrix_world, matrix_build_identity());
    gpu_set_blendmode_ext(bm_one, bm_zero);
    gpu_set_texfilter(true);
    draw_surface_ext(_big, 0, 0, 1 / _ss, 1 / _ss, 0, c_white, 1);
    gpu_pop_state();
    surface_reset_target();
    matrix_set(matrix_world, _m);
    var _spr = sprite_create_from_surface(_half, 0, 0, _w, _h, false, false, 0, 0);
    surface_free(_half); surface_free(_big);
    return _spr;
}

/// @function brk__demo_rect(ctx, x, y, w, h, rgb, [a])
function brk__demo_rect(_c, _x, _y, _w, _h, _rgb, _a = 1) { _c.fill = brk_cx_solid(_rgb, _a); brk_cx_fill_rect(_c, _x, _y, _w, _h); }

/// @function brk__demo_poly(ctx, points, rgb, [a])
function brk__demo_poly(_c, _pts, _rgb, _a = 1) {
    _c.fill = brk_cx_solid(_rgb, _a);
    brk_cx_begin(_c); brk_cx_move(_c, _pts[0][0], _pts[0][1]);
    for (var _i = 1; _i < array_length(_pts); _i++) brk_cx_line(_c, _pts[_i][0], _pts[_i][1]);
    brk_cx_close(_c); brk_cx_fill(_c);
}

/// @function brk__demo_window(ctx, x, y, w, h, lit, rng)
/// @description Internal. A leaded window in an oak frame: warm and lit, or dark glass catching the dusk.
function brk__demo_window(_c, _x, _y, _w, _h, _lit) {
    var _oak = [46, 30, 20];
    brk__demo_rect(_c, _x - 5, _y - 5, _w + 10, _h + 10, _oak);
    var _g = brk_cx_linear(_c, _x, _y, _x, _y + _h);
    if (_lit) { brk_cx_stop(_g, 0, [255, 214, 142], 1); brk_cx_stop(_g, 1, [214, 140, 64], 1); }
    else { brk_cx_stop(_g, 0, [58, 74, 98], 1); brk_cx_stop(_g, 1, [26, 34, 48], 1); }
    _c.fill = _g; brk_cx_fill_rect(_c, _x, _y, _w, _h);
    // leading: a lattice at a declared pitch
    var _pitch = 11, _lead = _lit ? [120, 70, 30] : [20, 26, 36];
    for (var _gx = _x + _pitch; _gx < _x + _w - 2; _gx += _pitch) brk__demo_rect(_c, _gx, _y, 1.2, _h, _lead, 0.8);
    for (var _gy = _y + _pitch * 1.3; _gy < _y + _h - 2; _gy += _pitch * 1.3) brk__demo_rect(_c, _x, _gy, _w, 1.2, _lead, 0.8);
    brk__demo_rect(_c, _x + _w / 2 - 2.5, _y, 5, _h, _oak);          // the mullion
    brk__demo_rect(_c, _x - 7, _y + _h + 3, _w + 14, 6, [74, 50, 32]); // the sill
    brk__demo_rect(_c, _x - 7, _y + _h + 3, _w + 14, 1.5, [120, 86, 56]);
}

/// @function brk__demo_front_paint(ctx, slot)
/// @description Internal. One timber-framed shop front (300 x 500, ground line at the bottom): a gable or an eaves roof,
/// a jettied upper storey with braced panels and leaded windows, and a ground floor with a shop window and a door. The
/// style is drawn from the slot's own seed, so the twelve fronts differ in plaster, roof, bracing and windows.
function brk__demo_front_paint(_c, _slot) {
    var _r = brk__rng(brk_hash("bracket demo front " + string(_slot)));
    var _q = array_create(8);
    for (var _i = 0; _i < 8; _i++) _q[_i] = brk__rng_next(_r);
    var _W = BRK_DEMO_FRONT, _H = 500;
    var _plasters = [[150, 140, 120], [140, 128, 104], [128, 124, 116], [156, 144, 128], [134, 118, 96]];
    var _pl = _plasters[floor(_q[0] * 5) mod 5];
    var _oak = [44, 29, 19], _oakLit = [86, 58, 36], _slate = [34, 40, 52], _slateLit = [58, 66, 82];
    var _roofTop = 30, _eave = 110, _beam = 268, _ground = _H;
    var _gable = (_q[1] < 0.6);
    // the roof
    if (_gable) {
        brk__demo_poly(_c, [[-6, _eave], [_W / 2, _roofTop - 10], [_W + 6, _eave]], _slate);
        brk__demo_poly(_c, [[-6, _eave], [_W / 2, _roofTop - 10], [_W / 2, _roofTop - 2], [4, _eave]], _slateLit, 0.55);
        _c.stroke = brk_cx_solid(_oak); _c.lw = 6;
        brk_cx_begin(_c); brk_cx_move(_c, -4, _eave + 2); brk_cx_line(_c, _W / 2, _roofTop - 8); brk_cx_line(_c, _W + 4, _eave + 2); brk_cx_stroke(_c);
    } else {
        brk__demo_rect(_c, -8, _eave - 54, _W + 16, 54, _slate);
        for (var _t = 0; _t < 6; _t++) brk__demo_rect(_c, -8, _eave - 54 + _t * 9, _W + 16, 1.5, _slateLit, 0.45);
        brk__demo_rect(_c, -10, _eave - 6, _W + 20, 8, _oak);
    }
    // the chimney
    var _chx = 40 + _q[2] * (_W - 120);
    brk__demo_rect(_c, _chx, _roofTop - 6 + (_gable ? 30 : 10), 30, 70, [70, 46, 38]);
    brk__demo_rect(_c, _chx - 4, _roofTop - 10 + (_gable ? 30 : 10), 38, 8, [52, 34, 28]);
    // the upper storey (jettied: wider by 8 each side)
    brk__demo_rect(_c, -8, _eave, _W + 16, _beam - _eave, _pl);
    var _shade = brk_cx_linear(_c, 0, _eave, 0, _beam);
    brk_cx_stop(_shade, 0, [0, 0, 0], 0.30); brk_cx_stop(_shade, 1, [0, 0, 0], 0);
    _c.fill = _shade; brk_cx_fill_rect(_c, -8, _eave, _W + 16, _beam - _eave);
    // studs and braces
    var _studs = [-8, 92, 196, _W - 4];
    for (var _s = 0; _s < 4; _s++) brk__demo_rect(_c, _studs[_s], _eave, 12, _beam - _eave, _oak);
    brk__demo_rect(_c, -8, _eave, _W + 16, 10, _oak);
    var _brace = (_q[3] < 0.5);
    for (var _p = 0; _p < 3; _p++) {
        var _x0 = _studs[_p] + 12, _x1 = _studs[_p + 1];
        if (_p == 1) continue;                                // the middle panel carries the windows
        if (_brace) { brk__demo_poly(_c, [[_x0, _beam - 6], [_x0 + 10, _beam - 6], [_x1, _eave + 22], [_x1, _eave + 10]], _oak); }
        else { brk__demo_poly(_c, [[_x0, _eave + 10], [_x0 + 10, _eave + 10], [_x1, _beam - 18], [_x1, _beam - 6]], _oak); brk__demo_poly(_c, [[_x1, _eave + 10], [_x1 - 10, _eave + 10], [_x0, _beam - 18], [_x0, _beam - 6]], _oak); }
    }
    // upper windows: one in each outer panel's centre band and a pair in the middle panel
    brk__demo_window(_c, 116, _eave + 44, 56, 70, _q[4] < 0.7);
    if (_q[5] < 0.5) brk__demo_window(_c, 224, _eave + 52, 44, 58, _q[5] < 0.25);
    // the jetty beam, lit along its top
    brk__demo_rect(_c, -12, _beam, _W + 24, 16, _oak);
    brk__demo_rect(_c, -12, _beam, _W + 24, 3, _oakLit);
    // the ground floor
    brk__demo_rect(_c, 0, _beam + 16, _W, _ground - _beam - 16, [_pl[0] * 0.82, _pl[1] * 0.82, _pl[2] * 0.84]);
    brk__demo_rect(_c, 0, _beam + 16, 12, _ground - _beam - 16, _oak);
    brk__demo_rect(_c, _W - 12, _beam + 16, 12, _ground - _beam - 16, _oak);
    // the shop window (lit), with its stall board below
    brk__demo_window(_c, 34, 382, 140, 74, true);
    brk__demo_rect(_c, 26, 470, 156, _ground - 470, [60, 40, 26]);
    brk__demo_rect(_c, 26, 470, 156, 3, _oakLit);
    // the door: a planked oak door under a lit fanlight
    var _dx = 206, _dw = 64, _dy = 356;
    brk__demo_rect(_c, _dx - 8, _dy - 8, _dw + 16, _ground - _dy + 8, _oak);
    var _fan = brk_cx_linear(_c, 0, _dy, 0, _dy + 24);
    brk_cx_stop(_fan, 0, [255, 210, 130], 1); brk_cx_stop(_fan, 1, [200, 120, 50], 1);
    _c.fill = _fan; brk_cx_fill_rect(_c, _dx, _dy, _dw, 22);
    var _doorC = [[92, 52, 34], [64, 70, 58], [78, 42, 40], [52, 58, 74]][floor(_q[6] * 4) mod 4];
    brk__demo_rect(_c, _dx, _dy + 28, _dw, _ground - _dy - 28, _doorC);
    for (var _pk = 1; _pk < 4; _pk++) brk__demo_rect(_c, _dx + _pk * _dw / 4, _dy + 28, 1.5, _ground - _dy - 28, [0, 0, 0], 0.35);
    _c.fill = brk_cx_solid([212, 170, 90]);
    brk_cx_begin(_c); brk_cx_ellipse(_c, _dx + _dw - 12, _dy + 100, 3.5, 3.5, 0, 0, pi * 2); brk_cx_fill(_c);
    // the step and the lantern by the door
    brk__demo_rect(_c, _dx - 12, _ground - 8, _dw + 24, 8, [70, 72, 80]);
    brk__demo_rect(_c, _W - 22, 300, 4, 22, [30, 30, 34]);
    brk__demo_poly(_c, [[_W - 30, 322], [_W - 12, 322], [_W - 15, 344], [_W - 27, 344]], [255, 198, 110]);
    brk__demo_rect(_c, _W - 31, 320, 20, 3, [30, 30, 34]);
    brk__demo_rect(_c, _W - 29, 344, 16, 3, [30, 30, 34]);
}

/// @function brk__demo_sky_paint(ctx)
/// @description Internal. The dusk behind the street: a sky and a far roofline, drawn wider than the screen for parallax.
function brk__demo_sky_paint(_c) {
    var _W = 1600, _H = 420;
    var _g = brk_cx_linear(_c, 0, 0, 0, _H);
    brk_cx_stop(_g, 0, [18, 24, 38], 1); brk_cx_stop(_g, 0.6, [44, 50, 72], 1); brk_cx_stop(_g, 1, [86, 74, 82], 1);
    _c.fill = _g; brk_cx_fill_rect(_c, 0, 0, _W, _H);
    var _r = brk__rng(brk_hash("bracket demo skyline"));
    var _x = -20;
    while (_x < _W) {
        var _a = brk__rng_next(_r), _b = brk__rng_next(_r), _e = brk__rng_next(_r);
        var _w = 70 + _a * 90, _top = 200 + _b * 120;
        brk__demo_poly(_c, [[_x, _H], [_x, _top + 30], [_x + _w / 2, _top], [_x + _w, _top + 30], [_x + _w, _H]], [26, 30, 44]);
        if (_e < 0.45) brk__demo_rect(_c, _x + _w * 0.3, _top + 52, 9, 12, [230, 170, 90], 0.55);
        _x += _w - 6;
    }
}

/// @function brk__demo_cobbles_paint(ctx)
/// @description Internal. A strip of cobbles (300 x 80) that tiles: courses at a declared pitch, stones offset by half.
function brk__demo_cobbles_paint(_c) {
    var _W = BRK_DEMO_FRONT, _H = 80;
    var _g = brk_cx_linear(_c, 0, 0, 0, _H);
    brk_cx_stop(_g, 0, [30, 34, 44], 1); brk_cx_stop(_g, 1, [16, 19, 26], 1);
    _c.fill = _g; brk_cx_fill_rect(_c, 0, 0, _W, _H);
    var _rows = 5, _rh = _H / _rows, _sw = 30;
    for (var _row = 0; _row < _rows; _row++) {
        var _off = (_row mod 2) * _sw / 2, _y = _row * _rh + _rh / 2;
        for (var _x = -_sw + _off; _x < _W + _sw; _x += _sw) {
            var _v = 0.75 + 0.25 * (_row / _rows);
            _c.fill = brk_cx_solid([58 * _v, 62 * _v, 74 * _v]);
            brk_cx_begin(_c); brk_cx_ellipse(_c, _x + _sw / 2, _y, _sw * 0.42, _rh * 0.36, 0, 0, pi * 2); brk_cx_fill(_c);
            _c.fill = brk_cx_solid([120, 120, 130], 0.18);
            brk_cx_begin(_c); brk_cx_ellipse(_c, _x + _sw / 2 - 3, _y - 2, _sw * 0.22, _rh * 0.14, 0, 0, pi * 2); brk_cx_fill(_c);
        }
    }
    brk__demo_rect(_c, 0, 0, _W, 4, [92, 92, 100]);        // the kerb
    brk__demo_rect(_c, 0, 4, _W, 3, [10, 12, 16], 0.6);
}

/// @function brk__demo_glow_paint(ctx)
/// @description Internal. A warm lantern glow, drawn additively over the street.
function brk__demo_glow_paint(_c) {
    var _g = brk_cx_radial(_c, 64, 64, 0, 64, 64, 64);
    brk_cx_stop(_g, 0, [255, 200, 120], 0.55); brk_cx_stop(_g, 0.35, [230, 150, 70], 0.16); brk_cx_stop(_g, 1, [230, 150, 70], 0);
    _c.fill = _g; brk_cx_begin(_c); brk_cx_ellipse(_c, 64, 64, 64, 64, 0, 0, pi * 2); brk_cx_fill(_c);
}

/// @function brk_demo_prepare(demo, [max_ms])
/// @description Paint what the current view needs, for up to max_ms (default 6; at least one piece per call): the sky,
/// the cobbles, the glow, the twelve fronts and the district's signs - or, in the Close Look and the Yard, their own
/// backdrops. Returns true when the view is ready. Called by brk_demo_draw every frame; call it from a Draw event.
function brk_demo_prepare(_d, _max_ms = 6) {
    var _t0 = get_timer(), _budget = _max_ms * 1000, _n = 0;
    var _go = function(_t0, _budget, _n) { return _n == 0 || get_timer() - _t0 < _budget; };
    if (_d.sky == -1) { _d.sky = brk__demo_bake(1600, 420, brk__demo_sky_paint, 1); _n++; }
    if (_d.cobbles == -1 && _go(_t0, _budget, _n)) { _d.cobbles = brk__demo_bake(BRK_DEMO_FRONT, 80, brk__demo_cobbles_paint, 2); _n++; }
    if (_d.glow == -1 && _go(_t0, _budget, _n)) { _d.glow = brk__demo_bake(128, 128, brk__demo_glow_paint, 1); _n++; }
    for (var _i = 0; _i < 12; _i++) if (_d.fronts[_i] == -1 && _go(_t0, _budget, _n)) {
        var _slot = _i;
        _d.fronts[_i] = brk__demo_bake(BRK_DEMO_FRONT + 24, 520, method({ slot: _slot }, function(_c) { brk_cx_translate(_c, 12, 20); brk__demo_front_paint(_c, slot); }), 2);
        _n++;
    }
    var _ready = (_d.sky != -1 && _d.cobbles != -1 && _d.glow != -1);
    for (var _j = 0; _j < 12; _j++) if (_d.fronts[_j] == -1) _ready = false;
    if (_d.mode == "street") {
        var _left = _go(_t0, _budget, _n) ? max(0.1, _max_ms - (get_timer() - _t0) / 1000) : 0.1;
        // the shop in front of you first, then the rest of the district
        var _profs = brk__demo_district_profiles(_d), _order = [_profs[_d.shop]];
        for (var _k = 0; _k < 12; _k++) if (_k != _d.shop) array_push(_order, _profs[_k]);
        if (!brk_prepare(_order, BRK_DEMO_SIGN_H, _left, { behind: "#5a5446" })) _ready = false;
    } else if (_d.mode == "look") {
        if (_d.look_district != _d.district) {
            if (_d.look_back != -1) { brk__flush_draws(); sprite_delete(_d.look_back); }
            var _seed = 7 + _d.district * 11;
            _d.look_back = brk__demo_bake(BRK_DEMO_W, BRK_DEMO_H, method({ seed: _seed }, function(_c) { brk_draw_street(_c, BRK_DEMO_W, BRK_DEMO_H, seed); }), 1);
            _d.look_district = _d.district;
        }
        brk_sign_sprite(_d.profiles[brk__demo_index(_d, _d.shop)], BRK_DEMO_LOOK_H, { behind: brk_palette().dusk });
    } else if (_d.mode == "yard") {
        var _yk = string(_d.district) + "/" + string(_d.version);
        if (_d.yard_for != _yk) {
            if (_d.yard != -1) { brk__flush_draws(); sprite_delete(_d.yard); }
            _d.yard = brk__demo_bake(BRK_DEMO_W, BRK_DEMO_H, method({ d: _d }, function(_c) { brk_demo_paint_yard(_c, d); }), 1);
            _d.yard_for = _yk;
        }
    }
    return _ready;
}

/// @function brk_demo_paint_yard(ctx, demo)
/// @description The Signwright's Yard of the current district, with its heading, into a brk_canvas context. Returns the
/// yard's result (brk_draw_yard).
function brk_demo_paint_yard(_c, _d) {
    var _res = brk_draw_yard(_c, brk__demo_district_profiles(_d), BRK_DEMO_W, BRK_DEMO_H, { head: BRK_DEMO_H * 0.13 });
    var _ink = brk_relief(brk_parse_hex(brk_palette().giltLit), -1, 10);
    _c.fill = brk__ink(_ink);
    var _title = "The Signwright's Yard";
    var _f = brk_fit_line(_title, floor(BRK_DEMO_H * 0.052 + 0.5), BRK_FACE_DISPLAY, BRK_DEMO_W * 0.8, 0);
    brk__strike_tracked(_c, _title, BRK_DEMO_W / 2, floor(BRK_DEMO_H * 0.062 + 0.5), { size: _f.size, tracking: 0 }, BRK_FACE_DISPLAY);
    var _dist = _d.districts[_d.district];
    _c.fill = brk_cx_solid([200, 190, 168], 0.85);
    var _sub = _dist.name + "  -  prosperity " + string(_dist.prosperity) + "  -  twelve shops, twelve signs";
    var _f2 = brk_fit_line(_sub, 16, BRK_FACE_BODY, BRK_DEMO_W * 0.8, 0.04);
    brk__strike_tracked(_c, _sub, BRK_DEMO_W / 2, floor(BRK_DEMO_H * 0.098 + 0.5), _f2, BRK_FACE_BODY);
    return _res;
}

/// @function brk__demo_plaque_sprite(demo, profile, subtitle, w, h)
/// @description Internal. The name plaque for the shop in front of you, re-baked only when the shop or its sign changes.
function brk__demo_plaque_sprite(_d, _p, _sub, _w, _h) {
    var _key = _p.name + "|" + _p.device + "|" + _sub + "|" + string(_w) + "x" + string(_h);
    if (_d.plaque != -1 && _d.plaque_for == _key && sprite_exists(_d.plaque)) return _d.plaque;
    if (_d.plaque != -1 && sprite_exists(_d.plaque)) { brk__flush_draws(); sprite_delete(_d.plaque); }
    _d.plaque = brk__demo_bake(_w, _h, method({ p: _p, sub: _sub, w: _w, h: _h }, function(_c) { brk_draw_plaque(_c, p, 0, 0, w, h, sub); }), 2);
    _d.plaque_for = _key;
    return _d.plaque;
}

/// @function brk__demo_text(x, y, text, colour, alpha, [halign])
/// @description Internal. A line of HUD text in the body face.
function brk__demo_text(_x, _y, _t, _col, _a, _ha = fa_left) {
    draw_set_font(fnt_bracket_body_s); draw_set_halign(_ha); draw_set_valign(fa_top);
    draw_set_colour(c_black); draw_set_alpha(_a * 0.6); draw_text(_x + 1, _y + 1, _t);
    draw_set_colour(_col); draw_set_alpha(_a); draw_text(_x, _y, _t);
    draw_set_alpha(1); draw_set_halign(fa_left);
}

/// @function brk__demo_footer(x, y, text, colour)
/// @description Internal. The key line, on its own dark band along the foot of the view so it never sits on the art.
function brk__demo_footer(_ox, _oy, _t, _col) {
    draw_set_colour(make_colour_rgb(10, 13, 19)); draw_set_alpha(0.72);
    draw_rectangle(_ox, _oy + BRK_DEMO_H - 26, _ox + BRK_DEMO_W, _oy + BRK_DEMO_H, false);
    draw_set_alpha(1);
    brk__demo_text(_ox + BRK_DEMO_W / 2, _oy + BRK_DEMO_H - 24, _t, _col, 0.9, fa_center);
}

/// @function brk_demo_draw(demo, [x], [y])
/// @description Draw the demo's current view at (x, y), 960 x 640. Call from a Draw event (it paints on demand).
function brk_demo_draw(_d, _ox = 0, _oy = 0) {
    if (!is_struct(_d)) return;
    var _ready = brk_demo_prepare(_d, 6);
    var _cream = make_colour_rgb(238, 228, 204), _dim = make_colour_rgb(178, 170, 150);
    if (_d.mode == "look" && _d.look_back != -1) {
        draw_sprite(_d.look_back, 0, _ox, _oy);
        var _p = _d.profiles[brk__demo_index(_d, _d.shop)];
        var _box = brk_sign_box(_p, BRK_DEMO_LOOK_H);
        var _spr = brk_sign_sprite(_p, BRK_DEMO_LOOK_H, { behind: brk_palette().dusk });
        draw_sprite(_spr, 0, _ox + floor((BRK_DEMO_W - _box.w) / 2), _oy + floor(BRK_DEMO_H * 0.04));
        var _pw = floor(BRK_DEMO_W * 0.52), _ph = floor(BRK_DEMO_H * 0.145);
        var _dist = _d.districts[_d.district];
        var _pl = brk__demo_plaque_sprite(_d, _p, _dist.name + "  -  " + _p.trade, _pw, _ph);
        draw_sprite(_pl, 0, _ox + floor((BRK_DEMO_W - _pw) / 2), _oy + BRK_DEMO_H - _ph - floor(BRK_DEMO_H * 0.04));
        brk__demo_footer(_ox, _oy, "THE CLOSE LOOK   LEFT/RIGHT next shop   R restock   W weather   Y yard   ENTER back", _dim);
        return;
    }
    if (_d.mode == "yard" && _d.yard != -1) {
        draw_sprite(_d.yard, 0, _ox, _oy);
        brk__demo_footer(_ox, _oy, "THE SIGNWRIGHT'S YARD   Y or ENTER back to the street", _dim);
        return;
    }
    // ---- the street ----
    draw_set_colour(make_colour_rgb(18, 24, 38));
    draw_rectangle(_ox, _oy, _ox + BRK_DEMO_W, _oy + BRK_DEMO_H, false);
    var _cam = _d.camx;
    if (_d.sky != -1) draw_sprite(_d.sky, 0, _ox - _cam * 0.25, _oy + 40);
    if (!_ready && _d.fronts[11] == -1) {
        brk__demo_text(_ox + BRK_DEMO_W / 2, _oy + BRK_DEMO_H / 2, "Painting the High Street...", _cream, 0.9, fa_center);
        return;
    }
    var _dist2 = _d.districts[_d.district];
    // poorer districts: the plaster greys and darkens
    var _k = 0.70 + 0.075 * _dist2.prosperity;
    var _tint = make_colour_rgb(255 * _k, 255 * (_k * 0.98), 255 * min(1, _k * 1.04));
    for (var _i = 0; _i < 12; _i++) {
        var _fx = _ox + _i * BRK_DEMO_FRONT - _cam;
        if (_fx > _ox + BRK_DEMO_W + 40 || _fx < _ox - BRK_DEMO_FRONT - 40) continue;
        if (_d.fronts[_i] != -1) draw_sprite_ext(_d.fronts[_i], 0, _fx - 12, _oy + BRK_DEMO_GROUND - 520, 1, 1, 0, _tint, 1);
    }
    // the cobbles
    if (_d.cobbles != -1) {
        var _start = -(floor(_cam) mod BRK_DEMO_FRONT) - frac(_cam);
        for (var _cx = _start - BRK_DEMO_FRONT; _cx < BRK_DEMO_W + BRK_DEMO_FRONT; _cx += BRK_DEMO_FRONT) draw_sprite(_d.cobbles, 0, _ox + _cx, _oy + BRK_DEMO_GROUND);
    }
    // the signs, hung from each front's left post over the shop window
    var _profs = brk__demo_district_profiles(_d);
    for (var _s = 0; _s < 12; _s++) {
        var _sx = _ox + _s * BRK_DEMO_FRONT - _cam + 2;
        if (_sx > _ox + BRK_DEMO_W + 40 || _sx < _ox - BRK_DEMO_FRONT - 40) continue;
        if (brk_sign_ready(_profs[_s], BRK_DEMO_SIGN_H, { behind: "#5a5446" })) brk_draw_sign_sprite(_profs[_s], _sx, _oy + BRK_DEMO_GROUND - 268, BRK_DEMO_SIGN_H, { behind: "#5a5446" });
    }
    // the lantern glows, additively (each front's lantern hangs at (300 - 21, 333) in its own paint, 167 px above the street)
    if (_d.glow != -1) {
        gpu_set_blendmode(bm_add);
        for (var _l = 0; _l < 12; _l++) { var _lx = _ox + _l * BRK_DEMO_FRONT - _cam + BRK_DEMO_FRONT - 21; if (_lx > _ox - 120 && _lx < _ox + BRK_DEMO_W + 120) draw_sprite_ext(_d.glow, 0, _lx - 96, _oy + BRK_DEMO_GROUND - 167 - 96, 1.5, 1.5, 0, c_white, 0.9); }
        gpu_set_blendmode(bm_normal);
    }
    // the plaque for the shop in front of you
    var _p2 = _profs[_d.shop];
    var _pw2 = 420, _ph2 = 70;
    var _pl2 = brk__demo_plaque_sprite(_d, _p2, _dist2.name + "  -  " + _p2.trade, _pw2, _ph2);
    draw_sprite(_pl2, 0, _ox + floor((BRK_DEMO_W - _pw2) / 2), _oy + 14);
    brk__demo_footer(_ox, _oy, "LEFT/RIGHT walk   UP/DOWN district   ENTER close look   Y yard   R restock   W weather", _dim);
    if (_d.flash > 0) { draw_set_colour(c_white); draw_set_alpha(_d.flash * 0.10); draw_rectangle(_ox, _oy, _ox + BRK_DEMO_W, _oy + BRK_DEMO_H, false); draw_set_alpha(1); }
}
