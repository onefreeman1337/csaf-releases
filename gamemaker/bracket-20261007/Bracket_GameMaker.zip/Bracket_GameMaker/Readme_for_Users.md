# Bracket - Shop Signs Composed from What the Shop Sells, for GameMaker

Every shop, inn and guild in your town hangs its own sign: a wrought-iron bracket, a shaped and painted board carrying a
trade mark composed from what the shop actually sells, the shop's name in carved or gilt capitals, iron rings and chain,
and weathering keyed to how prosperous the street is. Nothing is an image file. Change the stock and the sign re-composes.

- **Read, not authored.** Give Bracket a shop - its name, its goods with their prices, and how prosperous its street is -
  and it decides everything else: the trade (12: smith, armourer, apothecary, herbalist, jeweller, scribe, baker, tavern,
  inn, tailor, fishmonger, farrier), the board outline (10), the bracket (8 forms, grander for the dearer shops on YOUR
  price ladder), the colour scheme (6) and the weathering (0 to 4). Structure first - item kind, equipment slot, effect -
  then the goods' names, then the shop's name. You can override any of it by hand.
- **Drawn whole.** Oak boards with grain that runs the outline at each height, a pigment coat that retreats from the
  corners as it weathers, a chalk keyline, the trade mark as one silhouette, the name fitted and tracked to the board (on
  an arc where the board asks for it), lettering whose relief is solved for contrast rather than assumed, scrolled iron,
  rings and chain, rust bleeding from the rings, split corners and a missing chain link on the poorest streets.
- **28,800 forms** (12 trades x 10 boards x 8 brackets x 6 schemes x 5 weatherings) before the name is lettered. The demo
  town's 48 shops resolve to 48 different signs.
- **Baked to sprites** at twice the size and filtered down, cached, and prepared under a time budget.

Ported from our RPG Maker MZ plugin Bracket and held to it: the in-engine suite runs the reader, the geometry and every
paint operation through both and checks they agree (see Verification).

## Install

1. In GameMaker, **Tools > Import Local Package**, choose `Bracket.yymps`, and import everything.
2. Run the project with `rm_brk_demo` first in the room order. The demo is THE HIGH STREET: a dusk street of timber-framed
   shop fronts, every one with its sign hung over its window. LEFT / RIGHT walk the street, UP / DOWN change district
   (four, richest first), ENTER takes the Close Look (the sign full size against a dusk street, with its name plaque),
   Y opens the Signwright's Yard (the district's twelve signs on oak rails), R restocks the shop in front of you with
   another trade's goods (watch its sign re-compose), W turns the district's prosperity down a step (watch every sign
   weather).

Requires GameMaker 2024.14 or later. Built and tested on runtime 2024.14.4.268 (the VM, Windows). Pure GML, no extension;
nothing here depends on GMRT.

## Quickstart

```gml
// Create - a shop is a struct you build from your own data
my_shop = { name: "The Gilded Tankard", prosperity: 3,
            goods: [{ kind: "item", name: "Amber Ale", price: 90 }, { kind: "item", name: "Spiced Mead", price: 260 },
                    { kind: "item", name: "Cellar Wine", price: 420 }] };
my_sign = brk_profile(my_shop);          // the whole sign, as data: device "tankard", its board, bracket, scheme...

// Draw - (x, y) is the top-left of the sign; 150 is its height in pixels, bracket to foot
brk_draw_sign_sprite(my_sign, 64, 40, 150);

// Room End or Clean Up - free every baked sign
brk_sign_cache_clear();
```

`brk_draw_sign_sprite` bakes the sign the first time it is asked for (in a Draw event - baking uses surfaces) and draws
the cached sprite every time after. To have a whole street ready before it shows, call `brk_prepare` every frame on a
loading screen or while the room fades in:

```gml
// Draw - true once every sign in the list is baked
my_ready = brk_prepare(my_signs, 150, 4);   // up to 4 ms of baking per call, and always at least ONE sign
```

### What a shop can say

```gml
{ name: "Aurelian & Brothers",       // the name lettered on the board (blank: "The Smith", "The Tavern"...)
  prosperity: 4,                      // 0 (a back alley) to 4 (the richest street) - drives the weathering
  goods: [ { kind: "weapon", name: "Court Sword", price: 1400, typeName: "Sword" },
           { kind: "armor", name: "Kite Shield", price: 900, etypeId: 2 },
           { kind: "item", name: "Elixir", price: 1200, effects: [{ code: 11, dataId: 0, value1: 1 }] } ],
  // the hand always wins - any of these overrides what the goods would decide:
  device: "swordAnvil", board: "heater", bracket: "volute", scheme: "giltOak", weathering: 0, trade: "SMITH" }
```

Goods rows: `kind` ("item", "weapon" or "armor"), `name`, `price`, and optionally `itypeId` (2 = a key item, which is how
an inn's rooms are sold), `etypeId` (2 shield, 3 head, 4 body, 5 accessory), `typeName` (your own word for the type, e.g.
"Staff") and `effects` ({ code, dataId, value1 }: 11 recover HP, 12 recover MP, 22 remove a state, 21 add a state, 42 grow).

The ids: devices `swordAnvil shield flask herb gem scroll loaf tankard key shears fish horseshoe`; boards `heater oval
lozenge hanging arch banner keyhole barrelEnd tankardCut scrollEnd`; brackets `plainHook barAndRing singleScroll
doubleScroll volute leafScroll gallows crownedScroll`; schemes `oak verdigris oxblood indigo mustard giltOak`.

The bracket follows where a shop stands on a price ladder. Bracket ships a default ladder; to read it from your own goods'
prices, `brk_use_price_ladder(brk_ladder_from(my_all_prices))` once at game start.

## Reference

**Reading a shop**
- `brk_profile(shop)` - the sign as data: `{ key, name, trade, device, board, bracket, scheme, weathering, standing, tilt,
  seed, goods_count }`. Everything that draws a sign reads this and nothing else.
- `brk_volume([shops])` - `{ corpus, forms, resolved, distinct_tuples, collisions }`: how many signs Bracket could compose,
  and how many different ones YOUR shops resolve to (and which pairs collide).
- `brk_tuple(profile)` - "device/board/bracket/scheme", the tuple two signs should not share.
- `brk_standing(shop)` - 0..7, where the shop stands on the price ladder (decides the bracket).
- `brk_ladder_from(prices)` / `brk_use_price_ladder(ladder)` - build a price ladder from your own prices, and use it.

**Signs as sprites** (call these in a Draw event)
- `brk_draw_sign_sprite(profile, x, y, height, [options])` - draw a sign (baking it on first use). Returns the sprite, or -1.
- `brk_sign_sprite(profile, height, [options])` - the baked sprite (origin top-left), baked now if needed; -1 for a bad call.
- `brk_sign_box(profile, height)` - `{ w, h, x, y }`: the sprite's size and where the sign sits inside it.
- `brk_sign_ready(profile, height, [options])` - whether that sign is already baked. Never bakes.
- `brk_prepare(profiles, height, [max_ms], [options])` - bake a list under a time budget; true when all are baked.
- `brk_sign_cache_count()` / `brk_sign_cache_clear()` - how many signs are baked; free them all.

`options` is `{ swing, behind }`: `swing` hangs the board that many degrees off plumb on top of its own tilt (bake a few
swings to animate one), and `behind` is the colour behind the sign as "#rrggbb" - it shows through a split corner and
decides how the iron is lit.

**Drawing directly** (into a `brk_cx_create()` context, onto whatever surface is the current target)
- `brk_draw_sign(ctx, profile, x, y, height, [options])` - the whole sign, live. Returns what it drew.
- `brk_draw_device(ctx, id, cx, cy, w, h, ink, counter_ink)` - one trade mark on its own.
- `brk_draw_plaque(ctx, profile, x, y, w, h, [subtitle])` - the oak name plate that goes under a sign.
- `brk_draw_lintel(ctx, w, band)` - an oak lintel band to head a shop screen.
- `brk_draw_yard(ctx, profiles, w, h, [options])` - the Signwright's Yard: every sign on oak rails, the grid solved so they
  hang as large as the frame allows (`brk_solve_grid(n, w, h)` on its own).
- `brk_draw_street(ctx, w, h, [seed])` - the dusk street of the Close Look, with one distant sign and three lanterns.
- `brk_fit_line(text, size, face, max_w, tracking)` - fit a line of type to a width (`BRK_FACE_DISPLAY` or `BRK_FACE_BODY`).

## Performance - read this before hanging fifty signs

A sign is drawn by GML on GameMaker's primitives - every fill antialiased in code, struck at twice the size - so baking
one is not free. On our test machine (a shared, busy one) **a 150 px sign took 0.25 to 0.37 s to bake** across two runs,
and a 96 px sign about 0.19 s. Bake time grows with the sign's size. Once baked, drawing a sign is one `draw_sprite` call.

So: bake a town's signs while it loads (`brk_prepare` on a loading screen, or the room's first frames behind a fade),
keep sizes modest for signs on the map (100 to 160 px), and keep the big ones (the Close Look) for one sign at a time.
`brk_prepare` never splits one sign across frames - it bakes at least one per call and stops when the budget is spent.

## Fonts

The signs are lettered in two faces rasterised into font resources: Cinzel Bold (the names) and Alegreya (the trades and
the plaque), both SIL Open Font License 1.1. The licence texts and the notices are in `Bracket/fonts/`. The atlases carry
printable ASCII (32 to 126); a character outside that range is measured as nothing and not drawn.

## Verification

GameMaker code cannot be unit-tested outside the engine, so everything below ran in real executables built by GameMaker's
own compiler (Igor, runtime 2024.14.4.268):

- The reader, held to the MZ edition's: hashes and 3,000 generator states exact, 62 full profiles field for field, and
  the demo town's 48 shops read identically and resolving to 48 different signs.
- The geometry, held point for point: 247 signs x 64 numbers, the eight bracket spines and the twelve trade marks.
- The painter, held paint event for paint event: 215 drawings (24 trade marks, 186 signs at three sizes, 2 streets, 3
  yards) - 30,889 fills, strokes, clips and glyphs, each compared on colour, alpha, line width, path and transform - plus
  40 line fits and 6 grid solves.
- The bake (ink counted on the sprite, positive control first), the cache, the time budget, every refusal, and the demo
  driven through every key with each view saved and looked at.
- A fresh install of this package into a blank project running this Readme's code verbatim, and a generated adversarial
  pass over every function documented above.

Two things this does not prove, stated plainly: the timings above come from one shared machine and will differ on
yours, and the suite runs on Windows with the VM runtime (other targets and YYC were not built).

## Licence

See `LICENSE.txt`. Use it in unlimited games, commercial or free; modify it freely; do not resell the package itself.

Made by Core Systems Asset Factory. Written with AI assistance, disclosed on every store page that carries it.
