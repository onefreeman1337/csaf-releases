# Cloudshadow - Drifting Cloud Shadows for GameMaker

The shadows of passing clouds, drifting across your rooms. Cloudshadow reads the room you already built (which cells are
water, roof, cliff, wall or open ground) and draws the weather's shadow over it, every frame, as one quad. Nothing is
authored, no sprite is painted, and nothing your game draws is replaced: what is under the clouds is darkened and cooled,
the way ground looks when a cloud takes the sun.

- **Thirteen skies, each built differently, not recoloured:** clear, fair, popcorn cumulus, scattered, broken, a
  mackerel sky in rows across the wind, cirrus streaks, a high veil, overcast, fog banks, a squall line, towering
  cumulonimbus with soft anvils sheared downwind, and storm. Changing sky crossfades over the seconds you choose.
- **Three altitudes drift at three speeds** (0.56, 1.28 and 2.0 cells a second at the designed wind), along a wind that
  slowly veers, so the weather never moves as one rigid sheet and never repeats a loop you could spot.
- **The shadow lands by surface.** Water loses the most light and goes coolest (it mirrors the sky). A roof stands two
  cells up, so a cloud reaches it before the ground beside it. A wall face takes a grazing change. A covered cell takes
  none. The deepest shadow is capped at 58% of the light, so no setting punches a black hole in your room.
- **It reads your room.** Tile layers are classified by their names (Water, Roof, Cliff, Wall, Interior...), or by your
  rules: a layer, a list of tile indices, an object, a rectangle. The sky is derived from the room's make-up unless you
  set one. A room with almost nothing open to the sky opts itself out.
- **Your game logic can ask.** `cls_shade_at(x, y)` returns how much light the clouds are taking at a point right now,
  from the same arithmetic the shader runs: plants that want sun, a stealth bonus in shade, a vampire who burns in it.

Ported from our RPG Maker MZ plugin Cloudshadow and held to it: the in-engine suite checks every cloud mass and every
shade value of the MZ edition's five skies against the MZ code, exactly (see Verification).

## Install

1. In GameMaker, **Tools > Import Local Package**, choose `Cloudshadow.yymps`, and import everything.
2. Run the project with `rm_cls_demo` first in the room order. The demo is a painted valley: a lake, a cottage, a cliff,
   a road. LEFT and RIGHT change the sky, W turns the wind, N switches day and night, M shows the surface map Cloudshadow
   read from the room, H hides the panel. The panel reads `cls_shade_at` under the mouse.

Requires GameMaker 2024.14 or later. Built and tested on runtime 2024.14.4.268 (the VM, Windows). Pure GML and two small
GLSL ES shaders; no extension, no DLL; nothing here depends on GMRT.

## Quickstart

**Drop it in.** Put `obj_cls_shadow` in your room on a layer ABOVE everything the shadows should fall on (the ground,
your tile layers, your characters) and BELOW what they should not (rain and sky effects, the HUD). That is the whole
installation: it starts in its Create event, moves the clouds in Step, draws in Draw and frees everything in Clean Up.

**Tell it what your tile layers are.** Layers whose names contain a known word are read automatically: `water`, `sea`,
`lake`, `river`, `pond` are water; `roof` is roof; `cliff`, `ledge`, `walltop` are cliff tops; `wall` is a wall face;
`interior`, `indoor`, `cover`, `cave`, `canopy` are under cover (no cloud shadow); `ground`, `grass`, `floor`, `path`,
`road` are ground. Any cell nothing classifies is open ground. For anything else, say it once after the object exists:

```gml
// in the Create event of any object created after obj_cls_shadow (or in obj_cls_shadow's own Create, after cls_start)
cls_surface_layer("Tiles_Harbour", "water");     // every tile on this layer is water
cls_surface_tiles("Tiles_Town", "roof", [2, 3]);  // only these tile indices of a mixed layer are roof
cls_surface_rect(0, 0, 320, 96, "cover");        // a covered market: cells whose centres are inside take no shadow
```

**Choose the weather, or let the room choose it.**

```gml
cls_set_sky("squall", 6);        // crossfade to a squall line over six seconds (held across rooms until released)
cls_set_wind(200, 1.4);          // the clouds travel towards 200 degrees (GameMaker's: 0 right, 90 up) at 1.4x speed
cls_set_daylight(0.3);           // dusk: a cloud cannot take sunlight that has set, so the shadow eases off
cls_derive_sky();                // hand the sky back to the room's make-up
```

**Ask it in game logic.**

```gml
var my_light_lost = cls_shade_at(x, y);          // 0 in full sun .. 0.58 under the thickest cloud
if (cls_in_shadow(x, y, 0.2)) { stealth_bonus = 1; }
```

**Save it.** `cls_save()` returns a short JSON string with the sky, a fade under way, the wind and the clouds' place;
`cls_load(text)` restores it. Weather the player has already seen also carries from room to room on its own: a held sky
stays held, and the clouds keep their place.

## How it reads your room

- **The cell.** The surface map has one cell per tile of the first classified tile layer (or 32 px when there is none, or
  whatever `cls_start({ cell: 16 })` asks for). A room more than 2,046 cells wide gets a coarser map.
- **Top layer first.** For each cell, the classified tile layer nearest the camera (lowest depth) with a tile there
  decides. Then objects (`cls_surface_object`), then rectangles (`cls_surface_rect`), in the order you added them.
- **Objects.** `cls_surface_object(your_house_object, "roof")` marks the cells under every instance's bounding box
  (cells whose centres lie inside it). The map is
  read when the room starts; call `cls_surface_rebuild()` after you add or remove tiles or classified objects.
- **The sky the room asks for.** More than 30% water reads as a coast (scattered); more than 35% roof and wall reads as a
  town (clear); more than 8% water reads as fair; a dark room (`cls_set_daylight` under 0.4) turns fair or scattered to
  overcast. `cls_set_sky` overrides it.
- **Interiors.** With under 2% of the cells open to the sky, Cloudshadow draws nothing (`cls_start({ interior: "on" })`
  forces it off, `"off"` forces it on).
- **See what it read.** `cls_draw_surface_map()` draws the classification over the room (water blue, roof red, cliff top
  amber, wall grey, object green, cover dark): the demo's M key.

## The thirteen skies

| Sky | How it is built |
| --- | --- |
| clear | five small heaps, one altitude; barely any shadow |
| fair | eleven heaps on two altitudes |
| popcorn | forty-four small hard-edged cumulus humilis, low |
| scattered | seventeen ragged masses on two altitudes |
| broken | more cloud than sky: twenty-one large masses, two altitudes, no sheet |
| mackerel | sixty small high puffs in ten rows ACROSS the wind, each drawn out along its row |
| cirrus | sixteen high streaks, each at least fifteen times longer than wide, the faintest shadow |
| veil | a thin high SHEET over the whole sky with a little modulation (cirrostratus) |
| overcast | a low grey sheet with seven long masses thickening it |
| fog | six huge soft banks dragging slowly over the ground, over a light sheet |
| squall | a FRONT: two thirds of thirty storm cells packed in a band across the wind, broken weather behind it |
| towering | four giant hard-cored towers, each with a soft anvil on the high layer, sheared downwind |
| storm | twenty-three ragged masses on all three altitudes over a dark sheet |

`cls_start({ seed: 7 })` or `cls_set_seed(7)` gives the same sky different clouds (each room can have its own); seed 0
is the RPG Maker MZ edition's clouds.

## Reference

Everything below is documented again, with its arguments, in the header of each function in `cls_cloudshadow.gml` and
`cls_core.gml`.

| Function | What it does |
| --- | --- |
| `cls_start([options])` | start in this room (`sky`, `wind`, `wind_speed`, `veer`, `intensity`, `coolness`, `night_floor`, `cell`, `seed`, `auto_layers`, `interior`) |
| `cls_stop()` | stop and free every surface and buffer |
| `cls_is_running()` | true while running |
| `cls_update()` | one step of weather (obj_cls_shadow's Step) |
| `cls_draw()` | draw the shadows over the view (obj_cls_shadow's Draw) |
| `cls_set_sky(name, [seconds])` | change the sky with a crossfade; the sky is then held |
| `cls_get_sky()` | the sky showing |
| `cls_derive_sky()` | hand the sky back to the room |
| `cls_set_wind(degrees, [speed])` / `cls_get_wind()` | the direction the clouds travel and their speed |
| `cls_set_intensity(v)` / `cls_set_coolness(v)` / `cls_set_daylight(v)` | scale the effect, its cool cast, the sun |
| `cls_set_enabled(on)` / `cls_set_seed(n)` | hide the shadows; vary the clouds |
| `cls_surface_layer(layer, kind)` / `cls_surface_tiles(layer, kind, indices)` | classify a tile layer, or some of its tiles |
| `cls_surface_object(object, kind)` / `cls_surface_rect(x1, y1, x2, y2, kind)` | classify objects' boxes, rectangles |
| `cls_surface_rebuild()` / `cls_surface_kind_at(x, y)` | read the room again; the kind of a cell |
| `cls_draw_surface_map([alpha])` | the debug view of what was read |
| `cls_shade_at(x, y)` / `cls_in_shadow(x, y, [threshold])` | the light the clouds take at a point now |
| `cls_save()` / `cls_load(text)` | the weather as JSON |
| `cls_info()` | the sky, the wind, the map's size and make-up, timings |
| `cls_kind_names()` / `cls_sky_names()` / `cls_sky_exists(name)` / `cls_sky_spec(name)` | the vocabularies |
| `cls_field(w, h, sky, seed, [wind])` | the pure cloud model (`cls_core.gml`): a field of cloud masses |
| `cls_shade_at_field(field, x, y, t, [layer])` / `cls_measure(field, t, step)` | the light a field takes at a point; what a field does overall |
| `cls_hash(text)` / `cls_rng(seed)` / `cls_rng_next(rng)` | the seeded hash and generator (never the engine's random functions) |
| `cls_vnoise(seed, L, u, v)` / `cls_turbulence(seed, L, u, v)` | the wrapping lattice noise that roughens every cloud edge |

Kinds: `"ground"`, `"water"`, `"roof"`, `"walltop"`, `"wallside"`, `"object"`, `"cover"`.

## Performance

Measured on our test machine, a shared and busy one (runtime 2024.14.4.268, the VM, Windows), over the test runs quoted.
Yours will differ.

- **Every frame: one quad**, one shader, three texture reads per sky (six during a crossfade). Nothing is read back from
  the GPU while you play and nothing is allocated per frame.
- **A sky's first use** builds its cloud field and its noise table on the CPU (34 to 64 ms over three runs; the 64 on a
  busy machine) and bakes its sheet on the GPU (0.6 to 1.3 ms; the very first bake of a session 4 to 5 ms, while the
  shader warms up). Each sky is built once per room. Set the room's sky at the start, or warm a sky you will fade to.
- **Reading the room**: 2.4 to 3.3 ms for the 884-cell demo valley; it grows with the number of cells times classified
  layers.
- **`cls_shade_at`**: 0.31 to 0.41 ms a call over four runs. Ask for a handful of points a step.

## Differences from the RPG Maker MZ edition

- **Thirteen skies instead of five.** clear, fair, scattered, overcast and storm are the MZ edition's, cloud for cloud
  at seed 0; the eight others are new constructions.
- **A change of sky crossfades two baked sheets**, so nothing pops; the MZ edition swaps the sheet and fades the layers.
- **The clouds are drawn out ALONG the wind** whatever its direction (the MZ sheet stays axis-aligned), and the wind veers.
- **Your rooms are read through layer names and rules** instead of RPG Maker's tile tables, region ids and map notes.
- **Day and night is a number you pass** (`cls_set_daylight`) instead of a read of RPG Maker's screen tone.

## Verification

GameMaker code cannot be unit-tested outside the engine, so everything below ran in real executables built by GameMaker's
own compiler (Igor, runtime 2024.14.4.268):

- **The cloud model, held to the RPG Maker MZ edition run in Node, EXACTLY:** 12 hashes, 70 generator draws, 30 noise
  and turbulence points, 25 fields over five sizes and winds (315 cloud masses, every coordinate, radius, edge, altitude
  and drift), shade at 810 points at three moments each, and the MZ edition's own measurements of all five skies.
- **Every sky's sheet read back from the GPU** and compared with the exact cloud field at 39,936 samples: worst 5.2 of
  255, mean 0.04.
- **The shadow read back from the GPU** over the demo valley in six skies and compared with the same arithmetic on the
  CPU: worst 1.6 of 255. `cls_shade_at`, which reads the exact field rather than the baked sheet, agrees with the picture
  to within 1.2 of 255 at 95% of points, and can be about a tenth of the light apart (28 of 255 at worst) for a pixel or
  two along a ragged cloud edge.
- **The surface map** read from the demo's four marker tile layers cell for cell; layer rules, tile lists, rectangles and
  an object's box; motion (after one second the shade has moved exactly the measured distance downwind); fades; save and
  load; the 58% ceiling at intensity 25 on the CPU and on the GPU; interiors; bad input on every documented function.
- **A blank project** that installed the package the way you will and ran this Readme's own code, with what it drew
  counted; and an adversarial pass of the documented functions (undefined, negative, huge and wrong-typed arguments).

Two things this does not prove, stated plainly: the timings come from one shared machine and will differ on yours, and
the suite ran on Windows with the VM runtime only (HTML5, mobile and YYC were not built). The shaders are GLSL ES and use
`highp` where they carry positions; a platform without it falls back to its default precision.

## Fonts

The demo panel is lettered in two faces rasterised into font resources: Cinzel Bold and Alegreya, both SIL Open Font
License 1.1. The licence texts and the notices are in `Cloudshadow/fonts/`. The runtime itself uses no font.

## Licence

See `LICENSE.txt`. Use it in unlimited games, commercial or free; modify it freely; do not resell the package itself.

Made by Core Systems Asset Factory. Written with AI assistance, disclosed on every store page that carries it. The demo
valley is a painting made for the RPG Maker MZ edition of this product.
