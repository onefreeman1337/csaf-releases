{
  "$GMTileSet": "v1",
  "%Name": "ts_cls_marks",
  "autoTileSets": [],
  "macroPageTiles": {
    "SerialiseHeight": 0,
    "SerialiseWidth": 0,
    "TileSerialiseData": []
  },
  "name": "ts_cls_marks",
  "out_columns": 5,
  "out_tilehborder": 2,
  "out_tilevborder": 2,
  "parent": {
    "name": "Tile Sets",
    "path": "folders/Tile Sets.yy"
  },
  "resourceType": "GMTileSet",
  "resourceVersion": "2.0",
  "spriteId": {
    "name": "spr_cls_marks",
    "path": "sprites/spr_cls_marks/spr_cls_marks.yy"
  },
  "spriteNoExport": false,
  "textureGroupId": {
    "name": "Default",
    "path": "texturegroups/Default"
  },
  "tileAnimationFrames": [],
  "tileAnimationSpeed": 15,
  "tileHeight": 24,
  "tilehsep": 0,
  "tilevsep": 0,
  "tileWidth": 24,
  "tilexoff": 0,
  "tileyoff": 0,
  "tile_count": 5
}