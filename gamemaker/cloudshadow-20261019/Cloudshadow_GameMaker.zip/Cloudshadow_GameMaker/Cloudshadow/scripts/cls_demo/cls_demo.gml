/// cls_demo.gml - Cloudshadow's demo room: a painted valley (a lake, a cottage, a cliff, a road) under weather you can
/// change. The ground is a picture; the surface map comes from four INVISIBLE tile layers named Water, Roof, Cliff and
/// Wall, which Cloudshadow reads by their names - the technique works over any art, including a single painted backdrop.
///
/// Cloudshadow - Drifting Cloud Shadows for GameMaker. Copyright (c) 2026 Core Systems Asset Factory.
///
/// Keys: LEFT / RIGHT change the sky (a 4 second crossfade) . W turns the wind . N day / night . M shows the surface map
/// . H hides this panel. The panel reads cls_shade_at under the mouse: the same number game logic would get.

/// @function cls_demo_build_markers()
/// @description Make the demo's four invisible marker tile layers from cls_demo_ground_kinds(). Returns the layer ids.
/// @returns {Array<Id.Layer>}
function cls_demo_build_markers() {
    var _rows = cls_demo_ground_kinds(), _cell = cls_demo_ground_cell();
    var _names = ["Water", "Roof", "Cliff", "Wall"], _chars = ["w", "r", "c", "s"], _out = [];
    var _h = array_length(_rows), _w = string_length(_rows[0]);
    for (var _k = 0; _k < 4; _k++) {
        var _old = layer_get_id(_names[_k]);
        if (_old != -1) layer_destroy(_old);
        var _ly = layer_create(50, _names[_k]);
        var _tm = layer_tilemap_create(_ly, 0, 0, ts_cls_marks, _w, _h);
        for (var _y = 0; _y < _h; _y++) {
            var _r = _rows[_y];
            for (var _x = 0; _x < _w; _x++) if (string_char_at(_r, _x + 1) == _chars[_k]) tilemap_set(_tm, _k + 1, _x, _y);
        }
        layer_set_visible(_ly, false);
        array_push(_out, _ly);
    }
    return _out;
}

/// @function cls_demo_create()
/// @description Build the demo: the marker layers, then Cloudshadow itself (obj_cls_shadow on the Instances layer, above
/// the painted ground). Returns the demo's state.
/// @returns {Struct}
function cls_demo_create() {
    var _layers = cls_demo_build_markers();
    var _il = layer_get_id("Instances");
    if (_il == -1) _il = layer_create(0, "Instances");
    instance_create_layer(0, 0, _il, obj_cls_shadow);
    return { layers: _layers, sky_index: -1, show_map: false, night: false, hide: false, wind_steps: 0 };
}

/// @function cls_demo_step(demo)
/// @description The demo's keys.
function cls_demo_step(_d) {
    if (!is_struct(_d)) return;
    var _names = cls_sky_names(), _n = array_length(_names);
    if (_d.sky_index < 0) { var _cur = cls_get_sky(); for (var _i = 0; _i < _n; _i++) if (_names[_i] == _cur) _d.sky_index = _i; if (_d.sky_index < 0) _d.sky_index = 0; }
    if (keyboard_check_pressed(vk_right)) { _d.sky_index = (_d.sky_index + 1) mod _n; cls_set_sky(_names[_d.sky_index], 4); }
    if (keyboard_check_pressed(vk_left)) { _d.sky_index = (_d.sky_index + _n - 1) mod _n; cls_set_sky(_names[_d.sky_index], 4); }
    if (keyboard_check_pressed(ord("W"))) { var _w = cls_get_wind(); if (is_struct(_w)) cls_set_wind(_w.degrees + 45); }
    if (keyboard_check_pressed(ord("N"))) { _d.night = !_d.night; cls_set_daylight(_d.night ? 0 : 1); }
    if (keyboard_check_pressed(ord("M"))) _d.show_map = !_d.show_map;
    if (keyboard_check_pressed(ord("H"))) _d.hide = !_d.hide;
}

/// @function cls_demo_draw_gui(demo)
/// @description The demo's panel: the sky, the wind, and what cls_shade_at reads under the mouse.
function cls_demo_draw_gui(_d) {
    if (!is_struct(_d)) return;
    // the demo room has no views, so the GUI is the room: the surface map can be drawn here in room coordinates
    if (_d.show_map) cls_draw_surface_map(0.5);
    if (_d.hide) return;
    var _info = cls_info();
    if (!is_struct(_info)) return;
    var _x = 18, _y = 18, _w = 318, _h = 150;
    draw_set_alpha(0.80); draw_set_colour(make_colour_rgb(18, 22, 30));
    draw_rectangle(_x, _y, _x + _w, _y + _h, false);
    draw_set_alpha(0.85); draw_set_colour(make_colour_rgb(200, 164, 90));
    draw_rectangle(_x, _y, _x + _w, _y + _h, true);
    draw_line(_x + 14, _y + 42, _x + _w - 14, _y + 42);
    draw_set_alpha(1);
    draw_set_halign(fa_left); draw_set_valign(fa_top);
    draw_set_font(fnt_cloudshadow_display_s); draw_set_colour(make_colour_rgb(236, 224, 196));
    draw_text_transformed(_x + 14, _y + 9, "CLOUDSHADOW", 0.5, 0.5, 0);
    draw_set_font(fnt_cloudshadow_body_l); draw_set_colour(make_colour_rgb(246, 240, 226));
    var _sky = string_upper(string_char_at(_info.sky, 1)) + string_copy(_info.sky, 2, 99);
    var _line = _sky;
    if (_info.prev_sky != "") _line += "   from " + _info.prev_sky + " " + string(floor(_info.blend * 100)) + "%";
    draw_text_transformed(_x + 14, _y + 48, _line, 0.5, 0.5, 0);
    draw_set_font(fnt_cloudshadow_body_s); draw_set_colour(make_colour_rgb(176, 184, 196));
    draw_text_transformed(_x + 14, _y + 76, "wind " + string(round(_info.wind_now)) + " deg   " + (_d.night ? "night" : "day") + "   " + string(_info.cols) + " x " + string(_info.rows) + " cells", 0.5, 0.5, 0);
    var _mx = mouse_x, _my = mouse_y;
    var _s = cls_shade_at(_mx, _my), _k = cls_surface_kind_at(_mx, _my);
    draw_set_colour(make_colour_rgb(232, 210, 150));
    draw_text_transformed(_x + 14, _y + 96, "under the cursor: " + _k + ", " + string(round(_s * 100)) + "% of the light taken", 0.5, 0.5, 0);
    draw_set_colour(make_colour_rgb(150, 158, 172));
    draw_text_transformed(_x + 14, _y + 120, "LEFT RIGHT sky   W wind   N night   M map   H hide", 0.5, 0.5, 0);
    draw_set_colour(c_white);
}
