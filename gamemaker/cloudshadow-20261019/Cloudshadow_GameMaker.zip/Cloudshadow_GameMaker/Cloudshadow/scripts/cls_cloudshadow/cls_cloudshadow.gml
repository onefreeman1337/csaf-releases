/// cls_cloudshadow.gml - Cloudshadow's runtime: the drifting shadow of passing clouds over a room, generated from the room.
///
/// Cloudshadow - Drifting Cloud Shadows for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// What it does
///   It reads the room (tile layers by name, objects, rectangles) into a SURFACE MAP - which cells are water, roof, cliff,
///   wall, ground or under cover - and picks a sky from it. It bakes the sky's cloud field (cls_core) into a small tiling
///   sheet on the GPU, once per sky, and every frame draws ONE quad over the view that multiplies what the game has drawn
///   by the light left under the clouds. Three altitudes drift at three speeds along a wind that slowly veers; a roof
///   catches a cloud before the ground beside it; water loses the most light and goes coolest; a covered cell takes none.
///
/// Use it
///   Put obj_cls_shadow in the room on a layer ABOVE everything the shadow should fall on (ground, tiles, characters) and
///   BELOW what it should not (sky effects, HUD). That is the whole installation. Or call cls_start / cls_update / cls_draw
///   / cls_stop from your own object's Create / Step / Draw / Clean Up.
///
/// Public functions (each documented below): cls_start, cls_stop, cls_is_running, cls_update, cls_draw, cls_set_sky,
/// cls_get_sky, cls_derive_sky, cls_set_wind, cls_get_wind, cls_set_intensity, cls_set_coolness, cls_set_daylight,
/// cls_set_enabled, cls_set_seed, cls_surface_layer, cls_surface_tiles, cls_surface_object, cls_surface_rect,
/// cls_surface_rebuild, cls_surface_kind_at, cls_shade_at, cls_in_shadow, cls_save, cls_load, cls_info, cls_kind_names,
/// cls_draw_surface_map.

#macro CLS_SHEET 256
#macro CLS_LAT 128
#macro CLS_CELLS_PER_SEC 1.6
#macro CLS_ALT_SHIFT 0.55

// ---------------------------------------------------------------------------------------------------------------
// Surfaces: how each kind of cell takes the shadow (the MZ edition's tables)
// ---------------------------------------------------------------------------------------------------------------

/// @function cls_kind_names()
/// @description Every surface kind, in id order: "ground" (the default for any cell nothing classifies), "water", "roof",
/// "walltop" (cliff tops, wall tops), "wallside" (vertical faces), "object" (props), "cover" (under a roof or a canopy:
/// no cloud shadow at all).
/// @returns {Array<String>}
function cls_kind_names() { return ["ground", "water", "roof", "walltop", "wallside", "object", "cover"]; }

/// @function cls__kind_id(name)
/// @description Internal. A kind's id, or -1.
function cls__kind_id(_n) {
    if (!is_string(_n)) return -1;
    var _k = cls_kind_names(), _l = string_lower(_n);
    for (var _i = 0; _i < array_length(_k); _i++) if (_k[_i] == _l) return _i;
    return -1;
}

/// @function cls__kind_table()
/// @description Internal. Per kind id: [response (share of the shadow it takes), altitude in cells, coolness, open to sky].
/// Water changes most and goes coolest (it mirrors the sky); a roof stands two cells up, so a cloud reaches it first; a
/// wall face takes a grazing change; a covered cell takes none.
function cls__kind_table() {
    static _t = [[0.80, 0.0, 0.50, 1], [1.00, 0.0, 1.00, 1], [0.92, 2.0, 0.55, 1], [0.88, 1.4, 0.60, 1], [0.45, 0.7, 0.35, 1], [0.70, 0.2, 0.45, 1], [0.0, 0.0, 0.0, 0]];
    return _t;
}

/// @function cls__auto_kind(layer_name)
/// @description Internal. The kind a tile layer's NAME says it is, or -1 (the layer is not read). Cover first, so
/// "Indoor Walls" is cover, not wall.
function cls__auto_kind(_name) {
    var _n = string_lower(_name);
    var _cover = ["interior", "indoor", "inside", "cover", "cave", "canopy"];
    var _roof = ["roof"];
    var _top = ["cliff", "walltop", "wall_top", "wall top", "ledge", "plateau"];
    var _side = ["wall", "facade"];
    var _water = ["water", "sea", "lake", "river", "ocean", "pond", "swamp", "marsh"];
    var _ground = ["ground", "grass", "floor", "terrain", "path", "road", "sand", "dirt", "field", "soil"];
    var _obj = ["deco", "prop", "object", "furniture"];
    var _lists = [_cover, _roof, _top, _side, _water, _ground, _obj], _ids = [6, 2, 3, 4, 1, 0, 5];
    for (var _i = 0; _i < array_length(_lists); _i++) {
        var _l = _lists[_i];
        for (var _j = 0; _j < array_length(_l); _j++) if (string_pos(_l[_j], _n) > 0) return _ids[_i];
    }
    return -1;
}

// ---------------------------------------------------------------------------------------------------------------
// The runtime
// ---------------------------------------------------------------------------------------------------------------

/// @function cls__rt()
/// @description Internal. The running instance, or undefined.
function cls__rt() { return variable_global_exists("__cls") ? global.__cls : undefined; }

/// @function cls__num(v, fallback)
/// @description Internal. v when it is a finite number, else the fallback.
function cls__num(_v, _d) {
    if (!is_numeric(_v)) return _d;
    if (is_real(_v) && (is_nan(_v) || is_infinity(_v))) return _d;
    return real(_v);
}

/// @function cls__opt(options, name, fallback)
/// @description Internal. An option, or the fallback.
function cls__opt(_o, _k, _d) { return (is_struct(_o) && variable_struct_exists(_o, _k)) ? _o[$ _k] : _d; }

/// @function cls_start([options])
/// @description Start Cloudshadow in the current room (obj_cls_shadow's Create calls it). Starting again replaces the
/// running instance. Weather the player has already seen carries over from the previous room: a sky set with cls_set_sky
/// stays set, and the clouds keep their place. Every option is optional:
///   sky          a sky name to hold (default: derived from the room - see cls_derive_sky)
///   wind         degrees, GameMaker's convention (0 right, 90 up), the way the clouds TRAVEL (default: per room)
///   wind_speed   1 = the designed speed (0.56 / 1.28 / 2.0 cells a second for the three altitudes); 0 holds still
///   veer         degrees the wind wanders either side of its direction, slowly (default 9; 0 = a steady wind)
///   intensity    scales the whole effect (default 1)
///   coolness     scales the cool cast of shaded light (default 1; 0 = a plain grey dimming)
///   night_floor  how much of the effect survives at daylight 0 (default 0.25 - see cls_set_daylight)
///   cell         the surface-map cell in pixels (default: the first classified tile layer's tile width, else 32)
///   seed         varies the clouds without changing the sky (default 0, the RPG Maker MZ edition's clouds)
///   auto_layers  read tile layers by their names (default true; see cls_surface_layer)
///   interior     "auto" (default: a room with almost nothing open to the sky opts out), "on" or "off"
/// @param {Struct} [options]
/// @returns {Bool} true when started
function cls_start(_o = undefined) {
    if (!is_undefined(cls__rt())) cls_stop();
    var _carry = variable_global_exists("__cls_carry") ? global.__cls_carry : undefined;
    var _room_name = room_get_name(room);
    var _rt = {
        room_name: _room_name,
        enabled: true,
        intensity: max(0, cls__num(cls__opt(_o, "intensity", 1), 1)),
        coolness: max(0, cls__num(cls__opt(_o, "coolness", 1), 1)),
        night_floor: clamp(cls__num(cls__opt(_o, "night_floor", 0.25), 0.25), 0, 1),
        daylight: 1,
        cell_req: max(0, cls__num(cls__opt(_o, "cell", 0), 0)),
        seed: cls__num(cls__opt(_o, "seed", 0), 0),
        auto_layers: (cls__opt(_o, "auto_layers", true) == true),
        interior_mode: "auto",
        sky: "fair", sky_why: "initial", prev_sky: undefined, blend: 1, blend_rate: 0, held: false,
        wind_deg: (cls_hash("wind:" + _room_name) mod 3600) / 10, wind_set: false,
        wind_speed: max(0, cls__num(cls__opt(_o, "wind_speed", 1), 1)),
        veer: max(0, cls__num(cls__opt(_o, "veer", 9), 9)),
        phase: 0, off: [0, 0, 0, 0, 0, 0], dir_now: 0,
        rules_layers: [], rules_objects: [], rules_rects: [],
        map: { dirty: true, cw: 32, ch: 32, cols: 0, rows: 0, kinds: [], counts: [0, 0, 0, 0, 0, 0, 0], open: 1, buffer: -1, surface: -1, ms: 0, layers_read: [] },
        sheets: {}, stats: { bakes: 0, bake_ms: 0, map_ms: 0, draws: 0 },
    };
    var _im = cls__opt(_o, "interior", "auto");
    if (_im == "on" || _im == "off" || _im == "auto") _rt.interior_mode = _im;
    // weather the player has already seen carries over (a held sky, the clouds' place, a wind someone set)
    if (is_struct(_carry)) {
        if (_carry.held && cls_sky_exists(_carry.sky)) { _rt.sky = _carry.sky; _rt.held = true; _rt.sky_why = "held by cls_set_sky"; }
        _rt.phase = _carry.phase; _rt.off = _carry.off;
        if (_carry.wind_set) { _rt.wind_deg = _carry.wind_deg; _rt.wind_set = true; }
    }
    var _wd = cls__opt(_o, "wind", undefined);
    if (is_numeric(_wd)) { _rt.wind_deg = cls__num(_wd, _rt.wind_deg); _rt.wind_set = true; }
    var _sk = cls__opt(_o, "sky", undefined);
    if (cls_sky_exists(_sk)) { _rt.sky = _sk; _rt.held = true; _rt.sky_why = "start option"; }
    _rt.dir_now = _rt.wind_deg;
    global.__cls = _rt;
    return true;
}

/// @function cls_stop()
/// @description Stop Cloudshadow and free every surface and buffer it made (obj_cls_shadow's Clean Up calls it). The
/// weather's place is remembered for the next room.
function cls_stop() {
    var _rt = cls__rt();
    if (is_undefined(_rt)) return;
    global.__cls_carry = { sky: _rt.sky, held: _rt.held, phase: _rt.phase, off: _rt.off, wind_deg: _rt.wind_deg, wind_set: _rt.wind_set };
    if (surface_exists(_rt.map.surface)) surface_free(_rt.map.surface);
    if (buffer_exists(_rt.map.buffer)) buffer_delete(_rt.map.buffer);
    var _k = variable_struct_get_names(_rt.sheets);
    for (var _i = 0; _i < array_length(_k); _i++) cls__sheet_free(_rt.sheets[$ _k[_i]]);
    global.__cls = undefined;
}

/// @function cls_is_running()
/// @description True when Cloudshadow is running in this room.
/// @returns {Bool}
function cls_is_running() { return !is_undefined(cls__rt()); }

// ---------------------------------------------------------------------------------------------------------------
// The surface map
// ---------------------------------------------------------------------------------------------------------------

/// @function cls_surface_layer(layer_name, kind)
/// @description Say what a tile layer is: every tile drawn on it is that kind. Overrides the name-based guess. kind is a
/// name from cls_kind_names, or "none" to stop reading the layer. Applies at the next rebuild (done for you).
/// @param {String} layer_name
/// @param {String} kind
/// @returns {Bool} false for an unknown kind
function cls_surface_layer(_layer, _kind) { return cls__add_layer_rule(_layer, _kind, undefined); }

/// @function cls_surface_tiles(layer_name, kind, tile_indices)
/// @description Only the listed tile indices of a tile layer are that kind (for a layer that mixes water and land).
/// @param {String} layer_name
/// @param {String} kind
/// @param {Array<Real>} tile_indices
/// @returns {Bool}
function cls_surface_tiles(_layer, _kind, _tiles) {
    if (!is_array(_tiles)) return false;
    return cls__add_layer_rule(_layer, _kind, _tiles);
}

/// @function cls__add_layer_rule(layer, kind, tiles)
/// @description Internal.
function cls__add_layer_rule(_layer, _kind, _tiles) {
    var _rt = cls__rt();
    if (is_undefined(_rt) || !is_string(_layer)) return false;
    var _id = (_kind == "none") ? -2 : cls__kind_id(_kind);
    if (_id == -1) return false;
    var _set = undefined;
    if (is_array(_tiles)) { _set = {}; for (var _i = 0; _i < array_length(_tiles); _i++) if (is_numeric(_tiles[_i])) _set[$ string(floor(_tiles[_i]))] = true; }
    array_push(_rt.rules_layers, { name: string_lower(_layer), kind: _id, tiles: _set });
    _rt.map.dirty = true;
    return true;
}

/// @function cls_surface_object(object, kind)
/// @description Every instance of an object (and its children) marks the cells under its bounding box as that kind - a
/// building object as "roof", a tree canopy as "cover", a pond object as "water". Read at each rebuild.
/// @param {Asset.GMObject} object
/// @param {String} kind
/// @returns {Bool}
function cls_surface_object(_obj, _kind) {
    var _rt = cls__rt();
    // ⛔ an object asset is a reference on GameMaker 2024, not a number - MEASURED: an is_numeric guard refused
    // obj_cls_marker itself. Ask the engine, and treat anything it cannot answer as "no such object".
    if (is_undefined(_rt)) return false;
    var _exists = false;
    try { _exists = object_exists(_obj); } catch (_e) { _exists = false; }
    if (!_exists) return false;
    var _id = cls__kind_id(_kind);
    if (_id < 0) return false;
    array_push(_rt.rules_objects, { obj: _obj, kind: _id });
    _rt.map.dirty = true;
    return true;
}

/// @function cls_surface_rect(x1, y1, x2, y2, kind)
/// @description Mark a rectangle of the room (pixels) as a kind: every cell whose centre is at or right of x1 and left of
/// x2 (the same for y). Rectangles are applied after tile layers and objects.
/// @returns {Bool}
function cls_surface_rect(_x1, _y1, _x2, _y2, _kind) {
    var _rt = cls__rt();
    if (is_undefined(_rt)) return false;
    var _id = cls__kind_id(_kind);
    if (_id < 0) return false;
    if (!is_numeric(_x1) || !is_numeric(_y1) || !is_numeric(_x2) || !is_numeric(_y2)) return false;
    array_push(_rt.rules_rects, { x1: min(_x1, _x2), y1: min(_y1, _y2), x2: max(_x1, _x2), y2: max(_y1, _y2), kind: _id });
    _rt.map.dirty = true;
    return true;
}

/// @function cls_surface_rebuild()
/// @description Read the room again (after you add or remove tiles or classified objects). Cheap enough for a room start;
/// do not call it every step.
function cls_surface_rebuild() { var _rt = cls__rt(); if (!is_undefined(_rt)) _rt.map.dirty = true; }

/// @function cls__build_map(rt)
/// @description Internal. Classify every cell of the room, top tile layer first, then objects, then rectangles.
function cls__build_map(_rt) {
    var _t0 = get_timer();
    var _m = _rt.map;
    // the tile layers to read, with their kinds, top (lowest depth) first
    var _recs = [], _all = layer_get_all();
    for (var _i = 0; _i < array_length(_all); _i++) {
        var _ly = _all[_i];
        var _tm = layer_tilemap_get_id(_ly);
        if (_tm == -1) continue;
        var _nm = string_lower(layer_get_name(_ly)), _kind = -1, _tiles = undefined, _ruled = false;
        for (var _r = array_length(_rt.rules_layers) - 1; _r >= 0; _r--) {
            var _rl = _rt.rules_layers[_r];
            if (_rl.name == _nm) { _kind = _rl.kind; _tiles = _rl.tiles; _ruled = true; break; }
        }
        if (!_ruled && _rt.auto_layers) _kind = cls__auto_kind(_nm);
        if (_kind < 0) continue;
        array_push(_recs, { tm: _tm, kind: _kind, tiles: _tiles, depth: layer_get_depth(_ly), name: _nm });
    }
    array_sort(_recs, function(_a, _b) { return _a.depth - _b.depth; });
    // the cell: asked for, else the first classified tile layer's tile, else 32
    var _cw = _rt.cell_req, _ch = _rt.cell_req;
    if (_cw <= 0) {
        if (array_length(_recs) > 0) { _cw = tilemap_get_tile_width(_recs[0].tm); _ch = tilemap_get_tile_height(_recs[0].tm); }
        else { _cw = 32; _ch = 32; }
    }
    _cw = max(4, _cw); _ch = max(4, _ch);
    // never more than 2046 cells a side (a 2048 texture with its ring): a bigger room gets a coarser map
    while (ceil(room_width / _cw) > 2046) _cw *= 2;
    while (ceil(room_height / _ch) > 2046) _ch *= 2;
    var _cols = max(1, ceil(room_width / _cw)), _rows = max(1, ceil(room_height / _ch));
    var _kinds = array_create(_cols * _rows, 0), _nrec = array_length(_recs);
    for (var _cy = 0; _cy < _rows; _cy++) {
        var _py = (_cy + 0.5) * _ch;
        for (var _cx = 0; _cx < _cols; _cx++) {
            var _px = (_cx + 0.5) * _cw;
            for (var _q = 0; _q < _nrec; _q++) {
                var _rec = _recs[_q];
                var _td = tilemap_get_at_pixel(_rec.tm, _px, _py);
                if (_td == -1) continue;
                var _ti = tile_get_index(_td);
                if (_ti <= 0) continue;
                if (!is_undefined(_rec.tiles) && !variable_struct_exists(_rec.tiles, string(_ti))) continue;
                _kinds[_cy * _cols + _cx] = _rec.kind;
                break;
            }
        }
    }
    // objects mark their bounding boxes, then rectangles
    for (var _o = 0; _o < array_length(_rt.rules_objects); _o++) {
        var _ro = _rt.rules_objects[_o];
        with (_ro.obj) cls__stamp(_kinds, _cols, _rows, _cw, _ch, bbox_left, bbox_top, bbox_right, bbox_bottom, _ro.kind);
    }
    for (var _r2 = 0; _r2 < array_length(_rt.rules_rects); _r2++) {
        var _rr = _rt.rules_rects[_r2];
        cls__stamp(_kinds, _cols, _rows, _cw, _ch, _rr.x1, _rr.y1, _rr.x2, _rr.y2, _rr.kind);
    }
    var _counts = [0, 0, 0, 0, 0, 0, 0], _open = 0, _n = _cols * _rows;
    for (var _k = 0; _k < _n; _k++) { _counts[_kinds[_k]] += 1; if (_kinds[_k] != 6) _open += 1; }
    // the map texture's bytes, with a one-cell ring copied from the edge (rooms do not loop)
    if (buffer_exists(_m.buffer)) buffer_delete(_m.buffer);
    if (surface_exists(_m.surface)) surface_free(_m.surface);
    var _sw = _cols + 2, _sh = _rows + 2;
    var _buf = buffer_create(_sw * _sh * 4, buffer_fixed, 1), _tab = cls__kind_table();
    for (var _sy = 0; _sy < _sh; _sy++) {
        var _my = clamp(_sy - 1, 0, _rows - 1);
        for (var _sx = 0; _sx < _sw; _sx++) {
            var _mx = clamp(_sx - 1, 0, _cols - 1);
            var _row = _tab[_kinds[_my * _cols + _mx]];
            buffer_write(_buf, buffer_u8, round(clamp(_row[0], 0, 1) * 255));
            buffer_write(_buf, buffer_u8, round(clamp(_row[1] / 3, 0, 1) * 255));
            buffer_write(_buf, buffer_u8, round(clamp(_row[2], 0, 1) * 255));
            buffer_write(_buf, buffer_u8, (_row[3] > 0) ? 255 : 0);
        }
    }
    _m.buffer = _buf; _m.surface = -1;
    _m.cw = _cw; _m.ch = _ch; _m.cols = _cols; _m.rows = _rows; _m.kinds = _kinds; _m.counts = _counts;
    _m.open = (_n > 0) ? _open / _n : 0;
    _m.layers_read = [];
    for (var _z = 0; _z < _nrec; _z++) array_push(_m.layers_read, _recs[_z].name + "=" + cls_kind_names()[_recs[_z].kind]);
    _m.dirty = false;
    _m.ms = (get_timer() - _t0) / 1000;
    _rt.stats.map_ms = _m.ms;
    if (!_rt.held) cls__derive(_rt);
}

/// @function cls__stamp(kinds, cols, rows, cw, ch, x1, y1, x2, y2, kind)
/// @description Internal. Mark every cell whose centre lies inside the HALF-OPEN box [x1, x2) x [y1, y2). Half-open
/// because GameMaker 2024 reports bbox_right / bbox_bottom one past the last pixel (MEASURED: a 240 x 48 box at
/// (600, 300) read 600, 300, 840, 348), so a closed test would claim a row the object does not cover.
function cls__stamp(_kinds, _cols, _rows, _cw, _ch, _x1, _y1, _x2, _y2, _kind) {
    var _c0 = max(0, ceil(_x1 / _cw - 0.5)), _c1 = min(_cols - 1, ceil(_x2 / _cw - 0.5) - 1);
    var _r0 = max(0, ceil(_y1 / _ch - 0.5)), _r1 = min(_rows - 1, ceil(_y2 / _ch - 0.5) - 1);
    for (var _r = _r0; _r <= _r1; _r++) for (var _c = _c0; _c <= _c1; _c++) _kinds[@ _r * _cols + _c] = _kind;
}

/// @function cls_surface_kind_at(x, y)
/// @description The kind of the cell under a room point ("ground", "water", ...), or "" when not running.
/// @returns {String}
function cls_surface_kind_at(_x, _y) {
    var _rt = cls__rt();
    if (is_undefined(_rt) || !is_numeric(_x) || !is_numeric(_y)) return "";
    if (_rt.map.dirty) cls__build_map(_rt);
    var _m = _rt.map;
    var _c = clamp(floor(_x / _m.cw), 0, _m.cols - 1), _r = clamp(floor(_y / _m.ch), 0, _m.rows - 1);
    return cls_kind_names()[_m.kinds[_r * _m.cols + _c]];
}

// ---------------------------------------------------------------------------------------------------------------
// The sky
// ---------------------------------------------------------------------------------------------------------------

/// @function cls__derive(rt)
/// @description Internal. The sky the room's make-up asks for: open water reads coastal (broken weather), a room that is
/// mostly roof and wall reads as a town (quieter), a dark room reads overcast.
function cls__derive(_rt) {
    var _c = _rt.map.counts, _tot = 0;
    for (var _i = 0; _i < 7; _i++) _tot += _c[_i];
    _tot = max(1, _tot);
    var _water = _c[1] / _tot, _built = (_c[2] + _c[3] + _c[4]) / _tot;
    var _sky = "fair";
    if (_water > 0.3) _sky = "scattered";
    else if (_built > 0.35) _sky = "clear";
    else if (_water > 0.08) _sky = "fair";
    if (_rt.daylight < 0.4 && (_sky == "scattered" || _sky == "fair")) _sky = "overcast";
    if (_sky != _rt.sky) { _rt.prev_sky = undefined; _rt.blend = 1; _rt.blend_rate = 0; }
    _rt.sky = _sky; _rt.sky_why = "room make-up";
}

/// @function cls_set_sky(name, [seconds])
/// @description Change the sky, crossfading over `seconds` (default 4; 0 = at once). The sky is then HELD - it survives
/// room changes - until cls_derive_sky hands it back to the room. A change mid-fade starts from what is showing.
/// @param {String} name     from cls_sky_names
/// @param {Real} [seconds]
/// @returns {Bool} false for an unknown sky or when not running
function cls_set_sky(_name, _sec = 4) {
    var _rt = cls__rt();
    if (is_undefined(_rt) || !cls_sky_exists(_name)) return false;
    var _s = max(0, cls__num(_sec, 4));
    _rt.held = true; _rt.sky_why = "held by cls_set_sky";
    if (_name == _rt.sky) return true;
    _rt.prev_sky = (_rt.blend < 0.5 && !is_undefined(_rt.prev_sky)) ? _rt.prev_sky : _rt.sky;
    _rt.sky = _name;
    if (_s <= 0) { _rt.blend = 1; _rt.blend_rate = 0; _rt.prev_sky = undefined; }
    else { _rt.blend = 0; _rt.blend_rate = 1 / _s; }
    return true;
}

/// @function cls_get_sky()
/// @description The sky showing (the one being faded TO during a change), or "" when not running.
/// @returns {String}
function cls_get_sky() { var _rt = cls__rt(); return is_undefined(_rt) ? "" : _rt.sky; }

/// @function cls_derive_sky()
/// @description Release a held sky: the room's own make-up picks it again.
function cls_derive_sky() {
    var _rt = cls__rt();
    if (is_undefined(_rt)) return;
    _rt.held = false;
    if (_rt.map.dirty) cls__build_map(_rt); else cls__derive(_rt);
    global.__cls_carry = undefined;
}

/// @function cls_set_wind(degrees, [speed])
/// @description Set the direction the clouds travel (GameMaker degrees: 0 right, 90 up) and, optionally, the speed (1 =
/// designed). The sheet turns to the new wind at once, so set it at a room start or a cut, not mid-scene.
/// @returns {Bool}
function cls_set_wind(_deg, _speed = undefined) {
    var _rt = cls__rt();
    if (is_undefined(_rt) || !is_numeric(_deg)) return false;
    _rt.wind_deg = ((cls__num(_deg, 0) mod 360) + 360) mod 360; _rt.wind_set = true;
    if (is_numeric(_speed)) _rt.wind_speed = max(0, cls__num(_speed, 1));
    return true;
}

/// @function cls_get_wind()
/// @description { degrees (the set direction), now (with the veer), speed }, or undefined when not running.
/// @returns {Struct|Undefined}
function cls_get_wind() { var _rt = cls__rt(); return is_undefined(_rt) ? undefined : { degrees: _rt.wind_deg, now: _rt.dir_now, speed: _rt.wind_speed }; }

/// @function cls_set_intensity(value)
/// @description Scale the whole effect (1 = designed). The deepest shadow is still capped at CLS_MAX_SHADE (58% of the
/// light), so no setting punches a black hole in the room.
function cls_set_intensity(_v) { var _rt = cls__rt(); if (!is_undefined(_rt)) _rt.intensity = max(0, cls__num(_v, _rt.intensity)); }

/// @function cls_set_coolness(value)
/// @description Scale the cool cast of shaded light (1 = designed, 0 = plain grey dimming).
function cls_set_coolness(_v) { var _rt = cls__rt(); if (!is_undefined(_rt)) _rt.coolness = max(0, cls__num(_v, _rt.coolness)); }

/// @function cls_set_daylight(value)
/// @description Tell Cloudshadow how much sun there is, 0 (night) .. 1 (day): a cloud cannot take sunlight that has set, so
/// the shadow shrinks toward the night floor. Feed it from your day/night system.
function cls_set_daylight(_v) { var _rt = cls__rt(); if (!is_undefined(_rt)) _rt.daylight = clamp(cls__num(_v, 1), 0, 1); }

/// @function cls_set_enabled(on)
/// @description Show or hide the shadows (the clouds keep moving while hidden).
function cls_set_enabled(_on) { var _rt = cls__rt(); if (!is_undefined(_rt)) _rt.enabled = (_on == true); }

/// @function cls_set_seed(seed)
/// @description Different clouds for the same sky (each room can have its own). 0 = the RPG Maker MZ edition's clouds.
function cls_set_seed(_s) {
    var _rt = cls__rt();
    if (is_undefined(_rt) || !is_numeric(_s)) return;
    _rt.seed = cls__num(_s, 0);
}

// ---------------------------------------------------------------------------------------------------------------
// The sheets: one baked cloud field per sky, on the GPU
// ---------------------------------------------------------------------------------------------------------------

/// @function cls__sheet(rt, sky)
/// @description Internal. The sheet record for a sky (field + lattice table), made on first use. Its surfaces are made by
/// cls__sheet_ready, in a draw event.
function cls__sheet(_rt, _sky) {
    var _key = _sky + "|" + string(_rt.seed);
    if (variable_struct_exists(_rt.sheets, _key)) return _rt.sheets[$ _key];
    var _seed = real((int64(cls_hash("sheet:" + _sky)) ^ cls__u32(_rt.seed)) & int64($FFFFFFFF));
    var _f = cls_field(CLS_FIELD_UNITS, CLS_FIELD_UNITS, _sky, _seed, 0);
    // the lattice table: the three octaves' hashed values, exact here (cls_shade_at reads these) and rounded into a texture
    var _L = CLS_LUMP_LATTICE, _vals = [[], [], []];
    for (var _o = 0; _o < 3; _o++) {
        var _Lo = _L * power(2, _o), _so = _f.seed + 101 * _o, _arr = array_create(_Lo * _Lo, 0);
        for (var _j = 0; _j < _Lo; _j++) for (var _i = 0; _i < _Lo; _i++) _arr[_j * _Lo + _i] = cls_lattice_value(_so, _Lo, _i, _j);
        _vals[_o] = _arr;
    }
    var _buf = buffer_create(CLS_LAT * CLS_LAT * 4, buffer_fixed, 1);
    buffer_fill(_buf, 0, buffer_u8, 0, CLS_LAT * CLS_LAT * 4);
    for (var _o2 = 0; _o2 < 3; _o2++) {
        var _Lo2 = _L * power(2, _o2), _a2 = _vals[_o2];
        for (var _j2 = 0; _j2 < _Lo2; _j2++) for (var _i2 = 0; _i2 < _Lo2; _i2++) buffer_poke(_buf, ((_j2 * CLS_LAT + _i2) * 4) + _o2, buffer_u8, clamp(round(_a2[_j2 * _Lo2 + _i2] * 255), 0, 255));
    }
    for (var _p = 0; _p < CLS_LAT * CLS_LAT; _p++) buffer_poke(_buf, _p * 4 + 3, buffer_u8, 255);
    var _spec = cls_sky_spec(_sky), _mix = [0, 0, 0], _base = [0, 0, 0];
    for (var _ms = 0; _ms < array_length(_f.masses); _ms++) _mix[clamp(_f.masses[_ms].layer, 0, 2)] = 1;
    if (_spec.base > 0) { _mix[_spec.baselayer] = 1; _base[_spec.baselayer] = _spec.base; }
    var _rec = { sky: _sky, seed: _rt.seed, field: _f, depth: _spec.depth, lat_vals: _vals, lat_buffer: _buf, lat_surface: -1, surface: -1, mix: _mix, base: _base };
    _rt.sheets[$ _key] = _rec;
    return _rec;
}

/// @function cls__sheet_free(rec)
/// @description Internal.
function cls__sheet_free(_rec) {
    if (surface_exists(_rec.surface)) surface_free(_rec.surface);
    if (surface_exists(_rec.lat_surface)) surface_free(_rec.lat_surface);
    if (buffer_exists(_rec.lat_buffer)) buffer_delete(_rec.lat_buffer);
}

/// @function cls__sheet_ready(rt, rec)
/// @description Internal. Make sure the sheet's surfaces exist (surfaces are volatile and can be lost at any time - a
/// lost sheet is simply baked again from its field). Call in a draw event. Returns the sheet's surface.
function cls__sheet_ready(_rt, _rec) {
    if (surface_exists(_rec.surface)) return _rec.surface;
    var _t0 = get_timer();
    if (!surface_exists(_rec.lat_surface)) {
        _rec.lat_surface = surface_create(CLS_LAT, CLS_LAT);
        buffer_set_surface(_rec.lat_buffer, _rec.lat_surface, 0);
    }
    _rec.surface = surface_create(CLS_SHEET, CLS_SHEET);
    var _f = _rec.field, _lump = _f.lump, _lat = surface_get_texture(_rec.lat_surface), _uv = texture_get_uvs(_lat);
    var _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_build_identity());
    gpu_push_state();
    surface_set_target(_rec.surface);
    draw_clear_alpha(c_black, 0);
    gpu_set_blendmode_ext(bm_one, bm_one);
    gpu_set_texfilter(false); gpu_set_texrepeat(false);
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false); gpu_set_alphatestenable(false); gpu_set_cullmode(cull_noculling);
    shader_set(shd_cls_mass);
    var _um = shader_get_uniform(shd_cls_mass, "u_mass"), _us = shader_get_uniform(shd_cls_mass, "u_shape"), _uc = shader_get_uniform(shd_cls_mass, "u_chan");
    shader_set_uniform_f(shader_get_uniform(shd_cls_mass, "u_lat"), _uv[0], _uv[1], (_uv[2] - _uv[0]) / CLS_LAT, (_uv[3] - _uv[1]) / CLS_LAT);
    shader_set_uniform_f(shader_get_uniform(shd_cls_mass, "u_field"), CLS_FIELD_UNITS);
    shader_set_uniform_f(shader_get_uniform(shd_cls_mass, "u_L"), CLS_LUMP_LATTICE);
    var _px = CLS_SHEET / CLS_FIELD_UNITS, _F = CLS_FIELD_UNITS;
    for (var _i = 0; _i < array_length(_f.masses); _i++) {
        var _m = _f.masses[_i], _L = clamp(_m.layer, 0, 2);
        // the mass's reach: its ellipse grown by the most the turbulence can pull an edge out (half of lump), plus a margin
        // never past half the field: the core counts only the nearest copy of a mass (the shader enforces it per pixel)
        var _ex = min(_F / 2, _m.rx * (1 + 0.5 * _lump) + 0.5), _ey = min(_F / 2, _m.ry * (1 + 0.5 * _lump) + 0.5);
        shader_set_uniform_f(_us, _m.edge, _m.k, _lump, 0);
        shader_set_uniform_f(_uc, (_L == 0) ? 1 : 0, (_L == 1) ? 1 : 0, (_L == 2) ? 1 : 0, 0);
        // the field wraps: a mass near an edge is drawn again on the far side (up to nine copies; most fall off the sheet)
        for (var _oy = -1; _oy <= 1; _oy++) for (var _ox = -1; _ox <= 1; _ox++) {
            var _cx = _m.x + _ox * _F, _cy = _m.y + _oy * _F;
            var _x0 = max(0, _cx - _ex), _x1 = min(_F, _cx + _ex), _y0 = max(0, _cy - _ey), _y1 = min(_F, _cy + _ey);
            if (_x1 <= _x0 || _y1 <= _y0) continue;
            shader_set_uniform_f(_um, _cx, _cy, _m.rx, _m.ry);
            draw_primitive_begin_texture(pr_trianglestrip, _lat);
            draw_vertex_texture(_x0 * _px, _y0 * _px, _x0, _y0);
            draw_vertex_texture(_x1 * _px, _y0 * _px, _x1, _y0);
            draw_vertex_texture(_x0 * _px, _y1 * _px, _x0, _y1);
            draw_vertex_texture(_x1 * _px, _y1 * _px, _x1, _y1);
            draw_primitive_end();
        }
    }
    shader_reset();
    surface_reset_target();
    gpu_pop_state();
    matrix_set(matrix_world, _mw);
    _rt.stats.bakes += 1; _rt.stats.bake_ms = (get_timer() - _t0) / 1000;
    return _rec.surface;
}

// ---------------------------------------------------------------------------------------------------------------
// Every step and every frame
// ---------------------------------------------------------------------------------------------------------------

/// @function cls__span(rt)
/// @description Internal. How many cells one sheet spans: big weather on a big room (the MZ edition's 18 .. 90).
function cls__span(_rt) { return clamp(max(_rt.map.cols, _rt.map.rows), 18, 90); }

/// @function cls_update()
/// @description Advance the weather one step (obj_cls_shadow's Step calls it): the fade between skies, the veering wind,
/// three altitudes drifting at their own speeds. Reads the room the first time (and after cls_surface_rebuild).
function cls_update() {
    var _rt = cls__rt();
    if (is_undefined(_rt)) return;
    if (_rt.map.dirty) cls__build_map(_rt);
    var _fps = game_get_speed(gamespeed_fps);
    var _dt = 1 / max(1, _fps);
    if (_rt.blend_rate > 0 && _rt.blend < 1) {
        _rt.blend = min(1, _rt.blend + _rt.blend_rate * _dt);
        if (_rt.blend >= 1) { _rt.prev_sky = undefined; _rt.blend_rate = 0; }
    }
    _rt.phase += _dt;
    cls__advance(_rt, _dt);
}

/// @function cls__advance(rt, dt)
/// @description Internal. Move the clouds dt seconds along the (veering) wind.
function cls__advance(_rt, _dt) {
    var _t = _rt.phase;
    // the veer: two slow incommensurate swings, so the wind wanders and never repeats a loop you could notice
    var _v = _rt.veer * (0.7 * sin(2 * pi * _t / 97) + 0.3 * sin(2 * pi * _t / 31 + 1.3));
    _rt.dir_now = _rt.wind_deg + _v;
    var _e1x = dcos(_rt.wind_deg), _e1y = -dsin(_rt.wind_deg);
    var _wx = dcos(_rt.dir_now), _wy = -dsin(_rt.dir_now);
    // the velocity in sheet space (the sheet's +x runs along the set wind)
    var _sx = _wx * _e1x + _wy * _e1y, _sy = -_wx * _e1y + _wy * _e1x;
    var _span = cls__span(_rt);
    for (var _L = 0; _L < 3; _L++) {
        var _cps = (0.35 + 0.45 * _L) * CLS_CELLS_PER_SEC * _rt.wind_speed;
        var _o = _rt.off;
        // kept in 0 .. 1 (GameMaker's frac keeps the sign, so a negative drift is folded back up)
        _o[@ _L * 2] = frac(frac(_o[_L * 2] + _sx * _cps * _dt / _span) + 1);
        _o[@ _L * 2 + 1] = frac(frac(_o[_L * 2 + 1] + _sy * _cps * _dt / _span) + 1);
    }
}

/// @function cls__origin(rt)
/// @description Internal. Where this room's clouds start on the sheet (per room, so two rooms never show the same sky
/// in the same place).
function cls__origin(_rt) { return [(cls_hash("org:" + _rt.room_name) mod 1000) / 1000, (cls_hash("orgy:" + _rt.room_name) mod 1000) / 1000]; }

/// @function cls__light(rt)
/// @description Internal. intensity x the daylight factor.
function cls__light(_rt) { return _rt.intensity * (_rt.night_floor + (1 - _rt.night_floor) * _rt.daylight); }

/// @function cls__active(rt)
/// @description Internal. False when the shadows should not draw at all (disabled, or an interior).
function cls__active(_rt) {
    if (!_rt.enabled) return false;
    if (_rt.interior_mode == "on") return false;
    if (_rt.interior_mode == "auto" && _rt.map.open < 0.02) return false;
    return true;
}

/// @function cls_draw()
/// @description Draw the shadows over the current view (obj_cls_shadow's Draw event calls it). Everything drawn BELOW
/// this depth is darkened; nothing is replaced, and the blend leaves the target's alpha alone. One quad.
function cls_draw() {
    var _rt = cls__rt();
    if (is_undefined(_rt)) return;
    if (_rt.map.dirty) cls__build_map(_rt);
    if (!cls__active(_rt)) return;
    var _m = _rt.map;
    if (!surface_exists(_m.surface)) {
        _m.surface = surface_create(_m.cols + 2, _m.rows + 2);
        buffer_set_surface(_m.buffer, _m.surface, 0);
    }
    var _ra = cls__sheet(_rt, _rt.sky);
    var _rb = is_undefined(_rt.prev_sky) ? _ra : cls__sheet(_rt, _rt.prev_sky);
    var _sa = cls__sheet_ready(_rt, _ra), _sb = cls__sheet_ready(_rt, _rb);
    // the view (or the whole room), a little wider so nothing at the edge is left unlit
    var _x0 = 0, _y0 = 0, _x1 = room_width, _y1 = room_height;
    if (view_enabled && view_visible[view_current]) {
        var _cam = view_camera[view_current];
        _x0 = camera_get_view_x(_cam); _y0 = camera_get_view_y(_cam);
        _x1 = _x0 + camera_get_view_width(_cam); _y1 = _y0 + camera_get_view_height(_cam);
    }
    _x0 -= 2; _y0 -= 2; _x1 += 2; _y1 += 2;
    var _o = cls__origin(_rt), _span = cls__span(_rt);
    var _sh = shd_cls_shadow;
    var _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_build_identity());
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_dest_colour, bm_zero, bm_zero, bm_one);
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false); gpu_set_alphatestenable(false); gpu_set_cullmode(cull_noculling);
    gpu_set_texfilter(true); gpu_set_texrepeat(true);
    shader_set(_sh);
    var _sm = shader_get_sampler_index(_sh, "u_surface"), _sbi = shader_get_sampler_index(_sh, "u_sheetb");
    var _mtex = surface_get_texture(_m.surface);
    texture_set_stage(_sm, _mtex); gpu_set_tex_filter_ext(_sm, true); gpu_set_tex_repeat_ext(_sm, false);
    texture_set_stage(_sbi, surface_get_texture(_sb)); gpu_set_tex_filter_ext(_sbi, true); gpu_set_tex_repeat_ext(_sbi, true);
    var _muv = texture_get_uvs(_mtex);
    shader_set_uniform_f(shader_get_uniform(_sh, "u_map"), _m.cw, _m.ch, _m.cols, _m.rows);
    shader_set_uniform_f(shader_get_uniform(_sh, "u_mapuv"), _muv[0], _muv[1], _muv[2], _muv[3]);
    shader_set_uniform_f(shader_get_uniform(_sh, "u_cloud"), 1 / _span, _o[0], _o[1], CLS_ALT_SHIFT);
    shader_set_uniform_f(shader_get_uniform(_sh, "u_rot"), dcos(_rt.wind_deg), -dsin(_rt.wind_deg), dcos(_rt.dir_now), -dsin(_rt.dir_now));
    shader_set_uniform_f(shader_get_uniform(_sh, "u_off0"), _rt.off[0], _rt.off[1]);
    shader_set_uniform_f(shader_get_uniform(_sh, "u_off1"), _rt.off[2], _rt.off[3]);
    shader_set_uniform_f(shader_get_uniform(_sh, "u_off2"), _rt.off[4], _rt.off[5]);
    shader_set_uniform_f(shader_get_uniform(_sh, "u_mixa"), _ra.mix[0], _ra.mix[1], _ra.mix[2]);
    shader_set_uniform_f(shader_get_uniform(_sh, "u_basea"), _ra.base[0], _ra.base[1], _ra.base[2]);
    shader_set_uniform_f(shader_get_uniform(_sh, "u_mixb"), _rb.mix[0], _rb.mix[1], _rb.mix[2]);
    shader_set_uniform_f(shader_get_uniform(_sh, "u_baseb"), _rb.base[0], _rb.base[1], _rb.base[2]);
    var _k = is_undefined(_rt.prev_sky) ? 1 : _rt.blend;
    shader_set_uniform_f(shader_get_uniform(_sh, "u_depth"), _ra.depth, _rb.depth, _k, cls__light(_rt));
    var _cool = cls__cool();
    shader_set_uniform_f(shader_get_uniform(_sh, "u_cool"), _cool[0], _cool[1], _cool[2], _rt.coolness);
    shader_set_uniform_f(shader_get_uniform(_sh, "u_maxshade"), CLS_MAX_SHADE);
    draw_primitive_begin_texture(pr_trianglestrip, surface_get_texture(_sa));
    draw_vertex_texture(_x0, _y0, _x0, _y0);
    draw_vertex_texture(_x1, _y0, _x1, _y0);
    draw_vertex_texture(_x0, _y1, _x0, _y1);
    draw_vertex_texture(_x1, _y1, _x1, _y1);
    draw_primitive_end();
    shader_reset();
    gpu_pop_state();
    matrix_set(matrix_world, _mw);
    _rt.stats.draws += 1;
}

/// @function cls__cool()
/// @description Internal. The colour of skylight relative to sunlight, normalised to mean 1 (so it turns hue, not level).
function cls__cool() {
    static _c = undefined;
    if (is_undefined(_c)) { var _r = 0.62, _g = 0.72, _b = 1.0, _mn = (_r + _g + _b) / 3; _c = [_r / _mn, _g / _mn, _b / _mn]; }
    return _c;
}

// ---------------------------------------------------------------------------------------------------------------
// The CPU twin: what the player sees at a point, for game logic
// ---------------------------------------------------------------------------------------------------------------

/// @function cls__sheet_value(rec, L, x, y)
/// @description Internal. One channel of a sheet at field point (x, y): the exact field value (with the cached lattice
/// table), i.e. what the bake approximates. Equal to cls_shade_at_field(rec.field, x, y, 0, L) / depth.
function cls__sheet_value(_rec, _L, _x, _y) {
    var _f = _rec.field, _lump = 0, _F = CLS_FIELD_UNITS, _LL = CLS_LUMP_LATTICE;
    if (_f.lump != 0) {
        var _u = _x / _f.w * _LL, _v = _y / _f.h * _LL;
        var _a = cls__tab_noise(_rec.lat_vals[0], _LL, _u, _v);
        var _b = cls__tab_noise(_rec.lat_vals[1], _LL * 2, _u * 2, _v * 2);
        var _c = cls__tab_noise(_rec.lat_vals[2], _LL * 4, _u * 4, _v * 4);
        _lump = ((_a * 0.5 + _b * 0.33 + _c * 0.17) - 0.5) * _f.lump;
    }
    var _acc = 0, _ms = _f.masses, _n = array_length(_ms);
    for (var _i = 0; _i < _n; _i++) {
        var _m = _ms[_i];
        if (_m.layer != _L) continue;
        var _dx = _x - cls__wrap(_m.x, _f.w), _dy = _y - cls__wrap(_m.y, _f.h);
        if (_dx > _f.w / 2) _dx -= _f.w; else if (_dx < -_f.w / 2) _dx += _f.w;
        if (_dy > _f.h / 2) _dy -= _f.h; else if (_dy < -_f.h / 2) _dy += _f.h;
        var _d = sqrt((_dx * _dx) / (_m.rx * _m.rx) + (_dy * _dy) / (_m.ry * _m.ry)) + _lump;
        if (_d >= 1) continue;
        var _inner = 1 - _m.edge;
        var _vv = (_d <= _inner) ? 1 : 1 - (_d - _inner) / ((_m.edge != 0) ? _m.edge : 0.000001);
        _acc += _m.k * (_vv * _vv * (3 - 2 * _vv));
        if (_acc >= 1) return 1;
    }
    var _base = (_L == _f.baselayer) ? _f.base : 0;
    var _aa = (_acc > 1) ? 1 : _acc;
    return _base + _aa * (1 - _base);
}

/// @function cls__tab_noise(table, L, u, v)
/// @description Internal. cls_vnoise read from a cached lattice table (same values, same arithmetic).
function cls__tab_noise(_t, _L, _u, _v) {
    var _x0 = floor(_u), _y0 = floor(_v);
    var _fx = _u - _x0, _fy = _v - _y0;
    var _sx = _fx * _fx * (3 - 2 * _fx), _sy = _fy * _fy * (3 - 2 * _fy);
    var _i0 = ((_x0 mod _L) + _L) mod _L, _j0 = ((_y0 mod _L) + _L) mod _L;
    var _i1 = (((_x0 + 1) mod _L) + _L) mod _L, _j1 = (((_y0 + 1) mod _L) + _L) mod _L;
    var _n00 = _t[_j0 * _L + _i0], _n10 = _t[_j0 * _L + _i1], _n01 = _t[_j1 * _L + _i0], _n11 = _t[_j1 * _L + _i1];
    return (_n00 * (1 - _sx) + _n10 * _sx) * (1 - _sy) + (_n01 * (1 - _sx) + _n11 * _sx) * _sy;
}

/// @function cls__map_sample(m, cx, cy)
/// @description Internal. The surface map at a cell position, filtered exactly as the GPU filters it (bilinear between
/// cell centres over the ring-extended map): [response, altitude, coolness, open].
function cls__map_sample(_m, _cx, _cy) {
    var _tab = cls__kind_table();
    var _u = clamp(_cx, 0, _m.cols - 0.001) + 1 - 0.5, _v = clamp(_cy, 0, _m.rows - 0.001) + 1 - 0.5;
    var _i0 = floor(_u), _j0 = floor(_v), _fx = _u - _i0, _fy = _v - _j0;
    var _out = [0, 0, 0, 0];
    for (var _q = 0; _q < 4; _q++) {
        var _ii = _i0 + (_q mod 2), _jj = _j0 + (_q div 2);
        var _mx = clamp(_ii - 1, 0, _m.cols - 1), _my = clamp(_jj - 1, 0, _m.rows - 1);
        var _row = _tab[_m.kinds[_my * _m.cols + _mx]];
        var _w = ((_q mod 2) ? _fx : 1 - _fx) * ((_q div 2) ? _fy : 1 - _fy);
        // the texture holds bytes: read the same rounded values the GPU reads
        _out[0] += _w * round(clamp(_row[0], 0, 1) * 255) / 255;
        _out[1] += _w * round(clamp(_row[1] / 3, 0, 1) * 255) / 255 * 3;
        _out[2] += _w * round(clamp(_row[2], 0, 1) * 255) / 255;
        _out[3] += _w * ((_row[3] > 0) ? 1 : 0);
    }
    return _out;
}

/// @function cls__cloud(rt, rec, cuvx, cuvy)
/// @description Internal. The cloud cover a sheet gives at a sheet point (before depth), all three altitudes.
function cls__cloud(_rt, _rec, _ux, _uy) {
    var _sum = 0, _F = CLS_FIELD_UNITS;
    for (var _L = 0; _L < 3; _L++) {
        if (_rec.mix[_L] == 0) continue;
        var _fx = frac(frac(_ux - _rt.off[_L * 2]) + 1) * _F, _fy = frac(frac(_uy - _rt.off[_L * 2 + 1]) + 1) * _F;
        _sum += cls__sheet_value(_rec, _L, _fx, _fy);
    }
    return min(1, _sum);
}

/// @function cls_shade_at(x, y)
/// @description How much light the clouds are taking from a room point RIGHT NOW: 0 (full sun) .. CLS_MAX_SHADE (0.58).
/// The same arithmetic the shadow shader runs, from the exact cloud field, so game logic agrees with what the player
/// sees: plants that want sun, a vampire who burns in it, a stealth bonus in shade. It reads the EXACT cloud field; the
/// picture is drawn from a 256 px sheet of that field, so the two agree to within a percent almost everywhere and can
/// differ by about a tenth of the light for a pixel or two along a ragged cloud edge (measured by the self-test). About
/// 0.3 ms a call on the VM: ask for a handful of points a step, not every pixel.
/// @param {Real} x   room pixels
/// @param {Real} y
/// @returns {Real}
function cls_shade_at(_x, _y) {
    var _rt = cls__rt();
    if (is_undefined(_rt) || !is_numeric(_x) || !is_numeric(_y)) return 0;
    if (_rt.map.dirty) cls__build_map(_rt);
    if (!cls__active(_rt)) return 0;
    var _m = _rt.map;
    var _cx = real(_x) / _m.cw, _cy = real(_y) / _m.ch;
    var _s = cls__map_sample(_m, _cx, _cy);
    if (_s[3] <= 0) return 0;
    var _wx = dcos(_rt.dir_now), _wy = -dsin(_rt.dir_now);
    var _lx = _cx - _wx * (_s[1] * CLS_ALT_SHIFT), _ly = _cy - _wy * (_s[1] * CLS_ALT_SHIFT);
    var _e1x = dcos(_rt.wind_deg), _e1y = -dsin(_rt.wind_deg);
    var _rx = _lx * _e1x + _ly * _e1y, _ry = -_lx * _e1y + _ly * _e1x;
    var _o = cls__origin(_rt), _span = cls__span(_rt);
    var _ux = _rx / _span + _o[0], _uy = _ry / _span + _o[1];
    var _ra = cls__sheet(_rt, _rt.sky);
    var _shade = cls__cloud(_rt, _ra, _ux, _uy) * _ra.depth;
    if (!is_undefined(_rt.prev_sky) && _rt.blend < 1) {
        var _rb = cls__sheet(_rt, _rt.prev_sky);
        _shade = lerp(cls__cloud(_rt, _rb, _ux, _uy) * _rb.depth, _shade, _rt.blend);
    }
    return min(_shade * _s[0] * _s[3] * cls__light(_rt), CLS_MAX_SHADE);
}

/// @function cls_in_shadow(x, y, [threshold])
/// @description True when a room point has lost at least `threshold` of its light to the clouds (default 0.1).
/// @returns {Bool}
function cls_in_shadow(_x, _y, _th = 0.1) { return cls_shade_at(_x, _y) >= cls__num(_th, 0.1); }

// ---------------------------------------------------------------------------------------------------------------
// Saving
// ---------------------------------------------------------------------------------------------------------------

/// @function cls_save()
/// @description The weather as a small JSON string for your save file (the sky, a fade under way, the wind, the clouds'
/// place, the settings), or "" when not running.
/// @returns {String}
function cls_save() {
    var _rt = cls__rt();
    if (is_undefined(_rt)) return "";
    return json_stringify({ v: 1, sky: _rt.sky, prev_sky: is_undefined(_rt.prev_sky) ? "" : _rt.prev_sky, blend: _rt.blend, blend_rate: _rt.blend_rate,
        held: _rt.held, wind_deg: _rt.wind_deg, wind_set: _rt.wind_set, wind_speed: _rt.wind_speed, veer: _rt.veer, phase: _rt.phase, off: _rt.off,
        intensity: _rt.intensity, coolness: _rt.coolness, daylight: _rt.daylight, enabled: _rt.enabled, seed: _rt.seed });
}

/// @function cls_load(json)
/// @description Restore weather saved by cls_save. Forward compatible: a missing field keeps its current value, an
/// unknown one is ignored, a bad string changes nothing.
/// @param {String} json
/// @returns {Bool} true when something was restored
function cls_load(_json) {
    var _rt = cls__rt();
    if (is_undefined(_rt) || !is_string(_json) || _json == "") return false;
    var _d;
    try { _d = json_parse(_json); } catch (_e) { return false; }
    if (!is_struct(_d)) return false;
    var _g = function(_d, _k, _def) { return variable_struct_exists(_d, _k) ? _d[$ _k] : _def; };
    var _sky = _g(_d, "sky", _rt.sky);
    if (cls_sky_exists(_sky)) _rt.sky = _sky;
    var _pv = _g(_d, "prev_sky", "");
    _rt.prev_sky = cls_sky_exists(_pv) ? _pv : undefined;
    _rt.blend = clamp(cls__num(_g(_d, "blend", 1), 1), 0, 1);
    _rt.blend_rate = max(0, cls__num(_g(_d, "blend_rate", 0), 0));
    if (is_undefined(_rt.prev_sky)) { _rt.blend = 1; _rt.blend_rate = 0; }
    _rt.held = (_g(_d, "held", _rt.held) == true);
    if (_rt.held) _rt.sky_why = "held (loaded)";
    _rt.wind_deg = cls__num(_g(_d, "wind_deg", _rt.wind_deg), _rt.wind_deg);
    _rt.wind_set = (_g(_d, "wind_set", _rt.wind_set) == true);
    _rt.wind_speed = max(0, cls__num(_g(_d, "wind_speed", _rt.wind_speed), _rt.wind_speed));
    _rt.veer = max(0, cls__num(_g(_d, "veer", _rt.veer), _rt.veer));
    _rt.phase = max(0, cls__num(_g(_d, "phase", _rt.phase), _rt.phase));
    var _off = _g(_d, "off", undefined);
    if (is_array(_off) && array_length(_off) == 6) { for (var _i = 0; _i < 6; _i++) _rt.off[@ _i] = frac(frac(cls__num(_off[_i], 0)) + 1); }
    _rt.intensity = max(0, cls__num(_g(_d, "intensity", _rt.intensity), _rt.intensity));
    _rt.coolness = max(0, cls__num(_g(_d, "coolness", _rt.coolness), _rt.coolness));
    _rt.daylight = clamp(cls__num(_g(_d, "daylight", _rt.daylight), _rt.daylight), 0, 1);
    _rt.enabled = (_g(_d, "enabled", _rt.enabled) == true);
    _rt.seed = cls__num(_g(_d, "seed", _rt.seed), _rt.seed);
    cls__advance(_rt, 0);
    return true;
}

/// @function cls_draw_surface_map([alpha])
/// @description Debug view: draw what Cloudshadow READ from the room, one translucent rectangle per classified cell (water
/// blue, roof red, cliff top amber, wall face grey, object green, cover dark; open ground is left clear). Room
/// coordinates - call it from a Draw event (or Draw GUI when your GUI matches the room).
/// @param {Real} [alpha]   default 0.45
function cls_draw_surface_map(_alpha = 0.45) {
    var _rt = cls__rt();
    if (is_undefined(_rt)) return;
    if (_rt.map.dirty) cls__build_map(_rt);
    var _m = _rt.map, _a = clamp(cls__num(_alpha, 0.45), 0, 1);
    static _cols = [-1, make_colour_rgb(70, 140, 235), make_colour_rgb(225, 85, 70), make_colour_rgb(235, 180, 70), make_colour_rgb(170, 170, 185), make_colour_rgb(120, 200, 120), make_colour_rgb(40, 40, 60)];
    var _oa = draw_get_alpha(), _oc = draw_get_colour();
    draw_set_alpha(_a);
    for (var _r = 0; _r < _m.rows; _r++) for (var _c = 0; _c < _m.cols; _c++) {
        var _k = _m.kinds[_r * _m.cols + _c];
        if (_k == 0) continue;
        draw_set_colour(_cols[_k]);
        draw_rectangle(_c * _m.cw, _r * _m.ch, (_c + 1) * _m.cw - 1, (_r + 1) * _m.ch - 1, false);
    }
    draw_set_alpha(_oa); draw_set_colour(_oc);
}

/// @function cls_info()
/// @description What Cloudshadow is doing, for a debug overlay: { sky, why, prev_sky, blend, wind, wind_now, speed, phase,
/// cols, rows, cell, open (share of cells open to the sky), kinds {name: cells}, layers_read, interior, map_ms, bake_ms,
/// bakes }, or undefined when not running.
/// @returns {Struct|Undefined}
function cls_info() {
    var _rt = cls__rt();
    if (is_undefined(_rt)) return undefined;
    if (_rt.map.dirty) cls__build_map(_rt);
    var _m = _rt.map, _kn = cls_kind_names(), _kinds = {};
    for (var _i = 0; _i < 7; _i++) _kinds[$ _kn[_i]] = _m.counts[_i];
    return { sky: _rt.sky, why: _rt.sky_why, prev_sky: is_undefined(_rt.prev_sky) ? "" : _rt.prev_sky, blend: _rt.blend, wind: _rt.wind_deg, wind_now: _rt.dir_now,
        speed: _rt.wind_speed, phase: _rt.phase, cols: _m.cols, rows: _m.rows, cell: _m.cw, open: _m.open, kinds: _kinds, layers_read: _m.layers_read,
        interior: !cls__active(_rt), map_ms: _rt.stats.map_ms, bake_ms: _rt.stats.bake_ms, bakes: _rt.stats.bakes };
}
