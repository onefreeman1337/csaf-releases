/// cls_selftest.gml - Cloudshadow's in-engine test suite. Run the demo with -selftest; the result is written as
/// cls_selftest.json in the game's save folder.
///   1-6  the pure half held to the RPG Maker MZ edition run in Node (cls_oracle_core): hashes, draws, noise, fields
///        mass for mass, shadeAt (exact at t = 0), measure
///   7    the eight new skies: each exists, each casts shade, each is built the way its name says
///   8    every sky's baked SHEET read back from the GPU and held to the exact CPU field
///   9    the surface map read from the demo's marker tile layers, rules, objects, rectangles
///   10   the shadow OVERLAY read back from the GPU and held to cls_shade_at (the CPU twin)
///   11+  motion direction, fades, save / load, guards, the ceiling, interiors, timings
///
/// Cloudshadow - Drifting Cloud Shadows for GameMaker. Copyright (c) 2026 Core Systems Asset Factory.

/// @function cls_st_assert(state, condition, message)
/// @description Count one assertion; keep the first 60 failure messages.
function cls_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 60) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
/// @function cls_st_stage(state, n)
/// @description Record the stage reached (the crash handler reports it).
function cls_st_stage(_st, _n) { _st.stage = _n; global.cls_stage = _n; }

/// @function cls__st_fresh([options])
/// @description Internal. A fresh Cloudshadow over the demo's marker layers, with nothing carried from a previous start.
function cls__st_fresh(_o = undefined) {
    if (cls_is_running()) cls_stop();
    global.__cls_carry = undefined;
    cls_start(_o);
    cls_update();
}

/// @function cls__st_expect(x, y)
/// @description Internal. The overlay colour the shader should write at a room point over WHITE: [r, g, b] in 0..255,
/// from the CPU twin (cls_shade_at) and the same surface sample.
function cls__st_expect(_x, _y) {
    var _rt = cls__rt(), _m = _rt.map;
    var _s = cls_shade_at(_x, _y);
    var _smp = cls__map_sample(_m, _x / _m.cw, _y / _m.ch);
    var _cool = cls__cool(), _t = clamp(_s * _smp[2] * _rt.coolness, 0, 1);
    return [255 * (1 - _s) * lerp(1, _cool[0], _t), 255 * (1 - _s) * lerp(1, _cool[1], _t), 255 * (1 - _s) * lerp(1, _cool[2], _t)];
}

/// @function cls__st_cloud_filtered(rt, rec, ux, uy)
/// @description Internal. cls__cloud as the GPU SAMPLES it: each channel bilinear between the four sheet texel centres
/// round the point (texel (i, j) holds the exact field at ((i + 0.5) / 4, (j + 0.5) / 4)), wrapping like REPEAT.
function cls__st_cloud_filtered(_rt, _rec, _ux, _uy) {
    var _sum = 0, _S = CLS_SHEET;
    for (var _L = 0; _L < 3; _L++) {
        if (_rec.mix[_L] == 0) continue;
        var _u = frac(frac(_ux - _rt.off[_L * 2]) + 1) * _S - 0.5, _v = frac(frac(_uy - _rt.off[_L * 2 + 1]) + 1) * _S - 0.5;
        var _i0 = floor(_u), _j0 = floor(_v), _fx = _u - _i0, _fy = _v - _j0, _acc = 0;
        for (var _q = 0; _q < 4; _q++) {
            var _ii = (((_i0 + (_q mod 2)) mod _S) + _S) mod _S, _jj = (((_j0 + (_q div 2)) mod _S) + _S) mod _S;
            var _w = ((_q mod 2) ? _fx : 1 - _fx) * ((_q div 2) ? _fy : 1 - _fy);
            if (_w > 0) _acc += _w * cls__sheet_value(_rec, _L, (_ii + 0.5) / 4, (_jj + 0.5) / 4);
        }
        _sum += _acc;
    }
    return min(1, _sum);
}

/// @function cls__st_expect_filtered(x, y)
/// @description Internal. cls__st_expect with the GPU's sampling of the sheet (cls__st_cloud_filtered) in place of the
/// exact field: [r, g, b]. This is what the shader MUST write; cls__st_expect is what the exact twin says.
function cls__st_expect_filtered(_x, _y) {
    var _rt = cls__rt(), _m = _rt.map;
    var _smp = cls__map_sample(_m, _x / _m.cw, _y / _m.ch);
    var _s = 0;
    if (_smp[3] > 0 && cls__active(_rt)) {
        var _cx = _x / _m.cw, _cy = _y / _m.ch, _wx = dcos(_rt.dir_now), _wy = -dsin(_rt.dir_now);
        var _lx = _cx - _wx * (_smp[1] * CLS_ALT_SHIFT), _ly = _cy - _wy * (_smp[1] * CLS_ALT_SHIFT);
        var _e1x = dcos(_rt.wind_deg), _e1y = -dsin(_rt.wind_deg);
        var _o = cls__origin(_rt), _span = cls__span(_rt);
        var _ux = (_lx * _e1x + _ly * _e1y) / _span + _o[0], _uy = (-_lx * _e1y + _ly * _e1x) / _span + _o[1];
        var _ra = cls__sheet(_rt, _rt.sky);
        _s = cls__st_cloud_filtered(_rt, _ra, _ux, _uy) * _ra.depth;
        if (!is_undefined(_rt.prev_sky) && _rt.blend < 1) { var _rb = cls__sheet(_rt, _rt.prev_sky); _s = lerp(cls__st_cloud_filtered(_rt, _rb, _ux, _uy) * _rb.depth, _s, _rt.blend); }
        _s = min(_s * _smp[0] * _smp[3] * cls__light(_rt), CLS_MAX_SHADE);
    }
    var _cool = cls__cool(), _t = clamp(_s * _smp[2] * _rt.coolness, 0, 1);
    return [255 * (1 - _s) * lerp(1, _cool[0], _t), 255 * (1 - _s) * lerp(1, _cool[1], _t), 255 * (1 - _s) * lerp(1, _cool[2], _t)];
}

/// @function cls__st_overlay(buffer_out)
/// @description Internal. Draw the overlay over a white room-sized surface and read it back into a buffer. Returns the
/// buffer (caller deletes).
function cls__st_overlay() {
    var _s = surface_create(room_width, room_height);
    surface_set_target(_s);
    draw_clear_alpha(c_white, 1);
    cls_draw();
    surface_reset_target();
    var _b = buffer_create(room_width * room_height * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _s, 0);
    surface_free(_s);
    return _b;
}

/// @function cls_selftest_run()
/// @description Run the whole suite and return its state { pass, fail, total, stage, failures, measured: {...} }.
function cls_selftest_run() {
    var _st = { pass: 0, fail: 0, total: 0, stage: 0, failures: [], runtime: GM_runtime_version, epsilon: 0, measured: {} };
    var _eps0 = math_get_epsilon(); _st.epsilon = _eps0;
    var _O = cls_oracle_core(), _i, _j;

    // 1. hashes
    cls_st_stage(_st, 1);
    for (_i = 0; _i < array_length(_O.hashes); _i++) { var _hw = _O.hashes[_i]; var _hg = cls_hash(_hw[0]); cls_st_assert(_st, _hg == _hw[1], "hash '" + _hw[0] + "' want " + string(_hw[1]) + " got " + string(_hg)); }

    // 2. xorshift draws, exact
    cls_st_stage(_st, 2);
    for (_i = 0; _i < array_length(_O.rngs); _i++) {
        var _rw = _O.rngs[_i], _r = cls_rng(_rw[0]), _bad = "";
        for (_j = 0; _j < 10; _j++) { var _dv = cls_rng_next(_r); if (_dv != _rw[1][_j] && _bad == "") _bad = "draw " + string(_j) + " want " + string_format(_rw[1][_j], 1, 17) + " got " + string_format(_dv, 1, 17); }
        cls_st_assert(_st, _bad == "", "rng seed " + string(_rw[0]) + ": " + _bad);
    }

    // 3. lattice noise and turbulence, exact
    cls_st_stage(_st, 3);
    var _nbad = 0, _nfirst = "";
    for (_i = 0; _i < array_length(_O.noise); _i++) {
        var _nw = _O.noise[_i];
        var _vn = cls_vnoise(_nw[0], _nw[1], _nw[2], _nw[3]), _tb = cls_turbulence(_nw[0], _nw[1], _nw[2], _nw[3]);
        if (_vn != _nw[4] || _tb != _nw[5]) { _nbad++; if (_nfirst == "") _nfirst = "point " + string(_i) + " vnoise " + string_format(_vn, 1, 17) + " want " + string_format(_nw[4], 1, 17) + " turb " + string_format(_tb, 1, 17) + " want " + string_format(_nw[5], 1, 17); }
    }
    cls_st_assert(_st, _nbad == 0, string(_nbad) + " of " + string(array_length(_O.noise)) + " noise points differ: " + _nfirst);

    // 4. fields, mass for mass (exact)
    cls_st_stage(_st, 4);
    var _masses = 0;
    for (_i = 0; _i < array_length(_O.fields); _i++) {
        var _fw = _O.fields[_i];
        var _f = (_fw.wind == -999) ? cls_field(_fw.w, _fw.h, _fw.sky, _fw.seed) : cls_field(_fw.w, _fw.h, _fw.sky, _fw.seed, _fw.wind);
        var _got = [_f.w, _f.h, _f.wind, _f.depth, _f.base, _f.layers, _f.lump, _f.seed], _fb = "";
        var _fn = ["w", "h", "wind", "depth", "base", "layers", "lump", "seed"];
        for (_j = 0; _j < 8; _j++) if (_got[_j] != _fw.out[_j]) { _fb = _fn[_j] + " want " + string_format(_fw.out[_j], 1, 17) + " got " + string_format(_got[_j], 1, 17); break; }
        if (_fb == "" && array_length(_f.masses) != array_length(_fw.ms)) _fb = "mass count want " + string(array_length(_fw.ms)) + " got " + string(array_length(_f.masses));
        if (_fb == "") for (_j = 0; _j < array_length(_fw.ms); _j++) {
            var _mw = _fw.ms[_j], _mg = _f.masses[_j];
            var _gv = [_mg.x, _mg.y, _mg.rx, _mg.ry, _mg.edge, _mg.layer, _mg.drift];
            for (var _q = 0; _q < 7; _q++) if (_gv[_q] != _mw[_q]) { _fb = "mass " + string(_j) + " field " + string(_q) + " want " + string_format(_mw[_q], 1, 17) + " got " + string_format(_gv[_q], 1, 17); break; }
            if (_fb != "") break;
            _masses++;
        }
        cls_st_assert(_st, _fb == "", "field " + _fw.sky + " " + string(_fw.w) + "x" + string(_fw.h) + " seed " + string(_fw.seed) + ": " + _fb);
    }
    _st.measured.oracle_masses = _masses;

    // 5. shadeAt: exact at t = 0; to 1e-9 at t > 0 (cos / sin may differ in the last place between V8 and the CRT)
    cls_st_stage(_st, 5);
    var _sx0 = 0, _sxt = 0, _worst = 0, _sfirst = "", _spts = 0;
    for (_i = 0; _i < array_length(_O.shades); _i++) {
        var _sw = _O.shades[_i];
        var _sf = (_sw.wind == -999) ? cls_field(_sw.w, _sw.h, _sw.sky, _sw.seed) : cls_field(_sw.w, _sw.h, _sw.sky, _sw.seed, _sw.wind);
        for (_j = 0; _j < array_length(_sw.pts); _j++) {
            var _p = _sw.pts[_j];
            var _v0 = cls_shade_at_field(_sf, _p[0], _p[1], 0), _v1 = cls_shade_at_field(_sf, _p[0], _p[1], 7.25), _v2 = cls_shade_at_field(_sf, _p[0], _p[1], 41);
            _spts++;
            if (_v0 != _p[2]) { _sx0++; if (_sfirst == "") _sfirst = _sw.sky + " pt " + string(_j) + " t0 want " + string_format(_p[2], 1, 17) + " got " + string_format(_v0, 1, 17); }
            var _e = max(abs(_v1 - _p[3]), abs(_v2 - _p[4]));
            _worst = max(_worst, _e);
            if (_e > 0.000000001) { _sxt++; if (_sfirst == "") _sfirst = _sw.sky + " pt " + string(_j) + " t>0 off by " + string_format(_e, 1, 15); }
        }
    }
    cls_st_assert(_st, _sx0 == 0, string(_sx0) + " of " + string(_spts) + " t=0 shades differ: " + _sfirst);
    cls_st_assert(_st, _sxt == 0, string(_sxt) + " of " + string(_spts) + " t>0 shades off by > 1e-9: " + _sfirst);
    _st.measured.shade_points = _spts; _st.measured.shade_worst_t = _worst;

    // 6. measure(), exact
    cls_st_stage(_st, 6);
    for (_i = 0; _i < array_length(_O.measures); _i++) {
        var _ow = _O.measures[_i];
        var _mf = cls_field(64, 64, _ow[0], cls_hash("sheet:" + _ow[0]), 0);
        var _me = cls_measure(_mf, 0, 2);
        var _mg2 = [_me.mean, _me.touched, _me.covered, _me.deep, _me.spread, _me.max, _me.samples], _mb = "";
        for (_j = 0; _j < 7; _j++) if (_mg2[_j] != _ow[_j + 1]) { _mb = "field " + string(_j) + " want " + string_format(_ow[_j + 1], 1, 17) + " got " + string_format(_mg2[_j], 1, 17); break; }
        cls_st_assert(_st, _mb == "", "measure " + _ow[0] + ": " + _mb);
    }

    // 7. all thirteen skies
    cls_st_stage(_st, 7);
    var _names = cls_sky_names(), _feat = [], _deep = {}, _spread = {}, _touched = {};
    cls_st_assert(_st, array_length(_names) == 13, "13 skies, got " + string(array_length(_names)));
    for (_i = 0; _i < array_length(_names); _i++) {
        var _nm = _names[_i];
        cls_st_assert(_st, cls_sky_exists(_nm) && is_struct(cls_sky_spec(_nm)), "sky " + _nm + " exists");
        var _kf = cls_field(64, 64, _nm, cls_hash("sheet:" + _nm), 0);
        var _km = cls_measure(_kf, 0, 2);
        cls_st_assert(_st, _km.mean > 0 && _km.max <= _kf.depth + 0.000000001, "sky " + _nm + " casts shade within its depth (mean " + string(_km.mean) + ", max " + string(_km.max) + ")");
        array_push(_feat, [_km.touched, _km.covered, _km.deep, _km.spread, (_kf.depth > 0) ? _km.mean / _kf.depth : 0]);
        _deep[$ _nm] = _km.deep; _spread[$ _nm] = _km.spread; _touched[$ _nm] = _km.touched;
    }
    var _minpair = 99, _minname = "";
    for (_i = 0; _i < array_length(_feat); _i++) for (_j = _i + 1; _j < array_length(_feat); _j++) {
        var _dd = 0; for (var _z = 0; _z < 5; _z++) _dd += abs(_feat[_i][_z] - _feat[_j][_z]);
        if (_dd < _minpair) { _minpair = _dd; _minname = _names[_i] + "/" + _names[_j]; }
    }
    _st.measured.sky_min_pair = _minpair; _st.measured.sky_min_pair_names = _minname;
    cls_st_assert(_st, _minpair >= 0.04, "every pair of skies measurably different; closest " + _minname + " at " + string(_minpair));
    _st.measured.deep = _deep; _st.measured.spread = _spread; _st.measured.touched = _touched;
    cls_st_assert(_st, _deep[$ "storm"] > _deep[$ "clear"] && _deep[$ "towering"] > _deep[$ "clear"], "storm and towering are deeper than clear (deep " + string(_deep[$ "storm"]) + ", " + string(_deep[$ "towering"]) + " vs " + string(_deep[$ "clear"]) + ")");
    cls_st_assert(_st, _spread[$ "overcast"] < _spread[$ "storm"], "overcast is more even than storm (spread " + string(_spread[$ "overcast"]) + " vs " + string(_spread[$ "storm"]) + ")");
    cls_st_assert(_st, _touched[$ "veil"] >= 0.95, "veil is a sheet over the whole sky (touched " + string(_touched[$ "veil"]) + ")");
    var _mk = cls_field(64, 64, "mackerel", 1, 0), _mkok = (array_length(_mk.masses) == 60);
    for (_i = 0; _i < array_length(_mk.masses); _i++) if (_mk.masses[_i].layer != 2 || !(_mk.masses[_i].ry > _mk.masses[_i].rx)) _mkok = false;
    cls_st_assert(_st, _mkok, "mackerel: 60 high puffs in 10 rows, each drawn out along its row");
    var _ci = cls_field(64, 64, "cirrus", 2, 0), _ciok = true;
    for (_i = 0; _i < array_length(_ci.masses); _i++) if (_ci.masses[_i].layer != 2 || _ci.masses[_i].rx / _ci.masses[_i].ry < 15) _ciok = false;
    cls_st_assert(_st, _ciok, "cirrus: every streak high and at least 15x longer than wide");
    var _tw = cls_field(64, 64, "towering", 3, 0), _anv = 0;
    for (_i = 0; _i < array_length(_tw.masses); _i++) if (_tw.masses[_i].layer == 2 && _tw.masses[_i].k < 1) _anv++;
    cls_st_assert(_st, _anv == 4 && array_length(_tw.masses) == 8, "towering: four towers, each with a soft high anvil (anvils " + string(_anv) + ")");
    var _sq = cls_field(64, 64, "squall", 4, 0), _inb = 0;
    for (_i = 0; _i < array_length(_sq.masses); _i++) if (_sq.masses[_i].k == 1 && _sq.masses[_i].layer == 0) _inb++;
    cls_st_assert(_st, _inb == 20, "squall: two thirds of its 30 masses are the front (got " + string(_inb) + ")");

    // 8. every sky's baked sheet, read back from the GPU and held to the exact CPU field
    cls_st_stage(_st, 8);
    cls__st_fresh({ cell: 24 });
    var _rt = cls__rt(), _smax = 0, _ssum = 0, _sn = 0, _sworst = "", _bakes = [], _ink = 0;
    var _sb = buffer_create(CLS_SHEET * CLS_SHEET * 4, buffer_fixed, 1);
    var _lat_ms = [];
    for (_i = 0; _i < array_length(_names); _i++) {
        var _tl = get_timer();
        var _rec = cls__sheet(_rt, _names[_i]);
        array_push(_lat_ms, (get_timer() - _tl) / 1000);
        var _t0 = get_timer();
        var _sheet = cls__sheet_ready(_rt, _rec);
        array_push(_bakes, (get_timer() - _t0) / 1000);
        cls_st_assert(_st, surface_exists(_sheet) && surface_get_width(_sheet) == CLS_SHEET, "sheet " + _names[_i] + " baked");
        var _uv = texture_get_uvs(surface_get_texture(_sheet));
        cls_st_assert(_st, _uv[0] == 0 && _uv[1] == 0 && _uv[2] == 1 && _uv[3] == 1, "sheet " + _names[_i] + " texture spans uv 0..1 (it repeats)");
        buffer_get_surface(_sb, _sheet, 0);
        var _skmax = 0;
        for (var _py = 4; _py < CLS_SHEET; _py += 8) for (var _px = 4; _px < CLS_SHEET; _px += 8) {
            for (var _L = 0; _L < 3; _L++) {
                var _gpu = buffer_peek(_sb, (_py * CLS_SHEET + _px) * 4 + _L, buffer_u8);
                var _cpu = 255 * cls__sheet_value(_rec, _L, (_px + 0.5) / 4, (_py + 0.5) / 4);
                // the shader's base sheet is applied in the overlay, not baked: compare the masses alone on the base layer
                if (_L == _rec.field.baselayer && _rec.field.base > 0) { var _bb = _rec.field.base; _cpu = (_cpu / 255 - _bb) / (1 - _bb) * 255; }
                if (_L == _rec.field.baselayer && _rec.field.base > 0 && _cpu >= 254.9) _cpu = 255;
                var _de = abs(_gpu - _cpu);
                _smax = max(_smax, _de); _skmax = max(_skmax, _de); _ssum += _de; _sn++;
                if (_gpu > 128) _ink++;
            }
        }
        if (_skmax >= _smax) _sworst = _names[_i];
    }
    buffer_delete(_sb);
    _st.measured.sheet_max_err = _smax; _st.measured.sheet_mean_err = _ssum / max(1, _sn); _st.measured.sheet_worst = _sworst; _st.measured.sheet_samples = _sn;
    _st.measured.bake_ms = _bakes; _st.measured.field_and_lattice_ms = _lat_ms;
    cls_st_assert(_st, _ink > 0, "the sheets hold cloud (positive control: " + string(_ink) + " samples over half)");
    cls_st_assert(_st, _smax <= 14, "sheet vs CPU field, worst " + string(_smax) + "/255 on " + _sworst);
    cls_st_assert(_st, _ssum / max(1, _sn) <= 1.5, "sheet vs CPU field, mean " + string(_ssum / max(1, _sn)) + "/255");

    // 9. the surface map, from the demo's marker tile layers
    cls_st_stage(_st, 9);
    var _rows = cls_demo_ground_kinds(), _want = [0, 0, 0, 0, 0, 0, 0];
    for (_i = 0; _i < array_length(_rows); _i++) for (_j = 1; _j <= string_length(_rows[_i]); _j++) {
        var _ch = string_char_at(_rows[_i], _j);
        _want[(_ch == "w") ? 1 : ((_ch == "r") ? 2 : ((_ch == "c") ? 3 : ((_ch == "s") ? 4 : 0)))] += 1;
    }
    var _mlayers = cls_demo_build_markers();
    cls__st_fresh();
    var _info = cls_info(), _kn = cls_kind_names(), _kb = "";
    for (_i = 0; _i < 7; _i++) if (_info.kinds[$ _kn[_i]] != _want[_i]) _kb += _kn[_i] + " want " + string(_want[_i]) + " got " + string(_info.kinds[$ _kn[_i]]) + "; ";
    cls_st_assert(_st, _kb == "", "surface map from the marker layers: " + _kb);
    cls_st_assert(_st, _info.cols == 34 && _info.rows == 26 && _info.cell == 24, "map 34 x 26 at the marker tiles' 24 px (got " + string(_info.cols) + "x" + string(_info.rows) + " @" + string(_info.cell) + ")");
    cls_st_assert(_st, array_length(_info.layers_read) == 4, "four layers read by name (" + string(_info.layers_read) + ")");
    cls_st_assert(_st, cls_surface_kind_at(3.4 * 48, 8.6 * 48) == "water" && cls_surface_kind_at(26 * 24 + 12, 5 * 24 + 12) == "roof" && cls_surface_kind_at(24 * 30 + 12, 24 * 20 + 12) == "ground", "lake, roof and meadow read as water, roof and ground");
    cls_st_assert(_st, _info.sky == "fair" && _info.why == "room make-up", "the valley derives fair weather (11% water), got " + _info.sky + " (" + _info.why + ")");
    // explicit rules: a layer switched off, a tile list that excludes everything, a rectangle, an object
    cls_surface_layer("Water", "none"); cls_update(); _info = cls_info();
    cls_st_assert(_st, _info.kinds[$ "water"] == 0, "cls_surface_layer(..., \"none\") stops reading a layer");
    cls_surface_tiles("Roof", "roof", [3]); cls_update(); _info = cls_info();
    cls_st_assert(_st, _info.kinds[$ "roof"] == 0, "cls_surface_tiles reads only the listed tiles (roof tiles are index 2)");
    cls_surface_tiles("Roof", "roof", [2]); cls_update(); _info = cls_info();
    cls_st_assert(_st, _info.kinds[$ "roof"] == _want[2], "cls_surface_tiles with the right index reads them all again");
    cls_surface_rect(0, 600, 816, 624, "cover"); cls_update(); _info = cls_info();
    cls_st_assert(_st, _info.kinds[$ "cover"] == 34 && cls_shade_at(400, 612) == 0, "a cover rectangle: 34 cells, no shade under it");
    var _mk2 = instance_create_depth(600, 300, 0, obj_cls_marker);
    _mk2.image_xscale = 2; _mk2.image_yscale = 2;
    var _objok = cls_surface_object(obj_cls_marker, "object");
    _st.measured.marker = { type: typeof(obj_cls_marker), accepted: _objok, count: instance_number(obj_cls_marker), bbox: [_mk2.bbox_left, _mk2.bbox_top, _mk2.bbox_right, _mk2.bbox_bottom] };
    cls_st_assert(_st, _objok, "cls_surface_object accepts an object (" + typeof(obj_cls_marker) + ")");
    cls_update(); _info = cls_info();
    // the box reads 600, 300, 840, 348 (120 x 24 sprite at scale 2, full-image mask; the right and bottom are one past the
    // last pixel): cell centres in [600, 840) x [300, 348) are columns 25..33 (the room ends at 34 cells) and rows 12..13
    // = 9 x 2 = 18 cells, worked by hand. A closed test reads 27 (MEASURED, the run before the half-open fix).
    cls_st_assert(_st, _info.kinds[$ "object"] == 18 && cls_surface_kind_at(612, 312) == "object", "an object marks the 18 cells under its box (got " + string(_info.kinds[$ "object"]) + ")");
    instance_destroy(_mk2);

    // 10. the overlay, read back and held to the CPU twin (cls_shade_at)
    cls_st_stage(_st, 10);
    // two questions, kept apart: (a) does the SHADER compute what the CPU computes, given the same sampled sheet - held
    // tight against cls__st_expect_filtered; (b) how far is the EXACT twin (cls_shade_at, the exact field) from the
    // picture - measured as a distribution and bounded, because the picture is drawn from a 256 px sheet of the field
    var _omax = 0, _osum = 0, _on = 0, _odark = 0, _oworst = "", _xerr = [];
    var _skies10 = ["scattered", "storm", "overcast", "mackerel", "towering", "veil"];
    for (var _s10 = 0; _s10 < array_length(_skies10); _s10++) {
        cls__st_fresh({ sky: _skies10[_s10], veer: 0 });
        repeat (37) cls_update();
        var _ob = cls__st_overlay();
        for (var _k = 0; _k < 140; _k++) {
            var _ox = 3 + ((_k * 197) mod 810), _oy = 3 + ((_k * 113 + _s10 * 41) mod 618);
            var _ef = cls__st_expect_filtered(_ox + 0.5, _oy + 0.5), _ex = cls__st_expect(_ox + 0.5, _oy + 0.5);
            var _gg = buffer_peek(_ob, (_oy * room_width + _ox) * 4 + 1, buffer_u8), _gb = buffer_peek(_ob, (_oy * room_width + _ox) * 4 + 2, buffer_u8);
            var _de2 = max(abs(_gg - _ef[1]), abs(_gb - min(255, _ef[2])));
            if (_de2 > _omax) { _omax = _de2; _oworst = _skies10[_s10] + " at " + string(_ox) + "," + string(_oy) + " gpu g" + string(_gg) + " b" + string(_gb) + " want g" + string(_ef[1]) + " b" + string(_ef[2]); }
            _osum += _de2; _on++;
            array_push(_xerr, abs(_gg - _ex[1]));
            if (_gg < 225) _odark++;
        }
        buffer_delete(_ob);
    }
    array_sort(_xerr, true);
    var _xl = array_length(_xerr);
    _st.measured.overlay_max_err = _omax; _st.measured.overlay_mean_err = _osum / max(1, _on); _st.measured.overlay_worst = _oworst; _st.measured.overlay_samples = _on;
    _st.measured.exact_twin_p50 = _xerr[floor(0.5 * (_xl - 1))]; _st.measured.exact_twin_p95 = _xerr[floor(0.95 * (_xl - 1))]; _st.measured.exact_twin_max = _xerr[_xl - 1];
    cls_st_assert(_st, _odark > 0, "the overlay darkens something (positive control: " + string(_odark) + " samples under 225)");
    cls_st_assert(_st, _omax <= 6, "overlay vs the CPU on the same sampled sheet, worst " + string(_omax) + "/255: " + _oworst);
    cls_st_assert(_st, _osum / max(1, _on) <= 1.5, "overlay vs the CPU on the same sampled sheet, mean " + string(_osum / max(1, _on)) + "/255");
    cls_st_assert(_st, _st.measured.exact_twin_p95 <= 6 && _st.measured.exact_twin_max <= 48, "cls_shade_at vs the picture: p95 " + string(_st.measured.exact_twin_p95) + ", worst " + string(_st.measured.exact_twin_max) + " /255 (a ragged edge, a pixel wide)");

    // 11. motion: with the wind at 0 degrees (right) and no veer, a single-layer sky moves RIGHT by its measured speed
    cls_st_stage(_st, 11);
    cls__st_fresh({ sky: "popcorn", veer: 0, wind: 0 });
    // every point is on open ground (the valley's south-east meadow, rows 15..23, columns 20..32), so the surface map is
    // the same at x and at x + shift
    var _mvx = [], _mvy = [], _before = [];
    for (var _gy = 372; _gy <= 552; _gy += 30) for (var _gx = 486; _gx <= 750; _gx += 24) { array_push(_mvx, _gx); array_push(_mvy, _gy); array_push(_before, cls_shade_at(_gx, _gy)); }
    repeat (60) cls_update();
    var _shift = 0.35 * CLS_CELLS_PER_SEC * 1 * 24, _mvbad = 0, _mvnz = 0, _mvn = array_length(_mvx);
    for (_i = 0; _i < _mvn; _i++) {
        var _after = cls_shade_at(_mvx[_i] + _shift, _mvy[_i]);
        if (abs(_after - _before[_i]) > 0.000001) _mvbad++;
        if (_before[_i] > 0.01) _mvnz++;
    }
    cls_st_assert(_st, _mvbad == 0, "after one second the shade at x + " + string(_shift) + " px equals the shade that was at x (" + string(_mvbad) + " of " + string(_mvn) + " differ)");
    // ⛔ the vacuity guard: a sky with no cloud over the sample would pass the line above by comparing zeros
    cls_st_assert(_st, _mvnz >= 3, "the motion sample is under cloud at " + string(_mvnz) + " of " + string(_mvn) + " points (need 3)");
    _st.measured.motion_points_in_shade = _mvnz;

    // 12. a fade: the blend climbs over its seconds and ends on the new sky alone
    cls_st_stage(_st, 12);
    cls__st_fresh({ sky: "clear" });
    cls_st_assert(_st, cls_set_sky("storm", 2), "cls_set_sky(storm, 2)");
    repeat (60) cls_update();
    var _mid = cls_info();
    cls_st_assert(_st, _mid.prev_sky == "clear" && abs(_mid.blend - 0.5) < 0.02, "half way through a 2 s fade (blend " + string(_mid.blend) + ")");
    repeat (61) cls_update();
    var _end = cls_info();
    cls_st_assert(_st, _end.prev_sky == "" && _end.blend == 1 && _end.sky == "storm", "the fade ends on storm alone");
    cls_st_assert(_st, cls_set_sky("fog", 0) && cls_info().prev_sky == "" && cls_get_sky() == "fog", "a 0 s change is immediate");

    // 13. save and load
    cls_st_stage(_st, 13);
    cls__st_fresh();
    cls_set_sky("squall", 3); cls_set_wind(30, 1.4); cls_set_intensity(0.8); cls_set_daylight(0.6);
    repeat (45) cls_update();
    var _sv = cls_save(), _a1 = json_parse(_sv);
    cls__st_fresh();
    cls_st_assert(_st, cls_load(_sv), "cls_load accepts its own save");
    var _a2 = json_parse(cls_save()), _keys = variable_struct_get_names(_a1), _svb = "";
    for (_i = 0; _i < array_length(_keys); _i++) {
        var _va = _a1[$ _keys[_i]], _vb = _a2[$ _keys[_i]];
        if (is_array(_va)) { for (_j = 0; _j < array_length(_va); _j++) if (abs(_va[_j] - _vb[_j]) > 0.000000001) _svb += _keys[_i] + " "; }
        else if (is_numeric(_va)) { if (abs(_va - _vb) > 0.000000001) _svb += _keys[_i] + " "; }
        else if (_va != _vb) _svb += _keys[_i] + " ";
    }
    cls_st_assert(_st, _svb == "", "a save survives a restart unchanged (" + _svb + ")");
    cls_st_assert(_st, !cls_load("{bad json") && !cls_load(12) && !cls_load(""), "bad saves are refused");
    cls_st_assert(_st, cls_load("{\"sky\":\"veil\",\"future_field\":7}") && cls_get_sky() == "veil", "an unknown field is ignored, a missing one kept");

    // 14. guards: the documented API on bad input never crashes and refuses with a value
    cls_st_stage(_st, 14);
    cls__st_fresh();
    cls_st_assert(_st, !cls_set_sky(undefined) && !cls_set_sky("nonsense") && cls_set_sky("storm", "x"), "cls_set_sky refuses unknown skies");
    cls_st_assert(_st, cls_shade_at("a", 0) == 0 && cls_shade_at(undefined, undefined) == 0, "cls_shade_at on non-numbers is 0");
    cls_st_assert(_st, !cls_surface_rect(0, 0, 10, 10, "lava") && !cls_surface_layer(5, "water") && !cls_surface_tiles("Water", "water", "x") && !cls_surface_object(-5, "water"), "surface rules refuse bad kinds and targets");
    cls_st_assert(_st, !cls_set_wind("x") && is_undefined(cls_field(64, 64, "nope", 1)) && is_undefined(cls_field("a", 3, "fair", 1)), "wind and field refuse bad input");
    cls_st_assert(_st, cls_rng_next(undefined) == 0 && cls_shade_at_field(undefined, 1, 1, 0) == 0 && cls_measure(undefined, 0, 1).samples == 0, "pure functions refuse non-structs");
    cls_set_intensity("x"); cls_set_daylight(5); cls_set_coolness(-3);
    cls_st_assert(_st, cls__rt().daylight == 1 && cls__rt().coolness == 0 && cls__rt().intensity == 1, "setters clamp or ignore bad values");
    cls_st_assert(_st, cls_surface_kind_at("x", 1) == "" && cls_kind_names()[6] == "cover", "kind query refuses non-numbers");

    // 15. the ceiling: no intensity drives a shadow past CLS_MAX_SHADE, on the CPU twin or on the GPU
    cls_st_stage(_st, 15);
    cls__st_fresh({ sky: "storm", intensity: 25 });
    repeat (20) cls_update();
    var _cmax = 0;
    for (var _cy = 6; _cy < room_height; _cy += 24) for (var _cx = 6; _cx < room_width; _cx += 24) _cmax = max(_cmax, cls_shade_at(_cx, _cy));
    cls_st_assert(_st, _cmax <= CLS_MAX_SHADE && _cmax > 0.5, "at intensity 25 the deepest shade is the ceiling (" + string(_cmax) + ")");
    var _cb = cls__st_overlay(), _cmin = 255;
    for (var _k2 = 0; _k2 < room_width * room_height; _k2 += 7) _cmin = min(_cmin, buffer_peek(_cb, _k2 * 4 + 1, buffer_u8));
    buffer_delete(_cb);
    _st.measured.ceiling_min_green = _cmin;
    cls_st_assert(_st, _cmin >= floor(255 * (1 - CLS_MAX_SHADE) * cls__cool()[1]) - 3, "the GPU never darkens past the ceiling (min green " + string(_cmin) + ")");

    // 16. interiors: forced on, the overlay draws nothing and nothing is in shade
    cls_st_stage(_st, 16);
    cls__st_fresh({ sky: "storm", interior: "on" });
    var _ib = cls__st_overlay(), _imin = 255;
    for (var _k3 = 0; _k3 < room_width * room_height; _k3 += 13) _imin = min(_imin, buffer_peek(_ib, _k3 * 4 + 1, buffer_u8));
    buffer_delete(_ib);
    cls_st_assert(_st, _imin == 255 && cls_shade_at(400, 300) == 0, "an interior draws nothing (min " + string(_imin) + ")");
    cls_set_enabled(false);
    cls_st_assert(_st, cls_shade_at(400, 300) == 0, "disabled reads 0");

    // 17. timings (reported, not judged beyond a sanity ceiling)
    cls_st_stage(_st, 17);
    cls__st_fresh({ sky: "storm" });
    var _tq = get_timer();
    for (_i = 0; _i < 200; _i++) cls_shade_at(10 + _i * 4, 300);
    _st.measured.shade_at_us = (get_timer() - _tq) / 200;
    _st.measured.map_ms = cls__rt().stats.map_ms;
    cls_st_assert(_st, _st.measured.shade_at_us < 5000, "cls_shade_at under 5 ms (" + string(_st.measured.shade_at_us) + " us)");

    // 18. photographs: the valley with no weather, the surface map, and every sky (cls_render_*.png in the save folder),
    // and the positive control that the pictures say what the skies say: heavier weather takes more light
    cls_st_stage(_st, 18);
    var _means = {}, _shots = array_concat(["none", "map"], _names);
    for (_i = 0; _i < array_length(_shots); _i++) {
        var _shot = _shots[_i];
        cls__st_fresh({ sky: cls_sky_exists(_shot) ? _shot : "fair", veer: 0, wind: 20 });
        repeat (90) cls_update();
        var _surf = surface_create(room_width, room_height);
        surface_set_target(_surf);
        draw_clear_alpha(c_black, 1);
        draw_sprite(spr_cls_demo_ground, 0, 0, 0);
        if (_shot == "map") cls_draw_surface_map(0.5);
        else if (_shot != "none") cls_draw();
        surface_reset_target();
        surface_save(_surf, "cls_render_" + _shot + ".png");
        var _rb = buffer_create(room_width * room_height * 4, buffer_fixed, 1);
        buffer_get_surface(_rb, _surf, 0);
        var _sum = 0, _cnt = 0;
        for (var _p = 0; _p < room_width * room_height; _p += 11) { _sum += buffer_peek(_rb, _p * 4 + 1, buffer_u8); _cnt++; }
        buffer_delete(_rb);
        surface_free(_surf);
        _means[$ _shot] = _sum / _cnt;
    }
    _st.measured.render_mean_green = _means;
    cls_st_assert(_st, abs(_means[$ "map"] - _means[$ "none"]) > 1, "the surface-map view changes the picture (mean green " + string(_means[$ "map"]) + " vs " + string(_means[$ "none"]) + ")");
    cls_st_assert(_st, _means[$ "storm"] < _means[$ "clear"] && _means[$ "clear"] < _means[$ "none"] && _means[$ "overcast"] < _means[$ "fair"], "the photographs darken in the skies' order (none " + string(_means[$ "none"]) + ", clear " + string(_means[$ "clear"]) + ", fair " + string(_means[$ "fair"]) + ", overcast " + string(_means[$ "overcast"]) + ", storm " + string(_means[$ "storm"]) + ")");

    cls_stop();
    for (_i = 0; _i < array_length(_mlayers); _i++) layer_destroy(_mlayers[_i]);
    _st.epsilon_after = math_get_epsilon();
    cls_st_assert(_st, math_get_epsilon() == _eps0, "the caller's epsilon is handed back");
    return _st;
}

/// @function cls_selftest_write(state)
/// @description Write the self-test result as cls_selftest.json in the game's save folder.
function cls_selftest_write(_st) {
    var _f = file_text_open_write("cls_selftest.json");
    file_text_write_string(_f, json_stringify(_st));
    file_text_close(_f);
}
