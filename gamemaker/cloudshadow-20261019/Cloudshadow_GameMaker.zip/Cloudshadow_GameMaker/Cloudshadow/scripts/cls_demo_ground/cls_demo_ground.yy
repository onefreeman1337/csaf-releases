{
  "$GMScript": "v1",
  "%Name": "cls_demo_ground",
  "name": "cls_demo_ground",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}