/// cls_core.gml - Cloudshadow's pure half: it turns a seed and a sky into a field of cloud masses and answers how much
/// light any point has lost. Nothing here draws, reads the room, or uses the engine's random functions.
///
/// Cloudshadow - Drifting Cloud Shadows for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// The RPG Maker MZ edition's CloudshadowCore.js, ported line for line and held to it by the in-engine suite (cls_selftest,
/// against cls_oracle_core): the hash, the generator, the lattice noise, the five MZ skies' fields and shadeAt. The eight
/// skies the MZ edition does not have (popcorn, broken, mackerel, cirrus, veil, fog, squall, towering) are built by the
/// same machinery with their own CONSTRUCTION (rows, a front, towers with anvils, a high sheet), not new numbers alone.
///
/// Units: a field is built in "cloud units" (the runtime bakes one 64 x 64 field per sky and scrolls it); x, y and the
/// radii below are in those units. Every public function here is pure and allocates only what it returns.
///
/// Public functions (each documented below): cls_hash, cls_rng, cls_rng_next, cls_rng_range, cls_rng_int, cls_vnoise,
/// cls_turbulence, cls_sky_names, cls_sky_spec, cls_sky_exists, cls_field, cls_shade_at_field, cls_measure.

#macro CLS_VERSION "1.0.0"
#macro CLS_FIELD_UNITS 64
#macro CLS_LUMP_LATTICE 18
#macro CLS_MAX_SHADE 0.58

// ---------------------------------------------------------------------------------------------------------------
// Unsigned 32-bit arithmetic (JavaScript's Math.imul, >>> 0 and >> on int32, exact, as int64 halves)
// ---------------------------------------------------------------------------------------------------------------

/// @function cls__imul(a, b)
/// @description Internal. JavaScript's Math.imul, as an unsigned 32-bit result in an int64.
function cls__imul(_a, _b) {
    var _m = int64($FFFFFFFF);
    _a = int64(_a) & _m; _b = int64(_b) & _m;
    var _lo = (_a * (_b & int64($FFFF))) & _m;
    var _hi = ((_a * (_b >> 16)) & int64($FFFF)) << 16;
    return (_lo + _hi) & _m;
}

/// @function cls__u32(v)
/// @description Internal. JavaScript's (v >>> 0): truncated toward zero, then modulo 2^32; not a number -> 0.
function cls__u32(_v) {
    if (!is_numeric(_v)) return int64(0);
    if (is_real(_v) && (is_nan(_v) || is_infinity(_v))) return int64(0);
    if (_v < 0) return (int64($100000000) - (int64(-_v) & int64($FFFFFFFF))) & int64($FFFFFFFF);
    return int64(_v) & int64($FFFFFFFF);
}

/// @function cls__sar32(x, n)
/// @description Internal. JavaScript's (x >> n) on the int32 whose bits are x: an ARITHMETIC shift, as unsigned bits.
/// Written with a mask rather than a shift of a negative int64, so it does not depend on how the runtime shifts one.
function cls__sar32(_x, _n) {
    var _m = int64($FFFFFFFF);
    var _s = int64(_x) & _m;
    var _r = _s >> _n;
    if ((_s & int64($80000000)) != 0) _r = _r | ((_m << (32 - _n)) & _m);
    return _r & _m;
}

/// @function cls_hash(text)
/// @description The FNV-1a hash of a word (UTF-16 code units), exactly as the MZ edition computes it. Pure.
/// @param {String} text   anything; a non-string is hashed as its string form
/// @returns {Real} 0 .. 4294967295
function cls_hash(_s) {
    var _t = is_string(_s) ? _s : string(_s);
    var _h = int64(2166136261), _n = string_length(_t);
    for (var _i = 1; _i <= _n; _i++) { _h = _h ^ int64(ord(string_char_at(_t, _i)) & $FFFF); _h = cls__imul(_h, 16777619); }
    return real(_h);
}

// ---------------------------------------------------------------------------------------------------------------
// The seeded generator: xorshift32, the MZ edition's (never the engine's random functions - a room's sky must be the
// same sky every time the player walks back into it)
// ---------------------------------------------------------------------------------------------------------------

/// @function cls_rng(seed)
/// @description A generator for a seed (any number; it is taken modulo 2^32, and 0 becomes 1 as in the MZ edition).
/// @param {Real} seed
/// @returns {Struct} { s } - pass it to cls_rng_next / cls_rng_range / cls_rng_int
function cls_rng(_seed) {
    var _s = cls__u32(_seed);
    if (_s == 0) _s = int64(1);
    return { s: _s };
}

/// @function cls_rng_next(rng)
/// @description The next draw, 0 <= v < 1. Advances the generator.
/// @param {Struct} rng   from cls_rng
/// @returns {Real}
function cls_rng_next(_r) {
    if (!is_struct(_r) || !variable_struct_exists(_r, "s")) return 0;
    var _m = int64($FFFFFFFF);
    var _x = int64(_r.s) & _m;
    _x = (_x ^ ((_x << 13) & _m)) & _m;
    _x = (_x ^ cls__sar32(_x, 17)) & _m;
    _x = (_x ^ ((_x << 5) & _m)) & _m;
    _r.s = _x;
    return real(_x) / 4294967296;
}

/// @function cls_rng_range(rng, lo, hi)
/// @description A draw between lo and hi (lo + (hi - lo) * next).
/// @returns {Real}
function cls_rng_range(_r, _lo, _hi) { var _d = cls_rng_next(_r); return _lo + (_hi - _lo) * _d; }

/// @function cls_rng_int(rng, lo, hi)
/// @description A whole number from lo to hi inclusive.
/// @returns {Real}
function cls_rng_int(_r, _lo, _hi) { var _d = cls_rng_next(_r); return _lo + floor(_d * (_hi - _lo + 1)); }

// ---------------------------------------------------------------------------------------------------------------
// Lattice noise and turbulence (the MZ edition's, exact): value noise on a lattice that WRAPS on L, so a field baked
// over any size tiles seamlessly
// ---------------------------------------------------------------------------------------------------------------

/// @function cls_lattice_value(seed, L, i, j)
/// @description The hashed lattice value at integer cell (i, j) on a lattice of L cells that wraps. 0 <= v < 1.
/// @returns {Real}
function cls_lattice_value(_seed, _L, _i, _j) {
    var _m = int64($FFFFFFFF);
    var _a = ((_i mod _L) + _L) mod _L, _b = ((_j mod _L) + _L) mod _L;
    var _n = (cls__imul(_a, 374761393) + cls__imul(_b, 668265263) + cls__imul(cls__u32(_seed), 1274126177)) & _m;
    _n = (_n ^ (_n >> 13)) & _m;
    _n = cls__imul(_n, 1274126177);
    return real((_n ^ (_n >> 16)) & _m) / 4294967296;
}

/// @function cls_vnoise(seed, L, u, v)
/// @description Smoothstepped value noise at (u, v) in lattice cells, on a lattice of L cells that wraps. 0..1. Anything
/// that is not a number, or a lattice under one cell, reads 0.
/// @returns {Real}
function cls_vnoise(_seed, _L, _u, _v) {
    if (!is_numeric(_seed) || !is_numeric(_L) || !is_numeric(_u) || !is_numeric(_v)) return 0;
    if (!(_L >= 1)) return 0;
    return cls__vnoise(_seed, _L, _u, _v);
}

/// @function cls__vnoise(seed, L, u, v)
/// @description Internal. cls_vnoise without the guards (the field's hot path; its callers pass numbers).
function cls__vnoise(_seed, _L, _u, _v) {
    var _x0 = floor(_u), _y0 = floor(_v);
    var _fx = _u - _x0, _fy = _v - _y0;
    var _sx = _fx * _fx * (3 - 2 * _fx), _sy = _fy * _fy * (3 - 2 * _fy);
    var _n00 = cls_lattice_value(_seed, _L, _x0, _y0);
    var _n10 = cls_lattice_value(_seed, _L, _x0 + 1, _y0);
    var _n01 = cls_lattice_value(_seed, _L, _x0, _y0 + 1);
    var _n11 = cls_lattice_value(_seed, _L, _x0 + 1, _y0 + 1);
    return (_n00 * (1 - _sx) + _n10 * _sx) * (1 - _sy) + (_n01 * (1 - _sx) + _n11 * _sx) * _sy;
}

/// @function cls_turbulence(seed, L, u, v)
/// @description Three octaves of cls_vnoise (L, 2L, 4L), centred on zero: about -0.5 .. 0.5. This is what makes a cloud
/// edge ragged at three scales instead of an airbrushed ellipse (the MZ edition's finding, by looking).
/// Anything that is not a number, or a lattice under one cell, reads 0.
/// @returns {Real}
function cls_turbulence(_seed, _L, _u, _v) {
    if (!is_numeric(_seed) || !is_numeric(_L) || !is_numeric(_u) || !is_numeric(_v)) return 0;
    if (!(_L >= 1)) return 0;
    return cls__turbulence(_seed, _L, _u, _v);
}

/// @function cls__turbulence(seed, L, u, v)
/// @description Internal. cls_turbulence without the guards (the field's hot path).
function cls__turbulence(_seed, _L, _u, _v) {
    var _a = cls__vnoise(_seed, _L, _u, _v);
    var _b = cls__vnoise(_seed + 101, _L * 2, _u * 2, _v * 2);
    var _c = cls__vnoise(_seed + 202, _L * 4, _u * 4, _v * 4);
    return (_a * 0.5 + _b * 0.33 + _c * 0.17) - 0.5;
}

// ---------------------------------------------------------------------------------------------------------------
// The skies
// ---------------------------------------------------------------------------------------------------------------

/// @function cls__skies()
/// @description Internal. Every sky, built once. Each names its CONSTRUCTION, not only its numbers (a sky that is only
/// "the same clouds, fewer of them" is a palette, not a composition):
///   cover    share of the sky the state wants covered          masses   how many masses build it
///   stretch  how much longer than wide a mass runs (wind-drawn) edge     softness of the rim, share of the radius
///   layers   distinct altitudes                                  layer0   the lowest altitude used (0 low .. 2 high)
///   depth    light taken by the thickest shadow, 0..1            base     light taken everywhere first, share of depth
///   baselayer the altitude that carries the base sheet          lump     how ragged the rim is
///   form     puffs | rows | front | towers                       + per-form fields (rows, band, anvil)
/// The first five are the MZ edition's, number for number (cls_selftest holds them to it).
function cls__skies() {
    static _sk = undefined;
    if (!is_undefined(_sk)) return _sk;
    var _d = function(_cover, _masses, _stretch, _edge, _layers, _depth, _base, _lump) {
        return { cover: _cover, masses: _masses, stretch: _stretch, edge: _edge, layers: _layers, depth: _depth, base: _base, lump: _lump,
            layer0: 0, baselayer: 0, form: "puffs", rows: 0, band: 0, anvil: 0 };
    };
    _sk = {};
    // the MZ edition's five, exact
    _sk[$ "clear"] = _d(0.06, 5, 1.15, 0.30, 1, 0.18, 0, 0.50);
    _sk[$ "fair"] = _d(0.22, 11, 1.35, 0.26, 2, 0.28, 0, 0.58);
    _sk[$ "scattered"] = _d(0.42, 17, 1.6, 0.22, 2, 0.36, 0, 0.66);
    _sk[$ "overcast"] = _d(0.82, 7, 2.6, 0.60, 1, 0.46, 0.55, 0.40);
    _sk[$ "storm"] = _d(0.7, 23, 2.2, 0.16, 3, 0.62, 0.15, 0.78);
    // the eight the MZ edition does not have
    // popcorn: fair-weather cumulus humilis - many small hard-edged heaps, low, one altitude
    _sk[$ "popcorn"] = _d(0.20, 44, 1.1, 0.22, 1, 0.30, 0, 0.55);
    // broken: more cloud than sky, two altitudes, no sheet under it
    _sk[$ "broken"] = _d(0.62, 21, 1.8, 0.20, 2, 0.42, 0, 0.72);
    // mackerel: cirrocumulus - small puffs in ROWS across the wind, high and faint (form "rows")
    // depth 0.22, not 0.16: at 0.16 the first photograph read as a faint dapple, not as rows (LOOKED AT, 2026-10-19)
    var _mk = _d(0.36, 60, 1.25, 0.26, 1, 0.22, 0, 0.45); _mk.layer0 = 2; _mk.form = "rows"; _mk.rows = 10; _sk[$ "mackerel"] = _mk;
    // cirrus: long thin high streaks drawn out by the wind, the faintest shadow there is
    var _ci = _d(0.24, 16, 7.0, 0.55, 1, 0.12, 0, 0.32); _ci.layer0 = 2; _sk[$ "cirrus"] = _ci;
    // veil: cirrostratus - a thin high SHEET (the base rides the HIGH layer), barely modulated
    var _vl = _d(0.90, 5, 3.0, 0.85, 1, 0.17, 0.70, 0.25); _vl.layer0 = 2; _vl.baselayer = 2; _sk[$ "veil"] = _vl;
    // fog: low soft banks dragging slowly over the ground, a little sheet beneath them
    _sk[$ "fog"] = _d(0.75, 6, 2.2, 0.92, 1, 0.30, 0.25, 0.30);
    // squall: a FRONT - a dense band of storm cells across the wind, broken weather behind it (form "front")
    var _sq = _d(0.50, 30, 1.5, 0.16, 3, 0.62, 0, 0.80); _sq.form = "front"; _sq.band = 0.22; _sk[$ "squall"] = _sq;
    // towering: cumulonimbus - a few giant hard-cored towers, each with a soft ANVIL sheared downwind on the high layer
    var _tw = _d(0.30, 4, 1.0, 0.12, 1, 0.66, 0, 0.70); _tw.form = "towers"; _tw.anvil = 0.45; _sk[$ "towering"] = _tw;
    return _sk;
}

/// @function cls_sky_names()
/// @description Every sky, in order from the lightest weather to the heaviest (a new array each call).
/// @returns {Array<String>}
function cls_sky_names() {
    return ["clear", "fair", "popcorn", "scattered", "broken", "mackerel", "cirrus", "veil", "overcast", "fog", "squall", "towering", "storm"];
}

/// @function cls_sky_exists(name)
/// @description True when name is a sky (cls_sky_names).
/// @returns {Bool}
function cls_sky_exists(_n) { return is_string(_n) && variable_struct_exists(cls__skies(), _n); }

/// @function cls_sky_spec(name)
/// @description A COPY of one sky's numbers (see cls__skies for the fields), or undefined for an unknown name.
/// @returns {Struct|Undefined}
function cls_sky_spec(_n) {
    if (!cls_sky_exists(_n)) return undefined;
    var _s = cls__skies()[$ _n], _c = {}, _k = variable_struct_get_names(_s);
    for (var _i = 0; _i < array_length(_k); _i++) _c[$ _k[_i]] = _s[$ _k[_i]];
    return _c;
}

// ---------------------------------------------------------------------------------------------------------------
// The field
// ---------------------------------------------------------------------------------------------------------------

/// @function cls_field(w, h, sky, seed, [wind])
/// @description Build a field of cloud masses for one sky over a w x h area (cloud units). Pure and deterministic: the
/// same arguments give the same field. For the MZ edition's five skies it is the MZ field, mass for mass.
/// @param {Real} w      width (taken as floor, at least 1)
/// @param {Real} h      height
/// @param {String} sky  a name from cls_sky_names (unknown -> undefined)
/// @param {Real} seed   any number (modulo 2^32)
/// @param {Real} [wind] radians; omitted (or not a finite number) means "drawn from the seed", as in the MZ edition
/// @returns {Struct|Undefined} { sky, w, h, wind, depth, base, baselayer, layers, layer0, lump, seed, masses: [{x, y, rx, ry, edge, layer, drift, k}] }
function cls_field(_w, _h, _sky, _seed, _wind = undefined) {
    if (!cls_sky_exists(_sky)) return undefined;
    if (!is_numeric(_w) || !is_numeric(_h)) return undefined;
    var _eps = math_get_epsilon(); math_set_epsilon(0);
    var _spec = cls__skies()[$ _sky];
    var _W = max(1, floor(_w)), _H = max(1, floor(_h));
    var _rng = cls_rng(cls__u32(_seed) ^ int64(cls_hash("sky:" + _sky)));
    var _wd;
    if (is_numeric(_wind) && !(is_real(_wind) && (is_nan(_wind) || is_infinity(_wind)))) _wd = real(_wind);
    else _wd = cls_rng_range(_rng, 0, pi * 2);
    // the area a mass must cover to reach the state's cover share, spread over its mass count: a field is built in
    // cloud units, so a big area gets bigger weather rather than more of it
    var _area = _W * _H * _spec.cover;
    var _per = _area / _spec.masses;
    var _masses = [];
    if (_spec.form == "puffs") {
        for (var _i = 0; _i < _spec.masses; _i++) {
            // ⛔ every draw goes into its own variable, in the MZ edition's order (a GML struct or array literal of calls
            // that share state does not evaluate left to right - Doctrine_Craft s11)
            var _rr = cls_rng_range(_rng, 0.7, 1.4);
            var _r = sqrt(_per / pi) * _rr;
            var _mx = cls_rng_range(_rng, 0, _W);
            var _my = cls_rng_range(_rng, 0, _H);
            var _me = cls_rng_range(_rng, 0.85, 1.15);
            var _ml = cls_rng_int(_rng, 0, _spec.layers - 1);
            var _md = cls_rng_range(_rng, 0.82, 1.18);
            array_push(_masses, { x: _mx, y: _my, rx: _r * _spec.stretch, ry: _r / sqrt(_spec.stretch), edge: _spec.edge * _me, layer: _spec.layer0 + _ml, drift: _md, k: 1 });
        }
    } else {
        cls__field_form(_masses, _rng, _spec, _W, _H, _per);
    }
    var _f = { sky: _sky, w: _W, h: _H, wind: _wd, depth: _spec.depth, base: _spec.base, baselayer: _spec.baselayer, layers: _spec.layers,
        layer0: _spec.layer0, lump: _spec.lump, seed: real((cls__u32(_seed) ^ int64(cls_hash("lump:" + _sky))) & int64($FFFFFFFF)), masses: _masses };
    math_set_epsilon(_eps);
    return _f;
}

/// @function cls__field_form(masses, rng, spec, W, H, per)
/// @description Internal. The constructions the MZ edition does not have: rows (mackerel), a front (squall) and towers
/// with anvils (towering). Each draws from the same generator, so a field is still a pure function of its arguments.
function cls__field_form(_masses, _rng, _spec, _W, _H, _per) {
    var _i, _r, _rr, _mx, _my, _me, _ml, _md;
    if (_spec.form == "rows") {
        // columns ACROSS the wind (the wind runs along x in field space): a regular spacing, each row wavering, each puff
        // jittered - the herringbone of a mackerel sky, never a grid
        var _rows = max(1, _spec.rows), _per_row = max(1, round(_spec.masses / _rows));
        var _phase = cls_rng_range(_rng, 0, _W);
        for (var _c = 0; _c < _rows; _c++) {
            var _cx = _phase + (_c + 0.5) * (_W / _rows);
            var _wav = cls_rng_range(_rng, 0, pi * 2);
            for (var _j = 0; _j < _per_row; _j++) {
                _rr = cls_rng_range(_rng, 0.7, 1.3);
                _r = sqrt(_per / pi) * _rr;
                var _yy = (_j + cls_rng_range(_rng, 0.2, 0.8)) * (_H / _per_row);
                _mx = _cx + sin(_wav + _yy / _H * pi * 4) * (_W / _rows) * 0.18 + cls_rng_range(_rng, -0.08, 0.08) * (_W / _rows);
                _me = cls_rng_range(_rng, 0.85, 1.15);
                _md = cls_rng_range(_rng, 0.96, 1.04);
                // rows run ACROSS the wind, so a puff is drawn out along the row (y), not along the wind
                array_push(_masses, { x: _mx, y: _yy, rx: _r / sqrt(_spec.stretch), ry: _r * _spec.stretch, edge: _spec.edge * _me, layer: _spec.layer0, drift: _md, k: 1 });
            }
        }
        return;
    }
    if (_spec.form == "front") {
        // a band of storm cells across the wind at a random x, two thirds of the masses in it, the rest broken behind
        var _fx = cls_rng_range(_rng, 0, _W), _bw = _spec.band * _W;
        for (_i = 0; _i < _spec.masses; _i++) {
            var _inband = (_i * 3 < _spec.masses * 2);
            _rr = cls_rng_range(_rng, 0.7, 1.4);
            _r = sqrt(_per / pi) * _rr * (_inband ? 1.1 : 0.8);
            if (_inband) _mx = _fx + cls_rng_range(_rng, -0.5, 0.5) * _bw;
            else _mx = _fx - _bw * 0.6 - cls_rng_range(_rng, 0, _W * 0.45);
            _my = cls_rng_range(_rng, 0, _H);
            _me = cls_rng_range(_rng, 0.85, 1.15);
            _ml = cls_rng_int(_rng, 0, _spec.layers - 1);
            _md = cls_rng_range(_rng, 0.96, 1.04);
            array_push(_masses, { x: _mx, y: _my, rx: _r * _spec.stretch * (_inband ? 0.55 : 1), ry: _r / sqrt(_spec.stretch) * (_inband ? 1.7 : 1),
                edge: _spec.edge * _me * (_inband ? 1 : 1.6), layer: _spec.layer0 + (_inband ? 0 : _ml), drift: _md, k: _inband ? 1 : 0.7 });
        }
        return;
    }
    if (_spec.form == "towers") {
        // a few giants: a hard dense core low down, and a soft flat ANVIL sheared downwind on the high layer
        for (_i = 0; _i < _spec.masses; _i++) {
            _rr = cls_rng_range(_rng, 0.8, 1.25);
            _r = sqrt(_per / pi) * _rr * 0.8;
            _mx = cls_rng_range(_rng, 0, _W);
            _my = cls_rng_range(_rng, 0, _H);
            _me = cls_rng_range(_rng, 0.85, 1.15);
            _md = cls_rng_range(_rng, 0.97, 1.03);
            array_push(_masses, { x: _mx, y: _my, rx: _r * _spec.stretch, ry: _r / sqrt(_spec.stretch), edge: _spec.edge * _me, layer: 0, drift: _md, k: 1 });
            var _ao = cls_rng_range(_rng, 1.2, 1.9), _ay = cls_rng_range(_rng, -0.25, 0.25);
            array_push(_masses, { x: _mx + _r * _ao, y: _my + _r * _ay, rx: _r * 2.3, ry: _r * 1.25, edge: 0.7, layer: 2, drift: _md, k: _spec.anvil });
        }
        return;
    }
}

/// @function cls__wrap(v, n)
/// @description Internal. v wrapped into 0 .. n (the MZ edition's wrap).
function cls__wrap(_v, _n) { var _r = _v mod _n; return (_r < 0) ? _r + _n : _r; }

/// @function cls_shade_at_field(field, x, y, t, [layer])
/// @description How much light a point has lost at time t (seconds), the MZ edition's shadeAt: 0 .. field.depth. The field
/// WRAPS, so no area ever runs out of weather. With layer >= 0 only that altitude's masses are counted and the base sheet
/// only on its own layer - this is exactly one channel of the sheet the runtime bakes, divided back by depth.
/// @param {Struct} field   from cls_field
/// @param {Real} x         in cloud units
/// @param {Real} y
/// @param {Real} t         seconds of drift (0 = the field as built)
/// @param {Real} [layer]   -1 (default) = every altitude
/// @returns {Real}
function cls_shade_at_field(_f, _x, _y, _t, _layer = -1) {
    if (!is_struct(_f) || !variable_struct_exists(_f, "masses")) return 0;
    if (!is_numeric(_x) || !is_numeric(_y) || !is_numeric(_t)) return 0;
    var _eps = math_get_epsilon(); math_set_epsilon(0);
    var _cw = cos(_f.wind), _sw = sin(_f.wind);
    var _base = _f.base;
    if (_layer >= 0 && _layer != _f.baselayer) _base = 0;
    var _lump = 0;
    if (_f.lump != 0) _lump = cls__turbulence(_f.seed, CLS_LUMP_LATTICE, _x / _f.w * CLS_LUMP_LATTICE, _y / _f.h * CLS_LUMP_LATTICE) * _f.lump;
    var _acc = 0, _ms = _f.masses, _n = array_length(_ms), _full = false;
    for (var _i = 0; _i < _n; _i++) {
        var _m = _ms[_i];
        if (_layer >= 0 && _m.layer != _layer) continue;
        // a higher layer moves faster, which is what reads as altitude
        var _speed = (0.35 + 0.45 * _m.layer) * _m.drift;
        var _dx = _x - cls__wrap(_m.x + _cw * _speed * _t, _f.w);
        var _dy = _y - cls__wrap(_m.y + _sw * _speed * _t, _f.h);
        if (_dx > _f.w / 2) _dx -= _f.w; else if (_dx < -_f.w / 2) _dx += _f.w;
        if (_dy > _f.h / 2) _dy -= _f.h; else if (_dy < -_f.h / 2) _dy += _f.h;
        // the lumpy rim: the normalised distance pushed in and out by the local turbulence
        var _d = sqrt((_dx * _dx) / (_m.rx * _m.rx) + (_dy * _dy) / (_m.ry * _m.ry)) + _lump;
        if (_d >= 1) continue;
        var _inner = 1 - _m.edge;
        var _v = (_d <= _inner) ? 1 : 1 - (_d - _inner) / ((_m.edge != 0) ? _m.edge : 0.000001);
        _acc += _m.k * (_v * _v * (3 - 2 * _v));
        if (_acc >= 1) { _full = true; break; }
    }
    var _out;
    // a full mass stack is the full depth whatever the base (the MZ edition returns f.depth there)
    if (_full) _out = _f.depth;
    else { var _a = (_acc > 1) ? 1 : _acc; _out = _f.depth * (_base + _a * (1 - _base)); }
    math_set_epsilon(_eps);
    return _out;
}

/// @function cls_measure(field, t, step)
/// @description What a field actually does, sampled on a grid every `step` units: { mean, touched, covered, deep, spread,
/// max, samples } - touched = any loss at all, covered = a quarter of depth, deep = 70% of depth, spread = (p90 - p10) /
/// depth (an even sheet is small, a ragged storm large). The MZ edition's measure().
/// @returns {Struct}
function cls_measure(_f, _t, _step) {
    var _r = { mean: 0, touched: 0, covered: 0, deep: 0, spread: 0, max: 0, samples: 0 };
    if (!is_struct(_f) || !variable_struct_exists(_f, "masses")) return _r;
    var _eps = math_get_epsilon(); math_set_epsilon(0);
    var _s = max(1, floor(is_numeric(_step) ? _step : 1));
    var _tt = is_numeric(_t) ? _t : 0;
    var _sum = 0, _touched = 0, _covered = 0, _deep = 0, _max = 0, _n = 0, _vals = [];
    for (var _y = 0; _y < _f.h; _y += _s) {
        for (var _x = 0; _x < _f.w; _x += _s) {
            var _v = cls_shade_at_field(_f, _x, _y, _tt);
            _sum += _v; _n++; array_push(_vals, _v);
            if (_v > _f.depth * 0.01) _touched++;
            if (_v > _f.depth * 0.25) _covered++;
            if (_v > _f.depth * 0.7) _deep++;
            if (_v > _max) _max = _v;
        }
    }
    array_sort(_vals, true);
    var _len = array_length(_vals);
    var _q90 = (_len > 0) ? _vals[min(_len - 1, floor(0.9 * (_len - 1)))] : 0;
    var _q10 = (_len > 0) ? _vals[min(_len - 1, floor(0.1 * (_len - 1)))] : 0;
    _r.mean = (_n > 0) ? _sum / _n : 0;
    _r.touched = (_n > 0) ? _touched / _n : 0;
    _r.covered = (_n > 0) ? _covered / _n : 0;
    _r.deep = (_n > 0) ? _deep / _n : 0;
    _r.spread = (_f.depth != 0) ? (_q90 - _q10) / _f.depth : 0;
    _r.max = _max; _r.samples = _n;
    math_set_epsilon(_eps);
    return _r;
}
