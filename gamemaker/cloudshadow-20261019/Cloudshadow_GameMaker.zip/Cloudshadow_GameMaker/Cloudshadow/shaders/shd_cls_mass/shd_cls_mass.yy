{
  "$GMShader": "",
  "%Name": "shd_cls_mass",
  "name": "shd_cls_mass",
  "parent": {
    "name": "Shaders",
    "path": "folders/Shaders.yy"
  },
  "resourceType": "GMShader",
  "resourceVersion": "2.0",
  "type": 1
}