//
// shd_cls_mass (fragment) - Cloudshadow's sheet bake: ONE cloud mass, written into ONE altitude channel, added to what
// the sheet already holds. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
//
// This is cls_shade_at_field (cls_core.gml) for one mass, line for line: the normalised elliptical distance, pushed in
// and out by three octaves of lattice turbulence (the ragged rim), a soft edge across `edge` of the radius, smoothstepped.
// The sheet's blend is ADDITIVE, so the masses of a layer sum and the 8-bit target saturates at 1.0 - exactly the
// core's `a = min(acc, 1)`. The self-test reads the baked sheet back and holds it to the CPU field (cls_selftest).
//
// The lattice VALUES come from a table texture written by GML from the MZ edition's integer hash (GLSL ES 1.00 has no
// integer arithmetic to run it): R = the L-cell octave, G = 2L, B = 4L. They are read at exact texel centres with point
// sampling, and the smoothstep interpolation between them is done HERE, so the only difference from the CPU field is
// the table's 8-bit rounding of each lattice value (MEASURED by the suite, not assumed).
// ⛔ No loops: GameMaker's shader compiler unrolls loops round texture reads (gm-taproom measured a 5.8-minute asset
// compile from one), so the three octaves and four corners are written out.
//
precision highp float;

varying vec2 v_vTexcoord;   // the FIELD point of this fragment, in cloud units (0 .. u_field)
varying vec4 v_vColour;

uniform vec4 u_mass;        // the mass: centre x, centre y (already shifted for this wrap copy), rx, ry
uniform vec4 u_shape;       // edge, weight k, lump, unused
uniform vec4 u_chan;        // the channel this mass's altitude writes: (1,0,0,0) low, (0,1,0,0) mid, (0,0,1,0) high
uniform vec4 u_lat;         // the lattice table: u0, v0 of texel (0, 0)'s corner, and the size of one texel in u and v
uniform float u_field;      // the field size in cloud units (64)
uniform float u_L;          // the lattice cells across the field (18)

float lat_r(vec2 c) { return texture2D(gm_BaseTexture, vec2(u_lat.x + (c.x + 0.5) * u_lat.z, u_lat.y + (c.y + 0.5) * u_lat.w)).r; }
float lat_g(vec2 c) { return texture2D(gm_BaseTexture, vec2(u_lat.x + (c.x + 0.5) * u_lat.z, u_lat.y + (c.y + 0.5) * u_lat.w)).g; }
float lat_b(vec2 c) { return texture2D(gm_BaseTexture, vec2(u_lat.x + (c.x + 0.5) * u_lat.z, u_lat.y + (c.y + 0.5) * u_lat.w)).b; }

// the cell index wrapped onto the lattice, as cls_lattice_value does ((i mod L) + L) mod L
vec2 wrapc(vec2 c, float L) { return mod(mod(c, L) + L, L); }

float vn_r(float L, vec2 p) {
    vec2 i0 = floor(p); vec2 f = p - i0; vec2 s = f * f * (3.0 - 2.0 * f);
    float n00 = lat_r(wrapc(i0, L)); float n10 = lat_r(wrapc(i0 + vec2(1.0, 0.0), L));
    float n01 = lat_r(wrapc(i0 + vec2(0.0, 1.0), L)); float n11 = lat_r(wrapc(i0 + vec2(1.0, 1.0), L));
    return (n00 * (1.0 - s.x) + n10 * s.x) * (1.0 - s.y) + (n01 * (1.0 - s.x) + n11 * s.x) * s.y;
}
float vn_g(float L, vec2 p) {
    vec2 i0 = floor(p); vec2 f = p - i0; vec2 s = f * f * (3.0 - 2.0 * f);
    float n00 = lat_g(wrapc(i0, L)); float n10 = lat_g(wrapc(i0 + vec2(1.0, 0.0), L));
    float n01 = lat_g(wrapc(i0 + vec2(0.0, 1.0), L)); float n11 = lat_g(wrapc(i0 + vec2(1.0, 1.0), L));
    return (n00 * (1.0 - s.x) + n10 * s.x) * (1.0 - s.y) + (n01 * (1.0 - s.x) + n11 * s.x) * s.y;
}
float vn_b(float L, vec2 p) {
    vec2 i0 = floor(p); vec2 f = p - i0; vec2 s = f * f * (3.0 - 2.0 * f);
    float n00 = lat_b(wrapc(i0, L)); float n10 = lat_b(wrapc(i0 + vec2(1.0, 0.0), L));
    float n01 = lat_b(wrapc(i0 + vec2(0.0, 1.0), L)); float n11 = lat_b(wrapc(i0 + vec2(1.0, 1.0), L));
    return (n00 * (1.0 - s.x) + n10 * s.x) * (1.0 - s.y) + (n01 * (1.0 - s.x) + n11 * s.x) * s.y;
}

void main()
{
    vec2 p = v_vTexcoord;
    float lump = 0.0;
    if (u_shape.z != 0.0) {
        vec2 u = mod(p, u_field) / u_field * u_L;
        float t = (vn_r(u_L, u) * 0.5 + vn_g(u_L * 2.0, u * 2.0) * 0.33 + vn_b(u_L * 4.0, u * 4.0) * 0.17) - 0.5;
        lump = t * u_shape.z;
    }
    vec2 dd = p - u_mass.xy;
    // ⛔ ONLY THE NEAREST COPY: the field wraps, and cls_shade_at_field measures every mass by its SHORTEST distance on
    // the torus (|dx|, |dy| <= half the field). A mass wider than half the field (veil, overcast) would otherwise be
    // summed from two copies where the core counts one - MEASURED: 117/255 on veil before this line.
    if (abs(dd.x) > u_field * 0.5 || abs(dd.y) > u_field * 0.5) { gl_FragColor = vec4(0.0); return; }
    float d = sqrt((dd.x * dd.x) / (u_mass.z * u_mass.z) + (dd.y * dd.y) / (u_mass.w * u_mass.w)) + lump;
    float v = 0.0;
    if (d < 1.0) {
        float inner = 1.0 - u_shape.x;
        v = (d <= inner) ? 1.0 : 1.0 - (d - inner) / max(u_shape.x, 0.000001);
        v = clamp(v, 0.0, 1.0);
        v = u_shape.y * (v * v * (3.0 - 2.0 * v));
    }
    gl_FragColor = vec4(u_chan.rgb * v, 0.0);
}
