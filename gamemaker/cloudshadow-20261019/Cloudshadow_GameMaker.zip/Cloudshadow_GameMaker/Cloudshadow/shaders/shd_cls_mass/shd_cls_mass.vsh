//
// shd_cls_mass (vertex) - Cloudshadow's sheet bake. Copyright (c) 2026 Core Systems Asset Factory.
// Passes each corner's FIELD point (cloud units, sent as the texture coordinate) through to the fragment shader, which
// draws one cloud mass at that point. The bound texture is the lattice table (cls__lattice_surface), read by the
// fragment shader at exact texel centres - never by this coordinate.
//
attribute vec3 in_Position;
attribute vec4 in_Colour;
attribute vec2 in_TextureCoord;

varying vec2 v_vTexcoord;
varying vec4 v_vColour;

void main()
{
    vec4 object_space_pos = vec4(in_Position.x, in_Position.y, in_Position.z, 1.0);
    gl_Position = gm_Matrices[MATRIX_WORLD_VIEW_PROJECTION] * object_space_pos;
    v_vColour = in_Colour;
    v_vTexcoord = in_TextureCoord;
}
