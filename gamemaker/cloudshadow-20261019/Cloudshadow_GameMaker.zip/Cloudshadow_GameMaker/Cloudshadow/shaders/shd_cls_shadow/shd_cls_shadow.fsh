//
// shd_cls_shadow (fragment) - Cloudshadow's shadow overlay: how much light each room pixel has lost to the clouds,
// written as a MULTIPLIER and drawn with a multiply blend (cls_draw), so it darkens whatever the game drew beneath it
// without replacing a pixel. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
//
// The RPG Maker MZ edition's filter, line for line where it can be, with three GameMaker-side changes, each deliberate:
//   1. The sheet is ORIENTED along the room's wind (u_rot.xy), so a wind-drawn cloud is drawn out along the wind it
//      travels with; the MZ sheet stays axis-aligned whatever the wind.
//   2. A sky change CROSSFADES two baked sheets (gm_BaseTexture = the new sky, u_sheetb = the old), so nothing pops; the
//      MZ edition swaps the sheet and fades only the layer weights.
//   3. Rooms do not loop, so the surface map's edge repeats instead of wrapping.
// cls_shade_at (cls_cloudshadow.gml) is this file's CPU twin: same steps, same order, exact field values. The self-test
// reads the overlay back and holds it to that twin.
//
precision highp float;

varying vec2 v_vTexcoord;   // the ROOM point of this fragment, in pixels
varying vec4 v_vColour;

uniform sampler2D u_surface; // the surface map: R response, G altitude / 3, B coolness, A open to the sky; 1-cell ring
uniform sampler2D u_sheetb;  // the sky being left (the same sheet as gm_BaseTexture when no change is under way)
uniform vec4 u_map;          // cell width px, cell height px, columns, rows
uniform vec4 u_mapuv;        // the map texture's uv rect: u0, v0, u1, v1
uniform vec4 u_cloud;        // sheet repeats per cell, origin u, origin v, altitude shift in cells
uniform vec4 u_rot;          // the sheet's orientation (cos, sin) in the room, and the current wind direction (x, y)
uniform vec2 u_off0;         // each altitude's scroll, in sheet uv
uniform vec2 u_off1;
uniform vec2 u_off2;
uniform vec3 u_mixa;         // which channels the new sky uses
uniform vec3 u_basea;        // the new sky's base sheet per channel (0 where it has none)
uniform vec3 u_mixb;         // the same for the sky being left
uniform vec3 u_baseb;
uniform vec4 u_depth;        // new depth, old depth, blend 0..1 (1 = all new), intensity x daylight
uniform vec4 u_cool;         // the skylight cast (normalised to mean 1), and the project-wide coolness scale
uniform float u_maxshade;    // the deepest a shadow may ever go (CLS_MAX_SHADE)

void main()
{
    highp vec2 cell = v_vTexcoord / u_map.xy;
    highp vec2 cl = clamp(cell, vec2(0.0), u_map.zw - vec2(0.001));
    highp vec2 suv = mix(u_mapuv.xy, u_mapuv.zw, (cl + vec2(1.0)) / (u_map.zw + vec2(2.0)));
    vec4 surf = texture2D(u_surface, suv);
    float response = surf.r;
    float altitude = surf.g * 3.0;
    float coolness = surf.b;
    float sky = surf.a;
    // a surface up in the air meets the cloud before the ground beside it: it samples UPWIND of itself
    highp vec2 lifted = cell - u_rot.zw * (altitude * u_cloud.w);
    highp vec2 r = vec2(lifted.x * u_rot.x + lifted.y * u_rot.y, -lifted.x * u_rot.y + lifted.y * u_rot.x);
    highp vec2 cuv = r * u_cloud.x + u_cloud.yz;
    vec3 ca = vec3(texture2D(gm_BaseTexture, cuv - u_off0).r, texture2D(gm_BaseTexture, cuv - u_off1).g, texture2D(gm_BaseTexture, cuv - u_off2).b);
    vec3 cb = vec3(texture2D(u_sheetb, cuv - u_off0).r, texture2D(u_sheetb, cuv - u_off1).g, texture2D(u_sheetb, cuv - u_off2).b);
    ca = u_basea + ca * (vec3(1.0) - u_basea);
    cb = u_baseb + cb * (vec3(1.0) - u_baseb);
    float cloudA = min(1.0, dot(ca, u_mixa));
    float cloudB = min(1.0, dot(cb, u_mixb));
    float shade = mix(cloudB * u_depth.y, cloudA * u_depth.x, u_depth.z);
    // the ceiling is enforced HERE, where the shade is computed (a cloud takes the sun, never all the light)
    shade = min(shade * response * sky * u_depth.w, u_maxshade);
    // a cool cast is an ATTENUATION of the warm component (u_cool is normalised to mean 1, so it changes hue, not level)
    vec3 cool = mix(vec3(1.0), u_cool.rgb, clamp(shade * coolness * u_cool.a, 0.0, 1.0));
    gl_FragColor = vec4((1.0 - shade) * cool, 1.0);
}
