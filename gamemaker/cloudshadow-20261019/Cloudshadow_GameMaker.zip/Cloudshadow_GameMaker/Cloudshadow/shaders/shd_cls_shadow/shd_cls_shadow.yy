{
  "$GMShader": "",
  "%Name": "shd_cls_shadow",
  "name": "shd_cls_shadow",
  "parent": {
    "name": "Shaders",
    "path": "folders/Shaders.yy"
  },
  "resourceType": "GMShader",
  "resourceVersion": "2.0",
  "type": 1
}