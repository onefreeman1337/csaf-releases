//
// shd_cls_shadow (vertex) - Cloudshadow's shadow overlay. Copyright (c) 2026 Core Systems Asset Factory.
// The overlay is one quad over the view, drawn in ROOM coordinates; each corner's room point is sent as the texture
// coordinate and passed through, so the fragment shader knows which room pixel it is lighting.
//
attribute vec3 in_Position;
attribute vec4 in_Colour;
attribute vec2 in_TextureCoord;

varying vec2 v_vTexcoord;
varying vec4 v_vColour;

void main()
{
    vec4 object_space_pos = vec4(in_Position.x, in_Position.y, in_Position.z, 1.0);
    gl_Position = gm_Matrices[MATRIX_WORLD_VIEW_PROJECTION] * object_space_pos;
    v_vColour = in_Colour;
    v_vTexcoord = in_TextureCoord;
}
