{
  "$GMSprite": "v2",
  "%Name": "spr_cls_marks",
  "bboxMode": 1,
  "bbox_bottom": 23,
  "bbox_left": 0,
  "bbox_right": 119,
  "bbox_top": 0,
  "collisionKind": 1,
  "collisionTolerance": 0,
  "DynamicTexturePage": false,
  "edgeFiltering": false,
  "For3D": false,
  "frames": [
    {
      "$GMSpriteFrame": "v1",
      "%Name": "c51fcb22-44e4-72fd-327a-b591506dd190",
      "name": "c51fcb22-44e4-72fd-327a-b591506dd190",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    }
  ],
  "gridX": 0,
  "gridY": 0,
  "height": 24,
  "HTile": false,
  "layers": [
    {
      "$GMImageLayer": "",
      "%Name": "07cf2c31-d051-b511-443b-e2e8c472f8f0",
      "blendMode": 0,
      "displayName": "default",
      "isLocked": false,
      "name": "07cf2c31-d051-b511-443b-e2e8c472f8f0",
      "opacity": 100,
      "resourceType": "GMImageLayer",
      "resourceVersion": "2.0",
      "visible": true
    }
  ],
  "name": "spr_cls_marks",
  "nineSlice": null,
  "origin": 0,
  "parent": {
    "name": "Sprites",
    "path": "folders/Sprites.yy"
  },
  "preMultiplyAlpha": false,
  "resourceType": "GMSprite",
  "resourceVersion": "2.0",
  "sequence": {
    "$GMSequence": "v1",
    "%Name": "spr_cls_marks",
    "autoRecord": true,
    "backdropHeight": 768,
    "backdropImageOpacity": 0.5,
    "backdropImagePath": "",
    "backdropWidth": 1366,
    "backdropXOffset": 0,
    "backdropYOffset": 0,
    "events": {
      "$KeyframeStore<MessageEventKeyframe>": "",
      "Keyframes": [],
      "resourceType": "KeyframeStore<MessageEventKeyframe>",
      "resourceVersion": "2.0"
    },
    "eventStubScript": null,
    "eventToFunction": {},
    "length": 1,
    "lockOrigin": false,
    "moments": {
      "$KeyframeStore<MomentsEventKeyframe>": "",
      "Keyframes": [],
      "resourceType": "KeyframeStore<MomentsEventKeyframe>",
      "resourceVersion": "2.0"
    },
    "name": "spr_cls_marks",
    "playback": 1,
    "playbackSpeed": 30,
    "playbackSpeedType": 0,
    "resourceType": "GMSequence",
    "resourceVersion": "2.0",
    "showBackdrop": true,
    "showBackdropImage": false,
    "timeUnits": 1,
    "tracks": [
      {
        "$GMSpriteFramesTrack": "",
        "builtinName": 0,
        "events": [],
        "inheritsTrackColour": true,
        "interpolation": 1,
        "isCreationTrack": false,
        "keyframes": {
          "$KeyframeStore<SpriteFrameKeyframe>": "",
          "Keyframes": [
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "c51fcb22-44e4-72fd-327a-b591506dd190",
                    "path": "sprites/spr_cls_marks/spr_cls_marks.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "7018dc95-e2f1-aa75-ee58-6b3ebf6c7d6f",
              "IsCreationKey": false,
              "Key": 0,
              "Length": 1,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            }
          ],
          "resourceType": "KeyframeStore<SpriteFrameKeyframe>",
          "resourceVersion": "2.0"
        },
        "modifiers": [],
        "name": "frames",
        "resourceType": "GMSpriteFramesTrack",
        "resourceVersion": "2.0",
        "spriteId": null,
        "trackColour": 0,
        "tracks": [],
        "traits": 0
      }
    ],
    "visibleRange": null,
    "volume": 1,
    "xorigin": 0,
    "yorigin": 0
  },
  "swatchColours": null,
  "swfPrecision": 0.5,
  "textureGroupId": {
    "name": "Default",
    "path": "texturegroups/Default"
  },
  "type": 0,
  "VTile": false,
  "width": 120
}