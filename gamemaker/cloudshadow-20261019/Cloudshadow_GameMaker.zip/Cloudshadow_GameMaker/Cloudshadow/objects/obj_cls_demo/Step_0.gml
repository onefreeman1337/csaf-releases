/// @description The demo's keys (see cls_demo).
cls_demo_step(demo);
