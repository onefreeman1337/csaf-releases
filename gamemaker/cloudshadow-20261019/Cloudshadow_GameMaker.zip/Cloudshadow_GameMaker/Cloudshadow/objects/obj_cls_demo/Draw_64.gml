/// @description The demo's panel (see cls_demo).
cls_demo_draw_gui(demo);
