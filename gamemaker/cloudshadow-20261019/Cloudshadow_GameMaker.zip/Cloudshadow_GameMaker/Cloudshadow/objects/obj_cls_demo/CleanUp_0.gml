/// @description Nothing of the demo's own to free: Cloudshadow frees itself in obj_cls_shadow's Clean Up.
demo = undefined;
