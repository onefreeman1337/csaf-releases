/// @description Cloudshadow: start the weather in this room. Place this object on a layer ABOVE everything the cloud
/// shadows should fall on (ground, tiles, characters) and BELOW what they should not (sky effects, the HUD).
/// To configure it, call the cls_* functions after it is created (see the Readme), or replace this with your own
/// cls_start({ ... }) call.
cls_start();
