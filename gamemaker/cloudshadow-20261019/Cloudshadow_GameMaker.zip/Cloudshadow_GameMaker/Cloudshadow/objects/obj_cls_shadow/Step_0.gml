/// @description Cloudshadow: advance the clouds one step.
cls_update();
