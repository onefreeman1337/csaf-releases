/// @description Cloudshadow: free every surface and buffer; the clouds' place is remembered for the next room.
cls_stop();
