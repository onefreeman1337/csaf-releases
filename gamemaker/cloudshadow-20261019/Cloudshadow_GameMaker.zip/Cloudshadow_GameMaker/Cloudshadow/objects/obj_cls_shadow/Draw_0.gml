/// @description Cloudshadow: darken everything drawn below this layer by the light the clouds take. One quad.
cls_draw();
