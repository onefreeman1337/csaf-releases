{
  "$GMObject": "",
  "%Name": "obj_cls_marker",
  "eventList": [],
  "managed": true,
  "name": "obj_cls_marker",
  "overriddenProperties": [],
  "parent": {
    "name": "Objects",
    "path": "folders/Objects.yy"
  },
  "parentObjectId": null,
  "persistent": false,
  "physicsAngularDamping": 0.1,
  "physicsDensity": 0.5,
  "physicsFriction": 0.2,
  "physicsGroup": 1,
  "physicsKinematic": false,
  "physicsLinearDamping": 0.1,
  "physicsObject": false,
  "physicsRestitution": 0.1,
  "physicsSensor": false,
  "physicsShape": 1,
  "physicsShapePoints": [],
  "physicsStartAwake": true,
  "properties": [],
  "resourceType": "GMObject",
  "resourceVersion": "2.0",
  "solid": false,
  "spriteId": {
    "name": "spr_cls_marks",
    "path": "sprites/spr_cls_marks/spr_cls_marks.yy"
  },
  "spriteMaskId": null,
  "visible": false
}