/// fol_selftest.gml - Folio's in-engine test suite. Run the demo with -selftest: the result is written as fol_selftest.json in the game's save folder and the renders (fol_render_*.png) beside it, to be LOOKED at.
/// Stages: the generator; guards and the catalogue; pagination with a fixed-width measure (every line inside its box, justified lines full, no paragraph of four lines or more leaves one line alone, short paragraphs whole, headings kept with their lines, drop initials, long words); pagination with the real fonts; the leaf's geometry over random drags (the spine never lifts, the corner lands where it was carried, the pieces add up to the page, a full turn is a mirror); the turn state machine fed plain numbers (click, drag past the spine, drag short of it, a flick, the left side, hover, queue, goto, tabs); the papers (48, distinct pairwise, torn edges torn, cut edges cut); page composition (ink where text is, no white boxes, no holes); the book drawn at rest and mid-turn (the leaf shows both faces, the caller's matrix and blend come back); resources; renders.
///
/// Folio - A Page-Turning Book for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function fol_st_assert(state, condition, message)
/// @description Count one assertion; keep the first 80 failure messages.
function fol_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 80) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
/// @function fol_st_stage(state, n)
/// @description Record the stage reached (the crash handler reports it).
function fol_st_stage(_st, _n) { _st.stage = _n; global.fol_stage = _n; }
/// @function fol__st_read(surface)
/// @description Internal. A surface read into a buffer (R, G, B, A bytes, the whole surface).
function fol__st_read(_surf) {
    var _w = surface_get_width(_surf), _h = surface_get_height(_surf), _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _surf, 0);
    return { buf: _b, w: _w, h: _h };
}
/// @function fol__st_px(read, x, y)
/// @description Internal. One pixel as [r, g, b, a].
function fol__st_px(_rd, _x, _y) {
    var _o = (clamp(floor(_y), 0, _rd.h - 1) * _rd.w + clamp(floor(_x), 0, _rd.w - 1)) * 4;
    return [buffer_peek(_rd.buf, _o, buffer_u8), buffer_peek(_rd.buf, _o + 1, buffer_u8), buffer_peek(_rd.buf, _o + 2, buffer_u8), buffer_peek(_rd.buf, _o + 3, buffer_u8)];
}
/// @function fol__st_far(read, x0, y0, x1, y1, ref, tol)
/// @description Internal. Pixels in a box whose colour is more than tol from a reference [r, g, b] (any channel), x step 1, y step 1.
function fol__st_far(_rd, _x0, _y0, _x1, _y1, _ref, _tol) {
    var _n = 0;
    for (var _y = max(0, floor(_y0)); _y < min(_rd.h, _y1); _y++) for (var _x = max(0, floor(_x0)); _x < min(_rd.w, _x1); _x++) {
        var _o = (_y * _rd.w + _x) * 4;
        if (abs(buffer_peek(_rd.buf, _o, buffer_u8) - _ref[0]) > _tol || abs(buffer_peek(_rd.buf, _o + 1, buffer_u8) - _ref[1]) > _tol || abs(buffer_peek(_rd.buf, _o + 2, buffer_u8) - _ref[2]) > _tol) _n++;
    }
    return _n;
}
/// @function fol__st_grid(read, nx, ny)
/// @description Internal. A coarse per-channel signature: R, G, B, A cell means.
function fol__st_grid(_rd, _nx, _ny) {
    var _o = array_create(_nx * _ny * 4, 0);
    for (var _gy = 0; _gy < _ny; _gy++) for (var _gx = 0; _gx < _nx; _gx++) {
        var _x0 = floor(_gx * _rd.w / _nx), _x1 = floor((_gx + 1) * _rd.w / _nx), _y0 = floor(_gy * _rd.h / _ny), _y1 = floor((_gy + 1) * _rd.h / _ny), _s = [0, 0, 0, 0], _c = 0;
        for (var _y = _y0; _y < _y1; _y++) for (var _x = _x0; _x < _x1; _x++) {
            var _p = (_y * _rd.w + _x) * 4;
            _s[0] += buffer_peek(_rd.buf, _p, buffer_u8); _s[1] += buffer_peek(_rd.buf, _p + 1, buffer_u8); _s[2] += buffer_peek(_rd.buf, _p + 2, buffer_u8); _s[3] += buffer_peek(_rd.buf, _p + 3, buffer_u8); _c++;
        }
        var _i = (_gy * _nx + _gx) * 4;
        for (var _q = 0; _q < 4; _q++) _o[_i + _q] = real(_s[_q]) / max(1, _c);
    }
    return _o;
}
/// @function fol__st_diff(a, b)
/// @description Internal. Mean absolute difference of two signatures.
function fol__st_diff(_a, _b) { var _n = min(array_length(_a), array_length(_b)), _s = 0; for (var _i = 0; _i < _n; _i++) _s += abs(_a[_i] - _b[_i]); return _s / max(1, _n); }
/// @function fol__st_run(book, frames)
/// @description Internal. Step a book until nothing moves (or frames run out); returns frames used.
function fol__st_run(_b, _max = 400) { var _f = 0; while ((is_struct(_b.leaf) || _b.queue != 0) && _f < _max) { fol_book_step(_b, 1 / 60); _f++; } return _f; }
/// @function fol__st_words(gen, n)
/// @description Internal. n pseudo-words of 2..11 letters.
function fol__st_words(_g, _n) {
    var _s = "";
    for (var _i = 0; _i < _n; _i++) { var _l = 2 + floor(fol_rand(_g) * 10), _w = ""; repeat (_l) _w += chr(97 + floor(fol_rand(_g) * 26)); _s += ((_i > 0) ? " " : "") + _w; }
    return _s;
}
/// @function fol__st_fixed_book(seed, opts)
/// @description Internal. A book measured at 9 px a character, filled with seeded chapters, headings, paragraphs of every length, a picture slot (custom) and a break.
function fol__st_fixed_book(_seed, _paper = 0) {
    var _b = fol_book_create({ page_w: 400, page_h: 540, paper: _paper, measure: function(_s, _st) { return string_length(_s) * 9; } });
    var _g = fol_rng(_seed);
    for (var _c = 0; _c < 4; _c++) {
        fol_book_chapter(_b, "Chapter " + string(_c + 1) + " " + fol__st_words(_g, 2), { recto: (_c == 2) });
        for (var _p = 0; _p < 7; _p++) {
            if (_p == 3) fol_book_heading(_b, fol__st_words(_g, 3));
            fol_book_text(_b, fol__st_words(_g, 4 + floor(fol_rand(_g) * 90)));
        }
        if (_c == 1) fol_book_custom(_b, 120, function(_x, _y, _w, _h, _p) { });
        if (_c == 3) { fol_book_break(_b); fol_book_text(_b, fol__st_words(_g, 30)); }
    }
    return _b;
}

/// @function fol_selftest_run()
/// @description Run every stage; returns the state written by fol_selftest_write.
function fol_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, failures: [], stage: 0, notes: {}, timings: {} };
    _st.notes.epsilon = string_format(math_get_epsilon(), 1, 12);

    // ------------------------------------------------------------ 10: the generator
    fol_st_stage(_st, 10);
    var _g1 = fol_rng(42), _g2 = fol_rng(42), _same = true;
    repeat (50) if (fol_rand(_g1) != fol_rand(_g2)) _same = false;
    fol_st_assert(_st, _same, "the same seed draws the same sequence");
    var _lo = 1, _hi = 0;
    for (var _s = 0; _s < 400; _s++) { var _v = fol_rand(fol_rng(1000 + _s)); _lo = min(_lo, _v); _hi = max(_hi, _v); }
    fol_st_assert(_st, _lo < 0.05 && _hi > 0.95, "first draws over 400 NEARBY seeds span [0,1): " + string(_lo) + ".." + string(_hi));

    // ------------------------------------------------------------ 20: guards and the catalogue
    fol_st_stage(_st, 20);
    var _d0 = fol_book_create();
    fol_st_assert(_st, fol__is_book(_d0) && _d0.pw == 460 && _d0.ph == 620, "a book with no options takes the defaults");
    fol_st_assert(_st, fol_book_create({ page_w: -5 }).pw == 120 && fol_book_create({ page_w: "wide" }).pw == 460 && fol_book_create({ page_h: 99999 }).ph == 2048, "page sizes are clamped and a string is refused for a number");
    fol_st_assert(_st, !fol_book_text(undefined, "x") && !fol_book_chapter(123, "x") && !fol_book_heading("book", "x") && !fol_book_space({}, 4) && !fol_book_break(-1), "not a book: every adder refuses");
    fol_st_assert(_st, !fol_book_picture(_d0, -1) && !fol_book_picture(_d0, "nope") && !fol_book_picture(_d0, undefined), "a picture that is not a sprite is refused");
    fol_st_assert(_st, !fol_book_custom(_d0, 10, 5) && !fol_book_custom(_d0, 10, "draw"), "a custom block without a function is refused");
    fol_st_assert(_st, fol_book_pages(_d0) == 1 && fol_book_spreads(_d0) == 1, "an empty book has one page and one spread");
    fol_st_assert(_st, !fol_book_goto(_d0, 99) && !fol_book_goto(_d0, -3) && !fol_book_goto(_d0, "x"), "goto refuses a page that does not exist");
    fol_st_assert(_st, !fol_book_ribbon(_d0, 7, 0) && !fol_book_ribbon(_d0, -1, 0) && fol_book_ribbon(_d0, 2, 0), "ribbons 0..2 only");
    fol_st_assert(_st, !fol_book_next(_d0) && !fol_book_prev(_d0), "a one-spread book has nowhere to turn");
    fol_st_assert(_st, is_undefined(fol_book_hit(_d0, "x", 3)) && is_undefined(fol_book_hit(undefined, 1, 1)) && !fol_book_feed(_d0, 7) && !fol_book_draw("book", 0, 0), "hit, feed and draw refuse what is not theirs");
    fol_st_assert(_st, fol_paper_count() == 48, "48 paper looks: " + string(fol_paper_count()));
    _st.notes.looks = fol_paper_count();
    var _names = {}, _dupe = "", _pairs = {};
    for (var _i = 0; _i < fol_paper_count(); _i++) {
        var _lk = fol_paper_look(_i), _nm = string_lower(_lk.name), _pk = _lk.stock + "/" + _lk.ruling;
        if (variable_struct_exists(_names, _nm)) _dupe += _lk.name + " ";
        if (variable_struct_exists(_pairs, _pk)) _dupe += _pk + " ";
        _names[$ _nm] = true; _pairs[$ _pk] = true;
    }
    fol_st_assert(_st, _dupe == "", "every look has its own name and its own stock x ruling: " + _dupe);
    fol_st_assert(_st, array_length(variable_struct_get_names(_pairs)) == 48, "the 48 looks cover 8 stocks x 6 rulings exactly");
    fol_st_assert(_st, fol_paper_find("bestiary") == fol_paper_find("Bestiary") && fol_paper_find(" B E S T I A R Y ") >= 0 && fol_paper_find("no such paper") == -1 && fol_paper_find(48) == -1 && fol_paper_find(-1) == -1 && fol_paper_name(99) == "", "looks found by name or index; nothing else");
    fol_st_assert(_st, !fol_book_set_paper(_d0, "zzz") && fol_book_set_paper(_d0, "Grimoire") && fol_paper_name(_d0.paper) == "Grimoire", "set_paper takes a name and refuses an unknown one");
    fol_st_assert(_st, fol_folio_text(fol_book_create({ roman: true }), 13) == "xiv" && fol_folio_text(fol_book_create(), 13) == "14", "page 13 prints as 14, or xiv in roman");

    // ------------------------------------------------------------ 30: pagination, fixed measure
    fol_st_stage(_st, 30);
    var _t0 = get_timer();
    var _fb = fol__st_fixed_book(7);
    var _np = fol_book_paginate(_fb);
    _st.timings.paginate_fixed_ms = (get_timer() - _t0) / 1000;
    fol_st_assert(_st, _np >= 10, "the fixture flows onto many pages: " + string(_np));
    var _bad_box = 0, _bad_just = 0, _lines = 0, _just = 0, _bad_y = 0, _first_bad = "";
    var _para = {}; // paragraph -> { n, pages: { page: count } }
    for (var _p = 0; _p < _np; _p++) {
        var _P = _fb.pages[_p], _m = fol_book_metrics(_fb, _p);
        for (var _i = 0; _i < array_length(_P.items); _i++) {
            var _it = _P.items[_i];
            if (_it.k != "line") continue;
            _lines++;
            var _last = array_length(_it.ws) - 1, _end = _it.xs[_last] + string_length(_it.ws[_last]) * 9;
            if (_it.x < _m.x - 0.01 || _end > _m.x + _m.w + 0.5) { _bad_box++; if (_first_bad == "") _first_bad = "page " + string(_p) + " line ends at " + string(_end) + " of " + string(_m.x + _m.w); }
            if (_it.y < _m.y - 0.01 || _it.y + _m.pitch > _m.bottom + 0.5) _bad_y++;
            if (_it.i < _it.n - 1 && _last > 0) { _just++; if (abs(_end - (_m.x + _m.w)) > 1.5 && (_it.xs[1] - _it.xs[0] - string_length(_it.ws[0]) * 9) < 9 * 3.19) _bad_just++; }
            var _k = string(_it.p);
            if (!variable_struct_exists(_para, _k)) _para[$ _k] = { n: _it.n, pages: {} };
            var _pk = string(_p);
            _para[$ _k].pages[$ _pk] = (variable_struct_exists(_para[$ _k].pages, _pk) ? _para[$ _k].pages[$ _pk] : 0) + 1;
        }
    }
    fol_st_assert(_st, _lines > 300, "the fixture sets hundreds of lines: " + string(_lines));
    fol_st_assert(_st, _bad_box == 0, "every line inside its text box: " + string(_bad_box) + " outside (" + _first_bad + ")");
    fol_st_assert(_st, _bad_y == 0, "every line inside the page's lines: " + string(_bad_y));
    fol_st_assert(_st, _just > 100 && _bad_just == 0, "justified lines reach the right margin: " + string(_bad_just) + " of " + string(_just) + " short");
    var _widow = 0, _split_short = 0, _split = 0, _keys = variable_struct_get_names(_para);
    for (var _i = 0; _i < array_length(_keys); _i++) {
        var _pr = _para[$ _keys[_i]], _pks = variable_struct_get_names(_pr.pages);
        if (array_length(_pks) > 1) {
            _split++;
            if (_pr.n <= 3) _split_short++;
            for (var _q = 0; _q < array_length(_pks); _q++) if (_pr.pages[$ _pks[_q]] < 2) _widow++;
        }
    }
    fol_st_assert(_st, _split > 5, "the fixture splits paragraphs across pages (vacuity guard): " + string(_split));
    fol_st_assert(_st, _widow == 0, "no paragraph leaves a single line alone on a page: " + string(_widow));
    fol_st_assert(_st, _split_short == 0, "a paragraph of three lines or fewer is never split: " + string(_split_short));
    var _head_bad = 0, _heads = 0, _drops = 0, _drop_bad = 0, _opens = 0, _recto_ok = true;
    for (var _p = 0; _p < _np; _p++) {
        var _P = _fb.pages[_p], _m = fol_book_metrics(_fb, _p);
        if (_P.opens) { _opens++; if (string_pos("Chapter 3", (array_length(_P.items) > 1) ? _P.items[1].str : "") > 0 && (_p mod 2) != 0) _recto_ok = false; }
        for (var _i = 0; _i < array_length(_P.items); _i++) {
            var _it = _P.items[_i];
            if (_it.k == "heading") {
                _heads++;
                var _after = 0;
                for (var _j = _i + 1; _j < array_length(_P.items); _j++) if (_P.items[_j].k == "line") _after++;
                if (_after < 2) _head_bad++;
            }
            if (_it.k == "drop") {
                _drops++;
                var _seen = 0;
                for (var _j = _i + 1; _j < array_length(_P.items) && _seen < 3; _j++) if (_P.items[_j].k == "line") { if (_P.items[_j].x < _m.x + _it.w - 0.01) _drop_bad++; _seen++; }
            }
        }
    }
    fol_st_assert(_st, _opens == 4 && _heads == 4, "four chapters open pages, four headings: " + string(_opens) + ", " + string(_heads));
    fol_st_assert(_st, _head_bad == 0, "every heading has at least two lines after it on its page: " + string(_head_bad));
    fol_st_assert(_st, _drops == 4 && _drop_bad == 0, "four drop initials, the three lines beside each indented past it: " + string(_drops) + " / " + string(_drop_bad));
    fol_st_assert(_st, _recto_ok, "a chapter asked to start on a right-hand page does");
    fol_st_assert(_st, array_length(fol_book_sections(_fb)) == 4, "four thumb tabs");
    var _np2 = fol_book_paginate(_fb), _same_items = true;
    for (var _p = 0; _p < min(_np, _np2); _p++) if (array_length(_fb.pages[_p].items) == 0 && _p < _np - 1 && !_fb.pages[_p].blank) _same_items = false;
    fol_st_assert(_st, _np2 == _np, "pagination is deterministic: " + string(_np) + " then " + string(_np2));
    fol_st_assert(_st, _same_items, "no empty page in the middle of the book unless it is the blank before a right-hand chapter");
    var _sp_ok = true;
    for (var _p = 0; _p < _np; _p++) { var _pp = fol_spread_pages(_fb, fol_page_spread(_p)); if (_pp[0] != _p && _pp[1] != _p) _sp_ok = false; }
    fol_st_assert(_st, _sp_ok && fol_book_spreads(_fb) == floor(_np / 2) + 1, "every page lies in the spread fol_page_spread names");
    var _lw = fol_book_create({ page_w: 300, page_h: 400, measure: function(_s, _st2) { return string_length(_s) * 9; } });
    fol_book_text(_lw, "a " + string_repeat("x", 120) + " b");
    fol_book_paginate(_lw);
    var _lw_ok = true, _lw_m = fol_book_metrics(_lw, 0), _lw_n = 0, _hy = 0;
    for (var _i = 0; _i < array_length(_lw.pages[0].items); _i++) { var _it = _lw.pages[0].items[_i]; if (_it.k == "line") { _lw_n++; if (_it.x + _it.w > _lw_m.x + _lw_m.w + 0.5) _lw_ok = false; var _lwd = _it.ws[array_length(_it.ws) - 1]; if (string_char_at(_lwd, string_length(_lwd)) == "-") _hy++; } }
    fol_st_assert(_st, _lw_ok && _lw_n >= 4, "a word wider than a line is broken by its letters, every piece inside: " + string(_lw_n) + " lines");
    fol_st_assert(_st, _hy >= 2, "each cut of a broken word ends in a hyphen: " + string(_hy));

    // ------------------------------------------------------------ 40: pagination, the real fonts
    fol_st_stage(_st, 40);
    var _rb = fol_book_create({ page_w: 420, page_h: 560, paper: "Bestiary", title: "A Field Guide to Paper" });
    fol_demo_fill(_rb);
    _t0 = get_timer();
    var _rn = fol_book_paginate(_rb);
    _st.timings.paginate_demo_ms = (get_timer() - _t0) / 1000;
    var _rbad = 0, _rl = 0, _rfirst = "";
    for (var _p = 0; _p < _rn; _p++) {
        var _P = _rb.pages[_p], _m = fol_book_metrics(_rb, _p);
        for (var _i = 0; _i < array_length(_P.items); _i++) {
            var _it = _P.items[_i];
            if (_it.k != "line") continue;
            _rl++;
            var _last = array_length(_it.ws) - 1, _end = _it.xs[_last] + fol__font_width(_it.ws[_last], "body", _rb.type_px);
            if (_end > _m.x + _m.w + 0.5 || _it.x < _m.x - 0.01) { _rbad++; if (_rfirst == "") _rfirst = "page " + string(_p) + " '" + _it.ws[_last] + "' ends " + string(_end) + " of " + string(_m.x + _m.w); }
        }
    }
    _st.notes.demo_pages = _rn;
    fol_st_assert(_st, _rn >= 10 && _rl > 100, "the demo book sets on real type: " + string(_rn) + " pages, " + string(_rl) + " lines");
    fol_st_assert(_st, _rbad == 0, "measured in the shipped font, every line ends inside its box: " + string(_rbad) + " (" + _rfirst + ")");

    // ------------------------------------------------------------ 50: the leaf's geometry
    fol_st_stage(_st, 50);
    var _pw = 400, _ph = 540;
    var _P0 = fol_leaf_pose(_pw, _ph, _ph, _pw, _ph);
    fol_st_assert(_st, _P0.flat, "a leaf at rest is flat");
    var _gg = fol_rng(99), _nan = 0, _lift = 0, _corner = 0, _area = 0, _poses = 0, _mixed = 0, _neg_r = 0;
    for (var _i = 0; _i < 2000; _i++) {
        var _gv = (fol_rand(_gg) < 0.5) ? _ph : fol_rand(_gg) * _ph, _gx = -_pw * 1.2 + fol_rand(_gg) * _pw * 2.4, _gy = -_ph * 0.3 + fol_rand(_gg) * _ph * 1.6;
        var _P = fol_leaf_pose(_pw, _ph, _gv, _gx, _gy, fol_rand(_gg));
        if (_P.flat) continue;
        _poses++;
        if (is_nan(_P.lx) || is_nan(_P.ly) || is_nan(_P.r) || is_nan(_P.nx)) { _nan++; continue; }
        if (_P.r < 0) _neg_r++;
        for (var _v = 0; _v <= _ph; _v += _ph / 8) { var _mm = fol_leaf_map(_P, 0, _v); if (abs(_mm[0]) > 0.01 || abs(_mm[1] - _v) > 0.01 || _mm[2] > 0.0001) _lift++; }
        var _mc = fol_leaf_map(_P, _pw, _gv);
        if (point_distance(_mc[0], _mc[1], _P.gx, _P.gy) > 0.5) _corner++;
        var _bands = fol_leaf_bands(_P, _pw, _ph, 12), _sum = 0, _f = false, _bk = false;
        for (var _q = 0; _q < array_length(_bands); _q++) { _sum += abs(fol__area(_bands[_q].pts)) * 0.5; if (_bands[_q].side > 0) _f = true; else _bk = true; if (_bands[_q].side > 0 && _bands[_q].a1 > pi * 0.5 + 0.001) _mixed++; if (_bands[_q].side < 0 && _bands[_q].a0 < pi * 0.5 - 0.001) _mixed++; }
        if (abs(_sum - _pw * _ph) > _pw * _ph * 0.002) _area++;
    }
    fol_st_assert(_st, _poses > 1500, "the sweep exercises curled poses: " + string(_poses));
    _st.notes.poses = _poses;
    fol_st_assert(_st, _nan == 0 && _neg_r == 0, "no pose is undefined or has a negative radius: " + string(_nan) + " / " + string(_neg_r));
    fol_st_assert(_st, _lift == 0, "the spine never lifts (nine points down it, every pose): " + string(_lift));
    fol_st_assert(_st, _corner == 0, "the grabbed point lands where it was carried: " + string(_corner) + " poses off");
    fol_st_assert(_st, _area == 0, "the pieces of the leaf add up to the page: " + string(_area) + " poses off");
    fol_st_assert(_st, _mixed == 0, "no piece shows both faces (cut at the quarter turn): " + string(_mixed));
    var _Pf = fol_leaf_pose(_pw, _ph, _ph, -_pw, _ph), _mir = 0;
    for (var _u = 0; _u <= _pw; _u += 40) for (var _v = 0; _v <= _ph; _v += 60) { var _mm = fol_leaf_map(_Pf, _u, _v); if (abs(_mm[0] + _u) > 0.6 || abs(_mm[1] - _v) > 0.6) _mir++; }
    fol_st_assert(_st, !_Pf.flat && _Pf.r < 0.001 && _mir == 0, "a finished turn lays the leaf flat on the other side, a mirror: " + string(_mir) + " off, r " + string(_Pf.r));
    var _Ph = fol_leaf_pose(_pw, _ph, _ph, _pw * 0.1, _ph * 0.8), _hb = fol_leaf_bands(_Ph, _pw, _ph, 12), _fr = 0, _bc = 0, _smax = 0, _smin = 2;
    for (var _q = 0; _q < array_length(_hb); _q++) {
        if (_hb[_q].side > 0) _fr++; else _bc++;
        for (var _a = _hb[_q].a0; _a <= _hb[_q].a1 + 0.0001; _a += max(0.01, (_hb[_q].a1 - _hb[_q].a0) * 0.5)) { var _sh = fol_leaf_shade(_Ph, _a, _hb[_q].side, 1); _smax = max(_smax, _sh); _smin = min(_smin, _sh); }
    }
    fol_st_assert(_st, _fr >= 2 && _bc >= 2 && _Ph.r > 3, "half way over, both faces show and the curl has a radius: " + string(_fr) + " front, " + string(_bc) + " back, r " + string(_Ph.r));
    fol_st_assert(_st, _smax > 1.02 && _smin < 0.9 && _smin >= 0.42 && _smax <= 1.18, "the curl catches the lamp and turns away from it: shade " + string(_smin) + ".." + string(_smax));
    fol_st_assert(_st, fol_leaf_shade(_Ph, 0, 1, 1) == 1, "flat paper is shade 1");

    // ------------------------------------------------------------ 60: the turn, fed plain numbers
    fol_st_stage(_st, 60);
    st_turns = 0;
    var _tb = fol_book_create({ page_w: 400, page_h: 540, measure: function(_s, _st2) { return string_length(_s) * 9; }, on_turn: function(_bb, _from, _to) { st_turns += 1; } });
    var _tg = fol_rng(5);
    for (var _c = 0; _c < 3; _c++) { fol_book_chapter(_tb, "Part " + string(_c + 1)); repeat (12) fol_book_text(_tb, fol__st_words(_tg, 60)); }
    var _tn = fol_book_spreads(_tb);
    fol_book_place(_tb, 0, 0, 1);
    fol_st_assert(_st, _tn >= 8, "the turning fixture has spreads to turn: " + string(_tn));
    fol_st_assert(_st, !fol_book_prev(_tb) && fol_book_next(_tb) && fol_book_turning(_tb), "from the first spread: no back, forward starts a leaf");
    var _fr2 = fol__st_run(_tb);
    fol_st_assert(_st, _tb.spread == 1 && !fol_book_turning(_tb) && _fr2 > 10 && _fr2 < 120, "one automatic turn lands on spread 1 in " + string(_fr2) + " frames");
    fol_st_assert(_st, st_turns == 1, "on_turn (written inside the options struct) reached the caller's variable once: " + string(st_turns));
    fol_book_next(_tb); fol_book_next(_tb); fol_book_next(_tb);
    fol__st_run(_tb, 800);
    fol_st_assert(_st, _tb.spread == 4 && st_turns == 4, "three presses queue three turns: spread " + string(_tb.spread));
    fol_book_goto(_tb, 1);
    fol__st_run(_tb, 800);
    fol_st_assert(_st, _tb.spread == fol_page_spread(1), "goto riffles back to page 1's spread: " + string(_tb.spread));
    fol_book_goto(_tb, fol_book_pages(_tb) - 1, true);
    fol_st_assert(_st, _tb.spread == _tn - 1 && !fol_book_next(_tb), "goto(instant) to the last page; nothing past it");
    fol_book_goto(_tb, 4, true);
    var _s0 = _tb.spread;
    // a drag from the lower corner of the right page across the spine, let go: it falls over
    var _cx0 = 2 * 400 - 2, _cy0 = 540 - 2;
    fol_book_feed(_tb, { mx: _cx0, my: _cy0, down: true, pressed: true });
    for (var _i = 1; _i <= 20; _i++) fol_book_feed(_tb, { mx: _cx0 - _i * 30, my: _cy0 - _i * 4, down: true });
    var _dragged = is_struct(_tb.leaf) && _tb.leaf.mode == "drag" && _tb.leaf.gx < 0;
    fol_book_feed(_tb, { mx: _cx0 - 600, my: _cy0 - 80, down: false, released: true });
    fol__st_run(_tb);
    fol_st_assert(_st, _dragged && _tb.spread == _s0 + 1, "a corner dragged past the spine and let go falls over: " + string(_s0) + " -> " + string(_tb.spread));
    // a short drag springs back
    _s0 = _tb.spread;
    fol_book_feed(_tb, { mx: _cx0, my: _cy0, down: true, pressed: true });
    for (var _i = 1; _i <= 10; _i++) fol_book_feed(_tb, { mx: _cx0 - _i * 6, my: _cy0, down: true });
    fol_book_feed(_tb, { mx: _cx0 - 60, my: _cy0, down: false, released: true });
    var _sb = fol__st_run(_tb);
    fol_st_assert(_st, _tb.spread == _s0 && _sb > 2, "a corner let go short of the spine springs back: " + string(_tb.spread) + " after " + string(_sb) + " frames");
    // a flick: fast leftward, let go while still right of the spine
    fol_book_feed(_tb, { mx: _cx0, my: _cy0, down: true, pressed: true });
    fol_book_feed(_tb, { mx: _cx0 - 30, my: _cy0, down: true });
    fol_book_feed(_tb, { mx: _cx0 - 90, my: _cy0, down: true });
    var _gx_at = _tb.leaf.gx;
    fol_book_feed(_tb, { mx: _cx0 - 90, my: _cy0, down: false, released: true });
    fol__st_run(_tb);
    fol_st_assert(_st, _gx_at > 0 && _tb.spread == _s0 + 1, "a flick turns the page though it was let go right of the spine (gx " + string(_gx_at) + ")");
    // a click in the middle of a page turns it
    _s0 = _tb.spread;
    fol_book_feed(_tb, { mx: 600, my: 270, down: true, pressed: true });
    fol_book_feed(_tb, { mx: 601, my: 270, down: false, released: true });
    fol__st_run(_tb);
    fol_st_assert(_st, _tb.spread == _s0 + 1, "a click on the right page turns forward");
    _s0 = _tb.spread;
    fol_book_feed(_tb, { mx: 200, my: 270, down: true, pressed: true });
    fol_book_feed(_tb, { mx: 200, my: 270, down: false, released: true });
    fol__st_run(_tb);
    fol_st_assert(_st, _tb.spread == _s0 - 1, "a click on the left page turns back");
    // the left page dragged across to the right turns back
    _s0 = _tb.spread;
    fol_book_feed(_tb, { mx: 2, my: _cy0, down: true, pressed: true });
    for (var _i = 1; _i <= 20; _i++) fol_book_feed(_tb, { mx: 2 + _i * 32, my: _cy0 - _i * 3, down: true });
    var _ldir = is_struct(_tb.leaf) ? _tb.leaf.dir : 0;
    fol_book_feed(_tb, { mx: 660, my: _cy0 - 60, down: false, released: true });
    fol__st_run(_tb);
    fol_st_assert(_st, _ldir == -1 && _tb.spread == _s0 - 1, "the left page dragged over turns back: dir " + string(_ldir) + ", spread " + string(_tb.spread));
    // hover lifts the corner
    fol_book_feed(_tb, { mx: _cx0 - 10, my: _cy0 - 8, down: false });
    repeat (20) { fol_book_feed(_tb, { mx: _cx0 - 10, my: _cy0 - 8, down: false }); fol_book_step(_tb, 1 / 60); }
    fol_st_assert(_st, _tb.hover.side == 1 && _tb.hover.amt > 0.8, "resting near the corner lifts it: amt " + string(_tb.hover.amt));
    fol_book_feed(_tb, { mx: 600, my: 100, down: false });
    repeat (30) { fol_book_feed(_tb, { mx: 600, my: 100, down: false }); fol_book_step(_tb, 1 / 60); }
    fol_st_assert(_st, _tb.hover.amt < 0.05, "and it settles when the pointer leaves: " + string(_tb.hover.amt));
    // a thumb tab's box (written by the draw) opens its chapter
    _tb.hot = [{ x0: 900, y0: 10, x1: 930, y1: 40, page: fol_book_sections(_tb)[2].page, kind: "tab" }];
    fol_book_feed(_tb, { mx: 910, my: 20, down: true, pressed: true });
    fol_book_feed(_tb, { mx: 910, my: 20, down: false, released: true });
    fol__st_run(_tb, 1000);
    fol_st_assert(_st, _tb.spread == fol_page_spread(fol_book_sections(_tb)[2].page), "a tab opens its chapter: spread " + string(_tb.spread));
    // an automatic turn keeps the leaf over the book: the fold may tilt, but the leaf must not swing far past the head or the foot
    fol_book_goto(_tb, 2, true);
    fol_book_next(_tb);
    var _top = 0, _bot = 540, _frames = 0;
    while (is_struct(_tb.leaf) && _frames < 300) {
        fol_book_step(_tb, 1 / 60); _frames++;
        if (!is_struct(_tb.leaf)) break;
        var _Pa = fol_leaf_pose(400, 540, _tb.leaf.gv, _tb.leaf.gx, _tb.leaf.gy, 0.5);
        var _cs4 = [[400, 0], [400, 540], [0, 0], [0, 540]];
        for (var _q = 0; _q < 4; _q++) { var _mq = fol_leaf_map(_Pa, _cs4[_q][0], _cs4[_q][1]); _top = min(_top, _mq[1]); _bot = max(_bot, _mq[1]); }
    }
    _st.notes.auto_turn_reach = [_top, _bot];
    fol_st_assert(_st, _top > -540 * 0.06 && _bot < 540 * 1.06, "an automatic turn stays over the book: the leaf reaches " + string(_top) + " above the head and " + string(_bot - 540) + " below the foot");
    // step with a fixed dt is deterministic
    var _a1 = fol_book_create({ page_w: 300, page_h: 400, measure: function(_s, _st2) { return string_length(_s) * 9; } }), _a2 = fol_book_create({ page_w: 300, page_h: 400, measure: function(_s, _st2) { return string_length(_s) * 9; } });
    fol_book_text(_a1, string_repeat("word ", 400)); fol_book_text(_a2, string_repeat("word ", 400));
    fol_book_next(_a1); fol_book_next(_a2);
    repeat (13) { fol_book_step(_a1, 1 / 60); fol_book_step(_a2, 1 / 60); }
    fol_st_assert(_st, _a1.leaf.gx == _a2.leaf.gx && _a1.leaf.gy == _a2.leaf.gy, "the same steps give the same leaf");

    // ------------------------------------------------------------ 70: the papers
    fol_st_stage(_st, 70);
    var _sig = array_create(48), _tw = 150, _th = 204, _deck_bad = "", _cut_bad = "", _decks = 0, _cuts = 0, _paper_off = "";
    for (var _i = 0; _i < 48; _i++) {
        var _bk = fol_book_create({ page_w: _tw, page_h: _th, paper: _i, type_px: 8, measure: function(_s, _st2) { return string_length(_s) * 4; } });
        fol_book_paginate(_bk);
        var _ps = fol__compose(_bk, 0, 1), _rd = fol__st_read(_ps);
        _sig[_i] = fol__st_grid(_rd, 6, 8);
        var _lk = fol_paper_look(_i);
        // the edges: a torn edge leaves gaps at the fore-edge; a cut edge is solid there
        var _clear = 0;
        for (var _y = 4; _y < _th - 4; _y++) if (fol__st_px(_rd, _tw - 1, _y)[3] < 128) _clear++;
        if (_lk.edge == "deckle") { _decks++; if (_clear < _th * 0.15) _deck_bad += _lk.name + " "; }
        else { _cuts++; if (_clear > 0) _cut_bad += _lk.name + " "; }
        // the paper is the stock's colour: the middle of an empty margin
        var _pc = fol_paper_colours(_i).paper, _mid = fol__st_px(_rd, _tw * 0.5, _th * 0.04);
        if (abs(_mid[0] - colour_get_red(_pc)) > 40 || abs(_mid[1] - colour_get_green(_pc)) > 40 || abs(_mid[2] - colour_get_blue(_pc)) > 40) _paper_off += _lk.name + " ";
        buffer_delete(_rd.buf); surface_free(_ps);
        fol_book_free(_bk);
    }
    fol_st_assert(_st, _decks >= 12 && _deck_bad == "", "every deckle look is torn at its fore-edge: " + _deck_bad);
    fol_st_assert(_st, _cuts >= 24 && _cut_bad == "", "every cut or gilt look is solid to its edge: " + _cut_bad);
    fol_st_assert(_st, _paper_off == "", "every look's margin is its stock's colour: " + _paper_off);
    var _dmin = 9999, _dpair = "", _hist = array_create(12, 0);
    for (var _i = 0; _i < 48; _i++) for (var _j = _i + 1; _j < 48; _j++) {
        var _d = fol__st_diff(_sig[_i], _sig[_j]);
        _hist[min(11, floor(_d))] += 1;
        if (_d < _dmin) { _dmin = _d; _dpair = fol_paper_name(_i) + " / " + fol_paper_name(_j); }
    }
    _st.notes.paper_closest = _dpair + " at " + string_format(_dmin, 1, 3);
    _st.notes.paper_hist = _hist;
    fol_st_assert(_st, _dmin > 1.5, "no two looks render alike (closest " + _dpair + " at " + string(_dmin) + ")");
    // the bake time of a full page, three looks
    var _bt = [];
    for (var _i = 0; _i < 3; _i++) { fol_paper_sprite([0, 24, 42][_i], 420, 560, 0, 77); array_push(_bt, global.fol__last_bake_us / 1000); }
    _st.timings.paper_bake_ms = _bt;

    // ------------------------------------------------------------ 80: page composition
    fol_st_stage(_st, 80);
    _rb.surf = undefined;
    var _cs = fol__compose(_rb, 0, 1), _cr = fol__st_read(_cs), _m0 = fol_book_metrics(_rb, 0);
    var _ref = fol__st_px(_cr, _rb.pw * 0.5, _rb.ph * 0.03);
    var _ink_text = fol__st_far(_cr, _m0.x, _m0.y + _m0.pitch * 4, _m0.x + _m0.w, _m0.bottom, _ref, 60);
    var _ink_folio = fol__st_far(_cr, 0, _m0.bottom + 2, _rb.pw, _rb.ph - 2, _ref, 60);
    fol_st_assert(_st, _ink_text > 3000, "the opening page carries text in its box: " + string(_ink_text) + " inked pixels");
    fol_st_assert(_st, _ink_folio > 20, "and a page number below it: " + string(_ink_folio));
    var _white = 0, _hole = 0;
    for (var _y = 8; _y < _cr.h - 8; _y += 2) for (var _x = 8; _x < _cr.w - 8; _x += 2) { var _px = fol__st_px(_cr, _x, _y); if (_px[0] == 255 && _px[1] == 255 && _px[2] == 255) _white++; if (_px[3] < 250) _hole++; }
    fol_st_assert(_st, _white < 50, "no white box on the page (a sprite freed before its draw flushed): " + string(_white));
    fol_st_assert(_st, _hole == 0, "no translucent hole inside the page (alpha blends as over): " + string(_hole));
    buffer_delete(_cr.buf); surface_free(_cs);
    // the plate and the drawing land on their pages
    var _plate = -1, _custom = -1;
    for (var _p = 0; _p < _rn; _p++) for (var _i = 0; _i < array_length(_rb.pages[_p].items); _i++) { var _k2 = _rb.pages[_p].items[_i].k; if (_k2 == "picture") _plate = _p; if (_k2 == "custom") _custom = _p; }
    fol_st_assert(_st, _plate >= 0 && _custom >= 0, "the demo's plate and drawing are placed: pages " + string(_plate) + ", " + string(_custom));
    // a plate keeps its picture's shape, even when it was asked for more height than the measure allows (a 2:1 sprite asked for 400 px)
    var _wide = fol_book_create({ page_w: 300, page_h: 400, measure: function(_s, _st2) { return string_length(_s) * 9; } });
    var _ws = surface_create(200, 100); surface_set_target(_ws); draw_clear_alpha(c_red, 1); surface_reset_target();
    var _wspr = sprite_create_from_surface(_ws, 0, 0, 200, 100, false, false, 0, 0); surface_free(_ws);
    fol_book_picture(_wide, _wspr, 0, 400, "wide");
    fol_book_paginate(_wide);
    var _wit = undefined;
    for (var _p = 0; _p < array_length(_wide.pages); _p++) for (var _i = 0; _i < array_length(_wide.pages[_p].items); _i++) if (_wide.pages[_p].items[_i].k == "picture") _wit = _wide.pages[_p].items[_i];
    fol_st_assert(_st, !is_undefined(_wit) && abs(_wit.w / _wit.h - 2) < 0.01, "a plate keeps its picture's shape (2:1 asked 400 px tall): " + (is_undefined(_wit) ? "none" : string(_wit.w) + " x " + string(_wit.h)));
    sprite_delete(_wspr);
    if (_plate >= 0) {
        var _ps2 = fol__compose(_rb, _plate, 1), _pr2 = fol__st_read(_ps2), _red = 0, _pit = undefined;
        for (var _i = 0; _i < array_length(_rb.pages[_plate].items); _i++) if (_rb.pages[_plate].items[_i].k == "picture") _pit = _rb.pages[_plate].items[_i];
        for (var _y = floor(_pit.y); _y < _pit.y + _pit.h; _y += 2) for (var _x = floor(_pit.x); _x < _pit.x + _pit.w; _x += 2) { var _px = fol__st_px(_pr2, _x, _y); if (_px[0] > _px[1] + 60 && _px[0] > _px[2] + 60) _red++; }
        fol_st_assert(_st, _red > 20, "the plate shows its picture (the compass's red north): " + string(_red));
        buffer_delete(_pr2.buf); surface_free(_ps2);
    }
    if (_custom >= 0) {
        var _ps3 = fol__compose(_rb, _custom, 1), _pr3 = fol__st_read(_ps3), _navy = 0, _cit = undefined;
        for (var _i = 0; _i < array_length(_rb.pages[_custom].items); _i++) if (_rb.pages[_custom].items[_i].k == "custom") _cit = _rb.pages[_custom].items[_i];
        for (var _y = floor(_cit.y) + 4; _y < _cit.y + _cit.h - 4; _y += 3) for (var _x = floor(_cit.x + _cit.w * 0.2); _x < _cit.x + _cit.w * 0.8; _x += 3) { var _px = fol__st_px(_pr3, _x, _y); if (_px[2] > _px[0] + 20 && _px[0] < 90) _navy++; }
        fol_st_assert(_st, _navy > 100, "the custom drawing was called on its page: " + string(_navy));
        buffer_delete(_pr3.buf); surface_free(_ps3);
    }
    _t0 = get_timer();
    var _ps4 = fol__compose(_rb, 2, 1);
    _st.timings.compose_page_ms = (get_timer() - _t0) / 1000;
    surface_free(_ps4);

    // ------------------------------------------------------------ 90: the book drawn
    fol_st_stage(_st, 90);
    var _W = 980, _H = 680, _bx = 50, _by = 50, _k = 1;
    fol_book_goto(_rb, 4, true);
    var _s1 = surface_create(_W, _H);
    var _mw0 = matrix_get(matrix_world), _bm0 = gpu_get_blendmode();
    surface_set_target(_s1); draw_clear_alpha(c_black, 1);
    fol_book_draw(_rb, _bx, _by, _k);
    surface_reset_target();
    var _mw1 = matrix_get(matrix_world), _mok = true;
    for (var _i = 0; _i < 16; _i++) if (_mw0[_i] != _mw1[_i]) _mok = false;
    fol_st_assert(_st, _mok && gpu_get_blendmode() == _bm0, "drawing the book leaves the caller's matrix and blend as they were");
    var _r1 = fol__st_read(_s1);
    var _black = [0, 0, 0];
    var _inkL = fol__st_far(_r1, _bx + 20, _by + 20, _bx + _rb.pw - 20, _by + _rb.ph - 20, _black, 40), _inkR = fol__st_far(_r1, _bx + _rb.pw + 20, _by + 20, _bx + _rb.pw * 2 - 20, _by + _rb.ph - 20, _black, 40);
    fol_st_assert(_st, _inkL > (_rb.pw - 40) * (_rb.ph - 40) * 0.9 && _inkR > (_rb.pw - 40) * (_rb.ph - 40) * 0.9, "both pages are drawn: " + string(_inkL) + ", " + string(_inkR));
    var _sigA = fol__st_grid(_r1, 12, 8);
    surface_save(_s1, "fol_render_spread_rest.png");
    fol_st_assert(_st, array_length(_rb.hot) >= array_length(fol_book_sections(_rb)), "every tab (and every closed ribbon's tail) has a box to click: " + string(array_length(_rb.hot)));
    var _tab_in = 0, _tabs = 0;
    for (var _i = 0; _i < array_length(_rb.hot); _i++) { var _hb = _rb.hot[_i]; if (_hb.kind != "tab") continue; _tabs++; if (_hb.x1 > _bx + 0.5 && _hb.x0 < _bx + _rb.pw * 2 * _k - 0.5) _tab_in++; }
    fol_st_assert(_st, _tabs == array_length(fol_book_sections(_rb)) && _tab_in == 0, "every tab's box (where its initial is drawn) stands clear of the pages: " + string(_tab_in) + " of " + string(_tabs) + " overlap");
    // mid-turn
    fol_book_next(_rb);
    repeat (round(_rb.turn_time * 60 * 0.5)) fol_book_step(_rb, 1 / 60);
    surface_set_target(_s1); draw_clear_alpha(c_black, 1); fol_book_draw(_rb, _bx, _by, _k); surface_reset_target();
    var _r2 = fol__st_read(_s1), _sigB = fol__st_grid(_r2, 12, 8);
    surface_save(_s1, "fol_render_spread_turn.png");
    var _dL = 0, _dR = 0;
    for (var _gy = 0; _gy < 8; _gy++) for (var _gx = 0; _gx < 12; _gx++) { var _i = (_gy * 12 + _gx) * 4, _dd = abs(_sigA[_i + 1] - _sigB[_i + 1]) + abs(_sigA[_i + 2] - _sigB[_i + 2]) + abs(_sigA[_i + 3] - _sigB[_i + 3]); if (_gx < 6) _dL += _dd; else _dR += _dd; }
    fol_st_assert(_st, _dL > 40 && _dR > 40, "mid-turn, the leaf changes both halves of the spread: left " + string(_dL) + ", right " + string(_dR));
    fol_st_assert(_st, is_struct(_rb.leaf) && _rb.leaf.t > 0.3 && _rb.leaf.t < 0.7, "the turn is half way: t " + string(is_struct(_rb.leaf) ? _rb.leaf.t : -1));
    fol__st_run(_rb);
    buffer_delete(_r1.buf); buffer_delete(_r2.buf);
    // under a caller's 2x matrix, the book is drawn twice the size and the matrix comes back
    var _s2 = surface_create(_W, _H);
    surface_set_target(_s2); draw_clear_alpha(c_black, 1);
    var _mm2 = matrix_build(0, 0, 0, 0, 0, 0, 2, 2, 1);
    matrix_set(matrix_world, _mm2);
    fol_book_draw(_rb, 10, 10, 0.4);
    var _mw2 = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_build_identity());
    surface_reset_target();
    var _r3 = fol__st_read(_s2), _far = fol__st_far(_r3, 10 * 2 + _rb.pw * 0.4 * 2 * 2 - 30, 40, 10 * 2 + _rb.pw * 0.4 * 2 * 2 - 10, 200, _black, 40);
    fol_st_assert(_st, _mw2[0] == 2 && _mw2[5] == 2, "the caller's 2x matrix is still set after the draw");
    fol_st_assert(_st, _far > 100, "under a 2x matrix the book is drawn at twice its scale (ink at the far fore-edge): " + string(_far));
    buffer_delete(_r3.buf); surface_free(_s2);

    // ------------------------------------------------------------ 95: resources
    fol_st_stage(_st, 95);
    var _rc0 = debug_event("ResourceCounts", true);
    var _s3 = surface_create(_W, _H);
    for (var _f = 0; _f < 240; _f++) {
        if (!fol_book_turning(_rb)) { if (_rb.spread < fol_book_spreads(_rb) - 1) fol_book_next(_rb); else fol_book_goto(_rb, 0, true); }
        fol_book_step(_rb, 1 / 60);
        surface_set_target(_s3); draw_clear_alpha(c_black, 1); fol_book_draw(_rb, _bx, _by, _k); surface_reset_target();
    }
    var _rc1 = debug_event("ResourceCounts", true);
    fol_st_assert(_st, _rc1.surfaceCount - _rc0.surfaceCount <= 8, "240 frames of turning keep at most the cache's eight page surfaces: " + string(_rc0.surfaceCount) + " -> " + string(_rc1.surfaceCount));
    var _freed = fol_book_free(_rb);
    var _rc2 = debug_event("ResourceCounts", true);
    fol_st_assert(_st, _rc2.surfaceCount <= _rc0.surfaceCount, "fol_book_free lets every page surface go: " + string(_rc2.surfaceCount) + " (freed " + string(_freed) + ")");
    // what a frame costs: the first draw (pages composed), then at rest, then through one whole turn (each frame flushed and timed)
    fol_book_goto(_rb, 2, true);
    _t0 = get_timer();
    surface_set_target(_s3); draw_clear_alpha(c_black, 1); fol_book_draw(_rb, _bx, _by, _k); surface_reset_target();
    _st.timings.first_draw_ms = (get_timer() - _t0) / 1000;
    _t0 = get_timer();
    repeat (60) { fol_book_step(_rb, 1 / 60); surface_set_target(_s3); draw_clear_alpha(c_black, 1); fol_book_draw(_rb, _bx, _by, _k); surface_reset_target(); }
    _st.timings.rest_frame_ms = (get_timer() - _t0) / 1000 / 60;
    // warm the next spread's pages first, so the turn is timed as a turn and not as composition
    fol_book_next(_rb);
    surface_set_target(_s3); fol_book_draw(_rb, _bx, _by, _k); surface_reset_target();
    var _tf = 0, _tworst = 0;
    while (is_struct(_rb.leaf) && _tf < 200) {
        var _t1 = get_timer();
        fol_book_step(_rb, 1 / 60); surface_set_target(_s3); draw_clear_alpha(c_black, 1); fol_book_draw(_rb, _bx, _by, _k); surface_reset_target();
        var _dt = (get_timer() - _t1) / 1000; _tworst = max(_tworst, _dt); _st.timings.turn_frame_ms = (variable_struct_exists(_st.timings, "turn_frame_ms") ? _st.timings.turn_frame_ms : 0) + _dt; _tf++;
    }
    _st.timings.turn_frame_ms /= max(1, _tf);
    _st.timings.turn_frame_worst_ms = _tworst;
    fol_st_assert(_st, _tf > 10, "the timed turn ran: " + string(_tf) + " frames");
    surface_free(_s3);

    // ------------------------------------------------------------ 99: renders, to be looked at
    fol_st_stage(_st, 99);
    fol__st_renders(_st);
    surface_free(_s1);
    fol_book_free(_rb);
    return _st;
}
/// @function fol__st_renders(state)
/// @description Internal. The pictures to LOOK at: the 48 papers as a sheet, a turn in five moments, six spreads in six papers.
function fol__st_renders(_st) {
    // the 48 papers, each a small page with a paragraph
    var _cw = 150, _ch = 204, _cols = 8, _rows = 6, _gap = 14;
    var _sw = _cols * (_cw * 2 + _gap) + _gap, _sh = _rows * (_ch + _gap + 18) + _gap;
    var _sheet = surface_create(_sw, _sh);
    for (var _i = 0; _i < 48; _i++) {
        var _bk = fol_book_create({ page_w: _cw, page_h: _ch, paper: _i, type_px: 8 });
        fol_book_chapter(_bk, fol_paper_name(_i), { tab: false });
        fol_book_text(_bk, "The quick brown fox jumps over the lazy dog, and the page turns as paper turns, ruled and framed in its own way.");
        fol_book_text(_bk, "Second paragraph for the facing page of this little book, so both sides of the spread are set.");
        fol_book_paginate(_bk);
        var _ps = fol__page_surf(_bk, 0, 1), _pl = fol__page_surf(_bk, -1, 1);
        surface_set_target(_sheet);
        if (_i == 0) draw_clear_alpha(make_colour_rgb(40, 32, 28), 1);
        var _x = _gap + (_i mod _cols) * (_cw * 2 + _gap), _y = _gap + (_i div _cols) * (_ch + _gap + 18);
        gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
        draw_surface(_pl, _x, _y); draw_surface(_ps, _x + _cw, _y);
        gpu_set_blendmode(bm_normal);
        surface_reset_target();
        fol_book_free(_bk);
    }
    surface_save(_sheet, "fol_render_papers.png");
    surface_free(_sheet);
    // a turn in five moments
    var _b = fol_book_create({ page_w: 300, page_h: 400, paper: "Field Journal", title: "Folio" });
    fol_demo_fill(_b);
    fol_book_paginate(_b);
    fol_book_goto(_b, 2, true);
    var _strip = surface_create(5 * 640, 460);
    surface_set_target(_strip); draw_clear_alpha(make_colour_rgb(30, 24, 20), 1); surface_reset_target();
    fol_book_next(_b);
    var _ts = [0.12, 0.3, 0.5, 0.7, 0.88];
    for (var _i = 0; _i < 5; _i++) {
        while (is_struct(_b.leaf) && _b.leaf.t < _ts[_i]) fol_book_step(_b, 1 / 120);
        surface_set_target(_strip); fol_book_draw(_b, _i * 640 + 20, 30, 1); surface_reset_target();
    }
    surface_save(_strip, "fol_render_turn_strip.png");
    surface_free(_strip);
    fol__st_run(_b);
    // a corner dragged by hand, at three depths
    var _hand = surface_create(3 * 640, 460);
    surface_set_target(_hand); draw_clear_alpha(make_colour_rgb(30, 24, 20), 1); surface_reset_target();
    for (var _i = 0; _i < 3; _i++) {
        fol_book_place(_b, 20, 30, 1);
        _b.leaf = fol__leaf_new(_b, 1, _b.ph, "drag");
        _b.leaf.gx = [230, 120, -60][_i]; _b.leaf.gy = [330, 250, 300][_i];
        surface_set_target(_hand); fol_book_draw(_b, _i * 640 + 20, 30, 1); surface_reset_target();
        _b.leaf = undefined;
    }
    surface_save(_hand, "fol_render_drag.png");
    surface_free(_hand);
    // six spreads in six papers, at a size a buyer would use
    var _six = ["Bestiary", "Ship's Manifest", "Spellbook", "Night Journal", "Hymnal", "Detective's Casebook"];
    for (var _i = 0; _i < 6; _i++) {
        fol_book_set_paper(_b, _six[_i]); fol_book_paginate(_b); fol_book_goto(_b, [0, 3, 5, 7, 2, 9][_i], true);
        var _s = surface_create(940, 640);
        surface_set_target(_s); draw_clear_alpha(make_colour_rgb(30, 24, 20), 1);
        fol_book_draw(_b, 170, 120, 1);
        surface_reset_target();
        surface_save(_s, "fol_render_spread_" + string(_i) + ".png");
        surface_free(_s);
    }
    fol_book_free(_b);
    _st.notes.renders = 10;
}
/// @function fol_selftest_write(state)
/// @description Write the result file, for the runner.
function fol_selftest_write(_st) {
    var _f = file_text_open_write("fol_selftest.json");
    file_text_write_string(_f, json_stringify({ ran: true, total: _st.total, pass: _st.pass, fail: _st.fail, stage: _st.stage, failures: _st.failures, notes: _st.notes, timings: _st.timings }));
    file_text_close(_f);
}
