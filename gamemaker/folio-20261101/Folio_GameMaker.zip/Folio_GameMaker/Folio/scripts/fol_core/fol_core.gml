/// fol_core.gml - Folio's rules. NO DRAWING and no device input in this file: the book and its contents, pagination (lines, widows
/// and orphans, chapters that open with a drop initial, pictures, page breaks), running heads and page numbers, the ribbons and the
/// thumb tabs, and the page turn as a state machine fed plain numbers. Everything here runs in a headless test.
///
/// The words used throughout:
///   BOOK     fol_book_create({...}): the pages, their paper, where the reader is, and the leaf in motion.
///   BLOCK    what you add (a chapter, a paragraph, a heading, a picture, your own drawing); pagination flows blocks onto pages.
///   PAGE     page 0 is the first right-hand page. Page numbers printed on the paper are page + 1.
///   SPREAD   what lies open: spread k shows page 2k-1 on the left and page 2k on the right. Spread 0's left side is the endpaper.
///   LEAF     the sheet that turns: its front is a right-hand page, its back the next left-hand page.
///
/// Folio - A Page-Turning Book for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

#macro FOL_VERSION "1.0.0"
#macro FOL_MAX_PAGES 4000
#macro FOL_MAX_RIBBONS 3
#macro FOL_MAX_TABS 12

// ------------------------------------------------------------------------------------------------ small guards

/// @function fol__n(value, fallback)
/// @description Internal. A finite number, or the fallback: every public entry point takes its numbers through this.
function fol__n(_v, _d) {
    if (is_real(_v) || is_int32(_v) || is_int64(_v)) { if (is_nan(_v) || is_infinity(_v)) return _d; return _v; }
    return _d;
}
/// @function fol__opt(struct, key, fallback)
/// @description Internal. A field of an options struct, or the fallback when the struct or the field is missing.
function fol__opt(_o, _k, _d) {
    if (!is_struct(_o) || !variable_struct_exists(_o, _k)) return _d;
    var _v = _o[$ _k];
    return is_undefined(_v) ? _d : _v;
}
/// @function fol__is_book(value)
/// @description Internal. Is this a book made by fol_book_create?
function fol__is_book(_v) { return is_struct(_v) && variable_struct_exists(_v, "fol_kind_tag") && _v.fol_kind_tag == "book"; }
/// @function fol__rebind(callback, options)
/// @description Internal. A function literal written inside an options struct is bound to that struct; hand it to the caller instead, so it can read the caller's variables.
function fol__rebind(_f, _opts) {
    if (is_undefined(_f) || !is_method(_f)) return _f;
    if (method_get_self(_f) == _opts) return method(self, method_get_index(_f));
    return _f;
}
/// @function fol__callable(value)
/// @description Internal. A function you can hand Folio: a method (a function literal) or a named script function. A plain number or a string is not one, though GameMaker's is_callable says yes to any number that happens to be a script's index.
function fol__callable(_v) {
    if (is_method(_v)) return true;
    if (is_string(_v) || is_real(_v) || is_int32(_v) || is_int64(_v) || is_undefined(_v) || is_struct(_v) || is_array(_v) || is_bool(_v)) return false;
    return is_callable(_v);
}
/// @function fol__str(value)
/// @description Internal. Text from anything: a string stays, a number is printed, anything else is empty.
function fol__str(_v) {
    if (is_string(_v)) return _v;
    if (is_real(_v) || is_int32(_v) || is_int64(_v)) return string(_v);
    return "";
}

// ------------------------------------------------------------------------------------------------ the generator

/// @function fol_rng(seed)
/// @description A small seeded generator (Lehmer), warmed up here: a Lehmer generator's first draw is nearly a straight line in the seed for nearby seeds.
/// @param {real} seed  Any number.
/// @returns {struct} Pass it to fol_rand.
function fol_rng(_seed) {
    var _s = floor(abs(fol__n(_seed, 1))) mod 2147483646;
    var _g = { s: _s + 1 };
    repeat (3) fol_rand(_g);
    return _g;
}
/// @function fol_rand(generator)
/// @description The next draw in [0, 1). A non-generator draws 0.
/// @param {struct} generator  From fol_rng.
/// @returns {real}
function fol_rand(_g) {
    if (!is_struct(_g) || !variable_struct_exists(_g, "s")) return 0;
    _g.s = (_g.s * 48271) mod 2147483647;
    return (_g.s - 1) / 2147483646;
}

// ------------------------------------------------------------------------------------------------ the book

/// @function fol_book_create(options)
/// @description A new, empty book. Every option is optional.
///   page_w, page_h   one page in pixels (default 460 x 620; 120..2048 each)
///   paper            a paper look: its index, or its name ("Field Journal"); see fol_paper_count / fol_paper_name
///   title            printed in the running head of right-hand pages
///   type_px          the body type size in pixels (default: page width / 23)
///   justify          true (default) sets the text flush on both sides; false sets it ragged right
///   roman            true prints page numbers as lowercase roman numerals
///   seed             varies the paper's foxing and grain between two books of the same look
///   turn_time        seconds one page takes to turn by itself (default 0.62)
///   on_turn          function(book, from_spread, to_spread), called when a turn completes
///   cloth            the colour of the boards under the page block (a GameMaker colour; default: chosen to suit the paper)
///   measure          function(text, style) -> width in pixels; leave it unset in a game (Folio measures with its own fonts)
/// @param {struct} options
/// @returns {struct} The book.
function fol_book_create(_opts = undefined) {
    var _o = is_struct(_opts) ? _opts : {};
    var _pw = clamp(round(fol__n(fol__opt(_o, "page_w", 460), 460)), 120, 2048);
    var _ph = clamp(round(fol__n(fol__opt(_o, "page_h", 620), 620)), 160, 2048);
    var _b = {
        fol_kind_tag: "book",
        title: fol__str(fol__opt(_o, "title", "")),
        pw: _pw, ph: _ph,
        paper: 0,
        seed: floor(abs(fol__n(fol__opt(_o, "seed", 1), 1))),
        type_px: clamp(fol__n(fol__opt(_o, "type_px", _pw / 23), _pw / 23), 8, 96),
        justify: fol__opt(_o, "justify", true) == true,
        roman: fol__opt(_o, "roman", false) == true,
        turn_time: clamp(fol__n(fol__opt(_o, "turn_time", 0.62), 0.62), 0.15, 4),
        on_turn: fol__rebind(fol__opt(_o, "on_turn", undefined), _o),
        measure: fol__rebind(fol__opt(_o, "measure", undefined), _o),
        blocks: [],
        pages: [], sections: [], dirty: true,
        spread: 0,
        ribbons: [],
        leaf: undefined,
        queue: 0,
        hover: { side: 0, amt: 0, v: 0 },
        drag: undefined,
        place: { x: 0, y: 0, k: 1 },
        gen: 0,
        stats: { paginations: 0, composed: 0 },
        surf: undefined,
        hot: [],
        cloth: fol__n(fol__opt(_o, "cloth", -1), -1)
    };
    var _pp = fol__opt(_o, "paper", 0);
    _b.paper = fol_paper_find(_pp);
    if (_b.paper < 0) _b.paper = 0;
    return _b;
}
/// @function fol__add(book, block)
/// @description Internal. Append a block and mark the book for re-pagination.
function fol__add(_b, _blk) {
    if (!fol__is_book(_b)) return false;
    array_push(_b.blocks, _blk);
    _b.dirty = true;
    return true;
}
/// @function fol_book_chapter(book, title, options)
/// @description Start a chapter: a new page with a headpiece, the title in display capitals and a drop initial on the first paragraph. Options: tab (true gives it a thumb tab on the fore-edge, default true), recto (true starts it on a right-hand page, default false), initial (false for no drop initial).
/// @param {struct} book
/// @param {string} title
/// @param {struct} options
/// @returns {bool} False when the book is not a book.
function fol_book_chapter(_b, _title, _opts = undefined) {
    return fol__add(_b, { k: "chapter", title: fol__str(_title), tab: fol__opt(_opts, "tab", true) == true, recto: fol__opt(_opts, "recto", false) == true, initial: fol__opt(_opts, "initial", true) == true });
}
/// @function fol_book_text(book, text)
/// @description Add running text. Each line of the string ("\n") is a paragraph.
/// @param {struct} book
/// @param {string} text
/// @returns {bool}
function fol_book_text(_b, _text) {
    var _t = fol__str(_text);
    if (_t == "") return fol__is_book(_b);
    var _ps = string_split(_t, "\n", true);
    var _ok = true;
    for (var _i = 0; _i < array_length(_ps); _i++) { var _p = string_trim(_ps[_i]); if (_p != "") _ok = fol__add(_b, { k: "para", text: _p }) && _ok; }
    return _ok;
}
/// @function fol_book_heading(book, text)
/// @description A heading inside a chapter. It is kept with the two lines that follow it (never stranded at the foot of a page).
/// @param {struct} book
/// @param {string} text
/// @returns {bool}
function fol_book_heading(_b, _text) { return fol__add(_b, { k: "heading", text: fol__str(_text) }); }
/// @function fol_book_picture(book, sprite, subimg, height, caption)
/// @description A picture set into the text as a mounted plate, scaled to fit the text width and the given height (pixels; 0 = from the sprite's own shape), with an optional caption in italic below. A picture that does not fit what is left of a page moves to the next.
/// @param {struct} book
/// @param {asset.GMSprite} sprite
/// @param {real} subimg
/// @param {real} height
/// @param {string} caption
/// @returns {bool} False when the book is not a book or the sprite does not exist.
function fol_book_picture(_b, _spr, _sub = 0, _h = 0, _cap = "") {
    var _ok = false;
    try { _ok = sprite_exists(_spr); } catch (_e) { _ok = false; }
    if (!_ok) return false;
    return fol__add(_b, { k: "picture", spr: _spr, sub: fol__n(_sub, 0), h: max(0, fol__n(_h, 0)), cap: fol__str(_cap) });
}
/// @function fol_book_custom(book, height, draw)
/// @description Reserve height pixels in the flow for your own drawing. draw(x, y, w, h, page) is called while the page is being composed, with the page's surface as the target: draw your map, chart or portrait there. It is called again whenever the page is composed afresh.
/// @param {struct} book
/// @param {real} height
/// @param {function} draw
/// @returns {bool}
function fol_book_custom(_b, _h, _fn) {
    if (!fol__callable(_fn)) return false;
    return fol__add(_b, { k: "custom", h: max(1, fol__n(_h, 1)), fn: _fn });
}
/// @function fol_book_space(book, pixels)
/// @description Vertical space in the flow.
/// @param {struct} book
/// @param {real} pixels
/// @returns {bool}
function fol_book_space(_b, _px) { return fol__add(_b, { k: "space", h: max(0, fol__n(_px, 0)) }); }
/// @function fol_book_break(book)
/// @description Continue on a new page.
/// @param {struct} book
/// @returns {bool}
function fol_book_break(_b) { return fol__add(_b, { k: "break" }); }
/// @function fol_book_clear(book)
/// @description Remove every block. The reader goes back to the first spread.
/// @param {struct} book
/// @returns {bool}
function fol_book_clear(_b) {
    if (!fol__is_book(_b)) return false;
    _b.blocks = []; _b.dirty = true; _b.spread = 0; _b.leaf = undefined; _b.queue = 0; _b.drag = undefined;
    return true;
}

// ------------------------------------------------------------------------------------------------ layout metrics

/// @function fol_book_metrics(book, page)
/// @description Where text goes on a page: { x, y, w, h, pitch, type, inner, outer, top, bottom, recto }. Left- and right-hand pages mirror their margins (the wider one is outside).
/// @param {struct} book
/// @param {real} page
/// @returns {struct|undefined}
function fol_book_metrics(_b, _page) {
    if (!fol__is_book(_b)) return undefined;
    var _pg = floor(fol__n(_page, 0));
    var _look = fol_paper_look(_b.paper);
    var _recto = (_pg mod 2) == 0;
    var _inner = round(_b.pw * 0.105), _outer = round(_b.pw * 0.115), _top = round(_b.ph * 0.095), _bot = round(_b.ph * 0.105);
    if (_look.frame == "margin") _outer = round(_b.pw * 0.24);
    if (_look.frame == "illuminated" || _look.frame == "vine") { _outer += round(_b.pw * 0.03); _top += round(_b.ph * 0.012); }
    var _T = _b.type_px, _pitch = round(_T * 1.52);
    var _h = _b.ph - _top - _bot;
    _h = floor(_h / _pitch) * _pitch; // a whole number of lines, so ruled paper and text agree
    var _x = _recto ? _inner : _outer;
    return { x: _x, y: _top, w: _b.pw - _inner - _outer, h: _h, pitch: _pitch, type: _T, inner: _inner, outer: _outer, top: _top, bottom: _top + _h, recto: _recto };
}
/// @function fol__style_px(book, style)
/// @description Internal. The pixel size of each type style, from the body size.
function fol__style_px(_b, _st) {
    var _T = _b.type_px;
    switch (_st) {
        case "body": return _T;
        case "italic": return _T;
        case "caption": return _T * 0.84;
        case "heading": return _T * 1.18;
        case "title": return _T * 1.62;
        case "head": return _T * 0.74;
        case "folio": return _T * 0.82;
        case "drop": return _T * 5.3; // capitals about 0.7 of the size: the cap spans three lines (two pitches and a body cap)
    }
    return _T;
}
/// @function fol__measure(book, text, style)
/// @description Internal. The width of a string in a style, through the book's own measure or the fonts.
function fol__measure(_b, _s, _st) {
    if (fol__callable(_b.measure)) return fol__n(_b.measure(_s, _st), 0);
    return fol__font_width(_s, _st, fol__style_px(_b, _st));
}

// ------------------------------------------------------------------------------------------------ pagination

/// @function fol__wrap(book, words, width_of_line, style)
/// @description Internal. Greedy line breaking: [[word, ...], ...]. width_of_line(i) gives the room on line i (a drop initial narrows the first lines). A word wider than a whole line is broken by characters, never left to overflow.
function fol__wrap(_b, _words, _wfn, _st) {
    var _lines = [], _cur = [], _cw = 0, _sp = fol__measure(_b, " ", _st);
    var _i = 0, _n = array_length(_words), _guard = 0;
    while (_i < _n && _guard++ < 20000) {
        var _w = _words[_i], _ww = fol__measure(_b, _w, _st), _room = _wfn(array_length(_lines));
        var _need = (array_length(_cur) == 0) ? _ww : _cw + _sp + _ww;
        if (_need <= _room + 0.01) { array_push(_cur, _w); _cw = _need; _i++; continue; }
        if (array_length(_cur) > 0) { array_push(_lines, _cur); _cur = []; _cw = 0; continue; }
        // one word longer than the line: cut it by characters, with a hyphen at the cut
        var _cut = string_length(_w) - 1;
        while (_cut > 1 && fol__measure(_b, string_copy(_w, 1, _cut) + "-", _st) > _room) _cut--;
        array_push(_lines, [string_copy(_w, 1, _cut) + "-"]);
        _words[_i] = string_delete(_w, 1, _cut);
    }
    if (array_length(_cur) > 0) array_push(_lines, _cur);
    return _lines;
}
/// @function fol__new_page(state)
/// @description Internal. Close the page in hand and open the next.
function fol__new_page(_S) {
    array_push(_S.pages, _S.page);
    var _i = array_length(_S.pages);
    _S.page = { index: _i, items: [], chapter: _S.chapter, opens: false, blank: false };
    _S.m = fol_book_metrics(_S.b, _i);
    _S.y = _S.m.y;
}
/// @function fol__room(state)
/// @description Internal. Whole lines left on the page in hand.
function fol__room(_S) { return floor((_S.m.bottom - _S.y) / _S.m.pitch + 0.0001); }
/// @function fol__place_lines(state, lines, style, first_indent, drop_w, last_is_end)
/// @description Internal. Put laid-out lines on pages: a paragraph of four lines or more never leaves one line alone at the foot of a page or the head of the next; a shorter one moves whole.
function fol__place_lines(_S, _lines, _st, _ind, _dropw) {
    var _n = array_length(_lines), _k = 0;
    while (_k < _n) {
        var _room = fol__room(_S), _left = _n - _k, _take = _left;
        if (_left > _room) {
            if (_n <= 3 && _k == 0) _take = 0;                 // short paragraph: keep it whole
            else {
                _take = _room;
                if (_left - _take < 2) _take = _left - 2;     // never one line alone at the head of the next page
                if (_k == 0 && _take < 2) _take = 0;          // never one line alone at the foot of this one
            }
            if (_take <= 0 && _S.y == _S.m.y) _take = min(_left, max(1, _room)); // an empty page takes what it can
        }
        for (var _j = 0; _j < _take; _j++) {
            var _li = _k + _j, _ws = _lines[_li], _last = (_li == _n - 1);
            var _x0 = _S.m.x + ((_li == 0) ? _ind : 0) + ((_li < 3) ? _dropw : 0);
            var _room_w = _S.m.w - (_x0 - _S.m.x);
            var _wx = array_create(array_length(_ws), 0), _tot = 0, _sp = fol__measure(_S.b, " ", _st);
            for (var _q = 0; _q < array_length(_ws); _q++) { _wx[_q] = fol__measure(_S.b, _ws[_q], _st); _tot += _wx[_q]; }
            var _gap = _sp, _gaps = array_length(_ws) - 1;
            if (_S.b.justify && !_last && _gaps > 0) _gap = (_room_w - _tot) / _gaps;
            _gap = clamp(_gap, _sp * 0.6, _sp * 3.2);
            var _xs = array_create(array_length(_ws), 0), _cx = _x0;
            for (var _q = 0; _q < array_length(_ws); _q++) { _xs[_q] = _cx; _cx += _wx[_q] + _gap; }
            array_push(_S.page.items, { k: "line", x: _x0, y: _S.y, ws: _ws, xs: _xs, st: _st, p: _S.pid, i: _li, n: _n, w: _cx - _gap - _x0, room: _room_w });
            _S.y += _S.m.pitch;
        }
        _k += _take;
        if (_k < _n) fol__new_page(_S);
    }
}
/// @function fol_book_paginate(book)
/// @description Flow every block onto pages. Called for you before the book is drawn; call it yourself to know the page count up front.
/// @param {struct} book
/// @returns {real} The number of pages, or -1 when the book is not a book.
function fol_book_paginate(_b) {
    if (!fol__is_book(_b)) return -1;
    var _S = { b: _b, pages: [], page: { index: 0, items: [], chapter: "", opens: false, blank: false }, chapter: "", m: fol_book_metrics(_b, 0), y: 0, pid: 0 };
    _S.y = _S.m.y;
    var _sections = [], _pending_drop = false, _after_head = true;
    var _nb = array_length(_b.blocks);
    for (var _bi = 0; _bi < _nb; _bi++) {
        if (array_length(_S.pages) >= FOL_MAX_PAGES) break;
        var _blk = _b.blocks[_bi];
        switch (_blk.k) {
            case "chapter":
                if (array_length(_S.page.items) > 0) fol__new_page(_S);
                if (_blk.recto && (_S.page.index mod 2) == 1) { _S.page.blank = true; fol__new_page(_S); }
                _S.chapter = _blk.title; _S.page.chapter = _blk.title; _S.page.opens = true;
                var _sink = round(_S.m.pitch * 2);
                _S.y = _S.m.y + _sink;
                array_push(_S.page.items, { k: "headpiece", x: _S.m.x, y: _S.y, w: _S.m.w });
                _S.y += round(_S.m.pitch * 1.1);
                var _tl = fol__wrap(_b, string_split(_blk.title, " ", true), method({ w: _S.m.w * 0.9 }, function(_i) { return w; }), "title");
                for (var _t = 0; _t < array_length(_tl); _t++) {
                    var _s = ""; for (var _q = 0; _q < array_length(_tl[_t]); _q++) _s += (_q > 0 ? " " : "") + _tl[_t][_q];
                    array_push(_S.page.items, { k: "title", x: _S.m.x + _S.m.w * 0.5, y: _S.y, str: _s });
                    _S.y += round(_S.m.pitch * 1.45);
                }
                _S.y += round(_S.m.pitch * 0.55);
                _S.y = _S.m.y + ceil((_S.y - _S.m.y) / _S.m.pitch) * _S.m.pitch; // back on the line grid
                if (_blk.tab && array_length(_sections) < FOL_MAX_TABS) array_push(_sections, { title: _blk.title, page: _S.page.index });
                _pending_drop = _blk.initial;
                _after_head = true;
                break;
            case "heading":
                if (fol__room(_S) < 4) fol__new_page(_S);
                else if (_S.y > _S.m.y) _S.y += round(_S.m.pitch * 0.5);
                if (fol__room(_S) < 3) fol__new_page(_S);
                array_push(_S.page.items, { k: "heading", x: _S.m.x, y: _S.y, str: _blk.text, w: _S.m.w });
                _S.y += _S.m.pitch;
                _S.y = _S.m.y + ceil((_S.y - _S.m.y) / _S.m.pitch - 0.0001) * _S.m.pitch;
                _after_head = true;
                break;
            case "para":
                var _words = string_split(_blk.text, " ", true);
                if (array_length(_words) == 0) break;
                var _dropw = 0, _ind = 0;
                if (_pending_drop) {
                    var _first = _words[0], _ch = string_upper(string_char_at(_first, 1));
                    _words[0] = string_delete(_first, 1, 1);
                    if (_words[0] == "") array_delete(_words, 0, 1);
                    _dropw = ceil(fol__measure(_b, _ch, "drop") + _b.type_px * 0.55);
                    // a drop initial needs three lines of room: move to the next page rather than cut it
                    if (fol__room(_S) < 3) fol__new_page(_S);
                    array_push(_S.page.items, { k: "drop", x: _S.m.x, y: _S.y, ch: _ch, w: _dropw });
                } else if (!_after_head) _ind = round(_b.type_px * 1.4);
                var _fx = _dropw, _fi = _ind, _mw = _S.m.w;
                var _wf = method({ fx: _fx, fi: _fi, mw: _mw }, function(_i) { return mw - ((_i < 3) ? fx : 0) - ((_i == 0) ? fi : 0); });
                var _lines = (array_length(_words) > 0) ? fol__wrap(_b, _words, _wf, "body") : [[""]];
                _S.pid += 1;
                fol__place_lines(_S, _lines, "body", _ind, _dropw);
                if (_dropw > 0 && array_length(_lines) < 3) _S.y = max(_S.y, _S.m.y + ceil((_S.y - _S.m.y) / _S.m.pitch) * _S.m.pitch + (3 - array_length(_lines)) * _S.m.pitch);
                _pending_drop = false; _after_head = false;
                break;
            case "picture":
            case "custom":
                var _avw = _S.m.w, _ph = _blk.h;
                if (_blk.k == "picture") {
                    var _sw = max(1, sprite_get_width(_blk.spr)), _sh = max(1, sprite_get_height(_blk.spr));
                    if (_ph <= 0) _ph = _avw * 0.86 * _sh / _sw;
                    // a plate keeps the picture's shape: if the measure caps its width, its height comes down with it
                    _ph = min(_ph, _avw * 0.86 * _sh / _sw);
                }
                var _caph = (_blk.k == "picture" && _blk.cap != "") ? _S.m.pitch : 0;
                var _pad = round(_S.m.pitch * 0.5);
                var _tot = _ph + _caph + _pad * 2;
                var _maxh = _S.m.h;
                if (_tot > _maxh) { _ph = max(8, _maxh - _caph - _pad * 2); _tot = _ph + _caph + _pad * 2; }
                if (_S.y + _tot > _S.m.bottom) fol__new_page(_S);
                var _iy = _S.y + _pad;
                if (_blk.k == "picture") {
                    var _pw2 = min(_avw * 0.86, _ph * sprite_get_width(_blk.spr) / max(1, sprite_get_height(_blk.spr)));
                    array_push(_S.page.items, { k: "picture", x: _S.m.x + (_avw - _pw2) * 0.5, y: _iy, w: _pw2, h: _ph, spr: _blk.spr, sub: _blk.sub, cap: _blk.cap, cx: _S.m.x + _avw * 0.5 });
                } else array_push(_S.page.items, { k: "custom", x: _S.m.x, y: _iy, w: _avw, h: _ph, fn: _blk.fn });
                _S.y += _tot;
                _S.y = _S.m.y + ceil((_S.y - _S.m.y) / _S.m.pitch - 0.0001) * _S.m.pitch;
                _after_head = true;
                break;
            case "space":
                _S.y += _blk.h;
                if (_S.y >= _S.m.bottom) fol__new_page(_S);
                break;
            case "break":
                if (array_length(_S.page.items) > 0 || _S.y > _S.m.y) fol__new_page(_S);
                _after_head = true;
                break;
        }
    }
    array_push(_S.pages, _S.page);
    // an empty book still has one page to show
    _b.pages = _S.pages;
    _b.sections = _sections;
    _b.dirty = false;
    _b.gen += 1;
    _b.stats.paginations += 1;
    _b.spread = clamp(_b.spread, 0, fol_book_spreads(_b) - 1);
    for (var _r = 0; _r < array_length(_b.ribbons); _r++) _b.ribbons[_r].page = clamp(_b.ribbons[_r].page, 0, array_length(_b.pages) - 1);
    return array_length(_b.pages);
}
/// @function fol__ready(book)
/// @description Internal. Paginate when anything changed.
function fol__ready(_b) { if (_b.dirty) fol_book_paginate(_b); }
/// @function fol_book_pages(book)
/// @description How many pages the book has (paginating first when needed).
/// @param {struct} book
/// @returns {real} -1 when the book is not a book.
function fol_book_pages(_b) { if (!fol__is_book(_b)) return -1; fol__ready(_b); return array_length(_b.pages); }
/// @function fol_book_spreads(book)
/// @description How many spreads the book opens to: the first right-hand page alone, then pairs, then the last page with the back endpaper when the count is even.
/// @param {struct} book
/// @returns {real}
function fol_book_spreads(_b) { if (!fol__is_book(_b)) return -1; fol__ready(_b); return floor(array_length(_b.pages) / 2) + 1; }
/// @function fol_book_spread(book)
/// @description The spread lying open (the one being left, while a leaf turns).
/// @param {struct} book
/// @returns {real}
function fol_book_spread(_b) { if (!fol__is_book(_b)) return -1; return _b.spread; }
/// @function fol_spread_pages(book, spread)
/// @description The two page indices of a spread as [left, right]; -1 on a side that is an endpaper.
/// @param {struct} book
/// @param {real} spread
/// @returns {array}
function fol_spread_pages(_b, _s) {
    if (!fol__is_book(_b)) return [-1, -1];
    fol__ready(_b);
    var _n = array_length(_b.pages), _k = floor(fol__n(_s, 0));
    var _l = _k * 2 - 1, _r = _k * 2;
    return [(_l >= 0 && _l < _n) ? _l : -1, (_r >= 0 && _r < _n) ? _r : -1];
}
/// @function fol_page_spread(page)
/// @description The spread a page lies in.
/// @param {real} page
/// @returns {real}
function fol_page_spread(_p) { return floor((floor(fol__n(_p, 0)) + 1) / 2); }
/// @function fol_book_sections(book)
/// @description The chapters with thumb tabs: [{ title, page }, ...].
/// @param {struct} book
/// @returns {array}
function fol_book_sections(_b) { if (!fol__is_book(_b)) return []; fol__ready(_b); return _b.sections; }
/// @function fol_folio_text(book, page)
/// @description The page number as printed: arabic, or lowercase roman when the book asks for it.
/// @param {struct} book
/// @param {real} page
/// @returns {string}
function fol_folio_text(_b, _p) {
    var _n = floor(fol__n(_p, 0)) + 1;
    if (!fol__is_book(_b) || !_b.roman || _n > 3999 || _n < 1) return string(_n);
    var _v = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1], _s = ["m", "cm", "d", "cd", "c", "xc", "l", "xl", "x", "ix", "v", "iv", "i"], _o = "";
    for (var _i = 0; _i < 13; _i++) while (_n >= _v[_i]) { _o += _s[_i]; _n -= _v[_i]; }
    return _o;
}

// ------------------------------------------------------------------------------------------------ ribbons

/// @function fol_book_ribbon(book, index, page)
/// @description Lay ribbon bookmark index (0..2) in a page. A ribbon in the open spread lies across that page; otherwise its tail hangs below the book on the side its page is on, and clicking the tail opens the book there. page -1 takes the ribbon out.
/// @param {struct} book
/// @param {real} index
/// @param {real} page
/// @returns {bool}
function fol_book_ribbon(_b, _i, _p) {
    if (!fol__is_book(_b)) return false;
    var _k = floor(fol__n(_i, -1));
    if (_k < 0 || _k >= FOL_MAX_RIBBONS) return false;
    while (array_length(_b.ribbons) <= _k) array_push(_b.ribbons, { page: -1 });
    _b.ribbons[_k].page = floor(fol__n(_p, -1));
    return true;
}

// ------------------------------------------------------------------------------------------------ the turn: geometry first

/// @function fol_leaf_pose(pw, ph, grab_v, gx, gy, sharpness)
/// @description The shape of a turning leaf, in LEAF space: x runs from the spine (0) out to the fore-edge (pw), y down the page. The corner or edge point grabbed at (pw, grab_v) has been carried to (gx, gy); the page may not stretch past either end of the spine. Returns { gx, gy, nx, ny, lx, ly, r, d, flat }: the constrained point, the unit normal of the fold (pointing at the side that lifts), a point on the line where the paper starts to lift, the radius it curls around, and the distance moved.
/// @param {real} pw
/// @param {real} ph
/// @param {real} grab_v
/// @param {real} gx
/// @param {real} gy
/// @param {real} sharpness  0..1: how tightly the paper curls (default 0.5).
/// @returns {struct}
function fol_leaf_pose(_pw, _ph, _gv, _gx, _gy, _sharp = 0.5) {
    _pw = max(1, fol__n(_pw, 1)); _ph = max(1, fol__n(_ph, 1));
    _gv = clamp(fol__n(_gv, _ph), 0, _ph); _gx = fol__n(_gx, _pw); _gy = fol__n(_gy, _gv);
    _sharp = clamp(fol__n(_sharp, 0.5), 0, 1);
    // the page may not tear: the dragged point stays within reach of both ends of the spine
    var _rt = point_distance(0, 0, _pw, _gv), _rb = point_distance(0, _ph, _pw, _gv);
    repeat (4) {
        var _d1 = point_distance(0, _ph, _gx, _gy);
        if (_d1 > _rb) { _gx = _gx * _rb / _d1; _gy = _ph + (_gy - _ph) * _rb / _d1; }
        var _d0 = point_distance(0, 0, _gx, _gy);
        if (_d0 > _rt) { _gx = _gx * _rt / _d0; _gy = _gy * _rt / _d0; }
    }
    var _dx = _pw - _gx, _dy = _gv - _gy, _D = sqrt(_dx * _dx + _dy * _dy);
    if (_D < 0.5) return { gx: _pw, gy: _gv, nx: 1, ny: 0, lx: _pw, ly: _gv, r: 0, d: 0, flat: true };
    var _nx = _dx / _D, _ny = _dy / _D;
    // the radius: grows with the turn, never more than D / pi (the corner must reach its half turn), and shrinks to nothing at the spine
    var _r = min(_pw * lerp(0.16, 0.05, _sharp), _D * 0.22, _D / pi);
    var _mx = (_pw + _gx) * 0.5, _my = (_gv + _gy) * 0.5;
    var _st = (0 - _mx) * _nx + (0 - _my) * _ny, _sb = (0 - _mx) * _nx + (_ph - _my) * _ny; // where each spine end sits relative to the fold midline (<= 0 by the constraint)
    _r = max(0, min(_r, -2 * _st / pi, -2 * _sb / pi));
    var _s0 = (_D + pi * _r) * 0.5;
    return { gx: _gx, gy: _gy, nx: _nx, ny: _ny, lx: _pw - _s0 * _nx, ly: _gv - _s0 * _ny, r: _r, d: _D, flat: false };
}
/// @function fol_leaf_map(pose, x, y)
/// @description Where a point of the flat leaf lands once the leaf is curled: [x, y, height, side, angle]. side is 1 where the front of the leaf faces up and -1 where its back does; angle is how far round the curl the point has gone (0 flat, pi lying back down).
/// @param {struct} pose  From fol_leaf_pose.
/// @param {real} x
/// @param {real} y
/// @returns {array}
function fol_leaf_map(_P, _x, _y) {
    _x = fol__n(_x, 0); _y = fol__n(_y, 0);
    if (!fol__is_pose(_P) || _P.flat) return [_x, _y, 0, 1, 0];
    var _s = (_x - _P.lx) * _P.nx + (_y - _P.ly) * _P.ny;
    if (_s <= 0) return [_x, _y, 0, 1, 0];
    var _r = _P.r;
    if (_r > 0.0001 && _s < pi * _r) {
        var _a = _s / _r, _o = _r * sin(_a) - _s;
        return [_x + _o * _P.nx, _y + _o * _P.ny, _r * (1 - cos(_a)), (_a < pi * 0.5) ? 1 : -1, _a];
    }
    var _o2 = -(2 * _s - pi * _r);
    return [_x + _o2 * _P.nx, _y + _o2 * _P.ny, 2 * _r, -1, pi];
}
/// @function fol__is_pose(value)
/// @description Internal. Is this a pose made by fol_leaf_pose?
function fol__is_pose(_v) { return is_struct(_v) && variable_struct_exists(_v, "flat") && variable_struct_exists(_v, "lx") && variable_struct_exists(_v, "r"); }
/// @function fol__clip_half(points, nx, ny, c, keep_above)
/// @description Internal. Sutherland-Hodgman: keep the part of a convex outline where (p . n) >= c (or <= c).
function fol__clip_half(_p, _nx, _ny, _c, _above) {
    var _n = array_length(_p) div 2, _o = [];
    if (_n == 0) return _o;
    for (var _i = 0; _i < _n; _i++) {
        var _j = (_i + 1) mod _n;
        var _ax = _p[_i * 2], _ay = _p[_i * 2 + 1], _bx = _p[_j * 2], _by = _p[_j * 2 + 1];
        var _da = (_ax * _nx + _ay * _ny) - _c, _db = (_bx * _nx + _by * _ny) - _c;
        if (!_above) { _da = -_da; _db = -_db; }
        if (_da >= 0) array_push(_o, _ax, _ay);
        if ((_da >= 0) != (_db >= 0)) { var _t = _da / (_da - _db); array_push(_o, _ax + (_bx - _ax) * _t, _ay + (_by - _ay) * _t); }
    }
    return _o;
}
/// @function fol_leaf_bands(pose, pw, ph, bands)
/// @description The leaf cut into pieces along the fold, each piece flat enough to draw as triangles: [{ pts (leaf-space outline), side (1 front, -1 back), a0, a1 (curl angles) }, ...]. The curl is cut at exactly a quarter turn, so no piece has both faces showing. The flat part is first, the piece lying back down last.
/// @param {struct} pose
/// @param {real} pw
/// @param {real} ph
/// @param {real} bands  How many pieces the curl is cut into (an even number; default 12).
/// @returns {array}
function fol_leaf_bands(_P, _pw, _ph, _nb = 12) {
    _pw = clamp(fol__n(_pw, 1), 1, 8192); _ph = clamp(fol__n(_ph, 1), 1, 8192);
    var _rect = [0, 0, _pw, 0, _pw, _ph, 0, _ph], _out = [];
    if (!fol__is_pose(_P) || _P.flat) { array_push(_out, { pts: _rect, side: 1, a0: 0, a1: 0 }); return _out; }
    _nb = clamp(fol__n(_nb, 12), 2, 64);
    _nb = max(2, floor(fol__n(_nb, 12) / 2) * 2);
    var _c0 = _P.lx * _P.nx + _P.ly * _P.ny; // the lift line as p . n = c0
    var _flat = fol__clip_half(_rect, _P.nx, _P.ny, _c0, false);
    if (array_length(_flat) >= 6) array_push(_out, { pts: _flat, side: 1, a0: 0, a1: 0 });
    if (_P.r > 0.25) {
        for (var _k = 0; _k < _nb; _k++) {
            var _a0 = _k / _nb * pi, _a1 = (_k + 1) / _nb * pi;
            var _q = fol__clip_half(_rect, _P.nx, _P.ny, _c0 + _a0 * _P.r, true);
            _q = fol__clip_half(_q, _P.nx, _P.ny, _c0 + _a1 * _P.r, false);
            if (array_length(_q) >= 6 && abs(fol__area(_q)) > 0.01) array_push(_out, { pts: _q, side: (_a1 <= pi * 0.5 + 0.0001) ? 1 : -1, a0: _a0, a1: _a1 });
        }
    }
    // with no curl worth cutting, the part lying back down starts at the lift line itself (or a sliver of page would be missing)
    var _flap = fol__clip_half(_rect, _P.nx, _P.ny, (_P.r > 0.25) ? (_c0 + pi * _P.r) : _c0, true);
    if (array_length(_flap) >= 6 && abs(fol__area(_flap)) > 0.01) array_push(_out, { pts: _flap, side: -1, a0: pi, a1: pi });
    return _out;
}
/// @function fol_leaf_shade(pose, angle, side, sx)
/// @description How bright the paper is at a point of the curl, 1 = flat paper under the lamp (upper left, high). Above 1 is a highlight. sx is +1 for a leaf on the right of the spine, -1 on the left.
/// @param {struct} pose
/// @param {real} angle
/// @param {real} side
/// @param {real} sx
/// @returns {real}
function fol_leaf_shade(_P, _a, _side, _sx) {
    _a = fol__n(_a, 0); _side = (fol__n(_side, 1) < 0) ? -1 : 1; _sx = (fol__n(_sx, 1) < 0) ? -1 : 1;
    if (!fol__is_pose(_P) || _P.flat || _a <= 0) return 1;
    // the paper's normal, front face: (-sin a * n, cos a); the back face that shows is its opposite
    var _nx = -sin(_a) * _P.nx * _sx, _ny = -sin(_a) * _P.ny, _nz = cos(_a);
    if (_side < 0) { _nx = -_nx; _ny = -_ny; _nz = -_nz; }
    var _lx = -0.42, _ly = -0.50, _lz = 0.757; // toward the lamp, unit length
    var _flat = _lz;
    var _d = (_nx * _lx + _ny * _ly + _nz * _lz) / _flat;
    var _amb = (_side < 0) ? 0.86 : 1; // the back of a leaf has the lamp's light through one less sheet
    return clamp((0.3 + 0.7 * _d) * _amb, 0.42, 1.18);
}

// ------------------------------------------------------------------------------------------------ the turn: the state machine

/// @function fol__leaf_new(book, dir, grab_v, mode)
/// @description Internal. A leaf starts to turn: dir 1 = forward (a right-hand page goes over to the left), -1 = back.
function fol__leaf_new(_b, _dir, _gv, _mode) {
    return { dir: _dir, gv: _gv, gx: _b.pw, gy: _gv, t: 0, mode: _mode, vx: 0, vy: 0, target: 1, from: _b.spread, rest_v: _gv, done: false, life: 0 };
}
/// @function fol__can_turn(book, dir)
/// @description Internal. Is there a spread to turn to?
function fol__can_turn(_b, _dir) {
    var _n = fol_book_spreads(_b);
    if (_dir > 0) return _b.spread < _n - 1;
    return _b.spread > 0;
}
/// @function fol_book_next(book)
/// @description Turn one page forward (queued if a leaf is already turning).
/// @param {struct} book
/// @returns {bool} True when a turn started or was queued.
function fol_book_next(_b) { return fol__request(_b, 1); }
/// @function fol_book_prev(book)
/// @description Turn one page back (queued if a leaf is already turning).
/// @param {struct} book
/// @returns {bool}
function fol_book_prev(_b) { return fol__request(_b, -1); }
/// @function fol__request(book, dir)
/// @description Internal. Start an automatic turn, or queue it behind the one in motion.
function fol__request(_b, _dir) {
    if (!fol__is_book(_b)) return false;
    fol__ready(_b);
    var _pending = _b.spread + _b.queue + ((is_struct(_b.leaf) && _b.leaf.target == 1) ? _b.leaf.dir : 0);
    var _to = _pending + _dir;
    if (_to < 0 || _to > fol_book_spreads(_b) - 1) return false;
    if (is_struct(_b.leaf) || is_struct(_b.drag)) { _b.queue += _dir; return true; }
    _b.leaf = fol__leaf_new(_b, _dir, _b.ph * 0.97, "auto");
    return true;
}
/// @function fol_book_goto(book, page, instant)
/// @description Open the book at a page. instant false (default) riffles there a page at a time (up to six turns; a longer journey jumps most of the way first).
/// @param {struct} book
/// @param {real} page
/// @param {bool} instant
/// @returns {bool}
function fol_book_goto(_b, _page, _instant = false) {
    if (!fol__is_book(_b)) return false;
    fol__ready(_b);
    var _p = floor(fol__n(_page, -1));
    if (_p < 0 || _p >= array_length(_b.pages)) return false;
    var _to = fol_page_spread(_p);
    if (_instant == true) { _b.leaf = undefined; _b.drag = undefined; _b.queue = 0; _b.spread = _to; return true; }
    var _from = _b.spread + _b.queue + ((is_struct(_b.leaf) && _b.leaf.target == 1) ? _b.leaf.dir : 0);
    var _d = _to - _from;
    if (abs(_d) > 6 && !is_struct(_b.leaf)) { _b.spread = _to - sign(_d) * 6; _d = sign(_d) * 6; }
    if (_d == 0) return true;
    if (!is_struct(_b.leaf)) { _b.leaf = fol__leaf_new(_b, sign(_d), _b.ph * 0.97, "auto"); _d -= sign(_d); }
    _b.queue += _d;
    return true;
}
/// @function fol_book_turning(book)
/// @description Is a leaf in motion (or held by the reader)?
/// @param {struct} book
/// @returns {bool}
function fol_book_turning(_b) { return fol__is_book(_b) && (is_struct(_b.leaf) || _b.queue != 0); }
/// @function fol__ease(t)
/// @description Internal. The automatic turn's progress curve: it starts gently, as a lifted corner does.
function fol__ease(_t) { _t = clamp(_t, 0, 1); return _t * _t * (3 - 2 * _t); }
/// @function fol_book_step(book, dt)
/// @description Advance the leaf in motion by dt seconds (default: one frame of the game's speed). Call once a frame.
/// @param {struct} book
/// @param {real} dt
/// @returns {bool} True while anything is moving.
function fol_book_step(_b, _dt = undefined) {
    if (!fol__is_book(_b)) return false;
    fol__ready(_b);
    var _h = is_undefined(_dt) ? 1 / max(1, game_get_speed(gamespeed_fps)) : clamp(fol__n(_dt, 1 / 60), 0, 0.25);
    // the hover lift eases toward its target
    var _ht = (_b.hover.side != 0 && !is_struct(_b.leaf) && !is_struct(_b.drag)) ? 1 : 0;
    _b.hover.amt += (_ht - _b.hover.amt) * min(1, _h * 12);
    if (!is_struct(_b.leaf) && _b.queue != 0 && !is_struct(_b.drag)) {
        var _d = sign(_b.queue);
        if (fol__can_turn(_b, _d)) { _b.leaf = fol__leaf_new(_b, _d, _b.ph * 0.97, "auto"); _b.queue -= _d; }
        else _b.queue = 0;
    }
    var _L = _b.leaf;
    if (!is_struct(_L)) return _b.hover.amt > 0.01;
    _L.life += _h;
    var _pw = _b.pw;
    if (_L.mode == "auto") {
        var _speed = 1 / _b.turn_time;
        if (abs(_b.queue) > 0) _speed *= 1.9; // a riffle turns faster
        _L.t = min(1, _L.t + _h * _speed);
        var _e = fol__ease(_L.t);
        _L.gx = _pw - 2 * _pw * _e;
        // the corner rises a little as it crosses, most early in the turn: lifted too far, the fold tilts and the leaf swings out past the head of the book
        _L.gy = _L.gv + (_b.ph * 0.5 - _L.gv) * 0.14 * sin(pi * _L.t) * (1.25 - 0.5 * _L.t);
        if (_L.t >= 1) fol__leaf_land(_b, true);
    } else if (_L.mode == "settle") {
        // a critically damped spring toward the side it was let go on
        var _tx = (_L.target == 1) ? -_pw : _pw, _ty = _L.rest_v;
        var _w = 15, _k = _w * _w, _c = 2 * _w;
        var _steps = max(1, ceil(_h / (1 / 240)));
        var _hh = _h / _steps;
        repeat (_steps) {
            _L.vx += (-_k * (_L.gx - _tx) - _c * _L.vx) * _hh; _L.vy += (-_k * (_L.gy - _ty) - _c * _L.vy) * _hh;
            _L.gx += _L.vx * _hh; _L.gy += _L.vy * _hh;
        }
        _L.t = clamp((_pw - _L.gx) / (2 * _pw), 0, 1);
        if (abs(_L.gx - _tx) < 0.6 && abs(_L.gy - _ty) < 0.6 && abs(_L.vx) + abs(_L.vy) < 8) fol__leaf_land(_b, _L.target == 1);
        else if (_L.life > 4) fol__leaf_land(_b, _L.target == 1);
    }
    return true;
}
/// @function fol__leaf_land(book, completed)
/// @description Internal. The leaf comes to rest: on the far side (the spread changes) or back where it started.
function fol__leaf_land(_b, _done) {
    var _L = _b.leaf;
    _b.leaf = undefined;
    if (!_done) return;
    var _from = _b.spread;
    _b.spread = clamp(_b.spread + _L.dir, 0, fol_book_spreads(_b) - 1);
    if (fol__callable(_b.on_turn) && _b.spread != _from) _b.on_turn(_b, _from, _b.spread);
}
/// @function fol_book_leaf(book)
/// @description The leaf in motion as { dir, gx, gy, gv, t, mode } in leaf space, or undefined. For drawing your own effects over a turn.
/// @param {struct} book
/// @returns {struct|undefined}
function fol_book_leaf(_b) { if (!fol__is_book(_b)) return undefined; return _b.leaf; }

// ------------------------------------------------------------------------------------------------ the reader's hand

/// @function fol_book_place(book, x, y, scale)
/// @description Where the book lies on screen: the top-left corner of the left-hand page, and the scale it is drawn at. fol_book_draw sets this for you; set it yourself to feed input before the first draw.
/// @param {struct} book
/// @param {real} x
/// @param {real} y
/// @param {real} scale
/// @returns {bool}
function fol_book_place(_b, _x, _y, _k = 1) {
    if (!fol__is_book(_b)) return false;
    _b.place.x = fol__n(_x, 0); _b.place.y = fol__n(_y, 0); _b.place.k = max(0.05, fol__n(_k, 1));
    return true;
}
/// @function fol_book_to_leaf(book, side, x, y)
/// @description A screen point in leaf space for the leaf on one side of the spine (side 1 right, -1 left): [x from the spine, y from the top of the page].
/// @param {struct} book
/// @param {real} side
/// @param {real} x
/// @param {real} y
/// @returns {array}
function fol_book_to_leaf(_b, _side, _x, _y) {
    if (!fol__is_book(_b)) return [0, 0];
    _side = (fol__n(_side, 1) < 0) ? -1 : 1; _x = fol__n(_x, 0); _y = fol__n(_y, 0);
    var _k = _b.place.k, _sp = _b.place.x + _b.pw * _k;
    return [(_x - _sp) / _k * _side, (_y - _b.place.y) / _k];
}
/// @function fol_book_hit(book, x, y)
/// @description Which page lies under a screen point: { page, side, x, y } (page-space x and y from the page's own top-left), or undefined. side 1 right, -1 left. An endpaper reports page -1.
/// @param {struct} book
/// @param {real} x
/// @param {real} y
/// @returns {struct|undefined}
function fol_book_hit(_b, _x, _y) {
    if (!fol__is_book(_b)) return undefined;
    fol__ready(_b);
    var _k = _b.place.k, _px = (fol__n(_x, -99999) - _b.place.x) / _k, _py = (fol__n(_y, -99999) - _b.place.y) / _k;
    if (_py < 0 || _py > _b.ph || _px < 0 || _px > _b.pw * 2) return undefined;
    var _pp = fol_spread_pages(_b, _b.spread);
    if (_px < _b.pw) return { page: _pp[0], side: -1, x: _px, y: _py };
    return { page: _pp[1], side: 1, x: _px - _b.pw, y: _py };
}
/// @function fol_book_feed(book, input)
/// @description One frame of the reader's hand, as plain numbers and flags, so it runs without a device and in a test. input: { mx, my (screen), down, pressed, released (the pointer button), next, prev (one press each) }. Grab the fore-edge or a corner and drag to turn a page by hand; let go past the spine (or flick) and it falls over, short of it and it springs back. A click on a page turns it. Hovering near a corner lifts it a little.
/// @param {struct} book
/// @param {struct} input
/// @returns {bool}
function fol_book_feed(_b, _in) {
    if (!fol__is_book(_b) || !is_struct(_in)) return false;
    fol__ready(_b);
    var _mx = fol__n(fol__opt(_in, "mx", -99999), -99999), _my = fol__n(fol__opt(_in, "my", -99999), -99999);
    var _down = fol__opt(_in, "down", false) == true, _pr = fol__opt(_in, "pressed", false) == true, _rl = fol__opt(_in, "released", false) == true;
    if (fol__opt(_in, "next", false) == true) fol_book_next(_b);
    if (fol__opt(_in, "prev", false) == true) fol_book_prev(_b);
    var _pw = _b.pw, _ph = _b.ph, _zone = _pw * 0.16;
    var _R = fol_book_to_leaf(_b, 1, _mx, _my), _Lf = fol_book_to_leaf(_b, -1, _mx, _my);
    // hover: near a fore-edge corner of a page that can turn
    _b.hover.side = 0;
    if (!_down && !is_struct(_b.leaf)) {
        if (_R[0] > _pw - _zone && _R[0] < _pw + 6 && _R[1] > _ph * 0.62 && _R[1] < _ph + 6 && fol__can_turn(_b, 1)) { _b.hover.side = 1; _b.hover.v = clamp(_R[1], 0, _ph); }
        else if (_Lf[0] > _pw - _zone && _Lf[0] < _pw + 6 && _Lf[1] > _ph * 0.62 && _Lf[1] < _ph + 6 && fol__can_turn(_b, -1)) { _b.hover.side = -1; _b.hover.v = clamp(_Lf[1], 0, _ph); }
    }
    // a ribbon's tail or a thumb tab under the pointer opens the book at its page (their boxes are written by fol_book_draw)
    if (_pr && !is_struct(_b.drag) && variable_struct_exists(_b, "hot")) {
        for (var _h = array_length(_b.hot) - 1; _h >= 0; _h--) {
            var _hs = _b.hot[_h];
            if (_mx >= _hs.x0 && _mx <= _hs.x1 && _my >= _hs.y0 && _my <= _hs.y1) { fol_book_goto(_b, _hs.page); _pr = false; break; }
        }
    }
    if (_pr && !is_struct(_b.leaf) && !is_struct(_b.drag)) {
        var _side = 0, _P = _R;
        if (_R[0] >= 0 && _R[0] <= _pw + 6 && _R[1] >= -6 && _R[1] <= _ph + 6) { _side = 1; _P = _R; }
        else if (_Lf[0] >= 0 && _Lf[0] <= _pw + 6 && _Lf[1] >= -6 && _Lf[1] <= _ph + 6) { _side = -1; _P = _Lf; }
        if (_side != 0 && fol__can_turn(_b, _side)) {
            var _edge = _P[0] > _pw - _zone;
            _b.drag = { side: _side, x0: _P[0], y0: _P[1], edge: _edge, moved: 0, lastx: _P[0], vx: 0 };
            if (_edge) {
                var _gv = clamp(_P[1], 0, _ph);
                if (_gv > _ph * 0.8) _gv = _ph; else if (_gv < _ph * 0.2) _gv = 0; // near a corner, take the corner
                _b.leaf = fol__leaf_new(_b, _side, _gv, "drag");
                _b.leaf.gx = clamp(_P[0], -_pw, _pw); _b.leaf.gy = _P[1];
                _b.leaf.offx = _pw - _P[0]; _b.leaf.offy = _gv - _P[1];
            }
        }
    }
    if (is_struct(_b.drag)) {
        var _D = _b.drag, _Q = fol_book_to_leaf(_b, _D.side, _mx, _my);
        _D.moved = max(_D.moved, point_distance(_D.x0, _D.y0, _Q[0], _Q[1]));
        // the hand's speed across the page, from frames where it moved (the frame a button is let go often reports no movement)
        var _dvx = _Q[0] - _D.lastx;
        if (_dvx != 0) _D.vx = _D.vx * 0.5 + _dvx * 0.5;
        _D.lastx = _Q[0];
        if (!_D.edge && _D.moved > _pw * 0.05 && !is_struct(_b.leaf)) {
            // a drag that began inside the page grabs the edge at that height
            _b.leaf = fol__leaf_new(_b, _D.side, clamp(_D.y0, 0, _ph), "drag");
            _b.leaf.offx = _pw - _D.x0; _b.leaf.offy = 0; _D.edge = true;
        }
        if (is_struct(_b.leaf) && _b.leaf.mode == "drag") {
            _b.leaf.gx = clamp(_Q[0] + _b.leaf.offx, -_pw * 1.05, _pw);
            _b.leaf.gy = _Q[1] + _b.leaf.offy;
            _b.leaf.t = clamp((_pw - _b.leaf.gx) / (2 * _pw), 0, 1);
        }
        if (_rl || !_down) {
            if (is_struct(_b.leaf) && _b.leaf.mode == "drag" && _D.moved < _pw * 0.03) {
                // a click on the edge: the page turns by itself from where it was taken
                _b.leaf.mode = "auto"; _b.leaf.t = 0;
            } else if (is_struct(_b.leaf) && _b.leaf.mode == "drag") {
                var _flick = _D.vx < -_pw * 0.035;
                var _back = _D.vx > _pw * 0.035;
                var _go = (_b.leaf.gx < 0 || _flick) && !_back;
                _b.leaf.mode = "settle"; _b.leaf.target = _go ? 1 : 0;
                _b.leaf.vx = _D.vx * 30; _b.leaf.vy = 0; _b.leaf.rest_v = _b.leaf.gv;
            } else if (_D.moved < _pw * 0.03) {
                // a click: turn the page that was clicked
                if (_D.side > 0) fol_book_next(_b); else fol_book_prev(_b);
            }
            _b.drag = undefined;
        }
    }
    return true;
}
