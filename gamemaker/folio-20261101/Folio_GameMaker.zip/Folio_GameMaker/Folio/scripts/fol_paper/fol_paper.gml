/// fol_paper.gml - the 48 papers. Each look is a recipe: a STOCK (eight: ivory laid, cream wove, rag white, vellum, parchment,
/// kraft, ledger green, midnight) under a RULING (six: blank, lined, grid, ledger, staff, dots; every stock carries each ruling once,
/// so no two looks share both), plus an edge (cut, deckle, gilt), an age (new, worn, foxed), a frame, a page-number device, a
/// headpiece and a drop-initial style. The paper itself (colour, mottle, fibres, laid lines, toning, foxing, the torn deckle) is
/// baked once per look and page size into a sprite; everything that depends on the text (ruling, frame, running head, number) is
/// drawn when a page is composed, so ruled lines always sit under the text you set.
///
/// Folio - A Page-Turning Book for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function fol__stocks()
/// @description Internal. The eight stocks: base colour (Oklch), ink, ruling colour, grain kind, mottle and fibre strength.
function fol__stocks() {
    if (variable_global_exists("fol__stock_t")) return global.fol__stock_t;
    global.fol__stock_t = {
        ivory:    { name: "ivory laid",   L: 0.925, C: 0.030, h: 84,  ink: [0.25, 0.035, 45],  rule: [0.62, 0.05, 40],  grain: "laid",   mottle: 0.05, fibre: 0.07 },
        cream:    { name: "cream wove",   L: 0.912, C: 0.044, h: 80,  ink: [0.22, 0.020, 50],  rule: [0.66, 0.06, 245], grain: "wove",   mottle: 0.04, fibre: 0.06 },
        rag:      { name: "rag white",    L: 0.962, C: 0.010, h: 95,  ink: [0.19, 0.012, 262], rule: [0.70, 0.07, 240], grain: "rag",    mottle: 0.03, fibre: 0.08 },
        vellum:   { name: "vellum",       L: 0.880, C: 0.050, h: 72,  ink: [0.27, 0.055, 38],  rule: [0.60, 0.05, 45],  grain: "vellum", mottle: 0.10, fibre: 0.05 },
        parch:    { name: "parchment",    L: 0.838, C: 0.066, h: 74,  ink: [0.25, 0.060, 32],  rule: [0.56, 0.06, 45],  grain: "parch",  mottle: 0.14, fibre: 0.06 },
        kraft:    { name: "kraft",        L: 0.700, C: 0.072, h: 64,  ink: [0.17, 0.030, 45],  rule: [0.48, 0.05, 50],  grain: "kraft",  mottle: 0.07, fibre: 0.16 },
        ledger:   { name: "ledger green", L: 0.915, C: 0.034, h: 132, ink: [0.25, 0.050, 258], rule: [0.62, 0.07, 160], grain: "wove",   mottle: 0.03, fibre: 0.05 },
        midnight: { name: "midnight",     L: 0.205, C: 0.020, h: 265, ink: [0.88, 0.035, 85],  rule: [0.42, 0.03, 250], grain: "black",  mottle: 0.05, fibre: 0.10 }
    };
    return global.fol__stock_t;
}
/// @function fol__accent(name)
/// @description Internal. The accent (rubric) colours as Oklch.
function fol__accent(_n) {
    switch (_n) {
        case "rubric": return [0.50, 0.165, 28];
        case "lapis": return [0.47, 0.130, 262];
        case "verdigris": return [0.55, 0.095, 172];
        case "violet": return [0.46, 0.125, 312];
        case "gold": return [0.74, 0.125, 82];
        case "silver": return [0.80, 0.015, 250];
    }
    return [0.50, 0.15, 28];
}
/// @function fol__looks()
/// @description Internal. The 48 looks, in catalogue order. Fields: name, stock, ruling, edge, age, frame, folio, accent, head, init.
function fol__looks() {
    if (variable_global_exists("fol__look_t")) return global.fol__look_t;
    var _rows = [
        // ivory laid
        ["Monster Manual", "ivory", "blank", "cut", "worn", "double", "corner", "rubric", "knot", "boxed"],
        ["Captain's Log", "ivory", "lined", "cut", "foxed", "rule", "ruled", "lapis", "rule", "boxed"],
        ["Surveyor's Book", "ivory", "grid", "deckle", "worn", "rule", "corner", "lapis", "stars", "plain"],
        ["Ship's Manifest", "ivory", "ledger", "cut", "worn", "none", "corner", "rubric", "rule", "plain"],
        ["Hymnal", "ivory", "staff", "gilt", "new", "double", "ruled", "rubric", "fleuron", "boxed"],
        ["Cartographer's Notes", "ivory", "dots", "deckle", "worn", "margin", "plain", "verdigris", "stars", "plain"],
        // cream wove
        ["Fairy Tale", "cream", "blank", "gilt", "new", "vine", "lozenge", "rubric", "vine", "illuminated"],
        ["Field Journal", "cream", "lined", "deckle", "worn", "none", "corner", "verdigris", "rule", "plain"],
        ["Puzzle Book", "cream", "grid", "cut", "new", "double", "ruled", "violet", "stars", "boxed"],
        ["Apothecary Index", "cream", "ledger", "cut", "foxed", "double", "ruled", "verdigris", "fleuron", "boxed"],
        ["Lullaby Book", "cream", "staff", "deckle", "new", "vine", "lozenge", "violet", "vine", "flourish"],
        ["Recipe Book", "cream", "dots", "cut", "foxed", "margin", "corner", "rubric", "vine", "flourish"],
        // rag white
        ["Prayer Book", "rag", "blank", "gilt", "new", "rule", "ruled", "rubric", "fleuron", "illuminated"],
        ["School Primer", "rag", "lined", "cut", "new", "double", "plain", "lapis", "stars", "boxed"],
        ["Lab Notebook", "rag", "grid", "cut", "new", "margin", "corner", "rubric", "rule", "plain"],
        ["Census Roll", "rag", "ledger", "cut", "worn", "rule", "corner", "lapis", "rule", "plain"],
        ["Book of Songs", "rag", "staff", "gilt", "worn", "double", "lozenge", "violet", "fleuron", "flourish"],
        ["Herbarium Notes", "rag", "dots", "deckle", "worn", "vine", "plain", "verdigris", "vine", "flourish"],
        // vellum
        ["Bestiary", "vellum", "blank", "deckle", "foxed", "vine", "lozenge", "rubric", "vine", "flourish"],
        ["Pilgrim's Diary", "vellum", "lined", "deckle", "worn", "rule", "plain", "lapis", "stars", "plain"],
        ["Alchemist's Workbook", "vellum", "grid", "deckle", "foxed", "margin", "lozenge", "rubric", "knot", "flourish"],
        ["Tithe Register", "vellum", "ledger", "gilt", "worn", "double", "ruled", "rubric", "knot", "boxed"],
        ["Psalter", "vellum", "staff", "gilt", "new", "illuminated", "ruled", "gold", "vine", "illuminated"],
        ["Codex", "vellum", "dots", "deckle", "worn", "double", "lozenge", "rubric", "knot", "illuminated"],
        // parchment
        ["Spellbook", "parch", "blank", "deckle", "foxed", "illuminated", "lozenge", "violet", "knot", "illuminated"],
        ["Quest Log", "parch", "lined", "cut", "worn", "rule", "ruled", "rubric", "fleuron", "boxed"],
        ["Rune Lexicon", "parch", "grid", "deckle", "worn", "double", "lozenge", "verdigris", "knot", "boxed"],
        ["Tavern Ledger", "parch", "ledger", "cut", "foxed", "rule", "ruled", "rubric", "rule", "boxed"],
        ["Ballad Book", "parch", "staff", "deckle", "worn", "vine", "plain", "verdigris", "vine", "flourish"],
        ["Chronicle of Kings", "parch", "dots", "gilt", "worn", "double", "ruled", "gold", "knot", "illuminated"],
        // kraft
        ["Sketchbook", "kraft", "blank", "cut", "new", "none", "corner", "violet", "stars", "boxed"],
        ["Detective's Casebook", "kraft", "lined", "cut", "worn", "margin", "corner", "rubric", "rule", "plain"],
        ["Sea Chart Log", "kraft", "grid", "deckle", "foxed", "rule", "lozenge", "lapis", "stars", "boxed"],
        ["Bounty Ledger", "kraft", "ledger", "cut", "foxed", "rule", "corner", "rubric", "rule", "plain"],
        ["Shanty Book", "kraft", "staff", "deckle", "worn", "double", "ruled", "verdigris", "fleuron", "flourish"],
        ["Travel Journal", "kraft", "dots", "deckle", "worn", "none", "corner", "rubric", "stars", "flourish"],
        // ledger green
        ["Gardener's Almanac", "ledger", "blank", "deckle", "worn", "vine", "plain", "verdigris", "vine", "flourish"],
        ["Clerk's Copybook", "ledger", "lined", "cut", "new", "margin", "corner", "lapis", "rule", "boxed"],
        ["Engineer's Notes", "ledger", "grid", "cut", "worn", "rule", "corner", "lapis", "rule", "boxed"],
        ["Account Ledger", "ledger", "ledger", "cut", "new", "double", "ruled", "rubric", "rule", "plain"],
        ["Choirmaster's Book", "ledger", "staff", "gilt", "worn", "double", "lozenge", "rubric", "fleuron", "boxed"],
        ["Merchant's Daybook", "ledger", "dots", "cut", "foxed", "rule", "corner", "rubric", "rule", "boxed"],
        // midnight
        ["Grimoire", "midnight", "blank", "deckle", "worn", "illuminated", "lozenge", "violet", "knot", "illuminated"],
        ["Night Journal", "midnight", "lined", "cut", "new", "none", "corner", "silver", "stars", "plain"],
        ["Observatory Log", "midnight", "grid", "cut", "worn", "rule", "ruled", "silver", "stars", "boxed"],
        ["Thieves' Ledger", "midnight", "ledger", "cut", "foxed", "double", "corner", "gold", "rule", "boxed"],
        ["Starlit Psalms", "midnight", "staff", "gilt", "worn", "double", "lozenge", "gold", "fleuron", "illuminated"],
        ["Star Atlas", "midnight", "dots", "gilt", "new", "rule", "lozenge", "gold", "stars", "illuminated"]
    ];
    var _out = array_create(array_length(_rows));
    for (var _i = 0; _i < array_length(_rows); _i++) {
        var _r = _rows[_i];
        _out[_i] = { index: _i, name: _r[0], stock: _r[1], ruling: _r[2], edge: _r[3], age: _r[4], frame: _r[5], folio: _r[6], accent: _r[7], head: _r[8], init: _r[9] };
    }
    global.fol__look_t = _out;
    return _out;
}
/// @function fol_paper_count()
/// @description How many paper looks there are (48).
/// @returns {real}
function fol_paper_count() { return array_length(fol__looks()); }
/// @function fol_paper_name(index)
/// @description A paper look's name ("Bestiary", "Ship's Manifest", ...), or "" for an index that does not exist.
/// @param {real} index
/// @returns {string}
function fol_paper_name(_i) {
    var _L = fol__looks(), _k = floor(fol__n(_i, -1));
    if (_k < 0 || _k >= array_length(_L)) return "";
    return _L[_k].name;
}
/// @function fol_paper_find(look)
/// @description A paper look's index from its index or its name (case and spaces ignored); -1 when there is no such look.
/// @param {real|string} look
/// @returns {real}
function fol_paper_find(_v) {
    var _L = fol__looks();
    if (is_string(_v)) {
        var _key = string_lower(string_replace_all(_v, " ", ""));
        for (var _i = 0; _i < array_length(_L); _i++) if (string_lower(string_replace_all(_L[_i].name, " ", "")) == _key) return _i;
        return -1;
    }
    var _k = floor(fol__n(_v, -1));
    return (_k >= 0 && _k < array_length(_L)) ? _k : -1;
}
/// @function fol_paper_look(index)
/// @description A paper look's recipe: { name, stock, ruling, edge, age, frame, folio, accent, head, init }. An unknown index gives the first look.
/// @param {real} index
/// @returns {struct}
function fol_paper_look(_i) {
    var _L = fol__looks(), _k = floor(fol__n(_i, 0));
    if (_k < 0 || _k >= array_length(_L)) _k = 0;
    return _L[_k];
}
/// @function fol_book_set_paper(book, look)
/// @description Change a book's paper (index or name). The pages are composed again; the page count can change, because frames set their own margins.
/// @param {struct} book
/// @param {real|string} look
/// @returns {bool} False when the book is not a book or there is no such look.
function fol_book_set_paper(_b, _look) {
    if (!fol__is_book(_b)) return false;
    var _k = fol_paper_find(_look);
    if (_k < 0) return false;
    if (_k != _b.paper) { _b.paper = _k; _b.dirty = true; }
    return true;
}
/// @function fol_paper_colours(index)
/// @description The colours of a look: { paper, ink, rule, accent, dark, light } as GameMaker colours, for drawing your own work in a book's palette.
/// @param {real} index
/// @returns {struct}
function fol_paper_colours(_i) {
    var _lk = fol_paper_look(_i), _st = fol__stocks()[$ _lk.stock], _ac = fol__accent(_lk.accent);
    var _dark = (_st.L < 0.5);
    return {
        paper: fol_oklch(_st.L, _st.C, _st.h),
        ink: fol_oklch(_st.ink[0], _st.ink[1], _st.ink[2]),
        rule: fol_oklch(_st.rule[0], _st.rule[1], _st.rule[2]),
        accent: fol_oklch(_dark ? max(_ac[0], 0.72) : _ac[0], _ac[1], _ac[2]),
        dark: fol_oklch(_st.L - (_dark ? 0.06 : 0.20), _st.C * 1.2, _st.h - 6),
        light: fol_oklch(min(0.99, _st.L + 0.04), _st.C * 0.8, _st.h + 4),
        tone: fol_oklch(_st.L - (_dark ? 0.03 : 0.16), _st.C * 1.6 + 0.02, 62),
        midnight: _dark
    };
}

// ------------------------------------------------------------------------------------------------ the paper itself

/// @function fol__deckle(pw, ph, seed, amp)
/// @description Internal. The page outline, clockwise from the head of the spine. The spine edge is straight; head, fore-edge and tail are torn (amp > 0) or cut (amp 0). [x, y, ...].
function fol__deckle(_pw, _ph, _seed, _amp) {
    var _p = [], _step = 4;
    array_push(_p, 0, 0);
    var _n = max(2, round(_pw / _step));
    // each edge sits between 0.05 and 1.4 amplitudes inside the box: two octaves of noise, the fine one for the fibres
    for (var _i = 1; _i < _n; _i++) { var _x = _i / _n * _pw; array_push(_p, _x, _amp * clamp(0.6 + 0.45 * fol__noise1(_x * 0.09, _seed) + 0.35 * fol__noise1(_x * 0.41, _seed + 3), 0.05, 1.4)); }
    var _m = max(2, round(_ph / _step));
    for (var _i = 0; _i <= _m; _i++) { var _y = _i / _m * _ph; array_push(_p, _pw - _amp * clamp(0.6 + 0.45 * fol__noise1(_y * 0.09, _seed + 7) + 0.35 * fol__noise1(_y * 0.41, _seed + 9), 0.05, 1.4), _y); }
    for (var _i = _n - 1; _i >= 1; _i--) { var _x = _i / _n * _pw; array_push(_p, _x, _ph - _amp * clamp(0.6 + 0.45 * fol__noise1(_x * 0.09, _seed + 13) + 0.35 * fol__noise1(_x * 0.41, _seed + 17), 0.05, 1.4)); }
    array_push(_p, 0, _ph);
    return _p;
}
/// @function fol_paper_sprite(look, w, h, variant, seed)
/// @description A blank sheet of a look's paper as a sprite (premultiplied; draw it with gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha)). It is cached: the same look, size, variant and seed return the same sprite, and fol_art_free deletes them. The spine edge is on the LEFT (a right-hand page); draw it mirrored for a left-hand one.
/// @param {real} look
/// @param {real} w
/// @param {real} h
/// @param {real} variant  0..2: the same paper, foxed and toned differently.
/// @param {real} seed
/// @returns {asset.GMSprite}
function fol_paper_sprite(_look, _w, _h, _var = 0, _seed = 1) {
    var _li = fol_paper_find(_look); if (_li < 0) _li = 0;
    _w = clamp(round(fol__n(_w, 460)), 16, 2048); _h = clamp(round(fol__n(_h, 620)), 16, 2048);
    _var = floor(abs(fol__n(_var, 0))) mod 3; _seed = floor(abs(fol__n(_seed, 1))) mod 100000;
    var _key = "p" + string(_li) + "_" + string(_w) + "x" + string(_h) + "_" + string(_var) + "_" + string(_seed);
    var _c = fol__cache();
    if (variable_struct_exists(_c, _key) && sprite_exists(_c[$ _key])) return _c[$ _key];
    var _t0 = get_timer();
    var _spr = fol__paper_bake(_li, _w, _h, _var, _seed);
    _c[$ _key] = _spr;
    global.fol__last_bake_us = get_timer() - _t0;
    return _spr;
}
/// @function fol__paper_bake(look, w, h, variant, seed)
/// @description Internal. Paint one sheet: base, mottle, fibres, laid lines, toning, foxing, the gilt line, then the torn edge cut clean.
function fol__paper_bake(_li, _w, _h, _var, _seed) {
    var _lk = fol_paper_look(_li), _st = fol__stocks()[$ _lk.stock], _col = fol_paper_colours(_li);
    var _g = fol_rng(_seed * 7919 + _li * 101 + _var * 13 + 5);
    var _ss = (_w * _h > 260000) ? 1 : 2;
    var _bk = fol__bake_begin(_w, _h, _ss);
    var _amp = (_lk.edge == "deckle") ? clamp(min(_w, _h) * 0.012, 2, 7) : 0;
    var _out = fol__deckle(_w, _h, _seed * 31 + _var * 7 + _li, _amp);
    var _dark = _col.midnight;
    fol__b_begin();
    // the sheet
    var _cx = _w * 0.5, _cy = _h * 0.5, _np = array_length(_out) div 2;
    for (var _i = 0; _i < _np; _i++) { var _j = (_i + 1) mod _np; fol__tri(_cx, _cy, _col.paper, 1, _out[_i * 2], _out[_i * 2 + 1], _col.paper, 1, _out[_j * 2], _out[_j * 2 + 1], _col.paper, 1); }
    // mottle: broad soft clouds, darker and lighter
    var _nm = round(18 + 30 * _st.mottle / 0.14);
    for (var _i = 0; _i < _nm; _i++) {
        var _r = min(_w, _h) * (0.08 + 0.22 * fol_rand(_g)), _x = fol_rand(_g) * _w, _y = fol_rand(_g) * _h;
        var _cc = (fol_rand(_g) < 0.55) ? _col.dark : _col.light;
        fol__spot(_x, _y, _r, _cc, _st.mottle * (0.5 + 0.5 * fol_rand(_g)), 16);
    }
    // fibres: a physical size, so a big page is not coarser than a small one
    var _area = _w * _h, _nf = round(_area / 230 * (0.5 + _st.fibre * 4));
    var _fl = 3.2, _fw = 0.8;
    for (var _i = 0; _i < _nf; _i++) {
        var _x = fol_rand(_g) * _w, _y = fol_rand(_g) * _h, _a = fol_rand(_g) * pi * ((_st.grain == "laid") ? 0.25 : 1) + ((_st.grain == "laid") ? -pi * 0.125 : 0);
        var _l = _fl * (0.6 + 1.8 * fol_rand(_g));
        var _cc = (fol_rand(_g) < 0.5) ? _col.dark : _col.light, _al = _st.fibre * (0.5 + 0.8 * fol_rand(_g));
        if (_st.grain == "kraft" && fol_rand(_g) < 0.18) { _cc = fol_oklch(0.42, 0.05, 55); _al = 0.32; }
        if (_st.grain == "black") { _cc = fol_oklch(0.42, 0.02, 250); _al = 0.12 + 0.12 * fol_rand(_g); }
        fol__seg(_x, _y, _x + cos(_a) * _l, _y + sin(_a) * _l, _fw, _cc, _al);
    }
    // vellum: follicle specks in drifts; parchment: darker veining
    if (_st.grain == "vellum" || _st.grain == "parch") {
        var _nd = round(_area / 3200);
        for (var _i = 0; _i < _nd; _i++) {
            var _x = fol_rand(_g) * _w, _y = fol_rand(_g) * _h;
            repeat (3 + floor(fol_rand(_g) * 4)) fol__disc(_x + (fol_rand(_g) - 0.5) * 9, _y + (fol_rand(_g) - 0.5) * 9, 0.55 + fol_rand(_g) * 0.5, _col.dark, 0.20 + 0.15 * fol_rand(_g), 6);
        }
    }
    // laid paper: chain lines and the fine laid lines between them
    if (_st.grain == "laid") {
        var _cp = 25;
        for (var _x = _cp * (0.4 + fol_rand(_g) * 0.5); _x < _w; _x += _cp) fol__seg(_x, 0, _x + 0.6, _h, 1.4, _col.dark, 0.075);
        for (var _y = 1.5; _y < _h; _y += 2.6) fol__seg(0, _y, _w, _y, 0.9, _col.dark, 0.022);
    }
    // toning: the edges darken with age, the lower outer corner most (that is where a thumb turns the page)
    if (_lk.age != "new") {
        var _tw = min(_w, _h) * ((_lk.age == "foxed") ? 0.10 : 0.075), _ta = (_lk.age == "foxed") ? 0.30 : 0.20;
        if (_dark) _ta *= 0.6;
        var _tc = _col.tone;
        fol__quad(0, 0, _tc, _ta, _w, 0, _tc, _ta, _w, _tw, _tc, 0, 0, _tw, _tc, 0);
        fol__quad(0, _h, _tc, _ta, _w, _h, _tc, _ta, _w, _h - _tw, _tc, 0, 0, _h - _tw, _tc, 0);
        fol__quad(_w, 0, _tc, _ta, _w, _h, _tc, _ta, _w - _tw, _h, _tc, 0, _w - _tw, 0, _tc, 0);
        fol__spot(_w, _h, min(_w, _h) * 0.22, _tc, _ta * 0.75, 18);
        fol__spot(_w * (0.3 + 0.4 * fol_rand(_g)), _h * fol_rand(_g), min(_w, _h) * 0.3, _tc, _ta * 0.18, 16);
    }
    // foxing: rust spots, clustered toward the edges, and on some sheets a tide line
    if (_lk.age == "foxed") {
        var _fc = _dark ? fol_oklch(0.40, 0.06, 50) : fol_oklch(0.56, 0.085, 55);
        var _nfx = 26 + floor(fol_rand(_g) * 26);
        for (var _i = 0; _i < _nfx; _i++) {
            var _ex = fol_rand(_g), _x = (_ex < 0.5) ? _w - power(fol_rand(_g), 1.8) * _w * 0.5 : fol_rand(_g) * _w;
            var _y = (fol_rand(_g) < 0.5) ? power(fol_rand(_g), 1.6) * _h * 0.4 : _h - power(fol_rand(_g), 1.6) * _h * 0.5;
            var _r = 0.8 + power(fol_rand(_g), 2) * 3.6;
            fol__spot(_x, _y, _r * 1.8, _fc, 0.22, 10);
            fol__disc(_x, _y, _r * 0.6, _fc, 0.35, 8);
        }
        if (_var == 1) {
            var _tx = _w * (0.55 + 0.3 * fol_rand(_g)), _ty = _h * (0.15 + 0.6 * fol_rand(_g)), _tr = min(_w, _h) * (0.10 + 0.08 * fol_rand(_g)), _ring = [];
            for (var _i = 0; _i < 40; _i++) { var _a = _i / 40 * 2 * pi, _rr = _tr * (1 + 0.16 * fol__noise1(_i * 0.5, _seed + _li)); array_push(_ring, _tx + cos(_a) * _rr, _ty + sin(_a) * _rr * 0.86); }
            fol__fill(_ring, _fc, 0.05);
            fol__stroke(_ring, 1.6, _fc, 0.20, true);
        }
    }
    // a gilt edge catches the light along head, fore-edge and tail
    if (_lk.edge == "gilt") {
        var _gc = fol_oklch(0.76, 0.12, 82), _gd = fol_oklch(0.56, 0.10, 70);
        fol__quad(0, 0, _gc, 0.9, _w, 0, _gc, 0.9, _w, 2.2, _gd, 0, 0, 2.2, _gd, 0);
        fol__quad(0, _h, _gd, 0.9, _w, _h, _gd, 0.9, _w, _h - 2.2, _gd, 0, 0, _h - 2.2, _gd, 0);
        fol__quad(_w, 0, _gc, 0.9, _w, _h, _gd, 0.9, _w - 2.2, _h, _gd, 0, _w - 2.2, 0, _gc, 0);
    }
    fol__b_end();
    // cut the torn edge clean: the painted sheet is multiplied by a mask of its own outline (marks that reached past it go)
    if (_amp > 0) {
        surface_reset_target();
        var _ms = surface_create(_w * _ss, _h * _ss);
        surface_set_target(_ms);
        draw_clear_alpha(c_black, 0);
        gpu_set_blendmode_ext(bm_one, bm_zero);
        fol__b_begin();
        for (var _i = 0; _i < _np; _i++) { var _j = (_i + 1) mod _np; fol__tri(_cx, _cy, c_white, 1, _out[_i * 2], _out[_i * 2 + 1], c_white, 1, _out[_j * 2], _out[_j * 2 + 1], c_white, 1); }
        fol__b_end();
        matrix_set(matrix_world, matrix_build_identity());
        gpu_set_blendmode_ext_sepalpha(bm_dest_alpha, bm_zero, bm_dest_alpha, bm_zero);
        draw_surface(_bk.s, 0, 0);
        surface_reset_target();
        surface_set_target(_bk.s);
        gpu_set_blendmode_ext(bm_one, bm_zero);
        draw_surface(_ms, 0, 0);
        surface_free(_ms);
        matrix_set(matrix_world, matrix_build(0, 0, 0, 0, 0, 0, _ss, _ss, 1));
        gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    }
    return fol__bake_end(_bk);
}

// ------------------------------------------------------------------------------------------------ ornaments

/// @function fol__leaf_pts(len, width)
/// @description Internal. An ivy leaf (the printer's hedera) pointing along +x from the origin: a heart with a drawn-out tip. Concave at the stalk, so it is filled by ear clipping.
function fol__leaf_pts(_l, _wd) {
    var _p = [];
    fol__bez(0, 0, _l * 0.05, -_wd * 0.9, _l * 0.55, -_wd * 1.05, _l, 0, 8, _p);
    fol__bez(_l, 0, _l * 0.55, _wd * 1.05, _l * 0.05, _wd * 0.9, 0, 0, 8, _p);
    array_pop(_p); array_pop(_p);
    // the notch at the stalk
    array_push(_p, _l * 0.12, 0);
    return _p;
}
/// @function fol__fleuron(x, y, size, col, alpha, angle)
/// @description Internal. A fleuron: an ivy leaf with a curled stalk, the printer's ornament since the fifteenth century.
function fol__fleuron(_x, _y, _s, _c, _a, _ang = 0) {
    var _lf = fol__xform(fol__leaf_pts(_s, _s * 0.42), _x, _y, 1, _ang);
    fol__fill(_lf, _c, _a);
    var _st = [];
    var _ca = cos(_ang), _sa = sin(_ang);
    for (var _i = 0; _i <= 10; _i++) {
        var _t = _i / 10, _ax = -_s * 0.42 * _t, _ay = _s * 0.30 * sin(_t * pi * 1.15);
        array_push(_st, _x + _ax * _ca - _ay * _sa, _y + _ax * _sa + _ay * _ca);
    }
    fol__stroke(_st, max(1, _s * 0.07), _c, _a);
}
/// @function fol__headpiece(look, x, y, w, unit, colours)
/// @description Internal. The band above a chapter title.
function fol__headpiece(_lk, _x, _y, _w, _u, _col) {
    var _cx = _x + _w * 0.5, _ac = _col.accent, _ink = _col.ink;
    switch (_lk.head) {
        case "rule":
            fol__seg(_x + _w * 0.18, _y - 1.5, _x + _w * 0.82, _y - 1.5, max(1.4, _u * 0.12), _ink, 0.85);
            fol__seg(_x + _w * 0.18, _y + 2.2, _x + _w * 0.82, _y + 2.2, 1, _ink, 0.7);
            fol__fill([_cx, _y - _u * 0.42, _cx + _u * 0.42, _y, _cx, _y + _u * 0.42, _cx - _u * 0.42, _y], _ac, 1);
            break;
        case "fleuron":
            fol__fleuron(_cx + _u * 0.1, _y, _u * 1.1, _ac, 1, 0);
            fol__fleuron(_cx - _u * 0.1, _y, _u * 1.1, _ac, 1, pi);
            for (var _sd = -1; _sd <= 1; _sd += 2) {
                var _x0 = _cx + _sd * _u * 1.5, _x1 = _cx + _sd * _w * 0.34;
                fol__quad(_x0, _y - _u * 0.07, _ink, 0.85, _x1, _y - 0.4, _ink, 0.85, _x1, _y + 0.4, _ink, 0.85, _x0, _y + _u * 0.07, _ink, 0.85);
                fol__disc(_x1 + _sd * _u * 0.18, _y, _u * 0.11, _ac, 1, 8);
            }
            break;
        case "vine":
            var _p = [];
            for (var _i = 0; _i <= 60; _i++) { var _t = _i / 60; array_push(_p, _x + _w * (0.1 + 0.8 * _t), _y + sin(_t * pi * 6) * _u * 0.28); }
            fol__stroke(_p, max(1, _u * 0.08), _ink, 0.85);
            for (var _i = 0; _i < 12; _i++) {
                var _t = (_i + 0.5) / 12, _lx = _x + _w * (0.1 + 0.8 * _t), _ly = _y + sin(_t * pi * 6) * _u * 0.28, _up = ((_i mod 2) == 0) ? -1 : 1;
                fol__fill(fol__xform(fol__leaf_pts(_u * 0.55, _u * 0.22), _lx, _ly, 1, -pi * 0.5 * _up + 0.6 * _up), _ac, 1);
            }
            break;
        case "stars":
            for (var _i = -1; _i <= 1; _i++) fol__star(_cx + _i * _u * 1.6, _y, _u * 0.42, _ac, 1);
            break;
        case "knot":
            var _n = max(5, floor(_w * 0.7 / (_u * 0.9)));
            var _x0 = _cx - _n * _u * 0.45;
            for (var _i = 0; _i < _n; _i++) fol__ring(_x0 + (_i + 0.5) * _u * 0.9, _y, _u * 0.42, max(1.2, _u * 0.11), (_i mod 2 == 0) ? _ac : _ink, 1, 16);
            fol__seg(_x0 - _u * 0.4, _y - _u * 0.42, _x0 + _n * _u * 0.9 + _u * 0.4, _y - _u * 0.42, 1, _ink, 0.6);
            fol__seg(_x0 - _u * 0.4, _y + _u * 0.42, _x0 + _n * _u * 0.9 + _u * 0.4, _y + _u * 0.42, 1, _ink, 0.6);
            break;
    }
}
/// @function fol__star(x, y, r, col, alpha)
/// @description Internal. A six-pointed asterisk-star (concave, so ear clipped).
function fol__star(_x, _y, _r, _c, _a) {
    var _p = [];
    for (var _i = 0; _i < 12; _i++) { var _ang = -pi * 0.5 + _i / 12 * 2 * pi, _rr = ((_i mod 2) == 0) ? _r : _r * 0.42; array_push(_p, _x + cos(_ang) * _rr, _y + sin(_ang) * _rr); }
    fol__fill(_p, _c, _a);
}
/// @function fol__frame(look, m, pw, ph, unit, colours, recto, seed)
/// @description Internal. The frame a look draws round the text: a rule, a double rule with corner squares, a vine down the outer margin, a ruled margin column, or an illuminated border.
function fol__frame(_lk, _m, _pw, _ph, _u, _col, _recto, _seed) {
    var _pad = _u * 0.7, _x0 = _m.x - _pad, _y0 = _m.y - _pad, _x1 = _m.x + _m.w + _pad, _y1 = _m.bottom + _pad * 0.6;
    var _ink = _col.ink, _ac = _col.accent;
    switch (_lk.frame) {
        case "rule":
            fol__stroke([_x0, _y0, _x1, _y0, _x1, _y1, _x0, _y1], 1, _ink, 0.55, true);
            break;
        case "double":
            fol__stroke([_x0, _y0, _x1, _y0, _x1, _y1, _x0, _y1], max(1.6, _u * 0.13), _ink, 0.75, true);
            var _d = _u * 0.32;
            fol__stroke([_x0 + _d, _y0 + _d, _x1 - _d, _y0 + _d, _x1 - _d, _y1 - _d, _x0 + _d, _y1 - _d], 1, _ink, 0.55, true);
            var _cs = _u * 0.36;
            fol__rect(_x0 - _cs * 0.5, _y0 - _cs * 0.5, _cs, _cs, _ac, 1); fol__rect(_x1 - _cs * 0.5, _y0 - _cs * 0.5, _cs, _cs, _ac, 1);
            fol__rect(_x0 - _cs * 0.5, _y1 - _cs * 0.5, _cs, _cs, _ac, 1); fol__rect(_x1 - _cs * 0.5, _y1 - _cs * 0.5, _cs, _cs, _ac, 1);
            break;
        case "margin":
            var _mx = _recto ? (_m.x + _m.w + _pad) : (_m.x - _pad);
            var _ox = _recto ? (_pw - _u * 1.2) : (_u * 1.2);
            fol__seg(_mx, _y0, _mx, _y1, 1.6, _ac, 0.75); fol__seg(_mx + (_recto ? 3 : -3), _y0, _mx + (_recto ? 3 : -3), _y1, 1, _ac, 0.6);
            fol__seg(min(_mx, _ox), _y0, max(_mx, _ox), _y0, 1, _ink, 0.35);
            break;
        case "vine":
            var _vx = _recto ? (_m.x + _m.w + (_pw - _m.x - _m.w) * 0.42) : (_m.x * 0.58);
            var _g = fol_rng(_seed + 77), _p = [];
            var _yy0 = _m.y - _u * 0.4, _yy1 = _m.bottom + _u * 0.2, _n = 80;
            for (var _i = 0; _i <= _n; _i++) { var _t = _i / _n; array_push(_p, _vx + sin(_t * pi * 7 + _seed) * _u * 0.38, _yy0 + (_yy1 - _yy0) * _t); }
            fol__stroke(_p, max(1.2, _u * 0.09), _ink, 0.8);
            for (var _i = 0; _i < 14; _i++) {
                var _t = (_i + 0.35 + 0.3 * fol_rand(_g)) / 14, _ly = _yy0 + (_yy1 - _yy0) * _t, _lx = _vx + sin(_t * pi * 7 + _seed) * _u * 0.38, _sd = ((_i mod 2) == 0) ? 1 : -1;
                fol__fill(fol__xform(fol__leaf_pts(_u * 0.62, _u * 0.24), _lx, _ly, 1, (_sd > 0) ? -0.5 : pi + 0.5), _ac, 1);
                if ((_i mod 3) == 1) fol__disc(_lx + _sd * _u * 0.5, _ly + _u * 0.35, _u * 0.12, _ac, 1, 8);
            }
            break;
        case "illuminated":
            var _bx = _recto ? (_m.x + _m.w + _u * 0.5) : (_m.x - _u * 1.25), _bw = _u * 0.75;
            var _gr = fol__ramp(0.70, 0.12, 82, 0.20);
            fol__mass([_bx, _y0, _bx + _bw, _y0, _bx + _bw, _y1, _bx, _y1], _gr, 1.4);
            fol__rect(_bx + _bw * 0.3, _y0 + 4, _bw * 0.4, _y1 - _y0 - 8, _ac, 0.85);
            for (var _yy = _y0 + _u; _yy < _y1 - _u * 0.5; _yy += _u * 1.6) { fol__disc(_bx + _bw * 0.5, _yy, _bw * 0.3, _ink, 0.9, 10); fol__disc(_bx + _bw * 0.5, _yy, _bw * 0.17, fol__ramp_at(_gr, 0.8), 1, 10); }
            // corner sprays, top and bottom
            for (var _e = 0; _e < 2; _e++) {
                var _ey = (_e == 0) ? _y0 : _y1, _dir = _recto ? -1 : 1;
                fol__fleuron(_bx + _bw * 0.5, _ey, _u * 1.0, _ac, 1, (_dir > 0) ? 0 : pi);
                fol__disc(_bx + _bw * 0.5, _ey, _u * 0.22, fol__ramp_at(_gr, 0.85), 1, 12);
            }
            break;
    }
}
/// @function fol__ruling(look, m, pw, ph, unit, colours, recto, content_bottom)
/// @description Internal. The ruling under the text: lined on the text's own baselines, a grid, a ledger, music staves below the last line of text, or a dot grid.
function fol__ruling(_lk, _m, _pw, _ph, _u, _col, _recto, _cb) {
    var _rc = _col.rule, _al = _col.midnight ? 0.55 : 0.42;
    var _pitch = _m.pitch;
    switch (_lk.ruling) {
        case "lined":
            for (var _y = _m.y + _pitch - _pitch * 0.18; _y <= _m.bottom + 0.5; _y += _pitch) fol__seg(_m.x - _u * 0.4, _y, _m.x + _m.w + _u * 0.4, _y, 1, _rc, _al);
            var _red = fol_oklch(_col.midnight ? 0.62 : 0.60, 0.13, 22);
            var _mx = _recto ? (_m.x - _u * 0.8) : (_m.x + _m.w + _u * 0.8);
            fol__seg(_mx, _m.y - _pitch * 0.6, _mx, _m.bottom + _pitch * 0.3, 1.2, _red, _al + 0.1);
            break;
        case "grid":
            var _gs = _pitch * 0.5, _gx0 = _u * 0.9, _gy0 = _m.y - _pitch, _gx1 = _pw - _u * 0.9, _gy1 = _m.bottom + _pitch * 0.5;
            var _k = 0;
            for (var _x = _gx0; _x <= _gx1 + 0.5; _x += _gs) { fol__seg(_x, _gy0, _x, _gy1, 1, _rc, ((_k mod 4) == 0) ? _al : _al * 0.5); _k++; }
            _k = 0;
            for (var _y = _gy0; _y <= _gy1 + 0.5; _y += _gs) { fol__seg(_gx0, _y, _gx1, _y, 1, _rc, ((_k mod 4) == 0) ? _al : _al * 0.5); _k++; }
            break;
        case "ledger":
            var _red2 = fol_oklch(_col.midnight ? 0.62 : 0.56, 0.12, 22);
            for (var _y = _m.y + _pitch - _pitch * 0.18; _y <= _m.bottom + 0.5; _y += _pitch) fol__seg(_u * 0.5, _y, _pw - _u * 0.5, _y, 1, _rc, _al * 0.8);
            var _cols = _recto ? [_m.x - _u * 0.3, _m.x + _m.w + _u * 0.3, _pw - _u * 1.6] : [_u * 1.6, _m.x - _u * 0.3, _m.x + _m.w + _u * 0.3];
            for (var _i = 0; _i < 3; _i++) { fol__seg(_cols[_i], _m.y - _pitch, _cols[_i], _m.bottom + _pitch * 0.4, 1.1, _red2, _al + 0.1); fol__seg(_cols[_i] + 2.5, _m.y - _pitch, _cols[_i] + 2.5, _m.bottom + _pitch * 0.4, 1, _red2, _al); }
            fol__seg(_u * 0.5, _m.y - _pitch * 0.15, _pw - _u * 0.5, _m.y - _pitch * 0.15, 1.6, _red2, _al + 0.1);
            fol__seg(_u * 0.5, _m.y - _pitch * 0.15 + 3, _pw - _u * 0.5, _m.y - _pitch * 0.15 + 3, 1, _red2, _al);
            break;
        case "staff":
            var _gap = max(3, _pitch * 0.2), _sh = _gap * 4, _y = max(_cb + _pitch * 0.9, _m.y + _pitch * 0.5);
            while (_y + _sh <= _m.bottom + 0.5) {
                for (var _l = 0; _l < 5; _l++) fol__seg(_m.x, _y + _l * _gap, _m.x + _m.w, _y + _l * _gap, 1, _rc, _al + 0.1);
                fol__seg(_m.x, _y, _m.x, _y + _sh, 1.2, _rc, _al + 0.1); fol__seg(_m.x + _m.w, _y, _m.x + _m.w, _y + _sh, 1.2, _rc, _al + 0.1);
                _y += _sh + _pitch * 1.1;
            }
            break;
        case "dots":
            var _ds = _pitch * 0.5;
            for (var _y = _m.y - _pitch * 0.5; _y <= _m.bottom + _pitch * 0.4; _y += _ds) for (var _x = _u * 1.2; _x <= _pw - _u * 1.2; _x += _ds) fol__disc(_x, _y, 0.95, _rc, _al + 0.15, 5);
            break;
    }
}
/// @function fol__folio(look, text, m, pw, ph, unit, colours, recto)
/// @description Internal. Where and how the page number is printed: centred, at the outer corner, between rules, or in a lozenge. Draws the device; returns [x, y, halign] for the figures.
function fol__folio(_lk, _m, _pw, _ph, _u, _col, _recto, _tw) {
    var _y = _m.bottom + (_ph - _m.bottom) * 0.48, _cx = _m.x + _m.w * 0.5;
    switch (_lk.folio) {
        case "corner": return [_recto ? (_m.x + _m.w) : _m.x, _y, _recto ? fa_right : fa_left];
        case "ruled":
            fol__seg(_cx - _tw * 0.5 - _u * 2.4, _y, _cx - _tw * 0.5 - _u * 0.5, _y, 1, _col.ink, 0.6);
            fol__seg(_cx + _tw * 0.5 + _u * 0.5, _y, _cx + _tw * 0.5 + _u * 2.4, _y, 1, _col.ink, 0.6);
            return [_cx, _y, fa_center];
        case "lozenge":
            var _r = max(_tw * 0.5 + _u * 0.55, _u * 0.95);
            fol__stroke([_cx, _y - _r, _cx + _r * 1.15, _y, _cx, _y + _r, _cx - _r * 1.15, _y], 1.2, _col.accent, 0.9, true);
            return [_cx, _y, fa_center];
    }
    return [_cx, _y, fa_center];
}
/// @function fol__initial(look, ch, x, y, w, h, unit, colours, scale_fn)
/// @description Internal. The ground under a drop initial: none, a ruled box, a foliate flourish, or a burnished gold field.
function fol__initial_ground(_lk, _x, _y, _w, _h, _u, _col) {
    switch (_lk.init) {
        case "boxed":
            fol__rect(_x, _y, _w, _h, _col.accent, 1);
            fol__stroke([_x + 2, _y + 2, _x + _w - 2, _y + 2, _x + _w - 2, _y + _h - 2, _x + 2, _y + _h - 2], 1, _col.paper, 0.7, true);
            return _col.paper;
        case "flourish":
            for (var _i = 0; _i < 4; _i++) fol__fill(fol__xform(fol__leaf_pts(_w * 0.42, _w * 0.17), _x + _w * 0.5, _y + _h * 0.5, 1, _i * pi * 0.5 + pi * 0.25), _col.accent, 0.30);
            fol__ring(_x + _w * 0.5, _y + _h * 0.5, min(_w, _h) * 0.47, 1.2, _col.accent, 0.6, 28);
            return _col.ink;
        case "illuminated":
            var _gr = fol__ramp(0.72, 0.13, 82, 0.20);
            fol__mass([_x, _y, _x + _w, _y, _x + _w, _y + _h, _x, _y + _h], _gr, max(2, _u * 0.18));
            fol__rect(_x + _u * 0.32, _y + _u * 0.32, _w - _u * 0.64, _h - _u * 0.64, _col.accent, 1);
            for (var _i = 0; _i < 4; _i++) fol__disc(_x + ((_i mod 2) ? _w : 0), _y + ((_i div 2) ? _h : 0), _u * 0.16, fol__ramp_at(_gr, 0.9), 1, 10);
            return fol_oklch(0.93, 0.05, 85);
    }
    return _col.accent;
}
