/// fol_art.gml - how Folio draws: Oklch ramps, one vertex batch with GameMaker's limit counted in one place, outlines, a polygon filler for
/// concave shapes (ear clipping, so a leaf or a scroll never fills across its own notch), strokes with filled joins, the relief painter
/// (an outline's walls shaded by their normal against one fixed lamp, upper left), and the bake that turns drawings into sprites.
/// Everything drawn into a surface blends its alpha as "over", so a translucent mark never punches a hole in the page.
///
/// Folio - A Page-Turning Book for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

// ------------------------------------------------------------------------------------------------ colour

/// @function fol__lin(u)
/// @description Internal. Linear light to sRGB.
function fol__lin(_u) { return (_u <= 0.0031308) ? 12.92 * _u : 1.055 * power(_u, 1 / 2.4) - 0.055; }
/// @function fol_oklch(L, C, hue)
/// @description An Oklch colour (lightness 0..1, chroma, hue in degrees) as a GameMaker colour. Chroma walks down until it fits, so the hue stays where it was put.
/// @param {real} L    Lightness, 0..1.
/// @param {real} C    Chroma, 0 and up (0.1 is strong).
/// @param {real} hue  Hue in degrees.
/// @returns {real} A GameMaker colour.
function fol_oklch(_L, _C, _hdeg) {
    _L = clamp(fol__n(_L, 0.5), 0, 1); _C = max(0, fol__n(_C, 0)); var _h = degtorad(fol__n(_hdeg, 0));
    var _r = 0, _g = 0, _b = 0;
    for (var _i = 0; _i < 24; _i++) {
        var _a = cos(_h) * _C, _bb = sin(_h) * _C;
        var _l1 = _L + 0.3963377774 * _a + 0.2158037573 * _bb, _m1 = _L - 0.1055613458 * _a - 0.0638541728 * _bb, _s1 = _L - 0.0894841775 * _a - 1.2914855480 * _bb;
        _l1 = _l1 * _l1 * _l1; _m1 = _m1 * _m1 * _m1; _s1 = _s1 * _s1 * _s1;
        _r = 4.0767416621 * _l1 - 3.3077115913 * _m1 + 0.2309699292 * _s1;
        _g = -1.2684380046 * _l1 + 2.6097574011 * _m1 - 0.3413193965 * _s1;
        _b = -0.0041960863 * _l1 - 0.7034186147 * _m1 + 1.7076147010 * _s1;
        if (_r >= -0.0015 && _g >= -0.0015 && _b >= -0.0015 && _r <= 1.0015 && _g <= 1.0015 && _b <= 1.0015) break;
        _C *= 0.92;
    }
    return make_colour_rgb(round(fol__lin(clamp(_r, 0, 1)) * 255), round(fol__lin(clamp(_g, 0, 1)) * 255), round(fol__lin(clamp(_b, 0, 1)) * 255));
}
/// @function fol__ramp(L, C, hue, spread)
/// @description Internal. Five stops from shadow to light around one base colour. The whole ramp slides to fit rather than clamping at its ends (a clamped ramp collapses); shadows lean cool, lights warm.
function fol__ramp(_L, _C, _h, _spread = 0.25) {
    var _lo = _L - _spread, _hi = _L + _spread;
    if (_hi > 0.975) { _L -= _hi - 0.975; } else if (_lo < 0.07) { _L += 0.07 - _lo; }
    var _out = array_create(5, 0);
    for (var _i = 0; _i < 5; _i++) {
        var _t = (_i - 2) / 2;
        var _d = angle_difference(60, _h);
        var _hd = _h + sign(_d) * min(abs(_d), abs(_t * 10)) * sign(_t * 10);
        _out[_i] = fol_oklch(_L + _t * _spread, _C * (1 - abs(_t) * 0.28), _hd);
    }
    return _out;
}
/// @function fol__ramp_at(ramp, t)
/// @description Internal. A continuous position on a five-stop ramp.
function fol__ramp_at(_r, _t) {
    var _u = clamp(_t, 0, 1) * 4, _i = min(floor(_u), 3);
    return merge_colour(_r[_i], _r[_i + 1], _u - _i);
}

// ------------------------------------------------------------------------------------------------ the batch

/// @function fol__b_begin()
/// @description Internal. Open the one triangle batch. Every vertex goes through fol__tri, the only place GameMaker's per-batch vertex limit is counted (a batch past ~1000 vertices silently drops the rest).
function fol__b_begin() { global.fol__vn = 0; draw_primitive_begin(pr_trianglelist); }
/// @function fol__b_end()
/// @description Internal. Close the batch.
function fol__b_end() { draw_primitive_end(); }
/// @function fol__tri(x0, y0, c0, a0, x1, y1, c1, a1, x2, y2, c2, a2)
/// @description Internal. One Gouraud triangle.
function fol__tri(_x0, _y0, _c0, _a0, _x1, _y1, _c1, _a1, _x2, _y2, _c2, _a2) {
    if (global.fol__vn > 894) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); global.fol__vn = 0; }
    draw_vertex_colour(_x0, _y0, _c0, _a0); draw_vertex_colour(_x1, _y1, _c1, _a1); draw_vertex_colour(_x2, _y2, _c2, _a2);
    global.fol__vn += 3;
}
/// @function fol__quad(x0, y0, c0, a0, x1, y1, c1, a1, x2, y2, c2, a2, x3, y3, c3, a3)
/// @description Internal. Two triangles, corners in order round the quad.
function fol__quad(_x0, _y0, _c0, _a0, _x1, _y1, _c1, _a1, _x2, _y2, _c2, _a2, _x3, _y3, _c3, _a3) {
    fol__tri(_x0, _y0, _c0, _a0, _x1, _y1, _c1, _a1, _x2, _y2, _c2, _a2);
    fol__tri(_x0, _y0, _c0, _a0, _x2, _y2, _c2, _a2, _x3, _y3, _c3, _a3);
}
/// @function fol__rect(x, y, w, h, col, alpha)
/// @description Internal. A flat rectangle.
function fol__rect(_x, _y, _w, _h, _c, _a) { fol__quad(_x, _y, _c, _a, _x + _w, _y, _c, _a, _x + _w, _y + _h, _c, _a, _x, _y + _h, _c, _a); }
/// @function fol__seg(x0, y0, x1, y1, width, col, alpha)
/// @description Internal. A straight stroke of a given width (butt ends).
function fol__seg(_x0, _y0, _x1, _y1, _w, _c, _a) {
    var _dx = _x1 - _x0, _dy = _y1 - _y0, _l = sqrt(_dx * _dx + _dy * _dy);
    if (_l < 0.0001) return;
    var _nx = -_dy / _l * _w * 0.5, _ny = _dx / _l * _w * 0.5;
    fol__quad(_x0 + _nx, _y0 + _ny, _c, _a, _x1 + _nx, _y1 + _ny, _c, _a, _x1 - _nx, _y1 - _ny, _c, _a, _x0 - _nx, _y0 - _ny, _c, _a);
}
/// @function fol__disc(x, y, r, col, alpha, segs)
/// @description Internal. A flat disc.
function fol__disc(_x, _y, _r, _c, _a, _n = 16) {
    for (var _i = 0; _i < _n; _i++) {
        var _a0 = _i / _n * 2 * pi, _a1 = (_i + 1) / _n * 2 * pi;
        fol__tri(_x, _y, _c, _a, _x + cos(_a0) * _r, _y + sin(_a0) * _r, _c, _a, _x + cos(_a1) * _r, _y + sin(_a1) * _r, _c, _a);
    }
}
/// @function fol__spot(x, y, r, col, alpha, segs)
/// @description Internal. A soft round mark, its alpha falling to zero at the rim.
function fol__spot(_x, _y, _r, _c, _a, _n = 14) {
    for (var _i = 0; _i < _n; _i++) {
        var _a0 = _i / _n * 2 * pi, _a1 = (_i + 1) / _n * 2 * pi;
        fol__tri(_x, _y, _c, _a, _x + cos(_a0) * _r, _y + sin(_a0) * _r, _c, 0, _x + cos(_a1) * _r, _y + sin(_a1) * _r, _c, 0);
    }
}
/// @function fol__ring(x, y, r, width, col, alpha, segs)
/// @description Internal. A circle drawn as a band.
function fol__ring(_x, _y, _r, _w, _c, _a, _n = 24) {
    var _ri = max(0, _r - _w * 0.5), _ro = _r + _w * 0.5;
    for (var _i = 0; _i < _n; _i++) {
        var _a0 = _i / _n * 2 * pi, _a1 = (_i + 1) / _n * 2 * pi;
        fol__quad(_x + cos(_a0) * _ro, _y + sin(_a0) * _ro, _c, _a, _x + cos(_a1) * _ro, _y + sin(_a1) * _ro, _c, _a, _x + cos(_a1) * _ri, _y + sin(_a1) * _ri, _c, _a, _x + cos(_a0) * _ri, _y + sin(_a0) * _ri, _c, _a);
    }
}

// ------------------------------------------------------------------------------------------------ outlines and shapes

/// @function fol__bez(x0, y0, x1, y1, x2, y2, x3, y3, n, into)
/// @description Internal. A cubic Bezier sampled at n steps, appended to a flat [x, y, ...] list (the first point is skipped when the list already ends there).
function fol__bez(_x0, _y0, _x1, _y1, _x2, _y2, _x3, _y3, _n, _into) {
    var _s = (array_length(_into) >= 2) ? 1 : 0;
    for (var _i = _s; _i <= _n; _i++) {
        var _t = _i / _n, _u = 1 - _t;
        var _b0 = _u * _u * _u, _b1 = 3 * _u * _u * _t, _b2 = 3 * _u * _t * _t, _b3 = _t * _t * _t;
        array_push(_into, _b0 * _x0 + _b1 * _x1 + _b2 * _x2 + _b3 * _x3, _b0 * _y0 + _b1 * _y1 + _b2 * _y2 + _b3 * _y3);
    }
    return _into;
}
/// @function fol__area(points)
/// @description Internal. Twice the signed area of an outline (positive = clockwise on screen, y down).
function fol__area(_p) {
    var _n = array_length(_p) div 2, _s = 0;
    for (var _i = 0; _i < _n; _i++) { var _j = (_i + 1) mod _n; _s += _p[_i * 2] * _p[_j * 2 + 1] - _p[_j * 2] * _p[_i * 2 + 1]; }
    return _s;
}
/// @function fol__xform(points, x, y, scale, angle, mirror)
/// @description Internal. A copy of an outline moved, scaled, turned (radians, clockwise on screen) and optionally mirrored left to right first.
function fol__xform(_p, _x, _y, _s, _ang = 0, _mir = false) {
    var _n = array_length(_p) div 2, _o = array_create(_n * 2, 0), _c = cos(_ang), _sn = sin(_ang);
    for (var _i = 0; _i < _n; _i++) {
        var _px = _p[_i * 2] * (_mir ? -1 : 1) * _s, _py = _p[_i * 2 + 1] * _s;
        _o[_i * 2] = _x + _px * _c - _py * _sn; _o[_i * 2 + 1] = _y + _px * _sn + _py * _c;
    }
    if (_mir) {
        // mirroring reverses the winding; put it back so every outline here winds the same way
        var _r = array_create(_n * 2, 0);
        for (var _i = 0; _i < _n; _i++) { _r[_i * 2] = _o[(_n - 1 - _i) * 2]; _r[_i * 2 + 1] = _o[(_n - 1 - _i) * 2 + 1]; }
        return _r;
    }
    return _o;
}
/// @function fol__triangulate(points)
/// @description Internal. Ear clipping: a simple polygon (convex or not) as a list of vertex index triples. A concave outline handed to a fan fills across its notch; this never does. Returns [] for fewer than three points.
function fol__triangulate(_p) {
    var _n = array_length(_p) div 2, _out = [];
    if (_n < 3) return _out;
    var _idx = array_create(_n, 0);
    var _cw = fol__area(_p) > 0;
    for (var _i = 0; _i < _n; _i++) _idx[_i] = _i;
    var _guard = _n * _n + 8;
    while (array_length(_idx) > 3 && _guard-- > 0) {
        var _m = array_length(_idx), _cut = false;
        for (var _k = 0; _k < _m; _k++) {
            var _a = _idx[(_k + _m - 1) mod _m], _b = _idx[_k], _c = _idx[(_k + 1) mod _m];
            var _ax = _p[_a * 2], _ay = _p[_a * 2 + 1], _bx = _p[_b * 2], _by = _p[_b * 2 + 1], _cx = _p[_c * 2], _cy = _p[_c * 2 + 1];
            var _cr = (_bx - _ax) * (_cy - _ay) - (_by - _ay) * (_cx - _ax);
            if (_cw ? (_cr <= 0) : (_cr >= 0)) continue; // a reflex corner is never an ear
            var _inside = false;
            for (var _q = 0; _q < _m; _q++) {
                var _v = _idx[_q];
                if (_v == _a || _v == _b || _v == _c) continue;
                var _px = _p[_v * 2], _py = _p[_v * 2 + 1];
                var _d1 = (_bx - _ax) * (_py - _ay) - (_by - _ay) * (_px - _ax);
                var _d2 = (_cx - _bx) * (_py - _by) - (_cy - _by) * (_px - _bx);
                var _d3 = (_ax - _cx) * (_py - _cy) - (_ay - _cy) * (_px - _cx);
                if (_cw ? (_d1 >= 0 && _d2 >= 0 && _d3 >= 0) : (_d1 <= 0 && _d2 <= 0 && _d3 <= 0)) { _inside = true; break; }
            }
            if (_inside) continue;
            array_push(_out, [_a, _b, _c]);
            array_delete(_idx, _k, 1);
            _cut = true;
            break;
        }
        if (!_cut) break; // degenerate input: stop rather than spin
    }
    if (array_length(_idx) == 3) array_push(_out, [_idx[0], _idx[1], _idx[2]]);
    return _out;
}
/// @function fol__fill(points, col, alpha)
/// @description Internal. Fill any simple outline (concave included) inside the open batch.
function fol__fill(_p, _c, _a) {
    var _t = fol__triangulate(_p);
    for (var _i = 0; _i < array_length(_t); _i++) {
        var _r = _t[_i];
        fol__tri(_p[_r[0] * 2], _p[_r[0] * 2 + 1], _c, _a, _p[_r[1] * 2], _p[_r[1] * 2 + 1], _c, _a, _p[_r[2] * 2], _p[_r[2] * 2 + 1], _c, _a);
    }
    return array_length(_t);
}
/// @function fol__stroke(points, width, col, alpha, closed)
/// @description Internal. A polyline of a given width. Joins are filled with a disc of the stroke's own radius (butt-ended segments leave a notch at every turn), skipped below 2 px where the disc IS the segment.
function fol__stroke(_p, _w, _c, _a, _closed = false) {
    var _n = array_length(_p) div 2;
    if (_n < 2) return;
    var _m = _closed ? _n : _n - 1;
    for (var _i = 0; _i < _m; _i++) { var _j = (_i + 1) mod _n; fol__seg(_p[_i * 2], _p[_i * 2 + 1], _p[_j * 2], _p[_j * 2 + 1], _w, _c, _a); }
    if (_w >= 2 && _a >= 0.99) {
        var _s = _closed ? 0 : 1, _e = _closed ? _n : _n - 1;
        for (var _i = _s; _i < _e; _i++) fol__disc(_p[_i * 2], _p[_i * 2 + 1], _w * 0.5, _c, _a, 8);
    }
}
/// @function fol__ell(x, y, rx, ry, segs)
/// @description Internal. An ellipse as an outline.
function fol__ell(_x, _y, _rx, _ry, _n = 20) {
    var _p = [];
    for (var _i = 0; _i < _n; _i++) { var _a = _i / _n * 2 * pi; array_push(_p, _x + cos(_a) * _rx, _y + sin(_a) * _ry); }
    return _p;
}

/// @function fol__mass(points, ramp, bevel)
/// @description Internal. The relief painter, for convex or star-shaped outlines: a soft gradient across the lamp and walls shaded by how squarely each faces it (lamp upper left). The bevel is capped by the shortest edge, or it folds.
function fol__mass(_p, _ramp, _bevel) {
    var _n = array_length(_p) div 2;
    if (_n < 3) return;
    var _flip = fol__area(_p) < 0 ? -1 : 1;
    var _short = infinity, _cx = 0, _cy = 0, _R = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _j = (_i + 1) mod _n, _l = point_distance(_p[_i * 2], _p[_i * 2 + 1], _p[_j * 2], _p[_j * 2 + 1]);
        if (_l > 0.05) _short = min(_short, _l);
        _cx += _p[_i * 2]; _cy += _p[_i * 2 + 1];
    }
    _cx /= _n; _cy /= _n;
    for (var _i = 0; _i < _n; _i++) _R = max(_R, point_distance(_cx, _cy, _p[_i * 2], _p[_i * 2 + 1]));
    _R = max(0.001, _R);
    var _bev = min(_bevel, _short * 0.45);
    var _nxs = array_create(_n, 0), _nys = array_create(_n, 0);
    for (var _i = 0; _i < _n; _i++) {
        var _h = (_i + _n - 1) mod _n, _j = (_i + 1) mod _n;
        var _ax = _p[_i * 2] - _p[_h * 2], _ay = _p[_i * 2 + 1] - _p[_h * 2 + 1], _bx = _p[_j * 2] - _p[_i * 2], _by = _p[_j * 2 + 1] - _p[_i * 2 + 1];
        var _la = max(0.0001, sqrt(_ax * _ax + _ay * _ay)), _lb = max(0.0001, sqrt(_bx * _bx + _by * _by));
        var _nx = (_ay / _la + _by / _lb), _ny = -(_ax / _la + _bx / _lb), _ln = max(0.0001, sqrt(_nx * _nx + _ny * _ny));
        _nxs[_i] = _nx / _ln * _flip; _nys[_i] = _ny / _ln * _flip;
    }
    var _lx = -0.6, _ly = -0.8, _ccol = fol__ramp_at(_ramp, 0.52);
    for (var _i = 0; _i < _n; _i++) {
        var _j = (_i + 1) mod _n;
        var _ix = _p[_i * 2] - _nxs[_i] * _bev, _iy = _p[_i * 2 + 1] - _nys[_i] * _bev, _jx = _p[_j * 2] - _nxs[_j] * _bev, _jy = _p[_j * 2 + 1] - _nys[_j] * _bev;
        var _ti = 0.52 + 0.18 * (((_ix - _cx) * _lx + (_iy - _cy) * _ly) / _R), _tj = 0.52 + 0.18 * (((_jx - _cx) * _lx + (_jy - _cy) * _ly) / _R);
        var _ci = fol__ramp_at(_ramp, _ti), _cj = fol__ramp_at(_ramp, _tj);
        fol__tri(_cx, _cy, _ccol, 1, _ix, _iy, _ci, 1, _jx, _jy, _cj, 1);
        if (_bev > 0.01) {
            var _di = 0.5 + 0.5 * (_nxs[_i] * _lx + _nys[_i] * _ly), _dj = 0.5 + 0.5 * (_nxs[_j] * _lx + _nys[_j] * _ly);
            fol__quad(_p[_i * 2], _p[_i * 2 + 1], fol__ramp_at(_ramp, _di), 1, _p[_j * 2], _p[_j * 2 + 1], fol__ramp_at(_ramp, _dj), 1, _jx, _jy, _cj, 1, _ix, _iy, _ci, 1);
        }
    }
}

// ------------------------------------------------------------------------------------------------ noise

/// @function fol__hash(n)
/// @description Internal. A repeatable number in [0, 1) from an integer.
function fol__hash(_n) {
    var _x = (floor(_n) * 374761393 + 668265263) mod 2147483647;
    _x = (_x * 1103515245 + 12345) mod 2147483647;
    _x = (_x * 48271) mod 2147483647;
    return abs(_x) / 2147483647;
}
/// @function fol__noise1(x, seed)
/// @description Internal. Smooth 1D value noise in [-1, 1].
function fol__noise1(_x, _seed) {
    var _i = floor(_x), _f = _x - _i, _u = _f * _f * (3 - 2 * _f);
    var _a = fol__hash(_i * 7 + _seed * 131), _b = fol__hash((_i + 1) * 7 + _seed * 131);
    return (_a + (_b - _a) * _u) * 2 - 1;
}

// ------------------------------------------------------------------------------------------------ the bake and the cache

/// @function fol__bake_begin(w, h, supersample)
/// @description Internal. Open a supersampled surface for painting, under identity (the caller's matrix is handed back at the end). Alpha blends as "over".
function fol__bake_begin(_w, _h, _ss) {
    var _b = { w: _w, h: _h, ss: _ss, m: matrix_get(matrix_world), s: surface_create(_w * _ss, _h * _ss), a: draw_get_alpha(), c: draw_get_colour() };
    draw_set_alpha(1); draw_set_colour(c_white);
    surface_set_target(_b.s);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false); gpu_set_cullmode(cull_noculling); gpu_set_alphatestenable(false);
    matrix_set(matrix_world, matrix_build(0, 0, 0, 0, 0, 0, _ss, _ss, 1));
    return _b;
}
/// @function fol__bake_end(bake)
/// @description Internal. Close the surface, filter it down, make the sprite, free the surfaces, hand back the matrix. The result is premultiplied.
function fol__bake_end(_b) {
    matrix_set(matrix_world, matrix_build_identity());
    gpu_pop_state();
    surface_reset_target();
    var _d = surface_create(_b.w, _b.h);
    surface_set_target(_d);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    gpu_set_tex_filter(true);
    gpu_set_blendmode_ext(bm_one, bm_zero);
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false); gpu_set_cullmode(cull_noculling); gpu_set_alphatestenable(false);
    draw_surface_stretched(_b.s, 0, 0, _b.w, _b.h);
    gpu_pop_state();
    surface_reset_target();
    var _spr = sprite_create_from_surface(_d, 0, 0, _b.w, _b.h, false, false, 0, 0);
    surface_free(_d);
    surface_free(_b.s);
    matrix_set(matrix_world, _b.m);
    draw_set_alpha(_b.a); draw_set_colour(_b.c);
    return _spr;
}
/// @function fol__cache()
/// @description Internal. The shared table of baked paper sprites, keyed by look and size.
function fol__cache() {
    if (!variable_global_exists("fol__sprites")) global.fol__sprites = {};
    return global.fol__sprites;
}
/// @function fol_art_free()
/// @description Delete every baked paper sprite. Call it when no book is on screen (room end, a restart path): the next draw bakes again. Never call it between drawing and the end of a frame.
/// @returns {real} How many sprites were deleted.
function fol_art_free() {
    var _c = fol__cache(), _ks = variable_struct_get_names(_c), _n = 0;
    for (var _i = 0; _i < array_length(_ks); _i++) { var _v = _c[$ _ks[_i]]; if (is_real(_v) || is_int32(_v) || is_int64(_v) || is_handle(_v)) { if (sprite_exists(_v)) { sprite_delete(_v); _n++; } } }
    global.fol__sprites = {};
    return _n;
}
/// @function fol_art_count()
/// @description How many baked paper sprites the cache holds.
/// @returns {real}
function fol_art_count() { return array_length(variable_struct_get_names(fol__cache())); }
