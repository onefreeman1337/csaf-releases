/// fol_draw.gml - Folio on screen: type, page composition (paper, ruling, frame, text, pictures, your drawings, running head and
/// number, the shadow of the gutter), and the book: boards, the page block whose edges thicken on the side the pages are, the open
/// spread, the leaf in motion as a curled mesh with its highlight and the shadows it casts, ribbons and thumb tabs. Pages are
/// composed once into surfaces and kept (a few at a time); a surface the GPU loses is composed again on the next draw.
///
/// Folio - A Page-Turning Book for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

// ------------------------------------------------------------------------------------------------ type

/// @function fol__font(style, px)
/// @description Internal. The atlas, the scale and the ascent (cell top to baseline, at that scale) for a style at a pixel size: the smaller atlas when it is near enough, the larger one scaled down otherwise.
function fol__font(_st, _px) {
    var _f, _base, _asc;
    // the atlas is chosen by the size the type lands at on screen: a page composed at 1.5x must not magnify the small atlas (a bitmap font scaled up goes soft)
    var _e = _px * (variable_global_exists("fol__ck") ? global.fol__ck : 1);
    switch (_st) {
        case "italic": case "caption":
            if (_e <= 21) { _f = fnt_folio_italic_s; _base = 18; _asc = 17; } else { _f = fnt_folio_italic_l; _base = 36; _asc = 35; }
            break;
        case "heading": case "head":
            if (_e <= 33) { _f = fnt_folio_display_s; _base = 28; _asc = 27; } else { _f = fnt_folio_display_l; _base = 80; _asc = 78; }
            break;
        case "title": case "drop":
            if (_e <= 30) { _f = fnt_folio_display_s; _base = 28; _asc = 27; } else { _f = fnt_folio_display_l; _base = 80; _asc = 78; }
            break;
        default:
            if (_e <= 23) { _f = fnt_folio_text_s; _base = 20; _asc = 19; } else { _f = fnt_folio_text_l; _base = 40; _asc = 39; }
    }
    var _sc = _px / _base;
    return [_f, _sc, _asc * _sc];
}
/// @function fol__font_width(text, style, px)
/// @description Internal. A string's width in a style at a pixel size.
function fol__font_width(_s, _st, _px) {
    var _F = fol__font(_st, _px);
    var _pf = draw_get_font();
    draw_set_font(_F[0]);
    var _w = string_width(_s) * _F[1];
    if (font_exists(_pf)) draw_set_font(_pf);
    return _w;
}
/// @function fol__text(x, baseline, text, style, px, col, alpha, halign)
/// @description Internal. One string on a baseline. Scaled-down type is drawn with filtering on (point sampling drops one-pixel strokes), and the caller's filter setting is put back.
function fol__text(_x, _yb, _s, _st, _px, _c, _a, _ha = fa_left) {
    var _F = fol__font(_st, _px);
    var _tf = gpu_get_tex_filter();
    gpu_set_tex_filter(true);
    draw_set_font(_F[0]); draw_set_halign(_ha); draw_set_valign(fa_top); draw_set_colour(_c); draw_set_alpha(_a);
    draw_text_transformed(_x, _yb - _F[2], _s, _F[1], _F[1], 0);
    draw_set_halign(fa_left); draw_set_alpha(1); draw_set_colour(c_white);
    gpu_set_tex_filter(_tf);
}

// ------------------------------------------------------------------------------------------------ the static layer of a page

/// @function fol__overlay(book, recto)
/// @description Internal. The ruling and the frame of one side of the book, baked once per look, size, side and type size (a dot grid is thousands of marks; drawing it for every page would cost a frame).
function fol__overlay(_b, _recto) {
    var _m = fol_book_metrics(_b, _recto ? 0 : 1), _lk = fol_paper_look(_b.paper);
    var _key = "o" + string(_b.paper) + "_" + string(_b.pw) + "x" + string(_b.ph) + "_" + (_recto ? "r" : "v") + "_" + string(_m.pitch) + "_" + string(_b.seed);
    var _c = fol__cache();
    if (variable_struct_exists(_c, _key) && sprite_exists(_c[$ _key])) return _c[$ _key];
    var _col = fol_paper_colours(_b.paper), _u = _b.type_px * 0.9;
    var _bk = fol__bake_begin(_b.pw, _b.ph, 1);
    fol__b_begin();
    if (_lk.ruling != "staff") fol__ruling(_lk, _m, _b.pw, _b.ph, _u, _col, _recto, 0);
    fol__frame(_lk, _m, _b.pw, _b.ph, _u, _col, _recto, _b.seed + (_recto ? 11 : 0));
    fol__b_end();
    var _spr = fol__bake_end(_bk);
    _c[$ _key] = _spr;
    return _spr;
}
/// @function fol__endpaper(book, x, y)
/// @description Internal. The pattern on an endpaper: a lattice of small stars in the accent colour.
function fol__endpaper(_b) {
    var _col = fol_paper_colours(_b.paper), _u = _b.type_px * 0.9, _s = _u * 2.6;
    fol__b_begin();
    fol__rect(0, 0, _b.pw, _b.ph, _col.dark, 0.35);
    var _row = 0;
    for (var _y = _s * 0.5; _y < _b.ph; _y += _s * 0.87) {
        var _off = ((_row mod 2) == 0) ? 0 : _s * 0.5;
        for (var _x = _s * 0.4 + _off; _x < _b.pw; _x += _s) fol__star(_x, _y, _u * 0.34, _col.accent, 0.55);
        _row++;
    }
    fol__b_end();
}

// ------------------------------------------------------------------------------------------------ composing a page

/// @function fol__surf_cache(book, kc)
/// @description Internal. The book's page surfaces; everything is let go when the pagination, the paper or the scale changes.
function fol__surf_cache(_b, _kc) {
    var _S = _b.surf;
    if (!is_struct(_S) || _S.gen != _b.gen || _S.paper != _b.paper || _S.kc != _kc) {
        fol__surf_free(_b);
        _b.surf = { gen: _b.gen, paper: _b.paper, kc: _kc, map: {}, keys: [] };
    }
    return _b.surf;
}
/// @function fol__surf_free(book)
/// @description Internal. Free every page surface a book holds.
function fol__surf_free(_b) {
    var _S = _b.surf;
    if (!is_struct(_S)) return 0;
    var _n = 0;
    for (var _i = 0; _i < array_length(_S.keys); _i++) { var _s = _S.map[$ _S.keys[_i]]; if (!is_undefined(_s) && surface_exists(_s)) { surface_free(_s); _n++; } }
    _b.surf = undefined;
    return _n;
}
/// @function fol__page_surf(book, page, kc)
/// @description Internal. A page as a composed surface at scale kc, from the cache or composed now. Page -1, and any page past the end, is an endpaper.
function fol__page_surf(_b, _pg, _kc) {
    var _S = fol__surf_cache(_b, _kc);
    var _n = array_length(_b.pages);
    var _key = (_pg < 0) ? "e0" : ((_pg >= _n) ? "e1" : ("p" + string(_pg)));
    var _s = _S.map[$ _key];
    if (!is_undefined(_s) && surface_exists(_s)) {
        // most recently used goes last
        var _at = array_get_index(_S.keys, _key);
        if (_at >= 0) { array_delete(_S.keys, _at, 1); array_push(_S.keys, _key); }
        return _s;
    }
    if (!is_undefined(_s)) { var _at2 = array_get_index(_S.keys, _key); if (_at2 >= 0) array_delete(_S.keys, _at2, 1); }
    while (array_length(_S.keys) >= 8) {
        var _old = _S.keys[0]; array_delete(_S.keys, 0, 1);
        var _os = _S.map[$ _old]; if (!is_undefined(_os) && surface_exists(_os)) surface_free(_os);
        variable_struct_remove(_S.map, _old);
    }
    _s = fol__compose(_b, _pg, _kc);
    _S.map[$ _key] = _s;
    array_push(_S.keys, _key);
    return _s;
}
/// @function fol__compose(book, page, kc)
/// @description Internal. Draw one page into a new surface: paper, ruling and frame, content, running head, number, gutter.
function fol__compose(_b, _pg, _kc) {
    var _w = max(1, round(_b.pw * _kc)), _h = max(1, round(_b.ph * _kc));
    var _n = array_length(_b.pages), _end = (_pg < 0 || _pg >= _n);
    var _recto = _end ? (_pg >= _n ? ((_n mod 2) == 0) : false) : ((_pg mod 2) == 0);
    var _lk = fol_paper_look(_b.paper), _col = fol_paper_colours(_b.paper);
    // everything this needs that bakes a sprite is baked BEFORE the target is set (a bake sets its own targets)
    var _var = _end ? 2 : (_pg mod 3);
    var _paper = fol_paper_sprite(_b.paper, _b.pw, _b.ph, _var, _b.seed);
    var _ov = _end ? -1 : fol__overlay(_b, _recto);
    var _s = surface_create(_w, _h);
    var _pm = matrix_get(matrix_world), _pa = draw_get_alpha(), _pc = draw_get_colour(), _pf = draw_get_font();
    var _ck0 = variable_global_exists("fol__ck") ? global.fol__ck : 1;
    global.fol__ck = _kc;
    surface_set_target(_s);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false); gpu_set_cullmode(cull_noculling); gpu_set_alphatestenable(false);
    matrix_set(matrix_world, matrix_build(0, 0, 0, 0, 0, 0, _kc, _kc, 1));
    gpu_set_tex_filter(true);
    // the sheet (premultiplied), mirrored on a left-hand page so its spine edge meets the spine
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    draw_sprite_ext(_paper, 0, _recto ? 0 : _b.pw, 0, _recto ? 1 : -1, 1, 0, c_white, 1);
    if (!_end) draw_sprite(_ov, 0, 0, 0);
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    if (_end) fol__endpaper(_b);
    else {
        var _P = _b.pages[_pg], _m = fol_book_metrics(_b, _pg), _u = _b.type_px * 0.9;
        var _cb = _m.y;
        for (var _i = 0; _i < array_length(_P.items); _i++) _cb = max(_cb, _P.items[_i].y + _m.pitch);
        if (_lk.ruling == "staff") { fol__b_begin(); fol__ruling(_lk, _m, _b.pw, _b.ph, _u, _col, _recto, _P.blank ? _m.y : _cb); fol__b_end(); }
        fol__content(_b, _P, _m, _lk, _col, _u);
        // running head: the chapter on the left, the book's title on the right (not over a chapter's opening page)
        if (!_P.opens && !_P.blank && array_length(_P.items) > 0) {
            var _rh = (_recto && _b.title != "") ? _b.title : _P.chapter;
            if (_rh != "") {
                var _hp = fol__style_px(_b, "head");
                fol__text(_m.x + _m.w * 0.5, _m.y - _m.pitch * 0.85, string_upper(_rh), "head", _hp, _col.ink, 0.78, fa_center);
            }
        }
        // the page number
        if (!_P.blank) {
            var _ft = fol_folio_text(_b, _pg), _fp = fol__style_px(_b, "folio");
            var _tw = fol__font_width(_ft, "body", _fp);
            fol__b_begin();
            var _fo = fol__folio(_lk, _m, _b.pw, _b.ph, _u, _col, _recto, _tw);
            fol__b_end();
            fol__text(_fo[0], _fo[1] + _fp * 0.36, _ft, "body", _fp, _col.ink, 0.9, _fo[2]);
        }
    }
    // the gutter: the page curves down into the binding and catches less light there
    fol__b_begin();
    var _gx = _recto ? 0 : _b.pw, _gw = _b.pw * 0.10 * (_recto ? 1 : -1), _gk = _col.midnight ? c_black : fol_oklch(0.25, 0.03, 60);
    fol__quad(_gx, 0, _gk, 0.30, _gx + _gw, 0, _gk, 0, _gx + _gw, _b.ph, _gk, 0, _gx, _b.ph, _gk, 0.30);
    fol__quad(_gx, 0, _gk, 0.25, _gx + _gw * 0.18, 0, _gk, 0, _gx + _gw * 0.18, _b.ph, _gk, 0, _gx, _b.ph, _gk, 0.25);
    fol__b_end();
    gpu_pop_state();
    matrix_set(matrix_world, _pm);
    surface_reset_target();
    global.fol__ck = _ck0;
    draw_set_alpha(_pa); draw_set_colour(_pc); if (font_exists(_pf)) draw_set_font(_pf);
    _b.stats.composed += 1;
    return _s;
}
/// @function fol__content(book, page, metrics, look, colours, unit)
/// @description Internal. Every item pagination placed on a page.
function fol__content(_b, _P, _m, _lk, _col, _u) {
    var _T = _b.type_px, _pitch = _m.pitch;
    for (var _i = 0; _i < array_length(_P.items); _i++) {
        var _it = _P.items[_i];
        var _yb = _it.y + _pitch - _pitch * 0.30; // the baseline of a line set at y
        switch (_it.k) {
            case "line":
                var _F = fol__font("body", _T), _tf = gpu_get_tex_filter();
                gpu_set_tex_filter(true);
                draw_set_font(_F[0]); draw_set_halign(fa_left); draw_set_valign(fa_top); draw_set_colour(_col.ink); draw_set_alpha(1);
                for (var _q = 0; _q < array_length(_it.ws); _q++) draw_text_transformed(_it.xs[_q], _yb - _F[2], _it.ws[_q], _F[1], _F[1], 0);
                draw_set_colour(c_white);
                gpu_set_tex_filter(_tf);
                break;
            case "heading":
                fol__text(_it.x + _it.w * 0.5, _yb, string_upper(_it.str), "heading", fol__style_px(_b, "heading"), _col.accent, 1, fa_center);
                break;
            case "title":
                fol__text(_it.x, _it.y + _pitch * 1.05, _it.str, "title", fol__style_px(_b, "title"), _col.ink, 1, fa_center);
                break;
            case "headpiece":
                fol__b_begin(); fol__headpiece(_lk, _it.x, _it.y, _it.w, _u, _col); fol__b_end();
                break;
            case "drop":
                // the capital spans three lines: from the cap height of the first to the baseline of the third
                var _cap_top = _yb - _T * 0.70, _base3 = _yb + _pitch * 2;
                var _dpx = (_base3 - _cap_top) / 0.70;
                var _bw = _it.w - _T * 0.40, _pad = _T * 0.22;
                fol__b_begin();
                var _lc = fol__initial_ground(_lk, _it.x - _pad, _cap_top - _pad, _bw + _pad, _base3 - _cap_top + _pad * 2, _u, _col);
                fol__b_end();
                var _cx = (_lk.init == "boxed" || _lk.init == "illuminated" || _lk.init == "flourish") ? (_it.x - _pad + (_bw + _pad) * 0.5) : _it.x;
                fol__text(_cx, _base3, _it.ch, "drop", _dpx, _lc, 1, (_cx == _it.x) ? fa_left : fa_center);
                break;
            case "picture":
                var _pd = _T * 0.32;
                fol__b_begin();
                fol__rect(_it.x - _pd + 2, _it.y - _pd + 3, _it.w + _pd * 2, _it.h + _pd * 2, c_black, 0.10);
                fol__rect(_it.x - _pd, _it.y - _pd, _it.w + _pd * 2, _it.h + _pd * 2, _col.light, 1);
                fol__stroke([_it.x - _pd, _it.y - _pd, _it.x + _it.w + _pd, _it.y - _pd, _it.x + _it.w + _pd, _it.y + _it.h + _pd, _it.x - _pd, _it.y + _it.h + _pd], 1, _col.ink, 0.5, true);
                fol__b_end();
                draw_sprite_stretched_ext(_it.spr, _it.sub, _it.x, _it.y, _it.w, _it.h, c_white, 1);
                if (_it.cap != "") fol__text(_it.cx, _it.y + _it.h + _pd + _pitch * 0.78, _it.cap, "caption", fol__style_px(_b, "caption"), _col.ink, 0.92, fa_center);
                break;
            case "custom":
                gpu_push_state();
                try { _it.fn(_it.x, _it.y, _it.w, _it.h, _P.index); } catch (_e) { show_debug_message("Folio: a custom page drawing failed: " + string(_e.message)); }
                gpu_pop_state();
                draw_set_alpha(1); draw_set_colour(c_white);
                break;
        }
    }
}

// ------------------------------------------------------------------------------------------------ the book

/// @function fol__cloth(book)
/// @description Internal. The colour of the boards: the buyer's, or a deep cloth that suits the paper.
function fol__cloth(_b) {
    if (_b.cloth >= 0) return _b.cloth;
    var _lk = fol_paper_look(_b.paper);
    switch (_lk.accent) {
        case "lapis": return fol_oklch(0.30, 0.07, 258);
        case "verdigris": return fol_oklch(0.32, 0.06, 165);
        case "violet": return fol_oklch(0.28, 0.07, 315);
        case "gold": return fol_oklch(0.26, 0.04, 40);
        case "silver": return fol_oklch(0.24, 0.02, 260);
    }
    return fol_oklch(0.30, 0.09, 26);
}
/// @function fol__block(book, x, y, k, side, count, colours, gilt)
/// @description Internal. The edges of the pages under one side of the spread, stepped out so the side holding more pages reads thicker.
function fol__block(_b, _x, _y, _k, _side, _count, _col, _gilt) {
    var _t = clamp(1 + _count * 0.22, 1, 9);
    var _pw = _b.pw * _k, _ph = _b.ph * _k, _sp = _x + _pw;
    var _c0 = _gilt ? fol_oklch(0.70, 0.11, 80) : _col.dark, _c1 = _gilt ? fol_oklch(0.80, 0.10, 84) : _col.paper;
    for (var _i = ceil(_t); _i >= 1; _i--) {
        var _d = _i * _k * 0.9, _cc = ((_i mod 2) == 0) ? _c0 : _c1;
        if (_side > 0) fol__rect(_sp, _y + _d * 0.35, _pw + _d, _ph + _d * 0.35, _cc, 1);
        else fol__rect(_x - _d, _y + _d * 0.35, _pw + _d, _ph + _d * 0.35, _cc, 1);
    }
    return _t;
}
/// @function fol_book_draw(book, x, y, scale)
/// @description Draw the book open, with the leaf in motion if one is: x, y is the top-left corner of the left-hand page; the boards reach a little past it. Paginates first when anything changed. Draws in the current space (room or GUI), and sets fol_book_place for fol_book_feed / fol_book_read.
/// @param {struct} book
/// @param {real} x
/// @param {real} y
/// @param {real} scale  Default 1.
/// @returns {bool}
function fol_book_draw(_b, _x, _y, _k = 1) {
    if (!fol__is_book(_b)) return false;
    fol__ready(_b);
    _x = fol__n(_x, 0); _y = fol__n(_y, 0); _k = clamp(fol__n(_k, 1), 0.05, 8);
    fol_book_place(_b, _x, _y, _k);
    var _kc = clamp(round(_k * 20) / 20, 0.25, 2);
    var _pw = _b.pw * _k, _ph = _b.ph * _k, _sp = _x + _pw;
    var _lk = fol_paper_look(_b.paper), _col = fol_paper_colours(_b.paper);
    var _n = array_length(_b.pages), _L = _b.leaf;
    var _pp = fol_spread_pages(_b, _b.spread);
    var _left = (_b.spread == 0) ? -1 : (_b.spread * 2 - 1), _right = _b.spread * 2; // page indices, an endpaper past either end
    // what lies under a turning leaf, what is on its front and on its back
    var _under = undefined, _front = 0, _back = 0, _dir = 0;
    if (is_struct(_L)) {
        _dir = _L.dir;
        if (_dir > 0) { _front = _right; _back = _right + 1; _under = _right + 2; }
        else { _front = _left; _back = _left - 1; _under = _left - 2; }
    } else if (_b.hover.amt > 0.01 && _b.hover.side != 0) {
        _dir = _b.hover.side;
        if (_dir > 0) { _front = _right; _back = _right + 1; _under = _right + 2; }
        else { _front = _left; _back = _left - 1; _under = _left - 2; }
    }
    // compose what is needed BEFORE any drawing (composition switches targets)
    var _sL = fol__page_surf(_b, _left, _kc), _sR = fol__page_surf(_b, _right, _kc);
    var _sF = -1, _sB = -1, _sU = -1;
    if (_dir != 0) { _sF = fol__page_surf(_b, _front, _kc); _sB = fol__page_surf(_b, _back, _kc); _sU = fol__page_surf(_b, _under, _kc); }
    // a surface composed early can be freed by the cache's limit while composing a later one: check again
    if (!surface_exists(_sL)) _sL = fol__page_surf(_b, _left, _kc);
    if (!surface_exists(_sR)) _sR = fol__page_surf(_b, _right, _kc);
    var _pa = draw_get_alpha(), _pc = draw_get_colour();
    gpu_push_state();
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false); gpu_set_cullmode(cull_noculling); gpu_set_alphatestenable(false);
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    draw_set_alpha(1); draw_set_colour(c_white);
    _b.hot = [];
    // the shadow on the desk and the boards
    var _bd = _pw * 0.035;
    fol__b_begin();
    for (var _i = 0; _i < 6; _i++) { var _e = (_i + 1) * _k * 3.2; fol__rect(_x - _bd - _e * 0.4 + _k * 6, _y - _bd - _e * 0.2 + _k * 10, _pw * 2 + _bd * 2 + _e * 0.8, _ph + _bd * 2 + _e * 0.9, c_black, 0.07); }
    var _cl = fol__cloth(_b);
    fol__rect(_x - _bd, _y - _bd * 0.8, _pw * 2 + _bd * 2, _ph + _bd * 1.9, _cl, 1);
    fol__rect(_x - _bd, _y - _bd * 0.8, _pw * 2 + _bd * 2, _k * 2, merge_colour(_cl, c_white, 0.18), 1);
    fol__rect(_x - _bd, _y + _ph + _bd * 1.1 - _k * 2, _pw * 2 + _bd * 2, _k * 2, merge_colour(_cl, c_black, 0.35), 1);
    fol__rect(_sp - _k * 4, _y - _bd * 0.8, _k * 8, _ph + _bd * 1.9, merge_colour(_cl, c_black, 0.4), 1);
    // the page block's depth on each side: the side holding more pages stands thicker
    var _gilt = (_lk.edge == "gilt");
    var _cntL = max(0, _left + 1), _cntR = max(0, _n - _right - 1);
    var _dL = ceil(clamp(1 + _cntL * 0.22, 1, 9)) * _k * 0.9, _dR = ceil(clamp(1 + _cntR * 0.22, 1, 9)) * _k * 0.9;
    // thumb tabs: leather, rounded at the end that stands out of the fore-edge, on whichever side their chapter is (drawn before the pages, which cover their roots)
    var _secs = _b.sections, _ns = array_length(_secs);
    var _tabh = _ph * min(0.072, 0.84 / max(1, _ns)), _prot = max(8 * _k, _pw * 0.056), _root = _pw * 0.03;
    var _leathers = [[0.36, 0.10, 24], [0.52, 0.10, 70], [0.34, 0.07, 160], [0.33, 0.07, 255], [0.34, 0.08, 320], [0.48, 0.07, 50]];
    for (var _i = 0; _i < _ns; _i++) {
        var _tp = _secs[_i].page, _ty = _y + _ph * 0.07 + _i * (_ph * 0.84 / max(_ns, 6));
        var _onr = (_tp > _right);
        var _edge = _onr ? (_sp + _pw + _dR) : (_x - _dL), _sd = _onr ? 1 : -1;
        var _lr = _leathers[_i mod 6], _ramp = fol__ramp(_lr[0], _lr[1], _lr[2], 0.12);
        var _r = _tabh * 0.32, _xo = _edge + _sd * _prot, _xr = _edge - _sd * _root, _tp2 = [];
        array_push(_tp2, _xr, _ty);
        for (var _a = 0; _a <= 6; _a++) { var _an = -pi * 0.5 + _a / 6 * pi * 0.5; array_push(_tp2, _xo - _sd * _r + _sd * cos(_an) * _r, _ty + _r + sin(_an) * _r); }
        for (var _a = 0; _a <= 6; _a++) { var _an = _a / 6 * pi * 0.5; array_push(_tp2, _xo - _sd * _r + _sd * cos(_an) * _r, _ty + _tabh - _r + sin(_an) * _r); }
        array_push(_tp2, _xr, _ty + _tabh);
        fol__rect(_edge + (_onr ? 0 : -_prot) + _k * 2, _ty + _k * 3, _prot, _tabh, c_black, 0.25);
        fol__mass(_tp2, _ramp, max(1.2, _tabh * 0.10));
        array_push(_b.hot, { x0: min(_edge, _xo), y0: _ty, x1: max(_edge, _xo), y1: _ty + _tabh, page: _tp, kind: "tab" });
    }
    // the page block
    fol__block(_b, _x, _y, _k, -1, _cntL, _col, _gilt);
    fol__block(_b, _x, _y, _k, 1, _cntR, _col, _gilt);
    fol__b_end();
    // the open spread: under a turning leaf, the page it uncovers shows instead
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    var _ks = _k / _kc;
    var _sl = (_dir < 0) ? _sU : _sL, _sr = (_dir > 0) ? _sU : _sR;
    if (_dir < 0 && !surface_exists(_sl)) _sl = fol__page_surf(_b, _under, _kc);
    if (_dir > 0 && !surface_exists(_sr)) _sr = fol__page_surf(_b, _under, _kc);
    draw_surface_ext(_sl, _x, _y, _ks, _ks, 0, c_white, 1);
    draw_surface_ext(_sr, _sp, _y, _ks, _ks, 0, c_white, 1);
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    // the leaf
    if (_dir != 0) {
        var _gx, _gy, _gv;
        if (is_struct(_L)) { _gx = _L.gx; _gy = _L.gy; _gv = _L.gv; }
        else { var _a = _b.hover.amt; _gv = _b.ph; _gx = _b.pw - (10 + _b.pw * 0.06) * _a; _gy = _b.ph - (8 + _b.ph * 0.05) * _a; }
        if (!surface_exists(_sF)) _sF = fol__page_surf(_b, _front, _kc);
        if (!surface_exists(_sB)) _sB = fol__page_surf(_b, _back, _kc);
        fol__draw_leaf(_b, _x, _y, _k, _dir, _gx, _gy, _gv, _sF, _sB, _front, _back);
    }
    // the spine seam
    fol__b_begin();
    fol__quad(_sp - _k * 1.5, _y, c_black, 0, _sp, _y, c_black, 0.35, _sp, _y + _ph, c_black, 0.35, _sp - _k * 1.5, _y + _ph, c_black, 0);
    fol__quad(_sp, _y, c_black, 0.35, _sp + _k * 1.5, _y, c_black, 0, _sp + _k * 1.5, _y + _ph, c_black, 0, _sp, _y + _ph, c_black, 0.35);
    fol__b_end();
    // each tab's initial, on the part of the tab that stands clear of the pages
    for (var _i = 0; _i < _ns; _i++) {
        var _hh = _b.hot[_i], _lt = string_upper(string_char_at(_secs[_i].title, 1));
        var _lpx = min(_tabh * 0.52, _prot * 0.74);
        fol__text((_hh.x0 + _hh.x1) * 0.5, (_hh.y0 + _hh.y1) * 0.5 + _lpx * 0.36, _lt, "head", _lpx, fol_oklch(0.94, 0.035, 85), 1, fa_center);
    }
    // ribbons
    fol__ribbons(_b, _x, _y, _k, _left, _right);
    gpu_pop_state();
    draw_set_alpha(_pa); draw_set_colour(_pc);
    return true;
}
/// @function fol__ribbons(book, x, y, k, left, right)
/// @description Internal. Silk ribbons from the headband: one lying in an open page runs down across it and out at the foot; one in a closed part of the book shows only its tail, below the side its page is on.
function fol__ribbons(_b, _x, _y, _k, _left, _right) {
    var _cols = [fol__ramp(0.40, 0.15, 24, 0.14), fol__ramp(0.66, 0.12, 84, 0.14), fol__ramp(0.42, 0.10, 150, 0.14)];
    var _pw = _b.pw * _k, _ph = _b.ph * _k, _sp = _x + _pw, _rw = max(4, _pw * 0.034);
    fol__b_begin();
    for (var _i = 0; _i < array_length(_b.ribbons); _i++) {
        var _pg = _b.ribbons[_i].page;
        if (_pg < 0 || _pg >= array_length(_b.pages)) continue;
        var _rp = _cols[_i mod 3], _off = (_i - 1) * _rw * 1.6;
        var _open = (_pg == _left || _pg == _right) && !is_struct(_b.leaf);
        var _pts;
        if (_open) {
            // out of the headband beside the spine, down the page in a slack curve that drifts away from the gutter, and out over the foot
            var _sd = (_pg == _right) ? 1 : -1;
            var _x0 = _sp + _sd * (_rw * 0.9 + _i * _rw * 1.2), _x1 = _sp + _sd * (_pw * (0.11 + 0.05 * _i));
            var _xm = _x0 + (_x1 - _x0) * 0.15 + _sd * _pw * 0.02;
            _pts = [];
            for (var _q = 0; _q <= 10; _q++) {
                var _t = _q / 10, _u = 1 - _t;
                array_push(_pts, _u * _u * _x0 + 2 * _u * _t * _xm + _t * _t * _x1, _y - _k * 5 + (_ph + _k * 4) * _t);
            }
            array_push(_pts, _x1 + _sd * _rw * 0.25, _y + _ph + _ph * 0.085);
        } else {
            var _sd2 = (_pg > _right) ? 1 : -1, _bx = _sp + _sd2 * (_pw * (0.30 + 0.14 * _i));
            _pts = [_bx, _y + _ph - _k * 2, _bx + _sd2 * _rw * 0.5, _y + _ph + _ph * 0.045, _bx + _sd2 * _rw * 0.9, _y + _ph + _ph * 0.10];
        }
        var _np = array_length(_pts) div 2;
        // a band along the polyline, light down its middle (silk), the end cut in a swallowtail
        for (var _j = 0; _j < _np - 1; _j++) {
            var _ax = _pts[_j * 2], _ay = _pts[_j * 2 + 1], _bx2 = _pts[_j * 2 + 2], _by = _pts[_j * 2 + 3];
            var _dx = _bx2 - _ax, _dy = _by - _ay, _l = max(0.001, sqrt(_dx * _dx + _dy * _dy)), _nx = -_dy / _l * _rw * 0.5, _ny = _dx / _l * _rw * 0.5;
            fol__quad(_ax + _nx + _k * 2, _ay + _ny + _k * 3, c_black, 0.18, _bx2 + _nx + _k * 2, _by + _ny + _k * 3, c_black, 0.18, _bx2 - _nx + _k * 2, _by - _ny + _k * 3, c_black, 0.18, _ax - _nx + _k * 2, _ay - _ny + _k * 3, c_black, 0.18);
            fol__quad(_ax + _nx, _ay + _ny, _rp[1], 1, _bx2 + _nx, _by + _ny, _rp[1], 1, _bx2, _by, _rp[4], 1, _ax, _ay, _rp[4], 1);
            fol__quad(_ax, _ay, _rp[4], 1, _bx2, _by, _rp[4], 1, _bx2 - _nx, _by - _ny, _rp[1], 1, _ax - _nx, _ay - _ny, _rp[1], 1);
        }
        var _ex = _pts[(_np - 1) * 2], _ey = _pts[(_np - 1) * 2 + 1], _fx = _pts[(_np - 2) * 2], _fy = _pts[(_np - 2) * 2 + 1];
        var _dx2 = _ex - _fx, _dy2 = _ey - _fy, _l2 = max(0.001, sqrt(_dx2 * _dx2 + _dy2 * _dy2)), _ux = _dx2 / _l2, _uy = _dy2 / _l2;
        var _ex2 = _ex + _ux * _rw * 0.6, _ey2 = _ey + _uy * _rw * 0.6, _nx2 = -_uy * _rw * 0.5, _ny2 = _ux * _rw * 0.5;
        fol__tri(_ex + _nx2, _ey + _ny2, _rp[1], 1, _ex2 + _nx2, _ey2 + _ny2, _rp[0], 1, _ex, _ey, _rp[3], 1);
        fol__tri(_ex - _nx2, _ey - _ny2, _rp[1], 1, _ex2 - _nx2, _ey2 - _ny2, _rp[0], 1, _ex, _ey, _rp[3], 1);
        if (!_open) array_push(_b.hot, { x0: min(_pts[0], _ex2) - _rw, y0: _y + _ph, x1: max(_pts[0], _ex2) + _rw, y1: _ey2 + _rw, page: _pg, kind: "ribbon" });
    }
    fol__b_end();
}
/// @function fol__draw_leaf(book, x, y, k, dir, gx, gy, gv, front, back, front_page, back_page)
/// @description Internal. The turning leaf: the shadow it throws on the page it uncovers, its front (flat and rising), the shadow of the part lying back down, then that part (the leaf's back) and the highlight down the curl.
function fol__draw_leaf(_b, _x, _y, _k, _dir, _gx, _gy, _gv, _sF, _sB, _fp, _bp) {
    var _pw = _b.pw, _ph = _b.ph, _sp = _x + _pw * _k;
    var _P = fol_leaf_pose(_pw, _ph, _gv, _gx, _gy, 0.5);
    if (_P.flat) return;
    var _bands = fol_leaf_bands(_P, _pw, _ph, 12);
    // a texture's x for a leaf point: a right-hand page has its spine at its left edge, a left-hand page at its right
    var _n = array_length(_b.pages);
    var _frecto = (_fp >= 0 && _fp < _n) ? ((_fp mod 2) == 0) : (_dir > 0);
    var _brecto = !_frecto;
    // 1: the shadow under the curl, on the page beneath
    var _c0 = _P.lx * _P.nx + _P.ly * _P.ny, _sw = max(10, _P.r * 2.4 + _P.d * 0.06);
    var _band = fol__clip_half([0, 0, _pw, 0, _pw, _ph, 0, _ph], _P.nx, _P.ny, _c0, true);
    _band = fol__clip_half(_band, _P.nx, _P.ny, _c0 + _sw, false);
    var _fade = clamp(_P.d / (_pw * 0.25), 0, 1) * 0.38;
    fol__b_begin();
    var _nb = array_length(_band) div 2;
    for (var _i = 1; _i < _nb - 1; _i++) {
        var _ids = [0, _i, _i + 1];
        var _vx = array_create(3), _vy = array_create(3), _va = array_create(3);
        for (var _q = 0; _q < 3; _q++) {
            var _px = _band[_ids[_q] * 2], _py = _band[_ids[_q] * 2 + 1], _s = (_px * _P.nx + _py * _P.ny) - _c0;
            _vx[_q] = _sp + _dir * _px * _k; _vy[_q] = _y + _py * _k; _va[_q] = _fade * power(clamp(1 - _s / _sw, 0, 1), 1.6);
        }
        fol__tri(_vx[0], _vy[0], c_black, _va[0], _vx[1], _vy[1], c_black, _va[1], _vx[2], _vy[2], c_black, _va[2]);
    }
    fol__b_end();
    // 2: the front of the leaf
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    fol__leaf_pass(_b, _P, _bands, 1, _sF, _frecto, _sp, _y, _k, _dir);
    // 3: the part lying back down throws a soft shadow on whatever is under it
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    // three widening layers make the shadow soft, and it falls only on the pages (the leaf lies almost on them; beyond their edge a shadow reads as a grey card)
    var _bx0 = _x, _bx1 = _x + _pw * 2 * _k, _by0 = _y, _by1 = _y + _ph * _k;
    fol__b_begin();
    for (var _ly = 0; _ly < 3; _ly++) {
        var _sc = 1 + _ly * 0.8, _ox = ((2 + _P.r * 0.30) * _dir * 0.5 + 1.5) * _k * _sc, _oy = (2.5 + _P.r * 0.40) * _k * _sc, _al = 0.075;
        for (var _i = 0; _i < array_length(_bands); _i++) {
            var _bd = _bands[_i];
            if (_bd.side > 0) continue;
            var _pts = _bd.pts, _np = array_length(_pts) div 2, _sh = array_create(_np * 2, 0);
            for (var _j = 0; _j < _np; _j++) { var _mj = fol_leaf_map(_P, _pts[_j * 2], _pts[_j * 2 + 1]); _sh[_j * 2] = _sp + _dir * _mj[0] * _k + _ox; _sh[_j * 2 + 1] = _y + _mj[1] * _k + _oy; }
            _sh = fol__clip_half(_sh, 1, 0, _bx0, true); _sh = fol__clip_half(_sh, 1, 0, _bx1, false);
            _sh = fol__clip_half(_sh, 0, 1, _by0, true); _sh = fol__clip_half(_sh, 0, 1, _by1, false);
            var _ns = array_length(_sh) div 2;
            for (var _j = 1; _j < _ns - 1; _j++) fol__tri(_sh[0], _sh[1], c_black, _al, _sh[_j * 2], _sh[_j * 2 + 1], c_black, _al, _sh[_j * 2 + 2], _sh[_j * 2 + 3], c_black, _al);
        }
    }
    fol__b_end();
    // 4: the back of the leaf
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    fol__leaf_pass(_b, _P, _bands, -1, _sB, _brecto, _sp, _y, _k, _dir);
    // 5: the highlight where the curl turns toward the lamp
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_one, bm_zero, bm_one);
    fol__b_begin();
    for (var _i = 0; _i < array_length(_bands); _i++) {
        var _bd = _bands[_i];
        if (_bd.a1 <= 0) continue;
        var _pts = _bd.pts, _np = array_length(_pts) div 2;
        for (var _j = 1; _j < _np - 1; _j++) {
            var _ids = [0, _j, _j + 1], _vx = array_create(3), _vy = array_create(3), _va = array_create(3);
            for (var _q = 0; _q < 3; _q++) {
                var _m = fol_leaf_map(_P, _pts[_ids[_q] * 2], _pts[_ids[_q] * 2 + 1]);
                _vx[_q] = _sp + _dir * _m[0] * _k; _vy[_q] = _y + _m[1] * _k;
                _va[_q] = clamp((fol_leaf_shade(_P, _m[4], _m[3], _dir) - 1) * 1.3, 0, 0.28);
            }
            fol__tri(_vx[0], _vy[0], c_white, _va[0], _vx[1], _vy[1], c_white, _va[1], _vx[2], _vy[2], c_white, _va[2]);
        }
    }
    fol__b_end();
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
}
/// @function fol__leaf_pass(book, pose, bands, side, surface, recto, spine_x, y, k, dir)
/// @description Internal. One face of the leaf as textured triangles, each vertex shaded by how the paper there faces the lamp.
function fol__leaf_pass(_b, _P, _bands, _side, _surf, _recto, _sp, _y, _k, _dir) {
    if (!surface_exists(_surf)) return 0;
    var _tex = surface_get_texture(_surf), _pw = _b.pw, _ph = _b.ph, _nt = 0;
    draw_primitive_begin_texture(pr_trianglelist, _tex);
    var _vn = 0;
    for (var _i = 0; _i < array_length(_bands); _i++) {
        var _bd = _bands[_i];
        if (_bd.side != _side) continue;
        var _pts = _bd.pts, _np = array_length(_pts) div 2;
        var _mx = array_create(_np), _my = array_create(_np), _mu = array_create(_np), _mv = array_create(_np), _mc = array_create(_np);
        for (var _j = 0; _j < _np; _j++) {
            var _u = _pts[_j * 2], _v = _pts[_j * 2 + 1], _m = fol_leaf_map(_P, _u, _v);
            _mx[_j] = _sp + _dir * _m[0] * _k; _my[_j] = _y + _m[1] * _k;
            _mu[_j] = (_recto ? _u : (_pw - _u)) / _pw; _mv[_j] = _v / _ph;
            var _sh = min(1, fol_leaf_shade(_P, _m[4], _m[3], _dir)), _g = round(255 * _sh);
            _mc[_j] = make_colour_rgb(_g, _g, _g);
        }
        for (var _j = 1; _j < _np - 1; _j++) {
            if (_vn > 894) { draw_primitive_end(); draw_primitive_begin_texture(pr_trianglelist, _tex); _vn = 0; }
            draw_vertex_texture_colour(_mx[0], _my[0], _mu[0], _mv[0], _mc[0], 1);
            draw_vertex_texture_colour(_mx[_j], _my[_j], _mu[_j], _mv[_j], _mc[_j], 1);
            draw_vertex_texture_colour(_mx[_j + 1], _my[_j + 1], _mu[_j + 1], _mv[_j + 1], _mc[_j + 1], 1);
            _vn += 3; _nt++;
        }
    }
    draw_primitive_end();
    return _nt;
}
/// @function fol_book_free(book)
/// @description Free a book's page surfaces. Call it in Clean Up (the paper sprites are shared between books: fol_art_free deletes those).
/// @param {struct} book
/// @returns {real} How many surfaces were freed.
function fol_book_free(_b) {
    if (!fol__is_book(_b)) return 0;
    return fol__surf_free(_b);
}

// ------------------------------------------------------------------------------------------------ the devices

/// @function fol_book_read(book, gui)
/// @description Read the mouse, the keyboard (arrows, Page Up/Down, Home/End) and the first gamepad's shoulder buttons, and feed them to the book. gui true (default) reads the mouse in GUI space, for a book drawn in Draw GUI; false reads it in the room.
/// @param {struct} book
/// @param {bool} gui
/// @returns {bool}
function fol_book_read(_b, _gui = true) {
    if (!fol__is_book(_b)) return false;
    var _mx = (_gui == false) ? mouse_x : device_mouse_x_to_gui(0), _my = (_gui == false) ? mouse_y : device_mouse_y_to_gui(0);
    var _nx = keyboard_check_pressed(vk_right) || keyboard_check_pressed(vk_pagedown);
    var _pv = keyboard_check_pressed(vk_left) || keyboard_check_pressed(vk_pageup);
    for (var _g = 0; _g < 4; _g++) if (gamepad_is_connected(_g)) {
        if (gamepad_button_check_pressed(_g, gp_shoulderr) || gamepad_button_check_pressed(_g, gp_padr)) _nx = true;
        if (gamepad_button_check_pressed(_g, gp_shoulderl) || gamepad_button_check_pressed(_g, gp_padl)) _pv = true;
    }
    if (keyboard_check_pressed(vk_home)) fol_book_goto(_b, 0);
    if (keyboard_check_pressed(vk_end)) fol_book_goto(_b, fol_book_pages(_b) - 1);
    return fol_book_feed(_b, { mx: _mx, my: _my, down: mouse_check_button(mb_left), pressed: mouse_check_button_pressed(mb_left), released: mouse_check_button_released(mb_left), next: _nx, prev: _pv });
}
