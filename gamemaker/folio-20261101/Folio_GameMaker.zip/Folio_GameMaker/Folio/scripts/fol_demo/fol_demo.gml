/// fol_demo.gml - THE READING ROOM, Folio's demo: a book on a desk under a lamp, holding a short guide to itself. Drag a corner, click a
/// page, or use the arrows / Page Up and Down / a gamepad's shoulders to turn; Q and E (or the arrows on the plaque, or a gamepad's
/// face buttons) change the paper through all 48 looks; click a thumb tab or a ribbon's tail to jump. Everything on screen is drawn
/// by the package; nothing here ships an image.
///
/// Folio - A Page-Turning Book for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function fol_demo_desk(w, h)
/// @description The desk the demo's book lies on, as a sprite: walnut boards, their grain, and the pool of a lamp. Cached by size; fol_art_free deletes it.
/// @param {real} w
/// @param {real} h
/// @returns {asset.GMSprite}
function fol_demo_desk(_w, _h) {
    _w = clamp(round(fol__n(_w, 1280)), 64, 4096); _h = clamp(round(fol__n(_h, 720)), 64, 4096);
    var _key = "desk_" + string(_w) + "x" + string(_h), _c = fol__cache();
    if (variable_struct_exists(_c, _key) && sprite_exists(_c[$ _key])) return _c[$ _key];
    var _g = fol_rng(4242);
    var _bk = fol__bake_begin(_w, _h, 1);
    fol__b_begin();
    var _wood = fol__ramp(0.30, 0.055, 48, 0.10);
    var _bh = _h / 5;
    for (var _i = 0; _i < 5; _i++) {
        var _y0 = _i * _bh, _base = fol__ramp_at(_wood, 0.35 + 0.15 * fol_rand(_g));
        fol__rect(0, _y0, _w, _bh, _base, 1);
        // grain: long gently waving lines, a physical pitch
        for (var _l = 0; _l < _bh / 3.2; _l++) {
            var _yy = _y0 + fol_rand(_g) * _bh, _amp = 1 + fol_rand(_g) * 3, _ph = fol_rand(_g) * 6.28, _p = [];
            for (var _x = 0; _x <= _w + 40; _x += 40) array_push(_p, _x, _yy + sin(_x * 0.006 + _ph) * _amp + sin(_x * 0.021 + _ph * 2) * _amp * 0.4);
            fol__stroke(_p, 1, (fol_rand(_g) < 0.5) ? _wood[0] : _wood[3], 0.10 + 0.12 * fol_rand(_g));
        }
        fol__rect(0, _y0, _w, 1.5, c_black, 0.45);
        fol__rect(0, _y0 + 1.5, _w, 1, _wood[4], 0.18);
    }
    // the lamp: a warm pool, upper left of the book
    for (var _r = 0; _r < 9; _r++) fol__spot(_w * 0.46, _h * 0.42, max(_w, _h) * (0.62 - _r * 0.05), fol_oklch(0.85, 0.09, 75), 0.055, 32);
    // the room falls into shadow at the edges
    var _k = c_black;
    fol__quad(0, 0, _k, 0.55, _w, 0, _k, 0.55, _w, _h * 0.16, _k, 0, 0, _h * 0.16, _k, 0);
    fol__quad(0, _h, _k, 0.60, _w, _h, _k, 0.60, _w, _h * 0.80, _k, 0, 0, _h * 0.80, _k, 0);
    fol__quad(0, 0, _k, 0.50, _w * 0.14, 0, _k, 0, _w * 0.14, _h, _k, 0, 0, _h, _k, 0.50);
    fol__quad(_w, 0, _k, 0.50, _w * 0.86, 0, _k, 0, _w * 0.86, _h, _k, 0, _w, _h, _k, 0.50);
    fol__b_end();
    var _spr = fol__bake_end(_bk);
    _c[$ _key] = _spr;
    return _spr;
}
/// @function fol_demo_compass(size)
/// @description A compass rose drawn by code into a sprite, so the demo has a picture to set as a plate without shipping an image. Cached; fol_art_free deletes it.
/// @param {real} size
/// @returns {asset.GMSprite}
function fol_demo_compass(_s) {
    _s = clamp(round(fol__n(_s, 256)), 32, 1024);
    var _key = "compass_" + string(_s), _c = fol__cache();
    if (variable_struct_exists(_c, _key) && sprite_exists(_c[$ _key])) return _c[$ _key];
    var _bk = fol__bake_begin(_s, _s, 2);
    fol__b_begin();
    var _cx = _s * 0.5, _cy = _s * 0.5, _R = _s * 0.46;
    var _ink = fol_oklch(0.24, 0.03, 50), _red = fol_oklch(0.50, 0.16, 28), _pale = fol_oklch(0.93, 0.03, 85);
    fol__ring(_cx, _cy, _R, max(1.5, _s * 0.012), _ink, 1, 64);
    fol__ring(_cx, _cy, _R * 0.9, 1, _ink, 0.8, 64);
    for (var _i = 0; _i < 32; _i++) { var _a = _i / 32 * 2 * pi, _l = ((_i mod 4) == 0) ? 0.82 : 0.86; fol__seg(_cx + cos(_a) * _R * _l, _cy + sin(_a) * _R * _l, _cx + cos(_a) * _R * 0.9, _cy + sin(_a) * _R * 0.9, 1, _ink, 0.8); }
    for (var _i = 0; _i < 8; _i++) {
        var _a = -pi * 0.5 + _i / 8 * 2 * pi, _len = ((_i mod 2) == 0) ? _R * 0.86 : _R * 0.55, _wd = ((_i mod 2) == 0) ? _R * 0.12 : _R * 0.08;
        var _tx = _cx + cos(_a) * _len, _ty = _cy + sin(_a) * _len, _lx = _cx + cos(_a - pi * 0.5) * _wd, _ly = _cy + sin(_a - pi * 0.5) * _wd, _rx = _cx + cos(_a + pi * 0.5) * _wd, _ry = _cy + sin(_a + pi * 0.5) * _wd;
        var _main = (_i == 0) ? _red : _ink;
        fol__tri(_cx, _cy, _main, 1, _lx, _ly, _main, 1, _tx, _ty, _main, 1);
        fol__tri(_cx, _cy, _pale, 1, _tx, _ty, _pale, 1, _rx, _ry, _pale, 1);
        fol__stroke([_lx, _ly, _tx, _ty, _rx, _ry], 1, _ink, 0.9);
    }
    fol__disc(_cx, _cy, _R * 0.06, _ink, 1, 16);
    fol__disc(_cx, _cy, _R * 0.03, _pale, 1, 12);
    fol__b_end();
    var _spr = fol__bake_end(_bk);
    _c[$ _key] = _spr;
    return _spr;
}
/// @function fol_demo_fill(book)
/// @description The demo's book: a short guide to Folio, set in five chapters with a plate, a live drawing, headings and two ribbons.
/// @param {struct} book
/// @returns {bool}
function fol_demo_fill(_b) {
    if (!fol__is_book(_b)) return false;
    fol_book_clear(_b);
    fol_book_chapter(_b, "On Turning");
    fol_book_text(_b, "Take the lower corner of a right-hand page and draw it across the spine. The paper bends where you hold it and lies flat where it is still bound, and the light runs along the curl as it rises. Let go past the spine and the page falls over by itself; let go short of it and it springs back into place. A quick flick is enough, too.\nA click on either page turns it. The arrow keys, Page Up and Page Down, and the shoulder buttons of a gamepad do the same, and pressing them again while a leaf is still in the air queues the next turn, so a held key riffles through the book.\nResting the pointer near a corner lifts it a little, the way a page invites a reader who has reached the foot of it.");
    fol_book_heading(_b, "Where the light falls");
    fol_book_text(_b, "Every leaf is drawn as a mesh cut along the fold. The part still lying flat is one piece; the curl is cut into bands, each shaded by how squarely it faces a lamp above and to the left; the part that has gone over is the back of the leaf, which is the next page you will read. Beneath the curl the uncovered page darkens in the leaf's shadow, and the part lying back down throws a soft shadow of its own.\nNothing here is a picture of a page turning. It is the page you composed, bent.");
    fol_book_chapter(_b, "Forty-Eight Papers");
    fol_book_text(_b, "There are eight stocks: ivory laid, with its chain lines; cream wove; rag white; vellum, with the faint drift of follicles across it; parchment, mottled and uneven; brown kraft; pale ledger green; and a midnight paper written on in silver ink.\nEach stock comes ruled six ways: blank, lined to the text's own baselines, squared, laid out as a ledger, ruled with music staves below the writing, or dotted. That makes forty-eight papers, and no two of them share both a stock and a ruling.\nOn top of that each look chooses its edge, cut clean, torn as a deckle, or gilt; its age, from new through worn to foxed with rust-coloured spots and the odd tide line; a frame; a way of printing the page number; a headpiece over each chapter; and the style of its drop initials.");
    fol_book_heading(_b, "Changing the paper");
    fol_book_text(_b, "Press Q or E to walk through the papers. The book keeps its place, and the text flows again, because a frame can widen a margin and a margin decides where every line breaks.");
    fol_book_chapter(_b, "Your Own Words");
    fol_book_text(_b, "Give a book a chapter, then text. Each line of the string you hand it is a paragraph. Pagination sets the words on lines, justified or ragged, and lays the lines down the page on a grid of whole lines, so ruled paper and text always agree.\nA paragraph of four lines or more never leaves a single line stranded at the foot of a page or carried alone to the head of the next. A shorter one moves whole. A heading is never left at the bottom of a page without the two lines that follow it, and the first paragraph of each chapter opens with an initial three lines deep.\nThe left-hand pages carry the chapter's name at their head, the right-hand pages the book's title, and every page its number, in arabic or roman figures.");
    fol_book_heading(_b, "A word too long");
    fol_book_text(_b, "Should a single word be wider than a whole line, it is broken by its letters rather than left to run off the paper: Pneumonoultramicroscopicsilicovolcanoconiosis is the usual test, and here it is.");
    fol_book_chapter(_b, "Plates and Drawings");
    fol_book_text(_b, "A picture is set into the text as a mounted plate, scaled to the measure, with a caption beneath it in italic. If it does not fit what is left of a page, it moves to the next and the text closes up behind it.");
    fol_book_picture(_b, fol_demo_compass(256), 0, 0, "The compass rose, drawn by code and set as a plate.");
    fol_book_text(_b, "Your own drawing can take a place in the flow as well. Reserve a height, and Folio calls your function while that page is composed, with the page as the target, so a map, a chart or a portrait sits on the paper exactly as ink would.");
    fol_book_custom(_b, 150, function(_x, _y, _w, _h, _page) {
        var _cx = _x + _w * 0.5, _cy = _y + _h * 0.5, _g = fol_rng(7 + _page);
        draw_set_colour(merge_colour(c_black, c_navy, 0.5)); draw_set_alpha(0.85);
        draw_rectangle(_x + _w * 0.12, _y, _x + _w * 0.88, _y + _h, false);
        draw_set_colour(c_white);
        for (var _i = 0; _i < 60; _i++) { draw_set_alpha(0.4 + 0.6 * fol_rand(_g)); var _sx = _x + _w * (0.14 + 0.72 * fol_rand(_g)), _sy = _y + 4 + (_h - 8) * fol_rand(_g); draw_circle(_sx, _sy, 0.6 + fol_rand(_g) * 1.4, false); }
        draw_set_alpha(0.7); draw_set_colour(make_colour_rgb(230, 210, 150));
        draw_line_width(_cx - _w * 0.2, _cy + 20, _cx - _w * 0.05, _cy - 12, 1); draw_line_width(_cx - _w * 0.05, _cy - 12, _cx + _w * 0.12, _cy + 4, 1); draw_line_width(_cx + _w * 0.12, _cy + 4, _cx + _w * 0.24, _cy - 30, 1);
        draw_set_alpha(1); draw_set_colour(c_white);
    });
    fol_book_text(_b, "Above is a small star chart drawn by the demo's own code each time its page is composed.");
    fol_book_chapter(_b, "Ribbons and Tabs");
    fol_book_text(_b, "Up to three silk ribbons can be laid in a book. A ribbon in an open page runs down across it from the headband and out at the foot; one marking a page elsewhere shows only its tail below the book, on the side its page lies, and clicking the tail opens the book there.\nEvery chapter can carry a thumb tab on the fore-edge, standing out on whichever side of the open book its chapter is. Click a tab and the book riffles to it.\nThat is the whole of it: a book that composes its pages from your words and its own paper, and turns them as paper turns.");
    fol_book_ribbon(_b, 0, 9);
    fol_book_ribbon(_b, 1, 3);
    return true;
}
/// @function fol_demo_create()
/// @description THE READING ROOM: the demo's state.
/// @returns {struct}
function fol_demo_create() {
    var _b = fol_book_create({ page_w: 420, page_h: 560, paper: "Bestiary", title: "A Field Guide to Paper", seed: 3 });
    fol_demo_fill(_b);
    fol_book_paginate(_b);
    return { book: _b, x: 220, y: 96, k: 1, msg: "", msg_t: 0, prev_btn: undefined, next_btn: undefined };
}
/// @function fol_demo_paper(demo, step)
/// @description Move the demo's book to the next (step 1) or previous (step -1) paper, keeping its place.
/// @param {struct} demo
/// @param {real} step
/// @returns {real} The new paper's index.
function fol_demo_paper(_d, _s) {
    var _b = _d.book, _n = fol_paper_count(), _p = (_b.paper + _s + _n) mod _n;
    var _at = fol_spread_pages(_b, _b.spread)[1];
    fol_book_set_paper(_b, _p);
    fol_book_paginate(_b);
    fol_book_goto(_b, max(0, min(_at, fol_book_pages(_b) - 1)), true);
    return _p;
}
/// @function fol_demo_step(demo)
/// @description One frame of the reading room.
/// @param {struct} demo
/// @returns {bool}
function fol_demo_step(_d) {
    if (!is_struct(_d)) return false;
    var _b = _d.book;
    var _mx = device_mouse_x_to_gui(0), _my = device_mouse_y_to_gui(0), _clicked = mouse_check_button_pressed(mb_left);
    var _ch = 0;
    if (keyboard_check_pressed(ord("E")) || keyboard_check_pressed(vk_add)) _ch = 1;
    if (keyboard_check_pressed(ord("Q")) || keyboard_check_pressed(vk_subtract)) _ch = -1;
    for (var _g = 0; _g < 4; _g++) if (gamepad_is_connected(_g)) { if (gamepad_button_check_pressed(_g, gp_face4)) _ch = 1; if (gamepad_button_check_pressed(_g, gp_face3)) _ch = -1; }
    var _ok = true;
    if (_clicked && is_struct(_d.prev_btn) && point_in_rectangle(_mx, _my, _d.prev_btn.x0, _d.prev_btn.y0, _d.prev_btn.x1, _d.prev_btn.y1)) { _ch = -1; _ok = false; }
    if (_clicked && is_struct(_d.next_btn) && point_in_rectangle(_mx, _my, _d.next_btn.x0, _d.next_btn.y0, _d.next_btn.x1, _d.next_btn.y1)) { _ch = 1; _ok = false; }
    if (_ch != 0 && !fol_book_turning(_b)) fol_demo_paper(_d, _ch);
    if (_ok) fol_book_read(_b, true);
    fol_book_step(_b);
    return true;
}
/// @function fol_demo_draw(demo, w, h)
/// @description Draw the reading room into a w x h area (GUI space in the demo).
/// @param {struct} demo
/// @param {real} w
/// @param {real} h
/// @returns {bool}
function fol_demo_draw(_d, _w, _h) {
    if (!is_struct(_d)) return false;
    var _b = _d.book;
    var _desk = fol_demo_desk(_w, _h);
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    draw_sprite(_desk, 0, 0, 0);
    gpu_set_blendmode(bm_normal);
    var _k = min((_w - 120) / (_b.pw * 2), (_h - 150) / _b.ph);
    _d.k = _k; _d.x = (_w - _b.pw * 2 * _k) * 0.5; _d.y = 64 + (_h - 150 - _b.ph * _k) * 0.5;
    fol_book_draw(_b, _d.x, _d.y, _k);
    // the plaque: the paper's name and its number, and the arrows that change it
    var _pal = fol_oklch(0.90, 0.05, 80), _dim = fol_oklch(0.72, 0.05, 70), _acc = fol_oklch(0.74, 0.12, 80);
    var _name = fol_paper_name(_b.paper), _lk = fol_paper_look(_b.paper);
    fol__text(_w * 0.5, 34, "FOLIO", "title", 30, _pal, 1, fa_center);
    var _line = string(_b.paper + 1) + " / " + string(fol_paper_count()) + "   " + string_upper(_name);
    fol__text(_w * 0.5, 56, _line, "head", 15, _acc, 1, fa_center);
    var _tw = fol__font_width(_line, "head", 15);
    _d.prev_btn = { x0: _w * 0.5 - _tw * 0.5 - 40, y0: 38, x1: _w * 0.5 - _tw * 0.5 - 12, y1: 62 };
    _d.next_btn = { x0: _w * 0.5 + _tw * 0.5 + 12, y0: 38, x1: _w * 0.5 + _tw * 0.5 + 40, y1: 62 };
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    fol__b_begin();
    var _pb = _d.prev_btn, _nb = _d.next_btn, _cy = (_pb.y0 + _pb.y1) * 0.5;
    fol__tri(_pb.x1, _cy - 7, _acc, 1, _pb.x1, _cy + 7, _acc, 1, _pb.x0 + 8, _cy, _acc, 1);
    fol__tri(_nb.x0, _cy - 7, _acc, 1, _nb.x1 - 8, _cy, _acc, 1, _nb.x0, _cy + 7, _acc, 1);
    fol__b_end();
    gpu_pop_state();
    var _sub = _lk.ruling + " " + fol__stocks()[$ _lk.stock].name + ", " + _lk.edge + " edge, " + _lk.age;
    fol__text(_w * 0.5, _h - 34, _sub, "italic", 16, _dim, 1, fa_center);
    fol__text(_w * 0.5, _h - 12, "DRAG A CORNER OR CLICK A PAGE   ARROWS / SHOULDERS TURN   Q E CHANGE THE PAPER   TABS AND RIBBONS JUMP", "head", 12, _dim, 0.85, fa_center);
    return true;
}
/// @function fol_demo_free(demo)
/// @description Free the reading room.
/// @param {struct} demo
/// @returns {bool}
function fol_demo_free(_d) {
    if (!is_struct(_d)) return false;
    fol_book_free(_d.book);
    fol_art_free();
    return true;
}
