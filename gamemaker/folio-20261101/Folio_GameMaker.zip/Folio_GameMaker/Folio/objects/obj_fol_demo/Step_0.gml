/// @description One frame of the room.
if (!is_undefined(demo)) fol_demo_step(demo);
