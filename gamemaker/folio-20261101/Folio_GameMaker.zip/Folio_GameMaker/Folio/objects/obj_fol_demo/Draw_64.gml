/// @description Draw the room in GUI space.
if (!is_undefined(demo)) fol_demo_draw(demo, display_get_gui_width(), display_get_gui_height());
