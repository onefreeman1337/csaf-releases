/// @description Free the room. Clean Up runs even after Create left early, so check first.
if (variable_instance_exists(id, "demo") && !is_undefined(demo)) fol_demo_free(demo);
