{
  "$GMScript": "v1",
  "%Name": "lvy_selftest",
  "name": "lvy_selftest",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}