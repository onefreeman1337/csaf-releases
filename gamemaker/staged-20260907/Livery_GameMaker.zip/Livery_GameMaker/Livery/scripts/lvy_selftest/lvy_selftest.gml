/// LIVERY - lvy_selftest. The in-engine suite.
///
/// ⛔ GML CANNOT BE UNIT-TESTED OUTSIDE THE ENGINE. There is no Node-mockable core and no
/// -batchmode equivalent, so verification risk in this wing is structurally higher than anywhere
/// else in this factory, and saying otherwise would be the failure the master constitution's §2
/// forbids. What IS possible is running the real product inside a real Igor-built executable and
/// writing the result to a file, and that is what this is.
///
/// HOW IT RUNS:  Livery.exe -selftest  ->  %LOCALAPPDATA%\Livery\lvy_selftest.json
///
/// Four routes were measured on a previous product in this wing and three are dead:
///   show_debug_message + -debugoutput   dead in a release build
///   game_end(n) exit code               the argument is not propagated
///   stdout                              there is none
///   file_text_open_write                ✅ the one that works
///
/// -- WHAT THIS SUITE CAN AND CANNOT SEE ------------------------------------------------------
/// ⛔ IT CANNOT SEE THE PICTURE. This wing's constitution is a list of defects that passed every
/// mechanical check and were found by opening a PNG and looking: a gilt rim drawn across the food,
/// every moon crescent rendered as a quarter, ten of forty-two devices reading as the wrong object,
/// five cloud genera as concrete boxes. Every one of them had a green suite.
///
/// So this suite tests CONTRACTS, which is what it can reach: winding, containment, separation,
/// determinism, role coverage, emission order. The picture is checked by baking the store sheets
/// and looking at them, and that step is not optional and is not replaceable by anything here.
///
/// ⭐ AND EVERY LOOP CARRIES A VACUITY GUARD. A containment assertion that runs over zero shapes
/// passes, silently, forever. lvy_check_count is called before any loop whose body asserts, so a
/// corpus that fails to build is a red suite rather than a green one.
/// ============================================================================================

global.lvy_stage = -1;

function lvy_test_new() {
    return { pass: 0, fail: 0, stage: -1, notes: [] };
}

/// ⛔ ONE WRITER, TWO READERS. The suite reads _t.stage; the crash handler reads the global. Setting
/// the global only after a run finishes would report stage -1 for exactly the case the handler
/// exists for.
function lvy_set_stage(_t, _n) {
    _t.stage = _n;
    global.lvy_stage = _n;
}

function lvy_check(_t, _cond, _label) {
    if (_cond) { _t.pass += 1; return true; }
    _t.fail += 1;
    array_push(_t.notes, "FAIL: " + string(_label));
    return false;
}

/// Assert a COUNT is at least _min. Called before any loop whose body carries assertions, so a loop
/// that runs zero times is a failure rather than a silent pass.
function lvy_check_count(_t, _n, _min, _label) {
    return lvy_check(_t, _n >= _min,
                     _label + " count " + string(_n) + " < required " + string(_min));
}

/// Perceptual distance between two GameMaker colours, deliberately crude and only ever used with a
/// generous floor. A precise metric invites a precise threshold, and a precise threshold on a
/// perceptual quantity is how a distinctness assertion becomes a number nobody can defend. What it
/// must catch is "these two are the same colour", which is a large difference or none.
function lvy_col_dist(_a, _b) {
    var _dr = (colour_get_red(_a)   - colour_get_red(_b))   / 255;
    var _dg = (colour_get_green(_a) - colour_get_green(_b)) / 255;
    var _db = (colour_get_blue(_a)  - colour_get_blue(_b))  / 255;
    return sqrt(_dr * _dr * 0.30 + _dg * _dg * 0.59 + _db * _db * 0.11);
}

/// Relative luminance of a GameMaker colour, 0..1. Used for the ink-contrast assertion, which has
/// to be made on the COLOUR THAT SHIPS rather than on the lightness that was requested - the
/// request passes through a gamut walk and a gamma transfer before it becomes a pixel.
function lvy_lum(_c) {
    return (colour_get_red(_c) * 0.2126 + colour_get_green(_c) * 0.7152
          + colour_get_blue(_c) * 0.0722) / 255;
}

/// Every part in a list, checked against a rect. Returns the worst overshoot in pixels, 0 if none.
function lvy_worst_overshoot(_parts, _x0, _y0, _x1, _y1) {
    var _b = lvy_render_bounds(_parts);
    if (array_length(_parts) == 0) return 0;
    return max(0, max(_x0 - _b[0], _b[2] - _x1, _y0 - _b[1], _b[3] - _y1));
}

/// Does a part list contain a triangle FAN?
function lvy_has_fill(_parts) {
    for (var _i = 0; _i < array_length(_parts); _i++) {
        if (_parts[_i].kind == LVY_FILL) return true;
    }
    return false;
}

/// A stable digest of a part list's geometry, for the determinism assertions.
function lvy_geom_digest(_parts) {
    var _s = "";
    for (var _i = 0; _i < array_length(_parts); _i++) {
        var _p = _parts[_i];
        _s += string(_p.kind) + ":" + string(_p.role) + ":";
        switch (_p.kind) {
            case LVY_DOT: _s += string_format(_p.cx, 1, 3) + "," + string_format(_p.cy, 1, 3); break;
            case LVY_ARC: _s += string_format(_p.cx, 1, 3) + "," + string_format(_p.r, 1, 3); break;
            case LVY_STRIP:
                _s += string(array_length(_p.a));
                if (array_length(_p.a) > 0) _s += "," + string_format(_p.a[0][0], 1, 3);
                break;
            default:
                _s += string(array_length(_p.pts));
                if (array_length(_p.pts) > 0) _s += "," + string_format(_p.pts[0][0], 1, 3);
                break;
        }
        _s += ";";
    }
    return _s;
}

/// ============================================================================================
/// THE SUITE
/// ============================================================================================
function lvy_selftest_run() {
    var _t = lvy_test_new();

    // -- STAGE 0: PROVE THE SUITE CAN GO RED --------------------------------------------------
    // ⛔ WITHOUT THIS STAGE EVERY NUMBER BELOW IS UNFALSIFIABLE. It runs the failure path on
    // purpose, confirms the counter moved, and then removes the damage. A suite that has never
    // been seen to fail is a suite nobody has tested.
    lvy_set_stage(_t, 0);
    var _f0 = _t.fail;
    lvy_check(_t, false, "STAGE 0 deliberate failure - this must appear and be retracted");
    var _fired = (_t.fail == _f0 + 1);
    _t.fail = _f0;
    array_pop(_t.notes);
    lvy_check(_t, _fired, "STAGE 0: lvy_check did NOT register a failure - the suite is blind");

    var _f0b = _t.fail;
    lvy_check_count(_t, 0, 1, "STAGE 0 zero-count probe");
    var _fired2 = (_t.fail == _f0b + 1);
    _t.fail = _f0b;
    array_pop(_t.notes);
    lvy_check(_t, _fired2, "STAGE 0: lvy_check_count passed on ZERO - every loop guard is fake");

    // And the overshoot helper must SEE an overshoot, or every containment assertion below is
    // vacuous in the other direction.
    var _probe = [lvy_rect_fill(-50, -50, 10, 10, "m0")];
    lvy_check(_t, lvy_worst_overshoot(_probe, 0, 0, 100, 100) > 40,
              "STAGE 0: lvy_worst_overshoot did not see a 50px overshoot - containment is fake");
    lvy_check(_t, lvy_has_fill(_probe),
              "STAGE 0: lvy_has_fill did not see a fill - the fan assertions are fake");
    lvy_check(_t, !lvy_has_fill([lvy_poly([[0, 0], [1, 1]], false, 1, "m0")]),
              "STAGE 0: lvy_has_fill saw a fill in a polyline");

    // -- STAGE 1: THE ENVIRONMENT --------------------------------------------------------------
    lvy_set_stage(_t, 1);
    lvy_check(_t, variable_global_exists("lvy_lx"), "STAGE 1: global.lvy_lx not initialised");
    lvy_check(_t, abs(global.lvy_lx - LVY_LX) < 0.001, "STAGE 1: lamp x not at the default");
    lvy_check(_t, variable_global_exists("lvy_rebuilds"),
              "STAGE 1: global.lvy_rebuilds not initialised - top-level script code did not run");

    // ⛔ THE DEFAULT-EPSILON PROBE, IN TWO CLAUSES, AND IT MUST NOT BE REPAIRED INTO ONE.
    // The natural way to write this is `e > 0 && e < TOL`, and the FIRST clause goes red: the
    // difference between the epsilon and zero IS the epsilon, GML therefore calls them equal, and
    // equal is not greater-than. Split, the second clause is a POSITIVE test that the runtime still
    // applies an epsilon and goes red the day a release stops.
    var _eps = math_get_epsilon();
    lvy_check(_t, !(_eps > 0),
              "STAGE 1: math_get_epsilon() compared GREATER than zero - the default epsilon is gone");
    lvy_check(_t, _eps < 0.001, "STAGE 1: epsilon unexpectedly large: " + string(_eps));

    // -- STAGE 2: THE CORPUS -------------------------------------------------------------------
    lvy_set_stage(_t, 2);
    var _c = lvy_corpus();
    var _n = array_length(_c);
    lvy_check_count(_t, _n, 40, "STAGE 2: corpus");
    lvy_check(_t, _n == lvy_corpus_count(), "STAGE 2: lvy_corpus_count disagrees with the array");

    var _maxd = lvy_char_max_density();
    var _ids = {};
    for (var _i = 0; _i < _n; _i++) {
        var _m = _c[_i];
        var _lab = "STAGE 2 [" + string(_m.id) + "] ";
        lvy_check(_t, !variable_struct_exists(_ids, _m.id), _lab + "duplicate id");
        variable_struct_set(_ids, _m.id, true);
        lvy_check(_t, string_length(_m.name) > 2, _lab + "name too short");
        lvy_check(_t, _m.L > 0.10 && _m.L < 0.95, _lab + "base L out of range: " + string(_m.L));
        lvy_check(_t, _m.C >= 0 && _m.C <= 0.20, _lab + "base C out of range: " + string(_m.C));
        lvy_check(_t, _m.h >= 0 && _m.h < 360, _lab + "hue out of range: " + string(_m.h));
        lvy_check(_t, _m.spread > 0.15 && _m.spread <= 0.60, _lab + "spread out of range");
        lvy_check(_t, _m.weight >= 0.6 && _m.weight <= 1.4, _lab + "weight out of range");
        // ⛔ THE SIZE-HONESTY BOUND. A material declaring a density above the maximum is claiming a
        // surface character it cannot draw at LVY_MIN_COMPONENT_PX - the corpus would be making a
        // claim the renderer cannot keep.
        lvy_check(_t, _m.density <= _maxd,
                  _lab + "density " + string(_m.density) + " exceeds the max " + string(_maxd));
        lvy_check(_t, (_m.character == LVY_CH_NONE) == (_m.density <= 0),
                  _lab + "character and density disagree about whether there is a surface");
    }

    // The family table in the header is a claim about the corpus; assert it against the corpus.
    var _fams = lvy_families();
    lvy_check(_t, array_length(_fams) == 6,
              "STAGE 2: expected 6 families, found " + string(array_length(_fams)));

    // -- STAGE 3: RAMPS, IN EVERY STATE --------------------------------------------------------
    // ⛔ THE ASSERTION THAT WOULD HAVE CAUGHT limewash. A ramp whose two brightest stops collapse to
    // the same colour reads as a flat fill with a line round it, and it happens when a ramp is
    // CLAMPED to fit rather than SLID. It is checked in all five states because the state delta
    // moves the whole ramp, so a material that is safe idle can collapse on hover.
    lvy_set_stage(_t, 3);
    var _states = lvy_states();
    lvy_check_count(_t, array_length(_states), 5, "STAGE 3: states");
    var _checked3 = 0;
    for (var _i = 0; _i < _n; _i++) {
        for (var _s = 0; _s < array_length(_states); _s++) {
            var _sf = lvy_surface(_c[_i], _states[_s]);
            var _worst = 999;
            for (var _k = 0; _k < LVY_RAMP_N - 1; _k++) {
                var _a = variable_struct_get(_sf, "m" + string(_k));
                var _b = variable_struct_get(_sf, "m" + string(_k + 1));
                _worst = min(_worst, lvy_col_dist(_a, _b));
            }
            lvy_check(_t, _worst > 0.012,
                      "STAGE 3 [" + _c[_i].id + "/" + _states[_s] + "] adjacent ramp stops collapse: "
                      + string_format(_worst, 1, 4));
            _checked3 += 1;
        }
    }
    lvy_check_count(_t, _checked3, 200, "STAGE 3: ramp checks");

    // -- STAGE 4: INK CONTRAST -----------------------------------------------------------------
    // ⛔ ON A LIGHT MATERIAL EVERY RAMP STOP IS LIGHT. Measured on a sibling product: a caption set
    // in m0 - "the material's deepest stop" - was barely visible on parchment, whose ramp runs 0.62
    // to 0.98. Text goes in `ink`, and ink is asserted against `ground` on the SHIPPED COLOUR, after
    // the gamut walk and the gamma transfer, not on the lightness that was requested.
    lvy_set_stage(_t, 4);
    var _checked4 = 0;
    for (var _i = 0; _i < _n; _i++) {
        for (var _s = 0; _s < array_length(_states); _s++) {
            var _sf2 = lvy_surface(_c[_i], _states[_s]);
            var _d = abs(lvy_lum(_sf2.ink) - lvy_lum(_sf2.ground));
            lvy_check(_t, _d > 0.16,
                      "STAGE 4 [" + _c[_i].id + "/" + _states[_s] + "] ink/ground luminance gap "
                      + string_format(_d, 1, 3) + " - text will not read");
            // And type ON the accent must read too, which is a different pair and has its own
            // failure mode: a mid-lightness accent with a badly chosen accentInk.
            var _d2 = abs(lvy_lum(_sf2.accentInk) - lvy_lum(_sf2.accent));
            lvy_check(_t, _d2 > 0.20,
                      "STAGE 4 [" + _c[_i].id + "/" + _states[_s] + "] accentInk/accent gap "
                      + string_format(_d2, 1, 3));
            _checked4 += 1;
        }
    }
    lvy_check_count(_t, _checked4, 200, "STAGE 4: ink checks");

    // -- STAGE 5: THE STATE MODEL, ON ALL FORTY ------------------------------------------------
    // ⛔⛔ THE ASSERTION THIS PRODUCT MOST NEEDS, AND THE ONE A TUNED-ON-BRASS IMPLEMENTATION PASSES
    // AND SHIPS BROKEN. `disabled` written as `C * 0.4` is obvious on brass (C 0.09) and does
    // NOTHING on slate (C 0.006). Asserting it on every material is what makes the pull-toward-a-
    // target model necessary rather than merely tidier.
    lvy_set_stage(_t, 5);
    var _checked5 = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _idle = lvy_surface(_c[_i], LVY_ST_IDLE);
        var _dis  = lvy_surface(_c[_i], LVY_ST_DISABLED);
        var _hov  = lvy_surface(_c[_i], LVY_ST_HOVER);

        // ⚠️ MEASURED ACROSS THE ROLES A COMPONENT IS ACTUALLY DRAWN IN, NOT ON m3 ALONE, AND THAT
        // IS A CORRECTION RATHER THAN A RELAXATION. "Does this state read?" is a question about the
        // whole component - its bevel walls AND the field it sits on - and an m3-only test both
        // misses a state that changes everything except m3 and fires on one that changes only m3.
        //
        // ⛔ SO IT IS TWO ASSERTIONS, NOT ONE. The pair is what stops the widening from being a
        // loophole: the RAMP alone must still move (a state may not be a ground recolour with a
        // dead bevel), and the SURFACE as a whole must move by more. Dropping either half would
        // leave an assertion that a lazy state model could satisfy.
        var _rampDis = max(lvy_col_dist(_idle.m1, _dis.m1), lvy_col_dist(_idle.m2, _dis.m2),
                           lvy_col_dist(_idle.m3, _dis.m3));
        var _surfDis = max(_rampDis, lvy_col_dist(_idle.ground, _dis.ground));
        lvy_check(_t, _rampDis > 0.010,
                  "STAGE 5 [" + _c[_i].id + "] DISABLED does not move the RAMP - the bevel is dead "
                  + "but unchanged (" + string_format(_rampDis, 1, 4) + ")");
        lvy_check(_t, _surfDis > 0.020,
                  "STAGE 5 [" + _c[_i].id + "] DISABLED is indistinguishable from idle ("
                  + string_format(_surfDis, 1, 4) + ")");

        var _rampHov = max(lvy_col_dist(_idle.m1, _hov.m1), lvy_col_dist(_idle.m2, _hov.m2),
                           lvy_col_dist(_idle.m3, _hov.m3));
        var _surfHov = max(_rampHov, lvy_col_dist(_idle.ground, _hov.ground));
        lvy_check(_t, _rampHov > 0.008,
                  "STAGE 5 [" + _c[_i].id + "] HOVER does not move the RAMP ("
                  + string_format(_rampHov, 1, 4) + ")");
        lvy_check(_t, _surfHov > 0.014,
                  "STAGE 5 [" + _c[_i].id + "] HOVER is indistinguishable from idle ("
                  + string_format(_surfHov, 1, 4) + ")");
        // The accent must desaturate under disabled, or a disabled gauge still looks live.
        lvy_check(_t, lvy_col_dist(_idle.accent, _dis.accent) > 0.020,
                  "STAGE 5 [" + _c[_i].id + "] disabled ACCENT still reads as live");
        _checked5 += 1;
    }
    lvy_check_count(_t, _checked5, 40, "STAGE 5: state checks");

    // Pressed must INVERT the bevel rather than merely darken it, and focus must not move the ramp.
    lvy_check(_t, lvy_state_bevel(LVY_ST_PRESSED) < 0,
              "STAGE 5: PRESSED does not invert the bevel - a pressed button will not read as pressed");
    lvy_check(_t, lvy_state_inset(LVY_ST_PRESSED) > 0,
              "STAGE 5: PRESSED does not offset the cap");
    lvy_check(_t, abs(lvy_state_delta(LVY_ST_FOCUS).dL) < 0.0001,
              "STAGE 5: FOCUS moves the ramp - it must be told apart by shape, not brightness");

    // The hue pull must take the SHORT way round the circle.
    lvy_check(_t, abs(lvy_pull_hue(350, 10, 1.0) - 10) < 0.001,
              "STAGE 5: lvy_pull_hue did not wrap - a warm accent walks through cyan");
    lvy_check(_t, abs(lvy_pull_hue(350, 10, 0.5) - 0) < 0.001,
              "STAGE 5: lvy_pull_hue midpoint wrong: " + string(lvy_pull_hue(350, 10, 0.5)));

    // -- STAGE 6: CORNER TREATMENTS - TOTAL TURNING --------------------------------------------
    // ⛔ THE CHEAP TEST FOR THE BOWTIE. A simple closed polygon turns through exactly one
    // revolution; a figure-of-eight turns through zero. This wing shipped the bowtie once, on every
    // panel and well in a product, and it was found by opening a PNG.
    lvy_set_stage(_t, 6);
    var _corners = lvy_corners_all();
    lvy_check_count(_t, array_length(_corners), 6, "STAGE 6: corner treatments");
    var _aspects = [[0, 0, 200, 200], [0, 0, 400, 40], [0, 0, 40, 400], [0, 0, 26, 26],
                    [0, 0, 300, 120]];
    var _checked6 = 0;
    for (var _ci = 0; _ci < array_length(_corners); _ci++) {
        for (var _ai = 0; _ai < array_length(_aspects); _ai++) {
            var _r = _aspects[_ai];
            var _pts = lvy_shape_pts(_corners[_ci], _r[0], _r[1], _r[2], _r[3], 1.0, 1.0, undefined);
            var _turn = lvy_turning(_pts);
            lvy_check(_t, abs(abs(_turn) - 1.0) < 0.02,
                      "STAGE 6 [" + _corners[_ci] + " " + string(_r[2]) + "x" + string(_r[3])
                      + "] turning " + string_format(_turn, 1, 3));
            lvy_check(_t, lvy_is_simple(_pts),
                      "STAGE 6 [" + _corners[_ci] + " " + string(_r[2]) + "x" + string(_r[3])
                      + "] SELF-INTERSECTS");
            // And it must stay inside the rect it was given. A corner treatment that bulges outward
            // makes every component in a theme overlap its neighbour.
            var _bb = lvy_pts_bounds(_pts);
            lvy_check(_t, _bb[0] >= _r[0] - 0.01 && _bb[1] >= _r[1] - 0.01
                       && _bb[2] <= _r[2] + 0.01 && _bb[3] <= _r[3] + 0.01,
                      "STAGE 6 [" + _corners[_ci] + "] outline leaves its own rect");
            _checked6 += 1;
        }
    }
    lvy_check_count(_t, _checked6, 30, "STAGE 6: turning checks");

    // ⛔⛔ AND THE SAME TEST ON AN OUTLINE THAT IS ASSEMBLED RATHER THAN GENERATED. THIS GAP LET A
    // SELF-INTERSECTING HEADER SHIP TO A STORE SHEET.
    //
    // The block above asserts turning on everything lvy_shape_pts produces, and the header outline
    // is built in lvy_frame by clipping one of those to a half-plane. So the assertion covered the
    // INGREDIENTS and not the RESULT, and a header whose height exceeded its corner radius came out
    // as a bowtie on all six treatments - a dark wedge slashed across the title bar, found by
    // opening the four-themes sheet.
    //
    // ⭐ THE LESSON IS THE GAP, NOT THE WEDGE: an assertion on a component's inputs says nothing
    // about a component. Anything in this package that DERIVES an outline gets its own turning
    // check, and the heights below deliberately straddle the corner radius, which is the parameter
    // that decides whether the old bug fired at all.
    var _hh = [12, 20, 34, 60, 120];
    var _checked6b = 0;
    for (var _ci = 0; _ci < array_length(_corners); _ci++) {
        for (var _hi = 0; _hi < array_length(_hh); _hi++) {
            var _m6 = lvy_material_get("brass");
            // The corner treatment comes from the material, so drive it directly through the shape
            // layer with each corner in turn rather than only through brass's own.
            var _fullH = lvy_shape_pts(_corners[_ci], 0, 0, 300, _hh[_hi] * 2, 1.0, 1.0, undefined);
            var _clip = lvy_clip_below(_fullH, _hh[_hi]);
            lvy_check(_t, array_length(_clip) >= 3,
                      "STAGE 6b [" + _corners[_ci] + " h=" + string(_hh[_hi])
                      + "] clip produced fewer than 3 points");
            var _tb = lvy_turning(_clip);
            lvy_check(_t, abs(abs(_tb) - 1.0) < 0.02,
                      "STAGE 6b [" + _corners[_ci] + " h=" + string(_hh[_hi])
                      + "] clipped header turning " + string_format(_tb, 1, 3));
            // ⛔ AND THE DEFINITIVE TEST, because turning is necessary and NOT sufficient. Proved by
            // sabotage: reinstating the original filter-and-push made turning fire on STEP alone and
            // pass on the other five, including the CHAMFER whose visible defect started all this.
            // See lvy_is_simple's header.
            lvy_check(_t, lvy_is_simple(_clip),
                      "STAGE 6b [" + _corners[_ci] + " h=" + string(_hh[_hi])
                      + "] clipped header SELF-INTERSECTS");
            // And the clip must actually have CUT something, or the assertion is vacuous on a
            // shape that was already entirely above the line.
            lvy_check(_t, array_length(_clip) < array_length(_fullH) + 4,
                      "STAGE 6b [" + _corners[_ci] + "] clip returned the input unchanged");
            _checked6b += 1;
        }
    }
    lvy_check_count(_t, _checked6b, 30, "STAGE 6b: clipped-outline turning checks");

    // -- STAGE 7: THE INSET LIMIT --------------------------------------------------------------
    // ⭐ THIS STAGE CARRIES A MEASUREMENT THAT CORRECTS AN INHERITED RULE, so it is written to print
    // the numbers rather than merely to pass. The wing constitution says "cap a bevel at 0.45 of the
    // shortest edge". That is right about the DEFECT and wrong about the PROXY: on a smooth convex
    // curve the inset points cannot cross until the inset reaches the radius, so the old rule
    // refuses most of the legal range and every rounded component gets a hairline where the design
    // calls for a moulding.
    lvy_set_stage(_t, 7);
    var _circle = lvy_ellipse_pts(0, 0, 60, 60, 24);
    var _short7 = lvy_shortest_edge(_circle);
    var _lim7 = lvy_inset_limit(_circle);
    lvy_check(_t, _short7 > 14 && _short7 < 17,
              "STAGE 7: circle shortest edge unexpected: " + string_format(_short7, 1, 2));
    lvy_check(_t, _lim7 > _short7 * 2.0,
              "STAGE 7: inset limit " + string_format(_lim7, 1, 2) + " is not materially larger than "
              + "0.45*shortest-edge " + string_format(_short7 * 0.45, 1, 2)
              + " - the curvature rule has regressed to the old proxy");

    // ⛔ AND THE OTHER DIRECTION, WHICH IS THE HALF THAT MATTERS FOR CORRECTNESS. A shape with a
    // REFLEX notch must be clamped hard. Without this the stage would only prove the limit is
    // generous, which is exactly how a safety rule gets tuned into uselessness.
    //
    // ⚠️ THE FIRST FIXTURE HERE WAS A WIDE NOTCH AND THE ASSERTION ON IT WAS SIMPLY WRONG.
    // MEASURED on the first headless run: it failed with "allowed an inset of 10.65", and 10.65 is
    // the CORRECT answer for that shape - a triangular bite 50 units wide and 50 deep genuinely
    // tolerates a ten-unit inset. I had asserted `< 3.0` against a number I never computed.
    //
    // ⭐ A THRESHOLD NOBODY DERIVED IS A COIN TOSS, and this one landed on a false red. It is
    // replaced by two assertions that do not depend on guessing an absolute: a narrow V, whose
    // limit falls out of its own geometry at about one unit, and a COMPARATIVE check against the
    // same square with no notch at all - which cannot be wrong about a number because it only
    // claims the notch matters.
    var _plain = [[0, 0], [100, 0], [100, 100], [0, 100]];
    var _notched = [[0, 0], [48, 0], [50, 60], [52, 0], [100, 0], [100, 100], [0, 100]];
    var _limPlain = lvy_inset_limit(_plain);
    var _limNotch = lvy_inset_limit(_notched);
    lvy_check(_t, _limPlain > 30,
              "STAGE 7: an unnotched square was limited to " + string_format(_limPlain, 1, 2));
    lvy_check(_t, _limNotch < 2.0,
              "STAGE 7: a narrow V notch was allowed an inset of " + string_format(_limNotch, 1, 2)
              + " - the bevel will turn it inside out");
    lvy_check(_t, _limNotch < _limPlain * 0.10,
              "STAGE 7: the notch barely changed the limit (" + string_format(_limNotch, 1, 2)
              + " vs " + string_format(_limPlain, 1, 2) + ") - reflex vertices are not being seen");
    lvy_check(_t, _limNotch > 0, "STAGE 7: the notch's limit went to zero or below");

    // Every corner treatment must allow SOME bevel, or a theme has no relief at all.
    var _checked7 = 0;
    for (var _ci = 0; _ci < array_length(_corners); _ci++) {
        var _p7 = lvy_shape_pts(_corners[_ci], 0, 0, 200, 90, 1.0, 1.0, undefined);
        lvy_check(_t, lvy_inset_limit(_p7) > 2.0,
                  "STAGE 7 [" + _corners[_ci] + "] allows no usable bevel");
        _checked7 += 1;
    }
    lvy_check_count(_t, _checked7, 6, "STAGE 7: per-corner limits");

    // -- STAGE 8: SURFACE CHARACTER - CONTAINMENT AND VACUITY ----------------------------------
    // ⛔ A VEIN WANDERS, A CRAZE BRANCHES AND A TRACE TURNS CORNERS, so character is the highest-risk
    // shape in this package for drawing outside the rect it was given - which in a buyer's game
    // paints over whatever sits beside the widget. Three aspect ratios, because the wing
    // constitution records a wash that stayed inside every SQUARE test rect and bled out of a wide
    // one, its radius having been derived from the width.
    lvy_set_stage(_t, 8);
    var _rects8 = [[10, 10, 210, 210], [10, 10, 410, 60], [10, 10, 60, 410]];
    var _checked8 = 0;
    var _drew8 = 0;
    for (var _i = 0; _i < _n; _i++) {
        for (var _ri = 0; _ri < array_length(_rects8); _ri++) {
            var _r8 = _rects8[_ri];
            var _cp = lvy_char_parts(_c[_i], _r8[0], _r8[1], _r8[2], _r8[3], 4242);
            var _ov = lvy_worst_overshoot(_cp, _r8[0], _r8[1], _r8[2], _r8[3]);
            lvy_check(_t, _ov < 1.5,
                      "STAGE 8 [" + _c[_i].id + "/" + _c[_i].character + "] character escapes its "
                      + "rect by " + string_format(_ov, 1, 1) + "px");
            // ⭐ THE VACUITY HALF. A material that declares a character must PRODUCE marks; without
            // this, "stays inside the rect" is satisfied by drawing nothing at all, on all forty.
            if (_c[_i].character != LVY_CH_NONE) {
                lvy_check(_t, array_length(_cp) > 3,
                          "STAGE 8 [" + _c[_i].id + "/" + _c[_i].character + "] declared a character "
                          + "and drew " + string(array_length(_cp)) + " marks");
                _drew8 += 1;
            } else {
                lvy_check(_t, array_length(_cp) == 0,
                          "STAGE 8 [" + _c[_i].id + "] declares NO character and drew "
                          + string(array_length(_cp)) + " marks - the dispatch fell through");
            }
            _checked8 += 1;
        }
    }
    lvy_check_count(_t, _checked8, 120, "STAGE 8: character containment");
    lvy_check_count(_t, _drew8, 90, "STAGE 8: materials with a real character");

    // -- STAGE 9: COMPONENT CONTAINMENT --------------------------------------------------------
    // Every family, on a sample of materials spanning all six families and all six corners.
    lvy_set_stage(_t, 9);
    var _famUI = lvy_families_ui();
    lvy_check_count(_t, array_length(_famUI), 14, "STAGE 9: UI families");
    var _rect9 = [40, 40, 340, 240];
    var _checked9 = 0;
    for (var _fi = 0; _fi < array_length(_famUI); _fi++) {
        for (var _i = 0; _i < _n; _i += 7) {
            var _parts = lvy_draw_family(_famUI[_fi], _c[_i], _rect9[0], _rect9[1], _rect9[2], _rect9[3],
                                         LVY_ST_IDLE);
            // ⛔ THE ALLOWANCE IS PER-FAMILY, AND A SINGLE GENEROUS ONE MISSED A REAL DEFECT.
            // MEASURED: this stage passed while Slate's chamfered panel had a triangular flap of
            // bevel hanging outside itself, into the page, on the corners sheet. One allowance of
            // 0.34 of the short side is 68 pixels here, so a 30-pixel escape sailed through.
            //
            // ⭐ THE ALLOWANCE EXISTS FOR THREE FAMILIES AND ONLY THREE. A modal's drop shadow, a
            // tooltip's beak and a focus ring are DESIGNED to fall outside the rect - that is what
            // LVY_WIDGET_PAD is for. Every other family has NO business outside its own rectangle,
            // and giving them the same latitude as the three that do is how a containment
            // assertion stops containing anything.
            var _overhangs = (_famUI[_fi] == "modal" || _famUI[_fi] == "tooltip");
            var _allow = _overhangs
                       ? min(_rect9[2] - _rect9[0], _rect9[3] - _rect9[1]) * LVY_WIDGET_PAD
                       : 4;
            var _ov9 = lvy_worst_overshoot(_parts, _rect9[0], _rect9[1], _rect9[2], _rect9[3]);
            lvy_check(_t, _ov9 <= _allow,
                      "STAGE 9 [" + _famUI[_fi] + "/" + _c[_i].id + "] escapes its rect by "
                      + string_format(_ov9, 1, 1) + "px, allowance " + string_format(_allow, 1, 1));
            // ⭐ AND IT MUST DRAW SOMETHING. Fourteen families times six materials of "drew nothing"
            // would satisfy every containment assertion above.
            lvy_check(_t, array_length(_parts) > 2,
                      "STAGE 9 [" + _famUI[_fi] + "/" + _c[_i].id + "] emitted "
                      + string(array_length(_parts)) + " parts");
            _checked9 += 1;
        }
    }
    lvy_check_count(_t, _checked9, 70, "STAGE 9: component containment");

    // -- STAGE 10: THE FAN PRECONDITION --------------------------------------------------------
    // ⛔ lvy_render_fill IS pr_trianglefan AND ITS PRECONDITION IS THAT THE OUTLINE IS STAR-SHAPED
    // ABOUT pts[0]. Hand it a concave shape and it spans the concavity, silently. This wing shipped
    // every moon crescent as a quarter for that reason. A tick, a chevron, an I-beam and a busy ring
    // are all concave or open, so none of them may emit a fill.
    //
    // ⭐ AND THE SECOND HALF IS NOT OPTIONAL: "emits no fill" is satisfied by drawing nothing. Every
    // one of these also asserts it produced marks.
    lvy_set_stage(_t, 10);
    var _concave = [lvy_mark_tick(), lvy_mark_chevron(0), lvy_mark_chevron(1),
                    lvy_mark_chevron(2), lvy_mark_chevron(3), lvy_cursor_beam(), lvy_cursor_busy()];
    var _labels10 = ["tick", "chevron-up", "chevron-right", "chevron-down", "chevron-left",
                     "beam", "busy"];
    lvy_check_count(_t, array_length(_concave), 7, "STAGE 10: concave marks");
    for (var _i = 0; _i < array_length(_concave); _i++) {
        lvy_check(_t, !lvy_has_fill(_concave[_i]),
                  "STAGE 10 [" + _labels10[_i] + "] emits a triangle fan - a fan spans its concavity");
        lvy_check(_t, array_length(_concave[_i]) > 0,
                  "STAGE 10 [" + _labels10[_i] + "] drew nothing - the no-fill assertion is vacuous");
    }
    // The pointer arrow IS allowed a fill, and its fan anchor is stated explicitly in the builder
    // rather than left to the centroid. Assert it draws one, so a later edit that quietly turns it
    // into strokes is noticed.
    lvy_check(_t, lvy_has_fill(lvy_cursor_arrow()),
              "STAGE 10: the pointer arrow stopped emitting a fill");

    // -- STAGE 11: DETERMINISM -----------------------------------------------------------------
    // ⛔ NOTHING IN THIS PACKAGE MAY CALL random(). A surface that re-jitters every frame is the one
    // defect a buyer notices immediately and cannot work around, and it is invisible in a still.
    lvy_set_stage(_t, 11);
    var _checked11 = 0;
    for (var _i = 0; _i < _n; _i += 3) {
        var _a1 = lvy_geom_digest(lvy_char_parts(_c[_i], 0, 0, 200, 120, 99));
        var _a2 = lvy_geom_digest(lvy_char_parts(_c[_i], 0, 0, 200, 120, 99));
        lvy_check(_t, _a1 == _a2,
                  "STAGE 11 [" + _c[_i].id + "] character is not deterministic");
        var _b1 = lvy_geom_digest(lvy_frame(_c[_i], 0, 0, 300, 200, LVY_ST_IDLE));
        var _b2 = lvy_geom_digest(lvy_frame(_c[_i], 0, 0, 300, 200, LVY_ST_IDLE));
        lvy_check(_t, _b1 == _b2, "STAGE 11 [" + _c[_i].id + "] frame is not deterministic");
        lvy_check(_t, string_length(_b1) > 40,
                  "STAGE 11 [" + _c[_i].id + "] digest is empty - determinism check is vacuous");
        _checked11 += 1;
    }
    lvy_check_count(_t, _checked11, 12, "STAGE 11: determinism checks");

    // Two DIFFERENT materials must not produce the same picture. Without this, "deterministic" is
    // satisfied by a builder that ignores its material entirely.
    var _d1 = lvy_geom_digest(lvy_frame(lvy_material_get("iron"), 0, 0, 300, 200, LVY_ST_IDLE));
    var _d2 = lvy_geom_digest(lvy_frame(lvy_material_get("porcelain"), 0, 0, 300, 200, LVY_ST_IDLE));
    lvy_check(_t, _d1 != _d2,
              "STAGE 11: iron and porcelain frames have identical geometry - the material is ignored");

    // -- STAGE 12: ROLE COVERAGE ---------------------------------------------------------------
    // ⛔ THE RENDERER FALLS BACK TO `line` ON AN UNKNOWN ROLE - loudly wrong rather than invisible -
    // and that fallback is a diagnostic, not a licence to leave one in. Every part of every family
    // must ask for a role its surface actually carries.
    lvy_set_stage(_t, 12);
    var _surf12 = lvy_surface(_c[0], LVY_ST_IDLE);
    var _checked12 = 0;
    for (var _fi = 0; _fi < array_length(_famUI); _fi++) {
        var _p12 = lvy_draw_family(_famUI[_fi], _c[0], 40, 40, 340, 240, LVY_ST_IDLE);
        var _roles = lvy_roles_used(_p12);
        lvy_check_count(_t, array_length(_roles), 1, "STAGE 12 [" + _famUI[_fi] + "] roles");
        for (var _ri = 0; _ri < array_length(_roles); _ri++) {
            lvy_check(_t, variable_struct_exists(_surf12, _roles[_ri]),
                      "STAGE 12 [" + _famUI[_fi] + "] asks for role \"" + _roles[_ri]
                      + "\" which no surface carries");
        }
        _checked12 += 1;
    }
    lvy_check_count(_t, _checked12, 14, "STAGE 12: family role sweeps");

    // -- STAGE 13: THE EMISSION-ORDER CONTRACT -------------------------------------------------
    // ⛔ THE PICTURE IS UNREACHABLE FROM A TEST, SO THE CONTRACT IS WHAT GETS ASSERTED. This wing
    // shipped a gilt plate rim drawn ACROSS the food on every rimmed plate a product could produce,
    // because one ring was appended last "so it sits on top". The same shape is live here: a modal's
    // shadow emitted after its frame is a grey smear over the dialog.
    //
    // The scrim must be the FIRST part, and the shadow must come before the frame's own body.
    lvy_set_stage(_t, 13);
    var _mm = lvy_material_get("brass");
    var _modal = lvy_modal(_mm, 60, 60, 260, 200, 0, 0, 320, 260, LVY_ST_IDLE);
    lvy_check_count(_t, array_length(_modal), 10, "STAGE 13: modal parts");
    var _first = _modal[0];
    lvy_check(_t, _first.kind == LVY_FILL && _first.role == "m0",
              "STAGE 13: the modal's first part is not the scrim - the scrim will cover the dialog");
    // The scrim must cover the whole SCREEN, not the dialog.
    var _sb = lvy_render_bounds([_first]);
    lvy_check(_t, _sb[0] <= 0.01 && _sb[2] >= 319.99,
              "STAGE 13: the scrim does not span the screen it was given");
    // The shadow is the second part and must be offset AWAY from the lamp, i.e. down and right.
    var _shadow = _modal[1];
    var _shb = lvy_render_bounds([_shadow]);
    lvy_check(_t, _shb[0] > 60 && _shb[1] > 60,
              "STAGE 13: the drop shadow is not offset away from the lamp");

    // A frame must emit its body before its well: the well is a recess IN the moulding.
    var _fr13 = lvy_frame(_mm, 0, 0, 300, 220, LVY_ST_IDLE);
    lvy_check_count(_t, array_length(_fr13), 20, "STAGE 13: frame parts");
    var _bodyBB = lvy_render_bounds([_fr13[0]]);
    lvy_check(_t, (_bodyBB[2] - _bodyBB[0]) > 200,
              "STAGE 13: the frame's first part is not its full-width body");
    var _last = _fr13[array_length(_fr13) - 1];
    var _lastBB = lvy_render_bounds([_last]);
    lvy_check(_t, (_lastBB[2] - _lastBB[0]) < (_bodyBB[2] - _bodyBB[0]),
              "STAGE 13: the frame's last part is not inside its body - the well is not a recess");

    // -- STAGE 14: THE PRODUCT CLAIM -----------------------------------------------------------
    // ⛔ THE STORE PAGE SAYS FOURTEEN FAMILIES AND FORTY MATERIALS. Both numbers are derived from
    // array_length, and their product is the "distinct components" figure. Asserting it here is what
    // makes that figure a measurement rather than a sentence.
    lvy_set_stage(_t, 14);
    lvy_check(_t, lvy_family_count() == 14,
              "STAGE 14: family count is " + string(lvy_family_count()) + ", not 14");
    lvy_check(_t, lvy_corpus_count() == 40,
              "STAGE 14: material count is " + string(lvy_corpus_count()) + ", not 40");
    lvy_check(_t, lvy_component_count() == 560,
              "STAGE 14: component count is " + string(lvy_component_count()) + ", not 560");

    // -- STAGE 15: THE WIDGET CACHE ------------------------------------------------------------
    // The cache's correctness is a claim on the store page, so it is asserted rather than assumed.
    // ⚠️ NO SPRITE IS BUILT HERE. lvy_widget_build needs a render target and this suite runs from
    // Create; what is tested is the DECISION function, which is where the defect would live.
    lvy_set_stage(_t, 15);
    var _th = lvy_theme("brass");
    lvy_check(_t, !is_undefined(_th), "STAGE 15: lvy_theme(\"brass\") returned undefined");
    lvy_check(_t, is_undefined(lvy_theme("no-such-material")),
              "STAGE 15: an unknown material id returned a theme - a typo would ship silently");

    var _w = lvy_widget(_th, "button", 0, 0, 100, 40, LVY_ST_IDLE, 0);
    lvy_check(_t, lvy_widget_state_changed(_w),
              "STAGE 15: a never-built widget does not report a needed rebuild");
    // Pretend it was built, then check each thing that must and must not trigger a rebuild.
    _w.spr = 0; _w.builtState = LVY_ST_IDLE; _w.builtExtra = 0; _w.builtTheme = _th.id;
    lvy_check(_t, !lvy_widget_state_changed(_w),
              "STAGE 15: an unchanged widget wants a rebuild - the cache never hits");
    _w.state = LVY_ST_HOVER;
    lvy_check(_t, lvy_widget_state_changed(_w), "STAGE 15: a state change did not invalidate");
    _w.state = LVY_ST_IDLE;
    _w.extra = 0.0005;
    lvy_check(_t, !lvy_widget_state_changed(_w),
              "STAGE 15: a sub-pixel value change forced a rebuild - a smooth gauge rebuilds every frame");
    _w.extra = 0.05;
    lvy_check(_t, lvy_widget_state_changed(_w), "STAGE 15: a real value change did not invalidate");
    _w.extra = 0;
    _w.theme = lvy_theme("slate");
    lvy_check(_t, lvy_widget_state_changed(_w), "STAGE 15: a theme change did not invalidate");
    _w.spr = -1;

    // Hit testing uses the RECT, not the padded sprite.
    var _w2 = lvy_widget(_th, "button", 100, 100, 200, 140, LVY_ST_IDLE, 0);
    lvy_check(_t, lvy_widget_hit(_w2, 150, 120), "STAGE 15: hit test missed the centre");
    lvy_check(_t, !lvy_widget_hit(_w2, 150, 155),
              "STAGE 15: hit test extends past the rect - a button responds below itself");
    // A disabled widget must not be lit up by a hover.
    var _w3 = lvy_widget(_th, "button", 0, 0, 100, 40, LVY_ST_DISABLED, 0);
    lvy_widget_pointer(_w3, 50, 20, false);
    lvy_check(_t, _w3.state == LVY_ST_DISABLED,
              "STAGE 15: hover overrode DISABLED - the player will click a dead button");

    lvy_set_stage(_t, 99);
    return _t;
}

/// ============================================================================================
/// THE RESULT FILE
///
/// ⛔ THIS FUNCTION DOES NOT INSTALL A CRASH HANDLER, DELIBERATELY. obj_lvy_demo's Create event
/// installs one as its first statement and it records the MESSAGE AND THE STACKTRACE. Two handlers
/// would mean whichever was installed last silently won.
///
/// ⛔ AND THE ROUTE IS file_text_open_write, WHICH LANDS IN %LOCALAPPDATA%\Livery\. It is the only
/// one of the four candidates that survives a release build.
function lvy_selftest_write(_t) {
    var _notes = "";
    for (var _i = 0; _i < array_length(_t.notes); _i++) {
        if (_i > 0) _notes += " | ";
        _notes += string_replace_all(string(_t.notes[_i]), "\"", "'");
    }
    var _f = file_text_open_write("lvy_selftest.json");
    file_text_write_string(_f,
        "{\"ok\":" + ((_t.fail == 0) ? "true" : "false")
        + ",\"pass\":" + string(_t.pass)
        + ",\"fail\":" + string(_t.fail)
        + ",\"stage\":" + string(_t.stage)
        + ",\"epsilon\":" + string_format(math_get_epsilon(), 1, 12)
        + ",\"materials\":" + string(lvy_corpus_count())
        + ",\"families\":" + string(lvy_family_count())
        + ",\"components\":" + string(lvy_component_count())
        + ",\"notes\":\"" + _notes + "\"}");
    file_text_close(_f);
}
