/// LIVERY - lvy_bake. The store gallery, rendered by the product itself.
///
/// HOW IT RUNS:  Livery.exe -bake  ->  %LOCALAPPDATA%\Livery\sheet_*.png  +  lvy_bake.json
///
/// ⛔ A GALLERY RENDERED BY A SIDE PREVIEWER IS A PICTURE OF A RE-IMPLEMENTATION. This wing measured
/// that on a previous product: its JavaScript previewer carried a defect that was invisible in the
/// previewer and plainly visible in engine. Baking through the real executable, with the product's
/// own palette, fonts and public draw calls, is what lets the listing truthfully say "every image on
/// this page was rendered by the product itself".
///
/// -- THE INK BOX, AND ITS THREE KNOWN BLIND SPOTS ---------------------------------------------
/// Each sheet returns the y it finished at, and the runner compares that against the surface height.
/// ⛔ THAT ONE NUMBER IS BLIND IN TWO DIRECTIONS - it cannot see horizontal overflow and it cannot
/// see emptiness - so every sheet is ALSO scanned for its actual rendered pixels and an ink bounding
/// box is taken. Floors: 86% width, 80% height, 6px edge margin.
///
/// The three blind spots are recorded rather than tuned away, because a threshold that hides a
/// defect is worse than no threshold:
///   1. ⛔ STRIDE. y is stepped by 1, never 2. A 1px hairline on an odd row is exactly the shape
///      that gets clipped, and an even-only scan walks straight past it.
///   2. ⛔ A FLAT FILL CLOSE TO THE PAGE COLOUR IS NOT COUNTED AS INK, at any stride. Panels are
///      therefore SIZED FROM THE SPACE AVAILABLE so they cannot clip by construction.
///   3. ⛔ A BOUNDING BOX CANNOT SEE THE SPACE INSIDE ITSELF. A sheet of three small components
///      adrift on a large page scores well and looks empty. The only instrument for that is opening
///      the file, and it is not optional.
/// ============================================================================================

#macro LVY_SHEET_W 1600
#macro LVY_SHEET_H 1000

/// The page ground every sheet is cleared to, and the ink the captions are set in.
///
/// ⚠️ THE PAGE IS NOT A MATERIAL'S GROUND. A sheet showing forty materials cannot be drawn on any
/// one of their grounds without flattering that one and fighting the other thirty-nine. It is a
/// neutral dark, and the captions are set against IT rather than against a material's ink.
function lvy_bk_page()    { return lvy_oklch(0.155, 0.010, 250); }
function lvy_bk_ink()     { return lvy_oklch(0.880, 0.012, 250); }
function lvy_bk_dim()     { return lvy_oklch(0.560, 0.010, 250); }
function lvy_bk_rule()    { return lvy_oklch(0.330, 0.012, 250); }

/// A sheet title and its subtitle, returning the y below them.
function lvy_bk_head(_title, _sub, _y) {
    lvy_text_label(_title, 60, _y, LVY_SHEET_W - 120, 46, lvy_bk_page(), lvy_bk_ink());
    var _y2 = _y + 62;
    if (_sub != "") {
        lvy_text_line(_sub, 60, _y2, LVY_SHEET_W - 120, 22, lvy_bk_dim(), false);
        _y2 += 34;
    }
    draw_set_colour(lvy_bk_rule());
    // ⚠️ A FULL-WIDTH RULE NEUTRALISES THE X-FILL FLOOR, and that is stated rather than hidden: the
    // ink box's width test is satisfied by this line alone on every sheet, so the x floor earns its
    // keep only through the edge-clip test. The height floor and the CONTENT box below the rule are
    // what actually measure coverage.
    draw_rectangle(60, _y2 + 4, LVY_SHEET_W - 60, _y2 + 5, false);
    return _y2 + 26;
}

/// A caption under a cell, scaled to the cell so renaming can never overflow it.
///
/// ⛔ THIS WING HAS SHIPPED THE OVERFLOW DEFECT TWICE - "WickthorSt Cuthman's" on one product and
/// "HEDGEHOG FUNGUSCAULIFLOWER FUNGUS" on the next - and the second time it came back BECAUSE THE
/// FIRST FIX SHORTENED THE DATA. Material names come from the corpus and must not constrain the
/// layout, so the string is measured and scaled to the cell.
/// ⚠️ No ink check will ever catch this: overprinted text is ink exactly where ink belongs.
function lvy_bk_caption(_text, _cx, _y, _maxw, _px, _col) {
    draw_set_font(fnt_livery);
    draw_set_halign(fa_center);
    draw_set_valign(fa_top);
    draw_set_colour(_col);
    var _base = max(1, string_height("M"));
    var _sc = _px / _base;
    var _w = string_width(_text) * _sc;
    if (_w > _maxw && _w > 0) _sc *= _maxw / _w;
    draw_text_transformed(_cx, _y, _text, _sc, _sc, 0);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    return _base * _sc;
}

/// ============================================================================================
/// THE INK BOX
/// ============================================================================================

/// The bounding box of everything drawn on the current surface that is not the page colour.
///
/// Returns { full, content, ink } where `full` spans the whole surface and `content` is measured
/// BELOW _contentY - the rule under a title satisfies a width floor on its own, so the coverage
/// floors are applied to the content region and the clip test to the full one.
function lvy_bk_ink_bounds(_w, _h, _contentY) {
    var _buf = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_buf, surface_get_target(), 0);
    var _pg = lvy_bk_page();
    var _pr = colour_get_red(_pg), _pgn = colour_get_green(_pg), _pb = colour_get_blue(_pg);

    var _fx0 = _w, _fy0 = _h, _fx1 = -1, _fy1 = -1;
    var _cx0 = _w, _cy0 = _h, _cx1 = -1, _cy1 = -1;
    var _ink = 0;

    // ⛔ y STEPS BY 1. A 1px hairline lands on one row and an even-only scan walks past it, which is
    // exactly the feature most likely to be clipped. x may step by 2 - nothing in this package draws
    // a 1px-wide VERTICAL feature that is not part of a wider mark.
    for (var _y = 0; _y < _h; _y++) {
        for (var _x = 0; _x < _w; _x += 2) {
            var _o = (_y * _w + _x) * 4;
            var _r = buffer_peek(_buf, _o, buffer_u8);
            var _g = buffer_peek(_buf, _o + 1, buffer_u8);
            var _b = buffer_peek(_buf, _o + 2, buffer_u8);
            if (abs(_r - _pr) <= 10 && abs(_g - _pgn) <= 10 && abs(_b - _pb) <= 10) continue;
            _ink += 1;
            if (_x < _fx0) _fx0 = _x;
            if (_x > _fx1) _fx1 = _x;
            if (_y < _fy0) _fy0 = _y;
            if (_y > _fy1) _fy1 = _y;
            if (_y >= _contentY) {
                if (_x < _cx0) _cx0 = _x;
                if (_x > _cx1) _cx1 = _x;
                if (_y < _cy0) _cy0 = _y;
                if (_y > _cy1) _cy1 = _y;
            }
        }
    }
    buffer_delete(_buf);
    return {
        full:    [_fx0, _fy0, _fx1, _fy1],
        content: [_cx0, _cy0, _cx1, _cy1],
        ink: _ink
    };
}

/// ============================================================================================
/// THE SHEETS
///
/// Every one returns the y it finished at, which the runner checks against the surface height.
/// ============================================================================================

/// SHEET 1 - HERO. One complete interface, at full size, in one strong material.
function lvy_bk_hero() {
    var _t = lvy_theme("gilt");
    var _m = _t.mat;
    var _y = lvy_bk_head("LIVERY", "Forty complete interface themes, drawn in GML. No sprite, no "
                       + "nine-slice, no texture page.", 44);

    // ⛔ THE FIRST VERSION OF THIS SHEET HAD THREE LAYOUT DEFECTS AND ITS OWN INK CHECK CAUGHT ONE.
    // contentH read 0.658 against a floor of 0.80 - 254 pixels of dead page below the frame - and
    // that one is mechanical. The other two were not, and were found by opening the PNG: the
    // tooltip hung outside the frame's right edge and overlapped the disabled button, and the
    // scrollbar was drawn straight across the same button. Both were arithmetic that placed a
    // component from `_bx + a fixed offset` without checking it against the content rect it had to
    // live in. A bounding box cannot see the space inside itself, and it cannot see two things
    // sitting on top of each other either.
    var _fx0 = 60, _fy0 = _y, _fx1 = 900, _fy1 = LVY_SHEET_H - 54;
    lvy_draw_frame(_t, _fx0, _fy0, _fx1, _fy1, LVY_ST_IDLE);
    var _c = lvy_frame_content(_m, _fx0, _fy0, _fx1, _fy1);
    lvy_draw_header(_t, _c[0], _c[1], _c[2], _c[1] + 56, LVY_ST_IDLE);
    lvy_draw_label(_t, "GOLD LEAF", _c[0] + 20, _c[1], _c[2] - 140, _c[1] + 56, 26, LVY_ST_IDLE);
    lvy_draw_badge(_t, _c[2] - 96, _c[1] + 14, _c[2] - 18, _c[1] + 42);
    lvy_draw_accent_label(_t, "14", _c[2] - 96, _c[1] + 14, _c[2] - 18, _c[1] + 42, 18);

    var _bx = _c[0] + 20, _by = _c[1] + 84;
    for (var _i = 0; _i < 3; _i++) {
        lvy_draw_tab(_t, _bx + _i * 160, _by, _bx + _i * 160 + 150, _by + 48, (_i == 1), LVY_ST_IDLE);
        lvy_draw_label(_t, ["ARMS", "SPELLS", "PACK"][_i], _bx + _i * 160, _by + 2,
                       _bx + _i * 160 + 150, _by + 46, 16, LVY_ST_IDLE);
    }
    lvy_draw_divider(_t, _bx, _by + 62, _c[2] - 20, _by + 78, LVY_ST_IDLE);

    // ⭐ THE SCROLLBAR CLAIMS ITS COLUMN FIRST AND EVERY OTHER COMPONENT LAYS OUT INSIDE WHAT IS
    // LEFT. That ordering is the fix for the overlap: a fixed-offset layout has no way to know a
    // gutter exists, so the gutter is subtracted from the working width before anything is placed.
    var _sbW = 34;
    var _inner1 = _c[2] - 20 - _sbW - 18;
    lvy_draw_scrollbar(_t, _c[2] - 20 - _sbW, _by, _c[2] - 20, _fy1 - 42, 0.32, 0.4, LVY_ST_IDLE);

    var _sy = _by + 96;
    var _states = lvy_states();
    var _btnW = (_inner1 - _bx - 3 * 14) / 4;
    for (var _i = 0; _i < 4; _i++) {
        var _bx0 = _bx + _i * (_btnW + 14);
        lvy_draw_button(_t, _bx0, _sy, _bx0 + _btnW, _sy + 54, _states[_i]);
        lvy_draw_label(_t, ["IDLE", "HOVER", "PRESS", "OFF"][_i], _bx0, _sy, _bx0 + _btnW,
                       _sy + 54, 17, _states[_i]);
        lvy_bk_caption(_states[_i], _bx0 + _btnW * 0.5, _sy + 62, _btnW, 15, lvy_bk_dim());
    }

    var _colW = (_inner1 - _bx - 26) * 0.55;
    lvy_draw_slider(_t, _bx, _sy + 96, _bx + _colW, _sy + 144, 0.68, LVY_ST_IDLE);
    lvy_draw_gauge(_t, _bx, _sy + 160, _bx + _colW, _sy + 200, 0.74, 5, LVY_ST_IDLE);
    var _tx = _bx + _colW + 26;
    lvy_draw_check(_t, _tx, _sy + 100, _tx + 40, _sy + 140, true, LVY_ST_IDLE);
    lvy_draw_radio(_t, _tx + 54, _sy + 100, _tx + 94, _sy + 140, true, LVY_ST_IDLE);
    lvy_draw_switch(_t, _tx + 110, _sy + 104, _tx + 190, _sy + 136, true, LVY_ST_IDLE);
    lvy_draw_tooltip(_t, _tx, _sy + 162, _inner1, _sy + 210, 0, LVY_ST_IDLE);
    lvy_draw_label(_t, "every pixel is GML", _tx, _sy + 162, _inner1, _sy + 206, 15, LVY_ST_IDLE);

    // The frame is now full height, so the space the old version left empty carries a second row:
    // the four cursors and a plain statement of what the corpus contains.
    var _ry = _sy + 240;
    lvy_draw_divider(_t, _bx, _ry, _inner1, _ry + 14, LVY_ST_IDLE);
    for (var _i = 0; _i < 4; _i++) {
        var _cx2 = _bx + 46 + _i * 96;
        lvy_draw_cursor(_t, _i, _cx2, _ry + 70, 56);
        lvy_bk_caption(lvy_cursor_name(_i), _cx2, _ry + 104, 92, 14, lvy_bk_dim());
    }
    lvy_draw_well(_t, _bx + 420, _ry + 30, _inner1, _ry + 112, LVY_ST_IDLE);
    lvy_draw_label(_t, string(lvy_corpus_count()) + " MATERIALS", _bx + 436, _ry + 40,
                   _inner1 - 16, _ry + 70, 20, LVY_ST_IDLE);
    lvy_draw_label(_t, string(lvy_family_count()) + " FAMILIES / "
                   + string(lvy_component_count()) + " COMPONENTS", _bx + 436, _ry + 72,
                   _inner1 - 16, _ry + 100, 16, LVY_ST_IDLE);

    // The right column: four other themes, same interface fragment, to make the point that this is
    // a corpus and not a skin.
    var _others = ["obsidian", "linen", "circuit", "porcelain", "oxblood_placeholder"];
    _others[4] = "leather";
    var _ox = 940;
    var _oh = (_fy1 - _y - 24 * 4) / 5;
    for (var _i = 0; _i < 5; _i++) {
        var _ot = lvy_theme(_others[_i]);
        var _oy = _y + _i * (_oh + 24);
        lvy_draw_panel(_ot, _ox, _oy, LVY_SHEET_W - 60, _oy + _oh, LVY_ST_IDLE);
        lvy_draw_button(_ot, _ox + 22, _oy + 22, _ox + 190, _oy + 70, LVY_ST_IDLE);
        lvy_draw_label(_ot, string_upper(_ot.name), _ox + 22, _oy + 22, _ox + 190, _oy + 70, 15,
                       LVY_ST_IDLE);
        lvy_draw_slider(_ot, _ox + 210, _oy + 22, _ox + 480, _oy + 70, 0.45, LVY_ST_IDLE);
        lvy_draw_gauge(_ot, _ox + 22, _oy + _oh - 44, _ox + 380, _oy + _oh - 16, 0.6, 4, LVY_ST_IDLE);
        lvy_draw_check(_ot, _ox + 400, _oy + _oh - 48, _ox + 432, _oy + _oh - 16, true, LVY_ST_IDLE);
        lvy_draw_badge(_ot, _ox + 448, _oy + _oh - 44, _ox + 500, _oy + _oh - 20);
        lvy_draw_switch(_ot, _ox + 516, _oy + _oh - 42, _ox + 588, _oy + _oh - 20, true, LVY_ST_IDLE);
    }
    return _fy1 + 20;
}

/// SHEET 2 - THE FORTY. Every material in the corpus, labelled.
///
/// ⭐ THE SHEET THE WHOLE PRODUCT IS SOLD ON, and the reason it is a grid rather than a hero: the
/// claim is VOLUME, and volume is a thing you show all of at once. A buyer counts.
function lvy_bk_corpus() {
    var _y = lvy_bk_head("THE FORTY", "Every material draws its own button, gauge and frame corner. "
                       + "Nothing here is a recolour of anything else here.", 44);
    var _c = lvy_corpus();
    var _n = array_length(_c);
    var _cols = 8;
    var _rows = ceil(_n / _cols);
    // ⛔ SOLVED FROM THE SPACE AVAILABLE, NOT TYPED. The ink box cannot see a flat panel that clips
    // off the bottom (blind spot 2), so the cell height is derived and cannot overrun.
    var _pad = 18;
    var _cw = (LVY_SHEET_W - 120 - _pad * (_cols - 1)) / _cols;
    var _ch = (LVY_SHEET_H - _y - 40 - _pad * (_rows - 1)) / _rows;

    for (var _i = 0; _i < _n; _i++) {
        var _col = _i % _cols, _row = _i div _cols;
        var _x0 = 60 + _col * (_cw + _pad);
        var _y0 = _y + _row * (_ch + _pad);
        var _t = lvy_theme_of(_c[_i]);
        lvy_draw_panel(_t, _x0, _y0, _x0 + _cw, _y0 + _ch - 22, LVY_ST_IDLE);
        lvy_draw_button(_t, _x0 + 12, _y0 + 14, _x0 + _cw - 12, _y0 + 52, LVY_ST_IDLE);
        lvy_draw_gauge(_t, _x0 + 12, _y0 + 60, _x0 + _cw - 12, _y0 + 82, 0.66, 3, LVY_ST_IDLE);
        lvy_draw_check(_t, _x0 + 12, _y0 + 90, _x0 + 36, _y0 + 114, true, LVY_ST_IDLE);
        lvy_draw_badge(_t, _x0 + 44, _y0 + 92, _x0 + 84, _y0 + 112);
        lvy_bk_caption(_c[_i].name, _x0 + _cw * 0.5, _y0 + _ch - 18, _cw, 15, lvy_bk_ink());
    }
    return _y + _rows * (_ch + _pad) + 6;
}

/// SHEET 3 - CORNERS. The six treatments, large, so the geometry is legible.
function lvy_bk_corners() {
    var _y = lvy_bk_head("THE CORNER IS HALF THE IDENTITY",
                         "Six treatments, carried by the MATERIAL - so choosing a theme changes the "
                       + "geometry of all fourteen families at once.", 44);
    var _ex = ["iron", "parchment", "slate", "porcelain", "circuit", "glass"];
    var _cols = 3;
    var _pad = 30;
    var _cw = (LVY_SHEET_W - 120 - _pad * (_cols - 1)) / _cols;
    var _ch = (LVY_SHEET_H - _y - 50 - _pad) / 2;
    for (var _i = 0; _i < 6; _i++) {
        var _col = _i % _cols, _row = _i div _cols;
        var _x0 = 60 + _col * (_cw + _pad);
        var _y0 = _y + _row * (_ch + _pad);
        var _t = lvy_theme(_ex[_i]);
        lvy_draw_frame(_t, _x0, _y0, _x0 + _cw, _y0 + _ch - 34, LVY_ST_IDLE);
        var _cr = lvy_frame_content(_t.mat, _x0, _y0, _x0 + _cw, _y0 + _ch - 34);
        lvy_draw_button(_t, _cr[0] + 20, _cr[1] + 24, _cr[2] - 20, _cr[1] + 84, LVY_ST_IDLE);
        lvy_draw_label(_t, string_upper(_t.mat.corner), _cr[0] + 20, _cr[1] + 24, _cr[2] - 20,
                       _cr[1] + 84, 22, LVY_ST_IDLE);
        lvy_draw_slider(_t, _cr[0] + 20, _cr[1] + 100, _cr[2] - 20, _cr[1] + 144, 0.5, LVY_ST_IDLE);
        lvy_bk_caption(_t.mat.name + "  -  " + _t.mat.corner + " corner, " + _t.mat.furniture
                       + " furniture", _x0 + _cw * 0.5, _y0 + _ch - 28, _cw, 17, lvy_bk_ink());
    }
    return _y + 2 * (_ch + _pad) - _pad + 6;
}

/// SHEET 4 - SURFACE CHARACTER. Thirteen ways a face is worked, each on a large plate.
function lvy_bk_character() {
    var _y = lvy_bk_head("THIRTEEN SURFACE CHARACTERS",
                         "Brass and bronze are eleven degrees apart in hue. One is BRUSHED and one "
                       + "is PITTED - and that survives being seen small.", 44);
    var _c = lvy_corpus();
    // One representative material per character, found by walking the corpus rather than typed, so
    // adding a character to the corpus cannot leave this sheet silently short.
    var _chars = lvy_char_all();
    var _cols = 5;
    var _pad = 20;
    var _cw = (LVY_SHEET_W - 120 - _pad * (_cols - 1)) / _cols;
    var _rows = ceil(array_length(_chars) / _cols);
    var _ch = (LVY_SHEET_H - _y - 40 - _pad * (_rows - 1)) / _rows;

    for (var _k = 0; _k < array_length(_chars); _k++) {
        var _rep = undefined;
        for (var _i = 0; _i < array_length(_c); _i++) {
            if (_c[_i].character == _chars[_k]) { _rep = _c[_i]; break; }
        }
        if (is_undefined(_rep)) continue;
        var _col = _k % _cols, _row = _k div _cols;
        var _x0 = 60 + _col * (_cw + _pad);
        var _y0 = _y + _row * (_ch + _pad);
        var _t = lvy_theme_of(_rep);
        lvy_draw_panel(_t, _x0, _y0, _x0 + _cw, _y0 + _ch - 40, LVY_ST_IDLE);
        lvy_bk_caption(string_upper(_chars[_k]), _x0 + _cw * 0.5, _y0 + _ch - 36, _cw, 18,
                       lvy_bk_ink());
        var _note = (_rep.density > 0)
            ? (_rep.name + ", readable to " + string(round(lvy_char_min_px(_rep.density))) + "px")
            : (_rep.name + ", smooth by design");
        lvy_bk_caption(_note, _x0 + _cw * 0.5, _y0 + _ch - 16, _cw, 14, lvy_bk_dim());
    }
    return _y + _rows * (_ch + _pad) + 6;
}

/// SHEET 5 - FAMILIES. All fourteen, in one material, so the breadth is countable.
function lvy_bk_families() {
    var _y = lvy_bk_head("FOURTEEN FAMILIES",
                         "Frame, header, panel, modal, divider, tooltip, button, toggle, slider, "
                       + "gauge, tab, scrollbar, badge, cursor.", 44);
    var _t = lvy_theme("verdigris");
    var _f = lvy_families_ui();
    var _cols = 5;
    var _pad = 20;
    var _cw = (LVY_SHEET_W - 120 - _pad * (_cols - 1)) / _cols;
    var _rows = ceil(array_length(_f) / _cols);
    var _ch = (LVY_SHEET_H - _y - 40 - _pad * (_rows - 1)) / _rows;

    for (var _i = 0; _i < array_length(_f); _i++) {
        var _col = _i % _cols, _row = _i div _cols;
        var _x0 = 60 + _col * (_cw + _pad);
        var _y0 = _y + _row * (_ch + _pad);
        lvy_render_parts_raw(lvy_draw_family(_f[_i], _t.mat, _x0, _y0, _x0 + _cw, _y0 + _ch - 26,
                                             LVY_ST_IDLE),
                             lvy_theme_surface(_t, LVY_ST_IDLE));
        lvy_bk_caption(string_upper(_f[_i]), _x0 + _cw * 0.5, _y0 + _ch - 22, _cw, 16, lvy_bk_ink());
    }
    return _y + _rows * (_ch + _pad) + 6;
}

/// SHEET 6 - STATES. Five states across four families, in one material.
function lvy_bk_states() {
    var _y = lvy_bk_head("FIVE STATES, AND EVERY ONE IS A DIFFERENT OBJECT",
                         "Pressed INVERTS the bevel and offsets the cap. Disabled PULLS chroma "
                       + "toward neutral, so it reads on slate as well as on brass.", 44);
    var _mats = ["brass", "slate", "leather", "plasma"];
    var _states = lvy_states();
    var _pad = 22;
    var _cw = (LVY_SHEET_W - 260 - _pad * 4) / 5;
    var _ch = (LVY_SHEET_H - _y - 60 - _pad * 3) / 4;

    for (var _r = 0; _r < 4; _r++) {
        var _t = lvy_theme(_mats[_r]);
        var _y0 = _y + _r * (_ch + _pad);
        lvy_text_line(string_upper(_t.mat.name), 60, _y0 + _ch * 0.42, 170, 19, lvy_bk_ink(), true);
        for (var _s = 0; _s < 5; _s++) {
            var _x0 = 240 + _s * (_cw + _pad);
            lvy_draw_button(_t, _x0, _y0 + 10, _x0 + _cw, _y0 + _ch - 30, _states[_s]);
            lvy_draw_label(_t, string_upper(_states[_s]), _x0, _y0 + 10, _x0 + _cw, _y0 + _ch - 30,
                           17, _states[_s]);
            if (_r == 0) lvy_bk_caption(_states[_s], _x0 + _cw * 0.5, _y - 24, _cw, 15, lvy_bk_dim());
        }
    }
    return _y + 4 * (_ch + _pad) - _pad + 6;
}

/// SHEET 7 - SIZE. The same component from 24 px to 200 px.
///
/// ⛔ THE SHEET THAT ANSWERS THE QUESTION A BUYER ACTUALLY HAS, and the one most generated kits do
/// not survive. An interface component is not a picture with an aspect ratio; it has to be correct
/// at 40x18 and at 400x180. Everything here is built in pixel space to the rect it was given, and
/// this sheet is the evidence.
function lvy_bk_sizes() {
    var _y = lvy_bk_head("CORRECT AT EVERY SIZE",
                         "Built in pixel space to the rectangle it is given, never authored small "
                       + "and scaled. Corner radius and bevel come off the SHORT side.", 44);
    var _t = lvy_theme("bronze");
    var _hs = [24, 34, 48, 68, 96, 140];
    var _x = 70;
    var _base = _y + 210;
    for (var _i = 0; _i < array_length(_hs); _i++) {
        var _h = _hs[_i];
        var _w = _h * 2.6;
        lvy_draw_button(_t, _x, _base - _h, _x + _w, _base, LVY_ST_IDLE);
        lvy_bk_caption(string(_h) + "px", _x + _w * 0.5, _base + 10, _w + 20, 15, lvy_bk_dim());
        _x += _w + 26;
    }
    // The same set as gauges, which is the family whose fill is most likely to overrun at extremes.
    var _base2 = _y + 430;
    _x = 70;
    for (var _i = 0; _i < array_length(_hs); _i++) {
        var _h2 = _hs[_i];
        var _w2 = _h2 * 2.6;
        lvy_draw_gauge(_t, _x, _base2 - _h2, _x + _w2, _base2, 1.0, 4, LVY_ST_IDLE);
        _x += _w2 + 26;
    }
    lvy_text_line("gauges at value 1.0 - the fill is built inside the track's own inner rect, so it "
                + "cannot run past the end", 70, _base2 + 22, LVY_SHEET_W - 140, 18, lvy_bk_dim(),
                  false);

    // And a wide/tall pair, because an aspect ratio is a different test from a size.
    var _y3 = _base2 + 70;
    lvy_draw_frame(_t, 70, _y3, 700, _y3 + 120, LVY_ST_IDLE);
    lvy_draw_frame(_t, 730, _y3, 850, _y3 + 300, LVY_ST_IDLE);
    lvy_draw_slider(_t, 890, _y3 + 20, LVY_SHEET_W - 70, _y3 + 68, 0.4, LVY_ST_IDLE);
    lvy_draw_scrollbar(_t, 890, _y3 + 90, LVY_SHEET_W - 70, _y3 + 122, 0.3, 0.35, LVY_ST_IDLE);
    lvy_draw_scrollbar(_t, 1500, _y3 + 140, 1532, _y3 + 300, 0.3, 0.35, LVY_ST_IDLE);
    lvy_text_line("630x120, 120x300, and both scrollbar orientations - measured, never assumed",
                  890, _y3 + 140, 560, 18, lvy_bk_dim(), false);
    return _y3 + 310;
}

/// SHEET 8 - THE SAME SCREEN, FOUR TIMES.
function lvy_bk_rooms() {
    var _y = lvy_bk_head("ONE INTERFACE, FOUR THEMES, NO ASSET SWAP",
                         "Identical layout code. The only difference is which theme was handed to "
                       + "the widgets - one line.", 44);
    var _ids = ["oak", "obsidian", "holo", "brocade"];
    var _pad = 24;
    var _cw = (LVY_SHEET_W - 120 - _pad) / 2;
    var _ch = (LVY_SHEET_H - _y - 40 - _pad) / 2;
    for (var _i = 0; _i < 4; _i++) {
        var _col = _i % 2, _row = _i div 2;
        var _x0 = 60 + _col * (_cw + _pad);
        var _y0 = _y + _row * (_ch + _pad);
        var _t = lvy_theme(_ids[_i]);
        var _m = _t.mat;
        lvy_draw_frame(_t, _x0, _y0, _x0 + _cw, _y0 + _ch, LVY_ST_IDLE);
        var _c = lvy_frame_content(_m, _x0, _y0, _x0 + _cw, _y0 + _ch);
        lvy_draw_header(_t, _c[0], _c[1], _c[2], _c[1] + 44, LVY_ST_IDLE);
        lvy_draw_label(_t, string_upper(_m.name), _c[0] + 14, _c[1], _c[2] - 90, _c[1] + 44, 19,
                       LVY_ST_IDLE);
        lvy_draw_badge(_t, _c[2] - 70, _c[1] + 11, _c[2] - 14, _c[1] + 33);
        lvy_draw_accent_label(_t, "7", _c[2] - 70, _c[1] + 11, _c[2] - 14, _c[1] + 33, 15);
        var _bx = _c[0] + 16, _by = _c[1] + 62;
        lvy_draw_button(_t, _bx, _by, _bx + 150, _by + 44, LVY_ST_IDLE);
        lvy_draw_button(_t, _bx + 164, _by, _bx + 314, _by + 44, LVY_ST_HOVER);
        lvy_draw_slider(_t, _bx, _by + 58, _bx + 314, _by + 100, 0.55, LVY_ST_IDLE);
        lvy_draw_gauge(_t, _bx, _by + 112, _bx + 314, _by + 142, 0.7, 4, LVY_ST_IDLE);
        lvy_draw_check(_t, _bx + 336, _by + 4, _bx + 372, _by + 40, true, LVY_ST_IDLE);
        lvy_draw_radio(_t, _bx + 336, _by + 52, _bx + 372, _by + 88, true, LVY_ST_IDLE);
        lvy_draw_switch(_t, _bx + 336, _by + 108, _bx + 412, _by + 138, true, LVY_ST_IDLE);
        lvy_draw_scrollbar(_t, _c[2] - 44, _by, _c[2] - 16, _c[3] - 12, 0.3, 0.4, LVY_ST_IDLE);
    }
    return _y + 2 * (_ch + _pad) - _pad + 6;
}

/// ============================================================================================
/// THE COVER
///
/// ⛔ A COVER IS GENERATED ILLUSTRATION, NEVER A SCREENSHOT (CLAUDE.md 4.2c). The eight sheets above
/// are the screenshots; this has a different job, which is to make someone stop scrolling.
///
/// ⭐ AND FOR THIS PRODUCT THE PRODUCT ITSELF IS THE RIGHT ILLUSTRATOR. The OpenAI route returned
/// exit 7 - out of credits - which is the one condition that switches generators, and the doctrine's
/// fallback chain ends at "ship a DESIGNED cover". A stock-photo pastiche of material samples would
/// have been a picture of something we did not make; six real plaques drawn by the six corner
/// treatments in six materials is a picture of exactly what is for sale, composed deliberately at
/// cover size rather than cropped from a sheet.
///
/// ⚠️ NO WORDMARK IN THE PIXELS beyond the product name set in the product's own face. A generated
/// title is unreadable at thumbnail size and this wing has shipped source text printed through one.
/// The subtitle lives on the itch page.
#macro LVY_COVER_W 630
#macro LVY_COVER_H 500

/// ⛔ ONE HERO OBJECT, THEN THE EVIDENCE OF BREADTH BENEATH IT — AND THE FIRST VERSION WAS A GRID.
/// The first cover was six equal plaques in two columns. It was clean, honest and informative, and
/// held next to this catalogue's own reference covers (Sigil Core's single glowing seal, Meridian's
/// dark node tree) it read as a CONTACT SHEET rather than as a cover. A grid of six equals has no
/// subject; the eye is given nowhere to land and nothing is at stake in it.
///
/// ⭐ A COVER NEEDS A SUBJECT AND A COVER NEEDS A CLAIM, and they do different jobs. The subject is
/// one large ornate frame, drawn at a size where its moulding, its furniture and its surface
/// character are all legible - which is the craft argument. The claim is the strip of five other
/// materials under it, which is the volume argument. Six plaques of equal weight made neither.
function lvy_bk_cover() {
    // -- THE SUBJECT ---------------------------------------------------------------------------
    var _t = lvy_theme("gilt");
    var _hx0 = 34, _hy0 = 104, _hx1 = LVY_COVER_W - 34, _hy1 = 356;
    lvy_draw_frame(_t, _hx0, _hy0, _hx1, _hy1, LVY_ST_IDLE);
    var _c = lvy_frame_content(_t.mat, _hx0, _hy0, _hx1, _hy1);
    lvy_draw_header(_t, _c[0], _c[1], _c[2], _c[1] + 42, LVY_ST_IDLE);
    lvy_draw_label(_t, "GOLD LEAF", _c[0] + 14, _c[1], _c[2] - 76, _c[1] + 42, 19, LVY_ST_IDLE);
    lvy_draw_badge(_t, _c[2] - 62, _c[1] + 11, _c[2] - 12, _c[1] + 32);
    lvy_draw_accent_label(_t, "40", _c[2] - 62, _c[1] + 11, _c[2] - 12, _c[1] + 32, 14);

    var _bx = _c[0] + 14, _by = _c[1] + 56;
    var _bw = (_c[2] - _bx - 26) * 0.5;
    lvy_draw_button(_t, _bx, _by, _bx + _bw, _by + 40, LVY_ST_IDLE);
    lvy_draw_button(_t, _bx + _bw + 14, _by, _bx + _bw * 2 + 14, _by + 40, LVY_ST_HOVER);
    lvy_draw_slider(_t, _bx, _by + 50, _c[2] - 14, _by + 88, 0.62, LVY_ST_IDLE);
    lvy_draw_gauge(_t, _bx, _by + 96, _c[2] - 74, _by + 122, 0.74, 4, LVY_ST_IDLE);
    lvy_draw_check(_t, _c[2] - 60, _by + 92, _c[2] - 26, _by + 126, true, LVY_ST_IDLE);

    // -- THE CLAIM -----------------------------------------------------------------------------
    // Five other materials, deliberately picked to span the corpus's extremes: the darkest, the
    // most chromatic, the palest, the most textured and the emissive one. A strip of five that all
    // looked alike would argue against the product rather than for it.
    var _ids = ["obsidian", "malachite", "porcelain", "leather", "holo"];
    var _sy0 = 374, _sy1 = 452;
    var _gap = 12;
    var _sw = (LVY_COVER_W - 68 - _gap * 4) / 5;
    for (var _i = 0; _i < 5; _i++) {
        var _st = lvy_theme(_ids[_i]);
        var _sx = 34 + _i * (_sw + _gap);
        lvy_draw_panel(_st, _sx, _sy0, _sx + _sw, _sy1, LVY_ST_IDLE);
        lvy_draw_button(_st, _sx + 8, _sy0 + 8, _sx + _sw - 8, _sy0 + 34, LVY_ST_IDLE);
        lvy_draw_gauge(_st, _sx + 8, _sy0 + 42, _sx + _sw - 8, _sy0 + 62, 0.66, 2, LVY_ST_IDLE);
    }

    // The wordmark, set in the product's own title face, embossed by the same lamp as everything
    // else on the page.
    lvy_text_fit("LIVERY", LVY_COVER_W * 0.5, 46, LVY_COVER_W - 80, 54,
                 lvy_bk_page(), lvy_bk_ink());
    // ⚠️ lvy_text_fit AND NOT lvy_text_line, DELIBERATELY. The two differ in ANCHOR (centre vs left)
    // and in EMBOSS, and this catalogue records a contrast fix that swapped one for the other and
    // clipped every left-edge caption off the page. Here the subtitle wants to be centred, so the
    // centre-anchored one is correct and is passed a CENTRE x rather than a left edge.
    lvy_text_fit("40 INTERFACE THEMES / DRAWN IN GML", LVY_COVER_W * 0.5, 84,
                 LVY_COVER_W - 120, 16, lvy_bk_page(), lvy_bk_dim());
    lvy_text_fit("NO SPRITE / NO NINE-SLICE / NO TEXTURE PAGE", LVY_COVER_W * 0.5, 476,
                 LVY_COVER_W - 120, 15, lvy_bk_page(), lvy_bk_dim());
    return _sy1 + 40;
}

/// ============================================================================================
/// THE RUNNER
/// ============================================================================================

/// Render one sheet, measure it, save it, and return a JSON fragment describing what happened.
function lvy_bk_one(_name, _fn, _contentY) {
    var _surf = surface_create(LVY_SHEET_W, LVY_SHEET_H);
    surface_set_target(_surf);
    draw_clear(lvy_bk_page());
    lvy_lamp_reset();

    var _endY = _fn();
    var _ib = lvy_bk_ink_bounds(LVY_SHEET_W, LVY_SHEET_H, _contentY);

    surface_reset_target();
    surface_save(_surf, "sheet_" + _name + ".png");
    surface_free(_surf);

    // ⛔ THE EXTENT CHECK IS ONE NUMBER AND IT IS BLIND IN TWO DIRECTIONS - hence the ink box beside
    // it. Both are reported; the runner script decides.
    var _clipped = (_endY > LVY_SHEET_H) || (_ib.full[3] >= LVY_SHEET_H - 6)
                || (_ib.full[2] >= LVY_SHEET_W - 6) || (_ib.full[0] <= 5) || (_ib.full[1] <= 5);
    var _cw = (_ib.content[2] - _ib.content[0]) / LVY_SHEET_W;
    var _chh = (_ib.content[3] - _ib.content[1]) / max(1, LVY_SHEET_H - _contentY);

    return "{\"name\":\"" + _name + "\""
         + ",\"endY\":" + string(round(_endY))
         + ",\"ink\":" + string(_ib.ink)
         + ",\"fullBox\":[" + string(_ib.full[0]) + "," + string(_ib.full[1]) + ","
                            + string(_ib.full[2]) + "," + string(_ib.full[3]) + "]"
         + ",\"contentW\":" + string_format(_cw, 1, 3)
         + ",\"contentH\":" + string_format(_chh, 1, 3)
         + ",\"clipped\":" + (_clipped ? "true" : "false")
         + ",\"ok\":" + ((!_clipped && _cw >= 0.86 && _chh >= 0.80 && _ib.ink > 40000)
                         ? "true" : "false")
         + "}";
}

/// The cover, at its own size. Kept out of lvy_bk_one because that one is fixed to the sheet
/// dimensions and a cover that had to pretend to be 1600x1000 would be a cropped sheet, which is
/// the exact thing a cover must not be.
function lvy_bake_cover() {
    var _surf = surface_create(LVY_COVER_W, LVY_COVER_H);
    surface_set_target(_surf);
    draw_clear(lvy_bk_page());
    lvy_lamp_reset();
    lvy_bk_cover();
    var _ib = lvy_bk_ink_bounds(LVY_COVER_W, LVY_COVER_H, 100);
    surface_reset_target();
    surface_save(_surf, "cover.png");
    surface_free(_surf);
    return "{\"name\":\"cover\",\"w\":" + string(LVY_COVER_W) + ",\"h\":" + string(LVY_COVER_H)
         + ",\"ink\":" + string(_ib.ink)
         + ",\"fullBox\":[" + string(_ib.full[0]) + "," + string(_ib.full[1]) + ","
                            + string(_ib.full[2]) + "," + string(_ib.full[3]) + "]"
         + ",\"ok\":" + ((_ib.ink > 20000 && _ib.full[0] > 2 && _ib.full[1] > 2
                          && _ib.full[2] < LVY_COVER_W - 2 && _ib.full[3] < LVY_COVER_H - 2)
                         ? "true" : "false") + "}";
}

/// ============================================================================================
/// THE DEMO GIF
///
/// ⭐ THE HIGHEST-CONVERTING ASSET ON AN ITCH PAGE, AND FOR THIS PRODUCT IT IS ALSO THE HONEST ONE.
/// A still shows one theme. The thing being sold is a DIFFERENCE between forty, which a still
/// cannot show at all - so the GIF is not decoration here, it is the only asset that states the
/// actual claim.
///
/// ⛔ EVERY FRAME IS AN EXPLICIT STATE, NEVER A RUNNING ANIMATION PHOTOGRAPHED. The engine's own rAF
/// loop keeps running during a capture, so photographing an easing in progress paces the GIF by
/// screenshot latency rather than by anything deterministic. Here frame N simply IS material N.
///
/// ⛔ AND THE FRAME NUMBER IS PADDED BY ARITHMETIC. This wing lost a GIF to
/// `string_replace(string_format(f,3,0), " ", "0")` - which replaces ONE occurrence, so "  0"
/// became "0 0" and ffmpeg found no sequence, while the upstream frame COUNT still read 44 of 44.
function lvy_pad3(_n) {
    if (_n < 10) return "00" + string(_n);
    if (_n < 100) return "0" + string(_n);
    return string(_n);
}

function lvy_frames_run() {
    global.lvy_stage = 200;
    var _n = lvy_corpus_count();
    var _w = 800, _h = 450;
    var _count = 0;

    for (var _i = 0; _i < _n; _i++) {
        var _t = lvy_theme_at(_i);
        var _m = _t.mat;
        var _s = lvy_theme_surface(_t, LVY_ST_IDLE);
        var _surf = surface_create(_w, _h);
        surface_set_target(_surf);
        draw_clear(_s.ground);
        lvy_lamp_reset();

        lvy_draw_frame(_t, 18, 16, _w - 18, _h - 16, LVY_ST_IDLE);
        var _c = lvy_frame_content(_m, 18, 16, _w - 18, _h - 16);
        lvy_draw_header(_t, _c[0], _c[1], _c[2], _c[1] + 40, LVY_ST_IDLE);
        lvy_draw_label(_t, string_upper(_m.name), _c[0] + 14, _c[1], _c[2] - 84, _c[1] + 40, 19,
                       LVY_ST_IDLE);
        lvy_draw_badge(_t, _c[2] - 70, _c[1] + 10, _c[2] - 12, _c[1] + 31);
        lvy_draw_accent_label(_t, string(_i + 1) + "/" + string(_n),
                              _c[2] - 70, _c[1] + 10, _c[2] - 12, _c[1] + 31, 13);

        var _bx = _c[0] + 14, _by = _c[1] + 54;
        var _sbW = 26;
        var _in = _c[2] - 14 - _sbW - 14;
        lvy_draw_scrollbar(_t, _c[2] - 14 - _sbW, _by, _c[2] - 14, _c[3] - 14, 0.3, 0.4, LVY_ST_IDLE);

        var _states = lvy_states();
        var _bw = (_in - _bx - 3 * 10) / 4;
        for (var _k = 0; _k < 4; _k++) {
            var _bx0 = _bx + _k * (_bw + 10);
            lvy_draw_button(_t, _bx0, _by, _bx0 + _bw, _by + 38, _states[_k]);
            lvy_draw_label(_t, ["IDLE", "HOVER", "PRESS", "OFF"][_k], _bx0, _by, _bx0 + _bw,
                           _by + 38, 14, _states[_k]);
        }
        lvy_draw_slider(_t, _bx, _by + 50, _in - 150, _by + 88, 0.62, LVY_ST_IDLE);
        lvy_draw_gauge(_t, _bx, _by + 96, _in - 150, _by + 122, 0.74, 4, LVY_ST_IDLE);
        lvy_draw_check(_t, _in - 132, _by + 52, _in - 100, _by + 84, true, LVY_ST_IDLE);
        lvy_draw_radio(_t, _in - 88, _by + 52, _in - 56, _by + 84, true, LVY_ST_IDLE);
        lvy_draw_switch(_t, _in - 132, _by + 96, _in - 60, _by + 122, true, LVY_ST_IDLE);
        lvy_draw_divider(_t, _bx, _by + 132, _in, _by + 148, LVY_ST_IDLE);
        lvy_text_line(_m.family + " / " + _m.corner + " corner / " + _m.character + " surface",
                      _bx, _by + 154, _in - _bx, 14, _s.ink, false);

        surface_reset_target();
        surface_save(_surf, "frame_" + lvy_pad3(_i) + ".png");
        surface_free(_surf);
        _count += 1;
    }

    var _f = file_text_open_write("lvy_frames.json");
    file_text_write_string(_f, "{\"frames\":" + string(_count)
        + ",\"w\":" + string(_w) + ",\"h\":" + string(_h)
        + ",\"materials\":" + string(_n) + "}");
    file_text_close(_f);
}

/// Bake every sheet and write the manifest.
function lvy_bake_run() {
    global.lvy_stage = 100;
    var _rows = [];
    array_push(_rows, lvy_bake_cover());
    array_push(_rows, lvy_bk_one("1_hero",      lvy_bk_hero,      150));
    array_push(_rows, lvy_bk_one("2_corpus",    lvy_bk_corpus,    150));
    array_push(_rows, lvy_bk_one("3_corners",   lvy_bk_corners,   150));
    array_push(_rows, lvy_bk_one("4_character", lvy_bk_character, 150));
    array_push(_rows, lvy_bk_one("5_families",  lvy_bk_families,  150));
    array_push(_rows, lvy_bk_one("6_states",    lvy_bk_states,    150));
    array_push(_rows, lvy_bk_one("7_sizes",     lvy_bk_sizes,     150));
    array_push(_rows, lvy_bk_one("8_rooms",     lvy_bk_rooms,     150));

    var _j = "{\"sheets\":[";
    for (var _i = 0; _i < array_length(_rows); _i++) {
        if (_i > 0) _j += ",";
        _j += _rows[_i];
    }
    _j += "],\"materials\":" + string(lvy_corpus_count())
        + ",\"families\":" + string(lvy_family_count())
        + ",\"components\":" + string(lvy_component_count()) + "}";

    var _f = file_text_open_write("lvy_bake.json");
    file_text_write_string(_f, _j);
    file_text_close(_f);
}
