{
  "$GMScript": "v1",
  "%Name": "lvy_material",
  "name": "lvy_material",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}