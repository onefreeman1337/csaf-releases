/// LIVERY - lvy_material. The forty material seeds, and the state model.
///
/// ⛔ THIS FILE IS THE PRODUCT. Everything else draws; this decides what is being drawn out of.
/// Fourteen component families times forty materials is 560 distinct drawn components, and not one
/// of them is a PNG, a nine-slice or a tint of another one.
///
/// -- WHAT A MATERIAL IS ----------------------------------------------------------------------
/// Not a colour. A material is:
///
///   1. A FIVE-STOP RAMP through Oklch, evenly spaced in APPARENT lightness (see lvy_palette for
///      why that has to be Oklab and not HSV). The ramp is what lvy_relief shades a bevel with,
///      so it is what makes a raised button look raised.
///   2. A GROUND - the flat field the component sits on - and an INK that is guaranteed to be
///      readable against that ground.
///   3. An ACCENT, derived from the base hue rather than picked, so it belongs to the material.
///   4. A SURFACE CHARACTER: grain, hatch, knurl, crazing, weave, trace, speckle, vein, fleck,
///      scanline, brush, pit, or none. This is the thing that tells brass from bronze at a glance
///      when their hues are eleven degrees apart.
///   5. A GEOMETRY LANGUAGE: corner treatment, border weight, and what furniture the frame
///      carries. Porcelain has coved corners and no studs; blackened iron has square corners and
///      forty-eight of them.
///
/// ⛔ 4 AND 5 ARE WHY THIS IS NOT A PALETTE SWAP, AND THE DISTINCTION IS THE WHOLE PRODUCT. Forty
/// recolourings of one button is a colour picker with extra steps, and a buyer can write that
/// themselves in an afternoon. Forty materials that differ in how their surface is worked and how
/// their corners are cut are forty different objects, and re-authoring those by hand as art is
/// weeks of work - which is precisely the labour this removes.
///
/// -- THE STATE MODEL, AND THE LAW IT OBEYS ---------------------------------------------------
/// ⛔ A STATE TRANSFORM PULLS TOWARD A TARGET. IT NEVER SCALES OR DISPLACES.
///
/// This is a law this wing paid for on a previous product, and it is written into
/// Wings/GameMaker/CLAUDE.md: a browning model that ADDED to hue turned poultry swamp-green, and a
/// chroma model that MULTIPLIED could not brown pale dough at all, because both were tuned on the
/// one substance that did not need the missing term.
///
/// The identical trap is live here and it is worse, because forty materials is forty chances to
/// meet it. `disabled` implemented as `C * 0.4` looks perfect on brass, whose chroma is 0.09, and
/// does NOTHING WHATSOEVER on slate, whose chroma is 0.006 - so a disabled slate button would be
/// indistinguishable from an enabled one, on a product whose entire promise is that every state
/// reads. Implemented as a PULL toward a target chroma of 0.004 at strength 0.72, it works on both,
/// and lvy_selftest asserts the disabled/idle separation on ALL FORTY materials rather than on the
/// vivid one.
///
/// ⚠️ TUNE ON THE PALEST AND MOST NEUTRAL MATERIAL, NEVER THE VIVID ONE. The vivid one hides
/// exactly the terms that are missing. In this corpus that means bone and slate, not malachite.
/// ============================================================================================

/// The usable lightness band. Below the floor an Oklch colour is indistinguishable from black on a
/// cheap panel; above the ceiling it clips to paper white and the top two ramp stops merge.
#macro LVY_L_FLOOR 0.085
#macro LVY_L_CEIL  0.965

/// ⛔ A RAMP IS SLID TO FIT, NEVER CLAMPED. MEASURED on a sibling product in this catalogue and
/// recorded in the wing constitution: limewash at L 0.900 put its top two stops at 0.985 and 1.070,
/// both clamped to the ceiling, so they became THE SAME COLOUR and the worst adjacent gap was
/// exactly 0.000. A bevel whose two brightest walls are identical reads as a flat fill with a line
/// round it - which is the precise look this product is sold against.
///
/// The smallest adjacent-stop separation any material may have. Asserted for all forty.
#macro LVY_RAMP_MIN_GAP 0.028

/// The smallest lightness distance between a material's ink and its ground.
///
/// ⛔ ON A LIGHT MATERIAL EVERY RAMP STOP IS LIGHT, so m0 is NOT a text colour - ink is. Parchment's
/// ground is L 0.80 and its ramp runs 0.62 to 0.98, which makes m0 "merely less pale" rather than
/// dark. Every caption, label and value in this package is drawn in `ink`, and ink is defined
/// relative to its own ground with this floor asserted.
#macro LVY_INK_MIN_CONTRAST 0.34

/// ============================================================================================
/// SURFACE CHARACTER - and the size floor that keeps it honest
/// ============================================================================================

/// The smallest component this product claims to draw correctly, in pixels on the short side.
///
/// ⛔ INTERFACE COMPONENTS ARE SMALL BY DEFINITION AND THIS IS THE CONSTRAINT NOBODY REMEMBERS.
/// A button is 28 pixels tall in most games; a scrollbar is 12 wide; a badge is 16 across. A
/// material whose entire identity is a hatch at 40 strokes per unit is a material that DOES NOT
/// EXIST at the size it ships at - lvy_render floors every stroke at 1.0 px, so 40 strokes across
/// 24 pixels is a solid block, not a hatch.
#macro LVY_MIN_COMPONENT_PX 24

/// The minimum spacing a character feature must have, in pixels, at LVY_MIN_COMPONENT_PX.
///
/// Two pixels: one for the stroke and one for the gap. At anything less the character rasterises
/// to a flat tone, which is not a defect in the renderer but IS a lie in the corpus.
#macro LVY_CHAR_MIN_SPACING_PX 2.0

/// The largest character density a material may declare, derived rather than typed.
///
/// ⭐ DERIVED, BECAUSE A TYPED CONSTANT IS THE SIXTH MEMBER OF A FAMILY THIS FACTORY KEEPS PAYING
/// FOR. If this were the literal 12 and someone later raised LVY_MIN_COMPONENT_PX, the constant
/// would silently stop meaning what its name says. Written as the division, it moves with both.
function lvy_char_max_density() {
    return LVY_MIN_COMPONENT_PX / LVY_CHAR_MIN_SPACING_PX;
}

/// The pixel size at which a given density's features reach LVY_CHAR_MIN_SPACING_PX.
///
/// This is the honest answer to "how small can this material go", and lvy_bake prints it on the
/// material sheet so a buyer can read it rather than discover it.
function lvy_char_min_px(_density) {
    if (_density <= 0) return 0;
    return _density * LVY_CHAR_MIN_SPACING_PX;
}

/// ============================================================================================
/// THE RAMP
/// ============================================================================================

/// Five stops of lightness for a material, m0 (deepest) to m4 (brightest).
///
/// The band is [LVY_L_FLOOR, LVY_L_CEIL]. If the requested spread does not fit, the WHOLE ramp is
/// slid toward the middle; if it cannot fit even then, the spread itself is compressed. Compression
/// is not the same defect as clamping: clamping moves one end and merges two stops, compression
/// moves every stop and preserves their spacing ratio, so no two stops can ever collide.
function lvy_ramp_stops(_L, _spread) {
    var _band = LVY_L_CEIL - LVY_L_FLOOR;
    var _sp = min(_spread, _band);
    var _lo = _L - _sp * 0.5;
    var _hi = _L + _sp * 0.5;
    if (_lo < LVY_L_FLOOR) { _hi += (LVY_L_FLOOR - _lo); _lo = LVY_L_FLOOR; }
    if (_hi > LVY_L_CEIL)  { _lo -= (_hi - LVY_L_CEIL);  _hi = LVY_L_CEIL;  }
    // After both slides _lo can only be below the floor if _sp == _band, in which case it is the
    // floor exactly. Belt and braces, and cheap.
    _lo = max(_lo, LVY_L_FLOOR);
    var _out = array_create(LVY_RAMP_N);
    for (var _i = 0; _i < LVY_RAMP_N; _i++) {
        _out[_i] = _lo + (_hi - _lo) * (_i / (LVY_RAMP_N - 1));
    }
    return _out;
}

/// Chroma at a given point along the ramp.
///
/// Real materials are most chromatic in the MIDDLE of their range: a brass highlight goes toward
/// white and a brass shadow goes toward black, and both lose saturation doing it. A flat chroma
/// across the ramp is the single loudest tell of a colour ramp built in code, because the deepest
/// stop comes out as a saturated dark that no lit surface ever produces.
///
/// ⚠️ lvy_chroma_ceiling in lvy_palette does something DIFFERENT and both are needed. That one is a
/// GAMUT guard - it stops Oklch handing back a neon colour at L 0.95. This one is a MATERIAL model.
/// Removing either brings back a failure the other cannot see.
function lvy_ramp_chroma(_C, _t) {
    return _C * (0.46 + 0.54 * sin(pi * clamp(_t, 0, 1)));
}

/// ============================================================================================
/// THE STATE MODEL
/// ============================================================================================

#macro LVY_ST_IDLE     "idle"
#macro LVY_ST_HOVER    "hover"
#macro LVY_ST_PRESSED  "pressed"
#macro LVY_ST_DISABLED "disabled"
#macro LVY_ST_FOCUS    "focus"

/// Pull _v toward _target by _k. The ONLY colour transform in this package.
///
/// ⛔ SEE THE HEADER. Every state in this product is one or more calls to this function, and no
/// state anywhere multiplies or adds. k is a strength in 0..1, so k=0 is a no-op and k=1 lands
/// exactly on the target, which makes every state trajectory readable as "how far toward what".
function lvy_pull(_v, _target, _k) {
    return _v + (_target - _v) * clamp(_k, 0, 1);
}

/// Pull a HUE toward a target, the short way round the circle.
///
/// ⛔ A HUE IS NOT A SCALAR AND lvy_pull IS WRONG FOR IT. Pulling hue 350 toward hue 10 with a
/// linear pull walks BACKWARDS through 180 - straight through cyan - so a warm material asked to
/// take a warm accent passes through the coldest colour on the wheel on its way. The wrap is the
/// entire content of this function and it is why it exists separately.
function lvy_pull_hue(_h, _target, _k) {
    var _d = ((_target - _h) + 540) % 360 - 180;
    return ((_h + _d * clamp(_k, 0, 1)) + 360) % 360;
}

/// How a state moves a material's lightness, chroma, ramp spread and bevel.
///
/// Returns { dL, spreadK, Ctarget, Ck, bevel, inset } where
///   dL       lightness offset applied to the whole ramp AND the ground
///   spreadK  a multiplier on the ramp's SPREAD - how much relief the surface shows
///   Ctarget  the chroma this state pulls toward
///   Ck       how hard it pulls
///   bevel    a multiplier on bevel depth (negative INVERTS the bevel - a pressed button is sunken)
///   inset    how far the cap moves along the lamp vector, in unit-box units
///
/// ⛔ `pressed` INVERTS THE BEVEL RATHER THAN DARKENING THE FACE, and that is the difference
/// between a button that depresses and a button that changes colour. A darkened face reads as a
/// different button; an inverted bevel reads as the SAME button, pushed in.
///
/// ⛔⛔ `spreadK` WAS NOT IN THE FIRST VERSION AND ITS ABSENCE FAILED SEVEN MATERIALS. MEASURED on
/// this product's first headless run: 1737 pass, 17 fail, and six of the failures were
/// "DISABLED is indistinguishable from idle" on iron, bone, marble, obsidian, porcelain and carbon.
///
/// ⭐ THE HEADER OF THIS FILE PREDICTED THE FAILURE MODE AND I STILL SHIPPED HALF OF IT. It says a
/// chroma SCALE is invisible on a near-neutral material, so chroma was written as a pull - correctly.
/// But the LIGHTNESS half was left as a flat -0.020 offset, which is small on every material and is
/// ALL that a near-neutral material has to distinguish its states with, because its chroma had
/// almost none to give. Tuning on the vivid material hides the missing term; here the vivid ones
/// passed on chroma alone and the neutrals had nothing left.
///
/// The fix is a term with a physical meaning rather than a bigger constant: A DISABLED CONTROL HAS
/// LESS RELIEF. Compressing the ramp toward its own centre moves every stop except the middle one,
/// on every material, whatever its chroma - and it is what a flattened, dead control actually looks
/// like. `bevel: 0.42` was already saying this about the GEOMETRY; the ramp now agrees.
///
/// ⚠️ THE SAME TERM FIXES gilt's HOVER, WHICH FAILED FOR A DIFFERENT REASON AND IS WORTH RECORDING.
/// Gilt sits at L 0.72 with a spread of 0.52, so its ramp already reaches 0.98 and lvy_ramp_stops
/// SLIDES it back down to fit the ceiling. A pure `dL` for hover is therefore absorbed entirely by
/// the slide and the ramp does not move at all. A spread change cannot be absorbed that way: a
/// ceiling-pinned ramp that widens still moves every stop below the top one.
function lvy_state_delta(_state) {
    switch (_state) {
        case LVY_ST_HOVER:
            // Brighter, slightly more chromatic, and slightly MORE contrast: the material catches
            // more light. The spread term is what survives a ceiling-pinned ramp.
            return { dL: 0.070, spreadK: 1.12, Ctarget: 0.20, Ck: 0.16, bevel: 1.10, inset: 0 };
        case LVY_ST_PRESSED:
            // Darker, and the bevel turns over. The cap also moves a little TOWARD the lamp's
            // shadow side, which is what selling the depression actually takes.
            return { dL: -0.048, spreadK: 0.92, Ctarget: 0.10, Ck: 0.10, bevel: -0.85, inset: 0.012 };
        case LVY_ST_DISABLED:
            // ⛔ PULLS, NOT SCALES, ON BOTH AXES. A dead control is flat AND grey.
            //
            // ⚠️ dL WAS -0.020 AND IT WAS TOO TIMID TO SURVIVE ITS OWN SPREAD TERM. MEASURED on the
            // second headless run: marble still read as identical between idle and disabled,
            // because marble's IDLE ramp is ceiling-pinned - lvy_ramp_stops slides it down to fit -
            // while its narrower DISABLED ramp is not, so compressing it moved the effective centre
            // back UP by more than dL moved it down. The two terms cancelled.
            //
            // ⭐ A CEILING-PINNED RAMP IS A THIRD PLACE WHERE A DELTA CAN BE SILENTLY ABSORBED, and
            // it is invisible on the two thirds of the corpus that sit nowhere near the ceiling.
            // -0.045 clears the compression on the lightest material in the corpus with margin, and
            // a disabled control that dims by four hundredths of a lightness unit is not a strong
            // enough signal in any case.
            return { dL: -0.045, spreadK: 0.55, Ctarget: 0.004, Ck: 0.72, bevel: 0.42, inset: 0 };
        case LVY_ST_FOCUS:
            // Focus adds a ring; it deliberately does NOT move the ramp, so a focused button and a
            // hovered one are told apart by shape rather than by brightness.
            return { dL: 0.0, spreadK: 1.0, Ctarget: 0.20, Ck: 0.0, bevel: 1.0, inset: 0 };
        default:
            return { dL: 0.0, spreadK: 1.0, Ctarget: 0.20, Ck: 0.0, bevel: 1.0, inset: 0 };
    }
}

/// ============================================================================================
/// THE CORPUS - forty materials
///
/// SIX FAMILIES, and the families are not decoration: they decide the geometry language. A metal
/// frame is riveted and square; a mineral one is chamfered and heavy; a textile one is stitched and
/// soft. That is why a buyer can pick "the leather one" and get an interface that agrees with
/// itself, rather than a leather-coloured version of the same rectangle.
///
///   metal      8   worked, riveted, square or chamfered, high ramp spread
///   organic    7   grown, soft corners, warm, low chroma, visible grain
///   mineral    6   cut, heavy chamfers, veined or speckled, cool
///   made       7   moulded, coved or pill corners, smooth, high chroma
///   textile    5   woven, stitched borders, matte, very low ramp spread
///   technical  7   emissive accents, step corners, traces and scanlines
///
/// ⚠️ THE COUNTS ARE ASSERTED IN lvy_selftest, against this table rather than against a typed
/// total, so adding a material to the array cannot silently break the claim on the store page.
/// ============================================================================================

/// Character ids. Strings rather than an enum so the bake sheets and the Readme can print them.
#macro LVY_CH_NONE     "none"
#macro LVY_CH_GRAIN    "grain"
#macro LVY_CH_HATCH    "hatch"
#macro LVY_CH_KNURL    "knurl"
#macro LVY_CH_CRAZE    "craze"
#macro LVY_CH_WEAVE    "weave"
#macro LVY_CH_TRACE    "trace"
#macro LVY_CH_SPECKLE  "speckle"
#macro LVY_CH_VEIN     "vein"
#macro LVY_CH_FLECK    "fleck"
#macro LVY_CH_SCANLINE "scanline"
#macro LVY_CH_BRUSH    "brush"
#macro LVY_CH_PIT      "pit"

/// Corner treatments.
#macro LVY_CN_SQUARE  "square"
#macro LVY_CN_ROUND   "round"
#macro LVY_CN_CHAMFER "chamfer"
#macro LVY_CN_COVE    "cove"
#macro LVY_CN_STEP    "step"
#macro LVY_CN_PILL    "pill"

/// Frame furniture.
#macro LVY_FN_NONE    "none"
#macro LVY_FN_STUD    "stud"
#macro LVY_FN_BRACKET "bracket"
#macro LVY_FN_FILLET  "fillet"
#macro LVY_FN_CAP     "cap"
#macro LVY_FN_STITCH  "stitch"

/// One row of the corpus.
///
/// ⚠️ EVERY FIELD IS REQUIRED AND NONE DEFAULTS. A material with a missing field would fall through
/// to whatever the reader happened to do on `undefined`, which in GML is usually 0 and silently
/// plausible. lvy_selftest walks every row and asserts every field is present and in range.
function lvy_mat(_id, _name, _family, _L, _C, _h, _spread, _groundDL, _inkDL, _accentDH, _accentC,
                 _character, _density, _amp, _corner, _furniture, _weight) {
    return {
        id: _id, name: _name, family: _family,
        L: _L, C: _C, h: _h, spread: _spread,
        groundDL: _groundDL, inkDL: _inkDL,
        accentDH: _accentDH, accentC: _accentC,
        character: _character, density: _density, amp: _amp,
        corner: _corner, furniture: _furniture, weight: _weight
    };
}

/// The forty. Ordered by family so the material sheet reads as a swatch card.
///
/// ⛔ THE NUMBERS ARE NOT ARBITRARY AND THEY ARE NOT RANDOM. Each row's L and h are set from what
/// the real material looks like under a single raking lamp, the spread from how glossy it is (a
/// polished metal swings the whole ramp; felt barely moves), and the density from how fine its
/// surface is - bounded above by lvy_char_max_density() so nothing in the table can claim a
/// character it cannot draw at LVY_MIN_COMPONENT_PX.
/// ⛔ THE CORPUS IS BUILT ONCE INTO A GLOBAL, NOT WITH `static`, AND THAT IS A DELIBERATE CHOICE
/// ABOUT AN UNPROVEN KEYWORD. `static` inside a function is the natural way to write this and it is
/// documented for recent runtimes - but NO shipped product in this catalogue uses it, so on this
/// build it is untested, and a language feature that fails at compile time inside a paid package is
/// not worth forty struct allocations. Top-level script code IS proven to run at game start here:
/// lvy_relief sets its lamp globals that way and lvy_selftest asserts it happened.
///
/// ⚠️ The rebuild is not free and it is not a micro-optimisation to avoid it: lvy_material_get
/// walks the corpus, lvy_surface is called for every component in every state, and the demo room
/// resolves a whole screenful per frame. Rebuilding forty structs on each of those is the
/// difference between a theme switch that is instant and one a buyer can see.
global.lvy_corpus_cache = undefined;

function lvy_corpus() {
    if (!is_undefined(global.lvy_corpus_cache)) return global.lvy_corpus_cache;
    var _c = [
        // ── METAL (8) ─────────────────────────────────────────────────────────────────────────
        // Worked surfaces. Wide ramps, because metal is the only family that genuinely specular.
        lvy_mat("iron",      "Blackened Iron", "metal", 0.30, 0.012,  38, 0.44, -0.10, 0.46,  6, 0.030, LVY_CH_PIT,     7.0, 0.055, LVY_CN_SQUARE,  LVY_FN_STUD,    1.30),
        lvy_mat("brass",     "Brass",          "metal", 0.62, 0.092,  84, 0.50, -0.14, -0.44, -8, 0.130, LVY_CH_BRUSH,  10.0, 0.028, LVY_CN_CHAMFER, LVY_FN_STUD,    1.10),
        lvy_mat("pewter",    "Pewter",         "metal", 0.58, 0.011, 250, 0.40, -0.10, -0.40, 14, 0.040, LVY_CH_HATCH,   9.0, 0.024, LVY_CN_ROUND,   LVY_FN_FILLET,  1.00),
        lvy_mat("verdigris", "Verdigris",      "metal", 0.54, 0.062, 168, 0.38, -0.12, -0.40, -22, 0.098, LVY_CH_SPECKLE, 8.0, 0.046, LVY_CN_CHAMFER, LVY_FN_BRACKET, 1.20),
        lvy_mat("steel",     "Brushed Steel",  "metal", 0.66, 0.007, 232, 0.46, -0.12, -0.46, 18, 0.038, LVY_CH_BRUSH,  11.0, 0.020, LVY_CN_SQUARE,  LVY_FN_CAP,     0.90),
        lvy_mat("gilt",      "Gold Leaf",      "metal", 0.72, 0.112,  92, 0.52, -0.20, -0.52, -6, 0.150, LVY_CH_HATCH,   7.0, 0.026, LVY_CN_COVE,    LVY_FN_FILLET,  1.15),
        lvy_mat("bronze",    "Bronze",         "metal", 0.48, 0.080,  62, 0.46, -0.10, 0.40, -10, 0.115, LVY_CH_PIT,     6.0, 0.048, LVY_CN_CHAMFER, LVY_FN_STUD,    1.25),
        lvy_mat("gunmetal",  "Gunmetal",       "metal", 0.38, 0.010, 268, 0.42, -0.08, 0.44, 12, 0.052, LVY_CH_KNURL,   8.0, 0.030, LVY_CN_SQUARE,  LVY_FN_CAP,     1.05),

        // ── ORGANIC (7) ───────────────────────────────────────────────────────────────────────
        // Grown surfaces. Warm hues, modest chroma, and grain that runs one way.
        lvy_mat("parchment", "Parchment",      "organic", 0.80, 0.034,  76, 0.30, 0.02, -0.50,  10, 0.070, LVY_CH_FLECK,   9.0, 0.026, LVY_CN_ROUND,   LVY_FN_NONE,    0.80),
        lvy_mat("bone",      "Bone",           "organic", 0.84, 0.016,  84, 0.28, 0.02, -0.52,  -4, 0.048, LVY_CH_CRAZE,  10.0, 0.022, LVY_CN_COVE,    LVY_FN_FILLET,  0.85),
        lvy_mat("horn",      "Horn",           "organic", 0.56, 0.056,  62, 0.42, -0.06, -0.42, -12, 0.092, LVY_CH_VEIN,    5.0, 0.070, LVY_CN_COVE,    LVY_FN_NONE,    0.95),
        lvy_mat("leather",   "Oxblood Leather","organic", 0.34, 0.070,  28, 0.32, -0.04, 0.46, -14, 0.108, LVY_CH_SPECKLE, 9.0, 0.040, LVY_CN_ROUND,   LVY_FN_STITCH,  1.10),
        lvy_mat("oak",       "Oak",            "organic", 0.52, 0.062,  70, 0.36, -0.06, 0.42,  -8, 0.098, LVY_CH_GRAIN,   7.0, 0.062, LVY_CN_SQUARE,  LVY_FN_BRACKET, 1.15),
        lvy_mat("burr",      "Walnut Burr",    "organic", 0.36, 0.068,  52, 0.38, -0.05, 0.48, -10, 0.104, LVY_CH_VEIN,    6.0, 0.078, LVY_CN_COVE,    LVY_FN_FILLET,  1.05),
        lvy_mat("cork",      "Cork",           "organic", 0.66, 0.058,  68, 0.26, -0.04, -0.44,   8, 0.086, LVY_CH_FLECK,  10.0, 0.044, LVY_CN_ROUND,   LVY_FN_NONE,    0.85),

        // ── MINERAL (6) ───────────────────────────────────────────────────────────────────────
        // Cut surfaces. Heavy chamfers, cool hues, and veins or speckle rather than grain.
        lvy_mat("slate",     "Slate",          "mineral", 0.32, 0.006, 244, 0.34, -0.06, 0.50,  16, 0.034, LVY_CH_HATCH,   6.0, 0.038, LVY_CN_CHAMFER, LVY_FN_NONE,    1.25),
        lvy_mat("marble",    "Marble",         "mineral", 0.86, 0.008,  96, 0.30, 0.02, -0.54,  -8, 0.042, LVY_CH_VEIN,    4.0, 0.086, LVY_CN_CHAMFER, LVY_FN_FILLET,  1.00),
        lvy_mat("obsidian",  "Obsidian",       "mineral", 0.22, 0.018, 292, 0.40, -0.06, 0.54,   6, 0.078, LVY_CH_NONE,    0.0, 0.000, LVY_CN_CHAMFER, LVY_FN_CAP,     1.20),
        lvy_mat("jade",      "Jade",           "mineral", 0.58, 0.074, 156, 0.36, -0.08, -0.44, -18, 0.112, LVY_CH_VEIN,    5.0, 0.068, LVY_CN_COVE,    LVY_FN_FILLET,  1.05),
        lvy_mat("sandstone", "Sandstone",      "mineral", 0.72, 0.048,  72, 0.28, -0.04, -0.46,  10, 0.076, LVY_CH_SPECKLE,10.0, 0.036, LVY_CN_SQUARE,  LVY_FN_BRACKET, 1.20),
        lvy_mat("malachite", "Malachite",      "mineral", 0.44, 0.098, 162, 0.42, -0.08, 0.46, -20, 0.140, LVY_CH_VEIN,    6.0, 0.082, LVY_CN_CHAMFER, LVY_FN_CAP,     1.10),

        // ── MADE (7) ──────────────────────────────────────────────────────────────────────────
        // Moulded and glazed. Smooth or finely crazed, high chroma, soft corners.
        lvy_mat("lacquer",   "Vermilion Lacquer","made", 0.42, 0.140,  32, 0.48, -0.06, 0.52, -12, 0.170, LVY_CH_NONE,    0.0, 0.000, LVY_CN_COVE,    LVY_FN_FILLET,  0.95),
        lvy_mat("enamel",    "Enamel",         "made", 0.68, 0.104, 226, 0.44, -0.08, -0.46,  16, 0.145, LVY_CH_NONE,    0.0, 0.000, LVY_CN_PILL,    LVY_FN_NONE,    0.85),
        lvy_mat("porcelain", "Porcelain",      "made", 0.90, 0.014, 232, 0.32, 0.02, -0.56,  10, 0.062, LVY_CH_CRAZE,  11.0, 0.018, LVY_CN_COVE,    LVY_FN_FILLET,  0.80),
        lvy_mat("bakelite",  "Bakelite",       "made", 0.30, 0.052,  46, 0.34, -0.04, 0.50, -10, 0.086, LVY_CH_NONE,    0.0, 0.000, LVY_CN_ROUND,   LVY_FN_CAP,     1.00),
        lvy_mat("glass",     "Smoked Glass",   "made", 0.46, 0.030, 208, 0.50, -0.10, -0.48,  14, 0.078, LVY_CH_NONE,    0.0, 0.000, LVY_CN_PILL,    LVY_FN_NONE,    0.70),
        lvy_mat("resin",     "Amber Resin",    "made", 0.64, 0.118,  74, 0.46, -0.06, 0.46,  -8, 0.152, LVY_CH_FLECK,   8.0, 0.034, LVY_CN_PILL,    LVY_FN_NONE,    0.80),
        lvy_mat("celluloid", "Celluloid",      "made", 0.76, 0.070, 118, 0.38, -0.04, -0.48, -14, 0.108, LVY_CH_CRAZE,   9.0, 0.020, LVY_CN_ROUND,   LVY_FN_FILLET,  0.85),

        // ── TEXTILE (5) ───────────────────────────────────────────────────────────────────────
        // ⛔ VERY LOW SPREAD, AND THAT IS THE POINT. Cloth is the one family with no specular
        // highlight at all, so a wide ramp on felt reads as plastic. The bevel still works because
        // Oklab spacing keeps five stops distinct across a range this narrow; in HSV they would
        // collapse.
        lvy_mat("felt",      "Felt",           "textile", 0.36, 0.048, 348, 0.22, -0.03, 0.50, -16, 0.072, LVY_CH_SPECKLE,11.0, 0.020, LVY_CN_ROUND,   LVY_FN_STITCH,  0.90),
        lvy_mat("linen",     "Linen",          "textile", 0.78, 0.026,  84, 0.20, 0.02, -0.50,  12, 0.052, LVY_CH_WEAVE,   9.0, 0.024, LVY_CN_SQUARE,  LVY_FN_STITCH,  0.85),
        lvy_mat("velvet",    "Velvet",         "textile", 0.26, 0.076, 302, 0.24, -0.03, 0.54, -18, 0.104, LVY_CH_BRUSH,  10.0, 0.026, LVY_CN_ROUND,   LVY_FN_NONE,    0.95),
        lvy_mat("canvas",    "Canvas",         "textile", 0.70, 0.032,  78, 0.22, -0.02, -0.46,  14, 0.058, LVY_CH_WEAVE,  10.0, 0.028, LVY_CN_SQUARE,  LVY_FN_STITCH,  1.00),
        lvy_mat("brocade",   "Brocade",        "textile", 0.44, 0.088,  16, 0.26, -0.04, 0.48, -12, 0.126, LVY_CH_KNURL,   8.0, 0.032, LVY_CN_COVE,    LVY_FN_STITCH,  1.05),

        // ── TECHNICAL (7) ─────────────────────────────────────────────────────────────────────
        // Emissive accents and orthogonal geometry. The accent chroma is the highest in the corpus
        // because these are the only materials whose accent is meant to look like it EMITS.
        lvy_mat("circuit",   "Circuit Board",  "technical", 0.34, 0.056, 154, 0.36, -0.06, 0.52, -30, 0.168, LVY_CH_TRACE,   6.0, 0.042, LVY_CN_STEP, LVY_FN_CAP,     1.00),
        lvy_mat("cathode",   "Cathode",        "technical", 0.24, 0.048, 148, 0.38, -0.05, 0.56, -18, 0.180, LVY_CH_SCANLINE,10.0, 0.024, LVY_CN_STEP, LVY_FN_NONE,    0.75),
        lvy_mat("plasma",    "Plasma",         "technical", 0.30, 0.092, 316, 0.42, -0.06, 0.54, -24, 0.186, LVY_CH_SCANLINE, 9.0, 0.028, LVY_CN_PILL, LVY_FN_NONE,    0.80),
        lvy_mat("holo",      "Holographic",    "technical", 0.60, 0.086, 268, 0.44, -0.10, -0.48, -40, 0.176, LVY_CH_SCANLINE,11.0, 0.020, LVY_CN_STEP, LVY_FN_CAP,     0.70),
        lvy_mat("carbon",    "Carbon Fibre",   "technical", 0.26, 0.008, 262, 0.36, -0.04, 0.54,  20, 0.062, LVY_CH_WEAVE,   8.0, 0.030, LVY_CN_STEP, LVY_FN_CAP,     1.10),
        lvy_mat("anodised",  "Anodised",       "technical", 0.52, 0.088, 246, 0.44, -0.08, -0.44, -26, 0.150, LVY_CH_BRUSH,  11.0, 0.018, LVY_CN_CHAMFER, LVY_FN_CAP,  0.90),
        lvy_mat("phosphor",  "Phosphor",       "technical", 0.28, 0.040,  96, 0.36, -0.05, 0.56, -12, 0.184, LVY_CH_SCANLINE,10.0, 0.026, LVY_CN_SQUARE, LVY_FN_NONE,   0.75)
    ];
    global.lvy_corpus_cache = _c;
    return _c;
}

/// How many materials the corpus carries. Derived, never typed - the store page quotes this.
function lvy_corpus_count() {
    return array_length(lvy_corpus());
}

/// A material by id, or undefined.
function lvy_material_get(_id) {
    var _c = lvy_corpus();
    for (var _i = 0; _i < array_length(_c); _i++) {
        if (_c[_i].id == _id) return _c[_i];
    }
    return undefined;
}

/// A material by index, wrapping. Used by the bake sheets and the demo's cycle key.
function lvy_material_at(_i) {
    var _c = lvy_corpus();
    var _n = array_length(_c);
    return _c[((_i % _n) + _n) % _n];
}

/// Every distinct family in the corpus, in first-appearance order.
function lvy_families() {
    var _c = lvy_corpus();
    var _seen = {};
    var _out = [];
    for (var _i = 0; _i < array_length(_c); _i++) {
        var _f = _c[_i].family;
        if (!variable_struct_exists(_seen, _f)) {
            variable_struct_set(_seen, _f, true);
            array_push(_out, _f);
        }
    }
    return _out;
}

/// ============================================================================================
/// RESOLUTION - a material plus a state becomes a SURFACE, which is what the renderer consumes
/// ============================================================================================

/// The surface struct for a material in a state.
///
/// ⚠️ THE RETURNED STRUCT IS THE RENDERER'S PALETTE and its keys are ROLES, not colour names. That
/// indirection is what lets one component builder draw forty materials: lvy_control asks for "m3"
/// and never for "light brass".
///
/// Roles carried:
///   m0..m4   the five ramp stops, deepest to brightest - what lvy_relief shades bevels with
///   ground   the flat field the component sits on
///   ink      text and hairlines, guaranteed LVY_INK_MIN_CONTRAST from ground
///   accent   the material's own highlight - selection, focus, a gauge's fill
///   accentInk a colour readable ON the accent (a badge's number, a pressed tab's label)
///   line     the fallback the renderer uses on an unknown role. Deliberately loud.
///   panel    alias of m2, for the shared relief layer's lvy_ui_panel default
///   felt     alias of m1, for the shared relief layer's lvy_ui_well default
function lvy_surface(_mat, _state) {
    var _st = is_undefined(_state) ? LVY_ST_IDLE : _state;
    var _d = lvy_state_delta(_st);

    var _stops = lvy_ramp_stops(_mat.L + _d.dL, _mat.spread * _d.spreadK);
    var _out = {};

    for (var _i = 0; _i < LVY_RAMP_N; _i++) {
        var _t = _i / (LVY_RAMP_N - 1);
        var _C = lvy_pull(lvy_ramp_chroma(_mat.C, _t), _d.Ctarget * lvy_ramp_chroma(1.0, _t), _d.Ck);
        variable_struct_set(_out, "m" + string(_i), lvy_oklch(_stops[_i], _C, _mat.h));
    }

    // GROUND. Offset from the material's own base lightness, then moved by the state like the ramp,
    // so a disabled component's field dims with its bevel instead of staying bright underneath it.
    var _gL = clamp(_mat.L + _mat.groundDL + _d.dL, LVY_L_FLOOR, LVY_L_CEIL);
    var _gC = lvy_pull(_mat.C * 0.55, _d.Ctarget * 0.55, _d.Ck);
    _out.ground = lvy_oklch(_gL, _gC, _mat.h);

    // INK. Defined against the GROUND, never against the ramp - see LVY_INK_MIN_CONTRAST.
    // The sign of inkDL says whether this material takes dark type on a light field or the reverse,
    // and the floor is enforced here rather than trusted to the table.
    var _iL = _gL + _mat.inkDL;
    if (abs(_iL - _gL) < LVY_INK_MIN_CONTRAST) {
        _iL = _gL + (_mat.inkDL < 0 ? -LVY_INK_MIN_CONTRAST : LVY_INK_MIN_CONTRAST);
    }
    // ⛔ SLIDE THE INK, DO NOT CLAMP IT. Clamping an out-of-band ink lands it ON the ground for a
    // very light or very dark material and the text disappears - which is the single worst thing
    // this file could do, because a buyer would find it only after shipping.
    if (_iL < LVY_L_FLOOR) _iL = _gL + LVY_INK_MIN_CONTRAST;
    if (_iL > LVY_L_CEIL)  _iL = _gL - LVY_INK_MIN_CONTRAST;
    _out.ink = lvy_oklch(clamp(_iL, LVY_L_FLOOR, LVY_L_CEIL),
                         lvy_pull(_mat.C * 0.40, _d.Ctarget * 0.40, _d.Ck), _mat.h);

    // ACCENT. Hue is the material's own, rotated by a signed amount, so it always belongs to the
    // material. LIGHTNESS is derived from the GROUND, in whichever direction has room.
    //
    // ⛔ IT WAS `_mat.L + 0.14` AND THAT IS THE SAME MISTAKE THE INK BLOCK ABOVE EXISTS TO PREVENT,
    // MADE TWICE IN ONE FILE. MEASURED on the first headless run: marble's accent came out at
    // L 0.90 against a ground of L 0.86 - a four-hundredths separation, which is not an accent, it
    // is a slightly different white. The suite caught it as "disabled ACCENT still reads as live",
    // but the real finding is bigger than the state: marble's accent was invisible in EVERY state,
    // and so were porcelain's and bone's. An always-lighter rule works on the dark two thirds of
    // the corpus and fails silently on the light third.
    //
    // ⭐ The same law as ink, and it is worth stating once for both: A HIGHLIGHT IS DEFINED AGAINST
    // THE SURFACE IT SITS ON, NOT AGAINST THE MATERIAL'S NOMINAL LIGHTNESS. On a light material the
    // accent has to go DOWN.
    var _aBase = (_gL > 0.62) ? (_gL - 0.26) : (_gL + 0.22);
    var _aL = clamp(_aBase, 0.22, 0.88);
    // ⚠️ AND A DISABLED ACCENT CONVERGES ON THE FIELD, driven by the SAME spread term that flattens
    // the ramp rather than by a second constant. A disabled gauge whose fill still glows is telling
    // the player it is live.
    _aL = lvy_pull(_aL, _gL, 1 - _d.spreadK);
    var _aC = lvy_pull(_mat.accentC, _d.Ctarget, _d.Ck);
    var _aH = lvy_pull_hue(_mat.h, _mat.h + _mat.accentDH, 1.0);
    _out.accent = lvy_oklch(_aL, _aC, _aH);
    // Type ON the accent goes to whichever end of the axis is further from it.
    _out.accentInk = lvy_oklch(_aL > 0.58 ? 0.14 : 0.94, _aC * 0.18, _aH);

    // The renderer's fallback role. Kept LOUD on purpose: a component asking for a role the surface
    // does not carry should be visible in the bake, not blended away.
    _out.line = _out.ink;

    // Aliases the shared relief layer's UI helpers default to.
    _out.panel = _out.m2;
    _out.felt  = _out.m1;

    return _out;
}

/// The bevel depth multiplier and cap inset for a state. Pulled out so lvy_control does not have to
/// know the shape of the delta struct.
function lvy_state_bevel(_state) { return lvy_state_delta(_state).bevel; }
function lvy_state_inset(_state) { return lvy_state_delta(_state).inset; }

/// The five states, in the order the bake sheets and the demo cycle them.
function lvy_states() {
    return [LVY_ST_IDLE, LVY_ST_HOVER, LVY_ST_PRESSED, LVY_ST_DISABLED, LVY_ST_FOCUS];
}
