{
  "$GMScript": "v1",
  "%Name": "lvy_char",
  "name": "lvy_char",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}