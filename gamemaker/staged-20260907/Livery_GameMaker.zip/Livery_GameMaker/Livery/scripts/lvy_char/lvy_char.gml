/// LIVERY - lvy_char. Surface character: the thirteen ways a material's face is worked.
///
/// ⛔ THIS FILE IS WHY FORTY MATERIALS ARE FORTY MATERIALS AND NOT FORTY HUES.
/// Brass and bronze are eleven degrees apart on the hue circle. Slate and gunmetal are twenty-four.
/// Linen and canvas are six. If colour were the only difference, this corpus would be a gradient
/// with names on it, and a buyer would be right to say so. Brass is BRUSHED, bronze is PITTED;
/// slate is HATCHED, gunmetal is KNURLED; linen and canvas are both WOVEN and differ in the weave's
/// pitch and depth. That is a difference in what the surface IS, and it survives being seen small,
/// desaturated, or in a screenshot on a phone.
///
/// -- THE LAW THIS FILE IS WRITTEN UNDER ------------------------------------------------------
/// ⛔ TONE IS COUNT AND LENGTH. IT IS NOT LINE WIDTH.
/// lvy_render floors every stroke at 1.0 physical pixel because draw_line_width lays down an
/// unantialiased quad and a 0.55px stroke rasterises to a row of dashes. So no character here ramps
/// its strength by getting thinner - they ramp it by drawing FEWER strokes or SHORTER ones. This
/// wing has paid for that law three separate times and it is in Wings/GameMaker/CLAUDE.md.
///
/// ⛔ AND NEVER RAMP DENSITY WITH A CUTOFF. `if (shade < 0.24) continue` puts a hard visible edge
/// across the surface. Where a character needs to fade, its DISTRIBUTION is warped instead.
///
/// -- SIZE HONESTY ----------------------------------------------------------------------------
/// ⛔ EVERY CHARACTER TAKES ITS PITCH FROM lvy_char_spacing AND NONE OF THEM COMPUTES ITS OWN.
/// The pitch is a PHYSICAL constant per material, not a proportion of the component - see that
/// function for the receipt, which is a hero sheet on which gold leaf's fine engraving rendered as
/// eighty-pixel hazard stripes. A 400x40 progress bar and an 840x560 frame get the same grain,
/// because that is what one material means.
///
/// lvy_material bounds density above by lvy_char_max_density() so no row of the corpus can declare
/// a character that rasterises to a flat block at LVY_MIN_COMPONENT_PX, and lvy_selftest asserts
/// that bound on all forty rows.
///
/// -- CONTAINMENT -----------------------------------------------------------------------------
/// ⛔ EVERY MARK IS CLIPPED, ANALYTICALLY, TO THE RECT IT BELONGS TO.
/// The wing constitution records a public draw call that took a rect and drew hundreds of pixels
/// outside it, on a product where nothing mechanical could see it. Character is the highest-risk
/// shape for that here - a vein wanders, a craze branches, a trace turns corners - so every one of
/// them goes through lvy_clip_seg rather than trusting its own arithmetic, and lvy_selftest asserts
/// containment on all thirteen against three rects of different aspect.
///
/// -- DETERMINISM -----------------------------------------------------------------------------
/// ⛔ NOTHING HERE CALLS random(). Every character is seeded from the material id and the rect, so a
/// button redrawn on frame 2 is byte-identical to the same button on frame 1. A surface that
/// re-jitters every frame is the one defect a buyer notices immediately and cannot work around.
/// ============================================================================================

/// A stroke that is guaranteed to stay inside the rect, or nothing at all.
///
/// Returns a part or `undefined`. ⚠️ CALLERS MUST CHECK - lvy_append accepts a single part but not
/// an undefined one, and a segment entirely outside the rect legitimately produces nothing.
function lvy_char_seg(_x0, _y0, _x1, _y1, _rx0, _ry0, _rx1, _ry1, _w, _role) {
    var _c = lvy_clip_seg(_x0, _y0, _x1, _y1, _rx0, _ry0, _rx1, _ry1);
    if (is_undefined(_c)) return undefined;
    return lvy_poly([_c[0], _c[1]], false, _w, _role);
}

/// Push a clipped stroke onto a part list if it survived clipping.
function lvy_char_push(_dst, _x0, _y0, _x1, _y1, _rx0, _ry0, _rx1, _ry1, _w, _role) {
    var _p = lvy_char_seg(_x0, _y0, _x1, _y1, _rx0, _ry0, _rx1, _ry1, _w, _role);
    if (!is_undefined(_p)) array_push(_dst, _p);
    return _dst;
}

/// The stroke weight character is drawn at, in pixels.
///
/// One physical pixel, always. See the header: weight is not the variable. What varies between a
/// faint brush and a deep pit is HOW MANY strokes there are and which ramp stop they use.
#macro LVY_CHAR_W 1.0

/// The pixel spacing between a material's character features, on a component of this size.
///
/// ⛔⛔ THIS IS THE SECOND HALF OF THE SAME DEFECT lvy_shape's LVY_CORNER_MAX_PX RECORDS, AND THE
/// HERO SHEET SHOWED BOTH IN ONE LOOK. The first version was `min(w,h) / density`, which makes the
/// pitch PROPORTIONAL to the component - so gold leaf's hatch, authored as a fine engraving at
/// seven strokes across a 24px control, came out as 80-PIXEL DIAGONAL STRIPES on an 840x560 frame.
/// It read as hazard tape. Slate, brocade, gunmetal and every scanline material did the same.
///
/// ⭐ A MATERIAL'S GRAIN DOES NOT GET COARSER ON A BIGGER OBJECT. Oak is oak on a jewellery box and
/// on a door. The pitch is therefore a PHYSICAL constant derived from the material's own density -
/// `LVY_MIN_COMPONENT_PX / density`, which is the pitch that density was defined to mean - and the
/// proportional term survives only as an upper bound, so a component smaller than the reference
/// still gets a proportionally finer pitch instead of two enormous strokes.
///
/// ⚠️ THE COST IS REAL AND IT IS THE RIGHT COST. A fine pitch on a large frame is hundreds of
/// strokes rather than a dozen. That is what a fine hatch IS, it is why lvy_widget caches, and it
/// is why the cache is documented as the normal path rather than an optimisation.
function lvy_char_spacing(_mat, _w, _h) {
    if (_mat.density <= 0) return 0;
    var _physical = LVY_MIN_COMPONENT_PX / _mat.density;
    var _fit = min(_w, _h) / _mat.density;
    return max(LVY_CHAR_MIN_SPACING_PX, min(_physical, _fit));
}

/// The two ramp roles a character alternates between, chosen from the material's amplitude.
///
/// ⚠️ A CHARACTER IS A TWO-SIDED MARK, not a dark line on a light field. A scratch in metal has a
/// lit wall and a shadowed one, and drawing only the dark half is what makes procedural texture
/// read as dirt. The pair widens with amplitude: a faint brush is m2/m3, a deep pit is m0/m4.
function lvy_char_roles(_amp) {
    if (_amp >= 0.060) return ["m0", "m4"];
    if (_amp >= 0.040) return ["m1", "m4"];
    if (_amp >= 0.026) return ["m1", "m3"];
    return ["m2", "m3"];
}

/// ============================================================================================
/// THE THIRTEEN
///
/// Every one takes the same arguments and returns a part list in PIXEL space:
///   _x0.._y1  the rect to fill
///   _mat      the material row (for density, amp, hue-independent behaviour)
///   _seed     an integer; the same seed and rect always give the same marks
/// ============================================================================================

/// GRAIN - long wavering parallel strokes along the LONG axis. Wood.
///
/// The waver is a sum of two sines at incommensurable rates rather than a per-point jitter: grain
/// is a smooth thing and per-point noise reads as static. Each stroke is sampled, not drawn as one
/// segment, because a straight line is not grain.
function lvy_char_grain(_x0, _y0, _x1, _y1, _mat, _seed) {
    var _out = [];
    var _w = _x1 - _x0, _h = _y1 - _y0;
    var _horiz = (_w >= _h);
    var _short = min(_w, _h);
    var _sp = lvy_char_spacing(_mat, _w, _h);
    var _r = lvy_char_roles(_mat.amp);
    var _rng = lvy_rng(_seed);
    var _n = max(1, floor(_short / _sp));
    var _amp = _sp * _mat.amp * 9.0;

    for (var _i = 0; _i < _n; _i++) {
        var _u = (_i + 0.5) / _n;
        var _base = (_horiz ? _y0 + _u * _h : _x0 + _u * _w);
        var _ph = lvy_rng_next(_rng) * LVY_TAU;
        var _k1 = 1.7 + lvy_rng_next(_rng) * 1.1;
        var _role = _r[(_i % 2)];
        var _segs = 12;
        var _px = 0, _py = 0;
        for (var _s = 0; _s <= _segs; _s++) {
            var _t = _s / _segs;
            var _off = sin(_ph + _t * LVY_TAU * _k1) * _amp + sin(_ph * 2.3 + _t * LVY_TAU * 0.7) * _amp * 0.45;
            var _qx = _horiz ? (_x0 + _t * _w) : (_base + _off);
            var _qy = _horiz ? (_base + _off) : (_y0 + _t * _h);
            if (_s > 0) lvy_char_push(_out, _px, _py, _qx, _qy, _x0, _y0, _x1, _y1, LVY_CHAR_W, _role);
            _px = _qx; _py = _qy;
        }
    }
    return _out;
}

/// HATCH - short straight parallel strokes at a fixed angle. Engraving, slate, gold leaf.
///
/// The angle is 30 degrees off the long axis rather than 45. At exactly 45 on a square component
/// the hatch lines up with the corner diagonals and the whole surface reads as a hazard stripe.
function lvy_char_hatch(_x0, _y0, _x1, _y1, _mat, _seed) {
    var _out = [];
    var _w = _x1 - _x0, _h = _y1 - _y0;
    var _sp = lvy_char_spacing(_mat, _w, _h);
    var _r = lvy_char_roles(_mat.amp);
    var _a = degtorad(30);
    var _dx = cos(_a), _dy = sin(_a);
    // Perpendicular sweep long enough to cross the whole rect from either corner.
    var _span = _w * abs(_dy) + _h * abs(_dx);
    var _n = max(1, floor(_span / _sp));
    var _len = sqrt(_w * _w + _h * _h);
    var _cx = (_x0 + _x1) * 0.5, _cy = (_y0 + _y1) * 0.5;

    for (var _i = 0; _i <= _n; _i++) {
        var _o = (_i - _n * 0.5) * _sp;
        var _mx = _cx + (-_dy) * _o, _my = _cy + _dx * _o;
        var _role = _r[_i % 2];
        lvy_char_push(_out, _mx - _dx * _len, _my - _dy * _len,
                            _mx + _dx * _len, _my + _dy * _len,
                      _x0, _y0, _x1, _y1, LVY_CHAR_W, _role);
    }
    return _out;
}

/// KNURL - crosshatch. Gunmetal, brocade.
///
/// Two hatches at opposed angles, and the SECOND one uses the lit role while the first uses the
/// shadowed one. Drawn in the same role both ways it reads as a grid; drawn in two it reads as a
/// diamond pattern standing proud, which is what knurling looks like.
function lvy_char_knurl(_x0, _y0, _x1, _y1, _mat, _seed) {
    var _out = [];
    var _w = _x1 - _x0, _h = _y1 - _y0;
    var _sp = lvy_char_spacing(_mat, _w, _h);
    var _r = lvy_char_roles(_mat.amp);
    var _len = sqrt(_w * _w + _h * _h);
    var _cx = (_x0 + _x1) * 0.5, _cy = (_y0 + _y1) * 0.5;

    for (var _pass = 0; _pass < 2; _pass++) {
        var _a = degtorad(_pass == 0 ? 34 : -34);
        var _dx = cos(_a), _dy = sin(_a);
        var _span = _w * abs(_dy) + _h * abs(_dx);
        var _n = max(1, floor(_span / _sp));
        for (var _i = 0; _i <= _n; _i++) {
            var _o = (_i - _n * 0.5) * _sp;
            var _mx = _cx + (-_dy) * _o, _my = _cy + _dx * _o;
            lvy_char_push(_out, _mx - _dx * _len, _my - _dy * _len,
                                _mx + _dx * _len, _my + _dy * _len,
                          _x0, _y0, _x1, _y1, LVY_CHAR_W, _r[_pass]);
        }
    }
    return _out;
}

/// CRAZE - fine irregular cracks in a glaze. Porcelain, bone, celluloid.
///
/// Grown as short walks from scattered seeds, each branching once. A crack network drawn as
/// straight chords between random points reads as a cobweb; crazing is short, angular and
/// meandering, and it only branches at shallow angles.
function lvy_char_craze(_x0, _y0, _x1, _y1, _mat, _seed) {
    var _out = [];
    var _w = _x1 - _x0, _h = _y1 - _y0;
    var _sp = lvy_char_spacing(_mat, _w, _h);
    var _r = lvy_char_roles(_mat.amp);
    var _rng = lvy_rng(_seed + 977);
    var _seeds = max(2, floor((_w * _h) / (_sp * _sp * 3.2)));
    var _step = _sp * 0.9;

    for (var _s = 0; _s < _seeds; _s++) {
        var _px = _x0 + lvy_rng_next(_rng) * _w;
        var _py = _y0 + lvy_rng_next(_rng) * _h;
        var _dir = lvy_rng_next(_rng) * LVY_TAU;
        var _len = 3 + floor(lvy_rng_next(_rng) * 4);
        var _bx = 0, _by = 0, _bd = 0, _bat = floor(_len * 0.5);
        for (var _k = 0; _k < _len; _k++) {
            _dir += (lvy_rng_next(_rng) - 0.5) * 1.15;
            var _qx = _px + cos(_dir) * _step;
            var _qy = _py + sin(_dir) * _step;
            lvy_char_push(_out, _px, _py, _qx, _qy, _x0, _y0, _x1, _y1, LVY_CHAR_W,
                          _r[(_s + _k) % 2]);
            if (_k == _bat) { _bx = _qx; _by = _qy; _bd = _dir; }
            _px = _qx; _py = _qy;
        }
        // One branch, at a shallow angle. Crazing does not fork at right angles.
        if (_bat > 0) {
            var _d2 = _bd + (lvy_rng_next(_rng) < 0.5 ? -0.85 : 0.85);
            var _cx2 = _bx, _cy2 = _by;
            for (var _k = 0; _k < 3; _k++) {
                _d2 += (lvy_rng_next(_rng) - 0.5) * 0.9;
                var _nx = _cx2 + cos(_d2) * _step;
                var _ny = _cy2 + sin(_d2) * _step;
                lvy_char_push(_out, _cx2, _cy2, _nx, _ny, _x0, _y0, _x1, _y1, LVY_CHAR_W, _r[0]);
                _cx2 = _nx; _cy2 = _ny;
            }
        }
    }
    return _out;
}

/// WEAVE - an over-under grid. Linen, canvas, carbon fibre.
///
/// ⛔ THE OVER-UNDER IS THE WHOLE THING AND A PLAIN GRID IS NOT A WEAVE. Every warp stroke is drawn
/// as a DASHED line whose gaps fall exactly where a weft stroke crosses it, so the weft reads as
/// passing over. Drawn as two continuous sets of lines it is graph paper, which is what procedural
/// cloth almost always looks like.
function lvy_char_weave(_x0, _y0, _x1, _y1, _mat, _seed) {
    var _out = [];
    var _w = _x1 - _x0, _h = _y1 - _y0;
    var _sp = lvy_char_spacing(_mat, _w, _h);
    var _r = lvy_char_roles(_mat.amp);
    var _nx = max(1, floor(_w / _sp));
    var _ny = max(1, floor(_h / _sp));

    // Weft: horizontal, continuous, in the lit role.
    for (var _j = 0; _j <= _ny; _j++) {
        var _yy = _y0 + _j * _sp;
        if (_yy > _y1) break;
        lvy_char_push(_out, _x0, _yy, _x1, _yy, _x0, _y0, _x1, _y1, LVY_CHAR_W, _r[1]);
    }
    // Warp: vertical, BROKEN at every weft crossing, in the shadowed role.
    for (var _i = 0; _i <= _nx; _i++) {
        var _xx = _x0 + _i * _sp;
        if (_xx > _x1) break;
        for (var _j = 0; _j <= _ny; _j++) {
            var _ya = _y0 + _j * _sp + _sp * 0.30;
            var _yb = _y0 + (_j + 1) * _sp - _sp * 0.30;
            if (_ya >= _y1) break;
            lvy_char_push(_out, _xx, _ya, _xx, min(_yb, _y1), _x0, _y0, _x1, _y1, LVY_CHAR_W, _r[0]);
        }
    }
    return _out;
}

/// TRACE - orthogonal conductor paths with vias. Circuit board.
///
/// Manhattan routing with a single 45-degree mitre at each turn, which is how a real board is
/// routed and is instantly recognisable. Vias are dots at the ends, in the lit role.
function lvy_char_trace(_x0, _y0, _x1, _y1, _mat, _seed) {
    var _out = [];
    var _w = _x1 - _x0, _h = _y1 - _y0;
    var _sp = lvy_char_spacing(_mat, _w, _h);
    var _r = lvy_char_roles(_mat.amp);
    var _rng = lvy_rng(_seed + 4211);
    var _runs = max(2, floor((_w + _h) / (_sp * 2.6)));

    for (var _t = 0; _t < _runs; _t++) {
        var _px = _x0 + floor(lvy_rng_next(_rng) * max(1, _w / _sp)) * _sp;
        var _py = _y0 + floor(lvy_rng_next(_rng) * max(1, _h / _sp)) * _sp;
        var _horiz = lvy_rng_next(_rng) < 0.5;
        var _legs = 2 + floor(lvy_rng_next(_rng) * 3);
        var _sx = _px, _sy = _py;
        for (var _k = 0; _k < _legs; _k++) {
            var _run = (1 + floor(lvy_rng_next(_rng) * 3)) * _sp;
            var _sgn = lvy_rng_next(_rng) < 0.5 ? -1 : 1;
            var _qx = _horiz ? _px + _run * _sgn : _px;
            var _qy = _horiz ? _py : _py + _run * _sgn;
            lvy_char_push(_out, _px, _py, _qx, _qy, _x0, _y0, _x1, _y1, LVY_CHAR_W, _r[1]);
            _px = _qx; _py = _qy;
            _horiz = !_horiz;
        }
        // Vias at both ends of the run.
        //
        // ⛔ THE TEST IS ON THE DISC, NOT ON ITS CENTRE, AND THE FIRST VERSION TESTED THE CENTRE.
        // MEASURED on this product's first headless run: circuit was the ONLY material of forty to
        // fail containment, escaping its rect by 6.7px on one aspect and 1.7px on two others - a
        // via whose centre sat exactly on the edge, drawn at its full radius. In a buyer's game
        // that paints over whatever sits beside the widget.
        //
        // ⭐ It is the same shape as the wing's standing law about a stroke not being the segment
        // between its anchors: A MARK IS NOT ITS ANCHOR POINT, and any containment check written
        // against the anchor is checking the wrong object. lvy_char_seg gets this right for every
        // stroke because it clips the geometry; the two dots were the only marks in this file that
        // bypassed it, which is exactly why they were the two that failed.
        var _vr = max(1.0, _sp * 0.20);
        if (_sx - _vr >= _x0 && _sx + _vr <= _x1 && _sy - _vr >= _y0 && _sy + _vr <= _y1) {
            array_push(_out, lvy_dot(_sx, _sy, _vr, _r[1]));
        }
        if (_px - _vr >= _x0 && _px + _vr <= _x1 && _py - _vr >= _y0 && _py + _vr <= _y1) {
            array_push(_out, lvy_dot(_px, _py, _vr, _r[0]));
        }
    }
    return _out;
}

/// SPECKLE - scattered short marks. Sandstone, verdigris, felt, leather.
///
/// ⚠️ POISSON-ISH, NOT UNIFORM. Points drawn uniformly at random CLUMP, visibly, and a clumped
/// speckle reads as dirt rather than as a material. Each mark is placed in its own cell of a jittered
/// grid, which costs nothing and looks like stone.
function lvy_char_speckle(_x0, _y0, _x1, _y1, _mat, _seed) {
    var _out = [];
    var _w = _x1 - _x0, _h = _y1 - _y0;
    var _sp = lvy_char_spacing(_mat, _w, _h);
    var _r = lvy_char_roles(_mat.amp);
    var _rng = lvy_rng(_seed + 1319);
    var _nx = max(1, floor(_w / _sp));
    var _ny = max(1, floor(_h / _sp));
    var _len = _sp * 0.44;

    for (var _j = 0; _j < _ny; _j++) {
        for (var _i = 0; _i < _nx; _i++) {
            var _cx = _x0 + (_i + 0.15 + lvy_rng_next(_rng) * 0.70) * _sp;
            var _cy = _y0 + (_j + 0.15 + lvy_rng_next(_rng) * 0.70) * _sp;
            var _a = lvy_rng_next(_rng) * pi;
            var _role = _r[(_i + _j) % 2];
            lvy_char_push(_out, _cx - cos(_a) * _len * 0.5, _cy - sin(_a) * _len * 0.5,
                                _cx + cos(_a) * _len * 0.5, _cy + sin(_a) * _len * 0.5,
                          _x0, _y0, _x1, _y1, LVY_CHAR_W, _role);
        }
    }
    return _out;
}

/// VEIN - meandering bands. Marble, jade, malachite, horn, walnut burr.
///
/// ⛔ A VEIN IS A BAND, NOT A LINE, AND THAT IS WHY IT NEEDS TWO STROKES. A single meandering
/// stroke reads as a crack. A vein is a region of different mineral, so it is drawn as a pair of
/// near-parallel walls - the shadowed one and the lit one - which is what makes marble read as
/// marble and not as a broken plate.
function lvy_char_vein(_x0, _y0, _x1, _y1, _mat, _seed) {
    var _out = [];
    var _w = _x1 - _x0, _h = _y1 - _y0;
    var _short = min(_w, _h);
    var _sp = lvy_char_spacing(_mat, _w, _h);
    var _r = lvy_char_roles(_mat.amp);
    var _rng = lvy_rng(_seed + 733);
    var _n = max(1, floor(_mat.density * 0.5));
    var _half = max(0.9, _sp * 0.32);
    var _amp = _short * _mat.amp * 2.4;
    var _horiz = (_w >= _h);

    for (var _v = 0; _v < _n; _v++) {
        var _u = (_v + 0.5) / _n;
        var _base = _horiz ? (_y0 + _u * _h) : (_x0 + _u * _w);
        var _ph = lvy_rng_next(_rng) * LVY_TAU;
        var _k1 = 0.9 + lvy_rng_next(_rng) * 1.3;
        var _tilt = (lvy_rng_next(_rng) - 0.5) * 0.55;
        var _segs = 14;
        var _ax = 0, _ay = 0, _bx = 0, _by = 0;
        for (var _s = 0; _s <= _segs; _s++) {
            var _t = _s / _segs;
            var _off = sin(_ph + _t * LVY_TAU * _k1) * _amp + (_t - 0.5) * _amp * _tilt * 3.0;
            var _cx = _horiz ? (_x0 + _t * _w) : (_base + _off);
            var _cy = _horiz ? (_base + _off) : (_y0 + _t * _h);
            var _nx2 = _horiz ? 0 : 1;
            var _ny2 = _horiz ? 1 : 0;
            var _qax = _cx - _nx2 * _half, _qay = _cy - _ny2 * _half;
            var _qbx = _cx + _nx2 * _half, _qby = _cy + _ny2 * _half;
            if (_s > 0) {
                lvy_char_push(_out, _ax, _ay, _qax, _qay, _x0, _y0, _x1, _y1, LVY_CHAR_W, _r[0]);
                lvy_char_push(_out, _bx, _by, _qbx, _qby, _x0, _y0, _x1, _y1, LVY_CHAR_W, _r[1]);
            }
            _ax = _qax; _ay = _qay; _bx = _qbx; _by = _qby;
        }
    }
    return _out;
}

/// FLECK - small irregular inclusions. Parchment, cork, amber resin.
///
/// Little three- and four-sided blots rather than dots: a fleck in parchment is a fibre, not a
/// pinhole, and a field of perfect circles is the tell that it was generated.
function lvy_char_fleck(_x0, _y0, _x1, _y1, _mat, _seed) {
    var _out = [];
    var _w = _x1 - _x0, _h = _y1 - _y0;
    var _sp = lvy_char_spacing(_mat, _w, _h);
    var _r = lvy_char_roles(_mat.amp);
    var _rng = lvy_rng(_seed + 6101);
    var _nx = max(1, floor(_w / _sp));
    var _ny = max(1, floor(_h / _sp));

    for (var _j = 0; _j < _ny; _j++) {
        for (var _i = 0; _i < _nx; _i++) {
            // Two thirds of cells are empty. Parchment is mostly clean.
            if (lvy_rng_next(_rng) > 0.34) continue;
            var _cx = _x0 + (_i + 0.2 + lvy_rng_next(_rng) * 0.6) * _sp;
            var _cy = _y0 + (_j + 0.2 + lvy_rng_next(_rng) * 0.6) * _sp;
            var _rr = _sp * (0.16 + lvy_rng_next(_rng) * 0.20);
            var _sides = 3 + floor(lvy_rng_next(_rng) * 2);
            var _ph = lvy_rng_next(_rng) * LVY_TAU;
            var _pts = array_create(_sides);
            var _inside = true;
            for (var _k = 0; _k < _sides; _k++) {
                var _a = _ph + (_k / _sides) * LVY_TAU;
                var _px = _cx + cos(_a) * _rr, _py = _cy + sin(_a) * _rr;
                if (_px < _x0 || _px > _x1 || _py < _y0 || _py > _y1) _inside = false;
                _pts[_k] = [_px, _py];
            }
            // ⚠️ A blot is a FILL and a fill cannot be clipped by lvy_clip_seg, which works on
            // segments. Rather than clip it wrongly, a blot that would cross the edge is simply
            // not drawn - there are hundreds of them and one missing at the margin is invisible.
            if (_inside) array_push(_out, lvy_ring_fill(_pts, _r[(_i + _j) % 2], undefined, undefined));
        }
    }
    return _out;
}

/// SCANLINE - horizontal emissive bands. Cathode, plasma, holographic, phosphor.
///
/// ⚠️ EVERY THIRD LINE IS BRIGHTER, and that triplet is what makes it read as a display rather than
/// as a striped surface. A uniform stripe at any spacing is a textile; the uneven beat is the tell.
function lvy_char_scanline(_x0, _y0, _x1, _y1, _mat, _seed) {
    var _out = [];
    var _h = _y1 - _y0;
    var _sp = lvy_char_spacing(_mat, _x1 - _x0, _h);
    var _r = lvy_char_roles(_mat.amp);
    var _n = max(1, floor(_h / _sp));

    for (var _j = 0; _j <= _n; _j++) {
        var _yy = _y0 + _j * _sp;
        if (_yy > _y1) break;
        lvy_char_push(_out, _x0, _yy, _x1, _yy, _x0, _y0, _x1, _y1, LVY_CHAR_W,
                      (_j % 3 == 0) ? _r[1] : _r[0]);
    }
    return _out;
}

/// BRUSH - fine directional strokes of uneven length. Brushed steel, brass, velvet, anodised.
///
/// ⛔ THE LENGTHS ARE UNEVEN AND THE STROKES ARE BROKEN, and both matter. A brushed finish is many
/// short scratches, not a set of full-width rules; drawn full width it is a scanline, which is a
/// different material in this very corpus.
function lvy_char_brush(_x0, _y0, _x1, _y1, _mat, _seed) {
    var _out = [];
    var _w = _x1 - _x0, _h = _y1 - _y0;
    var _horiz = (_w >= _h);
    var _long = max(_w, _h);
    var _sp = lvy_char_spacing(_mat, _w, _h);
    var _r = lvy_char_roles(_mat.amp);
    var _rng = lvy_rng(_seed + 251);
    var _rows = max(1, floor(min(_w, _h) / _sp));

    for (var _j = 0; _j < _rows; _j++) {
        var _base = _horiz ? (_y0 + (_j + 0.5) * _sp) : (_x0 + (_j + 0.5) * _sp);
        var _pos = 0;
        var _guard = 0;
        while (_pos < _long && _guard < 64) {
            _guard++;
            var _run = _long * (0.10 + lvy_rng_next(_rng) * 0.34);
            var _gap = _long * (0.02 + lvy_rng_next(_rng) * 0.07);
            var _a0 = _pos, _a1 = min(_long, _pos + _run);
            var _role = _r[lvy_rng_next(_rng) < 0.5 ? 0 : 1];
            if (_horiz) {
                lvy_char_push(_out, _x0 + _a0, _base, _x0 + _a1, _base,
                              _x0, _y0, _x1, _y1, LVY_CHAR_W, _role);
            } else {
                lvy_char_push(_out, _base, _y0 + _a0, _base, _y0 + _a1,
                              _x0, _y0, _x1, _y1, LVY_CHAR_W, _role);
            }
            _pos = _a1 + _gap;
        }
    }
    return _out;
}

/// PIT - hammered dimples. Blackened iron, bronze.
///
/// Each pit is a two-arc mark, not a circle: the upper-left arc catches the lamp and the lower-right
/// one is in shadow, which is the smallest possible thing that reads as a dent. A ring would read as
/// a bubble and a dot as a rivet - and rivets are elsewhere in this package as actual furniture.
function lvy_char_pit(_x0, _y0, _x1, _y1, _mat, _seed) {
    var _out = [];
    var _w = _x1 - _x0, _h = _y1 - _y0;
    var _sp = lvy_char_spacing(_mat, _w, _h);
    var _r = lvy_char_roles(_mat.amp);
    var _rng = lvy_rng(_seed + 88);
    var _nx = max(1, floor(_w / _sp));
    var _ny = max(1, floor(_h / _sp));
    var _rr = _sp * 0.30;

    for (var _j = 0; _j < _ny; _j++) {
        for (var _i = 0; _i < _nx; _i++) {
            if (lvy_rng_next(_rng) > 0.72) continue;
            var _cx = _x0 + (_i + 0.25 + lvy_rng_next(_rng) * 0.5) * _sp;
            var _cy = _y0 + (_j + 0.25 + lvy_rng_next(_rng) * 0.5) * _sp;
            // ⚠️ THE STROKE WIDTH IS PART OF THE MARK. lvy_render_bounds measures an arc as
            // cx +/- (r + w), so a pit placed with only its radius cleared overhangs by one pixel.
            // Same law as the trace vias above: a mark is not its anchor point.
            var _pr = _rr + LVY_CHAR_W;
            if (_cx - _pr < _x0 || _cx + _pr > _x1 || _cy - _pr < _y0 || _cy + _pr > _y1) continue;
            // The lamp is up-left, so the pit's far (lower-right) wall faces it and is LIT.
            array_push(_out, lvy_arc(_cx, _cy, _rr, degtorad(20), degtorad(160), LVY_CHAR_W, _r[1]));
            array_push(_out, lvy_arc(_cx, _cy, _rr, degtorad(200), degtorad(340), LVY_CHAR_W, _r[0]));
        }
    }
    return _out;
}

/// ============================================================================================
/// THE DISPATCH
/// ============================================================================================

/// Draw a material's surface character into a rect, in pixel space.
///
/// ⚠️ RETURNS AN EMPTY LIST FOR LVY_CH_NONE, AND THAT IS A REAL ANSWER. Lacquer, enamel, glass,
/// bakelite and obsidian have no worked surface - they are smooth, and giving them a texture to
/// "look procedural enough" would be a worse product. Five of forty carry no character and are told
/// apart by hue, ramp spread, corner treatment and furniture instead.
function lvy_char_parts(_mat, _x0, _y0, _x1, _y1, _seed) {
    if (_x1 - _x0 < 2 || _y1 - _y0 < 2) return [];
    var _sd = is_undefined(_seed) ? lvy_hash32(_mat.id) : _seed;
    switch (_mat.character) {
        case LVY_CH_GRAIN:    return lvy_char_grain(_x0, _y0, _x1, _y1, _mat, _sd);
        case LVY_CH_HATCH:    return lvy_char_hatch(_x0, _y0, _x1, _y1, _mat, _sd);
        case LVY_CH_KNURL:    return lvy_char_knurl(_x0, _y0, _x1, _y1, _mat, _sd);
        case LVY_CH_CRAZE:    return lvy_char_craze(_x0, _y0, _x1, _y1, _mat, _sd);
        case LVY_CH_WEAVE:    return lvy_char_weave(_x0, _y0, _x1, _y1, _mat, _sd);
        case LVY_CH_TRACE:    return lvy_char_trace(_x0, _y0, _x1, _y1, _mat, _sd);
        case LVY_CH_SPECKLE:  return lvy_char_speckle(_x0, _y0, _x1, _y1, _mat, _sd);
        case LVY_CH_VEIN:     return lvy_char_vein(_x0, _y0, _x1, _y1, _mat, _sd);
        case LVY_CH_FLECK:    return lvy_char_fleck(_x0, _y0, _x1, _y1, _mat, _sd);
        case LVY_CH_SCANLINE: return lvy_char_scanline(_x0, _y0, _x1, _y1, _mat, _sd);
        case LVY_CH_BRUSH:    return lvy_char_brush(_x0, _y0, _x1, _y1, _mat, _sd);
        case LVY_CH_PIT:      return lvy_char_pit(_x0, _y0, _x1, _y1, _mat, _sd);
        default:              return [];
    }
}

/// Every character id the corpus can use, for the self-test's containment sweep.
///
/// ⭐ IT INCLUDES LVY_CH_NONE DELIBERATELY. A sweep that skipped it would not prove the dispatch
/// returns an empty list rather than falling through to whatever the last case was - which is a
/// real thing that happens when a switch loses a `break`.
function lvy_char_all() {
    return [LVY_CH_NONE, LVY_CH_GRAIN, LVY_CH_HATCH, LVY_CH_KNURL, LVY_CH_CRAZE, LVY_CH_WEAVE,
            LVY_CH_TRACE, LVY_CH_SPECKLE, LVY_CH_VEIN, LVY_CH_FLECK, LVY_CH_SCANLINE,
            LVY_CH_BRUSH, LVY_CH_PIT];
}
