{
  "$GMScript": "v1",
  "%Name": "lvy_geom",
  "name": "lvy_geom",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}