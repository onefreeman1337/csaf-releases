/// LIVERY - lvy_control. The other eight component families.
///
///   button     a pressable cap, in five states
///   toggle     checkbox, radio and switch - three shapes, one family
///   slider     a sunken track with a raised handle
///   gauge      a track with a value fill and tick marks
///   tab        a header-shaped cap that joins the panel below it when active
///   scrollbar  a track, a gripped thumb, and two arrow buttons
///   badge      a small accent-coloured count
///   cursor     four pointers, authored as detached marks
///
/// -- THE FAN PRECONDITION, AND WHY HALF THIS FILE USES RIBBONS --------------------------------
/// ⛔ lvy_render_fill IS pr_trianglefan AND ITS HEADER STATES ITS PRECONDITION: the outline must be
/// STAR-SHAPED ABOUT pts[0]. Hand it a concave shape and it spans the concavity, silently, with no
/// error and no failed assertion. The wing constitution records a product shipping every moon
/// crescent as a quarter for exactly this reason, on a sheet captioned with the correct geometry.
///
/// A check TICK, a CHEVRON, an I-BEAM and an ARROW are all concave or open, so not one of them is a
/// fill: they are ribbons and incised strokes. lvy_selftest asserts that no mark in the cursor and
/// tick corpus emits an LVY_FILL at all, AND that the marks are non-empty - without the second half
/// "no fill" is satisfied by drawing nothing, which is how that assertion passes vacuously.
///
/// -- STATE IS SHAPE, NOT TINT ----------------------------------------------------------------
/// Every state here changes GEOMETRY as well as colour: pressed inverts the bevel and offsets the
/// cap, focus adds a ring, disabled flattens the bevel to 42%. A kit that ships five tints of one
/// button has five pictures of the same object; this has five objects.
/// ============================================================================================

/// ============================================================================================
/// FAMILY 7 - BUTTON
/// ============================================================================================

/// A focus ring: the material's own outline, one bevel outside itself, drawn in the accent.
///
/// ⚠️ OUTSIDE THE COMPONENT, NOT INSIDE IT. A focus ring drawn inside eats the label's space and
/// changes the button's usable area between states, which is a layout bug a buyer inherits.
function lvy_focus_ring(_mat, _x0, _y0, _x1, _y1) {
    var _g = max(2.0, min(_x1 - _x0, _y1 - _y0) * 0.06);
    var _pts = lvy_shape_of(_mat, _x0 - _g, _y0 - _g, _x1 + _g, _y1 + _g, 1.0);
    return lvy_poly(_pts, true, max(1.5, _g * 0.55), "accent");
}

/// A pressable cap.
function lvy_button(_mat, _x0, _y0, _x1, _y1, _state) {
    var _st = is_undefined(_state) ? LVY_ST_IDLE : _state;
    var _out = [];
    if (_st == LVY_ST_FOCUS) array_push(_out, lvy_focus_ring(_mat, _x0, _y0, _x1, _y1));

    var _o = lvy_press_offset(_st, min(_x1 - _x0, _y1 - _y0));
    var _body = lvy_body_rect(_mat, _x0 + _o[0], _y0 + _o[1], _x1 + _o[0], _y1 + _o[1],
                              _st, false, LVY_BEV_CONTROL, lvy_hash32(_mat.id + "btn"), 1.0);
    lvy_append(_out, _body);
    return _out;
}

/// ============================================================================================
/// FAMILY 8 - TOGGLE
/// ============================================================================================

/// A check tick, as a two-segment RIBBON in the unit box.
///
/// ⛔ NOT A FILL. A tick is an L rotated - concave about every interior point - so a fan would span
/// the corner and draw a filled triangle. It is also drawn with a taper, because a tick made with a
/// pen is thin at the short arm and thick at the long one, and a constant-width tick reads as a
/// symbol rather than as a mark.
function lvy_mark_tick() {
    var _pts = [[-0.30, 0.02], [-0.08, 0.26], [0.32, -0.28]];
    return [lvy_taper_ribbon(_pts, 0.055, 0.085, "accent")];
}

/// A chevron, for a combo box or a scrollbar arrow. Also a ribbon, same reason.
function lvy_mark_chevron(_dir) {
    var _d = is_undefined(_dir) ? 2 : (_dir % 4);
    var _pts;
    switch (_d) {
        case 0:  _pts = [[-0.26, 0.13], [0, -0.13], [0.26, 0.13]]; break;
        case 1:  _pts = [[-0.13, -0.26], [0.13, 0], [-0.13, 0.26]]; break;
        case 3:  _pts = [[0.13, -0.26], [-0.13, 0], [0.13, 0.26]]; break;
        default: _pts = [[-0.26, -0.13], [0, 0.13], [0.26, -0.13]]; break;
    }
    return [lvy_ribbon(_pts, 0.055, "ink")];
}

/// A checkbox: a sunken well with a tick when on.
function lvy_toggle_check(_mat, _x0, _y0, _x1, _y1, _on, _state) {
    var _st = is_undefined(_state) ? LVY_ST_IDLE : _state;
    var _out = [];
    if (_st == LVY_ST_FOCUS) array_push(_out, lvy_focus_ring(_mat, _x0, _y0, _x1, _y1));
    lvy_append(_out, lvy_body_rect(_mat, _x0, _y0, _x1, _y1, _st, true, LVY_BEV_SMALL,
                                   lvy_hash32(_mat.id + "chk"), 0.6));
    if (_on) {
        var _s = min(_x1 - _x0, _y1 - _y0);
        lvy_append(_out, lvy_place(lvy_mark_tick(), (_x0 + _x1) * 0.5, (_y0 + _y1) * 0.5,
                                   _s * 0.92, 0, _s * 0.92, undefined));
    }
    return _out;
}

/// A radio button: a circular sunken well with a raised bead when on.
///
/// ⚠️ CIRCULAR WHATEVER THE MATERIAL'S CORNER TREATMENT IS, and that is deliberate rather than an
/// oversight. A radio is round in every interface convention there is; a coved or stepped radio
/// would be an unfamiliar control, and this product's job is to make a familiar control beautiful,
/// not to make a beautiful control unfamiliar.
function lvy_toggle_radio(_mat, _x0, _y0, _x1, _y1, _on, _state) {
    var _st = is_undefined(_state) ? LVY_ST_IDLE : _state;
    var _out = [];
    if (_st == LVY_ST_FOCUS) array_push(_out, lvy_focus_ring(_mat, _x0, _y0, _x1, _y1));
    var _cx = (_x0 + _x1) * 0.5, _cy = (_y0 + _y1) * 0.5;
    var _r = min(_x1 - _x0, _y1 - _y0) * 0.5;
    var _ring = lvy_ellipse_pts(_cx, _cy, _r, _r, 16);
    var _inv = (lvy_state_bevel(_st) < 0);
    var _b = lvy_bevel_cap(_ring, _r * 0.42 * abs(lvy_state_bevel(_st)));
    lvy_append(_out, _inv ? lvy_raise(_ring, _b, 2, "m2") : lvy_sink(_ring, _b, 2, "m1"));
    if (_on) lvy_append(_out, lvy_map_roles(lvy_boss(_cx, _cy, _r * 0.42, 12), { m3: "accent" }));
    return _out;
}

/// A switch: a pill track with a knob that slides.
function lvy_toggle_switch(_mat, _x0, _y0, _x1, _y1, _on, _state) {
    var _st = is_undefined(_state) ? LVY_ST_IDLE : _state;
    var _out = [];
    if (_st == LVY_ST_FOCUS) array_push(_out, lvy_focus_ring(_mat, _x0, _y0, _x1, _y1));
    var _h = _y1 - _y0;
    var _track = lvy_pts_pill(_x0, _y0, _x1, _y1, undefined);
    lvy_append(_out, lvy_sink(_track, lvy_bevel_cap(_track, _h * 0.20), 2, "m1"));
    // The ON half of the track carries the accent, which is what makes the state readable when the
    // knob is off screen at small sizes.
    if (_on) {
        var _fill = lvy_pts_pill(_x0 + _h * 0.14, _y0 + _h * 0.14, _x1 - _h * 0.14, _y1 - _h * 0.14, undefined);
        array_push(_out, lvy_ring_fill(_fill, "accent", undefined, undefined));
    }
    var _kr = _h * 0.40;
    var _kx = _on ? (_x1 - _h * 0.5) : (_x0 + _h * 0.5);
    lvy_append(_out, lvy_boss(_kx, (_y0 + _y1) * 0.5, _kr, 14));
    return _out;
}

/// ============================================================================================
/// FAMILY 9 - SLIDER
/// ============================================================================================

/// Knurl ridges across a handle, so it reads as something a thumb can move.
///
/// COUNT AND LENGTH, never width - lvy_render floors strokes at 1 px and a "fine" ridge drawn
/// thinner would rasterise to dashes.
function lvy_grip(_cx, _cy, _w, _h, _n) {
    var _out = [];
    var _k = max(2, is_undefined(_n) ? 3 : _n);
    for (var _i = 0; _i < _k; _i++) {
        var _x = _cx + (_i - (_k - 1) * 0.5) * (_w / max(1, _k));
        lvy_append(_out, lvy_incise([[_x, _cy - _h * 0.5], [_x, _cy + _h * 0.5]], false,
                                    max(1.0, _w * 0.10)));
    }
    return _out;
}

/// A slider. _t is 0..1.
function lvy_slider(_mat, _x0, _y0, _x1, _y1, _t, _state) {
    var _st = is_undefined(_state) ? LVY_ST_IDLE : _state;
    var _v = clamp(is_undefined(_t) ? 0.5 : _t, 0, 1);
    var _out = [];
    var _h = _y1 - _y0;
    var _cy = (_y0 + _y1) * 0.5;
    var _th = max(4, _h * 0.34);

    // 1. TRACK - sunken, pill-ended whatever the material, because a track is a slot.
    var _tr = lvy_pts_pill(_x0, _cy - _th * 0.5, _x1, _cy + _th * 0.5, undefined);
    lvy_append(_out, lvy_sink(_tr, lvy_bevel_cap(_tr, _th * 0.30), 2, "m1"));

    // 2. FILL - the travelled part of the track, in the accent.
    var _hx = _x0 + (_x1 - _x0) * _v;
    if (_hx > _x0 + _th * 0.6) {
        var _fp = lvy_pts_pill(_x0 + _th * 0.18, _cy - _th * 0.32, _hx, _cy + _th * 0.32, undefined);
        array_push(_out, lvy_ring_fill(_fp, "accent", undefined, undefined));
    }

    // 3. HANDLE - raised, gripped, and it takes the material's own corner treatment.
    var _hw = max(6, _h * 0.34);
    if (_st == LVY_ST_FOCUS) array_push(_out, lvy_focus_ring(_mat, _hx - _hw, _y0, _hx + _hw, _y1));
    var _o = lvy_press_offset(_st, _h);
    lvy_append(_out, lvy_body_rect(_mat, _hx - _hw + _o[0], _y0 + _o[1], _hx + _hw + _o[0], _y1 + _o[1],
                                   _st, false, LVY_BEV_CONTROL, lvy_hash32(_mat.id + "sld"), 0.9));
    lvy_append(_out, lvy_grip(_hx + _o[0], _cy + _o[1], _hw * 0.9, _h * 0.42, 3));
    return _out;
}

/// ============================================================================================
/// FAMILY 10 - GAUGE
/// ============================================================================================

/// A value bar with tick marks. _t is 0..1; _ticks is how many divisions to score into the track.
///
/// ⛔ THE FILL IS CLIPPED TO THE TRACK BY CONSTRUCTION, NOT BY A SCISSOR RECT. It is built as its
/// own pill inside the track's inner rect, so a value of 1.0 cannot run past the track's right
/// end - which is the single most common defect in a hand-rolled progress bar and the one a buyer
/// will hit on their first full health bar.
function lvy_gauge(_mat, _x0, _y0, _x1, _y1, _t, _ticks, _state) {
    var _st = is_undefined(_state) ? LVY_ST_IDLE : _state;
    var _v = clamp(is_undefined(_t) ? 0.5 : _t, 0, 1);
    var _n = is_undefined(_ticks) ? 0 : _ticks;
    var _out = [];
    var _h = _y1 - _y0;

    var _tr = lvy_shape_of(_mat, _x0, _y0, _x1, _y1, 0.8);
    lvy_append(_out, lvy_sink(_tr, lvy_bevel_cap(_tr, _h * LVY_BEV_CONTROL * abs(lvy_state_bevel(_st))), 2, "m1"));

    var _pad = max(2, _h * 0.16);
    var _ix0 = _x0 + _pad, _iy0 = _y0 + _pad, _ix1 = _x1 - _pad, _iy1 = _y1 - _pad;
    if (_ix1 > _ix0 && _iy1 > _iy0 && _v > 0) {
        var _fx = _ix0 + (_ix1 - _ix0) * _v;
        if (_fx > _ix0 + 1) {
            var _fp = lvy_shape_pts(_mat.corner, _ix0, _iy0, _fx, _iy1, _mat.weight, 0.6, undefined);
            array_push(_out, lvy_ring_fill(_fp, "accent", undefined, undefined));
            // A lit edge along the top of the fill, so it reads as a raised bar of light rather
            // than a coloured rectangle.
            lvy_append(_out, [lvy_poly([[_ix0 + 1, _iy0 + 1], [_fx - 1, _iy0 + 1]], false,
                                       max(1.0, _h * 0.06), "m4")]);
        }
    }
    // Tick marks, incised into the track ABOVE the fill so they read as scored into the glass.
    for (var _i = 1; _i < _n; _i++) {
        var _tx = _ix0 + (_ix1 - _ix0) * (_i / _n);
        lvy_append(_out, lvy_incise([[_tx, _iy0], [_tx, _iy1]], false, max(1.0, _h * 0.05)));
    }
    return _out;
}

/// ============================================================================================
/// FAMILY 11 - TAB
/// ============================================================================================

/// A tab. When ACTIVE it loses its lower edge, so it joins the panel below it; when inactive it
/// keeps the edge and sits lower and dimmer.
///
/// ⭐ THE JOIN IS THE WHOLE POINT OF A TAB AND ALMOST NO GENERATED KIT DOES IT. A tab that keeps its
/// bottom border when selected reads as a button that happens to be near a panel. Removing that one
/// edge is what makes it read as the front of a folder.
function lvy_tab(_mat, _x0, _y0, _x1, _y1, _active, _state) {
    var _st = is_undefined(_state) ? LVY_ST_IDLE : _state;
    var _out = [];
    var _drop = _active ? 0 : max(2, (_y1 - _y0) * 0.12);
    lvy_append(_out, lvy_header(_mat, _x0, _y0 + _drop, _x1, _y1 + (_active ? 2 : 0), _st));
    if (_active) {
        // An accent bar along the top edge - the second convention that says "this one".
        var _t = max(2, (_y1 - _y0) * 0.10);
        array_push(_out, lvy_rect_fill(_x0 + 2, _y0 + 1, _x1 - 2, _y0 + 1 + _t, "accent"));
    }
    return _out;
}

/// ============================================================================================
/// FAMILY 12 - SCROLLBAR
/// ============================================================================================

/// A scrollbar. _t is the thumb's position 0..1, _frac is how much of the content is visible 0..1.
///
/// _vertical is measured, not passed, for the same reason lvy_fn_cap measures: a scrollbar builder
/// that assumed vertical would draw a horizontal one on its side.
function lvy_scrollbar(_mat, _x0, _y0, _x1, _y1, _t, _frac, _state) {
    var _st = is_undefined(_state) ? LVY_ST_IDLE : _state;
    var _v = clamp(is_undefined(_t) ? 0.3 : _t, 0, 1);
    var _f = clamp(is_undefined(_frac) ? 0.35 : _frac, 0.05, 1);
    var _out = [];
    var _w = _x1 - _x0, _h = _y1 - _y0;
    var _vert = (_h >= _w);
    var _btn = _vert ? _w : _h;

    // 1. TRACK, the full length, sunken.
    var _tr = lvy_shape_of(_mat, _x0, _y0, _x1, _y1, 0.5);
    lvy_append(_out, lvy_sink(_tr, lvy_bevel_cap(_tr, _btn * 0.18), 2, "m1"));

    // 2. TWO ARROW BUTTONS at the ends.
    var _a0x0 = _x0, _a0y0 = _y0;
    var _a0x1 = _vert ? _x1 : _x0 + _btn;
    var _a0y1 = _vert ? _y0 + _btn : _y1;
    var _a1x0 = _vert ? _x0 : _x1 - _btn;
    var _a1y0 = _vert ? _y1 - _btn : _y0;
    lvy_append(_out, lvy_body_rect(_mat, _a0x0, _a0y0, _a0x1, _a0y1, _st, false, LVY_BEV_SMALL,
                                   lvy_hash32(_mat.id + "sb0"), 0.5));
    lvy_append(_out, lvy_body_rect(_mat, _a1x0, _a1y0, _x1, _y1, _st, false, LVY_BEV_SMALL,
                                   lvy_hash32(_mat.id + "sb1"), 0.5));
    lvy_append(_out, lvy_place(lvy_mark_chevron(_vert ? 0 : 3),
                               (_a0x0 + _a0x1) * 0.5, (_a0y0 + _a0y1) * 0.5,
                               _btn * 0.8, 0, _btn * 0.8, undefined));
    lvy_append(_out, lvy_place(lvy_mark_chevron(_vert ? 2 : 1),
                               (_a1x0 + _x1) * 0.5, (_a1y0 + _y1) * 0.5,
                               _btn * 0.8, 0, _btn * 0.8, undefined));

    // 3. THUMB, inside the run between the two buttons.
    var _run0 = _vert ? (_y0 + _btn) : (_x0 + _btn);
    var _run1 = _vert ? (_y1 - _btn) : (_x1 - _btn);
    var _runlen = _run1 - _run0;
    if (_runlen > _btn * 0.8) {
        var _tl = max(_btn * 0.8, _runlen * _f);
        var _tp = _run0 + (_runlen - _tl) * _v;
        var _in = max(1, _btn * 0.14);
        var _tx0 = _vert ? (_x0 + _in) : _tp;
        var _ty0 = _vert ? _tp : (_y0 + _in);
        var _tx1 = _vert ? (_x1 - _in) : (_tp + _tl);
        var _ty1 = _vert ? (_tp + _tl) : (_y1 - _in);
        lvy_append(_out, lvy_body_rect(_mat, _tx0, _ty0, _tx1, _ty1, _st, false, LVY_BEV_CONTROL,
                                       lvy_hash32(_mat.id + "sbt"), 0.6));
        // Grip ridges, across the thumb's SHORT axis.
        var _gx = (_tx0 + _tx1) * 0.5, _gy = (_ty0 + _ty1) * 0.5;
        if (_vert) {
            for (var _i = -1; _i <= 1; _i++) {
                lvy_append(_out, lvy_incise([[_tx0 + _in, _gy + _i * _btn * 0.22],
                                             [_tx1 - _in, _gy + _i * _btn * 0.22]], false,
                                            max(1.0, _btn * 0.07)));
            }
        } else {
            lvy_append(_out, lvy_grip(_gx, _gy, _btn * 0.7, (_ty1 - _ty0) * 0.5, 3));
        }
    }
    return _out;
}

/// ============================================================================================
/// FAMILY 13 - BADGE
/// ============================================================================================

/// A small accent-coloured count. Round when it holds one glyph, pill when it holds more, which is
/// the convention every interface follows and the reason it takes a width rather than a radius.
function lvy_badge(_mat, _x0, _y0, _x1, _y1) {
    var _out = [];
    var _pts = lvy_pts_pill(_x0, _y0, _x1, _y1, undefined);
    var _b = lvy_bevel_cap(_pts, min(_x1 - _x0, _y1 - _y0) * 0.22);

    // ⛔ THE FACE IS EMITTED DIRECTLY IN `accent`; IT IS NOT A ROLE REMAP OF A RAISED SHAPE.
    // The first version built `lvy_raise(pts, b, 2, "m3")` and then ran lvy_map_roles over the
    // result with { m3: "accent" }. That recolours the face - and ALSO every bevel wall whose
    // outward normal happens to land in the m3 band, because lvy_relief_role assigns walls from the
    // same five names the face uses. The badge came out as an accent oval with accent-coloured
    // patches scattered round its rim at whichever angles fell in that band, which on the families
    // sheet read as a broken component.
    //
    // ⭐ A ROLE IS NOT AN OBJECT. lvy_map_roles is right for "draw this whole mark in another
    // material" and wrong for "recolour one part of it", because the ramp names are shared by the
    // face and the relief BY DESIGN - that sharing is what makes one bevel engine serve forty
    // materials. Emitting the face separately costs one line and cannot be ambiguous.
    array_push(_out, lvy_ring_fill(_pts, "accent", undefined, undefined));
    lvy_append(_out, lvy_bevel(_pts, _b, 2, false));
    return _out;
}

/// ============================================================================================
/// FAMILY 14 - CURSOR
///
/// ⛔ AUTHORED IN THE UNIT BOX, NOT IN PIXEL SPACE, AND THAT IS THE ONE EXCEPTION IN THIS PACKAGE.
/// A cursor is a DETACHED MARK with a fixed aspect - it is never asked to fill a 400x24 slot - so
/// lvy_geom's rule puts it in the unit box with the other marks. Everything that takes a rectangle
/// is in pixel space; everything that has an intrinsic shape is in the unit box. The two are never
/// mixed in one builder.
/// ============================================================================================

/// The pointer arrow. Its outline is convex about its tip, so it MAY be a fill - checked, not
/// assumed, and the self-test asserts it.
function lvy_cursor_arrow() {
    var _pts = [[-0.34, -0.42], [-0.34, 0.30], [-0.16, 0.14], [-0.04, 0.44],
                [0.08, 0.38], [-0.03, 0.10], [0.16, 0.09]];
    var _out = [lvy_ring_fill(_pts, "m3", -0.24, 0.02)];
    lvy_append(_out, lvy_bevel(_pts, 0.045, 2, false));
    lvy_append(_out, [lvy_poly(_pts, true, 0.028, "m0")]);
    return _out;
}

/// The hand. A palm mass with four raised finger ridges - the fingers are RIDGES on the palm rather
/// than separate masses, because separate masses at cursor size read as a bundle of sticks.
function lvy_cursor_hand() {
    var _palm = lvy_round_rect_pts(-0.26, -0.06, 0.26, 0.44, 0.16, 4);
    var _out = lvy_raise(_palm, 0.055, 2, "m3");
    for (var _i = 0; _i < 4; _i++) {
        var _x = -0.19 + _i * 0.127;
        var _top = -0.34 + abs(_i - 1.4) * 0.055;
        lvy_append(_out, lvy_ridge([[_x, _top], [_x, 0.06]], false, 0.052));
    }
    lvy_append(_out, [lvy_poly(_palm, true, 0.026, "m0")]);
    return _out;
}

/// The text I-beam. Three strokes, no fill - it is an H rotated and a fan would fill the gap.
function lvy_cursor_beam() {
    var _out = [];
    lvy_append(_out, lvy_incise([[0, -0.40], [0, 0.40]], false, 0.055));
    lvy_append(_out, lvy_incise([[-0.15, -0.40], [0.15, -0.40]], false, 0.045));
    lvy_append(_out, lvy_incise([[-0.15, 0.40], [0.15, 0.40]], false, 0.045));
    return _out;
}

/// The busy ring. Twelve spokes of falling length around a hub - length, never width, carries the
/// gradient, which is this catalogue's standing law about what survives rasterisation.
function lvy_cursor_busy() {
    var _out = [];
    for (var _i = 0; _i < 12; _i++) {
        var _a = (_i / 12) * LVY_TAU;
        var _t = _i / 12;
        var _r0 = 0.16;
        var _r1 = 0.20 + 0.22 * (1 - _t);
        lvy_append(_out, [lvy_poly([[cos(_a) * _r0, sin(_a) * _r0],
                                    [cos(_a) * _r1, sin(_a) * _r1]], false, 0.05,
                                   _t < 0.5 ? "accent" : "m2")]);
    }
    return _out;
}

/// Every cursor by index, and its name. Four of them.
function lvy_cursor(_i) {
    switch (((_i % 4) + 4) % 4) {
        case 1:  return lvy_cursor_hand();
        case 2:  return lvy_cursor_beam();
        case 3:  return lvy_cursor_busy();
        default: return lvy_cursor_arrow();
    }
}

function lvy_cursor_name(_i) {
    switch (((_i % 4) + 4) % 4) {
        case 1:  return "hand";
        case 2:  return "text";
        case 3:  return "busy";
        default: return "pointer";
    }
}

/// ============================================================================================
/// THE FAMILY REGISTER
///
/// ⛔ DERIVED FROM THIS ONE ARRAY AND NEVER TYPED. The store page claims fourteen families and
/// forty materials; both numbers come from `array_length`, so the claim cannot drift from the code.
/// lvy_selftest asserts the product of the two against the number of components the bake actually
/// draws, which is the only thing that makes "560 distinct components" a measurement rather than a
/// sentence.
/// ============================================================================================
/// Cached in a global rather than with `static`, for the reason lvy_material's corpus records.
global.lvy_fam_cache = undefined;

function lvy_families_ui() {
    if (!is_undefined(global.lvy_fam_cache)) return global.lvy_fam_cache;
    var _f = ["frame", "header", "panel", "modal", "divider", "tooltip",
              "button", "toggle", "slider", "gauge", "tab", "scrollbar", "badge", "cursor"];
    global.lvy_fam_cache = _f;
    return _f;
}

function lvy_family_count() {
    return array_length(lvy_families_ui());
}

/// How many distinct components this product can draw: families times materials.
function lvy_component_count() {
    return lvy_family_count() * lvy_corpus_count();
}

/// ============================================================================================
/// ONE ENTRY POINT PER FAMILY, BY NAME
///
/// What the bake sheets, the demo room and the self-test all drive. A buyer never needs it - they
/// call lvy_button directly - but everything that has to walk ALL fourteen families does, and a
/// walk written as fourteen hand-listed calls is a walk that silently stops covering a family the
/// day one is added.
/// ============================================================================================
function lvy_draw_family(_name, _mat, _x0, _y0, _x1, _y1, _state) {
    var _st = is_undefined(_state) ? LVY_ST_IDLE : _state;
    var _cx = (_x0 + _x1) * 0.5, _cy = (_y0 + _y1) * 0.5;
    var _s = min(_x1 - _x0, _y1 - _y0);
    switch (_name) {
        case "frame":     return lvy_frame(_mat, _x0, _y0, _x1, _y1, _st);
        case "header":    return lvy_header(_mat, _x0, _y0, _x1, _y0 + (_y1 - _y0) * 0.42, _st);
        case "panel":     return lvy_panel(_mat, _x0, _y0, _x1, _y1, _st);
        case "modal":     return lvy_modal(_mat, _x0 + (_x1 - _x0) * 0.12, _y0 + (_y1 - _y0) * 0.14,
                                           _x1 - (_x1 - _x0) * 0.12, _y1 - (_y1 - _y0) * 0.14,
                                           _x0, _y0, _x1, _y1, _st);
        case "divider":   return lvy_divider(_mat, _x0, _cy - _s * 0.10, _x1, _cy + _s * 0.10, _st);
        case "tooltip":   return lvy_tooltip(_mat, _x0 + 4, _y0 + _s * 0.18, _x1 - 4,
                                             _y1 - _s * 0.30, 2, _st);
        case "button":    return lvy_button(_mat, _x0, _cy - _s * 0.22, _x1, _cy + _s * 0.22, _st);
        case "toggle":    return lvy_toggle_check(_mat, _cx - _s * 0.22, _cy - _s * 0.22,
                                                  _cx + _s * 0.22, _cy + _s * 0.22, true, _st);
        case "slider":    return lvy_slider(_mat, _x0, _cy - _s * 0.20, _x1, _cy + _s * 0.20, 0.62, _st);
        case "gauge":     return lvy_gauge(_mat, _x0, _cy - _s * 0.14, _x1, _cy + _s * 0.14, 0.72, 4, _st);
        case "tab":       return lvy_tab(_mat, _x0, _y0 + _s * 0.10, _x1, _y1 - _s * 0.10, true, _st);
        case "scrollbar": return lvy_scrollbar(_mat, _cx - _s * 0.13, _y0, _cx + _s * 0.13, _y1,
                                               0.35, 0.4, _st);
        case "badge":     return lvy_badge(_mat, _cx - _s * 0.26, _cy - _s * 0.17,
                                           _cx + _s * 0.26, _cy + _s * 0.17);
        case "cursor":    return lvy_place(lvy_cursor(0), _cx, _cy, _s * 0.8, 0, _s * 0.8, undefined);
        default:          return [];
    }
}
