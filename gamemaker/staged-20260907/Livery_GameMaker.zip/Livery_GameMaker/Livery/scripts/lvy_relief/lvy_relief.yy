{
  "$GMScript": "v1",
  "%Name": "lvy_relief",
  "name": "lvy_relief",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}