/// LIVERY - lvy_widget. The cached path, and the half of this product that makes it a SYSTEM.
///
/// ⛔⛔ THE CACHE IS NOT AN OPTIMISATION HERE. IT IS THE ONLY HONEST WAY TO SHIP A GENERATED
/// INTERFACE.
///
/// Every other product in this catalogue draws things that appear a few at a time. AN INTERFACE IS
/// ON SCREEN EVERY SINGLE FRAME, is the most redrawn surface in any game, and is the one place a
/// developer will not accept a frame cost they did not choose. A themed window frame with studs is
/// several hundred primitives; a screenful of twenty widgets rebuilt from geometry every frame is
/// tens of thousands of draw calls per frame and it WILL show up in a buyer's profiler.
///
/// A generated interface that costs more than the nine-slice it replaces is a WORSE PRODUCT than
/// the thing it replaces, however good it looks. So:
///
///   - a widget renders itself into a sprite ONCE, on its first draw;
///   - it rebuilds ONLY when something that changes its appearance changes;
///   - global.lvy_rebuilds counts every rebuild, and the demo room prints it on screen so a buyer
///     can SEE the cost is zero when nothing moves rather than take our word for it.
///
/// ⚠️ THE COUNTER IS PART OF THE PRODUCT, NOT DEBUG SCAFFOLDING. It is the only way a buyer can
/// check our performance claim in their own game, in five minutes, without a profiler. Removing it
/// to "tidy up before shipping" would remove the evidence for the claim on the store page.
///
/// -- OWNERSHIP, STATED ONCE AND STATED PLAINLY -----------------------------------------------
/// ⛔ THE CALLER OWNS EVERY WIDGET AND MUST CALL lvy_widget_free. A generator that hands out sprites
/// with no stated ownership is a leak with a nice API on top. The demo object frees every widget it
/// made in its Clean Up event, and the Readme says this in the same words.
///
/// ⛔ AND A WIDGET MUST NOT BE BUILT FROM A DRAW EVENT. surface_set_target inside a draw event nests
/// render targets, and on some drivers that silently produces an EMPTY sprite rather than an error -
/// the exact shape of failure this wing keeps recording. lvy_widget_draw is safe in Draw because it
/// only blits; the build happens on the first call, which is why the Readme says to make widgets in
/// Create. The one case that cannot be avoided is a widget created mid-game, so lvy_widget_draw
/// DETECTS the nested target and defers the build by one frame rather than producing a blank.
/// ============================================================================================

/// How many sprite rebuilds have happened since the game started.
///
/// Top-level, so it exists before the first room - the same mechanism lvy_relief uses for its lamp,
/// and lvy_selftest asserts it ran.
global.lvy_rebuilds = 0;

/// How much padding a widget's sprite carries around its rect, as a fraction of the short side.
///
/// ⛔ A WIDGET IS BIGGER THAN ITS RECT AND FORGETTING THAT CLIPS THE PRODUCT'S BEST FEATURES. A focus
/// ring is drawn OUTSIDE the component; a modal's drop shadow falls outside it; a tooltip's beak
/// sticks out of it by a fifth of its own height. Rendering into a surface exactly the size of the
/// rect cuts all three off, and the failure looks like a design choice rather than a bug.
#macro LVY_WIDGET_PAD 0.34

/// Make a widget.
///
/// _family is one of lvy_families_ui(). _extra carries whatever that family needs - a value for a
/// slider or gauge, an on/off for a toggle - and is compared on state changes, so a gauge whose
/// value has not moved does not rebuild.
function lvy_widget(_theme, _family, _x0, _y0, _x1, _y1, _state, _extra) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_theme)) return undefined;
    return {
        theme: _theme,
        family: _family,
        x0: _x0, y0: _y0, x1: _x1, y1: _y1,
        state: is_undefined(_state) ? LVY_ST_IDLE : _state,
        extra: is_undefined(_extra) ? 0 : _extra,
        spr: -1,
        // What the cached sprite was built FROM. A rebuild is needed when any of these disagrees
        // with the live values - see lvy_widget_state_changed.
        builtState: "",
        builtExtra: -99999,
        builtTheme: ""
    };
}

/// Does this widget's cached sprite still match what it should look like?
///
/// ⭐ IT COMPARES AGAINST WHAT WAS BUILT, NOT AGAINST A DIRTY FLAG, AND THE DIFFERENCE IS THE WHOLE
/// RELIABILITY OF THE CACHE. A dirty flag has to be set by every code path that changes anything,
/// and the one path that forgets produces a widget that is silently, permanently wrong - the worst
/// failure this file could have, because it looks like a rendering bug and lives in the caller's
/// code. Comparing the built-from values cannot be forgotten: a caller may set .state directly and
/// the cache still notices.
function lvy_widget_state_changed(_w) {
    if (_w.spr < 0) return true;
    if (_w.builtState != _w.state) return true;
    if (_w.builtTheme != _w.theme.id) return true;
    // ⚠️ A TOLERANCE, NOT AN EQUALITY, AND NOT ONE BELOW 1e-5. GML applies a default epsilon of
    // 0.00001 to numeric comparisons, so a tolerance at or below it can never fire in either
    // direction (lvy_palette's header carries the receipt). A gauge driven by a smoothly falling
    // health value would otherwise rebuild every single frame for a change no pixel can show.
    if (abs(_w.builtExtra - _w.extra) > 0.002) return true;
    return false;
}

/// The pixel rect a widget's sprite covers, including its padding.
function lvy_widget_bounds(_w) {
    var _p = min(_w.x1 - _w.x0, _w.y1 - _w.y0) * LVY_WIDGET_PAD;
    return [_w.x0 - _p, _w.y0 - _p, _w.x1 + _p, _w.y1 + _p];
}

/// The part list for a widget, in absolute pixel space.
function lvy_widget_parts(_w) {
    var _m = _w.theme.mat;
    var _st = _w.state;
    switch (_w.family) {
        case "toggle": return lvy_toggle_check(_m, _w.x0, _w.y0, _w.x1, _w.y1, _w.extra >= 0.5, _st);
        case "slider": return lvy_slider(_m, _w.x0, _w.y0, _w.x1, _w.y1, _w.extra, _st);
        case "gauge":  return lvy_gauge(_m, _w.x0, _w.y0, _w.x1, _w.y1, _w.extra, 4, _st);
        case "tab":    return lvy_tab(_m, _w.x0, _w.y0, _w.x1, _w.y1, _w.extra >= 0.5, _st);
        case "scrollbar": return lvy_scrollbar(_m, _w.x0, _w.y0, _w.x1, _w.y1, _w.extra, 0.4, _st);
        default:       return lvy_draw_family(_w.family, _m, _w.x0, _w.y0, _w.x1, _w.y1, _st);
    }
}

/// Build (or rebuild) a widget's cached sprite. Safe to call from Create; NOT from Draw.
function lvy_widget_build(_w) {
    if (_w.spr >= 0) { sprite_delete(_w.spr); _w.spr = -1; }
    var _b = lvy_widget_bounds(_w);
    var _sw = max(1, ceil(_b[2] - _b[0]));
    var _sh = max(1, ceil(_b[3] - _b[1]));

    var _surf = surface_create(_sw, _sh);
    surface_set_target(_surf);
    draw_clear_alpha(c_black, 0);
    // The parts are in absolute pixel space and the surface's origin is at _b[0],_b[1], so the
    // whole list is translated rather than re-derived at the origin. Re-deriving would mean every
    // builder needed an origin argument, and one that forgot it would draw off the surface.
    lvy_render_parts_raw(lvy_offset_parts(lvy_widget_parts(_w), -_b[0], -_b[1]),
                         lvy_theme_surface(_w.theme, _w.state));
    surface_reset_target();

    _w.spr = sprite_create_from_surface(_surf, 0, 0, _sw, _sh, false, false, 0, 0);
    surface_free(_surf);

    _w.builtState = _w.state;
    _w.builtExtra = _w.extra;
    _w.builtTheme = _w.theme.id;
    global.lvy_rebuilds += 1;
    return _w;
}

/// Draw a widget, rebuilding first if anything about it has changed.
///
/// ⚠️ THE NESTED-TARGET GUARD. If this is called while a surface is already the render target -
/// which is what happens when a widget is created mid-frame inside a Draw event - building would
/// nest surface_set_target and on some drivers silently yield an empty sprite. Rather than produce
/// a blank, the build is skipped for this frame and the widget draws its geometry directly. It
/// costs one uncached frame and it can never produce an invisible widget.
function lvy_widget_draw(_w) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_w)) return;
    if (lvy_widget_state_changed(_w)) {
        if (surface_get_target() != -1) {
            lvy_render_parts_raw(lvy_widget_parts(_w), lvy_theme_surface(_w.theme, _w.state));
            return;
        }
        lvy_widget_build(_w);
    }
    var _b = lvy_widget_bounds(_w);
    draw_sprite(_w.spr, 0, _b[0], _b[1]);
}

/// Move a widget. Rebuilds on the next draw only if its SIZE changed - a widget that has only been
/// translated keeps its sprite, which is the common case for anything that follows the mouse.
function lvy_widget_move(_w, _x0, _y0, _x1, _y1) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_w)) return _w;
    var _sizeChanged = (abs((_x1 - _x0) - (_w.x1 - _w.x0)) > 0.5)
                    || (abs((_y1 - _y0) - (_w.y1 - _w.y0)) > 0.5);
    _w.x0 = _x0; _w.y0 = _y0; _w.x1 = _x1; _w.y1 = _y1;
    if (_sizeChanged && _w.spr >= 0) { sprite_delete(_w.spr); _w.spr = -1; }
    return _w;
}

/// Set a widget's state. Cheap; the rebuild happens at the next draw.
function lvy_widget_set_state(_w, _state) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_w)) return _w; _w.state = _state; return _w; }

/// Set a widget's value (slider position, gauge fraction, toggle on/off as 0 or 1).
function lvy_widget_set_value(_w, _v) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_w)) return _w; _w.extra = _v; return _w; }

/// Re-theme a widget. This is the call that re-skins a whole interface.
function lvy_widget_set_theme(_w, _theme) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_w)) return _w; _w.theme = _theme; return _w; }

/// ⛔ FREE IT. See the header - the caller owns the sprite.
function lvy_widget_free(_w) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_w)) return _w;
    if (_w.spr >= 0) { sprite_delete(_w.spr); _w.spr = -1; }
    return _w;
}

/// Free a whole array of widgets, for a Clean Up event.
function lvy_widget_free_all(_arr) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_array(_arr)) return _arr;
    for (var _i = 0; _i < array_length(_arr); _i++) lvy_widget_free(_arr[_i]);
    return _arr;
}

/// ============================================================================================
/// HIT TESTING
///
/// The smallest amount of interaction logic that makes the cache useful, and no more.
///
/// ⛔ THIS PACKAGE IS NOT A UI FRAMEWORK AND MUST NOT GROW INTO ONE. Layout, focus order, keyboard
/// navigation and event routing are the buyer's game's business and every engine has opinions about
/// them; a half-framework that fights the buyer's own is worth less than none. What IS shipped is
/// the one thing that cannot be written without knowing how a widget was drawn: whether a point is
/// on it, using the widget's RECT and not its padded sprite.
/// ============================================================================================

/// Is (_px,_py) inside this widget's interactive rect?
///
/// ⚠️ THE RECT, NOT THE SPRITE. A focus ring and a drop shadow are outside the rect and are NOT
/// clickable; hit-testing the padded sprite would make a button respond a third of its own height
/// away from itself.
function lvy_widget_hit(_w, _px, _py) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_w)) return false;
    return (_px >= _w.x0 && _px <= _w.x1 && _py >= _w.y0 && _py <= _w.y1);
}

/// Resolve idle/hover/pressed from a pointer, leaving disabled and focus alone.
///
/// ⚠️ IT REFUSES TO OVERRIDE DISABLED, and that is a real bug class rather than politeness: a
/// disabled button that lights up on hover tells the player it can be clicked, and they will click
/// it. Passing a disabled widget through a hover resolver is a mistake the resolver can catch.
function lvy_widget_pointer(_w, _px, _py, _down) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_w)) return _w;
    if (_w.state == LVY_ST_DISABLED) return _w;
    var _in = lvy_widget_hit(_w, _px, _py);
    if (!_in) { _w.state = LVY_ST_IDLE; return _w; }
    _w.state = _down ? LVY_ST_PRESSED : LVY_ST_HOVER;
    return _w;
}
