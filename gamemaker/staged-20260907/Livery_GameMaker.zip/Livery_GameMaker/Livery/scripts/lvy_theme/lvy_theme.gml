/// LIVERY - lvy_theme. The buyer's front door.
///
/// A THEME is a material with its five state surfaces already resolved. It is the only object a
/// buyer's game needs to hold, and swapping one for another re-skins an entire interface without
/// touching a line of layout code - which is the promise on the store page and is implemented here
/// rather than claimed.
///
///     var _t = lvy_theme("brass");
///     lvy_draw_button(_t, 40, 40, 180, 76, LVY_ST_HOVER);
///
/// -- WHY THE SURFACES ARE RESOLVED UP FRONT --------------------------------------------------
/// lvy_surface does about sixty Oklch conversions, each of which walks a gamut-reduction loop. That
/// is nothing once and a great deal on every component of every frame. Five states resolved at
/// theme construction is five hundred-odd conversions, paid once, and every draw call after that is
/// a struct lookup.
///
/// ⚠️ AND IT IS WHY A THEME IS A VALUE RATHER THAN A NAME. A buyer who calls lvy_theme("brass") in
/// a Draw event has written the pathological case by accident; the Readme says to build it in
/// Create and keep it, and the demo room does exactly that. The function is cheap enough to survive
/// the mistake, but it is not free and pretending otherwise would be dishonest.
/// ============================================================================================

/// Build a theme from a material id. Returns undefined for an unknown id.
///
/// ⛔ UNDEFINED, NOT A FALLBACK THEME. A silent fallback to the first material means a buyer who
/// typos "brasss" ships an interface in blackened iron and never finds out why. An undefined return
/// is loud at the first draw call, which is where they can still fix it.
function lvy_theme(_id) {
    var _m = lvy_material_get(_id);
    if (is_undefined(_m)) return undefined;
    return lvy_theme_of(_m);
}

/// Build a theme from a material struct, for callers walking the corpus.
function lvy_theme_of(_mat) {
    var _sf = {};
    var _st = lvy_states();
    for (var _i = 0; _i < array_length(_st); _i++) {
        variable_struct_set(_sf, _st[_i], lvy_surface(_mat, _st[_i]));
    }
    return {
        id: _mat.id,
        name: _mat.name,
        family: _mat.family,
        mat: _mat,
        surfaces: _sf
    };
}

/// A theme by corpus index, wrapping. What the demo's cycle key and the bake sheets use.
function lvy_theme_at(_i) {
    return lvy_theme_of(lvy_material_at(_i));
}

/// The resolved surface for one state. Falls back to idle rather than to the renderer's `line`
/// role, because an unknown STATE is a caller mistake and an unknown ROLE is a corpus mistake, and
/// they want different failure modes.
function lvy_theme_surface(_theme, _state) {
    var _s = is_undefined(_state) ? LVY_ST_IDLE : _state;
    if (variable_struct_exists(_theme.surfaces, _s)) {
        return variable_struct_get(_theme.surfaces, _s);
    }
    return variable_struct_get(_theme.surfaces, LVY_ST_IDLE);
}

/// ============================================================================================
/// THE IMMEDIATE-MODE DRAW CALLS
///
/// One per family. This is the API a buyer reads first and it is deliberately boring: a rect, a
/// state, and nothing else. Everything interesting is decided by the theme.
///
/// ⚠️ THESE REBUILD THEIR GEOMETRY EVERY CALL. That is correct for a menu that is on screen for two
/// seconds and WRONG for a HUD that is on screen for six hours - use lvy_widget for the second case.
/// Both paths exist because both uses are real, and shipping only the fast one would make the
/// simple case require a lifecycle a buyer does not want to think about.
/// ============================================================================================

function lvy_draw_frame(_t, _x0, _y0, _x1, _y1, _state) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_t)) return;
    lvy_render_parts_raw(lvy_frame(_t.mat, _x0, _y0, _x1, _y1, _state), lvy_theme_surface(_t, _state));
}

function lvy_draw_header(_t, _x0, _y0, _x1, _y1, _state) {
    lvy_render_parts_raw(lvy_header(_t.mat, _x0, _y0, _x1, _y1, _state), lvy_theme_surface(_t, _state));
}

function lvy_draw_panel(_t, _x0, _y0, _x1, _y1, _state) {
    lvy_render_parts_raw(lvy_panel(_t.mat, _x0, _y0, _x1, _y1, _state), lvy_theme_surface(_t, _state));
}

function lvy_draw_well(_t, _x0, _y0, _x1, _y1, _state) {
    lvy_render_parts_raw(lvy_well(_t.mat, _x0, _y0, _x1, _y1, _state), lvy_theme_surface(_t, _state));
}

function lvy_draw_modal(_t, _x0, _y0, _x1, _y1, _sx0, _sy0, _sx1, _sy1, _state) {
    lvy_render_parts_raw(lvy_modal(_t.mat, _x0, _y0, _x1, _y1, _sx0, _sy0, _sx1, _sy1, _state),
                         lvy_theme_surface(_t, _state));
}

function lvy_draw_divider(_t, _x0, _y0, _x1, _y1, _state) {
    lvy_render_parts_raw(lvy_divider(_t.mat, _x0, _y0, _x1, _y1, _state), lvy_theme_surface(_t, _state));
}

function lvy_draw_tooltip(_t, _x0, _y0, _x1, _y1, _side, _state) {
    lvy_render_parts_raw(lvy_tooltip(_t.mat, _x0, _y0, _x1, _y1, _side, _state),
                         lvy_theme_surface(_t, _state));
}

function lvy_draw_button(_t, _x0, _y0, _x1, _y1, _state) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_t)) return;
    lvy_render_parts_raw(lvy_button(_t.mat, _x0, _y0, _x1, _y1, _state), lvy_theme_surface(_t, _state));
}

function lvy_draw_check(_t, _x0, _y0, _x1, _y1, _on, _state) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_t)) return;
    lvy_render_parts_raw(lvy_toggle_check(_t.mat, _x0, _y0, _x1, _y1, _on, _state),
                         lvy_theme_surface(_t, _state));
}

function lvy_draw_radio(_t, _x0, _y0, _x1, _y1, _on, _state) {
    lvy_render_parts_raw(lvy_toggle_radio(_t.mat, _x0, _y0, _x1, _y1, _on, _state),
                         lvy_theme_surface(_t, _state));
}

function lvy_draw_switch(_t, _x0, _y0, _x1, _y1, _on, _state) {
    lvy_render_parts_raw(lvy_toggle_switch(_t.mat, _x0, _y0, _x1, _y1, _on, _state),
                         lvy_theme_surface(_t, _state));
}

function lvy_draw_slider(_t, _x0, _y0, _x1, _y1, _v, _state) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_t)) return;
    lvy_render_parts_raw(lvy_slider(_t.mat, _x0, _y0, _x1, _y1, _v, _state),
                         lvy_theme_surface(_t, _state));
}

function lvy_draw_gauge(_t, _x0, _y0, _x1, _y1, _v, _ticks, _state) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_t)) return;
    lvy_render_parts_raw(lvy_gauge(_t.mat, _x0, _y0, _x1, _y1, _v, _ticks, _state),
                         lvy_theme_surface(_t, _state));
}

function lvy_draw_tab(_t, _x0, _y0, _x1, _y1, _active, _state) {
    lvy_render_parts_raw(lvy_tab(_t.mat, _x0, _y0, _x1, _y1, _active, _state),
                         lvy_theme_surface(_t, _state));
}

function lvy_draw_scrollbar(_t, _x0, _y0, _x1, _y1, _v, _frac, _state) {
    lvy_render_parts_raw(lvy_scrollbar(_t.mat, _x0, _y0, _x1, _y1, _v, _frac, _state),
                         lvy_theme_surface(_t, _state));
}

function lvy_draw_badge(_t, _x0, _y0, _x1, _y1) {
    lvy_render_parts_raw(lvy_badge(_t.mat, _x0, _y0, _x1, _y1), lvy_theme_surface(_t, LVY_ST_IDLE));
}

/// A cursor, drawn at a point rather than into a rect - it is a detached mark and has its own
/// aspect. _size is its height in pixels.
function lvy_draw_cursor(_t, _i, _x, _y, _size) {
    lvy_render_parts(lvy_cursor(_i), lvy_theme_surface(_t, LVY_ST_IDLE), _x, _y, _size, 0, _size,
                     undefined);
}

/// ============================================================================================
/// TEXT
///
/// ⛔ TEXT GOES IN `ink`, NEVER IN A RAMP STOP. lvy_material's header has the receipt: on a light
/// material every ramp stop is light, so m0 is not a text colour - it is merely less pale. Parchment
/// grounds at L 0.80 with a ramp from 0.62 to 0.98. These two wrappers exist so that no call site in
/// this package or in a buyer's game has to remember it.
/// ============================================================================================

/// A label on a component, centred in a rect.
function lvy_draw_label(_t, _text, _x0, _y0, _x1, _y1, _px, _state) {
    var _s = lvy_theme_surface(_t, _state);
    lvy_text_fit(_text, (_x0 + _x1) * 0.5, (_y0 + _y1) * 0.5, (_x1 - _x0) * 0.90,
                 is_undefined(_px) ? (_y1 - _y0) * 0.44 : _px, _s.m0, _s.ink);
}

/// A label ON an accent-coloured component - a badge count, a selected tab.
function lvy_draw_accent_label(_t, _text, _x0, _y0, _x1, _y1, _px) {
    var _s = lvy_theme_surface(_t, LVY_ST_IDLE);
    lvy_text_fit(_text, (_x0 + _x1) * 0.5, (_y0 + _y1) * 0.5, (_x1 - _x0) * 0.86,
                 is_undefined(_px) ? (_y1 - _y0) * 0.52 : _px, _s.accent, _s.accentInk);
}
