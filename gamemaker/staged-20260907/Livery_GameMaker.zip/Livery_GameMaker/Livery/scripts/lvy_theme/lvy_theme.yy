{
  "$GMScript": "v1",
  "%Name": "lvy_theme",
  "name": "lvy_theme",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}