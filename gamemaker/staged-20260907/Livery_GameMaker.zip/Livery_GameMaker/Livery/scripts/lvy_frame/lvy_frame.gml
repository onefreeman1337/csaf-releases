/// LIVERY - lvy_frame. Six of the fourteen component families, and the shared body every one of
/// the fourteen is made of.
///
///   frame     a window or dialog frame, with a content well and its material's own furniture
///   header    a title bar, with the frame's corner treatment on its top two corners only
///   panel     a raised content area
///   modal     a frame plus a scrim and a drop shadow
///   divider   an ornamental rule
///   tooltip   a small panel with a beak pointing at what it describes
///
/// lvy_control carries the other eight.
///
/// -- WHAT MAKES THESE COMPONENTS AND NOT PICTURES --------------------------------------------
/// ⛔ EVERY BUILDER TAKES A RECTANGLE AND RETURNS PARTS IN PIXEL SPACE, and none of them is ever
/// scaled afterwards. lvy_geom's COORDINATES header has the argument in full: an interface is not a
/// picture with an aspect ratio, and the moment a component is authored in a unit box and scaled to
/// fit, its corner radius and its bevel scale with it - so a wide button gets ovals for corners and
/// a tall one gets a moulding deeper than its own text.
///
/// -- THE ORDER PARTS ARE EMITTED IN IS LOAD-BEARING -------------------------------------------
/// ⛔ THE WING CONSTITUTION RECORDS A GILT PLATE RIM DRAWN ACROSS THE FOOD ON EVERY RIMMED PLATE A
/// PRODUCT COULD PRODUCE, because one closed ring was appended last "so it sits on top". The same
/// shape is live here in three places and each is handled explicitly rather than by hope:
///
///   1. A frame's WELL is sunk INTO its body, so the body is emitted first and the well second.
///   2. FURNITURE sits ON the body but UNDER the content, so it goes between them.
///   3. A modal's SCRIM is behind everything and its DROP SHADOW is behind the frame but in front
///      of the scrim, so the emission order is scrim, shadow, frame - never frame, shadow.
///
/// lvy_selftest asserts the ordering contract directly, because the picture is unreachable from a
/// test: it checks that a well's parts appear after the body's and before the furniture's, and it
/// is proved red by sabotage rather than assumed.
/// ============================================================================================

/// How deep a bevel is, as a fraction of the component's short side, per family.
///
/// ⚠️ THESE ARE NOT ONE NUMBER AND THEY MUST NOT BECOME ONE. A window frame is a thick moulding and
/// a divider is a scratch; giving both the same fraction makes the frame look thin and the divider
/// look like a gutter. The values are the design, and lvy_selftest bounds them rather than pinning
/// them, so a later improvement does not go red on a constant it was testing against itself.
#macro LVY_BEV_FRAME   0.085
#macro LVY_BEV_PANEL   0.070
#macro LVY_BEV_WELL    0.055
#macro LVY_BEV_CONTROL 0.150
#macro LVY_BEV_SMALL   0.220

/// The deepest a bevel may ever be, in pixels, before the material's weight multiplier.
///
/// ⛔⛔ THE THIRD AND FOURTH INSTANCES OF ONE LAW, ALL FOUND ON ONE HERO SHEET. lvy_shape's
/// LVY_CORNER_MAX_PX and lvy_char's lvy_char_spacing record the first two. This is the same defect
/// in the bevel and in the frame's moulding margin below:
///
///   a 796-tall frame took `short * 0.085 * weight` = a SIXTY-EIGHT PIXEL bevel, and
///   `lvy_frame_content` took a margin of 187 PIXELS on each side.
///
/// The frame's usable interior therefore collapsed to a fraction of itself, every component laid
/// out relative to it collided with the scrollbar, and one label was handed a rect whose right edge
/// was left of its left edge - which draws the text MIRRORED. A mirrored word on a store sheet.
///
/// ⭐ THE GENERAL RULE, AND IT IS WORTH STATING ONCE FOR ALL FOUR: A DIMENSION THAT DESCRIBES A
/// PHYSICAL DETAIL - a moulding, a bevel, a corner, a grain - MUST BE BOUNDED IN PIXELS, NOT ONLY
/// AS A PROPORTION. Proportional-only is correct going DOWN (a 24px checkbox may not have a 30px
/// corner) and wrong going UP, and it is wrong in a way that only shows on the largest component
/// the product can draw - which is exactly the one on the hero image.
///
/// ⚠️ AND NOTHING MECHANICAL SAW ANY OF THE FOUR. Turning passed, containment passed, the ink
/// floors passed, 1836 assertions passed. All four were found by opening one PNG and looking at it.
#macro LVY_BEV_MAX_PX 26

/// The thickest a frame's moulding may be, in pixels, before the weight multiplier.
#macro LVY_FRAME_MARGIN_MAX_PX 40

/// ============================================================================================
/// THE SHARED BODY
/// ============================================================================================

/// The bevel depth a component should use.
///
/// Three bounds, each catching a different failure: the proportional term keeps a small control's
/// bevel in scale with it, LVY_BEV_MAX_PX keeps a large frame's bevel a moulding rather than a
/// ramp, and lvy_bevel_cap stops any outline being turned inside out by its own bevel.
function lvy_body_depth(_mat, _pts, _state, _k) {
    var _bb = lvy_pts_bounds(_pts);
    var _short = min(_bb[2] - _bb[0], _bb[3] - _bb[1]);
    var _sb = lvy_state_bevel(_state);
    // The absolute cap is expressed in the FRAME's terms and scaled by this family's own depth
    // ratio, so a control keeps a proportionally deeper bevel than a moulding does - which is
    // correct, a button cap is chunkier than a window edge - without either being unbounded.
    var _absCap = LVY_BEV_MAX_PX * (_k / LVY_BEV_FRAME);
    var _want = min(_short * _k, _absCap) * _mat.weight * abs(_sb);
    return lvy_bevel_cap(_pts, _want);
}

/// The rect a component's surface character may occupy: its own bounds, pulled in past the bevel
/// AND past the corner treatment.
///
/// ⛔ PAST THE CORNER TREATMENT IS THE HALF THAT IS EASY TO FORGET. A COVE corner scoops INTO the
/// shape by about 0.29 of its radius, so a character rect inset only by the bevel would put grain,
/// speckle and crazing in a region where the component is not drawn at all - marks floating outside
/// their own object, on ten of the forty materials.
function lvy_face_rect(_mat, _pts, _b) {
    var _bb = lvy_pts_bounds(_pts);
    var _r = lvy_corner_radius(_bb[2] - _bb[0], _bb[3] - _bb[1], _mat.corner, _mat.weight);
    var _pad = max(_b * 1.35, _r * 0.62);
    var _x0 = _bb[0] + _pad, _y0 = _bb[1] + _pad;
    var _x1 = _bb[2] - _pad, _y1 = _bb[3] - _pad;
    if (_x1 - _x0 < 2 || _y1 - _y0 < 2) return undefined;
    return [_x0, _y0, _x1, _y1];
}

/// A component body: the material's outline, raised or sunk, with its surface character on the face.
///
/// _sunken asks for a recess. A PRESSED state flips whatever was asked for, which is the whole
/// mechanism behind a button that depresses rather than a button that changes colour - see
/// lvy_material's lvy_state_delta.
function lvy_body(_mat, _pts, _state, _sunken, _k, _seed) {
    var _b = lvy_body_depth(_mat, _pts, _state, _k);
    var _inv = _sunken;
    if (lvy_state_bevel(_state) < 0) _inv = !_inv;

    var _out = _inv ? lvy_sink(_pts, _b, 2, "m1") : lvy_raise(_pts, _b, 3, "m2");

    var _fr = lvy_face_rect(_mat, _pts, _b);
    if (!is_undefined(_fr)) {
        lvy_append(_out, lvy_char_parts(_mat, _fr[0], _fr[1], _fr[2], _fr[3], _seed));
    }
    return _out;
}

/// A body built straight from a rect under the material's own corner treatment.
function lvy_body_rect(_mat, _x0, _y0, _x1, _y1, _state, _sunken, _k, _seed, _cornerScale) {
    return lvy_body(_mat, lvy_shape_of(_mat, _x0, _y0, _x1, _y1, _cornerScale),
                    _state, _sunken, _k, _seed);
}

/// The pixel offset a pressed component's cap moves by, along the lamp's shadow direction.
///
/// ⚠️ AWAY FROM THE LAMP, NOT TOWARD IT. Moving a pressed cap toward the light makes it read as
/// LIFTED, which is the opposite of the intent and is a mistake that survives review because the
/// picture still looks like something.
function lvy_press_offset(_state, _short) {
    var _d = lvy_state_inset(_state) * _short;
    if (_d <= 0) return [0, 0];
    return [-LVY_LX * _d, -LVY_LY * _d];
}

/// ============================================================================================
/// FURNITURE - the six things a material's frame carries at its edges
///
/// ⭐ FURNITURE IS THE THIRD AXIS OF DIFFERENCE, after colour and corner, and it is the one a buyer
/// describes out loud. Nobody says "the one with hue 84"; they say "the riveted one". Iron, brass
/// and bronze are studded; oak and sandstone are bracketed; gilt, pewter and porcelain carry an
/// inner fillet; steel and the technical set have end caps; every textile is stitched.
/// ============================================================================================

/// Rivets set along the border, inset from the edge by their own diameter.
///
/// The spacing is derived from the frame's PERIMETER rather than typed, so a tall narrow dialog and
/// a wide banner get studs at the same physical pitch instead of the same COUNT - which is what
/// makes a set of frames look like they came out of the same workshop.
function lvy_fn_stud(_mat, _x0, _y0, _x1, _y1, _b) {
    var _out = [];
    var _r = max(1.2, _b * 0.62);
    var _in = _b * 1.55 + _r;
    var _ax0 = _x0 + _in, _ay0 = _y0 + _in, _ax1 = _x1 - _in, _ay1 = _y1 - _in;
    if (_ax1 <= _ax0 || _ay1 <= _ay0) return _out;
    var _pitch = max(_r * 4.2, 14);
    var _nx = max(1, round((_ax1 - _ax0) / _pitch));
    var _ny = max(1, round((_ay1 - _ay0) / _pitch));

    for (var _i = 0; _i <= _nx; _i++) {
        var _xx = _ax0 + (_ax1 - _ax0) * (_i / _nx);
        lvy_append(_out, lvy_boss(_xx, _ay0, _r, 10));
        lvy_append(_out, lvy_boss(_xx, _ay1, _r, 10));
    }
    // The vertical runs skip their first and last stud - those corners already carry one.
    for (var _j = 1; _j < _ny; _j++) {
        var _yy = _ay0 + (_ay1 - _ay0) * (_j / _ny);
        lvy_append(_out, lvy_boss(_ax0, _yy, _r, 10));
        lvy_append(_out, lvy_boss(_ax1, _yy, _r, 10));
    }
    return _out;
}

/// L-shaped corner brackets, raised, one per corner.
function lvy_fn_bracket(_mat, _x0, _y0, _x1, _y1, _b) {
    var _out = [];
    var _in = _b * 1.4;
    var _len = min((_x1 - _x0), (_y1 - _y0)) * 0.26;
    var _t = max(2.0, _b * 0.75);
    if (_len < _t * 2) return _out;
    var _sx = [1, 1, -1, -1];
    var _sy = [1, -1, -1, 1];
    var _cx = [_x0 + _in, _x0 + _in, _x1 - _in, _x1 - _in];
    var _cy = [_y0 + _in, _y1 - _in, _y1 - _in, _y0 + _in];
    for (var _c = 0; _c < 4; _c++) {
        var _px = _cx[_c], _py = _cy[_c];
        var _dx = _sx[_c], _dy = _sy[_c];
        // A single closed L, walked so it stays simple whichever corner it is on.
        var _pts = [
            [_px, _py],
            [_px + _dx * _len, _py],
            [_px + _dx * _len, _py + _dy * _t],
            [_px + _dx * _t, _py + _dy * _t],
            [_px + _dx * _t, _py + _dy * _len],
            [_px, _py + _dy * _len]
        ];
        lvy_append(_out, lvy_raise(_pts, lvy_bevel_cap(_pts, _t * 0.42), 2, "m3"));
    }
    return _out;
}

/// An inner hairline ridge, following the material's own corner treatment.
///
/// ⛔ NARROW, AND FOLLOWING THE FULL CORNER RADIUS, AND BOTH HALVES WERE WRONG FIRST TIME.
/// MEASURED by cropping one well corner to 16x: the ridge showed as a jagged dark CRACK across the
/// corner. lvy_ridge is three strokes - a dark wall, a lit wall and a centre - offset along the lamp
/// by 0.55 of the stroke width, which reads as one raised wire on a straight run and SEPARATES INTO
/// THREE on a tight curve. At 0.30 of a 16px bevel the offset was 2.7px, and the corner it was
/// following had been tightened to 0.75 of the material's radius, so it was the tightest curve in
/// the component.
///
/// ⭐ A COMPOSITE STROKE HAS A MINIMUM RADIUS OF CURVATURE, and it is set by its own offsets. Either
/// keep the offsets well under the radius it has to follow, or do not use one there. Nothing
/// mechanical in this package can see it: three strokes that separate are three strokes exactly
/// where three strokes belong.
function lvy_fn_fillet(_mat, _x0, _y0, _x1, _y1, _b) {
    var _in = _b * 1.9;
    if (_x1 - _x0 < _in * 3 || _y1 - _y0 < _in * 3) return [];
    var _pts = lvy_shape_of(_mat, _x0 + _in, _y0 + _in, _x1 - _in, _y1 - _in, 1.0);
    return lvy_ridge(_pts, true, max(1.0, _b * 0.16));
}

/// Raised end caps across the two SHORT ends of the component.
///
/// ⚠️ THE SHORT ENDS, DECIDED BY MEASURING. A cap builder that always capped left and right would
/// put two bars across the top and bottom of a tall dialog and read as a mistake. This is the same
/// vertical-from-horizontal law the wing constitution records, met from the other direction.
function lvy_fn_cap(_mat, _x0, _y0, _x1, _y1, _b) {
    var _out = [];
    var _w = _x1 - _x0, _h = _y1 - _y0;
    var _in = _b * 1.3;
    var _t = max(3.0, min(_w, _h) * 0.085);
    if (min(_w, _h) < _t * 4) return _out;
    if (_w >= _h) {
        var _a = lvy_pts_square(_x0 + _in, _y0 + _in, _x0 + _in + _t, _y1 - _in);
        var _c = lvy_pts_square(_x1 - _in - _t, _y0 + _in, _x1 - _in, _y1 - _in);
        lvy_append(_out, lvy_raise(_a, lvy_bevel_cap(_a, _t * 0.40), 2, "m3"));
        lvy_append(_out, lvy_raise(_c, lvy_bevel_cap(_c, _t * 0.40), 2, "m3"));
    } else {
        var _a2 = lvy_pts_square(_x0 + _in, _y0 + _in, _x1 - _in, _y0 + _in + _t);
        var _c2 = lvy_pts_square(_x0 + _in, _y1 - _in - _t, _x1 - _in, _y1 - _in);
        lvy_append(_out, lvy_raise(_a2, lvy_bevel_cap(_a2, _t * 0.40), 2, "m3"));
        lvy_append(_out, lvy_raise(_c2, lvy_bevel_cap(_c2, _t * 0.40), 2, "m3"));
    }
    return _out;
}

/// A dashed incised line inset from the edge. Every textile carries it.
function lvy_fn_stitch(_mat, _x0, _y0, _x1, _y1, _b) {
    var _out = [];
    var _in = _b * 2.0;
    var _ax0 = _x0 + _in, _ay0 = _y0 + _in, _ax1 = _x1 - _in, _ay1 = _y1 - _in;
    if (_ax1 <= _ax0 || _ay1 <= _ay0) return _out;
    var _dash = max(2.5, _b * 1.1);
    var _gap = _dash * 0.85;
    var _w = max(1.0, _b * 0.28);

    // Four runs, each stepped in dash+gap. A stitch that ran continuously would be a fillet.
    var _runs = [[_ax0, _ay0, _ax1, _ay0], [_ax1, _ay0, _ax1, _ay1],
                 [_ax1, _ay1, _ax0, _ay1], [_ax0, _ay1, _ax0, _ay0]];
    for (var _r = 0; _r < 4; _r++) {
        var _rr = _runs[_r];
        var _len = point_distance(_rr[0], _rr[1], _rr[2], _rr[3]);
        if (_len <= 0) continue;
        var _dx = (_rr[2] - _rr[0]) / _len, _dy = (_rr[3] - _rr[1]) / _len;
        var _pos = 0;
        var _guard = 0;
        while (_pos < _len && _guard < 512) {
            _guard++;
            var _e = min(_len, _pos + _dash);
            lvy_append(_out, lvy_incise([[_rr[0] + _dx * _pos, _rr[1] + _dy * _pos],
                                         [_rr[0] + _dx * _e,   _rr[1] + _dy * _e]], false, _w));
            _pos = _e + _gap;
        }
    }
    return _out;
}

/// Dispatch: whatever furniture this material's frames carry.
function lvy_furniture(_mat, _x0, _y0, _x1, _y1, _b) {
    switch (_mat.furniture) {
        case LVY_FN_STUD:    return lvy_fn_stud(_mat, _x0, _y0, _x1, _y1, _b);
        case LVY_FN_BRACKET: return lvy_fn_bracket(_mat, _x0, _y0, _x1, _y1, _b);
        case LVY_FN_FILLET:  return lvy_fn_fillet(_mat, _x0, _y0, _x1, _y1, _b);
        case LVY_FN_CAP:     return lvy_fn_cap(_mat, _x0, _y0, _x1, _y1, _b);
        case LVY_FN_STITCH:  return lvy_fn_stitch(_mat, _x0, _y0, _x1, _y1, _b);
        default:             return [];
    }
}

/// Every furniture id, for the self-test's containment sweep. LVY_FN_NONE is included so the
/// dispatch is proved to return an empty list rather than fall through.
function lvy_furniture_all() {
    return [LVY_FN_NONE, LVY_FN_STUD, LVY_FN_BRACKET, LVY_FN_FILLET, LVY_FN_CAP, LVY_FN_STITCH];
}

/// ============================================================================================
/// FAMILY 1 - FRAME
/// ============================================================================================

/// How thick a frame's moulding is, as a fraction of its short side.
#macro LVY_FRAME_MARGIN 0.085

/// The content rect inside a frame - what a buyer lays their own contents out in.
///
/// ⭐ PUBLIC, AND IT IS THE FUNCTION THAT MAKES THIS A SYSTEM RATHER THAN A PICTURE. A skin pack
/// hands you an image and leaves you to guess where the inside is; every frame here can be ASKED.
/// ⛔ BOUNDED IN PIXELS AS WELL AS PROPORTIONALLY - see LVY_BEV_MAX_PX for the receipt. Unbounded,
/// an 840x796 frame took a 187-pixel moulding on every side, which left an interior too small for
/// the components laid out inside it and produced a MIRRORED label where one rect ended up
/// inside-out. A window moulding is a physical thickness; it does not grow with the window.
function lvy_frame_content(_mat, _x0, _y0, _x1, _y1) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_mat) || !is_real(_x0) || !is_real(_y0) || !is_real(_x1) || !is_real(_y1)) return [0, 0, 0, 0];
    var _prop = min(_x1 - _x0, _y1 - _y0) * LVY_FRAME_MARGIN * _mat.weight * 2.4;
    var _m = clamp(_prop, 6, LVY_FRAME_MARGIN_MAX_PX * _mat.weight);
    return [_x0 + _m, _y0 + _m, _x1 - _m, _y1 - _m];
}

/// A window frame: a raised moulding, a sunken content well, and the material's furniture between.
function lvy_frame(_mat, _x0, _y0, _x1, _y1, _state) {
    var _st = is_undefined(_state) ? LVY_ST_IDLE : _state;
    var _pts = lvy_shape_of(_mat, _x0, _y0, _x1, _y1, 1.0);
    var _b = lvy_body_depth(_mat, _pts, _st, LVY_BEV_FRAME);

    // 1. BODY.
    var _out = lvy_body(_mat, _pts, _st, false, LVY_BEV_FRAME, lvy_hash32(_mat.id + "frame"));

    // 2. FURNITURE - on the moulding, before the well is cut.
    lvy_append(_out, lvy_furniture(_mat, _x0, _y0, _x1, _y1, _b));

    // 3. WELL - sunk into the body. Emitted last so it reads as a recess in the moulding rather
    //    than a panel laid on top of it.
    var _c = lvy_frame_content(_mat, _x0, _y0, _x1, _y1);
    if (_c[2] - _c[0] > 8 && _c[3] - _c[1] > 8) {
        var _wp = lvy_shape_of(_mat, _c[0], _c[1], _c[2], _c[3], 1.0);
        lvy_append(_out, lvy_sink(_wp, lvy_bevel_cap(_wp, lvy_body_depth(_mat, _wp, _st, LVY_BEV_WELL)), 2, "m1"));
    }
    return _out;
}

/// ============================================================================================
/// FAMILY 2 - HEADER
/// ============================================================================================

/// A title bar. The material's corner treatment on the TOP two corners and square on the bottom,
/// because a header sits ON something and its lower edge is a join, not an edge.
///
/// ⛔ BUILT BY TAKING THE MATERIAL'S OWN OUTLINE FOR A DOUBLE-HEIGHT RECT AND KEEPING THE TOP HALF,
/// rather than by hand-writing a fifth corner treatment. Hand-written, the header's corners would
/// drift from the frame's the first time a treatment was improved, and a header whose corners
/// disagree with the window it belongs to is the loudest possible tell that a kit was assembled
/// from parts.
/// ⛔ THE HALF-PLANE CLIP IS lvy_clip_below AND IT IS NOT A FILTER. The first version of this
/// function kept the points above the cut line and pushed one cut point onto each end of the array,
/// which produced a SELF-INTERSECTING outline on every header whose height exceeded its corner
/// radius - visible as a dark wedge slashed across Obsidian's title bar on the four-themes sheet,
/// and present on every theme. lvy_clip_below's header carries the full diagnosis.
function lvy_header(_mat, _x0, _y0, _x1, _y1, _state) {
    var _st = is_undefined(_state) ? LVY_ST_IDLE : _state;
    var _h = _y1 - _y0;
    var _full = lvy_shape_of(_mat, _x0, _y0, _x1, _y0 + _h * 2, 1.0);
    var _pts = lvy_clip_below(_full, _y0 + _h);
    if (array_length(_pts) < 3) _pts = lvy_pts_square(_x0, _y0, _x1, _y1);
    var _out = lvy_body(_mat, _pts, _st, false, LVY_BEV_PANEL, lvy_hash32(_mat.id + "header"));
    // A header's own hairline along its lower edge, which is what separates it from the content
    // below without drawing a border.
    lvy_append(_out, lvy_incise([[_x0 + 2, _y1 - 1], [_x1 - 2, _y1 - 1]], false,
                                max(1.0, (_y1 - _y0) * 0.04)));
    return _out;
}

/// ============================================================================================
/// FAMILY 3 - PANEL
/// ============================================================================================

function lvy_panel(_mat, _x0, _y0, _x1, _y1, _state) {
    var _st = is_undefined(_state) ? LVY_ST_IDLE : _state;
    return lvy_body_rect(_mat, _x0, _y0, _x1, _y1, _st, false, LVY_BEV_PANEL,
                         lvy_hash32(_mat.id + "panel"), 1.0);
}

/// A sunken content well. The other half of a panel and used everywhere a value is displayed.
function lvy_well(_mat, _x0, _y0, _x1, _y1, _state) {
    var _st = is_undefined(_state) ? LVY_ST_IDLE : _state;
    return lvy_body_rect(_mat, _x0, _y0, _x1, _y1, _st, true, LVY_BEV_WELL,
                         lvy_hash32(_mat.id + "well"), 0.8);
}

/// ============================================================================================
/// FAMILY 4 - MODAL
/// ============================================================================================

/// A modal dialog: a scrim over the whole screen, a drop shadow, and a frame.
///
/// ⛔ EMISSION ORDER IS SCRIM, SHADOW, FRAME, AND IT IS ASSERTED. The wing constitution records a
/// closed ring appended last on the reasoning that it would "sit on top", which put a gilt band
/// across the subject on every plate a product could draw. A shadow emitted after the frame is that
/// defect exactly: a grey smear over the dialog the buyer is trying to read.
///
/// _sx0.._sy1 is the SCREEN, which is a different rect from the dialog and must be passed rather
/// than guessed - a modal drawn into a surface has no idea how big the display is.
function lvy_modal(_mat, _x0, _y0, _x1, _y1, _sx0, _sy0, _sx1, _sy1, _state) {
    var _st = is_undefined(_state) ? LVY_ST_IDLE : _state;
    var _out = [];

    // 1. SCRIM - the whole screen, in the material's deepest stop.
    lvy_append(_out, lvy_rect_fill(_sx0, _sy0, _sx1, _sy1, "m0"));

    // 2. DROP SHADOW - the dialog's own outline, offset AWAY from the lamp.
    var _sh = min(_x1 - _x0, _y1 - _y0) * 0.045;
    var _pts = lvy_shape_of(_mat, _x0, _y0, _x1, _y1, 1.0);
    lvy_append(_out, [lvy_ring_fill(lvy_move_pts(_pts, -LVY_LX * _sh, -LVY_LY * _sh),
                                    "m0", undefined, undefined)]);

    // 3. FRAME.
    lvy_append(_out, lvy_frame(_mat, _x0, _y0, _x1, _y1, _st));
    return _out;
}

/// ============================================================================================
/// FAMILY 5 - DIVIDER
/// ============================================================================================

/// An ornamental rule. Three treatments, chosen by the material's FAMILY rather than at random, so
/// a divider belongs to the interface it is drawn in.
///
///   metal, technical   an incised groove with a lozenge at its centre
///   organic, textile   a plain incised line, softer and thinner
///   mineral, made      a groove with a raised bead at its centre
function lvy_divider(_mat, _x0, _y0, _x1, _y1, _state) {
    var _out = [];
    var _cy = (_y0 + _y1) * 0.5;
    var _w = max(1.0, (_y1 - _y0) * 0.22);
    // ⛔ THE RULE IS INSET BY ITS OWN STROKE, AND THE FIRST VERSION RAN IT EDGE TO EDGE.
    // MEASURED: 7.8px outside the rect on every material, found the moment STAGE 9's containment
    // allowance was tightened from 68px to 4px. An INCISED line is three strokes - one offset
    // toward the lamp, one away, one down the middle - so its true extent is half a stroke width
    // PLUS the incise offset of 0.55 of a width, at both ends. A divider laid across a panel would
    // have bled over whatever sat beside it.
    //
    // ⭐ Same law as the trace vias and the hammered pits in lvy_char: A MARK IS NOT THE PATH IT IS
    // DRAWN ALONG. Third time in this product, and the first two were caught by an assertion that
    // was already tight while this one hid behind an allowance that was not.
    var _pad = _w * 1.06;
    lvy_append(_out, lvy_incise([[_x0 + _pad, _cy], [_x1 - _pad, _cy]], false, _w));

    var _cx = (_x0 + _x1) * 0.5;
    var _r = max(2.0, (_y1 - _y0) * 0.42);
    if (_mat.family == "metal" || _mat.family == "technical") {
        var _lz = [[_cx, _cy - _r], [_cx + _r * 0.72, _cy], [_cx, _cy + _r], [_cx - _r * 0.72, _cy]];
        lvy_append(_out, lvy_raise(_lz, lvy_bevel_cap(_lz, _r * 0.40), 2, "m3"));
    } else if (_mat.family == "mineral" || _mat.family == "made") {
        lvy_append(_out, lvy_boss(_cx, _cy, _r * 0.78, 12));
    }
    return _out;
}

/// ============================================================================================
/// FAMILY 6 - TOOLTIP
/// ============================================================================================

/// A tooltip: a small panel with a beak.
///
/// _side is 0 up, 1 right, 2 down, 3 left - the direction the beak POINTS. The beak is emitted
/// BEFORE the body so the body's bevel closes over the beak's root; emitted after, the beak's own
/// outline draws a seam across the panel edge it is supposed to grow out of.
function lvy_tooltip(_mat, _x0, _y0, _x1, _y1, _side, _state) {
    var _st = is_undefined(_state) ? LVY_ST_IDLE : _state;
    var _sd = is_undefined(_side) ? 2 : (_side % 4);
    var _out = [];
    var _k = min(_x1 - _x0, _y1 - _y0) * 0.20;
    var _cx = (_x0 + _x1) * 0.5, _cy = (_y0 + _y1) * 0.5;

    var _beak;
    switch (_sd) {
        case 0:  _beak = [[_cx - _k, _y0 + 1], [_cx, _y0 - _k], [_cx + _k, _y0 + 1]]; break;
        case 1:  _beak = [[_x1 - 1, _cy - _k], [_x1 + _k, _cy], [_x1 - 1, _cy + _k]]; break;
        case 3:  _beak = [[_x0 + 1, _cy + _k], [_x0 - _k, _cy], [_x0 + 1, _cy - _k]]; break;
        default: _beak = [[_cx + _k, _y1 - 1], [_cx, _y1 + _k], [_cx - _k, _y1 - 1]]; break;
    }
    lvy_append(_out, lvy_raise(_beak, lvy_bevel_cap(_beak, _k * 0.35), 2, "m2"));
    lvy_append(_out, lvy_body_rect(_mat, _x0, _y0, _x1, _y1, _st, false, LVY_BEV_PANEL,
                                   lvy_hash32(_mat.id + "tip"), 0.9));
    return _out;
}
