{
  "$GMScript": "v1",
  "%Name": "lvy_palette",
  "name": "lvy_palette",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}