{
  "$GMScript": "v1",
  "%Name": "lvy_shape",
  "name": "lvy_shape",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}