/// @description Clean Up

// ⛔ THE CALLER OWNS EVERY WIDGET SPRITE AND THIS IS THE CALLER. lvy_widget's header says a
// generator that hands out sprites with no stated ownership is a leak with a nice API on top; this
// event is that statement made true, and the Readme quotes it in the same words.
//
// ⛔ AND IT IS GUARDED, BECAUSE CLEAN UP ALWAYS RUNS. The headless -selftest and -bake modes exit
// part way down Create, so `widgets` may never have been assigned. A sibling product in this wing
// reported a crash AFTER a fully green suite for exactly this - "Variable not set before reading
// it" at CleanUp, attributed to the last stage the SUITE had reached, i.e. a crash blamed on code
// that had already finished and passed.
//
// Create also declares `widgets` above every early exit, so this guard is the second of two. Two,
// because either one alone is a single edit away from the same failure and the failure destroys the
// result of the run it happens in.
if (!variable_instance_exists(id, "widgets")) exit;
lvy_widget_free_all(widgets);
