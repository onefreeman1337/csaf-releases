/// @description Create

// ⛔ THE FIRST LINE OF ANY HEADLESS ENTRY POINT, AND IT IS NOT OPTIONAL.
// A GML runtime error opens a MODAL DIALOG. Headless, nothing dismisses it and the process never
// exits - a build robot then reports a 180-second timeout instead of a defect. Installing a
// handler that records the stage number and ends the game turns an opaque hang into a named line
// in a result file. This wing measured that exact conversion on a previous product: an opaque
// 180 s hang became "CRASH at stage 5: Variable Index [25] out of range [25]", a real bug.
//
// ⛔ AND IT RECORDS THE STACKTRACE, NOT JUST THE MESSAGE. A stage is a whole block calling
// hundreds of functions, so the message alone sends you guessing through the call graph. GML's
// exception struct carries .stacktrace, which names the function AND the line, and writing it
// costs one string.
//
// ⛔ THIS IS THE ONLY exception_unhandled_handler IN THE PACKAGE. Whichever is installed last
// silently wins, so two handlers is a coin toss over how much you learn from a crash.
global.lvy_stage = -1;
exception_unhandled_handler(function(_ex) {
    var _st = "";
    try {
        var _tr = _ex.stacktrace;
        for (var _i = 0; _i < array_length(_tr); _i++) {
            if (_i > 0) _st += " <- ";
            _st += string(_tr[_i]);
        }
    } catch (_e) { _st = "(no stacktrace)"; }
    var _f = file_text_open_write("lvy_crash.json");
    file_text_write_string(_f, "{\"stage\":" + string(global.lvy_stage)
        + ",\"message\":\"" + string_replace_all(string(_ex.message), "\"", "'") + "\""
        + ",\"where\":\"" + string_replace_all(_st, "\"", "'") + "\"}");
    file_text_close(_f);
    game_end(1);
});

// ⛔ THE HEADLESS BRANCHES BELOW LEAVE Create PART WAY THROUGH, AND Clean Up STILL RUNS AT GAME
// END. A sibling product in this wing threw "variable not set before reading it" AFTER a fully
// green self-test, because its Clean Up read an instance variable that the early `exit` had
// skipped past - a crash after the work is done still fails the run and still hides the result.
//
// ⚠️ THIS OBJECT CANNOT USE THAT PRODUCT'S FIX. It owns SPRITES (every widget caches one), so its
// Clean Up cannot be empty - it has to free them or the demo leaks on exit. So `widgets` is
// declared HERE, above every branch, and Clean Up guards with variable_instance_exists as well.
// Both halves, because either one alone is a single edit away from the same crash.
widgets = [];

var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i + 1) + " ";

// -- headless modes: run, write the result file, exit -----------------------------------------
if (string_pos("-selftest", _args) > 0) {
    lvy_selftest_write(lvy_selftest_run());
    game_end(0);
    exit;
}
if (string_pos("-bake", _args) > 0) {
    lvy_bake_run();
    game_end(0);
    exit;
}
if (string_pos("-frames", _args) > 0) {
    lvy_frames_run();
    game_end(0);
    exit;
}

// -- the interactive demo ---------------------------------------------------------------------
// ⛔ A RUNNABLE DEMO ROOM IS MANDATORY IN THIS WING. It is the buyer's quickstart, the source of
// the store GIF, and the only real smoke test GML permits - all three at once. A buyer who cannot
// press Play cannot evaluate the product.
//
// ⭐ AND FOR THIS PRODUCT THE DEMO IS ALSO THE SALES ARGUMENT, because the thing being sold is a
// DIFFERENCE between forty options. A screenshot shows one theme; pressing RIGHT forty times shows
// what was actually built. That is why the demo cycles rather than posing.
//
// The shortest correct use of the API is three lines and they are the three below:
//     build a theme -> make widgets from it -> draw them.
mat_idx = 0;
theme   = lvy_theme_at(mat_idx);

// One widget per family that has interactive state, so the rebuild counter means something.
// ⚠️ BUILT IN CREATE, NOT IN DRAW. surface_set_target inside a draw event nests render targets and
// on some drivers silently yields an EMPTY sprite - the exact failure shape this wing keeps
// recording. lvy_widget_draw has a guard for the case that cannot be avoided; this is the case
// that can.
w_btn   = lvy_widget(theme, "button",    60, 300, 210, 348, LVY_ST_IDLE,     0);
w_btn2  = lvy_widget(theme, "button",   230, 300, 380, 348, LVY_ST_HOVER,    0);
w_btn3  = lvy_widget(theme, "button",   400, 300, 550, 348, LVY_ST_PRESSED,  0);
w_btn4  = lvy_widget(theme, "button",   570, 300, 720, 348, LVY_ST_DISABLED, 0);
w_slide = lvy_widget(theme, "slider",    60, 380, 380, 424, LVY_ST_IDLE,   0.62);
w_gauge = lvy_widget(theme, "gauge",     60, 444, 380, 480, LVY_ST_IDLE,   0.72);
w_chk   = lvy_widget(theme, "toggle",   410, 384, 446, 420, LVY_ST_IDLE,      1);
w_scr   = lvy_widget(theme, "scrollbar",746, 176, 774, 480, LVY_ST_IDLE,   0.30);

widgets = [w_btn, w_btn2, w_btn3, w_btn4, w_slide, w_gauge, w_chk, w_scr];

// Demo state.
auto    = true;
timer   = 0;
gauge_t = 0;
cached  = true;
mx = 0; my = 0; mdown = false;
