/// @description Draw GUI

if (!variable_instance_exists(id, "widgets")) exit;

var _s = lvy_theme_surface(theme, LVY_ST_IDLE);
var _m = theme.mat;

// The page. A flat fill in the material's own ground, so the whole screen re-tints with the theme
// and a buyer can see that the ground is part of the material rather than a backdrop we chose.
draw_clear(_s.ground);

// -- the frame, with a header ------------------------------------------------------------------
lvy_draw_frame(theme, 40, 40, 800, 512, LVY_ST_IDLE);
var _c = lvy_frame_content(_m, 40, 40, 800, 512);
lvy_draw_header(theme, _c[0], _c[1], _c[2], _c[1] + 46, LVY_ST_IDLE);
lvy_draw_label(theme, string_upper(_m.name), _c[0] + 16, _c[1], _c[2] - 120, _c[1] + 46, 22,
               LVY_ST_IDLE);

// A badge on the header, carrying this material's index - the one place the accent appears at full
// strength, which is what an accent is for.
lvy_draw_badge(theme, _c[2] - 78, _c[1] + 11, _c[2] - 14, _c[1] + 35);
lvy_draw_accent_label(theme, string(mat_idx + 1) + "/" + string(lvy_corpus_count()),
                      _c[2] - 78, _c[1] + 11, _c[2] - 14, _c[1] + 35, 15);

// -- tabs --------------------------------------------------------------------------------------
var _tabs = ["MATERIAL", "STATES", "SIZES"];
for (var _i = 0; _i < 3; _i++) {
    var _tx = 70 + _i * 132;
    lvy_draw_tab(theme, _tx, 176, _tx + 124, 220, (_i == 0), LVY_ST_IDLE);
    lvy_draw_label(theme, _tabs[_i], _tx, 178, _tx + 124, 218, 14, LVY_ST_IDLE);
}

lvy_draw_divider(theme, 70, 232, 730, 244, LVY_ST_IDLE);

// -- the material's own facts, in its own ink --------------------------------------------------
var _facts = "corner " + _m.corner + " / surface " + _m.character
           + " / furniture " + _m.furniture + " / family " + _m.family;
lvy_text_line(_facts, 70, 254, 660, 15, _s.ink, false);
// ⚠️ THE HONEST NUMBER, PRINTED WHERE A BUYER SEES IT. lvy_char_min_px is the size below which
// this material's surface character stops being visible, derived from its density rather than
// asserted in prose. Printing it is the difference between a claim and a specification.
lvy_text_line("readable to " + string(round(lvy_char_min_px(_m.density))) + " px",
              70, 274, 300, 13, _s.m1, false);

// -- the widgets ------------------------------------------------------------------------------
// ⭐ TWO PATHS, AND THE DEMO LETS A BUYER SWITCH BETWEEN THEM WITH TAB. Cached is what a HUD should
// use; immediate is what a two-second menu can use. Showing both, live, with the rebuild counter
// running, is how the performance claim on the store page is made checkable rather than asserted.
if (cached) {
    for (var _i = 0; _i < array_length(widgets); _i++) lvy_widget_draw(widgets[_i]);
} else {
    lvy_draw_button(theme, w_btn.x0, w_btn.y0, w_btn.x1, w_btn.y1, w_btn.state);
    lvy_draw_button(theme, 230, 300, 380, 348, LVY_ST_HOVER);
    lvy_draw_button(theme, 400, 300, 550, 348, LVY_ST_PRESSED);
    lvy_draw_button(theme, 570, 300, 720, 348, LVY_ST_DISABLED);
    lvy_draw_slider(theme, 60, 380, 380, 424, 0.62, LVY_ST_IDLE);
    lvy_draw_gauge(theme, 60, 444, 380, 480, w_gauge.extra, 4, LVY_ST_IDLE);
    lvy_draw_check(theme, 410, 384, 446, 420, true, LVY_ST_IDLE);
    lvy_draw_scrollbar(theme, 746, 176, 774, 480, 0.30, 0.4, LVY_ST_IDLE);
}

// State labels under the four buttons, so the five states are named rather than guessed at.
var _names = ["idle / live", "hover", "pressed", "disabled"];
for (var _i = 0; _i < 4; _i++) {
    lvy_text_line(_names[_i], 60 + _i * 170, 354, 150, 12, _s.m1, false);
}

// Radio and switch beside the checkbox - the toggle family is three shapes and showing one would
// under-sell it.
lvy_draw_radio(theme, 470, 384, 506, 420, true, LVY_ST_IDLE);
lvy_draw_switch(theme, 530, 388, 610, 416, true, LVY_ST_IDLE);
lvy_draw_check(theme, 640, 384, 676, 420, false, LVY_ST_IDLE);

// A tooltip, pointing down at the slider.
lvy_draw_tooltip(theme, 420, 444, 700, 492, 2, LVY_ST_IDLE);
lvy_draw_label(theme, "every pixel drawn in GML", 420, 444, 700, 486, 14, LVY_ST_IDLE);

// The four cursors, in a row.
//
// ⛔ THE FIRST VERSION PASSED SIZE 0 AND AN x THAT NEVER MOVED - `712 + _i * 0` - so it drew four
// zero-scale cursors on top of each other, i.e. nothing at all. It compiled, it ran, and no
// assertion in this package could see it, because a demo event is not part of the suite. Found by
// reading the line back while fixing the bake sheet that shares the same helper.
for (var _i = 0; _i < 4; _i++) lvy_draw_cursor(theme, _i, 706 + _i * 26, 452, 30);

// -- the readout -------------------------------------------------------------------------------
// ⭐ THE REBUILD COUNTER IS PART OF THE PRODUCT, NOT DEBUG SCAFFOLDING. It is the only way a buyer
// can check the performance claim in their own game in five minutes without a profiler: leave the
// demo running with auto-cycle OFF and watch it stop moving.
var _hud = "LEFT/RIGHT theme   SPACE auto:" + (auto ? "on" : "off")
         + "   TAB " + (cached ? "cached" : "immediate")
         + "      sprite rebuilds " + string(global.lvy_rebuilds)
         + "      fps " + string(fps_real == 0 ? fps : round(fps_real));
lvy_text_line(_hud, 40, 524, 760, 13, _s.ink, false);
