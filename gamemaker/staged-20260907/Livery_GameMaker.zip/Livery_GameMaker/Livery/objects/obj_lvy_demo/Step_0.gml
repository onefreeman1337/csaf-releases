/// @description Step

// ⚠️ EVERY BRANCH HERE GUARDS ON `widgets`. The headless modes leave Create early, and although
// they also end the game, GameMaker runs at least one more event tick on the way out. Reading an
// undeclared instance variable there would report a crash AFTER a green self-test, attributed to
// whatever stage the suite last reached - which is the sibling defect recorded in Create.
if (!variable_instance_exists(id, "widgets")) exit;

var _n = lvy_corpus_count();
var _changed = false;

if (keyboard_check_pressed(vk_right)) { mat_idx = (mat_idx + 1) % _n;      _changed = true; auto = false; }
if (keyboard_check_pressed(vk_left))  { mat_idx = (mat_idx + _n - 1) % _n; _changed = true; auto = false; }
if (keyboard_check_pressed(vk_space)) auto = !auto;
if (keyboard_check_pressed(vk_tab))   cached = !cached;

// Auto-cycle, so the demo sells itself with nobody at the keyboard - and so the store GIF has a
// subject. Two seconds a theme at 60fps.
if (auto) {
    timer += 1;
    if (timer >= 120) { timer = 0; mat_idx = (mat_idx + 1) % _n; _changed = true; }
}

if (_changed) {
    theme = lvy_theme_at(mat_idx);
    // ⭐ THIS LOOP IS THE PRODUCT'S WHOLE PROMISE IN FOUR LINES. Re-theming an entire interface is
    // handing every widget a different theme; no layout code changes, no asset is swapped, and
    // nothing is reloaded from disk. A skin pack cannot do this without shipping forty atlases.
    for (var _i = 0; _i < array_length(widgets); _i++) lvy_widget_set_theme(widgets[_i], theme);
}

// A live gauge, so the rebuild counter has something honest to count. It moves slowly enough that
// lvy_widget_state_changed's 0.002 tolerance genuinely suppresses most frames, which is the point
// being demonstrated.
gauge_t += 0.004;
lvy_widget_set_value(w_gauge, 0.5 + 0.5 * sin(gauge_t));

// Pointer state on the first button only, so a buyer can see idle/hover/pressed resolve from a real
// mouse while the other three sit in fixed states beside it for comparison.
mx = device_mouse_x_to_gui(0);
my = device_mouse_y_to_gui(0);
mdown = mouse_check_button(mb_left);
lvy_widget_pointer(w_btn, mx, my, mdown);
