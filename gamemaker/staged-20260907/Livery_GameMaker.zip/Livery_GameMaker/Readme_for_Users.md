# LIVERY — Generated Interface Theme Corpus

**Forty complete interface themes, drawn in GML. No sprite, no nine-slice, no texture page.**

Fourteen component families × forty materials = **560 distinct drawn components**, and not one of
them is a PNG or a tint of another one. `sprites/` does not exist in this package. That is the
headline claim and it is literally true — you can check it by looking at the folder.

- GameMaker **2024.14+**, built and tested against runtime `2024.14.4.268` (the legacy runtime).
  Pure GML: no extensions, no native DLLs, no shaders.
- **1,988 in-engine assertions**, run headlessly inside a real Igor-built executable.
- **A fresh install is tested as a fresh install.** The shipped `.yymps` is imported into a blank
  project and driven by buyer code written from this Readme alone: 35 assertions, including all 560
  components built and drawn.
- **60 hostile calls** against every entry point documented below — `undefined`, negative, absurd
  and wrong-typed arguments — with 0 crashes, and a positive control proving the crash counter
  still fires.
- Raw, readable source. Every public script carries a header block explaining what it does and,
  where it matters, what went wrong before it did.

---

## 1. Quickstart

Import the `.yymps`, open **`rm_lvy_demo`**, press Play. That room is the whole API in use.

Three lines is the shortest correct program:

```gml
// Create
theme = lvy_theme("brass");

// Draw
lvy_draw_frame(theme, 40, 40, 400, 300, LVY_ST_IDLE);
lvy_draw_button(theme, 60, 240, 200, 284, LVY_ST_HOVER);
```

In the demo room: **LEFT / RIGHT** cycle the forty themes, **SPACE** toggles auto-cycling,
**TAB** switches between the cached and immediate draw paths. The on-screen readout shows the live
sprite-rebuild count, which is there so you can check the performance claim rather than take our
word for it (see §4).

---

## 2. What a theme is

A theme is a **material** with its five state surfaces resolved. A material is not a colour — it is:

| | |
| --- | --- |
| **A five-stop ramp** | through Oklch, evenly spaced in *apparent* lightness. This is what the bevel engine shades walls from, and it is why a raised button looks raised. |
| **A ground and an ink** | the ink is guaranteed readable against the ground, with an asserted floor. On a light material every ramp stop is light, so text goes in `ink` — never in `m0`. |
| **An accent** | derived from the material's own hue, and placed against the **ground** in whichever direction has room. On marble it goes *darker*. |
| **A surface character** | one of thirteen: grain, hatch, knurl, craze, weave, trace, speckle, vein, fleck, scanline, brush, pit, or none. |
| **A geometry language** | corner treatment, border weight, and what furniture the frame carries. |

**The last two are why this is not a palette swap.** Brass and bronze are eleven degrees apart in
hue; one is *brushed* and one is *pitted*. Slate and gunmetal are twenty-four degrees apart; one is
*hatched* and one is *knurled*. Choosing "porcelain" changes the geometry of all fourteen families at
once, so the result agrees with itself.

### The forty

**Metal** — blackened iron, brass, pewter, verdigris, brushed steel, gold leaf, bronze, gunmetal
**Organic** — parchment, bone, horn, oxblood leather, oak, walnut burr, cork
**Mineral** — slate, marble, obsidian, jade, sandstone, malachite
**Made** — vermilion lacquer, enamel, porcelain, bakelite, smoked glass, amber resin, celluloid
**Textile** — felt, linen, velvet, canvas, brocade
**Technical** — circuit board, cathode, plasma, holographic, carbon fibre, anodised, phosphor

---

## 3. The fourteen families

`frame` · `header` · `panel` · `modal` · `divider` · `tooltip` · `button` · `toggle` (check, radio
and switch) · `slider` · `gauge` · `tab` · `scrollbar` · `badge` · `cursor` (pointer, hand, text,
busy)

Every one takes a **rectangle in pixels** and a state, and nothing else:

```gml
lvy_draw_gauge(theme, x0, y0, x1, y1, 0.72, 4, LVY_ST_IDLE);
lvy_draw_slider(theme, x0, y0, x1, y1, 0.5,  LVY_ST_HOVER);
lvy_draw_check (theme, x0, y0, x1, y1, true, LVY_ST_IDLE);
```

**Components are built in pixel space, never authored small and scaled.** Corner radius and bevel
depth come off the *shorter* side and are bounded in absolute pixels as well as proportionally, so a
40×18 button and a 400×180 frame are both correct rather than one being a stretched copy of the
other. The `CORRECT AT EVERY SIZE` store image is that claim rendered from 24 px to 140 px.

### The five states are five objects, not five tints

`LVY_ST_IDLE` · `LVY_ST_HOVER` · `LVY_ST_PRESSED` · `LVY_ST_DISABLED` · `LVY_ST_FOCUS`

**Pressed inverts the bevel** and offsets the cap along the lamp's shadow side, so it reads as the
same button pushed in rather than as a different, darker button. **Disabled flattens the ramp and
pulls chroma toward neutral** — a *pull*, not a scale, which is why it reads on slate (chroma 0.006)
as clearly as on brass (chroma 0.09). **Focus adds a ring outside the component**, so it never
changes the usable area between states.

### The content rect

```gml
var _c = lvy_frame_content(theme.mat, x0, y0, x1, y1);   // [x0, y0, x1, y1] inside the moulding
```

A skin pack hands you an image and leaves you to guess where the inside is. Every frame here can be
asked.

---

## 4. Performance, and the cache

An interface is on screen every frame and is the most redrawn surface in any game. A generated
interface that costs more than the nine-slice it replaces would be a worse product than the thing it
replaces, however good it looks. So there are two paths and both are supported:

**Immediate** — `lvy_draw_*`. Rebuilds geometry every call. Correct for a menu that is on screen for
two seconds; the wrong choice for a HUD.

**Cached** — `lvy_widget`. Renders once into a sprite and rebuilds only when something that changes
its appearance changes.

```gml
// Create
hp = lvy_widget(theme, "gauge", 20, 20, 240, 46, LVY_ST_IDLE, 1.0);

// Step
lvy_widget_set_value(hp, player_hp / player_hp_max);

// Draw
lvy_widget_draw(hp);

// Clean Up   -- YOU OWN THE SPRITE. This is not optional.
lvy_widget_free(hp);
```

- `global.lvy_rebuilds` counts every rebuild. Leave the demo running with auto-cycle off and watch
  it stop moving — that is the whole performance claim, checkable in five minutes without a
  profiler.
- **Build widgets in Create, not in Draw.** `surface_set_target` inside a draw event nests render
  targets and on some drivers yields an empty sprite. `lvy_widget_draw` detects that case and falls
  back to immediate drawing for one frame rather than showing you a blank, but the supported path is
  Create.
- Re-theming an entire interface is one call per widget: `lvy_widget_set_theme(w, other_theme)`.
  No asset is swapped and nothing is reloaded from disk.

`lvy_widget_hit` and `lvy_widget_pointer` are the only interaction helpers, and that is deliberate —
layout, focus order and event routing belong to your game, and a half-framework that fights yours is
worth less than none.

---

## 5. Making it yours

- **The lamp is settable.** `lvy_lamp_set(lx, ly)` re-aims the light for every component at once;
  `lvy_lamp_reset()` puts it back. Re-aiming it *per component* is what makes an interface look
  assembled from stock parts, so the API encourages the global move.
- **Add a material** by adding one row to `lvy_corpus()` in `lvy_material`. Everything else is
  derived — all fourteen families will draw it, and the self-test will check its ramp separation,
  its ink contrast, its state distinctness and its character size-honesty automatically.
- **Nothing is random at draw time.** Every surface is seeded from the material id, so a button
  redrawn on frame 2 is identical to the same button on frame 1.

### Namespacing

Every function, macro and global in this package is prefixed `lvy_` / `LVY_` (`global.lvy_lx`,
`global.lvy_ly`, `global.lvy_rebuilds`, `global.lvy_corpus_cache`, `global.lvy_fam_cache`,
`global.lvy_stage`). GML's global namespace is flat, and a collision in your project is a support
ticket nobody can debug remotely.

There are **no absolute paths** and **no hardcoded room or layer indices** anywhere in the package.

---

## 6. Honest limits

- **GML cannot be unit-tested outside the engine.** The 1,988 assertions run *inside* a real
  Igor-built executable, which is the strongest thing this language permits — and they test
  contracts (winding, containment, colour separation, determinism, emission order), not pictures.
  Several defects in this product's own development passed every assertion and were found by opening
  a PNG and looking at it. That step is not replaceable and we do not pretend otherwise.
- **Built against the legacy GMS2 runtime.** GameMaker's own 2026 roadmap marks that runtime feature
  complete with support "until at least Q1 2028", and GMRT states 99% compatibility. This package is
  a pure-GML runtime library with no extension surface, which is the shape most likely to carry
  forward — but GMRT support is not tested here and is not claimed.
- **A fine surface character on a very large component is hundreds of strokes.** That is what a fine
  hatch *is*. Use the cached path for anything persistent; the demo shows the cost either way.
- **Five of the forty materials carry no surface character at all** — lacquer, enamel, bakelite,
  smoked glass and obsidian are smooth, because those materials are smooth. They are told apart by
  hue, ramp spread, corner treatment and furniture.

---

## 7. Files

```
Livery/
  scripts/     13 scripts, all lvy_-prefixed, all raw and commented
  objects/     obj_lvy_demo        the demo, and the headless -selftest / -bake entry points
  rooms/       rm_lvy_demo         press Play here
  fonts/       fnt_livery, fnt_livery_title  (+ Apache-2.0.txt, THIRD-PARTY-NOTICES.txt)
```

`lvy_geom`, `lvy_palette`, `lvy_relief` and `lvy_render` are this studio's shared drawing
foundation, carried forward across several products with more than 2,300 prior in-engine assertions
behind them. `lvy_render` is the only file in the package that talks to the GPU.

---

## 8. Licence and AI disclosure

See `LICENSE.txt`. In short: build whatever you want with it, in unlimited commercial games; do not
resell or redistribute the package itself.

**This product was created with AI assistance.** Code: yes. Graphics: yes — every pixel is generated
by the GML in this package. Sounds: none in this package.

Fonts are third-party and separately licensed — see `Livery/fonts/THIRD-PARTY-NOTICES.txt`.

Copyright © 2026 Core Systems Asset Factory.
