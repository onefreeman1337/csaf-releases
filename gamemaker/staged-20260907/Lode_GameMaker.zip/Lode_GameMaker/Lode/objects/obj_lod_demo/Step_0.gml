/// @description Step - the demo's controls

// ⚠️ EVERY KEY HERE IS ALSO PRINTED ON SCREEN BY THE DRAW EVENT. A demo whose controls are only in
// the Readme is a demo a buyer closes after ten seconds, and the demo room is this wing's
// quickstart, its GIF source and its only real smoke test all at once.

if (is_undefined(data)) exit;

var _dirty = false;

// -- which species ------------------------------------------------------------------------------
if (keyboard_check_pressed(ord("Q"))) {
    species_i = (species_i + LOD_SPECIES_N - 1) % LOD_SPECIES_N;
    _dirty = true;
}
if (keyboard_check_pressed(ord("W"))) {
    species_i = (species_i + 1) % LOD_SPECIES_N;
    _dirty = true;
}
if (keyboard_check_pressed(vk_space)) {
    seed += 1;
    _dirty = true;
}

// -- how far the stone has been worked ----------------------------------------------------------
// ⭐ THIS IS THE CONTROL WORTH PUTTING IN A GIF: holding one species and one seed and stepping
// rough -> extracted -> cut -> polished redraws the same stone four ways from the same two
// integers, which is the product's central claim happening in front of the buyer.
if (keyboard_check_pressed(ord("A"))) { state = max(0, state - 1); _dirty = true; }
if (keyboard_check_pressed(ord("S"))) { state = min(3, state + 1); _dirty = true; }

// -- the assay kit ------------------------------------------------------------------------------
// Watching the candidate shortlist shrink as the kit improves is the system half of the product.
if (keyboard_check_pressed(ord("Z"))) { skill = max(0, skill - 0.15); _dirty = true; }
if (keyboard_check_pressed(ord("X"))) { skill = min(1, skill + 0.15); _dirty = true; }

// -- prospecting --------------------------------------------------------------------------------
if (keyboard_check_pressed(vk_left))  { depth = max(0, depth - 0.05); }
if (keyboard_check_pressed(vk_right)) { depth = min(1, depth + 0.05); }
if (keyboard_check_pressed(ord("P"))) {
    // ⚠️ lod_prospect CAN RETURN -1 AND THAT IS THE POINT. An empty pan is what makes a strike
    // mean anything, so the demo shows it rather than quietly re-rolling until something appears.
    var _got = lod_prospect(depth, seed * 31 + current_time);
    last_pan = _got;
    if (_got >= 0) {
        species_i = _got;
        state = 0;
        _dirty = true;
    }
}

if (keyboard_check_pressed(ord("C"))) show_cabinet = !show_cabinet;

if (_dirty) {
    data = lod_demo_state(species_i, seed, state, skill);
    // A stone the player has actually looked at goes into the case, which is what makes the
    // completion figure on screen mean something rather than being decoration.
    lod_cabinet_add(cab, data.stone);
}
