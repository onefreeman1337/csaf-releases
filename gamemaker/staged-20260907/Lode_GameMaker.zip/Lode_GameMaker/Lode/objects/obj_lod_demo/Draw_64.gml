/// @description Draw GUI - the demo

// ⛔ DRAWN IN THE GUI EVENT so the demo is resolution-independent and a buyer resizing the window
// does not have to reason about views to see the product.

if (is_undefined(data)) exit;

var _W = display_get_gui_width();
var _H = display_get_gui_height();

var _page  = lod_oklch(0.140, 0.009, 252);
var _ink   = lod_oklch(0.895, 0.010, 252);
var _dim   = lod_oklch(0.570, 0.010, 252);
var _warm  = lod_oklch(0.740, 0.080, 66);
var _panel = lod_oklch(0.195, 0.010, 252);

draw_set_colour(_page);
draw_rectangle(0, 0, _W, _H, false);

lod_lamp_reset();

// -- the stone ----------------------------------------------------------------------------------
var _sw = _W * 0.52;
draw_set_colour(_panel);
draw_rectangle(24, 24, 24 + _sw, _H - 24, false);
lod_render_in_rect_tight(data.parts, data.pal, 40, 44, _sw - 32, _H - 128, undefined);

lod_text_line(lod_specimen_label(data.stone), 40, _H - 76, _sw - 32, 22, _ink, true);
lod_text_line(lod_specimen_line(data.stone), 40, _H - 48, _sw - 32, 16, _dim, false);

// -- the readout --------------------------------------------------------------------------------
var _rx = _W * 0.56;
var _rw = _W - _rx - 24;

if (show_cabinet) {
    // The cabinet. Forty-eight slots, each showing the best state that species has reached.
    lod_text_line("THE CABINET", _rx, 30, _rw, 22, _warm, true);
    lod_text_line(string(cab.found) + " of " + string(LOD_SPECIES_N) + " species found   "
                + string_format(lod_cabinet_completion(cab) * 100, 1, 1) + " per cent complete",
                  _rx, 58, _rw, 15, _dim, false);
    var _cols = 8;
    var _cell = min((_rw - 8) / _cols, (_H - 130) / 6);
    for (var _i = 0; _i < LOD_SPECIES_N; _i++) {
        var _cx = _rx + (_i % _cols) * _cell;
        var _cy = 90 + floor(_i / _cols) * _cell;
        draw_set_colour(_panel);
        draw_rectangle(_cx + 2, _cy + 2, _cx + _cell - 2, _cy + _cell - 2, false);
        if (cab.slots[_i] >= 0) {
            lod_specimen_draw(lod_specimen(_i, 3100 + _i * 37, cab.slots[_i]),
                              _cx + 4, _cy + 4, _cell - 8, _cell - 8);
        } else {
            // An empty slot is a SILHOUETTE, not a blank: a collection screen has to show you what
            // you are missing or it is a list of things you already have.
            draw_set_colour(lod_oklch(0.250, 0.008, 252));
            draw_rectangle(_cx + _cell * 0.3, _cy + _cell * 0.34,
                           _cx + _cell * 0.7, _cy + _cell * 0.7, false);
        }
    }
} else {
    var _lines = lod_demo_lines(data, skill);
    var _ly = 30;
    for (var _i = 0; _i < array_length(_lines); _i++) {
        if (_lines[_i] != "") {
            lod_text_line(_lines[_i], _rx, _ly, _rw, (_i == 0) ? 22 : 16,
                          (_i == 0) ? _warm : ((_i == 1) ? _dim : _ink), (_i == 0));
        }
        _ly += (_i == 0) ? 32 : 24;
    }
    _ly += 6;
    lod_text_body(lod_demo_candidates(data, 8), _rx, _ly, _rw, 15, _warm);
    _ly += 56;

    // The column, and where the player is digging in it.
    lod_text_line("DEPTH " + string_format(depth, 1, 2) + "   ("
                + lod_band_names()[clamp(round(depth * (LOD_BAND_N - 1)), 0, LOD_BAND_N - 1)] + " zone)",
                  _rx, _ly, _rw, 16, _ink, true);
    draw_set_colour(_panel);
    draw_rectangle(_rx, _ly + 24, _rx + _rw, _ly + 40, false);
    draw_set_colour(_warm);
    draw_rectangle(_rx + depth * (_rw - 6), _ly + 24, _rx + depth * (_rw - 6) + 6, _ly + 40, false);
    _ly += 52;
    if (last_pan == -1) {
        lod_text_line("the pan came up empty", _rx, _ly, _rw, 15, _dim, false);
    } else if (last_pan >= 0) {
        lod_text_line("panned: " + lod_species(last_pan).name, _rx, _ly, _rw, 15, _warm, false);
    }
}

// -- the controls, on screen, always -------------------------------------------------------------
var _keys = "Q/W species    SPACE reseed    A/S rough-cut-polish    Z/X assay kit    "
          + "LEFT/RIGHT depth    P pan    C cabinet";
lod_text_line(_keys, 24, _H - 20, _W - 48, 14, _dim, false);
