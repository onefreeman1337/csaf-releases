/// @description Clean Up

// ⛔ THIS EVENT IS DELIBERATELY EMPTY, AND THE EMPTINESS IS THE POINT.
//
// A stone is PLAIN DATA. lod_specimen returns a struct of numbers and a corpus row; lod_specimen_parts
// returns arrays of numbers. Nothing in this package allocates a sprite, a surface, a buffer, a
// texture page or a ds_* structure that has to be freed, so there is nothing here to free. A buyer
// can generate ten thousand specimens in a loop and drop them on the floor, and GameMaker's garbage
// collector is the entire cleanup story.
//
// ⚠️ THE TWO EXCEPTIONS ARE OPT-IN AND THEY ARE THE CALLER'S. lod_render_to_sprite hands back a
// sprite, and whoever asks for one owns it; lod_bk_ink_bounds creates a buffer and frees it in the
// same function. Nothing in this package leaks either, and this demo calls neither.
//
// It is written out rather than deleted because Clean Up ALWAYS runs, including after the headless
// -selftest and -bake modes exit part way down Create. A sibling product in this wing reported a
// crash AFTER a fully green suite because this event read a variable those early exits had skipped,
// and the crash was attributed to the last stage the SUITE had reached - i.e. blamed on code that
// had already finished and passed. An event that is empty on purpose cannot do that; an event
// somebody adds a line to later can, so the warning lives here where they will be standing.
