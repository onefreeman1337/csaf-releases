/// LODE - lod_corpus. The 48 mineral species and the vocabulary they are built from.
///
/// ============================================================================================
/// GENERATED FILE - DO NOT EDIT BY HAND.
///
/// Written by Internal_Ops/emit_corpus.js from Internal_Ops/minerals.js, which is the ONE
/// declaration of this corpus. Internal_Ops/corpus_identical.js re-emits this file and compares
/// BYTES, so a hand edit here is found by the next check rather than shipped.
///
/// ⛔ WHY IT IS GENERATED RATHER THAN TYPED. The corpus carries guarantees that are PROVEN in
/// JS by Internal_Ops/audit_corpus.js - that no two species share a (habit, lustre, zoning)
/// triple and are therefore one drawing; that every family owns at least one habit no other
/// family uses, so a family cannot be a permutation of another; and that every vocabulary entry
/// is REACHED, so "21 crystal habits" means twenty-one a buyer can actually see. A second,
/// hand-typed copy of the same table would make every one of those proofs a statement about a
/// file the engine never reads.
///
/// ⛔ APPEND ONLY, every table. A saved specimen resolves its seed into these INDICES, so
/// reordering any list silently rewrites every stone already sitting in a buyer's save file.
/// ============================================================================================

#macro LOD_SPECIES_N 48
#macro LOD_HABIT_N 21
#macro LOD_LUSTRE_N 10
#macro LOD_ZONING_N 10
#macro LOD_CUT_N 10
#macro LOD_MATRIX_N 8
#macro LOD_BAND_N 7

/// The sentinel for "this species is never cut" - stored as a number because a struct field
/// read back as undefined is indistinguishable from a field nobody set.
#macro LOD_CUT_NONE -1

/// The 21 habit names, in corpus order. APPEND ONLY.
function lod_habit_names() {
    return ["prismatic", "acicular", "botryoidal", "dendritic", "geode", "massive", "tabular", "rhombohedral", "octahedral", "cubic", "bladed", "stellate", "druzy", "fibrous", "reniform", "columnar", "encrusting", "scalenohedral", "wire", "nodular", "pyritohedral"];
}

/// The 10 lustre names, in corpus order. APPEND ONLY.
function lod_lustre_names() {
    return ["metallic", "vitreous", "adamantine", "silky", "pearly", "resinous", "greasy", "earthy", "submetallic", "waxy"];
}

/// The 10 zoning names, in corpus order. APPEND ONLY.
function lod_zoning_names() {
    return ["uniform", "banded", "zoned", "phantom", "included", "chatoyant", "asterism", "iridescent", "speckled", "mottled"];
}

/// The 10 cut names, in corpus order. APPEND ONLY.
function lod_cut_names() {
    return ["brilliant", "step", "rose", "cabochon", "marquise", "trillion", "pear", "baguette", "oval", "cushion"];
}

/// The 8 matrix names, in corpus order. APPEND ONLY.
function lod_matrix_names() {
    return ["granite", "basalt", "limestone", "shale", "quartzite", "schist", "sandstone", "serpentinite"];
}

/// The 7 band names, in corpus order. APPEND ONLY.
function lod_band_names() {
    return ["alluvial", "oxide", "sulphide", "vein", "pegmatite", "skarn", "deep"];
}

/// Build the species table. Called once; lod_corpus() caches it.
///
/// Fields:
///   name      display name, ASCII, fits the cabinet caption at its measured width
///   family    drawing family - each owns at least one habit no other family uses
///   habit     index into lod_habit_names()   - the SILHOUETTE program
///   lustre    index into lod_lustre_names()  - the SHADING program
///   zoning    index into lod_zoning_names()  - the COLOUR DISTRIBUTION program
///   cut       index into lod_cut_names(), or LOD_CUT_NONE for a species never faceted
///   matrix    index into lod_matrix_names()  - the host rock it is drawn sitting in
///   band      index into lod_band_names()    - where in the column it forms
///   hue       base hue in degrees, 0..360
///   sat       base saturation 0..1  (mapped to an Oklch chroma by lod_material)
///   val       base value 0..1       (mapped to an Oklch lightness by lod_material)
///   hardness  Mohs 1..10 - gates which tool can cut it
///   density   g/cm3 - the assay reading, and the only number a player can measure early
///   rarity    0..1 - drives spawn weight
function lod_corpus_build() {
    return [
        { name: "Gold", family: "native", habit: 18, lustre: 0, zoning: 0, cut: LOD_CUT_NONE, matrix: 4, band: 3, hue: 47, sat: 0.86, val: 0.88, hardness: 2.5, density: 19.3, rarity: 0.94 },
        { name: "Silver", family: "native", habit: 18, lustre: 8, zoning: 0, cut: LOD_CUT_NONE, matrix: 0, band: 3, hue: 210, sat: 0.06, val: 0.86, hardness: 2.5, density: 10.5, rarity: 0.82 },
        { name: "Copper", family: "native", habit: 3, lustre: 0, zoning: 0, cut: LOD_CUT_NONE, matrix: 1, band: 1, hue: 18, sat: 0.72, val: 0.62, hardness: 3, density: 8.9, rarity: 0.55 },
        { name: "Platinum", family: "native", habit: 19, lustre: 0, zoning: 0, cut: LOD_CUT_NONE, matrix: 7, band: 0, hue: 200, sat: 0.04, val: 0.78, hardness: 4, density: 21.4, rarity: 0.97 },
        { name: "Bismuth", family: "native", habit: 6, lustre: 0, zoning: 7, cut: LOD_CUT_NONE, matrix: 0, band: 3, hue: 300, sat: 0.45, val: 0.7, hardness: 2.2, density: 9.8, rarity: 0.71 },
        { name: "Electrum", family: "native", habit: 3, lustre: 0, zoning: 8, cut: LOD_CUT_NONE, matrix: 4, band: 3, hue: 52, sat: 0.55, val: 0.82, hardness: 2.6, density: 15, rarity: 0.88 },
        { name: "Pyrite", family: "sulphide", habit: 20, lustre: 0, zoning: 0, cut: LOD_CUT_NONE, matrix: 3, band: 2, hue: 50, sat: 0.62, val: 0.72, hardness: 6.2, density: 5, rarity: 0.22 },
        { name: "Galena", family: "sulphide", habit: 9, lustre: 0, zoning: 0, cut: LOD_CUT_NONE, matrix: 2, band: 2, hue: 220, sat: 0.05, val: 0.55, hardness: 2.6, density: 7.6, rarity: 0.38 },
        { name: "Chalcopyrite", family: "sulphide", habit: 8, lustre: 8, zoning: 7, cut: LOD_CUT_NONE, matrix: 5, band: 2, hue: 45, sat: 0.7, val: 0.58, hardness: 3.7, density: 4.2, rarity: 0.44 },
        { name: "Cinnabar", family: "sulphide", habit: 2, lustre: 2, zoning: 0, cut: 3, matrix: 3, band: 1, hue: 356, sat: 0.82, val: 0.62, hardness: 2.2, density: 8.1, rarity: 0.79 },
        { name: "Stibnite", family: "sulphide", habit: 1, lustre: 0, zoning: 0, cut: LOD_CUT_NONE, matrix: 4, band: 3, hue: 215, sat: 0.08, val: 0.48, hardness: 2, density: 4.6, rarity: 0.68 },
        { name: "Sphalerite", family: "sulphide", habit: 8, lustre: 5, zoning: 2, cut: 0, matrix: 2, band: 2, hue: 28, sat: 0.68, val: 0.42, hardness: 3.7, density: 4.1, rarity: 0.49 },
        { name: "Hematite", family: "oxide", habit: 14, lustre: 8, zoning: 1, cut: 3, matrix: 6, band: 1, hue: 5, sat: 0.45, val: 0.38, hardness: 6, density: 5.3, rarity: 0.26 },
        { name: "Magnetite", family: "oxide", habit: 8, lustre: 0, zoning: 0, cut: LOD_CUT_NONE, matrix: 1, band: 6, hue: 220, sat: 0.1, val: 0.22, hardness: 6, density: 5.2, rarity: 0.31 },
        { name: "Rutile", family: "oxide", habit: 1, lustre: 2, zoning: 4, cut: 0, matrix: 4, band: 4, hue: 22, sat: 0.78, val: 0.55, hardness: 6.2, density: 4.2, rarity: 0.63 },
        { name: "Cassiterite", family: "oxide", habit: 19, lustre: 2, zoning: 3, cut: 1, matrix: 0, band: 4, hue: 30, sat: 0.55, val: 0.3, hardness: 6.5, density: 7, rarity: 0.66 },
        { name: "Corundum", family: "oxide", habit: 0, lustre: 2, zoning: 6, cut: 3, matrix: 5, band: 5, hue: 350, sat: 0.72, val: 0.6, hardness: 9, density: 4, rarity: 0.9 },
        { name: "Quartz", family: "silicate", habit: 0, lustre: 1, zoning: 3, cut: 0, matrix: 0, band: 3, hue: 200, sat: 0.05, val: 0.92, hardness: 7, density: 2.65, rarity: 0.1 },
        { name: "Amethyst", family: "silicate", habit: 4, lustre: 1, zoning: 2, cut: 8, matrix: 1, band: 3, hue: 278, sat: 0.55, val: 0.68, hardness: 7, density: 2.65, rarity: 0.34 },
        { name: "Tourmaline", family: "silicate", habit: 15, lustre: 1, zoning: 2, cut: 7, matrix: 0, band: 4, hue: 140, sat: 0.6, val: 0.55, hardness: 7.5, density: 3.1, rarity: 0.61 },
        { name: "Beryl", family: "silicate", habit: 0, lustre: 1, zoning: 4, cut: 1, matrix: 0, band: 4, hue: 158, sat: 0.62, val: 0.62, hardness: 7.8, density: 2.7, rarity: 0.83 },
        { name: "Garnet", family: "silicate", habit: 8, lustre: 1, zoning: 0, cut: 9, matrix: 5, band: 5, hue: 350, sat: 0.68, val: 0.42, hardness: 7.2, density: 3.9, rarity: 0.4 },
        { name: "Topaz", family: "silicate", habit: 0, lustre: 1, zoning: 2, cut: 6, matrix: 0, band: 4, hue: 38, sat: 0.42, val: 0.85, hardness: 8, density: 3.5, rarity: 0.7 },
        { name: "Peridot", family: "silicate", habit: 19, lustre: 1, zoning: 0, cut: 4, matrix: 1, band: 6, hue: 88, sat: 0.65, val: 0.7, hardness: 6.8, density: 3.3, rarity: 0.64 },
        { name: "Zircon", family: "silicate", habit: 17, lustre: 2, zoning: 3, cut: 5, matrix: 0, band: 4, hue: 25, sat: 0.5, val: 0.72, hardness: 7.5, density: 4.7, rarity: 0.72 },
        { name: "Calcite", family: "carbonate", habit: 7, lustre: 1, zoning: 3, cut: LOD_CUT_NONE, matrix: 2, band: 3, hue: 45, sat: 0.1, val: 0.9, hardness: 3, density: 2.7, rarity: 0.12 },
        { name: "Malachite", family: "carbonate", habit: 2, lustre: 3, zoning: 1, cut: 3, matrix: 6, band: 1, hue: 148, sat: 0.72, val: 0.42, hardness: 3.8, density: 4, rarity: 0.52 },
        { name: "Azurite", family: "carbonate", habit: 6, lustre: 1, zoning: 2, cut: 3, matrix: 6, band: 1, hue: 218, sat: 0.8, val: 0.45, hardness: 3.8, density: 3.8, rarity: 0.67 },
        { name: "Rhodochrosite", family: "carbonate", habit: 2, lustre: 4, zoning: 1, cut: 3, matrix: 2, band: 3, hue: 348, sat: 0.55, val: 0.72, hardness: 3.8, density: 3.7, rarity: 0.75 },
        { name: "Siderite", family: "carbonate", habit: 7, lustre: 4, zoning: 0, cut: LOD_CUT_NONE, matrix: 3, band: 3, hue: 32, sat: 0.45, val: 0.55, hardness: 4, density: 3.9, rarity: 0.36 },
        { name: "Fluorite", family: "halide", habit: 8, lustre: 1, zoning: 2, cut: 9, matrix: 2, band: 3, hue: 268, sat: 0.48, val: 0.72, hardness: 4, density: 3.2, rarity: 0.3 },
        { name: "Halite", family: "halide", habit: 9, lustre: 1, zoning: 0, cut: LOD_CUT_NONE, matrix: 3, band: 1, hue: 15, sat: 0.18, val: 0.88, hardness: 2.2, density: 2.2, rarity: 0.18 },
        { name: "Selenite", family: "halide", habit: 13, lustre: 3, zoning: 5, cut: LOD_CUT_NONE, matrix: 3, band: 1, hue: 50, sat: 0.06, val: 0.94, hardness: 2, density: 2.3, rarity: 0.24 },
        { name: "Barite", family: "halide", habit: 6, lustre: 4, zoning: 0, cut: LOD_CUT_NONE, matrix: 2, band: 3, hue: 40, sat: 0.14, val: 0.8, hardness: 3.2, density: 4.5, rarity: 0.33 },
        { name: "Apatite", family: "phosphate", habit: 0, lustre: 1, zoning: 0, cut: 8, matrix: 5, band: 5, hue: 172, sat: 0.55, val: 0.68, hardness: 5, density: 3.2, rarity: 0.42 },
        { name: "Turquoise", family: "phosphate", habit: 19, lustre: 9, zoning: 9, cut: 3, matrix: 6, band: 1, hue: 178, sat: 0.55, val: 0.72, hardness: 5.5, density: 2.8, rarity: 0.58 },
        { name: "Vivianite", family: "phosphate", habit: 10, lustre: 1, zoning: 2, cut: LOD_CUT_NONE, matrix: 3, band: 1, hue: 195, sat: 0.55, val: 0.4, hardness: 1.8, density: 2.7, rarity: 0.77 },
        { name: "Lazulite", family: "phosphate", habit: 6, lustre: 1, zoning: 0, cut: 5, matrix: 4, band: 5, hue: 222, sat: 0.62, val: 0.5, hardness: 5.8, density: 3.1, rarity: 0.69 },
        { name: "Opal", family: "amorphous", habit: 5, lustre: 9, zoning: 7, cut: 3, matrix: 6, band: 1, hue: 190, sat: 0.35, val: 0.85, hardness: 5.8, density: 2.1, rarity: 0.86 },
        { name: "Amber", family: "amorphous", habit: 19, lustre: 5, zoning: 4, cut: 3, matrix: 3, band: 0, hue: 35, sat: 0.78, val: 0.75, hardness: 2.3, density: 1.1, rarity: 0.73 },
        { name: "Jet", family: "amorphous", habit: 5, lustre: 9, zoning: 0, cut: 3, matrix: 3, band: 0, hue: 25, sat: 0.1, val: 0.14, hardness: 3, density: 1.3, rarity: 0.46 },
        { name: "Obsidian", family: "amorphous", habit: 5, lustre: 1, zoning: 1, cut: 2, matrix: 1, band: 0, hue: 280, sat: 0.12, val: 0.16, hardness: 5.5, density: 2.4, rarity: 0.2 },
        { name: "Agate", family: "aggregate", habit: 19, lustre: 9, zoning: 1, cut: 3, matrix: 1, band: 1, hue: 22, sat: 0.4, val: 0.68, hardness: 6.8, density: 2.6, rarity: 0.28 },
        { name: "Chrysocolla", family: "aggregate", habit: 16, lustre: 6, zoning: 9, cut: 3, matrix: 6, band: 1, hue: 182, sat: 0.62, val: 0.6, hardness: 3, density: 2.2, rarity: 0.5 },
        { name: "Smithsonite", family: "aggregate", habit: 2, lustre: 4, zoning: 9, cut: 3, matrix: 2, band: 1, hue: 168, sat: 0.38, val: 0.78, hardness: 4.5, density: 4.4, rarity: 0.62 },
        { name: "Wavellite", family: "aggregate", habit: 11, lustre: 1, zoning: 2, cut: LOD_CUT_NONE, matrix: 4, band: 1, hue: 95, sat: 0.5, val: 0.65, hardness: 3.8, density: 2.4, rarity: 0.65 },
        { name: "Uvarovite", family: "silicate", habit: 12, lustre: 1, zoning: 0, cut: LOD_CUT_NONE, matrix: 7, band: 6, hue: 142, sat: 0.8, val: 0.46, hardness: 7.5, density: 3.8, rarity: 0.85 },
        { name: "Goethite", family: "oxide", habit: 2, lustre: 7, zoning: 1, cut: LOD_CUT_NONE, matrix: 6, band: 1, hue: 30, sat: 0.55, val: 0.35, hardness: 5.2, density: 4.3, rarity: 0.15 },
    ];
}

/// The species table, built once per run.
///
/// ⚠️ CACHED IN A GLOBAL AND NAMESPACED TO THE PRODUCT. GML's global namespace is flat, so an
/// unprefixed cache name is a collision in a buyer's project that nobody can debug remotely.
function lod_corpus() {
    if (!variable_global_exists("lod_corpus_cache")) {
        global.lod_corpus_cache = lod_corpus_build();
    }
    return global.lod_corpus_cache;
}

/// One species by index. Clamped rather than throwing: a buyer indexing off the end of the
/// corpus should get a stone, not a crash inside their draw event.
/// ⛔ THE CLAMP ABOVE ONLY EVER HANDLED "OFF THE END", NOT "NOT A NUMBER AT ALL", AND THAT DEFEATED
/// THE COMMENT'S OWN PROMISE. `clamp` requires numbers, so lod_species("Amethyst") threw
/// "clamp argument 1 incorrect type (string)" INSIDE THE BUYER'S DRAW EVENT - the exact outcome the
/// line above says the clamp exists to prevent. Measured 2026-09-07 by the fresh-install harness on
/// its first run, and it is the likeliest mistake in the API: the Readme quickstart nests
/// lod_species_index("Amethyst") inside lod_specimen(), so dropping the inner call lands here.
///
/// The numeric contract is UNCHANGED - an index off either end still clamps and still returns a
/// stone. Only the non-numeric case is new, and it refuses with `undefined` rather than handing
/// back species 0, because a real wrong mineral is the fail-open shape this package rejects
/// everywhere else. lod_specimen tests the result, so one bad call stays one bad call.
function lod_species(_i) {
    if (!is_numeric(_i)) return undefined;
    var _c = lod_corpus();
    return _c[clamp(_i, 0, array_length(_c) - 1)];
}

/// The index of a species by name, or -1. Linear over 48 entries, which is nothing, and it
/// avoids shipping a second lookup structure that could disagree with the table.
function lod_species_index(_name) {
    var _c = lod_corpus();
    for (var _i = 0; _i < array_length(_c); _i++) {
        if (_c[_i].name == _name) return _i;
    }
    return -1;
}
