/// LODE - lod_rock. The eight host rocks a specimen is bedded in.
///
/// ============================================================================================
/// THE MATRIX IS HALF THE PICTURE.
///
/// A crystal drawn on nothing is a shape. A crystal drawn growing out of a block of laminated
/// shale is a SPECIMEN, and the difference is the whole reason a mineral pack looks like a
/// mineral pack. It also carries information the player uses: the rock tells them which depth
/// band they are in before they have assayed anything.
///
/// ⛔ EACH ROCK HAS A GRAIN PROGRAM OF ITS OWN, AND THEY ARE DIFFERENT PROGRAMS RATHER THAN ONE
/// NOISE FUNCTION AT EIGHT AMPLITUDES. Granite is SPECKLED (discrete mineral grains); shale is
/// LAMINATED (parallel bedding planes); schist is FOLIATED (wavy micaceous sheets); serpentinite
/// is VEINED (a network, not a field). A single noise term at different strengths would make all
/// eight the same rock, which is precisely the "ten leaf forms that were two quads" failure the
/// corpus audit exists to prevent, arriving through the back door.
///
/// ⛔ AND EVERY CELL GETS STRUCTURE BY CONSTRUCTION (CLAUDE.md, Muster). A large region of one
/// material with a smooth mottle over it renders FLAT wherever the noise sits mid-band - the same
/// biome did it twice, and a threshold tuned until one case passes leaves every case nobody looked
/// at. The block below is therefore drawn as a bevelled mass with a grain program that always
/// emits marks, never as a fill hoping a noise term will break it up.
/// ============================================================================================

/// The block a specimen sits on. Rough, bedded, and slightly wider than the crystal so the
/// crystal reads as growing OUT of it rather than balancing ON it.
function lod_rock_block(_matrix, _seed, _w, _h) {
    var _rng = lod_rng(_seed + 15486);
    var _g = LOD_GROUND;
    var _n = 11;
    var _pts = array_create(_n);
    // The top surface is broken; the sides and base are the clean faces of a hammered block, which
    // is what a collected specimen actually looks like.
    //
    // ⛔ THE TOP MUST STAY ABOVE THE GROUND LINE ALONG ITS WHOLE RUN. The first version multiplied
    // the height by `0.5 + 0.5 * sin(...)`, which reaches ZERO, so the top surface touched the base
    // line at two points and the outline pinched into a bow-tie waist. On the hero sheet the rock
    // read as a torn grey RIBBON rather than as a block, and the bevel then lit the pinch like a
    // fold. A floor of 0.35 keeps it a block whatever the noise does - true by construction, not by
    // a threshold that the next amplitude change re-breaks.
    for (var _i = 0; _i < _n; _i++) {
        var _u = _i / (_n - 1);
        var _rough = 0.35 + 0.65 * (0.5 + 0.5 * sin(_u * 5.1 + _seed));
        _pts[_i] = [-_w + _u * _w * 2, _g - _h * (0.16 + 0.30 * lod_rng_next(_rng)) * _rough];
    }
    // ⛔ AND THE SIDES ARE VERTICAL AND THE BASE IS FLAT AND FULL WIDTH. The first version closed
    // the outline at -0.92w, so the left side leaned in and the block read as a wedge or an arrow
    // head. A hammered specimen block has parallel sides; the interest belongs on the broken top.
    var _body = [];
    for (var _i = 0; _i < _n; _i++) array_push(_body, _pts[_i]);
    array_push(_body, [_w, _g + _h * 0.62]);
    array_push(_body, [-_w, _g + _h * 0.62]);

    var _out = [];
    lod_append(_out, lod_raise(_body, _w * 0.10, 2, "m2"));
    lod_append(_out, _lod_rock_grain(lod_rock_spec(_matrix).grain, _rng, _pts, _w, _h, _g));
    return _out;
}

/// The eight grain programs.
function _lod_rock_grain(_grain, _rng, _top, _w, _h, _g) {
    var _out = [];
    var _y0 = _g + _h * 0.02, _y1 = _g + _h * 0.58;
    switch (_grain) {
        case 0: {  // GRANITE: discrete speckles of three sizes - quartz, feldspar, mica.
            var _n = clamp(floor(_w * _h / 0.00042), 20, 160);
            for (var _i = 0; _i < _n; _i++) {
                var _x = -_w * 0.94 + lod_rng_next(_rng) * _w * 1.88;
                var _y = _y0 + lod_rng_next(_rng) * (_y1 - _y0);
                var _r = 0.0045 + 0.0055 * lod_rng_next(_rng);
                array_push(_out, lod_dot(_x, _y, _r, lod_stop((_i % 3 == 0) ? 4 : ((_i % 3 == 1) ? 1 : 3))));
            }
            break;
        }
        case 1: {  // BASALT: vesicles - gas bubbles frozen in place, so they are HOLES.
            var _n = clamp(floor(_w * _h / 0.0016), 8, 60);
            for (var _i = 0; _i < _n; _i++) {
                var _x = -_w * 0.90 + lod_rng_next(_rng) * _w * 1.80;
                var _y = _y0 + lod_rng_next(_rng) * (_y1 - _y0);
                var _r = 0.006 + 0.009 * lod_rng_next(_rng);
                lod_append(_out, lod_sink(lod_ellipse_pts(_x, _y, _r, _r * 0.88, 8), _r * 0.5, 1, "m0"));
            }
            break;
        }
        case 2: {  // LIMESTONE: pale flecks and the occasional shell section.
            var _n = clamp(floor(_w * _h / 0.0011), 10, 70);
            for (var _i = 0; _i < _n; _i++) {
                var _x = -_w * 0.90 + lod_rng_next(_rng) * _w * 1.80;
                var _y = _y0 + lod_rng_next(_rng) * (_y1 - _y0);
                if (_i % 7 == 0) {
                    array_push(_out, lod_arc(_x, _y, 0.020 + 0.012 * lod_rng_next(_rng),
                                             0, pi * (0.8 + 0.5 * lod_rng_next(_rng)), 0.0028, "m4"));
                } else {
                    array_push(_out, lod_dot(_x, _y, 0.0035 + 0.003 * lod_rng_next(_rng), "m4"));
                }
            }
            break;
        }
        case 3: {  // SHALE: parallel bedding planes, dead straight and closely spaced.
            var _n = max(6, floor((_y1 - _y0) / 0.017));
            for (var _i = 0; _i < _n; _i++) {
                var _y = _y0 + (_i + 0.5) * (_y1 - _y0) / _n;
                array_push(_out, lod_poly([[-_w * 0.95, _y], [_w * 0.95, _y + 0.004 * (lod_rng_next(_rng) - 0.5)]],
                                          false, 0.0026, lod_stop((_i % 2 == 0) ? 1 : 3)));
            }
            break;
        }
        case 4: {  // QUARTZITE: a sugary texture - very fine, very even, interlocking grains.
            var _n = clamp(floor(_w * _h / 0.00022), 40, 260);
            for (var _i = 0; _i < _n; _i++) {
                var _x = -_w * 0.94 + lod_rng_next(_rng) * _w * 1.88;
                var _y = _y0 + lod_rng_next(_rng) * (_y1 - _y0);
                array_push(_out, lod_dot(_x, _y, 0.0028, lod_stop((_i % 2 == 0) ? 4 : 1)));
            }
            break;
        }
        case 5: {  // SCHIST: wavy foliation with mica flashing along it.
            var _n = max(5, floor((_y1 - _y0) / 0.026));
            var _ph = lod_rng_next(_rng) * LOD_TAU;
            for (var _i = 0; _i < _n; _i++) {
                var _y = _y0 + (_i + 0.5) * (_y1 - _y0) / _n;
                var _m = 13;
                var _pts = array_create(_m);
                for (var _k = 0; _k < _m; _k++) {
                    var _u = _k / (_m - 1);
                    _pts[_k] = [-_w * 0.95 + _u * _w * 1.90, _y + sin(_ph + _u * 3.4 + _i * 0.7) * _h * 0.030];
                }
                array_push(_out, lod_poly(_pts, false, 0.0032, lod_stop((_i % 2 == 0) ? 1 : 3)));
                // Mica flakes catch the light ALONG the foliation, which is what makes schist
                // glitter and is the only thing separating it from shale at a glance.
                for (var _k = 1; _k < _m; _k += 3) {
                    array_push(_out, lod_dot(_pts[_k][0], _pts[_k][1], 0.005, "m4"));
                }
            }
            break;
        }
        case 6: {  // SANDSTONE: visibly granular, warm, with faint cross-bedding.
            var _n = clamp(floor(_w * _h / 0.00050), 24, 170);
            for (var _i = 0; _i < _n; _i++) {
                var _x = -_w * 0.93 + lod_rng_next(_rng) * _w * 1.86;
                var _y = _y0 + lod_rng_next(_rng) * (_y1 - _y0);
                array_push(_out, lod_dot(_x, _y, 0.0040 + 0.0025 * lod_rng_next(_rng), lod_stop((_i % 4 == 0) ? 1 : 3)));
            }
            for (var _i = 0; _i < 3; _i++) {
                var _y = _y0 + (_i + 0.5) * (_y1 - _y0) / 3;
                array_push(_out, lod_poly([[-_w * 0.92, _y + 0.02], [_w * 0.92, _y - 0.02]], false, 0.0030, "m1"));
            }
            break;
        }
        default: {  // SERPENTINITE: a NETWORK of veins, not a field of marks.
            var _n = 5 + floor(lod_rng_next(_rng) * 4);
            for (var _i = 0; _i < _n; _i++) {
                var _m = 9;
                var _pts = array_create(_m);
                var _x0 = -_w * 0.9 + lod_rng_next(_rng) * _w * 1.8;
                var _yy = _y0 + lod_rng_next(_rng) * (_y1 - _y0) * 0.4;
                var _dir = (lod_rng_next(_rng) < 0.5) ? -1 : 1;
                // ⛔ CLAMPED TO THE BLOCK. A vein starting near one edge and running 0.9w in that
                // direction reaches 1.8w - it walked straight out of the rock and hung in space to
                // the left of the serpentinite cell on the host-rock sheet. A vein is a crack IN
                // something; it cannot leave it. Nothing mechanical saw this either: a stroke is
                // ink, and it was ink somewhere the ink check has no opinion about.
                for (var _k = 0; _k < _m; _k++) {
                    var _u = _k / (_m - 1);
                    var _vx = _x0 + _dir * _u * _w * 0.9 + sin(_u * 6.1 + _i) * _w * 0.08;
                    _pts[_k] = [clamp(_vx, -_w * 0.94, _w * 0.94), _yy + _u * (_y1 - _yy) * 0.9];
                }
                array_push(_out, lod_poly(_pts, false, 0.0055, "m4"));
                array_push(_out, lod_poly(_pts, false, 0.0022, "m1"));
            }
            break;
        }
    }
    return _out;
}
