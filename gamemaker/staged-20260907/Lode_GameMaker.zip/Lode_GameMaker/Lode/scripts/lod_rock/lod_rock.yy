{
  "$GMScript": "v1",
  "%Name": "lod_rock",
  "name": "lod_rock",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}