{
  "$GMScript": "v1",
  "%Name": "lod_palette",
  "name": "lod_palette",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}