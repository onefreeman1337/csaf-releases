{
  "$GMScript": "v1",
  "%Name": "lod_shape",
  "name": "lod_shape",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}