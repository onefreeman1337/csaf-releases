{
  "$GMScript": "v1",
  "%Name": "lod_habit",
  "name": "lod_habit",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}