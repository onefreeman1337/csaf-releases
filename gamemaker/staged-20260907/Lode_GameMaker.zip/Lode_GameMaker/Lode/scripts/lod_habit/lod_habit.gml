/// LODE - lod_habit. The twenty-one crystal habits. THIS FILE IS THE PRODUCT'S MOAT.
///
/// ============================================================================================
/// A HABIT IS A DRAWING PROGRAM, NOT A WIDTH CONSTANT.
///
/// The corpus audit (Internal_Ops/audit_corpus.js) refuses to pass unless every one of these
/// twenty-one is REACHED by at least one species, because "21 crystal habits" is only an honest
/// claim if a buyer can see twenty-one different pictures. Each function below is a different
/// construction - a prism is built from three faces of a hexagonal solid, a spray is built from
/// a common root, a druse is built from a hundred and forty individual grains - and none of them
/// is another one with a parameter moved.
///
/// ⛔ THE FAILURE THIS EXISTS TO PREVENT IS RECORDED IN THE SIBLING PRODUCT. Verdure's first
/// corpus had ten "leaf forms" that were two quads at different widths, and six grain species
/// sharing three crown forms; the defect was filed as a rendering problem when it was a corpus
/// problem. The remedy for a collision is to EXTEND THE VOCABULARY, never to shade around it.
///
/// -- WHY IT IS FACETS AND NOT SILHOUETTES -----------------------------------------------------
/// A crystal is not a shape with shading on it. It is a set of PLANE FACES, and what makes one
/// read as mineral rather than as a coloured polygon is that each face takes a different stop of
/// the same five-stop ramp according to which way it points. lod_facet below is that idea in six
/// lines, and every solid habit here is a handful of calls to it.
///
/// That is also why this file needs no bevels on its crystal forms: a bevel is for a MADE object
/// with a rounded edge, and a crystal edge is not rounded - it is where two planes meet. The
/// rounded habits (botryoidal, reniform, nodular, druzy) are the exception and they use lod_raise,
/// because those genuinely are domes.
///
/// ⛔ EVERY FORM STANDS ON LOD_GROUND. lod_selftest asserts it against all twenty-one, so the
/// header stays literally true and a habit authored weeks apart from its matrix still meets it.
/// ============================================================================================

/// Which ramp stop a plane face with this outward normal shows. The integer form of
/// lod_relief_role, because a facet needs to derive its EDGE from its face and string-parsing a
/// role name back into a number to do that would be silly.
function lod_face_stop(_nx, _ny, _tilt) {
    var _m = point_distance(0, 0, _nx, _ny);
    if (_m < 0.0001) return 2;
    var _d = (_nx / _m) * global.lod_lx + (_ny / _m) * global.lod_ly;
    var _t = 0.5 + 0.5 * _d * _tilt;
    if (_t < 0.190) return 0;
    if (_t < 0.385) return 1;
    if (_t < 0.615) return 2;
    if (_t < 0.810) return 3;
    return 4;
}

/// A ramp stop as a role name.
function lod_stop(_i) {
    return "m" + string(clamp(round(_i), 0, LOD_RAMP_N - 1));
}

/// The centroid of an outline.
function lod_centroid(_pts) {
    var _n = array_length(_pts);
    if (_n == 0) return [0, 0];
    var _x = 0, _y = 0;
    for (var _i = 0; _i < _n; _i++) { _x += _pts[_i][0]; _y += _pts[_i][1]; }
    return [_x / _n, _y / _n];
}

/// ONE PLANE FACE OF A CRYSTAL: a fill at the stop its normal earns, plus the edge where it meets
/// the next face.
///
/// _ox,_oy is the point the face turns away FROM - the interior of the solid. The normal is the
/// direction from there to the face's own centre, which is exactly right for a convex solid and
/// is the only geometry a crystal habit needs.
///
/// ⛔ THE EDGE IS ONE STOP ABOVE THE FACE, NOT A BLACK LINE, AND THAT IS PHYSICS RATHER THAN
/// TASTE. Where two plane faces meet, the edge itself is a tiny rounded ridge that catches the
/// lamp from BOTH faces, which is why a real crystal looks wired with light along its edges and a
/// polygon with a dark outline looks like a sticker. Drawing it in m0 - the obvious choice, and
/// the one this wing already paid for on Lexicon - makes a bright stone read as a cartoon.
function lod_facet(_pts, _ox, _oy, _w) {
    var _c = lod_centroid(_pts);
    var _s = lod_face_stop(_c[0] - _ox, _c[1] - _oy, 1.0);
    var _out = [lod_ring_fill(_pts, lod_stop(_s), _c[0], _c[1])];
    if (_w > 0) array_push(_out, lod_poly(_pts, true, _w, lod_stop(_s + 1)));
    return _out;
}

/// The horizontal SPAN of a closed outline at a given y, as [xmin, xmax], or undefined if the
/// outline does not reach that height.
///
/// ⛔ A SHAPE IS ONLY AS WIDE AS ITS BOUNDING BOX AT ONE HEIGHT (CLAUDE.md, Muster). A colour band
/// or a striation clipped to the bounding box is correct for a rectangle and wrong for everything
/// else: a botryoidal lobe reaches its box width at a single y, so a band drawn at any other
/// height overhangs the stone on both sides. Every banding program in lod_zoning clips through
/// here.
///
/// ⚠️ TAKES THE OUTERMOST CROSSINGS, which is right for the convex-ish solids in this corpus and
/// would bridge the opening of a C-shape. Nothing here is C-shaped except the geode, which draws
/// its cavity as its own mass rather than as a notch, precisely so this stays true.
function lod_span_at_y(_pts, _y) {
    var _n = array_length(_pts);
    var _lo = 0, _hi = 0, _found = false;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _pts[_i], _b = _pts[(_i + 1) % _n];
        var _y0 = _a[1], _y1 = _b[1];
        if ((_y0 <= _y && _y1 > _y) || (_y1 <= _y && _y0 > _y)) {
            var _t = (_y - _y0) / (_y1 - _y0);
            var _x = _a[0] + (_b[0] - _a[0]) * _t;
            if (!_found) { _lo = _x; _hi = _x; _found = true; }
            else { _lo = min(_lo, _x); _hi = max(_hi, _x); }
        }
    }
    if (!_found) return undefined;
    return [_lo, _hi];
}

/// ============================================================================================
/// THE TWENTY-ONE HABITS
///
/// Every one returns a part list in UNIT-BOX space with its base on LOD_GROUND, using the generic
/// roles m0..m4 so the caller can map them onto whichever material this specimen is made of.
/// _h is the form's height above the bedding plane; _w is its half-width at the widest point.
/// ============================================================================================

/// 0 PRISMATIC. An elongated hexagonal prism with a pyramid termination - a quartz point.
/// Three faces of the prism and three of the pyramid are visible, which is what a hexagonal prism
/// seen slightly off-axis actually shows.
function lod_habit_prismatic(_rng, _h, _w) {
    var _g = LOD_GROUND;
    // ⛔ IT CAME BACK AS A HOUSE, AND BOTH CAUSES WERE PROPORTION RATHER THAN CONSTRUCTION.
    // (1) The prism was nearly as wide as it was tall, and (2) the termination was a shallow gable
    // spanning the full width. Together those are the drawing of a cottage with a pitched roof, on
    // the habit FIVE of this corpus's gem species use - quartz, beryl, topaz, corundum, apatite.
    //
    // A quartz point is two to four times taller than it is wide, its termination is a THIRD of its
    // length, and the faces meet at a POINT rather than along a ridge. Narrowing the form here
    // rather than asking every caller to pass a different width keeps the habit responsible for its
    // own proportions, which is the only place that knowledge belongs.
    var _ww = _w * 0.56;
    var _sh = _h * (0.56 + 0.07 * lod_rng_next(_rng));   // shoulder: where the termination starts
    var _ys = _g - _sh, _yt = _g - _h;
    // The FRONT face is the wide one and the side face is foreshortened, which is what a hexagonal
    // prism seen slightly off-axis shows. Having them the other way round is why the first version
    // read as a building rather than as a crystal.
    var _lx = -_ww, _mx = _ww * (0.24 + 0.10 * lod_rng_next(_rng)), _rx = _ww;
    // ⛔ TWO TERMINATION FACES, WITH THE APEX INSIDE THE FRONT FACE. A THIRD ONE MADE IT WORSE.
    // The gable reading came from the apex sitting midway between the outer edges, so the two
    // triangles were mirror images and the eye completed a roof ridge. Adding a third face to
    // "fix" it produced a folded paper bag, because the extra vertex sat BELOW the apex and cut a
    // notch into the silhouette.
    //
    // ⭐ The actual fix is one number: put the apex off-centre, over the front face. The two
    // triangles are then plainly different shapes - a narrow one on the left and a broad one on
    // the right - and an asymmetric pair of faces meeting at a high point is read as a POINT.
    // Same lesson as the wing's straight-sided-triangles-are-an-X law: the eye is completing a
    // familiar figure, and the cure is to break the symmetry that invites it, not to add parts.
    var _apex = lerp(_lx, _mx, 0.66);
    var _cx = _mx, _cy = _g - _sh * 0.5;
    var _out = [];
    // Prism: front face and side face, meeting on the vertical edge at _mx.
    lod_append(_out, lod_facet([[_lx, _g], [_lx, _ys], [_mx, _ys + _sh * 0.045], [_mx, _g + _sh * 0.045]], _cx, _cy, 0.004));
    lod_append(_out, lod_facet([[_mx, _g + _sh * 0.045], [_mx, _ys + _sh * 0.045], [_rx, _ys], [_rx, _g]], _cx, _cy, 0.004));
    // Termination.
    lod_append(_out, lod_facet([[_lx, _ys], [_apex, _yt], [_mx, _ys + _sh * 0.045]], _cx, _cy - _sh * 0.4, 0.004));
    lod_append(_out, lod_facet([[_mx, _ys + _sh * 0.045], [_apex, _yt], [_rx, _ys]], _cx, _cy - _sh * 0.4, 0.004));
    return _out;
}

/// 1 ACICULAR. A spray of fine needles from a common root - stibnite, rutile.
/// The needles are tapered ribbons, not lines: a line has no silhouette and this habit is
/// silhouette-only.
function lod_habit_acicular(_rng, _h, _w) {
    var _g = LOD_GROUND;
    var _n = 9 + floor(lod_rng_next(_rng) * 5);
    var _out = [];
    for (var _i = 0; _i < _n; _i++) {
        var _u = (_i + 0.5) / _n;
        var _a = -pi * 0.5 + (_u - 0.5) * 2.1 + (lod_rng_next(_rng) - 0.5) * 0.14;
        var _len = _h * (0.55 + 0.45 * (1 - abs(_u - 0.5) * 1.4)) * (0.82 + 0.30 * lod_rng_next(_rng));
        var _rootx = (_u - 0.5) * _w * 0.30;
        var _tipx = _rootx + cos(_a) * _len;
        var _tipy = _g + sin(_a) * _len;
        var _tw = _w * (0.055 + 0.030 * lod_rng_next(_rng));
        // A needle is a triangle from a finite root to a point. Drawn as a facet so the ones
        // leaning into the lamp are brighter than the ones leaning away - which is the whole
        // reason a spray reads as three-dimensional.
        lod_append(_out, lod_facet([[_rootx - _tw, _g], [_tipx, _tipy], [_rootx + _tw, _g]], 0, _g - _h * 0.3, 0.0025));
    }
    return _out;
}

/// 2 BOTRYOIDAL. Fused spheres, grape-like - malachite, smithsonite, cinnabar.
/// Genuinely domes, so genuinely lod_raise. Drawn back to front so the front lobes overlap the
/// back ones, which is what "fused" looks like.
function lod_habit_botryoidal(_rng, _h, _w) {
    var _g = LOD_GROUND;
    var _n = 5 + floor(lod_rng_next(_rng) * 4);
    var _out = [];
    // Back row first: smaller and higher, which reads as further away.
    //
    // ⛔ THE FRONT ROW IS CENTRED SO ITS LOBES MEET THE BEDDING PLANE EXACTLY. The first draft put
    // every centre at `_g - _r * 1.36`, so the lowest ink sat 0.42r ABOVE the ground and the whole
    // mass FLOATED - caught by the suite's stands-on-the-bedding-plane assertion, on a picture that
    // would have looked merely "a bit high" to the eye. A disc whose centre sits at exactly one
    // radius above the base touches it at one point and needs no fudge factor, which is the same
    // construction Welkin used to kill its cloud end-walls: make the contact true BY CONSTRUCTION
    // rather than by a tuned constant that the next radius change re-breaks.
    for (var _row = 0; _row < 2; _row++) {
        var _k = (_row == 0) ? 0.68 : 1.0;
        var _cnt = (_row == 0) ? max(2, _n - 2) : _n;
        for (var _i = 0; _i < _cnt; _i++) {
            var _u = (_i + 0.5) / _cnt;
            var _r = _w * _k * (0.26 + 0.13 * lod_rng_next(_rng));
            var _ry = _r * 0.94;
            var _cx = (_u - 0.5) * (_w * 2 - _r * 2.1);
            // Front row sits ON the plane; the back row is lifted so it reads as behind.
            var _cy = (_row == 1) ? (_g - _ry) : (_g - _ry - _h * 0.30);
            lod_append(_out, lod_raise(lod_ellipse_pts(_cx, _cy, _r, _ry, 22), _r * 0.62, 3, "m2"));
        }
    }
    return _out;
}

/// 3 DENDRITIC. Flat fractal branching across the rock face - native copper, electrum, pyrolusite.
/// The only habit in the corpus that is essentially two-dimensional, which is truthful: a dendrite
/// grows in a crack and is a FILM.
function lod_habit_dendritic(_rng, _h, _w) {
    var _g = LOD_GROUND;
    var _out = [];
    _lod_dendrite(_out, _rng, 0, _g, -pi * 0.5, _h * 0.46, _w * 0.075, 4);
    return _out;
}

/// One branch and its children. Recursive, depth-bounded, and the width halves each level so the
/// twigs are hairlines and the trunk is a mass.
function _lod_dendrite(_out, _rng, _x, _y, _a, _len, _wid, _depth) {
    if (_depth <= 0 || _len < 0.008) return;
    var _x2 = _x + cos(_a) * _len, _y2 = _y + sin(_a) * _len;
    var _stop = lod_face_stop(cos(_a - pi * 0.5), sin(_a - pi * 0.5), 0.85);
    array_push(_out, lod_poly([[_x, _y], [_x2, _y2]], false, max(_wid, 0.004), lod_stop(_stop)));
    // Dendrites branch at a characteristic angle - about 60 degrees for cubic metals - and that
    // constancy is what makes them read as crystalline rather than as a plant.
    var _br = 1.047 + (lod_rng_next(_rng) - 0.5) * 0.22;
    _lod_dendrite(_out, _rng, _x2, _y2, _a, _len * 0.74, _wid * 0.62, _depth - 1);
    _lod_dendrite(_out, _rng, lerp(_x, _x2, 0.55), lerp(_y, _y2, 0.55), _a - _br, _len * 0.60, _wid * 0.55, _depth - 1);
    _lod_dendrite(_out, _rng, lerp(_x, _x2, 0.72), lerp(_y, _y2, 0.72), _a + _br, _len * 0.60, _wid * 0.55, _depth - 1);
}

/// 4 GEODE. A hollow cavity lined with inward-pointing crystals - amethyst.
///
/// ⛔ THE CAVITY IS DRAWN AS ITS OWN MASS, NOT AS A NOTCH CUT OUT OF THE RIND. A crescent or a C
/// handed to a triangle fan is filled straight across its own opening, silently (CLAUDE.md,
/// Welkin: every moon crescent shipped as a quarter for exactly this). Building the rind as a
/// closed ring and the cavity as a separate convex mass on top of it keeps every outline in this
/// habit star-shaped about its own centre.
function lod_habit_geode(_rng, _h, _w) {
    var _g = LOD_GROUND;
    var _cy = _g - _h * 0.52;
    var _rx = _w, _ry = _h * 0.52;
    var _out = [];
    // The rind: a rough egg, split open toward the viewer.
    var _rind = lod_ellipse_pts(0, _cy, _rx, _ry, 26);
    for (var _i = 0; _i < array_length(_rind); _i++) {
        var _k = 1 + (lod_rng_next(_rng) - 0.5) * 0.10;
        _rind[_i] = [(_rind[_i][0]) * _k, _cy + (_rind[_i][1] - _cy) * _k];
    }
    lod_append(_out, lod_raise(_rind, _rx * 0.13, 3, "m2"));
    // The cavity: a smaller ellipse, sunken, and dark because you are looking into a hole.
    var _cav = lod_ellipse_pts(0, _cy + _ry * 0.05, _rx * 0.68, _ry * 0.66, 24);
    lod_append(_out, lod_sink(_cav, _rx * 0.10, 2, "m0"));
    // The lining: inward-pointing crystals all round the cavity wall.
    //
    // ⚠️ THEY MUST REACH WELL INTO THE CAVITY. The first version used a depth of 0.16-0.29 of the
    // radius and a half-width of 0.055, and on the hero sheet at 728 px the geode read as a grey
    // TYRE with a fringe: the crystals were a decorative edge rather than the thing the picture is
    // about. A geode IS its lining. 0.30-0.52 deep, and wide enough that neighbouring crystals
    // nearly touch at their bases, which is how a druse-lined cavity actually looks.
    var _n = 16 + floor(lod_rng_next(_rng) * 6);
    for (var _i = 0; _i < _n; _i++) {
        var _a = LOD_TAU * _i / _n;
        var _ca = cos(_a), _sa = sin(_a);
        var _ox = _ca * _rx * 0.67, _oy = _cy + _ry * 0.05 + _sa * _ry * 0.65;
        // ⚠️ THE DEPTHS MUST VARY WIDELY OR THE LINING READS AS A COGWHEEL. Uniform inward teeth of
        // equal length around a circle is a gear, and that is exactly what the first fix produced
        // when it made them all long. A real geode's crystals are wildly uneven; the wide spread
        // here is what turns a mechanical rosette back into a mineral surface, and it leaves the
        // middle of the cavity genuinely open, which is the whole point of a hollow.
        var _dep = (0.16 + 0.40 * lod_rng_next(_rng) * lod_rng_next(_rng) * 1.6);
        var _tx = _ox * (1 - _dep), _ty = (_cy + _ry * 0.05) + (_oy - _cy - _ry * 0.05) * (1 - _dep);
        var _pw = _rx * (0.075 + 0.045 * lod_rng_next(_rng));
        lod_append(_out, lod_facet([[_ox - _sa * _pw, _oy + _ca * _pw], [_tx, _ty], [_ox + _sa * _pw, _oy - _ca * _pw]], 0, _cy, 0.002));
    }
    return _out;
}

/// 5 MASSIVE. No external form at all: an irregular fracture lump - obsidian, opal, jet.
/// The facets here are CONCHOIDAL - the scooped shell-shaped break that glassy minerals make -
/// and they are the reason this is not just a blob.
function lod_habit_massive(_rng, _h, _w) {
    var _g = LOD_GROUND;
    var _n = 9;
    var _pts = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _a = pi + pi * _i / (_n - 1);
        var _r = 0.78 + 0.30 * lod_rng_next(_rng);
        _pts[_i] = [cos(_a) * _w * _r, _g + sin(_a) * _h * _r];
    }
    _pts[0] = [-_w * 0.94, _g];
    _pts[_n - 1] = [_w * 0.94, _g];
    var _out = [];
    lod_append(_out, lod_raise(_pts, _w * 0.10, 2, "m2"));
    // Conchoidal scars: shallow scooped facets across the body.
    var _sc = 3 + floor(lod_rng_next(_rng) * 3);
    for (var _i = 0; _i < _sc; _i++) {
        var _cx = (lod_rng_next(_rng) - 0.5) * _w * 1.1;
        var _cy = _g - _h * (0.25 + 0.5 * lod_rng_next(_rng));
        var _r = _w * (0.16 + 0.14 * lod_rng_next(_rng));
        var _sp = lod_span_at_y(_pts, _cy);
        if (is_undefined(_sp)) continue;
        _cx = clamp(_cx, _sp[0] + _r, _sp[1] - _r);
        if (_sp[1] - _sp[0] < _r * 2.2) continue;
        lod_append(_out, lod_sink(lod_ellipse_pts(_cx, _cy, _r, _r * 0.82, 16), _r * 0.5, 2, "m1"));
    }
    return _out;
}

/// 6 TABULAR. Flat plates stacked like a book - barite, vivianite, bismuth.
function lod_habit_tabular(_rng, _h, _w) {
    var _g = LOD_GROUND;
    var _n = 3 + floor(lod_rng_next(_rng) * 3);
    var _out = [];
    var _th = _h / (_n * 1.35);
    for (var _i = 0; _i < _n; _i++) {
        var _y0 = _g - _th * _i * 1.28;
        var _sk = _w * (0.10 + 0.09 * _i);            // each plate offset: a stack, not a block
        var _hw = _w * (0.94 - 0.06 * _i);
        var _top = [[-_hw + _sk, _y0 - _th], [_hw + _sk * 0.4, _y0 - _th * 1.14],
                    [_hw + _sk * 0.4 - _w * 0.13, _y0 - _th * 1.30], [-_hw + _sk - _w * 0.13, _y0 - _th * 1.16]];
        var _front = [[-_hw + _sk, _y0 - _th], [_hw + _sk * 0.4, _y0 - _th * 1.14], [_hw + _sk * 0.4, _y0], [-_hw + _sk, _y0]];
        lod_append(_out, lod_facet(_front, _sk, _y0 - _th * 2, 0.0035));
        lod_append(_out, lod_facet(_top, _sk, _y0 + _th, 0.0035));
    }
    return _out;
}

/// 7 RHOMBOHEDRAL. A skewed cube - calcite's cleavage rhomb, siderite.
/// Three faces, and the skew is what separates it from `cubic` at a glance.
function lod_habit_rhombohedral(_rng, _h, _w) {
    var _g = LOD_GROUND;
    var _s = _w * 0.82;
    var _skx = _s * (0.42 + 0.10 * lod_rng_next(_rng));
    var _sky = _s * 0.30;
    var _b = _g;
    var _out = [];
    var _cx = 0, _cy = _g - _h * 0.5;
    // front, right, top
    lod_append(_out, lod_facet([[-_s, _b], [0, _b - _sky * 0.5], [0, _b - _sky * 0.5 - _h * 0.72], [-_s, _b - _h * 0.72]], _cx, _cy, 0.004));
    lod_append(_out, lod_facet([[0, _b - _sky * 0.5], [_s, _b - _sky], [_s, _b - _sky - _h * 0.72], [0, _b - _sky * 0.5 - _h * 0.72]], _cx, _cy, 0.004));
    lod_append(_out, lod_facet([[-_s, _b - _h * 0.72], [0, _b - _sky * 0.5 - _h * 0.72], [_s, _b - _sky - _h * 0.72],
                                [_s - _skx, _b - _sky - _h * 0.72 - _sky * 0.9], [-_skx, _b - _sky * 0.5 - _h * 0.72 - _sky * 0.9],
                                [-_s - _skx * 0.5, _b - _h * 0.72 - _sky * 0.5]], _cx, _cy + _h * 0.4, 0.004));
    return _out;
}

/// 8 OCTAHEDRAL. Two square pyramids base to base - fluorite, magnetite, garnet, spinel.
function lod_habit_octahedral(_rng, _h, _w) {
    var _g = LOD_GROUND;
    var _cy = _g - _h * 0.50;
    var _wob = 0.94 + 0.10 * lod_rng_next(_rng);
    var _lft = [-_w * _wob, _cy], _rgt = [_w, _cy + _h * 0.05];
    var _top = [-_w * 0.10, _g - _h], _bot = [-_w * 0.04, _g];
    var _mid = [_w * 0.06, _cy + _h * 0.10];   // the near vertex of the equatorial square
    var _out = [];
    lod_append(_out, lod_facet([_top, _lft, _mid], 0, _cy, 0.004));
    lod_append(_out, lod_facet([_top, _mid, _rgt], 0, _cy, 0.004));
    lod_append(_out, lod_facet([_bot, _lft, _mid], 0, _cy, 0.004));
    lod_append(_out, lod_facet([_bot, _mid, _rgt], 0, _cy, 0.004));
    return _out;
}

/// 9 CUBIC. A cube, and this corpus draws its faces STRIATED - halite, galena.
/// The striations are a PHYSICAL detail: their pitch is bounded in unit-box terms so a big cube
/// gets more of them rather than fatter ones (CLAUDE.md, Livery).
function lod_habit_cubic(_rng, _h, _w) {
    var _g = LOD_GROUND;
    var _s = _w * 0.80, _d = _s * 0.42;
    var _cx = 0, _cy = _g - _h * 0.5;
    var _out = [];
    var _front = [[-_s, _g], [_s * 0.34, _g], [_s * 0.34, _g - _h * 0.78], [-_s, _g - _h * 0.78]];
    var _right = [[_s * 0.34, _g], [_s, _g - _d * 0.55], [_s, _g - _d * 0.55 - _h * 0.78], [_s * 0.34, _g - _h * 0.78]];
    var _top   = [[-_s, _g - _h * 0.78], [_s * 0.34, _g - _h * 0.78], [_s, _g - _d * 0.55 - _h * 0.78],
                  [_s - _d * 0.9, _g - _d * 1.05 - _h * 0.78], [-_s - _d * 0.35, _g - _d * 0.5 - _h * 0.78]];
    lod_append(_out, lod_facet(_front, _cx, _cy, 0.004));
    lod_append(_out, lod_facet(_right, _cx, _cy, 0.004));
    lod_append(_out, lod_facet(_top, _cx, _cy + _h * 0.5, 0.004));
    return _out;
}

/// 10 BLADED. Flat elongated blades in a sheaf - vivianite, kyanite.
function lod_habit_bladed(_rng, _h, _w) {
    var _g = LOD_GROUND;
    var _n = 4 + floor(lod_rng_next(_rng) * 4);
    var _out = [];
    for (var _i = 0; _i < _n; _i++) {
        var _u = (_i + 0.5) / _n;
        var _lean = (_u - 0.5) * 0.62;
        var _len = _h * (0.62 + 0.38 * (1 - abs(_u - 0.5) * 1.3));
        var _bx = (_u - 0.5) * _w * 0.55;
        var _tx = _bx + _lean * _h * 0.55;
        var _bw = _w * (0.10 + 0.05 * lod_rng_next(_rng));
        var _tw = _bw * 0.62;
        lod_append(_out, lod_facet([[_bx - _bw, _g], [_bx + _bw, _g],
                                    [_tx + _tw, _g - _len], [_tx, _g - _len - _h * 0.06], [_tx - _tw, _g - _len]],
                                   _bx, _g - _len * 0.4, 0.003));
    }
    return _out;
}

/// 11 STELLATE. A radiating starburst from one centre - wavellite, pyrophyllite.
function lod_habit_stellate(_rng, _h, _w) {
    var _g = LOD_GROUND;
    var _cy = _g - _h * 0.40;
    var _n = 13 + floor(lod_rng_next(_rng) * 6);
    var _out = [];
    for (var _i = 0; _i < _n; _i++) {
        var _a = LOD_TAU * _i / _n + lod_rng_next(_rng) * 0.05;
        var _len = min(_w, _h * 0.55) * (0.72 + 0.30 * lod_rng_next(_rng));
        var _tw = _len * 0.10;
        var _ca = cos(_a), _sa = sin(_a);
        lod_append(_out, lod_facet([[-_sa * _tw, _cy + _ca * _tw], [_ca * _len, _cy + _sa * _len], [_sa * _tw, _cy - _ca * _tw]],
                                   0, _cy, 0.002));
    }
    // The hub. A radial spray with no centre reads as a scribble.
    lod_append(_out, lod_raise(lod_ellipse_pts(0, _cy, _w * 0.16, _w * 0.16, 14), _w * 0.10, 2, "m3"));
    return _out;
}

/// 12 DRUZY. A carpet of tiny crystals over a surface - uvarovite.
///
/// ⚠️ THE GRAIN IS A PHYSICAL CONSTANT (CLAUDE.md, Livery). A druse does not get coarser because
/// the specimen is bigger; it gets MORE crystals. The count is therefore derived from the area to
/// be covered divided by a fixed grain size, never from a fixed count scaled up.
function lod_habit_druzy(_rng, _h, _w) {
    var _g = LOD_GROUND;
    var _grain = 0.016;
    var _out = [];
    // The substrate the druse grew on: a low mound, so the carpet has a form to follow.
    var _base = lod_ellipse_pts(0, _g - _h * 0.20, _w, _h * 0.62, 24);
    lod_append(_out, lod_raise(_base, _w * 0.10, 2, "m1"));
    var _cols = max(6, floor(_w * 2 / (_grain * 1.55)));
    var _rows = max(4, floor(_h * 0.55 / (_grain * 1.35)));
    for (var _r = 0; _r < _rows; _r++) {
        for (var _c = 0; _c < _cols; _c++) {
            // ⚠️ JITTERED. A perfect lattice of grains reads as a WAFFLE or a net, not as a crust
            // of crystals - measured on the first bake, where uvarovite came back looking like
            // green mesh. The offset is under half a cell so the coverage stays even; a druse is
            // dense and irregular, not random and sparse.
            var _jx = (lod_rng_next(_rng) - 0.5) * _grain * 1.15;
            var _jy = (lod_rng_next(_rng) - 0.5) * _grain * 1.15;
            var _x = -_w + (_c + 0.5 + (_r % 2) * 0.5) * (_w * 2 / _cols) + _jx;
            var _y = _g - _h * 0.20 - _h * 0.30 + (_r + 0.5) * (_h * 0.62 / _rows) + _jy;
            var _sp = lod_span_at_y(_base, _y);
            if (is_undefined(_sp)) continue;
            if (_x < _sp[0] + _grain || _x > _sp[1] - _grain) continue;
            var _rr = _grain * (0.55 + 0.40 * lod_rng_next(_rng));
            // Each grain is a tiny FOUR-SIDED crystal, randomly turned, not an upright triangle.
            // ⛔ THE UPRIGHT-TRIANGLE VERSION READ AS A FIELD OF ARROWHEADS - forty identical little
            // spearpoints in rows, which is a pattern rather than a crust. A druse is a mat of
            // crystals lying in every direction; giving each one its own rotation is what makes the
            // surface read as sparkling rather than as printed.
            var _a = lod_rng_next(_rng) * LOD_TAU;
            var _ca = cos(_a), _sa = sin(_a);
            lod_append(_out, lod_facet([
                [_x + _ca * _rr, _y + _sa * _rr],
                [_x - _sa * _rr * 0.62, _y + _ca * _rr * 0.62],
                [_x - _ca * _rr, _y - _sa * _rr],
                [_x + _sa * _rr * 0.62, _y - _ca * _rr * 0.62]], _x, _y, 0));
        }
    }
    return _out;
}

/// 13 FIBROUS. Dense parallel silky fibres - selenite satin spar, chrysotile.
function lod_habit_fibrous(_rng, _h, _w) {
    var _g = LOD_GROUND;
    var _out = [];
    var _body = [[-_w, _g], [-_w * 0.86, _g - _h * 0.96], [_w * 0.86, _g - _h], [_w, _g]];
    lod_append(_out, lod_facet(_body, 0, _g - _h * 0.4, 0.004));
    // The fibres. Parallel, dense, and the reason the whole habit exists - the silk is the
    // alignment, so they must all run the SAME way and vary only in weight.
    var _n = max(14, floor(_w * 2 / 0.011));
    for (var _i = 0; _i < _n; _i++) {
        var _u = (_i + 0.5) / _n;
        var _x0 = -_w + _u * _w * 2;
        var _x1 = -_w * 0.86 + _u * _w * 1.72;
        var _stop = 3 + ((_i % 3 == 0) ? 1 : -1);
        array_push(_out, lod_poly([[_x0, _g], [_x1, _g - _h * (0.96 + 0.04 * _u)]], false, 0.0028, lod_stop(_stop)));
    }
    return _out;
}

/// 14 RENIFORM. Smooth kidney mounds, internally banded - hematite.
function lod_habit_reniform(_rng, _h, _w) {
    var _g = LOD_GROUND;
    var _n = 2 + floor(lod_rng_next(_rng) * 2);
    var _out = [];
    for (var _i = 0; _i < _n; _i++) {
        var _u = (_i + 0.5) / _n;
        var _rx = _w / _n * (0.94 + 0.16 * lod_rng_next(_rng));
        var _ry = _h * (0.58 + 0.24 * lod_rng_next(_rng));
        var _cx = (_u - 0.5) * (_w * 2 - _rx * 1.2);
        var _cy = _g - _ry * 0.86;
        // A kidney is not an ellipse: it is wider below the middle and it is flattened where it
        // meets its neighbour. Both come out of one warp of the sampled ring.
        var _pts = lod_ellipse_pts(_cx, _cy, _rx, _ry, 24);
        for (var _k = 0; _k < array_length(_pts); _k++) {
            var _dy = (_pts[_k][1] - _cy) / _ry;
            _pts[_k] = [_cx + (_pts[_k][0] - _cx) * (1 + 0.16 * _dy), _pts[_k][1]];
        }
        lod_append(_out, lod_raise(_pts, _rx * 0.42, 3, "m2"));
    }
    return _out;
}

/// 15 COLUMNAR. Parallel thick columns at differing heights - tourmaline, beryl in a pocket.
function lod_habit_columnar(_rng, _h, _w) {
    var _g = LOD_GROUND;
    var _n = 4 + floor(lod_rng_next(_rng) * 3);
    var _out = [];
    var _cw = _w * 2 / (_n * 1.22);
    for (var _i = 0; _i < _n; _i++) {
        var _x = -_w + _cw * 0.61 + _i * _cw * 1.22;
        var _hh = _h * (0.46 + 0.54 * lod_rng_next(_rng));
        var _hw = _cw * 0.46;
        var _cx = _x, _cy = _g - _hh * 0.5;
        lod_append(_out, lod_facet([[_x - _hw, _g], [_x, _g], [_x, _g - _hh], [_x - _hw, _g - _hh * 0.97]], _cx, _cy, 0.003));
        lod_append(_out, lod_facet([[_x, _g], [_x + _hw, _g], [_x + _hw, _g - _hh * 0.97], [_x, _g - _hh]], _cx, _cy, 0.003));
        // Flat basal termination, slightly seen from above.
        lod_append(_out, lod_facet([[_x - _hw, _g - _hh * 0.97], [_x, _g - _hh], [_x + _hw, _g - _hh * 0.97],
                                    [_x, _g - _hh - _hw * 0.42]], _cx, _cy + _hh * 0.5, 0.003));
    }
    return _out;
}

/// 16 ENCRUSTING. A thin crust following the rock's own contour - turquoise, chrysocolla.
/// The only habit whose SHAPE is inherited from the matrix rather than from the mineral, which is
/// exactly what a crust is.
function lod_habit_encrusting(_rng, _h, _w) {
    var _g = LOD_GROUND;
    var _n = 22;
    var _top = array_create(_n), _bot = array_create(_n);
    var _ph = lod_rng_next(_rng) * LOD_TAU;
    // ⛔ THE CRUST'S UNDERSIDE MEETS THE BEDDING PLANE AT BOTH ENDS. A crust is the one habit whose
    // shape is inherited from the rock, and the first draft floated the whole band 0.07 above the
    // plane because its surface height never reached it - the suite caught it as "habit floats".
    // The `_end` term drives the underside to the plane at u=0 and u=1 by construction, so no
    // amplitude change can re-open the gap.
    // ⚠️ THE TAPER IS SATURATED, AND THE UNSATURATED VERSION READ AS A NECKLACE. A plain sin(pi*u)
    // thins the crust continuously from both ends, so at the habit-sheet size the band was a thin
    // arc with the botryoidal bumps strung along it - a bead necklace, not a crust. Multiplying by
    // 2.4 and clamping holds FULL thickness across the middle ~72% and only tapers at the extreme
    // ends, which is what a crust on a rock actually does.
    for (var _i = 0; _i < _n; _i++) {
        var _u = _i / (_n - 1);
        var _x = -_w + _u * _w * 2;
        var _end = clamp(sin(pi * _u) * 2.4, 0, 1);
        var _surf = _g - _h * _end * (0.42 + 0.30 * sin(_ph + _u * 4.1) * 0.5 + 0.16 * sin(_ph * 2 + _u * 9.3));
        var _t = _h * _end * (0.26 + 0.10 * sin(_ph + _u * 6.7));
        _top[_i] = [_x, _surf - _t];
        _bot[_i] = [_x, _surf];
    }
    var _out = [lod_strip(_top, _bot, "m3")];
    array_push(_out, lod_poly(_top, false, 0.0045, "m4"));
    array_push(_out, lod_poly(_bot, false, 0.0035, "m0"));
    // Botryoidal bumps ON the crust: turquoise and chrysocolla are never smooth.
    for (var _i = 1; _i < _n - 1; _i += 3) {
        var _r = _h * (0.045 + 0.030 * lod_rng_next(_rng));
        lod_append(_out, lod_raise(lod_ellipse_pts(_top[_i][0], _top[_i][1] + _r * 0.3, _r, _r * 0.86, 12), _r * 0.6, 2, "m3"));
    }
    return _out;
}

/// 17 SCALENOHEDRAL. A steep double pyramid - calcite "dogtooth".
function lod_habit_scalenohedral(_rng, _h, _w) {
    var _g = LOD_GROUND;
    var _cy = _g - _h * 0.30;
    var _apex = [_w * (-0.12 + 0.16 * lod_rng_next(_rng)), _g - _h];
    var _out = [];
    var _lft = [-_w, _cy], _rgt = [_w, _cy + _h * 0.06], _mid = [_w * 0.04, _cy + _h * 0.13];
    lod_append(_out, lod_facet([_apex, _lft, _mid], 0, _cy, 0.004));
    lod_append(_out, lod_facet([_apex, _mid, _rgt], 0, _cy, 0.004));
    // The lower half is short and steep - that asymmetry is what "dogtooth" means.
    lod_append(_out, lod_facet([[_w * 0.02, _g], _lft, _mid], 0, _cy, 0.004));
    lod_append(_out, lod_facet([[_w * 0.02, _g], _mid, _rgt], 0, _cy, 0.004));
    return _out;
}

/// 18 WIRE. Twisted filaments - native gold, native silver.
///
/// ⛔ IT IS A TANGLE, NOT ONE WIRE, AND THE SUITE IS WHAT SAID SO. The first draft drew a single
/// filament and emitted TWO parts, so "Gold, rough" and "Silver, rough" both tripped the
/// specimen-is-nearly-empty assertion. That was not a threshold being fussy: a lone wandering line
/// is the thinnest thing this corpus can produce, and native wire silver genuinely occurs as a
/// tangled mass of filaments rather than as one strand. The fix is more truth, not a lower floor.
function lod_habit_wire(_rng, _h, _w) {
    var _g = LOD_GROUND;
    var _out = [];
    var _strands = 3 + floor(lod_rng_next(_rng) * 3);
    for (var _s = 0; _s < _strands; _s++) {
        var _n = 22;
        var _pts = array_create(_n);
        var _ph = lod_rng_next(_rng) * LOD_TAU;
        var _amp = _w * (0.34 + 0.34 * lod_rng_next(_rng));
        var _root = (lod_rng_next(_rng) - 0.5) * _w * 0.7;
        var _top = _h * (0.55 + 0.45 * lod_rng_next(_rng));
        var _freq = 5.4 + lod_rng_next(_rng) * 4.0;
        for (var _i = 0; _i < _n; _i++) {
            var _u = _i / (_n - 1);
            // Every strand starts ON the bedding plane and the lateral swing grows with height,
            // which is what a filament that grew out of a crack looks like.
            _pts[_i] = [_root + sin(_ph + _u * _freq) * _amp * (0.15 + 0.85 * _u), _g - _u * _top];
        }
        // A wire has thickness that varies along its length, which is what stops it reading as a
        // stroke. lod_var_ribbon builds a strip, so this is a MASS with a silhouette.
        var _wid = array_create(_n);
        for (var _i = 0; _i < _n; _i++) {
            _wid[_i] = _w * (0.075 - 0.028 * (_i / (_n - 1))) * (0.80 + 0.40 * lod_rng_next(_rng));
        }
        array_push(_out, lod_var_ribbon(_pts, _wid, lod_stop((_s % 2 == 0) ? 3 : 2)));
        array_push(_out, lod_poly(_pts, false, 0.0035, "m4"));
    }
    return _out;
}

/// 19 NODULAR. A rounded nodule with a rind - flint, agate, amber, turquoise.
function lod_habit_nodular(_rng, _h, _w) {
    var _g = LOD_GROUND;
    var _cy = _g - _h * 0.46;
    var _pts = lod_ellipse_pts(0, _cy, _w, _h * 0.50, 22);
    for (var _i = 0; _i < array_length(_pts); _i++) {
        var _k = 1 + (lod_rng_next(_rng) - 0.5) * 0.13;
        _pts[_i] = [_pts[_i][0] * _k, _cy + (_pts[_i][1] - _cy) * _k];
    }
    var _out = [];
    lod_append(_out, lod_raise(_pts, _w * 0.30, 3, "m2"));
    // The rind: a weathered skin, drawn as a band just inside the silhouette. Concentric with the
    // outline rather than a circle, because a rind follows the surface it formed on.
    array_push(_out, lod_poly(lod_scale_pts(_pts, 0.86), true, 0.005, "m1"));
    return _out;
}

/// 20 PYRITOHEDRAL. Twelve pentagonal faces - pyrite's own form, which is NOT a cube.
///
/// This habit exists because the sulphides had none of their own: pyrite and galena both sat on
/// `cubic` with halite, which made the whole family a permutation of the halides. The corpus audit
/// refuses that, and the remedy is vocabulary rather than shading.
function lod_habit_pyritohedral(_rng, _h, _w) {
    var _g = LOD_GROUND;
    var _cy = _g - _h * 0.48;
    var _r = min(_w, _h * 0.5);
    var _out = [];
    // Five visible pentagonal faces of the dodecahedral form: one facing, four around it.
    //
    // ⚠️ THE FRONT FACE IS LARGE AND THE OUTER RING IS BARELY LARGER. A small front pentagon inside
    // a wide ring of long quads is a PINWHEEL, which is how the first version baked - it read as
    // folded paper rather than as a solid. On a real pyritohedron the face you are looking at
    // dominates and the surrounding faces are foreshortened slivers, so 0.66 against 1.0 is both
    // the more solid picture and the more truthful projection.
    var _front = array_create(5);
    for (var _i = 0; _i < 5; _i++) {
        var _a = -pi * 0.5 + LOD_TAU * _i / 5;
        _front[_i] = [cos(_a) * _r * 0.66, _cy + sin(_a) * _r * 0.66];
    }
    var _outer = array_create(5);
    for (var _i = 0; _i < 5; _i++) {
        var _a = -pi * 0.5 + LOD_TAU * (_i + 0.5) / 5;
        _outer[_i] = [cos(_a) * _r * 1.00, _cy + sin(_a) * _r * 0.97];
    }
    for (var _i = 0; _i < 5; _i++) {
        var _j = (_i + 1) % 5;
        lod_append(_out, lod_facet([_front[_i], _outer[_i], _outer[_j], _front[_j]], 0, _cy, 0.004));
    }
    lod_append(_out, lod_facet(_front, 0, _cy + _r, 0.004));
    // Pyrite's faces carry parallel STRIATIONS, and they run at right angles on adjacent faces -
    // which is the single most recognisable thing about the mineral.
    for (var _i = 0; _i < 5; _i++) {
        var _c = lod_centroid([_front[_i], _outer[_i], _outer[(_i + 1) % 5], _front[(_i + 1) % 5]]);
        var _a = ((_i % 2) == 0) ? 0.0 : (pi * 0.5);
        for (var _k = -2; _k <= 2; _k++) {
            var _off = _k * 0.014;
            array_push(_out, lod_poly([[_c[0] + cos(_a) * _r * 0.16 - sin(_a) * _off, _c[1] + sin(_a) * _r * 0.16 + cos(_a) * _off],
                                       [_c[0] - cos(_a) * _r * 0.16 - sin(_a) * _off, _c[1] - sin(_a) * _r * 0.16 + cos(_a) * _off]],
                                      false, 0.0022, "m1"));
        }
    }
    return _out;
}

/// ============================================================================================
/// THE DISPATCH
/// ============================================================================================

/// Build the parts for one habit. _seed makes it deterministic; the same seed always draws the
/// same specimen, which is what lets a buyer store a stone as an integer.
///
/// ⛔ THE SWITCH IS EXHAUSTIVE AND lod_selftest ASSERTS IT. A habit that fell through to a default
/// would draw a DIFFERENT species' picture, silently, and the corpus audit's "all 21 reached"
/// guarantee would be about a table nothing consults.
function lod_habit_parts(_habit, _seed, _h, _w) {
    var _rng = lod_rng(_seed);
    switch (_habit) {
        case  0: return lod_habit_prismatic(_rng, _h, _w);
        case  1: return lod_habit_acicular(_rng, _h, _w);
        case  2: return lod_habit_botryoidal(_rng, _h, _w);
        case  3: return lod_habit_dendritic(_rng, _h, _w);
        case  4: return lod_habit_geode(_rng, _h, _w);
        case  5: return lod_habit_massive(_rng, _h, _w);
        case  6: return lod_habit_tabular(_rng, _h, _w);
        case  7: return lod_habit_rhombohedral(_rng, _h, _w);
        case  8: return lod_habit_octahedral(_rng, _h, _w);
        case  9: return lod_habit_cubic(_rng, _h, _w);
        case 10: return lod_habit_bladed(_rng, _h, _w);
        case 11: return lod_habit_stellate(_rng, _h, _w);
        case 12: return lod_habit_druzy(_rng, _h, _w);
        case 13: return lod_habit_fibrous(_rng, _h, _w);
        case 14: return lod_habit_reniform(_rng, _h, _w);
        case 15: return lod_habit_columnar(_rng, _h, _w);
        case 16: return lod_habit_encrusting(_rng, _h, _w);
        case 17: return lod_habit_scalenohedral(_rng, _h, _w);
        case 18: return lod_habit_wire(_rng, _h, _w);
        case 19: return lod_habit_nodular(_rng, _h, _w);
        case 20: return lod_habit_pyritohedral(_rng, _h, _w);
    }
    return [];
}
