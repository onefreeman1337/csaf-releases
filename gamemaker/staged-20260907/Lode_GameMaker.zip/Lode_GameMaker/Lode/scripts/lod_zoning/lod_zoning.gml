/// LODE - lod_zoning. The ten colour-distribution programs, and the derived body outline they
/// are all clipped to.
///
/// ============================================================================================
/// ZONING IS HOW COLOUR IS DISTRIBUTED THROUGH A STONE. IT IS NOT A SECOND HUE.
///
/// Habit decides the silhouette, lustre decides how light is written, and zoning decides where
/// the colour goes. Those three are independent in nature and independent here, which is the
/// arithmetic behind the corpus's claim: 21 habits x 10 lustres x 10 zoning programs is a space
/// with real internal logic, not a palette swap over one drawing.
///
/// ⛔ EVERY PROGRAM CLIPS TO THE BODY'S SPAN AT ITS OWN y, NEVER TO ITS BOUNDING BOX.
/// A shape is only as wide as its bounding box at ONE height (CLAUDE.md, Muster): a botryoidal
/// lobe reaches its box width at a single y, so a band drawn at any other height overhangs the
/// stone on both sides. At corpus scale that is a faint artefact; on a hero plate it is whiskers.
///
/// ⛔⛔ AND THE BODY OUTLINE IS DERIVED FROM THE HABIT'S OWN PARTS, NEVER AUTHORED BESIDE IT.
/// The obvious design is a `lod_habit_body(habit, ...)` per habit returning the silhouette to band
/// against. That is a SECOND declaration of the same fact, and this factory has paid for that
/// shape repeatedly - most expensively when five Game Boy cartridges each held a hand-typed copy
/// of a generated alphabet and a change to the generator armed an out-of-bounds read in four SOLD
/// products (CLAUDE.md §2b, 2026-08-30). Here the divergence would be quieter and just as real:
/// edit a habit, and its bands would keep following the shape it used to have.
///
/// So the body is DERIVED from the parts the habit actually emitted - its own largest filled
/// outline where it has one, and the convex hull of everything otherwise (lod_body_of). It cannot
/// go stale.
///
/// ⛔ HONEST LIMIT, AND IT IS ENFORCED RATHER THAN MERELY DOCUMENTED: a hull is not the silhouette
/// of an OPEN habit. On a spray, a starburst or a row of columns the hull spans BETWEEN the spikes,
/// so an area fill there covers open space and the specimen bakes as a solid block. Three species
/// reached a store sheet that way before this was a check rather than a paragraph - tourmaline as a
/// box, wavellite as a hexagon, vivianite as a slab. lod_habit_open() routes the area-filling
/// programs away from those, and lod_selftest proves that table against a real coverage measurement
/// per habit.
/// ============================================================================================

/// How much of its own hull a habit must COVER before an AREA-FILLING zoning program is allowed to
/// sit on it.
///
/// ⭐ THE NUMBER SITS IN A MEASURED GAP, WHICH IS THE ONLY HONEST WAY TO PICK A THRESHOLD.
/// lod_selftest runs lod_hull_coverage over all twenty-one habits and prints every figure into its
/// result file. Sorted, the corpus divides itself:
///
///     dendritic 0.000  acicular 0.262  stellate 0.336  encrusting 0.351  wire 0.517
///     columnar 0.696      <-- 0.22 of empty band -->      bladed 0.915  tabular 0.921 ...
///
/// NOTHING lands between 0.696 and 0.915. 0.80 is the middle of that gap, so the classification is
/// a property of the corpus rather than a number somebody liked. If a future habit lands INSIDE the
/// gap the suite fails naming it, and that is the moment to look at the picture rather than to move
/// the number.
#macro LOD_SPIKY_FLOOR 0.80

/// Which habits have an OPEN silhouette - one whose convex hull spans empty space.
///
/// ⛔⛔ THIS IS A DECLARED TABLE BECAUSE TWO MEASURED VERSIONS WERE BOTH WRONG, AND THE SECOND ONE
/// IS THE INSTRUCTIVE FAILURE.
///
/// v1 sampled the hull against its own BOUNDING BOX, which never looks at a part at all.
/// v2 (lod_ink_ratio) summed the AREA of every part against the hull's area, which double-counts
/// overlap and read 1.206 on a sheaf.
///
/// ⚠️ AND THE FIRST HAND-WRITTEN VERSION OF THIS TABLE WAS ALSO WRONG, ON TWO ENTRIES, WHICH IS
/// THE WHOLE POINT OF CHECKING IT. I declared the sheaf and the row-of-columns OPEN from looking at
/// them; lod_hull_coverage measures 0.915 and 0.696. The sheaf's blades overlap into a near-solid
/// mass and genuinely can carry a rim - my eye was wrong and the measurement was right. This table
/// now comes FROM the measurement rather than from an impression of it, which is the only reason
/// it can be trusted at the two entries nobody will re-examine.
///
/// ⭐ AREA IS NOT COVERAGE. Summing what was drawn cannot answer where it was drawn, and no
/// threshold on a sum of overlapping areas ever will. The honest measure is point-in-polygon
/// coverage, which is far too slow to run inside a specimen build a buyer's game calls every frame.
///
/// So openness is DECLARED here, once, and the slow honest measure lives in the suite and proves
/// this table per habit. That is the same shape as the wing's declared-extent law: make the fast
/// path a declaration and make the test verify it, rather than shipping a cheap proxy that is
/// wrong in a way nobody can see.
function lod_habit_open() {
    //     0 prismatic   1 acicular    2 botryoidal  3 dendritic   4 geode       5 massive
    //     6 tabular     7 rhombohed   8 octahedral  9 cubic      10 bladed     11 stellate
    //    12 druzy      13 fibrous    14 reniform   15 columnar   16 encrusting 17 scalenohed
    //    18 wire       19 nodular    20 pyritohedral
    // Derived from lod_hull_coverage against LOD_SPIKY_FLOOR - see the gap in that macro's header.
    // OPEN, with their measured coverage: acicular 0.262, dendritic 0.000, stellate 0.336,
    // columnar 0.696, encrusting 0.351, wire 0.517. Everything else covers 0.915 or more.
    return [false, true,  false, true,  false, false,
            false, false, false, false, false, true,
            false, false, false, true,  true,  false,
            true,  false, false];
}

/// Every point a part list touches, flattened. Used only to derive the hull.
function lod_parts_points(_parts) {
    var _out = [];
    for (var _i = 0; _i < array_length(_parts); _i++) {
        var _p = _parts[_i];
        switch (_p.kind) {
            case LOD_DOT:
                array_push(_out, [_p.cx - _p.r, _p.cy], [_p.cx + _p.r, _p.cy],
                                 [_p.cx, _p.cy - _p.r], [_p.cx, _p.cy + _p.r]);
                break;
            case LOD_ARC: {
                // Sample the arc rather than taking its bounding circle: a 20-degree arc's circle
                // is nearly all empty and would inflate the hull to a shape nothing drew.
                var _n = 9;
                for (var _k = 0; _k <= _n; _k++) {
                    var _a = _p.a0 + (_p.a1 - _p.a0) * (_k / _n);
                    array_push(_out, [_p.cx + cos(_a) * _p.r, _p.cy + sin(_a) * _p.r]);
                }
                break;
            }
            case LOD_POLY:
            case LOD_FILL:
                for (var _k = 0; _k < array_length(_p.pts); _k++) array_push(_out, _p.pts[_k]);
                break;
            case LOD_STRIP:
                for (var _k = 0; _k < array_length(_p.a); _k++) array_push(_out, _p.a[_k]);
                for (var _k = 0; _k < array_length(_p.b); _k++) array_push(_out, _p.b[_k]);
                break;
        }
    }
    return _out;
}

/// Andrew's monotone chain convex hull. Returns a closed outline in counter-clockwise order in a
/// y-down space, which is what lod_out_sign expects everything here to agree about.
function lod_hull(_pts) {
    var _n = array_length(_pts);
    if (_n < 3) return _pts;
    var _s = array_create(_n);
    for (var _i = 0; _i < _n; _i++) _s[_i] = _pts[_i];
    array_sort(_s, function(_a, _b) {
        if (_a[0] < _b[0]) return -1;
        if (_a[0] > _b[0]) return 1;
        if (_a[1] < _b[1]) return -1;
        if (_a[1] > _b[1]) return 1;
        return 0;
    });
    var _lower = [], _upper = [];
    for (var _i = 0; _i < _n; _i++) {
        while (array_length(_lower) >= 2 && _lod_cross(_lower[array_length(_lower) - 2], _lower[array_length(_lower) - 1], _s[_i]) <= 0) {
            array_delete(_lower, array_length(_lower) - 1, 1);
        }
        array_push(_lower, _s[_i]);
    }
    for (var _i = _n - 1; _i >= 0; _i--) {
        while (array_length(_upper) >= 2 && _lod_cross(_upper[array_length(_upper) - 2], _upper[array_length(_upper) - 1], _s[_i]) <= 0) {
            array_delete(_upper, array_length(_upper) - 1, 1);
        }
        array_push(_upper, _s[_i]);
    }
    array_delete(_lower, array_length(_lower) - 1, 1);
    array_delete(_upper, array_length(_upper) - 1, 1);
    var _out = _lower;
    for (var _i = 0; _i < array_length(_upper); _i++) array_push(_out, _upper[_i]);
    return _out;
}

/// The z component of (b-a) x (c-a).
function _lod_cross(_a, _b, _c) {
    return (_b[0] - _a[0]) * (_c[1] - _a[1]) - (_b[1] - _a[1]) * (_c[0] - _a[0]);
}

/// The body outline of a built habit.
///
/// ⛔⛔ THE HULL IS THE FALLBACK, NOT THE ANSWER, AND USING IT ALWAYS SHIPPED A VISIBLE DEFECT.
/// A hull is convex; a lump is not. `massive` builds its outline by wobbling a sampled arc, so it
/// has real concavities - and every band clipped to its hull ran OUT of the stone and hung in the
/// air on both sides, worst exactly where the wobble bit deepest. It measured 0.962 coverage and
/// sailed past the openness gate, because coverage is an AVERAGE and an overhang is LOCAL.
///
/// ⭐ When a habit draws its body as one big filled outline - which every lump, nodule, kidney,
/// geode and bunch in this corpus does - that outline IS the silhouette, concavities and all, and
/// it is right there in the part list. Prefer it. The hull is then used only where there genuinely
/// is no single body: a prism built from separate facets, a spray, a stack of plates.
///
/// ⚠️ THE LARGEST FILL MAY BE A FAN FROM lod_ring_fill, whose point list starts with an inserted
/// CENTROID and repeats its first point. That is harmless for every consumer here: the spurious
/// spike from the centroid to p0 lies INSIDE the polygon, so it adds no crossing outside the real
/// outline and lod_span_at_y's min/max are unaffected.
function lod_body_of(_parts) {
    var _hull = lod_hull(lod_parts_points(_parts));
    var _ha = abs(lod_area2(_hull)) * 0.5;
    if (_ha < 0.000100) return _hull;

    var _best = -1, _ba = 0;
    for (var _i = 0; _i < array_length(_parts); _i++) {
        if (_parts[_i].kind != LOD_FILL) continue;
        var _a = abs(lod_area2(_parts[_i].pts)) * 0.5;
        if (_a > _ba) { _ba = _a; _best = _i; }
    }
    // A body has to be most of the shape to be the body. Below that it is a facet or a mark, and
    // banding against it would clip every stripe to one plane of the crystal.
    if (_best >= 0 && _ba >= _ha * 0.55) return _parts[_best].pts;
    return _hull;
}

/// A signature over EVERY point a part list contains.
///
/// ⛔ EXISTS BECAUSE A BOUNDING BOX IS A USELESS PROXY FOR "DID THIS DRAWING CHANGE", AND THE SUITE
/// PROVED IT. The determinism stage originally asserted that a different seed moved the specimen's
/// BOUNDS - and Electrum went red on a picture that was changing perfectly well. Electrum is
/// `dendritic`, whose first branch has a fixed angle and length, drawn on a rock block whose width
/// and base are fixed; three of the four bounds could not move whatever the seed did.
///
/// ⭐ The general lesson is the one this factory keeps paying for: ASSERT THE RESULT, NOT AN
/// INGREDIENT OR A SUMMARY OF IT. A bounding box answers "how big", never "which shape", so a
/// generator could redraw every interior point and satisfy it. This walks every coordinate.
///
/// ⚠️ Deliberately NOT a hash. A float sum is stable across runs, is cheap, and the only property
/// asserted against it is CHANGED / UNCHANGED - for which a sum is exactly as good as a digest and
/// far easier to reason about when it fires.
function lod_parts_signature(_parts) {
    var _pts = lod_parts_points(_parts);
    var _s = array_length(_pts) * 7919;
    for (var _i = 0; _i < array_length(_pts); _i++) {
        _s += _pts[_i][0] * (_i + 3) + _pts[_i][1] * (_i + 11);
    }
    return _s;
}

/// How much of its own hull a part list's GEOMETRY actually covers, roughly, as a ratio.
///
/// ⛔⛔ THE FIRST VERSION OF THIS FUNCTION MEASURED THE WRONG TWO THINGS AND ITS NAME HID IT.
/// It sampled a grid over the hull's BOUNDING BOX and counted how many samples fell inside the
/// HULL - which is the ratio of the hull to its own box, a number that never looks at a single
/// part. It read 0.679 for `acicular`, a spray of thin needles that covers perhaps a tenth of its
/// hull, because a fan-shaped hull genuinely does fill most of a box.
///
/// ⭐ It was caught by a VACUITY GUARD written to prove the gate above it was under test, and that
/// is the whole argument for pairing every threshold with an assertion about its fixture: the two
/// behaviour checks beside it would have passed, and the gate would have sat there doing nothing
/// on exactly the three species it was written for.
///
/// This version compares AREA to AREA. A fill contributes its polygon area, a strip the area
/// between its rails, a stroke its length times its width, a dot its disc. Overlap is not
/// subtracted, so a solid form can exceed 1.0 - which is fine, because the only question asked of
/// this number is "is there enough geometry here for an area fill to sit on".
/// TRUE COVERAGE: the fraction of the hull that at least one part actually paints.
///
/// ⛔ FOR THE SUITE ONLY. It is O(samples x parts) with a point-in-polygon test at every pair, which
/// is exactly why lod_habit_open() is a declared table rather than a call to this. Running it inside
/// a specimen build would put tens of thousands of polygon tests into a buyer's draw loop.
///
/// ⚠️ IT COUNTS AREA-PAINTING PARTS ONLY - fills, strips and dots. A stroke covers a line and no
/// area worth speaking of, which is precisely why `dendritic`, whose whole picture is strokes, is
/// an OPEN habit: there is nothing there for a band to land on.
function lod_hull_coverage(_parts, _samples) {
    var _hull = lod_body_of(_parts);
    if (array_length(_hull) < 3) return 0;
    var _bb = lod_pts_bounds(_hull);
    var _n = is_undefined(_samples) ? 20 : _samples;
    var _in = 0, _hit = 0;
    for (var _r = 0; _r < _n; _r++) {
        var _y = _bb[1] + (_bb[3] - _bb[1]) * ((_r + 0.5) / _n);
        var _sp = lod_span_at_y(_hull, _y);
        if (is_undefined(_sp)) continue;
        for (var _c = 0; _c < _n; _c++) {
            var _x = _bb[0] + (_bb[2] - _bb[0]) * ((_c + 0.5) / _n);
            if (_x < _sp[0] || _x > _sp[1]) continue;   // outside the hull: not part of the question
            _in++;
            if (_lod_covered(_parts, _x, _y)) _hit++;
        }
    }
    if (_in == 0) return 0;
    return _hit / _in;
}

/// Is (x,y) inside any area-painting part?
function _lod_covered(_parts, _x, _y) {
    for (var _i = 0; _i < array_length(_parts); _i++) {
        var _p = _parts[_i];
        switch (_p.kind) {
            case LOD_DOT:
                if (point_distance(_x, _y, _p.cx, _p.cy) <= _p.r) return true;
                break;
            case LOD_FILL:
                if (_lod_in_poly(_p.pts, _x, _y)) return true;
                break;
            case LOD_STRIP: {
                var _n = min(array_length(_p.a), array_length(_p.b));
                for (var _k = 0; _k < _n - 1; _k++) {
                    if (_lod_in_poly([_p.a[_k], _p.a[_k + 1], _p.b[_k + 1], _p.b[_k]], _x, _y)) return true;
                }
                break;
            }
        }
    }
    return false;
}

/// Ray-casting point-in-polygon.
function _lod_in_poly(_pts, _x, _y) {
    var _n = array_length(_pts);
    if (_n < 3) return false;
    var _inside = false;
    for (var _i = 0, _j = _n - 1; _i < _n; _j = _i++) {
        var _yi = _pts[_i][1], _yj = _pts[_j][1];
        if ((_yi > _y) == (_yj > _y)) continue;
        var _xi = _pts[_i][0], _xj = _pts[_j][0];
        if (_x < (_xj - _xi) * (_y - _yi) / (_yj - _yi) + _xi) _inside = !_inside;
    }
    return _inside;
}

function lod_ink_ratio(_parts) {
    var _hull = lod_body_of(_parts);
    if (array_length(_hull) < 3) return 0;
    var _ha = abs(lod_area2(_hull)) * 0.5;
    if (_ha < 0.000100) return 0;

    var _a = 0;
    for (var _i = 0; _i < array_length(_parts); _i++) {
        var _p = _parts[_i];
        switch (_p.kind) {
            case LOD_DOT: _a += pi * _p.r * _p.r; break;
            case LOD_ARC: _a += abs(_p.a1 - _p.a0) * _p.r * max(_p.w, 0.002); break;
            case LOD_FILL: _a += abs(lod_area2(_p.pts)) * 0.5; break;
            case LOD_POLY: {
                var _n = array_length(_p.pts);
                var _len = 0;
                for (var _k = 0; _k < _n - 1; _k++) {
                    _len += point_distance(_p.pts[_k][0], _p.pts[_k][1], _p.pts[_k + 1][0], _p.pts[_k + 1][1]);
                }
                if (_p.closed && _n > 1) {
                    _len += point_distance(_p.pts[_n - 1][0], _p.pts[_n - 1][1], _p.pts[0][0], _p.pts[0][1]);
                }
                _a += _len * max(_p.w, 0.002);
                break;
            }
            case LOD_STRIP: {
                var _n2 = min(array_length(_p.a), array_length(_p.b));
                for (var _k = 0; _k < _n2 - 1; _k++) {
                    // The quad a0,a1,b1,b0 as two triangles.
                    _a += abs(lod_area2([_p.a[_k], _p.a[_k + 1], _p.b[_k + 1], _p.b[_k]])) * 0.5;
                }
                break;
            }
        }
    }
    return _a / _ha;
}

/// Does a mark of half-size (_rx,_ry) centred at (_cx,_cy) fit inside the body at EVERY height it
/// occupies?
///
/// ⛔ CHECKING THE SPAN AT THE CENTRE ONLY IS NOT ENOUGH, AND THE SUITE MEASURED THE DIFFERENCE.
/// `speckled` and `mottled` both placed their marks by clamping x against the span at the mark's
/// CENTRE height - which is correct there and wrong at its top and bottom, because a stone narrows
/// as it rises. A speck sitting on the shoulder of a crystal therefore poked out of it by up to
/// 0.063 of the unit box, and a mottle patch by 0.021.
///
/// ⚠️ NEITHER MY OWN READING OF THE BAKED SHEET NOR THE BOUNDING-BOX ASSERTION SAW EITHER OF THEM.
/// I had gone to the sheet suspecting `banded` and `iridescent`, wrote a per-point span assertion
/// to settle the argument, and it cleared both of those and named these two instead. A picture that
/// two readings disagree about is a picture to MEASURE.
///
/// ⭐ A MARK OCCUPIES A RANGE OF HEIGHTS, SO IT MUST FIT AT ALL OF THEM. Same family as the wing's
/// span-at-y law one level up: there the mistake was clipping to a bounding box instead of a span,
/// here it is sampling the span at one height instead of across the mark's own range.
function lod_fits_span(_body, _cx, _cy, _rx, _ry) {
    for (var _k = -1; _k <= 1; _k++) {
        var _s = lod_span_at_y(_body, _cy + _ry * _k);
        if (is_undefined(_s)) return false;
        if (_cx - _rx < _s[0] || _cx + _rx > _s[1]) return false;
    }
    return true;
}

/// ============================================================================================
/// THE TEN PROGRAMS
///
/// Each returns parts drawn IN the body, using the secondary roles z0..z4 for the second colour
/// and m0..m4 for the mineral's own. The caller maps both.
/// ============================================================================================

/// A horizontal band across the body, clipped to the body's span at each of its own edges.
function _lod_band(_body, _y0, _y1, _role) {
    var _n = 10;
    var _a = array_create(_n + 1), _b = array_create(_n + 1);
    var _any = false;
    for (var _i = 0; _i <= _n; _i++) {
        var _y = _y0 + (_y1 - _y0) * (_i / _n);
        var _sp = lod_span_at_y(_body, _y);
        if (is_undefined(_sp)) { _a[_i] = [0, _y]; _b[_i] = [0, _y]; continue; }
        _a[_i] = [_sp[0], _y]; _b[_i] = [_sp[1], _y];
        _any = true;
    }
    if (!_any) return [];
    return [lod_strip(_a, _b, _role)];
}

/// 1 BANDED. Parallel bands - agate, malachite, rhodochrosite.
///
/// ⛔ THE FIRST VERSION PAINTED HALF THE STONE IN ONE FLAT SECONDARY AND NINE SPECIES CAME BACK
/// LOOKING LIKE BEACH TOWELS. Two things were wrong and only one of them was the band code.
///
/// 1. THE BANDS WERE TOO BROAD AND TOO FEW. A real agate has many fine bands with the ground
///    showing between them, not five stripes covering half the section. Thin bands, and the gap
///    between them is wider than the band.
/// 2. THEY WERE ALL THE SAME COLOUR, so a banded stone had two tones and no light in it. Real
///    banding varies band to band; stepping through three of the secondary's own stops gives the
///    section internal structure for free and costs nothing.
///
/// ⚠️ AND THE SECOND COLOUR ITSELF WAS THE LARGER HALF OF THE PROBLEM - see lod_pal_for, where the
/// secondary now sits much closer to the mineral. A band is a compositional change WITHIN one
/// species; it is not a different mineral.
function lod_zone_banded(_rng, _body, _bb) {
    var _out = [];
    var _h = _bb[3] - _bb[1];
    // Derived from the height so a tall stone gets MORE bands rather than thicker ones - the same
    // physical-detail law that bounds every grain in this package.
    var _n = clamp(floor(_h / 0.045), 4, 14);
    for (var _i = 0; _i < _n; _i++) {
        var _y = _bb[1] + _h * ((_i + 0.5) / _n);
        var _t = _h * (0.020 + 0.016 * lod_rng_next(_rng));
        if (_y + _t > _bb[3]) continue;
        lod_append(_out, _lod_band(_body, _y, _y + _t, "z" + string(1 + (_i % 3))));
    }
    return _out;
}

/// 2 ZONED. Colour changes core to rim - watermelon tourmaline, sphalerite.
///
/// ⛔ IT IS A RIM, NOT A CORE FILL, AND THE FIRST VERSION DESTROYED THE PICTURE IT SAT ON. Filling
/// the inner 60% of the hull paints an opaque disc over everything the habit drew - and on the
/// GEODE, whose whole subject is a cavity lined with inward-pointing crystals, the hero image came
/// back as a flat mauve disc inside a grey tyre. Every facet, every lining crystal and the cavity
/// itself were underneath it.
///
/// ⭐ A rim strip is both the fix and the more truthful drawing: watermelon tourmaline is a pink
/// core with a GREEN RIND on it, not a two-tone disc, and the second colour belongs where the
/// crystal's composition changed last - at the outside. It also leaves the interior alone by
/// construction, so no future habit can be painted over by it.
function lod_zone_zoned(_rng, _body, _bb) {
    var _k = 0.74 + 0.10 * lod_rng_next(_rng);
    var _inner = lod_scale_pts(_body, _k);
    var _n = array_length(_body);
    // A strip needs both rails the same length, which they are by construction here: lod_scale_pts
    // returns one point per input point. Closing the ring means repeating the first pair.
    var _a = array_create(_n + 1), _b = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        _a[_i] = _body[_i % _n];
        _b[_i] = _inner[_i % _n];
    }
    return [lod_strip(_a, _b, "z2"), lod_poly(_inner, true, 0.0035, "z1")];
}

/// 3 PHANTOM. A ghost of an earlier, smaller crystal inside - quartz, calcite, cassiterite.
/// Drawn as an OUTLINE rather than a fill, because that is what a phantom is: a dusted growth
/// surface, visible through clear stone, with the same stone on both sides of it.
function lod_zone_phantom(_rng, _body, _bb) {
    var _out = [];
    var _n = 2 + floor(lod_rng_next(_rng) * 2);
    for (var _i = 0; _i < _n; _i++) {
        var _k = 0.42 + 0.22 * _i + 0.06 * lod_rng_next(_rng);
        if (_k > 0.92) break;
        var _g = lod_scale_pts(_body, _k);
        // Shifted DOWN, because a phantom is where the crystal used to end and a crystal grows
        // upward: a concentric ghost centred on the middle reads as a reflection instead.
        array_push(_out, lod_poly(lod_move_pts(_g, 0, (_bb[3] - _bb[1]) * 0.10 * (1 - _k)), true, 0.0045, "z3"));
    }
    return _out;
}

/// 4 INCLUDED. Needles or flecks suspended inside - rutilated quartz, emerald's jardin, amber.
function lod_zone_included(_rng, _body, _bb) {
    var _out = [];
    var _n = 9 + floor(lod_rng_next(_rng) * 8);
    var _w = _bb[2] - _bb[0], _h = _bb[3] - _bb[1];
    for (var _i = 0; _i < _n; _i++) {
        var _y = _bb[1] + _h * (0.10 + 0.80 * lod_rng_next(_rng));
        var _sp = lod_span_at_y(_body, _y);
        if (is_undefined(_sp)) continue;
        if (_sp[1] - _sp[0] < _w * 0.12) continue;
        var _x = lerp(_sp[0], _sp[1], 0.12 + 0.76 * lod_rng_next(_rng));
        var _a = lod_rng_next(_rng) * pi;
        var _len = min(_w, _h) * (0.10 + 0.16 * lod_rng_next(_rng));
        var _x2 = _x + cos(_a) * _len, _y2 = _y + sin(_a) * _len;
        // Clip the far end back into the stone. A needle that runs out of the crystal is the
        // single most common way an inclusion program looks wrong.
        var _sp2 = lod_span_at_y(_body, _y2);
        if (is_undefined(_sp2)) continue;
        _x2 = clamp(_x2, _sp2[0], _sp2[1]);
        array_push(_out, lod_poly([[_x, _y], [_x2, _y2]], false, 0.0032, "z4"));
    }
    return _out;
}

/// 5 CHATOYANT. One moving band of light along the fibres - cat's eye, satin spar.
/// A single bright lens, ACROSS the fibre direction, which is what chatoyancy physically is.
function lod_zone_chatoyant(_rng, _body, _bb) {
    var _cy = lerp(_bb[1], _bb[3], 0.44);
    var _h = (_bb[3] - _bb[1]) * 0.10;
    var _out = [];
    lod_append(_out, _lod_band(_body, _cy - _h, _cy + _h * 0.6, "z4"));
    lod_append(_out, _lod_band(_body, _cy - _h * 0.42, _cy + _h * 0.20, "m4"));
    return _out;
}

/// 6 ASTERISM. A six-ray star - star sapphire, star garnet.
function lod_zone_asterism(_rng, _body, _bb) {
    var _cx = (_bb[0] + _bb[2]) * 0.5, _cy = lerp(_bb[1], _bb[3], 0.44);
    var _r = min(_bb[2] - _bb[0], _bb[3] - _bb[1]) * 0.46;
    var _out = [];
    for (var _i = 0; _i < 3; _i++) {
        var _a = pi * _i / 3 + 0.18;
        var _x0 = _cx - cos(_a) * _r, _y0 = _cy - sin(_a) * _r;
        var _x1 = _cx + cos(_a) * _r, _y1 = _cy + sin(_a) * _r;
        // ⛔ EACH END IS CLIPPED TO THE STONE'S OWN SPAN AT ITS OWN y. A star is INSIDE a cabochon;
        // rays that run past the girdle read as a beach ball, which is exactly what the product
        // COVER baked before this clip existed - on the one image most buyers ever see. The rest of
        // this file clips through lod_span_at_y and this program was the one that did not, because
        // its marks are strokes rather than bands and it did not look like it needed to.
        var _s0 = lod_span_at_y(_body, _y0);
        var _s1 = lod_span_at_y(_body, _y1);
        if (is_undefined(_s0) || is_undefined(_s1)) continue;
        // Pull in from the edge as well, so a ray stops short of the rim like a real asterism.
        var _in = (_bb[2] - _bb[0]) * 0.06;
        _x0 = clamp(_x0, _s0[0] + _in, _s0[1] - _in);
        _x1 = clamp(_x1, _s1[0] + _in, _s1[1] - _in);
        // Three lines, not six rays: a six-ray star IS three crossing lines, and drawing six rays
        // from a hub leaves a bright blob in the middle that no star sapphire has.
        array_push(_out, lod_poly([[_x0, _y0], [_x1, _y1]], false, 0.006, "z4"));
    }
    return _out;
}

/// 7 IRIDESCENT. Play of colour across the surface - labradorite, bismuth, chalcopyrite.
///
/// ⚠️ THE HUE DRIFT IS THE POINT AND THE LIGHTNESS MUST NOT MOVE MUCH. Iridescence is a change of
/// HUE at nearly constant lightness; a version that also brightens reads as a highlight, which is
/// a different physical thing and looks like a mistake beside a metallic lustre.
/// ⛔ IT IS A SHIMMER ACROSS THE SURFACE, NOT A REPAINT OF IT. The first version tiled four broad
/// bands over the whole stone at ONE lightness, and bismuth, chalcopyrite and opal all baked as
/// flat rainbow LAYER CAKES - every facet, bevel and relief cue underneath was painted out, and the
/// three species that should be the most spectacular in the corpus were the three flattest.
///
/// ⭐ The physics says which way to fix it. Iridescence is a thin-film effect on part of a surface:
/// you see the mineral, and ACROSS it a few narrow arcs of colour that move as you tilt. So the
/// bands must be NARROW and there must be more mineral than band - here about a third covered - and
/// they must leave the lit and shadowed faces reading through the gaps.
function lod_zone_iridescent(_rng, _body, _bb) {
    var _out = [];
    var _h = _bb[3] - _bb[1];
    var _n = clamp(floor(_h / 0.055), 3, 9);
    for (var _i = 0; _i < _n; _i++) {
        var _y0 = _bb[1] + _h * ((_i + 0.20) / _n);
        var _y1 = _y0 + _h / _n * (0.30 + 0.16 * lod_rng_next(_rng));
        lod_append(_out, _lod_band(_body, _y0, _y1, "i" + string(_i % 4)));
    }
    return _out;
}

/// 8 SPECKLED. Fine flecks - electrum, granite-hosted metals.
function lod_zone_speckled(_rng, _body, _bb) {
    var _out = [];
    var _w = _bb[2] - _bb[0], _h = _bb[3] - _bb[1];
    // A PHYSICAL grain: the count comes from the area, so a bigger stone gets more specks rather
    // than bigger ones (CLAUDE.md, Livery).
    var _n = clamp(floor(_w * _h / 0.00090), 12, 150);
    for (var _i = 0; _i < _n; _i++) {
        var _y = _bb[1] + _h * lod_rng_next(_rng);
        var _sp = lod_span_at_y(_body, _y);
        if (is_undefined(_sp)) continue;
        var _r = 0.004 + 0.004 * lod_rng_next(_rng);
        if (_sp[1] - _sp[0] < _r * 3) continue;
        var _x = lerp(_sp[0] + _r, _sp[1] - _r, lod_rng_next(_rng));
        // Must fit at the speck's top and bottom too, not only at its centre - see lod_fits_span.
        if (!lod_fits_span(_body, _x, _y, _r, _r)) continue;
        array_push(_out, lod_dot(_x, _y, _r, (_i % 3 == 0) ? "z1" : "z3"));
    }
    return _out;
}

/// 9 MOTTLED. Irregular patches - turquoise, chrysocolla, smithsonite.
function lod_zone_mottled(_rng, _body, _bb) {
    var _out = [];
    var _w = _bb[2] - _bb[0], _h = _bb[3] - _bb[1];
    var _n = 5 + floor(lod_rng_next(_rng) * 5);
    for (var _i = 0; _i < _n; _i++) {
        var _y = _bb[1] + _h * (0.12 + 0.76 * lod_rng_next(_rng));
        var _sp = lod_span_at_y(_body, _y);
        if (is_undefined(_sp)) continue;
        var _r = min(_w, _h) * (0.09 + 0.09 * lod_rng_next(_rng));
        if (_sp[1] - _sp[0] < _r * 2.4) continue;
        var _x = lerp(_sp[0] + _r, _sp[1] - _r, lod_rng_next(_rng));
        var _ry2 = _r * (0.62 + 0.4 * lod_rng_next(_rng));
        // Must fit at the patch's top and bottom too - see lod_fits_span.
        if (!lod_fits_span(_body, _x, _y, _r, _ry2)) continue;
        // Irregular, not elliptical. A field of ellipses reads as bubbles; a mottle is a patch.
        var _pts = lod_ellipse_pts(_x, _y, _r, _ry2, 11);
        for (var _k = 0; _k < array_length(_pts); _k++) {
            var _kk = 0.74 + 0.46 * lod_rng_next(_rng);
            _pts[_k] = [_x + (_pts[_k][0] - _x) * _kk, _y + (_pts[_k][1] - _y) * _kk];
        }
        array_push(_out, lod_ring_fill(_pts, (_i % 2 == 0) ? "z2" : "z1", _x, _y));
    }
    return _out;
}

/// ============================================================================================
/// THE DISPATCH
/// ============================================================================================

/// Build the zoning parts for a specimen whose habit has already been built.
///
/// ⛔ IT TAKES THE BUILT PARTS, NOT THE HABIT INDEX. That is what makes the body derived rather
/// than declared, and it is the whole argument in this file's header.
function lod_zoning_parts(_zoning, _seed, _parts, _habit) {
    if (_zoning == 0) return [];                        // uniform: the mineral's own colour, whole
    var _body = lod_body_of(_parts);
    if (array_length(_body) < 3) return [];
    var _bb = lod_pts_bounds(_body);
    var _rng = lod_rng(_seed + 7919);
    var _zn = _zoning;

    // ⛔⛔ THE HONEST LIMIT AT THE TOP OF THIS FILE IS NOW ENFORCED RATHER THAN MERELY DOCUMENTED,
    // AND IT SHIPPED VISIBLY BEFORE IT WAS. The header says a hull is not the silhouette of a
    // concave habit, and three species proved it on the corpus sheet: TOURMALINE (columnar) baked
    // as green columns inside a solid box, WAVELLITE (stellate) as a starburst inside a hexagon,
    // and VIVIANITE (bladed) as one solid slab. In every case the rim strip filled the GAPS BETWEEN
    // the spikes, because that is where the hull runs.
    //
    // ⭐ It was written down as a known limitation and it still shipped, which is the lesson worth
    // keeping: KNOWING A FAILURE IS NOT DETECTING IT (CLAUDE.md §2b, the `<p>undefined</p>` listing
    // that four clean audits walked past). A documented limit that nothing checks is a limit that
    // will be crossed by the next species somebody adds.
    //
    // lod_hull_fill measures how much of its own hull the habit actually occupies. Below the floor,
    // the AREA-FILLING programs are swapped for `included` - suspended needles, which sit inside the
    // real geometry and cannot bridge a gap. The stone still gets its second colour; it just gets it
    // in the one form that is safe on a spiky body.
    // _habit undefined means "this body is closed" - which is right for a CUT stone, whose girdle
    // is a convex outline by construction and is the only other caller.
    if (_zn == 1 || _zn == 2 || _zn == 5 || _zn == 7) {
        if (!is_undefined(_habit) && lod_habit_open()[clamp(_habit, 0, LOD_HABIT_N - 1)]) _zn = 4;
    }

    switch (_zn) {
        case 1: return lod_zone_banded(_rng, _body, _bb);
        case 2: return lod_zone_zoned(_rng, _body, _bb);
        case 3: return lod_zone_phantom(_rng, _body, _bb);
        case 4: return lod_zone_included(_rng, _body, _bb);
        case 5: return lod_zone_chatoyant(_rng, _body, _bb);
        case 6: return lod_zone_asterism(_rng, _body, _bb);
        case 7: return lod_zone_iridescent(_rng, _body, _bb);
        case 8: return lod_zone_speckled(_rng, _body, _bb);
        case 9: return lod_zone_mottled(_rng, _body, _bb);
    }
    return [];
}
