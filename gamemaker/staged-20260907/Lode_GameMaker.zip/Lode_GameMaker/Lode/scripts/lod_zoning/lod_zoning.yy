{
  "$GMScript": "v1",
  "%Name": "lod_zoning",
  "name": "lod_zoning",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}