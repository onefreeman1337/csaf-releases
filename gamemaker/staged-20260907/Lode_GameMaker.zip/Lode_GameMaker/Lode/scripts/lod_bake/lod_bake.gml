/// LODE - lod_bake. The store sheets, rendered BY THE PRODUCT.
///
/// ============================================================================================
/// ⛔ WHY THE GALLERY IS BAKED IN ENGINE AND NOT DRAWN BY A PREVIEWER.
/// A gallery rendered by a side previewer is a picture of a RE-IMPLEMENTATION. This wing measured
/// exactly that on a sibling product: the JavaScript previewer had a defect that was invisible in
/// the previewer and plainly visible in engine. Baking through Igor lets the listing say, truthfully,
/// that every image on the page was rendered by the code in the package.
///
/// ⛔ AND EVERY SHEET IS MEASURED, NOT EYEBALLED. lod_bk_one runs an INK BOUNDING BOX over the
/// finished surface and reports it. That catches an EMPTY sheet and a CLIPPED one - and it cannot
/// catch a SPARSE one, a wrongly-ordered one, or one where the picture is simply bad. The wing's
/// standing law: a bounding box cannot see the space inside itself, and the only instrument for
/// that is opening the PNG and looking at it. This file does not replace that step.
///
/// ⚠️ THE INK CHECK'S KNOWN BLIND SPOTS, carried forward because they are still true here:
///   - stride: y steps by 1, because a 1px hairline lands on one row and an even-only scan walks
///     past it. x may step by 2.
///   - a flat fill close to the page colour is NOT counted as ink, so a large panel at low contrast
///     can run off the bottom and still report ok.
///   - two boxes, not one: `full` for the clip test and `content`, measured below the title rule,
///     for the coverage floors, so the rule cannot satisfy them by itself.
/// ============================================================================================

#macro LOD_SHEET_W 1600
#macro LOD_SHEET_H 1000

function lod_bk_page()  { return lod_oklch(0.140, 0.009, 252); }
function lod_bk_ink()   { return lod_oklch(0.895, 0.010, 252); }
function lod_bk_dim()   { return lod_oklch(0.570, 0.010, 252); }
function lod_bk_rule()  { return lod_oklch(0.310, 0.012, 252); }
function lod_bk_warm()  { return lod_oklch(0.740, 0.080, 66);  }

/// A sheet heading.
///
/// ⛔ lod_text_label DRAWS AT THE x IT IS GIVEN (fa_left) - it does NOT centre on it. The donor
/// shipped titles running off the right edge by passing the page midpoint here, and the short
/// titles looked deliberately centred and hid it. Pass a LEFT edge.
function lod_bk_head(_title, _sub, _y) {
    lod_text_label(_title, 60, _y, LOD_SHEET_W - 120, 46, lod_bk_page(), lod_bk_ink());
    var _yy = _y + 58;
    if (_sub != "") {
        lod_text_body(_sub, 60, _yy, LOD_SHEET_W - 420, 19, lod_bk_dim());
        _yy += 30;
    }
    draw_set_colour(lod_bk_rule());
    draw_rectangle(60, _yy + 14, LOD_SHEET_W - 60, _yy + 15, false);
    return _yy + 40;
}

/// A caption under a cell, measured and scaled to its cell.
///
/// ⛔ THIS WING SHIPPED THE SAME OVERFLOW DEFECT TWICE - "WickthorSt Cuthman's" and "HEDGEHOG
/// FUNGUSCAULIFLOWER FUNGUS" - because the first fix shortened the DATA rather than making the
/// caption honest about its width. No ink check will ever catch it: overprinted text is ink
/// exactly where ink belongs. Found only by reading the sheet.
function lod_bk_caption(_text, _cx, _y, _maxw, _px, _col) {
    lod_text_line(_text, _cx - _maxw * 0.5, _y, _maxw, _px, _col, false);
}

/// Measure the rendered pixels. See this file's header for what it can and cannot see.
function lod_bk_ink_bounds(_w, _h, _contentY) {
    var _buf = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_buf, surface_get_target(), 0);
    var _pg = lod_bk_page();
    var _pr = colour_get_red(_pg), _pgn = colour_get_green(_pg), _pb = colour_get_blue(_pg);

    var _fx0 = _w, _fy0 = _h, _fx1 = -1, _fy1 = -1;
    var _cx0 = _w, _cy0 = _h, _cx1 = -1, _cy1 = -1;
    var _ink = 0;

    for (var _y = 0; _y < _h; _y++) {
        for (var _x = 0; _x < _w; _x += 2) {
            var _o = (_y * _w + _x) * 4;
            var _r = buffer_peek(_buf, _o, buffer_u8);
            var _g = buffer_peek(_buf, _o + 1, buffer_u8);
            var _b = buffer_peek(_buf, _o + 2, buffer_u8);
            if (abs(_r - _pr) <= 10 && abs(_g - _pgn) <= 10 && abs(_b - _pb) <= 10) continue;
            _ink += 1;
            if (_x < _fx0) _fx0 = _x;
            if (_x > _fx1) _fx1 = _x;
            if (_y < _fy0) _fy0 = _y;
            if (_y > _fy1) _fy1 = _y;
            if (_y >= _contentY) {
                if (_x < _cx0) _cx0 = _x;
                if (_x > _cx1) _cx1 = _x;
                if (_y < _cy0) _cy0 = _y;
                if (_y > _cy1) _cy1 = _y;
            }
        }
    }
    buffer_delete(_buf);
    return { full: [_fx0, _fy0, _fx1, _fy1], content: [_cx0, _cy0, _cx1, _cy1], ink: _ink };
}

/// A recessed well for a specimen to sit in, so a cell reads as a drawer rather than as a gap.
function lod_bk_well(_x, _y, _w, _h) {
    draw_set_colour(lod_oklch(0.190, 0.010, 252));
    draw_rectangle(_x, _y, _x + _w, _y + _h, false);
    draw_set_colour(lod_oklch(0.105, 0.008, 252));
    draw_rectangle(_x, _y, _x + _w, _y + 1, false);
    draw_rectangle(_x, _y, _x + 1, _y + _h, false);
    draw_set_colour(lod_oklch(0.275, 0.010, 252));
    draw_rectangle(_x, _y + _h - 1, _x + _w, _y + _h, false);
    draw_rectangle(_x + _w - 1, _y, _x + _w, _y + _h, false);
}

/// ============================================================================================
/// THE SHEETS
/// ============================================================================================

/// 1. HERO. One specimen, very large, with its cut stone beside it.
function lod_bk_hero() {
    var _y = lod_bk_head("EVERY MINERAL DRAWS ITSELF",
        "No sprites, no atlas, no texture page. A species is a row of numbers - habit, lustre, "
      + "zoning, matrix - and the picture is computed from them at runtime, at any size.", 46);

    // ⛔ NOT THE GEODE, AND THE FIRST VERSION OF THIS SHEET PROVED WHY. A geode is the iconic
    // mineral photograph and it is the WRONG hero for this product: at 728 px its cavity is a flat
    // dark disc filling most of the frame, the lining crystals read as teeth around it, and the
    // whole thing says "cog" rather than "stone". It works small - it is on the cover, behind the
    // beryl - and it fails large, which is the opposite of what a hero image needs.
    //
    // ⭐ A TERMINATED PRISM IS THE MOST LEGIBLE THING THIS CORPUS MAKES AT ANY SIZE: three plane
    // faces, a point, and a jardin of inclusions to prove the zoning is not a texture. Beryl also
    // cuts to a step, which is the second-best cell on the cuts sheet, so the pair on this sheet
    // are both strong. Choose the hero by looking at candidates AT HERO SIZE, not by picking the
    // most famous mineral.
    var _i = lod_species_index("Beryl");
    var _rough = lod_specimen(_i, 20260831, 0);
    lod_bk_well(60, _y, 760, 700);
    lod_specimen_draw(_rough, 76, _y + 16, 728, 668);
    lod_bk_caption(lod_specimen_label(_rough), 440, _y + 706, 700, 21, lod_bk_ink());

    var _sp0 = lod_species(_i);
    var _cut = lod_specimen(_i, 20260831, 3);
    lod_bk_well(860, _y, 340, 340);
    lod_specimen_draw(_cut, 876, _y + 16, 308, 308);
    lod_bk_caption(lod_cut_names()[_sp0.cut] + " cut, polished", 1030, _y + 346, 320, 18, lod_bk_dim());

    var _sp = lod_species(_i);
    var _tx = 1240;
    lod_text_line("THE SAME ROW OF NUMBERS", _tx, _y + 6, 300, 19, lod_bk_warm(), true);
    var _ty = _y + 40;
    var _rows = ["habit    " + lod_habit_names()[_sp.habit],
                 "lustre   " + lod_lustre_names()[_sp.lustre],
                 "zoning   " + lod_zoning_names()[_sp.zoning],
                 "cut      " + lod_cut_names()[_sp.cut],
                 "matrix   " + lod_matrix_names()[_sp.matrix],
                 "band     " + lod_band_names()[_sp.band],
                 "hardness " + string_format(_sp.hardness, 1, 1) + " Mohs",
                 "density  " + string_format(_sp.density, 1, 2) + " g/cm3"];
    for (var _k = 0; _k < array_length(_rows); _k++) {
        lod_text_line(_rows[_k], _tx, _ty, 300, 17, lod_bk_ink(), false);
        _ty += 27;
    }
    _ty += 18;
    lod_text_body("Change one index and the picture changes. Nothing is re-exported and nothing "
        + "is baked; the buyer's game holds two integers per stone.", _tx, _ty, 300, 16, lod_bk_dim());

    // The cut stone below, at the size a real inventory slot uses - the honest test.
    var _sy = _y + 420;
    lod_text_line("AT INVENTORY SIZE, 48 PX", 860, _sy, 340, 17, lod_bk_warm(), true);
    for (var _k = 0; _k < 6; _k++) {
        var _st = lod_specimen(lod_species_index("Amethyst") + _k * 3, 4400 + _k, 3);
        lod_bk_well(860 + _k * 56, _sy + 30, 48, 48);
        lod_specimen_draw(_st, 862 + _k * 56, _sy + 32, 44, 44);
    }
    // ⛔ THE BOTTOM RIGHT WAS BARE AND THE INK FLOORS PASSED IT AT 0.851 - a bounding box cannot
    // see the space inside itself, which is this wing's standing law and the reason opening the
    // file is not optional. Filling it with the corpus itself is also the strongest thing that
    // could go there: the sheet argues that a species is a row of numbers, and forty-eight names
    // in three columns is what forty-eight rows of numbers looks like.
    var _ly = _y + 520;
    lod_text_line("ALL FORTY-EIGHT, IN THE PACKAGE", 860, _ly, 680, 17, lod_bk_warm(), true);
    _ly += 28;
    // ⚠️ FOUR COLUMNS, NOT THREE, AND THE EXTENT CHECK IS WHAT SAID SO. Three columns is sixteen
    // rows at 21 px starting at 738, which ends at 1072 on a 1000 px page - the sheet reported
    // endY 1068 and clipped=True on the first bake. That check exists for exactly this and it
    // caught it in one run; the number is MEASURED, so do not widen the pitch without re-reading it.
    var _percol = ceil(LOD_SPECIES_N / 4);
    for (var _k = 0; _k < LOD_SPECIES_N; _k++) {
        var _col = floor(_k / _percol);
        var _row = _k - _col * _percol;
        lod_text_line(lod_species(_k).name, 860 + _col * 172, _ly + _row * 19, 166, 14,
                      lod_bk_ink(), false);
    }
    return max(_y + 740, _ly + _percol * 19 + 10);
}

/// 2. THE CORPUS. All 48 species, rough, in their own host rock.
function lod_bk_corpus() {
    var _y = lod_bk_head("FORTY-EIGHT SPECIES, FORTY-EIGHT DRAWINGS",
        "Not one recolour among them. No two species in this corpus share a habit, lustre and "
      + "zoning triple - the package refuses to build if any two do.", 40);

    var _cols = 8, _rows = 6;
    var _cw = (LOD_SHEET_W - 120) / _cols;
    var _ch = (LOD_SHEET_H - _y - 34) / _rows;
    for (var _i = 0; _i < LOD_SPECIES_N; _i++) {
        var _cx = 60 + (_i % _cols) * _cw;
        var _cy = _y + floor(_i / _cols) * _ch;
        lod_bk_well(_cx + 3, _cy, _cw - 6, _ch - 26);
        lod_specimen_draw(lod_specimen(_i, 3100 + _i * 37, 0), _cx + 8, _cy + 4, _cw - 16, _ch - 34);
        lod_bk_caption(lod_species(_i).name, _cx + _cw * 0.5, _cy + _ch - 22, _cw - 8, 15, lod_bk_ink());
    }
    return _y + _rows * _ch;
}

/// 3. HABITS. The twenty-one silhouette programs, large and named.
function lod_bk_habits() {
    var _y = lod_bk_head("TWENTY-ONE CRYSTAL HABITS",
        "Habit is the silhouette, and each one is a different construction rather than the same "
      + "shape at a different width. Every one is reachable by a species in the corpus.", 40);

    var _cols = 7, _rows = 3;
    var _cw = (LOD_SHEET_W - 120) / _cols;
    var _ch = (LOD_SHEET_H - _y - 30) / _rows;
    for (var _i = 0; _i < LOD_HABIT_N; _i++) {
        var _cx = 60 + (_i % _cols) * _cw;
        var _cy = _y + floor(_i / _cols) * _ch;
        lod_bk_well(_cx + 4, _cy, _cw - 8, _ch - 30);
        // One neutral material for every habit, so the SHAPE is what differs on this sheet and
        // nothing else. Showing 21 habits in 21 colours would prove nothing about the habits.
        var _sp = { name: "sample", family: "sample", habit: _i, lustre: 1, zoning: 0,
                    cut: LOD_CUT_NONE, matrix: 4, band: 3, hue: 210, sat: 0.10, val: 0.72,
                    hardness: 6, density: 3, rarity: 0.4 };
        var _pal = lod_pal_for(_sp, 4, 0, undefined);
        var _parts = lod_map_roles(lod_habit_parts(_i, 700 + _i * 91, 0.62, 0.34), lod_mat_map("s"));
        lod_render_in_rect_tight(_parts, _pal, _cx + 10, _cy + 5, _cw - 20, _ch - 40, undefined);
        lod_bk_caption(lod_habit_names()[_i], _cx + _cw * 0.5, _cy + _ch - 26, _cw - 10, 16, lod_bk_ink());
    }
    return _y + _rows * _ch;
}

/// 4. LUSTRE. One habit, one hue, ten lustres - the sheet that proves lustre is a shading program.
function lod_bk_lustre() {
    var _y = lod_bk_head("LUSTRE IS A SHADING PROGRAM, NOT A GLOSS SLIDER",
        "The same crystal, the same hue, ten lustres. Each changes how far the five-stop ramp "
      + "travels, how the stops are distributed, and which way chroma moves as the face lights.", 40);

    var _cols = 5, _rows = 2;
    var _cw = (LOD_SHEET_W - 120) / _cols;
    var _ch = (LOD_SHEET_H - _y - 30) / _rows;
    for (var _i = 0; _i < LOD_LUSTRE_N; _i++) {
        var _cx = 60 + (_i % _cols) * _cw;
        var _cy = _y + floor(_i / _cols) * _ch;
        lod_bk_well(_cx + 5, _cy, _cw - 10, _ch - 56);
        var _sp = { name: "sample", family: "sample", habit: 9, lustre: _i, zoning: 0,
                    cut: LOD_CUT_NONE, matrix: 0, band: 3, hue: 44, sat: 0.42, val: 0.62,
                    hardness: 6, density: 3, rarity: 0.4 };
        var _pal = lod_pal_for(_sp, 0, 0, undefined);
        var _parts = lod_map_roles(lod_habit_parts(9, 1234, 0.60, 0.34), lod_mat_map("s"));
        lod_render_in_rect_tight(_parts, _pal, _cx + 12, _cy + 6, _cw - 24, _ch - 74, undefined);
        // The ramp itself, printed under each cell. A claim about five stops is worth more when
        // the five stops are on the page.
        var _ramp = lod_mat_ramp(_sp, 0);
        for (var _k = 0; _k < LOD_RAMP_N; _k++) {
            draw_set_colour(_ramp[_k]);
            draw_rectangle(_cx + 20 + _k * 28, _cy + _ch - 48, _cx + 44 + _k * 28, _cy + _ch - 28, false);
        }
        lod_bk_caption(lod_lustre_names()[_i], _cx + _cw * 0.5, _cy + _ch - 24, _cw - 10, 16, lod_bk_ink());
    }
    return _y + _rows * _ch;
}

/// 5. ZONING. One habit, ten colour-distribution programs.
function lod_bk_zoning() {
    var _y = lod_bk_head("TEN WAYS COLOUR SITS IN A STONE",
        "Zoning is independent of habit and of lustre, which is the arithmetic behind the corpus: "
      + "21 x 10 x 10 is a space with real internal logic, not a palette swap over one drawing.", 40);

    var _cols = 5, _rows = 2;
    var _cw = (LOD_SHEET_W - 120) / _cols;
    var _ch = (LOD_SHEET_H - _y - 30) / _rows;
    for (var _i = 0; _i < LOD_ZONING_N; _i++) {
        var _cx = 60 + (_i % _cols) * _cw;
        var _cy = _y + floor(_i / _cols) * _ch;
        lod_bk_well(_cx + 5, _cy, _cw - 10, _ch - 30);
        var _sp = { name: "sample", family: "sample", habit: 5, lustre: 1, zoning: _i,
                    cut: LOD_CUT_NONE, matrix: 2, band: 3, hue: 196, sat: 0.44, val: 0.66,
                    hardness: 6, density: 3, rarity: 0.4 };
        var _pal = lod_pal_for(_sp, 2, 0, undefined);
        var _hab = lod_habit_parts(5, 2468, 0.60, 0.36);
        var _parts = lod_map_roles(_hab, lod_mat_map("s"));
        // ⛔ MAPPED, AND WITH THE HABIT PASSED - both of which this sheet was missing, and the sheet
        // is where it showed. Unmapped, `chatoyant`'s bright m4 core is not in the palette at all
        // and lod_render_colour falls back to `line`, so the cat's-eye band baked GREY on a
        // turquoise stone. lod_specimen_parts does both correctly; this sheet builds its cells by
        // hand to hold the habit constant, and hand-built call sites are where a contract gets
        // dropped.
        lod_append(_parts, lod_map_roles(lod_zoning_parts(_i, 2468, _hab, 5), lod_mat_map("s")));
        lod_render_in_rect_tight(_parts, _pal, _cx + 12, _cy + 6, _cw - 24, _ch - 48, undefined);
        lod_bk_caption(lod_zoning_names()[_i], _cx + _cw * 0.5, _cy + _ch - 26, _cw - 10, 16, lod_bk_ink());
    }
    return _y + _rows * _ch;
}

/// 6. THE CUT. Rough, cut and polished, for eight species - the product's whole loop in one image.
function lod_bk_cut() {
    var _y = lod_bk_head("ROUGH, CUT, POLISHED",
        "The same stone at three stages. Polishing is not a brightening: a smooth surface reflects "
      + "specularly instead of scattering, so the shadows DEEPEN as the highlight lifts.", 40);

    // ⛔ TWO COLUMNS OF FOUR, NOT FOUR OF TWO, AND THE FIRST LAYOUT WAS A TEXTBOOK CASE OF THIS
    // WING'S DEAD-SPACE LAW: "a specimen's aspect must match its cell, or a tight fit manufactures
    // dead space". Four across gave each stage a cell 118 wide by 344 tall - a 1:3 letterbox for a
    // roughly square stone - so lod_render_in_rect_tight matched the WIDTH and left more than half
    // of every cell bare. The ink floors passed it at 0.910 x 0.952, because a bounding box cannot
    // see the space inside itself. Fix the GRID, never the threshold.
    var _names = ["Amethyst", "Beryl", "Garnet", "Topaz", "Fluorite", "Peridot", "Zircon", "Opal"];
    var _cw = (LOD_SHEET_W - 120) / 2;
    var _ch = (LOD_SHEET_H - _y - 24) / 4;
    for (var _i = 0; _i < array_length(_names); _i++) {
        var _si = lod_species_index(_names[_i]);
        if (_si < 0) continue;
        var _cx = 60 + (_i % 2) * _cw;
        var _cy = _y + floor(_i / 2) * _ch;
        var _third = (_cw - 150) / 3;
        // The label sits to the LEFT of the row rather than under it, which is what buys the
        // stages their height back.
        lod_text_line(_names[_i], _cx + 6, _cy + _ch * 0.34, 138, 19, lod_bk_ink(), true);
        lod_text_line("rough / cut / polished", _cx + 6, _cy + _ch * 0.34 + 26, 138, 13, lod_bk_dim(), false);
        for (var _st = 0; _st < 3; _st++) {
            var _state = (_st == 0) ? 0 : ((_st == 1) ? 2 : 3);
            lod_bk_well(_cx + 150 + _st * _third, _cy + 4, _third - 8, _ch - 16);
            lod_specimen_draw(lod_specimen(_si, 8800 + _si, _state),
                              _cx + 154 + _st * _third, _cy + 8, _third - 16, _ch - 24);
        }
    }
    return _y + 4 * _ch;
}

/// 7. CUTS. The ten faceted cuts.
function lod_bk_cuts() {
    var _y = lod_bk_head("TEN FACETED CUTS, DRAWN AS FACETS",
        "A gem drawn as an outline with a highlight looks like plastic. These are drawn with a "
      + "table, a crown and the pavilion seen through the stone, which is what makes one read.", 40);

    var _cols = 5, _rows = 2;
    var _cw = (LOD_SHEET_W - 120) / _cols;
    var _ch = (LOD_SHEET_H - _y - 30) / _rows;
    for (var _i = 0; _i < LOD_CUT_N; _i++) {
        var _cx = 60 + (_i % _cols) * _cw;
        var _cy = _y + floor(_i / _cols) * _ch;
        lod_bk_well(_cx + 5, _cy, _cw - 10, _ch - 30);
        var _sp = { name: "sample", family: "sample", habit: 0, lustre: 2, zoning: 0,
                    cut: _i, matrix: 0, band: 4, hue: 348, sat: 0.62, val: 0.58,
                    hardness: 8, density: 4, rarity: 0.8 };
        var _pal = lod_pal_for(_sp, 0, 1.0, undefined);
        var _parts = lod_map_roles(lod_cut_parts(_sp, 500 + _i, 0.40), lod_mat_map("s"));
        lod_render_in_rect_tight(_parts, _pal, _cx + 14, _cy + 8, _cw - 28, _ch - 52, undefined);
        lod_bk_caption(lod_cut_names()[_i], _cx + _cw * 0.5, _cy + _ch - 26, _cw - 10, 16, lod_bk_ink());
    }
    return _y + _rows * _ch;
}

/// 8. THE HOST ROCK. Eight matrices, each with its own grain program.
function lod_bk_matrix() {
    var _y = lod_bk_head("EIGHT HOST ROCKS, EIGHT GRAIN PROGRAMS",
        "Granite is speckled, shale is laminated, schist is foliated, serpentinite is veined. "
      + "Different programs, not one noise function at eight amplitudes.", 40);

    var _cols = 4, _rows = 2;
    var _cw = (LOD_SHEET_W - 120) / _cols;
    var _ch = (LOD_SHEET_H - _y - 30) / _rows;
    for (var _i = 0; _i < LOD_MATRIX_N; _i++) {
        var _cx = 60 + (_i % _cols) * _cw;
        var _cy = _y + floor(_i / _cols) * _ch;
        lod_bk_well(_cx + 5, _cy, _cw - 10, _ch - 46);
        var _sp = { name: "sample", family: "sample", habit: 0, lustre: 1, zoning: 0,
                    cut: LOD_CUT_NONE, matrix: _i, band: 3, hue: 190, sat: 0.20, val: 0.80,
                    hardness: 7, density: 2.65, rarity: 0.2 };
        var _pal = lod_pal_for(_sp, _i, 0, undefined);
        var _parts = lod_map_roles(lod_rock_block(_i, 1900 + _i * 53, 0.44, 0.16), lod_mat_map("r"));
        lod_append(_parts, lod_map_roles(lod_habit_parts(0, 1900 + _i, 0.56, 0.24), lod_mat_map("s")));
        lod_render_in_rect_tight(_parts, _pal, _cx + 14, _cy + 8, _cw - 28, _ch - 66, undefined);
        lod_bk_caption(lod_matrix_names()[_i], _cx + _cw * 0.5, _cy + _ch - 42, _cw - 10, 16, lod_bk_ink());
        lod_bk_caption(lod_band_names()[min(_i, LOD_BAND_N - 1)] + " zone",
                       _cx + _cw * 0.5, _cy + _ch - 22, _cw - 10, 13, lod_bk_dim());
    }
    return _y + _rows * _ch;
}

/// 9. THE SYSTEM. The prospecting and assay loop, with its real numbers on the page.
///
/// ⭐ A STORE SHEET THAT PRINTS ITS OWN NUMBERS IS A BETTER INSTRUMENT THAN THE SUITE (CLAUDE.md,
/// Muster): the suite asserts what somebody thought to ask, and a printed figure that is absurd is
/// visible to anyone who reads the page. Every number below is computed at bake time.
function lod_bk_system() {
    var _y = lod_bk_head("IT IS A SYSTEM, NOT A PICTURE LIBRARY",
        "Prospecting by depth band, assay by density and hardness, cutting gated on Mohs, and a "
      + "cabinet that scores by best state. Every figure on this sheet was computed by the package.", 40);

    // LEFT: the depth column. Which species are reachable at each depth.
    lod_text_line("THE COLUMN", 60, _y, 420, 20, lod_bk_warm(), true);
    var _cy = _y + 34;
    for (var _b = 0; _b < LOD_BAND_N; _b++) {
        var _depth = _b / max(1, LOD_BAND_N - 1);
        var _n = 0;
        for (var _i = 0; _i < LOD_SPECIES_N; _i++) if (lod_spawn_weight(_i, _depth) > 0) _n++;
        lod_text_line(lod_band_names()[_b], 60, _cy, 180, 17, lod_bk_ink(), false);
        lod_text_line(string(_n) + " species reachable", 250, _cy, 230, 17, lod_bk_dim(), false);
        // A bar, so the shape of the column is visible without reading the numbers.
        draw_set_colour(lod_bk_warm());
        draw_rectangle(250, _cy + 21, 250 + _n * 8, _cy + 25, false);
        _cy += 44;
    }

    // MIDDLE: the assay. The same stone read by three kits.
    lod_text_line("ONE STONE, THREE ASSAY KITS", 560, _y, 480, 20, lod_bk_warm(), true);
    var _si = lod_species_index("Gold");
    var _stone = lod_specimen(_si, 424242, 1);
    var _ay = _y + 34;
    var _skills = [0.10, 0.55, 0.95];
    var _labels = ["a pan and an eye", "a balance and a streak plate", "a full assay bench"];
    for (var _k = 0; _k < 3; _k++) {
        var _as = lod_assay(_stone, _skills[_k]);
        lod_text_line(_labels[_k], 560, _ay, 460, 17, lod_bk_ink(), true);
        lod_text_line("density reads " + string_format(_as.density, 1, 1)
                    + "   hardness reads " + string_format(_as.hardness, 1, 1),
                      560, _ay + 24, 460, 16, lod_bk_dim(), false);
        var _cand = "";
        var _lim = min(array_length(_as.candidates), 6);
        for (var _c2 = 0; _c2 < _lim; _c2++) {
            if (_c2 > 0) _cand += ", ";
            _cand += lod_species(_as.candidates[_c2]).name;
        }
        if (array_length(_as.candidates) > _lim) _cand += ", ...";
        lod_text_line(string(array_length(_as.candidates)) + " candidates: " + _cand,
                      560, _ay + 46, 460, 15, lod_bk_warm(), false);
        _ay += 92;
    }
    lod_text_body("The reading's error is seeded from the STONE, so an unskilled assay is "
        + "consistently wrong. A player cannot re-read the same rock until the answer improves.",
        560, _ay + 4, 460, 15, lod_bk_dim());

    // RIGHT: cutting, gated on Mohs.
    lod_text_line("WHAT A TOOL CAN BITE", 1090, _y, 450, 20, lod_bk_warm(), true);
    var _ty = _y + 34;
    var _tools = [2.5, 5.5, 7.5, 10.0];
    var _tnames = ["a copper file", "a steel wheel", "a corundum lap", "a diamond lap"];
    for (var _k = 0; _k < array_length(_tools); _k++) {
        var _can = 0, _tot = 0;
        for (var _i = 0; _i < LOD_SPECIES_N; _i++) {
            if (!lod_is_cuttable(lod_species(_i))) continue;
            _tot++;
            if (lod_cut_outcome(lod_specimen(_i, 99, 1), _tools[_k], 0.9, 7) != 0) _can++;
        }
        lod_text_line(_tnames[_k] + "  (Mohs " + string_format(_tools[_k], 1, 1) + ")",
                      1090, _ty, 440, 17, lod_bk_ink(), false);
        lod_text_line("cuts " + string(_can) + " of " + string(_tot) + " cuttable species",
                      1090, _ty + 22, 440, 15, lod_bk_dim(), false);
        draw_set_colour(lod_bk_warm());
        draw_rectangle(1090, _ty + 44, 1090 + (_tot > 0 ? (_can / _tot) * 430 : 0), _ty + 48, false);
        _ty += 74;
    }
    var _cab = lod_cabinet_new();
    for (var _i = 0; _i < LOD_SPECIES_N; _i += 3) lod_cabinet_add(_cab, lod_specimen(_i, 5, 1));
    lod_text_line("A CABINET WITH " + string(_cab.found) + " ROUGH SPECIMENS IN IT SCORES "
                + string_format(lod_cabinet_completion(_cab) * 100, 1, 1) + " PER CENT",
                  1090, _ty + 6, 440, 16, lod_bk_warm(), true);
    lod_text_body("It scores by BEST STATE, not by presence - a case of rough is a third full. "
        + "Finding a second rough quartz when a polished one is already in the case is not progress.",
        1090, _ty + 32, 440, 15, lod_bk_dim());

    // ⛔ THE BOTTOM BAND EXISTS BECAUSE THE SHEET FAILED ITS OWN COVERAGE FLOOR AT 0.467, AND THE
    // FIX IS CONTENT RATHER THAN A LOWER THRESHOLD (wing CLAUDE.md: rebuild the sheet, never tune
    // the number). It is also the right thing to show: a sheet arguing that depth decides what you
    // find should PRINT what each depth yields, not merely count it.
    var _by = 706;
    draw_set_colour(lod_bk_rule());
    draw_rectangle(60, _by - 22, LOD_SHEET_W - 60, _by - 21, false);
    lod_text_line("WHAT THE COLUMN ACTUALLY YIELDS - PANNED AT EACH DEPTH, BY THE PACKAGE",
                  60, _by - 8, LOD_SHEET_W - 120, 17, lod_bk_warm(), true);
    var _cellw = (LOD_SHEET_W - 120) / LOD_BAND_N;
    for (var _b2 = 0; _b2 < LOD_BAND_N; _b2++) {
        var _depth2 = _b2 / max(1, LOD_BAND_N - 1);
        var _cx2 = 60 + _b2 * _cellw;
        lod_bk_well(_cx2 + 4, _by + 18, _cellw - 8, 190);
        // Pan until this depth yields something, and SAY how many pans it took - which is the
        // honest way to show that an empty pan is possible without printing a blank cell.
        var _tries = 0, _got2 = -1;
        while (_tries < 60 && _got2 < 0) {
            _got2 = lod_prospect(_depth2, _b2 * 977 + _tries * 13 + 5);
            _tries++;
        }
        if (_got2 >= 0) {
            lod_specimen_draw(lod_specimen(_got2, 6100 + _got2, 0), _cx2 + 10, _by + 24, _cellw - 20, 178);
            lod_bk_caption(lod_species(_got2).name, _cx2 + _cellw * 0.5, _by + 214, _cellw - 10, 15, lod_bk_ink());
        } else {
            lod_bk_caption("nothing here", _cx2 + _cellw * 0.5, _by + 110, _cellw - 10, 15, lod_bk_dim());
        }
        lod_bk_caption(lod_band_names()[_b2] + "   " + string(_tries) + " pan" + ((_tries == 1) ? "" : "s"),
                       _cx2 + _cellw * 0.5, _by + 234, _cellw - 10, 13, lod_bk_dim());
    }
    return _by + 260;
}

/// ============================================================================================
/// THE RUNNER
/// ============================================================================================

function lod_bk_one(_name, _fn, _contentY) {
    var _surf = surface_create(LOD_SHEET_W, LOD_SHEET_H);
    surface_set_target(_surf);
    draw_clear(lod_bk_page());
    lod_lamp_reset();

    var _endY = _fn();
    var _ib = lod_bk_ink_bounds(LOD_SHEET_W, LOD_SHEET_H, _contentY);

    surface_reset_target();
    surface_save(_surf, "sheet_" + _name + ".png");
    surface_free(_surf);

    var _clipped = (_endY > LOD_SHEET_H) || (_ib.full[3] >= LOD_SHEET_H - 6)
                || (_ib.full[2] >= LOD_SHEET_W - 6) || (_ib.full[0] <= 5) || (_ib.full[1] <= 5);
    var _cw = (_ib.content[2] - _ib.content[0]) / LOD_SHEET_W;
    var _chh = (_ib.content[3] - _ib.content[1]) / max(1, LOD_SHEET_H - _contentY);

    return "{\"name\":\"" + _name + "\""
         + ",\"endY\":" + string(round(_endY))
         + ",\"ink\":" + string(_ib.ink)
         + ",\"fullBox\":[" + string(_ib.full[0]) + "," + string(_ib.full[1]) + ","
                            + string(_ib.full[2]) + "," + string(_ib.full[3]) + "]"
         + ",\"contentW\":" + string_format(_cw, 1, 3)
         + ",\"contentH\":" + string_format(_chh, 1, 3)
         + ",\"clipped\":" + (_clipped ? "true" : "false")
         + ",\"ok\":" + ((!_clipped && _cw >= 0.86 && _chh >= 0.80 && _ib.ink > 40000)
                         ? "true" : "false")
         + "}";
}

/// ============================================================================================
/// THE COVER
///
/// ⚠️ 630x500 IS ITCH'S COVER SIZE and the cover is the only image most buyers ever see. It is
/// baked at its own size rather than cropped out of a sheet, because a cropped sheet is exactly
/// what a cover must not be.
/// ============================================================================================

#macro LOD_COVER_W 630
#macro LOD_COVER_H 500

function lod_bk_cover() {
    // ⛔ THE FIRST COVER WAS THREE SMALL OBJECTS ON A BLACK BAND WITH DEAD SPACE ABOVE AND BELOW,
    // AND IT WAS THE WEAKEST IMAGE IN THE PACKAGE - on the one picture most buyers ever see. Three
    // separate stones sitting in a row read as a SHELF of unrelated things; the eye had nothing to
    // land on and, at the 315px thumbnail itch actually shows, the whole frame went to mud.
    //
    // ⭐ WHAT A COVER NEEDS IS ONE SUBJECT, LARGE, WITH THE OTHERS SUPPORTING IT. A big terminated
    // crystal is the most legible thing this corpus makes - it is unmistakably a MINERAL at any
    // size - so it takes the frame, the geode overlaps behind it to show the matrix and the
    // cavity, and one polished gem sits in front to show what the loop is FOR. They overlap, so
    // they read as a collection rather than as a catalogue row.
    //
    // ⚠️ ONE SCRIM, AT THE BOTTOM. The first version put a hard band across the top as well, which
    // cut the image in two and left the title floating on a rectangle - a sticker on a picture. The
    // title now sits over the frame's own dark corner with a shadow, which is what lod_text_label's
    // two-colour signature is for.
    var _beryl = lod_specimen(lod_species_index("Beryl"), 20260831, 0);
    var _geode = lod_specimen(lod_species_index("Amethyst"), 771, 0);
    // ⚠️ A BRILLIANT, NOT A CABOCHON. The cover carried a cabochon-cut corundum and it was the
    // weakest object in the frame - a dome has no facets to catch the eye at 315px, and its
    // asterism rays read as a beach ball. A brilliant is the cut a buyer PICTURES when they think
    // "cut gem", and it is the strongest cell on the cuts sheet. Rutile is adamantine and orange,
    // which is also the complement of the beryl beside it.
    var _gem   = lod_specimen(lod_species_index("Rutile"), 909, 3);

    lod_specimen_draw(_geode, 288, 92, 342, 342);
    lod_specimen_draw(_beryl, -4, 40, 396, 396);
    lod_specimen_draw(_gem,  400, 268, 186, 186);

    // ⚠️ ONE SCRIM, AT THE BOTTOM, WHERE THERE IS ACTUALLY SOMETHING TO DARKEN. A second scrim was
    // added across the TOP for the title and it drew a hard grey BAR over page that was already
    // near-black - a sticker on the picture, solving a legibility problem that did not exist.
    // lod_text_label already draws its own shadow, which is what that two-colour signature is for.
    lod_render_scrim(0, LOD_COVER_H - 78, LOD_COVER_W, 78, lod_oklch(0.09, 0.010, 252), 0.86);

    lod_text_label("LODE", LOD_COVER_W * 0.5, 8, LOD_COVER_W - 60, 62,
                   lod_oklch(0.06, 0.010, 252), lod_oklch(0.95, 0.018, 66));
    lod_text_line("MINERALS THAT DRAW THEMSELVES", 40, LOD_COVER_H - 62, LOD_COVER_W - 80, 21,
                  lod_bk_warm(), true);
    lod_text_line("48 species   21 crystal habits   10 cuts   pure GML, no sprites",
                  40, LOD_COVER_H - 34, LOD_COVER_W - 80, 16, lod_oklch(0.86, 0.010, 252), false);
    return LOD_COVER_H;
}

function lod_bake_cover() {
    var _surf = surface_create(LOD_COVER_W, LOD_COVER_H);
    surface_set_target(_surf);
    draw_clear(lod_bk_page());
    lod_lamp_reset();
    lod_bk_cover();
    var _ib = lod_bk_ink_bounds(LOD_COVER_W, LOD_COVER_H, 0);
    surface_reset_target();
    surface_save(_surf, "cover.png");
    surface_free(_surf);
    return "{\"name\":\"cover\",\"ink\":" + string(_ib.ink)
         + ",\"ok\":" + ((_ib.ink > 20000) ? "true" : "false") + "}";
}

/// Bake every sheet and write a report.
///
/// ⛔ THE REPORT IS WRITTEN EVEN WHEN A SHEET FAILS ITS OWN CHECK. A baker that stops on the first
/// failure tells you about one defect per build, and an Igor build is about eighty seconds - so a
/// package with six clipped sheets costs six builds to find. All of them, every run.
function lod_bake_run() {
    global.lod_stage = 200;
    var _out = [];
    array_push(_out, lod_bk_one("hero",    lod_bk_hero,    150));
    array_push(_out, lod_bk_one("corpus",  lod_bk_corpus,  180));
    array_push(_out, lod_bk_one("habits",  lod_bk_habits,  180));
    array_push(_out, lod_bk_one("lustre",  lod_bk_lustre,  180));
    array_push(_out, lod_bk_one("zoning",  lod_bk_zoning,  180));
    array_push(_out, lod_bk_one("cut",     lod_bk_cut,     170));
    array_push(_out, lod_bk_one("cuts",    lod_bk_cuts,    180));
    array_push(_out, lod_bk_one("matrix",  lod_bk_matrix,  180));
    array_push(_out, lod_bk_one("system",  lod_bk_system,  180));
    array_push(_out, lod_bake_cover());

    var _f = file_text_open_write("lod_bake.json");
    var _s = "{\"sheets\":[";
    for (var _i = 0; _i < array_length(_out); _i++) {
        if (_i > 0) _s += ",";
        _s += _out[_i];
    }
    _s += "],\"version\":\"" + LOD_VERSION + "\"}";
    file_text_write_string(_f, _s);
    file_text_close(_f);
    global.lod_stage = 299;
}
