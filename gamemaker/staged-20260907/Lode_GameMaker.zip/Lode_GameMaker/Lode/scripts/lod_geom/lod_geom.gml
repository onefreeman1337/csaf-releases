/// LODE - lod_geom. Part of the shared drawing foundation.
///
/// This file is the studio's cross-product drawing/colour layer, carried forward with more
/// than 2,300 in-engine assertions behind it - including the GML default-epsilon fix
/// described below, which had produced a suite of assertions that could never go red.
///
/// ⛔ GML APPLIES A DEFAULT EPSILON TO NUMERIC COMPARISONS, and it is 0.00001 on this runtime
/// - MEASURED by lod_selftest, which prints math_get_epsilon() into its own result file at
/// twelve decimals. Any tolerance at or below about 0.00001 can NEVER fire, in either
/// direction, so a distinctness assertion written that way passes vacuously forever and an
/// equality assertion written that way goes red on two values that are the same object.
/// Never write one here. And GML has no exponent-literal syntax at all: `1e-5` is a lexer
/// error that reads like a bracket bug.
///
/// The five drawing primitives and the helpers that build them.
///
/// Lode draws every one of its minerals from data - the crystal habit, the terminations, the
/// facet edges of a cut stone, the host rock it grew in, the colour banding, the inclusions and
/// the weathered rind. There is NO sprite, NO spritesheet, NO atlas and NO texture page in this
/// package: `sprites/` does not exist. That is the product's headline claim and it is literally
/// true, and it is the whole reason the same species can be drawn as a rough specimen on matrix,
/// as a faceted gem, and as a cabinet plate, at RUNTIME, at any size, instead of being
/// re-exported from an art tool three times.
///
/// ⭐ IT IS ALSO THE ARGUMENT AGAINST THE SHELF THIS PRODUCT SELLS ON. The mineral territory on
/// itch's GameMaker shelf is STATIC ART - measured 2026-08-31, fourteen paid rows topping out at
/// $14.99, and not one generator among them. A crystal pack ships a fixed set of pictures; this
/// ships the thing that MAKES them, so an ore body in a buyer's game can be assayed, cut and
/// polished into a stone nobody drew.
///
/// This file produces GEOMETRY and knows nothing about drawing. lod_render turns geometry
/// into draw calls and knows nothing about what a `habit`, a `termination` or a `pavilion`
/// means. Keeping that split clean is what lets the whole corpus be checked before any of it
/// runs in-engine.
///
/// COORDINATES. Two spaces, and keeping them apart is what makes this product composable.
///
/// 1. UNIT-BOX SPACE, [-0.5, 0.5] on both axes, y DOWN, origin at the centre. EVERY PART OF A
///    SPECIMEN is authored here - a prism face, a pyramid termination, a botryoidal lobe, a
///    facet, a matrix block. LOD_GROUND is the BEDDING PLANE, the surface the specimen rests on
///    and grows out of, and it is the anchor every part is placed against: author a matrix block
///    and a crystal spray weeks apart and they still meet, because both know where the rock is.
///
/// 2. CELL SPACE, in PIXELS, which is where a finished specimen is DRAWN - an inventory slot, a
///    cabinet shelf, a sheet cell. lod_render_in_rect_tight maps the unit box into it.
///
/// ⛔ A SPECIMEN *IS* A PICTURE WITH AN ASPECT RATIO, which is exactly why the unit box is right
/// here and was wrong for an interface component. A quartz point and a galena cube are the same
/// drawing at different scales; a button at 40x18 and at 400x180 is not.
///
/// ⛔⛔ AND THAT MAKES ONE INHERITED LAW MORE IMPORTANT HERE, NOT LESS (wing CLAUDE.md, Livery,
/// four instances on one sheet): A PHYSICAL DETAIL BOUNDED ONLY AS A PROPORTION IS WRONG ON THE
/// LARGEST THING YOU DRAW. The striations on a pyrite face are about a millimetre apart on a
/// thumbnail crystal and about a millimetre apart on a fist-sized one; a druse of tiny crystals
/// does not get coarser because the plate is bigger. This package draws the same specimen at
/// 32 px in an inventory grid and at 800 px on a store sheet, so every detail whose size is
/// PHYSICAL - striation pitch, druse grain, cleavage step, fracture chip - is bounded at BOTH
/// ends: min(proportional, LOD_PX_MAX) going up, and a proportional floor going down. Nothing in
/// this package flips an axis, so a part reads the same in the corpus and in the buyer's hand.
/// ============================================================================================
#macro LOD_VERSION "1.0.0"

#macro LOD_DOT   0
#macro LOD_ARC   1
#macro LOD_POLY  2
#macro LOD_FILL  3
#macro LOD_STRIP 4

#macro LOD_TAU    6.283185307179586

/// The floor line in the unit box. Every mass in the corpus meets the boards here, and the strip
/// from LOD_GROUND to +0.5 is reserved for the contact shadow a piece throws where it stands.
/// Asserted by lod_selftest against every authored form, so the header above stays literally true.
#macro LOD_GROUND 0.44

/// ============================================================================================
/// PART CONSTRUCTORS
/// ============================================================================================

/// A filled circle.
function lod_dot(_cx, _cy, _r, _role) {
    return { kind: LOD_DOT, cx: _cx, cy: _cy, r: _r, role: _role };
}

/// A sampled, stroked arc. Angles in radians, y-down (angle 0 = +x, pi/2 = down).
function lod_arc(_cx, _cy, _r, _a0, _a1, _w, _role) {
    return { kind: LOD_ARC, cx: _cx, cy: _cy, r: _r, a0: _a0, a1: _a1, w: _w, role: _role };
}

/// A stroked polyline. _pts is an array of [x,y].
function lod_poly(_pts, _closed, _w, _role) {
    return { kind: LOD_POLY, pts: _pts, closed: _closed, w: _w, role: _role };
}

/// A triangle FAN. See the header: the outline must be star-shaped about pts[0].
function lod_fill(_pts, _role) {
    return { kind: LOD_FILL, pts: _pts, role: _role };
}

/// A triangle STRIP between two polylines of equal length.
function lod_strip(_a, _b, _role) {
    return { kind: LOD_STRIP, a: _a, b: _b, role: _role };
}

/// A full stroked circle. An arc, not a primitive of its own - GML's draw_circle outline ignores
/// line width, and width carries meaning across this whole corpus.
function lod_ring(_cx, _cy, _r, _w, _role) {
    return lod_arc(_cx, _cy, _r, 0, LOD_TAU, _w, _role);
}

/// An axis-aligned rectangle as a fan. Convex, so star-shaped about any corner.
function lod_rect_fill(_x0, _y0, _x1, _y1, _role) {
    return lod_fill([[_x0, _y0], [_x1, _y0], [_x1, _y1], [_x0, _y1]], _role);
}

/// An axis-aligned rectangle as a stroked outline.
function lod_rect_poly(_x0, _y0, _x1, _y1, _w, _role) {
    return lod_poly([[_x0, _y0], [_x1, _y0], [_x1, _y1], [_x0, _y1]], true, _w, _role);
}

/// Fill a CLOSED ring of points as a fan from an interior point.
///
/// USE THIS AND NEVER HAND-ROLL IT. A fan walks centre -> p0 -> p1 -> ... -> pN and closes from
/// pN straight back to the centre, so the edge from pN back to p0 is never walked and a wedge of
/// the shape is silently missing. The ring's first point is repeated at the end here. That is the
/// whole fix, and it is why every closed outline in this product is closed.
function lod_ring_fill(_pts, _role, _cx, _cy) {
    var _n = array_length(_pts);
    var _ax = _cx, _ay = _cy;
    if (is_undefined(_ax)) {
        _ax = 0; _ay = 0;
        for (var _i = 0; _i < _n; _i++) { _ax += _pts[_i][0]; _ay += _pts[_i][1]; }
        _ax /= _n; _ay /= _n;
    }
    var _out = array_create(_n + 2);
    _out[0] = [_ax, _ay];
    for (var _i = 0; _i < _n; _i++) _out[_i + 1] = _pts[_i];
    _out[_n + 1] = _pts[0];
    return lod_fill(_out, _role);
}

/// ============================================================================================
/// ARRAY HELPERS
/// ============================================================================================

/// Append every element of _src onto _dst, in place. Returns _dst.
/// Used everywhere instead of array_concat so the allocation pattern is one array per form
/// rather than one per composition step - a full form rebuilt every frame is real garbage.
/// ⛔ A SINGLE PART IS ACCEPTED, AND IT IS NOT TIDINESS. Four builders in this layer return ONE
/// part rather than a list - lod_fill, lod_poly, lod_dot and lod_taper_ribbon - and handing one of
/// those to the loop below asks array_length() about a struct, which answers 0. The part is then
/// dropped with no error, no warning and a perfectly clean compile. MEASURED in this studio's shared drawing layer, on the product it was written for: six call sites were computing geometry and throwing it away, and the only thing that noticed was a single assertion about where one form met the ground. Accepting a bare part is the difference between a defect that shouts and one that does
/// not exist as far as any tool can tell.
function lod_append(_dst, _src) {
    if (!is_array(_src)) { array_push(_dst, _src); return _dst; }
    var _n = array_length(_src);
    for (var _i = 0; _i < _n; _i++) array_push(_dst, _src[_i]);
    return _dst;
}

/// ============================================================================================
/// CURVE SAMPLING - everything curved in this corpus is a sampled polyline, because that is the
/// only curved thing GML draws with an honoured line width.
/// ============================================================================================

/// Quadratic bezier, _n segments, inclusive of both ends.
function lod_qbez(_p0, _p1, _p2, _n) {
    var _out = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n, _u = 1 - _t;
        _out[_i] = [
            _u * _u * _p0[0] + 2 * _u * _t * _p1[0] + _t * _t * _p2[0],
            _u * _u * _p0[1] + 2 * _u * _t * _p1[1] + _t * _t * _p2[1]
        ];
    }
    return _out;
}

/// Points along a circle, inclusive of both ends.
function lod_arc_pts(_cx, _cy, _r, _a0, _a1, _n) {
    var _out = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _a = _a0 + (_a1 - _a0) * (_i / _n);
        _out[_i] = [_cx + cos(_a) * _r, _cy + sin(_a) * _r];
    }
    return _out;
}

/// Points along an ellipse, closed (first point NOT repeated).
function lod_ellipse_pts(_cx, _cy, _rx, _ry, _n) {
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _a = (_i / _n) * LOD_TAU;
        _out[_i] = [_cx + cos(_a) * _rx, _cy + sin(_a) * _ry];
    }
    return _out;
}

/// Points along an ELLIPTICAL arc from _a0 to _a1, endpoints included.
///
/// ⚠️ lod_arc_pts above takes a single radius and is therefore a CIRCULAR arc. Almost nothing on
/// a specimen is circular in projection: a botryoidal lobe seen slightly from above, the girdle of
/// a cut stone, the mouth of a geode, the rounded back of a reniform mass and the table of a
/// cabochon are all ELLIPTICAL, so an arc of any of them needs both radii. Reaching for lod_arc_pts
/// silently draws a circle where the form is an ellipse, and the two agree only when _rx happens
/// to equal _ry. This is the same trap Repast paid for on a plate rim.
///
/// Angles follow the same convention as lod_ellipse_pts, and y grows DOWNWARD: sin(_a) > 0 is the
/// LOWER half of a shape on screen and sin(_a) < 0 is the upper half. The lamp in lod_relief sits
/// up and to the left, so that sign is what decides which half of a bezel is lit; do not "tidy"
/// it.
function lod_ellipse_arc_pts(_cx, _cy, _rx, _ry, _a0, _a1, _n) {
    var _out = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _a = _a0 + (_a1 - _a0) * (_i / _n);
        _out[_i] = [_cx + cos(_a) * _rx, _cy + sin(_a) * _ry];
    }
    return _out;
}

/// Regular polygon / star point ring.
function lod_star_pts(_cx, _cy, _r, _n, _phase) {
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _a = _phase + (_i / _n) * LOD_TAU;
        _out[_i] = [_cx + cos(_a) * _r, _cy + sin(_a) * _r];
    }
    return _out;
}

/// Offset a polyline sideways by _d, using per-vertex normals.
function lod_offset_pts(_pts, _d) {
    var _n = array_length(_pts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _pts[max(0, _i - 1)], _q = _pts[min(_n - 1, _i + 1)];
        var _dx = _q[0] - _p[0], _dy = _q[1] - _p[1];
        var _len = point_distance(0, 0, _dx, _dy);
        if (_len == 0) _len = 1;
        _dx /= _len; _dy /= _len;
        _out[_i] = [_pts[_i][0] - _dy * _d, _pts[_i][1] + _dx * _d];
    }
    return _out;
}

/// A polyline given real thickness, as a triangle strip. Correct for shapes a fan cannot do.
function lod_ribbon(_pts, _half, _role) {
    return lod_strip(lod_offset_pts(_pts, _half), lod_offset_pts(_pts, -_half), _role);
}

/// A ribbon whose half-width is given PER POINT rather than interpolated between two ends.
///
/// ⛔ THIS IS THE PRIMITIVE THAT MAKES ENGRAVED TONE POSSIBLE, AND ITS ABSENCE IS WHY FOUR ROUNDS
/// OF PARAMETER TUNING FAILED TO FIX THE SHADING. See lod_relief for the argument in
/// full; the short version is that an engraver ramps tone by SWELLING A LINE, not by filling a
/// region and drawing lines of constant weight on top of it. A constant-width stroke can only ever
/// participate in a pattern; a swelling one participates in a gradient. lod_taper_ribbon below is
/// the two-endpoint special case of this and stays because a ribbon tail genuinely does taper
/// monotonically - but tone does not, so it needs the array.
///
/// _w is a half-width per point and must be the same length as _pts. A shorter array is a DEFECT
/// rather than something to pad: it means the caller's two loops disagree, and silently reusing the
/// last width would draw a plausible wrong picture. Asserted rather than tolerated.
function lod_var_ribbon(_pts, _w, _role) {
    var _n = array_length(_pts);
    if (_n < 2 || array_length(_w) != _n) return lod_strip([], [], _role);
    var _a = array_create(_n), _b = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _pts[max(0, _i - 1)], _q = _pts[min(_n - 1, _i + 1)];
        var _dx = _q[0] - _p[0], _dy = _q[1] - _p[1];
        var _len = point_distance(0, 0, _dx, _dy);
        if (_len == 0) _len = 1;
        _dx /= _len; _dy /= _len;
        var _d = _w[_i];
        _a[_i] = [_pts[_i][0] - _dy * _d, _pts[_i][1] + _dx * _d];
        _b[_i] = [_pts[_i][0] + _dy * _d, _pts[_i][1] - _dx * _d];
    }
    return lod_strip(_a, _b, _role);
}

/// A ribbon whose thickness varies along its length, taper from _w0 at the start to _w1 at the
/// end with an optional exponent. A tapered ribbon tail reads as CUT; one of constant width reads
/// as extruded, which is the loudest tell of programmer art.
function lod_taper_ribbon(_pts, _w0, _w1, _role) {
    var _n = array_length(_pts);
    var _a = array_create(_n), _b = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _pts[max(0, _i - 1)], _q = _pts[min(_n - 1, _i + 1)];
        var _dx = _q[0] - _p[0], _dy = _q[1] - _p[1];
        var _len = point_distance(0, 0, _dx, _dy);
        if (_len == 0) _len = 1;
        _dx /= _len; _dy /= _len;
        var _d = lerp(_w0, _w1, _i / max(1, _n - 1));
        _a[_i] = [_pts[_i][0] - _dy * _d, _pts[_i][1] + _dx * _d];
        _b[_i] = [_pts[_i][0] + _dy * _d, _pts[_i][1] - _dx * _d];
    }
    return lod_strip(_a, _b, _role);
}

/// ============================================================================================
/// CLIPPING
///
/// Liang-Barsky: clip a segment to an axis-aligned rectangle. Returns [[x0,y0],[x1,y1]] or
/// undefined. Analytic rather than a scissor rect, because GML's clipping is a surface/viewport
/// operation that does not survive being called from inside a buyer's own draw event - and
/// every bevel quad, incised stroke, colour band and striation must stop at the outline that
/// owns it. A growth band that runs off the side of the crystal it belongs to, and a striation
/// that carries on past the face it is cut into, are the two reasons this is here - and both of
/// them are defects a buyer sees in the very first specimen they look at.
///
/// ⛔ AND CLIPPING IS NOT THE SAME QUESTION AS SPAN (wing CLAUDE.md, Muster): a bounding box is
/// only the shape's true width at ONE height. A band drawn across a botryoidal lobe at any other
/// height overhangs it on both sides. Clip a band to the outline's span AT ITS OWN y.
/// ============================================================================================

function lod_clip_seg(_x0, _y0, _x1, _y1, _rx0, _ry0, _rx1, _ry1) {
    var _t0 = 0, _t1 = 1;
    var _dx = _x1 - _x0, _dy = _y1 - _y0;
    var _p, _q, _r;
    for (var _e = 0; _e < 4; _e++) {
        switch (_e) {
            case 0: _p = -_dx; _q = _x0 - _rx0; break;
            case 1: _p =  _dx; _q = _rx1 - _x0; break;
            case 2: _p = -_dy; _q = _y0 - _ry0; break;
            default: _p = _dy; _q = _ry1 - _y0; break;
        }
        if (_p == 0) {
            if (_q < 0) return undefined;
        } else {
            _r = _q / _p;
            if (_p < 0) {
                if (_r > _t1) return undefined;
                if (_r > _t0) _t0 = _r;
            } else {
                if (_r < _t0) return undefined;
                if (_r < _t1) _t1 = _r;
            }
        }
    }
    return [[_x0 + _t0 * _dx, _y0 + _t0 * _dy], [_x0 + _t1 * _dx, _y0 + _t1 * _dy]];
}

/// ============================================================================================
/// TRANSFORMS
/// ============================================================================================

/// Map one point from unit-box space to form space.
function lod_map_pt(_p, _cx, _cy, _s, _rot) {
    var _x = _p[0] * _s, _y = _p[1] * _s;
    if (_rot != 0) {
        var _c = cos(_rot), _sn = sin(_rot);
        var _nx = _x * _c - _y * _sn;
        _y = _x * _sn + _y * _c;
        _x = _nx;
    }
    return [_cx + _x, _cy + _y];
}

/// Resolve a role through an optional remap struct.
function lod_role(_role, _map) {
    if (is_undefined(_map)) return _role;
    if (variable_struct_exists(_map, _role)) return variable_struct_get(_map, _role);
    return _role;
}

/// Place a unit-box part list at (_cx,_cy) at scale _s.
///
/// STROKE WIDTHS SCALE, WITH A FLOOR IN THE RENDERER. The design corpus originally said the
/// weight was "held constant in screen space rather than scaled" - implemented literally, that
/// makes a card-scale form's strokes 32% of its own width while a hero-scale one's are 6%, so
/// small forms rendered as solid blobs. Constant PROPORTION plus lod_render's 1.0px floor is
/// what the rule was actually reaching for.
function lod_place(_parts, _cx, _cy, _s, _rot, _wscale, _map) {
    var _n = array_length(_parts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _parts[_i];
        var _r = lod_role(_p.role, _map);
        switch (_p.kind) {
            case LOD_DOT: {
                var _q = lod_map_pt([_p.cx, _p.cy], _cx, _cy, _s, _rot);
                _out[_i] = lod_dot(_q[0], _q[1], _p.r * _s, _r);
            } break;
            case LOD_ARC: {
                var _q = lod_map_pt([_p.cx, _p.cy], _cx, _cy, _s, _rot);
                _out[_i] = lod_arc(_q[0], _q[1], _p.r * _s, _p.a0 + _rot, _p.a1 + _rot,
                                   _p.w * _wscale, _r);
            } break;
            case LOD_STRIP: {
                var _na = array_length(_p.a), _nb = array_length(_p.b);
                var _a = array_create(_na), _b = array_create(_nb);
                for (var _k = 0; _k < _na; _k++) _a[_k] = lod_map_pt(_p.a[_k], _cx, _cy, _s, _rot);
                for (var _k = 0; _k < _nb; _k++) _b[_k] = lod_map_pt(_p.b[_k], _cx, _cy, _s, _rot);
                _out[_i] = lod_strip(_a, _b, _r);
            } break;
            case LOD_FILL: {
                var _np = array_length(_p.pts);
                var _pts = array_create(_np);
                for (var _k = 0; _k < _np; _k++) _pts[_k] = lod_map_pt(_p.pts[_k], _cx, _cy, _s, _rot);
                _out[_i] = lod_fill(_pts, _r);
            } break;
            default: {
                var _np = array_length(_p.pts);
                var _pts = array_create(_np);
                for (var _k = 0; _k < _np; _k++) _pts[_k] = lod_map_pt(_p.pts[_k], _cx, _cy, _s, _rot);
                _out[_i] = lod_poly(_pts, _p.closed, _p.w * _wscale, _r);
            } break;
        }
    }
    return _out;
}

/// ============================================================================================
/// SEEDED HASH
///
/// Nothing in this product is random at draw time. The only randomness is a seeded hash of the
/// form's id, so two forms that differ in any property look different and the SAME form never
/// flickers between looks. Never call random() anywhere in this package - a jittered edge that
/// re-jitters every frame is the one bug a buyer will notice immediately and cannot work around.
/// ============================================================================================

/// Exact 32-bit unsigned multiply, done in 16-bit halves.
///
/// GML numbers are doubles. A direct h * 16777619 with h near 2^32 reaches 7.2e16, past the 2^53
/// point where doubles stop being exact - so the hash would silently lose its low bits and two
/// different form ids could collide. Splitting the multiply keeps every intermediate under 2^33.
function lod_mul32(_a, _b) {
    var _al = _a & 0xFFFF;
    var _ah = (_a >> 16) & 0xFFFF;
    var _bl = _b & 0xFFFF;
    var _bh = (_b >> 16) & 0xFFFF;
    var _lo = _al * _bl;
    var _mid = ((_al * _bh) + (_ah * _bl)) & 0xFFFF;
    return (_lo + (_mid << 16)) & 0xFFFFFFFF;
}

/// FNV-1a, 32-bit. Same construction as the authoring-side previewer, so a form looks the same
/// in the engine as it did on the corpus sheet.
function lod_hash32(_s) {
    var _h = 2166136261;
    var _n = string_length(_s);
    for (var _i = 1; _i <= _n; _i++) {
        _h = _h ^ ord(string_char_at(_s, _i));
        _h = lod_mul32(_h, 16777619);
    }
    return _h;
}

/// A deterministic 0..1 generator (Lehmer / MINSTD). The state is a ONE-ELEMENT ARRAY, and that
/// is the whole design: arrays are references in GML, so `lod_rng_next` mutates the caller's
/// state and nothing else, with no binding rules involved.
///
/// ⛔ IT WAS A STRUCT WITH A next() METHOD FIRST, AND THAT BROKE THE PRODUCT'S CENTRAL PROMISE.
/// The in-engine self-test came back with three failures of the form "geometry differs between
/// identical calls" plus an rng sequence that did not match the reference values computed in the
/// authoring previewer. Writing `s = ...` and then `self.s = ...` inside a struct-literal method
/// BOTH failed the same way: generator state was not staying with the generator, so two freshly
/// seeded rngs did not agree on their first draw. A jittered form would have re-jittered itself
/// differently every time anything else drew - which is exactly the bug this file's determinism
/// rule exists to prevent.
///
/// Nothing in the JavaScript preview could have caught it: JS closures capture correctly and have
/// no `self` to get wrong. This is the class of defect that ONLY an in-engine test finds, and it
/// is the reason this wing ships one.
/// ⛔⛔ THE GENERATOR IS WARMED UP, AND SKIPPING THAT MAKES THE FIRST DRAW A LINEAR FUNCTION OF THE
/// SEED. MEASURED 2026-08-31 on this product, and it had already shipped a broken game mechanic.
///
/// This is a Lehmer generator: the first draw is `(seed * 48271 mod 2^31-1) / 2^31-1`. For any run
/// of nearby seeds - which is what every caller in this package uses, `base + index` - that product
/// does not wrap, so the first draw is very nearly a straight line in the seed. Across the 440
/// seeds the suite prospects with, the FIRST DRAW SPANNED ONLY 0.5102 to 0.7358.
///
/// lod_prospect spends its first draw on the barren-pan roll against a threshold of 0.30, so a
/// stated 30% chance of an empty pan was measured at EXACTLY 0%: 440 pans, 440 finds, and the
/// mechanic that makes a strike mean anything could not fire at all. Nothing about the code looked
/// wrong, every determinism assertion passed, and the picture was unaffected - only the suite's
/// "an empty pan must be possible" assertion could see it.
///
/// Three discards decorrelate it: measured over the same 440 seeds, the first draw then spans
/// 0.0008 to 0.9992 and the barren rate reads 29.8% against the intended 30%.
///
/// ⭐ THE GENERAL FORM, and it is worth carrying to every product in this wing: A SEEDED GENERATOR'S
/// FIRST DRAW IS NOT UNIFORM ACROSS NEARBY SEEDS, so spending it on a RARE-EVENT DECISION makes
/// that event's probability depend on which seed range the caller happened to use. Warm up at the
/// seeding, not at the call site, or the next caller pays for it again.
function lod_rng(_seed) {
    var _s = _seed % 2147483647;
    if (_s <= 0) _s = 1;
    var _st = [_s];
    lod_rng_next(_st);
    lod_rng_next(_st);
    lod_rng_next(_st);
    return _st;
}

/// The next value in 0..1 from a generator made by lod_rng. Every intermediate stays under 2^47,
/// so no precision guard is needed here.
function lod_rng_next(_st) {
    _st[0] = (_st[0] * 48271) % 2147483647;
    return (_st[0] - 1) / 2147483646;
}
