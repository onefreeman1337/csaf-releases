{
  "$GMScript": "v1",
  "%Name": "lod_relief",
  "name": "lod_relief",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}