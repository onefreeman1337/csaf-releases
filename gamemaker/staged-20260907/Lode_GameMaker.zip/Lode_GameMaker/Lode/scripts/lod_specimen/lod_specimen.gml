/// LODE - lod_specimen. Where habit, lustre, zoning, matrix and cut become one picture.
///
/// ============================================================================================
/// THE PUBLIC SURFACE OF THE PRODUCT.
///
/// A buyer calls four functions:
///
///   lod_specimen(species_index, seed)     -> a stone, as data
///   lod_specimen_parts(stone)             -> its geometry
///   lod_specimen_pal(stone)               -> its palette
///   lod_specimen_draw(stone, x, y, w, h)  -> draw it, fitted to a rectangle
///
/// Everything else in this package is reachable and documented, but those four are the product.
///
/// ⛔ A STONE IS AN INTEGER PAIR AND NOTHING ELSE. `species` and `seed` fully determine the
/// picture, which is why a save file can store two numbers and get the same specimen back in six
/// months. That is only true because the corpus tables are APPEND ONLY - a saved stone resolves
/// its species through an INDEX, so reordering the corpus silently rewrites every stone already in
/// a buyer's save. lod_corpus.gml says so at the top and it is the most important sentence in it.
///
/// ⛔ AND THE ROLE MAPPING IS WHERE THE TWO MATERIALS ARE KEPT APART. The habit is authored in
/// generic m0..m4 and mapped onto the MINERAL's ramp; the host rock is authored in the same
/// generic roles and mapped onto the ROCK's ramp. One shared vocabulary, two materials, no
/// duplicated geometry - and it is why adding a habit costs one function rather than one function
/// per rock.
/// ============================================================================================

/// Is this a stone this package made? The ONE predicate every public entry point asks.
///
/// ⛔ ADDED 2026-09-07 AFTER A MEASURED 42 CRASHES IN 52 HOSTILE CALLS - every one of the fourteen
/// documented entry points took the room down on `undefined`, on a negative number and on a huge
/// one. A buyer hands these in on the frame a save finishes loading or a prospect returned -1 and
/// was not checked, so this is not an exotic input.
///
/// ⚠️ IT TESTS `sp`, NOT MERELY `is_struct`. A plain `{}` passes is_struct and then fails one line
/// later on `_stone.sp.name`, which moves the crash instead of preventing it - the wing's own
/// "a setter that accepts rubbish turns one bad call into a crash somewhere else".
///
/// ⚠️ AND IT USES is_numeric, NOT is_real. This wing has shipped the is_real mistake before: a GML
/// colour and an index are both integers but `state` arrives from arithmetic, and is_real rejects
/// values that are perfectly legal here. A false-red guard is worse than no guard, because the
/// product then refuses silently and reads as broken.
function lod_is_stone(_stone) {
    if (!is_struct(_stone)) return false;
    if (!is_struct(variable_struct_get(_stone, "sp"))) return false;
    if (!is_numeric(variable_struct_get(_stone, "state"))) return false;
    return true;
}

/// A stone. Deterministic in (species, seed).
///
/// _state 0 = rough in matrix, 1 = extracted rough, 2 = cut, 3 = cut and polished. A species that
/// is never cut clamps to 1, which is the honest answer rather than drawing a gem nobody can make.
///
/// ⛔ REFUSES WITH `undefined` RATHER THAN INVENTING A STONE. Returning species 0 for a bad index
/// would be the fail-open shape: the buyer's game would draw a real, wrong mineral and look almost
/// right, which is far harder to find than nothing at all. Every other entry point below already
/// refuses an `undefined` stone, so one bad call stays one bad call.
///
/// ⭐ THE STRING CASE IS THE LIKELIEST MISTAKE IN THE WHOLE API AND IT USED TO BE A HARD CRASH.
/// The quickstart reads lod_specimen(lod_species_index("Amethyst"), seed, 0); drop the inner call
/// and you pass the NAME where the index goes. That reached clamp() inside lod_species and threw
/// "clamp argument 1 incorrect type (string)" - inside the buyer's draw event, which is precisely
/// what lod_species's own comment says the clamp exists to prevent. Measured 2026-09-07.
function lod_specimen(_species, _seed, _state) {
    /// ⚠️ THE SEED IS REQUIRED AND AN OMITTED ONE IS REFUSED, WHILE _state DEFAULTS. That asymmetry
    /// is deliberate and matches the ORIGINAL contract: _state has always documented a default of
    /// 0, and the seed never had one. Quietly reading a missing seed as 0 would hand back a real,
    /// drawable stone for an incompletely written call - the same invent-a-stone shape refused for
    /// a bad species index one line up, and every distinct incomplete call would return the SAME
    /// stone, so two specimens a buyer meant to differ would be identical.
    if (!is_numeric(_species)) return undefined;
    if (!is_numeric(_seed)) return undefined;
    if (!is_undefined(_state) && !is_numeric(_state)) return undefined;

    var _sp = lod_species(_species);
    if (!is_struct(_sp)) return undefined;
    var _st = is_undefined(_state) ? 0 : clamp(_state, 0, 3);
    if (!lod_is_cuttable(_sp) && _st > 1) _st = 1;
    return { species: _species, seed: _seed, state: _st, sp: _sp };
}

/// The palette for a stone. Wetness comes from its state: a polished stone reads wet.
/// ⚠️ A FRESHLY CUT STONE IS NOT A POLISHED ONE, AND 0.55 MADE THEM THE SAME PICTURE. The store
/// sheet that shows rough / cut / polished side by side had five of its eight species looking
/// identical in the last two columns, under a caption claiming the shadows deepen. A stone off the
/// saw is MATTE - the facets are flat and true but the surface still scatters - and it is polishing
/// that makes it specular. 0.25 is the honest figure and it is the one that makes the claim visible.
function lod_specimen_pal(_stone) {
    /// Refuses with `undefined`, which is what lod_pal_for's own callers already test for.
    if (!lod_is_stone(_stone)) return undefined;
    var _wet = 0;
    if (_stone.state == 2) _wet = 0.25;
    if (_stone.state == 3) _wet = 1.0;
    return lod_pal_for(_stone.sp, _stone.sp.matrix, _wet, undefined);
}

/// The geometry for a stone, in unit-box space.
///
/// ⛔ PAINTER'S ORDER IS NOT A DETAIL HERE, IT IS THE PICTURE (CLAUDE.md, Vestige): matrix, then
/// crystal, then the colour that lives INSIDE the crystal. Zoning drawn before the habit would be
/// painted over by the habit's own facets and would silently do nothing - which is the worst
/// possible failure because the code still runs and the tests still pass.
function lod_specimen_parts(_stone) {
    /// ⛔ THE REFUSAL IS AN EMPTY ARRAY, NOT `undefined`. Every caller iterates the result with
    /// array_length, so undefined would throw one line later at THEIR call site - moving the crash
    /// rather than removing it. An empty part list draws nothing, which is investigable.
    if (!lod_is_stone(_stone)) return [];
    var _sp = _stone.sp;
    var _out = [];

    if (_stone.state >= 2) {
        // A cut stone. No matrix - it is held up to the light, not bedded in rock.
        var _cut = lod_cut_parts(_sp, _stone.seed, 0.40);
        lod_append(_out, lod_map_roles(_cut, lod_mat_map("s")));
        // ⛔ ZONING GOES THROUGH THE SAME MAP. Some zoning programs reach for the MINERAL's own
        // stops as well as the secondary - chatoyant paints a bright m4 core inside its z4 band -
        // and an unmapped m4 is not in the palette at all. lod_render_colour then falls back to
        // `line` SILENTLY, drawing a grey mark exactly where a coloured one belongs, and nothing
        // anywhere reports it. Caught only because the suite walks lod_roles_used per specimen.
        lod_append(_out, lod_map_roles(lod_zoning_parts(_sp.zoning, _stone.seed, _cut), lod_mat_map("s")));
        return _out;
    }

    var _h = 0.52 + 0.16 * ((_sp.hardness - 1) / 9);
    var _w = 0.30 + 0.10 * (1 - _sp.rarity);

    if (_stone.state == 0) {
        // Bedded. The rock is drawn first and is WIDER than the crystal, so the crystal reads as
        // having grown out of it.
        var _rock = lod_rock_block(_sp.matrix, _stone.seed, 0.44, 0.16);
        lod_append(_out, lod_map_roles(_rock, lod_mat_map("r")));
    }

    var _hab = lod_habit_parts(_sp.habit, _stone.seed, _h, _w);
    lod_append(_out, lod_map_roles(_hab, lod_mat_map("s")));
    // Zoning is built against the habit's own parts, so its body outline is DERIVED and cannot go
    // stale when a habit is edited. See lod_zoning's header. Mapped through the MINERAL's material
    // for the reason given in the cut branch above.
    lod_append(_out, lod_map_roles(lod_zoning_parts(_sp.zoning, _stone.seed, _hab, _sp.habit), lod_mat_map("s")));
    return _out;
}

/// Draw a stone into a rectangle. The one call a buyer needs.
///
/// ⚠️ UNIFORM SCALE, ALWAYS - lod_render_in_rect_tight handles it. A specimen squeezed to fill an
/// oblong slot turns every crystal face into a different angle, and this corpus tells species
/// apart BY their angles.
function lod_specimen_draw(_stone, _x, _y, _w, _h) {
    /// Draws NOTHING rather than inventing a stone. A blank rect where a mineral should be is the
    /// signal; a plausible wrong mineral is the failure that ships.
    if (!lod_is_stone(_stone)) return;
    /// A zero or negative rect is LEGAL to pass - a collapsed inventory slot produces one every
    /// frame while it animates open - and is refused rather than divided by.
    if (!is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_h)) return;
    if (_w <= 0 || _h <= 0) return;
    var _pal = lod_specimen_pal(_stone);
    var _parts = lod_specimen_parts(_stone);
    if (is_undefined(_pal) || array_length(_parts) == 0) return;
    lod_render_in_rect_tight(_parts, _pal, _x, _y, _w, _h, undefined);
}

/// A stone's display name, with its state.
///
/// ⚠️ ASCII ONLY. The shipped fonts carry glyphs 32..126 and a missing glyph draws NOTHING - no
/// error, no box, just absence, which reads as a deliberate spacing choice (CLAUDE.md, Livery, on
/// a product cover). Internal_Ops/ascii_check.js guards every string literal in this package.
function lod_specimen_label(_stone) {
    /// ⛔ THE REFUSAL IS AN EMPTY STRING, NOT A PLACEHOLDER LIKE "unknown". A buyer draws this
    /// straight into an inventory row, and a word that looks like a mineral name is exactly the
    /// plausible-wrong-picture failure this package refuses everywhere else. Nothing is visible.
    if (!lod_is_stone(_stone)) return "";
    switch (_stone.state) {
        case 0: return _stone.sp.name + " in " + lod_matrix_names()[_stone.sp.matrix];
        case 1: return _stone.sp.name + ", rough";
        case 2: return _stone.sp.name + ", " + lod_cut_names()[_stone.sp.cut] + " cut";
        default: return _stone.sp.name + ", " + lod_cut_names()[_stone.sp.cut] + " cut, polished";
    }
}

/// The one-line description a cabinet plate carries under the picture.
function lod_specimen_line(_stone) {
    var _sp = _stone.sp;
    return lod_habit_names()[_sp.habit] + " / " + lod_lustre_names()[_sp.lustre] +
           " / " + lod_zoning_names()[_sp.zoning];
}
