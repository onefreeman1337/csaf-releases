{
  "$GMScript": "v1",
  "%Name": "lod_specimen",
  "name": "lod_specimen",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}