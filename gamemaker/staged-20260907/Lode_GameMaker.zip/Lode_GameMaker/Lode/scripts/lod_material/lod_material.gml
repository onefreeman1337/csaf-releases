/// LODE - lod_material. What a mineral is MADE of, expressed as a five-stop ramp.
///
/// ============================================================================================
/// LUSTRE IS THE SHADING PROGRAM. IT IS NOT A GLOSS SLIDER.
///
/// The corpus gives every species a hue, a saturation and a value - which between them describe
/// what colour a stone is - and a LUSTRE, which describes how it answers light. Those are
/// genuinely independent in nature and they are kept independent here: galena and pyrite are both
/// `metallic` at completely different hues, and sphalerite and amber are both `resinous`. That
/// independence is the whole reason 48 species do not collapse into 48 recolours of one picture.
///
/// A lustre changes FOUR things about the ramp and nothing about the hue:
///
///   span    how far the five stops travel in apparent lightness. Metallic and adamantine swing
///           almost the whole axis, which is why a polished sulphide has a white glint and a black
///           shadow on the same face. Earthy travels 0.18, which is why ochre looks like a
///           powder no matter how you light it.
///   spec    how the stops are DISTRIBUTED across that span. See the warning below - this is a
///           distribution warp, never an addition.
///   chroma  how saturation moves from the shadow stop to the lit stop. Metals LOSE chroma as
///           they brighten (a lit steel face goes white, not blue); gems GAIN it (a lit facet of
///           amethyst is more violet than its shadow, because you are seeing through more stone).
///   drift   a per-stop hue rotation, which is what makes pearly and adamantine read as having
///           fire in them rather than being merely bright.
///
/// ⛔⛔ `spec` IS A DISTRIBUTION WARP AND NOT A TERM ADDED TO THE TOP STOP, AND THE DIFFERENCE IS
/// A LAW THIS WING PAID FOR (CLAUDE.md, Muster): A TERM ADDED TO A VALUE THAT IS THEN CLAMPED
/// SILENTLY DOES NOTHING AT THE TOP OF ITS RANGE, WHICH IS USUALLY WHERE IT WAS NEEDED. The
/// obvious way to write a specular highlight is to add to stop 4 and clamp to the ceiling; on
/// every bright mineral in this corpus - selenite at L 0.87, quartz at 0.85, calcite at 0.83 -
/// stop 4 is already at the ceiling, so the highlight would be arithmetically discarded on exactly
/// the pale stones whose whole identity is that they glitter. Warping `u` moves the stops apart
/// instead, and cannot be clamped away.
///
/// ⛔ AND THE RAMP SLIDES TO FIT. IT IS NEVER CLAMPED AT ITS ENDS (CLAUDE.md, Hearth): limewash
/// put its top two stops above the ceiling, both clamped to the same value, and drew a dome as a
/// flat fill with a line round it. Diamond-bright adamantine at high `val` is one line of clamping
/// away from the same collapse here.
/// ============================================================================================

/// ⚠️ LOD_RAMP_N IS DEFINED IN lod_relief, NOT HERE, AND THAT IS CORRECT RATHER THAN AWKWARD.
/// The number of stops is a property of the RELIEF model - it is how many bands lod_relief_role
/// quantises a surface normal into - and this file merely produces that many colours. Defining it
/// again here cost one Igor build ("macro LOD_RAMP_N is already defined"), and the fix is not to
/// rename it: two macros with the same meaning is exactly the shared-fact-with-two-declarations
/// trap that CLAUDE.md §2b records shipping an out-of-bounds read into four sold cartridges.

/// The lustre programs. Index-parallel with lod_lustre_names() in lod_corpus.
///
/// ⚠️ TUNED ON THE PALEST AND MOST NEUTRAL MATERIALS, NEVER THE VIVID ONE (CLAUDE.md, Repast). A
/// colour model tuned on the one substance that did not need the missing term looks perfect on
/// that substance and wrong on four others. The reference stones for this table are SELENITE
/// (sat 0.06, val 0.94 - almost colourless and almost white) and GALENA (sat 0.05, val 0.55 -
/// neutral grey), because anything that reads on those reads on amethyst for free.
function lod_lustre_spec(_lustre) {
    switch (clamp(_lustre, 0, LOD_LUSTRE_N - 1)) {
        case 0: return { span: 0.62, spec: 0.55, cLo: 0.60, cHi: 0.34, drift:  0 };  // metallic
        case 1: return { span: 0.46, spec: 0.22, cLo: 0.78, cHi: 1.28, drift:  0 };  // vitreous
        case 2: return { span: 0.70, spec: 0.72, cLo: 0.62, cHi: 1.40, drift:  7 };  // adamantine
        case 3: return { span: 0.30, spec: 0.14, cLo: 0.90, cHi: 1.10, drift:  0 };  // silky
        case 4: return { span: 0.26, spec: 0.10, cLo: 0.84, cHi: 1.16, drift: 30 };  // pearly
        case 5: return { span: 0.38, spec: 0.18, cLo: 0.86, cHi: 1.20, drift:  0 };  // resinous
        case 6: return { span: 0.30, spec: 0.12, cLo: 0.88, cHi: 1.04, drift:  0 };  // greasy
        case 7: return { span: 0.18, spec: 0.00, cLo: 0.96, cHi: 1.00, drift:  0 };  // earthy
        case 8: return { span: 0.50, spec: 0.38, cLo: 0.66, cHi: 0.52, drift:  0 };  // submetallic
        default: return { span: 0.34, spec: 0.08, cLo: 0.92, cHi: 1.06, drift: 0 };  // waxy
    }
}

/// A species' base colour in Oklch, before lustre shapes it into a ramp.
///
/// ⚠️ THE CORPUS STORES HSV-SHAPED NUMBERS AND THIS IS THE ONE PLACE THEY BECOME PERCEPTUAL. Real
/// mineralogical descriptions are written in hue/saturation/value terms, so the corpus is authored
/// that way and converted here rather than being authored in a space no mineralogist writes in.
/// The conversion is deliberately compressive at both ends: no stone in this corpus is pure black
/// or pure white, because no stone in the world is.
function lod_mat_base(_sp) {
    return {
        L: 0.09 + 0.82 * clamp(_sp.val, 0, 1),
        C: 0.155 * clamp(_sp.sat, 0, 1),
        h: _sp.hue
    };
}

/// Five stops for one species.
///
/// _wet is 0 for a dry specimen and 1 for a polished or wetted one. Wetting a stone is not a
/// brightening: it DEEPENS the shadows and lifts the highlight, because a smooth surface reflects
/// specularly instead of scattering. So it widens the span and raises spec, and it is the single
/// most convincing thing a mineral generator can do that a static sprite pack cannot.
function lod_mat_ramp(_sp, _wet) {
    var _b = _lod_mat_base_wet(_sp, _wet);
    var _ls = lod_lustre_spec(_sp.lustre);
    var _w = is_undefined(_wet) ? 0 : clamp(_wet, 0, 1);

    var _span = min(_ls.span * (1 + 0.28 * _w), 0.92 - 0.055);
    var _spec = _ls.spec * (1 + 0.5 * _w);

    // Slide, never clamp. See the header.
    var _floor = 0.055, _ceil = 0.920;
    var _lo = _b.L - _span * 0.5;
    var _hi = _b.L + _span * 0.5;
    if (_hi > _ceil) { _lo -= (_hi - _ceil); _hi = _ceil; }
    if (_lo < _floor) { _hi += (_floor - _lo); _lo = _floor; }
    _hi = min(_hi, _ceil);

    var _out = array_create(LOD_RAMP_N);
    for (var _i = 0; _i < LOD_RAMP_N; _i++) {
        var _t = _i / (LOD_RAMP_N - 1);
        // THE WARP. power > 1 holds the low stops down and leaves a wide gap to the top stop,
        // which is what a specular highlight IS. At spec 0 it is the identity and the stops are
        // evenly spaced, which is what a matte earthy surface wants.
        var _u = power(_t, 1 + _spec * 1.6);
        var _Li = _lo + (_hi - _lo) * _u;
        var _Ci = _b.C * lerp(_ls.cLo, _ls.cHi, _u);
        _out[_i] = lod_oklch(_Li, max(0, _Ci), _b.h + _ls.drift * (_u - 0.5) * 2);
    }
    return _out;
}

/// Wetting shifts the BASE too, not only the ramp: a wet stone reads darker overall because less
/// light scatters back out of it. Split out so lod_selftest can assert the direction.
function _lod_mat_base_wet(_sp, _wet) {
    var _b = lod_mat_base(_sp);
    var _w = is_undefined(_wet) ? 0 : clamp(_wet, 0, 1);
    return { L: _b.L * (1 - 0.10 * _w), C: _b.C * (1 + 0.22 * _w), h: _b.h };
}

/// The role map that points lod_relief's m0..m4 at a named ramp in the palette.
///
/// Returned fresh every call rather than cached, because lod_map_roles reads it once and a shared
/// mutable map is the kind of thing that works until two specimens are built in the same frame.
function lod_mat_map(_prefix) {
    return {
        m0: _prefix + "0", m1: _prefix + "1", m2: _prefix + "2",
        m3: _prefix + "3", m4: _prefix + "4",
    };
}

/// Write one species' five stops into a palette struct under a prefix.
function lod_mat_into(_pal, _prefix, _sp, _wet) {
    var _r = lod_mat_ramp(_sp, _wet);
    for (var _i = 0; _i < LOD_RAMP_N; _i++) {
        variable_struct_set(_pal, _prefix + string(_i), _r[_i]);
    }
    return _pal;
}

/// ⛔ THE THING YOU WRITE ON A SURFACE IS NOT THAT SURFACE'S DARKEST STOP (CLAUDE.md, Lexicon).
///
/// This corpus contains SELENITE at L 0.86 and JET at L 0.20 and captions both. A label set in m0
/// on selenite is "merely less pale" and vanishes; the same label in m0 on jet is invisible for
/// the opposite reason. An ink is defined RELATIVE to its own ground and goes the other way from
/// it, by an asserted minimum.
function lod_mat_ink(_sp) {
    var _b = lod_mat_base(_sp);
    var _sep = 0.36;
    var _L = (_b.L > 0.5) ? max(0.045, _b.L - _sep) : min(0.960, _b.L + _sep);
    return lod_oklch(_L, _b.C * 0.50, _b.h);
}

/// How far a species' ink sits from its own base, in Oklab lightness. Exists so the suite can
/// assert the separation rather than trust the arithmetic above, and so a species added at an
/// awkward lightness fires BY NAME instead of shipping an unreadable caption.
function lod_mat_ink_sep(_sp) {
    var _b = lod_mat_base(_sp);
    var _L = (_b.L > 0.5) ? max(0.045, _b.L - 0.36) : min(0.960, _b.L + 0.36);
    return abs(_L - _b.L);
}

/// ============================================================================================
/// THE HOST ROCK
///
/// ⚠️ THE MATRIX IS NOT A BACKGROUND. It is the second half of the picture and it carries the
/// depth band: a specimen on dark laminated shale reads as having come out of a sulphide zone and
/// one on pale sugary quartzite reads as a vein. It also does the hardest job in the product,
/// which is to make the crystal READ - a pale crystal on a pale rock is a picture of nothing, and
/// that is a contrast problem the corpus cannot solve on its own because the species and the
/// matrix are chosen by geology rather than by design.
///
/// ⛔ SO THE SEPARATION IS SOLVED, NOT ASSUMED (CLAUDE.md: "when a number cannot be chosen,
/// suspect the question"). lod_matrix_shift below rotates the ROCK away from the crystal in
/// lightness when the two would otherwise sit on top of each other. The rock moves, never the
/// mineral: the mineral's colour is the thing a buyer looked up, and the rock's is not.
/// ============================================================================================

/// The eight host rocks. Index-parallel with lod_matrix_names().
function lod_rock_spec(_matrix) {
    switch (clamp(_matrix, 0, LOD_MATRIX_N - 1)) {
        case 0: return { L: 0.66, C: 0.014, h:  40, span: 0.30, grain: 0 };  // granite, speckled
        case 1: return { L: 0.27, C: 0.010, h: 250, span: 0.24, grain: 1 };  // basalt, vesicular
        case 2: return { L: 0.75, C: 0.022, h:  72, span: 0.24, grain: 2 };  // limestone, flecked
        case 3: return { L: 0.31, C: 0.012, h: 242, span: 0.20, grain: 3 };  // shale, laminated
        case 4: return { L: 0.70, C: 0.008, h:  60, span: 0.26, grain: 4 };  // quartzite, sugary
        case 5: return { L: 0.45, C: 0.016, h:  92, span: 0.34, grain: 5 };  // schist, foliated
        case 6: return { L: 0.64, C: 0.048, h:  52, span: 0.26, grain: 6 };  // sandstone, granular
        default: return { L: 0.43, C: 0.055, h: 152, span: 0.28, grain: 7 }; // serpentinite, veined
    }
}

/// How far this rock must move so the crystal standing on it can be seen.
///
/// Returns a signed lightness offset. It is a SOLVED value rather than a tuned constant: if the
/// rock and the mineral are already more than the floor apart it returns 0 and the rock is drawn
/// exactly as the table describes it.
///
/// ⚠️ IT MOVES AWAY FROM THE MINERAL, WHICH MEANS IT CAN MOVE EITHER WAY, and both are correct:
/// pyrite on shale wants the shale darker, and jet on shale wants it lighter. A rule that only
/// darkened would make every dark stone invisible on every dark rock.
function lod_matrix_shift(_sp, _matrix) {
    var _b = lod_mat_base(_sp);
    var _r = lod_rock_spec(_matrix);
    var _floor = 0.20;
    var _d = _r.L - _b.L;
    if (abs(_d) >= _floor) return 0;
    var _dir = (_d >= 0) ? 1 : -1;
    // Near-equal lightness has no direction of its own, so push the rock toward whichever end of
    // the axis has more room. Without this, a mineral sitting exactly on its rock's lightness gets
    // an arbitrary sign and two neighbouring species in the corpus disagree for no visible reason.
    if (abs(_d) < 0.0100) _dir = (_b.L > 0.5) ? -1 : 1;
    var _want = _dir * _floor - _d;
    // Do not push the rock off the end of the axis; if there is no room that way, go the other.
    var _target = _r.L + _want;
    if (_target > 0.90 || _target < 0.12) _want = -_dir * _floor - _d;
    return _want;
}

/// Five stops for a host rock, already separated from the mineral standing on it.
function lod_rock_ramp(_sp, _matrix) {
    var _r = lod_rock_spec(_matrix);
    var _L0 = clamp(_r.L + lod_matrix_shift(_sp, _matrix), 0.10, 0.90);

    var _floor = 0.045, _ceil = 0.945;
    var _span = min(_r.span, _ceil - _floor);
    var _lo = _L0 - _span * 0.5;
    var _hi = _L0 + _span * 0.5;
    if (_hi > _ceil) { _lo -= (_hi - _ceil); _hi = _ceil; }
    if (_lo < _floor) { _hi += (_floor - _lo); _lo = _floor; }
    _hi = min(_hi, _ceil);

    var _out = array_create(LOD_RAMP_N);
    for (var _i = 0; _i < LOD_RAMP_N; _i++) {
        var _u = _i / (LOD_RAMP_N - 1);
        _out[_i] = lod_oklch(_lo + (_hi - _lo) * _u, _r.C * (0.85 + 0.30 * _u), _r.h);
    }
    return _out;
}

/// Write a host rock's five stops into a palette under a prefix.
function lod_rock_into(_pal, _prefix, _sp, _matrix) {
    var _r = lod_rock_ramp(_sp, _matrix);
    for (var _i = 0; _i < LOD_RAMP_N; _i++) {
        variable_struct_set(_pal, _prefix + string(_i), _r[_i]);
    }
    return _pal;
}

/// ============================================================================================
/// THE PALETTE A SPECIMEN IS DRAWN WITH
/// ============================================================================================

/// Everything one specimen needs, in one struct.
///
/// Roles: s0..s4 the mineral, r0..r4 the host rock, z0..z4 the SECONDARY mineral colour used by
/// the zoned/banded/phantom programs, ink for anything written on the stone, and the four page
/// roles a plate is composed on.
///
/// _wet 0..1 is dry to polished. _zone_hue is the secondary hue for a zoned stone; pass undefined
/// and lod_zoning picks one from the species itself.
function lod_pal_for(_sp, _matrix, _wet, _zone_hue) {
    var _pal = {
        page:  lod_oklch(0.155, 0.010, 250),
        panel: lod_oklch(0.215, 0.012, 250),
        line:  lod_oklch(0.400, 0.010, 250),
        label: lod_oklch(0.760, 0.008, 250),
        ink:   lod_mat_ink(_sp)
    };
    lod_mat_into(_pal, "s", _sp, _wet);
    lod_rock_into(_pal, "r", _sp, _matrix);

    // The secondary. A zoned stone is the SAME mineral at a different composition, so its hue is
    // near its own and its lightness is what actually separates the zones - which is why this is a
    // hue nudge and a lightness step rather than a second colour picked from anywhere.
    //
    // ⛔ THE FIRST VERSION MOVED IT FAR TOO FAR (hue +34, value x0.78) AND NINE SPECIES BAKED AS
    // FLAT MULTICOLOURED STRIPES. Nothing mechanical could see it: a band is ink exactly where ink
    // belongs, the ink floors went UP, and every geometry assertion passed. It was found by opening
    // the corpus sheet and looking at malachite, azurite, rhodochrosite and agate side by side.
    //
    // ⭐ The principle, and it is the same one the wing's colour laws keep arriving at: banding is
    // a COMPOSITIONAL change within one species, not a second mineral. Agate's bands differ by a
    // modest step in lightness and a few degrees of hue; the eye reads that as banding. Anything
    // larger reads as stripes painted on.
    var _h2 = is_undefined(_zone_hue) ? (_sp.hue + 15) : _zone_hue;
    var _alt = {
        name: _sp.name, family: _sp.family, habit: _sp.habit, lustre: _sp.lustre,
        zoning: _sp.zoning, cut: _sp.cut, matrix: _sp.matrix, band: _sp.band,
        hue: _h2, sat: clamp(_sp.sat * 0.90, 0, 1),
        // Step AWAY from the mineral's own value, and only by 0.10 - toward the light end from a
        // dark stone and the dark end from a pale one, so the band is visible on both without
        // being a different colour on either.
        val: clamp(_sp.val + ((_sp.val > 0.55) ? -0.10 : 0.10), 0, 1),
        hardness: _sp.hardness, density: _sp.density, rarity: _sp.rarity
    };
    lod_mat_into(_pal, "z", _alt, _wet);

    // The four iridescence roles. A play of colour is a HUE sweep at nearly constant lightness -
    // see lod_zone_iridescent - so these are deliberately four hues at ONE lightness taken from
    // the mineral's own mid stop, rather than four steps of a ramp. Built here because a palette
    // is the one place a colour belongs, and asserted distinct by lod_selftest.
    var _b = lod_mat_base(_sp);
    var _iL = clamp(_b.L * 0.94 + 0.10, 0.28, 0.82);
    for (var _i = 0; _i < 4; _i++) {
        variable_struct_set(_pal, "i" + string(_i), lod_oklch(_iL, 0.085, _sp.hue + 78 * _i + 20));
    }
    return _pal;
}

/// ⛔ HUE INTERPOLATION, WEIGHTED BY CHROMA CONTRIBUTION.
///
/// (CLAUDE.md, Armoury.) Steel sits at hue 250 and rust at 44, and BOTH ways round the circle are
/// wrong: the long way goes through green, the short way through magenta. The error is upstream of
/// the direction - polished steel's chroma is 0.006, so it does not HAVE a hue anyone can see, and
/// sweeping from it treats an invisible number as a starting appearance.
///
/// This corpus is full of exactly that pair. Selenite is C 0.009 and any zoning applied to it must
/// adopt the target's hue almost immediately and simply get MORE of it; malachite at C 0.112 must
/// genuinely blend. Weighting by how much chroma each side still contributes does both, and the
/// short-way-round rotation is then safe because nothing perceptible is being swept through.
function lod_hue_lerp(_h0, _h1, _k) {
    var _d = _h1 - _h0;
    while (_d > 180) _d -= 360;
    while (_d < -180) _d += 360;
    return _h0 + _d * _k;
}

/// The chroma-weighted blend factor for a transform of strength _k from _c0 toward _c1.
function lod_hue_weight(_c0, _c1, _k) {
    var _a = _c0 * (1 - _k);
    var _b = _c1 * _k;
    if (_a + _b > 0.0001) return _b / (_a + _b);
    return _k;
}
