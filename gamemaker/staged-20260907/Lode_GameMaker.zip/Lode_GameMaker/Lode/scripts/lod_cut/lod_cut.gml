/// LODE - lod_cut. The ten faceted cuts a rough stone becomes.
///
/// ============================================================================================
/// THE CUT IS THE PAYOFF, AND IT IS A SECOND DRAWING OF THE SAME MINERAL.
///
/// A player finds rough, assays it, and cuts it. The cut stone must be recognisably the SAME
/// species - same hue, same lustre program, same zoning carried through - and a completely
/// different picture. That pairing is the product's whole loop, and it is why the corpus stores a
/// `cut` per species and a LOD_CUT_NONE for the twenty that are never faceted. Native gold is not
/// cut; galena is not cut; pyrite is not cut. Saying so is more convincing than pretending
/// everything becomes a jewel.
///
/// -- WHAT MAKES A FACETED STONE READ ---------------------------------------------------------
/// A cut gem seen face-up is a TABLE (the flat top), a CROWN of facets sloping away from it, a
/// GIRDLE (the outline), and the PAVILION seen through the stone - and it is the pavilion that
/// does the work. The dark and bright wedges inside a brilliant are the back facets seen by
/// refraction, which is why a gem drawn as an outline with a highlight looks like plastic and one
/// drawn with an internal facet pattern looks like a stone.
///
/// ⛔ EVERY OUTLINE HERE IS CONVEX OR IS BUILT WITH lod_ring_fill. lod_render_fill is a triangle
/// FAN and its documented precondition is that the outline be star-shaped about pts[0]; hand it a
/// concave shape and it spans the concavity silently. This wing shipped every moon crescent as a
/// quarter for exactly that (CLAUDE.md, Welkin). A marquise and a pear are the two shapes here
/// that could go wrong, and both are built as star-shaped rings about their own centre.
///
/// ⛔ AND THE STONE IS NOT DRAWN STANDING ON LOD_GROUND. A cut stone is held up to the light, not
/// bedded in rock; it is centred in its cell. That is a deliberate difference from lod_habit and
/// lod_selftest asserts it, so the two never quietly drift into the same layout.
/// ============================================================================================

/// The girdle outline for a cut, as a closed ring about the origin. _r is the half-width.
///
/// ⚠️ EVERY OUTLINE IS RETURNED THROUGH lod_dedupe_pts. A duplicated vertex caps every bevel in a
/// shape to nothing and loses a turning test's meaning, and two of these builders can land two
/// points together at extreme aspect ratios.
function lod_cut_girdle(_cut, _r) {
    var _pts;
    switch (_cut) {
        case 0:  // brilliant: round
            _pts = lod_ellipse_pts(0, 0, _r, _r, 24);
            break;
        case 1:  // step / emerald: rectangle with cut corners
            _pts = lod_pts_chamfer(-_r * 0.78, -_r, _r * 0.78, _r, _r * 0.26);
            break;
        case 2:  // rose: round, flat based
            _pts = lod_ellipse_pts(0, 0, _r, _r * 0.96, 20);
            break;
        case 3:  // cabochon: a dome, so the outline is an oval
            _pts = lod_ellipse_pts(0, 0, _r, _r * 0.80, 22);
            break;
        case 4: {  // marquise: pointed ellipse - two arcs meeting at two points
            _pts = [];
            var _n = 11;
            for (var _i = 0; _i <= _n; _i++) {
                var _t = -1 + 2 * (_i / _n);
                array_push(_pts, [_t * _r, -power(1 - _t * _t, 0.72) * _r * 0.46]);
            }
            for (var _i = _n; _i >= 0; _i--) {
                var _t = -1 + 2 * (_i / _n);
                array_push(_pts, [_t * _r, power(1 - _t * _t, 0.72) * _r * 0.46]);
            }
            break;
        }
        case 5: {  // trillion: triangular, with the softened corners and slightly bowed sides a
                   // real trilliant has - a hard-cornered triangle reads as a warning sign.
            _pts = [];
            var _cr = 0.20;                 // how much of each corner is a rounded arc
            for (var _i = 0; _i < 3; _i++) {
                var _a = -pi * 0.5 + LOD_TAU * _i / 3;
                // The rounded corner: a short arc centred on the corner direction.
                for (var _k = 0; _k <= 3; _k++) {
                    var _t = _a + (-0.5 + _k / 3.0) * LOD_TAU / 3 * _cr;
                    array_push(_pts, [cos(_t) * _r, sin(_t) * _r]);
                }
                // The bowed side toward the next corner.
                var _b = _a + LOD_TAU / 3;
                for (var _k = 1; _k <= 3; _k++) {
                    var _t = _a + (_b - _a) * (_k / 4.0);
                    array_push(_pts, [cos(_t) * _r * 0.90, sin(_t) * _r * 0.90]);
                }
            }
            break;
        }
        case 6: {  // pear: a teardrop - round at one end, pointed at the other
            _pts = [];
            var _n = 22;
            for (var _i = 0; _i < _n; _i++) {
                var _a = LOD_TAU * _i / _n;
                // The taper is a function of the angle, so the shape stays star-shaped about the
                // origin - which is what keeps the fan honest.
                var _k = 0.60 + 0.40 * (1 - power(max(0, -sin(_a)), 1.5));
                array_push(_pts, [cos(_a) * _r * 0.78 * _k, sin(_a) * _r * _k]);
            }
            break;
        }
        case 7:  // baguette: narrow rectangle
            _pts = lod_pts_square(-_r * 0.40, -_r, _r * 0.40, _r);
            break;
        case 8:  // oval
            _pts = lod_ellipse_pts(0, 0, _r * 0.74, _r, 22);
            break;
        default: // cushion: square with rounded corners
            _pts = lod_pts_round(-_r * 0.88, -_r * 0.88, _r * 0.88, _r * 0.88, _r * 0.34, 5);
            break;
    }
    return lod_dedupe_pts(_pts);
}

/// The internal facet pattern for a cut, drawn INSIDE the girdle.
///
/// Each pattern is the real facet arrangement of that cut, simplified to what survives at the
/// sizes this product draws: radial crown mains for a brilliant, parallel steps for an emerald
/// cut, a triangular star for a rose, a single soft highlight for a cabochon.
function lod_cut_facets(_cut, _r, _seed) {
    var _out = [];
    var _rng = lod_rng(_seed + 104729);
    switch (_cut) {
        case 0: {  // BRILLIANT. Table, eight crown mains, and the pavilion star beneath.
            var _tab = lod_ellipse_pts(0, 0, _r * 0.46, _r * 0.46, 12);
            var _n = 8;
            for (var _i = 0; _i < _n; _i++) {
                var _a0 = LOD_TAU * _i / _n, _a1 = LOD_TAU * (_i + 1) / _n;
                var _am = (_a0 + _a1) * 0.5;
                lod_append(_out, lod_facet([[cos(_a0) * _r, sin(_a0) * _r],
                                            [cos(_a1) * _r, sin(_a1) * _r],
                                            [cos(_am) * _r * 0.46, sin(_am) * _r * 0.46]], 0, 0, 0.003));
            }
            lod_append(_out, lod_facet(_tab, 0, _r * 3, 0.004));
            // The pavilion, seen through the table: the alternating light and dark wedges that
            // make a brilliant look deep rather than flat.
            for (var _i = 0; _i < _n; _i++) {
                var _a0 = LOD_TAU * (_i + 0.5) / _n, _a1 = LOD_TAU * (_i + 1.5) / _n;
                array_push(_out, lod_fill([[0, 0], [cos(_a0) * _r * 0.44, sin(_a0) * _r * 0.44],
                                           [cos(_a1) * _r * 0.44, sin(_a1) * _r * 0.44]],
                                          lod_stop((_i % 2 == 0) ? 0 : 3)));
            }
            break;
        }
        case 1: {  // STEP. Parallel rectangular steps, which is the whole of an emerald cut.
            // ⛔⛔ THE STOPS ARE ASSIGNED EXPLICITLY HERE AND lod_facet IS NOT USED, BECAUSE THE
            // NORMAL TRICK CANNOT WORK ON CONCENTRIC SHAPES. lod_facet derives a face's stop from
            // the direction between an interior point and the face's own centre - which is exactly
            // right for the faces of a solid arranged AROUND that point, and meaningless for rings
            // nested INSIDE one another, where every ring shares the same centre. Every step
            // therefore took the same normal, every step took the same dark stop, and the emerald
            // cut and the baguette both baked as BLACK RECTANGLES with a pink rim.
            //
            // ⭐ A stepped crown physically gets lighter toward the table: each step is a plane
            // tilted a little further toward the lamp than the one outside it. Two lines of
            // explicit stops say that, and they say it correctly at any face count.
            var _n = 4;
            for (var _i = 0; _i < _n; _i++) {
                var _k = 1 - (_i + 1) * 0.18;
                var _pts = lod_pts_chamfer(-_r * 0.78 * _k, -_r * _k, _r * 0.78 * _k, _r * _k, _r * 0.26 * _k);
                array_push(_out, lod_ring_fill(_pts, lod_stop(1 + _i), 0, 0));
                array_push(_out, lod_poly(_pts, true, 0.0035, lod_stop(2 + _i)));
            }
            break;
        }
        case 2: {  // ROSE. Domed triangular facets rising to a central point, on a flat base.
            // ⚠️ TWELVE FACETS, NOT SIX. With six the lamp banding gives three lit and three dark
            // and the stone reads as a circle cut in half, which is what baked. A rose cut has 24
            // facets in life; twelve is enough for the dome to turn continuously at the sizes this
            // draws at.
            var _n = 12;
            for (var _i = 0; _i < _n; _i++) {
                var _a0 = LOD_TAU * _i / _n, _a1 = LOD_TAU * (_i + 1) / _n;
                // Interior point (0,0), NOT a point outside the stone. See the STEP case: a face
                // whose stop is derived from a distant interior point gets the same normal as every
                // other face, and the rose baked as a pale disc with one dark wedge. From the
                // centre the direction is radial, which is what a dome of facets needs.
                lod_append(_out, lod_facet([[cos(_a0) * _r, sin(_a0) * _r * 0.96],
                                            [cos(_a1) * _r, sin(_a1) * _r * 0.96], [0, 0]], 0, 0, 0.0025));
            }
            break;
        }
        case 3: {  // CABOCHON. No facets at all - a polished dome, so a bevel and a highlight.
            // ⛔ THE BEVEL IS CAPPED. A bevel wider than the feature it bevels turns that feature
            // INSIDE OUT (wing CLAUDE.md, Vestige): the inset rings cross each other and the dome
            // renders as a jagged ring of shards, which is exactly what a 0.44 dome on a 22-point
            // ellipse produced - the ugliest cell on the cuts sheet, and it reached the COVER.
            // lod_bevel_cap solves the depth from the outline's own inset limit, so no radius or
            // sample count can re-open it.
            // ⛔ A DOME IS NESTED RINGS OFFSET TOWARD THE LAMP, NOT A BEVEL. lod_bevel colours by
            // EDGE normal, which draws a lit RIM around a flat interior - correct for a raised
            // panel and wrong for a sphere, and it baked as a dark blob inside a staircase of
            // shards. A cabochon has no edges to catch light; its whole surface turns. Four
            // ellipses, each smaller and each shifted along the lamp vector, is the oldest way to
            // draw a sphere and it reads at any size.
            for (var _s = 0; _s < 5; _s++) {
                var _k = 1 - _s * 0.19;
                var _off = _r * 0.085 * _s;
                lod_append(_out, lod_ring_fill(
                    lod_ellipse_pts(LOD_LX * _off, LOD_LY * _off * 0.8, _r * _k, _r * 0.80 * _k, 20),
                    lod_stop(1 + _s), LOD_LX * _off, LOD_LY * _off * 0.8));
            }
            // ⚠️ THE HIGHLIGHT IS A FLAT MARK, NOT A RAISED ONE. Drawing it with lod_raise gave it
            // its own bevel, so the polish spot on a dome had a rim - a bead sitting on the stone
            // rather than a reflection in it.
            array_push(_out, lod_ring_fill(lod_ellipse_pts(-_r * 0.40, -_r * 0.34, _r * 0.16, _r * 0.09, 14),
                                           "m4", -_r * 0.40, -_r * 0.34));
            break;
        }
        case 4: case 6: case 8: {  // MARQUISE, PEAR, OVAL. A long axis, so the facets run along it.
            var _g = lod_cut_girdle(_cut, _r);
            var _n = array_length(_g);
            for (var _i = 0; _i < _n; _i++) {
                var _j = (_i + 1) % _n;
                lod_append(_out, lod_facet([_g[_i], _g[_j], [_g[_i][0] * 0.34, _g[_i][1] * 0.34]], 0, 0, 0.0022));
            }
            lod_append(_out, lod_facet(lod_scale_pts(_g, 0.34), 0, _r * 3, 0.003));
            break;
        }
        case 5: {  // TRILLION. Three crown mains and a triangular table.
            var _g = lod_cut_girdle(5, _r);
            var _n = array_length(_g);
            for (var _i = 0; _i < _n; _i++) {
                var _j = (_i + 1) % _n;
                // Interior point (0,0) - same reason as the ROSE case above.
                lod_append(_out, lod_facet([_g[_i], _g[_j], [0, 0]], 0, 0, 0.0025));
            }
            break;
        }
        case 7: {  // BAGUETTE. Long steps: a baguette is a plain, stepped stone.
            // Explicit stops, for the concentric-rings reason given in the STEP case above.
            for (var _i = 0; _i < 3; _i++) {
                var _k = 1 - (_i + 1) * 0.20;
                var _pts = lod_pts_square(-_r * 0.40 * _k, -_r * _k, _r * 0.40 * _k, _r * _k);
                array_push(_out, lod_ring_fill(_pts, lod_stop(1 + _i), 0, 0));
                array_push(_out, lod_poly(_pts, true, 0.003, lod_stop(2 + _i)));
            }
            break;
        }
        default: {  // CUSHION. A rounded square table with four corner mains.
            var _g = lod_cut_girdle(9, _r);
            var _n = array_length(_g);
            for (var _i = 0; _i < _n; _i++) {
                var _j = (_i + 1) % _n;
                lod_append(_out, lod_facet([_g[_i], _g[_j], [_g[_i][0] * 0.40, _g[_i][1] * 0.40]], 0, 0, 0.0022));
            }
            lod_append(_out, lod_facet(lod_scale_pts(_g, 0.40), 0, _r * 3, 0.0035));
            break;
        }
    }
    return _out;
}

/// A whole cut stone: girdle, facets, and the zoning carried through from the rough.
///
/// _polish 0..1 is how far the stone has been worked. It goes into lod_mat_ramp as `wet`, because
/// polishing and wetting are the same optical event - a smooth surface reflecting specularly
/// instead of scattering - and modelling them once means the demo's polish slider is the same code
/// path as a stone lifted out of a stream.
function lod_cut_parts(_sp, _seed, _r) {
    if (_sp.cut == LOD_CUT_NONE) return [];
    var _out = [];
    var _g = lod_cut_girdle(_sp.cut, _r);
    // The body of the stone first, so every facet is drawn ON it and no gap can show through.
    array_push(_out, lod_ring_fill(_g, "m2", 0, 0));
    lod_append(_out, lod_cut_facets(_sp.cut, _r, _seed));
    // The girdle line last: it is the stone's edge and nothing is in front of it.
    array_push(_out, lod_poly(_g, true, 0.005, "m4"));
    return _out;
}

/// Whether a species is ever cut. Exists so callers ask a question rather than compare against a
/// sentinel they might get the sign of wrong.
function lod_is_cuttable(_sp) {
    return (_sp.cut != LOD_CUT_NONE);
}
