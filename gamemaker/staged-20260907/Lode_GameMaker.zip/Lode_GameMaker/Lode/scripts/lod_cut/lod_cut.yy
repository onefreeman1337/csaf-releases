{
  "$GMScript": "v1",
  "%Name": "lod_cut",
  "name": "lod_cut",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}