/// LODE - lod_selftest. The in-engine suite.
///
/// ============================================================================================
/// ⛔ GML CANNOT BE UNIT-TESTED OUTSIDE THE ENGINE. There is no headless runner, no mock, no
/// assertion library. This wing's answer is to build the product through Igor, run the executable
/// with `-selftest`, and have it write a JSON result file - which is the ONE route that survives a
/// release build (show_debug_message is dead in one, and game_end's argument is not propagated).
///
/// ⛔ AND A SUITE FULL OF GREEN ASSERTIONS PROVES NOTHING UNTIL ONE OF THEM HAS BEEN MADE TO FAIL.
/// Two of this wing's worst incidents were suites that could never have gone red: a duplicate check
/// written with a tolerance below GML's default epsilon passed VACUOUSLY for every input, and a
/// containment assertion passed on all 216 letters of a corpus while most of them were being
/// silently shrunk. Where an assertion here could be vacuous, it is PAIRED with one that proves the
/// fixture is in the state the first one needs - and those pairs are marked VACUITY GUARD.
///
/// ⛔ THE DEFAULT EPSILON. math_get_epsilon() returns 0.00001 on this runtime and it PARTICIPATES
/// IN COMPARISONS, so `abs(a - b) < 0.0000001` is FALSE for every pair of values including equal
/// ones, and `abs(a - b) < 0.00001` is RED for two values that are the same object. Never write a
/// tolerance below or at ~1e-5. LOD_ST_EPS is the one this file uses.
///
/// ⚠️ WHAT THIS SUITE CANNOT SEE, STATED HERE RATHER THAN LEFT FOR A BUYER TO DISCOVER: it computes
/// POINTS and NUMBERS. It cannot see a FILL RULE, a DRAW ORDER or a PICTURE. This wing has shipped
/// a crescent moon rendered as a quarter, a rainbow that never drew at all and a gilt rim across
/// twelve plates, all with the geometry suite fully green. The instrument for those is opening the
/// baked sheet and looking at it, and that step is not optional because this file exists.
/// ============================================================================================

#macro LOD_ST_EPS 0.0001

function lod_st_new() {
    return { pass: 0, fail: 0, notes: [] };
}

function lod_st_ok(_r, _cond, _what) {
    if (_cond) { _r.pass += 1; return; }
    _r.fail += 1;
    // Cap the note list. A systemic failure can fire thousands of times and a result file that
    // cannot be written is a result file nobody reads.
    if (array_length(_r.notes) < 60) array_push(_r.notes, _what);
}

/// ============================================================================================
/// THE SUITE
/// ============================================================================================

function lod_selftest_run() {
    var _r = lod_st_new();

    // -- STAGE 0: the runtime still behaves the way this package assumes ------------------------
    global.lod_stage = 0;
    var _e = math_get_epsilon();
    // ⛔ TWO CLAUSES, AND THE SECOND IS `!(_e > 0)` ON PURPOSE. The natural single expression
    // `_e > 0 && _e < TOL` goes RED on its first clause forever: the difference between the epsilon
    // and zero IS the epsilon, so GML calls them equal, and equal is not greater-than. Written this
    // way it is a POSITIVE test that the runtime still applies an epsilon, and it goes red the day
    // a release stops - which is a thing this package would need to know.
    lod_st_ok(_r, !(_e > 0), "epsilon: expected (_e > 0) to be FALSE - the epsilon trap is gone");
    lod_st_ok(_r, _e < 0.001, "epsilon: " + string_format(_e, 1, 12) + " is larger than assumed");

    // -- STAGE 1: THE CORPUS IS THE ONE THE AUDIT PROVED ----------------------------------------
    // ⛔ lod_corpus.gml is GENERATED from Internal_Ops/minerals.js, which is where the uniqueness,
    // family-exclusivity and reachability guarantees are proven. These assertions re-prove the two
    // that can be checked cheaply IN ENGINE, so a generator defect that produced a valid-looking
    // but wrong table cannot pass silently.
    global.lod_stage = 1;
    var _c = lod_corpus();
    lod_st_ok(_r, array_length(_c) == LOD_SPECIES_N,
              "corpus: " + string(array_length(_c)) + " species, macro says " + string(LOD_SPECIES_N));
    lod_st_ok(_r, LOD_SPECIES_N >= 40, "corpus: " + string(LOD_SPECIES_N) + " species is below the volume floor of 40");

    var _habit_seen = array_create(LOD_HABIT_N, 0);
    var _lustre_seen = array_create(LOD_LUSTRE_N, 0);
    var _zone_seen = array_create(LOD_ZONING_N, 0);
    var _cut_seen = array_create(LOD_CUT_N, 0);
    var _mat_seen = array_create(LOD_MATRIX_N, 0);
    var _triples = 0;
    for (var _i = 0; _i < LOD_SPECIES_N; _i++) {
        var _sp = _c[_i];
        lod_st_ok(_r, _sp.habit >= 0 && _sp.habit < LOD_HABIT_N, _sp.name + ": habit out of range");
        lod_st_ok(_r, _sp.lustre >= 0 && _sp.lustre < LOD_LUSTRE_N, _sp.name + ": lustre out of range");
        lod_st_ok(_r, _sp.zoning >= 0 && _sp.zoning < LOD_ZONING_N, _sp.name + ": zoning out of range");
        lod_st_ok(_r, _sp.matrix >= 0 && _sp.matrix < LOD_MATRIX_N, _sp.name + ": matrix out of range");
        lod_st_ok(_r, _sp.band >= 0 && _sp.band < LOD_BAND_N, _sp.name + ": band out of range");
        lod_st_ok(_r, _sp.hardness >= 1 && _sp.hardness <= 10, _sp.name + ": hardness off the Mohs scale");
        lod_st_ok(_r, _sp.density > 0, _sp.name + ": impossible density");
        _habit_seen[_sp.habit] = 1;
        _lustre_seen[_sp.lustre] = 1;
        _zone_seen[_sp.zoning] = 1;
        _mat_seen[_sp.matrix] = 1;
        if (_sp.cut != LOD_CUT_NONE) {
            lod_st_ok(_r, _sp.cut >= 0 && _sp.cut < LOD_CUT_N, _sp.name + ": cut out of range");
            _cut_seen[_sp.cut] = 1;
        }
        // No two species may be the same drawing.
        for (var _j = _i + 1; _j < LOD_SPECIES_N; _j++) {
            var _o = _c[_j];
            var _same = (_sp.habit == _o.habit) && (_sp.lustre == _o.lustre) && (_sp.zoning == _o.zoning);
            if (_same) _triples++;
            lod_st_ok(_r, !_same, _sp.name + " and " + _o.name + " are the same drawing");
        }
    }
    lod_st_ok(_r, _triples == 0, "corpus: " + string(_triples) + " colliding (habit,lustre,zoning) triples");
    for (var _i = 0; _i < LOD_HABIT_N; _i++) {
        lod_st_ok(_r, _habit_seen[_i] == 1, "habit never reached: " + lod_habit_names()[_i]);
    }
    for (var _i = 0; _i < LOD_LUSTRE_N; _i++) {
        lod_st_ok(_r, _lustre_seen[_i] == 1, "lustre never reached: " + lod_lustre_names()[_i]);
    }
    for (var _i = 0; _i < LOD_ZONING_N; _i++) {
        lod_st_ok(_r, _zone_seen[_i] == 1, "zoning never reached: " + lod_zoning_names()[_i]);
    }
    for (var _i = 0; _i < LOD_CUT_N; _i++) {
        lod_st_ok(_r, _cut_seen[_i] == 1, "cut never reached: " + lod_cut_names()[_i]);
    }
    for (var _i = 0; _i < LOD_MATRIX_N; _i++) {
        lod_st_ok(_r, _mat_seen[_i] == 1, "matrix never reached: " + lod_matrix_names()[_i]);
    }

    // -- STAGE 2: EVERY HABIT DRAWS SOMETHING, AND STANDS ON THE BEDDING PLANE ------------------
    // ⛔ THE SWITCH IN lod_habit_parts IS EXHAUSTIVE AND THIS IS WHAT PROVES IT. A habit that fell
    // through to the default returns an EMPTY list and would draw a blank cell - which on a store
    // sheet reads as a layout gap rather than as a missing feature.
    global.lod_stage = 2;
    var _parts_total = 0;
    for (var _hb = 0; _hb < LOD_HABIT_N; _hb++) {
        var _p = lod_habit_parts(_hb, 12345 + _hb * 77, 0.60, 0.36);
        var _n = array_length(_p);
        _parts_total += _n;
        lod_st_ok(_r, _n > 0, "habit draws nothing: " + lod_habit_names()[_hb]);
        if (_n == 0) continue;
        var _bb = lod_render_bounds(_p);
        // Stands on the bedding plane. The tolerance is generous downward because a contact shadow
        // and a rind legitimately overhang it, and tight upward because a floating crystal is a
        // defect a buyer sees immediately.
        lod_st_ok(_r, _bb[3] >= LOD_GROUND - 0.02,
                  "habit floats: " + lod_habit_names()[_hb] + " bottom " + string_format(_bb[3], 1, 3));
        lod_st_ok(_r, _bb[1] < LOD_GROUND,
                  "habit has no height: " + lod_habit_names()[_hb]);
        // Inside the unit box, with the margin the renderer needs for stroke width.
        lod_st_ok(_r, _bb[0] > -0.62 && _bb[2] < 0.62,
                  "habit overflows the unit box: " + lod_habit_names()[_hb]
                  + " x " + string_format(_bb[0], 1, 3) + ".." + string_format(_bb[2], 1, 3));
    }
    // VACUITY GUARD. Every assertion above is inside a loop over the habit table; if that table
    // were empty the whole stage would pass over nothing (CLAUDE.md §2b: a strict check over an
    // empty set passes vacuously - `[].every()` is true).
    lod_st_ok(_r, _parts_total > 400,
              "VACUITY GUARD: the 21 habits emitted only " + string(_parts_total) + " parts");

    // -- STAGE 3: THE DERIVED BODY OUTLINE ------------------------------------------------------
    // The hull is what every zoning program clips to. If it were degenerate, every band in the
    // product would silently draw nothing - a defect that suppresses its own output, which this
    // wing has shipped before and which hides every defect behind it (CLAUDE.md, Welkin).
    global.lod_stage = 3;
    var _hull_pts = 0;
    for (var _hb = 0; _hb < LOD_HABIT_N; _hb++) {
        var _p = lod_habit_parts(_hb, 555 + _hb, 0.60, 0.36);
        var _body = lod_body_of(_p);
        var _hn = array_length(_body);
        _hull_pts += _hn;
        lod_st_ok(_r, _hn >= 3, "hull degenerate for habit " + lod_habit_names()[_hb]);
        if (_hn < 3) continue;
        // A hull is convex by construction, so it is simple by construction - which makes
        // lod_is_simple a STRUCTURAL assertion here rather than a measured one. Say so, and assert
        // the thing that is genuinely measured instead: that a mid-height span exists.
        var _bb2 = lod_pts_bounds(_body);
        var _mid = (_bb2[1] + _bb2[3]) * 0.5;
        var _sp2 = lod_span_at_y(_body, _mid);
        lod_st_ok(_r, !is_undefined(_sp2), "hull has no span at mid height: " + lod_habit_names()[_hb]);
        if (!is_undefined(_sp2)) {
            lod_st_ok(_r, _sp2[1] - _sp2[0] > 0.02,
                      "hull is a sliver at mid height: " + lod_habit_names()[_hb]);
        }
    }
    lod_st_ok(_r, _hull_pts > 60, "VACUITY GUARD: hulls totalled " + string(_hull_pts) + " points");

    // -- STAGE 4: THE RAMP -----------------------------------------------------------------------
    // ⛔ A CLAMPED RAMP SILENTLY COLLAPSES (CLAUDE.md, Hearth): limewash put its top two stops above
    // the ceiling, both clamped to the same value, and a bevel whose two brightest walls are
    // identical reads as a flat fill with a line round it. Every species is checked, wet and dry.
    global.lod_stage = 4;
    var _ramp_checked = 0;
    for (var _i = 0; _i < LOD_SPECIES_N; _i++) {
        var _sp = _c[_i];
        for (var _w = 0; _w <= 1; _w++) {
            var _ramp = lod_mat_ramp(_sp, _w);
            lod_st_ok(_r, array_length(_ramp) == LOD_RAMP_N, _sp.name + ": ramp has the wrong number of stops");
            var _dup = false;
            for (var _k = 0; _k < LOD_RAMP_N - 1; _k++) {
                if (_ramp[_k] == _ramp[_k + 1]) _dup = true;
            }
            lod_st_ok(_r, !_dup, _sp.name + ": two adjacent ramp stops are the same colour (wet=" + string(_w) + ")");
            _ramp_checked++;
        }
        // The ink must be readable on its own material.
        lod_st_ok(_r, lod_mat_ink_sep(_sp) > 0.20,
                  _sp.name + ": ink sits only " + string_format(lod_mat_ink_sep(_sp), 1, 3) + " from its ground");
        // The host rock must be separable from the mineral standing on it.
        var _rr = lod_rock_ramp(_sp, _sp.matrix);
        var _clash = false;
        for (var _k = 0; _k < LOD_RAMP_N; _k++) {
            if (_rr[_k] == lod_mat_ramp(_sp, 0)[2]) _clash = true;
        }
        lod_st_ok(_r, !_clash, _sp.name + ": its host rock renders the same colour as the mineral");
    }
    lod_st_ok(_r, _ramp_checked == LOD_SPECIES_N * 2,
              "VACUITY GUARD: checked " + string(_ramp_checked) + " ramps, expected " + string(LOD_SPECIES_N * 2));

    // -- STAGE 5: WETTING GOES THE RIGHT WAY -----------------------------------------------------
    // A wet stone is DARKER overall and has a WIDER span - it reflects specularly instead of
    // scattering. A version that merely brightened would be a plausible wrong answer, so the
    // direction is asserted rather than assumed.
    global.lod_stage = 5;
    var _wetter = 0;
    for (var _i = 0; _i < LOD_SPECIES_N; _i++) {
        var _dry = _lod_mat_base_wet(_c[_i], 0);
        var _wet = _lod_mat_base_wet(_c[_i], 1);
        lod_st_ok(_r, _wet.L < _dry.L - LOD_ST_EPS, _c[_i].name + ": wetting did not darken it");
        lod_st_ok(_r, _wet.C >= _dry.C, _c[_i].name + ": wetting reduced its chroma");
        _wetter++;
    }
    lod_st_ok(_r, _wetter == LOD_SPECIES_N, "VACUITY GUARD: wetting checked " + string(_wetter) + " species");

    // -- STAGE 6: HUE BLENDING IS CHROMA-WEIGHTED ------------------------------------------------
    // ⛔ ARMOURY DROVE RUSTING STEEL THROUGH MAGENTA on twelve swords because it swept the hue of a
    // colour that has no chroma. The assertion that missed it named the failure it expected
    // ("not in the GREEN band") and was silent about the one standing next to it, so this one is
    // written as a PROPERTY: a near-colourless source adopts the target's hue almost at once.
    global.lod_stage = 6;
    var _w_low = lod_hue_weight(0.006, 0.140, 0.5);
    var _w_even = lod_hue_weight(0.100, 0.100, 0.5);
    lod_st_ok(_r, _w_low > 0.90, "hue weight: a colourless source should adopt the target at once, got "
              + string_format(_w_low, 1, 3));
    lod_st_ok(_r, abs(_w_even - 0.5) < 0.01, "hue weight: two equal chromas should blend evenly, got "
              + string_format(_w_even, 1, 3));
    // And the rotation takes the short way round without wrapping past 180.
    lod_st_ok(_r, abs(lod_hue_lerp(350, 10, 0.5) - 360) < 0.01,
              "hue lerp: 350 to 10 should pass through 360, got " + string_format(lod_hue_lerp(350, 10, 0.5), 1, 3));

    // -- STAGE 7: THE CUTS -----------------------------------------------------------------------
    // ⛔ EVERY GIRDLE OUTLINE MUST BE SIMPLE. Total turning is the cheap test and it is NOT a
    // complete one - a polygon with one crossed-over flap still accumulates exactly one revolution
    // (CLAUDE.md, Livery, measured by sabotage: the turning assertion fired on 1 of 6 broken
    // shapes). lod_is_simple is the definitive test and it is what is used here.
    global.lod_stage = 7;
    var _cut_pts = 0;
    for (var _ct = 0; _ct < LOD_CUT_N; _ct++) {
        var _g = lod_cut_girdle(_ct, 0.40);
        var _gn = array_length(_g);
        _cut_pts += _gn;
        lod_st_ok(_r, _gn >= 3, "cut girdle degenerate: " + lod_cut_names()[_ct]);
        if (_gn < 3) continue;
        lod_st_ok(_r, lod_is_simple(_g), "cut girdle self-intersects: " + lod_cut_names()[_ct]);
        // ⚠️ lod_turning RETURNS REVOLUTIONS, NOT RADIANS - it divides by LOD_TAU on its last line.
        // The first version of this assertion compared against LOD_TAU and went RED on all ten
        // girdles, every one of which was correct. A FALSE RED COSTS EXACTLY WHAT A FALSE GREEN
        // DOES: acting on it would have meant reshaping ten correct outlines until a broken
        // instrument agreed with them, which is the same trap the function's own header records
        // about its dedupe. READ THE UNITS OF ANYTHING YOU ASSERT AGAINST.
        lod_st_ok(_r, abs(abs(lod_turning(_g)) - 1.0) < 0.03,
                  "cut girdle does not turn once: " + lod_cut_names()[_ct]
                  + " turning " + string_format(lod_turning(_g), 1, 3));
        var _gb = lod_pts_bounds(_g);
        lod_st_ok(_r, _gb[0] > -0.45 && _gb[2] < 0.45 && _gb[1] > -0.45 && _gb[3] < 0.45,
                  "cut girdle overflows its radius: " + lod_cut_names()[_ct]);
        // ⛔ A CUT STONE IS NOT BEDDED. It is centred, and lod_habit's forms stand on LOD_GROUND -
        // asserting the difference is what stops the two layouts quietly converging.
        lod_st_ok(_r, _gb[3] < LOD_GROUND - 0.02,
                  "cut stone is sitting on the bedding plane: " + lod_cut_names()[_ct]);
    }
    lod_st_ok(_r, _cut_pts > 80, "VACUITY GUARD: girdles totalled " + string(_cut_pts) + " points");

    // Every cuttable species produces a stone with geometry in it.
    var _cuttable = 0, _cut_parts = 0;
    for (var _i = 0; _i < LOD_SPECIES_N; _i++) {
        if (!lod_is_cuttable(_c[_i])) continue;
        _cuttable++;
        var _cp = lod_cut_parts(_c[_i], 900 + _i, 0.40);
        _cut_parts += array_length(_cp);
        lod_st_ok(_r, array_length(_cp) > 3, _c[_i].name + ": its cut stone is nearly empty");
    }
    lod_st_ok(_r, _cuttable >= 20, "VACUITY GUARD: only " + string(_cuttable) + " species are cuttable");
    lod_st_ok(_r, _cut_parts > 300, "VACUITY GUARD: cut stones emitted " + string(_cut_parts) + " parts");

    // -- STAGE 8: ZONING DRAWS INSIDE THE STONE --------------------------------------------------
    // The whole point of clipping to the span at each y rather than to the bounding box. A band
    // that overhangs is invisible at corpus scale and is whiskers at hero scale.
    global.lod_stage = 8;
    var _zoned_parts = 0, _zoning_ran = 0;
    for (var _zn = 1; _zn < LOD_ZONING_N; _zn++) {
        // Run every zoning program against a solid habit, so the hull is a fair body.
        var _hp = lod_habit_parts(0, 4242 + _zn, 0.60, 0.36);
        var _body = lod_body_of(_hp);
        var _bb3 = lod_pts_bounds(_body);
        var _zp = lod_zoning_parts(_zn, 4242 + _zn, _hp);
        _zoned_parts += array_length(_zp);
        lod_st_ok(_r, array_length(_zp) > 0, "zoning draws nothing: " + lod_zoning_names()[_zn]);
        if (array_length(_zp) == 0) continue;
        _zoning_ran++;
        var _zb = lod_render_bounds(_zp);
        // Inside the body's own box, with a small allowance for stroke width.
        lod_st_ok(_r, _zb[0] > _bb3[0] - 0.03 && _zb[2] < _bb3[2] + 0.03,
                  "zoning overhangs the stone: " + lod_zoning_names()[_zn]
                  + " x " + string_format(_zb[0], 1, 3) + ".." + string_format(_zb[2], 1, 3)
                  + " body " + string_format(_bb3[0], 1, 3) + ".." + string_format(_bb3[2], 1, 3));
        lod_st_ok(_r, _zb[1] > _bb3[1] - 0.03 && _zb[3] < _bb3[3] + 0.03,
                  "zoning overhangs the stone vertically: " + lod_zoning_names()[_zn]);

        // ⛔⛔ THE BOUNDING-BOX CHECK ABOVE CANNOT SEE A PER-ROW OVERHANG, WHICH IS THE ONLY KIND
        // THIS PRODUCT CAN ACTUALLY HAVE. A band is clipped to the body's span at its OWN y; if
        // that clip were wrong the marks would still sit inside the body's overall box and every
        // assertion here would stay green while the stone had stripes hanging off it.
        //
        // ⭐ This is the assertion that settles it, and it exists because I could not decide from
        // LOOKING at the baked sheet whether the bands overhung or not. A picture that two readings
        // disagree about is a picture to MEASURE, not to squint at - and the measurement is cheap:
        // every point of every zoning part, against the span at that point's own height.
        var _pts_checked = 0, _worst = 0;
        var _zpts = lod_parts_points(_zp);
        for (var _q = 0; _q < array_length(_zpts); _q++) {
            var _px = _zpts[_q][0], _py = _zpts[_q][1];
            var _spn = lod_span_at_y(_body, _py);
            if (is_undefined(_spn)) continue;   // above or below the body: the bbox test owns that
            _pts_checked++;
            var _over = max(_spn[0] - _px, _px - _spn[1]);
            if (_over > _worst) _worst = _over;
        }
        lod_st_ok(_r, _worst < 0.015,
                  "zoning hangs off the stone: " + lod_zoning_names()[_zn]
                  + " worst overhang " + string_format(_worst, 1, 4) + " unit-box");
        // ⚠️ FOUR, NOT SIX. asterism is THREE crossing lines and therefore contributes exactly
        // six points - the guard was set above its own smallest legitimate case and fired on a
        // correct program. A vacuity guard that goes red on healthy input is a false red and costs
        // exactly what a false green does.
        lod_st_ok(_r, _pts_checked >= 4,
                  "VACUITY GUARD: only " + string(_pts_checked) + " zoning points were span-checked for "
                  + lod_zoning_names()[_zn]);
    }
    lod_st_ok(_r, _zoning_ran == LOD_ZONING_N - 1,
              "VACUITY GUARD: " + string(_zoning_ran) + " of " + string(LOD_ZONING_N - 1) + " zoning programs ran");
    lod_st_ok(_r, _zoned_parts > 40, "VACUITY GUARD: zoning emitted " + string(_zoned_parts) + " parts");

    // ⛔⛔ THE DECLARED OPENNESS TABLE IS PROVEN HERE, PER HABIT, BY NAME.
    //
    // lod_habit_open() routes the area-filling zoning programs away from habits whose convex hull
    // spans empty space - the defect that baked tourmaline as a box, wavellite as a hexagon and
    // vivianite as a slab. It is a DECLARED table because the two cheap measured versions were both
    // wrong (see its header), so the expensive honest measure lives here and checks it.
    //
    // ⭐ THIS IS THE ASSERTION THAT MATTERS MOST IN THE SUITE. A declared table with no check is
    // exactly the shared-fact-with-two-declarations trap; this makes the second declaration
    // impossible to get wrong silently, and it fails naming the habit and printing the coverage.
    var _open = lod_habit_open();
    lod_st_ok(_r, array_length(_open) == LOD_HABIT_N,
              "lod_habit_open has " + string(array_length(_open)) + " entries for "
              + string(LOD_HABIT_N) + " habits");
    var _nopen = 0, _nclosed = 0;
    for (var _hb2 = 0; _hb2 < LOD_HABIT_N; _hb2++) {
        var _hp2 = lod_habit_parts(_hb2, 31337, 0.60, 0.36);
        var _cov = lod_hull_coverage(_hp2, 20);
        var _declared = _open[_hb2];
        var _measured = (_cov < LOD_SPIKY_FLOOR);
        lod_st_ok(_r, _declared == _measured,
                  "habit " + lod_habit_names()[_hb2] + " is declared "
                  + (_declared ? "OPEN" : "CLOSED") + " but covers "
                  + string_format(_cov, 1, 3) + " of its hull (floor "
                  + string_format(LOD_SPIKY_FLOOR, 1, 2) + ")");
        if (_declared) _nopen++; else _nclosed++;
    }
    // VACUITY GUARD, both ways: a table that was all-false or all-true would satisfy nothing above
    // in one direction and would silently disable or universally apply the gate.
    lod_st_ok(_r, _nopen >= 4, "VACUITY GUARD: only " + string(_nopen) + " habits are declared OPEN");
    lod_st_ok(_r, _nclosed >= 10, "VACUITY GUARD: only " + string(_nclosed) + " habits are declared CLOSED");

    // And the gate must actually route on that table, in both directions.
    var _spiky = lod_habit_parts(1, 31337, 0.60, 0.36);    // acicular - declared OPEN
    var _solid = lod_habit_parts(9, 31337, 0.60, 0.36);    // cubic    - declared CLOSED
    var _zs = lod_zoning_parts(2, 31337, _spiky, 1);
    var _zd = lod_zoning_parts(2, 31337, _solid, 9);
    var _zi = lod_zoning_parts(4, 31337, _spiky, 1);
    lod_st_ok(_r, array_length(_zs) == array_length(_zi),
              "the open-body gate did not fall back to included: got " + string(array_length(_zs))
              + " parts, included gives " + string(array_length(_zi)));
    lod_st_ok(_r, array_length(_zd) != array_length(_zi),
              "the open-body gate fired on a CLOSED body - every banded stone would lose its bands");
    // ⚠️ AND A CUT STONE PASSES NO HABIT AT ALL, which must mean CLOSED rather than OPEN: a girdle
    // is convex by construction. Asserted because "undefined" defaulting the wrong way would strip
    // the zoning from every faceted stone in the product, silently.
    lod_st_ok(_r, array_length(lod_zoning_parts(2, 31337, _solid)) == array_length(_zd),
              "a body with no habit was treated as OPEN - every cut stone would lose its zoning");

    // -- STAGE 9: THE WHOLE SPECIMEN, EVERY SPECIES, EVERY STATE ---------------------------------
    global.lod_stage = 9;
    var _spec_parts = 0, _states_run = 0;
    for (var _i = 0; _i < LOD_SPECIES_N; _i++) {
        for (var _st = 0; _st <= 3; _st++) {
            var _stone = lod_specimen(_i, 1000 + _i * 13 + _st, _st);
            // A species that cannot be cut clamps to state 1 - the honest answer.
            if (!lod_is_cuttable(_c[_i]) && _st > 1) {
                lod_st_ok(_r, _stone.state == 1, _c[_i].name + ": an uncuttable species reached state " + string(_stone.state));
            }
            var _p = lod_specimen_parts(_stone);
            _spec_parts += array_length(_p);
            _states_run++;
            lod_st_ok(_r, array_length(_p) > 2,
                      _c[_i].name + " state " + string(_st) + ": specimen is nearly empty");
            var _pal = lod_specimen_pal(_stone);
            lod_st_ok(_r, variable_struct_exists(_pal, "s2") && variable_struct_exists(_pal, "r2"),
                      _c[_i].name + ": palette is missing a material");
            // ⛔ EVERY ROLE A PART ASKS FOR MUST EXIST IN THE PALETTE. lod_render_colour falls back
            // to `line` for an unknown role, silently, so a typo in a role name draws a grey mark
            // exactly where a coloured one belongs and nothing anywhere reports it.
            var _roles = lod_roles_used(_p);
            for (var _k = 0; _k < array_length(_roles); _k++) {
                lod_st_ok(_r, variable_struct_exists(_pal, _roles[_k]),
                          _c[_i].name + " state " + string(_st) + ": role \"" + string(_roles[_k]) + "\" is not in the palette");
            }
        }
    }
    lod_st_ok(_r, _states_run == LOD_SPECIES_N * 4,
              "VACUITY GUARD: ran " + string(_states_run) + " specimen states, expected " + string(LOD_SPECIES_N * 4));
    lod_st_ok(_r, _spec_parts > 4000, "VACUITY GUARD: specimens emitted " + string(_spec_parts) + " parts");

    // -- STAGE 10: DETERMINISM -------------------------------------------------------------------
    // ⛔ THE SAME (species, seed) MUST ALWAYS DRAW THE SAME STONE, because a save file stores those
    // two integers and nothing else. This wing has already paid for a generator whose state did not
    // stay with the generator, and nothing in a JS preview could have caught it.
    global.lod_stage = 10;
    var _det = 0;
    for (var _i = 0; _i < LOD_SPECIES_N; _i += 5) {
        var _a = lod_specimen_parts(lod_specimen(_i, 7777, 0));
        var _b = lod_specimen_parts(lod_specimen(_i, 7777, 0));
        lod_st_ok(_r, array_length(_a) == array_length(_b),
                  _c[_i].name + ": two builds of the same seed differ in part count");
        // ⛔ SIGNATURE, NOT BOUNDS. The first version of this stage compared bounding boxes and went
        // RED on Electrum, whose picture was changing correctly: `dendritic` has a fixed first
        // branch and sits on a rock block of fixed width and base, so three of its four bounds
        // CANNOT move whatever the seed does. A bounding box answers "how big", never "which
        // shape". lod_parts_signature walks every coordinate.
        var _sa = lod_parts_signature(_a), _sb = lod_parts_signature(_b);
        lod_st_ok(_r, abs(_sa - _sb) < LOD_ST_EPS,
                  _c[_i].name + ": two builds of the same seed drew different geometry");
        // And a DIFFERENT seed must actually change the stone, or the seed is decorative.
        var _d = lod_specimen_parts(lod_specimen(_i, 8888, 0));
        lod_st_ok(_r, abs(_sa - lod_parts_signature(_d)) > LOD_ST_EPS,
                  _c[_i].name + ": changing the seed did not change the stone");
        _det++;
    }
    lod_st_ok(_r, _det >= 8, "VACUITY GUARD: determinism checked " + string(_det) + " species");

    // -- STAGE 11: THE ASSAY SYSTEM --------------------------------------------------------------
    global.lod_stage = 11;
    // A better kit must never return a LONGER shortlist than a worse one for the same stone.
    var _narrowed = 0, _assays = 0;
    for (var _i = 0; _i < LOD_SPECIES_N; _i += 3) {
        var _stone = lod_specimen(_i, 4000 + _i, 1);
        var _bad = lod_assay(_stone, 0.1);
        var _good = lod_assay(_stone, 0.95);
        _assays += 2;
        lod_st_ok(_r, array_length(_good.candidates) <= array_length(_bad.candidates),
                  _c[_i].name + ": a better assay returned MORE candidates ("
                  + string(array_length(_good.candidates)) + " vs " + string(array_length(_bad.candidates)) + ")");
        // A good assay must include the true species. An assay that can exclude the right answer
        // is not an assay, it is a lie.
        var _has = false;
        for (var _k = 0; _k < array_length(_good.candidates); _k++) {
            if (_good.candidates[_k] == _i) _has = true;
        }
        lod_st_ok(_r, _has, _c[_i].name + ": a 0.95-skill assay excluded the true species");
        if (array_length(_good.candidates) < array_length(_bad.candidates)) _narrowed++;
    }
    // VACUITY GUARD, and it is the one that matters here: if the shortlist never narrowed, the
    // "<=" assertion above would be satisfied by a function that ignores skill entirely.
    lod_st_ok(_r, _narrowed > 0,
              "VACUITY GUARD: skill never narrowed a shortlist in " + string(_assays) + " assays");

    // Cutting: a soft tool must never cut a hard stone, and a hard tool usually must.
    var _skate = 0, _cuts = 0, _shatter = 0;
    for (var _i = 0; _i < LOD_SPECIES_N; _i++) {
        if (!lod_is_cuttable(_c[_i])) continue;
        var _stone2 = lod_specimen(_i, 6000 + _i, 1);
        lod_st_ok(_r, lod_cut_outcome(_stone2, 1.0, 0.9, 11) == 0,
                  _c[_i].name + ": a hardness-1 tool cut it");
        var _o = lod_cut_outcome(_stone2, 10.0, 0.95, 12);
        if (_o == 0) _skate++;
        if (_o == 1) _cuts++;
        if (_o == 2) _shatter++;
    }
    lod_st_ok(_r, _skate == 0, "a hardness-10 tool skated off " + string(_skate) + " cuttable stones");
    lod_st_ok(_r, _cuts > 0, "VACUITY GUARD: a hardness-10 tool cut " + string(_cuts) + " stones");
    // An uncuttable species must always report 0, never a shatter.
    var _uncut_ok = true;
    for (var _i = 0; _i < LOD_SPECIES_N; _i++) {
        if (lod_is_cuttable(_c[_i])) continue;
        if (lod_cut_outcome(lod_specimen(_i, 1, 1), 10.0, 0.9, 3) != 0) _uncut_ok = false;
    }
    lod_st_ok(_r, _uncut_ok, "an uncuttable species returned a cut outcome");

    // Value must rise with work, for every species.
    for (var _i = 0; _i < LOD_SPECIES_N; _i++) {
        var _rough = lod_value(lod_specimen(_i, 1, 0));
        var _out2 = lod_value(lod_specimen(_i, 1, 1));
        lod_st_ok(_r, _out2 > _rough, _c[_i].name + ": extracting it did not raise its value");
        if (lod_is_cuttable(_c[_i])) {
            var _polished = lod_value(lod_specimen(_i, 1, 3));
            lod_st_ok(_r, _polished > _out2, _c[_i].name + ": polishing did not raise its value");
        }
    }

    // Prospecting: both outcomes must be reachable, and a species must only appear near its band.
    var _found = 0, _empty = 0, _wrong_band = 0;
    for (var _d = 0; _d <= 10; _d++) {
        var _depth = _d / 10;
        for (var _t = 0; _t < 40; _t++) {
            var _got = lod_prospect(_depth, _d * 1000 + _t);
            if (_got < 0) { _empty++; continue; }
            _found++;
            if (lod_spawn_weight(_got, _depth) <= 0) _wrong_band++;
        }
    }
    lod_st_ok(_r, _found > 0, "VACUITY GUARD: prospecting never found anything in 440 pans");
    lod_st_ok(_r, _empty > 0, "prospecting always found something - an empty pan must be possible");
    lod_st_ok(_r, _wrong_band == 0, string(_wrong_band) + " pans returned a species with zero weight at that depth");

    // The cabinet.
    var _cab = lod_cabinet_new();
    lod_st_ok(_r, abs(lod_cabinet_completion(_cab)) < LOD_ST_EPS, "a new cabinet is not empty");
    lod_st_ok(_r, array_length(lod_cabinet_missing(_cab)) == LOD_SPECIES_N, "a new cabinet is not missing everything");
    lod_st_ok(_r, lod_cabinet_add(_cab, lod_specimen(0, 1, 1)), "adding to an empty cabinet did not register");
    lod_st_ok(_r, !lod_cabinet_add(_cab, lod_specimen(0, 2, 0)),
              "a WORSE specimen of a species already held counted as progress");
    lod_st_ok(_r, lod_cabinet_completion(_cab) > 0, "the cabinet did not advance after a real addition");
    lod_st_ok(_r, _cab.found == 1, "the cabinet's found count is " + string(_cab.found) + ", expected 1");

    // -- STAGE 12: TEXT IS ASCII -----------------------------------------------------------------
    // ⛔ THE SHIPPED FONTS DECLARE 32..126 AND A MISSING GLYPH DRAWS NOTHING AT ALL - no error, no
    // warning, no missing-glyph box, just absence, which reads as a deliberate space. This wing
    // shipped a COVER reading "40 THEMES  DRAWN IN GML" because a middle dot is U+00B7.
    global.lod_stage = 12;
    var _texts = [];
    for (var _i = 0; _i < LOD_SPECIES_N; _i++) {
        array_push(_texts, _c[_i].name, _c[_i].family);
        for (var _st = 0; _st <= 3; _st++) {
            var _stn = lod_specimen(_i, 1, _st);
            array_push(_texts, lod_specimen_label(_stn), lod_specimen_line(_stn));
        }
    }
    var _tables = [lod_habit_names(), lod_lustre_names(), lod_zoning_names(),
                   lod_cut_names(), lod_matrix_names(), lod_band_names()];
    for (var _i = 0; _i < array_length(_tables); _i++) {
        for (var _k = 0; _k < array_length(_tables[_i]); _k++) array_push(_texts, _tables[_i][_k]);
    }
    var _scanned = 0;
    for (var _i = 0; _i < array_length(_texts); _i++) {
        var _txt = string(_texts[_i]);
        _scanned += string_length(_txt);
        var _bad2 = -1;
        for (var _ch = 1; _ch <= string_length(_txt); _ch++) {
            var _o2 = ord(string_char_at(_txt, _ch));
            if (_o2 < 32 || _o2 > 126) { _bad2 = _o2; break; }
        }
        lod_st_ok(_r, _bad2 == -1, "non-ASCII character " + string(_bad2) + " in: " + _txt);
    }
    lod_st_ok(_r, _scanned > 3000, "VACUITY GUARD: the ASCII scan read " + string(_scanned) + " characters");

    // ⛔ STAGE 99 MEANS "THE SUITE REACHED THE END". Every stage above sets global.lod_stage on the
    // way past, and the crash handler writes whatever it was last set to - so a suite that dies in
    // stage 7 records 7. Without a terminal marker, a run that crashed after its last assertion
    // would write a result file full of passes and no failures, which is indistinguishable from
    // success by every number in it. The runner REQUIRES 99 and fails the run otherwise.
    global.lod_stage = 99;
    return _r;
}

/// ============================================================================================
/// THE RESULT FILE
///
/// ⛔ file_text_open_write IS THE ONLY ROUTE THAT SURVIVES A RELEASE BUILD. Measured by this wing:
/// show_debug_message with -debugoutput yields a file holding only engine boot lines, and
/// game_end(n)'s argument is NOT propagated to the process exit code. This writes to
/// %LOCALAPPDATA%/Lode/ and needs no runner flag at all.
/// ============================================================================================

/// The TRUE HULL COVERAGE of every habit, as a JSON array, for the result file.
///
/// ⭐ A REPORTED MEASUREMENT, NOT AN ASSERTION, AND IT EARNS ITS PLACE. LOD_SPIKY_FLOOR has to sit
/// in the gap between the solid habits and the spiky ones, and a threshold nobody can see the
/// distribution behind is a number somebody will "tidy" later. Printing all twenty-one means the
/// next person to touch it can check the gap is still there in one glance at a file they already
/// have. This wing's own law: a sheet that prints its own numbers is a better instrument than the
/// suite, because the suite only asserts what somebody thought to ask.
/// ⚠️ EMITTED AS ONE FLAT STRING, NOT A NESTED ARRAY, AND THAT IS A DEFECT THIS RUN PAID FOR.
/// The result file is scraped by Internal_Ops/run_selftest.ps1 with a regex that matches up to the
/// first closing brace, so a nested object array truncated the JSON mid-way and ConvertFrom-Json
/// threw - on a run whose suite was entirely GREEN (4675 pass, 0 fail, stage 99). A reporting field
/// that breaks the reader of the field beside it is worse than no reporting field.
function lod_selftest_ratios() {
    var _s = "";
    for (var _i = 0; _i < LOD_HABIT_N; _i++) {
        if (_i > 0) _s += " | ";
        var _p = lod_habit_parts(_i, 31337, 0.60, 0.36);
        _s += lod_habit_names()[_i] + " " + string_format(lod_hull_coverage(_p, 20), 1, 3);
    }
    return _s;
}

function lod_selftest_write(_r) {
    var _f = file_text_open_write("lod_selftest.json");
    var _notes = "";
    for (var _i = 0; _i < array_length(_r.notes); _i++) {
        if (_i > 0) _notes += " | ";
        _notes += string_replace_all(string(_r.notes[_i]), "\"", "'");
    }
    file_text_write_string(_f,
        "{\"pass\":" + string(_r.pass)
        + ",\"fail\":" + string(_r.fail)
        + ",\"stage\":" + string(global.lod_stage)
        + ",\"epsilon\":" + string_format(math_get_epsilon(), 1, 12)
        + ",\"species\":" + string(LOD_SPECIES_N)
        + ",\"spikyFloor\":" + string_format(LOD_SPIKY_FLOOR, 1, 3)
        + ",\"inkRatios\":\"" + lod_selftest_ratios() + "\""
        + ",\"version\":\"" + LOD_VERSION + "\""
        + ",\"notes\":\"" + _notes + "\"}");
    file_text_close(_f);
}
