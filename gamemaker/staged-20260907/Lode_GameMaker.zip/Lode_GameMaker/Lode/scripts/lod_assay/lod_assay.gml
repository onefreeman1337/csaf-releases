/// LODE - lod_assay. Prospecting, assay, cutting, and what a stone is worth.
///
/// ============================================================================================
/// THIS IS THE HALF THAT MAKES IT A SYSTEM RATHER THAN AN ART GENERATOR.
///
/// A pack of pretty crystals is a picture library. What a buyer is actually short of is the LOOP:
/// where does ore appear, what can the player learn about it before committing a tool to it, what
/// happens when they cut it wrong, and what is it worth. All of that is here, and every function
/// in this file is PURE - no draw calls, no instance variables, no room state.
///
/// ⛔ THAT PURITY IS A VERIFICATION DECISION, NOT A STYLE ONE. GML cannot be unit-tested outside
/// the engine: there is no -batchmode, no Node-mockable core, and the wing's own constitution says
/// so plainly rather than pretending otherwise. The compensation is to push as much logic as
/// possible into functions with no engine calls, so lod_selftest can assert them exhaustively on a
/// real Igor-built executable. Everything below is checked over the whole corpus, not sampled.
///
/// -- THE PHYSICS IS REAL AND THAT IS THE PRODUCT'S ARGUMENT ----------------------------------
/// Density separates gold (19.3) from pyrite (5.0) and it is the assay a medieval prospector could
/// actually perform. Mohs hardness decides whether a tool bites or skates. Both numbers are in the
/// corpus because they are true, not because they were needed for a formula - which is why the
/// systems built on them behave sensibly for species nobody tuned.
/// ============================================================================================

/// ⚠️ TOLERANCE FLOOR. GML applies a default epsilon of 0.00001 to numeric comparisons, so any
/// tolerance at or below it can never fire in either direction - a distinctness check written that
/// way passes vacuously forever and an equality check goes red on two values that are the same
/// object. Never write one. This is the package's one comparison tolerance and it is well clear.
#macro LOD_EPS 0.0001

/// How likely this species is to turn up at this depth, 0..1.
///
/// Two independent terms: the species' own rarity, and how far the depth is from the band it
/// forms in. A species is not merely rarer with depth - it is ABSENT outside its band, which is
/// the whole reason a player learns to dig in the right place.
///
/// _depth is 0..1 from surface to deepest.
function lod_spawn_weight(_species, _depth) {
    var _sp = lod_species(_species);
    var _want = _sp.band / max(1, LOD_BAND_N - 1);
    var _d = abs(_depth - _want);
    // A band is about a fifth of the column wide, with soft edges - real ore zones overlap.
    var _band_fit = max(0, 1 - power(_d / 0.28, 2));
    return (1 - _sp.rarity * 0.92) * _band_fit;
}

/// Pick a species at a depth. Returns an index, or -1 if this depth yields nothing at all.
///
/// ⚠️ IT CAN RETURN -1 AND CALLERS MUST HANDLE IT. A prospecting system that always finds
/// something is a vending machine; the possibility of an empty pan is what makes a strike mean
/// anything. lod_selftest asserts that both outcomes are reachable over the corpus.
function lod_prospect(_depth, _seed) {
    /// Refuses with -1, which is the value this function ALREADY documents as "an empty pan" and
    /// which the Readme tells every caller to handle. Inventing a second refusal value would be a
    /// second thing for a buyer to check, and the one they check for is this one.
    if (!is_numeric(_depth) || !is_numeric(_seed)) return -1;
    var _rng = lod_rng(_seed + 22697);
    var _total = 0;
    var _n = LOD_SPECIES_N;
    for (var _i = 0; _i < _n; _i++) _total += lod_spawn_weight(_i, _depth);
    if (_total <= LOD_EPS) return -1;
    // The barren fraction: a pan that yields nothing. Scaled so rich bands are usually productive
    // and the deepest and shallowest reaches usually are not.
    var _barren = 0.30;
    if (lod_rng_next(_rng) < _barren) return -1;
    var _pick = lod_rng_next(_rng) * _total;
    var _acc = 0;
    for (var _i = 0; _i < _n; _i++) {
        _acc += lod_spawn_weight(_i, _depth);
        if (_pick <= _acc) return _i;
    }
    return _n - 1;
}

/// What an assay tells the player, at a given skill 0..1.
///
/// ⛔ THE READINGS ARE WRONG ON PURPOSE, AND THE ERROR IS DETERMINISTIC IN THE STONE. A reading
/// that re-rolls its noise every time it is displayed lets a player scrub the same rock until the
/// number they want appears, which destroys the whole mechanic. Seeding the error from the stone
/// means an unskilled assay is consistently wrong, which is what makes buying a better assay kit
/// feel like buying knowledge.
///
/// Returns a struct: density and hardness as READ, plus `confidence` and the shortlist size.
function lod_assay(_stone, _skill) {
    /// Refuses with undefined. An assay is a READING, so inventing one would put a hardness and a
    /// density in front of the player as though they had been measured - the plausible-wrong-answer
    /// failure, which is worse here than anywhere else in the package because the whole product
    /// claims the picture and the physics are the same row.
    if (!lod_is_stone(_stone)) return undefined;
    if (!is_numeric(_skill)) return undefined;
    var _sp = _stone.sp;
    var _sk = clamp(_skill, 0, 1);
    var _rng = lod_rng(_stone.seed + _stone.species * 131 + 5011);
    var _err = (1 - _sk) * 0.35;
    var _d = _sp.density * (1 + (lod_rng_next(_rng) - 0.5) * 2 * _err);
    var _h = _sp.hardness * (1 + (lod_rng_next(_rng) - 0.5) * 2 * _err * 0.6);
    return {
        density: _d,
        hardness: clamp(_h, 1, 10),
        confidence: _sk,
        candidates: lod_assay_shortlist(_d, _h, _err)
    };
}

/// Every species consistent with a density and hardness reading, given the reading's error.
///
/// This is the function that makes an assay INFORMATIVE rather than an answer: a bad reading
/// returns eleven candidates and a good one returns one, and the player can see the list shrink as
/// their kit improves.
function lod_assay_shortlist(_density, _hardness, _err) {
    var _out = [];
    var _dtol = max(0.30, _density * (_err + 0.06));
    var _htol = max(0.40, _hardness * (_err + 0.05));
    for (var _i = 0; _i < LOD_SPECIES_N; _i++) {
        var _sp = lod_species(_i);
        if (abs(_sp.density - _density) <= _dtol && abs(_sp.hardness - _hardness) <= _htol) {
            array_push(_out, _i);
        }
    }
    return _out;
}

/// Whether a tool of this hardness can cut this stone, and what happens if it tries.
///
/// Mohs is an ORDINAL scale and this treats it as one: a tool must be harder than the stone to
/// abrade it at all, and the margin decides how cleanly. That is why a diamond-tipped wheel is the
/// only thing that touches corundum, and why anyone can carve jet with a knife.
///
/// Returns: 0 = the tool skates off and nothing happens, 1 = cut, 2 = the stone shattered.
function lod_cut_outcome(_stone, _tool_hardness, _skill, _seed) {
    /// ⛔ REFUSES WITH 0 = "skated off", which this function already returns for a tool too soft.
    /// Of the three documented outcomes 0 is the only one that CHANGES NOTHING: 1 would hand the
    /// player a cut gem for a call that failed, and 2 would DESTROY a stone they still own. A
    /// refusal must never be the destructive branch, so the tri-state picks itself here.
    if (!lod_is_stone(_stone)) return 0;
    if (!is_numeric(_tool_hardness) || !is_numeric(_skill) || !is_numeric(_seed)) return 0;
    var _sp = _stone.sp;
    if (!lod_is_cuttable(_sp)) return 0;
    if (_tool_hardness < _sp.hardness + 0.5) return 0;

    var _rng = lod_rng(_seed + _stone.seed + 33613);
    // Softer stones shatter more readily under a hard tool, and skill is what stops it. A stone
    // one step below its tool is the safest thing to cut - which is exactly the lapidary's rule.
    var _over = _tool_hardness - _sp.hardness;
    var _risk = clamp(0.06 + _over * 0.045 + (2.5 - min(_sp.hardness, 2.5)) * 0.10, 0, 0.85);
    _risk *= (1 - clamp(_skill, 0, 1) * 0.80);
    if (lod_rng_next(_rng) < _risk) return 2;
    return 1;
}

/// ============================================================================================
/// VALUE
///
/// ⚠️ ONE FORMULA, AND EVERY TERM IS A THING THE PLAYER CAN SEE. Rarity is what the stone is;
/// hardness is how hard it was to work; the state is how much work has been done. A value function
/// with a hidden term is a value function a player cannot learn, and learning the market is most
/// of what a prospecting game IS.
/// ============================================================================================

/// What a stone is worth, in whatever the buyer's game calls money. Base 1..100-ish.
function lod_value(_stone) {
    /// Refuses with 0, and lod_price rounds it, so both entry points refuse together. A stone that
    /// is not a stone is worth nothing, and 0 flows safely through a buyer's shop arithmetic
    /// instead of throwing in the middle of it.
    if (!lod_is_stone(_stone)) return 0;
    var _sp = _stone.sp;
    var _base = 2 + 46 * power(_sp.rarity, 1.8);
    // Working a stone multiplies its value, and the multiplier is bigger for harder stones because
    // the work was harder. A polished jet is worth a little more than rough jet; a polished
    // corundum is worth a great deal more than rough corundum.
    var _work = 1.0;
    if (_stone.state == 1) _work = 1.15;
    if (_stone.state == 2) _work = 1.6 + _sp.hardness * 0.22;
    if (_stone.state == 3) _work = 2.1 + _sp.hardness * 0.34;
    return _base * _work;
}

/// A stone's value as a rounded integer, which is what a shop actually shows.
function lod_price(_stone) {
    return round(lod_value(_stone));
}

/// ============================================================================================
/// THE CABINET
///
/// The collection the player fills. Kept here rather than in an object so it is testable and so a
/// buyer can serialise it however their game already serialises things.
/// ============================================================================================

/// A new, empty cabinet: one slot per species, each holding the BEST state that species has been
/// brought to, or -1 for never found.
function lod_cabinet_new() {
    var _c = array_create(LOD_SPECIES_N, -1);
    return { slots: _c, found: 0 };
}

/// Record a stone. Returns true if the cabinet actually improved, which is the signal a game wants
/// for its "new specimen" fanfare.
///
/// ⚠️ IT COMPARES STATES, NOT PRESENCE. Finding a second rough quartz when a polished one is
/// already in the case is not progress, and a cabinet that lit up for it would be lying.
function lod_cabinet_add(_cab, _stone) {
    /// Refuses with false, which already means "the cabinet did not improve" - so a buyer's
    /// "new specimen" fanfare stays silent rather than firing for a call that failed.
    if (!is_struct(_cab) || !is_array(variable_struct_get(_cab, "slots"))) return false;
    if (!lod_is_stone(_stone)) return false;
    var _i = _stone.species;
    if (!is_numeric(_i) || _i < 0 || _i >= LOD_SPECIES_N) return false;
    var _was = _cab.slots[_i];
    if (_stone.state <= _was) return false;
    if (_was < 0) _cab.found += 1;
    _cab.slots[_i] = _stone.state;
    return true;
}

/// How complete the cabinet is, 0..1, counting BEST STATE rather than presence - so a case of
/// rough is a third full, not full.
function lod_cabinet_completion(_cab) {
    /// Refuses with 0 - an unreadable cabinet is not a full one, and a progress bar that reads
    /// empty is investigable where one that reads full is not.
    if (!is_struct(_cab) || !is_array(variable_struct_get(_cab, "slots"))) return 0;
    var _sum = 0, _max = 0;
    for (var _i = 0; _i < LOD_SPECIES_N; _i++) {
        var _sp = lod_species(_i);
        var _best = lod_is_cuttable(_sp) ? 3 : 1;
        _max += _best;
        if (_cab.slots[_i] >= 0) _sum += min(_cab.slots[_i], _best);
    }
    if (_max <= 0) return 0;
    return _sum / _max;
}

/// Which species in the cabinet are still missing entirely. Returns an array of indices.
function lod_cabinet_missing(_cab) {
    /// ⛔ REFUSES WITH AN EMPTY ARRAY, and that choice is the uncomfortable one, so it is written
    /// down: an empty list reads as "nothing is missing", i.e. a COMPLETE cabinet, which is the
    /// optimistic direction. The alternative - listing all 48 as missing - is worse, because a
    /// buyer drawing a "still to find" panel would show a full checklist of species the player may
    /// already own. Neither is good; the caller's real defence is that the array is only meaningful
    /// beside lod_cabinet_completion, which refuses with 0 and therefore disagrees loudly.
    if (!is_struct(_cab) || !is_array(variable_struct_get(_cab, "slots"))) return [];
    var _out = [];
    for (var _i = 0; _i < LOD_SPECIES_N; _i++) {
        if (_cab.slots[_i] < 0) array_push(_out, _i);
    }
    return _out;
}
