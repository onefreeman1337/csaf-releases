{
  "$GMScript": "v1",
  "%Name": "lod_demo",
  "name": "lod_demo",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}