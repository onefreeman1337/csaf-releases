/// LODE - lod_demo. The demo room's own logic, kept out of the object's events.
///
/// ⛔ A RUNNABLE DEMO ROOM IS MANDATORY IN THIS WING and it is three things at once: the buyer's
/// quickstart, the source of the store GIF, and the only real smoke test a GML package has. A
/// buyer who cannot press Play cannot evaluate.
///
/// The logic lives here rather than in the object so it can be called by the bake and read by
/// anyone browsing `scripts/`, which is where a buyer looks first.

/// Everything the demo shows about the currently selected stone.
function lod_demo_state(_species, _seed, _state, _skill) {
    var _stone = lod_specimen(_species, _seed, _state);
    return {
        stone: _stone,
        pal: lod_specimen_pal(_stone),
        parts: lod_specimen_parts(_stone),
        assay: lod_assay(_stone, _skill),
        price: lod_price(_stone)
    };
}

/// The demo's readout lines. Returned as an array of strings so the Draw event is a loop rather
/// than twenty hand-placed calls that drift out of alignment.
///
/// ⚠️ ASCII ONLY - the shipped fonts carry 32..126 and a missing glyph draws nothing at all, with
/// no error and no box. "g/cm3" rather than a superscript three for exactly that reason.
function lod_demo_lines(_d, _skill) {
    var _sp = _d.stone.sp;
    var _cand = array_length(_d.assay.candidates);
    return [
        lod_specimen_label(_d.stone),
        lod_specimen_line(_d.stone),
        "",
        "band          " + lod_band_names()[_sp.band],
        "hardness      " + string_format(_sp.hardness, 1, 1) + " Mohs",
        "density       " + string_format(_sp.density, 1, 2) + " g/cm3",
        "value         " + string(_d.price),
        "",
        "ASSAY at skill " + string_format(_skill, 1, 2),
        "  reads density  " + string_format(_d.assay.density, 1, 2),
        "  reads hardness " + string_format(_d.assay.hardness, 1, 1),
        "  " + string(_cand) + " candidate" + ((_cand == 1) ? "" : "s") + " remain"
    ];
}

/// The candidate shortlist as one line, truncated to fit a panel.
function lod_demo_candidates(_d, _max) {
    var _s = "";
    var _n = min(array_length(_d.assay.candidates), _max);
    for (var _i = 0; _i < _n; _i++) {
        if (_i > 0) _s += ", ";
        _s += lod_species(_d.assay.candidates[_i]).name;
    }
    if (array_length(_d.assay.candidates) > _n) _s += ", ...";
    if (_s == "") _s = "(none)";
    return _s;
}
