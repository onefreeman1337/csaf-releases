# LODE — Minerals That Draw Themselves

**Ore, gems and specimens for GameMaker, computed from a seed and drawn in pure GML.**
48 species · 21 crystal habits · 10 lustres · 10 zoning programs · 10 cuts · 8 host rocks ·
no sprites, no atlas, no texture page.

Version 1.0.0 · GameMaker Studio 2.3+ / GameMaker 2024.x · runtime `2024.14.4.268`

---

## What this is, and what it is not

**This is not a crystal sprite pack. It is the thing that makes them.**

The mineral shelf for GameMaker is static art: a folder of PNGs, a fixed set of pictures, and
nothing behind them. That is fine until your game needs a stone nobody drew — a half-polished
amethyst, a pyrite the player mistook for gold, the forty-first mineral when the pack shipped
forty.

Lode ships the generator. A stone is **two integers** — a species index and a seed — and everything
else is computed:

> **A mineral's picture and its physics are the same row.**

`lod_species()` returns a species' habit, lustre, zoning, cut, host rock, depth band, Mohs hardness
and density together. `lod_habit` draws the silhouette from the habit, `lod_material` builds the
five-stop ramp from the lustre, `lod_zoning` distributes the colour, and `lod_assay` gates cutting
on the *same* hardness the picture was drawn from. There is no second table and no synchronisation
step, so you cannot reach a state where a stone looks like corundum and files like chalk.

If you already have an inventory and a shop, use Lode for the stones and ask it what they are worth.
If you do not, there is enough here to prototype the whole loop.

---

## Quickstart

1. Import `Lode.yymps` (**Tools → Import Local Package**, select all).
2. Open `rm_lod_demo` and press Play. That room is the whole API in one screen.
3. `Q`/`W` species · `SPACE` reseed · `A`/`S` rough → cut → polished · `Z`/`X` assay kit ·
   `LEFT`/`RIGHT` depth · `P` pan · `C` the cabinet.

Then, in your own code:

```gml
// A stone is a species index and a seed. Store those two numbers; that is the whole save format.
var _stone = lod_specimen(lod_species_index("Amethyst"), 20260831, 0);

// Draw it, fitted to any rectangle, at any size.
lod_specimen_draw(_stone, x, y, 96, 96);

// Ask it things.
show_debug_message(lod_specimen_label(_stone));   // "Amethyst in basalt"
show_debug_message(lod_price(_stone));            // what it is worth
```

---

## The four functions that are the product

| call | gives you |
| --- | --- |
| `lod_specimen(species, seed, state)` | a stone, as plain data |
| `lod_specimen_parts(stone)` | its geometry, as a part list |
| `lod_specimen_pal(stone)` | its palette |
| `lod_specimen_draw(stone, x, y, w, h)` | draws it, fitted, uniformly scaled |

`state` is `0` rough in matrix · `1` extracted rough · `2` cut · `3` cut and polished. A species
that is never faceted — native gold, galena, pyrite — clamps to `1`, which is the honest answer
rather than drawing a jewel nobody can make.

## The system half

| call | what it does |
| --- | --- |
| `lod_prospect(depth, seed)` | a species index at that depth, or `-1` for an empty pan. **`depth` is a fraction of the column, `0.0` surface to `1.0` deepest** — not metres and not a room coordinate |
| `lod_assay(stone, skill)` | density and hardness AS READ, plus the candidate shortlist |
| `lod_cut_outcome(stone, tool_hardness, skill, seed)` | `0` skated off · `1` cut · `2` shattered |
| `lod_value(stone)` / `lod_price(stone)` | what it is worth, rising with work |
| `lod_cabinet_new/_add/_completion/_missing` | the collection, scored by BEST STATE |

Every one of those is a **pure function** — no draw calls, no instance variables, no room state — so
you can call them from a server, a unit test or a save-file migration.

⚠️ **Scale your own depth into `0..1` before calling `lod_prospect`.** A depth outside that range
sits outside every band, so the function correctly finds nothing and returns `-1` **every single
time** — which is indistinguishable from bad luck at a real depth. If prospecting never yields
anything, check this first: it is the one mistake here that fails silently and looks like the
documented behaviour.

⚠️ **`lod_prospect` can return `-1`, and that is the point.** An empty pan is what makes a strike
mean anything. Handle it.

---

## Performance, honestly

A finished specimen is a few hundred primitives. A cabinet of forty-eight of them redrawn every
frame from geometry is tens of thousands of draw calls, and it will show up in your profiler.

**A stone is a stable object** — once prospected, assayed and cut it does not change again — so
cache it:

```gml
// Build once, blit forever. YOU own the sprite; call sprite_delete when you are done with it.
var _spr = lod_render_to_sprite(lod_specimen_parts(_stone), lod_specimen_pal(_stone), 128, 128, 4);
```

Nothing else in this package allocates anything that must be freed. A stone is numbers and arrays;
generate ten thousand in a loop and drop them on the floor.

---

## What is in the box

```
scripts/
  lod_corpus      the 48 species and the vocabulary tables       (GENERATED - see below)
  lod_specimen    the public surface: the four functions above
  lod_habit       the 21 crystal habits - the silhouette programs
  lod_material    lustre -> a five-stop Oklch ramp, plus the host rocks
  lod_zoning      the 10 colour-distribution programs
  lod_cut         the 10 faceted cuts
  lod_rock        the 8 host rocks and their grain programs
  lod_assay       prospecting, assay, cutting, value, the cabinet - all pure
  lod_demo        the demo room's own logic
  lod_selftest    4,696 in-engine assertions
  lod_bake        the store sheets, rendered by the product itself
  lod_geom lod_palette lod_relief lod_render lod_shape    the drawing foundation
fonts/            fnt_lode, fnt_lode_title  (Open Sans, Apache-2.0 - see THIRD-PARTY-NOTICES.txt)
objects/ rooms/   the demo
```

**`lod_corpus.gml` is generated** and says so at the top. If you edit the corpus, edit it — but read
the append-only warning first: a saved stone resolves its species through an INDEX, so reordering
any table silently rewrites every stone already in a player's save file. **Append; never reorder.**

---

## Compatibility

- **GameMaker Studio 2.3+ and GameMaker 2024.x.** Built and verified against runtime
  `2024.14.4.268` (the legacy GMS2 runtime), which GameMaker has committed to supporting with SDK
  and critical fixes **until at least Q1 2028**.
- **GMRT**: this package is pure GML with no extensions, no native calls and no shaders, which is
  the shape GMRT's stated 99% compatibility carries forward. It is not tested there and is not sold
  on that basis.
- **No dependencies.** No extensions, no shaders, no external libraries, no internet access.
- **Everything is namespaced `lod_` / `LOD_`.** GML's global namespace is flat; the one global this
  package sets is `global.lod_corpus_cache`, and the lamp state `global.lod_lx` / `global.lod_ly`.

## What it does not do

- It does not draw an inventory, a shop or a mining minigame. It draws stones and answers questions
  about them; the screens are yours.
- It does not animate. A specimen is a still object.
- It is 2D. There is no 3D geometry here and no attempt at one.

---

## Verification

This package was built and checked by the following, on this machine, before release:

- **Igor package build** — exit 0, 0 errors, 0 warnings, 337 resources compiled.
- **4,696 in-engine assertions** on the Igor-built executable, 0 failures, suite reaching its
  terminal stage marker. Run them yourself: build the project and launch it with `-selftest`; it
  writes `lod_selftest.json` to `%LOCALAPPDATA%/Lode/`.
- **The store gallery was rendered by this package**, not by a previewer — `lod_bake`, via
  `-bake`. Every image on the store page is the code in this folder drawing.

⚠️ **Stated plainly: GML cannot be unit-tested outside the engine.** There is no headless runner and
no mock. Everything above is a real build and a real run, and the suite computes points and numbers
— it cannot see a fill rule, a draw order or a picture. Those were checked by opening the rendered
sheets and looking at them.

---

## Licence

See `LICENSE.txt`. Unlimited use in commercial and free games; do not resell the source as an asset.

Open Sans is used under the Apache License 2.0 — see `THIRD-PARTY-NOTICES.txt` and
`Apache-2.0.txt` beside the fonts.

---

## AI disclosure

This package was written with AI assistance. Code: yes. Graphics: yes — and there are no graphics
files; every image is drawn by the GML in this package at runtime. Sounds: none. Text: yes.

---

*Lode 1.0.0 · Core Systems Asset Factory*
