/// HOROLOGE - hrl_train. The gear train solver. This file is the SYSTEM the pictures are of.
///
/// ============================================================================================
/// WHAT IT DOES, AND WHY THAT IS THE PRODUCT RATHER THAN A DETAIL
///
/// Given nothing but tooth counts, a module and a layout angle per mesh, this file computes:
///
///   WHERE   every arbor sits, so that meshing wheels genuinely touch. Centre distance is
///           module * (Na + Nb) / 2 and it is DERIVED, never placed by eye.
///   HOW FAST every arbor turns, as a signed ratio chain from the driver.
///   WHAT PHASE every wheel starts at, so that a tooth of the driver lands in a GAP of the driven
///           wheel, at the line of centres, AT EVERY MOMENT and not merely at t = 0.
///
/// That third one is the part that separates a drawing of a gear train from a gear train. Any
/// animation can spin two discs at the right relative speed; the teeth only interleave if the
/// phase is solved. hrl_selftest checks it at a dozen arbitrary times per mesh by measuring, in
/// ARC LENGTH at the pitch point, how far the driver's nearest tooth is from the line of centres
/// against how far the driven wheel's nearest gap is from it. Those two arcs must cancel.
///
/// ============================================================================================
/// TIME IS QUANTISED BY THE ESCAPEMENT, AND EVERYTHING ELSE IS DERIVED FROM IT
///
/// A real clock train does not run smoothly. The weight or spring pulls continuously and the
/// escapement lets the train forward one half tooth at a time, so every wheel in the movement
/// advances in steps. That is why a mechanical seconds hand JUMPS and a quartz one glides, and it
/// is the single most recognisable thing about a mechanism.
///
/// So there is exactly ONE quantised quantity - `tick_t`, the time the train has actually been
/// allowed to advance to - and every arbor's angle is a pure function of it:
///
///     angle[i] = base[i] + turns[i] * TAU * tick_t
///
/// ⛔ ONE QUANTITY, NOT ONE PER WHEEL. If each arbor kept its own accumulated angle they would
/// drift apart over hours of play - floating point, variable frame times, a paused game - and the
/// teeth would slowly walk out of mesh with nothing to blame. A derived angle cannot drift,
/// because there is nothing for it to drift FROM. This is the same shared-fact-with-two-copies
/// trap CLAUDE.md §2b records, applied to state instead of to source.
///
/// ⚠️ `beat` OF ZERO MEANS CONTINUOUS, and it is a legitimate machine rather than a disabled one:
/// a mill, an orrery turned by hand and a music box have no escapement and genuinely do run
/// smoothly. Say which you have.
/// ============================================================================================

#macro HRL_MESH_EXTERNAL 0
#macro HRL_MESH_INTERNAL 1

/// ============================================================================================
/// BUILDING A TRAIN
/// ============================================================================================

function hrl_train_new(_module) {
    if (is_undefined(_module) || !is_real(_module)) { _module = 1; }
    _module = max(0.0001, abs(_module));
    return {
        module: max(0.02, _module),
        arbors: [],
        meshes: [],
        outputs: [],
        beat: 0,
        t: 0,
        tick_t: 0,
        beats: 0,
    };
}

/// Add an arbor. Returns its index.
///
///   _wheel   the wheel FIXED to this arbor - what it drives the next arbor with (or undefined)
///   _pinion  the pinion on this arbor - what the previous arbor drives IT with (or undefined)
///
/// ⚠️ THE NAMES ARE THE TRADE'S AND THEY ARE WORTH KEEPING STRAIGHT: on a clock arbor the WHEEL is
/// the large one that transmits power onward and the PINION is the small one that receives it.
/// Power goes wheel -> pinion, wheel -> pinion, all the way down, and each step is a REDUCTION in
/// torque and an INCREASE in speed. Getting the two the wrong way round builds a train that is
/// arithmetically fine and physically upside down.
/// ⚠️ THERE IS A THIRD SLOT, `extra`, AND IT EXISTS FOR ONE REAL MECHANISM RATHER THAN FOR
/// GENERALITY. A clock's MOTION WORK - the 12:1 reduction that drives the hour hand - is taken off
/// a CANNON PINION which is a third gear on the centre arbor, alongside the pinion that drives the
/// arbor and the wheel that drives the next one. Two slots cannot express it, and a movement whose
/// hour hand is not driven off the centre arbor is not a clock. Pass `undefined` everywhere else.
/// ⚠️ `_extra` IS OPTIONAL AND IS NOW DECLARED SO. It was always optional in FACT — the body just
/// stores it, so an arbor with no extra part is the normal case, and the Readme's own worked
/// example calls this with FOUR arguments. But the signature said five, so a buyer reading it saw
/// five required parameters while the documentation beside it passed four. A docs check caught the
/// disagreement; giving the parameter its default makes the signature state what the product
/// already did, rather than making the Readme wrong to match the code.
function hrl_train_add(_tr, _wheel, _pinion, _label, _extra = undefined) {
    /// ⛔ THE SIBLING BELOW ALREADY GUARDS THIS AND THIS ONE DID NOT, WHICH IS THE WHOLE DEFECT.
    /// `hrl_train_root` opens with exactly this line; `hrl_train_add` and `hrl_train_mesh` did not,
    /// so the two of them accounted for all 8 crashes an adversarial sweep of the DOCUMENTED api
    /// found. A buyer who mistypes the train handle got `Variable <unknown_object>.arbors ... cannot
    /// be resolved` from inside the package instead of a refusal, which names none of their code.
    /// -1 is the value the Readme's own worked example compares against, so refusing with it costs
    /// a caller nothing they were not already reading.
    if (!hrl_is_train(_tr)) return -1;
    var _a = {
        x: 0, y: 0,
        wheel: _wheel,
        pinion: _pinion,
        extra: _extra,
        base: 0,
        turns: 0,
        placed: false,
        label: is_undefined(_label) ? "" : _label,
    };
    array_push(_tr.arbors, _a);
    return array_length(_tr.arbors) - 1;
}

/// Resolve a part name on an arbor.
///
/// ⛔ ONE LOOKUP, USED BY BOTH THE SOLVER AND THE ASSERTION. Writing the ternary out at each call
/// site is how a third slot gets added to the solver and forgotten in the checker, and the checker
/// then measures the wrong pair and passes. Six of CLAUDE.md §2b's rows are one fact with two
/// declarations; this is the cheapest possible way not to add a seventh.
function hrl_arbor_part(_a, _name) {
    if (_name == "pinion") return _a.pinion;
    if (_name == "extra")  return _a.extra;
    return _a.wheel;
}

/// Fix the root arbor: where it is, how fast it turns, and at what angle it starts.
function hrl_train_root(_tr, _i, _x, _y, _turns, _base) {
    if (!hrl_is_train(_tr)) return _tr;
    if (!hrl_is_num(_i) || _i < 0 || _i >= array_length(_tr.arbors)) return _tr;
    var _a = _tr.arbors[_i];
    _a.x = _x; _a.y = _y;
    _a.turns = _turns;
    _a.base = is_undefined(_base) ? 0 : _base;
    _a.placed = true;
    return _tr;
}

/// Mesh arbor _ai's part onto arbor _bi's part, laying _bi out at angle _beta from _ai.
///
/// This is the whole solver. Three things are computed and NONE of them is a free parameter:
///
///   CENTRE DISTANCE  external: module * (Na + Nb) / 2   - the two pitch circles touch
///                    internal: module * (Nb - Na) / 2   - the pinion runs inside the ring
///   RATIO            external: turns_b = -turns_a * Na / Nb   (reverses)
///                    internal: turns_b = +turns_a * Na / Nb   (does not)
///   PHASE            derived below, and it is the only part that is not obvious
///
/// -- THE PHASE ---------------------------------------------------------------------------
/// Write pa_x for a wheel's angular pitch, TAU/N. Teeth sit at base + k*pa; the GAPS between them
/// sit at base + (k+0.5)*pa. For the two to interleave, when a tooth of A points along the line of
/// centres, a gap of B must point back along it.
///
/// If A happened to start with a tooth exactly on the line (base_a == beta) then B must start with
/// a gap there:
///
///     base_b = beta + pi - pa_b / 2
///
/// A does not generally start there, so let d = base_a - beta be how far A's tooth lattice is
/// rotated off the line. The wheels ROLL: A turning by d rolls B backwards by d * Na / Nb. So B's
/// lattice must start rotated the other way by exactly that:
///
///     base_b = (beta + pi - pa_b / 2) - d * Na / Nb
///
/// and because the RATES already satisfy the same ratio, a condition set at t = 0 holds forever.
/// That last sentence is the one the suite refuses to take on trust: it re-measures the mesh at a
/// dozen arbitrary times.
///
/// ⚠️ THE INTERNAL CASE IS NOT THE EXTERNAL ONE WITH A SIGN FLIPPED. The contact point of an
/// internal pair is on the FAR side of the pinion from the ring's centre, so the line of centres
/// is traversed in the other direction and the rolling correction changes sign as well as the
/// ratio. Both are written out below rather than folded together, because a single expression with
/// two sign variables in it is unreadable and this is the arithmetic the whole product rests on.
function hrl_train_mesh(_tr, _ai, _a_part, _bi, _b_part, _beta, _kind) {
    /// ⛔ SAME GUARD AS hrl_train_root, WHICH THIS FUNCTION WAS MISSING. Indexing `_tr.arbors[_ai]`
    /// with an unchecked train and unchecked indices was the other half of the 8 documented-api
    /// crashes: `undefined` gave `DoConv :1: illegal undefined/null use`, a negative index gave a
    /// resolution error naming the BUYER'S object, and a huge one gave `Unable to find instance for
    /// object index 4096` - three different engine-internal messages for one caller mistake, none
    /// of them naming this package.
    ///
    /// ⚠️ It returns `_tr` and says why on the debug log, which is what the unplaced-arbor branch
    /// immediately below already does. Failing the same way as the neighbouring refusal matters
    /// more than the particular value: a buyer who hits both should not have to learn two
    /// conventions to read one function.
    if (!hrl_is_train(_tr)) return _tr;
    if (!hrl_is_num(_ai) || _ai < 0 || _ai >= array_length(_tr.arbors)
     || !hrl_is_num(_bi) || _bi < 0 || _bi >= array_length(_tr.arbors)) {
        show_debug_message("HOROLOGE: mesh with an arbor index outside the train (" + string(_ai)
                           + ", " + string(_bi) + ") - the train holds "
                           + string(array_length(_tr.arbors)));
        return _tr;
    }
    var _A = _tr.arbors[_ai];
    var _B = _tr.arbors[_bi];
    if (!_A.placed) {
        // ⛔ FAIL LOUDLY. A mesh onto an unplaced arbor silently lays the whole rest of the
        // movement out from the origin, which draws as a heap of wheels on top of each other -
        // and looks enough like a layout mistake that it gets "fixed" by moving numbers around.
        show_debug_message("HOROLOGE: mesh from an unplaced arbor " + string(_ai));
        return _tr;
    }
    var _wa = hrl_arbor_part(_A, _a_part);
    var _wb = hrl_arbor_part(_B, _b_part);
    var _kd = is_undefined(_kind) ? HRL_MESH_EXTERNAL : _kind;

    var _Na = _wa.N, _Nb = _wb.N;
    var _pab = HRL_TAU / _Nb;
    var _d;

    if (_kd == HRL_MESH_INTERNAL) {
        var _dist_i = _tr.module * (_Nb - _Na) * 0.5;
        _B.x = _A.x + cos(_beta) * _dist_i;
        _B.y = _A.y + sin(_beta) * _dist_i;
        _B.turns = _A.turns * _Na / _Nb;
        _d = _A.base - (_beta + pi);
        _B.base = (_beta + pi - _pab * 0.5) + _d * _Na / _Nb;
    } else {
        var _dist_e = _tr.module * (_Na + _Nb) * 0.5;
        _B.x = _A.x + cos(_beta) * _dist_e;
        _B.y = _A.y + sin(_beta) * _dist_e;
        _B.turns = -_A.turns * _Na / _Nb;
        _d = _A.base - _beta;
        _B.base = (_beta + pi - _pab * 0.5) - _d * _Na / _Nb;
    }
    _B.placed = true;

    array_push(_tr.meshes, {
        a: _ai, b: _bi, a_part: _a_part, b_part: _b_part, kind: _kd, beta: _beta
    });
    return _tr;
}

/// Reverse the whole train.
///
/// ⛔⛔ THIS EXISTS BECAUSE THE FIRST BUILD OF EVERY CLOCK IN THIS PACKAGE RAN ANTICLOCKWISE, AND
/// NOTHING BUT AN ASSERTION WOULD HAVE CAUGHT IT. Every external mesh reverses direction, so
/// whether the hands go the right way round depends on whether the number of meshes between the
/// weight and the centre arbor happens to be even. The regulator has one, so its centre arbor came
/// out at MINUS one turn per hour, and the suite read "set to 3:00:00 and reads 9 hours" - which is
/// what a clock running backwards says.
///
/// ⭐ AND THE FIX IS PHYSICAL RATHER THAN COSMETIC: a clockmaker choosing which way to wind the
/// barrel reverses the entire train, which is exactly this. Negating every rate preserves the mesh
/// condition EXACTLY, because that condition is a relation between rates (turns_b = -turns_a *
/// Na / Nb) and it is invariant under a global sign flip, while the base angles - which carry the
/// t = 0 phase - are untouched. hrl_selftest re-measures every mesh AFTER the reversal rather than
/// taking that argument on trust.
///
/// ⚠️ It does NOT flip the drawing. Nothing is mirrored, no hand is negated, and no picture knows
/// this happened - the wheels simply turn the other way, which is the only thing that was wrong.
function hrl_train_reverse(_tr) {
    var _n = array_length(_tr.arbors);
    for (var _i = 0; _i < _n; _i++) _tr.arbors[_i].turns = -_tr.arbors[_i].turns;
    return _tr;
}

/// ============================================================================================
/// RUNNING IT
/// ============================================================================================

/// Advance the machine by _dt seconds of GAME time.
///
/// ⚠️ SECONDS, NOT FRAMES. A buyer's game may run at 30, 60 or 144 steps per second, or drop
/// frames under load, and a mechanism whose speed depends on the frame rate is a mechanism that
/// tells a different time on a different machine. Pass delta_time/1000000 and the movement keeps
/// real time regardless.
function hrl_train_step(_tr, _dt) {
    if (!hrl_is_train(_tr) || !hrl_is_num(_dt)) return _tr;
    _tr.t += _dt;
    if (_tr.beat > 0) {
        _tr.beats = floor(_tr.t / _tr.beat);
        _tr.tick_t = _tr.beats * _tr.beat;
    } else {
        _tr.beats = 0;
        _tr.tick_t = _tr.t;
    }
    return _tr;
}

/// Put the machine at an absolute time, in seconds since its own zero.
///
/// This is the hook a buyer's game actually uses: a clock in a world with its own clock is SET,
/// not stepped, and setting it must give the same picture as having stepped to it. hrl_selftest
/// asserts exactly that equivalence, because a set/step disagreement is the kind of defect that
/// only shows up after a save and load.
function hrl_train_set(_tr, _seconds) {
    if (!hrl_is_train(_tr) || !hrl_is_num(_seconds)) return _tr;
    _tr.t = _seconds;
    if (_tr.beat > 0) {
        _tr.beats = floor(_tr.t / _tr.beat);
        _tr.tick_t = _tr.beats * _tr.beat;
    } else {
        _tr.beats = 0;
        _tr.tick_t = _tr.t;
    }
    return _tr;
}

/// The angle of one arbor, in radians, right now.
function hrl_arbor_angle(_tr, _i) {
    var _a = _tr.arbors[_i];
    return _a.base + _a.turns * HRL_TAU * _tr.tick_t;
}

/// The angle of one arbor at an arbitrary time, without disturbing the machine.
///
/// ⚠️ EXISTS FOR THE SUITE, AND THAT IS A REASON TO SHIP IT RATHER THAN A REASON TO HIDE IT. The
/// mesh assertion has to sample a dozen times per mesh; making the suite step the machine to each
/// one would test stepping rather than meshing, and would leave the machine somewhere unexpected.
function hrl_arbor_angle_at(_tr, _i, _tick_t) {
    var _a = _tr.arbors[_i];
    return _a.base + _a.turns * HRL_TAU * _tick_t;
}

/// ============================================================================================
/// THE MESH ASSERTION - the one that proves the teeth actually interleave
/// ============================================================================================

/// Signed distance, in arc length at the pitch circle, from the line of centres to the nearest
/// TOOTH of the driver, and to the nearest GAP of the driven wheel. They must cancel.
///
/// Returns { arc_a, arc_b, err } where err is what the suite asserts is near zero.
///
/// ⛔ IT RECOMPUTES beta FROM THE ARBOR POSITIONS RATHER THAN READING mesh.beta. Reading the
/// stored angle would check the phase formula against the same number the phase formula used -
/// CLAUDE.md §2b's standing lesson, six recorded instances: verifying against the field you WROTE
/// proves only that assignment works. Deriving it from the positions means the assertion also
/// catches a layout that put the arbors somewhere the phase solver did not expect.
function hrl_mesh_error(_tr, _mi, _tick_t) {
    // A mesh that was never made cannot be measured; report zeros rather than throwing, and let
    // the caller's own assertion decide whether "no mesh" is acceptable.
    if (!hrl_is_train(_tr) || !variable_struct_exists(_tr, "meshes")) return { arc_a: 0, arc_b: 0, err: 0, raw: 0, pitch_a: 0, pitch_b: 0, pitch_err: 0, centre_dist: 0 };
    if (!hrl_is_num(_mi) || _mi < 0 || _mi >= array_length(_tr.meshes)) return { arc_a: 0, arc_b: 0, err: 0, raw: 0, pitch_a: 0, pitch_b: 0, pitch_err: 0, centre_dist: 0 };
    var _m = _tr.meshes[_mi];
    var _A = _tr.arbors[_m.a];
    var _B = _tr.arbors[_m.b];
    var _wa = hrl_arbor_part(_A, _m.a_part);
    var _wb = hrl_arbor_part(_B, _m.b_part);

    var _beta = arctan2(_B.y - _A.y, _B.x - _A.x);
    var _ta = hrl_arbor_angle_at(_tr, _m.a, _tick_t);
    var _tb = hrl_arbor_angle_at(_tr, _m.b, _tick_t);

    var _paa = HRL_TAU / _wa.N;
    var _pab = HRL_TAU / _wb.N;
    var _ra = hrl_wheel_pitch_r(_wa);
    var _rb = hrl_wheel_pitch_r(_wb);

    // Where along the line of centres does contact happen, seen from each wheel?
    var _dir_a = _beta;
    var _dir_b = _beta + pi;
    if (_m.kind == HRL_MESH_INTERNAL) { _dir_a = _beta + pi; _dir_b = _beta + pi; }

    // Offset of A's nearest TOOTH from that direction. Teeth at _ta + k*_paa.
    var _oa = _hrl_wrap_pm(_ta - _dir_a, _paa);
    // Offset of B's nearest GAP from its direction. Gaps at _tb + (k+0.5)*_pab.
    var _ob = _hrl_wrap_pm(_tb + _pab * 0.5 - _dir_b, _pab);

    var _arc_a = _oa * _ra;
    var _arc_b = _ob * _rb;
    var _raw = (_m.kind == HRL_MESH_INTERNAL) ? (_arc_a - _arc_b) : (_arc_a + _arc_b);

    // ⛔ THE ERROR IS REDUCED MODULO THE CIRCULAR PITCH, AND WITHOUT THAT THE ASSERTION HAS A
    // MEASURE-ZERO FALSE RED IN IT. Both offsets above are reduced into a half pitch either side,
    // so when the driver's tooth sits exactly on a half-pitch boundary the two reductions land on
    // OPPOSITE sides and the difference reads as a whole circular pitch. But "one whole tooth out"
    // is not out at all - the teeth are identical, and a train off by exactly one tooth meshes
    // perfectly. Reducing modulo the pitch says what was meant: how far from A tooth, not from
    // THE tooth.
    //
    // ⚠️ It also weakens the assertion in a way worth stating: this can no longer catch a phase
    // that is wrong by an exact whole number of teeth. Nothing visible distinguishes that case, so
    // it is not a defect a buyer could see - but the sentence "the phase is proven correct" would
    // be too strong, and the honest one is "proven correct to within an invisible whole tooth".
    var _pitch = pi * _tr.module;
    var _err = _hrl_wrap_pm(_raw, _pitch);

    return {
        arc_a: _arc_a, arc_b: _arc_b, err: _err, raw: _raw,
        // The mesh condition itself. Two wheels of different module cannot run together at all,
        // whatever the phase says, so the suite checks this FIRST - a phase assertion on a pair
        // that cannot mesh is a well-formed answer to the wrong question.
        pitch_a: hrl_wheel_pitch(_wa),
        pitch_b: hrl_wheel_pitch(_wb),
        pitch_err: abs(hrl_wheel_pitch(_wa) - hrl_wheel_pitch(_wb)),
        // And the layout condition: the pitch circles must actually touch.
        centre_dist: point_distance(_A.x, _A.y, _B.x, _B.y),
        centre_want: (_m.kind == HRL_MESH_INTERNAL)
            ? abs(_rb - _ra)
            : (_ra + _rb),
    };
}

/// Reduce an angle into [-_period/2, +_period/2).
///
/// ⛔ NOT `mod`, BECAUSE GML's `mod` KEEPS THE SIGN OF ITS LEFT OPERAND. `(-0.1) mod 0.5` is -0.1,
/// not 0.4, so a naive reduction of a negative angle lands in the wrong half period and the
/// assertion above reads a full pitch of error on a perfectly meshed pair. That is a FALSE RED,
/// and a false red costs exactly what a false green does.
///
/// ⛔⛔ AND NOT A `while` LOOP EITHER, WHICH IS WHAT THIS WAS AND WHY IT HAD TO CHANGE. Subtracting
/// the period until the value is in range is O(x / period), and this product reaches enormous
/// angles honestly: a counting machine's last arbor turns at 167 revolutions per second, so at
/// twelve hours it is at 45 million radians and the loop wanted FOUR HUNDRED MILLION iterations
/// against a period of 0.1. It did not hang - it did something worse. It came back with the wrong
/// answer, because four hundred million subtractions at that magnitude accumulate rounding error
/// far larger than the tolerance the mesh assertion uses.
///
/// MEASURED: the suite reported "counting machine mesh 2 at t=43200: teeth out of phase by -0.12"
/// against a tolerance of 0.02 - a real number, produced by a real defect, in the INSTRUMENT
/// rather than in the mechanism. One floor and one multiply is exact to the ulp of the input and
/// takes constant time.
///
/// ⭐ The general form worth keeping: AN ITERATIVE REDUCTION IS A LOOP WHOSE TRIP COUNT IS YOUR
/// INPUT, and any code that can be handed a large input has no business containing one.
function _hrl_wrap_pm(_x, _period) {
    if (_period <= 0) return _x;
    return _x - floor(_x / _period + 0.5) * _period;
}

/// ============================================================================================
/// OUTPUTS - how a mechanism drives something in the buyer's game
///
/// ⭐ THIS IS THE HALF OF THE PRODUCT THAT IS NOT A PICTURE, and it is why this is a subsystem
/// rather than an ornament. A movement's arbors turn at rates the tooth counts decided; an OUTPUT
/// names one of them and says what one revolution of it MEANS. A clock's centre arbor means sixty
/// minutes. An orrery's earth arbor means one year. A mill's stone arbor means so many sacks. The
/// game reads hrl_train_read and does not have to know anything about wheels.
/// ============================================================================================

/// Declare an output on an arbor.
///
///   _units_per_rev  what one revolution of this arbor counts out
///   _wrap           the value it rolls over at (0 = never wraps, it just accumulates)
function hrl_train_output(_tr, _i, _label, _units_per_rev, _unit, _wrap) {
    array_push(_tr.outputs, {
        arbor: _i, label: _label, per_rev: _units_per_rev,
        unit: _unit, wrap: is_undefined(_wrap) ? 0 : _wrap
    });
    return _tr;
}

/// Read one output's current value.
function hrl_train_read(_tr, _oi) {
    if (!hrl_is_train(_tr) || !variable_struct_exists(_tr, "outputs")) return undefined;
    if (!hrl_is_num(_oi) || _oi < 0 || _oi >= array_length(_tr.outputs)) return undefined;
    var _o = _tr.outputs[_oi];
    var _a = _tr.arbors[_o.arbor];
    var _revs = _a.turns * _tr.tick_t;
    var _v = _revs * _o.per_rev;
    if (_o.wrap > 0) {
        _v = _v - floor(_v / _o.wrap) * _o.wrap;
    }
    return _v;
}

/// Every output as a struct of label -> value, for a buyer who wants the whole readout at once.
function hrl_train_read_all(_tr) {
    if (!hrl_is_train(_tr) || !variable_struct_exists(_tr, "outputs")) return { hours: 0, minutes: 0, seconds: 0 };
    var _out = {};
    var _n = array_length(_tr.outputs);
    for (var _i = 0; _i < _n; _i++) {
        variable_struct_set(_out, _tr.outputs[_i].label, hrl_train_read(_tr, _i));
    }
    return _out;
}

/// ============================================================================================
/// EXTENT - where the whole movement sits, so it can be fitted into a rectangle
/// ============================================================================================

function hrl_train_bounds(_tr) {
    if (!hrl_is_train(_tr)) return [0, 0, 0, 0];
    var _n = array_length(_tr.arbors);
    if (_n == 0) return { x0: -1, y0: -1, x1: 1, y1: 1 };
    var _x0 = 999999, _y0 = 999999, _x1 = -999999, _y1 = -999999;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _tr.arbors[_i];
        var _r = 0;
        if (!is_undefined(_a.wheel))  _r = max(_r, hrl_wheel_extent(_a.wheel));
        if (!is_undefined(_a.pinion)) _r = max(_r, hrl_wheel_extent(_a.pinion));
        if (!is_undefined(_a.extra))  _r = max(_r, hrl_wheel_extent(_a.extra));
        if (_a.x - _r < _x0) _x0 = _a.x - _r;
        if (_a.y - _r < _y0) _y0 = _a.y - _r;
        if (_a.x + _r > _x1) _x1 = _a.x + _r;
        if (_a.y + _r > _y1) _y1 = _a.y + _r;
    }
    return { x0: _x0, y0: _y0, x1: _x1, y1: _y1 };
}

/// The overall reduction from one arbor to another, following the mesh chain.
///
/// ⚠️ COMPUTED FROM THE RATES THE SOLVER PRODUCED, so it answers "what did this train actually
/// end up doing" and not "what did I mean it to do". Those differ exactly when there is a bug,
/// which is when you want the answer.
function hrl_train_ratio(_tr, _from, _to) {
    if (!hrl_is_train(_tr)) return 0;
    var _n = array_length(_tr.arbors);
    if (!hrl_is_num(_from) || _from < 0 || _from >= _n) return 0;
    if (!hrl_is_num(_to)   || _to   < 0 || _to   >= _n) return 0;
    var _a = _tr.arbors[_from].turns;
    if (abs(_a) < 0.000000001) return 0;
    return _tr.arbors[_to].turns / _a;
}
