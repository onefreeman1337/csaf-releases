# ARMOURY

**Weapons that forge themselves from what they are made of and what they have done.**

A complete weapon system for GameMaker, written entirely in GML. No sprites, no spritesheets, no
atlas, no texture pages — `sprites/` does not exist in this package. Every blade, haft, guard,
pommel, rivet and notch is drawn from data at runtime.

Armoury 1.0.0 · GameMaker 2024.14+ · built and verified against runtime `2024.14.4.268`

---

## The thirty-second version

```gml
// Make a weapon. Same three arguments always give the same weapon.
var w = arm_forge("arming", "militia", 1234);

// Draw it.
arm_draw(w, x, y, 96);          // 96 pixels tall
arm_draw_icon(w, x, y, 32);     // fitted into a 32px inventory cell

// Read it.
arm_name(w)        // "A chipped militia arming sword"
arm_describe(w)    // "wrought iron blade, bronze furniture, leather grip. 14 years old, ..."
arm_stat_line(w)   // "reach 92 cm   mass 1.14 kg   balance 11 cm"

// Use it. Forty fights and two years later, badly looked after:
w = arm_use(w, 40, 2, 0.1);
```

That is the whole API surface most projects will ever touch.

---

## What makes this different from a weapon sprite pack

A sprite pack ships a fixed set of pictures. Every sword it contains looks the same in every game
that buys it, and it looks the same on the last day of the game as on the first.

**Armoury ships the thing that MAKES the pictures, and the weapon carries its own history.**

- **37 forms** — 18 hand blades, 19 axe / mace / hammer / polearm heads
- **8 pommels, 8 guards, 5 grip treatments, 4 polearm point profiles**
- **20 materials**, every colour computed in Oklab, none of them a hex value in a table
- **7 provenance classes** — issue, militia, guild, temple, looted, heirloom, grave

Those multiply. But the multiplication is not the point; **the history is.**

### The one thing to look at

A weapon accumulates damage, and **care does not remove that damage — it MOVES it.**

An owner who looks after a sword grinds the notches out of it, which takes metal off. So a
well-kept forty-year-old blade is not an unmarked blade, it is a **narrower** one. A neglected
blade of the same age is full width and full of notches, and rusted.

Those are two completely different silhouettes arising from one number, and neither of them is
"the new sword with a dirt filter over it". `arm_use()` is what advances it, and the `care`
argument is the player's choice, not the weapon's.

Other things the history layer does, all derived rather than drawn:

- **Notches are cut out of the SILHOUETTE**, not drawn on the face, and they cluster where a
  sword actually takes damage: the percussive centre around 60–85% of the way to the point, and
  the forte near the guard where you parry. Damage scattered evenly along a blade is the tell of
  a wear system written without looking at one.
- **Corrosion pulls toward a real target.** Iron goes to rust, bronze to verdigris, silver to
  tarnish, bone to a handled stain. Gold does not corrode at all.
- **A re-hafted weapon has a new pole on an old head** — fresh pale timber under fifty-year-old
  metal.
- **A grave-goods blade is BENT**, because ritually "killing" a sword before burying it with its
  owner is a real practice and it produces a silhouette nothing else on the shelf ships.
- **Every previous owner leaves a mark** — a punched maker's stamp, a tally filed into the
  pommel, a wire inlay, a re-peened tang, a re-wrapped grip.

### Stats that come out of the geometry

`arm_mass_kg()` and `arm_balance_cm()` are computed from the weapon's own dimensions and the real
density of what it is made of — not rolled, not tabled. Which means a blade ground back a third of
its width is genuinely **lighter and better balanced** than it was new, which is a real and
slightly surprising fact about old swords that your game can hand a player for free.

---

## Installing

1. In GameMaker: **Tools → Import Local Package**, choose `Armoury.yymps`, import all.
2. Open **`rm_arm_demo`** and press Play.

The demo room is the quickstart. Arrow keys cycle form and provenance, `F` puts the weapon through
ten more fights, `C` toggles whether this owner looks after it, `A` runs time automatically. Watch
the same sword age both ways — that is the product.

Everything is plain functions in `scripts/`. There are no objects to inherit from and nothing to
initialise.

### Compatibility

- **GameMaker 2024.14 and later**, GMS2 runtime. Built and gate-verified on `2024.14.4.268`.
- **Pure GML.** No extensions, no DLLs, no shaders, no external dependencies of any kind.
- **Every global and macro is namespaced `arm_` / `ARM_`.** GML's global namespace is flat, and a
  collision in your project is a support ticket nobody can debug remotely.
- **No absolute paths, no hardcoded room or layer indices.**
- A weapon is **plain data** — structs, arrays, numbers and strings. `json_stringify` it straight
  into your save file and read it back.
- **Nothing to free.** The package allocates no sprites, surfaces or buffers. The one exception is
  opt-in: `arm_render_to_sprite()` hands you a sprite and you own it.

---

## What is in the package

| Script | What it is |
| --- | --- |
| `arm_forge` | the assembler and the public API — start here |
| `arm_blade` | 22 blade profiles, and the blade-space every mark is authored in |
| `arm_head` | axes, maces, hammers, picks and polearm heads |
| `arm_hilt` | pommels, guards, grips, wraps and hafts |
| `arm_history` | provenance, wear, notching, honing, corrosion |
| `arm_material` | 20 materials as five-stop Oklab relief ramps |
| `arm_lore` | generated names, descriptions and derived stats |
| `arm_relief` | shades any outline by its own surface normal against one lamp |
| `arm_geom` · `arm_shape` | primitives, curve sampling, transforms, geometry assertions |
| `arm_render` | the only file that talks to the GPU |
| `arm_palette` | Oklab to sRGB |
| `arm_bake` | renders the store sheets — every image on the listing came from here |
| `arm_selftest` | 1,476 in-engine assertions |

The source ships raw and commented. The comments are not decoration: they record the measured
reasons behind decisions that look arbitrary, including several defects that shipped in earlier
products in this line and what they cost.

---

## Verification, stated honestly

**GML cannot be unit-tested outside the engine** — there is no headless runner and no mocking
layer. This package's answer is to build through Igor and run the executable with `-selftest`,
which writes a result file.

- **Gate: CLEAN.** Igor package build, exit 0, 0 errors, 0 warnings, 329 resources compiled.
- **In-engine suite: 1,476 assertions, 0 failures**, on a real Igor-built executable.
- **A fresh install is tested as a fresh install.** The shipped `.yymps` is imported into a blank
  project and driven by buyer code written from this Readme alone: 52 assertions, including all 259
  form-by-provenance weapons built and checked for real geometry.
- **40 hostile calls** against every entry point documented above — `undefined`, negative, absurd
  and wrong-typed arguments — with 0 crashes, and a positive control proving the crash counter
  still fires.
- **The suite has been proven able to FAIL.** A suite that has only ever passed is not a suite.
  Three deliberate sabotages were run and each fired the assertions it should have, by name.

What that does **not** prove: it says nothing about whether the rendered picture is beautiful. Nine
real defects in this product were found by baking the store sheets and looking at them while 1,476
assertions were green — including a point spur on six blades, rust rendering magenta, and a pommel
detached from its own grip. Those are fixed. The limitation is structural and worth knowing about.

An assertion count says nothing about code no assertion reaches, either. `arm_render_to_sprite`
cleared its surface to a palette key that no palette in this package has ever carried, so it threw
on its first call — and it survived every one of those 1,476 assertions because nothing in the
package called it: not the demo, not the bake, not the suite. It was found by writing the buyer's
side of the Readme and running it, which is now a shipped test rather than a one-off.

---

## Licence

One developer, unlimited games, commercial or free. Modify freely. Do not resell or redistribute
the package itself. Full terms in `LICENSE.txt`; font notices in `Armoury/fonts/`.

## AI disclosure

Code: AI-generated. Graphics: AI-generated (all artwork is drawn procedurally by this package's own
GML). Sounds: none. Text: AI-generated.

---

Core Systems Asset Factory
