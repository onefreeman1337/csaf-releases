/// ARMOURY - arm_blade. Every edged blade in the corpus, and the blade-space every mark on one
/// is authored in.
///
/// ============================================================================================
/// -- SCALE IS REAL, AND THAT IS A FEATURE ----------------------------------------------------
///
/// Every weapon in this package is authored at its TRUE length in metres and converted through
/// one constant. A dagger is not a small sword; it is 0.32 m of blade against 1.05 m, and drawn
/// side by side on a common scale that is exactly what it looks like.
///
/// ⭐ THAT IS WHY THE PACKAGE CAN DRAW A FAMILY PLATE AT ALL, and it is the first thing on the
/// store page that a fixed sprite sheet cannot answer: a pack ships a dagger icon and a sword
/// icon in the same 24x24 cell, so a buyer who wants them on the ground together has to guess.
/// arm_render_in_rect_tight fits ONE weapon to a cell for the catalogue; arm_forge_at_scale
/// draws several against the same metre, which is a different picture and a truer one.
///
/// ARM_METRE is set so the longest thing in the corpus - a 2.2 m poleaxe - spans the unit box
/// exactly, from ARM_GROUND at the butt to the top edge.
/// ============================================================================================

#macro ARM_METRE 0.4273

/// The longest weapon the corpus contains, in metres. Asserted against the actual corpus by the
/// suite, so a new form longer than this cannot be added without the constant moving with it.
#macro ARM_LONGEST_M 2.2

/// ============================================================================================
/// -- BLADE SPACE, AND WHY NOTHING IS CLIPPED -------------------------------------------------
///
/// A blade is a curved, tapering, asymmetric shape, and it carries marks all over it: a fuller,
/// a medial ridge, pattern-weld watering, an inlaid inscription, notches taken out of the edge,
/// a maker's stamp. Every one of those has to stay ON the blade.
///
/// ⛔ THE OBVIOUS ANSWER - DRAW THE MARK AND CLIP IT - IS THE WRONG ONE HERE, AND arm_clip_seg
/// CANNOT DO IT ANYWAY. That function clips to an axis-aligned RECTANGLE, which is the correct
/// tool for a stroke inside a panel and useless against a curved sabre. Clipping to a POLYGON is
/// a much larger piece of machinery, and it fails in the way polygon clipping always fails: the
/// mark is drawn wrong and then trimmed, so an error in the mark shows up as a shape that ends in
/// the right place and is wrong everywhere else.
///
/// ⭐ SO NOTHING IS CLIPPED. Every mark is authored in BLADE SPACE - (t, u), where t runs 0 at the
/// shoulder to 1 at the point and u runs -1 at the back edge to +1 at the cutting edge - and
/// arm_blade_pt maps it onto the real curved blade. A mark at u = 0.8 is at eight tenths of the
/// way to the edge WHEREVER it is along the blade, on a straight arming sword and on a curved
/// sabre alike, and it cannot leave the blade because there is nowhere for it to go. Containment
/// is true by construction rather than enforced, which is the shape this wing reaches for every
/// time the picture itself is unreachable from a test.
///
/// ⚠️ AND IT IS WHY HONING WORKS AT ALL. A blade that has been ground back a hundred times is
/// NARROWER, and its fuller is proportionally closer to its edge as a result. In blade space that
/// is free: the fuller stays at the same u, the half-width shrinks, and the fuller moves in with
/// it exactly as it does on a real over-sharpened blade. In world space it would be a second
/// calculation that somebody would forget.
/// ============================================================================================

/// The default sample count along a blade. 34 is enough that a sabre's curve does not facet at
/// hero size, and few enough that a screenful of weapons is not a problem.
#macro ARM_BLADE_SEG 34

/// A blade specification. Every named blade below is one of these, and so is anything the
/// generator interpolates between them.
///
///   len      blade length in metres, shoulder to point
///   wid      blade width at the shoulder, in metres
///   taper    0..1, how much of that width is gone at the point
///   belly    -0.35..0.65, profile bulge; negative waists the blade, positive gives it a leaf
///            or falchion belly. This is the single most identity-carrying number here.
///   curve    -0.45..0.55, spine curvature. Positive curves the point AWAY from the edge (a
///            sabre); negative curves it TOWARD the edge (a khopesh, a sickle).
///   back     0..1, how much of the curvature the BACK of the blade follows. 1 is a true
///            single-edged curved blade; 0 gives a straight back with all the curve on the edge.
///   edges    1 or 2
///   point    "acute" | "spatulate" | "clip" | "round" | "chisel"
///   section  "lenticular" | "diamond" | "fuller" | "hollow" | "flat"
///   ricasso  metres of unsharpened blade at the shoulder, 0 for none
function arm_blade_spec(_form) {
    switch (_form) {
        // -- DAGGERS AND SHORT BLADES ----------------------------------------------------------
        case "dagger":     return { len: 0.30, wid: 0.042, taper: 0.86, belly:  0.05, curve:  0.00, back: 1.0, edges: 2, point: "acute",     section: "diamond",    ricasso: 0.000 };
        case "rondel":     return { len: 0.33, wid: 0.028, taper: 0.72, belly: -0.22, curve:  0.00, back: 1.0, edges: 2, point: "acute",     section: "diamond",    ricasso: 0.000 };
        case "seax":       return { len: 0.36, wid: 0.052, taper: 0.55, belly:  0.10, curve:  0.00, back: 0.0, edges: 1, point: "clip",      section: "flat",       ricasso: 0.000 };
        case "tanto":      return { len: 0.29, wid: 0.046, taper: 0.30, belly:  0.02, curve:  0.06, back: 1.0, edges: 1, point: "chisel",    section: "flat",       ricasso: 0.000 };
        case "baselard":   return { len: 0.38, wid: 0.048, taper: 0.80, belly:  0.18, curve:  0.00, back: 1.0, edges: 2, point: "acute",     section: "lenticular", ricasso: 0.012 };

        // -- ONE-HANDED SWORDS -----------------------------------------------------------------
        case "gladius":    return { len: 0.52, wid: 0.058, taper: 0.62, belly:  0.30, curve:  0.00, back: 1.0, edges: 2, point: "acute",     section: "lenticular", ricasso: 0.018 };
        case "arming":     return { len: 0.80, wid: 0.055, taper: 0.60, belly:  0.06, curve:  0.00, back: 1.0, edges: 2, point: "acute",     section: "fuller",     ricasso: 0.020 };
        case "spatha":     return { len: 0.78, wid: 0.050, taper: 0.30, belly:  0.00, curve:  0.00, back: 1.0, edges: 2, point: "spatulate", section: "fuller",     ricasso: 0.014 };
        case "falchion":   return { len: 0.68, wid: 0.062, taper:-0.28, belly:  0.52, curve:  0.10, back: 0.2, edges: 1, point: "clip",      section: "flat",       ricasso: 0.016 };
        case "sabre":      return { len: 0.83, wid: 0.048, taper: 0.42, belly:  0.14, curve:  0.34, back: 1.0, edges: 1, point: "clip",      section: "fuller",     ricasso: 0.010 };

        // -- LONG AND SPECIALIST BLADES ---------------------------------------------------------
        case "longsword":  return { len: 1.05, wid: 0.052, taper: 0.66, belly:  0.02, curve:  0.00, back: 1.0, edges: 2, point: "acute",     section: "fuller",     ricasso: 0.030 };
        case "estoc":      return { len: 1.02, wid: 0.034, taper: 0.88, belly: -0.30, curve:  0.00, back: 1.0, edges: 2, point: "acute",     section: "diamond",    ricasso: 0.045 };
        case "rapier":     return { len: 1.06, wid: 0.026, taper: 0.82, belly: -0.18, curve:  0.00, back: 1.0, edges: 2, point: "acute",     section: "hollow",     ricasso: 0.055 };
        case "greatsword": return { len: 1.32, wid: 0.062, taper: 0.58, belly:  0.04, curve:  0.00, back: 1.0, edges: 2, point: "spatulate", section: "fuller",     ricasso: 0.090 };
        case "kris":       return { len: 0.44, wid: 0.050, taper: 0.64, belly:  0.16, curve:  0.00, back: 1.0, edges: 2, point: "acute",     section: "flat",       ricasso: 0.008 };
        case "khopesh":    return { len: 0.55, wid: 0.056, taper: 0.10, belly:  0.22, curve: -0.42, back: 1.0, edges: 1, point: "round",     section: "flat",       ricasso: 0.030 };
        case "cleaver":    return { len: 0.34, wid: 0.088, taper:-0.34, belly:  0.20, curve:  0.00, back: 1.0, edges: 1, point: "round",     section: "flat",       ricasso: 0.000 };
        case "sickle":     return { len: 0.40, wid: 0.036, taper: 0.30, belly:  0.10, curve: -0.52, back: 1.0, edges: 1, point: "acute",     section: "flat",       ricasso: 0.010 };

        // -- POLEARM POINTS ---------------------------------------------------------------------
        // ⭐ THESE ARE THE SAME OBJECT AS EVERYTHING ABOVE, WHICH IS THE POINT (see arm_head's
        // header). A spearhead is a short leaf blade carried on a socket instead of a tang, so it
        // gets a profile, a section, a honing model and a notching model for free, and improving
        // the profile law improves nineteen hand weapons and six polearms at the same time.
        // arm_head overrides `len` per form, because a glaive blade and a partisan blade are the
        // same drawing at two lengths.
        case "leaf":       return { len: 0.24, wid: 0.062, taper: 0.55, belly:  0.46, curve:  0.00, back: 1.0, edges: 2, point: "acute",     section: "diamond",    ricasso: 0.000 };
        case "needle":     return { len: 0.22, wid: 0.030, taper: 0.88, belly: -0.16, curve:  0.00, back: 1.0, edges: 2, point: "acute",     section: "diamond",    ricasso: 0.000 };
        case "glaive":     return { len: 0.42, wid: 0.058, taper: 0.16, belly:  0.26, curve:  0.14, back: 0.3, edges: 1, point: "clip",      section: "fuller",     ricasso: 0.000 };
        case "bill":       return { len: 0.33, wid: 0.048, taper: 0.30, belly:  0.18, curve: -0.20, back: 1.0, edges: 1, point: "acute",     section: "flat",       ricasso: 0.000 };
    }
    return arm_blade_spec("arming");
}

/// The HAND blade forms, in corpus order. This is what the blade catalogue plate shows, and it
/// deliberately excludes the four polearm points below: a spear leaf drawn on its own, with no
/// socket and no shaft, is not a weapon a buyer recognises.
function arm_blade_names() {
    return ["dagger", "rondel", "seax", "tanto", "baselard",
            "gladius", "arming", "spatha", "falchion", "sabre",
            "longsword", "estoc", "rapier", "greatsword", "kris",
            "khopesh", "cleaver", "sickle"];
}

/// The polearm point profiles. arm_head names these; nothing else should.
function arm_point_names() {
    return ["leaf", "needle", "glaive", "bill"];
}

/// Every blade profile in the package. The suite walks THIS, so a point profile can never go
/// unchecked just because it is not on the catalogue plate.
function arm_blade_all_names() {
    return arm_append(arm_blade_names(), arm_point_names());
}

#macro ARM_BLADE_N 18
#macro ARM_POINT_N 4

/// ============================================================================================
/// THE PROFILE
/// ============================================================================================

/// Half-width of the blade at t, in metres, before honing.
///
/// ⛔ THE PROFILE IS A CURVE, NOT A LINE, AND THAT IS THE WHOLE DIFFERENCE BETWEEN A SWORD AND A
/// TRIANGLE. A straight taper from shoulder to point draws a wedge, and a wedge is what every
/// programmer-art sword in the world looks like. Real blades either WAIST slightly and then run
/// out (a longsword), or swell into a BELLY toward the last third and cut back hard to the point
/// (a falchion, a gladius, a kukri). `belly` is that term, applied as a sine bump so it is zero
/// at both ends by construction and cannot pull the shoulder or the point off their marks.
///
/// ⚠️ A NEGATIVE `taper` IS NOT A MISTAKE. A falchion and a cleaver are WIDER at the end than at
/// the shoulder, which is what makes them chopping weapons. The one thing that must never happen
/// is a half-width reaching zero before the point, which would fold the outline through itself,
/// so the result is floored.
function arm_blade_halfw(_s, _t) {
    var _t2 = clamp(_t, 0, 1);
    var _base = _s.wid * 0.5;
    var _lin = 1.0 - _s.taper * _t2;
    var _bump = _s.belly * sin(pi * _t2);
    return max(_base * 0.10, _base * (_lin + _bump));
}

/// Where the spine of the blade is at t, as an offset sideways from straight, in metres.
///
/// A curved blade is not a straight blade bent at one place. The offset grows as t squared, which
/// puts almost all of the curvature in the outer half and is why a sabre's grip end looks
/// straight and its last twenty centimetres do all the work.
function arm_blade_bow(_s, _t) {
    var _t2 = clamp(_t, 0, 1);
    return _s.curve * _s.len * 0.30 * _t2 * _t2;
}

/// A blade with no history on it: brand new, straight, unsharpened, unmarked. Every function
/// below takes one of these, and arm_history builds the interesting ones.
function arm_wear_none() {
    return { hone: 0, bend: 0, notches: [], tip: 0 };
}

/// A point in BLADE SPACE mapped to the unit box.
///
/// _t 0..1 shoulder to point; _u -1..+1 back edge to cutting edge; _w is a wear struct.
/// _y0 is where the shoulder sits, which the hilt decides.
///
/// ⚠️ EVERY LENGTH IN A SPEC IS IN METRES AND IS CONVERTED BY ARM_METRE EXACTLY ONCE, HERE. Widths
/// and lengths are both metres and both need the conversion; applying it in the caller for one and
/// here for the other is arithmetically correct on the day it is written and silently wrong the
/// first time somebody adds a third length. One conversion, one place.
function arm_blade_point(_s, _t, _u, _w, _y0) {
    var _hw = arm_blade_halfw(_s, _t) * (1.0 - 0.30 * clamp(_w.hone, 0, 1))
            * arm_blade_close(_s, _t, _u);
    var _bow = arm_blade_bow(_s, _t);
    // The BACK of a blade follows only `back` of the curvature; the rest of the bow is taken up
    // by the edge. That single number is what separates a sabre (whose back curves with it) from
    // a falchion (whose back is nearly straight while its edge swells away).
    var _side = (_u >= 0) ? 1.0 : _s.back;
    // ⛔ A BEND IS NOT CURVATURE AND IS ADDED TO BOTH SIDES EQUALLY. A grave-goods blade that was
    // ritually "killed" is a straight blade that somebody bent; its BACK moves exactly as far as
    // its edge. Folding the bend into `curve` instead would make the blade curved, which is a
    // different weapon, and it would silently change the profile's belly with it.
    var _bend = _w.bend * _s.len * 0.34 * _t * _t;
    return [(_bow * _side + _bend + _u * _hw) * ARM_METRE, _y0 - _t * _s.len * ARM_METRE];
}

/// ============================================================================================
/// NOTCHES - AND WHY THEY ARE CUT OUT OF THE OUTLINE INSTEAD OF DRAWN ON THE FACE
///
/// ⛔ THE WING'S LAW, PAID FOR ON FORAGE: "a difference drawn inside a filled shape is not a
/// difference in the shape". Two mushroom species that differed only in marks drawn inside an
/// already-solid band measured at Jaccard distance exactly ZERO, and widening the difference moved
/// nothing, because the marks were inside an area that was already filled.
///
/// A notch is precisely that trap wearing armour. Drawn as a dark chevron on the blade face it is
/// a smudge; at inventory size it is nothing at all. A notch is a piece of steel that IS NOT THERE
/// ANY MORE, and the only honest way to draw one is to take it out of the silhouette.
///
/// In blade space that is one line: the edge is at u = +1 everywhere except where a notch is, and
/// there it is at u = 1 - depth. The notch then curves with a sabre, shrinks with honing and stays
/// on the blade, all for free - which is the whole argument for blade space.
/// ============================================================================================

/// The edge's u coordinate at t, given the notches cut into it.
function arm_notch_u(_notches, _t) {
    var _u = 1.0;
    for (var _i = 0; _i < array_length(_notches); _i++) {
        var _n = _notches[_i];
        var _d = abs(_t - _n.t);
        if (_d < _n.w) {
            // A cosine bite rather than a V: a notch taken out of a blade by another blade has a
            // rounded root, and a sharp V reads as a saw tooth. Deepest at the centre, zero at
            // both ends BY CONSTRUCTION, so a notch can never step the outline.
            _u = min(_u, 1.0 - _n.d * 0.5 * (1.0 + cos(pi * _d / _n.w)));
        }
    }
    return _u;
}

/// ⛔⛔ THE POINT IS A CLOSURE ON THE HALF-WIDTH. IT IS NOT A SWEEP OF u.
///
/// MEASURED 2026-08-30 by baking the blade sheet and looking at it: SIX of eighteen forms grew a
/// thin needle standing off the tip. The first construction walked the outline up the back at
/// u = -1, then ran a loop that moved t from the point-start to 1.0 while ALSO moving u from -1 to
/// +1 through `power(k, pow)`. With pow > 1 that leaves u pinned near -1 while t climbs to the very
/// tip, so the back edge runs all the way up as a spike and then jumps across; with pow < 1 the same
/// thing happens on the edge side. The point type was controlling a crossing, not a shape.
///
/// ⚠️ AND NOTHING MECHANICAL SAW IT. The outline stayed simple (arm_is_simple passed on all 22
/// profiles), it stayed closed, its turning was one revolution, it had area, and it sat inside the
/// unit box - 1,460 assertions green over a spike on six weapons. It is the wing's standing lesson
/// arriving again: a suite that computes POINTS cannot see a SHAPE.
///
/// The correct model is the physical one. A point is the place where the blade's WIDTH goes to
/// nothing, so it belongs in the half-width function, and the outline is then just "up one side and
/// down the other" with no special case at all. A clip point closes the BACK earlier than the edge;
/// a chisel point closes ONLY the edge, which is exactly what a tanto is.
///
/// _u selects the side: negative is the back, positive is the cutting edge.
function arm_blade_close(_s, _t, _u) {
    var _ps = arm_blade_point_start(_s);
    if (_t <= _ps) return 1.0;
    var _k = (_t - _ps) / max(0.0001, 1.0 - _ps);   // 0 at the point-start, 1 at the tip
    var _back = (_u < 0);

    switch (_s.point) {
        case "acute":
            // Concave: closes gently then runs out fine. A needle point.
            return power(1.0 - _k, 0.62);
        case "spatulate":
            // Holds its width and then rounds off - a spatha or a greatsword.
            return power(1.0 - _k * _k, 0.85);
        case "clip":
            // THE BACK IS CUT AWAY EARLY AND THE EDGE CARRIES ON. That asymmetry IS the clip point,
            // and drawing both sides the same makes a falchion into a small spatha.
            return _back ? power(1.0 - _k, 1.85) : power(1.0 - _k, 0.55);
        case "round":
            // A quarter circle: no point at all. A khopesh or a cleaver ends in an edge.
            return sqrt(max(0, 1.0 - _k * _k));
        case "chisel":
            // ONLY the edge closes. The back runs dead straight to the tip, which is the whole
            // visual identity of the form.
            return _back ? 1.0 : power(1.0 - _k, 0.70);
    }
    return power(1.0 - _k, 0.62);
}

/// How far along the blade the point starts to close in. A clipped point begins its false edge
/// much earlier than an acute one, which is most of what makes the two read differently.
function arm_blade_point_start(_s) {
    switch (_s.point) {
        case "acute":     return 0.86;
        case "spatulate": return 0.94;
        case "clip":      return 0.72;
        case "round":     return 0.90;
        case "chisel":    return 0.88;
    }
    return 0.88;
}

/// The closed outline of a blade, in the unit box.
///
/// Walks UP the back edge from the shoulder, round the point, and back DOWN the cutting edge, so
/// the winding is consistent for every form and arm_out_sign never has to guess.
///
/// ⚠️ THE POINT IS SAMPLED SEPARATELY AND MORE FINELY. Sampling it at the same rate as the body
/// gives a two-segment point on every weapon in the corpus, which at inventory size reads as a
/// blade somebody has snapped the tip off. Five extra samples over the last eighth of the blade
/// costs nothing and is the difference between a sword and a spike.
function arm_blade_outline(_s, _w, _y0) {
    var _pts = [];
    var _n = ARM_BLADE_SEG;
    var _ps = arm_blade_point_start(_s);
    // ⚠️ A NOTCHED EDGE NEEDS MORE SAMPLES THAN A CLEAN ONE, and the count is driven by the
    // narrowest notch rather than by a constant. A notch 0.02 wide sampled every 0.029 of the
    // blade is a notch that lands between two samples and does not exist - which is the silent
    // half of the "defect that suppresses its own output" law: nothing draws, nothing errors.
    var _edge_n = _n;
    for (var _q = 0; _q < array_length(_w.notches); _q++) {
        _edge_n = max(_edge_n, ceil(_ps / (_w.notches[_q].w * 0.34)));
    }
    _edge_n = min(_edge_n, 260);

    // ⭐ UP THE BACK, DOWN THE EDGE. There is no point loop and no special case: the point lives in
    // arm_blade_close, which the half-width goes through, so both sides converge on the tip by
    // construction. See that function's header for the six-weapon spike this replaced.
    //
    // A BROKEN TIP SHORTENS THE BLADE. `tip` is a separate injury from `hone` and they act on
    // different axes: honing narrows the whole blade along u, a snapped point removes length along
    // t. Stopping the walk short leaves a blunt squared-off end, which is what a snapped sword is.
    var _te = 1.0 - _w.tip * 0.11;

    // The point region is sampled finely on BOTH walks: at the body's rate the closure resolves in
    // two segments on every weapon in the corpus, which at inventory size reads as a snapped tip.
    var _tip_n = 12;

    for (var _i = 0; _i <= _n; _i++) {
        array_push(_pts, arm_blade_point(_s, (_i / _n) * _ps, -1, _w, _y0));
    }
    for (var _j = 1; _j <= _tip_n; _j++) {
        array_push(_pts, arm_blade_point(_s, lerp(_ps, _te, _j / _tip_n), -1, _w, _y0));
    }
    for (var _j2 = _tip_n - 1; _j2 >= 0; _j2--) {
        array_push(_pts, arm_blade_point(_s, lerp(_ps, _te, _j2 / _tip_n), 1, _w, _y0));
    }
    // Down the edge, cutting every notch out of the silhouette on the way.
    for (var _i2 = _edge_n; _i2 >= 0; _i2--) {
        var _t3 = (_i2 / _edge_n) * _ps;
        array_push(_pts, arm_blade_point(_s, _t3, arm_notch_u(_w.notches, _t3), _w, _y0));
    }
    return arm_dedupe_pts(_pts);
}

/// ============================================================================================
/// THE SECTION - what is cut INTO the face
/// ============================================================================================

/// A closed lens running up the middle of the blade between two t values at two u values.
/// Everything drawn on a blade face is one of these.
function arm_blade_band(_s, _t0, _t1, _u0, _u1, _w, _y0, _n) {
    var _pts = [];
    var _seg = is_undefined(_n) ? 16 : _n;
    for (var _i = 0; _i <= _seg; _i++) {
        var _t = lerp(_t0, _t1, _i / _seg);
        array_push(_pts, arm_blade_point(_s, _t, _u0, _w, _y0));
    }
    for (var _j = _seg; _j >= 0; _j--) {
        var _t2 = lerp(_t0, _t1, _j / _seg);
        array_push(_pts, arm_blade_point(_s, _t2, _u1, _w, _y0));
    }
    return arm_dedupe_pts(_pts);
}

/// The marks a blade's cross-section puts on its face.
///
/// ⛔ A FULLER IS SUNKEN AND A MEDIAL RIDGE IS RAISED, AND DRAWING EITHER AS THE OTHER IS THE
/// COMMONEST WAY A DRAWN SWORD LOOKS WRONG WITHOUT ANYONE BEING ABLE TO SAY WHY. A fuller is a
/// groove forged into the blade to take weight out of it; it is darker on the lamp side. A
/// diamond section is a RIDGE standing proud down the centre line; it is lighter on the lamp
/// side. They are the same shape and opposite objects, which is exactly what arm_sink and
/// arm_raise are for.
///
/// ⚠️ THE FULLER STOPS SHORT OF THE POINT, ALWAYS. A real fuller ends where the blade starts to
/// taper into its point, because there is no longer any width to take metal out of. Running it to
/// the tip is the tell of a drawing made from a memory of a sword rather than from a sword.
function arm_blade_section_parts(_s, _w, _y0, _mat) {
    var _out = [];
    var _map = arm_material_map(_mat);
    var _fend = min(0.74, arm_blade_point_start(_s) - 0.06);

    switch (_s.section) {
        case "fuller": {
            var _f = arm_blade_band(_s, 0.02, _fend, -0.30, 0.30, _w, _y0, 18);
            _out = arm_append(_out, arm_map_roles(
                arm_sink(_f, arm_bevel_cap(_f, 0.006), 2, "m1"), _map));
        } break;

        case "diamond": {
            var _d = arm_blade_band(_s, 0.00, 0.96, -0.22, 0.22, _w, _y0, 18);
            _out = arm_append(_out, arm_map_roles(
                arm_raise(_d, arm_bevel_cap(_d, 0.005), 2, "m3"), _map));
        } break;

        case "hollow": {
            // Two narrow flutes either side of the centre. A rapier's blade is stiff because it
            // is hollow-ground, and this is what that looks like from the flat.
            var _h1 = arm_blade_band(_s, 0.02, _fend, -0.62, -0.20, _w, _y0, 14);
            var _h2 = arm_blade_band(_s, 0.02, _fend,  0.20,  0.62, _w, _y0, 14);
            _out = arm_append(_out, arm_map_roles(
                arm_sink(_h1, arm_bevel_cap(_h1, 0.004), 1, "m1"), _map));
            _out = arm_append(_out, arm_map_roles(
                arm_sink(_h2, arm_bevel_cap(_h2, 0.004), 1, "m1"), _map));
        } break;

        case "lenticular": {
            // No cut feature at all - a lenticular blade is a smooth lens, and the only thing that
            // says so is a soft highlight running just off the centre line toward the lamp. One
            // stroke, and leaving it out is what makes a lenticular blade read as flat card.
            var _pts = [];
            for (var _i = 0; _i <= 12; _i++) {
                array_push(_pts, arm_blade_point(_s, lerp(0.04, 0.90, _i / 12), -0.10, _w, _y0));
            }
            _out = arm_append(_out, arm_map_roles(
                [arm_poly(_pts, false, 0.0035, "m4")], _map));
        } break;
    }
    return _out;
}

/// ============================================================================================
/// PATTERN WELDING - the one thing on this shelf a sprite pack cannot ship per-weapon
/// ============================================================================================

/// The watering on a pattern-welded or crucible-steel blade.
///
/// ⭐ THIS IS THE PRODUCT'S BEST SINGLE ARGUMENT AND IT IS THREE DOZEN LINES. Pattern-welded steel
/// is made by folding and twisting rods of different iron together, so the surface carries a
/// serpentine figure that is DIFFERENT ON EVERY BLADE EVER MADE. A sprite pack ships one drawing
/// of it and every sword in the buyer's game then has the same fingerprint. Here the figure comes
/// out of the weapon's own seed, so two watered swords in one inventory are visibly two swords.
///
/// ⚠️ IT IS AUTHORED ENTIRELY IN BLADE SPACE and therefore cannot leave the blade - see this
/// file's header. The bands run ALONG the blade rather than across it, because that is how a
/// twisted rod presents when the blade is ground flat, and because a cross-band at inventory size
/// reads as damage.
///
/// ⚠️ AND THE STROKES ARE DRAWN IN THE MATERIAL'S OWN m1 AND m3, NEVER IN BLACK. Watering is a
/// contrast between two irons, not a set of scratches; drawn in ink it reads as a blade somebody
/// has taken a wire brush to, which is a different and much worse picture.
function arm_blade_watering_parts(_s, _w, _y0, _mat, _seed) {
    var _out = [];
    var _map = arm_material_map(_mat);
    var _r = arm_rng(_seed ^ 0x5EED);
    var _fend = arm_blade_point_start(_s) - 0.02;
    var _rods = 5 + floor(arm_rng_next(_r) * 3);

    for (var _k = 0; _k < _rods; _k++) {
        // Each rod sits at its own u and wanders with its own phase and period. The wander is a
        // fraction of the available half-width, so a narrow rapier gets a tighter figure than a
        // broad falchion without a second constant.
        var _u0 = -0.80 + 1.60 * ((_k + 0.5) / _rods);
        var _amp = 0.16 + 0.16 * arm_rng_next(_r);
        var _per = 2.2 + 3.4 * arm_rng_next(_r);
        var _ph = arm_rng_next(_r) * ARM_TAU;
        var _pts = [];
        for (var _i = 0; _i <= 22; _i++) {
            var _t = lerp(0.03, _fend, _i / 22);
            var _u = clamp(_u0 + _amp * sin(_ph + _per * _t * pi), -0.88, 0.88);
            array_push(_pts, arm_blade_point(_s, _t, _u, _w, _y0));
        }
        array_push(_out, arm_poly(_pts, false, 0.0026, (_k % 2 == 0) ? "m1" : "m3"));
    }
    return arm_map_roles(_out, _map);
}

/// ============================================================================================
/// THE WHOLE BLADE
/// ============================================================================================

/// A finished blade: the mass, its section, and its watering if the metal has any.
///
/// ⛔ ORDER IS THE PICTURE. The mass goes down first, the section is cut into it, and the watering
/// goes on top of both - because watering is a property of the metal and is therefore visible
/// INSIDE the fuller as well as on the flat. Drawing the watering first and the fuller over it
/// produces a blade with a blank groove down the middle, which is the one thing a real
/// pattern-welded blade never has.
/// ⛔ `_mat` IS A PALETTE PREFIX, NOT A MATERIAL NAME, AND `_watered` IS SEPARATE BECAUSE OF IT.
///
/// Everything in this package draws through a prefix - "e" for the edge metal, "f" for the
/// fittings - so that one weapon can carry four materials at once. The first version of this
/// function decided whether to draw pattern-welding by testing `_mat == "watered"`, which is a
/// comparison between a prefix and a material name and is therefore FALSE FOR EVERY WEAPON EVER
/// FORGED. The watering - the single best argument this product has against a sprite sheet - would
/// have shipped having never once drawn, and nothing would have said so: no error, no warning, no
/// failed assertion, just a package whose headline feature quietly did not exist.
///
/// That is the wing's Welkin defect exactly (a rainbow that swept a 20-degree sliver under the
/// horizon and had never drawn in the product's life), and it is caught here only because the two
/// namespaces were written down. The caller passes the boolean because the caller is the only
/// thing that still knows the material's real name.
function arm_blade_parts(_form, _mat, _w, _y0, _seed, _watered) {
    var _s = arm_blade_spec(_form);
    var _map = arm_material_map(_mat);
    var _o = arm_blade_outline(_s, _w, _y0);

    var _out = arm_map_roles(arm_raise(_o, arm_bevel_cap(_o, 0.010), 2, "m2"), _map);
    _out = arm_append(_out, arm_blade_section_parts(_s, _w, _y0, _mat));
    if (_watered == true) {
        _out = arm_append(_out, arm_blade_watering_parts(_s, _w, _y0, _mat, _seed));
    }
    return _out;
}

/// Where a blade's point ends up in the unit box, given its shoulder. The hilt needs this to
/// decide whether the weapon fits, and the suite asserts against it.
function arm_blade_tip_y(_form, _y0) {
    return _y0 - arm_blade_spec(_form).len * ARM_METRE;
}
