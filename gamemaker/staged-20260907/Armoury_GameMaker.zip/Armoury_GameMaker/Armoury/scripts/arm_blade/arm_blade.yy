{
  "$GMScript": "v1",
  "%Name": "arm_blade",
  "name": "arm_blade",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}