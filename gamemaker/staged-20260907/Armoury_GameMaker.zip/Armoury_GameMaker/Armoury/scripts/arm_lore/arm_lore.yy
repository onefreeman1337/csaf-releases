{
  "$GMScript": "v1",
  "%Name": "arm_lore",
  "name": "arm_lore",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}