/// ARMOURY - arm_lore. The words and the numbers a weapon can tell you about itself.
///
/// ============================================================================================
/// ⭐ EVERY STRING AND EVERY NUMBER HERE IS DERIVED FROM THE WEAPON'S OWN STATE. There is no table
/// of names and no table of stats. Ask a weapon what it is and it answers from its geometry and
/// its history, which is why "a re-hafted militia billhook, notched" is a sentence this package
/// can produce and a sprite pack cannot.
///
/// ⛔ EVERY STRING IN THIS FILE IS PLAIN ASCII, 32..126, AND THAT IS A HARD CONSTRAINT, NOT A
/// STYLE. MEASURED on a sibling product 2026-08-30: the shipped fonts declare
/// "ranges":[{"lower":32,"upper":127}], so U+00B7 MIDDLE DOT (183) rendered as NOTHING - no error,
/// no warning, no missing-glyph box, just absence, which reads as a deliberate space. It reached
/// the cover, the hero sheet and the demo readout before anyone saw it. Use "-" not an en dash,
/// "'" not a curly quote, "..." not an ellipsis character. Internal_Ops/ascii_check.js enforces it.
/// ============================================================================================

/// A weapon's form as a buyer-facing noun. The corpus's internal names are terse on purpose;
/// these are what a player should see.
function arm_form_label(_form) {
    switch (_form) {
        case "dagger":     return "dagger";
        case "rondel":     return "rondel dagger";
        case "seax":       return "seax";
        case "tanto":      return "tanto";
        case "baselard":   return "baselard";
        case "gladius":    return "gladius";
        case "arming":     return "arming sword";
        case "spatha":     return "spatha";
        case "falchion":   return "falchion";
        case "sabre":      return "sabre";
        case "longsword":  return "longsword";
        case "estoc":      return "estoc";
        case "rapier":     return "rapier";
        case "greatsword": return "greatsword";
        case "kris":       return "kris";
        case "khopesh":    return "khopesh";
        case "cleaver":    return "cleaver";
        case "sickle":     return "war sickle";
        case "hatchet":    return "hatchet";
        case "bearded":    return "bearded axe";
        case "dane":       return "dane axe";
        case "broadaxe":   return "broadaxe";
        case "francisca":  return "francisca";
        case "poleaxe":    return "poleaxe";
        case "flanged":    return "flanged mace";
        case "knobbed":    return "knobbed mace";
        case "pernach":    return "pernach";
        case "morningstar":return "morningstar";
        case "warhammer":  return "war hammer";
        case "maul":       return "maul";
        case "pick":       return "war pick";
        case "spear":      return "spear";
        case "lance":      return "lance";
        case "partisan":   return "partisan";
        case "glaive":     return "glaive";
        case "billhook":   return "billhook";
        case "halberd":    return "halberd";
    }
    return _form;
}

/// A material as a buyer-facing noun.
function arm_material_label(_mat) {
    switch (_mat) {
        case "bogiron":   return "bog iron";
        case "iron":      return "wrought iron";
        case "steel":     return "steel";
        case "watered":   return "watered steel";
        case "blackened": return "blackened steel";
        case "bronze":    return "bronze";
        case "brass":     return "brass";
        case "silver":    return "silver";
        case "gold":      return "gold";
        case "meteoric":  return "sky-iron";
        case "gilt":      return "gilt";
        case "niello":    return "niello";
        case "ash":       return "ash";
        case "oak":       return "oak";
        case "yew":       return "yew";
        case "horn":      return "horn";
        case "bone":      return "bone";
        case "leather":   return "leather";
        case "cord":      return "cord";
        case "wire":      return "wire";
    }
    return _mat;
}

/// The one adjective that best describes this weapon's condition.
///
/// ⚠️ IT PICKS ONE, AND THAT IS THE DESIGN. A weapon that is "worn, notched, rusted, honed and
/// re-hafted" is a list, and a list is what a stat block looks like rather than what a person
/// says. The ordering below is a priority: the most striking thing about the object wins.
function arm_condition_word(_w) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_w)) return "";
    var _h = _w.history;
    if (_h.bend > 0.15) return "bent";
    var _d = arm_history_decay(_h);
    var _n = array_length(arm_history_notches(_h));
    if (_d > 0.72) return "corroded";
    if (_n >= 5) return "notched";
    if (arm_history_hone(_h) > 0.55) return "worn thin";
    if (_d > 0.38) return "pitted";
    if (_n >= 2) return "chipped";
    if (_h.age < 3 && _h.battles < 0.05) return "new";
    return "sound";
}

/// A short name for the weapon, derived from what it is and what has happened to it.
function arm_name(_w) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_w)) return "";
    var _h = _w.history;
    var _cond = arm_condition_word(_w);
    var _label = arm_form_label(_w.form);
    var _class = _h.class;

    // "new" and "sound" are not worth saying, so the class carries the sentence instead.
    var _lead = (_cond == "new" || _cond == "sound") ? _class : (_cond + " " + _class);
    var _art = "A ";
    var _c0 = string_char_at(_lead, 1);
    if (_c0 == "a" || _c0 == "e" || _c0 == "i" || _c0 == "o" || _c0 == "u") _art = "An ";
    var _s = _art + _lead + " " + _label;
    if (_h.rehafted && _w.family != "sword") _s += ", re-hafted";
    return _s;
}

/// A longer description: what it is made of, and what it has been through.
function arm_describe(_w) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_w)) return "";
    var _h = _w.history;
    var _s = arm_material_label(_w.edge_mat);
    if (_w.family == "sword") {
        _s += " blade, " + arm_material_label(_w.fit_mat) + " furniture";
        if (_w.grip_mat != "none") _s += ", " + arm_material_label(_w.grip_mat) + " grip";
    } else {
        _s += " head on " + arm_material_label(_w.haft_mat);
        if (_h.rehafted) _s += " (re-hafted)";
    }
    _s += ". " + string(floor(_h.age)) + " years old";
    var _n = array_length(arm_history_notches(_h));
    if (_n > 0) _s += ", " + string(_n) + " notch" + ((_n == 1) ? "" : "es") + " in the edge";
    var _hone = arm_history_hone(_h);
    if (_hone > 0.20) _s += ", ground back " + string(round(_hone * 30)) + " percent";
    if (array_length(_h.marks) > 0) {
        _s += ", " + string(array_length(_h.marks)) + " owner's mark"
           + ((array_length(_h.marks) == 1) ? "" : "s");
    }
    return _s + ".";
}

/// ============================================================================================
/// STATS THE GEOMETRY ACTUALLY IMPLIES
///
/// ⭐ THESE ARE NOT ROLLED AND THEY ARE NOT A TABLE. Reach is the weapon's real length. Mass comes
/// from its real dimensions and the real density of what it is made of. Balance is the centre of
/// mass of the parts, which is why putting a heavy wheel pommel on a sword moves it toward the
/// hand exactly as it does in life.
///
/// ⚠️ AND THEY MOVE WITH THE HISTORY, which is the part worth having. A blade ground back a third
/// of its width is LIGHTER and BETTER BALANCED than it was new, and that is a real and slightly
/// surprising fact about old swords that a game can hand a player for free.
/// ============================================================================================

/// Density in kg per cubic metre, for the mass model below.
function arm_density(_mat) {
    switch (_mat) {
        case "bogiron": case "iron": case "steel": case "watered":
        case "blackened": case "meteoric": return 7800;
        case "bronze": case "brass":        return 8600;
        case "silver": case "gilt":         return 10500;
        case "gold":                        return 19300;
        case "niello":                      return 7000;
        case "ash": case "oak": case "yew": return 700;
        case "horn": case "bone":           return 1300;
        case "leather": case "cord":        return 900;
        case "wire":                        return 8600;
    }
    return 7800;
}

/// A weapon's mass in kilograms, from its own dimensions.
///
/// ⚠️ THE 0.62 IS A SOLIDITY FACTOR AND IT IS HONEST ABOUT BEING ONE. A blade is not a box: it is
/// a lens in section, it tapers, and a fuller takes metal out of it. Multiplying the bounding
/// volume by a constant is an approximation, it is stated as one, and it lands every form in the
/// corpus inside the range real examples of that form actually weigh - which is the only test of
/// an approximation that matters.
function arm_mass_kg(_w) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_w)) return 0;
    var _h = _w.history;
    var _hone = arm_history_hone(_h);
    var _m = 0;

    if (_w.family == "sword") {
        var _s = arm_blade_spec(_w.form);
        var _thick = 0.0045 + _s.wid * 0.055;
        _m += _s.len * _s.wid * (1.0 - 0.30 * _hone) * _thick * 0.62 * arm_density(_w.edge_mat);
        // Pommel and guard, as solids of their own nominal size.
        var _pr = 0.020 + 0.010 * _s.wid / 0.05;
        _m += (4.0 / 3.0) * pi * power(_pr, 3) * 0.55 * arm_density(_w.fit_mat);
        _m += arm_grip_length_m(_w.form) * 0.030 * 0.024 * arm_density(_w.haft_mat);
    } else {
        var _len = arm_form_length_m(_w.form);
        var _hs = arm_head_spec(_w.form);
        var _hv = 0.00028;
        switch (_hs.kind) {
            case "axe":     _hv = _hs.reach * (_hs.rise + _hs.drop) * 0.010 * 0.50; break;
            case "mace":    _hv = pi * _hs.hrad * _hs.hrad * _hs.hlen * 0.55; break;
            case "hammer":  _hv = _hs.face * _hs.face * _hs.flen * 0.80; break;
            case "polearm": _hv = _hs.hlen * 0.045 * 0.006 * 0.62; break;
        }
        _m += _hv * arm_density(_w.edge_mat);
        _m += _len * pi * 0.017 * 0.017 * arm_density(_w.haft_mat);
    }
    return _m;
}

/// Where the weapon balances, in centimetres FORWARD OF THE GUARD. This is how sword balance is
/// actually quoted, and a negative number - which a heavy-pommelled short blade really can give -
/// means it balances behind the hand.
function arm_balance_cm(_w) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_w)) return 0;
    var _h = _w.history;
    var _hone = arm_history_hone(_h);

    if (_w.family != "sword") {
        // A hafted weapon's balance is dominated by the head, so it is quoted from the butt.
        var _len = arm_form_length_m(_w.form);
        var _hm = arm_mass_kg(_w) * 0.62;
        var _sm = arm_mass_kg(_w) * 0.38;
        return ((_hm * _len + _sm * _len * 0.5) / max(0.0001, _hm + _sm)) * 100;
    }

    var _s = arm_blade_spec(_w.form);
    var _thick = 0.0045 + _s.wid * 0.055;
    var _bm = _s.len * _s.wid * (1.0 - 0.30 * _hone) * _thick * 0.62 * arm_density(_w.edge_mat);
    var _pr = 0.020 + 0.010 * _s.wid / 0.05;
    var _pm = (4.0 / 3.0) * pi * power(_pr, 3) * 0.55 * arm_density(_w.fit_mat);
    var _gl = arm_grip_length_m(_w.form);
    var _gm = _gl * 0.030 * 0.024 * arm_density(_w.haft_mat);

    // Measured from the guard: the blade's centroid is about 42 percent of its length out (it is
    // wider at the base), the grip's is half its length back, the pommel's is at the very end.
    var _num = _bm * (_s.len * 0.42) + _gm * (-_gl * 0.5) + _pm * (-_gl - _pr);
    return (_num / max(0.0001, _bm + _gm + _pm)) * 100;
}

/// A one-line stat readout. What a tooltip would show.
function arm_stat_line(_w) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_w)) return "";
    return "reach " + string(round(arm_form_length_m(_w.form) * 100)) + " cm"
         + "   mass " + string(round(arm_mass_kg(_w) * 100) / 100) + " kg"
         + "   balance " + string(round(arm_balance_cm(_w))) + " cm";
}
