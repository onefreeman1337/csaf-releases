/// ARMOURY - arm_history. What a weapon has DONE, and what that did to it.
///
/// ============================================================================================
/// ⭐⭐ THIS FILE IS THE PRODUCT.
///
/// Fifty weapon assets were measured on itch's GameMaker shelf and every one of them is static
/// art: a fixed set of pictures, drawn once, identical in every game that buys them. The two most
/// expensive ship 270 images and 1,500 icons respectively, and NEITHER of them - nor anything else
/// on that shelf - records a single thing about what an item has been through.
///
/// A generator that only randomises appearance answers that with more pictures, which is a
/// quantitative reply to a qualitative problem and loses on price. What a sprite sheet cannot do
/// at any count is let a weapon CHANGE. The sword the player carried out of the first town is not
/// supposed to be the sword they carry into the last dungeon, and every game that wants that today
/// swaps one sprite for another and hopes nobody looks.
///
/// So: a weapon here owns a history, the history derives its appearance, and arm_history_use()
/// advances it. The same steel, forty fights later, is narrower from honing, notched where it
/// actually parries, rusted where it was not oiled, and re-gripped by whoever owns it now.
///
/// -- THE COUPLING THAT MAKES IT FEEL REAL ----------------------------------------------------
///
/// ⭐ CARE TURNS NOTCHES INTO HONING, and that one line is worth more than the rest of the model.
/// A soldier who looks after a sword grinds the notches OUT of it, which means a well-kept old
/// blade is not an unmarked blade - it is a NARROW one, because forty years of grinding have eaten
/// a third of its width. A neglected blade of the same age is full width and full of notches.
///
/// Those are two completely different silhouettes arising from one number, and neither of them is
/// "the new sword with a dirt filter on it", which is what wear normally means in a game.
/// ============================================================================================

/// The provenance classes. A class is not a rarity tier - it is a STORY about where the weapon
/// came from, and each one sets a different combination of quality, age, use and care.
function arm_provenance_names() {
    return ["issue", "militia", "guild", "temple", "looted", "heirloom", "grave"];
}

#macro ARM_PROV_N 7

/// What a class means, before any dice are rolled.
///
///   quality  0..1, what it was when it was made
///   age      years
///   battles  how much it has been used in anger
///   care     0..1, how well it has been looked after
///   owners   how many hands it has passed through
///   bend     a ritually "killed" blade, bent before burial
function arm_provenance_spec(_class) {
    switch (_class) {
        case "issue":    return { quality: 0.42, age:   6, battles: 0.35, care: 0.62, owners: 1, bend: 0 };
        case "militia":  return { quality: 0.16, age:  14, battles: 0.30, care: 0.20, owners: 2, bend: 0 };
        case "guild":    return { quality: 0.66, age:  10, battles: 0.20, care: 0.86, owners: 1, bend: 0 };
        case "temple":   return { quality: 0.95, age:  40, battles: 0.02, care: 0.98, owners: 1, bend: 0 };
        case "looted":   return { quality: 0.55, age:  22, battles: 0.72, care: 0.30, owners: 3, bend: 0 };
        case "heirloom": return { quality: 0.78, age: 120, battles: 0.55, care: 0.94, owners: 4, bend: 0 };
        // ⭐ A GRAVE-GOODS BLADE IS BENT, AND IT IS BENT ON PURPOSE. Ritually "killing" a sword
        // before burying it with its owner is a real and widespread practice, and it produces a
        // silhouette that no weapon pack on any shelf ships, because nobody draws a bent sword by
        // accident. It is the single most distinctive thing this corpus can produce.
        case "grave":    return { quality: 0.60, age: 900, battles: 0.45, care: 0.00, owners: 1, bend: 0.62 };
    }
    return arm_provenance_spec("issue");
}

/// ============================================================================================
/// BUILDING A HISTORY
/// ============================================================================================

/// A weapon's history, derived from its class and its seed.
///
/// ⚠️ EVERY FIELD HERE IS DATA, NOT GEOMETRY. Nothing in this file draws anything. That split is
/// what lets a buyer store a weapon as this struct, save it, load it, mutate it from their own
/// combat code and hand it back to the renderer - which is the difference between a system and a
/// picture generator.
function arm_history_new(_class, _seed) {
    var _p = arm_provenance_spec(_class);
    var _r = arm_rng(_seed ^ 0x4157);

    var _age = _p.age * (0.65 + 0.70 * arm_rng_next(_r));
    var _battles = clamp(_p.battles * (0.55 + 0.90 * arm_rng_next(_r)), 0, 1);
    var _care = clamp(_p.care + (arm_rng_next(_r) - 0.5) * 0.18, 0, 1);

    var _h = {
        class: _class,
        seed: _seed,
        quality: clamp(_p.quality + (arm_rng_next(_r) - 0.5) * 0.14, 0, 1),
        age: _age,
        battles: _battles,
        care: _care,
        owners: _p.owners,
        bend: _p.bend * (0.7 + 0.6 * arm_rng_next(_r)),
        rehafted: 0,
        marks: [],
    };

    // A weapon that has been through many hands and much use has usually been re-hafted at least
    // once, because the haft is the part that breaks. This is what puts a fifty-year-old head on
    // a five-year-old pole, which is one of the corpus's best pictures.
    if (_p.owners >= 2 && arm_rng_next(_r) < 0.30 + 0.45 * _battles) _h.rehafted = 1;

    // One mark per owner after the first. Each owner did something to it.
    var _kinds = ["stamp", "tally", "inlay", "rewrap", "peen"];
    for (var _i = 1; _i < _p.owners; _i++) {
        array_push(_h.marks, _kinds[floor(arm_rng_next(_r) * array_length(_kinds))]);
    }
    // A guild or temple piece carries its maker's stamp regardless of how many owners it has had.
    if (_class == "guild" || _class == "temple" || _class == "issue") {
        array_push(_h.marks, "stamp");
    }
    return _h;
}

/// ============================================================================================
/// FROM HISTORY TO WEAR
/// ============================================================================================

/// How far a weapon has corroded, 0..1.
///
/// Age drives it and care fights it, and the relationship is NOT linear in either: a weapon that
/// is oiled after every use barely corrodes for decades, and one that is never oiled is red inside
/// a couple of winters. The exponent is what produces that, and it is why `care` at 0.9 and at 1.0
/// are visibly different weapons while 0.1 and 0.2 are not.
function arm_history_decay(_h) {
    var _exposure = (_h.age / 60.0) * power(1.0 - _h.care, 1.7);
    return clamp(1.0 - exp(-_exposure * 2.2), 0, 1);
}

/// How far the blade has been ground back, 0..1.
///
/// ⭐ THIS IS THE COUPLING FROM THE HEADER. Every fight puts notches in an edge. A careful owner
/// grinds them out, which removes metal; a careless one leaves them. So care does not reduce the
/// damage a weapon has taken - it MOVES it, from the silhouette into the width.
function arm_history_hone(_h) {
    var _fights = _h.battles * (1.0 + _h.age / 90.0);
    return clamp(_fights * _h.care * 0.85, 0, 1);
}

/// The notches still in the edge. See arm_blade's NOTCHES section for why these cut the outline.
///
/// ⛔ NOTCHES ARE NOT UNIFORMLY DISTRIBUTED AND THAT IS THE DIFFERENCE BETWEEN THIS AND NOISE. A
/// sword is not damaged evenly along its length. It takes cuts in two places, for two reasons:
///
///   - the PERCUSSIVE CENTRE, around 0.6 to 0.85 of the way to the point, which is the part that
///     actually lands on things;
///   - the FORTE, the first fifth nearest the guard, which is what you parry with.
///
/// The stretch between them is comparatively clean on every worn blade in every museum case, and
/// scattering damage uniformly is the tell that a wear system was written without looking at one.
function arm_history_notches(_h) {
    var _out = [];
    var _left = 1.0 - _h.care;
    var _n = floor(_h.battles * _left * 11.0);
    if (_n <= 0) return _out;
    var _r = arm_rng(_h.seed ^ 0x0C17);

    for (var _i = 0; _i < _n; _i++) {
        var _t;
        if (arm_rng_next(_r) < 0.72) {
            _t = 0.60 + 0.25 * arm_rng_next(_r);            // percussive centre
        } else {
            _t = 0.04 + 0.16 * arm_rng_next(_r);            // forte, from parrying
        }
        // ⚠️ DEPTH IS A FRACTION OF THE HALF-WIDTH AND IT IS TUNED FOR LEGIBILITY, NOT FOR REALISM.
        // A real notch in a real sword is a millimetre or two, which at a 32px inventory icon is
        // nothing at all - the first bake put notches on the argument sheet that were 2 px deep and
        // invisible, so the sheet claimed damage the picture did not show. That is a market claim
        // the image does not support. These are deliberately larger than life, and they are still
        // bounded well below the fuller so a notched blade never reads as a saw.
        array_push(_out, {
            t: _t,
            d: 0.14 + 0.40 * arm_rng_next(_r) * _h.battles,
            w: 0.016 + 0.034 * arm_rng_next(_r),
        });
    }
    return _out;
}

/// The wear struct arm_blade draws from. This is the ONE place history becomes geometry.
function arm_history_wear(_h) {
    return {
        hone: arm_history_hone(_h),
        bend: _h.bend,
        notches: arm_history_notches(_h),
        // A tip goes when a weapon is used hard and not looked after. It is capped well below 1
        // because a sword with no point at all is a bar, and the corpus should not produce one by
        // accident.
        tip: clamp(_h.battles * (1.0 - _h.care) * 0.9, 0, 0.62),
    };
}

/// ============================================================================================
/// USING THE WEAPON - the half that makes this a system rather than a generator
/// ============================================================================================

/// Advance a weapon's history by _fights fights and _years years, and hand back a NEW history.
///
/// ⛔ IT RETURNS A NEW STRUCT AND DOES NOT MUTATE THE ONE IT IS GIVEN. A buyer will call this from
/// combat code, quite possibly while the old weapon is still being drawn this frame, and mutating
/// in place is how a weapon changes shape halfway down a draw event. It also means the caller can
/// diff the two - which is what a "your sword is looking worn" message needs.
///
/// ⚠️ `_care` IS THE CALLER'S, NOT THE WEAPON'S, and that is the interesting parameter. It is
/// whether the player oiled and ground it, which is a thing a game can let them choose, and it is
/// the entire difference between a narrow polished heirloom and a notched red ruin forty fights
/// from now.
function arm_history_use(_h, _fights, _years, _care) {
    var _n = {
        class: _h.class,
        seed: _h.seed,
        quality: _h.quality,
        age: _h.age + max(0, _years),
        battles: clamp(_h.battles + max(0, _fights) * 0.02, 0, 1),
        care: is_undefined(_care) ? _h.care : clamp(lerp(_h.care, _care, 0.35), 0, 1),
        owners: _h.owners,
        bend: _h.bend,
        rehafted: _h.rehafted,
        marks: _h.marks,
    };
    return _n;
}

/// Re-haft a weapon: a new pole, the old head. Returns a new history.
function arm_history_rehaft(_h) {
    var _n = arm_history_use(_h, 0, 0, undefined);
    _n.rehafted = 1;
    return _n;
}

/// Add an owner, and the mark they leave. Returns a new history.
///
/// ⚠️ THE MARKS ARRAY IS COPIED, not pushed onto. arm_history_use hands the SAME array reference
/// to the new struct - which is correct and cheap for a history that is not gaining marks - so
/// pushing here without copying would silently add the mark to every earlier version of the weapon
/// the caller is still holding, including the one on screen.
function arm_history_add_owner(_h, _mark) {
    var _n = arm_history_use(_h, 0, 0, undefined);
    var _m = [];
    for (var _i = 0; _i < array_length(_h.marks); _i++) array_push(_m, _h.marks[_i]);
    array_push(_m, is_undefined(_mark) ? "stamp" : _mark);
    _n.marks = _m;
    _n.owners = _h.owners + 1;
    return _n;
}
