{
  "$GMScript": "v1",
  "%Name": "arm_forge",
  "name": "arm_forge",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}