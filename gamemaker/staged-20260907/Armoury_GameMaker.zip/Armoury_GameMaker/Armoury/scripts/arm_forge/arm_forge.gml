/// ARMOURY - arm_forge. The assembler, and the whole public API a buyer touches.
///
/// ============================================================================================
/// -- THE FIVE CALLS THAT MATTER --------------------------------------------------------------
///
///   var w = arm_forge("arming", "militia", 1234);   // a weapon
///   arm_draw(w, x, y, 96);                          // draw it, 96 px tall
///   arm_draw_icon(w, x, y, 32);                     // draw it in an inventory cell
///   w = arm_use(w, 3);                              // three fights later
///   arm_name(w)                                     // "A notched militia billhook"
///
/// Everything else in this package is reachable from those, and nothing else needs to be.
///
/// -- WHAT A WEAPON IS ------------------------------------------------------------------------
///
/// A struct. It holds its form, its materials, its history and a cached part list, and it is
/// plain data all the way down - no instances, no sprites, no surfaces, nothing that has to be
/// freed. A buyer can put one in a save file with json_stringify and get it back.
///
/// ⛔ THE PART LIST IS CACHED AND THE CACHE IS KEYED ON THE HISTORY, NOT ON A DIRTY FLAG. A dirty
/// flag is a thing a caller can forget to set, and the failure mode is a weapon that visibly does
/// not change when the game says it changed. arm_forge_parts compares a cheap fingerprint of the
/// history it drew last time against the one it has now, so the cache cannot go stale without
/// somebody defeating it on purpose.
/// ============================================================================================

/// ⚠️ HOW A WEAPON IS LAID OUT, and why the butt is the anchor.
///
/// Everything is measured from the BUTT, at ARM_GROUND, running upward in negative y:
///
///     butt ---- pommel ---- grip ---- guard ---- blade/haft ---- head
///
/// The butt is the anchor because it is the part that does not move. A weapon is held near the
/// butt, so a buyer drawing a weapon in a hand wants the hand's position to stay put while the
/// blade changes length - and every one of the forms here has a different length. Anchoring at the
/// centre, which is the obvious choice, makes a longsword and a dagger drawn in the same hand sit
/// at two different heights.
///
/// ⚠️ AND IT IS WHY arm_draw TAKES A HEIGHT RATHER THAN A SCALE. A scale factor means a buyer has
/// to know the corpus's internal units to draw a weapon 96 pixels tall, which is the one thing
/// they always want to do.

/// The weapon families, which is what decides how a form is assembled.
function arm_family_of(_form) {
    var _b = arm_blade_names();
    for (var _i = 0; _i < array_length(_b); _i++) if (_b[_i] == _form) return "sword";
    var _h = arm_head_names();
    for (var _j = 0; _j < array_length(_h); _j++) {
        if (_h[_j] == _form) return (arm_head_spec(_form).kind == "polearm") ? "polearm" : "hafted";
    }
    return "sword";
}

/// Every form the package can make, in catalogue order.
function arm_form_names() {
    return arm_append(arm_blade_names(), arm_head_names());
}

#macro ARM_FORM_N 37

/// How long the whole weapon is, in metres. Derived from the form, never stored.
///
/// ⚠️ A HAFTED WEAPON'S LENGTH IS MOSTLY ITS HAFT, and the haft length is a property of how the
/// weapon is USED rather than of its head: a hatchet and a poleaxe can carry the same bit. So the
/// haft is a table here rather than a field on the head spec, which is where it would have gone if
/// it were a property of the head.
function arm_form_length_m(_form) {
    switch (arm_family_of(_form)) {
        case "sword": {
            var _s = arm_blade_spec(_form);
            // Blade, plus a grip proportioned to it. A greatsword's grip is a third of its blade;
            // a dagger's is almost as long as its own blade, because a hand is a fixed size.
            return _s.len + arm_grip_length_m(_form);
        }
        case "hafted": {
            switch (_form) {
                case "hatchet":   return 0.42;
                case "bearded":   return 0.78;
                case "dane":      return 1.25;
                case "broadaxe":  return 0.86;
                case "francisca": return 0.40;
                case "poleaxe":   return 1.70;
                case "flanged":   case "knobbed": case "pernach": return 0.62;
                case "morningstar": return 0.68;
                case "warhammer": return 0.72;
                case "maul":      return 0.95;
                case "pick":      return 0.58;
            }
            return 0.70;
        }
        case "polearm": {
            switch (_form) {
                case "spear":    return 2.05;
                case "lance":    return 2.20;
                case "partisan": return 1.95;
                case "glaive":   return 2.00;
                case "billhook": return 1.90;
                case "halberd":  return 1.85;
            }
            return 2.00;
        }
    }
    return 1.0;
}

/// The grip length for a sword form, in metres. A hand is 0.10 m wide and that is the constant
/// this whole table is really made of.
function arm_grip_length_m(_form) {
    var _s = arm_blade_spec(_form);
    if (_s.len < 0.40) return 0.105;                    // one hand, short
    if (_s.len < 0.90) return 0.115;                    // one hand
    if (_s.len < 1.10) return 0.230;                    // hand and a half
    return 0.320;                                        // two hands
}

/// ============================================================================================
/// FORGING
/// ============================================================================================

/// Make a weapon.
///
///   _form   any name from arm_form_names()
///   _class  any name from arm_provenance_names(), or undefined for "issue"
///   _seed   any integer. The same three arguments always give the same weapon.
function arm_forge(_form, _class, _seed) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    //
    // ⚠️ THIS IS A WIDENING OF THE DEFAULTS THAT WERE ALREADY HERE, not a new branch. Both lines
    // read `is_undefined(x) ? default : x`, so an omitted argument fell back and a WRONG-TYPED one
    // went straight through. A string seed then reached `_sd ^ 0xF04E` and threw
    // "unable to convert string 'xyzzy' to int64" — the only crash left in the adversarial harness
    // after the first round of guards, and one the first round had MASKED, because every caller of
    // arm_forge died earlier on its own unguarded dereference. One pass does not clear a family.
    //
    // A bad type now lands on the SAME default an omitted argument already had, which is the one
    // behaviour a caller can already reason about. Valid input is untouched: every real class is a
    // string and every real seed is a number.
    var _c = is_string(_class) ? _class : "issue";
    var _sd = is_real(_seed) ? _seed : 1;
    var _h = arm_history_new(_c, _sd);
    var _r = arm_rng(_sd ^ 0xF04E);

    var _w = {
        form: _form,
        family: arm_family_of(_form),
        history: _h,
        // Materials are chosen from the weapon's QUALITY, which the class set. A militia billhook
        // and a temple billhook are the same geometry in different metals, and that is most of
        // what makes them look like different objects.
        edge_mat: arm_edge_metal_for(_h.quality, _r),
        fit_mat: arm_fitting_metal_for(_h.quality, _r),
        haft_mat: arm_haft_wood_for(_h.quality, _r),
        grip_mat: arm_grip_cover_for(_h.quality, _r),
        pommel: arm_pommel_names()[floor(arm_rng_next(_r) * ARM_POMMEL_N)],
        guard: arm_guard_names()[floor(arm_rng_next(_r) * ARM_GUARD_N)],
        cache: undefined,
        cache_key: "",
    };

    // ⚠️ A GUARD IS NOT FREE AND A POOR WEAPON DOES NOT HAVE ONE. Basket and shell hilts are late,
    // expensive and made by specialists; putting one on a bog-iron militia sword is the single
    // fastest way to make a corpus look randomised rather than designed.
    if (_w.family == "sword") {
        if (_h.quality < 0.30) _w.guard = (arm_rng_next(_r) < 0.5) ? "cross" : "none";
        else if (_h.quality < 0.62 && (_w.guard == "basket" || _w.guard == "shell")) _w.guard = "cross";
    } else {
        // ⛔ LANGETS ARE FOR AN AXE, AND ONLY FOR AN AXE. They are the straps that stop a BIT being
        // cut off its shaft, so they belong where there is a bit to lose: an axe head or a polearm
        // blade. A mace or a hammer head is a socketed lump with nothing to shear off, and putting
        // straps on one drew two brass bars straight across every mace face in the corpus.
        var _hk = arm_head_spec(_form).kind;
        var _lang = (_hk == "axe" || _hk == "polearm");
        _w.guard = (_lang && _h.quality > 0.40) ? "langets" : "none";
    }

    // A re-hafted weapon has a NEW haft on an OLD head, so its wood is fresh and pale while its
    // metal is not. One line, and it is one of the corpus's most legible stories.
    if (_h.rehafted) _w.haft_mat = "ash";

    return _w;
}

/// A cheap fingerprint of everything that changes the picture. The parts cache is keyed on this.
function arm_forge_key(_w) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_w)) return "";
    var _h = _w.history;
    return _w.form + "|" + _w.edge_mat + "|" + _w.fit_mat + "|" + _w.haft_mat + "|"
         + _w.grip_mat + "|" + _w.pommel + "|" + _w.guard + "|"
         + string(round(_h.age * 4)) + "|" + string(round(_h.battles * 200)) + "|"
         + string(round(_h.care * 200)) + "|" + string(_h.rehafted) + "|"
         + string(round(_h.bend * 200)) + "|" + string(array_length(_h.marks));
}

/// ============================================================================================
/// ASSEMBLY
/// ============================================================================================

/// Build the part list for a weapon. Cached; see this file's header for why the key is a
/// fingerprint and not a flag.
function arm_forge_parts(_w) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_w)) return [];
    var _key = arm_forge_key(_w);
    if (_w.cache_key == _key && !is_undefined(_w.cache)) return _w.cache;

    var _h = _w.history;
    var _wear = arm_history_wear(_h);
    var _decay = arm_history_decay(_h);
    var _out = [];
    var _seed = _h.seed;

    // Materials resolve to palette prefixes here, once. Everything below draws through them.
    var _pal_edge = "e", _pal_fit = "f", _pal_haft = "h", _pal_grip = "g";

    if (_w.family == "sword") {
        var _bs = arm_blade_spec(_w.form);
        var _glen = arm_grip_length_m(_w.form) * ARM_METRE;
        var _pr = 0.020 + 0.010 * _bs.wid / 0.05;
        var _drop = arm_pommel_drop(_w.pommel) * _pr * ARM_METRE;

        var _y_butt = ARM_GROUND;
        var _y_gripbot = _y_butt - _drop;
        var _y_griptop = _y_gripbot - _glen;
        var _y_shoulder = _y_griptop;

        // ⛔ ORDER IS THE PICTURE (arm_hilt's guard section). Grip, then blade, then guard on top:
        // the blade's shoulder has to disappear INTO the guard, and it can only do that if the
        // guard is painted after it.
        _out = arm_append(_out, arm_grip_parts(_pal_haft, _pal_grip,
                                               _bs.wid * 0.42 * ARM_METRE,
                                               _y_gripbot, _y_griptop, _seed));
        // The watering flag is passed explicitly because the blade layer sees a palette PREFIX and
        // can no longer tell what metal it is. See arm_blade_parts' header.
        _out = arm_append(_out, arm_blade_parts(_w.form, _pal_edge, _wear, _y_shoulder, _seed,
                                                _w.edge_mat == "watered"));
        _out = arm_append(_out, arm_guard_parts(_w.guard, _pal_fit,
                                                _bs.wid * 1.85 * ARM_METRE, _y_shoulder, _seed));
        _out = arm_append(_out, arm_pommel_parts(_w.pommel, _pal_fit, _pr * ARM_METRE,
                                                 _y_butt, _seed));

    } else {
        var _len = arm_form_length_m(_w.form) * ARM_METRE;
        var _hr = arm_head_reach_m(_w.form) * ARM_METRE;
        var _y_butt2 = ARM_GROUND;
        var _y_haft_top = _y_butt2 - (_len - _hr);
        // Haft half-width in METRES, converted once. A polearm shaft is about 32 mm across and an
        // axe haft about 38 mm, and both are the same at every weapon length - a two-metre pike is
        // not a thicker stick than a spear, it is a longer one.
        var _hw = ((_w.family == "polearm") ? 0.016 : 0.019) * ARM_METRE;

        _out = arm_append(_out, arm_haft_parts(_pal_haft, _hw, _y_butt2, _y_haft_top,
                                               _pal_fit, _seed));
        _out = arm_append(_out, arm_head_parts(_w.form, _pal_edge, _y_haft_top, _seed, _wear));
        if (_w.guard == "langets") {
            _out = arm_append(_out, arm_guard_parts("langets", _pal_fit,
                                                    _hw * 2.4, _y_haft_top, _seed));
        }
    }

    _out = arm_append(_out, arm_mark_parts(_w, _decay));

    _w.cache = _out;
    _w.cache_key = _key;
    return _out;
}

/// The marks previous owners left. See arm_history for what each one means.
///
/// ⚠️ THESE ARE SMALL AND THEY ARE SUPPOSED TO BE. A maker's stamp on a real blade is four
/// millimetres across; blown up to be obvious it stops being a stamp and becomes a logo, which is
/// exactly the failure the wing's physical-detail law describes. They are legible on the hero
/// plate, suggestive at 96 px, and gone at 32 px, which is correct - a player squinting at an
/// inventory icon is not meant to read a maker's mark.
function arm_mark_parts(_w, _decay) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_w)) return [];
    var _out = [];
    var _h = _w.history;
    if (array_length(_h.marks) == 0) return _out;

    var _fmap = arm_material_map("f");
    var _r = arm_rng(_h.seed ^ 0x3A2C);
    var _sword = (_w.family == "sword");
    var _bs = _sword ? arm_blade_spec(_w.form) : undefined;
    var _y = ARM_GROUND - arm_form_length_m(_w.form) * ARM_METRE * 0.34;
    var _x = _sword ? (_bs.wid * 0.22 * ARM_METRE) : 0.012;

    // ⛔⛔ A STAMP IS SIZED TO THE THING IT IS STRUCK INTO. MEASURED 2026-08-30 on the heads sheet:
    // written as a flat 0.0085 in unit-box units, the maker's pit came out WIDER THAN THE HAFT it
    // sits on - a gold disc bulging off the side of every polearm in the corpus.
    //
    // This is the wing's physical-detail law from the other end. Livery's four instances were all
    // details that stayed proportional and grew absurd on a LARGE object; this one was absolute and
    // grew absurd on a SMALL one. Both bounds are needed, always: min(proportional, ABS_MAX) going
    // up and a proportional ceiling going down.
    var _host_hw = _sword ? (_bs.wid * 0.5 * ARM_METRE) : (0.016 * ARM_METRE);
    var _mr = min(0.0085, _host_hw * 0.55);

    for (var _i = 0; _i < array_length(_h.marks); _i++) {
        var _yy = _y - _i * 0.030;
        switch (_h.marks[_i]) {
            case "stamp":
                // A punched mark: a small pit with a bar struck into it.
                _out = arm_append(_out, arm_map_roles(arm_pit(_x, _yy, _mr, 9), _fmap));
                _out = arm_append(_out, arm_map_roles(arm_incise(
                    [[_x - _mr * 0.6, _yy], [_x + _mr * 0.6, _yy]], false, _mr * 0.26), _fmap));
                break;
            case "tally":
                // Notches filed into the pommel edge, one per year of service. A soldier's
                // scoreboard, and the only mark here that is a COUNT rather than a shape.
                for (var _k = 0; _k < 4; _k++) {
                    _out = arm_append(_out, arm_map_roles(arm_incise(
                        [[-0.011 + 0.0072 * _k, ARM_GROUND - 0.012],
                         [-0.011 + 0.0072 * _k, ARM_GROUND - 0.026]], false, 0.0020), _fmap));
                }
                break;
            case "inlay": {
                // A wire inlay running up the blade. Raised, not incised - the wire stands proud
                // of the groove it is hammered into, and drawing it sunken makes it a scratch.
                var _pts = [];
                for (var _j = 0; _j <= 8; _j++) {
                    array_push(_pts, [_x * 0.4, _yy - 0.055 + 0.014 * _j]);
                }
                _out = arm_append(_out, arm_map_roles(arm_ridge(_pts, false, 0.0026), _fmap));
                break;
            }
            case "peen":
                _out = arm_append(_out, arm_map_roles(
                    arm_boss(0, ARM_GROUND - 0.006, min(0.0075, _host_hw * 0.5), 9), _fmap));
                break;
            case "rewrap":
                // Handled by the grip material choice rather than by a mark; nothing to draw.
                break;
        }
    }
    return _out;
}

/// ============================================================================================
/// THE PALETTE
/// ============================================================================================

/// One weapon's palette: four ramps under the four prefixes the assembler uses, plus the flat
/// roles the renderer needs.
function arm_forge_palette(_w) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_w)) return undefined;
    var _decay = arm_history_decay(_w.history);
    var _pal = {};
    arm_material_into(_pal, "e", _w.edge_mat, _decay, 0);
    arm_material_into(_pal, "f", _w.fit_mat, _decay, 0);
    // ⚠️ A RE-HAFTED WEAPON'S WOOD IS YOUNGER THAN ITS METAL and must not take the same decay.
    // Passing one number to all four ramps is the obvious implementation and it throws away the
    // best story the history model produces.
    arm_material_into(_pal, "h", _w.haft_mat, _w.history.rehafted ? _decay * 0.15 : _decay, 0);
    arm_material_into(_pal, "g", _w.grip_mat, _decay * 0.75, 0);
    _pal.line = arm_material_ink(_w.edge_mat, _decay);
    _pal.ink = _pal.line;
    return _pal;
}

/// ============================================================================================
/// DRAWING
/// ============================================================================================

/// ⛔ THERE ARE TWO WAYS TO SIZE A WEAPON AND CONFLATING THEM IS A DESIGN BUG, NOT A CONVENIENCE.
///
/// "Draw this 96 pixels tall" and "draw this at 200 pixels per metre" are different questions with
/// different right answers, and a single `scale` argument silently picks one of them for the
/// caller. A first draft of the demo room tried to get the second out of the first with a chain of
/// ratios that cancelled to an arbitrary number - it compiled, it drew something, and it was
/// meaningless. Two named functions cost four lines and remove the whole class of mistake.
///
///   arm_draw          - an inventory slot, a shop row, a tooltip. Every weapon the same height.
///   arm_draw_at_scale - a rack, a world drop, a size comparison. Every weapon its TRUE size.

/// Draw a weapon exactly _h pixels tall, centred horizontally on _x with its BUTT at _y.
function arm_draw(_w, _x, _y, _h) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_w)) return;
    var _len_u = arm_form_length_m(_w.form) * ARM_METRE;
    arm_draw_at_scale(_w, _x, _y, _h / max(0.0001, _len_u));
}

/// Draw a weapon at _ppu pixels per unit-box unit, so that two weapons drawn at the same _ppu are
/// correctly sized against each other. ARM_METRE units per metre; see arm_blade's header.
function arm_draw_at_scale(_w, _x, _y, _ppu) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_w)) return;
    var _parts = arm_forge_parts(_w);
    var _pal = arm_forge_palette(_w);
    arm_render_parts(_parts, _pal, _x, _y - ARM_GROUND * _ppu, _ppu, 0, _ppu, undefined);
}

/// Draw a weapon fitted into a square inventory cell of _size pixels at (_x, _y).
///
/// ⭐ THE WEAPON IS ROTATED FOR THE CELL, and that is not decoration. A 2 m spear drawn upright in
/// a 32 px square is 32 pixels of nothing with a grey line up the middle. Every inventory in every
/// game lays long weapons on the diagonal for exactly this reason, and a weapon pack that does not
/// do it leaves the buyer to write it.
function arm_draw_icon(_w, _x, _y, _size) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_w)) return;
    var _parts = arm_forge_parts(_w);
    var _pal = arm_forge_palette(_w);
    var _len = arm_form_length_m(_w.form);
    var _rot = (_len > 0.55) ? 40 : 20;
    // ⚠️ arm_render_in_rect_tight FITS AT ROTATION ZERO and has no rotation parameter, so the
    // rotation has to happen BEFORE the fit or the weapon is fitted upright and then spun out of
    // its own cell. Rotating the parts first means the fitter measures the bounds it will actually
    // draw, which is the whole reason the tight fitter exists.
    var _turned = arm_place(_parts, 0, 0, 1, _rot, 1, undefined);
    arm_render_in_rect_tight(_turned, _pal, _x - _size * 0.5, _y - _size * 0.5,
                             _size, _size, undefined);
}

/// Advance a weapon by _fights fights, returning a NEW weapon. See arm_history_use.
function arm_use(_w, _fights, _years, _care) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_w)) return _w;
    var _n = arm_forge(_w.form, _w.history.class, _w.history.seed);
    _n.edge_mat = _w.edge_mat; _n.fit_mat = _w.fit_mat;
    _n.haft_mat = _w.haft_mat; _n.grip_mat = _w.grip_mat;
    _n.pommel = _w.pommel; _n.guard = _w.guard;
    _n.history = arm_history_use(_w.history, _fights,
                                 is_undefined(_years) ? 0 : _years, _care);
    return _n;
}
