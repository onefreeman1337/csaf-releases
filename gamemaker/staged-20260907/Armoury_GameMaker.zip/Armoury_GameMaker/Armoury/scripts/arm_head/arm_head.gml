/// ARMOURY - arm_head. Everything that goes on the END of a haft: axes, maces, hammers, picks
/// and polearm heads.
///
/// ============================================================================================
/// -- AN AXE HEAD IS ONE PIECE OF METAL AND MUST BE ONE OUTLINE -------------------------------
///
/// ⛔ THE WING HAS PAID FOR THIS ALREADY, ON A WAR HORN THAT READ AS THREE CHEVRONS: "a chain of
/// masses reads as a chain". Faking a continuous form out of an eye block, a cheek block and a
/// bit block bevels each on its OWN outline, so every join gets a lit edge running straight
/// across the object, and an axe becomes three plates riveted together.
///
/// A real axe head is forged from one bar - the eye is the bar wrapped round the haft and welded,
/// and the cheek and bit are the same metal drawn out. So every axe here is ONE closed outline,
/// walked as a single loop, and bevelled once. The places where a real axe DOES have separate
/// planes - a hammer poll, a back spike, langets - are separate masses, because there the eye
/// genuinely sees two pieces.
///
/// -- AND A POLEARM HEAD IS A BLADE ON A SOCKET -----------------------------------------------
///
/// ⭐ A SPEARHEAD IS NOT A NEW KIND OF OBJECT. It is a short leaf blade with a socket instead of a
/// tang, and a glaive is a long single-edged one, and a partisan is a leaf blade with two wings.
/// Building them out of arm_blade rather than out of a second geometry layer is not a shortcut -
/// it is the reason a partisan and a dagger share a profile law, a section, a honing model and a
/// notching model, and it is why adding "leaf" to the blade corpus improved four polearms at once.
///
/// The appendages that make a halberd a halberd (an axe bit on one side, a rear spike, a hook)
/// are the axe machinery above, re-aimed. Nothing here is a special case of nothing else.
/// ============================================================================================

/// A head specification.
///
///   kind    "axe" | "mace" | "hammer" | "polearm"
///   AXE:      reach forward extent (m), rise, drop, arc (bit curvature), beard 0..1,
///             poll "flat"|"spike"|"hammer", eye (m)
///   MACE:     hlen head length (m), hrad head radius (m), flanges n (0 = knobbed), knobs n
///   HAMMER:   face (m), flen face length (m), poll "spike"|"claw"|"flat", fluted 0/1
///   POLEARM:  blade (a blade form name), hlen override (m), wings 0/1, hook 0/1, axe 0/1,
///             rear "spike"|"hook"|"none"
function arm_head_spec(_form) {
    switch (_form) {
        // -- AXES -------------------------------------------------------------------------------
        case "hatchet":    return { kind: "axe", reach: 0.115, rise: 0.062, drop: 0.062, arc: 0.34, beard: 0.10, poll: "flat",   eye: 0.040 };
        case "bearded":    return { kind: "axe", reach: 0.145, rise: 0.055, drop: 0.150, arc: 0.28, beard: 0.92, poll: "flat",   eye: 0.042 };
        case "dane":       return { kind: "axe", reach: 0.165, rise: 0.135, drop: 0.135, arc: 0.52, beard: 0.28, poll: "flat",   eye: 0.038 };
        case "broadaxe":   return { kind: "axe", reach: 0.130, rise: 0.115, drop: 0.115, arc: 0.20, beard: 0.15, poll: "hammer", eye: 0.046 };
        case "francisca":  return { kind: "axe", reach: 0.120, rise: 0.090, drop: 0.030, arc: 0.44, beard: 0.05, poll: "flat",   eye: 0.036 };
        case "poleaxe":    return { kind: "axe", reach: 0.140, rise: 0.088, drop: 0.088, arc: 0.30, beard: 0.20, poll: "spike",  eye: 0.044 };

        // -- MACES ------------------------------------------------------------------------------
        case "flanged":    return { kind: "mace", hlen: 0.135, hrad: 0.046, flanges: 6, knobs: 0 };
        case "knobbed":    return { kind: "mace", hlen: 0.110, hrad: 0.048, flanges: 0, knobs: 7 };
        case "pernach":    return { kind: "mace", hlen: 0.120, hrad: 0.042, flanges: 4, knobs: 0 };
        case "morningstar":return { kind: "mace", hlen: 0.105, hrad: 0.050, flanges: 0, knobs: 12 };

        // -- HAMMERS AND PICKS ------------------------------------------------------------------
        case "warhammer":  return { kind: "hammer", face: 0.036, flen: 0.072, poll: "spike", fluted: 1 };
        case "maul":       return { kind: "hammer", face: 0.058, flen: 0.115, poll: "flat",  fluted: 0 };
        case "pick":       return { kind: "hammer", face: 0.026, flen: 0.038, poll: "claw",  fluted: 0 };

        // -- POLEARMS ---------------------------------------------------------------------------
        case "spear":      return { kind: "polearm", blade: "leaf",    hlen: 0.240, wings: 0, hook: 0, axe: 0, rear: "none"  };
        case "lance":      return { kind: "polearm", blade: "needle",  hlen: 0.200, wings: 0, hook: 0, axe: 0, rear: "none"  };
        case "partisan":   return { kind: "polearm", blade: "leaf",    hlen: 0.300, wings: 1, hook: 0, axe: 0, rear: "none"  };
        case "glaive":     return { kind: "polearm", blade: "glaive",  hlen: 0.420, wings: 0, hook: 0, axe: 0, rear: "spike" };
        case "billhook":   return { kind: "polearm", blade: "bill",    hlen: 0.330, wings: 0, hook: 1, axe: 0, rear: "spike" };
        case "halberd":    return { kind: "polearm", blade: "needle",  hlen: 0.280, wings: 0, hook: 0, axe: 1, rear: "spike" };
    }
    return arm_head_spec("hatchet");
}

/// The head forms, in corpus order.
function arm_head_names() {
    return ["hatchet", "bearded", "dane", "broadaxe", "francisca", "poleaxe",
            "flanged", "knobbed", "pernach", "morningstar",
            "warhammer", "maul", "pick",
            "spear", "lance", "partisan", "glaive", "billhook", "halberd"];
}

#macro ARM_HEAD_N 19

/// ============================================================================================
/// THE AXE
/// ============================================================================================

/// The single closed outline of an axe head, authored about the centre of its eye at (0,0).
///
/// Walked as one loop: up the back of the eye, forward along the top horn, round the bit's arc,
/// back along the underside and its beard, and home. There is no join anywhere in it.
///
/// ⚠️ THE BIT'S ARC IS SAMPLED FROM A CIRCLE THROUGH THREE POINTS AND IS NOT A CIRCLE. A real
/// axe edge is the arc of a very large circle, and drawing it as a small one gives the crescent
/// blade of a stage prop. Sampling a quadratic through the two horns and a mid point pushed out
/// by `arc` gives the shallow sweep a working axe has, and it degenerates correctly to a straight
/// edge when arc is 0.
function arm_axe_outline(_s) {
    var _e = _s.eye * 0.5;
    var _top = -_s.rise, _bot = _s.drop;
    var _pts = [];

    // ⛔⛔ AN AXE HAS A NECK, AND WITHOUT IT THE HEAD IS A PADDLE. MEASURED 2026-08-30 by baking the
    // heads sheet and looking at it: all six axes read as amorphous grey slabs stuck on a pole,
    // because this outline ran from the eye straight out to full rise and drop at the bit. That is
    // a trapezoid, and a trapezoid on a stick is a flag.
    //
    // The silhouette that says "axe" is NARROW AT THE HAFT AND WIDE AT THE EDGE, with the flare
    // happening in the outer half. The eye is a thick collar round the shaft, the neck is the
    // drawn-out bar between eye and bit, and only then does the metal spread. It is the same law
    // this wing learned on an axe-shaped emblem that kept reading as a flag: a shape on a pole
    // needs a narrow socket that FLARES, or the eye completes it as a banner.
    var _neck_t = _top * 0.30, _neck_b = _bot * 0.30;

    // Back of the eye - a shallow round, because the eye is the bar bent round the haft.
    array_push(_pts, [-_e * 1.55, _bot * 0.46]);
    array_push(_pts, [-_e * 1.95, 0]);
    array_push(_pts, [-_e * 1.55, _top * 0.46]);

    // The NECK: forward at nearly constant width, then the flare.
    array_push(_pts, [_e * 0.90, _neck_t]);
    array_push(_pts, [_s.reach * 0.42, _neck_t * 1.10]);
    var _horn_t = [_s.reach, _top];
    array_push(_pts, _horn_t);

    // The bit. A quadratic from the top horn to the bottom horn, bulged forward by `arc`.
    var _horn_b = [_s.reach, _bot];
    var _midy = (_top + _bot) * 0.5;
    var _ctrl = [_s.reach + _s.arc * (_bot - _top) * 0.90, _midy];
    var _bit = arm_qbez(_horn_t, _ctrl, _horn_b, 12);
    for (var _i = 1; _i < array_length(_bit); _i++) array_push(_pts, _bit[_i]);

    // The underside, and the beard: a bearded axe's lower horn hangs back TOWARD the haft, which
    // is what makes the shape, so the beard term pulls this point backward and downward at once.
    if (_s.beard > 0.02) {
        // A bearded axe's lower horn hangs BACK toward the haft as well as down, which is the whole
        // shape. The beard rejoins the neck rather than the eye, so the notch between beard and
        // haft stays open - that gap is what a hand hooks through.
        array_push(_pts, [_s.reach * (0.40 - 0.30 * _s.beard), _bot * (1.0 + 0.34 * _s.beard)]);
        array_push(_pts, [_s.reach * 0.30, _neck_b * 1.35]);
        array_push(_pts, [_e * 0.90, _neck_b]);
    } else {
        array_push(_pts, [_s.reach * 0.42, _neck_b * 1.10]);
        array_push(_pts, [_e * 0.90, _neck_b]);
    }

    return arm_dedupe_pts(_pts);
}

/// The poll - what is on the back of the axe, opposite the bit. A separate mass on purpose: a
/// hammer poll and a back spike are welded or forged as distinct planes and the eye sees them so.
function arm_axe_poll_parts(_s, _map) {
    var _e = _s.eye * 0.5;
    switch (_s.poll) {
        case "hammer": {
            var _pts = [[-_e * 1.85, -_e * 0.95], [-_e * 3.30, -_e * 0.80],
                        [-_e * 3.30,  _e * 0.80], [-_e * 1.85,  _e * 0.95]];
            return arm_map_roles(arm_raise(_pts, arm_bevel_cap(_pts, 0.006), 2, "m2"), _map);
        }
        case "spike": {
            var _sp = [[-_e * 1.80, -_e * 0.80], [-_e * 5.20, -_e * 0.16],
                       [-_e * 5.60, 0], [-_e * 5.20, _e * 0.16], [-_e * 1.80, _e * 0.80]];
            return arm_map_roles(arm_raise(_sp, arm_bevel_cap(_sp, 0.004), 2, "m2"), _map);
        }
    }
    return [];
}

/// ============================================================================================
/// THE MACE AND THE HAMMER
/// ============================================================================================

/// A flanged or knobbed mace head, authored about (0,0) with the haft entering from below.
///
/// ⛔ A FLANGE IS A SEPARATE PLANE AND A KNOB IS NOT. Flanges are welded plates standing off a
/// tube, so each one is its own mass with its own lit edge - that is what a flanged mace looks
/// like and drawing it as one lumpy outline loses the whole object. Knobs are forged INTO the
/// head, so they belong to its outline. Two different constructions for two different objects,
/// which is the distinction this file exists to keep.
function arm_mace_parts(_s, _map, _rng) {
    var _out = [];
    var _hl = _s.hlen, _hr = _s.hrad;

    if (_s.flanges > 0) {
        // The core drum first, so the flanges sit on it.
        var _core = arm_pts_round(-_hr * 0.42, -_hl * 0.5, _hr * 0.42, _hl * 0.5, _hr * 0.20, 5);
        _out = arm_append(_out, arm_map_roles(
            arm_raise(_core, arm_bevel_cap(_core, 0.006), 2, "m2"), _map));

        // Flanges, alternating left and right so a 2D view shows the count honestly. A six-flange
        // mace seen from the side shows two full flanges and the edges of the others, and drawing
        // all six as full plates is the tell of a drawing made from a description.
        var _pairs = max(1, floor(_s.flanges / 2));
        for (var _i = 0; _i < _pairs; _i++) {
            var _sgn = (_i % 2 == 0) ? 1 : -1;
            var _off = (_pairs == 1) ? 0 : (_i / (_pairs - 1) - 0.5) * _hl * 0.30;
            var _fl = [[_sgn * _hr * 0.36, -_hl * 0.42 + _off],
                       [_sgn * _hr * 1.00, -_hl * 0.20 + _off],
                       [_sgn * _hr * 1.00,  _hl * 0.22 + _off],
                       [_sgn * _hr * 0.36,  _hl * 0.44 + _off]];
            _out = arm_append(_out, arm_map_roles(
                arm_raise(_fl, arm_bevel_cap(_fl, 0.005), 2, "m3"), _map));
        }
        return _out;
    }

    // A knobbed head: one outline whose radius is modulated by the knob count.
    var _n = max(10, _s.knobs * 3);
    var _pts = [];
    for (var _i2 = 0; _i2 < _n; _i2++) {
        var _a = ARM_TAU * _i2 / _n;
        var _bump = 1.0 + 0.26 * power(max(0, cos(_s.knobs * _a * 0.5)), 2);
        array_push(_pts, [sin(_a) * _hr * _bump, -cos(_a) * _hl * 0.5 * _bump]);
    }
    _pts = arm_dedupe_pts(_pts);
    _out = arm_append(_out, arm_map_roles(
        arm_raise(_pts, arm_bevel_cap(_pts, 0.007), 2, "m2"), _map));
    return _out;
}

/// A hammer or pick head. The face and the poll are two masses on one axis, which is exactly what
/// they are on the real object.
function arm_hammer_parts(_s, _map) {
    var _out = [];
    var _f = _s.face * 0.5, _fl = _s.flen;

    // The face: a tapered block running forward, slightly larger at the striking end because a
    // hammer face is dressed proud so the edges do not bite.
    //
    // ⚠️ THE HEAD IS AUTHORED LYING ALONG +x AND THE HAFT RUNS ALONG y. A first draft wrote this
    // block with x and y swapped, which put the striking face where the eye is - and because every
    // number is symmetric about zero it still produced a plausible-looking block, which is the
    // kind of wrong that survives a glance at the geometry and fails on the sheet.
    var _face = [[_fl * 0.06, -_f * 0.86], [_fl * 1.00, -_f * 1.00],
                 [_fl * 1.00, _f * 1.00], [_fl * 0.06, _f * 0.86]];
    _out = arm_append(_out, arm_map_roles(
        arm_raise(_face, arm_bevel_cap(_face, 0.005), 2, "m2"), _map));

    if (_s.fluted) {
        // Four pyramidal teeth on the face. A war hammer's face is toothed to bite plate, and it
        // is the one detail that says "war hammer" rather than "carpenter's hammer" at icon size.
        for (var _i = 0; _i < 3; _i++) {
            var _y = -_f * 0.55 + _f * 0.55 * _i;
            var _t = [[_fl * 1.00, _y - _f * 0.16], [_fl * 1.20, _y],
                      [_fl * 1.00, _y + _f * 0.16]];
            _out = arm_append(_out, arm_map_roles(
                arm_raise(_t, arm_bevel_cap(_t, 0.003), 1, "m3"), _map));
        }
    }

    switch (_s.poll) {
        case "spike": {
            var _sp = [[-_fl * 0.06, -_f * 0.72], [-_fl * 2.30, -_f * 0.14],
                       [-_fl * 2.55, 0], [-_fl * 2.30, _f * 0.14], [-_fl * 0.06, _f * 0.72]];
            _out = arm_append(_out, arm_map_roles(
                arm_raise(_sp, arm_bevel_cap(_sp, 0.004), 2, "m2"), _map));
        } break;
        case "claw": {
            // A pick's claw is a CURVE, and a straight one reads as a second spike. The curve is
            // what lets it hook, and it is the whole difference between the two objects.
            var _c = arm_qbez([-_fl * 0.10, -_f * 0.80], [-_fl * 2.10, -_f * 1.30],
                              [-_fl * 3.00, _f * 0.30], 9);
            var _c2 = arm_qbez([-_fl * 3.00, _f * 0.30], [-_fl * 1.90, -_f * 0.50],
                               [-_fl * 0.10, _f * 0.80], 9);
            var _pts = arm_dedupe_pts(arm_append(_c, _c2));
            _out = arm_append(_out, arm_map_roles(
                arm_raise(_pts, arm_bevel_cap(_pts, 0.003), 2, "m2"), _map));
        } break;
        case "flat": {
            var _fp = [[-_fl * 0.06, -_f * 0.86], [-_fl * 0.75, -_f * 0.94],
                       [-_fl * 0.75, _f * 0.94], [-_fl * 0.06, _f * 0.86]];
            _out = arm_append(_out, arm_map_roles(
                arm_raise(_fp, arm_bevel_cap(_fp, 0.005), 2, "m2"), _map));
        } break;
    }
    return _out;
}

/// ============================================================================================
/// THE SOCKET
/// ============================================================================================

/// The socket or eye reinforcement where a head meets its haft. Always drawn, on every head:
/// a head that simply intersects a pole is the single most common way a drawn polearm looks like
/// two sprites overlapping.
function arm_socket_parts(_r, _len, _y0, _map) {
    // Authored in metres about _y0, exactly like every other builder in this file; the caller
    // converts. _r and _len are metres, _y0 is metres relative to the haft top.
    var _pts = arm_pts_round(-_r, _y0 - _len, _r, _y0, _r * 0.45, 5);
    var _out = arm_map_roles(arm_raise(_pts, arm_bevel_cap(_pts, 0.005), 2, "m2"), _map);
    // Two bands, because a socket is a rolled sheet held by rivets and the bands are where they
    // sit. Incised rather than drawn as lines: they are steps in the metal, not marks on it.
    _out = arm_append(_out, arm_map_roles(arm_incise(
        [[-_r, _y0 - _len * 0.22], [_r, _y0 - _len * 0.22]], false, 0.0035), _map));
    _out = arm_append(_out, arm_map_roles(arm_incise(
        [[-_r, _y0 - _len * 0.78], [_r, _y0 - _len * 0.78]], false, 0.0035), _map));
    return _out;
}

/// ============================================================================================
/// THE HEAD, ASSEMBLED
/// ============================================================================================

/// Every head in the corpus, placed with its business end at the top of a haft whose tip is at
/// _y0 in the unit box.
///
/// ⚠️ A HEAD'S OWN SPEC IS IN METRES AND IS CONVERTED HERE, ONCE, exactly as a blade's is. The
/// axe and mace builders above are written entirely in metres and know nothing about the unit box,
/// which is why they can be read against a photograph of a real object.
function arm_head_parts(_form, _mat, _y0, _seed, _wear) {
    var _s = arm_head_spec(_form);
    var _map = arm_material_map(_mat);
    var _rng = arm_rng(_seed ^ 0x11EAD);
    var _out = [];

    switch (_s.kind) {
        case "axe": {
            var _o = arm_axe_outline(_s);
            var _body = arm_map_roles(arm_raise(_o, arm_bevel_cap(_o, 0.008), 2, "m2"), _map);
            _out = arm_append(_out, arm_place(_body, 0, _y0, ARM_METRE, 0, ARM_METRE, undefined));
            var _poll = arm_axe_poll_parts(_s, _map);
            if (array_length(_poll) > 0) {
                _out = arm_append(_out, arm_place(_poll, 0, _y0, ARM_METRE, 0, ARM_METRE, undefined));
            }
        } break;

        case "mace": {
            var _m = arm_mace_parts(_s, _map, _rng);
            _out = arm_append(_out, arm_place(_m, 0, _y0 - _s.hlen * 0.5 * ARM_METRE,
                                              ARM_METRE, 0, ARM_METRE, undefined));
        } break;

        case "hammer": {
            var _h = arm_hammer_parts(_s, _map);
            _out = arm_append(_out, arm_place(_h, 0, _y0 - _s.flen * 0.5 * ARM_METRE,
                                              ARM_METRE, 0, ARM_METRE, undefined));
        } break;

        case "polearm": {
            _out = arm_append(_out, arm_polearm_parts(_s, _mat, _y0, _seed, _wear));
        } break;
    }
    return _out;
}

/// A polearm head: the point blade, the socket it is carried on, and whatever else the form
/// bolts to it.
function arm_polearm_parts(_s, _mat, _y0, _seed, _wear) {
    var _map = arm_material_map(_mat);
    var _out = [];
    var _sock_r = 0.020;
    var _sock_l = 0.070;

    // The socket sits at the top of the haft, and the blade grows out of its top.
    _out = arm_append(_out, arm_place(
        arm_socket_parts(_sock_r, _sock_l, 0, _map),
        0, _y0, ARM_METRE, 0, ARM_METRE, undefined));

    var _by = _y0 - _sock_l * ARM_METRE;

    // The point. arm_blade does the whole job; the head form only says which blade and how long.
    var _bs = arm_blade_spec(_s.blade);
    _bs.len = _s.hlen;
    // ⚠️ A POLEARM POINT CARRIES THE WEAPON'S WEAR TOO, and passing a clean one here would mean a
    // fifty-year-old billhook with a notched hook and a silvered haft had a factory-fresh point on
    // it. The forge hands the real wear down; this default exists only for the catalogue plates,
    // which show forms rather than histories.
    var _w = is_undefined(_wear) ? arm_wear_none() : _wear;
    var _o = arm_blade_outline(_bs, _w, _by);
    _out = arm_append(_out, arm_map_roles(arm_raise(_o, arm_bevel_cap(_o, 0.008), 2, "m2"), _map));
    _out = arm_append(_out, arm_blade_section_parts(_bs, _w, _by, _mat));

    if (_s.wings) {
        // A partisan's wings are two lugs at the base of the blade, and they are what stop a boar
        // running up the shaft at you. Authored as one mass each, mirrored.
        for (var _sg = -1; _sg <= 1; _sg += 2) {
            var _w = [[0, _by], [_sg * 0.052, _by - 0.030],
                      [_sg * 0.030, _by - 0.062], [0, _by - 0.040]];
            _out = arm_append(_out, arm_map_roles(
                arm_raise(_w, arm_bevel_cap(_w, 0.004), 2, "m2"), _map));
        }
    }

    if (_s.hook) {
        // A billhook's hook is a forward-curving beak off the back of the blade. It is the reason
        // the weapon exists - it pulls a rider off a horse - so it is large and unmistakable.
        var _h1 = arm_qbez([-0.012, _by - 0.060], [-0.090, _by - 0.130],
                           [-0.038, _by - 0.205], 10);
        var _h2 = arm_qbez([-0.038, _by - 0.205], [-0.058, _by - 0.120],
                           [-0.012, _by - 0.040], 10);
        var _hp = arm_dedupe_pts(arm_append(_h1, _h2));
        _out = arm_append(_out, arm_map_roles(
            arm_raise(_hp, arm_bevel_cap(_hp, 0.005), 2, "m2"), _map));
    }

    if (_s.axe) {
        // A halberd's axe bit, hung off the side of the socket.
        //
        // ⚠️ IT IS A SMALL BIT ON A LONG SHAFT, NOT A POLEAXE HEAD. Borrowing arm_head_spec's
        // "poleaxe" wholesale put a full-sized axe head halfway up the shaft beside a spike and a
        // rear hook, and the result read as a windmill rather than as a halberd. A halberd's bit is
        // roughly half the reach of an axe made to be the whole weapon, because on a halberd it is
        // one of three things the head does.
        var _as = { kind: "axe", reach: 0.082, rise: 0.052, drop: 0.052, arc: 0.30,
                    beard: 0.18, poll: "flat", eye: 0.026 };
        var _ao = arm_axe_outline(_as);
        var _ap = arm_map_roles(arm_raise(_ao, arm_bevel_cap(_ao, 0.005), 2, "m2"), _map);
        _out = arm_append(_out, arm_place(_ap, 0, _y0 - _sock_l * 0.30 * ARM_METRE,
                                          ARM_METRE, 0, ARM_METRE, undefined));
    }

    if (_s.rear == "spike") {
        var _sp = [[-0.008, _by - 0.020], [-0.075, _by - 0.052],
                   [-0.090, _by - 0.070], [-0.010, _by - 0.056]];
        _out = arm_append(_out, arm_map_roles(
            arm_raise(_sp, arm_bevel_cap(_sp, 0.003), 2, "m2"), _map));
    }
    return _out;
}

/// How far above the haft top a head reaches, in metres. The forge needs this to lay a weapon out
/// so that its total length is what the spec says it is, and the suite asserts against it.
function arm_head_reach_m(_form) {
    var _s = arm_head_spec(_form);
    switch (_s.kind) {
        case "axe":     return _s.rise;
        case "mace":    return _s.hlen;
        case "hammer":  return _s.face * 0.5;
        case "polearm": return 0.070 + _s.hlen;
    }
    return 0;
}
