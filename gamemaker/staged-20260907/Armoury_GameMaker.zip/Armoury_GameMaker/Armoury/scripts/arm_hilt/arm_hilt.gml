/// ARMOURY - arm_hilt. The end you hold: pommels, guards, grips, wraps and hafts.
///
/// ============================================================================================
/// ⭐ THE HILT IS WHERE A WEAPON'S OWNER IS VISIBLE, AND IT IS WHY THIS FILE IS AS LARGE AS THE
/// BLADE FILE.
///
/// A blade says what the weapon is FOR. A hilt says who paid for it. Two arming swords with the
/// same blade, one with an iron cross and a plain cord grip and one with a brass shell guard and
/// a wire-wrapped grip under a silver pommel, are a militiaman's sword and a captain's sword, and
/// a player reads that difference instantly without a line of text.
///
/// ⚠️ EVERYTHING HERE IS AUTHORED IN METRES ABOUT THE BUTT, exactly like arm_blade and arm_head.
/// The butt is y = 0 in this file's local space and the weapon runs in NEGATIVE y from there. The
/// forge converts once, at the end.
/// ============================================================================================

/// ============================================================================================
/// POMMELS
///
/// A pommel is a COUNTERWEIGHT before it is an ornament, which is why every one of these has real
/// mass at the very bottom of the weapon. The forms are the ones the historical record actually
/// carries; they are not eight random blobs, and they are recognisably different at 24 pixels,
/// which is the only test that matters.
/// ============================================================================================

/// _r is the pommel's nominal half-width in metres.
function arm_pommel_outline(_form, _r) {
    switch (_form) {
        case "wheel":
            // A flat disc seen edge-on-ish: wide, not very deep, with a slight lens to it.
            return arm_ellipse_pts(0, -_r * 0.78, _r, _r * 0.78, 20);

        case "disc":
            return arm_ellipse_pts(0, -_r * 0.52, _r * 1.06, _r * 0.52, 20);

        case "ball":
            return arm_ellipse_pts(0, -_r * 0.92, _r * 0.92, _r * 0.92, 20);

        case "pear": {
            // Narrow where it meets the grip, swelling to a round base. Built as two arcs so the
            // waist is a real curve rather than a corner.
            var _a = arm_qbez([-_r * 0.34, 0], [-_r * 1.02, -_r * 0.62], [0, -_r * 1.62], 10);
            var _b = arm_qbez([0, -_r * 1.62], [_r * 1.02, -_r * 0.62], [_r * 0.34, 0], 10);
            return arm_dedupe_pts(arm_append(_a, _b));
        }

        case "brazilnut": {
            // A wide, low, three-lobed cushion. The Norman pommel, and the flat top is what makes
            // it read as that rather than as a squashed ball.
            var _p = [];
            for (var _i = 0; _i <= 18; _i++) {
                var _u = _i / 18;
                var _x = lerp(-1, 1, _u);
                var _lobe = 1.0 - 0.22 * power(cos(_x * pi * 1.5), 2);
                array_push(_p, [_x * _r * 1.18, -_r * 0.86 * sqrt(max(0, 1 - _x * _x)) * _lobe]);
            }
            array_push(_p, [_r * 1.18, 0]);
            array_push(_p, [-_r * 1.18, 0]);
            return arm_dedupe_pts(_p);
        }

        case "cockedhat": {
            // Two horns rising either side of a central dip. Distinctive in silhouette, which is
            // exactly why it survives being drawn small.
            return arm_dedupe_pts([
                [-_r * 1.20, 0], [-_r * 1.32, -_r * 0.72], [-_r * 0.86, -_r * 1.05],
                [0, -_r * 0.58],
                [_r * 0.86, -_r * 1.05], [_r * 1.32, -_r * 0.72], [_r * 1.20, 0]]);
        }

        case "scentstopper": {
            // A faceted cone, like the stopper of a scent bottle. Straight sides, so it must NOT
            // be sampled as a curve: the flats are the object.
            return arm_dedupe_pts([
                [-_r * 0.36, 0], [-_r * 0.92, -_r * 0.52], [-_r * 0.58, -_r * 1.30],
                [0, -_r * 1.52],
                [_r * 0.58, -_r * 1.30], [_r * 0.92, -_r * 0.52], [_r * 0.36, 0]]);
        }

        case "fishtail": {
            // Flares outward and downward into two tails. A late, expensive shape.
            return arm_dedupe_pts([
                [-_r * 0.30, 0], [-_r * 1.36, -_r * 0.94], [-_r * 0.94, -_r * 1.16],
                [0, -_r * 0.72],
                [_r * 0.94, -_r * 1.16], [_r * 1.36, -_r * 0.94], [_r * 0.30, 0]]);
        }
    }
    return arm_ellipse_pts(0, -_r * 0.9, _r * 0.9, _r * 0.9, 18);
}

function arm_pommel_names() {
    return ["wheel", "disc", "ball", "pear", "brazilnut", "cockedhat", "scentstopper", "fishtail"];
}

#macro ARM_POMMEL_N 8

/// How far below the grip a pommel of this form hangs, as a multiple of its half-width. The forge
/// needs it to place the grip, and the suite asserts it against the real rendered bounds - which
/// is the only way a table like this can be prevented from drifting away from the shapes.
function arm_pommel_drop(_form) {
    switch (_form) {
        case "wheel":        return 1.56;
        case "disc":         return 1.04;
        case "ball":         return 1.84;
        case "pear":         return 1.62;
        case "brazilnut":    return 0.86;
        case "cockedhat":    return 1.05;
        case "scentstopper": return 1.52;
        case "fishtail":     return 1.16;
    }
    return 1.5;
}

/// A finished pommel, hanging below y = _y (metres), with its top at _y.
function arm_pommel_parts(_form, _mat, _r, _y, _seed) {
    var _map = arm_material_map(_mat);
    var _o = arm_pommel_outline(_form, _r);
    // ⛔ TRANSLATE, DO NOT MIRROR. The outlines above are authored running from y = 0 at the grip
    // end to NEGATIVE y at the far end, and a weapon also runs in negative y from its butt - so
    // both already point the same way and the pommel just moves to _y.
    //
    // MEASURED 2026-08-30 by baking the history sheet: written as `_y - _o[i][1]` this flipped the
    // pommel to the far side of the butt, so every sword on every sheet had its pommel floating as
    // a detached blob below the grip with a gap between them. The suite could not see it - a
    // detached pommel is still inside the unit box, still has area, still emits known roles, and
    // the twelve swords on the argument sheet all passed 1,477 assertions with a hole in them.
    var _f = [];
    for (var _i = 0; _i < array_length(_o); _i++) array_push(_f, [_o[_i][0], _y + _o[_i][1]]);
    var _out = arm_map_roles(arm_raise(_f, arm_bevel_cap(_f, 0.006), 2, "m2"), _map);

    // The tang button: the peened-over end of the tang, sitting on the far face of the pommel. It
    // is the one part of a sword that is genuinely a separate piece of metal on top of another, and
    // leaving it off is what makes a drawn pommel look like a bead threaded on a stick.
    _out = arm_append(_out, arm_map_roles(arm_boss(0, _y - arm_pommel_drop(_form) * _r * 0.62,
                                                   _r * 0.26, 10), _map));
    return _out;
}

/// ============================================================================================
/// GUARDS
///
/// ⛔ A GUARD IS DRAWN BEFORE THE BLADE AND AFTER THE GRIP, AND THAT ORDER IS NOT NEGOTIABLE. The
/// blade's shoulder disappears INTO the guard on every real hilted weapon - the tang passes
/// through it - so a guard drawn on top of a blade that has already been drawn is the only way to
/// get that. Draw the guard first and the blade's square shoulder sits proud of it, and the whole
/// weapon reads as two sprites laid over each other, which is precisely the failure the socket in
/// arm_head exists to prevent on polearms.
/// ============================================================================================

function arm_guard_names() {
    return ["none", "cross", "drooping", "disc", "shell", "knuckle", "basket", "langets"];
}

#macro ARM_GUARD_N 8

/// _span is the guard's half-width in metres.
function arm_guard_parts(_form, _mat, _span, _y, _seed) {
    var _map = arm_material_map(_mat);
    var _out = [];
    var _th = _span * 0.20; // quillon thickness

    switch (_form) {
        case "none": return [];

        case "cross": {
            // ⚠️ THE KNOPS ARE NOT DECORATION. A real quillon finishes in a knop or a flare, and a
            // plain bar with square ends reads as a lolly stick at every size this is drawn at.
            var _q = [[-_span * 1.04, _y - _th * 0.62], [_span * 1.04, _y - _th * 0.62],
                      [_span * 1.04, _y + _th * 0.62], [-_span * 1.04, _y + _th * 0.62]];
            _out = arm_append(_out, arm_map_roles(
                arm_raise(_q, arm_bevel_cap(_q, 0.004), 2, "m2"), _map));
            _out = arm_append(_out, arm_map_roles(arm_boss(-_span * 1.04, _y, _th * 0.62, 10), _map));
            _out = arm_append(_out, arm_map_roles(arm_boss(_span * 1.04, _y, _th * 0.62, 10), _map));
        } break;

        case "drooping": {
            // Quillons curving toward the blade. Two ribbons off one centre, mirrored.
            for (var _sg = -1; _sg <= 1; _sg += 2) {
                var _sp = arm_qbez([0, _y], [_sg * _span * 0.72, _y + _th * 0.20],
                                   [_sg * _span * 1.02, _y - _span * 0.42], 10);
                _out = arm_append(_out, arm_map_roles(
                    arm_taper_ribbon(_sp, _th * 0.62, _th * 0.30, "m2"), _map));
                _out = arm_append(_out, arm_map_roles(
                    arm_boss(_sg * _span * 1.02, _y - _span * 0.42, _th * 0.42, 9), _map));
            }
        } break;

        case "disc": {
            var _d = arm_ellipse_pts(0, _y, _span * 0.86, _th * 1.30, 18);
            _out = arm_append(_out, arm_map_roles(
                arm_raise(_d, arm_bevel_cap(_d, 0.004), 2, "m2"), _map));
        } break;

        case "shell": {
            // A cupped plate on the blade side. Its concavity is the whole object, so it is drawn
            // as a shallow bowl outline rather than as a disc, and it is SUNKEN, which is what
            // makes it read as a cup rather than as a second pommel.
            var _c = [];
            for (var _i = 0; _i <= 16; _i++) {
                var _u = -1 + 2 * (_i / 16);
                array_push(_c, [_u * _span, _y - _span * 0.46 * (1 - _u * _u)]);
            }
            for (var _j = 16; _j >= 0; _j--) {
                var _u2 = -1 + 2 * (_j / 16);
                array_push(_c, [_u2 * _span * 0.98, _y + _th * 0.55]);
            }
            var _cp = arm_dedupe_pts(_c);
            _out = arm_append(_out, arm_map_roles(
                arm_sink(_cp, arm_bevel_cap(_cp, 0.005), 2, "m2"), _map));
            // Radiating ribs, because a shell guard is a shell.
            for (var _k = -2; _k <= 2; _k++) {
                var _rx = _k / 2.6;
                _out = arm_append(_out, arm_map_roles(arm_ridge(
                    [[0, _y + _th * 0.3], [_rx * _span * 0.94, _y - _span * 0.40 * (1 - _rx * _rx)]],
                    false, _th * 0.24), _map));
            }
        } break;

        case "knuckle": {
            var _q2 = [[-_span * 0.96, _y - _th * 0.55], [_span * 0.96, _y - _th * 0.55],
                       [_span * 0.96, _y + _th * 0.55], [-_span * 0.96, _y + _th * 0.55]];
            _out = arm_append(_out, arm_map_roles(
                arm_raise(_q2, arm_bevel_cap(_q2, 0.004), 2, "m2"), _map));
            // The bow: from one quillon end down to the pommel. Drawn as a ribbon so it has real
            // width and catches the lamp along its length.
            var _bow = arm_qbez([-_span * 0.90, _y + _th * 0.2],
                                [-_span * 1.30, _y + _span * 1.30],
                                [-_span * 0.16, _y + _span * 2.30], 14);
            _out = arm_append(_out, arm_map_roles(
                arm_ribbon(_bow, _th * 0.40, "m2"), _map));
        } break;

        case "basket": {
            var _q3 = [[-_span * 0.90, _y - _th * 0.5], [_span * 0.90, _y - _th * 0.5],
                       [_span * 0.90, _y + _th * 0.5], [-_span * 0.90, _y + _th * 0.5]];
            _out = arm_append(_out, arm_map_roles(
                arm_raise(_q3, arm_bevel_cap(_q3, 0.004), 2, "m2"), _map));
            // Three bars sweeping down to the pommel on the near side. A basket hilt drawn in 2D
            // is a set of bars seen edge-on, and drawing it as a solid cup is the commonest way
            // this object is got wrong.
            for (var _b = 0; _b < 3; _b++) {
                var _w = 0.62 + 0.30 * _b;
                var _bar = arm_qbez([-_span * _w, _y],
                                    [-_span * (_w + 0.52), _y + _span * 1.25],
                                    [-_span * 0.14, _y + _span * 2.35], 13);
                _out = arm_append(_out, arm_map_roles(
                    arm_ribbon(_bar, _th * 0.26, "m2"), _map));
            }
        } break;

        case "langets": {
            // ⛔ LANGETS RUN DOWN THE HAFT, AWAY FROM THE HEAD. They are the straps that stop an axe
            // head being cut off its shaft, so they are nailed to the wood BELOW the eye.
            //
            // MEASURED 2026-08-30 by baking the heads sheet: written running in NEGATIVE y they ran
            // UPWARD into the head itself, so every hafted weapon in the corpus had two brass bars
            // standing across the middle of its own axe blade. The comment here previously said
            // "the forge decides which by where it places this" - it did not, and a note claiming
            // somebody else handles a case is not the same as that case being handled.
            //
            // y grows DOWNWARD and a weapon runs in negative y from its butt, so "down the haft,
            // toward the butt" is POSITIVE y from the head.
            for (var _sg2 = -1; _sg2 <= 1; _sg2 += 2) {
                var _lg = [[_sg2 * _span * 0.20, _y], [_sg2 * _span * 0.52, _y],
                           [_sg2 * _span * 0.44, _y + _span * 2.10],
                           [_sg2 * _span * 0.22, _y + _span * 2.10]];
                _out = arm_append(_out, arm_map_roles(
                    arm_raise(_lg, arm_bevel_cap(_lg, 0.003), 2, "m2"), _map));
                _out = arm_append(_out, arm_map_roles(
                    arm_boss(_sg2 * _span * 0.34, _y + _span * 1.60, _span * 0.10, 8), _map));
            }
        } break;
    }
    return _out;
}

/// ============================================================================================
/// GRIPS AND HAFTS
/// ============================================================================================

function arm_wrap_names() { return ["none", "cord", "leather", "wire", "scales"]; }

#macro ARM_WRAP_N 5

/// A grip: a tapered core between two y values, and whatever is wound round it.
///
/// ⛔ THE WRAP IS AUTHORED ACROSS THE GRIP AS A FRACTION OF ITS WIDTH, NOT IN ABSOLUTE UNITS, and
/// its PITCH is absolute. That is the wing's physical-detail law (arm_geom) applied to the one
/// place it is most visible: cord is about 4 mm thick whether it is on a dagger or on a
/// greatsword, so a greatsword's grip carries MORE TURNS, not fatter ones. Written the other way -
/// a fixed number of turns - a dagger gets thread and a greatsword gets rope.
function arm_grip_parts(_core_mat, _cover, _hw, _y0, _y1, _seed) {
    var _out = [];
    var _cmap = arm_material_map(_core_mat);
    var _len = abs(_y1 - _y0);

    // The core. Waisted slightly in the middle, because a grip is shaped to a hand and a straight
    // cylinder reads as dowel.
    var _pts = [];
    for (var _i = 0; _i <= 10; _i++) {
        var _u = _i / 10;
        array_push(_pts, [-_hw * (1.0 - 0.16 * sin(pi * _u)), lerp(_y0, _y1, _u)]);
    }
    for (var _j = 10; _j >= 0; _j--) {
        var _u2 = _j / 10;
        array_push(_pts, [_hw * (1.0 - 0.16 * sin(pi * _u2)), lerp(_y0, _y1, _u2)]);
    }
    _pts = arm_dedupe_pts(_pts);
    _out = arm_append(_out, arm_map_roles(
        arm_raise(_pts, arm_bevel_cap(_pts, 0.004), 2, "m2"), _cmap));

    if (_cover == "none") return _out;

    var _wmap = arm_material_map(_cover);

    if (_cover == "scales") {
        // Two plates riveted either side. Horn or bone scales are a different object from a wrap
        // and must not be drawn as one.
        for (var _sg = -1; _sg <= 1; _sg += 2) {
            var _pl = [[_sg * _hw * 0.20, _y0 + _len * 0.06], [_sg * _hw * 1.02, _y0 + _len * 0.10],
                       [_sg * _hw * 1.02, _y1 - _len * 0.10], [_sg * _hw * 0.20, _y1 - _len * 0.06]];
            _out = arm_append(_out, arm_map_roles(
                arm_raise(_pl, arm_bevel_cap(_pl, 0.003), 2, "m2"), _wmap));
        }
        var _riv = arm_material_map("iron");
        for (var _k = 0; _k < 3; _k++) {
            _out = arm_append(_out, arm_map_roles(
                arm_boss(0, lerp(_y0, _y1, 0.22 + 0.28 * _k), _hw * 0.30, 8), _riv));
        }
        return _out;
    }

    // A wound cover. PITCH IS PHYSICAL - see the header.
    var _pitch = (_cover == "wire") ? 0.0042 : ((_cover == "cord") ? 0.0075 : 0.0125);
    var _turns = max(3, floor(_len / (_pitch * ARM_METRE)));
    var _w = (_cover == "wire") ? 0.0022 : 0.0038;

    for (var _t = 0; _t < _turns; _t++) {
        var _u3 = (_t + 0.5) / _turns;
        var _y = lerp(_y0, _y1, _u3);
        var _hwl = _hw * (1.0 - 0.16 * sin(pi * _u3)) * 1.04;
        // A turn is a shallow diagonal across the grip, not a horizontal band: a wrap is a spiral
        // and the diagonal is the only thing that says so in a side view.
        var _dy = _len / _turns * 0.55;
        _out = arm_append(_out, arm_map_roles(
            [arm_poly([[-_hwl, _y + _dy * 0.5], [_hwl, _y - _dy * 0.5]], false, _w, "m3")], _wmap));
    }

    if (_cover == "wire") {
        // Twisted wire is TWO wires wound opposite ways, which is what makes the lozenge pattern
        // a buyer recognises. One spiral alone reads as a screw thread.
        for (var _t2 = 0; _t2 < _turns; _t2++) {
            var _u4 = (_t2 + 0.5) / _turns;
            var _y2 = lerp(_y0, _y1, _u4);
            var _hwl2 = _hw * (1.0 - 0.16 * sin(pi * _u4)) * 1.04;
            var _dy2 = _len / _turns * 0.55;
            _out = arm_append(_out, arm_map_roles(
                [arm_poly([[-_hwl2, _y2 - _dy2 * 0.5], [_hwl2, _y2 + _dy2 * 0.5]], false,
                          _w * 0.8, "m1")], _wmap));
        }
    }
    return _out;
}

/// A polearm haft: a long tapered pole with a ferrule at the head end and a butt cap.
///
/// ⚠️ A HAFT IS NOT A RECTANGLE AND THE TAPER IS THE WHOLE READ. An ash pole is thicker at the
/// butt and thinner at the head, and drawing it as a constant-width bar is what makes every
/// programmer-art spear look like a broom.
function arm_haft_parts(_wood, _hw, _y0, _y1, _fit_mat, _seed) {
    var _out = [];
    var _map = arm_material_map(_wood);
    var _len = abs(_y1 - _y0);

    var _pts = [];
    for (var _i = 0; _i <= 8; _i++) {
        var _u = _i / 8;
        array_push(_pts, [-_hw * (1.0 - 0.22 * _u), lerp(_y0, _y1, _u)]);
    }
    for (var _j = 8; _j >= 0; _j--) {
        var _u2 = _j / 8;
        array_push(_pts, [_hw * (1.0 - 0.22 * _u2), lerp(_y0, _y1, _u2)]);
    }
    _pts = arm_dedupe_pts(_pts);
    _out = arm_append(_out, arm_map_roles(
        arm_raise(_pts, arm_bevel_cap(_pts, 0.004), 2, "m2"), _map));

    // Grain. COUNT AND LENGTH carry the tone, never stroke width - the wing's Forage law, and on
    // this hardware draw_line_width floors every stroke at 1 px, so an authored swell is quantised
    // away and reads as a barcode.
    var _g = arm_rng(_seed ^ 0x6A17);
    var _lines = 3 + floor(arm_rng_next(_g) * 3);
    for (var _k = 0; _k < _lines; _k++) {
        var _off = (-0.55 + 1.10 * arm_rng_next(_g)) * _hw;
        var _a = lerp(_y0, _y1, 0.05 + 0.30 * arm_rng_next(_g));
        var _b = lerp(_y0, _y1, 0.55 + 0.40 * arm_rng_next(_g));
        _out = arm_append(_out, arm_map_roles(
            [arm_poly([[_off, _a], [_off * 0.86, _b]], false, 0.0022, "m1")], _map));
    }

    // The ferrule at the head end, and the butt cap. Both are metal on wood, so both take the
    // fitting material rather than the haft's.
    var _fmap = arm_material_map(_fit_mat);
    var _fw = _hw * 1.22;
    var _fl = _len * 0.035;
    var _fer = [[-_fw, _y1 + _fl], [_fw, _y1 + _fl], [_fw * 0.94, _y1], [-_fw * 0.94, _y1]];
    _out = arm_append(_out, arm_map_roles(
        arm_raise(_fer, arm_bevel_cap(_fer, 0.003), 2, "m2"), _fmap));
    var _cap = [[-_hw * 1.16, _y0], [_hw * 1.16, _y0],
                [_hw * 1.10, _y0 - _fl * 1.6], [-_hw * 1.10, _y0 - _fl * 1.6]];
    _out = arm_append(_out, arm_map_roles(
        arm_raise(_cap, arm_bevel_cap(_cap, 0.003), 2, "m2"), _fmap));
    return _out;
}
