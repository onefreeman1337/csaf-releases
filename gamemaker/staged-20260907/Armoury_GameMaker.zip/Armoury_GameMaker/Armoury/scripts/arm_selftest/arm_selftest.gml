/// ARMOURY - arm_selftest. The in-engine suite.
///
/// ============================================================================================
/// ⛔ GML CANNOT BE UNIT-TESTED OUTSIDE THE ENGINE. There is no headless runner, no mock, no
/// assertion library. This wing's answer is to build the product through Igor, run the executable
/// with `-selftest`, and have it write a JSON result file - which is the ONE route that survives a
/// release build (show_debug_message is dead in one, and game_end's argument is not propagated).
///
/// ⛔ AND A SUITE FULL OF GREEN ASSERTIONS PROVES NOTHING UNTIL ONE OF THEM HAS BEEN MADE TO FAIL.
/// Two of this wing's worst incidents were suites that could never have gone red: a duplicate check
/// written with a tolerance below GML's default epsilon passed VACUOUSLY for every input, and a
/// containment assertion passed on all 216 letters of a corpus while most of them were being
/// silently shrunk. Where an assertion here could be vacuous, it is paired with one that proves the
/// fixture is in the state the first one needs.
///
/// ⛔ THE DEFAULT EPSILON. math_get_epsilon() returns 0.00001 on this runtime and it PARTICIPATES
/// IN COMPARISONS, so `abs(a - b) < 0.0000001` is FALSE for every pair of values including equal
/// ones, and `abs(a - b) < 0.00001` is RED for two values that are the same object. Never write a
/// tolerance below or at ~1e-5. ARM_ST_EPS is the one this file uses.
///
/// ⛔ AND GML HAS NO EXPONENT-LITERAL SYNTAX. `1e-4` is a lexer error that reads like a bracket
/// bug. Every tolerance in this package is written out in full.
/// ============================================================================================

#macro ARM_ST_EPS 0.0001

/// The suite's accumulator.
function arm_st_new() {
    return { pass: 0, fail: 0, notes: [] };
}

function arm_st_ok(_r, _cond, _what) {
    if (_cond) { _r.pass += 1; return; }
    _r.fail += 1;
    array_push(_r.notes, _what);
}

/// ============================================================================================
/// THE SUITE
/// ============================================================================================

function arm_selftest_run() {
    var _r = arm_st_new();

    // -- STAGE 0: the runtime still behaves the way this package assumes -----------------------
    global.arm_stage = 0;
    var _e = math_get_epsilon();
    // ⛔ WRITTEN AS TWO CLAUSES, AND THE SECOND IS `!(_e > 0)` ON PURPOSE. The natural single
    // expression `_e > 0 && _e < TOL` goes RED on its first clause forever: the difference between
    // the epsilon and zero IS the epsilon, so GML calls them equal, and equal is not greater-than.
    // Written this way it is a POSITIVE test that the runtime still applies an epsilon, and it goes
    // red the day a release stops - which is a thing this package would need to know.
    arm_st_ok(_r, !(_e > 0), "epsilon: expected _e > 0 to be FALSE (the epsilon trap is gone)");
    arm_st_ok(_r, _e < 0.001, "epsilon: larger than this package's tolerances");

    // -- STAGE 1: the corpus is the size it says it is -------------------------------------------
    global.arm_stage = 1;
    arm_st_ok(_r, array_length(arm_blade_names()) == ARM_BLADE_N, "blade count != ARM_BLADE_N");
    arm_st_ok(_r, array_length(arm_point_names()) == ARM_POINT_N, "point count != ARM_POINT_N");
    arm_st_ok(_r, array_length(arm_head_names()) == ARM_HEAD_N, "head count != ARM_HEAD_N");
    arm_st_ok(_r, array_length(arm_pommel_names()) == ARM_POMMEL_N, "pommel count != ARM_POMMEL_N");
    arm_st_ok(_r, array_length(arm_guard_names()) == ARM_GUARD_N, "guard count != ARM_GUARD_N");
    arm_st_ok(_r, array_length(arm_material_names()) == ARM_MAT_N, "material count != ARM_MAT_N");
    arm_st_ok(_r, array_length(arm_provenance_names()) == ARM_PROV_N, "provenance count != ARM_PROV_N");
    arm_st_ok(_r, array_length(arm_form_names()) == ARM_FORM_N, "form count != ARM_FORM_N");

    // ⭐ THE VOLUME CLAIM, ASSERTED. The store page says the package contains more than forty
    // authored forms, and a marketing number that nothing checks is a number that drifts.
    var _authored = ARM_BLADE_N + ARM_POINT_N + ARM_HEAD_N + ARM_POMMEL_N + ARM_GUARD_N;
    arm_st_ok(_r, _authored >= 40, "authored form count fell below the 40 the listing claims: "
                                   + string(_authored));

    // -- STAGE 2: every material resolves, and its ink is legible on it ---------------------------
    global.arm_stage = 2;
    var _mats = arm_material_names();
    for (var _i = 0; _i < array_length(_mats); _i++) {
        var _m = _mats[_i];
        var _ramp = arm_material_ramp(_m, 0, 0);
        arm_st_ok(_r, array_length(_ramp) == ARM_RAMP_N, "ramp wrong length: " + _m);

        // ⛔ NO TWO ADJACENT STOPS MAY COLLAPSE. This is the Hearth limewash defect: a ramp whose
        // top stops both clamp to the ceiling makes a bevel whose two brightest walls are the same
        // colour, which reads as a flat fill with a line round it. arm_material_ramp SLIDES rather
        // than clamping, and this is what proves it still does.
        for (var _k = 0; _k < ARM_RAMP_N - 1; _k++) {
            arm_st_ok(_r, _ramp[_k] != _ramp[_k + 1],
                      "ramp stops " + string(_k) + "/" + string(_k + 1) + " collapsed: " + _m);
        }

        // The ink has to be far enough from the surface to be read ON it. See arm_material_ink.
        arm_st_ok(_r, arm_material_ink_sep(_m, 0) > 0.20, "ink too close to its ground: " + _m);
        arm_st_ok(_r, arm_material_ink_sep(_m, 0.9) > 0.20, "ink too close when decayed: " + _m);
    }

    // -- STAGE 3: decay PULLS TOWARD A TARGET and is not a scale ----------------------------------
    global.arm_stage = 3;
    // ⭐ GOLD IS THE NEGATIVE CONTROL AND IT IS THE WHOLE STAGE. Gold does not corrode, so its
    // decay target is "none" and its spec must be IDENTICAL at every decay level. A multiplicative
    // or additive model cannot express that; a pull-based one gets it for free. If somebody
    // "simplifies" arm_material_decayed back into a multiplier, this goes red immediately.
    var _g0 = arm_material_decayed("gold", 0);
    var _g1 = arm_material_decayed("gold", 1);
    arm_st_ok(_r, abs(_g0.L - _g1.L) < ARM_ST_EPS, "gold moved in lightness under decay");
    arm_st_ok(_r, abs(_g0.C - _g1.C) < ARM_ST_EPS, "gold moved in chroma under decay");
    arm_st_ok(_r, abs(_g0.h - _g1.h) < ARM_ST_EPS, "gold moved in hue under decay");

    // ⚠️ AND THE CONTROL NEEDS A POSITIVE PARTNER OR IT IS SATISFIED BY A DECAY THAT DOES NOTHING
    // AT ALL. Steel MUST move, and it must move a long way, or the three assertions above are
    // passing for the wrong reason - which is the vacuous-green shape this file exists to prevent.
    var _s0 = arm_material_decayed("steel", 0);
    var _s1 = arm_material_decayed("steel", 1);
    arm_st_ok(_r, abs(_s0.L - _s1.L) > 0.10, "steel did not darken under decay - is decay a no-op?");
    arm_st_ok(_r, _s1.C > _s0.C + 0.03, "steel did not gain chroma rusting - decay is still a scale");

    // ⛔⛔ AND IT MUST BE THE COLOUR OF RUST ALL THE WAY, NOT JUST AT THE END.
    //
    // ⚠️ THIS ASSERTION USED TO EXCLUDE ONLY GREEN, AND IT PASSED OVER A SHEET FULL OF MAGENTA
    // SWORDS. Written as "the midpoint is not in the green band", it encoded the ONE failure that
    // had already been thought of - a straight lerp from 250 to 44 going the long way through 150 -
    // and was silent when the short-way fix sent iron through 300 instead. A test that names the
    // failure mode it expects cannot see the one beside it.
    //
    // Stated as a PROPERTY instead: a rusting ferrous metal must be within 60 degrees of rust's own
    // hue at every step, because rust does not pass through any other colour on its way to being
    // rust. That is true of green, magenta and everything else at once, and it does not need to
    // know which way round the circle the implementation went.
    var _ferrous = ["steel", "iron", "bogiron", "watered", "meteoric"];
    for (var _fi = 0; _fi < array_length(_ferrous); _fi++) {
        for (var _st = 1; _st <= 4; _st++) {
            var _hh = arm_material_decayed(_ferrous[_fi], _st * 0.25).h;
            var _dd = abs(_hh - 44);
            if (_dd > 180) _dd = 360 - _dd;
            arm_st_ok(_r, _dd < 60,
                      _ferrous[_fi] + " at decay " + string(_st * 0.25)
                      + " is hue " + string(round(_hh)) + ", " + string(round(_dd))
                      + " degrees off rust - it is rusting through the wrong colour");
        }
    }

    // -- STAGE 4: every blade profile is a SIMPLE closed outline ----------------------------------
    global.arm_stage = 4;
    // ⛔ TOTAL TURNING IS THE CHEAP TEST AND ITS CONVERSE IS FALSE. A polygon with one crossed-over
    // flap still accumulates exactly one revolution, so turning alone passed on five of six
    // deliberately-broken outlines on a sibling product. arm_is_simple is the definitive test and
    // it is what is asserted here.
    var _all = arm_blade_all_names();
    var _wn = arm_wear_none();
    for (var _b = 0; _b < array_length(_all); _b++) {
        var _o = arm_blade_outline(arm_blade_spec(_all[_b]), _wn, 0);
        arm_st_ok(_r, array_length(_o) > 30, "blade outline too sparse: " + _all[_b]);
        arm_st_ok(_r, arm_is_simple(_o), "blade outline self-intersects: " + _all[_b]);
        // A blade must have real area, or a spec typo produces an invisible weapon that nothing
        // else in this suite would notice.
        arm_st_ok(_r, abs(arm_area2(_o)) > 0.00002, "blade outline has no area: " + _all[_b]);
    }

    // -- STAGE 5: a notch REMOVES metal from the silhouette ---------------------------------------
    global.arm_stage = 5;
    // ⭐ THIS IS THE PRODUCT'S CENTRAL CLAIM AND IT IS TESTED AS AN AREA, NOT AS A PICTURE. The
    // wing's Forage law: a difference drawn INSIDE a filled shape is not a difference in the shape,
    // and two species that differed only in marks on an already-solid band measured at distance
    // exactly zero. A notch that did not cut the outline would pass every other assertion here.
    var _spec = arm_blade_spec("arming");
    var _clean = arm_blade_outline(_spec, _wn, 0);
    var _notched_wear = { hone: 0, bend: 0, tip: 0,
                          notches: [{ t: 0.70, d: 0.30, w: 0.030 },
                                    { t: 0.50, d: 0.25, w: 0.030 }] };
    var _notched = arm_blade_outline(_spec, _notched_wear, 0);
    var _a_clean = abs(arm_area2(_clean));
    var _a_notch = abs(arm_area2(_notched));
    arm_st_ok(_r, _a_notch < _a_clean * 0.995,
              "notches did not remove area from the blade outline");
    arm_st_ok(_r, arm_is_simple(_notched), "a notched blade outline self-intersects");
    // ⚠️ THE VACUITY GUARD. Both assertions above are satisfied by a notch list the code never
    // reads, so this proves the fixture actually carries notches and that they are wide enough to
    // land on a sample. Every assertion that depends on a fixture being in a particular STATE needs
    // a second assertion that the fixture is in that state.
    arm_st_ok(_r, array_length(_notched_wear.notches) == 2, "notch fixture is empty");
    arm_st_ok(_r, arm_notch_u(_notched_wear.notches, 0.70) < 0.85,
              "the notch fixture does not actually cut the edge at its own centre");
    arm_st_ok(_r, abs(arm_notch_u(_notched_wear.notches, 0.20) - 1.0) < ARM_ST_EPS,
              "a notch is affecting the edge far away from itself");

    // -- STAGE 6: honing NARROWS the blade, and it is not the same thing as a notch -----------------
    global.arm_stage = 6;
    var _honed = arm_blade_outline(_spec, { hone: 1, bend: 0, tip: 0, notches: [] }, 0);
    arm_st_ok(_r, abs(arm_area2(_honed)) < _a_clean * 0.85, "honing did not narrow the blade");
    // A honed blade is still the same LENGTH - that is what makes it honing rather than breakage.
    var _bc = arm_render_bounds([arm_fill(_clean, "m2")]);
    var _bh = arm_render_bounds([arm_fill(_honed, "m2")]);
    arm_st_ok(_r, abs((_bc[3] - _bc[1]) - (_bh[3] - _bh[1])) < 0.002,
              "honing changed the blade's length");
    arm_st_ok(_r, (_bh[2] - _bh[0]) < (_bc[2] - _bc[0]) - 0.001,
              "honing did not reduce the blade's width");

    // -- STAGE 7: care MOVES damage rather than removing it -----------------------------------------
    global.arm_stage = 7;
    // ⭐ THE COUPLING FROM arm_history's HEADER, ASSERTED. Two weapons of the same age and the same
    // number of fights, one looked after and one not: the cared-for one must be NARROWER and have
    // FEWER notches, and the neglected one the reverse. If care simply reduced all damage, the
    // first of these would go red - which is what makes this a test of the model and not of the
    // arithmetic.
    var _kept = { class: "issue", seed: 7, quality: 0.6, age: 40, battles: 0.8,
                  care: 0.95, owners: 1, bend: 0, rehafted: 0, marks: [] };
    var _left = { class: "issue", seed: 7, quality: 0.6, age: 40, battles: 0.8,
                  care: 0.05, owners: 1, bend: 0, rehafted: 0, marks: [] };
    arm_st_ok(_r, arm_history_hone(_kept) > arm_history_hone(_left),
              "a cared-for blade is not more honed than a neglected one");
    arm_st_ok(_r, array_length(arm_history_notches(_kept))
                < array_length(arm_history_notches(_left)),
              "a cared-for blade does not have fewer notches than a neglected one");
    arm_st_ok(_r, arm_history_decay(_kept) < arm_history_decay(_left),
              "care did not reduce corrosion");
    // Vacuity guard: the neglected one must actually HAVE notches, or the comparison above is
    // 0 < 0 and proves nothing.
    arm_st_ok(_r, array_length(arm_history_notches(_left)) > 0,
              "the neglected fixture produced no notches at all");

    // -- STAGE 8: every form assembles, has area, and stays in the unit box --------------------------
    global.arm_stage = 8;
    var _forms = arm_form_names();
    var _provs = arm_provenance_names();
    for (var _f = 0; _f < array_length(_forms); _f++) {
        var _w = arm_forge(_forms[_f], _provs[_f % array_length(_provs)], 1000 + _f);
        var _parts = arm_forge_parts(_w);
        arm_st_ok(_r, array_length(_parts) > 12,
                  "form assembled almost nothing: " + _forms[_f]
                  + " (" + string(array_length(_parts)) + " parts)");

        var _bb = arm_render_bounds(_parts);
        // ⛔ THE UNIT BOX IS THE CONTRACT. A form that runs outside it paints over whatever sits
        // beside it in a buyer's inventory grid - the wing shipped exactly that on a sky product,
        // where a rainbow bled into the neighbouring cell.
        arm_st_ok(_r, _bb[0] > -0.52 && _bb[2] < 0.52,
                  "form runs outside the unit box horizontally: " + _forms[_f]);
        arm_st_ok(_r, _bb[1] > -0.60 && _bb[3] < 0.52,
                  "form runs outside the unit box vertically: " + _forms[_f]);

        // Every role a form emits must exist in its own palette, or the renderer silently falls
        // back to the ink colour and the whole part draws as a black shape.
        var _pal = arm_forge_palette(_w);
        var _roles = arm_roles_used(_parts);
        for (var _q = 0; _q < array_length(_roles); _q++) {
            arm_st_ok(_r, variable_struct_exists(_pal, _roles[_q]),
                      "form " + _forms[_f] + " asks for missing role " + _roles[_q]);
        }
    }

    // -- STAGE 9: the same seed gives the same weapon, twice -----------------------------------------
    global.arm_stage = 9;
    // ⛔ DETERMINISM IS THE PACKAGE'S CENTRAL PROMISE and this wing has lost it before: an rng
    // written as a struct with a next() method did not keep its state, so two freshly seeded
    // generators disagreed on their first draw and forms re-jittered themselves every time anything
    // else drew. Nothing in a JavaScript previewer could catch it - JS closures capture correctly -
    // which is the clearest single argument for testing in the engine.
    var _w1 = arm_forge("longsword", "looted", 4242);
    var _w2 = arm_forge("longsword", "looted", 4242);
    arm_st_ok(_r, _w1.edge_mat == _w2.edge_mat && _w1.pommel == _w2.pommel
                  && _w1.guard == _w2.guard, "same seed produced different materials");
    arm_st_ok(_r, array_length(arm_forge_parts(_w1)) == array_length(arm_forge_parts(_w2)),
              "same seed produced a different number of parts");
    var _b1 = arm_render_bounds(arm_forge_parts(_w1));
    var _b2 = arm_render_bounds(arm_forge_parts(_w2));
    arm_st_ok(_r, abs(_b1[0] - _b2[0]) < ARM_ST_EPS && abs(_b1[3] - _b2[3]) < ARM_ST_EPS,
              "same seed produced different geometry");

    // Different seeds must produce DIFFERENT weapons, or the generator is a constant with extra
    // steps - the other half of the same claim, and the half that is easy to leave untested.
    var _diff = 0;
    for (var _s2 = 0; _s2 < 24; _s2++) {
        var _wa = arm_forge("arming", "looted", 900 + _s2);
        if (_wa.pommel != _w1.pommel || _wa.guard != _w1.guard
            || _wa.edge_mat != _w1.edge_mat) _diff += 1;
    }
    arm_st_ok(_r, _diff >= 12, "24 seeds produced almost the same weapon every time: "
                               + string(_diff) + " differed");

    // -- STAGE 10: using a weapon CHANGES it, and does not mutate the original -----------------------
    global.arm_stage = 10;
    var _new = arm_forge("arming", "issue", 77);
    var _key_before = arm_forge_key(_new);
    var _old = arm_use(_new, 40, 20, 0.1);
    arm_st_ok(_r, arm_forge_key(_new) == _key_before,
              "arm_use MUTATED the weapon it was given");
    arm_st_ok(_r, arm_forge_key(_old) != _key_before,
              "arm_use returned a weapon identical to the one it was given");
    arm_st_ok(_r, arm_history_decay(_old.history) > arm_history_decay(_new.history),
              "forty fights and twenty years did not corrode a neglected weapon");
    arm_st_ok(_r, abs(arm_area2(arm_blade_outline(arm_blade_spec("arming"),
                                                  arm_history_wear(_old.history), 0)))
                != abs(arm_area2(arm_blade_outline(arm_blade_spec("arming"),
                                                   arm_history_wear(_new.history), 0))),
              "a used weapon draws exactly the same outline as a new one");

    // ⛔ AND add_owner MUST NOT PUSH ONTO THE ORIGINAL'S ARRAY. arm_history_use hands the SAME marks
    // reference to the new struct, so a push without a copy adds the mark to every earlier version
    // of the weapon the caller is still holding - including the one on screen.
    var _o1 = arm_forge("arming", "guild", 5);
    var _n_before = array_length(_o1.history.marks);
    var _h2 = arm_history_add_owner(_o1.history, "tally");
    arm_st_ok(_r, array_length(_o1.history.marks) == _n_before,
              "add_owner mutated the original weapon's marks array");
    arm_st_ok(_r, array_length(_h2.marks) == _n_before + 1, "add_owner did not add a mark");

    // -- STAGE 11: the bent grave blade is actually bent ----------------------------------------------
    global.arm_stage = 11;
    // The corpus's most distinctive silhouette, and one that would fail silently: a bend that did
    // nothing would leave a perfectly ordinary sword labelled "bent".
    var _straight = arm_blade_outline(_spec, _wn, 0);
    var _bentw = { hone: 0, bend: 0.62, tip: 0, notches: [] };
    var _bent = arm_blade_outline(_spec, _bentw, 0);
    var _sb = arm_render_bounds([arm_fill(_straight, "m2")]);
    var _bb2 = arm_render_bounds([arm_fill(_bent, "m2")]);
    arm_st_ok(_r, (_bb2[2] - _bb2[0]) > (_sb[2] - _sb[0]) + 0.01,
              "a bent blade is no wider than a straight one");
    arm_st_ok(_r, arm_is_simple(_bent), "a bent blade outline self-intersects");
    // A bend moves BOTH edges equally - it is not curvature. If the bend were folded into `curve`
    // the blade would get wider on one side only and its profile would change with it.
    var _bs2 = arm_blade_spec("arming");
    var _p_back = arm_blade_point(_bs2, 1.0, -1, _bentw, 0);
    var _p_edge = arm_blade_point(_bs2, 1.0, 1, _bentw, 0);
    var _p_back0 = arm_blade_point(_bs2, 1.0, -1, _wn, 0);
    var _p_edge0 = arm_blade_point(_bs2, 1.0, 1, _wn, 0);
    arm_st_ok(_r, abs((_p_back[0] - _p_back0[0]) - (_p_edge[0] - _p_edge0[0])) < ARM_ST_EPS,
              "a bend moved the back and the edge by different amounts");

    // -- STAGE 12: derived stats are in the range real weapons occupy ----------------------------------
    global.arm_stage = 12;
    for (var _f2 = 0; _f2 < array_length(_forms); _f2++) {
        var _w3 = arm_forge(_forms[_f2], "issue", 3000 + _f2);
        var _kg = arm_mass_kg(_w3);
        // ⚠️ A WIDE BAND ON PURPOSE. This is not a claim that the mass model is accurate; it is a
        // guard against a spec typo producing a four-hundred-kilogram dagger, which is the failure
        // this can actually catch. The solidity factor in arm_mass_kg is stated as an approximation
        // and this range is the range the whole corpus has to sit in to be believable.
        arm_st_ok(_r, _kg > 0.15 && _kg < 9.0,
                  "implausible mass for " + _forms[_f2] + ": " + string(_kg) + " kg");
        var _reach = arm_form_length_m(_forms[_f2]);
        arm_st_ok(_r, _reach > 0.20 && _reach <= ARM_LONGEST_M,
                  "form longer than ARM_LONGEST_M: " + _forms[_f2]);
    }

    // -- STAGE 13: every name renders, and every string is ASCII ------------------------------------
    global.arm_stage = 13;
    // ⛔ THE SHIPPED FONTS ARE ASCII 32..126 AND A MISSING GLYPH DRAWS NOTHING AT ALL - no error,
    // no box, just absence, which reads as a deliberate space. It reached a cover and a hero sheet
    // on a sibling product. Internal_Ops/ascii_check.js scans the SOURCE; this checks the strings
    // the product actually GENERATES at runtime, which no source scan can see.
    for (var _f3 = 0; _f3 < array_length(_forms); _f3++) {
        for (var _p2 = 0; _p2 < array_length(_provs); _p2++) {
            var _w4 = arm_forge(_forms[_f3], _provs[_p2], 500 + _f3 * 7 + _p2);
            var _txt = arm_name(_w4) + " " + arm_describe(_w4) + " " + arm_stat_line(_w4);
            var _bad = -1;
            for (var _c = 1; _c <= string_length(_txt); _c++) {
                var _o2 = ord(string_char_at(_txt, _c));
                if (_o2 < 32 || _o2 > 126) { _bad = _o2; break; }
            }
            arm_st_ok(_r, _bad == -1, "non-ASCII character " + string(_bad) + " in generated text for "
                                      + _forms[_f3] + "/" + _provs[_p2]);
            arm_st_ok(_r, string_length(arm_name(_w4)) > 6,
                      "generated name is empty or near-empty: " + _forms[_f3]);
        }
    }

    // ⛔ STAGE 99 MEANS "THE SUITE REACHED THE END". Every stage above sets global.arm_stage on the
    // way past, and the crash handler writes whatever it was last set to - so a suite that dies in
    // stage 7 records 7. Without a terminal marker, a run that crashed after its last assertion
    // would write a result file full of passes and no failures, which is indistinguishable from
    // success by every number in it. The runner requires 99 and fails the run otherwise.
    global.arm_stage = 99;
    return _r;
}

/// ============================================================================================
/// THE RESULT FILE
///
/// ⛔ file_text_open_write IS THE ONLY ROUTE THAT SURVIVES A RELEASE BUILD. Measured by this wing:
/// show_debug_message with -debugoutput yields a file holding only engine boot lines, and
/// game_end(n)'s argument is NOT propagated to the process exit code. This writes to
/// %LOCALAPPDATA%/Armoury/ and needs no runner flag at all.
/// ============================================================================================

function arm_selftest_write(_r) {
    var _f = file_text_open_write("arm_selftest.json");
    var _notes = "";
    for (var _i = 0; _i < array_length(_r.notes); _i++) {
        if (_i > 0) _notes += " | ";
        _notes += string_replace_all(string(_r.notes[_i]), "\"", "'");
    }
    file_text_write_string(_f,
        "{\"pass\":" + string(_r.pass)
        + ",\"fail\":" + string(_r.fail)
        + ",\"stage\":" + string(global.arm_stage)
        + ",\"epsilon\":" + string_format(math_get_epsilon(), 1, 12)
        + ",\"version\":\"" + ARM_VERSION + "\""
        + ",\"notes\":\"" + _notes + "\"}");
    file_text_close(_f);
}
