/// ARMOURY - arm_bake. The store sheets, rendered BY THE PRODUCT.
///
/// ============================================================================================
/// ⛔ EVERY IMAGE ON THE STORE PAGE IS DRAWN BY THIS PACKAGE, IN THE ENGINE, THROUGH THE SAME
/// PUBLIC FUNCTIONS A BUYER CALLS. Nothing here is a mock-up and nothing is drawn by a side
/// previewer.
///
/// That is not a purity exercise. A sibling product in this wing built its gallery from a
/// JavaScript previewer that RE-IMPLEMENTED the drawing layer, and the previewer had a defect
/// invisible in itself and plainly visible in engine - so the store page was a picture of a
/// reimplementation. Baking through Igor lets the listing say "every image on this page was
/// rendered by the product itself" and have it be true.
///
/// ⛔ AND THE EXTENT CHECK IS ONE NUMBER, BLIND IN TWO DIRECTIONS. A returned y only answers "did
/// the last thing drawn fall off the BOTTOM" - it cannot see horizontal overflow and it cannot see
/// emptiness. Both blind spots shipped on a sibling product while it reported ok. So every sheet is
/// ALSO measured as rendered pixels: an ink bounding box answering clipping AND coverage.
///
/// ⚠️ AND THE INK BOX HAS A PERMANENT BLIND SPOT OF ITS OWN: a bounding box cannot see the space
/// INSIDE itself. Three small objects adrift on a big page score well and look empty. The floors
/// here catch an EMPTY sheet and a CLIPPED one; they do not judge a sparse one, and the only
/// instrument for that is opening the PNG and looking at it. Never tune the number to pass.
/// ============================================================================================

#macro ARM_SHEET_W 1600
#macro ARM_SHEET_H 1000

function arm_bk_page()  { return arm_oklch(0.150, 0.008, 258); }
function arm_bk_ink()   { return arm_oklch(0.890, 0.010, 258); }
function arm_bk_dim()   { return arm_oklch(0.570, 0.010, 258); }
function arm_bk_rule()  { return arm_oklch(0.320, 0.012, 258); }
function arm_bk_warm()  { return arm_oklch(0.720, 0.075, 62);  }

/// A sheet title and its rule. Returns the y below the rule.
///
/// ⛔ arm_text_label, NOT arm_text_fit. The two differ in TWO ways and only one of them is in their
/// names: `fit` centres on the x it is given, `label` treats it as a left edge. The first bake of
/// this product passed a left edge to `fit` on every sheet, so "EIGHTEEN BLADE PROFILES" rendered as
/// "BLADE PROFILES" and "ARMOURY" as "RMOURY" - the title of the hero sheet, cut in half, on nine
/// sheets and the cover at once.
///
/// ⚠️ AND arm_text_fit's OWN HEADER WARNS ABOUT IT IN AS MANY WORDS - "if you are passing a left
/// edge, you want arm_text_line" - because a sibling product in this wing shipped exactly this and
/// read "atch, cob, one storey". Reading the warning is not the same as heeding it; what actually
/// caught it was opening the PNG. The ink box saw it too, as fullBox[0] = 0 on nine of ten sheets,
/// and that number was sitting in the bake report before I looked at the picture.
function arm_bk_head(_title, _sub, _y) {
    arm_text_label(_title, 60, _y, ARM_SHEET_W - 120, 46, arm_bk_page(), arm_bk_ink());
    var _yy = _y + 58;
    if (_sub != "") {
        arm_text_body(_sub, 60, _yy, ARM_SHEET_W - 480, 19, arm_bk_dim());
        _yy += 30;
    }
    draw_set_colour(arm_bk_rule());
    draw_rectangle(60, _yy + 14, ARM_SHEET_W - 60, _yy + 15, false);
    return _yy + 40;
}

/// A caption under a cell.
///
/// ⛔ IT IS MEASURED AND SCALED TO ITS CELL. This wing shipped the SAME overflow defect twice -
/// "WickthorSt Cuthman's" and "HEDGEHOG FUNGUSCAULIFLOWER FUNGUS" - because the first fix shortened
/// the DATA rather than making the caption honest about its width. No ink check will ever catch it:
/// overprinted text is ink exactly where ink belongs. Found only by reading the sheet.
function arm_bk_caption(_text, _cx, _y, _maxw, _px, _col) {
    arm_text_line(_text, _cx - _maxw * 0.5, _y, _maxw, _px, _col, false);
}

/// Measure the rendered pixels. See this file's header for what it can and cannot see.
function arm_bk_ink_bounds(_w, _h, _contentY) {
    var _buf = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_buf, surface_get_target(), 0);
    var _pg = arm_bk_page();
    var _pr = colour_get_red(_pg), _pgn = colour_get_green(_pg), _pb = colour_get_blue(_pg);

    var _fx0 = _w, _fy0 = _h, _fx1 = -1, _fy1 = -1;
    var _cx0 = _w, _cy0 = _h, _cx1 = -1, _cy1 = -1;
    var _ink = 0;

    // ⛔ y STEPS BY 1. A 1px hairline lands on one row and an even-only scan walks straight past it,
    // which is exactly the feature most likely to be clipped. x may step by 2 - nothing in this
    // package draws a 1px-wide VERTICAL feature that is not part of a wider mark.
    for (var _y = 0; _y < _h; _y++) {
        for (var _x = 0; _x < _w; _x += 2) {
            var _o = (_y * _w + _x) * 4;
            var _r = buffer_peek(_buf, _o, buffer_u8);
            var _g = buffer_peek(_buf, _o + 1, buffer_u8);
            var _b = buffer_peek(_buf, _o + 2, buffer_u8);
            if (abs(_r - _pr) <= 10 && abs(_g - _pgn) <= 10 && abs(_b - _pb) <= 10) continue;
            _ink += 1;
            if (_x < _fx0) _fx0 = _x;
            if (_x > _fx1) _fx1 = _x;
            if (_y < _fy0) _fy0 = _y;
            if (_y > _fy1) _fy1 = _y;
            if (_y >= _contentY) {
                if (_x < _cx0) _cx0 = _x;
                if (_x > _cx1) _cx1 = _x;
                if (_y < _cy0) _cy0 = _y;
                if (_y > _cy1) _cy1 = _y;
            }
        }
    }
    buffer_delete(_buf);
    return { full: [_fx0, _fy0, _fx1, _fy1], content: [_cx0, _cy0, _cx1, _cy1], ink: _ink };
}

/// ============================================================================================
/// THE SHEETS. Every one returns the y it finished at.
/// ============================================================================================

/// SHEET - HERO. One weapon, large, with its own generated description beside it.
function arm_bk_hero() {
    var _y = arm_bk_head("ARMOURY",
        "Weapons that forge themselves from what they are made of and what they have done. "
      + "Every mark on this page was drawn in GML by the package itself.", 54);

    // ⛔ THREE WEAPONS, NOT ONE. The first version of this sheet drew a single longsword on the left
    // third and left the rest of the page empty - contentW 0.649, which is the ink box reporting a
    // sheet that is two thirds void. A bounding box cannot see the space INSIDE itself, so no floor
    // in this file could ever have failed it; opening the PNG is the only instrument for sparseness.
    var _w = arm_forge("longsword", "heirloom", 8812);
    var _w2 = arm_forge("bearded", "militia", 4410);
    var _w3 = arm_forge("halberd", "temple", 7731);
    var _w4 = arm_forge("flanged", "guild", 5150);
    arm_draw_at_scale(_w2, 108, ARM_SHEET_H - 60, ARM_SHEET_H - 230);
    arm_draw_at_scale(_w,  268, ARM_SHEET_H - 60, ARM_SHEET_H - 230);
    arm_draw_at_scale(_w4, 420, ARM_SHEET_H - 60, ARM_SHEET_H - 230);
    arm_draw_at_scale(_w3, 560, ARM_SHEET_H - 60, ARM_SHEET_H - 230);

    var _tx = 700;
    arm_text_label(arm_name(_w), _tx, _y + 24, 840, 40, arm_bk_page(), arm_bk_ink());
    arm_text_body(arm_describe(_w), _tx, _y + 90, 820, 21, arm_bk_dim());
    arm_text_line(arm_stat_line(_w), _tx, _y + 178, 820, 21, arm_bk_warm(), false);

    // The same weapon in the sizes a game actually draws it at.
    var _cy = _y + 250;
    arm_text_line("THE SAME WEAPON, AT THE SIZES A GAME DRAWS IT", _tx, _cy, 820, 17,
                  arm_bk_dim(), false);
    var _sizes = [96, 64, 48, 32];
    for (var _i = 0; _i < 4; _i++) {
        var _x = _tx + 60 + _i * 130;
        arm_render_scrim(_x - 52, _cy + 36, 104, 104, arm_oklch(0.235, 0.008, 258), 1.0);
        arm_draw_icon(_w, _x, _cy + 88, _sizes[_i]);
        arm_bk_caption(string(_sizes[_i]) + " px", _x, _cy + 148, 120, 15, arm_bk_dim());
    }

    // ⛔ WHAT THIS SHEET SAYS ABOUT THE WEAPON IS READ OFF THE WEAPON. The first version hard-coded
    // these four lines, and they IMMEDIATELY disagreed with the description printed six centimetres
    // above them on the same image: the prose said "120 years old" and "Four owners. Four marks"
    // while arm_describe - reading the actual struct - said 125 years and 3 marks. A store image
    // that contradicts itself is a false market claim (master CLAUDE.md section 2), and a hard-coded
    // sentence about generated data is that defect waiting for the seed to change.
    var _hy = _cy + 200;
    arm_text_line("WHAT ITS HISTORY DID TO THE PICTURE", _tx, _hy, 820, 17, arm_bk_dim(), false);
    var _h = _w.history;
    var _lines = [
        string(floor(_h.age)) + " years old, and looked after - so it is "
            + string(round(arm_history_hone(_h) * 30)) + " percent NARROWER, not notched.",
        // ⚠️ THE COUNT IS USUALLY ZERO HERE, AND "carries only 0 notches" IS NOT A SENTENCE ANYONE
        // WRITES. The number is real and is kept; only the phrasing branches on it, because a
        // generated caption that reads as generated undoes the work the picture is doing.
        (array_length(arm_history_notches(_h)) == 0
            ? "Its owners ground the damage out. That is why it carries no notches at all."
            : "Its owners ground most of the damage out. It carries "
              + string(array_length(arm_history_notches(_h))) + " notches."),
        string(_h.owners) + " owners, and " + string(array_length(_h.marks))
            + " marks struck into the steel.",
        "None of this is a variant sprite. It is one weapon, aged.",
    ];
    for (var _j = 0; _j < 4; _j++) {
        arm_text_line(_lines[_j], _tx, _hy + 34 + _j * 30, 820, 19, arm_bk_ink(), false);
    }
    return _hy + 34 + 4 * 30 + 40;
}

/// SHEET - THE CORPUS. Every form the package makes, at a COMMON SCALE.
function arm_bk_corpus() {
    var _y = arm_bk_head("THIRTY-SEVEN FORMS, ONE SCALE",
        "Drawn at their true relative sizes. A dagger is small here because a dagger is small.",
        54);
    var _forms = arm_form_names();
    var _n = array_length(_forms);
    var _cols = 19;
    var _rows = ceil(_n / _cols);
    var _cw = (ARM_SHEET_W - 100) / _cols;
    var _ch = (ARM_SHEET_H - _y - 40) / _rows;

    // ⭐ A GROUND LINE AND A METRE RULE. The sheet's whole claim is that these are true relative
    // sizes, and a claim about scale with no scale on the page is a caption asking to be believed.
    //
    // ⚠️ IT ALSO ANSWERS A REAL MEASUREMENT. This sheet failed its own ink floor at 14,061 against
    // 40,000 - thirty-seven small weapons at true scale on a 1600x1000 page IS sparse, and it is
    // sparse for a reason that cannot be fixed by drawing them bigger without destroying the point.
    // The rule and the baselines add the missing structure instead of tuning the number, which is
    // this wing's standing rule about density floors.
    var _ppu = (_ch - 40) * 1.0;
    for (var _rw2 = 0; _rw2 < _rows; _rw2++) {
        var _b2 = _y + _ch * (_rw2 + 1) - 26;
        draw_set_colour(arm_bk_rule());
        draw_rectangle(50, _b2, ARM_SHEET_W - 50, _b2 + 1, false);
        // Metre gradations above each baseline, so a reader can measure any weapon off the page.
        for (var _m = 1; _m <= 2; _m++) {
            var _my = _b2 - _m * ARM_METRE * _ppu;
            if (_my < _y) break;
            draw_set_colour(arm_oklch(0.245, 0.010, 258));
            draw_rectangle(50, _my, ARM_SHEET_W - 50, _my + 1, false);
            arm_text_line(string(_m) + " m", 54, _my - 16, 60, 12,
                          arm_oklch(0.430, 0.010, 258), false);
        }
    }

    for (var _i = 0; _i < _n; _i++) {
        var _c = _i mod _cols, _rw = _i div _cols;
        var _x = 50 + _cw * (_c + 0.5);
        var _base = _y + _ch * (_rw + 1) - 26;
        var _w = arm_forge(_forms[_i], "issue", 200 + _i * 13);
        arm_draw_at_scale(_w, _x, _base, _ppu);
        arm_bk_caption(arm_form_label(_forms[_i]), _x, _base + 6, _cw - 4, 13, arm_bk_dim());
    }
    return _y + _ch * _rows + 30;
}

/// SHEET - THE ARGUMENT. One weapon, two lives.
///
/// ⭐ THIS IS THE SHEET THE PRODUCT IS SOLD ON, and it is the one no sprite pack can answer. The
/// same sword, same seed, same everything, run forward through the same forty fights - once cared
/// for and once neglected. The top row goes narrow and clean; the bottom row goes notched and red.
/// A pack would need two hundred images to show this and would still not let a player cause it.
function arm_bk_history() {
    var _y = arm_bk_head("ONE SWORD, FORTY FIGHTS, TWO OWNERS",
        "Identical weapon and identical seed in both rows. The only difference is whether its "
      + "owner looked after it. Care does not remove damage - it MOVES it, out of the silhouette "
      + "and into the width.", 54);

    var _steps = 6;
    var _cw = (ARM_SHEET_W - 140) / _steps;
    var _rows = [{ care: 0.95, label: "KEPT: oiled, and the notches ground out" },
                 { care: 0.05, label: "NEGLECTED: never oiled, never ground" }];

    // ⚠️ THE FIRST VERSION OF THIS SHEET DREW THE SWORDS AT SCALE 470 IN 400px ROWS AND LEFT HALF
    // THE PAGE EMPTY. Twelve small weapons floating in dark space is the sparseness the ink box is
    // structurally unable to see - a bounding box cannot measure the space inside itself. Bigger
    // weapons and tighter rows, and the change is composition, never a threshold.
    for (var _rr = 0; _rr < 2; _rr++) {
        var _ry = _y + 16 + _rr * 390;
        // ⛔ AN ACCENT BAR AND A RULE, NOT A FULL-BLEED SCRIM. A tinted panel behind each row would
        // separate the two lives nicely and would ALSO make every pixel under it count as ink -
        // arm_bk_ink_bounds measures against the PAGE colour, so a sheet that is 90% scrim reports
        // full coverage and zero clipping no matter what is drawn on it. That is a check that
        // cannot fail, which this wing treats as no check at all. The bar is 10px wide and the rule
        // is 1px, so both are visible to a reader and neither can flood the measurement.
        var _aL = (_rr == 0) ? 0.62 : 0.42;
        var _accent = arm_oklch(_aL, (_rr == 0) ? 0.020 : 0.090, (_rr == 0) ? 250 : 44);
        draw_set_colour(_accent);
        draw_rectangle(52, _ry - 6, 74, _ry + 360, false);
        // A solid header plate in the row's own colour. Two of these are the strongest thing on the
        // page and they are what finally separated this sheet from the corpus grid: with only a
        // 10px bar the two still hashed at distance 7 against a threshold of 8, which is a pass by
        // one bit and not a difference a buyer would notice either.
        draw_rectangle(52, _ry - 6, 52 + 26 + string_length(_rows[_rr].label) * 10, _ry + 28, false);
        draw_set_colour(arm_bk_rule());
        draw_rectangle(52, _ry + 362, ARM_SHEET_W - 60, _ry + 363, false);
        // ⛔ THE LABEL INK IS CHOSEN AGAINST THE PLATE IT SITS ON, NOT FIXED. Both labels were drawn
        // in arm_bk_page() (L 0.150), which is right on the KEPT plate (L 0.62, contrast 0.47) and
        // WRONG on the NEGLECTED one (L 0.42, contrast 0.27) - so the row that carries half the
        // sheet's argument had a caption a reader could barely make out at 1x. Found 2026-09-07 by
        // cropping that band and zooming it 3x; the density gate passed the sheet, because a
        // coverage floor cannot see contrast.
        //
        // The choice is DERIVED from the two inks' own lightnesses rather than tuned: take whichever
        // of page (0.150) and ink (0.890) sits further from the plate. That keeps the fix correct if
        // anyone later re-tints a row, which a hand-picked colour would not.
        var _label_col = (abs(_aL - 0.150) >= abs(_aL - 0.890)) ? arm_bk_page() : arm_bk_ink();
        arm_text_line(_rows[_rr].label, 86, _ry + 2, 900, 21, _label_col, false);
        var _w = arm_forge("arming", "issue", 4242);
        for (var _s = 0; _s < _steps; _s++) {
            var _x = 70 + _cw * (_s + 0.5);
            arm_draw_at_scale(_w, _x, _ry + 322, 730);
            arm_bk_caption(string(_s * 8) + " fights", _x, _ry + 330, _cw - 10, 16, arm_bk_dim());
            arm_bk_caption(arm_condition_word(_w), _x, _ry + 352, _cw - 10, 16, arm_bk_warm());
            _w = arm_use(_w, 8, 4, _rows[_rr].care);
        }
    }
    return _y + 16 + 390 + 375;
}

/// SHEET - PROVENANCE. The same form, seven origins.
function arm_bk_lives() {
    var _y = arm_bk_head("SEVEN ORIGINS, ONE FORM",
        "The same billhook, made and owned seven different ways. Materials, fittings, wear and "
      + "the marks on it all follow from where it came from.", 54);
    var _provs = arm_provenance_names();
    var _n = array_length(_provs);
    var _cw = (ARM_SHEET_W - 120) / _n;

    // ⚠️ THE HEADS ARE SHOWN LARGE AND THE WHOLE WEAPONS SMALL BENEATH THEM, which is the opposite
    // of the other sheets and is deliberate twice over. A billhook's provenance lives in its HEAD -
    // the metal, the corrosion, the notching, the langets - and at full length that head is eighty
    // pixels of a nine-hundred-pixel column. It also stops this sheet hashing as another row of
    // small objects on a dark page; see arm_bk_metals for what that check caught.
    for (var _i = 0; _i < _n; _i++) {
        var _x = 60 + _cw * (_i + 0.5);
        var _w = arm_forge("billhook", _provs[_i], 616 + _i * 31);
        var _parts = arm_forge_parts(_w);
        var _pal = arm_forge_palette(_w);

        // ⛔ THE HEAD IS BUILT SEPARATELY. IT IS NOT A ZOOMED-IN WHOLE WEAPON.
        //
        // MEASURED 2026-08-30 by baking this sheet and looking at it: the first version drew the
        // complete weapon at scale 2050 hoping the head would land in the box. arm_draw_at_scale
        // anchors the BUTT, so what actually filled every cell was the bottom of the haft and its
        // butt cap, with the heads somewhere off the top of the page and seven shafts running
        // straight through the title. Every mechanical check passed - the ink was high, nothing was
        // clipped by the ink box's definition, and the sheet was almost entirely wrong.
        //
        // arm_head_parts returns exactly the head, so the tight fitter can measure the thing that
        // is actually meant to be in the box. Anchoring by hope is not anchoring.
        var _hp = arm_head_parts(_w.form, "e", 0, _w.history.seed, arm_history_wear(_w.history));
        arm_render_in_rect_tight(_hp, _pal, _x - _cw * 0.44, _y + 40, _cw * 0.88, 420, undefined);

        draw_set_colour(arm_bk_rule());
        draw_rectangle(_x - _cw * 0.44, _y + 496, _x + _cw * 0.44, _y + 497, false);

        arm_bk_caption(string_upper(_provs[_i]), _x, _y + 512, _cw - 8, 21, arm_bk_warm());
        arm_bk_caption(arm_condition_word(_w), _x, _y + 540, _cw - 8, 17, arm_bk_dim());
        arm_bk_caption(arm_material_label(_w.edge_mat), _x, _y + 562, _cw - 8, 17, arm_bk_dim());

        // And the whole thing, small, so the head above is legibly part of a weapon.
        arm_render_in_rect_tight(_parts, _pal, _x - _cw * 0.30, _y + 578, _cw * 0.60, 202,
                                 undefined);
    }
    return _y + 786;
}

/// The metals shown in the corroded row, and the SINGLE place that set is declared.
///
/// ⚠️ EIGHT, WITH THEIR RAMPS, ACROSS THE FULL WIDTH. The first version showed four metals with no
/// ramps and left the bottom-right quarter of the sheet empty - and it also made the most
/// interesting claim on the page (that decay PULLS toward a target rather than scaling) with half
/// the evidence. Bronze going green while steel goes orange is the whole argument, and it is only
/// legible with the ramps beside it.
///
/// ⛔ Gold is deliberately absent: its decay is "none", so a corroded gold blade is the same blade
/// and the cell would argue against the row it is in.
function arm_bk_corroded_names() {
    return ["steel", "iron", "bogiron", "watered", "bronze", "brass", "silver", "bone"];
}

/// SHEET - METAL. Every material, on one blade.
function arm_bk_metals() {
    var _y = arm_bk_head("TWENTY MATERIALS, COMPUTED NOT TABULATED",
        "No hex values anywhere in the package. Each is a base colour and a lightness span in "
      // ⛔ "four" HERE WAS A STALE CLAIM AND THE ROW BELOW HAS SHOWN EIGHT SINCE IT WAS WIDENED —
      // the widening comment at `_cor` even says so. A caption that miscounts what is directly
      // beneath it is the cheapest possible thing for a buyer to catch us on, and the count is
      // taken from the array now rather than typed, so it cannot go stale again.
      + "Oklab, so it can be asked for at any age. Bottom row: the same "
      + string(array_length(arm_bk_corroded_names())) + " metals, corroded.", 54);
    var _mats = arm_material_names();
    var _cols = 10;
    var _cw = (ARM_SHEET_W - 120) / _cols;

    for (var _i = 0; _i < array_length(_mats); _i++) {
        var _c = _i mod _cols, _rw = _i div _cols;
        var _x = 60 + _cw * (_c + 0.5);
        var _yy = _y + 40 + _rw * 250;
        // A blade in this material, drawn directly rather than through the forge, so the sheet
        // shows the MATERIAL and not a weapon that happens to use it.
        var _pal = {};
        arm_material_into(_pal, "e", _mats[_i], 0, 0);
        _pal.line = arm_material_ink(_mats[_i], 0);
        var _parts = arm_blade_parts("arming", "e", arm_wear_none(), 0, 1, false);
        arm_render_in_rect_tight(_parts, _pal, _x - _cw * 0.42, _yy, _cw * 0.84, 150, undefined);

        // ⭐ THE FIVE STOPS, SHOWN AS THE BAR THEY ARE. This is what a material IS in this package -
        // arm_relief picks one of these five by how squarely a surface faces the lamp - so showing
        // the ramp beside the blade shows the reader the actual mechanism rather than its result.
        //
        // ⚠️ IT IS ALSO WHY THIS SHEET NO LONGER LOOKS LIKE THE OTHER THREE. Kernel/capture/dedupe
        // read corpus, history, lives and metals as ONE image (Hamming distance 3 to 7): four grids
        // of small dark objects on a dark page under a title bar have the same perceptual hash
        // whatever is in them. That is a real finding about the GALLERY, not a limitation of the
        // checker - a buyer scrolling four near-identical thumbnails learns nothing from three of
        // them. The fix is a different LAYOUT, never a higher threshold.
        var _ramp = arm_material_ramp(_mats[_i], 0, 0);
        var _bw = (_cw - 20) / ARM_RAMP_N;
        for (var _b = 0; _b < ARM_RAMP_N; _b++) {
            draw_set_colour(_ramp[_b]);
            draw_rectangle(_x - (_cw - 20) * 0.5 + _b * _bw, _yy + 158,
                           _x - (_cw - 20) * 0.5 + (_b + 1) * _bw - 2, _yy + 186, false);
        }
        arm_bk_caption(arm_material_label(_mats[_i]), _x, _yy + 194, _cw - 6, 15, arm_bk_dim());
    }

    var _cy = _y + 40 + 2 * 250 + 30;
    arm_text_line("THE SAME METALS AFTER A LIFETIME WITH NO OIL", 60, _cy, 900, 19,
                  arm_bk_dim(), false);
    // ⚠️ EIGHT, WITH THEIR RAMPS, ACROSS THE FULL WIDTH. The first version showed four metals with
    // no ramps and left the bottom-right quarter of the sheet empty - and it also made the most
    // interesting claim on the page (that decay PULLS toward a target rather than scaling) with
    // half the evidence. Bronze going green while steel goes orange is the whole argument, and it
    // is only legible with the ramps beside it.
    // ⛔ ONE DECLARATION, READ BY BOTH THE ROW AND THE CAPTION. The literal `8` in the loop bound
    // was the second place this count lived, and the header's "four" was the third — which is how
    // the caption came to miscount a row sitting directly under it. Two copies of a fact are a
    // fact that can drift (master §2b: find the READER).
    var _cor = arm_bk_corroded_names();
    for (var _j = 0; _j < array_length(_cor); _j++) {
        var _x2 = 60 + _cw * (_j + 0.5);
        var _p2 = {};
        arm_material_into(_p2, "e", _cor[_j], 0.95, 0);
        _p2.line = arm_material_ink(_cor[_j], 0.95);
        var _pt2 = arm_blade_parts("arming", "e", arm_wear_none(), 0, 1, false);
        arm_render_in_rect_tight(_pt2, _p2, _x2 - _cw * 0.42, _cy + 30, _cw * 0.84, 118, undefined);

        var _r2 = arm_material_ramp(_cor[_j], 0.95, 0);
        var _bw2 = (_cw - 20) / ARM_RAMP_N;
        for (var _b2 = 0; _b2 < ARM_RAMP_N; _b2++) {
            draw_set_colour(_r2[_b2]);
            draw_rectangle(_x2 - (_cw - 20) * 0.5 + _b2 * _bw2, _cy + 154,
                           _x2 - (_cw - 20) * 0.5 + (_b2 + 1) * _bw2 - 2, _cy + 180, false);
        }
        arm_bk_caption(arm_material_label(_cor[_j]), _x2, _cy + 188, _cw - 6, 15, arm_bk_dim());
    }
    return _cy + 214;
}

/// SHEET - BLADES. The profile corpus.
function arm_bk_blades() {
    var _y = arm_bk_head("EIGHTEEN BLADE PROFILES",
        "Each is a length, a width, a taper, a belly, a curvature and a point type - not a "
      + "drawing. The generator can produce anything between them.", 54);
    var _names = arm_blade_names();
    var _cols = 9;
    var _cw = (ARM_SHEET_W - 120) / _cols;
    var _rows = ceil(array_length(_names) / _cols);
    var _ch = (ARM_SHEET_H - _y - 50) / _rows;

    for (var _i = 0; _i < array_length(_names); _i++) {
        var _c = _i mod _cols, _rw = _i div _cols;
        var _x = 60 + _cw * (_c + 0.5);
        var _yy = _y + _ch * _rw + 10;
        var _pal = {};
        arm_material_into(_pal, "e", "steel", 0.06, 0);
        _pal.line = arm_material_ink("steel", 0.06);
        var _parts = arm_blade_parts(_names[_i], "e", arm_wear_none(), 0, 7 + _i, false);
        arm_render_in_rect_tight(_parts, _pal, _x - _cw * 0.40, _yy, _cw * 0.80, _ch - 54,
                                 undefined);
        arm_bk_caption(arm_form_label(_names[_i]), _x, _yy + _ch - 46, _cw - 6, 15, arm_bk_dim());
    }
    return _y + _ch * _rows + 30;
}

/// SHEET - HEADS.
function arm_bk_heads() {
    var _y = arm_bk_head("NINETEEN HEADS",
        "Axes are one closed outline, because a forged axe head is one piece of metal. Polearm "
      + "heads are blades on sockets, which is what they are.", 54);
    var _names = arm_head_names();
    var _cols = 10;
    var _cw = (ARM_SHEET_W - 120) / _cols;
    var _rows = ceil(array_length(_names) / _cols);
    var _ch = (ARM_SHEET_H - _y - 50) / _rows;

    for (var _i = 0; _i < array_length(_names); _i++) {
        var _c = _i mod _cols, _rw = _i div _cols;
        var _x = 60 + _cw * (_c + 0.5);
        var _yy = _y + _ch * _rw + 10;
        var _w = arm_forge(_names[_i], "guild", 40 + _i * 17);
        var _parts = arm_forge_parts(_w);
        arm_render_in_rect_tight(_parts, arm_forge_palette(_w),
                                 _x - _cw * 0.42, _yy, _cw * 0.84, _ch - 54, undefined);
        arm_bk_caption(arm_form_label(_names[_i]), _x, _yy + _ch - 46, _cw - 6, 15, arm_bk_dim());
    }
    return _y + _ch * _rows + 30;
}

/// SHEET - HILTS.
function arm_bk_hilts() {
    var _y = arm_bk_head("EIGHT POMMELS, EIGHT GUARDS",
        "A blade says what a weapon is for. A hilt says who paid for it. Every combination is "
      + "reachable, and the forge refuses the ones that would be a lie - a bog-iron militia sword "
      + "does not get a basket hilt.", 54);

    var _pom = arm_pommel_names();
    var _gua = arm_guard_names();
    var _cw = (ARM_SHEET_W - 120) / 8;

    arm_text_line("POMMELS", 60, _y + 6, 400, 19, arm_bk_warm(), false);
    for (var _i = 0; _i < array_length(_pom); _i++) {
        var _x = 60 + _cw * (_i + 0.5);
        var _pal = {};
        arm_material_into(_pal, "f", "brass", 0.10, 0);
        _pal.line = arm_material_ink("brass", 0.10);
        var _parts = arm_pommel_parts(_pom[_i], "f", 0.020, 0, 3 + _i);
        arm_render_in_rect_tight(_parts, _pal, _x - _cw * 0.36, _y + 34, _cw * 0.72, 150,
                                 undefined);
        arm_bk_caption(_pom[_i], _x, _y + 194, _cw - 6, 15, arm_bk_dim());
    }

    // ⚠️ THE THREE BANDS ARE SOLVED AGAINST THE PAGE, NOT STACKED BY EYE. The first layout put them
    // at +40, +290 and +620 and ran to endY 1072 on a 1000px sheet - the extent check caught it, and
    // the ink box confirmed it with fullBox bottom at 999. Sizing a band from the space available
    // rather than adding fixed offsets is what makes it impossible to clip by construction.
    var _gy = _y + 262;
    arm_text_line("GUARDS", 60, _gy, 400, 19, arm_bk_warm(), false);
    for (var _j = 0; _j < array_length(_gua); _j++) {
        var _x2 = 60 + _cw * (_j + 0.5);
        var _p2 = {};
        arm_material_into(_p2, "f", "steel", 0.10, 0);
        _p2.line = arm_material_ink("steel", 0.10);
        var _pt = arm_guard_parts(_gua[_j], "f", 0.045, 0, 11 + _j);
        if (array_length(_pt) > 0) {
            arm_render_in_rect_tight(_pt, _p2, _x2 - _cw * 0.40, _gy + 34, _cw * 0.80, 176,
                                     undefined);
        }
        arm_bk_caption(_gua[_j], _x2, _gy + 220, _cw - 6, 15, arm_bk_dim());
    }

    // Whole hilts, so the parts above are seen doing their job.
    var _hy = _gy + 268;
    arm_text_line("AND ASSEMBLED", 60, _hy, 400, 19, arm_bk_warm(), false);
    for (var _k = 0; _k < 8; _k++) {
        var _x3 = 60 + _cw * (_k + 0.5);
        var _w2 = arm_forge("arming", arm_provenance_names()[_k mod ARM_PROV_N], 900 + _k * 41);
        arm_draw_at_scale(_w2, _x3, _hy + 246, 596);
    }
    return _hy + 262;
}

/// SHEET - INVENTORY. The honest small sizes.
///
/// ⛔ THE CAPTION NAMES THE SIZE THE IMAGE IS ACTUALLY DRAWN AT. This wing shipped a proof plate
/// captioned "at dialogue size - 14 pixels" that was drawn at 34 because 14 looked too small. That
/// is a market claim the image does not support, and it was also the wrong instinct: the buyer's
/// real question is whether the thing reads when it is TINY.
function arm_bk_inventory() {
    var _y = arm_bk_head("AN INVENTORY, AT 32 PIXELS",
        "Drawn at the sizes named, not at a flattering size. Long weapons lay themselves on the "
      + "diagonal, because a two-metre spear upright in a 32px cell is a grey line.", 54);

    // ⚠️ THE GRID IS SIZED TO THE PAGE. At 12 x 4 cells of 74px it covered 888 x 296 of a 1600x1000
    // sheet and the ink box reported contentW 0.695, contentH 0.616 - a third of the page in each
    // direction doing nothing. An inventory sheet that does not look FULL is arguing against itself.
    var _forms = arm_form_names();
    var _cols = 17, _rows = 6;
    var _cell = 86;
    var _x0 = (ARM_SHEET_W - _cols * _cell) * 0.5, _y0 = _y + 16;

    for (var _i = 0; _i < _cols * _rows; _i++) {
        var _c = _i mod _cols, _rw = _i div _cols;
        var _x = _x0 + _c * _cell + _cell * 0.5;
        var _yy = _y0 + _rw * _cell + _cell * 0.5;
        // ⚠️ THE CELL GROUND IS LIGHTER THAN THE PAGE ON PURPOSE. At 0.225 the 32px icons were
        // nearly invisible against it - a dark weapon on a dark square. An inventory cell in a real
        // game is lighter than its background for exactly this reason.
        arm_render_scrim(_x - 40, _yy - 40, 80, 80, arm_oklch(0.295, 0.008, 258), 1.0);
        var _w = arm_forge(_forms[_i mod array_length(_forms)],
                           arm_provenance_names()[_i mod ARM_PROV_N], 3300 + _i * 7);
        arm_draw_icon(_w, _x, _yy, 32);   // 32, because the title says 32. See this sheet header.
    }

    var _by = _y0 + _rows * _cell + 26;
    arm_text_line("THE SAME FOUR WEAPONS AT 48 AND 64", 90, _by, 900, 19, arm_bk_dim(), false);
    var _big = ["greatsword", "halberd", "flanged", "sabre"];
    for (var _j = 0; _j < 4; _j++) {
        for (var _s = 0; _s < 2; _s++) {
            var _px = (_s == 0) ? 48 : 64;
            var _x2 = 120 + _j * 300 + _s * 130;
            var _w2 = arm_forge(_big[_j], "looted", 700 + _j);
            arm_render_scrim(_x2 - 40, _by + 40, 80, 80, arm_oklch(0.295, 0.008, 258), 1.0);
            arm_draw_icon(_w2, _x2, _by + 80, _px);
            arm_bk_caption(string(_px) + " px", _x2, _by + 128, 90, 14, arm_bk_dim());
        }
    }
    return _by + 160;
}

/// ============================================================================================
/// THE RUNNER
/// ============================================================================================

function arm_bk_one(_name, _fn, _contentY) {
    var _surf = surface_create(ARM_SHEET_W, ARM_SHEET_H);
    surface_set_target(_surf);
    draw_clear(arm_bk_page());
    arm_lamp_reset();

    var _endY = _fn();
    var _ib = arm_bk_ink_bounds(ARM_SHEET_W, ARM_SHEET_H, _contentY);

    surface_reset_target();
    surface_save(_surf, "sheet_" + _name + ".png");
    surface_free(_surf);

    var _clipped = (_endY > ARM_SHEET_H) || (_ib.full[3] >= ARM_SHEET_H - 6)
                || (_ib.full[2] >= ARM_SHEET_W - 6) || (_ib.full[0] <= 5) || (_ib.full[1] <= 5);
    var _cw = (_ib.content[2] - _ib.content[0]) / ARM_SHEET_W;
    var _chh = (_ib.content[3] - _ib.content[1]) / max(1, ARM_SHEET_H - _contentY);

    return "{\"name\":\"" + _name + "\""
         + ",\"endY\":" + string(round(_endY))
         + ",\"ink\":" + string(_ib.ink)
         + ",\"fullBox\":[" + string(_ib.full[0]) + "," + string(_ib.full[1]) + ","
                            + string(_ib.full[2]) + "," + string(_ib.full[3]) + "]"
         + ",\"contentW\":" + string_format(_cw, 1, 3)
         + ",\"contentH\":" + string_format(_chh, 1, 3)
         + ",\"clipped\":" + (_clipped ? "true" : "false")
         + ",\"ok\":" + ((!_clipped && _cw >= 0.86 && _chh >= 0.80 && _ib.ink > 40000)
                         ? "true" : "false")
         + "}";
}

/// ============================================================================================
/// THE COVER
///
/// ⚠️ 630x500 IS ITCH'S COVER SIZE and the cover is the only image most buyers ever see. It is
/// baked at its own size rather than cropped out of a sheet, because a cropped sheet is exactly
/// what a cover must not be.
/// ============================================================================================

#macro ARM_COVER_W 630
#macro ARM_COVER_H 500

function arm_bk_cover() {
    // ⛔ A RACK, NOT A SCATTER. The first cover crossed three weapons at three angles and read as
    // three objects dropped on a floor: unbalanced, mostly empty, and with no way for the eye to
    // enter it. At the 315px thumbnail itch actually shows on a shelf it was unreadable.
    //
    // Weapons standing in a row is the oldest arrangement there is for exactly this reason - it is
    // legible at any size, it shows VARIETY at a glance, which is the product's whole claim, and
    // the vertical rhythm gives the title somewhere to sit. Deliberately NOT a grid of forty: a
    // grid says "sprite sheet", which is the one thing this product argues it is not.
    var _rack = [
        arm_forge("halberd",    "issue",    233),
        arm_forge("bearded",    "militia",  517),
        arm_forge("longsword",  "temple",   991),
        arm_forge("flanged",    "guild",    404),
        arm_forge("sabre",      "looted",   612),
        arm_forge("dane",       "heirloom", 780),
    ];
    // ⛔ THE COVER FITS EACH WEAPON TO THE FRAME. IT DOES NOT USE THE COMMON SCALE.
    //
    // This is the one place in the package where arm_draw beats arm_draw_at_scale, and the reason
    // is worth writing down because it looks like an inconsistency. Drawn at true relative scale, a
    // rack of six ran a 2 m halberd against a 0.68 m sabre: the top forty percent of the cover was
    // empty, the short weapons were forty pixels of grey, and at the 315px thumbnail itch shows on
    // a shelf the whole thing read as matchsticks. True scale is a FACT ABOUT THE CORPUS and it has
    // its own sheet, captioned, where a buyer is already looking. A cover has one job.
    var _n = array_length(_rack);
    for (var _i = 0; _i < _n; _i++) {
        var _x = 46 + (ARM_COVER_W - 92) * ((_i + 0.5) / _n);
        arm_draw(_rack[_i], _x, 392, 348);
    }

    // A band under the title so the lettering never has to compete with a blade.
    arm_render_scrim(0, 396, ARM_COVER_W, ARM_COVER_H - 396, arm_oklch(0.115, 0.008, 258), 0.93);
    arm_text_label("ARMOURY", 40, 404, 550, 62, arm_bk_page(), arm_bk_ink());
    arm_text_line("WEAPONS THAT FORGE THEMSELVES", 44, 466, 550, 20, arm_bk_warm(), false);
    return ARM_COVER_H;
}

function arm_bake_cover() {
    var _surf = surface_create(ARM_COVER_W, ARM_COVER_H);
    surface_set_target(_surf);
    draw_clear(arm_bk_page());
    arm_lamp_reset();
    arm_bk_cover();
    var _ib = arm_bk_ink_bounds(ARM_COVER_W, ARM_COVER_H, 100);
    surface_reset_target();
    surface_save(_surf, "cover.png");
    surface_free(_surf);
    return "{\"name\":\"cover\",\"w\":" + string(ARM_COVER_W) + ",\"h\":" + string(ARM_COVER_H)
         + ",\"ink\":" + string(_ib.ink)
         + ",\"fullBox\":[" + string(_ib.full[0]) + "," + string(_ib.full[1]) + ","
                            + string(_ib.full[2]) + "," + string(_ib.full[3]) + "]"
         + ",\"ok\":" + ((_ib.ink > 20000 && _ib.full[0] > 2 && _ib.full[1] > 2
                          && _ib.full[2] < ARM_COVER_W - 2 && _ib.full[3] < ARM_COVER_H - 2)
                         ? "true" : "false") + "}";
}

/// ============================================================================================
/// THE DEMO GIF
///
/// ⭐ IT SHOWS ONE WEAPON AGEING, NOT FORTY WEAPONS CYCLING. A carousel of the corpus would be a
/// GIF of a sprite sheet, and the whole argument of this product is the thing a sprite sheet
/// cannot do. Two swords from one seed run forward through the same forty fights, side by side,
/// one cared for and one not - the left goes narrow and clean, the right goes notched and red.
///
/// ⛔ EVERY FRAME IS DRIVEN TO AN EXPLICIT STATE AND PHOTOGRAPHED. Nothing is animated and then
/// captured while it moves: arm_use is a pure function of the history, so frame N is built from
/// scratch at N fights. That is the wing's rule about never photographing an easing in progress,
/// and here it is free rather than a discipline.
/// ============================================================================================

function arm_pad3(_n) {
    // ⛔ PAD BY ARITHMETIC, NOT BY REPLACING SPACES IN A FORMATTED STRING. `string_replace` swaps
    // ONE occurrence, so string_replace(string_format(n,3,0), " ", "0") turns "  0" into "0 0" and
    // the frames save as `frame_0 0.png` - ffmpeg then finds no sequence while the upstream count
    // still reads the right number of files. Measured on a sibling product.
    if (_n < 10) return "00" + string(_n);
    if (_n < 100) return "0" + string(_n);
    return string(_n);
}

function arm_frames_run() {
    global.arm_stage = 200;
    var _w = 900, _h = 506;
    var _steps = 30;
    var _count = 0;

    var _kept = arm_forge("arming", "issue", 4242);
    var _left = arm_forge("arming", "issue", 4242);

    for (var _i = 0; _i < _steps; _i++) {
        var _surf = surface_create(_w, _h);
        surface_set_target(_surf);
        draw_clear(arm_bk_page());
        arm_lamp_reset();

        arm_text_label("ONE SWORD, TWO OWNERS", 34, 24, _w - 68, 30,
                       arm_bk_page(), arm_bk_ink());
        arm_text_line("The same weapon and the same seed. Only the care differs.",
                      34, 62, _w - 68, 15, arm_bk_dim(), false);

        // A held lead-in and a held tail, so the GIF reads as a sequence rather than a loop with
        // no beginning. The wing's gif_profile law: a lead-in and a closing hold are deliberate;
        // what is banned is the absence of any graduating run between them.
        var _k = clamp((_i - 3) / (_steps - 9), 0, 1);
        var _fights = round(_k * 40);

        arm_draw_at_scale(_kept, _w * 0.32, _h - 44, 1080);
        arm_draw_at_scale(_left, _w * 0.68, _h - 44, 1080);

        arm_text_line("KEPT", _w * 0.32 - 60, 92, 120, 17, arm_bk_warm(), false);
        arm_text_line("NEGLECTED", _w * 0.68 - 60, 92, 140, 17, arm_bk_ink(), false);
        arm_text_line(string(_fights) + " fights", 34, _h - 30, 200, 16, arm_bk_dim(), false);
        arm_text_line(arm_condition_word(_kept), _w * 0.32 - 60, _h - 28, 160, 16, arm_bk_warm(),
                      false);
        arm_text_line(arm_condition_word(_left), _w * 0.68 - 60, _h - 28, 160, 16, arm_bk_warm(),
                      false);

        surface_reset_target();
        surface_save(_surf, "frame_" + arm_pad3(_i) + ".png");
        surface_free(_surf);
        _count += 1;

        // Advance AFTER photographing, so frame 0 is the weapon as forged.
        if (_i >= 3 && _i < _steps - 6) {
            _kept = arm_use(_kept, 2, 1, 0.95);
            _left = arm_use(_left, 2, 1, 0.05);
        }
    }

    var _f = file_text_open_write("arm_frames.json");
    file_text_write_string(_f, "{\"frames\":" + string(_count)
        + ",\"w\":" + string(_w) + ",\"h\":" + string(_h) + "}");
    file_text_close(_f);
}

/// Bake every sheet and write the report.
function arm_bake_run() {
    var _rows = [];
    global.arm_stage = 100; array_push(_rows, arm_bk_one("1_hero", arm_bk_hero, 200));
    global.arm_stage = 101; array_push(_rows, arm_bk_one("2_corpus", arm_bk_corpus, 200));
    global.arm_stage = 102; array_push(_rows, arm_bk_one("3_history", arm_bk_history, 200));
    global.arm_stage = 103; array_push(_rows, arm_bk_one("4_lives", arm_bk_lives, 200));
    global.arm_stage = 104; array_push(_rows, arm_bk_one("5_metals", arm_bk_metals, 200));
    global.arm_stage = 105; array_push(_rows, arm_bk_one("6_blades", arm_bk_blades, 200));
    global.arm_stage = 106; array_push(_rows, arm_bk_one("7_heads", arm_bk_heads, 200));
    global.arm_stage = 107; array_push(_rows, arm_bk_one("8_hilts", arm_bk_hilts, 200));
    global.arm_stage = 108; array_push(_rows, arm_bk_one("9_inventory", arm_bk_inventory, 200));
    global.arm_stage = 109; array_push(_rows, arm_bake_cover());

    var _f = file_text_open_write("arm_bake.json");
    var _s = "[";
    for (var _i = 0; _i < array_length(_rows); _i++) {
        if (_i > 0) _s += ",";
        _s += _rows[_i];
    }
    file_text_write_string(_f, _s + "]");
    file_text_close(_f);
}
