/// ARMOURY - arm_material. What a weapon is MADE of, as five-stop relief ramps, and what time
/// and use do to it.
///
/// Every colour in this product is COMPUTED. There is no table of hex values in this package,
/// because a hex table is a thing a buyer cannot steer: ask it for "the same blade, forty years
/// of neglect later" and a table has no answer, while a ramp does.
///
/// -- WHAT A RAMP IS --------------------------------------------------------------------------
/// arm_relief shades a surface by how squarely it faces the lamp and returns one of five role
/// names, "m0" (facing away) through "m4" (facing the lamp). A MATERIAL is therefore five
/// colours, and arm_material_ramp() produces them. Hand the same steel two different corrosion
/// values and you get two ramps that are recognisably the same steel at two different ages.
///
/// ⛔ THE STOPS ARE SPACED IN OKLAB LIGHTNESS, NOT IN RGB. That is the whole reason arm_palette
/// exists. Five RGB-spaced stops on warm brass and five on cold steel have visibly different
/// contrast, and in this product those two materials sit ON THE SAME WEAPON, three millimetres
/// apart, lit by one lamp. Perceptual spacing is what lets one lamp light both correctly.
///
/// -- SPAN IS WHAT SEPARATES A POLISHED BLADE FROM A LEATHER GRIP ------------------------------
/// A sword is the hardest case this wing has drawn, because a single object carries a mirror
/// finish, a matte fibrous wrap, a horn scale and an oiled wooden haft within a hand's width of
/// each other, and the eye is close enough to tell them apart. SPAN does that work: steel and
/// leather at the same span read as the same stuff in two colours, which is the palette-swap
/// failure this product exists to avoid. Cord has almost no span because cord does not catch a
/// lamp; polished steel has nearly five times as much as anything organic in the list.
/// ============================================================================================

// ⚠️ ARM_RAMP_N IS DEFINED IN arm_relief, NOT HERE, AND IT IS DELIBERATELY NOT REPEATED.
// It belongs to the relief engine because it is the relief engine that decides how many stops a
// surface has - this file just fills them in. Declaring it in both places is what the first gate
// run of this product died on ("macro ARM_RAMP_N is already defined"), and the fix is not to
// rename one of them: a constant with two homes is a constant that will hold two values.

/// The number of named materials. Asserted against arm_material_names() by the suite, so the
/// list below and the names function can never drift apart silently.
#macro ARM_MAT_N 20

/// ============================================================================================
/// THE MATERIALS
///
/// Each is a base lightness, a chroma, a hue in degrees, how far the ramp spans in lightness,
/// and WHAT IT TURNS INTO when it is left alone. That last column is the product.
/// ============================================================================================

/// Each material is a base lightness, a chroma, a hue in degrees, how far the ramp spans in
/// lightness, and the name of the decay it suffers. A high span reads as a hard, polished
/// surface (steel, silver); a low span reads as a soft matte one (cord, leather).
function arm_material_spec(_mat) {
    switch (_mat) {
        // name           L      C      hue    span   decay        the surface being described
        case "bogiron":  return { L: 0.300, C: 0.020, h:  62, span: 0.30, decay: "rust" };      // smelted from marsh ore, never clean
        case "iron":     return { L: 0.345, C: 0.011, h: 252, span: 0.42, decay: "rust" };      // wrought, hammered, fittings
        case "steel":    return { L: 0.560, C: 0.006, h: 250, span: 0.58, decay: "rust" };      // a polished blade
        case "watered":  return { L: 0.480, C: 0.012, h: 248, span: 0.52, decay: "rust" };      // crucible / pattern-welded
        case "blackened":return { L: 0.190, C: 0.008, h: 258, span: 0.34, decay: "rust" };      // fire-blued, oil-blacked
        case "bronze":   return { L: 0.505, C: 0.086, h:  68, span: 0.40, decay: "verdigris" }; // cast, the old metal
        case "brass":    return { L: 0.600, C: 0.098, h:  88, span: 0.42, decay: "verdigris" }; // furniture, ferrules
        case "silver":   return { L: 0.780, C: 0.006, h: 250, span: 0.50, decay: "tarnish" };   // hilt inlay, chape
        case "gold":     return { L: 0.740, C: 0.120, h:  88, span: 0.44, decay: "none" };      // temple fittings
        case "meteoric": return { L: 0.400, C: 0.014, h: 268, span: 0.50, decay: "rust" };      // sky-iron, faintly cool
        case "gilt":     return { L: 0.700, C: 0.108, h:  86, span: 0.40, decay: "tarnish" };   // gold leaf over steel
        case "niello":   return { L: 0.150, C: 0.012, h: 282, span: 0.20, decay: "none" };      // black inlay in a groove
        // ⚠️ WOOD CHROMA IS LOW AND THE FIRST VALUES HERE WERE NOT. MEASURED 2026-08-30 on the heads
        // sheet: ash at C 0.048 rendered every polearm haft as bright yellow bamboo, and a corpus
        // where the most common single surface is that colour reads as a toy. Seasoned ash is a
        // pale GREY-brown; the warmth is in the ramp's hue, not in its saturation. A haft is also
        // the largest continuous area in the whole package, and chroma has to come down over a
        // large flat area - the same correction this wing made to an earth-plaster wall.
        case "ash":      return { L: 0.610, C: 0.026, h:  74, span: 0.22, decay: "weather" };   // the haft wood, springy
        case "oak":      return { L: 0.385, C: 0.030, h:  58, span: 0.26, decay: "weather" };   // heavy haft, hafted axes
        case "yew":      return { L: 0.495, C: 0.038, h:  46, span: 0.24, decay: "weather" };   // bow stave, warm
        case "horn":     return { L: 0.330, C: 0.040, h:  48, span: 0.32, decay: "none" };      // grip scales, translucent
        // ⛔ BONE IS THE TUNING MATERIAL FOR EVERY TRANSFORM IN THIS FILE, AND THAT IS DELIBERATE.
        // The wing's own law (Repast, 2026-08-30): a colour model tuned on one subject is tuned on
        // the one that did not need the missing term. Bone is the PALEST and nearly the most
        // NEUTRAL thing here, so it is the material on which a multiplicative decay visibly does
        // nothing - which is what proves the decay below is a PULL and not a scale.
        case "bone":     return { L: 0.820, C: 0.026, h:  88, span: 0.26, decay: "stain" };     // grip, pommel cap
        case "leather":  return { L: 0.360, C: 0.070, h:  44, span: 0.24, decay: "darken" };    // wrap, scabbard
        case "cord":     return { L: 0.620, C: 0.040, h:  78, span: 0.12, decay: "soil" };      // whipping, lashing
        case "wire":     return { L: 0.700, C: 0.020, h: 250, span: 0.46, decay: "tarnish" };   // twisted grip wire
    }
    return { L: 0.500, C: 0.030, h: 70, span: 0.30, decay: "none" };
}

/// The material names, in corpus order. Used by the self-test and the store sheets so that
/// neither can drift from the switch above without going red.
function arm_material_names() {
    return ["bogiron", "iron", "steel", "watered", "blackened", "bronze", "brass", "silver",
            "gold", "meteoric", "gilt", "niello", "ash", "oak", "yew", "horn", "bone",
            "leather", "cord", "wire"];
}

/// ============================================================================================
/// DECAY - THE ONE PIECE OF COLOUR MATHS IN THIS PACKAGE THAT HAD TO BE GOT RIGHT
///
/// ⛔⛔ A TRANSFORM THAT MANUFACTURES ITS OWN COLOUR MUST PULL TOWARD A TARGET, NEVER SCALE WHAT
/// WAS THERE. This is the wing's Repast law, and rust is the single clearest case of it there is:
///
///   - AS AN ADDITION it is wrong. `h + 26` is fine for iron (252 -> 278, a cool grey going
///     slightly violet, which is not rust either) and catastrophic for brass (88 -> 114, a
///     yellow going GREEN). Repast shipped exactly this and put four olive dishes on a sheet.
///   - AS A MULTIPLICATION it is worse. Steel's chroma is 0.006 because polished steel IS very
///     nearly colourless; no multiplier makes orange rust out of that, so a rusting blade would
///     run silver -> GREY and never reach a colour at all.
///
/// So every decay names a TARGET (L, C, h) and a strength, and the material travels toward it.
/// Steel at full rust arrives at rust's colour because rust's colour is where it is going, not
/// because its own numbers were nudged.
///
/// ⭐ AND `gold` DECAYS TO "none", WHICH IS THE NEGATIVE CONTROL. Gold does not corrode - that is
/// most of why it is on a temple sword - so at any decay strength its ramp must be UNCHANGED.
/// A scale-based model cannot express that; a pull-based one gets it for free, and the suite
/// asserts it, so the day someone "simplifies" this back into a multiplier it goes red.
/// ============================================================================================

/// Where a material ends up if it is never cleaned. See the header for why this is a target and
/// not a displacement.
function arm_decay_target(_decay) {
    switch (_decay) {
        //                        L      C      hue    how hard it pulls
        case "rust":      return { L: 0.335, C: 0.098, h:  44, k: 0.92 }; // iron oxide, orange-brown
        case "verdigris": return { L: 0.520, C: 0.070, h: 168, k: 0.80 }; // copper carbonate, blue-green
        case "tarnish":   return { L: 0.300, C: 0.022, h:  72, k: 0.85 }; // silver sulphide, warm near-black
        case "weather":   return { L: 0.585, C: 0.010, h:  92, k: 0.78 }; // silvered, grain-raised timber
        case "stain":     return { L: 0.545, C: 0.050, h:  62, k: 0.70 }; // handled bone, sweat and grease
        case "darken":    return { L: 0.215, C: 0.036, h:  40, k: 0.80 }; // leather blackened by wear
        case "soil":      return { L: 0.395, C: 0.026, h:  70, k: 0.75 }; // grease and dirt in fibre
    }
    return undefined; // "none" - and every caller must handle it, which is the point.
}

/// ⛔ HUE IS AN ANGLE AND MUST BE INTERPOLATED THE SHORT WAY ROUND. This is a new face of the
/// Repast browning bug rather than a repeat of it, and it is worse.
///
/// Steel sits at hue 250 and rust at hue 44. A straight lerp travels 250 -> 150 -> 44, i.e. it
/// takes a rusting blade THROUGH GREEN, and at half decay - which is most of the corpus - a
/// weathered sword is the colour of pond water. Going the short way round is 250 -> 300 -> 360/0
/// -> 44, which passes through violet and red and looks like what it is.
///
/// ⚠️ The tell that this was needed was NOT a failed assertion. It was working out, before
/// writing the ramp, that the two hues in question are 206 degrees apart, which is more than
/// half a circle - so this is a case where thinking about the number first was cheaper than
/// baking a sheet and looking at it. Both instruments are needed; this one is faster.
function arm_hue_lerp(_h0, _h1, _t) {
    var _d = _h1 - _h0;
    while (_d > 180) _d -= 360;
    while (_d < -180) _d += 360;
    var _h = _h0 + _d * _t;
    while (_h < 0) _h += 360;
    while (_h >= 360) _h -= 360;
    return _h;
}

/// A material's spec after _decay units of neglect (0..1). Returns the same shape as
/// arm_material_spec so everything downstream is unchanged.
///
/// Decay also COMPRESSES the span, and that third term is the one a naive implementation misses:
/// a corroded surface is not merely a differently-coloured surface, it is one whose lit and
/// shadowed faces have moved closer together, because it has stopped being smooth enough to catch
/// the lamp. A rust-orange blade with a mirror highlight on it reads as wet plastic.
function arm_material_decayed(_mat, _decay) {
    var _s = arm_material_spec(_mat);
    var _t = clamp(_decay, 0, 1);
    var _tg = arm_decay_target(_s.decay);
    if (is_undefined(_tg) || _t <= 0) return _s;

    var _k = _t * _tg.k;

    // ⛔⛔ HUE IS INTERPOLATED BY CHROMA WEIGHT, NOT BY _k. MEASURED 2026-08-30 by baking the
    // history sheet and looking at it: a neglected iron sword rusted through LILAC and came out
    // MAGENTA at every middle step. Six of twelve swords on the product's central sheet.
    //
    // The short-way-round fix above is correct and was not enough. Iron sits at hue 252 and rust at
    // 44, which is 208 degrees apart, so the short way is 252 -> 300 -> 360 -> 44: it avoids the
    // green this file's previous comment worried about and drives straight through magenta instead.
    //
    // ⭐ THE REAL ERROR IS DEEPER AND IT IS WORTH STATING: INTERPOLATING THE HUE OF A COLOUR THAT
    // HAS NO CHROMA IS MEANINGLESS. Steel's chroma is 0.006. It does not HAVE a hue in any sense a
    // viewer can see; the 250 in its spec is a direction the ramp leans, not a colour. Sweeping
    // from it to rust's 44 treats a number nobody can see as if it were a starting appearance, and
    // every intermediate hue it visits IS visible because the chroma is climbing at the same time.
    //
    // Mixing two pigments, the resulting hue is dominated by whichever brings more chroma. So the
    // hue weight is the target's CHROMA CONTRIBUTION, not the decay fraction: a near-colourless
    // metal adopts rust's hue almost immediately and simply gets more of it, while bronze - which
    // genuinely is a colour - blends properly with verdigris because both terms are real.
    var _cs = _s.C * (1 - _k);
    var _ct = _tg.C * _k;
    var _hw = (_cs + _ct > 0.00001) ? (_ct / (_cs + _ct)) : _k;

    return {
        L: lerp(_s.L, _tg.L, _k),
        C: lerp(_s.C, _tg.C, _k),
        h: arm_hue_lerp(_s.h, _tg.h, _hw),
        // Corrosion eats gloss faster than it changes colour, which is why the coefficient here
        // is larger than the ones above.
        span: _s.span * (1 - 0.62 * _t),
        decay: _s.decay,
    };
}

/// ============================================================================================
/// THE RAMP
/// ============================================================================================

/// Five stops for one material at one decay level.
///
/// ⛔ THE RAMP SLIDES TO FIT. IT IS NEVER CLAMPED AT ITS ENDS. The wing paid for this on Hearth's
/// limewash, whose top two stops both landed above the ceiling, were clamped to the same value,
/// and produced a bevel whose two brightest walls were IDENTICAL - which reads as a flat fill
/// with a line round it, not as a dome. Silver here is L 0.780 with a span of 0.50, so its top
/// stop wants 1.030 and the same collapse is one line of clamping away.
///
/// The only legitimate compression is when the span genuinely does not fit between the floor and
/// the ceiling at all; then it is scaled, which keeps every adjacent gap equal and non-zero
/// rather than flattening two of them to nothing.
function arm_material_ramp(_mat, _decay, _hue_shift) {
    var _s = arm_material_decayed(_mat, _decay);
    var _hs = is_undefined(_hue_shift) ? 0 : _hue_shift;

    var _floor = 0.055, _ceil = 0.975;
    var _span = min(_s.span, _ceil - _floor);
    var _lo = _s.L - _span * 0.5;
    var _hi = _s.L + _span * 0.5;
    if (_hi > _ceil) { _lo -= (_hi - _ceil); _hi = _ceil; }
    if (_lo < _floor) { _hi += (_floor - _lo); _lo = _floor; }
    // After both slides _hi can only exceed the ceiling if the span did not fit, which the min
    // above has already ruled out. Belt and braces, and cheap.
    _hi = min(_hi, _ceil);

    var _out = array_create(ARM_RAMP_N);
    for (var _i = 0; _i < ARM_RAMP_N; _i++) {
        var _u = _i / (ARM_RAMP_N - 1);
        var _Li = _lo + (_hi - _lo) * _u;
        // Chroma falls in the shadows, as it does in life: the dark face of a brass pommel is
        // browner than its lit face, never a more saturated yellow.
        var _Ci = _s.C * (0.82 + 0.36 * _u);
        _out[_i] = arm_oklch(_Li, max(0, _Ci), _s.h + _hs);
    }
    return _out;
}

/// The role map that points arm_relief's m0..m4 at a named ramp in the palette.
///
/// Returned as a fresh struct every call rather than cached, because arm_map_roles reads it once
/// and a shared mutable map is the kind of thing that works until two weapons are built in the
/// same frame.
function arm_material_map(_prefix) {
    return {
        m0: _prefix + "0", m1: _prefix + "1", m2: _prefix + "2",
        m3: _prefix + "3", m4: _prefix + "4",
    };
}

/// Write one material's five stops into a palette struct under a prefix.
function arm_material_into(_pal, _prefix, _mat, _decay, _hue_shift) {
    var _r = arm_material_ramp(_mat, _decay, _hue_shift);
    for (var _i = 0; _i < ARM_RAMP_N; _i++) {
        variable_struct_set(_pal, _prefix + string(_i), _r[_i]);
    }
    return _pal;
}

/// ⛔ THE THING YOU WRITE ON A SURFACE IS NOT THE SURFACE'S DARKEST STOP.
///
/// The wing's Lexicon law, and it bites harder here than anywhere it has bitten before, because
/// this corpus contains BONE at L 0.820 and BLACKENED STEEL at L 0.190 and marks both. A maker's
/// stamp set in m0 on bone is "merely less pale" and vanishes; the same stamp in m0 on blackened
/// steel is invisible for the opposite reason. An ink is defined RELATIVE to its own ground and
/// goes the other way from it, with an asserted floor on the distance.
function arm_material_ink(_mat, _decay) {
    var _s = arm_material_decayed(_mat, _decay);
    // Go down from a light ground and up from a dark one, always by at least this much.
    var _sep = 0.34;
    var _L = (_s.L > 0.5) ? max(0.045, _s.L - _sep) : min(0.965, _s.L + _sep);
    return arm_oklch(_L, _s.C * 0.55, _s.h);
}

/// How far a material's ink sits from its own mid stop, in Oklab lightness. Exists so the suite
/// can assert the separation instead of trusting the arithmetic above, and so a future material
/// added at an awkward lightness fires BY NAME.
function arm_material_ink_sep(_mat, _decay) {
    var _s = arm_material_decayed(_mat, _decay);
    var _L = (_s.L > 0.5) ? max(0.045, _s.L - 0.34) : min(0.965, _s.L + 0.34);
    return abs(_L - _s.L);
}

/// ============================================================================================
/// WHAT A WEAPON IS MADE OF, BY WHO MADE IT
///
/// ⚠️ THIS IS A WEALTH AND ORIGIN TELL AND IT IS SUPPOSED TO BE READABLE WITHOUT A CAPTION. A
/// militia weapon is bog iron on an unseasoned ash pole because that is what a village can make;
/// a temple weapon is watered steel with silver and gold on it because somebody was paid for a
/// year. Nothing in the corpus writes the word "poor" on a picture.
/// ============================================================================================

/// The blade or head metal for a weapon of this quality (0..1).
function arm_edge_metal_for(_quality, _rng) {
    if (_quality < 0.22) return "bogiron";
    if (_quality < 0.46) return "iron";
    if (_quality < 0.72) return "steel";
    // At the top the choice is a STYLE and not a further upgrade, which is why it forks rather
    // than continuing to climb: watered steel and blackened steel are both expensive and they
    // say different things about the owner.
    return (arm_rng_next(_rng) < 0.62) ? "watered" : "blackened";
}

/// The furniture metal - guard, pommel, ferrules, rivets.
function arm_fitting_metal_for(_quality, _rng) {
    if (_quality < 0.20) return "iron";
    if (_quality < 0.42) return (arm_rng_next(_rng) < 0.5) ? "iron" : "bronze";
    if (_quality < 0.68) return "bronze";
    if (_quality < 0.86) return "brass";
    return (arm_rng_next(_rng) < 0.5) ? "silver" : "gilt";
}

/// The haft or grip core.
function arm_haft_wood_for(_quality, _rng) {
    if (_quality < 0.30) return "oak";
    if (_quality < 0.70) return "ash";
    return (arm_rng_next(_rng) < 0.6) ? "ash" : "yew";
}

/// What is wrapped round the grip. Cord is what you can do yourself; wire is what a cutler does.
function arm_grip_cover_for(_quality, _rng) {
    if (_quality < 0.26) return "cord";
    if (_quality < 0.58) return "leather";
    if (_quality < 0.80) return (arm_rng_next(_rng) < 0.5) ? "leather" : "horn";
    return "wire";
}
