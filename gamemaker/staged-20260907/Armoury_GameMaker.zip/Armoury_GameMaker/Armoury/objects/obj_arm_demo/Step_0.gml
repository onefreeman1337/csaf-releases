/// @description Step

// The demo's whole control surface. Deliberately keyboard-only and deliberately tiny: a buyer
// opening this project should be able to read the entire interaction in one screen and then go
// and read arm_forge, which is the file that matters.

var _forms = arm_form_names();
var _provs = arm_provenance_names();
var _rebuild = false;

if (keyboard_check_pressed(vk_right)) { form_i = (form_i + 1) % array_length(_forms); _rebuild = true; }
if (keyboard_check_pressed(vk_left))  { form_i = (form_i + array_length(_forms) - 1) % array_length(_forms); _rebuild = true; }
if (keyboard_check_pressed(vk_up))    { prov_i = (prov_i + 1) % array_length(_provs); _rebuild = true; }
if (keyboard_check_pressed(vk_down))  { prov_i = (prov_i + array_length(_provs) - 1) % array_length(_provs); _rebuild = true; }
if (keyboard_check_pressed(vk_space)) { seed = irandom(100000); _rebuild = true; }

// R resets the weapon to the day it was made, which is the only way to SEE what time did to it.
if (keyboard_check_pressed(ord("R"))) { fights = 0; years = 0; _rebuild = true; }

// C toggles whether this owner looks after it. Watch the same weapon age both ways: cared for it
// goes NARROW and clean, neglected it goes notched and red. That is the coupling arm_history's
// header describes, and it is the single best thing to look at in this room.
if (keyboard_check_pressed(ord("C"))) { care = (care > 0.5) ? 0.05 : 0.95; _rebuild = true; }
if (keyboard_check_pressed(ord("A"))) auto = !auto;

if (_rebuild) {
    weapon = arm_forge(_forms[form_i], _provs[prov_i], seed);
    if (fights > 0 || years > 0) weapon = arm_use(weapon, fights, years, care);
}

// F puts the weapon through ten more fights and a year. Held down, it is the product's whole
// argument running in front of you.
if (keyboard_check_pressed(ord("F")) || (auto && (tick mod 24) == 0 && tick > 0)) {
    fights += 10;
    years += 1;
    weapon = arm_use(weapon, 10, 1, care);
}
tick += 1;
