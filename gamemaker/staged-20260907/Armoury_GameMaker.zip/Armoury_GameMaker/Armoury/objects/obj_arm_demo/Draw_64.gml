/// @description Draw GUI

// ⭐ THE DEMO ROOM IS THE ONE PLACE THE PRODUCT'S CLAIM CAN BE WATCHED HAPPENING. Everything on
// this screen is drawn by the same four public calls a buyer would write, and there is no code
// here that is not code a buyer could copy out.

var _W = display_get_gui_width();
var _H = display_get_gui_height();
var _pal = arm_forge_palette(weapon);

// A dark ground, so metal reads. Drawn as a ramp rather than a flat fill because a flat charcoal
// rectangle makes every weapon on it look like a cut-out.
arm_render_vgrad(0, 0, _W, _H, make_colour_rgb(26, 27, 31), make_colour_rgb(14, 14, 17));

// -- the weapon, large -------------------------------------------------------------------------
// Drawn by height in pixels, which is the call a buyer makes. The butt sits on a fixed line so
// that cycling through 37 forms of wildly different lengths does not make the weapon jump.
var _bx = _W * 0.30;
var _by = _H - 110;
// ⭐ ONE SCALE FOR THE WHOLE CORPUS, which is why this uses arm_draw_at_scale and not arm_draw. A
// dagger is SUPPOSED to be small here. Cycling through 37 forms at a common scale is the fastest
// way to see that the corpus is proportioned rather than fitted, and a demo that stretched every
// weapon to the same height would be hiding the thing worth showing.
//
// The longest weapon in the corpus spans exactly 1.0 unit (see ARM_METRE), so the available height
// IS the pixels-per-unit that just fits it.
arm_draw_at_scale(weapon, _bx, _by, _H - 200);

// -- the same weapon in inventory cells ---------------------------------------------------------
// ⭐ THREE SIZES, AND THE SMALLEST IS THE HONEST ONE. The wing's Lexicon law: a proof plate must
// not name a size the image is not drawn at, and the buyer's real question is whether the thing is
// still readable when it is TINY. So 64, 48 and 32 are the real numbers, drawn at those numbers.
var _cx = _W - 250;
var _cy = 120;
var _sizes = [64, 48, 32];
for (var _i = 0; _i < 3; _i++) {
    var _s = _sizes[_i];
    var _x = _cx + _i * 78;
    arm_render_scrim(_x - 36, _cy - 36, 72, 72, make_colour_rgb(38, 39, 45), 1.0);
    arm_draw_icon(weapon, _x, _cy, _s);
    arm_text_line(string(_s) + " px", _x - 34, _cy + 42, 68, 13,
                  make_colour_rgb(140, 142, 150), false);
}

// -- readouts ------------------------------------------------------------------------------------
var _tx = 34;
arm_text_fit(arm_name(weapon), _tx, 34, _W - 68, 30, make_colour_rgb(10, 10, 12), _pal.line);
arm_text_body(arm_describe(weapon), _tx, 76, _W - 380, 15, make_colour_rgb(176, 178, 186));
arm_text_line(arm_stat_line(weapon), _tx, 132, _W - 380, 15,
              make_colour_rgb(150, 178, 200), false);

var _h = weapon.history;
arm_text_line("class " + _h.class
            + "   age " + string(floor(_h.age))
            + "   fights " + string(fights)
            + "   care " + string(round(care * 100)) + "%",
              _tx, 156, _W - 380, 14, make_colour_rgb(130, 132, 140), false);

// -- controls -------------------------------------------------------------------------------------
var _keys = "LEFT/RIGHT form    UP/DOWN provenance    SPACE reseed    F +10 fights"
          + "    C toggle care    R reset    A auto";
arm_text_line(_keys, _tx, _H - 34, _W - 68, 14, make_colour_rgb(120, 122, 130), false);
