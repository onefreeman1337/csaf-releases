/// @description Create

// ⛔ THE FIRST LINE OF ANY HEADLESS ENTRY POINT, AND IT IS NOT OPTIONAL.
// A GML runtime error opens a MODAL DIALOG. Headless, nothing dismisses it and the process never
// exits - a build robot then reports a 180-second timeout instead of a defect. Installing a
// handler that records the stage number and ends the game turns an opaque hang into a named line
// in a result file. This wing measured that exact conversion on a previous product: an opaque
// 180 s hang became "CRASH at stage 5: Variable Index [25] out of range [25]", a real bug.
//
// ⛔ AND IT RECORDS THE STACKTRACE, NOT JUST THE MESSAGE. A stage is a whole block calling
// hundreds of functions, so the message alone sends you guessing through the call graph. GML's
// exception struct carries .stacktrace, which names the function AND the line, and writing it
// costs one string.
//
// ⛔ THIS IS THE ONLY exception_unhandled_handler IN THE PACKAGE. Whichever is installed last
// silently wins, so two handlers is a coin toss over how much you learn from a crash.
global.arm_stage = -1;
exception_unhandled_handler(function(_ex) {
    var _st = "";
    try {
        var _tr = _ex.stacktrace;
        for (var _i = 0; _i < array_length(_tr); _i++) {
            if (_i > 0) _st += " <- ";
            _st += string(_tr[_i]);
        }
    } catch (_e) { _st = "(no stacktrace)"; }
    var _f = file_text_open_write("arm_crash.json");
    file_text_write_string(_f, "{\"stage\":" + string(global.arm_stage)
        + ",\"message\":\"" + string_replace_all(string(_ex.message), "\"", "'") + "\""
        + ",\"where\":\"" + string_replace_all(_st, "\"", "'") + "\"}");
    file_text_close(_f);
    game_end(1);
});

// ⛔ EVERY VARIABLE A LATER EVENT READS IS DECLARED ABOVE THE EARLY EXITS. The headless branches
// below leave Create part way through, and GameMaker fires Clean Up at game end regardless - a
// sibling product in this wing threw "variable not set before reading it" AFTER a fully green
// self-test, and a crash after the work is done still fails the run and still hides the result.
weapon = undefined;
form_i = 6;
prov_i = 1;
fights = 0;
years = 0;
care = 0.5;
auto = true;
tick = 0;

var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i + 1) + " ";

// -- headless modes: run, write the result file, exit -----------------------------------------
if (string_pos("-selftest", _args) > 0) {
    arm_selftest_write(arm_selftest_run());
    game_end(0);
    exit;
}
if (string_pos("-bake", _args) > 0) {
    arm_bake_run();
    game_end(0);
    exit;
}
if (string_pos("-frames", _args) > 0) {
    arm_frames_run();
    game_end(0);
    exit;
}

// -- the interactive demo ---------------------------------------------------------------------
// ⛔ A RUNNABLE DEMO ROOM IS MANDATORY IN THIS WING. It is the buyer's quickstart, the source of
// the store GIF, and the only real smoke test GML permits - all three at once. A buyer who cannot
// press Play cannot evaluate the product.
//
// ⭐ AND THIS ONE DEMONSTRATES THE THING THAT IS ACTUALLY FOR SALE. A demo that showed forty
// weapons in a grid would be a demo of a sprite sheet. This one shows ONE weapon and lets you run
// time forward over it, because the product's claim is that a weapon changes, and a claim you
// cannot watch happen is a claim nobody believes.
randomize();
seed = irandom(100000);
weapon = arm_forge(arm_form_names()[form_i], arm_provenance_names()[prov_i], seed);
