/// @description Clean Up

// ⛔ THIS EVENT IS DELIBERATELY EMPTY, AND THE EMPTINESS IS THE POINT.
//
// A weapon is PLAIN DATA. arm_forge returns a struct of numbers, strings and arrays; nothing in
// this package allocates a sprite, a surface, a buffer or a data structure that has to be freed,
// so there is nothing here to free. A buyer can hold ten thousand weapons and drop them on the
// floor, and GameMaker's garbage collector is the entire cleanup story.
//
// ⚠️ THE ONE EXCEPTION IS OPT-IN AND IT IS THE CALLER'S. arm_render_to_sprite hands back a sprite,
// and whoever asks for one owns it. Nothing in this package calls it, and this demo does not.
//
// The donor object this was cloned from cached a sprite per component and had to free them here.
// Leaving that call in place would have been a call to a function that does not exist in this
// package - which the offline symbol resolver would have caught, but only because somebody ran it.
//
// It is written out rather than deleted because Clean Up ALWAYS runs, including after the headless
// -selftest and -bake modes exit part way down Create. A sibling product in this wing reported a
// crash AFTER a fully green suite because this event read a variable those early exits had skipped,
// and the crash was attributed to the last stage the SUITE had reached - i.e. blamed on code that
// had already finished and passed. An event that is empty on purpose cannot do that; an event
// somebody adds a line to later can, so the warning lives here where they will be standing.
