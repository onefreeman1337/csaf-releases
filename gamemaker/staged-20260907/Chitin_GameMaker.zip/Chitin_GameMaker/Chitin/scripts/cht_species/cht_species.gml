/// CHITIN - cht_species. THE CORPUS. 48 ANIMALS, COMPOSED FROM NUMBERS.
///
/// ⭐ THIS FILE IS THE MOAT AND IT IS WORTH SAYING WHY OUT LOUD.
///
/// The logic in this package is not hard. A competent developer with a language model can write a
/// half-width function and a bevel in an afternoon. What does not come cheaply is FORTY EIGHT
/// animals that are each recognisably themselves AND recognisably part of one drawing - a stag
/// beetle that is unmistakably a stag beetle beside a ladybird that is unmistakably a ladybird,
/// both drawn by the same twelve functions, neither of them a repaint of the other.
///
/// Every row below is a hypothesis about what makes one insect look like itself, and each is
/// falsifiable by opening the contact sheet: if two rows produce the same picture, one of them is
/// wrong. That is what cht_selftest's pairwise sweep is for.
///
/// -- WHAT A ROW IS -------------------------------------------------------------------------
/// plan     which body plan (cht_body). The silhouette class.
/// cut      which cuticle (cht_chroma). The colour AND the surface: gloss, grain, iridescence.
/// hk pk ak multipliers on the head, thorax and abdomen half-widths
/// lk bk    multipliers on body length and on how pinched the waist is
/// scu n    the elytral sculpture program and its count
/// ant al   antenna form, and its length as a fraction of body length
/// leg      leg form
/// mnd mx   mandible length in unit-box units (0 for none) and how far the tips cross
/// eye      compound eye radius in unit-box units
/// pat pn   the patterning program and its count (cht_pattern)
///
/// ⛔ THE NUMBERS ARE NOT DECORATION AND THEY ARE NOT INTERCHANGEABLE. A ladybird is round because
/// ak is 1.35 and lk is 0.72; a click beetle is a splinter because ak is 0.80 and lk is 1.22. Two
/// species that differ only in colour are the failure this corpus exists to avoid, and the sweep
/// over all 1,128 pairs is what proves they do not - the eye finds the pair it happens to land on,
/// and a measured sweep finds the pair that is actually worst.
///
/// ⚠️ AND FOR A LOOKALIKE PAIR, EVERYTHING THAT IS NOT THE TELL MUST BE AUTHORED IDENTICAL. The
/// two ladybirds below share every body number to the digit and differ only in their pattern,
/// because that IS the difference between them. Carried in from a product where faithfully-copied
/// proportion noise in the thousandths beat the tell it was supposed to be showing.
/// ============================================================================================

/// A species row. Constructed through a function rather than written as 48 struct literals so a
/// field added later cannot be forgotten in row 37.
function cht_sp(_plan, _cut, _hk, _pk, _ak, _lk, _bk, _scu, _scun,
                _ant, _al, _leg, _mnd, _mx, _eye, _pat, _patn) {
    return { plan: _plan, cut: _cut, hk: _hk, pk: _pk, ak: _ak, lk: _lk, bk: _bk,
             scu: _scu, scun: _scun, ant: _ant, al: _al, leg: _leg,
             mnd: _mnd, mx: _mx, eye: _eye, pat: _pat, patn: _patn };
}

/// How many species the corpus holds. Derived from the ROSTER in cht_corpus, never typed here:
/// two declarations of one number is the defect this studio keeps paying for, and the roster is
/// the one a buyer reads.
function cht_species_n() {
    return array_length(cht_species_names());
}

/// A species index a buyer may legitimately hold: a whole number inside the corpus.
///
/// ⚠️ THE BOUND COMES FROM cht_species_n(), NOT FROM A TYPED NUMBER, for the reason stated three
/// lines above. ⛔ AND THAT RULE IS ALREADY BROKEN ONE FUNCTION BELOW: cht_species_spec opens with
/// `clamp(_i, 0, 47)`, a hard-coded 47 sitting directly under a comment explaining why the count is
/// derived. They agree today because the roster holds 48. They are still two declarations of one
/// number, and if the roster ever grows, cht_species_n() will report the new count while
/// cht_species_spec silently keeps returning the 48th species for every index past it - a wrong
/// animal, not an error. Recorded rather than changed, because altering that clamp changes what the
/// product returns for out-of-range input and that deserves its own measured pass.
function cht_is_species(_v) {
    return cht_is_num(_v) && _v >= 0 && _v < cht_species_n();
}

/// The corpus.
function cht_species_spec(_i) {
    switch (clamp(_i, 0, 47)) {
        // -- beetles, elytra closed ---------------------------------------------------------
        //             plan cut   hk    pk    ak    lk    bk   scu  n  ant al   leg mnd   mx   eye  pat n
        case  0: return cht_sp(CHT_PLAN_ELYTRA,  1, 1.42, 1.06, 0.94, 1.18, 1.05,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_GENICULATE, 0.30, CHT_LEG_CURSORIAL,
                    0.190, 0.34, 0.030, CHT_PAT_PLAIN,    0);   // stag beetle
        case  1: return cht_sp(CHT_PLAN_ELYTRA,  1, 1.04, 1.30, 1.16, 1.02, 1.10,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_LAMELLATE,  0.22, CHT_LEG_FOSSORIAL,
                    0.062, 0.10, 0.024, CHT_PAT_PLAIN,    0);   // rhinoceros beetle
        case  2: return cht_sp(CHT_PLAN_ELYTRA, 11, 0.94, 1.02, 1.14, 1.12, 0.78,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_FILIFORM,   0.26, CHT_LEG_NATATORIAL,
                    0.052, 0.16, 0.026, CHT_PAT_PLAIN,    0);   // great diving beetle
        case  3: return cht_sp(CHT_PLAN_ELYTRA, 10, 0.98, 1.14, 1.10, 0.94, 1.00,
                    CHT_SCULPT_GRANULATE, 6, CHT_ANT_LAMELLATE,  0.20, CHT_LEG_FOSSORIAL,
                    0.058, 0.12, 0.022, CHT_PAT_METALLIC, 0);   // dor beetle
        case  4: return cht_sp(CHT_PLAN_ELYTRA,  6, 1.10, 0.94, 0.98, 1.06, 1.14,
                    CHT_SCULPT_PUNCTATE,  5, CHT_ANT_FILIFORM,   0.34, CHT_LEG_CURSORIAL,
                    0.130, 0.30, 0.040, CHT_PAT_SPOTTED,  6);   // green tiger beetle
        case  5: return cht_sp(CHT_PLAN_ELYTRA, 10, 1.00, 1.04, 1.02, 1.10, 1.08,
                    CHT_SCULPT_STRIATE,   9, CHT_ANT_FILIFORM,   0.30, CHT_LEG_CURSORIAL,
                    0.088, 0.22, 0.028, CHT_PAT_METALLIC, 0);   // violet ground beetle
        case  6: return cht_sp(CHT_PLAN_ELYTRA,  1, 1.00, 1.10, 1.08, 1.00, 0.96,
                    CHT_SCULPT_PUNCTATE,  4, CHT_ANT_LAMELLATE,  0.24, CHT_LEG_CURSORIAL,
                    0.050, 0.10, 0.030, CHT_PAT_PLAIN,    0);   // cockchafer
        case  7: return cht_sp(CHT_PLAN_ELYTRA,  6, 0.92, 1.16, 1.22, 0.92, 0.94,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_LAMELLATE,  0.20, CHT_LEG_CURSORIAL,
                    0.044, 0.08, 0.024, CHT_PAT_METALLIC, 0);   // rose chafer
        case  8: return cht_sp(CHT_PLAN_ELYTRA,  7, 0.90, 1.00, 1.00, 1.14, 1.02,
                    CHT_SCULPT_COSTATE,   4, CHT_ANT_SERRATE,    0.26, CHT_LEG_CURSORIAL,
                    0.046, 0.10, 0.026, CHT_PAT_METALLIC, 0);   // jewel beetle
        case  9: return cht_sp(CHT_PLAN_ELYTRA, 14, 0.88, 0.96, 0.82, 1.22, 1.04,
                    CHT_SCULPT_STRIATE,   9, CHT_ANT_PECTINATE,  0.30, CHT_LEG_CURSORIAL,
                    0.040, 0.08, 0.022, CHT_PAT_PLAIN,    0);   // click beetle
        case 10: return cht_sp(CHT_PLAN_ELYTRA,  0, 0.94, 1.06, 1.32, 0.84, 0.90,
                    CHT_SCULPT_RUGOSE,    3, CHT_ANT_MONILIFORM, 0.24, CHT_LEG_CURSORIAL,
                    0.048, 0.12, 0.026, CHT_PAT_PLAIN,    0);   // bloody nosed beetle
        case 11: return cht_sp(CHT_PLAN_ELYTRA,  9, 0.92, 1.02, 0.96, 1.16, 1.06,
                    CHT_SCULPT_PUNCTATE,  6, CHT_ANT_FILIFORM,   1.45, CHT_LEG_CURSORIAL,
                    0.044, 0.10, 0.028, CHT_PAT_METALLIC, 0);   // musk beetle

        // -- beetles, marked and small ------------------------------------------------------
        // ⚠️ THE TWO LADYBIRDS SHARE EVERY BODY NUMBER TO THE DIGIT. See the header: for a
        // lookalike pair, everything that is not the tell must be authored identical, or the
        // proportion difference disagrees across the whole animal while the tell occupies one spot.
        case 12: return cht_sp(CHT_PLAN_ELYTRA,  3, 0.82, 1.10, 1.36, 0.72, 0.86,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_CLAVATE,    0.16, CHT_LEG_CURSORIAL,
                    0.026, 0.06, 0.020, CHT_PAT_SPOTTED,  7);   // seven spot ladybird
        case 13: return cht_sp(CHT_PLAN_ELYTRA,  3, 0.82, 1.10, 1.36, 0.72, 0.86,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_CLAVATE,    0.16, CHT_LEG_CURSORIAL,
                    0.026, 0.06, 0.020, CHT_PAT_EYESPOT,  9);   // eyed ladybird
        case 14: return cht_sp(CHT_PLAN_ELYTRA,  2, 0.88, 0.98, 0.94, 1.12, 1.12,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_FILIFORM,   0.70, CHT_LEG_CURSORIAL,
                    0.040, 0.10, 0.026, CHT_PAT_BANDED,   4);   // wasp beetle
        case 15: return cht_sp(CHT_PLAN_SOFT,   16, 0.90, 1.00, 0.96, 1.14, 0.94,
                    CHT_SCULPT_PUNCTATE,  3, CHT_ANT_FILIFORM,   0.52, CHT_LEG_CURSORIAL,
                    0.042, 0.12, 0.026, CHT_PAT_PLAIN,    0);   // soldier beetle
        case 16: return cht_sp(CHT_PLAN_LARVAL,  1, 0.92, 1.00, 0.98, 1.06, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_MONILIFORM, 0.12, CHT_LEG_CURSORIAL,
                    0.020, 0.04, 0.014, CHT_PAT_BANDED,   9);   // glow worm
        case 17: return cht_sp(CHT_PLAN_SOFT,    0, 0.96, 1.02, 0.86, 1.28, 0.98,
                    CHT_SCULPT_GRANULATE, 4, CHT_ANT_MONILIFORM, 0.26, CHT_LEG_CURSORIAL,
                    0.086, 0.26, 0.024, CHT_PAT_PLAIN,    0);   // devils coach horse
        case 18: return cht_sp(CHT_PLAN_ELYTRA, 14, 0.74, 1.06, 1.18, 0.94, 1.04,
                    CHT_SCULPT_PUNCTATE,  6, CHT_ANT_GENICULATE, 0.30, CHT_LEG_CURSORIAL,
                    0.096, 0.02, 0.018, CHT_PAT_MARBLED,  5);   // weevil
        case 19: return cht_sp(CHT_PLAN_ELYTRA, 12, 0.90, 1.00, 0.98, 1.18, 1.04,
                    CHT_SCULPT_STRIATE,   6, CHT_ANT_FILIFORM,   1.60, CHT_LEG_CURSORIAL,
                    0.044, 0.10, 0.030, CHT_PAT_PLAIN,    0);   // longhorn beetle
        case 20: return cht_sp(CHT_PLAN_ELYTRA,  0, 0.96, 1.08, 1.02, 1.00, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_CLAVATE,    0.22, CHT_LEG_FOSSORIAL,
                    0.058, 0.16, 0.024, CHT_PAT_BANDED,   3);   // burying beetle
        case 21: return cht_sp(CHT_PLAN_ELYTRA,  8, 0.86, 1.06, 1.26, 0.80, 0.84,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_CLAVATE,    0.14, CHT_LEG_NATATORIAL,
                    0.028, 0.06, 0.026, CHT_PAT_METALLIC, 0);   // whirligig beetle
        case 22: return cht_sp(CHT_PLAN_ELYTRA,  3, 0.92, 1.04, 1.10, 1.06, 0.96,
                    CHT_SCULPT_PUNCTATE,  5, CHT_ANT_PECTINATE,  0.34, CHT_LEG_CURSORIAL,
                    0.040, 0.10, 0.028, CHT_PAT_PLAIN,    0);   // cardinal beetle
        case 23: return cht_sp(CHT_PLAN_ELYTRA,  6, 0.84, 1.02, 1.20, 0.60, 0.88,
                    CHT_SCULPT_STRIATE,   5, CHT_ANT_FILIFORM,   0.30, CHT_LEG_SALTATORIAL,
                    0.020, 0.06, 0.020, CHT_PAT_METALLIC, 0);   // flea beetle

        // -- butterflies ---------------------------------------------------------------------
        // Every butterfly is CLAVATE. That single fact is the oldest field mark there is - it is
        // how a butterfly is told from a moth before anything else about it is looked at - so it
        // is authored, not varied, and cht_selftest asserts it across the whole group.
        case 24: return cht_sp(CHT_PLAN_SPREAD,  3, 1.00, 1.12, 1.00, 1.00, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_CLAVATE,    0.46, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.026, CHT_PAT_EYESPOT,  4);   // peacock
        case 25: return cht_sp(CHT_PLAN_SPREAD,  0, 1.00, 1.10, 0.98, 1.02, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_CLAVATE,    0.46, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.026, CHT_PAT_BANDED,   3);   // red admiral
        case 26: return cht_sp(CHT_PLAN_SPREAD, 16, 0.98, 1.08, 0.98, 1.00, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_CLAVATE,    0.44, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.026, CHT_PAT_MARBLED,  6);   // painted lady
        case 27: return cht_sp(CHT_PLAN_SPREAD, 16, 0.96, 1.06, 0.96, 0.94, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_CLAVATE,    0.44, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.024, CHT_PAT_SPOTTED,  8);   // small tortoiseshell
        case 28: return cht_sp(CHT_PLAN_SPREAD,  2, 0.96, 1.04, 0.98, 1.02, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_CLAVATE,    0.42, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.024, CHT_PAT_PLAIN,    0);   // brimstone
        case 29: return cht_sp(CHT_PLAN_SPREAD,  5, 0.94, 1.02, 0.96, 0.96, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_CLAVATE,    0.42, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.024, CHT_PAT_BANDED,   2);   // orange tip
        case 30: return cht_sp(CHT_PLAN_SPREAD,  8, 0.92, 1.00, 0.94, 0.86, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_CLAVATE,    0.40, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.022, CHT_PAT_METALLIC, 0);   // common blue
        case 31: return cht_sp(CHT_PLAN_SPREAD,  9, 0.92, 1.00, 0.94, 0.88, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_CLAVATE,    0.40, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.022, CHT_PAT_SPOTTED,  9);   // chalkhill blue
        case 32: return cht_sp(CHT_PLAN_SPREAD,  2, 1.02, 1.14, 1.02, 1.10, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_CLAVATE,    0.48, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.026, CHT_PAT_RETICULATE, 5); // swallowtail
        case 33: return cht_sp(CHT_PLAN_SPREAD, 10, 1.02, 1.14, 1.02, 1.08, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_CLAVATE,    0.48, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.026, CHT_PAT_METALLIC, 0);   // purple emperor
        case 34: return cht_sp(CHT_PLAN_SPREAD, 13, 1.00, 1.10, 1.00, 1.04, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_CLAVATE,    0.46, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.026, CHT_PAT_SPOTTED, 11);   // silver washed fritillary
        case 35: return cht_sp(CHT_PLAN_SPREAD,  5, 0.98, 1.08, 0.98, 1.00, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_CLAVATE,    0.44, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.024, CHT_PAT_RETICULATE, 7); // marbled white

        // -- moths ---------------------------------------------------------------------------
        // Never clavate, always a thicker thorax, and the hawk moths are the group where the
        // BODY is the identification rather than the wings - which is why their thorax and
        // abdomen multipliers are the widest in the corpus.
        case 36: return cht_sp(CHT_PLAN_FOLDED, 10, 1.00, 1.26, 1.14, 1.06, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_FILIFORM,   0.34, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.028, CHT_PAT_BANDED,   4);   // elephant hawk moth
        case 37: return cht_sp(CHT_PLAN_FOLDED, 14, 1.02, 1.30, 1.10, 1.08, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_PECTINATE,  0.32, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.028, CHT_PAT_MARBLED,  6);   // poplar hawk moth
        case 38: return cht_sp(CHT_PLAN_FOLDED,  1, 1.04, 1.34, 1.18, 1.12, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_FILIFORM,   0.30, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.030, CHT_PAT_BANDED,   7);   // death's head hawk moth
        case 39: return cht_sp(CHT_PLAN_FOLDED, 11, 0.98, 1.24, 1.06, 0.94, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_FILIFORM,   0.30, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.028, CHT_PAT_BANDED,   3);   // hummingbird hawk moth
        case 40: return cht_sp(CHT_PLAN_FOLDED,  3, 1.00, 1.22, 1.08, 1.00, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_PECTINATE,  0.34, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.026, CHT_PAT_MARBLED,  8);   // garden tiger
        case 41: return cht_sp(CHT_PLAN_FOLDED,  3, 0.96, 1.14, 1.00, 0.98, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_FILIFORM,   0.36, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.024, CHT_PAT_SPOTTED,  4);   // cinnabar
        case 42: return cht_sp(CHT_PLAN_FOLDED,  1, 1.02, 1.28, 1.10, 1.02, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_PLUMOSE,    0.40, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.028, CHT_PAT_EYESPOT,  4);   // emperor moth
        case 43: return cht_sp(CHT_PLAN_FOLDED, 11, 1.00, 1.24, 1.06, 1.04, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_PECTINATE,  0.32, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.026, CHT_PAT_MARBLED,  5);   // lime hawk moth
        case 44: return cht_sp(CHT_PLAN_FOLDED, 13, 0.96, 1.18, 1.02, 0.96, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_FILIFORM,   0.34, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.024, CHT_PAT_METALLIC, 0);   // burnished brass
        case 45: return cht_sp(CHT_PLAN_FOLDED, 16, 0.98, 1.20, 1.04, 1.00, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_FILIFORM,   0.34, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.026, CHT_PAT_MARBLED,  7);   // angle shades
        case 46: return cht_sp(CHT_PLAN_FOLDED,  4, 1.00, 1.22, 0.98, 1.10, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_FILIFORM,   0.30, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.026, CHT_PAT_BANDED,   2);   // buff tip
        default: return cht_sp(CHT_PLAN_FOLDED,  8, 0.94, 1.14, 1.00, 0.94, 1.00,
                    CHT_SCULPT_SMOOTH,    0, CHT_ANT_FILIFORM,   0.36, CHT_LEG_CURSORIAL,
                    0.000, 0.00, 0.024, CHT_PAT_SPOTTED,  6);   // six spot burnet
    }
}

/// ============================================================================================
/// COMPOSITION
/// ============================================================================================

/// The body spec for a species.
function cht_species_body(_sp) {
    return cht_body_of(_sp.plan, _sp.hk, _sp.pk, _sp.ak, _sp.lk, _sp.bk);
}

/// How many bands the shell is drawn in at a given drawn width.
///
/// ⛔ A RESOLUTION DECISION, NOT A QUALITY SETTING, AND IT HAS A FLOOR AT BOTH ENDS. Below about
/// 5 px per band the strips stop being a gradient and become stripes - which for an iridescent
/// species is the rainbow-decal failure arriving by a different route - so the count falls with the
/// drawn size and the shell degrades to a flat correctly-coloured animal rather than a striped one.
/// The ceiling is where more bands stop being visible and start being a frame-rate bill.
function cht_species_bands(_px) {
    if (_px <= 0) return 0;
    return clamp(floor(_px / 5), 0, 44);
}

/// The palette for one species at one viewing phase.
///
/// Writes the cuticle's five DISCRETE relief stops under "c" - used by every cut, wall and rim in
/// the package - and the CONTINUOUS shell bands under "sh". Both come out of the same cuticle spec
/// and the same colour function, which is what keeps a bevelled leg and a domed elytron looking
/// like the same animal.
function cht_species_palette(_i, _phase, _px) {
    /// ⛔ REFUSE TO A USABLE PALETTE, NOT TO undefined. Everything downstream resolves roles through
    /// cht_render_colour, whose fallback is `line`, so the minimum honest refusal is a struct that
    /// carries one - anything less just moves the crash into the renderer. A caller who mistypes the
    /// index gets an animal drawn in flat outline colour, which is visibly wrong and safe.
    if (!cht_is_species(_i) || !cht_is_num(_px) || _px <= 0) {
        return { line: cht_oklch(0.10, 0.010, 250) };
    }
    var _sp = cht_species_spec(_i);
    var _cut = cht_cuticle_spec(_sp.cut);
    var _pal = { line: cht_oklch(0.10, 0.010, 250) };
    cht_chroma_into(_pal, "c", _cut);
    variable_struct_set(_pal, "ink", cht_chroma_ink(_cut));

    // ⛔ ON A LEPIDOPTERAN THE BODY IS DARKER THAN THE WINGS, AND WITHOUT THAT THE ANIMAL IS ONE
    // FLAT COLOUR. MEASURED 2026-09-01 by opening big_24: the peacock rendered as a single shade of
    // red from antenna to wingtip, so the wings did not read as wings - they read as a silhouette
    // with lines on it. It is not an artistic preference: a butterfly's thorax and abdomen are
    // furred and unscaled and sit a real step below the scaled wing they carry, which is why a set
    // specimen has a dark spine down the middle of a bright shape.
    //
    // ⚠️ THE BODY IS DARKENED RATHER THAN THE WING LIGHTENED, and that is the safer half of the
    // choice: the wing carries the pattern, and every ocellus, band and spot in the package is
    // authored against the wing's own ramp. Moving the ground under 24 species' markings to fix a
    // contrast problem is how a shape change silently deletes a corpus of marks.
    var _bodyK = (_sp.plan == CHT_PLAN_SPREAD || _sp.plan == CHT_PLAN_FOLDED) ? 0.62 : 1.00;

    var _nb = cht_species_bands(_px);
    for (var _b = 0; _b < _nb; _b++) {
        var _u = -1 + 2 * ((_b + 0.5) / _nb);
        variable_struct_set(_pal, "sh" + string(_b),
            cht_chroma_ramp_at(_cut, cht_tube_k(_u) * _bodyK, _u, _phase));

        // ⛔ A WING GETS ITS OWN, MUCH SHALLOWER BANDS, AND HANDING IT THE BODY'S WAS A DEFECT I
        // WROTE THE WARNING AGAINST AND THEN COMMITTED ANYWAY. cht_wing_membrane's own header says
        // a wing is a nearly flat sheet and that the body's tube gradient makes it read as a rolled
        // tube of paper; the first wiring passed the "sh" bands straight through, and MEASURED by
        // opening the peacock preview, that is exactly what four glossy rolled tubes look like.
        //
        // ⭐ Writing the constraint down does not enforce it. The membrane could not tell which
        // palette it had been given, so nothing could have caught this but looking - which is the
        // argument for making a constraint STRUCTURAL (a separate role prefix) rather than
        // documentary.
        //
        // The range is deliberately narrow: a wing is lit almost edge-on across its chord, and its
        // only real tonal variation is that the trailing half sits slightly in the forewing's and
        // the body's shadow.
        variable_struct_set(_pal, "wg" + string(_b),
            cht_chroma_ramp_at(_cut, 0.60 - 0.16 * _u, _u, _phase));
    }
    return _pal;
}

/// The role map pointing cht_relief's m0..m4 at this species' cuticle ramp.
function cht_species_map() {
    return cht_chroma_map("c");
}

/// ONE ANIMAL, WHOLE, in the unit box.
///
/// _px is the width the animal will be drawn at, in pixels. It is not a scale - the geometry is
/// always unit-box - it is the LEVEL OF DETAIL input, and every count in the package that has a
/// resolution floor reads it: how many striae, how many leg pairs, how many shimmer bands.
///
/// ⭐ PAINTER'S ORDER IS LOAD-BEARING HERE AND NOT MERELY TIDY. Legs go UNDER the body because
/// they emerge from beneath it; the shimmer goes over the shell but under the sculpture, because
/// structural colour is IN the cuticle and a groove cut into that cuticle is deeper than the
/// colour; the eyes go last because nothing on an insect is in front of its eyes.
/// ⚠️ SPLIT IN TWO ON PURPOSE, AND THE SPLIT IS WHAT MAKES THE FIT TESTABLE. cht_species_parts
/// below returns the animal fitted into the unit box, which is what every caller wants and what
/// the contract promises. This one returns it UNFITTED - so the suite can measure how much the fit
/// actually had to do, which is the only assertion that can still go red once containment is true
/// by construction. It is also the honest answer for a buyer who wants the animal at its natural
/// proportions inside a rect they have sized themselves.
function cht_species_parts_raw(_i, _px, _phase) {
    var _sp = cht_species_spec(_i);
    var _cut = cht_cuticle_spec(_sp.cut);
    var _bd = cht_species_body(_sp);
    var _out = [];

    // 0. WINGS, under absolutely everything, for the plans that have them.
    //
    // ⛔ THE WINGS GO DOWN FIRST AND THE BODY OVER THEM, AND THAT IS ANATOMY. A Lepidopteran's
    // wings attach UNDER the thorax and their bases disappear beneath it. Drawn over the body they
    // cut the thorax in half and the animal reads as a body lying on top of two leaves.
    if (_sp.plan == CHT_PLAN_SPREAD || _sp.plan == CHT_PLAN_FOLDED
        || _sp.plan == CHT_PLAN_ELYTRA_OPEN) {
        var _shape = (_sp.plan == CHT_PLAN_FOLDED) ? CHT_WSHAPE_MOTH : CHT_WSHAPE_BUTTERFLY;
        // The swallowtail is the one species in the roster whose wing SHAPE is its name, so it is
        // read off the roster rather than added as a column nothing else would use.
        if (_i == 32) _shape = CHT_WSHAPE_TAILED;
        // A moth at rest holds its wings closer to the body than a set specimen displays them.
        var _wscale = (_sp.plan == CHT_PLAN_FOLDED) ? 0.86 : 1.00;
        for (var _s = -1; _s <= 1; _s += 2) {
            cht_append(_out, cht_wing_pair(_bd, _shape, _s, _wscale, _sp.pat, _sp.patn,
                                           _cut, _px, cht_species_bands(_px), "wg", _i));
        }
    }

    // 1. Legs, under everything.
    //
    // ⚠️ 0.50 AND 0.0105, NOT 0.62 AND 0.0085. MEASURED by looking at the first shaded preview: at
    // the longer, thinner setting the legs read as a SPIDER's - six wires reaching most of a body
    // length out from a compact shell. A beetle's legs are short relative to its body and visibly
    // jointed, and the wing's own resolution law says the same thing from the other direction: an
    // appendage too thin reads as a hair, and six hairs read as a smudge rather than as six legs.
    cht_append(_out, cht_legs_parts(_sp.leg, _bd, _bd.len * 0.50, 0.0105, _px));

    // 2. Antennae, also under the head - they emerge from beneath its front margin.
    var _al = _bd.len * _sp.al;
    // How far back a long antenna is swept. Derived from the species' own antenna length rather
    // than authored per row: an antenna shorter than about half a body length is carried forward by
    // every insect that has one, and past that they are all carried back. See cht_ant_stem.
    var _back = clamp((_sp.al - 0.55) / 1.10, 0, 0.72);
    for (var _s = -1; _s <= 1; _s += 2) {
        var _root = cht_body_socket(_bd, 0.055, _s, 0.55);
        cht_append(_out, cht_antenna_parts(_sp.ant, _root, _s, _al, 0.0068, _i, _back));
    }

    // 3. The body itself: one continuous mass, shaded as one tube from head to tail.
    //
    // ⭐ ONE TUBE ACROSS THE WHOLE ANIMAL, INCLUDING BOTH ELYTRA, AND THAT IS ANATOMY RATHER THAN
    // A SAVING. A beetle's two elytra together form ONE dome across its back; they are not two
    // separately curved shells that happen to be adjacent. Shading them independently puts a
    // bright highlight on the inner edge of the right elytron, which is a surface that faces away
    // from the lamp. The suture is a groove cut in the single dome, and it is drawn as one.
    cht_append(_out, cht_body_parts(_bd, 0.014, _px, cht_species_bands(_px), "sh"));

    // 5. The sutures that make the three regions read as regions of one shell.
    cht_append(_out, cht_body_suture(_bd, CHT_T_HEAD_END, 0.86, 0.0055));
    cht_append(_out, cht_body_suture(_bd, CHT_T_THORAX_END, 0.94, 0.0065));

    // 6. Elytra and their sculpture - only on the plans that have them.
    if (_sp.plan == CHT_PLAN_ELYTRA || _sp.plan == CHT_PLAN_SOFT) {
        cht_append(_out, cht_elytra_parts(_bd, CHT_T_THORAX_END, _sp.scu, _sp.scun, _cut, _px));
    }

    // 7. The pattern, written into the body's own coordinate space.
    //
    // ⛔ ONLY FOR THE PLANS WHOSE PATTERN IS ON THE BODY. A ladybird's spots are on its elytra,
    // which ARE its body outline, so the body is the right space for them. A butterfly's markings
    // are not on its body at all - drawing them there put a red admiral's bands across its abdomen,
    // which is a picture of an insect nobody has ever seen. For those species the pattern is
    // already drawn, in WING space, by cht_wing_pattern above.
    if (_sp.plan != CHT_PLAN_SPREAD && _sp.plan != CHT_PLAN_FOLDED) {
        cht_append(_out, cht_pattern_parts(_bd, _sp, _cut, _px));
    }

    // 8. Mandibles, the horn, and eyes, last, because nothing is in front of them.
    //
    // The rhinoceros beetle is the one species in the roster whose HORN is its name, so it is read
    // off the index here rather than added as a column forty-seven species would carry as a zero -
    // the same decision, for the same reason, as the swallowtail's wing shape above.
    if (_i == 1) cht_append(_out, cht_head_horn(_bd, 0.235, 0.0125));
    cht_append(_out, cht_head_mandibles(_bd, _sp.mnd, 0.0125, _sp.mx));
    cht_append(_out, cht_head_eyes(_bd, 0.105, _sp.eye, 0.42));

    return _out;
}

/// ONE ANIMAL, WHOLE, FITTED INTO THE UNIT BOX. This is the function to call.
///
/// See cht_fit_unit: 26 of these 48 species reach past the box, and the ones that do are the ones
/// whose antennae or legs are longer than their bodies - which is anatomy, not error. The margin
/// keeps the outermost stroke off the edge of the rect rather than exactly on it.
function cht_species_parts(_i, _px, _phase) {
    /// ⛔ AN EMPTY PART LIST IS THE HONEST REFUSAL HERE. The Readme's own draw line feeds this
    /// straight into cht_render_in_rect, which walks an array - so a caller who mistypes the index
    /// draws NOTHING and sees it immediately, rather than getting an engine message from four
    /// frames deeper that names none of their code. Guarding the width too: a negative or absurd
    /// _px reaches the resolution floors, which is where a bad number turns into a wrong picture
    /// rather than an error.
    if (!cht_is_species(_i) || !cht_is_num(_px) || _px <= 0) return [];
    return cht_fit_unit(cht_species_parts_raw(_i, _px, _phase), 0.485);
}
