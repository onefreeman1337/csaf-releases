/// CHITIN - cht_cabinet. THE DRAWER THE PLAYER FILLS, AND THE GAPS IN IT.
///
/// ============================================================================================
/// THE GAPS ARE THE PRODUCT
///
/// A collection screen that lists what you have is a receipt. A collection screen that DRAWS the
/// empty slots - a pin standing in an empty compartment with a blank label under it - is a reason
/// to go back out at dusk in high summer, and it is the same reason every cabinet of real
/// Lepidoptera in every museum has one obviously empty row that somebody spent thirty years failing
/// to fill.
///
/// So the empty slot is DRAWN here, from geometry, at the same size and in the same compartment as
/// a full one. That is a deliberate cost: a text list of missing species would have been four lines.
///
/// ⛔ PURE. No draw calls, no surfaces, no instance variables, no globals. The layout is arithmetic
/// and the ghost slot is a parts array like every other drawing in the package, so cht_bake renders
/// it through exactly the same path as a specimen and cht_selftest can measure both. GML has no
/// unit test outside the engine; keeping this half GPU-free is the only reason any of it can be
/// asserted at all.
///
/// ⚠️ AND THE CABINET IS A VALUE, NOT AN OBJECT. Every mutator returns a NEW cabinet rather than
/// editing the one it was given. GML arrays are references, so `_cab.best[_i] = _c` inside a
/// function would reach back through the caller's copy and through any save-state it had taken -
/// which is how an undo, a preview and a "what if I pin this one instead" screen all quietly break
/// at once.
/// ============================================================================================

/// The three states a specimen is drawn in. Index-parallel with cht_state_names().
#macro CHT_STATE_LIVE   0
#macro CHT_STATE_SPREAD 1
#macro CHT_STATE_PINNED 2
#macro CHT_STATE_N      3

/// Nothing pinned in this slot.
#macro CHT_COND_EMPTY -1

/// How a species is DISPLAYED once it is in the cabinet.
///
/// This is a real curatorial fact rather than a rendering convenience: Lepidoptera are SET - the
/// wings opened and held flat on a board until they dry - and beetles are simply pinned through the
/// right elytron with their legs arranged. A cabinet that displays a beetle with its wings spread
/// is a cabinet nobody who has seen one will believe.
function cht_display_state(_i) {
    var _sp = cht_species_spec(_i);
    if (_sp.plan == CHT_PLAN_SPREAD || _sp.plan == CHT_PLAN_FOLDED) return CHT_STATE_SPREAD;
    return CHT_STATE_PINNED;
}

/// ============================================================================================
/// THE DRAWERS
/// ============================================================================================

/// The cabinet is four drawers, and the ranges are the same four blocks the roster is authored in.
///
/// ⛔ THE BOUNDS ARE DERIVED FROM THE BODY PLANS, NOT TYPED. A drawer whose range is written as
/// `24, 35` is a second declaration of a fact that already lives in cht_species, and it goes on
/// lying the day a species is inserted. This walks the roster and cuts a drawer where the plan
/// group changes, so adding a butterfly moves the moth drawer by itself.
function cht_cabinet_drawers() {
    var _n = cht_species_n();
    var _out = [];
    var _from = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _last = (_i == _n - 1);
        var _next = _last ? -1 : cht_cabinet_group_of(_i + 1);
        if (_last || _next != cht_cabinet_group_of(_i)) {
            array_push(_out, {
                name: cht_cabinet_group_name(cht_cabinet_group_of(_i)),
                from: _from, to: _i, n: _i - _from + 1
            });
            _from = _i + 1;
        }
    }
    return _out;
}

/// Which group a species belongs to. Read off its body plan, which is what a curator sorts by.
function cht_cabinet_group_of(_i) {
    var _sp = cht_species_spec(_i);
    if (_sp.plan == CHT_PLAN_SPREAD) return 1;
    if (_sp.plan == CHT_PLAN_FOLDED) return 2;
    return 0;
}

function cht_cabinet_group_name(_g) {
    switch (_g) {
        case 1:  return "butterflies";
        case 2:  return "moths";
        default: return "beetles";
    }
}

/// ============================================================================================
/// THE CABINET ITSELF
/// ============================================================================================

/// An empty cabinet: one slot per species, every one CHT_COND_EMPTY.
function cht_cabinet_new() {
    var _n = cht_species_n();
    var _b = array_create(_n, CHT_COND_EMPTY);
    return { best: _b, taken: array_create(_n, 0), n: _n };
}

/// A copy. The one place the arrays are duplicated, so every mutator below is one line of honesty.
function cht_cabinet_copy(_cab) {
    var _b = array_create(_cab.n, CHT_COND_EMPTY);
    var _t = array_create(_cab.n, 0);
    array_copy(_b, 0, _cab.best, 0, _cab.n);
    array_copy(_t, 0, _cab.taken, 0, _cab.n);
    return { best: _b, taken: _t, n: _cab.n };
}

/// Pin a specimen. Returns a NEW cabinet.
///
/// ⛔ IT KEEPS THE BEST CONDITION, NEVER THE LATEST, and that is the whole reason to catch a species
/// twice. A cabinet that overwrites punishes the player for going back out, which is the opposite
/// of what a collection is for.
function cht_cabinet_pin(_cab, _i, _cond) {
    /// ⛔ THE RANGE CHECK BELOW WAS ALREADY HERE AND IT WAS NOT ENOUGH - this is exactly the shape
    /// gm-lode shipped: a guard that covers the BOUNDS of an index and not the KIND of the value,
    /// defeated by the input its own existence anticipates. `_i < 0` on undefined does not refuse,
    /// it throws, and `_cab.n` on a non-cabinet throws before the comparison is even reached.
    /// Returning the caller's own _cab is the documented no-op: the Readme says every mutator
    /// returns a NEW cabinet, and handing back the old one leaves their `cabinet = ...` assignment
    /// holding a valid, unchanged value.
    if (!cht_has(_cab, "n") || !cht_is_num(_i)) return _cab;
    if (!cht_is_num(_cond)) return _cab;
    if (_i < 0 || _i >= _cab.n) return _cab;
    var _n = cht_cabinet_copy(_cab);
    _n.taken[_i] = _n.taken[_i] + 1;
    if (_cond > _n.best[_i]) _n.best[_i] = _cond;
    return _n;
}

function cht_cabinet_has(_cab, _i) {
    if (_i < 0 || _i >= _cab.n) return false;
    return _cab.best[_i] > CHT_COND_EMPTY;
}

/// How many species are represented at all.
function cht_cabinet_count(_cab) {
    var _c = 0;
    for (var _i = 0; _i < _cab.n; _i++) if (_cab.best[_i] > CHT_COND_EMPTY) _c += 1;
    return _c;
}

/// Completion, 0..1, by species present.
function cht_cabinet_complete(_cab) {
    if (_cab.n <= 0) return 0;
    return cht_cabinet_count(_cab) / _cab.n;
}

/// THE SCORE, and it is weighted by how hard the animal was to get.
///
/// ⭐ A FLAT "one point per species" SCORE MAKES THE FLEA BEETLE AND THE PURPLE EMPEROR THE SAME
/// ACHIEVEMENT, and there is no defending that to anyone who has tried to catch either. The weight
/// is cht_field_rarity plus cht_catch_difficulty - both DERIVED from the field and behaviour data,
/// so a buyer who edits a flight period gets a score that moves with it and never a stale table.
///
/// ⛔ WHAT THE 0.55 FLOOR ACTUALLY BUYS, CORRECTED AGAINST THE ARITHMETIC. This comment used to
/// claim it made "a damaged rare specimen beat a perfect common one", and cht_selftest went RED on
/// exactly that sentence on its first run: a damaged purple emperor scores 192 and a perfect flea
/// beetle 294. THE CLAIM WAS WRONG AND THE MODEL IS RIGHT. The flea beetle is common and one of the
/// hardest animals here to get a hand near; the purple emperor is the rarest and, once found, not
/// especially difficult. cht_catch_difficulty's own header says those two axes are meant to come
/// apart - so a score in which rarity always dominated difficulty would be contradicting the design
/// one file over.
///
/// What the floor DOES buy is the property the collection actually needs, and it is asserted rather
/// than asserted-about: A NEW SPECIES IN ANY CONDITION IS ALWAYS WORTH MORE THAN UPGRADING ONE YOU
/// ALREADY HAVE. That is what keeps a player going out for the thing they have never seen instead
/// of farming the one on the nearest nettle, and it is true only while the floor is high relative
/// to the per-grade step. cht_selftest measures both extremes over the whole roster.
function cht_cabinet_score(_cab) {
    var _s = 0;
    for (var _i = 0; _i < _cab.n; _i++) {
        if (_cab.best[_i] <= CHT_COND_EMPTY) continue;
        var _w = 1.0 + 1.6 * cht_field_rarity(_i) + 1.2 * cht_catch_difficulty(_i);
        var _cm = 0.55 + 0.15 * _cab.best[_i];    // 0.55, 0.70, 0.85, 1.00
        _s += _w * _cm * 100;
    }
    return floor(_s);
}

/// The highest score this cabinet could ever reach: every species, perfect. The denominator a
/// progress bar needs, derived from the same expression as the score so the two cannot drift.
function cht_cabinet_score_max() {
    var _s = 0;
    for (var _i = 0; _i < cht_species_n(); _i++) {
        _s += (1.0 + 1.6 * cht_field_rarity(_i) + 1.2 * cht_catch_difficulty(_i)) * 1.0 * 100;
    }
    return floor(_s);
}

/// What is missing, as species indices. The list the "gaps" plate draws.
function cht_cabinet_gaps(_cab) {
    var _out = [];
    for (var _i = 0; _i < _cab.n; _i++) if (_cab.best[_i] <= CHT_COND_EMPTY) array_push(_out, _i);
    return _out;
}

/// What is missing that could be caught RIGHT NOW, commonest first. The single most useful screen
/// in a collection game and the one that most often does not exist.
///
/// ⚠️ RETURNS THE SAME [{i, p}, ...] ROWS AS cht_field_now - NOT bare indices. Read the species off
/// .i and the probability off .p. Its sibling cht_cabinet_gaps() above DOES return bare indices,
/// and the two sitting next to each other is a trap: a fresh-install test written against these
/// headers compared a struct to an integer, which is always false in GML and throws nothing, so the
/// mistake surfaced as a wrong answer rather than an error. Same for cht_cabinet_upgrades_now.
function cht_cabinet_gaps_now(_cab, _hab, _sea, _day, _wx) {
    /// The four field indices are covered by cht_field_now's guard. The CABINET is not, and
    /// cht_cabinet_has reads it inside the loop - so a bad cabinet crashes per row rather than
    /// once, which is the harder version to read in a log.
    if (!cht_has(_cab, "n")) return [];
    var _l = cht_field_now(_hab, _sea, _day, _wx);
    var _out = [];
    for (var _k = 0; _k < array_length(_l); _k++) {
        if (!cht_cabinet_has(_cab, _l[_k].i)) array_push(_out, _l[_k]);
    }
    return _out;
}

/// Which species could be UPGRADED right now - present, but not in perfect condition. The reason
/// to keep hunting a common species after the slot is filled.
///
/// ⚠️ Same shape as cht_cabinet_gaps_now: [{i, p}, ...] rows, not bare indices.
function cht_cabinet_upgrades_now(_cab, _hab, _sea, _day, _wx) {
    var _l = cht_field_now(_hab, _sea, _day, _wx);
    var _out = [];
    for (var _k = 0; _k < array_length(_l); _k++) {
        var _i = _l[_k].i;
        if (cht_cabinet_has(_cab, _i) && _cab.best[_i] < 3) array_push(_out, _l[_k]);
    }
    return _out;
}

/// ============================================================================================
/// LAYOUT - pure arithmetic, so the plate and the suite agree about where things are
/// ============================================================================================

/// Lay _n compartments out in a grid inside a rect. Returns one cell per slot.
///
/// ⚠️ THE CELL SIZE IS DERIVED AND THEN THE GRID IS RE-CENTRED IN THE LEFTOVER. Laying cells from
/// the left edge at a rounded pitch leaves the remainder as one fat gap on the right, which reads
/// as a layout bug on any plate wider than about eight columns. This is the same money-in-the-
/// corner defect a sibling product shipped on its contact sheet.
function cht_cabinet_layout(_n, _cols, _x, _y, _w, _h, _gap) {
    if (_n <= 0 || _cols <= 0) return [];
    var _rows = ceil(_n / _cols);
    var _cw = (_w - _gap * (_cols - 1)) / _cols;
    var _ch = (_h - _gap * (_rows - 1)) / _rows;
    var _out = [];
    for (var _k = 0; _k < _n; _k++) {
        var _c = _k mod _cols;
        var _r = _k div _cols;
        array_push(_out, {
            x: _x + _c * (_cw + _gap),
            y: _y + _r * (_ch + _gap),
            w: _cw, h: _ch, col: _c, row: _r
        });
    }
    return _out;
}

/// ============================================================================================
/// THE EMPTY SLOT, DRAWN
/// ============================================================================================

/// An entomological pin and a blank determination label, in the unit box, as a parts array.
///
/// ⭐ THIS IS THE FUNCTION THE SECTION HEADER IS ABOUT. It is what a gap LOOKS like, and it is why
/// an incomplete drawer reads as a thing to finish rather than as a list with holes in it. A real
/// pin is a headed steel shaft with a small round head; the label is a rectangle of card with two
/// ruled lines on it, because that is what an unwritten determination label is.
///
/// The roles are the generic relief stops, so a caller passes any cuticle map and the pin takes the
/// same lighting as everything else on the plate.
function cht_cabinet_ghost_parts() {
    var _out = [];
    // The pin: a vertical shaft from a third of the way down to the label, with a head on top.
    var _px = 0.500;
    array_push(_out, cht_poly([[_px, 0.150], [_px, 0.620]], false, 0.013, "m1"));
    array_push(_out, cht_dot(_px, 0.150, 0.030, "m3"));
    array_push(_out, cht_dot(_px, 0.150, 0.018, "m4"));

    // The determination label: a card with two blank rules on it.
    var _lx0 = 0.300, _lx1 = 0.700, _ly0 = 0.660, _ly1 = 0.840;
    array_push(_out, cht_rect_fill(_lx0, _ly0, _lx1, _ly1, "m1"));
    array_push(_out, cht_rect_poly(_lx0, _ly0, _lx1, _ly1, 0.008, "m0"));
    array_push(_out, cht_poly([[_lx0 + 0.030, _ly0 + 0.058], [_lx1 - 0.030, _ly0 + 0.058]],
                              false, 0.007, "m0"));
    array_push(_out, cht_poly([[_lx0 + 0.030, _ly0 + 0.116], [_lx1 - 0.100, _ly0 + 0.116]],
                              false, 0.007, "m0"));
    return _out;
}

/// ============================================================================================
/// THE SUMMARY LINE
/// ============================================================================================

/// "31 of 48 species, 12 perfect, 4,180 points". ASCII only - the shipped fonts are 32..126 and a
/// character outside that range draws nothing at all.
function cht_cabinet_line(_cab) {
    var _perfect = 0;
    for (var _i = 0; _i < _cab.n; _i++) if (_cab.best[_i] == 3) _perfect += 1;
    return string(cht_cabinet_count(_cab)) + " of " + string(_cab.n) + " species, "
         + string(_perfect) + " perfect, " + string(cht_cabinet_score(_cab)) + " points";
}
