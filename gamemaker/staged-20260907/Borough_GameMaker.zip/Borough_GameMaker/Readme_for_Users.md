# Borough — settlement and architecture that draws its own buildings

**For GameMaker 2024.11 and newer. Pure GML. No sprites, no shaders, no extensions.**

Borough draws the buildings of a town, and it composes each facade from the state of the settlement
that built it. Founding, prosperity, trade role, wealth tier, age and damage go in; storeys, roof
form, window rhythm, door furniture, wall material, signage and weathering come out. Move the state
and the town visibly changes, in the same run, without a single new asset.

Everything on the store page was rendered by this package. There is not one image file in it.

---

## Install

1. In the IDE: **Tools ▸ Import Local Package**, choose `Borough.yymps`.
2. Import **all** resources when the dialog asks.
3. Open **`rm_borough_demo`** and press **Run**.

That room is the quickstart and it is also the smoke test — if it runs, the package imported
cleanly. Move the sliders, age the town two centuries, put it through a siege, and watch the street
rebuild itself.

### What you get

| | |
| --- | --- |
| `scripts/bor_*` | 14 scripts, raw readable GML, header-documented |
| `objects/obj_borough_demo` | the demo driver — read it, it is the shortest usage example there is |
| `rooms/rm_borough_demo` | the runnable demo room |
| `fonts/fnt_borough*` | Open Sans, used **only** by the demo readout (see *Fonts* below) |

---

## The whole thing in three calls

```gml
// Create — one integer seed is enough
town = bor_settlement_create(1618);
pal  = bor_palette_build(town);

// Draw — a street of 7 buildings, inside this rectangle
bor_street_draw(town, pal, 0, 0, room_width, room_height, 7);
```

That is the entire minimum integration.

### Moving the town

```gml
bor_settlement_step(town, 25, 0.6);   // 25 years pass, prosperity trending up
bor_settlement_step(town, 25, -0.8);  // 25 bad years — it starts boarding up
bor_settlement_damage(town, 0.5);     // a fire, a siege, a storm
pal = bor_palette_build(town);        // the palette follows the state
```

`bor_settlement_step` ages the place, drifts prosperity toward the trend you give it, and lets
damage HEAL while the town is prospering and accrue while it is not. Wealth follows prosperity but
lags it, because wealth is accumulated stock and prosperity is flow — without the lag one bad decade
strips the stone mouldings off a cathedral.

### Setting the state directly

Every field is yours to assign if your game already tracks its own numbers:

```gml
town.prosperity = 0.9;      // 0..1
town.wealth     = 4;        // 0..4
town.age        = 0.35;     // 0..1, visual age; ~300 years at 1.0
town.damage     = 0.0;      // 0..1
town.region     = "alpine"; // bor_region_names()
town.trade      = "port";   // bor_trade_names()
bor_settlement_derive(town);   // ⛔ ALWAYS, after a direct assignment
```

⛔ **`bor_settlement_derive` is not optional after a direct assignment.** It recomputes the wall
material, roof material, pitch, gable orientation and hue shift from the fields you just changed. If
you skip it you get last state's materials on this state's numbers, and it looks like the product
ignoring you rather than a missed step. `bor_settlement_step` and `bor_street_draw` both call it for
you, so this only bites on a raw assignment followed by a raw draw.

### One building at a time

```gml
b = bor_building_create(town, "inn", 3);        // role, and a slot index for per-building variation
bor_building_draw(b, pal, x, y, w, h);          // fitted inside the rect you give it
pts = bor_building_silhouette(b);               // outline points, for your own collision or shadow
```

`bor_street_build(town, count)` gives you the row as data if you would rather place the buildings
yourself.

### A bad argument is refused, never thrown

Every public entry point checks what it was handed and **returns instead of crashing your game**.
Nothing in this package can take a room down because a variable was `undefined` on the frame a save
finished loading or a town had not been built yet.

| given something it cannot use | it returns |
| --- | --- |
| `bor_settlement_create` | `undefined` |
| `bor_settlement_derive` / `_step` / `_damage` | the state you passed in, **unchanged** |
| `bor_palette_build` | `undefined` |
| `bor_building_create` | `undefined` |
| `bor_building_draw` / `_draw_at` / `bor_street_draw` | nothing is drawn |
| `bor_building_silhouette` / `bor_street_build` | an **empty** array |
| `bor_settlement_label` | an empty string |

⚠️ **The refusals are deliberately visible.** None of them invents a default town, a default palette
or a default building, because a plausible-looking wrong picture is far harder to find than an empty
rectangle. If a street stops drawing, the state you handed it is not a settlement — and
`bor_settlement_step` returning your input untouched is the same signal in the data.

---

## What is actually in the corpus

Measured by the package's own in-engine self-test, not estimated. **Every member below is the
literal string the package uses**, exactly as `bor_role_names()`, `bor_roof_names()`,
`bor_rhythm_names()`, `bor_door_names()` and `bor_wall_names()` return it — so you can copy one
straight into `bor_building_create(town, "inn", 3)` or compare it against a building's own fields.

| axis | count | members (literal ids) |
| --- | --- | --- |
| **Building roles** | 14 | cottage · townhouse · longhouse · shopfront · inn · smithy · mill · granary · warehouse · chapel · guildhall · gatehouse · watchtower · tenement |
| **Roof forms** | 10 | gable · hip · halfhip · gambrel · mansard · catslide · monopitch · parapet · conical · stepped |
| **Window rhythms** | 8 | single · paired · triple · arcade · oriel · dormer · blind · shuttered |
| **Door treatments** | 6 | plank · panelled · arched · pilastered · carriage · stall |
| **Wall treatments** | 6 | timberframe · rubble · ashlar · brick · render · halfrender |

**44 authored forms**, and the roles are proven mutually distinct by silhouette — not by colour. Six
regions and six trades sit on top of that, and region changes the OUTLINE (pitch, gable orientation,
parapet) rather than only the palette.

---

## How it is drawn, and why it does not look like the engine

Every mass is shaded by **surface normal against one fixed lamp**, from a five-stop Oklch ramp per
material. That is the whole reason a wall reads as a wall rather than as a filled rectangle, and it
is applied from the first mass rather than added afterwards.

- Material ramps darken, desaturate **and compress** with wear. A weathered wall is not just darker,
  it is a wall whose lit and shadowed faces have moved closer together — a soot-black wall with a
  bright highlight on it reads as wet plastic.
- Age sags the ridge, accretes a lean-to, and greens the wall from the ground up.
- Damage boards the windows, streaks soot down from the eaves, and at the top of the range takes a
  bay out of the wall entirely — the one weathering that changes the silhouette.
- No stroke carries anything load-bearing. `draw_line_width` floors at 1px with no antialiasing at
  the sizes a game runs at, so tone is carried by count, length and area instead.

---

## Verification, stated exactly

- **Builds clean** through the real GameMaker compiler (Igor, runtime `2024.14.4.268`): exit 0, zero
  errors, zero warnings.
- **1001 in-engine assertions pass, 0 fail**, run against a compiled executable — not a simulation
  of GML. Convexity and simplicity are asserted on every one of 118 building masses and 68 roof
  masses, and every role pair is checked for silhouette separation.
- **Every store image is rendered by this package**, by the same code you are importing.
- ⚠️ **What is NOT proven:** the IDE's import dialog cannot be driven headlessly, so the package
  payload is verified by compiling the project extracted from it rather than by watching the import
  succeed. If `Tools ▸ Import Local Package` ever refuses this file, that is a bug worth reporting
  and it will be fixed.

---

## Fonts

`fnt_borough` and `fnt_borough_title` are **Open Sans**, licensed Apache-2.0. The full licence and
the required NOTICE travel in `fonts/` inside the package.

They are used **only by the demo room's readout** — the settlement's trade, region, wealth tier and
age in years. The facades draw no text at all except shop signage, which is geometry rather than
lettering. If you delete both fonts you lose the readout and nothing else.

---

## Licence

See `LICENSE.txt`. Short version: use it in commercial and non-commercial games, modify it freely,
ship it inside your game. Do not resell it as an asset pack.

## Support

Post on the itch.io project page. Every script carries a header block explaining what it does and
what it assumes, and the demo object is deliberately short enough to read in one sitting.

---

*Core Systems Asset Factory*
