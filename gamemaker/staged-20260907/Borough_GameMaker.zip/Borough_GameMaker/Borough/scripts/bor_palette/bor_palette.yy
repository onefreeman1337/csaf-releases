{
  "$GMScript": "v1",
  "%Name": "bor_palette",
  "isCompatibility": false,
  "isDnD": false,
  "name": "bor_palette",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}