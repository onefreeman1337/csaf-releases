{
  "$GMScript": "v1",
  "%Name": "bor_building",
  "isCompatibility": false,
  "isDnD": false,
  "name": "bor_building",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}