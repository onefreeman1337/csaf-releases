/// BOROUGH - bor_building. THE ASSEMBLY: settlement state in, one composed facade out.
///
/// This is the file the product is named for. Everything else authors a vocabulary; this decides
/// what the building actually is and puts it together in the one order that reads as architecture:
///
///   1. masses          solved from the role and the state           (bor_massing)
///   2. relief-shade    every mass, by edge normal, against one lamp (bor_relief)
///   3. roof            its own mass, overhanging, with its shadow   (bor_roof)
///   4. wall treatment  clipped to the wall it belongs to            (bor_wall)
///   5. openings        subtracted area with a recessed reveal       (bor_opening)
///   6. furniture       signage, chimneys, the things that say TRADE
///   7. weathering      last, because dirt lies on top of everything (bor_wall)
///
/// ⛔ THE ORDER IS THE PICTURE, and step 3 is where a generated town usually dies. A roof drawn
/// FLUSH with the wall reads as a triangle on a box no matter how good the shading is. The eaves
/// overhang, and the SHADOW that overhang throws down the wall, are most of what says "building".
/// It is four lines and it is the highest-value four lines in the package.
///
/// -- PUBLIC API --------------------------------------------------------------------------------
///   bor_building_create(st, role, slot)     derive every visual property from the state
///   bor_building_parts(b)                   the part list, if you want to place it yourself
///   bor_building_draw(b, pal, x, y, w, h)   one call, and it stays inside the rect it is given
///   bor_building_silhouette(b)              the outline, for the buyer's own shadows and hit tests
///
/// ⚠️ bor_building_draw MUST STAY INSIDE ITS RECT. This wing shipped a product whose one unbounded
/// draw call bled into the cell beside it, and in a buyer's game that paints over whatever sits
/// next to it. bor_selftest measures the bounds of every role at several states and asserts they
/// fall inside the unit box, which is the only way to check it without a picture.
/// ============================================================================================

/// Derive a building from the settlement.
///
/// _slot is the buyer's index along the street. It is a SEED, not a position: it decides which role
/// this plot got and how its dice fell, so a street is stable frame to frame and identical between
/// two runs with the same settlement seed.
function bor_building_create(_st, _role, _slot) {
    // Guard: refuse rather than throw (2026-09-07). `undefined` is the refusal because a building is
    // a HANDLE - there is no such thing as a plausible default one, and every consumer below is
    // guarded to draw nothing when handed a non-building. Returning a fabricated cottage would put
    // a wrong facade on a buyer's street and look like the product working.
    if (!bor_is_settlement(_st)) return undefined;
    if (!is_undefined(_slot) && !is_numeric(_slot)) return undefined;
    if (!is_undefined(_role) && !is_string(_role)) return undefined;

    var _sl = is_undefined(_slot) ? 0 : _slot;
    var _roles = bor_trade_roles(_st.trade);
    var _r = is_undefined(_role) ? _roles[_sl % array_length(_roles)] : _role;

    // A per-building state. The settlement is shared; a building's OWN dice are not, or every
    // cottage on the street gets its lean-to on the same side.
    var _own = {
        seed:        _st.seed + _sl * 7919,
        prosperity:  _st.prosperity,
        trade:       _st.trade,
        wealth:      _st.wealth,
        age:         _st.age,
        damage:      _st.damage,
        region:      _st.region,
        founded:     _st.founded,
        hue_shift:   _st.hue_shift,
        sign_hue:    _st.sign_hue,
        wall_mat:    _st.wall_mat,
        roof_mat:    _st.roof_mat,
        pitch:       _st.pitch,
        parapet:     _st.parapet,
        gable_front: _st.gable_front,
    };

    // Vary the building against its neighbours WITHOUT breaking the settlement's character. Age and
    // damage jitter; region, materials and pitch do not, because those are what make a street look
    // like ONE town rather than a sampler sheet.
    var _rng = bor_rng(bor_hash32("bor_building:" + string(_own.seed)));
    _own.age    = clamp(_own.age    + (bor_rng_next(_rng) - 0.5) * 0.22, 0, 1);
    _own.damage = clamp(_own.damage + (bor_rng_next(_rng) - 0.5) * 0.20, 0, 1);

    var _masses = bor_massing_build(_r, _own);
    var _main   = bor_massing_main(_masses);
    var _ext    = bor_massing_extent(_masses);

    return {
        role:    _r,
        st:      _own,
        masses:  _masses,
        main:    _main,
        rhythm:  bor_rhythm_pick(_r, _own),
        door:    bor_door_pick(_r, _own),
        rooff:   bor_roof_pick(_r, _own),
        treat:   bor_wall_pick(_own),
        storeys: bor_massing_storeys(_r, _own),
        xl:      _ext[0],
        xr:      _ext[1],
        slot:    _sl,
    };
}

/// Does this role hang a sign? Trade buildings do; dwellings do not.
function bor_building_signed(_role) {
    switch (_role) {
        case "inn": case "shopfront": case "smithy": case "guildhall": return true;
    }
    return false;
}

/// ============================================================================================
/// THE PART LIST
/// ============================================================================================
function bor_building_parts(_b) {
    // Guard: refuse rather than throw (2026-09-07). An empty part list draws nothing, which is what
    // both draw entry points above already do with one.
    if (!bor_is_building(_b)) return [];

    var _out = [];
    var _st = _b.st;
    var _main = _b.main;
    var _nm = array_length(_b.masses);

    // -- 1 & 2. THE MASSES, RELIEF-SHADED ------------------------------------------------------
    // Each mass is bevelled on its own outline and mapped into its own material. The bevel is
    // solved from the mass's SMALLER dimension so it can never be wider than the feature it bevels
    // - which on a chimney stack or a staddle-stone leg is a real risk and would turn the feature
    // inside out.
    for (var _i = 0; _i < _nm; _i++) {
        var _m = _b.masses[_i];
        var _mw = _m.x1 - _m.x0;
        var _mh = BOR_GROUND - _m.ytop;
        var _bev = min(_mw, _mh) * 0.055;
        bor_append(_out, bor_map_roles(bor_raise(_m.pts, _bev, 2, _m.mat + "2"),
                                       bor_material_map(_m.mat)));
    }

    // -- 4. THE WALL TREATMENT, on the main block and on any wing ------------------------------
    for (var _i = 0; _i < _nm; _i++) {
        var _m = _b.masses[_i];
        if (_m.kind != "main" && _m.kind != "wing") continue;
        bor_append(_out, bor_wall_build(_b.treat, _m.x0 + 0.004, _m.ytop + 0.004,
                                        _m.x1 - 0.004, BOR_GROUND - 0.002, _st));
    }

    // -- 3. THE ROOF, ON EVERY MASS THAT HAS ONE -----------------------------------------------
    // Built after the wall treatment so it draws OVER the courses at the eaves, which is what
    // happens on a building: the roof laps the wall head.
    var _roofs = [];
    for (var _i = 0; _i < _nm; _i++) {
        var _m = _b.masses[_i];
        if (_m.kind == "plinth") continue;

        // A mass whose TOP EDGE IS ALREADY THE ROOF PLANE gets a capping ribbon, never a second
        // roof. See the sloped:true note in bor_massing - a monopitch stacked on an outshut read as
        // a plank floating out from the gable on every cottage in the corpus.
        if (variable_struct_exists(_m, "sloped") && _m.sloped) {
            var _cw = (_m.x1 - _m.x0);
            var _ca = _m.cap[0], _cb = _m.cap[1];
            // Extended a little past both ends: a lean-to's roof laps its own wall, and the tiny
            // overshoot is what stops the junction reading as a butt joint at small sizes.
            var _dx = (_cb[0] - _ca[0]) * 0.06, _dy = (_cb[1] - _ca[1]) * 0.06;
            bor_append(_out, bor_map_roles(
                bor_ribbon([[_ca[0] - _dx, _ca[1] - _dy], [_cb[0] + _dx, _cb[1] + _dy]],
                           _cw * 0.085, "roof3"),
                bor_material_map("roof")));
            continue;
        }

        var _form = (_m.kind == "main") ? _b.rooff
                  : ((_m.kind == "tower") ? "conical"
                  : ((_m.kind == "stack") ? "parapet" : "monopitch"));
        var _r = bor_roof_build(_form, _m.x0, _m.x1, _m.ytop, _st, _st.gable_front);
        array_push(_roofs, _r);

        // ⛔ THE EAVES SHADOW. The overhang throws a band of shade down the wall directly beneath
        // it, and this is the four lines the header calls the highest-value four lines here.
        // Drawn BEFORE the roof mass so the roof laps over its own shadow.
        //
        // ⛔ AND THE FIRST VERSION OF THESE FOUR LINES WAS WRONG IN THREE INDEPENDENT WAYS, EVERY
        // ONE OF THEM VISIBLE AND NONE OF THEM MECHANICALLY DETECTABLE. Measured 2026-08-28 by
        // cropping sheet 6 and looking: a cottage carried a solid BLACK BAND between its roof and
        // its wall head, a fifth of the wall deep and WIDER THAN THE BUILDING, with the chimney
        // ending in mid-air inside it. It read as a hole punched through the picture. The three
        // faults, in the order they matter:
        //
        //   1. THE COLOUR WAS THE PAGE'S SHADOW, NOT THE WALL'S. `_pal.shadow` is L=0.13 - very
        //      nearly the catalogue page ground - so an OPAQUE fill in it does not darken the wall,
        //      it DELETES the wall. A wall in shade is still that wall: it is the material's own
        //      darkest ramp stop, `<mat>0`, which is exactly what the palette header means by
        //      "down through the raking planes, to the wall in full shadow under an eave".
        //   2. THE DEPTH WAS DRIVEN BY THE BUILDING'S WIDTH. `_ov` is a fraction of the HALF-WIDTH,
        //      so the band's depth scaled with how WIDE the building is while the wall it lands on
        //      scales with how TALL it is. A cottage is the worst case in both directions at once -
        //      wide, low, and thatched, and thatch carries the largest overhang precisely because it
        //      is the poorest roof - so the error was largest exactly where the product can least
        //      afford it. Depth is now capped against the WALL HEIGHT, which is the surface the
        //      shadow is cast onto.
        //   3. IT EXTENDED PAST THE WALL ON BOTH SIDES, into open air, because it inherited the
        //      roof's overhung span. A shadow cast onto a wall cannot exist where there is no wall.
        //      That overshoot is what made the band read as sky-coloured damage rather than shade.
        //
        // ⚠️ NO CHECK IN THIS PRODUCT COULD HAVE CAUGHT IT. The band is ink, in a plausible place,
        // inside the content bounds - so the content floor counted it as content and the sheet
        // passed at 0.55. The convexity and simplicity assertions are about outlines and this is a
        // rectangle. It was found by cropping the PNG and enlarging it, which is the only instrument
        // this wing has ever had for defects of this class.
        var _ov = (_m.x1 - _m.x0) * 0.5 * bor_roof_overhang(_st);
        if (_r.form != "parapet") {
            var _wallh = BOR_GROUND - _m.ytop;
            var _shd   = min(_ov * 0.85, _wallh * 0.085);
            array_push(_out, bor_rect_fill(_m.x0, _m.ytop,
                                           _m.x1, _m.ytop + _shd, _m.mat + "0"));
        }

        var _nr = array_length(_r.masses);
        for (var _k = 0; _k < _nr; _k++) {
            var _rm = _r.masses[_k];
            var _rb = bor_render_bounds([bor_fill(_rm.pts, "m2")]);
            var _rbev = min(_rb[2] - _rb[0], max(0.004, _rb[3] - _rb[1])) * 0.10;
            bor_append(_out, bor_map_roles(bor_raise(_rm.pts, _rbev, 2, _rm.mat + "3"),
                                           bor_material_map(_rm.mat)));
        }
        bor_append(_out, bor_roof_surface(_r, _m.x0, _m.x1, _st));
    }

    // -- 5. THE OPENINGS ------------------------------------------------------------------------
    // One band per storey on the main block, the ground floor reserved for the door and the trade
    // treatment. Upper storeys get the rhythm.
    var _n = _b.storeys;
    var _wallh = BOR_GROUND - _main.ytop;
    var _sh = _wallh / max(1, _n);

    for (var _s = 0; _s < _n - 1; _s++) {
        var _yt = _main.ytop + _sh * _s;
        bor_append(_out, bor_opening_band(_b.rhythm, _main.x0 + _wallh * 0.05,
                                          _main.x1 - _wallh * 0.05, _yt, _yt + _sh, _st));
    }

    // A JETTIED upper storey on a timber-framed building: the first floor oversails the ground
    // floor on the joist ends. It is the most recognisable silhouette in medieval townscape and it
    // is one raised mass.
    if (_b.treat == "timberframe" && _n >= 2) {
        var _jy = BOR_GROUND - _sh;
        var _jx = (_main.x1 - _main.x0) * 0.045;
        bor_append(_out, bor_map_roles(
            bor_raise(bor_taper_box_pts(_main.x0 - _jx, _main.x1 + _jx, _jy - _sh * 0.06,
                                        _main.x0, _main.x1, _jy), _sh * 0.030, 2, "beam2"),
            bor_material_map("beam")));
    }

    // -- the ground floor: door, and the trade treatment beside it ------------------------------
    var _gy = BOR_GROUND;
    var _gtop = _gy - _sh;
    var _dw = min((_main.x1 - _main.x0) * 0.26, _sh * 0.52);
    var _dh = _sh * 0.74;
    // Off centre, because a centred door on every building in a row is the strongest possible
    // signal that a machine placed them.
    var _dx = lerp(_main.x0, _main.x1, 0.30 + 0.40 * frac(_st.seed * 0.61803398875));
    bor_append(_out, bor_opening_door(_b.door, _dx, _gy, _dw, _dh, _st));

    // Ground-floor windows either side of the door, where there is room for them.
    if (_b.door != "stall" && _b.door != "carriage" && (_main.x1 - _main.x0) > _dw * 3.0) {
        var _gw = _dw * 0.72;
        var _gh = _dh * 0.60;
        for (var _k = -1; _k <= 1; _k += 2) {
            var _wx = _dx + _k * (_dw * 0.5 + _gw * 0.95);
            if (_wx - _gw * 0.5 < _main.x0 + _dw * 0.25) continue;
            if (_wx + _gw * 0.5 > _main.x1 - _dw * 0.25) continue;
            var _wf = (_st.damage > 0.30 && (((_st.seed + _k) % 3) == 0)) ? "board" : "glass";
            bor_append(_out, bor_opening_one(_wx - _gw * 0.5, _gy - _dh * 0.92,
                                             _wx + _gw * 0.5, _gy - _dh * 0.92 + _gh, _st, _wf));
        }
    }

    // -- 6. FURNITURE: the marks that say what this building is FOR -----------------------------
    bor_append(_out, bor_building_furniture(_b, _roofs));

    // -- 7. WEATHERING, last, because dirt lies on top --------------------------------------------
    bor_append(_out, bor_wall_weather(_main.x0, _main.ytop, _main.x1, BOR_GROUND, _st));

    return _out;
}

/// The trade furniture. A signboard on a bracket, a chimney, a hoist beam, a bell.
///
/// ⚠️ THESE ARE WHAT MAKE FOURTEEN ROLES READ AS FOURTEEN THINGS rather than as fourteen sizes of
/// house. The massing carries the silhouette; this carries the meaning, and at a small size the
/// bracket-and-board shape is legible when nothing else on the facade is.
function bor_building_furniture(_b, _roofs) {
    var _out = [];
    var _st = _b.st;
    var _m = _b.main;
    var _w = _m.x1 - _m.x0;
    var _h = BOR_GROUND - _m.ytop;

    // A CHIMNEY on anything with a hearth. Rises past the ridge, tapers, and has a cap course.
    if (_b.role != "watchtower" && _b.role != "gatehouse" && _b.role != "granary"
     && _b.role != "warehouse" && _b.role != "mill") {
        var _cx = lerp(_m.x0, _m.x1, 0.22 + 0.56 * frac(_st.seed * 0.38196601125));
        var _top = _m.ytop - _h * 0.14;
        var _cw = _w * 0.045;
        bor_append(_out, bor_map_roles(
            bor_raise(bor_taper_box_pts(_cx - _cw, _cx + _cw, _top,
                                        _cx - _cw * 1.30, _cx + _cw * 1.30, _m.ytop + _h * 0.10),
                      _cw * 0.30, 2, "stone2"), bor_material_map("stone")));
        bor_append(_out, bor_map_roles(
            bor_raise(bor_box_pts(_cx - _cw * 1.45, _top - _h * 0.022,
                                  _cx + _cw * 1.45, _top + _h * 0.012),
                      _cw * 0.26, 2, "stone3"), bor_material_map("stone")));
    }

    // A SIGNBOARD on a wrought bracket, for the trades that had one.
    if (bor_building_signed(_b.role)) {
        var _sx = lerp(_m.x0, _m.x1, 0.76);
        var _sy = BOR_GROUND - _h * 0.62;
        var _bw = _w * 0.20;
        // The bracket: an L of ironwork with a scrolled stay under it. Drawn as incised strokes,
        // because at facade scale a bracket is a line and giving it a mass makes it read as a beam.
        bor_append(_out, bor_map_roles(
            bor_ridge([[_m.x1, _sy - _bw * 0.62], [_sx + _bw * 0.55, _sy - _bw * 0.62]],
                      false, 0.006), bor_material_map("iron")));
        bor_append(_out, bor_map_roles(
            bor_ridge([[_m.x1, _sy - _bw * 0.05], [_sx + _bw * 0.55, _sy - _bw * 0.62]],
                      false, 0.005), bor_material_map("iron")));
        // The board itself, hanging, in the settlement's own paint.
        array_push(_out, bor_rect_fill(_sx - _bw * 0.5, _sy - _bw * 0.52,
                                       _sx + _bw * 0.5, _sy + _bw * 0.30, "sign"));
        bor_append(_out, bor_map_roles(
            bor_bevel(bor_box_pts(_sx - _bw * 0.5, _sy - _bw * 0.52,
                                  _sx + _bw * 0.5, _sy + _bw * 0.30), _bw * 0.07, 2, false),
            bor_material_map("iron")));
        // A device on the board - a plain charge per trade, gilded at wealth 4. This is the one
        // place in the product where a building says a WORD, and it says it in a shape.
        var _dcol = (_st.wealth >= 4) ? "gild" : "roof4";
        var _dx = _sx, _dy = _sy - _bw * 0.11, _dr = _bw * 0.20;
        switch (_b.role) {
            case "inn":       array_push(_out, bor_ring(_dx, _dy, _dr, 0.008, _dcol));
                              array_push(_out, bor_rect_fill(_dx - _dr * 0.30, _dy - _dr * 1.05,
                                                             _dx + _dr * 0.30, _dy - _dr * 0.55,
                                                             _dcol)); break;
            case "smithy":    array_push(_out, bor_ring_fill(bor_star_pts(_dx, _dy, _dr, 3, -pi / 2),
                                                             _dcol, undefined, undefined)); break;
            case "guildhall": array_push(_out, bor_ring_fill(bor_star_pts(_dx, _dy, _dr, 5, -pi / 2),
                                                             _dcol, undefined, undefined)); break;
            default:          array_push(_out, bor_dot(_dx, _dy, _dr * 0.72, _dcol));
                              array_push(_out, bor_ring(_dx, _dy, _dr, 0.007, _dcol)); break;
        }
    }

    // A HOIST BEAM projecting from the gable of a warehouse or a granary - the loading door and its
    // lifting beam, which is the single mark that identifies a store building anywhere in Europe.
    if (_b.role == "warehouse" || _b.role == "granary" || _b.role == "mill") {
        var _hx = (_m.x0 + _m.x1) * 0.5;
        var _hy = _m.ytop + _h * 0.10;
        bor_append(_out, bor_map_roles(
            bor_raise(bor_box_pts(_hx - _w * 0.020, _hy - _h * 0.020,
                                  _hx + _w * 0.020, _hy + _h * 0.014), _w * 0.008, 2, "beam3"),
            bor_material_map("beam")));
        bor_append(_out, bor_map_roles([bor_ring(_hx, _hy + _h * 0.045, _h * 0.020, 0.005, "iron1")],
                                       bor_material_map("iron")));
    }

    // A BELL in the chapel's turret opening.
    if (_b.role == "chapel") {
        var _nm2 = array_length(_b.masses);
        for (var _i = 0; _i < _nm2; _i++) {
            var _t = _b.masses[_i];
            if (_t.kind != "tower") continue;
            var _tx = (_t.x0 + _t.x1) * 0.5;
            var _ty = _t.ytop + (BOR_GROUND - _t.ytop) * 0.16;
            var _tw = (_t.x1 - _t.x0) * 0.52;
            bor_append(_out, bor_opening_one(_tx - _tw * 0.5, _ty, _tx + _tw * 0.5,
                                             _ty + _tw * 1.35, _st, "shadow"));
            bor_append(_out, bor_map_roles(
                bor_raise([[_tx - _tw * 0.30, _ty + _tw * 0.42], [_tx + _tw * 0.30, _ty + _tw * 0.42],
                           [_tx + _tw * 0.20, _ty + _tw * 1.00], [_tx - _tw * 0.20, _ty + _tw * 1.00]],
                          _tw * 0.09, 2, "iron3"), bor_material_map("iron")));
        }
    }

    return _out;
}

/// ============================================================================================
/// DRAWING
/// ============================================================================================

/// The whole facade, into a rect, uniformly scaled and centred. Stays inside the rect.
function bor_building_draw(_b, _pal, _x, _y, _w, _h) {
    // Guard: refuse rather than throw (2026-09-07). Drawing NOTHING is the closed refusal - the
    // buyer sees an empty rect and goes looking. Drawing a default building into their scene would
    // be the failure this wing's own rule about fail-open guards exists for.
    if (!bor_is_building(_b)) return;
    if (!bor_is_palette(_pal)) return;
    if (!bor_is_rect(_x, _y, _w, _h)) return;

    bor_render_in_rect(bor_building_parts(_b), _pal, _x, _y, _w, _h, 0, undefined);
}

/// The whole facade at an explicit centre and scale. This is what a street uses, because a street
/// needs every building on ONE scale and ONE ground line - fitting each into its own slot would
/// make a cottage and a guildhall the same height, which is the proportion that carries the state.
function bor_building_draw_at(_b, _pal, _cx, _cy, _s) {
    // Guard: refuse rather than throw (2026-09-07). Sibling of bor_building_draw and guarded on the
    // same terms even though the Readme does not name it - this is the entry point bor_street_draw
    // itself uses, so an unguarded one would put the crash back one call deeper.
    if (!bor_is_building(_b)) return;
    if (!bor_is_palette(_pal)) return;
    if (!is_numeric(_cx) || !is_numeric(_cy) || !is_numeric(_s)) return;

    bor_render_parts(bor_building_parts(_b), _pal, _cx, _cy, _s, 0, 1, undefined);
}

/// The building's outline as a single closed path, for the buyer's own shadow, hit test or
/// occlusion. The union of the mass boxes, taken as the upper envelope at a set of sample columns.
///
/// ⚠️ THIS IS NOT A MASS AND MUST NOT BE FILLED WITH A FAN - it is the SKYLINE of a building, which
/// is concave wherever a wing steps down from the main block. It is returned as an open polyline
/// from left to right for exactly that reason, and the header of bor_massing explains what happens
/// to a caller who ignores this.
/// ⛔ IT SAMPLES A FIXED WINDOW, NOT THE BUILDING'S OWN EXTENT, AND THE FIRST VERSION DID THE
/// OPPOSITE. MEASURED 2026-08-28: sampling from xl to xr NORMALISES WIDTH AWAY, so a 0.20-wide
/// tenement and a 0.36-wide warehouse - both plain boxes - produced byte-identical profiles and the
/// suite reported EIGHT role pairs at a silhouette distance of exactly 0.0000. That is the
/// product's whole volume claim failing, reported as a pass by an instrument that could not see
/// width at all.
///
/// It is also wrong for the caller's own use: a game asking for a building's outline wants it in
/// the coordinates the building is drawn in, not in a per-building normalised space.
function bor_building_silhouette(_b) {
    // Guard: refuse rather than throw (2026-09-07). An EMPTY path, not a fabricated box.
    // ⛔ The dangerous direction here is specific and it is the reason this refusal is empty rather
    // than a unit rectangle: the header above says this outline is for "the buyer's own shadow, hit
    // test or occlusion". A default rectangle would report HITS on a building that does not exist,
    // and the caller's next line runs whatever a click on a building does. An empty path reports
    // nothing, and every `array_length` loop over it does nothing, which is what a refusal should
    // cost. Same reasoning as Livery's lvy_widget_hit returning false.
    if (!bor_is_building(_b)) return [];

    var _n = 48;
    var _out = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _x = lerp(-0.5, 0.5, _i / _n);
        var _top = BOR_GROUND;
        var _nm = array_length(_b.masses);
        for (var _k = 0; _k < _nm; _k++) {
            var _m = _b.masses[_k];
            if (_x >= _m.x0 && _x <= _m.x1) _top = min(_top, _m.ytop);
        }
        _out[_i] = [_x, _top];
    }
    return _out;
}
