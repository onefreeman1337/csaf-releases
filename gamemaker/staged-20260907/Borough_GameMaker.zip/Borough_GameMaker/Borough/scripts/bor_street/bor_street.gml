/// BOROUGH - bor_street. A row of buildings that belong to the same place.
///
/// One call draws a street. It is the thing most buyers will actually use, and it exists because a
/// row of buildings is not a list of buildings: they share a GROUND LINE, they share a SCALE, they
/// abut rather than float, and they are lit by the same lamp. Get any of those wrong and the row
/// reads as a sprite sheet laid out sideways.
///
/// ⛔ ONE SCALE FOR THE WHOLE ROW. Fitting each building into its own slot is the obvious
/// implementation and it destroys the product: a one-storey cottage and a four-storey guildhall
/// would be drawn the SAME HEIGHT, and relative height is precisely how a viewer reads prosperity
/// off a townscape. So the scale is computed once, from the row rect, and every building is placed
/// at that scale by its own centre.
///
/// ⛔ AND THE GROUND LINE IS SHARED FOR FREE. Every form in the corpus is authored to meet the
/// ground at y = BOR_GROUND in the unit box, so placing every unit box at the same centre y puts
/// every building on the same street with no per-building alignment term at all. That is the whole
/// reason the constant exists.
/// ============================================================================================

/// How wide a street rect must be before it is worth drawing anything into. Below this the row
/// would be one building wide and the caller almost certainly wanted bor_building_draw.
#macro BOR_STREET_MIN_W 0.001

/// Where the ground line sits in a street rect, as a fraction of its height. The band above is sky,
/// the band below is paving. Named because the SCALE SOLVE depends on it: a building rises from this
/// line to the top of its unit box, and the two numbers must agree or roofs clip.
#macro BOR_STREET_GROUND 0.80

/// Build a row of buildings for a settlement.
///
/// Roles are drawn from the trade's own list, so a port row is warehouses and inns and a monastic
/// one is chapels and granaries. The SEQUENCE is deterministic in the settlement seed.
function bor_street_build(_st, _count) {
    // Guard: refuse rather than throw (2026-09-07). An EMPTY row: bor_street_width sums to 0 and
    // bor_street_draw's own guard turns that into an empty rect. A one-building fallback row would
    // put a lone cottage in the middle of a street the buyer asked for and read as a layout bug
    // rather than as a rejected argument.
    if (!bor_is_settlement(_st)) return [];
    if (!is_numeric(_count)) return [];

    var _n = max(1, _count);
    var _roles = bor_trade_roles(_st.trade);
    var _nr = array_length(_roles);
    var _out = array_create(_n);
    var _rng = bor_rng(bor_hash32("bor_street:" + string(_st.seed)));
    for (var _i = 0; _i < _n; _i++) {
        // Walk the role list with a jump rather than in order, so a long row does not visibly
        // repeat its own cycle - which it does, obviously, at any count above the list length.
        var _k = (floor(bor_rng_next(_rng) * _nr) + _i) % _nr;
        _out[_i] = bor_building_create(_st, _roles[_k], _i);
    }
    return _out;
}

/// The total width of a row in unit-box units, so a caller can solve its own scale.
function bor_street_width(_row) {
    // Guard: refuse rather than throw (2026-09-07). Zero is the honest width of a row that is not a
    // row, and it is what an empty row from a refused bor_street_build already measures.
    if (!is_array(_row)) return 0;

    var _n = array_length(_row);
    var _w = 0;
    for (var _i = 0; _i < _n; _i++) _w += (_row[_i].xr - _row[_i].xl);
    return _w;
}

/// ============================================================================================
/// DRAWING
/// ============================================================================================

/// Draw a whole street into a rect.
///
/// _count buildings, abutting, sharing one ground line and one scale, in front of a graduated
/// backdrop, on paving that recedes.
///
/// ⚠️ THE SCALE IS SOLVED FROM THE ROW, NOT CHOSEN. The row is as wide as it is; the scale is
/// whatever makes it fit the rect, capped so that a two-building row does not render at cathedral
/// size. Solving rather than tuning is why a buyer can pass any count and any rect and never get a
/// clipped facade - the wing's own law, from a panel that ran 38 px off a sheet and reported ok.
function bor_street_draw(_st, _pal, _x, _y, _w, _h, _count) {
    // Guard: refuse rather than throw (2026-09-07). This is the product's one-call entry point, so
    // it is the one most likely to be handed something odd, and drawing nothing is the refusal.
    if (!bor_is_settlement(_st)) return;
    if (!bor_is_palette(_pal)) return;
    if (!bor_is_rect(_x, _y, _w, _h)) return;
    if (!is_numeric(_count)) return;

    if (_w <= BOR_STREET_MIN_W || _h <= BOR_STREET_MIN_W) return;

    // Defensive: a buyer who assigned st.prosperity directly and drew without deriving would
    // otherwise get last frame's materials on this frame's state, and it would look like the
    // product ignoring them. Cheap, and it removes the trap entirely.
    bor_settlement_derive(_st);

    // ⛔ THE ROW IS EXTENDED UNTIL IT FILLS THE RECT, AND THE FIRST VERSION LEFT HALF THE FRAME
    // EMPTY. MEASURED 2026-08-28 by rendering the hero sheet and looking at it: a seven-building row
    // covered about 45% of a 1600px strip and the rest was bare backdrop, on the one image a buyer
    // decides from. The cause is that the scale is capped by HEIGHT - as it must be, or a short row
    // renders at cathedral size - so the row's pixel width is whatever that cap makes it, and no
    // count chosen in advance can be right for an arbitrary rect.
    //
    // So _count is a MINIMUM, not a target. The row grows until it covers the rect. That also makes
    // the call honest for a buyer: "fill this strip with a town" is what the function is for, and it
    // now does that at any rect and any aspect without the caller solving for the count.
    // ⚠️ THE COUNT IS SOLVED, NOT SEARCHED. The obvious implementation - rebuild the whole row,
    // one building longer, until it fits - is O(n^2) building constructions and would run hundreds
    // of times per frame on a wide strip. bor_street_build is a PREFIX function (row n+1 begins with
    // row n), so the average frontage from one probe row gives the needed count directly.
    // ⛔ THE HEIGHT CAP IS SOLVED AGAINST THE GROUND LINE, NOT SET TO _h. MEASURED 2026-08-28 by
    // rendering the hero sheet and looking at it: the four-storey brick row had its roofs sliced off
    // by the top of its strip. The arithmetic is not subtle once written down - the ground line sits
    // at BOR_STREET_GROUND of the rect, a building reaches from the ground line up to the TOP of its
    // unit box, and that span is (BOR_GROUND + 0.5) box-units. So the scale that just fits is
    // (_h * BOR_STREET_GROUND) / (BOR_GROUND + 0.5), and using _h assumes the ground line is at the
    // bottom of the rect, which it deliberately is not.
    //
    // Solving it means no state, no role and no rect aspect can clip a roof. Choosing a smaller
    // constant would have hidden this one case and left the next one to be found by eye.
    var _probe = bor_street_build(_st, _count);
    var _tot = bor_street_width(_probe);
    var _s = min(_w / max(0.001, _tot),
                 (_h * BOR_STREET_GROUND) / (BOR_GROUND + 0.5));

    var _avg = _tot / max(1, array_length(_probe));
    var _need = max(_count, ceil(_w / max(0.0001, _avg * _s)) + 1);
    var _row = (_need == _count) ? _probe : bor_street_build(_st, min(_need, 400));

    // One bounded top-up, because the average is an average: a row that happens to draw several
    // narrow plots can still fall short of the rect by one building.
    if (bor_street_width(_row) * _s < _w) {
        _row = bor_street_build(_st, min(array_length(_row) + 4, 400));
    }
    var _n = array_length(_row);

    // Sit the ground line at four fifths of the rect height, leaving the top for sky and the bottom
    // for street. BOR_GROUND is where the buildings meet it inside their own box, so the box centre
    // is that far above the ground line.
    var _gy = _y + _h * BOR_STREET_GROUND;
    var _cy = _gy - BOR_GROUND * _s;

    // -- the backdrop ---------------------------------------------------------------------------
    bor_render_ramp(_x, _y, _w, _gy - _y,
                    [_pal.sky_hi, _pal.sky_lo], [1]);

    // -- the paving -----------------------------------------------------------------------------
    bor_render_vgrad(_x, _gy, _w, _y + _h - _gy, _pal.street2, _pal.street0);

    // Cobbles, thinning with distance from the viewer, drawn as short strokes rather than as a
    // grid: a grid reads as a floor tile and a scatter reads as stone.
    var _rows = 7;
    for (var _r = 0; _r < _rows; _r++) {
        var _t = (_r + 0.5) / _rows;
        var _cy2 = _gy + (_y + _h - _gy) * _t * _t;
        var _step = _w * (0.020 + 0.030 * _t);
        var _len = _step * 0.55;
        var _px = _x + _step * frac(_st.seed * 0.7548776662 + _r * 0.37);
        while (_px < _x + _w) {
            draw_set_colour((_r % 2 == 0) ? _pal.street1 : _pal.street3);
            draw_line_width(_px, _cy2, _px + _len, _cy2, max(BOR_MIN_STROKE, _w * 0.0016));
            _px += _step;
        }
    }

    // -- the buildings --------------------------------------------------------------------------
    // Walk left to right, advancing by each building's own extent, so they abut exactly. Their unit
    // boxes overlap, which is correct: a terrace is buildings sharing party walls.
    var _cx = _x;
    for (var _i = 0; _i < _n; _i++) {
        var _b = _row[_i];
        var _bw = (_b.xr - _b.xl) * _s;
        // The building's own centre inside its box is not the box centre - a lean-to pushes it to
        // one side - so place by the extent, not by the box.
        var _mid = (_b.xl + _b.xr) * 0.5;
        bor_building_draw_at(_b, _pal, _cx + _bw * 0.5 - _mid * _s, _cy, _s);
        _cx += _bw;
        // Once the row has covered the rect there is nothing to gain by composing more facades that
        // land entirely off the right edge - the count is a floor, and overshoot is normal.
        if (_cx > _x + _w) break;
    }
}

/// Draw a single building, centred in a rect, standing on a ground line, filling the frame.
///
/// This is the call for a catalogue cell and for a building shown on its own. It is separate from
/// bor_building_draw, which draws the facade with no setting at all.
///
/// ⛔ THE SCALE COMES FROM THE BUILDING'S MEASURED BOUNDS, NOT FROM THE UNIT BOX. MEASURED
/// 2026-08-28 by rendering the ageing sheet and looking at it: a one-storey cottage occupies about
/// a fifth of the unit box's height, so scaling by the box put six cottages in a thin band across a
/// sheet that was otherwise 60% black. The content check caught it at 21% of rows - correctly, and
/// the answer is more content in the frame, never a lower floor.
///
/// ⚠️ THIS IS THE OPPOSITE CHOICE FROM bor_street_draw, DELIBERATELY, AND THE REASON IS WORTH
/// STATING. A street MUST share one scale across every building, because relative height is how a
/// viewer reads prosperity off a row - a cottage beside a guildhall has to look small. A catalogue
/// cell has no neighbours to be relative to, so filling the cell is strictly better there. Two
/// callers, two rules, and the rule follows from what the picture is FOR.
function bor_street_draw_one(_b, _pal, _x, _y, _w, _h) {
    var _bb = bor_render_bounds(bor_building_parts(_b));
    var _bw = max(0.001, _bb[2] - _bb[0]);
    var _bh = max(0.001, _bb[3] - _bb[1]);
    // Leave a small margin so a chimney or an eave does not touch the cell edge - a form that
    // touches the frame reads as cropped even when it is not.
    // ⚠️ THE VERTICAL BUDGET IS THE SPACE ABOVE THE GROUND LINE, NOT THE WHOLE CELL. A building's
    // ink lies entirely above the line it stands on, so fitting _bh into _h and THEN standing the
    // result on a line at 80% of _h pushes the roof out of the top of the cell - which is the same
    // clipping defect this file already records for the street, arrived at from the other direction.
    // Fit into what is actually available and the two cannot disagree.
    var _gy = _y + _h * BOR_STREET_GROUND;
    var _avail = (_gy - _y) * 0.95;
    var _s = min(_w * 0.94 / _bw, _avail / _bh);
    var _mid = (_bb[0] + _bb[2]) * 0.5;
    // Stand the MEASURED bottom of the ink on the ground line, so a catalogue cell and a street row
    // read as the same world.
    var _cy = _gy - _bb[3] * _s;
    bor_building_draw_at(_b, _pal, _x + _w * 0.5 - _mid * _s, _cy, _s);
}

/// ============================================================================================
/// THE READOUT - the demo's own interface, drawn with the product's own relief
///
/// ⛔ THERE IS NO WINDOWSKIN AND NO NINE-SLICE IN THIS PACKAGE. The panel below is a rounded
/// outline handed to bor_ui_panel, lit by the same lamp as the buildings, and that is the whole
/// reason the demo does not look like a GameMaker default. Gate 1 for this wing is explicit that a
/// product must not look like the engine.
/// ============================================================================================
function bor_street_readout(_st, _pal, _x, _y, _w, _h) {
    bor_render_parts_raw(bor_map_roles(
        bor_ui_panel(_x, _y, _x + _w, _y + _h, min(_w, _h) * 0.16, min(_w, _h) * 0.10, "felt"),
        bor_material_map("stone")), _pal);

    // Light face over a dark shadow, never a material colour: this label sits on a panel whose
    // material changes with the settlement, so any colour derived from that material can and does
    // collide with it.
    var _px = min(_w, _h) * 0.30;
    bor_text_label(bor_settlement_label(_st), _x + _w * 0.06, _y + _h * 0.24,
                 _w * 0.88, _px, _pal.label_sh, _pal.label);
}
