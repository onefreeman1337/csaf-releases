{
  "$GMScript": "v1",
  "%Name": "bor_street",
  "isCompatibility": false,
  "isDnD": false,
  "name": "bor_street",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}