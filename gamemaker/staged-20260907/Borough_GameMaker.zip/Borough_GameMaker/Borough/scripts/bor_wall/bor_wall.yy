{
  "$GMScript": "v1",
  "%Name": "bor_wall",
  "isCompatibility": false,
  "isDnD": false,
  "name": "bor_wall",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}