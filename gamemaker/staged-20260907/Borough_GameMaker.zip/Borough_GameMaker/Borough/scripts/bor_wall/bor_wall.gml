/// BOROUGH - bor_wall. THE CORPUS IV: six wall treatments, and the weathering on them.
///
/// A wall is the largest area on the facade and therefore the thing that decides whether the
/// building reads as a material or as a fill. Six treatments, each carried by COUNT and LENGTH:
///
///   timberframe  studs, rails and braces, with render panels between them
///   rubble       irregular coursing, short stones, no two courses aligned
///   ashlar       regular deep courses with offset perpends, and quoins at the angles
///   brick        many fine courses and a projecting string course
///   render       a plain limewashed field, a plinth, and where the damp gets in
///   halfrender   render above a stone lower storey - the commonest real wall of all
///
/// ⛔ NOT ONE OF THEM IS A HATCH ACROSS THE WHOLE WALL. draw_line_width floors at 1.0 px with no
/// antialiasing on this hardware, so a wall covered edge to edge in fine lines is a grey blob with
/// a barcode on it - measured on this wing's own products, three times. Every treatment here draws
/// FEWER, SHORTER marks than the real material has, placed where the eye reads material from:
/// the corners, the openings, the plinth and the courses nearest the light.
///
/// ⚠️ AND EVERY MARK IS CLIPPED TO THE WALL IT BELONGS TO. A string course running past the corner
/// of the building is exactly the defect bor_clip_seg exists for, and a facade is where it happens.
/// ============================================================================================

/// The six wall treatments, in corpus order.
function bor_wall_names() {
    return ["timberframe", "rubble", "ashlar", "brick", "render", "halfrender"];
}

/// Which treatment a wall material implies.
///
/// halfrender is chosen rather than plain render when the settlement is old enough to have rebuilt
/// its ground floor in stone - which is what actually happened to most surviving medieval houses,
/// and which gives the whole street a horizontal band that reads as history.
function bor_wall_pick(_st) {
    switch (_st.wall_mat) {
        case "timber": return "timberframe";
        case "rubble": return "rubble";
        case "ashlar": return "ashlar";
        case "brick":  return "brick";
        case "render": return (_st.age > 0.45) ? "halfrender" : "render";
        case "cob":    return (_st.age > 0.60) ? "halfrender" : "render";
    }
    return "rubble";
}

/// A deterministic 0..1 from three integers. Used everywhere a stone needs to be a different size
/// from its neighbour without a per-frame random() making the wall shimmer.
function bor_wall_jitter(_seed, _a, _b) {
    return frac(abs(sin((_seed * 12.9898) + (_a * 78.233) + (_b * 37.719)) * 43758.5453));
}

/// ============================================================================================
/// THE TREATMENTS
///
/// _x0.._x1, _ytop.._ybot is the wall face. Everything returned is already in palette roles and
/// needs no further mapping.
/// ============================================================================================
function bor_wall_build(_treat, _x0, _ytop, _x1, _ybot, _st) {
    var _out = [];
    var _w = _x1 - _x0;
    var _h = _ybot - _ytop;
    if (_w <= 0.01 || _h <= 0.01) return _out;
    var _sd = _st.seed;

    switch (_treat) {

        case "ashlar": {
            // Deep regular courses. The PERPENDS (the short vertical joints) are offset course to
            // course and only two or three are drawn per course - that offset is what the eye reads
            // as coursed masonry, and drawing all of them turns the wall into graph paper.
            var _courses = max(3, round(_h / 0.038));
            for (var _i = 1; _i < _courses; _i++) {
                var _y = lerp(_ytop, _ybot, _i / _courses);
                array_push(_out, bor_poly([[_x0, _y], [_x1, _y]], false, 0.0045, "wall0"));
                var _np = 3;
                for (var _p = 0; _p < _np; _p++) {
                    var _t = (_p + 0.5 + ((_i % 2) * 0.5)) / _np;
                    var _px = lerp(_x0, _x1, _t);
                    if (_px <= _x0 || _px >= _x1) continue;
                    var _y2 = lerp(_ytop, _ybot, (_i + 1) / _courses);
                    array_push(_out, bor_poly([[_px, _y], [_px, min(_y2, _ybot)]],
                                              false, 0.0035, "wall0"));
                }
            }
            // Quoins: dressed stones alternating long-and-short up both angles. On a real building
            // this is the ONLY place the masonry is dressed, and it is the strongest "this is stone"
            // signal there is.
            for (var _k = -1; _k <= 1; _k += 2) {
                var _qx = (_k < 0) ? _x0 : _x1;
                var _nq = max(3, round(_h / 0.055));
                for (var _q = 0; _q < _nq; _q++) {
                    var _qy0 = lerp(_ytop, _ybot, _q / _nq);
                    var _qy1 = lerp(_ytop, _ybot, (_q + 1) / _nq);
                    var _long = ((_q % 2) == 0);
                    var _qw = _w * (_long ? 0.085 : 0.052);
                    bor_append(_out, bor_map_roles(
                        bor_raise(bor_box_pts(min(_qx, _qx + _k * _qw), _qy0 + _h * 0.004,
                                              max(_qx, _qx + _k * _qw), _qy1 - _h * 0.004),
                                  min(_qw, _qy1 - _qy0) * 0.16, 2, "stone3"),
                        bor_material_map("stone")));
                }
            }
        } break;

        case "rubble": {
            // Undressed field stone. Irregular, so the marks are SHORT SEGMENTS at jittered heights
            // rather than continuous courses - the absence of a through-line is the whole difference
            // between rubble and ashlar, and it is free.
            var _rows = max(4, round(_h / 0.028));
            for (var _i = 1; _i < _rows; _i++) {
                var _base = lerp(_ytop, _ybot, _i / _rows);
                var _n = max(2, round(_w / 0.045));
                var _px = _x0;
                for (var _s = 0; _s < _n; _s++) {
                    var _len = _w / _n * (0.55 + bor_wall_jitter(_sd, _i, _s) * 0.75);
                    var _dy = (bor_wall_jitter(_sd, _i, _s + 91) - 0.5) * _h * 0.012;
                    var _e = min(_px + _len, _x1);
                    if (_e - _px > _w * 0.02) {
                        array_push(_out, bor_poly([[_px, _base + _dy], [_e, _base + _dy]],
                                                  false, 0.004, "wall0"));
                    }
                    _px = _e + _w * 0.012;
                    if (_px >= _x1) break;
                }
            }
        } break;

        case "brick": {
            // Many fine courses, and ONLY in the lower two thirds where the eye actually resolves
            // them - the upper wall carries the string course instead. Drawing every course over
            // the whole wall is the barcode failure.
            var _courses = max(6, round(_h / 0.019));
            for (var _i = 1; _i < _courses; _i++) {
                var _t = _i / _courses;
                if (_t < 0.28) continue;
                var _y = lerp(_ytop, _ybot, _t);
                array_push(_out, bor_poly([[_x0, _y], [_x1, _y]], false, 0.003, "wall1"));
            }
            var _sy = lerp(_ytop, _ybot, 0.24);
            bor_append(_out, bor_map_roles(
                bor_raise(bor_box_pts(_x0 - _w * 0.012, _sy - _h * 0.012,
                                      _x1 + _w * 0.012, _sy + _h * 0.012),
                          _h * 0.008, 2, "stone3"), bor_material_map("stone")));
        } break;

        case "timberframe": {
            // Studs, a mid rail, and braces. The BRACE is the mark that identifies timber framing -
            // nothing else on a building runs diagonally - so it is drawn at every bay even though a
            // real frame braces only the end bays.
            var _bays = max(2, round(_w / 0.075));
            var _rail = lerp(_ytop, _ybot, 0.52);
            array_push(_out, bor_poly([[_x0, _rail], [_x1, _rail]], false, 0.011, "beam2"));
            array_push(_out, bor_poly([[_x0, _ytop], [_x1, _ytop]], false, 0.012, "beam2"));
            array_push(_out, bor_poly([[_x0, _ybot], [_x1, _ybot]], false, 0.013, "beam2"));
            for (var _i = 0; _i <= _bays; _i++) {
                var _px = lerp(_x0, _x1, _i / _bays);
                array_push(_out, bor_poly([[_px, _ytop], [_px, _ybot]], false, 0.010, "beam2"));
            }
            for (var _i = 0; _i < _bays; _i++) {
                var _a = lerp(_x0, _x1, _i / _bays);
                var _b = lerp(_x0, _x1, (_i + 1) / _bays);
                var _dir = ((_i % 2) == 0) ? 1 : -1;
                var _bx0 = (_dir > 0) ? _a : _b;
                var _bx1 = (_dir > 0) ? _b : _a;
                array_push(_out, bor_poly([[_bx0, _ybot], [_bx1, _rail]], false, 0.008, "beam1"));
            }
        } break;

        case "render": {
            // A plain field. What makes it read as lime render and not as a fill is the PLINTH at
            // the base - render never runs to the ground, because it would wick - and the damp
            // staining that gets in where it does.
            bor_append(_out, bor_map_roles(
                bor_raise(bor_box_pts(_x0 - _w * 0.014, _ybot - _h * 0.09,
                                      _x1 + _w * 0.014, _ybot), _h * 0.020, 2, "stone2"),
                bor_material_map("stone")));
        } break;

        case "halfrender": {
            // Render above, stone below. The BAND between them is the mark, and it must be a
            // projecting course rather than a colour change, or the wall reads as two flat fills
            // stacked - which is a palette swap wearing a hat.
            var _band = lerp(_ytop, _ybot, 0.56);
            bor_append(_out, bor_wall_build("rubble", _x0, _band, _x1, _ybot, _st));
            bor_append(_out, bor_map_roles(
                bor_raise(bor_box_pts(_x0 - _w * 0.020, _band - _h * 0.016,
                                      _x1 + _w * 0.020, _band + _h * 0.016),
                          _h * 0.011, 2, "stone3"), bor_material_map("stone")));
        } break;
    }

    return _out;
}

/// ============================================================================================
/// WEATHERING
///
/// The marks that say a building has stood for two hundred years and been through something.
/// Applied OVER the treatment, and driven by age and damage rather than authored.
///
/// ⚠️ EVERY ONE OF THESE IS AN AREA OR A SILHOUETTE CHANGE, NOT A TINT. A tint is what a palette
/// swap looks like, and this wing has a standing law that a difference must change area, spacing or
/// silhouette to be a difference at all.
/// ============================================================================================
function bor_wall_weather(_x0, _ytop, _x1, _ybot, _st) {
    var _out = [];
    var _w = _x1 - _x0;
    var _h = _ybot - _ytop;
    var _sd = _st.seed;

    // MOSS AND DAMP rise from the ground and spread with age. A ragged band of TUFTS along the
    // base, each a filled tapered quad of its own height - the raggedness is the whole read, and a
    // uniform band at the bottom would look like a skirting board.
    //
    // ⛔ THIS WAS A ROW OF HAIRLINE STROKES UNTIL 2026-08-28 AND IT HAD NEVER ONCE BEEN VISIBLE.
    // The store sheet captioned "THE WALL GREENS FROM THE GROUND UP" showed six cottages ageing
    // three hundred years with no green anywhere on any of them, and the caption was therefore a
    // claim the product did not deliver. Two independent causes, and this wing had already paid for
    // BOTH of them on earlier products:
    //
    //   1. TONE IS AREA, NOT LINE WIDTH. `draw_line_width` floors every stroke at 1px on this
    //      hardware with no antialiasing, so a 0.006-unit stroke is a hairline at any size a buyer
    //      will ever see. The wing's own doctrine states it three times over ("lead with large
    //      filled masses; thin strokes are the measured failure") and this product reintroduced it.
    //      A tuft is now a FILLED QUAD, so the mark has area and survives the quantisation.
    //   2. A DESATURATED GREEN ON A WARM WALL IS NOT GREEN, IT IS GREY. `_pal.moss` sat at C=0.055,
    //      which against cob or render at a similar lightness carries no hue signal at all. Moss on
    //      a shaded wall base is genuinely one of the most saturated things on a building.
    //
    // ⚠️ THE TUFTS ARE CONVEX QUADS, DELIBERATELY, AND ARE NEVER ONE COMB-SHAPED OUTLINE. A ragged
    // band authored as a single polygon is concave at every notch, and this package fills through a
    // triangle fan whose documented precondition is a star-shaped outline - a fan hands back a
    // silently WRONG picture there rather than an error, which is the defect a sibling product in
    // this wing shipped on every one of its moon phases.
    if (_st.age > 0.20) {
        var _n = max(4, round(_w / 0.020));
        var _amt = (_st.age - 0.20) / 0.80;
        // Bases overlap slightly so the band is continuous at the ground and ragged at the top,
        // which is how moss actually sits: a solid wet foot with a broken upper edge.
        var _hw = (_w / _n) * 0.62;
        for (var _i = 0; _i < _n; _i++) {
            var _px = lerp(_x0, _x1, (_i + 0.5) / _n);
            var _len = _h * (0.02 + 0.16 * _amt * bor_wall_jitter(_sd, 3, _i));
            var _tw = _hw * (0.55 + 0.45 * bor_wall_jitter(_sd, 11, _i));
            array_push(_out, bor_fill([[_px - _tw, _ybot],
                                       [_px + _tw, _ybot],
                                       [_px + _tw * 0.42, _ybot - _len],
                                       [_px - _tw * 0.42, _ybot - _len]], "moss"));
        }
    }

    // SOOT streaks DOWN from the eaves and from window heads, because that is where rain carries it.
    // Damage drives it, so a burnt or besieged town blackens from the top - the opposite direction
    // from moss, which is what makes the two read as different things rather than as "more dirt".
    if (_st.damage > 0.18) {
        var _n = max(3, round(_w / 0.055));
        var _amt = (_st.damage - 0.18) / 0.82;
        for (var _i = 0; _i < _n; _i++) {
            var _px = lerp(_x0 + _w * 0.05, _x1 - _w * 0.05, (_i + 0.5) / _n);
            var _len = _h * (0.10 + 0.55 * _amt * bor_wall_jitter(_sd, 7, _i));
            array_push(_out, bor_poly([[_px, _ytop], [_px, _ytop + _len]], false,
                                      _w * 0.022, "soot"));
        }
    }

    // A COLLAPSED BAY at high damage: the wall itself is gone at one end. This is the only
    // weathering that changes the SILHOUETTE, and it is the one that makes a ruined town read as
    // ruined rather than as dirty.
    if (_st.damage > 0.62) {
        // ⛔ A STRIP, NOT A FAN, AND THE REASON IS THE WHOLE POINT OF THE BREAK LINE.
        // A collapse edge is RAGGED, which means concave, which means bor_ring_fill would span its
        // own notches in silence and hand back a smooth wedge - a break line with no break in it.
        // Two rails sampled from ONE sweep are exact where a fan is not, and cost the same. This is
        // the same fix this wing recorded for a crescent that had been shipping as a quarter.
        var _side = ((_sd & 4) == 0) ? -1 : 1;
        var _bx = (_side < 0) ? _x0 : _x1;
        var _bw = _w * 0.24 * ((_st.damage - 0.62) / 0.38);
        var _steps = 9;
        var _rag = array_create(_steps + 1);
        var _edge = array_create(_steps + 1);
        for (var _i = 0; _i <= _steps; _i++) {
            var _t = _i / _steps;
            // The break widens as it climbs: a wall falls from the top down, so the gap is widest
            // at the eaves and closes toward the ground. Multiplying the jitter by t does that and
            // guarantees the two rails MEET at the bottom, so the wedge has no end wall.
            var _jx = _bw * _t * (0.35 + 0.65 * bor_wall_jitter(_sd, 11, _i));
            var _y = lerp(_ybot, _ytop, _t);
            _rag[_i]  = [_bx, _y];
            _edge[_i] = [_bx - _side * _jx, _y];
        }
        array_push(_out, bor_strip(_rag, _edge, "shadow"));
    }

    return _out;
}
