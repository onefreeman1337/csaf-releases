/// BOROUGH - bor_roof. THE CORPUS II: ten roof forms.
///
/// ⛔ THE ROOF IS ITS OWN MASS, NEVER A TRIANGLE STUCK ON A BOX. The eaves OVERHANG the wall, and
/// the shadow that overhang throws on the wall beneath it is most of what says "building" rather
/// than "rectangle". A roof drawn flush with the wall is the single most common tell of generated
/// architecture and it is one line of arithmetic to avoid.
///
/// -- THE TWO ORIENTATIONS ----------------------------------------------------------------------
/// A front elevation sees a roof in one of two completely different ways, and this is a SILHOUETTE
/// difference, which is why bor_settlement makes it regional rather than decorative:
///
///   GABLE FRONT  the ridge runs away from the street, so the street sees the gable END: a full
///                triangle (or a stepped, hipped or gambrelled version of one) as tall as the
///                pitch times the frontage. Upland and alpine towns build this way because the
///                plot is narrow and the snow must shed sideways off the neighbours.
///   EAVES FRONT  the ridge runs ALONG the street, so the street sees the eaves and a shallow band
///                of roof plane above them, with the ridge as a line near the top. Much lower, much
///                wider, and it makes a terrace read as continuous.
///
/// ⛔ A STEPPED GABLE IS CONCAVE AND IS NEVER ONE OUTLINE. It is a stack of convex boxes here, for
/// the reason bor_massing's header sets out at length: a fan spans a concavity in silence. The same
/// applies to a battlemented parapet, which is the same shape lying down.
/// ============================================================================================

/// The ten roof forms, in corpus order.
function bor_roof_names() {
    return ["gable", "hip", "halfhip", "gambrel", "mansard", "catslide",
            "monopitch", "parapet", "conical", "stepped"];
}

/// Which roof this building wears, in this settlement.
///
/// ⚠️ ROLE FIRST, THEN REGION. A watchtower is conical wherever it stands; a cottage's roof is
/// whatever the region does. Region-first would give every southern town ten identical parapets and
/// throw away nine of the ten forms - the volume IS the product.
function bor_roof_pick(_role, _st) {
    switch (_role) {
        case "watchtower": return "conical";
        case "mill":       return "conical";
        case "smithy":     return "monopitch";
        case "gatehouse":  return "parapet";
        case "warehouse":  return (_st.prosperity > 0.60) ? "mansard" : "gable";
        case "tenement":   return (_st.prosperity > 0.55) ? "mansard" : "gable";
        case "inn":        return "gambrel";
        case "longhouse":  return "halfhip";
        case "granary":    return "hip";
        case "guildhall":  return (_st.wealth >= 3) ? "hip" : "gable";
        case "chapel":     return (_st.wealth >= 3) ? "stepped" : "gable";
        case "cottage":    return (_st.age > 0.55) ? "catslide" : "gable";
    }
    if (_st.parapet) return "parapet";
    return "gable";
}

/// ⛔ HOW MUCH ROOF AN EAVES-FRONT ELEVATION SHOWS, AS A FRACTION OF THE FULL GABLE HEIGHT.
///
/// THIS NUMBER IS COMPUTED IN TWO PLACES AND THEY MUST NOT DRIFT: bor_massing reserves headroom for
/// the roof before it solves the storey height, and bor_roof_build then draws into that reservation.
/// If the two disagree, either the roof clips out of the unit box or a band of the box is reserved
/// for nothing. So both call THIS, and neither owns the constant.
///
/// ⚠️ IT WAS 0.46 AND THE ROOFS READ AS STRIPES. MEASURED 2026-08-28 by rendering the hero sheet and
/// looking at it: a three-storey townhouse showed a roof one eighth the height of its wall, which is
/// the "roof as a coloured band on top of a box" failure this file's header warns about in its first
/// paragraph. A real front elevation of an eaves-front building shows a substantial plane.
function bor_roof_band_factor() { return 0.85; }

/// How far the eaves project past the wall, as a fraction of the half-width.
///
/// ⚠️ A THATCHED ROOF OVERHANGS FAR MORE THAN A TILED ONE, because thatch has no gutter and must
/// throw water clear of a cob wall that would dissolve. This is one number and it changes the whole
/// character of a poor village against a rich town without touching a colour.
function bor_roof_overhang(_st) {
    if (_st.roof_mat == "thatch") return 0.150;
    if (_st.roof_mat == "slate")  return 0.070;
    return 0.090;
}

/// ============================================================================================
/// THE BUILDER
///
/// Returns { masses, ridge, eave, apex_x } where masses is an array of convex outlines in the
/// roof's own material, ridge is the y of the highest point and eave the y of the eaves line.
/// ============================================================================================
function bor_roof_build(_form, _x0, _x1, _yeave, _st, _gable_front) {
    var _hw = (_x1 - _x0) * 0.5;
    var _cx = (_x0 + _x1) * 0.5;
    var _ov = _hw * bor_roof_overhang(_st);
    var _ex0 = _x0 - _ov, _ex1 = _x1 + _ov;

    // Age SAGS a roof. A sagging ridge is the strongest single reading of age on a building and it
    // costs one term: the ridge drops and the eaves stay, so the roof line dishes.
    var _sag = _st.age * _hw * 0.075;

    var _pitch = _st.pitch;
    // ⚠️ THE RIDGE HEIGHT COMES FROM THE WALL SPAN, NOT THE OVERHUNG SPAN. The eaves project past
    // the wall and the ridge does not care: a roof's height is set by the distance between the walls
    // it spans. Using the overhung width inflated every thatched roof by 15% - and thatch has the
    // biggest overhang precisely because it is the poorest roof, so the error was largest exactly
    // where it was least wanted, on the one-storey cottages.
    var _full  = _pitch * (_x1 - _x0) * 0.5;     // full gable height at this pitch
    var _band  = _full * bor_roof_band_factor();  // what an eaves-front elevation actually shows

    var _masses = [];
    var _ridge = _yeave;

    if (_form == "parapet") {
        // A parapet hides the roof completely: what the street sees is the WALL carried up, with a
        // coping. Battlemented for a gatehouse, plain otherwise - and the battlement is a stack of
        // convex merlons, never one crenellated outline.
        var _ph = _hw * 0.19;
        _ridge = _yeave - _ph;
        array_push(_masses, { pts: bor_box_pts(_ex0, _yeave - _ph * 0.62, _ex1, _yeave),
                              kind: "roof", mat: "roof" });
        // The coping course, proud of the parapet on both sides.
        array_push(_masses, { pts: bor_box_pts(_ex0 - _ov * 0.35, _ridge, _ex1 + _ov * 0.35,
                                               _yeave - _ph * 0.62), kind: "coping", mat: "stone" });
        return { masses: _masses, ridge: _ridge, eave: _yeave, apex_x: _cx, form: _form };
    }

    if (_form == "conical") {
        // ⛔ A BROACH SPIRE IS TWO CONVEX MASSES, NOT ONE BOWED OUTLINE.
        //
        // The first version sampled a sine-warped profile and asserted in its own comment that
        // bowing inward "keeps the outline convex". It does not, and the convexity assertion caught
        // it: warping x by one function while moving y by another gives no guarantee at all, and the
        // curve went concave part way up. A claim about a shape is not a proof of it.
        //
        // A real broach spire IS two things - a squat splayed broach at the base carrying an
        // octagonal spire above it - so the decomposition is the construction, exactly as with the
        // crow-stepped gable. Both parts are convex by inspection: a trapezoid and a triangle.
        var _h = _full * 1.30;
        _ridge = _yeave - _h;
        var _bx = _hw * 0.62;
        var _by = _yeave - _h * 0.24;
        array_push(_masses, {
            pts: [[_ex0, _yeave], [_cx - _bx, _by], [_cx + _bx, _by], [_ex1, _yeave]],
            kind: "roof", mat: "roof",
        });
        array_push(_masses, {
            pts: [[_cx - _bx, _by], [_cx, _ridge + _sag * 0.4], [_cx + _bx, _by]],
            kind: "roof", mat: "roof",
        });
        return { masses: _masses, ridge: _ridge, eave: _yeave, apex_x: _cx, form: _form };
    }

    if (!_gable_front && _form != "stepped" && _form != "monopitch" && _form != "catslide") {
        // -- EAVES FRONT: a shallow band of roof plane, plus the ridge above it. -----------------
        // The band is a TRAPEZOID, not a rectangle: the far edge of a pitched plane is foreshortened
        // and its ends step in. A rectangle here is the "roof as a stripe" look, which reads as a
        // stripe.
        _ridge = _yeave - _band + _sag * 0.5;
        var _inset = (_form == "hip" || _form == "halfhip") ? _hw * 0.30 : _hw * 0.06;
        array_push(_masses, {
            pts: [[_ex0 + _inset, _ridge], [_ex1 - _inset, _ridge], [_ex1, _yeave], [_ex0, _yeave]],
            kind: "roof", mat: "roof",
        });
        return { masses: _masses, ridge: _ridge, eave: _yeave, apex_x: _cx, form: _form };
    }

    // -- GABLE FRONT and the forms that always show their profile -------------------------------
    switch (_form) {
        case "gable": {
            _ridge = _yeave - _full;
            array_push(_masses, { pts: [[_ex0, _yeave], [_cx, _ridge + _sag], [_ex1, _yeave]],
                                  kind: "roof", mat: "roof" });
        } break;

        // ⛔ THE FIVE PITCHED FORMS BELOW WERE MEASURED READING AS ONE ROOF. 2026-08-28, by
        // rendering the roof sheet and looking at it: gable, hip, halfhip, gambrel and mansard were
        // all "a low triangle with a slightly different top" and a buyer could not have told them
        // apart. That is this wing's Charter failure exactly - shipping a distinction the customer
        // cannot perceive - and no assertion catches it, because every one of them IS a different
        // polygon. The numbers below are widened so the DIFFERENCE is legible, not merely present:
        // a hip has a SHORT ridge, a mansard has a WIDE flat top, a gambrel has an obvious knuckle,
        // a jerkin head has a visible chamfer. Convexity is preserved in each - the assertion holds.
        case "hip": {
            // All four planes slope, so the gable end is a TRAPEZOID with a SHORT ridge. Short is
            // the whole tell against the mansard below, so it is short.
            _ridge = _yeave - _full * 0.90;
            array_push(_masses, {
                pts: [[_ex0, _yeave], [_cx - _hw * 0.16, _ridge + _sag],
                      [_cx + _hw * 0.16, _ridge + _sag], [_ex1, _yeave]],
                kind: "roof", mat: "roof",
            });
        } break;

        case "halfhip": {
            // A gable that is hipped only at the top - a "jerkin head".
            //
            // ⛔ THE HIP MUST BE SHALLOWER THAN THE MAIN SLOPE, AND THE FIRST VERSION HAD IT
            // STEEPER. Caught by the convexity assertion, not by looking: a profile that rises at
            // one slope, then at a STEEPER one, then goes flat is concave by definition, and a fan
            // would have spanned the notch in silence. It is also wrong as architecture - the hipped
            // end of a jerkin head lies back at a shallower angle than the verge it cuts, which is
            // why the shape exists at all. Getting the geometry right and getting the picture right
            // were the same edit.
            // The chamfer is deliberately LARGE: a jerkin head whose cut is subtle is a gable, and
            // the corpus already has a gable.
            _ridge = _yeave - _full;
            var _kx = _hw * 0.30, _ky = _full * 0.22;
            array_push(_masses, {
                pts: [[_ex0, _yeave], [_cx - _hw * 0.55, _ridge + _ky + _sag],
                      [_cx - _kx, _ridge + _sag], [_cx + _kx, _ridge + _sag],
                      [_cx + _hw * 0.55, _ridge + _ky + _sag], [_ex1, _yeave]],
                kind: "roof", mat: "roof",
            });
        } break;

        case "gambrel": {
            // Two pitches per side, the lower steep and the upper shallow. Convex, and the extra
            // volume it buys in the attic is the historical reason for it - which is why it lands
            // on the inn, the building that needs rooms.
            // ⛔ THE LOWER SLOPE IS THE STEEP ONE. The first version broke at 0.52 of the half width
            // and 0.52 of the height, which makes the UPPER slope steeper - an inverted gambrel,
            // concave, and caught by the convexity assertion rather than by eye. The break belongs
            // near the eaves: a short steep run, then a long shallow one to the ridge. That is what
            // buys the attic volume the shape exists for, and it is why the inn wears it.
            _ridge = _yeave - _full * 1.02;
            var _bx = _hw * 0.72, _by = _full * 0.62;
            array_push(_masses, {
                pts: [[_ex0, _yeave], [_cx - _bx, _yeave - _by], [_cx, _ridge + _sag],
                      [_cx + _bx, _yeave - _by], [_ex1, _yeave]],
                kind: "roof", mat: "roof",
            });
        } break;

        case "mansard": {
            // Steep lower slope, near-flat top, dormers in the steep part. The classic way to add
            // a storey without adding a storey, so it lands on prosperity.
            // A WIDE flat top over a STEEP lower slope - the opposite proportions from the hip, so
            // the two cannot be confused at a glance. That is also what a mansard is for: the flat
            // deck is unusable roof traded away to make the storey beneath it habitable.
            _ridge = _yeave - _full * 0.78;
            var _mx = _hw * 0.58;
            array_push(_masses, {
                pts: [[_ex0, _yeave], [_cx - _mx, _ridge + _sag],
                      [_cx + _mx, _ridge + _sag], [_ex1, _yeave]],
                kind: "roof", mat: "roof",
            });
        } break;

        case "catslide": {
            // ONE plane running from a high ridge down past the eaves of an outshut to a very low
            // eave on one side. Asymmetric, which is the whole point: it is what happens when a
            // lean-to gets roofed in with the main range rather than beside it.
            //
            // ⛔ THE LOW EAVE'S DROP IS A FRACTION OF THE WALL, NOT OF THE HALF-WIDTH. This was
            // `_yeave + _hw * 0.34` until 2026-08-28 and it buried the front of every aged cottage
            // in the product. MEASURED by cropping the ageing sheet at 240 years and enlarging it:
            // the long slope crossed the facade diagonally, ran past the wall's left edge into open
            // air, and came down below the window heads - it read as a tent thrown over the house,
            // or as a rendering fault, never as a roof.
            //
            // The cause is EXACTLY the cause of the eaves-shadow defect fixed in bor_building the
            // same day, and finding it twice in one product is the reason it is written up here as
            // a rule rather than as a number: A VERTICAL DIMENSION DERIVED FROM A HORIZONTAL ONE IS
            // A BUG WAITING FOR A WIDE SHAPE. A cottage is the widest and lowest thing in the
            // corpus, so 0.34 of its half-width came to about 64% of its wall height, while on the
            // tall narrow stub the roof CATALOGUE sheet draws it came to a perfectly reasonable
            // 26% - which is why every catalogue render of this form looked fine and every real
            // building using it did not. Driving the drop from the wall makes the two agree by
            // construction.
            //
            // ⚠️ AND NO ASSERTION COULD HAVE CAUGHT IT: a triangle is convex and simple whatever its
            // vertices are, so the geometry suite was right to pass it. The defect is entirely in
            // where the third point sits relative to a DIFFERENT mass, which the roof builder cannot
            // see and the outline tests do not model.
            var _side = ((_st.seed & 2) == 0) ? -1 : 1;
            _ridge = _yeave - _full;
            var _rx = _cx - _side * _hw * 0.30;
            var _wallh = max(0.001, BOR_GROUND - _yeave);
            var _lowy = _yeave + _wallh * 0.26;
            // The long slope reaches FURTHER out than the short one - that asymmetry is the form,
            // and the old numbers threw both sides out equally, which is a wide gable, not a
            // catslide.
            array_push(_masses, {
                pts: [[_cx - _side * (_hw + _ov), _yeave],
                      [_rx, _ridge + _sag],
                      [_cx + _side * (_hw + _ov + _hw * 0.10), _lowy]],
                kind: "roof", mat: "roof",
            });
        } break;

        case "monopitch": {
            // A single slope. Quadrilateral, convex.
            _ridge = _yeave - _full * 0.72;
            array_push(_masses, {
                pts: [[_ex0, _ridge + _sag], [_ex1, _yeave - _full * 0.10],
                      [_ex1, _yeave], [_ex0, _yeave]],
                kind: "roof", mat: "roof",
            });
        } break;

        case "stepped": {
            // ⛔ A CROW-STEPPED GABLE IS CONCAVE AND IS BUILT AS A STACK OF CONVEX BOXES.
            // Six steps a side. Each box is its own mass, its own bevel and its own shadow, which
            // is also how it is built in stone - so the decomposition is not a workaround, it is
            // the construction.
            var _steps = 6;
            _ridge = _yeave - _full;
            for (var _i = 0; _i < _steps; _i++) {
                var _t0 = _i / _steps;
                var _t1 = (_i + 1) / _steps;
                var _w0 = lerp(_hw + _ov, _hw * 0.12, _t0);
                var _y0 = lerp(_yeave, _ridge + _sag, _t1);
                var _y1 = lerp(_yeave, _ridge + _sag, _t0);
                array_push(_masses, {
                    pts: bor_box_pts(_cx - _w0, _y0, _cx + _w0, _y1),
                    kind: "roof", mat: "roof",
                });
            }
        } break;

        default: {
            _ridge = _yeave - _full;
            array_push(_masses, { pts: [[_ex0, _yeave], [_cx, _ridge + _sag], [_ex1, _yeave]],
                                  kind: "roof", mat: "roof" });
        } break;
    }

    return { masses: _masses, ridge: _ridge, eave: _yeave, apex_x: _cx, form: _form };
}

/// ============================================================================================
/// SURFACE: the courses that make a roof read as slate, tile or thatch
///
/// ⛔ CARRIED BY COUNT AND LENGTH, NEVER BY STROKE WEIGHT. draw_line_width floors at 1.0 px with no
/// antialiasing on this hardware, so a "lighter" course line is not lighter, it is dashed. Slate
/// gets MANY courses, tile gets FEWER and DEEPER, thatch gets none at all and a rounded ridge
/// instead - which is exactly the real difference between the three materials.
/// ============================================================================================
/// ⛔ THE HORIZONTAL SPAN OF AN OUTLINE AT ONE HEIGHT. A SCANLINE, BECAUSE ARITHMETIC WAS WRONG.
///
/// MEASURED 2026-08-28 by rendering the corpus sheet and looking at it. The first version drew each
/// course across the WALL span at a y between ridge and eave - which is correct only for a rectangle
/// and is wrong for every one of the ten roof forms. On the smithy's monopitch the courses ran out
/// into open sky beside the roof; on the cottage and longhouse they projected past the verge as
/// horizontal lines attached to nothing.
///
/// The shortening term that was supposed to hide this ("courses shorten toward the ridge") is a
/// SYMMETRIC approximation, so it cannot be right for an asymmetric form at all, and it was tuned
/// rather than derived. Intersecting the actual outline is exact for every form in the corpus -
/// triangle, trapezoid, pentagon, cone, and the stepped gable's stack of boxes - and it needs no
/// per-form knowledge, so a new roof form cannot re-open this.
///
/// Returns [x0, x1] or undefined when the line misses the shape entirely.
function bor_roof_span_at(_pts, _y) {
    var _n = array_length(_pts);
    if (_n < 3) return undefined;
    var _lo = 99999, _hi = -99999, _hits = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _pts[_i];
        var _b = _pts[(_i + 1) % _n];
        var _ay = _a[1], _by = _b[1];
        // Half-open in y so a vertex shared by two edges is counted once, not twice or zero times.
        if ((_ay <= _y && _by > _y) || (_by <= _y && _ay > _y)) {
            var _t = (_y - _ay) / (_by - _ay);
            var _x = _a[0] + (_b[0] - _a[0]) * _t;
            if (_x < _lo) _lo = _x;
            if (_x > _hi) _hi = _x;
            _hits++;
        }
    }
    if (_hits < 2) return undefined;
    return [_lo, _hi];
}

/// The TOP edge of an outline at one column - the transpose of bor_roof_span_at, and needed for the
/// same reason: anything that hugs a roof must hug the roof that is actually there.
///
/// _ymin/_ymax bound the search so a miss returns the eave rather than a sentinel that would draw a
/// line off the top of the world.
function bor_outline_top_at(_pts, _x, _ymin, _ymax) {
    var _n = array_length(_pts);
    var _best = _ymax;
    var _hit = false;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _pts[_i];
        var _b = _pts[(_i + 1) % _n];
        var _ax = _a[0], _bx = _b[0];
        if ((_ax <= _x && _bx > _x) || (_bx <= _x && _ax > _x)) {
            var _t = (_x - _ax) / (_bx - _ax);
            var _y = _a[1] + (_b[1] - _a[1]) * _t;
            if (!_hit || _y < _best) { _best = _y; _hit = true; }
        }
    }
    return _hit ? _best : _ymax;
}

function bor_roof_surface(_r, _x0, _x1, _st) {
    var _out = [];
    var _mat = _st.roof_mat;
    if (_r.form == "parapet") return _out;

    var _top = _r.ridge, _bot = _r.eave;
    var _h = _bot - _top;
    if (_h <= 0.001) return _out;

    if (_mat == "thatch") {
        // Thatch has no courses. It has a THICK ROUNDED RIDGE and a soft eave, and the ridge is what
        // identifies it at any size - so that is what gets drawn.
        //
        // ⚠️ IT FOLLOWS THE ROOF'S OWN TOP EDGE, not an assumed gable profile. The first version
        // computed the ridge as "eave at both ends, apex in the middle", which is true of a gable
        // seen end-on and false of every eaves-front trapezoid, every monopitch and every catslide -
        // so the thatch ridge floated off the roof on more than half the corpus.
        if (array_length(_r.masses) < 1) return _out;
        var _face2 = _r.masses[0].pts;
        var _bb = bor_render_bounds([bor_fill(_face2, "m2")]);
        var _n = 24;
        var _a = array_create(_n + 1), _b = array_create(_n + 1);
        for (var _i = 0; _i <= _n; _i++) {
            var _px = lerp(_bb[0], _bb[2], _i / _n);
            var _py = bor_outline_top_at(_face2, _px, _bb[1], _bb[3]);
            _a[_i] = [_px, _py];
            _b[_i] = [_px, _py + _h * 0.15];
        }
        array_push(_out, bor_strip(_a, _b, "roof4"));
        return _out;
    }

    // Courses are laid on the FIRST roof mass, which is the plane the street sees. A stepped gable
    // is a stack of boxes and gets none: its steps ARE its texture, and coursing them makes mud.
    if (_r.form == "stepped" || array_length(_r.masses) < 1) return _out;
    var _face = _r.masses[0].pts;

    var _courses = (_mat == "slate") ? 11 : 6;
    for (var _i = 1; _i < _courses; _i++) {
        var _t = _i / _courses;
        var _y = lerp(_top, _bot, _t);
        var _span = bor_roof_span_at(_face, _y);
        if (is_undefined(_span)) continue;
        // Inset from the verge by a little, so a course stops short of the edge the way a tile
        // course does under a barge board rather than running out to a point.
        var _pad = (_span[1] - _span[0]) * 0.06;
        if ((_span[1] - _span[0]) <= _pad * 2.5) continue;
        array_push(_out, bor_poly([[_span[0] + _pad, _y], [_span[1] - _pad, _y]],
                                  false, 0.004, "roof0"));
    }
    return _out;
}
