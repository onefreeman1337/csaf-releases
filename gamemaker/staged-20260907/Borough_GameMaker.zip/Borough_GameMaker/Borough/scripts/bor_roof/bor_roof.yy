{
  "$GMScript": "v1",
  "%Name": "bor_roof",
  "isCompatibility": false,
  "isDnD": false,
  "name": "bor_roof",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}