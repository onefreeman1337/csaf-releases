/// BOROUGH - bor_massing. THE CORPUS I: fourteen building roles, as solved masses.
///
/// A building is not one shape. It is two or three MASSES that meet - a main block, a lean-to, a
/// stair turret, a chimney stack - and the reason a generated town usually reads as boxes is that
/// it draws one rectangle per building and puts a triangle on it.
///
/// ⛔ EVERY MASS EMITTED BY THIS FILE IS CONVEX, AND THAT IS A CONTRACT, NOT AN ACCIDENT.
///
/// bor_raise / bor_sink / bor_ring_fill fill through a TRIANGLE FAN, whose documented precondition
/// is that the outline is star-shaped about its first point. Hand a fan a concave shape and it
/// spans the concavity silently: no error, no failed assertion, wrong picture. This wing shipped
/// every moon crescent in a previous product as a quarter for exactly this reason, on a store sheet
/// captioned with the geometry it was getting wrong.
///
/// An L-plan building, a catslide, a carriage arch and a gatehouse are all concave. So none of them
/// is ONE mass here. They are two or three convex masses that touch - which is also what they are
/// in life: a lean-to has its own roof, its own eaves line and its own shadow, and drawing it as a
/// notch cut out of the main block is what makes it look like a sticker.
///
/// bor_selftest asserts convexity on every mass of every role, at several settlement states. That
/// assertion is the only instrument that can see this defect, because the picture cannot be tested.
///
/// -- SIZING: SOLVED, NEVER TUNED ---------------------------------------------------------------
/// The storey height is SOLVED from the space left after the roof, so a four-storey tenement under
/// a steep alpine pitch cannot clip out of the unit box however the state moves. The wing's own
/// finding: a flat panel close to the page colour running off the bottom of a sheet was reported
/// `ok` by every mechanical check there is, and the fix was to solve the dimension rather than
/// choose it. Same law, applied before the defect instead of after it.
/// ============================================================================================

/// The top of the unit box that a building may occupy. Not -0.5: the ridge needs somewhere to cast
/// its shadow, and a form that touches the frame reads as cropped even when it is not.
#macro BOR_SKYLINE -0.455

/// The tallest a single storey is allowed to be. Storeys shrink below this when a tall building
/// runs out of box; they never grow above it, or a one-storey cottage becomes a barn door.
#macro BOR_STOREY_MAX 0.150

/// The fourteen roles, in corpus order.
function bor_role_names() {
    return ["cottage", "townhouse", "longhouse", "shopfront", "inn", "smithy", "mill",
            "granary", "warehouse", "chapel", "guildhall", "gatehouse", "watchtower", "tenement"];
}

/// Per-role shape constants.
///
///   halfw    half width of the main block in unit space - the frontage
///   storeys  base storey count before prosperity moves it
///   grow     how many storeys prosperity can ADD (a cottage never becomes a tower)
///   wing     "none" | "lean" | "gable" | "turret" | "stack" | "twin" | "raised" | "arcade"
///   slim     the main block is narrower than the plot, leaving a gap to its neighbour
function bor_role_spec(_role) {
    switch (_role) {
        // ⚠️ cottage and smithy were MEASURED at a silhouette distance of 0.0148 against a floor of
        // 0.020 - two one-storey boxes of almost the same frontage. The fix is not to move the
        // floor. A smithy is a chimney with a shed attached: it is wider, lower and its stack runs
        // well above the ridge, so it is authored as that and the pair separates on shape.
        case "cottage":    return { halfw: 0.265, storeys: 1, grow: 0, wing: "lean",   slim: 0.00 };
        case "townhouse":  return { halfw: 0.215, storeys: 2, grow: 1, wing: "none",   slim: 0.00 };
        case "longhouse":  return { halfw: 0.430, storeys: 1, grow: 0, wing: "lean",   slim: 0.00 };
        case "shopfront":  return { halfw: 0.290, storeys: 2, grow: 1, wing: "none",   slim: 0.00 };
        case "inn":        return { halfw: 0.330, storeys: 2, grow: 1, wing: "gable",  slim: 0.00 };
        case "smithy":     return { halfw: 0.375, storeys: 1, grow: 0, wing: "stack",  slim: 0.00 };
        case "mill":       return { halfw: 0.170, storeys: 3, grow: 1, wing: "lean",   slim: 0.06 };
        case "granary":    return { halfw: 0.270, storeys: 1, grow: 0, wing: "raised", slim: 0.04 };
        case "warehouse":  return { halfw: 0.360, storeys: 3, grow: 1, wing: "none",   slim: 0.00 };
        case "chapel":     return { halfw: 0.300, storeys: 2, grow: 0, wing: "turret", slim: 0.00 };
        case "guildhall":  return { halfw: 0.375, storeys: 2, grow: 1, wing: "arcade", slim: 0.00 };
        case "gatehouse":  return { halfw: 0.390, storeys: 2, grow: 1, wing: "twin",   slim: 0.00 };
        case "watchtower": return { halfw: 0.165, storeys: 4, grow: 1, wing: "none",   slim: 0.09 };
        case "tenement":   return { halfw: 0.200, storeys: 3, grow: 1, wing: "none",   slim: 0.00 };
    }
    return { halfw: 0.280, storeys: 1, grow: 0, wing: "none", slim: 0.00 };
}

/// How many storeys this role stands at, in this settlement.
///
/// Prosperity buys HEIGHT in a walled town, because the plot cannot get wider - which is the real
/// reason medieval towns grew upward, and it is the single clearest visual reading of the state
/// model on a street.
function bor_massing_storeys(_role, _st) {
    var _s = bor_role_spec(_role);
    var _extra = floor(clamp(_st.prosperity, 0, 1) * (_s.grow + 0.99));
    return _s.storeys + min(_s.grow, _extra);
}

/// A closed, convex, axis-aligned box as an outline, wound consistently.
///
/// ⚠️ Points are listed so that bor_area2 has a consistent sign for every mass in the corpus.
/// bor_relief measures the winding rather than requiring one, so this is not load-bearing for the
/// shading - but the self-test's total-turning assertion is much easier to read when every mass in
/// the product turns the same way.
function bor_box_pts(_x0, _ytop, _x1, _ybot) {
    return [[_x0, _ytop], [_x1, _ytop], [_x1, _ybot], [_x0, _ybot]];
}

/// A box whose top edge is a single slope - a lean-to, or a monopitch.
function bor_slope_box_pts(_x0, _y0, _x1, _y1, _ybot) {
    return [[_x0, _y0], [_x1, _y1], [_x1, _ybot], [_x0, _ybot]];
}

/// A box that tapers - wider at the base than the top, or the reverse. A batter on a tower base is
/// one of the few marks that says "defensive" without any ornament at all.
function bor_taper_box_pts(_xt0, _xt1, _ytop, _xb0, _xb1, _ybot) {
    return [[_xt0, _ytop], [_xt1, _ytop], [_xb1, _ybot], [_xb0, _ybot]];
}

/// ============================================================================================
/// THE SOLVER
/// ============================================================================================

/// Solve the masses for one building.
///
/// Returns an array of mass structs:
///     { pts, x0, x1, ytop, storeys, kind, mat }
///   kind: "main" | "wing" | "tower" | "stack" | "plinth"
///   mat : "wall" | "stone" | "beam"  - the palette prefix this mass is built from
///
/// The first mass is ALWAYS the main block. bor_building, bor_roof and bor_opening all rely on
/// that, and bor_selftest asserts it, because "the first one" is the kind of convention that is
/// true until someone sorts the array.
function bor_massing_build(_role, _st) {
    var _sp = bor_role_spec(_role);
    var _n  = bor_massing_storeys(_role, _st);

    var _hw = _sp.halfw - _sp.slim;

    // -- SOLVE THE STOREY HEIGHT ---------------------------------------------------------------
    // Reserve the roof first. A gable-fronted roof is as tall as the pitch times the full width; an
    // eaves-fronted one shows only a shallow band, so it costs much less height. Solving against
    // the taller of the two would waste a third of the box on every southern town.
    // ⚠️ THE EAVES-FRONT FIGURE COMES FROM bor_roof_band_factor() AND IS NOT REPEATED HERE. Two
    // places computing the same reservation is how a roof either clips out of the box or leaves a
    // reserved band empty, and neither shows up as an error.
    var _roof_h = _st.parapet
        ? 0.055
        : (_st.gable_front ? (_st.pitch * _hw * 1.05)
                           : (_st.pitch * _hw * bor_roof_band_factor()));
    // A turret or a stack rises above the main ridge and must be paid for here too, or a chapel
    // spire is the one thing in the product that clips.
    var _extra_top = 0;
    if (_sp.wing == "turret") _extra_top = 0.115;
    // A forge stack stands WELL clear of the ridge - it has to, to draw. Raised from 0.070 so the
    // smithy reads as a chimney with a shed attached rather than as another cottage.
    if (_sp.wing == "stack")  _extra_top = 0.165;

    var _avail = (BOR_GROUND - BOR_SKYLINE) - _roof_h - _extra_top;
    var _sh = min(BOR_STOREY_MAX, _avail / max(1, _n));

    // Age settles a building INTO the ground. Not a large number, and it is one of the two or three
    // marks that reads as age at a glance, because the ground line stays put while the eaves drop.
    var _settle = _st.age * 0.014;

    var _ybot = BOR_GROUND;
    var _ytop = _ybot - _sh * _n + _settle;

    var _out = [];

    // -- a raised granary stands on staddle stones, and the GAP UNDER IT is the whole silhouette --
    if (_sp.wing == "raised") {
        var _plinth = _sh * 0.34;
        _ytop -= _plinth;
        var _floor = _ybot - _plinth;
        // Four short stone legs. Each is its own convex mass; the air between them is what says
        // "granary" and not "shed", and it only exists because they are separate masses.
        for (var _i = 0; _i < 4; _i++) {
            var _lx = -_hw * 0.80 + (_hw * 1.60) * (_i / 3.0);
            array_push(_out, {
                pts: bor_taper_box_pts(_lx - _hw * 0.055, _lx + _hw * 0.055, _floor,
                                       _lx - _hw * 0.085, _lx + _hw * 0.085, _ybot),
                x0: _lx - _hw * 0.085, x1: _lx + _hw * 0.085,
                ytop: _floor, storeys: 0, kind: "plinth", mat: "stone",
            });
        }
        _ybot = _floor;
    }

    // -- the main block --------------------------------------------------------------------------
    var _main = {
        pts: bor_box_pts(-_hw, _ytop, _hw, _ybot),
        x0: -_hw, x1: _hw, ytop: _ytop, storeys: _n, kind: "main", mat: "wall",
    };
    array_push(_out, _main);

    // -- the second mass, which is what tells the fourteen roles apart at a glance ---------------
    switch (_sp.wing) {
        case "lean": {
            // A lean-to accretes onto the gable end, and it accretes WITH AGE - a young cottage has
            // none, an old one has a bulging outshut. Its roof is a monopitch running down from the
            // main wall, so its top edge is a slope and its outline is still convex.
            if (_st.age > 0.28) {
                // ⛔ SOLVED AGAINST THE BOX, NOT CHOSEN. MEASURED 2026-08-28: at halfw 0.430 an old
                // longhouse's outshut reached x = 0.633 and the suite caught it leaving the unit
                // box - which in a buyer's game is a building painting over its neighbour. The width
                // is whatever is left after the main block and the eaves, so a wide role simply gets
                // a smaller outshut and no state can re-open it.
                var _lw = min(_hw * (0.30 + _st.age * 0.22), max(0, 0.455 - _hw));
                var _lh = (_ybot - _ytop) * (0.46 + _st.age * 0.16);
                // Too little room left to be a building: draw nothing rather than a sliver. A
                // 2px-wide mass with its own bevel and its own roof is visual noise, not detail.
                if (_lw >= 0.030) {
                    var _side = ((_st.seed & 1) == 0) ? -1 : 1;
                    var _ax = _side * _hw;
                    var _bx = _side * (_hw + _lw);
                    // ⚠️ sloped:true - THE TOP EDGE OF THIS MASS *IS* THE ROOF PLANE, so it must not
                    // also be given a roof mass of its own. MEASURED 2026-08-28: building a
                    // monopitch on top of an already-sloping outshut produced a thin dark plank
                    // floating out from the gable on every cottage and longhouse in the corpus.
                    // A lean-to is one plane, and it gets a capping ribbon along that plane instead.
                    array_push(_out, {
                        pts: bor_slope_box_pts(_ax, _ybot - _lh, _bx, _ybot - _lh * 0.52, _ybot),
                        x0: min(_ax, _bx), x1: max(_ax, _bx), sloped: true,
                        cap: [[_ax, _ybot - _lh], [_bx, _ybot - _lh * 0.52]],
                        ytop: _ybot - _lh, storeys: 1, kind: "wing", mat: "wall",
                    });
                }
            }
        } break;

        case "gable": {
            // A cross-wing: a second block set forward, its own gable to the street. This is the
            // shape that says "inn" - a wide range with a projecting wing over the entry.
            var _gw = _hw * 0.44;
            var _gx = -_hw + _gw * 1.15;
            var _gy = _ytop - _sh * 0.16;
            array_push(_out, {
                pts: bor_box_pts(_gx - _gw, _gy, _gx + _gw, _ybot),
                x0: _gx - _gw, x1: _gx + _gw, ytop: _gy, storeys: _n, kind: "wing", mat: "wall",
            });
        } break;

        case "turret": {
            // A bellcote / stair turret rising past the ridge. Narrow, tall, and OFF CENTRE, because
            // a centred one reads as a symmetrical logo rather than a building.
            var _tw = _hw * 0.20;
            var _tx = _hw * 0.58;
            array_push(_out, {
                pts: bor_box_pts(_tx - _tw, _ytop - _extra_top, _tx + _tw, _ybot),
                x0: _tx - _tw, x1: _tx + _tw, ytop: _ytop - _extra_top,
                storeys: _n, kind: "tower", mat: "stone",
            });
        } break;

        case "stack": {
            // A smithy is a chimney with a shed attached, and the stack is a TAPER: wide at the
            // hearth, narrow at the head. Drawn as a straight column it reads as a pipe.
            var _sx = _hw * 0.62;
            array_push(_out, {
                pts: bor_taper_box_pts(_sx - _hw * 0.085, _sx + _hw * 0.085, _ytop - _extra_top,
                                       _sx - _hw * 0.155, _sx + _hw * 0.155, _ybot),
                x0: _sx - _hw * 0.155, x1: _sx + _hw * 0.155, ytop: _ytop - _extra_top,
                storeys: 0, kind: "stack", mat: "stone",
            });
        } break;

        case "twin": {
            // A gatehouse is TWO drum towers with a passage between them. The passage is the void
            // between two convex masses - which is the only way a fan can draw a carriage arch at
            // all - and the main block above is the range that spans them.
            for (var _k = -1; _k <= 1; _k += 2) {
                var _tx2 = _k * _hw * 0.76;
                var _tw2 = _hw * 0.235;
                array_push(_out, {
                    pts: bor_taper_box_pts(_tx2 - _tw2, _tx2 + _tw2, _ytop - _sh * 0.30,
                                           _tx2 - _tw2 * 1.22, _tx2 + _tw2 * 1.22, _ybot),
                    x0: _tx2 - _tw2 * 1.22, x1: _tx2 + _tw2 * 1.22, ytop: _ytop - _sh * 0.30,
                    storeys: _n, kind: "tower", mat: "stone",
                });
            }
        } break;

        case "arcade": {
            // A guildhall's ground floor is an open arcade on piers - the town's covered market.
            // The piers are separate masses and the gaps between them are the arcade. Setting the
            // main block's own base ABOVE them would need a concave outline, so instead the piers
            // are drawn in stone in front of the wall, and bor_opening cuts the arcade openings.
            var _piers = 5;
            var _py = _ybot - _sh * 0.94;
            for (var _i = 0; _i < _piers; _i++) {
                var _px = -_hw * 0.86 + (_hw * 1.72) * (_i / (_piers - 1.0));
                array_push(_out, {
                    pts: bor_box_pts(_px - _hw * 0.055, _py, _px + _hw * 0.055, _ybot),
                    x0: _px - _hw * 0.055, x1: _px + _hw * 0.055,
                    ytop: _py, storeys: 0, kind: "plinth", mat: "stone",
                });
            }
        } break;
    }

    return _out;
}

/// The main block of a mass list. See the contract note on bor_massing_build.
function bor_massing_main(_masses) {
    var _n = array_length(_masses);
    for (var _i = 0; _i < _n; _i++) if (_masses[_i].kind == "main") return _masses[_i];
    return _masses[0];
}

/// The full horizontal extent of a mass list, so a street can abut two buildings without knowing
/// anything about roles.
function bor_massing_extent(_masses) {
    var _n = array_length(_masses);
    var _x0 = 9999, _x1 = -9999;
    for (var _i = 0; _i < _n; _i++) {
        _x0 = min(_x0, _masses[_i].x0);
        _x1 = max(_x1, _masses[_i].x1);
    }
    return [_x0, _x1];
}

/// ============================================================================================
/// THE CONVEXITY CONTRACT
///
/// ⛔ THIS IS THE ASSERTION THAT CAN SEE THE DEFECT THE PICTURE CANNOT SHOW YOU. Read the file
/// header. A concave outline handed to bor_ring_fill produces a shape that spans its own
/// concavity, silently. Every mass this file emits must pass this, and bor_selftest runs it over
/// all fourteen roles at several settlement states.
///
/// Returns true if the polygon is convex: every consecutive cross product has the same sign.
/// A collinear triple (cross == 0) is allowed - a box with a mid-edge point is still convex.
///
/// ⚠️ THE TOLERANCE IS 0.0001 AND MAY NOT GO LOWER. GML applies a default epsilon of 0.00001 to
/// numeric comparisons, so a tolerance at or below it makes this test pass vacuously for every
/// input, including a figure-of-eight. Written in full because `1e-4` is a GML lexer error.
/// ============================================================================================
function bor_is_convex(_pts) {
    var _n = array_length(_pts);
    if (_n < 3) return false;
    var _seen_pos = false, _seen_neg = false;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _pts[_i];
        var _b = _pts[(_i + 1) % _n];
        var _c = _pts[(_i + 2) % _n];
        var _cross = (_b[0] - _a[0]) * (_c[1] - _b[1]) - (_b[1] - _a[1]) * (_c[0] - _b[0]);
        if (_cross >  0.0001) _seen_pos = true;
        if (_cross < -0.0001) _seen_neg = true;
    }
    return !(_seen_pos && _seen_neg);
}
