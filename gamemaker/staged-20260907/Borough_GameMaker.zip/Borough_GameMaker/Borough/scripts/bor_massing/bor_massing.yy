{
  "$GMScript": "v1",
  "%Name": "bor_massing",
  "isCompatibility": false,
  "isDnD": false,
  "name": "bor_massing",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}