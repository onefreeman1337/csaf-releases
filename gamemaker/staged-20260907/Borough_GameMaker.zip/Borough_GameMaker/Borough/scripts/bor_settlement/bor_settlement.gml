/// BOROUGH - bor_settlement. The state model, and the only thing in the product a buyer must learn.
///
/// One struct drives every building on the street. Nothing about a facade is authored per building:
/// storey count, glazing, wall material, roof form, door furniture, signage and weathering are all
/// DERIVED from the eight fields below. That is the product's promise - the town visibly changes as
/// the game is played - and it is only true if nothing anywhere else in the package hard-codes a
/// look.
///
/// ⛔ REGION MUST NOT BECOME A PALETTE SWAP. This is the single easiest way to fail this product,
/// and the wing's own law names it: a difference must change AREA, SPACING or SILHOUETTE. A steep
/// upland roof and a flat southern parapet are different OUTLINES, not the same outline in two
/// colours. bor_selftest asserts that every pair of regions differs in roof pitch or in parapet
/// treatment, so a future edit that quietly reduces region to a hue shift goes red.
///
/// ⛔ AND NEITHER MAY WEALTH. Wealth changes the window HEAD (square, segmental, arched), whether
/// there is a cornice at all, and how many door mouldings there are - all of which change the
/// silhouette of the opening. The hue it also shifts is the least of what it does.
/// ============================================================================================

#macro BOR_REGION_N 6
#macro BOR_TRADE_N  6

/// ============================================================================================
/// THE ARGUMENT GUARDS
///
/// Every public entry point in this package refuses an argument it cannot use instead of throwing.
/// Added 2026-09-07 after the package's own adversarial harness ran 48 attacks against the twelve
/// DOCUMENTED entry points and produced 36 crashes, all one family: a function dereferencing an
/// argument it never checked.
///
/// ⛔ `is_struct` ALONE IS NOT ENOUGH HERE AND THAT IS THE WHOLE REASON THIS IS A FUNCTION RATHER
/// THAN AN INLINE TEST. Every consumer immediately calls `clamp(_st.prosperity, 0, 1)`, and this
/// wing has MEASURED that `clamp(undefined, lo, hi)` THROWS in GML - a clamp is not a coercion. So
/// `{}` passes `is_struct` and then crashes on the very next line, which is the guard appearing to
/// work while changing nothing. The fields are checked for PRESENCE AND TYPE.
///
/// ⚠️ It checks the fields the derivation actually READS, not all eight. `seed` is checked because
/// the sign hue reads it; `wealth` because it is floored. A guard that demanded fields nothing uses
/// would reject a valid hand-built state, and a guard that false-reds a legitimate caller is a
/// guard that gets deleted.
///
/// ⛔⛔ EVERY NUMERIC TEST HERE IS `is_numeric`, NEVER `is_real`, AND THE DIFFERENCE IS NOT
/// COSMETIC - IT IS THE DIFFERENCE BETWEEN A GUARD AND A WALL. MEASURED 2026-09-07, and it took
/// the whole suite down in one run.
///
/// `is_real` in GML means "is a DOUBLE", not "is a number". `bor_settlement_create` computes its
/// seed as `_seed | 0`, and GML's bitwise operators return an **int64** - so `is_real(_st.seed)` is
/// FALSE for every settlement this product has ever created. Written with `is_real`, this predicate
/// rejected 100% of legitimate states: `bor_palette_build` refused, returned `undefined`, and the
/// self-test died at stage 11 with `variable_struct_get_names argument 1 incorrect type
/// (undefined)`. Changing this ONE line to `is_numeric` took the suite from a crash to 1001/1001,
/// which is what isolates the cause rather than merely correlating with it.
///
/// ⚠️ THE SAME TRAP IS WAITING ON COLOURS. `bor_is_palette` below tests ramp entries, and a GML
/// colour is an integer, so `is_real` would reject every palette ever built - and that one would
/// NOT have been caught by the self-test, because the palette guard is only reached from the draw
/// entry points. A false-red guard is worse than no guard: it refuses silently, so the product
/// draws nothing and looks broken rather than throwing where the mistake is.
function bor_is_settlement(_st) {
    if (!is_struct(_st)) return false;
    if (!is_numeric(variable_struct_get(_st, "prosperity"))) return false;
    if (!is_numeric(variable_struct_get(_st, "age"))) return false;
    if (!is_numeric(variable_struct_get(_st, "damage"))) return false;
    if (!is_numeric(variable_struct_get(_st, "wealth"))) return false;
    if (!is_numeric(variable_struct_get(_st, "seed"))) return false;
    if (!is_string(variable_struct_get(_st, "region"))) return false;
    if (!is_string(variable_struct_get(_st, "trade"))) return false;
    return true;
}

/// A building handle, as returned by bor_building_create.
///
/// ⚠️ `masses` is checked as an ARRAY rather than merely present, because bor_building_silhouette
/// and every part builder index it immediately, and `array_length` on a non-array throws.
function bor_is_building(_b) {
    if (!is_struct(_b)) return false;
    if (!is_array(variable_struct_get(_b, "masses"))) return false;
    if (!bor_is_settlement(variable_struct_get(_b, "st"))) return false;
    return true;
}

/// A palette, as returned by bor_palette_build. One sentinel ramp entry is enough: the palette is
/// built in one pass, so a struct carrying `wall0` carries all of them or the build itself failed.
function bor_is_palette(_pal) {
    if (!is_struct(_pal)) return false;
    if (!is_numeric(variable_struct_get(_pal, "wall0"))) return false;
    if (!is_numeric(variable_struct_get(_pal, "sky_hi"))) return false;
    return true;
}

/// A rect, for the draw entry points. Zero and negative extents are LEGAL to pass and are refused
/// downstream by the drawing code's own minimum-size test; what is checked here is only that the
/// four numbers are numbers at all.
function bor_is_rect(_x, _y, _w, _h) {
    return is_numeric(_x) && is_numeric(_y) && is_numeric(_w) && is_numeric(_h);
}

/// The six regions, in corpus order.
function bor_region_names() {
    return ["lowland", "upland", "coastal", "forest", "southern", "alpine"];
}

/// The six trades, in corpus order.
function bor_trade_names() {
    return ["market", "port", "mining", "farming", "monastic", "garrison"];
}

/// Roof pitch by region, as a fraction of the building's width. THIS IS THE SILHOUETTE and it is
/// deliberately the first thing in the file after the names.
///
/// Real reason for each, because a number with a reason behind it survives an edit and a magic
/// number does not: snow sheds off a steep pitch (alpine, upland), a flat parapet is possible only
/// where it does not snow (southern), thatch needs a steep pitch to shed water and dries badly if
/// it is shallow (forest, lowland), and a coastal roof is shallow and heavy because the wind will
/// take a tall one off.
function bor_region_pitch(_region) {
    switch (_region) {
        case "lowland":  return 0.48;
        case "upland":   return 0.62;
        case "coastal":  return 0.34;
        case "forest":   return 0.58;
        case "southern": return 0.16;   // near flat; usually parapeted, see below
        case "alpine":   return 0.74;
    }
    return 0.48;
}

/// Does the region build a PARAPET - a wall carried up past the roof, hiding it?
/// A parapet is a completely different silhouette from a gable, which is the point.
function bor_region_parapet(_region) {
    return (_region == "southern");
}

/// Does the region set its gable to the STREET (gable-end forward) or run the ridge along it?
/// This flips the whole facade: a gable-fronted building is a triangle over a narrow front, an
/// eaves-fronted one is a long horizontal with a shallow band of roof above it.
function bor_region_gable_front(_region) {
    switch (_region) {
        case "upland":  return true;
        case "alpine":  return true;
        case "coastal": return false;
        case "forest":  return true;
    }
    return false;
}

/// The regional hue shift in degrees, applied to earth materials only. See bor_material.
function bor_region_hue(_region) {
    switch (_region) {
        case "lowland":  return  0;
        case "upland":   return -14;   // colder, greyer stone
        case "coastal":  return -22;   // grey, salt-bleached
        case "forest":   return   8;   // warmer timber and daub
        case "southern": return  16;   // sand and warm lime
        case "alpine":   return -10;
    }
    return 0;
}

/// The wall material a region reaches for at a given wealth.
function bor_region_wall(_region, _wealth) {
    var _w = clamp(_wealth, 0, 4);
    switch (_region) {
        case "upland":   return (_w >= 3) ? "ashlar" : "rubble";
        case "alpine":   return (_w >= 3) ? "ashlar" : "rubble";
        case "coastal":  return (_w >= 3) ? "ashlar" : "rubble";
        case "forest":   return (_w >= 3) ? "timber" : "cob";
        case "southern": return (_w >= 2) ? "render" : "cob";
        case "lowland":  return (_w >= 3) ? "brick"  : ((_w >= 1) ? "render" : "cob");
    }
    return "rubble";
}

/// The roof material a region reaches for at a given prosperity. Thatch is what you use when you
/// cannot afford anything else, and it is also what you keep using in a forest where straw is free.
function bor_region_roof(_region, _prosperity) {
    var _p = clamp(_prosperity, 0, 1);
    switch (_region) {
        case "upland":   return (_p > 0.45) ? "slate" : "thatch";
        case "alpine":   return (_p > 0.35) ? "slate" : "thatch";
        case "coastal":  return (_p > 0.55) ? "slate" : "tile";
        case "forest":   return (_p > 0.70) ? "tile"  : "thatch";
        case "southern": return "tile";
        case "lowland":  return (_p > 0.50) ? "tile"  : "thatch";
    }
    return "thatch";
}

/// The building roles a trade actually supports, as an array of role names.
///
/// ⚠️ EVERY LIST HERE MUST BE NON-EMPTY AND EVERY NAME MUST EXIST IN bor_massing. A trade whose
/// list is empty produces an empty street with no error at all - the silent failure this wing
/// keeps recording. bor_selftest walks all six and checks both.
function bor_trade_roles(_trade) {
    switch (_trade) {
        case "market":
            return ["shopfront", "townhouse", "inn", "guildhall", "cottage", "tenement"];
        case "port":
            return ["warehouse", "inn", "shopfront", "cottage", "tenement", "watchtower"];
        case "mining":
            return ["cottage", "longhouse", "smithy", "warehouse", "chapel", "tenement"];
        case "farming":
            return ["cottage", "longhouse", "granary", "mill", "smithy", "chapel"];
        case "monastic":
            return ["chapel", "granary", "guildhall", "cottage", "longhouse", "gatehouse"];
        case "garrison":
            return ["gatehouse", "watchtower", "smithy", "inn", "tenement", "cottage"];
    }
    return ["cottage"];
}

/// ============================================================================================
/// THE STATE STRUCT
/// ============================================================================================

/// Create a settlement.
///
/// Everything is derived from _seed unless the caller overrides it afterwards - the fields are
/// plain and writable on purpose, because the buyer's game owns the simulation and this product
/// owns the picture. A game that tracks its own prosperity number just assigns it.
///
/// ⚠️ founded/age: `age` is 0..1 and is the visual one - how long this place has stood, mapped to
/// settling, sag, accretion and weathering depth. `founded` is a year the buyer's game can keep for
/// its own bookkeeping and this product never reads. Both exist because conflating them means a
/// game with a 900-year calendar cannot express a new town.
function bor_settlement_create(_seed) {
    // Guard: refuse rather than throw (2026-09-07). `_seed | 0` is not a coercion - GML raises
    // "unable to convert string 'xyzzy' to int64" - and this was the LAST of 36 crashes to fall.
    //
    // ⛔ THE REFUSAL IS `undefined`, NOT "TREAT IT LIKE AN ABSENT SEED". `undefined` is already a
    // LEGAL seed here and means 1, so folding a bad seed into that path would hand back a real,
    // drawable town - and the same one for every distinct bad seed, so two towns a buyer meant to
    // be different would be identical. That is the fail-open shape, and it is worse than a blank
    // rect because it looks like the product working.
    //
    // ⚠️ A STRING SEED IS NOT QUIETLY HASHED EITHER, tempting though it is - the seed IS hashed
    // internally, so accepting one would cost nothing and would work. It is refused because
    // widening a documented signature is a product decision and this is a crash fix; the Readme
    // says a number. If it should take a name, that is a deliberate feature with a Readme change.
    if (!is_undefined(_seed) && !is_numeric(_seed)) return undefined;

    var _s = is_undefined(_seed) ? 1 : (_seed | 0);
    var _r = bor_rng(bor_hash32("bor_settlement:" + string(_s)));

    var _regions = bor_region_names();
    var _trades  = bor_trade_names();

    var _region = _regions[floor(bor_rng_next(_r) * BOR_REGION_N) % BOR_REGION_N];
    var _trade  = _trades[floor(bor_rng_next(_r) * BOR_TRADE_N) % BOR_TRADE_N];
    var _pros   = 0.20 + bor_rng_next(_r) * 0.70;
    var _wealth = clamp(floor(_pros * 5), 0, 4);
    var _age    = bor_rng_next(_r) * 0.85;

    var _st = {
        seed:       _s,
        rngbase:    bor_hash32("bor_settlement:" + string(_s)),
        founded:    1000 + floor(bor_rng_next(_r) * 400),
        prosperity: _pros,
        trade:      _trade,
        wealth:     _wealth,
        age:        _age,
        damage:     0.0,
        region:     _region,
        // -- derived, refreshed by bor_settlement_derive ------------------------------------------
        hue_shift:  0,
        sign_hue:   0,
        wall_mat:   "rubble",
        roof_mat:   "thatch",
        pitch:      0.48,
        parapet:    false,
        gable_front: false,
    };
    return bor_settlement_derive(_st);
}

/// Recompute every derived field from the eight authored ones.
///
/// ⛔ CALL THIS AFTER ANY DIRECT ASSIGNMENT. A buyer who sets st.prosperity = 0.9 and draws without
/// deriving gets the old materials on the new prosperity, and the failure looks like "the product
/// ignores prosperity" rather than "you skipped a step". bor_settlement_step calls it for you, and
/// bor_street_draw calls it defensively, which is cheap and removes the trap entirely.
function bor_settlement_derive(_st) {
    // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    // ⛔ THE REFUSAL RETURNS WHAT IT WAS GIVEN, IT DOES NOT FABRICATE A SETTLEMENT. Returning a
    // default town would be a fail-open: the buyer's street would draw, in someone else's colours,
    // and look almost right. Handing the argument straight back means the next line the caller
    // writes fails at THEIR call site with THEIR value in it, which is where the mistake is.
    if (!bor_is_settlement(_st)) return _st;

    _st.prosperity = clamp(_st.prosperity, 0, 1);
    _st.age        = clamp(_st.age, 0, 1);
    _st.damage     = clamp(_st.damage, 0, 1);
    _st.wealth     = clamp(floor(_st.wealth), 0, 4);

    _st.hue_shift   = bor_region_hue(_st.region);
    _st.wall_mat    = bor_region_wall(_st.region, _st.wealth);
    _st.roof_mat    = bor_region_roof(_st.region, _st.prosperity);
    _st.pitch       = bor_region_pitch(_st.region);
    _st.parapet     = bor_region_parapet(_st.region);
    _st.gable_front = bor_region_gable_front(_st.region);

    // The sign hue is the settlement's own, so every painted board in one town belongs to that
    // town. Golden-angle stepping off the seed, which is the cheapest way to get hues that are far
    // apart for any two nearby seeds.
    _st.sign_hue = frac(_st.seed * BOR_GOLDEN_ANGLE / 360.0) * 360.0;

    return _st;
}

/// Advance the settlement by a number of years.
///
/// Age accrues, prosperity drifts toward its trend, and damage HEALS while the place is prospering
/// and accrues while it is not. That last clause is what makes the demo room worth watching: a town
/// that loses its trade does not merely stop growing, it visibly starts boarding up.
///
/// ⚠️ _trend is -1..1 and is the buyer's hook. A game that just wants time to pass calls with 0.
function bor_settlement_step(_st, _years, _trend) {
    // Guard: refuse rather than throw (2026-09-07). The refusal is "no time passed" - the state is
    // returned untouched. A town that visibly fails to age gets investigated; a town aged by a
    // fabricated number does not, and this function is the one a buyer calls every in-game month.
    if (!bor_is_settlement(_st)) return _st;
    if (!is_numeric(_years)) return _st;
    if (!is_undefined(_trend) && !is_numeric(_trend)) return _st;

    var _y = max(0, _years);
    var _t = is_undefined(_trend) ? 0 : clamp(_trend, -1, 1);

    // A century is the natural unit of visible ageing on a building, so age moves by years/100.
    _st.age = clamp(_st.age + _y / 100.0, 0, 1);

    _st.prosperity = clamp(_st.prosperity + _t * _y * 0.010, 0, 1);

    // Repair is proportional to prosperity ABOVE a subsistence line: a place at 0.3 keeps its roof
    // on and does no more.
    var _repair = max(0, _st.prosperity - 0.30) * _y * 0.020;
    var _decay  = max(0, 0.30 - _st.prosperity) * _y * 0.030;
    _st.damage = clamp(_st.damage - _repair + _decay, 0, 1);

    // Wealth follows prosperity, but LAGS it, because wealth is accumulated stock and prosperity is
    // flow. Without the lag a bad decade strips the stone mouldings off a cathedral.
    var _target = clamp(floor(_st.prosperity * 5), 0, 4);
    if (_target > _st.wealth && _y >= 20) _st.wealth += 1;
    if (_target < _st.wealth && _y >= 40) _st.wealth -= 1;

    return bor_settlement_derive(_st);
}

/// Apply a shock - a fire, a siege, a storm. Damage jumps and prosperity falls.
function bor_settlement_damage(_st, _amount) {
    // Guard: refuse rather than throw (2026-09-07). The refusal is "no shock was applied", which is
    // the closed direction: silently applying a coerced amount would let a fire land at a strength
    // nobody asked for, on a state the buyer keeps.
    if (!bor_is_settlement(_st)) return _st;
    if (!is_numeric(_amount)) return _st;

    _st.damage = clamp(_st.damage + max(0, _amount), 0, 1);
    _st.prosperity = clamp(_st.prosperity - max(0, _amount) * 0.35, 0, 1);
    return bor_settlement_derive(_st);
}

/// A short human line describing the settlement, for the demo readout and the store sheets.
function bor_settlement_label(_st) {
    // Guard: refuse rather than throw (2026-09-07). Not in the Readme's API list, and guarded anyway
    // - Livery measured that guarding only what the harness happened to scope leaves the sibling of
    // every fixed function exposed. An empty caption draws nothing; a fabricated one would read as
    // a real description of a town that does not exist.
    if (!bor_is_settlement(_st)) return "";

    var _tier = ["destitute", "poor", "steady", "prosperous", "rich"];
    return string_upper(string(_st.trade)) + " . " + string(_st.region)
         + " . " + _tier[clamp(_st.wealth, 0, 4)]
         + " . " + string(round(_st.age * 300)) + " years"
         + ((_st.damage > 0.15) ? (" . " + string(round(_st.damage * 100)) + "% damaged") : "");
}
