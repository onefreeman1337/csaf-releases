{
  "$GMScript": "v1",
  "%Name": "bor_settlement",
  "isCompatibility": false,
  "isDnD": false,
  "name": "bor_settlement",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}