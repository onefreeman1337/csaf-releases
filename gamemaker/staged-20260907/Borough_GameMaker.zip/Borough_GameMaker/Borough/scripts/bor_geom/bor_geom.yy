{
  "$GMScript": "v1",
  "%Name": "bor_geom",
  "isCompatibility": false,
  "isDnD": false,
  "name": "bor_geom",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}