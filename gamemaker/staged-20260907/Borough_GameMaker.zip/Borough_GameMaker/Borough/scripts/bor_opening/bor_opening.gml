/// BOROUGH - bor_opening. THE CORPUS III: eight window rhythms and six door treatments.
///
/// ⛔ AN OPENING IS A SUBTRACTED AREA WITH A RECESSED REVEAL. It is never lines drawn on a filled
/// wall. At game scale - a building forty pixels wide - a drawn rectangle is a smudge and a
/// recessed one is a window, because the reveal is LIT ON ONE SIDE AND DARK ON THE OTHER and that
/// asymmetry survives down to about four pixels. This is bor_sink, aimed at a small outline.
///
/// ⛔ AND THE REVEAL DEPTH IS SOLVED FROM THE OPENING'S OWN WIDTH. A bevel wider than the feature
/// it bevels turns that feature INSIDE OUT: the inner ring self-crosses and the opening renders as
/// two shards with a gap. Nothing mechanical sees it - the outline is fine, the winding is fine,
/// the ink is fine, the picture is wrong. A single facade-wide bevel constant would do exactly this
/// to every glazing bar in the product, because glazing bars are the smallest features on it.
///
/// -- WHAT THE STATE MOVES ----------------------------------------------------------------------
///   wealth      the HEAD of the opening: square lintel -> segmental -> arched -> arched with a
///               hood mould. Each is a different silhouette, which is the requirement.
///   prosperity  how much of the wall is glazed at all. Glass was the expensive part.
///   damage      boarding. A boarded window is a plank field where the glass was, and it is the
///               fastest-reading state change on the whole facade.
///   age         the sill wears and the reveal softens.
/// ============================================================================================

/// The eight window rhythms, in corpus order.
function bor_rhythm_names() {
    return ["single", "paired", "triple", "arcade", "oriel", "dormer", "blind", "shuttered"];
}

/// The six door treatments, in corpus order.
function bor_door_names() {
    return ["plank", "panelled", "arched", "pilastered", "carriage", "stall"];
}

/// Which rhythm this role uses on an upper storey.
function bor_rhythm_pick(_role, _st) {
    switch (_role) {
        case "warehouse":  return "blind";
        case "granary":    return "blind";
        case "watchtower": return "single";
        case "mill":       return "single";
        case "chapel":     return "arcade";
        case "guildhall":  return "arcade";
        case "gatehouse":  return "single";
        case "smithy":     return "shuttered";
        case "longhouse":  return "shuttered";
        case "inn":        return (_st.wealth >= 3) ? "oriel" : "triple";
        case "townhouse":  return (_st.wealth >= 3) ? "oriel" : "paired";
        case "shopfront":  return "triple";
        case "tenement":   return "paired";
        case "cottage":    return (_st.prosperity > 0.5) ? "paired" : "single";
    }
    return "paired";
}

/// Which door this role uses.
function bor_door_pick(_role, _st) {
    switch (_role) {
        case "gatehouse":  return "carriage";
        case "warehouse":  return "carriage";
        case "granary":    return "plank";
        case "smithy":     return "carriage";
        case "shopfront":  return "stall";
        case "guildhall":  return "arched";
        case "chapel":     return "arched";
        case "inn":        return (_st.wealth >= 3) ? "pilastered" : "panelled";
        case "townhouse":  return (_st.wealth >= 3) ? "pilastered" : "panelled";
        case "tenement":   return "panelled";
    }
    return (_st.wealth >= 2) ? "panelled" : "plank";
}

/// ============================================================================================
/// THE OPENING OUTLINE - where wealth changes the silhouette
/// ============================================================================================

/// One opening's outline, headed according to wealth.
///
/// ⚠️ CONVEX IN EVERY CASE, checked by bor_selftest. A square-headed opening is a box; a segmental
/// or round head is a box with an arc on top, which stays convex as long as the arc bulges OUTWARD
/// - and it does, because a window head is an arch, not a scallop.
function bor_opening_pts(_x0, _ytop, _x1, _ybot, _wealth) {
    var _w = _x1 - _x0;
    var _cx = (_x0 + _x1) * 0.5;

    if (_wealth <= 1) {
        // Square head under a flat timber lintel. Poor, and correct for poor.
        return bor_box_pts(_x0, _ytop, _x1, _ybot);
    }

    // Rise of the arch: shallow segmental at wealth 2, near semicircular at 3 and 4.
    var _rise = (_wealth == 2) ? (_w * 0.16) : (_w * 0.46);
    var _n = 10;
    var _pts = [];
    array_push(_pts, [_x0, _ytop]);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n;
        // A half ellipse from the left springing to the right, bulging up. sin() is zero at both
        // ends BY CONSTRUCTION, so the arch always meets the jambs exactly and no tuned constant
        // can re-open a step there.
        array_push(_pts, [lerp(_x0, _x1, _t), _ytop - _rise * sin(pi * _t)]);
    }
    array_push(_pts, [_x1, _ytop]);
    array_push(_pts, [_x1, _ybot]);
    array_push(_pts, [_x0, _ybot]);
    return _pts;
}

/// One complete opening: reveal, glass or boarding, head, sill, and glazing bars.
///
/// _face is the palette role for what sits INSIDE the opening - "glass" normally, "board" when it
/// is boarded up, or a wall role for a blind bay.
function bor_opening_one(_x0, _ytop, _x1, _ybot, _st, _face) {
    var _out = [];
    var _w = _x1 - _x0;
    var _h = _ybot - _ytop;
    if (_w <= 0.004 || _h <= 0.004) return _out;

    var _pts = bor_opening_pts(_x0, _ytop, _x1, _ybot, _st.wealth);

    // ⛔ THE REVEAL DEPTH, SOLVED FROM THE OPENING. See the header. Capped at a quarter of the
    // SMALLER dimension so that the inset rings cannot cross each other on a narrow lancet.
    var _b = min(_w, _h) * 0.22;

    // The reveal itself: the jambs and head, sunk into the wall.
    bor_append(_out, bor_map_roles(bor_sink(_pts, _b, 2, "wall1"), bor_material_map("wall")));

    // The face - glass, or boards. Inset by the reveal so it sits at the BACK of the opening, which
    // is what makes the reveal read as depth rather than as a border.
    var _inner = bor_inset(_pts, _b, bor_out_sign(_pts));
    array_push(_out, bor_ring_fill(_inner, _face, undefined, undefined));

    if (_face == "board") {
        // Boarding: diagonal planks nailed across. The DIAGONAL is the tell - a boarded window is
        // instantly readable at any size because nothing else on a facade runs at 30 degrees.
        var _n = 3;
        for (var _i = 0; _i < _n; _i++) {
            var _t = (_i + 0.5) / _n;
            array_push(_out, bor_poly([[_x0 + _b, lerp(_ytop + _h * 0.10, _ybot - _b, _t)],
                                       [_x1 - _b, lerp(_ytop + _b, _ybot - _h * 0.10, _t)]],
                                      false, _h * 0.055, "beam2"));
        }
        return _out;
    }

    // Glazing bars. COUNT AND LENGTH, never stroke weight - the wing's own law, three times paid
    // for: draw_line_width floors at 1.0 px with no antialiasing, so a "finer" bar is a dashed bar.
    // A rich window has MORE panes, not thinner leading.
    if (_face == "glass" && _w > 0.016) {
        var _cols = (_st.wealth >= 3) ? 3 : 2;
        var _rows = (_st.wealth >= 3) ? 4 : 2;
        for (var _c = 1; _c < _cols; _c++) {
            var _bx = lerp(_x0 + _b, _x1 - _b, _c / _cols);
            array_push(_out, bor_poly([[_bx, _ytop + _b * 0.6], [_bx, _ybot - _b]],
                                      false, 0.003, "lead2"));
        }
        for (var _r = 1; _r < _rows; _r++) {
            var _by = lerp(_ytop + _b * 0.6, _ybot - _b, _r / _rows);
            array_push(_out, bor_poly([[_x0 + _b, _by], [_x1 - _b, _by]], false, 0.003, "lead2"));
        }
        // A single lit pane. One window in a building being warm is the difference between a model
        // and a place, and it costs one fill.
        if (((_st.seed + round(_x0 * 1000)) % 5) == 0) {
            var _px0 = lerp(_x0 + _b, _x1 - _b, 0);
            var _px1 = lerp(_x0 + _b, _x1 - _b, 1.0 / _cols);
            var _py0 = lerp(_ytop + _b * 0.6, _ybot - _b, 0);
            var _py1 = lerp(_ytop + _b * 0.6, _ybot - _b, 1.0 / _rows);
            array_push(_out, bor_rect_fill(_px0, _py0, _px1, _py1, "glass_lit"));
        }
    }

    // The SILL: a stone shelf proud of the wall, with its underside in shadow. On a real elevation
    // the sill line is what makes a row of windows read as a row, because it is continuous shadow.
    var _sill = _h * 0.075;
    bor_append(_out, bor_map_roles(
        bor_raise(bor_box_pts(_x0 - _w * 0.07, _ybot, _x1 + _w * 0.07, _ybot + _sill),
                  _sill * 0.42, 2, "stone3"),
        bor_material_map("stone")));

    // The HOOD MOULD, wealth 4 only: a projecting drip course over the head. It is the single mark
    // that most reliably reads as money on a medieval facade.
    if (_st.wealth >= 4) {
        var _rise = _w * 0.46;
        var _hm = [];
        for (var _i = 0; _i <= 12; _i++) {
            var _t = _i / 12;
            array_push(_hm, [lerp(_x0 - _w * 0.10, _x1 + _w * 0.10, _t),
                             _ytop - _rise * sin(pi * _t) - _h * 0.045]);
        }
        bor_append(_out, bor_map_roles(bor_ridge(_hm, false, _h * 0.045),
                                       bor_material_map("stone")));
    }

    return _out;
}

/// ============================================================================================
/// THE RHYTHMS - a storey band in, a set of openings out
/// ============================================================================================

/// Lay a rhythm across one storey band of one mass.
///
/// _x0.._x1 is the wall the band runs across; _ytop.._ybot is the storey.
function bor_opening_band(_rhythm, _x0, _x1, _ytop, _ybot, _st) {
    var _out = [];
    var _w = _x1 - _x0;
    var _h = _ybot - _ytop;
    if (_w <= 0.01 || _h <= 0.01) return _out;

    // Glazing is expensive. A poor settlement puts fewer and smaller holes in its walls, and that
    // is a real proportion difference, not a colour one.
    var _oh = _h * (0.40 + 0.16 * _st.prosperity);
    var _oy = _ytop + _h * 0.24;
    var _boarded = (_st.damage > 0.30);

    // Which openings on this band are boarded. Deterministic in the seed so a building does not
    // shimmer between frames, and SPARSE rather than all-or-nothing, because a half-abandoned row
    // reads far worse than a uniformly shuttered one - which is the point.
    var _face = "glass";

    switch (_rhythm) {
        case "single": {
            var _ow = min(_w * 0.30, _oh * 0.62);
            var _cx = (_x0 + _x1) * 0.5;
            _face = (_boarded && ((_st.seed % 3) == 0)) ? "board" : "glass";
            bor_append(_out, bor_opening_one(_cx - _ow * 0.5, _oy, _cx + _ow * 0.5, _oy + _oh,
                                             _st, _face));
        } break;

        case "paired": case "triple": case "arcade": case "shuttered": {
            var _n = 2;
            if (_rhythm == "triple") _n = 3;
            if (_rhythm == "arcade") _n = 5;
            if (_rhythm == "shuttered") _n = 2;
            var _pitch = _w / _n;
            var _ow = min(_pitch * ((_rhythm == "arcade") ? 0.66 : 0.50), _oh * 0.66);
            for (var _i = 0; _i < _n; _i++) {
                var _cx = _x0 + _pitch * (_i + 0.5);
                _face = (_boarded && (((_st.seed + _i * 7) % 3) == 0)) ? "board" : "glass";
                var _oh2 = (_rhythm == "arcade") ? (_oh * 1.16) : _oh;
                bor_append(_out, bor_opening_one(_cx - _ow * 0.5, _oy, _cx + _ow * 0.5, _oy + _oh2,
                                                 _st, _face));
                if (_rhythm == "shuttered") {
                    // Shutters: two leaves folded back flat against the wall on either side. They
                    // are what a building has INSTEAD of glass, so they belong on the poor and the
                    // working roles, and they widen the opening's read considerably.
                    for (var _k = -1; _k <= 1; _k += 2) {
                        var _sx = _cx + _k * (_ow * 0.5 + _ow * 0.20);
                        bor_append(_out, bor_map_roles(
                            bor_raise(bor_box_pts(_sx - _ow * 0.19, _oy, _sx + _ow * 0.19,
                                                  _oy + _oh), _ow * 0.055, 2, "beam2"),
                            bor_material_map("beam")));
                    }
                }
            }
        } break;

        case "oriel": {
            // A projecting bay window carried on a corbel. This is the shape that says "money" more
            // than any amount of moulding: the building steps OUT over the street.
            var _ow = _w * 0.44;
            var _cx = (_x0 + _x1) * 0.5;
            var _proj = _oh * 0.16;
            // The corbel: a taper narrowing downward, carrying the bay.
            bor_append(_out, bor_map_roles(
                bor_raise(bor_taper_box_pts(_cx - _ow * 0.5, _cx + _ow * 0.5, _oy + _oh,
                                            _cx - _ow * 0.22, _cx + _ow * 0.22,
                                            _oy + _oh + _proj), _proj * 0.30, 2, "stone2"),
                bor_material_map("stone")));
            // The bay itself, proud of the wall, with its own little lead roof.
            bor_append(_out, bor_map_roles(
                bor_raise(bor_box_pts(_cx - _ow * 0.5, _oy - _proj * 0.5,
                                      _cx + _ow * 0.5, _oy + _oh), _proj * 0.22, 2, "wall3"),
                bor_material_map("wall")));
            bor_append(_out, bor_opening_one(_cx - _ow * 0.36, _oy, _cx + _ow * 0.36,
                                             _oy + _oh * 0.86, _st, "glass"));
        } break;

        case "dormer": {
            // Dormers sit ON the roof, not in the wall, so the band they are given is the roof
            // plane. Each is its own convex box with its own gablet above it.
            var _n = 3;
            var _pitch = _w / _n;
            var _ow = _pitch * 0.42;
            for (var _i = 0; _i < _n; _i++) {
                var _cx = _x0 + _pitch * (_i + 0.5);
                bor_append(_out, bor_map_roles(
                    bor_raise(bor_box_pts(_cx - _ow * 0.5, _oy, _cx + _ow * 0.5, _oy + _oh * 0.8),
                              _ow * 0.10, 2, "wall2"),
                    bor_material_map("wall")));
                bor_append(_out, bor_map_roles(
                    [bor_ring_fill([[_cx - _ow * 0.62, _oy], [_cx, _oy - _ow * 0.40],
                                    [_cx + _ow * 0.62, _oy]], "roof3", undefined, undefined)],
                    bor_material_map("roof")));
                bor_append(_out, bor_opening_one(_cx - _ow * 0.30, _oy + _oh * 0.14,
                                                 _cx + _ow * 0.30, _oy + _oh * 0.66, _st, "glass"));
            }
        } break;

        case "blind": {
            // A blind bay is a recessed PANEL with no glass at all - the wall articulated rather
            // than pierced. It is what a warehouse or a granary has, because those buildings must
            // not have windows, and it is the reason they still read as buildings and not as boxes.
            var _n = 4;
            var _pitch = _w / _n;
            var _ow = _pitch * 0.60;
            for (var _i = 0; _i < _n; _i++) {
                var _cx = _x0 + _pitch * (_i + 0.5);
                bor_append(_out, bor_opening_one(_cx - _ow * 0.5, _oy, _cx + _ow * 0.5,
                                                 _oy + _oh, _st, "wall1"));
            }
        } break;
    }
    return _out;
}

/// ============================================================================================
/// DOORS
/// ============================================================================================

/// One door, at the ground line.
function bor_opening_door(_kind, _cx, _ybot, _w, _h, _st) {
    var _out = [];
    var _x0 = _cx - _w * 0.5, _x1 = _cx + _w * 0.5;
    var _ytop = _ybot - _h;

    // Carriage arches and stall fronts are WIDE - wide enough that they change the whole ground
    // floor, which is the point of a ground-floor treatment.
    if (_kind == "carriage") { _x0 = _cx - _w * 0.95; _x1 = _cx + _w * 0.95; }
    if (_kind == "stall")    { _x0 = _cx - _w * 1.15; _x1 = _cx + _w * 1.15; }

    var _pts;
    if (_kind == "arched" || _kind == "carriage") {
        // A real arch, springing from the jambs at two thirds height. Convex.
        var _spring = _ytop + (_x1 - _x0) * 0.50;
        var _rise = (_x1 - _x0) * 0.50;
        _pts = [[_x0, _spring]];
        for (var _i = 0; _i <= 14; _i++) {
            var _t = _i / 14;
            array_push(_pts, [lerp(_x0, _x1, _t), _spring - _rise * sin(pi * _t)]);
        }
        array_push(_pts, [_x1, _spring]);
        array_push(_pts, [_x1, _ybot]);
        array_push(_pts, [_x0, _ybot]);
    } else {
        _pts = bor_box_pts(_x0, _ytop, _x1, _ybot);
    }

    var _b = min(_x1 - _x0, _h) * 0.16;
    bor_append(_out, bor_map_roles(bor_sink(_pts, _b, 2, "wall1"), bor_material_map("wall")));

    var _inner = bor_inset(_pts, _b, bor_out_sign(_pts));

    if (_kind == "stall") {
        // A shop stall is an OPEN counter under a shutter propped out as an awning - the medieval
        // shopfront. So the opening is glazed dark, with a heavy counter board across it.
        array_push(_out, bor_ring_fill(_inner, "glass", undefined, undefined));
        bor_append(_out, bor_map_roles(
            bor_raise(bor_box_pts(_x0 - _w * 0.04, _ybot - _h * 0.34,
                                  _x1 + _w * 0.04, _ybot - _h * 0.24), _h * 0.028, 2, "beam3"),
            bor_material_map("beam")));
        return _out;
    }

    // The leaf itself, in timber.
    bor_append(_out, bor_map_roles([bor_ring_fill(_inner, "beam2", undefined, undefined)],
                                   bor_material_map("beam")));

    if (_kind == "plank" || _kind == "carriage") {
        // Vertical planks with strap hinges. The STUDS on the straps are bor_boss, and at game
        // scale they are the thing that makes a door read as heavy.
        var _n = (_kind == "carriage") ? 7 : 4;
        for (var _i = 1; _i < _n; _i++) {
            var _px = lerp(_x0 + _b, _x1 - _b, _i / _n);
            array_push(_out, bor_poly([[_px, _ytop + _b], [_px, _ybot - _b * 0.3]],
                                      false, 0.004, "beam0"));
        }
        for (var _k = 0; _k < 2; _k++) {
            var _sy = lerp(_ytop + _h * 0.22, _ybot - _h * 0.18, _k);
            bor_append(_out, bor_map_roles(
                bor_raise(bor_box_pts(_x0 + _b, _sy - _h * 0.035, _x1 - _b, _sy + _h * 0.035),
                          _h * 0.016, 2, "iron2"), bor_material_map("iron")));
            var _studs = (_kind == "carriage") ? 6 : 4;
            for (var _s = 0; _s < _studs; _s++) {
                var _sx = lerp(_x0 + _b * 1.6, _x1 - _b * 1.6, _s / (_studs - 1.0));
                bor_append(_out, bor_map_roles(bor_boss(_sx, _sy, _h * 0.022, 8),
                                               bor_material_map("iron")));
            }
        }
    }

    if (_kind == "panelled" || _kind == "pilastered") {
        // Sunk panels. Two over two - the proportion that reads as a front door at any size.
        for (var _r = 0; _r < 2; _r++) {
            for (var _c = 0; _c < 2; _c++) {
                var _px0 = lerp(_x0 + _b * 1.6, _x1 - _b * 1.6, _c * 0.5 + 0.06);
                var _px1 = lerp(_x0 + _b * 1.6, _x1 - _b * 1.6, _c * 0.5 + 0.44);
                var _py0 = lerp(_ytop + _b * 1.6, _ybot - _b * 1.6, _r * 0.5 + 0.05);
                var _py1 = lerp(_ytop + _b * 1.6, _ybot - _b * 1.6, _r * 0.5 + 0.45);
                var _pw = min(_px1 - _px0, _py1 - _py0);
                bor_append(_out, bor_map_roles(
                    bor_sink(bor_box_pts(_px0, _py0, _px1, _py1), _pw * 0.20, 2, "beam1"),
                    bor_material_map("beam")));
            }
        }
    }

    if (_kind == "pilastered") {
        // A pilaster each side and an entablature over: the classical doorcase a wealthy merchant
        // puts on a medieval house. It projects, so it is a raised mass, not an incised line.
        for (var _k = -1; _k <= 1; _k += 2) {
            var _px = (_k < 0) ? _x0 : _x1;
            bor_append(_out, bor_map_roles(
                bor_raise(bor_box_pts(_px - _w * 0.075, _ytop - _h * 0.02,
                                      _px + _w * 0.075, _ybot), _w * 0.026, 2, "stone3"),
                bor_material_map("stone")));
        }
        bor_append(_out, bor_map_roles(
            bor_raise(bor_box_pts(_x0 - _w * 0.13, _ytop - _h * 0.10,
                                  _x1 + _w * 0.13, _ytop - _h * 0.02), _h * 0.022, 2, "stone3"),
            bor_material_map("stone")));
    }

    // A ring handle. One dot and one ring, and it is the difference between a door and a rectangle.
    bor_append(_out, bor_map_roles(
        [bor_ring(_cx + (_x1 - _x0) * 0.30, _ybot - _h * 0.46, _h * 0.045, 0.005, "iron1")],
        bor_material_map("iron")));

    return _out;
}
