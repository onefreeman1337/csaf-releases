{
  "$GMScript": "v1",
  "%Name": "bor_opening",
  "isCompatibility": false,
  "isDnD": false,
  "name": "bor_opening",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}