/// BOROUGH - bor_selftest. The assertions, run in-engine against a real Igor-built executable.
///
/// GML CANNOT BE UNIT-TESTED OUTSIDE THE ENGINE. That is a standing fact about this wing and it is
/// not being papered over. What does NOT follow is that the engine cannot test itself unattended:
/// Internal_Ops/run_engine.ps1 builds through gm_gate.ps1, unzips the package, runs the executable
/// with -selftest and reads the result file. Everything below runs on the shipping build.
///
/// ⛔ AND THE THING THESE ASSERTIONS CANNOT DO IS JUDGE A PICTURE. A sibling product in this wing
/// passed 369 in-engine assertions, an extent check AND an ink-bounds check, and shipped a gallery
/// with seven defects - every one found by opening the PNG and looking at it. These make NAMED
/// failure modes unshippable. They are not the review.
///
/// ⚠️ A TEST THAT HAS ONLY EVER PASSED IS NOT A TEST. Every block states what would make it
/// fail, and STAGE 0 below deliberately feeds each instrument a shape it must reject - because an
/// instrument that cannot fail proves nothing about the thing it is pointed at.
/// ============================================================================================

/// ⛔ 0.0001, NOT 0.00001, AND THE DIFFERENCE IS MEASURED RATHER THAN STYLISTIC.
/// math_get_epsilon() returns 0.00001 on this runtime and PARTICIPATES IN COMPARISONS, so a
/// tolerance at or below it can never fire in the `<` direction - a sibling product's suite had
/// every distinctness assertion passing vacuously, green forever and unable to go red. Writing the
/// tolerance exactly AT the epsilon fails the other way: a difference of ZERO compares as "equal"
/// and equal is not less-than, producing a false RED on two points that are the same array object.
/// Stay an order of magnitude clear in BOTH directions. And GML has no exponent-literal syntax at
/// all - `1e-4` is a lexer error that reads like a bracket bug.
#macro BOR_ST_EPS 0.0001

/// How far outside the unit box a part may reach. Not zero: a stroke has half-width, and the eaves
/// deliberately overhang. 0.62 is the same figure the sibling products use.
#macro BOR_ST_BOX 0.62

/// The mean silhouette separation two building roles must exceed to count as distinct.
/// ⚠️ REPORTED BESIDE ITS MEASUREMENT in the result file, so the number can be re-derived and
/// argued with rather than trusted.
#macro BOR_ST_ROLE_FLOOR 0.020

function bor_st_new() { return { pass: 0, fail: 0, failures: [] }; }

function bor_st_ok(_r, _cond, _what) {
    if (_cond) { _r.pass++; return true; }
    _r.fail++;
    array_push(_r.failures, _what);
    return false;
}

/// ============================================================================================
/// GEOMETRY HELPERS
/// ============================================================================================

/// Drop consecutive duplicate points, including the wrap-around pair.
///
/// ⛔ SKIPPING A DEGENERATE POINT INSTEAD OF REMOVING IT IS A FALSE RED, and a sibling product paid
/// a session for it: `continue` at a zero-length edge does not skip that point, it DISCARDS THE
/// TURN THAT HAPPENS AT IT, and every form that comes to a cusp reported a turning of 0.47 and was
/// called self-crossing. Deduplicate, THEN measure.
function bor_st_dedupe(_pts) {
    var _n = array_length(_pts);
    var _out = [];
    for (var _i = 0; _i < _n; _i++) {
        var _p = _pts[_i];
        if (array_length(_out) > 0) {
            var _q = _out[array_length(_out) - 1];
            if (abs(_p[0] - _q[0]) < BOR_ST_EPS && abs(_p[1] - _q[1]) < BOR_ST_EPS) continue;
        }
        array_push(_out, _p);
    }
    while (array_length(_out) > 1) {
        var _a = _out[0];
        var _b = _out[array_length(_out) - 1];
        if (abs(_a[0] - _b[0]) < BOR_ST_EPS && abs(_a[1] - _b[1]) < BOR_ST_EPS) {
            array_pop(_out);
        } else break;
    }
    return _out;
}

/// Total turning of a closed polygon, in revolutions.
///
/// ⛔ THE CHEAP TEST FOR A SELF-CROSSING OUTLINE. A simple closed polygon turns through exactly one
/// revolution; a figure-of-eight turns through zero. The failure it catches is vicious: a bowtie
/// fills the wrong region AND throws its inset points far outside the shape, so the bevel grows
/// corner hooks and the ink check reports a clipping error two steps downstream of the real cause.
function bor_st_turning(_pts_in) {
    var _pts = bor_st_dedupe(_pts_in);
    var _n = array_length(_pts);
    if (_n < 3) return 0;
    var _sum = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _pts[_i];
        var _b = _pts[(_i + 1) % _n];
        var _c = _pts[(_i + 2) % _n];
        var _a1 = arctan2(_b[1] - _a[1], _b[0] - _a[0]);
        var _a2 = arctan2(_c[1] - _b[1], _c[0] - _b[0]);
        var _d = _a2 - _a1;
        while (_d >  pi) _d -= BOR_TAU;
        while (_d < -pi) _d += BOR_TAU;
        _sum += _d;
    }
    return abs(_sum) / BOR_TAU;
}

/// The mean absolute difference between two silhouette polylines sampled at the same columns.
/// Both come from bor_building_silhouette, so they are already 49 points left to right.
function bor_st_sil_distance(_a, _b) {
    var _n = min(array_length(_a), array_length(_b));
    if (_n == 0) return 0;
    var _sum = 0;
    for (var _i = 0; _i < _n; _i++) _sum += abs(_a[_i][1] - _b[_i][1]);
    return _sum / _n;
}

/// Bounds of a part list, as [x0,y0,x1,y1].
function bor_st_bounds(_parts) {
    return bor_render_bounds(_parts);
}

/// The settlement states the suite runs every role against. Chosen to bracket the state model:
/// a poor young village, a rich old town, and a ruined one.
function bor_st_states() {
    var _a = bor_settlement_create(11);
    _a.prosperity = 0.15; _a.wealth = 0; _a.age = 0.05; _a.damage = 0.0;
    _a.region = "lowland"; bor_settlement_derive(_a);

    var _b = bor_settlement_create(22);
    _b.prosperity = 0.95; _b.wealth = 4; _b.age = 0.85; _b.damage = 0.0;
    _b.region = "alpine"; bor_settlement_derive(_b);

    var _c = bor_settlement_create(33);
    _c.prosperity = 0.40; _c.wealth = 2; _c.age = 0.60; _c.damage = 0.85;
    _c.region = "southern"; bor_settlement_derive(_c);

    var _d = bor_settlement_create(44);
    _d.prosperity = 0.65; _d.wealth = 3; _d.age = 0.35; _d.damage = 0.15;
    _d.region = "forest"; bor_settlement_derive(_d);

    return [_a, _b, _c, _d];
}

/// ============================================================================================
/// THE SUITE
/// ============================================================================================
function bor_selftest_run() {
    var _r = bor_st_new();
    var _out = {};

    // ---- STAGE 0. THE INSTRUMENTS MUST BE ABLE TO FAIL ---------------------------------------
    // ⛔ AN INSTRUMENT THAT CANNOT RETURN A BAD VERDICT PROVES NOTHING ABOUT WHAT IT MEASURES, and
    // this factory has shipped several: a duplicate check that passed vacuously, a subset check
    // that passed over zero entries, a "PASS" that scanned no assets. So every geometric instrument
    // in this file is handed a shape it MUST reject before it is trusted on the corpus.
    // TO MAKE IT FAIL: relax bor_is_convex's tolerance below the GML epsilon, or make the turning
    // function skip degenerate points instead of removing them.
    global.bor_stage = 0;

    var _bowtie = [[-0.3, -0.3], [0.3, 0.3], [0.3, -0.3], [-0.3, 0.3]];
    bor_st_ok(_r, bor_st_turning(_bowtie) < 0.5,
        "NEGATIVE CONTROL FAILED: a figure-of-eight was not detected as self-crossing");
    bor_st_ok(_r, !bor_is_convex([[0, 0], [0.4, 0], [0.4, 0.4], [0.2, 0.15], [0, 0.4]]),
        "NEGATIVE CONTROL FAILED: bor_is_convex accepted a concave arrowhead");
    bor_st_ok(_r, bor_is_convex(bor_box_pts(-0.2, -0.2, 0.2, 0.2)),
        "POSITIVE CONTROL FAILED: bor_is_convex rejected a box");
    bor_st_ok(_r, abs(bor_st_turning(bor_box_pts(-0.2, -0.2, 0.2, 0.2)) - 1.0) < 0.02,
        "POSITIVE CONTROL FAILED: a box did not turn through one revolution");
    bor_st_ok(_r, bor_st_sil_distance([[0, 0], [1, 0]], [[0, 1], [1, 1]]) > 0.9,
        "NEGATIVE CONTROL FAILED: the silhouette metric reported two different lines as identical");

    // ⛔ THE SINGLE-PART TRAP, ASSERTED. bor_map_roles used to return an EMPTY list when handed one
    // part instead of a list, which silently deleted the caller's mark from the picture - it cost
    // this product a door leaf and a dormer gablet on its first run. Most constructors in the layer
    // return a list; bor_ring_fill, bor_dot and bor_ring return one part, and nothing at a call
    // site distinguishes them. Both directions are asserted, because "returns something" would have
    // been satisfied by the broken version returning an empty array.
    var _one = bor_map_roles(bor_ring_fill(bor_box_pts(-0.1, -0.1, 0.1, 0.1), "m2",
                                           undefined, undefined), bor_material_map("wall"));
    bor_st_ok(_r, array_length(_one) == 1,
        "bor_map_roles dropped a SINGLE part: got " + string(array_length(_one)) + " back, not 1");
    bor_st_ok(_r, array_length(bor_map_roles([bor_dot(0, 0, 0.1, "m2"), bor_dot(0, 0, 0.1, "m3")],
                                             bor_material_map("wall"))) == 2,
        "bor_map_roles dropped parts from a two-part list");

    // ---- STAGE 1. TOP-LEVEL SCRIPT CODE RAN ---------------------------------------------------
    // ⚠️ AN ASSUMPTION ABOUT GML THAT THE PRODUCT TESTS RATHER THAN TRUSTS. The lamp globals are
    // initialised at the top level of bor_relief. If a runtime ever stops running top-level script
    // code at game start, every relief call reads an unset global and a buyer's FIRST FRAME
    // crashes. This makes that a red line in a result file instead.
    // TO MAKE IT FAIL: delete the two global.bor_lx/ly lines from bor_relief.
    global.bor_stage = 1;
    bor_st_ok(_r, variable_global_exists("bor_lx") && variable_global_exists("bor_ly"),
        "lamp globals missing - top-level script code did not run at game start");

    // ---- STAGE 2. THE EPSILON -----------------------------------------------------------------
    // ⛔ SPLIT INTO TWO CLAUSES ON PURPOSE, AND THE FIRST ONE IS THE TRAP ITSELF. The natural way to
    // write this is `_e > 0 && _e < TOL`, and the FIRST clause goes red: the difference between the
    // epsilon and zero IS the epsilon, GML therefore calls them equal, and equal is not
    // greater-than. Written as !(_e > 0) it becomes a POSITIVE test that the runtime still applies
    // an epsilon, and goes red the day a release stops. Do not repair this into one clause.
    global.bor_stage = 2;
    var _eps = math_get_epsilon();
    bor_st_ok(_r, !(_eps > 0.001), "math_get_epsilon unexpectedly large: " + string(_eps));
    bor_st_ok(_r, !(_eps > 0),
        "epsilon no longer participates in comparisons - re-read every tolerance in the package");
    _out.epsilon = _eps;

    // ---- STAGE 3. THE CORPUS IS THE SIZE THE LISTING WILL CLAIM -------------------------------
    // ⛔ AUTHOR THE COUNT, MEASURE THE COUNT, THEN WRITE THE COUNT. A sibling product's record had
    // to correct a "44 forms" claim down to 43 and a "40+ distinct" claim down to 29 because the
    // copy was written from the design document rather than from the suite. Whatever this stage
    // reports is what the store page may say, and nothing else.
    global.bor_stage = 3;
    var _roles    = bor_role_names();
    var _roofs    = bor_roof_names();
    var _rhythms  = bor_rhythm_names();
    var _doors    = bor_door_names();
    var _walls    = bor_wall_names();
    var _mats     = bor_material_names();
    var _regions  = bor_region_names();
    var _trades   = bor_trade_names();

    _out.roles   = array_length(_roles);
    _out.roofs   = array_length(_roofs);
    _out.rhythms = array_length(_rhythms);
    _out.doors   = array_length(_doors);
    _out.walls   = array_length(_walls);
    _out.mats    = array_length(_mats);
    _out.regions = array_length(_regions);
    _out.trades  = array_length(_trades);
    _out.forms   = _out.roles + _out.roofs + _out.rhythms + _out.doors + _out.walls;

    bor_st_ok(_r, _out.roles   == 14, "role count moved: " + string(_out.roles));
    bor_st_ok(_r, _out.roofs   == 10, "roof count moved: " + string(_out.roofs));
    bor_st_ok(_r, _out.rhythms ==  8, "rhythm count moved: " + string(_out.rhythms));
    bor_st_ok(_r, _out.doors   ==  6, "door count moved: " + string(_out.doors));
    bor_st_ok(_r, _out.walls   ==  6, "wall count moved: " + string(_out.walls));
    bor_st_ok(_r, _out.mats    == BOR_MAT_N, "material count moved: " + string(_out.mats));

    // Every name list must resolve to a REAL spec, not to the switch's default. A name that falls
    // through returns a generic shape and the corpus silently shrinks by one.
    // TO MAKE IT FAIL: rename a case label in bor_role_spec without renaming it in bor_role_names.
    for (var _i = 0; _i < array_length(_mats); _i++) {
        var _sp = bor_material_spec(_mats[_i]);
        var _def = bor_material_spec("__no_such_material__");
        bor_st_ok(_r, !(abs(_sp.L - _def.L) < BOR_ST_EPS && abs(_sp.C - _def.C) < BOR_ST_EPS
                        && abs(_sp.h - _def.h) < BOR_ST_EPS),
            "material '" + _mats[_i] + "' falls through to the default spec");
    }

    // ---- STAGE 4. EVERY TRADE CAN BUILD A STREET ----------------------------------------------
    // A trade whose role list is empty, or names a role that does not exist, produces an EMPTY
    // street with no error at all. That is the silent failure this wing keeps recording.
    global.bor_stage = 4;
    for (var _i = 0; _i < array_length(_trades); _i++) {
        var _tr = bor_trade_roles(_trades[_i]);
        bor_st_ok(_r, array_length(_tr) >= 4,
            "trade '" + _trades[_i] + "' offers only " + string(array_length(_tr)) + " role(s)");
        for (var _k = 0; _k < array_length(_tr); _k++) {
            var _found = false;
            for (var _q = 0; _q < array_length(_roles); _q++) {
                if (_roles[_q] == _tr[_k]) { _found = true; break; }
            }
            bor_st_ok(_r, _found,
                "trade '" + _trades[_i] + "' names role '" + _tr[_k] + "' which is not in the corpus");
        }
    }

    // ---- STAGE 5. REGION IS A SILHOUETTE, NOT A PALETTE SWAP ----------------------------------
    // ⛔ THE PRODUCT'S OWN HEADLINE RISK. If region ever collapses to a hue shift, the whole claim
    // fails and nothing else in this file would notice. So: every pair of regions must differ in
    // roof pitch, in parapet treatment, or in gable orientation.
    // TO MAKE IT FAIL: give two regions the same pitch, parapet flag and gable flag.
    global.bor_stage = 5;
    for (var _i = 0; _i < array_length(_regions); _i++) {
        for (var _k = _i + 1; _k < array_length(_regions); _k++) {
            var _ra = _regions[_i], _rb = _regions[_k];
            var _diff = (abs(bor_region_pitch(_ra) - bor_region_pitch(_rb)) > 0.02)
                     || (bor_region_parapet(_ra) != bor_region_parapet(_rb))
                     || (bor_region_gable_front(_ra) != bor_region_gable_front(_rb));
            bor_st_ok(_r, _diff,
                "regions '" + _ra + "' and '" + _rb + "' differ only in colour");
        }
    }

    // ---- STAGE 6. EVERY MASS IS CONVEX AND SIMPLE ---------------------------------------------
    // ⛔ THE FAN PRECONDITION, AND THE ONLY INSTRUMENT THAT CAN SEE IT. bor_ring_fill is a triangle
    // fan whose documented precondition is a star-shaped outline; hand it a concave shape and it
    // spans the concavity in silence, with no error and no failed assertion. This wing shipped
    // every moon crescent of a previous product as a quarter for exactly that reason.
    // TO MAKE IT FAIL: return a single L-shaped outline from any case in bor_massing_build.
    global.bor_stage = 6;
    var _states = bor_st_states();
    var _massn = 0;
    for (var _s = 0; _s < array_length(_states); _s++) {
        for (var _i = 0; _i < array_length(_roles); _i++) {
            var _ms = bor_massing_build(_roles[_i], _states[_s]);
            bor_st_ok(_r, array_length(_ms) >= 1,
                "role '" + _roles[_i] + "' produced no masses at state " + string(_s));
            bor_st_ok(_r, bor_massing_main(_ms).kind == "main",
                "role '" + _roles[_i] + "' has no mass of kind 'main'");
            for (var _k = 0; _k < array_length(_ms); _k++) {
                _massn++;
                bor_st_ok(_r, bor_is_convex(_ms[_k].pts),
                    "CONCAVE MASS: role '" + _roles[_i] + "' mass " + string(_k)
                    + " at state " + string(_s) + " - a fan will span it");
                var _t = bor_st_turning(_ms[_k].pts);
                bor_st_ok(_r, abs(_t - 1.0) < 0.05,
                    "SELF-CROSSING MASS: role '" + _roles[_i] + "' mass " + string(_k)
                    + " turns " + string_format(_t, 1, 3) + " revolutions, expected 1");
            }
        }
    }
    _out.masses_checked = _massn;
    // ⛔ AND THE COUNT MUST BE NON-ZERO. An `every()` over an empty set is vacuously true and this
    // factory has shipped exactly that failure. If the loop above ran on nothing, say so.
    bor_st_ok(_r, _massn >= 60,
        "the convexity stage checked only " + string(_massn) + " masses - it proved nothing");

    // ---- STAGE 7. EVERY ROOF FORM BUILDS, AND ITS MASSES ARE CONVEX ---------------------------
    // TO MAKE IT FAIL: build a crow-stepped gable as one crenellated outline instead of a stack.
    global.bor_stage = 7;
    var _roofn = 0;
    for (var _s = 0; _s < array_length(_states); _s++) {
        for (var _i = 0; _i < array_length(_roofs); _i++) {
            var _rf = bor_roof_build(_roofs[_i], -0.30, 0.30, 0.05, _states[_s], true);
            bor_st_ok(_r, array_length(_rf.masses) >= 1,
                "roof '" + _roofs[_i] + "' produced no masses");
            bor_st_ok(_r, _rf.ridge <= _rf.eave + BOR_ST_EPS,
                "roof '" + _roofs[_i] + "' has its ridge BELOW its eave");
            for (var _k = 0; _k < array_length(_rf.masses); _k++) {
                _roofn++;
                bor_st_ok(_r, bor_is_convex(_rf.masses[_k].pts),
                    "CONCAVE ROOF MASS: '" + _roofs[_i] + "' mass " + string(_k)
                    + " at state " + string(_s));
            }
        }
    }
    _out.roof_masses_checked = _roofn;
    bor_st_ok(_r, _roofn >= 40,
        "the roof stage checked only " + string(_roofn) + " masses - it proved nothing");

    // ---- STAGE 8. EVERY OPENING HEAD IS CONVEX ------------------------------------------------
    // An arched head is a box with an arc bulging OUT of it, which is convex. A scalloped or
    // ogee head would not be, and would go through the same fan.
    global.bor_stage = 8;
    for (var _w = 0; _w <= 4; _w++) {
        var _op = bor_opening_pts(-0.05, -0.10, 0.05, 0.02, _w);
        bor_st_ok(_r, bor_is_convex(_op), "opening head at wealth " + string(_w) + " is concave");
        bor_st_ok(_r, abs(bor_st_turning(_op) - 1.0) < 0.05,
            "opening head at wealth " + string(_w) + " is self-crossing");
    }

    // ---- STAGE 9. EVERY BUILDING STAYS INSIDE THE BOX IT IS GIVEN -----------------------------
    // ⚠️ A PUBLIC DRAW CALL THAT TAKES A RECT MUST BE ASSERTED TO STAY INSIDE IT. A sibling product
    // shipped a draw call that bled outside its rect into the neighbouring cell, which in a buyer's
    // game paints over whatever sits beside it. "It looked fine" only ever tested the one rect that
    // happened to be big enough.
    // TO MAKE IT FAIL: raise BOR_STOREY_MAX so a four-storey tenement outgrows the unit box.
    global.bor_stage = 9;
    var _partn = 0;
    for (var _s = 0; _s < array_length(_states); _s++) {
        for (var _i = 0; _i < array_length(_roles); _i++) {
            var _b = bor_building_create(_states[_s], _roles[_i], _i);
            var _ps = bor_building_parts(_b);
            _partn += array_length(_ps);
            bor_st_ok(_r, array_length(_ps) >= 20,
                "role '" + _roles[_i] + "' drew only " + string(array_length(_ps))
                + " parts at state " + string(_s) + " - it is not a building");
            // ⛔ EVERY ENTRY MUST BE A PART, NOT A NESTED LIST. array_push where bor_append was
            // meant produces a list inside a list; the renderer then tries to switch on an array
            // and dies with "I32 argument is array" - two steps downstream of the real mistake.
            // This names the role and the index instead.
            for (var _q = 0; _q < array_length(_ps); _q++) {
                if (is_array(_ps[_q])) {
                    bor_st_ok(_r, false, "role '" + _roles[_i] + "' part " + string(_q)
                        + " is a NESTED LIST - array_push where bor_append was meant");
                    break;
                }
            }
            var _bb = bor_st_bounds(_ps);
            bor_st_ok(_r, _bb[0] > -BOR_ST_BOX && _bb[1] > -BOR_ST_BOX
                       && _bb[2] <  BOR_ST_BOX && _bb[3] <  BOR_ST_BOX,
                "role '" + _roles[_i] + "' at state " + string(_s) + " leaves the unit box: ["
                + string_format(_bb[0], 1, 3) + "," + string_format(_bb[1], 1, 3) + ","
                + string_format(_bb[2], 1, 3) + "," + string_format(_bb[3], 1, 3) + "]");
        }
    }
    _out.parts_checked = _partn;
    bor_st_ok(_r, _partn >= 2000,
        "the parts stage counted only " + string(_partn) + " parts across the corpus");

    // ---- STAGE 10. THE FOURTEEN ROLES ARE FOURTEEN SHAPES -------------------------------------
    // ⛔ THE VOLUME CLAIM, MEASURED. The listing may say the roles are distinct only because this
    // passes. Silhouette, not parameter: two roles that differ only in a colour or a count would
    // fail here, which is the whole point.
    // TO MAKE IT FAIL: give two roles the same halfw, storeys and wing in bor_role_spec.
    global.bor_stage = 10;
    var _stD = _states[3];
    var _sils = array_create(array_length(_roles));
    for (var _i = 0; _i < array_length(_roles); _i++) {
        _sils[_i] = bor_building_silhouette(bor_building_create(_stD, _roles[_i], 0));
    }
    var _worst = 999, _worst_a = "", _worst_b = "", _pairs = 0;
    for (var _i = 0; _i < array_length(_roles); _i++) {
        for (var _k = _i + 1; _k < array_length(_roles); _k++) {
            var _d = bor_st_sil_distance(_sils[_i], _sils[_k]);
            _pairs++;
            if (_d < _worst) { _worst = _d; _worst_a = _roles[_i]; _worst_b = _roles[_k]; }
            bor_st_ok(_r, _d > BOR_ST_ROLE_FLOOR,
                "roles '" + _roles[_i] + "' and '" + _roles[_k] + "' have the same silhouette ("
                + string_format(_d, 1, 4) + ")");
        }
    }
    _out.role_pairs = _pairs;
    _out.role_min_sep = _worst;
    _out.role_closest = _worst_a + "/" + _worst_b;
    bor_st_ok(_r, _pairs == 91, "expected 91 role pairs, compared " + string(_pairs));

    // ---- STAGE 11. THE PALETTE RESOLVES EVERY ROLE THE CORPUS EMITS ---------------------------
    // ⛔ bor_render_colour FALLS BACK TO _pal.line FOR AN UNKNOWN ROLE, so a typo does not crash -
    // it draws a whole roof in the ink colour and looks like a shading bug. This is the only check
    // that can see it.
    // ⚠️ THE NON-EMPTY GUARD IS NOT DECORATION. A subset check over zero extracted entries passes
    // vacuously and this factory has shipped one.
    global.bor_stage = 11;
    var _pal = bor_palette_build(_stD);
    var _names = bor_palette_roles(_pal);
    bor_st_ok(_r, array_length(_names) >= 40,
        "the palette holds only " + string(array_length(_names)) + " roles - the check is vacuous");

    var _used = bor_roles_used(bor_building_parts(bor_building_create(_stD, "inn", 0)));
    bor_st_ok(_r, array_length(_used) >= 8,
        "an inn used only " + string(array_length(_used)) + " roles - the check is vacuous");
    _out.roles_used = array_length(_used);
    for (var _i = 0; _i < array_length(_used); _i++) {
        bor_st_ok(_r, variable_struct_exists(_pal, _used[_i]),
            "palette has no role '" + _used[_i] + "' - it will draw in the ink colour");
    }

    // ---- STAGE 12. A MATERIAL RAMP IS FIVE MONOTONIC, SEPARATED STOPS -------------------------
    // A ramp whose stops are not ordered lights a wall from the wrong side; a ramp whose stops are
    // too close makes relief invisible, which is the "flat and boxy" failure this product exists to
    // avoid. Both are checked, on every material, at three wear levels.
    global.bor_stage = 12;
    var _rampn = 0;
    for (var _i = 0; _i < array_length(_mats); _i++) {
        for (var _wi = 0; _wi < 3; _wi++) {
            var _ramp = bor_material_ramp(_mats[_i], _wi * 0.45, 0);
            _rampn++;
            bor_st_ok(_r, array_length(_ramp) == BOR_RAMP_N,
                "material '" + _mats[_i] + "' ramp is not " + string(BOR_RAMP_N) + " stops");
            var _mono = true, _sep = true;
            for (var _k = 1; _k < BOR_RAMP_N; _k++) {
                var _lo = colour_get_value(_ramp[_k - 1]);
                var _hi = colour_get_value(_ramp[_k]);
                if (_hi < _lo) _mono = false;
                if (abs(_hi - _lo) < 4) _sep = false;
            }
            bor_st_ok(_r, _mono, "material '" + _mats[_i] + "' ramp is not monotonic at wear "
                + string(_wi));
            bor_st_ok(_r, _sep, "material '" + _mats[_i] + "' ramp stops are indistinguishable at "
                + "wear " + string(_wi) + " - relief will be invisible");
        }
    }
    _out.ramps_checked = _rampn;

    // ---- STAGE 13. THE STATE MODEL MOVES THE PICTURE ------------------------------------------
    // ⛔ THE PRODUCT'S ENTIRE PROMISE IN ONE STAGE: step the settlement and the building must come
    // out DIFFERENT. A state model that advances numbers nothing reads is the failure that would
    // make every word of the listing false, and it is invisible to every other check here.
    // TO MAKE IT FAIL: stop bor_settlement_derive from recomputing wall_mat and roof_mat.
    global.bor_stage = 13;
    var _young = bor_settlement_create(77);
    _young.prosperity = 0.20; _young.wealth = 0; _young.age = 0.02; _young.damage = 0.0;
    _young.region = "lowland"; bor_settlement_derive(_young);
    var _sil_young = bor_building_silhouette(bor_building_create(_young, "townhouse", 0));
    var _parts_young = array_length(bor_building_parts(bor_building_create(_young, "townhouse", 0)));

    var _old = bor_settlement_create(77);
    _old.prosperity = 0.20; _old.wealth = 0; _old.age = 0.02; _old.damage = 0.0;
    _old.region = "lowland"; bor_settlement_derive(_old);
    bor_settlement_step(_old, 200, 1.0);
    var _sil_old = bor_building_silhouette(bor_building_create(_old, "townhouse", 0));
    var _parts_old = array_length(bor_building_parts(bor_building_create(_old, "townhouse", 0)));

    bor_st_ok(_r, _old.age > _young.age + 0.5, "200 years did not age the settlement");
    bor_st_ok(_r, _old.prosperity > _young.prosperity + 0.3,
        "a strong positive trend over 200 years did not raise prosperity");
    bor_st_ok(_r, _old.wealth > _young.wealth, "prosperity never carried wealth upward");
    bor_st_ok(_r, bor_st_sil_distance(_sil_young, _sil_old) > BOR_ST_ROLE_FLOOR,
        "the same building is the SAME SHAPE before and after two centuries of growth");
    bor_st_ok(_r, _parts_old != _parts_young,
        "the same building draws the same number of parts before and after two centuries");
    _out.growth_sep = bor_st_sil_distance(_sil_young, _sil_old);
    _out.parts_young = _parts_young;
    _out.parts_old = _parts_old;

    // Damage must show, and it must show DIFFERENTLY from age.
    var _burnt = bor_settlement_create(77);
    _burnt.prosperity = 0.20; _burnt.wealth = 0; _burnt.age = 0.02; _burnt.damage = 0.0;
    _burnt.region = "lowland"; bor_settlement_derive(_burnt);
    bor_settlement_damage(_burnt, 0.80);
    var _parts_burnt = array_length(bor_building_parts(bor_building_create(_burnt, "townhouse", 0)));
    bor_st_ok(_r, _burnt.damage > 0.7, "a shock of 0.80 did not register as damage");
    bor_st_ok(_r, _parts_burnt != _parts_young, "damage changed nothing about the drawn building");
    _out.parts_burnt = _parts_burnt;

    // ---- STAGE 14. A STREET IS A STREET -------------------------------------------------------
    global.bor_stage = 14;
    for (var _s = 0; _s < array_length(_states); _s++) {
        var _row = bor_street_build(_states[_s], 8);
        bor_st_ok(_r, array_length(_row) == 8,
            "a street of 8 came back with " + string(array_length(_row)));
        bor_st_ok(_r, bor_street_width(_row) > 1.0,
            "a street of 8 buildings is less than one unit box wide");
        // No building may be degenerate - a zero-width plot would silently swallow its neighbours.
        for (var _i = 0; _i < array_length(_row); _i++) {
            bor_st_ok(_r, (_row[_i].xr - _row[_i].xl) > 0.10,
                "building " + string(_i) + " on street " + string(_s) + " has no width");
        }
    }

    // ---- WRITE THE RESULT ---------------------------------------------------------------------
    // ✅ THE ONE ROUTE THAT WORKS HEADLESS. show_debug_message with -debugoutput is dead in a
    // release build, and game_end(n) does not propagate its argument. A JSON file under
    // %LOCALAPPDATA%\<Game>\ needs no runner flag and survives release.
    var _s2 = "{\"pass\":" + string(_r.pass) + ",\"fail\":" + string(_r.fail)
        + ",\"epsilon\":" + string_format(_out.epsilon, 1, 12)
        + ",\"roles\":" + string(_out.roles)
        + ",\"roofs\":" + string(_out.roofs)
        + ",\"rhythms\":" + string(_out.rhythms)
        + ",\"doors\":" + string(_out.doors)
        + ",\"walls\":" + string(_out.walls)
        + ",\"materials\":" + string(_out.mats)
        + ",\"regions\":" + string(_out.regions)
        + ",\"trades\":" + string(_out.trades)
        + ",\"counted_forms\":" + string(_out.forms)
        + ",\"masses_checked\":" + string(_out.masses_checked)
        + ",\"roof_masses_checked\":" + string(_out.roof_masses_checked)
        + ",\"parts_checked\":" + string(_out.parts_checked)
        + ",\"ramps_checked\":" + string(_out.ramps_checked)
        + ",\"role_pairs\":" + string(_out.role_pairs)
        + ",\"role_min_sep\":" + string_format(_out.role_min_sep, 1, 4)
        + ",\"role_closest\":\"" + _out.role_closest + "\""
        + ",\"roles_used\":" + string(_out.roles_used)
        + ",\"growth_sep\":" + string_format(_out.growth_sep, 1, 4)
        + ",\"parts_young\":" + string(_out.parts_young)
        + ",\"parts_old\":" + string(_out.parts_old)
        + ",\"parts_burnt\":" + string(_out.parts_burnt)
        + ",\"failures\":[";
    for (var _i = 0; _i < array_length(_r.failures); _i++) {
        if (_i > 0) _s2 += ",";
        _s2 += "\"" + string_replace_all(_r.failures[_i], "\"", "'") + "\"";
    }
    _s2 += "]}";

    var _f = file_text_open_write("bor_selftest.json");
    file_text_write_string(_f, _s2);
    file_text_close(_f);
    return _r;
}
