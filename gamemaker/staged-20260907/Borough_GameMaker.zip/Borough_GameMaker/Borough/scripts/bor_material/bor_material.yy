{
  "$GMScript": "v1",
  "%Name": "bor_material",
  "isCompatibility": false,
  "isDnD": false,
  "name": "bor_material",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}