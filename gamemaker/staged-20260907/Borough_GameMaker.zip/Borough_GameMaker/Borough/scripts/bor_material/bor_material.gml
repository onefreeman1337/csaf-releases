/// BOROUGH - bor_material. The materials a building is made of, as five-stop relief ramps.
///
/// Every colour in this product comes from here, and every one of them is COMPUTED. There is no
/// palette table of hex values in this package, because a hex table is a thing a buyer cannot
/// steer: ask it for "the same limestone, twenty years dirtier" and it has no answer.
///
/// -- WHAT A RAMP IS --------------------------------------------------------------------------
/// bor_relief shades a wall by how squarely it faces the lamp and returns one of five role names,
/// "m0" (facing away) through "m4" (facing the lamp). A MATERIAL is therefore five colours, and
/// bor_material_ramp() is the function that produces them. Give the same material two different
/// wear values and you get two ramps that are recognisably the same stone at different ages.
///
/// ⛔ THE STOPS ARE SPACED IN OKLAB LIGHTNESS, NOT IN RGB. That is the whole reason bor_palette
/// exists, and it is not decoration: five RGB-spaced stops on warm ochre plaster and five on cold
/// grey ashlar have visibly different contrast, and those two materials stand SIDE BY SIDE on the
/// same street in this product. Perceptual spacing is what lets one lamp light both correctly.
///
/// -- HOW A SECOND MATERIAL GETS ITS OWN RAMP -------------------------------------------------
/// bor_relief always emits m0..m4. A roof and the wall under it are different materials, so the
/// roof's parts are built in m0..m4 and then REMAPPED, once, at construction:
///
///     var _roof = bor_map_roles(bor_raise(_pts, 0.02, 2), bor_material_map("roof"));
///
/// bor_map_roles produces a new part list, which is exactly right for a property decided when the
/// building is created and never changed again. Do NOT use the renderer's draw-time role map for
/// this - that one is for drawing a mark in a borrowed palette just once.
///
/// ⚠️ EVERY PREFIX USED IN A MAP MUST EXIST IN THE PALETTE. bor_render_colour falls back to
/// _pal.line for an unknown role, so a typo does not crash - it draws the whole roof in the ink
/// colour and looks like a shading bug. bor_selftest asserts that every role any corpus form emits
/// resolves in the palette, which is the only way to catch it.
/// ============================================================================================

/// The materials. Each is a name, a base lightness, a chroma, a hue in degrees, and how far the
/// ramp spans in lightness. A high span reads as a hard, glossy surface (slate, glass, iron); a
/// low span reads as a soft matte one (thatch, limewash, cob).
///
/// ⚠️ THE SPAN IS THE MATERIAL, MORE THAN THE HUE IS. Thatch and slate at the same span read as
/// the same stuff in two colours, which is the palette-swap failure this product exists to avoid.
#macro BOR_MAT_N 14

function bor_material_spec(_mat) {
    switch (_mat) {
        // name        L      C      hue    span   the surface being described
        case "rubble":  return { L: 0.560, C: 0.016, h:  74, span: 0.30 }; // undressed field stone
        case "ashlar":  return { L: 0.720, C: 0.020, h:  82, span: 0.22 }; // dressed pale limestone
        case "brick":   return { L: 0.480, C: 0.075, h:  38, span: 0.26 }; // fired red brick
        case "timber":  return { L: 0.330, C: 0.040, h:  62, span: 0.34 }; // oak framing, dark
        case "render":  return { L: 0.790, C: 0.022, h:  88, span: 0.18 }; // limewash over daub
        case "cob":     return { L: 0.620, C: 0.048, h:  68, span: 0.16 }; // earth and straw
        case "slate":   return { L: 0.400, C: 0.014, h: 250, span: 0.36 }; // riven slate, cold
        case "tile":    return { L: 0.450, C: 0.086, h:  34, span: 0.28 }; // clay pantile, warm
        case "thatch":  return { L: 0.560, C: 0.060, h:  78, span: 0.14 }; // straw, matte, no sheen
        case "lead":    return { L: 0.520, C: 0.008, h: 250, span: 0.38 }; // sheet lead, flashing
        case "iron":    return { L: 0.260, C: 0.010, h: 250, span: 0.44 }; // hinges, brackets, tie
        case "glass":   return { L: 0.380, C: 0.028, h: 220, span: 0.46 }; // glazing, dark and hard
        case "paint":   return { L: 0.470, C: 0.110, h: 150, span: 0.24 }; // signboard, hue varies
        case "street":  return { L: 0.430, C: 0.012, h:  80, span: 0.20 }; // paving and mud
    }
    return { L: 0.500, C: 0.020, h: 80, span: 0.26 };
}

/// The material names, in corpus order. Used by the self-test and the store sheets so that neither
/// can drift from the switch above without going red.
function bor_material_names() {
    return ["rubble", "ashlar", "brick", "timber", "render", "cob", "slate",
            "tile", "thatch", "lead", "iron", "glass", "paint", "street"];
}

/// Five stops for one material at one wear level.
///
/// _wear is 0..1 and does three things at once, because that is what dirt does: it DARKENS the
/// surface, it DESATURATES it, and it COMPRESSES the ramp. The third is the one that matters and
/// the one a naive implementation misses - a weathered wall is not just a darker wall, it is a
/// wall whose lit and shadowed faces have moved closer together, because the surface has stopped
/// being smooth enough to catch the lamp cleanly. A soot-black wall with a bright highlight on it
/// reads as wet plastic.
///
/// _hue_shift lets one material serve a whole region without becoming a palette swap: the SAME
/// limestone runs cool grey in the north and warm sand in the south, which is a real difference
/// between real quarries, not a recolour of one texture.
function bor_material_ramp(_mat, _wear, _hue_shift) {
    var _s = bor_material_spec(_mat);
    var _w = clamp(_wear, 0, 1);
    var _hs = is_undefined(_hue_shift) ? 0 : _hue_shift;

    // Darken, desaturate, compress. The three coefficients are the material law above.
    var _L = _s.L * (1 - 0.30 * _w);
    var _C = _s.C * (1 - 0.55 * _w);
    var _span = _s.span * (1 - 0.45 * _w);

    var _out = array_create(BOR_RAMP_N);
    for (var _i = 0; _i < BOR_RAMP_N; _i++) {
        // -0.5 .. +0.5 across the five stops, so the nominal L stays the mid stop and a material
        // spec can be read as "the colour of the surface" rather than "the colour of its shadow".
        var _t = (_i / (BOR_RAMP_N - 1)) - 0.5;
        var _Li = clamp(_L + _span * _t, 0.05, 0.97);
        // Chroma falls in the shadows, as it does in life: a dark face of a red brick wall is
        // browner than its lit face, never a more saturated red.
        var _Ci = _C * (1 + 0.35 * _t);
        _out[_i] = bor_oklch(_Li, max(0, _Ci), _s.h + _hs);
    }
    return _out;
}

/// The role map that points bor_relief's m0..m4 at a named ramp in the palette.
///
/// Returned as a fresh struct every call rather than cached, because bor_map_roles reads it once
/// and a shared mutable map is the kind of thing that works until two buildings are built in the
/// same frame.
function bor_material_map(_prefix) {
    return {
        m0: _prefix + "0", m1: _prefix + "1", m2: _prefix + "2",
        m3: _prefix + "3", m4: _prefix + "4",
    };
}

/// Write one material's five stops into a palette struct under a prefix.
function bor_material_into(_pal, _prefix, _mat, _wear, _hue_shift) {
    var _r = bor_material_ramp(_mat, _wear, _hue_shift);
    for (var _i = 0; _i < BOR_RAMP_N; _i++) {
        variable_struct_set(_pal, _prefix + string(_i), _r[_i]);
    }
    return _pal;
}

/// ============================================================================================
/// THE SETTLEMENT PALETTE
///
/// One struct holding every ramp a street needs. Built once per settlement, handed to every draw
/// call, and never rebuilt per frame - it is about sixty colour conversions and there is no reason
/// to pay for them sixty times a second.
///
/// ⚠️ THE FLAT ROLES AT THE BOTTOM ARE NOT RELIEF ROLES and must not be shaded. `glass` is one
/// colour because a window pane is one plane; giving it a five-stop ramp would light the inside of
/// a building from the outside lamp, which is the tell that says "this is a texture, not a room".
/// ============================================================================================
function bor_palette_build(_st) {
    // Guard: refuse rather than throw (2026-09-07).
    // ⛔ `undefined`, NOT A DEFAULT PALETTE, AND THE CHOICE IS THE WHOLE POINT. A generic palette is
    // the most tempting refusal in this package and the worst one: the street would draw, in
    // plausible colours, and a buyer would ship a town whose materials have nothing to do with its
    // state. Every draw entry point tests bor_is_palette and draws nothing, so the refusal
    // propagates as an empty rect rather than as a wrong picture.
    if (!bor_is_settlement(_st)) return undefined;

    var _age = clamp(_st.age, 0, 1);
    var _dmg = clamp(_st.damage, 0, 1);
    var _pros = clamp(_st.prosperity, 0, 1);

    // Wear is age plus damage, and damage counts for more: a burnt gable is dirtier at five years
    // than an untouched wall is at two hundred.
    var _wear = clamp(_age * 0.55 + _dmg * 0.75, 0, 1);

    // The regional hue shift. Applied to the EARTH materials only - stone, brick, render, cob and
    // the roofs - because those are the ones that come out of a local quarry, kiln or field. Lead,
    // iron and glass are traded goods and look the same everywhere, which is itself a real thing
    // about pre-industrial building and reads correctly without being explained.
    var _hs = _st.hue_shift;

    var _pal = {};

    bor_material_into(_pal, "wall",   _st.wall_mat,  _wear,               _hs);
    bor_material_into(_pal, "roof",   _st.roof_mat,  _wear * 1.15,        _hs);
    bor_material_into(_pal, "stone",  "ashlar",      _wear * 0.70,        _hs);
    bor_material_into(_pal, "beam",   "timber",      _wear,               _hs * 0.5);
    bor_material_into(_pal, "iron",   "iron",        _wear * 0.85,        0);
    bor_material_into(_pal, "lead",   "lead",        _wear * 0.60,        0);
    bor_material_into(_pal, "street", "street",      clamp(_wear + 0.15, 0, 1), _hs);

    // m0..m4 unmapped default to the WALL, so a form that forgets to remap draws as masonry rather
    // than as the ink colour. A visible-but-wrong material is far easier to spot than a black one.
    for (var _i = 0; _i < BOR_RAMP_N; _i++) {
        variable_struct_set(_pal, "m" + string(_i),
                            variable_struct_get(_pal, "wall" + string(_i)));
    }

    // -- flat roles ------------------------------------------------------------------------------
    // Glazing goes DARKER and colder as a settlement gets poorer, because poorer glazing is thicker,
    // greener and set in smaller panes; a wealthy house has clearer, paler glass. This is one line
    // and it is one of the strongest wealth tells on the whole facade.
    _pal.glass     = bor_oklch(0.20 + 0.13 * _pros, 0.030 - 0.012 * _pros, 214);
    _pal.glass_lit = bor_oklch(0.62 + 0.16 * _pros, 0.042, 92);   // a lit window at dusk
    _pal.board     = bor_oklch(0.30, 0.030, 62);                  // boarded-up planking
    _pal.soot      = bor_oklch(0.14, 0.008, 60);
    // ⛔ MOSS WAS C=0.055 AND READ AS GREY, NOT GREEN. Measured 2026-08-28 against a cob cottage:
    // at that chroma, on a warm wall of similar lightness, the hue signal is gone and the mark says
    // "dirt" rather than "living thing". Moss at the damp foot of a wall is one of the most
    // saturated things on a building and it is DARKER than the wall it grows on, which is what makes
    // it read as sitting in front of the wall rather than as a stain in it.
    _pal.moss      = bor_oklch(0.34, 0.115, 138);
    _pal.sign      = bor_oklch(0.42, 0.105, _st.sign_hue);
    _pal.gild      = bor_oklch(0.78, 0.095, 88);                  // gilt lettering, wealth 4 only
    // ⛔ THE LABEL COLOUR IS FIXED AND IS NOT DERIVED FROM ANY MATERIAL. MEASURED 2026-08-28 by
    // rendering the hero sheet and reading it: the captions were drawn in the roof's lightest stop,
    // which on a brick town is a muddy red - two of four captions were barely legible against the
    // backdrop, on the one image a buyer decides from.
    //
    // The wing already has the general law from a medal-against-felt floor that no palette could
    // satisfy: WHEN A COLOUR CANNOT BE CHOSEN, SUSPECT THE QUESTION. There is no single label colour
    // that reads on a near-white sky band AND on a dark page, so the label does not try - it is
    // drawn light with a dark shadow under it, and the PAIR reads on both. See bor_bk_caption.
    _pal.label     = bor_oklch(0.94, 0.018, 86);
    _pal.label_sh  = bor_oklch(0.12, 0.010, 250);
    _pal.line      = bor_oklch(0.22, 0.010, 70);                  // the fallback ink
    _pal.ground    = bor_oklch(0.16, 0.014, 250);                 // page/backdrop base
    _pal.felt      = bor_oklch(0.24, 0.016, 250);                 // UI well face
    _pal.sky_hi    = bor_oklch(0.46 - 0.10 * _dmg, 0.040, 246);
    _pal.sky_lo    = bor_oklch(0.78 - 0.14 * _dmg, 0.030, 78);
    _pal.shadow    = bor_oklch(0.13, 0.012, 254);

    return _pal;
}

/// Every role name a palette built by bor_palette_build actually contains.
///
/// ⛔ THIS EXISTS SO THE SELF-TEST CAN CHECK A NON-EMPTY SET. A "every role a form emits resolves
/// in the palette" assertion is vacuously true if the role list comes back empty, and this factory
/// has shipped exactly that: a strict-subset check that passed over zero extracted entries and
/// reported clean. The suite asserts this list is long before it asserts anything with it.
function bor_palette_roles(_pal) {
    return variable_struct_get_names(_pal);
}
