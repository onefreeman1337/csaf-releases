/// BOROUGH - bor_bake. The store gallery, rendered by the product itself.
///
/// Borough.exe -bake writes every store sheet from the SHIPPED GML, using the product's own
/// palettes, its own fonts and its own public draw calls. Internal_Ops/run_engine.ps1 drives it
/// through gm_gate.ps1 and collects the PNGs.
///
/// ⛔ A GALLERY RENDERED BY A SIDE PREVIEWER IS A PICTURE OF A RE-IMPLEMENTATION. A sibling product
/// in this wing had a defect that was invisible in its JavaScript previewer and plainly visible in
/// engine. Baking is what lets the listing say, truthfully, that every image on the page was
/// rendered by the product a buyer is about to download.
///
/// -- WHAT THE CONTENT CHECK CAN AND CANNOT SEE -------------------------------------------------
/// It measures the fraction of ROWS that carry something other than that row's own leftmost pixel.
/// On a townscape that means: rows through buildings count, and rows of bare graduated backdrop do
/// not - which is exactly the reading wanted, because a sheet that is four fifths empty sky is a
/// sheet with nothing on it.
///
/// ⛔ AND IT IS BLIND IN THE ONE DIRECTION THAT MATTERS MOST: A BOUNDING BOX CANNOT SEE THE SPACE
/// INSIDE ITSELF. Three small buildings adrift on a wide page score well and look like nothing.
/// The floor catches EMPTY and CLIPPED. It cannot catch SPARSE, at any threshold, and the answer to
/// a sparse sheet is more content, never a lower number. The only instrument for that is opening
/// the PNG and looking at it, and that is a required step of every publish here.
/// ============================================================================================

/// Rows must be this fraction non-uniform for a sheet to pass.
/// ⚠️ REPORTED BESIDE ITS MEASUREMENT so it can be argued with rather than trusted.
#macro BOR_BK_CONTENT_FLOOR 0.45

/// How far a channel may drift before two pixels count as different colours.
#macro BOR_BK_TOL 6

/// The measure described in the header.
///
/// ⛔ y STEPS BY 1, NOT BY 2. This wing measured the cost of an even-only scan on another product:
/// a one-pixel rule sitting on an ODD row was walked past entirely, and a clipped hairline is
/// precisely the shape that lands on one row. x may step by 2 - nothing here draws a one-pixel-wide
/// VERTICAL feature at sheet scale.
function bor_bk_content(_surf, _w, _h) {
    var _buf = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_buf, _surf, 0);

    var _rows = 0;
    var _x0 = _w, _y0 = _h, _x1 = -1, _y1 = -1;

    for (var _y = 0; _y < _h; _y++) {
        var _base = _y * _w * 4;
        var _r0 = buffer_peek(_buf, _base, buffer_u8);
        var _g0 = buffer_peek(_buf, _base + 1, buffer_u8);
        var _b0 = buffer_peek(_buf, _base + 2, buffer_u8);
        var _hit = false;
        for (var _x = 2; _x < _w; _x += 2) {
            var _o = _base + _x * 4;
            var _rr = buffer_peek(_buf, _o, buffer_u8);
            var _gg = buffer_peek(_buf, _o + 1, buffer_u8);
            var _bb = buffer_peek(_buf, _o + 2, buffer_u8);
            if (abs(_rr - _r0) > BOR_BK_TOL || abs(_gg - _g0) > BOR_BK_TOL
             || abs(_bb - _b0) > BOR_BK_TOL) {
                _hit = true;
                if (_x < _x0) _x0 = _x;
                if (_x > _x1) _x1 = _x;
                if (_y < _y0) _y0 = _y;
                if (_y > _y1) _y1 = _y;
            }
        }
        if (_hit) _rows++;
    }
    buffer_delete(_buf);

    return { rows: _rows, frac: (_h > 0) ? (_rows / _h) : 0,
             x0: _x0, y0: _y0, x1: _x1, y1: _y1 };
}

/// Render one sheet, save it, measure it, and report.
function bor_bk_sheet(_name, _w, _h, _fn) {
    var _surf = surface_create(_w, _h);
    surface_set_target(_surf);
    draw_clear_alpha(c_black, 1);

    _fn(_w, _h);

    surface_reset_target();

    var _c = bor_bk_content(_surf, _w, _h);
    surface_save(_surf, _name + ".png");
    surface_free(_surf);

    var _ok = (_c.frac >= BOR_BK_CONTENT_FLOOR) && (_c.x1 > 0);
    var _reason = _ok ? "ok"
        : ("only " + string_format(_c.frac * 100, 1, 1) + "% of rows carry anything");

    return { sheet: _name, ok: _ok, frac: _c.frac, rows: _c.rows,
             content: [_c.x0, _c.y0, _c.x1, _c.y1], reason: _reason };
}

/// A caption. Sized from the MEASURED string, never from an assumed length.
///
/// ⛔ THIS WING HAS SHIPPED AN OVERPRINTED CAPTION TWICE - two names collided into a word that is
/// not a word, and a fix that shortened the DATA rather than the LAYOUT let it come straight back
/// on the next product. bor_text_line takes a max width and scales to it, so renaming a role can
/// never re-open it. NO INK CHECK WILL EVER CATCH THIS: overprinted text is ink exactly where ink
/// belongs. It is found by reading the sheet.
/// ⛔ LIGHT FACE OVER A DARK SHADOW, ALWAYS - NEVER ONE FLAT COLOUR. A caption on these sheets can
/// land on a near-white sky band, on a dark page, or on a brick wall, and no single colour reads on
/// all three. The pair does, because whichever the background is close to, the other one separates
/// from it. The _pal argument is taken rather than a colour so a call site cannot re-introduce a
/// material-derived label by accident.
function bor_bk_caption(_text, _x, _y, _maxw, _px, _pal) {
    bor_text_label(_text, _x, _y, _maxw, _px, _pal.label_sh, _pal.label);
}

/// A settlement built to order, for a sheet.
function bor_bk_state(_seed, _region, _trade, _pros, _wealth, _age, _damage) {
    var _st = bor_settlement_create(_seed);
    _st.region = _region; _st.trade = _trade;
    _st.prosperity = _pros; _st.wealth = _wealth; _st.age = _age; _st.damage = _damage;
    return bor_settlement_derive(_st);
}

/// The page ground for a catalogue sheet: a flat dark field the forms sit on, so the sheet reads as
/// a plate rather than as a screenshot.
function bor_bk_page(_w, _h, _pal) {
    draw_set_colour(_pal.ground);
    draw_rectangle(0, 0, _w, _h, false);
}

/// ============================================================================================
/// THE SHEETS
/// ============================================================================================
function bor_bake_run() {
    var _res = [];
    var _W = 1600, _H = 900;

    // -- 1. THE HERO: one settlement, four centuries ------------------------------------------
    // Same seed, same region, same trade. Only the state moves. This is the product's whole claim
    // in one image and it is the sheet a buyer decides on.
    array_push(_res, bor_bk_sheet("sheet_1_the_town_that_grows", _W, _H, function(_w, _h) {
        var _rows = 4;
        // ⛔ ROW 1 READ "one storey" UNTIL 2026-08-28 AND THE PICTURE SHOWED FOUR. Measured by
        // opening the sheet: at prosperity 0.15 and wealth 0 the poorest ROLES do come out low and
        // thatched, but a tenement and a guildhall are multi-storey by their own massing rule
        // whatever the town's purse, so the street has tall blocks in it and always did. The caption
        // was a specific, falsifiable claim that the image beside it contradicted - which is worse
        // than a vague one, because a buyer who notices stops believing the other three.
        // ⚠️ THE FIX IS THE CAPTION, NEVER THE DATA. Forcing every role to one storey to rescue a
        // label would have made the hero sheet a worse demonstration of the massing model in order
        // to make a sentence true.
        var _label = ["FOUNDED - thatch and cob, low eaves, no glazing",
                      "GROWING - tile arrives, a storey is added",
                      "PROSPEROUS - stone, glazing, oriels, signage",
                      "AFTER THE SIEGE - boarded, sooted, a bay down"];
        var _pros = [0.15, 0.45, 0.92, 0.30];
        var _wlth = [0, 2, 4, 2];
        var _age  = [0.03, 0.30, 0.62, 0.70];
        var _dmg  = [0.0, 0.0, 0.0, 0.78];
        var _rh = _h / _rows;
        for (var _i = 0; _i < _rows; _i++) {
            var _st = bor_bk_state(4181, "lowland", "market", _pros[_i], _wlth[_i],
                                   _age[_i], _dmg[_i]);
            var _pal = bor_palette_build(_st);
            bor_street_draw(_st, _pal, 0, _rh * _i, _w, _rh, 7);
            bor_bk_caption(_label[_i], _w * 0.018, _rh * _i + _rh * 0.055,
                           _w * 0.60, _rh * 0.115, _pal);
        }
    }));

    // -- 2. THE FOURTEEN ROLES ------------------------------------------------------------------
    array_push(_res, bor_bk_sheet("sheet_2_fourteen_roles", _W, _H, function(_w, _h) {
        var _st = bor_bk_state(2718, "lowland", "market", 0.70, 3, 0.35, 0.05);
        var _pal = bor_palette_build(_st);
        bor_bk_page(_w, _h, _pal);
        var _roles = bor_role_names();
        var _cols = 5, _rows = 3;
        var _cw = _w / _cols, _ch = (_h - _h * 0.10) / _rows;
        bor_bk_caption("FOURTEEN BUILDING ROLES - EVERY ONE COMPOSED FROM THE SAME TOWN",
                       _w * 0.018, _h * 0.025, _w * 0.96, _h * 0.048, _pal);
        for (var _i = 0; _i < array_length(_roles); _i++) {
            var _cx = (_i % _cols) * _cw;
            var _cy = _h * 0.10 + floor(_i / _cols) * _ch;
            var _b = bor_building_create(_st, _roles[_i], _i);
            bor_street_draw_one(_b, _pal, _cx + _cw * 0.06, _cy, _cw * 0.88, _ch * 0.80);
            bor_bk_caption(string_upper(_roles[_i]), _cx + _cw * 0.06, _cy + _ch * 0.84,
                           _cw * 0.88, _ch * 0.095, _pal);
        }
    }));

    // -- 3. THE TEN ROOF FORMS ------------------------------------------------------------------
    array_push(_res, bor_bk_sheet("sheet_3_ten_roofs", _W, _H, function(_w, _h) {
        var _st = bor_bk_state(1618, "upland", "market", 0.65, 3, 0.30, 0.0);
        var _pal = bor_palette_build(_st);
        bor_bk_page(_w, _h, _pal);
        var _forms = bor_roof_names();
        var _cols = 5, _rows = 2;
        var _cw = _w / _cols, _ch = (_h - _h * 0.10) / _rows;
        bor_bk_caption("TEN ROOF FORMS - THE SILHOUETTE, NOT THE COLOUR",
                       _w * 0.018, _h * 0.025, _w * 0.96, _h * 0.048, _pal);
        // ⚠️ FULL WALL, AND THE CELL IS FILLED BY MEASURED BOUNDS. Two corrections, in order, both
        // measured on 2026-08-28 by rendering this sheet and looking at it.
        //
        // First the cell was filled by the UNIT BOX, so the roof - the entire subject - was a fifth
        // of each cell and the sheet was 61% empty. Then the wall was cut to a stub to give the roof
        // the frame, and the sheet got WORSE: a stub and a roof together are wide and short, so tight
        // fitting became width-bound and the content still only filled a third of the cell height.
        //
        // The full wall is the right answer to both, and it is worth stating why, because the
        // instinct was backwards. A roof plus a full wall has an ASPECT close to the cell's, so the
        // tight fit is no longer width-bound and everything gets bigger - INCLUDING the roof, which
        // ends up with more pixels than the stub version gave it. Shrinking the subject's
        // surroundings to feature the subject made the subject smaller.
        for (var _i = 0; _i < array_length(_forms); _i++) {
            var _cx = (_i % _cols) * _cw;
            var _cy = _h * 0.10 + floor(_i / _cols) * _ch;
            var _r = bor_roof_build(_forms[_i], -0.30, 0.30, 0.06, _st, true);
            var _parts = [];
            bor_append(_parts, bor_map_roles(
                bor_raise(bor_box_pts(-0.30, 0.06, 0.30, BOR_GROUND), 0.016, 2, "wall2"),
                bor_material_map("wall")));
            bor_append(_parts, bor_wall_build("ashlar", -0.29, 0.07, 0.29, 0.43, _st));
            for (var _k = 0; _k < array_length(_r.masses); _k++) {
                bor_append(_parts, bor_map_roles(
                    bor_raise(_r.masses[_k].pts, 0.014, 2, _r.masses[_k].mat + "3"),
                    bor_material_map(_r.masses[_k].mat)));
            }
            bor_append(_parts, bor_roof_surface(_r, -0.30, 0.30, _st));
            // ⚠️ THE CELL IS WORKED HARDER THAN IT WAS. The subject here is WIDE (a roof over a full
            // wall, plus two eaves overhangs) inside a cell that is TALL, so the tight fit is
            // width-bound and every pixel taken off the width is taken off the subject twice over.
            // Widened to 0.94 of the cell and the caption pulled up under the content, which is the
            // only free space on this sheet.
            bor_render_in_rect_tight(_parts, _pal, _cx + _cw * 0.03, _cy + _ch * 0.03,
                                     _cw * 0.94, _ch * 0.76, undefined);
            bor_bk_caption(string_upper(_forms[_i]), _cx + _cw * 0.05, _cy + _ch * 0.82,
                           _cw * 0.90, _ch * 0.105, _pal);
        }
    }));

    // -- 4. OPENINGS: EIGHT RHYTHMS AND SIX DOORS -----------------------------------------------
    array_push(_res, bor_bk_sheet("sheet_4_openings", _W, _H, function(_w, _h) {
        var _st = bor_bk_state(3141, "lowland", "market", 0.80, 4, 0.25, 0.0);
        var _pal = bor_palette_build(_st);
        bor_bk_page(_w, _h, _pal);
        var _rh = bor_rhythm_names();
        var _dr = bor_door_names();
        bor_bk_caption("EIGHT WINDOW RHYTHMS", _w * 0.018, _h * 0.025, _w * 0.60,
                       _h * 0.044, _pal);
        // Eight rhythms across the top band, each fitted to its own cell by measured bounds rather
        // than by the unit box - the same correction as the roof sheet, for the same reason.
        var _cw = _w / 8;
        for (var _i = 0; _i < 8; _i++) {
            var _cx = _i * _cw;
            var _parts = [];
            bor_append(_parts, bor_map_roles(
                bor_raise(bor_box_pts(-0.34, -0.30, 0.34, 0.34), 0.016, 2, "wall2"),
                bor_material_map("wall")));
            bor_append(_parts, bor_wall_build(_st.wall_mat == "brick" ? "brick" : "ashlar",
                                              -0.33, -0.29, 0.33, 0.33, _st));
            bor_append(_parts, bor_opening_band(_rh[_i], -0.30, 0.30, -0.26, 0.30, _st));
            bor_render_in_rect_tight(_parts, _pal, _cx + _cw * 0.05, _h * 0.085,
                                     _cw * 0.90, _h * 0.335, undefined);
            bor_bk_caption(string_upper(_rh[_i]), _cx + _cw * 0.06, _h * 0.445,
                           _cw * 0.88, _h * 0.038, _pal);
        }
        bor_bk_caption("SIX DOOR TREATMENTS", _w * 0.018, _h * 0.510, _w * 0.60,
                       _h * 0.044, _pal);
        var _dw = _w / 6;
        for (var _i = 0; _i < 6; _i++) {
            var _cx = _i * _dw;
            var _parts = [];
            bor_append(_parts, bor_map_roles(
                bor_raise(bor_box_pts(-0.34, -0.24, 0.34, BOR_GROUND), 0.016, 2, "wall2"),
                bor_material_map("wall")));
            bor_append(_parts, bor_wall_build("ashlar", -0.33, -0.23, 0.33, 0.43, _st));
            bor_append(_parts, bor_opening_door(_dr[_i], 0, BOR_GROUND, 0.20, 0.44, _st));
            bor_render_in_rect_tight(_parts, _pal, _cx + _dw * 0.05, _h * 0.570,
                                     _dw * 0.90, _h * 0.345, undefined);
            bor_bk_caption(string_upper(_dr[_i]), _cx + _dw * 0.06, _h * 0.940,
                           _dw * 0.88, _h * 0.038, _pal);
        }
    }));

    // -- 5. WALLS AND MATERIALS -----------------------------------------------------------------
    array_push(_res, bor_bk_sheet("sheet_5_walls_and_materials", _W, _H, function(_w, _h) {
        var _st = bor_bk_state(2236, "lowland", "market", 0.60, 3, 0.40, 0.0);
        var _pal = bor_palette_build(_st);
        bor_bk_page(_w, _h, _pal);
        var _tr = bor_wall_names();
        bor_bk_caption("SIX WALL TREATMENTS - COUNT AND LENGTH, NEVER STROKE WEIGHT",
                       _w * 0.018, _h * 0.025, _w * 0.90, _h * 0.044, _pal);
        var _cw = _w / 6;
        for (var _i = 0; _i < 6; _i++) {
            var _cx = _i * _cw;
            var _parts = [];
            // ⚠️ THE SWATCH IS TALLER THAN IT IS WIDE, AND THAT IS THE FIX FOR THE DEAD SPACE.
            // MEASURED 2026-08-28 by opening this sheet: a near-square swatch at this scale filled
            // 180 of 266 px across and 175 of ~360 px down, so the top half of the sheet was mostly
            // page. Six cells across a 1600px sheet are WIDTH-BOUND whatever the scale, so simply
            // scaling up cannot reach the spare height - the aspect of the SUBJECT has to change.
            // Making the sample taller uses the height that was going to waste AND shows more
            // courses, which is the thing the sheet is about. The wing's law is that the answer to a
            // sparse sheet is more content, never a lower floor, and this is that answer in its
            // cheapest form: the same content, sized to its actual cell.
            bor_append(_parts, bor_map_roles(
                bor_raise(bor_box_pts(-0.36, -0.46, 0.36, 0.46), 0.018, 2, "wall2"),
                bor_material_map("wall")));
            bor_append(_parts, bor_wall_build(_tr[_i], -0.35, -0.45, 0.35, 0.45, _st));
            // ⚠️ 1.24 AND NOT 1.30: THE SWATCHES MUST NOT TOUCH. At 1.30 they filled 94% of the
            // cell and abutted, and ASHLAR's quoins - which sit on its own left and right edges -
            // read as DIVIDERS BELONGING TO THE SHEET rather than as part of that one treatment.
            // A gutter is the difference between six samples and one strip.
            bor_render_parts(_parts, _pal, _cx + _cw * 0.5, _h * 0.275, _cw * 1.24, 0, 1, undefined);
            bor_bk_caption(string_upper(_tr[_i]), _cx + _cw * 0.05, _h * 0.505,
                           _cw * 0.90, _h * 0.036, _pal);
        }
        // Every material's five stops, as a strip. This is the colour engine, shown rather than
        // claimed, and it is the one place a buyer can count seventy generated colours.
        bor_bk_caption("FOURTEEN MATERIALS x FIVE RELIEF STOPS - ALL COMPUTED, NO HEX TABLE",
                       _w * 0.018, _h * 0.565, _w * 0.90, _h * 0.044, _pal);
        var _mats = bor_material_names();
        var _mw = _w / array_length(_mats);
        for (var _i = 0; _i < array_length(_mats); _i++) {
            var _ramp = bor_material_ramp(_mats[_i], 0.15, 0);
            for (var _k = 0; _k < BOR_RAMP_N; _k++) {
                draw_set_colour(_ramp[_k]);
                draw_rectangle(_i * _mw + _mw * 0.06, _h * (0.635 + 0.052 * _k),
                               (_i + 1) * _mw - _mw * 0.06, _h * (0.635 + 0.052 * (_k + 1)), false);
            }
            bor_bk_caption(string_upper(_mats[_i]), _i * _mw + _mw * 0.06, _h * 0.915,
                           _mw * 0.88, _h * 0.030, _pal);
        }
    }));

    // -- 6. AGEING: ONE BUILDING, SIX AGES ------------------------------------------------------
    array_push(_res, bor_bk_sheet("sheet_6_ageing", _W, _H, function(_w, _h) {
        // ⛔ THREE COLUMNS BY TWO ROWS, NOT SIX ACROSS. MEASURED 2026-08-28: a cottage is WIDE and
        // LOW, so six of them across a 1600px sheet can be at most about 107px tall whatever the
        // fitting rule is - the sheet scored 18% of rows carrying content and looked like a strip of
        // stamps on a black field. The cell ASPECT has to suit the subject; no scaling fix can
        // rescue a layout that gives a wide low building a tall narrow cell.
        var _n = 6;
        var _cols = 3, _rows = 2;
        var _cw = _w / _cols;
        var _ch = (_h - _h * 0.09) / _rows;
        var _lbl = ["NEW", "60 YEARS", "120 YEARS", "180 YEARS", "240 YEARS", "300 YEARS"];
        var _st0 = bor_bk_state(5772, "forest", "farming", 0.45, 2, 0.0, 0.0);
        bor_bk_page(_w, _h, bor_palette_build(_st0));
        for (var _i = 0; _i < _n; _i++) {
            var _a = _i / (_n - 1.0);
            var _st = bor_bk_state(5772, "forest", "farming", 0.45, 2, _a, 0.0);
            var _pal = bor_palette_build(_st);
            var _cx = (_i % _cols) * _cw;
            var _cy = _h * 0.09 + floor(_i / _cols) * _ch;
            var _b = bor_building_create(_st, "cottage", 3);
            bor_street_draw_one(_b, _pal, _cx + _cw * 0.03, _cy, _cw * 0.94, _ch * 0.86);
            bor_bk_caption(_lbl[_i], _cx + _cw * 0.05, _cy + _ch * 0.88,
                           _cw * 0.90, _ch * 0.085, _pal);
        }
        bor_bk_caption("THE SAME COTTAGE, THE SAME SEED - ONLY THE YEARS MOVE. "
                     + "A LEAN-TO ACCRETES, THE RIDGE SAGS, THE WALL GREENS FROM THE GROUND UP.",
                       _w * 0.018, _h * 0.025, _w * 0.96, _h * 0.042,
                       bor_palette_build(_st0));
    }));

    // -- 7. DAMAGE ------------------------------------------------------------------------------
    array_push(_res, bor_bk_sheet("sheet_7_damage", _W, _H, function(_w, _h) {
        // ⛔ FOUR ROWS, NOT FIVE, AND DROPPING ONE MADE THE SHEET SAY MORE. MEASURED 2026-08-28 by
        // opening it: at five rows each street got 180px, and "NEGLECTED" (damage 0.22) was not
        // distinguishable from "INTACT" at that size - so the sheet spent a fifth of itself showing
        // the same picture twice and made the whole progression look like a palette shift.
        //
        // Damage is an OVERLAY - boards, soot, a collapsed bay - so unlike the hero sheet, where
        // prosperity changes the MATERIALS and every row is obviously a different town, adjacent
        // damage steps look alike by construction. The answer is to sample the axis where it
        // actually changes rather than evenly: 0.0, 0.45, 0.68, 0.92 puts a visible event between
        // every pair of neighbours, and the extra 45px a row buys makes each one legible.
        //
        // ⚠️ THE PRODUCT STILL SPANS THE WHOLE 0..1 RANGE CONTINUOUSLY. This is a choice about which
        // four frames to photograph, not a reduction in what ships, and the listing says damage is
        // continuous rather than claiming four levels.
        var _n = 4;
        var _rh = _h / _n;
        var _lbl = ["INTACT", "BOARDED UP", "BURNT", "RUINED"];
        var _d = [0.0, 0.45, 0.68, 0.92];
        for (var _i = 0; _i < _n; _i++) {
            var _st = bor_bk_state(8899, "coastal", "port", 0.55 - _d[_i] * 0.35, 3,
                                   0.45, _d[_i]);
            var _pal = bor_palette_build(_st);
            bor_street_draw(_st, _pal, 0, _rh * _i, _w, _rh, 6);
            bor_bk_caption(_lbl[_i], _w * 0.018, _rh * _i + _rh * 0.06,
                           _w * 0.35, _rh * 0.16, _pal);
        }
    }));

    // -- 8. REGIONS -----------------------------------------------------------------------------
    array_push(_res, bor_bk_sheet("sheet_8_six_regions", _W, _H, function(_w, _h) {
        // ⛔ ONE BUILDING PER REGION, LARGE - NOT A STREET PER REGION. MEASURED 2026-08-28: a street
        // cell is scale-limited by fitting four-plus frontages across a third of the sheet, so every
        // building came out about 150px tall and the sheet scored 36%. It also buried the CLAIM: this
        // sheet exists to show that region is a SILHOUETTE and not a palette swap, and a silhouette
        // argument needs the silhouette big enough to read.
        var _regs = bor_region_names();
        var _cols = 3, _rows = 2;
        var _cw = _w / _cols, _ch = (_h - _h * 0.08) / _rows;
        var _st0 = bor_bk_state(1414, "lowland", "market", 0.62, 3, 0.35, 0.0);
        bor_bk_page(_w, _h, bor_palette_build(_st0));
        bor_bk_caption("SIX REGIONS - THE SAME TOWNHOUSE, THE SAME SEED, THE SAME WEALTH. "
                     + "REGION CHANGES THE OUTLINE, NEVER ONLY THE COLOUR.",
                       _w * 0.018, _h * 0.022, _w * 0.96, _h * 0.040,
                       bor_palette_build(_st0));
        for (var _i = 0; _i < array_length(_regs); _i++) {
            var _cx = (_i % _cols) * _cw;
            var _cy = _h * 0.08 + floor(_i / _cols) * _ch;
            var _st = bor_bk_state(1414, _regs[_i], "market", 0.62, 3, 0.35, 0.0);
            var _pal = bor_palette_build(_st);
            var _b = bor_building_create(_st, "townhouse", 2);
            bor_street_draw_one(_b, _pal, _cx + _cw * 0.03, _cy, _cw * 0.94, _ch * 0.84);
            bor_bk_caption(string_upper(_regs[_i]) + "  -  PITCH "
                           + string_format(bor_region_pitch(_regs[_i]), 1, 2)
                           + (bor_region_parapet(_regs[_i]) ? ", PARAPETED" : "")
                           + (bor_region_gable_front(_regs[_i]) ? ", GABLE TO THE STREET" : ""),
                           _cx + _cw * 0.04, _cy + _ch * 0.87, _cw * 0.92, _ch * 0.070,
                           _pal);
        }
    }));

    // ---- WRITE THE RESULT ---------------------------------------------------------------------
    var _s = "{\"sheets\":[";
    for (var _i = 0; _i < array_length(_res); _i++) {
        var _e = _res[_i];
        if (_i > 0) _s += ",";
        _s += "{\"sheet\":\"" + _e.sheet + "\",\"ok\":" + (_e.ok ? "true" : "false")
            + ",\"frac\":" + string_format(_e.frac, 1, 4)
            + ",\"rows\":" + string(_e.rows)
            + ",\"content\":[" + string(_e.content[0]) + "," + string(_e.content[1]) + ","
            + string(_e.content[2]) + "," + string(_e.content[3]) + "]"
            + ",\"reason\":\"" + _e.reason + "\"}";
    }
    _s += "],\"floor\":" + string_format(BOR_BK_CONTENT_FLOOR, 1, 2) + "}";

    var _f = file_text_open_write("bor_bake.json");
    file_text_write_string(_f, _s);
    file_text_close(_f);
    return _res;
}
