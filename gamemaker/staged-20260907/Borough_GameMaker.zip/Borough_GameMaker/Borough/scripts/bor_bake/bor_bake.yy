{
  "$GMScript": "v1",
  "%Name": "bor_bake",
  "isCompatibility": false,
  "isDnD": false,
  "name": "bor_bake",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}