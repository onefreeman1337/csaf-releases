/// @description Create

// ⛔ THE FIRST LINE OF ANY HEADLESS ENTRY POINT, AND IT IS NOT OPTIONAL.
// A GML runtime error opens a MODAL DIALOG. Headless, nothing dismisses it and the process never
// exits - a build robot then reports a 180-second timeout instead of a defect. Installing a handler
// that records the stage number and ends the game turns an opaque hang into a named line in a
// result file. This wing measured that exact conversion on a previous product: an opaque 180 s hang
// became "CRASH at stage 5: Variable Index [25] out of range [25]", which was a real product bug.
// ⛔ AND IT RECORDS THE STACKTRACE, NOT JUST THE MESSAGE. MEASURED 2026-08-28, first run of this
// product: the handler caught "I32 argument is array" at stage 9 and that was ALL it said. A stage
// is a whole test block calling hundreds of functions, so the message alone sends you guessing
// through the call graph - which is the thing this wing's own doctrine says not to do. GML's
// exception struct carries .stacktrace, which names the function AND the line, and writing it costs
// one string. A diagnostic that narrows to a 300-line block is barely better than none.
global.bor_stage = -1;
exception_unhandled_handler(function(_ex) {
    var _st = "";
    try {
        var _tr = _ex.stacktrace;
        for (var _i = 0; _i < array_length(_tr); _i++) {
            if (_i > 0) _st += " <- ";
            _st += string(_tr[_i]);
        }
    } catch (_e) { _st = "(no stacktrace)"; }
    var _f = file_text_open_write("bor_crash.json");
    file_text_write_string(_f, "{\"stage\":" + string(global.bor_stage)
        + ",\"message\":\"" + string_replace_all(string(_ex.message), "\"", "'") + "\""
        + ",\"where\":\"" + string_replace_all(_st, "\"", "'") + "\"}");
    file_text_close(_f);
    game_end(1);
});

// ⛔ EVERY INSTANCE VARIABLE ANOTHER EVENT READS IS SET BEFORE ANY EARLY EXIT. MEASURED
// 2026-08-28: the headless branches below call game_end and `exit`, which leaves Create part way
// through - and Clean Up still runs at game end, read `cached`, and threw "Variable
// obj_borough_demo.cached not set before reading it" AFTER a fully green self-test. A crash after
// the work is done still fails the run and still hides the result, and the cause was three
// statements away from where it fired.
//
// The general rule this is an instance of: an object with an early exit in Create is only safe if
// everything its OTHER events touch has already been assigned. Construct first, branch second.
cached = noone;

var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i + 1) + " ";

// -- headless modes: run, write the result file, exit ------------------------------------------
if (string_pos("-selftest", _args) > 0) {
    bor_selftest_run();
    game_end(0);
    exit;
}
if (string_pos("-bake", _args) > 0) {
    bor_bake_run();
    game_end(0);
    exit;
}

// -- the interactive demo ----------------------------------------------------------------------
// ⛔ A RUNNABLE DEMO ROOM IS MANDATORY IN THIS WING. It is the buyer's quickstart, the source of the
// store GIF, and the only real smoke test available for GML - all three at once. A buyer who cannot
// press Play cannot evaluate the product.
//
// It is deliberately SHORT and it is deliberately the shortest correct use of the API:
//     create a settlement -> build a palette -> draw a street.
// Everything else in this file is the readout that shows what the state currently is.
randomise();
seed = irandom(9999);
st  = bor_settlement_create(seed);
pal = bor_palette_build(st);

years = 0;
trend = 1.0;
auto  = true;
timer = 0;
