/// @description Draw GUI

// Draw GUI rather than Draw: the demo is a full-frame street with a readout over it, and the GUI
// layer is resolution independent, so the same code is correct at any window size.
var _w = display_get_gui_width();
var _h = display_get_gui_height();

// ⛔ THE ENTIRE DEMO IS THESE TWO LINES. Everything below is the readout. If a buyer reads only one
// thing in this package, it should be able to be this.
bor_street_draw(st, pal, 0, 0, _w, _h * 0.90, 9);

// -- the readout, built from the product's own relief engine ------------------------------------
// There is no windowskin here and no nine-slice: this panel is a rounded outline handed to
// bor_ui_panel and lit by the same lamp as the buildings. That is why the demo does not look like a
// GameMaker default, which is a blocking gate in this wing.
bor_street_readout(st, pal, _w * 0.02, _h * 0.905, _w * 0.62, _h * 0.075);

// Light face over a dark shadow: this text sits over a street whose colour is whatever the
// settlement's materials are, so a single flat colour cannot be legible in every town.
var _px = _h * 0.026;
bor_text_label("SPACE pause  .  N new town  .  RIGHT +25 years  .  F fire or siege  .  R rebuild",
              _w * 0.66, _h * 0.925, _w * 0.32, _px, pal.label_sh, pal.label);

bor_text_label("seed " + string(seed) + "  .  year " + string(st.founded + years)
              + "  .  " + string(st.wall_mat) + " walls, " + string(st.roof_mat) + " roofs"
              + (auto ? "" : "  .  PAUSED"),
              _w * 0.66, _h * 0.955, _w * 0.32, _px, pal.label_sh, pal.label);
