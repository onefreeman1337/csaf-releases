/// @description Step

// Time passes. The whole point of the demo is that you WATCH the town change - a static screenshot
// of a generated street proves nothing that a sprite sheet could not also prove.
if (auto) {
    timer++;
    if (timer >= 12) {
        timer = 0;
        years += 10;
        bor_settlement_step(st, 10, trend);
        pal = bor_palette_build(st);

        // A town that grows for two centuries and then never stops is a graph, not a place. At the
        // top of the arc the trend turns and the street starts to decline, which is what makes the
        // damage half of the state model visible without anyone pressing a key.
        if (st.prosperity > 0.93) trend = -1.0;
        if (st.prosperity < 0.12) trend =  1.0;
    }
}

// -- keys, and every one of them is in the on-screen legend -------------------------------------
if (keyboard_check_pressed(vk_space)) auto = !auto;

if (keyboard_check_pressed(ord("N"))) {
    seed = irandom(9999);
    st = bor_settlement_create(seed);
    pal = bor_palette_build(st);
    years = 0;
    trend = 1.0;
}

if (keyboard_check_pressed(vk_right)) {
    bor_settlement_step(st, 25, trend);
    pal = bor_palette_build(st);
    years += 25;
}

if (keyboard_check_pressed(ord("F"))) {
    // A fire, a siege, a storm. One call, and the whole street answers it.
    bor_settlement_damage(st, 0.45);
    pal = bor_palette_build(st);
}

if (keyboard_check_pressed(ord("R"))) {
    st.damage = 0;
    bor_settlement_derive(st);
    pal = bor_palette_build(st);
}
