/// @description Clean Up

// ⚠️ THE CALLER OWNS ANY SPRITE bor_render_to_sprite HANDS BACK, AND MUST DELETE IT.
// A generator that hands out sprites with no stated ownership is a leak with a nice API on top. The
// demo makes the contract visible by honouring it here, and the Readme says it in the same words.
if (cached != noone && sprite_exists(cached)) {
    sprite_delete(cached);
    cached = noone;
}
