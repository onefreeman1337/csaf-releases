/// BARRAGE - bar_render. Part of the shared drawing foundation.
///
/// This file is the studio's cross-product drawing/colour layer, carried forward with more
/// than 2,300 in-engine assertions behind it - including the GML default-epsilon fix
/// described below, which had produced a suite of assertions that could never go red.
///
/// ⛔ GML APPLIES A DEFAULT EPSILON TO NUMERIC COMPARISONS, and it is 0.00001 on this runtime
/// - MEASURED by bar_selftest, which prints math_get_epsilon() into its own result file at
/// twelve decimals. Any tolerance at or below about 0.00001 can NEVER fire, in either
/// direction, so a distinctness assertion written that way passes vacuously forever and an
/// equality assertion written that way goes red on two values that are the same object.
/// Never write one here. And GML has no exponent-literal syntax at all: `1e-5` is a lexer
/// error that reads like a bracket bug.
///
/// The ONLY file in this package that talks to the GPU.
///
/// Everything above it produces PART LISTS - arrays of {kind, points, role} structs in a
/// unit box - and everything a buyer might want to change lives there. This file turns a
/// part list into draw calls, resolves a role against a surface, and does nothing else.
///
/// ⛔ THE STROKE FLOOR IS 1.0 PIXEL AND IT IS NOT NEGOTIABLE. draw_line_width lays down an
/// unantialiased quad, so a 0.55px stroke rasterises to a row of pixels on some scanlines
/// and nothing on others: a field of tone turns into a field of dashes. Anything that needs
/// to read finer than a pixel must carry its gradient in HOW MANY strokes and HOW FAR each
/// runs, never in how wide they are. On this product that law decides how grain, hatching, knurl,
/// grip ridges, weave and circuit traces are drawn - they are the surface character that tells
/// forty materials apart, and every one of them is carried by COUNT and LENGTH.
///
/// ⭐ AND IT IS SHARPER HERE THAN ANYWHERE ELSE IN THE CATALOGUE, BECAUSE INTERFACE COMPONENTS ARE
/// SMALL BY DEFINITION. An inventory icon is 32 pixels square in most games, which is SMALLER
/// than the button this argument was first written about. A material whose entire identity
/// is a 0.4px hatch is a material that does not exist at the size it ships at, so every surface
/// character in bar_material is authored to survive bar_material_min_px and is asserted against
/// it.
/// ============================================================================================
#macro BAR_MIN_STROKE 1.0

/// How many segments an arc is sampled at per full turn.
#macro BAR_ARC_SEGS 48

/// ============================================================================================
/// SURFACE LOOKUP
/// ============================================================================================

function bar_render_colour(_pal, _role) {
    if (variable_struct_exists(_pal, _role)) return variable_struct_get(_pal, _role);
    return _pal.line;
}

/// ============================================================================================
/// FITTING
/// ============================================================================================

/// Where to put the unit box so it fits (_x,_y,_w,_h) without distortion.
///
/// UNIFORM SCALE, ALWAYS. Mapping x by width and y by height independently would fill an oblong
/// slot exactly and turn every circle in the package into an ellipse - which on a product whose
/// forms are told apart by their outlines is not a cosmetic problem. A rim curve IS the
/// difference between a shallow bowl and a deep one, and a non-uniform scale changes every
/// curve in the corpus by the slot it happened to be drawn into. A form that does not fill
/// its slot is correct; a stretched one is a defect.
function bar_render_fit(_x, _y, _w, _h) {
    var _s = min(_w, _h);
    return { cx: _x + _w * 0.5, cy: _y + _h * 0.5, s: _s };
}

/// ============================================================================================
/// THE FIVE PRIMITIVES
/// ============================================================================================

function bar_render_poly(_pts, _closed, _w) {
    var _n = array_length(_pts);
    if (_n < 2) return;
    var _ww = max(BAR_MIN_STROKE, _w);
    for (var _i = 0; _i < _n - 1; _i++) {
        draw_line_width(_pts[_i][0], _pts[_i][1], _pts[_i + 1][0], _pts[_i + 1][1], _ww);
    }
    if (_closed) draw_line_width(_pts[_n - 1][0], _pts[_n - 1][1], _pts[0][0], _pts[0][1], _ww);
}

/// Fill a triangle fan. The caller is responsible for the outline being star-shaped about pts[0];
/// bar_ring_fill is the helper that guarantees it and closes the final wedge.
/// ⛔⛔ THE FAN IS CHUNKED, AND WITHOUT THAT A LARGE FILL LOSES A WEDGE OF ITSELF SILENTLY.
///
/// ⚠️ THE RECEIPT BELOW IS THE DONOR PRODUCT'S AND IS ATTRIBUTED RATHER THAN RESTATED. This
/// drawing layer is carried between products in this wing, and a comment claiming a measurement the
/// CURRENT product never made is the stale-receipt defect the wing constitution records: the next
/// session trusts it and goes hunting a defect that was never here.
///
/// MEASURED in the donor product: a fill of about 1,350 points came out with an eighth of its
/// interior missing - a hard straight edge, page showing through, and the outline stroke drawn
/// correctly right across the gap. A single draw_primitive batch does not carry that many vertices
/// and the tail is dropped, with no error. The geometry was correct, the suite was green, and the
/// ink and extent floors passed, because the missing wedge is INTERIOR and a bounding box cannot
/// see the space inside itself.
///
/// ⚠️ BARRAGE'S OWN LARGEST FAN IS ABOUT 194 POINTS - a body outline at 96 samples a side - so the
/// chunking here is insurance rather than a live fix. It stays because the limit is a property of
/// the driver rather than of the subject, and the next product to reuse this file may exceed it.
///
/// A triangle fan splits exactly: every sub-fan shares the apex and repeats one boundary point, so
/// chunking changes nothing about the shape. 256 is well inside any batch and the extra
/// begin/end pairs cost nothing measurable next to the vertex count itself.
///
/// ⭐ The general form: A PRIMITIVE BATCH HAS A CEILING AND EXCEEDING IT IS NOT AN ERROR. Any
/// generator that scales a point count with a user-supplied number can reach it, and the failure
/// looks like a modelling bug in a completely different file.
#macro BAR_FAN_CHUNK 256

function bar_render_fill(_pts) {
    var _n = array_length(_pts);
    if (_n < 3) return;
    if (_n <= BAR_FAN_CHUNK) {
        draw_primitive_begin(pr_trianglefan);
        for (var _i = 0; _i < _n; _i++) draw_vertex(_pts[_i][0], _pts[_i][1]);
        draw_primitive_end();
        return;
    }
    // pts[0] is the apex; pts[1..n-1] is the boundary. Walk the boundary in runs, repeating the
    // last point of each run as the first of the next so no triangle is skipped at a seam.
    var _i = 1;
    while (_i < _n - 1) {
        var _end = min(_n - 1, _i + BAR_FAN_CHUNK - 2);
        draw_primitive_begin(pr_trianglefan);
        draw_vertex(_pts[0][0], _pts[0][1]);
        for (var _j = _i; _j <= _end; _j++) draw_vertex(_pts[_j][0], _pts[_j][1]);
        draw_primitive_end();
        _i = _end;
    }
}

/// Fill a triangle strip between two rails. A rail-length mismatch draws NOTHING rather than the
/// overlapping part: a strip whose rails disagree means the producer's two loops disagree, and
/// drawing the common prefix would render a plausible half-shape and hide the defect.
/// A triangle strip between two polylines. CHUNKED for the same reason as the fan above - see that
/// comment. A strip emits TWO vertices per step, so it reaches the ceiling in half as many points,
/// and this product's motion trails are the longest strips in the catalogue.
function bar_render_strip(_a, _b) {
    var _n = array_length(_a);
    if (_n < 2 || array_length(_b) != _n) return;
    var _step = floor(BAR_FAN_CHUNK * 0.5);
    var _i = 0;
    while (_i < _n - 1) {
        var _end = min(_n - 1, _i + _step);
        draw_primitive_begin(pr_trianglestrip);
        for (var _j = _i; _j <= _end; _j++) {
            draw_vertex(_a[_j][0], _a[_j][1]);
            draw_vertex(_b[_j][0], _b[_j][1]);
        }
        draw_primitive_end();
        _i = _end;
    }
}

function bar_render_arc(_cx, _cy, _r, _a0, _a1, _w) {
    var _sweep = abs(_a1 - _a0);
    var _segs = max(3, ceil(BAR_ARC_SEGS * _sweep / BAR_TAU));
    var _ww = max(BAR_MIN_STROKE, _w);
    var _px = _cx + cos(_a0) * _r, _py = _cy + sin(_a0) * _r;
    for (var _i = 1; _i <= _segs; _i++) {
        var _a = _a0 + (_a1 - _a0) * (_i / _segs);
        var _qx = _cx + cos(_a) * _r, _qy = _cy + sin(_a) * _r;
        draw_line_width(_px, _py, _qx, _qy, _ww);
        _px = _qx; _py = _qy;
    }
}

/// ============================================================================================
/// THE DRAW LOOP
/// ============================================================================================

function bar_render_part(_p, _pal) {
    draw_set_colour(bar_render_colour(_pal, _p.role));
    switch (_p.kind) {
        case BAR_DOT:   draw_circle(_p.cx, _p.cy, max(0.5, _p.r), false);       break;
        case BAR_ARC:   bar_render_arc(_p.cx, _p.cy, _p.r, _p.a0, _p.a1, _p.w); break;
        case BAR_FILL:  bar_render_fill(_p.pts);                                break;
        case BAR_STRIP: bar_render_strip(_p.a, _p.b);                           break;
        default:        bar_render_poly(_p.pts, _p.closed, _p.w);               break;
    }
}

function bar_render_parts_raw(_parts, _pal) {
    var _n = array_length(_parts);
    for (var _i = 0; _i < _n; _i++) bar_render_part(_parts[_i], _pal);
}

/// Place a unit-box part list at (_cx,_cy) at scale _s and draw it.
///
/// _rot, _wscale and _map are optional. _wscale defaults to _s, which is the constant-PROPORTION
/// rule the primitive layer's header argues for: holding stroke weight constant in screen space
/// instead made a thumbnail-scale form's incisions 32% of its own width while a hero-scale one's were
/// 6%, so small forms rendered as solid blobs.
function bar_render_parts(_parts, _pal, _cx, _cy, _s, _rot, _wscale, _map) {
    var _r  = is_undefined(_rot)    ? 0  : _rot;
    var _ws = is_undefined(_wscale) ? _s : _wscale;
    bar_render_parts_raw(bar_place(_parts, _cx, _cy, _s, _r, _ws, _map), _pal);
}

function bar_render_in_rect(_parts, _pal, _x, _y, _w, _h, _rot, _map) {
    var _fit = bar_render_fit(_x, _y, _w, _h);
    bar_render_parts(_parts, _pal, _fit.cx, _fit.cy, _fit.s, _rot, _fit.s, _map);
}

/// ============================================================================================
/// MEASUREMENT - what the self-test asserts against
/// ============================================================================================

/// The bounding box of a part list in unit-box space, as [x0, y0, x1, y1].
///
/// It walks the ACTUAL VERTICES rather than a form's declared extents, and that is the point: a
/// declared extent is a claim and the vertices are evidence. Containment failures in this wing have
/// twice been a builder whose stated half width was right and whose geometry had drifted.
function bar_render_bounds(_parts) {
    var _n = array_length(_parts);
    var _x0 = 999, _y0 = 999, _x1 = -999, _y1 = -999;
    for (var _i = 0; _i < _n; _i++) {
        var _p = _parts[_i];
        switch (_p.kind) {
            case BAR_DOT: {
                _x0 = min(_x0, _p.cx - _p.r); _x1 = max(_x1, _p.cx + _p.r);
                _y0 = min(_y0, _p.cy - _p.r); _y1 = max(_y1, _p.cy + _p.r);
            } break;
            case BAR_ARC: {
                _x0 = min(_x0, _p.cx - _p.r - _p.w); _x1 = max(_x1, _p.cx + _p.r + _p.w);
                _y0 = min(_y0, _p.cy - _p.r - _p.w); _y1 = max(_y1, _p.cy + _p.r + _p.w);
            } break;
            case BAR_STRIP: {
                for (var _k = 0; _k < array_length(_p.a); _k++) {
                    _x0 = min(_x0, _p.a[_k][0]); _x1 = max(_x1, _p.a[_k][0]);
                    _y0 = min(_y0, _p.a[_k][1]); _y1 = max(_y1, _p.a[_k][1]);
                }
                for (var _k = 0; _k < array_length(_p.b); _k++) {
                    _x0 = min(_x0, _p.b[_k][0]); _x1 = max(_x1, _p.b[_k][0]);
                    _y0 = min(_y0, _p.b[_k][1]); _y1 = max(_y1, _p.b[_k][1]);
                }
            } break;
            case BAR_FILL: {
                for (var _k = 0; _k < array_length(_p.pts); _k++) {
                    _x0 = min(_x0, _p.pts[_k][0]); _x1 = max(_x1, _p.pts[_k][0]);
                    _y0 = min(_y0, _p.pts[_k][1]); _y1 = max(_y1, _p.pts[_k][1]);
                }
            } break;
            default: {
                var _hw = _p.w * 0.5;
                for (var _k = 0; _k < array_length(_p.pts); _k++) {
                    _x0 = min(_x0, _p.pts[_k][0] - _hw); _x1 = max(_x1, _p.pts[_k][0] + _hw);
                    _y0 = min(_y0, _p.pts[_k][1] - _hw); _y1 = max(_y1, _p.pts[_k][1] + _hw);
                }
            } break;
        }
    }
    return [_x0, _y0, _x1, _y1];
}

/// Fit a part list's ACTUAL CONTENT into a rectangle rather than fitting the unit box.
///
/// ⚠️ USE IT FOR A DETACHED MARK - one cursor on a swatch sheet, a single check tick in a
/// catalogue cell, a lone chevron. A ROW OF MARKS must go through bar_render_in_rect, because the
/// unit box is the frame the mark corpus is authored in and the BASELINE inside it is shared.
/// Tight fitting each one makes a full stop and a chevron the same height on screen and stands
/// them on different lines, which is exactly how a set of icons stops reading as a set.
///
/// ⛔ AND IT IS THE WRONG FUNCTION FOR A SHEET GRID, ALWAYS. A catalogue cell is laid out in
/// pixel space to the
/// rectangle it was given (see bar_geom's COORDINATES header); handing one to a fitter asks the
/// fitter to rescale geometry that was already correct, and the first thing that breaks is the
/// corner radius.
function bar_render_fit_parts(_parts, _x, _y, _w, _h) {
    var _bb = bar_render_bounds(_parts);
    var _bw = max(0.0001, _bb[2] - _bb[0]);
    var _bh = max(0.0001, _bb[3] - _bb[1]);
    var _s = min(_w / _bw, _h / _bh);
    var _mx = (_bb[0] + _bb[2]) * 0.5;
    var _my = (_bb[1] + _bb[3]) * 0.5;
    return { cx: _x + _w * 0.5 - _mx * _s, cy: _y + _h * 0.5 - _my * _s, s: _s };
}

function bar_render_in_rect_tight(_parts, _pal, _x, _y, _w, _h, _map) {
    var _f = bar_render_fit_parts(_parts, _x, _y, _w, _h);
    bar_render_parts(_parts, _pal, _f.cx, _f.cy, _f.s, 0, _f.s, _map);
}

/// ============================================================================================
/// MADE LETTERING
///
/// ⛔ TEXT IS THE ONE THING IN THIS PACKAGE THAT IS NOT GEOMETRY, and it still has to look made.
/// The trick is the same two-pass emboss the relief engine uses on a groove: draw the string once
/// offset AWAY from the lamp in the material's deepest stop, then again in place in its brightest.
/// Two draw calls, and the label reads as metal rather than as a caption laid over a picture of
/// metal.
///
/// ⚠️ EVERY STRING IN THIS FILE IS MEASURED AND SCALED TO ITS SPACE. Wings/GameMaker/CLAUDE.md
/// records this wing shipping the SAME overflow defect twice - "WickthorSt Cuthman's" on one
/// product and "HEDGEHOG FUNGUSCAULIFLOWER FUNGUS" on the next - because the first fix shortened
/// the DATA instead of making the caption honest about its width. Form names come from the
/// BUYER's game and cannot be shortened by us at all, so nothing here is allowed to assume a
/// length. No ink check will ever catch an overflow: overprinted text is ink exactly where ink
/// belongs.
/// ============================================================================================

/// The emboss offset for lettering, in pixels, at a given nominal size.
function bar_text_relief(_px) {
    return max(1, round(_px * 0.085));
}

/// One line of made text, centred at (_x,_y), scaled DOWN if it will not fit _maxw.
///
/// Returns the scale actually used, so a caller that cares can notice it was shrunk.
/// ⛔ _x AND _y ARE THE CENTRE OF THE STRING, NOT ITS TOP LEFT, AND THREE CALL SITES IN THIS
/// PACKAGE GOT THAT WRONG AT ONCE. halign is CENTRE and valign is MIDDLE below - which is right for
/// a title, and is the opposite convention to bar_text_line and bar_text_body two functions away.
/// Passing a left edge to it centres the string ON that edge, so half of it leaves the frame: a
/// product cover lost its first letter, a wordmark hung off its header panel, and a plate heading
/// floated over the top of a recessed well. All three looked like layout arithmetic
/// and all three were this. If you are passing a left edge, you want bar_text_line.
function bar_text_fit(_text, _x, _y, _maxw, _px, _col_shadow, _col_face) {
    draw_set_font(fnt_barrage_title);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    var _sc = bar_text_scale(_text, _maxw, _px);
    var _o = bar_text_relief(_px);
    draw_set_colour(_col_shadow);
    draw_text_transformed(_x - BAR_LX * _o, _y - BAR_LY * _o, _text, _sc, _sc, 0);
    draw_set_colour(_col_face);
    draw_text_transformed(_x, _y, _text, _sc, _sc, 0);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    return _sc;
}

/// A label made around an arc, one glyph at a time.
///
/// _a_mid is the angle the middle of the string sits at (-BAR_TAU/4 is the top of the form) and
/// _sweep is how much of the circle the whole string may occupy. The string is laid out by ADVANCE
/// so that letter spacing is even in ARC LENGTH - spacing the glyphs evenly in ANGLE instead
/// bunches the narrow letters and was the first thing this looked wrong doing.
///
/// ⚠️ THE ROTATION IS DERIVED, NOT GUESSED. GML's draw_text_transformed takes DEGREES and rotates
/// counter-clockwise on a y-DOWN screen, so a glyph's own x-axis lands at (cos t, -sin t). The
/// tangent to the circle at angle a is (-sin a, cos a). Solving the two gives
/// t = atan2(-cos a, -sin a), which is checkable in one place: at the top of the form a is
/// -TAU/4, the tangent is (1,0), and t comes out 0.
function bar_text_arc(_text, _cx, _cy, _r, _a_mid, _sweep, _px, _col_shadow, _col_face) {
    var _n = string_length(_text);
    if (_n <= 0 || _r <= 0) return 0;
    draw_set_font(fnt_barrage_title);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);

    var _base = max(1, string_height("M"));
    var _sc = _px / _base;
    var _total = 0;
    for (var _i = 1; _i <= _n; _i++) _total += string_width(string_char_at(_text, _i)) * _sc;
    var _arc = _r * _sweep;
    if (_total > _arc && _total > 0) {
        _sc *= _arc / _total;
        _total = _arc;
    }

    var _o = bar_text_relief(_px);
    var _run = 0;
    for (var _i = 1; _i <= _n; _i++) {
        var _ch = string_char_at(_text, _i);
        var _cw = string_width(_ch) * _sc;
        // Centre of this glyph along the run, converted to an angle about the form's centre.
        var _a = _a_mid + ((_run + _cw * 0.5) - _total * 0.5) / _r;
        var _t = radtodeg(arctan2(-cos(_a), -sin(_a)));
        var _px2 = _cx + cos(_a) * _r, _py2 = _cy + sin(_a) * _r;
        draw_set_colour(_col_shadow);
        draw_text_transformed(_px2 - BAR_LX * _o, _py2 - BAR_LY * _o, _ch, _sc, _sc, _t);
        draw_set_colour(_col_face);
        draw_text_transformed(_px2, _py2, _ch, _sc, _sc, _t);
        _run += _cw;
    }
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    return _sc;
}

/// A wrapped block of body copy, in the plain face, left aligned. No emboss: paragraph text made
/// in relief is unreadable, and the panels this appears on are paper, not metal.
function bar_text_body(_text, _x, _y, _w, _px, _col) {
    draw_set_font(fnt_barrage);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_colour(_col);
    var _base = max(1, string_height("M"));
    var _sc = _px / _base;
    draw_text_ext_transformed(_x, _y, _text, _base * 1.34, _w / _sc, _sc, _sc, 0);
    return string_height_ext(_text, _base * 1.34, _w / _sc) * _sc;
}

/// One line of plain text, left aligned, scaled to fit.
/// A LEFT-ANCHORED label drawn as a light face over a dark shadow.
///
/// ⛔ THIS EXISTS BECAUSE bar_text_fit IS CENTRE-ANCHORED AND bar_text_line IS LEFT-ANCHORED, AND
/// SWAPPING ONE FOR THE OTHER SILENTLY MOVES EVERY CAPTION BY HALF ITS OWN WIDTH.
/// MEASURED 2026-08-28 on a sibling product in this series (the receipt is kept verbatim rather
/// than reworded, because a defect this quiet is only believable with its evidence attached): a fix
/// for caption CONTRAST swapped bar_text_line for bar_text_fit, which solved the contrast and
/// clipped every left-edge caption on the store sheets off the page - the hero sheet read
/// "atch, cob, one storey". The two functions differ in two ways at once and only one of them is
/// in their names, so the trap is in the API, not in the caller.
///
/// The shadow is offset along the same lamp vector as every bevel in the package, so a label reads
/// as struck into the page rather than as text with a drop shadow bolted on.
function bar_text_label(_text, _x, _y, _maxw, _px, _col_shadow, _col_face) {
    draw_set_font(fnt_barrage_title);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    var _sc = bar_text_scale(_text, _maxw, _px);
    var _o = bar_text_relief(_px);
    draw_set_colour(_col_shadow);
    draw_text_transformed(_x - BAR_LX * _o, _y - BAR_LY * _o, _text, _sc, _sc, 0);
    draw_set_colour(_col_face);
    draw_text_transformed(_x, _y, _text, _sc, _sc, 0);
    return _sc;
}

/// The scale a line of text is drawn at: target height in px, shrunk to fit _maxw.
///
/// ⛔ THIS EXISTS BECAUSE THE SAME FOUR LINES WERE WRITTEN OUT IN THREE PLACES, AND A CENTRED
/// CAPTION NEEDS TO KNOW THE WIDTH *BEFORE* IT DRAWS. A fourth copy inside the centring helper
/// would be a measurement of the text held separately from the drawing of it - which is the shape
/// master §2b calls a checker holding the same stale number as the thing it checks. One
/// declaration, so the width a caption is centred on is by construction the width that gets drawn.
///
/// ⚠️ THE FONT MUST ALREADY BE SET when this is called: string_width and string_height both read
/// the CURRENT font, so measuring under one font and drawing under another returns a confident
/// wrong number. Every caller below sets the font first.
function bar_text_scale(_text, _maxw, _px) {
    var _base = max(1, string_height("M"));
    var _sc = _px / _base;
    var _w = string_width(_text) * _sc;
    if (_w > _maxw && _w > 0) _sc *= _maxw / _w;
    return _sc;
}

/// The drawn width of a line at the scale bar_text_scale would pick for it.
function bar_text_width(_text, _maxw, _px) {
    return string_width(_text) * bar_text_scale(_text, _maxw, _px);
}

function bar_text_line(_text, _x, _y, _maxw, _px, _col, _bold) {
    draw_set_font(_bold ? fnt_barrage_title : fnt_barrage);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_colour(_col);
    var _sc = bar_text_scale(_text, _maxw, _px);
    draw_text_transformed(_x, _y, _text, _sc, _sc, 0);
    return _sc;
}

/// The same line, centred on _cx.
///
/// ⛔ NOT A halign CHANGE. bar_text_line sets fa_left internally and this package has a receipt
/// (bar_text_label's header) for what swapping anchor conventions costs, so this centres by moving
/// the LEFT edge - the anchor convention of every caption in the package stays exactly one thing.
/// The left edge a line must start at for its midpoint to land on _cx.
///
/// ⚠️ SPLIT OUT SO THE CENTRING IS TESTABLE. Centring is a property of a draw call, and a draw call
/// is not something the suite can assert about without a surface - so the arithmetic that decides
/// it lives here as a pure function, and the suite checks THAT. A comment saying "this is centred"
/// is not a check, and this package has already paid once for the difference.
function bar_text_centre_left(_text, _cx, _maxw, _px) {
    return _cx - bar_text_width(_text, _maxw, _px) * 0.5;
}

function bar_text_line_centred(_text, _cx, _y, _maxw, _px, _col, _bold) {
    draw_set_font(_bold ? fnt_barrage_title : fnt_barrage);
    return bar_text_line(_text, bar_text_centre_left(_text, _cx, _maxw, _px),
        _y, _maxw, _px, _col, _bold);
}

/// ============================================================================================
/// SCREEN EFFECTS - the only alpha-blended draws in the package, and they live here
///
/// ⚠️ THE PART PATH DELIBERATELY HAS NO ALPHA. A role resolves to a colour, and that is the whole
/// contract - it is what lets the relief engine reason about five discrete values and what stops a
/// buyer's own blend mode changing what a form looks like. The readout flash and the shock ring
/// genuinely need blending, so they are written here as two named functions that set alpha and put
/// it back, rather than as loose draw calls in the toast where the next edit would forget the
/// second half.
/// ============================================================================================

/// A soft radial flash, drawn as a few nested discs of falling alpha.
///
/// Nested discs rather than a gradient sprite, because this package ships no sprite of any kind
/// and a genuine radial gradient in GML needs a texture or a shader. Six rings is enough that the
/// banding is invisible at the sizes this is used, and it is checked by looking.
/// ⛔ LARGEST DISC FIRST, SMALLEST LAST, AND THE FIRST VERSION HAD IT BACKWARDS. MEASURED BY LOOKING
/// at the strike sheet: drawn smallest-first, every dim outer disc is painted straight over the
/// bright core, so the whole thing flattens into a uniform grey donut - the exact opposite of a
/// flash. Painter's order is not a detail when the layers are translucent; it IS the gradient.
/// ⚠️ TWELVE DISCS, AND SIX LEFT VISIBLE BANDING. On a near-black page each step in the stack shows
/// as a concentric ring, and six of them read as a target rather than as a glow. Doubling the count
/// and halving the per-disc alpha costs nothing measurable and the banding goes. It is still a step
/// function - a true radial gradient needs a texture or a shader, and this package ships neither -
/// but at twelve steps the step is under two per cent of the range and invisible at any size the
/// flash is drawn at.
function bar_render_flash(_cx, _cy, _r, _col, _alpha) {
    if (_alpha <= 0 || _r <= 0) return;
    var _old = draw_get_alpha();
    draw_set_colour(_col);
    for (var _i = 11; _i >= 0; _i--) {
        var _t = _i / 11;
        draw_set_alpha(_alpha * (1 - _t) * 0.155);
        draw_circle(_cx, _cy, _r * (0.22 + _t * 0.78), false);
    }
    draw_set_alpha(_old);
}

/// An expanding shock ring.
function bar_render_ring(_cx, _cy, _r, _w, _col, _alpha) {
    if (_alpha <= 0 || _r <= 0) return;
    var _old = draw_get_alpha();
    draw_set_alpha(_alpha);
    draw_set_colour(_col);
    bar_render_arc(_cx, _cy, _r, 0, BAR_TAU, _w);
    draw_set_alpha(_old);
}

/// A SMOOTH VERTICAL GRADIENT between two colours.
///
/// ⛔ THIS IS THE ONE DRAW CALL IN THE PACKAGE THAT IS NOT A PART, and it is here rather than
/// in bar_shell so that the claim at the top of this file stays literally true: this is still
/// the only file that talks to the GPU.
///
/// draw_rectangle_colour takes FOUR corner colours and interpolates across the quad in
/// hardware. Passing the same colour to both top corners and both bottom corners gives a pure
/// vertical ramp with no banding at any resolution - which a stack of flat bands cannot do
/// without hundreds of them.
///
/// ⚠️ THE ALPHA IS SET AND RESTORED. A gradient drawn at whatever alpha the caller happened to
/// leave behind is the kind of defect that only appears when a fade runs at the same time.
function bar_render_vgrad(_x, _y, _w, _h, _top, _bot) {
    if (_h <= 0 || _w <= 0) return;
    var _old = draw_get_alpha();
    draw_set_alpha(1.0);
    draw_rectangle_colour(_x, _y, _x + _w, _y + _h, _top, _top, _bot, _bot, false);
    draw_set_alpha(_old);
}

/// A whole ramp of stops as a stack of gradient bands.
///
/// _stops is an array of colours, top of the frame first. Each adjacent pair becomes one
/// hardware-interpolated band, so five stops cost four draw calls for a whole backdrop.
///
/// ⚠️ THE BANDS ARE NOT EVENLY SPACED, AND THAT IS THE WHOLE POINT OF _weights. A play field
/// spends most of its height on the deep stops and compresses the pale band at the horizon into
/// the last tenth of the frame; spacing them evenly puts that pale colour a third of the way up
/// and the field reads as a beach towel. ⛔ AND ON THIS PRODUCT THE FIELD IS A LEGIBILITY
/// SURFACE, NOT DECORATION: a bullet is only readable against the band it crosses, so a field
/// whose pale stop sits where the bullets are is the "a shadow cannot exist on a black floor"
/// defect (wing CLAUDE.md, 2026-09-05) with the sign flipped. bar_legibility measures the shot
/// against this ramp rather than trusting it.
function bar_render_ramp(_x, _y, _w, _h, _stops, _weights) {
    var _n = array_length(_stops);
    if (_n < 2) return;
    var _total = 0;
    for (var _i = 0; _i < _n - 1; _i++) _total += _weights[_i];
    if (_total <= 0) return;
    var _yy = _y;
    for (var _i = 0; _i < _n - 1; _i++) {
        var _bh = _h * (_weights[_i] / _total);
        bar_render_vgrad(_x, _yy, _w, _bh + 1, _stops[_i], _stops[_i + 1]);
        _yy += _bh;
    }
}

/// A flat filled rectangle at an alpha - the scrim behind a modal panel, and the night wash over
/// the dimming wash over an interface that has lost focus.
/// ⛔⛔ IT WRITES COLOUR ONLY. DRAWING A SCRIM ONTO A SURFACE ALSO BLENDS ITS ALPHA CHANNEL, AND
/// THAT SHIPPED A SEMI-TRANSPARENT STORE COVER.
///
/// MEASURED 2026-08-31 by decoding the baked PNG (Internal_Ops/png_alpha_probe.js): the cover's
/// top-left pixel was RGB 7,8,11 - the dark page, exactly right - at ALPHA 206, with only 49,339
/// of its 315,000 pixels fully opaque. The picture was never grey. It was 81% opaque, and every
/// viewer composited it over its own light background, so it LOOKED like a flat grey card.
///
/// ⚠️ TWO WRONG DIAGNOSES CAME FIRST AND BOTH WERE REASONED, NOT MEASURED: the scrim's alpha was
/// blamed and raised, then the viewer's own frame was blamed for painting the canvas and
/// swapped. Neither changed anything, because the RGB was correct the whole time. A picture that
/// looks wrong in a viewer is not evidence about the bytes in the file - that is CLAUDE.md §2b's
/// "look at the rendered output" rule meeting its own limit, and the answer was to decode the file.
///
/// The default blend mode computes dst.a = src.a + dst.a * (1 - src.a), so an alpha-0.74 rectangle
/// over an opaque surface leaves it at 0.74 no matter what colour it was. Turning off the alpha
/// write leaves the surface's own alpha alone, which is what a scrim means.
function bar_render_scrim(_x, _y, _w, _h, _col, _alpha) {
    if (_alpha <= 0) return;
    var _old = draw_get_alpha();
    gpu_set_colorwriteenable(true, true, true, false);
    draw_set_alpha(_alpha);
    draw_set_colour(_col);
    draw_rectangle(_x, _y, _x + _w, _y + _h, false);
    draw_set_alpha(_old);
    gpu_set_colorwriteenable(true, true, true, true);
}

/// Force a surface fully opaque.
///
/// ⚠️ BELT AND BRACES, AND WORTH BOTH. bar_render_scrim above no longer punches holes in the alpha
/// channel, but it was not the only thing that could: any draw at an alpha below one does the same,
/// and this package's own text shadows and flashes do exactly that. A store image with an alpha
/// channel is a store image that looks different on every page it is shown on, so the bake calls
/// this before every save rather than trusting that nothing new will ever draw translucently.
function bar_render_opaque(_w, _h) {
    gpu_set_colorwriteenable(false, false, false, true);
    var _old = draw_get_alpha();
    draw_set_alpha(1);
    draw_set_colour(c_white);
    draw_rectangle(0, 0, _w, _h, false);
    draw_set_alpha(_old);
    gpu_set_colorwriteenable(true, true, true, true);
}

/// ============================================================================================
/// CACHING - the path a buyer's game should actually use
/// ============================================================================================

/// Render a part list once into a sprite and hand it back.
///
/// ⛔⛔ THE CACHE IS THE MOST DANGEROUS FUNCTION IN THIS PACKAGE AND THIS PRODUCT NEEDS IT MOST.
/// A dense pattern is the highest primitive count anything in this catalogue has ever drawn: a
/// 24-arm ring five waves deep is 120 bodies ON SCREEN AT ONCE, each several dozen primitives,
/// EVERY FRAME, at 60 fps. That WILL show up in a buyer's profiler, so the honest thing is to ship
/// the cache rather than let them discover the cost and write their own.
///
/// ⛔ AND THE JUSTIFICATION EVERY EARLIER PRODUCT IN THIS LINE USED FOR IT IS FALSE HERE, WHICH IS
/// WORTH SAYING OUT LOUD BECAUSE IT WOULD HAVE BEEN INHERITED SILENTLY. Their argument ran: the
/// shape is constant and only its ANGLE moves, and the finish is RADIAL, so the highlight is a
/// function of radius and therefore survives rotation. Neither half is true of a projectile.
///
/// A body in this package is shaded as a TUBE lit from one fixed direction - a bright left flank,
/// a dark right one, and no highlight at either end. Bake that and rotate the sprite and the shot
/// carries its lit side round with it, so a bullet fired ninety degrees away is lit from below:
/// the exact tell of a sprite pretending to be a lit object. ⭐ AND THIS IS THE SINGLE CLEAREST
/// PLACE THE PRODUCT BEATS A SPRITESHEET, because a pattern fires the SAME body at every heading
/// on the circle at once - so a baked bullet is wrong at 359 of 360 headings, and every dense ring
/// shows it at once.
///
/// ⇒ USE THE CACHE FOR BODIES DRAWN AT A FIXED ORIENTATION - a pattern preview, a bestiary entry,
/// an editor palette, a store sheet cell - and for RADIALLY SYMMETRIC bodies (a pellet, an orb, a
/// bubble), which have no lit side to carry round and are exactly the bodies a dense wall is made
/// of, so the case that needs the cache most is also the case where it is safe.
///
/// ⛔ NEVER CACHE AN ASYMMETRIC BODY THAT TURNS - a lance, a shard, a dart, anything with a nose.
/// bar_bullet marks each body `spin_safe`, and bar_selftest asserts that every body drawn through
/// this function is one, so the rule is enforced rather than remembered. The alternative a buyer
/// would otherwise reach for - baking one sprite per heading - is 360 sprites per body per palette
/// and is why this product draws instead.
///
/// ⚠️ THE CALLER OWNS THE SPRITE AND MUST sprite_delete IT. A generator that hands out sprites with
/// no stated ownership is a leak with a nice API on top.
///
/// ⛔ THIS PARAGRAPH USED TO CONTINUE: "the demo object's Clean Up event deletes every sprite it
/// made, and the Readme says this in the same words." BOTH HALVES WERE FALSE. MEASURED 2026-09-05
/// while writing the Readme: `CleanUp_0.gml` is a one-line placeholder that deletes nothing, and no
/// Readme existed at all. Nothing was leaking - NOTHING IN THIS PACKAGE CALLS THIS FUNCTION, so
/// there was no sprite to leak - which is exactly why it survived: a claim about cleanup is
/// unfalsifiable while the thing it cleans up is never created.
///
/// ⭐ The lesson is the one master §2b records in a harder form: a comment ASSERTING a safety
/// property is not a check, and the moment it names another file it is a claim about that file
/// which nothing keeps true. The cache is opt-in and unused by the demo; if you use it, the
/// sprite is yours to delete.
///
/// ⚠️ AND IT MUST NOT BE CALLED FROM A DRAW EVENT. surface_set_target inside a draw event nests
/// render targets, and on some drivers that silently produces an empty sprite rather than an error
/// - the exact shape of failure this wing keeps recording. Build in Create, draw in Draw.
function bar_render_to_sprite(_parts, _pal, _w, _h, _pad) {
    var _pd = is_undefined(_pad) ? 0 : _pad;
    var _surf = surface_create(_w, _h);
    surface_set_target(_surf);

    /// ⛔ `ground` IS AN OPTIONAL ROLE, AND READING IT AS A REQUIRED KEY IS THE BUG THIS LINE HAD.
    /// No palette this package builds carries one: bar_element_pal writes m0..m4, `line`, `core`,
    /// `aura`, `graze`, `name` and `hue`, and its own comment already names `line` as "the fallback
    /// for any role this palette does not name". So the opt-in cache the Compatibility section
    /// sells - "bakes a body to a sprite you can blit thousands of times" - threw on its first call
    /// for every element. It survived the suite and a clean gate because nothing in the package
    /// calls it; the suite asserts the spin_safe HALF of the cache contract and never invokes the
    /// function those rules are about.
    ///
    /// The surface is cleared to a fully TRANSPARENT colour, so this only decides what edge pixels
    /// blend toward when the sprite is filtered or scaled. The outline colour is the right default
    /// there - a shot's edge should fade into its own outline, not into an arbitrary black - and it
    /// is the fallback bar_render_colour already uses, so a palette valid for this renderer at all
    /// has one. Supply `ground` to override it.
    ///
    /// ⚠️ Read defensively, and that is not decoration here: this sits BETWEEN surface_set_target
    /// and surface_reset_target, so a throw leaves the caller's render target pointing at a surface
    /// that is about to be freed, for the rest of their frame. A crash inside a render target is
    /// never just one crash.
    var _ground = variable_struct_exists(_pal, "ground") ? _pal.ground
                : (variable_struct_exists(_pal, "line") ? _pal.line : c_black);
    draw_clear_alpha(_ground, 0);

    bar_render_in_rect(_parts, _pal, _pd, _pd, _w - _pd * 2, _h - _pd * 2, 0, undefined);
    surface_reset_target();
    var _spr = sprite_create_from_surface(_surf, 0, 0, _w, _h, false, false, _w * 0.5, _h * 0.5);
    surface_free(_surf);
    return _spr;
}
