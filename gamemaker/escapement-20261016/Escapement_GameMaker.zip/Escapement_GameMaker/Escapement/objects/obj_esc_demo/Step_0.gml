/// @description THE CLOCKMAKER'S BENCH: the bench, or the puzzle while one is open (esc_demo_step calls esc_step).
if (!is_struct(demo)) exit;
esc_demo_step(demo);
