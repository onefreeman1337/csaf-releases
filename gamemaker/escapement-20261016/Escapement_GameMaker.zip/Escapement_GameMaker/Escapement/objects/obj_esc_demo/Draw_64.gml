/// @description THE CLOCKMAKER'S BENCH, drawn in the GUI layer (esc_demo_draw calls esc_draw while a puzzle is open).
if (!is_struct(demo)) exit;
esc_demo_draw(demo);
