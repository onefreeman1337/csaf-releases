{
  "$GMObject": "",
  "%Name": "obj_esc_demo",
  "eventList": [
    {
      "$GMEvent": "v1",
      "%Name": "",
      "collisionObjectId": null,
      "eventNum": 0,
      "eventType": 0,
      "isDnD": false,
      "name": "",
      "resourceType": "GMEvent",
      "resourceVersion": "2.0"
    },
    {
      "$GMEvent": "v1",
      "%Name": "",
      "collisionObjectId": null,
      "eventNum": 0,
      "eventType": 3,
      "isDnD": false,
      "name": "",
      "resourceType": "GMEvent",
      "resourceVersion": "2.0"
    },
    {
      "$GMEvent": "v1",
      "%Name": "",
      "collisionObjectId": null,
      "eventNum": 64,
      "eventType": 8,
      "isDnD": false,
      "name": "",
      "resourceType": "GMEvent",
      "resourceVersion": "2.0"
    },
    {
      "$GMEvent": "v1",
      "%Name": "",
      "collisionObjectId": null,
      "eventNum": 0,
      "eventType": 12,
      "isDnD": false,
      "name": "",
      "resourceType": "GMEvent",
      "resourceVersion": "2.0"
    }
  ],
  "managed": true,
  "name": "obj_esc_demo",
  "overriddenProperties": [],
  "parent": {
    "name": "Objects",
    "path": "folders/Objects.yy"
  },
  "parentObjectId": null,
  "persistent": false,
  "physicsAngularDamping": 0.1,
  "physicsDensity": 0.5,
  "physicsFriction": 0.2,
  "physicsGroup": 1,
  "physicsKinematic": false,
  "physicsLinearDamping": 0.1,
  "physicsObject": false,
  "physicsRestitution": 0.1,
  "physicsSensor": false,
  "physicsShape": 1,
  "physicsShapePoints": [],
  "physicsStartAwake": true,
  "properties": [],
  "resourceType": "GMObject",
  "resourceVersion": "2.0",
  "solid": false,
  "spriteId": null,
  "spriteMaskId": null,
  "visible": true
}