/// esc_selftest_draw.gml - the drawing half of Escapement's self-test: every case the MZ EscapementDraw drew over a recording
/// canvas (esc_oracle_draw, written by Internal_Ops/_oracle_draw.js) is drawn again by this package's painter (esc_draw) with
/// the test log on, and the two logs are compared event for event (count, length, FNV hash); the numbers the drawing returns
/// (clear sides, payoff anchors, wheel ops, tray slots) are compared too. Called by esc_selftest. NOT part of the buyer API.
///
/// Escapement - Generated Clockwork Gear Puzzles, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

function esc__st_metal(_i) { var _M = esc_metal_ids(); return (is_numeric(_i) && _i >= 0 && _i < array_length(_M)) ? _M[_i] : undefined; }
function esc__st_style(_i) { var _S = esc_style_ids(); return (is_numeric(_i) && _i >= 0 && _i < array_length(_S)) ? _S[_i] : undefined; }
function esc__st_role(_i) { var _R = ["loose", "drive", "output"]; return (is_numeric(_i) && _i >= 0 && _i < 3) ? _R[_i] : undefined; }
/// the puzzle a case names: esc_generate({ seed, grade, payoff (index, -1 = the generator's pick), metal (likewise) })
function esc__st_pz(_seed, _grade, _pi, _mi) {
    var _opt = { seed: _seed, grade: _grade }, _P = esc_payoff_ids(), _M = esc_metal_ids();
    if (is_numeric(_pi) && _pi >= 0 && _pi < array_length(_P)) _opt.payoff = _P[_pi];
    if (is_numeric(_mi) && _mi >= 0 && _mi < array_length(_M)) _opt.metal = _M[_mi];
    return esc_generate(_opt);
}
/// a payoff base's anchors flattened in the oracle's order (an absent field gives undefined, which never matches)
function esc__st_anchors(_pi, _a) {
    if (!is_struct(_a)) return [];
    if (_pi == 0) {
        var _b = _a[$ "bolt"], _w = _a[$ "window"];
        if (!is_struct(_b) || !is_struct(_w)) return [];
        return [_b[$ "x"], _b[$ "y"], _b[$ "w"], _b[$ "len"], _b[$ "left0"], _b[$ "travel"], _w[$ "x"], _w[$ "y"]];
    }
    if (_pi == 1) { var _d = _a[$ "dial"]; if (!is_struct(_d)) return []; return [_d[$ "x"], _d[$ "y"], _d[$ "R"]]; }
    if (_pi == 2) {
        var _o = _a[$ "orrery"];
        if (!is_struct(_o) || !is_array(_o[$ "orbits"]) || array_length(_o.orbits) < 3) return [];
        return [_o[$ "x"], _o[$ "y"], _o.orbits[0], _o.orbits[1], _o.orbits[2]];
    }
    var _wn = _a[$ "winch"]; if (!is_struct(_wn)) return [];
    return [_wn[$ "x"], _wn[$ "y"], _wn[$ "bottom"]];
}
/// every element through esc__r100 (a non-number stays undefined)
function esc__st_r100s(_a) { var _o = array_create(array_length(_a)); for (var _i = 0; _i < array_length(_a); _i++) _o[_i] = is_numeric(_a[_i]) ? esc__r100(_a[_i]) : undefined; return _o; }

/// draw one oracle case through the public painter; returns the case's values (r100 numbers, often none) or undefined for a
/// kind this dispatcher does not know
function esc__st_draw_case(_c, _row) {
    switch (_row[0]) {
        case 0: esc_draw_bench(_c, _row[1], _row[2], "brass"); return [];
        case 1: esc_draw_plate(_c, esc__st_pz(_row[1], _row[2], _row[3], _row[4]), _row[5]); return [];
        case 2: esc_draw_arbor(_c, _row[1], _row[2], esc__st_metal(_row[3])); return [];
        case 3: esc_draw_turn_arrow(_c, _row[1], _row[2], _row[3], _row[4], esc__st_metal(_row[5]), _row[6], _row[7]); return [];
        case 4: esc_draw_turn_hint(_c, _row[1], _row[2], _row[3], _row[4]); return [];
        case 5: {
            var _pz5 = esc__st_pz(_row[1], _row[2], _row[3], _row[4]);
            if (!is_struct(_pz5)) return [];
            var _maxR = 0, _tray5 = _pz5.tray;
            for (var _t5 = 0; _t5 < array_length(_tray5); _t5++) _maxR = max(_maxR, esc_outer_r(_tray5[_t5].n));
            var _dR = esc_outer_r(_pz5.drive.n), _oR = esc_outer_r(_pz5.output.n), _v5;
            if (_row[5] == 0) _v5 = esc_clear_side(_pz5, _pz5.drive.x, _pz5.drive.y, _dR, { x: _pz5.output.x, y: _pz5.output.y, R: _oR }, _maxR, _pz5.plate.payoffX);
            else _v5 = esc_clear_side(_pz5, _pz5.output.x, _pz5.output.y, _oR, { x: _pz5.drive.x, y: _pz5.drive.y, R: _dR }, _maxR, _pz5.plate.payoffX);
            return [esc__r100(_v5)];
        }
        case 6: {
            var _a6 = esc_draw_payoff_base(_c, esc__st_pz(_row[1], _row[2], _row[3], _row[4]));
            return esc__st_r100s(esc__st_anchors(_row[3], _a6));
        }
        case 7: {
            var _o7 = esc_draw_gear(_c, { n: _row[1], module: _row[2], style: esc__st_style(_row[3]), metal: esc__st_metal(_row[4]), role: esc__st_role(_row[5]) });
            return [is_struct(_o7) ? esc__r100(_o7.ops) : undefined];
        }
        case 8: esc_draw_shadow(_c, _row[1], _row[2], _row[3], _row[4]); return [];
        case 9: esc_draw_glint(_c, _row[1], esc__st_metal(_row[2])); return [];
        case 10: esc_draw_bolt(_c, _row[1], esc__st_metal(_row[2])); return [];
        case 11: esc_draw_hand(_c, _row[1], _row[2], esc__st_metal(_row[3]), _row[4]); return [];
        case 12: esc_draw_planet_arm(_c, _row[1], _row[2], [_row[3], _row[4], _row[5]], esc__st_metal(_row[6])); return [];
        case 13: esc_draw_sun(_c, _row[1]); return [];
        case 14: esc_draw_drum(_c, _row[1], esc__st_metal(_row[2])); return [];
        case 15: esc_draw_weight(_c, esc__st_metal(_row[1])); return [];
        case 16: {
            var _o16 = esc_draw_tray(_c, _row[1], _row[2], _row[3], esc__st_metal(_row[4]));
            return [is_struct(_o16) ? esc__r100(_o16.slot) : undefined];
        }
        case 17: esc_draw_window_word(_c, _row[1], _row[2]); return [];
        case 18: esc_draw_warning(_c, _row[1]); return [];
        case 19: esc_draw_cursor(_c, _row[1]); return [];
        case 20: esc_draw_status(_c, _row[1], _row[2], _row[3]); return [];
        case 21: esc_draw_heading(_c, _row[1], _row[2], _row[3]); return [];
        case 22: esc_engrave(_c, _row[1], _row[2], _row[3], _row[4], esc__st_metal(_row[5]), _row[6], _row[7]); return [];
        case 23: esc_jewel(_c, _row[1], _row[2], _row[3]); return [];
        case 24: esc_tooth_path(_c, _row[1], _row[2]); esc__p_fill(_c); return [];
    }
    return undefined;
}

/// one case drawn into the scratch surface with the log on (keep = how many log characters to retain); returns
/// { vals, log } - the case's values and esc_log_end's { events, len, hash, text }
function esc__st_run_case(_surf, _row, _keep) {
    var _cx = esc_cx_create(1);
    surface_set_target(_surf); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha); gpu_set_ztestenable(false); gpu_set_zwriteenable(false);
    esc_log_begin(_cx, _keep);
    var _vals = esc__st_draw_case(_cx, _row);
    var _lg = esc_log_end(_cx);
    gpu_pop_state(); surface_reset_target();
    return { vals: _vals, log: _lg };
}

/// @function esc__selftest_draw()
/// @description Run every oracle drawing case through the GML painter and compare. Returns { cases, matched, events (the GML
/// side's paint events, summed), mismatches (the first 8: { i, kind, wantEvents, gotEvents, wantLen, gotLen, wantHash,
/// gotHash, gotText (the first 4000 log characters) }), values { checked, matched, fails (the first 8: { i, kind, index,
/// want, got }) }, firstFailFile }. The first failing case's WHOLE log is written to esc_draw_firstfail.txt in the game's
/// save area (first line: the case index) for Internal_Ops/_draw_diff.js. Draws into its own scratch surface (created and
/// freed here) under identity, with GameMaker's comparison epsilon off; hands back the caller's surface target, world
/// matrix and epsilon.
/// @returns {Struct}
function esc__selftest_draw() {
    var _OD = esc_oracle_draw(), _cases = _OD.cases, _nc = array_length(_cases);
    var _res = { cases: _nc, matched: 0, events: 0, mismatches: [], values: { checked: 0, matched: 0, fails: [] }, firstFailFile: "" };
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_build_identity());
    var _surf = surface_create(1024, 704);
    var _firstFail = -1;
    for (var _i = 0; _i < _nc; _i++) {
        var _row = _cases[_i];
        var _r = esc__st_run_case(_surf, _row, 4000);
        var _vals = _r.vals, _lg = _r.log;
        _res.events += _lg.events;
        if (is_array(_vals) && _lg.events == _row[9] && _lg.len == _row[10] && _lg.hash == _row[11]) _res.matched += 1;
        else {
            if (array_length(_res.mismatches) < 8) array_push(_res.mismatches, { i: _i, kind: _row[0], wantEvents: _row[9], gotEvents: is_array(_vals) ? _lg.events : -1,
                wantLen: _row[10], gotLen: _lg.len, wantHash: _row[11], gotHash: _lg.hash, gotText: string_copy(_lg.text, 1, 4000) });
            if (_firstFail < 0) _firstFail = _i;
        }
        var _want = _row[12];
        if (is_array(_want)) {
            for (var _v = 0; _v < array_length(_want); _v++) {
                _res.values.checked += 1;
                var _got = (is_array(_vals) && _v < array_length(_vals)) ? _vals[_v] : undefined;
                if (is_numeric(_got) && _got == _want[_v]) _res.values.matched += 1;
                else if (array_length(_res.values.fails) < 8) array_push(_res.values.fails, { i: _i, kind: _row[0], index: _v, want: _want[_v], got: _got });
            }
        }
    }
    // the first failing case's whole log, for diffing offline against Internal_Ops/oracle_draw_logs.json
    if (_firstFail >= 0) {
        var _ff = esc__st_run_case(_surf, _cases[_firstFail], 1000000);
        var _fh = file_text_open_write("esc_draw_firstfail.txt");
        file_text_write_string(_fh, string(_firstFail) + "\n" + _ff.log.text);
        file_text_close(_fh);
        _res.firstFailFile = "esc_draw_firstfail.txt";
    }
    surface_free(_surf);
    matrix_set(matrix_world, _mw);
    math_set_epsilon(_eps);
    return _res;
}
