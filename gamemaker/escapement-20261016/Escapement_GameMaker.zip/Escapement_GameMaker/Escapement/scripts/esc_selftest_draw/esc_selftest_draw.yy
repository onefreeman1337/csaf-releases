{
  "$GMScript": "v1",
  "%Name": "esc_selftest_draw",
  "name": "esc_selftest_draw",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}