/// esc_selftest.gml - Escapement's in-engine self-test, run headless by the demo object with -selftest. Holds the GML port to
/// the RPG Maker MZ edition run in Node: EscapementCore (esc_oracle_core: hashes, generator streams, 300 generated puzzles
/// field for field, gear relations, evaluate() on 300 scripted placements, canPlace over 10,552 arbor x wheel pairs, the
/// solver on 40 puzzles) and EscapementDraw (esc_oracle_draw, through esc__selftest_draw: every paint event of every case).
/// Then counts ink on every drawn wheel style, plays whole puzzles by injected mouse and keyboard input (solve, jam, the
/// pawl, refusals, leaving and carrying on), runs the demo room, and measures what opening a puzzle costs on this runtime.
/// Writes esc_selftest.json and esc_render_*.png.

/// @function esc_st_assert(state, condition, message)
function esc_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 60) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
/// @function esc_st_stage(state, n)
function esc_st_stage(_st, _n) { _st.stage = _n; global.esc_stage = _n; }
function esc__st_near(_a, _b, _tol) { return is_numeric(_a) && is_numeric(_b) && abs(_a - _b) <= _tol; }

/// internal (test): non-transparent pixels in a sprite (alpha > 8), counted on a surface read back as a buffer.
function esc__st_ink(_spr) {
    if (!is_numeric(_spr) || _spr < 0 || !sprite_exists(_spr)) return 0;
    var _w = sprite_get_width(_spr), _h = sprite_get_height(_spr), _s = surface_create(_w, _h);
    surface_set_target(_s); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_zero); draw_sprite(_spr, 0, sprite_get_xoffset(_spr), sprite_get_yoffset(_spr)); gpu_pop_state();
    surface_reset_target();
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _s, 0);
    var _n = 0;
    for (var _i = 3; _i < _w * _h * 4; _i += 4) if (buffer_peek(_b, _i, buffer_u8) > 8) _n++;
    buffer_delete(_b); surface_free(_s);
    return _n;
}
function esc__st_in(_T, _inj) { _T.inject = _inj; esc_step(_T, -1000, -1000); }
/// internal (test): set wheel t on arbor a the way a player does with the mouse: click the arbor, then the wheel's socket
function esc__st_place(_T, _a, _t) {
    var _A = _T.pz.arbors[_a];
    esc__st_in(_T, { x: ESC_PLATE_X + _A.x, y: ESC_PLATE_Y + _A.y, click: true });
    if (_T.mode != "tray") return false;
    esc__st_in(_T, { x: esc__tray_x(_T, _t), y: esc__tray_y(), click: true });
    return _T.placed[_a] == _t;
}
function esc__st_shot(_T, _surf, _name) { surface_set_target(_surf); draw_clear(c_black); esc_draw(_T, 0, 0, 1); surface_reset_target(); surface_save(_surf, _name); }
/// internal (test): the canPlace sweep string for one placement, in the oracle's format (reason index : blocker ;)
function esc__st_cp_sweep(_pz, _pl) {
    var _R = ["ok", "occupied", "in-use", "collide", "covers-post", "under-gear"], _s = "", _ok = 0;
    for (var _a = 0; _a < array_length(_pz.arbors); _a++) for (var _t = 0; _t < array_length(_pz.tray); _t++) {
        var _c = esc_can_place(_pz, _pl, _a, _t), _ri = -1;
        for (var _q = 0; _q < 6; _q++) if (_R[_q] == _c.reason) _ri = _q;
        _s += string(_ri) + ":" + string(_c.blocker) + ";";
        if (_c.ok) _ok++;
    }
    return { h: esc_hash(_s), ok: _ok };
}

/// @function esc_selftest_run()
/// @description Run every check. Returns { total, pass, fail, failures[], ... measurements }.
/// @returns {Struct}
function esc_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, failures: [], stage: 0, runtime: GM_runtime_version, epsilon: 0 };
    var _eps0 = math_get_epsilon();
    math_set_epsilon(0);
    _st.epsilon = math_get_epsilon();
    var _O = esc_oracle_core(), _i, _j;
    var _KINDS = ["train", "trap", "dead", "decoy"], _PAY = esc_payoff_ids(), _MET = esc_metal_ids(), _STY = esc_style_ids();

    // ---- 1. hashes, streams, radii, relations, intersections
    esc_st_stage(_st, 1);
    var _bad = 0;
    for (_i = 0; _i < array_length(_O.hashes); _i++) if (esc_hash(_O.hashes[_i][0]) != _O.hashes[_i][1]) _bad++;
    esc_st_assert(_st, _bad == 0, "hashes: " + string(_bad) + " of " + string(array_length(_O.hashes)) + " differ");
    _bad = 0;
    for (_i = 0; _i < array_length(_O.streams); _i++) { var _r = esc__rng(_O.streams[_i][0]); for (_j = 0; _j < 20; _j++) if (esc__rng_next(_r) != _O.streams[_i][1][_j]) _bad++; }
    esc_st_assert(_st, _bad == 0, "generator streams: " + string(_bad) + " of 60 draws differ (exact)");
    _bad = 0;
    for (_i = 0; _i < array_length(_O.radii); _i++) if (esc_pitch_r(_O.radii[_i][0]) != _O.radii[_i][1] || esc_outer_r(_O.radii[_i][0]) != _O.radii[_i][2]) _bad++;
    esc_st_assert(_st, _bad == 0, "radii: " + string(_bad) + " differ");
    _bad = 0;
    var _RELS = ["mesh", "collide", "free"];
    for (_i = 0; _i < array_length(_O.rels); _i++) { var _q = _O.rels[_i]; if (esc_relation(_q[0], _q[1], _q[2], _q[3], _q[4], _q[5]) != _RELS[_q[6]]) _bad++; }
    esc_st_assert(_st, _bad == 0, "relations: " + string(_bad) + " of " + string(array_length(_O.rels)) + " differ");
    _bad = 0;
    for (_i = 0; _i < array_length(_O.ints); _i++) {
        var _w = _O.ints[_i], _p = esc_intersect(_w[0], _w[1], _w[2], _w[3], _w[4], _w[5]);
        if (array_length(_p) != _w[6]) { _bad++; continue; }
        if (_w[6] > 0 && !(esc__st_near(_p[0].x, _w[7], 0.000001) && esc__st_near(_p[0].y, _w[8], 0.000001) && esc__st_near(_p[1].x, _w[9], 0.000001) && esc__st_near(_p[1].y, _w[10], 0.000001))) _bad++;
    }
    esc_st_assert(_st, _bad == 0, "intersections: " + string(_bad) + " differ");

    // ---- 2. 300 generated puzzles, field for field
    esc_st_stage(_st, 2);
    var _pzs = [], _firstBad = "";
    _bad = 0;
    var _tGen = get_timer();
    for (_i = 0; _i < array_length(_O.puzzles); _i++) {
        var _row = _O.puzzles[_i], _opt = { seed: _row[0] };
        if (_row[1] == -98) _opt.grade = NaN; else _opt.grade = _row[1];
        if (_row[2] >= 0) _opt.payoff = _PAY[_row[2]];
        if (_row[3] >= 0) _opt.metal = _MET[_row[3]];
        var _pz = esc_generate(_opt);
        array_push(_pzs, _pz);
        var _why = "";
        if (!is_struct(_pz)) _why = "undefined";
        else {
            if (_pz.seed != _row[4] || _pz.grade != _row[5] || _pz.attempt != _row[6] || _pz.payoff != _PAY[_row[7]] || _pz.metal != _MET[_row[8]] || _pz.k != _row[9]) _why = "header (seed " + string(_pz.seed) + " grade " + string(_pz.grade) + " attempt " + string(_pz.attempt) + ")";
            else if (!esc__st_near(_pz.drive.x, _row[10], 0.000001) || !esc__st_near(_pz.drive.y, _row[11], 0.000001) || _pz.drive.n != _row[12] || !esc__st_near(_pz.output.x, _row[13], 0.000001) || !esc__st_near(_pz.output.y, _row[14], 0.000001) || _pz.output.n != _row[15]) _why = "drive/output";
            else if (array_length(_pz.arbors) * 3 != array_length(_row[16]) || array_length(_pz.tray) * 3 != array_length(_row[17]) || array_length(_pz.solution) * 2 != array_length(_row[18])) _why = "counts";
            else {
                for (_j = 0; _j < array_length(_pz.arbors) && _why == ""; _j++) { var _A = _pz.arbors[_j]; if (!esc__st_near(_A.x, _row[16][_j * 3], 0.000001) || !esc__st_near(_A.y, _row[16][_j * 3 + 1], 0.000001) || _A.kind != _KINDS[_row[16][_j * 3 + 2]]) _why = "arbor " + string(_j); }
                for (_j = 0; _j < array_length(_pz.tray) && _why == ""; _j++) { var _Tr = _pz.tray[_j]; if (_Tr.n != _row[17][_j * 3] || _Tr.style != _STY[_row[17][_j * 3 + 1]] || _Tr.kind != _KINDS[_row[17][_j * 3 + 2]]) _why = "tray " + string(_j); }
                for (_j = 0; _j < array_length(_pz.solution) && _why == ""; _j++) if (_pz.solution[_j].arbor != _row[18][_j * 2] || _pz.solution[_j].tray != _row[18][_j * 2 + 1]) _why = "solution " + string(_j);
                var _tf = is_struct(_pz.trap) ? _pz.trap.from : -1, _tg = is_struct(_pz.trap) ? _pz.trap.gears : 0;
                if (_why == "" && (_tf != _row[19] || _tg != _row[20])) _why = "trap";
            }
        }
        if (_why != "") { _bad++; if (_firstBad == "") _firstBad = "puzzle " + string(_i) + ": " + _why; }
    }
    _st.generateMsPerPuzzle = (get_timer() - _tGen) / 1000 / array_length(_O.puzzles);
    esc_st_assert(_st, _bad == 0, "generated puzzles: " + string(_bad) + " of " + string(array_length(_O.puzzles)) + " differ from the MZ; first " + _firstBad);
    _st.puzzles = array_length(_pzs);

    // ---- 3. evaluate() on 300 scripted placements: solved / jam / wrong way / direction / every node's s and b
    esc_st_stage(_st, 3);
    _bad = 0; _firstBad = "";
    var _nS = 0, _nJ = 0, _nW = 0;
    for (_i = 0; _i < array_length(_O.evals); _i++) {
        var _e = _O.evals[_i], _pzE = _pzs[_e[0]], _ev = esc_evaluate(_pzE, _e[1]), _w2 = "";
        if (_ev.solved != _e[2] || _ev.jam != _e[3] || _ev.wrongWay != _e[4] || _ev.outputDir != _e[5] || _ev.requiredDir != _e[6] || array_length(_ev.edges) != _e[7]) _w2 = "flags";
        else if ((is_array(_ev.jamEdge) ? _ev.jamEdge[0] : -1) != _e[8] || (is_array(_ev.jamEdge) ? _ev.jamEdge[1] : -1) != _e[9]) _w2 = "jam edge";
        else for (_j = 0; _j < array_length(_e[10]) && _w2 == ""; _j++) {
            if ((_ev.connected[_j] ? 1 : 0) != _e[10][_j]) _w2 = "connected " + string(_j);
            else if (!esc__st_near(_ev.s[_j], _e[11][_j], 0.000000001)) _w2 = "s " + string(_j);
            else if (!esc__st_near(_ev.b[_j], _e[12][_j], 0.000001)) _w2 = "b " + string(_j) + " " + string_format(_ev.b[_j], 0, 9) + " v " + string_format(_e[12][_j], 0, 9);
        }
        if (_ev.solved) _nS++; if (_ev.jam) _nJ++; if (_ev.wrongWay) _nW++;
        if (_w2 != "") { _bad++; if (_firstBad == "") _firstBad = "row " + string(_i) + ": " + _w2; }
    }
    esc_st_assert(_st, _bad == 0, "evaluate: " + string(_bad) + " of " + string(array_length(_O.evals)) + " rows differ; first " + _firstBad);
    esc_st_assert(_st, _nS > 0 && _nJ > 0 && _nW > 0, "the evaluate rows exercise solved (" + string(_nS) + "), jammed (" + string(_nJ) + ") and wrong-way (" + string(_nW) + ")");
    _st.evaluateRows = array_length(_O.evals);

    // ---- 4. canPlace over every arbor x wheel pair, on the empty plate and the solved plate
    esc_st_stage(_st, 4);
    _bad = 0; _firstBad = "";
    var _checks = 0;
    for (_i = 0; _i < array_length(_O.cps); _i++) {
        var _cp = _O.cps[_i], _pzC = _pzs[_cp[0]];
        var _se = esc__st_cp_sweep(_pzC, esc_empty_placement(_pzC)), _ss = esc__st_cp_sweep(_pzC, esc_solution_placement(_pzC));
        _checks += _cp[1] * 2;
        if (_se.h != _cp[2] || _ss.h != _cp[3] || _se.ok != _cp[4] || _ss.ok != _cp[5]) { _bad++; if (_firstBad == "") _firstBad = "puzzle " + string(_cp[0]); }
    }
    esc_st_assert(_st, _bad == 0 && _checks > 10000, "canPlace: " + string(_bad) + " of " + string(array_length(_O.cps)) + " puzzles differ over " + string(_checks) + " checks; first " + _firstBad);
    _st.canPlaceChecks = _checks;

    // ---- 5. the solver (every puzzle solvable; the same search, node for node) and designs
    esc_st_stage(_st, 5);
    _bad = 0; _firstBad = "";
    var _tSolve = get_timer(), _nodes = 0;
    for (_i = 0; _i < array_length(_O.solves); _i++) {
        var _sv = _O.solves[_i], _pzS = _pzs[_sv[0]], _o = esc_solve(_pzS);
        _nodes += _o.nodes;
        var _fs = is_array(_o.firstSolution) && esc_evaluate(_pzS, _o.firstSolution).solved;
        if (_o.solutions != _sv[1] || _o.trapStates != _sv[2] || _o.jamStates != _sv[3] || _o.nodes != _sv[4] || _o.capped != _sv[5] || _fs != _sv[6]) { _bad++; if (_firstBad == "") _firstBad = "puzzle " + string(_sv[0]) + ": " + json_stringify({ solutions: _o.solutions, trap: _o.trapStates, jam: _o.jamStates, nodes: _o.nodes }); }
    }
    _st.solveMsTotal = (get_timer() - _tSolve) / 1000;
    esc_st_assert(_st, _bad == 0 && _nodes > 0, "solver: " + string(_bad) + " of " + string(array_length(_O.solves)) + " differ (" + string(_nodes) + " nodes); first " + _firstBad);
    _bad = 0;
    for (_i = 0; _i < array_length(_O.designs); _i++) { var _dg = esc_designs(_pzs[_O.designs[_i][0]]); if (array_length(_dg) != _O.designs[_i][1]) _bad++; else { var _js = ""; for (_j = 0; _j < array_length(_dg); _j++) _js += ((_j > 0) ? "|" : "") + _dg[_j]; if (esc_hash(_js) != _O.designs[_i][2]) _bad++; } }
    esc_st_assert(_st, _bad == 0, "designs: " + string(_bad) + " differ");
    var _corpus = {};
    for (_i = 0; _i < array_length(_pzs); _i++) { var _dd = esc_designs(_pzs[_i]); for (_j = 0; _j < array_length(_dd); _j++) _corpus[$ _dd[_j]] = true; }
    _st.corpus = array_length(variable_struct_get_names(_corpus));
    esc_st_assert(_st, _st.corpus == _O.corpus, "the corpus over 300 puzzles: " + string(_st.corpus) + " distinct designs (MZ " + string(_O.corpus) + ")");
    // a sabotage that must go red: a wrong grade must not reproduce the puzzle
    var _sab = esc_generate({ seed: _O.puzzles[20][0], grade: (_O.puzzles[20][5] mod 5) + 1 });
    esc_st_assert(_st, is_struct(_sab) && !(esc__st_near(_sab.drive.x, _O.puzzles[20][10], 0.000001) && _sab.k == _O.puzzles[20][9] && array_length(_sab.arbors) * 3 == array_length(_O.puzzles[20][16])), "sabotage: a different grade gives a different puzzle (the comparison can fail)");
    math_set_epsilon(_eps0);

    // ---- 6. the drawing, held to the MZ EscapementDraw paint event for paint event
    esc_st_stage(_st, 6);
    var _dr = esc__selftest_draw();
    _st.draw = { cases: _dr.cases, matched: _dr.matched, events: _dr.events, mismatches: _dr.mismatches, values: _dr.values };
    esc_st_assert(_st, _dr.cases > 0 && _dr.matched == _dr.cases, "drawing: " + string(_dr.matched) + " of " + string(_dr.cases) + " cases match the MZ (" + string(_dr.events) + " paint events)");
    esc_st_assert(_st, _dr.values.checked > 0 && _dr.values.matched == _dr.values.checked, "drawing values (clear sides, anchors): " + string(_dr.values.matched) + " of " + string(_dr.values.checked));

    // ---- 7. ink: every wheel style in every metal puts ink down (a positive control first)
    esc_st_stage(_st, 7);
    var _ctl = esc__bake(80, 80, esc__pnt_gear, { n: 20, style: "disc", metal: "brass", role: "loose" });
    var _ctlInk = esc__st_ink(_ctl);
    esc_st_assert(_st, _ctlInk > 2000, "positive control: a 20-tooth disc wheel inks " + string(_ctlInk) + " px");
    var _empty = esc__bake(80, 80, function(_c, _a) {}, {});
    esc_st_assert(_st, esc__st_ink(_empty) == 0, "negative control: an empty bake inks 0 px");
    _ctl = esc__kill(_ctl); _empty = esc__kill(_empty);
    var _minInk = 1000000000, _minWhat = "", _wheels = 0;
    for (_i = 0; _i < 8; _i++) for (_j = 0; _j < 5; _j++) {
        var _n = esc_teeth()[_i], _R = esc_outer_r(_n) + 2, _spr = esc__bake(_R * 2, _R * 2, esc__pnt_gear, { n: _n, style: _STY[(_i + _j) mod 8], metal: _MET[_j], role: "loose" });
        var _ink = esc__st_ink(_spr), _area = pi * _R * _R;
        if (_ink / _area < _minInk) { _minInk = _ink / _area; _minWhat = string(_n) + " " + _STY[(_i + _j) mod 8] + " " + _MET[_j]; }
        _spr = esc__kill(_spr); _wheels++;
    }
    _st.minInkFraction = _minInk;
    esc_st_assert(_st, _wheels == 40 && _minInk > 0.35, "40 wheels (8 sizes x 5 metals, styles rotated): the thinnest covers " + string_format(_minInk * 100, 0, 1) + "% of its disc (" + _minWhat + ")");

    // ---- 8. a whole puzzle played by the mouse, on every payoff
    esc_st_stage(_st, 8);
    var _shot = surface_create(ESC_SCENE_W, ESC_SCENE_H);
    var _played = 0, _solvedN = 0;
    var _plays = [{ seed: "vault door", grade: 3, payoff: "lock" }, { seed: 4242, grade: 2, payoff: "clock" }, { seed: "orrery", grade: 4, payoff: "orrery" }, { seed: "keep", grade: 5, payoff: "winch" }];
    var _sounds = [];
    for (_i = 0; _i < array_length(_plays); _i++) {
        var _rq = { seed: _plays[_i].seed, grade: _plays[_i].grade, payoff: _plays[_i].payoff, sound: method({ s: _sounds }, function(_nm) { array_push(s, _nm); }) };
        var _T = esc_open(_rq);
        if (!esc_st_assert(_st, is_struct(_T), "esc_open " + json_stringify(_plays[_i]))) continue;
        if (_i == 0) { _st.openMs = _T.bakeMs; _st.openTiming = _T.timing; esc__st_shot(_T, _shot, "esc_render_start.png"); }
        esc_st_assert(_st, esc__st_ink(_T.leather) > ESC_SCENE_W * ESC_SCENE_H * 0.9 && esc__st_ink(_T.bench) > _T.pz.plate.w * _T.pz.plate.h * 0.85, "the leather bench is drawn edge to edge and the plate fills its picture (" + _T.pz.payoff + ")");
        var _sol = _T.pz.solution, _ok = true;
        for (_j = 0; _j < array_length(_sol); _j++) {
            if (!esc__st_place(_T, _sol[_j].arbor, _sol[_j].tray)) _ok = false;
            if (_i == 0 && _j == 1) esc__st_shot(_T, _shot, "esc_render_half.png");
        }
        esc_st_assert(_st, _ok && _T.ev.solved && _T.mode == "solving", "the solution set by the mouse solves it (" + _T.pz.payoff + "): mode " + _T.mode);
        for (_j = 0; _j < 400 && !esc_closed(_T); _j++) { esc__st_in(_T, {}); if (_j == 75) esc__st_shot(_T, _shot, "esc_render_payoff_" + _T.pz.payoff + ".png"); }
        var _rs = _T.result;
        esc_st_assert(_st, esc_closed(_T) && is_struct(_rs) && _rs.solved && _rs.moves == array_length(_sol) && _rs.payoff == _plays[_i].payoff, "the payoff runs and the scene closes solved: " + json_stringify(_rs));
        if (is_struct(_rs) && _rs.solved) _solvedN++;
        _played++;
        esc_free(_T);
    }
    esc_st_assert(_st, _played == 4 && _solvedN == 4, "four payoffs played to the end: " + string(_solvedN));
    esc_st_assert(_st, array_length(_sounds) > 10, "sounds were asked for (" + string(array_length(_sounds)) + ")");

    // ---- 9. the traps: the pawl holds, the odd loop jams, refusals, leaving and carrying on, the keyboard
    esc_st_stage(_st, 9);
    var _T2 = undefined;
    for (_i = 8; _i < 120 && !is_struct(_T2); _i++) if (is_struct(_pzs[_i].trap) && _pzs[_i].grade >= 3) _T2 = esc_open({ seed: _pzs[_i].seed, grade: _pzs[_i].grade, payoff: _pzs[_i].payoff, metal: _pzs[_i].metal });
    if (esc_st_assert(_st, is_struct(_T2), "a trap puzzle opens")) {
        var _pz2 = _T2.pz, _trapA = [], _trapT = [];
        for (_j = 0; _j < array_length(_pz2.arbors); _j++) if (_pz2.arbors[_j].kind == "trap") array_push(_trapA, _j);
        for (_j = 0; _j < array_length(_pz2.tray); _j++) if (_pz2.tray[_j].kind == "trap") array_push(_trapT, _j);
        // the trap route alone: the true train up to the branch, then the trap wheels
        for (_j = 0; _j < _pz2.trap.from; _j++) esc__st_place(_T2, _pz2.solution[_j].arbor, _pz2.solution[_j].tray);
        var _usedT = [];
        for (_j = 0; _j < array_length(_trapA); _j++) for (var _u = 0; _u < array_length(_trapT); _u++) {
            if (array_get_index(_usedT, _trapT[_u]) >= 0) continue;
            if (esc_can_place(_pz2, _T2.placed, _trapA[_j], _trapT[_u]).ok && esc__st_place(_T2, _trapA[_j], _trapT[_u])) { array_push(_usedT, _trapT[_u]); break; }
        }
        esc_st_assert(_st, _T2.ev.wrongWay && !_T2.ev.solved && _T2.warnOn && string_pos("pawl holds", _T2.status) > 0, "the trap route alone: the pawl holds (" + _T2.status + ")");
        var _th0 = _T2.theta; esc__st_in(_T2, {}); esc__st_in(_T2, {});
        esc_st_assert(_st, _T2.theta == _th0, "a stuck train does not turn");
        esc__st_shot(_T2, _shot, "esc_render_pawl.png");
        // the rest of the true train closes an odd loop: jammed
        for (_j = _pz2.trap.from; _j < array_length(_pz2.solution); _j++) esc__st_place(_T2, _pz2.solution[_j].arbor, _pz2.solution[_j].tray);
        esc_st_assert(_st, _T2.ev.jam && !_T2.ev.solved && string_pos("Jammed", _T2.status) > 0, "both routes: the loop jams (" + _T2.status + ")");
        esc__st_shot(_T2, _shot, "esc_render_jammed.png");
        // lift a trap wheel (click its arbor): it runs
        var _lift = -1; for (_j = 0; _j < array_length(_trapA); _j++) if (_T2.placed[_trapA[_j]] >= 0) _lift = _trapA[_j];
        if (_lift >= 0) esc__st_in(_T2, { x: ESC_PLATE_X + _pz2.arbors[_lift].x, y: ESC_PLATE_Y + _pz2.arbors[_lift].y, click: true });
        var _anyTrap = false; for (_j = 0; _j < array_length(_trapA); _j++) if (_T2.placed[_trapA[_j]] >= 0) _anyTrap = true;
        if (_anyTrap) { for (_j = 0; _j < array_length(_trapA); _j++) if (_T2.placed[_trapA[_j]] >= 0) esc__st_in(_T2, { x: ESC_PLATE_X + _pz2.arbors[_trapA[_j]].x, y: ESC_PLATE_Y + _pz2.arbors[_trapA[_j]].y, click: true }); }
        esc_st_assert(_st, _T2.ev.solved && _T2.mode == "solving", "lifting the trap wheels lets it run (mode " + _T2.mode + ")");
        esc_free(_T2);
    }
    // a refusal: a wheel on an arbor it cannot fit (find one), then occupied
    var _T3 = esc_open({ seed: "refusals", grade: 4, payoff: "auto" });
    var _refA = -1, _refT = -1, _why3 = "";
    var _sol3 = _T3.pz.solution;
    for (_j = 0; _j < array_length(_sol3) - 1; _j++) esc__st_place(_T3, _sol3[_j].arbor, _sol3[_j].tray);
    for (_i = 0; _i < array_length(_T3.pz.arbors) && _refA < 0; _i++) for (_j = 0; _j < array_length(_T3.pz.tray); _j++) {
        var _c3 = esc_can_place(_T3.pz, _T3.placed, _i, _j);
        if (_T3.placed[_i] < 0 && array_get_index(_T3.placed, _j) < 0 && !_c3.ok) { _refA = _i; _refT = _j; _why3 = _c3.reason; break; }
    }
    var _before = esc__copy(_T3.placed);
    var _moved = (_refA >= 0) ? esc__st_place(_T3, _refA, _refT) : true;
    esc_st_assert(_st, _refA >= 0 && !_moved && array_equals(_before, _T3.placed) && _T3.flash > 0 && _T3.statusTone == "bad", "a wheel that does not fit is refused (" + _why3 + ": " + _T3.status + ")");
    // the refusal leaves the tray open (as the MZ does): Escape closes it
    esc__st_in(_T3, { cancel: true });
    esc_st_assert(_st, _T3.mode == "board" && !esc_closed(_T3), "after a refusal, Escape closes the tray (mode " + _T3.mode + ")");
    // the keyboard: right/left/up/down move the loupe, Enter opens the tray, Right picks, Escape returns to the plate
    var _cur0 = _T3.cursor, _movedK = false;
    var _dirs = [{ right: true }, { left: true }, { up: true }, { down: true }];
    for (_j = 0; _j < 4; _j++) { esc__st_in(_T3, _dirs[_j]); esc__st_in(_T3, {}); if (_T3.cursor != _cur0) _movedK = true; }
    esc_st_assert(_st, _movedK, "the arrow keys move the loupe between arbors");
    var _free3 = -1; for (_j = 0; _j < array_length(_T3.pz.arbors); _j++) if (_T3.placed[_j] < 0) { _free3 = _j; break; }
    _T3.cursor = _free3;
    esc__st_in(_T3, { ok: true });
    esc_st_assert(_st, _T3.mode == "tray", "Enter on an empty arbor opens the tray (mode " + _T3.mode + ")");
    var _tc0 = _T3.trayCursor; esc__st_in(_T3, { right: true }); esc__st_in(_T3, {});
    esc_st_assert(_st, _T3.trayCursor != _tc0 && _T3.wheelArbor[_T3.trayCursor] < 0, "Right picks the next free wheel");
    esc__st_shot(_T3, _shot, "esc_render_tray.png");
    esc__st_in(_T3, { cancel: true });
    esc_st_assert(_st, _T3.mode == "board" && !esc_closed(_T3), "Escape in the tray returns to the plate");
    esc__st_in(_T3, { cancel: true });
    var _r3 = _T3.result;
    esc_st_assert(_st, esc_closed(_T3) && is_struct(_r3) && !_r3.solved && array_equals(_r3.placed, _T3.placed), "Escape on the plate leaves, unsolved, with the wheels kept: " + json_stringify(_r3));
    esc_free(_T3);
    // carrying on: the kept placement comes back; a placement from another puzzle is refused
    var _T4 = esc_open({ seed: "refusals", grade: 4, payoff: "auto", placed: _r3.placed });
    esc_st_assert(_st, is_struct(_T4) && array_equals(_T4.placed, _r3.placed) && _T4.ev.connected[0], "the kept wheels are laid out again");
    esc_free(_T4);
    var _T5 = esc_open({ seed: "refusals", grade: 4, payoff: "auto", placed: [0, 0, 0] });
    esc_st_assert(_st, is_struct(_T5) && array_equals(_T5.placed, esc_empty_placement(_T5.pz)), "a placement that does not fit this puzzle is ignored");
    esc_free(_T5);
    var _T6 = esc_open({ seed: "no leaving", grade: 1, payoff: "winch", allow_leave: false });
    esc__st_in(_T6, { cancel: true });
    esc_st_assert(_st, !esc_closed(_T6) && string_pos("must be finished", _T6.status) > 0, "allow_leave false refuses Escape");
    esc_free(_T6);
    var _T7 = esc_open({ seed: "same", grade: 3 }), _T8 = esc_open({ seed: "same", grade: 3 });
    esc_st_assert(_st, _T7.pz.seed == _T8.pz.seed && _T7.pz.drive.x == _T8.pz.drive.x && array_length(_T7.pz.arbors) == array_length(_T8.pz.arbors), "the same seed gives the same puzzle");
    esc_free(_T7); esc_free(_T8);
    esc_st_assert(_st, is_undefined(esc_open("not a request")), "esc_open refuses a non-struct");

    // ---- 10. the demo room: open, leave (remembered), solve (stamped)
    esc_st_stage(_st, 10);
    var _D = esc_demo_create();
    esc_demo_step(_D);
    surface_set_target(_shot); draw_clear(c_black); gpu_push_state(); esc_demo_draw(_D); gpu_pop_state(); surface_reset_target(); surface_save(_shot, "esc_render_demo.png");
    _D.inject = { right: true }; esc_demo_step(_D); esc_demo_step(_D);
    esc_st_assert(_st, _D.pick == 1, "Right picks the next mechanism");
    _D.inject = { ok: true }; esc_demo_step(_D);
    esc_st_assert(_st, !is_struct(_D.puzzle) && _D.pending == 1, "Enter shows the wait card first (the open happens on a later step)");
    surface_set_target(_shot); draw_clear(c_black); esc_demo_draw(_D); surface_reset_target(); surface_save(_shot, "esc_render_demo_wait.png");
    esc_demo_step(_D); esc_demo_step(_D);
    esc_st_assert(_st, is_struct(_D.puzzle) && _D.puzzle.pz.payoff == "clock", "then the tower clock opens");
    if (is_struct(_D.puzzle)) {
        var _s0 = _D.puzzle.pz.solution[0];
        _D.puzzle.inject = { x: ESC_PLATE_X + _D.puzzle.pz.arbors[_s0.arbor].x, y: ESC_PLATE_Y + _D.puzzle.pz.arbors[_s0.arbor].y, click: true }; esc_step(_D.puzzle, -1000, -1000);
        _D.puzzle.inject = { x: esc__tray_x(_D.puzzle, _s0.tray), y: esc__tray_y(), click: true }; esc_step(_D.puzzle, -1000, -1000);
        _D.inject = { cancel: true }; esc_demo_step(_D);
    }
    var _keyD = "bench-clock-2";
    esc_st_assert(_st, !is_struct(_D.puzzle) && is_array(_D.placed[$ _keyD]) && array_get_index(_D.placed[$ _keyD], -1) >= 0, "leaving remembers the wheel set");
    _D.inject = { ok: true }; esc_demo_step(_D); esc_demo_step(_D); esc_demo_step(_D);
    if (is_struct(_D.puzzle)) {
        var _P2 = _D.puzzle, _solD = _P2.pz.solution, _n0 = 0;
        for (_j = 0; _j < array_length(_P2.placed); _j++) if (_P2.placed[_j] >= 0) _n0++;
        esc_st_assert(_st, _n0 == 1, "reopening lays out the remembered wheel (" + string(_n0) + ")");
        for (_j = 0; _j < array_length(_solD); _j++) if (_P2.placed[_solD[_j].arbor] < 0) esc__st_place(_P2, _solD[_j].arbor, _solD[_j].tray);
        for (_j = 0; _j < 400 && is_struct(_D.puzzle); _j++) esc_demo_step(_D);
    }
    esc_st_assert(_st, !is_struct(_D.puzzle) && _D.solved[1][1] && !variable_struct_exists(_D.placed, _keyD), "solving it stamps the card and forgets the half-set train");
    surface_set_target(_shot); draw_clear(c_black); esc_demo_draw(_D); surface_reset_target(); surface_save(_shot, "esc_render_demo_solved.png");
    esc_demo_free(_D);

    // ---- 11. cost on this runtime
    esc_st_stage(_st, 11);
    var _T9 = esc_open({ seed: "timing", grade: 5, payoff: "orrery" });
    var _t0 = get_timer();
    for (_i = 0; _i < 120; _i++) { esc__st_in(_T9, {}); surface_set_target(_shot); esc_draw(_T9, 0, 0, 1); surface_reset_target(); }
    _st.frameMs = (get_timer() - _t0) / 1000 / 120;
    _st.openMsGrade5 = _T9.bakeMs; _st.openTimingWarm = _T9.timing;
    var _lea = global.esc_leather; esc_forget_bench();
    esc_st_assert(_st, !sprite_exists(_lea) && _T9.timing.leatherMs < 5, "the leather bench is kept between puzzles (warm open drew it in " + string_format(_T9.timing.leatherMs, 0, 2) + " ms) and esc_forget_bench frees it");
    esc_st_assert(_st, _st.frameMs < 8, "a step + draw costs " + string_format(_st.frameMs, 0, 3) + " ms (budget 8)");
    esc_free(_T9);
    surface_free(_shot);
    esc_st_stage(_st, 99);
    return _st;
}

/// @function esc_selftest_write(state)
/// @description Write the self-test result as esc_selftest.json in the game's save folder.
function esc_selftest_write(_st) {
    var _f = file_text_open_write("esc_selftest.json");
    file_text_write_string(_f, json_stringify(_st));
    file_text_close(_f);
}
