{
  "$GMScript": "v1",
  "%Name": "esc_oracle_core",
  "name": "esc_oracle_core",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}