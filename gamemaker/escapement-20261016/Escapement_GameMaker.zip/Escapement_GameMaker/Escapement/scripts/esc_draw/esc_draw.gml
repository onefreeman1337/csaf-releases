/// esc_draw.gml - Escapement's drawing: the leather bench, the mechanism plate, every wheel in every metal and spoke style,
/// the jewelled arbors, the turn arrows and hints, the four payoff mechanisms (the strongroom lock, the tower clock, the
/// orrery, the portcullis winch) and their moving parts, the tray of loose wheels, the cursor and the words. Nothing here is
/// an image file: every picture is drawn when it is asked for, through the esc_canvas kit.
///
/// Escapement - Generated Clockwork Gear Puzzles, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// This is the RPG Maker MZ edition's EscapementDraw.js, ported op for op and HELD to it: the self-test runs the MZ drawing in
/// Node over a recording canvas and compares every fill, even-odd fill, stroke (and its dash), rectangle, stroked rectangle,
/// clip and line of text - colour, alpha, line width, caps, the path it paints and the transform it paints under - against
/// what this file asks the kit to do (esc_oracle_draw, run by esc__selftest_draw).
///
/// ⛔ GameMaker evaluates a function call's ARGUMENTS RIGHT TO LEFT. Wherever the MZ code draws several numbers from a
/// generator inside one expression (the bench's leather grain, the plate's brushed strokes, the orrery's stars, the tray's
/// wood grain), this file draws them into variables first, in the original's order.
/// ⛔ Every public function runs under math_set_epsilon(0) and hands the caller's epsilon back: GameMaker's default 1e-5
/// comparison epsilon decides loop ends and ties that JavaScript decides exactly.
///
/// Public functions (each documented below): esc_metal, esc_accent, esc_draw_gear, esc_tooth_path, esc_draw_shadow,
/// esc_draw_glint, esc_draw_bench, esc_draw_plate, esc_draw_arbor, esc_draw_turn_arrow, esc_draw_turn_hint, esc_clear_side,
/// esc_draw_payoff_base, esc_draw_bolt, esc_draw_hand, esc_draw_planet_arm, esc_draw_sun, esc_draw_drum, esc_draw_weight,
/// esc_draw_tray, esc_draw_window_word, esc_draw_warning, esc_draw_cursor, esc_draw_status, esc_draw_heading, esc_engrave,
/// esc_jewel. Metals are passed BY NAME ("brass", "steel", "bronze", "verdigris", "gunmetal"; anything else draws brass, as
/// the MZ does); colours as [r, g, b].

#macro ESC_TAU (pi * 2)
/// the italic lines are the upright Body face sheared 12 degrees (tan 12 = 0.2126) - a named deviation: the MZ sets them in
/// Palatino Italic, a system face no package may ship, and no OFL italic is part of this package
#macro ESC_OBLIQUE 0.2126
/// the largest size (a width, a height) a public drawing call accepts; a radius may be half of it
#macro ESC_DRAW_MAX 4096

// ---------------------------------------------------------------------------------------------------------------
// Guards: every documented drawing call REFUSES (draws nothing, returns its neutral value) rather than throwing inside the
// caller's Draw event when handed something that is not a drawing context, a finite number, a known style or role, or a
// puzzle struct without the fields it reads. GML resolves a field read on a non-struct against the CALLING INSTANCE, so an
// unguarded read surfaces in the buyer's project as "Variable obj_theirs.<our field> not set" - a support ticket nobody can
// trace. Valid input still draws exactly the MZ's operations.
// ---------------------------------------------------------------------------------------------------------------

function esc__is_ctx(_c) { return is_struct(_c) && is_array(_c[$ "m"]) && array_length(_c.m) == 6 && is_struct(_c[$ "fill"]) && is_struct(_c[$ "stroke"]) && is_array(_c[$ "stack"]) && is_array(_c[$ "dash"]); }
/// true when every argument is a finite number
function esc__dfin() { for (var _i = 0; _i < argument_count; _i++) { var _v = argument[_i]; if (!is_numeric(_v) || is_nan(_v) || is_infinity(_v)) return false; } return true; }
/// switch GameMaker's comparison epsilon off for a drawing call; returns the caller's, to hand back
function esc__eps_in() { var _e = math_get_epsilon(); math_set_epsilon(0); return _e; }
/// a > b decided exactly (JavaScript's >): the difference is magnified past any epsilon floor before it is compared
function esc__gt(_a, _b) { return (_a - _b) * 1000000000000000 > 0; }
/// the puzzle's plate, sane: { w, h, payoffX } finite, w and h in 40..ESC_DRAW_MAX, 0 <= payoffX <= w, and a numeric seed
function esc__plate_ok(_pz) {
    if (!is_struct(_pz)) return false;
    var _pl = _pz[$ "plate"];
    if (!is_struct(_pl) || !esc__dfin(_pl[$ "w"], _pl[$ "h"], _pl[$ "payoffX"], _pz[$ "seed"])) return false;
    return _pl.w >= 40 && _pl.h >= 40 && _pl.w <= ESC_DRAW_MAX && _pl.h <= ESC_DRAW_MAX && _pl.payoffX >= 0 && _pl.payoffX <= _pl.w;
}

// ---------------------------------------------------------------------------------------------------------------
// Metals (the MZ's hex constants as [r, g, b]) and the accent alloy a payoff is cut in
// ---------------------------------------------------------------------------------------------------------------

function esc__metals() {
    static _M = {
        brass:     { hi: [244, 221, 151], mid: [200, 155, 69], lo: [125, 90, 30], edge: [74, 51, 16], cut: [92, 65, 21], glint: [255, 248, 214], glintA: 0.55, plateHi: [230, 199, 122], plateMid: [185, 143, 63], plateLo: [110, 79, 27] },
        steel:     { hi: [227, 232, 238], mid: [142, 154, 168], lo: [70, 80, 92], edge: [31, 37, 44], cut: [44, 52, 61], glint: [240, 248, 255], glintA: 0.6, plateHi: [185, 198, 214], plateMid: [95, 114, 136], plateLo: [43, 55, 72] },
        bronze:    { hi: [231, 185, 138], mid: [168, 107, 60], lo: [92, 52, 25], edge: [46, 25, 11], cut: [68, 37, 17], glint: [255, 232, 210], glintA: 0.5, plateHi: [208, 154, 104], plateMid: [142, 86, 48], plateLo: [74, 41, 18] },
        verdigris: { hi: [185, 226, 207], mid: [95, 159, 134], lo: [44, 86, 71], edge: [21, 48, 42], cut: [31, 64, 54], glint: [225, 255, 240], glintA: 0.45, plateHi: [159, 201, 179], plateMid: [77, 133, 112], plateLo: [34, 63, 53] },
        gunmetal:  { hi: [184, 180, 196], mid: [94, 90, 108], lo: [42, 39, 51], edge: [17, 16, 22], cut: [27, 26, 34], glint: [235, 230, 255], glintA: 0.5, plateHi: [143, 138, 160], plateMid: [69, 65, 82], plateLo: [31, 29, 39] }
    };
    return _M;
}

/// @function esc_metal(name)
/// @description A metal's colours by name: { hi, mid, lo (the face ramp), edge (the tooth outline), cut (the colour an
/// engraved line reads in), glint + glintA (the specular, [r, g, b] and alpha), plateHi, plateMid, plateLo (the plate) },
/// every colour an [r, g, b] array. An unknown name (or a non-string) gives brass, as the MZ does. Shared: do not modify.
/// @param {String} name brass, steel, bronze, verdigris or gunmetal
/// @returns {Struct}
function esc_metal(_name) {
    var _M = esc__metals();
    if (is_string(_name) && variable_struct_exists(_M, _name)) return _M[$ _name];
    return _M.brass;
}

/// @function esc_accent(name)
/// @description The NAME of the second alloy a metal's payoff mechanism, screws and ratchet are cut in (brass -> steel,
/// steel -> brass, bronze -> brass, verdigris -> bronze, gunmetal -> brass); an unknown name gives "steel", as the MZ does.
/// @param {String} name a metal name
/// @returns {String}
function esc_accent(_name) {
    if (!is_string(_name)) return "steel";
    switch (_name) { case "brass": return "steel"; case "steel": return "brass"; case "bronze": return "brass"; case "verdigris": return "bronze"; case "gunmetal": return "brass"; }
    return "steel";
}

// ---------------------------------------------------------------------------------------------------------------
// The logged verbs this file adds to esc_paint's (the oracle's T, L and K events), the state save that also keeps the text
// settings, and type: three styles over the two faces, plus the one non-ASCII character Escapement sets (U+00B7)
// ---------------------------------------------------------------------------------------------------------------

/// the canvas save(), keeping the text settings (font, align, baseline) with the rest of the state, as a canvas does
function esc__save(_c) {
    esc_cx_save(_c);
    var _s = _c.stack[array_length(_c.stack) - 1];
    _s.esc_tf = _c[$ "tf"]; _s.esc_ta = _c[$ "ta"]; _s.esc_tb = _c[$ "tb"];
}
/// the canvas restore()
function esc__restore(_c) {
    var _n = array_length(_c.stack);
    if (_n == 0) return;
    var _s = _c.stack[_n - 1];
    _c.tf = _s[$ "esc_tf"]; _c.ta = _s[$ "esc_ta"]; _c.tb = _s[$ "esc_tb"];
    esc_cx_restore(_c);
}

/// face 0 = bold (Escapement Display, Cinzel Bold), 1 = regular (Escapement Body, Alegreya), 2 = italic (Escapement Body
/// struck oblique): the canvas font string's style word -> face
function esc__face_of(_style) {
    if (!is_string(_style)) return 1;
    if (string_pos("bold", _style) > 0) return 0;
    if (string_pos("italic", _style) > 0) return 2;
    return 1;
}
/// the kit face an atlas is struck from
function esc__kit_face(_face) { return (_face == 0) ? ESC_FACE_DISPLAY : ESC_FACE_BODY; }
/// U+00B7 in each face, read from the TTFs (Internal_Ops/font_advances.json "extra"): advance, dot centre and radius in em
function esc__dot(_face) { return (esc__kit_face(_face) == ESC_FACE_DISPLAY) ? { adv: 0.219, cx: 0.1095, cy: 0.353, r: 0.0725 } : { adv: 0.238, cx: 0.1195, cy: 0.2275, r: 0.0595 }; }
/// the width of a line at px, summed character by character in the order the oracle sums it (ASCII from the advance table,
/// U+00B7 from esc__dot), then times px; any other character measures 0
function esc__text_w(_s, _px, _face) {
    var _t = is_string(_s) ? _s : string(_s), _adv = esc_text_advance(esc__kit_face(_face)), _dot = esc__dot(_face), _sum = 0;
    for (var _i = 1; _i <= string_length(_t); _i++) { var _o = ord(string_char_at(_t, _i)); if (_o >= 32 && _o <= 126) _sum += _adv[_o - 32]; else if (_o == 183) _sum += _dot.adv; }
    return _sum * _px;
}
/// the canvas font: px and face
function esc__font(_c, _px, _face) { _c.tf = { px: _px, face: _face }; }
/// the canvas textAlign word -> 0 left, 1 centre, 2 right (empty or missing = centre, the MZ engrave's default)
function esc__align_code(_a) {
    if (!is_string(_a) || _a == "" || _a == "center") return 1;
    if (_a == "right") return 2;
    return 0;
}
/// the canvas measureText(t).width in the current font
function esc__measure(_c, _t) { var _f = _c[$ "tf"]; if (!is_struct(_f)) return esc__text_w(_t, 10, 1); return esc__text_w(_t, _f.px, _f.face); }
/// one glyph at the user-space baseline-left (x, y): an atlas glyph, the middle dot as a disc, an italic face sheared about
/// the glyph's DEVICE baseline (composed with the caller's world matrix, which is handed back)
function esc__strike(_c, _ch, _x, _y, _px, _face) {
    var _o = ord(_ch);
    if (_o == 183) {
        var _d = esc__dot(_face), _subs = _c.subs, _cur = _c.cur;
        esc_cx_begin(_c); esc_cx_arc(_c, _x + _d.cx * _px, _y - _d.cy * _px, _d.r * _px, 0, ESC_TAU); esc_cx_fill(_c);
        _c.subs = _subs; _c.cur = _cur;
        return;
    }
    if (_face < 2) { esc_cx_glyph(_c, _ch, _x, _y, _px, _face); return; }
    var _p = esc_cx__pt(_c, _x, _y), _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_multiply([1, 0, 0, 0, -ESC_OBLIQUE, 1, 0, 0, 0, 0, 1, 0, ESC_OBLIQUE * _p[1], 0, 0, 1], _mw));
    esc_cx_glyph(_c, _ch, _x, _y, _px, esc__kit_face(_face));
    matrix_set(matrix_world, _mw);
}
/// the canvas fillText of a whole line: logged as ONE event (the oracle's T: paint, the line's FNV hash, x + y, px, face,
/// align + baseline, transform, alpha), struck glyph by glyph under the transform. A gradient paint strikes in its first stop
/// (the kit's glyph rule) and is logged as the gradient.
function esc__q_text(_c, _t, _x, _y) {
    var _f = _c[$ "tf"], _al = _c[$ "ta"], _bl = _c[$ "tb"];
    if (!is_struct(_f)) _f = { px: 10, face: 1 };
    if (!is_numeric(_al)) _al = 0;
    if (!is_numeric(_bl)) _bl = 0;
    var _s = is_string(_t) ? _t : string(_t);
    if (esc__logging(_c)) esc__lg_emit(_c, "T" + esc__lg_paint(_c.fill) + ":" + string(int64(esc_hash(_s))) + ":" + string(esc__r100(_x + _y)) + ":" + string(esc__r100(_f.px)) + ":" + string(_f.face) + ":" + ((_al == 1) ? "c" : ((_al == 2) ? "r" : "l")) + ((_bl == 1) ? "m" : "a") + ":" + esc__lg_t(_c) + esc__lg_a(_c) + ";");
    var _w = esc__text_w(_s, _f.px, _f.face), _xx = (_al == 1) ? _x - _w / 2 : ((_al == 2) ? _x - _w : _x);
    // a canvas "middle" baseline sits about a third of the em below the point (the em box's middle)
    var _yy = (_bl == 1) ? _y + _f.px * ((esc__kit_face(_f.face) == ESC_FACE_BODY) ? 0.32 : 0.34) : _y;
    var _adv = esc_text_advance(esc__kit_face(_f.face)), _dot = esc__dot(_f.face);
    for (var _i = 1; _i <= string_length(_s); _i++) {
        var _ch = string_char_at(_s, _i), _o = ord(_ch);
        if (_o != 32) esc__strike(_c, _ch, _xx, _yy, _f.px, _f.face);
        if (_o >= 32 && _o <= 126) _xx += _adv[_o - 32] * _f.px; else if (_o == 183) _xx += _dot.adv * _f.px;
    }
}
/// the dash pattern as the oracle writes it ("6,5")
function esc__dash_str(_d) { var _s = ""; for (var _i = 0; _i < array_length(_d); _i++) _s += ((_i > 0) ? "," : "") + string(_d[_i]); return _s; }
/// the canvas stroke(): a dashed line logs its pattern first (the oracle's L), then the stroke (S)
function esc__q_stroke(_c) {
    if (esc__logging(_c) && array_length(_c.dash) > 0) esc__lg_emit(_c, "L" + esc__dash_str(_c.dash) + ";");
    esc__p_stroke(_c);
}
/// the canvas strokeRect(x, y, w, h): logged as L (when dashed) then K (paint, line width, x + y + w + h, transform, alpha);
/// it does not touch the current path. The kit's stroke_rect does not dash, so a dashed one is stroked as a path.
function esc__q_stroke_rect(_c, _x, _y, _w, _h) {
    if (esc__logging(_c)) {
        if (array_length(_c.dash) > 0) esc__lg_emit(_c, "L" + esc__dash_str(_c.dash) + ";");
        esc__lg_emit(_c, "K" + esc__lg_paint(_c.stroke) + ":" + string(esc__r100(_c.lw)) + ":" + string(esc__r100(_x + _y + _w + _h)) + ":" + esc__lg_t(_c) + esc__lg_a(_c) + ";");
    }
    if (array_length(_c.dash) == 0) { esc_cx_stroke_rect(_c, _x, _y, _w, _h); return; }
    var _subs = _c.subs, _cur = _c.cur;
    _c.subs = []; _c.cur = undefined;
    esc_cx_rect(_c, _x, _y, _w, _h);
    esc_cx_stroke(_c);
    _c.subs = _subs; _c.cur = _cur;
}
/// the canvas rect(x, y, w, h) path verb, logged as the recorder adds it (term by term)
function esc__q_rect(_c, _x, _y, _w, _h) {
    if (esc__logging(_c)) { _c.esc_lg.n += 1; _c.esc_lg.s += _x; _c.esc_lg.s += _y; _c.esc_lg.s += _w; _c.esc_lg.s += _h; }
    esc_cx_rect(_c, _x, _y, _w, _h);
}

// ---------------------------------------------------------------------------------------------------------------
// Small helpers (the MZ's own)
// ---------------------------------------------------------------------------------------------------------------

/// the MZ roundRect(ctx, x, y, w, h, r): quadratic corners, the radius NOT clamped (as the MZ)
function esc__rr(_c, _x, _y, _w, _h, _r) {
    esc__p_begin(_c);
    esc__p_move(_c, _x + _r, _y); esc__p_line(_c, _x + _w - _r, _y); esc__p_quad(_c, _x + _w, _y, _x + _w, _y + _r);
    esc__p_line(_c, _x + _w, _y + _h - _r); esc__p_quad(_c, _x + _w, _y + _h, _x + _w - _r, _y + _h);
    esc__p_line(_c, _x + _r, _y + _h); esc__p_quad(_c, _x, _y + _h, _x, _y + _h - _r);
    esc__p_line(_c, _x, _y + _r); esc__p_quad(_c, _x, _y, _x + _r, _y);
    esc__p_close(_c);
}
/// the MZ faceGrad(ctx, R, m): a face gradient lit from the upper left
function esc__face_grad(_c, _R, _m) {
    var _g = esc_cx_linear(_c, -_R, -_R, _R, _R);
    esc_cx_stop(_g, 0, _m.hi); esc_cx_stop(_g, 0.45, _m.mid); esc_cx_stop(_g, 1, _m.lo);
    return _g;
}
/// the MZ engrave(ctx, text, x, y, size, m, align, weight): a dark cut with a light lip below it
function esc__engrave(_c, _t, _x, _y, _size, _m, _align, _weight) {
    esc__save(_c);
    esc__font(_c, _size, esc__face_of(_weight));
    _c.ta = esc__align_code(_align); _c.tb = 1;
    _c.fill = esc_cx_solid([255, 255, 255], 0.35);
    esc__q_text(_c, _t, _x, _y + 1);
    _c.fill = esc_cx_solid(_m.cut);
    esc__q_text(_c, _t, _x, _y);
    esc__restore(_c);
}
/// the MZ screw(ctx, x, y, r, m, ang): a slotted screw head; an angle of 0 (or none) turns the slot by 0.6, as the MZ's
/// (ang || 0.6) does
function esc__screw(_c, _x, _y, _r, _m, _ang) {
    esc__save(_c);
    esc_cx_translate(_c, _x, _y);
    var _g = esc_cx_radial(_c, -_r * 0.35, -_r * 0.35, _r * 0.1, 0, 0, _r);
    esc_cx_stop(_g, 0, _m.hi); esc_cx_stop(_g, 0.6, _m.mid); esc_cx_stop(_g, 1, _m.lo);
    _c.fill = _g;
    esc__p_begin(_c); esc__p_arc(_c, 0, 0, _r, 0, ESC_TAU); esc__p_fill(_c);
    _c.stroke = esc_cx_solid(_m.edge); _c.lw = 1; esc__q_stroke(_c);
    esc_cx_rotate(_c, (is_numeric(_ang) && !is_nan(_ang) && _ang != 0) ? _ang : 0.6);
    _c.fill = esc_cx_solid(_m.edge);
    esc__p_fill_rect(_c, -_r * 0.85, -_r * 0.14, _r * 1.7, _r * 0.28);
    esc__restore(_c);
}
/// the MZ jewel(ctx, x, y, s): a ruby bearing in a gold chaton
function esc__jewel(_c, _x, _y, _s) {
    esc__save(_c);
    esc_cx_translate(_c, _x, _y);
    var _gold = esc_metal("brass");
    var _g = esc_cx_radial(_c, -_s * 0.3, -_s * 0.3, 1, 0, 0, _s);
    esc_cx_stop(_g, 0, _gold.hi); esc_cx_stop(_g, 0.7, _gold.mid); esc_cx_stop(_g, 1, _gold.lo);
    _c.fill = _g;
    esc__p_begin(_c); esc__p_arc(_c, 0, 0, _s, 0, ESC_TAU); esc__p_fill(_c);
    _c.stroke = esc_cx_solid(_gold.edge); _c.lw = 1; esc__q_stroke(_c);
    // the ruby
    var _rr = _s * 0.55;
    var _rg = esc_cx_radial(_c, -_rr * 0.3, -_rr * 0.35, 0.5, 0, 0, _rr);
    esc_cx_stop(_rg, 0, [255, 179, 193]); esc_cx_stop(_rg, 0.35, [212, 33, 63]); esc_cx_stop(_rg, 1, [90, 7, 20]);
    _c.fill = _rg;
    esc__p_begin(_c); esc__p_arc(_c, 0, 0, _rr, 0, ESC_TAU); esc__p_fill(_c);
    // the pivot hole
    _c.fill = esc_cx_solid([26, 2, 5]);
    esc__p_begin(_c); esc__p_arc(_c, 0, 0, _rr * 0.28, 0, ESC_TAU); esc__p_fill(_c);
    _c.fill = esc_cx_solid([255, 255, 255], 0.75);
    esc__p_begin(_c); esc__p_arc(_c, -_rr * 0.35, -_rr * 0.4, _rr * 0.18, 0, ESC_TAU); esc__p_fill(_c);
    esc__restore(_c);
}

// ---------------------------------------------------------------------------------------------------------------
// Gears
// ---------------------------------------------------------------------------------------------------------------

/// the MZ toothPath(ctx, n, module): one closed path; teeth centred on angles k * 2pi / n, tooth 0 along +x
function esc__tooth_path(_c, _n, _mod) {
    var _r = _n * _mod / 2, _ra = _r + _mod, _rf = _r - 1.25 * _mod, _p = ESC_TAU / _n;
    esc__p_begin(_c);
    for (var _k = 0; _k < _n; _k++) {
        var _cc = _k * _p;
        // root flank, pitch flank, tip land, pitch flank, root flank: a trapezoid with curved flanks
        var _pr = [_rf, _rf, _r, _ra - 0.3, _ra, _ra, _ra - 0.3, _r, _rf];
        var _pa = [_cc - 0.5 * _p, _cc - 0.30 * _p, _cc - 0.24 * _p, _cc - 0.15 * _p, _cc - 0.10 * _p, _cc + 0.10 * _p, _cc + 0.15 * _p, _cc + 0.24 * _p, _cc + 0.30 * _p];
        for (var _i = 0; _i < 9; _i++) {
            var _x = _pr[_i] * cos(_pa[_i]), _y = _pr[_i] * sin(_pa[_i]);
            if (_k == 0 && _i == 0) esc__p_move(_c, _x, _y); else esc__p_line(_c, _x, _y);
        }
    }
    esc__p_close(_c);
}
/// the MZ webHoles(ctx, style, rIn, hub): the spokes, windows or holes between rim and hub, appended to the current path
function esc__web_holes(_c, _style, _rIn, _hub) {
    var _i, _a, _n;
    if (_style == "disc") return;
    if (string_pos("spokes", _style) == 1 || _style == "curved") {
        _n = (_style == "curved") ? 5 : real(string_delete(_style, 1, 6));
        var _spokeHalf = max(0.09, 0.5 / _n) * ((_style == "curved") ? 0.9 : 1);
        var _gapHalf = pi / _n - _spokeHalf;
        for (_i = 0; _i < _n; _i++) {
            _a = _i * ESC_TAU / _n + pi / _n;
            esc__p_move(_c, (_hub + 3) * cos(_a - _gapHalf * 0.7), (_hub + 3) * sin(_a - _gapHalf * 0.7));
            if (_style == "curved") {
                var _bend = 0.45;
                esc__p_quad(_c, (_rIn * 0.55) * cos(_a - _gapHalf + _bend), (_rIn * 0.55) * sin(_a - _gapHalf + _bend),
                    _rIn * cos(_a - _gapHalf + _bend * 0.6), _rIn * sin(_a - _gapHalf + _bend * 0.6));
                esc__p_arc(_c, 0, 0, _rIn, _a - _gapHalf + _bend * 0.6, _a + _gapHalf + _bend * 0.6);
                esc__p_quad(_c, (_rIn * 0.55) * cos(_a + _gapHalf + _bend), (_rIn * 0.55) * sin(_a + _gapHalf + _bend),
                    (_hub + 3) * cos(_a + _gapHalf * 0.7), (_hub + 3) * sin(_a + _gapHalf * 0.7));
            } else {
                esc__p_line(_c, _rIn * cos(_a - _gapHalf), _rIn * sin(_a - _gapHalf));
                esc__p_arc(_c, 0, 0, _rIn, _a - _gapHalf, _a + _gapHalf);
                esc__p_line(_c, (_hub + 3) * cos(_a + _gapHalf * 0.7), (_hub + 3) * sin(_a + _gapHalf * 0.7));
            }
            esc__p_close(_c);
        }
        return;
    }
    if (_style == "holes") {
        _n = (_rIn > 38) ? 6 : 5;
        var _ring = (_rIn + _hub) / 2, _hr = min((_rIn - _hub) * 0.36, _ring * sin(pi / _n) * 0.72);
        for (_i = 0; _i < _n; _i++) {
            _a = _i * ESC_TAU / _n;
            esc__p_move(_c, _ring * cos(_a) + _hr, _ring * sin(_a));
            esc__p_arc(_c, _ring * cos(_a), _ring * sin(_a), _hr, 0, ESC_TAU);
            esc__p_close(_c);
        }
        return;
    }
    if (_style == "cross") {
        // four windows shaped like a crossing of two bars: each window a quarter annulus pinched at the bars
        for (_i = 0; _i < 4; _i++) {
            _a = _i * ESC_TAU / 4 + pi / 4;
            var _hw = pi / 4 - 0.22;
            esc__p_move(_c, (_hub + 6) * cos(_a), (_hub + 6) * sin(_a));
            esc__p_line(_c, _rIn * cos(_a - _hw), _rIn * sin(_a - _hw));
            esc__p_arc(_c, 0, 0, _rIn, _a - _hw, _a + _hw);
            esc__p_close(_c);
        }
    }
}
/// the MZ drawGear(ctx, spec) on validated input; returns { ops }
function esc__draw_gear(_c, _n, _mod, _style, _metal, _role) {
    var _ops = 0;
    var _m = esc_metal(_metal), _acc = esc_metal(esc_accent(_metal));
    var _r = _n * _mod / 2, _ra = _r + _mod, _rf = _r - 1.25 * _mod;
    var _rim = _rf - max(4, _mod * 1.1);
    var _hub = max(7, _r * 0.2);
    var _st = (_role == "drive") ? "disc" : _style;
    esc__save(_c);
    // teeth and wheel body in one even-odd path, holes cut out
    esc__tooth_path(_c, _n, _mod);
    esc__web_holes(_c, _st, _rim, _hub);
    // the bore
    esc__p_move(_c, _hub * 0.35, 0); esc__p_arc(_c, 0, 0, _hub * 0.35, 0, ESC_TAU);
    _c.fill = esc__face_grad(_c, _ra, _m);
    esc__p_fill(_c, true); _ops++;
    _c.stroke = esc_cx_solid(_m.edge); _c.lw = 1.2; esc__q_stroke(_c); _ops++;
    // circular graining across the face, the watchmaker's finish
    esc__save(_c);
    esc__tooth_path(_c, _n, _mod); esc__web_holes(_c, _st, _rim, _hub);
    esc__p_clip(_c, true);
    _c.lw = 0.6;
    for (var _cr = _hub + 2; _cr < _rf; _cr += 2.2) {
        _c.stroke = ((floor(_cr * 7 + 0.5) mod 3) == 0) ? esc_cx_solid([255, 255, 255], 0.10) : esc_cx_solid([0, 0, 0], 0.07);
        esc__p_begin(_c); esc__p_arc(_c, 0, 0, _cr, 0, ESC_TAU); esc__q_stroke(_c);
    }
    _ops++;
    esc__restore(_c);
    // the rim: a raised ring with a light inner lip and a dark outer groove
    _c.lw = 1.4;
    _c.stroke = esc_cx_solid([0, 0, 0], 0.35);
    esc__p_begin(_c); esc__p_arc(_c, 0, 0, _rf - 1, 0, ESC_TAU); esc__q_stroke(_c);
    if (_st != "disc") {
        _c.stroke = esc_cx_solid([255, 255, 255], 0.35);
        esc__p_begin(_c); esc__p_arc(_c, 0, 0, _rim - 0.5, 0, ESC_TAU); esc__q_stroke(_c);
        _c.stroke = esc_cx_solid(_m.edge); _c.lw = 1;
        esc__p_begin(_c); esc__p_arc(_c, 0, 0, _rim + 0.6, 0, ESC_TAU); esc__q_stroke(_c);
    }
    _ops++;
    if (_role == "drive") {
        // a mainspring barrel: a closed drum, its cover engraved with the coiled spring (the MZ's t === 0 is the first
        // point, which a flag decides exactly)
        _c.stroke = esc_cx_solid(_m.cut); _c.lw = 1.2;
        esc__p_begin(_c);
        var _first = true;
        for (var _t = 0; _t < 7 * ESC_TAU; _t += 0.08) {
            var _rr = _hub + 2 + (_rim - _hub - 6) * (_t / (7 * ESC_TAU));
            var _x = _rr * cos(_t), _y = _rr * sin(_t);
            if (_first) { esc__p_move(_c, _x, _y); _first = false; } else esc__p_line(_c, _x, _y);
        }
        esc__q_stroke(_c); _ops++;
        // ratchet wheel on the arbor
        var _rw = _hub * 1.9;
        esc__p_begin(_c);
        for (var _q = 0; _q < 16; _q++) {
            var _a0 = _q * ESC_TAU / 16;
            esc__p_line(_c, _rw * cos(_a0), _rw * sin(_a0));
            esc__p_line(_c, _rw * 0.78 * cos(_a0 + ESC_TAU / 16 * 0.85), _rw * 0.78 * sin(_a0 + ESC_TAU / 16 * 0.85));
        }
        esc__p_close(_c);
        _c.fill = esc__face_grad(_c, _rw, _acc); esc__p_fill(_c); _c.stroke = esc_cx_solid(_acc.edge); esc__q_stroke(_c); _ops++;
    } else if (_st == "disc") {
        // a solid wheel gets a turned recess and a ring of index dots
        _c.stroke = esc_cx_solid(_m.cut); _c.lw = 1;
        esc__p_begin(_c); esc__p_arc(_c, 0, 0, (_rf + _hub) * 0.55, 0, ESC_TAU); esc__q_stroke(_c);
        _c.fill = esc_cx_solid(_m.cut);
        var _dots = max(6, floor(_n / 2 + 0.5));
        for (var _d = 0; _d < _dots; _d++) {
            var _da = _d * ESC_TAU / _dots;
            esc__p_begin(_c); esc__p_arc(_c, (_rf - 5) * cos(_da), (_rf - 5) * sin(_da), 1.1, 0, ESC_TAU); esc__p_fill(_c);
        }
        _ops++;
    }
    // hub boss with three screws and the arbor
    esc__p_begin(_c); esc__p_arc(_c, 0, 0, _hub, 0, ESC_TAU);
    var _hg = esc_cx_radial(_c, -_hub * 0.4, -_hub * 0.4, 1, 0, 0, _hub);
    esc_cx_stop(_hg, 0, _m.hi); esc_cx_stop(_hg, 1, _m.lo);
    _c.fill = _hg; esc__p_fill(_c); _c.stroke = esc_cx_solid(_m.edge); _c.lw = 1; esc__q_stroke(_c); _ops++;
    if (_hub >= 9) {
        for (var _s = 0; _s < 3; _s++) {
            var _sa = _s * ESC_TAU / 3 + 0.5;
            esc__screw(_c, _hub * 0.62 * cos(_sa), _hub * 0.62 * sin(_sa), max(1.6, _hub * 0.2), _acc, _sa * 2);
        }
        _ops++;
    }
    esc__p_begin(_c); esc__p_arc(_c, 0, 0, max(2.5, _hub * 0.3), 0, ESC_TAU);
    _c.fill = esc_cx_solid(_acc.mid); esc__p_fill(_c); _c.stroke = esc_cx_solid(_acc.edge); esc__q_stroke(_c);
    // a timing mark on tooth 0, so a turning wheel visibly turns
    _c.fill = esc_cx_solid(_m.cut);
    esc__p_begin(_c); esc__p_arc(_c, _rf - 3.5, 0, 1.6, 0, ESC_TAU); esc__p_fill(_c); _ops++;
    esc__restore(_c);
    return { ops: _ops };
}

/// @function esc_draw_gear(ctx, spec)
/// @description Draw one wheel centred at the context origin: spec = { n (teeth), module (default 5), style ("disc",
/// "spokes3", "spokes4", "spokes5", "spokes6", "curved", "holes", "cross"; default "spokes5"), metal (a name), role ("loose",
/// "drive" or "output"; default "loose") }. A drive wheel is a mainspring barrel (always a disc, a coiled spring and a
/// ratchet). Tooth 0 points along +x, so a wheel rotated by theta shows a tooth at theta. Returns { ops } - a count of
/// construction steps. Refuses ({ ops: 0 }) a non-context, a non-finite or negative size, an unknown style or role, or a
/// wheel too small to have a web (or with a pitch radius over 1024).
/// @param {Struct} ctx an esc_cx_create context
/// @param {Struct} spec { n, module, style, metal, role }
/// @returns {Struct}
function esc_draw_gear(_c, _spec) {
    if (!esc__is_ctx(_c) || !is_struct(_spec)) return { ops: 0 };
    var _n = _spec[$ "n"], _mod = _spec[$ "module"], _style = _spec[$ "style"], _role = _spec[$ "role"];
    // the MZ: spec.module || 5, spec.style || 'spokes5'
    if (is_undefined(_mod) || (is_numeric(_mod) && _mod == 0)) _mod = 5;
    if (is_undefined(_style) || (is_string(_style) && _style == "")) _style = "spokes5";
    if (is_undefined(_role)) _role = "loose";
    if (!esc__dfin(_n, _mod) || _mod < 0) return { ops: 0 };
    if (!is_string(_role) || (_role != "loose" && _role != "drive" && _role != "output")) return { ops: 0 };
    if (!is_string(_style) || esc__index_of(esc_style_ids(), _style) < 0) return { ops: 0 };
    var _r = _n * _mod / 2, _rf = _r - 1.25 * _mod, _rim = _rf - max(4, _mod * 1.1), _hub = max(7, _r * 0.2);
    if (_n < 3 || _n > 400 || _r > 1024 || !(_rim > _hub + 1)) return { ops: 0 };
    var _e = esc__eps_in();
    var _o = esc__draw_gear(_c, _n, _mod, _style, _spec[$ "metal"], _role);
    math_set_epsilon(_e);
    return _o;
}

/// @function esc_tooth_path(ctx, n, module)
/// @description Trace a wheel's tooth outline as the context's current path (beginPath, nine points a tooth, closePath),
/// teeth centred on angles k * 2pi / n with tooth 0 along +x. Draws nothing: fill, stroke or clip it after. Refuses a
/// non-context, n outside 3..400, a module that is not positive, or a pitch radius over 1024.
/// @param {Struct} ctx an esc_cx_create context
/// @param {Real} n teeth
/// @param {Real} module tooth size (default 5)
function esc_tooth_path(_c, _n, _module = 5) {
    if (!esc__is_ctx(_c) || !esc__dfin(_n, _module) || _n < 3 || _n > 400 || _module <= 0 || _n * _module / 2 > 1024) return;
    var _e = esc__eps_in();
    esc__tooth_path(_c, _n, _module);
    math_set_epsilon(_e);
}

function esc__draw_shadow(_c, _x, _y, _R, _strength) {
    var _g = esc_cx_radial(_c, _x + 5, _y + 7, _R * 0.6, _x + 5, _y + 7, _R + 7);
    esc_cx_stop(_g, 0, [0, 0, 0], 0.45 * _strength);
    esc_cx_stop(_g, 1, [0, 0, 0], 0);
    _c.fill = _g;
    esc__p_begin(_c); esc__p_arc(_c, _x + 5, _y + 7, _R + 7, 0, ESC_TAU); esc__p_fill(_c);
}

/// @function esc_draw_shadow(ctx, x, y, R, strength)
/// @description The soft cast shadow of a wheel of radius R centred at (x, y), on the plate beneath it (offset down and
/// right; it does not turn). strength scales its darkness (1 = the MZ's). Refuses a non-context, a non-finite number or a
/// negative R.
/// @param {Struct} ctx an esc_cx_create context
function esc_draw_shadow(_c, _x, _y, _R, _strength = 1) {
    if (!esc__is_ctx(_c) || !esc__dfin(_x, _y, _R, _strength) || _R < 0 || _R > ESC_DRAW_MAX / 2) return;
    var _e = esc__eps_in();
    esc__draw_shadow(_c, _x, _y, _R, _strength);
    math_set_epsilon(_e);
}

function esc__draw_glint(_c, _R, _m) {
    var _g = esc_cx_radial(_c, -_R * 0.38, -_R * 0.42, 1, -_R * 0.2, -_R * 0.25, _R * 0.95);
    esc_cx_stop(_g, 0, _m.glint, _m.glintA);
    esc_cx_stop(_g, 1, [255, 255, 255], 0);
    _c.fill = _g;
    esc__p_begin(_c); esc__p_arc(_c, 0, 0, _R, 0, ESC_TAU); esc__p_fill(_c);
}

/// @function esc_draw_glint(ctx, R, metal)
/// @description The fixed glint over a wheel of radius R at the origin: light does not turn with the metal, so draw it
/// unrotated over a turning wheel. Refuses a non-context or a non-finite or negative R.
/// @param {Struct} ctx an esc_cx_create context
function esc_draw_glint(_c, _R, _metal = "brass") {
    if (!esc__is_ctx(_c) || !esc__dfin(_R) || _R < 0 || _R > ESC_DRAW_MAX / 2) return;
    var _e = esc__eps_in();
    esc__draw_glint(_c, _R, esc_metal(_metal));
    math_set_epsilon(_e);
}

// ---------------------------------------------------------------------------------------------------------------
// The bench and the plate
// ---------------------------------------------------------------------------------------------------------------

function esc__draw_bench(_c, _W, _H) {
    var _g = esc_cx_radial(_c, _W / 2, _H * 0.42, 60, _W / 2, _H / 2, _W * 0.75);
    esc_cx_stop(_g, 0, [58, 42, 34]); esc_cx_stop(_g, 0.6, [35, 24, 15]); esc_cx_stop(_g, 1, [11, 7, 5]);
    _c.fill = _g; esc__p_fill_rect(_c, 0, 0, _W, _H);
    // leather grain: 2,600 marks, logged one by one (the oracle's R) and drawn in one batch
    var _r = esc__rng($BEEF);
    var _lite = esc_cx_solid([255, 230, 200], 0.035), _dark = esc_cx_solid([0, 0, 0], 0.08);
    var _lg = esc__logging(_c), _pl = _lg ? esc__lg_paint(_lite) : "", _pd = _lg ? esc__lg_paint(_dark) : "", _tail = _lg ? ":" + esc__lg_t(_c) + esc__lg_a(_c) + ";" : "";
    var _list = array_create(2600);
    for (var _i = 0; _i < 2600; _i++) {
        var _isLite = (esc__rng_next(_r) < 0.5);
        var _x = esc__rng_next(_r) * _W;
        var _y = esc__rng_next(_r) * _H;
        var _w = 1 + esc__rng_next(_r) * 2;
        var _p = _isLite ? _lite : _dark;
        _c.fill = _p;
        if (_lg) esc__lg_emit(_c, "R" + (_isLite ? _pl : _pd) + ":" + string(esc__r100(_x + _y + _w + 1)) + _tail);
        _list[_i] = [_x, _y, _w, 1, _p.col, _p.a];
    }
    esc_cx_fill_rects(_c, _list);
    // saddle stitching round the edge
    _c.stroke = esc_cx_solid([214, 176, 120], 0.35); _c.lw = 1.2; esc_cx_set_dash(_c, [6, 5]);
    esc__q_stroke_rect(_c, 14.5, 14.5, _W - 29, _H - 29);
    esc_cx_set_dash(_c, []);
}

/// @function esc_draw_bench(ctx, W, H, metal)
/// @description The bench: a dark leather mat W x H from the origin, vignetted, with leather grain and saddle stitching
/// round the edge, so the plate sits on SOMETHING. The metal is accepted for the MZ's signature and not used. Refuses a
/// non-context or W, H not finite in 1..4096.
/// @param {Struct} ctx an esc_cx_create context
function esc_draw_bench(_c, _W, _H, _metal = "brass") {
    if (!esc__is_ctx(_c) || !esc__dfin(_W, _H) || _W <= 0 || _H <= 0 || _W > ESC_DRAW_MAX || _H > ESC_DRAW_MAX) return;
    var _e = esc__eps_in();
    esc__draw_bench(_c, _W, _H);
    math_set_epsilon(_e);
}

function esc__draw_plate(_c, _pz, _title) {
    var _pl = _pz.plate, _W = _pl.w, _H = _pl.h, _px = _pl.payoffX, _m = esc_metal(_pz[$ "metal"]);
    var _r = esc__rng(real((esc__u32(_pz.seed) ^ int64($51ED)) & int64($FFFFFFFF)));
    // drop shadow
    _c.fill = esc_cx_solid([0, 0, 0], 0.55);
    esc__rr(_c, 6, 9, _W, _H, 14); esc__p_fill(_c);
    // body
    var _g = esc_cx_linear(_c, 0, 0, _W, _H);
    esc_cx_stop(_g, 0, _m.plateHi); esc_cx_stop(_g, 0.5, _m.plateMid); esc_cx_stop(_g, 1, _m.plateLo);
    _c.fill = _g;
    esc__rr(_c, 0, 0, _W, _H, 14); esc__p_fill(_c);
    // brushed finish: long faint horizontal strokes
    esc__save(_c); esc__rr(_c, 0, 0, _W, _H, 14); esc__p_clip(_c, false);
    var _wh = esc_cx_solid([255, 255, 255], 0.05), _bk = esc_cx_solid([0, 0, 0], 0.05);
    for (var _i = 0; _i < 520; _i++) {
        var _y = esc__rng_next(_r) * _H;
        var _x = esc__rng_next(_r) * _W;
        var _len = 40 + esc__rng_next(_r) * 180;
        _c.stroke = (esc__rng_next(_r) < 0.5) ? _wh : _bk;
        _c.lw = 0.7;
        esc__p_begin(_c); esc__p_move(_c, _x, _y);
        var _dy = esc__rng_next(_r) - 0.5;
        esc__p_line(_c, _x + _len, _y + _dy); esc__q_stroke(_c);
    }
    // Geneva stripes across the train side: the watchmaker's decorated plate
    _c.alpha = 0.09;
    for (var _sx = -_H; _sx < _px; _sx += 22) {
        var _sg = esc_cx_linear(_c, _sx, 0, _sx + 22, 0);
        esc_cx_stop(_sg, 0, [0, 0, 0]); esc_cx_stop(_sg, 0.5, [255, 255, 255]); esc_cx_stop(_sg, 1, [0, 0, 0]);
        _c.fill = _sg;
        esc__p_begin(_c); esc__p_move(_c, _sx, 0); esc__p_line(_c, _sx + 22, 0); esc__p_line(_c, _sx + 22 + _H * 0.35, _H); esc__p_line(_c, _sx + _H * 0.35, _H); esc__p_close(_c); esc__p_fill(_c);
    }
    _c.alpha = 1;
    esc__restore(_c);
    // bevel
    _c.lw = 3;
    _c.stroke = esc_cx_solid([255, 255, 255], 0.45);
    esc__p_begin(_c); esc__p_move(_c, 4, _H - 14); esc__p_line(_c, 4, 14); esc__p_quad(_c, 4, 4, 14, 4); esc__p_line(_c, _W - 14, 4); esc__q_stroke(_c);
    _c.stroke = esc_cx_solid([0, 0, 0], 0.5);
    esc__p_begin(_c); esc__p_move(_c, _W - 4, 14); esc__p_line(_c, _W - 4, _H - 14); esc__p_quad(_c, _W - 4, _H - 4, _W - 14, _H - 4); esc__p_line(_c, 14, _H - 4); esc__q_stroke(_c);
    // engraved double border with a screw at each corner
    _c.stroke = esc_cx_solid(_m.cut); _c.lw = 1.2;
    esc__rr(_c, 14, 14, _W - 28, _H - 28, 8); esc__q_stroke(_c);
    _c.lw = 0.7;
    esc__rr(_c, 19, 19, _W - 38, _H - 38, 6); esc__q_stroke(_c);
    var _kx = [30, _W - 30, 30, _W - 30], _ky = [30, 30, _H - 30, _H - 30];
    for (var _k = 0; _k < 4; _k++) esc__screw(_c, _kx[_k], _ky[_k], 6.5, _m, 0.4 + _k * 1.1);
    // the payoff strip, ruled off
    _c.stroke = esc_cx_solid(_m.cut); _c.lw = 1.4;
    esc__p_begin(_c); esc__p_move(_c, _px, 26); esc__p_line(_c, _px, _H - 26); esc__q_stroke(_c);
    _c.stroke = esc_cx_solid([255, 255, 255], 0.3); _c.lw = 1;
    esc__p_begin(_c); esc__p_move(_c, _px + 1.5, 26); esc__p_line(_c, _px + 1.5, _H - 26); esc__q_stroke(_c);
    if (is_string(_title) && _title != "") esc__engrave(_c, _title, _px / 2, 22 + 12, 15, _m, "center", "italic");
}

/// @function esc_draw_plate(ctx, puzzle, [title])
/// @description The mechanism plate with its top-left at the context origin, in the puzzle's metal: drop shadow, bevel,
/// brushed finish (seeded by the puzzle), Geneva stripes across the train side, an engraved double border, corner screws,
/// the payoff strip ruled off at plate.payoffX, and the title (if a non-empty string) engraved over the train side.
/// Refuses a non-context, a puzzle without a sane plate { w, h, payoffX } and a numeric seed, or a title that is neither a
/// string nor undefined.
/// @param {Struct} ctx an esc_cx_create context
/// @param {Struct} puzzle what esc_generate returned
/// @param {String} title optional
function esc_draw_plate(_c, _pz, _title = undefined) {
    if (!esc__is_ctx(_c) || !esc__plate_ok(_pz)) return;
    if (!is_undefined(_title) && !is_string(_title)) return;
    var _e = esc__eps_in();
    esc__draw_plate(_c, _pz, _title);
    math_set_epsilon(_e);
}

function esc__draw_arbor(_c, _x, _y, _m) {
    _c.fill = esc_cx_solid([0, 0, 0], 0.28);
    esc__p_begin(_c); esc__p_arc(_c, _x + 1, _y + 1.5, 12, 0, ESC_TAU); esc__p_fill(_c);
    _c.stroke = esc_cx_solid(_m.cut); _c.lw = 1;
    esc__p_begin(_c); esc__p_arc(_c, _x, _y, 12, 0, ESC_TAU); esc__q_stroke(_c);
    esc__jewel(_c, _x, _y, 8);
    var _steel = esc_metal("steel");
    esc__screw(_c, _x - 14, _y - 7, 2.6, _steel, 0.3);
    esc__screw(_c, _x + 14, _y + 7, 2.6, _steel, 1.9);
}

/// @function esc_draw_arbor(ctx, x, y, metal)
/// @description An empty arbor at (x, y): a jewelled pivot in a sink ringed in the metal's cut colour, with two steel
/// chaton screws. Refuses a non-context or a non-finite position.
/// @param {Struct} ctx an esc_cx_create context
function esc_draw_arbor(_c, _x, _y, _metal = "brass") {
    if (!esc__is_ctx(_c) || !esc__dfin(_x, _y)) return;
    var _e = esc__eps_in();
    esc__draw_arbor(_c, _x, _y, esc_metal(_metal));
    math_set_epsilon(_e);
}

// ---------------------------------------------------------------------------------------------------------------
// Turn arrows and the side they are engraved on
// ---------------------------------------------------------------------------------------------------------------

function esc__draw_turn_arrow(_c, _x, _y, _R, _dir, _m, _label, _at) {
    esc__save(_c);
    _c.stroke = esc_cx_solid(_m.cut); _c.fill = esc_cx_solid(_m.cut); _c.lw = 2.2;
    var _a0 = _at - pi * 0.26, _a1 = _at + pi * 0.26;
    esc__p_begin(_c); esc__p_arc(_c, _x, _y, _R + 12, _a0, _a1); esc__q_stroke(_c);
    var _tip = (_dir > 0) ? _a1 : _a0;
    var _tx = _x + (_R + 12) * cos(_tip), _ty = _y + (_R + 12) * sin(_tip);
    var _tang = _tip + ((_dir > 0) ? pi / 2 : -pi / 2);
    esc__p_begin(_c);
    esc__p_move(_c, _tx + 7 * cos(_tang), _ty + 7 * sin(_tang));
    esc__p_line(_c, _tx + 5 * cos(_tang + 2.4), _ty + 5 * sin(_tang + 2.4));
    esc__p_line(_c, _tx + 5 * cos(_tang - 2.4), _ty + 5 * sin(_tang - 2.4));
    esc__p_close(_c); esc__p_fill(_c);
    if (is_string(_label) && _label != "") esc__engrave(_c, _label, _x + (_R + 30) * cos(_at), _y + (_R + 30) * sin(_at), 12, _m, "center", "italic");
    esc__restore(_c);
}

/// @function esc_draw_turn_arrow(ctx, x, y, R, dir, metal, [label], [at])
/// @description A curved arrow engraved in the plate round a wheel of radius R at (x, y), telling the player which way
/// it must turn (dir > 0 clockwise on screen, else counter-clockwise), centred on the side `at` (radians; default -0.6 pi,
/// the MZ's), with an optional italic label (a string) engraved beyond it. Refuses a non-context, a non-finite number, a
/// negative R, or a label that is neither a string nor undefined.
/// @param {Struct} ctx an esc_cx_create context
function esc_draw_turn_arrow(_c, _x, _y, _R, _dir, _metal = "brass", _label = undefined, _at = undefined) {
    if (is_undefined(_at)) _at = -pi * 0.6;
    if (!esc__is_ctx(_c) || !esc__dfin(_x, _y, _R, _dir, _at) || _R < 0 || _R > ESC_DRAW_MAX / 2) return;
    if (!is_undefined(_label) && !is_string(_label)) return;
    var _e = esc__eps_in();
    esc__draw_turn_arrow(_c, _x, _y, _R, _dir, esc_metal(_metal), _label, _at);
    math_set_epsilon(_e);
}

function esc__draw_turn_hint(_c, _R, _dir, _label, _at) {
    esc__save(_c);
    var _a0 = _at - pi * 0.26, _a1 = _at + pi * 0.26, _rr = _R + 12;
    var _tip = (_dir > 0) ? _a1 : _a0;
    var _tx = _rr * cos(_tip), _ty = _rr * sin(_tip);
    var _tang = _tip + ((_dir > 0) ? pi / 2 : -pi / 2);
    for (var _pass = 0; _pass < 2; _pass++) {
        _c.stroke = (_pass == 0) ? esc_cx_solid([20, 10, 4], 0.85) : esc_cx_solid([246, 230, 189]);
        _c.fill = _c.stroke;
        _c.lw = (_pass == 0) ? 5 : 2.2;
        esc__p_begin(_c); esc__p_arc(_c, 0, 0, _rr, _a0, _a1); esc__q_stroke(_c);
        var _s = (_pass == 0) ? 9.5 : 7;
        esc__p_begin(_c);
        esc__p_move(_c, _tx + _s * cos(_tang), _ty + _s * sin(_tang));
        esc__p_line(_c, _tx + (_s - 2) * cos(_tang + 2.4), _ty + (_s - 2) * sin(_tang + 2.4));
        esc__p_line(_c, _tx + (_s - 2) * cos(_tang - 2.4), _ty + (_s - 2) * sin(_tang - 2.4));
        esc__p_close(_c); esc__p_fill(_c);
    }
    if (is_string(_label) && _label != "") {
        var _lx = (_R + 32) * cos(_at), _ly = (_R + 32) * sin(_at);
        esc__font(_c, 13, 2); _c.ta = 1; _c.tb = 1;
        var _w = esc__measure(_c, _label) + 12;
        _c.fill = esc_cx_solid([20, 10, 4], 0.72); esc__rr(_c, _lx - _w / 2, _ly - 9, _w, 18, 8); esc__p_fill(_c);
        _c.fill = esc_cx_solid([246, 230, 189]); esc__q_text(_c, _label, _lx, _ly + 0.5);
    }
    esc__restore(_c);
}

/// @function esc_draw_turn_hint(ctx, R, dir, [label], at)
/// @description The same arrow as a HINT that sits above the wheels, centred on the origin (the output's arbor): cream on a
/// dark outline, so a wheel set beside the output can never hide which way it must turn; an optional label (a string) in a
/// dark lozenge beyond it. at (radians) is required. Refuses a non-context, a non-finite number (an undefined at included),
/// a negative R, or a label that is neither a string nor undefined.
/// @param {Struct} ctx an esc_cx_create context
function esc_draw_turn_hint(_c, _R, _dir, _label = undefined, _at = undefined) {
    if (!esc__is_ctx(_c) || !esc__dfin(_R, _dir, _at) || _R < 0 || _R > ESC_DRAW_MAX / 2) return;
    if (!is_undefined(_label) && !is_string(_label)) return;
    var _e = esc__eps_in();
    esc__draw_turn_hint(_c, _R, _dir, _label, _at);
    math_set_epsilon(_e);
}

function esc__clear_side(_pz, _cx, _cy, _R, _other, _maxLooseR, _xMax) {
    var _best = -pi / 2, _bestScore = -1000000000;
    var _arb = _pz.arbors, _na = array_length(_arb), _ph = _pz.plate.h;
    var _ox0 = _other.x, _oy0 = _other.y, _oR = _other.R;
    for (var _k = 0; _k < 16; _k++) {
        var _at = -pi + _k * ESC_TAU / 16;
        var _lx = _cx + (_R + 30) * cos(_at), _ly = _cy + (_R + 30) * sin(_at);
        var _score = 1000000000;
        for (var _i = 0; _i < _na; _i++) {
            var _ai = _arb[_i];
            var _dx = _lx - _ai.x, _dy = _ly - _ai.y;
            _score = min(_score, sqrt(_dx * _dx + _dy * _dy) - _maxLooseR - 10);
        }
        var _ox = _lx - _ox0, _oy = _ly - _oy0;
        _score = min(_score, sqrt(_ox * _ox + _oy * _oy) - _oR - 10);
        _score = min(_score, _lx - 40, (_xMax - 40) - _lx, _ly - 34, (_ph - 34) - _ly);
        if (esc__gt(_score, _bestScore)) { _bestScore = _score; _best = _at; }
    }
    return _best;
}

/// @function esc_clear_side(puzzle, cx, cy, R, other, maxLooseR, xMax)
/// @description Pick the side of a fixed wheel (radius R at cx, cy) to engrave its arrow on: of 16 directions, the one
/// whose label point (R + 30 out) lies farthest from every arbor (padded by maxLooseR, the biggest loose wheel), from the
/// other fixed wheel (other = { x, y, R }), and inside the plate (x in 40..xMax - 40, y in 34..plate.h - 34). Returns the
/// angle in radians; refuses (returns -pi / 2, the MZ's starting answer) a puzzle without arbors and a plate, an other
/// without x, y, R, or a non-finite number.
/// @returns {Real}
function esc_clear_side(_pz, _cx, _cy, _R, _other, _maxLooseR, _xMax) {
    if (!is_struct(_pz) || !is_struct(_other) || !esc__dfin(_cx, _cy, _R, _maxLooseR, _xMax)) return -pi / 2;
    if (!esc__dfin(_other[$ "x"], _other[$ "y"], _other[$ "R"])) return -pi / 2;
    var _pl = _pz[$ "plate"], _arb = _pz[$ "arbors"];
    if (!is_struct(_pl) || !esc__dfin(_pl[$ "h"]) || !is_array(_arb)) return -pi / 2;
    for (var _i = 0; _i < array_length(_arb); _i++) { var _ai = _arb[_i]; if (!is_struct(_ai) || !esc__dfin(_ai[$ "x"], _ai[$ "y"])) return -pi / 2; }
    var _e = esc__eps_in();
    var _v = esc__clear_side(_pz, _cx, _cy, _R, _other, _maxLooseR, _xMax);
    math_set_epsilon(_e);
    return _v;
}

// ---------------------------------------------------------------------------------------------------------------
// Payoffs: the thing the train is FOR. Each is a static base plus moving parts drawn separately, so the scene can move
// them without redrawing.
// ---------------------------------------------------------------------------------------------------------------

/// the anchors a refused esc_draw_payoff_base returns: the requested payoff's fields (all four payoffs' when the payoff is
/// unknown) at safe numbers - the default plate's, the output wheel level with the plate's middle
function esc__payoff_neutral(_payoff) {
    var _x0 = ESC_PAYOFF_X, _W = ESC_PLATE_W - _x0, _H = ESC_PLATE_H, _cx = _x0 + _W / 2, _oy = _H / 2;
    var _all = !is_string(_payoff) || esc__index_of(esc_payoff_ids(), _payoff) < 0;
    var _o = {};
    if (_all || _payoff == "lock") {
        var _sx = _x0 + 14, _sw = _W - 30;
        _o.bolt = { x: _sx, y: _oy, w: _sw, len: 64, left0: _sx - 26, travel: (_sw - 64 - 3) + 26 };
        _o.window = { x: _cx, y: _oy - 50 };
    }
    if (_all || _payoff == "clock") _o.dial = { x: _cx, y: _H / 2 + 6, R: min(_W / 2 - 8, 56) };
    if (_all || _payoff == "orrery") _o.orrery = { x: _cx, y: _H / 2 + 8, orbits: [19, 32, 46] };
    if (_all || _payoff == "winch") _o.winch = { x: _cx, y: 90, bottom: _H - 40 };
    return _o;
}

function esc__draw_payoff_base(_c, _pz) {
    var _metal = _pz[$ "metal"], _m = esc_metal(_metal), _a = esc_metal(esc_accent(_metal));
    var _pl = _pz.plate, _x0 = _pl.payoffX, _W = _pl.w - _x0, _H = _pl.h, _cx = _x0 + _W / 2;
    var _oy = _pz.output.y, _po = _pz.payoff;
    if (_po == "lock") {
        // a keeper housing the bolt slides in, riveted; a keyhole escutcheon above it and a window below that reads SHUT
        // or DRAWN (the window's words are a moving part)
        _c.fill = esc__face_grad(_c, 80, _a);
        esc__rr(_c, _x0 + 10, _oy - 30, _W - 22, 60, 6); esc__p_fill(_c);
        _c.stroke = esc_cx_solid(_a.edge); _c.lw = 1.2; esc__q_stroke(_c);
        for (var _i = 0; _i < 4; _i++) esc__screw(_c, _x0 + 22 + _i * ((_W - 46) / 3), _oy - 22, 2.8, _m, _i);
        for (var _j = 0; _j < 4; _j++) esc__screw(_c, _x0 + 22 + _j * ((_W - 46) / 3), _oy + 22, 2.8, _m, _j + 2);
        _c.fill = esc_cx_solid([0, 0, 0], 0.55);
        esc__rr(_c, _x0 + 14, _oy - 11, _W - 30, 22, 3); esc__p_fill(_c);
        // escutcheon: a shield-shaped plate with a pierced keyhole, placed where there is room. NAMED DEVIATION 1 (2026-10-10):
        // the MZ's oy - 108 laid the shield over the STRONGROOM label for outputs just below the middle (seen in the GIF
        // render); the shield is clamped to y >= 102. The oracle applies the same change.
        var _ey = (_oy > _H / 2) ? max(_oy - 108, 102) : _oy + 108;
        esc__save(_c); esc_cx_translate(_c, _cx, _ey);
        _c.fill = esc_cx_solid([0, 0, 0], 0.35);
        esc__p_begin(_c); esc__p_move(_c, 3, -38); esc__p_quad(_c, 35, -34, 33, 2); esc__p_quad(_c, 28, 30, 3, 44); esc__p_quad(_c, -24, 30, -27, 2); esc__p_quad(_c, -29, -34, 3, -38); esc__p_fill(_c);
        _c.fill = esc__face_grad(_c, 40, _a);
        esc__p_begin(_c); esc__p_move(_c, 0, -40); esc__p_quad(_c, 32, -36, 30, 0); esc__p_quad(_c, 26, 28, 0, 42); esc__p_quad(_c, -26, 28, -30, 0); esc__p_quad(_c, -32, -36, 0, -40); esc__p_fill(_c);
        _c.stroke = esc_cx_solid(_a.edge); _c.lw = 1.2; esc__q_stroke(_c);
        _c.stroke = esc_cx_solid(_a.cut); _c.lw = 0.8;
        esc__p_begin(_c); esc__p_move(_c, 0, -34); esc__p_quad(_c, 26, -30, 24, 0); esc__p_quad(_c, 21, 23, 0, 35); esc__p_quad(_c, -21, 23, -24, 0); esc__p_quad(_c, -26, -30, 0, -34); esc__q_stroke(_c);
        _c.fill = esc_cx_solid([12, 8, 6]);
        esc__p_begin(_c); esc__p_arc(_c, 0, -6, 8, 0, ESC_TAU); esc__p_fill(_c);
        esc__p_begin(_c); esc__p_move(_c, -5, -1); esc__p_line(_c, 5, -1); esc__p_line(_c, 7, 20); esc__p_line(_c, -7, 20); esc__p_close(_c); esc__p_fill(_c);
        esc__screw(_c, 0, -29, 3, _m, 0.2); esc__screw(_c, 0, 32, 3, _m, 1.2);
        esc__restore(_c);
        // the indicator window (deviation 1: below the output when above it would reach the STRONGROOM label, oy < 126)
        var _wy = (_oy > _H / 2 || _oy - 50 < 76) ? _oy + 50 : _oy - 50;
        _c.fill = esc__face_grad(_c, 30, _a); esc__rr(_c, _cx - 34, _wy - 13, 68, 26, 5); esc__p_fill(_c);
        _c.stroke = esc_cx_solid(_a.edge); _c.lw = 1; esc__q_stroke(_c);
        _c.fill = esc_cx_solid([18, 12, 8]); esc__rr(_c, _cx - 28, _wy - 8, 56, 16, 3); esc__p_fill(_c);
        esc__engrave(_c, "STRONGROOM", _cx, 52, 12, _m, "center", "bold");
        // the bolt: 64 long, poking 26 out of the keeper toward the pinion, withdrawing fully inside
        var _slotX = _x0 + 14, _slotW = _W - 30, _L = 64;
        return { bolt: { x: _slotX, y: _oy, w: _slotW, len: _L, left0: _slotX - 26, travel: (_slotW - _L - 3) + 26 }, window: { x: _cx, y: _wy } };
    }
    if (_po == "clock") {
        var _cy = _H / 2 + 6, _R = min(_W / 2 - 8, 56);
        // enamel dial, chapter ring, roman hours
        _c.fill = esc_cx_solid([0, 0, 0], 0.35); esc__p_begin(_c); esc__p_arc(_c, _cx + 3, _cy + 4, _R + 6, 0, ESC_TAU); esc__p_fill(_c);
        _c.fill = esc__face_grad(_c, _R + 6, _m); esc__p_begin(_c); esc__p_arc(_c, _cx, _cy, _R + 6, 0, ESC_TAU); esc__p_fill(_c);
        var _eg = esc_cx_radial(_c, _cx - _R * 0.3, _cy - _R * 0.3, 4, _cx, _cy, _R);
        esc_cx_stop(_eg, 0, [255, 253, 246]); esc_cx_stop(_eg, 1, [232, 223, 201]);
        _c.fill = _eg; esc__p_begin(_c); esc__p_arc(_c, _cx, _cy, _R, 0, ESC_TAU); esc__p_fill(_c);
        _c.stroke = esc_cx_solid([43, 33, 24]); _c.lw = 0.8;
        esc__p_begin(_c); esc__p_arc(_c, _cx, _cy, _R - 3, 0, ESC_TAU); esc__q_stroke(_c);
        esc__p_begin(_c); esc__p_arc(_c, _cx, _cy, _R - 14, 0, ESC_TAU); esc__q_stroke(_c);
        for (var _t = 0; _t < 60; _t++) {
            var _ta = _t * ESC_TAU / 60, _l = ((_t mod 5) == 0) ? 5 : 2.5;
            esc__p_begin(_c); esc__p_move(_c, _cx + (_R - 3) * cos(_ta), _cy + (_R - 3) * sin(_ta));
            esc__p_line(_c, _cx + (_R - 3 - _l) * cos(_ta), _cy + (_R - 3 - _l) * sin(_ta)); esc__q_stroke(_c);
        }
        var _RN = ["XII", "I", "II", "III", "IIII", "V", "VI", "VII", "VIII", "IX", "X", "XI"];
        _c.fill = esc_cx_solid([43, 33, 24]); esc__font(_c, 9, 1); _c.ta = 1; _c.tb = 1;
        for (var _h = 0; _h < 12; _h++) {
            var _ha = _h * ESC_TAU / 12 - pi / 2;
            esc__q_text(_c, _RN[_h], _cx + (_R - 21) * cos(_ha), _cy + (_R - 21) * sin(_ha));
        }
        esc__engrave(_c, "HOROLOGE", _cx, 52, 12, _m, "center", "bold");
        return { dial: { x: _cx, y: _cy, R: _R } };
    }
    if (_po == "orrery") {
        var _ocy = _H / 2 + 8;
        // a night-blue enamel sky inside a zodiac ring, so the planets read against something
        _c.fill = esc_cx_solid([0, 0, 0], 0.4); esc__p_begin(_c); esc__p_arc(_c, _cx + 3, _ocy + 4, 60, 0, ESC_TAU); esc__p_fill(_c);
        _c.fill = esc__face_grad(_c, 60, _a); esc__p_begin(_c); esc__p_arc(_c, _cx, _ocy, 60, 0, ESC_TAU); esc__p_fill(_c);
        _c.stroke = esc_cx_solid(_a.edge); _c.lw = 1; esc__q_stroke(_c);
        var _sky = esc_cx_radial(_c, _cx - 14, _ocy - 16, 4, _cx, _ocy, 54);
        esc_cx_stop(_sky, 0, [44, 63, 122]); esc_cx_stop(_sky, 1, [7, 11, 31]);
        _c.fill = _sky; esc__p_begin(_c); esc__p_arc(_c, _cx, _ocy, 53, 0, ESC_TAU); esc__p_fill(_c);
        var _sr = esc__rng(real((esc__u32(_pz.seed) ^ int64($5A5)) & int64($FFFFFFFF)));
        for (var _st = 0; _st < 46; _st++) {
            var _sa = esc__rng_next(_sr) * ESC_TAU;
            var _sd = 6 + esc__rng_next(_sr) * 45;
            _c.fill = esc_cx_solid([255, 248, 220], 0.35 + esc__rng_next(_sr) * 0.6);
            var _sw = (esc__rng_next(_sr) < 0.15) ? 2 : 1;
            esc__p_fill_rect(_c, _cx + _sd * cos(_sa), _ocy + _sd * sin(_sa), _sw, 1);
        }
        // zodiac ring ticks on the metal
        _c.stroke = esc_cx_solid(_a.cut); _c.lw = 1;
        for (var _zt = 0; _zt < 36; _zt++) {
            var _za = _zt * ESC_TAU / 36, _zl = ((_zt mod 3) == 0) ? 5 : 2.5;
            esc__p_begin(_c); esc__p_move(_c, _cx + (59 - _zl) * cos(_za), _ocy + (59 - _zl) * sin(_za)); esc__p_line(_c, _cx + 59 * cos(_za), _ocy + 59 * sin(_za)); esc__q_stroke(_c);
        }
        _c.stroke = esc_cx_solid([240, 210, 140], 0.55); _c.lw = 0.9;
        var _orbits = [19, 32, 46];
        for (var _ob = 0; _ob < 3; _ob++) { esc__p_begin(_c); esc__p_arc(_c, _cx, _ocy, _orbits[_ob], 0, ESC_TAU); esc__q_stroke(_c); }
        esc__engrave(_c, "ORRERY", _cx, 52, 12, _m, "center", "bold");
        return { orrery: { x: _cx, y: _ocy, orbits: _orbits } };
    }
    // winch: a drum with a chain dropping to a counterweight in a slotted guide
    var _dyw = 90;
    _c.fill = esc_cx_solid([0, 0, 0], 0.5); esc__rr(_c, _cx - 9, _dyw + 26, 18, _H - _dyw - 60, 4); esc__p_fill(_c);
    _c.stroke = esc_cx_solid(_m.cut); _c.lw = 1; esc__rr(_c, _cx - 12, _dyw + 23, 24, _H - _dyw - 54, 5); esc__q_stroke(_c);
    for (var _k2 = 0; _k2 < 6; _k2++) esc__engrave(_c, string(6 - _k2), _cx + 24, _dyw + 40 + _k2 * ((_H - _dyw - 90) / 5), 9, _m, "center", "");
    esc__engrave(_c, "WINCH", _cx, 52, 12, _m, "center", "bold");
    return { winch: { x: _cx, y: _dyw, bottom: _H - 40 } };
}

/// @function esc_draw_payoff_base(ctx, puzzle)
/// @description Draw the puzzle's payoff mechanism's static base into the strip right of plate.payoffX (context origin =
/// the plate's top-left) and return the anchor points its moving parts use: lock { bolt { x, y, w, len, left0, travel },
/// window { x, y } } · clock { dial { x, y, R } } · orrery { orrery { x, y, orbits [3] } } · winch { winch { x, y, bottom } }.
/// The lock and the orrery are cut in the metal's accent alloy. Refuses (draws nothing) a non-context, a puzzle without a
/// sane plate (a payoff strip at least 40 wide), an output { y } or a known payoff; the refusal returns the requested
/// payoff's anchors (every payoff's, when the payoff is unknown) at safe numbers, so a caller's reads never crash.
/// @returns {Struct}
function esc_draw_payoff_base(_c, _pz) {
    var _po = is_struct(_pz) ? _pz[$ "payoff"] : undefined;
    if (!esc__is_ctx(_c) || !esc__plate_ok(_pz) || !is_string(_po) || esc__index_of(esc_payoff_ids(), _po) < 0) return esc__payoff_neutral(_po);
    var _out = _pz[$ "output"];
    if (!is_struct(_out) || !esc__dfin(_out[$ "y"]) || _pz.plate.w - _pz.plate.payoffX < 40) return esc__payoff_neutral(_po);
    var _e = esc__eps_in();
    var _o = esc__draw_payoff_base(_c, _pz);
    math_set_epsilon(_e);
    return _o;
}

function esc__draw_bolt(_c, _w, _m) {
    _c.fill = esc__face_grad(_c, _w, _m);
    esc__rr(_c, 0, -8, _w, 16, 3); esc__p_fill(_c);
    _c.stroke = esc_cx_solid(_m.edge); _c.lw = 1; esc__q_stroke(_c);
    _c.fill = esc_cx_solid(_m.cut);
    for (var _i = 8; _i < _w - 6; _i += 6) esc__p_fill_rect(_c, _i, 5, 3, 3); // the rack the pinion drives
    _c.fill = esc_cx_solid([255, 255, 255], 0.35); esc__p_fill_rect(_c, 3, -6, _w - 6, 2);
}

/// @function esc_draw_bolt(ctx, w, metal)
/// @description The lock's bolt, w long, drawn from the origin along +x (it withdraws to the right), with the rack its
/// pinion drives. Refuses a non-context or w not finite in 0..4096.
/// @param {Struct} ctx an esc_cx_create context
function esc_draw_bolt(_c, _w, _metal = "brass") {
    if (!esc__is_ctx(_c) || !esc__dfin(_w) || _w < 0 || _w > ESC_DRAW_MAX) return;
    var _e = esc__eps_in();
    esc__draw_bolt(_c, _w, esc_metal(_metal));
    math_set_epsilon(_e);
}

function esc__draw_hand(_c, _len, _width, _m, _counter) {
    _c.fill = esc_cx_solid(_m.edge);
    esc__p_begin(_c);
    esc__p_move(_c, -_width, 0); esc__p_line(_c, -_width * 0.45, -_len * 0.7);
    esc__p_line(_c, 0, -_len); esc__p_line(_c, _width * 0.45, -_len * 0.7); esc__p_line(_c, _width, 0);
    esc__p_line(_c, _width * 0.5, _counter); esc__p_line(_c, -_width * 0.5, _counter); esc__p_close(_c); esc__p_fill(_c);
    esc__p_begin(_c); esc__p_arc(_c, 0, -_len * 0.62, _width * 0.9, 0, ESC_TAU); _c.fill = esc_cx_solid([255, 253, 246]); esc__p_fill(_c);
    _c.fill = esc_cx_solid(_m.edge); esc__p_begin(_c); esc__p_arc(_c, 0, 0, _width * 1.3, 0, ESC_TAU); esc__p_fill(_c);
}

/// @function esc_draw_hand(ctx, len, width, metal, counter)
/// @description A clock hand at the origin pointing up (-y): len to the tip, width at the arbor, a counterweight tail
/// `counter` below, a lume dot and the boss. Refuses a non-context, a non-finite number or a negative width.
/// @param {Struct} ctx an esc_cx_create context
function esc_draw_hand(_c, _len, _width, _metal, _counter) {
    if (!esc__is_ctx(_c) || !esc__dfin(_len, _width, _counter) || _width < 0 || _width > ESC_DRAW_MAX / 2 || abs(_len) > ESC_DRAW_MAX || abs(_counter) > ESC_DRAW_MAX) return;
    var _e = esc__eps_in();
    esc__draw_hand(_c, _len, _width, esc_metal(_metal), _counter);
    math_set_epsilon(_e);
}

function esc__draw_planet_arm(_c, _len, _pr, _rgb, _m) {
    _c.stroke = esc_cx_solid(_m.mid); _c.lw = 2;
    esc__p_begin(_c); esc__p_move(_c, 0, 0); esc__p_line(_c, _len, 0); esc__q_stroke(_c);
    var _g = esc_cx_radial(_c, _len - _pr * 0.35, -_pr * 0.35, 0.5, _len, 0, _pr);
    esc_cx_stop(_g, 0, [255, 255, 255]); esc_cx_stop(_g, 0.3, _rgb); esc_cx_stop(_g, 1, [11, 11, 20]);
    _c.fill = _g; esc__p_begin(_c); esc__p_arc(_c, _len, 0, _pr, 0, ESC_TAU); esc__p_fill(_c);
}

/// @function esc_draw_planet_arm(ctx, len, pr, rgb, metal)
/// @description An orrery planet of radius pr on an arm len long, drawn along +x from the origin; rgb = [r, g, b], the
/// planet's colour. Refuses a non-context, a non-finite number, a negative pr or an rgb that is not an array of three.
/// @param {Struct} ctx an esc_cx_create context
function esc_draw_planet_arm(_c, _len, _pr, _rgb, _metal = "brass") {
    if (!esc__is_ctx(_c) || !esc__dfin(_len, _pr) || _pr < 0 || _pr > ESC_DRAW_MAX / 2 || abs(_len) > ESC_DRAW_MAX) return;
    if (!is_array(_rgb) || array_length(_rgb) < 3 || !esc__dfin(_rgb[0], _rgb[1], _rgb[2])) return;
    var _e = esc__eps_in();
    esc__draw_planet_arm(_c, _len, _pr, _rgb, esc_metal(_metal));
    math_set_epsilon(_e);
}

function esc__draw_sun(_c, _r) {
    var _g = esc_cx_radial(_c, -_r * 0.3, -_r * 0.3, 0.5, 0, 0, _r);
    esc_cx_stop(_g, 0, [255, 251, 224]); esc_cx_stop(_g, 0.4, [255, 197, 61]); esc_cx_stop(_g, 1, [164, 84, 10]);
    _c.fill = _g; esc__p_begin(_c); esc__p_arc(_c, 0, 0, _r, 0, ESC_TAU); esc__p_fill(_c);
    _c.stroke = esc_cx_solid([255, 200, 80], 0.6); _c.lw = 1.2;
    for (var _i = 0; _i < 12; _i++) {
        var _a = _i * ESC_TAU / 12;
        esc__p_begin(_c); esc__p_move(_c, (_r + 2) * cos(_a), (_r + 2) * sin(_a)); esc__p_line(_c, (_r + 6) * cos(_a), (_r + 6) * sin(_a)); esc__q_stroke(_c);
    }
}

/// @function esc_draw_sun(ctx, r)
/// @description The orrery's sun, radius r at the origin, with twelve short rays. Refuses a non-context or a non-finite or
/// negative r.
/// @param {Struct} ctx an esc_cx_create context
function esc_draw_sun(_c, _r) {
    if (!esc__is_ctx(_c) || !esc__dfin(_r) || _r < 0 || _r > ESC_DRAW_MAX / 2) return;
    var _e = esc__eps_in();
    esc__draw_sun(_c, _r);
    math_set_epsilon(_e);
}

function esc__draw_drum(_c, _r, _m) {
    _c.fill = esc__face_grad(_c, _r, _m); esc__p_begin(_c); esc__p_arc(_c, 0, 0, _r, 0, ESC_TAU); esc__p_fill(_c);
    _c.stroke = esc_cx_solid(_m.edge); _c.lw = 1.2; esc__q_stroke(_c);
    for (var _i = 0; _i < 8; _i++) {
        var _a = _i * ESC_TAU / 8;
        esc__p_begin(_c); esc__p_move(_c, 4 * cos(_a), 4 * sin(_a)); esc__p_line(_c, (_r - 3) * cos(_a), (_r - 3) * sin(_a)); esc__q_stroke(_c);
    }
    _c.fill = esc_cx_solid(_m.cut); esc__p_begin(_c); esc__p_arc(_c, 0, 0, 4, 0, ESC_TAU); esc__p_fill(_c);
}

/// @function esc_draw_drum(ctx, r, metal)
/// @description The winch drum (it turns), radius r at the origin, with eight spokes. Refuses a non-context or a non-finite
/// or negative r.
/// @param {Struct} ctx an esc_cx_create context
function esc_draw_drum(_c, _r, _metal = "brass") {
    if (!esc__is_ctx(_c) || !esc__dfin(_r) || _r < 0 || _r > ESC_DRAW_MAX / 2) return;
    var _e = esc__eps_in();
    esc__draw_drum(_c, _r, esc_metal(_metal));
    math_set_epsilon(_e);
}

function esc__draw_weight(_c, _m) {
    _c.fill = esc__face_grad(_c, 18, _m);
    esc__p_begin(_c); esc__p_move(_c, -11, 6); esc__p_line(_c, 11, 6); esc__p_line(_c, 9, 30); esc__p_line(_c, -9, 30); esc__p_close(_c); esc__p_fill(_c);
    _c.stroke = esc_cx_solid(_m.edge); _c.lw = 1; esc__q_stroke(_c);
    esc__p_begin(_c); esc__p_arc(_c, 0, 3, 3.5, 0, ESC_TAU); esc__q_stroke(_c);
}

/// @function esc_draw_weight(ctx, metal)
/// @description The winch's counterweight, hanging from its ring at the origin (the body runs from y 6 to y 30). Refuses a
/// non-context.
/// @param {Struct} ctx an esc_cx_create context
function esc_draw_weight(_c, _metal = "brass") {
    if (!esc__is_ctx(_c)) return;
    var _e = esc__eps_in();
    esc__draw_weight(_c, esc_metal(_metal));
    math_set_epsilon(_e);
}

// ---------------------------------------------------------------------------------------------------------------
// The tray, the cursor and the words
// ---------------------------------------------------------------------------------------------------------------

function esc__draw_tray(_c, _W, _H, _count) {
    _c.fill = esc_cx_solid([0, 0, 0], 0.5); esc__rr(_c, 4, 6, _W, _H, 10); esc__p_fill(_c);
    var _wood = esc_cx_linear(_c, 0, 0, 0, _H);
    esc_cx_stop(_wood, 0, [107, 66, 38]); esc_cx_stop(_wood, 1, [58, 34, 19]);
    _c.fill = _wood; esc__rr(_c, 0, 0, _W, _H, 10); esc__p_fill(_c);
    var _r = esc__rng(77);
    for (var _i = 0; _i < 60; _i++) {
        _c.stroke = esc_cx_solid([0, 0, 0], 0.05 + esc__rng_next(_r) * 0.08); _c.lw = 1;
        var _y = esc__rng_next(_r) * _H;
        esc__p_begin(_c); esc__p_move(_c, 0, _y);
        var _ey = (esc__rng_next(_r) - 0.5) * 4;
        esc__p_bez(_c, _W * 0.3, _y + 3, _W * 0.6, _y - 3, _W, _y + _ey); esc__q_stroke(_c);
    }
    var _vel = esc_cx_linear(_c, 0, 8, 0, _H - 8);
    esc_cx_stop(_vel, 0, [61, 15, 29]); esc_cx_stop(_vel, 1, [31, 6, 16]);
    _c.fill = _vel; esc__rr(_c, 8, 8, _W - 16, _H - 16, 6); esc__p_fill(_c);
    var _slot = (_W - 16) / max(1, _count);
    for (var _s = 0; _s < _count; _s++) {
        var _sx = 8 + _slot * (_s + 0.5);
        _c.fill = esc_cx_solid([0, 0, 0], 0.35);
        esc__p_begin(_c); esc__p_arc(_c, _sx, _H / 2, min(_slot, _H - 16) * 0.44, 0, ESC_TAU); esc__p_fill(_c);
    }
    return { slot: _slot };
}

/// @function esc_draw_tray(ctx, W, H, count, metal)
/// @description The drawer of loose wheels, W x H from the origin: a wooden tray with a velvet lining and one socket per
/// wheel. Returns { slot } - the width of one wheel's place (socket s is centred at x = 8 + slot * (s + 0.5), y = H / 2).
/// The metal is accepted for the MZ's signature and not used. Refuses ({ slot: 0 }) a non-context, W or H not finite in
/// 16..4096, or a count not finite in 0..256.
/// @returns {Struct}
function esc_draw_tray(_c, _W, _H, _count, _metal = "brass") {
    if (!esc__is_ctx(_c) || !esc__dfin(_W, _H, _count) || _W < 16 || _H < 16 || _W > ESC_DRAW_MAX || _H > ESC_DRAW_MAX || _count < 0 || _count > 256) return { slot: 0 };
    var _e = esc__eps_in();
    var _o = esc__draw_tray(_c, _W, _H, _count);
    math_set_epsilon(_e);
    return _o;
}

/// @function esc_draw_window_word(ctx, word, good)
/// @description The word in the lock's indicator window (SHUT or DRAWN), centred at the origin, green when good else red.
/// Refuses a non-context or a word that is not a string.
/// @param {Struct} ctx an esc_cx_create context
function esc_draw_window_word(_c, _word, _good = false) {
    if (!esc__is_ctx(_c) || !is_string(_word)) return;
    var _ok = false;
    if (is_bool(_good)) _ok = _good; else if (is_numeric(_good) && !is_nan(_good)) _ok = (_good != 0);
    var _e = esc__eps_in();
    esc__font(_c, 12, 0); _c.ta = 1; _c.tb = 1;
    _c.fill = _ok ? esc_cx_solid([159, 224, 122]) : esc_cx_solid([232, 96, 74]);
    esc__q_text(_c, _word, 0, 1);
    math_set_epsilon(_e);
}

/// @function esc_draw_warning(ctx, R)
/// @description A red warning halo of radius R at the origin: drawn where the pawl holds or where a loop jams. Refuses a
/// non-context or a non-finite or negative R.
/// @param {Struct} ctx an esc_cx_create context
function esc_draw_warning(_c, _R) {
    if (!esc__is_ctx(_c) || !esc__dfin(_R) || _R < 0 || _R > ESC_DRAW_MAX / 2) return;
    var _e = esc__eps_in();
    var _g = esc_cx_radial(_c, 0, 0, _R * 0.6, 0, 0, _R);
    esc_cx_stop(_g, 0, [255, 70, 40], 0); esc_cx_stop(_g, 0.75, [255, 70, 40], 0.55); esc_cx_stop(_g, 1, [255, 70, 40], 0);
    _c.fill = _g; esc__p_begin(_c); esc__p_arc(_c, 0, 0, _R, 0, ESC_TAU); esc__p_fill(_c);
    math_set_epsilon(_e);
}

/// @function esc_draw_cursor(ctx, R)
/// @description The selector: a loupe ring of radius R at the origin with four ticks. Refuses a non-context or a non-finite
/// or negative R.
/// @param {Struct} ctx an esc_cx_create context
function esc_draw_cursor(_c, _R) {
    if (!esc__is_ctx(_c) || !esc__dfin(_R) || _R < 0 || _R > ESC_DRAW_MAX / 2) return;
    var _e = esc__eps_in();
    esc__save(_c);
    _c.stroke = esc_cx_solid([255, 236, 170], 0.95); _c.lw = 2.5;
    esc__p_begin(_c); esc__p_arc(_c, 0, 0, _R, 0, ESC_TAU); esc__q_stroke(_c);
    _c.stroke = esc_cx_solid([40, 20, 0], 0.8); _c.lw = 1;
    esc__p_begin(_c); esc__p_arc(_c, 0, 0, _R + 2.2, 0, ESC_TAU); esc__q_stroke(_c);
    _c.stroke = esc_cx_solid([255, 236, 170], 0.95); _c.lw = 2.5;
    for (var _i = 0; _i < 4; _i++) {
        var _a = _i * ESC_TAU / 4 + pi / 4;
        esc__p_begin(_c); esc__p_move(_c, (_R + 3) * cos(_a), (_R + 3) * sin(_a)); esc__p_line(_c, (_R + 10) * cos(_a), (_R + 10) * sin(_a)); esc__q_stroke(_c);
    }
    esc__restore(_c);
    math_set_epsilon(_e);
}

/// @function esc_draw_status(ctx, W, text, [tone])
/// @description A line of status text centred in a band W wide and 40 tall from the origin (the band is CLEARED first, as
/// the MZ's clearRect does), italic, with a dark drop: tone "bad" (red), "good" (green) or anything else (cream). Refuses a
/// non-context, W not finite in 1..4096, or a text that is not a string.
/// @param {Struct} ctx an esc_cx_create context
function esc_draw_status(_c, _W, _text, _tone = "") {
    if (!esc__is_ctx(_c) || !esc__dfin(_W) || _W <= 0 || _W > ESC_DRAW_MAX || !is_string(_text)) return;
    if (!is_string(_tone)) _tone = "";
    var _e = esc__eps_in();
    esc_cx_clear_rect(_c, 0, 0, _W, 40);
    esc__font(_c, 17, 2); _c.ta = 1; _c.tb = 1;
    _c.fill = esc_cx_solid([0, 0, 0], 0.6); esc__q_text(_c, _text, _W / 2 + 1, 21);
    _c.fill = (_tone == "bad") ? esc_cx_solid([255, 156, 134]) : ((_tone == "good") ? esc_cx_solid([200, 245, 166]) : esc_cx_solid([241, 223, 180]));
    esc__q_text(_c, _text, _W / 2, 20);
    math_set_epsilon(_e);
}

/// @function esc_draw_heading(ctx, W, title, grade)
/// @description The heading above the plate in a band W wide and 56 tall from the origin (CLEARED first): the puzzle's
/// title in a warm gold over a dark drop, and below it "grade <roman>" with the controls, in italic. grade is 0..5 (0
/// prints no numeral, as the MZ). Refuses a non-context, W not finite in 1..4096, a title that is not a string or a grade
/// that is not a whole number 0..5.
/// @param {Struct} ctx an esc_cx_create context
function esc_draw_heading(_c, _W, _title, _grade) {
    if (!esc__is_ctx(_c) || !esc__dfin(_W, _grade) || _W <= 0 || _W > ESC_DRAW_MAX || !is_string(_title)) return;
    if (_grade != floor(_grade) || _grade < 0 || _grade > 5) return;
    var _e = esc__eps_in();
    esc_cx_clear_rect(_c, 0, 0, _W, 56);
    esc__font(_c, 30, 1); _c.ta = 1; _c.tb = 1;
    _c.fill = esc_cx_solid([0, 0, 0], 0.6); esc__q_text(_c, _title, _W / 2 + 1, 25);
    var _g = esc_cx_linear(_c, 0, 8, 0, 42);
    esc_cx_stop(_g, 0, [255, 241, 196]); esc_cx_stop(_g, 1, [201, 149, 61]);
    _c.fill = _g; esc__q_text(_c, _title, _W / 2, 24);
    var _RO = ["", "I", "II", "III", "IV", "V"], _sep = "   " + chr(183) + "   ";
    esc__font(_c, 13, 2); _c.fill = esc_cx_solid([184, 154, 102]);
    esc__q_text(_c, "grade " + _RO[_grade] + _sep + "arrows choose an arbor" + _sep + "OK places or lifts a wheel" + _sep + "Esc leaves", _W / 2, 48);
    math_set_epsilon(_e);
}

/// @function esc_engrave(ctx, text, x, y, size, metal, [align], [weight])
/// @description Set text engraved into metal: the metal's cut colour with a light lip one pixel below, its MIDDLE at y.
/// align "center" (default), "left" (or "start") or "right"; weight "bold" (Escapement Display), "italic" (the Body face
/// struck oblique) or "" (Escapement Body). Refuses a non-context, a text that is not a string, a non-finite number, a size
/// not in (0, 512], or an align or weight it does not know.
/// @param {Struct} ctx an esc_cx_create context
function esc_engrave(_c, _text, _x, _y, _size, _metal = "brass", _align = "center", _weight = "") {
    if (!esc__is_ctx(_c) || !is_string(_text) || !esc__dfin(_x, _y, _size) || _size <= 0 || _size > 512) return;
    if (!is_undefined(_align) && !is_string(_align)) return;
    if (is_string(_align) && _align != "" && _align != "center" && _align != "left" && _align != "start" && _align != "right") return;
    if (!is_undefined(_weight) && !is_string(_weight)) return;
    var _e = esc__eps_in();
    esc__engrave(_c, _text, _x, _y, _size, esc_metal(_metal), _align, _weight);
    math_set_epsilon(_e);
}

/// @function esc_jewel(ctx, x, y, s)
/// @description A jewel bearing at (x, y): a ruby in a gold chaton of radius s, with its pivot hole and a highlight - what
/// an arbor pivots in. Refuses a non-context, a non-finite number or a negative s.
/// @param {Struct} ctx an esc_cx_create context
function esc_jewel(_c, _x, _y, _s) {
    if (!esc__is_ctx(_c) || !esc__dfin(_x, _y, _s) || _s < 0 || _s > ESC_DRAW_MAX / 2) return;
    var _e = esc__eps_in();
    esc__jewel(_c, _x, _y, _s);
    math_set_epsilon(_e);
}
