{
  "$GMScript": "v1",
  "%Name": "esc_paint",
  "name": "esc_paint",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}