/// esc_demo.gml - THE CLOCKMAKER'S BENCH, Escapement's demo room: four mechanisms (the strongroom lock, the tower clock,
/// the orrery, the portcullis winch) at five grades. Choose one and finish its train. A solved mechanism is stamped; a
/// train you walk away from is remembered and laid out again next time, as a game's save would keep it.
///
/// Escapement - Generated Clockwork Gear Puzzles, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// Four calls, the same shape as the puzzle's own (obj_esc_demo shows them):
///   Create: demo = esc_demo_create();   Step: esc_demo_step(demo);   Draw GUI: esc_demo_draw(demo);   Clean Up: esc_demo_free(demo);
/// Public functions (each documented below): esc_demo_create, esc_demo_step, esc_demo_draw, esc_demo_free, esc_demo_cards.

#macro ESC_DEMO_CARD_W 180
#macro ESC_DEMO_CARD_H 330
#macro ESC_DEMO_CARD_Y 126
#macro ESC_DEMO_GRADE_Y 492

/// @function esc_demo_cards()
/// @description The demo's four mechanisms: [{ payoff, metal, title }] - each card always opens the same puzzle at a grade
/// (seed "bench-<payoff>-<grade>"). Pure.
/// @returns {Array<Struct>}
function esc_demo_cards() {
    return [{ payoff: "lock", metal: "brass", title: "The Strongroom Lock" }, { payoff: "clock", metal: "gunmetal", title: "The Tower Clock" },
        { payoff: "orrery", metal: "verdigris", title: "The Orrery" }, { payoff: "winch", metal: "steel", title: "The Portcullis Winch" }];
}
function esc__demo_card_x(_i) { return 30 + _i * (ESC_DEMO_CARD_W + 12); }
/// the left edge of grade button g's 52-px box on the bench (the centres sit at x + 26, y ESC_DEMO_GRADE_Y + 8)
function esc__demo_grade_x(_g) { return 254 + (_g - 1) * 64; }
function esc__roman(_g) { switch (_g) { case 1: return "I"; case 2: return "II"; case 3: return "III"; case 4: return "IV"; case 5: return "V"; } return ""; }

/// internal: one line of type at a baseline (align 0 left, 1 centre), solid colour - for the demo's own words
function esc__demo_text(_c, _s, _x, _y, _px, _face, _rgb, _a, _align) {
    var _t = string(_s), _w = esc_text_width(_t, _px, _face), _x0 = (_align == 1) ? _x - _w / 2 : _x;
    var _adv = esc_text_advance(_face), _pen = _x0, _keep = _c.fill;
    _c.fill = esc_cx_solid(_rgb, _a);
    for (var _i = 1; _i <= string_length(_t); _i++) { var _ch = string_char_at(_t, _i), _o = ord(_ch); if (_o > 32 && _o <= 126) esc_cx_glyph(_c, _ch, _pen, _y, _px, _face); if (_o >= 32 && _o <= 126) _pen += _adv[_o - 32] * _px; }
    _c.fill = _keep;
}
function esc__demo_rr(_c, _x, _y, _w, _h, _r) {
    esc_cx_begin(_c); esc_cx_move(_c, _x + _r, _y); esc_cx_line(_c, _x + _w - _r, _y); esc_cx_quad(_c, _x + _w, _y, _x + _w, _y + _r); esc_cx_line(_c, _x + _w, _y + _h - _r);
    esc_cx_quad(_c, _x + _w, _y + _h, _x + _w - _r, _y + _h); esc_cx_line(_c, _x + _r, _y + _h); esc_cx_quad(_c, _x, _y + _h, _x, _y + _h - _r);
    esc_cx_line(_c, _x, _y + _r); esc_cx_quad(_c, _x, _y, _x + _r, _y); esc_cx_close(_c);
}

// painters
function esc__pnt_demo_bg(_c, _a) {
    esc_draw_bench(_c, ESC_SCENE_W, ESC_SCENE_H, "brass");
    // the room's name, set like the plate's heading: a dark drop and a warm face
    esc__demo_text(_c, "Escapement", ESC_SCENE_W / 2 + 1, 66, 46, ESC_FACE_DISPLAY, [0, 0, 0], 0.6, 1);
    esc__demo_text(_c, "Escapement", ESC_SCENE_W / 2, 65, 46, ESC_FACE_DISPLAY, [244, 221, 151], 1, 1);
    esc__demo_text(_c, "The Clockmaker's Bench: four mechanisms, five grades, every train generated from a seed", ESC_SCENE_W / 2, 96, 15, ESC_FACE_BODY, [184, 154, 102], 1, 1);
    esc__demo_text(_c, "GRADE", esc__demo_grade_x(1) - 70, ESC_DEMO_GRADE_Y + 13, 14, ESC_FACE_DISPLAY, [184, 154, 102], 1, 1);
    esc__demo_text(_c, "A lit jewel on a card is a grade you have solved; a train you leave half-set is kept for next time.", ESC_SCENE_W / 2, 562, 13, ESC_FACE_BODY, [184, 154, 102], 1, 1);
    esc__demo_text(_c, "Arrows choose a mechanism and a grade, Enter opens it. Or click. Inside: arrows and Enter set wheels, Esc leaves.", ESC_SCENE_W / 2, 600, 13, ESC_FACE_BODY, [150, 128, 92], 1, 1);
}
function esc__pnt_demo_card(_c, _a) {
    var _card = _a.card, _m = esc_metal(_card.metal), _W = ESC_DEMO_CARD_W, _H = ESC_DEMO_CARD_H;
    // the card is a small mechanism plate in its own metal
    _c.fill = esc_cx_solid([0, 0, 0], 0.5); esc__demo_rr(_c, 5, 8, _W, _H, 12); esc_cx_fill(_c);
    var _g = esc_cx_linear(_c, 0, 0, _W, _H); esc_cx_stop(_g, 0, _m.plateHi); esc_cx_stop(_g, 0.5, _m.plateMid); esc_cx_stop(_g, 1, _m.plateLo);
    _c.fill = _g; esc__demo_rr(_c, 0, 0, _W, _H, 12); esc_cx_fill(_c);
    _c.stroke = esc_cx_solid(_m.cut, 1); _c.lw = 1.2; esc__demo_rr(_c, 9, 9, _W - 18, _H - 18, 7); esc_cx_stroke(_c);
    // the payoff's wheel, large: the output wheel this mechanism ends in, with a mainspring barrel behind it
    esc_cx_save(_c); esc_cx_translate(_c, _W * 0.36, 122); esc_cx_scale(_c, 0.62, 0.62);
    esc_draw_gear(_c, { n: 24, module: ESC_MODULE, style: "disc", metal: _card.metal, role: "drive" }); esc_cx_restore(_c);
    var _styles = ["spokes5", "holes", "curved", "spokes6"];
    esc_cx_save(_c); esc_cx_translate(_c, _W * 0.36 + 0.62 * (esc_pitch_r(24) + esc_pitch_r(16)) * cos(-0.5), 122 + 0.62 * (esc_pitch_r(24) + esc_pitch_r(16)) * sin(-0.5)); esc_cx_scale(_c, 0.62, 0.62); esc_cx_rotate(_c, 0.17);
    esc_draw_gear(_c, { n: 16, module: ESC_MODULE, style: _styles[_a.i mod 4], metal: _card.metal, role: "loose" }); esc_cx_restore(_c);
    // the words sit in a dark inset so they read on every metal (engraved straight onto gunmetal and steel they did not -
    // found by looking at the first render, 2026-10-10)
    _c.fill = esc_cx_solid([0, 0, 0], 0.42); esc__demo_rr(_c, 16, 206, _W - 32, 88, 8); esc_cx_fill(_c);
    _c.stroke = esc_cx_solid([255, 236, 170], 0.35); _c.lw = 1; esc__demo_rr(_c, 16.5, 206.5, _W - 33, 87, 8); esc_cx_stroke(_c);
    esc__demo_text(_c, string_upper(_card.payoff == "lock" ? "strongroom" : (_card.payoff == "clock" ? "horologe" : _card.payoff)), _W / 2, 232, 14, ESC_FACE_DISPLAY, [244, 221, 151], 1, 1);
    esc__demo_text(_c, _card.title, _W / 2, 258, 15, ESC_FACE_BODY, [241, 226, 192], 1, 1);
    esc__demo_text(_c, esc_goal(_card.payoff), _W / 2, 281, 13, ESC_FACE_BODY, [190, 168, 128], 1, 1);
    // solved at which grades: five small jewels, lit for each grade solved
    for (var _q = 1; _q <= 5; _q++) {
        var _jx = _W / 2 + (_q - 3) * 22, _on = _a.solved[_q - 1];
        if (_on) esc_jewel(_c, _jx, 308, 6);
        else { _c.fill = esc_cx_solid([0, 0, 0], 0.3); esc_cx_begin(_c); esc_cx_arc(_c, _jx, 308, 5, 0, 2 * pi); esc_cx_fill(_c); _c.stroke = esc_cx_solid(_m.cut, 1); _c.lw = 1; esc_cx_stroke(_c); }
    }
}
/// the wait card: opening a puzzle draws every wheel once (seconds - see the Readme's Performance), so the bench shows this
/// for a frame first and opens on the next step, as a game would behind its own transition
function esc__pnt_demo_wait(_c, _a) {
    _c.fill = esc_cx_solid([0, 0, 0], 0.55); esc__demo_rr(_c, -204, -54, 420, 116, 14); esc_cx_fill(_c);
    _c.fill = esc_cx_solid([20, 12, 6], 0.92); esc__demo_rr(_c, -210, -60, 420, 116, 14); esc_cx_fill(_c);
    _c.stroke = esc_cx_solid([232, 196, 116], 0.9); _c.lw = 2; esc__demo_rr(_c, -204, -54, 408, 104, 10); esc_cx_stroke(_c);
    esc__demo_text(_c, "Winding the mainspring", 0, -6, 26, ESC_FACE_DISPLAY, [244, 221, 151], 1, 1);
    esc__demo_text(_c, "every wheel is being cut and drawn", 0, 26, 15, ESC_FACE_BODY, [190, 168, 128], 1, 1);
}
function esc__pnt_demo_pick(_c, _a) {
    var _W = ESC_DEMO_CARD_W, _H = ESC_DEMO_CARD_H;
    _c.stroke = esc_cx_solid([40, 20, 0], 0.8); _c.lw = 6; esc__demo_rr(_c, 3, 3, _W + 6, _H + 6, 14); esc_cx_stroke(_c);
    _c.stroke = esc_cx_solid([255, 236, 170], 0.95); _c.lw = 2.5; esc__demo_rr(_c, 3, 3, _W + 6, _H + 6, 14); esc_cx_stroke(_c);
}
function esc__pnt_demo_grades(_c, _a) {
    for (var _g = 1; _g <= 5; _g++) {
        var _x = 36 + (_g - 1) * 64, _on = (_g == _a.grade);
        _c.fill = _on ? esc_cx_solid([200, 155, 69], 1) : esc_cx_solid([45, 30, 20], 1);
        esc_cx_begin(_c); esc_cx_arc(_c, _x, 26, 20, 0, 2 * pi); esc_cx_fill(_c);
        _c.stroke = _on ? esc_cx_solid([255, 236, 170], 1) : esc_cx_solid([120, 92, 52], 1); _c.lw = 2; esc_cx_stroke(_c);
        esc__demo_text(_c, esc__roman(_g), _x, 33, 18, ESC_FACE_DISPLAY, _on ? [40, 24, 8] : [184, 154, 102], 1, 1);
    }
}

/// @function esc_demo_create()
/// @description Open THE CLOCKMAKER'S BENCH. Returns the demo (a struct); draw it with esc_demo_draw, free it with
/// esc_demo_free. The bench is 816 x 624 and is scaled to fit the GUI.
/// @returns {Struct}
function esc_demo_create() {
    var _D = { cards: esc_demo_cards(), pick: 0, grade: 2, puzzle: undefined, solved: [], placed: {}, bg: -1, cardSpr: [], pickSpr: -1, gradeSpr: -1,
        x: 0, y: 0, scale: 1, lastResult: undefined, opened: 0, pending: -1, waitAge: 0, waitSpr: -1, inject: undefined, held: { left: 0, right: 0, up: 0, down: 0 } };
    for (var _i = 0; _i < 4; _i++) array_push(_D.solved, [false, false, false, false, false]);
    _D.bg = esc__bake(ESC_SCENE_W, ESC_SCENE_H, esc__pnt_demo_bg, {}, 0, 0, false);
    for (var _k = 0; _k < 4; _k++) array_push(_D.cardSpr, -1);
    esc__demo_cards_bake(_D);
    _D.waitSpr = esc__bake(440, 140, esc__pnt_demo_wait, {});
    _D.pickSpr = esc__bake(ESC_DEMO_CARD_W + 12, ESC_DEMO_CARD_H + 12, esc__pnt_demo_pick, {}, 0, 0, false);
    esc__demo_grades_bake(_D);
    return _D;
}
function esc__demo_cards_bake(_D) {
    for (var _i = 0; _i < 4; _i++) { _D.cardSpr[_i] = esc__kill(_D.cardSpr[_i]); _D.cardSpr[_i] = esc__bake(ESC_DEMO_CARD_W + 8, ESC_DEMO_CARD_H + 12, esc__pnt_demo_card, { card: _D.cards[_i], i: _i, solved: _D.solved[_i] }, 0, 0, false); }
}
function esc__demo_grades_bake(_D) { _D.gradeSpr = esc__kill(_D.gradeSpr); _D.gradeSpr = esc__bake(5 * 64 + 20, 56, esc__pnt_demo_grades, { grade: _D.grade }, 0, 0, false); }
function esc__demo_key(_D, _i) { return "bench-" + _D.cards[_i].payoff + "-" + string(_D.grade); }
function esc__demo_open(_D, _i) {
    var _key = esc__demo_key(_D, _i), _c = _D.cards[_i];
    _D.puzzle = esc_open({ seed: _key, grade: _D.grade, payoff: _c.payoff, metal: _c.metal, title: _c.title, key: _key, placed: _D.placed[$ _key] });
    _D.opened++;
}

/// @function esc_demo_step(demo)
/// @description Run the bench (or the open puzzle) for one step. Call it in Step.
function esc_demo_step(_D) {
    if (!is_struct(_D)) return;
    _D.scale = max(0.1, min(display_get_gui_width() / ESC_SCENE_W, display_get_gui_height() / ESC_SCENE_H));
    _D.x = (display_get_gui_width() - ESC_SCENE_W * _D.scale) / 2; _D.y = (display_get_gui_height() - ESC_SCENE_H * _D.scale) / 2;
    if (is_struct(_D.puzzle)) {
        if (is_struct(_D.inject)) { _D.puzzle.inject = _D.inject; _D.inject = undefined; }
        esc_step(_D.puzzle);
        if (esc_closed(_D.puzzle)) {
            var _r = _D.puzzle.result;
            _D.lastResult = _r;
            if (is_struct(_r)) {
                if (_r.solved) { for (var _i = 0; _i < 4; _i++) if (_D.cards[_i].payoff == _r.payoff) array_set(_D.solved[_i], _r.grade - 1, true); variable_struct_remove(_D.placed, _r.key); esc__demo_cards_bake(_D); }
                else _D.placed[$ _r.key] = _r.placed;
            }
            esc_free(_D.puzzle); _D.puzzle = undefined;
        }
        return;
    }
    // a choice made last step opens now, behind the wait card drawn in between
    if (_D.pending >= 0) { _D.waitAge++; if (_D.waitAge >= 2) { var _pk = _D.pending; _D.pending = -1; esc__demo_open(_D, _pk); } return; }
    var _mx = (device_mouse_x_to_gui(0) - _D.x) / _D.scale, _my = (device_mouse_y_to_gui(0) - _D.y) / _D.scale;
    var _in = { x: _mx, y: _my, click: mouse_check_button_pressed(mb_left), ok: keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("Z")),
        left: keyboard_check(vk_left), right: keyboard_check(vk_right), up: keyboard_check(vk_up), down: keyboard_check(vk_down) };
    if (is_struct(_D.inject)) { var _f = ["x", "y", "click", "ok", "left", "right", "up", "down"]; for (var _q = 0; _q < 8; _q++) _in[$ _f[_q]] = is_undefined(_D.inject[$ _f[_q]]) ? ((_q < 2) ? -1000 : false) : _D.inject[$ _f[_q]]; _D.inject = undefined; }
    if (esc__repeat(_D, "left", _in.left)) _D.pick = (_D.pick + 3) mod 4;
    if (esc__repeat(_D, "right", _in.right)) _D.pick = (_D.pick + 1) mod 4;
    if (esc__repeat(_D, "up", _in.up)) { _D.grade = min(5, _D.grade + 1); esc__demo_grades_bake(_D); }
    if (esc__repeat(_D, "down", _in.down)) { _D.grade = max(1, _D.grade - 1); esc__demo_grades_bake(_D); }
    if (_in.click) {
        for (var _k = 0; _k < 4; _k++) if (_in.x >= esc__demo_card_x(_k) && _in.x < esc__demo_card_x(_k) + ESC_DEMO_CARD_W && _in.y >= ESC_DEMO_CARD_Y && _in.y < ESC_DEMO_CARD_Y + ESC_DEMO_CARD_H) { _D.pick = _k; _D.pending = _k; _D.waitAge = 0; return; }
        for (var _g = 1; _g <= 5; _g++) if (point_distance(_in.x, _in.y, esc__demo_grade_x(_g) + 26, ESC_DEMO_GRADE_Y + 8) <= 22) { _D.grade = _g; esc__demo_grades_bake(_D); }
    }
    if (_in.ok) { _D.pending = _D.pick; _D.waitAge = 0; }
}

/// @function esc_demo_draw(demo)
/// @description Draw the bench, or the open puzzle, scaled to fit the GUI. Call it in Draw GUI.
function esc_demo_draw(_D) {
    if (!is_struct(_D)) return;
    if (is_struct(_D.puzzle)) { esc_draw(_D.puzzle, _D.x, _D.y, _D.scale); return; }
    var _waiting = _D.pending >= 0;
    var _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_multiply(matrix_build(_D.x, _D.y, 0, 0, 0, 0, _D.scale, _D.scale, 1), _mw));
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); gpu_set_texfilter(true);
    esc__spr(_D.bg, 0, 0);
    for (var _i = 0; _i < 4; _i++) esc__spr(_D.cardSpr[_i], esc__demo_card_x(_i), ESC_DEMO_CARD_Y);
    esc__spr(_D.pickSpr, esc__demo_card_x(_D.pick) - 6, ESC_DEMO_CARD_Y - 6, 0.75 + 0.25 * sin(current_time / 260));
    esc__spr(_D.gradeSpr, esc__demo_grade_x(1) - 10, ESC_DEMO_GRADE_Y - 18);
    if (_waiting) esc__spr(_D.waitSpr, ESC_SCENE_W / 2, ESC_SCENE_H / 2);
    gpu_pop_state();
    matrix_set(matrix_world, _mw);
}

/// @function esc_demo_free(demo)
/// @description Free every sprite the demo and its open puzzle made. Runs even when Create left early (-selftest).
function esc_demo_free(_D) {
    if (!is_struct(_D)) return;
    if (is_struct(_D[$ "puzzle"])) esc_free(_D.puzzle);
    _D.puzzle = undefined;
    _D.bg = esc__kill(_D.bg); _D.pickSpr = esc__kill(_D.pickSpr); _D.waitSpr = esc__kill(_D.waitSpr); _D.gradeSpr = esc__kill(_D.gradeSpr);
    if (is_array(_D[$ "cardSpr"])) for (var _i = 0; _i < array_length(_D.cardSpr); _i++) _D.cardSpr[_i] = esc__kill(_D.cardSpr[_i]);
}
