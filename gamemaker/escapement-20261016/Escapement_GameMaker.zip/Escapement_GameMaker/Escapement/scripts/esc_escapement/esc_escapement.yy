{
  "$GMScript": "v1",
  "%Name": "esc_escapement",
  "name": "esc_escapement",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}