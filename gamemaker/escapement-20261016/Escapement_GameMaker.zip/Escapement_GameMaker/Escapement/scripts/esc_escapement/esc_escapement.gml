/// esc_escapement.gml - the puzzle scene: a generated clockwork train the player completes on a drawn brass plate.
///
/// Escapement - Generated Clockwork Gear Puzzles, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// The RPG Maker MZ edition's Scene_Escapement as five calls:
///   Create:   puzzle = esc_open({ seed: "vault door", grade: 3, payoff: "lock" });
///   Step:     esc_step(puzzle);  if (esc_closed(puzzle)) { var r = puzzle.result; esc_free(puzzle); puzzle = undefined; }
///   Draw GUI: esc_draw(puzzle, 0, 0, 1);
///   Clean Up: esc_free(puzzle);
/// The scene is 816 x 624 at scale 1 (the MZ edition's screen). Arrow keys choose an arbor; Enter / Space / Z on an empty
/// arbor opens the tray, Left / Right choose a wheel, Enter sets it; Enter on a set wheel lifts it back. Escape / Backspace
/// / X / right click leaves (the wheels stay where they were: puzzle.result.placed). Mouse or touch: click an arbor, then a
/// wheel in the tray. Every picture is drawn once at 2x through the canvas kit and kept as a sprite; a frame turns sprites.
///
/// Public functions (each documented below): esc_open, esc_step, esc_draw, esc_closed, esc_free, esc_goal, esc_title_for,
/// esc_forget_bench.

#macro ESC_SS 2
#macro ESC_SCENE_W 816
#macro ESC_SCENE_H 624
#macro ESC_PLATE_X 88
#macro ESC_PLATE_Y 76
#macro ESC_TRAY_Y 500
#macro ESC_TRAY_H 108

// ---------------------------------------------------------------------------------------------------------------
// Baking pictures: drawn through the kit at 2x, filtered down, kept as sprites (premultiplied)
// ---------------------------------------------------------------------------------------------------------------

/// internal: a w x h sprite of what painter(ctx, args) draws with the context's origin at the sprite's CENTRE (the MZ
/// makeDrawn), supersampled 2x and filtered down; the sprite's own origin is (ox, oy) (default the centre). PREMULTIPLIED.
/// Every internal pass runs under identity and the caller's world matrix and surface target are handed back.
function esc__bake(_w, _h, _painter, _args, _ox = undefined, _oy = undefined, _centred = true) {
    var _W = max(1, ceil(_w)), _H = max(1, ceil(_h));
    var _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_build_identity());
    var _s2 = surface_create(_W * ESC_SS, _H * ESC_SS), _s1 = surface_create(_W, _H);
    surface_set_target(_s2); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha); gpu_set_ztestenable(false); gpu_set_zwriteenable(false);
    var _c = esc_cx_create(ESC_SS);
    if (_centred) esc_cx_translate(_c, _w / 2, _h / 2);
    _painter(_c, _args);
    gpu_pop_state(); surface_reset_target();
    surface_set_target(_s1); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_zero); gpu_set_texfilter(true);
    draw_surface_ext(_s2, 0, 0, 1 / ESC_SS, 1 / ESC_SS, 0, c_white, 1);
    gpu_pop_state(); surface_reset_target();
    var _spr = sprite_create_from_surface(_s1, 0, 0, _W, _H, false, false, is_numeric(_ox) ? _ox : _W / 2, is_numeric(_oy) ? _oy : _H / 2);
    surface_free(_s2); surface_free(_s1);
    matrix_set(matrix_world, _mw);
    return _spr;
}
/// internal: draw a premultiplied sprite at alpha a, scale sc, rotated by rad RADIANS CLOCKWISE (the MZ sprite.rotation)
function esc__spr(_spr, _x, _y, _a = 1, _sc = 1, _rad = 0) {
    if (is_numeric(_spr) && _spr >= 0 && sprite_exists(_spr) && _a > 0) draw_sprite_ext(_spr, 0, _x, _y, _sc, _sc, -radtodeg(_rad), merge_colour(c_black, c_white, _a), _a);
}
function esc__kill(_spr) { if (is_numeric(_spr) && _spr >= 0 && sprite_exists(_spr)) sprite_delete(_spr); return -1; }
function esc__fin(_v, _d) { return (is_numeric(_v) && !is_nan(_v) && !is_infinity(_v)) ? _v : _d; }

// painters (ctx, args) - each the body of an MZ makeDrawn / bitmap draw
/// the leather bench under the plate. The MZ draws it with a FIXED seed and it depends on nothing but the screen size, so it is
/// drawn once per game run and kept (global.esc_leather) - it was the larger half of opening a puzzle (measured 2026-10-10).
/// Never freed by esc_free; esc_forget_bench() lets it go.
function esc__pnt_leather(_c, _a) { esc_draw_bench(_c, ESC_SCENE_W, ESC_SCENE_H, "brass"); }
function esc__leather() {
    if (variable_global_exists("esc_leather") && is_numeric(global.esc_leather) && global.esc_leather >= 0 && sprite_exists(global.esc_leather)) return global.esc_leather;
    global.esc_leather = esc__bake(ESC_SCENE_W, ESC_SCENE_H, esc__pnt_leather, {}, 0, 0, false);
    return global.esc_leather;
}
/// @function esc_forget_bench()
/// @description Free the leather bench esc_open keeps between puzzles (drawn once per game run). The next esc_open draws it
/// again. Call it when you will open no more puzzles for a while, or never: it is one 816 x 624 sprite.
function esc_forget_bench() { if (variable_global_exists("esc_leather")) global.esc_leather = esc__kill(global.esc_leather); }
/// the plate, its arbors, the mainspring arrow and the payoff base, baked into a PLATE-SIZED picture (ESC_PLATE_PAD round it
/// for the drop shadow): the plate clips its brushed finish, and a shaped clip is a layer the size of the target, so a
/// full-screen target made every plate pay for the whole screen (measured 2026-10-10)
#macro ESC_PLATE_PAD 24
function esc__pnt_bench(_c, _a) {
    var _T = _a.T, _pz = _T.pz, _t0 = get_timer();
    esc_cx_translate(_c, ESC_PLATE_PAD, ESC_PLATE_PAD);
    esc_draw_plate(_c, _pz, undefined);
    _T.timing.plateMs = (get_timer() - _t0) / 1000; _t0 = get_timer();
    for (var _i = 0; _i < array_length(_pz.arbors); _i++) esc_draw_arbor(_c, _pz.arbors[_i].x, _pz.arbors[_i].y, _pz.metal);
    esc_draw_turn_arrow(_c, _pz.drive.x, _pz.drive.y, esc_outer_r(_pz.drive.n), 1, _pz.metal, "mainspring", _T.driveSide);
    _T.timing.arborsMs = (get_timer() - _t0) / 1000; _t0 = get_timer();
    _T.anchor = esc_draw_payoff_base(_c, _pz);
    _T.timing.payoffBaseMs = (get_timer() - _t0) / 1000;
}
/// the heading on its own picture, as the MZ draws it on its own bitmap (esc_draw_heading clears its band first, so it must
/// never be drawn into the bench itself: that clear punched a hole through the bench - found by looking, 2026-10-10)
function esc__pnt_heading(_c, _a) { esc_draw_heading(_c, ESC_SCENE_W, _a.title, _a.grade); }
function esc__pnt_gear(_c, _a) { esc_draw_gear(_c, { n: _a.n, module: ESC_MODULE, style: _a.style, metal: _a.metal, role: _a.role }); }
function esc__pnt_glint(_c, _a) { esc_draw_glint(_c, _a.R, _a.metal); }
function esc__pnt_hint(_c, _a) { esc_draw_turn_hint(_c, _a.R, _a.dir, "must turn", _a.side); }
function esc__pnt_shadows(_c, _a) {
    var _T = _a.T, _pz = _T.pz;
    esc_draw_shadow(_c, _pz.drive.x, _pz.drive.y, esc_outer_r(_pz.drive.n), 1);
    esc_draw_shadow(_c, _pz.output.x, _pz.output.y, esc_outer_r(_pz.output.n), 1);
    for (var _i = 0; _i < array_length(_pz.arbors); _i++) if (_T.placed[_i] >= 0) esc_draw_shadow(_c, _pz.arbors[_i].x, _pz.arbors[_i].y, esc_outer_r(_pz.tray[_T.placed[_i]].n), 1);
}
function esc__pnt_tray(_c, _a) { _a.T.slot = esc_draw_tray(_c, _a.T.pz.plate.w, ESC_TRAY_H, array_length(_a.T.pz.tray), _a.T.pz.metal).slot; }
function esc__pnt_bolt(_c, _a) { esc_draw_bolt(_c, _a.L, _a.metal); }
function esc__pnt_word(_c, _a) { esc_draw_window_word(_c, _a.word, _a.good); }
function esc__pnt_hand(_c, _a) { esc_cx_translate(_c, 0, _a.dy); esc_draw_hand(_c, _a.len, _a.width, _a.metal, _a.counter); }
function esc__pnt_sun(_c, _a) { esc_draw_sun(_c, 9); }
function esc__pnt_arm(_c, _a) { esc_draw_planet_arm(_c, _a.len, _a.pr, _a.rgb, _a.metal); }
function esc__pnt_drum(_c, _a) { esc_draw_drum(_c, 20, _a.metal); }
function esc__pnt_weight(_c, _a) { esc_cx_translate(_c, 0, -18); esc_draw_weight(_c, _a.metal); }
function esc__pnt_warning(_c, _a) { esc_draw_warning(_c, 58); }
/// the loupe, drawn at ESC_CURSOR_K times its size and always scaled DOWN: the MZ scales a 17-px loupe up to 4.8x round a big
/// wheel, which here read as blocky steps (found by looking, 2026-10-10)
#macro ESC_CURSOR_K 5
function esc__pnt_cursor(_c, _a) { esc_cx_scale(_c, ESC_CURSOR_K, ESC_CURSOR_K); esc_draw_cursor(_c, 17); }
function esc__pnt_status(_c, _a) { esc_draw_status(_c, ESC_SCENE_W, _a.text, _a.tone); }

// ---------------------------------------------------------------------------------------------------------------
// Names and goals
// ---------------------------------------------------------------------------------------------------------------

/// @function esc_title_for(payoff)
/// @description The default name set above the plate for a payoff: "The Strongroom Lock", "The Tower Clock", "The
/// Orrery" or "The Portcullis Winch" (an unknown payoff names the lock). Pure.
/// @returns {String}
function esc_title_for(_payoff) {
    switch (_payoff) { case "clock": return "The Tower Clock"; case "orrery": return "The Orrery"; case "winch": return "The Portcullis Winch"; }
    return "The Strongroom Lock";
}
/// @function esc_goal(payoff)
/// @description What the payoff does when the train is right: "the bolt draws back", "the hands turn true", "the planets
/// wheel" or "the weight rises". Pure.
/// @returns {String}
function esc_goal(_payoff) {
    switch (_payoff) { case "clock": return "the hands turn true"; case "orrery": return "the planets wheel"; case "winch": return "the weight rises"; }
    return "the bolt draws back";
}
function esc__reason_text(_r) {
    switch (_r) {
        case "collide": return "No room: it fouls a wheel already there.";
        case "covers-post": return "No room: it would cover another pivot.";
        case "under-gear": return "No room: a wheel already overhangs this pivot.";
        case "occupied": return "That arbor already carries a wheel.";
        case "in-use": return "That wheel is already set.";
    }
    return "No room.";
}
/// internal: true for a placement that fits this puzzle (one entry per arbor, each -1 or a tray index used once)
function esc__placed_ok(_pz, _pl) {
    if (!is_array(_pl) || array_length(_pl) != array_length(_pz.arbors)) return false;
    var _seen = array_create(array_length(_pz.tray), false);
    for (var _i = 0; _i < array_length(_pl); _i++) {
        var _v = _pl[_i];
        if (!is_numeric(_v) || is_nan(_v) || _v != floor(_v)) return false;
        if (_v == -1) continue;
        if (_v < 0 || _v >= array_length(_pz.tray) || _seen[_v]) return false;
        _seen[_v] = true;
    }
    return true;
}

// ---------------------------------------------------------------------------------------------------------------
// Opening a puzzle
// ---------------------------------------------------------------------------------------------------------------

/// @function esc_open(request)
/// @description Generate a clockwork puzzle and lay it out on the bench. Returns the puzzle (a struct) - or undefined, with
/// a message in the output log, when the request is not a struct.
/// Request: { seed: "" (blank = a new puzzle every time; a number or a word gives the same puzzle every time), grade: 2 (1
/// easy to 5 hard), payoff: "lock" | "clock" | "orrery" | "winch" | "auto" (default "lock"), metal: "brass" | "steel" |
/// "bronze" | "verdigris" | "gunmetal" | "auto" (default "auto": chosen by the seed), title: "" (blank names it after the
/// payoff), placed: undefined (a placement from an earlier puzzle.result.placed, to carry on where the player left off),
/// allow_leave: true (false refuses Escape until the train is complete), drive_speed: 1.2 (degrees per step), sound:
/// undefined (function(name) called with "place", "lift", "refuse", "solve", "cursor"), key: "" (yours, handed back) }.
/// @param {Struct} request
/// @returns {Struct|Undefined}
function esc_open(_req) {
    if (!is_struct(_req)) { show_debug_message("Escapement: esc_open needs a request struct, e.g. { seed: \"vault\", grade: 3, payoff: \"lock\" }."); return undefined; }
    var _seed = _req[$ "seed"], _seedNum;
    if (is_numeric(_seed) && !is_nan(_seed) && !is_infinity(_seed)) _seedNum = _seed;
    else if (is_string(_seed) && string_trim(_seed) != "") {
        var _st = string_trim(_seed), _digits = string_digits(_st) == _st && string_length(_st) <= 10;
        _seedNum = _digits ? real(esc__u32(real(_st))) : esc_hash(_st);
    } else {
        global.esc_opened = (variable_global_exists("esc_opened") ? global.esc_opened : 0) + 1;
        _seedNum = esc_hash("e" + string(global.esc_opened) + "t" + string(get_timer()));
    }
    var _g = esc__fin(_req[$ "grade"], 2);
    if (!(_g >= 1)) _g = 2;
    var _pay = _req[$ "payoff"], _met = _req[$ "metal"];
    if (!is_string(_pay)) _pay = "lock";
    var _pz = esc_generate({ seed: _seedNum, grade: _g, payoff: (_pay == "auto") ? undefined : _pay, metal: (is_string(_met) && _met != "auto") ? _met : undefined });
    if (!is_struct(_pz)) return undefined;
    var _title = _req[$ "title"];
    _title = (is_string(_title) && string_trim(_title) != "") ? string_trim(_title) : esc_title_for(_pz.payoff);
    var _spd = clamp(esc__fin(_req[$ "drive_speed"], 1.2), 0.1, 5) * pi / 180;
    var _al = _req[$ "allow_leave"];
    var _T = {
        pz: _pz, title: _title, key: is_undefined(_req[$ "key"]) ? "" : _req.key, sound: _req[$ "sound"],
        allowLeave: is_undefined(_al) ? true : ((is_bool(_al) || is_numeric(_al)) ? bool(_al) : true), speed: _spd,
        placed: esc__placed_ok(_pz, _req[$ "placed"]) ? esc__copy(_req.placed) : esc_empty_placement(_pz),
        mode: "board", cursor: 0, trayCursor: 0, theta: 0, frame: 0, progress: 0, doneWait: 0,
        status: "", statusTone: "", flash: 0, moves: 0, x: 0, y: 0, scale: 1, closed: false, result: undefined, inject: undefined,
        ev: undefined, wheelArbor: [], restAngle: [], trayScale: [], slot: 0, warnOn: false, warnX: 0, warnY: 0, warnScale: 1,
        driveSide: 0, outputSide: 0, anchor: undefined, held: { left: 0, right: 0, up: 0, down: 0 },
        bench: -1, shadows: -1, tray: -1, driveSpr: -1, outputSpr: -1, wheelSpr: [], glintSpr: [], driveGlint: -1, outputGlint: -1,
        hint: -1, warn: -1, cursorSpr: -1, statusSpr: -1, headingSpr: -1, leather: -1, parts: {}, built: false, bakeMs: 0, timing: {}
    };
    var _t0 = get_timer();
    esc__build(_T);
    _T.bakeMs = (get_timer() - _t0) / 1000;
    return _T;
}

/// internal: draw everything once (the MZ create()).
function esc__build(_T) {
    var _pz = _T.pz, _maxR = 0;
    for (var _t = 0; _t < array_length(_pz.tray); _t++) _maxR = max(_maxR, esc_outer_r(_pz.tray[_t].n));
    var _dR = esc_outer_r(_pz.drive.n), _oR = esc_outer_r(_pz.output.n);
    _T.driveSide = esc_clear_side(_pz, _pz.drive.x, _pz.drive.y, _dR, { x: _pz.output.x, y: _pz.output.y, R: _oR }, _maxR, _pz.plate.payoffX);
    _T.outputSide = esc_clear_side(_pz, _pz.output.x, _pz.output.y, _oR, { x: _pz.drive.x, y: _pz.drive.y, R: _dR }, _maxR, _pz.plate.payoffX);
    var _tb = get_timer();
    _T.timing = {};
    _T.leather = esc__leather();
    _T.timing.leatherMs = (get_timer() - _tb) / 1000; _tb = get_timer();
    _T.bench = esc__bake(_pz.plate.w + ESC_PLATE_PAD * 2, _pz.plate.h + ESC_PLATE_PAD * 2, esc__pnt_bench, { T: _T }, 0, 0, false);
    _T.timing.benchMs = (get_timer() - _tb) / 1000; _tb = get_timer();
    _T.headingSpr = esc__bake(ESC_SCENE_W, 60, esc__pnt_heading, { title: _T.title, grade: _pz.grade }, 0, 0, false);
    _T.timing.headingMs = (get_timer() - _tb) / 1000; _tb = get_timer();
    // the payoff's moving parts
    var _a = _T.anchor, _acc = esc_accent(_pz.metal), _P = _T.parts, _m = _pz.metal;
    if (_pz.payoff == "lock") {
        var _L = _a.bolt.len;
        _P.bolt = esc__bake(_L * 2 + 4, 24, esc__pnt_bolt, { L: _L, metal: _m });
        _P.boltX0 = ESC_PLATE_X + _a.bolt.left0; _P.boltY = ESC_PLATE_Y + _a.bolt.y; _P.travel = _a.bolt.travel;
        _P.shut = esc__bake(56, 16, esc__pnt_word, { word: "SHUT", good: false });
        _P.drawn = esc__bake(56, 16, esc__pnt_word, { word: "DRAWN", good: true });
        _P.wx = ESC_PLATE_X + _a.window.x; _P.wy = ESC_PLATE_Y + _a.window.y;
        _P.boltX = _P.boltX0; _P.drawnOn = false;
    } else if (_pz.payoff == "clock") {
        var _R = _a.dial.R;
        _P.hour = esc__bake(20, _R * 1.3, esc__pnt_hand, { dy: _R * 0.3, len: _R * 0.5, width: 3.2, metal: _acc, counter: 7 }, 10, _R * 0.65 + _R * 0.3);
        _P.minute = esc__bake(16, _R * 2, esc__pnt_hand, { dy: _R * 0.62, len: _R * 0.78, width: 2.2, metal: _acc, counter: 9 }, 8, _R + _R * 0.62);
        _P.cx = ESC_PLATE_X + _a.dial.x; _P.cy = ESC_PLATE_Y + _a.dial.y;
        _P.hour0 = 5.2; _P.minute0 = 2.1; _P.hourRot = _P.hour0; _P.minuteRot = _P.minute0;
    } else if (_pz.payoff == "orrery") {
        var _o = _a.orrery;
        _P.sun = esc__bake(30, 30, esc__pnt_sun, {});
        _P.cx = ESC_PLATE_X + _o.x; _P.cy = ESC_PLATE_Y + _o.y;
        var _cols = [[127, 178, 255], [228, 107, 76], [231, 210, 122]], _pr = [4.5, 5.5, 7.5];
        _P.arms = []; _P.armRate = [1.0, 0.62, 0.38]; _P.arm0 = [0.4, 2.3, 4.4]; _P.armRot = [0.4, 2.3, 4.4]; _P.sunRot = 0;
        for (var _i = 0; _i < 3; _i++) array_push(_P.arms, esc__bake(_o.orbits[_i] * 2 + 16, 16, esc__pnt_arm, { len: _o.orbits[_i], pr: _pr[_i], rgb: _cols[_i], metal: _acc }));
    } else {
        var _w = _a.winch;
        _P.drum = esc__bake(46, 46, esc__pnt_drum, { metal: _acc });
        _P.weight = esc__bake(30, 70, esc__pnt_weight, { metal: _m }, 15, 17);
        _P.cx = ESC_PLATE_X + _w.x; _P.cy = ESC_PLATE_Y + _w.y;
        _P.top = ESC_PLATE_Y + _w.y + 30; _P.bottom = ESC_PLATE_Y + _w.bottom - 30;
        _P.weightY = _P.bottom; _P.drumRot = 0;
    }
    _T.timing.payoffMs = (get_timer() - _tb) / 1000; _tb = get_timer();
    _T.tray = esc__bake(_pz.plate.w + 8, ESC_TRAY_H + 8, esc__pnt_tray, { T: _T }, 0, 0, false);
    _T.timing.trayMs = (get_timer() - _tb) / 1000; _tb = get_timer();
    // the wheels: one sprite per tray wheel, moved between tray and arbor, never redrawn
    _T.driveSpr = esc__bake((_dR + 2) * 2, (_dR + 2) * 2, esc__pnt_gear, { n: _pz.drive.n, style: "disc", metal: _m, role: "drive" });
    _T.outputSpr = esc__bake((_oR + 2) * 2, (_oR + 2) * 2, esc__pnt_gear, { n: _pz.output.n, style: "holes", metal: _m, role: "output" });
    var _r = esc__rng(real((int64(_pz.seed) ^ int64($77)) & int64($FFFFFFFF)));
    for (var _k = 0; _k < array_length(_pz.tray); _k++) {
        var _n = _pz.tray[_k].n, _R2 = esc_outer_r(_n) + 2;
        array_push(_T.wheelSpr, esc__bake(_R2 * 2, _R2 * 2, esc__pnt_gear, { n: _n, style: _pz.tray[_k].style, metal: _m, role: "loose" }));
        array_push(_T.restAngle, esc__rng_next(_r) * pi * 2);
        array_push(_T.glintSpr, esc__bake(esc_outer_r(_n) * 2 + 2, esc_outer_r(_n) * 2 + 2, esc__pnt_glint, { R: esc_outer_r(_n), metal: _m }));
        array_push(_T.trayScale, min(1, (min(_T.slot, ESC_TRAY_H - 16) * 0.46) / esc_outer_r(_n)));
    }
    _T.timing.wheelsMs = (get_timer() - _tb) / 1000; _tb = get_timer();
    _T.driveGlint = esc__bake(_dR * 2 + 2, _dR * 2 + 2, esc__pnt_glint, { R: _dR, metal: _m });
    _T.outputGlint = esc__bake(_oR * 2 + 2, _oR * 2 + 2, esc__pnt_glint, { R: _oR, metal: _m });
    var _span = (_oR + 90) * 2;
    _T.hint = esc__bake(_span, _span, esc__pnt_hint, { R: _oR, dir: esc_required_dir(_pz), side: _T.outputSide });
    _T.warn = esc__bake(120, 120, esc__pnt_warning, {});
    _T.cursorSpr = esc__bake(60 * ESC_CURSOR_K, 60 * ESC_CURSOR_K, esc__pnt_cursor, {});
    _T.timing.restMs = (get_timer() - _tb) / 1000; _tb = get_timer();
    _T.built = true;
    esc__refresh(_T, true);
}

/// internal: the status line, redrawn only when it changes
function esc__set_status(_T, _text, _tone) {
    if (_text == _T.status && _tone == _T.statusTone && _T.statusSpr >= 0) return;
    _T.status = _text; _T.statusTone = _tone;
    _T.statusSpr = esc__kill(_T.statusSpr);
    _T.statusSpr = esc__bake(ESC_SCENE_W, 40, esc__pnt_status, { text: _text, tone: _tone }, 0, 0, false);
}
function esc__sound(_T, _name) { if (is_callable(_T.sound)) _T.sound(_name); }

/// internal: evaluate the train after a wheel moved; park every wheel, redraw the shadows, describe, start the payoff.
function esc__refresh(_T, _initial) {
    var _pz = _T.pz, _ev = esc_evaluate(_pz, _T.placed);
    _T.ev = _ev;
    _T.shadows = esc__kill(_T.shadows);
    _T.shadows = esc__bake(_pz.plate.w + 20, _pz.plate.h + 20, esc__pnt_shadows, { T: _T }, 0, 0, false);
    var _on = array_create(array_length(_pz.tray), -1);
    for (var _b = 0; _b < array_length(_T.placed); _b++) if (_T.placed[_b] >= 0) _on[_T.placed[_b]] = _b;
    _T.wheelArbor = _on;
    if (_initial) esc__set_status(_T, "Complete the train so " + esc_goal(_pz.payoff) + ".", "");
    else esc__describe(_T, _ev);
    // the warning halo: the output (the pawl holds) or the jamming mesh
    _T.warnOn = false;
    if (_ev.wrongWay) { _T.warnOn = true; _T.warnX = ESC_PLATE_X + _pz.output.x; _T.warnY = ESC_PLATE_Y + _pz.output.y; _T.warnScale = (esc_outer_r(_pz.output.n) + 16) / 58; }
    else if (_ev.jam && is_array(_ev.jamEdge)) {
        var _u = _ev.nodes[_ev.jamEdge[0]], _v = _ev.nodes[_ev.jamEdge[1]];
        _T.warnOn = true; _T.warnX = ESC_PLATE_X + (_u.x + _v.x) / 2; _T.warnY = ESC_PLATE_Y + (_u.y + _v.y) / 2; _T.warnScale = 0.8;
    }
    if (_ev.solved && _T.mode != "solving" && _T.mode != "done") { _T.mode = "solving"; _T.progress = 0; esc__sound(_T, "solve"); }
}
function esc__describe(_T, _ev) {
    var _pz = _T.pz, _turning = 0;
    for (var _i = 2; _i < array_length(_ev.nodes); _i++) if (!is_undefined(_ev.nodes[_i]) && _ev.connected[_i]) _turning++;
    if (_ev.jam) { esc__set_status(_T, "Jammed: a loop of an odd number of wheels fights itself.", "bad"); return; }
    if (_ev.solved) { var _g = esc_goal(_pz.payoff); esc__set_status(_T, "It runs. " + string_upper(string_char_at(_g, 1)) + string_delete(_g, 1, 1) + ".", "good"); return; }
    if (_ev.wrongWay) { esc__set_status(_T, "The pawl holds: the train reaches it turning the wrong way.", "bad"); return; }
    if (_turning == 0) { esc__set_status(_T, "Nothing turns yet. Start from the mainspring.", ""); return; }
    esc__set_status(_T, string(_turning) + ((_turning == 1) ? " wheel turns" : " wheels turn") + " with the mainspring.", "");
}

// ---------------------------------------------------------------------------------------------------------------
// Per step
// ---------------------------------------------------------------------------------------------------------------

function esc__tray_x(_T, _t) { return ESC_PLATE_X + 8 + _T.slot * (_t + 0.5); }
function esc__tray_y() { return ESC_TRAY_Y + ESC_TRAY_H / 2; }
/// internal: an MZ Input.isRepeated - true on the press, then every 6 steps once held 24
function esc__repeat(_T, _dir, _down) {
    if (!_down) { _T.held[$ _dir] = 0; return false; }
    var _h = _T.held[$ _dir] + 1; _T.held[$ _dir] = _h;
    return _h == 1 || (_h > 24 && ((_h - 24) mod 6) == 0);
}
function esc__input(_T, _x, _y) {
    return { x: _x, y: _y, click: mouse_check_button_pressed(mb_left), rclick: mouse_check_button_pressed(mb_right),
        ok: keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("Z")),
        cancel: keyboard_check_pressed(vk_escape) || keyboard_check_pressed(vk_backspace) || keyboard_check_pressed(ord("X")),
        left: keyboard_check(vk_left), right: keyboard_check(vk_right), up: keyboard_check(vk_up), down: keyboard_check(vk_down) };
}

/// @function esc_step(puzzle, [mouse_x], [mouse_y])
/// @description Run the puzzle for one step: input, the train turning, the payoff, the cursor and the ending. Call it in
/// Step. The mouse is read in GUI coordinates (device_mouse_x_to_gui) relative to where esc_draw last drew the scene; pass
/// your own coordinates when the scene is drawn in a room or a view.
function esc_step(_T, _mx = undefined, _my = undefined) {
    if (!is_struct(_T) || _T.closed || !_T.built) return;
    _T.frame++;
    var _gx = is_numeric(_mx) ? _mx : device_mouse_x_to_gui(0), _gy = is_numeric(_my) ? _my : device_mouse_y_to_gui(0), _k = (_T.scale > 0) ? _T.scale : 1;
    var _in = esc__input(_T, (_gx - _T.x) / _k, (_gy - _T.y) / _k);
    var _ij = _T.inject;
    if (is_struct(_ij)) {
        var _f = ["x", "y", "click", "rclick", "ok", "cancel", "left", "right", "up", "down"];
        for (var _i = 0; _i < array_length(_f); _i++) _in[$ _f[_i]] = is_undefined(_ij[$ _f[_i]]) ? ((_i < 2) ? -1000 : false) : _ij[$ _f[_i]];
        _T.inject = undefined;
    }
    if (_T.mode == "board" || _T.mode == "tray") esc__update_input(_T, _in);
    if (_T.closed) return;
    esc__update_train(_T);
    esc__update_payoff(_T);
    if (_T.mode == "solving") {
        _T.progress += 1 / 150;
        if (_T.progress >= 1) { _T.progress = 1; _T.mode = "done"; _T.doneWait = 70; }
    } else if (_T.mode == "done") {
        _T.doneWait--;
        if (_T.doneWait <= 0) esc__close(_T, true);
    }
}
function esc__close(_T, _solved) {
    var _pz = _T.pz;
    _T.result = { solved: _solved, placed: esc__copy(_T.placed), moves: _T.moves, seed: _pz.seed, grade: _pz.grade, payoff: _pz.payoff, metal: _pz.metal, key: _T.key };
    _T.closed = true;
}
function esc__stuck(_T) { return _T.ev.jam || _T.ev.wrongWay; }
function esc__update_train(_T) {
    var _stuck = esc__stuck(_T);
    if (!_stuck) _T.theta += _T.speed * ((_T.mode == "solving") ? 2.2 : 1);
    if (_T.flash > 0) _T.flash--;
}
function esc__ease(_p) { return _p * _p * (3 - 2 * _p); }
function esc__update_payoff(_T) {
    var _P = _T.parts, _pz = _T.pz, _ev = _T.ev, _e = esc__ease(_T.progress);
    var _jit = _ev.wrongWay ? 1.5 * sin(_T.frame * 1.3) : 0;
    var _outTheta = _ev.connected[1] ? esc__wheel_angle(_T, 1) : 0;
    if (_pz.payoff == "lock") { _P.boltX = _P.boltX0 + _P.travel * _e + _jit; _P.drawnOn = _T.progress >= 0.98; }
    else if (_pz.payoff == "clock") {
        var _mT = ceil(_P.minute0 / (pi * 2) + 3) * pi * 2;
        _P.minuteRot = _P.minute0 + (_mT - _P.minute0) * _e + _jit * 0.02;
        _P.hourRot = _P.hour0 + ((pi * 2) - _P.hour0) * _e + _jit * 0.02;
    } else if (_pz.payoff == "orrery") {
        for (var _i = 0; _i < 3; _i++) { var _free = _P.arm0[_i] + _P.armRate[_i] * _outTheta * 0.3; _P.armRot[_i] = _free * (1 - _e) + (-pi / 2 + pi * 2 * (3 - _i)) * _e + _jit * 0.02; }
        _P.sunRot = _T.frame * 0.004;
    } else { _P.drumRot = _outTheta * 0.5 + _jit * 0.02; _P.weightY = _P.bottom - (_P.bottom - _P.top) * _e + _jit; }
}
/// internal: the angle node i (0 drive, 1 output, 2 + a arbor a) shows this step: theta = s x theta_drive + b
function esc__wheel_angle(_T, _i) {
    var _shake = esc__stuck(_T) ? 0.035 * sin(_T.frame * 0.9) : 0, _th = _T.theta + _shake;
    if (_i == 0) return _th;
    return _T.ev.s[_i] * _th + _T.ev.b[_i];
}

function esc__update_input(_T, _in) {
    if (_in.click) { esc__on_touch(_T, _in.x, _in.y); return; }
    var _L = esc__repeat(_T, "left", _in.left), _R = esc__repeat(_T, "right", _in.right), _U = esc__repeat(_T, "up", _in.up), _D = esc__repeat(_T, "down", _in.down);
    if (_T.mode == "board") {
        if (_L) esc__move_board(_T, -1, 0);
        else if (_R) esc__move_board(_T, 1, 0);
        else if (_U) esc__move_board(_T, 0, -1);
        else if (_D) esc__move_board(_T, 0, 1);
        else if (_in.ok) esc__act_on_arbor(_T, _T.cursor);
        else if (_in.cancel || _in.rclick) esc__leave(_T);
    } else {
        if (_L) esc__move_tray(_T, -1);
        else if (_R) esc__move_tray(_T, 1);
        else if (_in.ok) esc__place_from_tray(_T, _T.trayCursor);
        else if (_in.cancel || _in.rclick) { _T.mode = "board"; esc__sound(_T, "lift"); }
    }
}
/// internal: the nearest arbor within 60 degrees of the pressed direction (the MZ moveBoard)
function esc__move_board(_T, _dx, _dy) {
    var _pz = _T.pz, _A = _pz.arbors[_T.cursor], _best = -1, _bestS = 1000000000;
    for (var _i = 0; _i < array_length(_pz.arbors); _i++) {
        if (_i == _T.cursor) continue;
        var _vx = _pz.arbors[_i].x - _A.x, _vy = _pz.arbors[_i].y - _A.y, _along = _vx * _dx + _vy * _dy;
        if (_along <= 0) continue;
        var _across = abs(_vx * _dy - _vy * _dx);
        if (_across > _along * 1.8) continue;
        var _s = _along + _across * 2;
        if (_s < _bestS) { _bestS = _s; _best = _i; }
    }
    if (_best >= 0) { _T.cursor = _best; esc__sound(_T, "cursor"); }
}
function esc__move_tray(_T, _dir) {
    var _n = array_length(_T.pz.tray);
    for (var _s = 1; _s <= _n; _s++) { var _t = (_T.trayCursor + _dir * _s + _n * 4) mod _n; if (_T.wheelArbor[_t] < 0) { _T.trayCursor = _t; esc__sound(_T, "cursor"); return; } }
}
function esc__first_free(_T) { for (var _t = 0; _t < array_length(_T.pz.tray); _t++) if (_T.wheelArbor[_t] < 0) return _t; return -1; }
function esc__act_on_arbor(_T, _a) {
    if (_T.placed[_a] >= 0) { _T.placed[_a] = -1; _T.moves++; esc__sound(_T, "lift"); esc__refresh(_T, false); return; }
    var _t = (_T.wheelArbor[_T.trayCursor] < 0) ? _T.trayCursor : esc__first_free(_T);
    if (_t < 0) { esc__refuse(_T, "Every wheel is already set."); return; }
    _T.trayCursor = _t; _T.mode = "tray"; esc__sound(_T, "cursor");
}
function esc__place_from_tray(_T, _t) {
    var _c = esc_can_place(_T.pz, _T.placed, _T.cursor, _t);
    if (!_c.ok) { esc__refuse(_T, esc__reason_text(_c.reason)); return; }
    _T.placed[_T.cursor] = _t; _T.moves++; _T.mode = "board";
    esc__sound(_T, "place");
    esc__refresh(_T, false);
    if (_T.ev.jam) esc__sound(_T, "refuse");
}
function esc__refuse(_T, _text) { _T.flash = 24; esc__sound(_T, "refuse"); esc__set_status(_T, _text, "bad"); }
function esc__on_touch(_T, _x, _y) {
    var _pz = _T.pz;
    if (_y >= ESC_TRAY_Y && _y <= ESC_TRAY_Y + ESC_TRAY_H) {
        var _t = floor((_x - ESC_PLATE_X - 8) / max(1, _T.slot));
        if (_t >= 0 && _t < array_length(_pz.tray) && _T.wheelArbor[_t] < 0) { _T.trayCursor = _t; if (_T.mode == "tray") esc__place_from_tray(_T, _t); }
        return;
    }
    var _best = -1, _bestD = 1000000000;
    for (var _a = 0; _a < array_length(_pz.arbors); _a++) {
        var _dd = point_distance(_x, _y, ESC_PLATE_X + _pz.arbors[_a].x, ESC_PLATE_Y + _pz.arbors[_a].y);
        var _reach = (_T.placed[_a] >= 0) ? esc_outer_r(_pz.tray[_T.placed[_a]].n) : 22;
        if (_dd <= _reach && _dd < _bestD) { _bestD = _dd; _best = _a; }
    }
    if (_best >= 0) { _T.cursor = _best; _T.mode = "board"; esc__act_on_arbor(_T, _best); }
}
function esc__leave(_T) {
    if (!_T.allowLeave) { esc__refuse(_T, "The mechanism must be finished first."); return; }
    esc__sound(_T, "lift");
    esc__close(_T, false);
}

/// @function esc_closed(puzzle)
/// @description True once the player has left the bench: after the payoff has run (solved) or on Escape (not solved).
/// Then read puzzle.result: { solved, placed, moves, seed, grade, payoff, metal, key } - hand `placed` back to esc_open to
/// carry on where the player left off.
/// @returns {Bool}
function esc_closed(_T) { return is_struct(_T) && _T[$ "closed"] == true; }

/// @function esc_free(puzzle)
/// @description Free every sprite the puzzle made. Call it in Step or Clean Up (never in a Draw event). Safe to call twice.
function esc_free(_T) {
    if (!is_struct(_T) || !is_array(_T[$ "wheelSpr"])) return;
    var _f = ["bench", "shadows", "tray", "driveSpr", "outputSpr", "driveGlint", "outputGlint", "hint", "warn", "cursorSpr", "statusSpr", "headingSpr"];
    for (var _i = 0; _i < array_length(_f); _i++) _T[$ _f[_i]] = esc__kill(_T[$ _f[_i]]);
    for (var _w = 0; _w < array_length(_T.wheelSpr); _w++) _T.wheelSpr[_w] = esc__kill(_T.wheelSpr[_w]);
    for (var _g = 0; _g < array_length(_T.glintSpr); _g++) _T.glintSpr[_g] = esc__kill(_T.glintSpr[_g]);
    var _P = _T.parts, _pn = variable_struct_get_names(_P);
    for (var _p = 0; _p < array_length(_pn); _p++) {
        var _v = _P[$ _pn[_p]];
        if (_pn[_p] == "arms" && is_array(_v)) { for (var _q = 0; _q < array_length(_v); _q++) _v[_q] = esc__kill(_v[_q]); }
        else if (_pn[_p] == "bolt" || _pn[_p] == "shut" || _pn[_p] == "drawn" || _pn[_p] == "hour" || _pn[_p] == "minute" || _pn[_p] == "sun" || _pn[_p] == "drum" || _pn[_p] == "weight") _P[$ _pn[_p]] = esc__kill(_v);
    }
    _T.built = false; _T.closed = true;
}

// ---------------------------------------------------------------------------------------------------------------
// Drawing a frame
// ---------------------------------------------------------------------------------------------------------------

/// @function esc_draw(puzzle, [x], [y], [scale])
/// @description Draw the scene with its top-left at (x, y) at scale (816 x 624 at scale 1). Call in Draw or Draw GUI; the
/// input is read relative to the same place.
function esc_draw(_T, _x = undefined, _y = undefined, _scale = undefined) {
    if (!is_struct(_T) || !_T[$ "built"]) return;
    if (is_numeric(_x)) _T.x = _x;
    if (is_numeric(_y)) _T.y = _y;
    if (is_numeric(_scale) && _scale > 0) _T.scale = _scale;
    var _pz = _T.pz, _P = _T.parts;
    var _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_multiply(matrix_build(_T.x, _T.y, 0, 0, 0, 0, _T.scale, _T.scale, 1), _mw));
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); gpu_set_texfilter(true);
    esc__spr(_T.leather, 0, 0);
    esc__spr(_T.bench, ESC_PLATE_X - ESC_PLATE_PAD, ESC_PLATE_Y - ESC_PLATE_PAD);
    esc__spr(_T.shadows, ESC_PLATE_X, ESC_PLATE_Y);
    // the payoff's moving parts (under the wheels, as the MZ adds them first)
    if (_pz.payoff == "lock") {
        esc__spr(_P.bolt, _P.boltX, _P.boltY);
        esc__spr(_P.drawnOn ? _P.drawn : _P.shut, _P.wx, _P.wy);
    } else if (_pz.payoff == "clock") {
        esc__spr(_P.hour, _P.cx, _P.cy, 1, 1, _P.hourRot);
        esc__spr(_P.minute, _P.cx, _P.cy, 1, 1, _P.minuteRot);
    } else if (_pz.payoff == "orrery") {
        for (var _i = 0; _i < 3; _i++) esc__spr(_P.arms[_i], _P.cx, _P.cy, 1, 1, _P.armRot[_i]);
        esc__spr(_P.sun, _P.cx, _P.cy, 1, 1, _P.sunRot);
    } else {
        // the rope: three one-pixel stripes from the drum to the weight
        var _rx = _P.cx - 1, _ry = _P.cy, _rh = max(1, _P.weightY - _ry - 4);
        draw_set_alpha(1);
        draw_rectangle_colour(_rx, _ry, _rx + 1, _ry + _rh, make_colour_rgb(44, 29, 16), make_colour_rgb(44, 29, 16), make_colour_rgb(44, 29, 16), make_colour_rgb(44, 29, 16), false);
        draw_rectangle_colour(_rx + 1, _ry, _rx + 2, _ry + _rh, make_colour_rgb(168, 132, 82), make_colour_rgb(168, 132, 82), make_colour_rgb(168, 132, 82), make_colour_rgb(168, 132, 82), false);
        draw_rectangle_colour(_rx + 2, _ry, _rx + 3, _ry + _rh, make_colour_rgb(75, 51, 27), make_colour_rgb(75, 51, 27), make_colour_rgb(75, 51, 27), make_colour_rgb(75, 51, 27), false);
        esc__spr(_P.weight, _P.cx, _P.weightY);
        esc__spr(_P.drum, _P.cx, _P.cy, 1, 1, _P.drumRot);
    }
    esc__spr(_T.tray, ESC_PLATE_X, ESC_TRAY_Y);
    var _ev = _T.ev;
    esc__spr(_T.driveSpr, ESC_PLATE_X + _pz.drive.x, ESC_PLATE_Y + _pz.drive.y, 1, 1, esc__wheel_angle(_T, 0));
    esc__spr(_T.outputSpr, ESC_PLATE_X + _pz.output.x, ESC_PLATE_Y + _pz.output.y, 1, 1, _ev.connected[1] ? esc__wheel_angle(_T, 1) : 0);
    for (var _w = 0; _w < array_length(_T.wheelSpr); _w++) {
        var _a = _T.wheelArbor[_w];
        if (_a >= 0) esc__spr(_T.wheelSpr[_w], ESC_PLATE_X + _pz.arbors[_a].x, ESC_PLATE_Y + _pz.arbors[_a].y, 1, 1, _ev.connected[2 + _a] ? esc__wheel_angle(_T, 2 + _a) : _T.restAngle[_w]);
        else esc__spr(_T.wheelSpr[_w], esc__tray_x(_T, _w), esc__tray_y(), 1, _T.trayScale[_w], _T.restAngle[_w]);
    }
    // the glints ADD light and never turn with the metal
    gpu_set_blendmode_ext(bm_one, bm_one);
    for (var _g = 0; _g < array_length(_T.glintSpr); _g++) { var _ga = _T.wheelArbor[_g]; if (_ga >= 0) esc__spr(_T.glintSpr[_g], ESC_PLATE_X + _pz.arbors[_ga].x, ESC_PLATE_Y + _pz.arbors[_ga].y); }
    esc__spr(_T.driveGlint, ESC_PLATE_X + _pz.drive.x, ESC_PLATE_Y + _pz.drive.y);
    esc__spr(_T.outputGlint, ESC_PLATE_X + _pz.output.x, ESC_PLATE_Y + _pz.output.y);
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    esc__spr(_T.hint, ESC_PLATE_X + _pz.output.x, ESC_PLATE_Y + _pz.output.y);
    if (_T.warnOn) {
        gpu_set_blendmode_ext(bm_one, bm_one);
        esc__spr(_T.warn, _T.warnX, _T.warnY, 1, _T.warnScale * (1 + 0.08 * sin(_T.frame * 0.25)));
        gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    }
    // the cursor: a loupe on the arbor, or on the tray socket
    var _pulse = 1 + 0.06 * sin(_T.frame * 0.12), _ca = (_T.flash > 0 && ((_T.flash >> 2) mod 2) == 0) ? 90 / 255 : 1;
    if (_T.mode == "board") {
        var _A = _pz.arbors[_T.cursor], _cr = (_T.placed[_T.cursor] >= 0) ? esc_outer_r(_pz.tray[_T.placed[_T.cursor]].n) + 6 : 17;
        esc__spr(_T.cursorSpr, ESC_PLATE_X + _A.x, ESC_PLATE_Y + _A.y, _ca, (_cr / 17) * _pulse / ESC_CURSOR_K);
    } else if (_T.mode == "tray") esc__spr(_T.cursorSpr, esc__tray_x(_T, _T.trayCursor), esc__tray_y(), _ca, (min(_T.slot, ESC_TRAY_H - 16) * 0.5 / 17) * _pulse / ESC_CURSOR_K);
    esc__spr(_T.headingSpr, 0, 10);
    esc__spr(_T.statusSpr, 0, ESC_PLATE_Y + _pz.plate.h + 8);
    gpu_pop_state();
    matrix_set(matrix_world, _mw);
}
