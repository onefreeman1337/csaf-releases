/// esc_core.gml - Escapement's rules: clockwork gear-train puzzles generated from a seed and solvable by construction, the
/// gear physics (who meshes, which way everything turns, whether the train jams) and the solver that proves it. Pure GML:
/// nothing here draws, and nothing uses the engine's random functions.
///
/// Escapement - Generated Clockwork Gear Puzzles, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// The RPG Maker MZ edition's EscapementCore.js, ported line for line and held to it by the in-engine suite (esc_selftest).
/// Units are PLATE UNITS (640 x 380): the scene draws them 1:1 as pixels.
///
/// Public functions (each documented below): esc_hash, esc_pitch_r, esc_outer_r, esc_relation, esc_intersect, esc_generate,
/// esc_can_place, esc_evaluate, esc_required_dir, esc_empty_placement, esc_solution_placement, esc_solve, esc_designs,
/// esc_payoff_ids, esc_metal_ids, esc_style_ids, esc_teeth.

#macro ESC_VERSION "1.0.0"
#macro ESC_PLATE_W 640
#macro ESC_PLATE_H 380
#macro ESC_PAYOFF_X 520
#macro ESC_MODULE 5
#macro ESC_MESH_TOL 2
#macro ESC_GAP 6
#macro ESC_POST_R 9

/// @function esc_teeth()
/// @returns {Array<Real>} the tooth counts a loose gear may have
function esc_teeth() { return [12, 14, 16, 18, 20, 22, 24, 28]; }
function esc__drive_teeth() { return [18, 20, 24]; }
function esc__output_teeth() { return [14, 16, 18]; }
/// @function esc_payoff_ids()
/// @returns {Array<String>} lock, clock, orrery, winch
function esc_payoff_ids() { return ["lock", "clock", "orrery", "winch"]; }
/// @function esc_metal_ids()
/// @returns {Array<String>} brass, steel, bronze, verdigris, gunmetal
function esc_metal_ids() { return ["brass", "steel", "bronze", "verdigris", "gunmetal"]; }
/// @function esc_style_ids()
/// @returns {Array<String>} the eight spoke styles
function esc_style_ids() { return ["disc", "spokes3", "spokes4", "spokes5", "spokes6", "curved", "holes", "cross"]; }
/// internal: the five grades (k = gears in the true train; trap = gears in the wrong-direction route; dead = dead-end arbors;
/// decoys = loose gears that belong nowhere; pool = the train's tooth counts)
function esc__grade(_g) {
    static _G = [undefined,
        { k: [3, 3], trap: 0, dead: 0, decoys: 1, pool: [18, 20, 22, 24, 28] },
        { k: [3, 4], trap: 0, dead: 1, decoys: 1, pool: [16, 18, 20, 22, 24] },
        { k: [4, 4], trap: 1, dead: 1, decoys: 1, pool: [14, 16, 18, 20, 22, 24] },
        { k: [4, 5], trap: 1, dead: 2, decoys: 2, pool: [12, 14, 16, 18, 20, 22] },
        { k: [5, 6], trap: 2, dead: 2, decoys: 2, pool: [12, 14, 16, 18, 20] }];
    return _G[_g];
}

// ---------------------------------------------------------------------------------------------------------------
// Deterministic randomness (the MZ edition's, exact)
// ---------------------------------------------------------------------------------------------------------------

/// @function esc__imul(a, b)
/// @description Internal. JavaScript's Math.imul on unsigned 32-bit values, as int64 halves.
function esc__imul(_a, _b) {
    var _m = int64($FFFFFFFF);
    _a = int64(_a) & _m; _b = int64(_b) & _m;
    var _lo = (_a * (_b & int64($FFFF))) & _m;
    var _hi = ((_a * (_b >> 16)) & int64($FFFF)) << 16;
    return (_lo + _hi) & _m;
}
/// @function esc__u32(v)
/// @description Internal. JavaScript's (v >>> 0): truncated toward zero, then modulo 2^32; not a number -> 0.
function esc__u32(_v) {
    if (!is_numeric(_v) || is_nan(_v) || is_infinity(_v)) return int64(0);
    return int64(_v) & int64($FFFFFFFF);
}
/// @function esc_hash(text)
/// @description A stable unsigned 32-bit FNV-1a hash of a string (as the MZ edition), so a key like "m3e12" becomes a seed.
/// @returns {Real}
function esc_hash(_s) {
    var _t = is_string(_s) ? _s : string(_s);
    var _h = int64($811c9dc5);
    for (var _i = 1; _i <= string_length(_t); _i++) { _h = _h ^ int64(ord(string_char_at(_t, _i)) & $FFFF); _h = esc__imul(_h, $01000193); }
    return real(_h);
}
/// @function esc__rng(seed)
/// @description Internal. mulberry32 as a struct { a }; draw with esc__rng_next. The ONLY source of randomness.
function esc__rng(_seed) { return { a: esc__u32(_seed) }; }
/// @function esc__rng_next(rng)
/// @description Internal. The next draw in [0, 1).
function esc__rng_next(_r) {
    var _m = int64($FFFFFFFF);
    _r.a = (_r.a + int64($6D2B79F5)) & _m;
    var _t = _r.a;
    _t = esc__imul(_t ^ (_t >> 15), _t | 1);
    var _x = esc__imul(_t ^ (_t >> 7), _t | 61);
    _t = _t ^ ((_t + _x) & _m);
    return real((_t ^ (_t >> 14)) & _m) / 4294967296;
}
function esc__pick(_r, _a) { var _n = array_length(_a); return _a[floor(esc__rng_next(_r) * _n) mod _n]; }
function esc__range(_r, _lo, _hi) { return _lo + (_hi - _lo) * esc__rng_next(_r); }

// ---------------------------------------------------------------------------------------------------------------
// Gear geometry
// ---------------------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------------------
// Guards: every documented call REFUSES (returns its neutral value) rather than throwing inside the caller's event when
// handed something that is not a number, a puzzle or a placement. GML resolves a field read on a non-struct against the
// CALLING INSTANCE, so an unguarded read would surface in your project as "Variable obj_yours.<our field> not set".
// ---------------------------------------------------------------------------------------------------------------

function esc__num(_v) { return is_numeric(_v) && !is_nan(_v) && !is_infinity(_v); }
/// internal: true for a struct esc_generate made (the fields every rule reads)
function esc__is_puzzle(_p) {
    return is_struct(_p) && is_array(_p[$ "arbors"]) && is_array(_p[$ "tray"]) && is_array(_p[$ "solution"]) && is_struct(_p[$ "drive"]) && is_struct(_p[$ "output"]) && esc__num(_p[$ "k"]);
}
/// internal: true for a placement of this puzzle: one number per arbor (-1 or a tray index)
function esc__is_placement(_pz, _pl) {
    if (!is_array(_pl) || array_length(_pl) != array_length(_pz.arbors)) return false;
    var _n = array_length(_pz.tray);
    for (var _i = 0; _i < array_length(_pl); _i++) { var _v = _pl[_i]; if (!esc__num(_v) || _v != floor(_v) || _v < -1 || _v >= _n) return false; }
    return true;
}
function esc__neutral_eval() { return { nodes: [], edges: [], connected: [false, false], jam: false, jamEdge: undefined, outputDir: 0, requiredDir: 1, solved: false, wrongWay: false, s: [0, 0], b: [0, 0] }; }

/// @function esc_pitch_r(teeth)
/// @returns {Real} the pitch radius (teeth x module / 2); 0 for anything that is not a number
function esc_pitch_r(_n) { if (!esc__num(_n)) return 0; return _n * ESC_MODULE / 2; }
/// @function esc_outer_r(teeth)
/// @returns {Real} the radius at the tips of the teeth; 0 for anything that is not a number
function esc_outer_r(_n) { if (!esc__num(_n)) return 0; return esc_pitch_r(_n) + ESC_MODULE; }
function esc__dist(_ax, _ay, _bx, _by) { var _dx = _bx - _ax, _dy = _by - _ay; return sqrt(_dx * _dx + _dy * _dy); }

/// @function esc_relation(ax, ay, na, bx, by, nb)
/// @description How two gears relate: "mesh" (centre distance = the sum of pitch radii, within 2), "collide" (their
/// teeth overlap) or "free" ("free" too for anything that is not six numbers).
/// @returns {String}
function esc_relation(_ax, _ay, _na, _bx, _by, _nb) {
    if (!esc__num(_ax) || !esc__num(_ay) || !esc__num(_na) || !esc__num(_bx) || !esc__num(_by) || !esc__num(_nb)) return "free";
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _r = esc__relation(_ax, _ay, _na, _bx, _by, _nb);
    math_set_epsilon(_eps);
    return _r;
}
/// internal: esc_relation without the guard (the rules call it in their inner loops)
function esc__relation(_ax, _ay, _na, _bx, _by, _nb) {
    var _d = esc__dist(_ax, _ay, _bx, _by);
    if (abs(_d - (esc_pitch_r(_na) + esc_pitch_r(_nb))) <= ESC_MESH_TOL) return "mesh";
    if (_d < esc_outer_r(_na) + esc_outer_r(_nb) + 1) return "collide";
    return "free";
}

/// @function esc_intersect(ax, ay, ra, bx, by, rb)
/// @description Circle-circle intersection: the points at distance ra from A and rb from B (zero or two { x, y }).
/// @returns {Array<Struct>}
function esc_intersect(_ax, _ay, _ra, _bx, _by, _rb) {
    if (!esc__num(_ax) || !esc__num(_ay) || !esc__num(_ra) || !esc__num(_bx) || !esc__num(_by) || !esc__num(_rb)) return [];
    var _d = esc__dist(_ax, _ay, _bx, _by);
    if (_d > _ra + _rb || _d < abs(_ra - _rb) || _d == 0) return [];
    var _a = (_ra * _ra - _rb * _rb + _d * _d) / (2 * _d);
    var _h2 = _ra * _ra - _a * _a;
    if (_h2 < 0) return [];
    var _h = sqrt(_h2);
    var _mx = _ax + _a * (_bx - _ax) / _d, _my = _ay + _a * (_by - _ay) / _d;
    return [{ x: _mx + _h * (_by - _ay) / _d, y: _my - _h * (_bx - _ax) / _d }, { x: _mx - _h * (_by - _ay) / _d, y: _my + _h * (_bx - _ax) / _d }];
}

// ---------------------------------------------------------------------------------------------------------------
// Generation
// ---------------------------------------------------------------------------------------------------------------

function esc__in_bounds(_x, _y, _n, _allowPayoff) {
    var _R = esc_outer_r(_n) + 4;
    if (_x - _R < 0 || _y - _R < 0 || _y + _R > ESC_PLATE_H) return false;
    if (_x + _R > (_allowPayoff ? ESC_PLATE_W : ESC_PAYOFF_X)) return false;
    return true;
}
/// internal: a candidate gear must stay CLEAR of `others` ([{x,y,n}]) and of arbor `posts` ([{x,y}])
function esc__clear_of(_x, _y, _n, _others, _posts) {
    for (var _i = 0; _i < array_length(_others); _i++) { var _o = _others[_i]; if (esc__dist(_x, _y, _o.x, _o.y) < esc_outer_r(_n) + esc_outer_r(_o.n) + ESC_GAP) return false; }
    for (var _j = 0; _j < array_length(_posts); _j++) if (esc__dist(_x, _y, _posts[_j].x, _posts[_j].y) < esc_outer_r(_n) + ESC_POST_R + 2) return false;
    return true;
}
function esc__copy(_a) { var _b = array_create(array_length(_a)); for (var _i = 0; _i < array_length(_a); _i++) _b[_i] = _a[_i]; return _b; }
/// internal: `list` without the given struct references (JavaScript's filter(o => o !== a && o !== b))
function esc__without(_list, _a, _b = undefined) { var _o = []; for (var _i = 0; _i < array_length(_list); _i++) { var _e = _list[_i]; if (_e != _a && (is_undefined(_b) || _e != _b)) array_push(_o, _e); } return _o; }
function esc__index_of(_a, _v) { for (var _i = 0; _i < array_length(_a); _i++) if (_a[_i] == _v) return _i; return -1; }

/// internal: lay a train of k loose gears from `from` to `to`, meshing each with the next, clear of `avoid`; the last gear is
/// placed EXACTLY by circle intersection. Returns the loose gears in order, or undefined.
function esc__lay_train(_r, _from, _to, _k, _pool, _avoid) {
    var _chain = [], _cur = _from;
    for (var _i = 0; _i < _k - 1; _i++) {
        var _ok = false;
        for (var _t = 0; _t < 30 && !_ok; _t++) {
            var _n = esc__pick(_r, _pool);
            var _want = arctan2(_to.y - _cur.y, _to.x - _cur.x);
            var _left = _k - 1 - _i;
            var _reach = esc__dist(_cur.x, _cur.y, _to.x, _to.y);
            var _span = esc_pitch_r(_cur.n) + esc_pitch_r(_n);
            var _slack = (_reach - _span) - 0;
            var _budget = _left * 2 * esc_pitch_r(_pool[array_length(_pool) - 1]) + esc_pitch_r(_to.n);
            var _wander = max(0.15, min(1.25, ((_budget - _slack) > 0) ? 0.35 + 0.9 * max(0, 1 - _slack / max(1, _budget)) : 0.2));
            var _ang = _want + esc__range(_r, -_wander, _wander);
            var _x = _cur.x + _span * cos(_ang);
            var _y = _cur.y + _span * sin(_ang);
            if (!esc__in_bounds(_x, _y, _n, false)) continue;
            var _others = esc__copy(_avoid);
            for (var _c = 0; _c < array_length(_chain) - 1; _c++) array_push(_others, _chain[_c]);
            if (array_length(_chain) != 0) array_push(_others, _from);
            if (!esc__clear_of(_x, _y, _n, esc__without(_others, _cur), [])) continue;
            if (esc__dist(_x, _y, _to.x, _to.y) < esc_outer_r(_n) + esc_outer_r(_to.n) + ESC_GAP) continue;
            var _g = { x: _x, y: _y, n: _n };
            array_push(_chain, _g);
            _cur = _g;
            _ok = true;
        }
        if (!_ok) return undefined;
    }
    // the closer meshes BOTH the last gear and `to`
    var _sizes = esc__copy(_pool);
    for (var _s = array_length(_sizes) - 1; _s > 0; _s--) { var _q = floor(esc__rng_next(_r) * (_s + 1)), _tmp = _sizes[_s]; _sizes[_s] = _sizes[_q]; _sizes[_q] = _tmp; }
    for (var _si = 0; _si < array_length(_sizes); _si++) {
        var _nn = _sizes[_si];
        var _pts = esc_intersect(_cur.x, _cur.y, esc_pitch_r(_cur.n) + esc_pitch_r(_nn), _to.x, _to.y, esc_pitch_r(_to.n) + esc_pitch_r(_nn));
        if (esc__rng_next(_r) < 0.5) _pts = array_reverse(_pts);
        for (var _pi = 0; _pi < array_length(_pts); _pi++) {
            var _p = _pts[_pi];
            if (!esc__in_bounds(_p.x, _p.y, _nn, false)) continue;
            var _others2 = esc__copy(_avoid);
            for (var _c2 = 0; _c2 < array_length(_chain) - 1; _c2++) array_push(_others2, _chain[_c2]);
            if (array_length(_chain) > 0) array_push(_others2, _from);
            _others2 = esc__without(_others2, _cur, _to);
            if (!esc__clear_of(_p.x, _p.y, _nn, _others2, [])) continue;
            array_push(_chain, { x: _p.x, y: _p.y, n: _nn });
            return _chain;
        }
    }
    return undefined;
}

/// @function esc_generate(options)
/// @description Generate one puzzle: { seed (a number; use esc_hash for a word), grade 1..5, payoff, metal }. The true train
/// is laid first and the puzzle built around it, so a generated puzzle cannot be unsolvable. Returns plain data: { v,
/// plate, drive, output, arbors [{x,y,kind}], tray [{n,style,kind}], solution [{arbor,tray}], trap, k, seed, grade,
/// attempt, payoff, metal } - or undefined (with a message in the output log) when no layout was found in 400 attempts.
/// @returns {Struct|Undefined}
function esc_generate(_opt) {
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _p = esc__generate(_opt);
    math_set_epsilon(_eps);
    return _p;
}
function esc__generate(_opt) {
    if (!is_struct(_opt)) _opt = {};
    var _go = _opt[$ "grade"], _gn = (is_numeric(_go) && !is_nan(_go) && !is_infinity(_go) && _go != 0) ? _go : 2;
    var _grade = max(1, min(5, floor(_gn + 0.5)));
    var _so = _opt[$ "seed"];
    var _seed = real(esc__u32(is_numeric(_so) ? _so : 0));
    var _G = esc__grade(_grade);
    for (var _attempt = 0; _attempt < 400; _attempt++) {
        var _r = esc__rng(real((int64(_seed) ^ esc__imul(_attempt + 1, $9E3779B1)) & int64($FFFFFFFF)));
        var _p = esc__try_generate(_r, _grade, _G);
        if (is_struct(_p)) {
            _p.seed = _seed; _p.grade = _grade; _p.attempt = _attempt;
            var _r2 = esc__rng(real((int64(_seed) ^ int64($A5A5A5A5)) & int64($FFFFFFFF)));
            var _po = _opt[$ "payoff"], _mo = _opt[$ "metal"];
            _p.payoff = (is_string(_po) && esc__index_of(esc_payoff_ids(), _po) >= 0) ? _po : esc__pick(_r2, esc_payoff_ids());
            _p.metal = (is_string(_mo) && esc__index_of(esc_metal_ids(), _mo) >= 0) ? _mo : esc__pick(_r2, esc_metal_ids());
            return _p;
        }
    }
    show_debug_message("Escapement: no layout for seed " + string(_seed) + " grade " + string(_grade));
    return undefined;
}

function esc__try_generate(_r, _grade, _G) {
    var _dx0 = esc__range(_r, 74, 104), _dy0 = esc__range(_r, 120, 260), _dn0 = esc__pick(_r, esc__drive_teeth());
    var _drive = { x: _dx0, y: _dy0, n: _dn0, role: "drive" };
    var _ox0 = esc__range(_r, 450, 470), _oy0 = esc__range(_r, 110, 270), _on0 = esc__pick(_r, esc__output_teeth());
    var _output = { x: _ox0, y: _oy0, n: _on0, role: "output" };
    if (!esc__in_bounds(_drive.x, _drive.y, _drive.n, false)) return undefined;
    if (!esc__in_bounds(_output.x, _output.y, _output.n, true)) return undefined;
    var _k = _G.k[0] + floor(esc__rng_next(_r) * (_G.k[1] - _G.k[0] + 1));
    var _train = esc__lay_train(_r, _drive, _output, _k, _G.pool, []);
    if (is_undefined(_train)) return undefined;
    var _nt = array_length(_train);
    for (var _i = 0; _i < _nt; _i++) {
        if (_i > 0 && esc__relation(_train[_i].x, _train[_i].y, _train[_i].n, _drive.x, _drive.y, _drive.n) != "free") return undefined;
        if (_i < _nt - 1 && esc__relation(_train[_i].x, _train[_i].y, _train[_i].n, _output.x, _output.y, _output.n) != "free") return undefined;
        for (var _j = _i + 2; _j < _nt; _j++) if (esc__relation(_train[_i].x, _train[_i].y, _train[_i].n, _train[_j].x, _train[_j].y, _train[_j].n) != "free") return undefined;
    }
    var _arbors = [], _tray = [];
    for (var _a0 = 0; _a0 < _nt; _a0++) { array_push(_arbors, { x: _train[_a0].x, y: _train[_a0].y, kind: "train" }); array_push(_tray, { n: _train[_a0].n, kind: "train" }); }
    var _solid = [_drive, _output];
    for (var _s0 = 0; _s0 < _nt; _s0++) array_push(_solid, _train[_s0]);

    // --- the trap: a second route of the WRONG parity from a train gear (or the drive) to the output
    var _trapInfo = undefined;
    if (_G.trap > 0) {
        for (var _tt = 0; _tt < 40 && is_undefined(_trapInfo); _tt++) {
            var _a = (_G.trap == 2) ? ((esc__rng_next(_r) < 0.5) ? 1 : 2) : 1;
            var _j0 = floor(esc__rng_next(_r) * _nt);
            var _from = (_j0 == 0) ? _drive : _train[_j0 - 1];
            var _viaTrue = _k - _j0;
            if (((_viaTrue - _a) mod 2) == 0) { _a = (_a == 1) ? 2 : 1; if (_a > 2) continue; }
            if (((_viaTrue - _a) mod 2) == 0) continue;
            var _avoid = esc__without(_solid, _from, _output);
            var _alt = esc__lay_train(_r, _from, _output, _a, _G.pool, _avoid);
            if (is_undefined(_alt)) continue;
            var _fine = true;
            for (var _q = 0; _q < array_length(_alt) && _fine; _q++) {
                for (var _pp = 0; _pp < array_length(_arbors); _pp++) {
                    if (esc__dist(_alt[_q].x, _alt[_q].y, _arbors[_pp].x, _arbors[_pp].y) < esc_outer_r(_alt[_q].n) + ESC_POST_R + 2) { _fine = false; break; }
                }
                if (esc__dist(_alt[_q].x, _alt[_q].y, _drive.x, _drive.y) < esc_outer_r(_alt[_q].n) + esc_outer_r(_drive.n) + ESC_GAP && _from != _drive) _fine = false;
            }
            if (!_fine) continue;
            _trapInfo = { from: _j0, gears: array_length(_alt) };
            for (var _z = 0; _z < array_length(_alt); _z++) { array_push(_arbors, { x: _alt[_z].x, y: _alt[_z].y, kind: "trap" }); array_push(_tray, { n: _alt[_z].n, kind: "trap" }); }
        }
        if (is_undefined(_trapInfo)) return undefined;
    }

    // --- dead ends: an arbor a real gear would mesh into, going nowhere
    var _deadMade = 0, _hosts = [_drive];
    for (var _h0 = 0; _h0 < _nt; _h0++) array_push(_hosts, _train[_h0]);
    for (var _dd = 0; _dd < 60 && _deadMade < _G.dead; _dd++) {
        var _host = esc__pick(_r, _hosts);
        var _dn = esc__pick(_r, _G.pool);
        var _ang = esc__range(_r, 0, pi * 2);
        var _dx = _host.x + (esc_pitch_r(_host.n) + esc_pitch_r(_dn)) * cos(_ang);
        var _dy = _host.y + (esc_pitch_r(_host.n) + esc_pitch_r(_dn)) * sin(_ang);
        if (!esc__in_bounds(_dx, _dy, _dn, false)) continue;
        if (!esc__clear_of(_dx, _dy, _dn, esc__without(_solid, _host), [])) continue;
        var _tooNear = false;
        for (var _ap = 0; _ap < array_length(_arbors); _ap++) if (esc__dist(_dx, _dy, _arbors[_ap].x, _arbors[_ap].y) < esc_outer_r(_dn) + ESC_POST_R + 6) _tooNear = true;
        if (_tooNear) continue;
        array_push(_arbors, { x: _dx, y: _dy, kind: "dead" });
        array_push(_tray, { n: _dn, kind: "dead" });
        _deadMade++;
    }
    if (_deadMade < _G.dead) return undefined;

    // --- decoys: loose gears that fit nowhere on purpose (or fit somewhere wrong)
    for (var _dc = 0; _dc < _G.decoys; _dc++) array_push(_tray, { n: esc__pick(_r, esc_teeth()), kind: "decoy" });

    // no solution gear may cover ANY arbor post but its own; no post under the drive or the output
    for (var _s1 = 0; _s1 < _nt; _s1++) for (var _s2 = 0; _s2 < array_length(_arbors); _s2++) {
        if (_s2 == _s1) continue;
        if (esc__dist(_train[_s1].x, _train[_s1].y, _arbors[_s2].x, _arbors[_s2].y) < esc_outer_r(_train[_s1].n) + ESC_POST_R + 2) return undefined;
    }
    for (var _s3 = 0; _s3 < array_length(_arbors); _s3++) {
        if (esc__dist(_drive.x, _drive.y, _arbors[_s3].x, _arbors[_s3].y) < esc_outer_r(_drive.n) + ESC_POST_R + 2) return undefined;
        if (esc__dist(_output.x, _output.y, _arbors[_s3].x, _arbors[_s3].y) < esc_outer_r(_output.n) + ESC_POST_R + 2) return undefined;
    }

    // styles: each tray gear its own spoke style; the tray ordered by size (then by original index)
    for (var _ty = 0; _ty < array_length(_tray); _ty++) _tray[_ty].style = esc__pick(_r, esc_style_ids());
    var _order = array_create(array_length(_tray));
    for (var _o0 = 0; _o0 < array_length(_tray); _o0++) _order[_o0] = _o0;
    array_sort(_order, method({ t: _tray }, function(_x, _y) { var _d = t[_x].n - t[_y].n; return (_d != 0) ? _d : _x - _y; }));
    var _sortedTray = [];
    for (var _o1 = 0; _o1 < array_length(_order); _o1++) array_push(_sortedTray, _tray[_order[_o1]]);
    var _solution = [];
    for (var _si = 0; _si < _nt; _si++) array_push(_solution, { arbor: _si, tray: esc__index_of(_order, _si) });
    // arbors shuffled so the train is not readable from the arbor order
    var _aord = array_create(array_length(_arbors));
    for (var _a1 = 0; _a1 < array_length(_arbors); _a1++) _aord[_a1] = _a1;
    for (var _sh = array_length(_aord) - 1; _sh > 0; _sh--) { var _w = floor(esc__rng_next(_r) * (_sh + 1)), _tt2 = _aord[_sh]; _aord[_sh] = _aord[_w]; _aord[_w] = _tt2; }
    var _shArbors = [];
    for (var _a2 = 0; _a2 < array_length(_aord); _a2++) { var _A = _arbors[_aord[_a2]]; array_push(_shArbors, { x: _A.x, y: _A.y, kind: _A.kind }); }
    for (var _s4 = 0; _s4 < array_length(_solution); _s4++) _solution[_s4].arbor = esc__index_of(_aord, _solution[_s4].arbor);
    var _outTray = [];
    for (var _o2 = 0; _o2 < array_length(_sortedTray); _o2++) array_push(_outTray, { n: _sortedTray[_o2].n, style: _sortedTray[_o2].style, kind: _sortedTray[_o2].kind });
    return {
        v: 1, plate: { w: ESC_PLATE_W, h: ESC_PLATE_H, payoffX: ESC_PAYOFF_X },
        drive: { x: _drive.x, y: _drive.y, n: _drive.n }, output: { x: _output.x, y: _output.y, n: _output.n },
        arbors: _shArbors, tray: _outTray, solution: _solution, trap: _trapInfo, k: _k
    };
}

// ---------------------------------------------------------------------------------------------------------------
// The train: who meshes, which way everything turns, and whether it jams
// ---------------------------------------------------------------------------------------------------------------

/// @function esc_can_place(puzzle, placed, arbor, tray_index)
/// @description Can this loose gear go on this arbor, given what is already placed (placed[arbor] = tray index or -1)?
/// Returns { ok, reason: "ok" | "occupied" | "in-use" | "collide" | "covers-post" | "under-gear", blocker } (blocker -2
/// the drive, -3 the output, >= 0 an arbor whose gear or post is in the way).
/// @returns {Struct}
function esc_can_place(_pz, _placed, _arbor, _ti) {
    if (!esc__is_puzzle(_pz) || !esc__is_placement(_pz, _placed) || !esc__num(_arbor) || !esc__num(_ti) || _arbor != floor(_arbor) || _ti != floor(_ti)
        || _arbor < 0 || _arbor >= array_length(_pz.arbors) || _ti < 0 || _ti >= array_length(_pz.tray)) return { ok: false, reason: "invalid", blocker: -1 };
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _c = esc__can_place(_pz, _placed, _arbor, _ti);
    math_set_epsilon(_eps);
    return _c;
}
function esc__can_place(_pz, _placed, _arbor, _ti) {
    if (_placed[_arbor] >= 0) return { ok: false, reason: "occupied", blocker: _arbor };
    for (var _a = 0; _a < array_length(_placed); _a++) if (_placed[_a] == _ti) return { ok: false, reason: "in-use", blocker: _a };
    var _A = _pz.arbors[_arbor], _n = _pz.tray[_ti].n, _fixed = [_pz.drive, _pz.output];
    for (var _f = 0; _f < 2; _f++) if (esc__relation(_A.x, _A.y, _n, _fixed[_f].x, _fixed[_f].y, _fixed[_f].n) == "collide") return { ok: false, reason: "collide", blocker: -2 - _f };
    for (var _b = 0; _b < array_length(_pz.arbors); _b++) {
        if (_b == _arbor) continue;
        var _B = _pz.arbors[_b];
        if (_placed[_b] >= 0) {
            if (esc__relation(_A.x, _A.y, _n, _B.x, _B.y, _pz.tray[_placed[_b]].n) == "collide") return { ok: false, reason: "collide", blocker: _b };
        } else if (esc__dist(_A.x, _A.y, _B.x, _B.y) < esc_outer_r(_n) + ESC_POST_R) {
            return { ok: false, reason: "covers-post", blocker: _b };
        }
        if (_placed[_b] >= 0 && esc__dist(_A.x, _A.y, _B.x, _B.y) < esc_outer_r(_pz.tray[_placed[_b]].n) + ESC_POST_R) return { ok: false, reason: "under-gear", blocker: _b };
    }
    return { ok: true, reason: "ok", blocker: -1 };
}

/// @function esc_evaluate(puzzle, placed)
/// @description Evaluate a placement. Node 0 is the drive, node 1 the output, node 2 + a is arbor a (undefined when
/// empty). Rotation spreads breadth-first from the drive; a mesh that asks a gear to turn both ways is a JAM. For every
/// connected node, s (turns per drive turn, signed) and b (phase): theta = s x theta_drive + b, so teeth interleave.
/// Returns { nodes, edges, connected, jam, jamEdge, outputDir, requiredDir, solved, wrongWay, s, b }.
/// @returns {Struct}
function esc_evaluate(_pz, _placed) {
    if (!esc__is_puzzle(_pz) || !esc__is_placement(_pz, _placed)) return esc__neutral_eval();
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _e = esc__evaluate(_pz, _placed);
    math_set_epsilon(_eps);
    return _e;
}
function esc__evaluate(_pz, _placed) {
    var _nodes = [{ x: _pz.drive.x, y: _pz.drive.y, n: _pz.drive.n, arbor: -1 }, { x: _pz.output.x, y: _pz.output.y, n: _pz.output.n, arbor: -1 }];
    for (var _a = 0; _a < array_length(_pz.arbors); _a++) {
        if (_placed[_a] >= 0) array_push(_nodes, { x: _pz.arbors[_a].x, y: _pz.arbors[_a].y, n: _pz.tray[_placed[_a]].n, arbor: _a });
        else array_push(_nodes, undefined);
    }
    var _N = array_length(_nodes), _adj = array_create(_N), _edges = [];
    for (var _i = 0; _i < _N; _i++) _adj[_i] = [];
    for (var _p = 0; _p < _N; _p++) {
        if (is_undefined(_nodes[_p])) continue;
        for (var _q = _p + 1; _q < _N; _q++) {
            if (is_undefined(_nodes[_q])) continue;
            if (esc__relation(_nodes[_p].x, _nodes[_p].y, _nodes[_p].n, _nodes[_q].x, _nodes[_q].y, _nodes[_q].n) == "mesh") { array_push(_adj[_p], _q); array_push(_adj[_q], _p); array_push(_edges, [_p, _q]); }
        }
    }
    var _s = array_create(_N, 0), _b = array_create(_N, 0), _seen = array_create(_N, false);
    _s[0] = 1; _b[0] = 0; _seen[0] = true;
    var _queue = [0], _qi = 0, _jam = false, _jamEdge = undefined;
    while (_qi < array_length(_queue)) {
        var _u = _queue[_qi]; _qi++;
        for (var _e = 0; _e < array_length(_adj[_u]); _e++) {
            var _v = _adj[_u][_e];
            var _ratio = _nodes[_u].n / _nodes[_v].n;
            var _sv = -_ratio * _s[_u];
            if (_seen[_v]) {
                if (sign(_s[_v]) != sign(_sv)) { _jam = true; if (is_undefined(_jamEdge)) _jamEdge = [_u, _v]; }
                continue;
            }
            var _phi = arctan2(_nodes[_v].y - _nodes[_u].y, _nodes[_v].x - _nodes[_u].x);
            _s[_v] = _sv;
            _b[_v] = _phi + pi + pi / _nodes[_v].n - _ratio * (_b[_u] - _phi);
            _seen[_v] = true;
            array_push(_queue, _v);
        }
    }
    var _outputDir = _seen[1] ? sign(_s[1]) : 0, _need = esc_required_dir(_pz);
    return { nodes: _nodes, edges: _edges, connected: _seen, jam: _jam, jamEdge: _jamEdge, outputDir: _outputDir, requiredDir: _need,
        solved: !_jam && _seen[1] && _outputDir == _need, wrongWay: !_jam && _seen[1] && _outputDir != _need, s: _s, b: _b };
}

/// @function esc_required_dir(puzzle)
/// @returns {Real} the direction the output must turn (+1 or -1): whatever the true train gives it
function esc_required_dir(_pz) { if (!esc__is_puzzle(_pz)) return 1; return ((_pz.k mod 2) == 1) ? 1 : -1; }
/// @function esc_empty_placement(puzzle)
/// @returns {Array<Real>} an empty placement (-1 on every arbor); [] for anything that is not a puzzle
function esc_empty_placement(_pz) { if (!esc__is_puzzle(_pz)) return []; return array_create(array_length(_pz.arbors), -1); }
/// @function esc_solution_placement(puzzle)
/// @returns {Array<Real>} the placement the puzzle was built from; [] for anything that is not a puzzle
function esc_solution_placement(_pz) { if (!esc__is_puzzle(_pz)) return []; var _a = esc_empty_placement(_pz); for (var _i = 0; _i < array_length(_pz.solution); _i++) _a[_pz.solution[_i].arbor] = _pz.solution[_i].tray; return _a; }

// ---------------------------------------------------------------------------------------------------------------
// Solver: grows the train from the drive one legal meshing gear at a time (the suite proves every puzzle solvable with it)
// ---------------------------------------------------------------------------------------------------------------

function esc__join(_a, _sep) { var _s = ""; for (var _i = 0; _i < array_length(_a); _i++) _s += ((_i > 0) ? _sep : "") + string(_a[_i]); return _s; }

/// @function esc_solve(puzzle, [limit])
/// @description Search every legal placement from the empty plate. Returns { solutions, trapStates, jamStates, nodes,
/// firstSolution, capped }.
/// @returns {Struct}
function esc_solve(_pz, _limit = 200000) {
    if (!esc__is_puzzle(_pz)) return { solutions: 0, trapStates: 0, jamStates: 0, nodes: 0, firstSolution: undefined, capped: false };
    if (!esc__num(_limit) || _limit < 1) _limit = 200000;
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _o = esc__solve(_pz, _limit);
    math_set_epsilon(_eps);
    return _o;
}
function esc__solve(_pz, _limit) {
    var _visited = {}, _out = { solutions: 0, trapStates: 0, jamStates: 0, nodes: 0, firstSolution: undefined, capped: false }, _sols = {};
    var _stack = [esc_empty_placement(_pz)];
    while (array_length(_stack) > 0) {
        var _placed = array_pop(_stack);
        var _key = esc__join(_placed, ",");
        if (variable_struct_exists(_visited, _key)) continue;
        _visited[$ _key] = true;
        _out.nodes++;
        if (_out.nodes > _limit) { _out.capped = true; break; }
        var _ev = esc__evaluate(_pz, _placed);
        if (_ev.jam) { _out.jamStates++; continue; }
        if (_ev.solved) {
            var _parts = [];
            for (var _i = 0; _i < array_length(_placed); _i++) if (_placed[_i] >= 0) array_push(_parts, string(_i) + ":" + string(_pz.tray[_placed[_i]].n));
            array_sort(_parts, true);
            var _sk = esc__join(_parts, "|");
            if (!variable_struct_exists(_sols, _sk)) { _sols[$ _sk] = true; _out.solutions++; if (is_undefined(_out.firstSolution)) _out.firstSolution = esc__copy(_placed); }
            continue;
        }
        if (_ev.wrongWay) _out.trapStates++;
        for (var _a = 0; _a < array_length(_pz.arbors); _a++) {
            if (_placed[_a] >= 0) continue;
            var _triedN = {};
            for (var _t = 0; _t < array_length(_pz.tray); _t++) {
                var _n = _pz.tray[_t].n;
                if (variable_struct_exists(_triedN, string(_n))) continue;
                if (esc__index_of(_placed, _t) >= 0) continue;
                var _c = esc__can_place(_pz, _placed, _a, _t);
                if (!_c.ok) continue;
                var _A = _pz.arbors[_a], _meshes = false;
                for (var _m = 0; _m < array_length(_ev.nodes) && !_meshes; _m++) {
                    if (is_undefined(_ev.nodes[_m]) || !_ev.connected[_m]) continue;
                    if (esc__relation(_A.x, _A.y, _n, _ev.nodes[_m].x, _ev.nodes[_m].y, _ev.nodes[_m].n) == "mesh") _meshes = true;
                }
                if (!_meshes) continue;
                _triedN[$ string(_n)] = true;
                var _nx = esc__copy(_placed); _nx[_a] = _t;
                array_push(_stack, _nx);
            }
        }
    }
    return _out;
}

/// @function esc_designs(puzzle)
/// @description The distinct things this puzzle draws: every loose gear design (teeth / style / metal) and the fixed pair.
/// @returns {Array<String>}
function esc_designs(_pz) {
    if (!esc__is_puzzle(_pz) || !is_string(_pz[$ "metal"]) || !is_string(_pz[$ "payoff"])) return [];
    var _d = [];
    var _add = function(_list, _k) { if (esc__index_of(_list, _k) < 0) array_push(_list, _k); };
    for (var _i = 0; _i < array_length(_pz.tray); _i++) _add(_d, string(_pz.tray[_i].n) + "/" + _pz.tray[_i].style + "/" + _pz.metal);
    _add(_d, "drive/" + string(_pz.drive.n) + "/" + _pz.metal);
    _add(_d, "output/" + string(_pz.output.n) + "/" + _pz.payoff + "/" + _pz.metal);
    return _d;
}
