# Escapement - Generated Clockwork Gear Puzzles, for GameMaker

A locked door is usually a switch and a line of text. Escapement turns it into a mechanism the player has to finish: a
brass plate with fixed arbors, a tray of loose wheels, a mainspring that drives, and a payoff that only moves when the
train is right.

- **Wheels mesh only when their sizes fit the gap** between two arbors, and every wheel turns the opposite way to the one
  driving it.
- **The payoff turns one way only.** Reach it the wrong way round and **the pawl holds**: the train stops and shakes.
- **Close a loop of an odd number of wheels and the whole train jams.** From grade 3 the plate hides a second route to
  the payoff that arrives turning the wrong way; fill both and it jams.
- **Every puzzle is generated from a seed, laid around a working train,** so it cannot be unsolvable. The same seed is the
  same puzzle on every machine. Five grades, from three wheels and one spare to six wheels, a trap route, two dead-end
  arbors and two spare wheels that fit nowhere.
- **Everything is drawn by the package.** The plate in one of five metals (brass, steel, bronze, verdigris, gunmetal) with
  a brushed finish, Geneva stripes, an engraved border and corner screws; jewelled arbors; wheels with 12 to 28 teeth in
  eight web styles (solid with index dots, three to six spokes, curved spokes, round windows, a cross), each with circular
  graining, a raised rim, a hub with screws and a timing mark, a cast shadow and a fixed glint; a mainspring barrel; and
  four payoffs, each with its own moving parts: a strongroom bolt with a keyhole escutcheon and a SHUT / DRAWN window, a
  tower clock whose hands wind round to the hour, an orrery whose planets come into conjunction, and a portcullis winch
  whose counterweight rises. No image file is loaded.

Ported from our RPG Maker MZ plugin Escapement and held to it: the in-engine suite runs the generator and the drawing
through both and checks they agree (see Verification).

## Install

1. In GameMaker, **Tools > Import Local Package**, choose `Escapement.yymps`, and import everything.
2. Run the project with `rm_esc_demo` first in the room order. The demo is THE CLOCKMAKER'S BENCH: four mechanisms (the
   strongroom lock, the tower clock, the orrery, the portcullis winch) at five grades. Choose one (arrows and Enter, or
   click) and finish its train. A solved mechanism lights a jewel on its card for that grade; a train you walk away from
   is kept and laid out again when you come back, the way your game's save would keep it.

Requires GameMaker 2024.14 or later. Built and tested on runtime 2024.14.4.268 (the VM, Windows). Pure GML, no shader, no
extension; nothing here depends on GMRT.

## Quickstart

```gml
// Create - open a puzzle (the same seed always gives the same puzzle)
my_puzzle = esc_open({ seed: "vault door", grade: 3, payoff: "lock" });

// Step - run it; when the player leaves, read the result
esc_step(my_puzzle);
if (esc_closed(my_puzzle)) {
    my_result = my_puzzle.result;     // { solved, placed, moves, seed, grade, payoff, metal, key }
    esc_free(my_puzzle);
    my_puzzle = undefined;
}

// Draw GUI - the scene is 816 x 624 at scale 1; draw it anywhere, at any scale
esc_draw(my_puzzle, 0, 0, 1);
```

`esc_open` generates the puzzle and draws every picture once (supersampled, filtered down) and keeps them as sprites, so
open a puzzle behind your own transition. **Call `esc_open` in Create or Step, never inside a Draw event or while a
surface is the render target** (it draws into its own surfaces). After that a frame turns a handful of sprites. The mouse
is read in GUI coordinates, relative to where you draw the scene. What a solved puzzle opens is your game's business:
`result.solved` says how it ended.

**Carrying on later.** When the player leaves without finishing, `result.placed` holds where every wheel was left. Keep it
(in your save) and hand it back to bring the train back as they left it:

```gml
my_puzzle = esc_open({ seed: "vault door", grade: 3, payoff: "lock", placed: my_result.placed });
```

A placement that does not fit the puzzle (another seed or grade) is ignored and the plate starts empty.

### The request

```gml
{ seed: "the north tower",    // a number or a word: the same puzzle every time; "" or absent: a new puzzle every time
  grade: 3,                   // 1 (easy) to 5 (hard); default 2
  payoff: "clock",            // "lock", "clock", "orrery", "winch" or "auto" (chosen by the seed); default "lock"
  metal: "verdigris",         // "brass", "steel", "bronze", "verdigris", "gunmetal" or "auto" (default: by the seed)
  title: "The Bell Tower",    // the name above the plate; blank names it after the payoff
  placed: undefined,          // an earlier result.placed, to carry on where the player left off
  allow_leave: true,          // false: Escape is refused until the train is complete
  drive_speed: 1.2,           // how fast the mainspring turns, degrees per step (0.1 to 5)
  sound: my_sound_hook,       // optional: function(name) called with "place", "lift", "refuse", "solve", "cursor"
  key: "chapter2|vault" }     // optional: yours, handed back in the result
```

### What the grades mean

| Grade | Wheels in the true train | Wrong-way trap route | Dead-end arbors | Spare wheels |
| --- | --- | --- | --- | --- |
| 1 | 3 | none | 0 | 1 |
| 2 | 3 to 4 | none | 1 | 1 |
| 3 | 4 | 1 to 2 wheels | 1 | 1 |
| 4 | 4 to 5 | 1 to 2 wheels | 2 | 2 |
| 5 | 5 to 6 | 1 to 2 wheels | 2 | 2 |

### Controls

- **Arrow keys** move the loupe between arbors. **Enter / Space / Z** on an empty arbor opens the tray; **Left / Right**
  choose a wheel; **Enter** sets it. **Enter** on a set wheel lifts it back into the tray.
- **Escape / Backspace / X / right click** leaves (the wheels stay where they were), or closes the tray.
- **Mouse or touch**: click an arbor, then click a wheel in the tray. On mobile exports a first finger reads as
  GameMaker's mouse (device 0); we have only built and tested Windows.

## Reference

**The scene** (`esc_open` once, then every frame `esc_step` in Step and `esc_draw` in Draw or Draw GUI)
- `esc_open(request)` - generate the puzzle and lay out the bench; returns the puzzle struct (undefined, with a message in
  the output log, when the request is not a struct).
- `esc_step(puzzle, [mouse_x], [mouse_y])` - one step: input, the train turning, the payoff, the cursor and the ending.
  Pass your own mouse position (in the same coordinates you draw in) if you do not draw in the GUI layer.
- `esc_draw(puzzle, [x], [y], [scale])` - draw it with its top-left at (x, y).
- `esc_closed(puzzle)` - true once the player has left: after the payoff has run (solved), or on Escape.
- `esc_free(puzzle)` - free every sprite it made (in Step or Clean Up, never in a Draw event). Safe to call twice.
- `esc_forget_bench()` - the leather bench under the plate is the same for every puzzle, so `esc_open` draws it once per
  game run and keeps it (one 816 x 624 sprite); this frees it. The next `esc_open` draws it again.
- `esc_title_for(payoff)`, `esc_goal(payoff)` - the default title ("The Tower Clock") and the goal ("the hands turn
  true") for a payoff.
- Fields you may set: `puzzle.inject` (scripted input for one step, in scene coordinates: `{ x, y, click: true }`,
  `{ ok: true }`, `{ cancel: true }`, `{ left / right / up / down: true }` - for a tutorial or a replay).
- `puzzle.result` - `{ solved, placed, moves, seed, grade, payoff, metal, key }`.

**The rules on their own** (pure GML, no drawing)
- `esc_generate({ seed, grade, payoff, metal })` - a puzzle as plain data: `{ plate, drive, output, arbors, tray,
  solution, trap, k, seed, grade, attempt, payoff, metal }` (arbors `{ x, y, kind }`, tray wheels `{ n, style, kind }`;
  kinds are "train", "trap", "dead" and "decoy").
- `esc_evaluate(puzzle, placed)` - who meshes, which way everything turns and whether it jams: `{ solved, jam, wrongWay,
  connected, outputDir, requiredDir, s, b, ... }`. For every turning wheel, `angle = s * drive_angle + b` keeps the teeth
  interleaved.
- `esc_can_place(puzzle, placed, arbor, tray_index)` - `{ ok, reason, blocker }`; reasons "occupied", "in-use",
  "collide", "covers-post", "under-gear" (and "invalid" for arguments that are not a puzzle and a placement).
- `esc_solve(puzzle, [limit])` - search every legal placement: `{ solutions, trapStates, jamStates, nodes,
  firstSolution, capped }`.
- `esc_empty_placement(puzzle)`, `esc_solution_placement(puzzle)`, `esc_required_dir(puzzle)`.
- `esc_hash(text)` - the 32-bit seed of a word. `esc_designs(puzzle)` - the distinct wheel designs a puzzle draws.
- `esc_pitch_r(teeth)`, `esc_outer_r(teeth)`, `esc_relation(ax, ay, na, bx, by, nb)` ("mesh", "collide", "free"),
  `esc_intersect(ax, ay, ra, bx, by, rb)`.
- `esc_teeth()`, `esc_payoff_ids()`, `esc_metal_ids()`, `esc_style_ids()` - the vocabularies.

**Drawing directly** (into an `esc_cx_create(scale)` context, onto whatever SURFACE is the current target). If you will
draw that surface somewhere else afterwards, set `gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one,
bm_inv_src_alpha)` before drawing into it (the package's own pictures are drawn this way). Metals are passed by name.
- `esc_draw_gear(ctx, { n, module, style, metal, role })` - one wheel centred on the origin (role "loose", "drive" or
  "output"). `esc_draw_shadow(ctx, x, y, radius, strength)`, `esc_draw_glint(ctx, radius, metal)`.
- `esc_draw_bench(ctx, w, h, metal)`, `esc_draw_plate(ctx, puzzle, title)`, `esc_draw_arbor(ctx, x, y, metal)`,
  `esc_draw_payoff_base(ctx, puzzle)` (returns where its moving parts go), `esc_draw_tray(ctx, w, h, count, metal)`.
- The payoffs' moving parts, each drawn at the origin: `esc_draw_bolt(ctx, length, metal)`,
  `esc_draw_hand(ctx, length, width, metal, counter)`, `esc_draw_planet_arm(ctx, length, radius, rgb, metal)`,
  `esc_draw_sun(ctx, radius)`, `esc_draw_drum(ctx, radius, metal)`, `esc_draw_weight(ctx, metal)`.
- The marks and words: `esc_draw_turn_arrow(ctx, x, y, radius, dir, metal, label, at)`,
  `esc_draw_turn_hint(ctx, radius, dir, label, at)`, `esc_clear_side(puzzle, x, y, radius, other, max_loose_radius,
  x_max)` (the side of a wheel no loose wheel can cover), `esc_draw_cursor(ctx, radius)`, `esc_draw_warning(ctx,
  radius)`, `esc_draw_window_word(ctx, word, good)`, `esc_draw_heading(ctx, w, title, grade)`,
  `esc_draw_status(ctx, w, text, tone)` (tone "", "good" or "bad"; the heading and the status line CLEAR their band
  first, as the MZ edition draws each on its own bitmap, so draw them into a surface of their own),
  `esc_engrave(ctx, text, x, y, size, metal, align,
  weight)`, `esc_jewel(ctx, x, y, size)`, `esc_tooth_path(ctx, teeth, module)` (a wheel's tooth outline as a path).
- `esc_metal(name)` (a metal's colours as [r, g, b]) and `esc_accent(name)` (the second alloy its payoff is cut in).

**The demo room** - `esc_demo_create()`, `esc_demo_step(demo)`, `esc_demo_draw(demo)`, `esc_demo_free(demo)`,
`esc_demo_cards()`: THE CLOCKMAKER'S BENCH, the same four calls in `obj_esc_demo`.

## Performance

Measured on our test machine, a shared and busy one (runtime 2024.14.4.268, the VM, Windows). Yours will differ.

- **Opening a puzzle costs about 2 to 2.5 s** (2,392 ms for the first puzzle of a run at grade III and 2,027 ms for a
  grade V puzzle in the last run): the plate (about 1 s) and every wheel (about 0.8 s) are drawn once at twice the size,
  filtered down and kept as sprites. The leather bench under the plate is drawn once per game run and kept (see
  `esc_forget_bench`). Open behind your own transition: the demo shows a "Winding the mainspring" card for a frame first.
- **After that a frame is cheap**: a step plus a draw cost about 0.2 ms in the last run (sprites turned, nothing
  redrawn); the train is evaluated again only when a wheel moves.
- **The rules alone are quick**: `esc_generate` about 10 ms a puzzle, `esc_solve` about 20 ms on average over 40
  puzzles of every grade.

## Fonts

The bench is lettered in two faces rasterised into font resources: Cinzel Bold (the payoff names, the window words) and
Alegreya (the rest), both SIL Open Font License 1.1. The licence texts and the notices are in `Escapement/fonts/`. The
atlases carry printable ASCII (32 to 126) and the middle dot; any other character is measured as nothing and not drawn.

## Differences from the RPG Maker MZ edition

- **Saving is yours.** The MZ edition writes solved puzzles and half-set trains into the RPG Maker save; here the scene
  hands back `result.placed` and takes it back as `placed`, so you keep it in your own save however you like.
- **Sounds are a hook** (`sound(name)`) instead of RPG Maker sound-effect names; the package plays nothing itself.
- **The plugin parameters are request fields** (`grade`, `metal`, `drive_speed`, `allow_leave`), and the scene is a
  struct you step and draw rather than a scene the engine pushes.
- **Type.** The MZ edition sets its words in Palatino Linotype, a system font no package may ship; this one ships Cinzel
  Bold and Alegreya, and its italic lines are the upright Alegreya struck at a 12 degree slant (no italic face is
  included). The heading's title, a gradient in the MZ edition, is set in the gradient's light colour.
- **The loupe cursor** is drawn at five times its size and scaled down, so it stays smooth round the largest wheels (the
  MZ edition scales a small drawing up).
- **The bench's stitched border** is drawn as a dashed path, the same look; and a direct `esc_draw_payoff_base` call with
  a payoff name it does not know draws nothing (the MZ edition draws the winch).

Every other mark is the MZ edition's drawing, operation for operation (see Verification).

## Verification

GameMaker code cannot be unit-tested outside the engine, so everything below ran in real executables built by GameMaker's
own compiler (Igor, runtime 2024.14.4.268):

- **The rules, held to the RPG Maker MZ edition run in Node:** the seed hash on 8 words, 60 generator draws (exact), 300
  generated puzzles compared field for field (every grade; odd seeds and grades included: negative, fractional, huge,
  zero, out of range, not a number), 60 gear relations, 6 circle intersections, 300 scripted placements through
  `esc_evaluate` (solved, jammed and wrong-way trains, every wheel's turn ratio and phase), 10,552 `esc_can_place` checks
  on 100 puzzles, and the solver node for node on 40 puzzles. Every puzzle solvable; 386 distinct wheel designs across
  the 300.
- **The drawing, held to the MZ edition's drawing code run over a recording canvas:** 243 drawings (every tooth count x
  every web style, the five metals, drive and output wheels, plates, arbors, arrows and hints, the four payoffs and their
  moving parts, trays, words, the heading and status lines) - 16,173 paint operations, each compared for its colour or
  gradient, line width, path, transform and order - plus 235 layout values (which side a wheel's arrow goes on, where
  each payoff's moving parts sit).
- **Ink:** 40 wheels (8 sizes x 5 metals, the webs rotated) each cover at least 47% of their disc.
- **The scene:** all four payoffs played to the end by scripted mouse input; the pawl holding on the wrong-way route; the
  odd loop jamming; a wheel refused where it does not fit; the arrow keys, Enter and Escape; leaving with the wheels
  kept and carrying on; a foreign placement ignored; `allow_leave` false; the same seed giving the same puzzle.
- **The demo room:** opened, a train left half-set and remembered, then solved and its jewel lit.
- **A blank project** that installed the package the way you will and ran this Readme's own code, with ink counted on
  everything it drew; and an adversarial pass of 232 calls (undefined, negative, huge and wrong-typed
  arguments) against the documented functions with zero crashes.

Two things this does not prove, stated plainly: the timings come from one shared machine and will differ on yours, and
the suite ran on Windows with the VM runtime only (other targets and YYC were not built).

## Licence

See `LICENSE.txt`. Use it in unlimited games, commercial or free; modify it freely; do not resell the package itself.

Made by Core Systems Asset Factory. Written with AI assistance, disclosed on every store page that carries it.
