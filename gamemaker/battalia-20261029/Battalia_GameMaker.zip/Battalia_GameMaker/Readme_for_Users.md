# Battalia - Army Battles for GameMaker

**Version 1.0.** For GameMaker 2024.14 and later (built and tested on runtime 2024.14.4.268, Windows, VM).

**Army battles for your game.** Two hosts of regiments meet on a painted field. Every soldier is drawn by the package
(foot, pikes, archers, horse and mages, in each army's colours), every regiment carries a banner whose arms are struck
from its name, and the field itself is painted from a seed. The player chooses a formation from four cards; then the
battle plays out soldier by soldier: volleys arc overhead, spells burst, cavalry charges, regiments break and run, the
fallen stay where they fell. A war record closes it, with every regiment's fate and the course of the battle charted,
and the result comes back to your code in soldiers.

Nothing is loaded: no sprites, no tiles, no sound files. Import the package, call one function, press Play.

What is inside: 5 arms x 4 poses x 2 liveries of drawn soldiers, banners from 16 ordinaries x 14 charges x 4 cloth
shapes x 10 tinctures, 5 battlefields (meadow, steppe, snow, desert, moor), each a different field per seed, 4
formations, a demo room with five battles, and the raw GML of all of it.

## Installing

1. **Tools > Import Local Package**, pick `Battalia.yymps`, **Add All**, **Import**.
2. Press Play with `rm_bta_demo` as the first room to see the demo (the War Room): five battles on five fields.

Every function starts with bta_ and every macro with BTA_; the demo object is `obj_bta_demo`, the room `rm_bta_demo` and the
fonts `fnt_battalia_display_s`, `fnt_battalia_display_l`, `fnt_battalia_body_s` and `fnt_battalia_body_l`, so nothing collides
with your project.

## Quickstart: a battle in one object

Put this in a new object and place it in a room.

```gml
// Create
my_battle = bta_scene_create({
    title: "The Battle of Ashford",
    terrain: "meadow",
    player: { name: "Your Host", army: "foot:44:Iron Company, pike:32:Black Pikes, archer:34:Rivermarch Bows, horse:16:Queen's Own" },
    enemy:  { name: "The Red Host", army: "foot:50:Crowfoot, archer:30:Sunspears, horse:20:Duskriders" }
});

// Step
bta_scene_step(my_battle);
if (bta_scene_done(my_battle)) {
    var _r = bta_scene_result(my_battle);    // _r.winner: 0 = your army, 1 = the enemy, -1 = neither held the field
    my_survivors = _r.sides[0].survived;     // in soldiers
    bta_scene_free(my_battle);
    instance_destroy();
}

// Draw GUI
bta_scene_draw(my_battle, 0, 0, display_get_gui_width() / 816);

// Clean Up
bta_scene_free(my_battle);
```

The scene's own frame is 816 x 624; `bta_scene_draw(scene, x, y, scale)` places and scales it anywhere, in Draw or Draw
GUI. Freeing twice is safe, and drawing a freed scene draws nothing.

## The scene: bta_scene_create(options)

| Option | Default | Meaning |
| --- | --- | --- |
| `title` | "The Battle" | Shown on the call to arms and the war record. |
| `terrain` | "meadow" | "meadow", "steppe", "snow", "desert" or "moor". |
| `seed` | a fresh one | Any number or string. The same seed replays the same battle exactly, frame for frame. |
| `player` | four regiments | `{ name, colour, army }`: the army's name, a tunic colour ("#rrggbb", a GameMaker colour or [r, g, b]) and its regiments. |
| `enemy` | four regiments | The same, for the enemy. |
| `playerForm` | "choose" | "choose" shows four formation cards; or fix it to "line", "wedge", "square" or "loose" (no cards). |
| `enemyForm` | "auto" | "auto" reads the enemy's own make-up (many bows or mages: loose; many riders: wedge; many pikes: square) with a seeded coin; or fix it. |
| `showEnemyForm` | true | The player sees how the enemy has formed before choosing. |
| `timeLimit` | 60 | Seconds of clash; then the stronger army holds the field if it is 15% ahead, or neither does. |
| `cap` | 240 | Figures drawn per side (8 to 600). A bigger army is carried at several soldiers per figure; every number you read back is still in soldiers. |
| `input` | "gui" | "gui": the scene reads the mouse in GUI coordinates and the keyboard. "room": mouse_x / mouse_y. false: drive it yourself. |
| `onEvent` | none | `function(type, x, y)` for every battle event (`BTA_EV_BLOW`, `BTA_EV_DEATH`, `BTA_EV_LOOSE`, `BTA_EV_ARROW_HIT`, `BTA_EV_ARROW_MISS`, `BTA_EV_CAST`, `BTA_EV_BURST`, `BTA_EV_ROUT`, `BTA_EV_CHARGE`). Play your own sounds here. It runs as your own object's code, so it can read and change your instance variables. |
| `onEnd` | none | `function(result)` once, when the battle is decided. |
| `artScale` | 1 | 2 paints the field, soldiers and banners at twice the resolution, for 2x displays and screenshots. |

**Controls** (when the scene owns input): Left / Right or the mouse choose a formation; Enter, Space or a click sounds
the charge. Hold Shift, Space, Enter or the mouse button during the clash to run it three times faster. Enter or a
click on the war record closes it.

**Your own input** (`input: false`): `bta_scene_choose(my_battle, "wedge")`, `bta_scene_set_fast(my_battle, true)`,
`bta_scene_skip(my_battle)` (resolve the rest at once and open the war record), `bta_scene_close(my_battle)` (close the
war record). `bta_scene_step` returns the phase:
`BTA_PHASE_TITLE`, `BTA_PHASE_CHOOSE`, `BTA_PHASE_CLASH`, `BTA_PHASE_RECORD`, `BTA_PHASE_DONE`.

## An army

An army is one line: regiments separated by commas, each `role:count:Name:strength`.

```gml
var _army = bta_army("foot:40:Shield_Men, archer:30:Bowmen:1.5, horse:20");
```

- **role**: foot, pike, archer, horse or mage.
- **count**: soldiers, 1 to 99,999.
- **Name** (optional): also decides the banner; the same name always flies the same arms. Underscores are spaces. A
  blank name becomes the arm and its place ("Horse 3").
- **strength** (optional): 1 = ordinary troops, 1.5 = veterans, 0.5 = levies (0.25 to 4).

A regiment that is not `role:count` is left out; an unknown role becomes foot. An array of structs
`{ name, role, count, strength }` works too.

## The result

`bta_scene_result(scene)` (or `bta_battle_result(battle)`) returns, in soldiers:

```gml
{ winner, frames, seconds, forms: ["square", "wedge"],
  sides: [ { count, survived, fled, dead }, { ... } ],
  regiments: [ { name, role, side, count, survived, fled, dead, routed }, ... ] }
```

For every regiment `survived + fled + dead = count`, exactly, whatever the army's size. Those who fled the field
survived; carry them home in your own variables.

## Who beats whom

- **Pikes stop horse.** Horse runs down archers and mages. Foot cut down archers and mages who let them close.
- **Archers and mages kill from range**: arrows fly in arcs and land where they were aimed; spells burst over an area.
- **The charge**: a rider's first blow lands at 1.6 times its force, except on pikes.
- **Morale**: a regiment that has lost most of its men while its army is losing may break and run for its own edge of
  the field.

## The four formations

| Formation | Beats | How |
| --- | --- | --- |
| Line | Loose | Steady ranks. |
| Wedge | Line | Drives in hard. |
| Square | Wedge | Shields locked; horse strike it at 60% of their force. |
| Loose | Square | Spread out: arrows and spells find little. |

The counter is worth a lot. Measured by the package's own suite (the `-selftest` run, seeded battles): with the smaller army (32 foot against 40), a wedge against the enemy's line won 17 of 20 battles, where copying the enemy's line won 0. Pikes in a square against horse in a wedge won 16 of 16. Identical armies in identical lines split fairly: 14 to the army on the left, 16 to the army on the right, 0 held by neither, over 30 battles. The counter is how a smaller army gets a chance; numbers still matter most.

## Without the scene: the rules alone

The rules draw nothing and can run headless (an auto-resolve, a strategy layer, a balance test):

```gml
var _b = bta_battle_create({ seed: 7, armies: [bta_army("foot:40:Shieldmen, archer:30:Bowmen"), "foot:50:Raiders, horse:20:Riders"], forms: ["square", "wedge"] });
bta_battle_run(_b);
var _r = bta_battle_result(_b);
show_debug_message("winner " + string(_r.winner) + " after " + string(_r.seconds) + " s");
```

Or step it yourself with `bta_battle_step(battle)` (one frame; returns the number of events written to
`battle.evType / evX / evY / evA`), and read `bta_battle_standing(battle, side)` (`{ count, alive, fled, dead }`) and
`bta_battle_share(battle, side)` (0..1 of a side's strength still fighting) at any time. `bta_enemy_formation(army, seed)`
is the enemy's own choice. Figures live in `battle.x` (from the centre line) and `battle.y`, 816 x 376 logical pixels.

## The pieces, for your own screens

```gml
var _arms = bta_heraldry("Iron Company", 0);     // the regiment's arms: the same name always gives the same arms
my_banner = bta_banner_sprite(_arms, 34, 24);    // one banner's cloth, painted at 2x
my_field  = bta_field_sprite("snow", 12, 816, 624);
my_atlas  = bta_soldier_atlas(bta_livery(0, "#3c6e8a"), bta_livery(1));
```

The banner and the soldier atlas are premultiplied: draw them with `gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha)`.
The atlas holds rows `side * 5 + role` and columns stand, step, strike, fallen, each cell 104 x 72 px (2x) with the
feet at (44, 66). Free each with `sprite_delete` when done.

## Cost

Measured in the shipped suite on a real build (VM, Windows, this machine shared with other work, so every figure is a
range over two runs): at the cap (240 figures a side, 480 on the field) one battle frame costs 8.8 to 10.0 ms on average to step (13.8 to 15.5 ms at the 95th percentile, over 600 frames a run) and 2.1 to 2.6 ms to draw (the median of 20 draws, every figure one sprite part from one atlas). The fast-forward steps three battle frames at once. Setting a battle up is a one-time cost: painting the field 144 to 174 ms, the soldier atlas 27 to 52 ms and each regiment's banner 15 ms. Lower `cap` for slower targets.

## What it touches

- Your project's resources: none. It adds scripts, one demo object, one demo room and four font resources, all
  prefixed.
- Global state: none at runtime (the demo object sets `global.bta_stage` for its crash report only). The blend mode,
  world matrix, colour, alpha, font and alignment are handed back as they were after every draw.

## Not tested

HTML5, mobile, consoles and YYC were not built. GML cannot be unit-tested outside the engine; every number in this
Readme came from real builds of this package.

## Fonts

The type is Cinzel (Bold) and Alegreya, rasterised into the four font resources named above, both under the SIL Open
Font Licence 1.1 (texts in `Battalia/fonts/`). Your game may ship them; see `THIRD-PARTY-NOTICES.txt`.

## Written with AI assistance

The code, the drawing and the store images were produced with AI assistance.

Core Systems Asset Factory - https://csaf.itch.io
