/// @description THE WAR ROOM - Battalia's demo room: five army battles on five fields, played start to finish.
/// Run with -selftest it is the headless test suite instead (writes bta_selftest.json and exits).
/// ⛔ The crash handler is installed FIRST, and every variable a later event reads is declared ABOVE the early exits:
/// Clean Up always runs, even when Create leaves early.
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("bta_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.bta_stage) + ": " + string(_ex.message) + " | " + string(_ex.stacktrace));
    file_text_close(_f);
    game_end();
});
global.bta_stage = 0;
demo = undefined;
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";
if (string_pos("-selftest", _args) > 0) { global.bta_stage = 1; bta_selftest_write(bta_selftest_run()); game_end(); exit; }
demo = bta_demo_create();
