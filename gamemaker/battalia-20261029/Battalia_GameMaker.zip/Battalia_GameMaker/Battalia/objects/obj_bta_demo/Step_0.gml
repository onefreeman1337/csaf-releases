/// @description Run the war room.
if (is_undefined(demo)) exit;
bta_demo_step(demo);
