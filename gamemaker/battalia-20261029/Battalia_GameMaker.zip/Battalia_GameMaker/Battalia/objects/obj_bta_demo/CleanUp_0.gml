/// @description Free what the war room drew (guarded: Clean Up runs even when Create left early for -selftest).
if (variable_instance_exists(id, "demo") && !is_undefined(demo)) { bta_demo_free(demo); demo = undefined; }
