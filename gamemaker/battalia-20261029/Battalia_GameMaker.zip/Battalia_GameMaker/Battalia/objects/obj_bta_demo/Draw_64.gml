/// @description Draw the war room, scaled to fit the GUI.
if (is_undefined(demo)) exit;
bta_demo_draw(demo);
