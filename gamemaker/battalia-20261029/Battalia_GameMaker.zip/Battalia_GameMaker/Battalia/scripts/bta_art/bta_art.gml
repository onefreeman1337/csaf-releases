/// bta_art.gml - EVERYTHING BATTALIA PAINTS ONCE: the soldier atlas (five arms x four poses x two liveries), the regimental
/// banners (arms struck from each regiment's name), the battlefield (meadow, steppe, snow, desert, moor) and two soft
/// sprites the effects are drawn with. No image file is loaded; every pixel is drawn by this file on first use.
///
/// Battalia - Army Battles for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ Four facts decide the shape of this file:
///   1. GameMaker's primitives have no antialiasing, so every figure is drawn 4x and filtered down twice (each a 2x2 box
///      average, exact because a half-scale bilinear draw samples on the texel corners).
///   2. A translucent mark drawn onto a surface lowers its alpha under the default blend: every bake blends alpha as
///      "over" (gpu_set_blendmode_ext_sepalpha) and the results are PREMULTIPLIED - draw them with bm_one, bm_inv_src_alpha.
///   3. A bake must not inherit the caller's world matrix or blend: each runs under its own matrix and gpu state and hands
///      both back (gpu_push_state / matrix_get / matrix_set).
///   4. Surfaces are volatile; everything kept is a SPRITE (sprite_create_from_surface). The caller frees them with
///      bta_art_free / bta_banner_free.
///
/// PUBLIC API:
///   bta_livery(side, [colour])                -> a livery { main, trim, dark, metal, skin, cloth } ([r,g,b] each)
///   bta_soldier_atlas(livery0, livery1)       -> { sprite, cellW, cellH, cx, foot, scale } (2x atlas, premultiplied)
///   bta_banner_sprite(arms, w, h)             -> a sprite of one banner's cloth (2x, premultiplied), origin top-left
///   bta_field_sprite(terrain, seed, w, h)     -> a sprite of a whole battlefield, w x h px, opaque
///   bta_terrains()                            -> ["meadow", "steppe", "snow", "desert", "moor"]

#macro BTA_CELL_W 52
#macro BTA_CELL_H 36
#macro BTA_CELL_CX 22
#macro BTA_CELL_FOOT 33
#macro BTA_FR_STAND 0
#macro BTA_FR_STEP 1
#macro BTA_FR_STRIKE 2
#macro BTA_FR_FALLEN 3

// ---------------------------------------------------------------------------------------------------------------------
// Colour helpers ([r, g, b] arrays)
// ---------------------------------------------------------------------------------------------------------------------

/// @function bta__c(rgb)
function bta__c(_c) { return make_colour_rgb(clamp(round(_c[0]), 0, 255), clamp(round(_c[1]), 0, 255), clamp(round(_c[2]), 0, 255)); }
/// @function bta__shade(rgb, k)  k < 0 darkens toward black, k > 0 lightens toward white
function bta__shade(_c, _k) { return (_k < 0) ? [_c[0] * (1 + _k), _c[1] * (1 + _k), _c[2] * (1 + _k)] : [_c[0] + (255 - _c[0]) * _k, _c[1] + (255 - _c[1]) * _k, _c[2] + (255 - _c[2]) * _k]; }
/// @function bta__mix(a, b, t)
function bta__mix(_a, _b, _t) { return [_a[0] + (_b[0] - _a[0]) * _t, _a[1] + (_b[1] - _a[1]) * _t, _a[2] + (_b[2] - _a[2]) * _t]; }
/// @function bta__hexrgb(value)
/// @description "#rrggbb" or "rrggbb" -> [r, g, b]; a GameMaker colour number -> [r, g, b]; anything else -> undefined.
function bta__hexrgb(_v) {
    if (is_array(_v) && array_length(_v) >= 3 && is_numeric(_v[0]) && is_numeric(_v[1]) && is_numeric(_v[2])) return [clamp(_v[0], 0, 255), clamp(_v[1], 0, 255), clamp(_v[2], 0, 255)];
    if (is_numeric(_v) && !is_nan(_v) && _v >= 0 && _v <= 16777215) return [colour_get_red(_v), colour_get_green(_v), colour_get_blue(_v)];
    if (!is_string(_v)) return undefined;
    var _t = string_replace(string_trim(_v), "#", "");
    if (string_length(_t) != 6) return undefined;
    var _hex = "0123456789abcdef", _n = 0;
    _t = string_lower(_t);
    for (var _i = 1; _i <= 6; _i++) { var _d = string_pos(string_char_at(_t, _i), _hex) - 1; if (_d < 0) return undefined; _n = _n * 16 + _d; }
    return [(_n div 65536) mod 256, (_n div 256) mod 256, _n mod 256];
}

/// @function bta__h2(x, y, s)
/// @description A seeded hash of three integers to [0, 1). Pure.
function bta__h2(_x, _y, _s) {
    var _m = int64(4294967295);
    var _h = (int64(floor(_x)) * int64(374761393) + int64(floor(_y)) * int64(668265263) + int64(floor(_s)) * int64(69069)) & _m;
    _h = ((_h ^ (_h >> 13)) * int64(1274126177)) & _m;
    return real(_h ^ (_h >> 16)) / 4294967296;
}
/// @function bta__noise(x, y, s)  value noise in [0, 1)
function bta__noise(_x, _y, _s) {
    var _xi = floor(_x), _yi = floor(_y), _xf = _x - _xi, _yf = _y - _yi;
    _xf = _xf * _xf * (3 - 2 * _xf); _yf = _yf * _yf * (3 - 2 * _yf);
    var _a = bta__h2(_xi, _yi, _s), _b = bta__h2(_xi + 1, _yi, _s), _c = bta__h2(_xi, _yi + 1, _s), _d = bta__h2(_xi + 1, _yi + 1, _s);
    return _a + (_b - _a) * _xf + (_c - _a) * _yf + (_a - _b - _c + _d) * _xf * _yf;
}
/// @function bta__fbm(x, y, s)
function bta__fbm(_x, _y, _s) { return bta__noise(_x, _y, _s) * 0.55 + bta__noise(_x * 2.1, _y * 2.1, _s + 7) * 0.28 + bta__noise(_x * 4.3, _y * 4.3, _s + 13) * 0.17; }

// ---------------------------------------------------------------------------------------------------------------------
// Liveries
// ---------------------------------------------------------------------------------------------------------------------

/// @function bta_livery(side, [colour])
/// @description An army's colours. side 0 defaults to a royal-blue host, side 1 to a crimson host; `colour` ("#rrggbb", a
/// GameMaker colour or [r, g, b]) replaces the tunic colour and derives its dark. Pure.
/// @returns {Struct}
function bta_livery(_side, _colour = undefined) {
    var _L = (is_numeric(_side) && _side >= 1)
        ? { main: [176, 42, 34], trim: [31, 26, 23], dark: [92, 20, 16], metal: [174, 180, 186], skin: [217, 165, 124], cloth: [74, 58, 42] }
        : { main: [47, 90, 168], trim: [233, 217, 166], dark: [26, 47, 92], metal: [185, 194, 204], skin: [226, 180, 140], cloth: [107, 74, 46] };
    var _c = bta__hexrgb(_colour);
    if (!is_undefined(_c)) { _L.main = _c; _L.dark = bta__shade(_c, -0.45); }
    return _L;
}

// ---------------------------------------------------------------------------------------------------------------------
// Primitive helpers for the supersampled figure bake (coordinates in CELL units; the world matrix scales them)
// ---------------------------------------------------------------------------------------------------------------------

/// @function bta__ln(x1, y1, x2, y2, w, rgb)
function bta__ln(_x1, _y1, _x2, _y2, _w, _c) { var _k = bta__c(_c); draw_line_width_colour(_x1, _y1, _x2, _y2, _w, _k, _k); draw_circle_colour(_x1, _y1, _w * 0.5, _k, _k, false); draw_circle_colour(_x2, _y2, _w * 0.5, _k, _k, false); }
/// @function bta__dot(x, y, r, rgb)
function bta__dot(_x, _y, _r, _c) { var _k = bta__c(_c); draw_circle_colour(_x, _y, _r, _k, _k, false); }
/// @function bta__ell(cx, cy, rx, ry, rgb, [alpha])
function bta__ell(_cx, _cy, _rx, _ry, _c, _a = 1) { var _k = bta__c(_c), _pa = draw_get_alpha(); draw_set_alpha(_a); draw_ellipse_colour(_cx - _rx, _cy - _ry, _cx + _rx, _cy + _ry, _k, _k, false); draw_set_alpha(_pa); }
/// @function bta__poly(pts, rgb)  a filled polygon, fanned from its centroid (every shape passed here is star-shaped about it)
function bta__poly(_p, _c) {
    var _n = array_length(_p) div 2;
    if (_n < 3) return;
    var _mx = 0, _my = 0, _i;
    for (_i = 0; _i < _n; _i++) { _mx += _p[_i * 2]; _my += _p[_i * 2 + 1]; }
    _mx /= _n; _my /= _n;
    var _k = bta__c(_c);
    draw_primitive_begin(pr_trianglelist);
    for (_i = 0; _i < _n; _i++) {
        var _j = (_i + 1) mod _n;
        draw_vertex_colour(_mx, _my, _k, 1); draw_vertex_colour(_p[_i * 2], _p[_i * 2 + 1], _k, 1); draw_vertex_colour(_p[_j * 2], _p[_j * 2 + 1], _k, 1);
    }
    draw_primitive_end();
}
/// @function bta__grow(pts, g)  every point pushed g away from the centroid (the ink outline pass)
function bta__grow(_p, _g) {
    if (_g <= 0) return _p;
    var _n = array_length(_p) div 2, _mx = 0, _my = 0, _i, _o = array_create(_n * 2, 0);
    for (_i = 0; _i < _n; _i++) { _mx += _p[_i * 2]; _my += _p[_i * 2 + 1]; }
    _mx /= _n; _my /= _n;
    for (_i = 0; _i < _n; _i++) {
        var _dx = _p[_i * 2] - _mx, _dy = _p[_i * 2 + 1] - _my, _d = max(0.001, sqrt(_dx * _dx + _dy * _dy));
        _o[_i * 2] = _p[_i * 2] + _dx / _d * _g; _o[_i * 2 + 1] = _p[_i * 2 + 1] + _dy / _d * _g;
    }
    return _o;
}
/// @function bta__quad(pts, x0, y0, cx, cy, x1, y1, steps)  append a quadratic curve's points (x0,y0 excluded)
function bta__quad(_p, _x0, _y0, _cx, _cy, _x1, _y1, _steps) {
    for (var _i = 1; _i <= _steps; _i++) { var _t = _i / _steps, _u = 1 - _t; array_push(_p, _u * _u * _x0 + 2 * _u * _t * _cx + _t * _t * _x1, _u * _u * _y0 + 2 * _u * _t * _cy + _t * _t * _y1); }
    return _p;
}
/// @function bta__arc_stroke(cx, cy, r, a0, a1, w, rgb)
function bta__arc_stroke(_cx, _cy, _r, _a0, _a1, _w, _c) {
    var _n = 10, _px = _cx + cos(_a0) * _r, _py = _cy + sin(_a0) * _r;
    for (var _i = 1; _i <= _n; _i++) { var _a = _a0 + (_a1 - _a0) * _i / _n, _qx = _cx + cos(_a) * _r, _qy = _cy + sin(_a) * _r; bta__ln(_px, _py, _qx, _qy, _w, _c); _px = _qx; _py = _qy; }
}
/// @function bta__affine(a, b, c, d, e, f)  x' = a x + c y + e, y' = b x + d y + f as a GameMaker matrix
function bta__affine(_a, _b, _c, _d, _e, _f) { return [_a, _b, 0, 0, _c, _d, 0, 0, 0, 0, 1, 0, _e, _f, 0, 1]; }

// ---------------------------------------------------------------------------------------------------------------------
// Soldiers (ported from the MZ edition's figure() and rider(); feet at (x, y), facing right)
// ---------------------------------------------------------------------------------------------------------------------

/// @function bta__figure(x, y, role, L, frame, pass)
function bta__figure(_x, _y, _role, _L, _frame, _pass) {
    var _o = (_pass == 0), _ink = [22, 16, 11], _g = _o ? 1.1 : 0;
    var _step = (_frame == BTA_FR_STEP) ? 1.6 : 0, _strike = (_frame == BTA_FR_STRIKE);
    var _leg = _o ? _ink : [58, 44, 34];
    bta__ln(_x - 1.2, _y - 7, _x - 1.6 - _step, _y - 0.5, 1.9 + _g * 2, _leg);
    bta__ln(_x + 1.2, _y - 7, _x + 1.8 + _step, _y - 0.5, 1.9 + _g * 2, _leg);
    var _robe = (_role == BTA_MAGE), _body;
    if (_robe) _body = [_x - 3.2, _y - 14.5, _x + 3.2, _y - 14.5, _x + 4.6, _y, _x - 4.6, _y];
    else _body = [_x - 3.3, _y - 14.5, _x + 3.3, _y - 14.5, _x + 3.8, _y - 5.5, _x - 3.8, _y - 5.5];
    bta__poly(bta__grow(_body, _g * 1.2), _o ? _ink : (_robe ? _L.dark : _L.main));
    if (!_o) {
        var _tr = bta__c(_L.trim);
        draw_rectangle_colour(_x - 3.6, _y - 7.4, _x + 3.6, _y - 6.2, _tr, _tr, _tr, _tr, false);           // belt / hem
        if (!_robe) draw_rectangle_colour(_x - 0.6, _y - 14, _x + 0.6, _y - 7.2, _tr, _tr, _tr, _tr, false); // tabard stripe
        else { var _mn = bta__c(_L.main); draw_rectangle_colour(_x - 0.8, _y - 14, _x + 0.8, _y, _mn, _mn, _mn, _mn, false); }
    }
    bta__dot(_x + 0.4, _y - 17.2, 2.7 + _g, _o ? _ink : _L.skin);
    // headgear
    var _hc = _o ? _ink : ((_role == BTA_ARCHER) ? _L.cloth : ((_role == BTA_MAGE) ? _L.dark : _L.metal)), _h = [];
    if (_role == BTA_FOOT || _role == BTA_PIKE) {
        var _r0 = (_role == BTA_FOOT) ? 3.2 : 3.0, _hy = (_role == BTA_FOOT) ? _y - 18 : _y - 18.2;
        for (var _q = 0; _q <= 8; _q++) { var _a = pi + pi * _q / 8; array_push(_h, _x + 0.4 + cos(_a) * (_r0 + _g), _hy + sin(_a) * (_r0 + _g)); }
        if (_role == BTA_FOOT) array_push(_h, _x + 4.6 + _g, _y - 17.6, _x - 3.8 - _g, _y - 17.6);
        bta__poly(_h, _hc);
    } else if (_role == BTA_ARCHER) {
        _h = [_x - 3.4 - _g, _y - 16];
        bta__quad(_h, _x - 3.4 - _g, _y - 16, _x - 2, _y - 23 - _g, _x + 2.6 + _g, _y - 20.5, 6);
        array_push(_h, _x + 3.2 + _g, _y - 17.5, _x - 0.5, _y - 19);
        bta__poly(_h, _hc);
    } else if (_role == BTA_MAGE) {
        bta__poly(bta__grow([_x - 4.6, _y - 18, _x + 4.6, _y - 18, _x - 1.2, _y - 27], _g * 1.3), _hc);
    }
    // arms and kit
    var _skin = _o ? _ink : _L.skin;
    if (_role == BTA_FOOT) {
        var _ax = _strike ? 7.5 : 4.5, _ay = _strike ? -15 : -11;
        bta__ln(_x + 2.5, _y - 13, _x + _ax, _y + _ay, 1.4 + _g * 2, _skin);
        bta__ln(_x + _ax, _y + _ay, _x + _ax + (_strike ? 6.5 : 1.5), _y + _ay + (_strike ? 1.5 : -7), 1.3 + _g * 2, _o ? _ink : [223, 228, 234]);
        bta__ell(_x + 3.6, _y - 10, 2.6 + _g, 4.2 + _g, _o ? _ink : _L.dark);
        if (!_o) { bta__ell(_x + 3.6, _y - 10, 1.4, 2.6, _L.trim); bta__dot(_x + 3.6, _y - 10, 0.8, _L.metal); }
    } else if (_role == BTA_PIKE) {
        var _pa = _strike ? -0.08 : -0.95, _len = 25, _bx = _x - 3, _by = _y - 11;
        var _tx = _bx + cos(_pa) * _len, _ty = _by + sin(_pa) * _len;
        bta__ln(_bx, _by, _tx, _ty, 1.3 + _g * 2, _o ? _ink : [106, 74, 42]);
        bta__poly(bta__grow([_tx + cos(_pa) * 4.5, _ty + sin(_pa) * 4.5, _tx + cos(_pa + 1.6) * 1.6, _ty + sin(_pa + 1.6) * 1.6, _tx + cos(_pa - 1.6) * 1.6, _ty + sin(_pa - 1.6) * 1.6], _g), _o ? _ink : [228, 232, 238]);
        bta__ln(_x + 1, _y - 13, _x + 5, _y - 11 + (_strike ? -1 : -3), 1.4 + _g * 2, _skin);
    } else if (_role == BTA_ARCHER) {
        var _bxx = _x + 5.2, _draw = _strike ? 3.2 : 0.4;
        bta__arc_stroke(_bxx - 3.2, _y - 12, 6.2, -1.05, 1.05, 1.3 + _g * 2, _o ? _ink : [90, 59, 28]);
        if (!_o) {
            bta__ln(_bxx - 3.2 + cos(-1.05) * 6.2, _y - 12 + sin(-1.05) * 6.2, _bxx - _draw - 2.6, _y - 12, 0.5, [232, 224, 204]);
            bta__ln(_bxx - _draw - 2.6, _y - 12, _bxx - 3.2 + cos(1.05) * 6.2, _y - 12 + sin(1.05) * 6.2, 0.5, [232, 224, 204]);
            if (_strike) bta__ln(_bxx - _draw - 2.6, _y - 12, _bxx + 4, _y - 12, 0.9, [216, 200, 160]);
        }
        bta__ln(_x + 1.5, _y - 13, _bxx + 0.2, _y - 12, 1.3 + _g * 2, _skin);
        var _qc = bta__c(_o ? _ink : [106, 69, 38]);
        draw_rectangle_colour(_x - 4.8 - _g, _y - 15 - _g, _x - 2.6 + _g, _y - 9 + _g, _qc, _qc, _qc, _qc, false);   // quiver
    } else if (_role == BTA_MAGE) {
        var _sx = _x + 4.5, _top = _strike ? _y - 27 : _y - 23, _gx = _sx + (_strike ? 1.5 : 0);
        bta__ln(_sx, _y + 0.5, _gx, _top, 1.2 + _g * 2, _o ? _ink : [74, 50, 32]);
        bta__ln(_x + 1.5, _y - 13, _sx, _y - 14 + (_strike ? -4 : 0), 1.3 + _g * 2, _skin);
        if (!_o) {
            var _gr = _strike ? 6 : 3.5, _gc = _strike ? [255, 215, 106] : [159, 216, 255];
            bta__ell(_gx, _top, _gr, _gr, _gc, 0.35); bta__ell(_gx, _top, _gr * 0.6, _gr * 0.6, _gc, 0.6); bta__dot(_gx, _top, _gr * 0.3, [255, 251, 232]);
        }
    }
}

/// @function bta__rider(x, y, L, frame, pass)
function bta__rider(_x, _y, _L, _frame, _pass) {
    var _o = (_pass == 0), _ink = [22, 16, 11], _g = _o ? 1.1 : 0, _gait = (_frame == BTA_FR_STEP), _strike = (_frame == BTA_FR_STRIKE);
    var _hide = [107, 68, 40], _hideD = [74, 46, 26];
    var _lx = [-7, -4.5, 5, 7.5];
    for (var _k = 0; _k < 4; _k++) { var _sw = ((_k mod 2) ? 1 : -1) * (_gait ? 2.2 : 0.4); bta__ln(_x + _lx[_k], _y - 7, _x + _lx[_k] + _sw, _y - 0.3, 1.6 + _g * 2, _o ? _ink : ((_k < 2) ? _hideD : _hide)); }
    bta__ell(_x, _y - 9, 9.5 + _g, 4.2 + _g, _o ? _ink : _hide);
    bta__poly(bta__grow([_x + 6, _y - 11, _x + 10, _y - 17, _x + 14, _y - 15, _x + 12.5, _y - 13, _x + 9, _y - 8], _g), _o ? _ink : _hide);
    bta__ln(_x - 9, _y - 10, _x - 12.5, _y - 5 + (_gait ? 1 : 0), 1.6 + _g * 2, _o ? _ink : [42, 26, 16]);
    if (!_o) {
        bta__poly([_x - 6, _y - 12.5, _x + 5, _y - 12.5, _x + 6, _y - 6, _x - 7, _y - 6], _L.main);   // caparison
        var _tr = bta__c(_L.trim);
        draw_rectangle_colour(_x - 7, _y - 6.8, _x + 6, _y - 5.8, _tr, _tr, _tr, _tr, false);
        bta__dot(_x + 12.6, _y - 15.4, 0.6, [20, 12, 8]);
    }
    bta__poly(bta__grow([_x - 2.6, _y - 21, _x + 2.6, _y - 21, _x + 3, _y - 12, _x - 3, _y - 12], _g * 1.2), _o ? _ink : _L.main);
    bta__dot(_x + 0.3, _y - 23.6, 2.5 + _g, _o ? _ink : _L.skin);
    var _h = [];
    for (var _q = 0; _q <= 8; _q++) { var _a = pi + pi * _q / 8; array_push(_h, _x + 0.3 + cos(_a) * (2.9 + _g), _y - 24.3 + sin(_a) * (2.9 + _g)); }
    bta__poly(_h, _o ? _ink : _L.metal);
    if (!_o) bta__ln(_x - 1, _y - 27, _x - 3.5, _y - 30, 1.4, _L.trim);   // plume
    var _la = _strike ? 0.02 : -0.55, _lbx = _x - 4, _lby = _y - 17, _tx = _lbx + cos(_la) * 26, _ty = _lby + sin(_la) * 26;
    bta__ln(_lbx, _lby, _tx, _ty, 1.3 + _g * 2, _o ? _ink : [122, 90, 54]);
    if (!_o) {
        bta__poly([_tx + cos(_la) * 4, _ty + sin(_la) * 4, _tx + cos(_la + 1.6) * 1.4, _ty + sin(_la + 1.6) * 1.4, _tx + cos(_la - 1.6) * 1.4, _ty + sin(_la - 1.6) * 1.4], [228, 232, 238]);
        var _pc = bta__c(_L.trim);
        draw_rectangle_colour(_tx - 5, _ty - 1.5, _tx - 2, _ty + 1.5, _pc, _pc, _pc, _pc, false);   // pennant
    }
}

/// @function bta__cell(role, L, frame)  one atlas cell, drawn at the CURRENT world matrix's cell origin
function bta__cell(_role, _L, _frame) {
    var _x = BTA_CELL_CX, _y = BTA_CELL_FOOT, _horse = (_role == BTA_HORSE);
    for (var _pass = 0; _pass < 2; _pass++) { if (_horse) bta__rider(_x, _y, _L, _frame, _pass); else bta__figure(_x, _y, _role, _L, _frame, _pass); }
}

/// @function bta_soldier_atlas(livery0, livery1)
/// @description Draw the soldier atlas for two liveries: rows = side * 5 + role, columns = stand, step, strike, fallen.
/// Drawn 4x and filtered to a 2x atlas (each cell 104 x 72 px). Returns { sprite, cellW, cellH, cx, foot, scale } where
/// cellW/cellH/cx/foot are in 1x units and scale is the atlas's own (2). The sprite is PREMULTIPLIED: draw it with
/// gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha) (bta_draw does). Free it with sprite_delete when done.
/// @returns {Struct}
function bta_soldier_atlas(_L0, _L1) {
    if (!is_struct(_L0)) _L0 = bta_livery(0);
    if (!is_struct(_L1)) _L1 = bta_livery(1);
    var _cols = 4, _rows = 10, _K = 4;
    var _w4 = BTA_CELL_W * _cols * _K, _h4 = BTA_CELL_H * _rows * _K;
    var _mPrev = matrix_get(matrix_world), _cp = draw_get_circle_precision();
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false); gpu_set_cullmode(cull_noculling);
    draw_set_circle_precision(24);
    var _s4 = surface_create(_w4, _h4);
    surface_set_target(_s4);
    draw_clear_alpha(c_black, 0);
    var _Ls = [_L0, _L1];
    for (var _s = 0; _s < 2; _s++) {
        var _L = _Ls[_s];
        var _Ld = { main: bta__shade(_L.main, -0.3), trim: bta__shade(_L.trim, -0.3), dark: bta__shade(_L.dark, -0.3), metal: bta__shade(_L.metal, -0.35), skin: bta__shade(_L.skin, -0.3), cloth: bta__shade(_L.cloth, -0.3) };
        for (var _r = 0; _r < 5; _r++) for (var _f = 0; _f < 4; _f++) {
            var _ox = _f * BTA_CELL_W, _oy = (_s * 5 + _r) * BTA_CELL_H, _x = _ox + BTA_CELL_CX, _y = _oy + BTA_CELL_FOOT;
            matrix_set(matrix_world, bta__affine(_K, 0, 0, _K, 0, 0));
            // each cell is clipped to itself, as the MZ edition's ctx.clip() did (a lance or a fallen pike must not reach the next cell)
            gpu_set_scissor(_ox * _K, _oy * _K, BTA_CELL_W * _K, BTA_CELL_H * _K);
            if (_f == BTA_FR_FALLEN) {
                bta__ell(_x, _y - 1.5, (_r == BTA_HORSE) ? 14 : 10, 2.6, [20, 14, 8], 0.28);
                // a body on the ground: a quarter turn about the feet (head to the right), or a horse flattened on its side
                if (_r == BTA_HORSE) matrix_set(matrix_world, bta__affine(_K, 0, 0, _K * 0.62, _K * _ox, _K * (0.38 * BTA_CELL_FOOT + 2.48 + _oy)));
                else matrix_set(matrix_world, bta__affine(0, _K, -_K, 0, _K * (BTA_CELL_FOOT + BTA_CELL_CX - 9 + _ox), _K * (BTA_CELL_FOOT - 6 - BTA_CELL_CX + _oy)));
                bta__cell(_r, _Ld, BTA_FR_STAND);
            } else {
                bta__ell(_x, _y, (_r == BTA_HORSE) ? 11 : 5.5, 1.8, [20, 14, 8], 0.30);
                matrix_set(matrix_world, bta__affine(_K, 0, 0, _K, _K * _ox, _K * _oy));
                bta__cell(_r, _L, _f);
            }
        }
    }
    matrix_set(matrix_world, matrix_build_identity());
    gpu_set_scissor(0, 0, _w4, _h4);
    surface_reset_target();
    // two exact 2x2 box filters: 4x -> 2x (the atlas keeps 2x for crisp store sheets; bta_draw draws it at half scale)
    var _s2 = surface_create(_w4 div 2, _h4 div 2);
    surface_set_target(_s2);
    draw_clear_alpha(c_black, 0);
    gpu_set_blendmode_ext(bm_one, bm_zero);
    gpu_set_texfilter(true);
    draw_surface_ext(_s4, 0, 0, 0.5, 0.5, 0, c_white, 1);
    surface_reset_target();
    var _spr = sprite_create_from_surface(_s2, 0, 0, _w4 div 2, _h4 div 2, false, false, 0, 0);
    surface_free(_s4); surface_free(_s2);
    draw_set_circle_precision(_cp);
    gpu_pop_state();
    matrix_set(matrix_world, _mPrev);
    return { sprite: _spr, cellW: BTA_CELL_W, cellH: BTA_CELL_H, cx: BTA_CELL_CX, foot: BTA_CELL_FOOT, scale: 2 };
}

// ---------------------------------------------------------------------------------------------------------------------
// Banners (drawn through the path kit: any outline, clipped ordinaries, curved charges, antialiased)
// ---------------------------------------------------------------------------------------------------------------------

/// @function bta__flag_path(ctx, shape, x, y, w, h)
function bta__flag_path(_c, _shape, _x, _y, _w, _h) {
    bta_cx_begin(_c);
    if (_shape == "swallowtail") { bta_cx_move(_c, _x, _y); bta_cx_line(_c, _x + _w, _y); bta_cx_line(_c, _x + _w * 0.72, _y + _h / 2); bta_cx_line(_c, _x + _w, _y + _h); bta_cx_line(_c, _x, _y + _h); }
    else if (_shape == "pennon") { bta_cx_move(_c, _x, _y); bta_cx_line(_c, _x + _w, _y + _h * 0.5); bta_cx_line(_c, _x, _y + _h); }
    else if (_shape == "gonfalon") {
        bta_cx_move(_c, _x, _y); bta_cx_line(_c, _x + _w, _y); bta_cx_line(_c, _x + _w, _y + _h * 0.72); bta_cx_line(_c, _x + _w * 0.83, _y + _h);
        bta_cx_line(_c, _x + _w * 0.67, _y + _h * 0.78); bta_cx_line(_c, _x + _w * 0.5, _y + _h); bta_cx_line(_c, _x + _w * 0.33, _y + _h * 0.78);
        bta_cx_line(_c, _x + _w * 0.17, _y + _h); bta_cx_line(_c, _x, _y + _h * 0.72);
    } else { bta_cx_move(_c, _x, _y); bta_cx_line(_c, _x + _w, _y); bta_cx_line(_c, _x + _w, _y + _h); bta_cx_line(_c, _x, _y + _h); }
    bta_cx_close(_c);
}

/// @function bta__rect(ctx, x, y, w, h)  fill a rectangle in the context's fill paint
function bta__rect(_c, _x, _y, _w, _h) { bta_cx_begin(_c); bta_cx_rect(_c, _x, _y, _w, _h); bta_cx_fill(_c); }
/// @function bta__bar(ctx, x1, y1, x2, y2, w)  fill a thick straight bar (a stroke with flat ends, as a polygon)
function bta__bar(_c, _x1, _y1, _x2, _y2, _w) {
    var _dx = _x2 - _x1, _dy = _y2 - _y1, _d = max(0.001, sqrt(_dx * _dx + _dy * _dy)), _nx = -_dy / _d * _w / 2, _ny = _dx / _d * _w / 2;
    bta_cx_begin(_c); bta_cx_move(_c, _x1 + _nx, _y1 + _ny); bta_cx_line(_c, _x2 + _nx, _y2 + _ny); bta_cx_line(_c, _x2 - _nx, _y2 - _ny); bta_cx_line(_c, _x1 - _nx, _y1 - _ny); bta_cx_close(_c); bta_cx_fill(_c);
}

/// @function bta__ordinary(ctx, o, x, y, w, h)
function bta__ordinary(_c, _o, _x, _y, _w, _h) {
    var _cx = _x + _w / 2, _cy = _y + _h / 2, _t = min(_w, _h);
    switch (_o) {
        case "pale": bta__rect(_c, _cx - _w * 0.16, _y, _w * 0.32, _h); break;
        case "fess": bta__rect(_c, _x, _cy - _h * 0.16, _w, _h * 0.32); break;
        case "bend": bta__bar(_c, _x - 4, _y - 4, _x + _w + 4, _y + _h + 4, _t * 0.28); break;
        case "bendsinister": bta__bar(_c, _x + _w + 4, _y - 4, _x - 4, _y + _h + 4, _t * 0.28); break;
        case "chevron": bta__bar(_c, _x - 2, _y + _h * 0.95, _cx, _y + _h * 0.3, _t * 0.22); bta__bar(_c, _cx, _y + _h * 0.3, _x + _w + 2, _y + _h * 0.95, _t * 0.22); bta_cx_begin(_c); bta_cx_arc(_c, _cx, _y + _h * 0.3, _t * 0.11, 0, 2 * pi); bta_cx_fill(_c); break;
        case "cross": bta__rect(_c, _cx - _w * 0.1, _y, _w * 0.2, _h); bta__rect(_c, _x, _cy - _h * 0.1, _w, _h * 0.2); break;
        case "saltire": bta__bar(_c, _x - 3, _y - 3, _x + _w + 3, _y + _h + 3, _t * 0.2); bta__bar(_c, _x + _w + 3, _y - 3, _x - 3, _y + _h + 3, _t * 0.2); break;
        case "perpale": bta__rect(_c, _cx, _y, _w / 2 + 2, _h); break;
        case "perfess": bta__rect(_c, _x, _cy, _w, _h / 2 + 2); break;
        case "quarterly": bta__rect(_c, _cx, _y, _w / 2 + 2, _h / 2); bta__rect(_c, _x, _cy, _w / 2, _h / 2 + 2); break;
        case "chief": bta__rect(_c, _x, _y, _w, _h * 0.3); break;
        case "bordure":
            var _b = _t * 0.18;
            bta__rect(_c, _x, _y, _w, _b); bta__rect(_c, _x, _y + _h - _b, _w, _b); bta__rect(_c, _x, _y, _b, _h); bta__rect(_c, _x + _w - _b, _y, _b, _h);
            break;
        case "pile": bta_cx_begin(_c); bta_cx_move(_c, _x + _w * 0.18, _y); bta_cx_line(_c, _x + _w * 0.82, _y); bta_cx_line(_c, _cx, _y + _h * 0.9); bta_cx_close(_c); bta_cx_fill(_c); break;
        case "barry": for (var _k = 1; _k < 6; _k += 2) bta__rect(_c, _x, _y + _h * _k / 6, _w, _h / 6); break;
        case "paly": for (var _q = 1; _q < 6; _q += 2) bta__rect(_c, _x + _w * _q / 6, _y, _w / 6, _h); break;
    }
}

/// @function bta__star(ctx, cx, cy, r, pts, inner)
function bta__star(_c, _cx, _cy, _r, _pts, _inner) {
    bta_cx_begin(_c);
    for (var _i = 0; _i < _pts * 2; _i++) { var _a = -pi / 2 + _i * pi / _pts, _rr = (_i mod 2) ? _r * _inner : _r; if (_i == 0) bta_cx_move(_c, _cx + cos(_a) * _rr, _cy + sin(_a) * _rr); else bta_cx_line(_c, _cx + cos(_a) * _rr, _cy + sin(_a) * _rr); }
    bta_cx_close(_c); bta_cx_fill(_c);
}
/// @function bta__disc(ctx, cx, cy, r)
function bta__disc(_c, _cx, _cy, _r) { bta_cx_begin(_c); bta_cx_arc(_c, _cx, _cy, _r, 0, 2 * pi); bta_cx_close(_c); bta_cx_fill(_c); }

/// @function bta__charge(ctx, charge, cx, cy, r, col, field)
function bta__charge(_c, _ch, _cx, _cy, _r, _col, _field) {
    var _pc = bta_cx_solid(_col), _pf = bta_cx_solid(_field);
    _c.fill = _pc;
    switch (_ch) {
        case "star": bta__star(_c, _cx, _cy, _r, 5, 0.42); break;
        case "sun": bta__star(_c, _cx, _cy, _r, 12, 0.62); _c.fill = _pf; bta__disc(_c, _cx, _cy, _r * 0.34); break;
        case "crescent": bta__disc(_c, _cx, _cy, _r * 0.85); _c.fill = _pf; bta__disc(_c, _cx, _cy - _r * 0.32, _r * 0.7); break;
        case "annulet": bta__disc(_c, _cx, _cy, _r * 0.8); _c.fill = _pf; bta__disc(_c, _cx, _cy, _r * 0.44); break;
        case "lozenge": bta_cx_begin(_c); bta_cx_move(_c, _cx, _cy - _r); bta_cx_line(_c, _cx + _r * 0.62, _cy); bta_cx_line(_c, _cx, _cy + _r); bta_cx_line(_c, _cx - _r * 0.62, _cy); bta_cx_close(_c); bta_cx_fill(_c); break;
        case "roundel": bta__disc(_c, _cx, _cy, _r * 0.7); break;
        case "crosslet": var _t = _r * 0.26; bta__rect(_c, _cx - _t, _cy - _r, _t * 2, _r * 2); bta__rect(_c, _cx - _r * 0.75, _cy - _r * 0.35 - _t, _r * 1.5, _t * 2); break;
        case "tower":
            bta__rect(_c, _cx - _r * 0.55, _cy - _r * 0.5, _r * 1.1, _r * 1.4);
            for (var _m = 0; _m < 3; _m++) bta__rect(_c, _cx - _r * 0.55 + _m * _r * 0.42, _cy - _r * 0.85, _r * 0.26, _r * 0.4);
            _c.fill = _pf; bta__rect(_c, _cx - _r * 0.16, _cy + _r * 0.35, _r * 0.32, _r * 0.55);
            break;
        case "sword":
            bta__bar(_c, _cx, _cy - _r, _cx, _cy + _r * 0.55, _r * 0.22);
            bta__bar(_c, _cx - _r * 0.5, _cy + _r * 0.45, _cx + _r * 0.5, _cy + _r * 0.45, _r * 0.2);
            bta__disc(_c, _cx, _cy + _r * 0.85, _r * 0.16);
            bta_cx_begin(_c); bta_cx_move(_c, _cx - _r * 0.11, _cy - _r); bta_cx_line(_c, _cx, _cy - _r * 1.25); bta_cx_line(_c, _cx + _r * 0.11, _cy - _r); bta_cx_close(_c); bta_cx_fill(_c);
            break;
        case "key":
            bta__disc(_c, _cx, _cy - _r * 0.55, _r * 0.45); _c.fill = _pf; bta__disc(_c, _cx, _cy - _r * 0.55, _r * 0.22); _c.fill = _pc;
            bta__bar(_c, _cx, _cy - _r * 0.15, _cx, _cy + _r, _r * 0.22);
            bta__bar(_c, _cx, _cy + _r * 0.6, _cx + _r * 0.42, _cy + _r * 0.6, _r * 0.2); bta__bar(_c, _cx, _cy + _r * 0.9, _cx + _r * 0.34, _cy + _r * 0.9, _r * 0.2);
            break;
        case "bird":
            bta_cx_begin(_c); bta_cx_move(_c, _cx - _r, _cy - _r * 0.2);
            bta_cx_quad(_c, _cx - _r * 0.4, _cy - _r * 0.9, _cx, _cy - _r * 0.1); bta_cx_quad(_c, _cx + _r * 0.4, _cy - _r * 0.9, _cx + _r, _cy - _r * 0.2);
            bta_cx_quad(_c, _cx + _r * 0.3, _cy - _r * 0.1, _cx + _r * 0.2, _cy + _r * 0.3); bta_cx_line(_c, _cx, _cy + _r * 0.9); bta_cx_line(_c, _cx - _r * 0.2, _cy + _r * 0.3);
            bta_cx_quad(_c, _cx - _r * 0.3, _cy - _r * 0.1, _cx - _r, _cy - _r * 0.2); bta_cx_close(_c); bta_cx_fill(_c);
            break;
        case "fleur":
            bta_cx_begin(_c); bta_cx_move(_c, _cx, _cy - _r); bta_cx_quad(_c, _cx + _r * 0.42, _cy - _r * 0.3, _cx, _cy + _r * 0.2); bta_cx_quad(_c, _cx - _r * 0.42, _cy - _r * 0.3, _cx, _cy - _r); bta_cx_close(_c); bta_cx_fill(_c);
            bta_cx_begin(_c); bta_cx_move(_c, _cx - _r * 0.1, _cy + _r * 0.05); bta_cx_quad(_c, _cx - _r * 1.05, _cy - _r * 0.55, _cx - _r * 0.75, _cy + _r * 0.25); bta_cx_quad(_c, _cx - _r * 0.45, _cy + _r * 0.3, _cx - _r * 0.1, _cy + _r * 0.3); bta_cx_close(_c); bta_cx_fill(_c);
            bta_cx_begin(_c); bta_cx_move(_c, _cx + _r * 0.1, _cy + _r * 0.05); bta_cx_quad(_c, _cx + _r * 1.05, _cy - _r * 0.55, _cx + _r * 0.75, _cy + _r * 0.25); bta_cx_quad(_c, _cx + _r * 0.45, _cy + _r * 0.3, _cx + _r * 0.1, _cy + _r * 0.3); bta_cx_close(_c); bta_cx_fill(_c);
            bta__rect(_c, _cx - _r * 0.55, _cy + _r * 0.3, _r * 1.1, _r * 0.2);
            bta_cx_begin(_c); bta_cx_move(_c, _cx - _r * 0.2, _cy + _r * 0.5); bta_cx_line(_c, _cx + _r * 0.2, _cy + _r * 0.5); bta_cx_line(_c, _cx, _cy + _r); bta_cx_close(_c); bta_cx_fill(_c);
            break;
        case "axe":
            bta__bar(_c, _cx - _r * 0.2, _cy + _r, _cx - _r * 0.2, _cy - _r * 0.9, _r * 0.18);
            bta_cx_begin(_c); bta_cx_move(_c, _cx - _r * 0.2, _cy - _r * 0.8); bta_cx_quad(_c, _cx + _r * 0.95, _cy - _r, _cx + _r * 0.75, _cy - _r * 0.1); bta_cx_quad(_c, _cx + _r * 0.4, _cy - _r * 0.35, _cx - _r * 0.2, _cy - _r * 0.2); bta_cx_close(_c); bta_cx_fill(_c);
            break;
    }
}

/// @function bta_banner_sprite(arms, w, h)
/// @description Draw one regimental banner's CLOTH (no staff: bta_draw plants it on a pole and ripples it) for arms from
/// bta_heraldry, w x h px at 1x, into a 2x premultiplied sprite with its origin at the hoist's top-left. Returns the sprite
/// (free it with sprite_delete), or -1 for arms that are not a struct.
/// @returns {Asset.GMSprite}
function bta_banner_sprite(_arms, _w, _h) {
    if (!is_struct(_arms) || !variable_struct_exists(_arms, "field")) return -1;
    _w = clamp(bta__num(_w, 34), 8, 512); _h = clamp(bta__num(_h, 24), 6, 512);
    var _ss = 2, _pad = 2, _W = ceil((_w + _pad * 2) * _ss), _H = ceil((_h + _pad * 2) * _ss);
    var _mPrev = matrix_get(matrix_world);
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false); gpu_set_cullmode(cull_noculling);
    matrix_set(matrix_world, matrix_build_identity());
    var _s = surface_create(_W, _H);
    surface_set_target(_s);
    draw_clear_alpha(c_black, 0);
    var _c = bta_cx_create(_ss), _fx = _pad, _fy = _pad;
    bta_cx_save(_c);
    bta__flag_path(_c, _arms.shape, _fx, _fy, _w, _h);
    _c.fill = bta_cx_solid(_arms.field); bta_cx_fill(_c);
    bta_cx_clip(_c);
    _c.fill = bta_cx_solid(_arms.other);
    bta__ordinary(_c, _arms.ordinary, _fx, _fy, _w, _h);
    if (_arms.charge != "none") {
        var _r = min(_w, _h) * 0.3, _cx = _fx + _w * ((_arms.shape == "pennon") ? 0.36 : 0.46), _cy = _fy + _h * ((_arms.ordinary == "chief") ? 0.6 : 0.5);
        bta__charge(_c, _arms.charge, _cx, _cy, _r, _arms.chargeCol, _arms.field);
    }
    // folds as soft vertical bands of shade and light
    for (var _k = 0; _k < 4; _k++) {
        var _gx = _fx + _w * (0.12 + _k * 0.25), _g = bta_cx_linear(_c, _gx - _w * 0.12, 0, _gx + _w * 0.12, 0);
        bta_cx_stop(_g, 0, [0, 0, 0], 0); bta_cx_stop(_g, 0.5, (_k mod 2) ? [255, 255, 255] : [0, 0, 0], (_k mod 2) ? 0.12 : 0.18); bta_cx_stop(_g, 1, [0, 0, 0], 0);
        _c.fill = _g; bta__rect(_c, _gx - _w * 0.12, _fy, _w * 0.24, _h);
    }
    bta_cx_restore(_c);
    bta__flag_path(_c, _arms.shape, _fx, _fy, _w, _h);
    _c.lw = 1.1; _c.stroke = bta_cx_solid([20, 12, 6], 0.85); bta_cx_stroke(_c);
    surface_reset_target();
    var _spr = sprite_create_from_surface(_s, 0, 0, _W, _H, false, false, 0, 0);
    surface_free(_s);
    gpu_pop_state();
    matrix_set(matrix_world, _mPrev);
    return _spr;
}

// ---------------------------------------------------------------------------------------------------------------------
// Two soft sprites for light, dust and shadow
// ---------------------------------------------------------------------------------------------------------------------

/// @function bta_soft_sprites()
/// @description { blob, spark }: a 64 px radial falloff (white, alpha 1 at the centre to 0 at the rim, premultiplied) and
/// a 32 px four-point glint. Drawn once and kept for the life of the game (static); never free them yourself.
/// @returns {Struct}
function bta_soft_sprites() {
    static _cache = undefined;
    if (is_struct(_cache) && sprite_exists(_cache.blob) && sprite_exists(_cache.spark)) return _cache;
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    var _mPrev = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_build_identity());
    var _cp = draw_get_circle_precision();
    draw_set_circle_precision(48);
    var _s = surface_create(64, 64);
    surface_set_target(_s); draw_clear_alpha(c_black, 0);
    gpu_set_blendmode_ext(bm_one, bm_zero);
    for (var _r = 32; _r >= 1; _r--) { var _t = 1 - _r / 32, _a = _t * _t * (3 - 2 * _t); draw_set_alpha(_a); draw_circle_colour(32, 32, _r, make_colour_rgb(255 * _a, 255 * _a, 255 * _a), make_colour_rgb(255 * _a, 255 * _a, 255 * _a), false); }
    draw_set_alpha(1);
    surface_reset_target();
    var _blob = sprite_create_from_surface(_s, 0, 0, 64, 64, false, false, 32, 32);
    surface_free(_s);
    _s = surface_create(32, 32);
    surface_set_target(_s); draw_clear_alpha(c_black, 0);
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    draw_primitive_begin(pr_trianglelist);
    for (var _i = 0; _i < 8; _i++) {
        var _a0 = -pi / 2 + _i * pi / 4, _a1 = -pi / 2 + (_i + 1) * pi / 4, _r0 = (_i mod 2) ? 4 : 15, _r1 = ((_i + 1) mod 2) ? 4 : 15;
        draw_vertex_colour(16, 16, c_white, 1); draw_vertex_colour(16 + cos(_a0) * _r0, 16 + sin(_a0) * _r0, c_white, 1); draw_vertex_colour(16 + cos(_a1) * _r1, 16 + sin(_a1) * _r1, c_white, 1);
    }
    draw_primitive_end();
    surface_reset_target();
    var _spark = sprite_create_from_surface(_s, 0, 0, 32, 32, false, false, 16, 16);
    surface_free(_s);
    draw_set_circle_precision(_cp);
    matrix_set(matrix_world, _mPrev);
    gpu_pop_state();
    _cache = { blob: _blob, spark: _spark };
    return _cache;
}

// ---------------------------------------------------------------------------------------------------------------------
// Battlefields
// ---------------------------------------------------------------------------------------------------------------------

/// @function bta_terrains()
/// @description The five fields, by id.
function bta_terrains() { static _t = ["meadow", "steppe", "snow", "desert", "moor"]; return _t; }

/// @function bta__terrain(id)
function bta__terrain(_id) {
    switch (_id) {
        case "steppe": return { sky: [[185, 196, 200], [239, 226, 196]], hills: [[160, 143, 114], [138, 118, 88], [111, 94, 68]], ground: [[179, 154, 94], [152, 128, 74]], patch: [[194, 168, 104], [142, 118, 68], [168, 146, 90]], tuft: [122, 102, 54], stone: [142, 132, 116], flower: [[216, 192, 112], [232, 220, 192], [176, 112, 64]], road: [200, 180, 136] };
        case "snow": return { sky: [[154, 168, 184], [221, 227, 234]], hills: [[184, 194, 204], [154, 166, 178], [126, 138, 152]], ground: [[230, 235, 239], [201, 210, 218]], patch: [[244, 247, 249], [188, 198, 208], [216, 224, 230]], tuft: [138, 144, 152], stone: [110, 116, 124], flower: [[255, 255, 255], [208, 218, 228], [184, 196, 208]], road: [180, 176, 168] };
        case "desert": return { sky: [[156, 194, 220], [246, 226, 188]], hills: [[214, 174, 120], [196, 150, 96], [168, 124, 76]], ground: [[224, 191, 134], [207, 166, 108]], patch: [[236, 208, 154], [198, 154, 96], [216, 180, 122]], tuft: [154, 124, 70], stone: [160, 136, 104], flower: [[240, 224, 176], [216, 160, 96], [184, 136, 80]], road: [200, 168, 120] };
        case "moor": return { sky: [[122, 132, 144], [196, 192, 180]], hills: [[94, 90, 98], [76, 72, 82], [58, 54, 64]], ground: [[106, 100, 72], [86, 80, 58]], patch: [[122, 110, 74], [74, 70, 50], [128, 106, 90]], tuft: [58, 54, 36], stone: [122, 120, 116], flower: [[138, 90, 138], [176, 122, 160], [216, 208, 176]], road: [138, 126, 98] };
    }
    return { sky: [[143, 182, 216], [217, 230, 232]], hills: [[111, 143, 122], [87, 122, 96], [63, 101, 71]], ground: [[111, 148, 72], [85, 122, 54]], patch: [[132, 168, 84], [77, 112, 50], [154, 174, 90]], tuft: [61, 94, 39], stone: [138, 138, 122], flower: [[232, 210, 74], [240, 240, 224], [200, 90, 138]], road: [155, 138, 98] };
}

/// @function bta__vgrad(x1, y1, x2, y2, rgbTop, rgbBottom, [alpha])
function bta__vgrad(_x1, _y1, _x2, _y2, _a, _b, _al = 1) { var _ka = bta__c(_a), _kb = bta__c(_b), _pa = draw_get_alpha(); draw_set_alpha(_al); draw_rectangle_colour(_x1, _y1, _x2, _y2, _ka, _ka, _kb, _kb, false); draw_set_alpha(_pa); }

/// @function bta_field_sprite(terrain, seed, w, h)
/// @description Paint a whole battlefield w x h px (the battle's frame is 816 x 624; any size scales the same picture):
/// sky, three ranges of hills with a keep on one and a tree line on the nearest, a field of noise-shaped patches under
/// broad light and cloud shadow, a cart track across the near ground, bushes, tufts, stones and flowers, and a vignette.
/// One seed is one field; two seeds are two fields. Returns an opaque sprite (free it with sprite_delete).
/// @returns {Asset.GMSprite}
function bta_field_sprite(_terrain, _seed, _w = 816, _h = 624) {
    var _T = bta__terrain(_terrain), _s = bta_hash(string(_seed)) mod 100000;
    _w = clamp(round(bta__num(_w, 816)), 32, 4096); _h = clamp(round(bta__num(_h, 624)), 32, 4096);
    var _W = 816, _H = 624, _HZ = 190, _k, _x, _y;
    var _mPrev = matrix_get(matrix_world), _cp = draw_get_circle_precision();
    var _blob = bta_soft_sprites().blob;
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false); gpu_set_cullmode(cull_noculling);
    draw_set_circle_precision(24);
    // the noise patches: one value per 6 px cell into a small surface, drawn up with filtering (cheap and smooth)
    var _pw = _W div 6, _ph = (_H - _HZ) div 6;
    var _ps = surface_create(_pw, _ph);
    surface_set_target(_ps);
    draw_clear_alpha(c_black, 0);
    gpu_set_blendmode_ext(bm_one, bm_zero);
    var _p0 = bta__c(_T.patch[0]), _p1 = bta__c(_T.patch[1]), _p2 = bta__c(_T.patch[2]);
    draw_primitive_begin(pr_pointlist);
    var _cnt = 0;
    for (_y = 0; _y < _ph; _y++) for (_x = 0; _x < _pw; _x++) {
        var _n = bta__fbm(_x * 6 * 0.010, (_HZ + _y * 6) * 0.026, _s + 101), _a = 0, _col = _p0;
        if (_n > 0.58) { _a = min(0.7, (_n - 0.58) * 2.8); _col = _p0; }
        else if (_n < 0.38) { _a = min(0.62, (0.38 - _n) * 2.8); _col = _p1; }
        else if (_n > 0.49 && _n < 0.51) { _a = 0.35; _col = _p2; }
        if (_a <= 0) continue;
        draw_vertex_colour(_x + 0.5, _y + 0.5, make_colour_rgb(colour_get_red(_col) * _a, colour_get_green(_col) * _a, colour_get_blue(_col) * _a), _a);
        _cnt++;
        if (_cnt >= 900) { draw_primitive_end(); draw_primitive_begin(pr_pointlist); _cnt = 0; }
    }
    draw_primitive_end();
    surface_reset_target();
    // the field itself, drawn in the 816 x 624 frame and scaled to w x h by the world matrix
    var _f = surface_create(_w, _h);
    surface_set_target(_f);
    draw_clear_alpha(c_black, 1);
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    matrix_set(matrix_world, bta__affine(_w / _W, 0, 0, _h / _H, 0, 0));
    bta__vgrad(0, 0, _W, _HZ + 2, _T.sky[0], _T.sky[1]);
    // clouds
    for (_k = 0; _k < 7; _k++) {
        var _cx = bta__h2(_k, 1, _s) * _W, _cy = 20 + bta__h2(_k, 2, _s) * (_HZ * 0.45), _cw = 60 + bta__h2(_k, 3, _s) * 110, _ca = 0.18 + bta__h2(_k, 4, _s) * 0.2;
        for (var _q = 0; _q < 5; _q++) bta__ell(_cx + (_q - 2) * _cw * 0.2, _cy + sin(_q * 1.7) * 4, _cw * 0.28, 7 + bta__h2(_k, _q, _s) * 6, [255, 255, 255], _ca);
    }
    // hills: three ranges far to near; the nearest fades into the ground so no seam shows at the horizon
    for (var _r = 0; _r < 3; _r++) {
        var _base = _HZ - 58 + _r * 22, _amp = 34 - _r * 8, _fq = 0.004 + _r * 0.003;
        var _top = (_r == 2) ? bta__shade(_T.ground[0], 0.08) : _T.hills[_r], _kt = bta__c(_T.hills[_r]), _kb = bta__c(_top);
        draw_primitive_begin(pr_trianglestrip);
        for (_x = 0; _x <= _W; _x += 6) {
            var _hy = _base - bta__fbm(_x * _fq, _r * 3.3, _s + _r * 17) * _amp * 1.6 + _amp * 0.3;
            var _tt = clamp((_hy - (_base - _amp)) / (_HZ + 6 - (_base - _amp)), 0, 1);
            draw_vertex_colour(_x, _hy, merge_colour(_kt, _kb, _tt), 1); draw_vertex_colour(_x, _HZ + 6, _kb, 1);
        }
        draw_primitive_end();
        if (_r == 2) for (_k = 0; _k < 46; _k++) {
            if (bta__h2(_k, 22, _s) < 0.35) continue;
            var _tx0 = bta__h2(_k, 21, _s) * _W, _ty0 = _base - bta__fbm(_tx0 * _fq, _r * 3.3, _s + _r * 17) * _amp * 1.6 + _amp * 0.3 + 4;
            bta__ell(_tx0, _ty0 - 4, 4 + bta__h2(_k, 24, _s) * 5, 5 + bta__h2(_k, 25, _s) * 5, bta__shade(_T.hills[2], -0.18 - bta__h2(_k, 23, _s) * 0.15));
        }
        if (_r == 1) {   // a keep on the middle range
            var _kx = 90 + bta__h2(9, 9, _s) * (_W - 180), _ky = _base - bta__fbm(_kx * _fq, _r * 3.3, _s + _r * 17) * _amp * 1.6 + _amp * 0.3;
            var _kc = bta__c(bta__shade(_T.hills[2], -0.25));
            draw_rectangle_colour(_kx - 10, _ky - 20, _kx + 10, _ky + 2, _kc, _kc, _kc, _kc, false);
            draw_rectangle_colour(_kx - 16, _ky - 12, _kx - 10, _ky + 2, _kc, _kc, _kc, _kc, false);
            draw_rectangle_colour(_kx + 10, _ky - 12, _kx + 16, _ky + 2, _kc, _kc, _kc, _kc, false);
            for (var _m = 0; _m < 4; _m++) draw_rectangle_colour(_kx - 10 + _m * 6, _ky - 24, _kx - 6.5 + _m * 6, _ky - 20, _kc, _kc, _kc, _kc, false);
            bta__ln(_kx, _ky - 24, _kx, _ky - 34, 1, bta__shade(_T.hills[2], -0.35));
            draw_triangle_colour(_kx, _ky - 34, _kx + 8, _ky - 31, _kx, _ky - 28, make_colour_rgb(168, 50, 42), make_colour_rgb(168, 50, 42), make_colour_rgb(168, 50, 42), false);
        }
    }
    // ground
    bta__vgrad(0, _HZ + 5, _W, _H, bta__shade(_T.ground[0], 0.08), _T.ground[1]);
    // broad light: sunlit swathes and cloud shadows (the large-scale value that makes a field read as land)
    gpu_set_blendmode_ext_sepalpha(bm_one, bm_inv_src_alpha, bm_zero, bm_one);
    for (_k = 0; _k < 9; _k++) {
        var _sx0 = bta__h2(_k, 31, _s) * _W, _sy0 = _HZ + 30 + bta__h2(_k, 32, _s) * (_H - _HZ - 30), _sr = 90 + bta__h2(_k, 33, _s) * 170, _lit = (_k mod 3) != 0;
        draw_sprite_ext(_blob, 0, _sx0, _sy0, _sr * 1.8 / 32, _sr * 0.55 / 32, 0, _lit ? make_colour_rgb(255 * 0.16, 248 * 0.16, 210 * 0.16) : c_black, _lit ? 0.16 : 0.20);
    }
    // patches, drawn up from the noise surface (premultiplied)
    gpu_set_texfilter(true);
    draw_surface_stretched(_ps, 0, _HZ + 4, _W, _H - _HZ - 4);
    gpu_set_texfilter(false);
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    // a cart track across the near ground, curving once (never down the middle between the armies)
    var _ty1 = _H - 70 - bta__h2(3, 3, _s) * 50, _ty2 = _H - 40 - bta__h2(4, 4, _s) * 60, _bend = _HZ + (_H - _HZ) * (0.55 + bta__h2(5, 5, _s) * 0.2);
    for (var _tr = 0; _tr < 2; _tr++) {
        var _pts = [-10, _ty1 + _tr * 4];
        bta__quad(_pts, -10, _ty1 + _tr * 4, _W * 0.5, _bend + (_ty1 + _ty2) * 0.25 - (_H - _HZ) * 0.1 + _tr * 4, _W + 10, _ty2 + _tr * 4, 40);
        draw_set_alpha(_tr ? 0.35 : 0.42);
        for (var _pi = 0; _pi + 3 < array_length(_pts); _pi += 2) bta__ln(_pts[_pi], _pts[_pi + 1], _pts[_pi + 2], _pts[_pi + 3], _tr ? 3 : 14, _tr ? bta__shade(_T.road, -0.25) : _T.road);
        draw_set_alpha(1);
    }
    // bushes in the near corners and along the edges
    for (_k = 0; _k < 16; _k++) {
        var _bxs = (((_k mod 2) == 1) ? _W - 40 : 40) + (bta__h2(_k, 41, _s) - 0.5) * 90, _bys = _HZ + 60 + bta__h2(_k, 42, _s) * (_H - _HZ - 60);
        var _br = 5 + bta__h2(_k, 43, _s) * 9 * ((_bys - _HZ) / (_H - _HZ) + 0.4);
        bta__ell(_bxs + 2, _bys + _br * 0.5, _br * 1.2, _br * 0.4, [20, 14, 8], 0.25);
        for (var _bq = 0; _bq < 4; _bq++) bta__dot(_bxs + (_bq - 1.5) * _br * 0.45, _bys - (_bq mod 2) * _br * 0.3, _br * (0.7 - _bq * 0.06), bta__shade(_T.tuft, (_bq == 3) ? 0.18 : -0.05 * _bq));
    }
    // tufts in small clusters, stones, flowers: denser and larger near the viewer
    for (_k = 0; _k < 260; _k++) {
        var _py = _HZ + 8 + power(bta__h2(_k, 11, _s), 0.75) * (_H - _HZ - 8), _px = bta__h2(_k, 12, _s) * _W, _depth = (_py - _HZ) / (_H - _HZ), _kind = bta__h2(_k, 13, _s);
        if (_kind < 0.7) {
            for (var _c2 = 0; _c2 < 3; _c2++) {
                var _cxx = _px + (bta__h2(_k, 50 + _c2, _s) - 0.5) * 10 * (0.5 + _depth), _hh = 2 + _depth * 5 * (0.6 + bta__h2(_k, 60 + _c2, _s) * 0.6), _lw = 0.7 + _depth * 0.7;
                var _kc2 = bta__c(_T.tuft);
                draw_line_width_colour(_cxx, _py, _cxx - 1.6, _py - _hh, _lw, _kc2, _kc2); draw_line_width_colour(_cxx, _py, _cxx + 0.3, _py - _hh * 1.2, _lw, _kc2, _kc2); draw_line_width_colour(_cxx, _py, _cxx + 1.8, _py - _hh * 0.9, _lw, _kc2, _kc2);
            }
        } else if (_kind < 0.85) {
            bta__ell(_px, _py, 1.2 + _depth * 3, 0.8 + _depth * 1.8, _T.stone);
            var _hl = c_white; draw_set_alpha(0.28); draw_rectangle_colour(_px - 0.8, _py - 1.2, _px + 0.4 + _depth * 1.5, _py - 0.3, _hl, _hl, _hl, _hl, false); draw_set_alpha(1);
        } else {
            for (var _fl = 0; _fl < 5; _fl++) {
                var _fc = bta__c(_T.flower[floor(bta__h2(_k, 70 + _fl, _s) * 3)]), _fx = _px + (bta__h2(_k, 80 + _fl, _s) - 0.5) * 12, _fy = _py + (bta__h2(_k, 90 + _fl, _s) - 0.5) * 5, _fz = 1 + _depth * 1.2;
                draw_rectangle_colour(_fx, _fy, _fx + _fz, _fy + _fz, _fc, _fc, _fc, _fc, false);
            }
        }
    }
    // vignette: four dark gradient edges
    var _vk = make_colour_rgb(10, 6, 2);
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_zero, bm_one);
    for (var _v = 0; _v < 24; _v++) {
        var _va = 0.38 * power(1 - _v / 24, 2) * 0.22;
        draw_set_alpha(_va);
        draw_rectangle_colour(0, _H - 5 - _v * 5, _W, _H - _v * 5, _vk, _vk, _vk, _vk, false);
        draw_set_alpha(_va * 0.5);
        draw_rectangle_colour(0, _v * 3, _W, _v * 3 + 3, _vk, _vk, _vk, _vk, false);
        draw_set_alpha(_va);
        draw_rectangle_colour(_v * 5, 0, _v * 5 + 5, _H, _vk, _vk, _vk, _vk, false);
        draw_rectangle_colour(_W - _v * 5 - 5, 0, _W - _v * 5, _H, _vk, _vk, _vk, _vk, false);
    }
    draw_set_alpha(1);
    matrix_set(matrix_world, matrix_build_identity());
    surface_reset_target();
    var _spr = sprite_create_from_surface(_f, 0, 0, _w, _h, false, false, 0, 0);
    surface_free(_f); surface_free(_ps);
    draw_set_circle_precision(_cp);
    gpu_pop_state();
    matrix_set(matrix_world, _mPrev);
    return _spr;
}
