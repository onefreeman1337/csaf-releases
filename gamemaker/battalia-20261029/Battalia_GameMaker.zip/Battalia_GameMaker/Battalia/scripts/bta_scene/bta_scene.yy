{
  "$GMScript": "v1",
  "%Name": "bta_scene",
  "name": "bta_scene",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}