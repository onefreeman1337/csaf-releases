/// bta_scene.gml - A WHOLE ARMY BATTLE ON SCREEN, START TO FINISH: the call to arms, the formation cards, the clash soldier
/// by soldier (volleys arcing overhead, spells bursting, banners rippling over every regiment, the fallen left on the
/// field), and the war record with the course of the battle charted. One struct; call step once per Step and draw once
/// per Draw (or Draw GUI). Everything drawn here is drawn by Battalia: no sprite, font or sound of yours is touched.
///
/// Battalia - Army Battles for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// The scene's own frame is 816 x 624 (the field the rules are written in). bta_scene_draw places and scales that frame
/// anywhere: bta_scene_draw(scene, x, y, scale).
///
/// PUBLIC API:
///   bta_scene_create(opts)           -> a scene (opts documented below)
///   bta_scene_step(scene)            -> advance one frame (input, battle, effects); returns the phase name
///   bta_scene_draw(scene, x, y, scale)
///   bta_scene_choose(scene, form)    -> pick the player's formation and sound the charge (for your own input)
///   bta_scene_set_fast(scene, on)    -> run the clash three times faster while on (for your own input)
///   bta_scene_skip(scene)            -> resolve the rest of the battle at once and open the war record
///   bta_scene_close(scene)           -> close the war record (for your own input)
///   bta_scene_done(scene)            -> true once the war record has been closed
///   bta_scene_result(scene)          -> bta_battle_result of the battle (also before it ends: the standing so far)
///   bta_scene_free(scene)            -> free every sprite the scene drew (call in Clean Up)

#macro BTA_PHASE_TITLE "title"
#macro BTA_PHASE_CHOOSE "choose"
#macro BTA_PHASE_CLASH "clash"
#macro BTA_PHASE_RECORD "record"
#macro BTA_PHASE_DONE "done"
#macro BTA__FXMAX 400

/// @function bta_scene_create(opts)
/// @description A battle scene. opts (every field optional):
///   title        "The Battle of Ashford" (default "The Battle")
///   terrain      "meadow" | "steppe" | "snow" | "desert" | "moor" (default "meadow")
///   seed         any number or string; the same seed replays the same battle (default: a fresh one from current_time)
///   player       { name: "Your Host", colour: "#2f5aa8", army: "foot:44:Iron Company, archer:34:Rivermarch Bows" }
///   enemy        { name: "The Red Host", colour: "#b02a22", army: ... }   army = a bta_army spec string or array
///   playerForm   "choose" (four cards; default) or "line" | "wedge" | "square" | "loose"
///   enemyForm    "auto" (read from its own make-up; default) or a formation
///   showEnemyForm  true (default): the player sees how the enemy has formed before choosing
///   timeLimit    seconds of clash before the stronger army holds the field (default 60)
///   input        "gui" (default: mouse in GUI coordinates) | "room" (mouse_x / mouse_y) | false (drive it yourself)
///   onEvent      function(type, x, y) called for every BTA_EV_* event (x, y in the scene frame) - play your sounds here
///   onEnd        function(result) called once when the battle is decided
///   artScale     1 (default) or 2: the resolution the field, soldiers and banners are painted at (2 for 2x displays)
///   cap          figures drawn per side (default 240, 8..600); a bigger army is carried at several soldiers per figure.
///                Lower it for slower targets: a 480-figure frame is the costliest case (see the Readme for measured costs)
/// @returns {Struct}
function bta_scene_create(_o = {}) {
    if (!is_struct(_o)) _o = {};
    var _pl = is_struct(_o[$ "player"]) ? _o[$ "player"] : {}, _en = is_struct(_o[$ "enemy"]) ? _o[$ "enemy"] : {};
    var _seed = _o[$ "seed"];
    if (is_undefined(_seed)) _seed = floor(current_time + get_timer() mod 100000);
    var _armyP = bta__normalize(_pl[$ "army"] ?? "foot:44:Iron Company, pike:32:Black Pikes, archer:34:Rivermarch Bows, horse:16:Queen's Own", 0);
    var _armyE = bta__normalize(_en[$ "army"] ?? "foot:50:Crowfoot, foot:30:Harrow, archer:30:Sunspears, horse:20:Duskriders", 1);
    var _sc = {
        title: is_string(_o[$ "title"]) ? _o[$ "title"] : "The Battle",
        terrain: bta__terrain_id(_o[$ "terrain"]), seed: _seed,
        names: [is_string(_pl[$ "name"]) ? _pl[$ "name"] : "Your Host", is_string(_en[$ "name"]) ? _en[$ "name"] : "The Red Host"],
        liveries: [bta_livery(0, _pl[$ "colour"]), bta_livery(1, _en[$ "colour"])],
        armies: [_armyP, _armyE],
        choose: !(bta_form_id(_o[$ "playerForm"]) >= 0),
        playerForm: max(0, bta_form_id(_o[$ "playerForm"])),
        enemyForm: 0, showEnemy: (_o[$ "showEnemyForm"] ?? true) ? true : false,
        timeLimit: max(10, bta__num(_o[$ "timeLimit"], 60)) * 60,
        input: _o[$ "input"] ?? "gui", onEvent: _o[$ "onEvent"], onEnd: _o[$ "onEnd"],
        artScale: (bta__num(_o[$ "artScale"], 1) >= 2) ? 2 : 1, cap: clamp(floor(bta__num(_o[$ "cap"], BTA_CAP_PER_SIDE)), 8, 600),
        phase: BTA_PHASE_TITLE, t: 0, hover: 0, fast: false, battle: undefined, result: undefined, ended: false, endT: 0,
        art: undefined, banners: [], arms: [], hist: { n: 0, s0: [], s1: [], routs: [] },
        fx: { n: 0, kind: array_create(BTA__FXMAX, 0), x: array_create(BTA__FXMAX, 0), y: array_create(BTA__FXMAX, 0), t: array_create(BTA__FXMAX, 0), life: array_create(BTA__FXMAX, 1), a: array_create(BTA__FXMAX, 0), b: array_create(BTA__FXMAX, 0), txt: array_create(BTA__FXMAX, "") },
        view: { px: [], py: [], head: array_create(400, -1), next: [], moving: [] },
        drawX: 0, drawY: 0, drawScale: 1, clicked: false, enemyNote: ""
    };
    // ⛔ a function written INSIDE the options struct literal is bound to that struct, so `onEvent: function() { hits += 1; }`
    // would read `hits` on the options struct and crash (MEASURED in the fresh install, 2026-10-29). A callback bound to the
    // options struct is rebound to whoever called bta_scene_create (the buyer's instance); one the buyer bound on purpose
    // (method(some_struct, fn)) is left alone.
    if (is_method(_sc.onEvent) && method_get_self(_sc.onEvent) == _o) _sc.onEvent = method(self, method_get_index(_sc.onEvent));
    if (is_method(_sc.onEnd) && method_get_self(_sc.onEnd) == _o) _sc.onEnd = method(self, method_get_index(_sc.onEnd));
    var _ef = bta_form_id(_o[$ "enemyForm"]);
    _sc.enemyForm = (_ef >= 0) ? _ef : bta_form_id(bta_enemy_formation(_armyE, _seed));
    // paint once: the field, both liveries' soldiers, every regiment's banner
    _sc.art = { field: bta_field_sprite(_sc.terrain, _seed, 816 * _sc.artScale, 624 * _sc.artScale), atlas: bta_soldier_atlas(_sc.liveries[0], _sc.liveries[1]) };
    for (var _s = 0; _s < 2; _s++) for (var _g = 0; _g < array_length(_sc.armies[_s]); _g++) {
        var _arms = bta_heraldry(_sc.armies[_s][_g].name, _s);
        array_push(_sc.arms, _arms);
        array_push(_sc.banners, bta_banner_sprite(_arms, 34, 24));
    }
    var _fn = ["a line", "a wedge", "a square", "a loose screen"];
    _sc.enemyNote = _sc.names[1] + " forms " + _fn[_sc.enemyForm] + ". Choose your order.";
    bta__scene_deploy(_sc, _sc.playerForm);
    return _sc;
}

/// @function bta__terrain_id(value)
function bta__terrain_id(_v) { var _t = bta_terrains(); if (is_string(_v)) { var _l = string_lower(string_trim(_v)); for (var _i = 0; _i < 5; _i++) if (_t[_i] == _l) return _l; } return "meadow"; }

/// @function bta__scene_deploy(scene, playerForm)  (re)build the battle in the given player formation
function bta__scene_deploy(_sc, _pf) {
    _sc.playerForm = _pf;
    _sc.battle = bta_battle_create({ seed: _sc.seed, armies: _sc.armies, forms: [_pf, _sc.enemyForm], timeLimit: _sc.timeLimit, cap: _sc.cap });
    var _n = max(1, _sc.battle.n);
    _sc.view.px = array_create(_n, 0); _sc.view.py = array_create(_n, 0); _sc.view.next = array_create(_n, -1); _sc.view.moving = array_create(_n, 0);
    array_copy(_sc.view.px, 0, _sc.battle.x, 0, _sc.battle.n); array_copy(_sc.view.py, 0, _sc.battle.y, 0, _sc.battle.n);
}

/// @function bta__scene_mouse(scene)  the mouse in the scene's own frame, or undefined when input is off
function bta__scene_mouse(_sc) {
    if (_sc.input == false || is_undefined(_sc.input)) return undefined;
    var _mx, _my;
    if (_sc.input == "room") { _mx = mouse_x; _my = mouse_y; } else { _mx = device_mouse_x_to_gui(0); _my = device_mouse_y_to_gui(0); }
    return [(_mx - _sc.drawX) / _sc.drawScale, (_my - _sc.drawY) / _sc.drawScale];
}

/// @function bta__card_rect(i)  the four formation cards in the scene frame
function bta__card_rect(_i) { return [40 + _i * 188, 50, 172, 150]; }

/// @function bta_scene_choose(scene, form)
/// @description Pick the player's formation ("line" | "wedge" | "square" | "loose" or 0..3) and sound the charge. Only
/// acts while the cards are up (or during the call to arms, which it ends). Returns true when it acted.
/// @returns {Bool}
function bta_scene_choose(_sc, _form) {
    if (!is_struct(_sc) || !variable_struct_exists(_sc, "phase")) return false;
    var _f = bta_form_id(_form);
    if (_f < 0 || !(_sc.phase == BTA_PHASE_CHOOSE || _sc.phase == BTA_PHASE_TITLE)) return false;
    bta__scene_deploy(_sc, _f);
    _sc.phase = BTA_PHASE_CLASH; _sc.t = 0;
    bta__scene_sample(_sc);
    return true;
}

/// @function bta_scene_set_fast(scene, on)
/// @description While on, the clash runs three battle frames per step.
function bta_scene_set_fast(_sc, _on) { if (is_struct(_sc) && variable_struct_exists(_sc, "fast")) _sc.fast = (_on == true); }

/// @function bta_scene_skip(scene)
/// @description Resolve the rest of the battle at once (no animation) and open the war record. Returns true when it acted.
/// @returns {Bool}
function bta_scene_skip(_sc) {
    if (!is_struct(_sc) || !variable_struct_exists(_sc, "phase")) return false;
    if (_sc.phase == BTA_PHASE_TITLE || _sc.phase == BTA_PHASE_CHOOSE) bta_scene_choose(_sc, _sc.playerForm);
    if (_sc.phase != BTA_PHASE_CLASH) return false;
    // quiet: the war record still learns who broke and when, but no effect is spawned and onEvent is not called for
    // a battle the player chose not to watch
    while (!_sc.battle.over) { bta_battle_step(_sc.battle); bta__scene_events(_sc, true); if ((_sc.battle.frame mod 30) == 0) bta__scene_sample(_sc); }
    bta__scene_end(_sc);
    _sc.phase = BTA_PHASE_RECORD; _sc.t = 0;
    return true;
}

/// @function bta_scene_close(scene)
/// @description Close the war record (for your own input; the scene's own input closes it on Enter or a click). Returns
/// true when it acted (only while the war record is up).
/// @returns {Bool}
function bta_scene_close(_sc) {
    if (!is_struct(_sc) || !variable_struct_exists(_sc, "phase") || _sc.phase != BTA_PHASE_RECORD) return false;
    _sc.phase = BTA_PHASE_DONE; _sc.t = 0;
    return true;
}

/// @function bta_scene_done(scene)
/// @returns {Bool}
function bta_scene_done(_sc) { return is_struct(_sc) && variable_struct_exists(_sc, "phase") && _sc.phase == BTA_PHASE_DONE; }

/// @function bta_scene_result(scene)
/// @description The battle's outcome in soldiers (bta_battle_result) - final once the battle is decided.
/// @returns {Struct}
function bta_scene_result(_sc) {
    if (!is_struct(_sc) || !variable_struct_exists(_sc, "battle")) return bta_battle_result(undefined);
    if (is_struct(_sc.result)) return _sc.result;
    return bta_battle_result(_sc.battle);
}

/// @function bta__scene_sample(scene)  one point of the course of the battle (twice a second)
function bta__scene_sample(_sc) {
    array_push(_sc.hist.s0, bta_battle_share(_sc.battle, 0)); array_push(_sc.hist.s1, bta_battle_share(_sc.battle, 1));
    _sc.hist.n = array_length(_sc.hist.s0);
}

/// @function bta__scene_end(scene)
function bta__scene_end(_sc) {
    if (_sc.ended) return;
    _sc.ended = true;
    bta__scene_sample(_sc);
    _sc.result = bta_battle_result(_sc.battle);
    if (is_callable(_sc.onEnd)) _sc.onEnd(_sc.result);
}

/// @function bta__fx_add(scene, kind, x, y, life, a, b, txt)
/// kinds: 1 spark, 2 dust, 3 burst, 4 note, 5 stuck arrow, 6 cast glow
function bta__fx_add(_sc, _kind, _x, _y, _life, _a = 0, _b = 0, _txt = "") {
    var _f = _sc.fx, _k = -1;
    for (var _i = 0; _i < _f.n; _i++) if (_f.kind[_i] == 0) { _k = _i; break; }
    if (_k < 0) { if (_f.n >= BTA__FXMAX) return; _k = _f.n; _f.n++; }
    _f.kind[_k] = _kind; _f.x[_k] = _x; _f.y[_k] = _y; _f.t[_k] = 0; _f.life[_k] = _life; _f.a[_k] = _a; _f.b[_k] = _b; _f.txt[_k] = _txt;
}

/// @function bta__scene_events(scene, [quiet])  turn this frame's battle events into effects (and the buyer's callback);
/// quiet = record the routs for the war record only
function bta__scene_events(_sc, _quiet = false) {
    var _b = _sc.battle;
    for (var _e = 0; _e < _b.evN; _e++) {
        var _t = _b.evType[_e], _x = _b.evX[_e] + BTA_FIELD_MID, _y = _b.evY[_e];
        if (_quiet) {
            if (_t == BTA_EV_ROUT) { var _gq = _b.regs[_b.evA[_e]]; array_push(_sc.hist.routs, { t: _b.frame / 60, side: _gq.side, name: _gq.name }); }
            continue;
        }
        switch (_t) {
            case BTA_EV_BLOW: if ((_e mod 2) == 0) bta__fx_add(_sc, 1, _x, _y, 9); break;
            case BTA_EV_DEATH: bta__fx_add(_sc, 2, _x, _y - 4, 26, 1); break;
            case BTA_EV_ARROW_MISS: bta__fx_add(_sc, 5, _x, _y, 240, (_b.side[_b.pfrom[_b.evA[_e]]] == 0) ? 1 : -1); bta__fx_add(_sc, 2, _x, _y, 14, 0.4); break;
            case BTA_EV_BURST: bta__fx_add(_sc, 3, _x, _y, 26); break;
            case BTA_EV_CAST: bta__fx_add(_sc, 6, _x + 4 * _b.face[_b.evA[_e]], _y - 24, 16); break;
            case BTA_EV_CHARGE: if ((_sc.battle.frame mod 4) == 0) bta__fx_add(_sc, 2, _x - 8 * _b.face[_b.evA[_e]], _y, 22, 0.7); break;
            case BTA_EV_ROUT:
                var _g = _b.regs[_b.evA[_e]];
                // "broke" agrees with every regiment name ("Iron Company broke", "Red Spears broke"); a note never lands on
                // another one still showing (LOOKED AT 2026-10-29: three routs stacked into one unreadable column)
                var _nx = clamp(_x, 120, 696), _ny = _y - 30, _fxs = _sc.fx;
                for (var _try = 0; _try < 8; _try++) {
                    var _hit = false;
                    for (var _q = 0; _q < _fxs.n; _q++) if (_fxs.kind[_q] == 4 && abs(_fxs.x[_q] - _nx) < 150 && abs(_fxs.y[_q] - _fxs.t[_q] * 18 / _fxs.life[_q] - _ny) < 26) { _hit = true; break; }
                    if (!_hit) break;
                    _ny -= 26;
                }
                bta__fx_add(_sc, 4, _nx, max(64, _ny), 150, _g.side, 0, _g.name + " broke!");
                array_push(_sc.hist.routs, { t: _b.frame / 60, side: _g.side, name: _g.name });
                break;
        }
        if (is_callable(_sc.onEvent)) _sc.onEvent(_t, _x, _y);
    }
}

/// @function bta_scene_step(scene)
/// @description One frame: input (when the scene owns it), the battle, the effects. Returns the phase name.
/// @returns {String}
function bta_scene_step(_sc) {
    if (!is_struct(_sc) || !variable_struct_exists(_sc, "phase")) return BTA_PHASE_DONE;
    _sc.t++;
    var _m = bta__scene_mouse(_sc), _owns = !is_undefined(_m);
    var _click = _owns && mouse_check_button_pressed(mb_left), _ok = _owns && (keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space));
    // effects age in every phase
    var _f = _sc.fx;
    for (var _i = 0; _i < _f.n; _i++) if (_f.kind[_i] != 0) { _f.t[_i]++; if (_f.t[_i] >= _f.life[_i]) _f.kind[_i] = 0; }
    switch (_sc.phase) {
        case BTA_PHASE_TITLE:
            if (_sc.t > 100 || _click || _ok) { _sc.phase = _sc.choose ? BTA_PHASE_CHOOSE : BTA_PHASE_CLASH; _sc.t = 0; if (!_sc.choose) bta_scene_choose(_sc, _sc.playerForm); }
            break;
        case BTA_PHASE_CHOOSE:
            if (_owns) {
                var _was = _sc.hover;
                if (keyboard_check_pressed(vk_left)) _sc.hover = (_sc.hover + 3) mod 4;
                if (keyboard_check_pressed(vk_right)) _sc.hover = (_sc.hover + 1) mod 4;
                var _over = -1;
                for (var _c = 0; _c < 4; _c++) { var _r = bta__card_rect(_c); if (_m[0] >= _r[0] && _m[0] <= _r[0] + _r[2] && _m[1] >= _r[1] && _m[1] <= _r[1] + _r[3]) _over = _c; }
                if (_over >= 0) _sc.hover = _over;
                if (_sc.hover != _was) bta__scene_deploy(_sc, _sc.hover);
                if (_ok || (_click && _over >= 0)) bta_scene_choose(_sc, _sc.hover);
            }
            break;
        case BTA_PHASE_CLASH:
            if (_owns) _sc.fast = keyboard_check(vk_shift) || keyboard_check(vk_space) || keyboard_check(vk_enter) || mouse_check_button(mb_left);
            var _steps = _sc.fast ? 3 : 1;
            for (var _k = 0; _k < _steps; _k++) {
                if (_sc.battle.over) break;
                array_copy(_sc.view.px, 0, _sc.battle.x, 0, _sc.battle.n); array_copy(_sc.view.py, 0, _sc.battle.y, 0, _sc.battle.n);
                bta_battle_step(_sc.battle);
                bta__scene_events(_sc);
                if ((_sc.battle.frame mod 30) == 0) bta__scene_sample(_sc);
            }
            for (var _q = 0; _q < _sc.battle.n; _q++) _sc.view.moving[_q] = (abs(_sc.battle.x[_q] - _sc.view.px[_q]) + abs(_sc.battle.y[_q] - _sc.view.py[_q]) > 0.05);
            if (_sc.battle.over) {
                bta__scene_end(_sc);
                _sc.endT++;
                if (_sc.endT > 75 || (_sc.endT > 10 && (_click || _ok))) { _sc.phase = BTA_PHASE_RECORD; _sc.t = 0; }
            }
            break;
        case BTA_PHASE_RECORD:
            if (_sc.t > 20 && (_click || _ok)) { _sc.phase = BTA_PHASE_DONE; _sc.t = 0; }
            break;
    }
    return _sc.phase;
}

/// @function bta_scene_free(scene)
/// @description Free every sprite the scene drew. Safe to call twice.
function bta_scene_free(_sc) {
    if (!is_struct(_sc) || !variable_struct_exists(_sc, "art")) return;
    if (is_struct(_sc.art)) {
        if (sprite_exists(_sc.art.field)) sprite_delete(_sc.art.field);
        if (is_struct(_sc.art.atlas) && sprite_exists(_sc.art.atlas.sprite)) sprite_delete(_sc.art.atlas.sprite);
    }
    for (var _i = 0; _i < array_length(_sc.banners); _i++) if (sprite_exists(_sc.banners[_i])) sprite_delete(_sc.banners[_i]);
    _sc.banners = []; _sc.art = undefined;
}

// ---------------------------------------------------------------------------------------------------------------------
// Drawing
// ---------------------------------------------------------------------------------------------------------------------

/// @function bta__txt(x, y, str, px, face, rgb, [alpha], [halign], [valign])
/// @description Type in the scene frame: Cinzel Bold (display, lining figures) or Alegreya (body), struck from the
/// shipped atlases and filtered. Numbers the player reads go in the display face (Alegreya's figures are old-style).
function bta__txt(_x, _y, _s, _px, _face, _rgb, _a = 1, _ha = fa_left, _va = fa_middle) {
    var _fi = bta_font_for(_face, _px), _sc = _px / _fi.px;
    draw_set_font(_fi.font); draw_set_halign(_ha); draw_set_valign(_va); draw_set_colour(bta__c(_rgb)); draw_set_alpha(_a);
    draw_text_transformed(_x, _y, _s, _sc, _sc, 0);
    draw_set_alpha(1);
}
/// @function bta__txt_w(str, px, face)
function bta__txt_w(_s, _px, _face) { var _fi = bta_font_for(_face, _px); draw_set_font(_fi.font); return string_width(_s) * _px / _fi.px; }
/// @function bta__fit(str, px, face, maxW)  the largest px <= px at which the string fits maxW
function bta__fit(_s, _px, _face, _maxW) { var _w = bta__txt_w(_s, _px, _face); return (_w > _maxW && _w > 0) ? max(8, _px * _maxW / _w) : _px; }

/// @function bta__plate(x, y, w, h, tone)  "iron" (dark, gold rim) or "parch" (parchment, brown rim)
function bta__plate(_x, _y, _w, _h, _tone, _seed = 0) {
    var _iron = (_tone == "iron");
    var _c0 = _iron ? make_colour_rgb(58, 52, 48) : make_colour_rgb(242, 230, 200), _c1 = _iron ? make_colour_rgb(34, 30, 27) : make_colour_rgb(220, 200, 156);
    draw_set_alpha(0.35); draw_roundrect_colour_ext(_x + 3, _y + 4, _x + _w + 3, _y + _h + 4, 12, 12, c_black, c_black, false); draw_set_alpha(1);
    draw_roundrect_colour_ext(_x, _y, _x + _w, _y + _h, 12, 12, _c0, _c0, false);
    draw_rectangle_colour(_x + 3, _y + 3, _x + _w - 3, _y + _h - 3, _c0, _c0, _c1, _c1, false);
    if (!_iron) {   // the parchment's own mottling: soft seeded blotches
        var _blob = bta_soft_sprites().blob;
        gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
        for (var _k = 0; _k < max(4, (_w * _h) div 4000); _k++) {
            var _bx = _x + 8 + bta__h2(_k, 1, _seed) * (_w - 16), _by = _y + 8 + bta__h2(_k, 2, _seed) * (_h - 16), _br = 6 + bta__h2(_k, 3, _seed) * 22;
            // a warm stain, never grey (LOOKED AT 2026-10-29: black blotches read as dirt on the war record)
            // premultiplied blend: the tint's colour is scaled by the same alpha, or the stain would ADD brown light
            var _sa = 0.05 + bta__h2(_k, 4, _seed) * 0.05;
            draw_sprite_ext(_blob, 0, _bx, _by, _br / 32, _br / 32, 0, make_colour_rgb(150 * _sa, 104 * _sa, 48 * _sa), _sa);
        }
        gpu_set_blendmode(bm_normal);
    }
    var _rim = _iron ? make_colour_rgb(176, 138, 72) : make_colour_rgb(138, 106, 58);
    draw_roundrect_colour_ext(_x, _y, _x + _w, _y + _h, 12, 12, _rim, _rim, true);
    draw_roundrect_colour_ext(_x + 1, _y + 1, _x + _w - 1, _y + _h - 1, 11, 11, _rim, _rim, true);
    draw_set_alpha(0.55);
    var _in = _iron ? make_colour_rgb(214, 176, 96) : make_colour_rgb(120, 88, 44);
    draw_roundrect_colour_ext(_x + 4, _y + 4, _x + _w - 4, _y + _h - 4, 8, 8, _in, _in, true);
    draw_set_alpha(1);
}

/// @function bta__banner_draw(sc, spr, x, y, t, lean, alpha, w)  a banner on its pole; (x, y) = the bearer's feet
function bta__banner_draw(_sc, _spr, _x, _y, _t, _lean, _al, _w = 34) {
    var _poleH = 38, _tx = _x + _lean * 10, _ty = _y - _poleH;
    var _pc = make_colour_rgb(58, 38, 22);
    draw_set_alpha(_al);
    draw_line_width_colour(_x, _y - 2, _tx, _ty, 2, _pc, _pc);
    draw_line_width_colour(_x + 0.6, _y - 2, _tx + 0.6, _ty, 0.7, make_colour_rgb(122, 90, 56), make_colour_rgb(122, 90, 56));
    var _gc = make_colour_rgb(214, 176, 80);
    draw_triangle_colour(_tx, _ty - 6, _tx + 2.6, _ty - 1, _tx - 2.6, _ty - 1, _gc, _gc, _gc, false);
    draw_set_alpha(1);
    if (!sprite_exists(_spr)) return;
    var _sw = sprite_get_width(_spr), _sh = sprite_get_height(_spr), _N = 8, _k = _w / (_sw / 2);
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    for (var _i = 0; _i < _N; _i++) {
        var _u = _i / _N, _amp = 2.2 * (_u + 0.12);
        var _dy = sin(_t * 0.13 - _i * 0.8) * _amp, _sl = cos(_t * 0.13 - _i * 0.8);
        var _lum = clamp(0.86 + _sl * 0.14 * (_u + 0.2), 0, 1);
        var _col = make_colour_rgb(255 * _lum * _al, 255 * _lum * _al, 255 * _lum * _al);
        var _l = floor(_sw * _i / _N), _r2 = floor(_sw * (_i + 1) / _N);
        draw_sprite_part_ext(_spr, 0, _l, 0, _r2 - _l, _sh, _tx - 2 * _k / 2 + _l * _k / 2, _ty - 1 + _dy - 2 * _k / 2, _k / 2, _k / 2, _col, _al);
    }
    gpu_set_blendmode(bm_normal);
}

/// @function bta__scene_field(sc)  the field, the fallen, the living (sorted by depth), the banners, the shots, the effects
function bta__scene_field(_sc) {
    var _b = _sc.battle, _A = _sc.art.atlas, _n = _b.n, _i;
    draw_sprite_ext(_sc.art.field, 0, 0, 0, 1 / _sc.artScale, 1 / _sc.artScale, 0, c_white, 1);
    var _spr = _A.sprite, _cw = BTA_CELL_W * 2, _ch = BTA_CELL_H * 2;
    var _x = _b.x, _y = _b.y, _st = _b.state, _side = _b.side, _role = _b.role, _act = _b.act, _face = _b.face;
    var _tf = gpu_get_texfilter();
    gpu_set_texfilter(true);
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    // the fallen first: they lie under everyone still standing
    for (_i = 0; _i < _n; _i++) if (_st[_i] == BTA_DEAD) {
        var _fx = _x[_i] + BTA_FIELD_MID, _fy = _y[_i], _row = _side[_i] * 5 + _role[_i];
        if (_face[_i] >= 0) draw_sprite_part_ext(_spr, 0, BTA_FR_FALLEN * _cw, _row * _ch, _cw, _ch, _fx - BTA_CELL_CX, _fy - BTA_CELL_FOOT, 0.5, 0.5, c_white, 1);
        else draw_sprite_part_ext(_spr, 0, BTA_FR_FALLEN * _cw, _row * _ch, _cw, _ch, _fx + BTA_CELL_CX, _fy - BTA_CELL_FOOT, -0.5, 0.5, c_white, 1);
    }
    // depth sort by bucket (one row per field pixel), then draw back to front
    var _head = _sc.view.head, _next = _sc.view.next;
    for (_i = 0; _i < 400; _i++) _head[_i] = -1;
    for (_i = 0; _i < _n; _i++) {
        if (_st[_i] == BTA_DEAD || _st[_i] == BTA_FLED) continue;
        var _r = clamp(floor(_y[_i]) - 200, 0, 399);
        _next[_i] = _head[_r]; _head[_r] = _i;
    }
    var _t = _b.frame;
    for (var _r = 0; _r < 400; _r++) {
        var _j = _head[_r];
        while (_j >= 0) {
            var _fr = BTA_FR_STAND;
            if (_act[_j] < 12 && _st[_j] == BTA_ALIVE) _fr = BTA_FR_STRIKE;
            else if (_sc.view.moving[_j] || _st[_j] == BTA_ROUTING) _fr = ((((_t + _j * 7) div 9) mod 2) == 0) ? BTA_FR_STEP : BTA_FR_STAND;
            var _row2 = _side[_j] * 5 + _role[_j], _sx = _x[_j] + BTA_FIELD_MID, _sy = _y[_j];
            if (_face[_j] >= 0) draw_sprite_part_ext(_spr, 0, _fr * _cw, _row2 * _ch, _cw, _ch, _sx - BTA_CELL_CX, _sy - BTA_CELL_FOOT, 0.5, 0.5, c_white, 1);
            else draw_sprite_part_ext(_spr, 0, _fr * _cw, _row2 * _ch, _cw, _ch, _sx + BTA_CELL_CX, _sy - BTA_CELL_FOOT, -0.5, 0.5, c_white, 1);
            _j = _next[_j];
        }
    }
    gpu_set_blendmode(bm_normal);
    // banners: each regiment's colours over its bearer (the living figure nearest its centre); a broken regiment's lean
    for (var _g = 0; _g < array_length(_b.regs); _g++) {
        var _i0 = _b.regFig0[_g], _nn = _b.regFigN[_g], _cx = 0, _cy = 0, _c = 0, _rout = _b.regRouted[_g];
        for (_i = _i0; _i < _i0 + _nn; _i++) if (_st[_i] == BTA_ALIVE || _st[_i] == BTA_ROUTING) { _cx += _x[_i]; _cy += _y[_i]; _c++; }
        if (_c == 0) continue;
        _cx /= _c; _cy /= _c;
        var _best = -1, _bd = 1000000000;
        for (_i = _i0; _i < _i0 + _nn; _i++) if (_st[_i] == BTA_ALIVE || _st[_i] == BTA_ROUTING) { var _dd = sqr(_x[_i] - _cx) + sqr(_y[_i] - _cy - 14); if (_dd < _bd) { _bd = _dd; _best = _i; } }
        bta__banner_draw(_sc, _sc.banners[_g], _x[_best] + BTA_FIELD_MID, _y[_best] - 6, _t + _g * 13, _rout ? -1.2 * _face[_best] : 0, _rout ? 0.8 : 1);
    }
    // shots in flight: arrows on arcs, spells as glowing orbs
    var _soft = bta_soft_sprites();
    for (var _k = 0; _k < _b.pn; _k++) if (_b.plive[_k]) {
        var _u = _b.pt[_k] / _b.pT[_k], _x0 = _b.px0[_k] + BTA_FIELD_MID, _y0 = _b.py0[_k], _x1 = _b.px1[_k] + BTA_FIELD_MID, _y1 = _b.py1[_k];
        var _d = point_distance(_x0, _y0, _x1, _y1), _hgt = (_b.pkind[_k] == 1) ? _d * 0.28 : 18;
        var _ax = lerp(_x0, _x1, _u), _ay = lerp(_y0, _y1, _u) - sin(pi * _u) * _hgt;
        if (_b.pkind[_k] == 1) {
            var _vx = (_x1 - _x0), _vy = (_y1 - _y0) - pi * cos(pi * _u) * _hgt, _vl = max(0.001, sqrt(_vx * _vx + _vy * _vy));
            var _ux = _vx / _vl, _uy = _vy / _vl, _sh = make_colour_rgb(58, 42, 26), _tip = make_colour_rgb(216, 216, 208);
            draw_line_width_colour(_ax - _ux * 9, _ay - _uy * 9, _ax, _ay, 1.2, _sh, _sh);
            draw_line_width_colour(_ax, _ay, _ax + _ux * 2.5, _ay + _uy * 2.5, 1.6, _tip, _tip);
            draw_line_width_colour(_ax - _ux * 9, _ay - _uy * 9, _ax - _ux * 6.5, _ay - _uy * 6.5, 2.4, make_colour_rgb(232, 224, 208), make_colour_rgb(232, 224, 208));
            draw_set_alpha(0.18); draw_ellipse_colour(lerp(_x0, _x1, _u) - 3, lerp(_y0, _y1, _u) - 1, lerp(_x0, _x1, _u) + 3, lerp(_y0, _y1, _u) + 1, c_black, c_black, false); draw_set_alpha(1);
        } else {
            gpu_set_blendmode(bm_add);
            draw_sprite_ext(_soft.blob, 0, _ax, _ay, 0.42, 0.42, 0, make_colour_rgb(255, 170, 70), 0.9);
            draw_sprite_ext(_soft.blob, 0, _ax, _ay, 0.18, 0.18, 0, make_colour_rgb(255, 250, 220), 1);
            gpu_set_blendmode(bm_normal);
        }
    }
    bta__scene_fx(_sc);
    gpu_set_texfilter(_tf);
}

/// @function bta__scene_fx(sc)
function bta__scene_fx(_sc) {
    var _f = _sc.fx, _soft = bta_soft_sprites();
    for (var _i = 0; _i < _f.n; _i++) {
        var _k = _f.kind[_i];
        if (_k == 0) continue;
        var _u = _f.t[_i] / _f.life[_i], _x = _f.x[_i], _y = _f.y[_i];
        switch (_k) {
            case 1:   // the clash of arms: a white-gold glint
                gpu_set_blendmode(bm_add);
                draw_sprite_ext(_soft.spark, 0, _x, _y, 0.42 * (1 - _u * 0.5), 0.42 * (1 - _u * 0.5), _i * 37, make_colour_rgb(255, 240, 200), 1 - _u);
                gpu_set_blendmode(bm_normal);
                break;
            case 2:   // dust kicked up by a fall, a miss or a charge
                gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
                var _s2 = (0.22 + _u * 0.35) * (0.6 + _f.a[_i] * 0.6), _a2 = (1 - _u) * 0.55;
                draw_sprite_ext(_soft.blob, 0, _x, _y - _u * 6, _s2 * 1.3, _s2 * 0.8, 0, make_colour_rgb(200 * _a2, 180 * _a2, 146 * _a2), _a2);
                gpu_set_blendmode(bm_normal);
                break;
            case 3:   // a spell bursting: a flash, a fireball, a ring
                gpu_set_blendmode(bm_add);
                var _r = 8 + _u * 30;
                draw_sprite_ext(_soft.blob, 0, _x, _y - 4, _r / 24, _r / 32, 0, make_colour_rgb(255, 140, 60), (1 - _u) * 0.9);
                draw_sprite_ext(_soft.blob, 0, _x, _y - 4, _r / 60, _r / 70, 0, make_colour_rgb(255, 248, 220), (1 - _u));
                gpu_set_blendmode(bm_normal);
                draw_set_alpha((1 - _u) * 0.8); draw_ellipse_colour(_x - _r, _y - _r * 0.45, _x + _r, _y + _r * 0.45, make_colour_rgb(255, 230, 180), make_colour_rgb(255, 230, 180), true); draw_set_alpha(1);
                break;
            case 4:   // a regiment breaks: its name rises from where it stood
                var _a4 = (_u < 0.15) ? _u / 0.15 : ((_u > 0.75) ? (1 - _u) / 0.25 : 1);
                var _w4 = bta__txt_w(_f.txt[_i], 15, BTA_FACE_BODY) + 22;
                draw_set_alpha(0.72 * _a4); draw_roundrect_colour_ext(_x - _w4 / 2, _y - 12 - _u * 18, _x + _w4 / 2, _y + 10 - _u * 18, 8, 8, make_colour_rgb(34, 26, 20), make_colour_rgb(34, 26, 20), false); draw_set_alpha(1);
                bta__txt(_x, _y - 1 - _u * 18, _f.txt[_i], 15, BTA_FACE_BODY, (_f.a[_i] == 0) ? [196, 214, 255] : [255, 196, 182], _a4, fa_center);
                break;
            case 5:   // an arrow that missed, stuck in the ground
                var _a5 = (_u > 0.8) ? (1 - _u) / 0.2 : 1, _d = _f.a[_i], _sc5 = make_colour_rgb(70, 50, 32);
                draw_set_alpha(_a5); draw_line_width_colour(_x, _y, _x - _d * 3, _y - 6, 1, _sc5, _sc5); draw_line_width_colour(_x - _d * 3, _y - 6, _x - _d * 3.6, _y - 7.5, 2, make_colour_rgb(230, 222, 204), make_colour_rgb(230, 222, 204)); draw_set_alpha(1);
                break;
            case 6:   // a mage's staff flaring as it casts
                gpu_set_blendmode(bm_add);
                draw_sprite_ext(_soft.blob, 0, _x, _y, 0.3 * (1 - _u * 0.5), 0.3 * (1 - _u * 0.5), 0, make_colour_rgb(255, 215, 106), 1 - _u);
                gpu_set_blendmode(bm_normal);
                break;
        }
    }
}

/// @function bta__scene_hud(sc)  the strip across the top during the clash
function bta__scene_hud(_sc) {
    bta__plate(6, 4, 804, 44, "iron");
    var _b = _sc.battle;
    for (var _s = 0; _s < 2; _s++) {
        var _st = bta_battle_standing(_b, _s), _L = _sc.liveries[_s], _left = (_s == 0);
        var _bx = _left ? 18 : 798 - 34;
        if (array_length(_sc.banners) > 0) {
            var _bi = (_s == 0) ? 0 : array_length(_sc.armies[0]);
            if (_bi < array_length(_sc.banners) && sprite_exists(_sc.banners[_bi])) { gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); draw_sprite_ext(_sc.banners[_bi], 0, _bx, 10, 0.42, 0.42, 0, c_white, 1); gpu_set_blendmode(bm_normal); }
        }
        var _nx = _left ? 60 : 756;
        var _lab = string(_st.alive) + " OF " + string(_st.count) + " STAND";
        // the name takes what the count leaves (LOOKED AT 2026-10-29: "The Northern Muster" ran into "4428 OF 5100 STAND")
        var _room = 280 - bta__txt_w(_lab, 11, BTA_FACE_DISPLAY) - 14;
        bta__txt(_nx, 17, _sc.names[_s], bta__fit(_sc.names[_s], 17, BTA_FACE_DISPLAY, max(60, _room)), BTA_FACE_DISPLAY, [240, 228, 200], 1, _left ? fa_left : fa_right);
        bta__txt(_left ? 340 : 476, 17, _lab, 11, BTA_FACE_DISPLAY, [200, 182, 140], 0.95, _left ? fa_right : fa_left);
        // the bar: fighting (livery), fled (gold), fallen (dark)
        var _x0 = _left ? 60 : 466, _w = 290, _y0 = 31, _h = 9, _cnt = max(1, _st.count);
        draw_rectangle_colour(_x0, _y0, _x0 + _w, _y0 + _h, make_colour_rgb(20, 16, 14), make_colour_rgb(20, 16, 14), make_colour_rgb(20, 16, 14), make_colour_rgb(20, 16, 14), false);
        var _wa = _w * _st.alive / _cnt, _wf = _w * _st.fled / _cnt, _mc = bta__c(_L.main), _mh = bta__c(bta__shade(_L.main, 0.35));
        if (_left) {
            if (_wa > 0) draw_rectangle_colour(_x0, _y0, _x0 + _wa, _y0 + _h, _mh, _mh, _mc, _mc, false);
            if (_wf > 0) draw_rectangle_colour(_x0 + _wa, _y0, _x0 + _wa + _wf, _y0 + _h, make_colour_rgb(222, 180, 80), make_colour_rgb(222, 180, 80), make_colour_rgb(176, 136, 52), make_colour_rgb(176, 136, 52), false);
        } else {
            if (_wa > 0) draw_rectangle_colour(_x0 + _w - _wa, _y0, _x0 + _w, _y0 + _h, _mh, _mh, _mc, _mc, false);
            if (_wf > 0) draw_rectangle_colour(_x0 + _w - _wa - _wf, _y0, _x0 + _w - _wa, _y0 + _h, make_colour_rgb(222, 180, 80), make_colour_rgb(222, 180, 80), make_colour_rgb(176, 136, 52), make_colour_rgb(176, 136, 52), false);
        }
        draw_rectangle_colour(_x0, _y0, _x0 + _w, _y0 + _h, make_colour_rgb(150, 118, 64), make_colour_rgb(150, 118, 64), make_colour_rgb(150, 118, 64), make_colour_rgb(150, 118, 64), true);
    }
    // crossed swords and the time
    var _gc = make_colour_rgb(214, 176, 96);
    draw_line_width_colour(399, 13, 417, 27, 2, _gc, _gc); draw_line_width_colour(417, 13, 399, 27, 2, _gc, _gc);
    draw_line_width_colour(397, 23, 403, 29, 2, _gc, _gc); draw_line_width_colour(419, 23, 413, 29, 2, _gc, _gc);
    bta__txt(408, 38, string(floor(_b.frame / 60)) + " S", 10, BTA_FACE_DISPLAY, [200, 182, 140], 1, fa_center);
}

/// @function bta__diagram(form, cx, cy, w, h, rgb)  a formation drawn as dots, pointing right
function bta__diagram(_form, _cx, _cy, _w, _h, _rgb) {
    var _k = bta__c(_rgb), _pts = [];
    switch (_form) {
        case BTA_LINE: for (var _c = 0; _c < 3; _c++) for (var _r = 0; _r < 8; _r++) array_push(_pts, _cx - 8 + _c * 8, _cy - 28 + _r * 8); break;
        case BTA_WEDGE: var _row = 0, _wd = 1, _in = 0; for (var _i = 0; _i < 25; _i++) { array_push(_pts, _cx + 14 - _row * 7, _cy + (_in - (_wd - 1) / 2) * 7); _in++; if (_in >= _wd) { _row++; _wd += 2; _in = 0; } } break;
        case BTA_SQUARE: for (var _a = 0; _a < 6; _a++) for (var _b2 = 0; _b2 < 6; _b2++) array_push(_pts, _cx - 17 + _a * 7, _cy - 17 + _b2 * 7); break;
        case BTA_LOOSE: for (var _q = 0; _q < 14; _q++) array_push(_pts, _cx - 26 + bta__h2(_q, 1, 7) * 52, _cy - 24 + bta__h2(_q, 2, 7) * 48); break;
    }
    if (_form == BTA_SQUARE) draw_rectangle_colour(_cx - 22, _cy - 22, _cx + 22, _cy + 22, _k, _k, _k, _k, true);
    for (var _p = 0; _p < array_length(_pts); _p += 2) draw_circle_colour(_pts[_p], _pts[_p + 1], 2.6, _k, _k, false);
}

/// @function bta__wrap(str, maxW, px, face)  word-wrapped lines
function bta__wrap(_s, _maxW, _px, _face) {
    var _words = string_split(_s, " "), _lines = [], _ln = "";
    for (var _i = 0; _i < array_length(_words); _i++) {
        var _t = (_ln == "") ? _words[_i] : _ln + " " + _words[_i];
        if (bta__txt_w(_t, _px, _face) > _maxW && _ln != "") { array_push(_lines, _ln); _ln = _words[_i]; } else _ln = _t;
    }
    if (_ln != "") array_push(_lines, _ln);
    return _lines;
}

/// @function bta__scene_cards(sc)  the note and the four formation cards
function bta__scene_cards(_sc) {
    var _F = bta_forms(), _note = _sc.showEnemy ? _sc.enemyNote : "Choose your order.";
    var _nw = bta__txt_w(_note, 17, BTA_FACE_BODY) + 44;
    bta__plate(408 - _nw / 2, 6, _nw, 34, "iron");
    bta__txt(408, 23, _note, 17, BTA_FACE_BODY, [240, 228, 200], 1, fa_center);
    for (var _i = 0; _i < 4; _i++) {
        var _r = bta__card_rect(_i), _hov = (_sc.hover == _i), _lift = _hov ? -6 : 0;
        var _x = _r[0], _y = _r[1] + _lift, _w = _r[2], _h = _r[3];
        bta__plate(_x, _y, _w, _h, "parch", 31 + _i);
        if (_hov) {
            var _gc = make_colour_rgb(214, 168, 64);
            draw_roundrect_colour_ext(_x - 2, _y - 2, _x + _w + 2, _y + _h + 2, 13, 13, _gc, _gc, true);
            draw_roundrect_colour_ext(_x - 3, _y - 3, _x + _w + 3, _y + _h + 3, 14, 14, _gc, _gc, true);
        }
        bta__diagram(_i, _x + _w / 2, _y + 40, 60, 56, _sc.liveries[0].dark);
        bta__txt(_x + _w / 2, _y + 84, string_upper(_F[_i].label), 20, BTA_FACE_DISPLAY, [42, 29, 18], 1, fa_center);
        bta__txt(_x + _w / 2, _y + 102, "beats " + _F[_F[_i].beats].label, 13, BTA_FACE_BODY, [110, 80, 46], 1, fa_center);
        var _ln = bta__wrap(_F[_i].motto, _w - 20, 12, BTA_FACE_BODY);
        for (var _l = 0; _l < min(2, array_length(_ln)); _l++) bta__txt(_x + _w / 2, _y + 120 + _l * 14, _ln[_l], 12, BTA_FACE_BODY, [58, 42, 26], 1, fa_center);
        if (_sc.showEnemy && _i == _sc.enemyForm) {
            var _tc = make_colour_rgb(150, 34, 26);
            draw_roundrect_colour_ext(_x + _w - 76, _y + 6, _x + _w - 6, _y + 22, 6, 6, _tc, _tc, false);
            bta__txt(_x + _w - 41, _y + 14, "THEIR ORDER", 9, BTA_FACE_DISPLAY, [255, 236, 220], 1, fa_center);
        }
    }
}

/// @function bta__scene_title(sc)  the call to arms on a hanging board
function bta__scene_title(_sc, _a) {
    var _w = 520, _h = 96, _x = 408 - _w / 2, _y = 236;
    draw_set_alpha(_a);
    var _rc = make_colour_rgb(70, 52, 34);
    draw_line_width_colour(_x + 60, _y - 60, _x + 60, _y + 2, 2, _rc, _rc); draw_line_width_colour(_x + _w - 60, _y - 60, _x + _w - 60, _y + 2, 2, _rc, _rc);
    draw_set_alpha(1);
    bta__plate(_x, _y, _w, _h, "parch", 5);
    var _ts = bta__fit(_sc.title, 34, BTA_FACE_DISPLAY, _w - 40);
    bta__txt(408, _y + 38, _sc.title, _ts, BTA_FACE_DISPLAY, [42, 29, 18], _a, fa_center);
    bta__txt(408, _y + 72, _sc.names[0] + "  against  " + _sc.names[1], 16, BTA_FACE_BODY, [110, 80, 46], _a, fa_center);
}

/// @function bta__scene_record(sc)  the war record: verdict, every regiment, the course of the battle, the totals
function bta__scene_record(_sc) {
    var _R = bta_scene_result(_sc), _x = 40, _y = 28, _w = 736, _h = 570;
    bta__plate(_x, _y, _w, _h, "parch", 77);
    var _v = (_R.winner == 0) ? "VICTORY" : ((_R.winner == 1) ? "DEFEAT" : "NEITHER HOLDS THE FIELD");
    bta__txt(408, _y + 42, _v, bta__fit(_v, 46, BTA_FACE_DISPLAY, 600), BTA_FACE_DISPLAY, [42, 29, 18], 1, fa_center);
    var _F = bta_forms(), _sub = _sc.title + "  -  " + string(_R.seconds) + " seconds  -  " + _F[bta_form_id(_R.forms[0])].label + " against " + _F[bta_form_id(_R.forms[1])].label;
    bta__txt(408, _y + 80, _sub, bta__fit(_sub, 15, BTA_FACE_BODY, 640), BTA_FACE_BODY, [110, 80, 46], 1, fa_center);
    var _lc = make_colour_rgb(150, 112, 62);
    draw_line_width_colour(_x + 30, _y + 98, _x + _w - 30, _y + 98, 1, _lc, _lc);
    // the regiments, two columns
    var _rows = [0, 0], _ri = 0;
    for (var _s = 0; _s < 2; _s++) {
        var _cx = (_s == 0) ? _x + 34 : _x + 372, _L = _sc.liveries[_s];
        bta__txt(_cx, _y + 116, _sc.names[_s], 17, BTA_FACE_DISPLAY, bta__shade(_L.main, -0.2), 1);
    }
    for (var _g = 0; _g < array_length(_R.regiments); _g++) {
        var _rg = _R.regiments[_g], _s2 = _rg.side, _k = _rows[_s2];
        _rows[_s2]++;
        if (_k >= 6) continue;
        var _cx2 = (_s2 == 0) ? _x + 34 : _x + 372, _ry = _y + 140 + _k * 30;
        if (_g < array_length(_sc.banners) && sprite_exists(_sc.banners[_g])) { gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); draw_sprite_ext(_sc.banners[_g], 0, _cx2, _ry - 9, 0.34, 0.34, 0, c_white, 1); gpu_set_blendmode(bm_normal); }
        bta__txt(_cx2 + 30, _ry - 3, _rg.name, bta__fit(_rg.name, 15, BTA_FACE_BODY, 150), BTA_FACE_BODY, [42, 29, 18], 1);
        bta__txt(_cx2 + 30, _ry + 10, _rg.role + (_rg.routed ? "  -  routed" : ""), 11, BTA_FACE_BODY, [120, 92, 60], 1);
        var _bx = _cx2 + 186, _bw = 120, _cnt = max(1, _rg.count), _mc = bta__c(_sc.liveries[_s2].main);
        draw_rectangle_colour(_bx, _ry - 4, _bx + _bw, _ry + 4, make_colour_rgb(86, 72, 58), make_colour_rgb(86, 72, 58), make_colour_rgb(70, 58, 46), make_colour_rgb(70, 58, 46), false);
        var _wa = _bw * _rg.survived / _cnt, _wf = _bw * _rg.fled / _cnt;
        if (_wa > 0) draw_rectangle_colour(_bx, _ry - 4, _bx + _wa, _ry + 4, _mc, _mc, _mc, _mc, false);
        if (_wf > 0) draw_rectangle_colour(_bx + _wa, _ry - 4, _bx + _wa + _wf, _ry + 4, make_colour_rgb(212, 170, 72), make_colour_rgb(212, 170, 72), make_colour_rgb(212, 170, 72), make_colour_rgb(212, 170, 72), false);
        bta__txt(_bx + _bw, _ry + 13, string(_rg.survived) + " / " + string(_rg.count), 10, BTA_FACE_DISPLAY, [58, 42, 26], 1, fa_right);
    }
    // the course of the battle
    var _gx = _x + 40, _gy = _y + 336, _gw = _w - 80, _gh = 150;
    bta__txt(_gx, _gy - 14, "THE COURSE OF THE BATTLE", 12, BTA_FACE_DISPLAY, [110, 80, 46], 1);
    draw_set_alpha(0.25); draw_rectangle_colour(_gx, _gy, _gx + _gw, _gy + _gh, make_colour_rgb(150, 120, 80), make_colour_rgb(150, 120, 80), make_colour_rgb(150, 120, 80), make_colour_rgb(150, 120, 80), false); draw_set_alpha(1);
    for (var _q = 0; _q <= 4; _q++) { var _ly = _gy + _gh * _q / 4; draw_set_alpha(0.35); draw_line_width_colour(_gx, _ly, _gx + _gw, _ly, 1, _lc, _lc); draw_set_alpha(1); }
    bta__txt(_gx - 6, _gy, "ALL", 9, BTA_FACE_DISPLAY, [110, 80, 46], 1, fa_right); bta__txt(_gx - 6, _gy + _gh / 2, "HALF", 9, BTA_FACE_DISPLAY, [110, 80, 46], 1, fa_right); bta__txt(_gx - 6, _gy + _gh, "NONE", 9, BTA_FACE_DISPLAY, [110, 80, 46], 1, fa_right);
    var _H = _sc.hist, _n = _H.n, _T = max(1, (_n - 1) * 0.5);
    for (var _s3 = 0; _s3 < 2; _s3++) {
        var _arr = (_s3 == 0) ? _H.s0 : _H.s1, _col = bta__c(bta__shade(_sc.liveries[_s3].main, -0.1));
        for (var _p = 1; _p < _n; _p++) draw_line_width_colour(_gx + _gw * (_p - 1) * 0.5 / _T, _gy + _gh * (1 - _arr[_p - 1]), _gx + _gw * _p * 0.5 / _T, _gy + _gh * (1 - _arr[_p]), 2.4, _col, _col);
    }
    // rout markers; each label takes the first place near its marker that no earlier label holds (LOOKED AT 2026-10-29:
    // "Harrow broke" printed over "Duskriders broke"); a label with no free place is left off and its marker kept
    var _placed = [];
    for (var _m = 0; _m < min(10, array_length(_H.routs)); _m++) {
        var _ro = _H.routs[_m], _mx = _gx + _gw * clamp(_ro.t / _T, 0, 1), _arr2 = (_ro.side == 0) ? _H.s0 : _H.s1;
        var _ix = clamp(round(_ro.t * 2), 0, max(0, _n - 1)), _my = _gy + _gh * (1 - ((_n > 0) ? _arr2[_ix] : 1));
        var _mk = bta__c(bta__shade(_sc.liveries[_ro.side].main, -0.3));
        draw_triangle_colour(_mx, _my - 6, _mx - 4, _my + 1, _mx + 4, _my + 1, _mk, _mk, _mk, false);
        var _lt = _ro.name + " broke", _lw = bta__txt_w(_lt, 10, BTA_FACE_BODY) + 6, _offs = [-13, 13, -25, 25, -37, 37];
        var _lx = clamp(_mx, _gx + _lw / 2, _gx + _gw - _lw / 2);
        for (var _o = 0; _o < 6; _o++) {
            var _ly = _my + _offs[_o], _free = (_ly > _gy + 4 && _ly < _gy + _gh - 4);
            for (var _pp = 0; _pp < array_length(_placed) && _free; _pp++) { var _pr = _placed[_pp]; if (abs(_pr[0] - _lx) < (_pr[2] + _lw) / 2 && abs(_pr[1] - _ly) < 12) _free = false; }
            if (_free) { bta__txt(_lx, _ly, _lt, 10, BTA_FACE_BODY, [70, 50, 30], 1, fa_center); array_push(_placed, [_lx, _ly, _lw]); break; }
        }
    }
    // time ticks on round seconds
    var _steps = [1, 2, 5, 10, 15, 30, 60], _st2 = 60;
    for (var _si = 0; _si < 7; _si++) if (_T / _steps[_si] <= 6) { _st2 = _steps[_si]; break; }
    for (var _tk = 0; _tk * _st2 <= _T + 0.001; _tk++) bta__txt(_gx + _gw * _tk * _st2 / _T, _gy + _gh + 10, string(_tk * _st2) + "S", 9, BTA_FACE_DISPLAY, [110, 80, 46], 1, fa_center);
    // totals
    draw_line_width_colour(_x + 30, _y + _h - 62, _x + _w - 30, _y + _h - 62, 1, _lc, _lc);
    for (var _s4 = 0; _s4 < 2; _s4++) {
        var _sd = _R.sides[_s4], _tx = string(_sd.survived) + " STAND  -  " + string(_sd.fled) + " FLED  -  " + string(_sd.dead) + " FELL";
        bta__txt((_s4 == 0) ? _x + 34 : _x + _w - 34, _y + _h - 40, _tx, 13, BTA_FACE_DISPLAY, [42, 29, 18], 1, (_s4 == 0) ? fa_left : fa_right);
    }
    bta__txt(408, _y + _h - 16, "coloured: stood  -  gold: fled the field  -  dark: fell", 11, BTA_FACE_BODY, [120, 92, 60], 1, fa_center);
}

/// @function bta_scene_draw(scene, x, y, scale)
/// @description Draw the scene with its 816 x 624 frame's top-left at (x, y), scaled by `scale`. Works in Draw or Draw GUI.
/// The caller's world matrix, blend, alpha, colour, font and alignment are handed back as they were.
function bta_scene_draw(_sc, _x = 0, _y = 0, _scale = 1) {
    if (!is_struct(_sc) || !variable_struct_exists(_sc, "phase") || !is_struct(_sc.art)) return;
    _scale = bta__num(_scale, 1); if (_scale <= 0) _scale = 1;
    _sc.drawX = bta__num(_x, 0); _sc.drawY = bta__num(_y, 0); _sc.drawScale = _scale;
    var _mPrev = matrix_get(matrix_world), _pf = draw_get_font(), _ph = draw_get_halign(), _pv = draw_get_valign(), _pa = draw_get_alpha(), _pc = draw_get_colour();
    gpu_push_state();
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false); gpu_set_cullmode(cull_noculling);
    matrix_set(matrix_world, matrix_multiply(bta__affine(_scale, 0, 0, _scale, _sc.drawX, _sc.drawY), _mPrev));
    gpu_set_blendmode(bm_normal);
    var _cp = draw_get_circle_precision();
    draw_set_circle_precision(16);
    bta__scene_field(_sc);
    switch (_sc.phase) {
        case BTA_PHASE_TITLE: bta__scene_title(_sc, min(1, _sc.t / 12)); break;
        case BTA_PHASE_CHOOSE: bta__scene_cards(_sc); break;
        case BTA_PHASE_CLASH: bta__scene_hud(_sc); break;
        case BTA_PHASE_RECORD: case BTA_PHASE_DONE: bta__scene_hud(_sc); bta__scene_record(_sc); break;
    }
    draw_set_circle_precision(_cp);
    gpu_pop_state();
    matrix_set(matrix_world, _mPrev);
    draw_set_font(_pf); draw_set_halign(_ph); draw_set_valign(_pv); draw_set_alpha(_pa); draw_set_colour(_pc);
}
