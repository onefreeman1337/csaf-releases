/// bta_selftest.gml - Battalia's headless in-engine suite. Run the demo with -selftest: the result is written as
/// bta_selftest.json in the game's save folder and the renders (bta_render_*.png) beside it, to be LOOKED at.
/// Counts the work, never only the verdict: every arm records how many things it exercised.
///
/// Battalia - Army Battles for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function bta_st_assert(st, cond, msg)
function bta_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 60) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
/// @function bta_st_stage(st, n)
function bta_st_stage(_st, _n) { _st.stage = _n; global.bta_stage = _n; }

/// @function bta__st_rgba(surface)  the whole surface read into a buffer (RGBA bytes); caller deletes it
function bta__st_rgba(_s) { var _b = buffer_create(surface_get_width(_s) * surface_get_height(_s) * 4, buffer_fixed, 1); buffer_get_surface(_b, _s, 0); return _b; }
/// @function bta__st_ink(surface, x, y, w, h)  pixels with alpha > 0 inside a rectangle
function bta__st_ink(_s, _x, _y, _w, _h) {
    var _sw = surface_get_width(_s), _sh = surface_get_height(_s), _b = bta__st_rgba(_s), _n = 0;
    for (var _yy = max(0, _y); _yy < min(_sh, _y + _h); _yy++) for (var _xx = max(0, _x); _xx < min(_sw, _x + _w); _xx++) if (buffer_peek(_b, (_yy * _sw + _xx) * 4 + 3, buffer_u8) > 0) _n++;
    buffer_delete(_b);
    return _n;
}
/// @function bta__st_diff(a, b, x, y, w, h, tol)  pixels whose largest RGB channel differs by more than tol
function bta__st_diff(_a, _b2, _x, _y, _w, _h, _tol) {
    var _sw = surface_get_width(_a), _sh = surface_get_height(_a), _ba = bta__st_rgba(_a), _bb = bta__st_rgba(_b2), _n = 0;
    for (var _yy = max(0, _y); _yy < min(_sh, _y + _h); _yy++) for (var _xx = max(0, _x); _xx < min(_sw, _x + _w); _xx++) {
        var _o = (_yy * _sw + _xx) * 4;
        if (abs(buffer_peek(_ba, _o, buffer_u8) - buffer_peek(_bb, _o, buffer_u8)) > _tol || abs(buffer_peek(_ba, _o + 1, buffer_u8) - buffer_peek(_bb, _o + 1, buffer_u8)) > _tol || abs(buffer_peek(_ba, _o + 2, buffer_u8) - buffer_peek(_bb, _o + 2, buffer_u8)) > _tol) _n++;
    }
    buffer_delete(_ba); buffer_delete(_bb);
    return _n;
}
/// @function bta__st_sprite_ink(sprite, x, y, w, h)  alpha>0 pixels of a sprite region (drawn 1:1 onto a cleared surface)
function bta__st_sprite_ink(_spr, _x, _y, _w, _h) {
    var _s = surface_create(max(1, _w), max(1, _h));
    surface_set_target(_s); draw_clear_alpha(c_black, 0);
    gpu_set_blendmode_ext(bm_one, bm_zero);
    draw_sprite_part(_spr, 0, _x, _y, _w, _h, 0, 0);
    gpu_set_blendmode(bm_normal);
    surface_reset_target();
    var _n = bta__st_ink(_s, 0, 0, _w, _h);
    surface_free(_s);
    return _n;
}
/// @function bta__st_battle(pa, pb, f0, f1, seed)  run a battle headless, return its result
function bta__st_battle(_pa, _pb, _f0, _f1, _seed) { var _b = bta_battle_create({ seed: _seed, armies: [_pa, _pb], forms: [_f0, _f1] }); bta_battle_run(_b); return bta_battle_result(_b); }

/// @function bta_selftest_run()
/// @description Run the whole suite and return its state { pass, fail, total, stage, failures, ... }.
function bta_selftest_run() {
    var _st = { pass: 0, fail: 0, total: 0, stage: 0, failures: [], runtime: GM_runtime_version, epsilon: math_get_epsilon(), counts: {}, timing: {}, balance: {}, renders: [], notes: [] };
    var _i, _j, _k;

    // 1. the generator: deterministic, in range, uniform, and nearby seeds do not deal nearby first draws
    bta_st_stage(_st, 1);
    var _g1 = bta_rng(42), _g2 = bta_rng(42), _same = true, _lo = 1, _hi = 0, _sum = 0;
    for (_i = 0; _i < 20000; _i++) { var _u1 = bta_rnd(_g1), _u2 = bta_rnd(_g2); if (_u1 != _u2) _same = false; _lo = min(_lo, _u1); _hi = max(_hi, _u1); _sum += _u1; }
    bta_st_assert(_st, _same, "same seed, same 20,000 draws");
    bta_st_assert(_st, _lo >= 0 && _hi < 1, "draws in [0,1): " + string(_lo) + ".." + string(_hi));
    bta_st_assert(_st, abs(_sum / 20000 - 0.5) < 0.01, "mean of 20,000 draws near 0.5: " + string(_sum / 20000));
    var _flo = 1, _fhi = 0, _buckets = array_create(10, 0);
    for (_i = 1; _i <= 200; _i++) { var _f = bta_rnd(bta_rng(_i)); _flo = min(_flo, _f); _fhi = max(_fhi, _f); _buckets[min(9, floor(_f * 10))]++; }
    var _emptyB = 0; for (_i = 0; _i < 10; _i++) if (_buckets[_i] == 0) _emptyB++;
    bta_st_assert(_st, _fhi - _flo > 0.9 && _emptyB == 0, "first draw over seeds 1..200 spans the unit interval (" + string(_flo) + ".." + string(_fhi) + ", empty deciles " + string(_emptyB) + ")");
    bta_st_assert(_st, bta_hash("Iron Company") == bta_hash("Iron Company") && bta_hash("Iron Company") != bta_hash("Iron company"), "hash is a function of the bytes");

    // 2. armies from a spec line
    bta_st_stage(_st, 2);
    var _a = bta_army("foot:40:Shield_Men, archer:30:Bowmen:1.5, horse:20, dragon:5:Nope, foot:0:Empty, foot:abc:Bad, pike");
    bta_st_assert(_st, array_length(_a) == 3, "spec keeps 3 good regiments of 7: got " + string(array_length(_a)));
    if (array_length(_a) == 3) {
        bta_st_assert(_st, _a[0].name == "Shield Men" && _a[0].count == 40 && _a[0].role == "foot", "underscores become spaces; count and role read");
        bta_st_assert(_st, _a[1].strength == 1.5 && _a[1].role == "archer", "strength read");
        bta_st_assert(_st, _a[2].name == "" && _a[2].count == 20 && _a[2].strength == 1, "optional fields default");
    }
    var _nz = bta__normalize(_a, 0);
    bta_st_assert(_st, array_length(_nz) == 3 && _nz[2].name == "Horse 3", "a blank name becomes the arm and its place: " + ((array_length(_nz) == 3) ? _nz[2].name : "?"));
    var _nz2 = bta__normalize([{ name: "X", role: "wizard", count: 5, strength: 99 }, { role: "pike", count: -3 }, "junk", undefined], 1);
    bta_st_assert(_st, array_length(_nz2) == 1 && _nz2[0].role == "foot" && _nz2[0].strength == 4, "unknown role becomes foot, strength clamps to 4, junk dropped");
    bta_st_assert(_st, array_length(bta_army(undefined)) == 0 && array_length(bta_army(12)) == 0 && array_length(bta_army("")) == 0, "a non-spec gives an empty army");

    // 3. deployment: figures, the cap, both halves of the field
    bta_st_stage(_st, 3);
    var _b = bta_battle_create({ seed: 5, armies: ["foot:3000:Horde, archer:2000:Bows", "foot:40:Few"], forms: ["square", "wedge"] });
    var _f0 = 0, _f1 = 0, _inside = true, _halves = true;
    for (_i = 0; _i < _b.n; _i++) {
        if (_b.side[_i] == 0) _f0++; else _f1++;
        if (_b.y[_i] < BTA_FIELD_TOP || _b.y[_i] > BTA_FIELD_BOTTOM || abs(_b.x[_i]) > BTA_FIELD_MID) _inside = false;
        if ((_b.side[_i] == 0 && _b.x[_i] >= 0) || (_b.side[_i] == 1 && _b.x[_i] <= 0)) _halves = false;
    }
    bta_st_assert(_st, _f0 == 240 && _f1 == 40, "5,000 soldiers carried by 240 figures; 40 by 40: got " + string(_f0) + " / " + string(_f1));
    bta_st_assert(_st, abs(_b.regs[0].rep - 3000 / _b.regs[0].figures) < 0.0001, "rep = soldiers per figure");
    bta_st_assert(_st, _inside && _halves, "every figure inside the field and on its own half");
    bta_st_assert(_st, _b.forms[0] == BTA_SQUARE && _b.forms[1] == BTA_WEDGE, "formations by name");
    var _st0 = bta_battle_standing(_b, 0);
    bta_st_assert(_st, _st0.count == 5000 && _st0.alive == 5000 && _st0.dead == 0, "standing before a blow: 5000 of 5000");
    var _empty = bta_battle_create({ seed: 1, armies: ["", "foot:10:A"] });
    bta_st_assert(_st, _empty.over && _empty.winner == 1, "an empty army loses at once without a step");

    // 4. a whole battle: deterministic, accounted to the soldier
    bta_st_stage(_st, 4);
    var _PA = "foot:44:Iron Company, pike:32:Black Pikes, archer:34:Rivermarch Bows, horse:16:Queen's Own, mage:8:Ember Magi";
    var _PB = "foot:50:Crowfoot, foot:30:Harrow, archer:30:Sunspears, horse:20:Duskriders, mage:8:Ashen Guard";
    var _t0 = get_timer();
    var _r1 = bta__st_battle(_PA, _PB, "square", "wedge", 77);
    var _tBattle = (get_timer() - _t0) / 1000;
    var _r2 = bta__st_battle(_PA, _PB, "square", "wedge", 77);
    var _identical = (_r1.winner == _r2.winner && _r1.frames == _r2.frames);
    for (_i = 0; _i < array_length(_r1.regiments); _i++) if (_r1.regiments[_i].survived != _r2.regiments[_i].survived || _r1.regiments[_i].dead != _r2.regiments[_i].dead) _identical = false;
    bta_st_assert(_st, _identical, "same armies, forms and seed: the same battle to the soldier");
    _st.timing.battleMs = _tBattle; _st.timing.battleFrames = _r1.frames;
    bta_st_assert(_st, _r1.frames > 60 && _r1.frames <= 3610, "the battle ends inside its time limit: " + string(_r1.frames) + " frames");
    var _acct = 0, _acctBad = 0;
    var _sizes = ["foot:7:A", "foot:5000:B, horse:777:C", "archer:333:D, mage:41:E", "pike:99999:F", "horse:1:G, foot:2:H, mage:3:I"];
    for (_i = 0; _i < 10; _i++) {
        var _rr = bta__st_battle(_sizes[_i mod 5], _sizes[(_i + 2) mod 5], bta_form_name(_i mod 4), bta_form_name((_i + 1) mod 4), 100 + _i);
        for (_j = 0; _j < array_length(_rr.regiments); _j++) { var _g = _rr.regiments[_j]; _acct++; if (_g.survived + _g.fled + _g.dead != _g.count || _g.survived < 0 || _g.fled < 0 || _g.dead < 0) _acctBad++; }
        for (_j = 0; _j < 2; _j++) { var _sd = _rr.sides[_j]; if (_sd.survived + _sd.fled + _sd.dead != _sd.count) _acctBad++; }
    }
    bta_st_assert(_st, _acct >= 20 && _acctBad == 0, "survived + fled + dead = count for " + string(_acct) + " regiments over 10 battles up to 99,999 soldiers (bad " + string(_acctBad) + ")");
    _st.counts.accountedRegiments = _acct;
    // the grid's nearest-enemy search is EXACT: against a scan of every figure, at four moments of a 480-figure battle
    var _ob = bta_battle_create({ seed: 9, armies: ["foot:120:A, pike:60:B, archer:40:C, horse:20:D", "foot:120:E, pike:60:F, archer:40:G, horse:20:H"], forms: ["loose", "wedge"] });
    var _queries = 0, _mism = 0, _far = 0, _moments = [1, 240, 420, 600];
    for (var _m = 0; _m < 4; _m++) {
        while (_ob.frame < _moments[_m] && !_ob.over) bta_battle_step(_ob);
        bta__grid(_ob);
        for (_i = 0; _i < _ob.n; _i++) {
            if (_ob.state[_i] != BTA_ALIVE) continue;
            var _gj = bta__nearest_enemy(_ob, _i), _bj = -1, _bdd = 1000000000000;
            for (_j = 0; _j < _ob.n; _j++) if (_ob.side[_j] != _ob.side[_i] && _ob.state[_j] == BTA_ALIVE) { var _dd2 = sqr(_ob.x[_j] - _ob.x[_i]) + sqr(_ob.y[_j] - _ob.y[_i]); if (_dd2 < _bdd) { _bdd = _dd2; _bj = _j; } }
            _queries++;
            if ((_gj < 0) != (_bj < 0)) _mism++;
            else if (_gj >= 0) { var _gd = sqr(_ob.x[_gj] - _ob.x[_i]) + sqr(_ob.y[_gj] - _ob.y[_i]); if (abs(_gd - _bdd) > 0.0001) _mism++; if (_bdd > sqr(32)) _far++; }
        }
    }
    _st.counts.nearestQueries = _queries; _st.counts.nearestFarQueries = _far;
    bta_st_assert(_st, _queries > 1000 && _mism == 0, "grid nearest = brute-force nearest for " + string(_queries) + " queries (" + string(_far) + " beyond the 32 px ring search), mismatches " + string(_mism));
    bta_st_assert(_st, _far > 0 && _far < _queries, "both the ring search and its full-scan fallback were exercised");
    var _diff = false, _r3 = bta__st_battle(_PA, _PB, "square", "wedge", 78);
    if (_r3.frames != _r1.frames || _r3.sides[0].dead != _r1.sides[0].dead) _diff = true;
    bta_st_assert(_st, _diff, "another seed is another battle");

    // 5. balance: identical armies split fairly; the counter-formation turns a smaller army's odds (counts of WINS, never !won)
    bta_st_stage(_st, 5);
    var _M = "foot:24:A, archer:12:B", _wl = 0, _wr = 0, _wn = 0, _N = 30;
    _t0 = get_timer();
    for (_i = 0; _i < _N; _i++) { var _rm = bta__st_battle(_M, _M, "line", "line", 500 + _i); if (_rm.winner == 0) _wl++; else if (_rm.winner == 1) _wr++; else _wn++; }
    _st.timing.mirrorBattleMs = (get_timer() - _t0) / 1000 / _N;
    _st.balance.mirror = { left: _wl, right: _wr, neither: _wn, battles: _N };
    bta_st_assert(_st, _wl >= 6 && _wr >= 6, "mirror battles split: left " + string(_wl) + ", right " + string(_wr) + ", neither " + string(_wn) + " of " + string(_N));
    var _P8 = "foot:32:A", _E10 = "foot:40:B", _cw = 0, _cc = 0, _NB = 20;
    for (_i = 0; _i < _NB; _i++) {
        if (bta__st_battle(_P8, _E10, "wedge", "line", 900 + _i).winner == 0) _cw++;   // the counter to a line
        if (bta__st_battle(_P8, _E10, "line", "line", 900 + _i).winner == 0) _cc++;    // copying the enemy
    }
    _st.balance.counter = { wedgeVsLineWins: _cw, lineVsLineWins: _cc, battles: _NB, note: "player 32 foot against 40 foot" };
    bta_st_assert(_st, _cw > _cc, "the counter (wedge against a line) wins more for the smaller army than copying: " + string(_cw) + " vs " + string(_cc) + " of " + string(_NB));
    var _sq = 0, _NS = 16;
    for (_i = 0; _i < _NS; _i++) if (bta__st_battle("pike:30:Pikes", "horse:20:Riders", "square", "wedge", 1300 + _i).winner == 0) _sq++;
    _st.balance.pikesSquareVsHorseWedge = { wins: _sq, battles: _NS };
    bta_st_assert(_st, _sq >= _NS / 2, "pikes in square stop horse in wedge: " + string(_sq) + " of " + string(_NS));
    var _routs = 0, _ev = 0;
    var _bb = bta_battle_create({ seed: 3, armies: [_PA, _PB], forms: ["line", "line"] });
    while (!_bb.over) { bta_battle_step(_bb); for (_k = 0; _k < _bb.evN; _k++) { _ev++; if (_bb.evType[_k] == BTA_EV_ROUT) _routs++; } }
    _st.counts.events = _ev; _st.counts.routs = _routs;
    bta_st_assert(_st, _ev > 500 && _routs >= 1, "a full battle emits events and at least one regiment breaks: " + string(_ev) + " events, " + string(_routs) + " routs");

    // 6. the enemy's own choice of formation
    bta_st_stage(_st, 6);
    var _ef = [bta_enemy_formation("archer:60:A, mage:10:B, foot:10:C", 1), bta_enemy_formation("horse:50:A, foot:20:B", 1), bta_enemy_formation("pike:50:A, foot:20:B", 1)];
    var _efOk = true, _want = ["loose", "wedge", "square"], _hits = [0, 0, 0], _specs = ["archer:60:A, mage:10:B, foot:10:C", "horse:50:A, foot:20:B", "pike:50:A, foot:20:B"];
    for (_j = 0; _j < 3; _j++) for (_i = 0; _i < 40; _i++) {
        var _e = bta_enemy_formation(_specs[_j], _i);
        if (_e != _want[_j] && _e != "line") _efOk = false;
        if (_e == _want[_j]) _hits[_j]++;
    }
    bta_st_assert(_st, _efOk && _hits[0] >= 18 && _hits[1] >= 18 && _hits[2] >= 18, "bows go loose, riders wedge, pikes square (or a line): " + string(_hits[0]) + "/" + string(_hits[1]) + "/" + string(_hits[2]) + " of 40");
    bta_st_assert(_st, bta_enemy_formation("", 1) == "line", "an empty army forms a line");

    // 7. heraldry: a name always flies the same arms; 60 names fly many; the rule of tincture holds
    bta_st_stage(_st, 7);
    var _keys = {}, _distinct = 0, _tinct = true, _names = 60;
    for (_i = 0; _i < _names; _i++) {
        var _nm = "Regiment " + string(_i), _h1 = bta_heraldry(_nm, _i mod 2), _h2 = bta_heraldry(_nm, _i mod 2);
        if (_h1.key != _h2.key || _h1.shape != _h2.shape) _tinct = false;
        if (!variable_struct_exists(_keys, _h1.key)) { _keys[$ _h1.key] = 1; _distinct++; }
        var _fm = (_h1.fieldId == "or" || _h1.fieldId == "argent"), _om = (_h1.otherId == "or" || _h1.otherId == "argent");
        if (_fm == _om) _tinct = false;
    }
    _st.counts.heraldryDistinct = _distinct;
    bta_st_assert(_st, _tinct, "same name same arms, and a metal always meets a colour");
    bta_st_assert(_st, _distinct >= 54, "60 regiment names fly " + string(_distinct) + " distinct arms");

    // 8. the soldier atlas: ink in every one of 40 cells, the poses differ, the two liveries differ
    bta_st_stage(_st, 8);
    _t0 = get_timer();
    var _A = bta_soldier_atlas(bta_livery(0), bta_livery(1));
    _st.timing.atlasMs = (get_timer() - _t0) / 1000;
    var _cw2 = BTA_CELL_W * 2, _ch2 = BTA_CELL_H * 2, _minInk = 999999, _cells = 0;
    for (_i = 0; _i < 10; _i++) for (_j = 0; _j < 4; _j++) { var _ink = bta__st_sprite_ink(_A.sprite, _j * _cw2, _i * _ch2, _cw2, _ch2); _minInk = min(_minInk, _ink); _cells++; }
    _st.counts.atlasCells = _cells; _st.counts.atlasMinInk = _minInk;
    bta_st_assert(_st, _cells == 40 && _minInk >= 250, "every atlas cell is inked (40 cells, the thinnest " + string(_minInk) + " px at 2x)");
    var _as = surface_create(sprite_get_width(_A.sprite), sprite_get_height(_A.sprite));
    surface_set_target(_as); draw_clear_alpha(c_black, 0); gpu_set_blendmode_ext(bm_one, bm_zero); draw_sprite(_A.sprite, 0, 0, 0); gpu_set_blendmode(bm_normal); surface_reset_target();
    var _poseDiff = bta__st_diff_regions(_as, 0, 0, _cw2 * 2, 0, _cw2, _ch2), _sideDiff = bta__st_diff_regions(_as, 0, 0, 0, _ch2 * 5, _cw2, _ch2);
    bta_st_assert(_st, _poseDiff > 60, "stand and strike differ (" + string(_poseDiff) + " px)");
    bta_st_assert(_st, _sideDiff > 200, "the two liveries differ (" + string(_sideDiff) + " px)");
    // the sheet, on parchment so the premultiplied figures read as they will on a field
    var _sheet = surface_create(sprite_get_width(_A.sprite) * 2, sprite_get_height(_A.sprite) * 2);
    surface_set_target(_sheet); draw_clear(make_colour_rgb(120, 140, 80)); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); draw_sprite_ext(_A.sprite, 0, 0, 0, 2, 2, 0, c_white, 1); gpu_set_blendmode(bm_normal); surface_reset_target();
    surface_save(_sheet, "bta_render_atlas.png"); array_push(_st.renders, "bta_render_atlas.png");
    surface_free(_sheet); surface_free(_as);
    sprite_delete(_A.sprite);

    // 9. banners: every shape and many arms inked; different arms draw different cloth
    bta_st_stage(_st, 9);
    var _P = bta_heraldry_parts(), _bmin = 999999, _bn = 0, _bspr = [];
    _t0 = get_timer();
    for (_i = 0; _i < 48; _i++) {
        var _arms = bta_heraldry("Banner " + string(_i * 7), _i mod 2);
        _arms.shape = _P.shapes[_i mod 4];
        var _bs = bta_banner_sprite(_arms, 34, 24);
        if (sprite_exists(_bs)) { var _bi = bta__st_sprite_ink(_bs, 0, 0, sprite_get_width(_bs), sprite_get_height(_bs)); _bmin = min(_bmin, _bi); _bn++; array_push(_bspr, _bs); }
    }
    _st.timing.bannerMs = (get_timer() - _t0) / 1000 / 48;
    _st.counts.banners = _bn; _st.counts.bannerMinInk = _bmin;
    bta_st_assert(_st, _bn == 48 && _bmin >= 900, "48 banners over 4 shapes all inked (thinnest " + string(_bmin) + " px at 2x)");
    bta_st_assert(_st, bta_banner_sprite("not arms", 34, 24) == -1 && bta_banner_sprite(undefined, -5, 99999) == -1, "a banner of no arms is refused with -1");
    var _bsheet = surface_create(8 * 92, 6 * 70);
    surface_set_target(_bsheet); draw_clear(make_colour_rgb(226, 212, 178)); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    for (_i = 0; _i < array_length(_bspr); _i++) draw_sprite(_bspr[_i], 0, 8 + (_i mod 8) * 92, 8 + (_i div 8) * 70);
    gpu_set_blendmode(bm_normal); surface_reset_target();
    surface_save(_bsheet, "bta_render_banners.png"); array_push(_st.renders, "bta_render_banners.png");
    surface_free(_bsheet);
    for (_i = 0; _i < array_length(_bspr); _i++) sprite_delete(_bspr[_i]);

    // 10. fields: five terrains, each its own picture; one seed one field, two seeds two fields
    bta_st_stage(_st, 10);
    var _T = bta_terrains(), _fs = [];
    _t0 = get_timer();
    for (_i = 0; _i < 5; _i++) array_push(_fs, bta_field_sprite(_T[_i], 11, 408, 312));
    _st.timing.fieldMs = (get_timer() - _t0) / 1000 / 5;
    var _fsa = [];
    for (_i = 0; _i < 5; _i++) { var _s5 = surface_create(408, 312); surface_set_target(_s5); draw_clear(c_black); draw_sprite(_fs[_i], 0, 0, 0); surface_reset_target(); array_push(_fsa, _s5); }
    var _minPair = 999999;
    for (_i = 0; _i < 5; _i++) for (_j = _i + 1; _j < 5; _j++) _minPair = min(_minPair, bta__st_diff(_fsa[_i], _fsa[_j], 0, 0, 408, 312, 24));
    bta_st_assert(_st, _minPair > 408 * 312 * 0.3, "the five fields differ pairwise (closest pair " + string(_minPair) + " px of " + string(408 * 312) + ")");
    var _fx = bta_field_sprite("meadow", 12, 408, 312), _s6 = surface_create(408, 312);
    surface_set_target(_s6); draw_clear(c_black); draw_sprite(_fx, 0, 0, 0); surface_reset_target();
    var _seedDiff = bta__st_diff(_fsa[0], _s6, 0, 0, 408, 312, 16);
    bta_st_assert(_st, _seedDiff > 2000, "another seed paints another field (" + string(_seedDiff) + " px)");
    var _fsheet = surface_create(816, 312 * 3 / 2 * 2);
    surface_set_target(_fsheet); draw_clear(c_black);
    for (_i = 0; _i < 5; _i++) draw_sprite_ext(_fs[_i], 0, (_i mod 2) * 408, (_i div 2) * 312, 1, 1, 0, c_white, 1);
    draw_sprite(_fx, 0, 408, 624);
    surface_reset_target();
    surface_save(_fsheet, "bta_render_fields.png"); array_push(_st.renders, "bta_render_fields.png");
    surface_free(_fsheet); surface_free(_s6); sprite_delete(_fx);
    for (_i = 0; _i < 5; _i++) { surface_free(_fsa[_i]); sprite_delete(_fs[_i]); }

    // 11. the scene, phase by phase, drawn and photographed
    bta_st_stage(_st, 11);
    global.bta__st_events = 0; global.bta__st_ended = 0;
    var _sc = bta_scene_create({ title: "The Battle of Ashford", terrain: "meadow", seed: 7, input: false,
        player: { name: "Your Host", army: _PA }, enemy: { name: "The Red Host", army: _PB },
        onEvent: function(_t, _x, _y) { global.bta__st_events += 1; },
        onEnd: function(_r) { global.bta__st_ended += 1; } });
    bta_st_assert(_st, _sc.phase == BTA_PHASE_TITLE, "a scene opens on the call to arms");
    var _surf = surface_create(816, 624), _bare = surface_create(816, 624);
    surface_set_target(_bare); draw_clear(c_black); draw_sprite(_sc.art.field, 0, 0, 0); surface_reset_target();
    bta__st_shot(_sc, _surf, "bta_render_title.png", _st);
    for (_i = 0; _i < 120; _i++) bta_scene_step(_sc);
    bta_st_assert(_st, _sc.phase == BTA_PHASE_CHOOSE, "the cards come up after the call to arms: " + _sc.phase);
    _sc.hover = 2; bta__scene_deploy(_sc, 2);
    bta__st_shot(_sc, _surf, "bta_render_choose.png", _st);
    var _deployInk = bta__st_diff(_bare, _surf, 0, 210, 816, 400, 30);
    bta_st_assert(_st, _deployInk > 6000, "the deployed armies are drawn over the field (" + string(_deployInk) + " px)");
    bta_st_assert(_st, bta_scene_choose(_sc, "square") && _sc.phase == BTA_PHASE_CLASH && _sc.battle.forms[0] == BTA_SQUARE, "choosing square sounds the charge in square");
    _t0 = get_timer();
    var _stepMax = 0, _drawMs = [];
    for (_i = 0; _i < 420; _i++) {
        var _ts = get_timer(); bta_scene_step(_sc); _stepMax = max(_stepMax, (get_timer() - _ts) / 1000);
        if (_i == 300) bta__st_shot(_sc, _surf, "bta_render_clash.png", _st);
        if (_i >= 280 && _i < 290) { surface_set_target(_surf); var _td = get_timer(); bta_scene_draw(_sc, 0, 0, 1); draw_flush(); array_push(_drawMs, (get_timer() - _td) / 1000); surface_reset_target(); }
        if (_sc.battle.over) break;
    }
    _st.timing.sceneStepMaxMs = _stepMax; _st.timing.sceneDrawMs = _drawMs;
    var _clashInk = bta__st_diff(_bare, _surf, 0, 50, 816, 570, 30);
    bta_st_assert(_st, _clashInk > 8000, "the clash draws soldiers, banners and the HUD over the field (" + string(_clashInk) + " px)");
    bta_st_assert(_st, global.bta__st_events > 50, "onEvent hears the battle: " + string(global.bta__st_events) + " events");
    bta_scene_skip(_sc);
    bta_st_assert(_st, _sc.phase == BTA_PHASE_RECORD && _sc.battle.over, "skip resolves the battle and opens the war record");
    bta_st_assert(_st, global.bta__st_ended == 1, "onEnd fires exactly once: " + string(global.bta__st_ended));
    bta_st_assert(_st, _sc.hist.n >= 3, "the course of the battle has points: " + string(_sc.hist.n));
    bta_st_assert(_st, array_length(_sc.hist.routs) >= 1, "a skipped battle still records who broke for the war record: " + string(array_length(_sc.hist.routs)));
    bta__st_shot(_sc, _surf, "bta_render_record.png", _st);
    var _R = bta_scene_result(_sc);
    bta_st_assert(_st, _R.sides[0].count == 134 && _R.sides[1].count == 138, "the record counts both armies: " + string(_R.sides[0].count) + " / " + string(_R.sides[1].count));
    for (_i = 0; _i < 30; _i++) bta_scene_step(_sc);
    bta_st_assert(_st, !bta_scene_done(_sc), "with input off the record waits for its owner");
    _sc.phase = BTA_PHASE_DONE;
    bta_st_assert(_st, bta_scene_done(_sc), "done once the record is closed");
    var _sprs = [_sc.art.field, _sc.art.atlas.sprite];
    bta_scene_free(_sc); bta_scene_free(_sc);
    bta_st_assert(_st, !sprite_exists(_sprs[0]) && !sprite_exists(_sprs[1]), "free deletes the scene's sprites, and twice is safe");
    // a callback written inside the options struct runs as the CALLER's code (it reads an instance variable of the caller)
    st_hits = 0; st_end = 0;
    var _scb = bta_scene_create({ seed: 12, input: false, playerForm: "line", player: { army: "foot:20:A, archer:10:B" }, enemy: { army: "foot:24:C" },
        onEvent: function(_t, _x, _y) { st_hits += 1; }, onEnd: function(_r) { st_end += 1; } });
    for (_i = 0; _i < 400; _i++) bta_scene_step(_scb);
    bta_scene_skip(_scb);
    bta_st_assert(_st, st_hits > 10 && st_end == 1, "callbacks in the options struct reach the caller's instance variables: " + string(st_hits) + " events, " + string(st_end) + " end");
    bta_scene_free(_scb);
    // a scene with a fixed formation skips the cards; a huge army is drawn at the cap
    var _sc2 = bta_scene_create({ seed: 47, terrain: "moor", playerForm: "wedge", input: false, player: { army: "foot:2400:A, archer:1200:B, horse:600:C" }, enemy: { army: "foot:3000:D, horse:900:E" } });
    for (_i = 0; _i < 104; _i++) bta_scene_step(_sc2);
    bta_st_assert(_st, _sc2.phase == BTA_PHASE_CLASH && _sc2.battle.forms[0] == BTA_WEDGE, "a fixed formation goes straight to the clash");
    for (_i = 0; _i < 200; _i++) bta_scene_step(_sc2);
    bta__st_shot(_sc2, _surf, "bta_render_horde.png", _st);
    bta_scene_free(_sc2);
    surface_free(_surf); surface_free(_bare);

    // 12. bad input: every public entry point refuses quietly
    bta_st_stage(_st, 12);
    var _crash = 0;
    try { bta_battle_step(undefined); bta_battle_step({}); bta_battle_run("x"); bta_battle_result(undefined); bta_battle_standing(undefined, 0); bta_battle_share(undefined, 0); bta_battle_share(_b, 7); } catch (_ex) { _crash++; }
    try { bta_scene_step(undefined); bta_scene_draw(undefined, 0, 0, 1); bta_scene_choose(undefined, "line"); bta_scene_skip(4); bta_scene_free("x"); bta_scene_set_fast(undefined, true); bta_scene_result(undefined); } catch (_ex2) { _crash++; }
    try { bta_heraldry(undefined, "x"); bta_livery(9, "#zzzzzz"); bta_enemy_formation(undefined, undefined); bta_form_id(undefined); bta_role_id([1]); } catch (_ex3) { _crash++; }
    bta_st_assert(_st, _crash == 0, "bad input to 19 entry points: " + string(_crash) + " throws");
    var _L = bta_livery(1, "#12ab34");
    bta_st_assert(_st, _L.main[0] == 18 && _L.main[1] == 171 && _L.main[2] == 52, "a #hex livery colour is read");
    bta_st_assert(_st, bta_livery(0, "nonsense").main[0] == 47, "a bad colour keeps the default");

    // 13. the cost at the cap: 240 figures a side, every step and every draw timed (RECORDED as ranges for the Readme; the
    // only gate is a sanity bound loose enough never to flake on a shared machine - wall clock is not a gate, doctrine s28)
    bta_st_stage(_st, 13);
    var _cap = bta_scene_create({ seed: 4, input: false, playerForm: "line", enemyForm: "line",
        player: { army: "foot:120:A, pike:60:B, archer:40:C, horse:20:D" }, enemy: { army: "foot:120:E, pike:60:F, archer:40:G, horse:20:H" } });
    bta_st_assert(_st, _cap.battle.n == 480, "the cap battle carries 480 figures: " + string(_cap.battle.n));
    for (_i = 0; _i < 101; _i++) bta_scene_step(_cap);
    var _steps = [], _draws = [], _cs = surface_create(816, 624), _figs = 0;
    for (_i = 0; _i < 600 && !_cap.battle.over; _i++) {
        var _t1 = get_timer(); bta_scene_step(_cap); array_push(_steps, (get_timer() - _t1) / 1000);
        if ((_i mod 30) == 0) {
            surface_set_target(_cs); var _t2 = get_timer(); bta_scene_draw(_cap, 0, 0, 1); draw_flush(); array_push(_draws, (get_timer() - _t2) / 1000); surface_reset_target();
            var _al = 0; for (_k = 0; _k < _cap.battle.n; _k++) if (_cap.battle.state[_k] == BTA_ALIVE || _cap.battle.state[_k] == BTA_ROUTING) _al++;
            _figs = max(_figs, _al);
        }
    }
    // where a cap frame's time goes, split in ONE run on the same state (the shared machine moves wall clock between runs)
    var _cb = _cap.battle, _tp = get_timer();
    for (_i = 0; _i < 20; _i++) bta__grid(_cb);
    var _pGrid = (get_timer() - _tp) / 1000 / 20;
    _tp = get_timer();
    for (_i = 0; _i < 20; _i++) bta__separate(_cb);
    var _pSep = (get_timer() - _tp) / 1000 / 20;
    _tp = get_timer();
    var _nq = 0;
    for (_i = 0; _i < _cb.n; _i++) if (_cb.state[_i] == BTA_ALIVE) { bta__nearest_enemy(_cb, _i); _nq++; }
    var _pNear = (get_timer() - _tp) / 1000;
    var _cp2 = bta_battle_create({ seed: 4, armies: [_cap.armies[0], _cap.armies[1]], forms: ["line", "line"] });
    while (_cp2.frame < _cb.frame && !_cp2.over) bta_battle_step(_cp2);
    _tp = get_timer();
    for (_i = 0; _i < 20 && !_cp2.over; _i++) bta_battle_step(_cp2);
    var _pStep = (get_timer() - _tp) / 1000 / max(1, _i);
    _st.timing.capProfile = { atFrame: _cb.frame, gridMs: _pGrid, separateMs: _pSep, nearestAllMs: _pNear, nearestQueries: _nq, battleStepMs: _pStep };
    array_sort(_steps, true); array_sort(_draws, true);
    var _ns = array_length(_steps), _nd = array_length(_draws), _mean = 0;
    for (_i = 0; _i < _ns; _i++) _mean += _steps[_i];
    _mean /= max(1, _ns);
    _st.timing.capStep = { frames: _ns, meanMs: _mean, p50Ms: _steps[_ns div 2], p95Ms: _steps[floor(_ns * 0.95)], maxMs: _steps[_ns - 1] };
    _st.timing.capDraw = { draws: _nd, p50Ms: _draws[_nd div 2], maxMs: _draws[_nd - 1], figuresDrawnMax: _figs };
    bta_st_assert(_st, _ns >= 300 && _mean < 40, "a 480-figure battle steps (mean " + string(_mean) + " ms over " + string(_ns) + " frames; sanity bound 40 ms)");
    bta_st_assert(_st, _nd >= 10 && _figs >= 300, "the cap battle is drawn " + string(_nd) + " times with up to " + string(_figs) + " figures standing");
    surface_set_target(_cs); draw_clear(c_black); bta_scene_draw(_cap, 0, 0, 1); surface_reset_target();
    surface_save(_cs, "bta_render_cap.png"); array_push(_st.renders, "bta_render_cap.png");
    surface_free(_cs); bta_scene_free(_cap);
    return _st;
}

/// @function bta__st_diff_regions(surface, ax, ay, bx, by, w, h)  pixels differing (alpha or RGB) between two regions of one surface
function bta__st_diff_regions(_s, _ax, _ay, _bx, _by, _w, _h) {
    var _sw = surface_get_width(_s), _b = bta__st_rgba(_s), _n = 0;
    for (var _y = 0; _y < _h; _y++) for (var _x = 0; _x < _w; _x++) {
        var _oa = ((_ay + _y) * _sw + _ax + _x) * 4, _ob = ((_by + _y) * _sw + _bx + _x) * 4, _d = 0;
        for (var _c = 0; _c < 4; _c++) _d = max(_d, abs(buffer_peek(_b, _oa + _c, buffer_u8) - buffer_peek(_b, _ob + _c, buffer_u8)));
        if (_d > 40) _n++;
    }
    buffer_delete(_b);
    return _n;
}

/// @function bta__st_shot(scene, surface, file, st)  draw the scene into a surface and save it
function bta__st_shot(_sc, _s, _fn, _st) {
    surface_set_target(_s); draw_clear(c_black); bta_scene_draw(_sc, 0, 0, 1); surface_reset_target();
    surface_save(_s, _fn); array_push(_st.renders, _fn);
}

/// @function bta_selftest_write(st)
function bta_selftest_write(_st) {
    var _f = file_text_open_write("bta_selftest.json");
    file_text_write_string(_f, json_stringify(_st));
    file_text_close(_f);
}
