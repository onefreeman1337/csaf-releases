/// bta_core.gml - THE RULES OF AN ARMY BATTLE. No drawing call anywhere in this file.
///
/// Battalia - Army Battles for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// Two armies of regiments meet on a field 816 x 376 logical pixels. Every soldier (or, for a big army, every FIGURE carrying
/// several soldiers) marches, closes, strikes, shoots or casts, and may break and run. Damage is applied at the END of each
/// frame so both armies strike simultaneously, and every push between figures is quantised to 1/256 px so the order the
/// figures are visited cannot matter: identical armies in identical formations split fairly (the suite measures it).
/// Every battle is seeded: the same armies, formations and seed play out the same way, frame for frame.
///
/// Ported from the RPG Maker MZ edition (WarhostCore.js 1.1) rule for rule; the random generator is this file's own, so a
/// seed here is not the same battle as the same seed in MZ.
///
/// PUBLIC API (each documented at its definition):
///   bta_army(spec)                       -> an army (array of regiment structs) from "role:count:Name:strength, ..."
///   bta_battle_create(opts)              -> a battle  { seed, armies:[a, b], forms:[f0, f1], timeLimit, cap }
///   bta_battle_step(battle)              -> advance one frame; returns the number of events written this frame
///   bta_battle_run(battle, [maxFrames])  -> run to the end; returns the frame count
///   bta_battle_result(battle)            -> { winner, frames, seconds, forms, sides, regiments } in SOLDIERS
///   bta_battle_standing(battle, side)    -> { count, alive, fled, dead } in soldiers, right now
///   bta_battle_share(battle, side)       -> the share of a side's starting strength still fighting, 0..1
///   bta_enemy_formation(army, seed)      -> "line" | "wedge" | "square" | "loose" read from the army's own make-up
///   bta_heraldry(name, side, [salt])     -> a regiment's arms (the same name always flies the same banner)
///   bta_form_id(name) / bta_form_name(id), bta_role_id(name) / bta_role_name(id)

#macro BTA_VERSION "1.0.0"
#macro BTA_FOOT 0
#macro BTA_PIKE 1
#macro BTA_ARCHER 2
#macro BTA_HORSE 3
#macro BTA_MAGE 4
#macro BTA_LINE 0
#macro BTA_WEDGE 1
#macro BTA_SQUARE 2
#macro BTA_LOOSE 3
#macro BTA_FIELD_W 816
#macro BTA_FIELD_TOP 214
#macro BTA_FIELD_BOTTOM 590
#macro BTA_FIELD_MID 408
#macro BTA_CAP_PER_SIDE 240
#macro BTA_EV_BLOW 1
#macro BTA_EV_DEATH 2
#macro BTA_EV_LOOSE 3
#macro BTA_EV_ARROW_HIT 4
#macro BTA_EV_ARROW_MISS 5
#macro BTA_EV_CAST 6
#macro BTA_EV_BURST 7
#macro BTA_EV_ROUT 8
#macro BTA_EV_CHARGE 9
#macro BTA_ALIVE 0
#macro BTA_DEAD 1
#macro BTA_ROUTING 2
#macro BTA_FLED 3
#macro BTA__ENGAGE 64
#macro BTA__SEP 7.5
#macro BTA__GRID 8
#macro BTA__GW 104
#macro BTA__GH 90
#macro BTA__EDGE 1.4
#macro BTA__EDGE_GUARD 0.8
#macro BTA__PMAX 512
#macro BTA__EVMAX 1024

// ---------------------------------------------------------------------------------------------------------------------
// Seeded generator (xorshift32 over an FNV-1a scramble of the seed; never GameMaker's global random state)
// ---------------------------------------------------------------------------------------------------------------------

/// @function bta_hash(value)
/// @description FNV-1a over the bytes of string(value). Returns a non-negative integer below 2^32. Pure.
/// @returns {Real}
function bta_hash(_v) {
    var _t = string(_v), _h = int64(2166136261), _n = string_byte_length(_t);
    for (var _i = 1; _i <= _n; _i++) {
        _h = _h ^ int64(string_byte_at(_t, _i));
        _h = (_h * int64(16777619)) & int64(4294967295);
    }
    return _h;
}

/// @function bta_rng(seed)
/// @description A generator state seeded from any value (number or string). Use with bta_rnd. Pure.
/// @returns {Array}
function bta_rng(_seed) {
    var _h = bta_hash("bta|" + string(_seed));
    if (_h == 0) _h = int64(1);
    var _st = [_h];
    // the first draws of xorshift over nearby states are correlated: discard three (wing doctrine s6)
    bta_rnd(_st); bta_rnd(_st); bta_rnd(_st);
    return _st;
}

/// @function bta_rnd(state)
/// @description The next draw in [0, 1) from a bta_rng state (advances it in place).
/// @returns {Real}
function bta_rnd(_st) {
    var _x = _st[0];
    _x = _x ^ ((_x << 13) & int64(4294967295));
    _x = _x ^ (_x >> 17);
    _x = _x ^ ((_x << 5) & int64(4294967295));
    _st[@ 0] = _x;
    return real(_x) / 4294967296;
}

// ---------------------------------------------------------------------------------------------------------------------
// The rules: five arms, four formations
// ---------------------------------------------------------------------------------------------------------------------

/// @function bta_roles()
/// @description The five arms as an array of structs indexed by role id (BTA_FOOT .. BTA_MAGE). speed px/frame, reach px,
/// cd frames between blows, range px for shots and spells, rout = the share of a regiment left when it may break. Read-only.
/// @returns {Array}
function bta_roles() {
    static _t = [
        { id: "foot",   label: "Foot",    hp: 12, atk: 3.0, speed: 0.55, reach: 13, cd: 42,  range: 0,   shot: 0,    spell: 0,   rout: 0.40 },
        { id: "pike",   label: "Pikes",   hp: 12, atk: 2.6, speed: 0.48, reach: 20, cd: 48,  range: 0,   shot: 0,    spell: 0,   rout: 0.40 },
        { id: "archer", label: "Archers", hp: 8,  atk: 1.2, speed: 0.50, reach: 12, cd: 90,  range: 210, shot: 1.45, spell: 0,   rout: 0.45 },
        { id: "horse",  label: "Horse",   hp: 18, atk: 4.2, speed: 1.35, reach: 14, cd: 36,  range: 0,   shot: 0,    spell: 0,   rout: 0.35 },
        { id: "mage",   label: "Mages",   hp: 7,  atk: 0.8, speed: 0.42, reach: 12, cd: 170, range: 190, shot: 0,    spell: 3.2, rout: 0.45 }
    ];
    return _t;
}

/// @function bta_forms()
/// @description The four formations indexed by form id (BTA_LINE .. BTA_LOOSE). speed = march multiplier, melee = blow
/// strength, taken* = damage the formation TAKES by kind, spacing = how far apart the ranks stand, beats = the form id this
/// one breaks in melee. Read-only.
/// @returns {Array}
function bta_forms() {
    static _t = [
        { id: "line",   label: "Line",   speed: 1.00, melee: 1.00, takenMelee: 1.00, takenShot: 1.00, takenSpell: 1.00, takenHorse: 1.00, spacing: 1.00, beats: 3, motto: "Steady ranks. Breaks a loose screen." },
        { id: "wedge",  label: "Wedge",  speed: 1.00, melee: 1.10, takenMelee: 1.00, takenShot: 1.00, takenSpell: 1.00, takenHorse: 1.00, spacing: 0.85, beats: 0, motto: "Drive in hard. Breaks a line." },
        { id: "square", label: "Square", speed: 0.95, melee: 1.00, takenMelee: 0.95, takenShot: 1.00, takenSpell: 1.05, takenHorse: 0.60, spacing: 0.72, beats: 1, motto: "Shields locked. Stops a wedge and horse." },
        { id: "loose",  label: "Loose",  speed: 1.00, melee: 0.90, takenMelee: 1.00, takenShot: 0.82, takenSpell: 0.80, takenHorse: 1.00, spacing: 1.60, beats: 2, motto: "Spread out. Arrows find little. Outlasts a square." }
    ];
    return _t;
}

/// @function bta__match(attackerRole, defenderRole)
/// @description Role-against-role damage multiplier: pikes stop horse, horse runs down bows and mages. Pure.
function bta__match(_a, _d) {
    static _m = [
        // vs foot pike archer horse mage
        1, 1, 1.3, 1, 1.3,      // foot
        1, 1, 1, 2.6, 1,        // pike
        1, 1, 1, 0.8, 1,        // archer
        1, 0.55, 1.8, 1, 2.0,   // horse
        1, 1, 1, 1, 1           // mage
    ];
    return _m[_a * 5 + _d];
}

/// @function bta_role_id(name)
/// @description "foot" | "pike" | "archer" | "horse" | "mage" (any case) -> 0..4, or -1 for anything else. Pure.
function bta_role_id(_name) {
    if (is_numeric(_name)) { var _n = floor(_name); return (_n >= 0 && _n <= 4) ? _n : -1; }
    if (!is_string(_name)) return -1;
    switch (string_lower(string_trim(_name))) {
        case "foot": return 0; case "pike": case "pikes": return 1; case "archer": case "archers": case "bow": case "bows": return 2;
        case "horse": case "cavalry": return 3; case "mage": case "mages": return 4;
    }
    return -1;
}

/// @function bta_role_name(id)
function bta_role_name(_id) { var _r = bta_roles(); return (is_numeric(_id) && _id >= 0 && _id <= 4) ? _r[floor(_id)].id : "foot"; }

/// @function bta_form_id(name)
/// @description "line" | "wedge" | "square" | "loose" (any case) -> 0..3, or -1 for anything else. Pure.
function bta_form_id(_name) {
    if (is_numeric(_name)) { var _n = floor(_name); return (_n >= 0 && _n <= 3) ? _n : -1; }
    if (!is_string(_name)) return -1;
    switch (string_lower(string_trim(_name))) { case "line": return 0; case "wedge": return 1; case "square": return 2; case "loose": return 3; }
    return -1;
}

/// @function bta_form_name(id)
function bta_form_name(_id) { var _f = bta_forms(); return (is_numeric(_id) && _id >= 0 && _id <= 3) ? _f[floor(_id)].id : "line"; }

/// @function bta__num(value, default)
/// @description A finite number from a number or a numeric string, else the default. Never throws.
function bta__num(_v, _d) {
    if (is_numeric(_v)) return (is_nan(_v) || is_infinity(_v)) ? _d : real(_v);
    if (is_string(_v)) {
        var _t = string_trim(_v);
        if (_t == "") return _d;
        try { var _r = real(_t); return (is_nan(_r) || is_infinity(_r)) ? _d : _r; } catch (_e) { return _d; }
    }
    return _d;
}

// ---------------------------------------------------------------------------------------------------------------------
// Armies
// ---------------------------------------------------------------------------------------------------------------------

/// @function bta_army(spec)
/// @description An army from a one-line spec: regiments separated by commas, each "role:count:Name:strength"
/// (everything after the count optional; underscores in a name are spaces). Also accepts an array of regiment structs
/// { name, role, count, strength } and returns it normalised. A regiment that is not role:count is left out.
/// Example: bta_army("foot:40:Shieldmen, archer:30:Bowmen:1.5, horse:20:Riders")
/// @returns {Array} of { name, role, count, strength }
function bta_army(_spec) {
    var _out = [];
    if (is_array(_spec)) {
        for (var _k = 0; _k < array_length(_spec); _k++) {
            var _r = _spec[_k];
            if (is_struct(_r)) array_push(_out, { name: _r[$ "name"], role: _r[$ "role"], count: _r[$ "count"], strength: _r[$ "strength"] });
        }
        return _out;
    }
    if (!is_string(_spec)) return _out;
    var _parts = string_split(_spec, ",");
    for (var _i = 0; _i < array_length(_parts); _i++) {
        var _p = string_trim(_parts[_i]);
        if (_p == "") continue;
        var _f = string_split(_p, ":");
        if (array_length(_f) < 2 || bta_role_id(_f[0]) < 0) continue;
        var _c = bta__num(_f[1], 0);
        if (_c < 1) continue;
        array_push(_out, { name: (array_length(_f) > 2) ? string_replace_all(string_trim(_f[2]), "_", " ") : "",
            role: string_lower(string_trim(_f[0])), count: floor(_c), strength: (array_length(_f) > 3) ? bta__num(_f[3], 1) : 1 });
    }
    return _out;
}

/// @function bta__normalize(list, side)
/// @description Validate one army: unknown roles become foot, counts below 1 drop the regiment, strength is clamped to
/// 0.25..4, a blank name becomes "<Arm> <n>". Returns new structs.
function bta__normalize(_list, _side) {
    var _out = [], _roles = bta_roles();
    if (is_string(_list)) _list = bta_army(_list);
    if (!is_array(_list)) return _out;
    for (var _k = 0; _k < array_length(_list); _k++) {
        var _r = _list[_k];
        if (!is_struct(_r)) continue;
        var _count = floor(bta__num(_r[$ "count"], 0));
        if (_count < 1) continue;
        var _rid = bta_role_id(_r[$ "role"]);
        if (_rid < 0) _rid = BTA_FOOT;
        var _nm = is_string(_r[$ "name"]) ? string_trim(_r[$ "name"]) : "";
        if (_nm == "") _nm = _roles[_rid].label + " " + string(_k + 1);
        array_push(_out, { name: _nm, role: _roles[_rid].id, roleId: _rid, count: min(_count, 99999),
            strength: clamp(bta__num(_r[$ "strength"], 1), 0.25, 4), side: _side, figures: 1, rep: 1, index: 0 });
    }
    return _out;
}

// ---------------------------------------------------------------------------------------------------------------------
// The battle
// ---------------------------------------------------------------------------------------------------------------------

/// @function bta__place_block(battle, i0, n, cx, cy, dir, form, rng, laneH)
/// @description Place a regiment's figures for its formation, front face toward the enemy (dir +1 = rightwards).
function bta__place_block(_b, _i0, _n, _cx, _cy, _dir, _form, _rng, _laneH) {
    var _fm = bta_forms(), _sp = 11 * _fm[_form].spacing, _k, _bx = _b.x, _by = _b.y;
    if (_form == BTA_WEDGE) {
        // rows of 3, 5, 7 ... behind a blunt point (a deep wedge arrives one man at a time)
        var _row = 0, _inRow = 0, _width = 3;
        for (_k = 0; _k < _n; _k++) {
            _bx[@ _i0 + _k] = _cx - _dir * _row * _sp * 0.8;
            _by[@ _i0 + _k] = _cy + (_inRow - (_width - 1) / 2) * _sp;
            _inRow++;
            if (_inRow >= _width) { _row++; _width += 2; _inRow = 0; }
        }
        return;
    }
    var _rows;
    if (_form == BTA_SQUARE) _rows = max(1, round(sqrt(_n)));
    else _rows = max(1, min(floor(_laneH / _sp), ceil(_n / ((_form == BTA_LINE) ? 3 : 4))));
    for (_k = 0; _k < _n; _k++) {
        var _c = floor(_k / _rows), _r = _k mod _rows, _jx = 0, _jy = 0;
        if (_form == BTA_LOOSE) {
            // two draws in two statements: GML evaluates a shared-state expression right to left (doctrine s11)
            _jx = (bta_rnd(_rng) - 0.5) * _sp * 0.7;
            _jy = (bta_rnd(_rng) - 0.5) * _sp * 0.7;
        }
        _bx[@ _i0 + _k] = _cx - _dir * _c * _sp + _jx;
        _by[@ _i0 + _k] = _cy + (_r - (_rows - 1) / 2) * _sp + _jy;
    }
}

/// @function bta_battle_create(opts)
/// @description A battle, ready to step. opts (every field optional):
///   seed       any number or string (default 1) - the same seed replays the same battle exactly
///   armies     [playerArmy, enemyArmy], each an array from bta_army() or a spec string
///   forms      [playerForm, enemyForm], "line" | "wedge" | "square" | "loose" (default "line")
///   timeLimit  frames (default 3600 = 60 s at 60 fps, at least 600): then the stronger army holds the field if 15% ahead
///   cap        figures per side (default 240, 8..600): a bigger army is carried at several soldiers per figure
/// Side 0 starts on the LEFT and faces right. Positions: b.x is measured from the field's centre line (screen x = b.x +
/// BTA_FIELD_MID), b.y in field pixels (BTA_FIELD_TOP .. BTA_FIELD_BOTTOM).
/// @returns {Struct}
function bta_battle_create(_o) {
    if (!is_struct(_o)) _o = {};
    var _seed = _o[$ "seed"];
    if (is_undefined(_seed)) _seed = 1;
    var _rng = bta_rng(_seed), _roles = bta_roles();
    var _arm = _o[$ "armies"];
    var _a0 = bta__normalize(is_array(_arm) && array_length(_arm) > 0 ? _arm[0] : [], 0);
    var _a1 = bta__normalize(is_array(_arm) && array_length(_arm) > 1 ? _arm[1] : [], 1);
    var _fo = _o[$ "forms"], _f0 = BTA_LINE, _f1 = BTA_LINE;
    if (is_array(_fo)) {
        if (array_length(_fo) > 0 && bta_form_id(_fo[0]) >= 0) _f0 = bta_form_id(_fo[0]);
        if (array_length(_fo) > 1 && bta_form_id(_fo[1]) >= 0) _f1 = bta_form_id(_fo[1]);
    }
    var _cap = clamp(floor(bta__num(_o[$ "cap"], BTA_CAP_PER_SIDE)), 8, 600);
    var _armies = [_a0, _a1], _regs = [], _total = 0, _s, _g, _k;
    for (_s = 0; _s < 2; _s++) {
        var _sum = 0;
        for (_g = 0; _g < array_length(_armies[_s]); _g++) _sum += _armies[_s][_g].count;
        var _scale = (_sum > _cap) ? _sum / _cap : 1;
        for (_g = 0; _g < array_length(_armies[_s]); _g++) {
            var _rg = _armies[_s][_g];
            _rg.figures = max(1, round(_rg.count / _scale));
            _rg.rep = _rg.count / _rg.figures;
            _rg.index = array_length(_regs);
            array_push(_regs, _rg);
            _total += _rg.figures;
        }
    }
    var _nr = array_length(_regs), _n = max(1, _total);
    var _b = {
        seed: _seed, rng: _rng, frame: 0, over: false, winner: -1,
        timeLimit: max(600, floor(bta__num(_o[$ "timeLimit"], 3600))),
        forms: [_f0, _f1], regs: _regs, n: _total,
        x: array_create(_n, 0), y: array_create(_n, 0), nx: array_create(_n, 0), ny: array_create(_n, 0),
        hp: array_create(_n, 0), hpMax: array_create(_n, 0), cd: array_create(_n, 0), side: array_create(_n, 0),
        role: array_create(_n, 0), reg: array_create(_n, 0), state: array_create(_n, 0), target: array_create(_n, -1),
        face: array_create(_n, 1), charged: array_create(_n, 0), deadAt: array_create(_n, 0), pend: array_create(_n, 0),
        slot: array_create(_n, 0), act: array_create(_n, 999), gridHead: array_create(BTA__GW * BTA__GH, -1),
        gridNext: array_create(_n, -1), valour: array_create(max(1, _nr), 1),
        pn: 0, px0: array_create(BTA__PMAX, 0), py0: array_create(BTA__PMAX, 0), px1: array_create(BTA__PMAX, 0),
        py1: array_create(BTA__PMAX, 0), pt: array_create(BTA__PMAX, 0), pT: array_create(BTA__PMAX, 1),
        pkind: array_create(BTA__PMAX, 0), pfrom: array_create(BTA__PMAX, 0), pto: array_create(BTA__PMAX, -1),
        plive: array_create(BTA__PMAX, 0),
        evN: 0, evType: array_create(BTA__EVMAX, 0), evX: array_create(BTA__EVMAX, 0), evY: array_create(BTA__EVMAX, 0),
        evA: array_create(BTA__EVMAX, 0),
        regAlive: array_create(max(1, _nr), 0), regStart: array_create(max(1, _nr), 0), regRouted: array_create(max(1, _nr), 0),
        regFig0: array_create(max(1, _nr), 0), regFigN: array_create(max(1, _nr), 0),
        sideActive: [0, 0], sideHp0: [0, 0], cell: array_create(_n, 0), gridUsed: array_create(_n, 0), gridUsedN: 0,
        alv0: array_create(_n, 0), alv1: array_create(_n, 0), alvN: [0, 0],
        rSpd: [], rRange: [], rReach: [], rCd: [], rShot: [], fSpd: []
    };
    // the rules flattened for the per-frame loop (derived here from the one table, never typed twice)
    var _fmsT = bta_forms();
    for (_g = 0; _g < 5; _g++) { array_push(_b.rSpd, _roles[_g].speed); array_push(_b.rRange, _roles[_g].range); array_push(_b.rReach, _roles[_g].reach); array_push(_b.rCd, _roles[_g].cd); array_push(_b.rShot, _roles[_g].shot); }
    array_push(_b.fSpd, _fmsT[_f0].speed, _fmsT[_f1].speed);
    // deploy: front rank (foot, pike), second (archer), rear (mage), wings (horse). x from the centre line.
    var _i = 0, _laneH = BTA_FIELD_BOTTOM - BTA_FIELD_TOP;
    var _mid = (BTA_FIELD_TOP + BTA_FIELD_BOTTOM) / 2, _span = _laneH * 0.86;
    for (_s = 0; _s < 2; _s++) {
        var _dir = (_s == 0) ? 1 : -1, _front = -_dir * 150, _sideStart = _i;
        var _gf = [], _g2 = [], _gr = [], _gw = [];
        for (_g = 0; _g < array_length(_armies[_s]); _g++) {
            var _q = _armies[_s][_g];
            if (_q.roleId == BTA_ARCHER) array_push(_g2, _q); else if (_q.roleId == BTA_MAGE) array_push(_gr, _q);
            else if (_q.roleId == BTA_HORSE) array_push(_gw, _q); else array_push(_gf, _q);
        }
        if (array_length(_gf) == 0 && array_length(_g2) > 0) { _gf = _g2; _g2 = []; }
        var _wingH = (array_length(_gw) > 0) ? _span * 0.2 : 0;
        var _lists = [_gf, _g2, _gr], _xs = [_front, _front - _dir * 70, _front - _dir * 130];
        var _y0s = [_mid - _span / 2 + _wingH, _mid - _span / 2 + _wingH, _mid - _span / 2 + _wingH + 20];
        var _y1s = [_mid + _span / 2 - _wingH, _mid + _span / 2 - _wingH, _mid + _span / 2 - _wingH - 20];
        if (array_length(_gw) > 0) {
            var _top = [], _bot = [];
            for (_g = 0; _g < array_length(_gw); _g++) { if (_g mod 2) array_push(_bot, _gw[_g]); else array_push(_top, _gw[_g]); }
            array_push(_lists, _top, _bot);
            array_push(_xs, _front - _dir * 20, _front - _dir * 20);
            array_push(_y0s, _mid - _span / 2, _mid + _span / 2 - _wingH * 2);
            array_push(_y1s, _mid - _span / 2 + _wingH * 2, _mid + _span / 2);
        }
        for (var _L = 0; _L < array_length(_lists); _L++) {
            var _list = _lists[_L];
            if (array_length(_list) == 0) continue;
            var _weight = 0;
            for (_g = 0; _g < array_length(_list); _g++) _weight += _list[_g].figures;
            var _yy = _y0s[_L];
            for (_g = 0; _g < array_length(_list); _g++) {
                var _rg2 = _list[_g], _h = (_y1s[_L] - _y0s[_L]) * _rg2.figures / _weight, _idx = _rg2.index;
                _b.regFig0[_idx] = _i; _b.regFigN[_idx] = _rg2.figures; _b.regStart[_idx] = _rg2.figures; _b.regAlive[_idx] = _rg2.figures;
                // this regiment's day: a seeded roll, so no two battles are the same arithmetic
                var _vr = bta_rng(string(_seed) + "|valour|" + string(_s) + "|" + string(_g) + "|" + string(_L));
                _b.valour[_idx] = 0.82 + bta_rnd(_vr) * 0.36;
                bta__place_block(_b, _i, _rg2.figures, _xs[_L], _yy + _h / 2, _dir, _b.forms[_s], _rng, max(20, _h - 8));
                var _R = _roles[_rg2.roleId];
                for (_k = 0; _k < _rg2.figures; _k++) {
                    _b.side[_i] = _s; _b.role[_i] = _rg2.roleId; _b.reg[_i] = _idx; _b.slot[_i] = _i - _sideStart;
                    _b.hpMax[_i] = _R.hp * _rg2.rep * _rg2.strength; _b.hp[_i] = _b.hpMax[_i];
                    _b.cd[_i] = floor(bta_rnd(_rng) * _R.cd); _b.target[_i] = -1; _b.face[_i] = _dir;
                    _b.x[_i] = clamp(_b.x[_i], 6 - BTA_FIELD_MID, BTA_FIELD_MID - 6);
                    _b.y[_i] = clamp(_b.y[_i], BTA_FIELD_TOP + 4, BTA_FIELD_BOTTOM - 4);
                    _i++;
                }
                _yy += _h;
            }
        }
    }
    for (_i = 0; _i < _b.n; _i++) { _b.sideHp0[_b.side[_i]] += _b.hpMax[_i]; if (_b.state[_i] == BTA_ALIVE) _b.sideActive[_b.side[_i]]++; }
    if (_b.sideActive[0] == 0 || _b.sideActive[1] == 0) bta__finish(_b, (_b.sideActive[0] > 0) ? 0 : ((_b.sideActive[1] > 0) ? 1 : -1));
    return _b;
}

/// @function bta__emit(battle, type, x, y, a)
function bta__emit(_b, _t, _x, _y, _a) {
    if (_b.evN >= BTA__EVMAX) return;
    var _k = _b.evN; _b.evN = _k + 1;
    _b.evType[_k] = _t; _b.evX[_k] = _x; _b.evY[_k] = _y; _b.evA[_k] = _a;
}

/// @function bta__damage(battle, i, j, kind)
/// @description Damage figure i deals figure j. kind 0 melee, 1 shot, 2 spell.
function bta__damage(_b, _i, _j, _kind) {
    var _roles = bta_roles(), _fms = bta_forms();
    var _ra = _b.role[_i], _rd = _b.role[_j], _R = _roles[_ra], _g = _b.regs[_b.reg[_i]];
    var _base = (_kind == 1) ? _R.shot : ((_kind == 2) ? _R.spell : _R.atk);
    var _sfa = _b.forms[_b.side[_i]], _sfd = _b.forms[_b.side[_j]], _fa = _fms[_sfa], _fd = _fms[_sfd];
    var _taken = (_kind == 1) ? _fd.takenShot : ((_kind == 2) ? _fd.takenSpell : ((_ra == BTA_HORSE) ? _fd.takenHorse * _fd.takenMelee : _fd.takenMelee));
    var _d = _base * _g.rep * _g.strength * bta__match(_ra, _rd) * _taken * _b.valour[_b.reg[_i]];
    if (_kind == 0) {
        _d *= _fa.melee;
        if (_fa.beats == _sfd) _d *= BTA__EDGE; else if (_fd.beats == _sfa) _d *= BTA__EDGE_GUARD;
        // the charge: the first blow lands at 1.6x - except on pikes, which is the whole point of pikes
        if (_ra == BTA_HORSE && !_b.charged[_i]) { if (_rd != BTA_PIKE) _d *= 1.6; _b.charged[_i] = 1; }
    }
    return _d * (0.85 + bta_rnd(_b.rng) * 0.3);
}

/// @function bta__hurt(battle, j, d)
/// @description Damage waits for the END of the frame so both armies strike simultaneously.
function bta__hurt(_b, _j, _d) { var _s = _b.state[_j]; if (_s == BTA_ALIVE || _s == BTA_ROUTING) _b.pend[_j] += _d; }

/// @function bta__grid(battle)
/// @description Bin every standing figure (alive or routing) into an 8 px grid from the START-of-frame positions, once a
/// frame: the nearest-enemy search, the arrow and spell landings and the separation pass all read it. 8 px because a
/// 7.5 px separation then needs only the 3 x 3 block (16 px cells put ~40 candidates round every man in a melee).
/// ⛔ The VM pays per call and per struct lookup, not per multiply: everything here is a local, every cell is computed
/// once (cached in b.cell), and only the cells used last frame are cleared (never all 9,360).
function bta__grid(_b) {
    var _head = _b.gridHead, _next = _b.gridNext, _x = _b.x, _y = _b.y, _st = _b.state, _n = _b.n, _i, _c;
    var _cell = _b.cell, _GW = BTA__GW, _GH = BTA__GH, _used = _b.gridUsed, _nu = _b.gridUsedN;
    var _a0 = _b.alv0, _a1 = _b.alv1, _n0 = 0, _n1 = 0, _side = _b.side;
    for (_i = 0; _i < _nu; _i++) _head[_used[_i]] = -1;
    _nu = 0;
    for (_i = 0; _i < _n; _i++) {
        var _s0 = _st[_i];
        if (_s0 != BTA_ALIVE && _s0 != BTA_ROUTING) { _next[_i] = -2; continue; }
        if (_s0 == BTA_ALIVE) { if (_side[_i] == 0) { _a0[_n0] = _i; _n0++; } else { _a1[_n1] = _i; _n1++; } }   // ascending index
        var _cx = floor((_x[_i] + BTA_FIELD_MID) / BTA__GRID) + 1, _cy = floor(_y[_i] / BTA__GRID) + 1;
        if (_cx < 0) _cx = 0; else if (_cx >= _GW) _cx = _GW - 1;
        if (_cy < 0) _cy = 0; else if (_cy >= _GH) _cy = _GH - 1;
        _c = _cy * _GW + _cx; _cell[_i] = _c;
        if (_head[_c] == -1) { _used[_nu] = _c; _nu++; }
        _next[_i] = _head[_c]; _head[_c] = _i;
    }
    _b.gridUsedN = _nu; _b.alvN[0] = _n0; _b.alvN[1] = _n1;
}

/// @function bta__separate(battle)
/// @description Push standing figures apart through the frame's grid (bta__grid). Reads start-of-frame positions, writes
/// only nx/ny. Every push is quantised to 1/256 px: sums of dyadic values are exact, so the ORDER neighbours are visited
/// cannot matter and a mirrored battle stays mirrored.
function bta__separate(_b) {
    var _head = _b.gridHead, _next = _b.gridNext, _x = _b.x, _y = _b.y, _st = _b.state, _n = _b.n, _i, _j, _c;
    var _side = _b.side, _slot = _b.slot, _nx = _b.nx, _ny = _b.ny, _cell = _b.cell, _sep2 = BTA__SEP * BTA__SEP, _GW = BTA__GW, _GH = BTA__GH;
    for (_i = 0; _i < _n; _i++) {
        if (_next[_i] == -2 || (_st[_i] != BTA_ALIVE && _st[_i] != BTA_ROUTING)) continue;
        _c = _cell[_i];
        var _gcx = _c mod _GW, _gcy = _c div _GW;
        var _gx0 = (_gcx > 0) ? _gcx - 1 : 0, _gx1 = (_gcx < _GW - 1) ? _gcx + 1 : _GW - 1;
        var _gy0 = (_gcy > 0) ? _gcy - 1 : 0, _gy1 = (_gcy < _GH - 1) ? _gcy + 1 : _GH - 1;
        var _px = 0, _py = 0, _xi = _x[_i], _yi = _y[_i];
        for (var _gy = _gy0; _gy <= _gy1; _gy++) {
            var _rowc = _gy * _GW;
            for (var _gx = _gx0; _gx <= _gx1; _gx++) {
                _j = _head[_rowc + _gx];
                while (_j >= 0) {
                    if (_j != _i && (_st[_j] == BTA_ALIVE || _st[_j] == BTA_ROUTING)) {
                        var _dx = _xi - _x[_j], _dy = _yi - _y[_j], _d2 = _dx * _dx + _dy * _dy;
                        if (_d2 < _sep2) {
                            var _d = sqrt(_d2);
                            // exactly stacked: part by side and parity (0.001 px, never a sub-epsilon tolerance: doctrine s3)
                            if (_d < 0.001) { _dx = (_side[_i] == 0) ? -1 : 1; _dy = (_slot[_i] & 1) ? 0.5 : -0.5; _d = sqrt(_dx * _dx + _dy * _dy); }
                            var _push = (BTA__SEP - _d) * 0.35 / _d;
                            _px += round(_dx * _push * 256) / 256; _py += round(_dy * _push * 256) / 256;
                        }
                    }
                    _j = _next[_j];
                }
            }
        }
        _nx[_i] += _px; _ny[_i] += _py;
    }
}

/// @function bta__nearest_enemy(battle, i)
/// @description The nearest fighting enemy of figure i, or -1. EXACT: rings of grid cells outward from i's own cell, and
/// it stops only when the best found is nearer than anything a further ring could hold (ring r+1 is at least r cells
/// away); past four rings (32 px) it scans the frame's list of the other side's living figures (bta__grid builds it).
/// MEASURED (2026-10-29, suite stage 13 profile): a twelve-ring search cost ~0.3 ms a query once the armies stood apart,
/// as much as the scan it was meant to avoid; four rings keep a melee query to a few cells.
function bta__nearest_enemy(_b, _i) {
    var _best = -1, _bd = 1000000000000, _s = _b.side[_i], _x = _b.x, _y = _b.y, _xi = _x[_i], _yi = _y[_i], _side = _b.side, _st = _b.state;
    var _head = _b.gridHead, _next = _b.gridNext, _GW = BTA__GW, _GH = BTA__GH, _c = _b.cell[_i], _cx = _c mod _GW, _cy = _c div _GW, _j;
    for (var _r = 0; _r <= 4; _r++) {
        for (var _gy = _cy - _r; _gy <= _cy + _r; _gy++) {
            if (_gy < 0 || _gy >= _GH) continue;
            var _stepx = (_gy == _cy - _r || _gy == _cy + _r || _r == 0) ? 1 : 2 * _r;
            for (var _gx = _cx - _r; _gx <= _cx + _r; _gx += _stepx) {
                if (_gx < 0 || _gx >= _GW) continue;
                _j = _head[_gy * _GW + _gx];
                while (_j >= 0) {
                    if (_side[_j] != _s && _st[_j] == BTA_ALIVE) {
                        var _ex = _x[_j] - _xi, _ey = _y[_j] - _yi, _dd = _ex * _ex + _ey * _ey;
                        if (_dd < _bd || (_dd == _bd && _j < _best)) { _bd = _dd; _best = _j; }
                    }
                    _j = _next[_j];
                }
            }
        }
        if (_best >= 0 && _bd <= sqr(_r * BTA__GRID)) return _best;
    }
    // every living enemy, in ascending index (ties go to the lower index, as a scan of every figure would)
    var _list = (_s == 0) ? _b.alv1 : _b.alv0, _ln = _b.alvN[1 - _s];
    _best = -1; _bd = 1000000000000;
    for (var _q = 0; _q < _ln; _q++) {
        _j = _list[_q];
        var _dx = _x[_j] - _xi, _dy = _y[_j] - _yi, _d = _dx * _dx + _dy * _dy;
        if (_d < _bd) { _bd = _d; _best = _j; }
    }
    return _best;
}

/// @function bta__launch(battle, kind, i, j, x1, y1, T)
function bta__launch(_b, _kind, _i, _j, _x1, _y1, _T) {
    for (var _k = 0; _k < BTA__PMAX; _k++) {
        if (_b.plive[_k]) continue;
        _b.plive[_k] = 1; _b.pkind[_k] = _kind; _b.pfrom[_k] = _i; _b.pto[_k] = _j;
        _b.px0[_k] = _b.x[_i]; _b.py0[_k] = _b.y[_i] - 6; _b.px1[_k] = _x1; _b.py1[_k] = _y1; _b.pt[_k] = 0; _b.pT[_k] = max(1, _T);
        if (_k >= _b.pn) _b.pn = _k + 1;
        return _k;
    }
    return -1;
}

/// @function bta__near(battle, x, y, rings)
/// @description Every figure binned this frame in the (2 rings + 1)^2 grid cells around the point (x from the centre line).
function bta__near(_b, _x, _y, _r) {
    var _out = [], _GW = BTA__GW, _GH = BTA__GH, _head = _b.gridHead, _next = _b.gridNext;
    var _cx = floor((_x + BTA_FIELD_MID) / BTA__GRID) + 1, _cy = floor(_y / BTA__GRID) + 1;
    for (var _gy = max(0, _cy - _r); _gy <= min(_GH - 1, _cy + _r); _gy++) for (var _gx = max(0, _cx - _r); _gx <= min(_GW - 1, _cx + _r); _gx++) {
        var _j = _head[_gy * _GW + _gx];
        while (_j >= 0) { array_push(_out, _j); _j = _next[_j]; }
    }
    return _out;
}

/// @function bta__land(battle, k)
function bta__land(_b, _k) {
    var _i = _b.pfrom[_k], _x = _b.px1[_k], _y = _b.py1[_k], _s = _b.side[_i], _j = _b.pto[_k], _q;
    if (_b.pkind[_k] == 1) {   // arrow
        var _hit = -1;
        if (_j >= 0 && _b.state[_j] != BTA_DEAD && _b.state[_j] != BTA_FLED) { var _dx = _b.x[_j] - _x, _dy = _b.y[_j] - _y; if (_dx * _dx + _dy * _dy < 256) _hit = _j; }
        if (_hit < 0) {   // anyone of theirs within 12 px of where it fell: two rings of 8 px cells hold every candidate
            var _bd = 144, _list = bta__near(_b, _x, _y, 2);
            for (var _li = 0; _li < array_length(_list); _li++) {
                _q = _list[_li];
                if (_b.side[_q] == _s || (_b.state[_q] != BTA_ALIVE && _b.state[_q] != BTA_ROUTING)) continue;
                var _ex = _b.x[_q] - _x, _ey = _b.y[_q] - _y, _d = _ex * _ex + _ey * _ey;
                if (_d < _bd || (_d == _bd && _q < _hit)) { _bd = _d; _hit = _q; }
            }
        }
        if (_hit >= 0) { bta__hurt(_b, _hit, bta__damage(_b, _i, _hit, 1)); bta__emit(_b, BTA_EV_ARROW_HIT, _x, _y, _hit); }
        else bta__emit(_b, BTA_EV_ARROW_MISS, _x, _y, _k);
    } else {                   // spell burst
        var _rad = 30;
        bta__emit(_b, BTA_EV_BURST, _x, _y, _i);
        var _cand = bta__near(_b, _x, _y, 4);   // 30 px < four 8 px cells from anywhere in the centre cell
        array_sort(_cand, true);                // hurt in index order, as a scan of every figure would
        for (var _ci = 0; _ci < array_length(_cand); _ci++) {
            _q = _cand[_ci];
            if (_b.side[_q] == _s || (_b.state[_q] != BTA_ALIVE && _b.state[_q] != BTA_ROUTING)) continue;
            var _fx = _b.x[_q] - _x, _fy = _b.y[_q] - _y, _dd = _fx * _fx + _fy * _fy;
            if (_dd < _rad * _rad) bta__hurt(_b, _q, bta__damage(_b, _i, _q, 2) * (1 - sqrt(_dd) / _rad * 0.6));
        }
    }
    _b.plive[_k] = 0;
}

/// @function bta_battle_step(battle)
/// @description Advance the battle one frame (call once per Step at 60 fps, or several times to fast-forward). Writes
/// this frame's events into battle.evType/evX/evY/evA[0 .. evN-1] (BTA_EV_*). Does nothing once battle.over.
/// @returns {Real} the number of events written this frame
function bta_battle_step(_b) {
    if (!is_struct(_b) || !variable_struct_exists(_b, "evN")) return 0;
    _b.evN = 0;
    if (_b.over) return 0;
    _b.frame++;
    var _f = _b.frame, _i, _j, _k, _n = _b.n;
    var _x = _b.x, _y = _b.y, _nx = _b.nx, _ny = _b.ny, _st = _b.state, _side = _b.side, _role = _b.role, _cd = _b.cd;
    var _tg = _b.target, _act = _b.act, _face = _b.face, _slot = _b.slot, _chg = _b.charged;
    // the rules as flat per-role and per-side arrays, built once at create from bta_roles()/bta_forms() (one source)
    var _rSpd = _b.rSpd, _rRange = _b.rRange, _rReach = _b.rReach, _rCd = _b.rCd, _rShot = _b.rShot, _fSpd = _b.fSpd;
    for (_i = 0; _i < _n; _i++) { _nx[_i] = _x[_i]; _ny[_i] = _y[_i]; }
    bta__grid(_b);   // once a frame, from the start-of-frame positions; every search below reads it
    // projectiles
    for (_k = 0; _k < _b.pn; _k++) { if (!_b.plive[_k]) continue; _b.pt[_k]++; if (_b.pt[_k] >= _b.pT[_k]) bta__land(_b, _k); }
    while (_b.pn > 0 && !_b.plive[_b.pn - 1]) _b.pn--;
    // soldiers
    for (_i = 0; _i < _n; _i++) {
        var _s0 = _st[_i];
        if (_s0 == BTA_DEAD || _s0 == BTA_FLED) continue;
        var _rid = _role[_i], _sd = _side[_i], _dir = (_sd == 0) ? 1 : -1;
        if (_act[_i] < 60000) _act[_i]++;
        if (_s0 == BTA_ROUTING) {   // routing: run for the home edge
            _nx[_i] = _x[_i] - _dir * _rSpd[_rid] * 1.5; _face[_i] = -_dir;
            if (_nx[_i] < -BTA_FIELD_MID - 12 || _nx[_i] > BTA_FIELD_MID + 12) _st[_i] = BTA_FLED;
            continue;
        }
        if (_cd[_i] > 0) _cd[_i]--;
        _j = _tg[_i];
        // staggered by the figure's place IN ITS OWN ARMY, so mirror figures retarget on the same frames
        if (_j < 0 || _st[_j] != BTA_ALIVE || ((_slot[_i] + _f) mod 20) == 0) { _j = bta__nearest_enemy(_b, _i); _tg[_i] = _j; }
        if (_j < 0) continue;
        var _dx = _x[_j] - _x[_i], _dy = _y[_j] - _y[_i], _dist = sqrt(_dx * _dx + _dy * _dy);
        if (_dist < 0.001) _dist = 0.001;
        _face[_i] = (_dx >= 0) ? 1 : -1;
        var _range = _rRange[_rid];
        if (_range > 0 && _dist <= _range && _dist > 42) {
            if (_cd[_i] <= 0) {
                _cd[_i] = _rCd[_rid] * (0.9 + bta_rnd(_b.rng) * 0.2); _act[_i] = 0;
                var _spread = _dist * 0.07;
                var _tx = _x[_j] + (bta_rnd(_b.rng) - 0.5) * _spread * 2;
                var _ty = _y[_j] + (bta_rnd(_b.rng) - 0.5) * _spread;
                if (_rShot[_rid] > 0) { bta__launch(_b, 1, _i, _j, _tx, _ty, round(26 + _dist / 7)); bta__emit(_b, BTA_EV_LOOSE, _x[_i], _y[_i], _i); }
                else { bta__launch(_b, 2, _i, _j, _x[_j], _y[_j], 34); bta__emit(_b, BTA_EV_CAST, _x[_i], _y[_i], _i); }
            }
            continue;
        }
        if (_dist <= _rReach[_rid] + 2) {
            if (_cd[_i] <= 0) {
                _cd[_i] = _rCd[_rid] * (0.9 + bta_rnd(_b.rng) * 0.2); _act[_i] = 0;
                bta__hurt(_b, _j, bta__damage(_b, _i, _j, 0));
                bta__emit(_b, BTA_EV_BLOW, (_x[_i] + _x[_j]) / 2, (_y[_i] + _y[_j]) / 2 - 6, _i);
            }
            continue;
        }
        var _sp = _rSpd[_rid] * _fSpd[_sd];
        if (_rid == BTA_HORSE && !_chg[_i] && _dist < 140) { _sp *= 1.5; if (_dist > 120) bta__emit(_b, BTA_EV_CHARGE, _x[_i], _y[_i], _i); }
        if (_dist > BTA__ENGAGE && _rid != BTA_HORSE) {
            // the approach: march STRAIGHT AHEAD as a body, drifting gently toward the enemy, so a regiment arrives as a line
            var _ahead = (_dx >= 0) ? 1 : -1;
            _nx[_i] = _x[_i] + _ahead * _sp * 0.92; _ny[_i] = _y[_i] + (_dy / _dist) * _sp * 0.22;
        } else { _nx[_i] = _x[_i] + _dx / _dist * _sp; _ny[_i] = _y[_i] + _dy / _dist * _sp * 0.8; }
    }
    bta__separate(_b);
    for (_i = 0; _i < _n; _i++) {
        var _yy = _ny[_i];
        if (_yy < BTA_FIELD_TOP) _yy = BTA_FIELD_TOP; else if (_yy > BTA_FIELD_BOTTOM) _yy = BTA_FIELD_BOTTOM;
        _x[_i] = _nx[_i]; _y[_i] = _yy;
    }
    // damage, all at once: a figure killed this frame still landed its own blow
    var _pend = _b.pend, _hp = _b.hp;
    for (_j = 0; _j < _n; _j++) {
        var _d = _pend[_j];
        if (_d == 0) continue;
        _pend[_j] = 0;
        if (_st[_j] != BTA_ALIVE && _st[_j] != BTA_ROUTING) continue;
        _hp[_j] -= _d;
        if (_hp[_j] <= 0) {
            _hp[_j] = 0;
            if (_st[_j] == BTA_ALIVE) _b.sideActive[_side[_j]]--;
            _st[_j] = BTA_DEAD; _b.deadAt[_j] = _f; _b.regAlive[_b.reg[_j]]--;
            bta__emit(_b, BTA_EV_DEATH, _x[_j], _y[_j], _j);
        }
    }
    if ((_f mod 30) == 0) bta__morale(_b);
    if (_b.sideActive[0] <= 0 || _b.sideActive[1] <= 0) bta__finish(_b, (_b.sideActive[0] > 0) ? 0 : ((_b.sideActive[1] > 0) ? 1 : -1));
    else if (_f >= _b.timeLimit) {
        var _p0 = bta__power(_b, 0), _p1 = bta__power(_b, 1);
        bta__finish(_b, (_p0 > _p1 * 1.15) ? 0 : ((_p1 > _p0 * 1.15) ? 1 : -1));
    }
    return _b.evN;
}

/// @function bta__power(battle, side)
/// @description Fighting power of a side (hp-weighted, living and not routing).
function bta__power(_b, _side) {
    var _p = 0, _roles = bta_roles();
    for (var _i = 0; _i < _b.n; _i++) if (_b.side[_i] == _side && _b.state[_i] == BTA_ALIVE) _p += _b.hp[_i] * (_roles[_b.role[_i]].atk + 1);
    return _p;
}

/// @function bta_battle_share(battle, side)
/// @description The share of a side's starting strength still fighting (living, not routing, hit points / starting hit
/// points), 0..1. The scene charts it; morale reads it.
/// @returns {Real}
function bta_battle_share(_b, _side) {
    if (!is_struct(_b) || !variable_struct_exists(_b, "sideHp0") || !is_numeric(_side) || _side < 0 || _side > 1) return 0;
    var _h = 0;
    for (var _i = 0; _i < _b.n; _i++) if (_b.side[_i] == _side && _b.state[_i] == BTA_ALIVE) _h += _b.hp[_i];
    return (_b.sideHp0[_side] > 0) ? _h / _b.sideHp0[_side] : 0;
}

/// @function bta__morale(battle)
/// @description Twice a second: a regiment that has lost most of its men while its army is losing may break and run.
/// Morale compares SHARES, never raw power (a pike wall that was winning must not believe it is losing to horse).
function bta__morale(_b) {
    var _p0 = bta_battle_share(_b, 0), _p1 = bta_battle_share(_b, 1), _roles = bta_roles();
    for (var _r = 0; _r < array_length(_b.regs); _r++) {
        if (_b.regRouted[_r] || _b.regAlive[_r] <= 0) continue;
        var _g = _b.regs[_r], _frac = _b.regAlive[_r] / _b.regStart[_r];
        var _mine = (_g.side == 0) ? _p0 : _p1, _theirs = (_g.side == 0) ? _p1 : _p0;
        if (_frac < _roles[_g.roleId].rout && _mine < _theirs * 0.9 && bta_rnd(_b.rng) < 0.5) {
            _b.regRouted[_r] = 1;
            var _i0 = _b.regFig0[_r], _n = _b.regFigN[_r], _cx = 0, _cy = 0, _c = 0;
            for (var _i = _i0; _i < _i0 + _n; _i++) if (_b.state[_i] == BTA_ALIVE) {
                _b.state[_i] = BTA_ROUTING; _b.sideActive[_b.side[_i]]--; _cx += _b.x[_i]; _cy += _b.y[_i]; _c++;
            }
            bta__emit(_b, BTA_EV_ROUT, (_c > 0) ? _cx / _c : 0, (_c > 0) ? _cy / _c : 0, _r);
        }
    }
}

/// @function bta__finish(battle, winner)
function bta__finish(_b, _winner) {
    _b.over = true; _b.winner = _winner;
    for (var _i = 0; _i < _b.n; _i++) if (_b.state[_i] == BTA_ROUTING) _b.state[_i] = BTA_FLED;
}

/// @function bta_battle_run(battle, [maxFrames])
/// @description Step the battle to its end (or maxFrames). For headless use: a quick-resolve, a balance test.
/// @returns {Real} the frame the battle stopped on
function bta_battle_run(_b, _max = 0) {
    if (!is_struct(_b) || !variable_struct_exists(_b, "over")) return 0;
    var _lim = (is_numeric(_max) && _max > 0) ? _max : _b.timeLimit + 10;
    while (!_b.over && _b.frame < _lim) bta_battle_step(_b);
    return _b.frame;
}

/// @function bta_battle_standing(battle, side)
/// @description Where a side stands right now, in SOLDIERS: { count, alive, fled, dead } (fled includes the routing).
/// @returns {Struct}
function bta_battle_standing(_b, _side) {
    var _o = { count: 0, alive: 0, fled: 0, dead: 0 };
    if (!is_struct(_b) || !variable_struct_exists(_b, "regs") || !is_numeric(_side)) return _o;
    for (var _r = 0; _r < array_length(_b.regs); _r++) {
        var _g = _b.regs[_r];
        if (_g.side != _side) continue;
        var _al = 0, _fl = 0;
        for (var _i = _b.regFig0[_r]; _i < _b.regFig0[_r] + _b.regFigN[_r]; _i++) { if (_b.state[_i] == BTA_ALIVE) _al++; else if (_b.state[_i] != BTA_DEAD) _fl++; }
        var _sv = min(_g.count, round(_al * _g.rep)), _gone = min(_g.count - _sv, round(_fl * _g.rep));
        _o.count += _g.count; _o.alive += _sv; _o.fled += _gone; _o.dead += _g.count - _sv - _gone;
    }
    return _o;
}

/// @function bta_battle_result(battle)
/// @description The outcome in SOLDIERS, not figures. winner 0 = side 0 (the player's), 1 = side 1, -1 = neither held the
/// field. Per regiment: count = survived + fled + dead exactly; a 5,000-man horde is accounted for to the man.
/// @returns {Struct} { winner, frames, seconds, forms:[name, name], sides:[{count, survived, fled, dead} x2], regiments:[...] }
function bta_battle_result(_b) {
    var _out = { winner: -1, frames: 0, seconds: 0, forms: ["line", "line"], sides: [], regiments: [] };
    if (!is_struct(_b) || !variable_struct_exists(_b, "regs")) { _out.sides = [{ count: 0, survived: 0, fled: 0, dead: 0 }, { count: 0, survived: 0, fled: 0, dead: 0 }]; return _out; }
    _out.winner = _b.winner; _out.frames = _b.frame; _out.seconds = round(_b.frame / 60);
    _out.forms = [bta_form_name(_b.forms[0]), bta_form_name(_b.forms[1])];
    var _sd = [{ count: 0, survived: 0, fled: 0, dead: 0 }, { count: 0, survived: 0, fled: 0, dead: 0 }];
    for (var _r = 0; _r < array_length(_b.regs); _r++) {
        var _g = _b.regs[_r], _al = 0, _fl = 0;
        for (var _i = _b.regFig0[_r]; _i < _b.regFig0[_r] + _b.regFigN[_r]; _i++) { if (_b.state[_i] == BTA_ALIVE) _al++; else if (_b.state[_i] != BTA_DEAD) _fl++; }
        var _sv = min(_g.count, round(_al * _g.rep)), _gone = min(_g.count - _sv, round(_fl * _g.rep));
        var _row = { name: _g.name, role: _g.role, side: _g.side, count: _g.count, survived: _sv, fled: _gone, dead: _g.count - _sv - _gone, routed: (_b.regRouted[_r] != 0) };
        array_push(_out.regiments, _row);
        var _t = _sd[_g.side];
        _t.count += _row.count; _t.survived += _row.survived; _t.fled += _row.fled; _t.dead += _row.dead;
    }
    _out.sides = _sd;
    return _out;
}

/// @function bta_enemy_formation(army, seed)
/// @description The formation an army chooses for itself, read from its own make-up (many bows or mages: loose; many
/// riders: wedge; many pikes: square; otherwise any), then a seeded coin decides between that and a line. It never looks
/// at the other army's choice.
/// @returns {String}
function bta_enemy_formation(_army, _seed) {
    var _regs = bta__normalize(_army, 1), _n = [0, 0, 0, 0, 0], _t = 0;
    for (var _k = 0; _k < array_length(_regs); _k++) { _n[_regs[_k].roleId] += _regs[_k].count; _t += _regs[_k].count; }
    if (_t <= 0) return "line";
    var _st = bta_rng(string(_seed) + "|enemy-form"), _a;
    if ((_n[BTA_ARCHER] + _n[BTA_MAGE]) / _t > 0.45) _a = "loose";
    else if (_n[BTA_HORSE] / _t > 0.3) _a = "wedge";
    else if (_n[BTA_PIKE] / _t > 0.35) _a = "square";
    else _a = bta_form_name(floor(bta_rnd(_st) * 4));
    return (bta_rnd(_st) < 0.7) ? _a : "line";
}

// ---------------------------------------------------------------------------------------------------------------------
// Heraldry: the arms a regiment's banner carries (drawn by bta_art)
// ---------------------------------------------------------------------------------------------------------------------

/// @function bta_tinctures()
/// @description The heraldic palette: { metals: [[id, [r,g,b]] ...], colours: [...] }. Read-only.
function bta_tinctures() {
    static _t = {
        metals: [["or", [217, 169, 42]], ["argent", [236, 230, 214]]],
        colours: [["gules", [179, 38, 30]], ["azure", [31, 79, 154]], ["vert", [47, 122, 58]], ["purpure", [106, 47, 126]],
            ["sable", [38, 34, 31]], ["tenne", [181, 101, 29]], ["sanguine", [122, 31, 43]], ["celeste", [111, 168, 216]]]
    };
    return _t;
}

/// @function bta_heraldry_parts()
/// @description The vocabularies arms are struck from: { ordinaries (16), charges (14, "none" first), shapes (4) }.
function bta_heraldry_parts() {
    static _t = {
        ordinaries: ["plain", "pale", "fess", "bend", "bendsinister", "chevron", "cross", "saltire", "perpale", "perfess", "quarterly", "chief", "bordure", "pile", "barry", "paly"],
        charges: ["none", "star", "crescent", "annulet", "lozenge", "roundel", "crosslet", "tower", "sword", "key", "sun", "bird", "fleur", "axe"],
        shapes: ["swallowtail", "square", "pennon", "gonfalon"]
    };
    return _t;
}

/// @function bta_heraldry(name, side, [salt])
/// @description A regiment's arms, derived from its name and side: the same name always flies the same banner. The rule
/// of tincture is kept (a metal on a colour or a colour on a metal). Returns { field, fieldId, other, otherId, ordinary,
/// charge, chargeCol, shape, key } with colours as [r, g, b].
/// @returns {Struct}
function bta_heraldry(_name, _side, _salt = "") {
    var _st = bta_rng("arms|" + string(_name) + "|" + string(is_numeric(_side) ? floor(_side) : 0) + "|" + string(_salt));
    var _T = bta_tinctures(), _P = bta_heraldry_parts();
    var _metalField = bta_rnd(_st) < 0.35, _i;
    _i = floor(bta_rnd(_st) * (_metalField ? 2 : 8));
    var _field = _metalField ? _T.metals[_i] : _T.colours[_i];
    _i = floor(bta_rnd(_st) * (_metalField ? 8 : 2));
    var _other = _metalField ? _T.colours[_i] : _T.metals[_i];
    var _ord = _P.ordinaries[floor(bta_rnd(_st) * 16)];
    var _ch = _P.charges[floor(bta_rnd(_st) * 14)];
    if (_ord == "plain" && _ch == "none") _ch = _P.charges[1 + floor(bta_rnd(_st) * 13)];
    var _chT = _other;
    if (!(_ord == "plain" || _ord == "bordure" || _ord == "chief")) {
        if (bta_rnd(_st) >= 0.5) { _i = floor(bta_rnd(_st) * (_metalField ? 8 : 2)); _chT = _metalField ? _T.colours[_i] : _T.metals[_i]; }
    }
    var _shape = _P.shapes[floor(bta_rnd(_st) * 4)];
    return { field: _field[1], fieldId: _field[0], other: _other[1], otherId: _other[0], ordinary: _ord, charge: _ch,
        chargeCol: _chT[1], shape: _shape, key: _field[0] + "/" + _other[0] + "/" + _ord + "/" + _ch };
}
