/// bta_demo.gml - THE WAR ROOM: Battalia's demo. Five battles on five fields, each played start to finish through the
/// public API exactly as a game would call it. Left / Right or the mouse choose a formation; Enter or a click sounds the
/// charge; hold Shift, Space or the mouse to run the clash three times faster; Enter or a click on the war record goes on to
/// the next battle. N starts the next battle at any time.
///
/// Battalia - Army Battles for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function bta_demo_battles()
/// @description The five battles the war room plays, in order. Each is a ready bta_scene_create options struct.
/// @returns {Array}
function bta_demo_battles() {
    return [
        { title: "The Battle of Ashford", terrain: "meadow", seed: 7,
          player: { name: "Your Host", army: "foot:44:Iron Company, pike:32:Black Pikes, archer:34:Rivermarch Bows, horse:16:Queen's Own, mage:8:Ember Magi" },
          enemy: { name: "The Red Host", army: "foot:50:Crowfoot, foot:30:Harrow, archer:30:Sunspears, horse:20:Duskriders, mage:8:Ashen Guard" } },
        { title: "The Battle of Kell Ford", terrain: "snow", seed: 21,
          player: { name: "The Frost Wardens", colour: "#3c6e8a", army: "pike:60:Glacier Pikes, pike:40:Rime Guard, archer:30:Snowbows" },
          enemy: { name: "The Wolf Riders", colour: "#5a3a26", army: "horse:40:Wolfsheads, horse:30:Grey Lances, foot:30:Howlers" } },
        { title: "The Battle of the Salt Road", terrain: "desert", seed: 33,
          player: { name: "The Sun Court", colour: "#c08a1e", army: "archer:50:Dune Bows, mage:16:Sunseers, foot:40:Spearwall" },
          enemy: { name: "The Brass Legion", colour: "#7a2e4a", army: "foot:60:Brass Shields, foot:40:Red Spears, horse:16:Outriders" } },
        { title: "The Battle of Greyhowe", terrain: "moor", seed: 47,
          player: { name: "The Northern Muster", army: "foot:2400:Fyrd of Greyhowe, archer:1200:Fen Bows, horse:600:Thanes, pike:900:Hill Pikes" },
          enemy: { name: "The Black Tide", colour: "#3a3a46", army: "foot:3000:Tide Raiders, horse:900:Sea Riders, archer:800:Spearthrowers" } },
        { title: "The Battle of the Long Grass", terrain: "steppe", seed: 59,
          player: { name: "The Khan's Own", colour: "#2e7a5a", army: "horse:30:Swift Arrows, archer:40:Horse Bows, horse:24:Iron Hooves" },
          enemy: { name: "The Walled Cities", colour: "#8a2a22", army: "pike:50:City Pikes, foot:40:Watchmen, archer:24:Tower Bows" } }
    ];
}

/// @function bta_demo_create()
/// @returns {Struct}
function bta_demo_create() {
    var _d = { list: bta_demo_battles(), index: 0, scene: undefined, last: undefined, played: 0 };
    bta__demo_open(_d, 0);
    return _d;
}

/// @function bta__demo_open(demo, i)
function bta__demo_open(_d, _i) {
    if (is_struct(_d.scene)) bta_scene_free(_d.scene);
    _d.index = (_i + array_length(_d.list)) mod array_length(_d.list);
    var _o = _d.list[_d.index];
    _o.seed = (_o[$ "seed"] ?? 1) + _d.played * 1000;
    _d.scene = bta_scene_create(_o);
}

/// @function bta_demo_step(demo)
function bta_demo_step(_d) {
    if (!is_struct(_d) || !is_struct(_d.scene)) return;
    bta_scene_step(_d.scene);
    if (keyboard_check_pressed(ord("N"))) { _d.played++; bta__demo_open(_d, _d.index + 1); return; }
    if (bta_scene_done(_d.scene)) { _d.last = bta_scene_result(_d.scene); _d.played++; bta__demo_open(_d, _d.index + 1); }
}

/// @function bta_demo_draw(demo)
function bta_demo_draw(_d) {
    if (!is_struct(_d) || !is_struct(_d.scene)) return;
    var _gw = display_get_gui_width(), _gh = display_get_gui_height(), _k = min(_gw / 816, _gh / 624);
    draw_clear(make_colour_rgb(18, 14, 11));
    bta_scene_draw(_d.scene, (_gw - 816 * _k) / 2, (_gh - 624 * _k) / 2, _k);
}

/// @function bta_demo_free(demo)
function bta_demo_free(_d) { if (is_struct(_d) && is_struct(_d.scene)) { bta_scene_free(_d.scene); _d.scene = undefined; } }
