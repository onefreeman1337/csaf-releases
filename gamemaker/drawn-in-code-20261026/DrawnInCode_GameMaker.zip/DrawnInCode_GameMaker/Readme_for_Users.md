# Drawn in Code: a free GameMaker sampler

**GameMaker 2024.14 and later. Built and gated on runtime `2024.14.4.268`. Pure GML. Free.**

Three systems from Core Systems Asset Factory's paid GameMaker line, trimmed to a working sample, in one
project. Every picture on screen is drawn by the code at run time: the skill tree's marks, the item icons,
the widgets and even the type. There is no sprite, no font resource and no texture page anywhere in the
package.

| System | What it draws | In this sampler | In the full version |
| --- | --- | --- | --- |
| **Meridian** (`mer_*`) | skill trees laid out from their prerequisite graph, every node mark generated | 15 motifs in all 8 disciplines, the constellation layout | 60 motifs, 4 layouts (constellation, branching, radial, grid), the Armature tree editor with GML and JSON export |
| **Trove** (`trv_*`) | inventory icons from polygons and colour maths, with rarity treatments | 15 icon forms, all 12 materials, all 6 rarity tiers, the inventory grid and detail panel | 75 icon forms |
| **Kinetic UI** (`kui_*`) | interface widgets that move on springs, not tweens | `KuiButton`, `KuiBar`, `KuiMenu`, `KuiTabs` and `KuiContext`, all 4 themes | 8 widgets: also `KuiToggle`, `KuiSlider`, `KuiGauge`, `KuiDialog` |

The full versions are paid listings on https://csaf.itch.io: **Meridian**
(https://csaf.itch.io/meridian-gamemaker), **Trove** (https://csaf.itch.io/trove-gamemaker) and
**Kinetic UI** (https://csaf.itch.io/kinetic-ui).

---

## 1. Install

1. In GameMaker: **Tools > Import Local Package**, choose `DrawnInCode.yymps`, **Add All**, import.
2. Open **`rm_drawn_demo`** and press Play.
3. Press **1**, **2**, **3** (or Tab) to switch system and **T** to cycle the four themes. Left-click a node to
   buy it, right-click to refund, the wheel zooms. Drag an item to move it.

`obj_drawn_demo` is the quickstart for all three systems: read its Create event top to bottom.

---

## 2. Meridian: a skill tree in a dozen lines

Declare what a node is, what it costs and what it depends on. There is no x and no y anywhere: the layout
derives every position from the prerequisite graph, and every node's mark is drawn from its motif.

```gml
// Create
my_tree = mer_tree_make();
mer_tree_add(my_tree, "edge",   { name: "EDGE",   sigil: "THRUST", disc: 0, tier: MER_TIER_MAJOR, cost: 1, maxRank: 1, requires: [],       stat: "power", value: 4, desc: "The first lesson." });
mer_tree_add(my_tree, "cleave", { name: "CLEAVE", sigil: "CLEAVE", disc: 0, tier: MER_TIER_MINOR, cost: 1, maxRank: 3, requires: ["edge"], stat: "power", value: 3, desc: "Swings carry through." });
mer_tree_add(my_tree, "ward",   { name: "WARD",   sigil: "WARD",   disc: 1, tier: MER_TIER_MINOR, cost: 1, maxRank: 3, requires: ["edge"], stat: "guard", value: 6, desc: "A standing barrier." });
mer_layout_apply(0, my_tree);
my_prog = mer_progress_make(6);              // six points to spend
my_view = mer_view_make(my_tree);
mer_view_frame_all(my_view, my_tree, 800, 500, 40);

// Step
mer_view_update(my_view, my_tree, my_prog, device_mouse_x_to_gui(0), device_mouse_y_to_gui(0), 400, 250, delta_time / 1000000);
if (mouse_check_button_pressed(mb_left)) mer_view_click(my_view, my_tree, my_prog, true);

// Draw GUI
mer_view_draw(my_view, my_tree, my_prog, 0, 0, 800, 500, true);
mer_view_draw_detail(my_view, my_tree, my_prog, 820, 20, 300, 460);
```

Buying in code: `mer_progress_unlock(my_tree, my_prog, "cleave")` returns `MER_UNLOCK_OK` when it worked.
`mer_progress_refund(my_tree, my_prog, "cleave")` gives the points back. Any motif can be drawn on its own:
`mer_sigil_draw(mer_sigil_find("NEXUS"), x, y, 64)`.

The 15 motifs in this sampler: CLEAVE, THRUST, PARRY, SUNDER, EXECUTE, FOCUS, CHANNEL, WARD, SEAL, NEXUS,
IGNITE, CINDER, SCORCH, PYRE, BLAST. A node naming a motif the sampler does not ship falls back to one that it
does, chosen from the node's name, so a tree written for the full Meridian still draws here.

---

## 3. Trove: item icons that are drawn, not loaded

Items are data. The icon form and the material are named as strings; the icon is drawn from the form, the
material's palette and the rarity.

```gml
// Create
my_grid = new TrvGrid(100, 100, 5, 3, 88, 12);
my_grid.set(0, new TrvItem("SUNBRAND", "SWORD", "GOLD", TRV_RARITY_LEGENDARY));
my_grid.set(1, new TrvItem("GREATER HEALING", "POTION", "EMBER", TRV_RARITY_RARE, 6));
my_grid.set(2, new TrvItem("VAULT KEY", "KEY", "GOLD", TRV_RARITY_RARE));

// Step
my_grid.update(delta_time / 1000000, device_mouse_x_to_gui(0), device_mouse_y_to_gui(0),
               mouse_check_button_pressed(mb_left), mouse_check_button_released(mb_left));

// Draw GUI
my_grid.draw();
trv_draw_detail(640, 100, 330, 452, my_grid.item_selected(), 1, current_time / 1000);
```

One icon anywhere, at any size: `trv_icon_draw(trv_icon_find("CRYSTAL"), x, y, 64, trv_material_palette(trv_material_find("ARCANE")), 1)`.

The 15 forms in this sampler: SWORD, AXE, BOW, STAFF, HELM, SHIELD, BOOTS, POTION, MUSHROOM, BREAD, SCROLL,
CRYSTAL, KEY, INGOT, COIN. The 12 materials: STEEL, IRON, GOLD, SILVER, BRONZE, OBSIDIAN, WOOD, BONE, EMBER,
TIDE, ARCANE, VERDANT.

---

## 4. Kinetic UI: widgets on springs

One input context shared by every widget, and the widgets you want kept in instance variables. Each is one call
from Draw GUI that returns what the player did. A spring can be retargeted on any frame, so changing the
selection while the highlight is still moving simply curves it toward the new row.

```gml
// Create
my_ui   = new KuiContext();
my_menu = new KuiMenu(["CONTINUE", "NEW GAME", "QUIT"]);
my_hull = new KuiBar(1.0);
my_hit  = new KuiButton("TAKE A HIT");
my_tabs = new KuiTabs(["MAP", "ITEMS"]);

// Draw GUI
my_ui.poll(delta_time / 1000000);                     // once per frame, before any widget
var _page   = my_tabs.draw(my_ui, 520, 20, 400, 48);    // the active tab index
var _chosen = my_menu.draw(my_ui, 64, 64, 400, 56);     // the confirmed row, or -1
my_hull.draw(my_ui, 520, 100, 400, 22);
if (my_hit.draw(my_ui, 520, 140, 200, 54)) my_hull.set(my_hull.value - 0.18);
```

A falling `KuiBar` leaves a ghost behind it for a third of a second, so a hit reads at a glance.

---

## 5. Themes

Each system keeps its own theme, and all three ship the same four: violet, ember, terminal and frost.
`drawn_theme_apply(1)` sets the same one on all three at once. Your own theme is six colours:
`kui_theme_set(kui_theme_make(backdrop, surface, accent, accentAlt, text, textDim))`, and the same for
`trv_theme_make` and `mer_theme_make`.

---

## 6. Upgrading to a full version

Every script, function, constructor and macro name in this sampler matches the paid product it came from, with
the same parameters. To upgrade one system, delete that system's scripts from your project (all the `mer_*`,
or all the `trv_*`, or all the `kui_*` scripts), then import the full package: your code keeps working, and the
motifs, forms, layouts and widgets the sampler left out become available. The `drawn_*` script, `obj_drawn_demo`
and `rm_drawn_demo` belong to the sampler only; the three systems do not depend on them and you can delete them.

---

## 7. Names this package adds to your project

GML's global namespace is flat. Everything here is prefixed: `mer_` / `MER_`, `trv_` / `TRV_`, `kui_` / `KUI_`
and `dic_` / `DRAWN_`, plus the constructors `TrvItem`, `TrvGrid`, `TrvToasts`, `KuiContext`, `KuiButton`,
`KuiBar`, `KuiMenu` and `KuiTabs`. The globals are `global.__mer_*`, `global.__trv_*`, `global.__kui_*` and
`global.drawn_stage`.

---

## 8. Verification

GML cannot be unit-tested outside the engine, so every check ran in a real Igor-built Windows executable.
`DrawnInCode.exe -selftest` runs the in-engine suite and writes `dic_selftest.json` to the game's save folder:
it asserts the counts above, draws every motif and every icon and asserts that each one is drawn (ink is
counted, not assumed) and that no two are the same picture, buys and refunds a node, renders all three pages
and asserts they differ, and checks that one theme call restyles all three systems. HTML5, mobile and YYC were
not built.

---

## 9. Licence

Free. Use it in unlimited games, commercial or free, with no attribution required. Do not resell or
redistribute the package itself. Full terms in `LICENSE.txt`.

The code was written with AI assistance and the store listing says so. The pictures are drawn by that code at
run time; none of them is the output of an image model.

Core Systems Asset Factory
