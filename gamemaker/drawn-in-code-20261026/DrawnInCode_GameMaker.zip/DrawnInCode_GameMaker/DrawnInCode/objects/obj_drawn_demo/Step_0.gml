/// @file    obj_drawn_demo :: Step
/// @package Drawn in Code - free GameMaker sampler (Core Systems Asset Factory)
///
/// The lines a real game needs are the mer_view_update call, the tree clicks and grid.update. The rest
/// is page switching and the SCAFFOLDING self-drive, which is marked.

// A still or a self-test runs on a fixed clock so the same command gives the same pixels.
var _dt = (still || selftest) ? (1 / 60) : ((film > 0) ? (1 / 12) : min(delta_time / 1000000, 1 / 20));
elapsed += _dt;

var _mx = device_mouse_x_to_gui(0);
var _my = device_mouse_y_to_gui(0);
if (still || selftest || film > 0) { _mx = -999; _my = -999; }

// --- pages: 1 2 3, the arrows, or the tabs themselves (KuiTabs handles its own clicks) ----------------
if (!still && !selftest) {
    if (keyboard_check_pressed(ord("1"))) tabs.index = 0;
    if (keyboard_check_pressed(ord("2"))) tabs.index = 1;
    if (keyboard_check_pressed(ord("3"))) tabs.index = 2;
    if (keyboard_check_pressed(vk_right) || keyboard_check_pressed(vk_tab)) tabs.index = (tabs.index + 1) mod drawn_page_count();
    if (keyboard_check_pressed(vk_left)) tabs.index = (tabs.index + drawn_page_count() - 1) mod drawn_page_count();
    if (keyboard_check_pressed(ord("T"))) themeIndex = drawn_theme_apply(themeIndex + 1);
    if (keyboard_check_pressed(vk_escape)) game_end();
    if (keyboard_check_pressed(vk_anykey) || mouse_check_button_pressed(mb_any)) idleFor = 0;
    else idleFor += _dt;
}
if (tabs.index != page) {
    page = tabs.index;
    pageClock = 0;
    if (page == 1) grid.reveal();
    if (page == 2) menu.replay();
    if (page == 0) view.revealAt = 0;
}
pageClock += _dt;

// --- MERIDIAN: the view advances every frame, on or off its page, so returning to it never shows a
//     stalled frame. Clicks buy, right-clicks refund, the wheel zooms. -----------------------------------
var _onTree = (page == 0) && (_mx < PANEL_X) && (_my > TREE_Y);
mer_view_update(view, tree, prog, _onTree ? _mx : -999, _onTree ? _my : -999,
                TREE_X + TREE_W * 0.5, TREE_Y + TREE_H * 0.5, _dt);
if (_onTree && !still && !selftest) {
    if (mouse_check_button_pressed(mb_left)) mer_view_click(view, tree, prog, true);
    if (mouse_check_button_pressed(mb_right) && view.hoveredId != "") mer_progress_refund(tree, prog, view.hoveredId);
    if (mouse_wheel_up())   view.zoom.target = clamp(view.zoom.target * 1.12, 0.35, 2.0);
    if (mouse_wheel_down()) view.zoom.target = clamp(view.zoom.target / 1.12, 0.35, 2.0);
}

// --- TROVE: hover lifts, click selects, drag moves an item between slots ----------------------------
if (page == 1) {
    var _gx = _mx, _gy = _my;
    if (still || selftest) { _gx = grid.slot_x(0) + grid.cell * 0.5; _gy = grid.slot_y(0) + grid.cell * 0.5; }
    grid.update(_dt, _gx, _gy,
                (!still && !selftest) && mouse_check_button_pressed(mb_left),
                (!still && !selftest) && mouse_check_button_released(mb_left));
}

// =====================================================================================================
// SCAFFOLDING - the self-drive. After five seconds with no input the sampler operates itself, so an
// unattended recording has something to record. DELETE FOR YOUR GAME.
// =====================================================================================================
if (!still && !selftest && idleFor > 5) {
    driveClock += _dt;
    if (pageClock > 7) tabs.index = (tabs.index + 1) mod drawn_page_count();
    if (driveClock > 1.1) {
        driveClock = 0;
        driveStep += 1;
        if (page == 0) {
            var _order = ["bl_b", "bl_d", "ar_d", "fl_b", "fl_c", "bl_key", "ar_key", "fl_key"];
            var _id = _order[driveStep mod array_length(_order)];
            mer_progress_grant(prog, 3);
            view.selected = _id;
            if (mer_progress_unlock(tree, prog, _id) == MER_UNLOCK_OK) view.pulse[variable_struct_get(tree.byId, _id)] = 0;
            if ((driveStep mod array_length(_order)) == 0) {
                mer_progress_respec(tree, prog);
                var _seed = ["bl_root", "bl_a", "bl_a", "ar_root", "ar_a", "fl_root", "fl_a"];
                for (var _i = 0; _i < array_length(_seed); _i++) mer_progress_unlock(tree, prog, _seed[_i]);
            }
        } else if (page == 1) {
            grid.selected = (grid.selected + 1 + irandom(3)) mod array_length(items);
        } else {
            menu.index = (menu.index + 1) mod menu.count;
            if ((driveStep mod 2) == 0) {
                if (bar_hull.value > 0.3) { bar_hull.set(bar_hull.value - 0.18); bar_shield.set(max(0, bar_shield.value - 0.11)); }
                else { bar_hull.set(1); bar_shield.set(0.72); }
            }
        }
    }
    if (page == 1) {
        var _sx = grid.slot_x(grid.selected) + grid.cell * 0.5, _sy = grid.slot_y(grid.selected) + grid.cell * 0.5;
        grid.update(0, _sx, _sy, false, false);
    }
}
