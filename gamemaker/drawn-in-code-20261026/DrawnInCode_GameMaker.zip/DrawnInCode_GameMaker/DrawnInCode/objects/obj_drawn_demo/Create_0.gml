/// @file    obj_drawn_demo :: Create
/// @package Drawn in Code - free GameMaker sampler (Core Systems Asset Factory)
///
/// THIS OBJECT IS THE QUICKSTART FOR ALL THREE SYSTEMS. Read it top to bottom and you have seen how each
/// is meant to be used: a Meridian skill tree (mer_*), a Trove inventory whose icons are drawn by the
/// code (trv_*), and Kinetic UI widgets that move on springs (kui_*). Each block below is independent;
/// copy the one you want.
///
/// Two blocks are SCAFFOLDING and you should delete them rather than copy them: the command-line parser
/// (so store captures are deterministic) and the self-drive in Step (so an unattended recording has
/// something to record). They are marked where they appear.

// A GML runtime error opens a modal dialog, and a headless run would never exit. The handler records how
// far the run got and ends it cleanly instead.
global.drawn_stage = 0;
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("dic_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.drawn_stage) + ": " + string(_ex.message));
    file_text_close(_f);
    game_end();
});

random_set_seed(20261026);

// Declared before any early exit, because Step and Draw read them.
page        = 0;
themeIndex  = 0;
still       = false;
selftest    = false;
film        = 0;        // > 0: write that many frames of the self-driving demo, then exit (store GIF source)
idleFor     = 0;
elapsed     = 0;
driveClock  = 0;
driveStep   = 0;
pageClock   = 0;

// =====================================================================================================
// KINETIC UI (kui_*) - one input context shared by every widget, and the widgets you want, kept in
// instance variables and drawn from Draw GUI. Nothing to initialise, nothing to clean up.
// =====================================================================================================
ui   = new KuiContext();
tabs = new KuiTabs(["SKILL TREE", "ITEM ICONS", "SPRING UI"]);
menu = new KuiMenu(["CONTINUE", "NEW GAME", "LOAD SLOT", "SETTINGS", "QUIT"]);
bar_hull    = new KuiBar(1.0);
bar_shield  = new KuiBar(0.72);
btn_damage  = new KuiButton("TAKE 18 DAMAGE");
btn_repair  = new KuiButton("REPAIR");

// =====================================================================================================
// MERIDIAN (mer_*) - declare what a node IS, what it COSTS and what it DEPENDS ON. No x, no y: the
// layout derives every position from the prerequisite graph.
// =====================================================================================================
tree = mer_tree_make();
var _add = function(_t, _id, _name, _sig, _disc, _tier, _cost, _max, _req, _stat, _val, _desc) {
    mer_tree_add(_t, _id, {
        name: _name, sigil: _sig, disc: _disc, tier: _tier, cost: _cost, maxRank: _max,
        requires: _req, stat: _stat, value: _val, desc: _desc
    });
};
// --- BLADE ---
_add(tree, "bl_root", "EDGE",     "THRUST",  0, MER_TIER_MAJOR,    1, 1, [],                 "power",  4, "The first lesson. Everything martial grows from it.");
_add(tree, "bl_a",    "CLEAVE",   "CLEAVE",  0, MER_TIER_MINOR,    1, 3, ["bl_root"],        "power",  3, "Heavy swings carry through to a second target.");
_add(tree, "bl_b",    "PARRY",    "PARRY",   0, MER_TIER_MINOR,    1, 3, ["bl_root"],        "guard",  5, "Deflect an incoming blow and open the counter.");
_add(tree, "bl_d",    "SUNDER",   "SUNDER",  0, MER_TIER_MAJOR,    2, 2, ["bl_a"],           "pierce", 8, "Split armour. Damage ignores a share of protection.");
_add(tree, "bl_key",  "EXECUTE",  "EXECUTE", 0, MER_TIER_KEYSTONE, 3, 1, ["bl_d", "bl_b"],   "power", 20, "Finish a wounded enemy outright below a health threshold.");
// --- ARCANE ---
_add(tree, "ar_root", "FOCUS",    "FOCUS",   1, MER_TIER_MAJOR,    1, 1, [],                 "mana",   6, "Hold a spell steady while the world moves around you.");
_add(tree, "ar_a",    "CHANNEL",  "CHANNEL", 1, MER_TIER_MINOR,    1, 3, ["ar_root"],        "mana",   5, "Sustained casting drains more slowly.");
_add(tree, "ar_b",    "WARD",     "WARD",    1, MER_TIER_MINOR,    1, 3, ["ar_root"],        "guard",  6, "A standing barrier absorbs the first hit of a fight.");
_add(tree, "ar_d",    "SEAL",     "SEAL",    1, MER_TIER_MAJOR,    2, 2, ["ar_b"],           "guard", 10, "Bind a target in place for a short time.");
_add(tree, "ar_key",  "NEXUS",    "NEXUS",   1, MER_TIER_KEYSTONE, 3, 1, ["ar_a", "ar_d"],   "mana",  25, "Every spell you cast leaves a mote that feeds the next.");
// --- FLAME ---
_add(tree, "fl_root", "IGNITE",   "IGNITE",  4, MER_TIER_MAJOR,    1, 1, [],                 "power",  6, "Set what you strike alight.");
_add(tree, "fl_a",    "CINDER",   "CINDER",  4, MER_TIER_MINOR,    1, 3, ["fl_root"],        "power",  4, "Burning enemies scatter embers to their neighbours.");
_add(tree, "fl_b",    "SCORCH",   "SCORCH",  4, MER_TIER_MINOR,    1, 3, ["fl_root"],        "pierce", 5, "Fire strips armour as it burns.");
_add(tree, "fl_c",    "PYRE",     "PYRE",    4, MER_TIER_MAJOR,    2, 2, ["fl_a"],           "power", 11, "A killed enemy detonates.");
_add(tree, "fl_key",  "CONFLAGRATION", "BLAST", 4, MER_TIER_KEYSTONE, 3, 1, ["fl_c", "fl_b"], "power", 28, "Every burning target feeds every other. The field goes up at once.");
mer_layout_apply(0, tree);

// A tree that has clearly been PLAYED, so the first screen shows every node state.
prog = mer_progress_make(6);
mer_progress_grant(prog, 24);
var _seed = ["bl_root", "bl_a", "bl_a", "bl_b", "ar_root", "ar_a", "ar_b", "fl_root", "fl_a"];
for (var _i = 0; _i < array_length(_seed); _i++) mer_progress_unlock(tree, prog, _seed[_i]);

view = mer_view_make(tree);
view.selected = "bl_d";
// The tree region stops above the points readout, so no node is ever drawn under its caption.
TREE_X = 40;  TREE_Y = 118; TREE_W = 860; TREE_H = 474;
PANEL_X = 924; PANEL_Y = 128; PANEL_W = 316; PANEL_H = 512;
mer_view_frame_all(view, tree, TREE_W, TREE_H, 64);

// =====================================================================================================
// TROVE (trv_*) - items are DATA, with icon forms and materials named as strings. The icon is drawn by
// the code from the form, the material and the rarity: there is no image anywhere.
// =====================================================================================================
items = [
    new TrvItem("SUNBRAND",        "SWORD",    "GOLD",    TRV_RARITY_LEGENDARY)
        .with_stats([{k:"DAMAGE", v:"96-118"}, {k:"WEIGHT", v:"7.0"}, {k:"BURN", v:"+22"}])
        .with_blurb("FORGED AT NOON, QUENCHED AT DAWN.").with_value(9800),
    new TrvItem("EMBER AXE",       "AXE",      "EMBER",   TRV_RARITY_RARE)
        .with_stats([{k:"DAMAGE", v:"64-81"}, {k:"WEIGHT", v:"11.2"}]).with_value(1250),
    new TrvItem("HUNTER'S BOW",    "BOW",      "WOOD",    TRV_RARITY_UNCOMMON)
        .with_stats([{k:"DAMAGE", v:"38-52"}, {k:"RANGE", v:"64"}]).with_value(360),
    new TrvItem("WITCHWOOD STAFF", "STAFF",    "ARCANE",  TRV_RARITY_EPIC)
        .with_stats([{k:"POWER", v:"88"}, {k:"FOCUS", v:"+31"}]).with_value(3900),
    new TrvItem("WARDEN HELM",     "HELM",     "STEEL",   TRV_RARITY_RARE)
        .with_stats([{k:"ARMOUR", v:"96"}, {k:"SIGHT", v:"-4"}]).with_value(980),
    new TrvItem("KITE SHIELD",     "SHIELD",   "BRONZE",  TRV_RARITY_UNCOMMON)
        .with_stats([{k:"BLOCK", v:"74"}, {k:"WEIGHT", v:"9.4"}]).with_value(420),
    new TrvItem("TRAVEL BOOTS",    "BOOTS",    "WOOD",    TRV_RARITY_COMMON)
        .with_stats([{k:"ARMOUR", v:"14"}, {k:"SPEED", v:"+2"}]).with_value(60),
    new TrvItem("GREATER HEALING", "POTION",   "EMBER",   TRV_RARITY_RARE, 6)
        .with_stats([{k:"RESTORES", v:"240 HP"}]).with_blurb("TASTES OF IRON AND MINT.").with_value(180),
    new TrvItem("MOONCAP",         "MUSHROOM", "VERDANT", TRV_RARITY_COMMON, 24).with_value(12),
    new TrvItem("TRAIL BREAD",     "BREAD",    "WOOD",    TRV_RARITY_COMMON, 5).with_value(4),
    new TrvItem("SEALED DECREE",   "SCROLL",   "BONE",    TRV_RARITY_RARE)
        .with_blurb("THE WAX IS STILL WARM.").with_value(700),
    new TrvItem("SOULSTONE",       "CRYSTAL",  "ARCANE",  TRV_RARITY_MYTHIC, 1)
        .with_stats([{k:"CHARGE", v:"FULL"}]).with_blurb("SOMETHING INSIDE IS COUNTING.").with_value(31000),
    new TrvItem("VAULT KEY",       "KEY",      "GOLD",    TRV_RARITY_RARE).with_value(0),
    new TrvItem("STEEL INGOT",     "INGOT",    "STEEL",   TRV_RARITY_COMMON, 32).with_value(30),
    new TrvItem("CROWN MARKS",     "COIN",     "GOLD",    TRV_RARITY_COMMON, 99).with_value(1)
];
grid = new TrvGrid(338, 206, 5, 3, 88, 12);
for (var _i = 0; _i < array_length(items); _i++) grid.set(_i, items[_i]);
grid.selected = 0;

drawn_theme_apply(themeIndex);

// =====================================================================================================
// SCAFFOLDING - command-line arguments, so captures are deterministic. DELETE FOR YOUR GAME.
//   DrawnInCode.exe --page=1 --theme=2 --still      a settled still of one page
//   DrawnInCode.exe -selftest                       the in-engine suite, then exit
// =====================================================================================================
for (var _a = 0; _a <= parameter_count(); _a++) {
    var _p = string_lower(parameter_string(_a));
    if (string_copy(_p, 1, 7) == "--page=")  page = real(string_delete(_p, 1, 7));
    if (string_copy(_p, 1, 8) == "--theme=") themeIndex = real(string_delete(_p, 1, 8));
    if (_p == "--still")   still = true;
    if (_p == "-selftest") selftest = true;
    if (string_copy(_p, 1, 7) == "--film=") film = clamp(real(string_delete(_p, 1, 7)), 1, 2000);
}
page = clamp(page, 0, drawn_page_count() - 1);
tabs.index = page;
themeIndex = drawn_theme_apply(themeIndex);

if (still || selftest) {
    // Settle every spring and entrance on a fixed clock, so the same command gives the same pixels.
    view.revealAt = 4;
    for (var _s = 0; _s < 240; _s++) {
        mer_view_update(view, tree, prog, -999, -999, TREE_X + TREE_W * 0.5, TREE_Y + TREE_H * 0.5, 1 / 60);
        grid.update(1 / 60, grid.slot_x(0) + 44, grid.slot_y(0) + 44, false, false);
    }
    view.time = 3.1;
    menu.index = 1;
    menu.snap();
    bar_hull.set(0.62);
    window_set_cursor(cr_none);
}

if (film > 0 && !selftest) {
    // SCAFFOLDING - the filmstrip. A GameMaker window that loses focus stops repainting, so a screen
    // recorder captures one frame over and over. Instead the demo drives itself on a fixed 12 fps clock and
    // writes each frame from inside the engine: the same command always gives the same frames.
    idleFor = 99;
    var _fw = 1280, _fh = 720;
    var _fs = surface_create(_fw, _fh);
    for (var _fr = 0; _fr < film; _fr++) {
        event_perform(ev_step, ev_step_normal);
        surface_set_target(_fs); draw_clear(c_black); event_perform(ev_draw, ev_gui); surface_reset_target();
        var _num = string(_fr);
        while (string_length(_num) < 4) _num = "0" + _num;   // pad by arithmetic, never by replacing spaces
        surface_save(_fs, "dic_film_" + _num + ".png");
    }
    surface_free(_fs);
    var _ff = file_text_open_write("dic_film.json");
    file_text_write_string(_ff, "{\"ran\":true,\"stage\":99,\"pass\":" + string(film) + ",\"fail\":0,\"frames\":" + string(film) + "}");
    file_text_close(_ff);
    game_end();
}

if (selftest) {
    // =================================================================================================
    // THE IN-ENGINE SUITE. Counts the work and asserts INK - never that a call returned.
    // =================================================================================================
    var _st = { ran: true, pass: 0, fail: 0, stage: 0, notes: "", version: DRAWN_VERSION };
    var _ck = function(_st, _ok, _what) {
        if (_ok) _st.pass += 1; else { _st.fail += 1; _st.notes += (_st.notes == "" ? "" : " | ") + _what; }
    };

    // ---- stage 1: the sampler ships exactly what it says it ships -----------------------------------
    global.drawn_stage = 1; _st.stage = 1;
    _ck(_st, mer_sigil_count() == 15, "Meridian lite ships 15 motifs (" + string(mer_sigil_count()) + ")");
    _ck(_st, mer_discipline_count() == 8, "all 8 disciplines (" + string(mer_discipline_count()) + ")");
    _ck(_st, mer_layout_count() == 1 && mer_layout_name(3) == "CONSTELLATION", "one layout, the constellation");
    _ck(_st, trv_icon_count() == 15, "Trove lite ships 15 icon forms (" + string(trv_icon_count()) + ")");
    _ck(_st, trv_material_count() == 12, "all 12 materials (" + string(trv_material_count()) + ")");
    _ck(_st, mer_tree_count(tree) == 15, "the demo tree holds 15 nodes (" + string(mer_tree_count(tree)) + ")");
    var _names = ["CLEAVE", "THRUST", "PARRY", "SUNDER", "EXECUTE", "FOCUS", "CHANNEL", "WARD", "SEAL", "NEXUS",
                  "IGNITE", "CINDER", "SCORCH", "PYRE", "BLAST"];
    var _found = 0;
    for (var _i = 0; _i < array_length(_names); _i++) if (mer_sigil_find(_names[_i]) >= 0) _found++;
    _ck(_st, _found == 15, "every motif the demo tree names resolves (" + string(_found) + "/15)");
    var _forms = ["SWORD", "AXE", "BOW", "STAFF", "HELM", "SHIELD", "BOOTS", "POTION", "MUSHROOM", "BREAD",
                  "SCROLL", "CRYSTAL", "KEY", "INGOT", "COIN"];
    _found = 0;
    for (var _i = 0; _i < array_length(_forms); _i++) if (trv_icon_find(_forms[_i]) >= 0) _found++;
    _ck(_st, _found == 15, "every icon form the demo items name resolves (" + string(_found) + "/15)");

    // ---- stage 2: every motif and every icon is a DISTINCT picture with real ink -------------------
    global.drawn_stage = 2; _st.stage = 2;
    var _w = 1280, _h = 720;
    var _sf = surface_create(_w, _h);
    var _bg = make_colour_rgb(128, 128, 128);
    surface_set_target(_sf); draw_clear(_bg); surface_reset_target();
    _ck(_st, drawn_ink(_sf, _w, _h, 0, 0, _w, _h, _bg) == 0, "control: a cleared surface has no ink");
    surface_set_target(_sf); draw_set_colour(c_red); draw_rectangle(10, 10, 29, 19, false); draw_set_colour(c_white); surface_reset_target();
    var _ctl = drawn_ink(_sf, _w, _h, 0, 0, _w, _h, _bg);
    _ck(_st, _ctl >= 81 && _ctl <= 121, "control: a 20 x 10 red block reads 81..121 sampled px (" + string(_ctl) + ")");

    surface_set_target(_sf); draw_clear(_bg);
    for (var _i = 0; _i < 15; _i++) mer_sigil_draw(_i, 60 + _i * 80, 80, 64, undefined, 1, 1, 0);
    for (var _i = 0; _i < 15; _i++) trv_icon_draw(_i, 28 + _i * 80, 200, 64, trv_material_palette(_i mod 12), 1);
    surface_reset_target();
    var _sigInk = 0, _iconInk = 0, _thin = "";
    var _hs = [], _hi = [];
    for (var _i = 0; _i < 15; _i++) {
        var _a = drawn_ink(_sf, _w, _h, 20 + _i * 80, 40, 80, 80, _bg);
        var _b = drawn_ink(_sf, _w, _h, 20 + _i * 80, 192, 80, 80, _bg);
        if (_a < 120) _thin += " motif" + string(_i) + "=" + string(_a);
        if (_b < 120) _thin += " icon" + string(_i) + "=" + string(_b);
        _sigInk += (_a >= 120); _iconInk += (_b >= 120);
        array_push(_hs, drawn_hash_region(_sf, _w, _h, 20 + _i * 80, 40, 80, 80));
        array_push(_hi, drawn_hash_region(_sf, _w, _h, 20 + _i * 80, 192, 80, 80));
    }
    _ck(_st, _sigInk == 15, "15 of 15 motifs draw at least 120 sampled px of ink" + _thin);
    _ck(_st, _iconInk == 15, "15 of 15 icons draw at least 120 sampled px of ink" + _thin);
    var _dupS = 0, _dupI = 0;
    for (var _i = 0; _i < 15; _i++) for (var _j = _i + 1; _j < 15; _j++) {
        if (_hs[_i] == _hs[_j]) _dupS++;
        if (_hi[_i] == _hi[_j]) _dupI++;
    }
    _ck(_st, _dupS == 0, "no two motifs are the same picture (" + string(_dupS) + " duplicate pairs)");
    _ck(_st, _dupI == 0, "no two icons are the same picture (" + string(_dupI) + " duplicate pairs)");
    _st.sigilsInked = _sigInk; _st.iconsInked = _iconInk;
    surface_save(_sf, "dic_render_corpus.png");

    // the store's "what is inside" board, drawn by the product itself: every motif and every form it ships
    {
        var _k = kui_theme_get(), _tr = trv_theme_get();
        var _matFor = [0, 0, 9, 11, 3];   // weapon STEEL, armour STEEL, supplies VERDANT, arcane ARCANE, material GOLD
        surface_set_target(_sf); draw_clear(_k.backdrop);
        kui_draw_backdrop(0, 0, _w, _h);
        kui_draw_text(60, 44, "WHAT IS IN THE SAMPLER", 26, _k.text, 1, 5);
        kui_draw_text(62, 88, string(mer_sigil_count()) + " SKILL MOTIFS  /  " + string(trv_icon_count()) + " ITEM FORMS x "
                      + string(trv_material_count()) + " MATERIALS  /  4 SPRING WIDGETS  /  4 THEMES", 11, _k.accent, 0.95, 2);
        kui_draw_text(60, 140, "MERIDIAN MOTIFS", 11, _k.textDim, 1, 2);
        for (var _i = 0; _i < 15; _i++) {
            var _cx = 80 + _i * 80;
            mer_sigil_draw(_i, _cx, 214, 60, undefined, 1, 1, 0);
            mer_draw_text_centred(_cx, 258, mer_sigil_name(_i), 7, _k.textDim, 0.85);
        }
        kui_draw_text(60, 320, "TROVE ITEM FORMS", 11, _k.textDim, 1, 2);
        for (var _i = 0; _i < 15; _i++) {
            var _x0 = 48 + _i * 80;
            trv_draw_round_rect(_x0, 352, 64, 64, 10, _tr.surfaceLo, 0.9);
            trv_draw_round_rect_outline(_x0, 352, 64, 64, 10, _tr.edge, _tr.edgeAlpha * 0.8, 1);
            trv_icon_draw(_i, _x0 + 8, 360, 48, trv_material_palette(_matFor[trv_icon_category(_i)]), 1);
            trv_draw_text_centred(_x0 + 32, 428, trv_icon_name(_i), 7, _tr.textDim, 0.85);
        }
        kui_draw_text(60, 500, "THE FULL VERSIONS", 11, _k.textDim, 1, 2);
        kui_draw_text(60, 530, "MERIDIAN: 60 MOTIFS, 4 LAYOUTS AND THE ARMATURE TREE EDITOR", 13, _k.text, 1, 3);
        kui_draw_text(60, 562, "TROVE: 75 ITEM FORMS", 13, _k.text, 1, 3);
        kui_draw_text(60, 594, "KINETIC UI: 8 WIDGETS, ADDING TOGGLE, SLIDER, GAUGE AND DIALOG", 13, _k.text, 1, 3);
        kui_draw_text_right(_w - 60, _h - 52, "EVERY MARK ON THIS BOARD WAS DRAWN BY THE SAMPLER'S OWN CODE", 10, _k.accent, 0.9, 2);
        surface_reset_target();
        surface_save(_sf, "dic_render_board.png");
    }

    // ---- stage 3: each system DOES something - a purchase, a refund, a bar, a grid move -----------
    global.drawn_stage = 3; _st.stage = 3;
    var _pts = prog.points;
    var _r = mer_progress_unlock(tree, prog, "bl_d");
    _ck(_st, _r == MER_UNLOCK_OK && prog.points == _pts - 2, "buying SUNDER (cost 2) spends 2 points (" + string(_pts) + " -> " + string(prog.points) + ")");
    _ck(_st, mer_progress_unlock(tree, prog, "fl_key") != MER_UNLOCK_OK, "a keystone with unmet prerequisites is refused");
    mer_progress_refund(tree, prog, "bl_d");
    _ck(_st, prog.points == _pts, "refunding SUNDER returns its points (" + string(prog.points) + ")");
    bar_shield.set(0.25);
    _ck(_st, abs(bar_shield.value - 0.25) < 0.0001, "KuiBar.set moves the value");
    _ck(_st, is_struct(grid.item_selected()) && grid.item_selected().name == "SUNBRAND", "the grid's first slot holds SUNBRAND");
    bar_shield.set(0.72);

    // ---- stage 4: every page renders, and renders its own system ----------------------------------
    global.drawn_stage = 4; _st.stage = 4;
    // Widgets advance their springs when they DRAW (the tab underline, the bar fill), so each page is
    // stepped AND drawn for 90 frames before the shutter. One draw photographs every spring mid-flight.
    var _ph = [];
    for (var _pg = 0; _pg < 3; _pg++) {
        tabs.index = _pg; page = _pg;
        for (var _s = 0; _s < 90; _s++) {
            event_perform(ev_step, ev_step_normal);
            surface_set_target(_sf); draw_clear(_bg); event_perform(ev_draw, ev_gui); surface_reset_target();
        }
        var _bgc = kui_theme_get().backdrop;
        var _content = drawn_ink(_sf, _w, _h, 20, 130, 1240, 520, _bgc);
        _ck(_st, _content > 6000, "page " + string(_pg) + " (" + drawn_page_name(_pg) + ") draws content ink (" + string(_content) + ")");
        array_push(_ph, drawn_hash_region(_sf, _w, _h, 0, 120, _w, 540));
        surface_save(_sf, "dic_render_page" + string(_pg) + ".png");
    }
    _ck(_st, _ph[0] != _ph[1] && _ph[1] != _ph[2] && _ph[0] != _ph[2], "the three pages are three different pictures");

    // the same three pages in the other three shipped themes, for the store gallery
    for (var _ti = 1; _ti < 4; _ti++) {
        themeIndex = drawn_theme_apply(_ti);
        for (var _pg = 0; _pg < 3; _pg++) {
            tabs.index = _pg; page = _pg;
            for (var _s = 0; _s < 45; _s++) {
                event_perform(ev_step, ev_step_normal);
                surface_set_target(_sf); draw_clear(_bg); event_perform(ev_draw, ev_gui); surface_reset_target();
            }
            surface_save(_sf, "dic_render_page" + string(_pg) + "_t" + string(_ti) + ".png");
        }
    }
    themeIndex = drawn_theme_apply(0);

    // ---- stage 5: every theme restyles all three systems at once -----------------------------------
    global.drawn_stage = 5; _st.stage = 5;
    var _accents = [];
    for (var _ti = 0; _ti < 4; _ti++) {
        drawn_theme_apply(_ti);
        var _same = (kui_theme_get().accent == trv_theme_get().accent) && (trv_theme_get().accent == mer_theme_get().accent);
        _ck(_st, _same, "theme " + string(_ti) + " sets one accent on all three systems");
        array_push(_accents, kui_theme_get().accent);
    }
    _ck(_st, _accents[0] != _accents[1] && _accents[1] != _accents[2] && _accents[2] != _accents[3], "the four themes have four different accents");
    _ck(_st, drawn_theme_apply(-1) == 3 && drawn_theme_apply("x") == 0, "drawn_theme_apply wraps and refuses a non-number");
    drawn_theme_apply(0);

    surface_free(_sf);
    global.drawn_stage = 99; _st.stage = 99;
    drawn_selftest_write(_st);
    game_end();
}
