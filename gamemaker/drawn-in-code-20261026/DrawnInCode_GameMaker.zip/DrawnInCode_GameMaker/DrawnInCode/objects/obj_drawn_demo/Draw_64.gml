/// @file    obj_drawn_demo :: Draw GUI
/// @package Drawn in Code - free GameMaker sampler (Core Systems Asset Factory)
///
/// Everything on this screen is drawn by the code: the skill tree's marks, the item icons, the widgets
/// and the type. There is no sprite, no font resource and no texture page in the project.
///
/// Every local is declared once, here at the top: GML scopes `var` to the whole event.

var _W = display_get_gui_width();
var _H = display_get_gui_height();
var _k = kui_theme_get();
var _dt = (still || selftest) ? (1 / 60) : ((film > 0) ? (1 / 12) : min(delta_time / 1000000, 1 / 20));
var _i = 0, _x = 0, _y = 0, _cx = 0, _cy = 0, _cw = 0, _pc = undefined, _item = undefined, _note = "";

ui.poll(_dt);
kui_draw_backdrop(0, 0, _W, _H);

switch (page) {

// =====================================================================================================
case 0:   // MERIDIAN - the tree, laid out from its prerequisite graph, and the detail panel
// =====================================================================================================
    var _m = mer_theme_get();
    mer_view_draw(view, tree, prog, TREE_X, TREE_Y, TREE_W, TREE_H, true);
    // mask the strip behind the panel so a node panned off the right does not slide under it
    draw_set_colour(_m.backdrop); draw_set_alpha(1);
    draw_rectangle(PANEL_X - 14, TREE_Y - 4, _W, _H, false);
    draw_set_colour(c_white);
    mer_view_draw_detail(view, tree, prog, PANEL_X, PANEL_Y, PANEL_W, PANEL_H);

    _pc = mer_progress_purchased_count(tree, prog);
    _x = 40; _y = _H - 112;
    mer_draw_round_rect(_x, _y, 268, 40, 8, _m.surface, 0.9);
    mer_draw_round_rect_outline(_x, _y, 268, 40, 8, _m.edge, 0.5, 1);
    mer_draw_text(_x + 16, _y + 13, "POINTS", 10, _m.textDim, 0.9);
    mer_draw_text(_x + 84, _y + 10, string(prog.points), 15, _m.accent, 1);
    mer_draw_text(_x + 130, _y + 13, "SPENT", 10, _m.textDim, 0.9);
    mer_draw_text(_x + 188, _y + 10, string(_pc.ranks), 15, _m.text, 1);
    _note = string(mer_tree_count(tree)) + " NODES  /  " + string(mer_sigil_count()) + " MOTIFS x "
          + string(mer_discipline_count()) + " DISCIPLINES  /  " + mer_layout_name(0);
    mer_draw_text(324, _H - 99, _note, 10, _m.textDim, 0.8);
    break;

// =====================================================================================================
case 1:   // TROVE - an inventory whose every icon is polygons and colour maths
// =====================================================================================================
    var _tr = trv_theme_get();
    trv_draw_text(60, 150, "CARRIED", 12, _tr.textDim, 0.8);
    _cx = 0;
    for (_i = 0; _i < grid.capacity; _i++) if (!is_undefined(grid.items[_i])) _cx++;
    trv_draw_text(60, 172, string(_cx) + " / " + string(grid.capacity), 22, _tr.accent, 0.95);
    trv_draw_text(60, 228, string(trv_icon_count()) + " FORMS", 12, _tr.text, 0.9);
    trv_draw_text(60, 248, "X " + string(trv_material_count()) + " MATERIALS", 12, _tr.text, 0.9);
    trv_draw_text(60, 268, "X 6 RARITY TIERS", 12, _tr.text, 0.9);
    trv_draw_text(60, 304, "NO IMAGE FILES.", 10, _tr.textDim, 0.8);
    trv_draw_text(60, 322, "DRAG TO MOVE.", 10, _tr.textDim, 0.8);

    _cw = grid.cols * grid.cell + (grid.cols - 1) * grid.gap;
    _cy = grid.rows * grid.cell + (grid.rows - 1) * grid.gap;
    trv_draw_panel(grid.gridX - 22, grid.gridY - 22, _cw + 44, _cy + 44, 0.9);
    grid.draw();

    // the same form in three materials, under the grid: the recolour is computed, not painted
    _y = grid.gridY + _cy + 46;
    trv_draw_text(grid.gridX, _y, "ONE FORM, THREE MATERIALS", 10, _tr.textDim, 0.85);
    var _mats = ["STEEL", "GOLD", "OBSIDIAN"];
    for (_i = 0; _i < 3; _i++) {
        _x = grid.gridX + _i * 96;
        trv_draw_round_rect(_x, _y + 22, 80, 80, 13, _tr.surfaceLo, 0.85);
        trv_icon_draw(trv_icon_find("SWORD"), _x + 12, _y + 32, 56, trv_material_palette(trv_material_find(_mats[_i])), 1);
    }

    _item = grid.item_selected();
    trv_draw_detail(_W - 60 - 330, 186, 330, 452, _item, min(1, pageClock / 0.5), elapsed);
    break;

// =====================================================================================================
default:  // KINETIC UI - a menu whose highlight is a spring, and bars that leave a ghost when they fall
// =====================================================================================================
    _x = 64; _y = 136; _cw = _W - 128;
    kui_draw_panel(_x, _y, _cw, 456);
    kui_draw_scanlines(_x + 3, _y + 3, _cw - 6, 450, 3);
    kui_draw_corner_ticks(_x + 12, _y + 12, _cw - 24, 432, 16, undefined, 0.45, 2);

    menu.draw(ui, _x + 44, _y + 44, 430, 56);

    _cx = _x + 540; _cy = _y + 44; _cw = _W - 128 - 540 - 44;
    kui_draw_round_rect(_cx, _cy, _cw, 300, _k.radius, _k.surfaceLo, 0.55);
    kui_draw_round_rect_outline(_cx, _cy, _cw, 300, _k.radius, _k.edge, 0.35, 1);
    kui_draw_corner_ticks(_cx + 10, _cy + 10, _cw - 20, 280, 12, undefined, 0.5, 2);
    kui_draw_text(_cx + 26, _cy + 26, "SAVE SLOT 03", 17, _k.text, 1, 3);
    kui_draw_text(_cx + 26, _cy + 54, "THE DROWNED CAUSEWAY", 11, _k.textDim, 1, 2);

    kui_draw_text(_cx + 26, _cy + 104, "HULL", 11, _k.textDim, 1, 2);
    kui_draw_text_right(_cx + _cw - 26, _cy + 104, string(round(bar_hull.value * 100)) + " / 100", 11, _k.text, 1, 2);
    bar_hull.draw(ui, _cx + 26, _cy + 124, _cw - 52, 22);
    kui_draw_text(_cx + 26, _cy + 170, "SHIELD", 11, _k.textDim, 1, 2);
    kui_draw_text_right(_cx + _cw - 26, _cy + 170, string(round(bar_shield.value * 100)) + " / 100", 11, _k.text, 1, 2);
    bar_shield.draw(ui, _cx + 26, _cy + 190, _cw - 52, 22);
    kui_draw_text(_cx + 26, _cy + 240, "A FALLING BAR LEAVES A GHOST BEHIND IT.", 10, _k.textDim, 1, 2);

    if (btn_damage.draw(ui, _cx, _cy + 330, (_cw - 16) * 0.5, 54)) {
        bar_hull.set(bar_hull.value - 0.18);
        bar_shield.set(max(0, bar_shield.value - 0.11));
    }
    if (btn_repair.draw(ui, _cx + (_cw + 16) * 0.5, _cy + 330, (_cw - 16) * 0.5, 54)) {
        bar_hull.set(1.0);
        bar_shield.set(0.72);
    }
    break;
}

// --- masthead, drawn over the content so a panned tree never shows through it --------------------
draw_set_colour(_k.backdrop); draw_set_alpha(1);
draw_rectangle(0, 0, _W, TREE_Y - 6, false);
draw_rectangle(0, _H - 58, _W, _H, false);
draw_set_colour(c_white);
kui_draw_text(40, 30, "DRAWN IN CODE", 28, _k.text, 1, 5);
kui_draw_text(42, 74, "FREE GAMEMAKER SAMPLER  /  THREE SYSTEMS THAT DRAW THEIR OWN ART", 11, _k.accent, 0.95, 2);
draw_set_alpha(0.3); draw_set_colour(_k.edge);
draw_line(40, TREE_Y - 14, _W - 40, TREE_Y - 14);
draw_set_alpha(1); draw_set_colour(c_white);

tabs.draw(ui, _W - 40 - 560, 24, 560, 48);

// --- footer --------------------------------------------------------------------------------------
kui_draw_text(40, _H - 40, "1 2 3 OR TAB - SYSTEM   /   T - THEME (" + kui_theme_name(themeIndex) + ")", 10, _k.textDim, 1, 2);
kui_draw_text_right(_W - 40, _H - 40, "FULL VERSIONS: MERIDIAN / TROVE / KINETIC UI  -  CSAF.ITCH.IO", 10, _k.accent, 0.9, 2);
