/// @file    drawn_sampler
/// @package Drawn in Code - free GameMaker sampler (Core Systems Asset Factory)
///
/// @summary The sampler's own glue: one call that themes all three systems at once, the page names
///          the demo room uses, and the in-engine self-test (`DrawnInCode.exe -selftest`).
///
/// @remarks Everything else in this project belongs to one of three paid products and keeps that
///          product's names: mer_* is Meridian, trv_* is Trove, kui_* is Kinetic UI. Only the dic_*
///          names are the sampler's. Delete this script and obj_drawn_demo / rm_drawn_demo when you have
///          copied what you want; the three systems do not depend on them.
///
///          GML's global namespace is flat and shared with your code, so the one global here is
///          global.drawn_stage and the one macro is DRAWN_VERSION.

#macro DRAWN_VERSION "1.0.0"

/// @func   drawn_theme_apply(_index)
/// @desc   Sets the same shipped theme (violet, ember, terminal, frost - wrapping) on all three
///         systems, so the sampler restyles as one. Each system keeps its own theme otherwise.
/// @param  {Real} _index  Any integer. Non-numbers are treated as 0.
/// @return {Real} The wrapped index that was applied, 0..3.
function drawn_theme_apply(_index) {
    var _i = is_real(_index) ? floor(_index) : 0;
    _i = ((_i mod 4) + 4) mod 4;
    kui_theme_set(kui_theme_by_index(_i));
    trv_theme_set(trv_theme_by_index(_i));
    mer_theme_set(mer_theme_by_index(_i));
    return _i;
}

/// @func   drawn_page_count()
/// @desc   How many pages the demo room shows: the skill tree, the item icons and the spring UI.
/// @return {Real} 3.
function drawn_page_count() { return 3; }

/// @func   drawn_page_name(_index)
/// @desc   The tab label of a demo page.
/// @param  {Real} _index  Any integer; wrapped into range. Non-numbers are treated as 0.
/// @return {String} The label.
function drawn_page_name(_index) {
    var _i = is_real(_index) ? floor(_index) : 0;
    _i = ((_i mod 3) + 3) mod 3;
    switch (_i) {
        case 0:  return "SKILL TREE";
        case 1:  return "ITEM ICONS";
        default: return "SPRING UI";
    }
}

/// @func   drawn_ink(_surface, _w, _h, _x, _y, _rw, _rh, _bg)
/// @desc   Counts pixels in a rectangle of a surface that differ from a background colour by more than
///         24 (sum of channel differences), sampling every second column. The self-test asserts INK
///         this way, never that a draw call returned.
/// @param  {Id.Surface} _surface  A surface of size _w x _h.
/// @param  {Real} _w   Surface width.
/// @param  {Real} _h   Surface height.
/// @param  {Real} _x   Rectangle left.
/// @param  {Real} _y   Rectangle top.
/// @param  {Real} _rw  Rectangle width.
/// @param  {Real} _rh  Rectangle height.
/// @param  {Real} _bg  Background colour (BGR, as make_colour_rgb returns).
/// @return {Real} Sampled pixel count, or 0 when the surface does not exist.
function drawn_ink(_surface, _w, _h, _x, _y, _rw, _rh, _bg) {
    if (!is_real(_w) || !is_real(_h) || _w < 1 || _h < 1) return 0;
    if (!surface_exists(_surface)) return 0;
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _surface, 0);
    var _br = colour_get_red(_bg), _bgg = colour_get_green(_bg), _bb = colour_get_blue(_bg);
    var _n = 0;
    var _y0 = max(0, floor(_y)), _y1 = min(_h, floor(_y + _rh));
    var _x0 = max(0, floor(_x)), _x1 = min(_w, floor(_x + _rw));
    for (var _yy = _y0; _yy < _y1; _yy++) {
        for (var _xx = _x0; _xx < _x1; _xx += 2) {
            var _o = (_yy * _w + _xx) * 4;
            // surface buffers are BGRA
            var _d = abs(buffer_peek(_b, _o, buffer_u8) - _bb)
                   + abs(buffer_peek(_b, _o + 1, buffer_u8) - _bgg)
                   + abs(buffer_peek(_b, _o + 2, buffer_u8) - _br);
            if (_d > 24) _n++;
        }
    }
    buffer_delete(_b);
    return _n;
}

/// @func   drawn_hash_region(_surface, _w, _h, _x, _y, _rw, _rh)
/// @desc   A cheap fingerprint of a rectangle of a surface (sum of position-weighted channel values).
///         Two different drawings in the same rectangle give different fingerprints; the self-test uses
///         it to prove the sampler's icons and motifs are DISTINCT pictures, not one picture fifteen times.
/// @return {Real} The fingerprint, or -1 when the surface does not exist.
function drawn_hash_region(_surface, _w, _h, _x, _y, _rw, _rh) {
    if (!is_real(_w) || !is_real(_h) || _w < 1 || _h < 1) return -1;
    if (!surface_exists(_surface)) return -1;
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _surface, 0);
    var _s = 0, _k = 1;
    var _y0 = max(0, floor(_y)), _y1 = min(_h, floor(_y + _rh));
    var _x0 = max(0, floor(_x)), _x1 = min(_w, floor(_x + _rw));
    for (var _yy = _y0; _yy < _y1; _yy++) {
        for (var _xx = _x0; _xx < _x1; _xx++) {
            var _o = (_yy * _w + _xx) * 4;
            _s = (_s + (buffer_peek(_b, _o, buffer_u8) + 3 * buffer_peek(_b, _o + 1, buffer_u8)
                       + 7 * buffer_peek(_b, _o + 2, buffer_u8)) * _k) mod 1000000007;
            _k = (_k mod 9973) + 1;
        }
    }
    buffer_delete(_b);
    return _s;
}

/// @func   drawn_selftest_write(_st)
/// @desc   Writes the self-test result to dic_selftest.json in the game's save area.
/// @param  {Struct} _st  The result struct the self-test in obj_drawn_demo's Create event builds.
function drawn_selftest_write(_st) {
    var _f = file_text_open_write("dic_selftest.json");
    file_text_write_string(_f, json_stringify(_st));
    file_text_close(_f);
}
