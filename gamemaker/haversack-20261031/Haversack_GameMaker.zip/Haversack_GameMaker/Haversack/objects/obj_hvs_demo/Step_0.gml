/// @description One frame of the room.
if (!is_undefined(demo)) hvs_demo_step(demo);
