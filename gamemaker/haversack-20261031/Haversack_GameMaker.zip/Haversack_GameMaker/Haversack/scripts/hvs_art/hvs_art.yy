{
  "$GMScript": "v1",
  "%Name": "hvs_art",
  "name": "hvs_art",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}