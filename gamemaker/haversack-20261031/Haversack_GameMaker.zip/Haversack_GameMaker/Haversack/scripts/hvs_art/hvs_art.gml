/// hvs_art.gml - how Haversack draws: Oklch ramps, one vertex batch with GameMaker's limit counted in one place, the relief painter (an outline's walls shaded by
/// their normal against one fixed lamp, upper left), and the bake that turns those drawings into sprites. No drawing happens per frame here; the desk draws what
/// was baked. Everything drawn is premultiplied, so a baked sprite composites the same over any colour.
///
/// Haversack - A Spatial Inventory That Draws Its Own Containers. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

// ------------------------------------------------------------------------------------------------ colour

/// @function hvs__lin(u)
/// @description Internal. Linear light to sRGB.
function hvs__lin(_u) { return (_u <= 0.0031308) ? 12.92 * _u : 1.055 * power(_u, 1 / 2.4) - 0.055; }
/// @function hvs_oklch(L, C, hue)
/// @description An Oklch colour (lightness 0..1, chroma, hue in degrees) as a GameMaker colour. Chroma walks down until it fits, so the hue stays where it was put.
function hvs_oklch(_L, _C, _hdeg) {
    _L = clamp(hvs__n(_L, 0.5), 0, 1); _C = max(0, hvs__n(_C, 0)); var _h = degtorad(hvs__n(_hdeg, 0));
    var _r = 0, _g = 0, _b = 0;
    for (var _i = 0; _i < 24; _i++) {
        var _a = cos(_h) * _C, _bb = sin(_h) * _C;
        var _l1 = _L + 0.3963377774 * _a + 0.2158037573 * _bb, _m1 = _L - 0.1055613458 * _a - 0.0638541728 * _bb, _s1 = _L - 0.0894841775 * _a - 1.2914855480 * _bb;
        _l1 = _l1 * _l1 * _l1; _m1 = _m1 * _m1 * _m1; _s1 = _s1 * _s1 * _s1;
        _r = 4.0767416621 * _l1 - 3.3077115913 * _m1 + 0.2309699292 * _s1;
        _g = -1.2684380046 * _l1 + 2.6097574011 * _m1 - 0.3413193965 * _s1;
        _b = -0.0041960863 * _l1 - 0.7034186147 * _m1 + 1.7076147010 * _s1;
        if (_r >= -0.0015 && _g >= -0.0015 && _b >= -0.0015 && _r <= 1.0015 && _g <= 1.0015 && _b <= 1.0015) break;
        _C *= 0.92;
    }
    return make_colour_rgb(round(hvs__lin(clamp(_r, 0, 1)) * 255), round(hvs__lin(clamp(_g, 0, 1)) * 255), round(hvs__lin(clamp(_b, 0, 1)) * 255));
}
/// @function hvs_ramp(L, C, hue, spread)
/// @description Five stops from shadow to light around one base colour. The whole ramp slides to fit rather than clamping at its ends (a clamped ramp collapses), and shadows lean cool, lights warm.
/// @returns {array} Five colours, dark to light.
function hvs_ramp(_L, _C, _h, _spread = 0.25) {
    _L = hvs__n(_L, 0.5); _C = hvs__n(_C, 0.05); _h = hvs__n(_h, 0); _spread = hvs__n(_spread, 0.25);
    var _lo = _L - _spread, _hi = _L + _spread;
    if (_hi > 0.975) { _L -= _hi - 0.975; } else if (_lo < 0.07) { _L += 0.07 - _lo; }
    var _out = array_create(5, 0);
    for (var _i = 0; _i < 5; _i++) {
        var _t = (_i - 2) / 2;
        // warm lights, cool shadows, a touch less colour at both ends
        var _hd = hvs__hue_lean(_h, _t * 10);
        _out[_i] = hvs_oklch(_L + _t * _spread, _C * (1 - abs(_t) * 0.28), _hd);
    }
    return _out;
}
/// @function hvs__hue_lean(hue, amount)
/// @description Internal. Lean a hue toward warm (+) along the short way round to orange at 60 degrees.
function hvs__hue_lean(_h, _a) {
    var _d = angle_difference(60, _h); // the short way to warm
    return _h + sign(_d) * min(abs(_d), abs(_a)) * sign(_a);
}
/// @function hvs__ramp_at(ramp, t)
/// @description Internal. A continuous position on a five-stop ramp.
function hvs__ramp_at(_r, _t) {
    var _u = clamp(_t, 0, 1) * 4, _i = min(floor(_u), 3);
    return merge_colour(_r[_i], _r[_i + 1], _u - _i);
}

// ------------------------------------------------------------------------------------------------ the batch

/// @function hvs__b_begin()
/// @description Internal. Open the one triangle batch. Every vertex goes through hvs__tri, which is the only place GameMaker's per-batch vertex limit is counted.
function hvs__b_begin() { global.hvs__vn = 0; draw_primitive_begin(pr_trianglelist); }
/// @function hvs__b_end()
/// @description Internal. Close the batch.
function hvs__b_end() { draw_primitive_end(); }
/// @function hvs__tri(x0, y0, c0, a0, x1, y1, c1, a1, x2, y2, c2, a2)
/// @description Internal. One Gouraud triangle.
function hvs__tri(_x0, _y0, _c0, _a0, _x1, _y1, _c1, _a1, _x2, _y2, _c2, _a2) {
    if (global.hvs__vn > 894) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); global.hvs__vn = 0; }
    draw_vertex_colour(_x0, _y0, _c0, _a0); draw_vertex_colour(_x1, _y1, _c1, _a1); draw_vertex_colour(_x2, _y2, _c2, _a2);
    global.hvs__vn += 3;
}
/// @function hvs__quad(x0, y0, c0, a0, x1, y1, c1, a1, x2, y2, c2, a2, x3, y3, c3, a3)
/// @description Internal. Two triangles, corners in order round the quad.
function hvs__quad(_x0, _y0, _c0, _a0, _x1, _y1, _c1, _a1, _x2, _y2, _c2, _a2, _x3, _y3, _c3, _a3) {
    hvs__tri(_x0, _y0, _c0, _a0, _x1, _y1, _c1, _a1, _x2, _y2, _c2, _a2);
    hvs__tri(_x0, _y0, _c0, _a0, _x2, _y2, _c2, _a2, _x3, _y3, _c3, _a3);
}
/// @function hvs__rect(x, y, w, h, col, alpha)
/// @description Internal. A flat rectangle.
function hvs__rect(_x, _y, _w, _h, _c, _a) { hvs__quad(_x, _y, _c, _a, _x + _w, _y, _c, _a, _x + _w, _y + _h, _c, _a, _x, _y + _h, _c, _a); }
/// @function hvs__seg(x0, y0, x1, y1, width, col, alpha)
/// @description Internal. A straight stroke of a given width.
function hvs__seg(_x0, _y0, _x1, _y1, _w, _c, _a) {
    var _dx = _x1 - _x0, _dy = _y1 - _y0, _l = sqrt(_dx * _dx + _dy * _dy);
    if (_l < 0.0001) return;
    var _nx = -_dy / _l * _w * 0.5, _ny = _dx / _l * _w * 0.5;
    hvs__quad(_x0 + _nx, _y0 + _ny, _c, _a, _x1 + _nx, _y1 + _ny, _c, _a, _x1 - _nx, _y1 - _ny, _c, _a, _x0 - _nx, _y0 - _ny, _c, _a);
}
/// @function hvs__spot(x, y, r, col, alpha, segs)
/// @description Internal. A soft round glow, its alpha falling to zero at the rim. Add a stop for a broader centre.
function hvs__spot(_x, _y, _r, _c, _a, _n = 18) {
    for (var _i = 0; _i < _n; _i++) {
        var _a0 = _i / _n * 2 * pi, _a1 = (_i + 1) / _n * 2 * pi;
        hvs__tri(_x, _y, _c, _a, _x + cos(_a0) * _r, _y + sin(_a0) * _r, _c, 0, _x + cos(_a1) * _r, _y + sin(_a1) * _r, _c, 0);
    }
}
/// @function hvs__disc(x, y, r, col, alpha, segs)
/// @description Internal. A flat disc.
function hvs__disc(_x, _y, _r, _c, _a, _n = 16) {
    for (var _i = 0; _i < _n; _i++) {
        var _a0 = _i / _n * 2 * pi, _a1 = (_i + 1) / _n * 2 * pi;
        hvs__tri(_x, _y, _c, _a, _x + cos(_a0) * _r, _y + sin(_a0) * _r, _c, _a, _x + cos(_a1) * _r, _y + sin(_a1) * _r, _c, _a);
    }
}

// ------------------------------------------------------------------------------------------------ outlines

/// @function hvs__rr4(x, y, w, h, r0, r1, r2, r3, segs)
/// @description Internal. A rounded rectangle as a flat [x, y, ...] outline, clockwise on screen from the top-left corner; a radius per corner (TL, TR, BR, BL).
function hvs__rr4(_x, _y, _w, _h, _r0, _r1, _r2, _r3, _n = 5) {
    var _m = min(_w, _h) * 0.5;
    _r0 = min(_r0, _m); _r1 = min(_r1, _m); _r2 = min(_r2, _m); _r3 = min(_r3, _m);
    var _p = [];
    var _cx = [_x + _r0, _x + _w - _r1, _x + _w - _r2, _x + _r3], _cy = [_y + _r0, _y + _r1, _y + _h - _r2, _y + _h - _r3], _rs = [_r0, _r1, _r2, _r3];
    for (var _c = 0; _c < 4; _c++) {
        var _a0 = pi + _c * pi / 2;
        if (_rs[_c] <= 0.001) { array_push(_p, _cx[_c], _cy[_c]); continue; }
        for (var _i = 0; _i <= _n; _i++) { var _a = _a0 + _i / _n * pi / 2; array_push(_p, _cx[_c] + cos(_a) * _rs[_c], _cy[_c] + sin(_a) * _rs[_c]); }
    }
    return _p;
}
/// @function hvs__rr(x, y, w, h, r, segs)
/// @description Internal. A rounded rectangle with one radius.
function hvs__rr(_x, _y, _w, _h, _r, _n = 5) { return hvs__rr4(_x, _y, _w, _h, _r, _r, _r, _r, _n); }
/// @function hvs__ell(x, y, rx, ry, segs)
/// @description Internal. An ellipse as an outline.
function hvs__ell(_x, _y, _rx, _ry, _n = 20) {
    var _p = [];
    for (var _i = 0; _i < _n; _i++) { var _a = _i / _n * 2 * pi; array_push(_p, _x + cos(_a) * _rx, _y + sin(_a) * _ry); }
    return _p;
}
/// @function hvs__cap(x0, y0, x1, y1, r, segs)
/// @description Internal. A capsule: a stroke with round ends, as an outline.
function hvs__cap(_x0, _y0, _x1, _y1, _r, _n = 5) {
    var _a = arctan2(_y1 - _y0, _x1 - _x0), _p = [];
    for (var _i = 0; _i <= _n; _i++) { var _t = _a - pi / 2 + _i / _n * pi; array_push(_p, _x1 + cos(_t) * _r, _y1 + sin(_t) * _r); }
    for (var _i = 0; _i <= _n; _i++) { var _t = _a + pi / 2 + _i / _n * pi; array_push(_p, _x0 + cos(_t) * _r, _y0 + sin(_t) * _r); }
    return _p;
}
/// @function hvs__centroid(points)
/// @description Internal. The middle of an outline's points, as [x, y, largest radius].
function hvs__centroid(_p) {
    var _n = array_length(_p) div 2, _cx = 0, _cy = 0, _r = 0;
    for (var _i = 0; _i < _n; _i++) { _cx += _p[_i * 2]; _cy += _p[_i * 2 + 1]; }
    _cx /= _n; _cy /= _n;
    for (var _i = 0; _i < _n; _i++) _r = max(_r, point_distance(_cx, _cy, _p[_i * 2], _p[_i * 2 + 1]));
    return [_cx, _cy, _r];
}
/// @function hvs__area(points)
/// @description Internal. Twice the signed area of an outline (positive = clockwise on screen, y down).
function hvs__area(_p) {
    var _n = array_length(_p) div 2, _s = 0;
    for (var _i = 0; _i < _n; _i++) { var _j = (_i + 1) mod _n; _s += _p[_i * 2] * _p[_j * 2 + 1] - _p[_j * 2] * _p[_i * 2 + 1]; }
    return _s;
}

/// @function hvs__mass(points, ramp, bevel, ink, ink_px)
/// @description Internal. The relief painter. An outline (convex, or star-shaped about its middle) filled with a soft gradient across the lamp, its walls shaded by how squarely each faces the lamp. The bevel is a property of the edge: it is capped at 0.45 of the shortest edge, or it folds. ink_px > 0 draws a dark silhouette first.
function hvs__mass(_p, _ramp, _bevel, _ink = undefined, _inkpx = 0) {
    var _n = array_length(_p) div 2;
    if (_n < 3) return;
    var _flip = hvs__area(_p) < 0 ? -1 : 1;
    // the shortest real edge
    var _short = infinity;
    for (var _i = 0; _i < _n; _i++) {
        var _j = (_i + 1) mod _n, _l = point_distance(_p[_i * 2], _p[_i * 2 + 1], _p[_j * 2], _p[_j * 2 + 1]);
        if (_l > 0.05) _short = min(_short, _l);
    }
    var _bev = min(_bevel, _short * 0.95); // a vertex moves along its own normal, so the inset first folds a sampled corner at about the length of its shortest edge
    var _nxs = array_create(_n, 0), _nys = array_create(_n, 0);
    for (var _i = 0; _i < _n; _i++) {
        var _h = (_i + _n - 1) mod _n, _j = (_i + 1) mod _n;
        var _ax = _p[_i * 2] - _p[_h * 2], _ay = _p[_i * 2 + 1] - _p[_h * 2 + 1], _bx = _p[_j * 2] - _p[_i * 2], _by = _p[_j * 2 + 1] - _p[_i * 2 + 1];
        var _la = max(0.0001, sqrt(_ax * _ax + _ay * _ay)), _lb = max(0.0001, sqrt(_bx * _bx + _by * _by));
        var _nx = (_ay / _la + _by / _lb), _ny = -(_ax / _la + _bx / _lb), _ln = max(0.0001, sqrt(_nx * _nx + _ny * _ny));
        _nxs[_i] = _nx / _ln * _flip; _nys[_i] = _ny / _ln * _flip;
    }
    // the silhouette
    var _ctr = hvs__centroid(_p), _cx = _ctr[0], _cy = _ctr[1], _R = max(0.001, _ctr[2]);
    if (_inkpx > 0) {
        for (var _i = 0; _i < _n; _i++) {
            var _j = (_i + 1) mod _n;
            hvs__tri(_cx, _cy, _ink, 1, _p[_i * 2] + _nxs[_i] * _inkpx, _p[_i * 2 + 1] + _nys[_i] * _inkpx, _ink, 1, _p[_j * 2] + _nxs[_j] * _inkpx, _p[_j * 2 + 1] + _nys[_j] * _inkpx, _ink, 1);
        }
    }
    // the lamp is upper left: outward normal (-0.6, -0.8) faces it squarely
    var _lx = -0.6, _ly = -0.8;
    var _ccol = hvs__ramp_at(_ramp, 0.52);
    for (var _i = 0; _i < _n; _i++) {
        var _j = (_i + 1) mod _n;
        var _ix = _p[_i * 2] - _nxs[_i] * _bev, _iy = _p[_i * 2 + 1] - _nys[_i] * _bev, _jx = _p[_j * 2] - _nxs[_j] * _bev, _jy = _p[_j * 2 + 1] - _nys[_j] * _bev;
        // the face: a gentle gradient across the lamp
        var _ti = 0.52 + 0.18 * (((_ix - _cx) * _lx + (_iy - _cy) * _ly) / _R), _tj = 0.52 + 0.18 * (((_jx - _cx) * _lx + (_jy - _cy) * _ly) / _R);
        var _ci = hvs__ramp_at(_ramp, _ti), _cj = hvs__ramp_at(_ramp, _tj);
        hvs__tri(_cx, _cy, _ccol, 1, _ix, _iy, _ci, 1, _jx, _jy, _cj, 1);
        if (_bev > 0.01) {
            // the wall: shaded by its own normal; vertex normals keep a curve smooth, and a corner still turns
            var _di = 0.5 + 0.5 * (_nxs[_i] * _lx + _nys[_i] * _ly), _dj = 0.5 + 0.5 * (_nxs[_j] * _lx + _nys[_j] * _ly);
            var _wi = hvs__ramp_at(_ramp, _di), _wj = hvs__ramp_at(_ramp, _dj);
            hvs__quad(_p[_i * 2], _p[_i * 2 + 1], _wi, 1, _p[_j * 2], _p[_j * 2 + 1], _wj, 1, _jx, _jy, _cj, 1, _ix, _iy, _ci, 1);
        }
    }
}
/// @function hvs__recess(x, y, w, h, r, depth, col)
/// @description Internal. A sunk rim: dark on the side away from the lamp's reach, a lit lip on the near side. It reads as a hole cut in the surface.
function hvs__recess(_x, _y, _w, _h, _d, _c) {
    var _k = c_black;
    hvs__quad(_x - _d, _y - _d, _k, 0.55, _x + _w + _d, _y - _d, _k, 0.55, _x + _w, _y, _k, 0.25, _x, _y, _k, 0.25);
    hvs__quad(_x - _d, _y - _d, _k, 0.45, _x, _y, _k, 0.25, _x, _y + _h, _k, 0.25, _x - _d, _y + _h + _d, _k, 0.45);
    hvs__quad(_x + _w, _y, _c, 0.25, _x + _w + _d, _y - _d, _c, 0.5, _x + _w + _d, _y + _h + _d, _c, 0.5, _x + _w, _y + _h, _c, 0.25);
    hvs__quad(_x, _y + _h, _c, 0.25, _x + _w, _y + _h, _c, 0.25, _x + _w + _d, _y + _h + _d, _c, 0.6, _x - _d, _y + _h + _d, _c, 0.6);
}

// ------------------------------------------------------------------------------------------------ the bake and the cache

/// @function hvs__bake_begin(w, h, supersample)
/// @description Internal. Open a supersampled surface for painting, under identity (the caller's matrix is handed back at the end). Alpha blends as "over", so a translucent mark does not punch through.
function hvs__bake_begin(_w, _h, _ss) {
    var _b = { w: _w, h: _h, ss: _ss, m: matrix_get(matrix_world), s: surface_create(_w * _ss, _h * _ss), a: draw_get_alpha(), c: draw_get_colour() };
    draw_set_alpha(1); draw_set_colour(c_white);
    surface_set_target(_b.s);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false); gpu_set_cullmode(cull_noculling); gpu_set_alphatestenable(false);
    matrix_set(matrix_world, matrix_build(0, 0, 0, 0, 0, 0, _ss, _ss, 1));
    return _b;
}
/// @function hvs__bake_end(bake, xorigin, yorigin)
/// @description Internal. Close the surface, filter it down, make the sprite, free the surfaces, hand back the matrix. The result is premultiplied.
function hvs__bake_end(_b, _xo, _yo) {
    matrix_set(matrix_world, matrix_build_identity());
    gpu_pop_state();
    surface_reset_target();
    var _d = surface_create(_b.w, _b.h);
    surface_set_target(_d);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    gpu_set_tex_filter(true);
    gpu_set_blendmode_ext(bm_one, bm_zero);
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false); gpu_set_cullmode(cull_noculling); gpu_set_alphatestenable(false);
    draw_surface_stretched(_b.s, 0, 0, _b.w, _b.h);
    gpu_pop_state();
    surface_reset_target();
    var _spr = sprite_create_from_surface(_d, 0, 0, _b.w, _b.h, false, false, _xo, _yo);
    surface_free(_d);
    surface_free(_b.s);
    matrix_set(matrix_world, _b.m);
    draw_set_alpha(_b.a); draw_set_colour(_b.c);
    return _spr;
}
/// @function hvs__blur_sprite(sprite, w, h, xorigin, yorigin)
/// @description Internal. A soft black copy of a sprite's silhouette, for a cast shadow: it is drawn small and filtered back up, which costs one pass and looks like a blur.
function hvs__blur_sprite(_spr, _w, _h, _xo, _yo) {
    var _m = matrix_get(matrix_world), _pa = draw_get_alpha(), _pc = draw_get_colour();
    draw_set_alpha(1); draw_set_colour(c_white);
    matrix_set(matrix_world, matrix_build_identity());
    var _sw = max(4, _w div 4), _sh = max(4, _h div 4), _a = surface_create(_sw, _sh), _b = surface_create(_w, _h);
    surface_set_target(_a);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    gpu_set_tex_filter(true);
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    draw_sprite_ext(_spr, 0, _xo * _sw / _w, _yo * _sh / _h, _sw / _w, _sh / _h, 0, c_black, 1);
    gpu_pop_state();
    surface_reset_target();
    surface_set_target(_b);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    gpu_set_tex_filter(true);
    gpu_set_blendmode_ext(bm_one, bm_zero);
    draw_surface_stretched(_a, 0, 0, _w, _h);
    gpu_pop_state();
    surface_reset_target();
    var _s = sprite_create_from_surface(_b, 0, 0, _w, _h, false, false, _xo, _yo);
    surface_free(_a); surface_free(_b);
    matrix_set(matrix_world, _m);
    draw_set_alpha(_pa); draw_set_colour(_pc);
    return _s;
}
/// @function hvs__cache()
/// @description Internal. The shared table of baked sprites.
function hvs__cache() {
    if (!variable_global_exists("hvs__sprites")) global.hvs__sprites = {};
    return global.hvs__sprites;
}
/// @function hvs_art_free()
/// @description Delete every baked sprite. Call it when the inventory is finished with (room end, a game restart path): the next draw bakes again. Never call it between drawing and the end of a frame.
/// @returns {real} How many sprites were deleted.
function hvs_art_free() {
    var _c = hvs__cache(), _ks = variable_struct_get_names(_c), _n = 0;
    for (var _i = 0; _i < array_length(_ks); _i++) {
        var _e = _c[$ _ks[_i]];
        if (is_struct(_e)) {
            var _sk = variable_struct_get_names(_e);
            for (var _j = 0; _j < array_length(_sk); _j++) {
                var _v = _e[$ _sk[_j]];
                if (string_pos("spr", _sk[_j]) == 1 && sprite_exists(_v)) { sprite_delete(_v); _n++; }
            }
        }
    }
    global.hvs__sprites = {};
    return _n;
}
/// @function hvs_art_count()
/// @description How many entries the art cache holds.
function hvs_art_count() { return array_length(variable_struct_get_names(hvs__cache())); }
