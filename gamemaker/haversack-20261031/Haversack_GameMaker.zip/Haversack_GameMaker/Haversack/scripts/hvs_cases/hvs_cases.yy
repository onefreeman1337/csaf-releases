{
  "$GMScript": "v1",
  "%Name": "hvs_cases",
  "name": "hvs_cases",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}