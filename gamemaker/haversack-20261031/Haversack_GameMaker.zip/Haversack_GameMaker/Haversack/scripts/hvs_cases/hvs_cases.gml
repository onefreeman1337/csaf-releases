/// hvs_cases.gml - the containers Haversack draws: 8 kinds x 6 materials. The kind decides the silhouette, the hardware and how the grid is made (cut foam, stitched canvas, felt and laths,
/// suede, straw and chalk, hex mesh, tufted velvet, sewn pockets); the material decides the shell's colour and grain, the metal, the lining's tint and how it wears. The grid IS the lining: no flat rectangle, and no cell lines drawn on top of a background.
/// Every container is drawn once to a sprite (with the seed and wear you give it) and kept.
///
/// Haversack - A Spatial Inventory That Draws Its Own Containers. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function hvs_case_kinds()
/// @description The container kinds: "attache", "rucksack", "footlocker", "saddlebag", "crate", "locker", "chest", "toolroll".
function hvs_case_kinds() { return ["attache", "rucksack", "footlocker", "saddlebag", "crate", "locker", "chest", "toolroll"]; }
/// @function hvs_case_materials()
/// @description The materials: "hide", "canvas", "oak", "steel", "polymer", "lacquer".
function hvs_case_materials() { return ["hide", "canvas", "oak", "steel", "polymer", "lacquer"]; }
/// @function hvs_case_title(kind, material)
/// @description A plain name for a container: "Oak Footlocker".
function hvs_case_title(_k, _m) {
    var _kn = "Case";
    switch (_k) { case "attache": _kn = "Attache Case"; break; case "rucksack": _kn = "Rucksack"; break; case "footlocker": _kn = "Footlocker"; break; case "saddlebag": _kn = "Saddlebag"; break; case "crate": _kn = "Crate"; break; case "locker": _kn = "Locker"; break; case "chest": _kn = "Chest"; break; case "toolroll": _kn = "Tool Roll"; break; }
    var _mn = "";
    switch (_m) { case "hide": _mn = "Hide"; break; case "canvas": _mn = "Canvas"; break; case "oak": _mn = "Oak"; break; case "steel": _mn = "Steel"; break; case "polymer": _mn = "Polymer"; break; case "lacquer": _mn = "Lacquer"; break; }
    return _mn + " " + _kn;
}
/// @function hvs_case_mask(kind, w, h)
/// @description The cell mask a kind suits at a size, as rows to pass to hvs_container: a saddlebag's rounded bottom corners, a rucksack's shoulders. Undefined means every cell is open.
function hvs_case_mask(_k, _w, _h) {
    _w = clamp(floor(hvs__n(_w, 6)), 1, HVS_MAX_SIDE); _h = clamp(floor(hvs__n(_h, 4)), 1, HVS_MAX_SIDE);
    if (_w < 4 || _h < 3) return undefined;
    var _rows = [];
    for (var _y = 0; _y < _h; _y++) {
        var _r = "";
        for (var _x = 0; _x < _w; _x++) {
            var _open = true;
            var _ex = min(_x, _w - 1 - _x);
            if (_k == "saddlebag" && _y == _h - 1 && _ex == 0) _open = false;
            if (_k == "rucksack" && _y == 0 && _ex == 0) _open = false;
            _r += _open ? "X" : ".";
        }
        array_push(_rows, _r);
    }
    if (_k != "saddlebag" && _k != "rucksack") return undefined;
    return _rows;
}
/// @function hvs__mat_spec(material)
/// @description Internal. What a material is: shell ramp, metal, lining tint, grain and how it wears.
function hvs__mat_spec(_m) {
    switch (_m) {
        case "canvas": return { sh: hvs_ramp(0.46, 0.052, 118, 0.17), metal: "iron", liner: [0.34, 0.040, 110], grain: 1, scuff: make_colour_rgb(190, 186, 150), ink: make_colour_rgb(30, 32, 18) };
        case "oak": return { sh: hvs_ramp(0.50, 0.075, 62, 0.20), metal: "iron", liner: [0.40, 0.075, 150], grain: 2, scuff: make_colour_rgb(214, 182, 134), ink: make_colour_rgb(36, 22, 12) };
        case "steel": return { sh: hvs_ramp(0.50, 0.012, 245, 0.25), metal: "silver", liner: [0.30, 0.030, 250], grain: 3, scuff: make_colour_rgb(226, 230, 236), ink: make_colour_rgb(20, 22, 26) };
        case "polymer": return { sh: hvs_ramp(0.28, 0.006, 250, 0.13), metal: "orange", liner: [0.33, 0.016, 235], grain: 4, scuff: make_colour_rgb(150, 152, 156), ink: make_colour_rgb(10, 10, 12) };
        case "lacquer": return { sh: hvs_ramp(0.36, 0.125, 18, 0.20), metal: "gold", liner: [0.32, 0.105, 318], grain: 5, scuff: make_colour_rgb(226, 170, 132), ink: make_colour_rgb(26, 8, 10) };
        default: return { sh: hvs_ramp(0.50, 0.095, 58, 0.20), metal: "brass", liner: [0.36, 0.085, 28], grain: 0, scuff: make_colour_rgb(222, 186, 138), ink: make_colour_rgb(32, 18, 10) };
    }
}
/// @function hvs__u(cell)
/// @description Internal. The hardware's scale. A rivet on a bigger case is not a bigger rivet: bounded at both ends.
function hvs__u(_cell) { return clamp(_cell / 40, 0.62, 1.5); }
/// @function hvs__cell_cap(w, h, cell)
/// @description Internal. A cell size that keeps the art at or under 2048 pixels a side, however large a container asks.
function hvs__cell_cap(_w, _h, _cell) { return clamp(floor(min(hvs__n(_cell, 40), 2048 / max(1, _w, _h))), 8, 128); }
/// @function hvs_case_metrics(kind, w, rows, cell)
/// @description How much drawn case surrounds the grid, in pixels: {ml, mt, mr, mb, w, h} (margins, then the whole drawn size). hvs_desk_add uses this; use it to lay out a screen.
function hvs_case_metrics(_k, _w, _rows, _cell) {
    _w = max(1, hvs__n(_w, 1)); _rows = max(1, hvs__n(_rows, 1)); _cell = clamp(hvs__n(_cell, 40), 8, 128);
    var _u = hvs__u(_cell), _l = 26, _t = 40, _r = 26, _b = 26;
    switch (_k) {
        case "attache": _l = 26; _t = 44; _r = 26; _b = 26; break;
        case "rucksack": _l = 40; _t = 74; _r = 40; _b = 30; break;
        case "footlocker": _l = 30; _t = 46; _r = 30; _b = 30; break;
        case "saddlebag": _l = 26; _t = 56; _r = 26; _b = 40; break;
        case "crate": _l = 32; _t = 34; _r = 32; _b = 32; break;
        case "locker": _l = 34; _t = 50; _r = 34; _b = 38; break;
        case "chest": _l = 38; _t = 60; _r = 38; _b = 32; break;
        case "toolroll": _l = 52; _t = 24; _r = 34; _b = 24; break;
    }
    var _ml = round(_l * _u), _mt = round(_t * _u), _mr = round(_r * _u), _mb = round(_b * _u);
    return { ml: _ml, mt: _mt, mr: _mr, mb: _mb, w: _ml + _mr + _w * _cell, h: _mt + _mb + _rows * _cell };
}

// ------------------------------------------------------------------------------------------------ hardware

/// @function hvs__rivet(x, y, r, metal)
/// @description Internal. A domed rivet with its shadow.
function hvs__rivet(_x, _y, _r, _m) {
    hvs__disc(_x + _r * 0.25, _y + _r * 0.35, _r * 1.1, c_black, 0.35, 10);
    hvs__mass(hvs__ell(_x, _y, _r, _r, 10), _m, _r * 0.55);
}
/// @function hvs__stitch(x0, y0, x1, y1, pitch, col)
/// @description Internal. A sewn line: short dashes, each with a small shadow under it.
function hvs__stitch(_x0, _y0, _x1, _y1, _p, _c) {
    var _l = point_distance(_x0, _y0, _x1, _y1), _n = max(1, floor(_l / _p)), _dx = (_x1 - _x0) / _n, _dy = (_y1 - _y0) / _n;
    for (var _i = 0; _i < _n; _i++) {
        var _ax = _x0 + _dx * _i, _ay = _y0 + _dy * _i, _bx = _ax + _dx * 0.62, _by = _ay + _dy * 0.62;
        hvs__seg(_ax + 0.5, _ay + 0.7, _bx + 0.5, _by + 0.7, 1.3, c_black, 0.3);
        hvs__seg(_ax, _ay, _bx, _by, 1.1, _c, 0.92);
    }
}
/// @function hvs__stitch_box(x, y, w, h, pitch, col)
/// @description Internal. A sewn rectangle.
function hvs__stitch_box(_x, _y, _w, _h, _p, _c) {
    hvs__stitch(_x, _y, _x + _w, _y, _p, _c); hvs__stitch(_x + _w, _y, _x + _w, _y + _h, _p, _c);
    hvs__stitch(_x + _w, _y + _h, _x, _y + _h, _p, _c); hvs__stitch(_x, _y + _h, _x, _y, _p, _c);
}
/// @function hvs__buckle(x, y0, y1, u, metal, strap)
/// @description Internal. A strap running down through a buckle, centred on x.
function hvs__buckle(_x, _y0, _y1, _u, _mt, _strap) {
    var _sw = 11 * _u;
    hvs__rect(_x - _sw * 0.5 + 1.5, _y0 + 1.5, _sw, _y1 - _y0, c_black, 0.28);
    hvs__mass(hvs__rr(_x - _sw * 0.5, _y0, _sw, _y1 - _y0, 1.6 * _u, 2), _strap, 2.0 * _u);
    var _by = lerp(_y0, _y1, 0.62), _bw = 16 * _u, _bh = 13 * _u;
    hvs__mass(hvs__rr(_x - _bw * 0.5, _by - _bh * 0.5, _bw, _bh, 2.2 * _u, 2), _mt, 1.6 * _u);
    hvs__mass(hvs__rr(_x - _bw * 0.5 + 2.8 * _u, _by - _bh * 0.5 + 2.8 * _u, _bw - 5.6 * _u, _bh - 5.6 * _u, 1 * _u, 2), _strap, 1 * _u);
    hvs__seg(_x, _by - _bh * 0.5, _x, _by + _bh * 0.5, 1.6 * _u, _mt[3], 1);
    for (var _i = 1; _i <= 2; _i++) hvs__disc(_x, _by - (_bh * 0.7 + _i * 5 * _u), 1 * _u, c_black, 0.6, 6);
}
/// @function hvs__handle(cx, y, w, h, u, ramp, metal)
/// @description Internal. A carrying handle standing on a top edge, with two lugs.
function hvs__handle(_cx, _y, _w, _h, _u, _ramp, _mt) {
    var _x0 = _cx - _w * 0.5;
    hvs__mass(hvs__rr4(_x0, _y - _h, _w, _h, _h * 0.55, _h * 0.55, 1, 1, 4), _ramp, 2.4 * _u);
    hvs__mass(hvs__rr(_x0 - 5 * _u, _y - 6 * _u, 9 * _u, 9 * _u, 1.6 * _u, 2), _mt, 1.6 * _u);
    hvs__mass(hvs__rr(_x0 + _w - 4 * _u, _y - 6 * _u, 9 * _u, 9 * _u, 1.6 * _u, 2), _mt, 1.6 * _u);
}
/// @function hvs__latch(x, y, u, metal)
/// @description Internal. A drawbolt latch centred on x, straddling a seam at y.
function hvs__latch(_x, _y, _u, _mt) {
    var _w = 22 * _u, _h = 18 * _u;
    hvs__rect(_x - _w * 0.5 + 1.5, _y - _h * 0.5 + 2, _w, _h, c_black, 0.32);
    hvs__mass(hvs__rr(_x - _w * 0.5, _y - _h * 0.5, _w, _h, 2.4 * _u, 2), _mt, 2.2 * _u);
    hvs__mass(hvs__rr(_x - 5.5 * _u, _y - 6 * _u, 11 * _u, 12 * _u, 1.6 * _u, 2), _mt, 1.8 * _u);
    hvs__seg(_x - 3 * _u, _y, _x + 3 * _u, _y, 1.2 * _u, c_black, 0.65);
    hvs__rivet(_x - _w * 0.5 + 3.2 * _u, _y, 1.1 * _u, _mt); hvs__rivet(_x + _w * 0.5 - 3.2 * _u, _y, 1.1 * _u, _mt);
}
/// @function hvs__corner(x, y, sx, sy, s, u, metal)
/// @description Internal. An L-shaped corner guard, its point at x, y, running in directions sx and sy.
function hvs__corner(_x, _y, _sx, _sy, _s, _u, _mt) {
    var _t = 8 * _u;
    var _ax = min(_x, _x + _sx * _s), _ay = min(_y, _y + _sy * _t), _bx = min(_x, _x + _sx * _t), _by = min(_y, _y + _sy * _s);
    hvs__rect(_ax + 1.5, _ay + 2, _s, _t, c_black, 0.28); hvs__rect(_bx + 1.5, _by + 2, _t, _s, c_black, 0.28);
    hvs__mass(hvs__rr(_ax, _ay, _s, _t, 1.4 * _u, 2), _mt, 1.8 * _u);
    hvs__mass(hvs__rr(_bx, _by, _t, _s, 1.4 * _u, 2), _mt, 1.8 * _u);
    hvs__rivet(_x + _sx * (_s - _t * 0.6), _y + _sy * _t * 0.5, 1.3 * _u, _mt); hvs__rivet(_x + _sx * _t * 0.5, _y + _sy * (_s - _t * 0.6), 1.3 * _u, _mt);
    hvs__rivet(_x + _sx * _t * 0.55, _y + _sy * _t * 0.55, 1.3 * _u, _mt);
}

// ------------------------------------------------------------------------------------------------ the shell's surface

/// @function hvs__grain(spec, x, y, w, h, gen, u)
/// @description Internal. A shell's surface, in rectangle x, y, w, h: pebbled hide, woven canvas, oak planks, brushed steel, moulded polymer, glossy lacquer. Marks stay inside the rectangle. A material's grain is a physical size: it does not get coarser on a bigger case.
function hvs__grain(_s, _x, _y, _w, _h, _g, _u) {
    var _r = _s.sh;
    switch (_s.grain) {
        case 0: // pebbled hide: thousands of little worn creases would be a mess; a sparse mottle reads as grain at game size
            var _n = floor(_w * _h / (42 * _u * _u));
            for (var _i = 0; _i < _n; _i++) {
                var _px = _x + hvs_rand(_g) * _w, _py = _y + hvs_rand(_g) * _h, _l = (1.5 + hvs_rand(_g) * 2.6) * _u, _a = hvs_rand(_g) * 2 * pi, _q = hvs_rand(_g);
                var _ca = cos(_a) * _l, _sa = sin(_a) * _l;
                hvs__seg(clamp(_px - _ca, _x, _x + _w), clamp(_py - _sa, _y, _y + _h), clamp(_px + _ca, _x, _x + _w), clamp(_py + _sa, _y, _y + _h), 1.0 * _u, _q < 0.55 ? _r[0] : _r[4], _q < 0.55 ? 0.16 : 0.10);
            }
            break;
        case 1: // woven canvas: warp and weft
            var _p = 3.1 * _u;
            for (var _v = _y + _p * 0.5; _v < _y + _h; _v += _p) hvs__seg(_x, _v, _x + _w, _v, 1.0, (floor(_v / _p) mod 2 == 0) ? _r[0] : _r[4], 0.11);
            for (var _v = _x + _p * 0.5; _v < _x + _w; _v += _p) hvs__seg(_v, _y, _v, _y + _h, 1.0, (floor(_v / _p) mod 2 == 0) ? _r[0] : _r[4], 0.09);
            // a few slubs, or it reads as a screen
            var _n = floor(_w * _h / (900 * _u * _u));
            for (var _i = 0; _i < _n; _i++) { var _px = _x + hvs_rand(_g) * (_w - 16 * _u), _py = _y + hvs_rand(_g) * _h; hvs__seg(_px, _py, _px + (6 + hvs_rand(_g) * 10) * _u, _py, 1.2, _r[0], 0.22); }
            break;
        case 2: // oak: planks, each with its own run of grain
            var _ph = 26 * _u, _yy = _y, _idx = 0;
            while (_yy < _y + _h) {
                var _hh = min(_ph, _y + _h - _yy);
                var _tint = hvs_rand(_g) * 0.18 - 0.09;
                hvs__rect(_x, _yy, _w, _hh, _tint < 0 ? c_black : c_white, abs(_tint) * 0.55);
                var _lines = floor(_hh / (2.4 * _u));
                for (var _l = 0; _l < _lines; _l++) {
                    var _ly = _yy + (_l + 0.5) * _hh / _lines, _ph0 = hvs_rand(_g) * 6.28, _amp = (0.5 + hvs_rand(_g) * 1.2) * _u, _alpha = 0.08 + hvs_rand(_g) * 0.16, _col = hvs_rand(_g) < 0.7 ? _r[0] : _r[4];
                    var _step = 18 * _u, _px = _x;
                    while (_px < _x + _w) {
                        var _nx = min(_px + _step, _x + _w);
                        hvs__seg(_px, clamp(_ly + sin(_ph0 + _px * 0.03 / _u) * _amp, _yy, _yy + _hh), _nx, clamp(_ly + sin(_ph0 + _nx * 0.03 / _u) * _amp, _yy, _yy + _hh), 1.0, _col, _alpha);
                        _px = _nx;
                    }
                }
                if (_yy > _y) { hvs__seg(_x, _yy, _x + _w, _yy, 1.6 * _u, c_black, 0.5); hvs__seg(_x, _yy + 1.4 * _u, _x + _w, _yy + 1.4 * _u, 0.9 * _u, _r[4], 0.25); }
                _yy += _ph; _idx++;
            }
            break;
        case 3: // brushed steel: long fine streaks along the length
            var _n = floor(_h / (1.5 * _u));
            for (var _i = 0; _i < _n; _i++) {
                var _ly = _y + hvs_rand(_g) * _h, _x0 = _x + hvs_rand(_g) * _w * 0.5, _ll = (0.3 + hvs_rand(_g) * 0.7) * _w;
                hvs__seg(_x0, _ly, min(_x0 + _ll, _x + _w), _ly, 1.0, hvs_rand(_g) < 0.5 ? _r[0] : _r[4], 0.05 + hvs_rand(_g) * 0.10);
            }
            break;
        case 4: // moulded polymer: a fine pebble texture and moulded ribs
            var _n = floor(_w * _h / (20 * _u * _u));
            for (var _i = 0; _i < _n; _i++) { var _px = _x + hvs_rand(_g) * _w, _py = _y + hvs_rand(_g) * _h; hvs__rect(_px, _py, min(1.3 * _u, _x + _w - _px), min(1.3 * _u, _y + _h - _py), hvs_rand(_g) < 0.5 ? _r[4] : c_black, 0.09); }
            break;
        case 5: // lacquer: depth and a long diagonal gloss
            var _gw = _w * 0.24, _gx = _x + _w * 0.18;
            hvs__quad(_gx, _y, _r[4], 0, _gx + _gw * 0.5, _y, _r[4], 0.20, min(_gx + _gw * 0.5 + _h * 0.3, _x + _w), _y + _h, _r[4], 0.03, min(_gx + _h * 0.3, _x + _w), _y + _h, _r[4], 0);
            hvs__quad(_gx + _gw * 0.5, _y, _r[4], 0.20, _gx + _gw, _y, _r[4], 0, min(_gx + _gw + _h * 0.3, _x + _w), _y + _h, _r[4], 0, min(_gx + _gw * 0.5 + _h * 0.3, _x + _w), _y + _h, _r[4], 0.03);
            break;
    }
}
/// @function hvs__wear(spec, x, y, w, h, wear, gen, u)
/// @description Internal. Handling: rubbed edges and scuffs along the rims where hands and floors reach, a few scratches across the field. What it looks like is the material's: pale rub on hide and canvas, chipped oak, bright scratches on steel, stress marks on polymer, crazing on lacquer.
function hvs__wear(_s, _x, _y, _w, _h, _wear, _g, _u) {
    if (_wear <= 0.001) return;
    var _c = _s.scuff, _per = 2 * (_w + _h);
    // the rims
    var _n = floor(_per / (9 * _u) * _wear);
    for (var _i = 0; _i < _n; _i++) {
        var _t = hvs_rand(_g) * _per, _l = (3 + hvs_rand(_g) * 13) * _u, _d = hvs_rand(_g) * 3 * _u, _a = (0.10 + hvs_rand(_g) * 0.26) * (0.5 + _wear * 0.5);
        if (_t < _w) hvs__seg(_x + _t, _y + _d, min(_x + _t + _l, _x + _w), _y + _d, 1.2 * _u, _c, _a);
        else if (_t < _w + _h) hvs__seg(_x + _w - _d, _y + _t - _w, _x + _w - _d, min(_y + _t - _w + _l, _y + _h), 1.2 * _u, _c, _a);
        else if (_t < 2 * _w + _h) hvs__seg(_x + _t - _w - _h, _y + _h - _d, min(_x + _t - _w - _h + _l, _x + _w), _y + _h - _d, 1.2 * _u, _c, _a);
        else hvs__seg(_x + _d, _y + _t - 2 * _w - _h, _x + _d, min(_y + _t - 2 * _w - _h + _l, _y + _h), 1.2 * _u, _c, _a);
    }
    // the field
    var _f = floor(_w * _h / (4200 * _u * _u) * _wear) + 1;
    for (var _i = 0; _i < _f; _i++) {
        var _px = _x + hvs_rand(_g) * _w, _py = _y + hvs_rand(_g) * _h, _a = hvs_rand(_g) * 6.28, _l = (5 + hvs_rand(_g) * 22) * _u;
        var _qx = clamp(_px + cos(_a) * _l, _x, _x + _w), _qy = clamp(_py + sin(_a) * _l, _y, _y + _h);
        hvs__seg(_px, _py, _qx, _qy, 1.0, _c, 0.14 + hvs_rand(_g) * 0.18);
        if (_s.grain == 2 || _s.grain == 5) hvs__seg(_px + 0.8, _py + 0.8, _qx + 0.8, _qy + 0.8, 1.0, c_black, 0.18);
    }
}

// ------------------------------------------------------------------------------------------------ the shells

/// @function hvs__case_shell(kind, material, W, H, m, gw, gh, cell, seed, wear)
/// @description Internal. Paint a whole case around its window. The window itself is left for the lining.
function hvs__case_shell(_k, _mat, _W, _H, _m, _gw, _gh, _cell, _seed, _wear) {
    var _s = hvs__mat_spec(_mat), _u = hvs__u(_cell), _g = hvs_rng(_seed * 131 + 7);
    var _mt = hvs__mat(_s.metal), _sh = _s.sh, _gx = _m.ml, _gy = _m.mt, _ink = _s.ink;
    var _thread = hvs_oklch(0.82, 0.05, 85), _pad = 8 * _u;
    switch (_k) {
        case "attache":
            var _bx = _pad, _by = _pad + 22 * _u, _bw = _W - _pad * 2, _bh = _H - _by - _pad;
            hvs__handle(_W * 0.5, _by + 2 * _u, 96 * _u, 14 * _u, _u, _sh, _mt);
            hvs__body(_s, _bx, _by, _bw, _bh, 7 * _u, _g, _u, _wear, _ink);
            // the shell's seam and the hinged lid rim
            hvs__seg(_bx + 3 * _u, _gy - 9 * _u, _bx + _bw - 3 * _u, _gy - 9 * _u, 1.6 * _u, c_black, 0.45);
            hvs__seg(_bx + 3 * _u, _gy - 7.6 * _u, _bx + _bw - 3 * _u, _gy - 7.6 * _u, 1 * _u, _sh[4], 0.35);
            hvs__latch(_W * 0.27, _gy - 9 * _u, _u, _mt); hvs__latch(_W * 0.73, _gy - 9 * _u, _u, _mt);
            hvs__corner(_bx, _by, 1, 1, 24 * _u, _u, _mt); hvs__corner(_bx + _bw, _by, -1, 1, 24 * _u, _u, _mt);
            hvs__corner(_bx, _by + _bh, 1, -1, 24 * _u, _u, _mt); hvs__corner(_bx + _bw, _by + _bh, -1, -1, 24 * _u, _u, _mt);
            break;
        case "rucksack":
            var _bx = _pad + 14 * _u, _by = _pad + 34 * _u, _bw = _W - (_pad + 14 * _u) * 2, _bh = _H - _by - _pad;
            // side pockets
            hvs__mass(hvs__rr4(_pad, _by + _bh * 0.42, 26 * _u, _bh * 0.50, 6 * _u, 2 * _u, 2 * _u, 10 * _u, 3), _sh, 3 * _u);
            hvs__mass(hvs__rr4(_W - _pad - 26 * _u, _by + _bh * 0.42, 26 * _u, _bh * 0.50, 2 * _u, 6 * _u, 10 * _u, 2 * _u, 3), _sh, 3 * _u);
            hvs__handle(_W * 0.5, _pad + 12 * _u, 42 * _u, 10 * _u, _u, hvs__mat("leather"), _mt);
            hvs__body(_s, _bx, _by, _bw, _bh, 22 * _u, _g, _u, _wear, _ink, 34 * _u, 34 * _u, 12 * _u, 12 * _u);
            hvs__stitch(_bx + 8 * _u, _by + _bh - 7 * _u, _bx + _bw - 8 * _u, _by + _bh - 7 * _u, 7 * _u, _thread);
            // the flap
            var _fw = _bw * 0.86, _fx = _W * 0.5 - _fw * 0.5, _fy = _pad + 12 * _u, _fh = _gy - _fy - 8 * _u;
            hvs__rect(_fx + 2, _fy + _fh, _fw, 4 * _u, c_black, 0.3);
            hvs__body(_s, _fx, _fy, _fw, _fh, 16 * _u, _g, _u, _wear * 0.8, _ink, 18 * _u, 18 * _u, 7 * _u, 7 * _u);
            hvs__stitch(_fx + 7 * _u, _fy + _fh - 5 * _u, _fx + _fw - 7 * _u, _fy + _fh - 5 * _u, 7 * _u, _thread);
            hvs__buckle(_W * 0.30, _fy + _fh * 0.25, _gy + 3 * _u, _u, _mt, hvs__mat("leather"));
            hvs__buckle(_W * 0.70, _fy + _fh * 0.25, _gy + 3 * _u, _u, _mt, hvs__mat("leather"));
            break;
        case "footlocker":
            var _bx = _pad, _by = _pad + 12 * _u, _bw = _W - _pad * 2, _bh = _H - _by - _pad;
            hvs__body(_s, _bx, _by, _bw, _bh, 3 * _u, _g, _u, _wear, _ink);
            // the top band and a hasp with a padlock
            hvs__mass(hvs__rr(_bx, _gy - 18 * _u, _bw, 11 * _u, 1 * _u, 2), _mt, 2 * _u);
            for (var _i = 0; _i < 7; _i++) hvs__rivet(_bx + (_i + 0.5) / 7 * _bw, _gy - 12.5 * _u, 1.5 * _u, _mt);
            hvs__mass(hvs__rr(_W * 0.5 - 9 * _u, _gy - 34 * _u, 18 * _u, 24 * _u, 2 * _u, 2), _mt, 2 * _u);
            hvs__mass(hvs__ell(_W * 0.5, _gy - 14 * _u, 8 * _u, 8 * _u, 12), hvs__mat("brass"), 2.4 * _u);
            hvs__disc(_W * 0.5, _gy - 15 * _u, 1.5 * _u, c_black, 0.8, 8); hvs__seg(_W * 0.5, _gy - 15 * _u, _W * 0.5, _gy - 10.5 * _u, 1.2 * _u, c_black, 0.8);
            hvs__corner(_bx, _by, 1, 1, 26 * _u, _u, _mt); hvs__corner(_bx + _bw, _by, -1, 1, 26 * _u, _u, _mt);
            hvs__corner(_bx, _by + _bh, 1, -1, 26 * _u, _u, _mt); hvs__corner(_bx + _bw, _by + _bh, -1, -1, 26 * _u, _u, _mt);
            // side grips
            hvs__mass(hvs__rr(_bx - 3 * _u, _by + _bh * 0.5 - 16 * _u, 6 * _u, 32 * _u, 2 * _u, 2), _mt, 1.6 * _u);
            hvs__mass(hvs__rr(_bx + _bw - 3 * _u, _by + _bh * 0.5 - 16 * _u, 6 * _u, 32 * _u, 2 * _u, 2), _mt, 1.6 * _u);
            break;
        case "saddlebag":
            var _bx = _pad, _by = _pad + 14 * _u, _bw = _W - _pad * 2, _bh = _H - _by - _pad;
            hvs__body(_s, _bx, _by, _bw, _bh, 10 * _u, _g, _u, _wear, _ink, 10 * _u, 10 * _u, 44 * _u, 44 * _u);
            hvs__stitch(_bx + 6 * _u, _by + 8 * _u, _bx + 6 * _u, _by + _bh - 40 * _u, 7 * _u, _thread);
            hvs__stitch(_bx + _bw - 6 * _u, _by + 8 * _u, _bx + _bw - 6 * _u, _by + _bh - 40 * _u, 7 * _u, _thread);
            // the flap, cut in a shallow scallop
            var _fh = _gy - _by - 6 * _u;
            hvs__rect(_bx + 6 * _u, _by + _fh, _bw - 12 * _u, 4 * _u, c_black, 0.3);
            hvs__body(_s, _bx - 1 * _u, _by - 1 * _u, _bw + 2 * _u, _fh, 10 * _u, _g, _u, _wear * 0.7, _ink, 10 * _u, 10 * _u, 4 * _u, 4 * _u);
            hvs__stitch(_bx + 8 * _u, _by + _fh - 6 * _u, _bx + _bw - 8 * _u, _by + _fh - 6 * _u, 7 * _u, _thread);
            hvs__buckle(_W * 0.5, _by + _fh * 0.15, _gy + 6 * _u, _u, _mt, hvs__mat("leather"));
            break;
        case "crate":
            var _bx = _pad, _by = _pad, _bw = _W - _pad * 2, _bh = _H - _pad * 2;
            hvs__body(_s, _bx, _by, _bw, _bh, 2 * _u, _g, _u, _wear, _ink);
            // battens, nailed on
            var _bt = 20 * _u;
            hvs__mass(hvs__rr(_bx, _by, _bw, _bt, 1 * _u, 2), hvs__shade_mix(_sh, 0.08), 2.2 * _u); hvs__mass(hvs__rr(_bx, _by + _bh - _bt, _bw, _bt, 1 * _u, 2), hvs__shade_mix(_sh, 0.08), 2.2 * _u);
            hvs__mass(hvs__rr(_bx, _by, _bt, _bh, 1 * _u, 2), hvs__shade_mix(_sh, 0.04), 2.2 * _u); hvs__mass(hvs__rr(_bx + _bw - _bt, _by, _bt, _bh, 1 * _u, 2), hvs__shade_mix(_sh, 0.04), 2.2 * _u);
            hvs__grain(_s, _bx + 2 * _u, _by + 2 * _u, _bw - 4 * _u, _bt - 4 * _u, _g, _u); hvs__grain(_s, _bx + 2 * _u, _by + _bh - _bt + 2 * _u, _bw - 4 * _u, _bt - 4 * _u, _g, _u);
            var _cn = [[_bx + _bt * 0.5, _by + _bt * 0.5], [_bx + _bw - _bt * 0.5, _by + _bt * 0.5], [_bx + _bt * 0.5, _by + _bh - _bt * 0.5], [_bx + _bw - _bt * 0.5, _by + _bh - _bt * 0.5], [_W * 0.5, _by + _bt * 0.5], [_W * 0.5, _by + _bh - _bt * 0.5]];
            for (var _i = 0; _i < array_length(_cn); _i++) hvs__rivet(_cn[_i][0], _cn[_i][1], 1.9 * _u, _mt);
            break;
        case "locker":
            var _bx = _pad, _by = _pad, _bw = _W - _pad * 2, _bh = _H - _pad * 2, _ch = 14 * _u;
            // chamfered: a machine, not a piece of luggage
            var _pts = [_bx + _ch, _by, _bx + _bw - _ch, _by, _bx + _bw, _by + _ch, _bx + _bw, _by + _bh - _ch, _bx + _bw - _ch, _by + _bh, _bx + _ch, _by + _bh, _bx, _by + _bh - _ch, _bx, _by + _ch];
            hvs__mass(_pts, _sh, 4 * _u);
            hvs__grain(_s, _bx + 6 * _u, _by + 6 * _u, _bw - 12 * _u, _bh - 12 * _u, _g, _u);
            hvs__wear(_s, _bx + 4 * _u, _by + 4 * _u, _bw - 8 * _u, _bh - 8 * _u, _wear, _g, _u);
            // the status strip
            var _sy = _by + 12 * _u, _accent = hvs_oklch(0.80, 0.15, 180);
            hvs__mass(hvs__rr(_bx + 14 * _u, _sy, _bw - 28 * _u, 14 * _u, 2 * _u, 2), hvs__mat("rubber"), 1.2 * _u);
            for (var _i = 0; _i < 3; _i++) { var _lx = _bx + 24 * _u + _i * 12 * _u; hvs__spot(_lx, _sy + 7 * _u, 6 * _u, _i == 0 ? hvs_oklch(0.8, 0.17, 145) : _accent, 0.5, 10); hvs__disc(_lx, _sy + 7 * _u, 2 * _u, _i == 0 ? hvs_oklch(0.9, 0.12, 145) : _accent, 1, 8); }
            for (var _i = 0; _i < 8; _i++) hvs__rect(_bx + _bw - 26 * _u - _i * 6 * _u, _sy + 3 * _u, 3 * _u, 8 * _u, c_black, 0.55);
            // grilles along the foot
            for (var _i = 0; _i < 10; _i++) { var _vx = _W * 0.5 - 45 * _u + _i * 10 * _u; hvs__mass(hvs__rr(_vx, _H - _pad - 16 * _u, 6 * _u, 8 * _u, 1 * _u, 2), hvs__mat("rubber"), 1 * _u); }
            hvs__rivet(_bx + 7 * _u, _by + _bh * 0.5, 1.6 * _u, _mt); hvs__rivet(_bx + _bw - 7 * _u, _by + _bh * 0.5, 1.6 * _u, _mt);
            break;
        case "chest":
            var _bx = _pad, _by = _pad + 26 * _u, _bw = _W - _pad * 2, _bh = _H - _by - _pad;
            // the lid's curve above the rim
            var _lid = []; var _lidn = 14;
            for (var _i = 0; _i <= _lidn; _i++) { var _t = _i / _lidn, _a = pi + _t * pi; array_push(_lid, _bx + 2 * _u + (_bw - 4 * _u) * _t, _by + 8 * _u + sin(_a) * 24 * _u); }
            array_push(_lid, _bx + _bw - 2 * _u, _by + 16 * _u, _bx + 2 * _u, _by + 16 * _u);
            hvs__mass(_lid, _sh, 4 * _u);
            hvs__body(_s, _bx, _by + 10 * _u, _bw, _bh - 10 * _u, 4 * _u, _g, _u, _wear, _ink);
            // iron bands
            hvs__mass(hvs__rr(_bx, _gy - 16 * _u, _bw, 10 * _u, 1 * _u, 2), _mt, 2 * _u);
            var _bands = [0.14, 0.86];
            for (var _i = 0; _i < 2; _i++) {
                var _ix = _bx + _bw * _bands[_i];
                hvs__mass(hvs__rr(_ix - 6 * _u, _gy - 16 * _u, 12 * _u, _H - _pad - _gy + 16 * _u, 1 * _u, 2), _mt, 2 * _u);
                hvs__rivet(_ix, _gy - 11 * _u, 1.8 * _u, _mt);
                hvs__rivet(_ix, _H - _pad - 8 * _u, 1.8 * _u, _mt);
                var _ty = _pad + 2 * _u + abs(_bands[_i] - 0.5) * 22 * _u;
                hvs__mass(hvs__rr(_ix - 6 * _u, _ty + 2 * _u, 12 * _u, _gy - 16 * _u - _ty, 1 * _u, 2), _mt, 2 * _u);
            }
            // the lock plate
            hvs__mass(hvs__rr(_W * 0.5 - 13 * _u, _gy - 30 * _u, 26 * _u, 26 * _u, 3 * _u, 2), hvs__mat(_s.metal == "gold" ? "gold" : "brass"), 2.6 * _u);
            hvs__disc(_W * 0.5, _gy - 20 * _u, 3 * _u, c_black, 0.85, 10); hvs__seg(_W * 0.5, _gy - 20 * _u, _W * 0.5, _gy - 12 * _u, 2.4 * _u, c_black, 0.85);
            break;
        case "toolroll":
            var _bx = _pad + 24 * _u, _by = _pad, _bw = _W - _bx - _pad, _bh = _H - _pad * 2;
            // the rolled-up edge on the left, and its ties
            hvs__body(_s, _bx, _by, _bw, _bh, 4 * _u, _g, _u, _wear, _ink);
            hvs__stitch_box(_bx + 6 * _u, _by + 6 * _u, _bw - 12 * _u, _bh - 12 * _u, 7 * _u, _thread);
            hvs__mass(hvs__rr(_pad + 2 * _u, _by - 2 * _u, 28 * _u, _bh + 4 * _u, 11 * _u, 4), _sh, 7 * _u);
            hvs__grain(_s, _pad + 7 * _u, _by + 6 * _u, 18 * _u, _bh - 12 * _u, _g, _u);
            var _tie = hvs__mat("leather");
            for (var _i = 0; _i < 2; _i++) {
                var _ty = _by + _bh * (0.3 + _i * 0.4);
                hvs__mass(hvs__rr(_pad - 1 * _u, _ty - 4 * _u, 34 * _u, 8 * _u, 2 * _u, 2), _tie, 1.6 * _u);
                hvs__seg(_pad + 3 * _u, _ty + 5 * _u, _pad - 2 * _u, _ty + 18 * _u, 3 * _u, _tie[2], 1);
            }
            break;
    }
    // the sunk rim of the window
    hvs__recess(_gx, _gy, _gw, _gh, clamp(3 * _u, 2, 5), _sh[4]);
}
/// @function hvs__shade_mix(ramp, amount)
/// @description Internal. A ramp, lightened.
function hvs__shade_mix(_r, _a) {
    var _o = array_create(5, 0);
    for (var _i = 0; _i < 5; _i++) _o[_i] = merge_colour(_r[_i], c_white, _a);
    return _o;
}
/// @function hvs__body(spec, x, y, w, h, r, gen, u, wear, ink, r0, r1, r2, r3)
/// @description Internal. The shell's main mass: a silhouette, relief walls, the material's grain and its wear.
function hvs__body(_s, _x, _y, _w, _h, _r, _g, _u, _wear, _ink, _r0 = undefined, _r1 = undefined, _r2 = undefined, _r3 = undefined) {
    var _a = is_undefined(_r0) ? _r : _r0, _b = is_undefined(_r1) ? _r : _r1, _c = is_undefined(_r2) ? _r : _r2, _d = is_undefined(_r3) ? _r : _r3;
    var _pts = hvs__rr4(_x, _y, _w, _h, _a, _b, _c, _d, 4);
    hvs__mass(_pts, _s.sh, 4 * _u, _ink, 1.2 * _u);
    var _in = max(max(_a, _b), max(_c, _d)) * 0.34 + 4 * _u;
    hvs__grain(_s, _x + _in, _y + _in * 0.7, _w - _in * 2, _h - _in * 1.4, _g, _u);
    hvs__wear(_s, _x + 3 * _u, _y + 3 * _u, _w - 6 * _u, _h - 6 * _u, _wear, _g, _u);
    if (_s.grain == 5) { // a gilt pinstripe follows every lacquered panel
        var _gl = hvs_oklch(0.80, 0.13, 88), _pp = 5 * _u;
        var _ring = hvs__rr4(_x + _pp, _y + _pp, _w - _pp * 2, _h - _pp * 2, max(_a - _pp, 1), max(_b - _pp, 1), max(_c - _pp, 1), max(_d - _pp, 1), 5), _rn = array_length(_ring) div 2;
        for (var _q = 0; _q < _rn; _q++) { var _nq = (_q + 1) mod _rn; hvs__seg(_ring[_q * 2], _ring[_q * 2 + 1], _ring[_nq * 2], _ring[_nq * 2 + 1], 1, _gl, 0.75); }
    }
}
// ------------------------------------------------------------------------------------------------ the linings: the grid is the lining

/// @function hvs__lining(kind, material, c, cell, seed)
/// @description Internal. Paint a container's grid, cell by cell, in its kind's own construction.
function hvs__lining(_k, _mat, _c, _cell, _seed) {
    var _s = hvs__mat_spec(_mat), _g = hvs_rng(_seed * 37 + 11);
    var _L = _s.liner[0], _C = _s.liner[1], _hu = _s.liner[2], _u = hvs__u(_cell);
    var _r = hvs_ramp(_L, _C, _hu, 0.14), _W = _c.w * _cell, _H = _c.h * _cell;
    var _edge = make_colour_rgb(8, 7, 8);
    hvs__rect(0, 0, _W, _H, _r[1], 1);
    // a surface across the whole grid
    switch (_k) {
        case "attache": // cut foam: dimples
            break;
        case "rucksack": // waxed canvas
            var _pp = 3 * _u;
            for (var _v = 0; _v < _H; _v += _pp) hvs__seg(0, _v, _W, _v, 1, _r[0], 0.22);
            for (var _v = 0; _v < _W; _v += _pp) hvs__seg(_v, 0, _v, _H, 1, _r[3], 0.10);
            break;
        case "footlocker": case "saddlebag": // felt and suede: soft mottle
            var _n = floor(_W * _H / (34 * _u * _u));
            for (var _i = 0; _i < _n; _i++) { var _px = hvs_rand(_g) * _W, _py = hvs_rand(_g) * _H; hvs__spot(_px, _py, (2 + hvs_rand(_g) * 4) * _u, hvs_rand(_g) < 0.5 ? _r[0] : _r[3], 0.20, 6); }
            break;
        case "crate": // straw
            hvs__rect(0, 0, _W, _H, _r[0], 0.7);
            var _st0 = hvs_ramp(0.50, 0.070, 84, 0.13), _n = floor(_W * _H / (20 * _u * _u));
            for (var _i = 0; _i < _n; _i++) {
                var _px = hvs_rand(_g) * _W, _py = hvs_rand(_g) * _H, _a = hvs_rand(_g) * 6.28, _l = (5 + hvs_rand(_g) * 14) * _u;
                var _qx = clamp(_px + cos(_a) * _l, 0, _W), _qy = clamp(_py + sin(_a) * _l, 0, _H);
                hvs__seg(_px + 0.8, _py + 1.2, _qx + 0.8, _qy + 1.2, 1.2 * _u, c_black, 0.22);
                hvs__seg(_px, _py, _qx, _qy, 1.0 * _u, hvs__ramp_at(_st0, hvs_rand(_g)), 0.62);
            }
            break;
        case "locker": // nothing across the grid: each cell is its own mesh panel
            break;
        case "chest": // velvet: a nap that catches the light unevenly
            var _n = floor(_W * _H / (70 * _u * _u));
            for (var _i = 0; _i < _n; _i++) { var _px = hvs_rand(_g) * _W, _py = hvs_rand(_g) * _H; hvs__spot(_px, _py, (5 + hvs_rand(_g) * 8) * _u, _r[4], 0.09, 8); }
            break;
    }
    // the cells
    for (var _y = 0; _y < _c.h; _y++) for (var _x = 0; _x < _c.w; _x++) {
        var _cx = _x * _cell, _cy = _y * _cell;
        var _v = _c.grid[_y * _c.w + _x];
        if (!is_struct(_v) && _v == HVS_BLOCKED) { hvs__cell_solid(_k, _s, _cx, _cy, _cell, _u, _r); continue; }
        hvs__cell(_k, _cx, _cy, _cell, _u, _r, _g, _edge);
    }
    // the dividers stand proud of the lining
    var _mt = hvs__mat(_s.metal == "orange" ? "gun" : _s.metal), _dvr = _k == "crate" || _k == "footlocker" ? _s.sh : _mt;
    for (var _i = 0; _i < array_length(_c.dividers); _i++) {
        var _d = _c.dividers[_i], _t = max(4, _cell * 0.13);
        if (_d[0] == "v") {
            var _dx = _d[1] * _cell, _y0 = max(0, _d[2]) * _cell, _y1 = min(_d[3], _c.h) * _cell;
            hvs__rect(_dx - _t * 0.5 + 2, _y0, _t, _y1 - _y0, c_black, 0.45);
            hvs__mass(hvs__rr(_dx - _t * 0.5, _y0, _t, _y1 - _y0, 1, 2), _dvr, _t * 0.28);
        } else {
            var _dy = _d[1] * _cell, _x0 = max(0, _d[2]) * _cell, _x1 = min(_d[3], _c.w) * _cell;
            hvs__rect(_x0, _dy - _t * 0.5 + 2, _x1 - _x0, _t, c_black, 0.45);
            hvs__mass(hvs__rr(_x0, _dy - _t * 0.5, _x1 - _x0, _t, 1, 2), _dvr, _t * 0.28);
        }
    }
}
/// @function hvs__cell(kind, x, y, cell, u, ramp, gen, edge)
/// @description Internal. One open cell, in its kind's own construction.
function hvs__cell(_k, _x, _y, _c, _u, _r, _g, _e) {
    switch (_k) {
        case "attache": // a dimple cut in foam: the walls catch the lamp the wrong way round, because this is a hollow
            var _i = _c * 0.06, _w = _c - _i * 2, _xx = _x + _i, _yy = _y + _i;
            hvs__quad(_xx, _yy, _r[0], 1, _xx + _w, _yy, _r[0], 1, _xx + _w * 0.84, _yy + _w * 0.16, _r[1], 1, _xx + _w * 0.16, _yy + _w * 0.16, _r[1], 1);
            hvs__quad(_xx, _yy, _r[0], 1, _xx + _w * 0.16, _yy + _w * 0.16, _r[1], 1, _xx + _w * 0.16, _yy + _w * 0.84, _r[1], 1, _xx, _yy + _w, _r[0], 1);
            hvs__quad(_xx + _w, _yy, _r[3], 1, _xx + _w, _yy + _w, _r[4], 1, _xx + _w * 0.84, _yy + _w * 0.84, _r[2], 1, _xx + _w * 0.84, _yy + _w * 0.16, _r[2], 1);
            hvs__quad(_xx, _yy + _w, _r[3], 1, _xx + _w * 0.16, _yy + _w * 0.84, _r[2], 1, _xx + _w * 0.84, _yy + _w * 0.84, _r[2], 1, _xx + _w, _yy + _w, _r[4], 1);
            hvs__rect(_xx + _w * 0.16, _yy + _w * 0.16, _w * 0.68, _w * 0.68, _r[1], 1);
            break;
        case "rucksack": // a stitched grid in waxed canvas
            hvs__stitch(_x + 1, _y + _c - 0.5, _x + _c - 1, _y + _c - 0.5, 5 * _u, _r[4]);
            hvs__stitch(_x + _c - 0.5, _y + 1, _x + _c - 0.5, _y + _c - 1, 5 * _u, _r[4]);
            hvs__rect(_x, _y, _c, _c * 0.12, c_black, 0.08);
            break;
        case "footlocker": // felt laid in a tray of thin laths
            var _t = max(1.5, _c * 0.05);
            hvs__rect(_x, _y, _c, _t, hvs__ramp_at(_r, 0.95), 0.62); hvs__rect(_x, _y, _t, _c, hvs__ramp_at(_r, 0.95), 0.62);
            hvs__rect(_x + _t, _y + _t, _c - _t, 1.2, c_black, 0.35); hvs__rect(_x + _t, _y + _t, 1.2, _c - _t, c_black, 0.35);
            break;
        case "saddlebag": // suede pressed into squares
            var _i = _c * 0.05;
            var _pts = hvs__rr(_x + _i, _y + _i, _c - _i * 2, _c - _i * 2, _c * 0.12, 3), _n = array_length(_pts) div 2;
            for (var _q = 0; _q < _n; _q++) { var _j = (_q + 1) mod _n; hvs__seg(_pts[_q * 2], _pts[_q * 2 + 1], _pts[_j * 2], _pts[_j * 2 + 1], 1.6 * _u, (_pts[_q * 2] + _pts[_q * 2 + 1]) < (_x + _y + _c) ? c_black : _r[4], 0.50); }
            break;
        case "crate": // chalked corner ticks on the straw
            // a stencilled square on the crate's floor, under the straw: dark and light in turn, with a chalked corner
            var _chalk = make_colour_rgb(238, 232, 210), _t = _c * 0.24;
            if (((round(_x / _c) + round(_y / _c)) mod 2) == 0) hvs__rect(_x, _y, _c, _c, c_black, 0.20);
            hvs__seg(_x + 1, _y + 1, _x + _t, _y + 1, 1.5 * _u, _chalk, 0.9); hvs__seg(_x + 1, _y + 1, _x + 1, _y + _t, 1.5 * _u, _chalk, 0.9);
            break;
        case "locker": // a mesh panel with a lit corner
            var _i = _c * 0.05, _w = _c - _i * 2;
            hvs__rect(_x + _i, _y + _i, _w, _w, _r[1], 1);
            var _pp = max(3, 6 * _u), _rr = _pp * 0.32;
            for (var _hy = 0; _hy < _w - _pp * 0.5; _hy += _pp * 0.86) for (var _hx = ((floor(_hy / (_pp * 0.86)) mod 2) * 0.5) * _pp; _hx < _w - _pp * 0.3; _hx += _pp) hvs__disc(_x + _i + _hx + _pp * 0.35, _y + _i + _hy + _pp * 0.4, _rr, c_black, 0.55, 6);
            hvs__seg(_x + _i, _y + _i + _w, _x + _i + _w, _y + _i + _w, 1, _r[4], 0.5); hvs__seg(_x + _i + _w, _y + _i, _x + _i + _w, _y + _i + _w, 1, _r[4], 0.5);
            var _tk = hvs_oklch(0.78, 0.13, 180);
            hvs__seg(_x + _i, _y + _i, _x + _i + _c * 0.14, _y + _i, 1.2 * _u, _tk, 0.8); hvs__seg(_x + _i, _y + _i, _x + _i, _y + _i + _c * 0.14, 1.2 * _u, _tk, 0.8);
            break;
        case "chest": // tufted velvet: folds running to a button at each corner
            var _b = _r[4], _d = _r[0], _m = _c * 0.5;
            hvs__quad(_x, _y, _d, 0.5, _x + _c, _y, _d, 0.05, _x + _m, _y + _m, _b, 0.16, _x, _y + _c, _d, 0.05);
            hvs__quad(_x + _c, _y + _c, _b, 0.22, _x, _y + _c, _d, 0.05, _x + _m, _y + _m, _b, 0.16, _x + _c, _y, _d, 0.05);
            var _br = max(1.4, _c * 0.055);
            hvs__mass(hvs__ell(_x, _y, _br, _br, 8), hvs__mat("gold"), _br * 0.5);
            break;
        case "toolroll": // a sewn pocket: an opening at the top, its shadow falling in
            var _i = _c * 0.04;
            hvs__mass(hvs__rr(_x + _i, _y + _c * 0.20, _c - _i * 2, _c * 0.80 - _i, _c * 0.06, 2), _r, _c * 0.03);
            hvs__rect(_x + _i, _y + _i, _c - _i * 2, _c * 0.18, c_black, 0.5);
            hvs__stitch(_x + _i + 1, _y + _c * 0.92, _x + _c - _i - 1, _y + _c * 0.92, 4.5 * _u, _r[4]);
            break;
    }
}
/// @function hvs__cell_solid(kind, spec, x, y, cell, u, ramp)
/// @description Internal. A masked-off cell: a padded block, raised, so it reads as a shape of the container and not as a missing square.
function hvs__cell_solid(_k, _s, _x, _y, _c, _u, _r) {
    var _ramp = _s.sh;
    hvs__rect(_x, _y, _c, _c, c_black, 0.35);
    hvs__mass(hvs__rr(_x + 1, _y + 1, _c - 2, _c - 2, _c * 0.14, 3), _ramp, _c * 0.09);
    hvs__stitch_box(_x + _c * 0.18, _y + _c * 0.18, _c * 0.64, _c * 0.64, 5 * _u, _ramp[4]);
}

// ------------------------------------------------------------------------------------------------ the cache

/// @function hvs_case_shell_art(kind, material, w, rows, cell, seed, wear)
/// @description The baked case around a grid window: {spr, w, h}. Drawn on first use and kept.
function hvs_case_shell_art(_k, _mat, _w, _rows, _cell, _seed = 1, _wear = 0.35) {
    _w = clamp(floor(hvs__n(_w, 1)), 1, HVS_MAX_SIDE); _rows = clamp(floor(hvs__n(_rows, 1)), 1, HVS_MAX_SIDE); _cell = hvs__cell_cap(_w, _rows, _cell);
    _seed = hvs__n(_seed, 1); _wear = clamp(hvs__n(_wear, 0.35), 0, 1);
    if (!is_string(_k)) _k = "attache";
    if (!is_string(_mat)) _mat = "hide";
    var _key = "sh|" + _k + "|" + _mat + "|" + string(_w) + "|" + string(_rows) + "|" + string(_cell) + "|" + string(_seed) + "|" + string(round(_wear * 100));
    var _cache = hvs__cache(), _e = _cache[$ _key];
    if (!is_undefined(_e) && sprite_exists(_e.spr)) return _e;
    var _m = hvs_case_metrics(_k, _w, _rows, _cell), _gw = _w * _cell, _gh = _rows * _cell;
    var _ss = (_m.w > 1024 || _m.h > 1024) ? 1 : 2;
    var _b = hvs__bake_begin(_m.w, _m.h, _ss);
    hvs__b_begin();
    hvs__case_ground_shadow(_k, _m.w, _m.h, hvs__u(_cell));
    hvs__case_shell(_k, _mat, _m.w, _m.h, _m, _gw, _gh, _cell, _seed, _wear);
    hvs__b_end();
    hvs__case_type(_k, _mat, _m, _cell, _seed);
    _e = { spr: hvs__bake_end(_b, 0, 0), w: _m.w, h: _m.h };
    _cache[$ _key] = _e;
    return _e;
}
/// @function hvs__case_ground_shadow(kind, W, H, u)
/// @description Internal. The soft shadow a case casts on what it sits on: the shape of its BODY, which on a rucksack or a chest is well inside the sprite's box.
function hvs__case_ground_shadow(_k, _W, _H, _u) {
    var _pad = 8 * _u, _top = 0, _side = 0, _rad = 10 * _u;
    switch (_k) {
        case "attache": _top = 22 * _u; break;
        case "rucksack": _top = 18 * _u; _side = 8 * _u; _rad = 24 * _u; break;
        case "footlocker": _top = 12 * _u; break;
        case "saddlebag": _top = 14 * _u; _rad = 30 * _u; break;
        case "chest": _top = 8 * _u; break;
        case "toolroll": _side = 2 * _u; break;
    }
    for (var _i = 5; _i >= 0; _i--) {
        var _e = _i * 1.2 * _u, _x = _pad + _side - _e + 2 * _u, _y = _pad + _top - _e + 4 * _u, _w = _W - (_pad + _side) * 2 + _e * 2 - 2 * _u, _h = _H - _pad * 2 - _top + _e * 2 - 2 * _u;
        var _pts = hvs__rr(_x, _y, _w, _h, _rad + _e, 3), _n = array_length(_pts) div 2, _ct = hvs__centroid(_pts);
        for (var _q = 0; _q < _n; _q++) { var _j = (_q + 1) mod _n; hvs__tri(_ct[0], _ct[1], c_black, 0.075, _pts[_q * 2], _pts[_q * 2 + 1], c_black, 0.075, _pts[_j * 2], _pts[_j * 2 + 1], c_black, 0.075); }
    }
}
/// @function hvs__case_type(kind, material, m, cell, seed)
/// @description Internal. Lettering: a crate's stencil and a footlocker's number. Set in the package's own stencil face.
function hvs__case_type(_k, _mat, _m, _cell, _seed) {
    if (_k != "crate" && _k != "footlocker") return;
    var _u = hvs__u(_cell), _s = hvs__mat_spec(_mat), _ty = _m.h - 8 * _u - (_k == "crate" ? 10 * _u : 11 * _u);
    draw_set_font(fnt_haversack_display_s);
    draw_set_halign(fa_center); draw_set_valign(fa_middle);
    var _lab = (_k == "crate" ? "LOT " : "NO. ") + string(100 + (floor(abs(_seed)) * 37) mod 900);
    gpu_set_tex_filter(true);
    draw_set_alpha(0.55);
    draw_text_transformed_colour(_m.w * 0.5, _ty, _lab, 0.36 * _u, 0.36 * _u, 0, _s.ink, _s.ink, _s.ink, _s.ink, 0.55);
    draw_set_alpha(1);
    draw_set_halign(fa_left); draw_set_valign(fa_top);
}
/// @function hvs_case_lining_art(container, cell)
/// @description The baked lining of a container's whole grid: {spr, w, h}. Keyed on everything that changes the picture.
function hvs_case_lining_art(_c, _cell) {
    if (!hvs__is_case(_c)) return undefined;
    _cell = hvs__cell_cap(_c.w, _c.h, _cell);
    var _msig = is_undefined(_c.mask) ? "" : string(_c.mask), _dsig = array_length(_c.dividers) == 0 ? "" : string(_c.dividers);
    var _key = "ln|" + _c.kind + "|" + _c.material + "|" + string(_c.w) + "|" + string(_c.h) + "|" + string(_cell) + "|" + string(_c.seed) + "|" + _msig + "|" + _dsig;
    var _cache = hvs__cache(), _e = _cache[$ _key];
    if (!is_undefined(_e) && sprite_exists(_e.spr)) return _e;
    var _W = _c.w * _cell, _H = _c.h * _cell, _ss = (_W > 1024 || _H > 1024) ? 1 : 2;
    var _b = hvs__bake_begin(_W, _H, _ss);
    hvs__b_begin();
    hvs__lining(_c.kind, _c.material, _c, _cell, _c.seed);
    hvs__b_end();
    _e = { spr: hvs__bake_end(_b, 0, 0), w: _W, h: _H };
    _cache[$ _key] = _e;
    return _e;
}
