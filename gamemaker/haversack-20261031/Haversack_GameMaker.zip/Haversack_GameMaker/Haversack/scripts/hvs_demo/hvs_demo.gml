/// hvs_demo.gml - THE QUARTERMASTER: Haversack's demo room. A bench with a case in front of you, a crate of loot and a scrolling footlocker. It uses only the public API. Delete this script and obj_hvs_demo from a shipped game.
///
/// Haversack - A Spatial Inventory That Draws Its Own Containers. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function hvs_demo_fill(container, list)
/// @description Fill a container with [id, x, y, rot, count] rows, skipping what does not fit.
function hvs_demo_fill(_c, _rows) {
    for (var _i = 0; _i < array_length(_rows); _i++) {
        var _r = _rows[_i], _it = hvs_item(_r[0], array_length(_r) > 4 ? _r[4] : 1);
        if (is_undefined(_it)) continue;
        hvs_put(_c, _it, _r[1], _r[2], _r[3]);
    }
}
/// @function hvs_demo_create()
/// @description Build the room's whole state.
function hvs_demo_create() {
    hvs_starter_items();
    // two coloured variants of the drawn forms, as a buyer would declare their own
    hvs_item_define("potion_red", { name: "Red Flask", shape: ["X", "X"], weight: 0.4, form: "potion", hue: 27 });
    hvs_item_define("potion_blue", { name: "Blue Flask", shape: ["X", "X"], weight: 0.4, form: "potion", hue: 245 });
    hvs_item_define("gem_green", { name: "Green Stone", shape: ["X"], weight: 0.05, stack: 10, form: "gem", hue: 150 });
    hvs_item_define("gem_blue", { name: "Blue Stone", shape: ["X"], weight: 0.05, stack: 10, form: "gem", hue: 255 });
    var _d = { kinds: hvs_case_kinds(), mats: hvs_case_materials(), kind_i: 0, mat_i: 0, ev: "Drag an item. R turns it. Drop it somewhere it cannot go and it springs back.", ev_t: 0, idle: 0, pad_seen: false, bg: -1, saved: "", subject: undefined, crate: undefined, locker: undefined, roll: undefined, main: undefined };
    _d.desk = hvs_desk_create({ on_event: method(_d, function(_what, _it, _p) {
        var _n = is_undefined(_it) ? "" : _it.def.name;
        switch (_what) {
            case "lift": ev = "Lifted the " + _n + ". It stays in its case, and in any save, until it lands."; break;
            case "drop": ev = _n + " placed."; break;
            case "snapback": ev = "No room: the " + _n + " sprang back to where it was, as it was."; break;
            case "rotate": ev = _n + " turned."; break;
            case "swap": ev = "Swapped: now holding the " + _n + "."; break;
            case "stack": ev = "Stacked: " + _n + " now " + string(_it.count) + " of " + string(_it.def.stack) + "."; break;
            case "transfer": ev = _n + " moved across."; break;
            case "tidy": ev = "Tidied."; break;
        }
    })});
    hvs_demo_rebuild(_d, true);
    return _d;
}
/// @function hvs_demo_rebuild(demo, first)
/// @description (Re)lay the bench: used when the main case changes kind or material. The contents survive by save and load; whatever no longer fits goes to the crate.
function hvs_demo_rebuild(_d, _first) {
    var _desk = _d.desk, _kind = _d.kinds[_d.kind_i], _mat = _d.mats[_d.mat_i], _keep = undefined;
    if (!_first) { hvs_desk_cancel(_desk); _keep = hvs_save_struct(_d.main); hvs_desk_remove(_desk, _d.main); }
    var _w = 9, _h = 6, _cell = 44;
    var _opts = { w: _w, h: _h, kind: _kind, material: _mat, seed: 12 + _d.kind_i * 3 + _d.mat_i, wear: 0.45, mask: hvs_case_mask(_kind, _w, _h), limit: 30, name: hvs_case_title(_kind, _mat) };
    if (_kind == "footlocker") _opts.dividers = [["v", 6, 0, 6]];
    if (_kind == "toolroll") _opts.dividers = [["h", 3, 0, 9]];
    var _main = hvs_container(_opts);
    if (_first) {
        _d.crate = hvs_container({ w: 7, h: 3, kind: "crate", material: "oak", seed: 31, wear: 0.6, name: "Loot Crate" });
        _d.locker = hvs_container({ w: 7, h: 8, kind: "locker", material: "steel", seed: 44, wear: 0.3, name: "Stash" });
        // a roll of small pockets: its accept function refuses anything bigger than two cells
        _d.roll = hvs_container({ w: 8, h: 2, kind: "toolroll", material: "canvas", seed: 52, wear: 0.5, name: "Tool Roll", accept: function(_i, _c) { return _i.def.area <= 2; } });
        hvs_demo_fill(_main, [["rifle", 0, 0, 0], ["shotgun", 0, 3, 0], ["pistol", 5, 0, 0], ["medkit", 7, 0, 0], ["magazine", 7, 2, 0, 3], ["potion_red", 8, 2, 0], ["grenade", 0, 2, 0, 2], ["herb", 1, 2, 0, 6], ["knife", 3, 4, 0], ["ammobox", 0, 4, 0, 2]]);
        hvs_demo_fill(_d.crate, [["axe", 0, 0, 0], ["gem_green", 2, 0, 0, 4], ["gem_blue", 3, 0, 0, 3], ["bread", 4, 0, 0, 2], ["key", 2, 1, 0], ["potion_blue", 6, 0, 0], ["goldbar", 4, 1, 0, 2], ["bandage", 2, 2, 0, 4]]);
        hvs_demo_fill(_d.roll, [["key", 0, 0, 0], ["syringe", 2, 0, 0], ["battery", 4, 0, 0, 4], ["flashlight", 5, 0, 0], ["vial", 7, 0, 0, 3], ["bandage", 0, 1, 0, 3], ["gem", 1, 1, 0, 2], ["ring", 2, 1, 0], ["scroll", 3, 1, 0, 2], ["herb", 5, 1, 0, 8]]);
        hvs_demo_fill(_d.locker, [["warhammer", 0, 0, 0], ["helmet", 3, 0, 0], ["longrifle", 0, 2, 1], ["roundshield", 5, 0, 0], ["book", 3, 3, 0], ["rope", 5, 3, 0], ["lantern", 1, 3, 0], ["pouch", 3, 5, 0], ["boots", 5, 5, 0], ["skull", 1, 6, 0]]);
    } else {
        // the same contents, carried across: every item finds room or joins the crate
        var _rep = {};
        var _old = hvs_load_struct(_keep, _rep);
        if (!is_undefined(_old)) {
            var _list = [], _ni = array_length(_old.items);
            for (var _i = 0; _i < _ni; _i++) { var _it = _old.items[_i]; array_push(_list, [_it, _it.x, _it.y, _it.rot]); }
            hvs_clear(_old);
            for (var _i = 0; _i < _ni; _i++) hvs_put(_main, _list[_i][0], _list[_i][1], _list[_i][2], _list[_i][3]);
            // anything the new shape refuses at its old place finds other room, or joins the crate
            for (var _i = 0; _i < _ni; _i++) { var _it = _list[_i][0]; if (is_undefined(_it.home)) { if (!hvs_add(_main, _it)) hvs_add(_d.crate, _it); } }
        }
    }
    _d.main = _main;
    _d.pane_main = hvs_desk_add(_desk, _main, 24, 94, { cell: _cell });
    if (!_first) {
        // the pouch may have been in the case that just changed: if so its open pane must follow the new one
        var _moved = hvs_find(_main, "pouch");
        if (!is_undefined(_moved) && is_struct(_d[$ "pane_pouch"]) && _d.pane_pouch.c != _moved.inside) {
            hvs_desk_remove(_desk, _d.pane_pouch.c);
            _d.pane_pouch = hvs_desk_add(_desk, _moved.inside, 912, 92, { cell: 44 });
        }
    }
    if (_first) {
        var _rx = 534;
        _d.pane_crate = hvs_desk_add(_desk, _d.crate, _rx, 92, { cell: 44 });
        var _mc = hvs_case_metrics("crate", 7, 3, 44);
        _d.pane_locker = hvs_desk_add(_desk, _d.locker, _rx, 92 + _mc.h + 2, { cell: 44, rows: 4 });
        _d.pane_roll = hvs_desk_add(_desk, _d.roll, 24, 486, { cell: 44 });
        // the pouch in the stash is a container too: it opens on the bench
        var _pouch = hvs_find(_d.locker, "pouch");
        if (!is_undefined(_pouch)) {
            hvs_demo_fill(_pouch.inside, [["gem_green", 0, 0, 0, 2], ["ring", 1, 0, 0], ["coinpouch", 2, 0, 0], ["apple", 0, 2, 0, 4], ["mushroom", 1, 2, 0, 3]]);
            _d.pane_pouch = hvs_desk_add(_desk, _pouch.inside, 912, 92, { cell: 44 });
        }
    }
}
/// @function hvs_demo_bench(w, h)
/// @description The bench: planks under a lamp. Drawn once to a sprite by the package.
function hvs_demo_bench(_w, _h) {
    var _b = hvs__bake_begin(_w, _h, 1), _g = hvs_rng(9), _r = hvs_ramp(0.30, 0.040, 58, 0.11);
    hvs__b_begin();
    hvs__rect(0, 0, _w, _h, _r[1], 1);
    var _ph = 58, _y = 0;
    while (_y < _h) {
        var _t = hvs_rand(_g) * 0.12;
        hvs__rect(0, _y, _w, _ph, hvs_rand(_g) < 0.5 ? c_black : _r[4], _t);
        for (var _l = 0; _l < 12; _l++) {
            var _ly = _y + (_l + 0.5) * _ph / 12, _ph0 = hvs_rand(_g) * 6.28, _amp = 0.6 + hvs_rand(_g) * 1.6, _al = 0.08 + hvs_rand(_g) * 0.14, _c = hvs_rand(_g) < 0.7 ? _r[0] : _r[4], _px = 0;
            while (_px < _w) { var _nx = _px + 28; hvs__seg(_px, _ly + sin(_ph0 + _px * 0.012) * _amp, _nx, _ly + sin(_ph0 + _nx * 0.012) * _amp, 1, _c, _al); _px = _nx; }
        }
        hvs__seg(0, _y, _w, _y, 2, c_black, 0.6); hvs__seg(0, _y + 2, _w, _y + 2, 1, _r[4], 0.2);
        _y += _ph;
    }
    // the lamp: broad and warm over the middle, night at the corners
    var _cx = _w * 0.46, _cy = _h * 0.42, _n = 26, _R = max(_w, _h) * 0.86;
    for (var _i = 0; _i < _n; _i++) {
        var _a0 = _i / _n * 2 * pi, _a1 = (_i + 1) / _n * 2 * pi, _lamp = make_colour_rgb(255, 214, 150);
        hvs__tri(_cx, _cy, _lamp, 0.14, _cx + cos(_a0) * _R * 0.55, _cy + sin(_a0) * _R * 0.55, _lamp, 0, _cx + cos(_a1) * _R * 0.55, _cy + sin(_a1) * _R * 0.55, _lamp, 0);
        hvs__quad(_cx + cos(_a0) * _R * 0.45, _cy + sin(_a0) * _R * 0.45, c_black, 0, _cx + cos(_a1) * _R * 0.45, _cy + sin(_a1) * _R * 0.45, c_black, 0, _cx + cos(_a1) * _R, _cy + sin(_a1) * _R, c_black, 0.72, _cx + cos(_a0) * _R, _cy + sin(_a0) * _R, c_black, 0.72);
    }
    hvs__b_end();
    return hvs__bake_end(_b, 0, 0);
}
/// @function hvs_demo_step(demo)
/// @description One frame of the room.
function hvs_demo_step(_d) {
    hvs_desk_step(_d.desk);
    if (keyboard_check_pressed(ord("K"))) { _d.kind_i = (_d.kind_i + 1) mod array_length(_d.kinds); hvs_demo_rebuild(_d, false); }
    if (keyboard_check_pressed(ord("M"))) { _d.mat_i = (_d.mat_i + 1) mod array_length(_d.mats); hvs_demo_rebuild(_d, false); }
    if (keyboard_check_pressed(ord("S"))) { _d.saved = hvs_save_string(_d.main); _d.ev = "Saved the case: " + string(string_length(_d.saved)) + " characters of JSON, rotation and nesting included."; }
    if (keyboard_check_pressed(ord("L")) && _d.saved != "") {
        var _rep = {}, _loaded = hvs_load_string(_d.saved, _rep);
        if (!is_undefined(_loaded)) {
            hvs_desk_cancel(_d.desk);
            hvs_desk_remove(_d.desk, _d.main);
            _d.main = _loaded;
            _d.pane_main = hvs_desk_add(_d.desk, _loaded, 24, 94, { cell: 44 });
            _d.subject = undefined;
            _d.ev = "Loaded: " + string(array_length(_loaded.items)) + " items, exactly as saved.";
        }
    }
}
/// @function hvs_demo_draw(demo, w, h)
/// @description Draw the room: the bench, the desk, the title and the prompts.
function hvs_demo_draw(_d, _w = 1280, _h = 720) {
    if (!sprite_exists(_d.bg)) _d.bg = hvs_demo_bench(_w, _h);
    gpu_set_blendmode_ext(bm_one, bm_zero);
    draw_sprite(_d.bg, 0, 0, 0);
    gpu_set_blendmode(bm_normal);
    hvs_desk_draw(_d.desk);
    gpu_set_tex_filter(true);
    var _ink = make_colour_rgb(238, 224, 190), _dim = make_colour_rgb(176, 158, 124);
    draw_set_halign(fa_left); draw_set_valign(fa_top);
    draw_set_font(fnt_haversack_display_l); draw_set_colour(_ink);
    draw_text_transformed(32, 12, "HAVERSACK", 0.82, 0.82, 0);
    draw_set_font(fnt_haversack_body_l); draw_set_colour(_dim);
    draw_text_transformed(32, 62, "THE QUARTERMASTER  /  " + _d.main.name, 0.42, 0.42, 0);
    // the inspector: the thing under the hand, at a size that shows it, with its footprint
    var _subj = hvs_desk_held(_d.desk);
    if (is_undefined(_subj)) _subj = hvs_desk_hovered(_d.desk);
    if (!is_undefined(_subj)) _d.subject = _subj;
    if (is_undefined(_d.subject)) _d.subject = _d.main.items[0];
    hvs_demo_inspector(_d, 912, 336, 344, 286, _d.subject);
    // the load
    var _lim = _d.main.limit, _wg = hvs_weight(_d.main), _bx = 912, _by = _h - 74, _bw = 344;
    draw_set_font(fnt_haversack_body_s); draw_set_colour(_ink);
    draw_text_transformed(_bx, _by - 22, "CARRIED IN THE CASE  " + string_format(_wg, 1, 1) + " / " + string_format(_lim, 1, 0) + " KG", 0.72, 0.72, 0);
    draw_set_colour(c_black); draw_set_alpha(0.55); draw_rectangle(_bx, _by, _bx + _bw, _by + 8, false); draw_set_alpha(1);
    var _f = clamp(_wg / max(1, _lim), 0, 1);
    draw_set_colour(_f > 0.85 ? make_colour_rgb(228, 78, 60) : make_colour_rgb(226, 188, 104));
    draw_rectangle(_bx, _by, _bx + _bw * _f, _by + 8, false);
    // the prompts
    draw_set_colour(_ink);
    draw_text_transformed(32, _h - 34, _d.ev, 0.78, 0.78, 0);
    draw_set_colour(_dim);
    draw_set_halign(fa_right);
    draw_text_transformed(_w - 24, 16, "DRAG or CLICK  /  R or RIGHT MOUSE turn  /  SHIFT+CLICK quick-move  /  T tidy  /  WHEEL scroll", 0.68, 0.68, 0);
    draw_text_transformed(_w - 24, 40, "K case  /  M material  /  S save  /  L load  /  GAMEPAD: d-pad, A, X, B, Y, START", 0.68, 0.68, 0);
    draw_set_halign(fa_left);
    draw_set_colour(c_white);
}
/// @function hvs_demo_inspector(demo, x, y, w, h, item)
/// @description The inspector plate: the item, large; its footprint as a small diagram; its numbers. Everything comes from the item's definition.
function hvs_demo_inspector(_d, _x, _y, _w, _h, _it) {
    var _ink = make_colour_rgb(238, 224, 190), _dim = make_colour_rgb(176, 158, 124), _cl = make_colour_rgb(226, 188, 104);
    draw_set_colour(make_colour_rgb(18, 14, 11)); draw_set_alpha(0.74); draw_rectangle(_x, _y, _x + _w, _y + _h, false); draw_set_alpha(1);
    draw_set_colour(_cl); draw_rectangle(_x, _y, _x + _w, _y + 2, false);
    var _def = _it.def, _rt = _def.rots[0], _cell = clamp(min((_w - 40) / _rt.w, 130 / _rt.h), 16, 64);
    var _ax = _x + 20 + (_w - 40 - _rt.w * _cell) * 0.5, _ay = _y + 12 + (130 - _rt.h * _cell) * 0.5;
    hvs_item_draw(_it, _ax, _ay, 0, floor(_cell));
    gpu_set_tex_filter(true);
    draw_set_halign(fa_left); draw_set_valign(fa_top);
    draw_set_font(fnt_haversack_display_s); draw_set_colour(_ink);
    var _sc = min(1, (_w - 36) / max(1, string_width(string_upper(_def.name))));
    draw_text_transformed(_x + 18, _y + 146, string_upper(_def.name), _sc * 0.72, _sc * 0.72, 0);
    draw_set_font(fnt_haversack_body_s); draw_set_colour(_dim);
    var _lines = ["FOOTPRINT  " + string(_def.area) + (_def.area == 1 ? " cell" : " cells") + ", " + string(array_length(_def.distinct)) + (array_length(_def.distinct) == 1 ? " rotation" : " rotations"),
        "WEIGHT  " + string_format(_def.weight, 1, 2) + " kg",
        (_def.stack > 1 ? "STACK  " + string(_it.count) + " of " + string(_def.stack) : (is_undefined(_it.inside) ? "DOES NOT STACK" : "HOLDS  " + string(_it.inside.w) + " x " + string(_it.inside.h)))];
    for (var _i = 0; _i < 3; _i++) draw_text_transformed(_x + 18, _y + 180 + _i * 24, _lines[_i], 0.72, 0.72, 0);
    // the footprint, as cells
    var _c = min(16, 88 / max(_rt.w, _rt.h)), _fx = _x + _w - 18 - _rt.w * _c, _fy = _y + _h - 14 - _rt.h * _c;
    draw_set_colour(_cl);
    for (var _i = 0; _i < array_length(_rt.cells); _i++) draw_rectangle(_fx + _rt.cells[_i][0] * _c, _fy + _rt.cells[_i][1] * _c, _fx + (_rt.cells[_i][0] + 1) * _c - 2, _fy + (_rt.cells[_i][1] + 1) * _c - 2, false);
    draw_set_colour(c_white);
}
/// @function hvs_demo_free(demo)
/// @description Free the room's surfaces and sprites.
function hvs_demo_free(_d) {
    if (!is_struct(_d)) return;
    hvs_desk_free(_d.desk);
    if (sprite_exists(_d.bg)) sprite_delete(_d.bg);
    hvs_art_free();
}
