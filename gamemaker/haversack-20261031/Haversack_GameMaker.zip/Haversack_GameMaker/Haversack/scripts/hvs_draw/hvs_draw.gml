/// hvs_draw.gml - the desk on screen. Each container's contents live on a surface that is redrawn ONLY when something in it changes (a surface lost to a window resize is rebuilt from the
/// sprites, which survive), so an open inventory with nothing happening costs a few sprite draws a frame. Per frame: the hover, the ghost, the item in the hand and any item in flight.
///
/// Haversack - A Spatial Inventory That Draws Its Own Containers. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function hvs_why_text(why)
/// @description hvs_why's answer as a short plain caption, ready for a player.
function hvs_why_text(_w) {
    switch (_w) {
        case "ok": return "Fits";
        case "bounds": return "Off the edge";
        case "masked": return "No room there";
        case "occupied": return "In the way";
        case "divider": return "Across a divider";
        case "self": return "Not inside itself";
        case "weight": return "Too heavy";
        case "refused": return "Does not belong here";
        default: return "";
    }
}
/// @function hvs__pane_hide(desk, pane)
/// @description Internal. Which of this pane's items are off the surface right now: the one in the hand, and any in flight. A change to this set is a change to the picture.
function hvs__pane_hide(_d, _p) {
    var _sig = "";
    if (!is_undefined(_d.hold) && _d.hold.it.home == _p.c) _sig += string(_d.hold.it.uid) + ",";
    for (var _i = 0; _i < array_length(_d.flights); _i++) { var _f = _d.flights[_i]; if (_f.pane == _p) _sig += string(_f.it.uid) + ","; }
    return _sig;
}
/// @function hvs__pane_compose(desk, pane)
/// @description Internal. Redraw a pane's contents: the lining, each item's contact shadow, then each item. Counted in pane.composes.
function hvs__pane_compose(_d, _p, _hide) {
    var _c = _p.c, _cell = _p.cell, _W = _c.w * _cell, _H = _c.h * _cell;
    var _m = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_build_identity());
    if (!surface_exists(_p.surf)) _p.surf = surface_create(_W, _H);
    // bake anything new BEFORE the surface target is set: a bake switches targets
    var _lin = hvs_case_lining_art(_c, _cell), _n = array_length(_c.items), _arts = array_create(_n, undefined);
    for (var _i = 0; _i < _n; _i++) { var _it = _c.items[_i]; _arts[_i] = hvs_item_art(_it, _it.rot, _cell); }
    surface_set_target(_p.surf);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_one, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_tex_filter(false);
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false); gpu_set_cullmode(cull_noculling); gpu_set_alphatestenable(false);
    draw_sprite(_lin.spr, 0, 0, 0);
    var _off = max(1.5, _cell * 0.06);
    for (var _i = 0; _i < _n; _i++) {
        var _it = _c.items[_i];
        if (string_pos("," + string(_it.uid) + ",", "," + _hide) > 0) continue;
        var _a = _arts[_i];
        var _cx = _it.x * _cell + _a.w * 0.5, _cy = _it.y * _cell + _a.h * 0.5;
        draw_sprite_ext(_a.spr_shadow, 0, _cx + _off, _cy + _off, 1, 1, 0, c_white, 0.72);
    }
    for (var _i = 0; _i < _n; _i++) {
        var _it = _c.items[_i];
        if (string_pos("," + string(_it.uid) + ",", "," + _hide) > 0) continue;
        var _a = _arts[_i];
        draw_sprite(_a.spr, 0, _it.x * _cell + _a.w * 0.5, _it.y * _cell + _a.h * 0.5);
    }
    // stack counts
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_tex_filter(true);
    for (var _i = 0; _i < _n; _i++) {
        var _it = _c.items[_i];
        if (_it.def.stack <= 1 || string_pos("," + string(_it.uid) + ",", "," + _hide) > 0) continue;
        var _a = _arts[_i];
        hvs__count_label(_d, _it.x * _cell + _a.w, _it.y * _cell + _a.h, _it.count, _cell);
    }
    gpu_pop_state();
    surface_reset_target();
    matrix_set(matrix_world, _m);
    _p.composes += 1; _d.composes += 1;
    _p.rev_seen = _c.rev; _p.hide_sig = _hide;
}
/// @function hvs__count_label(desk, x, y, count, cell)
/// @description Internal. A stack count, lower right of the item's box: lining figures on a small plate.
function hvs__count_label(_d, _x, _y, _n, _cell) {
    var _f = is_undefined(_d.font_small) ? fnt_haversack_body_s : _d.font_small;
    draw_set_font(_f);
    var _sc = clamp(_cell * 0.0125, 0.4, 0.9), _t = string(_n), _tw = string_width(_t) * _sc, _th = string_height(_t) * _sc;
    var _x1 = _x - 2, _y1 = _y - 2, _x0 = _x1 - _tw - 5, _y0 = _y1 - _th * 0.92;
    draw_set_colour(c_black); draw_set_alpha(0.72);
    draw_rectangle(_x0, _y0, _x1, _y1, false);
    draw_set_alpha(1);
    draw_set_halign(fa_right); draw_set_valign(fa_bottom);
    draw_set_colour(make_colour_rgb(244, 234, 208));
    draw_text_transformed(_x1 - 2.5, _y1 + _th * 0.04, _t, _sc, _sc, 0);
    draw_set_halign(fa_left); draw_set_valign(fa_top);
}
/// @function hvs__art_draw(art, cx, cy, scale, angle, alpha, shadow)
/// @description Internal. Draw a baked item at its centre, with a shadow that grows as it is lifted.
function hvs__art_draw(_a, _cx, _cy, _sc, _ang, _shoff, _shalpha) {
    if (_shoff > 0) draw_sprite_ext(_a.spr_shadow, 0, _cx + _shoff, _cy + _shoff * 1.25, _sc * 1.02, _sc * 1.02, _ang, c_white, _shalpha);
    draw_sprite_ext(_a.spr, 0, _cx, _cy, _sc, _sc, _ang, c_white, 1);
}
/// @function hvs__footprint_outline(pane, item, rot, x, y, col, alpha, width)
/// @description Internal. Trace the outside of a footprint: only edges with no neighbour in the footprint, so an L reads as an L.
function hvs__footprint_outline(_p, _it, _rot, _x, _y, _col, _alpha, _w) {
    var _rt = _it.def.rots[_rot], _cells = _rt.cells, _n = array_length(_cells), _cell = _p.cell, _map = _rt.map, _bw = _rt.w, _bh = _rt.h;
    var _o = hvs_cell_screen(_p, _x, _y);
    for (var _i = 0; _i < _n; _i++) {
        var _cx = _cells[_i][0], _cy = _cells[_i][1], _sx = _o.x + _cx * _cell, _sy = _o.y + _cy * _cell;
        if (_sy + _cell <= _p.gy || _sy >= _p.gy + hvs__pane_view_h(_p)) continue;
        if (_cy == 0 || !_map[(_cy - 1) * _bw + _cx]) hvs__seg(_sx - _w * 0.5, _sy, _sx + _cell + _w * 0.5, _sy, _w, _col, _alpha);
        if (_cy == _bh - 1 || !_map[(_cy + 1) * _bw + _cx]) hvs__seg(_sx - _w * 0.5, _sy + _cell, _sx + _cell + _w * 0.5, _sy + _cell, _w, _col, _alpha);
        if (_cx == 0 || !_map[_cy * _bw + _cx - 1]) hvs__seg(_sx, _sy - _w * 0.5, _sx, _sy + _cell + _w * 0.5, _w, _col, _alpha);
        if (_cx == _bw - 1 || !_map[_cy * _bw + _cx + 1]) hvs__seg(_sx + _cell, _sy - _w * 0.5, _sx + _cell, _sy + _cell + _w * 0.5, _w, _col, _alpha);
    }
}
/// @function hvs__ghost_draw(desk)
/// @description Internal. Where the held item would land: each cell glows if it can go there; each cell that cannot is hatched red; a stack or a swap reads amber.
function hvs__ghost_draw(_d) {
    var _h = _d.hold, _t = _d.target;
    if (is_undefined(_h) || is_undefined(_t)) return;
    var _p = _t.pane, _it = _h.it, _rt = _it.def.rots[_h.rot], _cells = _rt.cells, _n = array_length(_cells), _cell = _p.cell;
    var _ok = _t.why == "ok", _alt = !is_undefined(_t.swap) || !is_undefined(_t.merge);
    var _good = _ok ? make_colour_rgb(120, 236, 150) : make_colour_rgb(255, 196, 92), _bad = make_colour_rgb(246, 62, 52);
    var _pulse = 0.5 + 0.5 * sin(_d.frame * 0.16);
    hvs__b_begin();
    for (var _i = 0; _i < _n; _i++) {
        var _cx = _t.x + _cells[_i][0], _cy = _t.y + _cells[_i][1], _o = hvs_cell_screen(_p, _cx, _cy), _sx = _o.x, _sy = _o.y;
        if (_sy + _cell <= _p.gy || _sy >= _p.gy + hvs__pane_view_h(_p)) continue;
        var _legal = _ok || _alt;
        if (!_legal) {
            // say exactly which cells are the problem
            var _v = (_cx >= 0 && _cy >= 0 && _cx < _p.c.w && _cy < _p.c.h) ? _p.c.grid[_cy * _p.c.w + _cx] : HVS_BLOCKED;
            var _thiscell = is_struct(_v) ? (_v != _it) : (_v == HVS_BLOCKED);
            if (_t.why != "occupied" && _t.why != "masked" && _t.why != "bounds") _thiscell = true;
            if (!_thiscell) { hvs__rect(_sx + 1, _sy + 1, _cell - 2, _cell - 2, _good, 0.10); continue; }
            hvs__rect(_sx + 1, _sy + 1, _cell - 2, _cell - 2, _bad, 0.22);
            // diagonal hatch, clipped to the cell by construction
            var _pp = max(5, _cell / 5), _lw = max(1.5, _cell * 0.045);
            for (var _q = _pp * 0.5; _q < _cell * 2; _q += _pp) {
                var _ax = _sx + min(_q, _cell - 1), _ay = _sy + 1 + max(0, _q - (_cell - 1)), _bx = _sx + 1 + max(0, _q - (_cell - 1)), _by = _sy + min(_q, _cell - 1);
                if (_ay < _sy + _cell - 1 && _bx < _sx + _cell - 1) hvs__seg(_ax, _ay, _bx, _by, _lw, _bad, 0.82);
            }
        } else {
            hvs__rect(_sx + 1, _sy + 1, _cell - 2, _cell - 2, _good, 0.20 + 0.08 * _pulse);
        }
    }
    hvs__footprint_outline(_p, _it, _h.rot, _t.x, _t.y, (_ok || _alt) ? _good : _bad, 0.95, max(1.5, _cell * 0.05));
    hvs__b_end();
}
/// @function hvs__pad_cursor_draw(desk)
/// @description Internal. The gamepad cursor: four corner brackets round the thing it is on, walking with it.
function hvs__pad_cursor_draw(_d) {
    if (!_d.pad_mode || !is_undefined(_d.hold)) return;
    var _cur = _d.cursor, _p = _cur.pane;
    if (is_undefined(_p)) return;
    var _it = hvs_at(_p.c, _cur.x, _cur.y), _x0, _y0, _x1, _y1;
    if (!is_undefined(_it)) {
        var _o = hvs_cell_screen(_p, _it.x, _it.y), _rt = _it.def.rots[_it.rot];
        _x0 = _o.x; _y0 = _o.y; _x1 = _o.x + _rt.w * _p.cell; _y1 = _o.y + _rt.h * _p.cell;
    } else {
        var _o2 = hvs_cell_screen(_p, _cur.x, _cur.y);
        _x0 = _o2.x; _y0 = _o2.y; _x1 = _o2.x + _p.cell; _y1 = _o2.y + _p.cell;
    }
    var _g = 2 + 1.5 * sin(_d.frame * 0.14), _l = _p.cell * 0.28, _w = max(2, _p.cell * 0.06), _c = make_colour_rgb(255, 232, 170);
    _x0 -= _g; _y0 -= _g; _x1 += _g; _y1 += _g;
    hvs__b_begin();
    hvs__seg(_x0, _y0, _x0 + _l, _y0, _w, _c, 1); hvs__seg(_x0, _y0, _x0, _y0 + _l, _w, _c, 1);
    hvs__seg(_x1, _y0, _x1 - _l, _y0, _w, _c, 1); hvs__seg(_x1, _y0, _x1, _y0 + _l, _w, _c, 1);
    hvs__seg(_x0, _y1, _x0 + _l, _y1, _w, _c, 1); hvs__seg(_x0, _y1, _x0, _y1 - _l, _w, _c, 1);
    hvs__seg(_x1, _y1, _x1 - _l, _y1, _w, _c, 1); hvs__seg(_x1, _y1, _x1, _y1 - _l, _w, _c, 1);
    hvs__b_end();
}
/// @function hvs__plate(desk, x, y, title, sub, accent)
/// @description Internal. A small name plate near the pointer, kept on screen.
function hvs__plate(_d, _x, _y, _title, _sub, _acc) {
    var _ft = is_undefined(_d.font) ? fnt_haversack_body_l : _d.font;
    var _fs = is_undefined(_d.font_small) ? fnt_haversack_body_s : _d.font_small;
    draw_set_font(_ft);
    var _sc = is_undefined(_d.font) ? 0.40 : 1, _tw = string_width(_title) * _sc, _th = string_height("Mg") * _sc;
    draw_set_font(_fs);
    var _ss = is_undefined(_d.font_small) ? 0.56 : 1, _sw = string_width(_sub) * _ss, _sh = _sub == "" ? 0 : string_height("Mg") * _ss;
    var _w = max(_tw, _sw) + 20, _h = _th + _sh + 12;
    var _gw = display_get_gui_width(), _gh = display_get_gui_height();
    var _px = clamp(_x, 4, max(4, _gw - _w - 4)), _py = clamp(_y, 4, max(4, _gh - _h - 4));
    draw_set_alpha(0.9); draw_set_colour(make_colour_rgb(20, 16, 12)); draw_rectangle(_px, _py, _px + _w, _py + _h, false);
    draw_set_alpha(1); draw_set_colour(_acc); draw_rectangle(_px, _py, _px + 3, _py + _h, false);
    gpu_set_tex_filter(true);
    draw_set_halign(fa_left); draw_set_valign(fa_top);
    draw_set_font(_ft); draw_set_colour(make_colour_rgb(244, 234, 208)); draw_text_transformed(_px + 12, _py + 4, _title, _sc, _sc, 0);
    if (_sub != "") { draw_set_font(_fs); draw_set_colour(make_colour_rgb(190, 178, 150)); draw_text_transformed(_px + 12, _py + 5 + _th, _sub, _ss, _ss, 0); }
}
/// @function hvs_desk_preload(desk)
/// @description Bake everything the desk's containers show now, so the first frame does not pay for it. Call it behind a loading screen, in a Draw event.
/// @returns {real} How long it took, in milliseconds.
function hvs_desk_preload(_d) {
    if (!hvs__is_desk(_d)) return 0;
    var _t = get_timer();
    for (var _i = 0; _i < array_length(_d.panes); _i++) {
        var _p = _d.panes[_i], _c = _p.c;
        if (_p.draw_case) hvs_case_shell_art(_c.kind, _c.material, _c.w, _p.rows, _p.cell, _c.seed, _c.wear);
        hvs_case_lining_art(_c, _p.cell);
        for (var _n = 0; _n < array_length(_c.items); _n++) {
            var _it = _c.items[_n];
            // every rotation it really has, because the player can turn it
            for (var _r = 0; _r < array_length(_it.def.distinct); _r++) hvs_item_art(_it, _it.def.distinct[_r], _p.cell);
        }
    }
    return (get_timer() - _t) / 1000;
}
/// @function hvs_desk_draw(desk)
/// @description Draw the whole desk. Call it in Draw GUI (or in Draw, with hvs_desk_step(d, {gui: false})). Blend mode, font, colour, alpha and alignment are handed back as they were found.
function hvs_desk_draw(_d) {
    if (!hvs__is_desk(_d)) return;
    var _pf = draw_get_font(), _pc = draw_get_colour(), _pa = draw_get_alpha(), _ph = draw_get_halign(), _pv = draw_get_valign();
    draw_set_alpha(1); draw_set_colour(c_white);
    // bake what this frame needs while no scissor or target of ours is up
    var _np = array_length(_d.panes);
    var _held = _d.hold;
    var _heldart = is_undefined(_held) ? undefined : hvs_item_art(_held.it, _held.rot, _held.cell);
    var _farts = array_create(array_length(_d.flights), undefined);
    for (var _i = 0; _i < array_length(_d.flights); _i++) { var _f = _d.flights[_i]; _farts[_i] = hvs_item_art(_f.it, _f.r1, _f.pane.cell); }
    for (var _i = 0; _i < _np; _i++) {
        var _p = _d.panes[_i], _hide = hvs__pane_hide(_d, _p);
        if (!surface_exists(_p.surf) || _p.rev_seen != _p.c.rev || _p.hide_sig != _hide) hvs__pane_compose(_d, _p, _hide);
    }
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_one, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_tex_filter(false);
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false); gpu_set_cullmode(cull_noculling); gpu_set_alphatestenable(false);
    // the cases and their contents
    for (var _i = 0; _i < _np; _i++) {
        var _p = _d.panes[_i], _c = _p.c, _cell = _p.cell, _vh = hvs__pane_view_h(_p), _gw = _c.w * _cell;
        if (_p.draw_case) { var _sa = hvs_case_shell_art(_c.kind, _c.material, _c.w, _p.rows, _cell, _c.seed, _c.wear); draw_sprite(_sa.spr, 0, _p.x, _p.y); }
        draw_surface_part(_p.surf, 0, _p.scroll, _gw, _vh, _p.gx, _p.gy);
        // the inner shadow of the case falls across the contents, so they sit IN it
        if (_p.draw_case) {
            gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
            var _sd = max(4, _cell * 0.16), _k = c_black;
            hvs__b_begin();
            hvs__quad(_p.gx, _p.gy, _k, 0.42, _p.gx + _gw, _p.gy, _k, 0.42, _p.gx + _gw, _p.gy + _sd, _k, 0, _p.gx, _p.gy + _sd, _k, 0);
            hvs__quad(_p.gx, _p.gy, _k, 0.30, _p.gx + _sd, _p.gy, _k, 0, _p.gx + _sd, _p.gy + _vh, _k, 0, _p.gx, _p.gy + _vh, _k, 0.30);
            if (hvs__scroll_max(_p) > 0) {
                // the scroll, drawn into the lining's margin
                var _frac = _p.rows / _c.h, _bar = _vh * _frac, _by = _p.gy + (_p.scroll / max(1, hvs__scroll_max(_p))) * (_vh - _bar);
                hvs__rect(_p.gx + _gw - 5, _p.gy + 2, 3, _vh - 4, c_black, 0.45);
                hvs__rect(_p.gx + _gw - 5, _by + 2, 3, _bar - 4, make_colour_rgb(238, 220, 170), 0.9);
            }
            hvs__b_end();
            gpu_set_blendmode_ext_sepalpha(bm_one, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
        }
    }
    // the hover
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    if (!is_undefined(_d.hover) && !_d.pad_mode) {
        var _hv = _d.hover, _it = _hv.it;
        hvs__b_begin();
        hvs__footprint_outline(_hv.pane, _it, _it.rot, _it.x, _it.y, make_colour_rgb(255, 236, 186), 0.85, max(1, _hv.pane.cell * 0.035));
        hvs__b_end();
    }
    hvs__ghost_draw(_d);
    hvs__pad_cursor_draw(_d);
    gpu_set_blendmode_ext_sepalpha(bm_one, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_tex_filter(true);
    // things in flight
    for (var _i = 0; _i < array_length(_d.flights); _i++) {
        var _f = _d.flights[_i], _pos = hvs__flight_pos(_f), _a = _farts[_i];
        hvs__art_draw(_a, _pos.x + _a.w * 0.5, _pos.y + _a.h * 0.5, 1 + 0.07 * _pos.lift, 0, 2 + 8 * _pos.lift, 0.62);
    }
    // the hand
    if (!is_undefined(_held) && !is_undefined(_heldart)) {
        var _a = _heldart;
        hvs__art_draw(_a, _held.px + _a.w * 0.5, _held.py + _a.h * 0.5, 1 + 0.06 * _held.lift, -_held.ang, 2 + 10 * _held.lift, 0.58);
    }
    gpu_pop_state();
    // captions
    gpu_push_state();
    if (!is_undefined(_d.target) && !is_undefined(_held) && _d.target.why != "ok" && is_undefined(_d.target.swap) && is_undefined(_d.target.merge)) {
        hvs__plate(_d, _held.px, _held.py - 44, hvs_why_text(_d.target.why), "", make_colour_rgb(246, 62, 52));
    } else if (_d.tooltips && !is_undefined(_d.hover)) {
        if (_d.hover_last == _d.hover.it) _d.hover_t += 1; else { _d.hover_last = _d.hover.it; _d.hover_t = 0; }
        if (_d.hover_t > 20) {
            var _ti = _d.hover.it, _o = hvs_cell_screen(_d.hover.pane, _ti.x, _ti.y), _rt = _ti.def.rots[_ti.rot], _sub = "";
            if (_ti.def.weight > 0) _sub = string_format(_ti.def.weight * _ti.count, 1, 1) + " kg";
            if (_ti.def.stack > 1) _sub += (_sub == "" ? "" : "   ") + string(_ti.count) + " of " + string(_ti.def.stack);
            hvs__plate(_d, _o.x + _rt.w * _d.hover.pane.cell + 6, _o.y, _ti.def.name, _sub, make_colour_rgb(238, 200, 120));
        }
    } else { _d.hover_last = undefined; _d.hover_t = 0; }
    gpu_pop_state();
    draw_set_font(_pf); draw_set_colour(_pc); draw_set_alpha(_pa); draw_set_halign(_ph); draw_set_valign(_pv);
}
