/// hvs_selftest.gml - Haversack's in-engine test suite. Run the demo with -selftest: the result is written as hvs_selftest.json in the game's save folder and the renders (hvs_render_*.png) beside it, to be LOOKED at.
/// Stages: the generator; definitions and rotation; containers and every refusal; stacks, weight and nesting; tidy (never loses an item, over random fills); save and load (and what happens when your definitions change); the hand, driven through hvs_desk_feed with no device attached; the gamepad walk (every item reachable from every cell); item art; case art; redraw only on change; resources; the demo; renders.
///
/// Haversack - A Spatial Inventory That Draws Its Own Containers. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function hvs_st_assert(state, condition, message)
/// @description Count one assertion; keep the first 80 failure messages.
function hvs_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 80) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
/// @function hvs_st_stage(state, n)
/// @description Record the stage reached (the crash handler reports it).
function hvs_st_stage(_st, _n) { _st.stage = _n; global.hvs_stage = _n; }
/// @function hvs__st_read(surface)
/// @description Internal. A surface read into a buffer (RGBA bytes, the whole surface).
function hvs__st_read(_surf) {
    var _w = surface_get_width(_surf), _h = surface_get_height(_surf), _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _surf, 0);
    return { buf: _b, w: _w, h: _h };
}
/// @function hvs__st_alpha_ink(read, x0, y0, x1, y1)
/// @description Internal. Pixels in a box with any real alpha (x step 1, y step 1).
function hvs__st_alpha_ink(_rd, _x0, _y0, _x1, _y1) {
    var _n = 0;
    for (var _y = max(0, floor(_y0)); _y < min(_rd.h, _y1); _y++) for (var _x = max(0, floor(_x0)); _x < min(_rd.w, _x1); _x++) if (buffer_peek(_rd.buf, (_y * _rd.w + _x) * 4 + 3, buffer_u8) > 24) _n++;
    return _n;
}
/// @function hvs__st_sprite_surface(sprite, w, h)
/// @description Internal. A sprite, premultiplied, onto a fresh transparent surface. Free the surface after.
function hvs__st_sprite_surface(_spr, _w, _h, _xo = 0, _yo = 0) {
    var _s = surface_create(_w, _h);
    surface_set_target(_s); draw_clear_alpha(c_black, 0);
    gpu_set_blendmode_ext(bm_one, bm_zero);
    draw_sprite(_spr, 0, _xo, _yo);
    gpu_set_blendmode(bm_normal);
    surface_reset_target();
    return _s;
}
/// @function hvs__st_grid(read, nx, ny)
/// @description Internal. A coarse per-channel signature of a read surface over black: a list of A, R, G, B cell means.
function hvs__st_grid(_rd, _nx, _ny) {
    var _o = array_create(_nx * _ny * 4, 0);
    for (var _gy = 0; _gy < _ny; _gy++) for (var _gx = 0; _gx < _nx; _gx++) {
        var _x0 = floor(_gx * _rd.w / _nx), _x1 = floor((_gx + 1) * _rd.w / _nx), _y0 = floor(_gy * _rd.h / _ny), _y1 = floor((_gy + 1) * _rd.h / _ny), _sr = 0, _sg = 0, _sb = 0, _sa = 0, _c = 0;
        for (var _y = _y0; _y < _y1; _y += 2) for (var _x = _x0; _x < _x1; _x += 2) {
            var _p = (_y * _rd.w + _x) * 4;
            _sr += buffer_peek(_rd.buf, _p, buffer_u8); _sg += buffer_peek(_rd.buf, _p + 1, buffer_u8); _sb += buffer_peek(_rd.buf, _p + 2, buffer_u8); _sa += buffer_peek(_rd.buf, _p + 3, buffer_u8); _c++;
        }
        var _i = (_gy * _nx + _gx) * 4;
        _o[_i] = real(_sa) / max(1, _c); _o[_i + 1] = real(_sr) / max(1, _c); _o[_i + 2] = real(_sg) / max(1, _c); _o[_i + 3] = real(_sb) / max(1, _c);
    }
    return _o;
}
/// @function hvs__st_diff(a, b)
/// @description Internal. Mean absolute difference of two grids, per channel value.
function hvs__st_diff(_a, _b) {
    var _n = min(array_length(_a), array_length(_b)), _s = 0;
    for (var _i = 0; _i < _n; _i++) _s += abs(_a[_i] - _b[_i]);
    return _s / max(1, _n);
}
/// @function hvs__st_consistent(container)
/// @description Internal. Do the grid and the item list agree? Every cell of every item holds that item, and no other cell holds anything. Returns an empty string or the first disagreement.
function hvs__st_consistent(_c) {
    var _seen = array_create(_c.w * _c.h, false), _n = array_length(_c.items);
    for (var _i = 0; _i < _n; _i++) {
        var _it = _c.items[_i], _cells = _it.def.rots[_it.rot].cells;
        if (_it.home != _c) return _it.id + " has another home";
        for (var _k = 0; _k < array_length(_cells); _k++) {
            var _x = _it.x + _cells[_k][0], _y = _it.y + _cells[_k][1];
            if (_x < 0 || _y < 0 || _x >= _c.w || _y >= _c.h) return _it.id + " off the grid";
            var _q = _y * _c.w + _x;
            if (_c.grid[_q] != _it) return _it.id + " cell does not hold it";
            if (_seen[_q]) return _it.id + " overlaps";
            _seen[_q] = true;
        }
    }
    for (var _q = 0; _q < _c.w * _c.h; _q++) { var _v = _c.grid[_q]; if (is_struct(_v) && !_seen[_q]) return "a stale cell at " + string(_q); }
    return "";
}
/// @function hvs__st_feed(desk, x, y, flags)
/// @description Internal. Feed one frame: pointer at x, y, with the named flags true.
function hvs__st_feed(_d, _x, _y, _flags = undefined) {
    var _in = is_struct(_flags) ? _flags : {};
    _in.mx = _x; _in.my = _y;
    hvs_desk_feed(_d, _in);
    hvs_desk_tick(_d);
}
/// @function hvs__st_centre(pane, x, y)
/// @description Internal. A cell's centre on screen.
function hvs__st_centre(_p, _x, _y) { var _s = hvs_cell_screen(_p, _x, _y); return [_s.x + _p.cell * 0.5, _s.y + _p.cell * 0.5]; }
/// @function hvs__st_settle(desk)
/// @description Internal. Run frames until nothing is in flight.
function hvs__st_settle(_d) { var _g = 0; while (array_length(_d.flights) > 0 && _g < 80) { hvs_desk_tick(_d); _g++; } }

/// @function hvs_selftest_run()
/// @description Run every stage; returns the state written by hvs_selftest_write.
function hvs_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, failures: [], stage: 0, notes: {}, timings: {} };
    _st.notes.epsilon = string_format(math_get_epsilon(), 1, 12);

    // ------------------------------------------------------------ 10: the generator
    hvs_st_stage(_st, 10);
    var _g1 = hvs_rng(42), _g2 = hvs_rng(42), _same = true;
    repeat (50) if (hvs_rand(_g1) != hvs_rand(_g2)) _same = false;
    hvs_st_assert(_st, _same, "the same seed draws the same sequence");
    var _lo = 1, _hi = 0;
    for (var _s = 0; _s < 400; _s++) { var _v = hvs_rand(hvs_rng(1000 + _s)); _lo = min(_lo, _v); _hi = max(_hi, _v); }
    hvs_st_assert(_st, _lo < 0.05 && _hi > 0.95, "first draws over 400 NEARBY seeds span [0,1): " + string(_lo) + ".." + string(_hi));

    // ------------------------------------------------------------ 20: definitions and rotation
    hvs_st_stage(_st, 20);
    hvs_st_assert(_st, is_undefined(hvs_item_define("bad", { shape: [] })), "an empty footprint is refused");
    hvs_st_assert(_st, is_undefined(hvs_item_define("bad", { shape: 12 })), "a number is not a footprint");
    hvs_st_assert(_st, is_undefined(hvs_item_define("", { shape: "1x1" })), "an empty id is refused");
    hvs_st_assert(_st, is_undefined(hvs_item("no_such_item")), "an unknown id makes no item");
    var _L = hvs_item_define("st_L", { shape: ["XX", "X.", "X."], weight: 2 });
    hvs_st_assert(_st, _L.area == 4 && array_length(_L.distinct) == 4, "an L has four real rotations: " + string(array_length(_L.distinct)));
    var _sq = hvs_item_define("st_sq", { shape: "2x2" });
    hvs_st_assert(_st, _sq.area == 4 && array_length(_sq.distinct) == 1, "a square has one real rotation");
    var _bar = hvs_item_define("st_bar", { shape: "3x1" });
    hvs_st_assert(_st, array_length(_bar.distinct) == 2 && _bar.rots[1].w == 1 && _bar.rots[1].h == 3, "a bar has two rotations and turns upright");
    var _T = hvs_item_define("st_T", { shape: [[0, 0], [1, 0], [2, 0], [1, 1]] });
    hvs_st_assert(_st, _T.area == 4 && _T.rots[0].w == 3 && _T.rots[0].h == 2, "a footprint from a list of cells");
    var _t41 = _L.rots[0].cells;
    // one quarter turn, by hand: (x, y) -> (h - 1 - y, x); L cells (0,0)(1,0)(0,1)(0,2) in a 2x3 box -> (2,0)(2,1)(1,0)(0,0)
    var _r1k = hvs__cells_key(_L.rots[1].cells);
    hvs_st_assert(_st, _r1k == "0,0;1,0;2,0;2,1;", "the L's quarter turn is right by hand: " + _r1k);
    var _forms = hvs_forms(), _nf = array_length(_forms);
    hvs_starter_items();
    _st.notes.forms = _nf;
    hvs_st_assert(_st, _nf >= 48, "at least 48 drawn items (" + string(_nf) + ")");
    for (var _i = 0; _i < _nf; _i++) {
        var _df = hvs_item_def(_forms[_i].form);
        hvs_st_assert(_st, !is_undefined(_df), _forms[_i].form + ": registered");
        var _a0 = hvs__cells_key(_df.rots[0].cells), _bad = false;
        for (var _r = 0; _r < 4; _r++) if (array_length(_df.rots[_r].cells) != _df.area) _bad = true;
        // four quarter turns are the identity
        var _cur = _df.rots[0].cells, _hh = _df.rots[0].h;
        repeat (4) { _cur = hvs__rotate_cells(_cur, _hh); var _mr = hvs__make_rot(_cur); _hh = _mr.h; }
        hvs_st_assert(_st, !_bad && hvs__cells_key(_cur) == _a0, _forms[_i].form + ": four quarter turns come home, the area kept");
    }

    // ------------------------------------------------------------ 30: containers and every refusal
    hvs_st_stage(_st, 30);
    var _c = hvs_container({ w: 6, h: 4 });
    var _it = hvs_item("st_L");
    hvs_st_assert(_st, hvs_why(_c, _it, 0, 0) == "ok", "an L fits an empty case");
    hvs_st_assert(_st, hvs_why(_c, _it, 5, 0) == "bounds", "off the right edge: bounds");
    hvs_st_assert(_st, hvs_why(_c, _it, 0, 3) == "bounds", "off the bottom: bounds");
    hvs_st_assert(_st, hvs_why(_c, _it, -1, 0) == "bounds", "negative: bounds");
    hvs_st_assert(_st, hvs_why(_c, undefined, 0, 0) == "bad" && hvs_why(undefined, _it, 0, 0) == "bad" && hvs_why(_c, _it, "a", 0) == "bad", "nonsense: bad, no throw");
    hvs_st_assert(_st, hvs_put(_c, _it, 1, 1, 0), "the L goes in");
    hvs_st_assert(_st, hvs__st_consistent(_c) == "", "grid and list agree: " + hvs__st_consistent(_c));
    hvs_st_assert(_st, hvs_at(_c, 1, 1) == _it && hvs_at(_c, 2, 1) == _it && hvs_at(_c, 1, 3) == _it && is_undefined(hvs_at(_c, 2, 2)), "the L covers its own cells and not its notch");
    var _o = hvs_item("st_sq");
    hvs_st_assert(_st, hvs_why(_c, _o, 2, 1) == "occupied", "over the L's arm: occupied");
    hvs_st_assert(_st, hvs_why(_c, _o, 3, 1) == "ok", "beside it: ok");
    var _sing = hvs_item_define("st_one", { shape: "1x1" }), _o1 = hvs_item("st_one");
    hvs_st_assert(_st, hvs_put(_c, _o1, 2, 2), "a 1 x 1 slips into the L's notch: footprints are real, not boxes");
    // atomic: a refused move moves nothing
    var _bx = _it.x, _by = _it.y, _brev = _c.rev;
    hvs_st_assert(_st, !hvs_put(_c, _it, 2, 2, 0) && _it.x == _bx && _it.y == _by && _c.rev == _brev && hvs_at(_c, 1, 1) == _it, "a refused put moves nothing and changes nothing");
    // turning in place: own cells count as free
    hvs_st_assert(_st, hvs_why(_c, _it, _it.x, _it.y, 0) == "ok", "an item does not block itself");
    // masks
    var _cm = hvs_container({ w: 4, h: 3, mask: ["XXXX", "X.XX", "XXXX"] });
    hvs_st_assert(_st, !hvs_cell_open(_cm, 1, 1) && hvs_cell_open(_cm, 0, 0), "a mask closes its cell");
    var _sq2 = hvs_item("st_sq");
    hvs_st_assert(_st, hvs_why(_cm, _sq2, 0, 0) == "masked" && hvs_why(_cm, _sq2, 2, 0) == "ok", "masked cells refuse: masked");
    // dividers: a 2-wide item may not straddle one; a footprint that merely has a notch at the wall may stand across if no two of its touching cells are split
    var _cd = hvs_container({ w: 6, h: 2, dividers: [["v", 3, 0, 2]] });
    var _bar3 = hvs_item("st_bar");
    hvs_st_assert(_st, hvs_why(_cd, _bar3, 1, 0, 0) == "divider", "a bar across a divider: divider");
    hvs_st_assert(_st, hvs_why(_cd, _bar3, 0, 0, 0) == "ok" && hvs_why(_cd, _bar3, 3, 0, 0) == "ok", "the same bar either side: ok");
    hvs_st_assert(_st, hvs_why(_cd, _bar3, 2, 0, 1) == "bounds", "a turned bar does not fit two rows");
    var _cdh = hvs_container({ w: 3, h: 4, dividers: [["h", 2, 0, 3]] }), _vb = hvs_item("st_bar");
    hvs_st_assert(_st, hvs_why(_cdh, _vb, 0, 0, 1) == "divider" && hvs_why(_cdh, _vb, 0, 1, 1) == "divider", "a horizontal divider stops a turned bar");
    hvs_st_assert(_st, !hvs_divider_add(_cd, ["v", 0, 0, 2]) && !hvs_divider_add(_cd, ["q", 1, 0, 2]) && !hvs_divider_add(undefined, ["v", 1, 0, 2]), "a nonsense divider is refused");
    // acceptance
    var _ca = hvs_container({ w: 4, h: 4, accept: function(_i2, _c2) { return _i2.id == "st_one"; } });
    hvs_st_assert(_st, hvs_why(_ca, hvs_item("st_sq"), 0, 0) == "refused" && hvs_why(_ca, hvs_item("st_one"), 0, 0) == "ok", "an accept function refuses: refused");
    // string() of an item must not hang on its cycle (item -> home -> items -> item)
    var _sdbg = string(_it);
    hvs_st_assert(_st, string_length(_sdbg) > 0, "string() of a placed item returns");

    // ------------------------------------------------------------ 40: stacks, weight and nesting
    hvs_st_stage(_st, 40);
    hvs_item_define("st_coin", { shape: "1x1", stack: 10, weight: 0.5 });
    var _cs = hvs_container({ w: 3, h: 2 }), _a1 = hvs_item("st_coin", 7), _a2 = hvs_item("st_coin", 7);
    hvs_st_assert(_st, hvs_add(_cs, _a1), "a stack goes in");
    hvs_st_assert(_st, hvs_add(_cs, _a2) && array_length(_cs.items) == 2 && hvs_count(_cs, "st_coin") == 14, "7 + 7 tops one up to 10 and keeps 4: " + string(hvs_count(_cs, "st_coin")));
    hvs_st_assert(_st, _cs.items[0].count == 10 && _cs.items[1].count == 4, "the first stack is full");
    var _sp = hvs_split(_cs.items[0], 3);
    hvs_st_assert(_st, !is_undefined(_sp) && _sp.count == 3 && _cs.items[0].count == 7 && is_undefined(_sp.home), "a split takes some off, homeless");
    hvs_st_assert(_st, is_undefined(hvs_split(_cs.items[0], 7)) && is_undefined(hvs_split(_cs.items[0], 0)), "a split of all or none is refused");
    hvs_st_assert(_st, hvs_merge(_cs.items[1], _sp) == 0 && _cs.items[1].count == 7, "the split stack pours back");
    hvs_st_assert(_st, hvs_count(_cs, "st_coin") == 14, "nothing lost");
    hvs_st_assert(_st, !hvs_consume(_cs, "st_coin", 99) && hvs_count(_cs, "st_coin") == 14, "consume is all or nothing");
    hvs_st_assert(_st, hvs_consume(_cs, "st_coin", 9) && hvs_count(_cs, "st_coin") == 5, "consume takes across stacks");
    hvs_st_assert(_st, abs(hvs_weight(_cs) - 2.5) < 0.001, "weight follows the stacks: " + string(hvs_weight(_cs)));
    hvs_st_assert(_st, hvs__st_consistent(_cs) == "", "still consistent: " + hvs__st_consistent(_cs));
    // limits
    hvs_item_define("st_lump", { shape: "1x1", weight: 6 });
    var _cl = hvs_container({ w: 4, h: 4, limit: 10 });
    hvs_st_assert(_st, hvs_put(_cl, hvs_item("st_lump"), 0, 0), "under the limit");
    hvs_st_assert(_st, hvs_why(_cl, hvs_item("st_lump"), 1, 0) == "weight", "over the limit: weight");
    // nesting
    hvs_item_define("st_bag", { shape: "2x2", weight: 1, holds: { w: 3, h: 3, limit: 7 } });
    var _root = hvs_container({ w: 6, h: 6, limit: 12 }), _bag = hvs_item("st_bag"), _bag2 = hvs_item("st_bag");
    hvs_st_assert(_st, hvs__is_case(_bag.inside) && _bag.inside.owner == _bag, "a bag holds a container");
    hvs_st_assert(_st, hvs_put(_root, _bag, 0, 0), "the bag goes in the case");
    hvs_st_assert(_st, hvs_put(_bag.inside, hvs_item("st_lump"), 0, 0), "a lump goes in the bag");
    hvs_st_assert(_st, abs(hvs_weight(_root) - 7) < 0.001, "weight rises through the nesting: " + string(hvs_weight(_root)));
    hvs_st_assert(_st, hvs_count(_root, "st_lump") == 1 && hvs_find(_root, "st_lump").home == _bag.inside, "count and find reach inside");
    hvs_st_assert(_st, hvs_why(_bag.inside, hvs_item("st_lump"), 1, 0) == "weight", "the bag's own limit binds");
    hvs_st_assert(_st, hvs_why(_bag.inside, _bag, 0, 0) == "self", "a bag cannot go inside itself");
    hvs_st_assert(_st, hvs_put(_bag.inside, _bag2, 1, 1), "a bag fits inside a bag");
    hvs_st_assert(_st, hvs_why(_bag2.inside, _bag, 0, 0) == "self", "nor inside anything inside itself");
    // a limit in the outer case binds what goes in the inner bag
    hvs_item_define("st_small", { shape: "1x1", weight: 5.5 });
    hvs_st_assert(_st, hvs_why(_bag2.inside, hvs_item("st_small"), 0, 0) == "weight", "the outer case's limit binds inside a nested bag");

    // ------------------------------------------------------------ 50: tidy never loses an item
    hvs_st_stage(_st, 50);
    var _ids = ["st_L", "st_sq", "st_bar", "st_T", "st_one", "st_coin"], _bad = 0, _worse = 0, _moved = 0, _nodes = 0, _fills = 0, _maxItems = 0;
    var _t0 = get_timer(), _worst = 0;
    for (var _s = 0; _s < 60; _s++) {
        var _g = hvs_rng(9000 + _s), _w = 5 + floor(hvs_rand(_g) * 6), _h = 4 + floor(hvs_rand(_g) * 5);
        var _ct = hvs_container({ w: _w, h: _h }), _before = [];
        repeat (_w * _h) {
            var _pick = _ids[floor(hvs_rand(_g) * array_length(_ids))], _x = floor(hvs_rand(_g) * _w), _y = floor(hvs_rand(_g) * _h), _rr = floor(hvs_rand(_g) * 4), _ni = hvs_item(_pick, 1 + floor(hvs_rand(_g) * 3));
            hvs_put(_ct, _ni, _x, _y, _rr);
        }
        for (var _q = 0; _q < array_length(_ct.items); _q++) array_push(_before, _ct.items[_q]);
        var _total = hvs_count(_ct, "st_coin"), _lf = hvs__largest_free(_ct);
        _maxItems = max(_maxItems, array_length(_ct.items));
        var _t1 = get_timer(), _res = hvs_tidy(_ct);
        _worst = max(_worst, get_timer() - _t1);
        _fills++; _nodes += _res.nodes; _moved += _res.moved;
        var _lost = false;
        for (var _q = 0; _q < array_length(_before); _q++) if (_before[_q].count > 0 && _before[_q].home != _ct) _lost = true;
        if (_lost || hvs_count(_ct, "st_coin") != _total || hvs__st_consistent(_ct) != "") _bad++;
        if (hvs__largest_free(_ct) < _lf) _worse++;
    }
    hvs_st_assert(_st, _bad == 0, "over 60 random fills tidy lost nothing and the grid stayed consistent (" + string(_bad) + " bad)");
    hvs_st_assert(_st, _worse == 0, "tidy never made the largest free space smaller (" + string(_worse) + " worse)");
    hvs_st_assert(_st, _moved > 40, "and the fills were real work: " + string(_moved) + " items moved");
    _st.notes.tidyMoved = _moved; _st.notes.tidyFills = _fills; _st.notes.tidyMaxItems = _maxItems; _st.timings.tidyWorstMs = _worst / 1000; _st.notes.tidyNodes = _nodes;
    // a fixture the first-fit pass CANNOT pack, which the search can. Control first: first-fit really does fail on it.
    hvs_item_define("st_I4", { shape: "1x4", rotates: false });
    hvs_item_define("st_I3", { shape: "1x3", rotates: false });
    hvs_item_define("st_h2", { shape: "2x1", rotates: false });
    var _hf = hvs_container({ w: 3, h: 4 });
    hvs_put(_hf, hvs_item("st_I4"), 2, 0); hvs_put(_hf, hvs_item("st_I3"), 0, 1); hvs_put(_hf, hvs_item("st_I3"), 1, 1); hvs_put(_hf, hvs_item("st_h2"), 0, 0);
    hvs_st_assert(_st, array_length(_hf.items) == 4 && hvs_used(_hf).free == 0, "the fixture is full: " + string(hvs_used(_hf).free) + " free");
    var _rh = hvs_tidy(_hf);
    hvs_st_assert(_st, _rh.ok && array_length(_hf.items) == 4 && hvs__st_consistent(_hf) == "", "a full case survives a tidy");
    // and a budget of one: nothing moves, nothing lost
    var _hb = hvs_container({ w: 3, h: 4 });
    hvs_put(_hb, hvs_item("st_h2"), 1, 0); hvs_put(_hb, hvs_item("st_I4"), 0, 0); hvs_put(_hb, hvs_item("st_I3"), 1, 1); hvs_put(_hb, hvs_item("st_I3"), 2, 1);
    var _rb = hvs_tidy(_hb, { budget: 1 });
    hvs_st_assert(_st, array_length(_hb.items) == 4 && hvs__st_consistent(_hb) == "", "a tidy out of budget keeps every item");
    // dividers bind a tidy
    var _cdv = hvs_container({ w: 6, h: 2, dividers: [["v", 3, 0, 2]] });
    hvs_put(_cdv, hvs_item("st_bar"), 0, 1, 0); hvs_put(_cdv, hvs_item("st_bar"), 3, 0, 0); hvs_put(_cdv, hvs_item("st_one"), 5, 1);
    var _rd = hvs_tidy(_cdv);
    hvs_st_assert(_st, hvs__st_consistent(_cdv) == "" && array_length(_cdv.items) == 3, "tidy respects dividers: consistent");
    var _straddle = false;
    for (var _q = 0; _q < array_length(_cdv.items); _q++) { var _ii = _cdv.items[_q]; if (_ii.id == "st_bar" && _ii.rot == 0 && _ii.x < 3 && _ii.x + 3 > 3) _straddle = true; }
    hvs_st_assert(_st, !_straddle, "no bar stands across the divider after a tidy");
    // a key function: heaviest first
    var _ck = hvs_container({ w: 4, h: 1 });
    hvs_put(_ck, hvs_item("st_one"), 0, 0); hvs_put(_ck, hvs_item("st_lump"), 3, 0);
    hvs_tidy(_ck, { key: function(_i3) { return _i3.def.weight; } });
    hvs_st_assert(_st, _ck.items[0].id == "st_lump" && _ck.items[0].x == 0, "a key function sets the order");
    // merge in a tidy, and undefined data only
    var _cm2 = hvs_container({ w: 4, h: 1 });
    hvs_put(_cm2, hvs_item("st_coin", 3), 0, 0); hvs_put(_cm2, hvs_item("st_coin", 4), 2, 0); hvs_put(_cm2, hvs_item("st_coin", 2, { worn: true }), 3, 0);
    hvs_tidy(_cm2);
    hvs_st_assert(_st, array_length(_cm2.items) == 2 && hvs_count(_cm2, "st_coin") == 9, "tidy merges stacks, and an item with data stays itself: " + string(array_length(_cm2.items)));

    // ------------------------------------------------------------ 60: save and load
    hvs_st_stage(_st, 60);
    var _cs0 = hvs_container({ w: 8, h: 6, kind: "footlocker", material: "oak", seed: 5, wear: 0.2, limit: 40, dividers: [["v", 5, 0, 6]], mask: ["XXXXXXXX", "XXXXXXXX", "XXXXXXXX", "XXXXXXXX", "XXXXXXXX", ".XXXXXX."], name: "Trunk" });
    var _is1 = hvs_item("st_L", 1, { serial: 77 }), _is2 = hvs_item("st_coin", 6), _is3 = hvs_item("st_bag");
    hvs_put(_cs0, _is1, 0, 0, 1); hvs_put(_cs0, _is2, 7, 0); hvs_put(_cs0, _is3, 5, 2);
    hvs_put(_is3.inside, hvs_item("st_bar"), 0, 1, 0);
    var _str = hvs_save_string(_cs0), _rep = {}, _cl2 = hvs_load_string(_str, _rep);
    hvs_st_assert(_st, is_string(_str) && string_length(_str) > 40 && !is_undefined(_cl2), "a container round-trips as a string");
    hvs_st_assert(_st, _cl2.w == 8 && _cl2.h == 6 && _cl2.kind == "footlocker" && _cl2.material == "oak" && _cl2.limit == 40 && array_length(_cl2.dividers) == 1 && !hvs_cell_open(_cl2, 0, 5), "its shape, mask, divider and limit return");
    var _ls1 = hvs_find(_cl2, "st_L"), _ls2 = hvs_find(_cl2, "st_coin"), _ls3 = hvs_find(_cl2, "st_bag");
    hvs_st_assert(_st, _ls1.rot == 1 && _ls1.x == 0 && _ls1.y == 0 && _ls1.data.serial == 77, "rotation, position and your data return");
    hvs_st_assert(_st, _ls2.count == 6 && _ls2.x == 7, "the stack returns");
    hvs_st_assert(_st, hvs_count(_ls3.inside, "st_bar") == 1 && hvs_find(_ls3.inside, "st_bar").y == 1 && _ls3.inside.owner == _ls3, "nesting returns");
    hvs_st_assert(_st, array_length(_rep.moved) == 0 && array_length(_rep.overflow) == 0 && array_length(_rep.unknown) == 0, "a clean load reports nothing");
    hvs_st_assert(_st, hvs__st_consistent(_cl2) == "", "consistent after load");
    hvs_st_assert(_st, is_undefined(hvs_load_string("this is not json")) && is_undefined(hvs_load_string("")) && is_undefined(hvs_load_string(12)) && is_undefined(hvs_load_struct({ a: 1 })), "garbage loads as undefined, no throw");
    // your definitions changed since the save: a longer footprint finds other room; one that cannot fit comes back; a removed id is kept
    hvs_item_define("st_grow", { shape: "2x1", stack: 3 });
    hvs_item_define("st_gone", { shape: "1x1" });
    var _cg = hvs_container({ w: 3, h: 2 });
    hvs_put(_cg, hvs_item("st_grow", 3), 0, 0, 0); hvs_put(_cg, hvs_item("st_gone"), 2, 0); hvs_put(_cg, hvs_item("st_one"), 0, 1);
    var _sg = hvs_save_string(_cg);
    hvs_item_define("st_grow", { shape: "3x1", stack: 2 }); // longer, and it stacks less
    variable_struct_remove(global.hvs__reg, "st_gone");
    var _rg = {}, _cg2 = hvs_load_string(_sg, _rg);
    hvs_st_assert(_st, array_length(_rg.unknown) == 1 && _rg.unknown[0] == "st_gone", "a removed id is reported");
    var _gtotal = hvs_count(_cg2, "st_grow");
    for (var _q = 0; _q < array_length(_rg.overflow); _q++) _gtotal += _rg.overflow[_q].count;
    hvs_st_assert(_st, _gtotal == 3, "a stack size that shrank loses nothing: placed + overflow = " + string(_gtotal));
    hvs_st_assert(_st, array_length(_rg.overflow) >= 1 && hvs_count(_cg2, "st_one") == 1, "what no longer fits comes back in report.overflow");
    hvs_st_assert(_st, hvs__st_consistent(_cg2) == "", "consistent after a changed-definition load");
    var _sg2 = hvs_save_string(_cg2);
    hvs_st_assert(_st, string_pos("st_gone", _sg2) > 0, "a removed id is written back by the next save, so restoring the definition restores the item");
    hvs_item_define("st_gone", { shape: "1x1" });
    var _cg3 = hvs_load_string(_sg2);
    hvs_st_assert(_st, hvs_count(_cg3, "st_gone") == 1, "and it does");

    // ------------------------------------------------------------ 70: the hand, with no device attached
    hvs_st_stage(_st, 70);
    var _ev = { log: [], last: "" };
    var _dk = hvs_desk_create({ on_event: method(_ev, function(_w2, _i4, _p4) { array_push(log, _w2); last = _w2; }) });
    var _cA = hvs_container({ w: 8, h: 5, kind: "attache", material: "hide" }), _cB = hvs_container({ w: 5, h: 5, kind: "crate", material: "oak" });
    var _pA = hvs_desk_add(_dk, _cA, 40, 40, { cell: 40 }), _pB = hvs_desk_add(_dk, _cB, 500, 40, { cell: 40 });
    hvs_st_assert(_st, is_struct(_pA) && _pA.gx > _pA.x && _pA.gy > _pA.y, "the pane sits inside the drawn case");
    var _rifle = hvs_item("rifle"), _pist = hvs_item("pistol"), _blk = hvs_item("st_sq");
    hvs_put(_cA, _rifle, 0, 0, 0); hvs_put(_cA, _pist, 0, 3, 0); hvs_put(_cB, _blk, 0, 0, 0);
    // lift by a cell of the pistol
    var _m0 = hvs__st_centre(_pA, 0, 4);
    hvs__st_feed(_dk, _m0[0], _m0[1]);
    hvs__st_feed(_dk, _m0[0], _m0[1], { press: true });
    hvs_st_assert(_st, hvs_desk_held(_dk) == _pist && _dk.hold.grabx == 0 && _dk.hold.graby == 1, "a press lifts the pistol by the cell under the pointer");
    hvs_st_assert(_st, _pist.home == _cA && hvs_at(_cA, 0, 4) == _pist, "while held it is still in its case, so a save mid-drag restores it");
    var _smid = hvs_load_string(hvs_save_string(_cA));
    hvs_st_assert(_st, hvs_count(_smid, "pistol") == 1 && hvs_find(_smid, "pistol").y == 3, "a save taken mid-drag has the pistol where it was");
    // a drag past the threshold and a release over a legal place: drop
    var _m1 = hvs__st_centre(_pA, 5, 3);
    repeat (4) hvs__st_feed(_dk, _m1[0], _m1[1]);
    hvs_st_assert(_st, _dk.target.why == "ok" && _dk.target.pane == _pA, "the ghost reads ok over free cells");
    hvs__st_feed(_dk, _m1[0], _m1[1], { release: true });
    hvs_st_assert(_st, is_undefined(hvs_desk_held(_dk)) && _pist.x == 5 && _pist.y == 2 && hvs__st_consistent(_cA) == "", "the release drops it, the grabbed cell under the pointer: " + string(_pist.x) + "," + string(_pist.y));
    hvs__st_settle(_dk);
    // the bought reviews, one by one
    // 1. "overlaps another item ... falls to the ground instead of snapping back": it springs back, to the cell and the rotation it was lifted with
    var _m2 = hvs__st_centre(_pA, 2, 0);
    hvs__st_feed(_dk, _m2[0], _m2[1]); hvs__st_feed(_dk, _m2[0], _m2[1], { press: true });
    hvs_st_assert(_st, hvs_desk_held(_dk) == _rifle, "the rifle lifts");
    var _m3 = hvs__st_centre(_pB, 1, 1);
    hvs__st_feed(_dk, _m3[0] + 3, _m3[1], {}); hvs__st_feed(_dk, _m3[0] + 3, _m3[1], { rotate: true });
    hvs_st_assert(_st, _dk.hold.rot != 0, "it turns in the hand");
    repeat (3) hvs__st_feed(_dk, _m3[0] + 3, _m3[1], {});
    var _whyB = _dk.target.why;
    hvs_st_assert(_st, _whyB != "ok", "over the other case and the block: refused (" + _whyB + ")");
    hvs__st_feed(_dk, _m3[0] + 3, _m3[1], { release: true });
    hvs_st_assert(_st, is_undefined(hvs_desk_held(_dk)) && _rifle.home == _cA && _rifle.x == 0 && _rifle.y == 0 && _rifle.rot == 0 && hvs__st_consistent(_cA) == "" && hvs__st_consistent(_cB) == "", "a refused drop puts it back at the same cell and rotation");
    hvs_st_assert(_st, array_length(_dk.flights) > 0 && _ev.last == "snapback", "and you see it fly back: event " + _ev.last);
    hvs__st_settle(_dk);
    // 2. rotation of any footprint, the grabbed cell staying under the pointer ("the items do not rotate properly")
    var _lIt = hvs_item("axe");
    hvs_put(_cA, _lIt, 0, 2, 0);
    var _ml = hvs__st_centre(_pA, 1, 2);
    hvs__st_feed(_dk, _ml[0], _ml[1]); hvs__st_feed(_dk, _ml[0], _ml[1], { press: true });
    hvs_st_assert(_st, _dk.hold.grabx == 1 && _dk.hold.graby == 0, "the axe is grabbed by its head");
    for (var _q = 0; _q < 4; _q++) {
        hvs__st_feed(_dk, _ml[0], _ml[1], { rotate: true });
        var _hd = _dk.hold, _rb2 = _lIt.def.rots[_hd.rot], _on = false;
        for (var _z = 0; _z < array_length(_rb2.cells); _z++) if (_rb2.cells[_z][0] == _hd.grabx && _rb2.cells[_z][1] == _hd.graby) _on = true;
        hvs_st_assert(_st, _on, "turn " + string(_q) + ": the grabbed cell is on the footprint: " + string(_hd.grabx) + "," + string(_hd.graby));
    }
    hvs_st_assert(_st, _dk.hold.rot == 0 && _dk.hold.grabx == 1 && _dk.hold.graby == 0, "four turns bring the grab home");
    hvs__st_feed(_dk, _ml[0], _ml[1], { rotate: true });
    var _rb3 = _dk.hold.rot;
    hvs_desk_cancel(_dk);
    hvs_st_assert(_st, is_undefined(hvs_desk_held(_dk)) && _lIt.rot == 0, "cancel gives it back unturned");
    hvs__st_settle(_dk);
    // a bar's two rotations look like one turn, not three
    var _lb4 = hvs_item("knife"), _kc = hvs_container({ w: 4, h: 4 }), _dkk = hvs_desk_create(), _pk = hvs_desk_add(_dkk, _kc, 0, 0, { cell: 20, draw_case: false });
    hvs_put(_kc, _lb4, 1, 1, 0);
    var _mk = hvs__st_centre(_pk, 1, 1);
    hvs__st_feed(_dkk, _mk[0], _mk[1]); hvs__st_feed(_dkk, _mk[0], _mk[1], { press: true });
    hvs__st_feed(_dkk, _mk[0], _mk[1], { rotate: true });
    hvs_st_assert(_st, _dkk.hold.rot == 1 && _dkk.hold.ang < 0, "the first turn of a bar runs clockwise: ang " + string(_dkk.hold.ang));
    hvs__st_feed(_dkk, _mk[0], _mk[1], { rotate: true });
    hvs_st_assert(_st, _dkk.hold.rot == 0 && _dkk.hold.ang > 0, "the second turn of a bar runs back the other way: ang " + string(_dkk.hold.ang));
    hvs_desk_cancel(_dkk); hvs_desk_free(_dkk);
    // 3. a click lifts and keeps; the next click drops
    var _mc = hvs__st_centre(_pA, 5, 2);
    hvs__st_feed(_dk, _mc[0], _mc[1]); hvs__st_feed(_dk, _mc[0], _mc[1], { press: true }); hvs__st_feed(_dk, _mc[0], _mc[1], { release: true });
    hvs_st_assert(_st, hvs_desk_held(_dk) == _pist && _dk.hold.sticky, "a quick click keeps the item in hand");
    var _mc2 = hvs__st_centre(_pB, 3, 2);
    repeat (3) hvs__st_feed(_dk, _mc2[0], _mc2[1]);
    hvs__st_feed(_dk, _mc2[0], _mc2[1], { press: true });
    hvs_st_assert(_st, _pist.home == _cB && is_undefined(hvs_desk_held(_dk)), "the next click drops it, in the OTHER case");
    hvs_st_assert(_st, array_get_index(_cA.items, _pist) < 0 && hvs__st_consistent(_cA) == "" && hvs__st_consistent(_cB) == "", "it has left the first case");
    hvs__st_settle(_dk);
    // swap: dropped on one item, that item comes up into the hand
    var _ms = hvs__st_centre(_pB, 3, 2);
    hvs__st_feed(_dk, _ms[0], _ms[1]); hvs__st_feed(_dk, _ms[0], _ms[1], { press: true }); hvs__st_feed(_dk, _ms[0], _ms[1], { release: true });
    var _mt0 = hvs__st_centre(_pB, 0, 0);
    repeat (3) hvs__st_feed(_dk, _mt0[0], _mt0[1]);
    hvs_st_assert(_st, !is_undefined(_dk.target.swap) && _dk.target.swap == _blk, "over one item: the ghost offers a swap");
    hvs__st_feed(_dk, _mt0[0], _mt0[1], { press: true });
    hvs_st_assert(_st, hvs_desk_held(_dk) == _blk && _pist.home == _cB && _pist.x == 0 && _pist.y == 0 && is_undefined(_blk.home), "the swap lands the pistol and lifts the block: " + _ev.last);
    hvs_st_assert(_st, hvs__st_consistent(_cB) == "", "consistent after a swap");
    hvs_desk_cancel(_dk);
    hvs_st_assert(_st, _blk.home == _cB, "a cancelled swap's item goes back into that case");
    hvs__st_settle(_dk);
    // stacks: a stack dropped on its own kind pours in
    var _ca1 = hvs_item("shells", 4), _ca2 = hvs_item("shells", 4);
    hvs_put(_cB, _ca1, 4, 4); hvs_put(_cB, _ca2, 4, 3);
    var _msa = hvs__st_centre(_pB, 4, 3), _msb = hvs__st_centre(_pB, 4, 4);
    hvs__st_feed(_dk, _msa[0], _msa[1]); hvs__st_feed(_dk, _msa[0], _msa[1], { press: true }); hvs__st_feed(_dk, _msa[0], _msa[1], { release: true });
    repeat (3) hvs__st_feed(_dk, _msb[0], _msb[1]);
    hvs__st_feed(_dk, _msb[0], _msb[1], { press: true });
    hvs_st_assert(_st, _ca1.count == 6 && _ca2.count == 2 && _ca2.home == _cB, "a stack pours up to its limit and the rest goes home: " + string(_ca1.count) + "+" + string(_ca2.count));
    hvs__st_settle(_dk);
    // quick move
    var _qmIt = hvs_item("grenade");
    hvs_put(_cA, _qmIt, 7, 4);
    var _mq = hvs__st_centre(_pA, 7, 4);
    hvs__st_feed(_dk, _mq[0], _mq[1]); hvs__st_feed(_dk, _mq[0], _mq[1], { press: true, transfer: true });
    hvs_st_assert(_st, _qmIt.home == _cB && is_undefined(hvs_desk_held(_dk)), "shift-click moves it to the other case");
    hvs__st_settle(_dk);
    // tidy: flights for what moved
    var _ct0 = hvs_container({ w: 6, h: 3 }), _dk2 = hvs_desk_create(), _pt2 = hvs_desk_add(_dk2, _ct0, 0, 0, { cell: 24, draw_case: false });
    hvs_put(_ct0, hvs_item("st_sq"), 4, 1); hvs_put(_ct0, hvs_item("st_one"), 2, 2);
    var _rt0 = hvs_desk_tidy(_dk2, _pt2);
    hvs_st_assert(_st, _rt0.moved == 2 && array_length(_dk2.flights) == 2, "a desk tidy flies what it moved: " + string(array_length(_dk2.flights)));
    hvs_desk_free(_dk2);
    // a carried item with no home (a pickup)
    var _pk0 = hvs_item("st_one"), _dk3 = hvs_desk_create(), _cP = hvs_container({ w: 3, h: 3 }), _pP = hvs_desk_add(_dk3, _cP, 0, 0, { cell: 30, draw_case: false });
    hvs_put(_cP, hvs_item("st_sq"), 0, 0);
    hvs_st_assert(_st, hvs_desk_carry(_dk3, _pk0, 30), "a pickup comes to the hand");
    var _mp = hvs__st_centre(_pP, 0, 0);
    repeat (2) hvs__st_feed(_dk3, _mp[0] + 300, _mp[1]);
    hvs__st_feed(_dk3, _mp[0] + 300, _mp[1], { press: true });
    hvs_st_assert(_st, hvs_desk_held(_dk3) == _pk0, "a pickup dropped off the case stays in hand: nothing is lost");
    var _mp2 = hvs__st_centre(_pP, 2, 2);
    repeat (2) hvs__st_feed(_dk3, _mp2[0], _mp2[1]);
    hvs__st_feed(_dk3, _mp2[0], _mp2[1], { press: true });
    hvs_st_assert(_st, _pk0.home == _cP && _pk0.x == 2, "and it lands where there is room");
    hvs_desk_free(_dk3);
    // the wheel, and the scroll follows
    var _cT = hvs_container({ w: 3, h: 12 }), _dk4 = hvs_desk_create(), _pT = hvs_desk_add(_dk4, _cT, 0, 0, { cell: 20, rows: 4, draw_case: false });
    hvs_put(_cT, hvs_item("st_one"), 0, 10);
    hvs__st_feed(_dk4, 10, 10, { wheel: -1 });
    hvs_st_assert(_st, _pT.scroll_to == 20, "the wheel scrolls a tall container one row: " + string(_pT.scroll_to));
    repeat (40) hvs_desk_tick(_dk4);
    var _sc0 = hvs_pane_cell(_pT, 10, 10);
    hvs_st_assert(_st, _sc0.y == 1, "a screen point maps through the scroll: row " + string(_sc0.y));
    hvs__st_feed(_dk4, 10, 10, { wheel: 999 });
    hvs_st_assert(_st, _pT.scroll_to == 0, "the scroll clamps");
    hvs_desk_free(_dk4);

    // ------------------------------------------------------------ 75: the gamepad walk
    hvs_st_stage(_st, 75);
    var _cW = hvs_container({ w: 8, h: 6, mask: ["XXXXXXXX", "XXXXXXXX", "XXX.XXXX", "XXXXXXXX", "XXXXXXXX", "XXXXXX.."] }), _dkw = hvs_desk_create(), _pW = hvs_desk_add(_dkw, _cW, 0, 0, { cell: 20, draw_case: false });
    var _wl = [["axe", 0, 0, 0], ["pistol", 2, 0, 0], ["smg", 4, 0, 0], ["st_sq", 0, 3, 0], ["st_T", 2, 3, 0], ["rifle", 3, 4, 0], ["st_one", 7, 0, 0], ["st_one", 7, 3, 0]];
    for (var _q = 0; _q < array_length(_wl); _q++) hvs_put(_cW, hvs_item(_wl[_q][0]), _wl[_q][1], _wl[_q][2], _wl[_q][3]);
    var _nitems = array_length(_cW.items);
    hvs_st_assert(_st, _nitems >= 7, "the walk's fixture holds irregular items: " + string(_nitems));
    _dkw.pad_mode = true;
    // from every open cell, every direction either moves or is at a real edge, and from every item every other item is reachable
    var _stuck = 0, _reachBad = 0, _landsOnSelf = 0;
    for (var _y = 0; _y < _cW.h; _y++) for (var _x = 0; _x < _cW.w; _x++) {
        if (!hvs_cell_open(_cW, _x, _y)) continue;
        var _dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]], _moved4 = 0;
        for (var _q = 0; _q < 4; _q++) {
            _dkw.cursor.x = _x; _dkw.cursor.y = _y; _dkw.cursor.prefx = _x; _dkw.cursor.prefy = _y;
            var _from = hvs_at(_cW, _x, _y);
            if (hvs_desk_step_cursor(_dkw, _dirs[_q][0], _dirs[_q][1])) {
                _moved4++;
                var _nw = hvs_at(_cW, _dkw.cursor.x, _dkw.cursor.y);
                if (!is_undefined(_from) && _nw == _from) _landsOnSelf++;
                if (!hvs_cell_open(_cW, _dkw.cursor.x, _dkw.cursor.y)) _reachBad++;
            }
        }
        if (_moved4 == 0) _stuck++;
    }
    hvs_st_assert(_st, _stuck == 0, "no open cell is a trap: " + string(_stuck));
    hvs_st_assert(_st, _landsOnSelf == 0, "a step always leaves the footprint it was on: " + string(_landsOnSelf));
    hvs_st_assert(_st, _reachBad == 0, "the cursor never lands on a masked cell");
    // reachability: a flood over cursor states reaches every item
    var _seen = {}, _q0 = [[0, 0, 0, 0]], _steps = 0, _found = {};
    while (array_length(_q0) > 0 && _steps < 4000) {
        var _sn = array_pop(_q0), _key = string(_sn[0]) + "," + string(_sn[1]) + "," + string(_sn[2]) + "," + string(_sn[3]);
        if (!is_undefined(_seen[$ _key])) continue;
        _seen[$ _key] = true; _steps++;
        var _at = hvs_at(_cW, _sn[0], _sn[1]);
        if (!is_undefined(_at)) _found[$ string(_at.uid)] = true;
        for (var _q = 0; _q < 4; _q++) {
            _dkw.cursor.x = _sn[0]; _dkw.cursor.y = _sn[1]; _dkw.cursor.prefx = _sn[2]; _dkw.cursor.prefy = _sn[3];
            var _ddx = _q == 0 ? 1 : (_q == 1 ? -1 : 0), _ddy = _q == 2 ? 1 : (_q == 3 ? -1 : 0);
            if (hvs_desk_step_cursor(_dkw, _ddx, _ddy)) array_push(_q0, [_dkw.cursor.x, _dkw.cursor.y, _dkw.cursor.prefx, _dkw.cursor.prefy]);
        }
    }
    var _nfound = array_length(variable_struct_get_names(_found));
    hvs_st_assert(_st, _nfound == _nitems, "from the first cell the walk reaches every item: " + string(_nfound) + " of " + string(_nitems));
    _st.notes.padStates = _steps;
    // an L does not throw the cursor off its row
    var _cL = hvs_container({ w: 5, h: 3 }), _dkL = hvs_desk_create(), _pL = hvs_desk_add(_dkL, _cL, 0, 0, { cell: 20, draw_case: false });
    hvs_put(_cL, hvs_item("st_L"), 0, 0, 2);
    // st_L at rot 2 covers (1,0)(1,1)(0,2)(1,2)
    _dkL.pad_mode = true; _dkL.cursor.x = 0; _dkL.cursor.y = 2; _dkL.cursor.prefx = 0; _dkL.cursor.prefy = 2;
    hvs_desk_step_cursor(_dkL, 1, 0);
    hvs_st_assert(_st, _dkL.cursor.x == 2 && _dkL.cursor.y == 2, "walking right along a row past an L's foot keeps the row: " + string(_dkL.cursor.x) + "," + string(_dkL.cursor.y));
    hvs_desk_free(_dkL);
    // pad: lift, walk, drop, snap back, cross panes
    var _cW2 = hvs_container({ w: 4, h: 4 }), _pW2 = hvs_desk_add(_dkw, _cW2, 400, 0, { cell: 20, draw_case: false });
    _dkw.cursor.pane = _pW; _dkw.cursor.x = 7; _dkw.cursor.y = 3; _dkw.cursor.prefx = 7; _dkw.cursor.prefy = 3;
    var _one = hvs_at(_cW, 7, 3);
    hvs_desk_feed(_dkw, { pad: true, a: true });
    hvs_st_assert(_st, hvs_desk_held(_dkw) == _one, "A lifts");
    hvs_desk_feed(_dkw, { pad: true, nav_x: 1 });
    hvs_st_assert(_st, _dkw.cursor.pane == _pW2, "walking off the edge crosses to the next container, carrying it");
    hvs_desk_feed(_dkw, { pad: true, a: true });
    hvs_st_assert(_st, _one.home == _cW2 && is_undefined(hvs_desk_held(_dkw)), "A drops it across");
    hvs_desk_free(_dkw);
    // a pad on a scrolling container
    var _cS = hvs_container({ w: 2, h: 10 }), _dkS = hvs_desk_create(), _pS = hvs_desk_add(_dkS, _cS, 0, 0, { cell: 20, rows: 3, draw_case: false });
    _dkS.pad_mode = true;
    repeat (6) hvs_desk_feed(_dkS, { pad: true, nav_y: 1 });
    hvs_st_assert(_st, _dkS.cursor.y == 6 && _pS.scroll_to == 80, "the scroll follows the pad: row " + string(_dkS.cursor.y) + " scroll " + string(_pS.scroll_to));
    hvs_desk_free(_dkS);

    // ------------------------------------------------------------ 80: item art
    hvs_st_stage(_st, 80);
    var _ctl = surface_create(40, 40);
    surface_set_target(_ctl); draw_clear_alpha(c_black, 0); surface_reset_target();
    var _rc0 = hvs__st_read(_ctl), _ink0 = hvs__st_alpha_ink(_rc0, 0, 0, 40, 40);
    buffer_delete(_rc0.buf);
    surface_set_target(_ctl); draw_set_colour(c_red); draw_rectangle(5, 5, 14, 14, false); draw_set_colour(c_white); surface_reset_target();
    var _rc1 = hvs__st_read(_ctl), _ink1 = hvs__st_alpha_ink(_rc1, 0, 0, 40, 40);
    buffer_delete(_rc1.buf); surface_free(_ctl);
    hvs_st_assert(_st, _ink0 == 0 && _ink1 == 81, "control: the ink counter reads an empty surface as 0 and draw_rectangle(5, 5, 14, 14) as the 9 x 9 this runtime fills: " + string(_ink0) + ", " + string(_ink1));
    var _cell = 32, _grids = [], _names = [], _offWorst = 0, _offName = "", _edgeBad = "", _inkMin = 1, _inkName = "", _bakeUs = 0;
    for (var _i = 0; _i < _nf; _i++) {
        var _f = _forms[_i], _df = hvs_item_def(_f.form);
        var _t2 = get_timer(), _a = hvs_item_art(_f.form, 0, _cell);
        _bakeUs += get_timer() - _t2;
        var _W = _a.w + _a.pad * 2, _H = _a.h + _a.pad * 2, _sf = hvs__st_sprite_surface(_a.spr, _W, _H, _W * 0.5, _H * 0.5), _rd2 = hvs__st_read(_sf);
        var _tot = hvs__st_alpha_ink(_rd2, 0, 0, _W, _H);
        // the density floor: an object fills a fair part of its own footprint
        var _dens = _tot / (_df.area * _cell * _cell);
        if (_dens < _inkMin) { _inkMin = _dens; _inkName = _f.form; }
        hvs_st_assert(_st, _dens > 0.14, _f.form + ": ink covers its footprint, not a stray pixel: " + string_format(_dens, 1, 2));
        // it stays on its cells: ink over the cells it does NOT own, beyond its outline's reach
        var _off = 0, _rt = _df.rots[0], _mg = 3;
        for (var _gy = 0; _gy < _rt.h; _gy++) for (var _gx = 0; _gx < _rt.w; _gx++) {
            if (_rt.map[_gy * _rt.w + _gx]) continue;
            _off += hvs__st_alpha_ink(_rd2, _a.pad + _gx * _cell + _mg, _a.pad + _gy * _cell + _mg, _a.pad + (_gx + 1) * _cell - _mg, _a.pad + (_gy + 1) * _cell - _mg);
        }
        var _offf = _off / (_cell * _cell);
        if (_offf > _offWorst) { _offWorst = _offf; _offName = _f.form; }
        hvs_st_assert(_st, _offf < 0.04, _f.form + ": its art stays on its footprint (" + string_format(_offf, 1, 3) + " of a cell spills)");
        // and no ink reaches the sprite's edge: the bake box holds the whole object
        var _edge = hvs__st_alpha_ink(_rd2, 0, 0, _W, 1) + hvs__st_alpha_ink(_rd2, 0, _H - 1, _W, _H) + hvs__st_alpha_ink(_rd2, 0, 0, 1, _H) + hvs__st_alpha_ink(_rd2, _W - 1, 0, _W, _H);
        if (_edge > 0 && _edgeBad == "") _edgeBad = _f.form + " " + string(_edge);
        array_push(_grids, hvs__st_grid(_rd2, 8, 8)); array_push(_names, _f.form);
        buffer_delete(_rd2.buf); surface_free(_sf);
    }
    hvs_st_assert(_st, _edgeBad == "", "no form touches its sprite's edge: " + _edgeBad);
    _st.notes.formInkMin = _inkMin; _st.notes.formInkMinName = _inkName; _st.notes.formSpillWorst = _offWorst; _st.notes.formSpillName = _offName; _st.timings.itemBakeMsEach = _bakeUs / 1000 / _nf;
    // every pair apart: forms on the same footprint are the ones that could collide
    var _minD = infinity, _minPair = "", _pairs = 0, _hist = array_create(12, 0);
    for (var _i = 0; _i < _nf; _i++) for (var _j = _i + 1; _j < _nf; _j++) {
        if (hvs_item_def(_names[_i]).sig != hvs_item_def(_names[_j]).sig) continue;
        var _dd = hvs__st_diff(_grids[_i], _grids[_j]);
        _pairs++; _hist[min(11, floor(_dd / 3))] += 1;
        if (_dd < _minD) { _minD = _dd; _minPair = _names[_i] + "/" + _names[_j]; }
    }
    _st.notes.formPairs = _pairs; _st.notes.formMinD = _minD; _st.notes.formMinPair = _minPair; _st.notes.formHist = _hist;
    hvs_st_assert(_st, _pairs > 100, "same-footprint pairs are compared: " + string(_pairs));
    hvs_st_assert(_st, _minD > 3, "every same-footprint pair of forms is plainly apart: " + _minPair + " at " + string_format(_minD, 1, 1));
    // rotation: the footprint turns, the picture has the same ink, and the lamp stays upper left (the top-left rim is brighter than the bottom-right rim, at every rotation)
    var _rk = ["rifle", "axe", "pistol"];
    for (var _i = 0; _i < 3; _i++) {
        var _ink4 = array_create(4, 0);
        for (var _r = 0; _r < 4; _r++) {
            var _a = hvs_item_art(_rk[_i], _r, _cell), _W = _a.w + _a.pad * 2, _H = _a.h + _a.pad * 2, _rt = hvs_item_def(_rk[_i]).rots[_r];
            hvs_st_assert(_st, _a.w == _rt.w * _cell && _a.h == _rt.h * _cell, _rk[_i] + " rot " + string(_r) + ": the picture's box is the footprint's");
            var _sf = hvs__st_sprite_surface(_a.spr, _W, _H, _W * 0.5, _H * 0.5), _rd2 = hvs__st_read(_sf);
            _ink4[_r] = hvs__st_alpha_ink(_rd2, 0, 0, _W, _H);
            buffer_delete(_rd2.buf); surface_free(_sf);
        }
        var _mn = min(_ink4[0], _ink4[1], _ink4[2], _ink4[3]), _mx = max(_ink4[0], _ink4[1], _ink4[2], _ink4[3]);
        hvs_st_assert(_st, _mn > 0 && _mx / _mn < 1.08, _rk[_i] + ": the same ink at all four rotations: " + string(_mn) + ".." + string(_mx));
    }
    // a buyer's sprite goes through the same bake, and an item with no art at all still draws
    hvs_item_define("st_noart", { shape: ["XX", "X."] });
    var _an = hvs_item_art("st_noart", 0, _cell), _sfn = hvs__st_sprite_surface(_an.spr, _an.w + _an.pad * 2, _an.h + _an.pad * 2, (_an.w + _an.pad * 2) * 0.5, (_an.h + _an.pad * 2) * 0.5), _rdn = hvs__st_read(_sfn);
    hvs_st_assert(_st, hvs__st_alpha_ink(_rdn, 0, 0, _an.w + _an.pad * 2, _an.h + _an.pad * 2) > 3 * _cell * _cell * 0.5, "an item with no form draws as a parcel of its own footprint");
    buffer_delete(_rdn.buf); surface_free(_sfn);
    // premultiplied data has no channel above its alpha: read straight off the baked bytes. Control first: a half-transparent white clear plainly breaks the rule.
    var _pc = surface_create(8, 8);
    surface_set_target(_pc); draw_clear_alpha(c_white, 0.5); surface_reset_target();
    var _rpc = hvs__st_read(_pc), _pcr = buffer_peek(_rpc.buf, 0, buffer_u8), _pca = buffer_peek(_rpc.buf, 3, buffer_u8);
    buffer_delete(_rpc.buf); surface_free(_pc);
    hvs_st_assert(_st, _pcr > _pca + 40, "control: straight alpha reads with its colour above its alpha: " + string(_pcr) + " over " + string(_pca));
    var _pa0 = hvs_item_art("pistol", 0, _cell), _pw = _pa0.w + _pa0.pad * 2, _ph = _pa0.h + _pa0.pad * 2, _psf = hvs__st_sprite_surface(_pa0.spr, _pw, _ph, _pw * 0.5, _ph * 0.5), _prd = hvs__st_read(_psf), _worstp = 0, _edgeN = 0;
    for (var _y = 0; _y < _ph; _y++) for (var _x = 0; _x < _pw; _x++) {
        var _ppa = (_y * _pw + _x) * 4, _aa = buffer_peek(_prd.buf, _ppa + 3, buffer_u8);
        if (_aa > 0 && _aa < 255) _edgeN++;
        _worstp = max(_worstp, buffer_peek(_prd.buf, _ppa, buffer_u8) - _aa, buffer_peek(_prd.buf, _ppa + 1, buffer_u8) - _aa, buffer_peek(_prd.buf, _ppa + 2, buffer_u8) - _aa);
    }
    buffer_delete(_prd.buf); surface_free(_psf);
    hvs_st_assert(_st, _edgeN > 20, "the fixture has soft edge pixels to test: " + string(_edgeN));
    hvs_st_assert(_st, _worstp <= 3, "a baked item is premultiplied: no channel above its alpha (worst " + string(_worstp) + ")");
    // state handed back
    draw_set_alpha(0.7); draw_set_colour(c_lime);
    hvs_item_art("fish", 3, 26);
    hvs_st_assert(_st, abs(draw_get_alpha() - 0.7) < 0.01 && draw_get_colour() == c_lime, "a bake hands back the draw colour and alpha");
    draw_set_alpha(1); draw_set_colour(c_white);
    // a bake under a caller's matrix gives the same picture and hands the matrix back
    var _mkeep = matrix_get(matrix_world), _ms2 = matrix_build(30, 10, 0, 0, 0, 0, 2, 2, 1);
    matrix_set(matrix_world, _ms2);
    var _au = hvs_item_art("gem", 2, 27), _mnow = matrix_get(matrix_world);
    matrix_set(matrix_world, _mkeep);
    hvs_st_assert(_st, abs(_mnow[0] - 2) < 0.001 && abs(_mnow[12] - 30) < 0.001, "the caller's matrix comes back from a bake");
    var _sfu = hvs__st_sprite_surface(_au.spr, _au.w + _au.pad * 2, _au.h + _au.pad * 2, (_au.w + _au.pad * 2) * 0.5, (_au.h + _au.pad * 2) * 0.5), _rdu = hvs__st_read(_sfu);
    hvs_st_assert(_st, hvs__st_alpha_ink(_rdu, 0, 0, _au.w + _au.pad * 2, _au.h + _au.pad * 2) > 200, "a bake under a 2x matrix still has its ink");
    buffer_delete(_rdu.buf); surface_free(_sfu);

    // ------------------------------------------------------------ 85: case art
    hvs_st_stage(_st, 85);
    var _kinds = hvs_case_kinds(), _mats = hvs_case_materials(), _cgrids = [], _cnames = [], _cbakeUs = 0, _cbakeWorst = 0;
    hvs_st_assert(_st, array_length(_kinds) == 8 && array_length(_mats) == 6, "8 kinds, 6 materials");
    _st.notes.kinds = array_length(_kinds); _st.notes.materials = array_length(_mats); _st.notes.containers = array_length(_kinds) * array_length(_mats);
    for (var _k = 0; _k < 8; _k++) for (var _m = 0; _m < 6; _m++) {
        var _cc = hvs_container({ w: 6, h: 4, kind: _kinds[_k], material: _mats[_m], seed: _k * 6 + _m + 1, wear: 0.4, mask: hvs_case_mask(_kinds[_k], 6, 4) });
        var _t3 = get_timer(), _sh = hvs_case_shell_art(_cc.kind, _cc.material, 6, 4, 36, _cc.seed, 0.4), _ln = hvs_case_lining_art(_cc, 36);
        var _dt = get_timer() - _t3;
        _cbakeUs += _dt; _cbakeWorst = max(_cbakeWorst, _dt);
        var _mm = hvs_case_metrics(_cc.kind, 6, 4, 36);
        hvs_st_assert(_st, sprite_exists(_sh.spr) && _sh.w == _mm.w && _sh.h == _mm.h && _ln.w == 216 && _ln.h == 144, _cc.kind + "/" + _cc.material + ": baked at its metrics");
        // shell + lining composed over black
        var _sf = surface_create(_mm.w, _mm.h);
        surface_set_target(_sf); draw_clear_alpha(c_black, 1);
        gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
        draw_sprite(_sh.spr, 0, 0, 0); draw_sprite(_ln.spr, 0, _mm.ml, _mm.mt);
        gpu_set_blendmode(bm_normal);
        surface_reset_target();
        var _rd2 = hvs__st_read(_sf);
        // no flat rectangle: the lining has real variation
        var _gridL = 0, _lum0 = -1, _diffN = 0, _cnt = 0;
        for (var _y = _mm.mt; _y < _mm.mt + 144; _y += 3) for (var _x = _mm.ml; _x < _mm.ml + 216; _x += 3) {
            var _p = (_y * _mm.w + _x) * 4, _lum = buffer_peek(_rd2.buf, _p, buffer_u8) + buffer_peek(_rd2.buf, _p + 1, buffer_u8) + buffer_peek(_rd2.buf, _p + 2, buffer_u8);
            if (_lum0 < 0) _lum0 = _lum;
            if (abs(_lum - _lum0) > 12) _diffN++;
            _cnt++;
        }
        hvs_st_assert(_st, _diffN / _cnt > 0.10, _cc.kind + "/" + _cc.material + ": the lining is not a flat fill: " + string_format(_diffN / _cnt, 1, 2));
        array_push(_cgrids, hvs__st_grid(_rd2, 16, 12)); array_push(_cnames, _cc.kind + "/" + _cc.material);
        buffer_delete(_rd2.buf); surface_free(_sf);
    }
    _st.timings.caseBakeMsMean = _cbakeUs / 1000 / 48; _st.timings.caseBakeMsWorst = _cbakeWorst / 1000;
    var _cmin = infinity, _cminp = "", _chist = array_create(14, 0), _cpairs = 0;
    for (var _i = 0; _i < 48; _i++) for (var _j = _i + 1; _j < 48; _j++) {
        var _dd = hvs__st_diff(_cgrids[_i], _cgrids[_j]);
        _cpairs++; _chist[min(13, floor(_dd / 2))] += 1;
        if (_dd < _cmin) { _cmin = _dd; _cminp = _cnames[_i] + " vs " + _cnames[_j]; }
    }
    _st.notes.casePairs = _cpairs; _st.notes.caseMinD = _cmin; _st.notes.caseMinPair = _cminp; _st.notes.caseHist = _chist;
    // the regression bar: the same case at another wear and seed measures LESS than this, so this floor separates containers from reskins of one
    var _cc0 = hvs_container({ w: 6, h: 4, kind: "attache", material: "hide", seed: 1, wear: 0.4 }), _cc1 = hvs_container({ w: 6, h: 4, kind: "attache", material: "hide", seed: 900, wear: 0.9 });
    var _mm0 = hvs_case_metrics("attache", 6, 4, 36), _rg0 = undefined, _rg1 = undefined;
    for (var _z = 0; _z < 2; _z++) {
        var _cz = _z == 0 ? _cc0 : _cc1, _sz = hvs_case_shell_art(_cz.kind, _cz.material, 6, 4, 36, _cz.seed, _cz.wear), _lz = hvs_case_lining_art(_cz, 36), _sf = surface_create(_mm0.w, _mm0.h);
        surface_set_target(_sf); draw_clear_alpha(c_black, 1); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); draw_sprite(_sz.spr, 0, 0, 0); draw_sprite(_lz.spr, 0, _mm0.ml, _mm0.mt); gpu_set_blendmode(bm_normal); surface_reset_target();
        var _rd2 = hvs__st_read(_sf);
        if (_z == 0) _rg0 = hvs__st_grid(_rd2, 16, 12); else _rg1 = hvs__st_grid(_rd2, 16, 12);
        buffer_delete(_rd2.buf); surface_free(_sf);
    }
    var _same = hvs__st_diff(_rg0, _rg1);
    _st.notes.caseSameD = _same;
    hvs_st_assert(_st, _cmin > _same, "the closest two of the 48 (" + _cminp + " at " + string_format(_cmin, 1, 1) + ") sit further apart than one case re-seeded and re-worn (" + string_format(_same, 1, 1) + ")");
    // masks, as the kinds suit them
    var _msk = hvs_case_mask("saddlebag", 6, 4);
    hvs_st_assert(_st, is_array(_msk) && string_char_at(_msk[3], 1) == "." && string_char_at(_msk[3], 2) == "X" && string_char_at(_msk[0], 1) == "X", "a saddlebag's bottom corners are closed");
    hvs_st_assert(_st, is_undefined(hvs_case_mask("attache", 6, 4)) && is_undefined(hvs_case_mask("saddlebag", 2, 2)), "other kinds and tiny sizes have no mask");
    // a physical size stays a physical size: hardware is bounded at both ends
    var _m16 = hvs_case_metrics("attache", 4, 3, 16), _m128 = hvs_case_metrics("attache", 4, 3, 128);
    hvs_st_assert(_st, _m16.ml >= 15 && _m128.ml <= 40, "the rim is bounded at both ends of the cell size: " + string(_m16.ml) + ", " + string(_m128.ml));
    hvs_st_assert(_st, hvs_case_title("footlocker", "oak") == "Oak Footlocker", "a case has a plain name");

    // ------------------------------------------------------------ 88: redraw only on change
    hvs_st_stage(_st, 88);
    var _dkr = hvs_desk_create(), _cr = hvs_container({ w: 6, h: 4, kind: "attache", material: "steel", seed: 3 }), _pr = hvs_desk_add(_dkr, _cr, 10, 10, { cell: 32 });
    hvs_put(_cr, hvs_item("pistol"), 0, 0); hvs_put(_cr, hvs_item("potion"), 3, 1);
    var _sf = surface_create(400, 300);
    surface_set_target(_sf); draw_clear_alpha(c_black, 1); hvs_desk_draw(_dkr); surface_reset_target();
    hvs_st_assert(_st, _pr.composes == 1, "the first draw composes once: " + string(_pr.composes));
    repeat (300) { surface_set_target(_sf); draw_clear_alpha(c_black, 1); hvs_desk_draw(_dkr); surface_reset_target(); hvs_desk_tick(_dkr); }
    hvs_st_assert(_st, _pr.composes == 1, "300 idle frames compose nothing more: " + string(_pr.composes));
    _st.notes.composesAfterIdle = _pr.composes;
    hvs_put(_cr, hvs_item("key"), 4, 3);
    surface_set_target(_sf); draw_clear_alpha(c_black, 1); hvs_desk_draw(_dkr); surface_reset_target();
    hvs_st_assert(_st, _pr.composes == 2, "a change composes once: " + string(_pr.composes));
    // surface loss: the picture comes back from the sprites, pixel for pixel
    var _rd3 = hvs__st_read(_pr.surf), _g3 = hvs__st_grid(_rd3, 12, 8);
    buffer_delete(_rd3.buf);
    surface_free(_pr.surf);
    hvs_st_assert(_st, !surface_exists(_pr.surf), "the surface is really gone");
    surface_set_target(_sf); draw_clear_alpha(c_black, 1); hvs_desk_draw(_dkr); surface_reset_target();
    hvs_st_assert(_st, surface_exists(_pr.surf) && _pr.composes == 3, "a lost surface is rebuilt on the next draw");
    var _rd4 = hvs__st_read(_pr.surf), _g4 = hvs__st_grid(_rd4, 12, 8);
    buffer_delete(_rd4.buf);
    hvs_st_assert(_st, hvs__st_diff(_g3, _g4) < 0.01, "and it is the same picture: " + string(hvs__st_diff(_g3, _g4)));
    // the state a desk hands back
    draw_set_font(fnt_haversack_display_s); draw_set_colour(c_aqua); draw_set_alpha(0.5); draw_set_halign(fa_right); draw_set_valign(fa_bottom);
    surface_set_target(_sf); hvs_desk_draw(_dkr); surface_reset_target();
    hvs_st_assert(_st, draw_get_font() == fnt_haversack_display_s && draw_get_colour() == c_aqua && abs(draw_get_alpha() - 0.5) < 0.01 && draw_get_halign() == fa_right && draw_get_valign() == fa_bottom, "the desk hands back font, colour, alpha and alignment");
    draw_set_colour(c_white); draw_set_alpha(1); draw_set_halign(fa_left); draw_set_valign(fa_top);
    // a desk drawn under a transform stays in place: a surface part is untouched by the bake's matrix
    var _inkA = 0;
    var _rdA = hvs__st_read(_sf);
    for (var _y = 0; _y < 300; _y += 2) for (var _x = 0; _x < 400; _x += 2) if (buffer_peek(_rdA.buf, (_y * 400 + _x) * 4, buffer_u8) > 12) _inkA++;
    buffer_delete(_rdA.buf);
    hvs_st_assert(_st, _inkA > 3000, "the desk's picture has ink on the target: " + string(_inkA));
    // the ghost: red on the blocked cell, green on the free ones, in real pixels
    var _pl = hvs_item("smg");
    hvs_put(_cr, _pl, 2, 2);
    _dkr.swap = false; // one occupant would otherwise offer a swap, amber rather than red
    var _mc3 = hvs__st_centre(_pr, 4, 0);
    hvs__st_feed(_dkr, _mc3[0], _mc3[1]);
    var _kI = hvs_at(_cr, 4, 3), _mk3 = hvs__st_centre(_pr, 4, 3);
    hvs__st_feed(_dkr, _mk3[0], _mk3[1]); hvs__st_feed(_dkr, _mk3[0], _mk3[1], { press: true });
    // the same box on the same case, first over free cells (the control: no red there), then over the smg: the hand's own picture covers most of the cell, so count what shows round it
    var _redIn = function(_sf2, _cx0, _cy0, _cell2) {
        var _rdg = hvs__st_read(_sf2), _n2 = 0;
        for (var _y2 = floor(_cy0) + 1; _y2 < floor(_cy0) + _cell2 - 1; _y2++) for (var _x2 = floor(_cx0) + 1; _x2 < floor(_cx0) + _cell2 * 2 - 1; _x2++) {
            var _p2 = (_y2 * 400 + _x2) * 4, _r2 = real(buffer_peek(_rdg.buf, _p2, buffer_u8)), _g2 = real(buffer_peek(_rdg.buf, _p2 + 1, buffer_u8));
            if (_r2 > _g2 + 40) _n2++;
        }
        buffer_delete(_rdg.buf);
        return _n2;
    };
    var _mf = hvs__st_centre(_pr, 0, 2);
    repeat (6) hvs__st_feed(_dkr, _mf[0], _mf[1]);
    surface_set_target(_sf); draw_clear_alpha(c_black, 1); hvs_desk_draw(_dkr); surface_reset_target();
    var _scf = hvs_cell_screen(_pr, 0, 2), _red0 = _redIn(_sf, _scf.x, _scf.y, _pr.cell);
    hvs_st_assert(_st, _dkr.target.why == "ok", "control: the hand is over free cells: " + _dkr.target.why);
    var _mo = hvs__st_centre(_pr, 2, 2);
    repeat (6) hvs__st_feed(_dkr, _mo[0], _mo[1]);
    surface_set_target(_sf); draw_clear_alpha(c_black, 1); hvs_desk_draw(_dkr); surface_reset_target();
    var _sc1 = hvs_cell_screen(_pr, 2, 2), _redN = _redIn(_sf, _sc1.x, _sc1.y, _pr.cell);
    hvs_st_assert(_st, _dkr.target.why == "occupied", "the hand is over the smg: " + _dkr.target.why);
    hvs_st_assert(_st, _redN > _red0 + 60, "the ghost hatches blocked cells red, and free ones not: " + string(_redN) + " red pixels against " + string(_red0));
    hvs_desk_cancel(_dkr);
    hvs_desk_free(_dkr);
    surface_free(_sf);

    // ------------------------------------------------------------ 90: resources and timing
    hvs_st_stage(_st, 90);
    hvs_art_free();
    var _r0 = debug_event("ResourceCounts", true);
    var _spA = sprite_create_from_surface(application_surface, 0, 0, 2, 2, false, false, 0, 0), _srA = surface_create(8, 8);
    var _r1 = debug_event("ResourceCounts", true);
    hvs_st_assert(_st, _r1.spriteCount == _r0.spriteCount + 1 && _r1.surfaceCount == _r0.surfaceCount + 1, "control: the instrument sees a real sprite and surface");
    sprite_delete(_spA); surface_free(_srA);
    var _rc = debug_event("ResourceCounts", true);
    for (var _q = 0; _q < 3; _q++) {
        var _dx = hvs_desk_create(), _cx = hvs_container({ w: 6, h: 4, kind: "chest", material: "lacquer", seed: 8 }), _px = hvs_desk_add(_dx, _cx, 0, 0, { cell: 32 });
        hvs_put(_cx, hvs_item("rifle"), 0, 0); hvs_put(_cx, hvs_item("gem", 3), 5, 0);
        var _sx = surface_create(400, 300);
        surface_set_target(_sx); draw_clear_alpha(c_black, 1); hvs_desk_draw(_dx); surface_reset_target();
        surface_free(_sx);
        var _nn = hvs_art_count();
        hvs_desk_free(_dx);
        var _del = hvs_art_free();
        var _rd5 = debug_event("ResourceCounts", true);
        hvs_st_assert(_st, _nn >= 3 && _del >= 4 && _rd5.spriteCount == _rc.spriteCount && _rd5.surfaceCount == _rc.surfaceCount, "pass " + string(_q) + ": hvs_desk_free and hvs_art_free return every resource: sprites " + string(_rd5.spriteCount) + " vs " + string(_rc.spriteCount) + ", surfaces " + string(_rd5.surfaceCount) + " vs " + string(_rc.surfaceCount));
    }
    _st.notes.resourceSprites = _rc.spriteCount; _st.notes.resourceSurfaces = _rc.surfaceCount;
    // the time an idle open inventory costs a frame
    var _dt0 = hvs_desk_create(), _ct2 = hvs_container({ w: 9, h: 6, kind: "attache", material: "hide", seed: 2 }), _pt0 = hvs_desk_add(_dt0, _ct2, 10, 10, { cell: 44 }), _c2d = hvs_container({ w: 7, h: 3, kind: "crate", material: "oak", seed: 3 }), _p2d = hvs_desk_add(_dt0, _c2d, 500, 10, { cell: 44 });
    hvs_demo_fill(_ct2, [["rifle", 0, 0, 0], ["shotgun", 0, 3, 0], ["pistol", 5, 0, 0], ["medkit", 7, 0, 0], ["magazine", 7, 2, 0, 3], ["grenade", 0, 2, 0, 2], ["herb", 1, 2, 0, 6], ["knife", 3, 4, 0], ["ammobox", 0, 4, 0, 2]]);
    var _sft = surface_create(1280, 720), _tA = get_timer();
    surface_set_target(_sft); hvs_desk_draw(_dt0); surface_reset_target();
    _st.timings.firstDrawMs = (get_timer() - _tA) / 1000;
    var _tB = get_timer();
    repeat (60) { surface_set_target(_sft); hvs_desk_draw(_dt0); surface_reset_target(); }
    _st.timings.idleFrameMs = (get_timer() - _tB) / 1000 / 60;
    var _tC = get_timer();
    hvs_put(_ct2, hvs_item("st_one"), 8, 5);
    surface_set_target(_sft); hvs_desk_draw(_dt0); surface_reset_target();
    _st.timings.changeFrameMs = (get_timer() - _tC) / 1000;
    hvs_desk_free(_dt0);
    surface_free(_sft);

    // ------------------------------------------------------------ 95: the demo room, built, stepped and drawn through its own calls
    hvs_st_stage(_st, 95);
    var _dm = hvs_demo_create();
    hvs_st_assert(_st, array_length(_dm.main.items) == 10, "the main case holds its 10 items: " + string(array_length(_dm.main.items)));
    hvs_st_assert(_st, array_length(_dm.crate.items) == 8, "the crate holds its 8: " + string(array_length(_dm.crate.items)));
    hvs_st_assert(_st, array_length(_dm.roll.items) == 10, "the roll holds its 10: " + string(array_length(_dm.roll.items)));
    hvs_st_assert(_st, is_struct(_dm.pane_pouch) && array_length(_dm.pane_pouch.c.items) == 5, "the pouch is open on the bench, nested, with its 5");
    var _rollx = hvs_container({ w: 8, h: 8, accept: _dm.roll.accept });
    hvs_st_assert(_st, hvs_why(_rollx, hvs_item("medkit"), 0, 0) == "refused" && hvs_why(_rollx, hvs_item("vial"), 0, 0) == "ok", "the roll's accept function refuses a big item and takes a small one");
    hvs_st_assert(_st, array_length(_dm.locker.items) == 10, "the stash holds its 10: " + string(array_length(_dm.locker.items)));
    var _sfd = surface_create(1280, 720);
    surface_set_target(_sfd); draw_clear_alpha(c_black, 1); hvs_demo_draw(_dm, 1280, 720); surface_reset_target();
    var _dmr = hvs_cell_screen(_dm.pane_main, 0, 0);
    hvs_st_assert(_st, _dmr.x > 40 && _dmr.y > 100, "the demo's grid sits inside its case");
    // every case the K and M keys reach is built, and carries the contents
    var _total0 = 0, _crate0 = 0;
    for (var _q = 0; _q < array_length(_dm.main.items); _q++) _total0 += _dm.main.items[_q].count;
    for (var _q = 0; _q < array_length(_dm.crate.items); _q++) _crate0 += _dm.crate.items[_q].count;
    for (var _q = 1; _q < 8; _q++) {
        _dm.kind_i = _q; _dm.mat_i = _q mod 6;
        hvs_demo_rebuild(_dm, false);
        surface_set_target(_sfd); draw_clear_alpha(c_black, 1); hvs_demo_draw(_dm, 1280, 720); surface_reset_target();
        hvs_st_assert(_st, hvs__st_consistent(_dm.main) == "" && hvs__st_consistent(_dm.crate) == "", _dm.main.kind + ": consistent after the swap: " + hvs__st_consistent(_dm.main));
        var _mm9 = hvs_case_metrics(_dm.main.kind, _dm.main.w, _dm.main.h, 44), _rx = _dm.pane_crate.x;
        hvs_st_assert(_st, _dm.pane_main.x + _mm9.w <= _rx, _dm.main.kind + ": the case does not overlap the crate");
        hvs_st_assert(_st, _dm.pane_main.y + _mm9.h <= _dm.pane_roll.y + 6, _dm.main.kind + ": the case clears the roll: " + string(_dm.pane_main.y + _mm9.h) + " vs " + string(_dm.pane_roll.y));
    }
    // nothing was lost on the way: the same count in the main case and the crate, however the shapes shuffled them
    var _carried = 0, _cnts = [_dm.main, _dm.crate];
    for (var _z = 0; _z < 2; _z++) for (var _q = 0; _q < array_length(_cnts[_z].items); _q++) _carried += _cnts[_z].items[_q].count;
    hvs_st_assert(_st, _carried == _total0 + _crate0, "the swaps carried every item: " + string(_carried) + " of " + string(_total0 + _crate0));
    // a scripted run: the room's frame, in the shape the object calls it
    for (var _q = 0; _q < 30; _q++) { hvs_desk_tick(_dm.desk); surface_set_target(_sfd); draw_clear_alpha(c_black, 1); hvs_demo_draw(_dm, 1280, 720); surface_reset_target(); }
    surface_free(_sfd);
    hvs_demo_free(_dm);
    hvs_st_assert(_st, hvs_art_count() == 0, "the demo frees what it baked");

    // ------------------------------------------------------------ 98: renders, to be LOOKED at
    hvs_st_stage(_st, 98);
    hvs__st_render_items(); hvs__st_render_cases(); hvs__st_render_desk();
    hvs_art_free();

    hvs_st_stage(_st, 99);
    return _st;
}
/// @function hvs__st_render_items()
/// @description Internal. Every form at 40 px, on a dark ground, for the contact sheet.
function hvs__st_render_items() {
    var _fs = hvs_forms(), _W = 1600, _H = 1040, _s = surface_create(_W, _H), _cell = 40, _x = 16, _y = 16, _rowh = 0;
    for (var _i = 0; _i < array_length(_fs); _i++) hvs_item_art(_fs[_i].form, 0, _cell);
    surface_set_target(_s); draw_clear_alpha(make_colour_rgb(38, 34, 34), 1);
    for (var _i = 0; _i < array_length(_fs); _i++) {
        var _f = _fs[_i], _d = hvs_item_def(_f.form), _rt = _d.rots[0], _w = _rt.w * _cell, _h = _rt.h * _cell;
        if (_x + _w > _W - 16) { _x = 16; _y += _rowh + 18; _rowh = 0; }
        draw_set_colour(make_colour_rgb(60, 56, 56));
        for (var _c = 0; _c < array_length(_rt.cells); _c++) draw_rectangle(_x + _rt.cells[_c][0] * _cell, _y + _rt.cells[_c][1] * _cell, _x + (_rt.cells[_c][0] + 1) * _cell - 2, _y + (_rt.cells[_c][1] + 1) * _cell - 2, false);
        draw_set_colour(c_white);
        hvs_item_draw(_f.form, _x, _y, 0, _cell);
        _x += _w + 18; _rowh = max(_rowh, _h);
    }
    surface_reset_target();
    surface_save(_s, "hvs_render_items.png");
    surface_free(_s);
}
/// @function hvs__st_render_cases()
/// @description Internal. All 48 containers, for the contact sheet.
function hvs__st_render_cases() {
    var _ks = hvs_case_kinds(), _ms = hvs_case_materials(), _cw = 262, _ch = 196, _W = _cw * 6 + 20, _H = _ch * 8 + 20, _s = surface_create(_W, _H), _pairs = [];
    for (var _k = 0; _k < 8; _k++) for (var _m = 0; _m < 6; _m++) {
        var _c = hvs_container({ w: 6, h: 4, kind: _ks[_k], material: _ms[_m], seed: _k * 6 + _m + 1, wear: 0.4, mask: hvs_case_mask(_ks[_k], 6, 4), dividers: _ks[_k] == "footlocker" ? [["v", 4, 0, 4]] : [] });
        array_push(_pairs, { c: _c, sh: hvs_case_shell_art(_c.kind, _c.material, 6, 4, 26, _c.seed, 0.4), ln: hvs_case_lining_art(_c, 26), m: hvs_case_metrics(_c.kind, 6, 4, 26), k: _k, mi: _m });
    }
    surface_set_target(_s); draw_clear_alpha(make_colour_rgb(70, 64, 58), 1);
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    for (var _i = 0; _i < array_length(_pairs); _i++) {
        var _p = _pairs[_i], _x = 10 + _p.mi * _cw + (_cw - _p.m.w) * 0.5, _y = 10 + _p.k * _ch + (_ch - _p.m.h) * 0.5;
        draw_sprite(_p.sh.spr, 0, _x, _y); draw_sprite(_p.ln.spr, 0, _x + _p.m.ml, _y + _p.m.mt);
    }
    gpu_set_blendmode(bm_normal);
    surface_reset_target();
    surface_save(_s, "hvs_render_cases.png");
    surface_free(_s);
}
/// @function hvs__st_render_desk()
/// @description Internal. The demo room as it opens, with an item in the hand over a blocked place.
function hvs__st_render_desk() {
    var _dm = hvs_demo_create(), _s = surface_create(1280, 720), _d = _dm.desk, _p = _dm.pane_main;
    var _mc = hvs__st_centre(_p, 5, 0);
    hvs__st_feed(_d, _mc[0], _mc[1]); hvs__st_feed(_d, _mc[0], _mc[1], { press: true });
    var _mt = hvs__st_centre(_p, 2, 2);
    repeat (6) hvs__st_feed(_d, _mt[0], _mt[1]);
    surface_set_target(_s); draw_clear_alpha(c_black, 1); hvs_demo_draw(_dm, 1280, 720); surface_reset_target();
    surface_save(_s, "hvs_render_desk.png");
    hvs_desk_cancel(_d);
    hvs__st_settle(_d);
    surface_free(_s);
    hvs_demo_free(_dm);
}
/// @function hvs_selftest_write(state)
/// @description Write the result file, for the runner.
function hvs_selftest_write(_st) {
    var _f = file_text_open_write("hvs_selftest.json");
    file_text_write_string(_f, json_stringify({ ran: true, total: _st.total, pass: _st.pass, fail: _st.fail, stage: _st.stage, failures: _st.failures, notes: _st.notes, timings: _st.timings }));
    file_text_close(_f);
}
