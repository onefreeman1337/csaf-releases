{
  "$GMScript": "v1",
  "%Name": "hvs_desk",
  "name": "hvs_desk",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}