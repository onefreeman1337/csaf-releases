/// hvs_desk.gml - the hands. A DESK is a set of containers on screen and what the player is doing to them: lifting, turning, dropping, springing back, walking a
/// gamepad cursor over irregular footprints. hvs_desk_feed takes plain numbers and flags, so everything here can be driven by a test with no device attached;
/// hvs_desk_read reads the real mouse, touch, keyboard and gamepad and calls it. An item in the player's hand stays in its container until the drop lands, so
/// a save taken mid-drag restores it where it was.
///
/// Haversack - A Spatial Inventory That Draws Its Own Containers. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function hvs__is_desk(value)
/// @description Internal. Is this a desk made by hvs_desk_create?
function hvs__is_desk(_v) { return is_struct(_v) && variable_struct_exists(_v, "hvs_kind_tag") && _v.hvs_kind_tag == "desk"; }

/// @function hvs_desk_create(options)
/// @description Make a desk.
/// @param {struct} options  on_event: function(what, item, pane), told about "lift", "drop", "snapback", "refuse", "rotate", "stack", "swap", "transfer", "tidy", "discard". pad_device: gamepad slot (default 0). swap: dropping on one item picks that item up (default true). keys: {rotate, tidy} keyboard keys. font, font_small: your own fonts for labels. tooltips: false hides the name plate (default true).
/// @returns {struct} The desk.
function hvs_desk_create(_opts = undefined) {
    var _o = is_struct(_opts) ? _opts : {};
    var _d = {
        hvs_kind_tag: "desk", panes: [], hold: undefined, flights: [], hover: undefined, target: undefined, pad_mode: false,
        cursor: { pane: undefined, x: 0, y: 0, prefx: 0, prefy: 0 },
        mx: 0, my: 0, press_x: 0, press_y: 0, press_t: 0, frame: 0, pressed_on: undefined,
        on_event: hvs__rebind(_o[$ "on_event"], _o), pad_device: floor(hvs__n(_o[$ "pad_device"], 0)),
        swap: variable_struct_exists(_o, "swap") ? (_o.swap == true) : true,
        rotate_key: ord("R"), tidy_key: ord("T"),
        font: _o[$ "font"], font_small: _o[$ "font_small"], tooltips: variable_struct_exists(_o, "tooltips") ? (_o.tooltips == true) : true, hover_t: 0, hover_last: undefined,
        last_refusal: "", refusal_t: 0, composes: 0, nav_lock: 0
    };
    var _k = _o[$ "keys"];
    if (is_struct(_k)) {
        if (!is_undefined(_k[$ "rotate"])) _d.rotate_key = _k.rotate;
        if (!is_undefined(_k[$ "tidy"])) _d.tidy_key = _k.tidy;
    }
    return _d;
}
/// @function hvs_desk_add(desk, container, x, y, options)
/// @description Put a container on the desk, drawn at a screen position.
/// @param {struct} desk  The desk.
/// @param {struct} container  The container.
/// @param {real} x  Left edge of the drawn case.
/// @param {real} y  Top edge of the drawn case.
/// @param {struct} options  cell: pixels per cell (default 40). rows: rows shown at once; a taller container scrolls (default all). draw_case: false draws only the items, over your own panel (default true).
/// @returns {struct} The pane, or undefined.
function hvs_desk_add(_d, _c, _x, _y, _opts = undefined) {
    if (!hvs__is_desk(_d) || !hvs__is_case(_c)) return undefined;
    var _o = is_struct(_opts) ? _opts : {};
    var _cell = hvs__cell_cap(_c.w, _c.h, _o[$ "cell"]);
    var _rows = clamp(floor(hvs__n(_o[$ "rows"], _c.h)), 1, _c.h);
    var _draw = variable_struct_exists(_o, "draw_case") ? (_o.draw_case == true) : true;
    var _m = _draw ? hvs_case_metrics(_c.kind, _c.w, _rows, _cell) : { ml: 0, mt: 0, mr: 0, mb: 0, w: _c.w * _cell, h: _rows * _cell };
    var _p = { hvs_kind_tag: "pane", c: _c, x: hvs__n(_x, 0), y: hvs__n(_y, 0), cell: _cell, rows: _rows, draw_case: _draw, m: _m,
        gx: hvs__n(_x, 0) + _m.ml, gy: hvs__n(_y, 0) + _m.mt, scroll: 0, scroll_to: 0, surf: -1, rev_seen: -1, hide_sig: "", composes: 0,
        title: is_string(_o[$ "title"]) ? _o.title : _c.name };
    array_push(_d.panes, _p);
    if (is_undefined(_d.cursor.pane)) { _d.cursor.pane = _p; hvs__cursor_home(_d); }
    return _p;
}
/// @function hvs_desk_remove(desk, container)
/// @description Take a container off the desk (closing a bag). Its surface is freed; its items stay in it. If the player is holding one of its items, it goes back first.
function hvs_desk_remove(_d, _c) {
    if (!hvs__is_desk(_d)) return false;
    var _found = false;
    for (var _i = array_length(_d.panes) - 1; _i >= 0; _i--) {
        var _p = _d.panes[_i];
        if (_p.c != _c) continue;
        if (!is_undefined(_d.hold) && _d.hold.from_pane == _p) hvs_desk_cancel(_d);
        if (!is_undefined(_d.hover) && _d.hover.pane == _p) _d.hover = undefined;
        if (!is_undefined(_d.target) && _d.target.pane == _p) _d.target = undefined;
        if (surface_exists(_p.surf)) surface_free(_p.surf);
        array_delete(_d.panes, _i, 1);
        if (_d.cursor.pane == _p) { _d.cursor.pane = array_length(_d.panes) > 0 ? _d.panes[0] : undefined; hvs__cursor_home(_d); }
        _found = true;
    }
    return _found;
}
/// @function hvs_desk_free(desk)
/// @description Free the desk's surfaces. Call it in Clean Up. (Baked sprites are shared between desks: hvs_art_free releases those.)
function hvs_desk_free(_d) {
    if (!hvs__is_desk(_d)) return;
    for (var _i = 0; _i < array_length(_d.panes); _i++) { var _p = _d.panes[_i]; if (surface_exists(_p.surf)) surface_free(_p.surf); _p.surf = -1; }
}
/// @function hvs__fire(desk, what, item, pane)
/// @description Internal. Tell the game something happened.
function hvs__fire(_d, _what, _it, _p) { if (is_method(_d.on_event)) _d.on_event(_what, _it, _p); }

// ------------------------------------------------------------------------------------------------ geometry

/// @function hvs__pane_view_h(pane)
/// @description Internal. The pane's grid window height, in pixels.
function hvs__pane_view_h(_p) { return _p.rows * _p.cell; }
/// @function hvs__scroll_max(pane)
/// @description Internal. The largest scroll offset, in pixels.
function hvs__scroll_max(_p) { return max(0, (_p.c.h - _p.rows) * _p.cell); }
/// @function hvs_pane_at(desk, x, y)
/// @description The pane whose grid window holds this screen point, or undefined.
function hvs_pane_at(_d, _x, _y) {
    if (!hvs__is_desk(_d)) return undefined;
    _x = hvs__n(_x, -99999); _y = hvs__n(_y, -99999);
    for (var _i = array_length(_d.panes) - 1; _i >= 0; _i--) {
        var _p = _d.panes[_i];
        if (_x >= _p.gx && _y >= _p.gy && _x < _p.gx + _p.c.w * _p.cell && _y < _p.gy + hvs__pane_view_h(_p)) return _p;
    }
    return undefined;
}
/// @function hvs_pane_cell(pane, x, y)
/// @description The cell under a screen point as {x, y}, in the container's own coordinates (scroll included). Outside the window: undefined.
function hvs_pane_cell(_p, _x, _y) {
    if (!is_struct(_p) || !variable_struct_exists(_p, "hvs_kind_tag") || _p.hvs_kind_tag != "pane") return undefined;
    _x = hvs__n(_x, -99999); _y = hvs__n(_y, -99999);
    if (_x < _p.gx || _y < _p.gy || _x >= _p.gx + _p.c.w * _p.cell || _y >= _p.gy + hvs__pane_view_h(_p)) return undefined;
    return { x: floor((_x - _p.gx) / _p.cell), y: floor((_y - _p.gy + _p.scroll) / _p.cell) };
}
/// @function hvs_cell_screen(pane, x, y)
/// @description A cell's top-left corner on screen, as {x, y}, scroll included.
function hvs_cell_screen(_p, _x, _y) {
    if (!is_struct(_p) || !variable_struct_exists(_p, "gx")) return { x: 0, y: 0 };
    return { x: _p.gx + hvs__n(_x, 0) * _p.cell, y: _p.gy + hvs__n(_y, 0) * _p.cell - _p.scroll };
}

// ------------------------------------------------------------------------------------------------ the hand

/// @function hvs__lift(desk, pane, item, grabx, graby)
/// @description Internal. Take an item into the hand. It stays in its container (and in any save) until a drop lands.
function hvs__lift(_d, _p, _it, _gx, _gy) {
    var _s = hvs_cell_screen(_p, _it.x, _it.y);
    _d.hold = { it: _it, from_pane: _p, from_x: _it.x, from_y: _it.y, from_rot: _it.rot, rot: _it.rot, grabx: _gx, graby: _gy, sticky: false,
        cell: _p.cell, px: _s.x, py: _s.y, vx: 0, vy: 0, ang: 0, angv: 0, lift: 0, liftv: 0, free: false };
    _d.target = undefined;
    hvs__fire(_d, "lift", _it, _p);
}
/// @function hvs_desk_carry(desk, item, cell)
/// @description Put an item with no container into the player's hand (a pickup, a shop purchase). On a refused drop it stays in the hand; hvs_desk_cancel gives it back to you through on_event("discard").
/// @returns {bool} Whether it is now in hand.
function hvs_desk_carry(_d, _it, _cell = 40) {
    if (!hvs__is_desk(_d) || !hvs__is_item(_it) || !is_undefined(_d.hold)) return false;
    if (hvs__is_case(_it.home)) return false;
    var _c = clamp(floor(hvs__n(_cell, 40)), 8, 128);
    _d.hold = { it: _it, from_pane: undefined, from_x: -1, from_y: -1, from_rot: _it.rot, rot: _it.rot, grabx: 0, graby: 0, sticky: true,
        cell: _c, px: _d.mx, py: _d.my, vx: 0, vy: 0, ang: 0, angv: 0, lift: 0, liftv: 0, free: true };
    return true;
}
/// @function hvs_desk_held(desk)
/// @description The item in the player's hand, or undefined.
function hvs_desk_held(_d) { return hvs__is_desk(_d) && !is_undefined(_d.hold) ? _d.hold.it : undefined; }
/// @function hvs_desk_hovered(desk)
/// @description The item under the cursor (not the held one), or undefined.
function hvs_desk_hovered(_d) { return hvs__is_desk(_d) && !is_undefined(_d.hover) ? _d.hover.it : undefined; }
/// @function hvs_desk_cancel(desk)
/// @description Put the held item back where it was lifted from, springing home. If it had no home, on_event("discard") hands it to you.
function hvs_desk_cancel(_d) {
    if (!hvs__is_desk(_d) || is_undefined(_d.hold)) return false;
    var _h = _d.hold;
    if (_h.free) {
        var _back = _h[$ "swapped_from"];
        _d.hold = undefined; _d.target = undefined;
        if (!is_undefined(_back) && hvs_add(_back.c, _h.it)) { hvs__fly(_d, _h.it, _h.px, _h.py, _h.rot, _back, _h.it.x, _h.it.y, _h.it.rot, 14); return true; }
        hvs__fire(_d, "discard", _h.it, undefined);
        return true;
    }
    hvs__fly(_d, _h.it, _h.px, _h.py, _h.rot, _h.from_pane, _h.it.x, _h.it.y, _h.it.rot, 14);
    _d.hold = undefined; _d.target = undefined;
    return true;
}
/// @function hvs__fly(desk, item, fromx, fromy, fromrot, pane, cellx, celly, rot, frames)
/// @description Internal. An item travels on screen to a cell. The item is logically there already; only the picture is catching up.
function hvs__fly(_d, _it, _x0, _y0, _r0, _p, _cx, _cy, _r1, _frames) {
    array_push(_d.flights, { it: _it, x0: _x0, y0: _y0, r0: _r0, r1: _r1, pane: _p, cx: _cx, cy: _cy, t: 0, dur: max(1, _frames) });
}
/// @function hvs__target_compute(desk)
/// @description Internal. Where the held item would land right now: {pane, x, y, why, swap (one item that would be picked up), merge (a stack it would pour into)}. Undefined off every pane.
function hvs__target_compute(_d) {
    var _h = _d.hold;
    if (is_undefined(_h)) return undefined;
    var _p, _cx, _cy;
    if (_d.pad_mode) {
        _p = _d.cursor.pane;
        if (is_undefined(_p)) return undefined;
        _cx = _d.cursor.x - _h.grabx; _cy = _d.cursor.y - _h.graby;
    } else {
        _p = hvs_pane_at(_d, _d.mx, _d.my);
        if (is_undefined(_p)) return undefined;
        // the nearest cell to the item's own corner, so it lands where it visibly is
        var _lx = _d.mx - (_h.grabx + 0.5) * _p.cell, _ly = _d.my - (_h.graby + 0.5) * _p.cell;
        _cx = round((_lx - _p.gx) / _p.cell); _cy = round((_ly - _p.gy + _p.scroll) / _p.cell);
    }
    _h.cell = _p.cell;
    var _it = _h.it, _why = hvs_why(_p.c, _it, _cx, _cy, _h.rot), _swap = undefined, _merge = undefined;
    if (_why == "occupied") {
        var _one = hvs__sole_occupant(_p.c, _it, _cx, _cy, _h.rot);
        if (!is_undefined(_one)) {
            if (hvs_can_stack(_one, _it)) _merge = _one;
            else if (_d.swap && hvs__swap_legal(_p.c, _it, _one, _cx, _cy, _h.rot)) _swap = _one;
        }
    }
    return { pane: _p, x: _cx, y: _cy, why: _why, swap: _swap, merge: _merge };
}
/// @function hvs__sole_occupant(container, item, x, y, rot)
/// @description Internal. If exactly one other item stands under this footprint, that item.
function hvs__sole_occupant(_c, _it, _x, _y, _rot) {
    var _cells = _it.def.rots[_rot].cells, _one = undefined;
    for (var _i = 0; _i < array_length(_cells); _i++) {
        var _v = hvs_at(_c, _x + _cells[_i][0], _y + _cells[_i][1]);
        if (is_undefined(_v) || _v == _it) continue;
        if (!is_undefined(_one) && _one != _v) return undefined;
        _one = _v;
    }
    return _one;
}
/// @function hvs__swap_legal(container, item, other_item, x, y, rot)
/// @description Internal. Would the placement be legal with that one item out of the way? Asked by lifting it for an instant, so every rule is the real rule.
function hvs__swap_legal(_c, _it, _o, _x, _y, _rot) {
    var _cells = _o.def.rots[_o.rot].cells, _n = array_length(_cells);
    for (var _i = 0; _i < _n; _i++) _c.grid[(_o.y + _cells[_i][1]) * _c.w + _o.x + _cells[_i][0]] = HVS_FREE;
    var _ok = hvs_why(_c, _it, _x, _y, _rot) == "ok";
    for (var _i = 0; _i < _n; _i++) _c.grid[(_o.y + _cells[_i][1]) * _c.w + _o.x + _cells[_i][0]] = _o;
    return _ok;
}
/// @function hvs__refuse(desk, why)
/// @description Internal. Remember why the last drop was refused, for the caption.
function hvs__refuse(_d, _why) { _d.last_refusal = _why; _d.refusal_t = 90; }
/// @function hvs__drop(desk)
/// @description Internal. The drop: it lands, stacks or swaps if it can; otherwise the item springs back to exactly where it was lifted from, its rotation restored.
function hvs__drop(_d) {
    var _h = _d.hold;
    if (is_undefined(_h)) return;
    var _t = hvs__target_compute(_d), _it = _h.it;
    if (!is_undefined(_t)) {
        if (_t.why == "ok") {
            var _fp = _h.from_pane;
            hvs_put(_t.pane.c, _it, _t.x, _t.y, _h.rot);
            hvs__fly(_d, _it, _h.px, _h.py, _h.rot, _t.pane, _t.x, _t.y, _h.rot, 7);
            _d.hold = undefined; _d.target = undefined;
            hvs__fire(_d, "drop", _it, _t.pane);
            return;
        }
        if (!is_undefined(_t.merge)) {
            var _left = hvs_merge(_t.merge, _it);
            hvs__fire(_d, "stack", _t.merge, _t.pane);
            if (_left <= 0) { _d.hold = undefined; _d.target = undefined; return; }
            hvs_desk_cancel(_d);
            return;
        }
        if (!is_undefined(_t.swap)) {
            var _o = _t.swap, _ox = _o.x, _oy = _o.y, _orot = _o.rot;
            hvs_take(_o);
            if (hvs_put(_t.pane.c, _it, _t.x, _t.y, _h.rot)) {
                hvs__fly(_d, _it, _h.px, _h.py, _h.rot, _t.pane, _t.x, _t.y, _h.rot, 7);
                // the other item is in the hand now, with no home until it lands
                var _s = hvs_cell_screen(_t.pane, _ox, _oy), _cellp = _t.pane.cell;
                _d.hold = { it: _o, from_pane: undefined, from_x: -1, from_y: -1, from_rot: _orot, rot: _orot, grabx: 0, graby: 0, sticky: true,
                    cell: _cellp, px: _s.x, py: _s.y, vx: 0, vy: 0, ang: 0, angv: 0, lift: 0, liftv: 0, free: true, swapped_from: _t.pane };
                _d.target = undefined;
                hvs__fire(_d, "swap", _o, _t.pane);
                return;
            }
            hvs_put(_t.pane.c, _o, _ox, _oy, _orot); // cannot happen unless a rule changed mid-call; the item goes back, nothing is lost
        }
        hvs__refuse(_d, _t.why);
        hvs__fire(_d, "refuse", _it, _t.pane);
    }
    if (_h.free) { _h.sticky = true; return; }
    hvs__fire(_d, "snapback", _it, _h.from_pane);
    hvs__fly(_d, _it, _h.px, _h.py, _h.rot, _h.from_pane, _it.x, _it.y, _it.rot, 16);
    _d.hold = undefined; _d.target = undefined;
}
/// @function hvs__next_rot(item, rot)
/// @description Internal. The next rotation an item really has: a 2 x 2 does not turn at all, a bar has only two.
function hvs__next_rot(_it, _rot) {
    if (!_it.def.rotates) return _rot;
    var _ds = _it.def.distinct, _n = array_length(_ds);
    if (_n <= 1) return _rot;
    for (var _i = 0; _i < _n; _i++) if (_ds[_i] == _rot) return _ds[(_i + 1) mod _n];
    return _ds[0];
}
/// @function hvs__rotate_hold(desk)
/// @description Internal. Turn the item in the hand a quarter, keeping the grabbed cell under the cursor.
function hvs__rotate_hold(_d) {
    var _h = _d.hold, _it = _h.it, _nr = hvs__next_rot(_it, _h.rot);
    if (_nr == _h.rot) return false;
    var _steps = ((_nr - _h.rot) + 4) mod 4, _rc = _h.rot;
    var _gx = _h.grabx, _gy = _h.graby;
    // a bar's two real rotations are 0 and 1; going 1 -> 0 is three clockwise quarter turns, and the grabbed cell follows the same turns.
    repeat (_steps) { var _oh = _it.def.rots[_rc].h, _ngx = _oh - 1 - _gy; _gy = _gx; _gx = _ngx; _rc = (_rc + 1) mod 4; }
    var _rb = _it.def.rots[_nr];
    _h.grabx = clamp(_gx, 0, _rb.w - 1); _h.graby = clamp(_gy, 0, _rb.h - 1);
    _h.rot = _nr;
    _h.ang = (_steps == 3) ? 90 : -90; _h.angv = 0; // three clockwise quarters is one anticlockwise, and it should look like one
    hvs__fire(_d, "rotate", _it, _h.from_pane);
    return true;
}
/// @function hvs__hover_update(desk)
/// @description Internal. Which item the pointer or the pad cursor is on.
function hvs__hover_update(_d) {
    _d.hover = undefined;
    if (!is_undefined(_d.hold)) return;
    if (_d.pad_mode) {
        var _p = _d.cursor.pane;
        if (is_undefined(_p)) return;
        var _it = hvs_at(_p.c, _d.cursor.x, _d.cursor.y);
        if (!is_undefined(_it)) _d.hover = { pane: _p, it: _it };
        return;
    }
    var _p2 = hvs_pane_at(_d, _d.mx, _d.my);
    if (is_undefined(_p2)) return;
    var _cl = hvs_pane_cell(_p2, _d.mx, _d.my);
    if (is_undefined(_cl)) return;
    var _it2 = hvs_at(_p2.c, _cl.x, _cl.y);
    if (!is_undefined(_it2)) _d.hover = { pane: _p2, it: _it2 };
}

// ------------------------------------------------------------------------------------------------ the gamepad walk

/// @function hvs__cursor_home(desk)
/// @description Internal. Put the pad cursor on the first open cell of its pane.
function hvs__cursor_home(_d) {
    var _p = _d.cursor.pane;
    if (is_undefined(_p)) return;
    for (var _y = 0; _y < _p.c.h; _y++) for (var _x = 0; _x < _p.c.w; _x++) if (hvs_cell_open(_p.c, _x, _y)) { _d.cursor.x = _x; _d.cursor.y = _y; _d.cursor.prefx = _x; _d.cursor.prefy = _y; return; }
}
/// @function hvs_desk_step_cursor(desk, dx, dy)
/// @description Walk the pad cursor one step in a direction. Empty-handed it leaves the whole footprint it is on, however irregular, landing on the next different thing, and it remembers its column or row so an L-shape does not make it drift. With an item in hand it moves one cell. Past a container's edge it crosses to the nearest container that way.
/// @returns {bool} Whether it moved.
function hvs_desk_step_cursor(_d, _dx, _dy) {
    if (!hvs__is_desk(_d)) return false;
    _dx = sign(hvs__n(_dx, 0)); _dy = sign(hvs__n(_dy, 0));
    if (_dx != 0) _dy = 0;
    if (_dx == 0 && _dy == 0) return false;
    var _cur = _d.cursor, _p = _cur.pane;
    if (is_undefined(_p)) return false;
    var _c = _p.c, _from = hvs_at(_c, _cur.x, _cur.y), _carry = !is_undefined(_d.hold);
    // along the axis of travel, from the current cell; across it, on the remembered line. Masked cells and the item being left are stepped over.
    for (var _step = 1; _step <= max(_c.w, _c.h); _step++) {
        var _x = _cur.x + _dx * _step, _y = _cur.y + _dy * _step;
        if (_x < 0 || _y < 0 || _x >= _c.w || _y >= _c.h) break;
        var _ax = (_dx != 0) ? _x : _cur.prefx, _ay = (_dy != 0) ? _y : _cur.prefy;
        if (hvs_cell_open(_c, _ax, _ay) && (_carry || is_undefined(_from) || hvs_at(_c, _ax, _ay) != _from)) {
            _cur.x = _ax; _cur.y = _ay;
            if (_dx != 0) _cur.prefx = _ax; else _cur.prefy = _ay;
            hvs__pane_follow(_p, _cur.y);
            return true;
        }
    }
    // off the edge: the nearest pane in that direction
    var _np = hvs__pane_toward(_d, _p, _dx, _dy, _cur.x, _cur.y);
    if (is_undefined(_np)) return false;
    var _sc = hvs_cell_screen(_p, _cur.x + 0.5, _cur.y + 0.5), _best = undefined, _bd = infinity;
    for (var _yy = 0; _yy < _np.c.h; _yy++) for (var _xx = 0; _xx < _np.c.w; _xx++) {
        if (!hvs_cell_open(_np.c, _xx, _yy)) continue;
        var _ss = hvs_cell_screen(_np, _xx + 0.5, _yy + 0.5), _dd = abs(_ss.x - _sc.x) + abs(_ss.y - _sc.y);
        if (_dd < _bd) { _bd = _dd; _best = [_xx, _yy]; }
    }
    if (is_undefined(_best)) return false;
    _cur.pane = _np; _cur.x = _best[0]; _cur.y = _best[1]; _cur.prefx = _best[0]; _cur.prefy = _best[1];
    hvs__pane_follow(_np, _cur.y);
    return true;
}
/// @function hvs__pane_toward(desk, pane, dx, dy, cellx, celly)
/// @description Internal. The nearest other pane lying in a direction from this cell.
function hvs__pane_toward(_d, _p, _dx, _dy, _cx, _cy) {
    var _sc = hvs_cell_screen(_p, _cx + 0.5, _cy + 0.5), _best = undefined, _bd = infinity;
    for (var _i = 0; _i < array_length(_d.panes); _i++) {
        var _o = _d.panes[_i];
        if (_o == _p) continue;
        var _ox = _o.gx + _o.c.w * _o.cell * 0.5, _oy = _o.gy + hvs__pane_view_h(_o) * 0.5;
        var _ax = (_ox - _sc.x) * _dx + (_oy - _sc.y) * _dy, _bx = abs(_ox - _sc.x) * abs(_dy) + abs(_oy - _sc.y) * abs(_dx);
        if (_ax <= 0) continue;
        var _score = _ax + _bx * 0.6;
        if (_score < _bd) { _bd = _score; _best = _o; }
    }
    return _best;
}
/// @function hvs__pane_follow(pane, cell_y)
/// @description Internal. Scroll so a row is in the window.
function hvs__pane_follow(_p, _cy) {
    var _top = _cy * _p.cell, _bot = (_cy + 1) * _p.cell;
    if (_top < _p.scroll_to) _p.scroll_to = _top;
    if (_bot > _p.scroll_to + hvs__pane_view_h(_p)) _p.scroll_to = _bot - hvs__pane_view_h(_p);
    _p.scroll_to = clamp(_p.scroll_to, 0, hvs__scroll_max(_p));
}

// ------------------------------------------------------------------------------------------------ the feed

/// @function hvs_desk_feed(desk, input)
/// @description One frame of input, as plain values. No device is touched here, so a test or a replay can drive the whole desk. Call hvs_desk_read instead for the real devices.
/// @param {struct} desk  The desk.
/// @param {struct} input  Any of: mx, my (pointer, on screen); press, release (primary button edges); rotate; transfer (quick-move the item under the pointer); tidy; wheel (+1/-1); pad (this frame's input came from a gamepad); nav_x, nav_y (a pad step, -1/0/+1); a (lift or drop); b (cancel).
function hvs_desk_feed(_d, _in) {
    if (!hvs__is_desk(_d) || !is_struct(_in)) return;
    _d.frame += 1;
    if (_in[$ "pad"] == true) _d.pad_mode = true;
    var _mx = hvs__n(_in[$ "mx"], _d.mx), _my = hvs__n(_in[$ "my"], _d.my);
    if (_mx != _d.mx || _my != _d.my) { if (_in[$ "pad"] != true) _d.pad_mode = false; _d.mx = _mx; _d.my = _my; }
    if (_in[$ "press"] == true) _d.pad_mode = false;

    // the wheel
    var _wh = hvs__n(_in[$ "wheel"], 0);
    if (_wh != 0) {
        var _pw = hvs_pane_at(_d, _d.mx, _d.my);
        if (!is_undefined(_pw)) _pw.scroll_to = clamp(_pw.scroll_to - _wh * _pw.cell, 0, hvs__scroll_max(_pw));
    }
    // the pad walk
    var _nx = hvs__n(_in[$ "nav_x"], 0), _ny = hvs__n(_in[$ "nav_y"], 0);
    if (_nx != 0 || _ny != 0) hvs_desk_step_cursor(_d, _nx, _ny);

    // the primary action, by pointer
    if (_in[$ "press"] == true) {
        _d.press_x = _d.mx; _d.press_y = _d.my; _d.press_t = _d.frame;
        if (!is_undefined(_d.hold)) hvs__drop(_d);
        else {
            var _p = hvs_pane_at(_d, _d.mx, _d.my);
            var _cl = is_undefined(_p) ? undefined : hvs_pane_cell(_p, _d.mx, _d.my);
            var _it = is_undefined(_cl) ? undefined : hvs_at(_p.c, _cl.x, _cl.y);
            if (!is_undefined(_it)) {
                if (_in[$ "transfer"] == true) hvs__transfer(_d, _p, _it);
                else hvs__lift(_d, _p, _it, _cl.x - _it.x, _cl.y - _it.y);
            }
        }
    }
    if (_in[$ "release"] == true && !is_undefined(_d.hold) && !_d.hold.sticky) {
        // a quick click with no travel lifts and keeps: the next click drops. A real drag drops on release.
        var _dist = abs(_d.mx - _d.press_x) + abs(_d.my - _d.press_y);
        if (_d.frame - _d.press_t <= 14 && _dist < 6) _d.hold.sticky = true;
        else hvs__drop(_d);
    }
    // the primary action, by pad
    if (_in[$ "a"] == true) {
        _d.pad_mode = true;
        if (!is_undefined(_d.hold)) hvs__drop(_d);
        else {
            var _pp = _d.cursor.pane;
            if (!is_undefined(_pp)) {
                var _pi = hvs_at(_pp.c, _d.cursor.x, _d.cursor.y);
                if (!is_undefined(_pi)) { hvs__lift(_d, _pp, _pi, _d.cursor.x - _pi.x, _d.cursor.y - _pi.y); _d.hold.sticky = true; }
            }
        }
    }
    if (_in[$ "b"] == true && !is_undefined(_d.hold)) hvs_desk_cancel(_d);

    // turn
    if (_in[$ "rotate"] == true) {
        if (!is_undefined(_d.hold)) hvs__rotate_hold(_d);
        else { hvs__hover_update(_d); if (!is_undefined(_d.hover)) hvs__rotate_in_place(_d, _d.hover.pane, _d.hover.it); }
    }
    // quick-move, with a button of its own (the pointer's is handled on press)
    if (_in[$ "transfer"] == true && _in[$ "press"] != true && is_undefined(_d.hold)) {
        hvs__hover_update(_d);
        if (!is_undefined(_d.hover)) hvs__transfer(_d, _d.hover.pane, _d.hover.it);
    }
    // tidy the pane under the pointer or the pad cursor
    if (_in[$ "tidy"] == true && is_undefined(_d.hold)) {
        var _tp = _d.pad_mode ? _d.cursor.pane : hvs_pane_at(_d, _d.mx, _d.my);
        if (!is_undefined(_tp)) hvs_desk_tidy(_d, _tp);
    }
    hvs__hover_update(_d);
    _d.target = hvs__target_compute(_d);
    // dragging near a window's edge scrolls it
    if (!is_undefined(_d.hold) && !_d.pad_mode) {
        var _sp = hvs_pane_at(_d, _d.mx, _d.my);
        if (!is_undefined(_sp) && hvs__scroll_max(_sp) > 0) {
            var _edge = _sp.cell * 0.6;
            if (_d.my < _sp.gy + _edge) _sp.scroll_to = max(0, _sp.scroll_to - _sp.cell * 0.12);
            if (_d.my > _sp.gy + hvs__pane_view_h(_sp) - _edge) _sp.scroll_to = min(hvs__scroll_max(_sp), _sp.scroll_to + _sp.cell * 0.12);
        }
    }
}
/// @function hvs__rotate_in_place(desk, pane, item)
/// @description Internal. Turn an item where it stands, if its next rotation fits about the same corner.
function hvs__rotate_in_place(_d, _p, _it) {
    var _nr = hvs__next_rot(_it, _it.rot);
    if (_nr == _it.rot) return false;
    if (hvs_why(_p.c, _it, _it.x, _it.y, _nr) != "ok") { hvs__refuse(_d, "occupied"); hvs__fire(_d, "refuse", _it, _p); return false; }
    var _s = hvs_cell_screen(_p, _it.x, _it.y), _r0 = _it.rot;
    hvs_put(_p.c, _it, _it.x, _it.y, _nr);
    hvs__fly(_d, _it, _s.x, _s.y, _r0, _p, _it.x, _it.y, _nr, 8);
    hvs__fire(_d, "rotate", _it, _p);
    return true;
}
/// @function hvs__transfer(desk, pane, item)
/// @description Internal. Quick-move: the first other pane with room takes it.
function hvs__transfer(_d, _p, _it) {
    var _s = hvs_cell_screen(_p, _it.x, _it.y), _r0 = _it.rot;
    for (var _i = 0; _i < array_length(_d.panes); _i++) {
        var _o = _d.panes[_i];
        if (_o == _p) continue;
        var _room = hvs_find_room(_o.c, _it);
        if (is_undefined(_room)) continue;
        hvs_put(_o.c, _it, _room.x, _room.y, _room.rot);
        hvs__fly(_d, _it, _s.x, _s.y, _r0, _o, _room.x, _room.y, _room.rot, 16);
        hvs__pane_follow(_o, _room.y);
        hvs__fire(_d, "transfer", _it, _o);
        return true;
    }
    hvs__refuse(_d, "occupied");
    hvs__fire(_d, "refuse", _it, _p);
    return false;
}
/// @function hvs_desk_tidy(desk, pane)
/// @description Tidy a pane's container, with every item that moved flying to its new place.
/// @returns {struct} hvs_tidy's result.
function hvs_desk_tidy(_d, _p, _opts = undefined) {
    if (!hvs__is_desk(_d) || !is_struct(_p) || !variable_struct_exists(_p, "c")) return { ok: false, moved: 0, before: 0, after: 0, nodes: 0 };
    var _c = _p.c, _was = [];
    for (var _i = 0; _i < array_length(_c.items); _i++) { var _it = _c.items[_i], _s = hvs_cell_screen(_p, _it.x, _it.y); array_push(_was, { it: _it, x: _it.x, y: _it.y, rot: _it.rot, sx: _s.x, sy: _s.y }); }
    var _res = hvs_tidy(_c, _opts);
    for (var _i = 0; _i < array_length(_was); _i++) {
        var _w = _was[_i], _it = _w.it;
        if (_it.home != _c || (_it.x == _w.x && _it.y == _w.y && _it.rot == _w.rot)) continue;
        hvs__fly(_d, _it, _w.sx, _w.sy, _w.rot, _p, _it.x, _it.y, _it.rot, 16 + (_i mod 6));
    }
    hvs__fire(_d, "tidy", undefined, _p);
    return _res;
}

/// @function hvs_desk_tick(desk)
/// @description Advance the springs and flights one frame. hvs_desk_step does this for you.
function hvs_desk_tick(_d) {
    if (!hvs__is_desk(_d)) return;
    if (_d.refusal_t > 0) _d.refusal_t -= 1;
    var _h = _d.hold;
    if (!is_undefined(_h)) {
        var _tx, _ty, _cell = _h.cell;
        var _pt = _d.target;
        if (_d.pad_mode && !is_undefined(_pt)) { var _ps = hvs_cell_screen(_pt.pane, _pt.x, _pt.y); _tx = _ps.x; _ty = _ps.y; }
        else { _tx = _d.mx - (_h.grabx + 0.5) * _cell; _ty = _d.my - (_h.graby + 0.5) * _cell; }
        // a stiff, nearly critical spring: it follows the hand and arrives without wobble
        _h.vx += (_tx - _h.px) * 0.42; _h.vy += (_ty - _h.py) * 0.42;
        _h.vx *= 0.42; _h.vy *= 0.42;
        _h.px += _h.vx; _h.py += _h.vy;
        // the quarter turn, an underdamped spring: a little overshoot reads as weight
        _h.angv += (0 - _h.ang) * 0.28; _h.angv *= 0.58; _h.ang += _h.angv;
        if (abs(_h.ang) < 0.05 && abs(_h.angv) < 0.05) { _h.ang = 0; _h.angv = 0; }
        // the raise
        _h.liftv += (1 - _h.lift) * 0.30; _h.liftv *= 0.55; _h.lift += _h.liftv;
    }
    for (var _i = array_length(_d.flights) - 1; _i >= 0; _i--) {
        var _f = _d.flights[_i];
        _f.t += 1;
        if (_f.t >= _f.dur || _f.it.home != _f.pane.c) array_delete(_d.flights, _i, 1);
    }
    for (var _i = 0; _i < array_length(_d.panes); _i++) { var _p = _d.panes[_i]; _p.scroll += (_p.scroll_to - _p.scroll) * 0.35; if (abs(_p.scroll_to - _p.scroll) < 0.5) _p.scroll = _p.scroll_to; }
}
/// @function hvs__flight_pos(flight)
/// @description Internal. Where a flight is drawn this frame: eased, with a small overshoot past the landing that settles.
function hvs__flight_pos(_f) {
    var _u = clamp(_f.t / _f.dur, 0, 1), _s = hvs_cell_screen(_f.pane, _f.cx, _f.cy);
    var _e = 1 - power(1 - _u, 3);
    return { x: lerp(_f.x0, _s.x, _e), y: lerp(_f.y0, _s.y, _e), lift: (1 - _u) * (1 - _u), u: _u };
}
/// @function hvs_desk_read(desk, options)
/// @description Read the real mouse, touch, keyboard and gamepad into hvs_desk_feed. Mouse: drag, or click to lift and click to drop; right button or R turns; Shift + click quick-moves; T tidies; the wheel scrolls. Touch: as the mouse; a second finger turns. Gamepad: d-pad or left stick walks; A lifts and drops; X or a shoulder turns; B cancels; Y quick-moves; Start tidies.
/// @param {struct} desk  The desk.
/// @param {struct} options  gui: read the pointer in GUI space, for a desk drawn in Draw GUI (default true).
function hvs_desk_read(_d, _opts = undefined) {
    if (!hvs__is_desk(_d)) return;
    var _o = is_struct(_opts) ? _opts : {};
    var _gui = variable_struct_exists(_o, "gui") ? (_o.gui == true) : true;
    var _in = { mx: _gui ? device_mouse_x_to_gui(0) : mouse_x, my: _gui ? device_mouse_y_to_gui(0) : mouse_y };
    _in.press = mouse_check_button_pressed(mb_left);
    _in.release = mouse_check_button_released(mb_left);
    _in.rotate = mouse_check_button_pressed(mb_right) || keyboard_check_pressed(_d.rotate_key) || device_mouse_check_button_pressed(1, mb_left);
    _in.transfer = keyboard_check(vk_shift) && _in.press;
    _in.tidy = keyboard_check_pressed(_d.tidy_key);
    _in.wheel = (mouse_wheel_up() ? 1 : 0) - (mouse_wheel_down() ? 1 : 0);
    var _g = _d.pad_device;
    if (gamepad_is_connected(_g)) {
        var _nx = (gamepad_button_check_pressed(_g, gp_padr) ? 1 : 0) - (gamepad_button_check_pressed(_g, gp_padl) ? 1 : 0);
        var _ny = (gamepad_button_check_pressed(_g, gp_padd) ? 1 : 0) - (gamepad_button_check_pressed(_g, gp_padu) ? 1 : 0);
        // the stick, with a repeat
        var _sx = gamepad_axis_value(_g, gp_axislh), _sy = gamepad_axis_value(_g, gp_axislv);
        if (abs(_sx) > 0.55 || abs(_sy) > 0.55) {
            if (_d.nav_lock <= 0) {
                if (abs(_sx) >= abs(_sy)) _nx = sign(_sx); else _ny = sign(_sy);
                _d.nav_lock = 11;
            } else _d.nav_lock -= 1;
        } else _d.nav_lock = 0;
        var _any = _nx != 0 || _ny != 0;
        _in.nav_x = _nx; _in.nav_y = _ny;
        _in.a = gamepad_button_check_pressed(_g, gp_face1);
        _in.b = gamepad_button_check_pressed(_g, gp_face2);
        if (gamepad_button_check_pressed(_g, gp_face3) || gamepad_button_check_pressed(_g, gp_shoulderr)) { _in.rotate = true; _any = true; }
        if (gamepad_button_check_pressed(_g, gp_face4)) { _in.transfer = true; _any = true; }
        if (gamepad_button_check_pressed(_g, gp_start)) { _in.tidy = true; _any = true; }
        if (_any || _in.a || _in.b) _in.pad = true;
    }
    hvs_desk_feed(_d, _in);
}
/// @function hvs_desk_step(desk, options)
/// @description One frame: hvs_desk_read, then hvs_desk_tick. Call it in Step.
function hvs_desk_step(_d, _opts = undefined) {
    if (!hvs__is_desk(_d)) return;
    hvs_desk_read(_d, _opts);
    hvs_desk_tick(_d);
}
