/// hvs_core.gml - Haversack's rules. NO DRAWING and no device input in this file: items with real footprints, rotation, containers with
/// masks and dividers, stacks, weight, nesting, auto-tidy and the save format. Everything here can run in a headless test.
///
/// The words used throughout:
///   DEFINITION  hvs_item_define("rifle", {...}): what a kind of item IS (footprint, weight, stack size). Registered once, by id.
///   ITEM        hvs_item("rifle"): one thing the player owns (its rotation, count, position and your own data).
///   CONTAINER   hvs_container({w: 8, h: 6}): a cell grid. An item lives in at most one container at a time.
///   FOOTPRINT   the cells an item covers, declared in data and never derived from a sprite's size.
///
/// Haversack - A Spatial Inventory That Draws Its Own Containers. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

#macro HVS_VERSION "1.0.0"
#macro HVS_FREE 0
#macro HVS_BLOCKED -1
#macro HVS_MAX_SIDE 64

// ------------------------------------------------------------------------------------------------ small guards

/// @function hvs__n(value, fallback)
/// @description Internal. A finite number, or the fallback: every public entry point takes its numbers through this.
function hvs__n(_v, _d) {
    if (is_real(_v) || is_int32(_v) || is_int64(_v)) { if (is_nan(_v) || is_infinity(_v)) return _d; return _v; }
    return _d;
}
/// @function hvs__is_case(value)
/// @description Internal. Is this a container made by hvs_container?
function hvs__is_case(_v) { return is_struct(_v) && variable_struct_exists(_v, "hvs_kind_tag") && _v.hvs_kind_tag == "container"; }
/// @function hvs__is_item(value)
/// @description Internal. Is this an item made by hvs_item?
function hvs__is_item(_v) { return is_struct(_v) && variable_struct_exists(_v, "hvs_kind_tag") && _v.hvs_kind_tag == "item"; }
/// @function hvs__init()
/// @description Internal. The registry and the id counter, created on first use.
function hvs__init() {
    if (!variable_global_exists("hvs__reg")) { global.hvs__reg = {}; global.hvs__next_uid = 1; }
}
/// @function hvs__rebind(callback, options)
/// @description Internal. A function literal written inside an options struct is bound to that struct; hand it to the caller instead, so it can read the caller's variables.
function hvs__rebind(_f, _opts) {
    if (is_undefined(_f) || !is_method(_f)) return _f;
    if (method_get_self(_f) == _opts) return method(self, method_get_index(_f));
    return _f;
}

// ------------------------------------------------------------------------------------------------ the generator

/// @function hvs_rng(seed)
/// @description A small seeded generator (Lehmer). Warmed up here, because a Lehmer generator's first draw is nearly a straight line in the seed for nearby seeds.
/// @param {real} seed  Any number.
/// @returns {struct} Pass it to hvs_rand.
function hvs_rng(_seed) {
    var _s = floor(abs(hvs__n(_seed, 1))) mod 2147483646;
    var _g = { s: _s + 1 };
    repeat (3) hvs_rand(_g);
    return _g;
}
/// @function hvs_rand(generator)
/// @description The next draw in [0, 1). A non-generator draws 0.
function hvs_rand(_g) {
    if (!is_struct(_g) || !variable_struct_exists(_g, "s")) return 0;
    _g.s = (_g.s * 48271) mod 2147483647;
    return (_g.s - 1) / 2147483646;
}

// ------------------------------------------------------------------------------------------------ definitions

/// @function hvs__parse_shape(shape)
/// @description Internal. A footprint as [[x, y], ...], normalised to start at 0,0, from rows of text (["XX", "X."]), from "2x3", or from a list of [x, y] pairs.
function hvs__parse_shape(_shape) {
    var _cells = [];
    if (is_string(_shape)) {
        var _p = string_pos("x", _shape);
        if (_p <= 1) return undefined;
        var _a = string_digits(string_copy(_shape, 1, _p - 1)), _b = string_digits(string_delete(_shape, 1, _p));
        if (_a == "" || _b == "") return undefined;
        var _w = real(_a), _h = real(_b);
        if (_w < 1 || _h < 1 || _w > HVS_MAX_SIDE || _h > HVS_MAX_SIDE) return undefined;
        for (var _y = 0; _y < _h; _y++) for (var _x = 0; _x < _w; _x++) array_push(_cells, [_x, _y]);
    } else if (is_array(_shape)) {
        var _n = array_length(_shape);
        if (_n == 0) return undefined;
        if (is_string(_shape[0])) {
            for (var _y = 0; _y < _n; _y++) {
                if (!is_string(_shape[_y])) return undefined;
                var _row = _shape[_y];
                for (var _x = 0; _x < string_length(_row); _x++) {
                    var _ch = string_char_at(_row, _x + 1);
                    if (_ch == "X" || _ch == "x" || _ch == "#") array_push(_cells, [_x, _y]);
                }
            }
        } else {
            for (var _i = 0; _i < _n; _i++) {
                var _c = _shape[_i];
                if (!is_array(_c) || array_length(_c) < 2) return undefined;
                var _cx = hvs__n(_c[0], undefined), _cy = hvs__n(_c[1], undefined);
                if (is_undefined(_cx) || is_undefined(_cy)) return undefined;
                array_push(_cells, [floor(_cx), floor(_cy)]);
            }
        }
    } else return undefined;
    if (array_length(_cells) == 0) return undefined;
    return hvs__normalise(_cells);
}
/// @function hvs__normalise(cells)
/// @description Internal. Shift a footprint so its smallest x and y are 0, drop duplicates, and sort it in reading order.
function hvs__normalise(_cells) {
    var _minx = infinity, _miny = infinity, _n = array_length(_cells);
    for (var _i = 0; _i < _n; _i++) { _minx = min(_minx, _cells[_i][0]); _miny = min(_miny, _cells[_i][1]); }
    var _maxx = 0, _maxy = 0;
    for (var _i = 0; _i < _n; _i++) { _maxx = max(_maxx, _cells[_i][0] - _minx); _maxy = max(_maxy, _cells[_i][1] - _miny); }
    var _w = _maxx + 1, _h = _maxy + 1;
    if (_w > HVS_MAX_SIDE || _h > HVS_MAX_SIDE) return undefined;
    var _seen = array_create(_w * _h, false);
    for (var _i = 0; _i < _n; _i++) _seen[(_cells[_i][1] - _miny) * _w + (_cells[_i][0] - _minx)] = true;
    var _out = [];
    for (var _y = 0; _y < _h; _y++) for (var _x = 0; _x < _w; _x++) if (_seen[_y * _w + _x]) array_push(_out, [_x, _y]);
    return _out;
}
/// @function hvs__rotate_cells(cells, h)
/// @description Internal. One quarter turn clockwise: (x, y) -> (h - 1 - y, x).
function hvs__rotate_cells(_cells, _h) {
    var _out = [], _n = array_length(_cells);
    for (var _i = 0; _i < _n; _i++) array_push(_out, [_h - 1 - _cells[_i][1], _cells[_i][0]]);
    return hvs__normalise(_out);
}
/// @function hvs__cells_key(cells)
/// @description Internal. A footprint as text, for comparing two rotations.
function hvs__cells_key(_cells) {
    var _s = "", _n = array_length(_cells);
    for (var _i = 0; _i < _n; _i++) _s += string(_cells[_i][0]) + "," + string(_cells[_i][1]) + ";";
    return _s;
}
/// @function hvs__make_rot(cells)
/// @description Internal. One rotation's measurements: its cells, its box, and which of its cells touch (a divider may not run between two cells of one item).
function hvs__make_rot(_cells) {
    var _w = 0, _h = 0, _n = array_length(_cells);
    for (var _i = 0; _i < _n; _i++) { _w = max(_w, _cells[_i][0] + 1); _h = max(_h, _cells[_i][1] + 1); }
    var _map = array_create(_w * _h, false);
    for (var _i = 0; _i < _n; _i++) _map[_cells[_i][1] * _w + _cells[_i][0]] = true;
    var _right = [], _down = [];
    for (var _i = 0; _i < _n; _i++) {
        var _x = _cells[_i][0], _y = _cells[_i][1];
        if (_x + 1 < _w && _map[_y * _w + _x + 1]) array_push(_right, [_x, _y]);
        if (_y + 1 < _h && _map[(_y + 1) * _w + _x]) array_push(_down, [_x, _y]);
    }
    return { cells: _cells, w: _w, h: _h, map: _map, right: _right, down: _down };
}

/// @function hvs_item_define(id, options)
/// @description Register a kind of item. Call once per id at game start; a second call replaces the first.
/// @param {string} id  Your id for this kind of item.
/// @param {struct} options  shape: footprint, as rows (["XX", "X."]) or "2x3" or a list of [x, y] pairs (default "1x1"). name, weight (0), stack (1), rotates (true), form (a drawn form from hvs_forms(), or undefined), sprite (your own sprite instead of a form), hue (a hue in degrees for a form's liquid or cloth), holds ({w, h, ...}: this item is itself a container), data (anything).
/// @returns {struct} The definition, or undefined if the id or shape cannot be read.
function hvs_item_define(_id, _opts = undefined) {
    hvs__init();
    if (!is_string(_id) || _id == "") return undefined;
    var _o = is_struct(_opts) ? _opts : {};
    var _cells = hvs__parse_shape(variable_struct_exists(_o, "shape") ? _o.shape : "1x1");
    if (is_undefined(_cells)) return undefined;
    // the four quarter turns, and which of them are really different
    var _rots = [], _distinct = [], _keys = [], _cur = _cells;
    for (var _r = 0; _r < 4; _r++) {
        var _rt = hvs__make_rot(_cur);
        array_push(_rots, _rt);
        var _key = hvs__cells_key(_cur), _new = true;
        for (var _k = 0; _k < array_length(_keys); _k++) if (_keys[_k] == _key) _new = false;
        if (_new) { array_push(_keys, _key); array_push(_distinct, _r); }
        _cur = hvs__rotate_cells(_cur, _rt.h);
    }
    var _def = {
        hvs_kind_tag: "definition", id: _id,
        name: variable_struct_exists(_o, "name") && is_string(_o.name) ? _o.name : _id,
        rots: _rots, distinct: _distinct, area: array_length(_cells), sig: _keys[0],
        weight: max(0, hvs__n(_o[$ "weight"], 0)),
        stack: max(1, floor(hvs__n(_o[$ "stack"], 1))),
        rotates: variable_struct_exists(_o, "rotates") ? (_o.rotates == true) : true,
        form: is_string(_o[$ "form"]) ? _o.form : undefined,
        hue: hvs__n(_o[$ "hue"], undefined),
        sprite: _o[$ "sprite"],
        holds: is_struct(_o[$ "holds"]) ? _o.holds : undefined,
        data: _o[$ "data"]
    };
    global.hvs__reg[$ _id] = _def;
    return _def;
}
/// @function hvs_item_def(id)
/// @description The registered definition for an id, or undefined.
function hvs_item_def(_id) {
    hvs__init();
    if (!is_string(_id)) return undefined;
    return global.hvs__reg[$ _id];
}
/// @function hvs_item(id, count, data)
/// @description Make one item of a registered kind. It belongs to no container until you put it in one.
/// @param {string} id  A registered id.
/// @param {real} count  How many in this stack (default 1, capped at the definition's stack).
/// @param {any} data  Anything of yours (durability, a seed, a name). Saved with the item; keep it JSON-safe.
/// @returns {struct} The item, or undefined if the id is not registered.
function hvs_item(_id, _count = 1, _data = undefined) {
    var _def = hvs_item_def(_id);
    if (is_undefined(_def)) return undefined;
    var _it = { hvs_kind_tag: "item", uid: global.hvs__next_uid, id: _id, def: _def, count: clamp(floor(hvs__n(_count, 1)), 1, _def.stack),
        rot: 0, x: -1, y: -1, home: undefined, inside: undefined, data: _data };
    global.hvs__next_uid += 1;
    if (!is_undefined(_def.holds)) _it.inside = hvs__make_inner(_it, _def.holds);
    return _it;
}
/// @function hvs__make_inner(item, holds)
/// @description Internal. The container inside a container item.
function hvs__make_inner(_it, _holds) {
    var _c = hvs_container(_holds);
    if (!is_undefined(_c)) _c.owner = _it;
    return _c;
}

// ------------------------------------------------------------------------------------------------ containers

/// @function hvs_container(options)
/// @description Make a container.
/// @param {struct} options  w, h: size in cells (default 6 x 4, at most 64 each). mask: rows of text where X is a cell and anything else is solid (["XXXX", ".XX."]). dividers: walls items may not straddle, each ["v", at, from, to] or ["h", at, from, to]. limit: the most weight it holds, contents of nested containers included (0 = no limit). accept: function(item, container) returning true to allow an item. on_change: function(container, what, item). name, kind, material, seed, wear: read by the drawing layer.
/// @returns {struct} The container.
function hvs_container(_opts = undefined) {
    hvs__init();
    var _o = is_struct(_opts) ? _opts : {};
    var _w = clamp(floor(hvs__n(_o[$ "w"], 6)), 1, HVS_MAX_SIDE), _h = clamp(floor(hvs__n(_o[$ "h"], 4)), 1, HVS_MAX_SIDE);
    var _c = {
        hvs_kind_tag: "container", uid: global.hvs__next_uid, w: _w, h: _h,
        grid: array_create(_w * _h, HVS_FREE), items: [], rev: 0,
        name: is_string(_o[$ "name"]) ? _o.name : "",
        kind: is_string(_o[$ "kind"]) ? _o.kind : "attache",
        material: is_string(_o[$ "material"]) ? _o.material : "hide",
        seed: hvs__n(_o[$ "seed"], 1), wear: clamp(hvs__n(_o[$ "wear"], 0.35), 0, 1),
        limit: max(0, hvs__n(_o[$ "limit"], 0)),
        accept: hvs__rebind(_o[$ "accept"], _o), on_change: hvs__rebind(_o[$ "on_change"], _o),
        wall_v: undefined, wall_h: undefined, dividers: [], mask: undefined, owner: undefined, unresolved: []
    };
    global.hvs__next_uid += 1;
    // the mask
    var _m = _o[$ "mask"];
    if (is_array(_m)) {
        var _rows = [];
        for (var _y = 0; _y < _h; _y++) {
            var _row = (_y < array_length(_m) && is_string(_m[_y])) ? _m[_y] : "";
            array_push(_rows, _row);
            for (var _x = 0; _x < _w; _x++) {
                var _ch = string_char_at(_row, _x + 1);
                if (!(_ch == "X" || _ch == "x")) _c.grid[_y * _w + _x] = HVS_BLOCKED;
            }
        }
        _c.mask = _rows;
    }
    // the dividers
    var _dv = _o[$ "dividers"];
    if (is_array(_dv)) for (var _i = 0; _i < array_length(_dv); _i++) hvs_divider_add(_c, _dv[_i]);
    return _c;
}
/// @function hvs_divider_add(container, divider)
/// @description Add a wall items may not straddle. ["v", 3, 0, 4] stands between columns 2 and 3 for rows 0 to 3; ["h", 2, 0, 6] stands between rows 1 and 2 for columns 0 to 5.
/// @returns {bool} Whether it was read and added. Items already across it are not moved.
function hvs_divider_add(_c, _d) {
    if (!hvs__is_case(_c) || !is_array(_d) || array_length(_d) < 4 || !is_string(_d[0])) return false;
    var _at = hvs__n(_d[1], undefined), _a = hvs__n(_d[2], undefined), _b = hvs__n(_d[3], undefined);
    if (is_undefined(_at) || is_undefined(_a) || is_undefined(_b)) return false;
    _at = floor(_at); _a = floor(_a); _b = floor(_b);
    if (_d[0] == "v") {
        if (_at < 1 || _at >= _c.w) return false;
        if (is_undefined(_c.wall_v)) _c.wall_v = array_create(_c.w * _c.h, false);
        for (var _y = max(0, _a); _y < min(_b, _c.h); _y++) _c.wall_v[_y * _c.w + _at] = true;
    } else if (_d[0] == "h") {
        if (_at < 1 || _at >= _c.h) return false;
        if (is_undefined(_c.wall_h)) _c.wall_h = array_create(_c.w * _c.h, false);
        for (var _x = max(0, _a); _x < min(_b, _c.w); _x++) _c.wall_h[_at * _c.w + _x] = true;
    } else return false;
    array_push(_c.dividers, [_d[0], _at, _a, _b]);
    _c.rev += 1;
    return true;
}
/// @function hvs_cell_open(container, x, y)
/// @description Is this a usable cell of the container (inside the grid and not masked off)? Says nothing about what is in it.
function hvs_cell_open(_c, _x, _y) {
    if (!hvs__is_case(_c)) return false;
    _x = hvs__n(_x, -1); _y = hvs__n(_y, -1);
    if (_x < 0 || _y < 0 || _x >= _c.w || _y >= _c.h) return false;
    var _v = _c.grid[floor(_y) * _c.w + floor(_x)];
    return is_struct(_v) || _v != HVS_BLOCKED;
}
/// @function hvs_at(container, x, y)
/// @description The item covering this cell, or undefined.
function hvs_at(_c, _x, _y) {
    if (!hvs__is_case(_c)) return undefined;
    _x = hvs__n(_x, -1); _y = hvs__n(_y, -1);
    if (_x < 0 || _y < 0 || _x >= _c.w || _y >= _c.h) return undefined;
    var _v = _c.grid[floor(_y) * _c.w + floor(_x)];
    return is_struct(_v) ? _v : undefined;
}
/// @function hvs_item_cells(item, rot)
/// @description An item's footprint at a rotation (its current one by default): a list of [x, y] in the item's own box.
function hvs_item_cells(_it, _rot = undefined) {
    if (!hvs__is_item(_it)) return [];
    var _r = ((floor(hvs__n(_rot, _it.rot)) mod 4) + 4) mod 4;
    return _it.def.rots[_r].cells;
}
/// @function hvs_item_box(item, rot)
/// @description An item's box in cells at a rotation (its current one by default): {w, h}.
function hvs_item_box(_it, _rot = undefined) {
    if (!hvs__is_item(_it)) return { w: 0, h: 0 };
    var _r = ((floor(hvs__n(_rot, _it.rot)) mod 4) + 4) mod 4;
    var _rt = _it.def.rots[_r];
    return { w: _rt.w, h: _rt.h };
}
/// @function hvs__within(container, ancestor)
/// @description Internal. Is this container the ancestor, or nested anywhere inside it?
function hvs__within(_c, _anc) {
    var _guard = 0;
    while (hvs__is_case(_c) && _guard < 64) {
        if (_c == _anc) return true;
        var _own = _c.owner;
        if (!hvs__is_item(_own)) return false;
        _c = _own.home;
        _guard += 1;
    }
    return false;
}
/// @function hvs__item_weight(item)
/// @description Internal. An item's whole weight: its stack, plus everything inside it.
function hvs__item_weight(_it) {
    var _w = _it.def.weight * _it.count;
    if (hvs__is_case(_it.inside)) _w += hvs_weight(_it.inside);
    return _w;
}
/// @function hvs_weight(container)
/// @description The total weight in a container, nested containers included.
function hvs_weight(_c) {
    if (!hvs__is_case(_c)) return 0;
    var _t = 0, _n = array_length(_c.items);
    for (var _i = 0; _i < _n; _i++) _t += hvs__item_weight(_c.items[_i]);
    return _t;
}

/// @function hvs_why(container, item, x, y, rot)
/// @description Why an item could or could not go here, without moving anything. An item's own present cells count as free, so this also answers "can it turn in place?".
/// @param {struct} container  The container.
/// @param {struct} item  An item made by hvs_item.
/// @param {real} x  The cell of the item's box's top-left corner.
/// @param {real} y  The same, down.
/// @param {real} rot  Quarter turns clockwise (the item's current rotation by default).
/// @returns {string} "ok", or the reason: "bounds", "masked", "occupied", "divider", "self" (a bag into itself), "weight", "refused", "bad".
function hvs_why(_c, _it, _x, _y, _rot = undefined) {
    if (!hvs__is_case(_c) || !hvs__is_item(_it)) return "bad";
    _x = hvs__n(_x, undefined); _y = hvs__n(_y, undefined);
    if (is_undefined(_x) || is_undefined(_y)) return "bad";
    _x = floor(_x); _y = floor(_y);
    var _rr = ((floor(hvs__n(_rot, _it.rot)) mod 4) + 4) mod 4;
    var _rt = _it.def.rots[_rr];
    if (_x < 0 || _y < 0 || _x + _rt.w > _c.w || _y + _rt.h > _c.h) return "bounds";
    if (hvs__is_case(_it.inside) && hvs__within(_c, _it.inside)) return "self";
    var _cells = _rt.cells, _n = array_length(_cells), _w = _c.w, _grid = _c.grid, _hit = false;
    for (var _i = 0; _i < _n; _i++) {
        var _v = _grid[(_y + _cells[_i][1]) * _w + _x + _cells[_i][0]];
        if (is_struct(_v)) { if (_v != _it) _hit = true; }
        else if (_v == HVS_BLOCKED) return "masked";
    }
    if (_hit) return "occupied";
    if (!is_undefined(_c.wall_v)) {
        var _r = _rt.right, _m = array_length(_r);
        for (var _i = 0; _i < _m; _i++) if (_c.wall_v[(_y + _r[_i][1]) * _w + _x + _r[_i][0] + 1]) return "divider";
    }
    if (!is_undefined(_c.wall_h)) {
        var _d = _rt.down, _m = array_length(_d);
        for (var _i = 0; _i < _m; _i++) if (_c.wall_h[(_y + _d[_i][1] + 1) * _w + _x + _d[_i][0]]) return "divider";
    }
    if (is_method(_c.accept) && _it.home != _c) { if (_c.accept(_it, _c) != true) return "refused"; }
    if (!hvs__weight_allows(_c, _it)) return "weight";
    return "ok";
}
/// @function hvs__weight_allows(container, item)
/// @description Internal. Would every limited container from here upward still hold, with this item added?
function hvs__weight_allows(_c, _it) {
    var _add = hvs__item_weight(_it), _cur = _c, _guard = 0;
    while (hvs__is_case(_cur) && _guard < 64) {
        if (_cur.limit > 0 && !hvs__within(_it.home, _cur)) { if (hvs_weight(_cur) + _add > _cur.limit + 0.0001) return false; }
        var _own = _cur.owner;
        if (!hvs__is_item(_own)) break;
        _cur = _own.home;
        _guard += 1;
    }
    return true;
}
/// @function hvs_fits(container, item, x, y, rot)
/// @description True if the item could go here. hvs_why says why not.
function hvs_fits(_c, _it, _x, _y, _rot = undefined) { return hvs_why(_c, _it, _x, _y, _rot) == "ok"; }

/// @function hvs__clear(container, item)
/// @description Internal. Lift an item's cells out of the grid and its entry out of the list.
function hvs__clear(_c, _it) {
    var _rt = _it.def.rots[_it.rot], _cells = _rt.cells, _n = array_length(_cells), _w = _c.w;
    for (var _i = 0; _i < _n; _i++) _c.grid[(_it.y + _cells[_i][1]) * _w + _it.x + _cells[_i][0]] = HVS_FREE;
    var _idx = array_get_index(_c.items, _it);
    if (_idx >= 0) array_delete(_c.items, _idx, 1);
}
/// @function hvs__write(container, item, x, y, rot)
/// @description Internal. Write an item into the grid (the caller has already asked hvs_why).
function hvs__write(_c, _it, _x, _y, _rot) {
    var _rt = _it.def.rots[_rot], _cells = _rt.cells, _n = array_length(_cells), _w = _c.w;
    for (var _i = 0; _i < _n; _i++) _c.grid[(_y + _cells[_i][1]) * _w + _x + _cells[_i][0]] = _it;
    _it.x = _x; _it.y = _y; _it.rot = _rot; _it.home = _c;
    array_push(_c.items, _it);
}
/// @function hvs__changed(container, what, item)
/// @description Internal. Count a change, and tell the game.
function hvs__changed(_c, _what, _it) {
    _c.rev += 1;
    if (is_method(_c.on_change)) _c.on_change(_c, _what, _it);
}

/// @function hvs_put(container, item, x, y, rot)
/// @description Place an item at a cell, moving it from wherever it is now. ATOMIC: if the answer is not "ok", nothing has moved.
/// @returns {bool} Whether it went in. hvs_why says why not.
function hvs_put(_c, _it, _x, _y, _rot = undefined) {
    if (hvs_why(_c, _it, _x, _y, _rot) != "ok") return false;
    _x = floor(_x); _y = floor(_y);
    var _rr = ((floor(hvs__n(_rot, _it.rot)) mod 4) + 4) mod 4;
    var _from = _it.home;
    if (hvs__is_case(_from)) hvs__clear(_from, _it);
    hvs__write(_c, _it, _x, _y, _rr);
    if (hvs__is_case(_from) && _from != _c) hvs__changed(_from, "out", _it);
    hvs__changed(_c, "in", _it);
    return true;
}
/// @function hvs_take(item)
/// @description Take an item out of its container. It still exists; it belongs to nothing until put somewhere.
/// @returns {struct} The item, or undefined.
function hvs_take(_it) {
    if (!hvs__is_item(_it)) return undefined;
    var _from = _it.home;
    if (hvs__is_case(_from)) {
        hvs__clear(_from, _it);
        _it.home = undefined; _it.x = -1; _it.y = -1;
        hvs__changed(_from, "out", _it);
    }
    return _it;
}
/// @function hvs_find_room(container, item)
/// @description The first place this item fits, trying each rotation it allows. Nothing moves.
/// @returns {struct} {x, y, rot}, or undefined.
function hvs_find_room(_c, _it) {
    if (!hvs__is_case(_c) || !hvs__is_item(_it)) return undefined;
    var _def = _it.def, _nr = _def.rotates ? array_length(_def.distinct) : 1;
    for (var _k = 0; _k < _nr; _k++) {
        var _r = _def.rotates ? _def.distinct[_k] : _it.rot, _rt = _def.rots[_r];
        for (var _y = 0; _y <= _c.h - _rt.h; _y++) for (var _x = 0; _x <= _c.w - _rt.w; _x++) {
            if (hvs_why(_c, _it, _x, _y, _r) == "ok") return { x: _x, y: _y, rot: _r };
        }
    }
    return undefined;
}
/// @function hvs_can_stack(a, b)
/// @description Would these two items stack together? Same id, a stack size above 1, room left, and neither carries data of yours.
function hvs_can_stack(_a, _b) {
    if (!hvs__is_item(_a) || !hvs__is_item(_b) || _a == _b) return false;
    if (_a.id != _b.id || _a.def.stack <= 1) return false;
    if (!is_undefined(_a.data) || !is_undefined(_b.data)) return false;
    return _a.count < _a.def.stack;
}
/// @function hvs_merge(target, item)
/// @description Pour a stack into another of the same kind. If the source empties it leaves its container.
/// @returns {real} How many are left in the source.
function hvs_merge(_to, _from) {
    if (!hvs_can_stack(_to, _from)) return hvs__is_item(_from) ? _from.count : 0;
    var _mv = min(_to.def.stack - _to.count, _from.count);
    _to.count += _mv; _from.count -= _mv;
    if (hvs__is_case(_to.home)) hvs__changed(_to.home, "stack", _to);
    if (_from.count <= 0) { _from.count = 0; hvs_take(_from); }
    else if (hvs__is_case(_from.home)) hvs__changed(_from.home, "stack", _from);
    return _from.count;
}
/// @function hvs_split(item, amount)
/// @description Take some off a stack as a new item, belonging to nothing yet. The rest stays where it is.
/// @returns {struct} The new item, or undefined if there is nothing to split.
function hvs_split(_it, _amt) {
    if (!hvs__is_item(_it)) return undefined;
    _amt = floor(hvs__n(_amt, 0));
    if (_amt < 1 || _amt >= _it.count) return undefined;
    var _new = hvs_item(_it.id, _amt, _it.data);
    if (is_undefined(_new)) return undefined;
    _it.count -= _amt;
    _new.rot = _it.rot;
    if (hvs__is_case(_it.home)) hvs__changed(_it.home, "stack", _it);
    return _new;
}
/// @function hvs_add(container, item)
/// @description Give an item to a container: it tops up matching stacks first, then finds room for the rest.
/// @returns {bool} True if all of it is now in the container. False leaves the remainder in the item.
function hvs_add(_c, _it) {
    if (!hvs__is_case(_c) || !hvs__is_item(_it)) return false;
    if (_it.def.stack > 1) {
        var _n = array_length(_c.items);
        for (var _i = 0; _i < _n && _it.count > 0; _i++) {
            var _o = _c.items[_i];
            if (hvs_can_stack(_o, _it)) { _n = array_length(_c.items); hvs_merge(_o, _it); }
        }
        if (_it.count <= 0) return true;
    }
    var _room = hvs_find_room(_c, _it);
    if (is_undefined(_room)) return false;
    return hvs_put(_c, _it, _room.x, _room.y, _room.rot);
}
/// @function hvs_count(container, id)
/// @description How many of a kind are in a container, nested containers included.
function hvs_count(_c, _id) {
    if (!hvs__is_case(_c)) return 0;
    var _t = 0, _n = array_length(_c.items);
    for (var _i = 0; _i < _n; _i++) {
        var _it = _c.items[_i];
        if (_it.id == _id) _t += _it.count;
        if (hvs__is_case(_it.inside)) _t += hvs_count(_it.inside, _id);
    }
    return _t;
}
/// @function hvs_find(container, id)
/// @description The first item of a kind in a container, nested containers included, or undefined.
function hvs_find(_c, _id) {
    if (!hvs__is_case(_c)) return undefined;
    var _n = array_length(_c.items);
    for (var _i = 0; _i < _n; _i++) {
        var _it = _c.items[_i];
        if (_it.id == _id) return _it;
        if (hvs__is_case(_it.inside)) { var _f = hvs_find(_it.inside, _id); if (!is_undefined(_f)) return _f; }
    }
    return undefined;
}
/// @function hvs_consume(container, id, amount)
/// @description Use up some of a kind (ammunition, a reagent). All or nothing: if there are not enough, nothing is taken.
/// @returns {bool} Whether they were taken.
function hvs_consume(_c, _id, _amt = 1) {
    _amt = floor(hvs__n(_amt, 0));
    if (!hvs__is_case(_c) || _amt < 1 || hvs_count(_c, _id) < _amt) return false;
    while (_amt > 0) {
        var _it = hvs_find(_c, _id);
        if (is_undefined(_it)) return false;
        var _mv = min(_it.count, _amt);
        _it.count -= _mv; _amt -= _mv;
        if (_it.count <= 0) hvs_take(_it); else if (hvs__is_case(_it.home)) hvs__changed(_it.home, "stack", _it);
    }
    return true;
}
/// @function hvs_clear(container)
/// @description Take every item out of a container. Returns them as a list, in case you want them.
function hvs_clear(_c) {
    if (!hvs__is_case(_c)) return [];
    var _list = [];
    array_copy(_list, 0, _c.items, 0, array_length(_c.items));
    for (var _i = 0; _i < array_length(_list); _i++) hvs_take(_list[_i]);
    return _list;
}
/// @function hvs_used(container)
/// @description How the container is filled: {cells (usable cells), used, free, largest (the area of the largest free rectangle)}.
function hvs_used(_c) {
    if (!hvs__is_case(_c)) return { cells: 0, used: 0, free: 0, largest: 0 };
    var _cells = 0, _used = 0, _n = _c.w * _c.h;
    for (var _i = 0; _i < _n; _i++) { var _v = _c.grid[_i]; if (is_struct(_v)) { _cells++; _used++; } else if (_v != HVS_BLOCKED) _cells++; }
    return { cells: _cells, used: _used, free: _cells - _used, largest: hvs__largest_free(_c) };
}
/// @function hvs__largest_free(container)
/// @description Internal. The largest free rectangle, by the histogram method.
function hvs__largest_free(_c) {
    var _w = _c.w, _h = _c.h, _hist = array_create(_w, 0), _best = 0;
    for (var _y = 0; _y < _h; _y++) {
        for (var _x = 0; _x < _w; _x++) {
            var _v = _c.grid[_y * _w + _x];
            if (is_struct(_v) || _v == HVS_BLOCKED) _hist[_x] = 0; else _hist[_x] += 1;
        }
        for (var _x = 0; _x < _w; _x++) {
            var _mh = _hist[_x];
            if (_mh == 0) continue;
            for (var _e = _x; _e < _w && _hist[_e] > 0; _e++) {
                _mh = min(_mh, _hist[_e]);
                _best = max(_best, _mh * (_e - _x + 1));
            }
        }
    }
    return _best;
}

// ------------------------------------------------------------------------------------------------ tidy

/// @function hvs__tidy_try(container, list, budget)
/// @description Internal. Pack a list in order; first-fit, then a bounded search if that fails. Returns the placements or undefined, and leaves the grid holding them.
function hvs__tidy_try(_c, _list, _st) {
    var _n = array_length(_list), _placed = array_create(_n, undefined), _i = 0, _ok = true;
    for (_i = 0; _i < _n; _i++) {
        var _it = _list[_i], _room = hvs__tidy_room(_c, _it, 0, 0, 0, _st);
        if (is_undefined(_room)) { _ok = false; break; }
        hvs__tidy_mark(_c, _it, _room, _it);
        _placed[_i] = _room;
    }
    if (_ok) return _placed;
    // the greedy pass failed: unmark, and search with backtracking, cheapest branch first, within a budget
    for (var _j = 0; _j < _i; _j++) hvs__tidy_mark(_c, _list[_j], _placed[_j], HVS_FREE);
    _placed = array_create(_n, undefined);
    if (hvs__tidy_search(_c, _list, 0, _placed, _st)) return _placed;
    return undefined;
}
/// @function hvs__tidy_room(container, item, startx, starty, startrot, state)
/// @description Internal. The next cell and rotation the item fits at, in scan order, from a position. Weight and acceptance do not change during a tidy, so only the cells are read.
function hvs__tidy_room(_c, _it, _sx, _sy, _sk, _st) {
    var _def = _it.def, _nr = _def.rotates ? array_length(_def.distinct) : 1;
    for (var _y = _sy; _y < _c.h; _y++) {
        for (var _x = (_y == _sy ? _sx : 0); _x < _c.w; _x++) {
            for (var _k = ((_y == _sy && _x == _sx) ? _sk : 0); _k < _nr; _k++) {
                var _r = _def.rotates ? _def.distinct[_k] : _it.rot;
                _st.nodes += 1;
                if (hvs__tidy_fits(_c, _def.rots[_r], _x, _y)) return { x: _x, y: _y, rot: _r, k: _k };
            }
        }
    }
    return undefined;
}
/// @function hvs__tidy_fits(container, rotation, x, y)
/// @description Internal. Cells and dividers only.
function hvs__tidy_fits(_c, _rt, _x, _y) {
    if (_x + _rt.w > _c.w || _y + _rt.h > _c.h) return false;
    var _cells = _rt.cells, _n = array_length(_cells), _w = _c.w, _grid = _c.grid;
    for (var _i = 0; _i < _n; _i++) { var _v = _grid[(_y + _cells[_i][1]) * _w + _x + _cells[_i][0]]; if (is_struct(_v) || _v != HVS_FREE) return false; }
    if (!is_undefined(_c.wall_v)) { var _r = _rt.right, _m = array_length(_r); for (var _i = 0; _i < _m; _i++) if (_c.wall_v[(_y + _r[_i][1]) * _w + _x + _r[_i][0] + 1]) return false; }
    if (!is_undefined(_c.wall_h)) { var _d = _rt.down, _m = array_length(_d); for (var _i = 0; _i < _m; _i++) if (_c.wall_h[(_y + _d[_i][1] + 1) * _w + _x + _d[_i][0]]) return false; }
    return true;
}
/// @function hvs__tidy_mark(container, item, placement, value)
/// @description Internal. Write a placement's cells with a value (the item, or free).
function hvs__tidy_mark(_c, _it, _p, _val) {
    var _cells = _it.def.rots[_p.rot].cells, _n = array_length(_cells), _w = _c.w;
    for (var _i = 0; _i < _n; _i++) _c.grid[(_p.y + _cells[_i][1]) * _w + _p.x + _cells[_i][0]] = _val;
}
/// @function hvs__tidy_search(container, list, index, placed, state)
/// @description Internal. Depth-first placement with a node budget. Returns false when the budget runs out, and the caller keeps the original layout.
function hvs__tidy_search(_c, _list, _i, _placed, _st) {
    if (_i >= array_length(_list)) return true;
    var _it = _list[_i], _sx = 0, _sy = 0, _sk = 0;
    while (_st.nodes < _st.budget) {
        var _room = hvs__tidy_room(_c, _it, _sx, _sy, _sk, _st);
        if (is_undefined(_room)) return false;
        hvs__tidy_mark(_c, _it, _room, _it);
        _placed[@ _i] = _room;
        if (hvs__tidy_search(_c, _list, _i + 1, _placed, _st)) return true;
        hvs__tidy_mark(_c, _it, _room, HVS_FREE);
        _sx = _room.x; _sy = _room.y; _sk = _room.k + 1;
    }
    return false;
}
/// @function hvs__tidy_key(item, mode)
/// @description Internal. The sort key of a packing order: larger first.
function hvs__tidy_key(_it, _mode) {
    var _rt = _it.def.rots[0], _lng = max(_rt.w, _rt.h);
    if (_mode == 1) return _lng * 1000 + _it.def.area;
    if (_mode == 2) return (_rt.w * _rt.h - _it.def.area) * 1000 + _it.def.area * 10 + _lng;
    return _it.def.area * 1000 + _lng;
}
/// @function hvs__sort_keys(list, keys)
/// @description Internal. A stable insertion sort, largest key first: a function literal cannot capture the keys, and these lists are short.
function hvs__sort_keys(_list, _keys) {
    var _n = array_length(_list);
    for (var _i = 1; _i < _n; _i++) {
        var _a = _list[_i], _k = _keys[_i], _j = _i - 1;
        while (_j >= 0 && _keys[_j] < _k) { _list[@ _j + 1] = _list[_j]; _keys[@ _j + 1] = _keys[_j]; _j--; }
        _list[@ _j + 1] = _a; _keys[@ _j + 1] = _k;
    }
}

/// @function hvs_tidy(container, options)
/// @description Rearrange a container to open up the largest free space. Stacks merge first. Items keep their identity, count and data; an item is NEVER lost: if no better packing is found the layout stands as it was.
/// @param {struct} container  The container.
/// @param {struct} options  budget: how many placements the search may try (default 6000). stacks: merge partial stacks first (default true). key: function(item) returning a number; larger goes first, overriding the packing orders.
/// @returns {struct} {ok (a layout at least as good was kept), moved (items that changed place), before, after (largest free rectangle), nodes}.
function hvs_tidy(_c, _opts = undefined) {
    if (!hvs__is_case(_c)) return { ok: false, moved: 0, before: 0, after: 0, nodes: 0 };
    var _o = is_struct(_opts) ? _opts : {};
    var _budget = max(1, floor(hvs__n(_o[$ "budget"], 6000)));
    var _keyf = hvs__rebind(_o[$ "key"], _o);
    if (!variable_struct_exists(_o, "stacks") || _o.stacks == true) hvs__merge_all(_c);
    var _before = hvs__largest_free(_c), _orig = [], _n = array_length(_c.items);
    for (var _i = 0; _i < _n; _i++) { var _it = _c.items[_i]; array_push(_orig, { it: _it, x: _it.x, y: _it.y, rot: _it.rot }); }
    // clear the grid of items
    for (var _i = 0; _i < _n; _i++) hvs__tidy_mark(_c, _orig[_i].it, _orig[_i], HVS_FREE);
    var _st = { nodes: 0, budget: _budget }, _best = undefined, _bestScore = -1;
    var _modes = is_method(_keyf) ? 1 : 3;
    for (var _m = 0; _m < _modes; _m++) {
        var _list = [], _keys = [];
        for (var _i = 0; _i < _n; _i++) { var _it = _orig[_i].it; array_push(_list, _it); array_push(_keys, is_method(_keyf) ? hvs__n(_keyf(_it), 0) : hvs__tidy_key(_it, _m)); }
        hvs__sort_keys(_list, _keys);
        var _pl = hvs__tidy_try(_c, _list, _st);
        if (!is_undefined(_pl)) {
            var _score = hvs__largest_free(_c);
            if (_score > _bestScore) { _bestScore = _score; _best = { list: _list, pl: _pl }; }
            for (var _i = 0; _i < _n; _i++) hvs__tidy_mark(_c, _list[_i], _pl[_i], HVS_FREE);
        }
    }
    var _moved = 0, _ok = false;
    if (!is_undefined(_best) && (_bestScore >= _before || is_method(_keyf))) {
        _ok = true;
        for (var _i = 0; _i < _n; _i++) {
            var _it = _best.list[_i], _p = _best.pl[_i];
            if (_it.x != _p.x || _it.y != _p.y || _it.rot != _p.rot) _moved++;
            _it.x = _p.x; _it.y = _p.y; _it.rot = _p.rot;
            hvs__tidy_mark(_c, _it, _p, _it);
        }
        _c.items = _best.list;
    } else {
        for (var _i = 0; _i < _n; _i++) hvs__tidy_mark(_c, _orig[_i].it, _orig[_i], _orig[_i].it);
        _ok = !is_undefined(_best);
    }
    hvs__changed(_c, "tidy", undefined);
    return { ok: _ok, moved: _moved, before: _before, after: hvs__largest_free(_c), nodes: _st.nodes };
}
/// @function hvs__merge_all(container)
/// @description Internal. Top up every partial stack from the others of its kind.
function hvs__merge_all(_c) {
    var _i = 0;
    while (_i < array_length(_c.items)) {
        var _a = _c.items[_i];
        if (_a.def.stack > 1 && is_undefined(_a.data)) {
            var _j = _i + 1;
            while (_j < array_length(_c.items) && _a.count < _a.def.stack) {
                var _b = _c.items[_j];
                if (hvs_can_stack(_a, _b)) { hvs_merge(_a, _b); if (_b.count > 0) _j++; } else _j++;
            }
        }
        _i++;
    }
}

// ------------------------------------------------------------------------------------------------ save and load

/// @function hvs__save_item(item)
/// @description Internal. One item as plain data, its nested contents included.
function hvs__save_item(_it) {
    var _o = { id: _it.id, n: _it.count, x: _it.x, y: _it.y, r: _it.rot, sig: _it.def.sig };
    if (!is_undefined(_it.data)) _o.data = _it.data;
    if (hvs__is_case(_it.inside)) _o.inside = hvs_save_struct(_it.inside);
    return _o;
}
/// @function hvs_save_struct(container)
/// @description A container as plain data (rotation, nesting, stacks and your data included). Safe to put inside your own save struct.
function hvs_save_struct(_c) {
    if (!hvs__is_case(_c)) return undefined;
    var _items = [], _n = array_length(_c.items);
    for (var _i = 0; _i < _n; _i++) array_push(_items, hvs__save_item(_c.items[_i]));
    for (var _i = 0; _i < array_length(_c.unresolved); _i++) array_push(_items, _c.unresolved[_i]);
    var _o = { v: 1, w: _c.w, h: _c.h, name: _c.name, kind: _c.kind, material: _c.material, seed: _c.seed, wear: _c.wear, limit: _c.limit, items: _items };
    if (!is_undefined(_c.mask)) _o.mask = _c.mask;
    if (array_length(_c.dividers) > 0) _o.dividers = _c.dividers;
    return _o;
}
/// @function hvs_save_string(container)
/// @description A container as a JSON string.
function hvs_save_string(_c) {
    var _o = hvs_save_struct(_c);
    return is_undefined(_o) ? "" : json_stringify(_o);
}
/// @function hvs_load_struct(data, report)
/// @description Rebuild a container from hvs_save_struct's data. An item NEVER vanishes, even if your definitions changed since the save: a footprint that no longer fits where it was finds other room, and whatever still fits nowhere comes back in report.overflow for you to hand to the player. An id you removed stays in report.unknown and inside the container, unplaced, and is written back by the next save (restore the definition and it returns).
/// @param {struct} data  From hvs_save_struct.
/// @param {struct} report  Optional: a struct to fill with moved, overflow and unknown lists.
/// @returns {struct} The container, or undefined if the data cannot be read.
function hvs_load_struct(_d, _report = undefined) {
    if (!is_struct(_d) || !variable_struct_exists(_d, "items") || !is_array(_d.items)) return undefined;
    var _rep = is_struct(_report) ? _report : {};
    if (!variable_struct_exists(_rep, "moved")) { _rep.moved = []; _rep.overflow = []; _rep.unknown = []; }
    var _opts = { w: _d[$ "w"], h: _d[$ "h"], name: _d[$ "name"], kind: _d[$ "kind"], material: _d[$ "material"], seed: _d[$ "seed"], wear: _d[$ "wear"], limit: _d[$ "limit"], mask: _d[$ "mask"], dividers: _d[$ "dividers"] };
    var _c = hvs_container(_opts), _later = [];
    for (var _i = 0; _i < array_length(_d.items); _i++) {
        var _s = _d.items[_i];
        if (!is_struct(_s) || !is_string(_s[$ "id"])) continue;
        var _it = hvs_item(_s.id, hvs__n(_s[$ "n"], 1), _s[$ "data"]);
        if (is_undefined(_it)) { array_push(_c.unresolved, _s); array_push(_rep.unknown, _s.id); continue; }
        // a stack size that shrank since the save: the excess comes back as more stacks, never vanishes
        var _rest = floor(hvs__n(_s[$ "n"], 1)) - _it.count;
        while (_rest > 0) { var _ex = hvs_item(_s.id, _rest, _s[$ "data"]); array_push(_later, _ex); _rest -= _ex.count; }
        if (is_struct(_s[$ "inside"])) {
            var _in = hvs_load_struct(_s.inside, _rep);
            if (!is_undefined(_in)) { _in.owner = _it; _it.inside = _in; }
        }
        var _r = ((floor(hvs__n(_s[$ "r"], 0)) mod 4) + 4) mod 4;
        if (hvs_why(_c, _it, hvs__n(_s[$ "x"], -1), hvs__n(_s[$ "y"], -1), _r) == "ok") hvs_put(_c, _it, _s.x, _s.y, _r);
        else array_push(_later, _it);
    }
    for (var _i = 0; _i < array_length(_later); _i++) {
        var _it = _later[_i];
        if (hvs_add(_c, _it)) array_push(_rep.moved, _it.id); else array_push(_rep.overflow, _it);
    }
    _c.rev = 0;
    return _c;
}
/// @function hvs_load_string(text, report)
/// @description hvs_load_struct, from a JSON string. Text that is not JSON returns undefined rather than throwing.
function hvs_load_string(_s, _report = undefined) {
    if (!is_string(_s) || _s == "") return undefined;
    var _d = undefined;
    try { _d = json_parse(_s); } catch (_e) { return undefined; }
    return hvs_load_struct(_d, _report);
}
