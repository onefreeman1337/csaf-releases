/// hvs_forms.gml - the items Haversack can draw: each FORM is a small program of masses in cell units, on a footprint that fits the object. Parts are rotated BEFORE they are
/// shaded, so a rifle turned a quarter is still lit from the upper left. Use them to prototype before your own art exists, or ship them. Your own sprites work too: hvs_item_define(..., {sprite: spr_x}).
///
/// Haversack - A Spatial Inventory That Draws Its Own Containers. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function hvs__mat(name, hue)
/// @description Internal. A named material ramp. "liquid" and "cloth" take the item's hue where it has one.
function hvs__mat(_name, _hue = undefined) {
    if (!variable_global_exists("hvs__mats")) global.hvs__mats = {};
    var _key = is_undefined(_hue) ? _name : _name + "@" + string(round(_hue));
    var _r = global.hvs__mats[$ _key];
    if (!is_undefined(_r)) return _r;
    var _L = 0.5, _C = 0.02, _h = 250, _s = 0.25;
    switch (_name) {
        case "steel": _L = 0.62; _C = 0.012; _h = 250; _s = 0.30; break;
        case "gun": _L = 0.36; _C = 0.014; _h = 255; _s = 0.20; break;
        case "iron": _L = 0.42; _C = 0.008; _h = 70; _s = 0.20; break;
        case "brass": _L = 0.72; _C = 0.115; _h = 88; _s = 0.25; break;
        case "gold": _L = 0.80; _C = 0.145; _h = 88; _s = 0.22; break;
        case "silver": _L = 0.78; _C = 0.008; _h = 250; _s = 0.22; break;
        case "copper": _L = 0.60; _C = 0.115; _h = 48; _s = 0.25; break;
        case "wood": _L = 0.52; _C = 0.075; _h = 62; _s = 0.20; break;
        case "dark": _L = 0.34; _C = 0.045; _h = 50; _s = 0.14; break;
        case "leather": _L = 0.42; _C = 0.075; _h = 48; _s = 0.18; break;
        case "hide": _L = 0.60; _C = 0.075; _h = 68; _s = 0.20; break;
        case "cloth": _L = 0.50; _C = 0.050; _h = is_undefined(_hue) ? 120 : _hue; _s = 0.18; break;
        case "linen": _L = 0.85; _C = 0.022; _h = 85; _s = 0.13; break;
        case "paper": _L = 0.87; _C = 0.030; _h = 92; _s = 0.12; break;
        case "bone": _L = 0.86; _C = 0.028; _h = 88; _s = 0.14; break;
        case "rubber": _L = 0.26; _C = 0.006; _h = 250; _s = 0.13; break;
        case "red": _L = 0.52; _C = 0.175; _h = 27; _s = 0.20; break;
        case "blue": _L = 0.55; _C = 0.125; _h = 245; _s = 0.22; break;
        case "green": _L = 0.60; _C = 0.145; _h = 148; _s = 0.20; break;
        case "amber": _L = 0.74; _C = 0.145; _h = 72; _s = 0.18; break;
        case "purple": _L = 0.48; _C = 0.145; _h = 310; _s = 0.20; break;
        case "glass": _L = 0.84; _C = 0.022; _h = 205; _s = 0.11; break;
        case "herb": _L = 0.58; _C = 0.135; _h = 136; _s = 0.18; break;
        case "meat": _L = 0.52; _C = 0.105; _h = 35; _s = 0.18; break;
        case "bread": _L = 0.70; _C = 0.100; _h = 72; _s = 0.18; break;
        case "rope": _L = 0.68; _C = 0.060; _h = 85; _s = 0.17; break;
        case "white": _L = 0.92; _C = 0.006; _h = 250; _s = 0.08; break;
        case "orange": _L = 0.68; _C = 0.150; _h = 55; _s = 0.20; break;
        case "fish": _L = 0.70; _C = 0.028; _h = 225; _s = 0.20; break;
        case "liquid": _L = 0.54; _C = 0.17; _h = is_undefined(_hue) ? 27 : _hue; _s = 0.22; break;
        default: break;
    }
    _r = hvs_ramp(_L, _C, _h, _s);
    global.hvs__mats[$ _key] = _r;
    return _r;
}

/// @function hvs__fp(builder, points, material, bevel)
/// @description Internal. A mass from a flat outline, in cell units.
function hvs__fp(_k, _pts, _m, _b = 0.05) { array_push(_k.parts, { t: 0, p: _pts, m: _m, b: _b }); }
/// @function hvs__fr(builder, x, y, w, h, r, material, bevel)
/// @description Internal. A rounded rectangle mass.
function hvs__fr(_k, _x, _y, _w, _h, _r, _m, _b = 0.05) { hvs__fp(_k, hvs__rr(_x, _y, _w, _h, _r, 3), _m, _b); }
/// @function hvs__fe(builder, x, y, rx, ry, material, bevel)
/// @description Internal. An elliptical mass.
function hvs__fe(_k, _x, _y, _rx, _ry, _m, _b = 0.05) { hvs__fp(_k, hvs__ell(_x, _y, _rx, _ry, 20), _m, _b); }
/// @function hvs__fc(builder, x0, y0, x1, y1, r, material, bevel)
/// @description Internal. A capsule mass.
function hvs__fc(_k, _x0, _y0, _x1, _y1, _r, _m, _b = 0.04) { hvs__fp(_k, hvs__cap(_x0, _y0, _x1, _y1, _r, 4), _m, _b); }
/// @function hvs__fl(builder, x0, y0, x1, y1, width, material, stop, alpha)
/// @description Internal. A thin mark: a stroke in one ramp stop (0 dark to 1 light). It takes no silhouette.
function hvs__fl(_k, _x0, _y0, _x1, _y1, _w, _m, _s = 0, _a = 1) { array_push(_k.parts, { t: 1, x0: _x0, y0: _y0, x1: _x1, y1: _y1, w: _w, m: _m, s: _s, a: _a }); }
/// @function hvs__fs(builder, x, y, r, material, stop, alpha)
/// @description Internal. A soft highlight.
function hvs__fs(_k, _x, _y, _r, _m, _s, _a) { array_push(_k.parts, { t: 2, x: _x, y: _y, r: _r, m: _m, s: _s, a: _a }); }

/// @function hvs__fb(builder, spine, material, wall)
/// @description Internal. A curved bar: a spine given as x, y, half-width triples, shaded across its width as a tube. A fan cannot fill a crescent; this can.
function hvs__fb(_k, _sp, _m, _wall = 0.35) { array_push(_k.parts, { t: 3, sp: _sp, m: _m, wall: _wall }); }

/// @function hvs_forms()
/// @description The catalogue of drawn items: an array of {form, name, shape, weight, stack}. hvs_starter_items registers them all.
function hvs_forms() {
    if (variable_global_exists("hvs__formlist")) return global.hvs__formlist;
    var _L = [];
    var _a = function(_list, _f, _n, _s, _w, _st = 1, _extra = undefined) { var _e = { form: _f, name: _n, shape: _s, weight: _w, stack: _st }; if (!is_undefined(_extra)) _e.holds = _extra; array_push(_list, _e); };
    // firearms
    _a(_L, "pistol", "Service Pistol", ["XX", "X."], 1.1);
    _a(_L, "revolver", "Revolver", ["XX", "X."], 1.3);
    _a(_L, "smg", "Machine Pistol", ["XXX", ".X."], 3.0);
    _a(_L, "shotgun", "Pump Shotgun", ["XXXXX"], 3.6);
    _a(_L, "rifle", "Battle Rifle", ["XXXXX", "..X.."], 4.2);
    _a(_L, "longrifle", "Hunting Rifle", ["XXXXXX"], 4.0);
    // blades and hafts
    _a(_L, "knife", "Field Knife", ["XX"], 0.3);
    _a(_L, "shortsword", "Short Sword", ["X", "X", "X"], 1.4);
    _a(_L, "greatsword", "Greatsword", ["X", "X", "X", "X"], 3.2);
    _a(_L, "axe", "Hand Axe", ["XX", "X.", "X."], 1.8);
    _a(_L, "warhammer", "Warhammer", ["XXX", ".X.", ".X."], 3.4);
    _a(_L, "spear", "Spear", ["X", "X", "X", "X", "X"], 2.2);
    _a(_L, "pickaxe", "Pickaxe", ["XXX", ".X.", ".X."], 3.0);
    // bows and shields
    _a(_L, "bow", "Short Bow", ["XX", "XX", "XX"], 1.0);
    _a(_L, "crossbow", "Crossbow", ["XXX", ".X.", ".X."], 3.0);
    _a(_L, "roundshield", "Round Shield", ["XX", "XX"], 2.6);
    _a(_L, "kiteshield", "Kite Shield", ["XXX", "XXX", ".X."], 4.5);
    // wear
    _a(_L, "helmet", "Helmet", ["XX", "XX"], 1.6);
    _a(_L, "cuirass", "Cuirass", ["XXX", "XXX"], 6.0);
    _a(_L, "boots", "Boots", ["XX", "XX"], 1.2);
    _a(_L, "gloves", "Gauntlets", ["XX"], 0.7);
    // drink and medicine
    _a(_L, "potion", "Flask", ["X", "X"], 0.4, 1);
    _a(_L, "vial", "Vial", ["X"], 0.1, 5);
    _a(_L, "elixir", "Square Bottle", ["X", "X"], 0.5, 1);
    _a(_L, "canteen", "Canteen", ["X", "X"], 0.8);
    _a(_L, "medkit", "Field Dressing Case", ["XX", "XX"], 1.2);
    _a(_L, "bandage", "Bandage", ["X"], 0.1, 8);
    _a(_L, "syringe", "Syringe", ["XX"], 0.1, 3);
    _a(_L, "herb", "Sprig", ["X"], 0.05, 10);
    _a(_L, "mushroom", "Cap Mushroom", ["X"], 0.1, 10);
    // food
    _a(_L, "bread", "Loaf", ["XX"], 0.5, 3);
    _a(_L, "apple", "Apple", ["X"], 0.2, 10);
    _a(_L, "drumstick", "Roast Leg", ["XX"], 0.6);
    _a(_L, "fish", "Dried Fish", ["XX"], 0.5, 3);
    // munitions
    _a(_L, "ammobox", "Ammunition Can", ["XX"], 1.5, 3);
    _a(_L, "shells", "Box of Shells", ["X"], 0.5, 6);
    _a(_L, "magazine", "Magazine", ["X", "X"], 0.4, 3);
    _a(_L, "grenade", "Grenade", ["X"], 0.5, 4);
    _a(_L, "dynamite", "Dynamite", ["XX"], 0.8, 3);
    // tools
    _a(_L, "key", "Old Key", ["XX"], 0.05);
    _a(_L, "torch", "Torch", ["X", "X", "X"], 0.7);
    _a(_L, "lantern", "Lantern", ["X", "X"], 0.9);
    _a(_L, "rope", "Coil of Rope", ["XX", "XX"], 1.4);
    _a(_L, "radio", "Handset", ["X", "X"], 0.6);
    _a(_L, "flashlight", "Flashlight", ["XX"], 0.4);
    _a(_L, "battery", "Cell", ["X"], 0.1, 6);
    // valuables and paper
    _a(_L, "gem", "Cut Stone", ["X"], 0.05, 10);
    _a(_L, "coinpouch", "Coin Purse", ["X"], 0.4, 1);
    _a(_L, "goldbar", "Gold Bar", ["XX"], 2.0, 5);
    _a(_L, "ring", "Ring", ["X"], 0.02);
    _a(_L, "amulet", "Amulet", ["X", "X"], 0.1);
    _a(_L, "scroll", "Scroll", ["XX"], 0.1, 5);
    _a(_L, "book", "Bound Book", ["XX", "XX"], 1.0);
    _a(_L, "skull", "Old Skull", ["XX", "XX"], 1.0);
    _a(_L, "pouch", "Belt Pouch", ["XX", "XX"], 0.3, 1, { w: 3, h: 3, kind: "saddlebag", material: "hide", seed: 77 });
    global.hvs__formlist = _L;
    return _L;
}
/// @function hvs_starter_items()
/// @description Register every drawn form as an item, with the form's name as its id, so you can prototype before your own items exist.
/// @returns {real} How many were registered.
function hvs_starter_items() {
    var _fs = hvs_forms(), _n = array_length(_fs);
    for (var _i = 0; _i < _n; _i++) {
        var _f = _fs[_i], _o = { name: _f.name, shape: _f.shape, weight: _f.weight, stack: _f.stack, form: _f.form };
        if (variable_struct_exists(_f, "holds")) _o.holds = _f.holds;
        hvs_item_define(_f.form, _o);
    }
    return _n;
}

/// @function hvs__form_build(form, builder)
/// @description Internal. Run one form's program. Units are cells, at rotation 0.
function hvs__form_build(_f, _k) {
    switch (_f) {
    case "pistol":
        hvs__fp(_k, [0.20, 0.74, 0.82, 0.74, 0.74, 1.86, 0.14, 1.86], "rubber", 0.05);
        for (var _i = 0; _i < 6; _i++) hvs__fl(_k, 0.26, 1.0 + _i * 0.13, 0.70, 1.0 + _i * 0.13, 0.025, "gun", 0.9, 0.6);
        hvs__fp(_k, hvs__rr(0.86, 0.62, 0.36, 0.34, 0.1, 3), "gun", 0.02); hvs__fp(_k, hvs__rr(0.93, 0.67, 0.22, 0.19, 0.06, 3), "rubber", 0.01);
        hvs__fr(_k, 0.10, 0.40, 1.64, 0.28, 0.03, "gun", 0.04);
        hvs__fr(_k, 0.08, 0.18, 1.84, 0.30, 0.04, "steel", 0.05);
        for (var _i = 0; _i < 5; _i++) hvs__fl(_k, 0.20 + _i * 0.07, 0.22, 0.20 + _i * 0.07, 0.44, 0.03, "gun", 0, 0.8);
        hvs__fl(_k, 1.00, 0.30, 1.62, 0.30, 0.05, "gun", 0, 0.7);
        hvs__fr(_k, 1.74, 0.11, 0.08, 0.09, 0.01, "gun", 0.01);
        break;
    case "revolver":
        hvs__fp(_k, [0.26, 0.72, 0.74, 0.76, 0.66, 1.26, 0.74, 1.84, 0.20, 1.86, 0.10, 1.30], "wood", 0.06);
        hvs__fl(_k, 0.30, 1.0, 0.58, 1.6, 0.03, "wood", 0, 0.5); hvs__fl(_k, 0.42, 0.96, 0.60, 1.3, 0.03, "wood", 0, 0.5);
        hvs__fp(_k, hvs__rr(0.72, 0.68, 0.30, 0.28, 0.1, 3), "gun", 0.02); hvs__fp(_k, hvs__rr(0.78, 0.72, 0.18, 0.16, 0.05, 3), "rubber", 0.01);
        hvs__fc(_k, 0.98, 0.32, 1.86, 0.32, 0.11, "steel", 0.04);
        hvs__fl(_k, 1.02, 0.27, 1.82, 0.27, 0.03, "white", 0.9, 0.5);
        hvs__fr(_k, 0.26, 0.14, 0.46, 0.62, 0.08, "gun", 0.05);
        hvs__fr(_k, 0.54, 0.18, 0.46, 0.46, 0.09, "steel", 0.06);
        for (var _i = 0; _i < 3; _i++) hvs__fl(_k, 0.59, 0.28 + _i * 0.13, 0.95, 0.28 + _i * 0.13, 0.05, "gun", 0, 0.75);
        hvs__fr(_k, 1.74, 0.10, 0.07, 0.11, 0.01, "gun", 0.01);
        break;
    case "smg":
        hvs__fp(_k, [1.20, 0.68, 1.74, 0.68, 1.68, 1.90, 1.28, 1.90], "gun", 0.05);
        for (var _i = 0; _i < 5; _i++) hvs__fl(_k, 1.28, 0.96 + _i * 0.17, 1.66, 0.96 + _i * 0.17, 0.025, "steel", 0.8, 0.45);
        hvs__fp(_k, [0.10, 0.34, 0.60, 0.40, 0.60, 0.62, 0.24, 0.92, 0.10, 0.86], "rubber", 0.04);
        hvs__fc(_k, 2.20, 0.38, 2.90, 0.38, 0.07, "gun", 0.03);
        hvs__fr(_k, 2.18, 0.28, 0.34, 0.20, 0.03, "rubber", 0.03);
        hvs__fr(_k, 0.56, 0.20, 1.72, 0.50, 0.05, "steel", 0.06);
        hvs__fr(_k, 1.42, 0.26, 0.58, 0.14, 0.02, "rubber", 0.02);
        for (var _i = 0; _i < 5; _i++) hvs__fl(_k, 0.72 + _i * 0.12, 0.30, 0.72 + _i * 0.12, 0.60, 0.04, "gun", 0, 0.6);
        break;
    case "shotgun":
        hvs__fp(_k, [0.06, 0.34, 0.36, 0.20, 1.20, 0.26, 1.20, 0.70, 0.76, 0.70, 0.30, 0.90, 0.06, 0.90], "wood", 0.06);
        hvs__fl(_k, 0.30, 0.34, 1.12, 0.34, 0.02, "bread", 0.9, 0.5); hvs__fl(_k, 0.22, 0.62, 0.78, 0.50, 0.02, "dark", 0.4, 0.5);
        hvs__fr(_k, 1.16, 0.22, 0.86, 0.52, 0.05, "gun", 0.06);
        hvs__fc(_k, 2.00, 0.36, 4.88, 0.36, 0.07, "steel", 0.03);
        hvs__fc(_k, 2.00, 0.56, 4.28, 0.56, 0.08, "gun", 0.03);
        hvs__fr(_k, 2.46, 0.42, 1.00, 0.28, 0.08, "wood", 0.05);
        for (var _i = 0; _i < 7; _i++) hvs__fl(_k, 2.56 + _i * 0.12, 0.45, 2.56 + _i * 0.12, 0.67, 0.03, "dark", 0.2, 0.55);
        hvs__fr(_k, 4.70, 0.20, 0.08, 0.10, 0.01, "brass", 0.01);
        break;
    case "rifle":
        hvs__fp(_k, [2.16, 0.70, 2.86, 0.70, 2.78, 1.86, 2.24, 1.86], "gun", 0.05);
        for (var _i = 0; _i < 6; _i++) hvs__fl(_k, 2.26, 0.92 + _i * 0.15, 2.76, 0.92 + _i * 0.15, 0.025, "steel", 0.7, 0.45);
        hvs__fp(_k, [0.06, 0.28, 1.18, 0.34, 1.18, 0.68, 0.42, 0.68, 0.14, 0.92, 0.06, 0.90], "wood", 0.05);
        hvs__fr(_k, 1.14, 0.26, 2.02, 0.46, 0.04, "gun", 0.05);
        hvs__fc(_k, 3.14, 0.42, 4.88, 0.42, 0.06, "steel", 0.03);
        hvs__fr(_k, 3.10, 0.30, 0.86, 0.26, 0.06, "wood", 0.04);
        hvs__fc(_k, 1.54, 0.16, 2.66, 0.16, 0.09, "rubber", 0.03); hvs__fs(_k, 2.68, 0.15, 0.08, "glass", 1, 0.8);
        hvs__fl(_k, 1.28, 0.42, 2.04, 0.42, 0.05, "rubber", 0.1, 0.8);
        hvs__fr(_k, 4.74, 0.26, 0.14, 0.31, 0.02, "gun", 0.02);
        break;
    case "longrifle":
        hvs__fp(_k, [0.05, 0.32, 0.34, 0.20, 1.40, 0.28, 3.60, 0.30, 3.60, 0.58, 1.26, 0.64, 0.80, 0.82, 0.05, 0.88], "wood", 0.06);
        hvs__fl(_k, 0.28, 0.34, 3.5, 0.40, 0.02, "bread", 0.9, 0.45); hvs__fl(_k, 0.28, 0.62, 1.2, 0.50, 0.02, "dark", 0.4, 0.5);
        hvs__fc(_k, 1.34, 0.32, 5.90, 0.32, 0.06, "gun", 0.03);
        hvs__fr(_k, 1.34, 0.20, 0.96, 0.30, 0.04, "steel", 0.04);
        hvs__fc(_k, 1.90, 0.32, 2.20, 0.54, 0.05, "steel", 0.02);
        hvs__fc(_k, 1.28, 0.13, 2.74, 0.13, 0.07, "rubber", 0.03); hvs__fs(_k, 2.76, 0.13, 0.07, "glass", 1, 0.8);
        hvs__fr(_k, 5.76, 0.18, 0.06, 0.10, 0.01, "brass", 0.01);
        break;
    case "knife":
        hvs__fp(_k, [0.78, 0.30, 1.42, 0.30, 1.92, 0.36, 1.46, 0.70, 0.78, 0.70], "steel", 0.05);
        hvs__fl(_k, 0.84, 0.40, 1.60, 0.40, 0.04, "white", 0.9, 0.5);
        hvs__fr(_k, 0.66, 0.20, 0.14, 0.60, 0.03, "brass", 0.03);
        hvs__fr(_k, 0.08, 0.30, 0.60, 0.40, 0.09, "leather", 0.05);
        for (var _i = 0; _i < 4; _i++) hvs__fl(_k, 0.16 + _i * 0.13, 0.32, 0.16 + _i * 0.13, 0.68, 0.03, "dark", 0.1, 0.7);
        break;
    case "shortsword":
        hvs__fp(_k, [0.50, 0.05, 0.70, 0.30, 0.68, 2.10, 0.32, 2.10, 0.30, 0.30], "steel", 0.05);
        hvs__fl(_k, 0.50, 0.26, 0.50, 2.06, 0.05, "gun", 0.3, 0.6);
        hvs__fc(_k, 0.14, 2.14, 0.86, 2.14, 0.07, "brass", 0.03);
        hvs__fr(_k, 0.40, 2.22, 0.20, 0.50, 0.04, "leather", 0.03);
        hvs__fe(_k, 0.50, 2.82, 0.10, 0.10, "brass", 0.03);
        break;
    case "greatsword":
        hvs__fp(_k, [0.50, 0.04, 0.72, 0.30, 0.70, 2.78, 0.30, 2.78, 0.28, 0.30], "steel", 0.05);
        hvs__fl(_k, 0.50, 0.26, 0.50, 2.74, 0.06, "gun", 0.3, 0.6);
        hvs__fp(_k, [0.04, 2.72, 0.96, 2.72, 0.90, 2.92, 0.10, 2.92], "iron", 0.04);
        hvs__fr(_k, 0.40, 2.92, 0.20, 0.82, 0.04, "leather", 0.03);
        for (var _i = 0; _i < 6; _i++) hvs__fl(_k, 0.41, 3.02 + _i * 0.12, 0.59, 3.06 + _i * 0.12, 0.03, "dark", 0.1, 0.6);
        hvs__fe(_k, 0.50, 3.84, 0.12, 0.12, "iron", 0.04);
        break;
    case "axe":
        hvs__fc(_k, 0.44, 0.12, 0.44, 2.88, 0.09, "wood", 0.04);
        hvs__fl(_k, 0.41, 0.2, 0.41, 2.8, 0.025, "bread", 0.9, 0.45);
        hvs__fp(_k, [0.30, 0.20, 0.74, 0.28, 1.86, 0.08, 1.90, 0.40, 1.86, 0.90, 0.72, 0.68, 0.30, 0.70], "steel", 0.07);
        hvs__fl(_k, 1.70, 0.20, 1.72, 0.78, 0.09, "white", 0.9, 0.55);
        hvs__fr(_k, 0.30, 0.18, 0.28, 0.54, 0.03, "leather", 0.03);
        hvs__fr(_k, 0.31, 2.30, 0.26, 0.36, 0.03, "leather", 0.03);
        break;
    case "warhammer":
        hvs__fc(_k, 1.50, 0.70, 1.50, 2.92, 0.09, "dark", 0.04);
        hvs__fl(_k, 1.47, 0.8, 1.47, 2.84, 0.025, "wood", 1, 0.5);
        hvs__fr(_k, 1.38, 2.20, 0.24, 0.56, 0.03, "leather", 0.03);
        hvs__fr(_k, 0.72, 0.10, 1.56, 0.70, 0.05, "iron", 0.08);
        hvs__fr(_k, 0.10, 0.12, 0.68, 0.66, 0.05, "steel", 0.08);
        hvs__fp(_k, [2.24, 0.14, 2.92, 0.40, 2.92, 0.50, 2.24, 0.76], "steel", 0.07);
        hvs__fl(_k, 1.20, 0.10, 1.20, 0.80, 0.05, "brass", 0.8, 0.9); hvs__fl(_k, 1.80, 0.10, 1.80, 0.80, 0.05, "brass", 0.8, 0.9);
        break;
    case "spear":
        hvs__fc(_k, 0.50, 1.00, 0.50, 4.90, 0.06, "wood", 0.03);
        hvs__fl(_k, 0.48, 1.1, 0.48, 4.8, 0.02, "bread", 0.9, 0.45);
        hvs__fp(_k, [0.50, 0.05, 0.76, 0.56, 0.60, 1.06, 0.40, 1.06, 0.24, 0.56], "steel", 0.06);
        hvs__fl(_k, 0.50, 0.14, 0.50, 1.0, 0.03, "gun", 0.3, 0.55);
        hvs__fr(_k, 0.40, 1.04, 0.20, 0.26, 0.03, "leather", 0.03);
        hvs__fc(_k, 0.50, 1.34, 0.72, 1.64, 0.03, "liquid", 0.01); hvs__fc(_k, 0.50, 1.34, 0.30, 1.68, 0.03, "liquid", 0.01);
        break;
    case "pickaxe":
        hvs__fc(_k, 1.50, 0.44, 1.50, 2.90, 0.09, "wood", 0.04);
        hvs__fl(_k, 1.47, 0.6, 1.47, 2.84, 0.025, "bread", 0.9, 0.45);
        hvs__fb(_k, [0.08, 0.84, 0.01, 0.42, 0.46, 0.08, 0.92, 0.26, 0.13, 1.50, 0.20, 0.15, 2.08, 0.26, 0.13, 2.58, 0.46, 0.08, 2.92, 0.84, 0.01], "steel");
        hvs__fr(_k, 1.32, 0.10, 0.36, 0.48, 0.04, "iron", 0.05);
        break;
    case "bow":
        hvs__fl(_k, 1.34, 0.22, 1.34, 2.78, 0.035, "linen", 0.8, 1);
        hvs__fb(_k, [1.40, 0.14, 0.03, 1.02, 0.42, 0.07, 0.62, 0.96, 0.11, 0.42, 1.50, 0.15, 0.62, 2.04, 0.11, 1.02, 2.58, 0.07, 1.40, 2.86, 0.03], "wood");
        hvs__fr(_k, 0.24, 1.26, 0.30, 0.48, 0.06, "leather", 0.04);
        hvs__fl(_k, 1.34, 1.5, 1.84, 1.5, 0.04, "wood", 0.8, 1);
        hvs__fp(_k, [1.96, 1.50, 1.74, 1.40, 1.74, 1.60], "steel", 0.02);
        break;
    case "crossbow":
        hvs__fc(_k, 1.50, 0.34, 1.50, 2.86, 0.14, "wood", 0.05);
        hvs__fl(_k, 1.47, 0.5, 1.47, 2.7, 0.03, "dark", 0.2, 0.6);
        hvs__fb(_k, [0.12, 0.92, 0.03, 0.46, 0.46, 0.07, 1.00, 0.24, 0.10, 1.50, 0.20, 0.11, 2.00, 0.24, 0.10, 2.54, 0.46, 0.07, 2.88, 0.92, 0.03], "steel");
        hvs__fl(_k, 0.14, 0.92, 1.50, 1.32, 0.03, "linen", 0.7, 1); hvs__fl(_k, 2.86, 0.92, 1.50, 1.32, 0.03, "linen", 0.7, 1);
        hvs__fr(_k, 1.38, 1.26, 0.24, 0.26, 0.04, "iron", 0.04);
        hvs__fp(_k, [1.50, 0.02, 1.58, 0.30, 1.42, 0.30], "steel", 0.02);
        break;
    case "roundshield":
        hvs__fe(_k, 1, 1, 0.92, 0.92, "wood", 0.10);
        for (var _i = -3; _i <= 3; _i++) hvs__fl(_k, 1 + _i * 0.24, 1 - sqrt(max(0, 0.72 - power(_i * 0.24, 2))), 1 + _i * 0.24, 1 + sqrt(max(0, 0.72 - power(_i * 0.24, 2))), 0.025, "dark", 0.2, 0.7);
        hvs__fe(_k, 1, 1, 0.30, 0.30, "steel", 0.09);
        for (var _i = 0; _i < 8; _i++) { var _a = _i / 8 * 2 * pi; hvs__fe(_k, 1 + cos(_a) * 0.78, 1 + sin(_a) * 0.78, 0.045, 0.045, "brass", 0.02); }
        break;
    case "kiteshield":
        hvs__fp(_k, [0.20, 0.08, 2.80, 0.08, 2.84, 0.86, 2.56, 1.50, 1.50, 2.94, 0.44, 1.50, 0.16, 0.86], "steel", 0.08);
        hvs__fp(_k, [0.36, 0.24, 2.64, 0.24, 2.68, 0.84, 2.42, 1.40, 1.50, 2.66, 0.58, 1.40, 0.32, 0.84], "liquid", 0.03);
        hvs__fp(_k, [1.34, 0.24, 1.66, 0.24, 1.66, 2.42, 1.50, 2.66, 1.34, 2.42], "bone", 0.02);
        hvs__fp(_k, [0.38, 0.84, 2.62, 0.84, 2.58, 1.14, 0.46, 1.14], "bone", 0.02);
        break;
    case "helmet":
        hvs__fp(_k, [0.20, 1.10, 0.30, 0.56, 0.62, 0.20, 1.00, 0.10, 1.38, 0.20, 1.70, 0.56, 1.80, 1.10, 1.80, 1.72, 1.34, 1.88, 1.34, 1.30, 0.66, 1.30, 0.66, 1.88, 0.20, 1.72], "steel", 0.09);
        hvs__fr(_k, 0.34, 0.92, 1.32, 0.16, 0.02, "rubber", 0.02);
        hvs__fc(_k, 1.0, 1.04, 1.0, 1.78, 0.09, "steel", 0.04);
        hvs__fl(_k, 1.0, 0.14, 1.0, 0.86, 0.10, "brass", 0.75, 0.95);
        for (var _i = 0; _i < 5; _i++) hvs__fe(_k, 0.30 + _i * 0.35, 0.78 + abs(_i - 2) * 0.05, 0.03, 0.03, "brass", 0.01);
        break;
    case "cuirass":
        hvs__fp(_k, [0.46, 0.12, 1.18, 0.34, 1.50, 0.62, 1.82, 0.34, 2.54, 0.12, 2.86, 0.56, 2.50, 0.84, 2.42, 1.84, 0.58, 1.84, 0.50, 0.84, 0.14, 0.56], "steel", 0.09);
        hvs__fl(_k, 1.50, 0.70, 1.50, 1.80, 0.05, "gun", 0.3, 0.6);
        hvs__fl(_k, 0.72, 1.28, 2.28, 1.28, 0.04, "gun", 0.3, 0.45);
        for (var _i = 0; _i < 5; _i++) hvs__fe(_k, 0.72 + _i * 0.39, 1.68, 0.03, 0.03, "brass", 0.01);
        hvs__fr(_k, 0.74, 0.70, 0.44, 0.44, 0.15, "steel", 0.05); hvs__fr(_k, 1.82, 0.70, 0.44, 0.44, 0.15, "steel", 0.05);
        break;
    case "boots":
        hvs__fp(_k, [0.12, 0.10, 0.62, 0.10, 0.70, 1.20, 0.92, 1.42, 0.94, 1.84, 0.12, 1.84], "leather", 0.06);
        hvs__fr(_k, 0.10, 1.74, 0.86, 0.14, 0.03, "rubber", 0.02);
        hvs__fl(_k, 0.14, 0.26, 0.64, 0.26, 0.07, "dark", 0.0, 0.85);
        hvs__fp(_k, [1.08, 0.10, 1.58, 0.10, 1.66, 1.20, 1.88, 1.42, 1.90, 1.84, 1.08, 1.84], "leather", 0.06);
        hvs__fr(_k, 1.06, 1.74, 0.86, 0.14, 0.03, "rubber", 0.02);
        hvs__fl(_k, 1.10, 0.26, 1.60, 0.26, 0.07, "dark", 0.0, 0.85);
        for (var _i = 0; _i < 4; _i++) { hvs__fl(_k, 0.30, 0.46 + _i * 0.18, 0.56, 0.46 + _i * 0.18, 0.03, "linen", 0.8, 0.9); hvs__fl(_k, 1.26, 0.46 + _i * 0.18, 1.52, 0.46 + _i * 0.18, 0.03, "linen", 0.8, 0.9); }
        break;
    case "gloves":
        for (var _h = 0; _h < 2; _h++) {
            var _ox = _h * 1.0;
            hvs__fr(_k, _ox + 0.14, 0.40, 0.72, 0.52, 0.10, "steel", 0.05);
            for (var _i = 0; _i < 4; _i++) hvs__fc(_k, _ox + 0.24 + _i * 0.17, 0.14, _ox + 0.24 + _i * 0.17, 0.42, 0.06, "gun", 0.02);
            hvs__fl(_k, _ox + 0.16, 0.70, _ox + 0.84, 0.70, 0.05, "gun", 0.2, 0.7);
        }
        break;
    case "potion":
        hvs__fe(_k, 0.5, 1.30, 0.42, 0.56, "glass", 0.03);
        hvs__fp(_k, hvs__ell(0.5, 1.36, 0.34, 0.46, 18), "liquid", 0.05);
        hvs__fl(_k, 0.26, 1.08, 0.74, 1.08, 0.04, "white", 0.9, 0.4);
        hvs__fr(_k, 0.36, 0.34, 0.28, 0.48, 0.04, "glass", 0.03);
        hvs__fr(_k, 0.32, 0.12, 0.36, 0.26, 0.05, "wood", 0.04);
        hvs__fs(_k, 0.34, 1.12, 0.14, "white", 1, 0.8);
        break;
    case "vial":
        hvs__fr(_k, 0.34, 0.14, 0.32, 0.76, 0.12, "glass", 0.02);
        hvs__fr(_k, 0.38, 0.36, 0.24, 0.50, 0.10, "liquid", 0.03);
        hvs__fr(_k, 0.32, 0.08, 0.36, 0.14, 0.03, "wood", 0.03);
        hvs__fs(_k, 0.44, 0.50, 0.06, "white", 1, 0.8);
        break;
    case "elixir":
        hvs__fr(_k, 0.16, 0.66, 0.68, 1.22, 0.08, "glass", 0.03);
        hvs__fr(_k, 0.22, 0.86, 0.56, 0.96, 0.05, "liquid", 0.04);
        hvs__fr(_k, 0.38, 0.30, 0.24, 0.40, 0.03, "glass", 0.02);
        hvs__fr(_k, 0.34, 0.12, 0.32, 0.22, 0.04, "brass", 0.04);
        hvs__fr(_k, 0.26, 1.16, 0.48, 0.34, 0.02, "paper", 0.02);
        hvs__fl(_k, 0.32, 1.26, 0.68, 1.26, 0.03, "dark", 0.2, 0.8); hvs__fl(_k, 0.32, 1.38, 0.60, 1.38, 0.03, "dark", 0.2, 0.8);
        break;
    case "canteen":
        hvs__fe(_k, 0.5, 1.16, 0.42, 0.72, "cloth", 0.08);
        hvs__fl(_k, 0.5, 0.48, 0.5, 1.86, 0.03, "dark", 0.15, 0.6);
        hvs__fr(_k, 0.38, 0.22, 0.24, 0.26, 0.04, "steel", 0.04);
        hvs__fr(_k, 0.34, 0.10, 0.32, 0.16, 0.04, "gun", 0.03);
        hvs__fc(_k, 0.12, 0.70, 0.12, 1.50, 0.03, "leather", 0.01); hvs__fc(_k, 0.88, 0.70, 0.88, 1.50, 0.03, "leather", 0.01);
        break;
    case "medkit":
        hvs__fr(_k, 0.68, 0.10, 0.64, 0.30, 0.06, "gun", 0.03);
        hvs__fr(_k, 0.10, 0.28, 1.80, 1.60, 0.12, "white", 0.09);
        hvs__fl(_k, 0.12, 0.72, 1.88, 0.72, 0.04, "gun", 0.3, 0.45);
        hvs__fr(_k, 0.80, 0.82, 0.40, 0.92, 0.03, "red", 0.03); hvs__fr(_k, 0.54, 1.08, 0.92, 0.40, 0.03, "red", 0.03);
        hvs__fr(_k, 0.22, 0.58, 0.20, 0.26, 0.03, "steel", 0.03); hvs__fr(_k, 1.58, 0.58, 0.20, 0.26, 0.03, "steel", 0.03);
        break;
    case "bandage":
        // a flat field dressing in its paper wrapper, a red cross on it: a roll of white read as something else entirely
        hvs__fp(_k, [0.14, 0.26, 0.70, 0.18, 0.88, 0.36, 0.88, 0.76, 0.30, 0.86, 0.12, 0.66], "linen", 0.05);
        hvs__fl(_k, 0.16, 0.30, 0.34, 0.46, 0.02, "dark", 0.3, 0.5); hvs__fl(_k, 0.72, 0.20, 0.34, 0.46, 0.02, "dark", 0.3, 0.5); hvs__fl(_k, 0.34, 0.46, 0.32, 0.84, 0.02, "dark", 0.3, 0.5);
        hvs__fr(_k, 0.50, 0.38, 0.13, 0.36, 0.01, "red", 0.01); hvs__fr(_k, 0.385, 0.495, 0.36, 0.13, 0.01, "red", 0.01);
        break;
    case "syringe":
        hvs__fr(_k, 0.34, 0.32, 0.96, 0.36, 0.05, "glass", 0.02);
        hvs__fr(_k, 0.60, 0.37, 0.66, 0.26, 0.03, "liquid", 0.03);
        for (var _i = 0; _i < 6; _i++) hvs__fl(_k, 0.46 + _i * 0.14, 0.33, 0.46 + _i * 0.14, 0.46, 0.015, "gun", 0, 0.8);
        hvs__fr(_k, 0.08, 0.44, 0.30, 0.12, 0.02, "steel", 0.02); hvs__fr(_k, 0.06, 0.26, 0.08, 0.48, 0.02, "steel", 0.02);
        hvs__fr(_k, 1.28, 0.42, 0.16, 0.16, 0.03, "steel", 0.02);
        hvs__fl(_k, 1.42, 0.50, 1.94, 0.50, 0.025, "silver", 1, 1);
        break;
    case "herb":
        hvs__fl(_k, 0.5, 0.92, 0.5, 0.40, 0.05, "herb", 0.2, 1);
        var _lv = [[0.5, 0.20, 0.13, 0.24], [0.26, 0.42, 0.17, 0.12], [0.74, 0.42, 0.17, 0.12], [0.28, 0.66, 0.16, 0.11], [0.72, 0.66, 0.16, 0.11]];
        for (var _i = 0; _i < 5; _i++) hvs__fp(_k, hvs__ell(_lv[_i][0], _lv[_i][1], _lv[_i][2], _lv[_i][3], 14), "herb", 0.03);
        for (var _i = 1; _i < 5; _i++) hvs__fl(_k, 0.5, _lv[_i][1] + 0.02, _lv[_i][0] + (_lv[_i][0] < 0.5 ? -0.1 : 0.1), _lv[_i][1], 0.015, "herb", 0.1, 0.8);
        break;
    case "mushroom":
        hvs__fp(_k, [0.36, 0.50, 0.64, 0.50, 0.68, 0.88, 0.32, 0.88], "bone", 0.05);
        hvs__fp(_k, [0.06, 0.54, 0.16, 0.26, 0.50, 0.08, 0.84, 0.26, 0.94, 0.54, 0.66, 0.60, 0.34, 0.60], "red", 0.05);
        hvs__fe(_k, 0.34, 0.30, 0.06, 0.05, "white", 0.01); hvs__fe(_k, 0.62, 0.24, 0.07, 0.05, "white", 0.01); hvs__fe(_k, 0.72, 0.44, 0.05, 0.04, "white", 0.01); hvs__fe(_k, 0.24, 0.47, 0.04, 0.03, "white", 0.01);
        break;
    case "bread":
        hvs__fp(_k, hvs__rr(0.08, 0.20, 1.84, 0.66, 0.30, 4), "bread", 0.09);
        for (var _i = 0; _i < 4; _i++) hvs__fl(_k, 0.42 + _i * 0.38, 0.26, 0.58 + _i * 0.38, 0.54, 0.05, "linen", 0.5, 0.9);
        break;
    case "apple":
        hvs__fe(_k, 0.36, 0.56, 0.26, 0.32, "red", 0.06); hvs__fe(_k, 0.62, 0.56, 0.28, 0.33, "red", 0.06);
        hvs__fl(_k, 0.50, 0.28, 0.54, 0.14, 0.04, "dark", 0.2, 1);
        hvs__fp(_k, [0.54, 0.22, 0.70, 0.08, 0.84, 0.14, 0.70, 0.26], "herb", 0.02);
        hvs__fs(_k, 0.34, 0.42, 0.10, "white", 1, 0.6);
        break;
    case "drumstick":
        hvs__fc(_k, 1.20, 0.50, 1.84, 0.50, 0.06, "bone", 0.02);
        hvs__fe(_k, 1.86, 0.42, 0.08, 0.08, "bone", 0.02); hvs__fe(_k, 1.86, 0.58, 0.08, 0.08, "bone", 0.02);
        hvs__fp(_k, [0.10, 0.50, 0.26, 0.20, 0.66, 0.10, 1.08, 0.26, 1.34, 0.42, 1.34, 0.58, 1.08, 0.74, 0.66, 0.90, 0.26, 0.80], "meat", 0.09);
        hvs__fs(_k, 0.48, 0.34, 0.18, "amber", 0.9, 0.5);
        break;
    case "fish":
        hvs__fp(_k, [0.08, 0.50, 0.30, 0.28, 0.80, 0.18, 1.34, 0.30, 1.60, 0.46, 1.60, 0.54, 1.34, 0.70, 0.80, 0.82, 0.30, 0.72], "fish", 0.05);
        hvs__fp(_k, [1.52, 0.50, 1.92, 0.20, 1.86, 0.50, 1.92, 0.80], "fish", 0.03);
        hvs__fe(_k, 0.32, 0.42, 0.04, 0.04, "rubber", 0.01);
        hvs__fl(_k, 0.46, 0.32, 0.46, 0.70, 0.03, "gun", 0.1, 0.6);
        for (var _i = 0; _i < 4; _i++) hvs__fl(_k, 0.62 + _i * 0.2, 0.30, 0.62 + _i * 0.2, 0.70, 0.02, "gun", 0.2, 0.4);
        break;
    case "ammobox":
        hvs__fr(_k, 0.08, 0.20, 1.84, 0.70, 0.04, "cloth", 0.06);
        hvs__fr(_k, 0.04, 0.14, 1.92, 0.20, 0.03, "cloth", 0.04);
        hvs__fc(_k, 0.66, 0.11, 1.34, 0.11, 0.05, "gun", 0.02);
        hvs__fr(_k, 1.58, 0.16, 0.20, 0.34, 0.02, "steel", 0.03);
        hvs__fl(_k, 0.30, 0.56, 1.30, 0.56, 0.06, "linen", 0.8, 0.85); hvs__fl(_k, 0.30, 0.72, 0.96, 0.72, 0.05, "linen", 0.8, 0.85);
        break;
    case "shells":
        hvs__fr(_k, 0.08, 0.34, 0.84, 0.58, 0.03, "paper", 0.05);
        for (var _i = 0; _i < 4; _i++) { hvs__fr(_k, 0.12 + _i * 0.195, 0.16, 0.17, 0.24, 0.03, "red", 0.02); hvs__fr(_k, 0.12 + _i * 0.195, 0.30, 0.17, 0.08, 0.01, "brass", 0.01); }
        hvs__fl(_k, 0.20, 0.58, 0.80, 0.58, 0.05, "red", 0.5, 0.9); hvs__fl(_k, 0.20, 0.72, 0.60, 0.72, 0.04, "dark", 0.2, 0.7);
        break;
    case "magazine":
        hvs__fp(_k, [0.22, 0.20, 0.72, 0.20, 0.82, 0.98, 0.84, 1.88, 0.30, 1.88, 0.30, 1.02], "gun", 0.06);
        for (var _i = 0; _i < 6; _i++) hvs__fl(_k, 0.36, 0.56 + _i * 0.20, 0.72, 0.56 + _i * 0.20, 0.025, "steel", 0.7, 0.5);
        hvs__fr(_k, 0.30, 0.08, 0.34, 0.16, 0.05, "brass", 0.03);
        break;
    case "grenade":
        hvs__fe(_k, 0.48, 0.56, 0.30, 0.36, "cloth", 0.07);
        for (var _i = 0; _i < 3; _i++) hvs__fl(_k, 0.20, 0.42 + _i * 0.15, 0.76, 0.42 + _i * 0.15, 0.025, "dark", 0.1, 0.65);
        for (var _i = 0; _i < 3; _i++) hvs__fl(_k, 0.34 + _i * 0.14, 0.24, 0.34 + _i * 0.14, 0.88, 0.025, "dark", 0.1, 0.65);
        hvs__fr(_k, 0.36, 0.08, 0.28, 0.18, 0.02, "steel", 0.03);
        hvs__fp(_k, [0.62, 0.14, 0.92, 0.26, 0.88, 0.64, 0.78, 0.62, 0.78, 0.32, 0.60, 0.24], "steel", 0.02);
        break;
    case "dynamite":
        for (var _i = 0; _i < 3; _i++) { hvs__fr(_k, 0.14, 0.18 + _i * 0.24, 1.62, 0.25, 0.04, "red", 0.04); }
        hvs__fr(_k, 0.60, 0.14, 0.14, 0.76, 0.01, "rope", 0.02); hvs__fr(_k, 1.20, 0.14, 0.14, 0.76, 0.01, "rope", 0.02);
        hvs__fl(_k, 1.74, 0.42, 1.90, 0.24, 0.03, "gun", 0.2, 1); hvs__fs(_k, 1.90, 0.22, 0.07, "amber", 1, 0.9);
        break;
    case "key":
        hvs__fc(_k, 0.62, 0.50, 1.88, 0.50, 0.06, "brass", 0.02);
        hvs__fr(_k, 1.52, 0.52, 0.10, 0.24, 0.01, "brass", 0.02); hvs__fr(_k, 1.70, 0.52, 0.12, 0.30, 0.01, "brass", 0.02);
        hvs__fe(_k, 0.38, 0.50, 0.30, 0.30, "brass", 0.07); hvs__fe(_k, 0.38, 0.50, 0.14, 0.14, "dark", 0.02);
        break;
    case "torch":
        hvs__fc(_k, 0.50, 0.90, 0.50, 2.92, 0.09, "wood", 0.04);
        hvs__fl(_k, 0.47, 1.0, 0.47, 2.84, 0.025, "bread", 0.9, 0.45);
        hvs__fp(_k, [0.28, 0.50, 0.72, 0.50, 0.66, 1.02, 0.34, 1.02], "linen", 0.04);
        for (var _i = 0; _i < 4; _i++) hvs__fl(_k, 0.30, 0.60 + _i * 0.12, 0.70, 0.56 + _i * 0.12, 0.03, "dark", 0.1, 0.6);
        hvs__fp(_k, [0.50, 0.05, 0.74, 0.32, 0.72, 0.52, 0.28, 0.52, 0.26, 0.32], "orange", 0.04);
        hvs__fp(_k, [0.50, 0.20, 0.62, 0.38, 0.60, 0.50, 0.40, 0.50, 0.38, 0.38], "amber", 0.03);
        break;
    case "lantern":
        hvs__fp(_k, [0.28, 0.30, 0.34, 0.08, 0.66, 0.08, 0.72, 0.30, 0.64, 0.24, 0.36, 0.24], "iron", 0.02);
        hvs__fp(_k, [0.18, 0.60, 0.50, 0.26, 0.82, 0.60], "iron", 0.04);
        hvs__fr(_k, 0.24, 0.58, 0.52, 0.86, 0.04, "amber", 0.03);
        hvs__fs(_k, 0.50, 1.00, 0.30, "white", 1, 0.9);
        hvs__fr(_k, 0.20, 0.54, 0.60, 0.08, 0.01, "iron", 0.02); hvs__fr(_k, 0.14, 1.42, 0.72, 0.42, 0.04, "iron", 0.05);
        hvs__fl(_k, 0.26, 0.60, 0.26, 1.44, 0.04, "iron", 0.1, 1); hvs__fl(_k, 0.74, 0.60, 0.74, 1.44, 0.04, "iron", 0.1, 1); hvs__fl(_k, 0.50, 0.60, 0.50, 1.44, 0.03, "iron", 0.1, 0.8);
        break;
    case "rope":
        for (var _i = 0; _i < 4; _i++) {
            var _r0 = 0.88 - _i * 0.17;
            hvs__fp(_k, hvs__ell(1, 1, _r0, _r0, 24), "rope", 0.07);
            for (var _j = 0; _j < 18; _j++) { var _a2 = _j / 18 * 2 * pi; hvs__fl(_k, 1 + cos(_a2) * (_r0 - 0.13), 1 + sin(_a2) * (_r0 - 0.13), 1 + cos(_a2 + 0.2) * (_r0 - 0.01), 1 + sin(_a2 + 0.2) * (_r0 - 0.01), 0.018, "dark", 0.5, 0.45); }
        }
        hvs__fe(_k, 1, 1, 0.20, 0.20, "dark", 0.04);
        break;
    case "radio":
        hvs__fr(_k, 0.62, 0.06, 0.08, 0.44, 0.01, "rubber", 0.02);
        hvs__fr(_k, 0.18, 0.42, 0.64, 1.48, 0.08, "rubber", 0.06);
        hvs__fr(_k, 0.28, 0.54, 0.44, 0.28, 0.02, "green", 0.02);
        for (var _i = 0; _i < 5; _i++) hvs__fl(_k, 0.30, 1.00 + _i * 0.10, 0.70, 1.00 + _i * 0.10, 0.04, "gun", 0.5, 1);
        hvs__fr(_k, 0.30, 1.60, 0.18, 0.18, 0.03, "red", 0.02); hvs__fr(_k, 0.54, 1.60, 0.18, 0.18, 0.03, "gun", 0.02);
        break;
    case "flashlight":
        hvs__fc(_k, 0.20, 0.50, 1.10, 0.50, 0.17, "gun", 0.05);
        for (var _i = 0; _i < 6; _i++) hvs__fl(_k, 0.26 + _i * 0.13, 0.36, 0.26 + _i * 0.13, 0.64, 0.025, "steel", 0.8, 0.5);
        hvs__fp(_k, [1.10, 0.32, 1.40, 0.18, 1.90, 0.18, 1.90, 0.82, 1.40, 0.82, 1.10, 0.68], "steel", 0.05);
        hvs__fr(_k, 1.82, 0.20, 0.10, 0.60, 0.02, "glass", 0.02);
        hvs__fr(_k, 0.86, 0.26, 0.20, 0.10, 0.01, "red", 0.01);
        break;
    case "battery":
        hvs__fr(_k, 0.26, 0.20, 0.48, 0.72, 0.05, "gun", 0.06);
        hvs__fr(_k, 0.26, 0.20, 0.48, 0.24, 0.03, "amber", 0.03);
        hvs__fr(_k, 0.40, 0.08, 0.20, 0.13, 0.02, "steel", 0.02);
        hvs__fl(_k, 0.42, 0.62, 0.58, 0.62, 0.05, "white", 0.9, 0.9); hvs__fl(_k, 0.50, 0.54, 0.50, 0.70, 0.05, "white", 0.9, 0.9);
        break;
    case "gem":
        hvs__fp(_k, [0.22, 0.20, 0.78, 0.20, 0.94, 0.42, 0.50, 0.92, 0.06, 0.42], "liquid", 0.03);
        hvs__fp(_k, [0.30, 0.24, 0.70, 0.24, 0.80, 0.42, 0.20, 0.42], "liquid", 0.02);
        hvs__fl(_k, 0.20, 0.42, 0.50, 0.90, 0.015, "white", 1, 0.5); hvs__fl(_k, 0.80, 0.42, 0.50, 0.90, 0.015, "white", 1, 0.3); hvs__fl(_k, 0.38, 0.42, 0.50, 0.90, 0.015, "white", 1, 0.3);
        hvs__fs(_k, 0.38, 0.32, 0.12, "white", 1, 0.8);
        break;
    case "coinpouch":
        hvs__fp(_k, [0.32, 0.36, 0.68, 0.36, 0.90, 0.68, 0.76, 0.92, 0.24, 0.92, 0.10, 0.68], "leather", 0.07);
        hvs__fp(_k, [0.28, 0.12, 0.72, 0.12, 0.62, 0.34, 0.38, 0.34], "leather", 0.03);
        hvs__fr(_k, 0.34, 0.31, 0.32, 0.08, 0.02, "gold", 0.02);
        hvs__fe(_k, 0.50, 0.66, 0.11, 0.11, "gold", 0.03);
        break;
    case "goldbar":
        hvs__fp(_k, [0.32, 0.26, 1.68, 0.26, 1.92, 0.82, 0.08, 0.82], "gold", 0.08);
        hvs__fl(_k, 0.62, 0.50, 1.38, 0.50, 0.05, "brass", 0.25, 0.7);
        hvs__fl(_k, 0.62, 0.62, 1.20, 0.62, 0.04, "brass", 0.25, 0.7);
        break;
    case "ring":
        hvs__fp(_k, hvs__ell(0.5, 0.60, 0.32, 0.30, 22), "gold", 0.08);
        hvs__fp(_k, hvs__ell(0.5, 0.62, 0.20, 0.18, 18), "rubber", 0.01);
        hvs__fp(_k, [0.36, 0.28, 0.40, 0.14, 0.60, 0.14, 0.64, 0.28, 0.50, 0.38], "liquid", 0.02);
        hvs__fs(_k, 0.45, 0.20, 0.05, "white", 1, 0.9);
        break;
    case "amulet":
        for (var _i = 0; _i < 8; _i++) { var _ax = 0.5 + cos(_i / 8 * pi) * 0.34, _ay = 0.08 + sin(_i / 8 * pi) * 0.62; hvs__fe(_k, _ax, _ay, 0.035, 0.035, "brass", 0.01); }
        hvs__fe(_k, 0.5, 0.84, 0.05, 0.05, "brass", 0.02);
        hvs__fp(_k, hvs__ell(0.5, 1.30, 0.36, 0.42, 20), "gold", 0.07);
        hvs__fp(_k, hvs__ell(0.5, 1.30, 0.22, 0.27, 16), "liquid", 0.04);
        hvs__fs(_k, 0.42, 1.18, 0.07, "white", 1, 0.85);
        break;
    case "scroll":
        hvs__fr(_k, 0.26, 0.24, 1.48, 0.52, 0.02, "paper", 0.02);
        for (var _i = 0; _i < 3; _i++) hvs__fl(_k, 0.46, 0.36 + _i * 0.14, 1.54, 0.36 + _i * 0.14, 0.03, "dark", 0.3, 0.55);
        hvs__fc(_k, 0.20, 0.14, 0.20, 0.86, 0.11, "paper", 0.04); hvs__fc(_k, 1.80, 0.14, 1.80, 0.86, 0.11, "paper", 0.04);
        hvs__fr(_k, 0.88, 0.22, 0.24, 0.56, 0.01, "red", 0.02);
        hvs__fe(_k, 1.00, 0.50, 0.11, 0.11, "red", 0.03);
        break;
    case "book":
        hvs__fr(_k, 0.26, 0.12, 1.56, 1.80, 0.03, "paper", 0.02);
        hvs__fr(_k, 0.16, 0.08, 1.60, 1.80, 0.05, "liquid", 0.08);
        hvs__fr(_k, 0.16, 0.08, 0.26, 1.80, 0.03, "liquid", 0.05);
        hvs__fr(_k, 0.60, 0.40, 0.90, 0.86, 0.02, "gold", 0.03); hvs__fr(_k, 0.68, 0.48, 0.74, 0.70, 0.01, "liquid", 0.01);
        for (var _i = 0; _i < 3; _i++) hvs__fl(_k, 0.17, 0.30 + _i * 0.66, 0.41, 0.30 + _i * 0.66, 0.05, "gold", 0.7, 1);
        break;
    case "skull":
        hvs__fp(_k, [0.20, 0.82, 0.30, 0.34, 0.66, 0.08, 1.34, 0.08, 1.70, 0.34, 1.80, 0.82, 1.66, 1.24, 1.42, 1.34, 0.58, 1.34, 0.34, 1.24], "bone", 0.09);
        hvs__fr(_k, 0.60, 1.28, 0.80, 0.60, 0.08, "bone", 0.06);
        hvs__fe(_k, 0.68, 0.86, 0.24, 0.22, "rubber", 0.03); hvs__fe(_k, 1.32, 0.86, 0.24, 0.22, "rubber", 0.03);
        hvs__fp(_k, [1.0, 1.04, 1.12, 1.30, 0.88, 1.30], "rubber", 0.01);
        for (var _i = 0; _i < 3; _i++) hvs__fl(_k, 0.80 + _i * 0.20, 1.50, 0.80 + _i * 0.20, 1.84, 0.03, "dark", 0.1, 0.8);
        hvs__fl(_k, 0.64, 1.62, 1.36, 1.62, 0.025, "dark", 0.1, 0.7);
        hvs__fl(_k, 1.40, 0.20, 1.30, 0.40, 0.02, "dark", 0.2, 0.5); hvs__fl(_k, 1.30, 0.40, 1.42, 0.52, 0.02, "dark", 0.2, 0.5);
        break;
    case "pouch":
        hvs__fp(_k, [0.20, 0.54, 1.80, 0.54, 1.88, 1.48, 1.60, 1.88, 0.40, 1.88, 0.12, 1.48], "hide", 0.08);
        hvs__fp(_k, [0.14, 0.26, 1.86, 0.26, 1.82, 0.90, 1.00, 1.16, 0.18, 0.90], "hide", 0.07);
        hvs__fr(_k, 0.84, 0.76, 0.32, 0.56, 0.03, "leather", 0.03);
        hvs__fr(_k, 0.80, 0.90, 0.40, 0.22, 0.03, "brass", 0.03); hvs__fr(_k, 0.88, 0.95, 0.24, 0.12, 0.02, "leather", 0.01);
        for (var _i = 0; _i < 10; _i++) hvs__fl(_k, 0.24 + _i * 0.16, 0.34, 0.33 + _i * 0.16, 0.34, 0.025, "linen", 0.6, 0.9);
        break;
    default:
        hvs__form_parcel(_k);
        break;
    }
}
/// @function hvs__form_parcel(builder)
/// @description Internal. Any footprint with no form or sprite: its own cells as a parcel of waxed paper and twine.
function hvs__form_parcel(_k) {
    var _cells = _k.cells;
    for (var _i = 0; _i < array_length(_cells); _i++) {
        var _x = _cells[_i][0], _y = _cells[_i][1];
        hvs__fr(_k, _x + 0.06, _y + 0.06, 0.88, 0.88, 0.10, "hide", 0.06);
        hvs__fl(_k, _x + 0.5, _y + 0.08, _x + 0.5, _y + 0.92, 0.05, "rope", 0.9, 1);
        hvs__fl(_k, _x + 0.08, _y + 0.5, _x + 0.92, _y + 0.5, 0.05, "rope", 0.9, 1);
    }
}

/// @function hvs__form_paint(builder, rot, cell, padx, pady)
/// @description Internal. Paint a built form, rotated first so the lamp stays fixed, in logical pixels. Silhouettes go down first, so seams inside the object stay fine while its outside edge reads against any lining.
function hvs__form_paint(_k, _rot, _cell, _px, _py) {
    var _W = _k.W, _H = _k.H, _parts = _k.parts, _n = array_length(_parts), _ink = make_colour_rgb(16, 12, 10), _inkpx = max(0.8, _cell * 0.032);
    hvs__b_begin();
    // transform every mass once
    var _xf = array_create(_n, undefined);
    for (var _i = 0; _i < _n; _i++) {
        var _pt = _parts[_i];
        if (_pt.t == 3) { _xf[_i] = undefined; hvs__bar_ink(_pt, _W, _H, _rot, _cell, _px, _py, _ink, _inkpx); continue; }
        if (_pt.t != 0) continue;
        var _src = _pt.p, _m = array_length(_src), _dst = array_create(_m, 0);
        for (var _j = 0; _j < _m; _j += 2) {
            var _x = _src[_j], _y = _src[_j + 1], _rx = _x, _ry = _y;
            if (_rot == 1) { _rx = _H - _y; _ry = _x; } else if (_rot == 2) { _rx = _W - _x; _ry = _H - _y; } else if (_rot == 3) { _rx = _y; _ry = _W - _x; }
            _dst[_j] = _px + _rx * _cell; _dst[_j + 1] = _py + _ry * _cell;
        }
        _xf[_i] = _dst;
    }
    // the silhouette of the whole object, first
    for (var _i = 0; _i < _n; _i++) {
        if (is_undefined(_xf[_i])) continue;
        var _p = _xf[_i], _ct = hvs__centroid(_p), _cnt = array_length(_p) div 2, _fl = hvs__area(_p) < 0 ? -1 : 1;
        for (var _q = 0; _q < _cnt; _q++) {
            var _h = (_q + _cnt - 1) mod _cnt, _j = (_q + 1) mod _cnt, _jj = (_j + 1) mod _cnt;
            var _qn = hvs__vnorm(_p, _h, _q, _j, _fl), _jn = hvs__vnorm(_p, _q, _j, _jj, _fl);
            hvs__tri(_ct[0], _ct[1], _ink, 1, _p[_q * 2] + _qn[0] * _inkpx, _p[_q * 2 + 1] + _qn[1] * _inkpx, _ink, 1, _p[_j * 2] + _jn[0] * _inkpx, _p[_j * 2 + 1] + _jn[1] * _inkpx, _ink, 1);
        }
    }
    // then the object, in order
    for (var _i = 0; _i < _n; _i++) {
        var _pt = _parts[_i];
        if (_pt.t == 0) {
            hvs__mass(_xf[_i], hvs__mat(_pt.m, _k.hue), _pt.b * _cell);
        } else if (_pt.t == 3) {
            hvs__bar_paint(_pt, hvs__mat(_pt.m, _k.hue), _W, _H, _rot, _cell, _px, _py);
        } else if (_pt.t == 1) {
            var _a = hvs__xf(_pt.x0, _pt.y0, _W, _H, _rot), _b = hvs__xf(_pt.x1, _pt.y1, _W, _H, _rot);
            hvs__seg(_px + _a[0] * _cell, _py + _a[1] * _cell, _px + _b[0] * _cell, _py + _b[1] * _cell, max(0.7, _pt.w * _cell), hvs__ramp_at(hvs__mat(_pt.m, _k.hue), _pt.s), _pt.a);
        } else {
            var _c = hvs__xf(_pt.x, _pt.y, _W, _H, _rot);
            hvs__spot(_px + _c[0] * _cell, _py + _c[1] * _cell, _pt.r * _cell, hvs__ramp_at(hvs__mat(_pt.m, _k.hue), _pt.s), _pt.a, 12);
        }
    }
    hvs__b_end();
}
/// @function hvs__bar_rails(part, W, H, rot, cell, px, py)
/// @description Internal. A bar's spine in pixels, with the normal at each point.
function hvs__bar_rails(_pt, _W, _H, _rot, _cell, _px, _py) {
    var _sp = _pt.sp, _n = array_length(_sp) div 3, _o = [];
    for (var _i = 0; _i < _n; _i++) { var _a = hvs__xf(_sp[_i * 3], _sp[_i * 3 + 1], _W, _H, _rot); array_push(_o, [_px + _a[0] * _cell, _py + _a[1] * _cell, _sp[_i * 3 + 2] * _cell, 0, 0]); }
    for (var _i = 0; _i < _n; _i++) {
        var _a = _o[max(0, _i - 1)], _b = _o[min(_n - 1, _i + 1)], _dx = _b[0] - _a[0], _dy = _b[1] - _a[1], _l = max(0.0001, sqrt(_dx * _dx + _dy * _dy));
        _o[_i][3] = -_dy / _l; _o[_i][4] = _dx / _l;
    }
    return _o;
}
/// @function hvs__bar_ink(part, W, H, rot, cell, px, py, ink, inkpx)
/// @description Internal. A bar's silhouette.
function hvs__bar_ink(_pt, _W, _H, _rot, _cell, _px, _py, _ink, _inkpx) {
    var _r = hvs__bar_rails(_pt, _W, _H, _rot, _cell, _px, _py), _n = array_length(_r);
    for (var _i = 0; _i < _n - 1; _i++) {
        var _a = _r[_i], _b = _r[_i + 1], _wa = _a[2] + _inkpx, _wb = _b[2] + _inkpx;
        hvs__quad(_a[0] + _a[3] * _wa, _a[1] + _a[4] * _wa, _ink, 1, _b[0] + _b[3] * _wb, _b[1] + _b[4] * _wb, _ink, 1, _b[0] - _b[3] * _wb, _b[1] - _b[4] * _wb, _ink, 1, _a[0] - _a[3] * _wa, _a[1] - _a[4] * _wa, _ink, 1);
    }
}
/// @function hvs__bar_paint(part, ramp, W, H, rot, cell, px, py)
/// @description Internal. A bar shaded across its width: two walls by their normals against the lamp, a face between. One continuous mass, so it has no joints to catch the light.
function hvs__bar_paint(_pt, _ramp, _W, _H, _rot, _cell, _px, _py) {
    var _r = hvs__bar_rails(_pt, _W, _H, _rot, _cell, _px, _py), _n = array_length(_r), _lx = -0.6, _ly = -0.8, _k = 1 - _pt.wall;
    for (var _i = 0; _i < _n - 1; _i++) {
        var _a = _r[_i], _b = _r[_i + 1];
        var _da = _a[3] * _lx + _a[4] * _ly, _db = _b[3] * _lx + _b[4] * _ly;
        var _al = hvs__ramp_at(_ramp, 0.5 + 0.5 * _da), _bl = hvs__ramp_at(_ramp, 0.5 + 0.5 * _db), _ar = hvs__ramp_at(_ramp, 0.5 - 0.5 * _da), _br = hvs__ramp_at(_ramp, 0.5 - 0.5 * _db);
        var _am = hvs__ramp_at(_ramp, 0.52 + 0.15 * _da), _bm = hvs__ramp_at(_ramp, 0.52 + 0.15 * _db), _am2 = hvs__ramp_at(_ramp, 0.52 - 0.15 * _da), _bm2 = hvs__ramp_at(_ramp, 0.52 - 0.15 * _db);
        var _wa = _a[2], _wb = _b[2], _ia = _wa * _k, _ib = _wb * _k;
        hvs__quad(_a[0] + _a[3] * _wa, _a[1] + _a[4] * _wa, _al, 1, _b[0] + _b[3] * _wb, _b[1] + _b[4] * _wb, _bl, 1, _b[0] + _b[3] * _ib, _b[1] + _b[4] * _ib, _bm, 1, _a[0] + _a[3] * _ia, _a[1] + _a[4] * _ia, _am, 1);
        hvs__quad(_a[0] + _a[3] * _ia, _a[1] + _a[4] * _ia, _am, 1, _b[0] + _b[3] * _ib, _b[1] + _b[4] * _ib, _bm, 1, _b[0] - _b[3] * _ib, _b[1] - _b[4] * _ib, _bm2, 1, _a[0] - _a[3] * _ia, _a[1] - _a[4] * _ia, _am2, 1);
        hvs__quad(_a[0] - _a[3] * _ia, _a[1] - _a[4] * _ia, _am2, 1, _b[0] - _b[3] * _ib, _b[1] - _b[4] * _ib, _bm2, 1, _b[0] - _b[3] * _wb, _b[1] - _b[4] * _wb, _br, 1, _a[0] - _a[3] * _wa, _a[1] - _a[4] * _wa, _ar, 1);
    }
}

/// @function hvs__xf(x, y, W, H, rot)
/// @description Internal. A form point through a quarter-turn rotation.
function hvs__xf(_x, _y, _W, _H, _rot) {
    if (_rot == 1) return [_H - _y, _x];
    if (_rot == 2) return [_W - _x, _H - _y];
    if (_rot == 3) return [_y, _W - _x];
    return [_x, _y];
}
/// @function hvs__vnorm(points, h, i, j, flip)
/// @description Internal. The outward normal at a vertex.
function hvs__vnorm(_p, _h, _i, _j, _fl) {
    var _ax = _p[_i * 2] - _p[_h * 2], _ay = _p[_i * 2 + 1] - _p[_h * 2 + 1], _bx = _p[_j * 2] - _p[_i * 2], _by = _p[_j * 2 + 1] - _p[_i * 2 + 1];
    var _la = max(0.0001, sqrt(_ax * _ax + _ay * _ay)), _lb = max(0.0001, sqrt(_bx * _bx + _by * _by));
    var _nx = (_ay / _la + _by / _lb), _ny = -(_ax / _la + _bx / _lb), _ln = max(0.0001, sqrt(_nx * _nx + _ny * _ny));
    return [_nx / _ln * _fl, _ny / _ln * _fl];
}

/// @function hvs_item_art(item_or_id, rot, cell)
/// @description The baked picture of an item at a rotation and cell size, drawn on first use and kept: {spr (origin at the centre of the item's box), spr_shadow, w, h} in pixels. Premultiplied: draw through hvs_item_draw, or with gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha).
/// @returns {struct} The picture, or undefined.
function hvs_item_art(_v, _rot = 0, _cell = 40) {
    var _def = undefined, _hue = undefined;
    if (hvs__is_item(_v)) _def = _v.def; else _def = hvs_item_def(_v);
    if (is_undefined(_def)) return undefined;
    _rot = ((floor(hvs__n(_rot, 0)) mod 4) + 4) mod 4;
    _cell = clamp(floor(hvs__n(_cell, 40)), 8, 128);
    _hue = _def.hue;
    var _hasSprite = !is_undefined(_def.sprite) && (is_real(_def.sprite) || typeof(_def.sprite) == "ref") && sprite_exists(_def.sprite);
    var _name = _hasSprite ? "s" + string(_def.sprite) + "|" + _def.id : (is_undefined(_def.form) ? "p|" + _def.sig : _def.form);
    var _key = "it|" + _name + "|" + string(_rot) + "|" + string(_cell) + "|" + (is_undefined(_hue) ? "" : string(_hue));
    var _cache = hvs__cache(), _e = _cache[$ _key];
    if (!is_undefined(_e) && sprite_exists(_e.spr)) return _e;
    var _r0 = _def.rots[0], _rt = _def.rots[_rot], _pad = ceil(_cell * 0.10) + 2;
    var _bw = _rt.w * _cell, _bh = _rt.h * _cell, _w = _bw + _pad * 2, _h = _bh + _pad * 2;
    var _b = hvs__bake_begin(_w, _h, 2);
    if (_hasSprite) {
        // your own art, fitted to the footprint's box at rotation 0 and turned with it
        var _sw = sprite_get_width(_def.sprite), _sh = sprite_get_height(_def.sprite), _fit = min(_r0.w * _cell / max(1, _sw), _r0.h * _cell / max(1, _sh));
        var _ox = sprite_get_xoffset(_def.sprite), _oy = sprite_get_yoffset(_def.sprite);
        var _dx = (_sw * 0.5 - _ox) * _fit, _dy = (_sh * 0.5 - _oy) * _fit, _ang = -_rot * 90;
        var _cs = dcos(_ang), _sn = dsin(_ang);
        draw_sprite_ext(_def.sprite, 0, _w * 0.5 - (_dx * _cs + _dy * _sn), _h * 0.5 - (-_dx * _sn + _dy * _cs), _fit, _fit, _ang, c_white, 1);
    } else {
        var _k = { parts: [], cells: _r0.cells, W: _r0.w, H: _r0.h, hue: _hue };
        hvs__form_build(is_undefined(_def.form) ? "?" : _def.form, _k);
        hvs__form_paint(_k, _rot, _cell, _pad, _pad);
    }
    var _spr = hvs__bake_end(_b, _w * 0.5, _h * 0.5);
    var _shd = hvs__blur_sprite(_spr, _w, _h, _w * 0.5, _h * 0.5);
    _e = { spr: _spr, spr_shadow: _shd, w: _bw, h: _bh, pad: _pad };
    _cache[$ _key] = _e;
    return _e;
}
/// @function hvs_item_draw(item_or_id, x, y, rot, cell, scale, angle)
/// @description Draw an item's picture with the top-left corner of its footprint's box at x, y: an icon in your own UI, a shop list, a dropped pickup.
function hvs_item_draw(_v, _x, _y, _rot = 0, _cell = 40, _scale = 1, _angle = 0) {
    var _a = hvs_item_art(_v, _rot, _cell);
    if (is_undefined(_a)) return false;
    _x = hvs__n(_x, 0); _y = hvs__n(_y, 0); _scale = hvs__n(_scale, 1); _angle = hvs__n(_angle, 0);
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_one, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_tex_filter(true);
    draw_sprite_ext(_a.spr, 0, _x + _a.w * 0.5, _y + _a.h * 0.5, _scale, _scale, _angle, c_white, 1);
    gpu_pop_state();
    return true;
}
