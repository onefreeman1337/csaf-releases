{
  "$GMScript": "v1",
  "%Name": "hvs_forms",
  "name": "hvs_forms",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}