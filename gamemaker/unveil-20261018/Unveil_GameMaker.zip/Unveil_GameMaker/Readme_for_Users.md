# Unveil - Reveal Any Picture, a Qix-Style Minigame for GameMaker

Hide a picture from your game under a veil and let the player cut it away. The player walks the edge of the revealed land
and cuts lines into the veil; close a cut back onto revealed land and every region with no creature in it is claimed.
A creature drifting in the veil that touches the cut, or a spark running the edge that touches the player, costs a life.
Reveal the target share of the picture to win.

- **Your picture.** Any sprite or surface: a portrait, a map, a reward, a story card. It is scaled to cover the board.
- **Eight veils, each a different material, all drawn by the package from a seed:** draped silk under a woven damask
  lattice, frosted glass grown with ice ferns, black lacquer with gold wave scales and gold dust, velvet with a soft pile,
  washi paper printed with a hemp-leaf pattern and laid fibres, rolling smoke, an ink wash, and leaded stained glass. The
  same seed draws the same veil; another seed draws another one.
- **Seven creature forms** drift in the veil, each drawn in that veil's own palette (56 looks): the many-armed wisp, a
  jellyfish, a moth, a star, an eye, a comet and a spore. Radial forms spin; the jellyfish, the moth and the comet point
  the way they travel.
- **Eight spark styles**, one belonging to each veil (an ember, a snowflake, a fleck of gold leaf, a firefly, a paper
  pinwheel, a will-o'-the-wisp flame, a drop of seal ink, a prism) and any of them can be given to any veil.
- **The claimed veil breaks and falls away.** Every claim cuts the veil it took into pieces that wait their turn in a
  wave running out from where the cut closed, then pop, tumble, turn over (their backs in shadow) and fall away. A win
  brings the whole remaining veil down before the results come up. The fall never touches the game: it has its own
  generator, and a game plays the same with it on or off (`fall: false` gives the MZ edition's instant reveal).
- **The cut is a gilt seam with a glow, the trail a glowing thread,** and the band along the top shows the veil's name,
  the share revealed against the target and the lives left. No image file is loaded.

Ported from our RPG Maker MZ plugin Unveil and held to it: the in-engine suite replays the MZ edition's own games frame
for frame and checks every move, every creature and every spark agrees (see Verification).

## Install

1. In GameMaker, **Tools > Import Local Package**, choose `Unveil.yymps`, and import everything.
2. Run the project with `rm_unv_demo` first in the room order. The demo is THE VEILED GALLERY: eight framed veils, one of
   each material, each hiding a picture. Choose a frame and a setting (Gentle 60%, Fair 75%, Hard 85%) with the arrows,
   1 2 3 and Enter, or click, then cut the veil away. A frame you unveil keeps its picture on the wall. The gallery's
   pictures are stand-ins drawn by the package (`unv_demo_picture`) so the demo needs no image file; your game passes its
   own.

Requires GameMaker 2024.14 or later. Built and tested on runtime 2024.14.4.268 (the VM, Windows). Pure GML, no shader, no
extension; nothing here depends on GMRT.

## Quickstart

```gml
// Create - open a game over your own picture (any sprite; the same seed always plays the same game)
my_scene = unv_open({ picture: spr_my_picture, seed: "harbour", veil: "silk", target: 75 });

// Step - run it; when the player leaves, read the result
unv_step(my_scene, device_mouse_x_to_gui(0), device_mouse_y_to_gui(0));
if (unv_closed(my_scene)) {
    my_result = my_scene.result;     // { won, lost, left, percent, target, lives, cuts, hits, frames }
    unv_free(my_scene);
    my_scene = undefined;
}

// Draw GUI - the scene is 816 x 624 at scale 1; draw it anywhere, at any scale
unv_draw(my_scene, 0, 0, 1);
```

`unv_open` draws the veil, the creature, the spark and the marker once and keeps them, so open a game behind your own
transition (see Performance). **Call `unv_open` and `unv_step` in Create or Step, never inside a Draw event or while a
surface of yours is the render target** (they draw into surfaces of their own). `unv_draw` only blits. Pass the pointer
to `unv_step` in the same coordinates you draw the scene in. What a win unlocks is your game's business: `result.won`
says how it ended, `result.left` that the player walked away.

A surface works as the picture too; it is copied, so you may free it after `unv_open`:

```gml
my_scene = unv_open({ picture: my_surface, picture_kind: "surface", seed: 7 });
```

### The request

```gml
{ picture: spr_my_picture,    // a sprite, or a surface (required; a number that is both is read as a sprite unless picture_kind: "surface")
  seed: "harbour",            // a number or a word: the same game every time; "" or absent: a new game every time
  veil: "silk",               // "silk", "frost", "lacquer", "velvet", "washi", "smoke", "inkwash", "leaded" or "auto" (by the seed)
  creature: "auto",           // "wisp", "jelly", "moth", "star", "eye", "comet", "spore" or "auto" (by the seed)
  spark: "auto",              // "ember", "flake", "leaf", "firefly", "pinwheel", "flame", "droplet", "prism" or "auto" (the veil's own)
  target: 75,                 // percent of the picture to reveal, 10 to 95
  lives: 3,                   // 1 to 9
  creatures: 1,               // creatures in the veil, 1 to 4
  sparks: 2,                  // sparks on the edge, 0 to 6
  fall: true,                 // false: claimed veil vanishes at once instead of falling away
  allow_leave: true,          // false: Escape is refused
  sound: my_sound_hook }      // optional: function(name) called with "cut", "claim", "hit", "won", "lost"
```

### Controls

- **Arrow keys** walk the edge. **Hold Shift, Z, Space or Enter** while moving to cut into the veil; reach revealed land
  again to close the cut. A cut cannot cross itself.
- **Mouse or touch**: press and hold to steer toward the pointer and cut. A cut that stops a cell or two short of
  revealed land while the pointer is still held closes onto it (the MZ edition's magnet). On mobile exports a first
  finger reads as GameMaker's mouse (device 0); we have only built and tested Windows.
- **Escape** leaves unrevealed (when `allow_leave` is true). On the results, **Enter, Space, Z or a click** leaves.

## Reference

**The scene** (`unv_open` once, then every frame `unv_step` in Step and `unv_draw` in Draw or Draw GUI)
- `unv_open(request)` - open a game over the picture; returns the scene struct, or undefined when the request names no
  usable picture.
- `unv_step(scene, [mouse_x], [mouse_y])` - one frame: input, a move every 3 frames, the world every frame, the falling
  veil, and a redraw of whatever changed.
- `unv_draw(scene, x, y, scale)` - draw it with its top-left at (x, y), 816 x 624 times scale.
- `unv_closed(scene)` - true once the player has left (after the results, or on Escape).
- `unv_free(scene)` - free every surface and sprite it made (and the picture, when it copied a surface). Safe twice.
- Fields you may set: `scene.inject` (scripted input for one frame, in scene coordinates: `{ dx, dy, draw }` to move and
  cut, `{ ok: true }`, `{ leave: true }`, `{ held: true, mx, my }` - for a tutorial, a replay or an attract mode).
- `scene.result` - `{ won, lost, left, percent, target, lives, cuts, hits, frames }`.

**The rules on their own** (pure GML, no drawing; the board is `cols x rows` cells, the outer ring revealed)
- `unv_create_game(seed, [options])` - a game as plain data; options `{ cols, rows, target, lives, creatures, sparks,
  creature_speed, spark_every }`. `unv_is_game(value)` tells a game from anything else.
- `unv_move(game, dx, dy, draw)` - move the player one cell: returns "moved", "cut", "closed" or "blocked".
- `unv_tick(game)` - one frame of the world (creatures drift and bounce, sparks run the edge).
- `unv_claim(game)` - close the trail and claim every region with no creature in it (unv_move calls it); returns the
  cells claimed.
- `unv_at(game, x, y)` - `UNV_OPEN`, `UNV_CLAIMED` or `UNV_TRAIL`. `unv_is_edge(game, x, y)` - a claimed cell touching the
  veil. `unv_percent(game)` - percent of the interior claimed. `unv_nearest_edge(game, x, y, ax, ay, min_dist)`.
- `unv_results(game)` - `{ won, lost, percent, target, lives, cuts, hits, frames }`.
- `unv_hash_string(text)` - the 32-bit seed of a word. `unv_mix(a, b)` - mixes two 32-bit numbers.

**Drawing directly** (into a `unv_cx_create(scale)` context, onto whatever SURFACE is the current target). Each call
sets the package's blend for itself (alpha blended as "over") and hands yours back.
- `unv_draw_veil(ctx, w, h, theme, seed)` - a whole veil, w x h.
- `unv_draw_cut(ctx, game, cell_w, cell_h, theme)` - erase the claimed land from a veil already drawn into the target and
  strike the gilt rim along every edge; returns the rim segments drawn.
- `unv_draw_trail(ctx, game, cell_w, cell_h, theme)` - the trail as a glowing thread; returns its length.
- `unv_draw_creature(ctx, size, theme, [form])`, `unv_draw_spark(ctx, size, theme, [style])`, `unv_draw_marker(ctx, size,
  theme)` - each into a size x size box at the origin.
- `unv_draw_hud(ctx, w, theme, { percent, target, lives, lives_max })` - the 56 px band. `unv_draw_results(ctx, w, h,
  theme, result)` - the results panel.
- The vocabularies: `unv_themes()`, `unv_creatures()`, `unv_creature_turns(form)` ("spin", "face" or "still"),
  `unv_spark_styles()`, `unv_spark_of(theme)` (a veil's own spark), `unv_spark_turns(style)`.

**The demo room** - `unv_demo_create()`, `unv_demo_step(demo)`, `unv_demo_draw(demo)`, `unv_demo_free(demo)`,
`unv_demo_frames()`, `unv_demo_levels()`: THE VEILED GALLERY, the same four calls in `obj_unv_demo`.
`unv_demo_picture(ctx, kind, w, h)` draws the gallery's eight stand-in pictures (0 to 7).

## Performance

Measured on our test machine, a shared and busy one (runtime 2024.14.4.268, the VM, Windows), three runs. Yours will
differ.

- **Opening a game costs the veil's drawing**, once (three runs): ink wash 54 to 83 ms, frost 62 to 84 ms, washi 79 to
  116 ms, velvet 188 to 292 ms, smoke 223 to 350 ms, silk 268 to 420 ms, leaded glass 280 to 466 ms, lacquer 1.4 to 2.2 s.
  Open behind your own transition; the demo shows a "Weaving the veil" card for a frame first.
- **A frame is cheap**: the veil is redrawn only when land is claimed and the trail only when it grows. A claim costs one
  redraw of the veil plus cutting the falling layer (the slowest frame of a scripted game was 36 to 40 ms, on the claim);
  while pieces fall, each frame redraws them into one surface.

## Fonts

The band and the panel are lettered in two faces rasterised into font resources: Cinzel Bold (the veil's name, the
headings) and Alegreya (the rest), both SIL Open Font License 1.1. The licence texts and the notices are in
`Unveil/fonts/`. The atlases carry printable ASCII (32 to 126) and the middle dot; any other character is measured as
nothing and not drawn.

## Differences from the RPG Maker MZ edition

- **More to look at.** The MZ edition has three veils (silk, frost, lacquer), one creature and one spark; this edition adds
  five veils, six creature forms, seven spark styles and the falling veil. With `veil: "silk"`, `creature: "wisp"`,
  `spark: "ember"` and `fall: false` it is the MZ edition's look.
- **Saving is yours.** The MZ edition writes the result into RPG Maker variables and switches; here the scene hands back
  `result` and your game keeps whatever it likes.
- **Sounds are a hook** (`sound(name)`) instead of RPG Maker sound-effect names; the package plays nothing itself.
- **Type.** The MZ edition sets its words in Palatino Linotype, a system font no package may ship; this one ships Cinzel
  Bold and Alegreya.

## Verification

GameMaker code cannot be unit-tested outside the engine, so everything below ran in real executables built by GameMaker's
own compiler (Igor, runtime 2024.14.4.268):

- **The rules, held to the RPG Maker MZ edition run in Node:** the seed hash and mix, 54 created games on odd seeds and
  options, 4 unit move sequences, and 8 whole games played by the MZ edition's own scripted player and replayed frame for
  frame (21,505 frames, 7,156 moves, 183 checkpoints of the player, lives, the phase, the claimed share, the trail, a hash
  of every cell, every creature's position and speed and every spark), 3 won and 5 lost, every one exact.
- **The pictures:** each of the eight veils, a board mid-cut in three of them, all 56 creature looks and all 64 spark
  looks inked; no added spark style draws as the ember it replaces.
- **The scene:** opened over a picture, walked, a box cut and closed, won; the veil falling in pieces and the panel waiting
  for it; OK ignored early; Escape; a surface as the picture; `allow_leave` false; the same box cut with the fall on and
  off playing the same game frame for frame, and the falling cells exactly the cells claimed.
- **The demo room:** the gallery drawn, a frame opened by keys and left, another won and kept on the wall.
- **A blank project** that installed the package the way you will and ran this Readme's own code, with ink counted on
  everything it drew; and an adversarial pass of the documented functions (undefined, negative, huge and wrong-typed
  arguments) with zero crashes.

Two things this does not prove, stated plainly: the timings come from one shared machine and will differ on yours, and
the suite ran on Windows with the VM runtime only (other targets and YYC were not built).

## Licence

See `LICENSE.txt`. Use it in unlimited games, commercial or free; modify it freely; do not resell the package itself.

Made by Core Systems Asset Factory. Written with AI assistance, disclosed on every store page that carries it.
