/// @description Run the gallery, or the game opened from it.
if (is_undefined(demo)) exit;
unv_demo_step(demo);
