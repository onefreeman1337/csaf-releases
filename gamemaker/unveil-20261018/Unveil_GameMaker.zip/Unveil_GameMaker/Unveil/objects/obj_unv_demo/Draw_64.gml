/// @description Draw the gallery, or the game opened from it, scaled to fit the GUI.
if (is_undefined(demo)) exit;
unv_demo_draw(demo);
