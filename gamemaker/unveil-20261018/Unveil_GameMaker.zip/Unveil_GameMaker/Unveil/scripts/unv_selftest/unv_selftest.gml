/// unv_selftest.gml - Unveil's in-engine test suite: the GML rules held to the RPG Maker MZ edition run in Node
/// (unv_oracle_core): hashes, mixes, created games, unit move sequences and long logged plays replayed frame for frame.
/// Run the demo with -selftest; the result is written as unv_selftest.json in the game's save folder.
///
/// Unveil - Reveal Any Picture, a Qix-Style Minigame for GameMaker. Copyright (c) 2026 Core Systems Asset Factory.

/// @function unv_st_assert(state, condition, message)
/// @description Count one assertion; keep the first 60 failure messages.
function unv_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 60) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
/// @function unv_st_stage(state, n)
/// @description Record the stage reached (the crash handler reports it).
function unv_st_stage(_st, _n) { _st.stage = _n; global.unv_stage = _n; }

/// @function unv__st_cells_hash(game)
/// @description Internal. FNV-1a over every cell value, as the oracle hashes it.
function unv__st_cells_hash(_g) {
    var _h = int64(2166136261), _n = array_length(_g.cells);
    for (var _i = 0; _i < _n; _i++) { _h = _h ^ int64(_g.cells[_i]); _h = unv__imul(_h, 16777619); }
    return real(_h);
}

/// @function unv__st_snap(game)
/// @description Internal. The oracle's snapshot shape: [frame, px, py, lives, phase, claimed, trailLen, cuts, hits, drawing,
/// cellsHash, creatures flat (x, y, vx, vy), sparks flat (x, y, px, py)].
function unv__st_snap(_g) {
    var _ph = (_g.phase == "play") ? 0 : ((_g.phase == "won") ? 1 : 2), _cr = [], _sk = [];
    for (var _i = 0; _i < array_length(_g.creatures); _i++) { var _c = _g.creatures[_i]; array_push(_cr, _c.x, _c.y, _c.vx, _c.vy); }
    for (var _j = 0; _j < array_length(_g.sparks); _j++) { var _s = _g.sparks[_j]; array_push(_sk, _s.x, _s.y, _s.px, _s.py); }
    return [_g.frame, _g.px, _g.py, _g.lives, _ph, _g.claimed, _g.trailLen, _g.cuts, _g.hits, _g.drawing ? 1 : 0, unv__st_cells_hash(_g), _cr, _sk];
}

/// @function unv__st_snap_diff(want, got)
/// @description Internal. "" when the snapshots are identical (exact, epsilon off), else the first difference named.
function unv__st_snap_diff(_w, _g) {
    var _names = ["frame", "px", "py", "lives", "phase", "claimed", "trailLen", "cuts", "hits", "drawing", "cellsHash"];
    for (var _i = 0; _i < 11; _i++) if (_w[_i] != _g[_i]) return _names[_i] + " want " + string(_w[_i]) + " got " + string(_g[_i]);
    for (var _k = 11; _k <= 12; _k++) {
        var _a = _w[_k], _b = _g[_k];
        if (array_length(_a) != array_length(_b)) return ((_k == 11) ? "creatures" : "sparks") + " count want " + string(array_length(_a)) + " got " + string(array_length(_b));
        for (var _j = 0; _j < array_length(_a); _j++) if (_a[_j] != _b[_j]) return ((_k == 11) ? "creature" : "spark") + " field " + string(_j) + " want " + string_format(_a[_j], 1, 17) + " got " + string_format(_b[_j], 1, 17);
    }
    return "";
}

/// @function unv_selftest_run()
/// @description Run the whole suite and return its state { pass, fail, total, stage, failures, ... }.
function unv_selftest_run() {
    var _st = { pass: 0, fail: 0, total: 0, stage: 0, failures: [], runtime: GM_runtime_version, epsilon: 0, plays: [], replayedFrames: 0, replayedMoves: 0, checkpoints: 0, notes_thin: [] };
    var _eps = math_get_epsilon(); math_set_epsilon(0); _st.epsilon = math_get_epsilon();
    var _O = unv_oracle_core(), _i, _j;

    // 1. hashes and mixes
    unv_st_stage(_st, 1);
    for (_i = 0; _i < array_length(_O.hashes); _i++) { var _hw = _O.hashes[_i]; var _hg = unv_hash_string(_hw[0]); unv_st_assert(_st, _hg == _hw[1], "hash '" + _hw[0] + "' want " + string(_hw[1]) + " got " + string(_hg)); }
    for (_i = 0; _i < array_length(_O.mixes); _i++) { var _mw = _O.mixes[_i]; var _mg = unv_mix(_mw[0], _mw[1]); unv_st_assert(_st, _mg == _mw[2], "mix " + string(_mw[0]) + "," + string(_mw[1]) + " want " + string(_mw[2]) + " got " + string(_mg)); }

    // 2. created games: every option read, the player, creatures, sparks, the generator state
    unv_st_stage(_st, 2);
    for (_i = 0; _i < array_length(_O.creates); _i++) {
        var _cw = _O.creates[_i], _opts = undefined;
        if (_cw[1] == 1) {
            var _a = _cw[2]; _opts = {};
            if (_a[0] != 0) _opts.cols = _a[0];
            if (_a[1] != 0) _opts.rows = _a[1];
            if (_a[2] != 0) _opts.target = _a[2];
            if (_a[3] != 0) _opts.lives = _a[3];
            if (_a[4] != -1) _opts.creatures = _a[4];
            if (_a[5] != -1) _opts.sparks = _a[5];
            if (_a[6] != 0) _opts.creature_speed = _a[6];
            if (_a[7] != 0) _opts.spark_every = _a[7];
        }
        var _g = unv_create_game(_cw[0], _opts), _f = _cw[3];
        var _gotF = [_g.cols, _g.rows, _g.target, _g.lives, _g.creatureSpeed, _g.sparkEvery, _g.px, _g.py, _g.interior, real(_g.rs), unv__st_cells_hash(_g)];
        var _fn = ["cols", "rows", "target", "lives", "creatureSpeed", "sparkEvery", "px", "py", "interior", "rs", "cellsHash"], _bad = "";
        for (_j = 0; _j < 11; _j++) if (_f[_j] != _gotF[_j]) { _bad = _fn[_j] + " want " + string(_f[_j]) + " got " + string(_gotF[_j]); break; }
        unv_st_assert(_st, _bad == "", "create #" + string(_i) + " seed " + string(_cw[0]) + ": " + _bad);
        var _sn = unv__st_snap(_g), _cr = _sn[11], _sk = _sn[12], _bad2 = "";
        if (array_length(_cr) != array_length(_cw[4])) _bad2 = "creature count";
        else for (_j = 0; _j < array_length(_cr); _j++) if (_cr[_j] != _cw[4][_j]) { _bad2 = "creature field " + string(_j) + " want " + string_format(_cw[4][_j], 1, 17) + " got " + string_format(_cr[_j], 1, 17); break; }
        if (_bad2 == "") { if (array_length(_sk) != array_length(_cw[5])) _bad2 = "spark count"; else for (_j = 0; _j < array_length(_sk); _j++) if (_sk[_j] != _cw[5][_j]) { _bad2 = "spark field " + string(_j); break; } }
        unv_st_assert(_st, _bad2 == "", "create #" + string(_i) + " seed " + string(_cw[0]) + " creatures/sparks: " + _bad2);
    }

    // 3. unit move sequences: every result string and the board after
    unv_st_stage(_st, 3);
    for (_i = 0; _i < array_length(_O.units); _i++) {
        var _uw = _O.units[_i];
        var _ug = unv_create_game(_uw[0], { cols: 16, rows: 12, target: 95, creatures: 1, sparks: 0 }), _res = "";
        for (_j = 0; _j < array_length(_uw[1]); _j++) { var _in = _uw[1][_j]; _res += ((_j > 0) ? "," : "") + unv_move(_ug, _in[0], _in[1], _in[2] == 1); }
        unv_st_assert(_st, _res == _uw[2], "unit seq " + string(_i) + " results want " + _uw[2] + " got " + _res);
        var _ud = unv__st_snap_diff(_uw[3], unv__st_snap(_ug));
        unv_st_assert(_st, _ud == "", "unit seq " + string(_i) + " board: " + _ud);
    }

    // 4. long logged plays, replayed frame for frame: every move's result, a checkpoint every 120 frames, the outcome
    unv_st_stage(_st, 4);
    var _DX = [1, -1, 0, 0], _DY = [0, 0, 1, -1];
    for (_i = 0; _i < array_length(_O.plays); _i++) {
        var _P = _O.plays[_i], _pg = unv_create_game(_P.seed, _P.opts), _ci = 0, _moveRes = "", _first = "", _len = string_length(_P.inputs);
        var _t0 = get_timer();
        for (var _fr = 0; _fr < 9000 && _pg.phase == "play"; _fr++) {
            if (_fr + 1 <= _len) {
                var _ch = string_char_at(_P.inputs, _fr + 1);
                if (_ch != ".") {
                    var _code = ord(_ch) - 48, _r = unv_move(_pg, _DX[_code mod 4], _DY[_code mod 4], _code >= 4);
                    _moveRes += (_r == "closed") ? "l" : string_char_at(_r, 1);
                    _st.replayedMoves++;
                }
            }
            unv_tick(_pg);
            if (_pg.frame mod 120 == 0 && _ci < array_length(_P.checks) - 1) {
                var _d = unv__st_snap_diff(_P.checks[_ci], unv__st_snap(_pg));
                if (_d != "" && _first == "") _first = "checkpoint " + string(_ci) + " (frame " + string(_pg.frame) + "): " + _d;
                _ci++; _st.checkpoints++;
            }
        }
        _st.replayedFrames += _pg.frame;
        var _dl = unv__st_snap_diff(_P.checks[array_length(_P.checks) - 1], unv__st_snap(_pg));
        if (_dl != "" && _first == "") _first = "final: " + _dl;
        _st.checkpoints++;
        unv_st_assert(_st, _first == "", "play seed " + string(_P.seed) + " " + _first);
        unv_st_assert(_st, _moveRes == _P.results, "play seed " + string(_P.seed) + " move results differ (" + string(string_length(_moveRes)) + " vs " + string(string_length(_P.results)) + ")");
        var _R = unv_results(_pg), _o = _P.outcome;
        unv_st_assert(_st, (_R.won ? 1 : 0) == _o[0] && (_R.lost ? 1 : 0) == _o[1] && _R.percent == _o[2] && _R.target == _o[3] && _R.lives == _o[4] && _R.cuts == _o[5] && _R.hits == _o[6] && _R.frames == _o[7],
            "play seed " + string(_P.seed) + " outcome want " + string(_o) + " got " + json_stringify(_R));
        array_push(_st.plays, { seed: _P.seed, won: _R.won, lost: _R.lost, percent: _R.percent, frames: _R.frames, cuts: _R.cuts, hits: _R.hits, ms: (get_timer() - _t0) / 1000 });
    }

    // 5. refusals: the rules never crash on input that is not a game
    unv_st_stage(_st, 5);
    unv_st_assert(_st, unv_move(undefined, 1, 0, true) == "blocked", "move on undefined");
    unv_st_assert(_st, unv_tick("x") == "x", "step on a string returns it untouched");
    unv_st_assert(_st, unv_percent({}) == 0, "percent on an empty struct");
    unv_st_assert(_st, unv_at(-1, 0, 0) == UNV_CLAIMED, "at on a number");
    unv_st_assert(_st, unv_nearest_edge(undefined, 0, 0, 0, 0, 0) == -1, "nearest edge on undefined");
    unv_st_assert(_st, unv_claim([]) == 0, "claim on an array");
    var _rz = unv_results(undefined); unv_st_assert(_st, !_rz.won && !_rz.lost && _rz.percent == 0, "results on undefined is neutral");
    var _gv = unv_create_game(5); unv_st_assert(_st, unv_move(_gv, 1, 1, false) == "blocked" && unv_move(_gv, 2, 0, false) == "blocked" && unv_move(_gv, 0, 0, true) == "blocked", "diagonal, 2-cell and null moves are blocked");
    unv_st_assert(_st, unv_is_game(_gv) && !unv_is_game({ cells: [1], cols: 2, rows: 2 }), "is_game tells a game from a look-alike");

    // 6. renders to LOOK at (unv_render_*.png): each veil, a board mid-cut per veil, the won results; ink counted
    unv_st_stage(_st, 6);
    _st.renders = unv__st_renders(_st, _O);
    unv__st_hud_inks(_st);

    // 7. the scene: open over a picture, walk, cut a box and close it by scripted input, win, read the results, leave
    unv_st_stage(_st, 7);
    unv__st_scene(_st);
    if (variable_global_exists("unv_st_fall")) _st.fall = global.unv_st_fall;

    // 8. the demo room: the eight stand-in pictures (a sheet), the gallery drawn, a frame opened by scripted input and left,
    // another won and kept on the wall
    unv_st_stage(_st, 8);
    unv__st_demo(_st);

    math_set_epsilon(_eps);
    unv_st_stage(_st, 99);
    return _st;
}

/// @function unv__st_run(scene, inject, frames)
/// @description Internal. Step a scene `frames` frames with the same injected input each frame.
function unv__st_run(_T, _inj, _n) { repeat (_n) { _T.inject = _inj; unv_step(_T); } }

/// @function unv__st_shot(scene, file)
/// @description Internal. Draw the scene at scale 1 into a fresh surface, save it, return the pixels with ink (alpha > half).
function unv__st_shot(_T, _file) {
    var _s = surface_create(UNV_SCENE_W, UNV_SCENE_H);
    surface_set_target(_s); draw_clear_alpha(c_black, 0); unv_draw(_T, 0, 0, 1); surface_reset_target();
    surface_save(_s, _file);
    var _ink = unv__st_ink(_s, 0, UNV_TOP, UNV_SCENE_W, UNV_SCENE_H - UNV_TOP);
    // the scene drawn into a buyer's cleared surface must be OPAQUE everywhere (the first build blitted its premultiplied
    // layers with the normal blend and left the band and the panel translucent): sampled every 2 px, alpha under 250
    var _b = buffer_create(UNV_SCENE_W * UNV_SCENE_H * 4, buffer_fixed, 1); buffer_get_surface(_b, _s, 0);
    var _holes = 0;
    for (var _yy = 0; _yy < UNV_SCENE_H; _yy += 2) for (var _xx = 0; _xx < UNV_SCENE_W; _xx += 2) if (buffer_peek(_b, (_yy * UNV_SCENE_W + _xx) * 4 + 3, buffer_u8) < 250) _holes++;
    buffer_delete(_b);
    surface_free(_s);
    global.unv_st_holes = _holes;
    return _ink;
}

/// @function unv__st_scene(state)
/// @description Internal. The scene end to end by scripted input, as a buyer's game would drive it.
function unv__st_scene(_st) {
    // the buyer's picture: the stand-in, painted into a surface and made a sprite
    var _ps = surface_create(640, 400), _c = unv_cx_create(1);
    surface_set_target(_ps); draw_clear_alpha(c_black, 0); unv__st_picture(_c, 640, 400); surface_reset_target();
    var _spr = sprite_create_from_surface(_ps, 0, 0, 640, 400, false, false, 0, 0);
    var _sounds = []; global.unv_st_sounds = _sounds;
    var _T = unv_open({ picture: _spr, seed: "harbour", veil: "frost", target: 10, lives: 3, creatures: 1, sparks: 0, sound: function(_n) { array_push(global.unv_st_sounds, _n); } });
    unv_st_assert(_st, unv__is_scene(_T) && _T.theme == "frost" && _T.seed == unv_hash_string("harbour") && _T.game.target == 10 && array_length(_T.game.sparks) == 0, "unv_open: a scene over the picture with the request read");
    var _g = _T.game, _x0 = _g.px, _y0 = _g.py;
    unv__st_run(_T, { dx: -1 }, 24 * 3);
    unv_st_assert(_st, _g.px == _x0 - 24 && _g.py == _y0 && !_g.drawing, "walking left on the edge: one cell every 3 frames (px " + string(_g.px) + ")");
    unv__st_run(_T, { dy: -1, draw: true }, 12 * 3);
    unv_st_assert(_st, _g.drawing && _g.trailLen == 12 && _g.py == _y0 - 12, "holding draw cuts up into the veil (trail " + string(_g.trailLen) + ")");
    unv__st_run(_T, { dx: 1, draw: true }, 25 * 3);
    var _mid = unv__st_shot(_T, "unv_render_scene_cut.png");
    unv_st_assert(_st, _mid > 50000 && _g.trailLen == 37, "mid-cut the scene draws (ink " + string(_mid) + ", trail " + string(_g.trailLen) + ")");
    unv_st_assert(_st, global.unv_st_holes == 0, "mid-cut the scene is opaque in a buyer's surface (" + string(global.unv_st_holes) + " translucent samples)");
    unv__st_run(_T, { dx: 1, draw: true }, 25 * 3);
    unv__st_run(_T, { dy: 1, draw: true }, 12 * 3);
    unv_st_assert(_st, _g.cuts == 1 && _g.claimed >= 600 && _g.phase == "won" && _T.mode == "results", "closing the box claims it and wins at 10% (claimed " + string(_g.claimed) + ", phase " + _g.phase + ")");
    unv_st_assert(_st, array_length(global.unv_st_sounds) >= 3 && global.unv_st_sounds[0] == "cut" && array_get_index(global.unv_st_sounds, "claim") >= 0 && array_get_index(global.unv_st_sounds, "won") >= 0, "the sound hook heard cut, claim and won (" + string(global.unv_st_sounds) + ")");
    // the winning claim breaks the whole remaining veil: it falls in pieces before the panel comes up
    var _wl = (array_length(_T.falls) > 0) ? _T.falls[array_length(_T.falls) - 1] : undefined;
    unv_st_assert(_st, _T.falling && _T.fallN >= 1 && is_struct(_wl) && _wl.won && _wl.cells > 4000 && array_length(_wl.pieces) > 400,
        "the win breaks the remaining veil into falling pieces (falls " + string(_T.fallN) + ", cells " + (is_struct(_wl) ? string(_wl.cells) : "-") + ", pieces " + (is_struct(_wl) ? string(array_length(_wl.pieces)) : "-") + ")");
    unv__st_run(_T, {}, 14);
    var _fallInk = unv__st_shot(_T, "unv_render_scene_fall.png");
    var _fb = surface_exists(_T.fxSurf) ? unv__st_ink(_T.fxSurf, 0, 0, UNV_SCENE_W, UNV_SCENE_H - UNV_TOP) : 0;
    unv_st_assert(_st, _T.falling && _fb > 20000 && global.unv_st_holes == 0, "mid-fall the pieces draw (fall layer ink " + string(_fb) + ") and the scene stays opaque (" + string(global.unv_st_holes) + ")");
    var _panelEarly = _T.mode == "results" && _T.t == 0;
    unv__st_run(_T, { ok: true }, 5);
    unv_st_assert(_st, _panelEarly && !unv_closed(_T) && _T.t == 0, "OK while the veil is still falling is ignored and the panel waits (t " + string(_T.t) + ")");
    var _ff = 0; while (_T.falling && _ff < 300) { _T.inject = {}; unv_step(_T); _ff++; }
    unv_st_assert(_st, !_T.falling && _ff < 120 && array_length(_T.falls) == 0 && !surface_exists(_T.fxSurf), "the fall ends on its own and frees its layers (" + string(_ff + 19) + " frames after the win)");
    var _won = unv__st_shot(_T, "unv_render_scene_won.png");
    unv_st_assert(_st, _won > 50000, "the won screen draws the picture and the panel (ink " + string(_won) + ")");
    unv_st_assert(_st, global.unv_st_holes == 0, "the won screen is opaque in a buyer's surface (" + string(global.unv_st_holes) + " translucent samples)");
    unv__st_run(_T, { ok: true }, 10);
    unv_st_assert(_st, !unv_closed(_T), "OK in the first half second of the results is ignored");
    unv__st_run(_T, {}, 25);
    unv__st_run(_T, { ok: true }, 1);
    unv_st_assert(_st, unv_closed(_T) && _T.result.won && !_T.result.left && _T.result.cuts == 1, "OK on the results closes the scene with the result");
    unv_free(_T); unv_free(_T);
    unv_st_assert(_st, unv_closed(_T), "free twice is safe; a freed scene reads closed");
    // the fall never touches the game: the same box cut with fall on and fall off leaves the same game, frame for frame;
    // a claim that does not win breaks exactly the cells it claimed, and the falling pieces never hold the panel back
    var _Ta = unv_open({ picture: _spr, seed: "harbour", veil: "leaded", target: 95, lives: 3, creatures: 1, sparks: 0 });
    var _Tb = unv_open({ picture: _spr, seed: "harbour", veil: "leaded", target: 95, lives: 3, creatures: 1, sparks: 0, fall: false });
    var _steps = [[-1, 0, false, 24 * 3], [0, -1, true, 12 * 3], [1, 0, true, 50 * 3], [0, 1, true, 12 * 3], [0, 0, false, 120]];
    var _same = true, _firstDiff = "", _peak = 0, _tw0 = get_timer(), _worst = 0, _claimDelta = -1, _layerCells = -1, _layerWon = true;
    for (var _sx = 0; _sx < array_length(_steps); _sx++) {
        var _row = _steps[_sx];
        repeat (_row[3]) {
            var _cb = _Ta.game.claimed, _nb = _Ta.fallN;
            _Ta.inject = { dx: _row[0], dy: _row[1], draw: _row[2] }; var _t1 = get_timer(); unv_step(_Ta); _worst = max(_worst, (get_timer() - _t1) / 1000);
            _Tb.inject = { dx: _row[0], dy: _row[1], draw: _row[2] }; unv_step(_Tb);
            if (_Ta.fallN != _nb) { _claimDelta = _Ta.game.claimed - _cb; var _ly = _Ta.falls[array_length(_Ta.falls) - 1]; _layerCells = _ly.cells; _layerWon = _ly.won; }
            var _dd = unv__st_snap_diff(unv__st_snap(_Ta.game), unv__st_snap(_Tb.game));
            if (_dd != "" && _same) { _same = false; _firstDiff = _dd; }
            if (_Ta.falling) _peak = max(_peak, array_length(_Ta.falls));
        }
    }
    unv_st_assert(_st, _same && _Ta.game.cuts == 1 && _Ta.game.phase == "play" && _Ta.game.claimed > 500, "fall on and fall off play the same game frame for frame (cuts " + string(_Ta.game.cuts) + ", claimed " + string(_Ta.game.claimed) + ", phase " + _Ta.game.phase + ") " + _firstDiff);
    unv_st_assert(_st, _Ta.fallN == 1 && _Tb.fallN == 0 && _Ta.fallPieces > 30 && _peak == 1, "one claim, one fall: " + string(_Ta.fallPieces) + " pieces (fall off made " + string(_Tb.fallN) + ")");
    unv_st_assert(_st, _layerCells > 0 && _layerCells == _claimDelta && !_layerWon, "a claim that does not win breaks exactly the cells it claimed (" + string(_layerCells) + " falling, " + string(_claimDelta) + " claimed)");
    unv_st_assert(_st, !_Ta.falling && array_length(_Ta.falls) == 0 && !surface_exists(_Ta.fxSurf), "120 frames later the fall is over and its layers are freed");
    global.unv_st_fall = { pieces: _Ta.fallPieces, cells: _layerCells, worstStepMs: _worst, totalMs: (get_timer() - _tw0) / 1000 };
    unv_free(_Ta); unv_free(_Tb);
    // a surface as the picture is copied (and the copy freed with the scene); Escape leaves when allowed
    var _T2 = unv_open({ picture: _ps, picture_kind: "surface", seed: 7, allow_leave: true });
    unv_st_assert(_st, unv__is_scene(_T2) && _T2.picOwned && sprite_exists(_T2.pic), "a surface picture is copied into the scene's own sprite");
    var _own = _T2.pic;
    unv__st_run(_T2, { dx: 1 }, 6);
    unv__st_run(_T2, { leave: true }, 1);
    unv_st_assert(_st, unv_closed(_T2) && _T2.result.left && !_T2.result.won, "Escape leaves with the result marked left");
    unv_free(_T2);
    unv_st_assert(_st, !sprite_exists(_own), "the copied picture is freed with the scene");
    var _T3 = unv_open({ picture: _spr, seed: 7, allow_leave: false });
    unv__st_run(_T3, { leave: true }, 3);
    unv_st_assert(_st, !unv_closed(_T3), "allow_leave false: Escape does nothing");
    unv_free(_T3);
    // refusals
    unv_st_assert(_st, is_undefined(unv_open(undefined)) && is_undefined(unv_open({})) && is_undefined(unv_open({ picture: -5 })), "unv_open refuses a request with no usable picture");
    unv_step(undefined); unv_step("x"); unv_draw(undefined, 0, 0, 1); unv_draw({}, 0, 0, 1); unv_free(undefined); unv_free(12);
    unv_st_assert(_st, unv_closed(undefined), "the scene calls survive values that are not a scene");
    surface_free(_ps); sprite_delete(_spr);
}

/// @function unv__st_demo(state)
/// @description Internal. The demo room as a player would use it, by scripted input.
function unv__st_demo(_st) {
    // the eight pictures on one sheet (4 x 2 at 408 x 284), each inked
    var _pw = 408, _ph = 284, _sheet = surface_create(_pw * 4, _ph * 2), _one = surface_create(_pw, _ph), _least = 999999, _t0 = get_timer();
    surface_set_target(_sheet); draw_clear(c_black); surface_reset_target();
    for (var _k = 0; _k < 8; _k++) {
        surface_set_target(_one); draw_clear_alpha(c_black, 0); var _c = unv_cx_create(1); unv_demo_picture(_c, _k, _pw, _ph); surface_reset_target();
        _least = min(_least, unv__st_ink(_one, 0, 0, _pw, _ph));
        surface_set_target(_sheet); gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); draw_surface(_one, (_k mod 4) * _pw, (_k div 4) * _ph); gpu_pop_state(); surface_reset_target();
    }
    surface_save(_sheet, "unv_render_pictures.png"); surface_free(_sheet); surface_free(_one);
    unv_st_assert(_st, _least >= _pw * _ph / 4 * 0.98, "every demo picture fills its frame (least " + string(_least) + " of " + string(_pw * _ph / 4) + " samples) in " + string(round((get_timer() - _t0) / 1000)) + " ms");
    // the gallery, one frame shown unveiled
    var _D = unv_demo_create();
    var _ok = is_struct(_D) && array_length(_D.frames) == 8 && sprite_exists(_D.bg) && sprite_exists(_D.pickSpr) && sprite_exists(_D.levelSpr);
    for (var _i = 0; _i < 8; _i++) if (!sprite_exists(_D.frameSpr[_i])) _ok = false;
    unv_st_assert(_st, _ok, "unv_demo_create bakes the wall, eight frames, the pick and the settings");
    _D.revealed[2] = true; unv__demo_frame_bake(_D, 2);
    var _gs = surface_create(UNV_SCENE_W, UNV_SCENE_H);
    unv_demo_step(_D);
    surface_set_target(_gs); draw_clear_alpha(c_black, 0); unv_demo_draw(_D); surface_reset_target();
    surface_save(_gs, "unv_render_gallery.png");
    var _gi = unv__st_ink(_gs, 0, 0, UNV_SCENE_W, UNV_SCENE_H);
    unv_st_assert(_st, _gi >= UNV_SCENE_W * UNV_SCENE_H / 4 * 0.98, "the gallery draws edge to edge (" + string(_gi) + " samples)");
    // pick the second frame, Hard, open it, see the veil and the setting, then leave
    _D.inject = { right: true }; unv_demo_step(_D);
    _D.inject = { level: 2 }; unv_demo_step(_D);
    _D.inject = { ok: true }; unv_demo_step(_D);
    var _waited = _D.pending == 1;
    unv_demo_step(_D); unv_demo_step(_D);
    unv_st_assert(_st, _waited && is_struct(_D.scene) && _D.scene.theme == "frost" && _D.scene.game.target == 85 && array_length(_D.scene.game.creatures) == 2 && array_length(_D.scene.game.sparks) == 3,
        "Right, 3 and Enter open the frost frame at Hard behind the wait card (" + (is_struct(_D.scene) ? _D.scene.theme + " " + string(_D.scene.game.target) : "no scene") + ")");
    _D.inject = { leave: true }; unv_demo_step(_D);
    unv_st_assert(_st, is_undefined(_D.scene) && is_struct(_D.lastResult) && _D.lastResult.left && !_D.revealed[1], "Escape leaves the frame veiled");
    // the first frame at Gentle, won by the box the scene test cuts: it stays unveiled on the wall
    _D.inject = { left: true }; unv_demo_step(_D); _D.inject = { level: 0 }; unv_demo_step(_D);
    _D.inject = { ok: true }; unv_demo_step(_D); unv_demo_step(_D); unv_demo_step(_D);
    var _opened = is_struct(_D.scene) && _D.scene.theme == "silk";
    // FIXTURE, not the rules under test (those are held to the MZ in stages 1-4): the box claims about 10.5%, so the bar is
    // lowered to 10, the spark is taken off and the creature is parked far from the box, so one box always wins here
    if (_opened) {
        var _gg = _D.scene.game; _gg.target = 10; _gg.sparks = [];
        for (var _qi = 0; _qi < array_length(_gg.creatures); _qi++) { var _qq = _gg.creatures[_qi]; _qq.x = 80.5 + _qi; _qq.y = 10.5; _qq.vx = 0; _qq.vy = 0; }
    }
    var _steps = [[-1, 0, false, 24 * 3], [0, -1, true, 12 * 3], [1, 0, true, 50 * 3], [0, 1, true, 12 * 3]];
    for (var _s = 0; _s < 4 && _opened; _s++) { var _r = _steps[_s]; repeat (_r[3]) { _D.inject = { dx: _r[0], dy: _r[1], draw: _r[2] }; unv_demo_step(_D); } }
    var _guard = 0; while (is_struct(_D.scene) && _guard < 400) { _D.inject = (_guard > 150) ? { ok: true } : {}; unv_demo_step(_D); _guard++; }
    unv_st_assert(_st, _opened && is_undefined(_D.scene) && _D.revealed[0] && _D.best[0] > 10 && sprite_exists(_D.frameSpr[0]), "a won frame closes and stays unveiled on the wall (best " + string(_D.best[0]) + "%, " + string(_guard) + " steps after the win)");
    unv_demo_free(_D); unv_demo_free(_D);
    unv_st_assert(_st, !sprite_exists(_D.frameSpr[0]) && _D.bg == -1, "unv_demo_free frees everything, twice safely");
    surface_free(_gs);
}

/// @function unv__st_picture(ctx, w, h)
/// @description Internal. A stand-in for the buyer's picture in the test renders (a dusk sky, a sun, two hills, a lake),
/// drawn by the kit so the renders need no image file. The product never draws this; the buyer supplies the picture.
function unv__st_picture(_c, _w, _h) {
    var _sky = unv_cx_linear(_c, 0, 0, 0, _h); unv_cx_stop(_sky, 0, [38, 52, 110]); unv_cx_stop(_sky, 0.55, [236, 128, 86]); unv_cx_stop(_sky, 1, [252, 214, 140]);
    _c.fill = _sky; unv_cx_fill_rect(_c, 0, 0, _w, _h);
    _c.fill = unv_cx_solid([255, 236, 190]); unv_cx_begin(_c); unv_cx_arc(_c, _w * 0.62, _h * 0.52, _h * 0.11, 0, pi * 2); unv_cx_fill(_c);
    _c.fill = unv_cx_solid([66, 40, 70]); unv_cx_begin(_c); unv_cx_move(_c, 0, _h * 0.62); unv_cx_bezier(_c, _w * 0.25, _h * 0.42, _w * 0.45, _h * 0.6, _w * 0.7, _h * 0.58); unv_cx_bezier(_c, _w * 0.85, _h * 0.56, _w * 0.95, _h * 0.5, _w, _h * 0.55); unv_cx_line(_c, _w, _h); unv_cx_line(_c, 0, _h); unv_cx_close(_c); unv_cx_fill(_c);
    _c.fill = unv_cx_solid([30, 22, 48]); unv_cx_begin(_c); unv_cx_move(_c, 0, _h * 0.8); unv_cx_bezier(_c, _w * 0.3, _h * 0.7, _w * 0.6, _h * 0.86, _w, _h * 0.74); unv_cx_line(_c, _w, _h); unv_cx_line(_c, 0, _h); unv_cx_close(_c); unv_cx_fill(_c);
}

/// @function unv__st_hud_inks(state)
/// @description Internal. The band's share label is drawn in two inks, each clipped to what it sits on: dark over the
/// fill, light over the rest. Drawn at 50% (the label straddles the end of the fill), the pixels are read back: over the
/// fill no light ink may show and dark ink must; beside it light ink must show. (2026-10-18: type ignored the clip and the
/// light ink covered the whole label; read back here before the fix, the over-fill light count was the defect.)
function unv__st_hud_inks(_st) {
    var _W = 816, _s = surface_create(_W, 56), _c = unv_cx_create(1);
    surface_set_target(_s); draw_clear(make_colour_rgb(8, 6, 10));
    unv_draw_hud(_c, _W, "silk", { percent: 50, target: 75, lives: 3, lives_max: 3 });
    surface_reset_target();
    var _b = buffer_create(_W * 56 * 4, buffer_fixed, 1); buffer_get_surface(_b, _s, 0);
    // the bar: x 190 .. 190 + (816 - 380), y 18 .. 36; the fill ends at its middle (x 408), the label is centred there
    var _mid = 190 + (_W - 380) / 2, _lightOn = 0, _darkOn = 0, _lightOff = 0;
    for (var _y = 20; _y < 35; _y++) for (var _x = _mid - 30; _x < _mid + 30; _x++) {
        if (abs(_x - _mid) < 2) continue;   // the seam itself
        var _o = (_y * _W + _x) * 4, _r = buffer_peek(_b, _o, buffer_u8), _g = buffer_peek(_b, _o + 1, buffer_u8), _bl = buffer_peek(_b, _o + 2, buffer_u8);
        var _light = _r > 215 && _g > 215 && _bl > 215, _dark = _r < 90 && _g < 90 && _bl < 90;
        if (_x < _mid) { if (_light) _lightOn++; if (_dark) _darkOn++; } else if (_light) _lightOff++;
    }
    buffer_delete(_b); surface_free(_s);
    // bars from the read-back (2026-10-18): with type ignoring the clip it read 18 light / 20 dark over the fill and 13 light
    // beside it; the unfilled track is ~[37,36,39] and the fill [243,200,107], so a light or dark pixel here is glyph ink
    unv_st_assert(_st, _lightOn == 0 && _darkOn >= 10, "the share label is dark over the fill (" + string(_lightOn) + " light px, " + string(_darkOn) + " dark px)");
    unv_st_assert(_st, _lightOff >= 6, "and light beside it (" + string(_lightOff) + " light px)");
    _st.hudInks = { lightOnFill: _lightOn, darkOnFill: _darkOn, lightOffFill: _lightOff };
}

/// @function unv__st_ink(surface, x, y, w, h)
/// @description Internal. Count pixels in a region whose alpha is over half (a read-back; the renders are tests, not play).
function unv__st_ink(_s, _x, _y, _w, _h) {
    var _b = buffer_create(surface_get_width(_s) * surface_get_height(_s) * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _s, 0);
    var _sw = surface_get_width(_s), _n = 0;
    for (var _yy = _y; _yy < _y + _h; _yy += 2) for (var _xx = _x; _xx < _x + _w; _xx += 2) if (buffer_peek(_b, (_yy * _sw + _xx) * 4 + 3, buffer_u8) > 127) _n++;
    buffer_delete(_b);
    return _n;
}

/// @function unv__st_board(game, theme, file)
/// @description Internal. Draw a whole board as the scene will (picture, veil with the claimed land cut out, trail,
/// creatures, sparks, marker, the HUD) at 816 x 624 and save it. Returns { veilMs, cutMs, rim, ink }.
function unv__st_board(_g, _theme, _file, _withVeil = true) {
    var _W = 816, _H = 624, _top = 56, _VH = _H - _top, _cw = _W / _g.cols, _ch = _VH / _g.rows;
    var _S = surface_create(_W, _H), _V = surface_create(_W, _VH), _c = unv_cx_create(1), _out = { veilMs: 0, cutMs: 0, rim: 0, ink: 0 };
    // separate alpha: a translucent fill must not LOWER the alpha of what it lands on (the default blend multiplies it)
    surface_set_target(_V); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    var _t0 = get_timer(); unv_draw_veil(_c, _W, _VH, _theme, _g.seed); _out.veilMs = (get_timer() - _t0) / 1000;
    _t0 = get_timer(); _out.rim = unv_draw_cut(_c, _g, _cw, _ch, _theme); _out.cutMs = (get_timer() - _t0) / 1000;
    gpu_pop_state();
    surface_reset_target();
    surface_set_target(_S); draw_clear(make_colour_rgb(8, 6, 10));
    gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    unv_cx_save(_c); unv_cx_translate(_c, 0, _top); unv__st_picture(_c, _W, _VH); unv_cx_restore(_c);
    if (_withVeil) {
        gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
        draw_surface(_V, 0, _top); gpu_pop_state();
        unv_cx_save(_c); unv_cx_translate(_c, 0, _top); unv_draw_trail(_c, _g, _cw, _ch, _theme); unv_cx_restore(_c);
        for (var _i = 0; _i < array_length(_g.creatures); _i++) { var _q = _g.creatures[_i]; unv_cx_save(_c); unv_cx_translate(_c, _q.x * _cw - 32, _top + _q.y * _ch - 32); unv_draw_creature(_c, 64, _theme); unv_cx_restore(_c); }
        for (var _j = 0; _j < array_length(_g.sparks); _j++) { var _k = _g.sparks[_j]; unv_cx_save(_c); unv_cx_translate(_c, (_k.x + 0.5) * _cw - 12, _top + (_k.y + 0.5) * _ch - 12); unv_draw_spark(_c, 24, _theme); unv_cx_restore(_c); }
        unv_cx_save(_c); unv_cx_translate(_c, (_g.px + 0.5) * _cw - 11, _top + (_g.py + 0.5) * _ch - 11); unv_draw_marker(_c, 22, _theme); unv_cx_restore(_c);
    }
    unv_draw_hud(_c, _W, _theme, { percent: unv_percent(_g), target: _g.target, lives: _g.lives, lives_max: _g.livesMax });
    if (_g.phase != "play") unv_draw_results(_c, _W, _H, _theme, unv_results(_g));
    gpu_pop_state();
    surface_reset_target();
    _out.ink = unv__st_ink(_V, 0, 0, _W, _VH);
    surface_save(_S, _file);
    surface_free(_S); surface_free(_V);
    return _out;
}

/// @function unv__st_renders(state, oracle)
/// @description Internal. The test renders: each veil alone, a board mid-cut per veil, the won results screen.
function unv__st_renders(_st, _O) {
    var _out = [], _th = unv_themes(), _DX = [1, -1, 0, 0], _DY = [0, 0, 1, -1];
    // each veil on a fresh board (frame rim only)
    unv_st_assert(_st, array_length(_th) == 8, "eight veils (" + string(array_length(_th)) + ")");
    for (var _i = 0; _i < array_length(_th); _i++) {
        var _g0 = unv_create_game(1000 + _i, { cols: 96, rows: 64 });
        var _r0 = unv__st_board(_g0, _th[_i], "unv_render_veil_" + _th[_i] + ".png");
        unv_st_assert(_st, _r0.ink > 40000 && _r0.rim > 0, "veil " + _th[_i] + " has ink (" + string(_r0.ink) + ") and a frame rim (" + string(_r0.rim) + ")");
        array_push(_out, { name: "veil_" + _th[_i], veilMs: _r0.veilMs, cutMs: _r0.cutMs, rim: _r0.rim, ink: _r0.ink });
    }
    // a board mid-cut: replay the first logged play until frame >= 1800 with a cut of 6+ cells in progress
    var _P = _O.plays[0];
    for (var _t = 0; _t < 3; _t++) {
        var _g = unv_create_game(_P.seed, _P.opts), _len = string_length(_P.inputs);
        for (var _fr = 0; _fr < _len && _g.phase == "play"; _fr++) {
            var _chh = string_char_at(_P.inputs, _fr + 1);
            if (_chh != ".") { var _code = ord(_chh) - 48; unv_move(_g, _DX[_code mod 4], _DY[_code mod 4], _code >= 4); }
            unv_tick(_g);
            if (_g.frame >= 1800 + _t * 700 && _g.trailLen >= 6) break;
        }
        var _r1 = unv__st_board(_g, _th[_t], "unv_render_board_" + _th[_t] + ".png");
        unv_st_assert(_st, _g.trailLen >= 6 && _r1.rim > 0, "board " + _th[_t] + " mid-cut (trail " + string(_g.trailLen) + ", rim " + string(_r1.rim) + ")");
        array_push(_out, { name: "board_" + _th[_t], frame: _g.frame, percent: unv_percent(_g), trail: _g.trailLen, veilMs: _r1.veilMs, cutMs: _r1.cutMs, rim: _r1.rim, ink: _r1.ink });
    }
    // every creature form in every veil: a contact sheet (rows = veils, columns = forms), ink counted per cell
    var _cf = unv_creatures(), _cell = 80, _sheet = surface_create(_cell * array_length(_cf), _cell * array_length(_th)), _one = surface_create(64, 64), _thin = 0, _cells = 0;
    surface_set_target(_sheet); draw_clear(make_colour_rgb(8, 6, 10)); surface_reset_target();
    for (var _v = 0; _v < array_length(_th); _v++) for (var _f = 0; _f < array_length(_cf); _f++) {
        var _T = unv__stage(_th[_v]), _cxx = unv_cx_create(1);
        surface_set_target(_one); draw_clear_alpha(c_black, 0); unv_draw_creature(_cxx, 64, _th[_v], _cf[_f]); surface_reset_target();
        var _ink1 = unv__st_ink(_one, 0, 0, 64, 64); _cells++; if (_ink1 < 120) { _thin++; if (array_length(_st.failures) < 50 && _v == 0) array_push(_st.notes_thin, _cf[_f] + " " + string(_ink1)); }
        surface_set_target(_sheet);
        draw_set_colour(unv_col(_T.b)); draw_rectangle(_f * _cell + 2, _v * _cell + 2, _f * _cell + _cell - 3, _v * _cell + _cell - 3, false); draw_set_colour(c_white);
        gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); draw_surface(_one, _f * _cell + 8, _v * _cell + 8); gpu_pop_state();
        surface_reset_target();
    }
    surface_save(_sheet, "unv_render_creatures.png"); surface_free(_sheet); surface_free(_one);
    unv_st_assert(_st, _cells == 56 && _thin == 0, "every creature form draws ink in every veil (" + string(_cells) + " cells, " + string(_thin) + " thin; in the first veil: " + string(_st.notes_thin) + ")");
    array_push(_out, { name: "creatures", cells: _cells, thin: _thin });

    // every spark style in every veil at the scene's own 24 px (the sheet shows each doubled, pixel for pixel): ink counted
    // per cell, and each added style compared pixel by pixel with the ember in the same veil (a style that silently fell
    // through to the ember would draw exactly the ember, so that is the comparison that can see it)
    var _ss = unv_spark_styles(), _sc = 64, _sh = surface_create(_sc * array_length(_ss), _sc * array_length(_th)), _one2 = surface_create(24, 24);
    var _sthin = 0, _scells = 0, _sminInk = 999999, _sminDiff = 999999, _sminName = "", _emb = buffer_create(24 * 24 * 4, buffer_fixed, 1), _cur = buffer_create(24 * 24 * 4, buffer_fixed, 1);
    surface_set_target(_sh); draw_clear(make_colour_rgb(8, 6, 10)); surface_reset_target();
    for (var _v2 = 0; _v2 < array_length(_th); _v2++) for (var _f3 = 0; _f3 < array_length(_ss); _f3++) {
        var _T2 = unv__stage(_th[_v2]), _cx2 = unv_cx_create(1);
        surface_set_target(_one2); draw_clear_alpha(c_black, 0); unv_draw_spark(_cx2, 24, _th[_v2], _ss[_f3]); surface_reset_target();
        var _ink2 = unv__st_ink(_one2, 0, 0, 24, 24); _scells++; _sminInk = min(_sminInk, _ink2); if (_ink2 < 16) _sthin++;
        if (_f3 == 0) buffer_get_surface(_emb, _one2, 0);
        else {
            buffer_get_surface(_cur, _one2, 0);
            var _dif = 0;
            for (var _px = 0; _px < 24 * 24; _px++) {
                var _o = _px * 4, _mx = 0;
                for (var _ch2 = 0; _ch2 < 4; _ch2++) _mx = max(_mx, abs(buffer_peek(_emb, _o + _ch2, buffer_u8) - buffer_peek(_cur, _o + _ch2, buffer_u8)));
                if (_mx > 48) _dif++;
            }
            if (_dif < _sminDiff) { _sminDiff = _dif; _sminName = _th[_v2] + "/" + _ss[_f3]; }
        }
        surface_set_target(_sh);
        draw_set_colour(unv_col(_T2.b)); draw_rectangle(_f3 * _sc + 2, _v2 * _sc + 2, _f3 * _sc + _sc - 3, _v2 * _sc + _sc - 3, false); draw_set_colour(c_white);
        gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); gpu_set_texfilter(false); draw_surface_ext(_one2, _f3 * _sc + 8, _v2 * _sc + 8, 2, 2, 0, c_white, 1); gpu_pop_state();
        surface_reset_target();
    }
    buffer_delete(_emb); buffer_delete(_cur);
    surface_save(_sh, "unv_render_sparks.png"); surface_free(_sh); surface_free(_one2);
    unv_st_assert(_st, array_length(_ss) == 8 && _scells == 64 && _sthin == 0, "every spark style draws a solid form in every veil (" + string(_scells) + " cells, " + string(_sthin) + " thin, least ink " + string(_sminInk) + " samples)");
    unv_st_assert(_st, _sminDiff >= 60, "no added spark style draws as the ember it replaces (least different: " + _sminName + ", " + string(_sminDiff) + " of 576 px)");
    var _own = 0; for (var _v3 = 0; _v3 < array_length(_th); _v3++) if (array_get_index(_ss, unv_spark_of(_th[_v3])) >= 0) _own++;
    unv_st_assert(_st, _own == 8 && unv_spark_of("silk") == "ember" && unv_spark_of("nonsense") == "ember" && unv_spark_of(undefined) == "ember", "every veil names a spark style of its own (" + string(_own) + " of 8); anything else is the ember");
    array_push(_out, { name: "sparks", cells: _scells, thin: _sthin, leastInk: _sminInk, leastDiff: _sminDiff, leastDiffPair: _sminName });

    // the won results: the whole picture, the panel over it
    var _gw = unv_create_game(_P.seed, _P.opts);
    for (var _f2 = 0; _f2 < string_length(_P.inputs) && _gw.phase == "play"; _f2++) {
        var _c2 = string_char_at(_P.inputs, _f2 + 1);
        if (_c2 != ".") { var _cd = ord(_c2) - 48; unv_move(_gw, _DX[_cd mod 4], _DY[_cd mod 4], _cd >= 4); }
        unv_tick(_gw);
    }
    var _r2 = unv__st_board(_gw, "silk", "unv_render_results_won.png", false);
    unv_st_assert(_st, _gw.phase == "won", "the replayed play is won for the results render");
    array_push(_out, { name: "results_won", percent: unv_percent(_gw) });
    return _out;
}

/// @function unv_selftest_write(state)
/// @description Write the self-test result as unv_selftest.json in the game's save folder.
function unv_selftest_write(_st) {
    var _f = file_text_open_write("unv_selftest.json");
    file_text_write_string(_f, json_stringify(_st));
    file_text_close(_f);
}
