{
  "$GMScript": "v1",
  "%Name": "unv_veils",
  "name": "unv_veils",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}