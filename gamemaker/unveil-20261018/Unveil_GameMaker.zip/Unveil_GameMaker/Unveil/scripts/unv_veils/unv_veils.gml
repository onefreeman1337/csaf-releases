/// unv_veils.gml - the five veils this edition adds to the RPG Maker MZ edition's three: crushed velvet, washi paper under
/// a block-printed hemp-leaf lattice, rising smoke, a sumi-e ink wash of misty ridges with a seal, and leaded cathedral
/// glass. Each is a different STRUCTURE (never a recolour of another), seeded (the same seed draws the same veil), and
/// drawn through the kit by unv_draw_veil once per game. Internal: call unv_draw_veil with the veil's name.
///
/// Unveil - Reveal Any Picture, a Qix-Style Minigame for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// ⛔ Seeded draws are taken one statement each (GML evaluates stateful calls inside one expression right to left).

/// @function unv__mix_rgb(a, b, t)
/// @description Internal. Two [r, g, b] colours mixed, t from 0 (a) to 1 (b).
function unv__mix_rgb(_a, _b, _t) { return [_a[0] + (_b[0] - _a[0]) * _t, _a[1] + (_b[1] - _a[1]) * _t, _a[2] + (_b[2] - _a[2]) * _t]; }

/// @function unv__veil_velvet(ctx, w, h, stage, rng)
/// @description Internal. Crushed velvet: soft elongated patches where the pile lies toward the light or away from it, at
/// seeded angles; the nap as fine leaning marks; a sheen band where the light catches the pile.
function unv__veil_velvet(_c, _w, _h, _T, _R) {
    // each crushed patch is a CHAIN of soft discs along a seeded direction (2026-10-16: one radial fill under a rotated,
    // squashed transform showed its rectangle's hard edges and fell off the kit's fast path, 4.6 s a veil)
    for (var _i = 0; _i < 34; _i++) {
        var _x = unv__rand(_R) * _w; var _y = unv__rand(_R) * _h; var _r = 34 + unv__rand(_R) * 70;
        var _ang = unv__rand(_R) * pi; var _light = unv__rand(_R) < 0.5; var _al = 0.12 + unv__rand(_R) * 0.16; var _len = 1.2 + unv__rand(_R) * 1.6;
        var _col = _light ? _T.fold : [0, 0, 0];
        for (var _s = -2; _s <= 2; _s++) {
            var _cx = _x + cos(_ang) * _s * _r * _len * 0.45, _cy = _y + sin(_ang) * _s * _r * _len * 0.45, _cr = _r * (1 - abs(_s) * 0.18);
            var _g = unv_cx_radial(_c, _cx, _cy, 0, _cx, _cy, _cr); unv_cx_stop(_g, 0, _col, _al * (1 - abs(_s) * 0.2)); unv_cx_stop(_g, 1, _col, 0);
            _c.fill = _g; unv__p_fill_rect(_c, _cx - _cr, _cy - _cr, _cr * 2, _cr * 2);
        }
    }
    var _nap = array_create(1400), _nc = unv_col(_T.fold);
    for (var _k = 0; _k < 1400; _k++) { var _nx = unv__rand(_R) * _w; var _ny = unv__rand(_R) * _h; var _na = 0.05 + unv__rand(_R) * 0.08; _nap[_k] = [_nx, _ny, 1, 3, _nc, _na]; }
    unv_cx_fill_rects(_c, _nap);
    var _sb = unv_cx_linear(_c, 0, _h * 0.15, _w, _h * 0.85);
    unv_cx_stop(_sb, 0, _T.fold, 0); unv_cx_stop(_sb, 0.42, _T.fold, 0); unv_cx_stop(_sb, 0.5, _T.fold, 0.2); unv_cx_stop(_sb, 0.58, _T.fold, 0); unv_cx_stop(_sb, 1, _T.fold, 0);
    _c.fill = _sb; unv__p_fill_rect(_c, 0, 0, _w, _h);
}

/// @function unv__veil_washi(ctx, w, h, stage, rng)
/// @description Internal. Washi paper: long kozo fibres laid in the sheet, then a block-printed asanoha (hemp-leaf)
/// lattice in vermilion - a triangle grid with every triangle's corners joined to its centre - at a seeded pitch and offset.
function unv__veil_washi(_c, _w, _h, _T, _R) {
    _c.join = 0;
    for (var _i = 0; _i < 140; _i++) {
        var _x = unv__rand(_R) * _w; var _y = unv__rand(_R) * _h; var _a = unv__rand(_R) * UNV_TAU; var _len = 30 + unv__rand(_R) * 120;
        var _bend = (unv__rand(_R) - 0.5) * 40; var _al = 0.12 + unv__rand(_R) * 0.22; var _lw = 0.6 + unv__rand(_R) * 0.9;
        var _ex = _x + cos(_a) * _len, _ey = _y + sin(_a) * _len, _mx = (_x + _ex) / 2 - sin(_a) * _bend, _my = (_y + _ey) / 2 + cos(_a) * _bend;
        _c.stroke = unv_cx_solid(_T.fold, _al); _c.lw = _lw;
        unv__p_begin(_c); unv__p_move(_c, _x, _y); unv__p_quad(_c, _mx, _my, _ex, _ey); unv__p_stroke(_c);
    }
    var _pitch = unv__rand(_R); var _s = 60 + floor(_pitch * 4) * 6, _hh = _s * sqrt(3) / 2;
    var _ox0 = unv__rand(_R); var _oy0 = unv__rand(_R); var _ox = -_ox0 * _s, _oy = -_oy0 * _hh;
    var _rows = ceil((_h - _oy) / _hh) + 1, _cols = ceil(_w / _s) + 2;
    // the three line families as long lines: rows, and two diagonals through the lattice points
    unv__p_begin(_c);
    for (var _r = 0; _r <= _rows; _r++) { var _ly = _oy + _r * _hh; unv__p_move(_c, 0, _ly); unv__p_line(_c, _w, _ly); }
    var _span = _h + _hh * 2, _dxs = _span / sqrt(3);
    for (var _k = -ceil(_span / _s) - 1; _k <= _cols + ceil(_span / _s); _k++) {
        var _x0 = _ox + _k * _s;
        unv__p_move(_c, _x0, _oy); unv__p_line(_c, _x0 + _dxs, _oy + _span);
        unv__p_move(_c, _x0, _oy); unv__p_line(_c, _x0 - _dxs, _oy + _span);
    }
    _c.stroke = unv_cx_solid(_T.rim, 0.16); _c.lw = 1; unv__p_stroke(_c);   // the grid stays quiet: the leaves are the print
    // the leaves: each triangle's corners joined to its centroid, all in one path
    unv__p_begin(_c);
    for (var _rr = 0; _rr < _rows; _rr++) for (var _cc = -1; _cc < _cols; _cc++) {
        var _odd = (_rr mod 2), _px0 = _ox + _cc * _s + _odd * _s / 2, _py0 = _oy + _rr * _hh, _py1 = _py0 + _hh;
        // up-pointing: (p, p + s, below between) and down-pointing: (below, below + s, p + s)
        var _qx = _px0 + _s / 2;
        var _tri = [[_px0, _py0, _px0 + _s, _py0, _qx, _py1], [_qx, _py1, _qx + _s, _py1, _px0 + _s, _py0]];
        for (var _t = 0; _t < 2; _t++) {
            var _v = _tri[_t], _gx = (_v[0] + _v[2] + _v[4]) / 3, _gy = (_v[1] + _v[3] + _v[5]) / 3;
            if (_gx < -_s || _gx > _w + _s || _gy < -_s || _gy > _h + _s) continue;
            for (var _e = 0; _e < 3; _e++) { unv__p_move(_c, _v[_e * 2], _v[_e * 2 + 1]); unv__p_line(_c, _gx, _gy); }
        }
    }
    _c.stroke = unv_cx_solid(_T.rim, 0.36); _c.lw = 1.2; unv__p_stroke(_c);
}

/// @function unv__veil_smoke(ctx, w, h, stage, rng)
/// @description Internal. Smoke: plumes rising from below the frame, each a chain of soft billows that widen and fade as
/// they climb and drift, a wisp threaded through each, and darker eddies between them.
function unv__veil_smoke(_c, _w, _h, _T, _R) {
    for (var _d = 0; _d < 12; _d++) {
        var _ex = unv__rand(_R) * _w; var _ey = unv__rand(_R) * _h; var _er = 50 + unv__rand(_R) * 120; var _ea = 0.18 + unv__rand(_R) * 0.18;
        var _dg = unv_cx_radial(_c, _ex, _ey, 0, _ex, _ey, _er); unv_cx_stop(_dg, 0, [0, 0, 0], _ea); unv_cx_stop(_dg, 1, [0, 0, 0], 0);
        _c.fill = _dg; unv__p_fill_rect(_c, _ex - _er, _ey - _er, _er * 2, _er * 2);
    }
    _c.join = 0; _c.cap = UNV_STROKE_ROUND;
    for (var _p = 0; _p < 9; _p++) {
        var _x0 = unv__rand(_R) * _w; var _drift = (unv__rand(_R) - 0.5) * 0.9; var _ph = unv__rand(_R) * UNV_TAU; var _sway = 18 + unv__rand(_R) * 30;
        var _pts = [];
        for (var _k = 0; _k < 10; _k++) {
            var _t = _k / 9, _cx = _x0 + _drift * _t * _h * 0.6 + sin(_t * 5 + _ph) * _sway, _cy = _h + 30 - _t * _h * 1.08, _r = 30 + _t * 110;
            array_push(_pts, [_cx, _cy]);
            var _g = unv_cx_radial(_c, _cx, _cy, 0, _cx, _cy, _r); unv_cx_stop(_g, 0, _T.fold, 0.3 * (1 - _t * 0.65)); unv_cx_stop(_g, 0.55, _T.fold, 0.12 * (1 - _t * 0.65)); unv_cx_stop(_g, 1, _T.fold, 0);
            _c.fill = _g; unv__p_fill_rect(_c, _cx - _r, _cy - _r, _r * 2, _r * 2);
        }
        // a short, faint wisp off the plume's lower half only (2026-10-16: full-height wisps read as strands of hair)
        _c.stroke = unv_cx_solid(_T.fold, 0.16); _c.lw = 1.1;
        unv__p_begin(_c); unv__p_move(_c, _pts[1][0], _pts[1][1]);
        for (var _q = 2; _q < 5; _q++) unv__p_quad(_c, _pts[_q][0], _pts[_q][1], (_pts[_q][0] + _pts[_q + 1][0]) / 2, (_pts[_q][1] + _pts[_q + 1][1]) / 2);
        unv__p_stroke(_c);
    }
    _c.cap = 0;
}

/// @function unv__veil_inkwash(ctx, w, h, stage, rng)
/// @description Internal. Sumi-e: four ridges of mountains, back to front, each a seeded ridge line filled downward with
/// ink that fades into mist (paler the further back); a skein of birds; a vermilion seal in a corner.
function unv__veil_inkwash(_c, _w, _h, _T, _R) {
    for (var _L = 0; _L < 4; _L++) {
        var _base = _h * (0.28 + _L * 0.18), _amp = 70 - _L * 10, _n = 33, _hs = array_create(_n, 0);
        // a ridge by midpoint displacement: ends first, then halves, each displacement half the last
        var _e0 = unv__rand(_R); var _e1 = unv__rand(_R); _hs[0] = (_e0 - 0.5) * _amp; _hs[_n - 1] = (_e1 - 0.5) * _amp;
        var _step = _n - 1, _amp2 = _amp;
        while (_step > 1) {
            var _half = _step div 2;
            for (var _i = _half; _i < _n; _i += _step) { var _dv = unv__rand(_R); _hs[_i] = (_hs[_i - _half] + _hs[min(_n - 1, _i + _half)]) / 2 + (_dv - 0.5) * _amp2; }
            _step = _half; _amp2 *= 0.55;
        }
        var _top = _base - _amp;
        var _g = unv_cx_linear(_c, 0, _top, 0, _base + 190); unv_cx_stop(_g, 0, _T.fold, 0.16 + _L * 0.13); unv_cx_stop(_g, 0.55, _T.fold, 0.06 + _L * 0.05); unv_cx_stop(_g, 1, _T.fold, 0);
        _c.fill = _g;
        unv__p_begin(_c); unv__p_move(_c, -20, _base + _hs[0] - _amp * 0.5);
        for (var _j = 1; _j < _n; _j++) unv__p_line(_c, -20 + (_w + 40) * _j / (_n - 1), _base + _hs[_j] - _amp * 0.5 * (1 - abs(_j / (_n - 1) - 0.5)));
        unv__p_line(_c, _w + 20, _base + 190); unv__p_line(_c, -20, _base + 190); unv__p_close(_c); unv__p_fill(_c);
    }
    // birds: a loose skein of small strokes
    var _bx = unv__rand(_R) * _w * 0.6 + _w * 0.1; var _by = unv__rand(_R) * _h * 0.2 + _h * 0.08; var _nb = 5 + floor(unv__rand(_R) * 5);
    _c.stroke = unv_cx_solid(_T.fold, 0.7); _c.lw = 1.4; _c.join = 0;
    for (var _b = 0; _b < _nb; _b++) {
        var _jx = unv__rand(_R); var _jy = unv__rand(_R); var _sz = 5 + unv__rand(_R) * 5;
        var _x = _bx + _b * 22 + _jx * 14, _y = _by + _b * 7 + _jy * 10;
        unv__p_begin(_c); unv__p_move(_c, _x - _sz, _y - _sz * 0.3); unv__p_quad(_c, _x - _sz * 0.4, _y - _sz * 0.6, _x, _y); unv__p_quad(_c, _x + _sz * 0.4, _y - _sz * 0.6, _x + _sz, _y - _sz * 0.3); unv__p_stroke(_c);
    }
    // the seal: a vermilion square with an engraved border and three strokes of a mark
    var _ss = 34, _sx = _w - _ss - 26, _sy = _h - _ss - 26;
    _c.fill = unv_cx_solid(_T.trail, 0.86); unv__p_fill_rect(_c, _sx, _sy, _ss, _ss);
    _c.stroke = unv_cx_solid(_T.a, 0.9); _c.lw = 1.4; unv__p_begin(_c); unv_cx_rect(_c, _sx + 4, _sy + 4, _ss - 8, _ss - 8); unv__p_stroke(_c);
    for (var _m = 0; _m < 3; _m++) {
        var _m0 = unv__rand(_R); var _m1 = unv__rand(_R);
        unv__p_begin(_c); unv__p_move(_c, _sx + 9 + _m0 * 6, _sy + 9 + _m * 7); unv__p_line(_c, _sx + _ss - 9 - _m1 * 6, _sy + 11 + _m * 7); unv__p_stroke(_c);
    }
}

/// @function unv__veil_leaded(ctx, w, h, stage, rng)
/// @description Internal. Leaded cathedral glass: a hand-cut lattice of panes (a jittered grid, the frame kept straight),
/// each pane a jewel colour with light falling across it, and the lead cames over every joint with a dull highlight.
function unv__veil_leaded(_c, _w, _h, _T, _R) {
    var _jewel = [[166, 26, 44], [34, 64, 168], [210, 140, 34], [30, 128, 82], [112, 52, 150], [196, 186, 148], [40, 120, 150]];
    var _gc = unv__rand(_R); var _gr = unv__rand(_R); var _cols = 9 + floor(_gc * 4), _rows = 6 + floor(_gr * 3);
    var _cw = _w / _cols, _rh = _h / _rows, _P = array_create((_cols + 1) * (_rows + 1));
    for (var _j = 0; _j <= _rows; _j++) for (var _i = 0; _i <= _cols; _i++) {
        var _jx = unv__rand(_R); var _jy = unv__rand(_R);
        var _x = _i * _cw + ((_i == 0 || _i == _cols) ? 0 : (_jx - 0.5) * _cw * 0.36);
        var _y = _j * _rh + ((_j == 0 || _j == _rows) ? 0 : (_jy - 0.5) * _rh * 0.36);
        _P[_j * (_cols + 1) + _i] = [_x, _y];
    }
    for (var _r = 0; _r < _rows; _r++) for (var _q = 0; _q < _cols; _q++) {
        var _pick = unv__rand(_R); var _lit = unv__rand(_R);
        var _col = _jewel[floor(_pick * array_length(_jewel)) mod array_length(_jewel)];
        var _a = _P[_r * (_cols + 1) + _q], _b = _P[_r * (_cols + 1) + _q + 1], _d = _P[(_r + 1) * (_cols + 1) + _q], _e = _P[(_r + 1) * (_cols + 1) + _q + 1];
        var _g = unv_cx_linear(_c, _a[0], _a[1], _e[0], _e[1]);
        unv_cx_stop(_g, 0, unv__mix_rgb(_col, [255, 250, 230], 0.18 + _lit * 0.22)); unv_cx_stop(_g, 1, unv__mix_rgb(_col, [0, 0, 0], 0.35));
        _c.fill = _g; unv__p_begin(_c); unv__p_move(_c, _a[0], _a[1]); unv__p_line(_c, _b[0], _b[1]); unv__p_line(_c, _e[0], _e[1]); unv__p_line(_c, _d[0], _d[1]); unv__p_close(_c); unv__p_fill(_c);
    }
    // the cames: every grid line as one polyline, dark and wide, then a narrow dull highlight
    _c.join = 0;
    for (var _pass = 0; _pass < 2; _pass++) {
        unv__p_begin(_c);
        for (var _rr = 0; _rr <= _rows; _rr++) { for (var _k = 0; _k <= _cols; _k++) { var _p = _P[_rr * (_cols + 1) + _k]; if (_k == 0) unv__p_move(_c, _p[0], _p[1]); else unv__p_line(_c, _p[0], _p[1]); } }
        for (var _cc = 0; _cc <= _cols; _cc++) { for (var _k2 = 0; _k2 <= _rows; _k2++) { var _p2 = _P[_k2 * (_cols + 1) + _cc]; if (_k2 == 0) unv__p_move(_c, _p2[0], _p2[1]); else unv__p_line(_c, _p2[0], _p2[1]); } }
        _c.stroke = (_pass == 0) ? unv_cx_solid(_T.a, 1) : unv_cx_solid([132, 130, 138], 0.55); _c.lw = (_pass == 0) ? 6 : 1.5;
        unv__p_stroke(_c);
    }
}
