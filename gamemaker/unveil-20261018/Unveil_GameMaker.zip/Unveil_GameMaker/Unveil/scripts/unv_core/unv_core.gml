/// unv_core.gml - Unveil's rules: a Qix-style territory-capture game over the buyer's picture. Pure GML: nothing here
/// draws, and nothing uses the engine's random functions.
///
/// Unveil - Reveal Any Picture, a Qix-Style Minigame for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// The RPG Maker MZ edition's UnveilCore.js, ported line for line and held to it by the in-engine suite (unv_selftest).
///
/// How a game works
///   The field is a grid of cells: UNV_CLAIMED (the picture shows through), UNV_OPEN (still veiled) and UNV_TRAIL (the line
///   the player is drawing). The frame of the grid starts claimed. The player walks the edge of the claimed land; holding
///   "draw" it cuts into the veil, and when the trail reaches claimed land again every open region that holds no creature
///   is claimed. A creature touching the trail, or a spark running along the edge touching the player, costs a life.
///   Claim the target share to win. The same seed always plays the same game.
///
/// Public functions (each documented below): unv_hash_string, unv_mix, unv_create_game, unv_at, unv_is_edge, unv_percent,
/// unv_nearest_edge, unv_claim, unv_move, unv_tick, unv_results, unv_is_game.

#macro UNV_VERSION "1.0.0"
#macro UNV_OPEN 0
#macro UNV_CLAIMED 1
#macro UNV_TRAIL 2
#macro UNV_SPARK_CLEARANCE 12

// ---------------------------------------------------------------------------------------------------------------
// Unsigned 32-bit arithmetic, the hash, the mix and the generator (the MZ edition's, exact)
// ---------------------------------------------------------------------------------------------------------------

/// @function unv__imul(a, b)
/// @description Internal. JavaScript's Math.imul on unsigned 32-bit values, as int64 halves.
function unv__imul(_a, _b) {
    var _m = int64($FFFFFFFF);
    _a = int64(_a) & _m; _b = int64(_b) & _m;
    var _lo = (_a * (_b & int64($FFFF))) & _m;
    var _hi = ((_a * (_b >> 16)) & int64($FFFF)) << 16;
    return (_lo + _hi) & _m;
}

/// @function unv__u32(v)
/// @description Internal. JavaScript's (v >>> 0) for a number: truncated toward zero, then modulo 2^32; not a number -> 0.
function unv__u32(_v) {
    if (!is_numeric(_v) || is_nan(_v) || is_infinity(_v)) return int64(0);
    if (_v < 0) return (int64($100000000) - (int64(-_v) & int64($FFFFFFFF))) & int64($FFFFFFFF);
    return int64(_v) & int64($FFFFFFFF);
}

/// @function unv_hash_string(text)
/// @description The FNV-1a hash of a word, as the MZ edition computes it (UTF-16 code units). Pure.
/// @param {String} text   anything; a non-string is hashed as its string form
/// @returns {Real} 0 .. 4294967295
function unv_hash_string(_s) {
    var _t = is_string(_s) ? _s : string(_s);
    var _h = int64(2166136261), _n = string_length(_t);
    for (var _i = 1; _i <= _n; _i++) { _h = _h ^ int64(ord(string_char_at(_t, _i)) & $FFFF); _h = unv__imul(_h, 16777619); }
    return real(_h);
}

/// @function unv_mix(a, b)
/// @description Two unsigned 32-bit numbers mixed into one, as the MZ edition does (seed derivation). Pure.
/// @param {Real} a
/// @param {Real} b
/// @returns {Real} 0 .. 4294967295
function unv_mix(_a, _b) {
    var _m = int64($FFFFFFFF);
    var _h = unv__imul(unv__u32(_a) ^ int64($9E3779B9), int64($85EBCA6B)) ^ unv__u32(_b);
    _h = unv__imul((_h ^ (_h >> 13)) & _m, int64($C2B2AE35));
    return real((_h ^ (_h >> 16)) & _m);
}

/// @function unv__rand(game)
/// @description Internal. The next draw in [0, 1) from the game's own generator (mulberry32, state game.rs).
function unv__rand(_g) {
    var _m = int64($FFFFFFFF);
    _g.rs = (_g.rs + int64($6D2B79F5)) & _m;
    var _t = _g.rs;
    _t = unv__imul(_t ^ (_t >> 15), _t | 1);
    var _x = unv__imul(_t ^ (_t >> 7), _t | 61);
    _t = _t ^ ((_t + _x) & _m);
    return real((_t ^ (_t >> 14)) & _m) / 4294967296;
}

/// @function unv__num(v, fallback)
/// @description Internal. JavaScript's `Number(v) || d` for the cases the rules meet: a finite non-zero number, else d.
function unv__num(_v, _d) {
    if (is_numeric(_v) && !is_nan(_v) && !is_infinity(_v) && _v != 0) return _v;
    return _d;
}

/// @function unv__opt(options, name)
/// @description Internal. A field of an options struct, or undefined.
function unv__opt(_o, _k) { return (is_struct(_o) && variable_struct_exists(_o, _k)) ? _o[$ _k] : undefined; }

/// @function unv_is_game(game)
/// @description True when the value is a game made by unv_create_game. Every rule checks this first.
/// @param {Any} game
/// @returns {Bool}
function unv_is_game(_g) {
    return is_struct(_g) && variable_struct_exists(_g, "cells") && is_array(_g.cells) && variable_struct_exists(_g, "cols")
        && variable_struct_exists(_g, "rows") && array_length(_g.cells) == _g.cols * _g.rows;
}

// ---------------------------------------------------------------------------------------------------------------
// A new game
// ---------------------------------------------------------------------------------------------------------------

/// @function unv_create_game(seed, [options])
/// @description A new game. The same seed and options always make the same game. Pure (no drawing, no engine random).
/// @param {Real} seed       an unsigned 32-bit number (unv_hash_string turns a word into one)
/// @param {Struct} [options] { cols (96), rows (64), target percent (75), lives (3), creatures in the veil (1, max 4),
///                          sparks on the edge (2, max 6), creature_speed in cells a frame (0.35), spark_every frames per
///                          spark step (3) }. Missing or zero fields take the default.
/// @returns {Struct} the game: cells, the player (px, py), creatures, sparks, lives, phase ("play" | "won" | "lost") ...
function unv_create_game(_seed, _o = undefined) {
    var _eps = math_get_epsilon(); math_set_epsilon(0);
    var _sd = unv__u32(_seed);
    var _cols = max(16, min(160, floor(unv__num(unv__opt(_o, "cols"), 96))));
    var _rows = max(12, min(120, floor(unv__num(unv__opt(_o, "rows"), 64))));
    var _n = _cols * _rows;
    var _g = {
        v: 1, seed: real(_sd), rs: int64(unv_mix(_sd, $0A11)) & int64($FFFFFFFF), cols: _cols, rows: _rows,
        cells: array_create(_n, UNV_OPEN),
        target: max(10, min(95, unv__num(unv__opt(_o, "target"), 75))),
        lives: max(1, floor(unv__num(unv__opt(_o, "lives"), 3))),
        creatureSpeed: max(0.05, min(1, unv__num(unv__opt(_o, "creature_speed"), 0.35))),
        sparkEvery: max(1, floor(unv__num(unv__opt(_o, "spark_every"), 3))),
        px: floor(_cols / 2), py: _rows - 1, drawing: false, trail: array_create(_n, 0), trailLen: 0, sx: 0, sy: 0,
        creatures: [], sparks: [], claimed: 0, interior: (_cols - 2) * (_rows - 2), frame: 0, phase: "play", hits: 0, cuts: 0,
        stack: array_create(_n, 0), mark: array_create(_n, 0), markGen: 0
    };
    _g.livesMax = _g.lives;
    for (var _x = 0; _x < _cols; _x++) { _g.cells[_x] = UNV_CLAIMED; _g.cells[(_rows - 1) * _cols + _x] = UNV_CLAIMED; }
    for (var _y = 0; _y < _rows; _y++) { _g.cells[_y * _cols] = UNV_CLAIMED; _g.cells[_y * _cols + _cols - 1] = UNV_CLAIMED; }
    var _ncv = unv__opt(_o, "creatures"); _ncv = (is_numeric(_ncv) && !is_nan(_ncv) && !is_infinity(_ncv)) ? _ncv : 1;
    var _nc = max(1, min(4, floor(_ncv)));
    for (var _c = 0; _c < _nc; _c++) {
        // the MZ edition draws angle, then x, then y: drawn into variables in that order (GML evaluates arguments right to left)
        var _a = unv__rand(_g) * pi * 2;
        var _rx = unv__rand(_g);
        var _ry = unv__rand(_g);
        array_push(_g.creatures, { x: _cols / 2 + (_rx - 0.5) * _cols * 0.3, y: _rows / 2 + (_ry - 0.5) * _rows * 0.3,
            vx: cos(_a) * _g.creatureSpeed, vy: sin(_a) * _g.creatureSpeed });
    }
    var _nsv = unv__opt(_o, "sparks"); _nsv = (is_numeric(_nsv) && !is_nan(_nsv) && !is_infinity(_nsv)) ? _nsv : 2;
    var _ns = max(0, min(6, floor(_nsv)));
    for (var _s = 0; _s < _ns; _s++) array_push(_g.sparks, { x: (_s mod 2 == 1) ? _cols - 1 : 0, y: 0, px: -1, py: -1 });
    math_set_epsilon(_eps);
    return _g;
}

// ---------------------------------------------------------------------------------------------------------------
// Reading the board
// ---------------------------------------------------------------------------------------------------------------

/// @function unv_at(game, x, y)
/// @description The cell at (x, y): UNV_OPEN, UNV_CLAIMED or UNV_TRAIL. Off the board reads UNV_CLAIMED. Not a game -> UNV_CLAIMED.
/// @param {Struct} game
/// @param {Real} x
/// @param {Real} y
/// @returns {Real}
function unv_at(_g, _x, _y) {
    if (!unv_is_game(_g) || !is_numeric(_x) || !is_numeric(_y) || is_nan(_x) || is_nan(_y)) return UNV_CLAIMED;
    return unv__at(_g, floor(_x), floor(_y));
}

/// @function unv__at(game, x, y)
/// @description Internal. unv_at without the guards, for whole numbers on a known game (the rules' inner loops).
function unv__at(_g, _x, _y) {
    if (_x < 0 || _y < 0 || _x >= _g.cols || _y >= _g.rows) return UNV_CLAIMED;
    return _g.cells[_y * _g.cols + _x];
}

/// @function unv__is_edge(game, x, y)
/// @description Internal. unv_is_edge without the guards, for whole numbers on a known game.
function unv__is_edge(_g, _x, _y) {
    if (_x < 0 || _y < 0 || _x >= _g.cols || _y >= _g.rows) return false;
    if (_g.cells[_y * _g.cols + _x] != UNV_CLAIMED) return false;
    for (var _dy = -1; _dy <= 1; _dy++) for (var _dx = -1; _dx <= 1; _dx++) {
        if ((_dx != 0 || _dy != 0) && unv__at(_g, _x + _dx, _y + _dy) == UNV_OPEN) return true;
    }
    return false;
}

/// @function unv_is_edge(game, x, y)
/// @description True for a claimed cell touching the veil (any of 8 neighbours open): where the player and the sparks walk.
/// @param {Struct} game
/// @param {Real} x
/// @param {Real} y
/// @returns {Bool}
function unv_is_edge(_g, _x, _y) {
    if (!unv_is_game(_g) || !is_numeric(_x) || !is_numeric(_y) || is_nan(_x) || is_nan(_y)) return false;
    if (_x != floor(_x) || _y != floor(_y)) return false;
    return unv__is_edge(_g, _x, _y);
}

/// @function unv_percent(game)
/// @description Percent of the interior claimed, 0..100 with one decimal. Not a game -> 0.
/// @param {Struct} game
/// @returns {Real}
function unv_percent(_g) {
    if (!unv_is_game(_g)) return 0;
    return floor(1000 * _g.claimed / _g.interior + 0.5) / 10;   // JavaScript's Math.round is half-up
}

/// @function unv_nearest_edge(game, x, y, ax, ay, min_dist)
/// @description The nearest edge cell to (x, y), searched outward with the game's own queue and mark buffers (no
/// allocation), preferring one at least min_dist steps (Manhattan) from (ax, ay); the plain nearest when none is. A claim
/// can leave the player, or a spark, on land that no longer touches the veil: this is where it goes.
/// @returns {Real} the cell index (y * cols + x), or -1 when the board has no edge left (or the input is not a game)
function unv_nearest_edge(_g, _x, _y, _ax, _ay, _min) {
    if (!unv_is_game(_g) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_ax) || !is_numeric(_ay) || !is_numeric(_min)) return -1;
    if (_x < 0 || _y < 0 || _x >= _g.cols || _y >= _g.rows) return -1;
    var _cols = _g.cols, _rows = _g.rows, _head = 0, _tail = 0, _first = -1, _start = floor(_y) * _cols + floor(_x);
    _g.markGen++; _g.stack[_tail++] = _start; _g.mark[_start] = _g.markGen;
    while (_head < _tail) {
        var _k = _g.stack[_head++], _kx = _k mod _cols, _ky = (_k - _kx) / _cols;
        if (unv__is_edge(_g, _kx, _ky)) { if (_first < 0) _first = _k; if (abs(_kx - _ax) + abs(_ky - _ay) >= _min) return _k; }
        if (_kx > 0 && _g.mark[_k - 1] != _g.markGen) { _g.mark[_k - 1] = _g.markGen; _g.stack[_tail++] = _k - 1; }
        if (_kx < _cols - 1 && _g.mark[_k + 1] != _g.markGen) { _g.mark[_k + 1] = _g.markGen; _g.stack[_tail++] = _k + 1; }
        if (_ky > 0 && _g.mark[_k - _cols] != _g.markGen) { _g.mark[_k - _cols] = _g.markGen; _g.stack[_tail++] = _k - _cols; }
        if (_ky < _rows - 1 && _g.mark[_k + _cols] != _g.markGen) { _g.mark[_k + _cols] = _g.markGen; _g.stack[_tail++] = _k + _cols; }
    }
    return _first;
}

// ---------------------------------------------------------------------------------------------------------------
// Claiming, losing a life, moving, and one frame of the world
// ---------------------------------------------------------------------------------------------------------------

/// @function unv_claim(game)
/// @description Close the trail: the trail becomes claimed land, and every open region with no creature in it is claimed
/// too (the game's own stack and mark buffers, no allocation). Called by unv_move when a cut closes; public for tools.
/// @param {Struct} game
/// @returns {Real} the cells claimed by this cut (0 when not a game)
function unv_claim(_g) {
    if (!unv_is_game(_g)) return 0;
    var _eps = math_get_epsilon(); math_set_epsilon(0);
    var _cols = _g.cols, _n = array_length(_g.cells), _before = _g.claimed, _i;
    for (_i = 0; _i < _g.trailLen; _i++) { _g.cells[_g.trail[_i]] = UNV_CLAIMED; _g.claimed++; }
    _g.trailLen = 0; _g.drawing = false; _g.cuts++;
    // label the regions that hold a creature, then claim every open cell left unlabelled
    _g.markGen++;
    for (var _c = 0; _c < array_length(_g.creatures); _c++) {
        var _cx = floor(_g.creatures[_c].x), _cy = floor(_g.creatures[_c].y), _start = _cy * _cols + _cx;
        if (_start < 0 || _start >= _n) continue;
        if (_g.cells[_start] != UNV_OPEN || _g.mark[_start] == _g.markGen) continue;
        var _sp = 0; _g.stack[_sp++] = _start; _g.mark[_start] = _g.markGen;
        while (_sp > 0) {
            var _k = _g.stack[--_sp], _kx = _k mod _cols, _ky = (_k - _kx) / _cols;
            if (_kx > 0 && _g.cells[_k - 1] == UNV_OPEN && _g.mark[_k - 1] != _g.markGen) { _g.mark[_k - 1] = _g.markGen; _g.stack[_sp++] = _k - 1; }
            if (_kx < _cols - 1 && _g.cells[_k + 1] == UNV_OPEN && _g.mark[_k + 1] != _g.markGen) { _g.mark[_k + 1] = _g.markGen; _g.stack[_sp++] = _k + 1; }
            if (_ky > 0 && _g.cells[_k - _cols] == UNV_OPEN && _g.mark[_k - _cols] != _g.markGen) { _g.mark[_k - _cols] = _g.markGen; _g.stack[_sp++] = _k - _cols; }
            if (_ky < _g.rows - 1 && _g.cells[_k + _cols] == UNV_OPEN && _g.mark[_k + _cols] != _g.markGen) { _g.mark[_k + _cols] = _g.markGen; _g.stack[_sp++] = _k + _cols; }
        }
    }
    for (_i = 0; _i < _n; _i++) if (_g.cells[_i] == UNV_OPEN && _g.mark[_i] != _g.markGen) { _g.cells[_i] = UNV_CLAIMED; _g.claimed++; }
    if (unv_percent(_g) >= _g.target) _g.phase = "won";
    else unv__settle(_g);
    math_set_epsilon(_eps);
    return _g.claimed - _before;
}

/// @function unv__settle(game)
/// @description Internal. After a claim: whoever now stands on land that touches no veil steps to the nearest edge (sparks:
/// not onto the player).
function unv__settle(_g) {
    var _k;
    if (!unv__is_edge(_g, _g.px, _g.py)) { _k = unv_nearest_edge(_g, _g.px, _g.py, _g.px, _g.py, 0); if (_k >= 0) { _g.px = _k mod _g.cols; _g.py = (_k - _g.px) / _g.cols; } }
    for (var _s = 0; _s < array_length(_g.sparks); _s++) {
        var _sp = _g.sparks[_s];
        if (unv__is_edge(_g, _sp.x, _sp.y)) continue;
        _k = unv_nearest_edge(_g, _sp.x, _sp.y, _g.px, _g.py, UNV_SPARK_CLEARANCE);
        if (_k >= 0) { _sp.x = _k mod _g.cols; _sp.y = (_k - _sp.x) / _g.cols; _sp.px = -1; _sp.py = -1; }
    }
}

/// @function unv__hit(game)
/// @description Internal. The trail is broken (a creature or a spark): a life lost, the trail erased, the player back
/// where the cut began.
function unv__hit(_g) {
    for (var _i = 0; _i < _g.trailLen; _i++) _g.cells[_g.trail[_i]] = UNV_OPEN;
    if (_g.drawing) { _g.px = _g.sx; _g.py = _g.sy; }
    _g.trailLen = 0; _g.drawing = false; _g.lives--; _g.hits++;
    if (_g.lives <= 0) { _g.lives = 0; _g.phase = "lost"; }
}

/// @function unv_move(game, dx, dy, draw)
/// @description Move the player one cell (dx, dy each -1, 0 or 1, exactly one of them non-zero). Without draw the player
/// keeps to the edge of the claimed land; with it, it cuts into the veil. Crossing its own trail is refused. Reaching
/// claimed land again closes the cut (unv_claim).
/// @param {Struct} game
/// @param {Real} dx
/// @param {Real} dy
/// @param {Bool} draw
/// @returns {String} "moved" | "cut" | "closed" | "blocked" (also "blocked" for anything that is not a game)
function unv_move(_g, _dx, _dy, _draw) {
    if (!unv_is_game(_g) || !is_numeric(_dx) || !is_numeric(_dy)) return "blocked";
    if (_g.phase != "play" || (_dx != 0 && _dy != 0) || (_dx == 0 && _dy == 0)) return "blocked";
    if (abs(_dx) != 1 && _dx != 0) return "blocked";
    if (abs(_dy) != 1 && _dy != 0) return "blocked";
    var _nx = _g.px + _dx, _ny = _g.py + _dy;
    if (_nx < 0 || _ny < 0 || _nx >= _g.cols || _ny >= _g.rows) return "blocked";
    var _c = _g.cells[_ny * _g.cols + _nx];
    var _dr = (is_numeric(_draw) || is_bool(_draw)) ? bool(_draw) : false;
    if (!_g.drawing) {
        if (_c == UNV_CLAIMED) { if (!unv__is_edge(_g, _nx, _ny)) return "blocked"; _g.px = _nx; _g.py = _ny; return "moved"; }
        if (_c == UNV_OPEN && _dr) { _g.drawing = true; _g.sx = _g.px; _g.sy = _g.py; _g.cells[_ny * _g.cols + _nx] = UNV_TRAIL; _g.trail[_g.trailLen++] = _ny * _g.cols + _nx; _g.px = _nx; _g.py = _ny; return "cut"; }
        return "blocked";
    }
    if (_c == UNV_TRAIL) return "blocked";
    _g.px = _nx; _g.py = _ny;
    if (_c == UNV_OPEN) { _g.cells[_ny * _g.cols + _nx] = UNV_TRAIL; _g.trail[_g.trailLen++] = _ny * _g.cols + _nx; return "cut"; }
    unv_claim(_g); return "closed";
}

/// @function unv_tick(game)
/// @description One frame of the world: creatures drift through the veil and bounce off claimed land (touching the trail
/// breaks it); sparks run along the edge every spark_every frames (touching the player costs a life). Allocates nothing.
/// @param {Struct} game
/// @returns {Struct} the game (or the value handed in, untouched, when it is not a game)
function unv_tick(_g) {
    if (!unv_is_game(_g)) return _g;
    if (_g.phase != "play") return _g;
    var _eps = math_get_epsilon(); math_set_epsilon(0);
    _g.frame++;
    for (var _c = 0; _c < array_length(_g.creatures); _c++) {
        var _q = _g.creatures[_c], _nx = _q.x + _q.vx, _ny = _q.y + _q.vy;
        var _hx = unv__at(_g, floor(_nx), floor(_q.y)), _hy = unv__at(_g, floor(_q.x), floor(_ny));
        if (_hx == UNV_TRAIL || _hy == UNV_TRAIL) { unv__hit(_g); if (_g.phase != "play") { math_set_epsilon(_eps); return _g; } continue; }
        if (_hx == UNV_CLAIMED) { _q.vx = -_q.vx; _nx = _q.x; }
        if (_hy == UNV_CLAIMED) { _q.vy = -_q.vy; _ny = _q.y; }
        if (unv__at(_g, floor(_nx), floor(_ny)) == UNV_OPEN) { _q.x = _nx; _q.y = _ny; }
        else { _q.vx = -_q.vx; _q.vy = -_q.vy; }
    }
    if (_g.frame mod _g.sparkEvery == 0) for (var _s = 0; _s < array_length(_g.sparks); _s++) {
        var _sp = _g.sparks[_s];
        if (!unv__is_edge(_g, _sp.x, _sp.y)) {
            var _e = unv_nearest_edge(_g, _sp.x, _sp.y, _g.px, _g.py, UNV_SPARK_CLEARANCE);
            if (_e < 0) continue;
            _sp.x = _e mod _g.cols; _sp.y = (_e - _sp.x) / _g.cols; _sp.px = -1; _sp.py = -1;
        }
        var _bx = -1, _by = -1, _seen = 0;
        for (var _d = 0; _d < 4; _d++) {
            var _ex = _sp.x + ((_d == 0) ? 1 : ((_d == 1) ? -1 : 0)), _ey = _sp.y + ((_d == 2) ? 1 : ((_d == 3) ? -1 : 0));
            if ((_ex == _sp.px && _ey == _sp.py) || !unv__is_edge(_g, _ex, _ey)) continue;
            _seen++;
            // JavaScript: `bx < 0 || rand(g) < 1 / seen` draws ONLY when bx >= 0 - written out so no draw is spent otherwise
            if (_bx < 0) { _bx = _ex; _by = _ey; }
            else if (unv__rand(_g) < 1 / _seen) { _bx = _ex; _by = _ey; }
        }
        if (_bx < 0) { _bx = _sp.px; _by = _sp.py; if (_bx < 0) continue; }
        _sp.px = _sp.x; _sp.py = _sp.y; _sp.x = _bx; _sp.y = _by;
        if (_sp.x == _g.px && _sp.y == _g.py) { unv__hit(_g); if (_g.phase != "play") { math_set_epsilon(_eps); return _g; } }
    }
    math_set_epsilon(_eps);
    return _g;
}

/// @function unv_results(game)
/// @description The game's outcome: { won, lost, percent, target, lives, cuts, hits, frames }. Not a game -> a neutral
/// outcome (nothing won, nothing lost, all zero).
/// @param {Struct} game
/// @returns {Struct}
function unv_results(_g) {
    if (!unv_is_game(_g)) return { won: false, lost: false, percent: 0, target: 0, lives: 0, cuts: 0, hits: 0, frames: 0 };
    return { won: _g.phase == "won", lost: _g.phase == "lost", percent: unv_percent(_g), target: _g.target, lives: _g.lives,
        cuts: _g.cuts, hits: _g.hits, frames: _g.frame };
}
