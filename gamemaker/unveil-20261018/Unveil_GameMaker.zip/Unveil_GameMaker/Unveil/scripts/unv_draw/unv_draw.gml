/// unv_draw.gml - everything the player sees except the buyer's picture, drawn through the canvas kit (unv_canvas,
/// unv_paint) onto the current surface target: the veil (silk, frost or lacquer: three materials, not recolours), the rim
/// struck along every edge of the claimed land, the glowing trail, the creature, the sparks, the player's marker, the score
/// band and the results panel. Loads no image of its own.
///
/// Unveil - Reveal Any Picture, a Qix-Style Minigame for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// The RPG Maker MZ edition's UnveilDraw.js, ported call for call (the same paths, gradients and seeded scatter). Named
/// deviations (the kit's shadow is a FILL silhouette, so a canvas shadow on a STROKE becomes a wider, fainter glow stroke
/// under the line; the claimed land is erased as merged row spans, the same picture in far fewer draws; type is Cinzel and
/// Alegreya, not the MZ edition's Palatino system stack). Public functions (each documented below): unv_themes,
/// unv_draw_veil, unv_draw_cut, unv_draw_trail, unv_draw_creature, unv_draw_spark, unv_draw_marker, unv_draw_hud,
/// unv_draw_results.

#macro UNV_TAU (pi * 2)

/// @function unv__is_ctx(ctx)
/// @description Internal. True for a drawing context made by unv_cx_create.
function unv__is_ctx(_c) { return is_struct(_c) && is_array(_c[$ "m"]) && is_array(_c[$ "clips"]) && is_array(_c[$ "stack"]); }

/// @function unv__fin(v, fallback)
/// @description Internal. v when it is a finite number, else the fallback.
function unv__fin(_v, _d) { return (is_numeric(_v) && !is_nan(_v) && !is_infinity(_v)) ? _v : _d; }

/// @function unv__blend_begin()
/// @description Internal. Push the GPU state and blend ALPHA as "over" (colour as usual), so a translucent mark never lowers
/// the alpha of a surface it lands on (Doctrine_Craft s13/s15). Pair with unv__blend_end, which restores the caller's state.
function unv__blend_begin() { gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha); }
/// @function unv__blend_end()
/// @description Internal. Restore the GPU state unv__blend_begin saved.
function unv__blend_end() { gpu_pop_state(); }

/// @function unv_themes()
/// @description The veil materials, in order: the RPG Maker MZ edition's three ("silk", "frost", "lacquer") and five this
/// edition adds ("velvet", "washi", "smoke", "inkwash", "leaded"). Each is a different STRUCTURE, never a recolour.
/// @returns {Array<String>}
function unv_themes() { return ["silk", "frost", "lacquer", "velvet", "washi", "smoke", "inkwash", "leaded"]; }

/// @function unv__stage(theme)
/// @description Internal. A veil's palette ([r, g, b] colours), silk for anything unknown.
function unv__stage(_t) {
    static S = {
        silk: { name: "Silk", a: [90, 15, 42], b: [142, 29, 69], fold: [201, 74, 114], rim: [243, 200, 107], trail: [255, 227, 154], ink: [255, 242, 220], glow: [255, 207, 110] },
        frost: { name: "Frost", a: [44, 74, 102], b: [95, 141, 179], fold: [207, 232, 255], rim: [232, 246, 255], trail: [159, 240, 255], ink: [242, 251, 255], glow: [189, 243, 255] },
        lacquer: { name: "Lacquer", a: [13, 10, 14], b: [42, 18, 25], fold: [92, 58, 68], rim: [217, 178, 95], trail: [255, 122, 89], ink: [244, 236, 220], glow: [255, 154, 110] },
        // the five this edition adds (ink stays LIGHT on every veil: it is the band's and the panel's type colour)
        velvet: { name: "Velvet", a: [10, 40, 32], b: [24, 86, 66], fold: [104, 196, 156], rim: [232, 204, 128], trail: [255, 228, 156], ink: [240, 250, 236], glow: [255, 214, 120] },
        washi: { name: "Washi", a: [232, 222, 198], b: [208, 194, 164], fold: [150, 122, 84], rim: [182, 48, 36], trail: [196, 36, 28], ink: [250, 242, 224], glow: [255, 128, 96] },
        smoke: { name: "Smoke", a: [26, 24, 32], b: [56, 52, 70], fold: [176, 166, 198], rim: [206, 196, 236], trail: [224, 206, 255], ink: [238, 234, 250], glow: [192, 172, 255] },
        // hud: the band's fill, lives and the panel's border where the rim is too dark for the dark band (default = rim)
        inkwash: { name: "Ink Wash", a: [238, 234, 224], b: [214, 208, 194], fold: [36, 34, 42], rim: [42, 40, 48], trail: [196, 32, 40], ink: [246, 242, 234], glow: [228, 70, 70], hud: [214, 72, 64] },
        leaded: { name: "Leaded", a: [20, 22, 28], b: [34, 36, 44], fold: [255, 250, 236], rim: [255, 214, 120], trail: [255, 242, 204], ink: [250, 244, 230], glow: [255, 220, 140] }
    };
    return (is_string(_t) && variable_struct_exists(S, _t)) ? S[$ _t] : S.silk;
}

/// @function unv__hud_rgb(stage)
/// @description Internal. The colour the band and the results panel draw in: the stage's `hud` where it has one, else its rim.
function unv__hud_rgb(_T) { return variable_struct_exists(_T, "hud") ? _T.hud : _T.rim; }

/// @function unv__scatter(seed)
/// @description Internal. The MZ edition's scatter (mulberry32 from seed | 0) as a struct; draw with unv__rand.
function unv__scatter(_seed) { return { rs: unv__u32(_seed) }; }

/// @function unv__text(ctx, text, x, y, px, rgb, alpha, align, face)
/// @description Internal. One line of type with its MIDDLE on y (the canvas textBaseline "middle": the baseline at
/// y + px * 0.35), left-aligned at x or centred on it. The middle dot (U+00B7) is struck as a disc.
function unv__text(_c, _s, _x, _y, _px, _rgb, _a, _align, _face) {
    var _t = string(_s), _adv = unv_text_advance(_face), _w = 0, _i, _o;
    for (_i = 1; _i <= string_length(_t); _i++) { _o = ord(string_char_at(_t, _i)); if (_o >= 32 && _o <= 126) _w += _adv[_o - 32] * _px; else if (_o == 183) _w += 0.32 * _px; }
    var _pen = (_align == "center") ? _x - _w / 2 : _x, _base = _y + _px * 0.35;
    _c.fill = unv_cx_solid(_rgb, _a);
    for (_i = 1; _i <= string_length(_t); _i++) {
        var _ch = string_char_at(_t, _i); _o = ord(_ch);
        if (_o == 183) { unv__p_begin(_c); unv__p_arc(_c, _pen + 0.16 * _px, _base - _px * 0.27, max(0.9, _px * 0.065), 0, UNV_TAU); unv__p_fill(_c); _pen += 0.32 * _px; continue; }
        unv__p_text(_c, _ch, _pen, _base, _px, _face, 0);
        if (_o >= 32 && _o <= 126) _pen += _adv[_o - 32] * _px;
    }
}

/// @function unv__rrect(ctx, x, y, w, h, r)
/// @description Internal. The MZ edition's roundRect path (quadratic corners).
function unv__rrect(_c, _x, _y, _w, _h, _r) {
    unv__p_begin(_c); unv__p_move(_c, _x + _r, _y); unv__p_line(_c, _x + _w - _r, _y); unv__p_quad(_c, _x + _w, _y, _x + _w, _y + _r);
    unv__p_line(_c, _x + _w, _y + _h - _r); unv__p_quad(_c, _x + _w, _y + _h, _x + _w - _r, _y + _h); unv__p_line(_c, _x + _r, _y + _h);
    unv__p_quad(_c, _x, _y + _h, _x, _y + _h - _r); unv__p_line(_c, _x, _y + _r); unv__p_quad(_c, _x, _y, _x + _r, _y); unv__p_close(_c);
}

/// @function unv_draw_veil(ctx, w, h, theme, seed)
/// @description The veil material filling w x h: draped silk folds under a damask lattice, frosted glass with ice ferns,
/// or black lacquer with gold wave scales and gold dust; a vignette over all. Drawn ONCE per game (the scene keeps it).
/// @param {Struct} ctx a context from unv_cx_create
/// @param {Real} w
/// @param {Real} h
/// @param {String} theme "silk" | "frost" | "lacquer" (anything else draws silk)
/// @param {Real} seed the same seed draws the same veil
function unv_draw_veil(_c, _w, _h, _theme, _seed) { unv__blend_begin(); var _r = unv__draw_veil(_c, _w, _h, _theme, _seed); unv__blend_end(); return _r; }
function unv__draw_veil(_c, _w, _h, _theme, _seed) {
    if (!unv__is_ctx(_c)) return;
    _w = unv__fin(_w, 0); _h = unv__fin(_h, 0);
    if (!(_w > 0) || !(_h > 0)) return;
    var _T = unv__stage(_theme), _R = unv__scatter((is_numeric(_seed) && _seed != 0) ? _seed : 7), _i;
    var _base = unv_cx_linear(_c, 0, 0, _w, _h); unv_cx_stop(_base, 0, _T.a); unv_cx_stop(_base, 1, _T.b);
    _c.fill = _base; unv__p_fill_rect(_c, 0, 0, _w, _h);
    if (_theme == "frost") {
        _c.lw = 1.2; _c.join = 0;
        for (_i = 0; _i < 26; _i++) {                                   // ice ferns: branching strokes from seeded roots
            var _x = unv__rand(_R) * _w; var _y = unv__rand(_R) * _h; var _a = unv__rand(_R) * UNV_TAU; var _len = 30 + unv__rand(_R) * 80;
            _c.stroke = unv_cx_solid(_T.fold, 0.35 + unv__rand(_R) * 0.3);
            for (var _b = 0; _b < 3; _b++) {
                var _ex = _x + cos(_a) * _len, _ey = _y + sin(_a) * _len;
                unv__p_begin(_c); unv__p_move(_c, _x, _y); unv__p_line(_c, _ex, _ey); unv__p_stroke(_c);
                for (var _f = 1; _f < 6; _f++) {
                    var _px = _x + (_ex - _x) * _f / 6, _py = _y + (_ey - _y) * _f / 6, _fl = _len * 0.22 * (1 - _f / 7);
                    unv__p_begin(_c); unv__p_move(_c, _px, _py); unv__p_line(_c, _px + cos(_a + 0.7) * _fl, _py + sin(_a + 0.7) * _fl);
                    unv__p_move(_c, _px, _py); unv__p_line(_c, _px + cos(_a - 0.7) * _fl, _py + sin(_a - 0.7) * _fl); unv__p_stroke(_c);
                }
                _x = _ex; _y = _ey; _a += (unv__rand(_R) - 0.5) * 1.2; _len *= 0.7;
            }
        }
        var _dust = array_create(900);
        for (_i = 0; _i < 900; _i++) { var _al = unv__rand(_R) * 0.18; var _dx = unv__rand(_R) * _w; var _dy = unv__rand(_R) * _h; _dust[_i] = [_dx, _dy, 2, 2, c_white, _al]; }
        unv_cx_fill_rects(_c, _dust);
    } else if (_theme == "lacquer") {
        // black lacquer: overlapping wave scales (seigaiha) struck in gold, each row laid over the one above it, then ink
        // blooms and gold dust
        var _sr = 26, _row = 0;
        for (var _sy = -_sr; _sy < _h + _sr; _sy += _sr / 2) {
            for (var _sx = (_row mod 2) * _sr - _sr; _sx < _w + _sr * 2; _sx += _sr * 2) {
                _c.fill = _base; unv__p_begin(_c); unv__p_arc(_c, _sx, _sy + _sr, _sr, pi, UNV_TAU); unv__p_close(_c); unv__p_fill(_c);
                for (var _ring = 0; _ring < 4; _ring++) {
                    _c.stroke = unv_cx_solid(_T.rim, (_ring == 0) ? 0.42 : 0.16 + 0.05 * _ring); _c.lw = (_ring == 0) ? 1.4 : 1;
                    unv__p_begin(_c); unv__p_arc(_c, _sx, _sy + _sr, _sr * (1 - _ring * 0.24), pi, UNV_TAU); unv__p_stroke(_c);
                }
            }
            _row++;
        }
        for (_i = 0; _i < 14; _i++) {
            var _cx = unv__rand(_R) * _w; var _cy = unv__rand(_R) * _h; var _r = 60 + unv__rand(_R) * 160; var _ia = 0.35 + unv__rand(_R) * 0.25;
            var _gr = unv_cx_radial(_c, _cx, _cy, 0, _cx, _cy, _r); unv_cx_stop(_gr, 0, [6, 4, 8], _ia); unv_cx_stop(_gr, 1, [6, 4, 8], 0);
            _c.fill = _gr; unv__p_fill_rect(_c, _cx - _r, _cy - _r, _r * 2, _r * 2);
        }
        var _gold = array_create(700), _gc = unv_col(_T.rim);
        for (_i = 0; _i < 700; _i++) { var _ga = 0.25 + unv__rand(_R) * 0.55; var _ds = (unv__rand(_R) < 0.85) ? 1 : 2; var _gx = unv__rand(_R) * _w; var _gy = unv__rand(_R) * _h; _gold[_i] = [_gx, _gy, _ds, _ds, _gc, _ga]; }
        unv_cx_fill_rects(_c, _gold);
    } else if (_theme == "velvet") unv__veil_velvet(_c, _w, _h, _T, _R);
    else if (_theme == "washi") unv__veil_washi(_c, _w, _h, _T, _R);
    else if (_theme == "smoke") unv__veil_smoke(_c, _w, _h, _T, _R);
    else if (_theme == "inkwash") unv__veil_inkwash(_c, _w, _h, _T, _R);
    else if (_theme == "leaded") unv__veil_leaded(_c, _w, _h, _T, _R);
    else {
        for (_i = 0; _i < 18; _i++) {                                    // silk folds: soft vertical highlights and shadows
            var _fx = (_i + unv__rand(_R) * 0.6) * _w / 18; var _fw = 18 + unv__rand(_R) * 40; var _fa = 0.28 + unv__rand(_R) * 0.18;
            var _fg = unv_cx_linear(_c, _fx - _fw, 0, _fx + _fw, 0);
            unv_cx_stop(_fg, 0, _T.fold, 0); unv_cx_stop(_fg, 0.5, _T.fold, _fa); unv_cx_stop(_fg, 1, _T.fold, 0);
            _c.fill = _fg; unv__p_begin(_c); unv__p_move(_c, _fx - _fw, 0);
            unv__p_bez(_c, _fx - _fw + 20, _h * 0.3, _fx - _fw - 20, _h * 0.7, _fx - _fw + 10, _h); unv__p_line(_c, _fx + _fw + 10, _h);
            unv__p_bez(_c, _fx + _fw - 20, _h * 0.7, _fx + _fw + 20, _h * 0.3, _fx + _fw, 0); unv__p_close(_c); unv__p_fill(_c);
        }
        _c.stroke = unv_cx_solid(_T.rim, 0.25); _c.lw = 1;          // a woven damask diamond over the silk
        for (var _dd = -_h; _dd < _w; _dd += 28) {
            unv__p_begin(_c); unv__p_move(_c, _dd, 0); unv__p_line(_c, _dd + _h, _h); unv__p_stroke(_c);
            unv__p_begin(_c); unv__p_move(_c, _dd + _h, 0); unv__p_line(_c, _dd, _h); unv__p_stroke(_c);
        }
    }
    var _vig = unv_cx_radial(_c, _w / 2, _h / 2, _h * 0.2, _w / 2, _h / 2, _w * 0.7); unv_cx_stop(_vig, 0, [0, 0, 0], 0); unv_cx_stop(_vig, 1, [0, 0, 0], 0.35);
    _c.fill = _vig; unv__p_fill_rect(_c, 0, 0, _w, _h);
}

/// @function unv_draw_cut(ctx, game, cw, ch, theme)
/// @description Erase the claimed land from a veil already drawn into the current target, then strike the rim along every
/// edge between claimed land and veil (the board's own frame included, so the walkway reads from the first frame). Call it
/// when land is claimed, never per frame. Returns the rim segments drawn (0 when not a game).
/// @param {Struct} ctx
/// @param {Struct} game a game from unv_create_game
/// @param {Real} cw a cell's width on the target
/// @param {Real} ch a cell's height on the target
/// @param {String} theme
/// @returns {Real}
function unv_draw_cut(_c, _g, _cw, _ch, _theme) { unv__blend_begin(); var _r = unv__draw_cut(_c, _g, _cw, _ch, _theme); unv__blend_end(); return _r; }
function unv__draw_cut(_c, _g, _cw, _ch, _theme) {
    if (!unv__is_ctx(_c) || !unv_is_game(_g)) return 0;
    _cw = unv__fin(_cw, 0); _ch = unv__fin(_ch, 0);
    if (!(_cw > 0) || !(_ch > 0)) return 0;
    var _T = unv__stage(_theme), _cols = _g.cols, _rows = _g.rows, _cl = _g.cells, _x, _y, _rim = 0;
    // erase: every claimed interior cell, merged into row spans (one quad a span), destination-out
    var _prev = unv_cx__scissor_on(_c);
    gpu_push_state(); gpu_set_blendmode_ext(bm_zero, bm_inv_src_alpha);
    draw_primitive_begin(pr_trianglelist); var _v = 0;
    for (_y = 1; _y < _rows - 1; _y++) {
        _x = 1;
        while (_x < _cols - 1) {
            if (_cl[_y * _cols + _x] != UNV_CLAIMED) { _x++; continue; }
            var _x0 = _x; while (_x < _cols - 1 && _cl[_y * _cols + _x] == UNV_CLAIMED) _x++;
            var _p = unv_cx__pt(_c, _x0 * _cw - 0.5, _y * _ch - 0.5), _q = unv_cx__pt(_c, _x * _cw + 0.5, (_y + 1) * _ch + 0.5);
            if (_v >= 900) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); _v = 0; }
            draw_vertex_colour(_p[0], _p[1], c_white, 1); draw_vertex_colour(_q[0], _p[1], c_white, 1); draw_vertex_colour(_q[0], _q[1], c_white, 1);
            draw_vertex_colour(_p[0], _p[1], c_white, 1); draw_vertex_colour(_q[0], _q[1], c_white, 1); draw_vertex_colour(_p[0], _q[1], c_white, 1);
            _v += 6;
        }
    }
    draw_primitive_end();
    gpu_pop_state(); unv_cx__scissor_off(_prev);
    // the rim: one path of unit segments, a glow stroke under the line (the MZ edition's shadowBlur 6)
    unv__p_begin(_c);
    for (_y = 1; _y < _rows - 1; _y++) for (_x = 1; _x < _cols - 1; _x++) {
        if (_cl[_y * _cols + _x] != UNV_OPEN) continue;
        if (_cl[_y * _cols + _x - 1] == UNV_CLAIMED) { unv__p_move(_c, _x * _cw, _y * _ch); unv__p_line(_c, _x * _cw, (_y + 1) * _ch); _rim++; }
        if (_cl[_y * _cols + _x + 1] == UNV_CLAIMED) { unv__p_move(_c, (_x + 1) * _cw, _y * _ch); unv__p_line(_c, (_x + 1) * _cw, (_y + 1) * _ch); _rim++; }
        if (_cl[(_y - 1) * _cols + _x] == UNV_CLAIMED) { unv__p_move(_c, _x * _cw, _y * _ch); unv__p_line(_c, (_x + 1) * _cw, _y * _ch); _rim++; }
        if (_cl[(_y + 1) * _cols + _x] == UNV_CLAIMED) { unv__p_move(_c, _x * _cw, (_y + 1) * _ch); unv__p_line(_c, (_x + 1) * _cw, (_y + 1) * _ch); _rim++; }
    }
    if (_rim > 0) {
        _c.join = 0;
        _c.stroke = unv_cx_solid(_T.glow, 0.22); _c.lw = 6.5; unv__p_stroke(_c);
        _c.stroke = unv_cx_solid(_T.rim, 1); _c.lw = 2.2; unv__p_stroke(_c);
    }
    return _rim;
}

/// @function unv_draw_trail(ctx, game, cw, ch, theme)
/// @description The trail as a glowing thread through its cells, in order. Redraw it when it grows. Returns its length.
/// @returns {Real}
function unv_draw_trail(_c, _g, _cw, _ch, _theme) { unv__blend_begin(); var _r = unv__draw_trail(_c, _g, _cw, _ch, _theme); unv__blend_end(); return _r; }
function unv__draw_trail(_c, _g, _cw, _ch, _theme) {
    if (!unv__is_ctx(_c) || !unv_is_game(_g) || _g.trailLen <= 0) return 0;
    _cw = unv__fin(_cw, 0); _ch = unv__fin(_ch, 0);
    if (!(_cw > 0) || !(_ch > 0)) return 0;
    var _T = unv__stage(_theme);
    _c.join = 0; _c.cap = UNV_STROKE_ROUND;
    for (var _pass = 0; _pass < 3; _pass++) {
        // pass 0 is the glow the MZ edition draws as shadowBlur 10; passes 1 and 2 are its two strokes
        _c.stroke = (_pass == 0) ? unv_cx_solid(_T.glow, 0.28) : ((_pass == 2) ? unv_cx_solid([255, 255, 255], 1) : unv_cx_solid(_T.trail, 1));
        _c.lw = (_pass == 0) ? 10 : ((_pass == 2) ? 1.4 : 4);
        unv__p_begin(_c); unv__p_move(_c, (_g.sx + 0.5) * _cw, (_g.sy + 0.5) * _ch);
        for (var _i = 0; _i < _g.trailLen; _i++) { var _k = _g.trail[_i], _x = _k mod _g.cols, _y = (_k - _x) / _g.cols; unv__p_line(_c, (_x + 0.5) * _cw, (_y + 0.5) * _ch); }
        unv__p_stroke(_c);
    }
    _c.cap = 0;
    return _g.trailLen;
}

/// @function unv_draw_creature(ctx, size, theme, [form])
/// @description A creature in the veil's palette, drawn into a size x size box at the origin of the current transform: the
/// MZ edition's many-armed wisp (the default) or one of unv_creatures() ("jelly", "moth", "star", "eye", "comet",
/// "spore"). Draw it once into a sprite; turn it as unv_creature_turns(form) says.
function unv_draw_creature(_c, _size, _theme, _form = "wisp") { unv__blend_begin(); var _r = unv__draw_creature(_c, _size, _theme, _form); unv__blend_end(); return _r; }
function unv__draw_creature(_c, _size, _theme, _form = "wisp") {
    if (!unv__is_ctx(_c)) return;
    _size = unv__fin(_size, 0); if (!(_size > 0)) return;
    // the forms this edition adds (unv_creatures); the wisp below is the MZ edition's, and any unknown form draws it
    if (is_string(_form) && _form != "wisp" && unv__creature_form(_c, _size, unv__stage(_theme), _form)) return;
    var _T = unv__stage(_theme), _r = _size / 2;
    unv_cx_save(_c); unv_cx_translate(_c, _r, _r);
    var _halo = unv_cx_radial(_c, 0, 0, 0, 0, 0, _r); unv_cx_stop(_halo, 0, _T.glow, 0.55); unv_cx_stop(_halo, 1, _T.glow, 0);
    _c.fill = _halo; unv__p_fill_rect(_c, -_r, -_r, _size, _size);
    _c.join = 0; _c.cap = UNV_STROKE_ROUND;
    for (var _a = 0; _a < 7; _a++) {
        var _ang = _a * UNV_TAU / 7;
        _c.stroke = unv_cx_solid(_T.trail, 0.85); _c.lw = 2.4;
        unv__p_begin(_c); unv__p_move(_c, 0, 0);
        unv__p_bez(_c, cos(_ang) * _r * 0.4, sin(_ang) * _r * 0.4, cos(_ang + 0.6) * _r * 0.7, sin(_ang + 0.6) * _r * 0.7, cos(_ang + 0.3) * _r * 0.92, sin(_ang + 0.3) * _r * 0.92);
        unv__p_stroke(_c);
        _c.fill = unv_cx_solid([255, 255, 255]); unv__p_begin(_c); unv__p_arc(_c, cos(_ang + 0.3) * _r * 0.92, sin(_ang + 0.3) * _r * 0.92, 2, 0, UNV_TAU); unv__p_fill(_c);
    }
    _c.cap = 0;
    _c.fill = unv_cx_solid(_T.trail); unv__p_begin(_c); unv__p_arc(_c, 0, 0, _r * 0.22, 0, UNV_TAU); unv__p_fill(_c);
    _c.fill = unv_cx_solid([26, 11, 18]); unv__p_begin(_c); unv__p_arc(_c, _r * 0.06, -_r * 0.04, _r * 0.08, 0, UNV_TAU); unv__p_fill(_c);
    unv_cx_restore(_c);
}

/// @function unv_draw_spark(ctx, size, theme, [style])
/// @description A spark in the veil's palette, in a size x size box at the origin of the current transform: the veil's
/// own style (unv_spark_of) unless a style from unv_spark_styles() is named. "ember" (an ember with rays) is the MZ
/// edition's. Draw it once into a sprite; turn it while it runs when unv_spark_turns(style) is true.
function unv_draw_spark(_c, _size, _theme, _style = undefined) { unv__blend_begin(); var _r = unv__draw_spark(_c, _size, _theme, _style); unv__blend_end(); return _r; }
function unv__draw_spark(_c, _size, _theme, _style = undefined) {
    if (!unv__is_ctx(_c)) return;
    _size = unv__fin(_size, 0); if (!(_size > 0)) return;
    var _st = is_string(_style) ? _style : unv_spark_of(_theme);
    if (_st != "ember" && unv__spark_form(_c, _size, unv__stage(_theme), _st)) return;
    var _T = unv__stage(_theme), _r = _size / 2;
    unv_cx_save(_c); unv_cx_translate(_c, _r, _r);
    var _gl = unv_cx_radial(_c, 0, 0, 0, 0, 0, _r); unv_cx_stop(_gl, 0, [255, 255, 255]); unv_cx_stop(_gl, 0.3, _T.glow); unv_cx_stop(_gl, 1, _T.glow, 0);
    _c.fill = _gl; unv__p_fill_rect(_c, -_r, -_r, _size, _size);
    _c.stroke = unv_cx_solid([255, 255, 255]); _c.lw = 1.5; _c.join = 0;
    for (var _k = 0; _k < 4; _k++) { var _a = _k * pi / 4; unv__p_begin(_c); unv__p_move(_c, cos(_a) * _r * 0.9, sin(_a) * _r * 0.9); unv__p_line(_c, -cos(_a) * _r * 0.9, -sin(_a) * _r * 0.9); unv__p_stroke(_c); }
    unv_cx_restore(_c);
}

/// @function unv_draw_marker(ctx, size, theme)
/// @description The player's marker: a cut-diamond needle, in a size x size box at the origin of the current transform.
function unv_draw_marker(_c, _size, _theme) { unv__blend_begin(); var _r = unv__draw_marker(_c, _size, _theme); unv__blend_end(); return _r; }
function unv__draw_marker(_c, _size, _theme) {
    if (!unv__is_ctx(_c)) return;
    _size = unv__fin(_size, 0); if (!(_size > 0)) return;
    var _T = unv__stage(_theme), _r = _size / 2;
    unv_cx_save(_c); unv_cx_translate(_c, _r, _r);
    _c.fill = unv_cx_solid([0, 0, 0], 0.4); unv__p_begin(_c); unv__p_move(_c, 1, -_r + 3); unv__p_line(_c, _r - 1, 1); unv__p_line(_c, 1, _r - 1); unv__p_line(_c, -_r + 3, 1); unv__p_close(_c); unv__p_fill(_c);
    _c.fill = unv_cx_solid(_T.ink); unv__p_begin(_c); unv__p_move(_c, 0, -_r + 2); unv__p_line(_c, _r - 2, 0); unv__p_line(_c, 0, _r - 2); unv__p_line(_c, -_r + 2, 0); unv__p_close(_c); unv__p_fill(_c);
    _c.stroke = unv_cx_solid(_T.rim); _c.lw = 2; _c.join = 0; unv__p_stroke(_c);
    _c.fill = unv_cx_solid(_T.rim); unv__p_begin(_c); unv__p_arc(_c, 0, 0, _r * 0.18, 0, UNV_TAU); unv__p_fill(_c);
    unv_cx_restore(_c);
}

/// @function unv_draw_hud(ctx, w, theme, state)
/// @description The 56 px band along the top: the veil's name, the claimed share against the target (in two inks, each
/// clipped to what it sits on), and the lives as diamonds. Redraw it when the share or the lives change.
/// @param {Struct} ctx
/// @param {Real} w the band's width
/// @param {String} theme
/// @param {Struct} state { percent, target, lives, lives_max }
function unv_draw_hud(_c, _w, _theme, _st) { unv__blend_begin(); var _r = unv__draw_hud(_c, _w, _theme, _st); unv__blend_end(); return _r; }
function unv__draw_hud(_c, _w, _theme, _st) {
    if (!unv__is_ctx(_c) || !is_struct(_st)) return;
    _w = unv__fin(_w, 0); if (!(_w > 0)) return;
    var _T = unv__stage(_theme), _pc = clamp(unv__fin(_st[$ "percent"], 0), 0, 100), _tg = clamp(unv__fin(_st[$ "target"], 75), 0, 100);
    var _lv = max(0, floor(unv__fin(_st[$ "lives"], 0))), _lm = clamp(floor(unv__fin(_st[$ "lives_max"], _lv)), 0, 9);
    _c.fill = unv_cx_solid([8, 6, 10], 0.85); unv__p_fill_rect(_c, 0, 0, _w, 56);
    var _bx = 190, _bw = max(40, _w - 380), _by = 18, _bh = 18;
    _c.fill = unv_cx_solid([255, 255, 255], 0.12); unv__rrect(_c, _bx, _by, _bw, _bh, 9); unv__p_fill(_c);
    var _fw = max(18, _bw * min(1, _pc / 100));
    _c.fill = unv_cx_solid(unv__hud_rgb(_T)); unv__rrect(_c, _bx, _by, _fw, _bh, 9); unv__p_fill(_c);
    var _tx = _bx + _bw * _tg / 100;
    _c.stroke = unv_cx_solid([255, 255, 255]); _c.lw = 2; unv__p_begin(_c); unv__p_move(_c, _tx, _by - 6); unv__p_line(_c, _tx, _by + _bh + 6); unv__p_stroke(_c);
    var _label = string_format(_pc, 1, 1) + "%", _lx = _bx + _bw / 2, _ly = _by + _bh / 2 + 1;
    _label = string_trim(_label);
    unv_cx_save(_c); unv__p_begin(_c); unv_cx_rect(_c, _bx, _by - 2, _fw, _bh + 4); unv__p_clip(_c); unv__text(_c, _label, _lx, _ly, 14, [18, 12, 16], 1, "center", UNV_FACE_BODY); unv_cx_restore(_c);
    unv_cx_save(_c); unv__p_begin(_c); unv_cx_rect(_c, _bx + _fw, _by - 2, _bw - _fw + 2, _bh + 4); unv__p_clip(_c);
    unv__text(_c, _label, _lx + 1, _ly + 1, 14, [0, 0, 0], 0.8, "center", UNV_FACE_BODY);   // the MZ edition's text shadow
    unv__text(_c, _label, _lx, _ly, 14, [255, 255, 255], 1, "center", UNV_FACE_BODY); unv_cx_restore(_c);
    unv__text(_c, "target " + string(_tg) + "%", _tx, 49, 12, _T.ink, 1, "center", UNV_FACE_BODY);
    unv__text(_c, _T.name, 24, 28, 22, _T.ink, 1, "left", UNV_FACE_DISPLAY);
    for (var _i = 0; _i < _lm; _i++) {
        _c.fill = (_i < _lv) ? unv_cx_solid(unv__hud_rgb(_T)) : unv_cx_solid([255, 255, 255], 0.18);
        unv__p_begin(_c); unv__p_move(_c, _w - 30 - _i * 26, 16); unv__p_line(_c, _w - 22 - _i * 26, 28); unv__p_line(_c, _w - 30 - _i * 26, 40); unv__p_line(_c, _w - 38 - _i * 26, 28); unv__p_close(_c); unv__p_fill(_c);
    }
}

/// @function unv_draw_results(ctx, w, h, theme, results)
/// @description The results panel near the foot of a w x h screen: UNVEILED or THE VEIL HOLDS, the share against the
/// target, cuts and lives lost, and the way out. Draws over the scene (the scene hides the veil when it was won).
/// @param {Struct} results from unv_results
function unv_draw_results(_c, _w, _h, _theme, _res) { unv__blend_begin(); var _r = unv__draw_results(_c, _w, _h, _theme, _res); unv__blend_end(); return _r; }
function unv__draw_results(_c, _w, _h, _theme, _res) {
    if (!unv__is_ctx(_c) || !is_struct(_res)) return;
    _w = unv__fin(_w, 0); _h = unv__fin(_h, 0); if (!(_w > 0) || !(_h > 0)) return;
    var _T = unv__stage(_theme), _pw = 440, _ph = 230, _px = (_w - _pw) / 2, _py = _h - _ph - 30;
    var _won = (_res[$ "won"] == true), _pc = unv__fin(_res[$ "percent"], 0), _tg = unv__fin(_res[$ "target"], 0), _cuts = floor(unv__fin(_res[$ "cuts"], 0)), _hits = floor(unv__fin(_res[$ "hits"], 0));
    _c.fill = unv_cx_solid([8, 6, 10], 0.85); unv__rrect(_c, _px, _py, _pw, _ph, 14); unv__p_fill(_c);
    _c.stroke = unv_cx_solid(unv__hud_rgb(_T)); _c.lw = 3; _c.join = 0; unv__rrect(_c, _px + 3, _py + 3, _pw - 6, _ph - 6, 12); unv__p_stroke(_c);
    unv__text(_c, _won ? "UNVEILED" : "THE VEIL HOLDS", _w / 2, _py + 44, 28, _won ? unv__hud_rgb(_T) : [224, 120, 108], 1, "center", UNV_FACE_DISPLAY);
    unv__text(_c, string_trim(string_format(_pc, 1, 1)) + "% revealed  " + chr(183) + "  target " + string(_tg) + "%", _w / 2, _py + 98, 20, _T.ink, 1, "center", UNV_FACE_BODY);
    unv__text(_c, string(_cuts) + ((_cuts == 1) ? " cut" : " cuts") + "  " + chr(183) + "  " + string(_hits) + ((_hits == 1) ? " life lost" : " lives lost"), _w / 2, _py + 136, 18, _T.ink, 0.8, "center", UNV_FACE_BODY);
    unv__text(_c, "OK to leave", _w / 2, _py + _ph - 26, 15, _T.ink, 0.7, "center", UNV_FACE_BODY);
}
