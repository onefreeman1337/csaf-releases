/// unv_demo.gml - THE VEILED GALLERY, Unveil's demo room: eight framed veils, one of each material, each hiding a picture.
/// Choose a frame and how much must be revealed, then cut the veil away. A frame you unveil keeps its picture on the wall.
///
/// Unveil - Reveal Any Picture, a Qix-Style Minigame for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// The pictures here are STAND-INS drawn by this package (unv_demo_picture) so the demo needs no image file. Your game
/// passes its own picture to unv_open: any sprite, or a surface.
///
/// Four calls, the same shape as the scene's own (obj_unv_demo shows them):
///   Create: demo = unv_demo_create();   Step: unv_demo_step(demo);   Draw GUI: unv_demo_draw(demo);   Clean Up: unv_demo_free(demo);
/// Public functions (each documented below): unv_demo_create, unv_demo_step, unv_demo_draw, unv_demo_free, unv_demo_frames,
/// unv_demo_levels, unv_demo_picture.

#macro UNV_DEMO_FRAME_W 168
#macro UNV_DEMO_FRAME_H 132
#macro UNV_DEMO_GAP 18
#macro UNV_DEMO_ROW0 120
#macro UNV_DEMO_ROW1 300
#macro UNV_DEMO_LEVEL_Y 500

/// @function unv_demo_frames()
/// @description The gallery's eight frames: [{ veil, picture, title }], one of each veil, each over its own stand-in picture
/// (a kind for unv_demo_picture). Pure.
/// @returns {Array<Struct>}
function unv_demo_frames() {
    return [{ veil: "silk", picture: 0, title: "Dusk Hills" }, { veil: "frost", picture: 2, title: "Alpine Lake" },
        { veil: "lacquer", picture: 1, title: "Night Harbour" }, { veil: "velvet", picture: 4, title: "Misty Pines" },
        { veil: "washi", picture: 7, title: "Blossom" }, { veil: "smoke", picture: 5, title: "City Lights" },
        { veil: "inkwash", picture: 3, title: "Desert Moon" }, { veil: "leaded", picture: 6, title: "Aurora" }];
}

/// @function unv_demo_levels()
/// @description The demo's three settings: [{ name, target, creatures, sparks }] - how much must be revealed, how many
/// creatures drift in the veil and how many sparks run its edge. Pure.
/// @returns {Array<Struct>}
function unv_demo_levels() {
    return [{ name: "Gentle", target: 60, creatures: 1, sparks: 1 }, { name: "Fair", target: 75, creatures: 1, sparks: 2 }, { name: "Hard", target: 85, creatures: 2, sparks: 3 }];
}

function unv__demo_frame_x(_i) { return (UNV_SCENE_W - (4 * UNV_DEMO_FRAME_W + 3 * UNV_DEMO_GAP)) / 2 + (_i mod 4) * (UNV_DEMO_FRAME_W + UNV_DEMO_GAP); }
function unv__demo_frame_y(_i) { return (_i < 4) ? UNV_DEMO_ROW0 : UNV_DEMO_ROW1; }
/// the left edge of level button l (each 150 x 34)
function unv__demo_level_x(_l) { return UNV_SCENE_W / 2 - 240 + _l * 165; }

// ---------------------------------------------------------------------------------------------------------------
// The stand-in pictures
// ---------------------------------------------------------------------------------------------------------------

/// internal: fill everything under a ridge of summed sines from y0 (a fraction of h) down to the bottom
function unv__demo_ridge(_c, _w, _h, _y0, _amp, _R, _rgb, _a = 1, _sharp = 0) {
    var _f1 = 1 + unv__rand(_R) * 2; var _f2 = 3 + unv__rand(_R) * 4; var _f3 = 7 + unv__rand(_R) * 6; var _p1 = unv__rand(_R) * UNV_TAU; var _p2 = unv__rand(_R) * UNV_TAU; var _p3 = unv__rand(_R) * UNV_TAU;
    _c.fill = unv_cx_solid(_rgb, _a); unv_cx_begin(_c); unv_cx_move(_c, 0, _h);
    for (var _i = 0; _i <= 64; _i++) {
        var _u = _i / 64, _v = sin(_u * _f1 * pi + _p1) * 0.55 + sin(_u * _f2 * pi + _p2) * 0.3 + sin(_u * _f3 * pi + _p3) * 0.15;
        if (_sharp > 0) _v = _v * (1 - _sharp) + (1 - 2 * abs(frac(_u * _f2 * 0.5 + _p2) - 0.5) * 2) * _sharp;
        unv_cx_line(_c, _u * _w, (_y0 - _v * _amp) * _h);
    }
    unv_cx_line(_c, _w, _h); unv_cx_close(_c); unv_cx_fill(_c);
}
/// internal: a vertical sky in up to three stops
function unv__demo_sky(_c, _w, _h, _a, _b, _cc) {
    var _g = unv_cx_linear(_c, 0, 0, 0, _h); unv_cx_stop(_g, 0, _a); unv_cx_stop(_g, 0.55, _b); unv_cx_stop(_g, 1, _cc);
    _c.fill = _g; unv_cx_fill_rect(_c, 0, 0, _w, _h);
}
/// internal: stars, one batch
function unv__demo_stars(_c, _w, _h, _n, _R, _maxY) {
    var _l = array_create(_n);
    for (var _i = 0; _i < _n; _i++) { var _x = unv__rand(_R) * _w; var _y = unv__rand(_R) * _h * _maxY; var _s = (unv__rand(_R) < 0.15) ? 2 : 1; var _al = 0.4 + unv__rand(_R) * 0.6; _l[_i] = [_x, _y, _s, _s, c_white, _al]; }
    unv_cx_fill_rects(_c, _l);
}
/// internal: a soft disc with a glow (a sun or a moon)
function unv__demo_orb(_c, _x, _y, _r, _rgb, _glow) {
    var _g = unv_cx_radial(_c, _x, _y, _r * 0.9, _x, _y, _r * 3); unv_cx_stop(_g, 0, _glow, 0.45); unv_cx_stop(_g, 1, _glow, 0);
    _c.fill = _g; unv_cx_fill_rect(_c, _x - _r * 3, _y - _r * 3, _r * 6, _r * 6);
    _c.fill = unv_cx_solid(_rgb); unv_cx_begin(_c); unv_cx_arc(_c, _x, _y, _r, 0, UNV_TAU); unv_cx_fill(_c);
}

/// @function unv_demo_picture(ctx, kind, w, h)
/// @description Draw one of the demo's eight stand-in pictures filling w x h into the current target: 0 dusk hills, 1 night
/// harbour, 2 alpine lake, 3 desert moon, 4 misty pines, 5 city lights, 6 aurora, 7 blossom (anything else -> 0). The same
/// kind always draws the same picture. The product never needs these: your game passes its own picture to unv_open.
/// @param {Struct} ctx a context from unv_cx_create
/// @param {Real} kind 0..7
/// @param {Real} w
/// @param {Real} h
function unv_demo_picture(_c, _kind, _w, _h) {
    if (!unv__is_ctx(_c)) return;
    _w = unv__fin(_w, 0); _h = unv__fin(_h, 0); if (!(_w > 0) || !(_h > 0)) return;
    var _k = (is_numeric(_kind) && !is_nan(_kind) && !is_infinity(_kind)) ? clamp(floor(_kind), 0, 7) : 0;
    var _R = unv__scatter(unv_mix(unv_hash_string("gallery"), _k + 1)), _i;
    repeat (3) unv__rand(_R);
    unv__blend_begin();
    switch (_k) {
        case 1:   // night harbour: stars, a moon and its path on the water, a lighthouse on a rock throwing its beam
            unv__demo_sky(_c, _w, _h, [6, 10, 30], [22, 32, 72], [44, 56, 104]);
            unv__demo_stars(_c, _w, _h, 160, _R, 0.55);
            unv__demo_orb(_c, _w * 0.74, _h * 0.24, _h * 0.065, [244, 238, 214], [170, 190, 255]);
            var _sea = unv_cx_linear(_c, 0, _h * 0.62, 0, _h); unv_cx_stop(_sea, 0, [24, 36, 76]); unv_cx_stop(_sea, 1, [6, 10, 26]);
            _c.fill = _sea; unv_cx_fill_rect(_c, 0, _h * 0.62, _w, _h * 0.38);
            for (_i = 0; _i < 22; _i++) { var _py = _h * (0.64 + _i * 0.016), _pw = _w * (0.03 + _i * 0.006) * (0.6 + unv__rand(_R) * 0.8); _c.fill = unv_cx_solid([232, 228, 200], 0.55 - _i * 0.02); unv_cx_fill_rect(_c, _w * 0.74 - _pw / 2 + (unv__rand(_R) - 0.5) * _w * 0.02, _py, _pw, max(1, _h * 0.004)); }
            var _beam = unv_cx_linear(_c, _w * 0.22, _h * 0.4, _w * 0.62, _h * 0.3); unv_cx_stop(_beam, 0, [255, 236, 170], 0.42); unv_cx_stop(_beam, 1, [255, 236, 170], 0);
            _c.fill = _beam; unv_cx_begin(_c); unv_cx_move(_c, _w * 0.22, _h * 0.395); unv_cx_line(_c, _w * 0.66, _h * 0.26); unv_cx_line(_c, _w * 0.66, _h * 0.4); unv_cx_close(_c); unv_cx_fill(_c);
            _c.fill = unv_cx_solid([10, 12, 22]); unv_cx_begin(_c); unv_cx_move(_c, 0, _h * 0.66); unv_cx_bezier(_c, _w * 0.1, _h * 0.6, _w * 0.3, _h * 0.6, _w * 0.38, _h * 0.68); unv_cx_line(_c, _w * 0.38, _h); unv_cx_line(_c, 0, _h); unv_cx_close(_c); unv_cx_fill(_c);
            unv_cx_begin(_c); unv_cx_move(_c, _w * 0.2, _h * 0.62); unv_cx_line(_c, _w * 0.21, _h * 0.4); unv_cx_line(_c, _w * 0.23, _h * 0.4); unv_cx_line(_c, _w * 0.24, _h * 0.62); unv_cx_close(_c); unv_cx_fill(_c);
            _c.fill = unv_cx_solid([255, 228, 150]); unv_cx_fill_rect(_c, _w * 0.207, _h * 0.385, _w * 0.026, _h * 0.025);
            _c.fill = unv_cx_solid([10, 12, 22]); unv_cx_begin(_c); unv_cx_move(_c, _w * 0.202, _h * 0.388); unv_cx_line(_c, _w * 0.22, _h * 0.355); unv_cx_line(_c, _w * 0.238, _h * 0.388); unv_cx_close(_c); unv_cx_fill(_c);
            break;
        case 2:   // alpine lake: a far range and a near one, the near range mirrored in the water
            unv__demo_sky(_c, _w, _h, [92, 146, 206], [176, 210, 236], [232, 242, 248]);
            unv__demo_ridge(_c, _w, _h, 0.4, 0.2, _R, [166, 184, 214], 1, 0.7);
            unv__demo_ridge(_c, _w, _h, 0.52, 0.16, _R, [84, 104, 138], 1, 0.6);
            var _lake = unv_cx_linear(_c, 0, _h * 0.64, 0, _h); unv_cx_stop(_lake, 0, [120, 160, 196]); unv_cx_stop(_lake, 1, [40, 70, 104]);
            _c.fill = _lake; unv_cx_fill_rect(_c, 0, _h * 0.64, _w, _h * 0.36);
            for (_i = 0; _i < 30; _i++) { _c.fill = unv_cx_solid([255, 255, 255], 0.12 + unv__rand(_R) * 0.14); var _lx = unv__rand(_R) * _w; var _ly = _h * (0.66 + unv__rand(_R) * 0.32); unv_cx_fill_rect(_c, _lx, _ly, _w * (0.04 + unv__rand(_R) * 0.08), max(1, _h * 0.003)); }
            unv__demo_ridge(_c, _w, _h, 0.86, 0.05, _R, [36, 58, 50], 1, 0);
            break;
        case 3:   // desert moon: a huge low moon over three dunes
            unv__demo_sky(_c, _w, _h, [34, 18, 58], [196, 96, 84], [250, 186, 112]);
            unv__demo_stars(_c, _w, _h, 50, _R, 0.3);
            unv__demo_orb(_c, _w * 0.52, _h * 0.46, _h * 0.17, [255, 228, 180], [255, 170, 120]);
            unv__demo_ridge(_c, _w, _h, 0.66, 0.06, _R, [204, 112, 64]);
            unv__demo_ridge(_c, _w, _h, 0.76, 0.07, _R, [158, 78, 50]);
            unv__demo_ridge(_c, _w, _h, 0.88, 0.05, _R, [96, 46, 38]);
            break;
        case 4:   // misty pines: three layers of firs, mist between them
            unv__demo_sky(_c, _w, _h, [170, 196, 186], [214, 226, 214], [236, 238, 226]);
            var _cols = [[152, 176, 164], [92, 122, 106], [34, 58, 46]], _base = [0.6, 0.76, 0.96];
            for (var _layer = 0; _layer < 3; _layer++) {
                var _n = 14 + _layer * 4, _th = _h * (0.2 + _layer * 0.08);
                _c.fill = unv_cx_solid(_cols[_layer]); unv_cx_fill_rect(_c, 0, _h * _base[_layer] - _th * 0.05, _w, _h);
                for (_i = 0; _i < _n; _i++) {
                    var _tx = (_i + unv__rand(_R) * 0.8) * _w / (_n - 1); var _tt = _th * (0.7 + unv__rand(_R) * 0.5); var _tw = _tt * 0.36;
                    var _ty = _h * _base[_layer];
                    for (var _tier = 0; _tier < 3; _tier++) {
                        var _yy = _ty - _tt * _tier * 0.3, _ww = _tw * (1 - _tier * 0.25);
                        unv_cx_begin(_c); unv_cx_move(_c, _tx - _ww, _yy); unv_cx_line(_c, _tx, _yy - _tt * 0.45); unv_cx_line(_c, _tx + _ww, _yy); unv_cx_close(_c); unv_cx_fill(_c);
                    }
                }
                var _mist = unv_cx_linear(_c, 0, _h * _base[_layer] - _th * 0.3, 0, _h * _base[_layer] + _h * 0.04); unv_cx_stop(_mist, 0, [240, 242, 234], 0); unv_cx_stop(_mist, 1, [240, 242, 234], 0.5);
                if (_layer < 2) { _c.fill = _mist; unv_cx_fill_rect(_c, 0, _h * _base[_layer] - _th * 0.3, _w, _th * 0.3 + _h * 0.04); }
            }
            break;
        case 5:   // city lights: a far skyline, a near one with lit windows
            unv__demo_sky(_c, _w, _h, [26, 14, 48], [132, 56, 98], [248, 148, 106]);
            unv__demo_stars(_c, _w, _h, 40, _R, 0.3);
            for (var _sl = 0; _sl < 2; _sl++) {
                var _x = -_w * 0.02, _col = (_sl == 0) ? [86, 46, 92] : [22, 14, 34];
                while (_x < _w) {
                    var _bw = _w * (0.04 + unv__rand(_R) * 0.06); var _bh = _h * ((_sl == 0) ? (0.22 + unv__rand(_R) * 0.22) : (0.16 + unv__rand(_R) * 0.32));
                    _c.fill = unv_cx_solid(_col); unv_cx_fill_rect(_c, _x, _h - _bh, _bw + 1, _bh);
                    if (_sl == 1) {
                        var _win = [], _wx0 = _x + _bw * 0.15, _ws = max(3, _w * 0.009);
                        for (var _wy = _h - _bh + _ws * 2; _wy < _h - _ws * 2; _wy += _ws * 2.2) for (var _wx = _wx0; _wx < _x + _bw - _ws; _wx += _ws * 2) { if (unv__rand(_R) < 0.42) array_push(_win, [_wx, _wy, _ws, _ws * 1.2, make_colour_rgb(255, 206, 120), 0.75 + unv__rand(_R) * 0.25]); }
                        unv_cx_fill_rects(_c, _win);
                    }
                    _x += _bw + _w * 0.004;
                }
            }
            break;
        case 6:   // aurora: green ribbons over a night sky and snow
            unv__demo_sky(_c, _w, _h, [4, 8, 22], [10, 28, 52], [24, 54, 84]);
            unv__demo_stars(_c, _w, _h, 140, _R, 0.7);
            _c.cap = UNV_STROKE_ROUND; _c.join = 0;
            for (var _rb = 0; _rb < 3; _rb++) {
                var _y0 = _h * (0.2 + _rb * 0.1), _rgb = (_rb == 1) ? [120, 200, 255] : [90, 255, 170];
                for (var _ps = 0; _ps < 3; _ps++) {
                    _c.stroke = unv_cx_solid(_rgb, (_ps == 0) ? 0.1 : ((_ps == 1) ? 0.18 : 0.4)); _c.lw = _h * ((_ps == 0) ? 0.12 : ((_ps == 1) ? 0.05 : 0.012));
                    unv_cx_begin(_c); unv_cx_move(_c, -_w * 0.05, _y0 + _h * 0.05); unv_cx_bezier(_c, _w * 0.25, _y0 - _h * 0.12, _w * 0.55, _y0 + _h * 0.14, _w * 1.05, _y0 - _h * 0.06); unv_cx_stroke(_c);
                }
            }
            _c.cap = 0;
            unv__demo_ridge(_c, _w, _h, 0.74, 0.07, _R, [150, 172, 204]);
            unv__demo_ridge(_c, _w, _h, 0.86, 0.05, _R, [214, 228, 244]);
            break;
        case 7:   // blossom: a dark branch across a pale sky, flowers along it, petals falling
            unv__demo_sky(_c, _w, _h, [250, 206, 214], [252, 228, 228], [255, 244, 236]);
            unv__demo_ridge(_c, _w, _h, 0.84, 0.05, _R, [232, 186, 198]);
            _c.cap = UNV_STROKE_ROUND; _c.join = 0; _c.stroke = unv_cx_solid([66, 38, 44]);
            var _br = [[-0.05, 0.3, 0.3, 0.22, 0.55, 0.36, 0.9, 0.24, 0.022], [0.3, 0.22, 0.38, 0.1, 0.46, 0.08, 0.52, 0.02, 0.012], [0.55, 0.36, 0.6, 0.5, 0.68, 0.55, 0.78, 0.6, 0.01]];
            for (_i = 0; _i < 3; _i++) { var _b = _br[_i]; _c.lw = _h * _b[8]; unv_cx_begin(_c); unv_cx_move(_c, _b[0] * _w, _b[1] * _h); unv_cx_bezier(_c, _b[2] * _w, _b[3] * _h, _b[4] * _w, _b[5] * _h, _b[6] * _w, _b[7] * _h); unv_cx_stroke(_c); }
            _c.cap = 0;
            for (_i = 0; _i < 70; _i++) {
                var _t = unv__rand(_R); var _bi = floor(unv__rand(_R) * 3); var _b2 = _br[_bi]; var _o = (unv__rand(_R) - 0.5) * _h * 0.08; var _o2 = (unv__rand(_R) - 0.5) * _h * 0.08;
                var _u = 1 - _t, _bx = _u * _u * _u * _b2[0] + 3 * _u * _u * _t * _b2[2] + 3 * _u * _t * _t * _b2[4] + _t * _t * _t * _b2[6], _by = _u * _u * _u * _b2[1] + 3 * _u * _u * _t * _b2[3] + 3 * _u * _t * _t * _b2[5] + _t * _t * _t * _b2[7];
                var _fr = _h * (0.014 + unv__rand(_R) * 0.012), _pink = (unv__rand(_R) < 0.7);
                for (var _pt = 0; _pt < 5; _pt++) { var _pa = _pt * UNV_TAU / 5; _c.fill = unv_cx_solid(_pink ? [246, 156, 182] : [255, 236, 242]); unv_cx_begin(_c); unv_cx_arc(_c, _bx * _w + _o + cos(_pa) * _fr, _by * _h + _o2 + sin(_pa) * _fr, _fr * 0.8, 0, UNV_TAU); unv_cx_fill(_c); }
                _c.fill = unv_cx_solid([196, 70, 96]); unv_cx_begin(_c); unv_cx_arc(_c, _bx * _w + _o, _by * _h + _o2, _fr * 0.4, 0, UNV_TAU); unv_cx_fill(_c);
            }
            for (_i = 0; _i < 26; _i++) { var _fx = unv__rand(_R) * _w; var _fy = _h * (0.4 + unv__rand(_R) * 0.55); var _fa = unv__rand(_R) * pi; _c.fill = unv_cx_solid([246, 166, 188], 0.85); unv_cx_begin(_c); unv_cx_ellipse(_c, _fx, _fy, _h * 0.012, _h * 0.006, _fa, 0, UNV_TAU); unv_cx_fill(_c); }
            break;
        default:  // dusk hills: a low sun behind three ridges
            unv__demo_sky(_c, _w, _h, [38, 52, 110], [236, 128, 86], [252, 214, 140]);
            unv__demo_orb(_c, _w * 0.62, _h * 0.55, _h * 0.1, [255, 236, 190], [255, 190, 120]);
            unv__demo_ridge(_c, _w, _h, 0.6, 0.08, _R, [122, 70, 104]);
            unv__demo_ridge(_c, _w, _h, 0.72, 0.07, _R, [66, 40, 70]);
            unv__demo_ridge(_c, _w, _h, 0.86, 0.05, _R, [30, 22, 48]);
            break;
    }
    unv__blend_end();
}

// ---------------------------------------------------------------------------------------------------------------
// The gallery
// ---------------------------------------------------------------------------------------------------------------

/// internal: draw with the painter `_fn(ctx, args)` into a fresh w x h sprite (premultiplied; draw with bm_one, inv_src_alpha)
function unv__demo_bake(_w, _h, _fn, _args) {
    var _mw = matrix_get(matrix_world); matrix_set(matrix_world, matrix_build_identity());
    var _s = surface_create(_w, _h);
    surface_set_target(_s); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    _fn(unv_cx_create(1), _args);
    gpu_pop_state(); surface_reset_target();
    var _spr = sprite_create_from_surface(_s, 0, 0, _w, _h, false, false, 0, 0);
    surface_free(_s);
    matrix_set(matrix_world, _mw);
    return _spr;
}
function unv__demo_kill(_s) { if (is_numeric(_s) && _s >= 0 && sprite_exists(_s)) sprite_delete(_s); return -1; }

function unv__pnt_demo_bg(_c, _a) {
    var _g = unv_cx_linear(_c, 0, 0, 0, UNV_SCENE_H); unv_cx_stop(_g, 0, [34, 18, 30]); unv_cx_stop(_g, 0.7, [20, 11, 18]); unv_cx_stop(_g, 1, [12, 7, 11]);
    _c.fill = _g; unv_cx_fill_rect(_c, 0, 0, UNV_SCENE_W, UNV_SCENE_H);
    // a wall of damask: faint diamonds, then a dado rail
    _c.stroke = unv_cx_solid([243, 200, 107], 0.05); _c.lw = 1;
    for (var _d = -UNV_SCENE_H; _d < UNV_SCENE_W; _d += 34) { unv_cx_begin(_c); unv_cx_move(_c, _d, 0); unv_cx_line(_c, _d + 470, 470); unv_cx_move(_c, _d + 470, 0); unv_cx_line(_c, _d, 470); unv_cx_stroke(_c); }
    _c.fill = unv_cx_solid([0, 0, 0], 0.35); unv_cx_fill_rect(_c, 0, 472, UNV_SCENE_W, UNV_SCENE_H - 472);
    _c.fill = unv_cx_solid([150, 112, 58], 0.9); unv_cx_fill_rect(_c, 0, 470, UNV_SCENE_W, 3);
    unv__text(_c, "Unveil", UNV_SCENE_W / 2 + 1, 52, 44, [0, 0, 0], 0.6, "center", UNV_FACE_DISPLAY);
    unv__text(_c, "Unveil", UNV_SCENE_W / 2, 51, 44, [243, 200, 107], 1, "center", UNV_FACE_DISPLAY);
    unv__text(_c, "The Veiled Gallery: eight veils, eight hidden pictures. Cut the veil away.", UNV_SCENE_W / 2, 90, 15, [214, 186, 150], 1, "center", UNV_FACE_BODY);
    unv__text(_c, "Arrows choose a frame, 1 2 3 the setting, Enter opens it. Or click. Inside: arrows walk, hold Shift or Space to cut.", UNV_SCENE_W / 2, 590, 13, [168, 140, 112], 1, "center", UNV_FACE_BODY);
    unv__text(_c, "These pictures are drawn by the package for the demo. Your game passes its own.", UNV_SCENE_W / 2, 608, 12, [130, 108, 90], 1, "center", UNV_FACE_BODY);
}
function unv__pnt_demo_frame(_c, _a) {
    var _W = UNV_DEMO_FRAME_W, _H = UNV_DEMO_FRAME_H, _fr = _a.frame, _T = unv__stage(_fr.veil);
    // a drop shadow, then a gilt moulding: an outer bevel lit from the top left and an inner lip
    _c.fill = unv_cx_solid([0, 0, 0], 0.5); unv_cx_fill_rect(_c, 5, 7, _W, _H);
    var _gg = unv_cx_linear(_c, 0, 0, _W, _H); unv_cx_stop(_gg, 0, [246, 214, 132]); unv_cx_stop(_gg, 0.45, [178, 128, 54]); unv_cx_stop(_gg, 1, [102, 66, 26]);
    _c.fill = _gg; unv_cx_fill_rect(_c, 0, 0, _W, _H);
    _c.fill = unv_cx_solid([70, 44, 16]); unv_cx_fill_rect(_c, 8, 8, _W - 16, _H - 16);
    _c.stroke = unv_cx_solid([255, 236, 176], 0.8); _c.lw = 1; unv_cx_begin(_c); unv_cx_rect(_c, 1.5, 1.5, _W - 3, _H - 3); unv_cx_stroke(_c);
    _c.stroke = unv_cx_solid([60, 36, 12], 0.9); unv_cx_begin(_c); unv_cx_rect(_c, 7.5, 7.5, _W - 15, _H - 15); unv_cx_stroke(_c);
    // the window, baked on its own at exactly its size (2026-10-18, looked at: drawn straight into the frame, the ferns,
    // the washi print and the soft velvet and smoke ran out over the moulding onto the wall)
    if (sprite_exists(_a.win)) { gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); draw_sprite(_a.win, 0, 10, 10); gpu_pop_state(); }
    // the brass plate under the frame: the veil's name, or what was revealed
    _c.fill = unv_cx_solid([28, 18, 12], 0.9); unv_cx_fill_rect(_c, _W / 2 - 62, _H + 8, 124, 22);
    _c.stroke = unv_cx_solid([196, 150, 72], 0.9); _c.lw = 1; unv_cx_begin(_c); unv_cx_rect(_c, _W / 2 - 61.5, _H + 8.5, 123, 21); unv_cx_stroke(_c);
    unv__text(_c, _a.revealed ? _fr.title : _T.name, _W / 2, _H + 19, 13, _a.revealed ? [243, 220, 160] : [214, 186, 150], 1, "center", _a.revealed ? UNV_FACE_DISPLAY : UNV_FACE_BODY);
}
/// the window of a frame: the veil (drawn at twice the window and halved, so its pattern keeps the game's scale) or, once
/// unveiled, the picture; baked into a sprite exactly the window's size so nothing can run past it
function unv__pnt_demo_window(_c, _a) {
    var _iw = UNV_DEMO_FRAME_W - 20, _ih = UNV_DEMO_FRAME_H - 20, _fr = _a.frame;
    if (_a.revealed) { unv_cx_scale(_c, _iw / 816, _ih / 568); unv_demo_picture(_c, _fr.picture, 816, 568); }
    else { unv_cx_scale(_c, 0.5, 0.5); unv_draw_veil(_c, _iw * 2, _ih * 2, _fr.veil, unv_hash_string(_fr.title)); }
}
function unv__pnt_demo_pick(_c, _a) {
    _c.stroke = unv_cx_solid([30, 16, 4], 0.8); _c.lw = 6; unv_cx_begin(_c); unv_cx_rect(_c, 4, 4, UNV_DEMO_FRAME_W + 8, UNV_DEMO_FRAME_H + 8); unv_cx_stroke(_c);
    _c.stroke = unv_cx_solid([255, 236, 170], 0.95); _c.lw = 2.5; unv_cx_begin(_c); unv_cx_rect(_c, 4, 4, UNV_DEMO_FRAME_W + 8, UNV_DEMO_FRAME_H + 8); unv_cx_stroke(_c);
}
function unv__pnt_demo_levels(_c, _a) {
    var _L = unv_demo_levels();
    for (var _l = 0; _l < 3; _l++) {
        var _x = 10 + _l * 165, _on = (_l == _a.level);
        _c.fill = _on ? unv_cx_solid([200, 150, 66]) : unv_cx_solid([44, 28, 22]); unv__rrect(_c, _x, 6, 150, 34, 10); unv_cx_fill(_c);
        _c.stroke = _on ? unv_cx_solid([255, 236, 170]) : unv_cx_solid([120, 90, 52]); _c.lw = 1.5; unv__rrect(_c, _x + 0.5, 6.5, 149, 33, 10); unv_cx_stroke(_c);
        unv__text(_c, string(_l + 1) + "  " + _L[_l].name + "  " + string(_L[_l].target) + "%", _x + 75, 23, 15, _on ? [36, 22, 8] : [214, 186, 150], 1, "center", UNV_FACE_BODY);
    }
}
function unv__pnt_demo_wait(_c, _a) {
    _c.fill = unv_cx_solid([0, 0, 0], 0.55); unv__rrect(_c, 6, 6, 420, 116, 14); unv_cx_fill(_c);
    _c.fill = unv_cx_solid([22, 12, 18], 0.94); unv__rrect(_c, 0, 0, 420, 116, 14); unv_cx_fill(_c);
    _c.stroke = unv_cx_solid([232, 190, 110], 0.9); _c.lw = 2; unv__rrect(_c, 6, 6, 408, 104, 10); unv_cx_stroke(_c);
    unv__text(_c, "Weaving the veil", 210, 48, 26, [243, 214, 150], 1, "center", UNV_FACE_DISPLAY);
    unv__text(_c, "every thread is being drawn", 210, 80, 15, [190, 160, 128], 1, "center", UNV_FACE_BODY);
}

/// @function unv_demo_create()
/// @description Open THE VEILED GALLERY. Returns the demo (a struct); draw it with unv_demo_draw, free it with
/// unv_demo_free. The gallery is 816 x 624 and is scaled to fit the GUI.
/// @returns {Struct}
function unv_demo_create() {
    var _D = { frames: unv_demo_frames(), pick: 0, level: 1, scene: undefined, picSpr: -1, revealed: array_create(8, false), best: array_create(8, 0),
        bg: -1, frameSpr: array_create(8, -1), pickSpr: -1, levelSpr: -1, waitSpr: -1, pending: -1, waitAge: 0, opened: 0,
        x: 0, y: 0, scale: 1, lastResult: undefined, inject: undefined, held: { left: 0, right: 0, up: 0, down: 0 } };
    _D.bg = unv__demo_bake(UNV_SCENE_W, UNV_SCENE_H, unv__pnt_demo_bg, {});
    for (var _i = 0; _i < 8; _i++) unv__demo_frame_bake(_D, _i);
    _D.pickSpr = unv__demo_bake(UNV_DEMO_FRAME_W + 12, UNV_DEMO_FRAME_H + 12, unv__pnt_demo_pick, {});
    _D.waitSpr = unv__demo_bake(430, 126, unv__pnt_demo_wait, {});
    unv__demo_levels_bake(_D);
    return _D;
}
function unv__demo_frame_bake(_D, _i) {
    var _win = unv__demo_bake(UNV_DEMO_FRAME_W - 20, UNV_DEMO_FRAME_H - 20, unv__pnt_demo_window, { frame: _D.frames[_i], revealed: _D.revealed[_i] });
    _D.frameSpr[_i] = unv__demo_kill(_D.frameSpr[_i]);
    _D.frameSpr[_i] = unv__demo_bake(UNV_DEMO_FRAME_W + 8, UNV_DEMO_FRAME_H + 34, unv__pnt_demo_frame, { frame: _D.frames[_i], revealed: _D.revealed[_i], win: _win });
    unv__demo_kill(_win);   // only after the frame's bake has set and reset its target, which flushes the draw that used it
}
function unv__demo_levels_bake(_D) { _D.levelSpr = unv__demo_kill(_D.levelSpr); _D.levelSpr = unv__demo_bake(510, 46, unv__pnt_demo_levels, { level: _D.level }); }
/// internal: one held key as a press that repeats (first after 14 steps, then every 5)
function unv__demo_repeat(_D, _k, _down) {
    if (!_down) { _D.held[$ _k] = 0; return false; }
    _D.held[$ _k] += 1; var _n = _D.held[$ _k];
    return _n == 1 || (_n > 14 && ((_n - 14) mod 5) == 0);
}
function unv__demo_open(_D, _i) {
    var _LL = unv_demo_levels(), _fr = _D.frames[_i], _L = _LL[_D.level];
    var _mw = matrix_get(matrix_world); matrix_set(matrix_world, matrix_build_identity());
    var _s = surface_create(UNV_SCENE_W, UNV_SCENE_H - UNV_TOP);
    surface_set_target(_s); draw_clear_alpha(c_black, 0);
    unv_demo_picture(unv_cx_create(1), _fr.picture, UNV_SCENE_W, UNV_SCENE_H - UNV_TOP);
    surface_reset_target();
    _D.picSpr = unv__demo_kill(_D.picSpr);
    _D.picSpr = sprite_create_from_surface(_s, 0, 0, UNV_SCENE_W, UNV_SCENE_H - UNV_TOP, false, false, 0, 0);
    surface_free(_s);
    matrix_set(matrix_world, _mw);
    _D.scene = unv_open({ picture: _D.picSpr, seed: "gallery-" + _fr.veil + "-" + string(_D.level), veil: _fr.veil, target: _L.target, creatures: _L.creatures, sparks: _L.sparks });
    _D.opened++;
}

/// @function unv_demo_step(demo)
/// @description Run the gallery (or the open game) for one step. Call it in Step. For tests and attract modes set
/// demo.inject for one step: on the gallery { left, right, up, down, ok, level (0..2), x, y, click } (gallery
/// coordinates); inside a game it is handed to the scene as scene.inject.
function unv_demo_step(_D) {
    if (!is_struct(_D)) return;
    _D.scale = max(0.1, min(display_get_gui_width() / UNV_SCENE_W, display_get_gui_height() / UNV_SCENE_H));
    _D.x = (display_get_gui_width() - UNV_SCENE_W * _D.scale) / 2; _D.y = (display_get_gui_height() - UNV_SCENE_H * _D.scale) / 2;
    if (is_struct(_D.scene)) {
        if (is_struct(_D.inject)) { _D.scene.inject = _D.inject; _D.inject = undefined; }
        unv_step(_D.scene, device_mouse_x_to_gui(0), device_mouse_y_to_gui(0));
        if (unv_closed(_D.scene)) {
            var _r = _D.scene.result, _i = _D.pick;
            _D.lastResult = _r;
            if (is_struct(_r) && _r.won) { _D.best[_i] = max(_D.best[_i], _r.percent); if (!_D.revealed[_i]) { _D.revealed[_i] = true; unv__demo_frame_bake(_D, _i); } }
            unv_free(_D.scene); _D.scene = undefined;
        }
        return;
    }
    // a choice made last step opens now, behind the wait card drawn in between
    if (_D.pending >= 0) { _D.waitAge++; if (_D.waitAge >= 2) { var _pk = _D.pending; _D.pending = -1; unv__demo_open(_D, _pk); } return; }
    var _mx = (device_mouse_x_to_gui(0) - _D.x) / _D.scale, _my = (device_mouse_y_to_gui(0) - _D.y) / _D.scale;
    var _in = { x: _mx, y: _my, click: mouse_check_button_pressed(mb_left), ok: keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space),
        left: keyboard_check(vk_left), right: keyboard_check(vk_right), up: keyboard_check(vk_up), down: keyboard_check(vk_down),
        level: keyboard_check_pressed(ord("1")) ? 0 : (keyboard_check_pressed(ord("2")) ? 1 : (keyboard_check_pressed(ord("3")) ? 2 : -1)) };
    if (is_struct(_D.inject)) {
        var _f = ["x", "y", "click", "ok", "left", "right", "up", "down", "level"];
        for (var _q = 0; _q < 9; _q++) { var _v = _D.inject[$ _f[_q]]; _in[$ _f[_q]] = is_undefined(_v) ? ((_q < 2) ? -1000 : ((_q == 8) ? -1 : false)) : _v; }
        _D.inject = undefined;
    }
    if (unv__demo_repeat(_D, "left", _in.left)) _D.pick = (_D.pick + 7) mod 8;
    if (unv__demo_repeat(_D, "right", _in.right)) _D.pick = (_D.pick + 1) mod 8;
    var _rowUp = unv__demo_repeat(_D, "up", _in.up), _rowDown = unv__demo_repeat(_D, "down", _in.down);   // both counters advance every step
    if (_rowUp || _rowDown) _D.pick = (_D.pick + 4) mod 8;
    if (is_numeric(_in.level) && _in.level >= 0 && _in.level <= 2 && _in.level != _D.level) { _D.level = floor(_in.level); unv__demo_levels_bake(_D); }
    if (_in.click) {
        for (var _k = 0; _k < 8; _k++) if (_in.x >= unv__demo_frame_x(_k) && _in.x < unv__demo_frame_x(_k) + UNV_DEMO_FRAME_W && _in.y >= unv__demo_frame_y(_k) && _in.y < unv__demo_frame_y(_k) + UNV_DEMO_FRAME_H) { _D.pick = _k; _D.pending = _k; _D.waitAge = 0; return; }
        for (var _l = 0; _l < 3; _l++) if (_in.x >= unv__demo_level_x(_l) && _in.x < unv__demo_level_x(_l) + 150 && _in.y >= UNV_DEMO_LEVEL_Y && _in.y < UNV_DEMO_LEVEL_Y + 34 && _l != _D.level) { _D.level = _l; unv__demo_levels_bake(_D); }
    }
    if (_in.ok) { _D.pending = _D.pick; _D.waitAge = 0; }
}

/// @function unv_demo_draw(demo)
/// @description Draw the gallery, or the open game, scaled to fit the GUI. Call it in Draw GUI.
function unv_demo_draw(_D) {
    if (!is_struct(_D)) return;
    if (is_struct(_D.scene)) { unv_draw(_D.scene, _D.x, _D.y, _D.scale); return; }
    var _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_multiply(matrix_build(_D.x, _D.y, 0, 0, 0, 0, _D.scale, _D.scale, 1), _mw));
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); gpu_set_texfilter(true);
    if (sprite_exists(_D.bg)) draw_sprite(_D.bg, 0, 0, 0);
    for (var _i = 0; _i < 8; _i++) if (sprite_exists(_D.frameSpr[_i])) draw_sprite(_D.frameSpr[_i], 0, unv__demo_frame_x(_i), unv__demo_frame_y(_i));
    var _pa = 0.75 + 0.25 * sin(current_time / 260);
    if (sprite_exists(_D.pickSpr)) draw_sprite_ext(_D.pickSpr, 0, unv__demo_frame_x(_D.pick) - 8, unv__demo_frame_y(_D.pick) - 8, 1, 1, 0, make_colour_rgb(255 * _pa, 255 * _pa, 255 * _pa), _pa);
    if (sprite_exists(_D.levelSpr)) draw_sprite(_D.levelSpr, 0, unv__demo_level_x(0) - 10, UNV_DEMO_LEVEL_Y - 6);
    if (_D.pending >= 0 && sprite_exists(_D.waitSpr)) draw_sprite(_D.waitSpr, 0, UNV_SCENE_W / 2 - 215, UNV_SCENE_H / 2 - 63);
    gpu_pop_state();
    matrix_set(matrix_world, _mw);
}

/// @function unv_demo_free(demo)
/// @description Free every sprite the gallery and its open game made. Safe when Create left early (-selftest) and twice.
function unv_demo_free(_D) {
    if (!is_struct(_D)) return;
    if (is_struct(_D[$ "scene"])) unv_free(_D.scene);
    _D.scene = undefined;
    _D.bg = unv__demo_kill(_D[$ "bg"]); _D.pickSpr = unv__demo_kill(_D[$ "pickSpr"]); _D.waitSpr = unv__demo_kill(_D[$ "waitSpr"]); _D.levelSpr = unv__demo_kill(_D[$ "levelSpr"]); _D.picSpr = unv__demo_kill(_D[$ "picSpr"]);
    if (is_array(_D[$ "frameSpr"])) for (var _i = 0; _i < array_length(_D.frameSpr); _i++) _D.frameSpr[_i] = unv__demo_kill(_D.frameSpr[_i]);
}
