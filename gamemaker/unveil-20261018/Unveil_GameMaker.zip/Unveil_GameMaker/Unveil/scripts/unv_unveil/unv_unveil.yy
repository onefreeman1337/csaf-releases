{
  "$GMScript": "v1",
  "%Name": "unv_unveil",
  "name": "unv_unveil",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}