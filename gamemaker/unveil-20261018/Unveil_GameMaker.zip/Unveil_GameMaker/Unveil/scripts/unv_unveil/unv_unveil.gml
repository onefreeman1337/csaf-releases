/// unv_unveil.gml - the Unveil scene: one call opens a game over the buyer's own picture, then step it and draw it until it
/// closes. Five calls: unv_open, unv_step, unv_draw, unv_closed, unv_free.
///
/// Unveil - Reveal Any Picture, a Qix-Style Minigame for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// The RPG Maker MZ edition's Scene_Unveil, ported: the same pace (one move every 3 frames, the world every frame), the
/// same steering (arrows, or toward a held pointer), the same "magnet" (a cut that stops a cell or two short of revealed
/// land while the pointer is still held closes onto it), the veil redrawn ONLY when land is claimed and the trail only
/// when it grows. The scene is 816 x 624 at scale 1 (a 56 px band on top, the board below); draw it anywhere at any scale.
///
/// ⛔ Open and step in Create / Step, never while a surface of yours is the draw target: the scene bakes its veil, its
/// sprites and its bands into surfaces of its own there. unv_draw only blits.

#macro UNV_SCENE_W 816
#macro UNV_SCENE_H 624
#macro UNV_TOP 56
#macro UNV_COLS 96
#macro UNV_ROWS 64
#macro UNV_MOVE_EVERY 3
#macro UNV_MAGNET 2
#macro UNV_FALL_BLOCK 3
#macro UNV_FALL_FRAMES 54
#macro UNV_FALL_DELAY_MAX 30

/// @function unv__is_scene(scene)
/// @description Internal. True for a scene made by unv_open.
function unv__is_scene(_T) { return is_struct(_T) && variable_struct_exists(_T, "game") && variable_struct_exists(_T, "mode") && unv_is_game(_T.game); }

/// @function unv__seed_of(seed, salt)
/// @description Internal. A request's seed: a number (or a string that is a plain whole number) as an unsigned 32-bit
/// number; any other word hashed; blank or absent -> a new game every time (mixed from the time and a counter).
function unv__seed_of(_s, _salt) {
    if (is_numeric(_s) && !is_nan(_s) && !is_infinity(_s)) return real(unv__u32(floor(abs(_s))));
    if (is_string(_s)) {
        var _t = string_trim(_s);
        if (_t != "") {
            var _digits = string_length(string_digits(_t)) == string_length(_t);
            return _digits ? real(unv__u32(real(_t))) : unv_hash_string(_t);
        }
    }
    return unv_mix(unv_hash_string("unveil") ^ (_salt * 7919), current_time);
}

/// @function unv__req_num(request, key, default, min, max)
/// @description Internal. A whole-number request field, clamped; anything else -> the default.
function unv__req_num(_r, _k, _d, _lo, _hi) {
    var _v = _r[$ _k];
    if (!is_numeric(_v) || is_nan(_v) || is_infinity(_v)) return _d;
    return clamp(floor(_v), _lo, _hi);
}

/// @function unv_open(request)
/// @description Open a game over a picture. The same seed always plays the same game.
/// @param {Struct} request { picture: a sprite OR a surface (required; a surface is copied, so it may be freed after),
///   seed: a number or a word (blank = a new game every time), veil: "auto" or one of unv_themes() ("silk", "frost",
///   "lacquer", "velvet", "washi", "smoke", "inkwash", "leaded"), creature: "auto" or one of unv_creatures() ("wisp",
///   "jelly", "moth", "star", "eye", "comet", "spore"; auto picks from the seed), spark: "auto" (the veil's own) or
///   one of unv_spark_styles() ("ember", "flake", "leaf", "firefly", "pinwheel", "flame", "droplet", "prism"),
///   target: percent to reveal (75, 10..95), lives (3, 1..9), creatures (1, 1..4), sparks (2, 0..6),
///   fall: the claimed veil breaks and falls away in pieces (true; false = it vanishes, as in the MZ edition),
///   allow_leave: Escape leaves unrevealed (true), sound: a function(name) for "cut", "claim", "hit", "won", "lost" }
/// @returns {Struct} the scene; undefined when the request names no usable picture
function unv_open(_req) {
    if (!is_struct(_req)) return undefined;
    var _pic = _req[$ "picture"], _owned = false;
    if (is_numeric(_pic) && surface_exists(_pic) && !sprite_exists(_pic)) { _pic = sprite_create_from_surface(_pic, 0, 0, surface_get_width(_pic), surface_get_height(_pic), false, false, 0, 0); _owned = true; }
    else if (is_numeric(_pic) && surface_exists(_pic) && sprite_exists(_pic)) {
        // a number that is BOTH a live surface and a sprite index is ambiguous; a request names which with picture_kind
        if (_req[$ "picture_kind"] == "surface") { _pic = sprite_create_from_surface(_pic, 0, 0, surface_get_width(_pic), surface_get_height(_pic), false, false, 0, 0); _owned = true; }
    }
    if (!is_numeric(_pic) || !sprite_exists(_pic)) return undefined;
    global.unv_opened = (variable_global_exists("unv_opened") ? global.unv_opened : 0) + 1;
    var _seed = unv__seed_of(_req[$ "seed"], global.unv_opened);
    var _th = unv_themes(), _v = _req[$ "veil"];
    var _theme = (is_string(_v) && array_get_index(_th, _v) >= 0) ? _v : _th[_seed mod array_length(_th)];
    var _g = unv_create_game(_seed, { cols: UNV_COLS, rows: UNV_ROWS, target: unv__req_num(_req, "target", 75, 10, 95),
        lives: unv__req_num(_req, "lives", 3, 1, 9), creatures: unv__req_num(_req, "creatures", 1, 1, 4), sparks: unv__req_num(_req, "sparks", 2, 0, 6) });
    var _al = _req[$ "allow_leave"], _cf = unv_creatures(), _cv = _req[$ "creature"];
    var _form = (is_string(_cv) && array_get_index(_cf, _cv) >= 0) ? _cv : _cf[(_seed div 8) mod array_length(_cf)];
    var _sv = _req[$ "spark"], _ss = (is_string(_sv) && array_get_index(unv_spark_styles(), _sv) >= 0) ? _sv : unv_spark_of(_theme);
    var _fl = _req[$ "fall"];
    var _T = { req: _req, game: _g, seed: _seed, theme: _theme, pic: _pic, picOwned: _owned,
        cw: UNV_SCENE_W / UNV_COLS, ch: (UNV_SCENE_H - UNV_TOP) / UNV_ROWS,
        veilSpr: -1, crSpr: -1, spSpr: -1, mkSpr: -1, veilSurf: -1, trailSurf: -1, hudSurf: -1, resSurf: -1,
        claimedShown: -1, trailShown: -1, hudKey: -1, mode: "play", t: 0, moveT: 0, lastDir: 0, spin: 0,
        inject: undefined, closed: false, left: false, result: undefined, view: { x: 0, y: 0, s: 1 },
        allowLeave: is_undefined(_al) ? true : ((is_bool(_al) || is_numeric(_al)) && _al), form: _form, turns: unv_creature_turns(_form),
        spark: _ss, sparkTurns: unv_spark_turns(_ss),
        fall: is_undefined(_fl) ? true : ((is_bool(_fl) || is_numeric(_fl)) && _fl), falls: [], fxSurf: -1, falling: false, fallN: 0, fallPieces: 0,
        shownCells: undefined,
        sound: is_callable(_req[$ "sound"]) ? _req.sound : undefined };
    unv__bake(_T);
    return _T;
}

/// @function unv__sound(scene, name)
/// @description Internal. Call the request's sound hook, if any.
function unv__sound(_T, _n) { if (!is_undefined(_T.sound)) _T.sound(_n); }

/// @function unv__bake(scene)
/// @description Internal. Draw the pristine veil, the creature, the spark and the marker once, into sprites (sprites
/// survive a lost surface); then the live surfaces. Separate-alpha blending: a translucent fill must not LOWER the alpha of
/// what it lands on.
function unv__bake(_T) {
    var _mw = matrix_get(matrix_world); matrix_set(matrix_world, matrix_build_identity());   // s19: bake under identity
    var _W = UNV_SCENE_W, _VH = UNV_SCENE_H - UNV_TOP, _c = unv_cx_create(1);
    var _s = surface_create(_W, _VH);
    surface_set_target(_s); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    unv_draw_veil(_c, _W, _VH, _T.theme, _T.seed);
    gpu_pop_state(); surface_reset_target();
    _T.veilSpr = sprite_create_from_surface(_s, 0, 0, _W, _VH, false, false, 0, 0);
    surface_free(_s);
    var _mk = [[64, 0], [24, 1], [22, 2]];
    for (var _i = 0; _i < 3; _i++) {
        var _n = _mk[_i][0], _t = surface_create(_n, _n);
        surface_set_target(_t); draw_clear_alpha(c_black, 0);
        gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
        var _cc = unv_cx_create(1);
        if (_i == 0) unv_draw_creature(_cc, _n, _T.theme, _T.form); else if (_i == 1) unv_draw_spark(_cc, _n, _T.theme, _T.spark); else unv_draw_marker(_cc, _n, _T.theme);
        gpu_pop_state(); surface_reset_target();
        var _spr = sprite_create_from_surface(_t, 0, 0, _n, _n, false, false, _n / 2, _n / 2);
        surface_free(_t);
        if (_i == 0) _T.crSpr = _spr; else if (_i == 1) _T.spSpr = _spr; else _T.mkSpr = _spr;
    }
    unv__refresh(_T);
    matrix_set(matrix_world, _mw);
}

/// @function unv__refresh(scene)
/// @description Internal. Redraw what changed (or was lost): the veil when land was claimed, the trail when it grew, the
/// band when the share or the lives changed, the results panel once. Never per frame otherwise.
function unv__refresh(_T) {
    var _g = _T.game, _W = UNV_SCENE_W, _VH = UNV_SCENE_H - UNV_TOP;
    var _mw = matrix_get(matrix_world); matrix_set(matrix_world, matrix_build_identity());   // s19: a rebuild from unv_draw runs under the caller's matrix otherwise
    if (!surface_exists(_T.veilSurf) || _g.claimed != _T.claimedShown) {
        // the claimed veil breaks and falls away: its pieces are copied out of the OLD veil before the new one is drawn
        // (never on the first bake, never on a rebuild after a lost surface: there is no old veil to break)
        if (_T.fall && surface_exists(_T.veilSurf) && _T.claimedShown >= 0 && _g.claimed != _T.claimedShown) unv__fall_begin(_T);
        if (!surface_exists(_T.veilSurf)) _T.veilSurf = surface_create(_W, _VH);
        surface_set_target(_T.veilSurf); draw_clear_alpha(c_black, 0);
        gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
        draw_sprite(_T.veilSpr, 0, 0, 0);
        unv_draw_cut(unv_cx_create(1), _g, _T.cw, _T.ch, _T.theme);
        gpu_pop_state(); surface_reset_target();
        _T.claimedShown = _g.claimed;
        var _n = array_length(_g.cells), _kept = array_create(_n, 0);
        array_copy(_kept, 0, _g.cells, 0, _n);
        _T.shownCells = _kept;
    }
    if (!surface_exists(_T.trailSurf) || _g.trailLen != _T.trailShown) {
        if (!surface_exists(_T.trailSurf)) _T.trailSurf = surface_create(_W, _VH);
        surface_set_target(_T.trailSurf); draw_clear_alpha(c_black, 0);
        gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
        unv_draw_trail(unv_cx_create(1), _g, _T.cw, _T.ch, _T.theme);
        gpu_pop_state(); surface_reset_target();
        _T.trailShown = _g.trailLen;
    }
    var _key = _g.claimed * 16 + _g.lives;
    if (!surface_exists(_T.hudSurf) || _key != _T.hudKey) {
        if (!surface_exists(_T.hudSurf)) _T.hudSurf = surface_create(_W, UNV_TOP);
        surface_set_target(_T.hudSurf); draw_clear_alpha(c_black, 0);
        gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
        unv_draw_hud(unv_cx_create(1), _W, _T.theme, { percent: unv_percent(_g), target: _g.target, lives: _g.lives, lives_max: _g.livesMax });
        gpu_pop_state(); surface_reset_target();
        _T.hudKey = _key;
    }
    if (_T.mode == "results" && !surface_exists(_T.resSurf)) {
        _T.resSurf = surface_create(_W, UNV_SCENE_H);
        surface_set_target(_T.resSurf); draw_clear_alpha(c_black, 0);
        gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
        unv_draw_results(unv_cx_create(1), _W, UNV_SCENE_H, _T.theme, _T.result);
        gpu_pop_state(); surface_reset_target();
    }
    matrix_set(matrix_world, _mw);
}

/// @function unv__fall_begin(scene)
/// @description Internal. Land was just claimed: copy the part of the OLD veil that now falls (the newly claimed cells;
/// on a win, every cell that was still veiled) into a layer of its own, cut it into pieces of UNV_FALL_BLOCK x
/// UNV_FALL_BLOCK cells, and start them falling in a wave out from where the cut closed. Its own generator (seeded from the
/// game's seed and the fall's index): the game's generator is never touched, so a game plays the same with fall on or off.
/// Returns the pieces made.
function unv__fall_begin(_T) {
    var _g = _T.game, _prev = _T.shownCells;
    if (!is_array(_prev) || !surface_exists(_T.veilSurf)) return 0;
    var _won = (_g.phase == "won"), _cols = _g.cols, _rows = _g.rows, _cl = _g.cells, _cw = _T.cw, _ch = _T.ch;
    var _W = UNV_SCENE_W, _VH = UNV_SCENE_H - UNV_TOP, _N = _cols * _rows;
    if (array_length(_prev) != _N || array_length(_cl) != _N) return 0;
    var _mask = array_create(_N, 0), _cells = 0;
    for (var _k = 0; _k < _N; _k++) if (_prev[_k] != UNV_CLAIMED && (_won || _cl[_k] == UNV_CLAIMED)) { _mask[_k] = 1; _cells++; }
    if (_cells == 0) return 0;
    // two layers at most: a claim made while two are still falling ends the older one at once
    if (array_length(_T.falls) >= 2) { unv__fall_drop(_T.falls[0]); array_delete(_T.falls, 0, 1); }
    var _sf = surface_create(_W, _VH);
    surface_set_target(_sf); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_zero);   // an exact copy: the veil layer is premultiplied
    for (var _y = 0; _y < _rows; _y++) {
        var _x = 0;
        while (_x < _cols) {
            if (_mask[_y * _cols + _x] == 0) { _x++; continue; }
            var _x0 = _x; while (_x < _cols && _mask[_y * _cols + _x] == 1) _x++;
            var _l = floor(_x0 * _cw), _t = floor(_y * _ch), _rr = min(_W, ceil(_x * _cw)), _bb = min(_VH, ceil((_y + 1) * _ch));
            draw_surface_part(_T.veilSurf, _l, _t, _rr - _l, _bb - _t, _l, _t);
        }
    }
    gpu_pop_state(); surface_reset_target();
    var _R = unv__scatter(unv_mix(_T.seed, 7919 + _T.fallN * 104729));
    repeat (3) unv__rand(_R);   // warm up: nearby seeds' first draws are not uniform (Doctrine_Craft s6)
    var _ox = _g.px + 0.5, _oy = _g.py + 0.5, _B = UNV_FALL_BLOCK, _P = [];
    for (var _by = 0; _by < _rows; _by += _B) for (var _bx = 0; _bx < _cols; _bx += _B) {
        var _has = 0, _ex = min(_cols, _bx + _B), _ey = min(_rows, _by + _B);
        for (var _yy = _by; _yy < _ey; _yy++) for (var _xx = _bx; _xx < _ex; _xx++) _has += _mask[_yy * _cols + _xx];
        if (_has == 0) continue;
        var _pl = floor(_bx * _cw), _pt = floor(_by * _ch), _pw = min(_W, ceil(_ex * _cw)) - _pl, _ph = min(_VH, ceil(_ey * _ch)) - _pt;
        var _ddx = (_bx + _ex) / 2 - _ox, _ddy = (_by + _ey) / 2 - _oy, _d = sqrt(_ddx * _ddx + _ddy * _ddy);
        // every draw in its own statement: GML evaluates a struct literal's or argument list's calls in no promised order
        var _u0 = unv__rand(_R); var _u1 = unv__rand(_R); var _u2 = unv__rand(_R); var _u3 = unv__rand(_R); var _u4 = unv__rand(_R); var _u5 = unv__rand(_R);
        var _nx = (_d > 0) ? _ddx / _d : 0;
        // (2026-10-18, looked at: a gentle pop and a slow spin piled the pieces up into a heap of blocks at the bottom of the
        // board; they pop harder, spread wider, spin faster and shrink as they fall AWAY, so the eye reads depth, not a pile)
        array_push(_P, { l: _pl, t: _pt, w: _pw, h: _ph, x: _pl + _pw / 2, y: _pt + _ph / 2,
            vx: _nx * (0.7 + _u0 * 1.6) + (_u1 - 0.5) * 2.2, vy: -(1.2 + _u2 * 2.6), rot: 0, vr: (_u3 - 0.5) * 22,
            flip: _u4 * pi, fs: 0.1 + _u5 * 0.16, delay: min(UNV_FALL_DELAY_MAX, floor(_d * 0.42 + _u0 * 3)), age: 0, live: true });
    }
    array_push(_T.falls, { surf: _sf, pieces: _P, live: array_length(_P), cells: _cells, won: _won });
    _T.fallN += 1; _T.fallPieces += array_length(_P); _T.falling = true;
    return array_length(_P);
}

/// @function unv__fall_drop(layer)
/// @description Internal. Free one fall layer's surface.
function unv__fall_drop(_L) { if (is_struct(_L) && is_numeric(_L[$ "surf"]) && surface_exists(_L.surf)) surface_free(_L.surf); }

/// @function unv__fall_step(scene)
/// @description Internal. Move every falling piece one frame (each waits for its place in the wave, then pops up, tumbles,
/// turns over - its back in shadow - shrinks a little and fades), then redraw the pieces into the scene's fall surface.
/// Runs only while something is falling; the layers are freed as they empty.
function unv__fall_step(_T) {
    if (!_T.falling) return;
    var _VH = UNV_SCENE_H - UNV_TOP, _W = UNV_SCENE_W, _alive = 0;
    for (var _i = array_length(_T.falls) - 1; _i >= 0; _i--) {
        var _L = _T.falls[_i];
        if (!surface_exists(_L.surf)) { array_delete(_T.falls, _i, 1); continue; }   // the layer was lost: that fall ends
        var _P = _L.pieces, _n = 0;
        for (var _j = 0; _j < array_length(_P); _j++) {
            var _p = _P[_j]; if (!_p.live) continue;
            if (_p.age < _p.delay) { _p.age += 1; _n++; continue; }
            var _t = _p.age - _p.delay; _p.age += 1;
            _p.vy += 0.36; _p.vx *= 0.985; _p.x += _p.vx; _p.y += _p.vy; _p.rot += _p.vr; _p.flip += _p.fs;
            if (_t >= UNV_FALL_FRAMES || _p.y - _p.h > _VH + 8) { _p.live = false; continue; }
            _n++;
        }
        _L.live = _n;
        if (_n == 0) { unv__fall_drop(_L); array_delete(_T.falls, _i, 1); } else _alive += _n;
    }
    if (_alive == 0) { _T.falling = false; if (surface_exists(_T.fxSurf)) surface_free(_T.fxSurf); _T.fxSurf = -1; return; }
    var _mw = matrix_get(matrix_world); matrix_set(matrix_world, matrix_build_identity());
    if (!surface_exists(_T.fxSurf)) _T.fxSurf = surface_create(_W, _VH);
    surface_set_target(_T.fxSurf); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); gpu_set_texfilter(true);   // premultiplied over
    for (var _i2 = 0; _i2 < array_length(_T.falls); _i2++) {
        var _L2 = _T.falls[_i2], _P2 = _L2.pieces;
        for (var _j2 = 0; _j2 < array_length(_P2); _j2++) {
            var _q = _P2[_j2]; if (!_q.live) continue;
            if (_q.age <= _q.delay) { draw_surface_part(_L2.surf, _q.l, _q.t, _q.w, _q.h, _q.l, _q.t); continue; }   // waiting in place
            var _tt = _q.age - _q.delay, _a = clamp((UNV_FALL_FRAMES - _tt) / 22, 0, 1), _k = 1 - 0.5 * (_tt / UNV_FALL_FRAMES);
            var _cf = cos(_q.flip), _xs = max(0.16, abs(_cf)) * _k, _ys = _k;
            var _v = 255 * _a * ((_cf < 0) ? 0.58 : 1), _col = make_colour_rgb(_v, _v, _v);   // premultiplied: colour carries the alpha
            // rotate about the piece's centre: draw_surface_general turns about the part's top-left corner
            var _th = degtorad(_q.rot), _hx = _q.w * 0.5 * _xs, _hy = _q.h * 0.5 * _ys;
            var _dx = _hx * cos(_th) + _hy * sin(_th), _dy = -_hx * sin(_th) + _hy * cos(_th);
            draw_surface_general(_L2.surf, _q.l, _q.t, _q.w, _q.h, _q.x - _dx, _q.y - _dy, _xs, _ys, _q.rot, _col, _col, _col, _col, _a);
        }
    }
    gpu_pop_state(); surface_reset_target();
    matrix_set(matrix_world, _mw);
}

/// @function unv__steer(scene, input)
/// @description Internal. Which way the player steers this frame: arrows, or toward a held pointer along its longer axis
/// (with the magnet). Returns 0 (none), 4 left, 6 right, 8 up, 2 down.
function unv__steer(_T, _in) {
    var _g = _T.game;
    if (_in.held) {
        var _tx = floor(_in.mx / _T.cw), _ty = floor((_in.my - UNV_TOP) / _T.ch), _dx = _tx - _g.px, _dy = _ty - _g.py;
        if (_dx == 0 && _dy == 0) return unv__magnet(_T);
        return (abs(_dx) >= abs(_dy)) ? ((_dx > 0) ? 6 : 4) : ((_dy > 0) ? 2 : 8);
    }
    return _in.left ? 4 : (_in.right ? 6 : (_in.up ? 8 : (_in.down ? 2 : 0)));
}

/// @function unv__magnet(scene)
/// @description Internal. A pointer that stops a cell or two short of revealed land while cutting still closes the cut:
/// keep the last direction when claimed land lies within UNV_MAGNET cells ahead.
function unv__magnet(_T) {
    var _g = _T.game, _d = _T.lastDir;
    if (!_g.drawing || _d == 0) return 0;
    var _ux = (_d == 4) ? -1 : ((_d == 6) ? 1 : 0), _uy = (_d == 8) ? -1 : ((_d == 2) ? 1 : 0);
    for (var _k = 1; _k <= UNV_MAGNET; _k++) { var _cell = unv_at(_g, _g.px + _ux * _k, _g.py + _uy * _k); if (_cell == UNV_CLAIMED) return _d; if (_cell != UNV_OPEN) return 0; }
    return 0;
}

/// @function unv_step(scene, [mouse_x], [mouse_y])
/// @description Run the scene one frame: read the keyboard (arrows move; hold Shift, Z, Space or Enter to cut; Enter, Space
/// or Z on the results to leave; Escape leaves when allowed) and the mouse (press and hold: steer toward the pointer and
/// cut), move the player every 3 frames, run the world, redraw what changed. Pass the pointer in the SAME coordinates you
/// give unv_draw (for Draw GUI: device_mouse_x_to_gui(0), device_mouse_y_to_gui(0)). For tutorials, tests or replays set
/// scene.inject = { dx, dy, draw, ok, leave, held, mx, my } (scene coordinates) for one frame: it replaces the devices.
/// @param {Struct} scene
/// @param {Real} [mouse_x]
/// @param {Real} [mouse_y]
function unv_step(_T, _mx = undefined, _my = undefined) {
    if (!unv__is_scene(_T) || _T.closed) return;
    var _in = { left: false, right: false, up: false, down: false, draw: false, ok: false, leave: false, held: false, mx: 0, my: 0 };
    var _j = _T.inject; _T.inject = undefined;
    if (is_struct(_j)) {
        var _dx = is_numeric(_j[$ "dx"]) ? _j.dx : 0, _dy = is_numeric(_j[$ "dy"]) ? _j.dy : 0;
        _in.left = _dx < 0; _in.right = _dx > 0; _in.up = _dy < 0; _in.down = _dy > 0;
        _in.draw = _j[$ "draw"] == true; _in.ok = _j[$ "ok"] == true; _in.leave = _j[$ "leave"] == true; _in.held = _j[$ "held"] == true;
        _in.mx = is_numeric(_j[$ "mx"]) ? _j.mx : 0; _in.my = is_numeric(_j[$ "my"]) ? _j.my : 0;
    } else {
        _in.left = keyboard_check(vk_left); _in.right = keyboard_check(vk_right); _in.up = keyboard_check(vk_up); _in.down = keyboard_check(vk_down);
        _in.draw = keyboard_check(vk_shift) || keyboard_check(ord("Z")) || keyboard_check(vk_space) || keyboard_check(vk_enter);
        _in.ok = keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("Z")) || mouse_check_button_pressed(mb_left);
        _in.leave = keyboard_check_pressed(vk_escape);
        if (is_numeric(_mx) && is_numeric(_my) && mouse_check_button(mb_left)) {
            var _v = _T.view, _s = (_v.s > 0) ? _v.s : 1;
            _in.held = true; _in.mx = (_mx - _v.x) / _s; _in.my = (_my - _v.y) / _s;
        }
    }
    _T.spin += 0.06;
    var _g = _T.game;
    if (_T.mode == "play") {
        if (_in.leave && _T.allowLeave) {
            _T.left = true; _T.result = unv_results(_g); _T.result.left = true; _T.closed = true; return;
        }
        _T.moveT += 1;
        if (_T.moveT >= UNV_MOVE_EVERY) {
            var _dir = unv__steer(_T, _in);
            if (_dir != 0) {
                _T.moveT = 0; _T.lastDir = _dir;
                var _r = unv_move(_g, (_dir == 4) ? -1 : ((_dir == 6) ? 1 : 0), (_dir == 8) ? -1 : ((_dir == 2) ? 1 : 0), _in.draw || _in.held);
                if (_r == "cut" && _g.trailLen == 1) unv__sound(_T, "cut");
                if (_r == "closed") unv__sound(_T, "claim");
            }
        }
        var _lives = _g.lives;
        unv_tick(_g);
        if (_g.lives != _lives) unv__sound(_T, "hit");
        if (_g.phase != "play") { _T.mode = "results"; _T.t = 0; _T.result = unv_results(_g); _T.result.left = false; unv__sound(_T, (_g.phase == "won") ? "won" : "lost"); }
    } else if (_T.mode == "results") {
        // the panel waits for the veil to finish falling; OK counts from when it appears
        if (!_T.falling) {
            _T.t++;
            if (_T.t > 30 && (_in.ok || _in.held)) _T.closed = true;
        }
    }
    unv__refresh(_T);
    unv__fall_step(_T);
}

/// @function unv_draw(scene, x, y, scale)
/// @description Draw the scene with its top-left at (x, y), 816 x 624 times scale: the picture (scaled to cover the
/// board), the veil with the revealed land cut out, the trail, the creatures, the sparks, the player, the band, and the
/// results. Only blits what unv_step baked (a surface lost since is rebuilt here, once).
/// @param {Struct} scene
/// @param {Real} x
/// @param {Real} y
/// @param {Real} scale
function unv_draw(_T, _x, _y, _s) {
    if (!unv__is_scene(_T)) return;
    _x = unv__fin(_x, 0); _y = unv__fin(_y, 0); _s = unv__fin(_s, 1); if (!(_s > 0)) _s = 1;
    _T.view = { x: _x, y: _y, s: _s };
    if (!surface_exists(_T.veilSurf) || !surface_exists(_T.trailSurf) || !surface_exists(_T.hudSurf) || (_T.mode == "results" && !surface_exists(_T.resSurf))) unv__refresh(_T);
    var _g = _T.game, _W = UNV_SCENE_W, _VH = UNV_SCENE_H - UNV_TOP, _top = UNV_TOP * _s;
    draw_set_alpha(1); draw_set_colour(make_colour_rgb(8, 6, 10)); draw_rectangle(_x, _y, _x + _W * _s - 1, _y + UNV_SCENE_H * _s - 1, false);
    draw_set_colour(c_white);
    // the picture, scaled to COVER the board and centred (the overflow is cropped)
    var _pw = sprite_get_width(_T.pic), _ph = sprite_get_height(_T.pic), _k = max(_W / max(1, _pw), _VH / max(1, _ph));
    var _sw = _W / _k, _sh = _VH / _k, _sx = (_pw - _sw) / 2, _sy = (_ph - _sh) / 2;
    // ⛔ Two blends, on purpose. The buyer's picture is an ordinary sprite: straight alpha, drawn with separate alpha so it
    // never lowers the alpha of a surface the buyer draws the scene into. Everything the scene BAKED (veil, trail, band,
    // panel, creature, spark, marker) was drawn into a transparent surface with separate alpha, which leaves its colour
    // PREMULTIPLIED: it is blitted premultiplied-over (one, inv_src_alpha). Blitting it with the normal blend multiplied
    // every halo by its alpha twice and punched alpha holes in a buyer's surface (seen in the first scene render).
    gpu_push_state(); gpu_set_texfilter(true);
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    draw_sprite_part_ext(_T.pic, 0, _sx, _sy, _sw, _sh, _x, _y + _top, _k * _s, _k * _s, c_white, 1);   // a part is in IMAGE pixels; the origin plays no part
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    var _won = (_g.phase == "won");
    if (!_won) draw_surface_ext(_T.veilSurf, _x, _y + _top, _s, _s, 0, c_white, 1);
    if (_T.falling && surface_exists(_T.fxSurf)) draw_surface_ext(_T.fxSurf, _x, _y + _top, _s, _s, 0, c_white, 1);   // the veil falling away
    if (!_won) {
        draw_surface_ext(_T.trailSurf, _x, _y + _top, _s, _s, 0, c_white, 1);
        for (var _i = 0; _i < array_length(_g.creatures); _i++) {
            var _q = _g.creatures[_i];
            var _rot = (_T.turns == "spin") ? -radtodeg(_T.spin) : ((_T.turns == "face") ? -radtodeg(arctan2(_q.vy, _q.vx)) : 0);
            draw_sprite_ext(_T.crSpr, 0, _x + _q.x * _T.cw * _s, _y + _top + _q.y * _T.ch * _s, _s, _s, _rot, c_white, 1);
        }
        for (var _j = 0; _j < array_length(_g.sparks); _j++) {
            var _p = _g.sparks[_j], _ps = (((_g.frame + _j) mod 6) < 3) ? 1 : 0.8, _sr = _T.sparkTurns ? -radtodeg(_T.spin * 1.5) - _j * 23 : 0;
            draw_sprite_ext(_T.spSpr, 0, _x + (_p.x + 0.5) * _T.cw * _s, _y + _top + (_p.y + 0.5) * _T.ch * _s, _ps * _s, _ps * _s, _sr, c_white, 1);
        }
        draw_sprite_ext(_T.mkSpr, 0, _x + (_g.px + 0.5) * _T.cw * _s, _y + _top + (_g.py + 0.5) * _T.ch * _s, _s, _s, 0, c_white, 1);
    }
    draw_surface_ext(_T.hudSurf, _x, _y, _s, _s, 0, c_white, 1);
    if (_T.mode == "results" && !_T.falling && surface_exists(_T.resSurf)) draw_surface_ext(_T.resSurf, _x, _y, _s, _s, 0, c_white, 1);
    gpu_pop_state();
}

/// @function unv_closed(scene)
/// @description True once the player has left: read scene.result then ({ won, lost, left, percent, target, lives, cuts,
/// hits, frames }) and unv_free the scene. Not a scene -> true (nothing to wait for).
/// @returns {Bool}
function unv_closed(_T) { return !unv__is_scene(_T) || _T.closed; }

/// @function unv_free(scene)
/// @description Free everything the scene made (its surfaces and sprites; the picture too when the scene copied it from a
/// surface). Safe to call twice; the scene is unusable afterwards.
function unv_free(_T) {
    if (!is_struct(_T)) return;
    var _surfs = ["veilSurf", "trailSurf", "hudSurf", "resSurf", "fxSurf"], _sprs = ["veilSpr", "crSpr", "spSpr", "mkSpr"];
    for (var _i = 0; _i < array_length(_surfs); _i++) { var _sf = _T[$ _surfs[_i]]; if (is_numeric(_sf) && surface_exists(_sf)) surface_free(_sf); _T[$ _surfs[_i]] = -1; }
    for (var _i2 = 0; _i2 < array_length(_sprs); _i2++) { var _sp = _T[$ _sprs[_i2]]; if (is_numeric(_sp) && _sp >= 0 && sprite_exists(_sp)) sprite_delete(_sp); _T[$ _sprs[_i2]] = -1; }
    var _fs = _T[$ "falls"]; if (is_array(_fs)) for (var _f = 0; _f < array_length(_fs); _f++) unv__fall_drop(_fs[_f]);
    _T.falls = []; _T.falling = false;
    if (_T[$ "picOwned"] == true && is_numeric(_T[$ "pic"]) && sprite_exists(_T.pic)) sprite_delete(_T.pic);
    _T.picOwned = false; _T.closed = true;
    if (variable_struct_exists(_T, "game")) _T.game = undefined;
}
