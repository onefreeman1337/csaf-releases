/// unv_creatures.gml - the creature forms that drift in the veil: the RPG Maker MZ edition's many-armed wisp and six this
/// edition adds (a jellyfish, a moth, a star, an eye, a comet, a spore). Every form is drawn in the veil's own palette into
/// a size x size box (directional forms face +x, the way they travel); the scene bakes one sprite a game and turns it -
/// spinning the radial forms, pointing the directional ones along their drift. Below them, the spark styles that run the
/// revealed edge: the MZ edition's ember and seven this edition adds, one for each veil.
///
/// Unveil - Reveal Any Picture, a Qix-Style Minigame for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function unv_creatures()
/// @description The creature forms, in order: ["wisp", "jelly", "moth", "star", "eye", "comet", "spore"].
/// @returns {Array<String>}
function unv_creatures() { return ["wisp", "jelly", "moth", "star", "eye", "comet", "spore"]; }

/// @function unv_creature_turns(form)
/// @description How the scene turns a form: "spin" (radial forms turn steadily), "face" (directional forms point along their
/// drift) or "still" (the eye keeps its gaze level).
/// @returns {String}
function unv_creature_turns(_f) {
    if (_f == "jelly" || _f == "moth" || _f == "comet") return "face";
    if (_f == "eye") return "still";
    return "spin";
}

/// @function unv__creature_form(ctx, size, stage, form)
/// @description Internal. Draw one of the six added forms centred in a size x size box; false for an unknown form (the
/// caller then draws the wisp).
function unv__creature_form(_c, _size, _T, _f) {
    var _r = _size / 2;
    unv_cx_save(_c); unv_cx_translate(_c, _r, _r);
    var _halo = unv_cx_radial(_c, 0, 0, 0, 0, 0, _r); unv_cx_stop(_halo, 0, _T.glow, 0.42); unv_cx_stop(_halo, 1, _T.glow, 0);
    _c.fill = _halo; unv__p_fill_rect(_c, -_r, -_r, _size, _size);
    _c.join = 0; _c.cap = UNV_STROKE_ROUND;
    var _done = true;
    switch (_f) {
        case "jelly":
            // tentacles trail behind (-x), wavy; the bell leads (+x), lit from inside
            // (2026-10-16, looked at: the first bell was a sliver beside its tentacles - enlarged, the tentacles thickened)
            _c.stroke = unv_cx_solid(_T.trail, 0.85); _c.lw = 2.4;
            for (var _t = 0; _t < 6; _t++) {
                var _y0 = (-0.34 + _t * 0.136) * _r;
                unv__p_begin(_c); unv__p_move(_c, 0, _y0);
                unv__p_bez(_c, -_r * 0.3, _y0 + _r * 0.12 * ((_t mod 2) ? 1 : -1), -_r * 0.6, _y0 - _r * 0.12 * ((_t mod 2) ? 1 : -1), -_r * 0.9, _y0 + _r * 0.05);
                unv__p_stroke(_c);
            }
            var _bg = unv_cx_radial(_c, _r * 0.12, 0, 0, _r * 0.12, 0, _r * 0.62); unv_cx_stop(_bg, 0, [255, 255, 255], 0.98); unv_cx_stop(_bg, 0.45, _T.trail, 0.95); unv_cx_stop(_bg, 1, _T.glow, 0.8);
            _c.fill = _bg; unv__p_begin(_c); unv__p_ellipse(_c, _r * 0.02, 0, _r * 0.5, _r * 0.54, 0, -pi / 2, pi / 2); unv__p_line(_c, _r * 0.02, _r * 0.54); unv__p_line(_c, _r * 0.02, -_r * 0.54); unv__p_close(_c); unv__p_fill(_c);
            _c.stroke = unv_cx_solid([255, 255, 255], 0.8); _c.lw = 1.2; unv__p_stroke(_c);
            break;
        case "moth":
            // four wings with eyespots, a furred body, two feathered antennae reaching forward (+x)
            var _wings = [[-0.05, -0.32, 0.36, 0.22, -0.5], [-0.05, 0.32, 0.36, 0.22, 0.5], [-0.32, -0.2, 0.22, 0.15, -0.9], [-0.32, 0.2, 0.22, 0.15, 0.9]];
            for (var _w = 0; _w < 4; _w++) {
                var _wv = _wings[_w];
                var _wg = unv_cx_radial(_c, _wv[0] * _r, _wv[1] * _r, 0, _wv[0] * _r, _wv[1] * _r, _wv[2] * _r * 1.1); unv_cx_stop(_wg, 0, _T.trail, 0.95); unv_cx_stop(_wg, 1, _T.glow, 0.7);
                _c.fill = _wg; unv__p_begin(_c); unv__p_ellipse(_c, _wv[0] * _r, _wv[1] * _r, _wv[2] * _r, _wv[3] * _r, _wv[4], 0, UNV_TAU); unv__p_fill(_c);
                _c.fill = unv_cx_solid([26, 11, 18], 0.85); unv__p_begin(_c); unv__p_arc(_c, _wv[0] * _r, _wv[1] * _r, _wv[3] * _r * 0.42, 0, UNV_TAU); unv__p_fill(_c);
                _c.fill = unv_cx_solid([255, 255, 255], 0.9); unv__p_begin(_c); unv__p_arc(_c, _wv[0] * _r + 1, _wv[1] * _r - 1, _wv[3] * _r * 0.14, 0, UNV_TAU); unv__p_fill(_c);
            }
            _c.fill = unv_cx_solid(_T.ink); unv__p_begin(_c); unv__p_ellipse(_c, 0, 0, _r * 0.34, _r * 0.09, 0, 0, UNV_TAU); unv__p_fill(_c);
            _c.stroke = unv_cx_solid(_T.ink, 0.9); _c.lw = 1.2;
            for (var _an = -1; _an <= 1; _an += 2) { unv__p_begin(_c); unv__p_move(_c, _r * 0.3, _an * _r * 0.03); unv__p_quad(_c, _r * 0.6, _an * _r * 0.08, _r * 0.78, _an * _r * 0.3); unv__p_stroke(_c); }
            break;
        case "star":
            var _n = 6, _sg = unv_cx_radial(_c, 0, 0, 0, 0, 0, _r * 0.9); unv_cx_stop(_sg, 0, [255, 255, 255]); unv_cx_stop(_sg, 0.35, _T.trail); unv_cx_stop(_sg, 1, _T.glow, 0.85);
            _c.fill = _sg; unv__p_begin(_c);
            for (var _k = 0; _k < _n * 2; _k++) { var _a = _k * pi / _n - pi / 2, _rr = ((_k mod 2) == 0) ? _r * 0.9 : _r * 0.38; if (_k == 0) unv__p_move(_c, cos(_a) * _rr, sin(_a) * _rr); else unv__p_line(_c, cos(_a) * _rr, sin(_a) * _rr); }
            unv__p_close(_c); unv__p_fill(_c);
            _c.stroke = unv_cx_solid([255, 255, 255], 0.85); _c.lw = 1.4; unv__p_stroke(_c);
            _c.fill = unv_cx_solid([26, 11, 18]); unv__p_begin(_c); unv__p_arc(_c, 0, 0, _r * 0.12, 0, UNV_TAU); unv__p_fill(_c);
            break;
        case "eye":
            _c.fill = unv_cx_solid(_T.ink); unv__p_begin(_c); unv__p_ellipse(_c, 0, 0, _r * 0.82, _r * 0.44, 0, 0, UNV_TAU); unv__p_fill(_c);
            var _ig = unv_cx_radial(_c, 0, 0, 0, 0, 0, _r * 0.34); unv_cx_stop(_ig, 0, _T.trail); unv_cx_stop(_ig, 1, _T.glow);
            _c.fill = _ig; unv__p_begin(_c); unv__p_arc(_c, 0, 0, _r * 0.34, 0, UNV_TAU); unv__p_fill(_c);
            _c.fill = unv_cx_solid([12, 6, 10]); unv__p_begin(_c); unv__p_arc(_c, 0, 0, _r * 0.15, 0, UNV_TAU); unv__p_fill(_c);
            _c.fill = unv_cx_solid([255, 255, 255], 0.95); unv__p_begin(_c); unv__p_arc(_c, -_r * 0.08, -_r * 0.09, _r * 0.06, 0, UNV_TAU); unv__p_fill(_c);
            _c.stroke = unv_cx_solid(_T.glow); _c.lw = 1.6; unv__p_begin(_c); unv__p_ellipse(_c, 0, 0, _r * 0.82, _r * 0.44, 0, 0, UNV_TAU); unv__p_stroke(_c);
            _c.lw = 1.4;
            for (var _l = 0; _l < 7; _l++) { var _la = pi + 0.35 + _l * (pi - 0.7) / 6, _lx = cos(_la) * _r * 0.8, _ly = sin(_la) * _r * 0.43; unv__p_begin(_c); unv__p_move(_c, _lx, _ly); unv__p_line(_c, _lx * 1.15, _ly * 1.5 - _r * 0.06); unv__p_stroke(_c); }
            break;
        case "comet":
            // the head leads (+x); the tail streams behind and fades
            // (2026-10-16, looked at: the first comet was a faint streak - the tail widened and strengthened, the head made solid)
            var _tg = unv_cx_linear(_c, _r * 0.4, 0, -_r * 0.95, 0); unv_cx_stop(_tg, 0, _T.trail, 0.98); unv_cx_stop(_tg, 0.6, _T.trail, 0.55); unv_cx_stop(_tg, 1, _T.trail, 0);
            _c.fill = _tg; unv__p_begin(_c); unv__p_move(_c, _r * 0.4, -_r * 0.3); unv__p_quad(_c, -_r * 0.3, -_r * 0.44, -_r * 0.95, -_r * 0.08); unv__p_line(_c, -_r * 0.95, _r * 0.08); unv__p_quad(_c, -_r * 0.3, _r * 0.44, _r * 0.4, _r * 0.3); unv__p_close(_c); unv__p_fill(_c);
            _c.stroke = unv_cx_solid([255, 255, 255], 0.7); _c.lw = 1.3;
            for (var _s = -1; _s <= 1; _s++) { unv__p_begin(_c); unv__p_move(_c, _r * 0.3, _s * _r * 0.12); unv__p_line(_c, -_r * 0.85, _s * _r * 0.28); unv__p_stroke(_c); }
            _c.fill = unv_cx_solid(_T.trail); unv__p_begin(_c); unv__p_arc(_c, _r * 0.44, 0, _r * 0.24, 0, UNV_TAU); unv__p_fill(_c);
            var _hg = unv_cx_radial(_c, _r * 0.48, -_r * 0.04, 0, _r * 0.48, -_r * 0.04, _r * 0.2); unv_cx_stop(_hg, 0, [255, 255, 255]); unv_cx_stop(_hg, 1, [255, 255, 255], 0);
            _c.fill = _hg; unv__p_fill_rect(_c, _r * 0.28, -_r * 0.24, _r * 0.4, _r * 0.4);
            break;
        case "spore":
            // (2026-10-16: the first spore was too airy to hold its own on a busy veil - stalks, tips and core strengthened)
            _c.stroke = unv_cx_solid(_T.trail, 0.9); _c.lw = 1.5;
            for (var _p = 0; _p < 16; _p++) {
                var _pa = _p * UNV_TAU / 16 + ((_p mod 2) ? 0.09 : 0), _pl = ((_p mod 3) == 0) ? 0.86 : 0.7;
                unv__p_begin(_c); unv__p_move(_c, cos(_pa) * _r * 0.2, sin(_pa) * _r * 0.2); unv__p_line(_c, cos(_pa) * _r * _pl, sin(_pa) * _r * _pl); unv__p_stroke(_c);
                _c.fill = unv_cx_solid([255, 255, 255], 0.95); unv__p_begin(_c); unv__p_arc(_c, cos(_pa) * _r * _pl, sin(_pa) * _r * _pl, 2.6, 0, UNV_TAU); unv__p_fill(_c);
            }
            var _cg = unv_cx_radial(_c, 0, 0, 0, 0, 0, _r * 0.3); unv_cx_stop(_cg, 0, [255, 255, 255]); unv_cx_stop(_cg, 1, _T.trail);
            _c.fill = _cg; unv__p_begin(_c); unv__p_arc(_c, 0, 0, _r * 0.3, 0, UNV_TAU); unv__p_fill(_c);
            break;
        default: _done = false;
    }
    _c.cap = 0;
    unv_cx_restore(_c);
    return _done;
}

// ---------------------------------------------------------------------------------------------------------------
// Sparks: the RPG Maker MZ edition draws one spark (an ember with rays) on every veil. This edition gives every veil
// its own spark, drawn in that veil's palette; "ember" is the MZ edition's and stays the silk veil's.
// ---------------------------------------------------------------------------------------------------------------

/// @function unv_spark_styles()
/// @description The spark styles, in order: ["ember", "flake", "leaf", "firefly", "pinwheel", "flame", "droplet",
/// "prism"]. Each veil has its own (unv_spark_of); any veil can be given any style.
/// @returns {Array<String>}
function unv_spark_styles() { return ["ember", "flake", "leaf", "firefly", "pinwheel", "flame", "droplet", "prism"]; }

/// @function unv_spark_of(theme)
/// @description The spark style a veil draws by default: silk ember, frost flake, lacquer leaf, velvet firefly, washi
/// pinwheel, smoke flame, ink wash droplet, leaded prism. Anything else -> "ember".
/// @returns {String}
function unv_spark_of(_theme) {
    static M = { silk: "ember", frost: "flake", lacquer: "leaf", velvet: "firefly", washi: "pinwheel", smoke: "flame", inkwash: "droplet", leaded: "prism" };
    return (is_string(_theme) && variable_struct_exists(M, _theme)) ? M[$ _theme] : "ember";
}

/// @function unv_spark_turns(style)
/// @description True for the styles the scene turns as they run (the flake, the pinwheel and the prism); the others keep
/// their orientation and only pulse.
/// @returns {Bool}
function unv_spark_turns(_s) { return _s == "flake" || _s == "pinwheel" || _s == "prism"; }

/// @function unv__spark_form(ctx, size, stage, style)
/// @description Internal. Draw one of the seven added spark styles centred in a size x size box; false for "ember" or an
/// unknown style (the caller then draws the MZ edition's ember). Sized for the scene's 24 px box: every mark is at least
/// 1.4 px wide and every form keeps a white core so a spark reads on the darkest and the palest veil.
function unv__spark_form(_c, _size, _T, _s) {
    var _r = _size / 2, _done = true;
    unv_cx_save(_c); unv_cx_translate(_c, _r, _r);
    var _gl = unv_cx_radial(_c, 0, 0, 0, 0, 0, _r); unv_cx_stop(_gl, 0, _T.glow, 0.7); unv_cx_stop(_gl, 0.45, _T.glow, 0.32); unv_cx_stop(_gl, 1, _T.glow, 0);
    _c.join = 0; _c.cap = UNV_STROKE_ROUND;
    switch (_s) {
        case "flake":
            // six arms, each with two barbs, round a white hub
            _c.fill = _gl; unv__p_fill_rect(_c, -_r, -_r, _size, _size);
            for (var _pass = 0; _pass < 2; _pass++) {
                _c.stroke = (_pass == 0) ? unv_cx_solid(_T.trail, 0.9) : unv_cx_solid([255, 255, 255], 1); _c.lw = (_pass == 0) ? 3.2 : 1.5;
                for (var _k = 0; _k < 6; _k++) {
                    var _a = _k * pi / 3 - pi / 2, _ca = cos(_a), _sa = sin(_a), _L = _r * 0.86;
                    unv__p_begin(_c); unv__p_move(_c, 0, 0); unv__p_line(_c, _ca * _L, _sa * _L);
                    var _bx = _ca * _L * 0.55, _by = _sa * _L * 0.55, _bl = _r * 0.3;
                    unv__p_move(_c, _bx, _by); unv__p_line(_c, _bx + cos(_a + 0.75) * _bl, _by + sin(_a + 0.75) * _bl);
                    unv__p_move(_c, _bx, _by); unv__p_line(_c, _bx + cos(_a - 0.75) * _bl, _by + sin(_a - 0.75) * _bl);
                    unv__p_stroke(_c);
                }
            }
            _c.fill = unv_cx_solid([255, 255, 255]); unv__p_begin(_c); unv__p_arc(_c, 0, 0, _r * 0.16, 0, UNV_TAU); unv__p_fill(_c);
            break;
        case "leaf":
            // a fleck of gold leaf, folded once: two facets of the rim gold, the lit one paler, a hot point where it folds
            _c.fill = _gl; unv__p_fill_rect(_c, -_r, -_r, _size, _size);
            _c.fill = unv_cx_solid(unv__mix_rgb(_T.rim, [70, 40, 10], 0.25)); unv__p_begin(_c);
            unv__p_move(_c, -_r * 0.78, -_r * 0.18); unv__p_line(_c, _r * 0.05, -_r * 0.72); unv__p_line(_c, _r * 0.12, _r * 0.06); unv__p_line(_c, -_r * 0.42, _r * 0.5); unv__p_close(_c); unv__p_fill(_c);
            _c.fill = unv_cx_solid(unv__mix_rgb(_T.rim, [255, 250, 220], 0.45)); unv__p_begin(_c);
            unv__p_move(_c, _r * 0.05, -_r * 0.72); unv__p_line(_c, _r * 0.8, -_r * 0.1); unv__p_line(_c, _r * 0.3, _r * 0.74); unv__p_line(_c, _r * 0.12, _r * 0.06); unv__p_close(_c); unv__p_fill(_c);
            _c.stroke = unv_cx_solid([255, 246, 210], 0.95); _c.lw = 1.4; unv__p_begin(_c); unv__p_move(_c, _r * 0.05, -_r * 0.72); unv__p_line(_c, _r * 0.12, _r * 0.06); unv__p_stroke(_c);
            var _hot = unv_cx_radial(_c, _r * 0.08, -_r * 0.3, 0, _r * 0.08, -_r * 0.3, _r * 0.42); unv_cx_stop(_hot, 0, [255, 255, 255], 0.95); unv_cx_stop(_hot, 1, [255, 255, 255], 0);
            _c.fill = _hot; unv__p_fill_rect(_c, -_r * 0.34, -_r * 0.72, _r * 0.84, _r * 0.84);
            break;
        case "firefly":
            // seen from above: two wings spread out to the SIDES (2026-10-18, looked at: wings drawn above the body read as
            // a mushroom cap), a dark head and thorax, and the glowing tail inside a wide warm halo
            var _hl = unv_cx_radial(_c, 0, _r * 0.28, 0, 0, _r * 0.28, _r * 0.95); unv_cx_stop(_hl, 0, _T.glow, 0.9); unv_cx_stop(_hl, 0.3, _T.glow, 0.45); unv_cx_stop(_hl, 1, _T.glow, 0);
            _c.fill = _hl; unv__p_fill_rect(_c, -_r, -_r, _size, _size);
            _c.fill = unv_cx_solid([255, 255, 255], 0.5);
            unv__p_begin(_c); unv__p_ellipse(_c, -_r * 0.36, -_r * 0.12, _r * 0.36, _r * 0.15, 0.55, 0, UNV_TAU); unv__p_fill(_c);
            unv__p_begin(_c); unv__p_ellipse(_c, _r * 0.36, -_r * 0.12, _r * 0.36, _r * 0.15, -0.55, 0, UNV_TAU); unv__p_fill(_c);
            _c.fill = unv_cx_solid([46, 34, 24]); unv__p_begin(_c); unv__p_ellipse(_c, 0, -_r * 0.2, _r * 0.12, _r * 0.3, 0, 0, UNV_TAU); unv__p_fill(_c);
            var _tl = unv_cx_radial(_c, 0, _r * 0.3, 0, 0, _r * 0.3, _r * 0.24); unv_cx_stop(_tl, 0, [255, 255, 255]); unv_cx_stop(_tl, 0.5, _T.trail); unv_cx_stop(_tl, 1, _T.glow, 0.9);
            _c.fill = _tl; unv__p_begin(_c); unv__p_ellipse(_c, 0, _r * 0.3, _r * 0.17, _r * 0.25, 0, 0, UNV_TAU); unv__p_fill(_c);
            break;
        case "pinwheel":
            // a paper pinwheel: four folded blades, each half the veil's red and half the paper, a pin at the hub
            _c.fill = _gl; unv__p_fill_rect(_c, -_r, -_r, _size, _size);
            for (var _b = 0; _b < 4; _b++) {
                var _a0 = _b * pi / 2, _tip = _r * 0.9;
                var _ox = cos(_a0) * _tip, _oy = sin(_a0) * _tip, _sx = cos(_a0 + pi / 2) * _tip * 0.62, _sy = sin(_a0 + pi / 2) * _tip * 0.62;
                _c.fill = unv_cx_solid(_T.trail); unv__p_begin(_c); unv__p_move(_c, 0, 0); unv__p_line(_c, _ox, _oy); unv__p_line(_c, _ox * 0.5 + _sx * 0.5, _oy * 0.5 + _sy * 0.5); unv__p_close(_c); unv__p_fill(_c);
                _c.fill = unv_cx_solid([252, 246, 232]); unv__p_begin(_c); unv__p_move(_c, 0, 0); unv__p_line(_c, _ox * 0.5 + _sx * 0.5, _oy * 0.5 + _sy * 0.5); unv__p_line(_c, _sx * 0.55, _sy * 0.55); unv__p_close(_c); unv__p_fill(_c);
            }
            _c.stroke = unv_cx_solid([60, 20, 16], 0.7); _c.lw = 1;
            for (var _e = 0; _e < 4; _e++) { var _ae = _e * pi / 2; unv__p_begin(_c); unv__p_move(_c, 0, 0); unv__p_line(_c, cos(_ae) * _r * 0.9, sin(_ae) * _r * 0.9); unv__p_stroke(_c); }
            _c.fill = unv_cx_solid([255, 214, 120]); unv__p_begin(_c); unv__p_arc(_c, 0, 0, _r * 0.17, 0, UNV_TAU); unv__p_fill(_c);
            _c.fill = unv_cx_solid([255, 255, 255]); unv__p_begin(_c); unv__p_arc(_c, -_r * 0.05, -_r * 0.05, _r * 0.07, 0, UNV_TAU); unv__p_fill(_c);
            break;
        case "flame":
            // a will-o'-the-wisp: a teardrop flame leaning up, a pale tongue inside it, a white seed at its foot
            _c.fill = _gl; unv__p_fill_rect(_c, -_r, -_r, _size, _size);
            var _fo = unv_cx_linear(_c, 0, _r * 0.7, 0, -_r * 0.9); unv_cx_stop(_fo, 0, _T.glow, 1); unv_cx_stop(_fo, 0.6, _T.trail, 0.95); unv_cx_stop(_fo, 1, _T.trail, 0.2);
            _c.fill = _fo; unv__p_begin(_c); unv__p_move(_c, 0, -_r * 0.92);
            unv__p_bez(_c, _r * 0.22, -_r * 0.42, _r * 0.62, -_r * 0.06, _r * 0.5, _r * 0.34); unv__p_bez(_c, _r * 0.38, _r * 0.74, -_r * 0.38, _r * 0.74, -_r * 0.5, _r * 0.34);
            unv__p_bez(_c, -_r * 0.62, -_r * 0.06, -_r * 0.1, -_r * 0.36, 0, -_r * 0.92); unv__p_close(_c); unv__p_fill(_c);
            _c.fill = unv_cx_solid([255, 255, 255], 0.88); unv__p_begin(_c); unv__p_move(_c, 0, -_r * 0.3);
            unv__p_bez(_c, _r * 0.12, -_r * 0.08, _r * 0.3, _r * 0.12, _r * 0.22, _r * 0.36); unv__p_bez(_c, _r * 0.12, _r * 0.56, -_r * 0.12, _r * 0.56, -_r * 0.22, _r * 0.36);
            unv__p_bez(_c, -_r * 0.3, _r * 0.12, -_r * 0.06, -_r * 0.1, 0, -_r * 0.3); unv__p_close(_c); unv__p_fill(_c);
            break;
        case "droplet":
            // a splash of the red seal ink: a round drop, a crown of satellite drops, an ink-dark rim so it reads on paper
            for (var _d = 0; _d < 7; _d++) {
                var _da = _d * UNV_TAU / 7 + 0.4, _dr = _r * ((_d mod 2) ? 0.62 : 0.76), _ds = _r * ((_d mod 2) ? 0.11 : 0.15);
                _c.fill = unv_cx_solid([40, 24, 28], 0.85); unv__p_begin(_c); unv__p_arc(_c, cos(_da) * _dr, sin(_da) * _dr, _ds + 0.9, 0, UNV_TAU); unv__p_fill(_c);
                _c.fill = unv_cx_solid(_T.trail); unv__p_begin(_c); unv__p_arc(_c, cos(_da) * _dr, sin(_da) * _dr, _ds, 0, UNV_TAU); unv__p_fill(_c);
            }
            _c.fill = unv_cx_solid([40, 24, 28], 0.9); unv__p_begin(_c); unv__p_arc(_c, 0, 0, _r * 0.42, 0, UNV_TAU); unv__p_fill(_c);
            var _dg = unv_cx_radial(_c, -_r * 0.1, -_r * 0.12, 0, 0, 0, _r * 0.36); unv_cx_stop(_dg, 0, [255, 236, 226]); unv_cx_stop(_dg, 0.35, _T.glow); unv_cx_stop(_dg, 1, _T.trail);
            _c.fill = _dg; unv__p_begin(_c); unv__p_arc(_c, 0, 0, _r * 0.36, 0, UNV_TAU); unv__p_fill(_c);
            break;
        case "prism":
            // a cut crystal throwing a spectrum: four coloured rays behind a faceted diamond with a white table
            _c.fill = _gl; unv__p_fill_rect(_c, -_r, -_r, _size, _size);
            var _rays = [[236, 72, 72], [255, 196, 70], [96, 210, 120], [90, 150, 255]];
            _c.lw = 2;
            for (var _q = 0; _q < 4; _q++) {
                var _qa = _q * pi / 2 + pi / 4;
                _c.stroke = unv_cx_solid(_rays[_q], 0.95); unv__p_begin(_c); unv__p_move(_c, cos(_qa) * _r * 0.3, sin(_qa) * _r * 0.3); unv__p_line(_c, cos(_qa) * _r * 0.92, sin(_qa) * _r * 0.92); unv__p_stroke(_c);
            }
            var _dx = _r * 0.42, _dy = _r * 0.62;
            _c.fill = unv_cx_solid(unv__mix_rgb(_T.fold, [150, 180, 220], 0.4)); unv__p_begin(_c); unv__p_move(_c, 0, -_dy); unv__p_line(_c, _dx, 0); unv__p_line(_c, 0, _dy); unv__p_line(_c, -_dx, 0); unv__p_close(_c); unv__p_fill(_c);
            _c.fill = unv_cx_solid([255, 255, 255]); unv__p_begin(_c); unv__p_move(_c, 0, -_dy); unv__p_line(_c, _dx, 0); unv__p_line(_c, 0, 0); unv__p_close(_c); unv__p_fill(_c);
            _c.fill = unv_cx_solid([120, 140, 190], 0.9); unv__p_begin(_c); unv__p_move(_c, 0, _dy); unv__p_line(_c, -_dx, 0); unv__p_line(_c, 0, 0); unv__p_close(_c); unv__p_fill(_c);
            _c.stroke = unv_cx_solid(_T.rim); _c.lw = 1.2; unv__p_begin(_c); unv__p_move(_c, 0, -_dy); unv__p_line(_c, _dx, 0); unv__p_line(_c, 0, _dy); unv__p_line(_c, -_dx, 0); unv__p_close(_c); unv__p_stroke(_c);
            break;
        default: _done = false;
    }
    _c.cap = 0;
    unv_cx_restore(_c);
    return _done;
}
