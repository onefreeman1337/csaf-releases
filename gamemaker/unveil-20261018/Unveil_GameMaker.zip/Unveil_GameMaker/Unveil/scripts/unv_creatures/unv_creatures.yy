{
  "$GMScript": "v1",
  "%Name": "unv_creatures",
  "name": "unv_creatures",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}