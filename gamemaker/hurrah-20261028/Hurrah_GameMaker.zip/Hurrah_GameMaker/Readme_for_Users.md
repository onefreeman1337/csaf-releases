# Hurrah - Celebration Effects for GameMaker

**Hurrah is a celebration and reward-feedback system for GameMaker (2024.14, tested on runtime 2024.14.4.268) in pure GML,
with a runnable demo room.** One call fires a whole moment: two-sided paper confetti that tumbles and flutters, curling
streamers, balloons that rise on swaying strings, coins and gems that spin, pile up or fly into your score counter, rays,
rings, starbursts and sparkles, falling ticker tape, sequins, petals and feathers, and ribbon, scroll, bunting and rosette
banners drawn behind your own words. 43 piece forms in 9 families, 6 palettes (or your own colours), 8 ready
moments (level up, win, new record, chest, achievement, birthday, jackpot, petals). Every piece is drawn by the package;
no image files ship. One commercial licence covers all your games.

Every picture on the store page was rendered by this package in a blank GameMaker project.

---

## What is in the package

| | |
| --- | --- |
| `hur_core` | the world, the 43 forms and their outlines, the palettes, the moments, every piece's motion, the budget, events - **no drawing calls** |
| `hur_draw` | drawing: every piece written into vertex buffers, five submits a frame whatever the count; single pieces for icons and menus |
| `hur_demo` + `obj_hur_demo` + `rm_hur_demo` | THE PARTY ROOM: every moment on a key, coins that fly into a score counter, an attract mode |
| `hur_selftest` | the in-engine test suite (run the demo with `-selftest`) |
| 4 fonts | `fnt_hurrah_display_s/_l` (from Titan One) and `fnt_hurrah_body_s/_l` (Barlow Condensed SemiBold), both SIL OFL 1.1; licences and notices in `Hurrah/fonts/` |

## Install

1. In GameMaker: **Tools > Import Local Package**, choose `Hurrah.yymps`, **Add All**, **Import**.
2. Run the project with `rm_hur_demo` first in the room order to open THE PARTY ROOM.

The raw `.gml` sources are also in the `Hurrah/` folder of this download, readable without GameMaker.

## Quickstart

```gml
// Create - one world for every celebration in the room; coins pile and confetti settles on the floor line
my_party = hur_world_create({ floor: room_height - 40 });
my_score = 0;
```

```gml
// Step - move every piece; count the coins that reached the counter
hur_world_step(my_party);
var my_events = hur_world_events(my_party);
for (var my_i = 0; my_i < array_length(my_events); my_i++) if (my_events[my_i].type == "arrive") my_score += my_events[my_i].value;
```

```gml
// Draw GUI - every live piece, in five vertex-buffer submits
hur_world_draw(my_party);
```

```gml
// Clean Up - free the world's vertex buffers
hur_world_free(my_party);
```

Then, wherever something good happens:

```gml
hur_fire(my_party, "levelup", room_width / 2, 220, 1, { text: "LEVEL UP!" });
hur_shower_to(my_party, chest_x, chest_y, 846, 30, 30, { value: 10 });
hur_banner(my_party, "NEW RECORD", room_width / 2, 160, "banner_scroll");
```

`hur_shower_to` throws the coins up out of the chest, then flies each one into (846, 30); every coin reports an `"arrive"`
event carrying its value as it lands, so your counter rises coin by coin. Coins sent this way are never thinned by the
budget: each one carries value your game counts.

## The moments

| kind | what it fires |
| --- | --- |
| `levelup` | rays, a flash, a starburst, sparkles and a confetti burst; with `text`, a ribbon banner under it |
| `win` | two confetti cannons from the bottom corners with streamers, ticker tape falling from the top; with `text`, a ribbon banner |
| `record` | rays, a ring, sparkles, a starburst and falling sequins; with `text`, a scroll |
| `chest` | a flash, rays and sparkles, then coins and gems burst out (they pile on the floor, or fly to `tx`, `ty`) |
| `achievement` | a rosette with your `text` (default `"1st"`), rays, sparkles, a ring and confetti |
| `birthday` | balloons released from below, streamers and confetti; with `text`, bunting across the top (one letter per flag up to 12) |
| `jackpot` | rays, a flash, a starburst and a long shower of coins and gems |
| `petals` | petals and feathers drifting down, sparkles |

The building blocks fire on their own too: `popper`, `cannon`, `fall`, `shower`, `balloons`, `streamers`, `burst`, `banner`.

## The forms

| family | forms |
| --- | --- |
| confetti | `square`, `strip`, `dot`, `triangle`, `star`, `heart`, `diamond`, `flower`, `crescent`, `spiral` |
| streamer | `ribbon`, `serpentine`, `zigzag`, `twist`, `tinsel` |
| balloon | `balloon_round`, `balloon_oval`, `balloon_heart`, `balloon_star`, `balloon_long` |
| coin | `coin_gold`, `coin_silver`, `coin_copper` |
| gem | `gem_round`, `gem_emerald`, `gem_heart`, `gem_marquise`, `gem_pear` |
| burst | `rays`, `ring`, `starburst`, `sparkle`, `flash` |
| fall | `ticker`, `sequin`, `petal`, `feather` |
| banner | `banner_ribbon`, `banner_scroll`, `banner_bunting`, `banner_rosette` |
| launcher | `popper`, `cannon` |

Paper is drawn with two faces: as a piece tumbles, the face it shows decides its colour, how squarely it faces you decides
its light, and foil catches a glint as it turns flat. Light (rays, rings, flashes, sparks, sparkles) is drawn additive.

## Palettes

`party`, `gold`, `royal`, `pastel`, `neon`, `sakura`; or pass your own colours: `{ theme: [c_red, c_orange, c_yellow] }`.
Set a world's palette with the `theme` option of `hur_world_create`, or one call's with the `theme` option of `hur_fire`.

## Reference

**The world**
- `hur_world_create([options])` -> a world. Options: `seed`, `theme`, `budget` (default 400), `floor` (a y, or undefined), `bounds` (`[x0, y0, x1, y1]`, default the room)
- `hur_world_step(world, [dt])` - dt in seconds, default this frame's `delta_time`, capped at 0.05
- `hur_world_draw(world, [ox], [oy])`; `hur_world_free(world)`
- `hur_world_pause(world, paused)`, `hur_world_clear(world)`, `hur_world_count(world)`
- `hur_world_events(world)` -> `[{ type: "arrive", id, form, value, x, y }, { type: "done", id }]`

**Firing**
- `hur_fire(world, kind, x, y, [strength], [options])` -> a handle, or -1 when refused. `strength` 0.25..3. Options: `theme`, `dir` (degrees, 90 = up), `spread`, `forms`, `form`, `text`, `tx`, `ty`, `count`, `value`, `prop` (true draws the popper or cannon), `width`, `hold`, `font`
- `hur_banner(world, text, x, y, [form], [options])` -> a handle. Options: `theme`, `width`, `hold` (seconds, default 2.6), `font`, `strength`
- `hur_shower_to(world, x, y, tx, ty, count, [options])` -> a handle. Options: `forms`, `gems` (0..1), `value`, `theme`

**The catalogue**
- `hur_forms([family])`, `hur_families()`, `hur_form_family(form)`, `hur_form_title(form)`, `hur_form_shape(form, [lo])`
- `hur_themes()`, `hur_theme(name)`, `hur_presets()`, `hur_kinds()`
- `hur_piece_draw(form, x, y, size, [angle], [phase], [theme], [foil])` - one still piece for an icon or a menu (`phase` defaults to the form's best moment, `foil` true draws confetti, falls and streamers in foil); returns false for a name that is not a form
- `hur_form_peak(form)` - the phase at which a form shows best in a still drawing
- `hur_rng(seed)`, `hur_rand(generator)` - the seeded generator the world uses

Every drawing call blends alpha as "over" (a translucent piece keeps an opaque surface opaque) and hands back your blend,
colour, alpha, font, alignment and world matrix.

## Performance (measured, two suite runs, Windows VM build)

- One moment at its busiest: stepping 5.4 ms to 7.3 ms, drawing 6.5 ms to 10 ms at worst across the eight.
- A world full to the default budget (400 pieces): stepping 3.3 ms to 4.4 ms, drawing 14 ms to 18 ms a frame on average.
- A world full to 700 pieces: stepping 4.8 ms to 5.5 ms, drawing 16 ms to 19 ms a frame on average.

Pieces beyond the budget are thinned (never queued), so a frame's cost has a ceiling you choose. These figures are the VM
on a busy Windows machine; YYC was not built.

## Limits, stated

- 2D only. Pieces are drawn into the space you fire in (room or GUI); pass an offset to `hur_world_draw` to move them.
- No sound ships. Watch `hur_world_events` (and the handles `hur_fire` returns) to play your own.
- Built and tested on Windows (VM). HTML5, mobile and YYC were not built.
- GML cannot be unit-tested outside the engine. Every figure above came from real Igor-built executables running the
  package's own suite (339 assertions) and a fresh install of the package into a blank project.

## Globals

Hurrah keeps four globals, all namespaced: `global.hur_vb` and `global.hur_vn` (the vertex buffer being filled and its
count), `global.hur_vtotal` (vertices written, for profiling) and `global.hur_stage` (the suite's progress).

## Licence and AI disclosure

One commercial licence, unlimited games: see `LICENSE.txt`. The fonts are SIL OFL 1.1 (`Hurrah/fonts/`).
Hurrah was written with AI assistance (code and the drawings it makes). Copyright (c) 2026 Core Systems Asset Factory.
