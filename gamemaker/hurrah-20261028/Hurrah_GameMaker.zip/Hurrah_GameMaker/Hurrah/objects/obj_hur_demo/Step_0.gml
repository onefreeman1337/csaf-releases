/// @description Run the party room one frame.
if (is_struct(demo)) hur_demo_step(demo);
