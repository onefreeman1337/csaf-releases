/// @description THE PARTY ROOM - Hurrah's demo room: every moment on a key, coins that fly into the score counter.
/// Run with -selftest it is the headless test suite instead (writes hur_selftest.json and exits).
/// The crash handler is installed FIRST, and every variable a later event reads is declared ABOVE the early exits:
/// Clean Up always runs, even when Create leaves early.
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("hur_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.hur_stage) + ": " + string(_ex.message) + " | " + string(_ex.stacktrace));
    file_text_close(_f);
    game_end();
});
global.hur_stage = 0;
demo = undefined;
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";
if (string_pos("-selftest", _args) > 0) { global.hur_stage = 1; hur_selftest_write(hur_selftest_run()); game_end(); exit; }
demo = hur_demo_create();
