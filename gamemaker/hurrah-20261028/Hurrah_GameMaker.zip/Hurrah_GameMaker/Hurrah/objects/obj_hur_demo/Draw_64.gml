/// @description Draw the party room (GUI layer).
if (is_struct(demo)) hur_demo_draw(demo);
