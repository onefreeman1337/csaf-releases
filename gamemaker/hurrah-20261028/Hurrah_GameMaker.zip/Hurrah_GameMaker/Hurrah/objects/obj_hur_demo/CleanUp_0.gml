/// @description Free the world's vertex buffers.
if (variable_instance_exists(id, "demo") && is_struct(demo)) hur_demo_free(demo);
