/// hur_draw.gml - Hurrah's drawing. Every piece is built from triangles written into one vertex buffer per layer and drawn in
/// four submits a frame (bursts behind, balloons, the middle layer of streamers, coins, gems, banners and launchers, then
/// confetti, falls and sparks in front), so hundreds of pieces cost four draw calls. Paper is drawn with two faces: the
/// tumble foreshortens it, the face it shows decides its colour, how squarely it faces you decides its light, and foil
/// catches a glint as it turns flat. Nothing here loads an image: the package ships no sprites.
///
/// Public functions: hur_world_draw, hur_world_free, hur_piece_draw.
///
/// Hurrah - Celebration Effects for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

// ------------------------------------------------------------------------------------------------ the vertex batch

/// @function hur__fmt()
/// @description Internal. The vertex format (2D position + colour), made once.
function hur__fmt() {
    static _f = undefined;
    if (is_undefined(_f)) { vertex_format_begin(); vertex_format_add_position(); vertex_format_add_colour(); _f = vertex_format_end(); }
    return _f;
}

/// @function hur__over()
/// @description Internal. Colour blends normally, alpha as "over", so a translucent piece keeps an opaque surface opaque
/// (wing doctrine s15). Always inside gpu_push_state / gpu_pop_state.
function hur__over() { gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha); }

/// @function hur__light()
/// @description Internal. Light adds to what is behind it (rays, rings, flashes, sparks), while alpha still blends as "over"
/// so an opaque surface stays opaque. Always inside gpu_push_state / gpu_pop_state.
function hur__light() { gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_one, bm_one, bm_inv_src_alpha); }

/// @function hur__vb_begin(vb)
/// @description Internal. Start filling a vertex buffer; the vertex counter resets.
function hur__vb_begin(_vb) { global.hur_vb = _vb; global.hur_vn = 0; vertex_begin(_vb, hur__fmt()); }

/// @function hur__vb_end()
/// @description Internal. Close the buffer and draw it (a buffer with no vertices is not submitted). Returns the count.
function hur__vb_end() {
    var _vb = global.hur_vb, _n = global.hur_vn;
    vertex_end(_vb);
    if (_n > 0) vertex_submit(_vb, pr_trianglelist, -1);
    global.hur_vtotal = (variable_global_exists("hur_vtotal") ? global.hur_vtotal : 0) + _n;
    return _n;
}

/// @function hur__tri(x1, y1, c1, x2, y2, c2, x3, y3, c3, alpha)
/// @description Internal. One triangle with a colour per corner.
function hur__tri(_x1, _y1, _c1, _x2, _y2, _c2, _x3, _y3, _c3, _a) {
    var _vb = global.hur_vb;
    vertex_position(_vb, _x1, _y1); vertex_colour(_vb, _c1, _a);
    vertex_position(_vb, _x2, _y2); vertex_colour(_vb, _c2, _a);
    vertex_position(_vb, _x3, _y3); vertex_colour(_vb, _c3, _a);
    global.hur_vn += 3;
}

/// @function hur__tri_a(x1, y1, c1, a1, x2, y2, c2, a2, x3, y3, c3, a3)
/// @description Internal. One triangle with a colour AND an alpha per corner (glows, rays, trails).
function hur__tri_a(_x1, _y1, _c1, _a1, _x2, _y2, _c2, _a2, _x3, _y3, _c3, _a3) {
    var _vb = global.hur_vb;
    vertex_position(_vb, _x1, _y1); vertex_colour(_vb, _c1, _a1);
    vertex_position(_vb, _x2, _y2); vertex_colour(_vb, _c2, _a2);
    vertex_position(_vb, _x3, _y3); vertex_colour(_vb, _c3, _a3);
    global.hur_vn += 3;
}

/// @function hur__quad(x1, y1, c1, x2, y2, c2, x3, y3, c3, x4, y4, c4, alpha)
/// @description Internal. A quad, corners in order round it, a colour per corner.
function hur__quad(_x1, _y1, _c1, _x2, _y2, _c2, _x3, _y3, _c3, _x4, _y4, _c4, _a) {
    hur__tri(_x1, _y1, _c1, _x2, _y2, _c2, _x3, _y3, _c3, _a);
    hur__tri(_x1, _y1, _c1, _x3, _y3, _c3, _x4, _y4, _c4, _a);
}

/// @function hur__rect(x0, y0, x1, y1, col, alpha)
/// @description Internal. An axis-aligned rectangle in one colour.
function hur__rect(_x0, _y0, _x1, _y1, _c, _a) { hur__quad(_x0, _y0, _c, _x1, _y0, _c, _x1, _y1, _c, _x0, _y1, _c, _a); }

/// @function hur__ellipse(x, y, rx, ry, cIn, cOut, alpha, [segments], [aIn], [aOut])
/// @description Internal. A filled ellipse as a fan: cIn at the centre, cOut at the rim (alpha per ring when given).
function hur__ellipse(_x, _y, _rx, _ry, _ci, _co, _a, _m = 0, _ai = -1, _ao = -1) {
    var _n = (_m > 0) ? _m : clamp(floor(max(abs(_rx), abs(_ry)) * 0.7) + 10, 10, 40);
    var _A = (_ai < 0) ? _a : _ai, _O = (_ao < 0) ? _a : _ao;
    var _px = _x + _rx, _py = _y;
    for (var _k = 1; _k <= _n; _k++) {
        var _t = _k / _n * pi * 2, _qx = _x + cos(_t) * _rx, _qy = _y + sin(_t) * _ry;
        hur__tri_a(_x, _y, _ci, _A, _px, _py, _co, _O, _qx, _qy, _co, _O);
        _px = _qx; _py = _qy;
    }
}

/// @function hur__ring(x, y, r0, r1, c0, c1, a0, a1)
/// @description Internal. An annulus from r0 (colour c0, alpha a0) to r1 (c1, a1).
function hur__ring(_x, _y, _r0, _r1, _c0, _c1, _a0, _a1) {
    var _n = clamp(floor(_r1 * 0.5) + 16, 16, 64);
    for (var _k = 0; _k < _n; _k++) {
        var _t0 = _k / _n * pi * 2, _t1 = (_k + 1) / _n * pi * 2;
        var _ax = cos(_t0), _ay = sin(_t0), _bx = cos(_t1), _by = sin(_t1);
        hur__tri_a(_x + _ax * _r0, _y + _ay * _r0, _c0, _a0, _x + _ax * _r1, _y + _ay * _r1, _c1, _a1, _x + _bx * _r1, _y + _by * _r1, _c1, _a1);
        hur__tri_a(_x + _ax * _r0, _y + _ay * _r0, _c0, _a0, _x + _bx * _r1, _y + _by * _r1, _c1, _a1, _x + _bx * _r0, _y + _by * _r0, _c0, _a0);
    }
}

/// @function hur__bar(x1, y1, x2, y2, w, c1, c2, alpha)
/// @description Internal. A bar of width w between two points, shading from c1 to c2 along it.
function hur__bar(_x1, _y1, _x2, _y2, _w, _c1, _c2, _a) {
    var _dx = _x2 - _x1, _dy = _y2 - _y1, _l = max(0.0001, sqrt(_dx * _dx + _dy * _dy)), _nx = -_dy / _l * _w / 2, _ny = _dx / _l * _w / 2;
    hur__quad(_x1 + _nx, _y1 + _ny, _c1, _x2 + _nx, _y2 + _ny, _c2, _x2 - _nx, _y2 - _ny, _c2, _x1 - _nx, _y1 - _ny, _c1, _a);
}

/// @function hur__star(x, y, ro, ri, points, rot, cIn, cOut, alpha)
/// @description Internal. A star as a fan from its centre.
function hur__star(_x, _y, _ro, _ri, _p, _rot, _ci, _co, _a) {
    var _n = _p * 2, _px = 0, _py = 0;
    for (var _k = 0; _k <= _n; _k++) {
        var _t = _rot + _k / _n * pi * 2, _r = (_k mod 2 == 0) ? _ro : _ri, _qx = _x + cos(_t) * _r, _qy = _y + sin(_t) * _r;
        if (_k > 0) hur__tri(_x, _y, _ci, _px, _py, _co, _qx, _qy, _co, _a);
        _px = _qx; _py = _qy;
    }
}

/// @function hur__atlas_forms()
/// @description Internal. The forms the paper atlas holds, in cell order.
function hur__atlas_forms() { return ["square", "strip", "dot", "triangle", "star", "heart", "diamond", "flower", "crescent", "spiral", "ticker", "sequin", "petal"]; }

/// @function hur__shape_tris(S, x0, y0, ux, uy, vx, vy, cen, rim, alpha)
/// @description Internal. A unit outline's triangles written into the open buffer through the affine map
/// point = (x0, y0) + u * (ux, uy) + v * (vx, vy): fans from their centre, strips as quads between their rails.
function hur__shape_tris(_S, _x0, _y0, _ux, _uy, _vx, _vy, _cen, _rim, _a) {
    var _xs = _S.xs, _ys = _S.ys, _n = array_length(_xs);
    if (_S.kind == "fan") {
        var _cx = _x0 + _S.cx * _ux + _S.cy * _vx, _cy = _y0 + _S.cx * _uy + _S.cy * _vy;
        var _px = _x0 + _xs[_n - 1] * _ux + _ys[_n - 1] * _vx, _py = _y0 + _xs[_n - 1] * _uy + _ys[_n - 1] * _vy;
        for (var _k = 0; _k < _n; _k++) {
            var _qx = _x0 + _xs[_k] * _ux + _ys[_k] * _vx, _qy = _y0 + _xs[_k] * _uy + _ys[_k] * _vy;
            hur__tri(_cx, _cy, _cen, _px, _py, _rim, _qx, _qy, _rim, _a);
            _px = _qx; _py = _qy;
        }
    } else {
        var _xs2 = _S.xs2, _ys2 = _S.ys2, _last = _S.closed ? _n : _n - 1;
        for (var _k = 0; _k < _last; _k++) {
            var _j = (_k + 1) mod _n;
            hur__quad(_x0 + _xs[_k] * _ux + _ys[_k] * _vx, _y0 + _xs[_k] * _uy + _ys[_k] * _vy, _rim, _x0 + _xs[_j] * _ux + _ys[_j] * _vx, _y0 + _xs[_j] * _uy + _ys[_j] * _vy, _rim,
                      _x0 + _xs2[_j] * _ux + _ys2[_j] * _vx, _y0 + _xs2[_j] * _uy + _ys2[_j] * _vy, _cen, _x0 + _xs2[_k] * _ux + _ys2[_k] * _vx, _y0 + _xs2[_k] * _uy + _ys2[_k] * _vy, _cen, _a);
        }
    }
}

/// @function hur__atlas()
/// @description Internal. The paper atlas: every paper form drawn once, white centre to grey rim, into one sprite (one
/// texture, so every paper piece in a frame batches into one draw). Made on first use and kept in global.hur_atlas for the
/// game's life; remade if the sprite was ever deleted. Drawn under an identity transform with the caller's matrix and scissor
/// handed back (a bake inside a draw pass inherits both - wing doctrine s19). { spr, cell, r[], idx{}, n }.
function hur__atlas() {
    if (variable_global_exists("hur_atlas") && is_struct(global.hur_atlas) && sprite_exists(global.hur_atlas.spr)) return global.hur_atlas;
    var _forms = hur__atlas_forms(), _n = array_length(_forms), _C = 40, _R = array_create(_n, 14), _idx = {};
    var _mw = matrix_get(matrix_world), _sc = gpu_get_scissor();
    matrix_set(matrix_world, matrix_build_identity());
    var _sf = surface_create(_n * _C, _C);
    surface_set_target(_sf);
    draw_clear_alpha(c_white, 0);
    gpu_push_state();
    hur__over();
    var _vb = vertex_create_buffer(), _ovb = variable_global_exists("hur_vb") ? global.hur_vb : undefined, _ovn = variable_global_exists("hur_vn") ? global.hur_vn : 0;
    hur__vb_begin(_vb);
    for (var _k = 0; _k < _n; _k++) {
        var _S = hur_form_shape(_forms[_k], false), _ext = 0.01;
        for (var _i = 0; _i < array_length(_S.xs); _i++) _ext = max(_ext, abs(_S.xs[_i]), abs(_S.ys[_i]));
        _R[_k] = min(14, (_C / 2 - 2) / _ext);
        _idx[$ _forms[_k]] = _k;
        hur__shape_tris(_S, _k * _C + _C / 2, _C / 2, _R[_k], 0, 0, _R[_k], c_white, make_colour_rgb(214, 214, 214), 1);
    }
    hur__vb_end();
    vertex_delete_buffer(_vb);
    global.hur_vb = _ovb; global.hur_vn = _ovn;
    gpu_pop_state();
    surface_reset_target();
    var _spr = sprite_create_from_surface(_sf, 0, 0, _n * _C, _C, false, false, 0, 0);
    surface_free(_sf);
    matrix_set(matrix_world, _mw);
    gpu_set_scissor(_sc);
    global.hur_atlas = { spr: _spr, cell: _C, r: _R, idx: _idx, n: _n };
    return global.hur_atlas;
}

/// @function hur__draw_paper_sprite(P, ox, oy, A)
/// @description Internal. A paper piece as ONE draw_sprite_general call from the atlas: scaled across by its size, down by
/// its tumble (the local y axis, before the turn), turned by its spin about its own centre, tinted by the face it shows with
/// the light and the foil glint folded into the tint. Returns false when the atlas does not hold the form.
function hur__draw_paper_sprite(_P, _ox, _oy, _A) {
    if (!variable_struct_exists(_A.idx, _P.form)) return false;
    var _k = _A.idx[$ _P.form];
    var _c = cos(_P.ph), _fs = abs(_c), _base = (_c >= 0) ? _P.col : _P.col2, _kl = 0.62 + 0.44 * _fs;
    var _lit = make_colour_rgb(min(255, colour_get_red(_base) * _kl), min(255, colour_get_green(_base) * _kl), min(255, colour_get_blue(_base) * _kl));
    var _gl = _P.foil ? clamp((_fs - 0.86) / 0.14, 0, 1) * 0.85 : clamp((_fs - 0.96) / 0.04, 0, 1) * 0.3;
    var _tint = merge_colour(_lit, c_white, 0.06 + _gl);
    var _s = _P.size / _A.r[_k], _sx = _s, _sy = _s * max(0.07, _fs), _h = _A.cell / 2;
    var _ang = -radtodeg(_P.rot), _ca = cos(_P.rot), _sa = -sin(_P.rot);
    var _dx = _h * _sx, _dy = _h * _sy;
    // the part turns about its top-left corner: place that corner so the CENTRE lands on the piece
    draw_sprite_general(_A.spr, 0, _k * _A.cell, 0, _A.cell, _A.cell, _P.x + _ox - (_dx * _ca + _dy * _sa), _P.y + _oy - (-_dx * _sa + _dy * _ca), _sx, _sy, _ang, _tint, _tint, _tint, _tint, _P.alpha);
    global.hur_sprites = (variable_global_exists("hur_sprites") ? global.hur_sprites : 0) + 1;
    return true;
}

/// @function hur__mul(col, f)
/// @description Internal. Each channel times f, clamped.
function hur__mul(_c, _f) { return make_colour_rgb(clamp(colour_get_red(_c) * _f, 0, 255), clamp(colour_get_green(_c) * _f, 0, 255), clamp(colour_get_blue(_c) * _f, 0, 255)); }

/// @function hur__ease_back(t)
/// @description Internal. Ease-out with a small overshoot (a banner or rosette popping into place).
function hur__ease_back(_t) { var _u = clamp(_t, 0, 1) - 1; return 1 + _u * _u * (2.4 * _u + 1.4); }

// ------------------------------------------------------------------------------------------------ the world

/// @function hur_world_draw(world, [ox], [oy])
/// @description Draw every live piece of a world, offset by (ox, oy). Call it from a Draw or Draw GUI event (whichever space
/// you fired in). Five vertex-buffer submits whatever the piece count (light behind, balloons, the middle layer, confetti,
/// light in front - the two light layers are drawn additive); the caller's blend, colour, alpha, font and alignment come
/// back unchanged.
function hur_world_draw(_W, _ox = 0, _oy = 0) {
    if (!hur__is_world(_W)) return;
    var _dx = is_numeric(_ox) ? real(_ox) : 0, _dy = is_numeric(_oy) ? real(_oy) : 0;
    if (!is_array(_W.vb)) _W.vb = [vertex_create_buffer(), vertex_create_buffer(), vertex_create_buffer(), vertex_create_buffer(), vertex_create_buffer()];
    var _sc = draw_get_colour(), _sa = draw_get_alpha(), _sf = draw_get_font(), _sh = draw_get_halign(), _sv = draw_get_valign();
    gpu_push_state();
    hur__over();
    var _np = array_length(_W.pieces);
    var _A = hur__atlas();
    for (var _L = 0; _L < 5; _L++) {
        if (_L == 0 || _L == 4) hur__light(); else hur__over();
        hur__vb_begin(_W.vb[_L]);
        for (var _i = 0; _i < _np; _i++) { var _P = _W.pieces[_i]; if (_P.layer == _L && !(_L == 3 && _P.fc == 0 && _P.pk != 2)) hur__draw_piece(_P, _dx, _dy, _W.time); }
        hur__vb_end();
        if (_L == 3) {
            // paper in front: one atlas sprite each, filtered (pieces are drawn smaller and larger than the atlas cell)
            gpu_set_texfilter(true);
            for (var _i = 0; _i < _np; _i++) { var _P = _W.pieces[_i]; if (_P.layer == 3 && _P.fc == 0 && _P.pk != 2 && _P.alpha > 0.004) if (!hur__draw_paper_sprite(_P, _dx, _dy, _A)) hur__draw_paper_fallback(_W, _P, _dx, _dy); }
        }
        if (_L == 2) for (var _i = 0; _i < _np; _i++) { var _P = _W.pieces[_i]; if (_P.fc == 6) hur__banner_text(_P, _dx, _dy); }
    }
    gpu_pop_state();
    draw_set_colour(_sc); draw_set_alpha(_sa); draw_set_font(_sf); draw_set_halign(_sh); draw_set_valign(_sv);
}

/// @function hur__draw_paper_fallback(W, P, ox, oy)
/// @description Internal. A paper piece the atlas does not hold, drawn through the vertex path in its own small buffer.
function hur__draw_paper_fallback(_W, _P, _ox, _oy) {
    var _vb = vertex_create_buffer();
    hur__vb_begin(_vb);
    hur__draw_piece(_P, _ox, _oy, _W.time);
    hur__vb_end();
    vertex_delete_buffer(_vb);
}

/// @function hur_world_free(world)
/// @description Free a world's vertex buffers (call in Clean Up). The world can still be stepped and drawn afterwards; it
/// makes new buffers on its next draw.
function hur_world_free(_W) {
    if (!hur__is_world(_W) || !is_array(_W.vb)) return;
    for (var _i = 0; _i < array_length(_W.vb); _i++) vertex_delete_buffer(_W.vb[_i]);
    _W.vb = undefined;
}

/// @function hur_form_peak(form)
/// @description The phase (0..1) at which a form shows best in a still drawing: a burst early, a ring a third of the way out, a
/// sparkle at its fullest; paper slightly turned. 0.05 for anything else, including a name that is not a form.
function hur_form_peak(_f) {
    switch (_f) {
        case "rays": return 0.12; case "ring": return 0.3; case "starburst": return 0.15; case "sparkle": return 0.5; case "flash": return 0.08;
    }
    return 0.05;
}

/// @function hur_piece_draw(form, x, y, size, [angle], [phase], [theme], [foil])
/// @description Draw one piece form, still, at (x, y): size is its radius in pixels (a banner's height is about 2 x size,
/// a streamer is about 4 x size long). angle in degrees, phase 0..1 picks the moment of its turn or burst (default: the form's
/// best moment, hur_form_peak), theme a palette
/// name or colour array, foil true draws confetti, falls and streamers in the palette's foil (it glints as it turns flat).
/// For icons, menus and reference sheets; the world draws moving pieces itself. Returns false for a name that is not a form.
function hur_piece_draw(_form, _x, _y, _size, _ang = 0, _ph = -1, _theme = "party", _foil = false) {
    if (hur_form_family(_form) == "" || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_size)) return false;
    var _s = clamp(real(_size), 0.5, 2000), _T = hur_theme(_theme), _f = hur_form_family(_form);
    var _phv = (is_numeric(_ph) && real(_ph) >= 0) ? clamp(real(_ph), 0, 1) : hur_form_peak(_form);
    var _P = { h: 0, form: _form, fam: _f, x: real(_x), y: real(_y), vx: 0, vy: 0, size: _s, col: _T.paper[0], col2: merge_colour(merge_colour(_T.paper[0], c_white, 0.38), c_black, 0.1),
               rot: degtorad(is_numeric(_ang) ? -real(_ang) : 0), vr: 0, ph: _phv * pi * 2, vph: 0, age: 0, life: 1, alpha: 1, rest: false, restT: 0, foil: false, seed: 3, layer: 2,
               tx: 0, ty: 0, homing: false, value: 0, delay: 0, age0: 0, fc: 0, pk: 0, swf: 2.4 };
    switch (_f) { case "streamer": _P.fc = 1; break; case "balloon": _P.fc = 2; break; case "coin": _P.fc = 3; break; case "gem": _P.fc = 4; break; case "burst": _P.fc = 5; break; case "banner": _P.fc = 6; break; case "launcher": _P.fc = 7; break; }
    _P.pk = (_form == "feather") ? 2 : ((_form == "petal") ? 1 : 0);
    switch (_f) {
        case "confetti": case "fall":
            _P.col = _T.paper[1 mod array_length(_T.paper)];
            _P.col2 = merge_colour(merge_colour(_P.col, c_white, 0.38), c_black, 0.1);
            if (_form == "sequin") { _P.foil = true; _P.col = _T.foil[0]; _P.col2 = merge_colour(_P.col, c_black, 0.35); }
            if (_form == "petal") { _P.col = merge_colour(_T.paper[0], c_white, 0.15); _P.col2 = merge_colour(_P.col, c_white, 0.35); }
            if (_form == "feather") { _P.col = merge_colour(_T.paper[3 mod array_length(_T.paper)], c_white, 0.55); _P.col2 = merge_colour(_P.col, c_black, 0.18); _P.rot += pi / 2; }
            break;
        case "streamer":
            var _N = 12, _len = _s * 4;
            _P.nx = array_create(_N); _P.ny = array_create(_N);
            for (var _k = 0; _k < _N; _k++) { var _u = _k / (_N - 1); _P.nx[_k] = _P.x - _len * 0.42 + _u * _len * 0.84; _P.ny[_k] = _P.y + sin(_u * pi * 1.6 + 0.4) * _len * 0.16; }
            _P.size = _s * 0.24; _P.twist = (_form == "twist") ? 1.4 : 0.6; _P.col = _T.paper[2 mod array_length(_T.paper)];
            _P.col2 = merge_colour(merge_colour(_P.col, c_white, 0.38), c_black, 0.1);
            if (_form == "tinsel") { _P.foil = true; _P.col = _T.foil[0]; _P.col2 = merge_colour(_P.col, c_black, 0.35); }
            break;
        case "balloon":
            _P.col = (_form == "balloon_star") ? _T.foil[0] : _T.paper[0]; _P.foil = (_form == "balloon_star"); _P.col2 = merge_colour(_P.col, c_black, 0.4);
            var _S = hur_form_shape(_form), _N2 = 7, _kn = _s * _S.knot;
            _P.nx = array_create(_N2); _P.ny = array_create(_N2);
            for (var _k = 0; _k < _N2; _k++) { _P.nx[_k] = _P.x + sin(_k * 0.9) * _s * 0.08; _P.ny[_k] = _P.y + _kn + _k * _s * 0.24; }
            break;
        case "gem": var _gc = hur__gem_colours(); _P.col = _gc[1]; break;
        case "burst": _P.life = 1; _P.age = (_phv > 0) ? _phv : ((_form == "rays" || _form == "flash") ? 0.3 : 0.4); _P.col = _T.glow; _P.col2 = _T.trim; if (_form == "starburst") { _P.col = _T.foil[0]; _P.vx = _s * 6; } break;
        case "banner": _P.text = "HURRAH!"; _P.T = _T; _P.size = _s / 32; _P.age = 0.8; _P.hold = 10; _P.life = 20; _P.width = _s * 9; _P.font = undefined; _P.rot = 0; break;
        case "launcher": _P.T = _T; _P.age = 0.12; _P.life = 10; _P.col = _T.paper[0]; _P.col2 = _T.trim; _P.rot = degtorad(is_numeric(_ang) ? real(_ang) : 0); break;   // a launcher aims in GameMaker degrees (90 = up)
    }
    if (_foil == true && (_P.fc == 0 || _P.fc == 1) && _P.pk == 0) { _P.foil = true; _P.col = _T.foil[0]; _P.col2 = merge_colour(_P.col, c_black, 0.35); }
    var _sc = draw_get_colour(), _sa = draw_get_alpha(), _sf = draw_get_font(), _sh = draw_get_halign(), _sv = draw_get_valign();
    gpu_push_state();
    if (_f == "burst") hur__light(); else hur__over();
    var _vb = vertex_create_buffer();
    hur__vb_begin(_vb);
    hur__draw_piece(_P, 0, 0, 0);
    hur__vb_end();
    if (_f == "banner") hur__banner_text(_P, 0, 0);
    vertex_delete_buffer(_vb);
    gpu_pop_state();
    draw_set_colour(_sc); draw_set_alpha(_sa); draw_set_font(_sf); draw_set_halign(_sh); draw_set_valign(_sv);
    return true;
}

/// @function hur__draw_piece(P, ox, oy, time)
/// @description Internal. Write one piece's triangles into the open buffer (a numeric switch on the family code).
function hur__draw_piece(_P, _ox, _oy, _time) {
    if (_P.alpha <= 0.004) return;
    switch (_P.fc) {
        case 0: if (_P.pk == 2) hur__draw_feather(_P, _ox, _oy); else hur__draw_paper(_P, _ox, _oy); break;
        case 1: hur__draw_streamer(_P, _ox, _oy); break;
        case 2: hur__draw_balloon(_P, _ox, _oy); break;
        case 3: hur__draw_coin(_P, _ox, _oy); break;
        case 4: hur__draw_gem(_P, _ox, _oy); break;
        case 5: hur__draw_burst(_P, _ox, _oy); break;
        case 6: hur__draw_banner(_P, _ox, _oy); break;
        case 7: hur__draw_launcher(_P, _ox, _oy); break;
    }
}

// ------------------------------------------------------------------------------------------------ paper

/// @function hur__draw_paper(P, ox, oy)
/// @description Internal. A flat piece from its unit outline: foreshortened by the tumble (about the piece's own x axis),
/// turned by its spin, scaled by its size. The face it shows (front or back) picks its colour, how squarely it faces you
/// picks its light, and foil catches a glint as it turns flat. Fan shapes from their centre (bright) to the rim; strip shapes
/// as quads between two rails. Under 14 px the outline's low-detail version is used. Vertex writes are inline: on the VM a
/// function call per triangle was most of the frame.
function hur__draw_paper(_P, _ox, _oy) {
    var _S = hur_form_shape(_P.form, _P.size < 14);
    if (is_undefined(_S)) return;
    var _c = cos(_P.ph), _fs = abs(_c), _base = (_c >= 0) ? _P.col : _P.col2, _kl = 0.6 + 0.42 * _fs;
    var _lit = make_colour_rgb(min(255, colour_get_red(_base) * _kl), min(255, colour_get_green(_base) * _kl), min(255, colour_get_blue(_base) * _kl));
    var _gl = _P.foil ? clamp((_fs - 0.86) / 0.14, 0, 1) * 0.85 : clamp((_fs - 0.96) / 0.04, 0, 1) * 0.3;
    var _cen = merge_colour(_lit, c_white, 0.1 + _gl), _rim = merge_colour(hur__mul(_lit, 0.84), c_white, _gl * 0.4);
    _fs = max(0.07, _fs);
    var _a = _P.alpha, _sz = _P.size, _cr = cos(_P.rot), _sr = sin(_P.rot), _x0 = _P.x + _ox, _y0 = _P.y + _oy;
    var _ux = _sz * _cr, _uy = _sz * _sr, _vx = -_fs * _sz * _sr, _vy = _fs * _sz * _cr;
    var _vb = global.hur_vb, _xs = _S.xs, _ys = _S.ys, _n = array_length(_xs);
    if (_S.kind == "fan") {
        var _cx = _x0 + _S.cx * _ux + _S.cy * _vx, _cy = _y0 + _S.cx * _uy + _S.cy * _vy;
        var _px = _x0 + _xs[_n - 1] * _ux + _ys[_n - 1] * _vx, _py = _y0 + _xs[_n - 1] * _uy + _ys[_n - 1] * _vy;
        for (var _k = 0; _k < _n; _k++) {
            var _qx = _x0 + _xs[_k] * _ux + _ys[_k] * _vx, _qy = _y0 + _xs[_k] * _uy + _ys[_k] * _vy;
            vertex_position(_vb, _cx, _cy); vertex_colour(_vb, _cen, _a);
            vertex_position(_vb, _px, _py); vertex_colour(_vb, _rim, _a);
            vertex_position(_vb, _qx, _qy); vertex_colour(_vb, _rim, _a);
            _px = _qx; _py = _qy;
        }
        global.hur_vn += _n * 3;
    } else {
        var _xs2 = _S.xs2, _ys2 = _S.ys2, _last = _S.closed ? _n : _n - 1;
        var _ax = _x0 + _xs[0] * _ux + _ys[0] * _vx, _ay = _y0 + _xs[0] * _uy + _ys[0] * _vy, _bx = _x0 + _xs2[0] * _ux + _ys2[0] * _vx, _by = _y0 + _xs2[0] * _uy + _ys2[0] * _vy;
        for (var _k = 0; _k < _last; _k++) {
            var _j = (_k + 1) mod _n;
            var _cx2 = _x0 + _xs[_j] * _ux + _ys[_j] * _vx, _cy2 = _y0 + _xs[_j] * _uy + _ys[_j] * _vy, _dx2 = _x0 + _xs2[_j] * _ux + _ys2[_j] * _vx, _dy2 = _y0 + _xs2[_j] * _uy + _ys2[_j] * _vy;
            var _cA = ((_k mod 2) == 0) ? _rim : hur__mul(_rim, 0.92);
            vertex_position(_vb, _ax, _ay); vertex_colour(_vb, _cA, _a);
            vertex_position(_vb, _cx2, _cy2); vertex_colour(_vb, _cA, _a);
            vertex_position(_vb, _dx2, _dy2); vertex_colour(_vb, _cen, _a);
            vertex_position(_vb, _ax, _ay); vertex_colour(_vb, _cA, _a);
            vertex_position(_vb, _dx2, _dy2); vertex_colour(_vb, _cen, _a);
            vertex_position(_vb, _bx, _by); vertex_colour(_vb, _cen, _a);
            _ax = _cx2; _ay = _cy2; _bx = _dx2; _by = _dy2;
        }
        global.hur_vn += _last * 6;
    }
    if (_P.pk == 1 && _sz >= 7) {   // a petal's centre vein
        hur__bar(_x0 - _vx * 0.55, _y0 - _vy * 0.55, _x0 + _vx * 0.85, _y0 + _vy * 0.85, max(1, _sz * 0.08), hur__mul(_rim, 0.88), hur__mul(_rim, 0.78), _a * 0.7);
    }
}

/// @function hur__draw_feather(P, ox, oy)
/// @description Internal. A feather: a curved quill, a vane on each side that widens then tapers to the tip, a soft
/// darker edge, and three barb splits.
function hur__draw_feather(_P, _ox, _oy) {
    var _a = _P.alpha, _cr = cos(_P.rot), _sr = sin(_P.rot), _sz = _P.size, _x0 = _P.x + _ox, _y0 = _P.y + _oy;
    var _N = 12, _qx = array_create(_N + 1), _qy = array_create(_N + 1);
    for (var _k = 0; _k <= _N; _k++) {
        var _u = -1.1 + _k / _N * 2.2, _bend = 0.12 * (1 - _u * _u);
        _qx[_k] = _x0 + (_u * _sz) * _cr - (_bend * _sz) * _sr; _qy[_k] = _y0 + (_u * _sz) * _sr + (_bend * _sz) * _cr;
    }
    var _ci = merge_colour(_P.col, c_white, 0.25), _co = _P.col2;
    for (var _side = -1; _side <= 1; _side += 2) {
        for (var _k = 1; _k < _N; _k++) {
            var _t0 = _k / _N, _t1 = (_k + 1) / _N;
            var _w0 = 0.36 * power(max(0, sin(pi * min(1, (_t0 - 0.08) / 0.92))), 0.7) * _sz, _w1 = 0.36 * power(max(0, sin(pi * min(1, (_t1 - 0.08) / 0.92))), 0.7) * _sz;
            if (_k + 1 == _N) _w1 = 0;
            var _nx = -_sr * _side, _ny = _cr * _side, _sweep = 0.22 * _sz;
            var _e0x = _qx[_k] + _nx * _w0 - _cr * _sweep, _e0y = _qy[_k] + _ny * _w0 - _sr * _sweep;
            var _e1x = _qx[_k + 1] + _nx * _w1 - _cr * _sweep, _e1y = _qy[_k + 1] + _ny * _w1 - _sr * _sweep;
            hur__quad(_qx[_k], _qy[_k], _ci, _qx[_k + 1], _qy[_k + 1], _ci, _e1x, _e1y, _co, _e0x, _e0y, _co, _a * 0.95);
        }
    }
    for (var _s3 = 0; _s3 < 3; _s3++) {
        var _k3 = 4 + _s3 * 2, _side3 = (_s3 mod 2 == 0) ? 1 : -1, _w3 = 0.34 * _sz;
        hur__bar(_qx[_k3], _qy[_k3], _qx[_k3] - _sr * _side3 * _w3 - _cr * 0.24 * _sz, _qy[_k3] + _cr * _side3 * _w3 - _sr * 0.24 * _sz, max(1, _sz * 0.05), hur__mul(_co, 0.9), _co, _a * 0.6);
    }
    for (var _k = 0; _k < _N; _k++) hur__bar(_qx[_k], _qy[_k], _qx[_k + 1], _qy[_k + 1], max(1, _sz * 0.07 * (1.3 - _k / _N)), hur__mul(_co, 0.8), hur__mul(_co, 0.8), _a);
}

// ------------------------------------------------------------------------------------------------ streamers

/// @function hur__draw_streamer(P, ox, oy)
/// @description Internal. A ribbon along the rope (Catmull-Rom, two points per segment): its width pinches where the twist
/// turns it edge-on and its colour flips to the back face; serpentine and zigzag ride a sideways offset; tinsel is a thin
/// strand with glints.
function hur__draw_streamer(_P, _ox, _oy) {
    var _N = array_length(_P.nx), _M = (_N - 1) * 2 + 1, _xs = array_create(_M), _ys = array_create(_M), _a = _P.alpha;
    for (var _k = 0; _k < _N - 1; _k++) {
        var _i0 = max(0, _k - 1), _i3 = min(_N - 1, _k + 2);
        for (var _s = 0; _s < 2; _s++) {
            var _t = _s / 2, _t2 = _t * _t, _t3 = _t2 * _t;
            _xs[_k * 2 + _s] = 0.5 * ((2 * _P.nx[_k]) + (-_P.nx[_i0] + _P.nx[_k + 1]) * _t + (2 * _P.nx[_i0] - 5 * _P.nx[_k] + 4 * _P.nx[_k + 1] - _P.nx[_i3]) * _t2 + (-_P.nx[_i0] + 3 * _P.nx[_k] - 3 * _P.nx[_k + 1] + _P.nx[_i3]) * _t3) + _ox;
            _ys[_k * 2 + _s] = 0.5 * ((2 * _P.ny[_k]) + (-_P.ny[_i0] + _P.ny[_k + 1]) * _t + (2 * _P.ny[_i0] - 5 * _P.ny[_k] + 4 * _P.ny[_k + 1] - _P.ny[_i3]) * _t2 + (-_P.ny[_i0] + 3 * _P.ny[_k] - 3 * _P.ny[_k + 1] + _P.ny[_i3]) * _t3) + _oy;
        }
    }
    _xs[_M - 1] = _P.nx[_N - 1] + _ox; _ys[_M - 1] = _P.ny[_N - 1] + _oy;
    var _w = _P.size * ((_P.form == "tinsel") ? 0.36 : ((_P.form == "serpentine") ? 0.42 : ((_P.form == "twist") ? 1.15 : 0.95)));
    var _lx = [], _ly = [], _rx = [], _ry = [], _cl = [];
    for (var _k = 0; _k < _M; _k++) {
        var _kp = max(0, _k - 1), _kn = min(_M - 1, _k + 1);
        var _tx = _xs[_kn] - _xs[_kp], _ty = _ys[_kn] - _ys[_kp], _tl = max(0.0001, sqrt(_tx * _tx + _ty * _ty));
        var _nx = -_ty / _tl, _ny = _tx / _tl;
        var _tw = cos(_P.twist * _k * ((_P.form == "twist") ? 1.3 : 0.45) + _P.ph), _hw = _w * max(0.1, abs(_tw));
        var _off = 0;
        // serpentine coils (a big slow wave on a narrow strip), zigzag folds (a triangle wave four points long)
        if (_P.form == "serpentine") { _off = sin(_k * 0.95 + _P.ph * 1.5) * _P.size * 1.9; _hw = _w; _tw = 1; }
        if (_P.form == "zigzag") { _off = (abs((_k mod 4) - 2) - 1) * _P.size * 1.5; }
        var _cx = _xs[_k] + _nx * _off, _cy = _ys[_k] + _ny * _off;
        array_push(_lx, _cx + _nx * _hw); array_push(_ly, _cy + _ny * _hw); array_push(_rx, _cx - _nx * _hw); array_push(_ry, _cy - _ny * _hw);
        var _face = (_tw >= 0) ? _P.col : _P.col2;
        array_push(_cl, merge_colour(hur__mul(_face, 0.62 + 0.4 * abs(_tw)), c_white, _P.foil ? clamp((abs(_tw) - 0.8) / 0.2, 0, 1) * 0.7 : 0));
    }
    for (var _k = 0; _k < _M - 1; _k++) {
        var _ca = _cl[_k], _cb = _cl[_k + 1];
        hur__quad(_lx[_k], _ly[_k], _ca, _lx[_k + 1], _ly[_k + 1], _cb, _rx[_k + 1], _ry[_k + 1], hur__mul(_cb, 0.86), _rx[_k], _ry[_k], hur__mul(_ca, 0.86), _a);
    }
    if (_P.form == "tinsel") {
        // tinsel: fine foil strands radiating from the core all along it, each catching the light in turn, plus glints
        for (var _k = 0; _k < _M; _k++) for (var _q = 0; _q < 3; _q++) {
            var _ang = _k * 2.4 + _q * 2.1 + _P.ph * 0.5, _len = _P.size * (1.1 + 0.5 * sin(_k * 1.7 + _q)), _lt = 0.5 + 0.5 * sin(_P.ph * 2 + _k + _q * 2);
            hur__bar(_xs[_k], _ys[_k], _xs[_k] + cos(_ang) * _len, _ys[_k] + sin(_ang) * _len, max(1, _P.size * 0.12), merge_colour(_P.col, c_white, _lt * 0.6), _P.col2, _a * 0.9);
        }
        for (var _k = 1; _k < _M; _k += 3) {
            var _gl = 0.5 + 0.5 * sin(_P.ph * 3 + _k * 1.3);
            if (_gl > 0.55) hur__star(_xs[_k], _ys[_k], _P.size * 1.1 * _gl, _P.size * 0.16, 4, _P.ph + _k, c_white, _P.col, _a * _gl);
        }
    }
}

// ------------------------------------------------------------------------------------------------ balloons

/// @function hur__draw_balloon(P, ox, oy)
/// @description Internal. The string first (a soft curve through its seven nodes), then the body as a fan lit from upper
/// left, a foil star in alternating facets, the tied knot, and a specular highlight.
function hur__draw_balloon(_P, _ox, _oy) {
    var _a = _P.alpha, _S = hur_form_shape(_P.form), _sz = _P.size, _cr = cos(_P.rot), _sr = sin(_P.rot), _x0 = _P.x + _ox, _y0 = _P.y + _oy;
    var _N = array_length(_P.nx), _sc = make_colour_rgb(206, 206, 216);
    for (var _k = 0; _k < _N - 1; _k++) hur__bar(_P.nx[_k] + _ox, _P.ny[_k] + _oy, _P.nx[_k + 1] + _ox, _P.ny[_k + 1] + _oy, max(1.2, _sz * 0.045), _sc, hur__mul(_sc, 0.85), _a * 0.85);
    var _n = array_length(_S.xs), _lit = merge_colour(_P.col, c_white, 0.3), _dk = merge_colour(_P.col, c_black, 0.3);
    var _cx = _x0 + _S.cx * _sz * _cr - _S.cy * _sz * _sr, _cy = _y0 + _S.cx * _sz * _sr + _S.cy * _sz * _cr;
    var _u = _S.xs[_n - 1] * _sz, _v = _S.ys[_n - 1] * _sz, _px = _x0 + _u * _cr - _v * _sr, _py = _y0 + _u * _sr + _v * _cr, _pa = arctan2(_S.ys[_n - 1], _S.xs[_n - 1]);
    for (var _k = 0; _k < _n; _k++) {
        _u = _S.xs[_k] * _sz; _v = _S.ys[_k] * _sz;
        var _qx = _x0 + _u * _cr - _v * _sr, _qy = _y0 + _u * _sr + _v * _cr, _qa = arctan2(_S.ys[_k], _S.xs[_k]);
        var _rimP = merge_colour(_dk, _P.col, 0.5 + 0.5 * cos(_pa + 2.3)), _rimQ = merge_colour(_dk, _P.col, 0.5 + 0.5 * cos(_qa + 2.3));
        if (_P.foil) { var _ff = (_k mod 2 == 0) ? 1.12 : 0.78; _rimP = hur__mul(_P.col, _ff); _rimQ = _rimP; }
        hur__tri(_cx, _cy, _P.foil ? merge_colour(_P.col, c_white, 0.45) : _lit, _px, _py, _rimP, _qx, _qy, _rimQ, _a * 0.97);
        _px = _qx; _py = _qy; _pa = _qa;
    }
    var _kx = _x0 - _sr * _S.knot * _sz, _ky = _y0 + _cr * _S.knot * _sz, _kw = max(2, _sz * 0.13);
    hur__tri(_kx, _ky - _kw * 0.6, _dk, _kx - _kw, _ky + _kw * 0.9, _dk, _kx + _kw, _ky + _kw * 0.9, hur__mul(_dk, 0.8), _a);
    var _hx = _x0 + (-0.36 * _cr + 0.44 * _sr) * _sz, _hy = _y0 + (-0.36 * _sr - 0.44 * _cr) * _sz;
    if (_P.form == "balloon_long") { _hx = _x0 + (-0.12 * _cr + 0.6 * _sr) * _sz; _hy = _y0 + (-0.12 * _sr - 0.6 * _cr) * _sz; }
    hur__ellipse(_hx, _hy, _sz * 0.16, _sz * 0.24, c_white, c_white, _a, 14, _a * 0.75, 0);
    hur__ellipse(_hx - _sz * 0.03, _hy - _sz * 0.05, _sz * 0.05, _sz * 0.07, c_white, c_white, _a * 0.9, 10);
}

// ------------------------------------------------------------------------------------------------ coins and gems

/// @function hur__draw_coin(P, ox, oy)
/// @description Internal. A coin spinning about its upright axis: the milled edge shows as a band beside the face as it
/// turns, the face is lit across a diagonal, a sunk ring and a raised star are struck in it, and a glint flashes as it faces
/// you square.
function hur__draw_coin(_P, _ox, _oy) {
    var _M = hur__metal(_P.form), _a = _P.alpha, _r = _P.size, _x0 = _P.x + _ox, _y0 = _P.y + _oy;
    var _w = cos(_P.ph), _rx = _r * max(0.06, abs(_w)), _th = _r * 0.17 * sin(_P.ph), _vb = global.hur_vb;
    var _segs = (_r < 16) ? 14 : 24;
    if (abs(_th) > 0.6) {
        var _ex = _x0 + _th;
        hur__ellipse(_ex, _y0, _rx, _r, _M.edge, hur__mul(_M.edge, 0.8), _a, 10);
        hur__rect(min(_x0, _ex), _y0 - _r, max(_x0, _ex), _y0 + _r, _M.edge, _a);
        for (var _k = -1; _k <= 1; _k++) { var _yy = _y0 + _k * _r * 0.5; hur__bar(min(_x0, _ex), _yy, max(_x0, _ex), _yy, max(1, _r * 0.06), _M.dark, _M.dark, _a * 0.45); }
    }
    var _px = _x0 + _rx, _py = _y0, _pc = merge_colour(_M.dark, _M.light, 0.5 + 0.5 * cos(2.36));
    for (var _k = 1; _k <= _segs; _k++) {
        var _t = _k / _segs * pi * 2, _qx = _x0 + cos(_t) * _rx, _qy = _y0 + sin(_t) * _r, _qc = merge_colour(_M.dark, _M.light, 0.5 + 0.5 * cos(_t + 2.36));
        vertex_position(_vb, _x0, _y0); vertex_colour(_vb, _M.face, _a);
        vertex_position(_vb, _px, _py); vertex_colour(_vb, _pc, _a);
        vertex_position(_vb, _qx, _qy); vertex_colour(_vb, _qc, _a);
        _px = _qx; _py = _qy; _pc = _qc;
    }
    global.hur_vn += _segs * 3;
    if (abs(_w) > 0.22) {
        var _f = abs(_w);
        hur__ellipse(_x0, _y0, _rx * 0.76, _r * 0.76, _M.face, hur__mul(_M.face, 0.86), _a, (_r < 16) ? 12 : 20);
        // the raised star, squeezed across by the same turn as the face it is struck in
        var _sx = _x0 - _f * _r * 0.04, _sy = _y0 - _r * 0.05, _mid = merge_colour(_M.face, _M.light, 0.5), _ppx = _sx, _ppy = _sy - _r * 0.46;
        for (var _k = 1; _k <= 10; _k++) {
            var _t = -pi / 2 + _k / 10 * pi * 2, _rr = ((_k mod 2) == 0) ? _r * 0.46 : _r * 0.2;
            var _qx = _sx + cos(_t) * _rr * _f, _qy = _sy + sin(_t) * _rr;
            vertex_position(_vb, _sx, _sy); vertex_colour(_vb, _M.light, _a);
            vertex_position(_vb, _ppx, _ppy); vertex_colour(_vb, _mid, _a);
            vertex_position(_vb, _qx, _qy); vertex_colour(_vb, _mid, _a);
            _ppx = _qx; _ppy = _qy;
        }
        global.hur_vn += 30;
    }
    if (abs(_w) > 0.9) { var _g = (abs(_w) - 0.9) / 0.1; hur__star(_x0 - _rx * 0.42, _y0 - _r * 0.42, _r * 0.7 * _g, _r * 0.08, 4, 0.3, c_white, _M.light, _a * _g); }
}

/// @function hur__draw_gem(P, ox, oy)
/// @description Internal. A cut gem: crown facets between the girdle and the table, each lit by its direction and the gem's
/// turn so the facets flash in sequence as it tumbles; the table lighter; a sparkle when a facet catches.
function hur__draw_gem(_P, _ox, _oy) {
    var _S = hur_form_shape(_P.form);
    if (is_undefined(_S)) return;
    var _a = _P.alpha, _sz = _P.size, _cr = cos(_P.rot), _sr = sin(_P.rot), _x0 = _P.x + _ox, _y0 = _P.y + _oy, _n = array_length(_S.xs);
    var _lt = merge_colour(_P.col, c_white, 0.55), _dk = merge_colour(_P.col, c_black, 0.5), _tb = merge_colour(_P.col, c_white, 0.32);
    var _gx = array_create(_n), _gy = array_create(_n), _tx = array_create(_n), _ty = array_create(_n);
    var _cx = _x0 + (_S.cx * _cr - _S.cy * _sr) * _sz, _cy = _y0 + (_S.cx * _sr + _S.cy * _cr) * _sz;
    for (var _k = 0; _k < _n; _k++) {
        var _u = _S.xs[_k] * _sz, _v = _S.ys[_k] * _sz;
        _gx[_k] = _x0 + _u * _cr - _v * _sr; _gy[_k] = _y0 + _u * _sr + _v * _cr;
        _tx[_k] = _cx + (_gx[_k] - _cx) * 0.52; _ty[_k] = _cy + (_gy[_k] - _cy) * 0.52;
    }
    for (var _k = 0; _k < _n; _k++) {
        var _j = (_k + 1) mod _n, _ang = arctan2((_gy[_k] + _gy[_j]) / 2 - _cy, (_gx[_k] + _gx[_j]) / 2 - _cx);
        var _s = 0.5 + 0.5 * cos(_ang * 2 + _P.ph * 3 + 0.8);
        var _fc = merge_colour(_dk, _lt, _s);
        hur__quad(_gx[_k], _gy[_k], hur__mul(_fc, 0.9), _gx[_j], _gy[_j], hur__mul(_fc, 0.9), _tx[_j], _ty[_j], _fc, _tx[_k], _ty[_k], _fc, _a);
    }
    for (var _k = 0; _k < _n; _k++) { var _j = (_k + 1) mod _n; hur__tri(_cx, _cy, merge_colour(_tb, c_white, 0.2), _tx[_k], _ty[_k], _tb, _tx[_j], _ty[_j], _tb, _a); }
    var _sp = sin(_P.ph * 2.3 + _P.seed);
    if (_sp > 0.7) { var _g = (_sp - 0.7) / 0.3; hur__star(_tx[0], _ty[0], _sz * 0.9 * _g, _sz * 0.1, 4, 0.2, c_white, _lt, _a * _g); }
}

// ------------------------------------------------------------------------------------------------ bursts

/// @function hur__draw_burst(P, ox, oy)
/// @description Internal. Rays wheel out behind and fade; a ring pushes out and thins; a flash blooms and dies; a starburst
/// spark trails its own streak; a sparkle swells and shrinks once.
function hur__draw_burst(_P, _ox, _oy) {
    var _x0 = _P.x + _ox, _y0 = _P.y + _oy, _t = clamp(_P.age / max(0.001, _P.life), 0, 1);
    switch (_P.form) {
        case "rays":
            var _e = 1 - power(1 - min(1, _t * 4), 3), _fa = power(1 - _t, 1.3) * 0.62, _R = _P.size * _e, _n = 14;
            for (var _k = 0; _k < _n; _k++) {
                var _ac = _P.rot + _k / _n * pi * 2 + _P.age * 0.35, _hw = pi / _n * 0.56, _rr = _R * ((_k mod 2 == 0) ? 1 : 0.72);
                var _c = (_k mod 2 == 0) ? _P.col : _P.col2;
                hur__tri_a(_x0, _y0, _c, _fa, _x0 + cos(_ac - _hw) * _rr, _y0 + sin(_ac - _hw) * _rr, _c, 0, _x0 + cos(_ac + _hw) * _rr, _y0 + sin(_ac + _hw) * _rr, _c, 0);
            }
            break;
        case "ring":
            var _r = _P.size * (1 - power(1 - _t, 3)), _w = 18 * (1 - _t) + 2, _ra = (1 - _t) * 0.9;
            hur__ring(_x0, _y0, max(0, _r - _w), _r, _P.col, _P.col, 0, _ra);
            hur__ring(_x0, _y0, _r, _r + max(1.5, _w * 0.18), c_white, _P.col, _ra, 0);
            break;
        case "flash":
            var _fr = _P.size * (0.6 + 0.5 * _t), _fa2 = power(1 - _t, 2) * 0.85;
            hur__ellipse(_x0, _y0, _fr, _fr, c_white, _P.col, _fa2, 28, _fa2, 0);
            break;
        case "starburst":
            var _sa = clamp((1 - _t) / 0.45, 0, 1), _ss = _P.size * (0.6 + 0.4 * _sa);
            var _sp = sqrt(_P.vx * _P.vx + _P.vy * _P.vy);
            if (_sp > 20) {
                var _tl = min(90, _sp * 0.11), _ux = -_P.vx / _sp, _uy = -_P.vy / _sp;
                hur__tri_a(_x0 - _uy * _ss * 0.42, _y0 + _ux * _ss * 0.42, _P.col, _sa * 0.7, _x0 + _uy * _ss * 0.42, _y0 - _ux * _ss * 0.42, _P.col, _sa * 0.7, _x0 + _ux * _tl, _y0 + _uy * _tl, _P.col, 0);
            }
            hur__ellipse(_x0, _y0, _ss * 1.6, _ss * 1.6, _P.col2, _P.col2, _sa * 0.35, 16, _sa * 0.35, 0);
            hur__star(_x0, _y0, _ss, _ss * 0.45, 5, _P.rot, merge_colour(_P.col, c_white, 0.6), _P.col, _sa);
            break;
        case "sparkle":
            if (_P.delay > 0) break;
            var _tt = clamp((_P.age - _P.age0) / max(0.001, _P.life - _P.age0), 0, 1), _e2 = sin(pi * _tt), _s2 = _P.size * _e2;
            if (_s2 < 0.5) break;
            hur__ellipse(_x0, _y0, _s2 * 0.9, _s2 * 0.9, _P.col, _P.col, _e2 * 0.3, 14, _e2 * 0.3, 0);
            hur__star(_x0, _y0, _s2, _s2 * 0.16, 4, _P.rot, c_white, _P.col, _e2);
            hur__star(_x0, _y0, _s2 * 0.5, _s2 * 0.1, 4, _P.rot + pi / 4, c_white, _P.col, _e2 * 0.8);
            break;
    }
}

// ------------------------------------------------------------------------------------------------ banners

/// @function hur__banner_font(P)
/// @description Internal. The font a banner letters in: the caller's, else the shipped display face.
function hur__banner_font(_P) { return (!is_undefined(_P.font) && font_exists(_P.font)) ? _P.font : fnt_hurrah_display_l; }

/// @function hur__banner_geom(P)
/// @description Internal. A banner's state this frame: { u (unfurl 0..1, with overshoot), f (fold 0..1), w, h, ts (text scale) }.
function hur__banner_geom(_P) {
    var _u = hur__ease_back(_P.age / 0.45), _f = clamp((_P.age - 0.45 - _P.hold) / 0.5, 0, 1);
    var _font = hur__banner_font(_P), _of = draw_get_font();
    draw_set_font(_font);
    var _tw = max(1, string_width(_P.text)), _thh = max(1, string_height("H"));
    draw_set_font(_of);
    var _h = 66 * _P.size, _ts = (_h * 0.62) / _thh;
    var _w = _tw * _ts + _h * 1.1;
    return { u: _u, f: _f, w: _w, h: _h, ts: _ts, tw: _tw * _ts };
}

/// @function hur__draw_banner(P, ox, oy)
/// @description Internal. The banner's cloth, paper or flags (its words are drawn after the layer, by hur__banner_text).
function hur__draw_banner(_P, _ox, _oy) {
    var _G = hur__banner_geom(_P), _T = _P.T, _x = _P.x + _ox, _y = _P.y + _oy, _a = _P.alpha * (1 - _G.f), _sy = 1 - _G.f * 0.7;
    if (_a <= 0.01) return;
    switch (_P.form) {
        case "banner_ribbon":
            var _hw = _G.w / 2 * max(0, _G.u), _h = _G.h * _sy, _hh = _h / 2;
            if (_G.u > 0.75) {
                var _ta = _a * clamp((_G.u - 0.75) / 0.25, 0, 1);
                for (var _sd = -1; _sd <= 1; _sd += 2) {
                    var _xi = _x + _sd * (_hw - _h * 0.5), _xo = _x + _sd * (_hw + _h * 1.15), _yt = _y - _hh + _h * 0.32, _yb = _y + _hh + _h * 0.32;
                    var _tc = hur__mul(_T.band, 0.8);
                    hur__quad(_xi, _yt, _tc, _xo, _yt, hur__mul(_tc, 0.92), _xo - _sd * _h * 0.36, (_yt + _yb) / 2, hur__mul(_tc, 0.85), _xi, _yb, _tc, _ta);
                    hur__tri(_xo, _yt, hur__mul(_tc, 0.92), _xo, _yb, hur__mul(_tc, 0.8), _xo - _sd * _h * 0.36, (_yt + _yb) / 2, hur__mul(_tc, 0.85), _ta);
                    hur__tri(_xi, _yt, _tc, _xi, _yb, _tc, _xi - _sd * 0.01, _yb, _tc, _ta);
                    hur__tri(_x + _sd * _hw, _y + _hh, _T.bandDark, _xi, _yb, _T.bandDark, _xi, _y + _hh, _T.bandDark, _ta);
                }
            }
            var _K = 16;
            for (var _k = 0; _k < _K; _k++) {
                var _x1 = _x - _hw + _k / _K * _hw * 2, _x2 = _x - _hw + (_k + 1) / _K * _hw * 2;
                var _w1 = sin(_k / _K * pi * 2 + _P.age * 2.2) * _h * 0.05, _w2 = sin((_k + 1) / _K * pi * 2 + _P.age * 2.2) * _h * 0.05;
                var _sh1 = 0.93 + 0.07 * cos(_k / _K * pi * 2 + _P.age * 2.2), _sh2 = 0.93 + 0.07 * cos((_k + 1) / _K * pi * 2 + _P.age * 2.2);
                var _c1 = hur__mul(_T.band, _sh1), _c2 = hur__mul(_T.band, _sh2);
                hur__quad(_x1, _y - _hh + _w1, hur__mul(_T.bandLight, _sh1), _x2, _y - _hh + _w2, hur__mul(_T.bandLight, _sh2), _x2, _y - _hh * 0.6 + _w2, _c2, _x1, _y - _hh * 0.6 + _w1, _c1, _a);
                hur__quad(_x1, _y - _hh * 0.6 + _w1, _c1, _x2, _y - _hh * 0.6 + _w2, _c2, _x2, _y + _hh * 0.62 + _w2, hur__mul(_c2, 0.9), _x1, _y + _hh * 0.62 + _w1, hur__mul(_c1, 0.9), _a);
                hur__quad(_x1, _y + _hh * 0.62 + _w1, hur__mul(_c1, 0.9), _x2, _y + _hh * 0.62 + _w2, hur__mul(_c2, 0.9), _x2, _y + _hh + _w2, _T.bandDark, _x1, _y + _hh + _w1, _T.bandDark, _a);
                var _tt = max(1.5, _h * 0.045);
                hur__quad(_x1, _y - _hh * 0.78 + _w1, _T.trim, _x2, _y - _hh * 0.78 + _w2, _T.trim, _x2, _y - _hh * 0.78 + _w2 + _tt, _T.trim, _x1, _y - _hh * 0.78 + _w1 + _tt, _T.trim, _a * 0.9);
                hur__quad(_x1, _y + _hh * 0.78 + _w1 - _tt, _T.trim, _x2, _y + _hh * 0.78 + _w2 - _tt, _T.trim, _x2, _y + _hh * 0.78 + _w2, _T.trim, _x1, _y + _hh * 0.78 + _w1, _T.trim, _a * 0.9);
            }
            break;
        case "banner_scroll":
            var _hw2 = (_G.w / 2 + _G.h * 0.2) * max(0.08, min(1, _G.u)), _h2 = _G.h * 1.12 * _sy, _paper = make_colour_rgb(246, 234, 204), _pd = make_colour_rgb(214, 192, 150);
            hur__quad(_x - _hw2, _y - _h2 / 2, _paper, _x + _hw2, _y - _h2 / 2, _paper, _x + _hw2, _y + _h2 / 2, _pd, _x - _hw2, _y + _h2 / 2, _pd, _a);
            hur__quad(_x - _hw2, _y - _h2 / 2, _pd, _x - _hw2 + _G.h * 0.3, _y - _h2 / 2, _paper, _x - _hw2 + _G.h * 0.3, _y + _h2 / 2, _paper, _x - _hw2, _y + _h2 / 2, _pd, _a * 0.8);
            hur__quad(_x + _hw2 - _G.h * 0.3, _y - _h2 / 2, _paper, _x + _hw2, _y - _h2 / 2, _pd, _x + _hw2, _y + _h2 / 2, _pd, _x + _hw2 - _G.h * 0.3, _y + _h2 / 2, _paper, _a * 0.8);
            var _rr = _G.h * 0.17, _rh = _h2 * 0.62 + _rr;
            for (var _sd2 = -1; _sd2 <= 1; _sd2 += 2) {
                var _rx = _x + _sd2 * _hw2, _rc = make_colour_rgb(232, 214, 176), _rd = make_colour_rgb(150, 118, 76);
                hur__quad(_rx - _rr, _y - _rh, _rd, _rx, _y - _rh, _rc, _rx, _y + _rh, _rc, _rx - _rr, _y + _rh, _rd, _a);
                hur__quad(_rx, _y - _rh, _rc, _rx + _rr, _y - _rh, _rd, _rx + _rr, _y + _rh, _rd, _rx, _y + _rh, _rc, _a);
                hur__ellipse(_rx, _y - _rh, _rr * 1.25, _rr * 0.42, _T.trim, hur__mul(_T.trim, 0.7), _a, 14);
                hur__ellipse(_rx, _y + _rh, _rr * 1.25, _rr * 0.42, _T.trim, hur__mul(_T.trim, 0.7), _a, 14);
            }
            break;
        case "banner_bunting":
            var _span = (_P.width > 0) ? _P.width : max(_G.w * 1.5, 420 * _P.size), _sag = 34 * _P.size, _x0b = _x - _span / 2;
            var _letters = (string_length(_P.text) > 0 && string_length(_P.text) <= 12), _nf = _letters ? string_length(_P.text) : 9;
            var _rope = make_colour_rgb(236, 226, 206), _nseg = 24;
            for (var _k = 0; _k < _nseg; _k++) {
                var _t1 = _k / _nseg, _t2 = (_k + 1) / _nseg;
                hur__bar(_x0b + _t1 * _span, _y + _sag * 4 * _t1 * (1 - _t1), _x0b + _t2 * _span, _y + _sag * 4 * _t2 * (1 - _t2), max(1.5, 2.6 * _P.size), _rope, hur__mul(_rope, 0.85), _a);
            }
            for (var _k = 0; _k < _nf; _k++) {
                var _d = clamp((_P.age - _k * 0.06) / 0.3, 0, 1);
                if (_d <= 0) continue;
                var _tc = (_k + 0.5) / _nf, _fw = _span / _nf * 0.42, _ta = _tc - _fw / _span, _tb = _tc + _fw / _span;
                var _ax = _x0b + _ta * _span, _ay = _y + _sag * 4 * _ta * (1 - _ta), _bx = _x0b + _tb * _span, _by = _y + _sag * 4 * _tb * (1 - _tb);
                var _fh = 58 * _P.size * hur__ease_back(_d) * _sy, _sway = sin(_P.age * 3 + _k * 1.7) * 4 * _P.size;
                var _cc = _T.paper[_k mod array_length(_T.paper)];
                hur__tri((_ax + _bx) / 2 + _sway, (_ay + _by) / 2 + _fh, hur__mul(_cc, 0.82), _ax, _ay, merge_colour(_cc, c_white, 0.15), _bx, _by, _cc, _a);
            }
            break;
        case "banner_rosette":
            var _R = 56 * _P.size * hur__ease_back(_P.age / 0.4) * _sy, _wob = sin(_P.age * 2.4) * 0.06;
            if (_R <= 1) break;
            for (var _sd3 = -1; _sd3 <= 1; _sd3 += 2) {
                var _ang = pi / 2 + _sd3 * 0.36 + _wob, _len = _R * 1.75, _tw2 = _R * 0.26;
                var _ex = _x + cos(_ang) * _len, _ey = _y + sin(_ang) * _len, _nx = -sin(_ang) * _tw2, _ny = cos(_ang) * _tw2;
                var _tcol = (_sd3 < 0) ? _T.band : hur__mul(_T.band, 0.85);
                hur__quad(_x + _nx, _y + _ny, _tcol, _ex + _nx, _ey + _ny, hur__mul(_tcol, 0.85), _ex + cos(_ang) * -_tw2 * 0.9, _ey + sin(_ang) * -_tw2 * 0.9, hur__mul(_tcol, 0.8), _x - _nx, _y - _ny, _tcol, _a);
                hur__tri(_x - _nx, _y - _ny, _tcol, _ex + cos(_ang) * -_tw2 * 0.9, _ey + sin(_ang) * -_tw2 * 0.9, hur__mul(_tcol, 0.8), _ex - _nx, _ey - _ny, hur__mul(_tcol, 0.85), _a);
            }
            var _np = 30;
            for (var _k = 0; _k < _np; _k++) {
                var _a0 = _k / _np * pi * 2 + _wob, _a1 = (_k + 1) / _np * pi * 2 + _wob, _am = (_a0 + _a1) / 2;
                var _pc = (_k mod 2 == 0) ? (_T.dark ? merge_colour(_T.paper[0], c_white, 0.25) : _T.bandLight) : (_T.dark ? _T.paper[0] : _T.band);
                hur__tri(_x + cos(_a0) * _R * 0.6, _y + sin(_a0) * _R * 0.6, _pc, _x + cos(_am) * _R, _y + sin(_am) * _R, merge_colour(_pc, c_white, 0.15), _x + cos(_a1) * _R * 0.6, _y + sin(_a1) * _R * 0.6, hur__mul(_pc, 0.82), _a);
                hur__tri(_x + cos(_a0) * _R * 0.6, _y + sin(_a0) * _R * 0.6, _pc, _x + cos(_a0) * _R * 0.94, _y + sin(_a0) * _R * 0.94, hur__mul(_pc, 0.85), _x + cos(_am) * _R, _y + sin(_am) * _R, merge_colour(_pc, c_white, 0.15), _a);
            }
            hur__ring(_x, _y, _R * 0.5, _R * 0.64, _T.trim, hur__mul(_T.trim, 0.78), _a, _a);
            hur__ellipse(_x, _y, _R * 0.52, _R * 0.52, merge_colour(_T.band, c_white, 0.12), hur__mul(_T.band, 0.88), _a, 28);
            break;
    }
}

/// @function hur__text(x, y, s, font, scale, col, alpha, shadow)
/// @description Internal. Centred text with a drop shadow, filtered while scaled (a 1 px stroke survives a scale below 1,
/// wing doctrine s3), restoring the caller's font, alignment, colour, alpha and filter.
function hur__text(_x, _y, _s, _font, _sc, _col, _al, _sh) {
    var _tf = gpu_get_texfilter(), _f = draw_get_font(), _hh = draw_get_halign(), _vv = draw_get_valign(), _c = draw_get_colour(), _a = draw_get_alpha();
    gpu_set_texfilter(true);
    draw_set_font(_font); draw_set_halign(fa_center); draw_set_valign(fa_middle);
    var _d = max(1, 3 * _sc);
    draw_set_colour(_sh); draw_set_alpha(_al * 0.55); draw_text_transformed(_x + _d * 0.4, _y + _d, _s, _sc, _sc, 0);
    draw_set_colour(_col); draw_set_alpha(_al); draw_text_transformed(_x, _y, _s, _sc, _sc, 0);
    draw_set_font(_f); draw_set_halign(_hh); draw_set_valign(_vv); draw_set_colour(_c); draw_set_alpha(_a);
    gpu_set_texfilter(_tf);
}

/// @function hur__banner_text(P, ox, oy)
/// @description Internal. A banner's words, once it has unfurled: centred on the ribbon or scroll, one letter per flag on
/// bunting (or below it when the words are long), in the middle of a rosette.
function hur__banner_text(_P, _ox, _oy) {
    var _G = hur__banner_geom(_P), _T = _P.T, _x = _P.x + _ox, _y = _P.y + _oy, _font = hur__banner_font(_P);
    var _ta = _P.alpha * (1 - _G.f) * clamp((_G.u - 0.7) / 0.3, 0, 1);
    if (_ta <= 0.01) return;
    switch (_P.form) {
        case "banner_ribbon": hur__text(_x, _y - _G.h * 0.02, _P.text, _font, _G.ts, _T.ink, _ta, _T.inkShadow); break;
        case "banner_scroll": hur__text(_x, _y, _P.text, _font, _G.ts * 0.92, merge_colour(_T.bandDark, c_black, 0.25), _ta, make_colour_rgb(255, 250, 236)); break;
        case "banner_bunting":
            var _span = (_P.width > 0) ? _P.width : max(_G.w * 1.5, 420 * _P.size), _sag = 34 * _P.size, _x0b = _x - _span / 2, _n = string_length(_P.text);
            if (_n > 0 && _n <= 12) {
                for (var _k = 0; _k < _n; _k++) {
                    var _ch = string_char_at(_P.text, _k + 1);
                    if (_ch == " ") continue;
                    var _d = clamp((_P.age - _k * 0.06 - 0.12) / 0.25, 0, 1), _tc = (_k + 0.5) / _n;
                    var _fx = _x0b + _tc * _span + sin(_P.age * 3 + _k * 1.7) * 1.5 * _P.size, _fy = _y + _sag * 4 * _tc * (1 - _tc) + 20 * _P.size;
                    var _fw = _span / _n * 0.8;
                    var _of = draw_get_font(); draw_set_font(_font); var _chh = max(1, string_height("H")); draw_set_font(_of);
                    var _cs = min(_fw / max(1, _chh) * 1.1, 32 * _P.size / _chh);
                    hur__text(_fx, _fy, _ch, _font, _cs, c_white, _P.alpha * (1 - _G.f) * _d, merge_colour(_T.paper[_k mod array_length(_T.paper)], c_black, 0.55));
                }
            } else hur__text(_x, _y + _sag + 90 * _P.size, _P.text, _font, _G.ts, _T.ink, _ta, _T.inkShadow);
            break;
        case "banner_rosette":
            var _R = 56 * _P.size * hur__ease_back(_P.age / 0.4) * (1 - _G.f * 0.7);
            var _of2 = draw_get_font(); draw_set_font(_font); var _w = max(1, string_width(_P.text)), _hh = max(1, string_height("H")); draw_set_font(_of2);
            var _sc = min(_R * 0.8 / _w, _R * 0.62 / _hh);
            hur__text(_x, _y, _P.text, _font, _sc, _T.ink, _ta, _T.inkShadow);
            break;
    }
}

// ------------------------------------------------------------------------------------------------ launchers

/// @function hur__draw_launcher(P, ox, oy)
/// @description Internal. The party popper (a striped paper cone with a twisted rim and its pull cord) or the confetti cannon
/// (a banded tube with a dark mouth and a puff), aimed along its direction, kicking back as it fires and fading.
function hur__draw_launcher(_P, _ox, _oy) {
    var _T = _P.T, _a = clamp((_P.life - _P.age) / 0.4, 0, 1), _kick = 8 * exp(-_P.age * 9) * _P.size / 26;
    var _dx = cos(_P.rot), _dy = -sin(_P.rot), _nx = -_dy, _ny = _dx, _sz = _P.size;
    var _bx = _P.x + _ox - _dx * _kick, _by = _P.y + _oy - _dy * _kick;
    if (_P.form == "popper") {
        var _L = _sz * 2.1, _ax = _bx - _dx * _L, _ay = _by - _dy * _L, _mw = _sz * 0.62;
        var _nb = 5;
        for (var _k = 0; _k < _nb; _k++) {
            var _t0 = _k / _nb, _t1 = (_k + 1) / _nb, _c = (_k mod 2 == 0) ? _T.paper[0] : _T.trim;
            var _p0x = _ax + _dx * _L * _t0, _p0y = _ay + _dy * _L * _t0, _p1x = _ax + _dx * _L * _t1, _p1y = _ay + _dy * _L * _t1;
            hur__quad(_p0x + _nx * _mw * _t0, _p0y + _ny * _mw * _t0, merge_colour(_c, c_white, 0.2), _p1x + _nx * _mw * _t1, _p1y + _ny * _mw * _t1, merge_colour(_c, c_white, 0.2),
                      _p1x - _nx * _mw * _t1, _p1y - _ny * _mw * _t1, hur__mul(_c, 0.7), _p0x - _nx * _mw * _t0, _p0y - _ny * _mw * _t0, hur__mul(_c, 0.7), _a);
        }
        for (var _k = -3; _k <= 3; _k++) {
            var _tx = _bx + _nx * _mw * _k / 3.4, _ty = _by + _ny * _mw * _k / 3.4;
            hur__tri(_tx - _nx * _sz * 0.11, _ty - _ny * _sz * 0.11, _T.paper[2 mod array_length(_T.paper)], _tx + _nx * _sz * 0.11, _ty + _ny * _sz * 0.11, _T.paper[2 mod array_length(_T.paper)], _tx + _dx * _sz * 0.32, _ty + _dy * _sz * 0.32, merge_colour(_T.paper[2 mod array_length(_T.paper)], c_white, 0.3), _a);
        }
        hur__bar(_ax, _ay, _ax - _dx * _sz * 0.7 + _nx * _sz * 0.2, _ay - _dy * _sz * 0.7 + _ny * _sz * 0.2, max(1.2, _sz * 0.06), make_colour_rgb(240, 236, 226), make_colour_rgb(200, 196, 186), _a);
        hur__ellipse(_ax - _dx * _sz * 0.74 + _nx * _sz * 0.2, _ay - _dy * _sz * 0.74 + _ny * _sz * 0.2, _sz * 0.12, _sz * 0.12, _T.trim, hur__mul(_T.trim, 0.7), _a, 10);
    } else {
        var _L2 = _sz * 2.2, _w2 = _sz * 0.46, _ex = _bx - _dx * _L2, _ey = _by - _dy * _L2;
        var _lit = merge_colour(_T.paper[0], c_white, 0.18), _dk = merge_colour(_T.paper[0], c_black, 0.45);
        hur__quad(_ex + _nx * _w2, _ey + _ny * _w2, _lit, _bx + _nx * _w2, _by + _ny * _w2, _lit, _bx - _nx * _w2, _by - _ny * _w2, _dk, _ex - _nx * _w2, _ey - _ny * _w2, _dk, _a);
        for (var _k = 0; _k < 3; _k++) {
            var _t = 0.18 + _k * 0.3, _cx = _ex + _dx * _L2 * _t, _cy = _ey + _dy * _L2 * _t, _bw = _sz * 0.14;
            hur__quad(_cx + _nx * _w2 * 1.06, _cy + _ny * _w2 * 1.06, _T.trim, _cx + _dx * _bw + _nx * _w2 * 1.06, _cy + _dy * _bw + _ny * _w2 * 1.06, _T.trim,
                      _cx + _dx * _bw - _nx * _w2 * 1.06, _cy + _dy * _bw - _ny * _w2 * 1.06, hur__mul(_T.trim, 0.6), _cx - _nx * _w2 * 1.06, _cy - _ny * _w2 * 1.06, hur__mul(_T.trim, 0.6), _a);
        }
        var _mx = _bx, _my = _by;
        hur__quad(_mx + _nx * _w2 * 1.12, _my + _ny * _w2 * 1.12, _T.paper[0], _mx + _dx * _sz * 0.18 + _nx * _w2 * 1.12, _my + _dy * _sz * 0.18 + _ny * _w2 * 1.12, _T.paper[0],
                  _mx + _dx * _sz * 0.18 - _nx * _w2 * 1.12, _my + _dy * _sz * 0.18 - _ny * _w2 * 1.12, hur__mul(_T.paper[0], 0.6), _mx - _nx * _w2 * 1.12, _my - _ny * _w2 * 1.12, hur__mul(_T.paper[0], 0.6), _a);
        var _pa = clamp(1 - _P.age / 0.5, 0, 1);
        if (_pa > 0) for (var _k = 0; _k < 4; _k++) {
            var _pr = _sz * (0.18 + _P.age * 0.9) * (1 + _k * 0.2), _px = _bx + _dx * _sz * (0.5 + _k * 0.45 + _P.age * 1.4) + _nx * (_k - 1.5) * _sz * 0.22, _py = _by + _dy * _sz * (0.5 + _k * 0.45 + _P.age * 1.4) + _ny * (_k - 1.5) * _sz * 0.22;
            hur__ellipse(_px, _py, _pr, _pr, make_colour_rgb(250, 250, 250), make_colour_rgb(230, 230, 236), _a * _pa * 0.5, 16, _a * _pa * 0.5, 0);
        }
    }
}
