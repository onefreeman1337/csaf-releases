/// hur_selftest.gml - Hurrah's in-engine test suite. Run the demo with -selftest: the result is written as hur_selftest.json
/// in the game's save folder and the renders (hur_render_*.png) beside it, to be LOOKED at.
/// Stages: the generator; the catalogue (43 forms, families, titles, every fan outline star-shaped about its own centre so a
/// fan fills it exactly, every strip's rails paired); palettes; physics (paper falls slowly and turns both faces, settles on a
/// floor; the streamer rope holds its length; balloons rise with the string tied to the knot; coins arc, pile and never sink
/// through the floor; every coin of a shower reaches the counter with its value, under any budget); every preset retires
/// and reports "done" exactly once; the budget holds; pause, clear and determinism; refusals; timing; then renders of every
/// form, every banner, every preset and the demo frame - each inked against a ground read off a blank surface, and saved.
///
/// Hurrah - Celebration Effects for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function hur_st_assert(state, condition, message)
/// @description Count one assertion; keep the first 80 failure messages.
function hur_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 80) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
/// @function hur_st_stage(state, n)
/// @description Record the stage reached (the crash handler reports it).
function hur_st_stage(_st, _n) { _st.stage = _n; global.hur_stage = _n; }

/// @function hur__st_read(surface)
/// @description Internal. A surface read into a buffer (RGBA bytes, the whole surface - wing doctrine s13).
function hur__st_read(_surf) {
    var _w = surface_get_width(_surf), _h = surface_get_height(_surf);
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _surf, 0);
    return { buf: _b, w: _w, h: _h };
}
/// @function hur__st_px(read, x, y)
/// @description Internal. [r, g, b, a] at a pixel.
function hur__st_px(_rd, _x, _y) {
    var _o = (clamp(floor(_y), 0, _rd.h - 1) * _rd.w + clamp(floor(_x), 0, _rd.w - 1)) * 4;
    return [buffer_peek(_rd.buf, _o, buffer_u8), buffer_peek(_rd.buf, _o + 1, buffer_u8), buffer_peek(_rd.buf, _o + 2, buffer_u8), buffer_peek(_rd.buf, _o + 3, buffer_u8)];
}
/// @function hur__st_ink_box(read, x0, y0, x1, y1, rgb, tol)
/// @description Internal. Pixels in a box that differ from rgb by more than tol in any channel (x step 2, y step 1), x2.
function hur__st_ink_box(_rd, _x0, _y0, _x1, _y1, _ref, _tol) {
    var _n = 0;
    for (var _y = max(0, _y0); _y < min(_rd.h, _y1); _y++) for (var _x = max(0, _x0); _x < min(_rd.w, _x1); _x += 2) {
        var _o = (_y * _rd.w + _x) * 4;
        if (abs(buffer_peek(_rd.buf, _o, buffer_u8) - _ref[0]) > _tol || abs(buffer_peek(_rd.buf, _o + 1, buffer_u8) - _ref[1]) > _tol || abs(buffer_peek(_rd.buf, _o + 2, buffer_u8) - _ref[2]) > _tol) _n++;
    }
    return _n * 2;
}
/// @function hur__st_diff(readA, readB, tol)
/// @description Internal. Pixels (x step 2, y step 2) where two same-size reads differ by more than tol in any channel, x4.
function hur__st_diff(_ra, _rb, _tol) {
    var _n = 0;
    for (var _y = 0; _y < _ra.h; _y += 2) for (var _x = 0; _x < _ra.w; _x += 2) {
        var _o = (_y * _ra.w + _x) * 4;
        if (abs(buffer_peek(_ra.buf, _o, buffer_u8) - buffer_peek(_rb.buf, _o, buffer_u8)) > _tol || abs(buffer_peek(_ra.buf, _o + 1, buffer_u8) - buffer_peek(_rb.buf, _o + 1, buffer_u8)) > _tol || abs(buffer_peek(_ra.buf, _o + 2, buffer_u8) - buffer_peek(_rb.buf, _o + 2, buffer_u8)) > _tol) _n++;
    }
    return _n * 4;
}
/// @function hur__st_run(world, seconds)
/// @description Internal. Step a world at 60 Hz for a number of seconds; returns every event it reported.
function hur__st_run(_W, _secs) {
    var _all = [];
    repeat (round(_secs * 60)) { hur_world_step(_W, 1 / 60); var _e = hur_world_events(_W); for (var _i = 0; _i < array_length(_e); _i++) array_push(_all, _e[_i]); }
    return _all;
}
/// @function hur__st_count(events, type, id)
/// @description Internal. Events of one type (and one handle, unless id < 0).
function hur__st_count(_ev, _type, _id) { var _n = 0; for (var _i = 0; _i < array_length(_ev); _i++) if (_ev[_i].type == _type && (_id < 0 || _ev[_i].id == _id)) _n++; return _n; }
/// @function hur__st_fam(world, family)
/// @description Internal. The live pieces of one family.
function hur__st_fam(_W, _fam) { var _o = []; for (var _i = 0; _i < array_length(_W.pieces); _i++) if (_W.pieces[_i].fam == _fam) array_push(_o, _W.pieces[_i]); return _o; }

/// @function hur_selftest_run()
/// @description Run every stage; returns the state written by hur_selftest_write.
function hur_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, failures: [], stage: 0, notes: {}, timings: {} };
    _st.notes.epsilon = string_format(math_get_epsilon(), 1, 12);

    // ------------------------------------------------------------ 10: the generator
    hur_st_stage(_st, 10);
    var _g1 = hur_rng(42), _g2 = hur_rng(42), _same = true;
    repeat (50) if (hur_rand(_g1) != hur_rand(_g2)) _same = false;
    hur_st_assert(_st, _same, "the same seed draws the same sequence");
    var _lo = 1, _hi = 0;
    for (var _s = 0; _s < 400; _s++) { var _v = hur_rand(hur_rng(1000 + _s)); _lo = min(_lo, _v); _hi = max(_hi, _v); }
    hur_st_assert(_st, _lo < 0.05 && _hi > 0.95, "first draws over 400 NEARBY seeds span [0,1): " + string(_lo) + ".." + string(_hi));
    var _inr = true, _g3 = hur_rng(7);
    repeat (2000) { var _v = hur_rand(_g3); if (_v < 0 || _v >= 1) _inr = false; }
    hur_st_assert(_st, _inr, "every draw lies in [0, 1)");
    hur_st_assert(_st, hur_rand(undefined) == 0 && hur_rand({}) == 0, "a non-generator draws 0 and does not throw");

    // ------------------------------------------------------------ 20: the catalogue
    hur_st_stage(_st, 20);
    var _forms = hur_forms(), _fams = hur_families(), _sum = 0;
    hur_st_assert(_st, array_length(_forms) == 43, "43 piece forms (" + string(array_length(_forms)) + ")");
    hur_st_assert(_st, array_length(_fams) == 9, "nine families");
    _st.notes.forms = array_length(_forms);
    for (var _f = 0; _f < array_length(_fams); _f++) { var _n = array_length(hur_forms(_fams[_f])); _sum += _n; hur_st_assert(_st, _n >= 2, _fams[_f] + ": at least two forms (" + string(_n) + ")"); }
    hur_st_assert(_st, _sum == array_length(_forms), "the families partition the catalogue (" + string(_sum) + ")");
    var _names = {}, _dup = 0;
    for (var _i = 0; _i < array_length(_forms); _i++) {
        var _fm = _forms[_i];
        if (variable_struct_exists(_names, _fm)) _dup++; _names[$ _fm] = 1;
        hur_st_assert(_st, hur_form_family(_fm) != "" && string_length(hur_form_title(_fm)) > 2, _fm + ": a family and a title");
    }
    hur_st_assert(_st, _dup == 0, "no form name twice");
    hur_st_assert(_st, hur_form_family("teapot") == "" && hur_form_title("teapot") == "" && hur_form_family(12) == "", "a name that is not a form has no family or title");
    // every fan outline is star-shaped about its fan centre: every triangle (centre, p_i, p_i+1) turns the same way (wing doctrine s3)
    var _fanN = 0, _stripN = 0;
    for (var _i = 0; _i < array_length(_forms) * 2; _i++) {
        var _lod = (_i >= array_length(_forms)), _fnm = _forms[_i mod array_length(_forms)] + (_lod ? " (low detail)" : "");
        var _S = hur_form_shape(_forms[_i mod array_length(_forms)], _lod);
        if (is_undefined(_S)) continue;
        if (_S.kind == "fan") {
            _fanN++;
            var _n = array_length(_S.xs), _pos = 0, _neg = 0, _far = 0;
            for (var _k = 0; _k < _n; _k++) {
                var _j = (_k + 1) mod _n;
                var _cr = (_S.xs[_k] - _S.cx) * (_S.ys[_j] - _S.cy) - (_S.ys[_k] - _S.cy) * (_S.xs[_j] - _S.cx);
                if (_cr > 0.0001) _pos++; else if (_cr < -0.0001) _neg++;
                _far = max(_far, abs(_S.xs[_k]), abs(_S.ys[_k]));
            }
            hur_st_assert(_st, _n >= 3 && (_pos == 0 || _neg == 0) && (_pos + _neg) > 0, _fnm + ": the fan outline is star-shaped about its centre (" + string(_pos) + " +, " + string(_neg) + " -)");
            hur_st_assert(_st, _far > 0.5 && _far < 1.6, _fnm + ": the outline spans about one unit (" + string(_far) + ")");
            if (variable_struct_exists(_S, "knot")) {
                var _low = -10;
                for (var _k = 0; _k < _n; _k++) if (abs(_S.xs[_k]) < 0.2) _low = max(_low, _S.ys[_k]);
                hur_st_assert(_st, abs(_S.knot - _low) < 0.12, _fnm + ": the knot sits at the bottom of the balloon (" + string(_S.knot) + " vs " + string(_low) + ")");
            }
        } else {
            _stripN++;
            hur_st_assert(_st, array_length(_S.xs) == array_length(_S.xs2) && array_length(_S.xs) >= 6, _fnm + ": the strip's two rails are paired");
        }
    }
    hur_st_assert(_st, _fanN >= 40 && _stripN == 6, "fan outlines " + string(_fanN) + " (both details), strips 6 (crescent, curl, sequin x2): " + string(_stripN));
    hur_st_assert(_st, is_undefined(hur_form_shape("ribbon")) && is_undefined(hur_form_shape("teapot")) && is_undefined(hur_form_shape(undefined)), "forms drawn by their own routine have no outline");

    // ------------------------------------------------------------ 30: palettes
    hur_st_stage(_st, 30);
    var _ths = hur_themes();
    hur_st_assert(_st, array_length(_ths) == 6, "six palettes");
    for (var _t = 0; _t < array_length(_ths); _t++) {
        var _T = hur_theme(_ths[_t]);
        hur_st_assert(_st, _T.name == _ths[_t] && array_length(_T.paper) >= 5 && array_length(_T.foil) >= 2 && string_length(_T.title) > 2, _ths[_t] + ": a full palette");
    }
    hur_st_assert(_st, hur_theme("nowhere").name == "party" && hur_theme(12).name == "party", "an unknown palette is party");
    var _cu = hur_theme([c_red, c_lime, "x"]);
    hur_st_assert(_st, _cu.name == "custom" && array_length(_cu.paper) == 2, "your own colours make a palette (non-colours dropped)");
    hur_st_assert(_st, hur_theme(["x"]).name == "party" && hur_theme([]).name == "party", "an array with no colours is party");

    // ------------------------------------------------------------ 40: physics
    hur_st_stage(_st, 40);
    // paper: falls slowly, turns both faces, drifts sideways
    var _W = hur_world_create({ seed: 3, bounds: [0, 0, 960, 640] });
    var _hp = hur_fire(_W, "popper", 480, 500, 1);
    var _paper = hur__st_fam(_W, "confetti"), _n0 = array_length(_paper);
    hur_st_assert(_st, _hp > 0 && _n0 >= 40, "a popper throws its confetti (" + string(_n0) + ")");
    var _flips = array_create(_n0, 0), _last = array_create(_n0, 0), _x0 = array_create(_n0, 0);
    for (var _i = 0; _i < _n0; _i++) { _last[_i] = (cos(_paper[_i].ph) >= 0); _x0[_i] = _paper[_i].x; }
    var _maxFall = 0, _riseFirst = 0;
    for (var _f = 0; _f < 180; _f++) {
        hur_world_step(_W, 1 / 60);
        for (var _i = 0; _i < _n0; _i++) { var _fc = (cos(_paper[_i].ph) >= 0); if (_fc != _last[_i]) { _flips[_i]++; _last[_i] = _fc; } if (_f > 90) _maxFall = max(_maxFall, _paper[_i].vy); }
        if (_f == 10) for (var _i = 0; _i < _n0; _i++) if (_paper[_i].y < 500) _riseFirst++;
    }
    var _flipped = 0, _drift = 0, _meanVy = 0;
    for (var _i = 0; _i < _n0; _i++) { if (_flips[_i] >= 2) _flipped++; if (abs(_paper[_i].x - _x0[_i]) > 20) _drift++; _meanVy += _paper[_i].vy / _n0; }
    hur_st_assert(_st, _riseFirst > _n0 * 0.8, "the popper throws UP first (" + string(_riseFirst) + " of " + string(_n0) + " above the mouth at 1/6 s)");
    hur_st_assert(_st, _flipped == _n0, "every piece shows both faces as it tumbles (" + string(_flipped) + " of " + string(_n0) + ")");
    hur_st_assert(_st, _maxFall < 420 && _meanVy > 20, "paper falls like paper: fastest " + string(_maxFall) + " px/s after 1.5 s, mean " + string(_meanVy));
    hur_st_assert(_st, _drift > _n0 * 0.5, "paper drifts sideways (" + string(_drift) + " moved over 20 px)");
    _st.notes.paperFastest = _maxFall; _st.notes.paperMeanVy = _meanVy;
    // on a floor paper settles and nothing sinks through
    var _Wf = hur_world_create({ seed: 4, floor: 500, bounds: [0, 0, 960, 640] });
    hur_fire(_Wf, "popper", 480, 480, 1.5);
    var _below = 0, _rested = 0;
    // settled paper fades after about two seconds, so the measure is the PEAK number lying on the floor during the run
    repeat (300) { hur_world_step(_Wf, 1 / 60); var _rn = 0; for (var _i = 0; _i < array_length(_Wf.pieces); _i++) { var _P = _Wf.pieces[_i]; if (_P.y > 500.5) _below++; if (_P.rest) _rn++; } _rested = max(_rested, _rn); }
    hur_st_assert(_st, _below == 0, "no paper below the floor at any step (" + string(_below) + ")");
    hur_st_assert(_st, _rested > 10, "paper settles on the floor (peak " + string(_rested) + " at rest)");
    // streamers: the rope holds its length at every step
    var _Ws = hur_world_create({ seed: 5, bounds: [0, 0, 960, 640] });
    hur_fire(_Ws, "streamers", 480, 560, 1.5);
    var _ns = array_length(hur__st_fam(_Ws, "streamer")), _over = 0, _worst = 0, _headTravel = 0;
    repeat (150) {
        hur_world_step(_Ws, 1 / 60);
        var _ss = hur__st_fam(_Ws, "streamer");
        for (var _i = 0; _i < array_length(_ss); _i++) { var _P = _ss[_i]; for (var _k = 1; _k < array_length(_P.nx); _k++) { var _dl = point_distance(_P.nx[_k], _P.ny[_k], _P.nx[_k - 1], _P.ny[_k - 1]); _worst = max(_worst, _dl / _P.seg); if (_dl > _P.seg * 1.001) _over++; } }
    }
    var _ss2 = hur__st_fam(_Ws, "streamer");
    for (var _i = 0; _i < array_length(_ss2); _i++) _headTravel = max(_headTravel, point_distance(480, 560, _ss2[_i].nx[0], _ss2[_i].ny[0]));
    hur_st_assert(_st, _ns >= 8 && _over == 0, "every streamer link stays within its length (" + string(_ns) + " streamers, worst " + string(_worst) + " x)");
    hur_st_assert(_st, _headTravel > 150, "a streamer's head flies (" + string(_headTravel) + " px)");
    // balloons rise; the string is tied to the knot
    var _Wb = hur_world_create({ seed: 6, bounds: [0, 0, 960, 640] });
    hur_fire(_Wb, "balloons", 480, 600, 2);
    hur__st_run(_Wb, 3);   // the release runs 1.4 s, so the last balloon has had 1.6 s
    var _bs = hur__st_fam(_Wb, "balloon"), _rise = 0, _tied = 0, _strOver = 0;
    for (var _i = 0; _i < array_length(_bs); _i++) {
        var _P = _bs[_i], _S = hur_form_shape(_P.form);
        if (_P.y < 600 - 120) _rise++;
        var _kx = _P.x - sin(_P.rot) * _P.size * _S.knot, _ky = _P.y + cos(_P.rot) * _P.size * _S.knot;
        if (point_distance(_kx, _ky, _P.nx[0], _P.ny[0]) < 0.5) _tied++;
        for (var _k = 1; _k < array_length(_P.nx); _k++) if (point_distance(_P.nx[_k], _P.ny[_k], _P.nx[_k - 1], _P.ny[_k - 1]) > _P.seg * 1.001) _strOver++;
    }
    hur_st_assert(_st, array_length(_bs) >= 8 && _rise == array_length(_bs), "balloons rise (" + string(_rise) + " of " + string(array_length(_bs)) + " up 120 px)");
    hur_st_assert(_st, _tied == array_length(_bs) && _strOver == 0, "every string is tied to its knot and keeps its length (" + string(_tied) + " tied, " + string(_strOver) + " stretched)");
    // coins: arc, bounce, pile, never sink through the floor
    var _Wc = hur_world_create({ seed: 8, floor: 560, bounds: [0, 0, 960, 640] });
    hur_fire(_Wc, "chest", 480, 540, 1.5);
    var _sink = 0, _peak = 560;
    repeat (240) { hur_world_step(_Wc, 1 / 60); var _cs = hur__st_fam(_Wc, "coin"); for (var _i = 0; _i < array_length(_cs); _i++) { if (_cs[_i].y > 560.5) _sink++; _peak = min(_peak, _cs[_i].y); } }
    var _restC = 0, _cs2 = hur__st_fam(_Wc, "coin"), _pileMax = 0;
    for (var _i = 0; _i < array_length(_cs2); _i++) if (_cs2[_i].rest) _restC++;
    for (var _i = 0; _i < array_length(_Wc.pile); _i++) _pileMax = max(_pileMax, _Wc.pile[_i]);
    hur_st_assert(_st, _sink == 0, "no coin below the floor at any step (" + string(_sink) + ")");
    hur_st_assert(_st, _peak < 400, "coins arc up out of the chest (highest y " + string(_peak) + ")");
    hur_st_assert(_st, _restC > 5 && _pileMax > 3, "coins come to rest and stack (" + string(_restC) + " at rest, pile " + string(_pileMax) + " px)");
    // a shower to a counter: every coin arrives once with its value, even under a budget of 10
    var _Wt = hur_world_create({ seed: 9, budget: 10, floor: 560, bounds: [0, 0, 960, 640] });
    var _ht = hur_shower_to(_Wt, 480, 420, 846, 30, 40, { value: 25 });
    var _evt = hur__st_run(_Wt, 6), _arr = 0, _val = 0, _atT = 0;
    for (var _i = 0; _i < array_length(_evt); _i++) if (_evt[_i].type == "arrive") { _arr++; _val += _evt[_i].value; if (_evt[_i].x == 846 && _evt[_i].y == 30) _atT++; }
    hur_st_assert(_st, _ht > 0 && _arr == 40 && _val == 1000, "a shower of 40 at 25 each arrives whole under a budget of 10: " + string(_arr) + " arrivals, value " + string(_val));
    hur_st_assert(_st, _atT == 40, "every arrival reports the target point");
    hur_st_assert(_st, hur__st_count(_evt, "done", _ht) == 1 && hur_world_count(_Wt) == 0, "the shower reports done exactly once and leaves nothing behind");
    _st.notes.showerArrivals = _arr;

    // ------------------------------------------------------------ 45: every kind retires and reports done once
    hur_st_stage(_st, 45);
    var _kinds = hur_kinds(), _okDone = 0, _okEmpty = 0, _maxLife = 0;
    for (var _k = 0; _k < array_length(_kinds); _k++) for (var _fl = 0; _fl < 2; _fl++) {
        var _Wk = hur_world_create({ seed: 20 + _k, floor: (_fl == 1) ? 590 : undefined, bounds: [0, 0, 960, 640] });
        var _hk = hur_fire(_Wk, _kinds[_k], 480, 300, 1, { text: "HURRAH", tx: 846, ty: 30 });
        var _evk = [], _secs = 0;
        while (_secs < 30 && (hur_world_count(_Wk) > 0 || array_length(_Wk.emitters) > 0 || _secs < 0.1)) { var _e = hur__st_run(_Wk, 0.5); for (var _q = 0; _q < array_length(_e); _q++) array_push(_evk, _e[_q]); _secs += 0.5; }
        var _e2 = hur__st_run(_Wk, 0.05); for (var _q = 0; _q < array_length(_e2); _q++) array_push(_evk, _e2[_q]);
        _maxLife = max(_maxLife, _secs);
        var _dn = hur__st_count(_evk, "done", _hk);
        if (_dn == 1) _okDone++; else hur_st_assert(_st, false, _kinds[_k] + (_fl ? " (floor)" : "") + ": done reported " + string(_dn) + " times");
        if (hur_world_count(_Wk) == 0) _okEmpty++; else hur_st_assert(_st, false, _kinds[_k] + (_fl ? " (floor)" : "") + ": " + string(hur_world_count(_Wk)) + " pieces still alive after " + string(_secs) + " s");
    }
    hur_st_assert(_st, _okDone == array_length(_kinds) * 2 && _okEmpty == array_length(_kinds) * 2, "all 16 kinds, with and without a floor, retire completely and report done exactly once (" + string(_okDone) + ", " + string(_okEmpty) + ")");
    _st.notes.longestCelebrationS = _maxLife;

    // ------------------------------------------------------------ 50: budget, pause, clear, determinism
    hur_st_stage(_st, 50);
    var _Wq = hur_world_create({ seed: 11, budget: 120, bounds: [0, 0, 960, 640] });
    var _maxLive = 0;
    for (var _r = 0; _r < 20; _r++) { hur_fire(_Wq, "cannon", 100 + _r * 40, 600, 2); hur_world_step(_Wq, 1 / 60); _maxLive = max(_maxLive, hur_world_count(_Wq)); }
    repeat (120) { hur_world_step(_Wq, 1 / 60); _maxLive = max(_maxLive, hur_world_count(_Wq)); }
    hur_st_assert(_st, _maxLive <= 120 && _maxLive > 60, "twenty cannons under a budget of 120 never exceed it (peak " + string(_maxLive) + ")");
    hur_st_assert(_st, _Wq.stats.thinned > 0, "the excess is thinned and counted (" + string(_Wq.stats.thinned) + ")");
    var _Wp = hur_world_create({ seed: 12, bounds: [0, 0, 960, 640] });
    hur_fire(_Wp, "win", 480, 300, 1);
    hur__st_run(_Wp, 0.5);
    hur_world_pause(_Wp, true);
    var _snap = [];
    for (var _i = 0; _i < array_length(_Wp.pieces); _i++) array_push(_snap, _Wp.pieces[_i].x * 1000 + _Wp.pieces[_i].y);
    var _nSnap = array_length(_Wp.pieces);
    hur__st_run(_Wp, 0.5);
    var _moved = 0;
    for (var _i = 0; _i < min(_nSnap, array_length(_Wp.pieces)); _i++) if (_Wp.pieces[_i].x * 1000 + _Wp.pieces[_i].y != _snap[_i]) _moved++;
    hur_st_assert(_st, _nSnap > 50 && _moved == 0 && array_length(_Wp.pieces) == _nSnap, "a paused world does not move (" + string(_moved) + " of " + string(_nSnap) + " moved)");
    hur_world_pause(_Wp, false);
    hur__st_run(_Wp, 0.1);
    var _moved2 = 0;
    for (var _i = 0; _i < min(_nSnap, array_length(_Wp.pieces)); _i++) if (_Wp.pieces[_i].x * 1000 + _Wp.pieces[_i].y != _snap[_i]) _moved2++;
    hur_st_assert(_st, _moved2 > 0, "and moves again when resumed");
    hur_world_clear(_Wp);
    hur_st_assert(_st, hur_world_count(_Wp) == 0 && array_length(_Wp.emitters) == 0, "clear retires everything");
    var _Wd1 = hur_world_create({ seed: 77, floor: 590, bounds: [0, 0, 960, 640] }), _Wd2 = hur_world_create({ seed: 77, floor: 590, bounds: [0, 0, 960, 640] });
    hur_fire(_Wd1, "birthday", 480, 300, 1, { text: "HI" }); hur_fire(_Wd2, "birthday", 480, 300, 1, { text: "HI" });
    hur__st_run(_Wd1, 2); hur__st_run(_Wd2, 2);
    var _detOk = (hur_world_count(_Wd1) == hur_world_count(_Wd2));
    for (var _i = 0; _i < min(hur_world_count(_Wd1), hur_world_count(_Wd2)); _i++) if (_Wd1.pieces[_i].x != _Wd2.pieces[_i].x || _Wd1.pieces[_i].y != _Wd2.pieces[_i].y) _detOk = false;
    hur_st_assert(_st, _detOk && hur_world_count(_Wd1) > 20, "the same seed and the same calls give the same celebration");

    // ------------------------------------------------------------ 60: refusals
    hur_st_stage(_st, 60);
    var _Wr = hur_world_create();
    hur_st_assert(_st, hur_fire(undefined, "win", 0, 0) == -1 && hur_fire({}, "win", 0, 0) == -1 && hur_fire(_Wr, "teapot", 0, 0) == -1 && hur_fire(_Wr, 12, 0, 0) == -1, "hur_fire refuses a non-world and an unknown kind");
    hur_st_assert(_st, hur_fire(_Wr, "popper", "x", 0) == -1 && hur_fire(_Wr, "popper", 0, undefined) == -1 && hur_fire(_Wr, "popper", infinity, 0) == -1, "hur_fire refuses a position that is not a finite number");
    hur_st_assert(_st, hur_fire(_Wr, "popper", 100, 100, "loud") > 0 && hur_fire(_Wr, "popper", 100, 100, -5) > 0, "a bad strength falls back and still fires");
    hur_st_assert(_st, hur_banner(_Wr, "HI", 0, 0, "teapot") == -1 && hur_banner(_Wr, 5, 0, 0) == -1 && hur_banner(undefined, "HI", 0, 0) == -1, "hur_banner refuses a bad form, non-text words and a non-world");
    hur_st_assert(_st, hur_shower_to(_Wr, 0, 0, "x", 0, 5) == -1 && hur_shower_to(_Wr, 0, 0, 0, 0, "many") == -1 && hur_shower_to({}, 0, 0, 0, 0, 5) == -1, "hur_shower_to refuses a bad target, a bad count and a non-world");
    hur_world_step(undefined); hur_world_step({}, 1); hur_world_pause(undefined, true); hur_world_clear(12); hur_world_free(undefined);
    hur_st_assert(_st, hur_world_count("x") == 0 && array_length(hur_world_events(undefined)) == 0, "the world calls ignore a non-world");
    hur_world_step(_Wr, "soon"); hur_world_step(_Wr, -3); hur_world_step(_Wr, 99);
    hur_st_assert(_st, _Wr.time <= HUR_DT_MAX + 0.0001, "a bad dt is refused, a huge dt capped at " + string(HUR_DT_MAX) + " s (time " + string(_Wr.time) + ")");
    var _Wbad = hur_world_create({ budget: "lots", floor: "low", bounds: [0, "a"], theme: 99, seed: "s" });
    hur_st_assert(_st, hur__is_world(_Wbad) && _Wbad.budget == HUR_BUDGET && is_undefined(_Wbad.floorY) && _Wbad.theme.name == "party", "hur_world_create accepts junk options and falls back to defaults");

    // ------------------------------------------------------------ 70: drawing
    hur_st_stage(_st, 70);
    var _blank = surface_create(64, 64);
    surface_set_target(_blank); draw_clear_alpha(make_colour_rgb(239, 230, 210), 1); surface_reset_target();
    var _brd = hur__st_read(_blank), _bpx = hur__st_px(_brd, 3, 3);
    buffer_delete(_brd.buf); surface_free(_blank);
    _st.notes.blankBytes = string(_bpx[0]) + "," + string(_bpx[1]) + "," + string(_bpx[2]) + "," + string(_bpx[3]);
    hur_st_assert(_st, _bpx[0] == 239 && _bpx[1] == 230 && _bpx[2] == 210, "a blank surface reads back R, G, B (the ink counter's control)");
    var _GND = [30, 28, 52];
    // every form draws ink in its cell
    var _cols = 9, _cell = 120, _sfF = surface_create(_cols * _cell, ceil(43 / _cols) * _cell);
    surface_set_target(_sfF); draw_clear_alpha(make_colour_rgb(_GND[0], _GND[1], _GND[2]), 1);
    for (var _i = 0; _i < 43; _i++) {
        var _fm = _forms[_i], _cx = (_i mod _cols) * _cell + _cell / 2, _cy = (_i div _cols) * _cell + _cell / 2, _fam = hur_form_family(_fm);
        var _sz = (_fam == "banner") ? 13 : ((_fam == "streamer") ? 26 : ((_fam == "burst") ? 30 : ((_fam == "launcher") ? 22 : 34)));
        var _ok = hur_piece_draw(_fm, _cx, _cy, _sz, (_fam == "launcher") ? 45 : 20, hur_form_peak(_fm), "party");
        if (!_ok) hur_st_assert(_st, false, _fm + ": hur_piece_draw refused a catalogue form");
    }
    surface_reset_target();
    surface_save(_sfF, "hur_render_forms.png");
    var _rdF = hur__st_read(_sfF), _empty = 0, _thin = "";
    for (var _i = 0; _i < 43; _i++) {
        var _cx = (_i mod _cols) * _cell, _cy = (_i div _cols) * _cell;
        var _ink = hur__st_ink_box(_rdF, _cx + 2, _cy + 2, _cx + _cell - 2, _cy + _cell - 2, _GND, 14);
        if (_ink < 300) { _empty++; _thin += _forms[_i] + "(" + string(_ink) + ") "; }
    }
    hur_st_assert(_st, _empty == 0, "all 43 forms draw at least 300 px of ink in their cell: " + _thin);
    // distinctness within each family: 24 x 24 samples per cell, a sample differs if any channel moves > 40
    var _closest = 1, _cPair = "", _hist = [0, 0, 0, 0, 0];
    for (var _a = 0; _a < 43; _a++) for (var _b = _a + 1; _b < 43; _b++) {
        if (hur_form_family(_forms[_a]) != hur_form_family(_forms[_b])) continue;
        var _ax = (_a mod _cols) * _cell, _ay = (_a div _cols) * _cell, _bx = (_b mod _cols) * _cell, _by = (_b div _cols) * _cell, _dif = 0, _tot = 0;
        for (var _yy = 0; _yy < 24; _yy++) for (var _xx = 0; _xx < 24; _xx++) {
            var _pa = hur__st_px(_rdF, _ax + 12 + _xx * 4, _ay + 12 + _yy * 4), _pb = hur__st_px(_rdF, _bx + 12 + _xx * 4, _by + 12 + _yy * 4);
            var _ia = (abs(_pa[0] - _GND[0]) + abs(_pa[1] - _GND[1]) + abs(_pa[2] - _GND[2]) > 30), _ib = (abs(_pb[0] - _GND[0]) + abs(_pb[1] - _GND[1]) + abs(_pb[2] - _GND[2]) > 30);
            if (!_ia && !_ib) continue;
            _tot++;
            if (abs(_pa[0] - _pb[0]) > 40 || abs(_pa[1] - _pb[1]) > 40 || abs(_pa[2] - _pb[2]) > 40) _dif++;
        }
        var _fr = _dif / max(1, _tot);
        _hist[min(4, floor(_fr / 0.1))]++;
        if (_fr < 0.25) { if (!variable_struct_exists(_st.notes, "closePairs")) _st.notes.closePairs = []; array_push(_st.notes.closePairs, _forms[_a] + "/" + _forms[_b] + " " + string_format(_fr, 1, 3)); }
        if (_fr < _closest) { _closest = _fr; _cPair = _forms[_a] + "/" + _forms[_b]; }
        hur_st_assert(_st, _fr > 0.15, _forms[_a] + " and " + _forms[_b] + " look alike (" + string(_fr) + " of samples differ)");
    }
    _st.notes.closestPair = _cPair + " " + string(_closest);
    _st.notes.pairHistogram10pct = _hist;
    buffer_delete(_rdF.buf); surface_free(_sfF);
    // the caller's state comes back, and a translucent piece leaves an opaque surface opaque
    var _Wv = hur_world_create({ seed: 14, floor: 590, bounds: [0, 0, 960, 640] });
    hur_fire(_Wv, "levelup", 480, 300, 1, { text: "LEVEL UP!" }); hur_fire(_Wv, "birthday", 480, 330, 1, { text: "PARTY" }); hur_fire(_Wv, "chest", 760, 560, 1);
    hur__st_run(_Wv, 0.8);
    var _sfV = surface_create(960, 640);
    surface_set_target(_sfV); draw_clear_alpha(make_colour_rgb(_GND[0], _GND[1], _GND[2]), 1);
    draw_set_colour(c_lime); draw_set_alpha(0.5); draw_set_font(fnt_hurrah_body_s); draw_set_halign(fa_right);
    global.hur_vtotal = 0; global.hur_sprites = 0;
    hur_world_draw(_Wv);
    var _gc = draw_get_colour(), _ga = draw_get_alpha(), _gf = draw_get_font(), _gh = draw_get_halign();
    draw_set_colour(c_white); draw_set_alpha(1); draw_set_halign(fa_left);
    surface_reset_target();
    hur_st_assert(_st, _gc == c_lime, "hur_world_draw hands back the caller's colour (" + string(_gc) + ")");
    hur_st_assert(_st, abs(_ga - 0.5) < 0.01, "hur_world_draw hands back the caller's alpha (" + string(_ga) + ")");
    hur_st_assert(_st, _gf == fnt_hurrah_body_s, "hur_world_draw hands back the caller's font");
    hur_st_assert(_st, _gh == fa_right, "hur_world_draw hands back the caller's alignment");
    hur_st_assert(_st, global.hur_vtotal > 1000 && global.hur_sprites > 50, "a full frame writes its pieces: " + string(global.hur_vtotal) + " vertices + " + string(global.hur_sprites) + " atlas sprites for " + string(hur_world_count(_Wv)) + " pieces");
    _st.notes.verticesFullFrame = global.hur_vtotal; _st.notes.spritesFullFrame = global.hur_sprites;
    var _rdV = hur__st_read(_sfV), _transl = 0;
    for (var _y = 0; _y < 640; _y += 2) for (var _x = 0; _x < 960; _x += 2) if (buffer_peek(_rdV.buf, (_y * 960 + _x) * 4 + 3, buffer_u8) < 255) _transl++;
    hur_st_assert(_st, _transl == 0, "translucent pieces leave an opaque surface opaque (" + string(_transl) + " translucent samples)");
    buffer_delete(_rdV.buf); surface_free(_sfV);
    hur_world_free(_Wv);
    // a piece drawn under a caller's 2x transform draws, and the matrix comes back
    var _mw = matrix_get(matrix_world);
    var _sf2 = surface_create(200, 200);
    surface_set_target(_sf2); draw_clear_alpha(make_colour_rgb(_GND[0], _GND[1], _GND[2]), 1);
    matrix_set(matrix_world, matrix_build(0, 0, 0, 0, 0, 0, 2, 2, 1));
    hur_piece_draw("star", 50, 50, 20);
    var _back = matrix_get(matrix_world);
    matrix_set(matrix_world, _mw);
    surface_reset_target();
    var _rd2 = hur__st_read(_sf2);
    hur_st_assert(_st, _back[0] == 2 && _back[5] == 2, "hur_piece_draw hands the caller's world matrix back");
    hur_st_assert(_st, hur__st_ink_box(_rd2, 60, 60, 140, 140, _GND, 14) > 600 && hur__st_ink_box(_rd2, 0, 0, 40, 40, _GND, 14) == 0, "and draws where the transform puts it (centred at 100, 100)");
    buffer_delete(_rd2.buf); surface_free(_sf2);
    hur_st_assert(_st, hur_form_peak("ring") > hur_form_peak("rays") && hur_form_peak("sparkle") == 0.5 && hur_form_peak("teapot") == 0.05 && hur_form_peak(undefined) == 0.05, "hur_form_peak orders the bursts and answers anything else with 0.05");
    hur_st_assert(_st, hur_piece_draw("teapot", 0, 0, 10) == false && hur_piece_draw("star", "x", 0, 10) == false && hur_piece_draw("star", 0, 0, undefined) == false, "hur_piece_draw refuses bad input");
    var _We = hur_world_create();
    hur_world_draw(_We); hur_world_draw(undefined);
    hur_st_assert(_st, true, "an empty world and a non-world draw without a crash");
    hur_world_free(_We);
    // the paper atlas: 13 cells, each inked
    var _A = hur__atlas(), _sfA = surface_create(_A.n * _A.cell, _A.cell), _emptyA = 0;
    surface_set_target(_sfA); draw_clear_alpha(make_colour_rgb(_GND[0], _GND[1], _GND[2]), 1); draw_sprite(_A.spr, 0, 0, 0); surface_reset_target();
    var _rdA = hur__st_read(_sfA);
    for (var _k = 0; _k < _A.n; _k++) if (hur__st_ink_box(_rdA, _k * _A.cell, 0, (_k + 1) * _A.cell, _A.cell, _GND, 20) < 120) _emptyA++;
    hur_st_assert(_st, _A.n == 13 && sprite_exists(_A.spr) && _emptyA == 0, "the paper atlas holds 13 inked cells (" + string(_emptyA) + " empty)");
    buffer_delete(_rdA.buf); surface_free(_sfA);
    // an atlas piece lands where the vertex path lands it: ink centres at four spins x two tumbles
    var _spins = [0, 0.7, 2.0, -1.2], _tums = [0, 1.0], _worstOff = 0, _worstPair = 0, _placed = 0;
    for (var _a = 0; _a < 4; _a++) for (var _b = 0; _b < 2; _b++) {
        var _Wa = hur_world_create({ seed: 1, bounds: [0, 0, 400, 200] });
        var _Pa = hur__piece(_Wa, 1, "strip", 100, 100, 0, 0, 26, c_red, c_red);
        _Pa.layer = 3; _Pa.rot = _spins[_a]; _Pa.ph = _tums[_b]; _Pa.vr = 0; _Pa.vph = 0;
        var _Pv = hur__piece(_Wa, 1, "strip", 300, 100, 0, 0, 26, c_red, c_red);
        _Pv.layer = 2; _Pv.rot = _spins[_a]; _Pv.ph = _tums[_b];   // layer 2 draws through the vertex path
        var _sfp = surface_create(400, 200);
        surface_set_target(_sfp); draw_clear_alpha(c_black, 1); hur_world_draw(_Wa); surface_reset_target();
        var _rdp = hur__st_read(_sfp), _cxA = 0, _cyA = 0, _nA = 0, _cxV = 0, _cyV = 0, _nV = 0;
        for (var _y = 0; _y < 200; _y++) for (var _x = 0; _x < 400; _x++) {
            if (buffer_peek(_rdp.buf, (_y * 400 + _x) * 4, buffer_u8) > 60) { if (_x < 200) { _cxA += _x; _cyA += _y; _nA++; } else { _cxV += _x; _cyV += _y; _nV++; } }
        }
        buffer_delete(_rdp.buf); surface_free(_sfp); hur_world_free(_Wa);
        if (_nA > 20 && _nV > 20) {
            _placed++;
            _cxA /= _nA; _cyA /= _nA; _cxV /= _nV; _cyV /= _nV;
            _worstOff = max(_worstOff, point_distance(_cxA + 0.5, _cyA + 0.5, 100, 100), point_distance(_cxV + 0.5, _cyV + 0.5, 300, 100));
            _worstPair = max(_worstPair, point_distance(_cxA, _cyA, _cxV - 200, _cyV), abs(_nA - _nV) / max(1, _nV) * 10);
        }
    }
    hur_st_assert(_st, _placed == 8, "all eight placement cases drew ink on both paths (" + string(_placed) + ")");
    hur_st_assert(_st, _worstOff < 1.6, "an atlas piece and a vertex piece both centre on their own position at every spin and tumble (worst " + string(_worstOff) + " px)");
    hur_st_assert(_st, _worstPair < 1.6, "the atlas path and the vertex path agree on where and how big a piece is (worst " + string(_worstPair) + ")");
    _st.notes.atlasPlacementWorstPx = _worstOff;

    // banners: each form lettered, inside its own band
    var _sfB = surface_create(1200, 560), _bforms = hur_forms("banner");
    var _Wbn = hur_world_create({ seed: 15, bounds: [0, 0, 1200, 560] });
    var _bx = [300, 900, 600, 300], _by = [90, 90, 270, 420];
    hur_banner(_Wbn, "LEVEL UP!", 300, 90, "banner_ribbon");
    hur_banner(_Wbn, "NEW RECORD", 900, 90, "banner_scroll");
    hur_banner(_Wbn, "HOORAY", 600, 250, "banner_bunting", { width: 900 });
    hur_banner(_Wbn, "1st", 300, 420, "banner_rosette", { strength: 1.4 });
    hur_banner(_Wbn, "WELL DONE", 900, 420, "banner_ribbon", { theme: "royal" });
    hur__st_run(_Wbn, 1.0);
    surface_set_target(_sfB); draw_clear_alpha(make_colour_rgb(_GND[0], _GND[1], _GND[2]), 1); hur_world_draw(_Wbn); surface_reset_target();
    surface_save(_sfB, "hur_render_banners.png");
    var _rdB = hur__st_read(_sfB);
    hur_st_assert(_st, hur__st_ink_box(_rdB, 120, 50, 480, 130, _GND, 14) > 8000, "the ribbon banner is drawn round its words");
    hur_st_assert(_st, hur__st_ink_box(_rdB, 720, 40, 1080, 140, _GND, 14) > 8000, "the scroll is unrolled");
    hur_st_assert(_st, hur__st_ink_box(_rdB, 150, 240, 1050, 340, _GND, 14) > 6000, "the bunting hangs its flags");
    hur_st_assert(_st, hur__st_ink_box(_rdB, 230, 350, 370, 490, _GND, 14) > 6000, "the rosette is pleated round its centre");
    hur_st_assert(_st, hur__st_ink_box(_rdB, 0, 0, 1200, 4, _GND, 14) == 0, "no banner reaches the top edge of its surface");
    buffer_delete(_rdB.buf); surface_free(_sfB); hur_world_free(_Wbn);

    // ------------------------------------------------------------ 80: every preset over the demo scene, and the demo frame
    hur_st_stage(_st, 80);
    var _D = hur_demo_create();
    var _sfS = surface_create(960, 640);
    surface_set_target(_sfS); draw_clear_alpha(c_black, 1); hur_demo_scene_draw(_D, 0, 0, 960, 640); surface_reset_target();
    var _rdS = hur__st_read(_sfS);
    var _pres = hur_presets(), _peak = [0.7, 1.0, 0.8, 0.9, 0.8, 1.9, 0.6, 2.6], _stepMax = 0, _drawMax = 0, _thl = hur_themes();
    for (var _p = 0; _p < array_length(_pres); _p++) {
        var _Wx = hur_world_create({ seed: 30 + _p, floor: 590, bounds: [0, 0, 960, 640], theme: _thl[_p mod 6] });
        var _hx = 480, _hy = 260, _ox = {};
        if (_pres[_p] == "chest") { _hx = 760; _hy = 540; }
        if (_pres[_p] == "jackpot") { _ox = { tx: 846, ty: 30 }; _hy = 420; }
        if (_pres[_p] == "levelup") _ox = { text: "LEVEL UP!" };
        if (_pres[_p] == "win") _ox = { text: "YOU WIN!" };
        if (_pres[_p] == "record") _ox = { text: "NEW RECORD" };
        if (_pres[_p] == "achievement") _ox = { text: "1st" };
        if (_pres[_p] == "birthday") { _ox = { text: "PARTY TIME" }; _hy = 330; }
        hur_fire(_Wx, _pres[_p], _hx, _hy, 1, _ox);
        repeat (round(_peak[_p] * 60)) { var _t0 = get_timer(); hur_world_step(_Wx, 1 / 60); _stepMax = max(_stepMax, (get_timer() - _t0) / 1000); }
        var _sfx = surface_create(960, 640);
        surface_set_target(_sfx); draw_clear_alpha(c_black, 1); hur_demo_scene_draw(_D, 0, 0, 960, 640);
        var _t1 = get_timer(); hur_world_draw(_Wx); _drawMax = max(_drawMax, (get_timer() - _t1) / 1000);
        surface_reset_target();
        surface_save(_sfx, "hur_render_" + _pres[_p] + ".png");
        var _rdx = hur__st_read(_sfx), _added = hur__st_diff(_rdx, _rdS, 24);
        hur_st_assert(_st, _added > 960 * 640 * 0.02, _pres[_p] + ": the celebration changes the screen (" + string(_added) + " px, " + string(hur_world_count(_Wx)) + " pieces)");
        _st.notes[$ "px_" + _pres[_p]] = _added;
        buffer_delete(_rdx.buf); surface_free(_sfx); hur_world_free(_Wx);
    }
    buffer_delete(_rdS.buf); surface_free(_sfS);
    _st.timings.presetStepWorstMs = _stepMax; _st.timings.presetDrawWorstMs = _drawMax;
    // a full budget, timed: step and draw at the default budget and at 700 live pieces
    var _budgets = [HUR_BUDGET, 700];
    for (var _bq = 0; _bq < 2; _bq++) {
        var _Wm = hur_world_create({ seed: 40, budget: _budgets[_bq], bounds: [0, 0, 960, 640] });
        hur_fire(_Wm, "win", 480, 300, 1.4); hur_fire(_Wm, "levelup", 480, 280, 1.4); hur_fire(_Wm, "birthday", 480, 320, 1); hur_fire(_Wm, "cannon", 200, 600, 2); hur_fire(_Wm, "cannon", 760, 600, 2);
        hur__st_run(_Wm, 0.5);
        var _sfm = surface_create(960, 640), _sMean = 0, _dMean = 0, _sWorst = 0, _dWorst = 0, _nn = 0, _live = 0;
        global.hur_vtotal = 0; global.hur_sprites = 0;
        repeat (30) {
            var _a0 = get_timer(); hur_world_step(_Wm, 1 / 60); var _a1 = get_timer();
            surface_set_target(_sfm); draw_clear_alpha(c_black, 1); hur_world_draw(_Wm); surface_reset_target();
            var _a2 = get_timer();
            _sMean += (_a1 - _a0) / 1000; _dMean += (_a2 - _a1) / 1000; _sWorst = max(_sWorst, (_a1 - _a0) / 1000); _dWorst = max(_dWorst, (_a2 - _a1) / 1000); _nn++;
            _live = max(_live, hur_world_count(_Wm));
        }
        surface_free(_sfm); hur_world_free(_Wm);
        var _tag = (_bq == 0) ? "default" : "full700";
        _st.timings[$ _tag + "StepMeanMs"] = _sMean / _nn; _st.timings[$ _tag + "DrawMeanMs"] = _dMean / _nn; _st.timings[$ _tag + "StepWorstMs"] = _sWorst; _st.timings[$ _tag + "DrawWorstMs"] = _dWorst; _st.timings[$ _tag + "Live"] = _live;
        hur_st_assert(_st, _live >= _budgets[_bq] * 0.8, _tag + ": the timing fixture fills its budget (" + string(_live) + " of " + string(_budgets[_bq]) + " live)");
        // wall-clock time on a shared machine is NOT a gate (the same source measured 20 ms, then 41 ms): it is recorded for the
        // Readme as a range over two runs. The gate is the deterministic cost - primitives written per live piece - plus a
        // sanity bound loose enough never to flake.
        var _prim = (global.hur_vtotal / 3 + global.hur_sprites) / max(1, _nn * _live);
        _st.timings[$ _tag + "PrimitivesPerPiece"] = _prim;
        hur_st_assert(_st, _prim < 12, _tag + ": " + string(_prim) + " primitives a piece a frame (triangles + atlas sprites), under 12");
        hur_st_assert(_st, (_sMean + _dMean) / _nn < 250, _tag + ": sanity, a budget of " + string(_budgets[_bq]) + " frames in " + string((_sMean + _dMean) / _nn) + " ms mean (recorded, not a gate)");
    }
    // the demo frame, mid level-up
    hur_demo_fire(_D, 1); hur_demo_fire(_D, 7);
    repeat (40) hur_world_step(_D.world, 1 / 60);
    var _sfD = surface_create(960, 640);
    surface_set_target(_sfD); draw_clear_alpha(c_black, 1); hur_demo_draw(_D); surface_reset_target();
    surface_save(_sfD, "hur_render_demo.png");
    var _rdD = hur__st_read(_sfD);
    hur_st_assert(_st, hur__st_ink_box(_rdD, 0, 0, 960, 640, [0, 0, 0], 6) > 960 * 640 * 0.9, "the demo frame fills the room");
    buffer_delete(_rdD.buf); surface_free(_sfD);
    hur_demo_free(_D);
    hur_st_stage(_st, 99);
    return _st;
}

/// @function hur_selftest_write(state)
/// @description Write the suite's result as hur_selftest.json in the save folder.
function hur_selftest_write(_st) {
    var _f = file_text_open_write("hur_selftest.json");
    file_text_write_string(_f, json_stringify(_st));
    file_text_close(_f);
}
