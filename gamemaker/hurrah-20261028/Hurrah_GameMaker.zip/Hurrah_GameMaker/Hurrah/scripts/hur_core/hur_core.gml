/// hur_core.gml - Hurrah's simulation: the catalogue of 43 drawn piece forms in 9 families, six palettes, the moment presets,
/// and the world that fires, moves and retires every piece. NO DRAWING CALLS live in this file: everything here is plain
/// arithmetic on structs, so it runs headless and is what the in-engine suite exercises.
///
/// Families: confetti (10 cuts of two-sided paper that tumbles and flutters), streamers (5 forms of ribbon on a rope chain),
/// balloons (5 shapes that rise and sway on a string), coins (3 metals that spin edge-on and pile up or fly to a counter),
/// gems (5 cuts), bursts (5: rays, ring, starburst, sparkle, flash), falls (4: ticker tape, sequins, petals, feathers),
/// banners (4: ribbon, scroll, bunting, rosette - drawn behind your own text) and launchers (party popper, confetti cannon).
///
/// Public functions: hur_world_create, hur_world_step, hur_world_clear, hur_world_pause, hur_world_count, hur_world_events,
/// hur_world_free (in hur_draw), hur_fire, hur_banner, hur_shower_to, hur_forms, hur_families, hur_form_family,
/// hur_form_title, hur_themes, hur_theme, hur_presets, hur_kinds, hur_rng, hur_rand.
///
/// Hurrah - Celebration Effects for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

#macro HUR_VERSION "1.0.0"
#macro HUR_BUDGET 400
#macro HUR_G_HEAVY 1100
#macro HUR_G_PAPER 520
#macro HUR_DT_MAX 0.05

// ------------------------------------------------------------------------------------------------ the generator

/// @function hur_rng(seed)
/// @description A seeded generator (Lehmer, 48271). Three draws are discarded at seeding: the first draw of a Lehmer generator
/// is nearly a straight line in the seed, so nearby seeds would otherwise start alike (wing doctrine s6).
/// @param {real} seed  Any number.
/// @returns {struct} A generator for hur_rand.
function hur_rng(_seed) {
    var _s = is_numeric(_seed) ? floor(abs(_seed)) : 1;
    if (_s != _s) _s = 1;
    var _g = { s: (_s mod 2147483646) + 1 };
    repeat (3) hur_rand(_g);
    return _g;
}

/// @function hur_rand(generator)
/// @description The next draw in [0, 1). A non-generator draws 0 and does not throw.
function hur_rand(_g) {
    if (!is_struct(_g) || !variable_struct_exists(_g, "s")) return 0;
    _g.s = (_g.s * 48271) mod 2147483647;
    return (_g.s - 1) / 2147483646;
}

/// @function hur__range(g, a, b)
/// @description Internal. A draw in [a, b).
function hur__range(_g, _a, _b) { return _a + (_b - _a) * hur_rand(_g); }

/// @function hur__pick(g, array)
/// @description Internal. One element of a non-empty array.
function hur__pick(_g, _arr) { return _arr[min(array_length(_arr) - 1, floor(hur_rand(_g) * array_length(_arr)))]; }

/// @function hur__num(v, default, lo, hi)
/// @description Internal. A finite number clamped to [lo, hi], or the default for anything that is not one.
function hur__num(_v, _d, _lo, _hi) {
    if (!is_numeric(_v)) return _d;
    var _r = real(_v);
    if (_r != _r) return _d;
    return clamp(_r, _lo, _hi);
}

/// @function hur__opt(opts, key, default)
/// @description Internal. opts.key when opts is a struct that has it, else the default.
function hur__opt(_o, _k, _d) { return (is_struct(_o) && variable_struct_exists(_o, _k)) ? _o[$ _k] : _d; }

// ------------------------------------------------------------------------------------------------ the catalogue

/// @function hur_families()
/// @description The nine piece families, in catalogue order.
function hur_families() { return ["confetti", "streamer", "balloon", "coin", "gem", "burst", "fall", "banner", "launcher"]; }

/// @function hur_forms([family])
/// @description Every drawn piece form (43), or those of one family. A fresh array each call.
/// @param {string} [family]  One of hur_families(); omitted or "" for all.
function hur_forms(_family = "") {
    var _all = ["square", "strip", "dot", "triangle", "star", "heart", "diamond", "flower", "crescent", "spiral",
                "ribbon", "serpentine", "zigzag", "twist", "tinsel",
                "balloon_round", "balloon_oval", "balloon_heart", "balloon_star", "balloon_long",
                "coin_gold", "coin_silver", "coin_copper",
                "gem_round", "gem_emerald", "gem_heart", "gem_marquise", "gem_pear",
                "rays", "ring", "starburst", "sparkle", "flash",
                "ticker", "sequin", "petal", "feather",
                "banner_ribbon", "banner_scroll", "banner_bunting", "banner_rosette",
                "popper", "cannon"];
    if (!is_string(_family) || _family == "") return _all;
    var _out = [];
    for (var _i = 0; _i < array_length(_all); _i++) if (hur_form_family(_all[_i]) == _family) array_push(_out, _all[_i]);
    return _out;
}

/// @function hur_form_family(form)
/// @description The family a form belongs to, or "" for a name that is not a form.
function hur_form_family(_f) {
    if (!is_string(_f)) return "";
    switch (_f) {
        case "square": case "strip": case "dot": case "triangle": case "star": case "heart": case "diamond": case "flower": case "crescent": case "spiral": return "confetti";
        case "ribbon": case "serpentine": case "zigzag": case "twist": case "tinsel": return "streamer";
        case "balloon_round": case "balloon_oval": case "balloon_heart": case "balloon_star": case "balloon_long": return "balloon";
        case "coin_gold": case "coin_silver": case "coin_copper": return "coin";
        case "gem_round": case "gem_emerald": case "gem_heart": case "gem_marquise": case "gem_pear": return "gem";
        case "rays": case "ring": case "starburst": case "sparkle": case "flash": return "burst";
        case "ticker": case "sequin": case "petal": case "feather": return "fall";
        case "banner_ribbon": case "banner_scroll": case "banner_bunting": case "banner_rosette": return "banner";
        case "popper": case "cannon": return "launcher";
    }
    return "";
}

/// @function hur_form_title(form)
/// @description A short caption for a form ("Star cut", "Heart balloon"), or "" for a name that is not a form.
function hur_form_title(_f) {
    switch (_f) {
        case "square": return "Square cut"; case "strip": return "Strip cut"; case "dot": return "Dot cut"; case "triangle": return "Triangle cut";
        case "star": return "Star cut"; case "heart": return "Heart cut"; case "diamond": return "Diamond cut"; case "flower": return "Flower cut";
        case "crescent": return "Crescent cut"; case "spiral": return "Paper curl";
        case "ribbon": return "Ribbon streamer"; case "serpentine": return "Serpentine"; case "zigzag": return "Zigzag streamer"; case "twist": return "Twist streamer"; case "tinsel": return "Tinsel strand";
        case "balloon_round": return "Round balloon"; case "balloon_oval": return "Oval balloon"; case "balloon_heart": return "Heart balloon"; case "balloon_star": return "Star foil balloon"; case "balloon_long": return "Long balloon";
        case "coin_gold": return "Gold coin"; case "coin_silver": return "Silver coin"; case "coin_copper": return "Copper coin";
        case "gem_round": return "Round gem"; case "gem_emerald": return "Emerald cut gem"; case "gem_heart": return "Heart gem"; case "gem_marquise": return "Marquise gem"; case "gem_pear": return "Pear gem";
        case "rays": return "Rays"; case "ring": return "Shock ring"; case "starburst": return "Starburst"; case "sparkle": return "Sparkle"; case "flash": return "Flash";
        case "ticker": return "Ticker tape"; case "sequin": return "Sequin"; case "petal": return "Petal"; case "feather": return "Feather";
        case "banner_ribbon": return "Ribbon banner"; case "banner_scroll": return "Scroll banner"; case "banner_bunting": return "Bunting"; case "banner_rosette": return "Rosette";
        case "popper": return "Party popper"; case "cannon": return "Confetti cannon";
    }
    return "";
}

/// @function hur__circle_pts(n, rx, ry, cx, cy, a0)
/// @description Internal. n points round an ellipse, starting at angle a0 (radians, y down).
function hur__circle_pts(_n, _rx, _ry, _cx, _cy, _a0) {
    var _xs = array_create(_n), _ys = array_create(_n);
    for (var _k = 0; _k < _n; _k++) { var _a = _a0 + _k / _n * pi * 2; _xs[_k] = _cx + cos(_a) * _rx; _ys[_k] = _cy + sin(_a) * _ry; }
    return { xs: _xs, ys: _ys };
}

/// @function hur__heart_pts(n, s, cy)
/// @description Internal. A heart outline (point DOWN), unit size s, shifted so its bounds are centred on cy.
function hur__heart_pts(_n, _s, _cy) {
    var _xs = array_create(_n), _ys = array_create(_n);
    for (var _k = 0; _k < _n; _k++) {
        var _t = _k / _n * pi * 2, _st = sin(_t);
        _xs[_k] = 16 * _st * _st * _st / 16 * _s;
        _ys[_k] = (-(13 * cos(_t) - 5 * cos(2 * _t) - 2 * cos(3 * _t) - cos(4 * _t)) / 16 - 0.155) * _s + _cy;
    }
    return { xs: _xs, ys: _ys };
}

/// @function hur__star_pts(points, ro, ri, a0)
/// @description Internal. A star outline about (0, 0) with the first point at angle a0.
function hur__star_pts(_p, _ro, _ri, _a0) {
    var _xs = array_create(_p * 2), _ys = array_create(_p * 2);
    for (var _k = 0; _k < _p * 2; _k++) { var _a = _a0 + _k / (_p * 2) * pi * 2, _r = (_k mod 2 == 0) ? _ro : _ri; _xs[_k] = cos(_a) * _r; _ys[_k] = sin(_a) * _r; }
    return { xs: _xs, ys: _ys };
}

/// @function hur_form_shape(form, [lo])
/// @description The unit outline (radius about 1, y down) a flat form is drawn from: { kind: "fan", xs, ys, cx, cy } for a
/// shape that is star-shaped about (cx, cy), or { kind: "strip", xs, ys, xs2, ys2, closed } for one that is not (a crescent,
/// a curl, a ring) - drawn as quads between two rails, never as a fan (wing doctrine s3). lo = true gives the same outline
/// with fewer points on its curves, for a piece drawn small. undefined for a form drawn by its own routine (streamers, coins,
/// bursts, banners, launchers, the feather). Cached.
function hur_form_shape(_f, _lo = false) {
    static _cache = {};
    if (!is_string(_f)) return undefined;
    var _key = (_lo == true) ? _f + "|lo" : _f;
    if (variable_struct_exists(_cache, _key)) return _cache[$ _key];
    var _L = (_lo == true);
    var _S = undefined;
    switch (_f) {
        case "square": _S = { kind: "fan", xs: [-0.78, 0.78, 0.78, -0.78], ys: [-0.78, -0.78, 0.78, 0.78], cx: 0, cy: 0 }; break;
        case "strip": _S = { kind: "fan", xs: [-0.34, 0.34, 0.34, -0.34], ys: [-1.15, -1.15, 1.15, 1.15], cx: 0, cy: 0 }; break;
        case "ticker": _S = { kind: "fan", xs: [-0.15, 0.15, 0.15, -0.15], ys: [-1.4, -1.4, 1.4, 1.4], cx: 0, cy: 0 }; break;
        case "dot": var _c = hur__circle_pts(_L ? 9 : 16, 0.82, 0.82, 0, 0, 0); _S = { kind: "fan", xs: _c.xs, ys: _c.ys, cx: 0, cy: 0 }; break;
        case "triangle": var _t = hur__circle_pts(3, 1.02, 1.02, 0, 0.12, -pi / 2); _S = { kind: "fan", xs: _t.xs, ys: _t.ys, cx: 0, cy: 0.12 }; break;
        case "star": var _st = hur__star_pts(5, 1.08, 0.46, -pi / 2); _S = { kind: "fan", xs: _st.xs, ys: _st.ys, cx: 0, cy: 0 }; break;
        case "heart": var _h = hur__heart_pts(_L ? 14 : 32, 0.98, 0); _S = { kind: "fan", xs: _h.xs, ys: _h.ys, cx: 0, cy: 0.04 }; break;
        case "diamond": _S = { kind: "fan", xs: [0, 0.66, 0, -0.66], ys: [-1.12, 0, 1.12, 0], cx: 0, cy: 0 }; break;
        case "flower":
            // five rounded petals: r(t) = 0.5 + 0.48 |cos(2.5 t)|, a polar function of the angle, so star-shaped about the centre
            var _nf = _L ? 20 : 40, _fx = array_create(_nf), _fy = array_create(_nf);
            for (var _k = 0; _k < _nf; _k++) { var _th = _k / _nf * pi * 2 - pi / 2, _rr = 0.5 + 0.5 * power(abs(cos(2.5 * (_th + pi / 2))), 0.8); _fx[_k] = cos(_th) * _rr; _fy[_k] = sin(_th) * _rr; }
            _S = { kind: "fan", xs: _fx, ys: _fy, cx: 0, cy: 0 }; break;
        case "crescent":
            var _n = _L ? 8 : 18, _a = array_create(_n + 1), _b = array_create(_n + 1), _a2 = array_create(_n + 1), _b2 = array_create(_n + 1);
            for (var _k = 0; _k <= _n; _k++) {
                var _u = _k / _n, _th = pi * 0.58 + _u * pi * 0.84, _w = 1 - 0.56 * sin(pi * _u);
                _a[_k] = cos(_th) + 0.42; _b[_k] = sin(_th);
                _a2[_k] = cos(_th) * _w + 0.42; _b2[_k] = sin(_th) * _w;
            }
            _S = { kind: "strip", xs: _a, ys: _b, xs2: _a2, ys2: _b2, closed: false }; break;
        case "spiral":
            var _n2 = _L ? 12 : 26, _p = array_create(_n2 + 1), _q = array_create(_n2 + 1), _p2 = array_create(_n2 + 1), _q2 = array_create(_n2 + 1);
            for (var _k = 0; _k <= _n2; _k++) {
                var _u = _k / _n2, _r = 0.22 + 0.8 * _u, _th = 2.4 * pi * _u, _hw = 0.13 * min(1, min(_u * 6, (1 - _u) * 6) + 0.25);
                var _cx = cos(_th) * _r, _cy = sin(_th) * _r, _nx = cos(_th), _ny = sin(_th);
                _p[_k] = _cx + _nx * _hw; _q[_k] = _cy + _ny * _hw; _p2[_k] = _cx - _nx * _hw; _q2[_k] = _cy - _ny * _hw;
            }
            _S = { kind: "strip", xs: _p, ys: _q, xs2: _p2, ys2: _q2, closed: false }; break;
        case "sequin":
            var _ns = _L ? 9 : 18, _o = hur__circle_pts(_ns, 0.9, 0.9, 0, 0, 0), _i = hur__circle_pts(_ns, 0.24, 0.24, 0, 0, 0);
            _S = { kind: "strip", xs: _o.xs, ys: _o.ys, xs2: _i.xs, ys2: _i.ys, closed: true }; break;
        case "petal":
            var _m = _L ? 8 : 20, _px = [], _py = [];
            for (var _k = 0; _k <= _m; _k++) { var _th = -pi / 2 - 2.05 + _k / _m * 4.1; array_push(_px, cos(_th) * 0.7); array_push(_py, sin(_th) * 0.62 - 0.3); }
            array_push(_px, 0); array_push(_py, 1.08);
            _S = { kind: "fan", xs: _px, ys: _py, cx: 0, cy: 0 }; break;
        case "balloon_round":
            var _br = hur__circle_pts(28, 0.9, 1, 0, -0.06, 0);
            for (var _k = 0; _k < 28; _k++) if (_br.ys[_k] > -0.06) _br.ys[_k] = -0.06 + (_br.ys[_k] + 0.06) * 1.1;
            _S = { kind: "fan", xs: _br.xs, ys: _br.ys, cx: 0, cy: -0.1, knot: 1.04 }; break;
        case "balloon_oval": var _bo = hur__circle_pts(28, 0.68, 1.08, 0, -0.02, 0); _S = { kind: "fan", xs: _bo.xs, ys: _bo.ys, cx: 0, cy: -0.05, knot: 1.06 }; break;
        case "balloon_heart": var _bh = hur__heart_pts(36, 1.08, -0.04); _S = { kind: "fan", xs: _bh.xs, ys: _bh.ys, cx: 0, cy: 0, knot: 0.94 }; break;
        case "balloon_star": var _bs = hur__star_pts(5, 1.12, 0.6, -pi / 2); _S = { kind: "fan", xs: _bs.xs, ys: _bs.ys, cx: 0, cy: 0, knot: 0.6 * sin(pi / 2) }; break;
        case "balloon_long":
            var _lx = [], _ly = [];
            for (var _k = 0; _k <= 12; _k++) { var _th = pi + _k / 12 * pi; array_push(_lx, cos(_th) * 0.34); array_push(_ly, sin(_th) * 0.34 - 0.9); }
            for (var _k = 0; _k <= 12; _k++) { var _th = _k / 12 * pi; array_push(_lx, cos(_th) * 0.34); array_push(_ly, sin(_th) * 0.34 + 0.9); }
            _S = { kind: "fan", xs: _lx, ys: _ly, cx: 0, cy: 0, knot: 1.24 }; break;
        case "gem_round": var _g8 = hur__circle_pts(8, 1, 1, 0, 0, pi / 8); _S = { kind: "fan", xs: _g8.xs, ys: _g8.ys, cx: 0, cy: 0 }; break;
        case "gem_emerald": _S = { kind: "fan", xs: [-0.5, 0.5, 0.74, 0.74, 0.5, -0.5, -0.74, -0.74], ys: [-1, -1, -0.76, 0.76, 1, 1, 0.76, -0.76], cx: 0, cy: 0 }; break;
        case "gem_heart": var _gh = hur__heart_pts(_L ? 12 : 24, 1.02, 0); _S = { kind: "fan", xs: _gh.xs, ys: _gh.ys, cx: 0, cy: 0.04 }; break;
        case "gem_marquise":
            var _mx = [], _my = [], _nm = _L ? 12 : 24;
            // a lens pointed at both ends: x = 0.62 sin t |sin t| reaches the tips with a finite slope (a point, not a round)
            for (var _k = 0; _k < _nm; _k++) { var _t = _k / _nm * pi * 2, _st = sin(_t); array_push(_mx, 0.62 * _st * abs(_st)); array_push(_my, -1.06 * cos(_t)); }
            _S = { kind: "fan", xs: _mx, ys: _my, cx: 0, cy: 0 }; break;
        case "gem_pear":
            var _r = 0.62, _ccy = 0.36, _d = 1.06 + _ccy, _ac = arccos(_r / _d), _ex = [0], _ey = [-1.06], _np = _L ? 9 : 18;
            for (var _k = 0; _k <= _np; _k++) { var _th = -pi / 2 + _ac + _k / _np * (pi * 2 - 2 * _ac); array_push(_ex, cos(_th) * _r); array_push(_ey, _ccy + sin(_th) * _r); }
            _S = { kind: "fan", xs: _ex, ys: _ey, cx: 0, cy: 0.3 }; break;
    }
    _cache[$ _key] = _S;
    return _S;
}

// ------------------------------------------------------------------------------------------------ palettes

/// @function hur_themes()
/// @description The six palette names.
function hur_themes() { return ["party", "gold", "royal", "pastel", "neon", "sakura"]; }

/// @function hur__rgb(r, g, b)
/// @description Internal. make_colour_rgb, clamped (no drawing; a colour is a number).
function hur__rgb(_r, _g, _b) { return make_colour_rgb(clamp(_r, 0, 255), clamp(_g, 0, 255), clamp(_b, 0, 255)); }

/// @function hur_theme(name)
/// @description A palette: { name, title, paper: [colours], foil: [colours], glow, ink, inkShadow, band, bandDark, bandLight,
/// trim, dark }. An array of colours makes a custom palette from your own colours; an unknown name gives "party".
function hur_theme(_name) {
    if (is_array(_name) && array_length(_name) > 0) {
        var _cs = [];
        for (var _i = 0; _i < array_length(_name); _i++) if (is_numeric(_name[_i])) array_push(_cs, _name[_i]);
        if (array_length(_cs) == 0) return hur_theme("party");
        var _T = hur_theme("party");
        _T.name = "custom"; _T.title = "Your colours"; _T.paper = _cs; _T.band = _cs[0]; _T.bandDark = merge_colour(_cs[0], c_black, 0.4); _T.bandLight = merge_colour(_cs[0], c_white, 0.4);
        return _T;
    }
    var _T = { name: "party", title: "Party", dark: false,
               paper: [hur__rgb(242, 62, 98), hur__rgb(255, 176, 36), hur__rgb(54, 198, 120), hur__rgb(56, 146, 240), hur__rgb(168, 86, 230), hur__rgb(255, 228, 72)],
               foil: [hur__rgb(242, 196, 80), hur__rgb(214, 220, 230)],
               glow: hur__rgb(255, 238, 170), ink: hur__rgb(255, 255, 255), inkShadow: hur__rgb(120, 20, 44),
               band: hur__rgb(226, 48, 76), bandDark: hur__rgb(140, 22, 46), bandLight: hur__rgb(255, 120, 140), trim: hur__rgb(255, 206, 84) };
    switch (_name) {
        case "gold":
            _T.name = "gold"; _T.title = "Gold gala";
            _T.paper = [hur__rgb(250, 214, 112), hur__rgb(236, 184, 66), hur__rgb(255, 242, 196), hur__rgb(206, 156, 58), hur__rgb(252, 248, 236), hur__rgb(186, 136, 40)];
            _T.foil = [hur__rgb(246, 200, 84), hur__rgb(255, 230, 150)];
            _T.glow = hur__rgb(255, 226, 140); _T.ink = hur__rgb(255, 222, 120); _T.inkShadow = hur__rgb(20, 16, 10);
            _T.band = hur__rgb(34, 32, 40); _T.bandDark = hur__rgb(14, 12, 18); _T.bandLight = hur__rgb(70, 66, 80); _T.trim = hur__rgb(240, 196, 80); break;
        case "royal":
            _T.name = "royal"; _T.title = "Royal";
            _T.paper = [hur__rgb(112, 52, 176), hur__rgb(226, 184, 62), hur__rgb(186, 30, 62), hur__rgb(58, 82, 196), hur__rgb(244, 236, 252)];
            _T.foil = [hur__rgb(236, 190, 70), hur__rgb(226, 230, 240)];
            _T.glow = hur__rgb(255, 230, 160); _T.ink = hur__rgb(255, 232, 150); _T.inkShadow = hur__rgb(40, 10, 60);
            _T.band = hur__rgb(98, 40, 152); _T.bandDark = hur__rgb(54, 18, 92); _T.bandLight = hur__rgb(150, 92, 206); _T.trim = hur__rgb(236, 192, 72); break;
        case "pastel":
            _T.name = "pastel"; _T.title = "Pastel";
            _T.paper = [hur__rgb(255, 168, 190), hur__rgb(166, 216, 255), hur__rgb(186, 238, 198), hur__rgb(255, 228, 156), hur__rgb(208, 188, 255), hur__rgb(255, 198, 158)];
            _T.foil = [hur__rgb(250, 214, 150), hur__rgb(232, 236, 244)];
            _T.glow = hur__rgb(255, 246, 220); _T.ink = hur__rgb(255, 255, 255); _T.inkShadow = hur__rgb(150, 80, 120);
            _T.band = hur__rgb(244, 132, 168); _T.bandDark = hur__rgb(196, 84, 124); _T.bandLight = hur__rgb(255, 196, 214); _T.trim = hur__rgb(255, 255, 255); break;
        case "neon":
            _T.name = "neon"; _T.title = "Neon"; _T.dark = true;
            _T.paper = [hur__rgb(255, 44, 182), hur__rgb(40, 236, 255), hur__rgb(180, 255, 44), hur__rgb(255, 232, 44), hur__rgb(152, 84, 255)];
            _T.foil = [hur__rgb(80, 250, 255), hur__rgb(255, 120, 230)];
            _T.glow = hur__rgb(120, 240, 255); _T.ink = hur__rgb(160, 250, 255); _T.inkShadow = hur__rgb(150, 0, 120);
            _T.band = hur__rgb(30, 18, 60); _T.bandDark = hur__rgb(12, 6, 30); _T.bandLight = hur__rgb(70, 44, 120); _T.trim = hur__rgb(255, 60, 200); break;
        case "sakura":
            _T.name = "sakura"; _T.title = "Sakura";
            _T.paper = [hur__rgb(255, 178, 200), hur__rgb(255, 214, 226), hur__rgb(250, 248, 250), hur__rgb(238, 136, 168), hur__rgb(204, 112, 156)];
            _T.foil = [hur__rgb(250, 224, 230), hur__rgb(240, 200, 120)];
            _T.glow = hur__rgb(255, 236, 244); _T.ink = hur__rgb(255, 255, 255); _T.inkShadow = hur__rgb(130, 40, 76);
            _T.band = hur__rgb(196, 58, 98); _T.bandDark = hur__rgb(120, 28, 60); _T.bandLight = hur__rgb(240, 130, 160); _T.trim = hur__rgb(255, 232, 238); break;
    }
    return _T;
}

/// @function hur__metal(form)
/// @description Internal. A coin's metal ramp { face, light, dark, edge }.
function hur__metal(_f) {
    switch (_f) {
        case "coin_silver": return { face: hur__rgb(196, 204, 214), light: hur__rgb(250, 252, 255), dark: hur__rgb(112, 120, 134), edge: hur__rgb(150, 158, 172) };
        case "coin_copper": return { face: hur__rgb(206, 118, 70), light: hur__rgb(252, 186, 136), dark: hur__rgb(122, 58, 30), edge: hur__rgb(160, 84, 46) };
    }
    return { face: hur__rgb(236, 186, 62), light: hur__rgb(255, 240, 160), dark: hur__rgb(156, 104, 22), edge: hur__rgb(184, 128, 30) };
}

/// @function hur__gem_colours()
/// @description Internal. Ruby, sapphire, emerald, amethyst, topaz, diamond.
function hur__gem_colours() { return [hur__rgb(222, 30, 62), hur__rgb(40, 92, 222), hur__rgb(30, 172, 92), hur__rgb(152, 70, 204), hur__rgb(244, 172, 40), hur__rgb(212, 236, 252)]; }

// ------------------------------------------------------------------------------------------------ the world

/// @function hur_world_create([options])
/// @description A world that holds every live celebration. Options (all optional): seed, theme (a name or an array of
/// colours), budget (most pieces alive at once, default 400 - extra pieces are thinned, never queued), floor (a y where
/// coins pile and confetti settles; undefined = no floor, pieces fall away), bounds ([x0, y0, x1, y1], where falls start and
/// past which pieces retire; default the room).
function hur_world_create(_o = undefined) {
    var _b = hur__opt(_o, "bounds", undefined);
    if (!is_array(_b) || array_length(_b) < 4) _b = [0, 0, room_width, room_height];
    var _fl = hur__opt(_o, "floor", undefined);
    if (!is_undefined(_fl)) _fl = hur__num(_fl, undefined, -100000, 100000);
    var _W = { version: HUR_VERSION, pieces: [], emitters: [], events: [], pending: [],
               theme: hur_theme(hur__opt(_o, "theme", "party")), budget: floor(hur__num(hur__opt(_o, "budget", HUR_BUDGET), HUR_BUDGET, 0, 20000)),
               floorY: _fl, bounds: [hur__num(_b[0], 0, -100000, 100000), hur__num(_b[1], 0, -100000, 100000), hur__num(_b[2], room_width, -100000, 100000), hur__num(_b[3], room_height, -100000, 100000)],
               paused: false, time: 0, rng: hur_rng(hur__num(hur__opt(_o, "seed", 1), 1, 0, 2147483000)), nextId: 1, handles: {},
               pile: array_create(64, 0), pileW: 1, stats: { spawned: 0, thinned: 0, retired: 0, arrived: 0, peak: 0 }, vb: undefined };
    _W.pileW = max(1, (_W.bounds[2] - _W.bounds[0]) / 64);
    return _W;
}

/// @function hur__is_world(w)
/// @description Internal. True for a struct made by hur_world_create.
function hur__is_world(_W) { return is_struct(_W) && variable_struct_exists(_W, "pieces") && variable_struct_exists(_W, "emitters") && variable_struct_exists(_W, "budget"); }

/// @function hur_world_pause(world, paused)
/// @description Freeze (true) or resume (false) a world. A paused world keeps drawing exactly where it stopped.
function hur_world_pause(_W, _p) { if (hur__is_world(_W)) _W.paused = (_p == true); }

/// @function hur_world_count(world)
/// @description Live pieces in a world (0 for anything that is not one).
function hur_world_count(_W) { return hur__is_world(_W) ? array_length(_W.pieces) : 0; }

/// @function hur_world_events(world)
/// @description The events of the last hur_world_step: an array of structs, { type: "arrive", id, form, value, x, y } when a
/// coin or gem sent by hur_shower_to reaches its target, and { type: "done", id } when everything one hur_fire call made has
/// retired. The same array until the next step; empty for anything that is not a world.
function hur_world_events(_W) { return hur__is_world(_W) ? _W.events : []; }

/// @function hur_world_clear(world)
/// @description Retire every piece and emitter at once (no events).
function hur_world_clear(_W) {
    if (!hur__is_world(_W)) return;
    _W.pieces = []; _W.emitters = []; _W.events = []; _W.pending = []; _W.handles = {};
    for (var _i = 0; _i < array_length(_W.pile); _i++) _W.pile[_i] = 0;
}

/// @function hur__handle_add(W, id, n)
/// @description Internal. Count n pieces or emitters against a handle.
function hur__handle_add(_W, _id, _n) { var _k = string(_id); _W.handles[$ _k] = (variable_struct_exists(_W.handles, _k) ? _W.handles[$ _k] : 0) + _n; }

/// @function hur__handle_sub(W, id)
/// @description Internal. One piece or emitter of a handle retired; a "done" event when it was the last.
function hur__handle_sub(_W, _id) {
    var _k = string(_id);
    if (!variable_struct_exists(_W.handles, _k)) return;
    var _n = _W.handles[$ _k] - 1;
    if (_n <= 0) { variable_struct_remove(_W.handles, _k); array_push(_W.pending, { type: "done", id: _id }); }
    else _W.handles[$ _k] = _n;
}

/// @function hur__allow(W, n)
/// @description Internal. How many of n new pieces fit under the budget; the rest are thinned and counted.
function hur__allow(_W, _n) {
    var _room = max(0, _W.budget - array_length(_W.pieces));
    var _ok = min(_n, _room);
    if (_ok < _n) _W.stats.thinned += _n - _ok;
    return _ok;
}

/// @function hur__piece(W, h, form, x, y, vx, vy, size, col, col2)
/// @description Internal. A new piece with the fields every family shares; added to the world and counted on its handle.
function hur__piece(_W, _h, _form, _x, _y, _vx, _vy, _size, _col, _col2) {
    var _g = _W.rng;
    var _P = { h: _h, form: _form, fam: hur_form_family(_form), x: _x, y: _y, vx: _vx, vy: _vy, size: _size, col: _col, col2: _col2,
               rot: hur__range(_g, 0, pi * 2), vr: hur__range(_g, -6, 6), ph: hur__range(_g, 0, pi * 2), vph: hur__range(_g, 5, 13),
               age: 0, life: 6, alpha: 1, rest: false, restT: 0, foil: false, seed: hur_rand(_g) * 1000, layer: 2,
               tx: 0, ty: 0, homing: false, value: 0, delay: 0, age0: 0, fc: 0, pk: 0, swf: 2.4 };
    // numeric codes, set once, so the per-frame step and draw never compare strings
    switch (_P.fam) { case "streamer": _P.fc = 1; break; case "balloon": _P.fc = 2; break; case "coin": _P.fc = 3; break; case "gem": _P.fc = 4; break; case "burst": _P.fc = 5; break; case "banner": _P.fc = 6; break; case "launcher": _P.fc = 7; break; }
    _P.pk = (_form == "feather") ? 2 : ((_form == "petal") ? 1 : 0);
    _P.swf = 2.2 + hur_rand(_g) * 1.6;
    array_push(_W.pieces, _P);
    _W.stats.spawned += 1;
    hur__handle_add(_W, _h, 1);
    return _P;
}

/// @function hur__paper(W, T, P, foilChance)
/// @description Internal. A paper colour and its back-face colour, drawn from a palette (foil sometimes).
function hur__paper(_W, _T, _P, _foilChance) {
    var _g = _W.rng;
    if (hur_rand(_g) < _foilChance) { _P.foil = true; _P.col = hur__pick(_g, _T.foil); _P.col2 = merge_colour(_P.col, c_black, 0.35); }
    else { _P.col = hur__pick(_g, _T.paper); _P.col2 = merge_colour(merge_colour(_P.col, c_white, 0.38), c_black, 0.1); }
}

// ------------------------------------------------------------------------------------------------ firing

/// @function hur_presets()
/// @description The moment presets: levelup, win, record, chest, achievement, birthday, jackpot, petals.
function hur_presets() { return ["levelup", "win", "record", "chest", "achievement", "birthday", "jackpot", "petals"]; }

/// @function hur_kinds()
/// @description Every kind hur_fire accepts: the eight presets, then the building blocks (popper, cannon, fall, shower,
/// balloons, streamers, burst, banner).
function hur_kinds() { var _k = hur_presets(); array_push(_k, "popper", "cannon", "fall", "shower", "balloons", "streamers", "burst", "banner"); return _k; }

/// @function hur_fire(world, kind, x, y, [strength], [options])
/// @description Fire a celebration at (x, y). kind is a preset (levelup, win, record, chest, achievement, birthday, jackpot,
/// petals) or a building block (popper, cannon, fall, shower, balloons, streamers, burst, banner). strength 0.25..3 scales
/// how much is thrown and how hard (default 1). Options (all optional): theme (name or colour array, this call only), dir
/// (degrees, 90 = up), spread (degrees), forms (array of form names to throw), form (one form), text (a banner's words),
/// tx / ty (a target: coins and gems fly there and report "arrive" events), count, value (per coin), prop (true draws the
/// popper or cannon itself), width (a fall's or banner's width), hold (seconds a banner stays).
/// @returns {real} A handle (watch for its "done" event), or -1 when refused (not a world, unknown kind, bad position).
function hur_fire(_W, _kind, _x, _y, _str = 1, _o = undefined) {
    if (!hur__is_world(_W) || !is_string(_kind)) return -1;
    if (!is_numeric(_x) || !is_numeric(_y)) return -1;
    var _px = real(_x), _py = real(_y);
    if (_px != _px || _py != _py || abs(_px) > 100000 || abs(_py) > 100000) return -1;
    var _s = hur__num(_str, 1, 0.25, 3);
    var _ok = false, _kinds = hur_kinds();
    for (var _i = 0; _i < array_length(_kinds); _i++) if (_kinds[_i] == _kind) _ok = true;
    if (!_ok) return -1;
    var _id = _W.nextId; _W.nextId += 1;
    var _T = is_undefined(hur__opt(_o, "theme", undefined)) ? _W.theme : hur_theme(hur__opt(_o, "theme", "party"));
    hur__handle_add(_W, _id, 1);   // held until the call has finished spawning
    hur__fire_kind(_W, _id, _kind, _px, _py, _s, _o, _T);
    hur__handle_sub(_W, _id);
    return _id;
}

/// @function hur__emitter(W, id, kind, x, y, dur, rate, s, o, T)
/// @description Internal. A timed spawner: rate pieces a second for dur seconds (falls, cannons, showers, balloon releases).
function hur__emitter(_W, _id, _kind, _x, _y, _dur, _rate, _s, _o, _T) {
    array_push(_W.emitters, { h: _id, kind: _kind, x: _x, y: _y, dur: _dur, rate: _rate, acc: 0.999, t: 0, s: _s, o: _o, T: _T });
    hur__handle_add(_W, _id, 1);
}

/// @function hur__fire_kind(W, id, kind, x, y, s, o, T)
/// @description Internal. What each kind throws. Presets are compositions of the building blocks.
function hur__fire_kind(_W, _id, _kind, _x, _y, _s, _o, _T) {
    var _B = _W.bounds, _cx = (_B[0] + _B[2]) / 2, _w = _B[2] - _B[0], _bh = _B[3] - _B[1];
    var _ground = (is_undefined(_W.floorY) ? _B[3] : min(_B[3], _W.floorY)) - 6;   // the corner cannons stand on the floor, never under it
    switch (_kind) {
        case "popper": hur__spawn_paper(_W, _id, _x, _y, floor(46 * _s), hur__opt(_o, "dir", 90), hur__opt(_o, "spread", 34), 880 * sqrt(_s), hur__opt(_o, "forms", undefined), _T, _o); if (hur__opt(_o, "prop", false)) hur__spawn_prop(_W, _id, "popper", _x, _y, hur__opt(_o, "dir", 90), _T); break;
        case "cannon":
            hur__emitter(_W, _id, "cannon", _x, _y, 0.22, 420 * _s, _s, _o, _T);
            hur__spawn_streamers(_W, _id, _x, _y, max(1, floor(3 * _s)), hur__opt(_o, "dir", 90), 22, 980 * sqrt(_s), _T, undefined);
            if (hur__opt(_o, "prop", false)) hur__spawn_prop(_W, _id, "cannon", _x, _y, hur__opt(_o, "dir", 90), _T);
            break;
        case "fall": hur__emitter(_W, _id, "fall", _x, _y, hur__opt(_o, "dur", 3.2), 70 * _s, _s, _o, _T); break;
        case "shower": hur__emitter(_W, _id, "shower", _x, _y, 0.5, 60 * _s, _s, _o, _T); break;
        case "balloons": hur__emitter(_W, _id, "balloons", _x, _y, 1.4, 6 * _s, _s, _o, _T); break;
        case "streamers": hur__spawn_streamers(_W, _id, _x, _y, max(1, floor(7 * _s)), hur__opt(_o, "dir", 90), hur__opt(_o, "spread", 50), 860 * sqrt(_s), _T, hur__opt(_o, "form", undefined)); break;
        case "burst": hur__spawn_burst(_W, _id, hur__opt(_o, "form", "starburst"), _x, _y, _s, _T); break;
        case "banner": hur__spawn_banner(_W, _id, hur__opt(_o, "form", "banner_ribbon"), hur__opt(_o, "text", "HURRAH!"), _x, _y, _s, _o, _T); break;
        case "levelup":
            hur__spawn_burst(_W, _id, "rays", _x, _y, _s, _T);
            hur__spawn_burst(_W, _id, "flash", _x, _y, _s, _T);
            hur__spawn_burst(_W, _id, "starburst", _x, _y, _s, _T);
            hur__spawn_burst(_W, _id, "sparkle", _x, _y, _s, _T);
            hur__spawn_paper(_W, _id, _x, _y, floor(60 * _s), 90, 70, 950 * sqrt(_s), ["square", "strip", "star", "dot"], _T, _o);
            if (!is_undefined(hur__opt(_o, "text", undefined))) hur__spawn_banner(_W, _id, "banner_ribbon", _o.text, _x, _y + 74 * _s, _s, _o, _T);
            break;
        case "win":
            hur__emitter(_W, _id, "cannon", _B[0] + _w * 0.04, _ground, 0.3, 360 * _s, _s, { dir: 68, spread: 16 }, _T);
            hur__emitter(_W, _id, "cannon", _B[2] - _w * 0.04, _ground, 0.3, 360 * _s, _s, { dir: 112, spread: 16 }, _T);
            hur__spawn_streamers(_W, _id, _B[0] + _w * 0.04, _ground, max(1, floor(4 * _s)), 66, 14, 1300 * sqrt(_s), _T, undefined);
            hur__spawn_streamers(_W, _id, _B[2] - _w * 0.04, _ground, max(1, floor(4 * _s)), 114, 14, 1300 * sqrt(_s), _T, undefined);
            hur__emitter(_W, _id, "fall", _cx, _B[1], 2.6, 40 * _s, _s, { form: "ticker", width: _w }, _T);
            if (!is_undefined(hur__opt(_o, "text", undefined))) hur__spawn_banner(_W, _id, "banner_ribbon", _o.text, _x, _y, _s, _o, _T);
            break;
        case "record":
            hur__spawn_burst(_W, _id, "rays", _x, _y, _s * 1.1, _T);
            hur__spawn_burst(_W, _id, "ring", _x, _y, _s, _T);
            hur__spawn_burst(_W, _id, "sparkle", _x, _y, _s * 1.3, _T);
            hur__spawn_burst(_W, _id, "flash", _x, _y, _s, _T);
            hur__spawn_burst(_W, _id, "starburst", _x, _y, _s * 1.2, _T);
            hur__emitter(_W, _id, "fall", _cx, _B[1], 2.4, 46 * _s, _s, { form: "sequin", width: _w }, _T);
            if (!is_undefined(hur__opt(_o, "text", undefined))) hur__spawn_banner(_W, _id, "banner_scroll", _o.text, _x, _y + 70 * _s, _s, _o, _T);
            break;
        case "chest":
            hur__spawn_burst(_W, _id, "flash", _x, _y, _s * 0.8, _T);
            hur__spawn_burst(_W, _id, "rays", _x, _y, _s * 0.7, _T);
            hur__spawn_burst(_W, _id, "sparkle", _x, _y - 30, _s, _T);
            hur__emitter(_W, _id, "shower", _x, _y, 0.6, 70 * _s, _s, _o, _T);
            break;
        case "achievement":
            hur__spawn_burst(_W, _id, "rays", _x, _y, _s * 0.9, _T);
            hur__spawn_banner(_W, _id, "banner_rosette", hur__opt(_o, "text", "1st"), _x, _y, _s * 1.3, _o, _T);
            hur__spawn_burst(_W, _id, "sparkle", _x, _y, _s * 1.5, _T);
            hur__spawn_burst(_W, _id, "ring", _x, _y, _s, _T);
            hur__spawn_paper(_W, _id, _x, _y, floor(64 * _s), 90, 170, 850 * sqrt(_s), ["star", "dot", "diamond", "flower"], _T, _o);
            break;
        case "birthday":
            hur__emitter(_W, _id, "balloons", _x, _B[3] + 60, 1.6, 7 * _s, _s, { width: _w * 0.8 }, _T);
            hur__spawn_streamers(_W, _id, _x, _y, max(1, floor(5 * _s)), 90, 70, 760 * sqrt(_s), _T, undefined);
            hur__spawn_paper(_W, _id, _x, _y, floor(56 * _s), 90, 60, 900 * sqrt(_s), ["heart", "star", "square", "spiral", "crescent"], _T, _o);
            if (!is_undefined(hur__opt(_o, "text", undefined))) hur__spawn_banner(_W, _id, "banner_bunting", _o.text, _cx, _B[1] + _bh * 0.16, _s, { width: _w * 0.78 }, _T);
            break;
        case "jackpot":
            hur__spawn_burst(_W, _id, "rays", _x, _y, _s * 1.2, _T);
            hur__spawn_burst(_W, _id, "flash", _x, _y, _s, _T);
            hur__spawn_burst(_W, _id, "starburst", _x, _y, _s, _T);
            hur__emitter(_W, _id, "shower", _x, _y, 1.2, 80 * _s, _s, _o, _T);
            break;
        case "petals":
            hur__emitter(_W, _id, "fall", _cx, _B[1], 4.2, 46 * _s, _s, { form: "petal", width: _w }, _T);
            hur__emitter(_W, _id, "fall", _cx, _B[1], 3.6, 7 * _s, _s, { form: "feather", width: _w }, _T);
            hur__spawn_burst(_W, _id, "sparkle", _x, _y, _s, _T);
            break;
    }
}

/// @function hur_banner(world, text, x, y, [form], [options])
/// @description A banner behind your words: form banner_ribbon (default), banner_scroll, banner_bunting or banner_rosette.
/// It unfurls, holds for options.hold seconds (default 2.6), then folds away. Options: theme, width (bunting span), font
/// (your font resource; default the shipped display face), hold. Returns a handle, or -1 when refused.
function hur_banner(_W, _text, _x, _y, _form = "banner_ribbon", _o = undefined) {
    if (!hur__is_world(_W) || !is_string(_text) || hur_form_family(_form) != "banner") return -1;
    var _oo = is_struct(_o) ? _o : {};
    var _o2 = { form: _form, text: _text };
    var _keys = variable_struct_get_names(_oo);
    for (var _i = 0; _i < array_length(_keys); _i++) if (_keys[_i] != "form" && _keys[_i] != "text") _o2[$ _keys[_i]] = _oo[$ _keys[_i]];
    return hur_fire(_W, "banner", _x, _y, hur__opt(_oo, "strength", 1), _o2);
}

/// @function hur_shower_to(world, x, y, tx, ty, count, [options])
/// @description Burst count coins (and gems, if options.gems > 0) up from (x, y) that arc, then fly into (tx, ty) - your score
/// counter - each reporting an "arrive" event with its value (options.value, default 1) as it lands. Options: forms (array of
/// coin / gem forms), gems (0..1, share of gems), value, theme. Returns a handle, or -1 when refused.
function hur_shower_to(_W, _x, _y, _tx, _ty, _count, _o = undefined) {
    if (!hur__is_world(_W) || !is_numeric(_tx) || !is_numeric(_ty) || !is_numeric(_count)) return -1;
    var _ttx = real(_tx), _tty = real(_ty);
    if (_ttx != _ttx || _tty != _tty) return -1;
    var _n = floor(hur__num(_count, 0, 0, 2000));
    var _oo = is_struct(_o) ? _o : {};
    var _o2 = { tx: _ttx, ty: _tty, count: _n };
    var _keys = variable_struct_get_names(_oo);
    for (var _i = 0; _i < array_length(_keys); _i++) if (_keys[_i] != "tx" && _keys[_i] != "ty" && _keys[_i] != "count") _o2[$ _keys[_i]] = _oo[$ _keys[_i]];
    return hur_fire(_W, "shower", _x, _y, 1, _o2);
}

// ------------------------------------------------------------------------------------------------ spawners

/// @function hur__spawn_paper(W, id, x, y, n, dir, spread, speed, forms, T, o)
/// @description Internal. n confetti pieces thrown from (x, y) in a cone.
function hur__spawn_paper(_W, _id, _x, _y, _n, _dir, _spread, _speed, _forms, _T, _o) {
    var _g = _W.rng, _cuts = is_array(_forms) ? _forms : hur_forms("confetti");
    var _okc = [];
    for (var _i = 0; _i < array_length(_cuts); _i++) if (hur_form_family(_cuts[_i]) == "confetti" || hur_form_family(_cuts[_i]) == "fall") array_push(_okc, _cuts[_i]);
    if (array_length(_okc) == 0) _okc = hur_forms("confetti");
    var _m = hur__allow(_W, _n), _d = hur__num(_dir, 90, -100000, 100000), _sp = hur__num(_spread, 30, 0, 360);
    for (var _i = 0; _i < _m; _i++) {
        var _a = degtorad(_d + hur__range(_g, -_sp, _sp) * 0.5 * 2 * (0.35 + 0.65 * hur_rand(_g)));
        var _v = _speed * hur__range(_g, 0.45, 1.1);
        var _f = hur__pick(_g, _okc);
        var _P = hur__piece(_W, _id, _f, _x, _y, cos(_a) * _v, -sin(_a) * _v, hur__range(_g, 5, 9), c_white, c_white);
        hur__paper(_W, _T, _P, 0.16);
        if (_f == "strip") _P.size *= 0.9;
        _P.life = hur__range(_g, 4.5, 6.5); _P.layer = 3;
    }
}

/// @function hur__spawn_streamers(W, id, x, y, n, dir, spread, speed, T, form)
/// @description Internal. n streamers thrown from (x, y): each a rope of 12 nodes whose head flies and whose tail follows.
function hur__spawn_streamers(_W, _id, _x, _y, _n, _dir, _spread, _speed, _T, _form) {
    var _g = _W.rng, _m = hur__allow(_W, _n);
    for (var _i = 0; _i < _m; _i++) {
        var _f = (is_string(_form) && hur_form_family(_form) == "streamer") ? _form : hur__pick(_g, ["ribbon", "serpentine", "zigzag", "twist", "tinsel"]);
        var _a = degtorad(_dir + hur__range(_g, -_spread, _spread) * 0.5);
        var _v = _speed * hur__range(_g, 0.7, 1.05);
        var _P = hur__piece(_W, _id, _f, _x, _y, cos(_a) * _v, -sin(_a) * _v, hur__range(_g, 5, 7), c_white, c_white);
        hur__paper(_W, _T, _P, (_f == "tinsel") ? 1 : 0.1);
        var _N = 12, _len = hur__range(_g, 150, 230);
        _P.nx = array_create(_N, _x); _P.ny = array_create(_N, _y); _P.nvx = array_create(_N, 0); _P.nvy = array_create(_N, 0);
        _P.seg = _len / (_N - 1); _P.life = hur__range(_g, 4.5, 6); _P.layer = 2;
        _P.twist = hur__range(_g, 0.35, 0.8) * ((_f == "twist") ? 2.2 : 1);
    }
}

/// @function hur__spawn_balloon(W, id, x, y, T, o)
/// @description Internal. One balloon released at (x, y), with a 7-node string hanging from its knot.
function hur__spawn_balloon(_W, _id, _x, _y, _T, _o) {
    var _g = _W.rng;
    if (hur__allow(_W, 1) < 1) return;
    var _forms = hur__opt(_o, "forms", undefined);
    var _f = is_array(_forms) ? hur__pick(_g, _forms) : hur__pick(_g, ["balloon_round", "balloon_round", "balloon_oval", "balloon_heart", "balloon_star", "balloon_long"]);
    if (hur_form_family(_f) != "balloon") _f = "balloon_round";
    var _P = hur__piece(_W, _id, _f, _x, _y, hur__range(_g, -30, 30), hur__range(_g, -150, -90), hur__range(_g, 26, 38), c_white, c_white);
    _P.col = (_f == "balloon_star") ? hur__pick(_g, _T.foil) : hur__pick(_g, _T.paper);
    _P.foil = (_f == "balloon_star");
    _P.col2 = merge_colour(_P.col, c_black, 0.4);
    _P.rot = 0; _P.vr = 0; _P.life = 16; _P.layer = 1;
    var _N = 7;
    _P.nx = array_create(_N, _x); _P.ny = array_create(_N, _y); _P.nvx = array_create(_N, 0); _P.nvy = array_create(_N, 0);
    for (var _k = 0; _k < _N; _k++) _P.ny[_k] = _y + _P.size * 1.1 + _k * 9;
    _P.seg = 9 + _P.size * 0.12;
}

/// @function hur__spawn_coin(W, id, x, y, T, o)
/// @description Internal. One coin or gem thrown up from (x, y); with o.tx / o.ty it homes into that target after its arc.
function hur__spawn_coin(_W, _id, _x, _y, _T, _o) {
    var _g = _W.rng;
    // a coin sent to a target carries value the game counts, so it is never thinned by the budget
    if (is_undefined(hur__opt(_o, "tx", undefined)) && hur__allow(_W, 1) < 1) return;
    var _forms = hur__opt(_o, "forms", undefined), _f;
    if (is_array(_forms) && array_length(_forms) > 0) _f = hur__pick(_g, _forms);
    else _f = (hur_rand(_g) < hur__num(hur__opt(_o, "gems", 0.22), 0.22, 0, 1)) ? hur__pick(_g, hur_forms("gem")) : hur__pick(_g, ["coin_gold", "coin_gold", "coin_gold", "coin_silver", "coin_copper"]);
    var _fam = hur_form_family(_f);
    if (_fam != "coin" && _fam != "gem") _f = "coin_gold";
    var _a = degtorad(90 + hur__range(_g, -38, 38)), _v = hur__range(_g, 520, 860);
    var _P = hur__piece(_W, _id, _f, _x, _y, cos(_a) * _v, -sin(_a) * _v, hur__range(_g, 9, 13), c_white, c_white);
    if (hur_form_family(_f) == "gem") { _P.col = hur__pick(_g, hur__gem_colours()); _P.size *= 1.12; _P.vph = hur__range(_g, 2, 4); } else { _P.col = c_white; _P.vph = hur__range(_g, 7, 14); }
    _P.life = 9; _P.layer = 2;
    if (!is_undefined(hur__opt(_o, "tx", undefined))) {
        _P.homing = true; _P.tx = _o.tx; _P.ty = _o.ty; _P.value = hur__num(hur__opt(_o, "value", 1), 1, -1000000, 1000000);
        _P.delay = hur__range(_g, 0.28, 0.5); _P.life = 6;
    }
}

/// @function hur__spawn_fall(W, id, x, width, y, form, T)
/// @description Internal. One falling piece entering from above the top edge, somewhere across width.
function hur__spawn_fall(_W, _id, _x, _width, _y, _form, _T) {
    var _g = _W.rng;
    if (hur__allow(_W, 1) < 1) return;
    var _f = (hur_form_family(_form) == "fall" || hur_form_family(_form) == "confetti") ? _form : "ticker";
    var _P = hur__piece(_W, _id, _f, _x + hur__range(_g, -0.5, 0.5) * _width, _y - hur__range(_g, 10, 60), hur__range(_g, -20, 20), hur__range(_g, 40, 110), hur__range(_g, 6, 9), c_white, c_white);
    hur__paper(_W, _T, _P, (_f == "sequin") ? 1 : 0.12);
    _P.life = 9; _P.layer = 3;
    switch (_f) {
        case "ticker": _P.size = hur__range(_g, 8, 12); _P.vph = hur__range(_g, 6, 11); break;
        case "petal": _P.size = hur__range(_g, 11, 16); _P.col = merge_colour(hur__pick(_g, _T.paper), c_white, 0.15); _P.col2 = merge_colour(_P.col, c_white, 0.35); _P.vph = hur__range(_g, 2, 4.5); _P.vy *= 0.6; _P.foil = false; break;
        case "feather": _P.size = hur__range(_g, 20, 28); _P.col = merge_colour(hur__pick(_g, _T.paper), c_white, 0.55); _P.col2 = merge_colour(_P.col, c_black, 0.18); _P.vph = hur__range(_g, 1.2, 2.2); _P.vy *= 0.4; _P.foil = false; _P.layer = 2; break;
        case "sequin": _P.size = hur__range(_g, 6, 9); _P.vph = hur__range(_g, 8, 16); break;
    }
}

/// @function hur__spawn_burst(W, id, form, x, y, s, T)
/// @description Internal. A burst: rays, ring and flash are single timed pieces; starburst flings 9-14 star sparks; sparkle
/// scatters 10-16 twinkles round the point.
function hur__spawn_burst(_W, _id, _form, _x, _y, _s, _T) {
    var _g = _W.rng;
    switch (_form) {
        case "rays": if (hur__allow(_W, 1) > 0) { var _P = hur__piece(_W, _id, "rays", _x, _y, 0, 0, 150 * _s, _T.glow, _T.trim); _P.life = 1.9; _P.layer = 0; _P.vr = 0.35; } break;
        case "ring": if (hur__allow(_W, 1) > 0) { var _P = hur__piece(_W, _id, "ring", _x, _y, 0, 0, 170 * _s, _T.glow, _T.trim); _P.life = 0.7; _P.layer = 0; } break;
        case "flash": if (hur__allow(_W, 1) > 0) { var _P = hur__piece(_W, _id, "flash", _x, _y, 0, 0, 130 * _s, _T.glow, c_white); _P.life = 0.4; _P.layer = 0; } break;
        case "starburst":
            var _n = hur__allow(_W, floor(hur__range(_g, 9, 14) * min(2, _s)));
            for (var _i = 0; _i < _n; _i++) {
                var _a = _i / max(1, _n) * pi * 2 + hur__range(_g, -0.2, 0.2), _v = hur__range(_g, 300, 520) * sqrt(_s);
                var _P = hur__piece(_W, _id, "starburst", _x, _y, cos(_a) * _v, sin(_a) * _v, hur__range(_g, 6, 10) * min(1.6, sqrt(_s)), hur__pick(_g, _T.foil), _T.glow);
                _P.life = hur__range(_g, 0.8, 1.2); _P.layer = 4;
            }
            break;
        case "sparkle":
            var _n2 = hur__allow(_W, floor(hur__range(_g, 10, 16) * min(2, _s)));
            for (var _i = 0; _i < _n2; _i++) {
                var _a = hur__range(_g, 0, pi * 2), _r = hur__range(_g, 0.25, 1) * 110 * _s;
                var _P = hur__piece(_W, _id, "sparkle", _x + cos(_a) * _r, _y + sin(_a) * _r * 0.8, 0, -hur__range(_g, 0, 30), hur__range(_g, 7, 15), _T.glow, c_white);
                _P.life = hur__range(_g, 0.7, 1.4); _P.delay = hur__range(_g, 0, 0.5); _P.layer = 4; _P.rot = hur__range(_g, -0.3, 0.3); _P.vr = hur__range(_g, -1, 1);
            }
            break;
    }
}

/// @function hur__spawn_banner(W, id, form, text, x, y, s, o, T)
/// @description Internal. A banner piece: it unfurls over 0.45 s, holds, folds away.
function hur__spawn_banner(_W, _id, _form, _text, _x, _y, _s, _o, _T) {
    if (hur__allow(_W, 1) < 1) return;
    var _f = (hur_form_family(_form) == "banner") ? _form : "banner_ribbon";
    var _P = hur__piece(_W, _id, _f, _x, _y, 0, 0, 1 * _s, _T.band, _T.bandDark);
    _P.text = is_string(_text) ? _text : string(_text);
    _P.T = _T; _P.rot = 0; _P.vr = 0;
    _P.hold = hur__num(hur__opt(_o, "hold", 2.6), 2.6, 0.2, 600);
    _P.life = 0.45 + _P.hold + 0.5;
    _P.width = hur__num(hur__opt(_o, "width", 0), 0, 0, 100000);
    _P.font = hur__opt(_o, "font", undefined);
    _P.layer = 2;
}

/// @function hur__spawn_prop(W, id, form, x, y, dir, T)
/// @description Internal. The popper or cannon drawn at the firing point, recoiling, then fading.
function hur__spawn_prop(_W, _id, _form, _x, _y, _dir, _T) {
    if (hur__allow(_W, 1) < 1) return;
    var _P = hur__piece(_W, _id, _form, _x, _y, 0, 0, (_form == "cannon") ? 34 : 26, _T.paper[0], _T.trim);
    _P.rot = degtorad(_dir); _P.vr = 0; _P.life = 1.3; _P.layer = 2; _P.T = _T;
}

// ------------------------------------------------------------------------------------------------ the step

/// @function hur_world_step(world, [dt])
/// @description Advance a world by dt seconds (default: this frame's delta_time, capped at 0.05 so a hitch cannot fling
/// pieces through the floor). Runs every emitter, moves every piece, retires the finished ones, and fills hur_world_events.
function hur_world_step(_W, _dt = undefined) {
    if (!hur__is_world(_W)) return;
    _W.events = _W.pending; _W.pending = [];
    if (_W.paused) return;
    var _d = is_undefined(_dt) ? clamp(delta_time / 1000000, 0, HUR_DT_MAX) : hur__num(_dt, 0, 0, HUR_DT_MAX);
    if (_d <= 0) return;
    _W.time += _d;
    // emitters
    for (var _e = array_length(_W.emitters) - 1; _e >= 0; _e--) {
        var _E = _W.emitters[_e];
        _E.t += _d;
        _E.acc += _E.rate * _d;
        var _n = floor(_E.acc); _E.acc -= _n;
        if (_E.kind == "shower" && !is_undefined(hur__opt(_E.o, "count", undefined))) {
            if (!variable_struct_exists(_E, "left")) _E.left = floor(_E.o.count);
            _n = min(_E.left, max(_n, ceil(_E.left * _d / max(0.05, _E.dur - _E.t + _d))));
            _E.left -= _n;
        }
        repeat (_n) hur__emit_one(_W, _E);
        var _finished = (_E.kind == "shower" && variable_struct_exists(_E, "left")) ? (_E.left <= 0) : (_E.t >= _E.dur);
        if (_finished) { array_delete(_W.emitters, _e, 1); hur__handle_sub(_W, _E.h); }
    }
    // pieces
    var _B = _W.bounds, _fl = _W.floorY, _live = [];
    for (var _i = 0; _i < array_length(_W.pieces); _i++) {
        var _P = _W.pieces[_i];
        _P.age += _d;
        if (_P.delay > 0 && !_P.homing) { _P.delay -= _d; if (_P.delay <= 0) _P.age0 = _P.age; array_push(_live, _P); continue; }
        var _fc = _P.fc;
        switch (_fc) {
            case 0: hur__step_paper(_W, _P, _d, _fl); break;
            case 1: hur__step_streamer(_W, _P, _d, _fl); break;
            case 2: hur__step_balloon(_W, _P, _d); break;
            case 3: case 4: hur__step_coin(_W, _P, _d, _fl); break;
            case 5: if (_P.form == "starburst") { var _k = power(0.04, _d); _P.vx *= _k; _P.vy *= _k; _P.vy += 120 * _d; _P.x += _P.vx * _d; _P.y += _P.vy * _d; } else { _P.x += _P.vx * _d; _P.y += _P.vy * _d; } _P.rot += _P.vr * _d; break;
            default: break;
        }
        // retire
        var _out = (_P.age >= _P.life);
        if (_fc < 5) {
            if (_P.y > _B[3] + 260 || _P.y < _B[1] - 900 || _P.x < _B[0] - 600 || _P.x > _B[2] + 600) _out = true;
            if (_fc != 2) _P.alpha = clamp((_P.life - _P.age) / 0.6, 0, 1);
        }
        if (_out) {
            if (_P.homing) { array_push(_W.pending, { type: "arrive", id: _P.h, form: _P.form, value: _P.value, x: _P.tx, y: _P.ty }); _W.stats.arrived += 1; }
            _W.stats.retired += 1; hur__handle_sub(_W, _P.h);
        } else array_push(_live, _P);
    }
    _W.pieces = _live;
    _W.stats.peak = max(_W.stats.peak, array_length(_live));
}

/// @function hur__emit_one(W, E)
/// @description Internal. One piece from an emitter.
function hur__emit_one(_W, _E) {
    var _g = _W.rng;
    switch (_E.kind) {
        case "cannon": hur__spawn_paper(_W, _E.h, _E.x, _E.y, 1, hur__opt(_E.o, "dir", 90), hur__opt(_E.o, "spread", 18), 1500 * sqrt(_E.s), hur__opt(_E.o, "forms", undefined), _E.T, _E.o); break;
        case "fall": var _w = hur__opt(_E.o, "width", _W.bounds[2] - _W.bounds[0]); hur__spawn_fall(_W, _E.h, _E.x, _w, _E.y, hur__opt(_E.o, "form", hur__pick(_g, ["ticker", "square", "strip", "dot"])), _E.T); break;
        case "shower": hur__spawn_coin(_W, _E.h, _E.x, _E.y, _E.T, _E.o); break;
        case "balloons": var _bw = hur__opt(_E.o, "width", 200); hur__spawn_balloon(_W, _E.h, _E.x + hur__range(_g, -0.5, 0.5) * _bw, _E.y + hur__range(_g, 0, 40), _E.T, _E.o); break;
    }
}

/// @function hur__step_paper(W, P, d, floorY)
/// @description Internal. Two-sided paper: gravity, quadratic drag that is strongest while the piece lies flat to its fall
/// (so it hangs, then slips edge-first - the flutter), a sideways sway, the tumble about the piece's own axis, and the spin.
/// A feather swings like a pendulum instead; on a floor, paper settles flat and fades.
function hur__step_paper(_W, _P, _d, _fl) {
    if (_P.rest) { _P.restT += _d; if (_P.restT > 1.4) _P.life = min(_P.life, _P.age + 0.6); return; }
    var _pk = _P.pk, _feather = (_pk == 2);
    var _flat = abs(cos(_P.ph));
    var _k = _feather ? 3.6 : ((_pk == 1) ? 2.4 : 1.3) * (0.3 + 0.7 * _flat);
    var _sp = sqrt(_P.vx * _P.vx + _P.vy * _P.vy);
    // a slug of confetti flies together for its first third of a second, then opens out: the drag ramps 0.25 -> 1
    var _launch = min(1, 0.25 + _P.age * 2.2);
    var _drag = 1 / (1 + (_k * 0.005 * _sp + _k * 1.6) * _launch * _d);
    _P.vx *= _drag; _P.vy *= _drag;
    _P.vy += HUR_G_PAPER * _d * (_feather ? 0.22 : 1);
    // the sway: a slow side-to-side drift at the piece's own frequency (2.2..3.8 rad/s), about 20 px either way
    _P.vx += sin(_P.age * (_feather ? 2.1 : _P.swf) + _P.seed) * (_feather ? 210 : ((_pk == 1) ? 260 : 230)) * _d;
    _P.x += _P.vx * _d; _P.y += _P.vy * _d;
    if (_feather) _P.rot = sin(_P.age * 2.1 + _P.seed) * 0.7 + pi / 2;
    else { _P.ph += _P.vph * _d; _P.rot += _P.vr * _d; }
    if (!is_undefined(_fl) && _P.vy > 0 && _P.y >= _fl - 2 && _P.y - _P.vy * _d <= _fl - 2) { _P.y = _fl - 2; _P.rest = true; _P.vx = 0; _P.vy = 0; _P.ph = (cos(_P.ph) >= 0) ? 0.18 : pi + 0.18; }
}

/// @function hur__step_streamer(W, P, d, floorY)
/// @description Internal. A rope of 12 nodes: each node feels gravity and paper drag, the head is thrown, and two passes of
/// distance constraints pull every node back to within one segment of the node before it (only the follower moves, so the
/// tail trails the head the way a thrown streamer does).
function hur__step_streamer(_W, _P, _d, _fl) {
    var _N = array_length(_P.nx);
    var _ox = array_create(_N), _oy = array_create(_N);
    var _drag = 1 / (1 + 2.6 * _d);
    for (var _k = 0; _k < _N; _k++) {
        _ox[_k] = _P.nx[_k]; _oy[_k] = _P.ny[_k];
        if (_k == 0) {
            var _sp = sqrt(_P.vx * _P.vx + _P.vy * _P.vy), _hd = 1 / (1 + (0.0036 * _sp + 0.8) * _d);
            _P.vx *= _hd; _P.vy *= _hd; _P.vy += HUR_G_PAPER * 0.55 * _d;
            _P.vx += sin(_P.age * 2.6 + _P.seed) * 40 * _d;
            _P.nx[0] += _P.vx * _d; _P.ny[0] += _P.vy * _d;
        } else {
            _P.nvx[_k] *= _drag; _P.nvy[_k] *= _drag; _P.nvy[_k] += HUR_G_PAPER * 0.5 * _d;
            _P.nx[_k] += _P.nvx[_k] * _d; _P.ny[_k] += _P.nvy[_k] * _d;
        }
    }
    repeat (2) for (var _k = 1; _k < _N; _k++) {
        var _dx = _P.nx[_k] - _P.nx[_k - 1], _dy = _P.ny[_k] - _P.ny[_k - 1], _l = sqrt(_dx * _dx + _dy * _dy);
        if (_l > _P.seg) { var _f = _P.seg / _l; _P.nx[_k] = _P.nx[_k - 1] + _dx * _f; _P.ny[_k] = _P.ny[_k - 1] + _dy * _f; }
    }
    for (var _k = 1; _k < _N; _k++) { _P.nvx[_k] = (_P.nx[_k] - _ox[_k]) / _d; _P.nvy[_k] = (_P.ny[_k] - _oy[_k]) / _d; }
    if (!is_undefined(_fl)) for (var _k = 0; _k < _N; _k++) if (_P.ny[_k] > _fl - 1 && _oy[_k] <= _fl - 1) { _P.ny[_k] = _fl - 1; _P.nvy[_k] = 0; _P.nvx[_k] *= 0.5; if (_k == 0) { _P.vy = 0; _P.vx *= 0.5; } }
    _P.x = _P.nx[0]; _P.y = _P.ny[0];
    _P.ph += _d * 3;
}

/// @function hur__step_balloon(W, P, d)
/// @description Internal. Buoyancy against drag (a balloon rises at a steady pace), a sway, a tilt that follows the sway, and
/// the string: node 0 pinned to the knot, the rest hanging under gravity within one segment of the node above.
function hur__step_balloon(_W, _P, _d) {
    var _drag = 1 / (1 + 1.4 * _d);
    _P.vx *= _drag; _P.vy *= _drag;
    _P.vy -= 260 * _d;
    _P.vy = max(_P.vy, -150);
    _P.vx += sin(_P.age * 1.3 + _P.seed) * 34 * _d;
    _P.x += _P.vx * _d; _P.y += _P.vy * _d;
    _P.rot = clamp(_P.vx * 0.006, -0.35, 0.35);
    var _S = hur_form_shape(_P.form), _kn = _P.size * _S.knot;
    var _N = array_length(_P.nx);
    _P.nx[0] = _P.x - sin(_P.rot) * _kn; _P.ny[0] = _P.y + cos(_P.rot) * _kn;
    var _sd = 1 / (1 + 3 * _d);
    for (var _k = 1; _k < _N; _k++) {
        var _px = _P.nx[_k], _py = _P.ny[_k];
        _P.nvx[_k] *= _sd; _P.nvy[_k] = _P.nvy[_k] * _sd + 400 * _d;
        _P.nx[_k] += _P.nvx[_k] * _d; _P.ny[_k] += _P.nvy[_k] * _d;
        var _dx = _P.nx[_k] - _P.nx[_k - 1], _dy = _P.ny[_k] - _P.ny[_k - 1], _l = sqrt(_dx * _dx + _dy * _dy);
        if (_l > _P.seg) { var _f = _P.seg / _l; _P.nx[_k] = _P.nx[_k - 1] + _dx * _f; _P.ny[_k] = _P.ny[_k - 1] + _dy * _f; }
        _P.nvx[_k] = (_P.nx[_k] - _px) / _d; _P.nvy[_k] = (_P.ny[_k] - _py) / _d;
    }
    if (_P.y < _W.bounds[1] - _P.size * 3 - 200) _P.life = min(_P.life, _P.age);
}

/// @function hur__step_coin(W, P, d, floorY)
/// @description Internal. A coin or gem: a ballistic arc while it spins about its upright axis; with a target it then homes
/// in (a steering gain that grows with time, and a hard arrival by 1.6 s after the arc so every coin always lands); on a floor
/// it bounces, slides and comes to rest on the pile, stacking on the coins already lying in its column.
function hur__step_coin(_W, _P, _d, _fl) {
    if (_P.rest) { _P.restT += _d; if (_P.restT > 2.2) _P.life = min(_P.life, _P.age + 0.6); return; }
    _P.ph += _P.vph * _d;
    if (_P.fam == "gem") _P.rot += _P.vr * 0.35 * _d;
    if (_P.homing && _P.age > _P.delay) {
        var _t = _P.age - _P.delay, _dx = _P.tx - _P.x, _dy = _P.ty - _P.y, _dist = sqrt(_dx * _dx + _dy * _dy);
        var _want = 420 + 1500 * _t, _gain = min(1, (3 + 14 * _t) * _d);
        _P.vx += (_dx / max(1, _dist) * _want - _P.vx) * _gain;
        _P.vy += (_dy / max(1, _dist) * _want - _P.vy) * _gain;
        _P.x += _P.vx * _d; _P.y += _P.vy * _d;
        if (_dist < 14 || _t > 1.6) { _P.x = _P.tx; _P.y = _P.ty; _P.life = _P.age; }
        return;
    }
    _P.vy += HUR_G_HEAVY * _d;
    _P.x += _P.vx * _d; _P.y += _P.vy * _d;
    if (!is_undefined(_fl) && !_P.homing) {
        var _col = clamp(floor((_P.x - _W.bounds[0]) / _W.pileW), 0, array_length(_W.pile) - 1);
        var _top = _fl - _W.pile[_col] - _P.size * 0.5;
        // lands when it crosses the pile top moving down - or when it started this step anywhere above the bare floor line,
        // so a column that grew under an airborne coin lifts it onto the pile instead of letting it through
        if (_P.vy > 0 && _P.y >= _top && _P.y - _P.vy * _d <= max(_top, _fl - _P.size * 0.5) + 1) {
            _P.y = _top;
            if (abs(_P.vy) < 140) {
                _P.rest = true; _P.vx = 0; _P.vy = 0;
                _P.ph = (_P.fam == "coin") ? pi / 2 - 0.22 : _P.ph;
                _W.pile[_col] = min(_W.pile[_col] + _P.size * 0.34, 120);
            } else { _P.vy = -_P.vy * 0.34; _P.vx *= 0.6; _P.vph *= 0.7; }
        }
    }
}
