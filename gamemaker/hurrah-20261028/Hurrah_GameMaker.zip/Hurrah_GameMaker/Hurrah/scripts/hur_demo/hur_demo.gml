/// hur_demo.gml - THE PARTY ROOM, Hurrah's demo room: a drawn game screen (a night sky, hills, a stone floor, a chest and a
/// HUD with a score counter) where every moment preset fires on a key, coins fly into the counter and add to the score, and
/// an attract mode plays the moments in turn when nobody touches anything for six seconds.
/// Keys: 1 level up - 2 win - 3 new record - 4 chest - 5 achievement - 6 birthday - 7 jackpot - 8 petals.
/// Left click a party popper at the mouse, right click a confetti cannon. T next palette - P pause - C clear - B budget
/// 400 / 150 - F floor on / off - A attract mode on / off.
///
/// Hurrah - Celebration Effects for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function hur_demo_create()
/// @description Build the demo: a world over the 960 x 640 room with its floor on the stone ledge, and the HUD state.
function hur_demo_create() {
    var _D = { world: hur_world_create({ seed: 7, theme: "party", floor: 590, bounds: [0, 0, 960, 640] }),
               theme: 0, score: 0, shown: 0, last: "", lastT: 0, idle: 0, attract: true, next: 0, floorOn: true, chestOpen: 0, fps: 60 };
    return _D;
}

/// @function hur_demo_counter()
/// @description Where the HUD's coin counter sits (the target hur_shower_to flies into).
function hur_demo_counter() { return { x: 846, y: 30 }; }

/// @function hur_demo_fire(demo, n)
/// @description Fire moment n (1..8) where it belongs in the scene; returns its handle.
function hur_demo_fire(_D, _n) {
    var _W = _D.world, _c = hur_demo_counter(), _h = -1;
    switch (_n) {
        case 1: _h = hur_fire(_W, "levelup", 480, 250, 1.1, { text: "LEVEL UP!" }); _D.last = "LEVEL UP"; break;
        case 2: _h = hur_fire(_W, "win", 480, 230, 1, { text: "YOU WIN!" }); _D.last = "WIN"; break;
        case 3: _h = hur_fire(_W, "record", 480, 220, 1, { text: "NEW RECORD" }); _D.last = "NEW RECORD"; break;
        case 4: _h = hur_fire(_W, "chest", 760, 540, 1); _D.chestOpen = 3; _D.last = "CHEST"; break;
        case 5: _h = hur_fire(_W, "achievement", 480, 250, 1.3, { text: "1st" }); _D.last = "ACHIEVEMENT"; break;
        case 6: _h = hur_fire(_W, "birthday", 480, 330, 1, { text: "PARTY TIME" }); _D.last = "BIRTHDAY"; break;
        case 7: _h = hur_shower_to(_W, 480, 420, _c.x, _c.y, 40, { value: 25, gems: 0.2 }); hur_fire(_W, "burst", 480, 420, 1, { form: "rays" }); hur_fire(_W, "burst", 480, 420, 1, { form: "flash" }); _D.last = "JACKPOT"; break;
        case 8: _h = hur_fire(_W, "petals", 480, 300, 1); _D.last = "PETALS"; break;
    }
    _D.lastT = 2;
    return _h;
}

/// @function hur_demo_step(demo)
/// @description Read the keys and mouse, run the attract mode, step the world and count the coins that arrived.
function hur_demo_step(_D) {
    var _W = _D.world, _any = false;
    for (var _k = 1; _k <= 8; _k++) if (keyboard_check_pressed(ord(string(_k)))) { hur_demo_fire(_D, _k); _any = true; }
    if (mouse_check_button_pressed(mb_left)) { hur_fire(_W, "popper", mouse_x, mouse_y, 1, { dir: 90, prop: true }); _any = true; }
    if (mouse_check_button_pressed(mb_right)) { hur_fire(_W, "cannon", mouse_x, mouse_y, 1, { dir: 90, prop: true }); _any = true; }
    if (keyboard_check_pressed(ord("T"))) {
        var _th = hur_themes();
        _D.theme = (_D.theme + 1) mod array_length(_th);
        _W.theme = hur_theme(_th[_D.theme]); _any = true;
    }
    if (keyboard_check_pressed(ord("P"))) { hur_world_pause(_W, !_W.paused); _any = true; }
    if (keyboard_check_pressed(ord("C"))) { hur_world_clear(_W); _any = true; }
    if (keyboard_check_pressed(ord("B"))) { _W.budget = (_W.budget > 200) ? 150 : HUR_BUDGET; _any = true; }
    if (keyboard_check_pressed(ord("F"))) { _D.floorOn = !_D.floorOn; _W.floorY = _D.floorOn ? 590 : undefined; _any = true; }
    if (keyboard_check_pressed(ord("A"))) { _D.attract = !_D.attract; _any = true; }
    var _dt = clamp(delta_time / 1000000, 0, HUR_DT_MAX);
    _D.idle = _any ? 0 : _D.idle + _dt;
    if (_D.attract && _D.idle > 6 && !_W.paused) {
        _D.next -= _dt;
        if (_D.next <= 0) { hur_demo_fire(_D, (_D.shown mod 8) + 1); _D.shown += 1; _D.next = 3.2; }
    }
    hur_world_step(_W, _dt);
    var _ev = hur_world_events(_W);
    for (var _e = 0; _e < array_length(_ev); _e++) if (_ev[_e].type == "arrive") _D.score += _ev[_e].value;
    if (_D.lastT > 0) _D.lastT -= _dt;
    if (_D.chestOpen > 0) _D.chestOpen -= _dt;
    if (_dt > 0) _D.fps = lerp(_D.fps, 1 / _dt, 0.05);
}

/// @function hur_demo_scene_draw(demo, x, y, w, h)
/// @description Draw the demo's game screen into a rectangle: a night sky, two ranges of hills, a stone ledge, a chest (open
/// while demo.chestOpen > 0). Plain primitives; it stands in for the buyer's own game.
function hur_demo_scene_draw(_D, _x, _y, _w, _h) {
    var _sx = _w / 960, _sy = _h / 640;
    draw_primitive_begin(pr_trianglestrip);
    draw_vertex_colour(_x, _y, make_colour_rgb(24, 22, 58), 1); draw_vertex_colour(_x + _w, _y, make_colour_rgb(24, 22, 58), 1);
    draw_vertex_colour(_x, _y + _h * 0.75, make_colour_rgb(70, 54, 118), 1); draw_vertex_colour(_x + _w, _y + _h * 0.75, make_colour_rgb(70, 54, 118), 1);
    draw_primitive_end();
    var _g = hur_rng(11);
    draw_primitive_begin(pr_trianglelist);
    for (var _i = 0; _i < 70; _i++) {
        var _px = _x + hur_rand(_g) * _w, _py = _y + hur_rand(_g) * _h * 0.6, _r = (0.6 + hur_rand(_g) * 1.3) * _sx, _al = 0.35 + 0.6 * hur_rand(_g);
        draw_vertex_colour(_px - _r, _py, c_white, _al); draw_vertex_colour(_px + _r, _py, c_white, _al); draw_vertex_colour(_px, _py - _r * 2.2, c_white, _al);
        draw_vertex_colour(_px - _r, _py, c_white, _al); draw_vertex_colour(_px + _r, _py, c_white, _al); draw_vertex_colour(_px, _py + _r * 2.2, c_white, _al);
    }
    draw_primitive_end();
    for (var _band = 0; _band < 2; _band++) {
        var _base = _y + _h * (0.62 + _band * 0.1), _amp = _h * (0.07 - _band * 0.02), _col = (_band == 0) ? make_colour_rgb(52, 44, 96) : make_colour_rgb(36, 32, 70);
        draw_primitive_begin(pr_trianglestrip);
        for (var _k = 0; _k <= 32; _k++) {
            var _px = _x + _k / 32 * _w, _py = _base - (sin(_k * 0.55 + _band * 2.1) * 0.6 + sin(_k * 0.21 + _band) * 0.4 + 0.6) * _amp;
            draw_vertex_colour(_px, _py, _col, 1); draw_vertex_colour(_px, _y + _h, _col, 1);
        }
        draw_primitive_end();
    }
    var _fy = _y + 590 * _sy;
    draw_set_alpha(1);
    draw_rectangle_colour(_x, _fy, _x + _w, _y + _h, make_colour_rgb(84, 76, 96), make_colour_rgb(84, 76, 96), make_colour_rgb(40, 34, 50), make_colour_rgb(40, 34, 50), false);
    draw_set_colour(make_colour_rgb(130, 120, 146)); draw_line_width(_x, _fy, _x + _w, _fy, 3 * _sy);
    draw_set_colour(make_colour_rgb(58, 50, 68));
    for (var _k = 0; _k < 12; _k++) { var _bx = _x + (_k * 96 + ((_k mod 2) * 40)) * _sx; draw_line_width(_bx, _fy + 4 * _sy, _bx, _y + _h, 2 * _sx); }
    // the chest
    var _cx = _x + 760 * _sx, _cw = 70 * _sx, _ch = 46 * _sy, _cy = _fy - _ch;
    draw_rectangle_colour(_cx - _cw / 2, _cy, _cx + _cw / 2, _fy, make_colour_rgb(150, 92, 44), make_colour_rgb(150, 92, 44), make_colour_rgb(98, 56, 24), make_colour_rgb(98, 56, 24), false);
    draw_set_colour(make_colour_rgb(236, 190, 70));
    draw_rectangle(_cx - _cw / 2, _cy, _cx + _cw / 2, _cy + 5 * _sy, false);
    draw_rectangle(_cx - 6 * _sx, _cy + 8 * _sy, _cx + 6 * _sx, _cy + 22 * _sy, false);
    var _open = (_D.chestOpen > 0);
    if (_open) {
        draw_set_colour(make_colour_rgb(255, 230, 140)); draw_set_alpha(0.55);
        draw_rectangle(_cx - _cw / 2 + 4 * _sx, _cy - 4 * _sy, _cx + _cw / 2 - 4 * _sx, _cy + 2 * _sy, false);
        draw_set_alpha(1);
        draw_rectangle_colour(_cx - _cw / 2, _cy - 40 * _sy, _cx + _cw / 2, _cy - 30 * _sy, make_colour_rgb(170, 108, 52), make_colour_rgb(170, 108, 52), make_colour_rgb(120, 70, 30), make_colour_rgb(120, 70, 30), false);
    } else {
        draw_rectangle_colour(_cx - _cw / 2, _cy - 18 * _sy, _cx + _cw / 2, _cy, make_colour_rgb(176, 112, 56), make_colour_rgb(176, 112, 56), make_colour_rgb(140, 84, 38), make_colour_rgb(140, 84, 38), false);
        draw_set_colour(make_colour_rgb(236, 190, 70)); draw_rectangle(_cx - _cw / 2, _cy - 3 * _sy, _cx + _cw / 2, _cy + 1 * _sy, false);
    }
    draw_set_colour(c_white);
}

/// @function hur_demo_hud(demo, x, y, w, h)
/// @description The HUD band: level, the score counter with its coin (where the jackpot coins land), and the room's state.
function hur_demo_hud(_D, _x, _y, _w, _h) {
    var _sx = _w / 960, _W = _D.world, _c = hur_demo_counter();
    draw_set_alpha(0.55); draw_set_colour(make_colour_rgb(10, 8, 26));
    draw_rectangle(_x, _y, _x + _w, _y + 60 * _sx, false);
    draw_set_alpha(1);
    hur_piece_draw("coin_gold", _x + (_c.x - 26) * _sx, _y + _c.y * _sx, 13 * _sx, 0, 0);
    var _sc = string(floor(max(0, _D.score)));
    while (string_length(_sc) < 6) _sc = "0" + _sc;   // padded by arithmetic, never by replacing spaces (wing CLAUDE.md s3)
    hur__text(_x + (_c.x + 46) * _sx, _y + _c.y * _sx, _sc, fnt_hurrah_display_s, 0.95 * _sx, make_colour_rgb(255, 226, 120), 1, make_colour_rgb(60, 30, 10));
    var _of = draw_get_font(); draw_set_font(fnt_hurrah_display_s); var _tw = string_width("THE PARTY ROOM") * 0.78; draw_set_font(_of);
    hur__text(_x + (24 + _tw / 2) * _sx, _y + 30 * _sx, "THE PARTY ROOM", fnt_hurrah_display_s, 0.78 * _sx, c_white, 1, make_colour_rgb(80, 30, 90));
    var _info = string(hur_world_count(_W)) + " pieces / budget " + string(_W.budget) + "   thinned " + string(_W.stats.thinned) + "   palette " + string_upper(_W.theme.title) + (_W.paused ? "   PAUSED" : "") + (_D.floorOn ? "" : "   NO FLOOR");
    hur__text(_x + 440 * _sx, _y + 30 * _sx, _info, fnt_hurrah_body_s, 0.62 * _sx, make_colour_rgb(214, 210, 236), 1, make_colour_rgb(10, 8, 26));
}

/// @function hur_demo_draw(demo)
/// @description Draw the room: the scene, every celebration, the HUD, the last moment's name and the key line.
function hur_demo_draw(_D) {
    hur_demo_scene_draw(_D, 0, 0, 960, 640);
    hur_world_draw(_D.world);
    hur_demo_hud(_D, 0, 0, 960, 640);
    if (_D.lastT > 0 && _D.idle > 6 && _D.attract) hur__text(480, 600, _D.last, fnt_hurrah_body_l, 0.5, c_white, clamp(_D.lastT, 0, 1), make_colour_rgb(10, 8, 26));
    hur__text(480, 624, "1-8 MOMENTS   CLICK POPPER   RIGHT CLICK CANNON   T PALETTE   P PAUSE   C CLEAR   B BUDGET   F FLOOR   A ATTRACT", fnt_hurrah_body_s, 0.5, make_colour_rgb(230, 228, 244), 0.9, make_colour_rgb(10, 8, 26));
}

/// @function hur_demo_free(demo)
/// @description Free what the demo made.
function hur_demo_free(_D) { if (is_struct(_D)) hur_world_free(_D.world); }
