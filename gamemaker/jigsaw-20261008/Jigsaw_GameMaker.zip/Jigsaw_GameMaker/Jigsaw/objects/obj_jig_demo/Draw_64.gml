/// @description THE PUZZLE ROOM, drawn in the GUI layer (jig_demo_draw calls jig_draw while a puzzle is open).
if (!is_struct(demo)) exit;
jig_demo_draw(demo);
