/// @description THE PUZZLE ROOM: the room, or the table while a puzzle is open (jig_demo_step calls jig_step).
if (!is_struct(demo)) exit;
jig_demo_step(demo);
