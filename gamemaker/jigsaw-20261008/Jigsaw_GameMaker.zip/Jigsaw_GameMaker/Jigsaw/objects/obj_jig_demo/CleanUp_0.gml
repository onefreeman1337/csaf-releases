/// @description Free every sprite the demo and its puzzle made. Runs even when Create left early (-selftest).
if (variable_instance_exists(id, "demo") && is_struct(demo)) jig_demo_free(demo);
demo = undefined;
