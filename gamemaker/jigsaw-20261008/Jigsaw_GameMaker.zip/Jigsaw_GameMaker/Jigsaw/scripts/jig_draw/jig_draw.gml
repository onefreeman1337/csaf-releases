/// jig_draw.gml - Jigsaw's renderer: each piece drawn from YOUR picture with a bevel, a rim light, a card-stock sheen and a
/// shadow, and the table (a felt mat inside a wooden rim) drawn from a seed. Draws through the canvas kit (jig_canvas) onto
/// the current surface target; it loads no image of its own. Each piece is traced along the cut's own curves, so its edge
/// stays smooth at any size.
///
/// Jigsaw - Jigsaw Puzzles From Any Picture, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// The RPG Maker MZ edition's JigsawDraw.js, ported call for call (the same paths, shadows, strokes, gradients and seeded
/// grain). Public functions (each documented below): jig_trace_piece, jig_draw_piece, jig_bevel_of, jig_margin,
/// jig_draw_table, jig_felt_inset, jig_cx_image.

/// @function jig__is_ctx(ctx)
/// @description Internal. True for a drawing context made by jig_cx_create.
function jig__is_ctx(_c) { return is_struct(_c) && is_array(_c[$ "m"]) && is_array(_c[$ "clips"]) && is_array(_c[$ "stack"]); }

/// @function jig__is_piece(piece)
/// @description Internal. True for a piece of a cut made by jig_cut.
function jig__is_piece(_p) { return is_struct(_p) && is_struct(_p[$ "edges"]) && is_numeric(_p[$ "bw"]) && is_numeric(_p[$ "homeX"]) && is_array(_p[$ "outline"]); }

/// @function jig__fin(v, fallback)
/// @description Internal. v when it is a finite number, else the fallback.
function jig__fin(_v, _d) { return (is_numeric(_v) && !is_nan(_v) && !is_infinity(_v)) ? _v : _d; }

/// @function jig_cx_image(ctx, sprite, subimg, x, y, w, h)
/// @description Draw a sprite stretched to the USER-space box (x, y, w, h) under the context's transform (translation and
/// scale; the box is axis-aligned) at the context alpha, inside the current clip (a shaped clip's LAYER cuts it to the path
/// when the clip is restored). The canvas drawImage(img, x, y, w, h) for this kit. Returns 1 when something was drawn.
/// @returns {Real}
function jig_cx_image(_c, _spr, _sub, _x, _y, _w, _h) {
    if (!jig__is_ctx(_c) || !is_numeric(_spr) || !sprite_exists(_spr)) return 0;
    _x = jig__fin(_x, 0); _y = jig__fin(_y, 0); _w = jig__fin(_w, 0); _h = jig__fin(_h, 0);
    if (!(_w > 0) || !(_h > 0)) return 0;
    var _p = jig_cx__pt(_c, _x, _y), _q = jig_cx__pt(_c, _x + _w, _y + _h);
    var _prev = jig_cx__scissor_on(_c);
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_texfilter(true);
    draw_sprite_stretched_ext(_spr, is_numeric(_sub) ? _sub : 0, _p[0], _p[1], _q[0] - _p[0], _q[1] - _p[1], c_white, _c.alpha);
    gpu_pop_state();
    jig_cx__scissor_off(_prev);
    _c.counts.fill++;
    return 1;
}

/// @function jig_trace_piece(ctx, piece)
/// @description Trace one piece's closed outline into the context's current path, in picture coordinates, along the cut's
/// own cubic curves (twelve of them, three per side).
function jig_trace_piece(_c, _piece) {
    if (!jig__is_ctx(_c) || !jig__is_piece(_piece)) return;
    var _order = ["top", "right", "bottom", "left"];
    for (var _i = 0; _i < 4; _i++) {
        var _e = _piece.edges[$ _order[_i]], _P = _e.base.pts;
        var _pts = _P;
        if (_e.reversed) { _pts = array_create(10); for (var _r = 0; _r < 10; _r++) _pts[_r] = _P[9 - _r]; }
        if (_i == 0) jig_cx_move(_c, _pts[0][0], _pts[0][1]);
        for (var _k = 1; _k < 10; _k += 3) jig_cx_bezier(_c, _pts[_k][0], _pts[_k][1], _pts[_k + 1][0], _pts[_k + 1][1], _pts[_k + 2][0], _pts[_k + 2][1]);
    }
    jig_cx_close(_c);
}

/// @function jig_bevel_of(piece)
/// @description The bevel jig_draw_piece gives a piece (px): it grows with the piece, so a big piece reads as thick card.
/// @returns {Real}
function jig_bevel_of(_piece) {
    if (!jig__is_piece(_piece)) return 1.5;
    return max(1.5, min(_piece.bw, _piece.bh) * 0.035);
}

/// @function jig_margin(piece)
/// @description How far past its outline box a piece's LIFTED shadow can reach (blur ~1.5 x the shadow blur, plus the
/// offset): the margin a piece's own sprite needs so no shadow is clipped (px on every side).
/// @returns {Real}
function jig_margin(_piece) { var _b = jig_bevel_of(_piece); return ceil(_b * 7 * 1.5 + _b * 3.4) + 2; }

/// @function jig_draw_piece(ctx, sprite, cut, piece, x, y, [options])
/// @description Draw a piece with its home bounding box at (x, y): its shadow (deeper and further when lifted), the
/// picture clipped to the piece, a rim light upper left and a dark lip lower right, a faint sheen so it reads as card
/// stock, and the cut line as a hairline. The picture is drawn at the cut's w x h.
/// @param {Struct} ctx a context from jig_cx_create, drawing onto a SURFACE target (a shaped clip needs one)
/// @param {Asset.GMSprite} sprite the picture
/// @param {Struct} cut the cut (jig_cut)
/// @param {Struct} piece one of cut.pieces
/// @param {Real} x left of the piece's bounding box
/// @param {Real} y top of the piece's bounding box
/// @param {Struct} [options] { lifted: false, bevel: px (default jig_bevel_of), subimg: 0 }
function jig_draw_piece(_c, _spr, _cut, _piece, _x, _y, _o = undefined) {
    if (!jig__is_ctx(_c) || !jig__is_piece(_piece) || !is_struct(_cut) || !is_numeric(_cut[$ "w"])) return;
    if (!is_struct(_o)) _o = {};
    _x = jig__fin(_x, 0); _y = jig__fin(_y, 0);
    var _lf = _o[$ "lifted"], _lifted = (is_bool(_lf) || is_numeric(_lf)) && _lf;
    var _bev = (is_numeric(_o[$ "bevel"]) && _o.bevel > 0) ? _o.bevel : jig_bevel_of(_piece);
    var _sub = is_numeric(_o[$ "subimg"]) ? _o.subimg : 0;
    jig_cx_save(_c);
    jig_cx_translate(_c, _x - _piece.homeX, _y - _piece.homeY);
    // shadow first, under the piece: deeper when the piece is lifted
    jig_cx_save(_c);
    jig_cx_begin(_c); jig_trace_piece(_c, _piece);
    jig_cx_shadow(_c, [0, 0, 0], _lifted ? 0.55 : 0.38, _lifted ? _bev * 7 : _bev * 2.2, _lifted ? _bev * 2.6 : _bev * 0.7, _lifted ? _bev * 3.4 : _bev * 0.9);
    _c.fill = jig_cx_solid([32, 24, 15]);
    jig_cx_fill(_c);
    jig_cx_restore(_c);
    // the picture, clipped to the piece
    jig_cx_save(_c);
    jig_cx_begin(_c); jig_trace_piece(_c, _piece); jig_cx_clip(_c);
    jig_cx_image(_c, _spr, _sub, 0, 0, _cut.w, _cut.h);
    // bevel: light from the upper left, a dark lip lower right, each a stroke of the outline offset inside the clip.
    // Deviation (measured): the MZ strokes these with lineJoin "round"; the kit's round join is an exact scanline union
    // and cost ~200 ms a piece on the VM, so the bevel takes the mitred strip (the curves are flattened finely, so a
    // joint turns a degree or two and the two joins draw the same line).
    _c.join = 0;
    _c.lw = _bev * 1.5;
    jig_cx_save(_c); jig_cx_translate(_c, _bev * 0.6, _bev * 0.6); jig_cx_begin(_c); jig_trace_piece(_c, _piece);
    _c.stroke = jig_cx_solid([255, 246, 226], 0.26); jig_cx_stroke(_c); jig_cx_restore(_c);
    jig_cx_save(_c); jig_cx_translate(_c, -_bev * 0.6, -_bev * 0.6); jig_cx_begin(_c); jig_trace_piece(_c, _piece);
    _c.stroke = jig_cx_solid([20, 12, 4], 0.40); jig_cx_stroke(_c); jig_cx_restore(_c);
    // a faint sheen across the face so a piece reads as card stock, not a cut-out of a screenshot
    var _g = jig_cx_linear(_c, _piece.homeX, _piece.homeY, _piece.homeX + _piece.bw, _piece.homeY + _piece.bh);
    jig_cx_stop(_g, 0, [255, 255, 255], 0.10); jig_cx_stop(_g, 0.5, [255, 255, 255], 0); jig_cx_stop(_g, 1, [0, 0, 0], 0.10);
    _c.fill = _g; jig_cx_fill_rect(_c, _piece.homeX - 4, _piece.homeY - 4, _piece.bw + 8, _piece.bh + 8);
    jig_cx_restore(_c);
    // the cut line itself: a hairline of the board's grey core
    jig_cx_begin(_c); jig_trace_piece(_c, _piece);
    _c.lw = max(0.8, _bev * 0.45); _c.stroke = jig_cx_solid([48, 38, 26], 0.85); jig_cx_stroke(_c);
    jig_cx_restore(_c);
}

/// @function jig_felt_inset(w, h)
/// @description The wooden rim's width on a w x h table: the felt starts this far in. The scene lays out inside it.
/// @returns {Real}
function jig_felt_inset(_w, _h) { return floor(min(jig__fin(_w, 0), jig__fin(_h, 0)) * 0.045 + 0.5); }

/// @function jig_draw_table(ctx, w, h, [options])
/// @description The table: a wooden board with seeded grain, a felt mat inside its rim with a fine nap, the mat's lip, and a
/// pool of light from above. Drawn once per scene.
/// @param {Struct} ctx a context from jig_cx_create
/// @param {Real} w width
/// @param {Real} h height
/// @param {Struct} [options] { seed: 7, felt: [36, 69, 58], wood: [90, 58, 34] } (colours as [r, g, b])
function jig_draw_table(_c, _w, _h, _o = undefined) {
    if (!jig__is_ctx(_c)) return;
    _w = jig__fin(_w, 0); _h = jig__fin(_h, 0);
    if (!(_w > 0) || !(_h > 0)) return;
    if (!is_struct(_o)) _o = {};
    var _sd = _o[$ "seed"];
    var _blank = is_undefined(_sd) || (is_numeric(_sd) && _sd == 0) || (is_string(_sd) && _sd == "");
    var _R = jig__rng(jig_seed_of(_blank ? 7 : _sd));
    var _wood = (is_array(_o[$ "wood"]) && array_length(_o.wood) >= 3) ? _o.wood : [90, 58, 34];
    var _felt = (is_array(_o[$ "felt"]) && array_length(_o.felt) >= 3) ? _o.felt : [36, 69, 58];
    // wood
    _c.fill = jig_cx_solid(_wood); jig_cx_fill_rect(_c, 0, 0, _w, _h);
    var _grain = array_create(90);
    for (var _n = 0; _n < 90; _n++) _grain[_n] = jig__rng_next(_R);
    _c.join = 0;
    for (var _i = 0; _i < 90; _i++) {
        var _y = _grain[_i] * _h;
        _c.stroke = (_i mod 2) ? jig_cx_solid([255, 220, 170], 0.05 + _grain[(_i + 7) mod 90] * 0.06) : jig_cx_solid([30, 15, 5], 0.05 + _grain[(_i + 7) mod 90] * 0.06);
        _c.lw = 1 + _grain[(_i + 3) mod 90] * 2.5;
        jig_cx_begin(_c); jig_cx_move(_c, 0, _y);
        jig_cx_bezier(_c, _w * 0.3, _y + (_grain[(_i + 11) mod 90] - 0.5) * 18, _w * 0.7, _y + (_grain[(_i + 23) mod 90] - 0.5) * 18, _w, _y + (_grain[(_i + 5) mod 90] - 0.5) * 10);
        jig_cx_stroke(_c);
    }
    // felt mat
    var _m = jig_felt_inset(_w, _h);
    _c.fill = jig_cx_solid(_felt); jig_cx_fill_rect(_c, _m, _m, _w - _m * 2, _h - _m * 2);
    for (var _k = 0; _k < 1400; _k++) {
        var _white = jig__rng_next(_R) < 0.5, _a = 0.025 + jig__rng_next(_R) * 0.03;
        var _fx = _m + jig__rng_next(_R) * (_w - _m * 2), _fy = _m + jig__rng_next(_R) * (_h - _m * 2), _fw = 1 + jig__rng_next(_R) * 1.6, _fh = 1 + jig__rng_next(_R) * 1.6;
        _c.fill = jig_cx_solid(_white ? [255, 255, 255] : [0, 0, 0], _a);
        jig_cx_fill_rect(_c, _fx, _fy, _fw, _fh);
    }
    // the mat's lip and a pool of light from above
    _c.stroke = jig_cx_solid([0, 0, 0], 0.45); _c.lw = 3; jig_cx_stroke_rect(_c, _m + 1.5, _m + 1.5, _w - _m * 2 - 3, _h - _m * 2 - 3);
    _c.stroke = jig_cx_solid([255, 240, 210], 0.18); _c.lw = 1; jig_cx_stroke_rect(_c, _m - 0.5, _m - 0.5, _w - _m * 2 + 1, _h - _m * 2 + 1);
    var _lg = jig_cx_radial(_c, _w * 0.5, _h * 0.42, min(_w, _h) * 0.1, _w * 0.5, _h * 0.5, max(_w, _h) * 0.75);
    jig_cx_stop(_lg, 0, [255, 240, 205], 0.10); jig_cx_stop(_lg, 1, [0, 0, 0], 0.38);
    _c.fill = _lg; jig_cx_fill_rect(_c, 0, 0, _w, _h);
}
