/// jig_selftest.gml - Jigsaw's in-engine self-test, run headless by the demo object with -selftest. Holds the GML port to the
/// RPG Maker MZ edition's JigsawCut run in Node (jig_oracle_cut): the seed hash and generator, 56 grid choices, 14 cuts
/// (623 pieces: every box, edge side and outline point) and the flattened edges - all EXACT - then proves the cut TILES the
/// picture, counts ink on every drawn piece, plays whole puzzles by injected mouse and keyboard input, and measures what
/// opening a puzzle costs on this runtime. Writes jig_selftest.json and jig_render_*.png.

/// @function jig_st_assert(state, condition, message)
function jig_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 60) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
/// @function jig_st_stage(state, n)
function jig_st_stage(_st, _n) { _st.stage = _n; global.jig_stage = _n; }
function jig__st_near(_a, _b, _tol) { return abs(_a - _b) <= _tol; }

/// internal (test): non-transparent pixels in a sprite (alpha > 8), counted on a surface read back as a buffer.
function jig__st_ink(_spr) {
    if (!is_numeric(_spr) || _spr < 0 || !sprite_exists(_spr)) return 0;
    var _w = sprite_get_width(_spr), _h = sprite_get_height(_spr), _s = surface_create(_w, _h);
    surface_set_target(_s); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_zero); draw_sprite(_spr, 0, sprite_get_xoffset(_spr), sprite_get_yoffset(_spr)); gpu_pop_state();
    surface_reset_target();
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _s, 0);
    var _n = 0;
    for (var _i = 3; _i < _w * _h * 4; _i += 4) if (buffer_peek(_b, _i, buffer_u8) > 8) _n++;
    buffer_delete(_b); surface_free(_s);
    return _n;
}
/// internal (test): a point inside a scene piece, in table coordinates (its outline's centre, else a scan).
function jig__st_point_in(_P) {
    var _p = _P.p, _cx = _p.homeX + _p.bw / 2, _cy = _p.homeY + _p.bh / 2;
    if (!jig_piece_contains(_p, _cx, _cy)) {
        var _found = false;
        for (var _gy = 0.3; _gy <= 0.7 && !_found; _gy += 0.05) for (var _gx = 0.3; _gx <= 0.7 && !_found; _gx += 0.05) {
            var _tx = _p.homeX + _p.bw * _gx, _ty = _p.homeY + _p.bh * _gy;
            if (jig_piece_contains(_p, _tx, _ty)) { _cx = _tx; _cy = _ty; _found = true; }
        }
    }
    return [_P.x + _P.pad + (_cx - _p.homeX), _P.y + _P.pad + (_cy - _p.homeY)];
}
function jig__st_in(_T, _inj) { _T.inject = _inj; jig_step(_T, -1000, -1000); }
/// internal (test): drag a piece by the mouse from inside it to (its home + dx, dy) and let go.
function jig__st_drag(_T, _idx, _dx, _dy) {
    var _P = _T.pieces[_idx], _pt = jig__st_point_in(_P), _tx = _pt[0] + (_P.homeX - _P.x) + _dx, _ty = _pt[1] + (_P.homeY - _P.y) + _dy;
    jig__st_in(_T, { x: _pt[0], y: _pt[1], click: true, down: true });
    if (_T.held != _idx) return false;
    jig__st_in(_T, { x: (_pt[0] + _tx) / 2, y: (_pt[1] + _ty) / 2, down: true });
    jig__st_in(_T, { x: _tx, y: _ty, down: true });
    jig__st_in(_T, { x: _tx, y: _ty, down: false });
    return true;
}
/// internal (test): walk the keyboard hand to within 4 px of (tx, ty) with the arrow keys (Shift when far).
function jig__st_hand_to(_T, _tx, _ty) {
    var _n = 0;
    while ((abs(_T.hand.x - _tx) > 4 || abs(_T.hand.y - _ty) > 4) && _n < 3000) {
        var _ddx = _tx - _T.hand.x, _ddy = _ty - _T.hand.y, _far = max(abs(_ddx), abs(_ddy)) > 9;
        jig__st_in(_T, { left: _ddx < -4, right: _ddx > 4, up: _ddy < -4, down_key: _ddy > 4, shift: _far });
        _n++;
    }
    return _n;
}
function jig__st_shot(_T, _surf, _name) { surface_set_target(_surf); draw_clear(c_black); jig_draw(_T, 0, 0, 1); surface_reset_target(); surface_save(_surf, _name); }

/// @function jig_selftest_run()
/// @description Run every stage; returns the state struct (total, pass, fail, failures, notes, metrics).
function jig_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, stage: 0, notes: [], failures: [], metrics: {} };
    var _O = jig_oracle_cut();
    _st.metrics.epsilonAtStart = math_get_epsilon();
    math_set_epsilon(0);
    _st.metrics.epsilonInSuite = math_get_epsilon();
    // ---- 1: the seed hash and the generator, EXACT ----
    jig_st_stage(_st, 1);
    var _sb = 0, _sf = "";
    for (var _i = 0; _i < array_length(_O.seeds); _i++) { var _got = jig_seed_of(_O.seeds[_i][0]); if (_got != _O.seeds[_i][1]) { _sb++; if (_sf == "") _sf = string(_O.seeds[_i][0]) + " got " + string(_got) + " want " + string(_O.seeds[_i][1]); } }
    var _rb = 0, _rn = 0;
    for (var _k = 0; _k < array_length(_O.streams); _k++) { var _R = jig__rng(_O.streams[_k][0]), _w = _O.streams[_k][1]; for (var _j = 0; _j < array_length(_w); _j++) { _rn++; if (jig__rng_next(_R) != _w[_j]) _rb++; } }
    jig_st_assert(_st, _sb == 0 && array_length(_O.seeds) == 14, "seed_of on 14 numbers and words: " + string(_sb) + " differ " + _sf);
    jig_st_assert(_st, _rb == 0 && _rn == 60, "generator, 3 streams x 20 draws: " + string(_rb) + " of " + string(_rn) + " differ");
    // ---- 2: the grid choice for 56 pictures and counts ----
    jig_st_stage(_st, 2);
    var _gb = 0, _gf = "";
    for (var _g = 0; _g < array_length(_O.grids); _g++) { var _q = _O.grids[_g], _G = jig_grid_for(_q[0], _q[1], _q[2]); if (_G.cols != _q[3] || _G.rows != _q[4]) { _gb++; if (_gf == "") _gf = string(_q[0]) + "x" + string(_q[1]) + " n" + string(_q[2]) + " got " + string(_G.cols) + "x" + string(_G.rows); } }
    jig_st_assert(_st, _gb == 0 && array_length(_O.grids) == 56, "grid_for on 56 picture / count pairs: " + string(_gb) + " differ " + _gf);
    // ---- 3: 14 cuts against the MZ, piece for piece ----
    jig_st_stage(_st, 3);
    var _cb = 0, _cf = "", _pieces = 0, _points = 0, _signs = ["top", "right", "bottom", "left"];
    for (var _c = 0; _c < array_length(_O.cuts); _c++) {
        var _row = _O.cuts[_c], _K = jig_cut({ w: _row[0], h: _row[1], cols: _row[2], rows: _row[3], seed: _row[4] });
        if (_K.w != _row[5] || _K.h != _row[6] || _K.cols != _row[7] || _K.rows != _row[8] || _K.seed != _row[9] || array_length(_K.pieces) != array_length(_row[11])) { _cb++; if (_cf == "") _cf = "cut " + string(_c) + " header " + string(_K.cols) + "x" + string(_K.rows) + " seed " + string(_K.seed); continue; }
        for (var _p = 0; _p < array_length(_K.pieces); _p++) {
            var _P = _K.pieces[_p], _E = _row[11][_p], _bad = false;
            _pieces++;
            if (!jig__st_near(_P.homeX, _E[0], 0.000000001) || !jig__st_near(_P.homeY, _E[1], 0.000000001) || !jig__st_near(_P.bw, _E[2], 0.000000001) || !jig__st_near(_P.bh, _E[3], 0.000000001)) _bad = true;
            for (var _s = 0; _s < 4; _s++) if (_P.edges[$ _signs[_s]].sign != _E[4][_s]) _bad = true;
            if (_row[10] == 1) {
                var _ol = _E[5];
                if (array_length(_P.outline) != array_length(_ol)) _bad = true;
                else for (var _q2 = 0; _q2 < array_length(_ol); _q2++) { _points++; if (!jig__st_near(_P.outline[_q2][0], _ol[_q2][0], 0.000000001) || !jig__st_near(_P.outline[_q2][1], _ol[_q2][1], 0.000000001)) _bad = true; }
            } else {
                var _sx = 0, _sy = 0, _sw = 0;
                for (var _q3 = 0; _q3 < array_length(_P.outline); _q3++) { _sx += _P.outline[_q3][0]; _sy += _P.outline[_q3][1]; _sw += _P.outline[_q3][0] * (_q3 + 1) - _P.outline[_q3][1] * (_q3 mod 7); }
                if (array_length(_P.outline) != _E[5] || !jig__st_near(_sx, _E[6], 0.000001) || !jig__st_near(_sy, _E[7], 0.000001) || !jig__st_near(_sw, _E[8], 0.0001)) _bad = true;
            }
            if (_bad) { _cb++; if (_cf == "") _cf = "cut " + string(_c) + " piece " + string(_p) + " box " + string_format(_P.homeX, 1, 9) + "," + string_format(_P.homeY, 1, 9) + " want " + string_format(_E[0], 1, 9) + "," + string_format(_E[1], 1, 9); }
        }
    }
    jig_st_assert(_st, _cb == 0 && _pieces == 623 && _points == 3240, "14 cuts, " + string(_pieces) + " pieces and " + string(_points) + " listed outline points against the MZ: " + string(_cb) + " differ " + _cf);
    // ---- 4: the flattened edges (8 steps, both directions) ----
    jig_st_stage(_st, 4);
    var _K1 = jig_cut({ w: 400, h: 300, cols: 3, rows: 3, seed: "castle" }), _eb = 0, _en = 0;
    for (var _e = 0; _e < 4; _e++) { var _fl = jig_flatten_edge(_K1.pieces[4].edges[$ _signs[_e]], 8), _want = _O.edges[_e]; if (array_length(_fl) != array_length(_want)) { _eb++; continue; } for (var _f = 0; _f < array_length(_fl); _f++) { _en++; if (!jig__st_near(_fl[_f][0], _want[_f][0], 0.000000001) || !jig__st_near(_fl[_f][1], _want[_f][1], 0.000000001)) _eb++; } }
    jig_st_assert(_st, _eb == 0 && _en == 100, "flatten_edge on the four edges of a middle piece: " + string(_eb) + " of " + string(_en) + " points differ");
    // ---- 5: the cut TILES the picture: every point inside exactly one piece ----
    jig_st_stage(_st, 5);
    var _tiling = [[640, 480, 6, 4, 7], [500, 500, 10, 10, "tiles"], [816, 624, 16, 16, 3]], _one = 0, _none = 0, _two = 0, _tot = 0;
    for (var _t = 0; _t < 3; _t++) {
        var _tc = _tiling[_t], _TK = jig_cut({ w: _tc[0], h: _tc[1], cols: _tc[2], rows: _tc[3], seed: _tc[4] }), _TR = jig__rng(99 + _t);
        for (var _pt = 0; _pt < 400; _pt++) {
            var _x = 1 + jig__rng_next(_TR) * (_tc[0] - 2), _y = 1 + jig__rng_next(_TR) * (_tc[1] - 2), _hits = 0;
            for (var _pi = 0; _pi < array_length(_TK.pieces); _pi++) if (jig_piece_contains(_TK.pieces[_pi], _x, _y)) _hits++;
            _tot++; if (_hits == 1) _one++; else if (_hits == 0) _none++; else _two++;
        }
    }
    jig_st_assert(_st, _one == _tot && _tot == 1200, "1200 random points over 3 cuts (24, 100, 256 pieces): " + string(_one) + " inside exactly one piece, " + string(_none) + " in none, " + string(_two) + " in two or more");
    var _Kc = jig_cut({ w: 640, h: 480, cols: 6, rows: 4, seed: 7 }), _knobs = 0;
    for (var _kk = 0; _kk < array_length(_Kc.pieces); _kk++) for (var _s2 = 0; _s2 < 4; _s2++) if (_Kc.pieces[_kk].edges[$ _signs[_s2]].sign != 0) _knobs++;
    jig_st_assert(_st, _knobs == 2 * ((6 - 1) * 4 + 6 * (4 - 1)), "every inner edge is a knob on one side and a socket on the other: " + string(_knobs) + " knobbed sides (want 76)");
    // ---- 6: the drawing - pieces and the table, ink counted, positive and negative controls ----
    jig_st_stage(_st, 6);
    var _pic = jig_demo_picture("harbour", 640, 480);
    var _picInk = jig__st_ink(_pic);
    jig_st_assert(_st, _picInk > 640 * 480 * 0.98, "the demo picture is painted edge to edge: " + string(_picInk) + " inked px of " + string(640 * 480));
    var _surfE = surface_create(32, 32); surface_set_target(_surfE); draw_clear_alpha(c_black, 0); surface_reset_target();
    var _empty = sprite_create_from_surface(_surfE, 0, 0, 32, 32, false, false, 0, 0); surface_free(_surfE);
    jig_st_assert(_st, jig__st_ink(_empty) == 0, "negative control: an empty sprite counts 0 ink (" + string(jig__st_ink(_empty)) + ")");
    sprite_delete(_empty);
    var _T6 = { pic: _pic, picSub: 0, cut: jig_cut({ w: 320, h: 240, cols: 4, rows: 3, seed: 21 }) }, _inkMin = 1000000000, _inkSum = 0, _areaMin = 1;
    for (var _d = 0; _d < 12; _d++) {
        var _pp = _T6.cut.pieces[_d], _pad = jig_margin(_pp), _sp = jig__bake(ceil(_pp.bw) + _pad * 2, ceil(_pp.bh) + _pad * 2, 0, 0, jig__pnt_piece, { T: _T6, p: _pp, pad: _pad, lifted: (_d mod 2) == 1 });
        var _ink = jig__st_ink(_sp), _area = _pp.bw * _pp.bh;
        _inkMin = min(_inkMin, _ink); _inkSum += _ink; _areaMin = min(_areaMin, _ink / (sprite_get_width(_sp) * sprite_get_height(_sp)));
        sprite_delete(_sp);
    }
    jig_st_assert(_st, _inkMin > 0, "12 drawn pieces (6 lifted): least ink " + string(_inkMin) + " px, least share of its sprite " + string_format(_areaMin, 1, 3));
    // the picture is CLIPPED to the piece: a white picture lights (nearly) exactly the outline's own area, never the box
    var _ws = surface_create(64, 64); surface_set_target(_ws); draw_clear(c_white); surface_reset_target();
    var _white = sprite_create_from_surface(_ws, 0, 0, 64, 64, false, false, 0, 0); surface_free(_ws);
    var _Tw = { pic: _white, picSub: 0, cut: _T6.cut }, _ratioLo = 10, _ratioHi = 0;
    for (var _d3 = 0; _d3 < 12; _d3++) {
        var _pw = _Tw.cut.pieces[_d3], _pdw = jig_margin(_pw), _spw = jig__bake(ceil(_pw.bw) + _pdw * 2, ceil(_pw.bh) + _pdw * 2, 0, 0, jig__pnt_piece, { T: _Tw, p: _pw, pad: _pdw, lifted: false });
        var _area = 0, _ol3 = _pw.outline, _n3 = array_length(_ol3);
        for (var _v = 0; _v < _n3; _v++) { var _a3 = _ol3[_v], _b3 = _ol3[(_v + 1) mod _n3]; _area += _a3[0] * _b3[1] - _b3[0] * _a3[1]; }
        _area = abs(_area) / 2;
        var _bw3 = sprite_get_width(_spw), _bh3 = sprite_get_height(_spw), _s3 = surface_create(_bw3, _bh3);
        surface_set_target(_s3); draw_clear_alpha(c_black, 0); gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_zero); draw_sprite(_spw, 0, 0, 0); gpu_pop_state(); surface_reset_target();
        var _buf = buffer_create(_bw3 * _bh3 * 4, buffer_fixed, 1); buffer_get_surface(_buf, _s3, 0);
        var _lit = 0; for (var _bi = 0; _bi < _bw3 * _bh3 * 4; _bi += 4) if (buffer_peek(_buf, _bi, buffer_u8) > 200) _lit++;
        buffer_delete(_buf); surface_free(_s3); sprite_delete(_spw);
        _ratioLo = min(_ratioLo, _lit / _area); _ratioHi = max(_ratioHi, _lit / _area);
    }
    sprite_delete(_white);
    jig_st_assert(_st, _ratioLo > 0.7 && _ratioHi < 1.05, "a white picture clipped to 12 pieces lights " + string_format(_ratioLo, 1, 3) + " to " + string_format(_ratioHi, 1, 3) + " of each outline's own area (the rim strokes darken the edge; above 1 would mean the box, not the piece)");
    var _sTab = jig__bake(816, 624, 0, 0, jig__pnt_table, { w: 816, h: 624 });
    var _tabInk = jig__st_ink(_sTab);
    jig_st_assert(_st, _tabInk == 816 * 624, "the table covers its whole sprite: " + string(_tabInk) + " of " + string(816 * 624));
    // ⛔ bake FIRST, then draw: a bake inside another surface target leaves that target's projection wrong (measured: the
    // pieces came out as white boxes). The scene bakes in Step and draws in Draw for the same reason.
    var _shot = surface_create(816, 624), _baked = [];
    for (var _d2 = 0; _d2 < 12; _d2++) { var _pq = _T6.cut.pieces[_d2], _pd = jig_margin(_pq); array_push(_baked, [jig__bake(ceil(_pq.bw) + _pd * 2, ceil(_pq.bh) + _pd * 2, 0, 0, jig__pnt_piece, { T: _T6, p: _pq, pad: _pd, lifted: _d2 == 5 }), _pq, _pd]); }
    surface_set_target(_shot); draw_clear(c_black);
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); draw_sprite(_sTab, 0, 0, 0);
    for (var _d4 = 0; _d4 < 12; _d4++) { var _bk = _baked[_d4]; draw_sprite(_bk[0], 0, 120 + _bk[1].homeX * 1.15 - _bk[2] + _bk[1].col * 26, 110 + _bk[1].homeY * 1.15 - _bk[2] + _bk[1].row * 26); }
    gpu_pop_state(); surface_reset_target(); surface_save(_shot, "jig_render_pieces.png");
    for (var _d5 = 0; _d5 < 12; _d5++) sprite_delete(_baked[_d5][0]);
    sprite_delete(_sTab);
    // ---- 7: a whole puzzle played by the mouse: 24 pieces dragged home, the ending, the result ----
    jig_st_stage(_st, 7);
    var _snd = { pick: 0, drop: 0, place: 0, solve: 0 };
    var _T = jig_open({ sprite: _pic, pieces: 24, seed: 7, width: 816, height: 624, key: "harbour", sound: method({ s: _snd }, function(_n) { s[$ _n] += 1; }) });
    jig_st_assert(_st, is_struct(_T) && _T.built && array_length(_T.pieces) == _T.cut.cols * _T.cut.rows && _T.layout.fits, "jig_open: built, " + (is_struct(_T) ? string(array_length(_T.pieces)) + " pieces (" + string(_T.cut.cols) + "x" + string(_T.cut.rows) + "), layout fits after " + string(_T.layout.tries) + " tries" : "undefined"));
    _st.metrics.open24Ms = is_struct(_T) ? _T.bakeMs : -1;
    _st.metrics.open24Timing = is_struct(_T) ? _T.timing : {};
    // every loose piece starts on the table and on a spot of its own
    var _onTable = 0, _overlap = 0;
    for (var _a = 0; _a < array_length(_T.pieces); _a++) {
        var _A = _T.pieces[_a], _ax = _A.x + _A.pad, _ay = _A.y + _A.pad;
        if (_ax >= _T.t && _ay >= _T.t && _ax + _A.p.bw <= _T.W - _T.t + 1 && _ay + _A.p.bh <= _T.H - _T.t + 1) _onTable++;
        for (var _b = _a + 1; _b < array_length(_T.pieces); _b++) { var _B = _T.pieces[_b], _bx = _B.x + _B.pad, _by = _B.y + _B.pad; if (_ax < _bx + _B.p.bw - 1 && _bx < _ax + _A.p.bw - 1 && _ay < _by + _B.p.bh - 1 && _by < _ay + _A.p.bh - 1) _overlap++; }
    }
    jig_st_assert(_st, _onTable == 24 && _overlap == 0, "the 24 loose pieces start on the felt (" + string(_onTable) + ") and no two outline boxes overlap (" + string(_overlap) + ")");
    jig__st_shot(_T, _shot, "jig_render_table.png");
    // a wrong drop first: into the middle of the empty frame (where no loose piece lies), far from its home - not placed
    var _w0 = _T.layer[array_length(_T.layer) - 1], _m0 = _T.moves, _W0 = _T.pieces[_w0];
    var _wdx = (_T.fx + _T.fw / 2 - _W0.p.bw / 2 - _W0.pad) - _W0.homeX, _wdy = (_T.fy + _T.fh / 2 - _W0.p.bh / 2 - _W0.pad) - _W0.homeY;
    jig__st_drag(_T, _w0, _wdx, _wdy);
    jig_st_assert(_st, (abs(_wdx) > _T.snap || abs(_wdy) > _T.snap) && !_W0.placed && _T.moves == _m0 + 1 && _T.placedN == 0, "a piece dropped " + string(round(point_distance(0, 0, _wdx, _wdy))) + " px from home stays loose and counts a move (moves " + string(_T.moves) + ", placed " + string(_T.placedN) + ")");
    var _dragged = 0, _order7 = [];
    for (var _o = 0; _o < 24; _o++) array_push(_order7, _o);
    for (var _o2 = 0; _o2 < 24; _o2++) { if (jig__st_drag(_T, _order7[_o2], 5, -4)) _dragged++; if (_o2 == 11) jig__st_shot(_T, _shot, "jig_render_midgame.png"); }
    jig_st_assert(_st, _dragged == 24 && _T.placedN == 24 && _T.done && _T.solved, "24 pieces dragged to within 6 px of home and snapped: placed " + string(_T.placedN) + ", solved " + string(_T.solved));
    for (var _f7 = 0; _f7 < 60; _f7++) { jig__st_in(_T, {}); if (_f7 == 20) jig__st_shot(_T, _shot, "jig_render_rising.png"); }
    jig__st_shot(_T, _shot, "jig_render_solved.png");
    jig__st_in(_T, { ok: true });
    var _r7 = _T.result;
    jig_st_assert(_st, jig_closed(_T) && is_struct(_r7) && _r7.solved && _r7.moves == 25 && _r7.placed == 24 && _r7.pieces == 24 && _r7.key == "harbour" && _r7.seed == "7", "the ending and the result: closed " + string(jig_closed(_T)) + ", " + json_stringify(_r7));
    jig_st_assert(_st, _snd.pick == 25 && _snd.place == 24 && _snd.drop == 1 && _snd.solve == 1, "sound hooks: pick " + string(_snd.pick) + ", place " + string(_snd.place) + ", drop " + string(_snd.drop) + ", solve " + string(_snd.solve));
    var _sprs = [_T.table, _T.frameSpr, _T.pieces[0].spr, _T.pieces[23].spr, _T.hudSpr, _T.plaqueSpr, _T.wholeSpr];
    jig_free(_T);
    var _left = 0; for (var _z = 0; _z < array_length(_sprs); _z++) if (_sprs[_z] >= 0 && sprite_exists(_sprs[_z])) _left++;
    jig_st_assert(_st, _left == 0 && sprite_exists(_pic), "jig_free deletes the puzzle's sprites (" + string(_left) + " left) and leaves the caller's picture");
    // ---- 8: the keyboard hand, the box lid, and setting a puzzle aside ----
    jig_st_stage(_st, 8);
    var _T8 = jig_open({ sprite: _pic, pieces: 12, seed: "keys", width: 816, height: 624 });
    var _i8 = _T8.layer[array_length(_T8.layer) - 1], _P8 = _T8.pieces[_i8], _pt8 = jig__st_point_in(_P8);
    var _walk = jig__st_hand_to(_T8, _pt8[0], _pt8[1]);
    jig__st_in(_T8, { ok: true });
    var _held8 = _T8.held == _i8;
    var _walk2 = jig__st_hand_to(_T8, _T8.hand.x + (_P8.homeX - _P8.x), _T8.hand.y + (_P8.homeY - _P8.y));
    jig__st_in(_T8, { ok: true });
    jig_st_assert(_st, _held8 && _P8.placed && _T8.placedN == 1 && _T8.hand.visible, "the keyboard hand walks to a piece (" + string(_walk) + " steps), picks it up with OK, carries it home (" + string(_walk2) + " steps) and snaps it: held " + string(_held8) + ", placed " + string(_P8.placed));
    for (var _l = 0; _l < 4; _l++) jig__st_in(_T8, { peek: true });
    var _lidUp = _T8.lidA;
    jig__st_shot(_T8, _shot, "jig_render_lid.png");
    for (var _l2 = 0; _l2 < 8; _l2++) jig__st_in(_T8, {});
    jig__st_in(_T8, { x: _T8.hudX + 20, y: _T8.hudY + 10, click: true, down: true }); jig__st_in(_T8, { x: _T8.hudX + 20, y: _T8.hudY + 10, down: true }); jig__st_in(_T8, { down: false });
    jig_st_assert(_st, _lidUp > 0.6 && _T8.peeks == 2 && _T8.held < 0, "the box lid: held Q raises it (" + string_format(_lidUp, 1, 2) + "), a press on the plaque too; peeks " + string(_T8.peeks) + ", nothing picked up");
    jig__st_in(_T8, { cancel: true });
    for (var _f8 = 0; _f8 < 56; _f8++) jig__st_in(_T8, {});
    jig__st_shot(_T8, _shot, "jig_render_set_aside.png");
    jig__st_in(_T8, { click: true });
    var _r8 = _T8.result;
    jig_st_assert(_st, jig_closed(_T8) && is_struct(_r8) && !_r8.solved && _r8.placed == 1 && _r8.pieces == 12 && _r8.peeks == 2 && _r8.seed == "keys", "set aside: " + json_stringify(_r8));
    jig_free(_T8);
    // a surface as the picture (a capture of a room): copied as it opens, freed with the puzzle
    var _cap = surface_create(400, 300); surface_set_target(_cap); draw_clear(make_colour_rgb(40, 60, 90)); draw_sprite_stretched(_pic, 0, 20, 20, 360, 260); surface_reset_target();
    var _Ts = jig_open({ surface: _cap, pieces: 6, seed: 2, width: 816, height: 624 });
    surface_free(_cap);
    var _ownPic = is_struct(_Ts) ? _Ts.pic : -1;
    jig_st_assert(_st, is_struct(_Ts) && _Ts.ownPic && sprite_exists(_ownPic) && _Ts.pw == 400 && array_length(_Ts.pieces) == _Ts.cut.cols * _Ts.cut.rows, "a SURFACE picture is copied as the puzzle opens (400x300, " + (is_struct(_Ts) ? string(array_length(_Ts.pieces)) : "?") + " pieces) and survives the surface being freed");
    jig_free(_Ts);
    jig_st_assert(_st, _ownPic >= 0 && !sprite_exists(_ownPic), "... and jig_free deletes that copy");
    jig_st_assert(_st, is_undefined(jig_open({ pieces: 24 })) && is_undefined(jig_open(undefined)) && is_undefined(jig_open({ sprite: -1 })), "no picture: jig_open refuses (undefined), never throws");
    // ---- 9: the demo room ----
    jig_st_stage(_st, 9);
    var _D = jig_demo_create(1024, 768);
    surface_free(_shot); _shot = surface_create(1024, 768);
    surface_set_target(_shot); draw_clear(c_black); jig_demo_draw(_D); surface_reset_target(); surface_save(_shot, "jig_render_demo.png");
    jig__demo_click(_D, _D.cards[2].x + 20, _D.cards[2].y + 20);
    surface_set_target(_shot); draw_clear(c_black); jig_demo_draw(_D); surface_reset_target(); surface_save(_shot, "jig_render_demo_wait.png");
    var _pend = _D.pending;
    jig_demo_step(_D);
    var _opened = is_struct(_D.puzzle) && _D.puzzle.key == 2;
    if (_opened) { surface_set_target(_shot); draw_clear(c_black); jig_demo_draw(_D); surface_reset_target(); surface_save(_shot, "jig_render_demo_castle.png"); }
    var _inkCards = 0; for (var _cc = 0; _cc < 3; _cc++) _inkCards += (jig__st_ink(_D.cards[_cc].spr) > 0) ? 1 : 0;
    jig_st_assert(_st, _inkCards == 3 && _pend == 2 && _opened && array_length(_D.puzzle.pieces) == _D.puzzle.cut.cols * _D.puzzle.cut.rows, "THE PUZZLE ROOM: 3 inked box lids, a click on the castle shows the cutting frame and opens its puzzle (" + (_opened ? string(array_length(_D.puzzle.pieces)) : "?") + " pieces at 1024x768)");
    jig_demo_free(_D);
    // ---- 10: what opening a puzzle costs on this runtime ----
    jig_st_stage(_st, 10);
    var _costs = [], _counts10 = [48, 96, 256];
    for (var _n10 = 0; _n10 < 3; _n10++) { var _cnt = _counts10[_n10], _T10 = jig_open({ sprite: _pic, pieces: _cnt, seed: 5, width: 816, height: 624 }); array_push(_costs, [_cnt, array_length(_T10.pieces), _T10.bakeMs, _T10.layout.fits]); jig_free(_T10); }
    _st.metrics.openCosts = _costs;
    jig_st_assert(_st, _costs[2][1] == 256, "256 pieces open (cut " + string(_costs[2][1]) + ")");
    array_push(_st.notes, "opening a puzzle (cut + layout + every piece baked at 2x): 24 pieces " + string_format(_st.metrics.open24Ms, 1, 0) + " ms; 48 " + string_format(_costs[0][2], 1, 0) + " ms; 96 " + string_format(_costs[1][2], 1, 0) + " ms; 256 " + string_format(_costs[2][2], 1, 0) + " ms");
    sprite_delete(_pic);
    surface_free(_shot);
    return _st;
}

/// @function jig_selftest_write(state)
function jig_selftest_write(_st) {
    var _f = file_text_open_write("jig_selftest.json");
    file_text_write_string(_f, json_stringify(_st));
    file_text_close(_f);
}
