{
  "$GMScript": "v1",
  "%Name": "jig_paint",
  "name": "jig_paint",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}