/// jig_demo.gml - THE PUZZLE ROOM, Jigsaw's demo: three pictures painted by the package (a harbour at dusk, a mountain
/// lake, a castle at night) on the table as box lids, a piece-count chooser, and the jigsaw itself on a click. Also the demo
/// pictures' painter, which the self-test cuts too. Replace the pictures with your own sprites: jig_open({ sprite: ... }).
///
/// Jigsaw - Jigsaw Puzzles From Any Picture, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// Public functions (each documented below): jig_demo_picture, jig_demo_create, jig_demo_step, jig_demo_draw, jig_demo_free.

/// @function jig_demo_picture_ids()
/// @returns {Array<String>} harbour, lake, castle
function jig_demo_picture_ids() { return ["harbour", "lake", "castle"]; }

/// internal: a seeded ridge line across [0, w] (midpoint displacement), as an array of y values at w / 64 steps.
function jig__ridge(_R, _w, _y0, _rough) {
    var _n = 65, _ys = array_create(_n, _y0);
    _ys[0] = _y0 + (jig__rng_next(_R) - 0.5) * _rough; _ys[64] = _y0 + (jig__rng_next(_R) - 0.5) * _rough;
    var _step = 64, _amp = _rough;
    while (_step > 1) {
        var _half = _step div 2;
        for (var _i = _half; _i < _n; _i += _step) _ys[_i] = (_ys[_i - _half] + _ys[min(_n - 1, _i + _half)]) / 2 + (jig__rng_next(_R) - 0.5) * _amp;
        _step = _half; _amp *= 0.55;
    }
    return _ys;
}

/// internal: the painter for a demo picture.
function jig__pnt_picture(_c, _a) {
    var _w = _a.w, _h = _a.h, _kind = _a.kind, _R = jig__rng(jig_seed_of("demo:" + _kind));
    var _sky0, _sky1, _sun, _far, _mid, _near, _water, _hz = _h * 0.56;
    if (_kind == "castle") { _sky0 = [12, 16, 44]; _sky1 = [58, 52, 104]; _sun = [244, 238, 214]; _far = [44, 46, 88]; _mid = [30, 30, 62]; _near = [16, 16, 34]; _water = [22, 26, 60]; _hz = _h * 0.62; }
    else if (_kind == "lake") { _sky0 = [86, 150, 210]; _sky1 = [222, 236, 240]; _sun = [255, 250, 226]; _far = [128, 150, 182]; _mid = [70, 108, 116]; _near = [32, 66, 52]; _water = [64, 120, 150]; _hz = _h * 0.58; }
    else { _sky0 = [54, 40, 92]; _sky1 = [250, 160, 92]; _sun = [255, 214, 140]; _far = [116, 78, 112]; _mid = [74, 46, 80]; _near = [36, 22, 42]; _water = [92, 66, 104]; _hz = _h * 0.6; }
    // sky
    var _g = jig_cx_linear(_c, 0, 0, 0, _hz); jig_cx_stop(_g, 0, _sky0); jig_cx_stop(_g, 1, _sky1);
    _c.fill = _g; jig_cx_fill_rect(_c, 0, 0, _w, _hz + 2);
    // stars (night) or a few soft clouds
    if (_kind == "castle") {
        for (var _s = 0; _s < 90; _s++) { var _sx = jig__rng_next(_R) * _w, _sy = jig__rng_next(_R) * _hz * 0.8, _sr = 0.5 + jig__rng_next(_R) * 1.3; _c.fill = jig_cx_solid([255, 250, 230], 0.35 + jig__rng_next(_R) * 0.6); jig_cx_begin(_c); jig_cx_arc(_c, _sx, _sy, _sr, 0, 2 * pi); jig_cx_fill(_c); }
    } else {
        // clouds: a flat base and a few puffs of different sizes, lit on top, all drawn into one soft (blurred) layer so no
        // ellipse edge shows; one fill per cloud body (the union), so overlapping puffs never stack their alpha
        jig__p_blur_begin(_c, 2.2);
        for (var _k = 0; _k < 6; _k++) {
            var _cx = jig__rng_next(_R) * _w, _cy = _hz * (0.14 + jig__rng_next(_R) * 0.42), _cw = _w * (0.1 + jig__rng_next(_R) * 0.14), _np = 3 + floor(jig__rng_next(_R) * 3);
            var _lit = (_kind == "harbour") ? [255, 206, 170] : [255, 255, 255], _sh = (_kind == "harbour") ? [150, 92, 128] : [206, 220, 236];
            // a sunset's clouds are long streaks: the same body drawn stretched along the horizon
            jig_cx_save(_c);
            if (_kind == "harbour") { jig_cx_translate(_c, _cx, _cy); jig_cx_scale(_c, 2.1, 0.42); jig_cx_translate(_c, -_cx, -_cy); }
            jig_cx_begin(_c); jig_cx_ellipse(_c, _cx, _cy, _cw * 0.62, _cw * 0.11, 0, 0, 2 * pi);
            for (var _b = 0; _b < _np; _b++) { var _pr = _cw * (0.14 + jig__rng_next(_R) * 0.14), _px0 = _cx + (_b - (_np - 1) / 2) * _cw * 0.3 + (jig__rng_next(_R) - 0.5) * _cw * 0.1; jig_cx_move(_c, _px0 + _pr, _cy - _pr * 0.35); jig_cx_arc(_c, _px0, _cy - _pr * 0.35, _pr, 0, 2 * pi); }
            _c.fill = jig_cx_solid(_sh, 0.55); jig_cx_fill(_c);
            jig_cx_save(_c); jig_cx_translate(_c, 0, -_cw * 0.035);
            jig_cx_begin(_c);
            for (var _b2 = 0; _b2 < _np; _b2++) { var _pr2 = _cw * (0.12 + jig__rng_next(_R) * 0.1), _px2 = _cx + (_b2 - (_np - 1) / 2) * _cw * 0.3; jig_cx_move(_c, _px2 + _pr2, _cy - _pr2 * 0.55); jig_cx_arc(_c, _px2, _cy - _pr2 * 0.55, _pr2, 0, 2 * pi); }
            _c.fill = jig_cx_solid(_lit, 0.5); jig_cx_fill(_c);
            jig_cx_restore(_c);
            jig_cx_restore(_c);
        }
        jig__p_blur_end(_c);
    }
    // the sun or the moon with its glow
    var _ux = _w * ((_kind == "lake") ? 0.72 : ((_kind == "castle") ? 0.78 : 0.5)), _uy = _hz * ((_kind == "harbour") ? 0.84 : 0.3), _ur = min(_w, _h) * ((_kind == "harbour") ? 0.09 : 0.055);
    var _gl = jig_cx_radial(_c, _ux, _uy, _ur * 0.8, _ux, _uy, _ur * 5); jig_cx_stop(_gl, 0, _sun, 0.55); jig_cx_stop(_gl, 1, _sun, 0);
    _c.fill = _gl; jig_cx_fill_rect(_c, _ux - _ur * 5, _uy - _ur * 5, _ur * 10, _ur * 10);
    _c.fill = jig_cx_solid(_sun); jig_cx_begin(_c); jig_cx_arc(_c, _ux, _uy, _ur, 0, 2 * pi); jig_cx_fill(_c);
    // three ridges, far to near, each lit from above
    var _cols = [_far, _mid, _near], _lift = [0.16, 0.08, 0.02], _rough = [_h * 0.22, _h * 0.16, _h * 0.1];
    for (var _r = 0; _r < 3; _r++) {
        var _ys = jig__ridge(_R, _w, _hz - _h * _lift[_r], _rough[_r]);
        jig_cx_begin(_c); jig_cx_move(_c, 0, _hz + 1);
        for (var _i = 0; _i < 65; _i++) jig_cx_line(_c, _w * _i / 64, min(_hz + 1, _ys[_i]));
        jig_cx_line(_c, _w, _hz + 1); jig_cx_close(_c);
        var _top = _hz - _h * (_lift[_r] + 0.2), _rg = jig_cx_linear(_c, 0, _top, 0, _hz);
        var _cl = _cols[_r];
        jig_cx_stop(_rg, 0, [min(255, _cl[0] + 26), min(255, _cl[1] + 26), min(255, _cl[2] + 26)]); jig_cx_stop(_rg, 1, _cl);
        _c.fill = _rg; jig_cx_fill(_c);
    }
    // the castle on the near ridge, its windows lit
    if (_kind == "castle") {
        var _bx = _w * 0.3, _by = _hz - _h * 0.02, _u = _w / 64;
        _c.fill = jig_cx_solid([10, 10, 24]);
        jig_cx_fill_rect(_c, _bx, _by - _u * 9, _u * 16, _u * 9);
        for (var _t = 0; _t < 3; _t++) { var _tx = _bx - _u + _t * _u * 7.5, _th = _u * (14 + (_t == 1) * 6); jig_cx_fill_rect(_c, _tx, _by - _th, _u * 3, _th); jig_cx_begin(_c); jig_cx_move(_c, _tx - _u * 0.4, _by - _th); jig_cx_line(_c, _tx + _u * 1.5, _by - _th - _u * 4); jig_cx_line(_c, _tx + _u * 3.4, _by - _th); jig_cx_close(_c); jig_cx_fill(_c); }
        for (var _m = 0; _m < 8; _m++) jig_cx_fill_rect(_c, _bx + _m * _u * 2, _by - _u * 10, _u, _u);
        _c.fill = jig_cx_solid([255, 206, 110], 0.95);
        for (var _q = 0; _q < 9; _q++) jig_cx_fill_rect(_c, _bx + _u * (1.5 + (_q mod 5) * 3), _by - _u * (3 + (_q div 5) * 3.5), _u * 0.8, _u * 1.3);
    }
    // water with the sky's reflection and glints
    var _wg = jig_cx_linear(_c, 0, _hz, 0, _h); jig_cx_stop(_wg, 0, _sky1, 1); jig_cx_stop(_wg, 0.25, _water, 1); jig_cx_stop(_wg, 1, [floor(_water[0] * 0.5), floor(_water[1] * 0.5), floor(_water[2] * 0.5)], 1);
    _c.fill = _wg; jig_cx_fill_rect(_c, 0, _hz, _w, _h - _hz);
    _c.join = 0;
    for (var _l = 0; _l < 60; _l++) {
        var _ly = _hz + 3 + jig__rng_next(_R) * (_h - _hz - 6), _lx = (_ux - _w * 0.12) + jig__rng_next(_R) * _w * 0.24 * (1 + (_ly - _hz) / _h);
        _c.stroke = jig_cx_solid(_sun, 0.18 + jig__rng_next(_R) * 0.4); _c.lw = 1 + jig__rng_next(_R) * 1.5;
        jig_cx_begin(_c); jig_cx_move(_c, _lx, _ly); jig_cx_line(_c, _lx + 6 + jig__rng_next(_R) * 26, _ly); jig_cx_stroke(_c);
    }
    // the harbour: boats with masts, moored on the water
    if (_kind == "harbour") {
        for (var _bt = 0; _bt < 4; _bt++) {
            var _hx = _w * (0.12 + _bt * 0.22 + jig__rng_next(_R) * 0.05), _hy = _hz + (_h - _hz) * (0.3 + jig__rng_next(_R) * 0.4), _hs = _w * (0.05 + jig__rng_next(_R) * 0.03);
            _c.fill = jig_cx_solid([28, 16, 30]);
            jig_cx_begin(_c); jig_cx_move(_c, _hx - _hs, _hy); jig_cx_line(_c, _hx + _hs, _hy); jig_cx_line(_c, _hx + _hs * 0.7, _hy + _hs * 0.35); jig_cx_line(_c, _hx - _hs * 0.7, _hy + _hs * 0.35); jig_cx_close(_c); jig_cx_fill(_c);
            jig_cx_fill_rect(_c, _hx - 1, _hy - _hs * 2.2, 2, _hs * 2.2);
            _c.fill = jig_cx_solid([250, 222, 180], 0.85);
            jig_cx_begin(_c); jig_cx_move(_c, _hx + 2, _hy - _hs * 2); jig_cx_line(_c, _hx + _hs * 0.9, _hy - _hs * 0.3); jig_cx_line(_c, _hx + 2, _hy - _hs * 0.3); jig_cx_close(_c); jig_cx_fill(_c);
        }
    }
    // foreground pines (lake, castle)
    if (_kind != "harbour") {
        _c.fill = jig_cx_solid((_kind == "castle") ? [6, 8, 18] : [16, 40, 30]);
        for (var _p = 0; _p < 14; _p++) {
            var _px = (_p < 7) ? jig__rng_next(_R) * _w * 0.22 : _w * 0.78 + jig__rng_next(_R) * _w * 0.22, _pb = _h - jig__rng_next(_R) * _h * 0.06, _ph = _h * (0.22 + jig__rng_next(_R) * 0.2), _pw = _ph * 0.28;
            for (var _tier = 0; _tier < 3; _tier++) { var _ty = _pb - _ph * (_tier * 0.28); jig_cx_begin(_c); jig_cx_move(_c, _px - _pw * (1 - _tier * 0.2), _ty); jig_cx_line(_c, _px, _ty - _ph * 0.48); jig_cx_line(_c, _px + _pw * (1 - _tier * 0.2), _ty); jig_cx_close(_c); jig_cx_fill(_c); }
        }
    }
}

/// @function jig_demo_picture(kind, w, h)
/// @description One of the demo's three pictures, painted by the package (no image file): "harbour", "lake" or "castle".
/// Returns a NEW sprite (free it with sprite_delete when done), 64 to 2048 px a side; an unknown kind paints the harbour.
/// @returns {Asset.GMSprite}
function jig_demo_picture(_kind, _w = 640, _h = 480) {
    var _k = (is_string(_kind) && array_contains(jig_demo_picture_ids(), _kind)) ? _kind : "harbour";
    _w = clamp(floor(jig__fin(_w, 640)), 64, 2048); _h = clamp(floor(jig__fin(_h, 480)), 64, 2048);
    return jig__bake(_w, _h, 0, 0, jig__pnt_picture, { w: _w, h: _h, kind: _k });
}

// ---------------------------------------------------------------------------------------------------------------
// The demo room
// ---------------------------------------------------------------------------------------------------------------

function jig__pnt_demo_bg(_c, _a) {
    jig_draw_table(_c, _a.w, _a.h, { seed: 11 });
    var _S = _a.S, _ty = _a.ty;
    jig__text(_c, "THE PUZZLE ROOM", 0, _ty, _a.w, jig__round(40 * _S), jig__round(30 * _S), JIG_FACE_DISPLAY, "center", [246, 226, 180], 1);
    jig__text(_c, "Three pictures painted by the package. Pick a box, choose the pieces, and assemble it.", 0, _ty + jig__round(38 * _S), _a.w, jig__round(24 * _S), jig__round(15 * _S), JIG_FACE_BODY, "center", [234, 215, 176], 0.8);
}
function jig__pnt_card(_c, _a) {
    var _w = _a.w, _h = _a.h, _ih = _a.ih;
    jig_cx_begin(_c); jig_cx_rect(_c, 6, 6, _w - 12, _h - 12);
    jig_cx_shadow(_c, [0, 0, 0], 0.45, 9, 3, 5); _c.fill = jig_cx_solid([30, 20, 12]); jig_cx_fill(_c);
    _c.fill = jig_cx_solid([40, 26, 16]); jig_cx_fill_rect(_c, 6, 6, _w - 12, _h - 12);
    jig_cx_image(_c, _a.pic, 0, 12, 12, _w - 24, _ih);
    _c.stroke = jig_cx_solid([244, 206, 128], 0.8); _c.lw = 1.5; jig_cx_stroke_rect(_c, 11, 11, _w - 22, _ih + 2);
    jig__text(_c, _a.title, 12, 12 + _ih + 6, _w - 24, 26, 18, JIG_FACE_DISPLAY, "center", [246, 226, 180], 1);
    jig__text(_c, _a.sub, 12, 12 + _ih + 30, _w - 24, 20, 14, JIG_FACE_BODY, "center", [234, 215, 176], _a.done ? 0.95 : 0.7);
}
function jig__pnt_wait(_c, _a) {
    _c.fill = jig_cx_solid([0, 0, 0], 0.55); jig_cx_fill_rect(_c, 0, 0, _a.w, _a.h);
    jig__text(_c, "Cutting the picture" + chr(183) + chr(183) + chr(183), 0, _a.h / 2 - 20, _a.w, 40, 26, JIG_FACE_DISPLAY, "center", [246, 226, 180], 1);
}

/// @function jig_demo_create(width, height)
/// @description THE PUZZLE ROOM: three painted pictures as box lids, a piece-count chooser (12 / 24 / 48 / 96) under them,
/// and the puzzle on a click. Returns the demo (a struct). Free it with jig_demo_free.
/// @returns {Struct}
function jig_demo_create(_w = undefined, _h = undefined) {
    var _W = max(640, floor(jig__fin(_w, display_get_gui_width()))), _H = max(480, floor(jig__fin(_h, display_get_gui_height())));
    var _S = jig_ui_scale(_W, _H);
    var _D = { W: _W, H: _H, S: _S, pics: [], cards: [], counts: [12, 24, 48, 96], countIx: 1, puzzle: undefined, pending: -1, wait: -1, bg: -1, chooser: -1, chooserKey: -1, solved: [false, false, false], results: [], x: 0, y: 0, scale: 1, cursor: 0, rep: 0 };
    var _ids = jig_demo_picture_ids(), _titles = ["Harbour at Dusk", "Mountain Lake", "Castle at Night"];
    var _cw = floor(min((_W - 80) / 3, 300)), _ih = floor(_cw * 0.75), _ch = _ih + 72;
    // the title, the three boxes and the chooser as ONE group, centred on the table
    var _head = jig__round(84 * _S), _group = _head + _ch + 18 + 64, _ty = max(jig_felt_inset(_W, _H) + 8, floor((_H - _group) / 2));
    _D.bg = jig__bake(_W, _H, 0, 0, jig__pnt_demo_bg, { w: _W, h: _H, S: _S, ty: _ty });
    for (var _i = 0; _i < 3; _i++) {
        array_push(_D.pics, jig_demo_picture(_ids[_i], 640, 480));
        var _cx = floor(_W / 2 + (_i - 1) * (_cw + 20) - _cw / 2), _cy = _ty + _head;
        array_push(_D.cards, { x: _cx, y: _cy, w: _cw, h: _ch, ih: _ih, title: _titles[_i], spr: -1 });
    }
    jig__demo_cards(_D);
    _D.wait = jig__bake(_W, _H, 0, 0, jig__pnt_wait, { w: _W, h: _H });
    jig__demo_chooser(_D);
    return _D;
}
function jig__demo_cards(_D) {
    for (var _i = 0; _i < 3; _i++) {
        var _C = _D.cards[_i];
        if (_C.spr >= 0 && sprite_exists(_C.spr)) sprite_delete(_C.spr);
        _C.spr = jig__bake(_C.w, _C.h, 0, 0, jig__pnt_card, { w: _C.w, h: _C.h, ih: _C.ih, pic: _D.pics[_i], title: _C.title, sub: _D.solved[_i] ? "SOLVED" : "click to cut", done: _D.solved[_i] });
    }
}
function jig__pnt_chooser(_c, _a) {
    var _D = _a.D, _n = array_length(_D.counts);
    jig__text(_c, "PIECES", 0, 0, _a.w, 22, 14, JIG_FACE_BODY, "center", [234, 215, 176], 0.75);
    for (var _i = 0; _i < _n; _i++) {
        var _bx = _a.w / 2 + (_i - (_n - 1) / 2) * 76 - 32, _on = (_i == _D.countIx);
        _c.fill = jig_cx_solid(_on ? [244, 196, 112] : [24, 14, 8], _on ? 0.95 : 0.62); jig__rrect(_c, _bx, 26, 64, 34, 6); jig_cx_fill(_c);
        _c.stroke = jig_cx_solid([255, 226, 170], 0.5); _c.lw = 1; jig__rrect(_c, _bx + 0.5, 26.5, 63, 33, 6); jig_cx_stroke(_c);
        jig__text(_c, string(_D.counts[_i]), _bx, 26, 64, 34, 18, JIG_FACE_DISPLAY, "center", _on ? [30, 18, 8] : [246, 226, 180], 1);
    }
}
function jig__demo_chooser(_D) {
    if (_D.chooserKey == _D.countIx) return;
    _D.chooserKey = _D.countIx;
    if (_D.chooser >= 0 && sprite_exists(_D.chooser)) sprite_delete(_D.chooser);
    _D.chooser = jig__bake(360, 64, 0, 0, jig__pnt_chooser, { D: _D, w: 360 });
}

/// @function jig_demo_step(demo)
/// @description Run the room, or the puzzle while one is open. Call in Step.
function jig_demo_step(_D) {
    if (!is_struct(_D)) return;
    if (is_struct(_D.puzzle)) {
        jig_step(_D.puzzle);
        if (jig_closed(_D.puzzle)) {
            var _r = _D.puzzle.result;
            if (is_struct(_r)) { array_push(_D.results, _r); if (_r.solved) { _D.solved[_D.puzzle.key] = true; jig__demo_cards(_D); } }
            jig_free(_D.puzzle); _D.puzzle = undefined;
        }
        return;
    }
    if (_D.pending >= 0) {
        // the "cutting" frame has been drawn; open now (baking every piece takes a moment)
        _D.puzzle = jig_open({ sprite: _D.pics[_D.pending], pieces: _D.counts[_D.countIx], width: _D.W, height: _D.H, key: _D.pending });
        _D.pending = -1;
        return;
    }
    var _mx = (device_mouse_x_to_gui(0) - _D.x) / _D.scale, _my = (device_mouse_y_to_gui(0) - _D.y) / _D.scale;
    if (keyboard_check_pressed(vk_left)) _D.cursor = (_D.cursor + 2) mod 3;
    if (keyboard_check_pressed(vk_right)) _D.cursor = (_D.cursor + 1) mod 3;
    if (keyboard_check_pressed(vk_up)) _D.countIx = min(array_length(_D.counts) - 1, _D.countIx + 1);
    if (keyboard_check_pressed(vk_down)) _D.countIx = max(0, _D.countIx - 1);
    if (keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space)) _D.pending = _D.cursor;
    if (mouse_check_button_pressed(mb_left)) jig__demo_click(_D, _mx, _my);
    jig__demo_chooser(_D);
}
/// internal: a click in the room at (x, y): a card opens its puzzle, a count button chooses the count.
function jig__demo_click(_D, _x, _y) {
    for (var _i = 0; _i < 3; _i++) { var _C = _D.cards[_i]; if (_x >= _C.x && _y >= _C.y && _x < _C.x + _C.w && _y < _C.y + _C.h) { _D.cursor = _i; _D.pending = _i; return; } }
    var _n = array_length(_D.counts), _ox = floor(_D.W / 2 - 180), _oy = _D.cards[0].y + _D.cards[0].h + 18;
    for (var _k = 0; _k < _n; _k++) { var _bx = _ox + 180 + (_k - (_n - 1) / 2) * 76 - 32; if (_x >= _bx && _x < _bx + 64 && _y >= _oy + 26 && _y < _oy + 60) { _D.countIx = _k; return; } }
}

/// @function jig_demo_draw(demo, [x], [y], [scale])
/// @description Draw the room, or the puzzle while one is open. Call in Draw GUI.
function jig_demo_draw(_D, _x = 0, _y = 0, _scale = 1) {
    if (!is_struct(_D)) return;
    _D.x = _x; _D.y = _y; _D.scale = _scale;
    if (is_struct(_D.puzzle)) { jig_draw(_D.puzzle, _x, _y, _scale); return; }
    var _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_multiply(matrix_build(_x, _y, 0, 0, 0, 0, _scale, _scale, 1), _mw));
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); gpu_set_texfilter(true);
    jig__draw_spr(_D.bg, 0, 0, 1);
    for (var _i = 0; _i < 3; _i++) { var _C = _D.cards[_i]; jig__draw_spr(_C.spr, _C.x, _C.y - ((_i == _D.cursor) ? 4 : 0), 1); }
    jig__draw_spr(_D.chooser, floor(_D.W / 2 - 180), _D.cards[0].y + _D.cards[0].h + 18, 1);
    if (_D.pending >= 0) jig__draw_spr(_D.wait, 0, 0, 1);
    gpu_pop_state();
    matrix_set(matrix_world, _mw);
}

/// @function jig_demo_free(demo)
/// @description Free every sprite the demo (and an open puzzle) made.
function jig_demo_free(_D) {
    if (!is_struct(_D)) return;
    if (is_struct(_D.puzzle)) jig_free(_D.puzzle);
    _D.puzzle = undefined;
    var _f = ["bg", "wait", "chooser"];
    for (var _i = 0; _i < 3; _i++) { var _s = _D[$ _f[_i]]; if (is_numeric(_s) && _s >= 0 && sprite_exists(_s)) sprite_delete(_s); _D[$ _f[_i]] = -1; }
    for (var _c = 0; _c < array_length(_D.cards); _c++) { var _C = _D.cards[_c]; if (_C.spr >= 0 && sprite_exists(_C.spr)) sprite_delete(_C.spr); _C.spr = -1; }
    for (var _p = 0; _p < array_length(_D.pics); _p++) if (sprite_exists(_D.pics[_p])) sprite_delete(_D.pics[_p]);
    _D.pics = [];
}
