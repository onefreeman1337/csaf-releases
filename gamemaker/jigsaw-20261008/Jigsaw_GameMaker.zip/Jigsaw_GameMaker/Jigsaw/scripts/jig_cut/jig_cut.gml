/// jig_cut.gml - Jigsaw's cutting model: any picture cut into interlocking knob-and-socket pieces from a seed. Pure GML:
/// nothing here draws, and nothing uses the engine's random functions.
///
/// Jigsaw - Jigsaw Puzzles From Any Picture, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// The RPG Maker MZ edition's JigsawCut.js, ported line for line and held to it by the in-engine suite (jig_selftest): the
/// seed hash, the generator, the grid choice and every piece's box and outline point EXACT.
///
/// How a cut is made
///   1. A grid sized to the picture's aspect, its inner corners nudged so no two pieces are the same rectangle.
///   2. Every inner edge becomes ONE knob curve (three cubic segments), with the knob's side, size, lean and neck drawn
///      from the seed.
///   3. The two pieces that share an edge both use that same curve, one forwards and one backwards, so a tab always meets
///      its own socket and the pieces tile the picture exactly. The border stays straight.
/// The same seed always cuts the same puzzle.
///
/// Public functions (each documented below): jig_seed_of, jig_grid_for, jig_cut, jig_flatten_edge, jig_flatten_outline,
/// jig_piece_contains.

#macro JIG_VERSION "1.0.0"
#macro JIG_MIN_SIDE 2
#macro JIG_MAX_SIDE 16

// ---------------------------------------------------------------------------------------------------------------
// Unsigned 32-bit arithmetic, the seed hash and the generator (the MZ edition's, exact)
// ---------------------------------------------------------------------------------------------------------------

/// @function jig__imul(a, b)
/// @description Internal. JavaScript's Math.imul on unsigned 32-bit values, as int64 halves.
function jig__imul(_a, _b) {
    var _m = int64($FFFFFFFF);
    _a = int64(_a) & _m; _b = int64(_b) & _m;
    var _lo = (_a * (_b & int64($FFFF))) & _m;
    var _hi = ((_a * (_b >> 16)) & int64($FFFF)) << 16;
    return (_lo + _hi) & _m;
}

/// @function jig__u32(v)
/// @description Internal. JavaScript's (v >>> 0) for a number: truncated toward zero, then modulo 2^32; not a number -> 0.
function jig__u32(_v) {
    if (!is_numeric(_v) || is_nan(_v) || is_infinity(_v)) return int64(0);
    return int64(_v) & int64($FFFFFFFF);
}

/// @function jig__is_number_text(text)
/// @description Internal. True for a string that is a plain decimal number ("7", " 42 ", "-3.5"): the MZ edition reads
/// such a seed as the number. Other strings (hex, exponents, words) are hashed as text.
function jig__is_number_text(_s) {
    var _t = string_trim(_s), _n = string_length(_t);
    if (_n == 0) return false;
    var _dot = false, _digits = 0;
    for (var _i = 1; _i <= _n; _i++) {
        var _ch = string_char_at(_t, _i);
        if (_ch == "-" && _i == 1) continue;
        if (_ch == "." && !_dot) { _dot = true; continue; }
        if (ord(_ch) < 48 || ord(_ch) > 57) return false;
        _digits++;
    }
    return _digits > 0;
}

/// @function jig_seed_of(seed)
/// @description The cut's unsigned 32-bit seed from a number or a word: a number (or a string that is a plain decimal
/// number) is used as it is (whole part, sign dropped); any other text is hashed (FNV-1a). Never 0. Pure.
/// @param {Real|String} seed
/// @returns {Real} 1 .. 4294967295
function jig_seed_of(_s) {
    if (is_numeric(_s) && !is_nan(_s) && !is_infinity(_s)) { var _u = jig__u32(floor(abs(_s))); return (_u == 0) ? 1 : real(_u); }
    if (is_string(_s) && jig__is_number_text(_s)) { var _u2 = jig__u32(floor(abs(real(string_trim(_s))))); return (_u2 == 0) ? 1 : real(_u2); }
    var _t = is_string(_s) ? _s : ((is_undefined(_s)) ? "undefined" : string(_s));
    var _h = int64(2166136261);
    var _n = string_length(_t);
    for (var _i = 1; _i <= _n; _i++) { _h = _h ^ int64(ord(string_char_at(_t, _i)) & $FFFF); _h = jig__imul(_h, 16777619); }
    return (_h == 0) ? 1 : real(_h);
}

/// @function jig__rng(seed)
/// @description Internal. The MZ edition's generator (mulberry32) as a struct { a }; draw with jig__rng_next.
function jig__rng(_seed) { return { a: jig__u32(_seed) }; }

/// @function jig__rng_next(rng)
/// @description Internal. The next draw in [0, 1).
function jig__rng_next(_r) {
    var _m = int64($FFFFFFFF);
    _r.a = (_r.a + int64($6D2B79F5)) & _m;
    var _t = _r.a;
    _t = jig__imul(_t ^ (_t >> 15), _t | 1);
    var _x = jig__imul(_t ^ (_t >> 7), _t | 61);
    _t = _t ^ ((_t + _x) & _m);
    return real((_t ^ (_t >> 14)) & _m) / 4294967296;
}

/// @function jig__clamp_side(v)
/// @description Internal. A side count rounded (half up, as JavaScript's Math.round) and clamped to 2..16; not a number -> 4.
function jig__clamp_side(_v) {
    if (!is_numeric(_v) || is_nan(_v) || is_infinity(_v)) return 4;
    return max(JIG_MIN_SIDE, min(JIG_MAX_SIDE, floor(_v + 0.5)));
}

/// @function jig__num(v, fallback)
/// @description Internal. A finite number, or the fallback (JavaScript's `Number(v) || d` for the cases the MZ edition meets).
function jig__num(_v, _d) {
    if (is_numeric(_v) && !is_nan(_v) && !is_infinity(_v) && _v != 0) return _v;
    return _d;
}

// ---------------------------------------------------------------------------------------------------------------
// The grid, the knob curve and the cut
// ---------------------------------------------------------------------------------------------------------------

/// @function jig_grid_for(w, h, pieces)
/// @description The grid for about `pieces` pieces on a w x h picture, keeping each cell near square (2..16 a side).
/// Pure.
/// @returns {Struct} { cols, rows }
function jig_grid_for(_w, _h, _n) {
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _G = jig__grid_for(_w, _h, _n);
    math_set_epsilon(_eps);
    return _G;
}

/// @function jig__grid_for(w, h, pieces)
/// @description Internal. jig_grid_for's body (run with the comparison epsilon off).
function jig__grid_for(_w, _h, _n) {
    _w = max(1, jig__num(_w, 1)); _h = max(1, jig__num(_h, 1)); _n = max(4, jig__num(_n, 24));
    var _bc = 0, _br = 0, _bs = 0, _have = false, _big = power(10, 30);
    for (var _rows = JIG_MIN_SIDE; _rows <= JIG_MAX_SIDE; _rows++) {
        for (var _cols = JIG_MIN_SIDE; _cols <= JIG_MAX_SIDE; _cols++) {
            var _aspect = (_w / _cols) / (_h / _rows);
            var _score = abs(_cols * _rows - _n) / _n + abs(ln(_aspect)) * 0.8;
            // ⛔ GML's `<` applies the comparison epsilon, so a near-tie (a square picture's 4x3 against 3x4 differ in the
            // last bit) reads as equal; the MZ edition takes the strictly smaller. Compare the difference scaled up.
            if (!_have || (_score - _bs) * _big < -0.5) { _bc = _cols; _br = _rows; _bs = _score; _have = true; }
        }
    }
    return { cols: _bc, rows: _br };
}

/// @function jig__knob_edge(A, B, axisNormal, sign, rng)
/// @description Internal. A knob curve from A to B (ten control points: three cubic segments), bulging toward the normal
/// side `sign` (+1 / -1; 0 = straight). Draws six numbers from the generator whatever the sign (as the MZ edition).
function jig__knob_edge(_A, _B, _axis, _sign, _R) {
    var _ux = _B[0] - _A[0], _uy = _B[1] - _A[1];
    var _nx = -_uy, _ny = _ux;
    if (_nx * _axis[0] + _ny * _axis[1] < 0) { _nx = -_nx; _ny = -_ny; }
    var _t = 0.085 + jig__rng_next(_R) * 0.025;
    var _a = (jig__rng_next(_R) * 2 - 1) * 0.035;
    var _b = (jig__rng_next(_R) * 2 - 1) * 0.035;
    var _c = (jig__rng_next(_R) * 2 - 1) * 0.035;
    var _d = (jig__rng_next(_R) * 2 - 1) * 0.035;
    var _e = (jig__rng_next(_R) * 2 - 1) * 0.035;
    var _local = undefined;
    if (_sign != 0) _local = [[0, 0], [0.2, _a], [0.5 + _b + _d, -_t + _c], [0.5 - _t + _b, _t + _c], [0.5 - 2 * _t + _b - _d, 3 * _t + _c],
        [0.5 + 2 * _t + _b - _d, 3 * _t + _c], [0.5 + _t + _b, _t + _c], [0.5 + _b + _d, -_t + _c], [0.8, _e], [1, 0]];
    var _pts = array_create(10);
    for (var _i = 0; _i < 10; _i++) {
        var _L = is_undefined(_local) ? [_i / 9, 0] : _local[_i];
        var _s = is_undefined(_local) ? 0 : _L[1] * _sign;
        _pts[_i] = [_A[0] + _ux * _L[0] + _nx * _s, _A[1] + _uy * _L[0] + _ny * _s];
    }
    return { pts: _pts, sign: _sign, knob: (_sign == 0) ? 0 : _t };
}

/// @function jig__cubic(p0, p1, p2, p3, t)
/// @description Internal. A point on a cubic Bezier.
function jig__cubic(_p0, _p1, _p2, _p3, _t) {
    var _m = 1 - _t;
    return [_m * _m * _m * _p0[0] + 3 * _m * _m * _t * _p1[0] + 3 * _m * _t * _t * _p2[0] + _t * _t * _t * _p3[0],
        _m * _m * _m * _p0[1] + 3 * _m * _m * _t * _p1[1] + 3 * _m * _t * _t * _p2[1] + _t * _t * _t * _p3[1]];
}

/// @function jig_flatten_edge(edge, [steps])
/// @description Points along a piece edge in the PIECE's direction (clockwise round the piece), first to last inclusive.
/// Pure.
/// @param {Struct} edge a piece edge { base, reversed, sign, knob }
/// @param {Real} [steps] samples per cubic segment (default 8)
/// @returns {Array<Array<Real>>}
function jig_flatten_edge(_edge, _steps = 8) {
    if (!is_struct(_edge) || !is_struct(_edge[$ "base"])) return [];
    _steps = (is_numeric(_steps) && _steps >= 1) ? floor(_steps) : 8;
    var _P = _edge.base.pts, _out = [_P[0]];
    for (var _seg = 0; _seg < 3; _seg++) {
        var _k = _seg * 3;
        for (var _s = 1; _s <= _steps; _s++) array_push(_out, jig__cubic(_P[_k], _P[_k + 1], _P[_k + 2], _P[_k + 3], _s / _steps));
    }
    if (_edge.reversed) { var _r = array_create(array_length(_out)); for (var _i = 0; _i < array_length(_out); _i++) _r[_i] = _out[array_length(_out) - 1 - _i]; return _r; }
    return _out;
}

/// @function jig_flatten_outline(piece, [steps])
/// @description The closed outline of a piece (each corner once), clockwise, in picture coordinates. Pure.
/// @returns {Array<Array<Real>>}
function jig_flatten_outline(_piece, _steps = 8) {
    if (!is_struct(_piece) || !is_struct(_piece[$ "edges"])) return [];
    var _out = [], _order = ["top", "right", "bottom", "left"];
    for (var _i = 0; _i < 4; _i++) {
        var _pts = jig_flatten_edge(_piece.edges[$ _order[_i]], _steps);
        for (var _k = 0; _k < array_length(_pts) - 1; _k++) array_push(_out, _pts[_k]);
    }
    return _out;
}

/// @function jig__r2dp(v)
/// @description Internal. JavaScript's Math.round(v * 100) / 100 (half up), with -0 made 0.
function jig__r2dp(_v) { return (floor(_v * 100 + 0.5) + 0) / 100; }

/// @function jig_cut(options)
/// @description Cut a w x h picture into cols x rows interlocking pieces. Pure: the same options always cut the same
/// puzzle. Options: { w, h (at least 16), cols, rows (2..16), seed (a number or a word; default 1) }.
/// Each piece: { index, col, row, edges { top, right, bottom, left }, homeX, homeY, bw, bh, outline } - homeX/homeY/bw/bh
/// are the box of its outline in picture coordinates; outline is its closed polygon (points rounded to 0.01 px).
/// @param {Struct} options
/// @returns {Struct} { w, h, cols, rows, seed, pieces }
function jig_cut(_o) {
    // ⛔ GML's comparison epsilon (1e-5 by default) would read a draw within 1e-5 of 0.5 as EQUAL to it and flip that knob,
    // and blur the outline's box: the cut runs with the epsilon off (generator draws are multiples of 2^-32, far above
    // the 1e-11 floor math_set_epsilon(0) leaves) and hands the caller's epsilon back.
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _K = jig__cut(_o);
    math_set_epsilon(_eps);
    return _K;
}

/// @function jig__cut(options)
/// @description Internal. jig_cut's body (run with the comparison epsilon off).
function jig__cut(_o) {
    if (!is_struct(_o)) _o = {};
    var _w = max(16, jig__num(_o[$ "w"], 0)), _h = max(16, jig__num(_o[$ "h"], 0));
    var _cols = jig__clamp_side(_o[$ "cols"]), _rows = jig__clamp_side(_o[$ "rows"]);
    var _seed = jig_seed_of(is_undefined(_o[$ "seed"]) ? 1 : _o[$ "seed"]);
    var _R = jig__rng(_seed), _cw = _w / _cols, _ch = _h / _rows, _r, _c;
    var _corner = array_create(_rows + 1);
    for (_r = 0; _r <= _rows; _r++) {
        _corner[_r] = array_create(_cols + 1);
        for (_c = 0; _c <= _cols; _c++) {
            var _inner = _r > 0 && _r < _rows && _c > 0 && _c < _cols;
            var _jx = _inner ? (jig__rng_next(_R) * 2 - 1) * 0.05 * _cw : 0;
            var _jy = _inner ? (jig__rng_next(_R) * 2 - 1) * 0.05 * _ch : 0;
            _corner[_r][_c] = [_c * _cw + _jx, _r * _ch + _jy];
        }
    }
    // horizontal lines (r = 0..rows), segment c: corner[r][c] -> corner[r][c+1], normal +y. The side is drawn BEFORE
    // the curve's own six numbers (JavaScript evaluates the call's arguments first).
    var _H = array_create(_rows + 1), _V = array_create(_cols + 1);
    for (_r = 0; _r <= _rows; _r++) {
        _H[_r] = array_create(_cols);
        for (_c = 0; _c < _cols; _c++) {
            var _sg = (_r == 0 || _r == _rows) ? 0 : ((jig__rng_next(_R) < 0.5) ? 1 : -1);
            _H[_r][_c] = jig__knob_edge(_corner[_r][_c], _corner[_r][_c + 1], [0, 1], _sg, _R);
        }
    }
    // vertical lines (c = 0..cols), segment r: corner[r][c] -> corner[r+1][c], normal +x
    for (_c = 0; _c <= _cols; _c++) {
        _V[_c] = array_create(_rows);
        for (_r = 0; _r < _rows; _r++) {
            var _sv = (_c == 0 || _c == _cols) ? 0 : ((jig__rng_next(_R) < 0.5) ? 1 : -1);
            _V[_c][_r] = jig__knob_edge(_corner[_r][_c], _corner[_r + 1][_c], [1, 0], _sv, _R);
        }
    }
    var _pieces = array_create(_rows * _cols);
    for (_r = 0; _r < _rows; _r++) {
        for (_c = 0; _c < _cols; _c++) {
            // outward sign per side: top faces -y (so -base), right +x (base), bottom +y (base), left -x (-base)
            var _top = { base: _H[_r][_c], reversed: false, sign: -_H[_r][_c].sign, knob: _H[_r][_c].knob };
            var _right = { base: _V[_c + 1][_r], reversed: false, sign: _V[_c + 1][_r].sign, knob: _V[_c + 1][_r].knob };
            var _bottom = { base: _H[_r + 1][_c], reversed: true, sign: _H[_r + 1][_c].sign, knob: _H[_r + 1][_c].knob };
            var _left = { base: _V[_c][_r], reversed: true, sign: -_V[_c][_r].sign, knob: _V[_c][_r].knob };
            if (_top.sign == 0) _top.sign = 0;
            if (_left.sign == 0) _left.sign = 0;
            var _piece = { index: _r * _cols + _c, col: _c, row: _r, edges: { top: _top, right: _right, bottom: _bottom, left: _left } };
            var _poly = jig_flatten_outline(_piece, 6), _x0 = infinity, _y0 = infinity, _x1 = -infinity, _y1 = -infinity;
            for (var _i = 0; _i < array_length(_poly); _i++) {
                if (_poly[_i][0] < _x0) _x0 = _poly[_i][0];
                if (_poly[_i][1] < _y0) _y0 = _poly[_i][1];
                if (_poly[_i][0] > _x1) _x1 = _poly[_i][0];
                if (_poly[_i][1] > _y1) _y1 = _poly[_i][1];
            }
            _piece.homeX = _x0; _piece.homeY = _y0; _piece.bw = _x1 - _x0; _piece.bh = _y1 - _y0;
            var _ol = array_create(array_length(_poly));
            for (var _q = 0; _q < array_length(_poly); _q++) _ol[_q] = [jig__r2dp(_poly[_q][0]), jig__r2dp(_poly[_q][1])];
            _piece.outline = _ol;
            _pieces[_piece.index] = _piece;
        }
    }
    return { w: _w, h: _h, cols: _cols, rows: _rows, seed: _seed, pieces: _pieces };
}

/// @function jig_piece_contains(piece, x, y)
/// @description Is the picture-space point (x, y) inside the piece's own outline (even-odd)? Pure.
/// @returns {Bool}
function jig_piece_contains(_p, _x, _y) {
    if (!is_struct(_p) || !is_array(_p[$ "outline"]) || !is_numeric(_x) || !is_numeric(_y)) return false;
    var _o = _p.outline, _n = array_length(_o), _in = false;
    for (var _a = 0; _a < _n; _a++) {
        var _b = (_a == 0) ? _n - 1 : _a - 1;
        if (((_o[_a][1] > _y) != (_o[_b][1] > _y)) && (_x < (_o[_b][0] - _o[_a][0]) * (_y - _o[_a][1]) / (_o[_b][1] - _o[_a][1]) + _o[_a][0])) _in = !_in;
    }
    return _in;
}
