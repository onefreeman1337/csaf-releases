{
  "$GMScript": "v1",
  "%Name": "jig_cut",
  "name": "jig_cut",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}