{
  "$GMScript": "v1",
  "%Name": "jig_jigsaw",
  "name": "jig_jigsaw",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}