/// jig_jigsaw.gml - the jigsaw table: any picture cut into a generated jigsaw that the player assembles on a drawn table.
///
/// Jigsaw - Jigsaw Puzzles From Any Picture, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// The RPG Maker MZ edition's Scene_Jigsaw as five calls:
///   Create:   puzzle = jig_open({ sprite: spr_castle, pieces: 24 });
///   Step:     jig_step(puzzle);  if (jig_closed(puzzle)) { var r = puzzle.result; jig_free(puzzle); puzzle = undefined; }
///   Draw GUI: jig_draw(puzzle, 0, 0, 1);
///   Clean Up: jig_free(puzzle);
/// The player drags pieces with the mouse (or a finger), or moves the hand with the arrow keys (Shift = faster) and presses
/// Enter / Space / Z to pick up and put down. A piece dropped close to its home snaps in. Hold Q or Page Up, or press the
/// plaque, for the box lid. Escape / Backspace / X / right click sets the puzzle aside.
/// Every picture is drawn once at 2x through the kit and kept as a sprite; a frame costs a handful of sprites.
///
/// Public functions (each documented below): jig_open, jig_step, jig_draw, jig_closed, jig_free, jig_ui_scale.

#macro JIG_SS 2
#macro JIG_HUD_H 40

// ---------------------------------------------------------------------------------------------------------------
// Baking pictures: drawn through the kit at 2x, filtered down, kept as sprites (premultiplied)
// ---------------------------------------------------------------------------------------------------------------

/// internal: a w x h sprite (origin ox, oy) of what painter(ctx, args) draws, supersampled 2x and filtered down; the sprite
/// is PREMULTIPLIED. Every internal pass runs under identity and the caller's world matrix is handed back.
function jig__bake(_w, _h, _ox, _oy, _painter, _args) {
    var _W = max(1, ceil(_w)), _H = max(1, ceil(_h));
    var _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_build_identity());
    var _s2 = surface_create(_W * JIG_SS, _H * JIG_SS), _s1 = surface_create(_W, _H);
    surface_set_target(_s2); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha); gpu_set_ztestenable(false); gpu_set_zwriteenable(false);
    var _c = jig_cx_create(JIG_SS);
    _painter(_c, _args);
    gpu_pop_state(); surface_reset_target();
    surface_set_target(_s1); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_zero); gpu_set_texfilter(true);
    draw_surface_ext(_s2, 0, 0, 1 / JIG_SS, 1 / JIG_SS, 0, c_white, 1);
    gpu_pop_state(); surface_reset_target();
    var _spr = sprite_create_from_surface(_s1, 0, 0, _W, _H, false, false, _ox, _oy);
    surface_free(_s2); surface_free(_s1);
    matrix_set(matrix_world, _mw);
    return _spr;
}
function jig__draw_spr(_spr, _x, _y, _a, _sc = 1) { if (is_numeric(_spr) && sprite_exists(_spr) && _a > 0) draw_sprite_ext(_spr, 0, _x, _y, _sc, _sc, 0, merge_colour(c_black, c_white, _a), _a); }
function jig__swap(_T, _field, _spr) { var _o = _T[$ _field]; if (is_numeric(_o) && sprite_exists(_o)) array_push(_T.trash, _o); _T[$ _field] = _spr; }
function jig__round(_v) { return floor(_v + 0.5); }

/// @function jig__text(ctx, text, x, y, w, lineh, px, face, align, rgb, alpha)
/// @description Internal. One line of type in a box, as an MZ Bitmap.drawText sets it: the baseline at
/// y + lineh / 2 + px * 0.35, aligned "left", "center" or "right" in [x, x + w], squeezed to fit when wider than w.
#macro JIG_DOT_ADV 0.32
function jig__text_w(_t, _px, _face) {
    var _a = jig_text_advance(_face), _sum = 0;
    for (var _i = 1; _i <= string_length(_t); _i++) { var _o = ord(string_char_at(_t, _i)); if (_o >= 32 && _o <= 126) _sum += _a[_o - 32]; else if (_o == 183) _sum += JIG_DOT_ADV; }
    return _sum * _px;
}
function jig__text(_c, _s, _x, _y, _w, _lh, _px, _face, _align, _rgb, _a) {
    var _t = string(_s), _tw = jig__text_w(_t, _px, _face), _k = (_tw > _w && _tw > 0) ? _w / _tw : 1;
    var _x0 = _x;
    if (_align == "center") _x0 = _x + (_w - _tw * _k) / 2; else if (_align == "right") _x0 = _x + _w - _tw * _k;
    var _base = jig__round(_y + _lh / 2 + _px * 0.35);
    jig_cx_save(_c);
    _c.fill = jig_cx_solid(_rgb, _a);
    jig_cx_translate(_c, _x0, _base); jig_cx_scale(_c, _k, 1);
    var _adv = jig_text_advance(_face), _pen = 0;
    for (var _i = 1; _i <= string_length(_t); _i++) {
        var _ch = string_char_at(_t, _i), _o = ord(_ch);
        if (_o == 183) {
            // the middle dot is not in the atlases (32..126): struck as a disc at the x-height's middle
            jig_cx_begin(_c); jig_cx_arc(_c, _pen + JIG_DOT_ADV * _px / 2, -_px * 0.27, max(0.9, _px * 0.065), 0, 2 * pi); jig_cx_fill(_c);
            _pen += JIG_DOT_ADV * _px;
            continue;
        }
        jig_cx_glyph(_c, _ch, _pen, 0, _px, _face);
        if (_o >= 32 && _o <= 126) _pen += _adv[_o - 32] * _px;
    }
    jig_cx_restore(_c);
}
function jig__rrect(_c, _x, _y, _w, _h, _r) {
    jig_cx_begin(_c); jig_cx_move(_c, _x + _r, _y); jig_cx_line(_c, _x + _w - _r, _y); jig_cx_quad(_c, _x + _w, _y, _x + _w, _y + _r); jig_cx_line(_c, _x + _w, _y + _h - _r);
    jig_cx_quad(_c, _x + _w, _y + _h, _x + _w - _r, _y + _h); jig_cx_line(_c, _x + _r, _y + _h); jig_cx_quad(_c, _x, _y + _h, _x, _y + _h - _r);
    jig_cx_line(_c, _x, _y + _r); jig_cx_quad(_c, _x, _y, _x + _r, _y); jig_cx_close(_c);
}
function jig__clock(_secs) { var _mm = floor(_secs / 60), _ss = _secs mod 60; return string(_mm) + ":" + ((_ss < 10) ? "0" : "") + string(_ss); }

// painters (ctx, args)
function jig__pnt_table(_c, _a) { jig_draw_table(_c, _a.w, _a.h, { seed: 5 }); }
function jig__pnt_frame(_c, _a) {
    var _T = _a.T, _fx = _T.fx, _fy = _T.fy, _fw = _T.fw, _fh = _T.fh, _S = _T.S;
    _c.fill = jig_cx_solid([0, 0, 0], 0.30); jig_cx_fill_rect(_c, _fx - 6, _fy - 6, _fw + 12, _fh + 12);
    _c.stroke = jig_cx_solid([255, 235, 200], 0.25); _c.lw = 1; jig_cx_stroke_rect(_c, _fx - 6.5, _fy - 6.5, _fw + 13, _fh + 13);
    // a ghost of the picture in the frame, so the player has the box art to work from
    _c.alpha = 0.16; jig_cx_image(_c, _T.pic, _T.picSub, _fx, _fy, _fw, _fh); _c.alpha = 1;
    // the hint, engraved in the gap under the frame
    var _hh = jig__round(16 * _S);
    jig__text(_c, "Hold Q or press the plaque for the box lid  " + chr(183) + "  Esc sets it aside", _fx - 4, _fy + _fh + 5, _fw + 12, _hh, jig__round(12 * _S), JIG_FACE_BODY, "left", [255, 226, 170], 0.55);
}
function jig__pnt_piece(_c, _a) { jig_draw_piece(_c, _a.T.pic, _a.T.cut, _a.p, _a.pad, _a.pad, { lifted: _a.lifted, subimg: _a.T.picSub }); }
function jig__pnt_hand(_c, _a) {
    jig_cx_begin(_c); jig_cx_move(_c, 4, 2); jig_cx_line(_c, 4, 22); jig_cx_line(_c, 10, 16); jig_cx_line(_c, 16, 26); jig_cx_line(_c, 20, 24); jig_cx_line(_c, 14, 14); jig_cx_line(_c, 22, 14); jig_cx_close(_c);
    _c.fill = jig_cx_solid([255, 240, 205], 0.9); jig_cx_fill(_c);
    _c.stroke = jig_cx_solid([40, 25, 10], 0.9); _c.lw = 2; jig_cx_stroke(_c);
}
function jig__pnt_lid(_c, _a) {
    var _T = _a.T, _fw = _T.fw, _fh = _T.fh;
    _c.fill = jig_cx_solid([16, 9, 4], 0.9); jig_cx_fill_rect(_c, 0, 0, _fw + 8, _fh + 8);
    jig_cx_image(_c, _T.pic, _T.picSub, 4, 4, _fw, _fh);
    _c.stroke = jig_cx_solid([244, 206, 128], 0.8); _c.lw = 1.5; jig_cx_stroke_rect(_c, 2.75, 2.75, _fw + 2.5, _fh + 2.5);
}
function jig__pnt_hud(_c, _a) {
    var _T = _a.T, _w = _a.w, _h = _a.h, _n = array_length(_T.pieces), _S = _T.S, _secs = _a.secs;
    _c.fill = jig_cx_solid([24, 14, 8], 0.62); jig__rrect(_c, 0.5, 0.5, _w - 1, _h - 1, 7); jig_cx_fill(_c);
    _c.stroke = jig_cx_solid([255, 226, 170], 0.38); _c.lw = 1; jig__rrect(_c, 3.5, 3.5, _w - 7, _h - 7, 5); jig_cx_stroke(_c);
    // the progress rule along the plaque's foot
    var _fill = (_n > 0) ? _T.placedN / _n : 0, _ry = _h - jig__round(9 * _S), _rh = max(2, jig__round(2 * _S));
    _c.fill = jig_cx_solid([255, 226, 170], 0.16); jig_cx_fill_rect(_c, 10, _ry, _w - 20, _rh);
    _c.fill = jig_cx_solid([244, 196, 112], 0.95); jig_cx_fill_rect(_c, 10, _ry, jig__round((_w - 20) * _fill), _rh);
    // deviation: the counts sit 2 px higher than the MZ (y 13, not 15), so the gilt rule runs under them, not through them
    var _third = floor((_w - 24) / 3), _y1 = jig__round(1 * _S), _y2 = jig__round(13 * _S), _l1 = jig__round(18 * _S), _l2 = jig__round(20 * _S);
    var _p1 = jig__round(13 * _S), _p2 = jig__round(17 * _S);
    jig__text(_c, "PLACED", 12, _y1, _third, _l1, _p1, JIG_FACE_BODY, "left", [255, 226, 170], 0.62);
    jig__text(_c, "TIME", 12 + _third, _y1, _third, _l1, _p1, JIG_FACE_BODY, "center", [255, 226, 170], 0.62);
    jig__text(_c, "MOVES", 12 + _third * 2, _y1, _third, _l1, _p1, JIG_FACE_BODY, "right", [255, 226, 170], 0.62);
    jig__text(_c, string(_T.placedN) + " / " + string(_n), 12, _y2, _third, _l2, _p2, JIG_FACE_DISPLAY, "left", [246, 230, 196], 1);
    jig__text(_c, jig__clock(_secs), 12 + _third, _y2, _third, _l2, _p2, JIG_FACE_DISPLAY, "center", [246, 230, 196], 1);
    jig__text(_c, string(_T.moves), 12 + _third * 2, _y2, _third, _l2, _p2, JIG_FACE_DISPLAY, "right", [246, 230, 196], 1);
}
function jig__pnt_whole(_c, _a) {
    var _T = _a.T, _tw = _a.tw, _th = _a.th;
    jig_cx_image(_c, _T.pic, _T.picSub, 4, 4, _tw, _th);
    _c.stroke = jig_cx_solid([244, 206, 128], 0.95); _c.lw = 2; jig_cx_stroke_rect(_c, 3, 3, _tw + 2, _th + 2);
    _c.stroke = jig_cx_solid([40, 22, 8], 0.7); _c.lw = 1; jig_cx_stroke_rect(_c, 0.5, 0.5, _tw + 7, _th + 7);
}
function jig__pnt_plaque(_c, _a) {
    var _T = _a.T, _w = _a.w, _h = _a.h, _S = _T.S, _n = array_length(_T.pieces);
    _c.fill = jig_cx_solid([22, 12, 6], 0.86); jig__rrect(_c, 0.5, 0.5, _w - 1, _h - 1, 9 * _S); jig_cx_fill(_c);
    _c.stroke = jig_cx_solid([244, 206, 128], 0.75); _c.lw = max(1, _S * 0.9); jig__rrect(_c, 4.5 * _S, 4.5 * _S, _w - 9 * _S, _h - 9 * _S, 6 * _S); jig_cx_stroke(_c);
    // a small flourish either side of the title: a rule ending in a diamond (clear of the widest title)
    var _gap = (_T.solved ? 92 : 128) * _S, _fy0 = 22 * _S;
    _c.fill = jig_cx_solid([244, 206, 128], 0.85); _c.stroke = jig_cx_solid([244, 206, 128], 0.85);
    for (var _s = -1; _s <= 1; _s += 2) {
        var _cx = _w / 2 + _s * _gap;
        jig_cx_begin(_c); jig_cx_move(_c, _cx, _fy0); jig_cx_line(_c, _cx + _s * 34 * _S, _fy0); jig_cx_stroke(_c);
        jig_cx_begin(_c); jig_cx_move(_c, _cx + _s * 40 * _S, _fy0); jig_cx_line(_c, _cx + _s * 36 * _S, _fy0 - 3 * _S); jig_cx_line(_c, _cx + _s * 32 * _S, _fy0); jig_cx_line(_c, _cx + _s * 36 * _S, _fy0 + 3 * _S); jig_cx_close(_c); jig_cx_fill(_c);
    }
    var _t = jig__clock(_a.secs);
    jig__text(_c, _T.solved ? "S O L V E D" : "S E T   A S I D E", 0, jig__round(6 * _S), _w, jig__round(32 * _S), jig__round(24 * _S), JIG_FACE_DISPLAY, "center", [246, 226, 180], 1);
    var _line = _T.solved ? (string(_n) + " pieces  " + chr(183) + "  " + _t + "  " + chr(183) + "  " + string(_T.moves) + " moves") : (string(_T.placedN) + " of " + string(_n) + " placed  " + chr(183) + "  " + _t);
    jig__text(_c, _line, 0, jig__round(38 * _S), _w, jig__round(22 * _S), jig__round(16 * _S), JIG_FACE_BODY, "center", [234, 215, 176], 1);
    jig__text(_c, "OK to continue", 0, jig__round(62 * _S), _w, jig__round(18 * _S), jig__round(12 * _S), JIG_FACE_BODY, "center", [234, 215, 176], 0.6);
}

// ---------------------------------------------------------------------------------------------------------------
// Opening a puzzle
// ---------------------------------------------------------------------------------------------------------------

/// @function jig_ui_scale(w, h)
/// @description The type and plaque scale for a w x h table: 1 at 816 x 624, up to 3 (a 1080-wide portrait screen reads
/// 1.73). Pure.
/// @returns {Real}
function jig_ui_scale(_w, _h) { return max(1, min(3, min(jig__fin(_w, 624), jig__fin(_h, 624)) / 624)); }

/// @function jig__seed_text(seed)
/// @description Internal. A seed as text, for the derived streams (":order", ":scatter").
function jig__seed_text(_s) { if (is_string(_s)) return _s; if (is_numeric(_s) && !is_nan(_s) && !is_infinity(_s) && _s == floor(_s)) return string(int64(_s)); return string(_s); }

/// @function jig_open(request)
/// @description Cut a picture into a jigsaw and lay it out on a drawn table. Returns the puzzle (a struct) - or undefined,
/// with a message in the output log, when the picture is missing.
/// Request: { sprite (the picture: any sprite) | surface (copied as the puzzle opens), subimg: 0, pieces: 24 (about; 4 to
/// 256), seed: "" (blank = a new cut every time; a number or a word cuts the same puzzle every time), width / height: the
/// table's size (default the GUI's), snap: 16 (px), sound: undefined (function(name) called with "pick", "drop", "place",
/// "solve"), key: "" (yours, handed back in the result) }.
/// @param {Struct} request
/// @returns {Struct|Undefined}
function jig_open(_req) {
    if (!is_struct(_req)) { show_debug_message("Jigsaw: jig_open needs a request struct, e.g. { sprite: spr_castle, pieces: 24 }."); return undefined; }
    var _pic = -1, _sub = 0, _own = false;
    var _sp = _req[$ "sprite"], _sf = _req[$ "surface"];
    if (is_numeric(_sp) && sprite_exists(_sp)) { _pic = _sp; _sub = is_numeric(_req[$ "subimg"]) ? clamp(floor(_req.subimg), 0, max(0, sprite_get_number(_sp) - 1)) : 0; }
    else if (is_numeric(_sf) && surface_exists(_sf)) { _pic = sprite_create_from_surface(_sf, 0, 0, surface_get_width(_sf), surface_get_height(_sf), false, false, 0, 0); _own = true; }
    if (_pic < 0 || sprite_get_width(_pic) < 1) { show_debug_message("Jigsaw: no picture. Pass { sprite: <a sprite> } or { surface: <a surface> }."); return undefined; }
    var _W = jig__fin(_req[$ "width"], display_get_gui_width()), _H = jig__fin(_req[$ "height"], display_get_gui_height());
    _W = max(320, floor(_W)); _H = max(240, floor(_H));
    var _n = jig__fin(_req[$ "pieces"], 24);
    _n = max(4, min(256, _n));
    var _seed = _req[$ "seed"];
    if (is_undefined(_seed) || (is_string(_seed) && string_trim(_seed) == "") || !(is_string(_seed) || is_numeric(_seed))) {
        global.jig_opened = (variable_global_exists("jig_opened") ? global.jig_opened : 0) + 1;
        _seed = "j" + string(global.jig_opened) + "t" + string(get_timer());
    } else if (is_string(_seed)) _seed = string_trim(_seed);
    var _T = {
        pic: _pic, picSub: _sub, ownPic: _own, pw: sprite_get_width(_pic), ph: sprite_get_height(_pic),
        W: _W, H: _H, n: _n, seed: _seed, snap: max(4, jig__fin(_req[$ "snap"], 16)), sound: _req[$ "sound"], key: is_undefined(_req[$ "key"]) ? "" : _req.key,
        x: 0, y: 0, scale: 1, closed: false, result: undefined, trash: [], inject: undefined, frame: 0,
        built: false, held: -1, grabX: 0, grabY: 0, viaHand: false, moves: 0, frames: 0, done: false, solved: false, doneAge: 0,
        peeks: 0, peeking: false, peekTouch: false, placedN: 0, hudKey: -1, lidA: 0,
        hand: { x: _W / 2, y: _H / 2, visible: false }, pieces: [], layer: [],
        table: -1, frameSpr: -1, handSpr: -1, hudSpr: -1, lidSpr: -1, wholeSpr: -1, plaqueSpr: -1,
        S: jig_ui_scale(_W, _H), fx: 0, fy: 0, fw: 0, fh: 0, t: 0, cut: undefined, layout: undefined, fin: undefined,
        wholeA: 0, wholeX: 0, wholeY: 0, wholeS: 1, fadeA: 1, plaqueA: 0, plaqueX: 0, plaqueY: 0,
        bakeMs: 0
    };
    var _t0 = get_timer();
    jig__build(_T);
    _T.bakeMs = (get_timer() - _t0) / 1000;
    return _T;
}

/// internal: lay out the table, the frame and the pieces; cut once.
function jig__build(_T) {
    var _W = _T.W, _H = _T.H, _t0 = get_timer();
    _T.timing = {};
    _T.table = jig__bake(_W, _H, 0, 0, jig__pnt_table, { w: _W, h: _H });
    _T.timing.tableMs = (get_timer() - _t0) / 1000; _t0 = get_timer();
    // the frame: the largest one whose loose pieces each get a spot of their own
    var _L = jig__solve_layout(_T);
    _T.layout = _L; _T.fx = _L.fx; _T.fy = _L.fy; _T.fw = _L.fw; _T.fh = _L.fh; _T.t = _L.t; _T.cut = _L.cut;
    _T.timing.layoutMs = (get_timer() - _t0) / 1000; _t0 = get_timer();
    _T.frameSpr = jig__bake(_W, _H, 0, 0, jig__pnt_frame, { T: _T });
    _T.timing.frameMs = (get_timer() - _t0) / 1000; _t0 = get_timer();
    var _R = jig__rng(jig_seed_of(jig__seed_text(_T.seed) + ":scatter"));
    var _ps = _T.cut.pieces;
    for (var _i = 0; _i < array_length(_ps); _i++) {
        var _p = _ps[_i], _pad = jig_margin(_p);
        var _bw = ceil(_p.bw) + _pad * 2, _bh = ceil(_p.bh) + _pad * 2;
        var _spr = jig__bake(_bw, _bh, 0, 0, jig__pnt_piece, { T: _T, p: _p, pad: _pad, lifted: false });
        var _at = _L.pos[_i];
        var _sx = jig__round(_at[0] - _pad + (jig__rng_next(_R) * 2 - 1) * 3), _sy = jig__round(_at[1] - _pad + (jig__rng_next(_R) * 2 - 1) * 3);
        _sx = max(_L.t - _pad, min(_W - _L.t - _bw + _pad, _sx)); _sy = max(_L.t - _pad, min(_H - _L.t - _bh + _pad, _sy));
        array_push(_T.pieces, { p: _p, pad: _pad, w: _bw, h: _bh, x: _sx, y: _sy, homeX: _T.fx + _p.homeX - _pad, homeY: _T.fy + _p.homeY - _pad, placed: false, spr: _spr, lift: -1, sc: 1 });
        array_push(_T.layer, _i);
    }
    _T.timing.piecesMs = (get_timer() - _t0) / 1000; _t0 = get_timer();
    _T.handSpr = jig__bake(28, 28, 0, 0, jig__pnt_hand, {});
    _T.lidSpr = jig__bake(_T.fw + 8, _T.fh + 8, 0, 0, jig__pnt_lid, { T: _T });
    _T.hudX = _T.fx - 6; _T.hudY = _L.t + 8; _T.hudW = _T.fw + 12; _T.hudH = jig__round(JIG_HUD_H * _T.S);
    _T.built = true;
    jig__draw_hud(_T);
    _T.timing.restMs = (get_timer() - _t0) / 1000;
}

/// internal: the table's layout: the largest frame (top left, under the plaque) whose loose pieces each get a spot of their
/// own on the free table. Shrinks the frame 4% a step until the spots cover the pieces; past 40 steps it keeps the smallest
/// and the extra pieces share spots.
function jig__solve_layout(_T) {
    var _W = _T.W, _H = _T.H, _pw = _T.pw, _ph = _T.ph, _S = _T.S, _portrait = _H > _W * 1.15;
    var _Tn = jig_felt_inset(_W, _H), _top = _Tn + 8 + jig__round(JIG_HUD_H * _S) + 14, _fx = _Tn + 14;
    var _kMax = _portrait ? min((_W - _fx * 2) / _pw, (_H - _top - _Tn) * 0.5 / _ph) : min((_W - _fx - _Tn) * 0.66 / _pw, (_H - _top - _Tn - 8) / _ph);
    var _L = undefined, _st = jig__seed_text(_T.seed);
    for (var _t = 0; _t < 40; _t++) {
        var _k = _kMax * power(0.96, _t), _fw = max(16, jig__round(_pw * _k)), _fh = max(16, jig__round(_ph * _k));
        if (_portrait) _fx = jig__round((_W - _fw) / 2);
        var _g = jig_grid_for(_fw, _fh, _T.n);
        var _cut = jig_cut({ w: _fw, h: _fh, cols: _g.cols, rows: _g.rows, seed: _T.seed });
        // the same seeded order every try, so the solve is a function of the screen and the seed alone
        var _R = jig__rng(jig_seed_of(_st + ":order")), _np = array_length(_cut.pieces), _order = array_create(_np);
        for (var _i = 0; _i < _np; _i++) _order[_i] = _i;
        for (var _q = _np - 1; _q > 0; _q--) { var _j = floor(jig__rng_next(_R) * (_q + 1)), _tq = _order[_q]; _order[_q] = _order[_j]; _order[_j] = _tq; }
        var _below = _top + _fh + 10 + jig__round(16 * _S);
        var _regions = _portrait ? [[_Tn + 6, _below, _W - _Tn - 6, _H - _Tn - 6]] : [[_fx + _fw + 18, _Tn + 6, _W - _Tn - 6, _H - _Tn - 6], [_Tn + 6, _below, _fx + _fw + 6, _H - _Tn - 6]];
        var _pk = jig__pack_loose(_cut, _order, _regions, 12);
        _L = { fw: _fw, fh: _fh, fx: _fx, fy: _top, t: _Tn, cut: _cut, pos: _pk.pos, fits: _pk.fits, tries: _t + 1 };
        if (_pk.fits) break;
    }
    return _L;
}

/// internal: shelf-pack the loose pieces by their OWN outline boxes into the free regions, in the given order: left to
/// right, a new row when a piece will not fit, the next region when the rows run out; each row and each region's block is
/// centred. A piece that fits nowhere is stacked at the last region's centre and `fits` is false.
function jig__pack_loose(_cut, _order, _regions, _gap) {
    var _np = array_length(_cut.pieces), _pos = array_create(_np, undefined), _k = 0, _no = array_length(_order);
    for (var _r = 0; _r < array_length(_regions) && _k < _no; _r++) {
        var _g = _regions[_r], _x = _g[0], _y = _g[1], _rowH = 0, _rowStart = _k, _blockStart = _k;
        while (_k < _no) {
            var _p = _cut.pieces[_order[_k]];
            if (_x > _g[0] && _x + _p.bw > _g[2]) { jig__shift_row(_pos, _order, _rowStart, _k, (_g[2] - (_x - _gap)) / 2, 0); _x = _g[0]; _y += _rowH + _gap; _rowH = 0; _rowStart = _k; }
            if (_x + _p.bw > _g[2] || _y + _p.bh > _g[3]) break;
            _pos[_order[_k]] = [_x, _y]; _x += _p.bw + _gap; _rowH = max(_rowH, _p.bh); _k++;
        }
        if (_k > _rowStart) jig__shift_row(_pos, _order, _rowStart, _k, (_g[2] - (_x - _gap)) / 2, 0);
        if (_k > _blockStart) jig__shift_row(_pos, _order, _blockStart, _k, 0, (_g[3] - (_y + _rowH)) / 2);
    }
    var _fits = (_k == _no), _last = _regions[array_length(_regions) - 1];
    while (_k < _no) { var _q = _cut.pieces[_order[_k]]; _pos[_order[_k]] = [(_last[0] + _last[2] - _q.bw) / 2, (_last[1] + _last[3] - _q.bh) / 2]; _k++; }
    return { pos: _pos, fits: _fits };
}
function jig__shift_row(_pos, _order, _a, _b, _dx, _dy) { for (var _i = _a; _i < _b; _i++) { var _o = _pos[_order[_i]]; _pos[_order[_i]] = [_o[0] + _dx, _o[1] + _dy]; } }

/// internal: redraw the plaque when what it says has changed (once a second at most while the clock runs).
function jig__draw_hud(_T) {
    var _secs = floor(_T.frames / 60), _key = _secs * 1000000 + _T.placedN * 1000 + _T.moves;
    if (_key == _T.hudKey) return;
    _T.hudKey = _key;
    jig__swap(_T, "hudSpr", jig__bake(_T.hudW, _T.hudH, 0, 0, jig__pnt_hud, { T: _T, w: _T.hudW, h: _T.hudH, secs: _secs }));
}

// ---------------------------------------------------------------------------------------------------------------
// Play
// ---------------------------------------------------------------------------------------------------------------

/// internal: the topmost unplaced piece under (x, y) by its own outline, as a position in the layer; -1 when none.
function jig__piece_at(_T, _x, _y) {
    for (var _i = array_length(_T.layer) - 1; _i >= 0; _i--) {
        var _P = _T.pieces[_T.layer[_i]];
        if (_P.placed) continue;
        if (jig_piece_contains(_P.p, _x - _P.x - _P.pad + _P.p.homeX, _y - _P.y - _P.pad + _P.p.homeY)) return _i;
    }
    return -1;
}
function jig__sound(_T, _name) {
    var _f = _T.sound;
    if (is_method(_f)) _f(_name);
    else if (is_numeric(_f) && script_exists(_f)) script_execute(_f, _name);
}
function jig__lifted(_T, _P, _on) {
    if (_on) { if (_P.lift < 0 || !sprite_exists(_P.lift)) _P.lift = jig__bake(_P.w, _P.h, 0, 0, jig__pnt_piece, { T: _T, p: _P.p, pad: _P.pad, lifted: true }); }
    _P.sc = _on ? 1.04 : 1;
}
function jig__grab(_T, _x, _y) {
    var _i = jig__piece_at(_T, _x, _y);
    if (_i < 0) return;
    var _idx = _T.layer[_i];
    array_delete(_T.layer, _i, 1); array_push(_T.layer, _idx);   // to the top
    var _P = _T.pieces[_idx];
    _T.held = _idx; _T.grabX = _x - _P.x; _T.grabY = _y - _P.y;
    jig__lifted(_T, _P, true);
    jig__sound(_T, "pick");
}
function jig__drop(_T) {
    var _idx = _T.held; _T.held = -1;
    if (_idx < 0) return;
    var _P = _T.pieces[_idx];
    jig__lifted(_T, _P, false); _T.moves++;
    if (abs(_P.x - _P.homeX) <= _T.snap && abs(_P.y - _P.homeY) <= _T.snap) {
        _P.x = _P.homeX; _P.y = _P.homeY; _P.placed = true; _T.placedN++;
        for (var _i = 0; _i < array_length(_T.layer); _i++) if (_T.layer[_i] == _idx) { array_delete(_T.layer, _i, 1); break; }
        array_insert(_T.layer, 0, _idx);   // to the bottom: a placed piece lies flat under the loose ones
        jig__sound(_T, "place");
        if (_T.placedN == array_length(_T.pieces)) jig__solve(_T, true);
    } else jig__sound(_T, "drop");
}

/// internal: the puzzle ends - solved, or set aside - and the result is written.
function jig__solve(_T, _solved) {
    if (_T.done) return;
    _T.done = true; _T.solved = _solved; _T.doneAge = 0; _T.held = -1;
    var _secs = floor(_T.frames / 60);
    _T.result = { solved: _solved, seconds: _secs, moves: _T.moves, peeks: _T.peeks, pieces: array_length(_T.pieces), placed: _T.placedN, seed: jig__seed_text(_T.seed), key: _T.key };
    _T.lidA = 0;
    if (_solved) jig__sound(_T, "solve");
    jig__build_finale(_T, _secs);
}

/// internal: the ending: on a solve the whole picture rises over the joined pieces under a thin gilt line; either way a
/// plaque gives the result. Both fade in from jig_step; built once.
function jig__build_finale(_T, _secs) {
    var _fw = _T.fw, _fh = _T.fh, _W = _T.W, _H = _T.H, _Tn = _T.t, _S = _T.S, _h = jig__round(92 * _S);
    var _kz = max(1, min((_W - _Tn * 2 - 60) / _fw, (_H - _Tn * 2 - _h - 56) / _fh)), _tw = jig__round(_fw * _kz), _th = jig__round(_fh * _kz);
    _T.fin = { x0: _T.fx - 4, y0: _T.fy - 4, s0: _fw / _tw, x1: jig__round((_W - _tw) / 2) - 4, y1: jig__round((_H - _th - _h - 16) / 2) - 4 };
    if (_T.solved) {
        _T.wholeSpr = jig__bake(_tw + 8, _th + 8, 0, 0, jig__pnt_whole, { T: _T, tw: _tw, th: _th });
        _T.wholeX = _T.fin.x0; _T.wholeY = _T.fin.y0; _T.wholeS = _T.fin.s0; _T.wholeA = 0;
    }
    _T.hudKey = -1; jig__draw_hud(_T);
    var _w = min(_W - 40, max(jig__round(320 * _S), jig__round(_tw * 0.7)));
    _T.plaqueSpr = jig__bake(_w, _h, 0, 0, jig__pnt_plaque, { T: _T, w: _w, h: _h, secs: _secs });
    _T.plaqueX = _T.solved ? jig__round((_W - _w) / 2) : jig__round(_T.fx + _fw / 2 - _w / 2);
    _T.plaqueX = max(20, min(_W - _w - 20, _T.plaqueX));
    _T.plaqueY = _T.solved ? _T.fin.y1 + _th + 8 + 14 : jig__round(_T.fy + _fh / 2 - _h / 2);
    _T.plaqueA = 0;
}

/// internal: this frame's input, in table coordinates.
function jig__input(_T, _x, _y) {
    return { x: _x, y: _y, click: mouse_check_button_pressed(mb_left), down: mouse_check_button(mb_left), rclick: mouse_check_button_pressed(mb_right),
        ok: keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("Z")),
        cancel: keyboard_check_pressed(vk_escape) || keyboard_check_pressed(vk_backspace) || keyboard_check_pressed(ord("X")),
        peek: keyboard_check(ord("Q")) || keyboard_check(vk_pageup), shift: keyboard_check(vk_shift),
        left: keyboard_check(vk_left), right: keyboard_check(vk_right), up: keyboard_check(vk_up), down_key: keyboard_check(vk_down) };
}

/// @function jig_step(puzzle, [mouse_x], [mouse_y])
/// @description Run the table for one step: the hand, dragging, snapping, the box lid, the clock and the ending. Call it in
/// Step. The mouse is read in GUI coordinates (device_mouse_x_to_gui) relative to where jig_draw last drew the table;
/// pass your own coordinates when the table is drawn in a room or a view.
function jig_step(_T, _mx = undefined, _my = undefined) {
    if (!is_struct(_T) || _T.closed || !_T.built) return;
    _T.frame++;
    for (var _d = 0; _d < array_length(_T.trash); _d++) if (sprite_exists(_T.trash[_d])) sprite_delete(_T.trash[_d]);
    _T.trash = [];
    var _gx = is_numeric(_mx) ? _mx : device_mouse_x_to_gui(0), _gy = is_numeric(_my) ? _my : device_mouse_y_to_gui(0), _k = (_T.scale > 0) ? _T.scale : 1;
    var _in = jig__input(_T, (_gx - _T.x) / _k, (_gy - _T.y) / _k);
    var _ij = _T.inject;
    if (is_struct(_ij)) {
        var _f = ["x", "y", "click", "down", "rclick", "ok", "cancel", "peek", "shift", "left", "right", "up", "down_key"];
        for (var _i = 0; _i < array_length(_f); _i++) _in[$ _f[_i]] = is_undefined(_ij[$ _f[_i]]) ? ((_i < 2) ? -1000 : false) : _ij[$ _f[_i]];
        _T.inject = undefined;
    }
    if (_T.done) {
        _T.doneAge++;
        if (_T.wholeSpr >= 0 && sprite_exists(_T.wholeSpr)) {
            var _e = min(1, _T.doneAge / 40), _F = _T.fin; _e = _e * _e * (3 - 2 * _e);
            _T.wholeA = min(255, _T.doneAge * 12) / 255;
            _T.wholeS = _F.s0 + (1 - _F.s0) * _e;
            _T.wholeX = _F.x0 + (_F.x1 - _F.x0) * _e; _T.wholeY = _F.y0 + (_F.y1 - _F.y0) * _e;
            _T.fadeA = jig__round(255 * (1 - _e)) / 255;
        }
        _T.plaqueA = max(0, min(255, (_T.doneAge - ((_T.wholeSpr >= 0) ? 30 : 0)) * 12)) / 255;
        _T.hand.visible = false;
        // the ending finishes (picture at rest by step 40, plaque in by 52) before OK can leave it
        if (_T.doneAge > 52 && (_in.ok || _in.cancel || _in.click || _in.rclick)) _T.closed = true;
        return;
    }
    _T.frames++;
    // keyboard hand
    var _dx = (_in.right ? 1 : 0) - (_in.left ? 1 : 0), _dy = (_in.down_key ? 1 : 0) - (_in.up ? 1 : 0);
    if (_dx != 0 || _dy != 0) { var _sp = _in.shift ? 9 : 4; _T.hand.visible = true; _T.hand.x = max(0, min(_T.W - 4, _T.hand.x + _dx * _sp)); _T.hand.y = max(0, min(_T.H - 4, _T.hand.y + _dy * _sp)); }
    if (_in.ok) { _T.hand.visible = true; if (_T.held < 0) { jig__grab(_T, _T.hand.x, _T.hand.y); _T.viaHand = true; } else jig__drop(_T); }
    if (_T.done) return;
    if (_T.held >= 0 && _T.viaHand) { var _h = _T.pieces[_T.held]; _h.x = _T.hand.x - _T.grabX; _h.y = _T.hand.y - _T.grabY; }
    // the box lid (key or a press on the plaque); a peek is counted once per press
    var _hx = _in.x - _T.hudX, _hy = _in.y - _T.hudY;
    if (_in.click && _T.held < 0 && _hx >= 0 && _hy >= 0 && _hx < _T.hudW && _hy < _T.hudH) _T.peekTouch = true;
    if (_T.peekTouch && !_in.down) _T.peekTouch = false;
    var _peek = _in.peek || _T.peekTouch;
    if (_peek && !_T.peeking) _T.peeks++;
    _T.peeking = _peek;
    _T.lidA = max(0, min(235, _T.lidA * 255 + (_peek ? 40 : -40))) / 255;
    // mouse and touch
    if (_in.click && _T.held < 0 && !_T.peekTouch) { _T.hand.visible = false; _T.viaHand = false; jig__grab(_T, _in.x, _in.y); }
    if (_T.held >= 0 && !_T.viaHand) {
        var _t = _T.pieces[_T.held];
        if (_in.down) { _t.x = _in.x - _T.grabX; _t.y = _in.y - _T.grabY; } else jig__drop(_T);
    }
    if (_T.done) return;
    if (_in.cancel || _in.rclick) jig__solve(_T, false);
    jig__draw_hud(_T);
}

/// @function jig_closed(puzzle)
/// @description True once the player has left the table (OK after the ending). Then read puzzle.result:
/// { solved, seconds, moves, peeks, pieces, placed, seed, key }.
/// @returns {Bool}
function jig_closed(_T) { return is_struct(_T) && _T.closed; }

/// @function jig_free(puzzle)
/// @description Free every sprite the puzzle made (and its copy of a surface picture). Call it in Step or Clean Up (never
/// in a Draw event). Safe to call twice.
function jig_free(_T) {
    if (!is_struct(_T)) return;
    var _f = ["table", "frameSpr", "handSpr", "hudSpr", "lidSpr", "wholeSpr", "plaqueSpr"];
    for (var _i = 0; _i < array_length(_f); _i++) { var _s = _T[$ _f[_i]]; if (is_numeric(_s) && _s >= 0 && sprite_exists(_s)) sprite_delete(_s); _T[$ _f[_i]] = -1; }
    if (is_array(_T[$ "pieces"])) for (var _p = 0; _p < array_length(_T.pieces); _p++) {
        var _P = _T.pieces[_p];
        if (is_numeric(_P.spr) && _P.spr >= 0 && sprite_exists(_P.spr)) sprite_delete(_P.spr);
        if (is_numeric(_P.lift) && _P.lift >= 0 && sprite_exists(_P.lift)) sprite_delete(_P.lift);
        _P.spr = -1; _P.lift = -1;
    }
    for (var _d = 0; _d < array_length(_T.trash); _d++) if (sprite_exists(_T.trash[_d])) sprite_delete(_T.trash[_d]);
    _T.trash = [];
    if (_T.ownPic && is_numeric(_T.pic) && _T.pic >= 0 && sprite_exists(_T.pic)) sprite_delete(_T.pic);
    _T.pic = -1; _T.ownPic = false; _T.closed = true;
}

/// @function jig_draw(puzzle, [x], [y], [scale])
/// @description Draw the table with its top-left at (x, y) at scale (width x height at scale 1). Call in Draw or Draw GUI;
/// the input is read relative to the same place.
function jig_draw(_T, _x = undefined, _y = undefined, _scale = undefined) {
    if (!is_struct(_T) || _T.closed || !_T.built) return;
    if (is_numeric(_x)) _T.x = _x;
    if (is_numeric(_y)) _T.y = _y;
    if (is_numeric(_scale) && _scale > 0) _T.scale = _scale;
    var _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_multiply(matrix_build(_T.x, _T.y, 0, 0, 0, 0, _T.scale, _T.scale, 1), _mw));
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); gpu_set_texfilter(true);
    jig__draw_spr(_T.table, 0, 0, 1);
    var _fa = _T.done ? _T.fadeA : 1;
    jig__draw_spr(_T.frameSpr, 0, 0, _fa);
    for (var _i = 0; _i < array_length(_T.layer); _i++) {
        var _P = _T.pieces[_T.layer[_i]];
        var _spr = (_P.sc > 1 && _P.lift >= 0 && sprite_exists(_P.lift)) ? _P.lift : _P.spr;
        jig__draw_spr(_spr, _P.x, _P.y, _fa, _P.sc);
    }
    if (_T.hand.visible) jig__draw_spr(_T.handSpr, _T.hand.x, _T.hand.y, 1);
    jig__draw_spr(_T.hudSpr, _T.hudX, _T.hudY, _fa);
    if (_T.lidA > 0) jig__draw_spr(_T.lidSpr, _T.fx - 4, _T.fy - 4, _T.lidA);
    if (_T.done) {
        if (_T.wholeSpr >= 0) jig__draw_spr(_T.wholeSpr, _T.wholeX, _T.wholeY, _T.wholeA, _T.wholeS);
        jig__draw_spr(_T.plaqueSpr, _T.plaqueX, _T.plaqueY, _T.plaqueA);
    }
    gpu_pop_state();
    matrix_set(matrix_world, _mw);
}
