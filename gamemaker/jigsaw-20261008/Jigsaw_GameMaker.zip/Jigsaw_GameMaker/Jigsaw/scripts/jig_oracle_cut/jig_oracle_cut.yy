{
  "$GMScript": "v1",
  "%Name": "jig_oracle_cut",
  "name": "jig_oracle_cut",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}