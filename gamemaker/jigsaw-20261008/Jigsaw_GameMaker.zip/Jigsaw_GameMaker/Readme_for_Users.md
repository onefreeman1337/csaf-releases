# Jigsaw - Jigsaw Puzzles From Any Picture, for GameMaker

Turn any picture in your game into a jigsaw the player assembles on a drawn table: a sprite, a background, or a surface
(a capture of the room the player is standing in).

- **Every cut is generated.** A seed cuts the picture into 4 to 256 interlocking knob-and-socket pieces: the grid fits
  the picture's shape, the inner corners are nudged so no two pieces are the same rectangle, and every inner edge is one
  curve shared by the two pieces it separates (a tab always meets its own socket), with the knob's side, size, lean and
  neck drawn from the seed. A blank seed gives a new puzzle every time; a fixed seed (a number or a word) repeats one.
- **Pieces are drawn as card.** Each piece is your picture clipped to its own curves, with a rim light upper left, a
  dark lip lower right, a faint sheen and a card-stock shadow; a piece in the hand lifts and casts a deeper shadow.
- **The table.** A felt mat inside a wooden rim with its grain, a faint ghost of the picture in the frame to work from,
  the box lid (hold Q or Page Up, or press the plaque) showing the whole picture, and a plaque with the count, the clock
  and the moves along a gilt progress rule. A finished puzzle rises out of the frame under a SOLVED plaque; a puzzle set
  aside says how many pieces were placed.
- **Mouse and keyboard.** Drag a piece; or move the hand with the arrow keys (Shift = faster) and press Enter / Space / Z
  to pick up and put down. A piece dropped close to its home snaps in. On mobile exports a first finger reads as
  GameMaker's mouse (device 0); we have only built and tested Windows.

Ported from our RPG Maker MZ plugin Jigsaw and held to it: the in-engine suite runs the cut through both and checks every
piece agrees (see Verification).

## Install

1. In GameMaker, **Tools > Import Local Package**, choose `Jigsaw.yymps`, and import everything.
2. Run the project with `rm_jig_demo` first in the room order. The demo is THE PUZZLE ROOM: three pictures painted by the
   package (a harbour at dusk, a mountain lake, a castle at night) as box lids, and a piece-count chooser (12, 24, 48,
   96). Click a box (or walk the arrows and press Enter) to cut it; the room shows "Cutting the picture" for a frame while
   the pieces are drawn (see Performance).

Requires GameMaker 2024.14 or later. Built and tested on runtime 2024.14.4.268 (the VM, Windows). Pure GML, no shader, no
extension; nothing here depends on GMRT.

## Quickstart

```gml
// Create - cut a picture into about 24 pieces
my_puzzle = jig_open({ sprite: spr_castle, pieces: 24 });

// Step - run the table; when the player leaves it, read the result
jig_step(my_puzzle);
if (jig_closed(my_puzzle)) {
    my_result = my_puzzle.result;     // { solved, seconds, moves, peeks, pieces, placed, seed, key }
    jig_free(my_puzzle);
    my_puzzle = undefined;
}

// Draw GUI - the table fills the GUI by default; draw it anywhere, at any scale
jig_draw(my_puzzle, 0, 0, 1);
```

`jig_open` cuts the picture and draws every piece once (supersampled, filtered down) and keeps them as sprites, so open a
puzzle behind your own transition: draw a "cutting" frame, then open on the next Step, as `jig_demo_step` does. **Call
`jig_open` in Create or Step, never inside a Draw event or while a surface is the render target** (it draws into its own
surfaces). After that a frame costs a handful of sprites. The mouse is read in GUI coordinates, relative to where you
draw the table. What a solved puzzle is worth is your game's business: `result` says how it ended.

### The request

```gml
{ sprite: spr_castle,         // the picture: any sprite (or surface: a surface, copied as the puzzle opens)
  subimg: 0,                  // which frame of the sprite
  pieces: 48,                 // about how many pieces: 4 to 256 (the grid keeps the pieces near square)
  seed: "the north tower",    // "" or absent: a new cut every time; a number or a word: the same cut every time
  width: 1280, height: 720,   // the table's size (default: the GUI's)
  snap: 16,                   // how close (px) a piece must be dropped to its home to snap in
  sound: my_sound_hook,       // optional: function(name) called with "pick", "drop", "place", "solve"
  key: "chapter2|tower" }     // optional: yours, handed back in the result
```

## Reference

**The table** (`jig_open` once, then every frame `jig_step` in Step and `jig_draw` in Draw or Draw GUI)
- `jig_open(request)` - cut the picture and lay out the table; returns the puzzle struct (undefined, with a message in
  the output log, when there is no picture).
- `jig_step(puzzle, [mouse_x], [mouse_y])` - one step: the hand, dragging, snapping, the box lid, the clock and the
  ending. Pass your own mouse position (in the same coordinates you draw in) if you do not draw in the GUI layer.
- `jig_draw(puzzle, [x], [y], [scale])` - draw it with its top-left at (x, y).
- `jig_closed(puzzle)` - true once the player has left the table.
- `jig_free(puzzle)` - free every sprite it made, and its copy of a surface picture (in Step or Clean Up, never in a Draw
  event). Your own sprite is never touched.
- `jig_ui_scale(w, h)` - the type and plaque scale for a table size (1 at 816 x 624, up to 3).
- Fields you may set: `puzzle.inject` (scripted input for one step, in table coordinates: `{ x, y, click, down }`,
  `{ ok: true }`, `{ peek: true }`, `{ cancel: true }`, `{ left / right / up / down_key: true, shift }` - for a tutorial or
  a replay).
- `puzzle.result` - `{ solved, seconds, moves, peeks, pieces, placed, seed, key }`.

**The cut on its own** (pure GML, no drawing)
- `jig_cut({ w, h, cols, rows, seed })` - the pieces: each `{ index, col, row, edges, homeX, homeY, bw, bh, outline }`.
- `jig_grid_for(w, h, pieces)` - the `{ cols, rows }` that keeps the cells near square for about that many pieces.
- `jig_seed_of(seed)` - the cut's 32-bit seed from a number or a word.
- `jig_flatten_edge(edge, [steps])`, `jig_flatten_outline(piece, [steps])` - a piece edge or outline as points.
- `jig_piece_contains(piece, x, y)` - is a point (picture coordinates) inside the piece.

**Drawing directly** (into a `jig_cx_create(scale)` context, onto whatever SURFACE is the current target). If you will
draw that surface somewhere else afterwards, set `gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one,
bm_inv_src_alpha)` before drawing into it (the package's own pictures are drawn this way): under the default blend the
surface keeps only partial alpha where translucent strokes land, and the picture comes out washed when you draw it.
- `jig_draw_piece(ctx, sprite, cut, piece, x, y, [options])` (`{ lifted, bevel, subimg }`), `jig_trace_piece(ctx, piece)`,
  `jig_bevel_of(piece)`, `jig_margin(piece)` (how far its lifted shadow reaches).
- `jig_draw_table(ctx, w, h, [options])` (`{ seed, felt: [r, g, b], wood: [r, g, b] }`), `jig_felt_inset(w, h)`.
- `jig_cx_image(ctx, sprite, subimg, x, y, w, h)` - a sprite into the current clip.
- `jig_demo_picture(kind, w, h)` - one of the demo's painted pictures ("harbour", "lake", "castle") as a new sprite, 64
  to 2048 px a side (free it with `sprite_delete`).

## Performance - read this before opening a puzzle mid-frame

Measured on our test machine, a shared and busy one (runtime 2024.14.4.268, the VM, Windows). Yours will differ.

- **Opening a puzzle costs about 1.2 s at 24 pieces**, about 3 s at 48 or 96, and about 9.5 s at 256 (the cut and layout
  take about 0.1 s; nearly all the rest is drawing every piece at twice the size). Open behind a "cutting" frame, as the
  demo does.
- **Picking up a piece draws its lifted picture once** (then it is kept); every other frame is a handful of sprites.

## Fonts

The table is lettered in two faces rasterised into font resources: Cinzel Bold (counts and plaque titles) and Alegreya
(the rest), both SIL Open Font License 1.1. The licence texts and the notices are in `Jigsaw/fonts/`. The atlases carry
printable ASCII (32 to 126) and the middle dot (drawn as a disc); any other character is measured as nothing and not
drawn.

## Differences from the RPG Maker MZ edition

- The bevel strokes use a mitred join instead of a round one (four times faster to draw here; the curves turn a degree
  or two per joint, so the line is the same to the eye).
- The plaque's counts sit 2 px higher, so the gilt progress rule runs under them rather than through them.
- A seed given as a hex or exponent string ("0x1F", "1e3") is read as a word, not a number; plain numbers and words cut
  exactly as the MZ edition does.

## Verification

GameMaker code cannot be unit-tested outside the engine, so everything below ran in real executables built by GameMaker's
own compiler (Igor, runtime 2024.14.4.268):

- The cut, held to the RPG Maker MZ edition run in Node: the seed hash on 14 numbers and words, 60 generator draws, the
  grid choice for 56 picture sizes and counts, 14 cuts (623 pieces: every box and edge side, and 3,240 outline points
  listed in full), and 100 points along the four edges of a piece - every value exact.
- The cut tiles the picture: 1,200 random points over cuts of 24, 100 and 256 pieces, each inside exactly one piece.
- The drawing: a white picture clipped to 12 pieces lights the pieces' own outline area, not their boxes; every drawn
  piece and the table carry ink.
- The table: a 24-piece puzzle played by scripted mouse input (a wrong drop first, then every piece dragged home and
  snapped), the ending and the result; the keyboard hand carrying a piece home; the box lid by key and by the plaque;
  setting a puzzle aside; a surface picture copied and freed; opening with no picture refused.
- The demo room: built, drawn, a box clicked, the cutting frame shown and its puzzle opened.

Two things this does not prove, stated plainly: the timings come from one shared machine and will differ on yours, and
the suite ran on Windows with the VM runtime only (other targets and YYC were not built).

## Licence

See `LICENSE.txt`. Use it in unlimited games, commercial or free; modify it freely; do not resell the package itself.

Made by Core Systems Asset Factory. Written with AI assistance, disclosed on every store page that carries it.
