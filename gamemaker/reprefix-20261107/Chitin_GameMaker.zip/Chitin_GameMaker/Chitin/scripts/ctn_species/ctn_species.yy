{
  "$GMScript": "v1",
  "%Name": "ctn_species",
  "name": "ctn_species",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}