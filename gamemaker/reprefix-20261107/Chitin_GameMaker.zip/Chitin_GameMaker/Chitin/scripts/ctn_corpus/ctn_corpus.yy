{
  "$GMScript": "v1",
  "%Name": "ctn_corpus",
  "name": "ctn_corpus",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}