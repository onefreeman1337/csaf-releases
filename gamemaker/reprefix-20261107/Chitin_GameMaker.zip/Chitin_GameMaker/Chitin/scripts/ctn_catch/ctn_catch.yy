{
  "$GMScript": "v1",
  "%Name": "ctn_catch",
  "name": "ctn_catch",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}