/// CHITIN - ctn_field. WHERE AND WHEN. The layer that makes the corpus a place rather than a list.
///
/// ============================================================================================
/// WHY THIS FILE EXISTS, AND IT IS THE WHOLE ARGUMENT FOR THE PRODUCT
///
/// A species corpus on its own is an art pack with extra steps. Forty eight beautiful insects that
/// are all available all the time, everywhere, is a sprite sheet with a fancier build script - the
/// player sees everything in the first ten minutes and there is nothing left to want.
///
/// What turns it into a game is SCARCITY WITH A REASON. The hawk moth is not rare because a die
/// said so; it is rare because it flies at dusk, in high summer, along a hedgerow, and only when it
/// is not blowing a gale. A player who learns that has learned something TRUE, and the knowledge is
/// the reward. That is the difference between a collection and a shelf.
///
/// ⛔ EVERY FUNCTION HERE IS PURE. No instance variables, no draw calls, no room state, no
/// randomness at query time. GML cannot be unit-tested outside the engine (wing CLAUDE.md), so the
/// only defence this package has is that the half of it which does not need a GPU never touches one
/// - ctn_selftest then runs the whole layer in-engine and can assert every branch of it.
///
/// ⚠️ THE DATA IS AUTHORED, NOT HASHED, AND THAT IS THE EXPENSIVE CHOICE ON PURPOSE. It would have
/// been four lines to derive a habitat and a flight period from ctn_hash32(species index). It would
/// also have put the great diving beetle in a pine wood and the swallowtail on a heath, and a buyer
/// who knows one insect would find the first wrong answer inside a minute. Forty eight rows of real
/// British natural history is the content, and it is the part a competitor cannot generate.
/// ============================================================================================

/// -- HABITAT. Index-parallel with ctn_habitat_names(), as BITS so a species can occupy several.
#macro CTN_HAB_MEADOW    1
#macro CTN_HAB_HEDGEROW  2
#macro CTN_HAB_OAKWOOD   4
#macro CTN_HAB_PINEWOOD  8
#macro CTN_HAB_HEATH     16
#macro CTN_HAB_MARSH     32
#macro CTN_HAB_RIVERBANK 64
#macro CTN_HAB_ORCHARD   128
#macro CTN_HAB_N         8

/// -- SEASON. Six of them, and a MASK rather than a first/last window.
///
/// ⛔ A WINDOW WAS THE FIRST DESIGN AND IT IS WRONG FOR THIS SUBJECT. The peacock and the
/// brimstone are HIBERNATORS: they fly in early spring, disappear for the summer as the new
/// generation is in its chrysalis, and fly again in late summer and autumn. A contiguous
/// `first..last` window can only express that as "out all year", which erases the single most
/// interesting fact about them - that seeing one in March means something different from seeing one
/// in September. A mask costs one integer and says it correctly.
#macro CTN_SEA_ESPRING 1
#macro CTN_SEA_LSPRING 2
#macro CTN_SEA_ESUMMER 4
#macro CTN_SEA_HSUMMER 8
#macro CTN_SEA_LSUMMER 16
#macro CTN_SEA_AUTUMN  32
#macro CTN_SEASON_N    6

/// -- TIME OF DAY. Index-parallel with ctn_daypart_names().
#macro CTN_DAY_DAWN      1
#macro CTN_DAY_MORNING   2
#macro CTN_DAY_MIDDAY    4
#macro CTN_DAY_AFTERNOON 8
#macro CTN_DAY_DUSK      16
#macro CTN_DAY_NIGHT     32
#macro CTN_DAYPART_N     6

/// -- WEATHER. Index-parallel with ctn_weather_names().
#macro CTN_WX_CLEAR    1
#macro CTN_WX_OVERCAST 2
#macro CTN_WX_RAIN     4
#macro CTN_WX_WIND     8
#macro CTN_WEATHER_N   4

/// Convenience compounds, so a row reads as natural history rather than as arithmetic.
#macro CTN_DAY_DAYLIGHT (CTN_DAY_MORNING | CTN_DAY_MIDDAY | CTN_DAY_AFTERNOON)
#macro CTN_DAY_SUNNY    (CTN_DAY_MIDDAY | CTN_DAY_AFTERNOON)
#macro CTN_DAY_DARK     (CTN_DAY_DUSK | CTN_DAY_NIGHT)
#macro CTN_SEA_ALL      (CTN_SEA_ESPRING | CTN_SEA_LSPRING | CTN_SEA_ESUMMER | CTN_SEA_HSUMMER \
                        | CTN_SEA_LSUMMER | CTN_SEA_AUTUMN)
#macro CTN_SEA_SUMMER   (CTN_SEA_ESUMMER | CTN_SEA_HSUMMER | CTN_SEA_LSUMMER)
#macro CTN_WX_DRY       (CTN_WX_CLEAR | CTN_WX_OVERCAST)
#macro CTN_WX_ANY       (CTN_WX_CLEAR | CTN_WX_OVERCAST | CTN_WX_RAIN | CTN_WX_WIND)

/// -- ESCAPE PROGRAMS. Six of them, index-parallel with ctn_evade_names(), and each is a real
/// switch case in ctn_catch_step. They are the reason a tiger beetle is harder than a ladybird
/// without the buyer tuning a single number: the DIFFICULTY IS THE ANIMAL.
#macro CTN_EVADE_RUN   0   // straight-line sprint along the ground - a ground beetle, a tiger beetle
#macro CTN_EVADE_FLIT  1   // erratic, direction changing every few frames - a butterfly
#macro CTN_EVADE_DROP  2   // lets go and falls - a weevil, a chafer, a leaf beetle
#macro CTN_EVADE_DIVE  3   // straight down into water and out of reach - a diving beetle
#macro CTN_EVADE_JUMP  4   // one enormous jump, then stillness - a flea beetle
#macro CTN_EVADE_BOLT  5   // fast, low, and gone in a straight line - a hawk moth
#macro CTN_EVADE_N     6

/// ============================================================================================
/// THE ROW
/// ============================================================================================

/// One species' field record.
///
/// Constructed through a function rather than written as 48 struct literals, for the reason
/// ctn_species gives: a field added later cannot then be forgotten in row 37.
///
/// hab    habitat bitmask
/// sea    season bitmask
/// peak   the season it is COMMONEST in, as an index. Must be a member of sea; asserted.
/// day    daypart bitmask
/// wx     the weathers it will fly in at all
/// wxp    the weather it prefers, as a bit. Must be a member of wx; asserted.
/// abund  0..1, how many there are when conditions ARE right
/// alarm  how close you may get, in body lengths, before it reacts. The whole difficulty curve.
/// speed  escape speed in unit-box widths per second
/// evade  which escape program it runs
function ctn_fd(_hab, _sea, _peak, _day, _wx, _wxp, _abund, _alarm, _speed, _evade) {
    return { hab: _hab, sea: _sea, peak: _peak, day: _day, wx: _wx, wxp: _wxp,
             abund: _abund, alarm: _alarm, speed: _speed, evade: _evade };
}

/// THE FIELD DATA. Forty eight rows of where and when.
///
/// ⚠️ THE ALARM COLUMN IS THE DIFFICULTY CURVE AND IT IS AUTHORED FROM LIFE. The green tiger beetle
/// is the hardest animal in this corpus to get near and that is not a game-design decision - it is
/// the single most famous thing about the insect. The bloody nosed beetle walks slowly across a
/// path and lets you pick it up. A buyer who ships this untouched gets a difficulty spread they did
/// not have to design, and one that teaches the player something real.
function ctn_field_spec(_i) {
    switch (clamp(_i, 0, 47)) {
        // -- beetles, elytra closed ---------------------------------------------------------
        case  0: return ctn_fd(CTN_HAB_OAKWOOD | CTN_HAB_ORCHARD,
                    CTN_SEA_LSPRING | CTN_SEA_ESUMMER | CTN_SEA_HSUMMER, 3,
                    CTN_DAY_DARK, CTN_WX_DRY, CTN_WX_CLEAR,
                    0.34, 1.10, 0.55, CTN_EVADE_RUN);          // stag beetle
        case  1: return ctn_fd(CTN_HAB_OAKWOOD,
                    CTN_SEA_ESUMMER | CTN_SEA_HSUMMER, 3,
                    CTN_DAY_NIGHT, CTN_WX_DRY, CTN_WX_CLEAR,
                    0.22, 1.05, 0.50, CTN_EVADE_RUN);          // rhinoceros beetle
        case  2: return ctn_fd(CTN_HAB_MARSH | CTN_HAB_RIVERBANK,
                    CTN_SEA_ALL, 2,
                    CTN_DAY_DAYLIGHT | CTN_DAY_DUSK, CTN_WX_ANY, CTN_WX_OVERCAST,
                    0.46, 3.40, 2.30, CTN_EVADE_DIVE);         // great diving beetle
        case  3: return ctn_fd(CTN_HAB_HEATH | CTN_HAB_MEADOW,
                    CTN_SEA_LSPRING | CTN_SEA_ESUMMER | CTN_SEA_HSUMMER | CTN_SEA_LSUMMER
                    | CTN_SEA_AUTUMN, 4,
                    CTN_DAY_DARK, CTN_WX_DRY, CTN_WX_OVERCAST,
                    0.52, 1.30, 0.60, CTN_EVADE_RUN);          // dor beetle
        case  4: return ctn_fd(CTN_HAB_HEATH | CTN_HAB_MEADOW,
                    CTN_SEA_LSPRING | CTN_SEA_ESUMMER | CTN_SEA_HSUMMER, 2,
                    CTN_DAY_SUNNY, CTN_WX_CLEAR, CTN_WX_CLEAR,
                    0.38, 5.20, 3.40, CTN_EVADE_RUN);          // green tiger beetle
        case  5: return ctn_fd(CTN_HAB_HEDGEROW | CTN_HAB_OAKWOOD | CTN_HAB_ORCHARD,
                    CTN_SEA_ALL, 1,
                    CTN_DAY_DARK, CTN_WX_ANY, CTN_WX_OVERCAST,
                    0.60, 2.60, 2.10, CTN_EVADE_RUN);          // violet ground beetle
        case  6: return ctn_fd(CTN_HAB_HEDGEROW | CTN_HAB_OAKWOOD | CTN_HAB_ORCHARD,
                    CTN_SEA_LSPRING, 1,
                    CTN_DAY_DARK, CTN_WX_DRY, CTN_WX_CLEAR,
                    0.66, 1.40, 1.05, CTN_EVADE_DROP);         // cockchafer
        case  7: return ctn_fd(CTN_HAB_MEADOW | CTN_HAB_HEDGEROW | CTN_HAB_ORCHARD,
                    CTN_SEA_ESUMMER | CTN_SEA_HSUMMER | CTN_SEA_LSUMMER, 3,
                    CTN_DAY_SUNNY, CTN_WX_CLEAR, CTN_WX_CLEAR,
                    0.44, 2.20, 1.60, CTN_EVADE_DROP);         // rose chafer
        case  8: return ctn_fd(CTN_HAB_PINEWOOD | CTN_HAB_OAKWOOD,
                    CTN_SEA_HSUMMER, 3,
                    CTN_DAY_SUNNY, CTN_WX_CLEAR, CTN_WX_CLEAR,
                    0.16, 3.80, 2.40, CTN_EVADE_BOLT);         // jewel beetle
        case  9: return ctn_fd(CTN_HAB_MEADOW | CTN_HAB_HEDGEROW,
                    CTN_SEA_LSPRING | CTN_SEA_ESUMMER, 1,
                    CTN_DAY_DAYLIGHT, CTN_WX_DRY, CTN_WX_CLEAR,
                    0.56, 1.80, 0.90, CTN_EVADE_JUMP);         // click beetle
        case 10: return ctn_fd(CTN_HAB_HEATH | CTN_HAB_MEADOW,
                    CTN_SEA_ESPRING | CTN_SEA_LSPRING | CTN_SEA_ESUMMER, 1,
                    CTN_DAY_MORNING | CTN_DAY_MIDDAY, CTN_WX_DRY, CTN_WX_OVERCAST,
                    0.40, 0.60, 0.35, CTN_EVADE_RUN);          // bloody nosed beetle
        case 11: return ctn_fd(CTN_HAB_RIVERBANK | CTN_HAB_MARSH,
                    CTN_SEA_HSUMMER, 3,
                    CTN_DAY_AFTERNOON | CTN_DAY_DUSK, CTN_WX_DRY, CTN_WX_CLEAR,
                    0.14, 2.00, 1.20, CTN_EVADE_DROP);         // musk beetle

        // -- beetles, marked and small ------------------------------------------------------
        case 12: return ctn_fd(CTN_HAB_MEADOW | CTN_HAB_HEDGEROW | CTN_HAB_ORCHARD,
                    CTN_SEA_ALL, 2,
                    CTN_DAY_DAYLIGHT | CTN_DAY_DUSK, CTN_WX_DRY, CTN_WX_CLEAR,
                    0.86, 1.20, 0.70, CTN_EVADE_DROP);         // seven spot ladybird
        case 13: return ctn_fd(CTN_HAB_PINEWOOD,
                    CTN_SEA_LSPRING | CTN_SEA_ESUMMER | CTN_SEA_HSUMMER | CTN_SEA_LSUMMER, 2,
                    CTN_DAY_SUNNY, CTN_WX_DRY, CTN_WX_CLEAR,
                    0.30, 1.30, 0.75, CTN_EVADE_DROP);         // eyed ladybird
        case 14: return ctn_fd(CTN_HAB_HEDGEROW | CTN_HAB_OAKWOOD,
                    CTN_SEA_LSPRING | CTN_SEA_ESUMMER, 2,
                    CTN_DAY_SUNNY, CTN_WX_CLEAR, CTN_WX_CLEAR,
                    0.32, 3.10, 1.90, CTN_EVADE_BOLT);         // wasp beetle
        case 15: return ctn_fd(CTN_HAB_MEADOW | CTN_HAB_HEDGEROW,
                    CTN_SEA_ESUMMER | CTN_SEA_HSUMMER | CTN_SEA_LSUMMER, 3,
                    CTN_DAY_SUNNY, CTN_WX_DRY, CTN_WX_CLEAR,
                    0.78, 1.60, 0.95, CTN_EVADE_DROP);         // soldier beetle
        case 16: return ctn_fd(CTN_HAB_MEADOW | CTN_HAB_HEATH | CTN_HAB_HEDGEROW,
                    CTN_SEA_ESUMMER | CTN_SEA_HSUMMER, 3,
                    CTN_DAY_NIGHT, CTN_WX_DRY, CTN_WX_CLEAR,
                    0.18, 0.40, 0.15, CTN_EVADE_RUN);          // glow worm
        case 17: return ctn_fd(CTN_HAB_HEDGEROW | CTN_HAB_ORCHARD | CTN_HAB_OAKWOOD,
                    CTN_SEA_LSUMMER | CTN_SEA_AUTUMN, 5,
                    CTN_DAY_DARK, CTN_WX_ANY, CTN_WX_OVERCAST,
                    0.48, 1.90, 1.40, CTN_EVADE_RUN);          // devils coach horse
        case 18: return ctn_fd(CTN_HAB_HEDGEROW | CTN_HAB_OAKWOOD | CTN_HAB_ORCHARD,
                    CTN_SEA_LSPRING | CTN_SEA_ESUMMER | CTN_SEA_HSUMMER | CTN_SEA_LSUMMER, 2,
                    CTN_DAY_DAYLIGHT, CTN_WX_DRY, CTN_WX_OVERCAST,
                    0.72, 1.10, 0.45, CTN_EVADE_DROP);         // weevil
        case 19: return ctn_fd(CTN_HAB_OAKWOOD | CTN_HAB_PINEWOOD,
                    CTN_SEA_ESUMMER | CTN_SEA_HSUMMER, 3,
                    CTN_DAY_SUNNY, CTN_WX_CLEAR, CTN_WX_CLEAR,
                    0.36, 2.40, 1.50, CTN_EVADE_BOLT);         // longhorn beetle
        case 20: return ctn_fd(CTN_HAB_MEADOW | CTN_HAB_HEDGEROW | CTN_HAB_HEATH,
                    CTN_SEA_LSPRING | CTN_SEA_ESUMMER | CTN_SEA_HSUMMER | CTN_SEA_LSUMMER
                    | CTN_SEA_AUTUMN, 3,
                    CTN_DAY_NIGHT, CTN_WX_DRY, CTN_WX_OVERCAST,
                    0.28, 1.50, 0.80, CTN_EVADE_RUN);          // burying beetle
        case 21: return ctn_fd(CTN_HAB_RIVERBANK | CTN_HAB_MARSH,
                    CTN_SEA_LSPRING | CTN_SEA_ESUMMER | CTN_SEA_HSUMMER | CTN_SEA_LSUMMER
                    | CTN_SEA_AUTUMN, 2,
                    CTN_DAY_DAYLIGHT | CTN_DAY_DUSK, CTN_WX_DRY, CTN_WX_CLEAR,
                    0.64, 4.80, 3.60, CTN_EVADE_DIVE);         // whirligig beetle
        case 22: return ctn_fd(CTN_HAB_OAKWOOD | CTN_HAB_HEDGEROW,
                    CTN_SEA_LSPRING | CTN_SEA_ESUMMER, 2,
                    CTN_DAY_SUNNY, CTN_WX_CLEAR, CTN_WX_CLEAR,
                    0.42, 1.70, 1.00, CTN_EVADE_DROP);         // cardinal beetle
        case 23: return ctn_fd(CTN_HAB_MEADOW | CTN_HAB_ORCHARD,
                    CTN_SEA_LSPRING | CTN_SEA_ESUMMER | CTN_SEA_HSUMMER | CTN_SEA_LSUMMER, 3,
                    CTN_DAY_SUNNY, CTN_WX_DRY, CTN_WX_CLEAR,
                    0.90, 4.40, 4.20, CTN_EVADE_JUMP);         // flea beetle

        // -- butterflies ---------------------------------------------------------------------
        // ⛔ THE TWO HIBERNATORS ARE WHY THE SEASON COLUMN IS A MASK. The peacock and the brimstone
        // fly in early spring as ADULTS THAT OVERWINTERED, vanish while the next generation is in
        // its chrysalis, and fly again from late summer. A first..last window says "out all year",
        // which is the one thing that is not true about them.
        case 24: return ctn_fd(CTN_HAB_MEADOW | CTN_HAB_HEDGEROW | CTN_HAB_ORCHARD,
                    CTN_SEA_ESPRING | CTN_SEA_HSUMMER | CTN_SEA_LSUMMER | CTN_SEA_AUTUMN, 4,
                    CTN_DAY_SUNNY, CTN_WX_CLEAR, CTN_WX_CLEAR,
                    0.58, 3.20, 2.20, CTN_EVADE_FLIT);         // peacock
        case 25: return ctn_fd(CTN_HAB_MEADOW | CTN_HAB_HEDGEROW | CTN_HAB_ORCHARD,
                    CTN_SEA_ESUMMER | CTN_SEA_HSUMMER | CTN_SEA_LSUMMER | CTN_SEA_AUTUMN, 4,
                    CTN_DAY_SUNNY, CTN_WX_CLEAR, CTN_WX_CLEAR,
                    0.62, 3.40, 2.60, CTN_EVADE_FLIT);         // red admiral
        case 26: return ctn_fd(CTN_HAB_MEADOW | CTN_HAB_HEATH,
                    CTN_SEA_ESUMMER | CTN_SEA_HSUMMER | CTN_SEA_LSUMMER, 3,
                    CTN_DAY_SUNNY, CTN_WX_CLEAR, CTN_WX_CLEAR,
                    0.34, 3.60, 2.80, CTN_EVADE_FLIT);         // painted lady
        case 27: return ctn_fd(CTN_HAB_MEADOW | CTN_HAB_HEDGEROW | CTN_HAB_ORCHARD,
                    CTN_SEA_ESPRING | CTN_SEA_LSPRING | CTN_SEA_HSUMMER | CTN_SEA_LSUMMER
                    | CTN_SEA_AUTUMN, 4,
                    CTN_DAY_SUNNY, CTN_WX_CLEAR, CTN_WX_CLEAR,
                    0.68, 3.00, 2.30, CTN_EVADE_FLIT);         // small tortoiseshell
        case 28: return ctn_fd(CTN_HAB_HEDGEROW | CTN_HAB_OAKWOOD,
                    CTN_SEA_ESPRING | CTN_SEA_LSPRING | CTN_SEA_LSUMMER | CTN_SEA_AUTUMN, 0,
                    CTN_DAY_DAYLIGHT, CTN_WX_CLEAR, CTN_WX_CLEAR,
                    0.50, 2.90, 2.10, CTN_EVADE_FLIT);         // brimstone
        case 29: return ctn_fd(CTN_HAB_MEADOW | CTN_HAB_HEDGEROW | CTN_HAB_RIVERBANK,
                    CTN_SEA_LSPRING | CTN_SEA_ESUMMER, 1,
                    CTN_DAY_SUNNY, CTN_WX_CLEAR, CTN_WX_CLEAR,
                    0.44, 2.70, 1.90, CTN_EVADE_FLIT);         // orange tip
        case 30: return ctn_fd(CTN_HAB_MEADOW | CTN_HAB_HEATH,
                    CTN_SEA_LSPRING | CTN_SEA_ESUMMER | CTN_SEA_HSUMMER | CTN_SEA_LSUMMER, 3,
                    CTN_DAY_SUNNY, CTN_WX_CLEAR, CTN_WX_CLEAR,
                    0.54, 2.50, 1.70, CTN_EVADE_FLIT);         // common blue
        case 31: return ctn_fd(CTN_HAB_MEADOW,
                    CTN_SEA_HSUMMER | CTN_SEA_LSUMMER, 3,
                    CTN_DAY_SUNNY, CTN_WX_CLEAR, CTN_WX_CLEAR,
                    0.24, 2.60, 1.80, CTN_EVADE_FLIT);         // chalkhill blue
        case 32: return ctn_fd(CTN_HAB_MARSH,
                    CTN_SEA_LSPRING | CTN_SEA_ESUMMER | CTN_SEA_LSUMMER, 2,
                    CTN_DAY_SUNNY, CTN_WX_CLEAR, CTN_WX_CLEAR,
                    0.10, 4.00, 3.10, CTN_EVADE_FLIT);         // swallowtail
        case 33: return ctn_fd(CTN_HAB_OAKWOOD,
                    CTN_SEA_HSUMMER, 3,
                    CTN_DAY_MIDDAY, CTN_WX_CLEAR, CTN_WX_CLEAR,
                    0.08, 4.20, 3.00, CTN_EVADE_FLIT);         // purple emperor
        case 34: return ctn_fd(CTN_HAB_OAKWOOD,
                    CTN_SEA_HSUMMER | CTN_SEA_LSUMMER, 3,
                    CTN_DAY_SUNNY, CTN_WX_CLEAR, CTN_WX_CLEAR,
                    0.30, 3.50, 2.70, CTN_EVADE_FLIT);         // silver washed fritillary
        case 35: return ctn_fd(CTN_HAB_MEADOW,
                    CTN_SEA_HSUMMER, 3,
                    CTN_DAY_SUNNY, CTN_WX_CLEAR, CTN_WX_CLEAR,
                    0.46, 2.80, 1.85, CTN_EVADE_FLIT);         // marbled white

        // -- moths ---------------------------------------------------------------------------
        // ⚠️ FIVE OF THE TWELVE FLY BY DAY, AND THAT IS THE POINT OF THE DAYPART COLUMN. "Moths come
        // out at night" is the folk rule, and the cinnabar, the six spot burnet, the hummingbird
        // hawk moth and the male emperor moth all break it in broad sunshine. A player who works
        // that out from the field guide has learned a real thing about moths.
        case 36: return ctn_fd(CTN_HAB_MEADOW | CTN_HAB_RIVERBANK | CTN_HAB_HEDGEROW,
                    CTN_SEA_ESUMMER | CTN_SEA_HSUMMER, 3,
                    CTN_DAY_DARK, CTN_WX_DRY, CTN_WX_CLEAR,
                    0.32, 2.30, 2.90, CTN_EVADE_BOLT);         // elephant hawk moth
        case 37: return ctn_fd(CTN_HAB_RIVERBANK | CTN_HAB_HEDGEROW | CTN_HAB_ORCHARD,
                    CTN_SEA_LSPRING | CTN_SEA_ESUMMER | CTN_SEA_HSUMMER, 2,
                    CTN_DAY_NIGHT, CTN_WX_DRY, CTN_WX_OVERCAST,
                    0.36, 1.60, 2.40, CTN_EVADE_BOLT);         // poplar hawk moth
        case 38: return ctn_fd(CTN_HAB_MEADOW | CTN_HAB_ORCHARD,
                    CTN_SEA_LSUMMER | CTN_SEA_AUTUMN, 5,
                    CTN_DAY_NIGHT, CTN_WX_DRY, CTN_WX_OVERCAST,
                    0.05, 2.80, 3.30, CTN_EVADE_BOLT);         // death's head hawk moth
        case 39: return ctn_fd(CTN_HAB_MEADOW | CTN_HAB_HEDGEROW | CTN_HAB_ORCHARD,
                    CTN_SEA_HSUMMER | CTN_SEA_LSUMMER, 4,
                    CTN_DAY_DAYLIGHT, CTN_WX_CLEAR, CTN_WX_CLEAR,
                    0.20, 5.00, 4.60, CTN_EVADE_BOLT);         // hummingbird hawk moth
        case 40: return ctn_fd(CTN_HAB_MEADOW | CTN_HAB_HEDGEROW | CTN_HAB_RIVERBANK,
                    CTN_SEA_HSUMMER | CTN_SEA_LSUMMER, 3,
                    CTN_DAY_NIGHT, CTN_WX_DRY, CTN_WX_CLEAR,
                    0.38, 1.70, 1.80, CTN_EVADE_BOLT);         // garden tiger
        case 41: return ctn_fd(CTN_HAB_MEADOW | CTN_HAB_HEATH | CTN_HAB_RIVERBANK,
                    CTN_SEA_LSPRING | CTN_SEA_ESUMMER, 2,
                    CTN_DAY_SUNNY | CTN_DAY_DUSK, CTN_WX_DRY, CTN_WX_CLEAR,
                    0.56, 1.40, 1.10, CTN_EVADE_FLIT);         // cinnabar
        case 42: return ctn_fd(CTN_HAB_HEATH,
                    CTN_SEA_ESPRING | CTN_SEA_LSPRING, 1,
                    CTN_DAY_SUNNY, CTN_WX_CLEAR, CTN_WX_CLEAR,
                    0.22, 4.10, 3.80, CTN_EVADE_BOLT);         // emperor moth
        case 43: return ctn_fd(CTN_HAB_HEDGEROW | CTN_HAB_ORCHARD | CTN_HAB_OAKWOOD,
                    CTN_SEA_LSPRING | CTN_SEA_ESUMMER, 1,
                    CTN_DAY_NIGHT, CTN_WX_DRY, CTN_WX_OVERCAST,
                    0.30, 1.50, 2.20, CTN_EVADE_BOLT);         // lime hawk moth
        case 44: return ctn_fd(CTN_HAB_MEADOW | CTN_HAB_HEDGEROW | CTN_HAB_ORCHARD,
                    CTN_SEA_ESUMMER | CTN_SEA_HSUMMER | CTN_SEA_LSUMMER, 3,
                    CTN_DAY_NIGHT, CTN_WX_DRY, CTN_WX_OVERCAST,
                    0.42, 2.00, 1.90, CTN_EVADE_BOLT);         // burnished brass
        case 45: return ctn_fd(CTN_HAB_HEDGEROW | CTN_HAB_ORCHARD | CTN_HAB_MEADOW,
                    CTN_SEA_ALL, 5,
                    CTN_DAY_NIGHT, CTN_WX_ANY, CTN_WX_OVERCAST,
                    0.64, 1.30, 1.60, CTN_EVADE_FLIT);         // angle shades
        case 46: return ctn_fd(CTN_HAB_OAKWOOD | CTN_HAB_HEDGEROW,
                    CTN_SEA_LSPRING | CTN_SEA_ESUMMER | CTN_SEA_HSUMMER, 2,
                    CTN_DAY_NIGHT, CTN_WX_DRY, CTN_WX_CLEAR,
                    0.34, 0.90, 1.40, CTN_EVADE_BOLT);         // buff tip
        default: return ctn_fd(CTN_HAB_MEADOW | CTN_HAB_HEATH,
                    CTN_SEA_HSUMMER | CTN_SEA_LSUMMER, 3,
                    CTN_DAY_SUNNY, CTN_WX_CLEAR, CTN_WX_CLEAR,
                    0.52, 1.20, 0.90, CTN_EVADE_FLIT);         // six spot burnet
    }
}

/// ============================================================================================
/// THE QUERY. What is out right now.
/// ============================================================================================

/// Is bit _b set in mask _m? One place, because `(_m & _b) != 0` written 200 times is 200 chances
/// to write `== 1` instead and have it work for the first habitat only.
function ctn_bit(_m, _b) {
    return (_m & _b) != 0;
}

/// Turn an INDEX into the BIT at that index. Every mask in this file is index-parallel with a name
/// array, so this is the bridge between "the third habitat" and "the habitat bit".
function ctn_bit_at(_idx) {
    return 1 << _idx;
}

/// How likely a species is to be encountered under one set of conditions. 0 means NOT OUT.
///
/// ⛔ IT RETURNS A DENSITY, NOT A BOOLEAN, AND THAT IS WHAT MAKES THE SEASON WORTH LEARNING. A
/// species is present across its whole flight period, but there is a MONTH when there are most of
/// them, and a weather it actually likes as opposed to merely tolerates. A boolean answer erases
/// both, and the player has no reason to prefer one afternoon to another.
///
/// _hab, _sea, _day are INDICES (0..n-1) because that is what a game's clock and map hold.
/// _wx is a BIT, because weather is a single condition rather than a place in a list.
function ctn_field_density(_i, _hab, _sea, _day, _wx) {
    var _f = ctn_field_spec(_i);
    if (!ctn_bit(_f.hab, ctn_bit_at(_hab))) return 0;
    if (!ctn_bit(_f.sea, ctn_bit_at(_sea))) return 0;
    if (!ctn_bit(_f.day, ctn_bit_at(_day))) return 0;
    if (!ctn_bit(_f.wx, _wx)) return 0;

    var _p = _f.abund;
    // The peak month. Off-peak it is present but thin.
    if (_sea != _f.peak) _p *= 0.55;
    // Preferred weather versus merely tolerated.
    if (_wx != _f.wxp) _p *= 0.60;
    return _p;
}

/// Everything that is out under one set of conditions, commonest first.
///
/// ⚠️ THE TIE-BREAK IS THE SPECIES INDEX AND THAT IS NOT COSMETIC. Two species at identical density
/// must come back in the same order every call or the field list flickers between frames, which is
/// the one defect a buyer notices immediately. ctn_selftest asserts the whole list is identical
/// across two calls for this reason.
function ctn_field_now(_hab, _sea, _day, _wx) {
    /// ⛔ AN EMPTY LIST IS ALREADY A DOCUMENTED OUTCOME HERE, which is what makes it the right
    /// refusal: the Readme says this returns rows "commonest first" and ctn_field_pick already
    /// treats a zero-length result as "nothing is out". A caller who passes undefined for a habitat
    /// therefore gets the same answer as a caller who asked about a genuinely empty combination.
    /// ⚠️ That is a deliberate trade and it has a cost worth naming: the two cases become
    /// indistinguishable to the caller. It is still better than DoConv from four frames deeper, and
    /// the indices are small enumerations a buyer reads straight off the Readme.
    if (!ctn_is_num(_hab) || !ctn_is_num(_sea) || !ctn_is_num(_day) || !ctn_is_num(_wx)) return [];
    var _out = [];
    for (var _i = 0; _i < ctn_species_n(); _i++) {
        var _p = ctn_field_density(_i, _hab, _sea, _day, _wx);
        if (_p > 0) array_push(_out, { i: _i, p: _p });
    }
    // Insertion sort. The list is at most 48 long and usually under 10, and a stable hand-written
    // sort with an explicit tie-break is cheaper to reason about than array_sort with a comparator.
    for (var _a = 1; _a < array_length(_out); _a++) {
        var _v = _out[_a];
        var _b = _a - 1;
        while (_b >= 0 && (_out[_b].p < _v.p || (_out[_b].p == _v.p && _out[_b].i > _v.i))) {
            _out[_b + 1] = _out[_b];
            _b -= 1;
        }
        _out[_b + 1] = _v;
    }
    return _out;
}

/// Pick ONE species out of what is available, by density, from a seed. Deterministic.
///
/// This is the function a spawner calls. It is here rather than in the spawner because the
/// weighting is a property of the corpus, and because a pure function that takes a seed can be
/// asserted - ctn_selftest runs it 4,000 times and checks the distribution matches the densities.
/// Returns -1 when nothing at all is out, which is a real answer: a heath in the rain at 3am is
/// empty, and a game that always finds you something has thrown away the field layer.
function ctn_field_pick(_hab, _sea, _day, _wx, _seed) {
    /// The four indices are covered by ctn_field_now's own guard - a bad one returns an empty list
    /// and this function's documented -1 falls out of it. The SEED is not, because it is used after
    /// that check, so it is guarded here. ⚠️ A seed is defaulted rather than refused: -1 means "the
    /// combination is empty" to a caller, and returning it for a missing seed would say something
    /// false about the world instead of about the call.
    if (!ctn_is_num(_seed)) _seed = 0;
    var _l = ctn_field_now(_hab, _sea, _day, _wx);
    var _n = array_length(_l);
    if (_n == 0) return -1;
    var _tot = 0;
    for (var _k = 0; _k < _n; _k++) _tot += _l[_k].p;
    var _g = ctn_rng(_seed);
    var _r = ctn_rng_next(_g) * _tot;
    var _acc = 0;
    for (var _k = 0; _k < _n; _k++) {
        _acc += _l[_k].p;
        if (_r < _acc) return _l[_k].i;
    }
    return _l[_n - 1].i;
}

/// ============================================================================================
/// RARITY, DERIVED
/// ============================================================================================

/// How many of the 1,152 (habitat x season x daypart x weather) cells a species occupies.
function ctn_field_cells(_i) {
    var _f = ctn_field_spec(_i);
    var _h = 0, _s = 0, _d = 0, _w = 0, _k;
    for (_k = 0; _k < CTN_HAB_N;     _k++) if (ctn_bit(_f.hab, ctn_bit_at(_k))) _h += 1;
    for (_k = 0; _k < CTN_SEASON_N;  _k++) if (ctn_bit(_f.sea, ctn_bit_at(_k))) _s += 1;
    for (_k = 0; _k < CTN_DAYPART_N; _k++) if (ctn_bit(_f.day, ctn_bit_at(_k))) _d += 1;
    for (_k = 0; _k < CTN_WEATHER_N; _k++) if (ctn_bit(_f.wx,  ctn_bit_at(_k))) _w += 1;
    return _h * _s * _d * _w;
}

/// How hard a species is to find, 0 (everywhere, always) to 1 (one cell, and thin when you get
/// there). DERIVED from the field data and the abundance, never authored.
///
/// ⛔ THE SECOND DECLARATION OF A NUMBER IS THE DEFECT THIS FACTORY KEEPS PAYING FOR (CLAUDE.md 2b,
/// six recorded instances). A `rare: true` column beside a flight period of one season, one habitat
/// and one daypart would be exactly that: the data ALREADY says it is rare, and the day someone
/// widens the flight period the column would go on lying.
function ctn_field_rarity(_i) {
    var _f = ctn_field_spec(_i);
    var _cells = ctn_field_cells(_i);
    // 1,152 is every cell in the space. The fourth root keeps the scale readable: a species in a
    // tenth of the space is not ten times rarer to the player, because they are not sampling the
    // space uniformly - they are standing in one habitat at one time of year.
    var _cover = power(_cells / (CTN_HAB_N * CTN_SEASON_N * CTN_DAYPART_N * CTN_WEATHER_N), 0.25);
    return clamp(1 - _cover * clamp(_f.abund * 1.35, 0, 1), 0, 1);
}

/// The rarity BAND a player sees. Five of them, and the thresholds are the only authored numbers in
/// the rarity chain.
function ctn_field_rarity_band(_i) {
    var _r = ctn_field_rarity(_i);
    if (_r < 0.42) return 0;
    if (_r < 0.60) return 1;
    if (_r < 0.74) return 2;
    if (_r < 0.86) return 3;
    return 4;
}

/// ============================================================================================
/// THE FIELD GUIDE. Sentences built from the same masks the query reads.
/// ============================================================================================

/// "meadow", "meadow and hedgerow", "meadow, hedgerow and orchard". English, from a bitmask.
///
/// ⚠️ ASCII ONLY IN EVERY LITERAL HERE. The shipped fonts declare 32..126 and a character outside
/// that range draws NOTHING - no box, no warning, just a hole that reads as a spacing choice.
/// Internal_Ops/ascii_check.js scans for it because no ink check can see it.
function ctn_field_list(_mask, _names) {
    var _hit = [];
    for (var _k = 0; _k < array_length(_names); _k++) {
        if (ctn_bit(_mask, ctn_bit_at(_k))) array_push(_hit, _names[_k]);
    }
    var _n = array_length(_hit);
    if (_n == 0) return "nowhere";
    if (_n == 1) return _hit[0];
    var _s = "";
    for (var _k = 0; _k < _n - 1; _k++) {
        if (_k > 0) _s += ", ";
        _s += _hit[_k];
    }
    return _s + " and " + _hit[_n - 1];
}

/// The whole "where and when" line for one species, as a player reads it in the guide.
function ctn_field_when_line(_i) {
    var _f = ctn_field_spec(_i);
    return ctn_field_list(_f.hab, ctn_habitat_names())
         + "; " + ctn_field_list(_f.sea, ctn_season_names())
         + "; " + ctn_field_list(_f.day, ctn_daypart_names());
}

/// ============================================================================================
/// IDENTIFICATION. The field marks, and what separates two species.
/// ============================================================================================

/// The marks an identification card shows, as label/value pairs. Six of them, and every one is read
/// off the species record rather than written twice.
function ctn_field_marks(_i) {
    var _sp = ctn_species_spec(_i);
    var _pn = ctn_name_of(ctn_pattern_names(), _sp.pat);
    if (_sp.patn > 0) _pn += " x" + string(_sp.patn);
    return [
        { label: "form",      value: ctn_name_of(ctn_plan_names(), _sp.plan) },
        { label: "antennae",  value: ctn_name_of(ctn_antenna_names(), _sp.ant) },
        { label: "sculpture", value: ctn_name_of(ctn_sculpture_names(), _sp.scu) },
        { label: "legs",      value: ctn_name_of(ctn_leg_names(), _sp.leg) },
        { label: "cuticle",   value: ctn_name_of(ctn_cuticle_names(), _sp.cut) },
        { label: "marking",   value: _pn }
    ];
}

/// WHICH MARKS TELL TWO SPECIES APART. Returns the labels that DIFFER.
///
/// ⭐ THIS IS THE ONE FUNCTION IN THE FILE THAT TEACHES. A player who confuses the seven spot and
/// the eyed ladybird gets back exactly one word - "marking" - which is true, is the whole answer,
/// and is a fact about ladybirds rather than a hint from a game. The corpus is authored so that
/// this is possible: the two ladybirds share every body number to the digit precisely so that the
/// difference between them is the difference between them.
///
/// ⛔ AND AN EMPTY RESULT IS A CORPUS DEFECT, NOT A DRAW. Two species with no distinguishing mark
/// at all are two species the player cannot ever separate, which means one of them is redundant.
/// ctn_selftest asserts this over all 1,128 pairs.
function ctn_field_separates(_a, _b) {
    /// Both arguments are species indices, and the answer for "these two do not both exist" is the
    /// same as for "nothing separates them": an empty label list.
    if (!ctn_is_species(_a) || !ctn_is_species(_b)) return [];
    var _ma = ctn_field_marks(_a);
    var _mb = ctn_field_marks(_b);
    var _out = [];
    for (var _k = 0; _k < array_length(_ma); _k++) {
        if (_ma[_k].value != _mb[_k].value) array_push(_out, _ma[_k].label);
    }
    return _out;
}

/// THE SPECIES THIS ONE IS MOST EASILY CONFUSED WITH, and the marks that tell them apart.
///
/// ⭐ THIS IS THE FUNCTION A FIELD GUIDE PAGE IS ACTUALLY FOR. A real guide does not only describe
/// an animal; it says "and here is the one you will mistake it for, and here is how not to". The
/// answer is DERIVED - it is the species sharing the most field marks - so it moves with the corpus
/// and can never become a stale cross-reference table.
///
/// ⚠️ THE TIE-BREAK IS THE LOWEST INDEX, and it is not cosmetic: without it two equally-close
/// species return in whichever order the loop happened to reach them, and a guide page that names a
/// different lookalike between two runs is a page nobody can trust. ctn_selftest asserts the whole
/// result is identical across calls.
function ctn_field_nearest(_i) {
    var _best = -1, _bestN = 99;
    for (var _j = 0; _j < ctn_species_n(); _j++) {
        if (_j == _i) continue;
        var _n = array_length(ctn_field_separates(_i, _j));
        if (_n < _bestN) { _bestN = _n; _best = _j; }
    }
    return { i: _best, marks: (_best < 0) ? [] : ctn_field_separates(_i, _best), n: _bestN };
}

/// Was a guess right? Returns a struct rather than a boolean because a wrong guess is a teaching
/// moment and the caller needs the material for it.
function ctn_field_identify(_actual, _guess) {
    if (_actual == _guess) {
        return { correct: true, marks: [], near: false };
    }
    var _d = ctn_field_separates(_actual, _guess);
    // "Near" means a defensible mistake: three or fewer of the six marks differ. A player who
    // called a chalkhill blue a common blue was nearly right and should be told so; one who called
    // it a stag beetle was not.
    return { correct: false, marks: _d, near: (array_length(_d) <= 3) };
}
