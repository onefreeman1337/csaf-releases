{
  "$GMScript": "v1",
  "%Name": "ctn_antenna",
  "name": "ctn_antenna",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}