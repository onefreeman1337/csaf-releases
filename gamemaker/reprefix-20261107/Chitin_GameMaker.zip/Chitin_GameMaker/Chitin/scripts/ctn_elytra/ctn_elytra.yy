{
  "$GMScript": "v1",
  "%Name": "ctn_elytra",
  "name": "ctn_elytra",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}