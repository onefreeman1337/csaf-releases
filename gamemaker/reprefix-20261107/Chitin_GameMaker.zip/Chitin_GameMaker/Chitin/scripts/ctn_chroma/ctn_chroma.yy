{
  "$GMScript": "v1",
  "%Name": "ctn_chroma",
  "name": "ctn_chroma",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}