{
  "$GMScript": "v1",
  "%Name": "ctn_wing",
  "name": "ctn_wing",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}