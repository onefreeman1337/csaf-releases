/// @description THE TAPROOM - free every sprite the room and the table made. Runs even when Create left early (-selftest).
if (is_struct(demo)) tpm_demo_free(demo);
demo = undefined;
