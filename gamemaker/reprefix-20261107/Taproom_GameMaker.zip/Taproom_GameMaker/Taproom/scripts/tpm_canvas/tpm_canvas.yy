{
  "$GMScript": "v1",
  "%Name": "tpm_canvas",
  "name": "tpm_canvas",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}