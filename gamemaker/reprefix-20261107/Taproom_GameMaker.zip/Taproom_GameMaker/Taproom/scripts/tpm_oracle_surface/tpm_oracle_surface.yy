{
  "$GMScript": "v1",
  "%Name": "tpm_oracle_surface",
  "name": "tpm_oracle_surface",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}