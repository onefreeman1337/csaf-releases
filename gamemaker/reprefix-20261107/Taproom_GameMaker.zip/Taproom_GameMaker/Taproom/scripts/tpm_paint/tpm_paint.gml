/// tpm_paint.gml - the canvas verbs Taproom's painter draws through, each feeding the TEST LOG when one is open (free
/// otherwise): the log is how the self-test holds the GML painter to the RPG Maker MZ edition drawn over a recording canvas.
/// Also the canvas filter blur(px) as a layer. Shared with this studio's other GameMaker drawing products.
///
/// Taproom - Tavern Board Games Against an Opponent Who Thinks, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

#macro TPM_STROKE_ROUND 1

// ---------------------------------------------------------------------------------------------------------------
// The test log (free unless ctx.tpm_lg is a struct) and the path verbs that feed it. The log is HASHED as it is written
// (FNV-1a, the MZ hash, chunk by chunk), never built whole: a yard of 36 signs logs a quarter of a million characters.
// ---------------------------------------------------------------------------------------------------------------

/// @function tpm__r100(v)
/// @description Internal. floor(v * 100 + 0.5), with -0 made 0 (the oracle's rounding).
function tpm__r100(_v) { return floor(_v * 100 + 0.5) + 0; }

/// @function tpm_log_begin(ctx, [keep])
/// @description Switch the test log on for a context: every paint event is hashed into ctx.tpm_lg { h, len, events, keep }.
/// keep = how many leading characters to retain for a diagnostic (0 by default).
function tpm_log_begin(_c, _keep = 0) { _c.tpm_lg = { h: int64(2166136261), len: 0, events: 0, keep: _keep, text: "", n: 0, s: 0 }; }

/// @function tpm_log_end(ctx)
/// @description The log's { events, len, hash, text } and the log switched off.
function tpm_log_end(_c) {
    var _l = _c[$ "tpm_lg"];
    if (!is_struct(_l)) return { events: 0, len: 0, hash: 0, text: "" };
    _c.tpm_lg = undefined;
    return { events: _l.events, len: _l.len, hash: real(_l.h), text: _l.text };
}

function tpm__logging(_c) { return is_struct(_c[$ "tpm_lg"]); }
function tpm__lg_emit(_c, _ev) {
    var _l = _c.tpm_lg, _h = _l.h, _m = int64($FFFFFFFF), _p = int64(16777619);
    for (var _i = 1; _i <= string_length(_ev); _i++) _h = ((_h ^ int64(ord(string_char_at(_ev, _i)))) * _p) & _m;
    _l.h = _h; _l.len += string_length(_ev); _l.events += 1;
    if (string_length(_l.text) < _l.keep) _l.text += _ev;
}
function tpm__lg_add(_c, _v) { if (tpm__logging(_c)) _c.tpm_lg.s += _v; }
function tpm__lg_n(_c) { if (tpm__logging(_c)) _c.tpm_lg.n += 1; }

/// @function tpm__lg_paint(paint)
/// @description Internal. A paint as the oracle writes it: "r,g,b:a" or "G<L|R><stops>@<geometry>:t,r,g,b,a/...".
function tpm__lg_paint(_p) {
    if (_p.kind == 0) return string(colour_get_red(_p.col)) + "," + string(colour_get_green(_p.col)) + "," + string(colour_get_blue(_p.col)) + ":" + string(tpm__r100(_p.a));
    var _geo = (_p.kind == 1) ? (_p.x0 + _p.y0 + _p.x1 + _p.y1) : (_p.x0 + _p.y0 + _p.r0 + _p.x1 + _p.y1 + _p.r1);
    var _s = "G" + ((_p.kind == 1) ? "L" : "R") + string(array_length(_p.stops)) + "@" + string(tpm__r100(_geo)) + ":";
    for (var _i = 0; _i < array_length(_p.stops); _i++) {
        var _st = _p.stops[_i];
        _s += ((_i > 0) ? "/" : "") + string(tpm__r100(_st[0])) + "," + string(colour_get_red(_st[1])) + "," + string(colour_get_green(_st[1])) + "," + string(colour_get_blue(_st[1])) + "," + string(tpm__r100(_st[2]));
    }
    return _s;
}

/// @function tpm__lg_t(ctx)
/// @description Internal. The current transform and alpha as the oracle writes them.
function tpm__lg_t(_c) { var _m = _c.m; return string(tpm__r100(_m[0])) + "," + string(tpm__r100(_m[1])) + "," + string(tpm__r100(_m[2])) + "," + string(tpm__r100(_m[3])) + "," + string(tpm__r100(_m[4])) + "," + string(tpm__r100(_m[5])); }
function tpm__lg_a(_c) { return ":a" + string(tpm__r100(_c.alpha)); }

function tpm__p_begin(_c) { tpm_cx_begin(_c); if (tpm__logging(_c)) { _c.tpm_lg.n = 0; _c.tpm_lg.s = 0; } }
function tpm__p_move(_c, _x, _y) { if (tpm__logging(_c)) { _c.tpm_lg.n += 1; _c.tpm_lg.s += _x; _c.tpm_lg.s += _y; } tpm_cx_move(_c, _x, _y); }
function tpm__p_line(_c, _x, _y) { if (tpm__logging(_c)) { _c.tpm_lg.n += 1; _c.tpm_lg.s += _x; _c.tpm_lg.s += _y; } tpm_cx_line(_c, _x, _y); }
function tpm__p_quad(_c, _a, _b, _x, _y) { if (tpm__logging(_c)) { _c.tpm_lg.n += 1; _c.tpm_lg.s += _a; _c.tpm_lg.s += _b; _c.tpm_lg.s += _x; _c.tpm_lg.s += _y; } tpm_cx_quad(_c, _a, _b, _x, _y); }
function tpm__p_bez(_c, _a, _b, _cc, _d, _x, _y) { if (tpm__logging(_c)) { _c.tpm_lg.n += 1; _c.tpm_lg.s += _a; _c.tpm_lg.s += _b; _c.tpm_lg.s += _cc; _c.tpm_lg.s += _d; _c.tpm_lg.s += _x; _c.tpm_lg.s += _y; } tpm_cx_bezier(_c, _a, _b, _cc, _d, _x, _y); }
function tpm__p_close(_c) { if (tpm__logging(_c)) _c.tpm_lg.n += 1; tpm_cx_close(_c); }
/// the canvas arc(x, y, r, a0, a1, [ccw])
function tpm__p_arc(_c, _x, _y, _r, _a0, _a1, _ccw = false) {
    if (tpm__logging(_c)) { _c.tpm_lg.n += 1; _c.tpm_lg.s += _x; _c.tpm_lg.s += _y; _c.tpm_lg.s += _r; _c.tpm_lg.s += _a0; _c.tpm_lg.s += _a1; }
    tpm_cx_ellipse(_c, _x, _y, _r, _r, 0, _a0, _a1, _ccw);
}
/// the canvas ellipse(x, y, rx, ry, rot, a0, a1, [ccw])
function tpm__p_ellipse(_c, _x, _y, _rx, _ry, _rot, _a0, _a1, _ccw = false) {
    if (tpm__logging(_c)) { _c.tpm_lg.n += 1; _c.tpm_lg.s += _x; _c.tpm_lg.s += _y; _c.tpm_lg.s += _rx; _c.tpm_lg.s += _ry; _c.tpm_lg.s += _rot; _c.tpm_lg.s += _a0; _c.tpm_lg.s += _a1; }
    tpm_cx_ellipse(_c, _x, _y, _rx, _ry, _rot, _a0, _a1, _ccw);
}
function tpm__p_fill(_c, _evenodd = false) {
    if (tpm__logging(_c)) tpm__lg_emit(_c, (_evenodd ? "E" : "F") + tpm__lg_paint(_c.fill) + ":" + string(_c.tpm_lg.n) + ":" + string(tpm__r100(_c.tpm_lg.s)) + ":" + tpm__lg_t(_c) + tpm__lg_a(_c) + ";");
    if (_evenodd) tpm_cx_fill_rule(_c, TPM_FILL_EVENODD); else tpm_cx_fill(_c);
}
function tpm__p_stroke(_c) {
    if (tpm__logging(_c)) tpm__lg_emit(_c, "S" + tpm__lg_paint(_c.stroke) + ":" + string(tpm__r100(_c.lw)) + ":" + ((_c.cap == 1) ? "r" : "b") + ((_c.join == 1) ? "r" : "m") + ":" + string(_c.tpm_lg.n) + ":" + string(tpm__r100(_c.tpm_lg.s)) + ":" + tpm__lg_t(_c) + tpm__lg_a(_c) + ";");
    tpm_cx_stroke(_c);
}
function tpm__p_fill_rect(_c, _x, _y, _w, _h) {
    if (tpm__logging(_c)) tpm__lg_emit(_c, "R" + tpm__lg_paint(_c.fill) + ":" + string(tpm__r100(_x + _y + _w + _h)) + ":" + tpm__lg_t(_c) + tpm__lg_a(_c) + ";");
    tpm_cx_fill_rect(_c, _x, _y, _w, _h);
}
/// a clip; even-odd and nonzero coincide in the kit's layer clip for every path this painter clips by (see tpm_canvas)
function tpm__p_clip(_c, _evenodd = false) {
    if (tpm__logging(_c)) tpm__lg_emit(_c, (_evenodd ? "D:" : "C:") + string(_c.tpm_lg.n) + ":" + string(tpm__r100(_c.tpm_lg.s)) + ":" + tpm__lg_t(_c) + ";");
    tpm_cx_clip(_c);
}
/// one glyph, baseline at (x, y), left-aligned (align 0) or centred on x (align 1), at an integer px, in a face
function tpm__p_text(_c, _ch, _x, _y, _px, _face, _align) {
    if (tpm__logging(_c)) tpm__lg_emit(_c, "T" + tpm__lg_paint(_c.fill) + ":" + string(ord(_ch)) + ":" + string(tpm__r100(_x + _y)) + ":" + string(_px) + ":" + string(_face) + ":" + ((_align == 1) ? "c" : "l") + ":" + tpm__lg_t(_c) + tpm__lg_a(_c) + ";");
    var _xx = (_align == 1) ? _x - tpm_text_width(_ch, _px, _face) / 2 : _x;
    return tpm_cx_glyph(_c, _ch, _xx, _y, _px, _face);
}

// ---------------------------------------------------------------------------------------------------------------
// The canvas filter blur(px), as a LAYER: what is drawn until tpm__p_blur_end goes into a transparent surface, which is
// then softened (taken down to 1/f size and back up, filtered) and composited, premultiplied, onto the target.
// ---------------------------------------------------------------------------------------------------------------

function tpm__p_blur_begin(_c, _px) {
    if (tpm__logging(_c)) tpm__lg_emit(_c, "B" + string(tpm__r100(_px)) + ";");
    var _tgt = surface_get_target();
    if (!variable_struct_exists(_c, "blurs")) _c.blurs = [];
    if (_tgt == -1 || !surface_exists(_tgt)) { array_push(_c.blurs, undefined); return; }
    var _w = surface_get_width(_tgt), _h = surface_get_height(_tgt);
    var _lay = surface_create(_w, _h);
    surface_set_target(_lay);
    draw_clear_alpha(c_black, 0);
    array_push(_c.blurs, { layer: _lay, w: _w, h: _h, f: max(2, round(_px * tpm_cx__scale(_c) * 1.4)) });
}
function tpm__p_blur_end(_c) {
    if (!variable_struct_exists(_c, "blurs") || array_length(_c.blurs) == 0) return;
    var _b = array_pop(_c.blurs);
    if (!is_struct(_b) || !surface_exists(_b.layer)) return;
    surface_reset_target();
    var _sw = max(1, ceil(_b.w / _b.f)), _sh = max(1, ceil(_b.h / _b.f));
    var _small = surface_create(_sw, _sh);
    var _pt = gpu_get_texfilter();
    gpu_push_state();
    gpu_set_texfilter(true);
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    surface_set_target(_small);
    draw_clear_alpha(c_black, 0);
    draw_surface_ext(_b.layer, 0, 0, _sw / _b.w, _sh / _b.h, 0, c_white, 1);
    surface_reset_target();
    draw_surface_ext(_small, 0, 0, _b.w / _sw, _b.h / _sh, 0, c_white, 1);
    gpu_pop_state();
    gpu_set_texfilter(_pt);
    surface_free(_small);
    surface_free(_b.layer);
}
