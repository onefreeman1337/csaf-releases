{
  "$GMScript": "v1",
  "%Name": "tpm_paint",
  "name": "tpm_paint",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}