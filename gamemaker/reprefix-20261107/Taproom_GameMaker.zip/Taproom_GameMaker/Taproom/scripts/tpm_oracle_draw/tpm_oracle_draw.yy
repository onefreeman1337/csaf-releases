{
  "$GMScript": "v1",
  "%Name": "tpm_oracle_draw",
  "name": "tpm_oracle_draw",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}