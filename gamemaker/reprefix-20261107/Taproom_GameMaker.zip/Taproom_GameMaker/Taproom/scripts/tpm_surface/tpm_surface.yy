{
  "$GMScript": "v1",
  "%Name": "tpm_surface",
  "name": "tpm_surface",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}