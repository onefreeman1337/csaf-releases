{
  "$GMScript": "v1",
  "%Name": "tpm_table",
  "name": "tpm_table",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}