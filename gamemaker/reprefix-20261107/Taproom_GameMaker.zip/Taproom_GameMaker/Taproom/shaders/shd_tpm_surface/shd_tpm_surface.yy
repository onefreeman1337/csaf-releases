{
  "$GMShader": "",
  "%Name": "shd_tpm_surface",
  "name": "shd_tpm_surface",
  "parent": {
    "name": "Shaders",
    "path": "folders/Shaders.yy"
  },
  "resourceType": "GMShader",
  "resourceVersion": "2.0",
  "type": 1
}