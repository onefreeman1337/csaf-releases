/// @description Keys: SPACE settles the next tie, A runs the rest, R redraws, L swaps the format, S restyles.
if (!csm_is_state(demo)) exit;
if (keyboard_check_pressed(vk_space)) csm_demo_play_one(demo);
if (keyboard_check_pressed(ord("A"))) csm_demo_play_all(demo);
if (keyboard_check_pressed(ord("R"))) demo = csm_demo_state(demo.record.format);
if (keyboard_check_pressed(ord("L"))) demo = csm_demo_state((demo.record.format == "single") ? "league" : "single");
if (keyboard_check_pressed(ord("S"))) style_index = (style_index + 1) mod array_length(csm_board_styles());
