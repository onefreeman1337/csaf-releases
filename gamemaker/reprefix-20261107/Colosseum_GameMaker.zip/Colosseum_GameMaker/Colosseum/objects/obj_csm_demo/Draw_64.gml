/// @description The drawn bracket board, or the ruled league table, plus the control bar.
if (!csm_is_state(demo)) exit;
csm_demo_draw(demo, display_get_gui_width(), display_get_gui_height(), csm_board_styles()[style_index]);
