/// @description Colosseum demo - and the headless entry point (-selftest).
/// ⛔ The crash handler is installed FIRST, and every variable a later event reads is declared ABOVE the early
/// exits: Clean Up always runs, even when Create leaves early, and it must not free what was never assigned.
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("csm_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.csm_stage) + ": " + string(_ex.message) + " | " + string(_ex.stacktrace));
    file_text_close(_f);
    game_end();
});
global.csm_stage = 0;
demo = undefined;
style_index = 0;
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";
if (string_pos("-selftest", _args) > 0) { global.csm_stage = 1; csm_selftest_write(csm_selftest_run()); game_end(); exit; }
if (string_pos("-bake", _args) > 0) { global.csm_stage = 200; csm_bake_all(); game_end(); exit; }
demo = csm_demo_state("single");
