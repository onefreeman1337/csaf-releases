/// csm_core.gml - the tournament record: teams and their ratings, weighted seeding, the bracket (single
/// elimination or league), results, standings, rivals that level between rounds, and the standard each team
/// carries.
///
/// Colosseum - Tournaments Your Game Draws, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory.
/// Every function in this file is PURE GML: no drawing, no surfaces, no instances, no globals. A port of this
/// factory's RPG Maker MZ plugin colosseum-core: the same model, re-shaped for GML - entrants are authored as
/// structs, ids live in ARRAYS of records (never as struct keys), and a match result is REPORTED by your game
/// rather than simulated, so it works with whatever combat you already have.

#macro CSM_VERSION 1
#macro CSM_SCHEMA 1
#macro CSM_STANDARD_FAMILIES 6
#macro CSM_STANDARD_CHARGES 10
#macro CSM_STANDARD_DIVISIONS 8
#macro CSM_STANDARD_TINCTURES 8
#macro CSM_STANDARD_ORDINARIES 6

/// @function csm_num(value, fallback)
/// @description `value` if it is a real number (not NaN), else `fallback`. `buffer_read` returns int32, so an
/// int32 is a number here too. Pure.
function csm_num(_v, _def) {
    if (is_real(_v) || is_int32(_v) || is_int64(_v)) { if (_v == _v) return _v; }
    return _def;
}

/// @function csm_hash(text, [salt])
/// @description A stable non-negative integer from a string: multiply by 48271 modulo 2^31 - 1 per character, so
/// every product stays under 2^53 and is exact in a double. Pure.
function csm_hash(_s, _salt = 0) {
    if (!is_string(_s)) _s = string(_s);
    var _M = 2147483647, _h = (1234567 + floor(csm_num(_salt, 0)) * 7919) mod _M;
    if (_h < 0) _h += _M;
    for (var _i = 1; _i <= string_length(_s); _i++) { _h = ((_h ^ ord(string_char_at(_s, _i))) * 48271 + 11) mod _M; if (_h < 0) _h += _M; }
    // avalanche: three more rounds so the low digits of `mod n` do not follow the last character
    repeat (3) { _h = (_h * 48271 + 12345) mod _M; _h = _h ^ (_h >> 13); }
    return _h;
}

/// @function csm_pick(key, stream, n)
/// @description An independent value in [0, n) from a key and a stream label - different labels give uncorrelated
/// choices from the same team. Pure.
function csm_pick(_key, _stream, _n) {
    _n = floor(csm_num(_n, 1));
    if (_n <= 1) return 0;
    return csm_hash(string(_key) + "|" + string(_stream)) mod _n;
}

/// @function csm__find(list, id)
/// @description Index of the record whose `id` equals `id`, or -1. Internal.
function csm__find(_l, _id) {
    if (!is_array(_l) || !is_string(_id)) return -1;
    for (var _i = 0; _i < array_length(_l); _i++) if (is_struct(_l[_i]) && is_string(_l[_i][$ "id"]) && _l[_i].id == _id) return _i;
    return -1;
}

/// @function csm_create([options])
/// @description A fresh tournament. Options (all optional): `title` ("The Colosseum"), `rounds_to_level` (1 - how
/// many rounds a surviving rival needs before it gains a level), `level_gain` (1), `bye_label` ("bye"),
/// `points_win` (3), `points_draw` (1). Nothing throws; bad options fall back. Pure.
function csm_create(_o = undefined) {
    if (!is_struct(_o)) _o = {};
    var _cfg = {
        title: is_string(_o[$ "title"]) ? _o.title : "The Colosseum",
        rounds_to_level: clamp(floor(csm_num(_o[$ "rounds_to_level"], 1)), 1, 16),
        level_gain: clamp(floor(csm_num(_o[$ "level_gain"], 1)), 0, 32),
        bye_label: is_string(_o[$ "bye_label"]) ? _o.bye_label : "bye",
        points_win: clamp(floor(csm_num(_o[$ "points_win"], 3)), 0, 16),
        points_draw: clamp(floor(csm_num(_o[$ "points_draw"], 1)), 0, 16)
    };
    return { version: CSM_VERSION, cfg: _cfg, teams: [], problems: [],
        record: { v: CSM_SCHEMA, format: "", matches: [], rounds: 0, started: false, champion: "", history: [] } };
}

/// @function csm_is_state(value)
/// @description True for a record made by csm_create. Every public function refuses anything else.
function csm_is_state(_s) { return is_struct(_s) && is_struct(_s[$ "cfg"]) && is_array(_s[$ "teams"]) && is_struct(_s[$ "record"]); }

/// @function csm_add_team(state, id, name, [rating], [options])
/// @description Enter a team. `rating` (default 50) drives weighted seeding and nothing else - your game decides
/// who actually wins. Options: `level` (1), `colour_key` (a string that fixes the standard; defaults to the id).
/// A duplicate id is kept out and REPORTED in `.problems`, never thrown. Returns the team record or undefined.
function csm_add_team(_st, _id, _name, _rating = 50, _o = undefined) {
    if (!csm_is_state(_st)) return undefined;
    if (!is_string(_id) || string_trim(_id) == "") { array_push(_st.problems, "a team with no id was skipped"); return undefined; }
    if (_st.record.started) { array_push(_st.problems, "team \"" + _id + "\" arrived after the draw and was skipped"); return undefined; }
    _id = string_trim(_id);
    if (csm__find(_st.teams, _id) >= 0) { array_push(_st.problems, "duplicate team id \"" + _id + "\" - the later one was ignored"); return undefined; }
    if (!is_struct(_o)) _o = {};
    var _t = {
        id: _id,
        name: is_string(_name) ? _name : _id,
        rating: clamp(csm_num(_rating, 50), 0, 1000),
        level: clamp(floor(csm_num(_o[$ "level"], 1)), 1, 999),
        colour_key: is_string(_o[$ "colour_key"]) ? _o.colour_key : _id,
        wins: 0, losses: 0, draws: 0, points: 0, rounds_survived: 0, out: false, seed: 0
    };
    array_push(_st.teams, _t);
    return _t;
}

/// @function csm_team(state, id)
/// @description One team record, or undefined.
function csm_team(_st, _id) { if (!csm_is_state(_st)) return undefined; var _i = csm__find(_st.teams, _id); return (_i >= 0) ? _st.teams[_i] : undefined; }

/// @function csm_teams(state)
/// @description Every team, in entry order (the live array - treat it as read-only).
function csm_teams(_st) { return csm_is_state(_st) ? _st.teams : []; }

/// @function csm_team_count(state)
function csm_team_count(_st) { return csm_is_state(_st) ? array_length(_st.teams) : 0; }

/// @function csm_problems(state)
/// @description Authoring problems found while entering teams or drawing the bracket (never thrown).
function csm_problems(_st) { return csm_is_state(_st) ? _st.problems : []; }

/// @function csm__seed_order(n)
/// @description The classic bracket seed order for a power-of-two field: [1, 8, 5, 4, 3, 6, 7, 2] for 8, so the
/// top seed and the second seed can only meet in the final. Returns 1-based seeds. Internal. Pure.
function csm__seed_order(_n) {
    var _out = [1];
    while (array_length(_out) < _n) {
        var _next = [], _rounds = array_length(_out) * 2;
        for (var _i = 0; _i < array_length(_out); _i++) { array_push(_next, _out[_i]); array_push(_next, _rounds + 1 - _out[_i]); }
        _out = _next;
    }
    return _out;
}

/// @function csm_seed(state)
/// @description Sort the field by rating (highest first) and stamp each team's `seed`, 1 upward. A tie is broken
/// by the team id so the draw is the same on every machine. Returns the seeded array (a copy).
function csm_seed(_st) {
    if (!csm_is_state(_st)) return [];
    var _n = array_length(_st.teams), _order = array_create(_n);
    for (var _i = 0; _i < _n; _i++) _order[_i] = _st.teams[_i];
    // insertion sort: the field is small and this keeps the tie-break explicit and stable
    for (var _i = 1; _i < _n; _i++) {
        var _t = _order[_i], _j = _i - 1;
        while (_j >= 0 && (_order[_j].rating < _t.rating || (_order[_j].rating == _t.rating && _order[_j].id > _t.id))) { _order[_j + 1] = _order[_j]; _j--; }
        _order[_j + 1] = _t;
    }
    for (var _i = 0; _i < _n; _i++) _order[_i].seed = _i + 1;
    return _order;
}

/// @function csm_start(state, format)
/// @description Draw the bracket. `format` is "single" (single elimination, the field padded to a power of two
/// with byes) or "league" (every team plays every other once). Returns true when it drew. Refuses a second draw
/// and a field of fewer than two teams, reporting both in `.problems`.
function csm_start(_st, _format) {
    if (!csm_is_state(_st)) return false;
    if (_st.record.started) { array_push(_st.problems, "the bracket was already drawn"); return false; }
    var _n = array_length(_st.teams);
    if (_n < 2) { array_push(_st.problems, "a tournament needs at least two teams, got " + string(_n)); return false; }
    if (!is_string(_format) || (_format != "single" && _format != "league")) _format = "single";
    var _seeded = csm_seed(_st);
    _st.record.format = _format;
    _st.record.matches = [];
    if (_format == "league") {
        // circle method: every team meets every other exactly once
        var _r = 1, _idx = 0;
        for (var _a = 0; _a < _n; _a++) for (var _b = _a + 1; _b < _n; _b++) {
            array_push(_st.record.matches, csm__match("m" + string(_idx), 1 + floor(_idx / max(1, floor(_n / 2))), _idx, _seeded[_a].id, _seeded[_b].id));
            _idx++;
        }
        _st.record.rounds = (array_length(_st.record.matches) > 0) ? _st.record.matches[array_length(_st.record.matches) - 1].round : 1;
    } else {
        var _size = 2;
        while (_size < _n) _size *= 2;
        var _order = csm__seed_order(_size), _slots = array_create(_size, "");
        for (var _i = 0; _i < _size; _i++) { var _s = _order[_i]; _slots[_i] = (_s <= _n) ? _seeded[_s - 1].id : ""; }
        var _idx = 0;
        for (var _i = 0; _i < _size; _i += 2) { array_push(_st.record.matches, csm__match("m" + string(_idx), 1, _idx, _slots[_i], _slots[_i + 1])); _idx++; }
        var _round = 1, _count = _size / 2;
        while (_count > 1) {
            _count = _count / 2; _round++;
            for (var _i = 0; _i < _count; _i++) { array_push(_st.record.matches, csm__match("m" + string(_idx), _round, _i, "", "")); _idx++; }
        }
        _st.record.rounds = _round;
        // a first-round bye is resolved immediately, so the chart never shows a team playing nobody
        for (var _i = 0; _i < array_length(_st.record.matches); _i++) {
            var _m = _st.record.matches[_i];
            if (_m.round != 1) continue;
            if (_m.a != "" && _m.b == "") csm__advance(_st, _m, _m.a, true);
            else if (_m.a == "" && _m.b != "") csm__advance(_st, _m, _m.b, true);
        }
    }
    _st.record.started = true;
    return true;
}

/// @function csm__match(id, round, slot, a, b)
/// @description One match record. Internal.
function csm__match(_id, _round, _slot, _a, _b) {
    return { id: _id, round: _round, slot: _slot, a: _a, b: _b, winner: "", loser: "", drawn: false, score_a: 0, score_b: 0, played: false, bye: false };
}

/// @function csm_matches(state)
/// @description Every match, in draw order (the live array - treat it as read-only).
function csm_matches(_st) { return csm_is_state(_st) ? _st.record.matches : []; }

/// @function csm_match(state, id)
/// @description One match record, or undefined.
function csm_match(_st, _id) { if (!csm_is_state(_st)) return undefined; var _i = csm__find(_st.record.matches, _id); return (_i >= 0) ? _st.record.matches[_i] : undefined; }

/// @function csm_next_match(state)
/// @description The next match that can be played: both places filled and not yet played. undefined when the
/// tournament is waiting on an earlier result or is over.
function csm_next_match(_st) {
    if (!csm_is_state(_st)) return undefined;
    var _M = _st.record.matches;
    for (var _i = 0; _i < array_length(_M); _i++) { var _m = _M[_i]; if (!_m.played && _m.a != "" && _m.b != "") return _m; }
    return undefined;
}

/// @function csm__advance(state, match, winner_id, is_bye)
/// @description Settle a match and carry the winner into the next round of a single-elimination draw. Internal.
function csm__advance(_st, _m, _win, _bye) {
    _m.played = true; _m.bye = _bye; _m.winner = _win;
    _m.loser = (_m.a == _win) ? _m.b : _m.a;
    if (_st.record.format != "single") return;
    var _next_round = _m.round + 1;
    if (_next_round > _st.record.rounds) { _st.record.champion = _win; return; }
    var _target = floor(_m.slot / 2), _M = _st.record.matches;
    for (var _i = 0; _i < array_length(_M); _i++) {
        var _c = _M[_i];
        if (_c.round != _next_round || _c.slot != _target) continue;
        if (_m.slot mod 2 == 0) _c.a = _win; else _c.b = _win;
        // a bye that meets an empty place carries straight on
        if (_c.a != "" && _c.b == "" && _bye) { }
        break;
    }
}

/// @function csm_report(state, match_id, winner_id, [score_a], [score_b])
/// @description Report what YOUR game decided: who won a match, and optionally the score. Pass "" as the winner
/// in a league to record a draw. Losers are marked out in an elimination draw, survivors count a round, and the
/// winner is carried into the next round. Returns true when the result was recorded.
function csm_report(_st, _mid, _win, _sa = 0, _sb = 0) {
    if (!csm_is_state(_st)) return false;
    var _m = csm_match(_st, _mid);
    if (_m == undefined || _m.played) return false;
    if (_m.a == "" || _m.b == "") return false;
    var _is_draw = (_win == "" || _win == undefined);
    if (!_is_draw && _win != _m.a && _win != _m.b) return false;
    _m.score_a = csm_num(_sa, 0); _m.score_b = csm_num(_sb, 0);
    var _ta = csm_team(_st, _m.a), _tb = csm_team(_st, _m.b);
    if (_is_draw && _st.record.format == "league") {
        _m.played = true; _m.drawn = true;
        if (is_struct(_ta)) { _ta.draws++; _ta.points += _st.cfg.points_draw; _ta.rounds_survived++; }
        if (is_struct(_tb)) { _tb.draws++; _tb.points += _st.cfg.points_draw; _tb.rounds_survived++; }
        array_push(_st.record.history, { match: _m.id, winner: "", drawn: true });
        csm__level(_st);
        return true;
    }
    if (_is_draw) return false;
    csm__advance(_st, _m, _win, false);
    var _tw = csm_team(_st, _m.winner), _tl = csm_team(_st, _m.loser);
    if (is_struct(_tw)) { _tw.wins++; _tw.points += _st.cfg.points_win; _tw.rounds_survived++; }
    if (is_struct(_tl)) { _tl.losses++; if (_st.record.format == "single") _tl.out = true; }
    array_push(_st.record.history, { match: _m.id, winner: _m.winner, drawn: false });
    if (_st.record.format == "league" && csm_next_match(_st) == undefined) {
        var _table = csm_standings(_st);
        if (array_length(_table) > 0) _st.record.champion = _table[0].id;
    }
    csm__level(_st);
    return true;
}

/// @function csm__level(state)
/// @description Rivals that keep surviving get stronger: every `rounds_to_level` rounds a team survives, it gains
/// `level_gain` levels and a little rating. Internal - this is what makes a later round feel later.
function csm__level(_st) {
    for (var _i = 0; _i < array_length(_st.teams); _i++) {
        var _t = _st.teams[_i];
        if (_t.out) continue;
        var _want = 1 + floor(_t.rounds_survived / _st.cfg.rounds_to_level) * _st.cfg.level_gain;
        if (_want > _t.level) { _t.rating = clamp(_t.rating + (_want - _t.level) * 2, 0, 1000); _t.level = _want; }
    }
}

/// @function csm_standings(state)
/// @description The table, best first: points, then wins, then fewer losses, then the id so it is the same on
/// every machine. Returns an array of the team records (a new array, the same structs).
function csm_standings(_st) {
    if (!csm_is_state(_st)) return [];
    var _n = array_length(_st.teams), _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) _out[_i] = _st.teams[_i];
    for (var _i = 1; _i < _n; _i++) {
        var _t = _out[_i], _j = _i - 1;
        while (_j >= 0 && csm__ranks_below(_out[_j], _t)) { _out[_j + 1] = _out[_j]; _j--; }
        _out[_j + 1] = _t;
    }
    return _out;
}

/// @function csm__ranks_below(a, b)
/// @description True when `a` should sit BELOW `b` in the table. Internal. Pure.
function csm__ranks_below(_a, _b) {
    if (_a.points != _b.points) return _a.points < _b.points;
    if (_a.wins != _b.wins) return _a.wins < _b.wins;
    if (_a.losses != _b.losses) return _a.losses > _b.losses;
    return _a.id > _b.id;
}

/// @function csm_champion(state)
/// @description The winner's team id once the tournament is decided, else "".
function csm_champion(_st) { return csm_is_state(_st) ? _st.record.champion : ""; }

/// @function csm_is_over(state)
/// @description True once every match that can be played has been played.
function csm_is_over(_st) { return csm_is_state(_st) && _st.record.started && csm_next_match(_st) == undefined; }

/// @function csm_round_of(state, round)
/// @description Every match in one round, in slot order.
function csm_round_of(_st, _round) {
    var _out = [];
    if (!csm_is_state(_st)) return _out;
    _round = floor(csm_num(_round, 0));
    var _M = _st.record.matches;
    for (var _i = 0; _i < array_length(_M); _i++) if (_M[_i].round == _round) array_push(_out, _M[_i]);
    return _out;
}

/// @function csm_round_name(state, round)
/// @description What a round is called in an elimination draw: "Final", "Semi-final", "Quarter-final", else
/// "Round N". A league round is always "Round N". Pure enough to caption a board with.
function csm_round_name(_st, _round) {
    if (!csm_is_state(_st)) return "";
    _round = floor(csm_num(_round, 0));
    if (_st.record.format != "single") return "Round " + string(_round);
    var _from_end = _st.record.rounds - _round;
    if (_from_end == 0) return "Final";
    if (_from_end == 1) return "Semi-final";
    if (_from_end == 2) return "Quarter-final";
    return "Round " + string(_round);
}

/// @function csm_standard_from_key(key, [level])
/// @description The standard a KEY carries, as indices the board draws: { key, family, charge, division, tincture,
/// metal, ordinary, level }. Every index is hashed from the key on its own independent stream, so no two of them
/// drift together and no two keys collapse onto the same arms. Pure.
///
/// This takes a bare string rather than a team on purpose: a standard is worth drawing for a guild, a town, a
/// house or a player's chosen name, none of which is a tournament entrant. csm_standard is the tournament-shaped
/// wrapper around it.
function csm_standard_from_key(_k, _level = 1) {
    if (!is_string(_k)) _k = string(_k);
    return {
        key: _k,
        family: csm_pick(_k, "family", CSM_STANDARD_FAMILIES),
        charge: csm_pick(_k, "charge", CSM_STANDARD_CHARGES),
        division: csm_pick(_k, "division", CSM_STANDARD_DIVISIONS),
        tincture: csm_pick(_k, "tincture", CSM_STANDARD_TINCTURES),
        metal: csm_pick(_k, "metal", 2),
        ordinary: csm_pick(_k, "ordinary", CSM_STANDARD_ORDINARIES),
        level: clamp(floor(csm_num(_level, 1)), 1, 999)
    };
}

/// @function csm_standard(state, team_id)
/// @description The standard a team carries. The key is the team's `colour_key`, which defaults to its id, so an
/// author can pin a rival's arms by setting it and change the rival's name freely. undefined for an unknown team.
function csm_standard(_st, _id) {
    var _t = csm_team(_st, _id);
    if (_t == undefined) return undefined;
    return csm_standard_from_key(_t.colour_key, _t.level);
}

// ⛔ `csm_standard_families()` USED TO LIVE HERE and returned ["iron","blood","verdant","azure","sable","gilt"].
// It was written in session 1, when a standard's `family` was going to pick a colour scheme. By the time the
// standard was actually drawn, `family` picks the SILHOUETTE, and the function would have shipped six colour
// names as the labels of six shield shapes - a header describing the code somebody meant to write. The live
// answer is `csm_standard_shapes()` in csm_board, and it is derived from the same index the drawing reads.

/// @function csm_save(state)
/// @description The tournament as a JSON string (teams and the draw both - unlike a story graph, a bracket IS the
/// run). "" on refusal.
function csm_save(_st) {
    if (!csm_is_state(_st)) return "";
    return json_stringify({ v: CSM_SCHEMA, teams: _st.teams, record: _st.record });
}

/// @function csm_load(state, json)
/// @description Install a save from csm_save. Anything unreadable leaves the state untouched and returns false
/// (never a crash).
function csm_load(_st, _s) {
    if (!csm_is_state(_st) || !is_string(_s) || _s == "") return false;
    var _r = undefined;
    try { _r = json_parse(_s); } catch (_e) { return false; }
    if (!is_struct(_r) || !is_array(_r[$ "teams"]) || !is_struct(_r[$ "record"])) return false;
    var _rec = _r.record;
    if (!is_array(_rec[$ "matches"])) return false;
    _st.teams = _r.teams;
    _st.record = _rec;
    return true;
}
