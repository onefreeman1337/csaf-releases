/// hal_selftest.gml - Halation's in-engine test suite. Run the demo with -selftest: the result is written as hal_selftest.json in the game's save
/// folder and the renders (hal_render_*.png) beside it, to be LOOKED at.
/// Stages: the generator; the catalogue (every kit x kind compiles to plain data); colour temperature; the aperture law, read off real pixels; the axis;
/// flicker and envelopes; the world; all five occluder modes against real instances, tiles and surfaces; drawing (ink for every design, state handed back, an
/// opaque surface stays opaque, a batch past GameMaker's vertex limit still draws its far end); the retro kit on its grid; every pair of designs measured apart;
/// resources (the package owns none); timing; then renders.
///
/// Halation - Lens Flares, Glints and Glare for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function hal_st_assert(state, condition, message)
/// @description Count one assertion; keep the first 80 failure messages.
function hal_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 80) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
/// @function hal_st_stage(state, n)
/// @description Record the stage reached (the crash handler reports it).
function hal_st_stage(_st, _n) { _st.stage = _n; global.hal_stage = _n; }

/// @function hal__st_read(surface)
/// @description Internal. A surface read into a buffer (RGBA bytes, the whole surface).
function hal__st_read(_surf) {
    var _w = surface_get_width(_surf), _h = surface_get_height(_surf), _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _surf, 0);
    return { buf: _b, w: _w, h: _h };
}
/// @function hal__st_lum(read, x, y)
/// @description Internal. The sum of the red, green and blue bytes at a pixel.
function hal__st_lum(_rd, _x, _y) {
    var _o = (clamp(floor(_y), 0, _rd.h - 1) * _rd.w + clamp(floor(_x), 0, _rd.w - 1)) * 4;
    return buffer_peek(_rd.buf, _o, buffer_u8) + buffer_peek(_rd.buf, _o + 1, buffer_u8) + buffer_peek(_rd.buf, _o + 2, buffer_u8);
}
/// @function hal__st_ink(read, x0, y0, x1, y1, tol)
/// @description Internal. Pixels (x step 2, y step 1) in a box whose red + green + blue exceeds tol, on a black ground.
function hal__st_ink(_rd, _x0, _y0, _x1, _y1, _tol) {
    var _n = 0;
    for (var _y = max(0, floor(_y0)); _y < min(_rd.h, _y1); _y++) for (var _x = max(0, floor(_x0)); _x < min(_rd.w, _x1); _x += 2) {
        var _o = (_y * _rd.w + _x) * 4;
        if (buffer_peek(_rd.buf, _o, buffer_u8) + buffer_peek(_rd.buf, _o + 1, buffer_u8) + buffer_peek(_rd.buf, _o + 2, buffer_u8) > _tol) _n++;
    }
    return _n;
}
/// @function hal__st_black(surface)
/// @description Internal. Set the target to this surface, cleared to opaque black.
function hal__st_black(_sf) { surface_set_target(_sf); draw_clear_alpha(c_black, 1); }

/// @function hal__st_plain(value, depth)
/// @description Internal. Is this value only numbers, strings, booleans, arrays and structs? A design must hold no resource handle.
function hal__st_plain(_v, _d) {
    if (_d > 6) return true;
    if (is_array(_v)) { for (var _i = 0; _i < array_length(_v); _i++) if (!hal__st_plain(_v[_i], _d + 1)) return false; return true; }
    if (is_struct(_v)) { var _ks = variable_struct_get_names(_v); for (var _i = 0; _i < array_length(_ks); _i++) if (!hal__st_plain(_v[$ _ks[_i]], _d + 1)) return false; return true; }
    return is_real(_v) || is_string(_v) || is_bool(_v) || is_int32(_v) || is_int64(_v);
}

/// @function hal__st_arcs(read, cx, cy, r, tol)
/// @description Internal. Walk a circle and count the separate bright arcs: how many spikes cross it.
function hal__st_arcs(_rd, _cx, _cy, _r, _tol) {
    var _n = 720, _prev = false, _first = false, _count = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _i * 2 * pi / _n, _on = hal__st_lum(_rd, _cx + cos(_a) * _r, _cy + sin(_a) * _r) > _tol;
        if (_i == 0) _first = _on;
        if (_on && !_prev && _i > 0) _count++;
        _prev = _on;
    }
    if (_first && !_prev) _count++;
    return _count;
}

/// @function hal_selftest_run()
/// @description Run every stage; returns the state written by hal_selftest_write.
function hal_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, failures: [], stage: 0, notes: {}, timings: {} };
    _st.notes.epsilon = string_format(math_get_epsilon(), 1, 12);

    // ------------------------------------------------------------ 10: the generator
    hal_st_stage(_st, 10);
    var _g1 = hal_rng(42), _g2 = hal_rng(42), _same = true;
    repeat (50) if (hal_rand(_g1) != hal_rand(_g2)) _same = false;
    hal_st_assert(_st, _same, "the same seed draws the same sequence");
    var _lo = 1, _hi = 0;
    for (var _s = 0; _s < 400; _s++) { var _v = hal_rand(hal_rng(1000 + _s)); _lo = min(_lo, _v); _hi = max(_hi, _v); }
    hal_st_assert(_st, _lo < 0.05 && _hi > 0.95, "first draws over 400 NEARBY seeds span [0,1): " + string(_lo) + ".." + string(_hi));
    hal_st_assert(_st, hal_rand(undefined) == 0 && hal_rand({}) == 0, "a non-generator draws 0 and does not throw");

    // ------------------------------------------------------------ 20: the catalogue
    hal_st_stage(_st, 20);
    var _kits = hal_kits(), _kinds = hal_kinds();
    hal_st_assert(_st, array_length(_kits) == 8, "eight lens kits (" + string(array_length(_kits)) + ")");
    hal_st_assert(_st, array_length(_kinds) == 10, "ten light kinds (" + string(array_length(_kinds)) + ")");
    _st.notes.kits = array_length(_kits); _st.notes.kinds = array_length(_kinds); _st.notes.designs = array_length(_kits) * array_length(_kinds);
    for (var _i = 0; _i < array_length(_kits); _i++) hal_st_assert(_st, string_length(hal_kit_title(_kits[_i])) > 3 && string_length(hal_kit_line(_kits[_i])) > 20, _kits[_i] + ": a title and a line");
    for (var _i = 0; _i < array_length(_kinds); _i++) hal_st_assert(_st, string_length(hal_kind_title(_kinds[_i])) > 2, _kinds[_i] + ": a title");
    hal_st_assert(_st, hal_kit_title("teapot") == "" && hal_kit_line(12) == "" && hal_kind_title("teapot") == "", "a name that is not a kit or a kind has no title");
    var _plainBad = 0, _emptyBad = 0;
    for (var _a = 0; _a < array_length(_kits); _a++) for (var _b = 0; _b < array_length(_kinds); _b++) {
        var _D = hal_design(_kits[_a], _kinds[_b]);
        if (!is_struct(_D) || _D.n < 2) _emptyBad++;
        if (!hal__st_plain(_D, 0)) _plainBad++;
    }
    hal_st_assert(_st, _emptyBad == 0, "all 80 designs compile to at least two elements (" + string(_emptyBad) + " did not)");
    hal_st_assert(_st, _plainBad == 0, "a design is plain data: no resource handle anywhere (" + string(_plainBad) + " held one)");
    hal_st_assert(_st, hal_design("vintage", "sun") == hal_design("vintage", "sun"), "a design is cached");
    hal_st_assert(_st, is_undefined(hal_design("teapot", "sun")) && is_undefined(hal_design("vintage", "teapot")) && is_undefined(hal_design(4096, undefined)), "bad names compile to undefined, never a crash");
    // the cache has a ceiling: a colour animated every frame cannot grow it without bound
    for (var _i = 0; _i < 600; _i++) hal_design("vintage", "orb", { colour: _i });
    hal_st_assert(_st, global.hal_t_design_count <= 512, "the design cache holds at most 512 designs (" + string(global.hal_t_design_count) + ")");
    // a kit you define
    hal_st_assert(_st, hal_kit_define("st_seven", "vintage", { blades: 7, coat: [c_red, c_lime], core: { g: 0.5 } }), "hal_kit_define takes a base and overrides");
    hal_st_assert(_st, global.hal_t_kits[$ "st_seven"].core.g == 0.5 && global.hal_t_kits[$ "st_seven"].core.s == global.hal_t_kits[$ "vintage"].core.s, "a struct field merges: core.g replaced, core.s inherited");
    hal_st_assert(_st, hal_design_stats("st_seven", "sun").spikes == 14, "a seven-blade lens you define gives fourteen spikes");
    hal_st_assert(_st, !hal_kit_define(4096, "vintage", {}) && !hal_kit_define("x", "teapot", {}), "hal_kit_define refuses a bad name or a bad base");
    array_delete(global.hal_t_kit_order, array_length(global.hal_t_kit_order) - 1, 1);
    struct_remove(global.hal_t_kits, "st_seven");
    hal_st_assert(_st, array_length(hal_kits()) == 8, "the catalogue is back to eight");

    // ------------------------------------------------------------ 25: colour temperature
    hal_st_stage(_st, 25);
    hal_st_assert(_st, #FF0000 == c_red && #0000FF == c_blue, "the colour literals read as written (red and blue)");
    var _prev = -1, _mono = true;
    for (var _k = 1500; _k <= 12000; _k += 500) { var _c = hal_kelvin(_k), _rb = colour_get_blue(_c) / max(colour_get_red(_c), 1); if (_rb < _prev - 0.0001) _mono = false; _prev = _rb; }
    hal_st_assert(_st, _mono, "blue over red rises with temperature, 1500 K to 12000 K");
    var _t1 = hal_kelvin(1850), _t2 = hal_kelvin(6600), _t3 = hal_kelvin(9000);
    hal_st_assert(_st, colour_get_red(_t1) > colour_get_blue(_t1) + 150, "a torch at 1850 K is orange (" + string(colour_get_red(_t1)) + ", " + string(colour_get_blue(_t1)) + ")");
    hal_st_assert(_st, abs(colour_get_red(_t2) - colour_get_blue(_t2)) < 12, "6600 K is near white");
    hal_st_assert(_st, colour_get_blue(_t3) > colour_get_red(_t3) + 20, "9000 K is cold");
    hal_st_assert(_st, hal_kelvin("hot") == hal_kelvin(5600) && hal_kelvin(undefined) == hal_kelvin(5600), "a bad temperature falls back to daylight");

    // ------------------------------------------------------------ 30: the aperture law, in numbers and in pixels
    hal_st_stage(_st, 30);
    hal_st_assert(_st, hal__spike_count(5) == 10 && hal__spike_count(6) == 6 && hal__spike_count(7) == 14 && hal__spike_count(8) == 8 && hal__spike_count(9) == 18 && hal__spike_count(0) == 0, "odd blades give twice their count in spikes, even blades their count");
    for (var _b = 5; _b <= 9; _b++) for (var _r = 0; _r < 2; _r++) {
        var _P = hal__poly(_b, _r * 0.3, 11), _pos = 0, _neg = 0;
        for (var _i = 0; _i < _P.n; _i++) {
            var _j = (_i + 1) mod _P.n, _m = (_i + 2) mod _P.n;
            var _cr = (_P.xs[_j] - _P.xs[_i]) * (_P.ys[_m] - _P.ys[_j]) - (_P.ys[_j] - _P.ys[_i]) * (_P.xs[_m] - _P.xs[_j]);
            if (_cr > 0.0001) _pos++; else if (_cr < -0.0001) _neg++;
        }
        hal_st_assert(_st, (_pos == 0 || _neg == 0) && (_pos + _neg) >= _b, string(_b) + " blades, round " + string(_r * 0.3) + ": the ghost outline is convex, so a fan fills it");
    }
    var _sf = surface_create(540, 540);
    var _lawKits = ["st_b5", "st_b6", "st_b7", "st_b8", "st_b9"], _lawCounts = [10, 6, 14, 8, 18];
    for (var _i = 0; _i < 5; _i++) {
        hal_kit_define(_lawKits[_i], "vintage", { blades: 5 + _i, rot: 0, ghosts: [], rings: [], streaks: [], bloom: { g: 0 }, core: { g: 0 }, veil: { g: 0 }, dirt: { g: 0 }, spike: { g: 1, len: 0.46, w: 0.006, count: 0, jit: 0 } });
        hal__st_black(_sf);
        hal_flare_draw(_lawKits[_i], "sun", 270, 270, 1, { fx: 0, fy: 0, fw: 540, fh: 540 });
        surface_reset_target();
        var _rd = hal__st_read(_sf), _arcs = hal__st_arcs(_rd, 270, 270, 60, 60);
        buffer_delete(_rd.buf);
        hal_st_assert(_st, _arcs == _lawCounts[_i], string(5 + _i) + " blades draw " + string(_lawCounts[_i]) + " spikes on the screen (counted " + string(_arcs) + " bright arcs round the source)");
    }

    // ------------------------------------------------------------ 35: the axis, and a ghost on it
    hal_st_stage(_st, 35);
    var _p0 = hal_axis_point(100, 80, 0, 0, 0, 960, 540), _p1 = hal_axis_point(100, 80, 1, 0, 0, 960, 540), _p2 = hal_axis_point(100, 80, 2, 0, 0, 960, 540);
    hal_st_assert(_st, _p0.x == 100 && _p0.y == 80, "t 0 is the light");
    hal_st_assert(_st, _p1.x == 480 && _p1.y == 270, "t 1 is the frame's centre");
    hal_st_assert(_st, _p2.x == 860 && _p2.y == 460, "t 2 is the mirror point");
    var _sa = surface_create(960, 540);
    hal_kit_define("st_ghost", "vintage", { ghosts: [[1.5, 0.05, 1, 0, 2]], rings: [], streaks: [], spike: { g: 0 }, bloom: { g: 0 }, core: { g: 0 }, veil: { g: 0 }, dirt: { g: 0 } });
    hal__st_black(_sa);
    hal_flare_draw("st_ghost", "sun", 200, 120, 1, { fx: 0, fy: 0, fw: 960, fh: 540 });
    surface_reset_target();
    var _rd = hal__st_read(_sa), _pa = hal_axis_point(200, 120, 1.5, 0, 0, 960, 540);
    hal_st_assert(_st, hal__st_lum(_rd, _pa.x, _pa.y) > 120, "a ghost at t 1.5 draws at its point on the axis (" + string(hal__st_lum(_rd, _pa.x, _pa.y)) + ")");
    hal_st_assert(_st, hal__st_lum(_rd, 200, 120) < 3 && hal__st_lum(_rd, 480, 270) < 3, "and nowhere else: dark at the light and at the frame's centre");
    buffer_delete(_rd.buf);
    // moved with the source: ghosts collapse as the source reaches the frame's centre
    hal__st_black(_sa);
    hal_flare_draw("st_ghost", "sun", 480, 270, 1, { fx: 0, fy: 0, fw: 960, fh: 540 });
    surface_reset_target();
    _rd = hal__st_read(_sa);
    hal_st_assert(_st, hal__st_ink(_rd, 0, 0, 960, 540, 6) == 0, "a source at the frame's centre has no ghost (they collapse into it)");
    buffer_delete(_rd.buf);
    // a source far outside the frame draws nothing at all, one just outside still scatters in
    hal__st_black(_sa);
    hal_flare_draw("vintage", "sun", -2000, 270, 1, { fx: 0, fy: 0, fw: 960, fh: 540 });
    surface_reset_target();
    _rd = hal__st_read(_sa);
    hal_st_assert(_st, hal__st_ink(_rd, 0, 0, 960, 540, 6) == 0, "a source far off the frame draws nothing");
    buffer_delete(_rd.buf);
    hal__st_black(_sa);
    hal_flare_draw("vintage", "sun", -60, 270, 1, { fx: 0, fy: 0, fw: 960, fh: 540 });
    surface_reset_target();
    _rd = hal__st_read(_sa);
    hal_st_assert(_st, hal__st_ink(_rd, 0, 0, 960, 540, 6) > 2000, "a source just off the frame still scatters into it");
    buffer_delete(_rd.buf);

    // ------------------------------------------------------------ 40: flicker and envelopes
    hal_st_stage(_st, 40);
    var _modes = ["none", "flame", "breathe", "hum", "pulse", "twinkle"];
    for (var _m = 0; _m < array_length(_modes); _m++) {
        var _mn = 10, _mx = -10, _ok = true;
        for (var _i = 0; _i < 600; _i++) {
            var _t = _i * 0.0167, _f = hal__flicker(_modes[_m], _t, 1.7, 0.3);
            if (_f != hal__flicker(_modes[_m], _t, 1.7, 0.3)) _ok = false;
            _mn = min(_mn, _f); _mx = max(_mx, _f);
        }
        hal_st_assert(_st, _ok && _mn >= 0 && _mx <= 1.0001, _modes[_m] + ": repeatable and inside 0..1 (" + string(_mn) + ".." + string(_mx) + ")");
        if (_modes[_m] == "none") hal_st_assert(_st, _mn == 1 && _mx == 1, "none does not move");
        else hal_st_assert(_st, _mx - _mn > 0.05, _modes[_m] + " moves (" + string(_mx - _mn) + ")");
    }
    hal_st_assert(_st, hal__flicker("teapot", 1, 1, 1) == 1, "an unknown flicker is steady");
    hal_st_assert(_st, hal__env(0, 0.01, 0.1) == 0 && abs(hal__env(0.01, 0.01, 0.1) - 1) < 0.0001 && hal__env(0.11, 0.01, 0.1) == 0 && hal__env(0.5, 0.01, 0.1) == 0, "an envelope rises from 0 to 1 and ends at exactly 0");
    var _decr = true, _pe = 1;
    for (var _a = 0.01; _a <= 0.11; _a += 0.002) { var _e = hal__env(_a, 0.01, 0.1); if (_e > _pe + 0.0001) _decr = false; _pe = _e; }
    hal_st_assert(_st, _decr, "and only falls after its peak");
    var _v = 0;
    repeat (120) _v = hal__vis_step(_v, 1, 1 / 60, 0.06, 0.14);
    hal_st_assert(_st, _v > 0.99 && _v <= 1, "visibility opens to its target (" + string(_v) + ")");
    var _v1 = hal__vis_step(1, 0, 1 / 60, 0.06, 0.14), _v2 = hal__vis_step(0, 1, 1 / 60, 0.06, 0.14);
    hal_st_assert(_st, _v2 > (1 - _v1), "opening is quicker than closing at the default rates (" + string(_v2) + " against " + string(1 - _v1) + ")");
    hal_st_assert(_st, hal__vis_step(0.4, 1, 0, 0.06, 0.14) == 0.4 && hal__vis_step(0.4, 1, 0.1, 0, 0) == 1, "no time moves nothing; a zero rate snaps");

    // ------------------------------------------------------------ 50: the world
    hal_st_stage(_st, 50);
    var _W = hal_world_create({ kit: "dream" });
    hal_st_assert(_st, _W.kit == "dream" && hal_world_count(_W) == 0, "a world starts empty, on its kit");
    hal_st_assert(_st, hal_world_create({ kit: "teapot" }).kit == "vintage", "a bad kit falls back to the first");
    var _L = hal_light_add(_W, "torch", 10, 20);
    hal_st_assert(_st, hal__is_light(_L) && hal_world_count(_W) == 1 && hal_light_exists(_W, _L), "a light is added");
    hal_st_assert(_st, is_undefined(hal_light_add(_W, "teapot", 0, 0)) && is_undefined(hal_light_add(undefined, "torch", 0, 0)), "a bad kind or world is refused");
    hal_light_move(_L, 50, 60);
    hal_st_assert(_st, _L.x == 50 && _L.y == 60, "hal_light_move");
    hal_st_assert(_st, !hal_light_move(undefined, 0, 0) && !hal_light_set(undefined, {}) && hal_light_visibility(undefined) == 0, "light calls refuse what is not a light");
    hal_world_step(_W, 1 / 60);
    var _D0 = hal__light_design(_W, _L);
    hal_st_assert(_st, _D0.kit == "dream", "a light looks through its world's kit");
    hal_world_set_kit(_W, "pixel");
    hal_st_assert(_st, hal__light_design(_W, _L).kit == "pixel", "changing the world's kit changes the light's design");
    hal_light_set(_L, { kit: "telescope" });
    hal_st_assert(_st, hal__light_design(_W, _L).kit == "telescope", "a light's own kit wins");
    hal_light_set(_L, { colour: c_lime });
    hal_st_assert(_st, hal__light_design(_W, _L).lc == c_lime, "hal_light_set changes its colour");
    var _F = hal_flash(_W, "muzzle", 100, 100);
    hal_st_assert(_st, _F.once && hal_world_count(_W) == 2, "a flash is a light that will retire");
    var _peak = 0, _life = 0;
    repeat (60) { hal_world_step(_W, 1 / 60); if (hal_light_exists(_W, _F)) { _life += 1 / 60; _peak = max(_peak, _F.env); } }
    hal_st_assert(_st, !hal_light_exists(_W, _F) && _peak > 0.6, "a muzzle flash peaks (" + string(_peak) + ") and retires itself");
    hal_st_assert(_st, _life < 0.15, "and is gone in under 0.15 s (" + string(_life) + ")");
    var _E = hal_flash(_W, "explosion", 100, 100); repeat (30) hal_world_step(_W, 1 / 60);
    hal_st_assert(_st, hal_light_exists(_W, _E), "an explosion is still burning after half a second");
    repeat (30) hal_world_step(_W, 1 / 60);
    hal_st_assert(_st, !hal_light_exists(_W, _E), "and has retired after a second");
    var _Fc = hal_flash(_W, "lantern", 1, 1, { attack: 0.01, decay: 0.05 }); repeat (6) hal_world_step(_W, 1 / 60);
    hal_st_assert(_st, !hal_light_exists(_W, _Fc), "any kind can flash, with its own timing");
    hal_world_pause(_W, true);
    var _tp = _W.t; hal_world_step(_W, 0.03);
    hal_st_assert(_st, _W.t == _tp, "hal_world_pause holds time");
    hal_world_pause(_W, false);
    var _inst = instance_create_depth(321, 123, 0, obj_hal_wall), _Lf = hal_light_add(_W, "orb", 0, 0, { follow: _inst });
    hal_world_step(_W, 1 / 60);
    hal_st_assert(_st, _Lf.x == 321 && _Lf.y == 123, "a light follows its instance");
    instance_destroy(_inst);
    hal_world_step(_W, 1 / 60);
    hal_st_assert(_st, !hal_light_exists(_W, _Lf), "and retires with it");
    hal_st_assert(_st, hal_light_remove(_W, _L) && !hal_light_remove(_W, _L), "hal_light_remove removes once");
    hal_glint(_W, 10, 10); hal_glint_along(_W, 0, 0, 100, 0, { life: 0.2 });
    hal_st_assert(_st, array_length(_W.glints) == 2, "glints queue");
    repeat (60) hal_world_step(_W, 1 / 60);
    hal_st_assert(_st, array_length(_W.glints) == 0, "and retire");
    hal_light_add(_W, "sun", 0, 0); hal_world_clear(_W);
    hal_st_assert(_st, hal_world_count(_W) == 0, "hal_world_clear");
    hal_st_assert(_st, !hal_world_step(undefined) && !hal_world_draw(undefined) && hal_world_count(4096) == 0 && !hal_world_set_kit(undefined, "dream") && !hal_world_set_kit(_W, "teapot"), "world calls refuse what is not a world");

    // ------------------------------------------------------------ 60: occlusion, every mode, against the real thing
    hal_st_stage(_st, 60);
    var _settle = function(_w) { repeat (90) hal_world_step(_w, 1 / 60); };
    // objects
    var _block = instance_create_depth(200, 100, 0, obj_hal_wall);
    _block.image_xscale = 2; _block.image_yscale = 3;   // 128 x 96 px
    hal_st_assert(_st, _block.bbox_left <= 200 && _block.bbox_right >= 327 && _block.bbox_bottom >= 195, "fixture: the block's box covers 200..328 x 100..196 (" + string(_block.bbox_right) + ", " + string(_block.bbox_bottom) + ")");
    var _Wo = hal_world_create({ occluder: { mode: "objects", objects: obj_hal_wall } }), _Lo = hal_light_add(_Wo, "torch", 260, 150, { radius: 6 });
    _settle(_Wo); hal_st_assert(_st, hal_light_visibility(_Lo) < 0.01, "objects: a light behind a block goes dark (" + string(hal_light_visibility(_Lo)) + ")");
    hal_light_move(_Lo, 600, 400); _settle(_Wo); hal_st_assert(_st, hal_light_visibility(_Lo) > 0.99, "objects: clear of it, it comes back");
    hal_light_move(_Lo, 200, 150); hal_light_set(_Lo, { radius: 30 }); _settle(_Wo);
    var _half = hal_light_visibility(_Lo);
    hal_st_assert(_st, _half > 0.2 && _half < 0.8, "objects: half behind the block's edge, half its light (" + string(_half) + ")");
    var _vv = 1, _monoV = true; hal_light_move(_Lo, 260, 150);
    repeat (30) { hal_world_step(_Wo, 1 / 60); if (hal_light_visibility(_Lo) > _vv + 0.0001) _monoV = false; _vv = hal_light_visibility(_Lo); }
    hal_st_assert(_st, _monoV && _vv < 0.2, "objects: passing behind fades smoothly, it does not pop");
    // a light in front of the walls
    var _Lfw = hal_light_add(_Wo, "torch", 260, 150, { radius: 6, occlude: false });
    _settle(_Wo); hal_st_assert(_st, hal_light_visibility(_Lfw) > 0.99, "occlude false: a light in front of the block stays lit");
    hal_light_set(_Lfw, { occlude: true }); _settle(_Wo); hal_st_assert(_st, hal_light_visibility(_Lfw) < 0.01, "and hal_light_set can put it behind again");
    hal_light_remove(_Wo, _Lfw);
    var _Ffw = hal_flash(_Wo, "muzzle", 260, 150, { occlude: false });
    hal_st_assert(_st, hal_light_visibility(_Ffw) == 1, "a flash in front of the wall opens fully");
    // the flash opens at what it can see
    var _Fo = hal_flash(_Wo, "muzzle", 260, 150);
    hal_st_assert(_st, hal_light_visibility(_Fo) == 0, "a flash behind a wall starts dark");
    // tiles: a real tile layer, by id and by name
    var _tl = layer_create(50, "hal_st_tiles"), _tm = layer_tilemap_create(_tl, 0, 0, ts_hal_mark, 30, 20);
    for (var _j = 3; _j < 6; _j++) for (var _i = 6; _i < 10; _i++) tilemap_set(_tm, 1, _i, _j);   // 192..320 x 96..192
    var _Wt = hal_world_create({ occluder: { mode: "tiles", tilemaps: _tm } }), _Lt = hal_light_add(_Wt, "torch", 256, 144, { radius: 6 });
    _settle(_Wt); hal_st_assert(_st, hal_light_visibility(_Lt) < 0.01, "tiles: a light behind tiles goes dark");
    hal_light_move(_Lt, 600, 400); _settle(_Wt); hal_st_assert(_st, hal_light_visibility(_Lt) > 0.99, "tiles: over empty cells, it comes back");
    var _Wt2 = hal_world_create({ occluder: { mode: "tiles", tilemaps: "hal_st_tiles" } }), _Lt2 = hal_light_add(_Wt2, "torch", 256, 144, { radius: 6 });
    _settle(_Wt2); hal_st_assert(_st, hal_light_visibility(_Lt2) < 0.01, "tiles: a layer given by name works too");
    hal_st_assert(_st, is_undefined(hal__occluder({ mode: "tiles", tilemaps: "no_such_layer" }, self)), "tiles: a layer that does not exist is refused");
    // mask: a surface the buyer draws, read through its alpha
    var _ms = surface_create(320, 180);
    surface_set_target(_ms); draw_clear_alpha(c_black, 0); draw_set_colour(c_white); draw_rectangle(40, 30, 120, 90, false); surface_reset_target();
    var _Wm = hal_world_create({ occluder: { mode: "mask", surface: _ms, scale: 0.5 } }), _Lm = hal_light_add(_Wm, "torch", 160, 120, { radius: 4 });
    _settle(_Wm); hal_st_assert(_st, hal_light_visibility(_Lm) < 0.01, "mask: inside the painted part (scale 0.5), dark (" + string(hal_light_visibility(_Lm)) + ")");
    hal_light_move(_Lm, 500, 300); _settle(_Wm); hal_st_assert(_st, hal_light_visibility(_Lm) > 0.99, "mask: over the transparent part, lit");
    surface_free(_ms);
    hal_light_move(_Lm, 160, 120); hal_world_step(_Wm, 1 / 60);
    hal_st_assert(_st, _Wm.occluder.lost == true, "mask: a lost surface is noted and covers nothing, never a crash");
    // line: a viewer's line of sight
    var _Wl = hal_world_create({ occluder: { mode: "line", objects: obj_hal_wall, from: [50, 150] } }), _Ll = hal_light_add(_Wl, "torch", 500, 150, { radius: 4 });
    _settle(_Wl); hal_st_assert(_st, hal_light_visibility(_Ll) < 0.01, "line: a wall between the viewer and the light blocks it");
    hal_light_move(_Ll, 150, 150); _settle(_Wl); hal_st_assert(_st, hal_light_visibility(_Ll) > 0.99, "line: nothing between, lit");
    // function: a callback written inside the options struct is bound to that struct by GameMaker; it must read the CALLER's variables
    limit_x = 300;
    var _Wf = hal_world_create({ occluder: { mode: "function", fn: function(_x, _y) { return _x < limit_x; } } }), _Lf2 = hal_light_add(_Wf, "torch", 100, 100, { radius: 2 });
    _settle(_Wf); hal_st_assert(_st, hal_light_visibility(_Lf2) < 0.01, "function: a callback reads the caller's own variable");
    limit_x = 50; _settle(_Wf); hal_st_assert(_st, hal_light_visibility(_Lf2) > 0.99, "function: and its answer can change");
    // refusals and overrides
    hal_st_assert(_st, is_undefined(hal__occluder({ mode: "teapot" }, self)) && is_undefined(hal__occluder(12, self)) && is_undefined(hal__occluder({ mode: "objects" }, self)) && is_undefined(hal__occluder({ mode: "line", objects: obj_hal_wall }, self)) && is_undefined(hal__occluder({ mode: "function", fn: 4096 }, self)), "unusable occluder descriptions are refused");
    hal_st_assert(_st, !hal_world_set_occluder(_Wo, { mode: "teapot" }) && hal_world_set_occluder(_Wo, { mode: "objects", objects: obj_hal_wall }), "hal_world_set_occluder answers");
    var _Ls = hal_light_add(_Wo, "sun", 260, 150, { screen: true }); _settle(_Wo);
    hal_st_assert(_st, hal_light_visibility(_Ls) > 0.99, "a screen light ignores the world's occluder");
    hal_world_set_occluder(_Wo, undefined); hal_light_set(_Lo, { radius: 4 }); hal_light_move(_Lo, 260, 150); _settle(_Wo);
    hal_st_assert(_st, hal_light_visibility(_Lo) > 0.99, "clearing the occluder lights everything");
    // what the eye gets: a covered light draws no ink, the same light uncovered draws plenty
    var _Wi = hal_world_create({ kit: "vintage", occluder: { mode: "objects", objects: obj_hal_wall } }), _Li = hal_light_add(_Wi, "sun", 260, 150, { radius: 8 });
    _settle(_Wi);
    hal__st_black(_sa); hal_world_draw(_Wi, 0, 0, 960, 540); surface_reset_target();
    _rd = hal__st_read(_sa); var _inkOff = hal__st_ink(_rd, 0, 0, 960, 540, 6); buffer_delete(_rd.buf);
    hal_light_move(_Li, 700, 150); _settle(_Wi);
    hal__st_black(_sa); hal_world_draw(_Wi, 0, 0, 960, 540); surface_reset_target();
    _rd = hal__st_read(_sa); var _inkOn = hal__st_ink(_rd, 0, 0, 960, 540, 6); buffer_delete(_rd.buf);
    hal_st_assert(_st, _inkOff == 0, "a fully covered sun draws no ink at all (" + string(_inkOff) + ")");
    hal_st_assert(_st, _inkOn > 20000, "the same sun uncovered draws plenty (" + string(_inkOn) + ")");
    instance_destroy(_block); layer_destroy(_tl);

    // ------------------------------------------------------------ 70: drawing
    hal_st_stage(_st, 70);
    // every design draws, within a sane number of vertices; the batch limit is respected by flushing
    var _vmax = 0, _vmaxName = "", _vs = [], _dead = 0, _sb = surface_create(480, 270);
    for (var _a = 0; _a < array_length(_kits); _a++) for (var _b = 0; _b < array_length(_kinds); _b++) {
        var _v0 = global.hal_vtotal;
        hal__st_black(_sb);
        hal_flare_draw(_kits[_a], _kinds[_b], 150, 90, 1, { fx: 0, fy: 0, fw: 480, fh: 270, t: 0.4 });
        surface_reset_target();
        var _vc = global.hal_vtotal - _v0;
        _rd = hal__st_read(_sb);
        var _ik = hal__st_ink(_rd, 0, 0, 480, 270, 30);
        buffer_delete(_rd.buf);
        array_push(_vs, _vc);
        if (_vc > _vmax) { _vmax = _vc; _vmaxName = _kits[_a] + " x " + _kinds[_b]; }
        if (_ik < 40) { _dead++; array_push(_st.failures, "no ink: " + _kits[_a] + " x " + _kinds[_b] + " " + string(_ik)); }
    }
    array_sort(_vs, true);
    _st.notes.vertsMedian = _vs[array_length(_vs) div 2]; _st.notes.vertsMax = _vmax; _st.notes.vertsMaxName = _vmaxName;
    hal_st_assert(_st, _dead == 0, "all 80 designs draw ink on a black frame (" + string(_dead) + " did not)");
    hal_st_assert(_st, _vmax < 6000, "the heaviest design stays under 6000 vertices (" + _vmaxName + ": " + string(_vmax) + ")");
    hal_st_assert(_st, _vmax > 1000, "fixture: at least one design runs past a single batch's limit, so the flush is exercised (" + string(_vmax) + ")");
    // the far end of a batch past the limit still draws: the crystal kit's last ring element is written after well over 1000 vertices
    hal_kit_define("st_batch", "crystal", { ghosts: [], spike: { g: 0 }, core: { g: 0 }, bloom: { g: 0 }, sparks: { n: 0, g: 0 }, veil: { g: 0 }, rings: [{ g: 1, r: 0.32, w: 0.02, arc: 1, at: 0, chroma: 0 }] });
    hal__st_black(_sa);
    hal_flare_draw("st_batch", "sun", 480, 270, 1, { fx: 0, fy: 0, fw: 960, fh: 540 });
    surface_reset_target();
    _rd = hal__st_read(_sa);
    var _ringR = 0.32 * 540, _gaps = 0;
    for (var _i = 0; _i < 72; _i++) { var _ga = _i * 2 * pi / 72; if (hal__st_lum(_rd, 480 + cos(_ga) * _ringR, 270 + sin(_ga) * _ringR) < 60) _gaps++; }
    buffer_delete(_rd.buf);
    hal_st_assert(_st, _gaps == 0, "a full ring has no gap (" + string(_gaps) + " of 72 samples dark)");

    // state handed back
    surface_set_target(_sa); draw_clear_alpha(c_black, 1);
    gpu_set_blendmode_ext_sepalpha(bm_src_colour, bm_inv_src_alpha, bm_one, bm_zero);
    draw_set_colour(c_aqua); draw_set_alpha(0.7);
    var _m0 = matrix_get(matrix_world); matrix_set(matrix_world, matrix_build(5, 7, 0, 0, 0, 0, 1, 1, 1));
    var _before = gpu_get_blendmode_ext_sepalpha();
    hal_flare_draw("vintage", "sun", 200, 200, 1, { fx: 0, fy: 0, fw: 960, fh: 540 });
    hal_glint_draw(50, 50, 30);
    var _Wst = hal_world_create(); hal_light_add(_Wst, "torch", 100, 100); hal_world_step(_Wst, 1 / 60); hal_world_draw(_Wst, 0, 0, 960, 540);
    var _after = gpu_get_blendmode_ext_sepalpha(), _mAfter = matrix_get(matrix_world);
    hal_st_assert(_st, array_length(_before) == 4 && _after[0] == _before[0] && _after[1] == _before[1] && _after[2] == _before[2] && _after[3] == _before[3] && _before[0] == bm_src_colour && _before[3] == bm_zero, "the caller's blend is handed back");
    hal_st_assert(_st, draw_get_colour() == c_aqua, "the caller's colour is handed back (" + string(draw_get_colour()) + ")");
    hal_st_assert(_st, abs(draw_get_alpha() - 0.7) < 0.006, "the caller's alpha is handed back (" + string(draw_get_alpha()) + ", stored as a byte)");
    hal_st_assert(_st, _mAfter[12] == 5 && _mAfter[13] == 7, "the caller's matrix is handed back");
    matrix_set(matrix_world, _m0); draw_set_alpha(1); draw_set_colour(c_white); gpu_set_blendmode(bm_normal);
    surface_reset_target();
    // an opaque surface stays opaque: colour adds, alpha is "over"
    hal__st_black(_sa); hal_flare_draw("vintage", "sun", 200, 120, 1, { fx: 0, fy: 0, fw: 960, fh: 540 }); surface_reset_target();
    var _rdA = hal__st_read(_sa), _trans = 0;
    for (var _y = 0; _y < 540; _y += 3) for (var _x = 0; _x < 960; _x += 3) if (buffer_peek(_rdA.buf, (_y * 960 + _x) * 4 + 3, buffer_u8) != 255) _trans++;
    buffer_delete(_rdA.buf);
    hal_st_assert(_st, _trans == 0, "drawing on an opaque surface leaves it opaque (" + string(_trans) + " translucent samples)");
    // a transform applies: under a caller's 2x, the source lands at twice the place
    hal__st_black(_sa);
    var _m1 = matrix_get(matrix_world); matrix_set(matrix_world, matrix_build(0, 0, 0, 0, 0, 0, 2, 2, 1));
    hal_flare_draw("vintage", "sun", 120, 90, 1, { fx: 0, fy: 0, fw: 480, fh: 270 });
    matrix_set(matrix_world, _m1); surface_reset_target();
    _rd = hal__st_read(_sa);
    hal_st_assert(_st, hal__st_lum(_rd, 240, 180) > 700 && hal__st_lum(_rd, 120, 90) < hal__st_lum(_rd, 240, 180) - 200, "under a caller's 2x transform the source lands at twice its place");
    buffer_delete(_rd.buf);
    // frames: a smaller frame scales the flare, and clip keeps it inside; without clip its bloom spills
    var _Wc = hal_world_create({ kit: "vintage", camera: -1 }), _Lc = hal_light_add(_Wc, "sun", 340, 200, { screen: true });
    hal_world_step(_Wc, 1 / 60);
    hal__st_black(_sa); hal_world_draw(_Wc, 50, 50, 320, 180, true); surface_reset_target();
    _rd = hal__st_read(_sa);
    var _inA = hal__st_ink(_rd, 50, 50, 370, 230, 6), _outA = hal__st_ink(_rd, 0, 0, 960, 50, 2) + hal__st_ink(_rd, 0, 230, 960, 540, 2) + hal__st_ink(_rd, 0, 50, 50, 230, 2) + hal__st_ink(_rd, 370, 50, 960, 230, 2);
    buffer_delete(_rd.buf);
    hal_st_assert(_st, _inA > 5000 && _outA == 0, "clip true keeps every pixel inside the frame (" + string(_inA) + " in, " + string(_outA) + " out)");
    hal__st_black(_sa); hal_world_draw(_Wc, 50, 50, 320, 180, false); surface_reset_target();
    _rd = hal__st_read(_sa);
    var _outB = hal__st_ink(_rd, 370, 50, 960, 230, 2) + hal__st_ink(_rd, 0, 230, 960, 540, 2);
    buffer_delete(_rd.buf);
    hal_st_assert(_st, _outB > 500, "control: without clip the bloom does leave the frame (" + string(_outB) + "), so clip was doing the work");
    // the camera maps a room position into the frame
    var _cam = camera_create_view(1000, 500, 480, 270);
    var _Wv = hal_world_create({ kit: "telescope", camera: _cam }), _Lv = hal_light_add(_Wv, "sun", 1240, 635);
    hal_world_step(_Wv, 1 / 60);
    hal__st_black(_sa); hal_world_draw(_Wv, 0, 0, 960, 540); surface_reset_target();
    _rd = hal__st_read(_sa);
    hal_st_assert(_st, hal__st_lum(_rd, 480, 270) > 600, "a camera view maps the room onto the frame: a light at the view's centre lands at the frame's centre");
    buffer_delete(_rd.buf);
    camera_destroy(_cam);
    // veil: reaches every corner for a sun, and stops at the frame's edge
    hal_kit_define("st_veil", "vintage", { ghosts: [], rings: [], streaks: [], spike: { g: 0 }, bloom: { g: 0 }, core: { g: 0 }, dirt: { g: 0 }, veil: { g: 0.5, col: c_white, reach: 4 } });
    hal__st_black(_sa); hal_flare_draw("st_veil", "sun", 200, 100, 1, { fx: 100, fy: 50, fw: 400, fh: 225 }); surface_reset_target();
    _rd = hal__st_read(_sa);
    hal_st_assert(_st, hal__st_lum(_rd, 110, 60) > 30 && hal__st_lum(_rd, 490, 265) > 20, "the veil lifts the whole frame");
    hal_st_assert(_st, hal__st_ink(_rd, 0, 0, 960, 48, 0) == 0 && hal__st_ink(_rd, 502, 0, 960, 540, 0) == 0, "and stops at its edge");
    buffer_delete(_rd.buf);
    // dirt lights only near a bright source
    hal_kit_define("st_dirt", "vintage", { ghosts: [], rings: [], streaks: [], spike: { g: 0 }, bloom: { g: 0 }, core: { g: 0 }, veil: { g: 0 }, dirt: { n: 200, g: 1, size: 0.008, seed: 5, reach: 0.25 } });
    hal__st_black(_sa); hal_flare_draw("st_dirt", "sun", 200, 200, 1, { fx: 0, fy: 0, fw: 960, fh: 540 }); surface_reset_target();
    _rd = hal__st_read(_sa);
    var _dNear = hal__st_ink(_rd, 80, 80, 320, 320, 10), _dFar = hal__st_ink(_rd, 620, 200, 960, 540, 10);
    buffer_delete(_rd.buf);
    hal_st_assert(_st, _dNear > 80 && _dFar == 0, "lens dirt lights up near the source and nowhere else (" + string(_dNear) + " near, " + string(_dFar) + " far)");
    hal_st_assert(_st, !hal_flare_draw("teapot", "sun", 0, 0) && !hal_flare_draw("vintage", "teapot", 0, 0) && !hal_flare_draw("vintage", "sun", 0, 0, 1, { fw: 0 }), "hal_flare_draw refuses bad names and an empty frame");
    // glints: ink, only where they are put; a twinkle's ends are dark
    hal__st_black(_sa); hal_glint_draw(100, 100, 30); surface_reset_target();
    _rd = hal__st_read(_sa);
    var _gi = hal__st_ink(_rd, 60, 60, 140, 140, 30), _gOut = hal__st_ink(_rd, 200, 200, 960, 540, 3);
    buffer_delete(_rd.buf);
    hal_st_assert(_st, _gi > 30 && _gOut == 0, "hal_glint_draw draws where it is put (" + string(_gi) + ")");
    hal__st_black(_sa); hal_glint_draw(100, 100, 30, 0); surface_reset_target();
    _rd = hal__st_read(_sa); hal_st_assert(_st, hal__st_ink(_rd, 60, 60, 140, 140, 6) == 0, "a glint at phase 0 is dark"); buffer_delete(_rd.buf);

    // ------------------------------------------------------------ 80: the retro kit stays on its grid
    hal_st_stage(_st, 80);
    var _blockBad = function(_rd, _p) {
        var _bad = 0;
        for (var _y = 0; _y + _p <= _rd.h; _y += _p) for (var _x = 0; _x + _p <= _rd.w; _x += _p) {
            var _o = (_y * _rd.w + _x) * 4, _r0 = buffer_peek(_rd.buf, _o, buffer_u8), _g0 = buffer_peek(_rd.buf, _o + 1, buffer_u8), _b0 = buffer_peek(_rd.buf, _o + 2, buffer_u8), _flag = false;
            for (var _j = 0; _j < _p && !_flag; _j++) for (var _i = 0; _i < _p; _i++) {
                var _q = ((_y + _j) * _rd.w + _x + _i) * 4;
                if (abs(buffer_peek(_rd.buf, _q, buffer_u8) - _r0) > 2 || abs(buffer_peek(_rd.buf, _q + 1, buffer_u8) - _g0) > 2 || abs(buffer_peek(_rd.buf, _q + 2, buffer_u8) - _b0) > 2) { _flag = true; break; }
            }
            if (_flag) _bad++;
        }
        return _bad;
    };
    var _pixelBad = 0, _pixelInk = 0;
    for (var _b = 0; _b < array_length(_kinds); _b++) {
        hal__st_black(_sa); hal_flare_draw("pixel", _kinds[_b], 203, 127, 1, { fx: 0, fy: 0, fw: 960, fh: 540 }); surface_reset_target();
        _rd = hal__st_read(_sa);
        var _bb = _blockBad(_rd, 3);
        _pixelBad += _bb; _pixelInk += hal__st_ink(_rd, 0, 0, 960, 540, 6);
        if (_bb > 0) array_push(_st.failures, "pixel x " + _kinds[_b] + ": " + string(_bb) + " 3 x 3 blocks not uniform");
        buffer_delete(_rd.buf);
    }
    hal_st_assert(_st, _pixelInk > 3000, "fixture: the retro kit drew real ink across its ten kinds (" + string(_pixelInk) + ")");
    hal_st_assert(_st, _pixelBad == 0, "every pixel of the retro kit sits in a whole 3 x 3 block at 540 lines, a smear would break one (" + string(_pixelBad) + " blocks)");
    hal__st_black(_sa); hal_flare_draw("vintage", "sun", 203, 127, 1, { fx: 0, fy: 0, fw: 960, fh: 540 }); surface_reset_target();
    _rd = hal__st_read(_sa); var _ctl = _blockBad(_rd, 3); buffer_delete(_rd.buf);
    hal_st_assert(_st, _ctl > 200, "control: a smooth kit does break that test (" + string(_ctl) + " blocks), so it can fire");
    hal_st_assert(_st, hal__snap(101, 3) == 102 && hal__snap(100, 3) == 99 && hal__snap(-4, 3) == -3, "hal__snap rounds to the grid");

    // ------------------------------------------------------------ 85: every pair of designs measured apart
    hal_st_stage(_st, 85);
    var _nk = array_length(_kits), _nd = array_length(_kinds), _nall = _nk * _nd, _gx = 48, _gy = 27, _grids = array_create(_nall), _sg = surface_create(480, 270);
    var _sig = function(_sf, _kit, _kind, _gx, _gy, _br) {
        hal__st_black(_sf);
        hal_flare_draw(_kit, _kind, 144, 81, _br, { fx: 0, fy: 0, fw: 480, fh: 270, t: 0.4 });
        surface_reset_target();
        var _rd = hal__st_read(_sf), _o = array_create(_gx * _gy * 3, 0), _cw = 10, _ch = 10;
        for (var _j = 0; _j < _gy; _j++) for (var _i = 0; _i < _gx; _i++) {
            var _r = 0, _g = 0, _b = 0, _c = 0;
            for (var _y = _j * _ch; _y < (_j + 1) * _ch; _y += 2) for (var _x = _i * _cw; _x < (_i + 1) * _cw; _x += 2) {
                var _q = (_y * _rd.w + _x) * 4; _r += buffer_peek(_rd.buf, _q, buffer_u8); _g += buffer_peek(_rd.buf, _q + 1, buffer_u8); _b += buffer_peek(_rd.buf, _q + 2, buffer_u8); _c++;
            }
            var _idx = (_j * _gx + _i) * 3;
            _o[_idx] = _r / _c; _o[_idx + 1] = _g / _c; _o[_idx + 2] = _b / _c;
        }
        buffer_delete(_rd.buf);
        return _o;
    };
    var _dist = function(_a, _b, _n) { var _s = 0, _t = 0; for (var _i = 0; _i < _n; _i++) { var _p = _a[_i], _q = _b[_i], _d = _p - _q; if (_d < 0) _d = -_d; _s += _d; _t += _p + _q; } return (_t > 0) ? _s / _t : 0; };
    for (var _a = 0; _a < _nk; _a++) for (var _b = 0; _b < _nd; _b++) _grids[_a * _nd + _b] = _sig(_sg, _kits[_a], _kinds[_b], _gx, _gy, 1);
    var _ncells = _gx * _gy * 3, _closest = [], _hist = array_create(20, 0), _minD = 100000, _minPair = "";
    for (var _i = 0; _i < _nall; _i++) for (var _j = _i + 1; _j < _nall; _j++) {
        var _dd = _dist(_grids[_i], _grids[_j], _ncells);
        _hist[min(floor(_dd * 20), 19)] += 1;
        if (_dd < _minD) { _minD = _dd; _minPair = _kits[_i div _nd] + "/" + _kinds[_i mod _nd] + " vs " + _kits[_j div _nd] + "/" + _kinds[_j mod _nd]; }
        if (_dd < 0.20) array_push(_closest, string_format(_dd, 1, 3) + " " + _kits[_i div _nd] + "/" + _kinds[_i mod _nd] + " vs " + _kits[_j div _nd] + "/" + _kinds[_j mod _nd]);
    }
    _st.notes.pairs = _nall * (_nall - 1) / 2;
    _st.notes.minDistance = _minD; _st.notes.minPair = _minPair; _st.notes.histogram = _hist; _st.notes.closePairs = _closest;
    // the noise floor: one design drawn at 90% brightness measures how far "the same design" moves
    var _floorMax = 0;
    for (var _b = 0; _b < _nd; _b++) { var _alt = _sig(_sg, "vintage", _kinds[_b], _gx, _gy, 0.9); _floorMax = max(_floorMax, _dist(_grids[_b], _alt, _ncells)); }
    _st.notes.sameDesign90 = _floorMax;
    hal_st_assert(_st, _minD > _floorMax, "the closest two of 80 designs (" + _minPair + ", " + string_format(_minD, 1, 3) + ") differ by more than a design differs from itself dimmed by a tenth (" + string_format(_floorMax, 1, 3) + ")");
    hal_st_assert(_st, _st.notes.pairs == 3160, "the sweep compared every pair (" + string(_st.notes.pairs) + ")");
    surface_free(_sg);

    // ------------------------------------------------------------ 90: the package owns nothing
    hal_st_stage(_st, 90);
    var _rc0 = debug_event("ResourceCounts", true);
    hal_st_assert(_st, is_struct(_rc0) && variable_struct_exists(_rc0, "spriteCount") && variable_struct_exists(_rc0, "surfaceCount") && variable_struct_exists(_rc0, "vertexBufferCount"), "fixture: the engine reports its resource counts here");
    repeat (40) {
        var _Wx = hal_world_create({ kit: "crystal" });
        var _lx = hal_light_add(_Wx, "sun", 100, 100); hal_flash(_Wx, "explosion", 200, 100); hal_glint(_Wx, 50, 50);
        hal_world_step(_Wx, 1 / 60);
        surface_set_target(_sa); hal_world_draw(_Wx, 0, 0, 960, 540); surface_reset_target();
        hal_world_clear(_Wx);
    }
    var _rc1 = debug_event("ResourceCounts", true), _rk = variable_struct_get_names(_rc0), _delta = "";
    for (var _i = 0; _i < array_length(_rk); _i++) { var _dv = _rc1[$ _rk[_i]] - _rc0[$ _rk[_i]]; if (_dv != 0) _delta += _rk[_i] + " " + string(_dv) + " "; }
    _st.notes.resourceCountKeys = array_length(_rk);
    hal_st_assert(_st, array_length(_rk) >= 20, "the engine reports many resource counts (" + string(array_length(_rk)) + ")");
    hal_st_assert(_st, _delta == "", "forty worlds of flares moved none of them (" + _delta + ")");
    // positive control: the same reading does move when something IS created
    var _spr0 = sprite_create_from_surface(_sb, 0, 0, 4, 4, false, false, 0, 0), _vb0 = vertex_create_buffer(), _sf0 = surface_create(4, 4);
    var _rc2 = debug_event("ResourceCounts", true);
    hal_st_assert(_st, _rc2.spriteCount == _rc1.spriteCount + 1 && _rc2.vertexBufferCount == _rc1.vertexBufferCount + 1 && _rc2.surfaceCount == _rc1.surfaceCount + 1, "control: a sprite, a vertex buffer and a surface do move those counts by one each");
    sprite_delete(_spr0); vertex_delete_buffer(_vb0); surface_free(_sf0);

    // ------------------------------------------------------------ 100: timing (a number for the Readme; never a gate on this shared machine)
    hal_st_stage(_st, 100);
    var _timed = function(_kit, _kind, _sf) {
        var _t0 = get_timer();
        repeat (40) hal_flare_draw(_kit, _kind, 200, 120, 1, { fx: 0, fy: 0, fw: 960, fh: 540, t: 0.4 });
        draw_flush();
        return (get_timer() - _t0) / 40000;
    };
    surface_set_target(_sa); draw_clear_alpha(c_black, 1);
    _st.timings.vintage_sun = _timed("vintage", "sun", _sa);
    _st.timings.crystal_sun = _timed("crystal", "sun", _sa);
    _st.timings.telescope_sun = _timed("telescope", "sun", _sa);
    _st.timings.pixel_sun = _timed("pixel", "sun", _sa);
    _st.timings.vintage_torch = _timed("vintage", "torch", _sa);
    var _Wb = hal_world_create({ kit: "vintage" });
    hal_light_add(_Wb, "sun", 200, 100);
    for (var _i = 0; _i < 8; _i++) hal_light_add(_Wb, "torch", 80 + _i * 90, 400);
    hal_world_step(_Wb, 1 / 60);
    var _t0 = get_timer();
    repeat (30) hal_world_draw(_Wb, 0, 0, 960, 540);
    draw_flush();
    _st.timings.sun_plus_8_torches = (get_timer() - _t0) / 30000;
    surface_reset_target();
    var _v0b = global.hal_vtotal; surface_set_target(_sa); hal_world_draw(_Wb, 0, 0, 960, 540); surface_reset_target();
    _st.notes.vertsSunPlus8 = global.hal_vtotal - _v0b;
    var _v0c = global.hal_vtotal; surface_set_target(_sa); hal_flare_draw("vintage", "sun", 200, 120, 1, { fx: 0, fy: 0, fw: 960, fh: 540, t: 0.4 }); surface_reset_target();
    _st.notes.vertsVintageSun = global.hal_vtotal - _v0c;
    var _v0d = global.hal_vtotal; surface_set_target(_sa); hal_flare_draw("vintage", "torch", 200, 120, 1, { fx: 0, fy: 0, fw: 960, fh: 540, t: 0.4 }); surface_reset_target();
    _st.notes.vertsVintageTorch = global.hal_vtotal - _v0d;
    hal_st_assert(_st, _st.notes.vertsVintageTorch < _st.notes.vertsVintageSun * 0.6, "a torch costs well under a sun (" + string(_st.notes.vertsVintageTorch) + " vertices against " + string(_st.notes.vertsVintageSun) + ")");
    hal_st_assert(_st, _st.timings.sun_plus_8_torches < 200, "sanity: a sun and eight torches are nowhere near a fifth of a second a frame (" + string(_st.timings.sun_plus_8_torches) + " ms)");

    // ------------------------------------------------------------ 105: the demo room itself: built, run and drawn through its own calls
    hal_st_stage(_st, 105);
    var _dm = hal_demo_create();
    hal_st_assert(_st, is_struct(_dm) && hal_world_count(_dm.world) >= 9, "THE BACKLOT builds, with its set's lights (" + string(hal_world_count(_dm.world)) + ")");
    hal_st_assert(_st, array_length(_dm.blocks) == array_length(hal_demo_walls()) && instance_number(obj_hal_wall) == array_length(_dm.blocks), "and its walls are real instances");
    hal_st_assert(_st, tilemap_get_at_pixel(_dm.tilemap, 448, 300) > 0 && tilemap_get_at_pixel(_dm.tilemap, 600, 100) <= 0, "and its tile layer covers the columns and not the sky");
    var _sd = surface_create(room_width, room_height), _demoTods = [0.12, 0.40, 0.66, 0.90], _demoNames = ["noon", "golden", "dusk", "night"];
    for (var _i = 0; _i < 4; _i++) {
        hal_demo_set_time(_dm, _demoTods[_i]);
        _dm.clock = false; _dm.gun = 0;
        repeat (40) hal_world_step(_dm.world, 1 / 60);
        hal_demo_step(_dm);
        surface_set_target(_sd); draw_clear_alpha(c_black, 1); hal_demo_draw(_dm); surface_reset_target();
        surface_save(_sd, "hal_render_demo_" + _demoNames[_i] + ".png");
        _rd = hal__st_read(_sd);
        var _inkD = hal__st_ink(_rd, 0, 0, room_width, room_height, 12);
        buffer_delete(_rd.buf);
        hal_st_assert(_st, _inkD > 100000, "the demo draws its " + _demoNames[_i] + " frame (" + string(_inkD) + ")");
    }
    // every occluder the demo cycles through keeps working, and the sun is behind the column it should be behind
    for (var _i = 0; _i < 4; _i++) {
        _dm.occI = _i; hal_demo__set_occluder(_dm);
        hal_light_move(_dm.sun, 456, 300); _dm.sun.brightness = 1;   // inside the column (434..465) AND inside its tile cell (448..480)
        hal_light_set(_dm.sun, { radius: 4 });
        repeat (60) hal_world_step(_dm.world, 1 / 60);
        var _vd = hal_light_visibility(_dm.sun);
        hal_st_assert(_st, (_i < 3) ? (_vd < 0.02) : (_vd > 0.98), "demo occluder " + string(_i) + ": a sun behind a column reads " + string(_vd));
    }
    hal_demo_free(_dm);
    hal_st_assert(_st, instance_number(obj_hal_wall) == 0 && !layer_exists("hal_demo_tiles"), "the demo removes its walls and its tile layer");
    surface_free(_sd);

    // ------------------------------------------------------------ 110: renders, to be looked at
    hal_st_stage(_st, 110);
    // the contact sheet comes first: every kit x kind at 180 x 101
    var _cw = 180, _ch = 101, _sc = surface_create(_cw * _nd, _ch * _nk);
    surface_set_target(_sc); draw_clear_alpha(#0B0D14, 1);
    for (var _a = 0; _a < _nk; _a++) for (var _b = 0; _b < _nd; _b++) {
        var _cx = _b * _cw, _cy = _a * _ch;
        gpu_set_scissor(_cx, _cy, _cw, _ch);
        hal_flare_draw(_kits[_a], _kinds[_b], _cx + _cw * 0.3, _cy + _ch * 0.34, 1, { fx: _cx, fy: _cy, fw: _cw, fh: _ch, t: 0.4 });
    }
    gpu_set_scissor(0, 0, _cw * _nd, _ch * _nk);
    surface_reset_target();
    surface_save(_sc, "hal_render_contact.png");
    surface_free(_sc);
    // every kit on a real scene
    var _sh = surface_create(960, 540);
    for (var _a = 0; _a < _nk; _a++) {
        surface_set_target(_sh); draw_clear_alpha(c_black, 1);
        hal_demo_scene(0, 0, 960, 540, 0.26);
        var _Sn = hal_demo_sun(0.26);
        hal_flare_draw(_kits[_a], "sun", _Sn.x * 960, _Sn.y * 540, 1, { fx: 0, fy: 0, fw: 960, fh: 540, t: 0.4, grade: true, kelvin: 4800 });
        surface_reset_target();
        surface_save(_sh, "hal_render_kit_" + _kits[_a] + ".png");
    }
    // the set through the day
    var _tods = [0.08, 0.30, 0.46, 0.58, 0.74, 0.92];
    for (var _i = 0; _i < array_length(_tods); _i++) {
        surface_set_target(_sh); draw_clear_alpha(c_black, 1);
        hal_demo_scene(0, 0, 960, 540, _tods[_i]);
        surface_reset_target();
        surface_save(_sh, "hal_render_set_" + string(_i) + ".png");
    }
    surface_free(_sh); surface_free(_sa); surface_free(_sf); surface_free(_sb);
    _st.notes.done = true;
    hal_st_stage(_st, 99);
    return _st;
}

/// @function hal_selftest_write(state)
/// @description Write the suite's result as hal_selftest.json in the save folder.
function hal_selftest_write(_st) {
    var _f = file_text_open_write("hal_selftest.json");
    file_text_write_string(_f, json_stringify(_st));
    file_text_close(_f);
}
