/// hal_demo.gml - THE BACKLOT, Halation's demo room: one location from noon to night. The sun crosses the sky and passes behind a ruined colonnade, the torches, the lantern and the neon come on at dusk, the moon rises, and a gunfight breaks out at the far end of the street. Everything is real lights in one world, looking through the lens you choose; the set is drawn with the same primitives.
/// Keys: 1..8 choose the lens - Left / Right scrub the time of day - Space hold or run the clock - F muzzle flash at the mouse - X explosion at the mouse - G a glint along the sword
/// Left mouse: a light you carry (K changes its kind) - O the occluder: objects / a tile layer / a function / none - V veil on or off - D dirt on or off - H hide the captions.
///
/// Halation - Lens Flares, Glints and Glare for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function hal_demo__sky(time)
/// @description Internal. The sky's three colours at a time of day.
function hal_demo__sky(_tod) {
    static _T = [0, 0.30, 0.48, 0.62, 0.78, 1];
    static _TOP = [ #3A7DD0, #4369B8, #3A3F92, #1E1C5C, #0E1034, #050814];
    static _MID = [ #7FB6E6, #8FA6D8, #C0719A, #6A3B82, #1C1C4E, #0A1028];
    static _BOT = [ #D6ECF4, #FFD79C, #FF9256, #E8664C, #3A2A5C, #141A3A];
    var _i = 0;
    while (_i < array_length(_T) - 2 && _tod > _T[_i + 1]) _i++;
    var _u = clamp((_tod - _T[_i]) / (_T[_i + 1] - _T[_i]), 0, 1);
    return { top: merge_colour(_TOP[_i], _TOP[_i + 1], _u), mid: merge_colour(_MID[_i], _MID[_i + 1], _u), bot: merge_colour(_BOT[_i], _BOT[_i + 1], _u) };
}

/// @function hal_demo_sun(time)
/// @description Where the sun is at a time of day, in frame fractions: { x, y, up } (up 0 once it has set).
function hal_demo_sun(_tod) {
    var _u = clamp(_tod / 0.64, 0, 1);
    return { x: lerp(0.14, 0.72, _u), y: lerp(0.13, 0.80, power(_u, 1.45)), up: 1 - clamp((_tod - 0.56) / 0.09, 0, 1) };
}

/// @function hal_demo_moon(time)
/// @description Where the moon is at a time of day, in frame fractions: { x, y, up }.
function hal_demo_moon(_tod) {
    var _u = clamp((_tod - 0.60) / 0.40, 0, 1);
    return { x: lerp(0.93, 0.66, _u), y: lerp(0.56, 0.15, power(_u, 0.8)), up: clamp((_tod - 0.62) / 0.14, 0, 1) };
}

/// @function hal_demo_walls()
/// @description The colonnade's solid parts in frame fractions, [x0, y0, x1, y1]: what blocks the sun. The last row is the ground.
function hal_demo_walls() {
    return [
        [0.360, 0.335, 0.392, 0.740], [0.452, 0.335, 0.484, 0.740], [0.544, 0.410, 0.576, 0.740], [0.636, 0.525, 0.668, 0.740],
        [0.344, 0.292, 0.500, 0.335], [0.530, 0.372, 0.590, 0.410],
        [0.000, 0.745, 1.000, 1.000]
    ];
}

/// @function hal_demo__ridge(u, seed, amp)
/// @description Internal. A hill line: three sines of different lengths, in frame fractions.
function hal_demo__ridge(_u, _seed, _amp) {
    return _amp * (0.50 * sin(_u * 6.1 + _seed) + 0.30 * sin(_u * 13.7 + _seed * 2.3) + 0.14 * sin(_u * 31.3 + _seed * 3.7));
}

/// @function hal_demo__q(x0, y0, x1, y1, c0, c1, batch)
/// @description Internal. One quad, top colour to bottom colour, flushing the batch before GameMaker's vertex limit.
function hal_demo__q(_x0, _y0, _x1, _y1, _c0, _c1, _B) {
    draw_vertex_colour(_x0, _y0, _c0, 1); draw_vertex_colour(_x1, _y0, _c0, 1); draw_vertex_colour(_x1, _y1, _c1, 1);
    draw_vertex_colour(_x0, _y0, _c0, 1); draw_vertex_colour(_x1, _y1, _c1, 1); draw_vertex_colour(_x0, _y1, _c1, 1);
    _B.n += 6;
    if (_B.n >= 880) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); _B.n = 0; }
}

/// @function hal_demo_scene(x, y, w, h, time)
/// @description Draw the set (no flares): sky, stars, the sun's and moon's discs, hills, the ruined colonnade, the street, its torches, sign and windows. time 0 is noon, 1 is deep night.
function hal_demo_scene(_x, _y, _w, _h, _tod) {
    var _S = hal_demo__sky(_tod), _hz = _y + _h * 0.74, _B = { n: 0 };
    var _day = 1 - clamp((_tod - 0.40) / 0.36, 0, 1), _night = clamp((_tod - 0.55) / 0.30, 0, 1);
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    draw_primitive_begin(pr_trianglelist);
    // sky: two gradient bands meeting at the mid colour
    hal_demo__q(_x, _y, _x + _w, _y + _h * 0.42, _S.top, _S.mid, _B);
    hal_demo__q(_x, _y + _h * 0.42, _x + _w, _hz, _S.mid, _S.bot, _B);
    draw_primitive_end();
    // stars
    if (_night > 0.02) {
        draw_primitive_begin(pr_trianglelist);
        var _g = hal_rng(4242);
        repeat (90) {
            var _sx = _x + hal_rand(_g) * _w, _sy = _y + power(hal_rand(_g), 1.5) * _h * 0.66, _sa = (0.25 + 0.75 * hal_rand(_g)) * _night, _ss = max(_h / 540, 1) * ((hal_rand(_g) > 0.86) ? 2 : 1);
            draw_vertex_colour(_sx, _sy, c_white, _sa); draw_vertex_colour(_sx + _ss, _sy, c_white, _sa); draw_vertex_colour(_sx + _ss, _sy + _ss, c_white, _sa);
            draw_vertex_colour(_sx, _sy, c_white, _sa); draw_vertex_colour(_sx + _ss, _sy + _ss, c_white, _sa); draw_vertex_colour(_sx, _sy + _ss, c_white, _sa);
        }
        draw_primitive_end();
    }
    // the moon's own disc, with a shaded limb
    var _M = hal_demo_moon(_tod);
    if (_M.up > 0.01) {
        var _mx = _x + _M.x * _w, _my = _y + _M.y * _h, _mr = _h * 0.038;
        draw_set_colour(merge_colour(_S.top, #DDE6F8, _M.up)); draw_circle(_mx, _my, _mr, false);
        draw_set_colour(merge_colour(_S.top, #A9B4CC, _M.up)); draw_circle(_mx + _mr * 0.32, _my - _mr * 0.2, _mr * 0.20, false); draw_circle(_mx - _mr * 0.28, _my + _mr * 0.34, _mr * 0.27, false); draw_circle(_mx + _mr * 0.18, _my + _mr * 0.42, _mr * 0.13, false);
    }
    draw_primitive_begin(pr_trianglelist);
    // far and near hills, each band fading into the air below its ridge line
    var _hills = [[0.655, 0.040, 1.3, #6E90B4, #2A2C56, #090C20], [0.695, 0.030, 4.1, #5E7F7C, #231F44, #070A1A]];
    for (var _h2 = 0; _h2 < 2; _h2++) {
        var _R = _hills[_h2];
        var _ct = (_tod < 0.5) ? merge_colour(_R[3], _R[4], _tod / 0.5) : merge_colour(_R[4], _R[5], (_tod - 0.5) / 0.5);
        var _cb = merge_colour(_ct, _S.bot, 0.42);
        for (var _i = 0; _i < 56; _i++) {
            var _u0 = _i / 56, _u1 = (_i + 1) / 56;
            var _y0 = _y + _h * (_R[0] + hal_demo__ridge(_u0, _R[2], _R[1])), _y1 = _y + _h * (_R[0] + hal_demo__ridge(_u1, _R[2], _R[1]));
            var _px0 = _x + _u0 * _w, _px1 = _x + _u1 * _w;
            draw_vertex_colour(_px0, _y0, _ct, 1); draw_vertex_colour(_px1, _y1, _ct, 1); draw_vertex_colour(_px1, _hz, _cb, 1);
            draw_vertex_colour(_px0, _y0, _ct, 1); draw_vertex_colour(_px1, _hz, _cb, 1); draw_vertex_colour(_px0, _hz, _cb, 1);
            _B.n += 6;
            if (_B.n >= 880) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); _B.n = 0; }
        }
    }
    // ground: the land, then the road
    var _gt = (_tod < 0.5) ? merge_colour(#8E8458, #3A2C34, _tod / 0.5) : merge_colour(#3A2C34, #0C0E1C, (_tod - 0.5) / 0.5);
    var _gb = merge_colour(_gt, c_black, 0.45);
    hal_demo__q(_x, _hz, _x + _w, _y + _h, _gt, _gb, _B);
    var _rd = merge_colour(_gb, #6A6470, 0.25);
    hal_demo__q(_x, _y + _h * 0.86, _x + _w, _y + _h * 0.975, _rd, merge_colour(_rd, c_black, 0.3), _B);
    // road dashes
    for (var _i = 0; _i < 11; _i++) { var _dx = _x + _w * (_i + 0.25) / 11; hal_demo__q(_dx, _y + _h * 0.915, _dx + _w * 0.038, _y + _h * 0.921, merge_colour(_rd, #D8D0B8, 0.34 * (0.3 + 0.7 * _day)), merge_colour(_rd, #D8D0B8, 0.34 * (0.3 + 0.7 * _day)), _B); }
    // the colonnade: lit faces by day, silhouettes at night; a shadow side on every column
    var _lit = (_tod < 0.5) ? merge_colour(#E2CDA0, #9C6A58, _tod / 0.5) : merge_colour(#9C6A58, #14131F, (_tod - 0.5) / 0.5);
    var _shd = merge_colour(_lit, #1A1830, 0.55);
    var _W = hal_demo_walls();
    for (var _i = 0; _i < array_length(_W) - 1; _i++) {
        var _r = _W[_i], _rx0 = _x + _r[0] * _w, _ry0 = _y + _r[1] * _h, _rx1 = _x + _r[2] * _w, _ry1 = _y + _r[3] * _h;
        if (_i < 4) {
            hal_demo__q(_rx0, _ry0, _rx1, _ry1, _lit, merge_colour(_lit, _shd, 0.45), _B);
            hal_demo__q(_rx0 + (_rx1 - _rx0) * 0.62, _ry0, _rx1, _ry1, _shd, _shd, _B);
            var _fl = (_rx1 - _rx0) * 0.09;
            for (var _f = 1; _f < 4; _f++) { var _fx = _rx0 + (_rx1 - _rx0) * _f * 0.22; hal_demo__q(_fx, _ry0, _fx + _fl, _ry1, merge_colour(_lit, _shd, 0.4), merge_colour(_lit, _shd, 0.7), _B); }
            // capital and base
            hal_demo__q(_rx0 - _w * 0.006, _ry0 - _h * 0.002, _rx1 + _w * 0.006, _ry0 + _h * 0.014, _lit, merge_colour(_lit, _shd, 0.5), _B);
            hal_demo__q(_rx0 - _w * 0.008, _ry1 - _h * 0.016, _rx1 + _w * 0.008, _ry1 + _h * 0.006, merge_colour(_lit, _shd, 0.3), _shd, _B);
        } else {
            hal_demo__q(_rx0, _ry0, _rx1, _ry1, _lit, merge_colour(_lit, _shd, 0.62), _B);
            hal_demo__q(_rx0, _ry1 - _h * 0.006, _rx1, _ry1, _shd, _shd, _B);
        }
    }
    // the street: a row of buildings, windows that light at dusk
    var _bl = (_tod < 0.5) ? merge_colour(#7A6E74, #3A2A44, _tod / 0.5) : merge_colour(#3A2A44, #0B0C18, (_tod - 0.5) / 0.5);
    static _BX = [[0.725, 0.560, 0.815], [0.815, 0.492, 0.905], [0.905, 0.600, 1.000], [0.000, 0.610, 0.105], [0.105, 0.668, 0.195]];
    var _wg = hal_rng(77);
    for (var _i = 0; _i < 5; _i++) {
        var _b = _BX[_i], _bx0 = _x + _b[0] * _w, _by0 = _y + _b[1] * _h, _bx1 = _x + _b[2] * _w, _by1 = _hz + _h * 0.012;
        var _bc = merge_colour(_bl, c_black, _i * 0.05);
        hal_demo__q(_bx0, _by0, _bx1, _by1, _bc, merge_colour(_bc, c_black, 0.28), _B);
        hal_demo__q(_bx0 - _w * 0.003, _by0 - _h * 0.008, _bx1 + _w * 0.003, _by0, merge_colour(_bc, c_white, 0.08), _bc, _B);
        var _cw = _w * 0.018, _ch = _h * 0.034;
        for (var _r2 = 0; _r2 < 4; _r2++) for (var _c2 = 0; _c2 < 3; _c2++) {
            var _wx = _bx0 + (_bx1 - _bx0) * (0.14 + _c2 * 0.29), _wy = _by0 + _h * (0.03 + _r2 * 0.056);
            var _on = hal_rand(_wg), _wc;
            if (_wy + _ch > _by1 - _h * 0.01) continue;
            if (_i == 1 && _r2 == 0) continue;   // the sign's board hangs here
            if (_on > 0.42) _wc = merge_colour(merge_colour(_bc, c_black, 0.4), (_on > 0.74) ? #FFC96E : #FFAE58, _night * 0.95);
            else _wc = merge_colour(_bc, c_black, 0.4);
            hal_demo__q(_wx, _wy, _wx + _cw, _wy + _ch, _wc, merge_colour(_wc, c_black, 0.15), _B);
        }
    }
    // the sign's board and tube, torch posts and the lantern's bracket
    var _nx = _x + _w * 0.836, _ny = _y + _h * 0.525;
    hal_demo__q(_nx - _w * 0.006, _ny - _h * 0.020, _nx + _w * 0.070, _ny + _h * 0.020, merge_colour(_bl, c_black, 0.5), merge_colour(_bl, c_black, 0.6), _B);
    var _tube = merge_colour(#7A3A58, #FFD0E0, _night), _tt = max(_h / 300, 1.2);
    hal_demo__q(_nx, _ny - _tt, _nx + _w * 0.064, _ny + _tt, _tube, _tube, _B);
    static _TOR = [0.070, 0.190, 0.300];
    for (var _i = 0; _i < 3; _i++) {
        var _tx = _x + _w * _TOR[_i];
        hal_demo__q(_tx - _w * 0.0022, _y + _h * 0.690, _tx + _w * 0.0022, _hz + _h * 0.012, merge_colour(_bl, c_black, 0.3), merge_colour(_bl, c_black, 0.5), _B);
        hal_demo__q(_tx - _w * 0.0055, _y + _h * 0.678, _tx + _w * 0.0055, _y + _h * 0.692, merge_colour(_bl, #5A4030, 0.4), _bl, _B);
    }
    draw_primitive_end();
    gpu_pop_state();
}

/// @function hal_demo_lights(demo)
/// @description Internal. Add the set's lights to the demo's world, placed for its frame in room pixels.
function hal_demo_lights(_D) {
    var _W = _D.world, _w = _D.w, _h = _D.h;
    _D.sun = hal_light_add(_W, "sun", 0, 0, { radius: _h * 0.03 });
    _D.moon = hal_light_add(_W, "moon", 0, 0, { radius: _h * 0.024, brightness: 0 });
    _D.torches = [];
    static _TOR = [0.070, 0.190, 0.300];
    for (var _i = 0; _i < 3; _i++) array_push(_D.torches, hal_light_add(_W, "torch", _w * _TOR[_i], _h * 0.672, { brightness: 0 }));
    _D.lantern = hal_light_add(_W, "lantern", _w * 0.742, _h * 0.640, { brightness: 0 });
    _D.neon = hal_light_add(_W, "neon", _w * 0.868, _h * 0.525, { brightness: 0, elong: 3.2 });
    _D.eyes = [hal_light_add(_W, "eye", _w * 0.215, _h * 0.780, { brightness: 0, occlude: false }), hal_light_add(_W, "eye", _w * 0.226, _h * 0.780, { brightness: 0, occlude: false })];
    _D.lamp = hal_light_add(_W, "headlamp", -100, _h * 0.895, { brightness: 0, occlude: false });
    _D.carry = undefined;
}

/// @function hal_demo_set_time(demo, time)
/// @description Move the set's lights to a time of day: the sun and moon along their arcs, everything else on at dusk.
function hal_demo_set_time(_D, _tod) {
    _D.tod = clamp(_tod, 0, 1);
    var _w = _D.w, _h = _D.h, _n = clamp((_D.tod - 0.48) / 0.20, 0, 1), _S = hal_demo_sun(_D.tod), _M = hal_demo_moon(_D.tod);
    hal_light_move(_D.sun, _S.x * _w, _S.y * _h);
    _D.sun.brightness = _S.up;
    // a low sun reddens
    var _k = round(lerp(5600, 2300, clamp((_D.tod - 0.28) / 0.34, 0, 1)) / 100) * 100;
    if (_k != _D.sunK) { _D.sunK = _k; hal_light_set(_D.sun, { kelvin: _k }); }
    hal_light_move(_D.moon, _M.x * _w, _M.y * _h);
    _D.moon.brightness = _M.up;
    for (var _i = 0; _i < array_length(_D.torches); _i++) _D.torches[_i].brightness = _n;
    _D.lantern.brightness = _n;
    _D.neon.brightness = _n;
    var _e = clamp((_D.tod - 0.74) / 0.12, 0, 1);
    _D.eyes[0].brightness = _e; _D.eyes[1].brightness = _e;
}

/// @function hal_demo_create()
/// @description Build THE BACKLOT: the blocks that stand in for the colonnade's collision, a tile layer over the same columns, a world, its lights.
function hal_demo_create() {
    var _w = room_width, _h = room_height;
    var _D = { w: _w, h: _h, world: undefined, tod: 0, clock: true, kitI: 0, kindI: 2, occI: 0, showHud: true, gun: 2.2, gunSide: 0, gunBurst: 0, sunK: 5600, lampT: 0, fps: 60, blocks: [], glintT: 3, tileLayer: -1, tilemap: -1 };
    // the colonnade as real instances
    var _W = hal_demo_walls();
    for (var _i = 0; _i < array_length(_W); _i++) {
        var _r = _W[_i], _b = instance_create_depth(_r[0] * _w, _r[1] * _h, 0, obj_hal_wall);
        _b.image_xscale = (_r[2] - _r[0]) * _w / 64; _b.image_yscale = (_r[3] - _r[1]) * _h / 32;
        array_push(_D.blocks, _b);
    }
    // the same columns as a tile layer, 32 px cells, for the "tiles" occluder
    _D.tileLayer = layer_create(100, "hal_demo_tiles");
    _D.tilemap = layer_tilemap_create(_D.tileLayer, 0, 0, ts_hal_mark, ceil(_w / 32), ceil(_h / 32));
    layer_set_visible(_D.tileLayer, false);
    for (var _j = 0; _j < ceil(_h / 32); _j++) for (var _i = 0; _i < ceil(_w / 32); _i++) {
        var _px = (_i + 0.5) * 32 / _w, _py = (_j + 0.5) * 32 / _h;
        for (var _q = 0; _q < array_length(_W); _q++) { var _r = _W[_q]; if (_px >= _r[0] && _px < _r[2] && _py >= _r[1] && _py < _r[3]) { tilemap_set(_D.tilemap, 1, _i, _j); break; } }
    }
    _D.world = hal_world_create({ kit: "vintage", occluder: { mode: "objects", objects: obj_hal_wall } });
    hal_demo_lights(_D);
    hal_demo_set_time(_D, 0.10);
    return _D;
}

/// @function hal_demo__set_occluder(demo)
/// @description Internal. Apply the occluder mode chosen with O.
function hal_demo__set_occluder(_D) {
    switch (_D.occI) {
        case 0: hal_world_set_occluder(_D.world, { mode: "objects", objects: obj_hal_wall }); break;
        case 1: hal_world_set_occluder(_D.world, { mode: "tiles", tilemaps: _D.tilemap }); break;
        case 2:
            var _r = hal_demo_walls(), _w = _D.w, _h = _D.h;
            hal_world_set_occluder(_D.world, { mode: "function", fn: method({ r: _r, w: _w, h: _h }, function(_x, _y) { var _u = _x / w, _v = _y / h; for (var _i = 0; _i < array_length(r); _i++) { var _q = r[_i]; if (_u >= _q[0] && _u < _q[2] && _v >= _q[1] && _v < _q[3]) return true; } return false; }) });
            break;
        default: hal_world_set_occluder(_D.world, undefined); break;
    }
}

/// @function hal_demo_step(demo)
/// @description Read the keys, run the clock and the street's events, step the world.
function hal_demo_step(_D) {
    var _dt = clamp(delta_time / 1000000, 0, 0.05), _W = _D.world, _kits = hal_kits();
    for (var _k = 1; _k <= min(8, array_length(_kits)); _k++) if (keyboard_check_pressed(ord(string(_k)))) { _D.kitI = _k - 1; hal_world_set_kit(_W, _kits[_D.kitI]); }
    if (keyboard_check_pressed(vk_space)) _D.clock = !_D.clock;
    var _tod = _D.tod;
    if (keyboard_check(vk_left)) { _tod -= _dt * 0.16; _D.clock = false; }
    if (keyboard_check(vk_right)) { _tod += _dt * 0.16; _D.clock = false; }
    if (_D.clock) { _tod += _dt * 0.022; if (_tod > 1) _tod = 0.04; }
    hal_demo_set_time(_D, _tod);
    if (keyboard_check_pressed(ord("O"))) { _D.occI = (_D.occI + 1) mod 4; hal_demo__set_occluder(_D); }
    if (keyboard_check_pressed(ord("V"))) _W.useVeil = !_W.useVeil;
    if (keyboard_check_pressed(ord("D"))) _W.useDirt = !_W.useDirt;
    if (keyboard_check_pressed(ord("H"))) _D.showHud = !_D.showHud;
    if (keyboard_check_pressed(ord("K"))) { var _ks = hal_kinds(); _D.kindI = (_D.kindI + 1) mod array_length(_ks); if (!is_undefined(_D.carry)) { hal_light_remove(_W, _D.carry); _D.carry = undefined; } }
    if (keyboard_check_pressed(ord("F"))) hal_flash(_W, "muzzle", mouse_x, mouse_y, { occlude: false });
    if (keyboard_check_pressed(ord("X"))) hal_flash(_W, "explosion", mouse_x, mouse_y, { occlude: false });
    if (keyboard_check_pressed(ord("G"))) hal_glint_along(_W, 40, 400, 160, 280, { size: 42, colour: #FFFFFF });
    if (mouse_check_button(mb_left)) {
        if (is_undefined(_D.carry)) { var _ks = hal_kinds(); _D.carry = hal_light_add(_W, _ks[_D.kindI], mouse_x, mouse_y); }   // the light you carry does go behind the columns: that is the point of carrying it
        hal_light_move(_D.carry, mouse_x, mouse_y);
    } else if (!is_undefined(_D.carry)) { hal_light_remove(_W, _D.carry); _D.carry = undefined; }
    // a gunfight down the street after dark: short bursts from each end, in turn
    var _n = clamp((_D.tod - 0.70) / 0.08, 0, 1);
    if (_n > 0.5) {
        _D.gun -= _dt;
        if (_D.gun <= 0) {
            if (_D.gunBurst <= 0) { _D.gunBurst = 3 + irandom(3); _D.gunSide = 1 - _D.gunSide; }
            var _gx = _D.w * ((_D.gunSide == 0) ? 0.596 : 0.690), _gy = _D.h * ((_D.gunSide == 0) ? 0.800 : 0.790);
            hal_flash(_W, "muzzle", _gx, _gy, { occlude: false });
            _D.gunBurst -= 1;
            _D.gun = (_D.gunBurst > 0) ? 0.11 : 1.1 + random(1.4);
        }
    }
    // a car passes along the road
    _D.lampT -= _dt;
    if (_D.lampT <= 0 && _D.tod > 0.62) { _D.lampT = 8; _D.lamp.x = -60; }
    if (_D.tod > 0.62 && _D.lamp.x < _D.w + 80) { _D.lamp.x += 150 * _dt; _D.lamp.brightness = 1; } else _D.lamp.brightness = 0;
    // a glint on something you might pick up
    _D.glintT -= _dt;
    if (_D.glintT <= 0) { _D.glintT = 3 + random(2); hal_glint(_W, _D.w * 0.46, _D.h * 0.81, { size: 22, points: 4 }); }
    hal_world_step(_W, _dt);
    if (_dt > 0) _D.fps = lerp(_D.fps, 1 / _dt, 0.05);
}

/// @function hal_demo_draw(demo)
/// @description Draw the set, the flares, a slate of what is on screen and the keys.
function hal_demo_draw(_D) {
    var _w = _D.w, _h = _D.h;
    display_set_gui_size(_w, _h);
    hal_demo_scene(0, 0, _w, _h, _D.tod);
    var _v0 = global.hal_vtotal;
    hal_world_draw(_D.world, 0, 0, _w, _h);
    var _verts = global.hal_vtotal - _v0, _kits = hal_kits(), _kit = _kits[_D.kitI];
    if (!_D.showHud) return;
    var _oldF = draw_get_font(), _ha = draw_get_halign(), _va = draw_get_valign(), _ca = draw_get_colour(), _aa = draw_get_alpha();
    draw_set_halign(fa_left); draw_set_valign(fa_top);
    draw_set_colour(c_black); draw_set_alpha(0.42); draw_rectangle(0, 0, _w, 40, false); draw_rectangle(0, _h - 30, _w, _h, false);
    draw_set_alpha(1); draw_set_colour(c_white);
    draw_set_font(fnt_halation_display_s);
    draw_text(14, 3, "HALATION");
    var _titleX = 14 + string_width("HALATION") + 10, _kitTitle = string_upper(hal_kit_title(_kit));
    draw_set_colour(#FFD08A); draw_text(_titleX, 3, _kitTitle);
    var _lineX = _titleX + string_width(_kitTitle) + 24;
    draw_set_font(fnt_halation_body_s); draw_set_colour(#D8DCE6);
    var _tx = 0.62;
    draw_text_transformed(_lineX, 10, hal_kit_line(_kit), min(_tx, (_w - _lineX - 14) / max(string_width(hal_kit_line(_kit)), 1)), min(_tx, (_w - _lineX - 14) / max(string_width(hal_kit_line(_kit)), 1)), 0);
    var _modes = ["objects", "tile layer", "function", "no occluder"], _ks = hal_kinds();
    var _foot = "1-8 lens   LEFT/RIGHT time   SPACE clock   MOUSE carry a " + string_lower(hal_kind_title(_ks[_D.kindI])) + " (K)   F flash   X explosion   G glint   O " + _modes[_D.occI] + "   V veil   D dirt   H hide";
    var _read = "sun " + string(round(hal_light_visibility(_D.sun) * 100)) + "%   " + string(_verts) + " vertices";
    var _footK = min(_tx, (_w - 14 - string_width(_read) * _tx - 40) / max(string_width(_foot), 1));
    var _tf = gpu_get_texfilter();
    gpu_set_texfilter(true);
    draw_text_transformed(14, _h - 24, _foot, _footK, _footK, 0);
    draw_set_halign(fa_right);
    draw_text_transformed(_w - 14, _h - 24, _read, _tx, _tx, 0);
    gpu_set_texfilter(_tf);
    draw_set_font(_oldF); draw_set_halign(_ha); draw_set_valign(_va); draw_set_colour(_ca); draw_set_alpha(_aa);
}

/// @function hal_demo_free(demo)
/// @description Clean Up. The world owns nothing to free; the demo's tile layer does go.
function hal_demo_free(_D) {
    if (!is_struct(_D)) return;
    if (_D.tileLayer != -1 && layer_exists(_D.tileLayer)) layer_destroy(_D.tileLayer);
    for (var _i = 0; _i < array_length(_D.blocks); _i++) if (instance_exists(_D.blocks[_i])) instance_destroy(_D.blocks[_i]);
}
