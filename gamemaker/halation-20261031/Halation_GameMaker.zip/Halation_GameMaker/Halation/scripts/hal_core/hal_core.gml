/// hal_core.gml - Halation's rules: lens kits, light kinds, colour temperature, the design compiler, the optical axis, flicker,
/// envelopes, occlusion and the world of lights. NO DRAWING CALLS live in this file: every number a flare draws is decided here,
/// so it can be asserted without a surface. Drawing is hal_draw.
///
/// What a flare is here: a light declares its KIND (sun, torch, neon ...) and looks through a LENS KIT (vintage prime, anamorphic
/// cinema ...). hal_design compiles the pair into a list of optical elements - bloom, core, ghosts strung along the axis through
/// the frame's centre, rings, spikes, streaks, veiling glare, lens dirt, sparkles. Nothing is a sprite. The package owns no
/// surface, sprite, shader or vertex buffer, so there is nothing to free, to lose or to leak.
///
/// Halation - Lens Flares, Glints and Glare for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

// element types of a compiled design
#macro HAL_EL_RADIAL 0
#macro HAL_EL_GHOST 1
#macro HAL_EL_SPIKES 2
#macro HAL_EL_RING 3
#macro HAL_EL_STREAK 4
#macro HAL_EL_VEIL 5
#macro HAL_EL_DIRT 6
#macro HAL_EL_SPARK 7
#macro HAL_EL_SCAN 8
#macro HAL_EL_NOISE 9

/// @function hal__init()
/// @description Internal. Builds the catalogue tables once.
function hal__init() {
    if (variable_global_exists("hal_t_kits")) return;
    global.hal_t_kits = hal__kits_build();
    global.hal_t_kinds = hal__kinds_build();
    global.hal_t_kit_order = ["vintage", "anamorphic", "phone", "telescope", "crystal", "pixel", "nightvision", "dream"];
    global.hal_t_kind_order = ["sun", "moon", "torch", "lantern", "neon", "muzzle", "orb", "eye", "headlamp", "explosion"];
    global.hal_t_designs = {};
    global.hal_t_design_count = 0;
    global.hal_t_circles = {};
    global.hal_t_discs = {};
    global.hal_vtotal = 0;
}

/// @function hal__num(value, fallback)
/// @description Internal. A usable finite number, or the fallback. Every public argument passes through this or a name check.
function hal__num(_v, _d) { if (is_numeric(_v) && !is_nan(_v) && !is_infinity(_v)) return _v; return _d; }

/// @function hal__opt(options, key, fallback)
/// @description Internal. A field of an options struct, or the fallback when the struct or the field is absent.
function hal__opt(_o, _k, _d) { if (is_struct(_o) && variable_struct_exists(_o, _k)) return _o[$ _k]; return _d; }

/// @function hal_rng(seed)
/// @description A seeded generator (Lehmer), warmed up so nearby seeds do not share a first draw.
/// @param {Real} seed Any number.
/// @returns {Struct} The generator; read it with hal_rand.
function hal_rng(_seed) {
    var _s = floor(abs(hal__num(_seed, 1)));
    _s = (_s mod 2147483646) + 1;
    var _g = { s: _s };
    repeat (3) hal_rand(_g);
    return _g;
}

/// @function hal_rand(generator)
/// @description The next draw in [0, 1). A value that is not a generator draws 0 rather than throwing.
/// @param {Struct} generator From hal_rng.
/// @returns {Real}
function hal_rand(_g) {
    if (!is_struct(_g) || !variable_struct_exists(_g, "s")) return 0;
    _g.s = (_g.s * 48271) mod 2147483647;
    return (_g.s - 1) / 2147483646;
}

/// @function hal__hash(text)
/// @description Internal. A small stable number from a string, for seeding.
function hal__hash(_txt) { var _h = 7, _n = string_length(_txt); for (var _i = 1; _i <= _n; _i++) _h = (_h * 31 + string_byte_at(_txt, _i)) mod 1000003; return _h; }

/// @function hal_kelvin(kelvin)
/// @description The colour of a black body at a temperature (1000..40000 K): 1900 is a candle's orange, 5600 is daylight, 9000 is a cold blue.
/// @param {Real} kelvin Colour temperature.
/// @returns {Real} A colour.
function hal_kelvin(_k) {
    var _t = clamp(hal__num(_k, 5600), 1000, 40000) / 100;
    var _r, _g, _b;
    if (_t <= 66) { _r = 255; _g = 99.4708025861 * ln(_t) - 161.1195681661; }
    else { _r = 329.698727446 * power(_t - 60, -0.1332047592); _g = 288.1221695283 * power(_t - 60, -0.0755148492); }
    if (_t >= 66) _b = 255; else if (_t <= 19) _b = 0; else _b = 138.5177312231 * ln(_t - 10) - 305.0447927307;
    return make_colour_rgb(clamp(_r, 0, 255), clamp(_g, 0, 255), clamp(_b, 0, 255));
}

/// @function hal__luma(colour)
/// @description Internal. Perceived brightness 0..1.
function hal__luma(_c) { return (0.2126 * colour_get_red(_c) + 0.7152 * colour_get_green(_c) + 0.0722 * colour_get_blue(_c)) / 255; }

/// @function hal__shift(colour, degrees)
/// @description Internal. The same colour with its hue turned, for a chromatic fringe.
function hal__shift(_c, _deg) {
    var _h = colour_get_hue(_c) + _deg * 255 / 360;
    while (_h < 0) _h += 255; while (_h >= 255) _h -= 255;
    return make_colour_hsv(_h, colour_get_saturation(_c), colour_get_value(_c));
}

/// @function hal__quant(colour)
/// @description Internal. The nearest of the retro kit's 12 colours.
function hal__quant(_c) {
    static _pal = [ #FFFFFF, #FFEC9E, #FFB347, #FF6B57, #FF3D8B, #B66DFF, #5C7CFF, #38C6FF, #4CF0B4, #8DF04C, #6E6A86, #1D2B53];
    var _r = colour_get_red(_c), _g = colour_get_green(_c), _b = colour_get_blue(_c), _best = _pal[0], _bd = 1000000000;
    for (var _i = 0; _i < array_length(_pal); _i++) {
        var _q = _pal[_i], _dr = _r - colour_get_red(_q), _dg = _g - colour_get_green(_q), _db = _b - colour_get_blue(_q);
        var _dd = _dr * _dr * 2 + _dg * _dg * 4 + _db * _db;
        if (_dd < _bd) { _bd = _dd; _best = _q; }
    }
    return _best;
}

/// @function hal__tone(colour, design)
/// @description Internal. A colour as this lens renders it: green phosphor for night vision, 12 colours for the retro kit, else as is.
function hal__tone(_c, _K) {
    if (_K.mono >= 0) return merge_colour(c_black, _K.mono, clamp(hal__luma(_c) * 1.25, 0.2, 1));
    if (_K.pixel > 0) return hal__quant(_c);
    return _c;
}

/// @function hal__kits_build()
/// @description Internal. The eight lens kits. Sizes are fractions of the frame's short side; gains are additive alpha.
/// A ghost row is [t along the axis (0 at the light, 1 at the frame's centre, 2 mirrored), radius, alpha, coat index, style].
/// Ghost styles: 0 lit polygon with a bright rim, 1 hollow rim, 2 soft disc, 3 doughnut.
function hal__kits_build() {
    var _K = {};
    _K.vintage = {
        title: "Vintage Prime", line: "a single-coated prime from the 1970s: hexagon ghosts in amber and green, a rainbow arc",
        blades: 6, round: 0.08, rot: 17, squeeze: 1, ghostTint: 0.10, mono: -1, pixel: 0, grade: -1,
        coat: [ #FFB347, #7DE08A, #FF6FA8, #62C7FF, #FFE28A],
        core: { s: 0.032, g: 1 }, bloom: { s: 0.44, g: 0.46, pow: 2.5, tint: #FFC98A, mix: 0.30 },
        spike: { g: 0.62, len: 0.26, w: 0.0052, count: 0, jit: 0.22 },
        ghosts: [[0.42, 0.018, 0.26, 3, 0], [0.62, 0.040, 0.15, 1, 0], [0.86, 0.026, 0.20, 0, 1], [1.14, 0.058, 0.12, 2, 0], [1.34, 0.022, 0.26, 4, 0], [1.56, 0.088, 0.085, 1, 0], [1.82, 0.046, 0.15, 0, 1], [2.22, 0.125, 0.065, 3, 0]],
        rings: [{ g: 0.26, r: 0.235, w: 0.020, arc: 0.40, at: 0, chroma: 1 }],
        streaks: [{ g: 0.10, len: 0.26, th: 0.0048, col: -1, off: 0 }],
        veil: { g: 0.13, col: #FFD9A8, reach: 0.95 }, dirt: { n: 34, g: 0.30, size: 0.011, seed: 71, reach: 0.30 },
        sparks: { n: 0, g: 0, r: 0.2, size: 0.012 }, scan: 0, noise: 0
    };
    _K.anamorphic = {
        title: "Anamorphic Cinema", line: "a squeezed cinema lens: a long blue streak across the frame, tall oval ghosts",
        blades: 0, round: 1, rot: 0, squeeze: 0.56, ghostTint: 0.05, mono: -1, pixel: 0, grade: -1,
        coat: [ #3F9BFF, #7A6BFF, #3FE0E6, #A9C8FF, #5F7BFF],
        core: { s: 0.026, g: 1 }, bloom: { s: 0.30, g: 0.34, pow: 2.8, tint: #79B8FF, mix: 0.45 },
        spike: { g: 0, len: 0, w: 0, count: 0, jit: 0 },
        ghosts: [[0.50, 0.040, 0.11, 0, 2], [0.78, 0.024, 0.20, 2, 1], [1.20, 0.072, 0.09, 1, 1], [1.46, 0.030, 0.16, 3, 2], [1.76, 0.104, 0.06, 0, 1], [2.10, 0.052, 0.11, 4, 2]],
        rings: [],
        streaks: [{ g: 0.88, len: 0.92, th: 0.0048, col: #6FB7FF, off: 0 }, { g: 0.32, len: 0.52, th: 0.022, col: #3C86FF, off: 0 }, { g: 0.16, len: 0.34, th: 0.0035, col: #8FD0FF, off: 0.020 }, { g: 0.16, len: 0.34, th: 0.0035, col: #8FD0FF, off: -0.020 }],
        veil: { g: 0.06, col: #6FA6FF, reach: 0.8 }, dirt: { n: 0, g: 0, size: 0.01, seed: 11, reach: 0.25 },
        sparks: { n: 0, g: 0, r: 0.2, size: 0.012 }, scan: 0, noise: 0
    };
    _K.phone = {
        title: "Cheap Phone", line: "a tiny phone lens: a violet wash, one hard green blob mirrored, a greasy thumbprint of dust",
        blades: 0, round: 1, rot: 0, squeeze: 1, ghostTint: 0, mono: -1, pixel: 0, grade: -1,
        coat: [ #5CFF9E, #A06BFF, #FF5CA8, #5CFFE0],
        core: { s: 0.056, g: 1 }, bloom: { s: 0.34, g: 0.42, pow: 1.7, tint: #B288FF, mix: 0.55 },
        spike: { g: 0, len: 0, w: 0, count: 0, jit: 0 },
        ghosts: [[1.72, 0.052, 0.46, 0, 2], [1.96, 0.020, 0.30, 3, 2], [0.72, 0.016, 0.16, 2, 2]],
        rings: [{ g: 0.17, r: 0.155, w: 0.038, arc: 0.72, at: 180, chroma: 1 }],
        streaks: [], veil: { g: 0.28, col: #A98BFF, reach: 1.25 }, dirt: { n: 56, g: 0.46, size: 0.015, seed: 37, reach: 0.40 },
        sparks: { n: 0, g: 0, r: 0.2, size: 0.012 }, scan: 0, noise: 0
    };
    _K.telescope = {
        title: "Space Telescope", line: "a segmented mirror on three struts: eight dispersed diffraction spikes, Airy rings, a doughnut ghost",
        blades: 6, round: 0, rot: 30, squeeze: 1, ghostTint: 0.25, mono: -1, pixel: 0, grade: -1,
        coat: [ #FFD8B0, #CFE3FF],
        core: { s: 0.020, g: 1 }, bloom: { s: 0.17, g: 0.30, pow: 3.2, tint: #FFE9D0, mix: 0.2 },
        spike: { g: 1.05, len: 0.62, w: 0.0030, count: 0, jit: 0, angles: [30, 90, 150, 210, 270, 330, 0, 180], lens: [1, 1, 1, 1, 1, 1, 0.42, 0.42], rainbow: 1 },
        ghosts: [[1.68, 0.052, 0.13, 1, 3]],
        rings: [{ g: 0.30, r: 0.040, w: 0.0030, arc: 1, at: 0, chroma: 0 }, { g: 0.19, r: 0.066, w: 0.0030, arc: 1, at: 0, chroma: 0 }, { g: 0.11, r: 0.092, w: 0.0030, arc: 1, at: 0, chroma: 0 }],
        streaks: [], veil: { g: 0, col: c_white, reach: 0.5 }, dirt: { n: 0, g: 0, size: 0.01, seed: 5, reach: 0.25 },
        sparks: { n: 0, g: 0, r: 0.2, size: 0.012 }, scan: 0, noise: 0
    };
    _K.crystal = {
        title: "Fantasy Crystal", line: "a lens cut from quartz: prismatic hexagon shards, full rainbow rings and a dust of sparkles",
        blades: 6, round: 0, rot: 0, squeeze: 1, ghostTint: 0, mono: -1, pixel: 0, grade: -1,
        coat: [ #FF6BD6, #6BE6FF, #FFE36B, #A58CFF, #7CFFB0, #FF8C6B],
        core: { s: 0.030, g: 1 }, bloom: { s: 0.30, g: 0.40, pow: 2.3, tint: #D7A8FF, mix: 0.45 },
        spike: { g: 0.72, len: 0.20, w: 0.0060, count: 12, jit: 0.45 },
        ghosts: [[0.38, 0.030, 0.26, 0, 0], [0.66, 0.062, 0.17, 1, 1], [0.92, 0.022, 0.32, 2, 0], [1.20, 0.082, 0.14, 3, 1], [1.46, 0.034, 0.28, 4, 0], [1.74, 0.058, 0.20, 5, 1], [2.06, 0.112, 0.11, 1, 0]],
        rings: [{ g: 0.34, r: 0.150, w: 0.016, arc: 1, at: 0, chroma: 1 }, { g: 0.20, r: 0.285, w: 0.020, arc: 1, at: 0, chroma: 1 }],
        streaks: [], veil: { g: 0.09, col: #E2B8FF, reach: 0.9 }, dirt: { n: 0, g: 0, size: 0.01, seed: 19, reach: 0.25 },
        sparks: { n: 18, g: 0.90, r: 0.30, size: 0.020 }, scan: 0, noise: 0
    };
    _K.pixel = {
        title: "Retro Pixel", line: "a 16-bit flare: every shape snapped to a pixel grid, 12 colours, stepped light",
        blades: 8, round: 0, rot: 0, squeeze: 1, ghostTint: 0, mono: -1, pixel: 180, grade: -1,
        coat: [ #FFB347, #4CF0B4, #FF3D8B, #38C6FF, #B66DFF],
        core: { s: 0.042, g: 1 }, bloom: { s: 0.24, g: 0.34, pow: 2, tint: #FFEC9E, mix: 0.4 },
        spike: { g: 0.80, len: 0.20, w: 0, count: 8, jit: 0 },
        ghosts: [[0.44, 0.022, 0.42, 3, 0], [0.70, 0.044, 0.24, 1, 1], [1.12, 0.066, 0.20, 2, 1], [1.40, 0.022, 0.44, 0, 0], [1.72, 0.088, 0.16, 4, 1], [2.12, 0.044, 0.30, 3, 0]],
        rings: [{ g: 0.42, r: 0.170, w: 0.006, arc: 1, at: 0, chroma: 0 }],
        streaks: [{ g: 0.46, len: 0.22, th: 0.006, col: -1, off: 0 }], veil: { g: 0, col: c_white, reach: 0.5 }, dirt: { n: 0, g: 0, size: 0.01, seed: 3, reach: 0.25 },
        sparks: { n: 0, g: 0, r: 0.2, size: 0.012 }, scan: 0, noise: 0
    };
    _K.nightvision = {
        title: "Night Vision", line: "an image-intensifier tube: green phosphor, a bloomed-out source, scanlines and live noise, and the frame graded green",
        blades: 0, round: 1, rot: 0, squeeze: 1, ghostTint: 0, mono: #63FF7A, pixel: 0, grade: #2FBF46,
        coat: [ #63FF7A, #8CFFA0],
        core: { s: 0.062, g: 1 }, bloom: { s: 0.40, g: 0.66, pow: 2.1, tint: #63FF7A, mix: 0.7 },
        spike: { g: 0, len: 0, w: 0, count: 0, jit: 0 },
        ghosts: [[1.62, 0.040, 0.20, 1, 2]],
        rings: [{ g: 0.10, r: 0.215, w: 0.058, arc: 1, at: 0, chroma: 0 }],
        streaks: [], veil: { g: 0.26, col: #63FF7A, reach: 1.15 }, dirt: { n: 0, g: 0, size: 0.01, seed: 29, reach: 0.25 },
        sparks: { n: 0, g: 0, r: 0.2, size: 0.012 }, scan: 0.34, noise: 0.85
    };
    _K.dream = {
        title: "Dreamy Soft", line: "a mist filter over an old portrait lens: a red halation glow, pastel bokeh, nothing with an edge",
        blades: 0, round: 1, rot: 0, squeeze: 1, ghostTint: 0.15, mono: -1, pixel: 0, grade: -1,
        coat: [ #FFB0C8, #C8B8FF, #FFD8A8, #B0E8FF],
        core: { s: 0.040, g: 0.74 }, bloom: { s: 0.56, g: 0.34, pow: 2.3, tint: #FFB098, mix: 0.55 },
        spike: { g: 0, len: 0, w: 0, count: 0, jit: 0 },
        ghosts: [[0.55, 0.072, 0.10, 0, 2], [0.95, 0.112, 0.070, 1, 2], [1.38, 0.056, 0.13, 2, 2], [1.78, 0.150, 0.055, 3, 2]],
        rings: [{ g: 0.26, r: 0.092, w: 0.066, arc: 1, at: 0, chroma: 2 }],
        streaks: [], veil: { g: 0.13, col: #FFC4B0, reach: 1.15 }, dirt: { n: 0, g: 0, size: 0.01, seed: 41, reach: 0.25 },
        sparks: { n: 0, g: 0, r: 0.2, size: 0.012 }, scan: 0, noise: 0
    };
    return _K;
}

/// @function hal__kinds_build()
/// @description Internal. The ten light kinds. A kind scales each optical class of the lens it looks through, sets its colour and how it behaves.
function hal__kinds_build() {
    var _L = {};
    _L.sun = { title: "Sun", kelvin: 5600, colour: -1, size: 1, elong: 1, radius: 16, flicker: "none", amount: 0, attack: 0, decay: 0, sparkN: 0, ringScale: 1, ringFull: false, g: { core: 1.2, bloom: 1, spike: 1, ghost: 1, ring: 1, streak: 1, veil: 1, dirt: 1, spark: 1 } };
    _L.moon = { title: "Moon", kelvin: 9000, colour: -1, size: 0.56, elong: 1, radius: 12, flicker: "none", amount: 0, attack: 0, decay: 0, sparkN: 0, ringScale: 1.62, ringFull: true, g: { core: 0.72, bloom: 0.46, spike: 0.20, ghost: 0.30, ring: 0.72, streak: 0.30, veil: 0.30, dirt: 0.30, spark: 0.40 } };
    _L.torch = { title: "Torch", kelvin: 1850, colour: -1, size: 0.46, elong: 1, radius: 6, flicker: "flame", amount: 0.30, attack: 0, decay: 0, sparkN: 0, ringScale: 0.7, ringFull: false, g: { core: 0.92, bloom: 0.74, spike: 0.52, ghost: 0.24, ring: 0.22, streak: 0.42, veil: 0.09, dirt: 0.12, spark: 0.70 } };
    _L.lantern = { title: "Lantern", kelvin: 2650, colour: -1, size: 0.58, elong: 1, radius: 8, flicker: "breathe", amount: 0.12, attack: 0, decay: 0, sparkN: 0, ringScale: 0.5, ringFull: true, g: { core: 0.62, bloom: 1.05, spike: 0, ghost: 0.14, ring: 0.62, streak: 0.10, veil: 0.12, dirt: 0.08, spark: 0.28 } };
    _L.neon = { title: "Neon tube", kelvin: 0, colour: #FF2F7E, size: 0.40, elong: 3.4, radius: 8, flicker: "hum", amount: 0.06, attack: 0, decay: 0, sparkN: 0, ringScale: 0.8, ringFull: false, g: { core: 0.88, bloom: 0.92, spike: 0, ghost: 0.20, ring: 0, streak: 0.86, veil: 0.14, dirt: 0.12, spark: 0 } };
    _L.muzzle = { title: "Muzzle flash", kelvin: 2300, colour: -1, size: 0.36, elong: 1, radius: 4, flicker: "none", amount: 0, attack: 0.008, decay: 0.095, sparkN: 5, ringScale: 0.6, ringFull: false, g: { core: 1.5, bloom: 0.62, spike: 2.4, ghost: 0.40, ring: 0, streak: 0.16, veil: 0.20, dirt: 0.40, spark: 0.9 } };
    _L.orb = { title: "Magic orb", kelvin: 0, colour: #6E8CFF, size: 0.44, elong: 1, radius: 8, flicker: "pulse", amount: 0.22, attack: 0, decay: 0, sparkN: 9, ringScale: 0.72, ringFull: true, g: { core: 1.0, bloom: 0.92, spike: 0.36, ghost: 0.26, ring: 0.95, streak: 0.22, veil: 0.14, dirt: 0.10, spark: 1.6 } };
    _L.eye = { title: "Eye glint", kelvin: 0, colour: #FFD24D, size: 0.16, elong: 1, radius: 2, flicker: "twinkle", amount: 0.55, attack: 0, decay: 0, sparkN: 0, ringScale: 0.4, ringFull: false, g: { core: 1.0, bloom: 0.40, spike: 0.34, ghost: 0, ring: 0, streak: 0.62, veil: 0, dirt: 0, spark: 0 } };
    _L.headlamp = { title: "Headlamp", kelvin: 8200, colour: -1, size: 0.74, elong: 1.5, radius: 7, flicker: "none", amount: 0, attack: 0, decay: 0, sparkN: 0, ringScale: 0.85, ringFull: false, g: { core: 1.32, bloom: 0.90, spike: 0.18, ghost: 0.70, ring: 0.30, streak: 2.2, veil: 0.42, dirt: 0.72, spark: 0 } };
    _L.explosion = { title: "Explosion", kelvin: 2300, colour: -1, size: 1.34, elong: 1, radius: 20, flicker: "none", amount: 0, attack: 0.035, decay: 0.72, sparkN: 6, ringScale: 1.35, ringFull: true, g: { core: 1.5, bloom: 1.35, spike: 0.92, ghost: 0.82, ring: 1.4, streak: 0.82, veil: 1.65, dirt: 1, spark: 1.3 } };
    return _L;
}

/// @function hal_kits()
/// @description The lens kit names, in catalogue order (your own kits from hal_kit_define follow).
/// @returns {Array<String>}
function hal_kits() {
    hal__init();
    var _o = array_create(array_length(global.hal_t_kit_order));
    array_copy(_o, 0, global.hal_t_kit_order, 0, array_length(global.hal_t_kit_order));
    return _o;
}

/// @function hal_kinds()
/// @description The light kind names, in catalogue order.
/// @returns {Array<String>}
function hal_kinds() {
    hal__init();
    var _o = array_create(array_length(global.hal_t_kind_order));
    array_copy(_o, 0, global.hal_t_kind_order, 0, array_length(global.hal_t_kind_order));
    return _o;
}

/// @function hal_kit_title(kit)
/// @description A lens kit's display name, or "" for a name that is not a kit.
/// @param {String} kit A name from hal_kits.
/// @returns {String}
function hal_kit_title(_kit) { hal__init(); if (is_string(_kit) && variable_struct_exists(global.hal_t_kits, _kit)) return global.hal_t_kits[$ _kit].title; return ""; }

/// @function hal_kit_line(kit)
/// @description One sentence describing a lens kit, or "" for a name that is not a kit.
/// @param {String} kit A name from hal_kits.
/// @returns {String}
function hal_kit_line(_kit) { hal__init(); if (is_string(_kit) && variable_struct_exists(global.hal_t_kits, _kit)) return global.hal_t_kits[$ _kit].line; return ""; }

/// @function hal_kind_title(kind)
/// @description A light kind's display name, or "" for a name that is not a kind.
/// @param {String} kind A name from hal_kinds.
/// @returns {String}
function hal_kind_title(_kind) { hal__init(); if (is_string(_kind) && variable_struct_exists(global.hal_t_kinds, _kind)) return global.hal_t_kinds[$ _kind].title; return ""; }

/// @function hal_kit_define(name, base, overrides)
/// @description Make your own lens from an existing kit: anything you do not name is inherited. Top-level fields replace; a field whose
/// value is a struct (core, bloom, spike, veil, dirt, sparks) merges field by field. Redefining a name replaces it and clears the design cache.
/// @param {String} name The new kit's name.
/// @param {String} base An existing kit to start from.
/// @param {Struct} overrides The fields that differ, e.g. { blades: 7, coat: [c_red, c_orange] }.
/// @returns {Bool} false when the name or the base is not usable.
function hal_kit_define(_name, _base, _over) {
    hal__init();
    if (!is_string(_name) || string_length(_name) == 0 || !is_string(_base) || !variable_struct_exists(global.hal_t_kits, _base)) return false;
    var _src = global.hal_t_kits[$ _base], _new = {}, _ks = variable_struct_get_names(_src);
    for (var _i = 0; _i < array_length(_ks); _i++) _new[$ _ks[_i]] = _src[$ _ks[_i]];
    _new.title = _name;
    if (is_struct(_over)) {
        var _os = variable_struct_get_names(_over);
        for (var _i = 0; _i < array_length(_os); _i++) {
            var _f = _os[_i], _v = _over[$ _f], _old = variable_struct_exists(_new, _f) ? _new[$ _f] : undefined;
            if (is_struct(_v) && is_struct(_old)) {
                var _m = {}, _ok = variable_struct_get_names(_old), _vk = variable_struct_get_names(_v);
                for (var _j = 0; _j < array_length(_ok); _j++) _m[$ _ok[_j]] = _old[$ _ok[_j]];
                for (var _j = 0; _j < array_length(_vk); _j++) _m[$ _vk[_j]] = _v[$ _vk[_j]];
                _new[$ _f] = _m;
            } else _new[$ _f] = _v;
        }
    }
    var _known = variable_struct_exists(global.hal_t_kits, _name);
    global.hal_t_kits[$ _name] = _new;
    if (!_known) array_push(global.hal_t_kit_order, _name);
    global.hal_t_designs = {};
    global.hal_t_design_count = 0;
    return true;
}

/// @function hal__spike_count(blades)
/// @description Internal. A real aperture's law: an even number of blades gives that many spikes, an odd number gives twice as many.
function hal__spike_count(_blades) { if (_blades <= 0) return 0; return ((_blades mod 2) == 0) ? _blades : _blades * 2; }

/// @function hal__poly(blades, round, rot)
/// @description Internal. A unit ghost outline: the aperture polygon, rounded toward a circle by round (0..1). Convex, so a fan fills it.
function hal__poly(_blades, _round, _rot) {
    var _xs = [], _ys = [];
    if (_blades <= 0) {
        for (var _i = 0; _i < 18; _i++) { array_push(_xs, cos(_i * 2 * pi / 18)); array_push(_ys, sin(_i * 2 * pi / 18)); }
        return { xs: _xs, ys: _ys, n: 18 };
    }
    var _sub = (_round > 0.001) ? 3 : 1, _n = _blades * _sub, _r0 = degtorad(_rot), _sect = 2 * pi / _blades;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _i * 2 * pi / _n, _m = _a mod _sect;
        var _edge = cos(pi / _blades) / cos(_m - pi / _blades);
        var _rr = lerp(_edge, 1, _round);
        array_push(_xs, cos(_a + _r0) * _rr); array_push(_ys, sin(_a + _r0) * _rr);
    }
    return { xs: _xs, ys: _ys, n: _n };
}

/// @function hal__el_radial(radius, alpha, pow, inner, outer, sx, sy, angle)
/// @description Internal. A radial falloff element: ring radii denser toward the centre, alpha (1 - r)^pow.
function hal__el_radial(_r, _a, _pow, _inner, _outer, _sx, _sy, _ang) {
    var _n = 5, _rr = array_create(_n), _aa = array_create(_n), _cc = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _u = _i / (_n - 1), _p = power(_u, 1.6);
        _rr[_i] = _p; _aa[_i] = _a * power(1 - _p, _pow); _cc[_i] = merge_colour(_inner, _outer, _u);
    }
    return { ty: HAL_EL_RADIAL, cls: "radial", r: _r, sx: _sx, sy: _sy, cr: dcos(_ang), sr: dsin(_ang), rr: _rr, aa: _aa, cc: _cc, n: _n };
}

/// @function hal_design(kit, kind, [options])
/// @description Compile a kit and a kind into a flare design (cached). Options: colour, kelvin, size (x the kind's own), elong, angle.
/// Designs are plain data: compiling allocates no graphics resource. You rarely need to call this: lights and hal_flare_draw do.
/// @param {String} kit A lens kit name.
/// @param {String} kind A light kind name.
/// @param {Struct} [options] colour, kelvin, size, elong, angle.
/// @returns {Struct} A design, or undefined when kit or kind is not a known name.
function hal_design(_kit, _kind, _opt = undefined) {
    hal__init();
    if (!is_string(_kit) || !variable_struct_exists(global.hal_t_kits, _kit)) return undefined;
    if (!is_string(_kind) || !variable_struct_exists(global.hal_t_kinds, _kind)) return undefined;
    var _col = hal__num(hal__opt(_opt, "colour", -1), -1);
    var _kel = hal__num(hal__opt(_opt, "kelvin", 0), 0);
    var _size = clamp(hal__num(hal__opt(_opt, "size", 1), 1), 0.05, 8);
    var _elong = clamp(hal__num(hal__opt(_opt, "elong", -1), -1), -1, 16);
    var _ang = hal__num(hal__opt(_opt, "angle", 0), 0);
    var _key = _kit + "|" + _kind + "|" + string(_col) + "|" + string(_kel) + "|" + string(_size) + "|" + string(_elong) + "|" + string(_ang);
    if (variable_struct_exists(global.hal_t_designs, _key)) return global.hal_t_designs[$ _key];
    var _D = hal__compile(_kit, _kind, _col, _kel, _size, _elong, _ang);
    if (global.hal_t_design_count >= 512) { global.hal_t_designs = {}; global.hal_t_design_count = 0; }   // a colour animated every frame cannot grow this without bound
    global.hal_t_designs[$ _key] = _D;
    global.hal_t_design_count += 1;
    return _D;
}

/// @function hal__compile(kit, kind, colour, kelvin, size, elong, angle)
/// @description Internal. Pure: the optical elements of one kit x kind pair, each with its colours and gains resolved.
function hal__compile(_kit, _kind, _col, _kel, _size, _elongIn, _ang) {
    var _K = global.hal_t_kits[$ _kit], _L = global.hal_t_kinds[$ _kind], _g = _L.g;
    var _lc = _col;
    if (_lc < 0) { if (_kel > 0) _lc = hal_kelvin(_kel); else if (_L.colour >= 0) _lc = _L.colour; else _lc = hal_kelvin(_L.kelvin); }
    var _S = _size * _L.size, _els = [], _elong = (_elongIn > 0) ? _elongIn : _L.elong;
    var _pixel = (_K.pixel > 0), _hot = merge_colour(_lc, c_white, 0.72);
    var _rng = hal_rng(hal__hash(_kit) * 13 + hal__hash(_kind));

    // veiling glare: the whole frame lifted, strongest near the source
    var _vg = _K.veil.g * _g.veil;
    if (_vg >= 0.02) array_push(_els, { ty: HAL_EL_VEIL, cls: "veil", a: _vg, reach: _K.veil.reach, col: hal__tone(merge_colour(_K.veil.col, _lc, 0.35), _K) });

    // bloom: the light scattering around the source, its colour pulled toward the kit's glass
    var _bg = _K.bloom.g * _g.bloom;
    if (_bg >= 0.01) {
        var _inner = hal__tone(merge_colour(_lc, c_white, 0.30), _K), _outer = hal__tone(merge_colour(_lc, _K.bloom.tint, _K.bloom.mix), _K);
        var _e = hal__el_radial(_K.bloom.s * power(_S, 0.8), _bg, _K.bloom.pow, _inner, _outer, _elong, 1, _ang);
        _e.cls = "bloom"; array_push(_els, _e);
    }

    // rings: a rainbow arc, Airy rings, a halation glow; chroma 0 plain, 1 a spectrum, 2 a warm halation red
    var _gr = _g.ring;
    for (var _i = 0; _i < array_length(_K.rings) && _gr > 0; _i++) {
        var _R = _K.rings[_i], _a = _R.g * _gr;
        if (_a < 0.06) continue;
        var _cols;
        if (_R.chroma == 1) _cols = [hal__tone(#6A5CFF, _K), hal__tone(#3CE0B4, _K), hal__tone(#FFE05C, _K), hal__tone(#FF5C5C, _K)];
        else if (_R.chroma == 2) { var _h1 = hal__tone(merge_colour(_lc, #FF5A3C, 0.75), _K); _cols = [_h1, _h1, hal__tone(#FF3C28, _K), hal__tone(#FF3C28, _K)]; }
        else { var _h2 = hal__tone(merge_colour(_lc, c_white, 0.25), _K); _cols = [_h2, _h2, _h2, _h2]; }
        array_push(_els, { ty: HAL_EL_RING, cls: "ring", r: _R.r * _L.ringScale * power(_S, 0.35), w: _R.w, a: _a, arc: _L.ringFull ? 1 : _R.arc, at: _R.at, cols: _cols });
    }

    // ghosts: reflections between the glass, strung along the axis through the frame's centre, shaped by the aperture
    var _P = hal__poly(_K.blades, _K.round, _K.rot), _gscale = lerp(0.72, 1, clamp(_S, 0, 1));
    if (_g.ghost > 0) for (var _i = 0; _i < array_length(_K.ghosts); _i++) {
        var _G = _K.ghosts[_i], _a = _G[2] * _g.ghost;
        if (_a < 0.035) continue;
        var _c = _K.coat[_G[3] mod array_length(_K.coat)];
        _c = merge_colour(_c, _lc, _K.ghostTint);
        var _rim = hal__tone(hal__shift(_c, 26), _K);
        array_push(_els, { ty: HAL_EL_GHOST, cls: "ghost", t: _G[0], r: _G[1] * _gscale, sx: _K.squeeze, a: _a, style: _G[4], c: hal__tone(_c, _K), rim: _rim, xs: _P.xs, ys: _P.ys, n: _P.n, metric: _K.blades });
    }

    // streaks: the anamorphic line, thin and long
    for (var _i = 0; _i < array_length(_K.streaks); _i++) {
        var _T = _K.streaks[_i], _a = _T.g * _g.streak;
        if (_a < 0.012) continue;
        var _tc = (_T.col >= 0) ? merge_colour(_T.col, _lc, 0.25) : _lc;
        array_push(_els, { ty: HAL_EL_STREAK, cls: "streak", len: _T.len * lerp(0.45, 1, clamp(_S, 0, 1)), th: _T.th, a: _a, col: hal__tone(_tc, _K), off: _T.off, cr: dcos(_ang), sr: dsin(_ang) });
    }

    // spikes: diffraction from the aperture blades, an even count gives that many, an odd count twice as many
    var _sg = _K.spike.g * _g.spike;
    var _hasAngles = variable_struct_exists(_K.spike, "angles");
    var _nsp = _hasAngles ? array_length(_K.spike.angles) : ((_K.spike.count > 0) ? _K.spike.count : hal__spike_count(_K.blades));
    if (_sg >= 0.02 && _nsp > 0) {
        var _ca = array_create(_nsp), _sa = array_create(_nsp), _ln = array_create(_nsp), _jit = _K.spike.jit;
        for (var _i = 0; _i < _nsp; _i++) {
            var _deg = _hasAngles ? _K.spike.angles[_i] : (_K.rot + _i * 360 / _nsp);
            var _j = hal_rand(_rng);
            _ca[_i] = dcos(_deg); _sa[_i] = dsin(_deg);
            _ln[_i] = _K.spike.len * power(_S, 0.7) * (_hasAngles ? _K.spike.lens[_i] : (1 - _jit * _j));
        }
        var _rb = variable_struct_exists(_K.spike, "rainbow") ? _K.spike.rainbow : 0;
        array_push(_els, { ty: HAL_EL_SPIKES, cls: "spike", n: _nsp, ca: _ca, sa: _sa, ln: _ln, w: _K.spike.w, a: _sg, col: hal__tone(_hot, _K), rainbow: _rb });
        if (!_pixel) {
            // a wider, fainter root under each needle, so a spike has a body and not only a hairline
            var _ln2 = array_create(_nsp);
            for (var _i = 0; _i < _nsp; _i++) _ln2[_i] = _ln[_i] * 0.42;
            array_push(_els, { ty: HAL_EL_SPIKES, cls: "spike", n: _nsp, ca: _ca, sa: _sa, ln: _ln2, w: _K.spike.w * 3, a: _sg * 0.30, col: hal__tone(_lc, _K), rainbow: 0 });
        }
    }

    // core: the source itself, burnt to white
    var _cg = _K.core.g * _g.core;
    if (_cg >= 0.01) {
        var _e = hal__el_radial(_K.core.s * power(_S, 0.8), min(_cg, 1.4), 1.25, hal__tone(c_white, _K), hal__tone(_hot, _K), _elong, 1, _ang);
        _e.cls = "core"; array_push(_els, _e);
    }

    // dirt: dust on the front glass, invisible until a bright source crosses it
    var _dg = _K.dirt.g * _g.dirt, _dn = floor(_K.dirt.n * clamp(_g.dirt, 0.3, 1));
    if (_dg >= 0.05 && _dn > 0) {
        var _dr = hal_rng(_K.dirt.seed), _xs = array_create(_dn), _ys = array_create(_dn), _rs = array_create(_dn), _as = array_create(_dn);
        for (var _i = 0; _i < _dn; _i++) {
            var _u0 = hal_rand(_dr); var _u1 = hal_rand(_dr); var _u2 = hal_rand(_dr); var _u3 = hal_rand(_dr);
            _xs[_i] = _u0; _ys[_i] = _u1;
            _rs[_i] = _K.dirt.size * (0.35 + 1.5 * _u2 * _u2);
            _as[_i] = _dg * (0.45 + 0.55 * _u3) / (0.6 + _u2);
        }
        array_push(_els, { ty: HAL_EL_DIRT, cls: "dirt", n: _dn, xs: _xs, ys: _ys, rs: _rs, as: _as, reach: _K.dirt.reach * lerp(0.6, 1, clamp(_S, 0, 1)), col: hal__tone(merge_colour(_lc, c_white, 0.45), _K) });
    }

    // sparkles: twinkling stars around the source, always for a magic orb, densely in the crystal kit
    var _sn = floor(_K.sparks.n * clamp(_g.spark, 0, 1)) + _L.sparkN;
    if (_sn > 0) {
        var _sr = hal_rng(hal__hash(_kit) + _L.sparkN * 17 + 3), _ang2 = array_create(_sn), _dst = array_create(_sn), _sz = array_create(_sn), _ph = array_create(_sn), _rt = array_create(_sn), _cs = array_create(_sn);
        var _spr = (_K.sparks.n > 0) ? _K.sparks.r : 0.22, _ssz = _K.sparks.size;
        for (var _i = 0; _i < _sn; _i++) {
            var _u0 = hal_rand(_sr); var _u1 = hal_rand(_sr); var _u2 = hal_rand(_sr); var _u3 = hal_rand(_sr); var _u4 = hal_rand(_sr);
            _ang2[_i] = _u0 * 2 * pi; _dst[_i] = _spr * (0.25 + 0.75 * _u1); _sz[_i] = _ssz * (0.55 + 0.9 * _u2 * _u2); _ph[_i] = _u3 * 6.283; _rt[_i] = 1.6 + 3.4 * _u4;
            _cs[_i] = hal__tone((_K.sparks.n > 0) ? _K.coat[_i mod array_length(_K.coat)] : merge_colour(_lc, c_white, 0.4), _K);
        }
        array_push(_els, { ty: HAL_EL_SPARK, cls: "spark", n: _sn, ang: _ang2, dst: _dst, sz: _sz, ph: _ph, rate: _rt, cols: _cs, a: max(_K.sparks.g, 0.8) * clamp(_g.spark, 0.2, 1.2) });
    }

    // the tube's own marks: scanlines over the bloom, and live noise
    if (_K.scan > 0) array_push(_els, { ty: HAL_EL_SCAN, cls: "scan", a: _K.scan * clamp(_g.bloom, 0, 1), r: 0.20 * power(_S, 0.7), col: hal__tone(_hot, _K) });
    if (_K.noise > 0) array_push(_els, { ty: HAL_EL_NOISE, cls: "noise", a: _K.noise, r: 0.34 * power(_S, 0.5), n: 42, col: hal__tone(c_white, _K) });

    return { kit: _kit, kind: _kind, els: _els, n: array_length(_els), lc: _lc, pixel: _K.pixel, grade: _K.grade };
}

/// @function hal_axis_point(lightX, lightY, t, frameX, frameY, frameW, frameH)
/// @description Where a ghost at t sits: the axis runs from the light through the frame's centre (t 1), and on to the mirror point (t 2).
/// @returns {Struct} { x, y }
function hal_axis_point(_lx, _ly, _t, _fx, _fy, _fw, _fh) {
    var _x = hal__num(_lx, 0), _y = hal__num(_ly, 0), _tt = hal__num(_t, 0);
    var _cx = hal__num(_fx, 0) + hal__num(_fw, 0) * 0.5, _cy = hal__num(_fy, 0) + hal__num(_fh, 0) * 0.5;
    return { x: _x + (_cx - _x) * _tt, y: _y + (_cy - _y) * _tt };
}

/// @function hal__flicker(mode, t, seed, amount)
/// @description Internal. Pure: a light's brightness multiplier at time t.
function hal__flicker(_mode, _t, _seed, _amt) {
    switch (_mode) {
        case "flame": var _n = 0.5 * sin(_t * 11.3 + _seed) + 0.3 * sin(_t * 23.7 + _seed * 2.1) + 0.2 * sin(_t * 47.1 + _seed * 3.3); return clamp(1 - _amt * (0.5 + 0.5 * _n), 0, 1);
        case "breathe": return 1 - _amt * (0.5 + 0.5 * sin(_t * 1.7 + _seed));
        case "hum": var _b = floor(_t * 9 + _seed), _hn = frac(sin(_b * 12.9898) * 43758.5453); return ((_hn < 0.05) ? 0.22 : 1) * (1 - _amt * (0.5 + 0.5 * sin(_t * 37.7)));
        case "pulse": var _p = 0.5 + 0.5 * sin(_t * 3.1 + _seed); return 1 - _amt * (1 - _p * _p);
        case "twinkle": var _p = 0.5 + 0.5 * sin(_t * 2.3 + _seed); return 1 - _amt * (1 - _p * _p * _p);
        default: return 1;
    }
}

/// @function hal__env(age, attack, decay)
/// @description Internal. Pure: a one-shot's brightness at an age: a fast rise, then a curved fall to exactly zero at attack + decay.
function hal__env(_age, _attack, _decay) {
    if (_decay <= 0) return 1;
    if (_age < _attack) return _age / max(_attack, 0.0001);
    var _u = (_age - _attack) / _decay;
    if (_u >= 1) return 0;
    return power(1 - _u, 2.2);
}

/// @function hal__vis_step(v, target, dt, attack, release)
/// @description Internal. Pure: visibility eases toward its target, opening at attack seconds and closing at release seconds.
function hal__vis_step(_v, _target, _dt, _attack, _release) {
    if (_dt <= 0) return _v;
    var _rate = (_target > _v) ? _attack : _release;
    if (_rate <= 0) return _target;
    return _v + (_target - _v) * (1 - exp(-_dt / _rate));
}

/// @function hal__disc(n)
/// @description Internal. n sample offsets across a unit disc, the first at the centre, on a golden-angle spiral (cached).
function hal__disc(_n) {
    var _k = string(_n);
    if (variable_struct_exists(global.hal_t_discs, _k)) return global.hal_t_discs[$ _k];
    var _xs = array_create(_n), _ys = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _r = (_n <= 1) ? 0 : sqrt(_i / (_n - 1)), _a = _i * 2.39996323;
        _xs[_i] = cos(_a) * _r; _ys[_i] = sin(_a) * _r;
    }
    var _D = { xs: _xs, ys: _ys, n: _n };
    global.hal_t_discs[$ _k] = _D;
    return _D;
}

/// @function hal__occluder(spec, owner)
/// @description Internal. Normalise an occluder description into the form hal__covered reads, or undefined when it is not one.
/// A callback written inside the spec's own struct literal is bound to that struct by GameMaker, so it is rebound to the caller.
function hal__occluder(_oc, _owner) {
    if (!is_struct(_oc) || !variable_struct_exists(_oc, "mode") || !is_string(_oc.mode)) return undefined;
    var _R = { mode: _oc.mode, precise: hal__opt(_oc, "precise", false) == true };
    switch (_oc.mode) {
        case "objects": case "line":
            var _ob = hal__opt(_oc, "objects", undefined);
            if (is_undefined(_ob)) return undefined;
            _R.objects = is_array(_ob) ? _ob : [_ob];
            if (array_length(_R.objects) == 0) return undefined;
            if (_oc.mode == "line") {
                _R.from = hal__opt(_oc, "from", undefined);
                if (is_undefined(_R.from) || (is_array(_R.from) && array_length(_R.from) < 2)) return undefined;
            }
            return _R;
        case "tiles":
            var _tm = hal__opt(_oc, "tilemaps", undefined), _out = [];
            if (is_undefined(_tm)) return undefined;
            if (!is_array(_tm)) _tm = [_tm];
            for (var _i = 0; _i < array_length(_tm); _i++) {
                var _e = _tm[_i];
                if (is_string(_e)) { var _lid = layer_get_id(_e); if (_lid != -1) { var _map = layer_tilemap_get_id(_lid); if (_map != -1) array_push(_out, _map); } }
                else array_push(_out, _e);
            }
            if (array_length(_out) == 0) return undefined;
            _R.tilemaps = _out;
            return _R;
        case "mask":
            _R.surface = hal__opt(_oc, "surface", -1);
            _R.scale = max(hal__num(hal__opt(_oc, "scale", 1), 1), 0.0001);
            _R.ox = hal__num(hal__opt(_oc, "ox", 0), 0); _R.oy = hal__num(hal__opt(_oc, "oy", 0), 0);
            _R.threshold = clamp(hal__num(hal__opt(_oc, "threshold", 0.5), 0.5), 0, 1);
            _R.lost = false;
            return _R;
        case "function":
            var _fn = hal__opt(_oc, "fn", undefined);
            if (!is_method(_fn) && !(is_numeric(_fn) && script_exists(_fn))) return undefined;
            if (is_method(_fn) && method_get_self(_fn) == _oc && !is_undefined(_owner)) _fn = method(_owner, method_get_index(_fn));
            _R.fn = _fn;
            return _R;
        default: return undefined;
    }
}

/// @function hal__covered(occluder, x, y)
/// @description Internal. Does this occluder cover the point? A mask surface that has been lost covers nothing and is counted, never a crash.
function hal__covered(_oc, _x, _y) {
    switch (_oc.mode) {
        case "objects":
            var _ob = _oc.objects;
            for (var _i = 0; _i < array_length(_ob); _i++) if (collision_point(_x, _y, _ob[_i], _oc.precise, false) != noone) return true;
            return false;
        case "line":
            var _ob = _oc.objects, _fx = 0, _fy = 0, _fr = _oc.from;
            if (is_array(_fr)) { _fx = _fr[0]; _fy = _fr[1]; }
            else if (instance_exists(_fr)) { _fx = _fr.x; _fy = _fr.y; }
            else return false;
            for (var _i = 0; _i < array_length(_ob); _i++) if (collision_line(_fx, _fy, _x, _y, _ob[_i], _oc.precise, false) != noone) return true;
            return false;
        case "tiles":
            var _tm = _oc.tilemaps;
            for (var _i = 0; _i < array_length(_tm); _i++) { var _v = tilemap_get_at_pixel(_tm[_i], _x, _y); if (_v > 0 && tile_get_index(_v) != 0) return true; }
            return false;
        case "mask":
            if (!surface_exists(_oc.surface)) { _oc.lost = true; return false; }
            _oc.lost = false;
            var _c = surface_getpixel_ext(_oc.surface, (_x - _oc.ox) * _oc.scale, (_y - _oc.oy) * _oc.scale);
            return ((_c >> 24) & 255) / 255 >= _oc.threshold;
        case "function":
            return _oc.fn(_x, _y) == true;
    }
    return false;
}

/// @function hal__cover(light, occluder)
/// @description Internal. The fraction of a light's disc that an occluder covers, 0..1.
function hal__cover(_L, _oc, _samples) {
    var _D = hal__disc(_samples), _hit = 0, _r = _L.radius, _xs = _D.xs, _ys = _D.ys;
    for (var _i = 0; _i < _samples; _i++) if (hal__covered(_oc, _L.x + _xs[_i] * _r, _L.y + _ys[_i] * _r)) _hit++;
    return _hit / _samples;
}

/// @function hal__camera(value)
/// @description Internal. A usable camera id, or -1 (follow view 0). GameMaker throws on a bad id, so it is probed here, once.
function hal__camera(_c) {
    if (!is_numeric(_c) || _c == -1) return -1;
    try { if (camera_get_view_width(_c) > 0) return _c; } catch (_e) { return -1; }
    return -1;
}

/// @function hal__is_world(value)
/// @description Internal. Is this a world from hal_world_create?
function hal__is_world(_W) { return is_struct(_W) && variable_struct_exists(_W, "lights") && variable_struct_exists(_W, "halWorld"); }

/// @function hal__is_light(value)
/// @description Internal. Is this a light from hal_light_add or hal_flash?
function hal__is_light(_L) { return is_struct(_L) && variable_struct_exists(_L, "halLight"); }

/// @function hal_world_create([options])
/// @description One world per camera or per screen. Options: kit (default "vintage"), occluder, camera, samples (disc samples per light, default 12),
/// attack and release (seconds visibility takes to open and close, defaults 0.06 and 0.14), gain (every light's brightness, default 1), veil, dirt and grade
/// (each default true; false turns that class off for the whole world).
/// Occluders: { mode: "objects", objects, precise } · { mode: "tiles", tilemaps } (ids or layer names) · { mode: "mask", surface, scale, ox, oy, threshold } ·
/// { mode: "line", objects, from, precise } (from = [x, y] or an instance) · { mode: "function", fn } (fn(x, y) returns true when covered).
/// @param {Struct} [options]
/// @returns {Struct} The world. It owns no graphics resource and needs no freeing.
function hal_world_create(_opt = undefined) {
    hal__init();
    var _kit = hal__opt(_opt, "kit", "vintage");
    if (!is_string(_kit) || !variable_struct_exists(global.hal_t_kits, _kit)) _kit = "vintage";
    return {
        halWorld: true, kit: _kit, lights: [], glints: [], t: 0, paused: false,
        occluder: hal__occluder(hal__opt(_opt, "occluder", undefined), self),
        camera: hal__camera(hal__opt(_opt, "camera", -1)),
        samples: clamp(floor(hal__num(hal__opt(_opt, "samples", 12), 12)), 1, 48),
        attack: max(hal__num(hal__opt(_opt, "attack", 0.06), 0.06), 0), release: max(hal__num(hal__opt(_opt, "release", 0.14), 0.14), 0),
        gain: max(hal__num(hal__opt(_opt, "gain", 1), 1), 0),
        useVeil: hal__opt(_opt, "veil", true) != false, useDirt: hal__opt(_opt, "dirt", true) != false, useGrade: hal__opt(_opt, "grade", true) != false,
        vx: 0, vy: 0, vw: 1, vh: 1, seq: 0
    };
}

/// @function hal_world_set_kit(world, kit)
/// @description Change the lens every light in the world looks through (lights with their own kit keep it). Takes effect on the next draw.
/// @param {Struct} world The world.
/// @param {String} kit A lens kit name.
/// @returns {Bool} false when either is not usable.
function hal_world_set_kit(_W, _kit) {
    if (!hal__is_world(_W) || !is_string(_kit) || !variable_struct_exists(global.hal_t_kits, _kit)) return false;
    _W.kit = _kit;
    return true;
}

/// @function hal_world_set_occluder(world, occluder)
/// @description Change what blocks the lights. Pass undefined to clear it.
/// @param {Struct} world The world.
/// @param {Struct} occluder An occluder description (see hal_world_create).
/// @returns {Bool} false when world is not a world, or the description is not usable.
function hal_world_set_occluder(_W, _oc) {
    if (!hal__is_world(_W)) return false;
    if (is_undefined(_oc)) { _W.occluder = undefined; return true; }
    var _r = hal__occluder(_oc, self);
    if (is_undefined(_r)) return false;
    _W.occluder = _r;
    return true;
}

/// @function hal_world_set_camera(world, camera)
/// @description Which camera maps room coordinates into the frame. -1 (the default) follows view 0 when views are on, else the whole room.
/// @param {Struct} world The world.
/// @param {Id.Camera} camera A camera id, or -1.
/// @returns {Bool} false when world is not a world.
function hal_world_set_camera(_W, _cam) {
    if (!hal__is_world(_W)) return false;
    _W.camera = hal__camera(_cam);
    return true;
}

/// @function hal_world_pause(world, paused)
/// @description Freeze time, flicker and one-shots. Lights keep drawing.
/// @param {Struct} world The world.
/// @param {Bool} paused True to freeze.
/// @returns {Bool} false when world is not a world.
function hal_world_pause(_W, _p) { if (!hal__is_world(_W)) return false; _W.paused = (_p == true); return true; }

/// @function hal_world_clear(world)
/// @description Remove every light and glint.
/// @param {Struct} world The world.
/// @returns {Bool} false when world is not a world.
function hal_world_clear(_W) { if (!hal__is_world(_W)) return false; _W.lights = []; _W.glints = []; return true; }

/// @function hal_world_count(world)
/// @description How many lights are live (glints not counted).
/// @param {Struct} world The world.
/// @returns {Real}
function hal_world_count(_W) { if (!hal__is_world(_W)) return 0; return array_length(_W.lights); }

/// @function hal_light_add(world, kind, x, y, [options])
/// @description Add a lasting light. Options: colour, kelvin, size (x the kind's own), brightness (default 1), elong and angle (a neon tube's length and slope),
/// kit (its own lens), radius (the disc occlusion samples, in room pixels), occluder (its own), occlude (false: nothing blocks it, for a light in front of the walls), screen (true: x and y are in the frame, and it is never occluded unless it has its own),
/// flicker ("none", "flame", "breathe", "hum", "pulse", "twinkle"), flickerAmount, follow (an instance it tracks; it retires when that instance does).
/// @param {Struct} world The world.
/// @param {String} kind A light kind name.
/// @param {Real} x Room x.
/// @param {Real} y Room y.
/// @param {Struct} [options]
/// @returns {Struct} The light, or undefined when refused.
function hal_light_add(_W, _kind, _x, _y, _opt = undefined) {
    if (!hal__is_world(_W) || !is_string(_kind) || !variable_struct_exists(global.hal_t_kinds, _kind)) return undefined;
    var _K = global.hal_t_kinds[$ _kind];
    _W.seq += 1;
    var _kit = hal__opt(_opt, "kit", undefined);
    if (!is_string(_kit) || !variable_struct_exists(global.hal_t_kits, _kit)) _kit = "";
    var _L = {
        halLight: true, seq: _W.seq, kind: _kind, x: hal__num(_x, 0), y: hal__num(_y, 0), ownKit: _kit,
        colour: hal__num(hal__opt(_opt, "colour", -1), -1), kelvin: hal__num(hal__opt(_opt, "kelvin", 0), 0),
        size: hal__num(hal__opt(_opt, "size", 1), 1), elong: hal__num(hal__opt(_opt, "elong", -1), -1), angle: hal__num(hal__opt(_opt, "angle", 0), 0),
        brightness: max(hal__num(hal__opt(_opt, "brightness", 1), 1), 0),
        radius: max(hal__num(hal__opt(_opt, "radius", _K.radius), _K.radius), 0),
        occluder: hal__occluder(hal__opt(_opt, "occluder", undefined), self), occlude: hal__opt(_opt, "occlude", true) != false, screen: hal__opt(_opt, "screen", false) == true,
        follow: hal__opt(_opt, "follow", noone),
        flicker: hal__opt(_opt, "flicker", _K.flicker), amount: hal__num(hal__opt(_opt, "flickerAmount", _K.amount), _K.amount),
        seed: _W.seq * 2.71 + 0.4, age: 0, attack: 0, decay: 0, once: false, env: 1, vis: 1, flick: 1, design: undefined, designKit: "", dirty: true
    };
    if (!is_string(_L.flicker)) _L.flicker = "none";
    array_push(_W.lights, _L);
    return _L;
}

/// @function hal_flash(world, kind, x, y, [options])
/// @description Fire a one-shot that retires itself. Muzzle flashes and explosions carry their own timing; any other kind takes the options attack and decay
/// (seconds, default 0.02 and 0.25). Every option of hal_light_add also applies.
/// @param {Struct} world The world.
/// @param {String} kind A light kind name.
/// @param {Real} x Room x.
/// @param {Real} y Room y.
/// @param {Struct} [options]
/// @returns {Struct} The light, or undefined when refused.
function hal_flash(_W, _kind, _x, _y, _opt = undefined) {
    var _L = hal_light_add(_W, _kind, _x, _y, _opt);
    if (is_undefined(_L)) return undefined;
    var _K = global.hal_t_kinds[$ _kind];
    _L.attack = max(hal__num(hal__opt(_opt, "attack", (_K.decay > 0) ? _K.attack : 0.02), 0.02), 0);
    _L.decay = max(hal__num(hal__opt(_opt, "decay", (_K.decay > 0) ? _K.decay : 0.25), 0.25), 0.01);
    _L.once = true; _L.env = 0;
    _L.flicker = hal__opt(_opt, "flicker", "none");
    if (!is_string(_L.flicker)) _L.flicker = "none";
    var _oc = is_undefined(_L.occluder) ? _W.occluder : _L.occluder;
    if (_L.occlude && !_L.screen && !is_undefined(_oc)) _L.vis = 1 - hal__cover(_L, _oc, _W.samples);   // a flash has no time to ease in: it opens at what it can see
    return _L;
}

/// @function hal_light_move(light, x, y)
/// @description Move a light.
/// @param {Struct} light The light.
/// @param {Real} x New x.
/// @param {Real} y New y.
/// @returns {Bool} false when light is not a light.
function hal_light_move(_L, _x, _y) { if (!hal__is_light(_L)) return false; _L.x = hal__num(_x, _L.x); _L.y = hal__num(_y, _L.y); return true; }

/// @function hal_light_set(light, options)
/// @description Change a light: colour, kelvin, size, elong, angle, brightness, kit, radius, occlude. A change of colour or size recompiles its design (cached per value, so animate brightness, not colour).
/// @param {Struct} light The light.
/// @param {Struct} options The fields to change.
/// @returns {Bool} false when light is not a light.
function hal_light_set(_L, _opt) {
    if (!hal__is_light(_L) || !is_struct(_opt)) return false;
    _L.colour = hal__num(hal__opt(_opt, "colour", _L.colour), _L.colour);
    _L.kelvin = hal__num(hal__opt(_opt, "kelvin", _L.kelvin), _L.kelvin);
    _L.size = hal__num(hal__opt(_opt, "size", _L.size), _L.size);
    _L.elong = hal__num(hal__opt(_opt, "elong", _L.elong), _L.elong);
    _L.angle = hal__num(hal__opt(_opt, "angle", _L.angle), _L.angle);
    _L.brightness = max(hal__num(hal__opt(_opt, "brightness", _L.brightness), _L.brightness), 0);
    _L.radius = max(hal__num(hal__opt(_opt, "radius", _L.radius), _L.radius), 0);
    _L.occlude = hal__opt(_opt, "occlude", _L.occlude) != false;
    var _kit = hal__opt(_opt, "kit", undefined);
    if (is_string(_kit) && (_kit == "" || variable_struct_exists(global.hal_t_kits, _kit))) _L.ownKit = _kit;
    _L.dirty = true;
    return true;
}

/// @function hal_light_remove(world, light)
/// @description Remove one light now.
/// @param {Struct} world The world.
/// @param {Struct} light The light.
/// @returns {Bool} false when it was not in that world.
function hal_light_remove(_W, _L) {
    if (!hal__is_world(_W) || !hal__is_light(_L)) return false;
    for (var _i = array_length(_W.lights) - 1; _i >= 0; _i--) if (_W.lights[_i] == _L) { array_delete(_W.lights, _i, 1); return true; }
    return false;
}

/// @function hal_light_visibility(light)
/// @description How much of a light the lens can see right now, eased, 0..1. Read it to drive your own bloom, sound or lens-dirt.
/// @param {Struct} light The light.
/// @returns {Real} 0 for a value that is not a light.
function hal_light_visibility(_L) { if (!hal__is_light(_L)) return 0; return _L.vis; }

/// @function hal_light_exists(world, light)
/// @description Is this light still in the world? A flash retires itself; a follower retires with its instance.
/// @param {Struct} world The world.
/// @param {Struct} light The light.
/// @returns {Bool}
function hal_light_exists(_W, _L) {
    if (!hal__is_world(_W) || !hal__is_light(_L)) return false;
    for (var _i = array_length(_W.lights) - 1; _i >= 0; _i--) if (_W.lights[_i] == _L) return true;
    return false;
}

/// @function hal_glint(world, x, y, [options])
/// @description A one-shot sparkle on a pickup, a gem or a blade. Options: size (pixels, default 26), life (seconds, default 0.55), colour, points (4 or 6, default 4), spin (degrees over its life), screen.
/// @param {Struct} world The world.
/// @param {Real} x Room x.
/// @param {Real} y Room y.
/// @param {Struct} [options]
/// @returns {Bool} false when refused.
function hal_glint(_W, _x, _y, _opt = undefined) {
    if (!hal__is_world(_W)) return false;
    array_push(_W.glints, { x0: hal__num(_x, 0), y0: hal__num(_y, 0), x1: hal__num(_x, 0), y1: hal__num(_y, 0),
        size: clamp(hal__num(hal__opt(_opt, "size", 26), 26), 1, 4096), life: max(hal__num(hal__opt(_opt, "life", 0.55), 0.55), 0.02), age: 0,
        colour: hal__num(hal__opt(_opt, "colour", #FFF4D8), #FFF4D8), points: (hal__opt(_opt, "points", 4) == 6) ? 6 : 4, spin: hal__num(hal__opt(_opt, "spin", 40), 40), screen: hal__opt(_opt, "screen", false) == true });
    return true;
}

/// @function hal_glint_along(world, x0, y0, x1, y1, [options])
/// @description A glint that runs along an edge once: a blade being drawn, a coin's rim, a sword held up to the light. Options as hal_glint; life defaults to 0.45.
/// @param {Struct} world The world.
/// @param {Real} x0 Start x.
/// @param {Real} y0 Start y.
/// @param {Real} x1 End x.
/// @param {Real} y1 End y.
/// @param {Struct} [options]
/// @returns {Bool} false when refused.
function hal_glint_along(_W, _x0, _y0, _x1, _y1, _opt = undefined) {
    if (!hal__is_world(_W)) return false;
    if (!hal_glint(_W, _x0, _y0, _opt)) return false;
    var _g = _W.glints[array_length(_W.glints) - 1];
    _g.x1 = hal__num(_x1, _g.x0); _g.y1 = hal__num(_y1, _g.y0);
    if (!is_struct(_opt) || !variable_struct_exists(_opt, "life")) _g.life = 0.45;
    return true;
}

/// @function hal_world_step(world, [dt])
/// @description Advance time: ages one-shots, follows instances, runs flicker and occlusion. dt in seconds, default this frame's delta_time, capped at 0.05.
/// @param {Struct} world The world.
/// @param {Real} [dt] Seconds.
/// @returns {Bool} false when world is not a world.
function hal_world_step(_W, _dt = undefined) {
    if (!hal__is_world(_W)) return false;
    var _d = clamp(hal__num(_dt, delta_time / 1000000), 0, 0.05);
    if (_W.paused) _d = 0;
    _W.t += _d;
    var _Ls = _W.lights, _occ = _W.occluder, _t = _W.t, _sm = _W.samples, _at = _W.attack, _rl = _W.release;
    for (var _i = array_length(_Ls) - 1; _i >= 0; _i--) {
        var _L = _Ls[_i];
        if (_L.once) {
            _L.age += _d;
            if (_L.age >= _L.attack + _L.decay) { array_delete(_Ls, _i, 1); continue; }
            _L.env = hal__env(_L.age, _L.attack, _L.decay);
        }
        if (_L.follow != noone) {
            if (!instance_exists(_L.follow)) { array_delete(_Ls, _i, 1); continue; }
            _L.x = _L.follow.x; _L.y = _L.follow.y;
        }
        _L.flick = hal__flicker(_L.flicker, _t, _L.seed, _L.amount);
        var _oc = is_undefined(_L.occluder) ? _occ : _L.occluder;
        if (!_L.occlude || is_undefined(_oc) || (_L.screen && is_undefined(_L.occluder))) { _L.vis = hal__vis_step(_L.vis, 1, _d, _at, _rl); continue; }
        _L.vis = hal__vis_step(_L.vis, 1 - hal__cover(_L, _oc, _sm), _d, _at, _rl);
    }
    var _Gs = _W.glints;
    for (var _i = array_length(_Gs) - 1; _i >= 0; _i--) { _Gs[_i].age += _d; if (_Gs[_i].age >= _Gs[_i].life) array_delete(_Gs, _i, 1); }
    return true;
}

/// @function hal__view(world)
/// @description Internal. Read the rectangle of the room this world looks at.
function hal__view(_W) {
    var _c = _W.camera;
    if (_c == -1 && view_enabled && view_visible[0]) _c = view_camera[0];
    if (_c != -1) {
        var _vw = camera_get_view_width(_c), _vh = camera_get_view_height(_c);
        if (_vw > 0 && _vh > 0) { _W.vx = camera_get_view_x(_c); _W.vy = camera_get_view_y(_c); _W.vw = _vw; _W.vh = _vh; return; }
    }
    _W.vx = 0; _W.vy = 0; _W.vw = room_width; _W.vh = room_height;
}

/// @function hal__light_design(world, light)
/// @description Internal. The light's compiled design for the lens it currently looks through.
function hal__light_design(_W, _L) {
    var _kit = (_L.ownKit != "") ? _L.ownKit : _W.kit;
    if (_L.dirty || _L.designKit != _kit) {
        _L.design = hal_design(_kit, _L.kind, { colour: _L.colour, kelvin: _L.kelvin, size: _L.size, elong: _L.elong, angle: _L.angle });
        _L.designKit = _kit; _L.dirty = false;
    }
    return _L.design;
}

/// @function hal_design_stats(kit, kind)
/// @description What one design is made of: { elements, ghosts, spikes, rings, streaks }. Empty fields for names that are not a kit and a kind.
/// @param {String} kit A lens kit name.
/// @param {String} kind A light kind name.
/// @returns {Struct}
function hal_design_stats(_kit, _kind) {
    var _D = hal_design(_kit, _kind), _o = { elements: 0, ghosts: 0, spikes: 0, rings: 0, streaks: 0 };
    if (is_undefined(_D)) return _o;
    _o.elements = _D.n;
    for (var _i = 0; _i < _D.n; _i++) {
        var _E = _D.els[_i];
        switch (_E.ty) {
            case HAL_EL_GHOST: _o.ghosts += 1; break;
            case HAL_EL_SPIKES: _o.spikes = max(_o.spikes, _E.n); break;
            case HAL_EL_RING: _o.rings += 1; break;
            case HAL_EL_STREAK: _o.streaks += 1; break;
        }
    }
    return _o;
}
