/// hal_draw.gml - Halation's drawing. Every flare is drawn with draw_vertex_colour in one additive pass: no sprite, no surface, no shader
/// and no vertex buffer is created, so there is nothing to free when a room or the game restarts, and a world matrix, a camera or a GUI scale
/// you have set simply applies. One draw_primitive batch holds about 1000 vertices before GameMaker drops the rest, so every loop flushes at 900.
/// Colour adds; alpha blends as "over", so drawing onto an opaque surface leaves it opaque. Your blend, shader, depth and scissor state are handed back.
///
/// Halation - Lens Flares, Glints and Glare for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function hal__state_begin()
/// @description Internal. Save the caller's GPU state and set the additive pass. Returns what hal__state_end needs.
function hal__state_begin() {
    var _sh = shader_current();
    if (_sh != -1) shader_reset();
    gpu_push_state();
    gpu_set_blendenable(true);
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_one, bm_one, bm_inv_src_alpha);
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false); gpu_set_cullmode(cull_noculling); gpu_set_alphatestenable(false); gpu_set_fog(false, c_black, 0, 1);
    return _sh;
}

/// @function hal__state_end(shader)
/// @description Internal. Hand the caller's GPU state back.
function hal__state_end(_sh) {
    gpu_pop_state();
    if (_sh != -1) shader_set(_sh);
}

/// @function hal__circle(segments)
/// @description Internal. A cached unit circle table: { c, s }, one entry past the end so the last segment closes without a modulo.
function hal__circle(_seg) {
    var _k = string(_seg);
    if (variable_struct_exists(global.hal_t_circles, _k)) return global.hal_t_circles[$ _k];
    var _c = array_create(_seg + 1), _s = array_create(_seg + 1);
    for (var _i = 0; _i <= _seg; _i++) { _c[_i] = cos(_i * 2 * pi / _seg); _s[_i] = sin(_i * 2 * pi / _seg); }
    var _T = { c: _c, s: _s };
    global.hal_t_circles[$ _k] = _T;
    return _T;
}

/// @function hal__d_radial(x, y, fs, element, k)
/// @description Internal. A radial falloff: a fan to the first ring, then ring strips, optionally stretched and turned (a neon tube's bloom).
function hal__d_radial(_x, _y, _fs, _E, _k) {
    var _r = _E.r * _fs, _rx = _r * _E.sx, _ry = _r * _E.sy;
    var _seg = clamp(round(max(_rx, _ry) * 0.11 + 9), 10, 30);
    if (_rx != _ry) _seg = clamp(_seg + 6, 10, 36);
    var _T = hal__circle(_seg), _ct = _T.c, _st = _T.s, _cr = _E.cr, _sr = _E.sr;
    var _rr = _E.rr, _aa = _E.aa, _cc = _E.cc, _n = _E.n, _cnt = 0, _tot = 0;
    draw_primitive_begin(pr_trianglelist);
    for (var _ring = 0; _ring < _n - 1; _ring++) {
        var _r0 = _rr[_ring], _r1 = _rr[_ring + 1], _a0 = _aa[_ring] * _k, _a1 = _aa[_ring + 1] * _k, _c0 = _cc[_ring], _c1 = _cc[_ring + 1];
        var _ax0 = _rx * _r0, _ay0 = _ry * _r0, _ax1 = _rx * _r1, _ay1 = _ry * _r1;
        for (var _i = 0; _i < _seg; _i++) {
            var _u0 = _ct[_i], _v0 = _st[_i], _u1 = _ct[_i + 1], _v1 = _st[_i + 1];
            var _ox1 = _u0 * _ax1, _oy1 = _v0 * _ay1, _ox2 = _u1 * _ax1, _oy2 = _v1 * _ay1;
            var _p1x = _x + _ox1 * _cr - _oy1 * _sr, _p1y = _y + _ox1 * _sr + _oy1 * _cr;
            var _p2x = _x + _ox2 * _cr - _oy2 * _sr, _p2y = _y + _ox2 * _sr + _oy2 * _cr;
            if (_ring == 0) {
                draw_vertex_colour(_x, _y, _c0, _a0); draw_vertex_colour(_p1x, _p1y, _c1, _a1); draw_vertex_colour(_p2x, _p2y, _c1, _a1);
                _cnt += 3;
            } else {
                var _ox3 = _u0 * _ax0, _oy3 = _v0 * _ay0, _ox4 = _u1 * _ax0, _oy4 = _v1 * _ay0;
                var _p3x = _x + _ox3 * _cr - _oy3 * _sr, _p3y = _y + _ox3 * _sr + _oy3 * _cr;
                var _p4x = _x + _ox4 * _cr - _oy4 * _sr, _p4y = _y + _ox4 * _sr + _oy4 * _cr;
                draw_vertex_colour(_p3x, _p3y, _c0, _a0); draw_vertex_colour(_p1x, _p1y, _c1, _a1); draw_vertex_colour(_p2x, _p2y, _c1, _a1);
                draw_vertex_colour(_p3x, _p3y, _c0, _a0); draw_vertex_colour(_p2x, _p2y, _c1, _a1); draw_vertex_colour(_p4x, _p4y, _c0, _a0);
                _cnt += 6;
            }
            if (_cnt >= 900) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); _tot += _cnt; _cnt = 0; }
        }
    }
    draw_primitive_end();
    global.hal_vtotal += _tot + _cnt;
}

/// @function hal__d_ghost(x, y, fs, element, k)
/// @description Internal. One ghost: the aperture's shape, lit by style (0 polygon with a bright rim, 1 hollow, 2 soft disc, 3 doughnut), with a chromatic fringe outside the rim.
function hal__d_ghost(_x, _y, _fs, _E, _k) {
    var _r = _E.r * _fs, _a = _E.a * _k;
    if (_r < 0.6 || _a < 0.003) return;
    var _xs = _E.xs, _ys = _E.ys, _n = _E.n, _sx = _E.sx, _c = _E.c, _rim = _E.rim, _st = _E.style;
    var _a0, _a1, _a2, _in, _fr;
    switch (_st) {
        case 0: _a0 = _a * 0.42; _a1 = _a * 0.58; _a2 = _a; _in = 0.86; _fr = 0.045; break;
        case 1: _a0 = 0; _a1 = _a * 0.10; _a2 = _a; _in = 0.80; _fr = 0.055; break;
        case 2: _a0 = _a; _a1 = _a * 0.68; _a2 = 0; _in = 0.62; _fr = 0; break;
        default: _a0 = 0; _a1 = _a; _a2 = _a * 0.55; _in = 0.46; _fr = 0.04; break;
    }
    var _rx = _r * _sx, _cnt = 0;
    draw_primitive_begin(pr_trianglelist);
    for (var _i = 0; _i < _n; _i++) {
        var _j = (_i + 1 == _n) ? 0 : _i + 1;
        var _ux = _xs[_i] * _rx, _uy = _ys[_i] * _r, _vx = _xs[_j] * _rx, _vy = _ys[_j] * _r;
        var _ix = _x + _ux * _in, _iy = _y + _uy * _in, _jx = _x + _vx * _in, _jy = _y + _vy * _in;
        var _ox = _x + _ux, _oy = _y + _uy, _px = _x + _vx, _py = _y + _vy;
        draw_vertex_colour(_x, _y, _c, _a0); draw_vertex_colour(_ix, _iy, _c, _a1); draw_vertex_colour(_jx, _jy, _c, _a1);
        draw_vertex_colour(_ix, _iy, _c, _a1); draw_vertex_colour(_ox, _oy, _rim, _a2); draw_vertex_colour(_px, _py, _rim, _a2);
        draw_vertex_colour(_ix, _iy, _c, _a1); draw_vertex_colour(_px, _py, _rim, _a2); draw_vertex_colour(_jx, _jy, _c, _a1);
        _cnt += 9;
        if (_fr > 0 && _r >= 7) {
            var _f = 1 + _fr, _qx = _x + _ux * _f, _qy = _y + _uy * _f, _sx2 = _x + _vx * _f, _sy2 = _y + _vy * _f;
            draw_vertex_colour(_ox, _oy, _rim, _a2); draw_vertex_colour(_qx, _qy, _rim, 0); draw_vertex_colour(_sx2, _sy2, _rim, 0);
            draw_vertex_colour(_ox, _oy, _rim, _a2); draw_vertex_colour(_sx2, _sy2, _rim, 0); draw_vertex_colour(_px, _py, _rim, _a2);
            _cnt += 6;
        }
    }
    draw_primitive_end();
    global.hal_vtotal += _cnt;
}

/// @function hal__d_spikes(x, y, fs, element, k)
/// @description Internal. Diffraction spikes: a needle per spike, widest at the source and gone at its tip. A rainbow kit disperses each spike along its length.
function hal__d_spikes(_x, _y, _fs, _E, _k) {
    var _a = _E.a * _k, _w = max(_E.w * _fs, 1.1), _col = _E.col, _n = _E.n, _ca = _E.ca, _sa = _E.sa, _ln = _E.ln, _cnt = 0;
    if (_a < 0.004) return;
    draw_primitive_begin(pr_trianglelist);
    if (_E.rainbow > 0) {
        static _spec = [ #FFFFFF, #FFF0C0, #FFD06A, #FF7A5C, #FF5CC8, #7A6CFF, #4CC8FF];
        var _ns = array_length(_spec) - 1;
        for (var _i = 0; _i < _n; _i++) {
            var _dx = _ca[_i], _dy = _sa[_i], _L = _ln[_i] * _fs;
            for (var _q = 0; _q < _ns; _q++) {
                var _u0 = _q / _ns, _u1 = (_q + 1) / _ns, _w0 = _w * (1 - _u0 * 0.72), _w1 = _w * (1 - _u1 * 0.72);
                var _a0 = _a * power(1 - _u0, 1.7), _a1 = _a * power(1 - _u1, 1.7), _c0 = _spec[_q], _c1 = _spec[_q + 1];
                var _x0 = _x + _dx * _L * _u0, _y0 = _y + _dy * _L * _u0, _x1 = _x + _dx * _L * _u1, _y1 = _y + _dy * _L * _u1;
                var _nx = -_dy, _ny = _dx;
                draw_vertex_colour(_x0 + _nx * _w0, _y0 + _ny * _w0, _c0, 0); draw_vertex_colour(_x0, _y0, _c0, _a0); draw_vertex_colour(_x1, _y1, _c1, _a1);
                draw_vertex_colour(_x0 + _nx * _w0, _y0 + _ny * _w0, _c0, 0); draw_vertex_colour(_x1, _y1, _c1, _a1); draw_vertex_colour(_x1 + _nx * _w1, _y1 + _ny * _w1, _c1, 0);
                draw_vertex_colour(_x0 - _nx * _w0, _y0 - _ny * _w0, _c0, 0); draw_vertex_colour(_x0, _y0, _c0, _a0); draw_vertex_colour(_x1, _y1, _c1, _a1);
                draw_vertex_colour(_x0 - _nx * _w0, _y0 - _ny * _w0, _c0, 0); draw_vertex_colour(_x1, _y1, _c1, _a1); draw_vertex_colour(_x1 - _nx * _w1, _y1 - _ny * _w1, _c1, 0);
                _cnt += 12;
                if (_cnt >= 900) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); global.hal_vtotal += _cnt; _cnt = 0; }
            }
        }
    } else for (var _i = 0; _i < _n; _i++) {
        var _dx = _ca[_i], _dy = _sa[_i], _L = _ln[_i] * _fs;
        var _tx = _x + _dx * _L, _ty = _y + _dy * _L, _lx = _x - _dy * _w, _ly = _y + _dx * _w, _rx = _x + _dy * _w, _ry = _y - _dx * _w;
        draw_vertex_colour(_x, _y, _col, _a); draw_vertex_colour(_lx, _ly, _col, 0); draw_vertex_colour(_tx, _ty, _col, 0);
        draw_vertex_colour(_x, _y, _col, _a); draw_vertex_colour(_tx, _ty, _col, 0); draw_vertex_colour(_rx, _ry, _col, 0);
        _cnt += 6;
    }
    draw_primitive_end();
    global.hal_vtotal += _cnt;
}

/// @function hal__d_ring(x, y, fs, element, k, axis)
/// @description Internal. A ring or an arc round the source, three bands across its width so a spectrum runs inner to outer. An arc tapers to nothing at both ends and faces the frame's centre (plus its "at" degrees).
function hal__d_ring(_x, _y, _fs, _E, _k, _axis) {
    var _a = _E.a * _k, _r = _E.r * _fs, _w = max(_E.w * _fs, 1.2);
    if (_a < 0.004) return;
    var _arc = _E.arc, _full = (_arc >= 0.999);
    var _seg = clamp(ceil(2 * pi * _r * _arc / 13), 10, 44);
    var _cols = _E.cols, _st0 = _r - _w, _st1 = _r - _w * 0.34, _st2 = _r + _w * 0.34, _st3 = _r + _w, _cnt = 0;
    var _sw = 2 * pi * _arc, _a0 = _axis + degtorad(_E.at) - _sw * 0.5;
    var _T = _full ? hal__circle(_seg) : undefined;
    draw_primitive_begin(pr_trianglelist);
    for (var _i = 0; _i < _seg; _i++) {
        var _c0, _s0, _c1, _s1, _t0 = 1, _t1 = 1;
        if (_full) { _c0 = _T.c[_i]; _s0 = _T.s[_i]; _c1 = _T.c[_i + 1]; _s1 = _T.s[_i + 1]; }
        else {
            var _u0 = _i / _seg, _u1 = (_i + 1) / _seg, _b0 = _a0 + _sw * _u0, _b1 = _a0 + _sw * _u1;
            _c0 = cos(_b0); _s0 = sin(_b0); _c1 = cos(_b1); _s1 = sin(_b1);
            _t0 = sin(pi * _u0); _t1 = sin(pi * _u1);
        }
        var _p0 = _a * _t0, _p1 = _a * _t1;
        // inner soft edge, the plateau, outer soft edge
        draw_vertex_colour(_x + _c0 * _st0, _y + _s0 * _st0, _cols[0], 0); draw_vertex_colour(_x + _c0 * _st1, _y + _s0 * _st1, _cols[1], _p0); draw_vertex_colour(_x + _c1 * _st1, _y + _s1 * _st1, _cols[1], _p1);
        draw_vertex_colour(_x + _c0 * _st0, _y + _s0 * _st0, _cols[0], 0); draw_vertex_colour(_x + _c1 * _st1, _y + _s1 * _st1, _cols[1], _p1); draw_vertex_colour(_x + _c1 * _st0, _y + _s1 * _st0, _cols[0], 0);
        draw_vertex_colour(_x + _c0 * _st1, _y + _s0 * _st1, _cols[1], _p0); draw_vertex_colour(_x + _c0 * _st2, _y + _s0 * _st2, _cols[2], _p0); draw_vertex_colour(_x + _c1 * _st2, _y + _s1 * _st2, _cols[2], _p1);
        draw_vertex_colour(_x + _c0 * _st1, _y + _s0 * _st1, _cols[1], _p0); draw_vertex_colour(_x + _c1 * _st2, _y + _s1 * _st2, _cols[2], _p1); draw_vertex_colour(_x + _c1 * _st1, _y + _s1 * _st1, _cols[1], _p1);
        draw_vertex_colour(_x + _c0 * _st2, _y + _s0 * _st2, _cols[2], _p0); draw_vertex_colour(_x + _c0 * _st3, _y + _s0 * _st3, _cols[3], 0); draw_vertex_colour(_x + _c1 * _st3, _y + _s1 * _st3, _cols[3], 0);
        draw_vertex_colour(_x + _c0 * _st2, _y + _s0 * _st2, _cols[2], _p0); draw_vertex_colour(_x + _c1 * _st3, _y + _s1 * _st3, _cols[3], 0); draw_vertex_colour(_x + _c1 * _st2, _y + _s1 * _st2, _cols[2], _p1);
        _cnt += 18;
        if (_cnt >= 880) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); global.hal_vtotal += _cnt; _cnt = 0; }
    }
    draw_primitive_end();
    global.hal_vtotal += _cnt;
}

/// @function hal__d_streak(x, y, fw, fs, element, k)
/// @description Internal. A long thin lozenge: full at the source, gone at both tips and along both edges. Turned with the light's angle.
function hal__d_streak(_x, _y, _fw, _fs, _E, _k) {
    var _a = _E.a * _k, _L = _E.len * _fw, _T = max(_E.th * _fs, 1), _col = _E.col, _cr = _E.cr, _sr = _E.sr;
    if (_a < 0.004) return;
    var _ox = -_sr * _E.off * _fs, _oy = _cr * _E.off * _fs;
    var _mx = _x + _ox, _my = _y + _oy, _dx = _cr * _L, _dy = _sr * _L, _nx = -_sr * _T, _ny = _cr * _T;
    draw_primitive_begin(pr_trianglelist);
    draw_vertex_colour(_mx, _my, _col, _a); draw_vertex_colour(_mx - _dx, _my - _dy, _col, 0); draw_vertex_colour(_mx + _nx, _my + _ny, _col, 0);
    draw_vertex_colour(_mx, _my, _col, _a); draw_vertex_colour(_mx + _nx, _my + _ny, _col, 0); draw_vertex_colour(_mx + _dx, _my + _dy, _col, 0);
    draw_vertex_colour(_mx, _my, _col, _a); draw_vertex_colour(_mx + _dx, _my + _dy, _col, 0); draw_vertex_colour(_mx - _nx, _my - _ny, _col, 0);
    draw_vertex_colour(_mx, _my, _col, _a); draw_vertex_colour(_mx - _nx, _my - _ny, _col, 0); draw_vertex_colour(_mx - _dx, _my - _dy, _col, 0);
    draw_primitive_end();
    global.hal_vtotal += 12;
}

/// @function hal__d_veil(sx, sy, fx, fy, fw, fh, fs, element, k)
/// @description Internal. Veiling glare: the whole frame (and only the frame) lifted, a floor everywhere plus a part that falls with distance from the source. Scattered light has no edge, so nothing here reaches zero inside the frame.
function hal__d_veil(_sx, _sy, _fx, _fy, _fw, _fh, _fs, _E, _k) {
    var _a = _E.a * _k, _col = _E.col, _reach = _E.reach * _fs;
    if (_a < 0.002) return;
    static _nx = 9;
    static _ny = 5;
    static _g = array_create((_nx + 1) * (_ny + 1), 0);
    for (var _j = 0; _j <= _ny; _j++) for (var _i = 0; _i <= _nx; _i++) {
        var _dx = _fx + _fw * _i / _nx - _sx, _dy = _fy + _fh * _j / _ny - _sy;
        var _q = max(1 - sqrt(_dx * _dx + _dy * _dy) / _reach, 0);
        _g[_j * (_nx + 1) + _i] = _a * (0.14 + 0.86 * _q * _q);
    }
    draw_primitive_begin(pr_trianglelist);
    for (var _j = 0; _j < _ny; _j++) {
        var _y0 = _fy + _fh * _j / _ny, _y1 = _fy + _fh * (_j + 1) / _ny;
        for (var _i = 0; _i < _nx; _i++) {
            var _x0 = _fx + _fw * _i / _nx, _x1 = _fx + _fw * (_i + 1) / _nx;
            var _o = _j * (_nx + 1) + _i, _p00 = _g[_o], _p10 = _g[_o + 1], _p01 = _g[_o + _nx + 1], _p11 = _g[_o + _nx + 2];
            draw_vertex_colour(_x0, _y0, _col, _p00); draw_vertex_colour(_x1, _y0, _col, _p10); draw_vertex_colour(_x1, _y1, _col, _p11);
            draw_vertex_colour(_x0, _y0, _col, _p00); draw_vertex_colour(_x1, _y1, _col, _p11); draw_vertex_colour(_x0, _y1, _col, _p01);
        }
    }
    draw_primitive_end();
    global.hal_vtotal += _nx * _ny * 6;
}

/// @function hal__d_dirt(sx, sy, fx, fy, fw, fh, fs, element, k)
/// @description Internal. Dust on the front glass: fixed specks across the frame that only light up as a bright source comes near. Out-of-focus discs, a little brighter at the rim, as dust really reads.
function hal__d_dirt(_sx, _sy, _fx, _fy, _fw, _fh, _fs, _E, _k) {
    var _n = _E.n, _xs = _E.xs, _ys = _E.ys, _rs = _E.rs, _as = _E.as, _reach = _E.reach * _fs, _col = _E.col, _cnt = 0;
    var _T = hal__circle(7), _ct = _T.c, _st = _T.s;
    draw_primitive_begin(pr_trianglelist);
    for (var _i = 0; _i < _n; _i++) {
        var _px = _fx + _xs[_i] * _fw, _py = _fy + _ys[_i] * _fh, _dx = _px - _sx, _dy = _py - _sy;
        var _q = 1 - sqrt(_dx * _dx + _dy * _dy) / _reach;
        if (_q <= 0) continue;
        var _a = _as[_i] * _q * _q * _k;
        if (_a < 0.006) continue;
        var _r = max(_rs[_i] * _fs, 0.8);
        for (var _s = 0; _s < 7; _s++) {
            draw_vertex_colour(_px, _py, _col, _a * 0.68); draw_vertex_colour(_px + _ct[_s] * _r, _py + _st[_s] * _r, _col, _a); draw_vertex_colour(_px + _ct[_s + 1] * _r, _py + _st[_s + 1] * _r, _col, _a);
        }
        _cnt += 21;
        if (_cnt >= 870) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); global.hal_vtotal += _cnt; _cnt = 0; }
    }
    draw_primitive_end();
    global.hal_vtotal += _cnt;
}

/// @function hal__d_star(x, y, size, col, a, points, rot)
/// @description Internal. Writes one sparkle into the open batch: long needles, a short cross turned between them, a small hot centre. Returns the vertices written.
function hal__d_star(_x, _y, _size, _col, _a, _pts, _rot) {
    var _w = max(_size * 0.085, 0.8), _cnt = 0;
    for (var _i = 0; _i < _pts; _i++) {
        var _ang = _rot + _i * 2 * pi / _pts, _dx = cos(_ang), _dy = sin(_ang), _tx = _x + _dx * _size, _ty = _y + _dy * _size;
        var _lx = _x - _dy * _w, _ly = _y + _dx * _w, _rx = _x + _dy * _w, _ry = _y - _dx * _w;
        draw_vertex_colour(_x, _y, _col, _a); draw_vertex_colour(_lx, _ly, _col, 0); draw_vertex_colour(_tx, _ty, _col, 0);
        draw_vertex_colour(_x, _y, _col, _a); draw_vertex_colour(_tx, _ty, _col, 0); draw_vertex_colour(_rx, _ry, _col, 0);
        var _ang2 = _ang + pi / _pts, _mx = _x + cos(_ang2) * _size * 0.36, _my = _y + sin(_ang2) * _size * 0.36;
        var _lx2 = _x - sin(_ang2) * _w * 0.8, _ly2 = _y + cos(_ang2) * _w * 0.8, _rx2 = _x + sin(_ang2) * _w * 0.8, _ry2 = _y - cos(_ang2) * _w * 0.8;
        draw_vertex_colour(_x, _y, _col, _a * 0.6); draw_vertex_colour(_lx2, _ly2, _col, 0); draw_vertex_colour(_mx, _my, _col, 0);
        draw_vertex_colour(_x, _y, _col, _a * 0.6); draw_vertex_colour(_mx, _my, _col, 0); draw_vertex_colour(_rx2, _ry2, _col, 0);
        _cnt += 12;
    }
    return _cnt;
}

/// @function hal__d_spark(x, y, fs, element, k, t)
/// @description Internal. Sparkles round the source, each on its own twinkle.
function hal__d_spark(_x, _y, _fs, _E, _k, _t) {
    var _n = _E.n, _ang = _E.ang, _dst = _E.dst, _sz = _E.sz, _ph = _E.ph, _rate = _E.rate, _cols = _E.cols, _a = _E.a * _k, _cnt = 0;
    draw_primitive_begin(pr_trianglelist);
    for (var _i = 0; _i < _n; _i++) {
        var _tw = 0.5 + 0.5 * sin(_t * _rate[_i] + _ph[_i]);
        _tw = _tw * _tw * _tw;
        var _aa = _a * _tw;
        if (_aa < 0.01) continue;
        var _d = _dst[_i] * _fs, _s = max(_sz[_i] * _fs * (0.6 + 0.4 * _tw), 2);
        _cnt += hal__d_star(_x + cos(_ang[_i]) * _d, _y + sin(_ang[_i]) * _d, _s, _cols[_i], _aa, 4, 0.3);
        if (_cnt >= 850) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); global.hal_vtotal += _cnt; _cnt = 0; }
    }
    draw_primitive_end();
    global.hal_vtotal += _cnt;
}

/// @function hal__d_scan(x, y, fx, fy, fw, fh, fs, element, k)
/// @description Internal. An intensifier tube's scanlines across its own bloom: thin rows whose brightness falls with distance from the source.
function hal__d_scan(_x, _y, _fx, _fy, _fw, _fh, _fs, _E, _k) {
    var _R = _E.r * _fs, _a = _E.a * _k, _col = _E.col;
    if (_a < 0.004) return;
    var _pitch = max(round(_fs / 180), 2), _cnt = 0, _y0 = floor((max(_y - _R, _fy)) / _pitch) * _pitch, _y1 = min(_y + _R, _fy + _fh);
    draw_primitive_begin(pr_trianglelist);
    for (var _py = _y0; _py < _y1; _py += _pitch * 2) {
        var _dy = abs(_py - _y) / _R;
        if (_dy >= 1) continue;
        var _half = sqrt(1 - _dy * _dy) * _R, _p = _a * (1 - _dy), _h = max(_pitch * 0.5, 1);
        var _x0 = max(_x - _half, _fx), _x1 = min(_x + _half, _fx + _fw), _xm = clamp(_x, _x0, _x1);
        draw_vertex_colour(_x0, _py, _col, 0); draw_vertex_colour(_xm, _py, _col, _p); draw_vertex_colour(_xm, _py + _h, _col, _p);
        draw_vertex_colour(_x0, _py, _col, 0); draw_vertex_colour(_xm, _py + _h, _col, _p); draw_vertex_colour(_x0, _py + _h, _col, 0);
        draw_vertex_colour(_xm, _py, _col, _p); draw_vertex_colour(_x1, _py, _col, 0); draw_vertex_colour(_x1, _py + _h, _col, 0);
        draw_vertex_colour(_xm, _py, _col, _p); draw_vertex_colour(_x1, _py + _h, _col, 0); draw_vertex_colour(_xm, _py + _h, _col, _p);
        _cnt += 12;
        if (_cnt >= 880) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); global.hal_vtotal += _cnt; _cnt = 0; }
    }
    draw_primitive_end();
    global.hal_vtotal += _cnt;
}

/// @function hal__d_noise(x, y, fs, element, k, t)
/// @description Internal. Tube noise: bright flecks that change every frame near a bright source. Seeded from time, so a paused world holds still.
function hal__d_noise(_x, _y, _fs, _E, _k, _t) {
    var _n = _E.n, _R = _E.r * _fs, _a = _E.a * min(_k, 1), _col = _E.col, _s = floor(_t * 30) * 7919 + 13, _p = max(_fs / 400, 1.2);
    if (_a < 0.02) return;
    draw_primitive_begin(pr_trianglelist);
    for (var _i = 0; _i < _n; _i++) {
        _s = (_s * 48271) mod 2147483647; var _u0 = _s / 2147483647;
        _s = (_s * 48271) mod 2147483647; var _u1 = _s / 2147483647;
        _s = (_s * 48271) mod 2147483647; var _u2 = _s / 2147483647;
        var _ang = _u0 * 2 * pi, _d = sqrt(_u1) * _R, _px = _x + cos(_ang) * _d, _py = _y + sin(_ang) * _d, _aa = _a * _u2 * (1 - _d / _R);
        draw_vertex_colour(_px, _py, _col, _aa); draw_vertex_colour(_px + _p, _py, _col, _aa); draw_vertex_colour(_px + _p, _py + _p, _col, _aa);
        draw_vertex_colour(_px, _py, _col, _aa); draw_vertex_colour(_px + _p, _py + _p, _col, _aa); draw_vertex_colour(_px, _py + _p, _col, _aa);
    }
    draw_primitive_end();
    global.hal_vtotal += _n * 6;
}

/* ------------------------------------------------- the retro kit: every shape on the pixel grid ------------------------------------------------- */

/// @function hal__snap(value, p)
/// @description Internal. Pure: a coordinate on the p-pixel grid.
function hal__snap(_v, _p) { return floor(_v / _p + 0.5) * _p; }

/// @function hal__p_span(metric, r, dy)
/// @description Internal. Pure: half the width of a shape of radius r at height dy: 0 circle, 4 diamond, 6 hexagon, 8 octagon.
function hal__p_span(_metric, _r, _dy) {
    var _d = abs(_dy);
    if (_d > _r) return -1;
    switch (_metric) {
        case 4: return _r - _d;
        case 6: return min(_r * 0.92, 1.72 * (_r - _d) );
        case 8: return min(_r, 1.41 * _r - _d);
        default: return sqrt(_r * _r - _d * _d);
    }
}

/// @function hal__p_quad(x0, y0, x1, y1, col, a)
/// @description Internal. One flat rectangle into the open batch.
function hal__p_quad(_x0, _y0, _x1, _y1, _col, _a) {
    draw_vertex_colour(_x0, _y0, _col, _a); draw_vertex_colour(_x1, _y0, _col, _a); draw_vertex_colour(_x1, _y1, _col, _a);
    draw_vertex_colour(_x0, _y0, _col, _a); draw_vertex_colour(_x1, _y1, _col, _a); draw_vertex_colour(_x0, _y1, _col, _a);
    global.hal_pn += 6;
    if (global.hal_pn >= 900) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); global.hal_vtotal += global.hal_pn; global.hal_pn = 0; }
}

/// @function hal__p_disc(x, y, r, metric, col, a, p, sx)
/// @description Internal. A filled shape as rows of whole pixels.
function hal__p_disc(_x, _y, _r, _metric, _col, _a, _p, _sx) {
    var _rows = floor(_r / _p);
    for (var _j = -_rows; _j <= _rows; _j++) {
        var _h = hal__p_span(_metric, _r, _j * _p);
        if (_h < 0) continue;
        var _px = hal__snap(_h * _sx, _p);
        if (_px <= 0) _px = _p;
        hal__p_quad(_x - _px, _y + _j * _p, _x + _px, _y + (_j + 1) * _p, _col, _a);
    }
}

/// @function hal__p_outline(x, y, r, metric, col, a, p)
/// @description Internal. A shape's outline as whole pixels: the two ends of each row, and the caps of the top and bottom.
function hal__p_outline(_x, _y, _r, _metric, _col, _a, _p) {
    var _rows = floor(_r / _p), _prev = -1;
    for (var _j = -_rows; _j <= _rows; _j++) {
        var _h = hal__p_span(_metric, _r, _j * _p);
        if (_h < 0) continue;
        var _px = max(hal__snap(_h, _p), _p);
        var _next = hal__p_span(_metric, _r, (_j + 1) * _p);
        var _nx = (_next < 0) ? 0 : max(hal__snap(_next, _p), _p);
        var _inner = (_j == -_rows || _j == _rows) ? 0 : min(_px - _p, max((_prev < 0) ? _px - _p : _prev, _nx) - _p);
        if (_j > -_rows && _prev >= 0 && _prev < _px) _inner = min(_inner, _prev);
        if (_j < _rows && _nx < _px) _inner = min(_inner, _nx);
        _inner = max(_inner, 0);
        var _y0 = _y + _j * _p, _y1 = _y0 + _p;
        hal__p_quad(_x - _px, _y0, _x - _inner, _y1, _col, _a);
        hal__p_quad(_x + _inner, _y0, _x + _px, _y1, _col, _a);
        _prev = _px;
    }
}

/// @function hal__p_render(design element, x, y, ...)
/// @description Internal. Draw one element of the retro kit: stepped light on the grid, never a gradient.
function hal__p_render(_E, _x, _y, _fw, _fs, _k, _p, _gx, _gy, _gf) {
    global.hal_pn = 0;
    draw_primitive_begin(pr_trianglelist);
    switch (_E.ty) {
        case HAL_EL_RADIAL:
            var _r = _E.r * _fs, _rr = _E.sx;
            if (_E.cls == "core") {
                hal__p_disc(_x, _y, _r, 0, _E.cc[2], min(_E.aa[0] * _k, 1) * 0.72, _p, _rr);
                hal__p_disc(_x, _y, _r * 0.55, 0, _E.cc[0], min(_E.aa[0] * _k, 1), _p, _rr);
            } else {
                hal__p_disc(_x, _y, _r, 4, _E.cc[3], _E.aa[0] * _k * 0.24, _p, _rr);
                hal__p_disc(_x, _y, _r * 0.62, 8, _E.cc[2], _E.aa[0] * _k * 0.34, _p, _rr);
                hal__p_disc(_x, _y, _r * 0.32, 0, _E.cc[1], _E.aa[0] * _k * 0.58, _p, _rr);
            }
            break;
        case HAL_EL_GHOST:
            var _r = max(_E.r * _fs, _p), _a = _E.a * _k * _gf;
            if (_a < 0.01) break;
            _gx = hal__snap(_gx, _p); _gy = hal__snap(_gy, _p);
            if (_E.style == 1) hal__p_outline(_gx, _gy, _r, _E.metric, _E.c, _a * 1.6, _p);
            else { hal__p_disc(_gx, _gy, _r, _E.metric, _E.c, _a * 0.7, _p, 1); hal__p_outline(_gx, _gy, _r, _E.metric, _E.rim, _a, _p); }
            break;
        case HAL_EL_SPIKES:
            // dashes along the eight compass rays: each ray of whole pixels fading in three steps
            var _a = _E.a * _k;
            for (var _i = 0; _i < _E.n; _i++) {
                var _L = floor(_E.ln[_i] * _fs / _p), _dx = sign(round(_E.ca[_i] * 1000) / 1000), _dy = sign(round(_E.sa[_i] * 1000) / 1000);
                if (abs(_E.ca[_i]) < 0.38) _dx = 0;
                if (abs(_E.sa[_i]) < 0.38) _dy = 0;
                if (_dx != 0 && _dy != 0) _L = floor(_L * 0.6);
                for (var _q = 1; _q <= _L; _q++) {
                    var _u = _q / _L, _st = (_u < 0.34) ? 1 : ((_u < 0.67) ? 0.56 : 0.24);
                    if (_q > _L * 0.67 && (_q mod 2) == 1) continue;
                    var _px = _x + _dx * _q * _p, _py = _y + _dy * _q * _p;
                    hal__p_quad(_px, _py, _px + _p, _py + _p, _E.col, _a * _st);
                }
            }
            break;
        case HAL_EL_RING:
            // a dotted circle, every dot a whole pixel
            var _r = _E.r * _fs, _a = _E.a * _k, _n = clamp(round(2 * pi * _r / (_p * 3)), 8, 120);
            for (var _i = 0; _i < _n; _i++) {
                var _b = _i * 2 * pi / _n, _px = hal__snap(_x + cos(_b) * _r, _p), _py = hal__snap(_y + sin(_b) * _r, _p);
                hal__p_quad(_px, _py, _px + _p, _py + _p, _E.cols[1], _a);
            }
            break;
        case HAL_EL_STREAK:
            // one row of whole pixels in three steps
            var _L = hal__snap(_E.len * _fw, _p), _a = _E.a * _k, _o = hal__snap(_E.off * _fs, _p);
            hal__p_quad(_x - _L, _y + _o, _x + _L, _y + _o + _p, _E.col, _a * 0.28);
            hal__p_quad(_x - hal__snap(_L * 0.6, _p), _y + _o, _x + hal__snap(_L * 0.6, _p), _y + _o + _p, _E.col, _a * 0.34);
            hal__p_quad(_x - hal__snap(_L * 0.25, _p), _y + _o, _x + hal__snap(_L * 0.25, _p), _y + _o + _p, _E.col, _a * 0.5);
            break;
    }
    draw_primitive_end();
    global.hal_vtotal += global.hal_pn;
    global.hal_pn = 0;
}

/* ------------------------------------------------- one flare ------------------------------------------------- */

/// @function hal__flare_render(design, sx, sy, k, fx, fy, fw, fh, t, useVeil, useDirt)
/// @description Internal. Draw a design with its source at (sx, sy) inside a frame. The caller has set the additive state.
function hal__flare_render(_D, _sx, _sy, _k, _fx, _fy, _fw, _fh, _t, _useVeil, _useDirt) {
    if (_k <= 0.003) return 0;
    var _fs = min(_fw, _fh), _cx = _fx + _fw * 0.5, _cy = _fy + _fh * 0.5;
    var _p = 0;
    if (_D.pixel > 0) { _p = max(1, round(_fs / _D.pixel)); _sx = hal__snap(_sx, _p); _sy = hal__snap(_sy, _p); }
    // a source outside the frame still scatters into it, and fades as it leaves
    var _ox = max(max(_fx - _sx, _sx - (_fx + _fw)), 0), _oy = max(max(_fy - _sy, _sy - (_fy + _fh)), 0);
    var _edge = 1 - clamp(sqrt(_ox * _ox + _oy * _oy) / (_fs * 0.55), 0, 1);
    _k *= _edge;
    if (_k <= 0.003) return 0;
    var _ax = _cx - _sx, _ay = _cy - _sy, _d = sqrt(_ax * _ax + _ay * _ay) / _fs, _axis = arctan2(_ay, _ax);
    // ghosts collapse into the source as it nears the frame's centre, and strengthen toward the frame's edge
    var _gf = clamp((_d - 0.02) / 0.14, 0, 1) * (0.62 + 0.38 * min(_d / 0.62, 1));
    var _els = _D.els, _n = _D.n;
    for (var _i = 0; _i < _n; _i++) {
        var _E = _els[_i], _ty = _E.ty;
        if (_p > 0) {
            if (_ty == HAL_EL_GHOST) hal__p_render(_E, _sx, _sy, _fw, _fs, _k, _p, _sx + _ax * _E.t, _sy + _ay * _E.t, _gf);
            else if (_ty != HAL_EL_VEIL && _ty != HAL_EL_DIRT) hal__p_render(_E, _sx, _sy, _fw, _fs, _k, _p, 0, 0, 1);
            continue;
        }
        switch (_ty) {
            case HAL_EL_RADIAL: hal__d_radial(_sx, _sy, _fs, _E, _k); break;
            case HAL_EL_GHOST:
                if (_gf > 0) { var _gk = _k * _gf; hal__d_ghost(_sx + _ax * _E.t, _sy + _ay * _E.t, _fs, _E, _gk); }
                break;
            case HAL_EL_SPIKES: hal__d_spikes(_sx, _sy, _fs, _E, _k); break;
            case HAL_EL_RING: hal__d_ring(_sx, _sy, _fs, _E, _k, _axis); break;
            case HAL_EL_STREAK: hal__d_streak(_sx, _sy, _fw, _fs, _E, _k); break;
            case HAL_EL_VEIL: if (_useVeil) hal__d_veil(_sx, _sy, _fx, _fy, _fw, _fh, _fs, _E, _k * _k); break;
            case HAL_EL_DIRT: if (_useDirt) hal__d_dirt(_sx, _sy, _fx, _fy, _fw, _fh, _fs, _E, _k); break;
            case HAL_EL_SPARK: hal__d_spark(_sx, _sy, _fs, _E, _k, _t); break;
            case HAL_EL_SCAN: hal__d_scan(_sx, _sy, _fx, _fy, _fw, _fh, _fs, _E, _k); break;
            case HAL_EL_NOISE: hal__d_noise(_sx, _sy, _fs, _E, _k, _t); break;
        }
    }
    return _n;
}

/// @function hal__grade(colour, x, y, w, h)
/// @description Internal. Multiply the frame by a colour: the night vision kit's green. Colour and alpha state are the caller's to restore.
function hal__grade(_col, _x, _y, _w, _h) {
    gpu_set_blendmode_ext_sepalpha(bm_dest_colour, bm_zero, bm_zero, bm_one);
    draw_primitive_begin(pr_trianglelist);
    global.hal_pn = 0;
    hal__p_quad(_x, _y, _x + _w, _y + _h, _col, 1);
    draw_primitive_end();
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_one, bm_one, bm_inv_src_alpha);
    global.hal_vtotal += 6;
    global.hal_pn = 0;
}

/// @function hal_world_draw(world, [x], [y], [w], [h], [clip])
/// @description Draw every light and glint into a frame, in Draw GUI or Draw. The frame defaults to the GUI (display_get_gui_width x display_get_gui_height). The world's camera view maps onto it, so room
/// coordinates land where the player sees them. clip true keeps the flare inside the frame with the GPU scissor, in render-target pixels: use it for split screen drawn 1:1, not under a GUI scale.
/// Hands back your blend, shader, matrix and scissor.
/// @param {Struct} world The world.
/// @param {Real} [x] Frame left.
/// @param {Real} [y] Frame top.
/// @param {Real} [w] Frame width.
/// @param {Real} [h] Frame height.
/// @param {Bool} [clip] Scissor to the frame.
/// @returns {Bool} false when world is not a world, or the frame is empty.
function hal_world_draw(_W, _x = undefined, _y = undefined, _w = undefined, _h = undefined, _clip = false) {
    if (!hal__is_world(_W)) return false;
    var _fx = hal__num(_x, 0), _fy = hal__num(_y, 0), _fw = hal__num(_w, display_get_gui_width()), _fh = hal__num(_h, display_get_gui_height());
    if (_fw <= 0 || _fh <= 0) return false;
    _fw = min(_fw, 16384); _fh = min(_fh, 16384);
    hal__view(_W);
    var _sx = _fw / _W.vw, _sy = _fh / _W.vh, _vx = _W.vx, _vy = _W.vy;
    var _doClip = (_clip == true), _old = undefined;
    if (_doClip) { _old = gpu_get_scissor(); gpu_set_scissor(_fx, _fy, _fw, _fh); }
    var _sh = hal__state_begin(), _Ls = _W.lights, _t = _W.t, _gain = _W.gain, _graded = false;
    for (var _i = 0; _i < array_length(_Ls); _i++) {
        var _L = _Ls[_i], _D = hal__light_design(_W, _L);
        if (is_undefined(_D)) continue;
        if (!_graded && _W.useGrade && _D.grade >= 0) { hal__grade(_D.grade, _fx, _fy, _fw, _fh); _graded = true; }
        var _k = _L.brightness * _L.env * _L.flick * _L.vis * _gain;
        var _px = _L.screen ? _L.x : _fx + (_L.x - _vx) * _sx, _py = _L.screen ? _L.y : _fy + (_L.y - _vy) * _sy;
        hal__flare_render(_D, _px, _py, _k, _fx, _fy, _fw, _fh, _t + _L.seed, _W.useVeil, _W.useDirt);
    }
    hal__glints_render(_W, _fx, _fy, _sx, _sy, _vx, _vy);
    hal__state_end(_sh);
    if (_doClip) gpu_set_scissor(_old);
    return true;
}

/// @function hal__glints_render(world, fx, fy, sx, sy, vx, vy)
/// @description Internal. Draw the world's live glints.
function hal__glints_render(_W, _fx, _fy, _sx, _sy, _vx, _vy) {
    var _Gs = _W.glints, _n = array_length(_Gs), _cnt = 0;
    if (_n == 0) return;
    draw_primitive_begin(pr_trianglelist);
    for (var _i = 0; _i < _n; _i++) {
        var _g = _Gs[_i], _u = clamp(_g.age / _g.life, 0, 1), _env = sin(pi * power(_u, 0.62));
        var _gx = lerp(_g.x0, _g.x1, _u), _gy = lerp(_g.y0, _g.y1, _u);
        var _px = _g.screen ? _gx : _fx + (_gx - _vx) * _sx, _py = _g.screen ? _gy : _fy + (_gy - _vy) * _sy;
        _cnt += hal__d_star(_px, _py, _g.size * (0.45 + 0.55 * _env), _g.colour, _env, _g.points, degtorad(_g.spin * _u) + 0.2);
        if (_cnt >= 800) { draw_primitive_end(); draw_primitive_begin(pr_trianglelist); global.hal_vtotal += _cnt; _cnt = 0; }
    }
    draw_primitive_end();
    global.hal_vtotal += _cnt;
}

/// @function hal_flare_draw(kit, kind, x, y, [brightness], [options])
/// @description Draw one flare right now, with no world: for a title screen, a cutscene or a still. x and y are in the frame. Options: fx, fy, fw, fh (the frame, default the GUI), t (seconds, drives sparkles and noise),
/// colour, kelvin, size, elong, angle, veil, dirt, grade (true multiplies the frame by the kit's grade, night vision's green).
/// @param {String} kit A lens kit name.
/// @param {String} kind A light kind name.
/// @param {Real} x Source x.
/// @param {Real} y Source y.
/// @param {Real} [brightness] 0.. (default 1).
/// @param {Struct} [options]
/// @returns {Bool} false when kit or kind is not a known name, or the frame is empty.
function hal_flare_draw(_kit, _kind, _x, _y, _br = 1, _opt = undefined) {
    var _D = hal_design(_kit, _kind, _opt);
    if (is_undefined(_D)) return false;
    var _fx = hal__num(hal__opt(_opt, "fx", 0), 0), _fy = hal__num(hal__opt(_opt, "fy", 0), 0);
    var _fw = hal__num(hal__opt(_opt, "fw", display_get_gui_width()), display_get_gui_width()), _fh = hal__num(hal__opt(_opt, "fh", display_get_gui_height()), display_get_gui_height());
    if (_fw <= 0 || _fh <= 0) return false;
    _fw = min(_fw, 16384); _fh = min(_fh, 16384);
    var _k = max(hal__num(_br, 1), 0), _sh = hal__state_begin();
    if (hal__opt(_opt, "grade", false) == true && _D.grade >= 0) hal__grade(_D.grade, _fx, _fy, _fw, _fh);
    hal__flare_render(_D, hal__num(_x, 0), hal__num(_y, 0), _k, _fx, _fy, _fw, _fh, hal__num(hal__opt(_opt, "t", 0.37), 0.37), hal__opt(_opt, "veil", true) != false, hal__opt(_opt, "dirt", true) != false);
    hal__state_end(_sh);
    return true;
}

/// @function hal_glint_draw(x, y, size, [phase], [colour], [points], [rot])
/// @description Draw one still sparkle: on an item icon, in a menu, on a shop's gem. phase 0..1 runs one twinkle (default 0.5, its brightest).
/// @param {Real} x Centre x.
/// @param {Real} y Centre y.
/// @param {Real} size Needle length in pixels.
/// @param {Real} [phase] 0..1.
/// @param {Real} [colour] Default a warm white.
/// @param {Real} [points] 4 or 6.
/// @param {Real} [rot] Degrees.
/// @returns {Bool} true.
function hal_glint_draw(_x, _y, _size, _phase = 0.5, _colour = undefined, _points = 4, _rot = 12) {
    hal__init();
    var _u = clamp(hal__num(_phase, 0.5), 0, 1), _env = sin(pi * _u), _s = clamp(hal__num(_size, 16), 0, 4096);
    var _sh = hal__state_begin();
    draw_primitive_begin(pr_trianglelist);
    var _cnt = hal__d_star(hal__num(_x, 0), hal__num(_y, 0), _s * (0.45 + 0.55 * _env), hal__num(_colour, #FFF4D8), _env, (_points == 6) ? 6 : 4, degtorad(hal__num(_rot, 12)));
    draw_primitive_end();
    global.hal_vtotal += _cnt;
    hal__state_end(_sh);
    return true;
}
