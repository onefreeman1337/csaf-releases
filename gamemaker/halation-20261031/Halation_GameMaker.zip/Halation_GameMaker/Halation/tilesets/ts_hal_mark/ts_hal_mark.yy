{
  "$GMTileSet": "v1",
  "%Name": "ts_hal_mark",
  "autoTileSets": [],
  "macroPageTiles": {
    "SerialiseHeight": 0,
    "SerialiseWidth": 0,
    "TileSerialiseData": []
  },
  "name": "ts_hal_mark",
  "out_columns": 2,
  "out_tilehborder": 2,
  "out_tilevborder": 2,
  "parent": {
    "name": "Tile Sets",
    "path": "folders/Tile Sets.yy"
  },
  "resourceType": "GMTileSet",
  "resourceVersion": "2.0",
  "spriteId": {
    "name": "spr_hal_mark",
    "path": "sprites/spr_hal_mark/spr_hal_mark.yy"
  },
  "spriteNoExport": false,
  "textureGroupId": {
    "name": "Default",
    "path": "texturegroups/Default"
  },
  "tileAnimationFrames": [],
  "tileAnimationSpeed": 15,
  "tileHeight": 32,
  "tilehsep": 0,
  "tilevsep": 0,
  "tileWidth": 32,
  "tilexoff": 0,
  "tileyoff": 0,
  "tile_count": 2
}