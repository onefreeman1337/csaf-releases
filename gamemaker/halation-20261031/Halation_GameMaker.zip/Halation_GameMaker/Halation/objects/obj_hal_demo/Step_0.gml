/// @description Run the clock and the street, step the world.
if (!is_undefined(demo)) hal_demo_step(demo);
