/// @description The world owns nothing to free; the demo removes its own tile layer and blocks.
if (variable_instance_exists(id, "demo") && !is_undefined(demo)) hal_demo_free(demo);
