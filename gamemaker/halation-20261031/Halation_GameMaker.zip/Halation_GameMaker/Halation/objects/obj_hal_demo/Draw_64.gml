/// @description The set, the flares, the slate.
if (!is_undefined(demo)) hal_demo_draw(demo);
