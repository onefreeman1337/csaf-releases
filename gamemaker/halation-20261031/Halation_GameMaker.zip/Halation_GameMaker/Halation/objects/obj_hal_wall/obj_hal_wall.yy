{
  "$GMObject": "",
  "%Name": "obj_hal_wall",
  "eventList": [],
  "managed": true,
  "name": "obj_hal_wall",
  "overriddenProperties": [],
  "parent": {
    "name": "Objects",
    "path": "folders/Objects.yy"
  },
  "parentObjectId": null,
  "persistent": false,
  "physicsAngularDamping": 0.1,
  "physicsDensity": 0.5,
  "physicsFriction": 0.2,
  "physicsGroup": 1,
  "physicsKinematic": false,
  "physicsLinearDamping": 0.1,
  "physicsObject": false,
  "physicsRestitution": 0.1,
  "physicsSensor": false,
  "physicsShape": 1,
  "physicsShapePoints": [],
  "physicsStartAwake": true,
  "properties": [],
  "resourceType": "GMObject",
  "resourceVersion": "2.0",
  "solid": false,
  "spriteId": {
    "name": "spr_hal_mark",
    "path": "sprites/spr_hal_mark/spr_hal_mark.yy"
  },
  "spriteMaskId": null,
  "visible": false
}