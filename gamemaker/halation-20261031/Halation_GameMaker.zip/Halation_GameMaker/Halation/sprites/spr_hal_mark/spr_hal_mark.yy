{
  "$GMSprite": "v2",
  "%Name": "spr_hal_mark",
  "bboxMode": 1,
  "bbox_bottom": 31,
  "bbox_left": 0,
  "bbox_right": 63,
  "bbox_top": 0,
  "collisionKind": 1,
  "collisionTolerance": 0,
  "DynamicTexturePage": false,
  "edgeFiltering": false,
  "For3D": false,
  "frames": [
    {
      "$GMSpriteFrame": "v1",
      "%Name": "139e8c94-4366-a4c2-1134-8d2c2ebcf48f",
      "name": "139e8c94-4366-a4c2-1134-8d2c2ebcf48f",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    }
  ],
  "gridX": 0,
  "gridY": 0,
  "height": 32,
  "HTile": false,
  "layers": [
    {
      "$GMImageLayer": "",
      "%Name": "b0e67830-34de-7413-b611-b3f3c919348a",
      "blendMode": 0,
      "displayName": "default",
      "isLocked": false,
      "name": "b0e67830-34de-7413-b611-b3f3c919348a",
      "opacity": 100,
      "resourceType": "GMImageLayer",
      "resourceVersion": "2.0",
      "visible": true
    }
  ],
  "name": "spr_hal_mark",
  "nineSlice": null,
  "origin": 0,
  "parent": {
    "name": "Sprites",
    "path": "folders/Sprites.yy"
  },
  "preMultiplyAlpha": false,
  "resourceType": "GMSprite",
  "resourceVersion": "2.0",
  "sequence": {
    "$GMSequence": "v1",
    "%Name": "spr_hal_mark",
    "autoRecord": true,
    "backdropHeight": 768,
    "backdropImageOpacity": 0.5,
    "backdropImagePath": "",
    "backdropWidth": 1366,
    "backdropXOffset": 0,
    "backdropYOffset": 0,
    "events": {
      "$KeyframeStore<MessageEventKeyframe>": "",
      "Keyframes": [],
      "resourceType": "KeyframeStore<MessageEventKeyframe>",
      "resourceVersion": "2.0"
    },
    "eventStubScript": null,
    "eventToFunction": {},
    "length": 1,
    "lockOrigin": false,
    "moments": {
      "$KeyframeStore<MomentsEventKeyframe>": "",
      "Keyframes": [],
      "resourceType": "KeyframeStore<MomentsEventKeyframe>",
      "resourceVersion": "2.0"
    },
    "name": "spr_hal_mark",
    "playback": 1,
    "playbackSpeed": 30,
    "playbackSpeedType": 0,
    "resourceType": "GMSequence",
    "resourceVersion": "2.0",
    "showBackdrop": true,
    "showBackdropImage": false,
    "timeUnits": 1,
    "tracks": [
      {
        "$GMSpriteFramesTrack": "",
        "builtinName": 0,
        "events": [],
        "inheritsTrackColour": true,
        "interpolation": 1,
        "isCreationTrack": false,
        "keyframes": {
          "$KeyframeStore<SpriteFrameKeyframe>": "",
          "Keyframes": [
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "139e8c94-4366-a4c2-1134-8d2c2ebcf48f",
                    "path": "sprites/spr_hal_mark/spr_hal_mark.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "04d9e1df-20f2-ef09-98f3-192061310d4d",
              "IsCreationKey": false,
              "Key": 0,
              "Length": 1,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            }
          ],
          "resourceType": "KeyframeStore<SpriteFrameKeyframe>",
          "resourceVersion": "2.0"
        },
        "modifiers": [],
        "name": "frames",
        "resourceType": "GMSpriteFramesTrack",
        "resourceVersion": "2.0",
        "spriteId": null,
        "trackColour": 0,
        "tracks": [],
        "traits": 0
      }
    ],
    "visibleRange": null,
    "volume": 1,
    "xorigin": 0,
    "yorigin": 0
  },
  "swatchColours": null,
  "swfPrecision": 0.5,
  "textureGroupId": {
    "name": "Default",
    "path": "texturegroups/Default"
  },
  "type": 0,
  "VTile": false,
  "width": 64
}