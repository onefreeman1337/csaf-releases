/// @description Draw the camp, or the dig opened from it, scaled to fit the GUI.
if (is_undefined(demo)) exit;
stra_demo_draw(demo);
