/// @description Run the camp, or the dig opened from it.
if (is_undefined(demo)) exit;
stra_demo_step(demo);
