{
  "$GMScript": "v1",
  "%Name": "stra_scene",
  "name": "stra_scene",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}