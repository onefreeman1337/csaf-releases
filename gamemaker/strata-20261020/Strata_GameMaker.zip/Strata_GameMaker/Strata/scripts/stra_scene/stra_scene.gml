/// stra_scene.gml - the Strata dig: one call opens a generated dig site, then step it and draw it until it closes. Five
/// calls: stra_open, stra_step, stra_draw, stra_closed, stra_free (and stra_result to read what was found).
///
/// Strata - Generated Excavation Digs for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// The RPG Maker MZ edition's Scene_Strata, ported: the same layout (a 13 x 10 face of 40 px cells in a timbered frame,
/// the stability plank above it, the tools and the found tray below), the same controls, the same messages and the same
/// collapse rule. Added here: a SECTION column showing the rock's six layers, a LEDGER of blows and stress, cracks that
/// spread across the face as the stress rises, rubble that falls when it gives way, a glint over each find as it comes
/// free, and a results card. The scene is 816 x 624 at scale 1; draw it anywhere at any scale.
///
/// ⛔ Open and step in Create / Step, never while a surface of yours is the draw target: the scene bakes its sheets and
/// panels into surfaces of its own there. stra_draw only blits (and rebuilds a surface the GPU lost, once).

#macro STRA_SCENE_W 816
#macro STRA_SCENE_H 624
#macro STRA_FACE_X 148
#macro STRA_FACE_Y 104
#macro STRA_FACE_W 520
#macro STRA_FACE_H 400

/// @function stra__is_scene(scene)
/// @description Internal. True for a scene made by stra_open.
function stra__is_scene(_T) { return is_struct(_T) && stra_is_site(_T[$ "site"]) && is_struct(_T[$ "st"]) && is_string(_T[$ "mode"]); }

/// @function stra__seed_of(seed, salt)
/// @description Internal. A request's seed: a number (or a string that is a plain whole number) as an unsigned 32-bit
/// number; any other word hashed; blank or absent -> a new site every time (mixed from the time and a counter).
function stra__seed_of(_s, _salt) {
    if (is_numeric(_s) && !is_nan(_s) && !is_infinity(_s)) return real(stra__u32(floor(abs(_s))));
    if (is_string(_s)) {
        var _t = string_trim(_s);
        if (_t != "") {
            var _digits = string_length(string_digits(_t)) == string_length(_t) && string_length(_t) <= 10;
            return _digits ? real(stra__u32(real(_t))) : stra_hash_string(_t);
        }
    }
    return real((stra__u32(stra_hash_string("strata")) ^ stra__u32(current_time + _salt * 7919)) & int64($FFFFFFFF));
}

/// @function stra_open(request)
/// @description Open a dig. The same seed, grade, rock and finds always give the same site.
/// @param {Struct} request { seed: a number or a word (blank = a new site every time; a word keys the dig to a place,
///   e.g. "mine-3-east"), grade: 1 (forgiving) .. 5 (hard) (2), rock: "auto" or one of stra_sites() ("sandstone",
///   "shale", "limestone", "clay", "basalt", "chalk", "ironstone", "permafrost"), finds: an array, one entry per find in
///   order, each a family id (stra_families()) or YOUR item's name ("Gold Coin" draws a coin - see stra_family_for);
///   blank = the seed chooses, title: shown above the face (blank = named after the rock), worked: true re-opens the face
///   worked out (nothing left to find), allow_leave: Escape packs up (true), detail: 1 or 2 (1; 2 draws every sheet at
///   twice the resolution - use it when you draw the scene above scale 1), sound: a function(name) called with "pick",
///   "hammer", "tool", "free", "collapse", "done" }
/// @returns {Struct} the scene, or undefined when the request is not a struct
function stra_open(_req) {
    if (!is_struct(_req)) return undefined;
    global.stra_opened = (variable_global_exists("stra_opened") ? global.stra_opened : 0) + 1;
    var _seed = stra__seed_of(_req[$ "seed"], global.stra_opened);
    var _gv = _req[$ "grade"], _grade = (is_numeric(_gv) && !is_nan(_gv) && !is_infinity(_gv)) ? clamp(floor(_gv), 1, 5) : 2;
    var _rk = _req[$ "rock"], _rock = (is_string(_rk) && array_get_index(stra_sites(), _rk) >= 0) ? _rk : undefined;
    // finds: each entry a family id or an item name; any that maps fills the gaps with one family from the seed (the MZ rule)
    var _want = _req[$ "finds"], _fams = undefined, _names = [];
    if (is_array(_want) && array_length(_want) > 0) {
        var _ids = stra_families(), _any = false, _m = [];
        for (var _i = 0; _i < array_length(_want); _i++) { var _f = stra_family_for(is_string(_want[_i]) ? _want[_i] : ""); array_push(_m, _f); array_push(_names, is_string(_want[_i]) ? _want[_i] : ""); if (!is_undefined(_f)) _any = true; }
        if (_any) { _fams = []; for (var _j = 0; _j < array_length(_m); _j++) array_push(_fams, is_undefined(_m[_j]) ? _ids[_seed mod array_length(_ids)] : _m[_j]); }
    }
    var _site = stra_generate({ seed: _seed, grade: _grade, site: _rock, families: _fams });
    if (!stra_is_site(_site)) return undefined;
    var _dt = _req[$ "detail"], _ss = (is_numeric(_dt) && _dt >= 2) ? 2 : 1;
    var _al = _req[$ "allow_leave"], _wk = _req[$ "worked"];
    var _ttl = _req[$ "title"];
    var _T = { req: _req, site: _site, st: stra_start(_site), seed: _seed, grade: _grade, rock: _site.site, ss: _ss,
        title: (is_string(_ttl) && string_trim(_ttl) != "") ? _ttl : stra_rock_title(_site.site), names: _names,
        worked: (is_bool(_wk) || is_numeric(_wk)) && _wk == true,
        allowLeave: is_undefined(_al) ? true : ((is_bool(_al) || is_numeric(_al)) && _al),
        sound: is_callable(_req[$ "sound"]) ? _req.sound : undefined,
        mode: "dig", tool: "pick", cx: floor(STRA_COLS / 2), cy: floor(STRA_ROWS / 2), frame: 0, shake: 0, wait: 0,
        status: "", tone: "", result: undefined, closed: false, inject: undefined, view: { x: 0, y: 0, s: 1 },
        rubble: array_create(STRA_COLS * STRA_ROWS, 0), cracks: stra_crack_net(_seed, STRA_FACE_W, STRA_FACE_H),
        dust: [], falls: [], glints: [], lastStrike: undefined, dustCol: stra__col(stra__mix(stra__rock(_site.site).fleck, stra__rock(_site.site).layers[1], 0.45)),
        bgSpr: -1, underSpr: -1, layerSpr: array_create(6, -1), grainSpr: -1, rockSpr: -1, rubbleSpr: -1, chunkSpr: [], iconSpr: [],
        faceSurf: -1, hudSurf: -1, cardSurf: -1, faceKey: "", hudKey: "", cardKey: "", held: { l: 0, r: 0, u: 0, d: 0 }, mouseCell: -1 };
    if (_T.worked) { for (var _c = 0; _c < array_length(_T.st.depth); _c++) _T.st.depth[_c] = 0; _T.st.collapsed = true; _T.mode = "done"; _T.wait = 0; }
    stra__bake(_T);
    stra__set_status(_T, _T.worked ? "This face is worked out. Nothing more to find here." : "Free every find before the face gives way.", "");
    if (_T.worked) _T.result = stra__make_result(_T, false);
    stra__refresh(_T);
    return _T;
}

/// @function stra__sound(scene, name)
/// @description Internal. Call the request's sound hook, if any.
function stra__sound(_T, _n) { if (!is_undefined(_T.sound)) _T.sound(_n); }

/// @function stra__bake_into(w, h, fn, args)
/// @description Internal. Draw with the painter fn(ctx, args) into a new transparent w x h sprite (premultiplied; draw
/// it with bm_one, bm_inv_src_alpha). Bakes under IDENTITY and hands the caller's world matrix back (Doctrine_Craft s19).
function stra__bake_into(_w, _h, _ss, _fn, _args) {
    var _mw = matrix_get(matrix_world); matrix_set(matrix_world, matrix_build_identity());
    var _s = surface_create(max(1, ceil(_w * _ss)), max(1, ceil(_h * _ss)));
    surface_set_target(_s); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    _fn(stra_cx_create(_ss), _args);
    gpu_pop_state(); surface_reset_target();
    var _spr = sprite_create_from_surface(_s, 0, 0, surface_get_width(_s), surface_get_height(_s), false, false, 0, 0);
    surface_free(_s);
    matrix_set(matrix_world, _mw);
    return _spr;
}

/// @function stra__kill(sprite)
/// @description Internal. Delete a sprite if it exists; returns -1.
function stra__kill(_s) { if (is_numeric(_s) && _s >= 0 && sprite_exists(_s)) sprite_delete(_s); return -1; }

/// @function stra__bake(scene)
/// @description Internal. Everything drawn once per dig, into sprites (sprites survive a lost surface): the six layer
/// sheets and the grain, the bed with the finds lying in it, the bedrock stones, the rubble sheet and falling chunks, the
/// tray icons, and the backdrop with the frame, the heading and the SECTION column.
function stra__bake(_T) {
    var _ss = _T.ss, _s = _T.site, _W = STRA_FACE_W, _H = STRA_FACE_H, _tb = get_timer();
    _T.bakeMs = {};
    var _mw = matrix_get(matrix_world); matrix_set(matrix_world, matrix_build_identity());
    // layer sheets (opaque) and the grain (transparent), drawn natively
    for (var _L = 0; _L < 6; _L++) {
        var _sf = surface_create(_W * _ss, _H * _ss);
        surface_set_target(_sf); stra__blend_begin(); stra__layer_sheet(_T.rock, _T.seed, _L, _W, _H, _ss); stra__blend_end(); surface_reset_target();
        _T.layerSpr[_L] = sprite_create_from_surface(_sf, 0, 0, _W * _ss, _H * _ss, false, false, 0, 0);
        surface_free(_sf);
    }
    var _gs = surface_create(_W * _ss, _H * _ss);
    surface_set_target(_gs); draw_clear_alpha(c_black, 0); stra__blend_begin(); stra__grain_sheet(_T.rock, _T.seed, _W, _H, _ss); stra__blend_end(); surface_reset_target();
    _T.grainSpr = sprite_create_from_surface(_gs, 0, 0, _W * _ss, _H * _ss, false, false, 0, 0);
    surface_free(_gs);
    matrix_set(matrix_world, _mw);
    // (each part's time is kept in scene.bakeMs: what a buyer's open costs, by part)
    var _t1 = get_timer(); _T.bakeMs.sheets = (_t1 - _tb) / 1000;
    // the bed with the finds lying in it (none when the face is worked out: they were taken)
    _T.underSpr = stra__bake_into(_W, _H, _ss, stra__pnt_under, { T: _T });
    var _t2 = get_timer(); _T.bakeMs.bed = (_t2 - _t1) / 1000;
    _T.rockSpr = stra__bake_into(_W, _H, _ss, stra__pnt_bedrock, { T: _T });
    _T.rubbleSpr = stra__bake_into(_W, _H, _ss, stra__pnt_rubble, { T: _T });
    for (var _k = 0; _k < 4; _k++) array_push(_T.chunkSpr, stra__bake_into(22, 22, _ss, stra__pnt_chunk, { T: _T, k: _k }));
    var _t3 = get_timer(); _T.bakeMs.stonesRubble = (_t3 - _t2) / 1000;
    for (var _f = 0; _f < array_length(_s.finds); _f++) array_push(_T.iconSpr, stra__bake_into(80, 62, _ss, stra__pnt_icon, { F: _s.finds[_f] }));
    var _t4 = get_timer(); _T.bakeMs.icons = (_t4 - _t3) / 1000;
    _T.bgSpr = stra__bake_into(STRA_SCENE_W, STRA_SCENE_H, _ss, stra__pnt_bg, { T: _T });
    _T.bakeMs.backdrop = (get_timer() - _t4) / 1000;
}

function stra__pnt_under(_c, _a) {
    var _T = _a.T, _s = _T.site;
    stra_draw_under(_c, _T.rock, STRA_FACE_W, STRA_FACE_H, _s.seed);
    if (_T.worked) return;
    for (var _f = 0; _f < array_length(_s.finds); _f++) {
        var _F = _s.finds[_f];
        stra_cx_save(_c); stra_cx_translate(_c, _F.x * STRA_CELL, _F.y * STRA_CELL); stra_draw_find(_c, _F); stra_cx_restore(_c);
    }
}
function stra__pnt_bedrock(_c, _a) {
    var _s = _a.T.site;
    for (var _y = 0; _y < _s.rows; _y++) for (var _x = 0; _x < _s.cols; _x++) if (_s.rock[_y * _s.cols + _x]) stra_draw_bedrock(_c, _x, _y, _s.seed);
}
function stra__pnt_rubble(_c, _a) {
    // the fallen face: a jumble of broken blocks in the rock's own colours, over the dark bed. Drawn NATIVELY (a vertex-
    // coloured fan per block, lit from the top left, and a dark rim): through the canvas kit the 520 blocks cost ~0.45 s of
    // every open (measured 2026-10-20: 476 ms of a 941 ms open), natively they cost a few ms.
    var _T = _a.T, _P = stra__rock(_T.rock), _r = stra_rng(real((stra__u32(_T.seed) ^ int64($B0B)) & int64($FFFFFFFF))), _k = _c.m[0];
    stra__blend_begin();
    draw_set_alpha(1); draw_set_colour(stra__col(stra__shade(_P.under, 0.2)));
    draw_rectangle(0, 0, STRA_FACE_W * _k, STRA_FACE_H * _k, false);
    for (var _i = 0; _i < 520; _i++) {
        var _u0 = stra_rand(_r); var _u1 = stra_rand(_r); var _u2 = stra_rand(_r); var _u3 = stra_rand(_r); var _u4 = stra_rand(_r);
        var _x = _u0 * STRA_FACE_W, _y = _u1 * STRA_FACE_H, _sz = 4 + _u2 * 10, _rgb = _P.layers[floor(_u3 * 6)];
        var _pts = [];
        for (var _q = 0; _q < 5; _q++) { var _uq = stra_rand(_r); var _aq = _u4 * STRA_TAU + _q / 5 * STRA_TAU; array_push(_pts, [_x + cos(_aq) * _sz * (0.6 + _uq * 0.5), _y + sin(_aq) * _sz * (0.6 + _uq * 0.5)]); }
        var _lit = stra__col(stra__shade(_rgb, 0.18)), _dk = stra__col(stra__shade(_rgb, -0.3));
        draw_primitive_begin(pr_trianglefan);
        draw_vertex_colour(_x * _k, _y * _k, merge_colour(_lit, _dk, 0.5), 1);
        for (var _q2 = 0; _q2 <= 5; _q2++) {
            var _p = _pts[_q2 mod 5], _t = clamp(((_p[0] - _x) + (_p[1] - _y)) / (4 * _sz) + 0.5, 0, 1);
            draw_vertex_colour(_p[0] * _k, _p[1] * _k, merge_colour(_lit, _dk, _t), 1);
        }
        draw_primitive_end();
        draw_primitive_begin(pr_linestrip);
        for (var _q3 = 0; _q3 <= 5; _q3++) { var _p3 = _pts[_q3 mod 5]; draw_vertex_colour(_p3[0] * _k, _p3[1] * _k, c_black, 0.35); }
        draw_primitive_end();
    }
    draw_set_colour(c_white);
    stra__blend_end();
}
function stra__pnt_chunk(_c, _a) {
    var _T = _a.T, _P = stra__rock(_T.rock), _r = stra_rng(real((stra__u32(_T.seed) ^ stra__u32(901 + _a.k * 37)) & int64($FFFFFFFF)));
    var _pts = [], _rgb = _P.layers[1 + _a.k];
    for (var _q = 0; _q < 6; _q++) { var _u = stra_rand(_r); var _aq = _q / 6 * STRA_TAU; array_push(_pts, [11 + cos(_aq) * 9 * (0.65 + _u * 0.4), 11 + sin(_aq) * 9 * (0.65 + _u * 0.4)]); }
    stra__blend_begin();
    var _g = stra_cx_linear(_c, 2, 2, 20, 20); stra_cx_stop(_g, 0, stra__shade(_rgb, 0.2)); stra_cx_stop(_g, 1, stra__shade(_rgb, -0.35));
    _c.fill = _g; stra__poly(_c, _pts); stra_cx_fill(_c);
    _c.stroke = stra_cx_solid([0, 0, 0], 0.5); _c.lw = 1; stra_cx_stroke(_c);
    stra__blend_end();
}
function stra__pnt_icon(_c, _a) {
    var _F = _a.F, _sc = min(74 / (_F.w * STRA_CELL), 56 / (_F.h * STRA_CELL));
    stra_cx_translate(_c, 40 - _F.w * STRA_CELL * _sc / 2, 31 - _F.h * STRA_CELL * _sc / 2); stra_cx_scale(_c, _sc, _sc);
    stra_draw_find(_c, _F);
}
function stra__pnt_bg(_c, _a) {
    var _T = _a.T, _P = stra__rock(_T.rock);
    stra_draw_backdrop(_c, STRA_SCENE_W, STRA_SCENE_H);
    stra_draw_frame(_c, STRA_FACE_X, STRA_FACE_Y, STRA_FACE_W, STRA_FACE_H, _T.seed);
    stra__blend_begin();
    // heading: the title and the controls
    stra__text_fit(_c, _T.title, STRA_SCENE_W / 2 + 1, 27, 30, [0, 0, 0], 0.6, "center", STRA_FACE_DISPLAY, 760);
    stra__text_fit(_c, _T.title, STRA_SCENE_W / 2, 26, 30, [251, 231, 192], 1, "center", STRA_FACE_DISPLAY, 760);
    stra__text(_c, "arrows move, Enter strikes, Q or W changes tool, Esc packs up. Or click a cell.", STRA_SCENE_W / 2, 52, 13, [184, 154, 112], 1, "center", STRA_FACE_BODY);
    // the SECTION column: the six layers of this rock, outer face at the top
    stra__text(_c, "SECTION", 66, 112, 13, [214, 186, 140], 1, "center", STRA_FACE_DISPLAY);
    _c.fill = stra_cx_solid([0, 0, 0], 0.45); stra_cx_fill_rect(_c, 22, 124, 90, 330);
    for (var _L = 0; _L < 6; _L++) {
        var _y = 128 + _L * 54;
        _c.fill = stra_cx_solid(_P.layers[_L]); stra_cx_fill_rect(_c, 40, _y, 66, 50);
        stra__text(_c, string(_L + 1), 31, _y + 25, 13, [190, 164, 124], 1, "center", STRA_FACE_BODY);
    }
    stra__blend_end();
    // the layer sheets themselves in the column (their structure, not only their colour)
    for (var _L2 = 0; _L2 < 6; _L2++) if (sprite_exists(_T.layerSpr[_L2])) {
        var _k = _c.m[0];
        draw_sprite_part_ext(_T.layerSpr[_L2], 0, 200 * _T.ss, (60 + _L2 * 50) * _T.ss, 66 * _T.ss, 50 * _T.ss, 40 * _k, (128 + _L2 * 54) * _k, _k / _T.ss, _k / _T.ss, c_white, 1);
    }
    stra__blend_begin();
    _c.stroke = stra_cx_solid([150, 112, 66], 0.9); _c.lw = 1;
    for (var _L3 = 0; _L3 < 6; _L3++) { stra_cx_begin(_c); stra_cx_rect(_c, 40.5, 128.5 + _L3 * 54, 65, 49); stra_cx_stroke(_c); }
    stra__text_fit(_c, string_upper(string_char_at(_T.rock, 1)) + string_copy(_T.rock, 2, 40), 66, 470, 14, [214, 186, 140], 1, "center", STRA_FACE_BODY, 100);
    stra__text(_c, "LEDGER", 750, 112, 13, [214, 186, 140], 1, "center", STRA_FACE_DISPLAY);
    stra__text(_c, "STABILITY", 74, 79, 12, [214, 186, 140], 1, "center", STRA_FACE_DISPLAY);
    stra__blend_end();
}

/// @function stra__set_status(scene, text, tone)
/// @description Internal. The line under the face; tone "good", "bad" or "".
function stra__set_status(_T, _text, _tone) { _T.status = _text; _T.tone = _tone; }

/// @function stra__refresh(scene)
/// @description Internal. Redraw what changed (or was lost): the face when a blow changed it, the panels when a number
/// or the tool changed, the results card once. Never per frame otherwise.
function stra__refresh(_T) {
    var _mw = matrix_get(matrix_world); matrix_set(matrix_world, matrix_build_identity());
    var _ss = _T.ss, _st = _T.st, _s = _T.site;
    var _f = (_s.stability > 0) ? _st.stress / _s.stability : 0;
    var _fk = string(_st.blows) + ":" + string(_st.collapsed) + ":" + string(_T.mode);
    if (!surface_exists(_T.faceSurf) || _fk != _T.faceKey) {
        if (!surface_exists(_T.faceSurf)) _T.faceSurf = surface_create(STRA_FACE_W * _ss, STRA_FACE_H * _ss);
        surface_set_target(_T.faceSurf); draw_clear_alpha(c_black, 0);
        stra__compose_face(_T, _st.collapsed ? 1 : _f);
        surface_reset_target();
        _T.faceKey = _fk;
    }
    var _freed = stra_freed_list(_s, _st);
    var _hk = string(_st.blows) + ":" + _T.tool + ":" + string(array_length(_freed)) + ":" + _T.status + ":" + _T.mode;
    if (!surface_exists(_T.hudSurf) || _hk != _T.hudKey) {
        if (!surface_exists(_T.hudSurf)) _T.hudSurf = surface_create(STRA_SCENE_W * _ss, STRA_SCENE_H * _ss);
        surface_set_target(_T.hudSurf); draw_clear_alpha(c_black, 0);
        gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
        stra__pnt_hud(stra_cx_create(_ss), _T, _freed, _f);
        gpu_pop_state(); surface_reset_target();
        _T.hudKey = _hk;
    }
    if (_T.mode == "done" && is_struct(_T.result) && (!surface_exists(_T.cardSurf) || _T.cardKey != "card")) {
        if (!surface_exists(_T.cardSurf)) _T.cardSurf = surface_create(400 * _ss, 210 * _ss);
        surface_set_target(_T.cardSurf); draw_clear_alpha(c_black, 0);
        gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
        stra__pnt_card(stra_cx_create(_ss), _T);
        gpu_pop_state(); surface_reset_target();
        _T.cardKey = "card";
    }
    matrix_set(matrix_world, _mw);
}

/// @function stra__cell_hash(c, k)
/// @description Internal. A stable number in [0, 1) for a cell and a salt (the step edges' jitter, so an edge does not
/// move when a blow elsewhere redraws the face).
function stra__cell_hash(_c, _k) { return real(stra__imul(stra__u32(_c * 2654435761 + _k * 40503) ^ int64($5BD1E995), int64($27D4EB2D)) & int64($FFFF)) / 65536; }

/// @function stra__compose_face(scene, f)
/// @description Internal. The face onto the current target at the scene's detail: each standing cell from the layer
/// sheet its cut has reached (rock has no grid: a region cut to the same layer is one continuous surface), the grain,
/// the cracks up to share f, cleared and bedrock cells cut away, then the steps (a cell standing higher than its
/// neighbour casts a shadow down onto it and catches a lit lip) and the bedrock stones.
function stra__compose_face(_T, _f) {
    var _s = _T.site, _st = _T.st, _ss = _T.ss, _C = STRA_CELL, _cols = _s.cols, _rows = _s.rows, _k = _C * _ss;
    gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha); gpu_set_texfilter(false);
    for (var _y = 0; _y < _rows; _y++) for (var _x = 0; _x < _cols; _x++) {
        var _c = _y * _cols + _x;
        if (_s.rock[_c] || _st.depth[_c] <= 0 || _T.rubble[_c]) continue;
        var _L = min(5, _s.depth[_c] - _st.depth[_c]);
        draw_sprite_part(_T.layerSpr[max(0, _L)], 0, _x * _k, _y * _k, _k, _k, _x * _k, _y * _k);
    }
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);   // the grain sheet is premultiplied
    for (var _y2 = 0; _y2 < _rows; _y2++) for (var _x2 = 0; _x2 < _cols; _x2++) {
        var _c2 = _y2 * _cols + _x2;
        if (_s.rock[_c2] || _st.depth[_c2] <= 0 || _T.rubble[_c2]) continue;
        draw_sprite_part(_T.grainSpr, 0, _x2 * _k, _y2 * _k, _k, _k, _x2 * _k, _y2 * _k);
    }
    // cracks: every segment the stress has reached, a dark cut with a pale lower lip
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    var _cr = _T.cracks, _shown = 0;
    for (var _i = 0; _i < array_length(_cr); _i++) {
        var _q = _cr[_i];
        if (_q.t > _f) continue;
        _shown++;
        draw_set_alpha(0.3); draw_line_width_colour((_q.x0 + 0.8) * _ss, (_q.y0 + 1) * _ss, (_q.x1 + 0.8) * _ss, (_q.y1 + 1) * _ss, max(1, _q.w * 0.7 * _ss), c_white, c_white);
        draw_set_alpha(0.82); draw_line_width_colour(_q.x0 * _ss, _q.y0 * _ss, _q.x1 * _ss, _q.y1 * _ss, max(1, _q.w * _ss), make_colour_rgb(16, 10, 6), make_colour_rgb(16, 10, 6));
    }
    _T.cracksShown = _shown;
    // rubble last of the standing face, so a fallen cell covers the cracks that ran across it
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    draw_set_alpha(1);
    for (var _y6 = 0; _y6 < _rows; _y6++) for (var _x6 = 0; _x6 < _cols; _x6++) {
        var _c6 = _y6 * _cols + _x6;
        if (!_s.rock[_c6] && _st.depth[_c6] > 0 && _T.rubble[_c6]) draw_sprite_part(_T.rubbleSpr, 0, _x6 * _k, _y6 * _k, _k, _k, _x6 * _k, _y6 * _k);
    }
    // cut away cleared cells and the bedrock's own cells (the bed shows round a stone, as in the MZ edition)
    gpu_set_blendmode_ext(bm_zero, bm_zero);
    draw_set_alpha(1); draw_set_colour(c_black);
    for (var _y3 = 0; _y3 < _rows; _y3++) for (var _x3 = 0; _x3 < _cols; _x3++) {
        var _c3 = _y3 * _cols + _x3;
        if (_s.rock[_c3] || _st.depth[_c3] <= 0) draw_rectangle(_x3 * _k, _y3 * _k, (_x3 + 1) * _k - 1, (_y3 + 1) * _k - 1, false);
    }
    // depth: a cell darkens with every layer taken off it, so a cut reads as DOWN on every rock (on the pale rocks the
    // six layer colours alone sit too close together: looked at 2026-10-20, a limestone cut read as flat grey tiles)
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    draw_set_colour(c_black);
    for (var _y5 = 0; _y5 < _rows; _y5++) for (var _x5 = 0; _x5 < _cols; _x5++) {
        var _c5 = _y5 * _cols + _x5;
        if (_s.rock[_c5] || _st.depth[_c5] <= 0 || _T.rubble[_c5]) continue;
        var _taken = _s.depth[_c5] - _st.depth[_c5];
        if (_taken > 0) { draw_set_alpha(min(0.44, 0.085 * _taken)); draw_rectangle(_x5 * _k, _y5 * _k, (_x5 + 1) * _k - 1, (_y5 + 1) * _k - 1, false); }
    }
    // walls: where a neighbour stands higher, the wall casts a soft shadow into the lower cell from the sides the light
    // comes from (top and left) and shows its lit face on the far sides (bottom and right); an open cell (the bed showing)
    // takes the deepest shadow. Height = minus the layers taken; rubble counts as uncut; the bed is far below.
    var _nb = [[0, -1], [-1, 0], [0, 1], [1, 0]];
    for (var _y4 = 0; _y4 < _rows; _y4++) for (var _x4 = 0; _x4 < _cols; _x4++) {
        var _c4 = _y4 * _cols + _x4;
        if (_s.rock[_c4]) continue;
        var _open = _st.depth[_c4] <= 0;
        var _d = _open ? -99 : (_T.rubble[_c4] ? 0 : -(_s.depth[_c4] - _st.depth[_c4]));
        for (var _n = 0; _n < 4; _n++) {
            var _nx = _x4 + _nb[_n][0], _ny = _y4 + _nb[_n][1];
            if (_nx < 0 || _ny < 0 || _nx >= _cols || _ny >= _rows) continue;
            var _nc = _ny * _cols + _nx;
            if (_s.rock[_nc]) continue;
            var _dn = (_st.depth[_nc] <= 0) ? -99 : (_T.rubble[_nc] ? 0 : -(_s.depth[_nc] - _st.depth[_nc]));
            if (_dn <= _d) continue;
            var _drop = _open ? 5 : min(5, _dn - _d);
            var _x0 = _x4 * _C, _y0 = _y4 * _C, _x1 = _x0 + _C, _y1 = _y0 + _C;
            if (_n < 2) {
                // shadow cast into this cell from its top (n 0) or left (n 1) wall
                var _sw = (3 + 1.6 * _drop) * _ss, _sa = _open ? 0.62 : min(0.55, 0.16 + 0.08 * _drop);
                draw_primitive_begin(pr_trianglestrip);
                if (_n == 0) {
                    draw_vertex_colour(_x0 * _ss, _y0 * _ss, c_black, _sa); draw_vertex_colour(_x1 * _ss, _y0 * _ss, c_black, _sa);
                    draw_vertex_colour(_x0 * _ss, _y0 * _ss + _sw, c_black, 0); draw_vertex_colour(_x1 * _ss, _y0 * _ss + _sw, c_black, 0);
                } else {
                    draw_vertex_colour(_x0 * _ss, _y0 * _ss, c_black, _sa); draw_vertex_colour(_x0 * _ss, _y1 * _ss, c_black, _sa);
                    draw_vertex_colour(_x0 * _ss + _sw, _y0 * _ss, c_black, 0); draw_vertex_colour(_x0 * _ss + _sw, _y1 * _ss, c_black, 0);
                }
                draw_primitive_end();
            } else {
                // the lit face of the bottom (n 2) or right (n 3) wall, facing the light: drawn as the WALL ITSELF, a strip
                // banded with the rock's own layers from the neighbour's surface down (the strata showing in the cut), lit
                // (looked at 2026-10-21: a plain pale band read as a grey UI line round each cut, not as rock)
                // at most three bands, each at least ~2.5 px at scale 1 (looked at 2026-10-21: five 1 px bands read as hairlines)
                var _tk = (_dn == -99) ? 6 : -_dn, _bands = max(1, min(3, _drop, 6 - _tk)), _bw = (2.5 + 1.6 * min(_drop, 4)) * _ss, _bh = _bw / _bands;
                var _lay = stra__rock(_T.rock).layers;
                draw_set_alpha(0.92);
                for (var _bi = 0; _bi < _bands; _bi++) {
                    draw_set_colour(stra__col(stra__shade(_lay[clamp(_tk + _bi, 0, 5)], 0.12 - 0.05 * _bi)));
                    if (_n == 2) draw_rectangle(_x0 * _ss, _y1 * _ss - _bw + _bi * _bh, _x1 * _ss - 1, _y1 * _ss - _bw + (_bi + 1) * _bh - 1, false);
                    else draw_rectangle(_x1 * _ss - _bw + _bi * _bh, _y0 * _ss, _x1 * _ss - _bw + (_bi + 1) * _bh - 1, _y1 * _ss - 1, false);
                }
                // the wall's foot in shadow where it meets the lower floor
                draw_set_alpha(0.45); draw_set_colour(c_black);
                if (_n == 2) draw_line_width(_x0 * _ss, _y1 * _ss - _bw, _x1 * _ss, _y1 * _ss - _bw, max(1, 0.9 * _ss));
                else draw_line_width(_x1 * _ss - _bw, _y0 * _ss, _x1 * _ss - _bw, _y1 * _ss, max(1, 0.9 * _ss));
            }
            // the lip of the higher cell catches the light along its edge
            draw_set_alpha(0.2); draw_set_colour(make_colour_rgb(255, 240, 215));
            if (_n == 0) draw_line_width(_x0 * _ss, _y0 * _ss - 1, _x1 * _ss, _y0 * _ss - 1, max(1, _ss));
            else if (_n == 1) draw_line_width(_x0 * _ss - 1, _y0 * _ss, _x0 * _ss - 1, _y1 * _ss, max(1, _ss));
        }
    }
    draw_set_alpha(1); draw_set_colour(c_white);
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    draw_sprite(_T.rockSpr, 0, 0, 0);
    gpu_pop_state();
    draw_set_alpha(1); draw_set_colour(c_white);
}

/// @function stra__pnt_hud(ctx, scene, freed, f)
/// @description Internal. The panels that change: the stability plank, the LEDGER, the status line, the tools and the
/// found tray.
function stra__pnt_hud(_c, _T, _freed, _f) {
    var _s = _T.site, _st = _T.st;
    stra_cx_save(_c); stra_cx_translate(_c, STRA_FACE_X, 64); stra_draw_gauge(_c, STRA_FACE_W, _f, _T.seed); stra_cx_restore(_c);
    stra__blend_begin();
    // LEDGER
    var _rows = [["Grade", string(_T.grade)], ["Blows", string(_st.blows)], ["Stress", string(floor(100 * _f + 0.5)) + "%"], ["Finds", string(array_length(_freed)) + " of " + string(array_length(_s.finds))]];
    _c.fill = stra_cx_solid([0, 0, 0], 0.45); stra_cx_fill_rect(_c, 704, 124, 92, 330);
    for (var _i = 0; _i < 4; _i++) {
        var _y = 150 + _i * 78;
        stra__text(_c, _rows[_i][0], 750, _y, 13, [184, 154, 112], 1, "center", STRA_FACE_BODY);
        var _hot = (_i == 2 && _f > 0.8);
        stra__text_fit(_c, _rows[_i][1], 750, _y + 28, 22, _hot ? [255, 120, 90] : [251, 231, 192], 1, "center", STRA_FACE_DISPLAY, 84);
        if (_i < 3) { _c.fill = stra_cx_solid([150, 112, 66], 0.5); stra_cx_fill_rect(_c, 716, _y + 50, 68, 1); }
    }
    // status
    var _tone = (_T.tone == "bad") ? [255, 156, 134] : ((_T.tone == "good") ? [200, 245, 166] : [241, 223, 180]);
    stra__text_fit(_c, _T.status, STRA_SCENE_W / 2 + 1, 544, 17, [0, 0, 0], 0.6, "center", STRA_FACE_BODY, 760);
    stra__text_fit(_c, _T.status, STRA_SCENE_W / 2, 543, 17, _tone, 1, "center", STRA_FACE_BODY, 760);
    stra__blend_end();
    // tools
    stra_cx_save(_c); stra_cx_translate(_c, 184, 586); stra_draw_tool(_c, "pick", 26, _T.tool == "pick"); stra_cx_restore(_c);
    stra_cx_save(_c); stra_cx_translate(_c, 254, 586); stra_draw_tool(_c, "hammer", 26, _T.tool == "hammer"); stra_cx_restore(_c);
    // found tray
    stra__blend_begin();
    for (var _k = 0; _k < array_length(_s.finds); _k++) {
        var _x = 326 + _k * 88, _is = array_get_index(_freed, _k) >= 0;
        _c.fill = stra_cx_solid([0, 0, 0], 0.35); stra_cx_fill_rect(_c, _x, 556, 80, 62);
        _c.stroke = _is ? stra_cx_solid([232, 199, 126]) : stra_cx_solid([200, 170, 120], 0.35); _c.lw = 1.5;
        stra_cx_begin(_c); stra_cx_rect(_c, _x + 0.5, 556.5, 79, 61); stra_cx_stroke(_c);
        if (!_is) stra__text(_c, "?", _x + 40, 588, 26, [220, 190, 140], 0.5, "center", STRA_FACE_BODY);
    }
    stra__blend_end();
    var _m = _c.m;
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    for (var _k2 = 0; _k2 < array_length(_s.finds); _k2++) if (array_get_index(_freed, _k2) >= 0 && sprite_exists(_T.iconSpr[_k2])) draw_sprite_ext(_T.iconSpr[_k2], 0, (326 + _k2 * 88) * _m[0], 556 * _m[0], _m[0] / _T.ss, _m[0] / _T.ss, 0, c_white, 1);
    gpu_pop_state();
}

/// @function stra__pnt_card(ctx, scene)
/// @description Internal. The results card: what happened, the finds freed drawn at their own size, how to leave.
function stra__pnt_card(_c, _T) {
    var _r = _T.result, _W = 400, _H = 210;
    stra__blend_begin();
    _c.fill = stra_cx_solid([0, 0, 0], 0.55); stra__rrect(_c, 6, 8, _W - 6, _H - 8, 14); stra_cx_fill(_c);
    var _g = stra_cx_linear(_c, 0, 0, 0, _H); stra_cx_stop(_g, 0, [46, 32, 22]); stra_cx_stop(_g, 1, [24, 16, 11]);
    _c.fill = _g; stra__rrect(_c, 0, 0, _W - 6, _H - 8, 14); stra_cx_fill(_c);
    _c.stroke = stra_cx_solid([200, 150, 80], 0.9); _c.lw = 2; stra__rrect(_c, 6, 6, _W - 18, _H - 20, 10); stra_cx_stroke(_c);
    var _head = _T.worked ? "Worked out" : (_r.cleared ? (_r.collapsed ? "Freed as it fell" : "Every find is free") : (_r.left ? "Packed up" : "The face gave way"));
    stra__text_fit(_c, _head, (_W - 6) / 2, 34, 24, [251, 231, 192], 1, "center", STRA_FACE_DISPLAY, 360);
    stra__text(_c, string(_r.found) + " of " + string(_r.total) + " found in " + string(_r.blows) + " blows", (_W - 6) / 2, 60, 14, [200, 172, 130], 1, "center", STRA_FACE_BODY);
    stra__text(_c, "Enter or click to leave", (_W - 6) / 2, _H - 26, 13, [168, 140, 104], 1, "center", STRA_FACE_BODY);
    stra__blend_end();
    var _n = array_length(_r.freed), _m = _c.m;
    if (_n == 0) { stra__blend_begin(); stra__text(_c, "Nothing came out of the rock.", (_W - 6) / 2, 118, 15, [190, 160, 128], 1, "center", STRA_FACE_BODY); stra__blend_end(); return; }
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    var _x0 = ((_W - 6) - (_n * 84 - 4)) / 2;
    for (var _i = 0; _i < _n; _i++) { var _ix = _r.freed[_i]; if (sprite_exists(_T.iconSpr[_ix])) draw_sprite_ext(_T.iconSpr[_ix], 0, (_x0 + _i * 84) * _m[0], 84 * _m[0], _m[0] / _T.ss, _m[0] / _T.ss, 0, c_white, 1); }
    gpu_pop_state();
    stra__blend_begin();
    // each find under its picture by the buyer's own name for it (the family id when the request named none)
    for (var _j = 0; _j < _n; _j++) stra__text_fit(_c, _r.names[_j], _x0 + _j * 84 + 40, 156, 12, [214, 186, 140], 1, "center", STRA_FACE_BODY, 80);
    stra__blend_end();
}

/// @function stra__make_result(scene, left)
/// @description Internal. The dig's result.
function stra__make_result(_T, _left) {
    // a face opened worked out has every cell cleared, but nothing was found THIS time: its finds were taken before
    var _s = _T.site, _fr = _T.worked ? [] : stra_freed_list(_s, _T.st), _fam = [], _nm = [];
    for (var _i = 0; _i < array_length(_fr); _i++) { array_push(_fam, _s.finds[_fr[_i]].family); array_push(_nm, (_fr[_i] < array_length(_T.names)) ? _T.names[_fr[_i]] : _s.finds[_fr[_i]].family); }
    return { freed: _fr, families: _fam, names: _nm, found: array_length(_fr), total: array_length(_s.finds), cleared: array_length(_fr) == array_length(_s.finds) && !_T.worked,
        collapsed: _T.st.collapsed && !_T.worked, left: _left, worked: _T.worked, blows: _T.st.blows, stress: _T.st.stress, stability: _s.stability,
        seed: _T.seed, grade: _T.grade, rock: _T.rock };
}

/// @function stra__puff(scene, col, row, n)
/// @description Internal. Dust from a blow: n motes thrown up from a cell, falling back.
function stra__puff(_T, _col, _row, _n) {
    var _r = stra_rng(real(stra__u32(_T.frame * 2654435761 + _col * 977 + _row * 131)));
    for (var _k = 0; _k < _n; _k++) {
        var _u0 = stra_rand(_r); var _u1 = stra_rand(_r); var _u2 = stra_rand(_r); var _u3 = stra_rand(_r); var _u4 = stra_rand(_r); var _u5 = stra_rand(_r);
        array_push(_T.dust, { x: _col * STRA_CELL + STRA_CELL / 2 + (_u0 - 0.5) * STRA_CELL, y: _row * STRA_CELL + STRA_CELL / 2 + (_u1 - 0.5) * STRA_CELL,
            s: 0.8 + _u2 * 1.6, vx: (_u3 - 0.5) * 3.2, vy: -1.5 - _u4 * 2.2, life: 18 + floor(_u5 * 16) });
    }
    while (array_length(_T.dust) > 80) array_delete(_T.dust, 0, 1);
}

/// @function stra__collapse(scene)
/// @description Internal. The collapse: every cell not over a freed find falls back to at least one layer of rubble,
/// rubble rains from the top of the face and the frame shakes (the MZ collapse, with the fall drawn).
function stra__collapse(_T) {
    var _s = _T.site, _st = _T.st, _fr = stra_freed_list(_s, _st);
    // the whole face slumps: every cell that is not bedrock and not over a freed find becomes rubble (looked at 2026-10-20:
    // rubble on the cut cells alone left an intact-looking face under a red gauge, and the collapse did not read)
    for (var _c = 0; _c < array_length(_st.depth); _c++) {
        var _own = stra_find_at(_s, _c);
        if (_own >= 0 && array_get_index(_fr, _own) >= 0) continue;
        if (_s.rock[_c]) continue;
        _T.rubble[_c] = 1;
        _st.depth[_c] = max(_st.depth[_c], 1);
    }
    _T.shake = 26;
    var _r = stra_rng(real(stra__u32(_T.seed + 4242)));
    for (var _i = 0; _i < 46; _i++) {
        var _u0 = stra_rand(_r); var _u1 = stra_rand(_r); var _u2 = stra_rand(_r); var _u3 = stra_rand(_r); var _u4 = stra_rand(_r);
        array_push(_T.falls, { x: _u0 * STRA_FACE_W, y: -10 - _u1 * 120, vx: (_u2 - 0.5) * 1.6, vy: 1 + _u3 * 2, rot: _u4 * 360, vr: (_u2 - 0.5) * 16, k: _i mod 4, life: 70 + floor(_u1 * 30) });
    }
    stra__puff(_T, floor(_s.cols / 2), 1, 24);
}

/// @function stra__end(scene, text, tone, left)
/// @description Internal. Settle the dig: the result, the status, the card.
function stra__end(_T, _text, _tone, _left) {
    _T.result = stra__make_result(_T, _left);
    _T.mode = "done"; _T.wait = 0;
    stra__set_status(_T, _text, _tone);
    stra__sound(_T, "done");
}

/// @function stra__strike_at(scene, col, row)
/// @description Internal. One blow with the current tool, and everything it causes (the MZ strikeAt).
function stra__strike_at(_T, _col, _row) {
    var _s = _T.site, _st = _T.st;
    var _res = stra_strike(_s, _st, _T.tool, _col, _row);
    _T.lastStrike = _res;
    stra__sound(_T, _T.tool);
    _T.shake = (_T.tool == "hammer") ? 10 : 5;
    stra__puff(_T, _col, _row, (_T.tool == "hammer") ? 18 : 10);
    for (var _g = 0; _g < array_length(_res.freed); _g++) array_push(_T.glints, { find: _res.freed[_g], age: 0 });
    if (array_length(_res.freed) > 0) stra__sound(_T, "free");
    var _fr = stra_freed_list(_s, _st), _n = array_length(_s.finds);
    // a find freed by the blow that also brings the face down still counts
    if (array_length(_fr) == _n) {
        if (_res.collapsed) { stra__sound(_T, "collapse"); _T.shake = 26; stra__end(_T, "Every find is free, just as the face gives way.", "good", false); return _res; }
        stra__end(_T, "Every find is free. The face holds.", "good", false); return _res;
    }
    if (_res.collapsed) { stra__sound(_T, "collapse"); stra__collapse(_T); stra__end(_T, "The face gives way. " + string(array_length(_fr)) + " of " + string(_n) + " saved.", "bad", false); return _res; }
    if (array_length(_res.freed) > 0) stra__set_status(_T, "Free! " + string(array_length(_fr)) + " of " + string(_n) + " found.", "good");
    else if (array_length(_res.changed) == 0) stra__set_status(_T, "Nothing gives there.", "");
    else if (_st.stress / _s.stability > 0.8) stra__set_status(_T, "The face is groaning. Careful.", "bad");
    else stra__set_status(_T, (_T.tool == "hammer") ? "The hammer bites wide." : "The pick bites deep.", "");
    return _res;
}

/// @function stra__repeat(scene, key, down)
/// @description Internal. A held key as a press that repeats (first after 14 steps, then every 5).
function stra__repeat(_T, _k, _down) {
    if (!_down) { _T.held[$ _k] = 0; return false; }
    _T.held[$ _k] += 1; var _n = _T.held[$ _k];
    return _n == 1 || (_n > 14 && ((_n - 14) mod 5) == 0);
}

/// @function stra_step(scene, [mouse_x], [mouse_y])
/// @description Run the scene one frame: read the keyboard (arrows move the mark; Enter, Space or Z strikes; Q, W, Tab
/// or Shift changes tool; Escape packs up when allowed; on the results, Enter, Space, Z or a click leaves) and the mouse
/// (the mark follows the pointer over the face; click a cell to strike it, a tool to take it). Pass the pointer in the
/// SAME coordinates you give stra_draw (for Draw GUI: device_mouse_x_to_gui(0), device_mouse_y_to_gui(0)). For
/// tutorials, tests or replays set scene.inject = { dx, dy, strike, col, row, tool ("pick", "hammer" or "switch"), leave,
/// ok } for one frame: it replaces the devices (col and row aim the strike at a cell).
/// @param {Struct} scene
/// @param {Real} [mouse_x]
/// @param {Real} [mouse_y]
function stra_step(_T, _mx = undefined, _my = undefined) {
    if (!stra__is_scene(_T) || _T.closed) return;
    _T.frame++;
    var _in = { dx: 0, dy: 0, strike: false, col: -1, row: -1, tool: "", leave: false, ok: false, hover: -1 };
    var _j = _T.inject; _T.inject = undefined;
    if (is_struct(_j)) {
        _in.dx = is_numeric(_j[$ "dx"]) ? sign(_j.dx) : 0; _in.dy = is_numeric(_j[$ "dy"]) ? sign(_j.dy) : 0;
        _in.strike = _j[$ "strike"] == true; _in.leave = _j[$ "leave"] == true; _in.ok = _j[$ "ok"] == true;
        _in.tool = is_string(_j[$ "tool"]) ? _j.tool : "";
        if (is_numeric(_j[$ "col"]) && is_numeric(_j[$ "row"])) { _in.col = floor(_j.col); _in.row = floor(_j.row); }
    } else {
        var _l = stra__repeat(_T, "l", keyboard_check(vk_left)), _rt = stra__repeat(_T, "r", keyboard_check(vk_right));
        var _u = stra__repeat(_T, "u", keyboard_check(vk_up)), _d = stra__repeat(_T, "d", keyboard_check(vk_down));
        _in.dx = _l ? -1 : (_rt ? 1 : 0); _in.dy = _u ? -1 : (_d ? 1 : 0);
        _in.strike = keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("Z"));
        _in.ok = _in.strike;
        if (keyboard_check_pressed(ord("Q")) || keyboard_check_pressed(ord("W")) || keyboard_check_pressed(vk_tab) || keyboard_check_pressed(vk_shift)) _in.tool = "switch";
        _in.leave = keyboard_check_pressed(vk_escape);
        if (is_numeric(_mx) && is_numeric(_my)) {
            var _v = _T.view, _s = (_v.s > 0) ? _v.s : 1;
            var _px = (_mx - _v.x) / _s, _py = (_my - _v.y) / _s;
            var _hc = floor((_px - STRA_FACE_X) / STRA_CELL), _hr = floor((_py - STRA_FACE_Y) / STRA_CELL);
            var _onFace = _hc >= 0 && _hr >= 0 && _hc < STRA_COLS && _hr < STRA_ROWS;
            if (_onFace) _in.hover = _hr * STRA_COLS + _hc;
            if (mouse_check_button_pressed(mb_left)) {
                if (_onFace) { _in.strike = true; _in.col = _hc; _in.row = _hr; }
                else if (point_distance(_px, _py, 184, 586) <= 28) _in.tool = "pick";
                else if (point_distance(_px, _py, 254, 586) <= 28) _in.tool = "hammer";
                _in.ok = true;
            }
            if (mouse_check_button_pressed(mb_right)) _in.tool = "switch";
        }
    }
    if (_T.mode == "dig") {
        if (_in.hover >= 0 && _in.hover != _T.mouseCell) { _T.cx = _in.hover mod STRA_COLS; _T.cy = _in.hover div STRA_COLS; }
        _T.mouseCell = _in.hover;
        _T.cx = clamp(_T.cx + _in.dx, 0, STRA_COLS - 1); _T.cy = clamp(_T.cy + _in.dy, 0, STRA_ROWS - 1);
        var _nt = (_in.tool == "switch") ? ((_T.tool == "pick") ? "hammer" : "pick") : _in.tool;
        if ((_nt == "pick" || _nt == "hammer") && _nt != _T.tool) { _T.tool = _nt; stra__sound(_T, "tool"); }
        if (_in.leave && _T.allowLeave) {
            var _fr = stra_freed_list(_T.site, _T.st);
            stra__end(_T, "You pack up with " + string(array_length(_fr)) + " of " + string(array_length(_T.site.finds)) + ".", "", true);
        } else if (_in.strike) {
            if (_in.col >= 0) { _T.cx = clamp(_in.col, 0, STRA_COLS - 1); _T.cy = clamp(_in.row, 0, STRA_ROWS - 1); }
            stra__strike_at(_T, _T.cx, _T.cy);
        }
    } else if (_T.mode == "done") {
        _T.wait++;
        if (_T.wait > 40 && (_in.ok || _in.leave)) _T.closed = true;
    }
    // the world: shake, dust, falling rubble, glints
    if (_T.shake > 0) _T.shake--;
    for (var _i = array_length(_T.dust) - 1; _i >= 0; _i--) { var _p = _T.dust[_i]; _p.life--; _p.x += _p.vx; _p.y += _p.vy; _p.vy += 0.18; if (_p.life <= 0) array_delete(_T.dust, _i, 1); }
    for (var _k = array_length(_T.falls) - 1; _k >= 0; _k--) { var _q = _T.falls[_k]; _q.life--; _q.vy += 0.32; _q.x += _q.vx; _q.y += _q.vy; _q.rot += _q.vr; if (_q.life <= 0 || _q.y > STRA_FACE_H + 30) array_delete(_T.falls, _k, 1); }
    for (var _g = array_length(_T.glints) - 1; _g >= 0; _g--) { _T.glints[_g].age++; if (_T.glints[_g].age > 60) array_delete(_T.glints, _g, 1); }
    stra__refresh(_T);
}

/// @function stra_draw(scene, x, y, scale)
/// @description Draw the scene with its top-left at (x, y), 816 x 624 times scale: the cave and frame, the bed with the
/// finds, the face as it stands, the mark and the tool's reach, dust, rubble, glints, the panels, and the results card.
/// Only blits what stra_step baked (a surface lost since is rebuilt here, once).
/// @param {Struct} scene
/// @param {Real} x
/// @param {Real} y
/// @param {Real} scale
function stra_draw(_T, _x, _y, _s) {
    if (!stra__is_scene(_T)) return;
    _x = stra__fin(_x, 0); _y = stra__fin(_y, 0); _s = stra__fin(_s, 1); if (!(_s > 0)) _s = 1;
    _T.view = { x: _x, y: _y, s: _s };
    if (!surface_exists(_T.faceSurf) || !surface_exists(_T.hudSurf) || (_T.mode == "done" && is_struct(_T.result) && !surface_exists(_T.cardSurf))) stra__refresh(_T);
    var _k = _s / _T.ss, _sh = (_T.shake > 0) ? (((_T.shake & 1) ? 2 : -2) * (_T.shake / 8)) : 0;
    var _fx = _x + (STRA_FACE_X + _sh) * _s, _fy = _y + STRA_FACE_Y * _s;
    gpu_push_state(); gpu_set_texfilter(true);
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);   // everything baked here is premultiplied
    draw_sprite_ext(_T.bgSpr, 0, _x, _y, _k, _k, 0, c_white, 1);
    draw_sprite_ext(_T.underSpr, 0, _fx, _fy, _k, _k, 0, c_white, 1);
    // glints: a band of light sweeps across a find as it comes free, and its footprint is ringed in gold
    gpu_set_blendmode(bm_add);
    for (var _g = 0; _g < array_length(_T.glints); _g++) {
        var _G = _T.glints[_g], _F = _T.site.finds[_G.find], _a = clamp(1 - _G.age / 60, 0, 1);
        var _bx = _fx + _F.x * STRA_CELL * _s, _by = _fy + _F.y * STRA_CELL * _s, _bw = _F.w * STRA_CELL * _s, _bh = _F.h * STRA_CELL * _s;
        var _p = _G.age / 36, _sx = _bx - _bh + (_bw + _bh * 2) * _p;
        gpu_set_scissor(_bx, _by, _bw, _bh);
        draw_primitive_begin(pr_trianglestrip);
        draw_vertex_colour(_sx - 10 * _s, _by + _bh, c_white, 0); draw_vertex_colour(_sx + _bh - 10 * _s, _by, c_white, 0);
        draw_vertex_colour(_sx, _by + _bh, make_colour_rgb(255, 236, 190), 0.55 * _a); draw_vertex_colour(_sx + _bh, _by, make_colour_rgb(255, 236, 190), 0.55 * _a);
        draw_vertex_colour(_sx + 10 * _s, _by + _bh, c_white, 0); draw_vertex_colour(_sx + _bh + 10 * _s, _by, c_white, 0);
        draw_primitive_end();
        gpu_set_scissor(0, 0, display_get_gui_width() * 4, display_get_gui_height() * 4);
        draw_set_alpha(0.7 * _a); draw_set_colour(make_colour_rgb(232, 199, 126));
        for (var _cc = 0; _cc < array_length(_F.cells); _cc++) {
            var _cx = _F.cells[_cc] mod STRA_COLS, _cy = _F.cells[_cc] div STRA_COLS;
            draw_rectangle(_fx + _cx * STRA_CELL * _s, _fy + _cy * STRA_CELL * _s, _fx + (_cx + 1) * STRA_CELL * _s - 1, _fy + (_cy + 1) * STRA_CELL * _s - 1, true);
        }
    }
    draw_set_alpha(1);
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    draw_surface_ext(_T.faceSurf, _fx, _fy, _k, _k, 0, c_white, 1);
    // the mark: the struck cell outlined, the tool's reach dashed
    if (_T.mode == "dig") {
        var _pa = 0.75 + 0.24 * sin(_T.frame * 0.15), _C = STRA_CELL * _s, _mx = _fx + _T.cx * _C, _my = _fy + _T.cy * _C;
        // separate alpha: the normal blend LOWERS the alpha of what a translucent mark lands on, which holed the scene in a
        // buyer's surface along every line of the mark (measured: 608 translucent px, 2026-10-20)
        gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
        draw_set_colour(make_colour_rgb(255, 231, 168)); draw_set_alpha(_pa);
        for (var _w = 0; _w < 2; _w++) draw_rectangle(_mx + 1 + _w, _my + 1 + _w, _mx + _C - 2 - _w, _my + _C - 2 - _w, true);
        draw_set_alpha(0.55 * _pa);
        var _reach = (_T.tool == "hammer") ? [[-1, -1], [0, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [0, 1], [1, 1]] : [[0, -1], [-1, 0], [1, 0], [0, 1]];
        for (var _q = 0; _q < array_length(_reach); _q++) {
            var _rx = _T.cx + _reach[_q][0], _ry = _T.cy + _reach[_q][1];
            if (_rx < 0 || _ry < 0 || _rx >= STRA_COLS || _ry >= STRA_ROWS) continue;
            var _x0 = _fx + _rx * _C + 3 * _s, _y0 = _fy + _ry * _C + 3 * _s, _x1 = _fx + (_rx + 1) * _C - 3 * _s, _y1 = _fy + (_ry + 1) * _C - 3 * _s;
            for (var _dd = 0; _dd < 1; _dd += 0.25) {
                draw_line(_x0 + (_x1 - _x0) * _dd, _y0, _x0 + (_x1 - _x0) * (_dd + 0.14), _y0); draw_line(_x0 + (_x1 - _x0) * _dd, _y1, _x0 + (_x1 - _x0) * (_dd + 0.14), _y1);
                draw_line(_x0, _y0 + (_y1 - _y0) * _dd, _x0, _y0 + (_y1 - _y0) * (_dd + 0.14)); draw_line(_x1, _y0 + (_y1 - _y0) * _dd, _x1, _y0 + (_y1 - _y0) * (_dd + 0.14));
            }
        }
        draw_set_alpha(1);
        gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    }
    // dust (in the rock's own pale colour, fine grains, not bubbles) and falling rubble
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    draw_set_colour(_T.dustCol);
    for (var _i = 0; _i < array_length(_T.dust); _i++) {
        var _p = _T.dust[_i], _dr = max(0.8, _p.s * 0.9 * _s);
        draw_set_alpha(min(1, _p.life / 18) * 0.8);
        draw_rectangle(_fx + _p.x * _s - _dr, _fy + _p.y * _s - _dr, _fx + _p.x * _s + _dr, _fy + _p.y * _s + _dr, false);
    }
    draw_set_alpha(1);
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    gpu_set_scissor(_fx, _fy, STRA_FACE_W * _s, STRA_FACE_H * _s);
    for (var _f = 0; _f < array_length(_T.falls); _f++) {
        var _r = _T.falls[_f]; if (_r.y < -24) continue;
        var _spr = _T.chunkSpr[_r.k];
        if (sprite_exists(_spr)) draw_sprite_ext(_spr, 0, _fx + (_r.x - 11) * _s, _fy + (_r.y - 11) * _s, _k, _k, _r.rot, c_white, 1);
    }
    gpu_set_scissor(0, 0, display_get_gui_width() * 4, display_get_gui_height() * 4);
    draw_surface_ext(_T.hudSurf, _x, _y, _k, _k, 0, c_white, 1);
    if (_T.mode == "done" && surface_exists(_T.cardSurf) && _T.wait > 20 && array_length(_T.falls) == 0) {
        var _ca = clamp((_T.wait - 20) / 12, 0, 1), _ck = make_colour_rgb(255 * _ca, 255 * _ca, 255 * _ca);
        draw_surface_ext(_T.cardSurf, _x + (STRA_SCENE_W / 2 - 197) * _s, _y + (STRA_FACE_Y + STRA_FACE_H / 2 - 100) * _s, _k, _k, 0, _ck, _ca);
    }
    gpu_pop_state();
    draw_set_alpha(1); draw_set_colour(c_white);
}

/// @function stra_closed(scene)
/// @description True once the player has left: read stra_result then and stra_free the scene. Not a scene -> true.
/// @returns {Bool}
function stra_closed(_T) { return !stra__is_scene(_T) || _T.closed; }

/// @function stra_result(scene)
/// @description What the dig came to, once it is over (undefined while digging): { found, total, freed: the indices of
/// the finds freed (into your request's `finds` list, so you know which of YOUR items to give), families, names (your
/// names for them), cleared (every find freed), collapsed, left (packed up with Escape), worked, blows, stress,
/// stability, seed, grade, rock }.
/// @param {Struct} scene
/// @returns {Struct|Undefined}
function stra_result(_T) { return (is_struct(_T) && is_struct(_T[$ "result"])) ? _T.result : undefined; }

/// @function stra_free(scene)
/// @description Free everything the scene made (its sprites and surfaces). Safe to call twice; the scene is unusable
/// afterwards (stra_result still answers).
function stra_free(_T) {
    if (!is_struct(_T)) return;
    var _surfs = ["faceSurf", "hudSurf", "cardSurf"], _sprs = ["bgSpr", "underSpr", "grainSpr", "rockSpr", "rubbleSpr"];
    for (var _i = 0; _i < array_length(_surfs); _i++) { var _sf = _T[$ _surfs[_i]]; if (is_numeric(_sf) && _sf >= 0 && surface_exists(_sf)) surface_free(_sf); _T[$ _surfs[_i]] = -1; }
    for (var _i2 = 0; _i2 < array_length(_sprs); _i2++) _T[$ _sprs[_i2]] = stra__kill(_T[$ _sprs[_i2]]);
    var _arrs = ["layerSpr", "chunkSpr", "iconSpr"];
    for (var _a = 0; _a < array_length(_arrs); _a++) { var _A = _T[$ _arrs[_a]]; if (is_array(_A)) for (var _j = 0; _j < array_length(_A); _j++) _A[_j] = stra__kill(_A[_j]); }
    _T.closed = true;
}
