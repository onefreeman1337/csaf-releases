/// stra_draw.gml - every picture Strata shows, drawn in code onto the current surface target: the eight rocks (each a
/// different STRUCTURE, not a recolour), the bed under the face, bedrock stones, the sixteen families of finds, the
/// timbered frame, the tools, the stability gauge, type and the cave behind it all. Loads no image file.
///
/// Strata - Generated Excavation Digs for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// The RPG Maker MZ edition's StrataDraw.js, ported through the canvas kit (stra_canvas) for the finds, stones, frame,
/// tools and type; the face itself is drawn natively from pre-baked layer sheets (stra_scene), because the MZ edition
/// redraws the whole face per blow and a per-cell canvas port costs a visible hitch on the VM. Named additions over the
/// MZ edition: six families (fern, fish, point, coin, skull, sherd), three rocks (chalk, ironstone, permafrost), a
/// structure per rock (cross-bedding, laminae, fossil hash, mottles, columnar joints, flint bands, concretions, ice
/// lenses), and a crack network ON the face that spreads with the stress (stra_crack_net).
/// Public functions (each documented below): stra_rock_names, stra_rock_title, stra_draw_find, stra_find_sprite,
/// stra_draw_bedrock, stra_draw_under, stra_draw_frame, stra_draw_tool, stra_draw_gauge, stra_draw_backdrop,
/// stra_crack_net.

#macro STRA_TAU (pi * 2)
#macro STRA_CELL 40
#macro STRA_FACE_DISPLAY_PX 30

// ---------------------------------------------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------------------------------------------

/// @function stra__is_ctx(ctx)
/// @description Internal. True for a drawing context made by stra_cx_create.
function stra__is_ctx(_c) { return is_struct(_c) && is_array(_c[$ "m"]) && is_array(_c[$ "clips"]) && is_array(_c[$ "stack"]); }

/// @function stra__fin(v, fallback)
/// @description Internal. v when it is a finite number, else the fallback.
function stra__fin(_v, _d) { return (is_numeric(_v) && !is_nan(_v) && !is_infinity(_v)) ? _v : _d; }

/// @function stra__blend_begin()
/// @description Internal. Push the GPU state and blend ALPHA as "over" (colour as usual), so a translucent mark never
/// lowers the alpha of a surface it lands on (Doctrine_Craft s13/s15). Pair with stra__blend_end.
function stra__blend_begin() { gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha); }
/// @function stra__blend_end()
/// @description Internal. Restore the GPU state stra__blend_begin saved.
function stra__blend_end() { gpu_pop_state(); }

/// @function stra__shade(rgb, k)
/// @description Internal. The MZ shade(): k > 0 moves toward white by k, k < 0 toward black by -k. Returns [r, g, b].
function stra__shade(_c, _k) {
    var _o = [0, 0, 0];
    for (var _i = 0; _i < 3; _i++) { var _v = _c[_i]; _o[_i] = clamp(floor(((_k >= 0) ? _v + (255 - _v) * _k : _v * (1 + _k)) + 0.5), 0, 255); }
    return _o;
}

/// @function stra__mix(a, b, t)
/// @description Internal. a toward b by t, per channel. Returns [r, g, b].
function stra__mix(_a, _b, _t) { return [_a[0] + (_b[0] - _a[0]) * _t, _a[1] + (_b[1] - _a[1]) * _t, _a[2] + (_b[2] - _a[2]) * _t]; }

/// @function stra__pickc(gen, list)
/// @description Internal. One entry of a list by a draw (the MZ [ ... ][Math.floor(r() * n)]).
function stra__pickc(_r, _l) { var _u = stra_rand(_r); return _l[min(array_length(_l) - 1, floor(_u * array_length(_l)))]; }

/// @function stra__text(ctx, text, x, y, px, rgb, alpha, align, face)
/// @description Internal. One line of type with its MIDDLE on y (the canvas textBaseline "middle"), left-aligned at x,
/// centred on it ("center") or right-aligned to it ("right"). Returns the width.
function stra__text(_c, _s, _x, _y, _px, _rgb, _a, _align, _face) {
    var _t = string(_s), _adv = stra_text_advance(_face), _w = 0, _i, _o;
    for (_i = 1; _i <= string_length(_t); _i++) { _o = ord(string_char_at(_t, _i)); if (_o >= 32 && _o <= 126) _w += _adv[_o - 32] * _px; }
    var _pen = (_align == "center") ? _x - _w / 2 : ((_align == "right") ? _x - _w : _x), _base = _y + _px * 0.35;
    _c.fill = stra_cx_solid(_rgb, _a);
    for (_i = 1; _i <= string_length(_t); _i++) {
        var _ch = string_char_at(_t, _i); _o = ord(_ch);
        stra_cx_glyph(_c, _ch, _pen, _base, _px, _face);
        if (_o >= 32 && _o <= 126) _pen += _adv[_o - 32] * _px;
    }
    return _w;
}

/// @function stra__text_fit(ctx, text, x, y, px, rgb, alpha, align, face, maxw)
/// @description Internal. stra__text, its size reduced until the line fits maxw (a caption that can overflow will).
function stra__text_fit(_c, _s, _x, _y, _px, _rgb, _a, _align, _face, _maxw) {
    var _w = stra_text_width(_s, _px, _face);
    if (_w > _maxw && _w > 0) _px = max(8, _px * _maxw / _w);
    return stra__text(_c, _s, _x, _y, _px, _rgb, _a, _align, _face);
}

/// @function stra__rrect(ctx, x, y, w, h, r)
/// @description Internal. A rounded-rectangle path (quadratic corners).
function stra__rrect(_c, _x, _y, _w, _h, _r) {
    stra_cx_begin(_c); stra_cx_move(_c, _x + _r, _y); stra_cx_line(_c, _x + _w - _r, _y); stra_cx_quad(_c, _x + _w, _y, _x + _w, _y + _r);
    stra_cx_line(_c, _x + _w, _y + _h - _r); stra_cx_quad(_c, _x + _w, _y + _h, _x + _w - _r, _y + _h); stra_cx_line(_c, _x + _r, _y + _h);
    stra_cx_quad(_c, _x, _y + _h, _x, _y + _h - _r); stra_cx_line(_c, _x, _y + _r); stra_cx_quad(_c, _x, _y, _x + _r, _y); stra_cx_close(_c);
}

/// @function stra__disc(ctx, x, y, r, rgb, a)
/// @description Internal. A filled disc.
function stra__disc(_c, _x, _y, _r, _rgb, _a) { _c.fill = stra_cx_solid(_rgb, _a); stra_cx_begin(_c); stra_cx_arc(_c, _x, _y, max(0.1, _r), 0, STRA_TAU); stra_cx_fill(_c); }

/// @function stra__oval(ctx, x, y, rx, ry, rot, rgb, a)
/// @description Internal. A filled ellipse.
function stra__oval(_c, _x, _y, _rx, _ry, _rot, _rgb, _a) { _c.fill = stra_cx_solid(_rgb, _a); stra_cx_begin(_c); stra_cx_ellipse(_c, _x, _y, max(0.1, _rx), max(0.1, _ry), _rot, 0, STRA_TAU); stra_cx_fill(_c); }

/// @function stra__soft(ctx, x, y, rx, ry)
/// @description Internal. The MZ soft(): a find's contact shadow, offset down-right.
function stra__soft(_c, _x, _y, _rx, _ry) { stra__oval(_c, _x + 3, _y + 4, _rx, _ry, 0, [0, 0, 0], 0.35); }

/// @function stra__poly(ctx, pts, closed)
/// @description Internal. A path through [[x, y], ...].
function stra__poly(_c, _p, _closed = true) {
    stra_cx_begin(_c);
    for (var _i = 0; _i < array_length(_p); _i++) { if (_i == 0) stra_cx_move(_c, _p[_i][0], _p[_i][1]); else stra_cx_line(_c, _p[_i][0], _p[_i][1]); }
    if (_closed) stra_cx_close(_c);
}

/// @function stra__line(ctx, x0, y0, x1, y1, rgb, a, w)
/// @description Internal. One stroked segment.
function stra__line(_c, _x0, _y0, _x1, _y1, _rgb, _a, _w) { _c.stroke = stra_cx_solid(_rgb, _a); _c.lw = _w; stra_cx_begin(_c); stra_cx_move(_c, _x0, _y0); stra_cx_line(_c, _x1, _y1); stra_cx_stroke(_c); }

// ---------------------------------------------------------------------------------------------------------------
// The rocks
// ---------------------------------------------------------------------------------------------------------------

/// @function stra__rock(name)
/// @description Internal. A rock's palette and structure: six layers (outer first), a fleck, the bed colour, a title, the
/// structure kind. The MZ five keep the MZ colours; sandstone for anything unknown.
function stra__rock(_n) {
    static R = {
        sandstone: { layers: [[217, 168, 108], [201, 143, 85], [182, 121, 69], [161, 102, 58], [138, 84, 49], [115, 68, 40]], fleck: [243, 215, 168], under: [42, 26, 16], title: "The Sandstone Cut", kind: "crossbed" },
        shale: { layers: [[141, 150, 161], [122, 131, 144], [104, 113, 127], [88, 96, 110], [72, 80, 94], [58, 65, 78]], fleck: [196, 204, 214], under: [21, 24, 29], title: "The Shale Bed", kind: "laminae" },
        limestone: { layers: [[227, 220, 200], [212, 204, 181], [195, 186, 161], [176, 167, 140], [156, 147, 120], [135, 127, 102]], fleck: [251, 247, 234], under: [35, 31, 22], title: "The Limestone Quarry", kind: "hash" },
        clay: { layers: [[184, 106, 75], [165, 91, 63], [146, 78, 53], [126, 66, 45], [107, 55, 38], [88, 45, 32]], fleck: [227, 164, 136], under: [30, 15, 10], title: "The Clay Bank", kind: "mottle" },
        basalt: { layers: [[93, 90, 96], [79, 76, 83], [67, 64, 71], [56, 53, 60], [46, 44, 50], [37, 35, 41]], fleck: [155, 151, 163], under: [12, 11, 14], title: "The Basalt Seam", kind: "columns" },
        chalk: { layers: [[238, 234, 222], [228, 223, 208], [216, 210, 192], [203, 196, 176], [189, 181, 160], [172, 164, 143]], fleck: [255, 255, 250], under: [40, 38, 33], title: "The Chalk Cliff", kind: "flint" },
        ironstone: { layers: [[176, 104, 58], [158, 88, 48], [139, 74, 41], [120, 62, 36], [100, 52, 32], [82, 43, 28]], fleck: [222, 160, 92], under: [26, 14, 9], title: "The Ironstone Drift", kind: "concretion" },
        permafrost: { layers: [[196, 214, 222], [168, 190, 202], [142, 165, 180], [120, 142, 160], [98, 120, 140], [80, 100, 122]], fleck: [240, 250, 255], under: [16, 22, 30], title: "The Permafrost Wall", kind: "ice" }
    };
    return (is_string(_n) && variable_struct_exists(R, _n)) ? R[$ _n] : R.sandstone;
}

/// @function stra_rock_names()
/// @description The eight rocks in order (the same list as stra_sites). Pure.
/// @returns {Array<String>}
function stra_rock_names() { return stra_sites(); }

/// @function stra_rock_title(rock)
/// @description A dig's default heading for a rock ("The Limestone Quarry"). Unknown -> the sandstone title. Pure.
/// @param {String} rock
/// @returns {String}
function stra_rock_title(_n) { return stra__rock(_n).title; }

/// @function stra__layer_rgb(rock, layer)
/// @description Internal. Layer L's colour (0 = the outer face), clamped to the six.
function stra__layer_rgb(_n, _L) { var _P = stra__rock(_n); return _P.layers[clamp(floor(_L), 0, 5)]; }

/// @function stra__col(rgb)
/// @description Internal. [r, g, b] as a GameMaker colour.
function stra__col(_c) { return make_colour_rgb(clamp(_c[0], 0, 255), clamp(_c[1], 0, 255), clamp(_c[2], 0, 255)); }

/// @function stra__quad_native(x0, y0, x1, y1, x2, y2, x3, y3, col, a)
/// @description Internal. A flat quad (two triangles) straight onto the target, no antialiasing (the face sheets are
/// axis-filling bands and grain, drawn once per dig).
function stra__quad_native(_x0, _y0, _x1, _y1, _x2, _y2, _x3, _y3, _col, _a) {
    draw_primitive_begin(pr_trianglelist);
    draw_vertex_colour(_x0, _y0, _col, _a); draw_vertex_colour(_x1, _y1, _col, _a); draw_vertex_colour(_x2, _y2, _col, _a);
    draw_vertex_colour(_x0, _y0, _col, _a); draw_vertex_colour(_x2, _y2, _col, _a); draw_vertex_colour(_x3, _y3, _col, _a);
    draw_primitive_end();
}

/// @function stra__layer_sheet(rock, seed, L, w, h, k)
/// @description Internal. Draw layer L of a rock's face, w x h face units at scale k, onto the current target: the layer's
/// own colour with bedding bands running across the whole face at the site's tilt (the MZ drawFace bands), then the
/// rock's STRUCTURE for that layer. Called once per layer per dig.
function stra__layer_sheet(_rock, _seed, _L, _w, _h, _k) {
    var _P = stra__rock(_rock), _base = _P.layers[clamp(_L, 0, 5)];
    var _t0 = stra_rng(_seed); var _ut = stra_rand(_t0); var _tilt = (_ut - 0.5) * 0.35;
    draw_clear_alpha(stra__col(_base), 1);
    var _rb = stra_rng(real((stra__u32(_seed) ^ stra__u32(_L * 7717)) & int64($FFFFFFFF)));
    var _W = _w * _k, _H = _h * _k, _kind = _P.kind;
    // bedding bands: the MZ count, spacing and shade spread; laminae (shale) run thin and many, chalk and limestone thick
    var _pitch = (_kind == "laminae") ? 13 : ((_kind == "hash" || _kind == "flint") ? 46 : 34);
    var _hmin = (_kind == "laminae") ? 3 : 12, _hvar = (_kind == "laminae") ? 7 : 22, _spread = (_kind == "laminae") ? 0.2 : 0.14;
    for (var _sb = -3; _sb * _pitch < _h + 40; _sb++) {
        var _u0 = stra_rand(_rb); var _u1 = stra_rand(_rb); var _u2 = stra_rand(_rb);
        var _y0 = _sb * _pitch + _u0 * 10, _hg = _hmin + _u1 * _hvar;
        var _col = stra__col(stra__shade(_base, (_u2 - 0.5) * _spread));
        stra__quad_native(0, _y0 * _k, _W, (_y0 + _tilt * _w) * _k, _W, (_y0 + _hg + _tilt * _w) * _k, 0, (_y0 + _hg) * _k, _col, 1);
        if (_kind == "crossbed" && _u2 < 0.55) {
            // cross-bedding: thin foresets running diagonally inside the band
            var _fc = stra__col(stra__shade(_base, -0.08)), _ang = 0.55 + _u1 * 0.3;
            for (var _fx = -40; _fx < _w + 40; _fx += 9) {
                var _x0 = _fx, _x1 = _fx + _hg / _ang;
                stra__quad_native(_x0 * _k, (_y0 + _tilt * _x0) * _k, (_x0 + 1.2) * _k, (_y0 + _tilt * _x0) * _k, (_x1 + 1.2) * _k, (_y0 + _hg + _tilt * _x1) * _k, _x1 * _k, (_y0 + _hg + _tilt * _x1) * _k, _fc, 0.45);
            }
        }
    }
    var _g = stra_rng(real((stra__u32(_seed) ^ stra__u32(4049 + _L * 131)) & int64($FFFFFFFF)));
    if (_kind == "mottle") {
        // clay: soft oxidised mottles and pale reduction spots
        repeat (34) {
            var _mx = stra_rand(_g) * _w; var _my = stra_rand(_g) * _h; var _mr = 6 + stra_rand(_g) * 16; var _mt = stra_rand(_g);
            var _mc = stra__col((_mt < 0.6) ? stra__shade(_base, -0.12) : stra__mix(_base, [196, 170, 150], 0.35));
            draw_set_colour(_mc);
            for (var _ring = 3; _ring >= 1; _ring--) { draw_set_alpha(0.12); draw_ellipse((_mx - _mr * _ring / 3) * _k, (_my - _mr * 0.7 * _ring / 3) * _k, (_mx + _mr * _ring / 3) * _k, (_my + _mr * 0.7 * _ring / 3) * _k, false); }
        }
        draw_set_alpha(1);
    } else if (_kind == "hash") {
        // limestone: a fossil hash - shell fragments and crinoid discs scattered through the bed
        var _hc = stra__col(stra__shade(_base, 0.28)), _hd = stra__col(stra__shade(_base, -0.2));
        repeat (90) {
            var _hx = stra_rand(_g) * _w; var _hy = stra_rand(_g) * _h; var _hs = 1.5 + stra_rand(_g) * 3; var _ha = stra_rand(_g) * pi;
            draw_set_alpha(0.55); draw_set_colour(_hd); draw_circle(_hx * _k, (_hy + 0.6) * _k, _hs * _k, true);
            draw_set_colour(_hc); draw_line_width(( _hx - cos(_ha) * _hs) * _k, (_hy - sin(_ha) * _hs) * _k, (_hx + cos(_ha) * _hs) * _k, (_hy + sin(_ha) * _hs) * _k, max(1, _k));
        }
        draw_set_alpha(1);
    } else if (_kind == "ice") {
        // permafrost: frozen silt bands with clear ice lenses
        repeat (16) {
            var _ix = stra_rand(_g) * _w; var _iy = stra_rand(_g) * _h; var _iw = 18 + stra_rand(_g) * 40; var _ih = 3 + stra_rand(_g) * 5;
            draw_set_alpha(0.55); draw_set_colour(make_colour_rgb(222, 242, 252));
            draw_ellipse((_ix - _iw / 2) * _k, (_iy + _tilt * _ix - _ih / 2) * _k, (_ix + _iw / 2) * _k, (_iy + _tilt * _ix + _ih / 2) * _k, false);
            draw_set_alpha(0.7); draw_set_colour(c_white);
            draw_line_width((_ix - _iw * 0.3) * _k, (_iy + _tilt * _ix - _ih * 0.2) * _k, (_ix + _iw * 0.1) * _k, (_iy + _tilt * _ix - _ih * 0.25) * _k, max(1, _k));
        }
        draw_set_alpha(1);
    }
}

/// @function stra__grain_sheet(rock, seed, w, h, k)
/// @description Internal. The grain over the WHOLE face (transparent elsewhere), in face coordinates so it runs across
/// cells: the MZ flecks and bedding planes, then the rock's own marks (vesicles and joints in basalt, flint nodules in
/// chalk, concretions in ironstone, frost in permafrost, rootlets in clay, partings in shale). Drawn once per dig and
/// shown only where rock still stands.
function stra__grain_sheet(_rock, _seed, _w, _h, _k) {
    var _P = stra__rock(_rock), _kind = _P.kind;
    var _r = stra_rng(real((stra__u32(_seed) ^ int64($3131)) & int64($FFFFFFFF)));
    var _t0 = stra_rng(_seed); var _ut = stra_rand(_t0); var _tilt = (_ut - 0.5) * 0.35;
    var _fl = stra__col(_P.fleck);
    for (var _i = 0; _i < 1400; _i++) {
        var _u0 = stra_rand(_r); var _u1 = stra_rand(_r); var _u2 = stra_rand(_r); var _u3 = stra_rand(_r); var _u4 = stra_rand(_r); var _u5 = stra_rand(_r);
        draw_set_colour((_u0 < 0.55) ? _fl : c_black);
        draw_set_alpha((0.1 + _u1 * 0.22) * ((_u0 < 0.55) ? 1 : 0.9));
        var _fx = _u2 * _w, _fy = _u3 * _h;
        draw_rectangle(_fx * _k, _fy * _k, (_fx + 1 + _u4 * 2.2) * _k - 1, (_fy + 1 + _u5 * 1.4) * _k - 1, false);
    }
    // bedding planes: long faint lines across the whole face (the MZ nine)
    draw_set_alpha(0.22); draw_set_colour(stra__col(stra__shade(_P.layers[3], -0.3)));
    for (var _b = 0; _b < 9; _b++) {
        var _by = (_b + 0.5) * _h / 9, _px = 0, _py = _by;
        for (var _bx = 26; _bx <= _w + 26; _bx += 26) { var _uj = stra_rand(_r); var _ny = _by + _tilt * _bx + (_uj - 0.5) * 3; draw_line_width(_px * _k, _py * _k, _bx * _k, _ny * _k, max(1, _k)); _px = _bx; _py = _ny; }
    }
    var _g = stra_rng(real((stra__u32(_seed) ^ int64($7A11)) & int64($FFFFFFFF)));
    if (_kind == "columns") {
        // basalt: columnar joints (a polygon network of dark cracks) and gas vesicles
        draw_set_colour(make_colour_rgb(12, 11, 16));
        for (var _cy = 0; _cy < _h + 30; _cy += 30) for (var _cx = 0; _cx < _w + 30; _cx += 26) {
            var _ox = _cx + ((_cy / 30) mod 2) * 13;
            var _a0 = stra_rand(_g) * 0.6;
            var _pts = [];
            for (var _q = 0; _q < 6; _q++) { var _uq = stra_rand(_g); var _ang = _a0 + _q * pi / 3; array_push(_pts, [_ox + cos(_ang) * (14 + _uq * 3), _cy + sin(_ang) * (14 + _uq * 3)]); }
            draw_set_alpha(0.32);
            for (var _q2 = 0; _q2 < 6; _q2++) { var _p0 = _pts[_q2], _p1 = _pts[(_q2 + 1) mod 6]; draw_line_width(_p0[0] * _k, _p0[1] * _k, _p1[0] * _k, _p1[1] * _k, max(1, 1.1 * _k)); }
        }
        repeat (70) {
            var _vx = stra_rand(_g) * _w; var _vy = stra_rand(_g) * _h; var _vr = 1 + stra_rand(_g) * 2.6;
            draw_set_alpha(0.75); draw_set_colour(make_colour_rgb(14, 13, 18)); draw_ellipse((_vx - _vr) * _k, (_vy - _vr * 0.8) * _k, (_vx + _vr) * _k, (_vy + _vr * 0.8) * _k, false);
            draw_set_alpha(0.35); draw_set_colour(_fl); draw_line_width((_vx - _vr * 0.6) * _k, (_vy + _vr * 0.7) * _k, (_vx + _vr * 0.6) * _k, (_vy + _vr * 0.7) * _k, max(1, _k * 0.8));
        }
    } else if (_kind == "flint") {
        // chalk: rows of black flint nodules along the bedding, each with a pale cortex
        for (var _row = 0; _row < 4; _row++) {
            var _ry = 50 + _row * 95 + stra_rand(_g) * 20;
            var _nx = stra_rand(_g) * 30;
            while (_nx < _w) {
                var _nw = 10 + stra_rand(_g) * 18; var _nh = 6 + stra_rand(_g) * 7; var _ny2 = _ry + _tilt * _nx + (stra_rand(_g) - 0.5) * 8;
                draw_set_alpha(0.9); draw_set_colour(make_colour_rgb(236, 232, 220)); draw_ellipse((_nx - 1.5) * _k, (_ny2 - 1.5) * _k, (_nx + _nw + 1.5) * _k, (_ny2 + _nh + 1.5) * _k, false);
                draw_set_colour(make_colour_rgb(40, 40, 46)); draw_ellipse(_nx * _k, _ny2 * _k, (_nx + _nw) * _k, (_ny2 + _nh) * _k, false);
                draw_set_alpha(0.45); draw_set_colour(make_colour_rgb(150, 150, 166)); draw_line_width((_nx + _nw * 0.25) * _k, (_ny2 + _nh * 0.3) * _k, (_nx + _nw * 0.6) * _k, (_ny2 + _nh * 0.25) * _k, max(1, _k));
                _nx += _nw + 14 + stra_rand(_g) * 44;
            }
        }
    } else if (_kind == "concretion") {
        // ironstone: rusty concretions (rings of oxide) and streaks of limonite down the face
        repeat (14) {
            var _kx = stra_rand(_g) * _w; var _ky = stra_rand(_g) * _h; var _kr = 5 + stra_rand(_g) * 9;
            for (var _ri = 0; _ri < 4; _ri++) { draw_set_alpha(0.28); draw_set_colour((_ri mod 2 == 0) ? make_colour_rgb(110, 46, 18) : make_colour_rgb(214, 140, 64)); draw_circle(_kx * _k, _ky * _k, (_kr - _ri * _kr / 4.2) * _k, true); }
        }
        repeat (22) {
            var _sx = stra_rand(_g) * _w; var _sy = stra_rand(_g) * _h; var _sl = 14 + stra_rand(_g) * 40;
            draw_set_alpha(0.18); draw_set_colour(make_colour_rgb(232, 158, 70)); draw_line_width(_sx * _k, _sy * _k, (_sx + (stra_rand(_g) - 0.5) * 4) * _k, (_sy + _sl) * _k, max(1, 1.6 * _k));
        }
    } else if (_kind == "ice") {
        // permafrost: hoarfrost - small six-armed stars on the face
        repeat (60) {
            var _ix = stra_rand(_g) * _w; var _iy = stra_rand(_g) * _h; var _is = 1.5 + stra_rand(_g) * 2.5; var _ia = stra_rand(_g);
            draw_set_alpha(0.55); draw_set_colour(c_white);
            for (var _a = 0; _a < 3; _a++) { var _an = _ia + _a * pi / 3; draw_line_width((_ix - cos(_an) * _is) * _k, (_iy - sin(_an) * _is) * _k, (_ix + cos(_an) * _is) * _k, (_iy + sin(_an) * _is) * _k, max(1, 0.8 * _k)); }
        }
    } else if (_kind == "mottle") {
        // clay: rootlet traces - fine branching dark lines
        repeat (18) {
            var _lx = stra_rand(_g) * _w; var _ly = stra_rand(_g) * _h * 0.6; var _la = pi / 2 + (stra_rand(_g) - 0.5) * 0.8;
            draw_set_colour(make_colour_rgb(60, 26, 16));
            for (var _s = 0; _s < 7; _s++) {
                var _nl = 4 + stra_rand(_g) * 6; var _nxx = _lx + cos(_la) * _nl; var _nyy = _ly + sin(_la) * _nl;
                draw_set_alpha(0.32 - _s * 0.03); draw_line_width(_lx * _k, _ly * _k, _nxx * _k, _nyy * _k, max(1, _k * 0.9));
                _lx = _nxx; _ly = _nyy; _la += (stra_rand(_g) - 0.5) * 0.7;
            }
        }
    } else if (_kind == "laminae") {
        // shale: fissile partings - thin pale lines where the laminae split
        draw_set_colour(_fl);
        for (var _pp = 0; _pp < 26; _pp++) {
            var _py2 = stra_rand(_g) * _h; var _px0 = stra_rand(_g) * _w; var _pl = 30 + stra_rand(_g) * 90;
            draw_set_alpha(0.3); draw_line_width(_px0 * _k, (_py2 + _tilt * _px0) * _k, (_px0 + _pl) * _k, (_py2 + _tilt * (_px0 + _pl)) * _k, max(1, _k * 0.8));
        }
    } else if (_kind == "crossbed") {
        // sandstone: scattered quartz grains catching the light
        draw_set_colour(c_white);
        repeat (110) { var _qx = stra_rand(_g) * _w; var _qy = stra_rand(_g) * _h; draw_set_alpha(0.25 + stra_rand(_g) * 0.3); draw_rectangle(_qx * _k, _qy * _k, (_qx + 1) * _k, (_qy + 1) * _k, false); }
    }
    draw_set_alpha(1); draw_set_colour(c_white);
}

// ---------------------------------------------------------------------------------------------------------------
// The crack network: seeded, revealed segment by segment as the stress rises
// ---------------------------------------------------------------------------------------------------------------

/// @function stra_crack_net(seed, w, h)
/// @description The crack network a face can grow: an array of segments { x0, y0, x1, y1, w, t }, where t in (0, 1] is
/// the share of the stability at which the segment appears. Cracks start at the timbers along the top and sides,
/// wander and branch inward; the first appear at a quarter of the stability and the last at the collapse. Pure.
/// @param {Real} seed
/// @param {Real} w   face width in pixels
/// @param {Real} h   face height in pixels
/// @returns {Array<Struct>}
function stra_crack_net(_seed, _w, _h) {
    // a width or height that is not a finite number is the face's own (the adversarial pass found undefined and a string
    // reaching the arithmetic below and throwing, 2026-10-20); a size under one pixel is one pixel
    _w = max(1, stra__fin(_w, STRA_FACE_W)); _h = max(1, stra__fin(_h, STRA_FACE_H));
    var _g = stra_rng(real((stra__u32(_seed) ^ int64($C4AC)) & int64($FFFFFFFF)));
    repeat (3) stra_rand(_g);   // warm up: nearby seeds' first draws are not uniform (Doctrine_Craft s6)
    var _segs = [], _stack = [];
    var _roots = 3 + floor(stra_rand(_g) * 3);
    for (var _i = 0; _i < _roots; _i++) {
        var _side = stra_rand(_g); var _pos = stra_rand(_g);
        var _x, _y, _a;
        if (_side < 0.55) { _x = (0.1 + 0.8 * _pos) * _w; _y = 0; _a = pi / 2; }
        else if (_side < 0.78) { _x = 0; _y = (0.1 + 0.6 * _pos) * _h; _a = 0; }
        else { _x = _w; _y = (0.1 + 0.6 * _pos) * _h; _a = pi; }
        var _ua = stra_rand(_g);
        array_push(_stack, { x: _x, y: _y, a: _a + (_ua - 0.5) * 0.7, w: 2.6, n: 14 + floor(stra_rand(_g) * 10), d: 0 });
    }
    var _guard = 0;
    while (array_length(_stack) > 0 && _guard++ < 400) {
        var _b = array_pop(_stack);
        var _x2 = _b.x, _y2 = _b.y, _a2 = _b.a, _wd = _b.w;
        for (var _s = 0; _s < _b.n; _s++) {
            var _ul = stra_rand(_g); var _uw = stra_rand(_g); var _ub = stra_rand(_g);
            var _len = 7 + _ul * 9;
            _a2 += (_uw - 0.5) * 0.9;
            var _nx = _x2 + cos(_a2) * _len, _ny = _y2 + sin(_a2) * _len;
            if (_nx < -4 || _ny < -4 || _nx > _w + 4 || _ny > _h + 4) break;
            array_push(_segs, { x0: _x2, y0: _y2, x1: _nx, y1: _ny, w: _wd, d: _b.d, k: array_length(_segs) });
            _x2 = _nx; _y2 = _ny; _wd = max(0.8, _wd * 0.93);
            if (_ub < 0.16 && _b.d < 3) { var _uc = stra_rand(_g); array_push(_stack, { x: _x2, y: _y2, a: _a2 + ((_uc < 0.5) ? -1 : 1) * (0.5 + _uc * 0.6), w: _wd * 0.75, n: 5 + floor(_uc * 8), d: _b.d + 1 }); }
        }
    }
    // order of appearance: trunks before branches, then the order drawn - t from 0.25 to 1
    var _n = array_length(_segs);
    for (var _j = 0; _j < _n; _j++) _segs[_j].t = 0.25 + 0.75 * (_j + 1) / max(1, _n);
    return _segs;
}

// ---------------------------------------------------------------------------------------------------------------
// Bedrock, the bed under the face
// ---------------------------------------------------------------------------------------------------------------

/// @function stra_draw_bedrock(ctx, col, row, n)
/// @description An unbreakable bedrock stone over one cell: dark, glossy, obviously different (the MZ drawBedrock).
/// @param {Struct} ctx
/// @param {Real} col
/// @param {Real} row
/// @param {Real} n   the site's seed (each stone is shaped by its place and the seed)
function stra_draw_bedrock(_c, _col, _row, _n) {
    if (!stra__is_ctx(_c)) return;
    stra__blend_begin();
    var _C = STRA_CELL, _x = _col * _C, _y = _row * _C;
    var _r = stra_rng(real(stra__u32(_col * 911 + _row * 3571 + stra__fin(_n, 0))));
    var _pts = [];
    for (var _i = 0; _i < 9; _i++) { var _a = _i / 9 * STRA_TAU; var _u = stra_rand(_r); var _rr = _C * (0.46 + _u * 0.05); array_push(_pts, [_x + _C / 2 + cos(_a) * _rr, _y + _C / 2 + sin(_a) * _rr]); }
    var _g = stra_cx_radial(_c, _x + _C * 0.35, _y + _C * 0.3, 2, _x + _C / 2, _y + _C / 2, _C * 0.6);
    stra_cx_stop(_g, 0, [109, 106, 120]); stra_cx_stop(_g, 0.5, [46, 44, 54]); stra_cx_stop(_g, 1, [20, 19, 25]);
    _c.fill = _g; stra__poly(_c, _pts); stra_cx_fill(_c);
    _c.stroke = stra_cx_solid([8, 7, 10]); _c.lw = 1.2; stra__poly(_c, _pts); stra_cx_stroke(_c);
    _c.stroke = stra_cx_solid([200, 200, 230], 0.25); _c.lw = 1;
    stra_cx_begin(_c); stra_cx_move(_c, _x + 10, _y + 14); stra_cx_line(_c, _x + 18, _y + 22); stra_cx_line(_c, _x + 15, _y + 30); stra_cx_stroke(_c);
    stra__blend_end();
}

/// @function stra_draw_under(ctx, rock, w, h, seed)
/// @description The bed under the face: packed dark soil with pebbles, what a cleared cell shows where nothing is buried.
/// @param {Struct} ctx
/// @param {String} rock
/// @param {Real} w
/// @param {Real} h
/// @param {Real} seed
function stra_draw_under(_c, _rock, _w, _h, _seed) {
    if (!stra__is_ctx(_c)) return;
    stra__blend_begin();
    var _P = stra__rock(_rock), _r = stra_rng(real((stra__u32(_seed) ^ int64($44)) & int64($FFFFFFFF)));
    var _g = stra_cx_linear(_c, 0, 0, 0, _h); stra_cx_stop(_g, 0, stra__shade(_P.under, 0.12)); stra_cx_stop(_g, 1, _P.under);
    _c.fill = _g; stra_cx_fill_rect(_c, 0, 0, _w, _h);
    // the pebbles and grit, drawn natively under the context's transform (1 to 4 px marks: through the kit they cost ~80 ms
    // an open). Each pebble is a stone in the rock's own colour with a lit top and a shadow under it (looked at 2026-10-21:
    // faint grey dots left the bed reading as a flat dark slab at twice the size)
    var _m = _c.m, _gk = sqrt(abs(_m[0] * _m[3] - _m[1] * _m[2])), _lay = _P.layers;
    for (var _i = 0; _i < 420; _i++) {
        var _u0 = stra_rand(_r); var _u1 = stra_rand(_r); var _u2 = stra_rand(_r); var _u3 = stra_rand(_r); var _u4 = stra_rand(_r); var _u5 = stra_rand(_r);
        var _s = 0.8 + _u1 * _u1 * 4.2, _px = _u2 * _w, _py = _u3 * _h, _ry = _s * (0.6 + _u4 * 0.4);
        var _gx = _m[0] * _px + _m[2] * _py + _m[4], _gy = _m[1] * _px + _m[3] * _py + _m[5];
        if (_u0 < 0.62) {
            // grit: a dark speck
            draw_set_colour(c_black); draw_set_alpha(0.3);
            draw_ellipse(_gx - _s * 0.6 * _gk, _gy - _ry * 0.6 * _gk, _gx + _s * 0.6 * _gk, _gy + _ry * 0.6 * _gk, false);
        } else {
            // a pebble: shadow, body in a darkened layer colour, lit cap
            var _pc = stra__shade(_lay[floor(_u5 * 6)], -0.45);
            draw_set_colour(c_black); draw_set_alpha(0.45); draw_ellipse(_gx - _s * _gk + 0.6 * _gk, _gy - _ry * _gk + 0.9 * _gk, _gx + _s * _gk + 0.6 * _gk, _gy + _ry * _gk + 0.9 * _gk, false);
            draw_set_colour(stra__col(_pc)); draw_set_alpha(0.95); draw_ellipse(_gx - _s * _gk, _gy - _ry * _gk, _gx + _s * _gk, _gy + _ry * _gk, false);
            draw_set_colour(stra__col(stra__shade(_pc, 0.35))); draw_set_alpha(0.6); draw_ellipse(_gx - _s * 0.7 * _gk, _gy - _ry * 0.85 * _gk, _gx + _s * 0.2 * _gk, _gy - _ry * 0.1 * _gk, false);
        }
    }
    draw_set_alpha(1); draw_set_colour(c_white);
    stra__blend_end();
}

// ---------------------------------------------------------------------------------------------------------------
// The finds. Each draws inside its footprint box (w x h cells) in its NATURAL orientation; a rotated find is drawn in
// the swapped box and turned a quarter.
// ---------------------------------------------------------------------------------------------------------------

/// @function stra_draw_find(ctx, find)
/// @description Draw one find at the context's origin, filling its footprint (find.w x find.h cells of 40 px): the
/// family's own picture, its colourway and details from find.variant (the same variant draws the same find).
/// @param {Struct} ctx
/// @param {Struct} find   { family, rot, w, h, variant } (a find from stra_generate)
function stra_draw_find(_c, _f) {
    if (!stra__is_ctx(_c) || !is_struct(_f) || !stra__is_family(_f[$ "family"])) return;
    var _rot = (_f[$ "rot"] == true);
    var _fw = stra__fin(_f[$ "w"], 1), _fh = stra__fin(_f[$ "h"], 1);
    var _natW = (_rot ? _fh : _fw) * STRA_CELL, _natH = (_rot ? _fw : _fh) * STRA_CELL;
    var _r = stra_rng(stra__fin(_f[$ "variant"], 0));
    stra__blend_begin();
    stra_cx_save(_c);
    if (_rot) { stra_cx_translate(_c, _fw * STRA_CELL, 0); stra_cx_rotate(_c, pi / 2); }
    switch (_f.family) {
        case "ammonite": stra__f_ammonite(_c, _natW, _natH, _r); break;
        case "trilobite": stra__f_trilobite(_c, _natW, _natH, _r); break;
        case "bone": stra__f_bone(_c, _natW, _natH, _r); break;
        case "tooth": stra__f_tooth(_c, _natW, _natH, _r); break;
        case "amber": stra__f_amber(_c, _natW, _natH, _r); break;
        case "geode": stra__f_geode(_c, _natW, _natH, _r); break;
        case "ore": stra__f_ore(_c, _natW, _natH, _r); break;
        case "crystal": stra__f_crystal(_c, _natW, _natH, _r); break;
        case "tablet": stra__f_tablet(_c, _natW, _natH, _r); break;
        case "shell": stra__f_shell(_c, _natW, _natH, _r); break;
        case "fern": stra__f_fern(_c, _natW, _natH, _r); break;
        case "fish": stra__f_fish(_c, _natW, _natH, _r); break;
        case "point": stra__f_point(_c, _natW, _natH, _r); break;
        case "coin": stra__f_coin(_c, _natW, _natH, _r); break;
        case "skull": stra__f_skull(_c, _natW, _natH, _r); break;
        case "sherd": stra__f_sherd(_c, _natW, _natH, _r); break;
    }
    stra_cx_restore(_c);
    stra__blend_end();
}

/// The MZ ten, ported call for call (shapes, colourways, detail counts); the comments that follow each are the MZ
/// edition's own "found by looking" notes, kept because they are true here too.

function stra__f_ammonite(_c, _W, _H, _r) {
    var _cx = _W / 2, _cy = _H / 2, _R = min(_W, _H) * 0.46;
    var _mat = stra__pickc(_r, [[[217, 178, 94], [122, 85, 32]], [[232, 224, 204], [139, 125, 98]], [[111, 182, 166], [45, 79, 107]]]);
    stra__soft(_c, _cx, _cy, _R, _R);
    var _g = stra_cx_radial(_c, _cx - _R * 0.3, _cy - _R * 0.3, 2, _cx, _cy, _R); stra_cx_stop(_g, 0, _mat[0]); stra_cx_stop(_g, 1, _mat[1]);
    _c.fill = _g; stra_cx_begin(_c); stra_cx_arc(_c, _cx, _cy, _R, 0, STRA_TAU); stra_cx_fill(_c);
    // the coil: a logarithmic spiral traced inward, with ribs crossing each whorl
    var _k = 0.21, _turns = 3.3, _ua = stra_rand(_r); var _a0 = _ua * STRA_TAU;
    _c.stroke = stra_cx_solid([40, 25, 10], 0.65); _c.lw = 1.6;
    stra_cx_begin(_c);
    for (var _t = 0; _t <= _turns * STRA_TAU; _t += 0.05) {
        var _rr = _R * exp(-_k * _t), _px = _cx + _rr * cos(_a0 + _t), _py = _cy + _rr * sin(_a0 + _t);
        if (_t == 0) stra_cx_move(_c, _px, _py); else stra_cx_line(_c, _px, _py);
    }
    stra_cx_stroke(_c);
    _c.lw = 1; _c.stroke = stra_cx_solid([40, 25, 10], 0.4);
    for (var _t2 = 0; _t2 <= _turns * STRA_TAU; _t2 += 0.28) {
        var _r1 = _R * exp(-_k * _t2), _r2 = _R * exp(-_k * (_t2 + STRA_TAU)), _a = _a0 + _t2;
        stra_cx_begin(_c); stra_cx_move(_c, _cx + _r1 * cos(_a), _cy + _r1 * sin(_a));
        stra_cx_quad(_c, _cx + (_r1 + _r2) / 2 * cos(_a + 0.12), _cy + (_r1 + _r2) / 2 * sin(_a + 0.12), _cx + _r2 * cos(_a), _cy + _r2 * sin(_a));
        stra_cx_stroke(_c);
    }
    _c.stroke = stra_cx_solid([255, 255, 255], 0.35); _c.lw = 1.4;
    stra_cx_begin(_c); stra_cx_arc(_c, _cx, _cy, _R - 1.5, pi * 1.05, pi * 1.55); stra_cx_stroke(_c);
}

function stra__f_trilobite(_c, _W, _H, _r) {
    var _cx = _W / 2, _top = _H * 0.08, _bot = _H * 0.94, _hw = _W * 0.42;
    var _col = stra__pickc(_r, [[74, 64, 56], [91, 80, 72], [63, 68, 80]]);
    stra__soft(_c, _cx, (_top + _bot) / 2, _hw, (_bot - _top) / 2);
    // cephalon: a half-moon head shield with genal spines
    _c.fill = stra_cx_solid(stra__shade(_col, 0.15));
    stra_cx_begin(_c); stra_cx_move(_c, _cx - _hw, _top + _H * 0.26);
    stra_cx_quad(_c, _cx - _hw, _top, _cx, _top); stra_cx_quad(_c, _cx + _hw, _top, _cx + _hw, _top + _H * 0.26);
    stra_cx_line(_c, _cx + _hw * 1.05, _top + _H * 0.38); stra_cx_line(_c, _cx + _hw * 0.8, _top + _H * 0.28);
    stra_cx_line(_c, _cx - _hw * 0.8, _top + _H * 0.28); stra_cx_line(_c, _cx - _hw * 1.05, _top + _H * 0.38); stra_cx_close(_c); stra_cx_fill(_c);
    // thorax segments narrowing to the pygidium
    var _us = stra_rand(_r); var _segs = 8 + floor(_us * 4);
    var _sy = _top + _H * 0.28, _sh = (_bot - _sy) * 0.78 / _segs;
    for (var _i = 0; _i < _segs; _i++) {
        var _w = _hw * (1 - _i / _segs * 0.45);
        stra__oval(_c, _cx, _sy + _i * _sh + _sh / 2, _w, _sh * 0.62, 0, stra__shade(_col, (_i mod 2) ? 0.05 : 0.18), 1);
    }
    stra__oval(_c, _cx, _bot - (_bot - _sy) * 0.12, _hw * 0.45, (_bot - _sy) * 0.13, 0, stra__shade(_col, 0.1), 1);
    // axial lobe and glabella: the raised spine that makes a trilobite a trilobite
    stra__oval(_c, _cx, _top + _H * 0.16, _hw * 0.28, _H * 0.1, 0, stra__shade(_col, 0.32), 1);
    _c.fill = stra_cx_solid(stra__shade(_col, 0.32));
    stra__poly(_c, [[_cx - _hw * 0.2, _sy], [_cx + _hw * 0.2, _sy], [_cx + _hw * 0.1, _bot - 6], [_cx - _hw * 0.1, _bot - 6]]); stra_cx_fill(_c);
    stra__disc(_c, _cx - _hw * 0.45, _top + _H * 0.17, 2.4, [21, 17, 13], 1);
    stra__disc(_c, _cx + _hw * 0.45, _top + _H * 0.17, 2.4, [21, 17, 13], 1);
}

function stra__f_bone(_c, _W, _H, _r) {
    // a long bone (a femur): a shaft that narrows to the middle, knuckled condyles at both ends, the growth line under each
    // head, a nutrient pit and a crack. Fresh ivory, a tan fossil or a dark permineralised one.
    var _cy = _H / 2, _t = _H * 0.21, _e = _H * 0.38;
    var _mat = stra__pickc(_r, [[[236, 224, 196], [150, 126, 86]], [[190, 146, 92], [96, 66, 34]], [[104, 80, 62], [40, 28, 22]]]);
    var _ivory = _mat[0], _dark = _mat[1];
    var _ub = stra_rand(_r); var _bend = (_ub - 0.5) * _t * 0.6;   // a slight bow in the shaft
    stra__soft(_c, _W / 2, _cy, _W * 0.47, _H * 0.32);
    var _g = stra_cx_linear(_c, 0, _cy - _e, 0, _cy + _e); stra_cx_stop(_g, 0, stra__shade(_ivory, 0.3)); stra_cx_stop(_g, 0.55, _ivory); stra_cx_stop(_g, 1, stra__shade(_ivory, -0.35));
    _c.fill = _g;
    stra_cx_begin(_c);
    stra_cx_move(_c, _e * 1.6, _cy - _t);
    stra_cx_bezier(_c, _W * 0.4, _cy - _t * 0.62 + _bend, _W * 0.6, _cy - _t * 0.62 + _bend, _W - _e * 1.6, _cy - _t);
    stra_cx_arc(_c, _W - _e * 1.1, _cy - _e * 0.45, _e * 0.64, pi * 1.1, pi * 0.1);
    stra_cx_arc(_c, _W - _e * 1.1, _cy + _e * 0.45, _e * 0.64, -pi * 0.1, pi * 0.9);
    stra_cx_bezier(_c, _W * 0.6, _cy + _t * 0.62 + _bend, _W * 0.4, _cy + _t * 0.62 + _bend, _e * 1.6, _cy + _t);
    stra_cx_arc(_c, _e * 1.1, _cy + _e * 0.45, _e * 0.64, pi * 0.1, pi * 1.1);
    stra_cx_arc(_c, _e * 1.1, _cy - _e * 0.45, _e * 0.64, pi * 0.9, pi * 1.9);
    stra_cx_close(_c); stra_cx_fill(_c);
    _c.stroke = stra_cx_solid(stra__shade(_dark, -0.3), 0.75); _c.lw = 1.1; stra_cx_stroke(_c);
    // the heads: a darker growth line where each head meets the shaft, and the notch between the two knuckles
    for (var _s = 0; _s < 2; _s++) {
        var _hx = (_s == 0) ? _e * 1.75 : _W - _e * 1.75;
        stra__line(_c, _hx, _cy - _t * 0.95, _hx + ((_s == 0) ? 1.5 : -1.5), _cy + _t * 0.95, _dark, 0.5, 1.2);
        var _nx = (_s == 0) ? _e * 0.35 : _W - _e * 0.35;
        _c.fill = stra_cx_solid(_dark, 0.55); stra__poly(_c, [[_nx, _cy - 2.2], [_nx + ((_s == 0) ? 4.5 : -4.5), _cy], [_nx, _cy + 2.2]]); stra_cx_fill(_c);
    }
    // the shaft's lit ridge, a nutrient pit, mineral speckle and a crack across the shaft
    stra__line(_c, _e * 1.9, _cy - _t * 0.45 + _bend * 0.5, _W - _e * 1.9, _cy - _t * 0.45 + _bend * 0.5, stra__shade(_ivory, 0.45), 0.55, 1.3);
    var _up = stra_rand(_r); stra__oval(_c, _W * (0.42 + _up * 0.12), _cy + _t * 0.15, 1.6, 1.1, 0, _dark, 0.8);
    repeat (14) { var _sx = stra_rand(_r); var _sy = stra_rand(_r); stra__disc(_c, _e * 1.8 + _sx * (_W - _e * 3.6), _cy + (_sy - 0.5) * _t * 1.2, 0.7, _dark, 0.35); }
    _c.stroke = stra_cx_solid(stra__shade(_dark, -0.3), 0.6); _c.lw = 1;
    var _uk = stra_rand(_r); var _cxk = _W * (0.3 + _uk * 0.4);
    stra_cx_begin(_c); stra_cx_move(_c, _cxk, _cy - _t * 0.75); stra_cx_line(_c, _cxk + 4, _cy - 1); stra_cx_line(_c, _cxk - 2, _cy + _t * 0.75); stra_cx_stroke(_c);
}

function stra__f_tooth(_c, _W, _H, _r) {
    // a predator's fang: a crown that curves back to its tip, a serrated trailing edge, and a forked root below a dark
    // neck. Ivory, a brown fossil or a black fossil with glossy enamel.
    var _mat = stra__pickc(_r, [[[247, 241, 226], [168, 150, 112], [120, 86, 56]], [[214, 170, 110], [118, 80, 40], [86, 56, 32]], [[86, 80, 84], [26, 22, 26], [70, 52, 40]]]);
    var _cx = _W / 2, _bw = _W * 0.36, _tip = _H * 0.03, _neck = _H * 0.6;
    var _uc = stra_rand(_r); var _curl = _bw * (0.55 + _uc * 0.35);   // how far the tip sweeps back
    stra__soft(_c, _cx, _H / 2, _bw, _H * 0.44);
    // the root: two prongs splaying apart, darker, below the neck
    _c.fill = stra_cx_solid(_mat[2]);
    stra_cx_begin(_c); stra_cx_move(_c, _cx - _bw * 0.9, _neck); stra_cx_quad(_c, _cx - _bw * 1.0, _H * 0.8, _cx - _bw * 0.78, _H * 0.97);
    stra_cx_line(_c, _cx - _bw * 0.28, _H * 0.97); stra_cx_quad(_c, _cx - _bw * 0.12, _H * 0.78, _cx, _H * 0.74);
    stra_cx_quad(_c, _cx + _bw * 0.12, _H * 0.78, _cx + _bw * 0.28, _H * 0.97); stra_cx_line(_c, _cx + _bw * 0.78, _H * 0.97);
    stra_cx_quad(_c, _cx + _bw * 1.0, _H * 0.8, _cx + _bw * 0.9, _neck); stra_cx_close(_c); stra_cx_fill(_c);
    _c.stroke = stra_cx_solid(stra__shade(_mat[2], -0.4), 0.8); _c.lw = 1; stra_cx_stroke(_c);
    // the crown: the front edge bows out, the back edge runs up to the tip swept back
    var _g = stra_cx_linear(_c, _cx - _bw, 0, _cx + _bw, 0); stra_cx_stop(_g, 0, stra__shade(_mat[0], 0.2)); stra_cx_stop(_g, 0.45, _mat[0]); stra_cx_stop(_g, 1, _mat[1]);
    _c.fill = _g;
    stra_cx_begin(_c); stra_cx_move(_c, _cx - _bw, _neck + 2);
    stra_cx_bezier(_c, _cx - _bw * 1.15, _H * 0.32, _cx - _bw * 0.2 + _curl * 0.3, _H * 0.1, _cx + _curl, _tip);
    stra_cx_bezier(_c, _cx + _curl * 0.55, _H * 0.18, _cx + _bw * 0.85, _H * 0.36, _cx + _bw, _neck + 2);
    stra_cx_close(_c); stra_cx_fill(_c);
    _c.stroke = stra_cx_solid(stra__shade(_mat[1], -0.45), 0.85); _c.lw = 1; stra_cx_stroke(_c);
    // serrations along the back edge: small teeth on the curve from the tip down
    for (var _s = 1; _s < 9; _s++) {
        var _t = _s / 9, _ex = (1 - _t) * (_cx + _curl) + _t * (_cx + _bw), _ey = (1 - _t) * _tip + _t * (_neck + 2);
        _ex -= sin(_t * pi) * _bw * 0.12;
        stra__line(_c, _ex - 0.5, _ey, _ex + 1.6, _ey + 1.2, stra__shade(_mat[1], -0.5), 0.75, 1);
    }
    // the neck where enamel stops, and the enamel's gloss
    stra__line(_c, _cx - _bw * 0.98, _neck + 1, _cx + _bw * 0.98, _neck + 1, _mat[2], 0.8, 1.6);
    _c.stroke = stra_cx_solid([255, 255, 255], 0.55); _c.lw = 1.5;
    stra_cx_begin(_c); stra_cx_move(_c, _cx - _bw * 0.62, _neck - 6); stra_cx_quad(_c, _cx - _bw * 0.62, _H * 0.3, _cx + _curl * 0.55, _tip + 8); stra_cx_stroke(_c);
}

function stra__f_amber(_c, _W, _H, _r) {
    var _cx = _W / 2, _cy = _H / 2;
    stra__soft(_c, _cx, _cy, _W * 0.42, _H * 0.38);
    var _pts = [];
    stra_cx_begin(_c);
    for (var _i = 0; _i < 12; _i++) {
        var _a = _i / 12 * STRA_TAU; var _u = stra_rand(_r); var _rr = min(_W, _H) * (0.36 + _u * 0.08);
        var _px = _cx + cos(_a) * _rr * 1.08, _py = _cy + sin(_a) * _rr * 0.92;
        if (_i == 0) stra_cx_move(_c, _px, _py); else stra_cx_quad(_c, _cx + cos(_a - 0.26) * _rr * 1.2, _cy + sin(_a - 0.26) * _rr, _px, _py);
    }
    stra_cx_close(_c);
    var _hue = stra__pickc(_r, [[[255, 210, 122], [196, 106, 14], [107, 46, 5]], [[255, 227, 154], [224, 154, 28], [122, 67, 8]], [[255, 180, 107], [178, 68, 13], [77, 21, 4]]]);
    var _g = stra_cx_radial(_c, _cx - 8, _cy - 10, 3, _cx, _cy, _W * 0.45); stra_cx_stop(_g, 0, _hue[0]); stra_cx_stop(_g, 0.55, _hue[1]); stra_cx_stop(_g, 1, _hue[2]);
    _c.fill = _g; stra_cx_fill(_c);
    stra_cx_save(_c); stra_cx_clip(_c);
    // the inclusion: a trapped insect in silhouette, or a drift of bubbles
    _c.alpha = 0.75;
    var _ui = stra_rand(_r);
    if (_ui < 0.65) {
        var _u1 = stra_rand(_r); var _u2 = stra_rand(_r); var _u3 = stra_rand(_r);
        stra_cx_translate(_c, _cx + (_u1 - 0.5) * 12, _cy + (_u2 - 0.5) * 10); stra_cx_rotate(_c, _u3 * STRA_TAU);
        stra__oval(_c, 0, 0, 7, 3, 0, [58, 26, 5], 1);
        stra__disc(_c, 8, 0, 2.5, [58, 26, 5], 1);
        stra__oval(_c, -1, -6, 7, 3, -0.4, [255, 240, 210], 0.45);
        stra__oval(_c, -1, 6, 7, 3, 0.4, [255, 240, 210], 0.45);
        _c.stroke = stra_cx_solid([58, 26, 5]); _c.lw = 0.9;
        for (var _l = -1; _l <= 1; _l++) { stra_cx_begin(_c); stra_cx_move(_c, _l * 3, 0); stra_cx_line(_c, _l * 4 - 2, 7); stra_cx_move(_c, _l * 3, 0); stra_cx_line(_c, _l * 4 - 2, -7); stra_cx_stroke(_c); }
    } else {
        for (var _b = 0; _b < 9; _b++) { var _v1 = stra_rand(_r); var _v2 = stra_rand(_r); var _v3 = stra_rand(_r); _c.stroke = stra_cx_solid([255, 245, 220], 0.7); _c.lw = 1; stra_cx_begin(_c); stra_cx_arc(_c, _cx + (_v1 - 0.5) * _W * 0.5, _cy + (_v2 - 0.5) * _H * 0.5, 1 + _v3 * 3, 0, STRA_TAU); stra_cx_stroke(_c); }
    }
    stra_cx_restore(_c); _c.alpha = 1;
    stra__oval(_c, _cx - _W * 0.16, _cy - _H * 0.2, _W * 0.1, _H * 0.05, -0.5, [255, 255, 255], 0.55);
}

function stra__f_geode(_c, _W, _H, _r) {
    var _cx = _W / 2, _cy = _H / 2, _R = min(_W, _H) * 0.44;
    var _gem = stra__pickc(_r, [[[217, 184, 255], [122, 63, 192], [59, 20, 102]], [[242, 247, 255], [159, 182, 214], [77, 100, 128]], [[255, 233, 166], [224, 165, 38], [122, 79, 7]]]);
    stra__soft(_c, _cx, _cy, _R, _R);
    var _pts = [];
    for (var _i = 0; _i < 14; _i++) { var _a = _i / 14 * STRA_TAU; var _u = stra_rand(_r); var _rr = _R * (0.93 + _u * 0.08); array_push(_pts, [_cx + cos(_a) * _rr, _cy + sin(_a) * _rr]); }
    _c.fill = stra_cx_solid([106, 98, 90]); stra__poly(_c, _pts); stra_cx_fill(_c);
    // agate banding in the rind
    for (var _bnd = 0; _bnd < 4; _bnd++) { _c.stroke = (_bnd mod 2) ? stra_cx_solid([230, 220, 205], 0.5) : stra_cx_solid([90, 80, 75], 0.6); _c.lw = 2; stra_cx_begin(_c); stra_cx_arc(_c, _cx, _cy, _R * (0.86 - _bnd * 0.06), 0, STRA_TAU); stra_cx_stroke(_c); }
    // the cavity lined with crystals pointing inward
    var _Rc = _R * 0.62;
    stra__disc(_c, _cx, _cy, _Rc, _gem[2], 1);
    var _nC = 18;
    for (var _k = 0; _k < _nC; _k++) {
        var _u1 = stra_rand(_r); var _u2 = stra_rand(_r);
        var _a2 = _k / _nC * STRA_TAU + _u1 * 0.1, _len = _Rc * (0.45 + _u2 * 0.4), _wd = 0.14;
        var _bx = _cx + cos(_a2) * _Rc, _by = _cy + sin(_a2) * _Rc, _tx = _cx + cos(_a2) * (_Rc - _len), _ty = _cy + sin(_a2) * (_Rc - _len);
        var _g = stra_cx_linear(_c, _bx, _by, _tx, _ty); stra_cx_stop(_g, 0, _gem[1]); stra_cx_stop(_g, 1, _gem[0]);
        _c.fill = _g; stra__poly(_c, [[_cx + cos(_a2 - _wd) * _Rc, _cy + sin(_a2 - _wd) * _Rc], [_tx, _ty], [_cx + cos(_a2 + _wd) * _Rc, _cy + sin(_a2 + _wd) * _Rc]]); stra_cx_fill(_c);
    }
    stra__disc(_c, _cx - _Rc * 0.3, _cy - _Rc * 0.35, 2.2, [255, 255, 255], 0.7);
}

function stra__f_ore(_c, _W, _H, _r) {
    // (MZ, found by looking) a hard-edged L polygon read as a HANDGUN: ore is a lumpy rounded nugget, a ring of bulges
    // around the footprint's centre of mass (three cells across the top, two below right)
    var _metal = stra__pickc(_r, [[[255, 224, 122], [184, 134, 11]], [[255, 181, 138], [177, 84, 42]], [[230, 236, 242], [142, 154, 166]], [[159, 227, 255], [47, 127, 168]]]);
    var _blobs = [[_W * 0.2, _H * 0.28, _H * 0.26], [_W * 0.5, _H * 0.26, _H * 0.3], [_W * 0.78, _H * 0.3, _H * 0.28], [_W * 0.55, _H * 0.66, _H * 0.28], [_W * 0.8, _H * 0.7, _H * 0.26]];
    var _pts = [], _sh = [];
    for (var _i2 = 0; _i2 < 28; _i2++) {
        var _a = _i2 / 28 * STRA_TAU, _cxm = _W * 0.57, _cym = _H * 0.45, _best = 0;
        for (var _b2 = 0; _b2 < 5; _b2++) {
            var _dx = _blobs[_b2][0] - _cxm, _dy = _blobs[_b2][1] - _cym, _proj = _dx * cos(_a) + _dy * sin(_a);
            var _perp = abs(-_dx * sin(_a) + _dy * cos(_a)), _rr0 = _blobs[_b2][2];
            if (_perp < _rr0) _best = max(_best, _proj + sqrt(_rr0 * _rr0 - _perp * _perp));
        }
        var _u = stra_rand(_r); _best *= 0.94 + _u * 0.08;
        array_push(_pts, [_cxm + cos(_a) * _best, _cym + sin(_a) * _best]); array_push(_sh, [_cxm + cos(_a) * _best + 3, _cym + sin(_a) * _best + 4]);
    }
    _c.fill = stra_cx_solid([0, 0, 0], 0.35); stra__poly(_c, _sh); stra_cx_fill(_c);
    var _g = stra_cx_linear(_c, 0, 0, _W, _H); stra_cx_stop(_g, 0, [109, 101, 94]); stra_cx_stop(_g, 1, [58, 52, 48]);
    _c.fill = _g; stra__poly(_c, _pts); stra_cx_fill(_c);
    _c.stroke = stra_cx_solid([30, 26, 23]); _c.lw = 1.2; stra_cx_stroke(_c);
    stra_cx_save(_c); stra__poly(_c, _pts); stra_cx_clip(_c);
    for (var _v = 0; _v < 4; _v++) {
        var _u1 = stra_rand(_r); var _u2 = stra_rand(_r); var _u3 = stra_rand(_r); var _u4 = stra_rand(_r); var _u5 = stra_rand(_r);
        var _y0 = _u1 * _H, _wv = 3 + _u2 * 4;
        var _vg = stra_cx_linear(_c, 0, _y0 - _wv, 0, _y0 + _wv); stra_cx_stop(_vg, 0, _metal[1]); stra_cx_stop(_vg, 0.5, _metal[0]); stra_cx_stop(_vg, 1, _metal[1]);
        _c.stroke = _vg; _c.lw = _wv;
        stra_cx_begin(_c); stra_cx_move(_c, 0, _y0); stra_cx_bezier(_c, _W * 0.3, _y0 + (_u3 - 0.5) * 30, _W * 0.7, _y0 + (_u4 - 0.5) * 30, _W, _y0 + (_u5 - 0.5) * 20); stra_cx_stroke(_c);
    }
    for (var _f = 0; _f < 22; _f++) { var _q1 = stra_rand(_r); var _q2 = stra_rand(_r); var _q3 = stra_rand(_r); _c.fill = stra_cx_solid(_metal[0], 0.5 + _q1 * 0.5); stra_cx_fill_rect(_c, _q2 * _W, _q3 * _H, 2, 2); }
    stra_cx_restore(_c);
}

function stra__f_crystal(_c, _W, _H, _r) {
    var _col = stra__pickc(_r, [[[232, 246, 255], [143, 199, 232], [45, 111, 147]], [[255, 214, 240], [224, 114, 184], [122, 31, 92]], [[216, 255, 217], [92, 196, 106], [28, 102, 48]]]);
    // (MZ, found by looking) the fan of prisms bled far outside the footprint: spread and lengths stay inside the box
    var _cx = _W / 2, _by = _H * 0.92;
    stra_cx_save(_c); stra_cx_begin(_c); stra_cx_rect(_c, 0, 0, _W, _H); stra_cx_clip(_c);
    stra__soft(_c, _cx, _H * 0.55, _W * 0.36, _H * 0.4);
    var _un = stra_rand(_r); var _n = 3 + floor(_un * 3);
    for (var _i = 0; _i < _n; _i++) {
        var _u1 = stra_rand(_r); var _u2 = stra_rand(_r); var _u3 = stra_rand(_r);
        var _ang = (_i - (_n - 1) / 2) * 0.17 + (_u1 - 0.5) * 0.06, _len = _H * (0.5 + _u2 * 0.32), _w = _W * (0.09 + _u3 * 0.04);
        stra_cx_save(_c); stra_cx_translate(_c, _cx + (_i - (_n - 1) / 2) * _w * 0.7, _by); stra_cx_rotate(_c, _ang);
        var _pr = [[-_w, 0], [-_w, -_len * 0.78], [0, -_len], [_w, -_len * 0.78], [_w, 0]];
        var _g = stra_cx_linear(_c, -_w, 0, _w, 0); stra_cx_stop(_g, 0, _col[1]); stra_cx_stop(_g, 0.45, _col[0]); stra_cx_stop(_g, 1, _col[2]);
        _c.fill = _g; stra__poly(_c, _pr); stra_cx_fill(_c);
        _c.stroke = stra_cx_solid(stra__shade(_col[2], -0.3)); _c.lw = 1; stra__poly(_c, _pr); stra_cx_stroke(_c);
        _c.stroke = stra_cx_solid([255, 255, 255], 0.55); stra_cx_begin(_c); stra_cx_move(_c, -_w * 0.2, -4); stra_cx_line(_c, -_w * 0.2, -_len * 0.78); stra_cx_line(_c, 0, -_len); stra_cx_stroke(_c);
        stra_cx_restore(_c);
    }
    stra_cx_restore(_c);
}

function stra__f_tablet(_c, _W, _H, _r) {
    var _x = _W * 0.1, _y = _H * 0.05, _w = _W * 0.8, _h = _H * 0.9;
    var _stone = stra__pickc(_r, [[143, 134, 118], [166, 155, 134], [118, 108, 96]]);
    _c.fill = stra_cx_solid([0, 0, 0], 0.35); stra_cx_fill_rect(_c, _x + 3, _y + 4, _w, _h);
    stra_cx_begin(_c); stra_cx_move(_c, _x, _y + _h); stra_cx_line(_c, _x, _y + _w / 2); stra_cx_arc(_c, _x + _w / 2, _y + _w / 2, _w / 2, pi, 0); stra_cx_line(_c, _x + _w, _y + _h * 0.82); stra_cx_line(_c, _x + _w * 0.78, _y + _h); stra_cx_close(_c);
    var _g = stra_cx_linear(_c, _x, _y, _x + _w, _y + _h); stra_cx_stop(_g, 0, stra__shade(_stone, 0.2)); stra_cx_stop(_g, 1, stra__shade(_stone, -0.25));
    _c.fill = _g; stra_cx_fill(_c); _c.stroke = stra_cx_solid(stra__shade(_stone, -0.5)); _c.lw = 1.2; stra_cx_stroke(_c);
    // an inscription in an unknown script: glyph strokes on ruled lines, different on every tablet
    _c.stroke = stra_cx_solid(stra__shade(_stone, -0.55)); _c.lw = 1.3;
    var _rows = 6, _gw = 7;
    for (var _ro = 0; _ro < _rows; _ro++) {
        var _ly = _y + _w * 0.42 + _ro * (_h - _w * 0.5) / _rows;
        for (var _gx = _x + 7; _gx < _x + _w - 10; _gx += _gw + 3) {
            var _u = stra_rand(_r); var _k = floor(_u * 5);
            stra_cx_begin(_c);
            if (_k == 0) { stra_cx_move(_c, _gx, _ly); stra_cx_line(_c, _gx + _gw, _ly); stra_cx_move(_c, _gx + _gw / 2, _ly - 4); stra_cx_line(_c, _gx + _gw / 2, _ly + 4); }
            else if (_k == 1) { stra_cx_move(_c, _gx, _ly + 4); stra_cx_line(_c, _gx + _gw / 2, _ly - 4); stra_cx_line(_c, _gx + _gw, _ly + 4); }
            else if (_k == 2) { stra_cx_arc(_c, _gx + _gw / 2, _ly, _gw / 2.4, 0, STRA_TAU); }
            else if (_k == 3) { stra_cx_move(_c, _gx, _ly - 4); stra_cx_line(_c, _gx + _gw, _ly + 4); stra_cx_move(_c, _gx + _gw, _ly - 4); stra_cx_line(_c, _gx + _gw / 2, _ly); }
            else { stra_cx_move(_c, _gx, _ly - 3); stra_cx_line(_c, _gx, _ly + 4); stra_cx_line(_c, _gx + _gw, _ly + 4); }
            stra_cx_stroke(_c);
        }
    }
    _c.stroke = stra_cx_solid(stra__shade(_stone, -0.6));
    stra_cx_begin(_c); stra_cx_move(_c, _x + _w, _y + _h * 0.82); stra_cx_line(_c, _x + _w * 0.86, _y + _h * 0.9); stra_cx_line(_c, _x + _w * 0.78, _y + _h); stra_cx_stroke(_c);
}

function stra__f_shell(_c, _W, _H, _r) {
    // (MZ, found by looking) ribs at R*1.9 bled far outside the 2x2 box: the fan radius is derived from the box
    var _cx = _W / 2, _hy = _H * 0.84, _R = min(_W, _H) * 0.25;
    var _col = stra__pickc(_r, [[[255, 226, 201], [229, 154, 106]], [[243, 239, 230], [184, 169, 143]], [[255, 208, 221], [209, 112, 140]]]);
    stra__soft(_c, _cx, _H / 2, _R, _R * 0.9);
    // ears at the hinge, then a fan of ribs
    _c.fill = stra_cx_solid(stra__shade(_col[1], -0.1));
    stra__poly(_c, [[_cx - _R * 0.45, _hy], [_cx - _R * 0.2, _hy - _R * 0.25], [_cx + _R * 0.2, _hy - _R * 0.25], [_cx + _R * 0.45, _hy]]); stra_cx_fill(_c);
    var _ur = stra_rand(_r); var _ribs = 11 + floor(_ur * 5), _a0 = -pi * 0.92, _a1 = -pi * 0.08;
    for (var _i = 0; _i < _ribs; _i++) {
        var _ta = _a0 + (_a1 - _a0) * (_i / _ribs), _tb = _a0 + (_a1 - _a0) * ((_i + 1) / _ribs);
        stra_cx_begin(_c); stra_cx_move(_c, _cx, _hy);
        stra_cx_line(_c, _cx + cos(_ta) * _R * 1.9, _hy + sin(_ta) * _R * 1.9);
        stra_cx_quad(_c, _cx + cos((_ta + _tb) / 2) * _R * 2.02, _hy + sin((_ta + _tb) / 2) * _R * 2.02, _cx + cos(_tb) * _R * 1.9, _hy + sin(_tb) * _R * 1.9);
        stra_cx_close(_c);
        var _g = stra_cx_linear(_c, _cx, _hy, _cx, _hy - _R * 1.9); stra_cx_stop(_g, 0, _col[1]); stra_cx_stop(_g, 1, (_i mod 2) ? _col[0] : stra__shade(_col[0], -0.08));
        _c.fill = _g; stra_cx_fill(_c); _c.stroke = stra_cx_solid(stra__shade(_col[1], -0.35)); _c.lw = 0.8; stra_cx_stroke(_c);
    }
    _c.stroke = stra_cx_solid([120, 70, 40], 0.35); _c.lw = 0.8;
    for (var _gr = 1; _gr < 4; _gr++) { stra_cx_begin(_c); stra_cx_arc(_c, _cx, _hy, _R * 0.5 * _gr, _a0, _a1); stra_cx_stroke(_c); }
}

// The six this edition adds. Each keeps the MZ grammar: a contact shadow, a body in a two- or three-stop material, one
// structure that makes the subject read as itself, a highlight on the lamp's side (top left), three colourways.

function stra__slab(_c, _W, _H, _r, _rgb, _inset) {
    // an irregular stone slab filling the box: a split nodule or bedding slab the fossil lies on
    var _pts = [], _n = 18, _cx = _W / 2, _cy = _H / 2;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _i / _n * STRA_TAU; var _u = stra_rand(_r);
        var _ex = (_W / 2 - _inset) * (0.9 + _u * 0.1), _ey = (_H / 2 - _inset) * (0.88 + _u * 0.12);
        // a rounded rectangle-ish slab: superellipse radius
        var _co = cos(_a), _si = sin(_a);
        var _k = power(power(abs(_co), 4) + power(abs(_si), 4), -0.25);
        array_push(_pts, [_cx + _co * _ex * _k, _cy + _si * _ey * _k]);
    }
    var _sh = []; for (var _j = 0; _j < _n; _j++) array_push(_sh, [_pts[_j][0] + 3, _pts[_j][1] + 4]);
    _c.fill = stra_cx_solid([0, 0, 0], 0.35); stra__poly(_c, _sh); stra_cx_fill(_c);
    var _g = stra_cx_linear(_c, 0, 0, _W, _H); stra_cx_stop(_g, 0, stra__shade(_rgb, 0.16)); stra_cx_stop(_g, 1, stra__shade(_rgb, -0.18));
    _c.fill = _g; stra__poly(_c, _pts); stra_cx_fill(_c);
    _c.stroke = stra_cx_solid(stra__shade(_rgb, -0.45), 0.9); _c.lw = 1.1; stra__poly(_c, _pts); stra_cx_stroke(_c);
    _c.stroke = stra_cx_solid([255, 255, 255], 0.22); _c.lw = 1;
    stra_cx_begin(_c); for (var _q = 10; _q <= 15; _q++) { if (_q == 10) stra_cx_move(_c, _pts[_q][0] + 1.5, _pts[_q][1] + 1.5); else stra_cx_line(_c, _pts[_q][0] + 1.5, _pts[_q][1] + 1.5); } stra_cx_stroke(_c);
    return _pts;
}

function stra__f_fern(_c, _W, _H, _r) {
    var _cw = stra__pickc(_r, [[[150, 148, 140], [36, 34, 32]], [[196, 176, 140], [74, 52, 30]], [[168, 116, 92], [44, 26, 20]]]);
    stra__slab(_c, _W, _H, _r, _cw[0], 3);
    // the frond: a curving rachis from the base to a curled tip, pinnae alternating and shrinking toward the tip
    var _bx = _W * 0.5, _by = _H * 0.95, _u = stra_rand(_r); var _lean = (_u - 0.5) * _W * 0.25;
    var _ink = _cw[1], _n = 22, _sp = [];
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n, _y = _by - _t * _H * 0.86, _x = _bx + _lean * _t * _t + sin(_t * pi) * _W * 0.05;
        array_push(_sp, [_x, _y]);
    }
    for (var _p = 1; _p < _n - 1; _p++) {
        var _t2 = _p / _n, _len = _W * 0.42 * (1 - _t2 * 0.75) * (0.35 + 0.65 * min(1, _t2 * 4)), _side = (_p mod 2) ? 1 : -1;
        var _x0 = _sp[_p][0], _y0 = _sp[_p][1], _ang = -pi / 2 + _side * (1.05 - _t2 * 0.35);
        var _tx = _x0 + cos(_ang) * _len, _ty = _y0 + sin(_ang) * _len * 0.8;
        // each pinna a lobed leaflet: a lens with three notches, filled, then a midrib
        var _nx = -(_ty - _y0), _ny = (_tx - _x0), _nl = max(0.001, sqrt(_nx * _nx + _ny * _ny)); _nx /= _nl; _ny /= _nl;
        var _bw = _len * 0.2, _pts = [];
        for (var _s = 0; _s <= 8; _s++) { var _f = _s / 8, _wd = _bw * sin(_f * pi) * (1 - 0.35 * ((_s mod 2 == 1) ? 1 : 0)); array_push(_pts, [_x0 + (_tx - _x0) * _f + _nx * _wd, _y0 + (_ty - _y0) * _f + _ny * _wd]); }
        for (var _s2 = 7; _s2 >= 1; _s2--) { var _f2 = _s2 / 8, _wd2 = _bw * sin(_f2 * pi) * (1 - 0.35 * ((_s2 mod 2 == 1) ? 1 : 0)); array_push(_pts, [_x0 + (_tx - _x0) * _f2 - _nx * _wd2, _y0 + (_ty - _y0) * _f2 - _ny * _wd2]); }
        _c.fill = stra_cx_solid(_ink, 0.82); stra__poly(_c, _pts); stra_cx_fill(_c);
        stra__line(_c, _x0, _y0, _tx, _ty, stra__shade(_cw[0], 0.25), 0.35, 0.8);
    }
    _c.stroke = stra_cx_solid(_ink, 0.95); _c.lw = 2.2; stra__poly(_c, _sp, false); stra_cx_stroke(_c);
    // the crozier: the tip curls over
    var _tip = _sp[_n]; _c.lw = 1.6;
    stra_cx_begin(_c); stra_cx_arc(_c, _tip[0] + 3, _tip[1] + 2, 3.2, pi, pi * 2.6); stra_cx_stroke(_c);
}

function stra__f_fish(_c, _W, _H, _r) {
    var _cw = stra__pickc(_r, [[[226, 210, 172], [120, 82, 44]], [[170, 168, 160], [40, 38, 40]], [[214, 170, 100], [92, 50, 22]]]);
    stra__slab(_c, _W, _H, _r, _cw[0], 2);
    var _ink = _cw[1], _cx = _W * 0.48, _cy = _H * 0.5, _L = _W * 0.38, _B = _H * 0.26;
    var _ua = stra_rand(_r); var _bend = (_ua - 0.5) * 0.25;
    // body: a spindle, head to the left
    var _top = [], _bot = [];
    for (var _i = 0; _i <= 16; _i++) {
        var _t = _i / 16, _x = _cx - _L + 2 * _L * _t, _y = _cy + _bend * sin(_t * pi) * _H * 0.4, _w = _B * power(sin(pi * min(1, _t * 1.05)), 0.75) * (1 - 0.35 * _t);
        array_push(_top, [_x, _y - _w]); array_push(_bot, [_x, _y + _w]);
    }
    var _body = []; for (var _a = 0; _a <= 16; _a++) array_push(_body, _top[_a]); for (var _b = 16; _b >= 0; _b--) array_push(_body, _bot[_b]);
    _c.fill = stra_cx_solid(stra__shade(_cw[0], -0.18), 0.85); stra__poly(_c, _body); stra_cx_fill(_c);
    // tail: a forked caudal fin with rays
    var _tx = _cx + _L, _ty = _cy;
    var _tail = [[_tx - 2, _ty - _B * 0.18], [_tx + _W * 0.11, _ty - _B * 1.05], [_tx + _W * 0.075, _ty], [_tx + _W * 0.11, _ty + _B * 1.05], [_tx - 2, _ty + _B * 0.18]];
    _c.fill = stra_cx_solid(stra__shade(_cw[0], -0.25), 0.8); stra__poly(_c, _tail); stra_cx_fill(_c);
    for (var _k = 0; _k < 7; _k++) { var _f = (_k + 0.5) / 7; stra__line(_c, _tx, _ty, _tx + _W * (0.11 - 0.035 * sin(_f * pi)), _ty - _B * 1.05 + _f * _B * 2.1, _ink, 0.55, 0.8); }
    // fins: dorsal and anal with rays
    for (var _side = -1; _side <= 1; _side += 2) {
        var _fx0 = _cx + _L * ((_side < 0) ? 0.05 : 0.25), _fx1 = _fx0 + _L * 0.42, _fy = _cy + _side * _B * 0.9;
        for (var _q = 0; _q < 8; _q++) { var _qx = _fx0 + (_fx1 - _fx0) * _q / 7; stra__line(_c, _qx, _fy, _qx + 5, _fy + _side * (_B * 0.55 - _q * 1.2), _ink, 0.6, 0.9); }
    }
    // the spine and ribs: what makes a fossil fish a fossil fish
    var _verts = 24;
    for (var _v = 0; _v < _verts; _v++) {
        var _t3 = 0.2 + 0.75 * _v / (_verts - 1), _vx = _cx - _L + 2 * _L * _t3, _vy = _cy + _bend * sin(_t3 * pi) * _H * 0.4;
        _c.fill = stra_cx_solid(_ink, 0.85); stra_cx_fill_rect(_c, _vx - 1.6, _vy - 1.4, 3, 2.8);
        if (_t3 < 0.8) { var _rl = _B * (0.95 - _t3 * 0.55); stra__line(_c, _vx, _vy, _vx - 3, _vy - _rl, _ink, 0.55, 0.9); stra__line(_c, _vx, _vy, _vx - 3, _vy + _rl, _ink, 0.55, 0.9); }
    }
    // skull: plates, the eye, the jaw
    var _hx = _cx - _L * 0.78;
    _c.stroke = stra_cx_solid(_ink, 0.8); _c.lw = 1.2;
    stra_cx_begin(_c); stra_cx_arc(_c, _hx + _L * 0.14, _cy, _B * 0.85, -pi / 2, pi / 2); stra_cx_stroke(_c);
    stra__disc(_c, _hx - _L * 0.02, _cy - _B * 0.25, _B * 0.2, _ink, 0.9);
    stra__disc(_c, _hx - _L * 0.02 - 1, _cy - _B * 0.25 - 1, _B * 0.06, stra__shade(_cw[0], 0.3), 0.8);
    stra__line(_c, _cx - _L, _cy + _B * 0.05, _hx + _L * 0.06, _cy + _B * 0.4, _ink, 0.7, 1.1);
}

function stra__f_point(_c, _W, _H, _r) {
    // a knapped point, tip up: a blade widest low down, two BARBS flaring down at its shoulders, a narrow stem between them
    // (the barbs and the stem are what tell it from a tooth at a glance), flake scars meeting at the midline
    var _mat = stra__pickc(_r, [[[150, 150, 156], [70, 70, 78], [214, 214, 222]], [[214, 162, 92], [124, 78, 34], [250, 214, 150]], [[44, 40, 52], [12, 10, 16], [150, 150, 190]]]);
    var _cx = _W / 2, _tip = _H * 0.03, _stem = _H * 0.66, _bw = _W * 0.46;
    var _L = [], _R = [];
    for (var _i = 0; _i <= 12; _i++) {
        var _t = _i / 12, _y = _tip + (_stem - _tip) * _t, _w = _bw * power(sin(min(1, _t * 1.1) * pi / 2), 0.85);
        var _u1 = stra_rand(_r); var _u2 = stra_rand(_r);
        array_push(_L, [_cx - _w - (_u1 - 0.5) * 1.6, _y]); array_push(_R, [_cx + _w + (_u2 - 0.5) * 1.6, _y]);
    }
    var _ub = stra_rand(_r); var _barb = _H * (0.1 + _ub * 0.05), _tw = _bw * 0.3;
    var _shp = []; for (var _a = 0; _a <= 12; _a++) array_push(_shp, _R[_a]);
    array_push(_shp, [_cx + _bw * 0.98, _stem + _barb]); array_push(_shp, [_cx + _tw * 1.1, _stem + _barb * 0.35]);
    array_push(_shp, [_cx + _tw, _H * 0.94]); array_push(_shp, [_cx + _tw * 1.25, _H * 0.98]); array_push(_shp, [_cx - _tw * 1.25, _H * 0.98]); array_push(_shp, [_cx - _tw, _H * 0.94]);
    array_push(_shp, [_cx - _tw * 1.1, _stem + _barb * 0.35]); array_push(_shp, [_cx - _bw * 0.98, _stem + _barb]);
    for (var _b = 12; _b >= 0; _b--) array_push(_shp, _L[_b]);
    var _sh = []; for (var _j = 0; _j < array_length(_shp); _j++) array_push(_sh, [_shp[_j][0] + 3, _shp[_j][1] + 4]);
    _c.fill = stra_cx_solid([0, 0, 0], 0.35); stra__poly(_c, _sh); stra_cx_fill(_c);
    var _g = stra_cx_linear(_c, _cx - _bw, 0, _cx + _bw, 0); stra_cx_stop(_g, 0, _mat[2]); stra_cx_stop(_g, 0.5, _mat[0]); stra_cx_stop(_g, 1, _mat[1]);
    _c.fill = _g; stra__poly(_c, _shp); stra_cx_fill(_c);
    // flake scars: shallow facets from each edge toward the midline, alternately lit and shaded
    for (var _k = 0; _k < 11; _k++) {
        var _p0 = _L[_k], _p1 = _L[_k + 1], _q0 = _R[_k], _q1 = _R[_k + 1], _my = (_p0[1] + _p1[1]) / 2;
        _c.fill = stra_cx_solid(_mat[2], (_k mod 2) ? 0.28 : 0.12); stra__poly(_c, [_p0, _p1, [_cx, _my + 3]]); stra_cx_fill(_c);
        _c.fill = stra_cx_solid(_mat[1], (_k mod 2) ? 0.12 : 0.3); stra__poly(_c, [_q0, _q1, [_cx, _my + 3]]); stra_cx_fill(_c);
    }
    _c.stroke = stra_cx_solid(stra__shade(_mat[1], -0.4), 0.9); _c.lw = 1; stra__poly(_c, _shp); stra_cx_stroke(_c);
    stra__line(_c, _cx - 0.5, _tip + 6, _cx - 0.5, _stem - 4, _mat[2], 0.45, 1);
}

function stra__f_coin(_c, _W, _H, _r) {
    // a struck coin: rim, a dotted border, a device, wear on the high points; gold, silver or bronze with verdigris
    var _m = stra__pickc(_r, [[[255, 226, 130], [196, 140, 30], [110, 70, 10]], [[236, 238, 240], [150, 154, 160], [70, 72, 78]], [[214, 150, 96], [140, 82, 40], [70, 40, 18]]]);
    var _cx = _W / 2, _cy = _H / 2, _R = min(_W, _H) * 0.44;
    stra__soft(_c, _cx, _cy, _R, _R);
    var _g = stra_cx_radial(_c, _cx - _R * 0.35, _cy - _R * 0.4, 1, _cx, _cy, _R); stra_cx_stop(_g, 0, _m[0]); stra_cx_stop(_g, 0.7, _m[1]); stra_cx_stop(_g, 1, _m[2]);
    _c.fill = _g; stra_cx_begin(_c); stra_cx_arc(_c, _cx, _cy, _R, 0, STRA_TAU); stra_cx_fill(_c);
    _c.stroke = stra_cx_solid(_m[2], 0.9); _c.lw = 1.4; stra_cx_begin(_c); stra_cx_arc(_c, _cx, _cy, _R * 0.82, 0, STRA_TAU); stra_cx_stroke(_c);
    for (var _d = 0; _d < 24; _d++) { var _a = _d / 24 * STRA_TAU; stra__disc(_c, _cx + cos(_a) * _R * 0.91, _cy + sin(_a) * _R * 0.91, 0.75, _m[2], 0.85); }
    var _ud = stra_rand(_r); var _dev = floor(_ud * 4);
    var _ink = stra__shade(_m[2], -0.2);
    if (_dev == 0) {   // a six-pointed star
        var _sp = []; for (var _s = 0; _s < 12; _s++) { var _aa = _s / 12 * STRA_TAU - pi / 2, _rr = (_s mod 2 == 0) ? _R * 0.58 : _R * 0.26; array_push(_sp, [_cx + cos(_aa) * _rr, _cy + sin(_aa) * _rr]); }
        _c.fill = stra_cx_solid(_ink, 0.75); stra__poly(_c, _sp); stra_cx_fill(_c);
    } else if (_dev == 1) {   // a crescent and a dot
        stra__disc(_c, _cx - _R * 0.08, _cy, _R * 0.5, _ink, 0.75); stra__disc(_c, _cx + _R * 0.12, _cy - _R * 0.06, _R * 0.42, _m[1], 1); stra__disc(_c, _cx + _R * 0.3, _cy + _R * 0.05, _R * 0.1, _ink, 0.8);
    } else if (_dev == 2) {   // an owl's head, the classic tetradrachm
        stra__oval(_c, _cx, _cy + _R * 0.08, _R * 0.42, _R * 0.48, 0, _ink, 0.7);
        stra__disc(_c, _cx - _R * 0.17, _cy - _R * 0.04, _R * 0.15, _m[0], 0.9); stra__disc(_c, _cx + _R * 0.17, _cy - _R * 0.04, _R * 0.15, _m[0], 0.9);
        stra__disc(_c, _cx - _R * 0.17, _cy - _R * 0.04, _R * 0.06, _ink, 1); stra__disc(_c, _cx + _R * 0.17, _cy - _R * 0.04, _R * 0.06, _ink, 1);
    } else {   // a cross with wedge ends
        _c.fill = stra_cx_solid(_ink, 0.75); stra_cx_fill_rect(_c, _cx - _R * 0.09, _cy - _R * 0.55, _R * 0.18, _R * 1.1); stra_cx_fill_rect(_c, _cx - _R * 0.55, _cy - _R * 0.09, _R * 1.1, _R * 0.18);
    }
    // verdigris on bronze, tarnish on silver
    if (_m[0][2] < 120) { repeat (4) { var _v1 = stra_rand(_r); var _v2 = stra_rand(_r); stra__oval(_c, _cx + (_v1 - 0.5) * _R * 1.2, _cy + (_v2 - 0.5) * _R * 1.2, _R * 0.2, _R * 0.13, _v1 * 3, [92, 170, 140], 0.45); } }
    _c.stroke = stra_cx_solid([255, 255, 255], 0.55); _c.lw = 1.2; stra_cx_begin(_c); stra_cx_arc(_c, _cx, _cy, _R - 1.2, pi * 1.08, pi * 1.5); stra_cx_stroke(_c);
}

function stra__f_skull(_c, _W, _H, _r) {
    // a small reptile skull in side view, snout to the right: cranium, a big orbit, the opening before it, nostril, jaw, teeth
    var _bone = stra__pickc(_r, [[[236, 224, 196], [150, 126, 92]], [[176, 132, 92], [86, 58, 34]], [[180, 176, 168], [90, 88, 86]]]);
    var _x0 = _W * 0.06, _x1 = _W * 0.95, _yt = _H * 0.12, _yb = _H * 0.62, _yj = _H * 0.86;
    var _out = [];
    // the upper skull: a rounded cranium falling to a long snout
    for (var _i = 0; _i <= 20; _i++) {
        var _t = _i / 20, _x = _x0 + (_x1 - _x0) * _t;
        var _top = _yt + (_H * 0.3) * power(_t, 1.6) + ((_t < 0.25) ? (0.25 - _t) * _H * 0.5 : 0);
        array_push(_out, [_x, _top]);
    }
    array_push(_out, [_x1, _yb - _H * 0.06]);
    for (var _j = 20; _j >= 0; _j--) { var _t2 = _j / 20, _x2 = _x0 + (_x1 - _x0) * _t2; array_push(_out, [_x2, _yb + ((_t2 < 0.3) ? (0.3 - _t2) * _H * 0.25 : 0)]); }
    var _jaw = [[_x0 + _W * 0.12, _yb + 2], [_x1 - _W * 0.04, _yb + 1], [_x1 - _W * 0.08, _yb + _H * 0.1], [_x0 + _W * 0.35, _yj], [_x0 + _W * 0.14, _yj - _H * 0.04]];
    var _sh = []; for (var _q = 0; _q < array_length(_out); _q++) array_push(_sh, [_out[_q][0] + 3, _out[_q][1] + 4]);
    _c.fill = stra_cx_solid([0, 0, 0], 0.35); stra__poly(_c, _sh); stra_cx_fill(_c);
    var _gj = stra_cx_linear(_c, 0, _yb, 0, _yj); stra_cx_stop(_gj, 0, stra__shade(_bone[0], -0.08)); stra_cx_stop(_gj, 1, _bone[1]);
    _c.fill = _gj; stra__poly(_c, _jaw); stra_cx_fill(_c);
    _c.stroke = stra_cx_solid(stra__shade(_bone[1], -0.4), 0.9); _c.lw = 1; stra__poly(_c, _jaw); stra_cx_stroke(_c);
    var _g = stra_cx_linear(_c, 0, _yt, 0, _yb); stra_cx_stop(_g, 0, _bone[0]); stra_cx_stop(_g, 1, stra__shade(_bone[0], -0.22));
    _c.fill = _g; stra__poly(_c, _out); stra_cx_fill(_c);
    _c.stroke = stra_cx_solid(stra__shade(_bone[1], -0.4), 0.95); _c.lw = 1.2; stra__poly(_c, _out); stra_cx_stroke(_c);
    // teeth along the upper jaw
    var _ut = stra_rand(_r); var _nt = 7 + floor(_ut * 4);
    for (var _k = 0; _k < _nt; _k++) {
        var _tx = _x0 + _W * 0.3 + (_x1 - _x0 - _W * 0.32) * _k / (_nt - 1), _tl = _H * (0.07 + 0.03 * ((_k mod 3) == 1));
        _c.fill = stra_cx_solid([250, 244, 228], 0.95); stra__poly(_c, [[_tx - 2.2, _yb - 1], [_tx + 2.2, _yb - 1], [_tx + 0.6, _yb + _tl]]); stra_cx_fill(_c);
    }
    // openings: the orbit, the antorbital opening, the nostril, the temporal fenestra
    var _dark = stra__shade(_bone[1], -0.55);
    stra__oval(_c, _x0 + _W * 0.3, _yt + _H * 0.2, _W * 0.085, _H * 0.15, 0, _dark, 0.95);
    stra__oval(_c, _x0 + _W * 0.52, _yt + _H * 0.3, _W * 0.11, _H * 0.09, -0.2, _dark, 0.9);
    stra__oval(_c, _x1 - _W * 0.09, _yt + _H * 0.38, _W * 0.035, _H * 0.04, 0, _dark, 0.9);
    stra__oval(_c, _x0 + _W * 0.12, _yt + _H * 0.18, _W * 0.05, _H * 0.1, 0.3, _dark, 0.8);
    stra__line(_c, _x0 + _W * 0.08, _yt + _H * 0.05, _x1 - _W * 0.2, _yt + _H * 0.22, [255, 255, 255], 0.3, 1.2);
}

function stra__f_sherd(_c, _W, _H, _r) {
    // a broken pot: an angular fragment hugging the L footprint (the top two cells and the lower right), a painted band
    var _ware = stra__pickc(_r, [[[208, 124, 76], [24, 18, 16], [240, 170, 120]], [[236, 236, 230], [44, 72, 150], [255, 255, 255]], [[150, 172, 120], [60, 52, 40], [200, 220, 170]]]);
    var _pts = [[_W * 0.04, _H * 0.12], [_W * 0.28, _H * 0.04], [_W * 0.62, _H * 0.07], [_W * 0.94, _H * 0.03], [_W * 0.97, _H * 0.42], [_W * 0.93, _H * 0.95],
        [_W * 0.62, _H * 0.92], [_W * 0.54, _H * 0.55], [_W * 0.3, _H * 0.47], [_W * 0.06, _H * 0.43]];
    for (var _i = 0; _i < array_length(_pts); _i++) { var _u1 = stra_rand(_r); var _u2 = stra_rand(_r); _pts[_i] = [_pts[_i][0] + (_u1 - 0.5) * 5, _pts[_i][1] + (_u2 - 0.5) * 5]; }
    var _sh = []; for (var _j = 0; _j < array_length(_pts); _j++) array_push(_sh, [_pts[_j][0] + 3, _pts[_j][1] + 4]);
    _c.fill = stra_cx_solid([0, 0, 0], 0.35); stra__poly(_c, _sh); stra_cx_fill(_c);
    // the curve of the pot reads as a gradient across the fragment
    var _g = stra_cx_linear(_c, 0, 0, _W, 0); stra_cx_stop(_g, 0, stra__shade(_ware[0], -0.15)); stra_cx_stop(_g, 0.45, stra__shade(_ware[0], 0.1)); stra_cx_stop(_g, 1, stra__shade(_ware[0], -0.22));
    _c.fill = _g; stra__poly(_c, _pts); stra_cx_fill(_c);
    stra_cx_save(_c); stra__poly(_c, _pts); stra_cx_clip(_c);
    var _ud = stra_rand(_r); var _dec = floor(_ud * 3), _ink = _ware[1];
    var _by = _H * 0.16;
    _c.fill = stra_cx_solid(_ink, 0.9); stra_cx_fill_rect(_c, 0, _by, _W, 2.2); stra_cx_fill_rect(_c, 0, _by + 15, _W, 2.2);
    if (_dec == 0) {   // a meander (Greek key)
        _c.stroke = stra_cx_solid(_ink, 0.9); _c.lw = 1.8;
        for (var _x = -4; _x < _W; _x += 13) { stra_cx_begin(_c); stra_cx_move(_c, _x, _by + 12); stra_cx_line(_c, _x, _by + 5); stra_cx_line(_c, _x + 8, _by + 5); stra_cx_line(_c, _x + 8, _by + 10); stra_cx_line(_c, _x + 4, _by + 10); stra_cx_stroke(_c); }
    } else if (_dec == 1) {   // a running wave
        _c.stroke = stra_cx_solid(_ink, 0.9); _c.lw = 1.8;
        stra_cx_begin(_c); for (var _x2 = 0; _x2 <= _W; _x2 += 2) { var _yy = _by + 8.5 + sin(_x2 / 5) * 4; if (_x2 == 0) stra_cx_move(_c, _x2, _yy); else stra_cx_line(_c, _x2, _yy); } stra_cx_stroke(_c);
    } else {   // a chain of leaves
        for (var _x3 = 3; _x3 < _W; _x3 += 10) stra__oval(_c, _x3, _by + 8.5, 4, 2.2, 0.6, _ink, 0.85);
    }
    // a second, wider band lower on the body where the fragment reaches it
    _c.fill = stra_cx_solid(_ink, 0.85); stra_cx_fill_rect(_c, 0, _H * 0.62, _W, 3);
    var _us = stra_rand(_r);
    for (var _k = 0; _k < 5; _k++) stra__disc(_c, _W * 0.62 + _k * 6.5, _H * 0.72 + ((_k mod 2) ? 3 : 0), 1.6, _ink, 0.8);
    stra_cx_restore(_c);
    // the broken edges catch the light: a thin pale core line along the top breaks
    _c.stroke = stra_cx_solid(_ware[2], 0.7); _c.lw = 1.2;
    stra_cx_begin(_c); stra_cx_move(_c, _pts[0][0] + 1, _pts[0][1] + 1); stra_cx_line(_c, _pts[1][0], _pts[1][1] + 1); stra_cx_line(_c, _pts[2][0], _pts[2][1] + 1); stra_cx_line(_c, _pts[3][0] - 1, _pts[3][1] + 1); stra_cx_stroke(_c);
    _c.stroke = stra_cx_solid(stra__shade(_ware[0], -0.5), 0.9); _c.lw = 1; stra__poly(_c, _pts); stra_cx_stroke(_c);
}

/// @function stra_find_sprite(family, variant, size)
/// @description A find drawn into a new sprite `size` x `size` pixels (the find fitted and centred, transparent around
/// it) - for an inventory icon, a codex or a reward screen. YOU free it with sprite_delete. Call it from Create or Step,
/// never while one of your surfaces is the draw target. An unknown family -> -1.
/// @param {String} family    one of stra_families()
/// @param {Real} variant     any whole number (the same variant draws the same find; a find from a dig carries its own)
/// @param {Real} size        8 .. 1024 pixels
/// @returns {Real} a sprite, or -1
function stra_find_sprite(_fam, _variant, _size) {
    if (!stra__is_family(_fam)) return -1;
    var _sz = clamp(floor(stra__fin(_size, 64)), 8, 1024);
    var _fp = stra_footprint(_fam, false), _fw = 1, _fh = 1;
    for (var _i = 0; _i < array_length(_fp); _i++) { _fw = max(_fw, _fp[_i][0] + 1); _fh = max(_fh, _fp[_i][1] + 1); }
    var _W = _fw * STRA_CELL, _H = _fh * STRA_CELL;
    var _k = _sz * 0.9 / (max(_W, _H) + 8);
    var _mw = matrix_get(matrix_world); matrix_set(matrix_world, matrix_build_identity());
    var _s = surface_create(_sz, _sz);
    surface_set_target(_s); draw_clear_alpha(c_black, 0);
    var _c = stra_cx_create(1);
    stra_cx_translate(_c, (_sz - _W * _k) / 2, (_sz - _H * _k) / 2); stra_cx_scale(_c, _k, _k);
    stra_draw_find(_c, { family: _fam, rot: false, w: _fw, h: _fh, variant: floor(abs(stra__fin(_variant, 0))) });
    surface_reset_target();
    var _spr = sprite_create_from_surface(_s, 0, 0, _sz, _sz, false, false, _sz / 2, _sz / 2);
    surface_free(_s);
    matrix_set(matrix_world, _mw);
    return _spr;
}

// ---------------------------------------------------------------------------------------------------------------
// Frame, gauge, tools, backdrop
// ---------------------------------------------------------------------------------------------------------------

/// @function stra_draw_frame(ctx, x, y, w, h, seed)
/// @description The timbered frame round a face of w x h at (x, y): shoring posts and beams with grain, iron bolts, a
/// dark gap behind (the MZ drawFrame).
function stra_draw_frame(_c, _x, _y, _w, _h, _seed) {
    if (!stra__is_ctx(_c)) return;
    stra__blend_begin();
    var _r = stra_rng(real((stra__u32(_seed) ^ int64($77)) & int64($FFFFFFFF)));
    _c.fill = stra_cx_solid([0, 0, 0], 0.55); stra_cx_fill_rect(_c, _x - 10, _y - 10, _w + 26, _h + 28);
    var _beams = [[_x - 18, _y - 18, _w + 36, 16], [_x - 18, _y + _h + 2, _w + 36, 16], [_x - 18, _y - 2, 16, _h + 4], [_x + _w + 2, _y - 2, 16, _h + 4]];
    for (var _b = 0; _b < 4; _b++) {
        var _bx = _beams[_b][0], _by = _beams[_b][1], _bw = _beams[_b][2], _bh = _beams[_b][3];
        var _g = stra_cx_linear(_c, _bx, _by, _bx + _bw, _by + _bh); stra_cx_stop(_g, 0, [110, 74, 43]); stra_cx_stop(_g, 1, [61, 38, 22]);
        _c.fill = _g; stra_cx_fill_rect(_c, _bx, _by, _bw, _bh);
        _c.stroke = stra_cx_solid([0, 0, 0], 0.35); _c.lw = 1;
        for (var _i = 0; _i < 6; _i++) {
            var _u1 = stra_rand(_r); var _u2 = stra_rand(_r); var _u3 = stra_rand(_r);
            stra_cx_begin(_c);
            if (_bw > _bh) { var _yy = _by + _u1 * _bh; stra_cx_move(_c, _bx, _yy); stra_cx_line(_c, _bx + _bw, _yy + (_u3 - 0.5) * 3); }
            else { var _xx = _bx + _u2 * _bw; stra_cx_move(_c, _xx, _by); stra_cx_line(_c, _xx + (_u3 - 0.5) * 3, _by + _bh); }
            stra_cx_stroke(_c);
        }
        _c.stroke = stra_cx_solid([30, 18, 10]); stra_cx_begin(_c); stra_cx_rect(_c, _bx + 0.5, _by + 0.5, _bw - 1, _bh - 1); stra_cx_stroke(_c);
    }
    var _bolts = [[_x - 10, _y - 10], [_x + _w + 10, _y - 10], [_x - 10, _y + _h + 10], [_x + _w + 10, _y + _h + 10]];
    for (var _k = 0; _k < 4; _k++) { stra__disc(_c, _bolts[_k][0], _bolts[_k][1], 3, [138, 143, 150], 1); stra__disc(_c, _bolts[_k][0] - 0.8, _bolts[_k][1] - 0.8, 1, [230, 232, 236], 0.7); }
    stra__blend_end();
}

/// @function stra_draw_gauge(ctx, w, f, seed)
/// @description The stability gauge: a crack that runs along a plank w wide as the face weakens. f in 0..1 (stress over
/// stability); past 0.8 the crack burns red (the MZ drawStabilityCrack).
function stra_draw_gauge(_c, _w, _f, _seed) {
    if (!stra__is_ctx(_c)) return;
    stra__blend_begin();
    var _r = stra_rng(real((stra__u32(_seed) ^ int64($99)) & int64($FFFFFFFF)));
    var _g = stra_cx_linear(_c, 0, 0, 0, 22); stra_cx_stop(_g, 0, [122, 84, 51]); stra_cx_stop(_g, 1, [74, 49, 28]);
    _c.fill = _g; stra_cx_fill_rect(_c, 0, 2, _w, 22);
    _c.stroke = stra_cx_solid([30, 18, 10]); _c.lw = 1; stra_cx_begin(_c); stra_cx_rect(_c, 0.5, 2.5, _w - 1, 21); stra_cx_stroke(_c);
    var _e = _w * clamp(stra__fin(_f, 0), 0, 1);
    if (_e > 2) {
        _c.stroke = (_f > 0.8) ? stra_cx_solid([255, 90, 60]) : stra_cx_solid([20, 11, 5]); _c.lw = 2.2;
        stra_cx_begin(_c); stra_cx_move(_c, 0, 13);
        for (var _x = 6; _x <= _e; _x += 6) { var _u = stra_rand(_r); stra_cx_line(_c, _x, 13 + (_u - 0.5) * 12); }
        stra_cx_stroke(_c);
    }
    stra__blend_end();
}

/// @function stra_draw_tool(ctx, tool, s, active)
/// @description A tool glyph centred on the origin, radius s: "pick" or "hammer"; active draws it lit (the MZ drawTool).
function stra_draw_tool(_c, _tool, _s, _active) {
    if (!stra__is_ctx(_c)) return;
    stra__blend_begin();
    _s = stra__fin(_s, 26);
    stra_cx_save(_c);
    stra__disc(_c, 0, 0, _s, _active ? [255, 222, 150] : [0, 0, 0], 0.25);
    _c.stroke = _active ? stra_cx_solid([255, 227, 161]) : stra_cx_solid([140, 122, 93]); _c.lw = _active ? 2.4 : 1.4;
    stra_cx_begin(_c); stra_cx_arc(_c, 0, 0, _s, 0, STRA_TAU); stra_cx_stroke(_c);
    stra_cx_rotate(_c, -0.6);
    _c.fill = stra_cx_solid([122, 81, 48]); stra_cx_fill_rect(_c, -2.5, -_s * 0.2, 5, _s * 0.95);
    var _st = stra_cx_linear(_c, 0, -_s * 0.6, 0, -_s * 0.2); stra_cx_stop(_st, 0, [230, 235, 240]); stra_cx_stop(_st, 1, [110, 120, 132]);
    _c.fill = _st;
    if (_tool == "pick") { stra_cx_begin(_c); stra_cx_move(_c, -_s * 0.75, -_s * 0.2); stra_cx_quad(_c, 0, -_s * 0.62, _s * 0.75, -_s * 0.2); stra_cx_quad(_c, 0, -_s * 0.42, -_s * 0.75, -_s * 0.2); stra_cx_close(_c); stra_cx_fill(_c); }
    else stra_cx_fill_rect(_c, -_s * 0.42, -_s * 0.52, _s * 0.84, _s * 0.34);
    stra_cx_restore(_c);
    stra__blend_end();
}

/// @function stra_draw_backdrop(ctx, w, h)
/// @description The cave behind everything: dark rock under a warm lantern falloff (the MZ drawBackdrop).
function stra_draw_backdrop(_c, _w, _h) {
    if (!stra__is_ctx(_c)) return;
    stra__blend_begin();
    var _g = stra_cx_radial(_c, _w / 2, _h * 0.45, 40, _w / 2, _h / 2, _w * 0.75); stra_cx_stop(_g, 0, [59, 43, 32]); stra_cx_stop(_g, 0.6, [28, 20, 14]); stra_cx_stop(_g, 1, [7, 5, 4]);
    _c.fill = _g; stra_cx_fill_rect(_c, 0, 0, _w, _h);
    stra__blend_end();
    // the speckle is drawn natively (1,600 marks): the MZ edition's texture, at a fraction of the kit's cost
    var _r = stra_rng($CAFE), _m = _c.m;
    for (var _i = 0; _i < 1600; _i++) {
        var _u0 = stra_rand(_r); var _u1 = stra_rand(_r); var _u2 = stra_rand(_r); var _u3 = stra_rand(_r); var _u4 = stra_rand(_r);
        draw_set_colour((_u0 < 0.5) ? make_colour_rgb(255, 220, 180) : c_black); draw_set_alpha((_u0 < 0.5) ? 0.03 : 0.12);
        var _x = _u1 * _w, _y = _u2 * _h;
        draw_rectangle(_m[0] * _x + _m[4], _m[3] * _y + _m[5], _m[0] * (_x + 1 + _u3 * 3) + _m[4] - 1, _m[3] * (_y + 1 + _u4 * 2) + _m[5] - 1, false);
    }
    draw_set_alpha(1); draw_set_colour(c_white);
}
