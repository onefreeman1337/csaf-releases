/// stra_demo.gml - THE FIELD CAMP, Strata's demo room: eight rock faces to work, one of each rock, each a test pit with
/// something showing in it. Choose a rock and a grade, then dig. Whatever you free goes into the camp's collection.
///
/// Strata - Generated Excavation Digs for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// Every dig opened here is a NEW site (the seed counts the visits to that rock), so the camp never runs out. Your game
/// keys its own digs: a word per place (stra_open's `seed`), and the finds as YOUR item names.
///
/// Four calls, the same shape as the scene's own (obj_stra_demo shows them):
///   Create: demo = stra_demo_create();   Step: stra_demo_step(demo);   Draw GUI: stra_demo_draw(demo);   Clean Up: stra_demo_free(demo);
/// Public functions (each documented below): stra_demo_create, stra_demo_step, stra_demo_draw, stra_demo_free,
/// stra_demo_pits, stra_demo_grades.

#macro STRA_DEMO_CARD_W 168
#macro STRA_DEMO_CARD_H 120
#macro STRA_DEMO_GAP 18
#macro STRA_DEMO_ROW0 112
#macro STRA_DEMO_ROW1 284
#macro STRA_DEMO_GRADE_Y 452
#macro STRA_DEMO_TRAY_Y 506

/// @function stra_demo_pits()
/// @description The camp's eight test pits: [{ rock, find, title }] - one of each rock, and the family of the find
/// showing in its pit. Pure.
/// @returns {Array<Struct>}
function stra_demo_pits() {
    return [{ rock: "sandstone", find: "bone", title: "Sandstone" }, { rock: "shale", find: "trilobite", title: "Shale" },
        { rock: "limestone", find: "ammonite", title: "Limestone" }, { rock: "clay", find: "sherd", title: "Clay" },
        { rock: "basalt", find: "crystal", title: "Basalt" }, { rock: "chalk", find: "point", title: "Chalk" },
        { rock: "ironstone", find: "ore", title: "Ironstone" }, { rock: "permafrost", find: "tooth", title: "Permafrost" }];
}

/// @function stra_demo_grades()
/// @description The five grades as the camp names them: [{ grade, name }]. Pure.
/// @returns {Array<Struct>}
function stra_demo_grades() {
    return [{ grade: 1, name: "Gentle" }, { grade: 2, name: "Easy" }, { grade: 3, name: "Fair" }, { grade: 4, name: "Hard" }, { grade: 5, name: "Severe" }];
}

function stra__demo_card_x(_i) { return (STRA_SCENE_W - (4 * STRA_DEMO_CARD_W + 3 * STRA_DEMO_GAP)) / 2 + (_i mod 4) * (STRA_DEMO_CARD_W + STRA_DEMO_GAP); }
function stra__demo_card_y(_i) { return (_i < 4) ? STRA_DEMO_ROW0 : STRA_DEMO_ROW1; }
function stra__demo_grade_x(_g) { return STRA_SCENE_W / 2 - 330 + _g * 134; }

/// internal: draw with the painter `_fn(ctx, args)` into a fresh w x h sprite (premultiplied; draw with bm_one, inv_src_alpha)
function stra__demo_bake(_w, _h, _fn, _args) {
    var _mw = matrix_get(matrix_world); matrix_set(matrix_world, matrix_build_identity());
    var _s = surface_create(_w, _h);
    surface_set_target(_s); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    _fn(stra_cx_create(1), _args);
    gpu_pop_state(); surface_reset_target();
    var _spr = sprite_create_from_surface(_s, 0, 0, _w, _h, false, false, 0, 0);
    surface_free(_s);
    matrix_set(matrix_world, _mw);
    return _spr;
}

function stra__pnt_demo_bg(_c, _a) {
    stra_draw_backdrop(_c, STRA_SCENE_W, STRA_SCENE_H);
    stra__blend_begin();
    // a duckboard floor under the trays
    _c.fill = stra_cx_solid([0, 0, 0], 0.4); stra_cx_fill_rect(_c, 0, STRA_DEMO_TRAY_Y - 12, STRA_SCENE_W, STRA_SCENE_H - STRA_DEMO_TRAY_Y + 12);
    _c.fill = stra_cx_solid([122, 84, 51], 0.9); stra_cx_fill_rect(_c, 0, STRA_DEMO_TRAY_Y - 14, STRA_SCENE_W, 3);
    stra__text(_c, "Strata", STRA_SCENE_W / 2 + 1, 47, 44, [0, 0, 0], 0.6, "center", STRA_FACE_DISPLAY);
    stra__text(_c, "Strata", STRA_SCENE_W / 2, 46, 44, [251, 231, 192], 1, "center", STRA_FACE_DISPLAY);
    stra__text(_c, "The Field Camp: eight rock faces, something buried in every one. Free it before the face gives way.", STRA_SCENE_W / 2, 84, 15, [214, 186, 140], 1, "center", STRA_FACE_BODY);
    stra__text(_c, "Arrows choose a pit, 1 to 5 the grade, Enter digs. Or click. Every visit opens a new site.", STRA_SCENE_W / 2, 596, 13, [184, 154, 112], 1, "center", STRA_FACE_BODY);
    stra__text(_c, "Your game keys a dig to a place with a word, and names the finds after its own items.", STRA_SCENE_W / 2, 613, 12, [140, 116, 88], 1, "center", STRA_FACE_BODY);
    stra__blend_end();
}

/// the pit of a card: the rock's six layers cut back in steps (the outer face at the top), the grain over them, and the
/// pit's find lying half-freed in the lowest step. Baked once per card.
function stra__pnt_demo_pit(_c, _a) {
    var _W = STRA_DEMO_CARD_W - 20, _H = STRA_DEMO_CARD_H - 20, _pit = _a.pit, _seed = stra_hash_string("camp-" + _pit.rock);
    // each layer from its own sheet (stra__layer_sheet clears its target, so it is drawn alone and copied in)
    var _band = _H / 6, _tmp = surface_create(_W, _H), _prev = surface_get_target();
    for (var _L = 0; _L < 6; _L++) {
        surface_reset_target();
        surface_set_target(_tmp); stra__blend_begin(); stra__layer_sheet(_pit.rock, _seed, _L, _W, _H, 1); stra__blend_end(); surface_reset_target();
        surface_set_target(_prev);
        // the steps: each lower layer is set in a little further from the left, so the cut reads as terraces
        var _x0 = _L * 7, _y0 = floor(_L * _band);
        gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_zero);
        draw_surface_part(_tmp, _x0, _y0, _W - _x0, ceil(_band) + 1, _x0, _y0);
        gpu_pop_state();
        if (_L > 0) {
            stra__blend_begin();
            _c.fill = stra_cx_solid([0, 0, 0], 0.42); stra_cx_fill_rect(_c, _x0, _y0, _W - _x0, 3);
            _c.fill = stra_cx_solid([255, 240, 215], 0.22); stra_cx_fill_rect(_c, _x0, _y0 - 1, _W - _x0, 1);
            _c.fill = stra_cx_solid([0, 0, 0], 0.32); stra_cx_fill_rect(_c, _x0, _y0, 3, _H - _y0);
            stra__blend_end();
        }
    }
    surface_free(_tmp);
    // the step faces left of each terrace show the bed
    stra__blend_begin();
    var _P = stra__rock(_pit.rock);
    for (var _L2 = 1; _L2 < 6; _L2++) { _c.fill = stra_cx_solid(stra__shade(_P.under, 0.1 + _L2 * 0.02)); stra_cx_fill_rect(_c, (_L2 - 1) * 7, floor(_L2 * _band), 7, _H - floor(_L2 * _band)); }
    stra__blend_end();
    // the find, lying in the bottom right of the pit, at its own drawing (no box)
    var _fp = stra_footprint(_pit.find, false), _fw = 1, _fh = 1;
    for (var _i = 0; _i < array_length(_fp); _i++) { _fw = max(_fw, _fp[_i][0] + 1); _fh = max(_fh, _fp[_i][1] + 1); }
    var _k = min((_W * 0.42) / (_fw * STRA_CELL), (_H * 0.5) / (_fh * STRA_CELL));
    stra_cx_save(_c); stra_cx_translate(_c, _W - _fw * STRA_CELL * _k - 8, _H - _fh * STRA_CELL * _k - 6); stra_cx_scale(_c, _k, _k);
    stra_draw_find(_c, { family: _pit.find, rot: false, w: _fw, h: _fh, variant: _seed mod 1000000 });
    stra_cx_restore(_c);
}

function stra__pnt_demo_card(_c, _a) {
    var _W = STRA_DEMO_CARD_W, _H = STRA_DEMO_CARD_H;
    _c.fill = stra_cx_solid([0, 0, 0], 0.5); stra_cx_fill_rect(_c, 5, 7, _W, _H);
    // shoring timbers round the pit: posts and a header beam with grain, bolted
    var _g = stra_cx_linear(_c, 0, 0, _W, _H); stra_cx_stop(_g, 0, [124, 86, 50]); stra_cx_stop(_g, 1, [64, 40, 23]);
    _c.fill = _g; stra_cx_fill_rect(_c, 0, 0, _W, _H);
    _c.stroke = stra_cx_solid([0, 0, 0], 0.3); _c.lw = 1;
    var _r = stra_rng(stra_hash_string(_a.pit.rock + "-timber"));
    for (var _i = 0; _i < 7; _i++) { var _u = stra_rand(_r); stra_cx_begin(_c); stra_cx_move(_c, 0, 2 + _u * 6); stra_cx_line(_c, _W, 3 + _u * 6); stra_cx_stroke(_c); }
    for (var _j = 0; _j < 5; _j++) { var _v = stra_rand(_r); stra_cx_begin(_c); stra_cx_move(_c, 2 + _v * 6, 10); stra_cx_line(_c, 3 + _v * 6, _H); stra_cx_stroke(_c); stra_cx_begin(_c); stra_cx_move(_c, _W - 9 + _v * 6, 10); stra_cx_line(_c, _W - 8 + _v * 6, _H); stra_cx_stroke(_c); }
    _c.fill = stra_cx_solid([20, 12, 7]); stra_cx_fill_rect(_c, 9, 9, _W - 18, _H - 18);
    _c.stroke = stra_cx_solid([30, 18, 10]); stra_cx_begin(_c); stra_cx_rect(_c, 0.5, 0.5, _W - 1, _H - 1); stra_cx_stroke(_c);
    var _bolts = [[5, 5], [_W - 5, 5], [5, _H - 5], [_W - 5, _H - 5]];
    for (var _b = 0; _b < 4; _b++) { stra__disc(_c, _bolts[_b][0], _bolts[_b][1], 2.6, [138, 143, 150], 1); stra__disc(_c, _bolts[_b][0] - 0.7, _bolts[_b][1] - 0.7, 0.9, [230, 232, 236], 0.7); }
    if (sprite_exists(_a.win)) { gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); draw_sprite(_a.win, 0, 10, 10); gpu_pop_state(); }
    // the plate under the card: the rock, and how many digs it has had
    _c.fill = stra_cx_solid([28, 18, 12], 0.92); stra_cx_fill_rect(_c, _W / 2 - 66, _H + 6, 132, 22);
    _c.stroke = stra_cx_solid([196, 150, 72], 0.9); _c.lw = 1; stra_cx_begin(_c); stra_cx_rect(_c, _W / 2 - 65.5, _H + 6.5, 131, 21); stra_cx_stroke(_c);
    var _lab = _a.pit.title + ((_a.digs > 0) ? ("  (" + string(_a.digs) + ")") : "");
    stra__text_fit(_c, _lab, _W / 2, _H + 17, 13, [243, 220, 160], 1, "center", STRA_FACE_DISPLAY, 124);
}

function stra__pnt_demo_pick(_c, _a) {
    _c.stroke = stra_cx_solid([30, 16, 4], 0.8); _c.lw = 6; stra_cx_begin(_c); stra_cx_rect(_c, 4, 4, STRA_DEMO_CARD_W + 8, STRA_DEMO_CARD_H + 8); stra_cx_stroke(_c);
    _c.stroke = stra_cx_solid([255, 231, 168], 0.95); _c.lw = 2.5; stra_cx_begin(_c); stra_cx_rect(_c, 4, 4, STRA_DEMO_CARD_W + 8, STRA_DEMO_CARD_H + 8); stra_cx_stroke(_c);
}

function stra__pnt_demo_grades(_c, _a) {
    var _G = stra_demo_grades();
    for (var _g = 0; _g < 5; _g++) {
        var _x = 10 + _g * 134, _on = (_g == _a.grade);
        _c.fill = _on ? stra_cx_solid([200, 150, 80]) : stra_cx_solid([46, 32, 22]); stra__rrect(_c, _x, 6, 122, 34, 10); stra_cx_fill(_c);
        _c.stroke = _on ? stra_cx_solid([255, 231, 168]) : stra_cx_solid([120, 90, 52]); _c.lw = 1.5; stra__rrect(_c, _x + 0.5, 6.5, 121, 33, 10); stra_cx_stroke(_c);
        stra__text(_c, string(_g + 1) + "  " + _G[_g].name, _x + 61, 23, 15, _on ? [36, 22, 8] : [214, 186, 140], 1, "center", STRA_FACE_BODY);
    }
}

function stra__pnt_demo_tray(_c, _a) {
    var _D = _a.D, _n = array_length(_D.collection);
    _c.fill = stra_cx_solid([0, 0, 0], 0.35); stra_cx_fill_rect(_c, 0, 0, 660, 70);
    _c.stroke = stra_cx_solid([150, 112, 66], 0.7); _c.lw = 1; stra_cx_begin(_c); stra_cx_rect(_c, 0.5, 0.5, 659, 69); stra_cx_stroke(_c);
    if (_n == 0) { stra__text(_c, "Nothing yet. What you free goes here.", 330, 35, 15, [184, 154, 112], 1, "center", STRA_FACE_BODY); return; }
    var _show = min(_n, 12), _x0 = 8;
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    for (var _i = 0; _i < _show; _i++) { var _spr = _D.colSpr[_n - _show + _i]; if (sprite_exists(_spr)) draw_sprite_ext(_spr, 0, _x0 + _i * 54 + 26, 35, 1, 1, 0, c_white, 1); }
    gpu_pop_state();
}

function stra__pnt_demo_note(_c, _a) {
    var _D = _a.D, _n = array_length(_D.collection), _r = _D.lastResult;
    stra__text_fit(_c, "THE COLLECTION", 4, 8, 11, [214, 186, 140], 1, "left", STRA_FACE_DISPLAY, 116);
    stra__text(_c, string(_n) + ((_n == 1) ? " find" : " finds") + ", " + string(_D.digs) + ((_D.digs == 1) ? " dig" : " digs"), 4, 30, 15, [251, 231, 192], 1, "left", STRA_FACE_BODY);
    if (is_struct(_r)) {
        var _how = _r.cleared ? "cleared" : (_r.left ? "packed up" : (_r.collapsed ? "gave way" : "done"));
        stra__text_fit(_c, "last: " + string(_r.found) + " of " + string(_r.total) + ", " + _how, 4, 54, 12, _r.cleared ? [200, 245, 166] : (_r.collapsed ? [255, 156, 134] : [214, 186, 140]), 1, "left", STRA_FACE_BODY, 116);
    }
}

function stra__pnt_demo_wait(_c, _a) {
    _c.fill = stra_cx_solid([0, 0, 0], 0.55); stra__rrect(_c, 6, 6, 420, 116, 14); stra_cx_fill(_c);
    _c.fill = stra_cx_solid([30, 20, 13], 0.95); stra__rrect(_c, 0, 0, 420, 116, 14); stra_cx_fill(_c);
    _c.stroke = stra_cx_solid([200, 150, 80], 0.9); _c.lw = 2; stra__rrect(_c, 6, 6, 408, 104, 10); stra_cx_stroke(_c);
    stra__text(_c, "Surveying the face", 210, 48, 26, [251, 231, 192], 1, "center", STRA_FACE_DISPLAY);
    stra__text(_c, "laying out the site and what lies under it", 210, 80, 15, [200, 172, 130], 1, "center", STRA_FACE_BODY);
}

/// @function stra_demo_create()
/// @description Open THE FIELD CAMP. Returns the demo (a struct); draw it with stra_demo_draw, free it with stra_demo_free.
/// The camp is 816 x 624 and is scaled to fit the GUI.
/// @returns {Struct}
function stra_demo_create() {
    var _D = { pits: stra_demo_pits(), pick: 2, grade: 1, scene: undefined, visits: array_create(8, 0), digs: 0,
        collection: [], colSpr: [], bg: -1, cardSpr: array_create(8, -1), pickSpr: -1, gradeSpr: -1, waitSpr: -1, traySpr: -1, noteSpr: -1,
        pending: -1, waitAge: 0, x: 0, y: 0, scale: 1, lastResult: undefined, inject: undefined, held: { left: 0, right: 0, up: 0, down: 0 } };
    _D.bg = stra__demo_bake(STRA_SCENE_W, STRA_SCENE_H, stra__pnt_demo_bg, {});
    for (var _i = 0; _i < 8; _i++) stra__demo_card_bake(_D, _i);
    _D.pickSpr = stra__demo_bake(STRA_DEMO_CARD_W + 12, STRA_DEMO_CARD_H + 12, stra__pnt_demo_pick, {});
    _D.waitSpr = stra__demo_bake(430, 126, stra__pnt_demo_wait, {});
    stra__demo_grades_bake(_D);
    stra__demo_tray_bake(_D);
    return _D;
}
function stra__demo_card_bake(_D, _i) {
    var _win = stra__demo_bake(STRA_DEMO_CARD_W - 20, STRA_DEMO_CARD_H - 20, stra__pnt_demo_pit, { pit: _D.pits[_i] });
    _D.cardSpr[_i] = stra__kill(_D.cardSpr[_i]);
    _D.cardSpr[_i] = stra__demo_bake(STRA_DEMO_CARD_W + 8, STRA_DEMO_CARD_H + 32, stra__pnt_demo_card, { pit: _D.pits[_i], win: _win, digs: _D.visits[_i] });
    stra__kill(_win);   // only after the card's bake has set and reset its target, which flushes the draw that used it
}
function stra__demo_grades_bake(_D) { _D.gradeSpr = stra__kill(_D.gradeSpr); _D.gradeSpr = stra__demo_bake(690, 46, stra__pnt_demo_grades, { grade: _D.grade }); }
function stra__demo_tray_bake(_D) {
    _D.traySpr = stra__kill(_D.traySpr); _D.traySpr = stra__demo_bake(660, 70, stra__pnt_demo_tray, { D: _D });
    _D.noteSpr = stra__kill(_D.noteSpr); _D.noteSpr = stra__demo_bake(124, 70, stra__pnt_demo_note, { D: _D });
}
/// internal: one held key as a press that repeats (first after 14 steps, then every 5)
function stra__demo_repeat(_D, _k, _down) {
    if (!_down) { _D.held[$ _k] = 0; return false; }
    _D.held[$ _k] += 1; var _n = _D.held[$ _k];
    return _n == 1 || (_n > 14 && ((_n - 14) mod 5) == 0);
}
function stra__demo_open(_D, _i) {
    var _pit = _D.pits[_i];
    _D.visits[_i]++;
    _D.scene = stra_open({ seed: "camp-" + _pit.rock + "-" + string(_D.grade + 1) + "-" + string(_D.visits[_i]), grade: _D.grade + 1, rock: _pit.rock,
        detail: (_D.scale >= 1.5) ? 2 : 1 });
    stra__demo_card_bake(_D, _i);
}

/// @function stra_demo_step(demo)
/// @description Run the camp (or the open dig) for one step. Call it in Step. For tests and attract modes set demo.inject
/// for one step: in the camp { left, right, up, down, ok, grade (0..4), x, y, click } (camp coordinates); inside a dig it is
/// handed to the scene as scene.inject.
function stra_demo_step(_D) {
    if (!is_struct(_D)) return;
    _D.scale = max(0.1, min(display_get_gui_width() / STRA_SCENE_W, display_get_gui_height() / STRA_SCENE_H));
    _D.x = (display_get_gui_width() - STRA_SCENE_W * _D.scale) / 2; _D.y = (display_get_gui_height() - STRA_SCENE_H * _D.scale) / 2;
    if (is_struct(_D.scene)) {
        if (is_struct(_D.inject)) { _D.scene.inject = _D.inject; _D.inject = undefined; }
        stra_step(_D.scene, device_mouse_x_to_gui(0), device_mouse_y_to_gui(0));
        if (stra_closed(_D.scene)) {
            var _r = stra_result(_D.scene);
            _D.lastResult = _r; _D.digs++;
            if (is_struct(_r)) for (var _f = 0; _f < array_length(_r.freed); _f++) {
                var _F = _D.scene.site.finds[_r.freed[_f]];
                array_push(_D.collection, { family: _F.family, variant: _F.variant, rock: _r.rock });
                array_push(_D.colSpr, stra_find_sprite(_F.family, _F.variant, 46));
            }
            stra_free(_D.scene); _D.scene = undefined;
            stra__demo_tray_bake(_D);
        }
        return;
    }
    // a choice made last step opens now, behind the wait card drawn in between
    if (_D.pending >= 0) { _D.waitAge++; if (_D.waitAge >= 2) { var _pk = _D.pending; _D.pending = -1; stra__demo_open(_D, _pk); } return; }
    var _mx = (device_mouse_x_to_gui(0) - _D.x) / _D.scale, _my = (device_mouse_y_to_gui(0) - _D.y) / _D.scale;
    var _gk = -1;
    for (var _q = 0; _q < 5; _q++) if (keyboard_check_pressed(ord(string(_q + 1)))) _gk = _q;
    var _in = { x: _mx, y: _my, click: mouse_check_button_pressed(mb_left), ok: keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space),
        left: keyboard_check(vk_left), right: keyboard_check(vk_right), up: keyboard_check(vk_up), down: keyboard_check(vk_down), grade: _gk };
    if (is_struct(_D.inject)) {
        var _fl = ["x", "y", "click", "ok", "left", "right", "up", "down", "grade"];
        for (var _k = 0; _k < 9; _k++) { var _v = _D.inject[$ _fl[_k]]; _in[$ _fl[_k]] = is_undefined(_v) ? ((_k < 2) ? -1000 : ((_k == 8) ? -1 : false)) : _v; }
        _D.inject = undefined;
    }
    if (stra__demo_repeat(_D, "left", _in.left)) _D.pick = (_D.pick + 7) mod 8;
    if (stra__demo_repeat(_D, "right", _in.right)) _D.pick = (_D.pick + 1) mod 8;
    var _rowUp = stra__demo_repeat(_D, "up", _in.up), _rowDown = stra__demo_repeat(_D, "down", _in.down);   // both counters advance every step
    if (_rowUp || _rowDown) _D.pick = (_D.pick + 4) mod 8;
    if (is_numeric(_in.grade) && _in.grade >= 0 && _in.grade <= 4 && floor(_in.grade) != _D.grade) { _D.grade = floor(_in.grade); stra__demo_grades_bake(_D); }
    if (_in.click) {
        for (var _c = 0; _c < 8; _c++) if (_in.x >= stra__demo_card_x(_c) && _in.x < stra__demo_card_x(_c) + STRA_DEMO_CARD_W && _in.y >= stra__demo_card_y(_c) && _in.y < stra__demo_card_y(_c) + STRA_DEMO_CARD_H) { _D.pick = _c; _D.pending = _c; _D.waitAge = 0; return; }
        for (var _g = 0; _g < 5; _g++) if (_in.x >= stra__demo_grade_x(_g) && _in.x < stra__demo_grade_x(_g) + 122 && _in.y >= STRA_DEMO_GRADE_Y && _in.y < STRA_DEMO_GRADE_Y + 34 && _g != _D.grade) { _D.grade = _g; stra__demo_grades_bake(_D); }
    }
    if (_in.ok) { _D.pending = _D.pick; _D.waitAge = 0; }
}

/// @function stra_demo_draw(demo)
/// @description Draw the camp, or the open dig, scaled to fit the GUI. Call it in Draw GUI.
function stra_demo_draw(_D) {
    if (!is_struct(_D)) return;
    if (is_struct(_D.scene)) { stra_draw(_D.scene, _D.x, _D.y, _D.scale); return; }
    var _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_multiply(matrix_build(_D.x, _D.y, 0, 0, 0, 0, _D.scale, _D.scale, 1), _mw));
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); gpu_set_texfilter(true);
    if (sprite_exists(_D.bg)) draw_sprite(_D.bg, 0, 0, 0);
    for (var _i = 0; _i < 8; _i++) if (sprite_exists(_D.cardSpr[_i])) draw_sprite(_D.cardSpr[_i], 0, stra__demo_card_x(_i), stra__demo_card_y(_i));
    var _pa = 0.75 + 0.25 * sin(current_time / 260);
    if (sprite_exists(_D.pickSpr)) draw_sprite_ext(_D.pickSpr, 0, stra__demo_card_x(_D.pick) - 8, stra__demo_card_y(_D.pick) - 8, 1, 1, 0, make_colour_rgb(255 * _pa, 255 * _pa, 255 * _pa), _pa);
    if (sprite_exists(_D.gradeSpr)) draw_sprite(_D.gradeSpr, 0, stra__demo_grade_x(0) - 10, STRA_DEMO_GRADE_Y - 6);
    if (sprite_exists(_D.traySpr)) draw_sprite(_D.traySpr, 0, 144, STRA_DEMO_TRAY_Y - 6);
    if (sprite_exists(_D.noteSpr)) draw_sprite(_D.noteSpr, 0, 14, STRA_DEMO_TRAY_Y + 12);
    if (_D.pending >= 0 && sprite_exists(_D.waitSpr)) draw_sprite(_D.waitSpr, 0, STRA_SCENE_W / 2 - 215, STRA_SCENE_H / 2 - 63);
    gpu_pop_state();
    matrix_set(matrix_world, _mw);
}

/// @function stra_demo_free(demo)
/// @description Free every sprite the camp and its open dig made. Safe when Create left early (-selftest) and twice.
function stra_demo_free(_D) {
    if (!is_struct(_D)) return;
    if (is_struct(_D[$ "scene"])) stra_free(_D.scene);
    _D.scene = undefined;
    _D.bg = stra__kill(_D[$ "bg"]); _D.pickSpr = stra__kill(_D[$ "pickSpr"]); _D.waitSpr = stra__kill(_D[$ "waitSpr"]); _D.gradeSpr = stra__kill(_D[$ "gradeSpr"]);
    _D.traySpr = stra__kill(_D[$ "traySpr"]); _D.noteSpr = stra__kill(_D[$ "noteSpr"]);
    if (is_array(_D[$ "cardSpr"])) for (var _i = 0; _i < array_length(_D.cardSpr); _i++) _D.cardSpr[_i] = stra__kill(_D.cardSpr[_i]);
    if (is_array(_D[$ "colSpr"])) for (var _j = 0; _j < array_length(_D.colSpr); _j++) _D.colSpr[_j] = stra__kill(_D.colSpr[_j]);
}
