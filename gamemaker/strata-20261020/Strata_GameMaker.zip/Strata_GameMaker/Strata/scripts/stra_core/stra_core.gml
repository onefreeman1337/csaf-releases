/// stra_core.gml - Strata's rules: generated excavation digs and their fair stability budgets. Pure GML: nothing here
/// draws, and nothing uses the engine's random functions.
///
/// Strata - Generated Excavation Digs for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// The RPG Maker MZ edition's StrataCore.js, ported line for line and held to it by the in-engine suite (stra_selftest,
/// against stra_oracle_core). This edition's tables are larger - 16 find families (the MZ ten plus fern, fish, point,
/// coin, skull and sherd) and 8 rocks (plus chalk, ironstone and permafrost) - and the oracle runs the MZ code over the
/// same tables, so every rule below is the MZ rule.
///
/// How a dig works
///   A face of 13 x 10 cells. Every cell holds 2 to 6 layers of rock; somewhere under it lie 2 to 4 finds, each a
///   footprint of cells (an ammonite is 3 x 3, a coin is one cell). Bedrock stones cannot be cut. Each blow removes
///   layers - the pick 2 at the target and 1 beside it, the hammer 2 at the target and beside it and 1 on the diagonals -
///   and adds stress: 2 for the pick, 4 for the hammer. A find is FREE when every cell over it is cleared. When stress
///   reaches the site's stability the face collapses. A find freed by the blow that brings it down still counts.
///   Stability is derived per site: never below what a greedy digger who knows where everything is spends (x 1.15 + 2),
///   and set at a quantile of 24 seeded runs of a SIGHTED digger who does not - so the grade decides how forgiving it is,
///   and every site is proven clearable.
///
/// Public functions (each documented below): stra_families, stra_sites, stra_tools, stra_footprint, stra_hash_string,
/// stra_rng, stra_rand, stra_generate, stra_is_site, stra_start, stra_strike, stra_freed_list, stra_find_at,
/// stra_greedy_plan, stra_prospect, stra_replay, stra_family_for.

#macro STRA_VERSION "1.0.0"
#macro STRA_COLS 13
#macro STRA_ROWS 10
#macro STRA_PROSPECT_RUNS 24

// ---------------------------------------------------------------------------------------------------------------
// Tables
// ---------------------------------------------------------------------------------------------------------------

/// @function stra__tables()
/// @description Internal. The family footprints (cells as [col, row]; `rot` = may be laid a quarter turn), the tools,
/// the grades. Built once.
function stra__tables() {
    static _t = undefined;
    if (!is_undefined(_t)) return _t;
    var _fam = {
        ammonite: { cells: [[0, 0], [1, 0], [2, 0], [0, 1], [1, 1], [2, 1], [0, 2], [1, 2], [2, 2]], rot: false },
        trilobite: { cells: [[0, 0], [1, 0], [0, 1], [1, 1], [0, 2], [1, 2]], rot: true },
        bone: { cells: [[0, 0], [1, 0], [2, 0], [3, 0]], rot: true },
        tooth: { cells: [[0, 0], [0, 1]], rot: true },
        amber: { cells: [[0, 0], [1, 0], [0, 1], [1, 1]], rot: false },
        geode: { cells: [[0, 0], [1, 0], [0, 1], [1, 1]], rot: false },
        ore: { cells: [[0, 0], [1, 0], [2, 0], [1, 1], [2, 1]], rot: true },
        crystal: { cells: [[1, 0], [0, 1], [1, 1], [1, 2]], rot: true },
        tablet: { cells: [[0, 0], [1, 0], [0, 1], [1, 1], [0, 2], [1, 2]], rot: true },
        shell: { cells: [[0, 0], [1, 0], [0, 1], [1, 1]], rot: false },
        fern: { cells: [[0, 0], [1, 0], [0, 1], [1, 1], [0, 2], [1, 2]], rot: true },
        fish: { cells: [[0, 0], [1, 0], [2, 0], [3, 0], [0, 1], [1, 1], [2, 1], [3, 1]], rot: true },
        point: { cells: [[0, 0], [0, 1], [0, 2]], rot: true },
        coin: { cells: [[0, 0]], rot: false },
        skull: { cells: [[0, 0], [1, 0], [2, 0], [0, 1], [1, 1], [2, 1]], rot: false },
        sherd: { cells: [[0, 0], [1, 0], [1, 1]], rot: true }
    };
    _t = {
        fam: _fam,
        ids: ["ammonite", "trilobite", "bone", "tooth", "amber", "geode", "ore", "crystal", "tablet", "shell", "fern", "fish", "point", "coin", "skull", "sherd"],
        sites: ["sandstone", "shale", "limestone", "clay", "basalt", "chalk", "ironstone", "permafrost"],
        tools: { pick: { center: 2, ortho: 1, diag: 0, stress: 2 }, hammer: { center: 2, ortho: 2, diag: 1, stress: 4 } },
        toolIds: ["pick", "hammer"],
        // finds [lo, hi], bedrock stones [lo, hi], depth [lo, hi], slack over the greedy plan, quantile of the sighted digger
        grades: [undefined,
            { finds: [2, 2], rocks: [1, 2], depth: [2, 4], slack: 1.15, q: 0.9 },
            { finds: [2, 3], rocks: [2, 3], depth: [2, 5], slack: 1.15, q: 0.75 },
            { finds: [3, 3], rocks: [2, 4], depth: [3, 5], slack: 1.15, q: 0.6 },
            { finds: [3, 4], rocks: [3, 4], depth: [3, 6], slack: 1.15, q: 0.45 },
            { finds: [4, 4], rocks: [3, 5], depth: [4, 6], slack: 1.15, q: 0.3 }]
    };
    return _t;
}

/// @function stra_families()
/// @description The 16 find families, in order: ammonite, trilobite, bone, tooth, amber, geode, ore, crystal, tablet,
/// shell, fern, fish, point, coin, skull, sherd. A fresh array each call. Pure.
/// @returns {Array<String>}
function stra_families() { var _a = stra__tables().ids, _o = []; for (var _i = 0; _i < array_length(_a); _i++) array_push(_o, _a[_i]); return _o; }

/// @function stra_sites()
/// @description The 8 rocks a face can be cut from: sandstone, shale, limestone, clay, basalt, chalk, ironstone,
/// permafrost. A fresh array each call. Pure.
/// @returns {Array<String>}
function stra_sites() { var _a = stra__tables().sites, _o = []; for (var _i = 0; _i < array_length(_a); _i++) array_push(_o, _a[_i]); return _o; }

/// @function stra_tools()
/// @description The two tools as { pick: { center, ortho, diag, stress }, hammer: {...} } (layers removed at the
/// target, beside it, on its diagonals; stress added per blow). A copy. Pure.
/// @returns {Struct}
function stra_tools() {
    var _t = stra__tables().tools;
    return { pick: { center: _t.pick.center, ortho: _t.pick.ortho, diag: _t.pick.diag, stress: _t.pick.stress },
        hammer: { center: _t.hammer.center, ortho: _t.hammer.ortho, diag: _t.hammer.diag, stress: _t.hammer.stress } };
}

/// @function stra__is_family(name)
/// @description Internal. True for one of the 16 family ids.
function stra__is_family(_f) { return is_string(_f) && variable_struct_exists(stra__tables().fam, _f); }

/// @function stra_footprint(family, rot)
/// @description A family's footprint as [col, row] cells from its top-left; rot = laid a quarter turn (columns and
/// rows swapped). An unknown family -> [] (nothing). Pure.
/// @param {String} family
/// @param {Bool} rot
/// @returns {Array}
function stra_footprint(_fam, _rot) {
    if (!stra__is_family(_fam)) return [];
    var _c = stra__tables().fam[$ _fam].cells, _o = [];
    for (var _i = 0; _i < array_length(_c); _i++) array_push(_o, (_rot == true) ? [_c[_i][1], _c[_i][0]] : [_c[_i][0], _c[_i][1]]);
    return _o;
}

// ---------------------------------------------------------------------------------------------------------------
// Unsigned 32-bit arithmetic, the hash and the generator (the MZ edition's, exact)
// ---------------------------------------------------------------------------------------------------------------

/// @function stra__imul(a, b)
/// @description Internal. JavaScript's Math.imul on unsigned 32-bit values, as int64 halves.
function stra__imul(_a, _b) {
    var _m = int64($FFFFFFFF);
    _a = int64(_a) & _m; _b = int64(_b) & _m;
    var _lo = (_a * (_b & int64($FFFF))) & _m;
    var _hi = ((_a * (_b >> 16)) & int64($FFFF)) << 16;
    return (_lo + _hi) & _m;
}

/// @function stra__u32(v)
/// @description Internal. JavaScript's (v >>> 0) for a number: truncated toward zero, then modulo 2^32; not a number -> 0.
function stra__u32(_v) {
    if (!is_numeric(_v) || is_nan(_v) || is_infinity(_v)) return int64(0);
    if (_v < 0) return (int64($100000000) - (int64(-_v) & int64($FFFFFFFF))) & int64($FFFFFFFF);
    return int64(_v) & int64($FFFFFFFF);
}

/// @function stra_hash_string(text)
/// @description The FNV-1a hash of a word, as the MZ edition computes it (UTF-16 code units). Use it to key a dig to a
/// place: the same word always gives the same site. Pure.
/// @param {String} text   anything; a non-string is hashed as its string form
/// @returns {Real} 0 .. 4294967295
function stra_hash_string(_s) {
    var _t = is_string(_s) ? _s : string(_s);
    var _h = int64(2166136261), _n = string_length(_t);
    for (var _i = 1; _i <= _n; _i++) { _h = _h ^ int64(ord(string_char_at(_t, _i)) & $FFFF); _h = stra__imul(_h, 16777619); }
    return real(_h);
}

/// @function stra_rng(seed)
/// @description A seeded generator (the MZ edition's mulberry32). Draw from it with stra_rand. Pure.
/// @param {Real} seed   any number (taken as unsigned 32-bit)
/// @returns {Struct}
function stra_rng(_seed) { return { a: stra__u32(_seed) }; }

/// @function stra_rand(gen)
/// @description The next draw in [0, 1) from a generator made by stra_rng. A non-generator -> 0.
/// @param {Struct} gen
/// @returns {Real}
function stra_rand(_g) {
    if (!is_struct(_g) || !variable_struct_exists(_g, "a")) return 0;
    var _m = int64($FFFFFFFF);
    _g.a = (int64(_g.a) + int64($6D2B79F5)) & _m;
    var _t = _g.a;
    _t = stra__imul(_t ^ (_t >> 15), _t | 1);
    var _x = stra__imul(_t ^ (_t >> 7), _t | 61);
    _t = _t ^ ((_t + _x) & _m);
    return real((_t ^ (_t >> 14)) & _m) / 4294967296;
}

/// @function stra__pick(gen, array)
/// @description Internal. arr[floor(r * len) % len], the MZ pick.
function stra__pick(_r, _arr) { var _n = array_length(_arr); var _u = stra_rand(_r); return _arr[floor(_u * _n) mod _n]; }

/// @function stra__between(gen, lo, hi)
/// @description Internal. lo + floor(r * (hi - lo + 1)), the MZ between.
function stra__between(_r, _lo, _hi) { var _u = stra_rand(_r); return _lo + floor(_u * (_hi - _lo + 1)); }

/// @function stra__round(x)
/// @description Internal. JavaScript's Math.round (half toward +infinity).
function stra__round(_x) { return floor(_x + 0.5); }

// ---------------------------------------------------------------------------------------------------------------
// Generation
// ---------------------------------------------------------------------------------------------------------------

/// @function stra_generate(options)
/// @description Generate a dig site. The same seed, grade, rock and families always give the same site, on every
/// machine. Every site is proven clearable: a careful digger can free every find within its stability.
/// @param {Struct} options { seed: a number (default 0), grade: 1 (forgiving) .. 5 (hard) (default 2),
///   site: one of stra_sites() (default: the seed chooses), families: an array of family ids, one per find, in order
///   (an unknown id or a missing one: the seed chooses) }
/// @returns {Struct} { v, cols, rows, depth[], rock[], finds[], stability, greedyStress, greedyBlows, prospectStress,
///   site, grade, seed, attempt } where each find is { family, rot, x, y, w, h, cells[], variant }
function stra_generate(_opt) {
    var _eps = math_get_epsilon(); math_set_epsilon(0);
    var _o = is_struct(_opt) ? _opt : {};
    var _gr = _o[$ "grade"];
    var _grade = (is_numeric(_gr) && !is_nan(_gr) && !is_infinity(_gr) && _gr != 0) ? _gr : 2;
    _grade = max(1, min(5, stra__round(_grade)));
    var _sd = _o[$ "seed"];
    var _seed = real(stra__u32(is_numeric(_sd) ? _sd : 0));
    var _T = stra__tables(), _G = _T.grades[_grade];
    var _site = undefined;
    for (var _attempt = 0; _attempt < 200; _attempt++) {
        var _r = stra_rng(real((stra__u32(_seed) ^ stra__imul(_attempt + 1, $9E3779B1)) & int64($FFFFFFFF)));
        _site = stra__try_generate(_r, _G, _o);
        if (is_struct(_site)) {
            _site.grade = _grade; _site.seed = _seed; _site.attempt = _attempt;
            var _r2 = stra_rng(real((stra__u32(_seed) ^ int64($5173)) & int64($FFFFFFFF)));
            var _want = _o[$ "site"];
            _site.site = (is_string(_want) && array_get_index(_T.sites, _want) >= 0) ? _want : stra__pick(_r2, _T.sites);
            math_set_epsilon(_eps);
            return _site;
        }
    }
    math_set_epsilon(_eps);
    show_debug_message("stra_generate: no layout for seed " + string(_seed));
    return undefined;
}

/// @function stra__noise(g, x, y)
/// @description Internal. Bilinear value noise over a 5 x 4 lattice of seeds (smoothstep weights), the MZ noise.
function stra__noise(_g, _x, _y) {
    var _xi = floor(_x), _yi = floor(_y), _fx = _x - _xi, _fy = _y - _yi;
    var _sx = _fx * _fx * (3 - 2 * _fx), _sy = _fy * _fy * (3 - 2 * _fy);
    var _a = _g[(((_xi mod 5) + 5) mod 5) + 5 * (((_yi mod 4) + 4) mod 4)];
    var _b = _g[((((_xi + 1) mod 5) + 5) mod 5) + 5 * (((_yi mod 4) + 4) mod 4)];
    var _c = _g[(((_xi mod 5) + 5) mod 5) + 5 * ((((_yi + 1) mod 4) + 4) mod 4)];
    var _d = _g[((((_xi + 1) mod 5) + 5) mod 5) + 5 * ((((_yi + 1) mod 4) + 4) mod 4)];
    var _top = _a * (1 - _sx) + _b * _sx;
    var _bot = _c * (1 - _sx) + _d * _sx;
    return _top * (1 - _sy) + _bot * _sy;
}

/// @function stra__try_generate(gen, grade, options)
/// @description Internal. One attempt at a layout; undefined when a find cannot be placed or the greedy digger cannot
/// free everything.
function stra__try_generate(_r, _G, _opt) {
    var _T = stra__tables(), _cols = STRA_COLS, _rows = STRA_ROWS, _n = _cols * _rows;
    var _depth = array_create(_n, 0), _rock = array_create(_n, 0), _owner = array_create(_n, -1);
    var _g1 = [], _g2 = [];
    for (var _i = 0; _i < 20; _i++) { var _u1 = stra_rand(_r); array_push(_g1, _u1); var _u2 = stra_rand(_r); array_push(_g2, _u2); }
    for (var _y = 0; _y < _rows; _y++) for (var _x = 0; _x < _cols; _x++) {
        var _v = 0.6 * stra__noise(_g1, _x / 4.3, _y / 3.7) + 0.4 * stra__noise(_g2, _x / 2.1 + 3, _y / 1.9 + 7);
        _depth[_y * _cols + _x] = _G.depth[0] + stra__round(_v * (_G.depth[1] - _G.depth[0]));
    }
    var _nf = stra__between(_r, _G.finds[0], _G.finds[1]);
    var _fams = [], _want = _opt[$ "families"];
    if (is_array(_want) && array_length(_want) > 0) for (var _w = 0; _w < min(_nf, array_length(_want)); _w++) array_push(_fams, _want[_w]);
    while (array_length(_fams) < _nf) array_push(_fams, stra__pick(_r, _T.ids));
    var _finds = [];
    for (var _f = 0; _f < _nf; _f++) {
        var _fam = stra__is_family(_fams[_f]) ? _fams[_f] : stra__pick(_r, _T.ids);
        var _placed = false;
        for (var _t = 0; _t < 60 && !_placed; _t++) {
            var _rot = false;
            if (_T.fam[$ _fam].rot) { var _ur = stra_rand(_r); _rot = _ur < 0.5; }
            var _fp = stra_footprint(_fam, _rot);
            var _fw = 0, _fh = 0;
            for (var _k = 0; _k < array_length(_fp); _k++) { _fw = max(_fw, _fp[_k][0] + 1); _fh = max(_fh, _fp[_k][1] + 1); }
            var _ox = stra__between(_r, 0, _cols - _fw);
            var _oy = stra__between(_r, 0, _rows - _fh);
            var _ok = true;
            for (var _k2 = 0; _k2 < array_length(_fp) && _ok; _k2++) {
                var _cx = _ox + _fp[_k2][0], _cy = _oy + _fp[_k2][1];
                // keep a one-cell moat between finds so no single blow frees two at once
                for (var _dy = -1; _dy <= 1 && _ok; _dy++) for (var _dx = -1; _dx <= 1 && _ok; _dx++) {
                    var _qx = _cx + _dx, _qy = _cy + _dy;
                    if (_qx < 0 || _qy < 0 || _qx >= _cols || _qy >= _rows) continue;
                    if (_owner[_qy * _cols + _qx] >= 0) _ok = false;
                }
            }
            if (!_ok) continue;
            var _cells = [];
            for (var _k3 = 0; _k3 < array_length(_fp); _k3++) { var _cc = (_oy + _fp[_k3][1]) * _cols + (_ox + _fp[_k3][0]); array_push(_cells, _cc); _owner[_cc] = array_length(_finds); }
            var _uv = stra_rand(_r);
            array_push(_finds, { family: _fam, rot: _rot, x: _ox, y: _oy, w: _fw, h: _fh, cells: _cells, variant: floor(_uv * 1000000000) });
            _placed = true;
        }
        if (!_placed) return undefined;
    }
    // bedrock: unbreakable stones, never on a find
    var _nr = stra__between(_r, _G.rocks[0], _G.rocks[1]);
    for (var _b = 0; _b < _nr; _b++) {
        for (var _tb = 0; _tb < 40; _tb++) {
            var _ub = stra_rand(_r); var _bw = (_ub < 0.5) ? 1 : 2;
            var _uh = stra_rand(_r); var _bh = (_uh < 0.6) ? 1 : 2;
            var _bx = stra__between(_r, 0, _cols - _bw);
            var _by = stra__between(_r, 0, _rows - _bh);
            var _clear = true;
            for (var _yy = _by; _yy < _by + _bh && _clear; _yy++) for (var _xx = _bx; _xx < _bx + _bw; _xx++) if (_owner[_yy * _cols + _xx] >= 0 || _rock[_yy * _cols + _xx]) _clear = false;
            if (!_clear) continue;
            for (var _y2 = _by; _y2 < _by + _bh; _y2++) for (var _x2 = _bx; _x2 < _bx + _bw; _x2++) _rock[_y2 * _cols + _x2] = 1;
            break;
        }
    }
    // stability 0 is a placeholder: the greedy and sighted diggers below run on the site before its stability is known
    // (they never read it; stra_is_site needs the field to exist), and it is set from them at the end
    var _site = { v: 1, cols: _cols, rows: _rows, depth: _depth, rock: _rock, finds: _finds, owner: _owner, stability: 0 };
    var _greedy = stra__greedy(_site);
    if (!_greedy.clearedAll) return undefined;
    _site.greedyStress = _greedy.stress;
    _site.greedyBlows = _greedy.blows;
    // calibrate against a player who cannot see underground: STRA_PROSPECT_RUNS seeded sighted digs, no budget
    var _need = [];
    for (var _pr = 0; _pr < STRA_PROSPECT_RUNS; _pr++) { var _us = stra_rand(_r); array_push(_need, stra__prospect(_site, stra_rng(floor(_us * 4294967296))).stress); }
    array_sort(_need, true);
    var _qi = min(array_length(_need) - 1, max(0, stra__round(_G.q * (array_length(_need) - 1))));
    _site.prospectStress = _need[_qi];
    _site.stability = max(ceil(_greedy.stress * _G.slack) + 2, _need[_qi] + 1);
    return _site;
}

/// @function stra_is_site(value)
/// @description True when the value is a site made by stra_generate. Every rule checks this first.
/// @param {Any} value
/// @returns {Bool}
function stra_is_site(_s) {
    return is_struct(_s) && is_array(_s[$ "depth"]) && is_array(_s[$ "rock"]) && is_array(_s[$ "finds"]) && is_numeric(_s[$ "cols"])
        && is_numeric(_s[$ "rows"]) && is_numeric(_s[$ "stability"]) && array_length(_s.depth) == _s.cols * _s.rows && array_length(_s.rock) == _s.cols * _s.rows;
}

/// @function stra__owner(site)
/// @description Internal. The cell -> find index table (-1 = no find). The MZ edition searches the finds for every cell
/// (findAt); this table gives the same answers once, so the greedy digger runs in a frame.
function stra__owner(_s) {
    if (is_array(_s[$ "owner"]) && array_length(_s.owner) == _s.cols * _s.rows) return _s.owner;
    var _o = array_create(_s.cols * _s.rows, -1);
    for (var _f = array_length(_s.finds) - 1; _f >= 0; _f--) { var _c = _s.finds[_f].cells; for (var _k = 0; _k < array_length(_c); _k++) if (_c[_k] >= 0 && _c[_k] < array_length(_o)) _o[_c[_k]] = _f; }
    _s.owner = _o;
    return _o;
}

// ---------------------------------------------------------------------------------------------------------------
// Play: the state is a copy of the depth grid plus the stress spent
// ---------------------------------------------------------------------------------------------------------------

/// @function stra_start(site)
/// @description A fresh play state for a site: { depth[] (a copy), stress, blows, collapsed }. Not a site -> undefined.
/// @param {Struct} site
/// @returns {Struct}
function stra_start(_s) {
    if (!stra_is_site(_s)) return undefined;
    var _n = array_length(_s.depth), _d = array_create(_n, 0);
    array_copy(_d, 0, _s.depth, 0, _n);
    return { depth: _d, stress: 0, blows: 0, collapsed: false };
}

/// @function stra__is_state(site, state)
/// @description Internal. True when the play state fits the site.
function stra__is_state(_s, _st) { return is_struct(_st) && is_array(_st[$ "depth"]) && array_length(_st.depth) == _s.cols * _s.rows && is_numeric(_st[$ "stress"]); }

/// @function stra_strike(site, state, tool, col, row)
/// @description Strike the face. Bedrock takes nothing and passes nothing on; a cleared cell stays cleared. Stress is
/// spent even on a wasted blow; a blow off the face, or after a collapse, does nothing at all.
/// @param {Struct} site
/// @param {Struct} state   from stra_start (changed in place)
/// @param {String} tool    "pick" or "hammer" (anything else: the pick)
/// @param {Real} col
/// @param {Real} row
/// @returns {Struct} { changed: cells changed, collapsed: this blow brought the face down, freed: finds newly freed }
function stra_strike(_s, _st, _tool, _col, _row) {
    var _out = { changed: [], collapsed: false, freed: [] };
    if (!stra_is_site(_s) || !stra__is_state(_s, _st)) return _out;
    if (_st.collapsed) return _out;
    if (!is_numeric(_col) || !is_numeric(_row) || is_nan(_col) || is_nan(_row)) return _out;
    _col = floor(_col); _row = floor(_row);
    if (_col < 0 || _row < 0 || _col >= _s.cols || _row >= _s.rows) return _out;
    var _T = stra__tables().tools, _tl = (_tool == "hammer") ? _T.hammer : _T.pick;
    var _before = stra_freed_list(_s, _st);
    for (var _dy = -1; _dy <= 1; _dy++) for (var _dx = -1; _dx <= 1; _dx++) {
        var _x = _col + _dx, _y = _row + _dy;
        if (_x < 0 || _y < 0 || _x >= _s.cols || _y >= _s.rows) continue;
        var _dmg = (_dx == 0 && _dy == 0) ? _tl.center : ((_dx == 0 || _dy == 0) ? _tl.ortho : _tl.diag);
        var _c = _y * _s.cols + _x;
        if (_dmg <= 0 || _s.rock[_c] || _st.depth[_c] <= 0) continue;
        _st.depth[_c] = max(0, _st.depth[_c] - _dmg);
        array_push(_out.changed, _c);
    }
    _st.stress += _tl.stress; _st.blows++;
    if (_st.stress >= _s.stability) { _st.stress = _s.stability; _st.collapsed = true; _out.collapsed = true; }
    var _after = stra_freed_list(_s, _st);
    for (var _i = 0; _i < array_length(_after); _i++) if (array_get_index(_before, _after[_i]) < 0) array_push(_out.freed, _after[_i]);
    return _out;
}

/// @function stra_freed_list(site, state)
/// @description The indices of the finds whose every cell is cleared.
/// @param {Struct} site
/// @param {Struct} state
/// @returns {Array<Real>}
function stra_freed_list(_s, _st) {
    var _out = [];
    if (!stra_is_site(_s) || !stra__is_state(_s, _st)) return _out;
    for (var _f = 0; _f < array_length(_s.finds); _f++) {
        var _all = true, _cells = _s.finds[_f].cells;
        for (var _k = 0; _k < array_length(_cells); _k++) if (_st.depth[_cells[_k]] > 0) { _all = false; break; }
        if (_all) array_push(_out, _f);
    }
    return _out;
}

/// @function stra_find_at(site, cell)
/// @description The index of the find under a cell (cell = row * cols + col), or -1.
/// @param {Struct} site
/// @param {Real} cell
/// @returns {Real}
function stra_find_at(_s, _c) {
    if (!stra_is_site(_s) || !is_numeric(_c) || is_nan(_c)) return -1;
    _c = floor(_c);
    if (_c < 0 || _c >= _s.cols * _s.rows) return -1;
    return stra__owner(_s)[_c];
}

/// @function stra_greedy_plan(site)
/// @description The greedy digger: each blow picks the tool and cell that removes the most depth still standing over
/// UNFREED find cells, per unit of stress. The site's stability is derived from what it spends, so play this good always
/// clears the face. Returns { clearedAll, stress, blows, plan: [{ tool, x, y }] }.
/// @param {Struct} site
/// @returns {Struct}
function stra_greedy_plan(_s) {
    if (!stra_is_site(_s)) return { clearedAll: false, stress: 0, blows: 0, plan: [] };
    var _eps = math_get_epsilon(); math_set_epsilon(0);
    var _r = stra__greedy(_s);
    math_set_epsilon(_eps);
    return _r;
}

/// @function stra__greedy(site)
/// @description Internal. stra_greedy_plan's body (the epsilon is the caller's).
function stra__greedy(_s) {
    var _st = stra_start(_s), _guard = 0, _log = [], _own = stra__owner(_s), _T = stra__tables();
    var _cols = _s.cols, _rows = _s.rows, _dep = _st.depth, _rk = _s.rock;
    while (array_length(stra_freed_list(_s, _st)) < array_length(_s.finds) && _guard++ < 400) {
        var _best = undefined, _bestScore = 0;
        for (var _ti = 0; _ti < 2; _ti++) {
            var _tool = _T.toolIds[_ti], _tl = _T.tools[$ _tool];
            for (var _y = 0; _y < _rows; _y++) for (var _x = 0; _x < _cols; _x++) {
                var _gain = 0;
                for (var _dy = -1; _dy <= 1; _dy++) for (var _dx = -1; _dx <= 1; _dx++) {
                    var _qx = _x + _dx, _qy = _y + _dy;
                    if (_qx < 0 || _qy < 0 || _qx >= _cols || _qy >= _rows) continue;
                    var _c = _qy * _cols + _qx;
                    if (_own[_c] < 0 || _rk[_c] || _dep[_c] <= 0) continue;
                    var _dmg = (_dx == 0 && _dy == 0) ? _tl.center : ((_dx == 0 || _dy == 0) ? _tl.ortho : _tl.diag);
                    _gain += min(_dmg, _dep[_c]);
                }
                var _score = _gain / _tl.stress;
                if (_score > _bestScore) { _bestScore = _score; _best = { tool: _tool, x: _x, y: _y }; }
            }
        }
        if (is_undefined(_best)) break;
        // the budget is not spent here, so a greedy plan can run past it; stability is set from its total
        var _t2 = _T.tools[$ _best.tool];
        for (var _ddy = -1; _ddy <= 1; _ddy++) for (var _ddx = -1; _ddx <= 1; _ddx++) {
            var _ax = _best.x + _ddx, _ay = _best.y + _ddy;
            if (_ax < 0 || _ay < 0 || _ax >= _cols || _ay >= _rows) continue;
            var _cc = _ay * _cols + _ax;
            var _dm = (_ddx == 0 && _ddy == 0) ? _t2.center : ((_ddx == 0 || _ddy == 0) ? _t2.ortho : _t2.diag);
            if (_dm > 0 && !_rk[_cc]) _dep[_cc] = max(0, _dep[_cc] - _dm);
        }
        _st.stress += _t2.stress; _st.blows++;
        array_push(_log, _best);
    }
    return { clearedAll: array_length(stra_freed_list(_s, _st)) == array_length(_s.finds), stress: _st.stress, blows: _st.blows, plan: _log };
}

/// @function stra_prospect(site, gen)
/// @description A SIGHTED digger - a model of an attentive player, not an oracle. It cannot see underground: until part
/// of a find shows it strikes at random; once part shows, three blows in four go to a still-buried cell of a showing
/// find, with the hammer when there is a lot left to clear. Runs with NO budget and reports the stress it needed to free
/// everything: { stress, blows }.
/// @param {Struct} site
/// @param {Struct} gen   from stra_rng (advanced)
/// @returns {Struct}
function stra_prospect(_s, _r) {
    if (!stra_is_site(_s) || !is_struct(_r)) return { stress: 0, blows: 0 };
    var _eps = math_get_epsilon(); math_set_epsilon(0);
    var _o = stra__prospect(_s, _r);
    math_set_epsilon(_eps);
    return _o;
}

/// @function stra__prospect(site, gen)
/// @description Internal. stra_prospect's body.
function stra__prospect(_s, _r) {
    var _st = stra_start(_s), _guard = 0, _n = _s.cols * _s.rows;
    var _probe = { v: 1, stability: 1000000000, cols: _s.cols, rows: _s.rows, rock: _s.rock, finds: _s.finds, depth: _s.depth };
    while (array_length(stra_freed_list(_s, _st)) < array_length(_s.finds) && _guard++ < 2000) {
        var _showing = [];
        for (var _f = 0; _f < array_length(_s.finds); _f++) {
            var _cells = _s.finds[_f].cells, _open = false, _shut = false;
            for (var _k = 0; _k < array_length(_cells); _k++) { if (_st.depth[_cells[_k]] == 0) _open = true; else _shut = true; }
            if (_open && _shut) for (var _k2 = 0; _k2 < array_length(_cells); _k2++) if (_st.depth[_cells[_k2]] > 0) array_push(_showing, _cells[_k2]);
        }
        var _aim = false;
        if (array_length(_showing) > 0) { var _ua = stra_rand(_r); _aim = _ua < 0.75; }
        var _c;
        if (_aim) { var _uc = stra_rand(_r); _c = _showing[floor(_uc * array_length(_showing))]; }
        else { var _un = stra_rand(_r); _c = floor(_un * _n); }
        stra_strike(_probe, _st, (array_length(_showing) > 3) ? "hammer" : "pick", _c mod _s.cols, floor(_c / _s.cols));
    }
    return { stress: _st.stress, blows: _st.blows };
}

/// @function stra_replay(site, plan)
/// @description Play a whole plan ([{ tool, x, y }], e.g. from stra_greedy_plan) through stra_strike, honouring the
/// budget. Returns { freed, collapsed, stress }.
/// @param {Struct} site
/// @param {Array} plan
/// @returns {Struct}
function stra_replay(_s, _plan) {
    var _st = stra_start(_s);
    if (is_undefined(_st) || !is_array(_plan)) return { freed: 0, collapsed: false, stress: 0 };
    for (var _i = 0; _i < array_length(_plan) && !_st.collapsed; _i++) {
        var _p = _plan[_i];
        if (is_struct(_p)) stra_strike(_s, _st, _p[$ "tool"], _p[$ "x"], _p[$ "y"]);
    }
    return { freed: array_length(stra_freed_list(_s, _st)), collapsed: _st.collapsed, stress: _st.stress };
}

/// @function stra_family_for(name)
/// @description The family an item NAMED like this is drawn as, read from the WORDS of its name ("Gold Coin" -> "coin",
/// "Raptor Skull" -> "skull", "Amber Drop" -> "amber", "Iron Ore" -> "ore"), or undefined when no word says (the seed
/// then chooses). Whole words only, so "Health Potion" is not a pot and "Lore Tablet" is not ore; a plural counts
/// ("Glyphs"), and three stems match the start of a word (nautil-, trilob-, inscri-). The first matching rule wins, in
/// this order: coin, skull, fern, fish, point, sherd, ammonite, trilobite, amber, geode, crystal, ore, bone, tooth, shell,
/// tablet. A family id itself is returned as is. Pure.
/// @param {String} name
/// @returns {String|Undefined}
function stra_family_for(_name) {
    if (!is_string(_name)) return undefined;
    var _t = string_lower(string_trim(_name));
    if (_t == "") return undefined;
    if (stra__is_family(_t)) return _t;
    // the words of the name: runs of the letters a..z
    var _words = [], _cur = "", _len = string_length(_t);
    for (var _p = 1; _p <= _len + 1; _p++) {
        var _o = (_p <= _len) ? ord(string_char_at(_t, _p)) : 32;
        if (_o >= 97 && _o <= 122) _cur += chr(_o); else { if (_cur != "") array_push(_words, _cur); _cur = ""; }
    }
    if (array_length(_words) == 0) return undefined;
    // a keyword ending in * is a stem (matches the start of a word); any other matches a whole word or its plural
    var _rules = [
        ["coin", ["coin", "denarius", "doubloon", "drachma", "sovereign", "token", "ducat", "florin"]],
        ["skull", ["skull", "cranium", "head"]],
        ["fern", ["fern", "frond", "leaf", "plant"]],
        ["fish", ["fish", "coelacanth"]],
        ["point", ["arrowhead", "arrow", "spearhead", "spear", "flint", "point", "blade", "knife", "obsidian"]],
        ["sherd", ["sherd", "shard", "pot", "urn", "vase", "ceramic", "amphora", "pottery"]],
        ["ammonite", ["ammonite", "fossil", "nautil*"]],
        ["trilobite", ["trilob*"]],
        ["amber", ["amber", "resin"]],
        ["geode", ["geode", "agate"]],
        ["crystal", ["crystal", "gem", "quartz", "jewel", "diamond", "ruby", "sapphire", "emerald", "amethyst"]],
        ["ore", ["ore", "gold", "silver", "copper", "iron", "mithril", "nugget"]],
        ["bone", ["bone", "skeleton", "femur"]],
        ["tooth", ["tooth", "teeth", "fang", "claw"]],
        ["shell", ["shell", "seashell", "scallop", "clam"]],
        ["tablet", ["tablet", "rune", "glyph", "stele", "inscri*"]]
    ];
    for (var _i = 0; _i < array_length(_rules); _i++) {
        var _kw = _rules[_i][1];
        for (var _j = 0; _j < array_length(_kw); _j++) {
            var _k = _kw[_j], _stem = string_char_at(_k, string_length(_k)) == "*";
            if (_stem) _k = string_copy(_k, 1, string_length(_k) - 1);
            for (var _w = 0; _w < array_length(_words); _w++) {
                var _wd = _words[_w];
                if (_stem ? (string_copy(_wd, 1, string_length(_k)) == _k) : (_wd == _k || _wd == _k + "s" || _wd == _k + "es")) return _rules[_i][0];
            }
        }
    }
    return undefined;
}
