/// stra_selftest.gml - Strata's in-engine test suite: the GML rules held to the RPG Maker MZ edition run in Node
/// (stra_oracle_core) - hashes, generator draws, generated sites, scripted strike sequences, greedy plans and sighted
/// prospects - then the drawing (every family, every rock), the scene end to end by scripted input, and the demo room.
/// Run the demo with -selftest; the result is written as stra_selftest.json in the game's save folder, and the renders
/// it makes (stra_render_*.png) beside it, to be LOOKED at.
///
/// Strata - Generated Excavation Digs for GameMaker. Copyright (c) 2026 Core Systems Asset Factory.

/// @function stra_st_assert(state, condition, message)
/// @description Count one assertion; keep the first 60 failure messages.
function stra_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 60) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
/// @function stra_st_stage(state, n)
/// @description Record the stage reached (the crash handler reports it).
function stra_st_stage(_st, _n) { _st.stage = _n; global.stra_stage = _n; }

/// @function stra__st_n(v)
/// @description Internal. A whole number as the oracle writes it (no decimals, no padding).
function stra__st_n(_v) { return string_trim(string_format(_v, 1, 0)); }

/// @function stra__st_enc_site(site)
/// @description Internal. A site encoded exactly as the oracle encodes it (encSite in _oracle_core.js).
function stra__st_enc_site(_s) {
    var _d = "", _r = "", _f = "";
    for (var _i = 0; _i < array_length(_s.depth); _i++) { _d += stra__st_n(_s.depth[_i]); _r += stra__st_n(_s.rock[_i]); }
    for (var _k = 0; _k < array_length(_s.finds); _k++) {
        var _F = _s.finds[_k], _cl = "";
        for (var _c = 0; _c < array_length(_F.cells); _c++) _cl += ((_c > 0) ? "." : "") + stra__st_n(_F.cells[_c]);
        _f += ((_k > 0) ? ";" : "") + _F.family + "," + (_F.rot ? "1" : "0") + "," + stra__st_n(_F.x) + "," + stra__st_n(_F.y) + "," + stra__st_n(_F.w) + "," + stra__st_n(_F.h) + "," + _cl + "," + stra__st_n(_F.variant);
    }
    return _s.site + "|" + stra__st_n(_s.grade) + "|" + stra__st_n(_s.seed) + "|" + stra__st_n(_s.attempt) + "|" + stra__st_n(_s.stability) + "|" + stra__st_n(_s.greedyStress)
        + "|" + stra__st_n(_s.greedyBlows) + "|" + stra__st_n(_s.prospectStress) + "|" + _d + "|" + _r + "|" + _f;
}

/// @function stra__st_join(array, sep)
/// @description Internal. Whole numbers joined, as JavaScript's Array.join.
function stra__st_join(_a, _sep) { var _o = ""; for (var _i = 0; _i < array_length(_a); _i++) _o += ((_i > 0) ? _sep : "") + stra__st_n(_a[_i]); return _o; }

/// @function stra__st_first_diff(a, b)
/// @description Internal. "" when two strings are equal, else where they part (for a readable failure).
function stra__st_first_diff(_a, _b) {
    if (_a == _b) return "";
    var _n = min(string_length(_a), string_length(_b)), _i = 1;
    while (_i <= _n && string_char_at(_a, _i) == string_char_at(_b, _i)) _i++;
    return "at char " + string(_i) + ": want '" + string_copy(_a, max(1, _i - 12), 40) + "' got '" + string_copy(_b, max(1, _i - 12), 40) + "'";
}

/// @function stra_selftest_run()
/// @description Run the whole suite and return its state { pass, fail, total, stage, failures, ... }.
function stra_selftest_run() {
    var _st = { pass: 0, fail: 0, total: 0, stage: 0, failures: [], runtime: GM_runtime_version, epsilon: 0, sites: 0, strikes: 0, timing: {}, renders: [], notes: [] };
    var _eps = math_get_epsilon(); math_set_epsilon(0); _st.epsilon = math_get_epsilon();
    var _O = stra_oracle_core(), _i, _j;

    // 1. the hash and the generator, exact
    stra_st_stage(_st, 1);
    for (_i = 0; _i < array_length(_O.hashes); _i++) { var _hw = _O.hashes[_i]; var _hg = stra_hash_string(_hw[0]); stra_st_assert(_st, _hg == _hw[1], "hash '" + _hw[0] + "' want " + string(_hw[1]) + " got " + string(_hg)); }
    for (_i = 0; _i < array_length(_O.rng); _i++) {
        var _rw = _O.rng[_i], _g = stra_rng(_rw[0]), _bad = "";
        for (_j = 0; _j < array_length(_rw[1]); _j++) { var _u = stra_rand(_g); if (_u != _rw[1][_j] && _bad == "") _bad = "draw " + string(_j) + " want " + string_format(_rw[1][_j], 1, 17) + " got " + string_format(_u, 1, 17); }
        stra_st_assert(_st, _bad == "", "rng seed " + string(_rw[0]) + ": " + _bad);
    }

    // 2. generated sites: every field, every find, the stability and the diggers' figures, as one string per site
    stra_st_stage(_st, 2);
    var _sites = [], _worstMs = 0, _sumMs = 0;
    for (_i = 0; _i < array_length(_O.sites); _i++) {
        var _e = _O.sites[_i], _t0 = get_timer();
        var _s = stra_generate({ seed: _e.seed, grade: _e.grade, site: _e.site, families: _e.families });
        var _ms = (get_timer() - _t0) / 1000; _worstMs = max(_worstMs, _ms); _sumMs += _ms;
        array_push(_sites, _s);
        var _enc = stra_is_site(_s) ? stra__st_enc_site(_s) : "(no site)";
        stra_st_assert(_st, _enc == _e.enc, "site #" + string(_i) + " seed " + string(_e.seed) + " grade " + string(_e.grade) + ": " + stra__st_first_diff(_e.enc, _enc));
        _st.sites++;
    }
    _st.timing.generateWorstMs = _worstMs; _st.timing.generateMeanMs = _sumMs / max(1, array_length(_O.sites));

    // 3. scripted strike sequences: every blow's cells, collapse, freed finds, stress, blows and the whole depth grid
    stra_st_stage(_st, 3);
    for (_i = 0; _i < array_length(_O.plays); _i++) {
        var _P = _O.plays[_i], _ps = _sites[_P.site], _pst = stra_start(_ps), _R = stra_rng(_P.script), _first = "";
        for (_j = 0; _j < array_length(_P.steps) && !_pst.collapsed; _j++) {
            var _ut = stra_rand(_R); var _tool = (_ut < 0.4) ? "hammer" : "pick";
            var _uc = stra_rand(_R); var _col = floor(_uc * (_ps.cols + 2)) - 1;
            var _ur = stra_rand(_R); var _row = floor(_ur * (_ps.rows + 2)) - 1;
            var _res = stra_strike(_ps, _pst, _tool, _col, _row);
            var _got = _tool + "|" + stra__st_n(_col) + "|" + stra__st_n(_row) + "|" + stra__st_join(_res.changed, ".") + "|" + (_res.collapsed ? "1" : "0") + "|" + stra__st_join(_res.freed, ".")
                + "|" + stra__st_n(_pst.stress) + "|" + stra__st_n(_pst.blows) + "|" + stra__st_join(_pst.depth, "");
            if (_got != _P.steps[_j] && _first == "") _first = "step " + string(_j) + " " + stra__st_first_diff(_P.steps[_j], _got);
            _st.strikes++;
        }
        stra_st_assert(_st, _first == "" && _j == array_length(_P.steps), "play on site " + string(_P.site) + ": " + _first + " (" + string(_j) + " of " + string(array_length(_P.steps)) + " steps)");
    }
    // greedy plans: whole plan, stress, blows; and the MZ guarantee: replayed under the budget it frees everything
    for (_i = 0; _i < array_length(_O.plans); _i++) {
        var _pw = _O.plans[_i], _gs = _sites[_pw.site], _gp = stra_greedy_plan(_gs), _pl = "";
        for (_j = 0; _j < array_length(_gp.plan); _j++) _pl += ((_j > 0) ? ";" : "") + string_char_at(_gp.plan[_j].tool, 1) + stra__st_n(_gp.plan[_j].x) + "," + stra__st_n(_gp.plan[_j].y);
        var _genc = (_gp.clearedAll ? "1" : "0") + "|" + stra__st_n(_gp.stress) + "|" + stra__st_n(_gp.blows) + "|" + _pl;
        stra_st_assert(_st, _genc == _pw.enc, "greedy plan on site " + string(_pw.site) + ": " + stra__st_first_diff(_pw.enc, _genc));
        var _rp = stra_replay(_gs, _gp.plan);
        stra_st_assert(_st, _rp.freed == array_length(_gs.finds) && !_rp.collapsed, "the greedy plan replayed under the budget frees all " + string(array_length(_gs.finds)) + " on site " + string(_pw.site) + " (" + string(_rp.freed) + ")");
    }
    for (_i = 0; _i < array_length(_O.prospects); _i++) {
        var _qw = _O.prospects[_i], _qs = _sites[_qw.site], _qe = "";
        for (_j = 0; _j < 4; _j++) { var _pr = stra_prospect(_qs, stra_rng(4242 + _j * 17)); _qe += ((_j > 0) ? ";" : "") + stra__st_n(_pr.stress) + "," + stra__st_n(_pr.blows); }
        stra_st_assert(_st, _qe == _qw.enc, "prospects on site " + string(_qw.site) + " want " + _qw.enc + " got " + _qe);
    }

    // 4. what the MZ edition does not have: the tables, the name reader, and refusals that never crash
    stra_st_stage(_st, 4);
    stra__st_rules(_st);

    // 5. drawing: every family in three variants (a contact sheet, ink counted, families told apart), every rock's six
    // layers and grain (a sheet), the crack network
    stra_st_stage(_st, 5);
    stra__st_draw(_st);

    // 6. the scene, as a buyer's game drives it
    stra_st_stage(_st, 6);
    stra__st_scene(_st);

    // 7. every rock as a dig in progress (renders to LOOK at)
    stra_st_stage(_st, 7);
    stra__st_boards(_st);

    // 8. the demo room by scripted input
    stra_st_stage(_st, 8);
    stra__st_demo(_st);

    math_set_epsilon(_eps);
    stra_st_stage(_st, 99);
    return _st;
}

/// @function stra__st_rules(state)
/// @description Internal. Tables, the name reader, footprints and the refusals.
function stra__st_rules(_st) {
    var _f = stra_families(), _r = stra_sites(), _t = stra_tools();
    stra_st_assert(_st, array_length(_f) == 16 && _f[0] == "ammonite" && _f[15] == "sherd" && array_length(_r) == 8 && _r[7] == "permafrost", "16 families and 8 rocks, in order");
    stra_st_assert(_st, _t.pick.stress == 2 && _t.hammer.stress == 4 && _t.hammer.diag == 1 && _t.pick.diag == 0, "the two tools as the MZ edition has them");
    _f[0] = "changed"; stra_st_assert(_st, stra_families()[0] == "ammonite", "stra_families hands out a copy");
    var _names = [["Gold Coin", "coin"], ["Raptor Skull", "skull"], ["Amber Drop", "amber"], ["Iron Ore", "ore"], ["Fossil Fern", "fern"], ["Flint Arrowhead", "point"],
        ["Clay Pot", "sherd"], ["Ancient Glyphs", "tablet"], ["Inscribed Stone", "tablet"], ["Trilobite Cast", "trilobite"], ["Nautilus", "ammonite"], ["Dragon Fang", "tooth"],
        ["Ruby", "crystal"], ["AMMONITE", "ammonite"], ["  geode  ", "geode"], ["Coelacanth", "fish"], ["Sea Shells", "shell"]];
    var _bad = "";
    for (var _i = 0; _i < array_length(_names); _i++) { var _g = stra_family_for(_names[_i][0]); if (_g != _names[_i][1] && _bad == "") _bad = "'" + _names[_i][0] + "' want " + _names[_i][1] + " got " + string(_g); }
    stra_st_assert(_st, _bad == "", "item names read as families by whole words: " + _bad);
    stra_st_assert(_st, is_undefined(stra_family_for("Health Potion")) && is_undefined(stra_family_for("Explorer's Map")) && is_undefined(stra_family_for("Golden Idol")), "a word that only CONTAINS a keyword says nothing (potion is not a pot, explorer is not ore)");
    stra_st_assert(_st, stra_family_for("Lore Tablet") == "tablet", "'Lore Tablet' is a tablet, not ore (" + string(stra_family_for("Lore Tablet")) + ")");
    stra_st_assert(_st, is_undefined(stra_family_for("")) && is_undefined(stra_family_for(12)) && is_undefined(stra_family_for(undefined)) && is_undefined(stra_family_for("!!!")), "the name reader refuses what is not a name");
    var _fp = stra_footprint("bone", true), _fq = stra_footprint("bone", false);
    stra_st_assert(_st, array_length(_fp) == 4 && _fp[3][0] == 0 && _fp[3][1] == 3 && _fq[3][0] == 3 && _fq[3][1] == 0, "a rotated footprint swaps columns and rows");
    stra_st_assert(_st, array_length(stra_footprint("nope", false)) == 0 && array_length(stra_footprint(undefined, true)) == 0, "an unknown family has no footprint");
    // refusals
    stra_st_assert(_st, !stra_is_site(undefined) && !stra_is_site({ depth: [1], rock: [0], finds: [], cols: 2, rows: 2, stability: 3 }), "is_site tells a site from a look-alike");
    stra_st_assert(_st, is_undefined(stra_start("x")) && array_length(stra_strike(undefined, undefined, "pick", 0, 0).changed) == 0, "start and strike refuse what is not a site");
    var _s = stra_generate({ seed: 11, grade: 3 }), _st0 = stra_start(_s);
    var _o1 = stra_strike(_s, _st0, "pick", -1, 0), _o2 = stra_strike(_s, _st0, "pick", 13, 4), _o3 = stra_strike(_s, _st0, "pick", "a", 2), _o4 = stra_strike(_s, _st0, "pick", 3, undefined);
    stra_st_assert(_st, _st0.blows == 0 && _st0.stress == 0 && array_length(_o1.changed) + array_length(_o2.changed) + array_length(_o3.changed) + array_length(_o4.changed) == 0, "a blow off the face, or at a cell that is not a number, does nothing at all");
    var _o5 = stra_strike(_s, _st0, "spade", 6, 5);
    stra_st_assert(_st, _st0.stress == 2 && _st0.blows == 1, "an unknown tool strikes as the pick (stress " + string(_st0.stress) + ")");
    stra_st_assert(_st, stra_find_at(_s, -1) == -1 && stra_find_at(_s, 130) == -1 && stra_find_at(undefined, 0) == -1 && stra_find_at(_s, "x") == -1, "find_at refuses a cell off the face");
    var _sx = stra_generate({ seed: -5, grade: "hard", site: "marble", families: "coin" });
    stra_st_assert(_st, stra_is_site(_sx) && _sx.grade == 2 && array_get_index(stra_sites(), _sx.site) >= 0, "generate reads nonsense options as defaults (grade " + (stra_is_site(_sx) ? string(_sx.grade) : "-") + ")");
    var _s9 = stra_generate({ seed: 11, grade: 9 }), _s0 = stra_generate({ seed: 11, grade: -3 });
    stra_st_assert(_st, _s9.grade == 5 && _s0.grade == 1, "grade is clamped to 1..5");
    stra_st_assert(_st, stra_greedy_plan(undefined).clearedAll == false && stra_prospect(undefined, stra_rng(1)).stress == 0 && stra_replay(_s, "plan").freed == 0, "the diggers refuse what is not a site or a plan");
    stra_st_assert(_st, stra_rand(undefined) == 0 && stra_rand({}) == 0, "rand on a non-generator is 0");
    // every grade, many seeds: the guarantee holds and the budget sits above the greedy figure
    var _worst = "", _n = 0, _t0 = get_timer();
    for (var _gr = 1; _gr <= 5; _gr++) for (var _sd = 0; _sd < 6; _sd++) {
        var _q = stra_generate({ seed: 7000 + _sd * 31 + _gr, grade: _gr }), _gp = stra_greedy_plan(_q), _rp = stra_replay(_q, _gp.plan); _n++;
        if (!(_rp.freed == array_length(_q.finds) && _q.stability > _q.greedyStress && _q.stability > _q.prospectStress) && _worst == "") _worst = "grade " + string(_gr) + " seed " + string(7000 + _sd * 31 + _gr);
    }
    stra_st_assert(_st, _worst == "", "30 more sites over every grade: each clearable inside its stability (" + _worst + ")");
    _st.timing.thirtySitesMs = (get_timer() - _t0) / 1000;
    // the balance, MEASURED (the Readme's grade table is this, not the MZ edition's): per grade, 12 fresh sites and 5 fresh
    // sighted digs on each (generators the calibration never used); a dig clears when the stress it needed to free every
    // find, less its last blow (a find freed by the blow that brings the face down still counts), stays under the stability
    _st.balance = [];
    var _orderOk = true, _prevShare = 2;
    for (var _g2 = 1; _g2 <= 5; _g2++) {
        var _clear = 0, _digs = 0, _finds = 0, _stab = 0, _rocks = 0;
        for (var _k = 0; _k < 12; _k++) {
            var _bs = stra_generate({ seed: 90000 + _g2 * 1000 + _k * 37, grade: _g2 });
            _finds += array_length(_bs.finds); _stab += _bs.stability; for (var _q2 = 0; _q2 < array_length(_bs.rock); _q2++) _rocks += _bs.rock[_q2];
            for (var _d = 0; _d < 5; _d++) {
                var _pr = stra_prospect(_bs, stra_rng(777000 + _g2 * 100 + _k * 7 + _d * 1311));
                // the last blow of a sighted dig is the pick (2) or the hammer (4): count the pick, the stricter reading
                if (_pr.stress - 2 < _bs.stability) _clear++;
                _digs++;
            }
        }
        var _share = _clear / _digs;
        array_push(_st.balance, { grade: _g2, clearShare: _share, digs: _digs, meanFinds: _finds / 12, meanStability: _stab / 12, meanBedrockCells: _rocks / 12 });
        if (_share > _prevShare + 0.1) _orderOk = false;
        _prevShare = _share;
    }
    stra_st_assert(_st, _orderOk && _st.balance[0].clearShare >= 0.6 && _st.balance[4].clearShare < _st.balance[0].clearShare, "the grades order the difficulty: grade 1 clears " + string(round(_st.balance[0].clearShare * 100)) + "% of sighted digs, grade 5 " + string(round(_st.balance[4].clearShare * 100)) + "%");
}

/// @function stra__st_ink(surface, x, y, w, h)
/// @description Internal. Count samples (every 2 px) in a region whose alpha is over half.
function stra__st_ink(_s, _x, _y, _w, _h) {
    var _sw = surface_get_width(_s), _sh = surface_get_height(_s), _b = buffer_create(_sw * _sh * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _s, 0);
    var _n = 0;
    for (var _yy = _y; _yy < _y + _h; _yy += 2) for (var _xx = _x; _xx < _x + _w; _xx += 2) if (buffer_peek(_b, (_yy * _sw + _xx) * 4 + 3, buffer_u8) > 127) _n++;
    buffer_delete(_b);
    return _n;
}

/// @function stra__st_draw(state)
/// @description Internal. The finds sheet (16 families x 3 variants), the rocks sheet (8 rocks x 6 layers, grain over) and
/// the crack network.
function stra__st_draw(_st) {
    // positive control first: an empty surface reads 0 ink and a filled one reads every sample
    var _pc = surface_create(64, 64);
    surface_set_target(_pc); draw_clear_alpha(c_black, 0); surface_reset_target(); var _e0 = stra__st_ink(_pc, 0, 0, 64, 64);
    surface_set_target(_pc); draw_clear_alpha(c_white, 1); surface_reset_target(); var _e1 = stra__st_ink(_pc, 0, 0, 64, 64);
    surface_free(_pc);
    stra_st_assert(_st, _e0 == 0 && _e1 == 1024, "the ink counter reads 0 on an empty surface and 1024 on a full one (" + string(_e0) + ", " + string(_e1) + ")");

    var _fam = stra_families(), _var = [101, 2024, 777777], _cell = 104, _sz = 96;
    var _sheet = surface_create(_cell * 8, _cell * 6), _thin = 0, _least = 999999, _leastName = "", _masks = [];
    surface_set_target(_sheet); draw_clear(make_colour_rgb(30, 22, 16)); surface_reset_target();
    var _t0 = get_timer();
    for (var _i = 0; _i < 16; _i++) for (var _v = 0; _v < 3; _v++) {
        var _spr = stra_find_sprite(_fam[_i], _var[_v], _sz);
        var _one = surface_create(_sz, _sz);
        surface_set_target(_one); draw_clear_alpha(c_black, 0); gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_zero); draw_sprite(_spr, 0, _sz / 2, _sz / 2); gpu_pop_state(); surface_reset_target();
        var _ink = stra__st_ink(_one, 0, 0, _sz, _sz);
        if (_ink < _least) { _least = _ink; _leastName = _fam[_i] + "/" + string(_var[_v]); }
        if (_ink < 120) _thin++;
        if (_v == 0) { var _mb = buffer_create(_sz * _sz * 4, buffer_fixed, 1); buffer_get_surface(_mb, _one, 0); array_push(_masks, _mb); }
        var _cx = (_i mod 8) * _cell + 4, _cy = ((_i div 8) * 3 + _v) * _cell + 4;
        surface_set_target(_sheet); gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); draw_surface(_one, _cx, _cy); gpu_pop_state(); surface_reset_target();
        surface_free(_one); sprite_delete(_spr);
    }
    _st.timing.findSheetMs = (get_timer() - _t0) / 1000;
    surface_save(_sheet, "stra_render_finds.png"); surface_free(_sheet);
    stra_st_assert(_st, _thin == 0, "all 48 finds (16 families x 3 variants) draw a solid form (least ink " + string(_least) + " samples, " + _leastName + ")");
    // families told apart: every pair differs in SILHOUETTE (>= 6% of the cell) or in what is drawn INSIDE it (>= 15% of
    // the shared samples, on luminance with each picture's own mean taken off, so a recolour alone does not count). Round
    // things are round (a coin, a geode, an ammonite): the silhouette alone false-reds them, and the interior is what tells
    // them apart. Measured 2026-10-20 before the redesign: tooth/point 2.7% silhouette - that pair was the defect.
    var _minS = 999999, _minSP = "", _worst = 999999, _worstP = "", _fails = "";
    var _lum = [], _mean = [];
    for (var _m0 = 0; _m0 < 16; _m0++) {
        var _L0 = array_create(_sz * _sz, -1), _sum = 0, _cnt = 0;
        for (var _p0 = 0; _p0 < _sz * _sz; _p0 += 2) if (buffer_peek(_masks[_m0], _p0 * 4 + 3, buffer_u8) > 127) { var _lv = (buffer_peek(_masks[_m0], _p0 * 4, buffer_u8) + buffer_peek(_masks[_m0], _p0 * 4 + 1, buffer_u8) + buffer_peek(_masks[_m0], _p0 * 4 + 2, buffer_u8)) / 3; _L0[_p0] = _lv; _sum += _lv; _cnt++; }
        array_push(_lum, _L0); array_push(_mean, (_cnt > 0) ? _sum / _cnt : 0);
    }
    for (var _a = 0; _a < 16; _a++) for (var _b = _a + 1; _b < 16; _b++) {
        var _d = 0, _both = 0, _inner = 0;
        for (var _p = 0; _p < _sz * _sz; _p += 2) {
            var _la = _lum[_a][_p], _lb = _lum[_b][_p];
            if ((_la >= 0) != (_lb >= 0)) _d++;
            else if (_la >= 0) { _both++; if (abs((_la - _mean[_a]) - (_lb - _mean[_b])) > 40) _inner++; }
        }
        var _sil = _d / (_sz * _sz / 2), _int = (_both > 0) ? _inner / _both : 1;
        if (_d < _minS) { _minS = _d; _minSP = _fam[_a] + "/" + _fam[_b] + " (inside " + string(round(_int * 100)) + "%)"; }
        var _score = max(_sil / 0.06, _int / 0.15);
        if (_score < _worst) { _worst = _score; _worstP = _fam[_a] + "/" + _fam[_b] + " silhouette " + string(round(_sil * 1000) / 10) + "% inside " + string(round(_int * 1000) / 10) + "%"; }
        if (_sil < 0.06 && _int < 0.15 && _fails == "") _fails = _fam[_a] + "/" + _fam[_b];
    }
    // the control: a family against ITSELF must read as the same picture, or the measure cannot fail
    var _cd = 0, _cb = 0, _ci = 0;
    for (var _pc2 = 0; _pc2 < _sz * _sz; _pc2 += 2) { var _l1 = _lum[3][_pc2]; if (_l1 >= 0) { _cb++; if (abs((_l1 - _mean[3]) - (_l1 - _mean[3])) > 40) _ci++; } }
    stra_st_assert(_st, _cb > 500 && _cd == 0 && _ci == 0, "control: a family against itself reads as the same picture (" + string(_cb) + " shared samples)");
    for (var _m = 0; _m < array_length(_masks); _m++) buffer_delete(_masks[_m]);
    stra_st_assert(_st, _fails == "", "no two families draw the same picture (closest by silhouette " + _minSP + "; closest overall " + _worstP + ") " + _fails);
    _st.closestFamilies = { bySilhouette: _minSP, overall: _worstP };

    // the rocks: six layers each, the grain over them; each rock's layer 0 told apart from every other rock's
    var _rk = stra_sites(), _cw = 120, _ch = 80, _rs = surface_create(_cw * 6 + 8, _ch * 8 + 8), _tmp = surface_create(_cw, _ch), _gr = surface_create(_cw, _ch);
    surface_set_target(_rs); draw_clear(make_colour_rgb(12, 9, 7)); surface_reset_target();
    var _edges = [];
    for (var _r = 0; _r < 8; _r++) {
        surface_set_target(_gr); draw_clear_alpha(c_black, 0); stra__blend_begin(); stra__grain_sheet(_rk[_r], 4242, _cw, _ch, 1); stra__blend_end(); surface_reset_target();
        for (var _L = 0; _L < 6; _L++) {
            surface_set_target(_tmp); stra__blend_begin(); stra__layer_sheet(_rk[_r], 4242, _L, _cw, _ch, 1); stra__blend_end();
            gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); draw_surface(_gr, 0, 0); gpu_pop_state(); surface_reset_target();
            surface_set_target(_rs); draw_surface(_tmp, 4 + _L * _cw, 4 + _r * _ch); surface_reset_target();
            if (_L == 0) {
                // structure, not only colour: the share of neighbouring pixels whose brightness steps by more than 6
                var _bf = buffer_create(_cw * _ch * 4, buffer_fixed, 1); buffer_get_surface(_bf, _tmp, 0);
                var _ed = 0, _tot = 0;
                for (var _y = 0; _y < _ch; _y++) for (var _x = 0; _x < _cw - 1; _x++) {
                    var _o = (_y * _cw + _x) * 4;
                    var _l0 = buffer_peek(_bf, _o, buffer_u8) + buffer_peek(_bf, _o + 1, buffer_u8) + buffer_peek(_bf, _o + 2, buffer_u8);
                    var _l1 = buffer_peek(_bf, _o + 4, buffer_u8) + buffer_peek(_bf, _o + 5, buffer_u8) + buffer_peek(_bf, _o + 6, buffer_u8);
                    if (abs(_l0 - _l1) > 18) _ed++; _tot++;
                }
                buffer_delete(_bf);
                array_push(_edges, { rock: _rk[_r], edgeShare: _ed / _tot });
            }
        }
    }
    surface_save(_rs, "stra_render_rocks.png");
    surface_free(_rs); surface_free(_tmp); surface_free(_gr);
    _st.rockEdges = _edges;
    var _flat = 0; for (var _q = 0; _q < 8; _q++) if (_edges[_q].edgeShare < 0.01) _flat++;
    stra_st_assert(_st, _flat == 0, "every rock's face carries structure, not a flat colour (" + string(_flat) + " rocks under 1% edges)");

    // the crack network: seeded, ordered, growing with the stress
    var _n1 = stra_crack_net(77, STRA_FACE_W, STRA_FACE_H), _n2 = stra_crack_net(77, STRA_FACE_W, STRA_FACE_H), _n3 = stra_crack_net(78, STRA_FACE_W, STRA_FACE_H);
    var _same = array_length(_n1) == array_length(_n2), _ordered = true, _inside = true;
    for (var _k = 0; _k < array_length(_n1) && _same; _k++) if (_n1[_k].x1 != _n2[_k].x1 || _n1[_k].t != _n2[_k].t) _same = false;
    for (var _k2 = 1; _k2 < array_length(_n1); _k2++) if (_n1[_k2].t < _n1[_k2 - 1].t) _ordered = false;
    for (var _k3 = 0; _k3 < array_length(_n1); _k3++) if (_n1[_k3].x1 < -4 || _n1[_k3].x1 > STRA_FACE_W + 4 || _n1[_k3].y1 < -4 || _n1[_k3].y1 > STRA_FACE_H + 4) _inside = false;
    stra_st_assert(_st, array_length(_n1) >= 30 && _same && _ordered && _inside && _n1[0].t >= 0.25 && abs(_n1[array_length(_n1) - 1].t - 1) < 0.0001,
        "the crack network: " + string(array_length(_n1)) + " segments, the same for the same seed, appearing in order from a quarter of the stability to the collapse");
    stra_st_assert(_st, array_length(_n3) != array_length(_n1) || _n3[0].x1 != _n1[0].x1, "another seed grows another network");
}

/// @function stra__st_shot(scene, file)
/// @description Internal. Draw the scene at scale 1 into a fresh surface, save it, return the ink; the count of translucent
/// samples (alpha under 250) is left in global.stra_st_holes - a scene drawn into a buyer's cleared surface must be opaque.
function stra__st_shot(_T, _file) {
    var _s = surface_create(STRA_SCENE_W, STRA_SCENE_H);
    surface_set_target(_s); draw_clear_alpha(c_black, 0); stra_draw(_T, 0, 0, 1); surface_reset_target();
    surface_save(_s, _file);
    var _b = buffer_create(STRA_SCENE_W * STRA_SCENE_H * 4, buffer_fixed, 1); buffer_get_surface(_b, _s, 0);
    var _holes = 0, _ink = 0;
    for (var _yy = 0; _yy < STRA_SCENE_H; _yy += 2) for (var _xx = 0; _xx < STRA_SCENE_W; _xx += 2) { var _al = buffer_peek(_b, (_yy * STRA_SCENE_W + _xx) * 4 + 3, buffer_u8); if (_al < 250) _holes++; if (_al > 127) _ink++; }
    buffer_delete(_b); surface_free(_s);
    global.stra_st_holes = _holes;
    return _ink;
}

/// @function stra__st_same_state(a, b)
/// @description Internal. "" when two play states agree (depth grid, stress, blows, collapsed), else the first difference.
function stra__st_same_state(_a, _b) {
    if (_a.stress != _b.stress) return "stress " + string(_a.stress) + " vs " + string(_b.stress);
    if (_a.blows != _b.blows) return "blows " + string(_a.blows) + " vs " + string(_b.blows);
    if (_a.collapsed != _b.collapsed) return "collapsed";
    for (var _i = 0; _i < array_length(_a.depth); _i++) if (_a.depth[_i] != _b.depth[_i]) return "depth at cell " + string(_i);
    return "";
}

/// @function stra__st_scene(state)
/// @description Internal. The scene end to end by scripted input, as a buyer's game would drive it.
function stra__st_scene(_st) {
    global.stra_st_sounds = [];
    var _t0 = get_timer();
    var _T = stra_open({ seed: "quarry-7", grade: 2, rock: "limestone", finds: ["Gold Coin", "Raptor Skull", "Amber Drop"], sound: function(_n) { array_push(global.stra_st_sounds, _n); } });
    _st.timing.openMs = (get_timer() - _t0) / 1000;
    var _tg = get_timer();
    var _ref = stra_generate({ seed: stra_hash_string("quarry-7"), grade: 2, site: "limestone", families: ["coin", "skull", "amber"] });
    _st.timing.openGenerateMs = (get_timer() - _tg) / 1000;   // the share of the open that is the generator; the rest is the bake
    _st.timing.bakeMs = _T.bakeMs;
    stra_st_assert(_st, stra__is_scene(_T) && _T.seed == stra_hash_string("quarry-7") && _T.rock == "limestone" && _T.grade == 2 && _T.mode == "dig", "stra_open: a dig with the request read (seed word hashed, rock, grade)");
    stra_st_assert(_st, stra__st_enc_site(_T.site) == stra__st_enc_site(_ref), "the scene's site is the generator's site for the same request");
    stra_st_assert(_st, _T.site.finds[0].family == "coin" && _T.site.finds[1].family == "skull" && _T.names[0] == "Gold Coin", "the buyer's item names become the finds, in order (" + _T.site.finds[0].family + ", " + _T.site.finds[1].family + ")");
    var _ink0 = stra__st_shot(_T, "stra_render_scene_fresh.png");
    stra_st_assert(_st, _ink0 >= STRA_SCENE_W * STRA_SCENE_H / 4 * 0.98 && global.stra_st_holes == 0, "a fresh dig draws edge to edge and opaque (" + string(_ink0) + " samples, " + string(global.stra_st_holes) + " translucent)");
    // the mark follows the pointer once the scene knows where it is drawn
    stra_step(_T, STRA_FACE_X + 3 * STRA_CELL + 5, STRA_FACE_Y + 4 * STRA_CELL + 5);
    stra_st_assert(_st, _T.cx == 3 && _T.cy == 4, "the mark follows the pointer over the face (" + string(_T.cx) + ", " + string(_T.cy) + ")");
    // tool changes
    _T.inject = { tool: "switch" }; stra_step(_T); var _sw1 = _T.tool; _T.inject = { tool: "switch" }; stra_step(_T);
    stra_st_assert(_st, _sw1 == "hammer" && _T.tool == "pick" && array_get_index(global.stra_st_sounds, "tool") >= 0, "Q/W switches the tool both ways, with the tool sound");
    // arrows move the mark and stop at the edge
    _T.inject = { dx: 1 }; stra_step(_T); var _ax = _T.cx;
    repeat (20) { _T.inject = { dx: -1, dy: -1 }; stra_step(_T); }
    stra_st_assert(_st, _ax == 4 && _T.cx == 0 && _T.cy == 0, "arrows move the mark and stop at the edge of the face");
    // the greedy plan played by injected input, blow for blow held to stra_strike on a twin state
    var _plan = stra_greedy_plan(_T.site).plan, _twin = stra_start(_T.site), _diff = "", _mid = floor(array_length(_plan) / 2), _midInk = 0, _midCracks = -1;
    for (var _i = 0; _i < array_length(_plan) && _T.mode == "dig"; _i++) {
        var _p = _plan[_i];
        _T.inject = { tool: _p.tool, strike: true, col: _p.x, row: _p.y }; stra_step(_T);
        stra_strike(_T.site, _twin, _p.tool, _p.x, _p.y);
        var _dd = stra__st_same_state(_twin, _T.st); if (_dd != "" && _diff == "") _diff = "blow " + string(_i) + ": " + _dd;
        if (_i == _mid) { repeat (6) stra_step(_T); _midInk = stra__st_shot(_T, "stra_render_scene_mid.png"); _midCracks = _T.cracksShown; }
    }
    stra_st_assert(_st, _diff == "", "every blow struck through the scene is the rules' blow (" + string(array_length(_plan)) + " blows) " + _diff);
    stra_st_assert(_st, _midInk >= STRA_SCENE_W * STRA_SCENE_H / 4 * 0.98 && global.stra_st_holes == 0, "mid-dig the scene draws edge to edge and opaque (" + string(global.stra_st_holes) + " translucent)");
    var _r = stra_result(_T);
    stra_st_assert(_st, _T.mode == "done" && is_struct(_r) && _r.cleared && !_r.collapsed && _r.found == _r.total && _r.found == array_length(_T.site.finds), "the plan clears the face and the face holds (" + _T.mode + ")");
    stra_st_assert(_st, _r.names[0] == "Gold Coin" && _r.families[0] == "coin" && _r.freed[0] == 0, "the result names the buyer's items freed (" + string(_r.names) + ")");
    var _snd = global.stra_st_sounds;
    stra_st_assert(_st, array_get_index(_snd, "free") >= 0 && array_get_index(_snd, "done") >= 0 && (array_get_index(_snd, "pick") >= 0 || array_get_index(_snd, "hammer") >= 0) && array_get_index(_snd, "collapse") < 0, "the sound hook heard the blows, each find coming free and the end (" + string(array_length(_snd)) + " calls)");
    stra_st_assert(_st, array_length(_T.glints) >= 1, "a glint over the find that came free (" + string(array_length(_T.glints)) + ")");
    _st.greedyMidCracks = _midCracks;
    _T.inject = { ok: true }; stra_step(_T);
    stra_st_assert(_st, !stra_closed(_T), "OK in the first moments of the results is ignored");
    repeat (44) { _T.inject = {}; stra_step(_T); }
    var _cardInk = stra__st_shot(_T, "stra_render_scene_cleared.png");
    stra_st_assert(_st, surface_exists(_T.cardSurf) && _cardInk >= STRA_SCENE_W * STRA_SCENE_H / 4 * 0.98 && global.stra_st_holes == 0, "the results card draws over the cleared face (" + string(global.stra_st_holes) + " translucent)");
    _T.inject = { ok: true }; stra_step(_T);
    stra_st_assert(_st, stra_closed(_T) && stra_result(_T).cleared, "OK on the results closes the dig with the result");
    stra_free(_T); stra_free(_T);
    stra_st_assert(_st, stra_closed(_T) && !sprite_exists(_T.bgSpr) && !surface_exists(_T.faceSurf), "free twice is safe; a freed dig reads closed and owns nothing");

    // the face gives way: one cell hammered until the stress runs out
    global.stra_st_sounds = [];
    var _C = stra_open({ seed: 4242, grade: 5, rock: "basalt", sound: function(_n) { array_push(global.stra_st_sounds, _n); } }), _g = 0;
    while (_C.mode == "dig" && _g < 400) { _C.inject = { tool: "hammer", strike: true, col: 0, row: 0 }; stra_step(_C); _g++; }
    var _rc = stra_result(_C), _rub = 0; for (var _k = 0; _k < array_length(_C.rubble); _k++) _rub += _C.rubble[_k];
    stra_st_assert(_st, is_struct(_rc) && _rc.collapsed && !_rc.cleared && _C.st.stress == _C.site.stability && _rub > 0 && array_length(_C.falls) > 0 && _C.shake > 0,
        "hammering one cell brings the face down after " + string(_g) + " blows: rubble on " + string(_rub) + " cells, " + string(array_length(_C.falls)) + " stones falling");
    stra_st_assert(_st, array_get_index(global.stra_st_sounds, "collapse") >= 0 && _C.cracksShown == array_length(_C.cracks), "the collapse sound, and every crack showing (" + string(_C.cracksShown) + ")");
    repeat (10) { _C.inject = {}; stra_step(_C); }
    var _fallInk = stra__st_shot(_C, "stra_render_scene_collapse.png");
    stra_st_assert(_st, _fallInk >= STRA_SCENE_W * STRA_SCENE_H / 4 * 0.98 && global.stra_st_holes == 0, "mid-fall the scene draws and stays opaque");
    var _ff = 0; while (array_length(_C.falls) > 0 && _ff < 300) { _C.inject = {}; stra_step(_C); _ff++; }
    repeat (30) { _C.inject = {}; stra_step(_C); }
    stra__st_shot(_C, "stra_render_scene_gave_way.png");
    stra_st_assert(_st, _ff < 200 && surface_exists(_C.cardSurf), "the fall ends on its own (" + string(_ff) + " frames) and the card comes up");
    stra_free(_C);

    // Escape packs up when allowed and does nothing when not; a worked-out face opens worked out
    var _L = stra_open({ seed: 7, grade: 1 });
    _L.inject = { strike: true, col: 6, row: 5 }; stra_step(_L);
    _L.inject = { leave: true }; stra_step(_L);
    stra_st_assert(_st, _L.mode == "done" && stra_result(_L).left && !stra_result(_L).cleared && stra_result(_L).blows == 1, "Escape packs up with the result marked left");
    stra_free(_L);
    var _N = stra_open({ seed: 7, grade: 1, allow_leave: false });
    repeat (3) { _N.inject = { leave: true }; stra_step(_N); }
    stra_st_assert(_st, _N.mode == "dig", "allow_leave false: Escape does nothing");
    stra_free(_N);
    var _W = stra_open({ seed: 7, grade: 1, worked: true });
    var _wz = 0; for (var _c = 0; _c < array_length(_W.st.depth); _c++) _wz += _W.st.depth[_c];
    stra_st_assert(_st, _W.mode == "done" && stra_result(_W).worked && stra_result(_W).found == 0 && _wz == 0, "worked: true opens the face worked out, nothing left to find");
    stra_free(_W);
    // the same request is the same dig; a blank seed is a new dig every time
    var _A = stra_open({ seed: "mine-3-east", grade: 3 }), _B = stra_open({ seed: "mine-3-east", grade: 3 }), _X = stra_open({ grade: 3 }), _Y = stra_open({ grade: 3 });
    stra_st_assert(_st, stra__st_enc_site(_A.site) == stra__st_enc_site(_B.site) && _X.seed != _Y.seed, "the same seed word is the same dig; a blank seed is a new one each time");
    var _Z = stra_open({ seed: "12345", grade: 3 });
    stra_st_assert(_st, _Z.seed == 12345, "a seed of plain digits is read as that number");
    stra_free(_A); stra_free(_B); stra_free(_X); stra_free(_Y); stra_free(_Z);
    // detail 2: every sheet at twice the resolution, drawn at scale 2
    var _D2 = stra_open({ seed: "quarry-7", grade: 2, rock: "limestone", detail: 2 });
    var _s2 = surface_create(STRA_SCENE_W * 2, STRA_SCENE_H * 2);
    surface_set_target(_s2); draw_clear_alpha(c_black, 0); stra_draw(_D2, 0, 0, 2); surface_reset_target();
    surface_save(_s2, "stra_render_scene_detail2.png");
    var _i2 = stra__st_ink(_s2, 0, 0, STRA_SCENE_W * 2, STRA_SCENE_H * 2);
    surface_free(_s2);
    stra_st_assert(_st, _D2.ss == 2 && _i2 >= STRA_SCENE_W * STRA_SCENE_H * 0.98, "detail 2 draws the scene at twice the size edge to edge (" + string(_i2) + ")");
    stra_free(_D2);
    // a lost surface is rebuilt by the next draw
    var _V = stra_open({ seed: 5, grade: 2 });
    surface_free(_V.faceSurf); surface_free(_V.hudSurf);
    var _vi = stra__st_shot(_V, "stra_render_scene_rebuilt.png");
    stra_st_assert(_st, surface_exists(_V.faceSurf) && surface_exists(_V.hudSurf) && _vi >= STRA_SCENE_W * STRA_SCENE_H / 4 * 0.98, "a surface the GPU lost is rebuilt by the next draw");
    stra_free(_V);
    // refusals
    stra_st_assert(_st, is_undefined(stra_open(undefined)) && is_undefined(stra_open(12)), "stra_open refuses what is not a request");
    var _odd = stra_open({ seed: 3, grade: "x", rock: 5, finds: 7, title: 9, detail: "big" });
    stra_st_assert(_st, stra__is_scene(_odd) && _odd.grade == 2 && _odd.ss == 1, "nonsense request fields fall back to the defaults");
    stra_free(_odd);
    stra_step(undefined); stra_step("x"); stra_draw(undefined, 0, 0, 1); stra_draw({}, 0, 0, 1); stra_free(undefined); stra_free(12);
    stra_st_assert(_st, stra_closed(undefined) && is_undefined(stra_result(undefined)), "the scene calls survive values that are not a scene");
}

/// @function stra__st_dig_like_a_player(scene, share, gen)
/// @description Internal. Strike through the scene the way the SIGHTED digger the stability is calibrated on digs (the MZ
/// prospect rule: until part of a find shows, anywhere; then three blows in four on a still-buried cell of a showing
/// find, the hammer when much is left), by injected input, until the stress reaches `share` of the stability or only one
/// find is left buried. Returns the blows struck.
function stra__st_dig_like_a_player(_T, _share, _g) {
    var _s = _T.site, _n = _s.cols * _s.rows, _b = 0;
    while (_T.mode == "dig" && _T.st.stress < _share * _s.stability && array_length(stra_freed_list(_s, _T.st)) < array_length(_s.finds) - 1 && _b < 600) {
        var _showing = [];
        for (var _f = 0; _f < array_length(_s.finds); _f++) {
            var _cells = _s.finds[_f].cells, _op = false, _sh = false;
            for (var _k = 0; _k < array_length(_cells); _k++) { if (_T.st.depth[_cells[_k]] == 0) _op = true; else _sh = true; }
            if (_op && _sh) for (var _k2 = 0; _k2 < array_length(_cells); _k2++) if (_T.st.depth[_cells[_k2]] > 0) array_push(_showing, _cells[_k2]);
        }
        var _ua = stra_rand(_g), _c;
        if (array_length(_showing) > 0 && _ua < 0.75) { var _uc = stra_rand(_g); _c = _showing[floor(_uc * array_length(_showing))]; }
        else { var _un = stra_rand(_g); _c = floor(_un * _n); }
        _T.inject = { tool: (array_length(_showing) > 3) ? "hammer" : "pick", strike: true, col: _c mod _s.cols, row: _c div _s.cols }; stra_step(_T);
        _b++;
    }
    return _b;
}

/// @function stra__st_boards(state)
/// @description Internal. Every rock as a dig in progress, dug the way a player digs to a little over half the stability,
/// rendered to look at; and the cracks, which a player's stress reaches and the greedy digger's never does.
function stra__st_boards(_st) {
    var _rk = stra_sites(), _least = 999999, _crackBad = "";
    for (var _r = 0; _r < 8; _r++) {
        var _T = stra_open({ seed: "board-" + _rk[_r], grade: 3, rock: _rk[_r] });
        var _bl = stra__st_dig_like_a_player(_T, 0.58, stra_rng(stra_hash_string("player-" + _rk[_r])));
        repeat (40) { _T.inject = {}; stra_step(_T); }
        var _ink = stra__st_shot(_T, "stra_render_board_" + _rk[_r] + ".png");
        _least = min(_least, _ink);
        var _f = _T.st.stress / _T.site.stability;
        if (_T.mode == "dig" && _f > 0.3 && !(_T.cracksShown > 0 && _T.cracksShown < array_length(_T.cracks)) && _crackBad == "") _crackBad = _rk[_r] + " at " + string(floor(_f * 100)) + "% shows " + string(_T.cracksShown) + " of " + string(array_length(_T.cracks));
        array_push(_st.renders, { name: "board_" + _rk[_r], blows: _T.st.blows, stress: _T.st.stress, stability: _T.site.stability, share: _f, freed: array_length(stra_freed_list(_T.site, _T.st)), finds: array_length(_T.site.finds), cracks: _T.cracksShown, of: array_length(_T.cracks), mode: _T.mode, holes: global.stra_st_holes });
        stra_free(_T);
    }
    stra_st_assert(_st, _least >= STRA_SCENE_W * STRA_SCENE_H / 4 * 0.98, "every rock draws as a dig in progress (least " + string(_least) + " samples)");
    stra_st_assert(_st, _crackBad == "", "past a quarter of the stability the face shows some of its cracks and not all " + _crackBad);
    // the cracks grow with the stress: struck at one bedrock-free spot, the count shown never falls and reaches every crack
    var _C = stra_open({ seed: "cracks", grade: 4, rock: "shale" }), _prev = 0, _mono = true, _seen = [];
    var _cc = 0; while (_C.site.rock[_cc] && _cc < 129) _cc++;
    while (_C.mode == "dig") { _C.inject = { tool: "hammer", strike: true, col: _cc mod STRA_COLS, row: _cc div STRA_COLS }; stra_step(_C); if (_C.cracksShown < _prev) _mono = false; _prev = _C.cracksShown; array_push(_seen, _prev); }
    stra_st_assert(_st, _mono && _prev == array_length(_C.cracks) && _seen[0] == 0, "the cracks spread blow by blow and never close (" + string(array_length(_seen)) + " blows, " + string(_prev) + " of " + string(array_length(_C.cracks)) + ")");
    stra_free(_C);
}

/// @function stra__st_demo(state)
/// @description Internal. The demo room as a player would use it, by scripted input.
function stra__st_demo(_st) {
    var _D = stra_demo_create();
    var _ok = is_struct(_D) && array_length(_D.pits) == 8 && sprite_exists(_D.bg) && sprite_exists(_D.pickSpr) && sprite_exists(_D.gradeSpr) && sprite_exists(_D.traySpr);
    for (var _i = 0; _i < 8; _i++) if (!sprite_exists(_D.cardSpr[_i])) _ok = false;
    stra_st_assert(_st, _ok, "stra_demo_create bakes the camp, eight pits, the pick, the grades and the tray");
    var _gs = surface_create(STRA_SCENE_W, STRA_SCENE_H);
    stra_demo_step(_D);
    surface_set_target(_gs); draw_clear_alpha(c_black, 0); stra_demo_draw(_D); surface_reset_target();
    surface_save(_gs, "stra_render_camp.png");
    var _gi = stra__st_ink(_gs, 0, 0, STRA_SCENE_W, STRA_SCENE_H);
    stra_st_assert(_st, _gi >= STRA_SCENE_W * STRA_SCENE_H / 4 * 0.98, "the camp draws edge to edge (" + string(_gi) + " samples)");
    // Right, grade 4, Enter: the clay pit opens at grade 4 behind the wait card
    _D.inject = { right: true }; stra_demo_step(_D);
    _D.inject = { grade: 3 }; stra_demo_step(_D);
    _D.inject = { ok: true }; stra_demo_step(_D);
    var _waited = _D.pending == 3;
    stra_demo_step(_D); stra_demo_step(_D);
    stra_st_assert(_st, _waited && is_struct(_D.scene) && _D.scene.rock == "clay" && _D.scene.grade == 4, "Right, 4 and Enter open the clay pit at grade 4 behind the wait card (" + (is_struct(_D.scene) ? _D.scene.rock + " " + string(_D.scene.grade) : "no scene") + ")");
    // clear it by the greedy plan, then leave the results: the finds go into the collection
    var _plan = is_struct(_D.scene) ? stra_greedy_plan(_D.scene.site).plan : [], _nf = is_struct(_D.scene) ? array_length(_D.scene.site.finds) : 0;
    for (var _p = 0; _p < array_length(_plan) && is_struct(_D.scene) && _D.scene.mode == "dig"; _p++) { _D.inject = { tool: _plan[_p].tool, strike: true, col: _plan[_p].x, row: _plan[_p].y }; stra_demo_step(_D); }
    var _guard = 0; while (is_struct(_D.scene) && _guard < 200) { _D.inject = (_guard > 60) ? { ok: true } : {}; stra_demo_step(_D); _guard++; }
    var _sprOk = array_length(_D.colSpr) == _nf; for (var _c = 0; _c < array_length(_D.colSpr); _c++) if (!sprite_exists(_D.colSpr[_c])) _sprOk = false;
    stra_st_assert(_st, is_undefined(_D.scene) && _nf > 0 && array_length(_D.collection) == _nf && _sprOk && _D.digs == 1 && _D.lastResult.cleared, "a cleared dig closes and its " + string(_nf) + " finds join the collection");
    // a second dig at the limestone pit: packed up with Escape after one blow
    _D.inject = { left: true }; stra_demo_step(_D); _D.inject = { ok: true }; stra_demo_step(_D); stra_demo_step(_D); stra_demo_step(_D);
    var _second = is_struct(_D.scene) && _D.scene.rock == "limestone";
    if (_second) { _D.inject = { strike: true, col: 6, row: 5 }; stra_demo_step(_D); _D.inject = { leave: true }; stra_demo_step(_D); }
    _guard = 0; while (is_struct(_D.scene) && _guard < 200) { _D.inject = (_guard > 60) ? { ok: true } : {}; stra_demo_step(_D); _guard++; }
    stra_st_assert(_st, _second && is_undefined(_D.scene) && _D.lastResult.left && _D.digs == 2 && _D.visits[2] == 1 && _D.visits[3] == 1, "a dig packed up with Escape returns to the camp (digs " + string(_D.digs) + ")");
    // a third visit to the clay pit is a NEW site
    var _s1 = stra_hash_string("camp-clay-4-1"), _s2 = stra_hash_string("camp-clay-4-2");
    stra_st_assert(_st, _s1 != _s2, "each visit to a pit is keyed to a new site");
    stra_demo_step(_D);
    surface_set_target(_gs); draw_clear_alpha(c_black, 0); stra_demo_draw(_D); surface_reset_target();
    surface_save(_gs, "stra_render_camp_collection.png");
    stra_demo_free(_D); stra_demo_free(_D);
    stra_st_assert(_st, _D.bg == -1 && _D.cardSpr[0] == -1 && (array_length(_D.colSpr) == 0 || _D.colSpr[0] == -1), "stra_demo_free frees everything, twice safely");
    surface_free(_gs);
}

/// @function stra_selftest_write(state)
/// @description Write the self-test result as stra_selftest.json in the game's save folder.
function stra_selftest_write(_st) {
    var _f = file_text_open_write("stra_selftest.json");
    file_text_write_string(_f, json_stringify(_st));
    file_text_close(_f);
}
