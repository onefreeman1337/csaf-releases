# Strata - Generated Excavation Digs for GameMaker

Give the player a rock face and two tools. Every blow cuts the rock back a layer or two and puts stress on the face;
somewhere under it lie fossils, relics, crystals or ore. Free a find completely before the face gives way and it is
theirs. Push too hard and the face collapses, taking whatever is still buried with it.

- **Every dig is generated from a seed:** the finds and where they lie, the bedrock stones that cannot be cut, the
  thickness of the rock cell by cell and the stability of the face. Stability is derived from how a careful digger does on
  that exact site, so no site is impossible and the grade decides how forgiving it is. The same seed is the same site on
  every machine.
- **Sixteen families of finds, all drawn by the package:** ammonite, trilobite, bone, tooth, amber, geode, ore, crystal,
  tablet, shell, fern, fish, flint point, coin, skull and potsherd, each in three colourways, with its details (the
  amber's inclusion, the tablet's script, the coin's device, the fish's pose) re-seeded for every find. Each lies in its
  own footprint of cells: an ammonite takes 3 x 3, a coin one cell.
- **Eight rocks, each a different structure, not a recolour:** cross-bedded sandstone, laminated shale with partings,
  limestone full of fossil hash, mottled clay with rootlets, columnar basalt with gas vesicles, chalk with rows of flint
  nodules, ironstone with rusty concretions, and permafrost with ice lenses and hoarfrost. Six layers each, and the
  SECTION column beside the face shows all six.
- **The face reads its own depth.** A cut cell darkens with every layer taken, the walls of a cut cast their shadow into
  it, cracks spread across the face as the stress rises, and when it gives way the whole face slumps into rubble while
  stones fall from the top.
- **Your items, by name.** Pass your own item names (`"Gold Coin"`, `"Raptor Skull"`) and each becomes the find it reads
  as; the result tells you which of YOUR items were freed. No image file is loaded.

Ported from our RPG Maker MZ plugin Strata and held to it: the in-engine suite checks the generator, the rules and both
model diggers against the MZ edition's own code, site for site and blow for blow (see Verification).

## Install

1. In GameMaker, **Tools > Import Local Package**, choose `Strata.yymps`, and import everything.
2. Run the project with `rm_stra_demo` first in the room order. The demo is THE FIELD CAMP: eight test pits, one of each
   rock, with something showing in every one. Choose a pit and a grade with the arrows, 1 to 5 and Enter, or click, then
   dig. Whatever you free joins the camp's collection, and every visit to a pit opens a new site.

Requires GameMaker 2024.14 or later. Built and tested on runtime 2024.14.4.268 (the VM, Windows). Pure GML, no shader, no
extension; nothing here depends on GMRT.

## Quickstart

```gml
// Create - open a dig (the same seed always gives the same site)
my_inventory = [];
my_loot = ["Gold Coin", "Raptor Skull", "Amber Drop"];
my_dig = stra_open({ seed: "quarry-east", grade: 2, rock: "limestone", finds: my_loot });

// Step - run it; when the player leaves, give them what they freed
stra_step(my_dig, device_mouse_x_to_gui(0), device_mouse_y_to_gui(0));
if (stra_closed(my_dig)) {
    my_result = stra_result(my_dig);    // { found, total, freed, names, cleared, collapsed, left, ... }
    for (var i = 0; i < array_length(my_result.freed); i++) array_push(my_inventory, my_loot[my_result.freed[i]]);
    stra_free(my_dig);
    my_dig = undefined;
}

// Draw GUI - the scene is 816 x 624 at scale 1; draw it anywhere, at any scale
stra_draw(my_dig, 0, 0, 1);
```

`result.freed` holds indices into the `finds` list you passed, so `my_loot[i]` is the item to give. A dig has 2 to 4
finds depending on the grade; the list is read in order, and finds beyond it are chosen by the seed (their `names` entry
is then the family, `"coin"`). `stra_open` generates the site and draws everything it needs once, so open a dig behind
your own transition (see Performance). **Call `stra_open` and `stra_step` in Create or Step, never inside a Draw event or
while a surface of yours is the render target** (they draw into surfaces of their own). `stra_draw` only blits. Pass the
pointer to `stra_step` in the same coordinates you draw the scene in.

To key a dig to a place, give it a word; to let a place be dug only once, remember that you dug it and reopen it worked
out:

```gml
my_dig = stra_open({ seed: "mine-3-east", grade: 4, worked: true });   // the same face, cut away, nothing left to find
```

### The request

```gml
{ seed: "quarry-east",        // a number or a word: the same site every time; "" or absent: a new site every time
  grade: 2,                   // 1 (forgiving) to 5 (hard)
  rock: "limestone",          // "sandstone", "shale", "limestone", "clay", "basalt", "chalk", "ironstone", "permafrost" or "auto"
  finds: my_loot,             // your item names (or family ids), one per find, in order; [] or absent: the seed chooses
  title: "",                  // the heading above the face; "" names it after the rock ("The Limestone Quarry")
  worked: false,              // true: the face opens already cut away, nothing left to find
  allow_leave: true,          // false: Escape is refused
  detail: 1,                  // 2 draws every sheet at twice the resolution, for drawing the scene above scale 1
  sound: my_sound_hook }      // optional: function(name) called with "pick", "hammer", "tool", "free", "collapse", "done"
```

How a name becomes a find (`stra_family_for(name)`): the words of the name are read, whole words only, and the first
rule that matches wins, in this order: coin, skull, fern, fish, flint point, potsherd, ammonite, trilobite, amber, geode,
crystal, ore, bone, tooth, shell, tablet. `"Gold Coin"` is a coin, `"Iron Ore"` ore, `"Dragon Fang"` a tooth,
`"Ancient Glyphs"` a tablet; `"Health Potion"` is not a pot and `"Lore Tablet"` is not ore. A family id (`"ammonite"`)
works as a name. A name that says nothing is drawn as a find of the site's own choosing.

### Grades

| Grade | Finds | Bedrock stones | Sighted digs that clear the face |
| --- | --- | --- | --- |
| 1 | 2 | 1 to 2 | 88% |
| 2 | 2 to 3 | 2 to 3 | 80% |
| 3 | 3 | 2 to 4 | 58% |
| 4 | 3 to 4 | 3 to 4 | 40% |
| 5 | 4 | 3 to 5 | 27% |

The last column is measured by the suite: per grade, 60 digs on 12 fresh sites by a model of an attentive player who
cannot see underground (`stra_prospect`). Every site is proven clearable within its stability by a digger who knows where
everything is (`stra_greedy_plan`).

### Controls

- **Arrow keys** move the mark. **Enter, Space or Z** strikes. **Q, W, Tab or Shift** changes tool.
- **Pick**: 2 layers at the target, 1 on the four cells beside it, stress 2. **Hammer**: 2 layers at the target and
  beside it, 1 on the diagonals, stress 4. The mark shows the tool's reach.
- **Mouse or touch**: the mark follows the pointer over the face; click a cell to strike it, click a tool to take it,
  right-click to change tool. On mobile exports a first finger reads as GameMaker's mouse (device 0); we have only built
  and tested Windows.
- **Escape** packs up and leaves, keeping every find that is already free (when `allow_leave` is true). On the results,
  **Enter, Space, Z or a click** leaves.

## Reference

**The scene** (`stra_open` once, then every frame `stra_step` in Step and `stra_draw` in Draw or Draw GUI)
- `stra_open(request)` - open a dig; returns the scene struct, or undefined when the request is not a struct.
- `stra_step(scene, [mouse_x], [mouse_y])` - one frame: input, the blow, dust, falling rubble, glints, and a redraw of
  whatever changed.
- `stra_draw(scene, x, y, scale)` - draw it with its top-left at (x, y), 816 x 624 times scale.
- `stra_closed(scene)` - true once the player has left (after the results, or on Escape).
- `stra_result(scene)` - once the dig is over: `{ found, total, freed, families, names, cleared, collapsed, left, worked,
  blows, stress, stability, seed, grade, rock }`; undefined while digging.
- `stra_free(scene)` - free every surface and sprite it made. Safe twice.
- Fields you may set: `scene.inject` (scripted input for ONE frame: `{ dx, dy }` to move the mark, `{ strike: true, col,
  row }` to strike a cell, `{ tool: "pick" }`, `"hammer"` or `"switch"`, `{ leave: true }`, `{ ok: true }` - for a
  tutorial, a replay or an attract mode).

**The rules on their own** (pure GML, no drawing; a face is 13 x 10 cells, a cell is `row * 13 + col`)
- `stra_generate({ seed, grade, site, families })` - a site as plain data: `{ cols, rows, depth[], rock[], finds[],
  stability, site, grade, seed, ... }`, each find `{ family, rot, x, y, w, h, cells[], variant }`. `stra_is_site(value)`
  tells a site from anything else.
- `stra_start(site)` - a fresh play state `{ depth[], stress, blows, collapsed }`.
- `stra_strike(site, state, tool, col, row)` - one blow; returns `{ changed[], collapsed, freed[] }`.
- `stra_freed_list(site, state)` - the finds whose every cell is cleared. `stra_find_at(site, cell)` - the find under a
  cell, or -1.
- `stra_greedy_plan(site)` - the digger who knows where everything is: `{ clearedAll, stress, blows, plan[] }`;
  `stra_replay(site, plan)` plays a plan under the budget. `stra_prospect(site, gen)` - the sighted digger: `{ stress,
  blows }`.
- `stra_families()`, `stra_sites()`, `stra_tools()`, `stra_footprint(family, rot)`, `stra_family_for(name)`.
- `stra_hash_string(text)` - the 32-bit seed of a word. `stra_rng(seed)` and `stra_rand(gen)` - the seeded generator.

**Drawing directly** (into a `stra_cx_create(scale)` context, onto whatever SURFACE is the current target, from Create or
Step). Each call sets the package's blend for itself and hands yours back.
- `stra_find_sprite(family, variant, size)` - a find drawn into a new size x size sprite, for an inventory icon, a codex
  or a reward screen; you free it with `sprite_delete`.
- `stra_draw_find(ctx, find)` - one find at the context's origin, filling its footprint at 40 px a cell.
- `stra_draw_bedrock(ctx, col, row, seed)`, `stra_draw_under(ctx, rock, w, h, seed)`, `stra_draw_frame(ctx, x, y, w, h,
  seed)`, `stra_draw_gauge(ctx, w, share, seed)`, `stra_draw_tool(ctx, tool, radius, active)`, `stra_draw_backdrop(ctx,
  w, h)` - the stones, the bed, the timbered frame, the stability plank, a tool and the cave behind the scene.
- `stra_crack_net(seed, w, h)` - the crack network a face can grow, as segments `{ x0, y0, x1, y1, w, t }`.
- `stra_rock_names()` and `stra_rock_title(rock)`.

**The demo room** - `stra_demo_create()`, `stra_demo_step(demo)`, `stra_demo_draw(demo)`, `stra_demo_free(demo)`,
`stra_demo_pits()`, `stra_demo_grades()`: THE FIELD CAMP, the same four calls in `obj_stra_demo`.

## Performance

Measured on our test machine, a shared and busy one (runtime 2024.14.4.268, the VM, Windows), three runs. Yours will
differ.

- **Opening a dig costs about half a second, once** (0.45 to 0.5 s over three runs): generating the site (0.1 to 0.4 s
  depending on the site, as the greedy digger and 24 sighted digs prove it fair) and drawing its sheets, stones, rubble and
  panels. Open behind your own transition; the demo shows a "Surveying the face" card for a frame first.
- **A frame is cheap**: the face is redrawn only when a blow changes it and the panels only when a number changes.

## Fonts

The scene is lettered in two faces rasterised into font resources: Cinzel Bold (the headings and figures) and Alegreya
(the rest), both SIL Open Font License 1.1. The licence texts and the notices are in `Strata/fonts/`. The atlases carry
printable ASCII (32 to 126); any other character is measured as nothing and not drawn.

## Differences from the RPG Maker MZ edition

- **More to find and more to dig.** The MZ edition has ten families and five rocks; this edition adds fern, fish, flint
  point, coin, skull and potsherd, and chalk, ironstone and permafrost, each rock with a structure of its own.
- **More on the face.** Cracks spread across the face itself (the MZ edition shows them on the gauge only), cuts are
  shaded by depth, the face slumps into rubble when it gives way, and the scene adds the SECTION column, the LEDGER and a
  results card showing what came out.
- **Names are read by whole words**, so a name that only contains a keyword says nothing.
- **Saving is yours.** The MZ edition writes into RPG Maker variables, switches and its own save record; here the scene
  hands back a result, and `worked: true` reopens a face your game remembers digging.
- **Sounds are a hook** (`sound(name)`) instead of RPG Maker sound-effect names; the package plays nothing itself.
- **Type.** The MZ edition draws in a Georgia and Palatino stack, system fonts no package may ship; this one ships Cinzel
  Bold and Alegreya.

## Verification

GameMaker code cannot be unit-tested outside the engine, so everything below ran in real executables built by GameMaker's
own compiler (Igor, runtime 2024.14.4.268):

- **The rules, held to the RPG Maker MZ edition run in Node:** the seed hash and 72 generator draws; 49 generated sites
  (every grade on seven seeds, every rock forced, six lists of families forced), each compared field for field with
  every find, the stability and both diggers' figures; 400 scripted blows on ten of them, each compared cell for cell; 4
  greedy plans; 12 sighted digs. Every one exact.
- **The pictures:** all 48 finds (16 families in three variants) inked, and no two families drawing the same picture; the
  six layers of all eight rocks, each carrying structure; the crack network.
- **The scene:** opened with item names, the mark following the pointer, the tools switched, a whole dig played by
  scripted input and checked blow for blow against the rules, the results card, a collapse, Escape, `allow_leave` false,
  `worked: true`, the same seed giving the same site, detail 2, a surface lost and rebuilt, and the scene opaque in a
  surface of your own; every rock dug to half its stability.
- **The demo room:** the camp drawn, a pit opened by keys and cleared, its finds in the collection, another packed up.
- **A blank project** that installed the package the way you will and ran this Readme's own code, with ink counted on
  everything it drew; and an adversarial pass of the documented functions (undefined, negative, huge and wrong-typed
  arguments) with zero crashes.

Two things this does not prove, stated plainly: the timings come from one shared machine and will differ on yours, and
the suite ran on Windows with the VM runtime only (other targets and YYC were not built).

## Licence

See `LICENSE.txt`. Use it in unlimited games, commercial or free; modify it freely; do not resell the package itself.

Made by Core Systems Asset Factory. Written with AI assistance, disclosed on every store page that carries it.
