# Scales - Weighing Puzzles on a Drawn Brass Balance, for GameMaker

Sit your player at a money-changer's counter and give them a weighing puzzle to solve on a brass balance:

| puzzle | what it is |
| --- | --- |
| The counterfeit | a hoard of 3 to 13 coins, one of them false; find it (and, when you are not told, whether it is heavy or light) in the weighings allowed |
| The order | weigh out an exact amount of goods with a box of weights; a weight may go in either pan |

- **The counterfeiter answers every weighing.** The false coin is not chosen in advance: each weighing falls the worst
  way for the player (the way that loses the puzzle, if their weighing allowed one; otherwise the way that leaves the most
  possibilities), so a lucky guess never wins and the player has to find a real method. Every puzzle
  allows exactly the fewest weighings that always suffice (proven by the solver), and `scl_hint` gives a weighing that
  keeps the puzzle winnable from wherever the player stands.
- **Everything is drawn.** The walnut counter and green baize, the balance (stand, beam, fulcrum, pans on chains), the
  numbered coin tray and the fitted weight box, 90 coin designs (5 metals x 6 devices x 3 rims, each with a legend lettered
  round the rim), the bell weights stamped with their values, 8 kinds of goods heaped grain by grain, the mint card, the
  ledger, the brass plaques and two verdict plates: the false coin with a banker's test cut showing the base metal under
  its face, or the weighed packet sealed in wax. Nothing is an image file.
- **The beam swings.** A weighing releases the beam on a damped spring and the pans ride its ends; the ledger keeps every
  weighing with a little drawn balance showing how it fell.
- **A word chooses everything.** The seed can be a phrase (`"the bishop's hoard"`), and the same phrase always makes the
  same hoard, the same mint and the same order. Five sets of weights (ternary, doubling, apothecary's, spicer's,
  assayer's) and three difficulties.

Ported from our RPG Maker MZ plugin Scales and held to it: the in-engine suite runs the puzzles and every paint operation
of the drawing through both and checks they agree (see Verification).

## Install

1. In GameMaker, **Tools > Import Local Package**, choose `Scales.yymps`, and import everything.
2. Run the project with `rm_scl_demo` first in the room order. The demo is THE MONEY-CHANGER: three hoards and three
   orders laid out on the baize. Click a card (or walk the arrows and press Enter) to sit at the counter; the room shows
   "Setting out the scales" while the counter is drawn (under a second, see Performance). At the counter: click a coin or
   a weight (or move with the arrows and press Enter) to move it between the tray and the pans; Shift (or the Weigh
   plaque) weighs; "Name the false coin" and then a coin gives your answer; Esc goes back a step and leaves.

Requires GameMaker 2024.14 or later. Built and tested on runtime 2024.14.4.268 (the VM, Windows). Pure GML, no shader, no
extension; nothing here depends on GMRT.

## Quickstart

```gml
// Create - open a puzzle at the counter
my_counter = scl_open({ puzzle: "counterfeit", difficulty: "normal", seed: "the bishop's hoard", key: "chapter2|hoard" });

// Step - run the counter; when the player leaves it, read the result
scl_step(my_counter);
if (scl_closed(my_counter)) {
    my_result = my_counter.result;     // { value: 1 solved / 2 named the wrong coin / 0 left, won, weighings, ... }
    scl_free(my_counter);
    my_counter = undefined;
}

// Draw GUI - the counter is 816 x 624; draw it anywhere, at any scale
scl_draw(my_counter, 72, 8, 1);
```

`scl_open` draws everything once (the counter, the balance, the coins or weights, the card) and keeps them as sprites, so
open it behind your own transition (draw a "setting out" frame, then open on the next Step, as `scl_demo_step` does).
After that a frame costs a handful of sprites. The mouse is read in GUI coordinates, relative to where you draw the
counter. What a solved puzzle is worth is your game's business: `result` says how it ended, and the puzzle's record
remembers it was solved (reopen it and the counter shows its verdict).

### The request

```gml
{ puzzle: "measure",          // "counterfeit" | "measure"
  difficulty: "hard",         // "easy" | "normal" | "hard" | "auto" (chosen by the seed)
  coins: 12,                  // counterfeit only: 3 to 13 coins (0 or absent: chosen by the difficulty)
  seed: "the spice merchant", // a phrase or a number: the same seed, the same puzzle
  title: "The Spicer's Order",// optional: shown on the card (default: the mint's name, or the order)
  metal: "gold",              // optional, counterfeit: restyle the hoard - gold silver copper electrum bronze
  device: "tower",            //   star rosette cross sun crescent tower (the puzzle itself does not change)
  key: "market|spicer" }      // optional: where the puzzle's record lives (default: from the seed)
```

`scl_request(options)` turns these options into a request (the puzzle generated, the title chosen); `scl_open` accepts
either. The ids: `scl_metal_ids()`, `scl_device_ids()`, `scl_rim_ids()` (beaded milled rope), `scl_goods()` (saffron,
pepper, silver dust, salt, tea, cloves, myrrh, indigo) and `scl_weight_sets()`.

## Reference

**The counter** (`scl_open` once, then every frame `scl_step` in Step and `scl_draw` in Draw or Draw GUI)
- `scl_request(options)` - a request from the options above: `{ key, puzzle, title }`.
- `scl_open(request)` - sit the player at the counter; returns the counter struct.
- `scl_step(counter, [mouse_x], [mouse_y])` - one frame: input, the beam's swing, the verdict. Pass your own mouse
  position (in the same coordinates you draw in) if you do not draw in the GUI layer.
- `scl_draw(counter, [x], [y], [scale])` - draw it with its top-left at (x, y).
- `scl_closed(counter)` - true once the player has left the counter.
- `scl_free(counter)` - free every sprite it made (in Step or Clean Up, never in a Draw event).
- Fields you may set: `counter.sounds` (`{ place, weigh, win, lose }` - your sound asset ids, -1 for none),
  `counter.inject` (scripted input for one frame, in counter coordinates: `{ x, y, click }`, `{ shift: true }`,
  `{ cancel: true }` and so on - for a tutorial or a replay).
- `counter.result` - `{ value, won, weighings, key, kind, coin, dir }`: value 1 solved, 2 the wrong coin named, 0 left
  without an answer; `coin` (0-based) and `dir` (+1 heavy, -1 light) are the false coin once it is named.

**Records** (kept across puzzles; save them yourself)
- `scl_record(key)` - a puzzle's `{ done, won, tries }`.
- `scl_records_save()` / `scl_records_load(json)` - every record as a JSON string for your save file, and back.

**The puzzles on their own** (pure GML, no drawing)
- `scl_counterfeit([options])`, `scl_measure([options])` - a puzzle from `{ seed, difficulty, coins }`.
- `scl_new_game(puzzle)`, `scl_weigh(puzzle, game, L, R)` (coin indices on each pan; returns +1 left sank, 0 level, -1
  right sank), `scl_hint(puzzle, game)` (`{ L, R }` or undefined), `scl_accuse(puzzle, game, coin, dir)`,
  `scl_hypotheses(status)` (what the weighings still allow).
- `scl_new_measure(puzzle)`, `scl_measure_weigh(puzzle, game)`, `scl_measure_balance(puzzle, place)`.
- `scl_min_weighings(n, known)`, `scl_reach(weights)`, `scl_subset_sum(weights, target)`, `scl_mint(seed, [options])`,
  `scl_word(n)`, `scl_hash(text)`.

**Drawing directly** (into a `scl_cx_create(scale)` context, onto whatever surface is the current target)
- `scl_draw_table(ctx, w, h, [inlay])`, `scl_draw_stand(ctx)`, `scl_draw_beam(ctx)`, `scl_draw_fulcrum(ctx)`,
  `scl_draw_pan(ctx, [contents], [label])`, `scl_bal()` (the balance's geometry).
- `scl_draw_coin(ctx, cx, cy, r, mint, [options])` (`{ cut: 1 }` shows the test cut), `scl_draw_coin_flat(ctx, cx, cy, rx,
  mint)`, `scl_pile_coins(ctx, cx, rim_y, count, mint)`, `scl_draw_weight(ctx, cx, base_y, value, [options])`,
  `scl_draw_goods(ctx, cx, rim_y, goods, seed)`.
- `scl_draw_tray(ctx, n)`, `scl_tray_slots(n)`, `scl_draw_box(ctx, weights, set_name)`, `scl_box_slots(weights)`.
- `scl_draw_card(ctx, w, h, info)`, `scl_draw_ledger(ctx, w, h, info)`, `scl_draw_plaque(ctx, x, y, w, h, text, state)`,
  `scl_draw_status(ctx, w, h, text)`, `scl_draw_verdict(ctx, w, h, info)`.

## Performance - read this before opening a counter mid-frame

Measured on our test machine, a shared and busy one (runtime 2024.14.4.268, the VM, Windows). Yours will differ.

- **Opening the counter takes about 0.7 to 0.9 s** (the average over nine counters, three suite runs). `scl_open` draws
  everything once at twice the size, filtered down. The demo shows "Setting out the scales" for a frame first, then opens
  the counter on the next Step.
- **Moving a coin or a weight costs about 30 to 36 ms on average** over a whole suite run, most of it the first time a pan's
  contents or a plaque's state is drawn; those pictures are kept, so after the first time only the pan's paper tag is
  redrawn. Every other frame is a handful of sprites.
- **Generating a puzzle costs about 2 ms** (a counterfeit and a measure puzzle together, averaged over 50 of each).

## Fonts

The counter is lettered in two faces rasterised into font resources: Cinzel Bold (titles, plaques, coin legends,
weights) and Alegreya (the rest), both SIL Open Font License 1.1. The italic lines are Alegreya sheared in code. The
licence texts and the notices are in `Scales/fonts/`. The atlases carry printable ASCII (32 to 126) and the middle dot
(drawn as a disc at the face's own size); any other character is measured as nothing and not drawn.

## Verification

GameMaker code cannot be unit-tested outside the engine, so everything below ran in real executables built by GameMaker's
own compiler (Igor, runtime 2024.14.4.268):

- The puzzles, held to the RPG Maker MZ edition run in Node: the solver, the minimum weighings, the generators for both
  kinds, 213 counterfeit playout steps and 237 measure steps, every answer exact.
- The drawing: 195 drawings (the table, the balance in its parts, 6 pans, 94 coins covering all 90 designs and 2 test
  cuts, 26 weights, 16 heaps of goods, trays, weight boxes, cards, ledgers, plaques and both verdicts), 40,951 paint
  operations each compared with the MZ edition's on colour, alpha, width, path and transform: 0 differ. One difference
  is deliberate and applied to both sides: the card sets its title a few pixels narrower, so a long mint name stays
  inside the card's frame line.
- The counter: 13 whole puzzles played through `scl_open` / `scl_step` with scripted clicks and the Shift key (nine
  hoards across the three difficulties, four orders), every one of the 23 weighings replayed through the bare puzzle code
  with the same outcome; losing, leaving, reopening a solved puzzle and the records round trip.
- The demo room: built, a puzzle chosen, the counter opened centred, left, the room rebuilt, everything freed.

Two things this does not prove, stated plainly: the timings come from one shared machine and will differ on yours, and
the suite ran on Windows with the VM runtime only (other targets and YYC were not built).

## Licence

See `LICENSE.txt`. Use it in unlimited games, commercial or free; modify it freely; do not resell the package itself.

Made by Core Systems Asset Factory. Written with AI assistance, disclosed on every store page that carries it.
