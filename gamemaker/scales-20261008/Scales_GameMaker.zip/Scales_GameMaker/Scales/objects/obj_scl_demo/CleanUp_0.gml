/// @description Free every sprite the demo and its counter made. Runs even when Create left early (-selftest).
if (variable_instance_exists(id, "demo") && is_struct(demo)) scl_demo_free(demo);
demo = undefined;
