/// @description THE MONEY-CHANGER - Scales' demo room. Six puzzles on the baize; click one to sit at the counter and solve it.
/// Run with -selftest it is the headless test suite instead (writes scl_selftest.json and exits).
/// ⛔ The crash handler is installed FIRST, and every variable a later event reads is declared ABOVE the early exits:
/// Clean Up always runs, even when Create leaves early.
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("scl_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.scl_stage) + ": " + string(_ex.message) + " | " + string(_ex.stacktrace));
    file_text_close(_f);
    game_end();
});
global.scl_stage = 0;
demo = undefined;
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";
if (string_pos("-selftest", _args) > 0) { global.scl_stage = 1; scl_selftest_write(scl_selftest_run()); game_end(); exit; }
demo = scl_demo_create(display_get_gui_width(), display_get_gui_height());
