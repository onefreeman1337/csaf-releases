/// @description THE MONEY-CHANGER: the room, or the counter while a puzzle is open (scl_demo_step calls scl_step).
if (!is_struct(demo)) exit;
scl_demo_step(demo);
