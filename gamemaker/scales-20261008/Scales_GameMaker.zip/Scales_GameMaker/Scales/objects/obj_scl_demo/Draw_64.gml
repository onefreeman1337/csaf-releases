/// @description THE MONEY-CHANGER, drawn in the GUI layer (scl_demo_draw calls scl_draw while a puzzle is open).
if (!is_struct(demo)) exit;
scl_demo_draw(demo);
