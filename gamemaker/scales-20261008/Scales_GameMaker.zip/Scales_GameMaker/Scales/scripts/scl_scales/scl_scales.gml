/// scl_scales.gml - THE COUNTER: a weighing puzzle played at a money-changer's balance, start to verdict. One struct, three
/// calls: scl_open (once), scl_step (every Step), scl_draw (every Draw or Draw GUI); then read .result and scl_free.
/// Mouse and keyboard are read for you; every picture is drawn by the package (scl_draw) and kept as sprites.
///
/// Scales - Weighing Puzzles on a Drawn Brass Balance, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// The RPG Maker MZ edition's Scene_Scales (Scales.js), ported: the same modes, plaques, ledger, beam swing and verdict.
/// Differences, on purpose: the switch and variable an MZ event sets are YOUR game's business here - read .result when the
/// puzzle closes; sounds are optional asset ids (.sounds); the counter is drawn at any position and scale.
///
/// Public functions (each documented below): scl_request, scl_open, scl_step, scl_draw, scl_closed, scl_free, scl_record,
/// scl_records_save, scl_records_load, scl_word.

#macro SCL_W 816
#macro SCL_H 624
#macro SCL_SS 2

function scl__card_box() { static _B = { x: 560, y: 20, w: 240, h: 196 }; return _B; }
function scl__ledger_box() { static _B = { x: 560, y: 222, w: 240, h: 248 }; return _B; }
function scl__status_box() { static _B = { x: 552, y: 470, w: 256, h: 38 }; return _B; }
function scl__plaque_box() { static _B = { x: 564, y: 512, w: 228, h: 30, gap: 34 }; return _B; }

// ---------------------------------------------------------------------------------------------------------------
// Records and words
// ---------------------------------------------------------------------------------------------------------------

function scl__records() { static _R = { v: 1, puzzles: {} }; return _R; }

/// @function scl_record(key)
/// @description A puzzle's record { done, won, tries } (created on first ask). key = the request's key.
/// @returns {Struct}
function scl_record(_key) {
    var _P = scl__records().puzzles, _k = string(_key);
    if (!is_struct(_P[$ _k])) _P[$ _k] = { done: false, won: false, tries: 0 };
    return _P[$ _k];
}
/// @function scl_records_save()
/// @description Every puzzle record as a JSON string, for your save file.
/// @returns {String}
function scl_records_save() { return json_stringify(scl__records()); }
/// @function scl_records_load(json)
/// @description Restore what scl_records_save wrote. A string that is not a Scales record is refused (returns false).
/// @returns {Bool}
function scl_records_load(_json) {
    if (!is_string(_json)) return false;
    var _d = undefined;
    try { _d = json_parse(_json); } catch (_e) { return false; }
    if (!is_struct(_d) || !is_struct(_d[$ "puzzles"])) return false;
    scl__records().puzzles = _d.puzzles;
    return true;
}
/// @function scl_word(n)
/// @description "no", "one" ... "thirteen", else the number.
/// @returns {String}
function scl_word(_n) { var _W = ["no", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen"]; return (is_numeric(_n) && _n >= 0 && _n <= 13 && _n == floor(_n)) ? _W[_n] : string(_n); }

// ---------------------------------------------------------------------------------------------------------------
// Baking pictures: drawn through the kit at 2x, filtered down, kept as sprites
// ---------------------------------------------------------------------------------------------------------------

/// internal: a w x h sprite (origin ox, oy) of what painter(ctx, args) draws, supersampled 2x and filtered down; the sprite
/// is PREMULTIPLIED. Every internal pass runs under identity and the caller's world matrix is handed back.
function scl__bake(_w, _h, _ox, _oy, _painter, _args) {
    var _W = max(1, ceil(_w)), _H = max(1, ceil(_h));
    var _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_build_identity());
    var _s2 = surface_create(_W * SCL_SS, _H * SCL_SS), _s1 = surface_create(_W, _H);
    surface_set_target(_s2); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha); gpu_set_ztestenable(false); gpu_set_zwriteenable(false);
    var _c = scl_cx_create(SCL_SS);
    _painter(_c, _args);
    gpu_pop_state(); surface_reset_target();
    surface_set_target(_s1); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_zero); gpu_set_texfilter(true);
    draw_surface_ext(_s2, 0, 0, 1 / SCL_SS, 1 / SCL_SS, 0, c_white, 1);
    gpu_pop_state(); surface_reset_target();
    var _spr = sprite_create_from_surface(_s1, 0, 0, _W, _H, false, false, _ox, _oy);
    surface_free(_s2); surface_free(_s1);
    matrix_set(matrix_world, _mw);
    return _spr;
}
function scl__draw_spr(_spr, _x, _y, _a, _rot = 0) { if (is_numeric(_spr) && sprite_exists(_spr)) draw_sprite_ext(_spr, 0, _x, _y, 1, 1, _rot, merge_colour(c_black, c_white, _a), _a); }
function scl__swap(_T, _field, _spr) { var _o = _T[$ _field]; if (is_numeric(_o) && sprite_exists(_o)) array_push(_T.trash, _o); _T[$ _field] = _spr; }

// painters (ctx, args)
function scl__pnt_bg(_c, _a) { scl_draw_table(_c, SCL_W, SCL_H); scl_draw_stand(_c); if (_a.measure) scl_draw_box(_c, _a.p.weights, _a.p.set_name); else scl_draw_tray(_c, _a.p.n); }
function scl__pnt_beam(_c, _a) { scl_draw_beam(_c); }
function scl__pnt_fulcrum(_c, _a) { var _A = scl_bal(); scl_cx_translate(_c, 40 - _A.fx, 34 - _A.fy); scl_draw_fulcrum(_c); }
function scl__pnt_ring(_c, _a) { scl_draw_cursor(_c); }
function scl__pnt_card(_c, _a) { scl_draw_card(_c, _a.w, _a.h, _a.info); }
function scl__pnt_ledger(_c, _a) { scl_draw_ledger(_c, _a.w, _a.h, _a.info); }
function scl__pnt_status(_c, _a) { scl_draw_status(_c, _a.w, _a.h, _a.text); }
function scl__pnt_plaque(_c, _a) { scl_draw_plaque(_c, 8, 8, _a.w, _a.h, _a.label, _a.state); }
function scl__pnt_pan(_c, _a) { scl_draw_pan(_c, undefined, _a.label, _a.part); }
function scl__pnt_pan_in(_c, _a) { _a.contents(_c, SCL_PAN_HX, 6 + scl_bal().drop); }
function scl__pnt_verdict(_c, _a) { scl_draw_verdict(_c, SCL_W, SCL_H, _a.info); }

// ---------------------------------------------------------------------------------------------------------------
// Opening the counter
// ---------------------------------------------------------------------------------------------------------------

/// @function scl_request(options)
/// @description A puzzle request from options { puzzle ("counterfeit" | "measure"), difficulty ("easy" | "normal" | "hard"
/// | "auto"), coins (3..13, counterfeit only; 0 = by the difficulty), metal, device (restyle the hoard's mint without
/// changing the puzzle), title (shown on the card; default: the mint's name or the order), seed (a number, or a string
/// hashed; default: the key hashed), key (where the puzzle lives, for its record; default "scales|" + the seed text) }.
/// Returns { key, puzzle, title }.
/// @returns {Struct}
function scl_request(_opt) {
    var _q = is_struct(_opt) ? _opt : {};
    var _seedArg = _q[$ "seed"], _key = is_string(_q[$ "key"]) && _q.key != "" ? _q.key : "scales|" + (is_undefined(_seedArg) ? "" : string(_seedArg));
    var _seed = is_numeric(_seedArg) ? real(scl__u32(_seedArg)) : (is_string(_seedArg) && _seedArg != "" ? scl_hash(_seedArg) : scl_hash(_key));
    var _kind = (_q[$ "puzzle"] == "measure") ? "measure" : "counterfeit", _diff = is_string(_q[$ "difficulty"]) ? _q.difficulty : "normal";
    var _o = { seed: _seed, difficulty: (_diff == "auto") ? undefined : _diff, coins: is_numeric(_q[$ "coins"]) ? floor(_q.coins) : 0 };
    var _p = (_kind == "measure") ? scl_measure(_o) : scl_counterfeit(_o);
    var _metal = is_string(_q[$ "metal"]) ? _q.metal : "auto", _device = is_string(_q[$ "device"]) ? _q.device : "auto";
    if (_metal != "auto" || _device != "auto") _p.mint = scl_mint(_p.mint.seed, { metal: _metal, device: _device });
    var _title = (is_string(_q[$ "title"]) && _q.title != "") ? _q.title : ((_kind == "measure") ? string(_p.target) + " drams of " + _p.goods : _p.mint.name);
    return { key: _key, puzzle: _p, title: _title };
}

/// @function scl_open(request)
/// @description Sit the player at the counter. request = what scl_request returns, or its options directly. Everything is
/// drawn here once (supersampled - an OPENING cost; open it behind your own transition). Returns the counter struct.
/// @returns {Struct}
function scl_open(_req) {
    var _r = (is_struct(_req) && is_struct(_req[$ "puzzle"])) ? _req : scl_request(_req);
    var _p = _r.puzzle, _measure = (_p.kind == "measure"), _n = _measure ? array_length(_p.weights) : _p.n;
    var _T = { req: _r, p: _p, measure: _measure, rec: scl_record(_r.key), game: _measure ? scl_new_measure(_p) : scl_new_game(_p),
        pos: array_create(_n, 0), items: _n, cursor: 0, mode: "play", theta: 0, omega: 0, target: 0, frame: 0, verdictT: 0, verdictA: 0,
        statusText: "", plaqueKey: "", panKeyL: undefined, panKeyR: undefined, pick: -1, last: 0, outcome: undefined, verdictInfo: undefined,
        result: undefined, closed: false, x: 0, y: 0, scale: 1, inject: undefined, rep: { left: 0, right: 0, up: 0, down: 0 }, inp: undefined,
        sounds: { place: -1, weigh: -1, win: -1, lose: -1 }, trash: [], ringOn: false, ringX: 0, ringY: 0,
        bg: -1, beam: -1, ful: -1, ring: -1, card: -1, ledger: -1, status: -1, verdict: -1, coin: -1, markL: -1, markR: -1, wts: [],
        panBack: -1, panFront: -1, panCL: -1, panCR: -1, panTL: -1, panTR: -1, pq: {}, pqNow: [-1, -1, -1], sc: {}, pc: {} };
    _T.bg = scl__bake(SCL_W, SCL_H, 0, 0, scl__pnt_bg, { measure: _measure, p: _p });
    // a pan is four pictures: the chains and dish back, then what lies in it, then the bowl and lip (both baked once), then
    // its tag - so a click re-draws only the contents and the tag, never the ~70 chain links
    _T.panBack = scl__bake(SCL_PAN_W, SCL_PAN_H, 0, 0, scl__pnt_pan, { label: "", part: 1 });
    _T.panFront = scl__bake(SCL_PAN_W, SCL_PAN_H, 0, 0, scl__pnt_pan, { label: "", part: 2 });
    _T.beam = scl__bake(SCL_BEAM_W, SCL_BEAM_H, SCL_BEAM_OX, SCL_BEAM_OY, scl__pnt_beam, {});
    _T.ful = scl__bake(80, 60, 0, 0, scl__pnt_fulcrum, {});
    _T.ring = scl__bake(76, 76, 38, 38, scl__pnt_ring, {});
    var _C = scl__card_box();
    _T.card = scl__bake(_C.w, _C.h, 0, 0, scl__pnt_card, { w: _C.w, h: _C.h, info: scl__card_info(_r) });
    scl__refresh_pans(_T); scl__bake_items(_T); scl__refresh_ledger(_T); scl__place_cursor(_T); scl__apply_beam(_T);
    scl__set_status(_T, _measure ? "OK moves a weight. Shift weighs. Esc leaves." : "OK moves a coin. Shift weighs. Esc leaves.");
    if (_T.rec.won) scl__show_verdict(_T);
    return _T;
}
/// the card for a request: the mint card (counterfeit) or the order slip (measure)
function scl__card_info(_r) {
    var _p = _r.puzzle;
    if (_p.kind == "measure") return { kicker: "THE ORDER", goods: _p.goods, seed: _p.seed, title: _r.title, sub: _p.set_name + ": " + scl__join(_p.weights, ", "), task: "Weigh it out exactly. A weight may go in either pan." };
    return { kicker: "THE COUNTERFEIT", mint: _p.mint, title: _r.title, sub: scl_word(_p.n) + " " + _p.mint.unit + ", all alike", task: scl__task_text(_p) };
}
function scl__join(_a, _sep) { var _s = ""; for (var _i = 0; _i < array_length(_a); _i++) _s += ((_i > 0) ? _sep : "") + string(_a[_i]); return _s; }
function scl__task_text(_p) {
    var _k = scl_word(_p.weighings) + ((_p.weighings == 1) ? " weighing" : " weighings");
    if (_p.known) return "One is false and " + ((_p.dir > 0) ? "HEAVIER" : "LIGHTER") + " than the rest. Find it in " + _k + ".";
    return "One is false, heavier or lighter. Find it, and say which, in " + _k + ".";
}
function scl__play(_T, _which) { var _id = _T.sounds[$ _which]; if (is_numeric(_id) && _id >= 0 && audio_exists(_id)) audio_play_sound(_id, 1, false); }

// ---------------------------------------------------------------------------------------------------------------
// What is where
// ---------------------------------------------------------------------------------------------------------------

/// coin (or weight) indices on a side: 1 left, 2 right
function scl__on_side(_T, _side) { var _out = []; for (var _i = 0; _i < array_length(_T.pos); _i++) if (_T.pos[_i] == _side) array_push(_out, _i); return _out; }
/// the item positions the cursor can visit: tray / box slots, then the plaques
function scl__item_xy(_T, _i) {
    var _P = scl__plaque_box();
    if (_i < _T.items) { if (_T.measure) { var _s = scl_box_slots(_T.p.weights)[_i]; return { x: _s.x, y: _s.y - 24 }; } return scl_tray_slots(_T.p.n)[_i]; }
    var _k = _i - _T.items; return { x: _P.x + _P.w / 2, y: _P.y + _k * _P.gap + _P.h / 2 };
}
function scl__plaque_labels(_T) {
    if (_T.mode == "dir") return ["Heavier", "Lighter", "Back"];
    if (_T.measure) return ["Weigh", "Clear the pans", "Leave the counter"];
    return ["Weigh", "Clear the pans", (_T.mode == "accuse") ? "Back" : "Name the false coin"];
}
function scl__can_weigh(_T) {
    if (_T.mode != "play") return false;
    if (_T.measure) return !_T.game.over;
    var _L = array_length(scl__on_side(_T, 1)); return _T.game.left > 0 && _L > 0 && _L == array_length(scl__on_side(_T, 2));
}
function scl__plaque_state(_T, _k) {
    if (_T.mode == "dir") return (_T.cursor == _T.items + _k) ? "on" : "idle";
    var _on = (_T.cursor == _T.items + _k);
    if (_k == 0 && !scl__can_weigh(_T)) return "off";
    if (_k == 1 && (_T.mode != "play" || (array_length(scl__on_side(_T, 1)) == 0 && array_length(scl__on_side(_T, 2)) == 0))) return "off";
    if (_k == 2 && !_T.measure && _T.mode != "play" && _T.mode != "accuse") return "off";
    return _on ? "on" : "idle";
}

// ---------------------------------------------------------------------------------------------------------------
// Redraws (only on change; a replaced sprite is deleted in the next Step, never while it may be queued to draw)
// ---------------------------------------------------------------------------------------------------------------

function scl__refresh_pans(_T) {
    var _p = _T.p, _L = scl__on_side(_T, 1), _R = scl__on_side(_T, 2);
    var _kl = scl__join(_L, ","), _kr = scl__join(_R, ","), _doL = (_kl != _T.panKeyL), _doR = (_kr != _T.panKeyR);
    _T.panKeyL = _kl; _T.panKeyR = _kr;
    if (!_doL && !_doR) return;
    var _sep = _T.measure ? " + " : " " + chr(183) + " ";
    var _label = function(_T2, _list, _sep2) { var _t = []; for (var _i = 0; _i < array_length(_list); _i++) array_push(_t, _T2.measure ? _T2.p.weights[_list[_i]] : _list[_i] + 1); return scl__join(_t, _sep2); };
    var _contL = undefined, _contR = undefined, _labL = "", _labR = "";
    if (_T.measure) {
        _contL = method({ p: _p, list: _L }, function(_c, _cx, _rimY) {
            if (array_length(list) > 0) { scl_cx_save(_c); scl_cx_translate(_c, _cx - 26, _rimY); scl_cx_scale(_c, 0.78, 0.78); scl_draw_goods(_c, 0, 0, p.goods, p.seed); scl_cx_restore(_c); scl__stand(_c, p, _rimY, list, _cx + 2, 60); }
            else scl_draw_goods(_c, _cx, _rimY, p.goods, p.seed);
        });
        _labL = (array_length(_L) > 0) ? "goods + " + _label(_T, _L, _sep) : string(_p.target) + " drams of " + _p.goods;
        if (array_length(_R) > 0) _contR = method({ p: _p, list: _R }, function(_c, _cx, _rimY) { scl__stand(_c, p, _rimY, list, _cx - 64, 128); });
        _labR = (array_length(_R) > 0) ? _label(_T, _R, _sep) : "the far pan";
    } else {
        if (array_length(_L) > 0) _contL = method({ m: _p.mint, n: array_length(_L) }, function(_c, _cx, _rimY) { scl_pile_coins(_c, _cx, _rimY, n, m); });
        if (array_length(_R) > 0) _contR = method({ m: _p.mint, n: array_length(_R) }, function(_c, _cx, _rimY) { scl_pile_coins(_c, _cx, _rimY, n, m); });
        _labL = (array_length(_L) > 0) ? _label(_T, _L, _sep) : ""; _labR = (array_length(_R) > 0) ? _label(_T, _R, _sep) : "";
    }
    // what lies in a pan is kept by side and contents (a pile depends only on its count; a stand of weights on which weights),
    // so a coin moved back and forth costs nothing the second time; the tag is re-drawn, but only its own strip
    var _ck = _T.measure ? undefined : array_length(_L), _ckr = _T.measure ? undefined : array_length(_R);
    if (_doL) { _T.panCL = scl__pan_contents(_T, "L" + (_T.measure ? _kl : string(_ck)), _contL); scl__swap(_T, "panTL", scl__pan_tag(_labL)); }
    if (_doR) { _T.panCR = scl__pan_contents(_T, "R" + (_T.measure ? _kr : string(_ckr)), _contR); scl__swap(_T, "panTR", scl__pan_tag(_labR)); }
}
function scl__pan_contents(_T, _key, _cont) {
    if (is_undefined(_cont)) return -1;
    var _s = _T.pc[$ _key];
    if (!(is_numeric(_s) && sprite_exists(_s))) { _s = scl__bake(SCL_PAN_W, SCL_PAN_H, 0, 0, scl__pnt_pan_in, { contents: _cont }); _T.pc[$ _key] = _s; }
    return _s;
}
#macro SCL_TAG_Y 196
function scl__pan_tag(_label) { return (_label == "") ? -1 : scl__bake(SCL_PAN_W, SCL_PAN_H - SCL_TAG_Y, 0, -SCL_TAG_Y, scl__pnt_tag, { label: _label }); }
function scl__pnt_tag(_c, _a) { scl_cx_translate(_c, 0, -SCL_TAG_Y); scl_draw_pan(_c, undefined, _a.label, 3); }
/// weights standing in a pan, scaled so the row fits the span [x0, x0 + span] (a dish is 142 px across)
function scl__stand(_c, _p, _rimY, _list, _x0, _span) {
    var _ws = 0, _i; for (_i = 0; _i < array_length(_list); _i++) _ws += scl_weight_h(_p.weights[_list[_i]]) * 0.78 + 4;
    var _sc = min(0.8, _span / max(1, _ws)), _x = _x0 + (_span - _ws * _sc) / 2;
    for (_i = 0; _i < array_length(_list); _i++) { var _w = scl_weight_h(_p.weights[_list[_i]]) * 0.78 * _sc; scl_cx_save(_c); scl_cx_translate(_c, _x + _w / 2, _rimY + 3); scl_cx_scale(_c, _sc, _sc); scl_draw_weight(_c, 0, 0, _p.weights[_list[_i]]); scl_cx_restore(_c); _x += _w + 4 * _sc; }
}
/// the tray's (or box's) items are baked ONCE as sprites - one coin (every coin of a hoard looks alike), the L and R marks
/// left in an emptied recess, one sprite per weight - so moving an item redraws nothing; scl_draw places them each frame
function scl__bake_items(_T) {
    var _p = _T.p;
    if (_T.measure) {
        _T.wts = array_create(array_length(_p.weights), -1);
        for (var _i = 0; _i < array_length(_p.weights); _i++) _T.wts[_i] = scl__bake(120, 110, 60, 96, scl__pnt_weight, { v: _p.weights[_i] });
    } else {
        _T.coin = scl__bake(72, 72, 36, 36, scl__pnt_coin, { m: _p.mint });
        _T.markL = scl__bake(30, 30, 15, 15, scl__pnt_mark, { t: "L" }); _T.markR = scl__bake(30, 30, 15, 15, scl__pnt_mark, { t: "R" });
    }
}
function scl__pnt_weight(_c, _a) { scl_draw_weight(_c, 60, 96, _a.v); }
function scl__pnt_coin(_c, _a) { scl_draw_coin(_c, 36, 36, 23, _a.m, {}); }
function scl__pnt_mark(_c, _a) { scl__font(_c, 20, 3); scl__text_align(_c, 1, 1); _c.fill = scl__rgb([240, 225, 190], 0.5); scl__q_text(_c, _a.t, 15, 16); }
function scl__draw_items(_T) {
    var _p = _T.p, _i;
    if (_T.measure) { var _S = scl_box_slots(_p.weights); for (_i = 0; _i < array_length(_p.weights); _i++) if (_T.pos[_i] == 0) scl__draw_spr(_T.wts[_i], _S[_i].x, _S[_i].y, 1); return; }
    var _Ts = scl_tray_slots(_p.n);
    for (_i = 0; _i < _p.n; _i++) scl__draw_spr((_T.pos[_i] == 0) ? _T.coin : ((_T.pos[_i] == 1) ? _T.markL : _T.markR), _Ts[_i].x, _Ts[_i].y, 1);
}
function scl__ledger_text(_T, _e) {
    var _p = _T.p, _i, _a = [], _b = [];
    if (_T.measure) {
        for (_i = 0; _i < array_length(_e.place); _i++) { if (_e.place[_i] < 0) array_push(_a, _p.weights[_i]); else if (_e.place[_i] > 0) array_push(_b, _p.weights[_i]); }
        return "goods" + ((array_length(_a) > 0) ? " + " + scl__join(_a, " + ") : "") + "  v  " + ((array_length(_b) > 0) ? scl__join(_b, " + ") : "nothing");
    }
    for (_i = 0; _i < array_length(_e.L); _i++) array_push(_a, _e.L[_i] + 1);
    for (_i = 0; _i < array_length(_e.R); _i++) array_push(_b, _e.R[_i] + 1);
    return scl__join(_a, chr(183)) + "  v  " + scl__join(_b, chr(183));
}
function scl__refresh_ledger(_T) {
    var _L = scl__ledger_box(), _g = _T.game, _E = [], _i;
    for (_i = 0; _i < array_length(_g.log); _i++) array_push(_E, { text: scl__ledger_text(_T, _g.log[_i]), o: _g.log[_i].o });
    var _info = _T.measure ? { allowed: 0, left: 0, headline: "Weighings: " + string(array_length(_g.log)) + "   fewest weights: " + string(_T.p.fewest), entries: _E, empty: "Nothing weighed yet." }
        : { allowed: _T.p.weighings, left: _g.left, entries: _E, empty: "No weighings yet." };
    scl__swap(_T, "ledger", scl__bake(_L.w, _L.h, 0, 0, scl__pnt_ledger, { w: _L.w, h: _L.h, info: _info }));
}
function scl__refresh_plaques(_T) {
    var _P = scl__plaque_box(), _labels = scl__plaque_labels(_T), _key = _T.mode + "|" + string(_T.cursor) + "|", _st = [];
    for (var _k = 0; _k < 3; _k++) { array_push(_st, scl__plaque_state(_T, _k)); _key += _labels[_k] + _st[_k]; }
    if (_key == _T.plaqueKey) return;
    _T.plaqueKey = _key;
    // each plaque picture is kept by label and state (a handful in all), so a change after the first costs nothing
    for (var _i = 0; _i < 3; _i++) {
        var _pk = _labels[_i] + "|" + _st[_i], _s = _T.pq[$ _pk];
        if (!(is_numeric(_s) && sprite_exists(_s))) { _s = scl__bake(_P.w + 20, _P.h + 16, 0, 0, scl__pnt_plaque, { w: _P.w, h: _P.h, label: _labels[_i], state: _st[_i] }); _T.pq[$ _pk] = _s; }
        _T.pqNow[_i] = _s;
    }
}
/// the status line; its pictures are kept by text (the counter says a bounded set of things)
function scl__set_status(_T, _t) {
    if (_t == _T.statusText) return;
    _T.statusText = _t;
    var _s = _T.sc[$ _t];
    if (!(is_numeric(_s) && sprite_exists(_s))) { var _S = scl__status_box(); _s = scl__bake(_S.w, _S.h, 0, 0, scl__pnt_status, { w: _S.w, h: _S.h, text: _t }); _T.sc[$ _t] = _s; }
    _T.status = _s;
}
function scl__place_cursor(_T) {
    _T.ringOn = (_T.cursor < _T.items) && (_T.mode == "play" || _T.mode == "accuse");
    if (_T.ringOn) { var _xy = scl__item_xy(_T, _T.cursor); _T.ringX = _xy.x; _T.ringY = _xy.y; }
    scl__refresh_plaques(_T);
}

// ---------------------------------------------------------------------------------------------------------------
// The beam: a damped swing toward the target angle; the pans hang from its ends
// ---------------------------------------------------------------------------------------------------------------

function scl__apply_beam(_T) { var _A = scl_bal(), _c = cos(_T.theta), _s = sin(_T.theta); _T.panLx = _A.fx - _c * _A.arm - SCL_PAN_HX; _T.panLy = _A.fy - _s * _A.arm - 6; _T.panRx = _A.fx + _c * _A.arm - SCL_PAN_HX; _T.panRy = _A.fy + _s * _A.arm - 6; }
function scl__update_beam(_T) {
    var _e = _T.theta - _T.target;
    if (abs(_e) < 0.0008 && abs(_T.omega) < 0.0008) { if (_T.theta != _T.target) { _T.theta = _T.target; _T.omega = 0; scl__apply_beam(_T); } return false; }
    _T.omega += -0.018 * _e - 0.11 * _T.omega; _T.theta += _T.omega; scl__apply_beam(_T); return true;
}

// ---------------------------------------------------------------------------------------------------------------
// Per frame
// ---------------------------------------------------------------------------------------------------------------

/// @function scl_step(counter, [mouse_x], [mouse_y])
/// @description One frame: input, the beam's swing, the verdict. Pass your own mouse position (in the coordinates you
/// draw in) if you do not draw in the GUI layer. counter.inject = { x, y, click, rclick, ok, cancel, shift, left, right,
/// up, down } (counter coordinates) scripts one frame's input - for a tutorial, a replay or a test.
function scl_step(_T, _mx = undefined, _my = undefined) {
    if (!is_struct(_T) || _T.closed) return;
    _T.frame++;
    for (var _d = 0; _d < array_length(_T.trash); _d++) if (sprite_exists(_T.trash[_d])) sprite_delete(_T.trash[_d]);
    _T.trash = [];
    var _gx = is_numeric(_mx) ? _mx : device_mouse_x_to_gui(0), _gy = is_numeric(_my) ? _my : device_mouse_y_to_gui(0), _k = (_T.scale > 0) ? _T.scale : 1;
    _T.inp = scl__input(_T, (_gx - _T.x) / _k, (_gy - _T.y) / _k);
    var _ij = _T[$ "inject"];
    if (is_struct(_ij)) {
        var _f = ["x", "y", "click", "rclick", "ok", "cancel", "shift", "left", "right", "up", "down"];
        for (var _i = 0; _i < array_length(_f); _i++) _T.inp[$ _f[_i]] = is_undefined(_ij[$ _f[_i]]) ? ((_i < 2) ? -1000 : false) : _ij[$ _f[_i]];
        _T.inject = undefined;
    }
    var _moving = scl__update_beam(_T);
    switch (_T.mode) {
        case "play": case "accuse": case "dir": scl__update_input(_T); break;
        case "swing": if (!_moving) scl__after_swing(_T); break;
        case "reveal": _T.verdictT++; _T.verdictA = min(255, floor(_T.verdictT * 255 / 24 + 0.5)) / 255; if (_T.verdictT >= 30) { _T.mode = "done"; scl__set_status(_T, (is_struct(_T.verdictInfo) && _T.verdictInfo.won) ? "Solved." : "The counterfeiter wins this time."); } break;
        case "done": if (_T.inp.ok || _T.inp.cancel || _T.inp.click || _T.inp.rclick) scl__leave(_T); break;
    }
}
function scl__input(_T, _x, _y) {
    var _in = { x: _x, y: _y, click: mouse_check_button_pressed(mb_left), rclick: mouse_check_button_pressed(mb_right),
        ok: keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("Z")),
        cancel: keyboard_check_pressed(vk_escape) || keyboard_check_pressed(vk_backspace) || keyboard_check_pressed(ord("X")),
        shift: keyboard_check_pressed(vk_shift) };
    var _keys = [["left", vk_left], ["right", vk_right], ["up", vk_up], ["down", vk_down]];
    for (var _i = 0; _i < 4; _i++) { var _nm = _keys[_i][0]; _T.rep[$ _nm] = keyboard_check(_keys[_i][1]) ? _T.rep[$ _nm] + 1 : 0; var _n = _T.rep[$ _nm]; _in[$ _nm] = (_n == 1) || (_n > 24 && ((_n - 24) mod 6) == 0); }
    return _in;
}
/// the cursor's next item in a direction: the nearest item that way, preferring the same line
function scl__nearest(_T, _dx, _dy) {
    var _here = scl__item_xy(_T, _T.cursor), _best = -1, _bestScore = 1000000000, _n = _T.items + 3;
    for (var _i = 0; _i < _n; _i++) {
        if (_i == _T.cursor || !scl__selectable(_T, _i)) continue;
        var _xy = scl__item_xy(_T, _i), _px = (_xy.x - _here.x) * _dx + (_xy.y - _here.y) * _dy, _sx = abs((_xy.x - _here.x) * _dy) + abs((_xy.y - _here.y) * _dx);
        if (_px <= 8) continue;
        var _score = _px + _sx * 2.5; if (_score < _bestScore) { _bestScore = _score; _best = _i; }
    }
    return _best;
}
function scl__selectable(_T, _i) { if (_T.mode == "dir") return _i >= _T.items; if (_T.mode == "accuse") return _i < _T.items || _i == _T.items + 2; return true; }
function scl__move_cursor(_T, _i) { if (_i < 0 || _i == _T.cursor) return; _T.cursor = _i; scl__place_cursor(_T); }
function scl__update_input(_T) {
    var _in = _T.inp, _t = -1;
    if (_in.left) _t = scl__nearest(_T, -1, 0); else if (_in.right) _t = scl__nearest(_T, 1, 0); else if (_in.up) _t = scl__nearest(_T, 0, -1); else if (_in.down) _t = scl__nearest(_T, 0, 1);
    if (_t >= 0) scl__move_cursor(_T, _t);
    if (_in.ok) { scl__activate(_T, _T.cursor); return; }
    if (_in.shift && _T.mode == "play") { scl__weigh(_T); return; }
    if (_in.cancel || _in.rclick) { scl__back(_T); return; }
    if (_in.click) { var _hit = scl__item_at(_T, _in.x, _in.y); if (_hit >= 0 && scl__selectable(_T, _hit)) { scl__move_cursor(_T, _hit); scl__activate(_T, _hit); } }
}
function scl__item_at(_T, _x, _y) {
    var _P = scl__plaque_box(), _i;
    for (_i = 0; _i < 3; _i++) if (_x >= _P.x && _x < _P.x + _P.w && _y >= _P.y + _i * _P.gap && _y < _P.y + _i * _P.gap + _P.h) return _T.items + _i;
    for (_i = 0; _i < _T.items; _i++) { var _xy = scl__item_xy(_T, _i), _r = _T.measure ? 32 : 28; if ((_x - _xy.x) * (_x - _xy.x) + (_y - _xy.y) * (_y - _xy.y) <= _r * _r) return _i; }
    return -1;
}
function scl__back(_T) {
    if (_T.mode == "dir") { _T.mode = "accuse"; _T.cursor = _T.pick; scl__set_status(_T, "Which coin is false?"); scl__place_cursor(_T); return; }
    if (_T.mode == "accuse") { _T.mode = "play"; scl__set_status(_T, "OK moves a coin. Shift weighs. Esc leaves."); scl__place_cursor(_T); return; }
    scl__leave(_T);
}
function scl__activate(_T, _i) {
    var _k = _i - _T.items;
    if (_T.mode == "dir") { if (_k == 0) scl__accuse(_T, _T.pick, 1); else if (_k == 1) scl__accuse(_T, _T.pick, -1); else scl__back(_T); return; }
    if (_T.mode == "accuse") {
        if (_k == 2) { scl__back(_T); return; }
        if (_i < _T.items) { _T.pick = _i; if (_T.p.known) scl__accuse(_T, _i, _T.p.dir); else { _T.mode = "dir"; _T.cursor = _T.items; scl__set_status(_T, "Coin " + string(_i + 1) + ": heavier or lighter?"); scl__place_cursor(_T); } }
        return;
    }
    if (_i < _T.items) { scl__move_item(_T, _i); return; }
    if (_k == 0) scl__weigh(_T);
    else if (_k == 1) scl__clear_pans(_T);
    else if (_T.measure) scl__leave(_T);
    else { _T.mode = "accuse"; _T.cursor = 0; scl__set_status(_T, "Which coin is false?"); scl__place_cursor(_T); }
}
/// OK on a coin: tray -> left -> right -> tray. On a weight: box -> far (right) -> goods (left) -> box.
function scl__move_item(_T, _i) {
    var _c = _T.pos[_i];
    _T.pos[_i] = _T.measure ? ((_c == 0) ? 2 : ((_c == 2) ? 1 : 0)) : ((_c == 0) ? 1 : ((_c == 1) ? 2 : 0));
    scl__pan_changed(_T); scl__play(_T, "place");
}
function scl__clear_pans(_T) { var _any = false; for (var _i = 0; _i < array_length(_T.pos); _i++) if (_T.pos[_i] != 0) { _T.pos[_i] = 0; _any = true; } if (_any) { scl__pan_changed(_T); scl__play(_T, "place"); } }
/// the pans changed: the arrest takes the beam back to level, and the pans and tray are redrawn
function scl__pan_changed(_T) {
    _T.target = 0; scl__refresh_pans(_T); scl__refresh_plaques(_T);
    var _L = array_length(scl__on_side(_T, 1)), _R = array_length(scl__on_side(_T, 2));
    if (!_T.measure) scl__set_status(_T, (_L != 0 || _R != 0) ? ((_L == _R) ? string(_L) + " against " + string(_R) + ". Shift weighs." : "The pans must hold the same number of coins.") : "OK moves a coin. Shift weighs. Esc leaves.");
}
function scl__weigh(_T) {
    if (!scl__can_weigh(_T)) { if (!_T.measure && _T.game.left <= 0) scl__set_status(_T, "No weighings left. Name the false coin."); return; }
    // the pans are copied into the puzzle before each weighing: the far (right) pan counts +1, the goods (left) pan -1
    if (_T.measure) for (var _i = 0; _i < array_length(_T.pos); _i++) _T.game.place[_i] = (_T.pos[_i] == 2) ? 1 : ((_T.pos[_i] == 1) ? -1 : 0);
    var _o = _T.measure ? scl_measure_weigh(_T.p, _T.game) : scl_weigh(_T.p, _T.game, scl__on_side(_T, 1), scl__on_side(_T, 2));
    if (is_undefined(_o)) return;
    // a level result still swings: the beam is released, rocks and comes to rest level
    _T.last = _o; _T.target = -_o * scl_bal().maxTilt; _T.omega += (_o == 0) ? 0.014 : -_o * 0.02;
    _T.mode = "swing"; scl__refresh_ledger(_T); scl__refresh_plaques(_T); scl__place_cursor(_T); scl__play(_T, "weigh");
    scl__set_status(_T, "The beam is released...");
}
function scl__after_swing(_T) {
    var _o = _T.last;
    if (_T.measure && _o == 0) { scl__finish(_T, true); return; }
    _T.mode = "play"; scl__place_cursor(_T);
    var _said = (_o > 0) ? "The left pan sank." : ((_o < 0) ? "The right pan sank." : "The beam holds level.");
    if (_T.measure) _said = (_o > 0) ? "The goods pan sank: too little on the far pan." : "The far pan sank: too much against the goods.";
    else if (_T.game.left <= 0) _said += " Name the false coin.";
    scl__set_status(_T, _said);
}
function scl__accuse(_T, _coin, _dir) { var _r = scl_accuse(_T.p, _T.game, _coin, _dir); _T.outcome = _r; scl__finish(_T, _r.won); }

// ---------------------------------------------------------------------------------------------------------------
// The verdict
// ---------------------------------------------------------------------------------------------------------------

function scl__finish(_T, _won) {
    var _rec = _T.rec;
    _rec.tries = (is_numeric(_rec[$ "tries"]) ? _rec.tries : 0) + 1;
    if (_won) {
        _rec.done = true; _rec.won = true; _rec.weighings = array_length(_T.game.log);
        if (is_struct(_T.outcome)) { _rec.coin = _T.outcome.coin; _rec.dir = _T.outcome.dir; }
        if (_T.measure) { var _last = _T.game.log[array_length(_T.game.log) - 1]; _rec.place = scl__copy(_last.place); _rec.used = _last.used; }
    }
    _T.result = { value: _won ? 1 : 2, won: _won, weighings: array_length(_T.game.log), key: _T.req.key, kind: _T.p.kind };
    if (is_struct(_T.outcome)) { _T.result.coin = _T.outcome.coin; _T.result.dir = _T.outcome.dir; }
    scl__play(_T, _won ? "win" : "lose");
    scl__draw_verdict_sprite(_T, _won); _T.verdictA = 0; _T.verdictT = 0; _T.mode = "reveal"; _T.ringOn = false; scl__refresh_plaques(_T);
}
function scl__draw_verdict_sprite(_T, _won) {
    var _p = _T.p, _info;
    if (_T.measure) {
        var _n = array_length(_T.game.log), _last = (_n > 0) ? _T.game.log[_n - 1] : undefined, _g = (_n > 0) ? _n : (is_numeric(_T.rec[$ "weighings"]) && _T.rec.weighings > 0 ? _T.rec.weighings : 1);
        var _used = is_struct(_last) ? _last.used : (is_numeric(_T.rec[$ "used"]) && _T.rec.used > 0 ? _T.rec.used : _p.fewest), _place = is_struct(_last) ? _last.place : (is_array(_T.rec[$ "place"]) ? _T.rec.place : _p.solution);
        _info = { goods: _p.goods, amount: _p.target, label: string(_p.target) + " drams of " + _p.goods, seed: _p.seed, weights: _p.weights, place: _place, won: true,
            title: _T.req.title + ", weighed out", sub: "in " + scl_word(_g) + ((_g == 1) ? " weighing" : " weighings") + " with " + scl_word(_used) + ((_used == 1) ? " weight" : " weights") + ((_used <= _p.fewest) ? " (the fewest there are)" : " (it can be done with " + scl_word(_p.fewest) + ")") };
    } else {
        var _rc = _T.rec[$ "coin"], _rd = _T.rec[$ "dir"];
        var _r = is_struct(_T.outcome) ? _T.outcome : { coin: is_numeric(_rc) ? _rc : 0, dir: is_numeric(_rd) ? _rd : 1, won: true }, _core = scl_core_of(_p.mint.metal, _r.dir), _k = array_length(_T.game.log);
        if (_k == 0 && is_numeric(_T.rec[$ "weighings"])) _k = _T.rec.weighings;
        _info = { mint: _p.mint, dir: _r.dir, won: _won, genuine: min(7, _p.n - 1),
            title: (_won ? "Found: " : "Not that one. It was ") + "No. " + string(_r.coin + 1) + ", " + ((_r.dir > 0) ? "heavier" : "lighter"),
            sub: (_won ? "In " + scl_word(_k) + ((_k == 1) ? " weighing" : " weighings") + ". " : "The weighings still allowed it. ") + "The cut shows " + _core.name + " under the " + _p.mint.metal + "." };
    }
    _T.verdictInfo = _info;
    scl__swap(_T, "verdict", scl__bake(SCL_W, SCL_H, 0, 0, scl__pnt_verdict, { info: _info }));
}
/// a solved puzzle reopened: straight to the verdict
function scl__show_verdict(_T) {
    _T.game.over = true; scl__draw_verdict_sprite(_T, true); _T.verdictA = 1; _T.mode = "done"; _T.ringOn = false; scl__set_status(_T, "Solved.");
    _T.result = { value: 1, won: true, weighings: is_numeric(_T.rec[$ "weighings"]) ? _T.rec.weighings : 0, key: _T.req.key, kind: _T.p.kind };
    scl__refresh_plaques(_T);
}
function scl__leave(_T) {
    if (_T.mode == "gone") return;
    if (_T.mode != "done") _T.result = { value: 0, won: false, weighings: array_length(_T.game.log), key: _T.req.key, kind: _T.p.kind };
    _T.mode = "gone"; _T.closed = true;
}

/// @function scl_closed(counter)
/// @description True once the player has left the counter (after the verdict, or by leaving). Then read counter.result:
/// { value: 1 solved / 2 the wrong coin named / 0 left without an answer, won, weighings, key, kind, coin?, dir? }.
/// @returns {Bool}
function scl_closed(_T) { return is_struct(_T) && _T.closed; }

/// @function scl_free(counter)
/// @description Free every sprite the counter made. Call it in Step or Clean Up (never in a Draw event).
function scl_free(_T) {
    if (!is_struct(_T)) return;
    var _f = ["bg", "beam", "ful", "ring", "card", "ledger", "status", "verdict", "coin", "markL", "markR", "panBack", "panFront", "panCL", "panCR", "panTL", "panTR"];
    for (var _i = 0; _i < array_length(_f); _i++) { var _s = _T[$ _f[_i]]; if (is_numeric(_s) && sprite_exists(_s)) sprite_delete(_s); _T[$ _f[_i]] = -1; }
    if (is_array(_T[$ "wts"])) for (var _w = 0; _w < array_length(_T.wts); _w++) if (is_numeric(_T.wts[_w]) && sprite_exists(_T.wts[_w])) sprite_delete(_T.wts[_w]);
    _T.wts = [];
    var _maps = [_T[$ "pq"], _T[$ "sc"], _T[$ "pc"]];
    for (var _m = 0; _m < 3; _m++) if (is_struct(_maps[_m])) { var _ks = variable_struct_get_names(_maps[_m]); for (var _k = 0; _k < array_length(_ks); _k++) { var _ms = _maps[_m][$ _ks[_k]]; if (is_numeric(_ms) && sprite_exists(_ms)) sprite_delete(_ms); } }
    _T.pq = {}; _T.sc = {}; _T.pc = {}; _T.pqNow = [-1, -1, -1];
    for (var _d = 0; _d < array_length(_T.trash); _d++) if (sprite_exists(_T.trash[_d])) sprite_delete(_T.trash[_d]);
    _T.trash = []; _T.closed = true;
}

/// @function scl_draw(counter, [x], [y], [scale])
/// @description Draw the counter with its top-left at (x, y) at scale (816 x 624 at scale 1). Call in Draw or Draw GUI; the
/// input is read relative to the same place.
function scl_draw(_T, _x = undefined, _y = undefined, _scale = undefined) {
    if (!is_struct(_T) || _T.closed) return;
    if (is_numeric(_x)) _T.x = _x;
    if (is_numeric(_y)) _T.y = _y;
    if (is_numeric(_scale) && _scale > 0) _T.scale = _scale;
    var _mw = matrix_get(matrix_world), _A = scl_bal(), _Tr = scl_tray(), _C = scl__card_box(), _L = scl__ledger_box(), _S = scl__status_box(), _P = scl__plaque_box();
    matrix_set(matrix_world, matrix_multiply(matrix_build(_T.x, _T.y, 0, 0, 0, 0, _T.scale, _T.scale, 1), _mw));
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); gpu_set_texfilter(true);
    scl__draw_spr(_T.bg, 0, 0, 1);
    scl__draw_spr(_T.panBack, _T.panLx, _T.panLy, 1); scl__draw_spr(_T.panCL, _T.panLx, _T.panLy, 1); scl__draw_spr(_T.panFront, _T.panLx, _T.panLy, 1); scl__draw_spr(_T.panTL, _T.panLx, _T.panLy, 1);
    scl__draw_spr(_T.panBack, _T.panRx, _T.panRy, 1); scl__draw_spr(_T.panCR, _T.panRx, _T.panRy, 1); scl__draw_spr(_T.panFront, _T.panRx, _T.panRy, 1); scl__draw_spr(_T.panTR, _T.panRx, _T.panRy, 1);
    scl__draw_spr(_T.beam, _A.fx, _A.fy, 1, -radtodeg(_T.theta));
    scl__draw_spr(_T.ful, _A.fx - 40, _A.fy - 34, 1);
    scl__draw_items(_T);
    if (_T.ringOn) scl__draw_spr(_T.ring, _T.ringX, _T.ringY, 1);
    scl__draw_spr(_T.card, _C.x, _C.y, 1); scl__draw_spr(_T.ledger, _L.x, _L.y, 1); scl__draw_spr(_T.status, _S.x, _S.y, 1);
    for (var _k = 0; _k < 3; _k++) scl__draw_spr(_T.pqNow[_k], _P.x - 8, _P.y + _k * _P.gap - 8, 1);
    if (_T.mode == "reveal" || _T.mode == "done") scl__draw_spr(_T.verdict, 0, 0, _T.verdictA);
    gpu_pop_state();
    matrix_set(matrix_world, _mw);
}
