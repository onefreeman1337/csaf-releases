{
  "$GMScript": "v1",
  "%Name": "scl_scales",
  "name": "scl_scales",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}