{
  "$GMScript": "v1",
  "%Name": "scl_oracle_core",
  "name": "scl_oracle_core",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}