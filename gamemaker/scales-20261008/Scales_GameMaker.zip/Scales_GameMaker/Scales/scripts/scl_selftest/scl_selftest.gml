/// scl_selftest.gml - Scales' in-engine self-test, run headless by the demo object with -selftest. Holds the GML port to the
/// RPG Maker MZ edition's ScalesCore run in Node (scl_oracle_core): the hash and generator, 300 mints, the solver's
/// minimum-weighings table, 300 counterfeit and 300 measure puzzles, every weight box's reach, 60 counterfeit playouts
/// (the counterfeiter's every answer, hints, refusals, the accusation) and 60 measure playouts - all EXACT - and measures
/// the solver's cost on this runtime. Writes scl_selftest.json.

/// @function scl_st_assert(state, condition, message)
function scl_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 60) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
/// @function scl_st_stage(state, n)
function scl_st_stage(_st, _n) { _st.stage = _n; global.scl_stage = _n; }
function scl__st_join(_a) { var _s = ""; for (var _i = 0; _i < array_length(_a); _i++) _s += ((_i > 0) ? "," : "") + string(_a[_i]); return _s; }
function scl__st_same(_a, _b) { if (array_length(_a) != array_length(_b)) return false; for (var _i = 0; _i < array_length(_a); _i++) if (_a[_i] != _b[_i]) return false; return true; }
function scl__st_b(_v) { return _v ? 1 : 0; }

/// @function scl__st_draw_case(ctx, row)
/// @description Internal (test). Draw one oracle case through the GML painter (the same call the MZ recorder made); false
/// when its kind is not ported yet.
function scl__st_draw_case(_c, _row) {
    switch (_row[0]) {
        case 0: scl_draw_table(_c, _row[1], _row[2], (_row[3] >= 0) ? { x: _row[3], y: _row[4], w: _row[5], h: _row[6] } : undefined); return true;
        case 1: if (_row[1] == 0) scl_draw_stand(_c); else if (_row[1] == 1) scl_draw_beam(_c); else scl_draw_fulcrum(_c); return true;
        case 2: {
            var _M0 = scl_mint(77, { metal: "gold", device: "tower" }); _M0.rim = "beaded";
            var _labs2 = ["", "1 2 3 4", "1" + chr(183) + "2" + chr(183) + "3" + chr(183) + "4" + chr(183) + "5", "goods + 9", "27 + 3", "a label long enough to be fitted down"];
            var _pi = _row[1], _cont = undefined;
            if (_pi == 2 || _pi == 5) { var _n2 = 4 + _pi; _cont = method({ m: _M0, n: _n2 }, function(_cc, _x, _y) { scl_pile_coins(_cc, _x, _y, n, m); }); }
            else if (_pi == 3) _cont = function(_cc, _x, _y) { scl_draw_goods(_cc, _x, _y, "pepper", 31); };
            else if (_pi == 4) _cont = function(_cc, _x, _y) { scl_draw_weight(_cc, _x - 20, _y, 27); scl_draw_weight(_cc, _x + 24, _y, 3); };
            scl_draw_pan(_c, _cont, _labs2[_pi]);
            return true;
        }
        case 8: {
            var _mk8 = function(_mi, _di, _ri, _sd) { var _mm = scl_mint(_sd, { metal: scl_metal_ids()[_mi], device: scl_device_ids()[_di] }); _mm.rim = scl_rim_ids()[_ri]; return _mm; };
            if (_row[1] == 0) {
                var _cards = [
                    { kicker: "THE COUNTERFEIT", title: "The Tower Gold", sub: "twelve crowns, all alike", task: "One is false, heavier or lighter. Find it, and say which, in three weighings.", mint: _mk8(0, 5, 0, 77) },
                    { kicker: "THE MEASURE", title: "Saffron, an order of 23", sub: "with the apothecary's set", task: "Weigh out exactly 23 grains. A weight may go in with the goods.", goods: "saffron", seed: 3 },
                    { kicker: "THE COUNTERFEIT", title: "The Moon Electrum, a very long name for a mint", sub: "thirteen staters, one heavier", task: "The false one is heavier. Find it in three weighings, using the fewest you can, before the money-changer returns.", mint: _mk8(3, 4, 2, 5) }
                ];
                scl_draw_card(_c, 240, 200, _cards[_row[2]]);
            } else {
                var _d8 = chr(183), _many = [];
                for (var _i8 = 0; _i8 < 9; _i8++) array_push(_many, { text: string(_i8 + 1) + _d8 + string(_i8 + 2) + " v " + string(_i8 + 3) + _d8 + string(_i8 + 4), o: (_i8 mod 3) - 1 });
                var _ledgers = [
                    { allowed: 3, left: 1, entries: [{ text: "1" + _d8 + "2" + _d8 + "3" + _d8 + "4 v 5" + _d8 + "6" + _d8 + "7" + _d8 + "8", o: 1 }, { text: "1" + _d8 + "9" + _d8 + "10" + _d8 + "11 v 2" + _d8 + "3" + _d8 + "4" + _d8 + "5", o: 0 }] },
                    { allowed: 0, left: 0, headline: "Fewest weights: 3", entries: [{ text: "goods + 9 v 27 + 3", o: -1 }, { text: "goods + 9 + 1 v 27 + 3", o: 0 }] },
                    { allowed: 4, left: 4, entries: [], empty: "No weighings yet." },
                    { allowed: 2, left: 0, entries: _many }
                ];
                scl_draw_ledger(_c, 240, 260, _ledgers[_row[2]]);
            }
            return true;
        }
        case 10: {
            var _mk10 = function(_mi, _di, _ri, _sd) { var _mm = scl_mint(_sd, { metal: scl_metal_ids()[_mi], device: scl_device_ids()[_di] }); _mm.rim = scl_rim_ids()[_ri]; return _mm; };
            var _verd = [
                { mint: _mk10(0, 5, 0, 77), dir: 1, genuine: 11, title: "Coin 7, heavy", sub: "Found in three weighings", won: true },
                { mint: _mk10(1, 3, 1, 9), dir: -1, genuine: 3, title: "Not that one", sub: "", won: false },
                { goods: "saffron", amount: 23, label: "23 grains of saffron", weights: [1, 2, 5, 10, 20], place: [1, -1, 0, 1, 1], title: "Weighed out", sub: "with four weights", won: true }
            ];
            scl_draw_verdict(_c, 816, 624, _verd[_row[1]]);
            return true;
        }
        case 3: {
            var _m3 = scl_mint(_row[5], { metal: scl_metal_ids()[_row[1]], device: scl_device_ids()[_row[2]] }); _m3.rim = scl_rim_ids()[_row[3]];
            var _at3 = (_row[5] >= 5000) ? 130 : 60;
            scl_draw_coin(_c, _at3, _at3, _row[4], _m3, (_row[6] != 0) ? { cut: _row[6] } : {});
            return true;
        }
        case 4: {
            var _mk = function(_mi, _di, _ri, _sd) { var _mm = scl_mint(_sd, { metal: scl_metal_ids()[_mi], device: scl_device_ids()[_di] }); _mm.rim = scl_rim_ids()[_ri]; return _mm; };
            if (_row[2] == 0) scl_draw_coin_flat(_c, 40, 40, 15, _mk(_row[1], 0, 0, 9));
            else { var _cnt = _row[2]; scl_pile_coins(_c, 100, 100, _cnt, _mk(_cnt mod 5, _cnt mod 6, _cnt mod 3, _cnt)); }
            return true;
        }
        case 5: { var _sets5 = scl_weight_sets(); var _v5 = (_row[1] == 9) ? _row[3] : _sets5[_row[1]].w[_row[2]]; scl_draw_weight(_c, 50, 90, _v5, (_row[4] == 1) ? { dim: true } : undefined); return true; }
        case 6: scl_draw_goods(_c, 80, 80, scl_goods()[_row[1]], _row[2]); return true;
        case 7: { if (_row[1] == 0) scl_draw_tray(_c, _row[2]); else { var _s7 = scl_weight_sets()[_row[2]]; scl_draw_box(_c, _s7.w, _s7.name); } return true; }
        case 9: {
            if (_row[1] == 0) { scl_draw_beam_glyph(_c, 30, 30, _row[2]); return true; }
            if (_row[1] == 1) { var _labs = ["Weigh", "Accuse", "Leave"], _sts = ["idle", "on", "off"]; scl_draw_plaque(_c, 10, 10, 120, 36, _labs[_row[2]], _sts[_row[3]]); return true; }
            if (_row[1] == 2) { var _tx = ["Weighing II of III", "Put the same number of coins on each pan, then weigh.", "The far pan sinks."]; scl_draw_status(_c, 300, 40, _tx[_row[2]]); return true; }
            scl_draw_cursor(_c); return true;
        }
    }
    return false;
}

/// @function scl_selftest_run()
/// @returns {Struct} { total, pass, fail, stage, failures, notes, metrics }
function scl_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, stage: 0, notes: [], failures: [], metrics: {} };
    var _O = scl_oracle_core();
    _st.metrics.epsilonAtStart = math_get_epsilon();
    var _eps0 = math_get_epsilon();
    math_set_epsilon(0);
    var _metals = scl_metal_ids(), _devices = scl_device_ids(), _rims = scl_rim_ids(), _diffs = ["easy", "normal", "hard"], _goods = scl_goods(), _sets = scl_weight_sets();
    // ---- 1: the hash and the generator, EXACT ----
    scl_st_stage(_st, 1);
    var _hb = 0, _hf = "";
    for (var _i = 0; _i < array_length(_O.hashes); _i++) { var _h = scl_hash(_O.hashes[_i][0]); if (_h != _O.hashes[_i][1]) { _hb++; if (_hf == "") _hf = "'" + _O.hashes[_i][0] + "' got " + string(_h); } }
    var _rb = 0;
    for (var _k = 0; _k < array_length(_O.streams); _k++) { var _r = scl__rng(_O.streams[_k][0]), _w = _O.streams[_k][1]; for (var _j = 0; _j < array_length(_w); _j++) if (scl__rng_next(_r) != _w[_j]) _rb++; }
    scl_st_assert(_st, _hb == 0 && _rb == 0 && array_length(_O.hashes) == 8, "FNV hash on 8 strings (" + string(_hb) + " differ " + _hf + ") and 3 generator streams x 20 (" + string(_rb) + " differ)");
    // ---- 2: 300 mints, field for field ----
    scl_st_stage(_st, 2);
    var _mb = 0, _mf = "";
    for (var _m = 0; _m < array_length(_O.mints); _m++) {
        var _row = _O.mints[_m], _opt = undefined;
        if (_row[1] >= 0 || _row[2] >= 0) { _opt = {}; if (_row[1] >= 0) _opt.metal = _metals[_row[1]]; if (_row[2] >= 0) _opt.device = _devices[_row[2]]; }
        if (_m >= 40 && _m < 44) _opt = { metal: "tin", device: "dragon" };
        var _M = scl_mint(_row[0], _opt);
        if (scl__index_of(_metals, _M.metal) != _row[3] || scl__index_of(_devices, _M.device) != _row[4] || scl__index_of(_rims, _M.rim) != _row[5] || _M.points != _row[6] || _M.petals != _row[7] || _M.rays != _row[8]
            || _M.inner != _row[9] || _M.legend != _row[10] || scl__st_b(_M.pellets) != _row[11] || scl__st_b(_M.ring) != _row[12] || scl_hash(_M.name) != _row[13] || scl_hash(_M.unit) != _row[14] || _M.seed != _row[15]) {
            _mb++; if (_mf == "") _mf = "seed " + string(_row[0]) + ": " + _M.metal + "/" + _M.device + "/" + _M.rim + " " + _M.name + " inner " + string_format(_M.inner, 1, 12);
        }
    }
    scl_st_assert(_st, _mb == 0 && array_length(_O.mints) == 300, "300 mints (40 with a fixed or an unknown metal / device) against the MZ, field for field: " + string(_mb) + " differ " + _mf);
    // ---- 3: the solver - the fewest weighings for 1..13 coins, told and untold; and its cost on this runtime ----
    scl_st_stage(_st, 3);
    var _t3 = get_timer(), _wb = 0, _wf = "";
    for (var _q = 0; _q < array_length(_O.minw); _q++) { var _mw = _O.minw[_q], _got = scl_min_weighings(_mw[0], _mw[1] == 1); if (_got != _mw[2]) { _wb++; if (_wf == "") _wf = string(_mw[0]) + (_mw[1] ? " told" : " untold") + " got " + string(_got) + " want " + string(_mw[2]); } }
    _st.metrics.solverColdMs = (get_timer() - _t3) / 1000;
    var _t3b = get_timer(); for (var _q2 = 0; _q2 < array_length(_O.minw); _q2++) scl_min_weighings(_O.minw[_q2][0], _O.minw[_q2][1] == 1); _st.metrics.solverWarmMs = (get_timer() - _t3b) / 1000;
    _st.metrics.memoEntries = array_length(variable_struct_get_names(scl__memo()));
    scl_st_assert(_st, _wb == 0 && array_length(_O.minw) == 26, "the fewest weighings for 1..13 coins, told and untold, against the MZ solver (26 answers, 13 coins untold = 3): " + string(_wb) + " differ " + _wf);
    array_push(_st.notes, "the whole minimum-weighings table: " + string_format(_st.metrics.solverColdMs, 1, 1) + " ms with a cold memo, " + string_format(_st.metrics.solverWarmMs, 1, 2) + " ms warm (" + string(_st.metrics.memoEntries) + " memo entries)");
    // ---- 4: 300 counterfeit puzzles and 300 measure puzzles, and every weight box's reach ----
    scl_st_stage(_st, 4);
    var _cb = 0, _cf = "";
    for (var _c = 0; _c < array_length(_O.cps); _c++) {
        var _cr = _O.cps[_c], _co = { seed: _cr[0] };
        if (_cr[1] >= 0) _co.difficulty = _diffs[_cr[1]];
        if (_cr[2] >= 0) _co.coins = _cr[2];
        var _P = scl_counterfeit(_co);
        if (scl__index_of(_diffs, _P.difficulty) != _cr[3] || _P.n != _cr[4] || scl__st_b(_P.known) != _cr[5] || _P.dir != _cr[6] || _P.weighings != _cr[7] || _P.mint.seed != _cr[8] || _P.seed != _cr[0]) { _cb++; if (_cf == "") _cf = "seed " + string(_cr[0]) + ": " + _P.difficulty + " n " + string(_P.n) + " k " + string(_P.weighings); }
    }
    var _xb = 0, _xf = "";
    for (var _x = 0; _x < array_length(_O.reaches); _x++) {
        var _xr = _O.reaches[_x], _R = scl_reach(_sets[_xr[0]].w), _dg = "";
        for (var _y = 0; _y < array_length(_R.keys); _y++) { var _kk = _R.keys[_y], _e = _R.at[$ string(_kk)]; _dg += ((_y > 0) ? ";" : "") + string(_kk) + ":" + string(_e.used) + ":" + scl__st_join(_e.place) + ":" + string(scl__st_b(_e.both_pans)); }
        if (array_length(_R.keys) != _xr[1] || scl_hash(_dg) != _xr[2] || _R.keys[0] != _xr[3] || _R.keys[array_length(_R.keys) - 1] != _xr[4]) { _xb++; if (_xf == "") _xf = "set " + string(_xr[0]) + " keys " + string(array_length(_R.keys)) + "/" + string(_xr[1]); }
    }
    var _pb = 0, _pf = "";
    for (var _p = 0; _p < array_length(_O.mps); _p++) {
        var _pr = _O.mps[_p], _po = { seed: _pr[0] };
        if (_pr[1] >= 0) _po.difficulty = _diffs[_pr[1]];
        var _Q = scl_measure(_po), _si = -1;
        for (var _s = 0; _s < array_length(_sets); _s++) if (_sets[_s].name == _Q.set_name) _si = _s;
        if (scl__index_of(_diffs, _Q.difficulty) != _pr[2] || _si != _pr[3] || _Q.target != _pr[4] || scl__index_of(_goods, _Q.goods) != _pr[5] || _Q.fewest != _pr[6] || scl_hash(scl__st_join(_Q.solution)) != _pr[7] || scl__st_b(_Q.both_pans) != _pr[8] || _Q.mint.seed != _pr[9]) { _pb++; if (_pf == "") _pf = "seed " + string(_pr[0]) + ": " + _Q.difficulty + " set " + string(_si) + " target " + string(_Q.target) + "/" + string(_pr[4]); }
    }
    scl_st_assert(_st, _cb == 0 && _xb == 0 && _pb == 0 && array_length(_O.cps) == 300 && array_length(_O.mps) == 300, "300 counterfeit puzzles (" + string(_cb) + " differ " + _cf + "), the reach of 5 weight boxes (" + string(_xb) + " differ " + _xf + ") and 300 measure puzzles (" + string(_pb) + " differ " + _pf + ") against the MZ");
    // ---- 5: 60 counterfeit playouts - every answer of the counterfeiter, the status it leaves, the hints, a refusal, the
    //         accusation and its verdict; and 60 measure playouts ----
    scl_st_stage(_st, 5);
    var _gb = 0, _gf = "", _steps = 0, _won = 0;
    for (var _g = 0; _g < array_length(_O.plays); _g++) {
        var _pl = _O.plays[_g], _P5 = scl_counterfeit({ seed: _pl[0], difficulty: _diffs[_pl[1]] }), _G = scl_new_game(_P5);
        for (var _z = 0; _z < array_length(_pl[2]); _z++) {
            var _sp = _pl[2][_z], _bad = false;
            if (_sp[0] == 0) { var _hn = scl_hint(_P5, _G); if (is_undefined(_hn) || !scl__st_same(_hn.L, _sp[1]) || !scl__st_same(_hn.R, _sp[2])) _bad = true; }
            var _o = scl_weigh(_P5, _G, _sp[1], _sp[2]);
            var _ow = is_undefined(_o) ? 9 : _o;
            var _last = (array_length(_G.log) > 0) ? _G.log[array_length(_G.log) - 1] : undefined;
            if (_ow != _sp[3] || string_join_ext("", _G.status) != _sp[4] || _G.left != _sp[5]) _bad = true;
            if (_ow != 9 && (_last.hyps != _sp[6] || scl__st_b(_last.winnable) != _sp[7])) _bad = true;
            _steps++;
            if (_bad) { _gb++; if (_gf == "") _gf = "playout " + string(_g) + " step " + string(_z) + " kind " + string(_sp[0]) + ": outcome " + string(_ow) + "/" + string(_sp[3]) + " status " + string_join_ext("", _G.status) + "/" + _sp[4]; }
        }
        var _ac = _pl[3], _res = scl_accuse(_P5, _G, _ac[0], _ac[1]);
        if (scl__st_b(_res.won) != _ac[2] || _res.coin != _ac[3] || _res.dir != _ac[4] || !_G.over) { _gb++; if (_gf == "") _gf = "playout " + string(_g) + " accusation " + string(_res.won) + " coin " + string(_res.coin) + "/" + string(_ac[3]); }
        if (_res.won) _won++;
    }
    var _eb = 0, _ef = "", _msteps = 0;
    for (var _n = 0; _n < array_length(_O.mplays); _n++) {
        var _ml = _O.mplays[_n], _Q5 = scl_measure({ seed: _ml[0], difficulty: _diffs[_ml[1]] }), _MG = scl_new_measure(_Q5);
        for (var _v = 0; _v < array_length(_ml[2]); _v++) {
            var _ms = _ml[2][_v];
            array_copy(_MG.place, 0, _ms[0], 0, array_length(_ms[0]));
            var _mo = scl_measure_weigh(_Q5, _MG); _msteps++;
            if ((is_undefined(_mo) ? 9 : _mo) != _ms[1]) { _eb++; if (_ef == "") _ef = "measure " + string(_n) + " step " + string(_v) + " got " + string(_mo) + " want " + string(_ms[1]); }
        }
        var _fr = _ml[3], _MR = _MG.result;
        if (!is_struct(_MR) || scl__st_b(_MR.won) != _fr[0] || _MR.weighings != _fr[1] || _MR.used != _fr[2] || _MR.fewest != _fr[3]) { _eb++; if (_ef == "") _ef = "measure " + string(_n) + " result"; }
    }
    _st.metrics.playSteps = _steps; _st.metrics.playsWon = _won; _st.metrics.measureSteps = _msteps;
    scl_st_assert(_st, _gb == 0 && _eb == 0 && _steps >= 200 && _won > 0 && _won < array_length(_O.plays) && _msteps >= 200, "60 counterfeit playouts (" + string(_steps) + " weighings incl. 60 refused, " + string(_won) + " accusations won, the rest lost) and 60 measure playouts (" + string(_msteps) + " weighings) against the MZ: " + string(_gb) + " + " + string(_eb) + " differ " + _gf + _ef);
    // ---- 6: refusals that must not throw (the buyer's step event) ----
    scl_st_stage(_st, 6);
    var _P6 = scl_counterfeit({ seed: 5, difficulty: "hard" }), _G6 = scl_new_game(_P6);
    var _r1 = scl_weigh(_P6, _G6, [0, 0], [1, 2]), _r2 = scl_weigh(_P6, _G6, [99], [1]), _r3 = scl_weigh(undefined, _G6, [0], [1]), _r4 = scl_weigh(_P6, _G6, "xyzzy", [1]);
    var _r5 = scl_counterfeit("xyzzy"), _r6 = scl_measure(-3), _r7 = scl_mint("xyzzy"), _r8 = scl_accuse(undefined, undefined, 1, 1), _r9 = scl_hint(_P6, undefined), _r10 = scl_reach(undefined);
    scl_st_assert(_st, is_undefined(_r1) && is_undefined(_r2) && is_undefined(_r3) && is_undefined(_r4) && _G6.left == _P6.weighings && array_length(_G6.log) == 0 && is_struct(_r5) && _r5.n >= 3 && is_struct(_r6) && _r6.target > 0 && is_struct(_r7) && !_r8.won && is_undefined(_r9) && array_length(_r10.keys) == 0,
        "refusals: a coin twice, a coin not in the hoard, no puzzle, a string for the pans each refused without a weighing used; garbage options give a default puzzle, mint and reach");
    // the cost of generating puzzles on this runtime, memo warm (what a buyer pays opening one)
    var _t7 = get_timer(); for (var _q7 = 0; _q7 < 50; _q7++) { scl_counterfeit({ seed: 1000 + _q7 }); scl_measure({ seed: 2000 + _q7 }); } _st.metrics.puzzlePairMs = (get_timer() - _t7) / 1000 / 50;
    array_push(_st.notes, "one counterfeit + one measure puzzle generated in " + string_format(_st.metrics.puzzlePairMs, 1, 2) + " ms on average (memo warm)");
    // ---- 7: the drawing, held to the MZ ScalesDraw drawn over a recording canvas - every event of every case ported so far
    //         (the table, the stand, the beam, the fulcrum); and the assembled balance rendered for LOOKING ----
    scl_st_stage(_st, 7);
    var _OD = scl_oracle_draw(), _ds7 = surface_create(1024, 704), _dn7 = 0, _db7 = 0, _df7 = "", _dev7 = 0;
    for (var _ci7 = 0; _ci7 < array_length(_OD.cases); _ci7++) {
        var _row7 = _OD.cases[_ci7], _kd7 = _row7[0];
        var _cx7 = scl_cx_create(1);
        surface_set_target(_ds7); draw_clear_alpha(c_black, 0);
        scl_log_begin(_cx7, 0);
        var _ok7 = scl__st_draw_case(_cx7, _row7);
        var _lg7 = scl_log_end(_cx7);
        surface_reset_target();
        if (!_ok7) continue;   // a kind not ported yet
        _dn7++; _dev7 += _lg7.events;
        if (_lg7.events != _row7[7] || _lg7.len != _row7[8] || _lg7.hash != _row7[9]) {
            _db7++;
            if (_df7 == "") {
                _df7 = "case " + string(_ci7) + " kind " + string(_kd7) + " events " + string(_lg7.events) + "/" + string(_row7[7]) + " len " + string(_lg7.len) + "/" + string(_row7[8]);
                // the first failure's whole log, for diffing offline against Internal_Ops/oracle_draw_logs.json
                surface_set_target(_ds7); var _cy7 = scl_cx_create(1); scl_log_begin(_cy7, 400000);
                scl__st_draw_case(_cy7, _row7);
                var _lf7 = scl_log_end(_cy7); surface_reset_target();
                var _fh7 = file_text_open_write("scl_draw_firstfail.txt"); file_text_write_string(_fh7, string(_ci7) + "\n" + _lf7.text); file_text_close(_fh7);
            }
        }
    }
    // the balance assembled as the scene will stand it (the beam level), at 1x, for LOOKING
    surface_set_target(_ds7); draw_clear(c_black);
    var _ca7 = scl_cx_create(1), _A7 = scl_bal();
    scl_draw_table(_ca7, 816, 624); scl_draw_stand(_ca7);
    scl_cx_save(_ca7); scl_cx_translate(_ca7, _A7.fx - SCL_BEAM_OX, _A7.fy - SCL_BEAM_OY); scl_draw_beam(_ca7); scl_cx_restore(_ca7);
    scl_draw_fulcrum(_ca7);
    scl_draw_tray(_ca7, 12);
    surface_reset_target();
    surface_save_part(_ds7, "scl_render_balance.png", 0, 0, 816, 624);
    surface_set_target(_ds7); draw_clear(c_black);
    var _cb7 = scl_cx_create(1); scl_draw_table(_cb7, 816, 624); var _ws7 = scl_weight_sets()[2]; scl_draw_box(_cb7, _ws7.w, _ws7.name);
    var _bs7 = scl_box_slots(_ws7.w); for (var _b7 = 0; _b7 < array_length(_ws7.w); _b7++) scl_draw_weight(_cb7, _bs7[_b7].x, _bs7[_b7].y, _ws7.w[_b7]);
    surface_reset_target();
    surface_save_part(_ds7, "scl_render_box.png", 0, 0, 816, 624);
    // a coin contact sheet: five metals down, six devices across, the rims cycling, on the baize; one cut coin at the end
    surface_set_target(_ds7); draw_clear(make_colour_rgb(30, 63, 41));
    var _cc7 = scl_cx_create(1);
    for (var _cm7 = 0; _cm7 < 5; _cm7++) for (var _cd7 = 0; _cd7 < 6; _cd7++) {
        var _mm7 = scl_mint(300 + _cm7 * 7 + _cd7, { metal: scl_metal_ids()[_cm7], device: scl_device_ids()[_cd7] }); _mm7.rim = scl_rim_ids()[(_cm7 + _cd7) mod 3];
        scl_draw_coin(_cc7, 60 + _cd7 * 112, 60 + _cm7 * 112, 48, _mm7, {});
    }
    scl_draw_coin(_cc7, 900, 300, 100, scl_mint(77, { metal: "gold", device: "tower" }), { cut: 1 });
    surface_reset_target();
    surface_save_part(_ds7, "scl_render_coins.png", 0, 0, 1024, 600);
    // an assembled counterfeit scene (the beam level): table, balance, both pans hung at the beam ends with coins, the tray of
    // twelve, the card and the ledger at the right - the parts as the scene will place them
    surface_set_target(_ds7); draw_clear(c_black);
    var _cs7 = scl_cx_create(1), _As = scl_bal(), _Ms = scl_mint(77, { metal: "gold", device: "tower" }); _Ms.rim = "beaded";
    scl_draw_table(_cs7, 816, 624); scl_draw_stand(_cs7);
    var _side7 = [-1, 1], _lab7 = ["1" + chr(183) + "9" + chr(183) + "10" + chr(183) + "11", "2" + chr(183) + "3" + chr(183) + "4" + chr(183) + "5"];
    for (var _p7 = 0; _p7 < 2; _p7++) {
        scl_cx_save(_cs7); scl_cx_translate(_cs7, _As.fx + _side7[_p7] * _As.arm - SCL_PAN_HX, _As.fy - 6);
        scl_draw_pan(_cs7, method({ m: _Ms }, function(_cc, _x, _y) { scl_pile_coins(_cc, _x, _y, 4, m); }), _lab7[_p7]); scl_cx_restore(_cs7);
    }
    scl_cx_save(_cs7); scl_cx_translate(_cs7, _As.fx - SCL_BEAM_OX, _As.fy - SCL_BEAM_OY); scl_draw_beam(_cs7); scl_cx_restore(_cs7);
    scl_draw_fulcrum(_cs7);
    scl_draw_tray(_cs7, 12); var _sl7 = scl_tray_slots(12);
    for (var _t7 = 0; _t7 < 12; _t7++) if (_t7 != 0 && _t7 < 9) continue; else scl_draw_coin(_cs7, _sl7[_t7].x, _sl7[_t7].y, 25, _Ms, {});
    scl_cx_save(_cs7); scl_cx_translate(_cs7, 556, 8); scl_draw_card(_cs7, 240, 200, { kicker: "THE COUNTERFEIT", title: "The Tower Gold", sub: "twelve crowns, all alike", task: "One is false, heavier or lighter. Find it, and say which, in three weighings.", mint: _Ms }); scl_cx_restore(_cs7);
    scl_cx_save(_cs7); scl_cx_translate(_cs7, 556, 216); scl_draw_ledger(_cs7, 240, 300, { allowed: 3, left: 1, entries: [{ text: _lab7[0] + " v " + _lab7[1], o: 1 }, { text: "1" + chr(183) + "2 v 3" + chr(183) + "4", o: 0 }] }); scl_cx_restore(_cs7);
    surface_reset_target();
    surface_save_part(_ds7, "scl_render_scene.png", 0, 0, 816, 624);
    // the two verdict plates
    surface_set_target(_ds7); draw_clear(c_black); var _cv7 = scl_cx_create(1);
    scl_draw_verdict(_cv7, 816, 624, { mint: _Ms, dir: 1, genuine: 11, title: "Coin 7, heavy", sub: "Found in three weighings", won: true });
    surface_reset_target(); surface_save_part(_ds7, "scl_render_verdict_coin.png", 0, 0, 816, 624);
    surface_set_target(_ds7); draw_clear(c_black); var _cw7 = scl_cx_create(1);
    scl_draw_verdict(_cw7, 816, 624, { goods: "saffron", amount: 23, label: "23 grains of saffron", weights: [1, 2, 5, 10, 20], place: [1, -1, 0, 1, 1], title: "Weighed out", sub: "with four weights", won: true });
    surface_reset_target(); surface_save_part(_ds7, "scl_render_verdict_packet.png", 0, 0, 816, 624);
    // the type at 2x as the scene bakes it: three plaques, two status lines (italic, struck oblique), the glyphs, the cursor
    surface_set_target(_ds7); draw_clear(make_colour_rgb(30, 63, 41));
    var _ct7 = scl_cx_create(2);
    scl_draw_plaque(_ct7, 10, 10, 120, 36, "Weigh", "idle"); scl_draw_plaque(_ct7, 140, 10, 120, 36, "Accuse", "on"); scl_draw_plaque(_ct7, 270, 10, 120, 36, "Leave", "off");
    scl_cx_save(_ct7); scl_cx_translate(_ct7, 0, 60); scl_draw_status(_ct7, 400, 40, "Put the same number of coins on each pan, then weigh."); scl_cx_restore(_ct7);
    scl_cx_save(_ct7); scl_cx_translate(_ct7, 0, 100); scl__font(_ct7, 13, 0); scl__text_align(_ct7, 0, 1); _ct7.fill = scl__rgb([241, 223, 180]); var _md7 = chr(183); scl__q_text(_ct7, "1" + _md7 + "2" + _md7 + "3" + _md7 + "4 v 5" + _md7 + "6" + _md7 + "7" + _md7 + "8", 20, 20); scl_cx_restore(_ct7);
    scl_draw_beam_glyph(_ct7, 300, 120, 1); scl_draw_beam_glyph(_ct7, 340, 120, 0); scl_draw_beam_glyph(_ct7, 380, 120, -1);
    scl_cx_save(_ct7); scl_cx_translate(_ct7, 400, 0); scl_draw_cursor(_ct7); scl_cx_restore(_ct7);
    // weights (the ternary box, one dimmed) and three goods heaps
    var _tw7 = [1, 3, 9, 27];
    for (var _w7 = 0; _w7 < 4; _w7++) scl_draw_weight(_ct7, 40 + _w7 * 50, 230, _tw7[_w7], (_w7 == 3) ? { dim: true } : undefined);
    scl_draw_goods(_ct7, 280, 225, "saffron", 5); scl_draw_goods(_ct7, 360, 225, "indigo", 5); scl_draw_goods(_ct7, 440, 225, "salt", 5);
    surface_reset_target();
    surface_save_part(_ds7, "scl_render_type.png", 0, 0, 1024, 500);
    surface_free(_ds7);
    _st.metrics.drawCases = _dn7; _st.metrics.drawEvents = _dev7;
    scl_st_assert(_st, _db7 == 0 && _dn7 == 195 && _dn7 == array_length(_OD.cases) && _dev7 > 30000, string(_dn7) + " drawings - EVERY case in the oracle (3 tables, the stand, the beam, the fulcrum, 6 pans, 3 cards, 4 ledgers, 3 verdicts, 94 coins = 90 designs + 4 large incl. 2 test cuts, 5 flat coins, 5 piles, 26 weights incl. 2 dimmed, 16 goods heaps, 6 trays, 5 weight boxes, 3 beam glyphs, 9 plaques, 3 status lines, the cursor) against the MZ ScalesDraw, " + string(_dev7) + " paint events: " + string(_db7) + " differ " + _df7);
    // ---- 8: THE COUNTER - whole games played through scl_open / scl_step / scl_draw with injected clicks and keys, every
    //         weighing the scene made replayed through the bare core and compared; lose, leave, reopen, records; frames LOOKED AT ----
    scl_st_stage(_st, 8);
    var _s8 = surface_create(816, 624), _diffs8 = ["easy", "normal", "hard"], _won8 = 0, _wn8 = 0, _cmp8 = 0, _bad8 = "", _opn8 = 0, _optime8 = 0, _clk0 = global.scl__st_clicks, _clt0 = global.scl__st_click_us;
    for (var _g8 = 0; _g8 < 9; _g8++) {
        var _t8 = get_timer();
        var _T8 = scl_open({ puzzle: "counterfeit", difficulty: _diffs8[_g8 mod 3], seed: 900 + _g8, key: "st8|c" + string(_g8) });
        _optime8 += get_timer() - _t8; _opn8++;
        var _ws8 = scl__st_play_counterfeit(_T8, (_g8 == 0) ? _s8 : -1);
        if (!is_array(_ws8)) { if (_bad8 == "") _bad8 = "game " + string(_g8) + " stalled in mode " + _T8.mode; scl_free(_T8); continue; }
        // the scene's game, replayed through the bare core from the scene's own logged pans: every outcome must agree
        var _g2 = scl_new_game(_T8.p), _agree8 = true;
        for (var _k8 = 0; _k8 < array_length(_T8.game.log); _k8++) { var _e8 = _T8.game.log[_k8]; _cmp8++; if (scl_weigh(_T8.p, _g2, _e8.L, _e8.R) != _e8.o) _agree8 = false; }
        var _H8 = scl_hypotheses(_T8.game.status);
        scl__st_click(_T8, _T8.items + 2);                       // Name the false coin
        if (array_length(_H8) == 1) { scl__st_click(_T8, _H8[0].coin); if (!_T8.p.known) scl__st_click(_T8, _T8.items + ((_H8[0].dir > 0) ? 0 : 1)); }
        scl__st_settle(_T8);
        if (_g8 == 0) scl__st_shot(_T8, _s8, "scl_render_counter_verdict.png");
        var _ok8 = _agree8 && array_length(_H8) == 1 && _T8.mode == "done" && is_struct(_T8.result) && _T8.result.value == 1 && _T8.result.weighings >= 1 && _T8.result.weighings <= _T8.p.weighings;
        scl__st_in(_T8, { ok: true });
        _ok8 = _ok8 && scl_closed(_T8) && _T8.result.value == 1;
        if (_ok8) _won8++; else if (_bad8 == "") _bad8 = "game " + string(_g8) + " (" + _T8.p.difficulty + ", " + string(_T8.p.n) + " coins) agree " + string(_agree8) + " hyps " + string(array_length(_H8)) + " mode " + _T8.mode + " result " + json_stringify(_T8.result);
        _wn8 += array_length(_T8.game.log);
        scl_free(_T8);
    }
    _st.metrics.counterOpenMs = _optime8 / 1000 / max(1, _opn8);
    scl_st_assert(_st, _won8 == 9 && _cmp8 >= 18 && _cmp8 == _wn8, "9 counterfeit games (easy / normal / hard) played at the counter by clicks and the Shift key, each in its allowed weighings and named right: " + string(_won8) + " won, " + string(_cmp8) + " weighings replayed through the bare core, every outcome agreeing " + _bad8);
    // measure: one empty weighing first (the goods pan must sink), then the order's fewest-weights placement
    var _mw8 = 0, _mbad8 = "";
    for (var _m8 = 0; _m8 < 4; _m8++) {
        var _M8 = scl_open({ puzzle: "measure", difficulty: _diffs8[_m8 mod 3], seed: 1900 + _m8, key: "st8|m" + string(_m8) });
        scl__st_click(_M8, _M8.items); scl__st_settle(_M8);
        var _o18 = (array_length(_M8.game.log) == 1) ? _M8.game.log[0].o : 99, _mode18 = _M8.mode;
        for (var _w8 = 0; _w8 < array_length(_M8.p.solution); _w8++) { var _pl8 = _M8.p.solution[_w8]; if (_pl8 != 0) scl__st_click(_M8, _w8); if (_pl8 < 0) scl__st_click(_M8, _w8); }
        if (_m8 == 0) scl__st_shot(_M8, _s8, "scl_render_counter_measure.png");
        scl__st_click(_M8, _M8.items); scl__st_settle(_M8);
        if (_m8 == 0) scl__st_shot(_M8, _s8, "scl_render_counter_measure_verdict.png");
        var _rec8 = scl_record("st8|m" + string(_m8));
        if (_o18 == 1 && _mode18 == "play" && _M8.mode == "done" && _M8.result.value == 1 && _M8.result.weighings == 2 && _rec8.won && _rec8.used == _M8.p.fewest) _mw8++;
        else if (_mbad8 == "") _mbad8 = "measure " + string(_m8) + ": first o " + string(_o18) + " then " + _mode18 + ", mode " + _M8.mode + " result " + json_stringify(_M8.result) + " used " + string(_rec8[$ "used"]) + "/" + string(_M8.p.fewest);
        scl_free(_M8);
    }
    scl_st_assert(_st, _mw8 == 4, "4 measure orders weighed out at the counter (an empty weighing sinks the goods pan first; then the fewest weights placed by clicks, the beam level, the record kept): " + string(_mw8) + " " + _mbad8);
    // losing, leaving, reopening a solved puzzle, the records
    var _L8 = scl_open({ puzzle: "counterfeit", difficulty: "hard", seed: 950, key: "st8|lose" });
    scl__st_click(_L8, _L8.items + 2); scl__st_click(_L8, 0); if (!_L8.p.known) scl__st_click(_L8, _L8.items); scl__st_settle(_L8);
    var _lose8 = _L8.mode == "done" && _L8.result.value == 2 && !_L8.result.won && !scl_record("st8|lose").won && scl_record("st8|lose").tries == 1;
    scl_free(_L8);
    var _V8 = scl_open({ puzzle: "counterfeit", seed: 951, key: "st8|leave" }); scl__st_in(_V8, { cancel: true });
    var _leave8 = scl_closed(_V8) && _V8.result.value == 0; scl_free(_V8);
    var _R8 = scl_open({ puzzle: "counterfeit", difficulty: "easy", seed: 900, key: "st8|c0" });
    var _again8 = _R8.mode == "done" && _R8.result.value == 1 && sprite_exists(_R8.verdict), _ids8 = [_R8.verdict, _R8.bg]; scl_free(_R8);
    var _fr8 = _ids8[0] >= 0 && _ids8[1] >= 0 && !sprite_exists(_ids8[0]) && !sprite_exists(_ids8[1]);
    var _js8 = scl_records_save(), _rt8 = scl_records_load(_js8) && scl_record("st8|c0").won && !scl_records_load("not a record") && !scl_records_load(12);
    scl_st_assert(_st, _lose8 && _leave8 && _again8 && _fr8 && _rt8, "the wrong coin named loses (value 2, tries 1): " + string(_lose8) + "; Esc leaves (value 0): " + string(_leave8) + "; a solved puzzle reopens on its verdict: " + string(_again8) + "; scl_free deletes the sprites: " + string(_fr8) + "; records save / load round-trip and refuse junk: " + string(_rt8));
    _st.metrics.counterGames = _won8 + _mw8; _st.metrics.counterWeighings = _wn8;
    _st.metrics.counterClickMs = (global.scl__st_click_us - _clt0) / 1000 / max(1, global.scl__st_clicks - _clk0);
    array_push(_st.notes, "the counter opens in " + string_format(_st.metrics.counterOpenMs, 1, 1) + " ms (everything drawn at 2x and kept as sprites); a click that moves a coin costs " + string_format(_st.metrics.counterClickMs, 1, 1) + " ms on average");
    surface_free(_s8);
    // ---- 9: THE MONEY-CHANGER, the demo room: the room and six cards built, a puzzle chosen (the setting-out plate), the
    //         counter opened centred, left by Esc, the room rebuilt, everything freed; three frames LOOKED AT ----
    scl_st_stage(_st, 9);
    var _s9 = surface_create(960, 640), _D9 = scl_demo_create(960, 640);
    scl_demo_step(_D9);
    var _built9 = sprite_exists(_D9.bg) && sprite_exists(_D9.wait) && array_length(_D9.cards) == 6 && sprite_exists(_D9.cards[0]) && sprite_exists(_D9.cards[5]);
    _D9.cur = 1;
    surface_set_target(_s9); draw_clear(c_black); scl_demo_draw(_D9); surface_reset_target(); surface_save(_s9, "scl_render_demo.png");
    _D9.pending = 1; _D9.pendingFrames = 0;
    surface_set_target(_s9); draw_clear(c_black); scl_demo_draw(_D9); surface_reset_target(); surface_save(_s9, "scl_render_demo_wait.png");
    scl_demo_step(_D9); scl_demo_step(_D9);
    var _open9 = is_struct(_D9.counter) && _D9.counter.p.kind == "counterfeit" && _D9.counter.x == (960 - SCL_W) / 2 && _D9.counter.y == (640 - SCL_H) / 2;
    surface_set_target(_s9); draw_clear(c_black); scl_demo_draw(_D9); surface_reset_target(); surface_save(_s9, "scl_render_demo_counter.png");
    if (is_struct(_D9.counter)) _D9.counter.inject = { cancel: true };
    scl_demo_step(_D9);
    var _back9 = !is_struct(_D9.counter) && _D9.played == 1 && _D9.dirty;
    scl_demo_step(_D9);
    _back9 = _back9 && !_D9.dirty && sprite_exists(_D9.bg);
    var _ids9 = [_D9.bg, _D9.wait, _D9.cards[0]]; scl_demo_free(_D9);
    var _freed9 = !sprite_exists(_ids9[0]) && !sprite_exists(_ids9[1]) && !sprite_exists(_ids9[2]);
    scl_demo_step(undefined); scl_demo_draw(12); scl_demo_free("demo");
    surface_free(_s9);
    scl_st_assert(_st, _built9 && _open9 && _back9 && _freed9, "THE MONEY-CHANGER: room + 6 cards + the setting-out plate built: " + string(_built9) + "; the chosen puzzle opens centred at the counter: " + string(_open9) + "; Esc brings the room back, rebuilt: " + string(_back9) + "; scl_demo_free deletes the sprites: " + string(_freed9) + "; wrong-typed demo calls refused without a throw");
    math_set_epsilon(_eps0);
    scl_st_stage(_st, 99);
    return _st;
}

// ---- stage 8 helpers: one injected frame, a click on an item or plaque, waiting out the beam and the verdict, a frame shot ----
global.scl__st_clicks = 0;
global.scl__st_click_us = 0;
function scl__st_in(_T, _inj) { _T.inject = _inj; scl_step(_T, -1000, -1000); }
function scl__st_click(_T, _i) { var _xy = scl__item_xy(_T, _i), _t = get_timer(); scl__st_in(_T, { x: _xy.x, y: _xy.y, click: true }); global.scl__st_click_us += get_timer() - _t; global.scl__st_clicks++; }
function scl__st_settle(_T) { var _n = 0; while ((_T.mode == "swing" || _T.mode == "reveal") && _n < 4000) { scl__st_in(_T, {}); _n++; } return _n; }
function scl__st_shot(_T, _surf, _name) { surface_set_target(_surf); draw_clear(c_black); scl_draw(_T, 0, 0, 1); surface_reset_target(); surface_save_part(_surf, _name, 0, 0, 816, 624); }
/// play a counterfeit game at the counter by the solver's hints: clear the pans (plaque), click each left coin once and each
/// right coin twice, weigh with the Shift key, wait out the swing. Returns the hints used, or undefined if the scene stalled.
function scl__st_play_counterfeit(_T, _shotSurf) {
    var _ws = [], _guard = 0;
    while (_guard < 20) {
        _guard++;
        var _h = scl_hint(_T.p, _T.game);
        if (is_undefined(_h)) break;
        scl__st_click(_T, _T.items + 1);
        for (var _a = 0; _a < array_length(_h.L); _a++) scl__st_click(_T, _h.L[_a]);
        for (var _b = 0; _b < array_length(_h.R); _b++) { scl__st_click(_T, _h.R[_b]); scl__st_click(_T, _h.R[_b]); }
        array_push(_ws, _h);
        scl__st_in(_T, { shift: true });
        if (_T.mode != "swing") return undefined;
        scl__st_settle(_T);
        if (_T.mode != "play") return undefined;
        if (_guard == 1 && _shotSurf != -1) scl__st_shot(_T, _shotSurf, "scl_render_counter.png");
    }
    return _ws;
}

/// @function scl_selftest_write(state)
function scl_selftest_write(_st) {
    var _f = file_text_open_write("scl_selftest.json");
    file_text_write_string(_f, json_stringify(_st));
    file_text_close(_f);
}
