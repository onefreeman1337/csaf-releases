/// scl_core.gml - Scales' rules: generated weighing puzzles (THE COUNTERFEIT and THE MEASURE), the exact solver that proves
/// every counterfeit puzzle winnable in its stated number of weighings, the counterfeiter that answers each weighing, and
/// the measure play. Pure GML: nothing here draws, and nothing uses the engine's random functions.
///
/// Scales - Weighing Puzzles on a Drawn Brass Balance, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// The RPG Maker MZ edition's ScalesCore.js, ported line for line and held to it by the in-engine suite (scl_selftest):
/// the hash, the generator, every mint, every puzzle, the solver and the counterfeiter's every answer EXACT.
///
/// Public functions (each documented below): scl_hash, scl_mint, scl_solvable, scl_first_good_weighing, scl_outcomes,
/// scl_min_weighings, scl_counterfeit, scl_measure, scl_reach, scl_subset_sum, scl_new_game, scl_count_state,
/// scl_hypotheses, scl_weigh, scl_after, scl_hint, scl_accuse, scl_measure_balance, scl_new_measure, scl_measure_weigh,
/// scl_metal_ids, scl_device_ids, scl_rim_ids, scl_weight_sets, scl_goods.

#macro SCL_VERSION "1.0.0"

// ---------------------------------------------------------------------------------------------------------------
// Unsigned 32-bit arithmetic, the hash and the generator (the MZ edition's, exact)
// ---------------------------------------------------------------------------------------------------------------

/// @function scl__imul(a, b)
/// @description Internal. JavaScript's Math.imul on unsigned 32-bit values, as int64 halves.
function scl__imul(_a, _b) {
    var _m = int64($FFFFFFFF);
    _a = int64(_a) & _m; _b = int64(_b) & _m;
    var _lo = (_a * (_b & int64($FFFF))) & _m;
    var _hi = ((_a * (_b >> 16)) & int64($FFFF)) << 16;
    return (_lo + _hi) & _m;
}

/// @function scl__u32(v)
/// @description Internal. JavaScript's (v >>> 0) for a number: truncated toward zero, then modulo 2^32; not a number -> 0.
function scl__u32(_v) {
    if (!is_numeric(_v) || is_nan(_v) || is_infinity(_v)) return int64(0);
    return int64(_v) & int64($FFFFFFFF);
}

/// @function scl_hash(text)
/// @description A stable unsigned 32-bit FNV-1a hash of a string (as the MZ edition).
/// @returns {Real} 0 .. 4294967295
function scl_hash(_s) {
    var _t = is_string(_s) ? _s : string(_s);
    var _h = int64(2166136261);
    var _n = string_byte_length(_t);
    for (var _i = 1; _i <= _n; _i++) { _h = _h ^ int64(string_byte_at(_t, _i)); _h = scl__imul(_h, 16777619); }
    return real(_h);
}

/// @function scl__rng(seed)
/// @description Internal. The MZ edition's generator (a mulberry32 variant) as a struct { a }; draw with scl__rng_next.
function scl__rng(_seed) { return { a: scl__u32(_seed) }; }

/// @function scl__rng_next(rng)
/// @description Internal. The next draw in [0, 1).
function scl__rng_next(_r) {
    var _m = int64($FFFFFFFF);
    _r.a = (_r.a + int64($6D2B79F5)) & _m;
    var _t = _r.a;
    _t = scl__imul(_t ^ (_t >> 15), _t | 1);
    var _x = scl__imul(_t ^ (_t >> 7), _t | 61);
    _t = _t ^ ((_t + _x) & _m);
    return real((_t ^ (_t >> 14)) & _m) / 4294967296;
}
function scl__pick(_r, _a) { var _n = array_length(_a); return _a[floor(scl__rng_next(_r) * _n) mod _n]; }
function scl__rand_int(_r, _lo, _hi) { var _w = _hi - _lo + 1; return _lo + (floor(scl__rng_next(_r) * _w) mod _w); }
function scl__index_of(_a, _v) { for (var _i = 0; _i < array_length(_a); _i++) if (_a[_i] == _v) return _i; return -1; }

// ---------------------------------------------------------------------------------------------------------------
// The counterfeit: an exact solver over COUNT states
//
// Coins are interchangeable except for what the weighings have taught about them, so a position is four counts: u coins
// that could be heavy OR light, h only heavy, l only light, g known genuine. The hypotheses left are 2u + h + l. A
// weighing puts some of each class on each pan (the same number of coins on both). Its three outcomes:
//   balance     -> every coin on a pan is genuine
//   left heavy  -> the counterfeit is a heavy one on the left or a light one on the right: h' = u1 + h1, l' = u2 + l2
//   right heavy -> the mirror image.
// scl_solvable(state, k) asks: is there a weighing whose every outcome is solvable in k - 1? Exact and memoised.
// ---------------------------------------------------------------------------------------------------------------

function scl__memo() { static _M = {}; return _M; }
function scl__hyps(_s) { return 2 * _s[0] + _s[1] + _s[2]; }

/// @function scl_outcomes(state, weighing)
/// @description The three outcome states [left heavy, balance, right heavy] of weighing w = [u1,h1,l1,g1,u2,h2,l2,g2]
/// from state s = [u,h,l,g].
/// @returns {Array<Array<Real>>}
function scl_outcomes(_s, _w) {
    var _n = _s[0] + _s[1] + _s[2] + _s[3];
    var _bal = [_s[0] - _w[0] - _w[4], _s[1] - _w[1] - _w[5], _s[2] - _w[2] - _w[6], 0]; _bal[3] = _n - _bal[0] - _bal[1] - _bal[2];
    var _lh = [0, _w[0] + _w[1], _w[4] + _w[6], 0]; _lh[3] = _n - _lh[1] - _lh[2];
    var _rh = [0, _w[4] + _w[5], _w[0] + _w[2], 0]; _rh[3] = _n - _rh[1] - _rh[2];
    return [_lh, _bal, _rh];
}

/// @function scl_solvable(state, k)
/// @description Can the counterfeit be found (and its direction named) from state [u, h, l, g] in k more weighings?
/// @returns {Bool}
function scl_solvable(_s, _k) {
    var _H = scl__hyps(_s);
    if (_H <= 1) return true;
    if (_k <= 0 || _H > power(3, _k)) return false;
    var _key = string(_s[0]) + "," + string(_s[1]) + "," + string(_s[2]) + "," + string(_s[3]) + "|" + string(_k);
    var _M = scl__memo();
    if (variable_struct_exists(_M, _key)) return _M[$ _key];
    var _ok = !is_undefined(scl_first_good_weighing(_s, _k));
    _M[$ _key] = _ok;
    return _ok;
}

/// @function scl_first_good_weighing(state, k)
/// @description A weighing [u1,h1,l1,g1,u2,h2,l2,g2] whose three outcomes are all solvable in k - 1, or undefined.
/// @returns {Array<Real>|Undefined}
function scl_first_good_weighing(_s, _k) {
    var _u = _s[0], _h = _s[1], _l = _s[2], _g = _s[3];
    for (var _u1 = 0; _u1 <= _u; _u1++) for (var _u2 = 0; _u2 <= _u - _u1; _u2++)
    for (var _h1 = 0; _h1 <= _h; _h1++) for (var _h2 = 0; _h2 <= _h - _h1; _h2++)
    for (var _l1 = 0; _l1 <= _l; _l1++) for (var _l2 = 0; _l2 <= _l - _l1; _l2++) {
        var _a = _u1 + _h1 + _l1, _b = _u2 + _h2 + _l2;
        // genuine coins only ever top up the lighter-counted pan
        var _g1 = (_b > _a) ? _b - _a : 0, _g2 = (_a > _b) ? _a - _b : 0;
        if (_g1 + _g2 > _g || _a + _g1 == 0) continue;
        // canonical: never try the mirror image of a weighing already tried
        if (_u1 < _u2 || (_u1 == _u2 && (_h1 + _l2 < _h2 + _l1))) continue;
        var _w = [_u1, _h1, _l1, _g1, _u2, _h2, _l2, _g2], _o = scl_outcomes(_s, _w);
        if (scl_solvable(_o[0], _k - 1) && scl_solvable(_o[1], _k - 1) && scl_solvable(_o[2], _k - 1)) return _w;
    }
    return undefined;
}

/// @function scl_min_weighings(n, known)
/// @description The fewest weighings that always find the counterfeit among n coins (known = its direction is told);
/// -1 when no number up to 7 does.
/// @returns {Real}
function scl_min_weighings(_n, _known) {
    if (!is_numeric(_n)) return -1;
    var _s = _known ? [0, _n, 0, 0] : [_n, 0, 0, 0];
    for (var _k = 0; _k < 8; _k++) if (scl_solvable(_s, _k)) return _k;
    return -1;
}

// ---------------------------------------------------------------------------------------------------------------
// Mints: one design per hoard (every coin in it is identical - that is the puzzle)
// ---------------------------------------------------------------------------------------------------------------

/// @function scl_metal_ids()
/// @returns {Array<String>} gold, silver, copper, electrum, bronze
function scl_metal_ids() { return ["gold", "silver", "copper", "electrum", "bronze"]; }
/// @function scl_device_ids()
/// @returns {Array<String>} star, rosette, cross, sun, crescent, tower
function scl_device_ids() { return ["star", "rosette", "cross", "sun", "crescent", "tower"]; }
/// @function scl_rim_ids()
/// @returns {Array<String>} beaded, milled, rope
function scl_rim_ids() { return ["beaded", "milled", "rope"]; }
function scl__mint_name(_d) { switch (_d) { case "star": return "Star"; case "rosette": return "Rose"; case "cross": return "Cross"; case "sun": return "Sun"; case "crescent": return "Moon"; case "tower": return "Tower"; } return ""; }
function scl__unit(_m) { switch (_m) { case "gold": return "crowns"; case "silver": return "marks"; case "copper": return "pence"; case "electrum": return "staters"; case "bronze": return "obols"; } return ""; }

/// @function scl_mint(seed, [options])
/// @description A generated mint: { seed, metal, device, rim, points, petals, rays, inner, legend, pellets, ring, name,
/// unit }. Deterministic from the seed. options = { metal, device } to fix either (an unknown id is ignored).
/// @returns {Struct}
function scl_mint(_seed, _opt = undefined) {
    var _sd = scl__u32(_seed);
    var _r = scl__rng(_sd ^ int64($3171)), _o = is_struct(_opt) ? _opt : {};
    var _metals = scl_metal_ids(), _devices = scl_device_ids();
    var _metal = (scl__index_of(_metals, _o[$ "metal"]) >= 0) ? _o.metal : scl__pick(_r, _metals);
    var _device = (scl__index_of(_devices, _o[$ "device"]) >= 0) ? _o.device : scl__pick(_r, _devices);
    var _M = { seed: real(_sd), metal: _metal, device: _device };
    _M.rim = scl__pick(_r, scl_rim_ids());
    _M.points = scl__rand_int(_r, 5, 8);
    _M.petals = scl__rand_int(_r, 5, 8);
    _M.rays = scl__rand_int(_r, 8, 16);
    _M.inner = 0.34 + scl__rng_next(_r) * 0.14;
    _M.legend = scl__rand_int(_r, 18, 30);
    _M.pellets = scl__rng_next(_r) < 0.5;
    _M.ring = scl__rng_next(_r) < 0.6;
    _M.name = "The " + scl__mint_name(_device) + " " + string_upper(string_char_at(_metal, 1)) + string_delete(_metal, 1, 1);
    _M.unit = scl__unit(_metal);
    return _M;
}

// ---------------------------------------------------------------------------------------------------------------
// Puzzle generation
// ---------------------------------------------------------------------------------------------------------------

function scl__diffs() { return ["easy", "normal", "hard"]; }

/// @function scl_counterfeit([options])
/// @description A counterfeit puzzle: { v, kind, seed, difficulty, n, known, dir, weighings, mint }. n coins of one mint,
/// whether the direction is told (dir -1 light, +1 heavy, 0 not told) and the weighings allowed - the proven minimum.
/// options = { seed, difficulty ("easy" | "normal" | "hard"), coins (3..13) }.
/// @returns {Struct}
function scl_counterfeit(_opt = undefined) {
    var _q = is_struct(_opt) ? _opt : {};
    var _seed = scl__u32(_q[$ "seed"]), _r = scl__rng(_seed ^ int64($C0)), _ds = scl__diffs();
    var _diff = (scl__index_of(_ds, _q[$ "difficulty"]) >= 0) ? _q.difficulty : scl__pick(_r, _ds);
    var _n, _known, _dir = 0;
    if (_diff == "easy") { _n = scl__pick(_r, [3, 4, 6, 8, 9]); _known = true; _dir = (scl__rng_next(_r) < 0.5) ? -1 : 1; }
    else if (_diff == "normal") { _n = scl__pick(_r, [4, 5, 6, 8, 9]); _known = scl__rng_next(_r) < 0.5; _dir = _known ? ((scl__rng_next(_r) < 0.5) ? -1 : 1) : 0; if (_known) _n = scl__pick(_r, [10, 12, 13]); }
    else { _n = scl__pick(_r, [10, 11, 12]); _known = false; }
    var _c = _q[$ "coins"];
    if (is_numeric(_c) && !is_nan(_c)) { var _cn = floor(_c); if (_cn >= 3 && _cn <= 13) _n = _cn; }
    var _k = scl_min_weighings(_n, _known);
    return { v: 1, kind: "counterfeit", seed: real(_seed), difficulty: _diff, n: _n, known: _known, dir: _dir, weighings: _k, mint: scl_mint(real(_seed ^ int64($77))) };
}

/// @function scl_reach(weights)
/// @description Every positive signed sum of the weights (each weight on the goods pan, the far pan or neither) and the
/// way to make it with the fewest weights: { keys: [sums ascending], at: { "<sum>": { used, place, both_pans } } }.
/// place[i]: +1 on the far pan, -1 on the goods pan, 0 left in the box.
/// @returns {Struct}
function scl_reach(_weights) {
    var _out = {}, _keys = [];
    if (!is_array(_weights)) return { keys: _keys, at: _out };
    var _n = array_length(_weights), _total = power(3, _n);
    for (var _c = 0; _c < _total; _c++) {
        var _x = _c, _sum = 0, _used = 0, _place = [], _neg = false;
        for (var _i = 0; _i < _n; _i++) { var _d = _x mod 3; _x = (_x - _d) / 3; var _p = (_d == 2) ? -1 : _d; array_push(_place, _p); _sum += _p * _weights[_i]; if (_p != 0) _used++; if (_p == -1) _neg = true; }
        if (_sum > 0) {
            var _ks = string(_sum), _e = _out[$ _ks];
            if (!is_struct(_e)) { array_push(_keys, _sum); _out[$ _ks] = { used: _used, place: _place, both_pans: _neg }; }
            else if (_used < _e.used) _out[$ _ks] = { used: _used, place: _place, both_pans: _neg };
        }
    }
    // a JavaScript object walks integer keys in ascending order; a struct promises no order - so the keys are sorted
    array_sort(_keys, true);
    return { keys: _keys, at: _out };
}

/// @function scl_weight_sets()
/// @description The five boxes of weights: [{ name, w, both_pans }] (both_pans false = every target can be made on one pan).
/// @returns {Array<Struct>}
function scl_weight_sets() {
    return [
        { name: "the ternary set", w: [1, 3, 9, 27], both_pans: true },
        { name: "the doubling set", w: [1, 2, 4, 8, 16], both_pans: false },
        { name: "the apothecary's set", w: [1, 2, 5, 10, 20], both_pans: true },
        { name: "the spicer's set", w: [2, 3, 7, 15, 25], both_pans: true },
        { name: "the assayer's set", w: [1, 4, 6, 13, 22], both_pans: true }
    ];
}
/// @function scl_goods()
/// @returns {Array<String>} saffron, pepper, silver dust, salt, tea, cloves, myrrh, indigo
function scl_goods() { return ["saffron", "pepper", "silver dust", "salt", "tea", "cloves", "myrrh", "indigo"]; }

/// @function scl_subset_sum(weights, target)
/// @description True when some of the weights, all on one pan, make exactly the target.
/// @returns {Bool}
function scl_subset_sum(_w, _t) {
    if (!is_array(_w)) return false;
    var _n = array_length(_w);
    for (var _m = 1; _m < (1 << _n); _m++) { var _s = 0; for (var _i = 0; _i < _n; _i++) if ((_m & (1 << _i)) != 0) _s += _w[_i]; if (_s == _t) return true; }
    return false;
}

/// @function scl_measure([options])
/// @description A measure puzzle: { v, kind, seed, difficulty, weights, set_name, target, goods, fewest, solution,
/// both_pans, mint }. easy = one pan is enough; normal / hard = every way to make the target needs a weight in the goods
/// pan too (hard = the most weights). options = { seed, difficulty }.
/// @returns {Struct}
function scl_measure(_opt = undefined) {
    var _q = is_struct(_opt) ? _opt : {};
    var _seed = scl__u32(_q[$ "seed"]), _r = scl__rng(_seed ^ int64($5E)), _ds = scl__diffs();
    var _diff = (scl__index_of(_ds, _q[$ "difficulty"]) >= 0) ? _q.difficulty : scl__pick(_r, _ds);
    // the doubling set makes EVERY target with one pan (the MZ edition measured it), so it is an easy-only box
    var _all = scl_weight_sets(), _pool = [];
    for (var _i = 0; _i < array_length(_all); _i++) if (_diff == "easy" || _all[_i].both_pans) array_push(_pool, _all[_i]);
    var _set = scl__pick(_r, _pool), _R = scl_reach(_set.w), _cands = [];
    for (var _j = 0; _j < array_length(_R.keys); _j++) {
        var _t = _R.keys[_j], _e = _R.at[$ string(_t)];
        var _one = scl_subset_sum(_set.w, _t);
        if ((_diff == "easy") ? (_one && _e.used >= 2) : (!_one && ((_diff == "hard") ? _e.used >= 3 : _e.used >= 2))) array_push(_cands, _t);
    }
    if (array_length(_cands) == 0) for (var _k = 0; _k < array_length(_R.keys); _k++) if (_R.at[$ string(_R.keys[_k])].used >= 2) array_push(_cands, _R.keys[_k]);
    array_sort(_cands, true);
    var _target = _cands[floor(scl__rng_next(_r) * array_length(_cands)) mod array_length(_cands)];
    var _best = _R.at[$ string(_target)];
    return { v: 1, kind: "measure", seed: real(_seed), difficulty: _diff, weights: scl__copy(_set.w), set_name: _set.name, target: _target, goods: scl__pick(_r, scl_goods()),
        fewest: _best.used, solution: scl__copy(_best.place), both_pans: !scl_subset_sum(_set.w, _target), mint: scl_mint(real(_seed ^ int64($77))) };
}
function scl__copy(_a) { var _o = array_create(array_length(_a)); array_copy(_o, 0, _a, 0, array_length(_a)); return _o; }

// ---------------------------------------------------------------------------------------------------------------
// Playing a counterfeit puzzle: the counterfeiter (an adversary)
// ---------------------------------------------------------------------------------------------------------------

/// @function scl_new_game(puzzle)
/// @description A fresh play state { status, left, log, over }: every coin could be heavy or light ("U"), or only the told
/// direction ("H" / "L").
/// @returns {Struct}
function scl_new_game(_p) {
    var _st = [];
    if (is_struct(_p) && is_numeric(_p[$ "n"])) for (var _i = 0; _i < _p.n; _i++) array_push(_st, _p.known ? ((_p.dir > 0) ? "H" : "L") : "U");
    return { status: _st, left: (is_struct(_p) && is_numeric(_p[$ "weighings"])) ? _p.weighings : 0, log: [], over: false, result: undefined };
}

/// @function scl_count_state(status)
/// @description [u, h, l, g] counted from a status array.
/// @returns {Array<Real>}
function scl_count_state(_st) {
    var _s = [0, 0, 0, 0];
    for (var _i = 0; _i < array_length(_st); _i++) { var _x = string_pos(_st[_i], "UHLG") - 1; if (_x >= 0) _s[_x] += 1; }
    return _s;
}

/// @function scl_hypotheses(status)
/// @description Every { coin, dir } the weighings still allow (dir +1 heavy, -1 light).
/// @returns {Array<Struct>}
function scl_hypotheses(_st) {
    var _out = [];
    for (var _i = 0; _i < array_length(_st); _i++) {
        if (_st[_i] == "U" || _st[_i] == "H") array_push(_out, { coin: _i, dir: 1 });
        if (_st[_i] == "U" || _st[_i] == "L") array_push(_out, { coin: _i, dir: -1 });
    }
    return _out;
}

/// @function scl_after(status, L, R, outcome)
/// @description The status array after weighing coin lists L against R gave outcome (+1 left heavy, 0, -1 right heavy).
/// @returns {Array<String>}
function scl_after(_st, _L, _R, _o) {
    var _out = scl__copy(_st), _onL = {}, _onR = {}, _i;
    for (_i = 0; _i < array_length(_L); _i++) _onL[$ string(_L[_i])] = 1;
    for (_i = 0; _i < array_length(_R); _i++) _onR[$ string(_R[_i])] = 1;
    for (_i = 0; _i < array_length(_out); _i++) {
        var _s = _out[_i]; if (_s == "G") continue;
        var _canH = (_s == "U" || _s == "H"), _canL = (_s == "U" || _s == "L");
        var _l = variable_struct_exists(_onL, string(_i)), _r = variable_struct_exists(_onR, string(_i));
        // under outcome o, could coin i be the heavy one? the light one?
        var _hOK = _canH && (_l ? _o == 1 : (_r ? _o == -1 : _o == 0)), _lOK = _canL && (_l ? _o == -1 : (_r ? _o == 1 : _o == 0));
        _out[_i] = (_hOK && _lOK) ? "U" : (_hOK ? "H" : (_lOK ? "L" : "G"));
    }
    return _out;
}

/// @function scl_weigh(puzzle, game, L, R)
/// @description Weigh coin lists L against R. Returns the outcome (+1 left pan heavy, 0 balance, -1 right pan heavy) and
/// updates the game, or undefined if the pans hold different numbers of coins, a coin twice, a coin that is not in the
/// hoard, or no weighings are left. The counterfeiter answers with the outcome the weighings allow that hides the coin
/// best: one from which the puzzle can no longer be won, if the player's weighing left one; else the one leaving the most
/// possibilities (ties broken by the puzzle's seed).
/// @returns {Real|Undefined}
function scl_weigh(_p, _game, _L, _R) {
    if (!is_struct(_p) || !is_struct(_game) || !is_array(_L) || !is_array(_R)) return undefined;
    if (_game.over || _game.left <= 0 || array_length(_L) == 0 || array_length(_L) != array_length(_R)) return undefined;
    var _seen = {}, _i;
    for (_i = 0; _i < array_length(_L); _i++) { var _a = _L[_i]; if (!is_numeric(_a) || _a < 0 || _a >= _p.n || variable_struct_exists(_seen, string(_a))) return undefined; _seen[$ string(_a)] = 1; }
    for (_i = 0; _i < array_length(_R); _i++) { var _b = _R[_i]; if (!is_numeric(_b) || _b < 0 || _b >= _p.n || variable_struct_exists(_seen, string(_b))) return undefined; _seen[$ string(_b)] = 1; }
    var _os = [1, 0, -1], _live = [];
    for (_i = 0; _i < 3; _i++) { var _st = scl_after(_game.status, _L, _R, _os[_i]); if (array_length(scl_hypotheses(_st)) > 0) array_push(_live, { o: _os[_i], st: _st }); }
    var _k = _game.left - 1;
    var _r = scl__rng(((int64(_p.seed) ^ int64($ADD)) + array_length(_game.log) * 7919 + array_length(_L) * 31 + _R[0] * 3 + _L[0]) & int64($FFFFFFFF));
    var _lost = [];
    for (_i = 0; _i < array_length(_live); _i++) if (!scl_solvable(scl_count_state(_live[_i].st), _k)) array_push(_lost, _live[_i]);
    var _pool = (array_length(_lost) > 0) ? _lost : _live, _best = -1, _choice = [];
    for (_i = 0; _i < array_length(_pool); _i++) {
        var _hn = array_length(scl_hypotheses(_pool[_i].st));
        if (_hn > _best) { _best = _hn; _choice = [_pool[_i]]; } else if (_hn == _best) array_push(_choice, _pool[_i]);
    }
    var _c = _choice[floor(scl__rng_next(_r) * array_length(_choice)) mod array_length(_choice)];
    _game.status = _c.st; _game.left = _k;
    array_push(_game.log, { L: scl__copy(_L), R: scl__copy(_R), o: _c.o, hyps: array_length(scl_hypotheses(_c.st)), winnable: scl_solvable(scl_count_state(_c.st), _k) });
    return _c.o;
}

/// @function scl_hint(puzzle, game)
/// @description A weighing that keeps the puzzle winnable from where the game stands, as coin numbers { L, R }, or
/// undefined if the weighings so far have already lost it (or nothing is left to learn). The solver's count-level move,
/// each class filled from the coins in that class, lowest numbers first.
/// @returns {Struct|Undefined}
function scl_hint(_p, _game) {
    if (!is_struct(_game) || !is_array(_game[$ "status"])) return undefined;
    var _s = scl_count_state(_game.status);
    if (scl__hyps(_s) <= 1 || _game.left <= 0) return undefined;
    var _w = scl_first_good_weighing(_s, _game.left); if (is_undefined(_w)) return undefined;
    var _pools = { U: [], H: [], L: [], G: [] }, _i;
    for (_i = 0; _i < array_length(_game.status); _i++) array_push(_pools[$ _game.status[_i]], _i);
    var _cls = ["U", "H", "L", "G"], _Lo = [], _Ro = [];
    for (_i = 0; _i < 4; _i++) { var _pl = _pools[$ _cls[_i]]; repeat (_w[_i]) array_push(_Lo, array_shift(_pl)); }
    for (_i = 0; _i < 4; _i++) { var _pr = _pools[$ _cls[_i]]; repeat (_w[4 + _i]) array_push(_Ro, array_shift(_pr)); }
    return { L: _Lo, R: _Ro };
}

/// @function scl_accuse(puzzle, game, coin, dir)
/// @description The player names the counterfeit (and, when it was not told, whether it is heavy (+1) or light (-1)).
/// Wins only if the weighings have left exactly that one possibility; otherwise the counterfeiter shows another the
/// weighings still allowed. Ends the game. Returns { won, coin, dir }.
/// @returns {Struct}
function scl_accuse(_p, _game, _coin, _dir) {
    if (!is_struct(_p) || !is_struct(_game) || !is_array(_game[$ "status"])) return { won: false, coin: -1, dir: 0 };
    var _H = scl_hypotheses(_game.status), _d = _p.known ? _p.dir : _dir, _mine = 0, _other = [], _i;
    for (_i = 0; _i < array_length(_H); _i++) { if (_H[_i].coin == _coin && _H[_i].dir == _d) _mine++; else array_push(_other, _H[_i]); }
    _game.over = true;
    if (array_length(_H) == 1 && _mine == 1) { _game.result = { won: true, coin: _coin, dir: _d }; return _game.result; }
    var _cc = is_numeric(_coin) ? int64(_coin) : int64(0);
    var _r = scl__rng((int64(_p.seed) ^ int64($F00) ^ _cc) & int64($FFFFFFFF));
    var _t = (array_length(_other) > 0) ? _other[floor(scl__rng_next(_r) * array_length(_other)) mod array_length(_other)] : ((array_length(_H) > 0) ? _H[0] : { coin: -1, dir: 0 });
    _game.result = { won: false, coin: _t.coin, dir: _t.dir };
    return _game.result;
}

// ---------------------------------------------------------------------------------------------------------------
// Playing a measure puzzle
// ---------------------------------------------------------------------------------------------------------------

/// @function scl_measure_balance(puzzle, place)
/// @description Weights on the far pan minus the goods and the weights on the goods pan: 0 when the beam is level;
/// undefined when the puzzle is not a measure puzzle (never 0, which would read as level).
/// @returns {Real|Undefined}
function scl_measure_balance(_p, _place) {
    if (!is_struct(_p) || !is_array(_p[$ "weights"]) || !is_numeric(_p[$ "target"])) return undefined;
    var _s = -_p.target;
    for (var _i = 0; _i < array_length(_p.weights); _i++) { var _v = (is_array(_place) && _i < array_length(_place) && is_numeric(_place[_i])) ? _place[_i] : 0; _s += _v * (is_numeric(_p.weights[_i]) ? _p.weights[_i] : 0); }
    return _s;
}

/// @function scl_new_measure(puzzle)
/// @description A fresh measure play state { place, log, over }: every weight in its box (0); +1 = on the far pan,
/// -1 = on the goods pan.
/// @returns {Struct}
function scl_new_measure(_p) { var _n = (is_struct(_p) && is_array(_p[$ "weights"])) ? array_length(_p.weights) : 0; return { place: array_create(_n, 0), log: [], over: false, result: undefined }; }

/// @function scl_measure_weigh(puzzle, game)
/// @description Weigh the goods (on the LEFT pan with any weights placed there) against the far pan. Returns +1 the goods
/// pan sinks, 0 the beam is level (solved: the game is over and game.result says so), -1 the far pan sinks; undefined
/// when the game is over.
/// @returns {Real|Undefined}
function scl_measure_weigh(_p, _game) {
    if (!is_struct(_p) || !is_struct(_game) || !is_array(_game[$ "place"]) || !is_array(_game[$ "log"]) || _game[$ "over"] == true) return undefined;
    var _s = scl_measure_balance(_p, _game.place);
    if (is_undefined(_s)) return undefined;
    var _o = (_s < 0) ? 1 : ((_s > 0) ? -1 : 0), _used = 0;
    for (var _i = 0; _i < array_length(_game.place); _i++) if (_game.place[_i] != 0) _used++;
    array_push(_game.log, { place: scl__copy(_game.place), o: _o, used: _used });
    if (_o == 0) { _game.over = true; _game.result = { won: true, weighings: array_length(_game.log), used: _used, fewest: _p.fewest }; }
    return _o;
}
