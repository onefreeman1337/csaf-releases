{
  "$GMScript": "v1",
  "%Name": "scl_canvas",
  "name": "scl_canvas",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}