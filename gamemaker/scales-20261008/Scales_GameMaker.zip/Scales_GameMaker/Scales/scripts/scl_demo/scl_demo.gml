/// scl_demo.gml - THE MONEY-CHANGER, the demo room's logic: six puzzles laid out on the money-changer's baize, three hoards
/// with a false coin among them and three orders to weigh out. Click a card (or walk the arrows and press Enter) to sit at
/// the counter; when you leave, the room comes back with the puzzle marked if you solved it. Everything on screen is drawn by
/// the package. Run by obj_scl_demo; read it as the worked example of scl_request / scl_open / scl_step / scl_draw /
/// scl_closed / scl_free.
///
/// Scales - Weighing Puzzles on a Drawn Brass Balance, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// Public functions: scl_demo_puzzles, scl_demo_create, scl_demo_step, scl_demo_draw, scl_demo_free.

/// @function scl_demo_puzzles()
/// @description The six puzzles on the demo's baize, as scl_request options (the seed is a word; the hoard's mint, the
/// goods and the weight set all come from it).
/// @returns {Array<Struct>}
function scl_demo_puzzles() {
    return [
        { puzzle: "counterfeit", difficulty: "easy", seed: "copper and a liar", key: "demo|hoard-1" },
        { puzzle: "counterfeit", difficulty: "normal", seed: "the tower gold", metal: "gold", device: "tower", key: "demo|hoard-2" },
        { puzzle: "counterfeit", difficulty: "hard", coins: 12, seed: "twelve alike", key: "demo|hoard-3" },
        { puzzle: "measure", difficulty: "easy", seed: "a pinch for the cook", key: "demo|order-1" },
        { puzzle: "measure", difficulty: "normal", seed: "the apothecary", key: "demo|order-2" },
        { puzzle: "measure", difficulty: "hard", seed: "the spice merchant", key: "demo|order-3" }
    ];
}

/// @function scl_demo_create(width, height)
/// @description The demo's state for a width x height GUI.
/// @returns {Struct}
function scl_demo_create(_w, _h) {
    var _D = { w: _w, h: _h, opts: scl_demo_puzzles(), reqs: [], cur: 0, counter: undefined, cards: [], bg: -1, wait: -1, rep: { left: 0, right: 0, up: 0, down: 0 }, dirty: true, played: 0, pending: -1, pendingFrames: 0, cells: [] };
    for (var _i = 0; _i < array_length(_D.opts); _i++) array_push(_D.reqs, scl_request(_D.opts[_i]));
    var _cw = 240, _ch = 196, _gx = 24, _gy = 20, _x0 = (_w - (_cw * 3 + _gx * 2)) / 2, _y0 = 132;
    for (var _j = 0; _j < 6; _j++) array_push(_D.cells, { x: _x0 + (_j mod 3) * (_cw + _gx), y: _y0 + (_j div 3) * (_ch + _gy), w: _cw, h: _ch });
    return _D;
}

function scl__demo_pnt_room(_c, _a) {
    // the baize under the six cards (the counter's own baize sits under its balance)
    scl_draw_table(_c, _a.w, _a.h, { x: _a.w / 2 - 408, y: 120, w: 816, h: 446 });
    scl__text_align(_c, 1, 0);
    scl__font(_c, 46, 0); _c.fill = scl__rgb([0, 0, 0], 0.45); scl__q_text(_c, "THE MONEY-CHANGER", _a.w / 2 + 2, 72);
    _c.fill = scl__rgb([241, 223, 180]); scl__q_text(_c, "THE MONEY-CHANGER", _a.w / 2, 70);
    var _t1 = "Three hoards with a false coin in each, three orders to weigh out. Every coin, weight and pan is drawn by the package.";
    scl__fit_text(_c, _t1, _a.w - 60, 17, "italic"); _c.fill = scl__rgb([232, 211, 162]); scl__q_text(_c, _t1, _a.w / 2, 104);
    var _t2 = "Click a card, or walk the arrows and press Enter. At the counter: OK moves a coin, Shift weighs, Esc goes back.";
    scl__fit_text(_c, _t2, _a.w - 40, 14, "regular"); _c.fill = scl__rgb([214, 190, 140]); scl__q_text(_c, _t2, _a.w / 2, _a.h - 20);
}
function scl__demo_pnt_card(_c, _a) { scl_cx_translate(_c, 4, 4); scl_draw_card(_c, _a.w, _a.h, _a.info); }
function scl__demo_pnt_wait(_c, _a) {
    _c.fill = scl__rgb([20, 12, 7], 0.94); scl__p_fill_rect(_c, 0, 0, _a.w, 124);
    _c.fill = scl__rgb([214, 170, 96]); scl__p_fill_rect(_c, 0, 0, _a.w, 2); scl__p_fill_rect(_c, 0, 122, _a.w, 2);
    scl__text_align(_c, 1, 1); scl__font(_c, 30, 0); _c.fill = scl__rgb([241, 223, 180]); scl__q_text(_c, "SETTING OUT THE SCALES", _a.w / 2, 46);
    scl__font(_c, 16, 2); _c.fill = scl__rgb([214, 190, 140]); scl__q_text(_c, "The money-changer levels the beam and lays out the counter.", _a.w / 2, 86);
}

/// @function scl_demo_step(demo)
/// @description One frame of the demo: the counter while a puzzle is open, the room otherwise.
function scl_demo_step(_D) {
    if (!is_struct(_D) || !is_array(_D[$ "reqs"])) return;   // not a demo: nothing to step (never a throw in the buyer's Step)
    if (is_struct(_D.counter)) {
        scl_step(_D.counter);
        if (scl_closed(_D.counter)) { scl_free(_D.counter); _D.counter = undefined; _D.dirty = true; _D.played++; }
        return;
    }
    if (_D.dirty) scl__demo_rebuild(_D);
    // a puzzle was chosen: the "setting out" plate has been on screen for a frame, so the counter opens now (opening draws
    // every picture once - see scl_open - so the player sees why the room paused)
    if (_D.pending >= 0) {
        _D.pendingFrames++;
        if (_D.pendingFrames < 2) return;
        _D.counter = scl_open(_D.reqs[_D.pending]);
        _D.counter.x = (_D.w - SCL_W) / 2; _D.counter.y = (_D.h - SCL_H) / 2;
        _D.pending = -1;
        return;
    }
    var _mx = device_mouse_x_to_gui(0), _my = device_mouse_y_to_gui(0), _hit = -1;
    for (var _i = 0; _i < 6; _i++) { var _c = _D.cells[_i]; if (_mx >= _c.x && _mx < _c.x + _c.w && _my >= _c.y && _my < _c.y + _c.h) _hit = _i; }
    if (_hit >= 0) _D.cur = _hit;
    var _keys = [["left", vk_left, -1, 0], ["right", vk_right, 1, 0], ["up", vk_up, 0, -1], ["down", vk_down, 0, 1]];
    for (var _k = 0; _k < 4; _k++) {
        var _nm = _keys[_k][0]; _D.rep[$ _nm] = keyboard_check(_keys[_k][1]) ? _D.rep[$ _nm] + 1 : 0;
        var _n = _D.rep[$ _nm];
        if (_n == 1 || (_n > 24 && ((_n - 24) mod 6) == 0)) { var _col = (_D.cur mod 3) + _keys[_k][2], _row = (_D.cur div 3) + _keys[_k][3]; _D.cur = clamp(_row, 0, 1) * 3 + clamp(_col, 0, 2); }
    }
    if ((mouse_check_button_pressed(mb_left) && _hit >= 0) || keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space)) { _D.pending = _D.cur; _D.pendingFrames = 0; }
}
function scl__demo_rebuild(_D) {
    // rebuilt in Step, never in Draw: deleting a sprite drawn in the same frame leaves a white box
    if (sprite_exists(_D.bg)) sprite_delete(_D.bg);
    for (var _i = 0; _i < array_length(_D.cards); _i++) if (sprite_exists(_D.cards[_i])) sprite_delete(_D.cards[_i]);
    _D.bg = scl__bake(_D.w, _D.h, 0, 0, scl__demo_pnt_room, { w: _D.w, h: _D.h });
    if (!sprite_exists(_D.wait)) _D.wait = scl__bake(_D.w, 124, 0, 0, scl__demo_pnt_wait, { w: _D.w });
    _D.cards = [];
    for (var _j = 0; _j < 6; _j++) {
        var _c = _D.cells[_j], _r = _D.reqs[_j], _info = scl__card_info(_r), _rec = scl_record(_r.key);
        if (_rec.won) _info.kicker = _info.kicker + " " + chr(183) + " SOLVED";
        array_push(_D.cards, scl__bake(_c.w + 16, _c.h + 16, 4, 4, scl__demo_pnt_card, { w: _c.w, h: _c.h, info: _info }));
    }
    _D.dirty = false;
}

/// @function scl_demo_draw(demo)
/// @description Draw the demo (call in Draw GUI).
function scl_demo_draw(_D) {
    if (!is_struct(_D) || !is_array(_D[$ "reqs"])) return;
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); gpu_set_texfilter(true);
    if (is_struct(_D.counter)) {
        // the room stays behind the counter, dimmed, where the GUI is wider or taller than the counter
        draw_clear(c_black);
        scl__draw_spr(_D.bg, 0, 0, 0.3);
        gpu_pop_state();
        scl_draw(_D.counter);
        return;
    }
    if (_D.dirty) { gpu_pop_state(); return; }
    scl__draw_spr(_D.bg, 0, 0, 1);
    for (var _i = 0; _i < 6; _i++) { var _c = _D.cells[_i]; scl__draw_spr(_D.cards[_i], _c.x, _c.y + ((_i == _D.cur) ? -4 : 0), 1); }
    gpu_pop_state();
    var _s = _D.cells[_D.cur];
    draw_set_alpha(0.9); draw_set_colour(make_colour_rgb(250, 214, 120));
    draw_rectangle(_s.x - 3, _s.y - 7, _s.x + _s.w + 2, _s.y + _s.h - 2, true); draw_rectangle(_s.x - 4, _s.y - 8, _s.x + _s.w + 3, _s.y + _s.h - 1, true);
    draw_set_alpha(1); draw_set_colour(c_white);
    if (_D.pending >= 0) {
        draw_set_alpha(0.62); draw_set_colour(c_black); draw_rectangle(0, 0, _D.w, _D.h, false); draw_set_alpha(1); draw_set_colour(c_white);
        gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha); gpu_set_texfilter(true);
        scl__draw_spr(_D.wait, 0, _D.h / 2 - 62, 1);
        gpu_pop_state();
    }
}

/// @function scl_demo_free(demo)
/// @description Free everything the demo made (call in Clean Up).
function scl_demo_free(_D) {
    if (!is_struct(_D) || !is_array(_D[$ "reqs"])) return;
    if (is_struct(_D.counter)) scl_free(_D.counter);
    if (sprite_exists(_D.bg)) sprite_delete(_D.bg);
    if (sprite_exists(_D.wait)) sprite_delete(_D.wait);
    for (var _i = 0; _i < array_length(_D.cards); _i++) if (sprite_exists(_D.cards[_i])) sprite_delete(_D.cards[_i]);
    _D.cards = []; _D.counter = undefined;
}
