/// scl_draw.gml - Scales' drawing: the counting-house table, the balance (stand, beam, fulcrum, pans and chains), every coin
/// of every mint, the bell weights, the goods, the coin tray and the weight box, the card, the ledger, the plaques and the
/// verdict. Nothing here is an image file: every picture is drawn when it is asked for.
///
/// Scales - Weighing Puzzles on a Drawn Brass Balance, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// This is the RPG Maker MZ edition's ScalesDraw.js, ported op for op onto the scl_canvas kit and HELD to it: the self-test
/// runs the MZ drawing in Node over a recording canvas and compares every fill, stroke, rectangle and line of text - colour,
/// alpha, line width, caps, the path it paints and the transform it paints under - against what this file asks the kit to
/// do (scl_oracle_draw).
///
/// ⛔ GameMaker evaluates a function call's ARGUMENTS RIGHT TO LEFT. Wherever the MZ code draws several numbers from a
/// generator inside one expression, this file draws them into variables first, in the original's order.
///
/// PORT IN PROGRESS (2026-10-08): the table and the balance's stand, beam and fulcrum are ported and held; pans, coins,
/// weights, goods, tray, box, card, ledger, plaques, status, cursor and verdict follow (PORT_PLAN.md).

#macro SCL_TAU (pi * 2)

// ---------------------------------------------------------------------------------------------------------------
// Guards: every documented drawing call REFUSES (draws nothing, returns its neutral value) rather than throwing inside the
// caller's Draw event when handed something that is not a drawing context, a finite number, a mint or an info struct.
// GML resolves a field read on a non-struct against the CALLING INSTANCE, so an unguarded read surfaces in the buyer's
// project as "Variable obj_theirs.<our field> not set" - a support ticket nobody can trace.
// ---------------------------------------------------------------------------------------------------------------

function scl__is_ctx(_c) { return is_struct(_c) && is_array(_c[$ "m"]) && array_length(_c.m) == 6; }
function scl__fin() { for (var _i = 0; _i < argument_count; _i++) { var _v = argument[_i]; if (!is_numeric(_v) || is_nan(_v) || is_infinity(_v)) return false; } return true; }
function scl__is_mint(_m) { return is_struct(_m) && is_string(_m[$ "metal"]) && is_string(_m[$ "device"]) && is_string(_m[$ "rim"]) && is_numeric(_m[$ "points"]) && is_numeric(_m[$ "legend"]); }
/// a shallow copy of an info struct with the named fields made strings (missing -> ""), so a partial info draws blank lines
function scl__texts(_s, _keys) {
    var _o = {}, _n = variable_struct_get_names(_s), _i;
    for (_i = 0; _i < array_length(_n); _i++) _o[$ _n[_i]] = _s[$ _n[_i]];
    for (_i = 0; _i < array_length(_keys); _i++) { var _v = _o[$ _keys[_i]]; if (!is_string(_v)) _o[$ _keys[_i]] = is_undefined(_v) ? "" : string(_v); }
    return _o;
}

// ---------------------------------------------------------------------------------------------------------------
// Colours (the MZ's hex constants as [r, g, b]) and the logged verbs this file adds to scl_paint's
// ---------------------------------------------------------------------------------------------------------------

function scl__brass() { static _B = { lite: [255, 241, 192], hi: [242, 210, 126], mid: [201, 152, 62], lo: [138, 98, 32], dark: [78, 53, 16] }; return _B; }
function scl__ink() { return [44, 32, 20]; }
/// a solid paint from [r, g, b] and an alpha
function scl__rgb(_c, _a = 1) { return scl_cx_solid(_c, _a); }
/// a gradient stop
function scl__stop(_g, _t, _c, _a = 1) { scl_cx_stop(_g, _t, _c, _a); }
/// JavaScript's Math.round for the non-negative channel values this file rounds
function scl__jround(_v) { return floor(_v + 0.5); }
/// the MZ shade(hex, k): lighten (k > 0) or darken (k < 0) a colour, channels rounded as Math.round does
function scl__shade(_c, _k) {
    var _o = [0, 0, 0];
    for (var _i = 0; _i < 3; _i++) { var _v = _c[_i]; _o[_i] = clamp(scl__jround((_k >= 0) ? _v + (255 - _v) * _k : _v * (1 + _k)), 0, 255); }
    return _o;
}
/// the MZ brassGrad(ctx, x0, y0, x1, y1)
function scl__brass_grad(_c, _x0, _y0, _x1, _y1) {
    var _B = scl__brass(), _g = scl_cx_linear(_c, _x0, _y0, _x1, _y1);
    scl__stop(_g, 0, _B.lo); scl__stop(_g, 0.3, _B.hi); scl__stop(_g, 0.5, _B.lite); scl__stop(_g, 0.7, _B.mid); scl__stop(_g, 1, _B.dark);
    return _g;
}
function scl__q_stroke(_c) {
    if (scl__logging(_c) && array_length(_c.dash) > 0) { var _d = ""; for (var _i = 0; _i < array_length(_c.dash); _i++) _d += ((_i > 0) ? "," : "") + string(_c.dash[_i]); scl__lg_emit(_c, "L" + _d + ";"); }
    scl__p_stroke(_c);
}
/// the MZ rr(ctx, x, y, w, h, r): a rounded rectangle path with quadratic corners, the radius clamped to the box
function scl__rr(_c, _x, _y, _w, _h, _r) {
    _r = max(0, min(_r, _w / 2, _h / 2));
    scl__p_begin(_c);
    scl__p_move(_c, _x + _r, _y); scl__p_line(_c, _x + _w - _r, _y); scl__p_quad(_c, _x + _w, _y, _x + _w, _y + _r);
    scl__p_line(_c, _x + _w, _y + _h - _r); scl__p_quad(_c, _x + _w, _y + _h, _x + _w - _r, _y + _h);
    scl__p_line(_c, _x + _r, _y + _h); scl__p_quad(_c, _x, _y + _h, _x, _y + _h - _r);
    scl__p_line(_c, _x, _y + _r); scl__p_quad(_c, _x, _y, _x + _r, _y);
    scl__p_close(_c);
}

// ---------------------------------------------------------------------------------------------------------------
// Type: four styles over the two faces, and the one non-ASCII character Scales sets (U+00B7, the middle dot)
// ---------------------------------------------------------------------------------------------------------------

/// face 0 = bold (Scales Display), 1 = regular (Scales Body), 2 = italic (Scales Body struck OBLIQUE), 3 = italic bold
/// (Scales Display struck oblique). The MZ sets italic lines in Palatino Italic, a system face no package may ship, and no
/// OFL italic is part of this package: the italic lines are the upright faces sheared 12 degrees - a named deviation.
#macro SCL_OBLIQUE 0.2126
/// the canvas font string -> face: the MZ's style word ("bold", "", "italic", "italic bold")
function scl__face_of(_style) { var _b = (string_pos("bold", _style) > 0), _i = (string_pos("italic", _style) > 0); return _b ? (_i ? 3 : 0) : (_i ? 2 : 1); }
/// the kit face an atlas is struck from
function scl__kit_face(_face) { return (_face == 0 || _face == 3) ? SCL_FACE_DISPLAY : SCL_FACE_BODY; }
/// U+00B7 in each face, read from the TTFs (Internal_Ops/_font_extra_advances.py): advance, dot centre and radius in em
function scl__dot(_face) { return (scl__kit_face(_face) == SCL_FACE_DISPLAY) ? { adv: 0.219, cx: 0.1095, cy: 0.353, r: 0.0725 } : { adv: 0.238, cx: 0.1195, cy: 0.2275, r: 0.0595 }; }
/// the width of a line at px, summed character by character in the order the oracle sums it (ASCII from the advance table,
/// U+00B7 from scl__dot), then times px; any other character measures 0
function scl__text_w(_s, _px, _face) {
    var _t = string(_s), _adv = scl_text_advance(scl__kit_face(_face)), _dot = scl__dot(_face), _sum = 0;
    for (var _i = 1; _i <= string_length(_t); _i++) { var _o = ord(string_char_at(_t, _i)); if (_o >= 32 && _o <= 126) _sum += _adv[_o - 32]; else if (_o == 183) _sum += _dot.adv; }
    return _sum * _px;
}
/// FNV-1a over a string's CHARACTERS (UTF-16 code units, as the MZ hashString's charCodeAt) - scl_hash reads UTF-8 BYTES,
/// which differ from it on any non-ASCII character (U+00B7 is two bytes and one code unit)
function scl__hash_u16(_s) {
    var _t = string(_s), _h = int64(2166136261);
    for (var _i = 1; _i <= string_length(_t); _i++) { _h = _h ^ int64(ord(string_char_at(_t, _i))); _h = scl__imul(_h, 16777619); }
    return real(_h);
}
/// the canvas font: px and face
function scl__font(_c, _px, _face) { _c.tf = { px: _px, face: _face }; }
/// align 0 = left, 1 = centre, 2 = right; base 0 = alphabetic, 1 = middle
function scl__text_align(_c, _align, _base) { _c.ta = _align; _c.tb = _base; }
function scl__measure(_c, _t) { var _f = _c[$ "tf"]; if (!is_struct(_f)) return 0; return scl__text_w(_t, _f.px, _f.face); }
/// the MZ fitText(ctx, text, maxW, size, style): the size steps down from `size` (to 9 at the least) until the line fits
function scl__fit_text(_c, _t, _maxw, _size, _style = "bold") {
    // the MZ writes (style || 'bold'): an EMPTY style is bold too (the ledger passes '' - found by the oracle diff)
    if (!is_string(_style) || _style == "") _style = "bold";
    var _face = scl__face_of(_style);
    scl__font(_c, _size, _face);
    while (_size > 9 && scl__measure(_c, _t) > _maxw) { _size--; scl__font(_c, _size, _face); }
    return _size;
}
/// the MZ wrap(ctx, text, maxW): words greedily into lines no wider than maxW (a lone long word stays whole)
function scl__wrap(_c, _t, _maxw) {
    var _words = string_split(string(_t), " "), _lines = [], _cur = "";
    for (var _i = 0; _i < array_length(_words); _i++) {
        var _try = (_cur != "") ? _cur + " " + _words[_i] : _words[_i];
        if (scl__measure(_c, _try) > _maxw && _cur != "") { array_push(_lines, _cur); _cur = _words[_i]; } else _cur = _try;
    }
    if (_cur != "") array_push(_lines, _cur);
    return _lines;
}
/// one glyph at the user-space baseline-left (x, y): an atlas glyph, the middle dot as a disc, an italic face sheared
function scl__strike(_c, _ch, _x, _y, _px, _face) {
    var _o = ord(_ch);
    if (_o == 183) {
        var _d = scl__dot(_face), _subs = _c.subs, _cur = _c.cur;
        scl_cx_begin(_c); scl_cx_arc(_c, _x + _d.cx * _px, _y - _d.cy * _px, _d.r * _px, 0, SCL_TAU); scl_cx_fill(_c);
        _c.subs = _subs; _c.cur = _cur;
        return;
    }
    if (_face < 2) { scl_cx_glyph(_c, _ch, _x, _y, _px, _face); return; }
    // oblique: shear x by the height above the baseline, about the glyph's DEVICE baseline
    var _p = scl_cx__pt(_c, _x, _y), _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, [1, 0, 0, 0, -SCL_OBLIQUE, 1, 0, 0, 0, 0, 1, 0, SCL_OBLIQUE * _p[1], 0, 0, 1]);
    scl_cx_glyph(_c, _ch, _x, _y, _px, scl__kit_face(_face));
    matrix_set(matrix_world, _mw);
}
/// the canvas fillText of a whole line: logged as ONE event (the oracle's T), struck glyph by glyph under the transform
function scl__q_text(_c, _t, _x, _y) {
    var _f = _c[$ "tf"], _al = _c[$ "ta"], _bl = _c[$ "tb"];
    if (!is_struct(_f)) _f = { px: 10, face: 1 };
    if (is_undefined(_al)) _al = 0;
    if (is_undefined(_bl)) _bl = 0;
    var _s = string(_t);
    if (scl__logging(_c)) scl__lg_emit(_c, "T" + scl__lg_paint(_c.fill) + ":" + string(int64(scl__hash_u16(_s))) + ":" + string(scl__r100(_x + _y)) + ":" + string(scl__r100(_f.px)) + ":" + string(_f.face) + ":" + ((_al == 1) ? "c" : ((_al == 2) ? "r" : "l")) + ((_bl == 1) ? "m" : "a") + ":" + scl__lg_t(_c) + scl__lg_a(_c) + ";");
    var _w = scl__text_w(_s, _f.px, _f.face), _xx = (_al == 1) ? _x - _w / 2 : ((_al == 2) ? _x - _w : _x);
    // a canvas "middle" baseline sits about a third of the em below the point (the em box's middle)
    var _yy = (_bl == 1) ? _y + _f.px * ((scl__kit_face(_f.face) == SCL_FACE_BODY) ? 0.32 : 0.34) : _y;
    var _adv = scl_text_advance(scl__kit_face(_f.face)), _dot = scl__dot(_f.face);
    for (var _i = 1; _i <= string_length(_s); _i++) {
        var _ch = string_char_at(_s, _i), _o = ord(_ch);
        if (_o != 32) scl__strike(_c, _ch, _xx, _yy, _f.px, _f.face);
        if (_o >= 32 && _o <= 126) _xx += _adv[_o - 32] * _f.px; else if (_o == 183) _xx += _dot.adv * _f.px;
    }
}

/// the canvas rect(x, y, w, h) path verb, logged as the recorder adds it (term by term)
function scl__q_rect(_c, _x, _y, _w, _h) {
    if (scl__logging(_c)) { _c.scl_lg.n += 1; _c.scl_lg.s += _x; _c.scl_lg.s += _y; _c.scl_lg.s += _w; _c.scl_lg.s += _h; }
    scl_cx_rect(_c, _x, _y, _w, _h);
}

/// @function scl_bal()
/// @description The balance's geometry, shared with the scene: { fx, fy (the fulcrum), arm, drop (hook to dish), dishW,
/// dishD, baseY, maxTilt }.
/// @returns {Struct}
function scl_bal() { static _B = { fx: 270, fy: 104, arm: 180, drop: 168, dishW: 142, dishD: 30, baseY: 366, maxTilt: 0.15 }; return _B; }
#macro SCL_BEAM_W 420
#macro SCL_BEAM_H 120
#macro SCL_BEAM_OX 210
#macro SCL_BEAM_OY 96

// ---------------------------------------------------------------------------------------------------------------
// The counting-house table
// ---------------------------------------------------------------------------------------------------------------

/// @function scl_draw_table(ctx, w, h, [inlay])
/// @description The walnut counter with a green baize inlay lit by a candle above the balance. inlay = { x, y, w, h }
/// moves the baize (default: under the balance and the tray).
function scl_draw_table(_c, _W, _H, _inlay = undefined) {
    if (!scl__is_ctx(_c) || !scl__fin(_W, _H) || _W <= 0 || _H <= 0) return;
    if (is_struct(_inlay) && !scl__fin(_inlay[$ "x"], _inlay[$ "y"], _inlay[$ "w"], _inlay[$ "h"])) _inlay = undefined;
    var _g = scl_cx_linear(_c, 0, 0, 0, _H); scl__stop(_g, 0, [46, 28, 16]); scl__stop(_g, 1, [23, 13, 7]); _c.fill = _g; scl__p_fill_rect(_c, 0, 0, _W, _H);
    var _r = scl__rng(int64($5CA1));
    // walnut grain, every line running past the edge
    for (var _y = 0; _y < _H; _y += 3) {
        _c.stroke = (scl__rng_next(_r) < 0.5) ? scl__rgb([255, 210, 160], 0.03) : scl__rgb([0, 0, 0], 0.13);
        _c.lw = 1 + scl__rng_next(_r) * 2;
        scl__p_begin(_c); scl__p_move(_c, -10, _y);
        for (var _x = -10; _x < _W + 50; _x += 40) scl__p_line(_c, _x, _y + sin(_x / 97 + _y / 41) * 2.2);
        scl__q_stroke(_c);
    }
    // baize inlay under the balance and the tray
    var _in = is_struct(_inlay);
    var _bx = _in ? _inlay.x : 12, _by = _in ? _inlay.y : 12, _bw = _in ? _inlay.w : 536, _bh = _in ? _inlay.h : _H - 24, _lx = _bx + _bw / 2;
    _c.fill = scl__rgb([0, 0, 0], 0.5); scl__rr(_c, _bx + 3, _by + 5, _bw, _bh, 8); scl__p_fill(_c);
    var _bg = scl_cx_radial(_c, _lx, 190, 40, _lx, 260, 460); scl__stop(_bg, 0, [47, 90, 60]); scl__stop(_bg, 0.55, [30, 63, 41]); scl__stop(_bg, 1, [15, 34, 22]);
    _c.fill = _bg; scl__rr(_c, _bx, _by, _bw, _bh, 8); scl__p_fill(_c);
    for (var _i = 0; _i < _bw * _bh / 90; _i++) {
        _c.fill = (scl__rng_next(_r) < 0.5) ? scl__rgb([160, 220, 170], 0.05) : scl__rgb([0, 0, 0], 0.08);
        var _sx = _bx + scl__rng_next(_r) * _bw, _sy = _by + scl__rng_next(_r) * _bh, _sh = 1 + scl__rng_next(_r) * 2;
        scl__p_fill_rect(_c, _sx, _sy, 1, _sh);
    }
    // a brass bead round the inlay
    var _B = scl__brass();
    _c.stroke = scl__rgb(_B.mid); _c.lw = 2; scl__rr(_c, _bx + 1, _by + 1, _bw - 2, _bh - 2, 7); scl__q_stroke(_c);
    _c.stroke = scl__rgb([255, 240, 190], 0.35); _c.lw = 1; scl__rr(_c, _bx + 3, _by + 3, _bw - 6, _bh - 6, 6); scl__q_stroke(_c);
    // candle pool of light, and a vignette
    var _lg = scl_cx_radial(_c, _lx, 150, 10, _lx, 200, 330); scl__stop(_lg, 0, [255, 200, 120], 0.16); scl__stop(_lg, 1, [255, 200, 120], 0); _c.fill = _lg; scl__p_fill_rect(_c, 0, 0, _W, _H);
    var _vg = scl_cx_radial(_c, _W / 2, _H / 2, _H * 0.35, _W / 2, _H / 2, _H * 0.85); scl__stop(_vg, 0, [0, 0, 0], 0); scl__stop(_vg, 1, [0, 0, 0], 0.45); _c.fill = _vg; scl__p_fill_rect(_c, 0, 0, _W, _H);
}

// ---------------------------------------------------------------------------------------------------------------
// The balance, in parts (geometry shared with the scene through scl_bal)
// ---------------------------------------------------------------------------------------------------------------

/// @function scl_draw_stand(ctx)
/// @description The static parts: the plinth, the fluted column, the scale arc the pointer reads against.
function scl_draw_stand(_c) {
    if (!scl__is_ctx(_c)) return;
    var _A = scl_bal(), _B = scl__brass(), _cx = _A.fx, _by = _A.baseY;
    scl_cx_save(_c);
    _c.fill = scl__rgb([0, 0, 0], 0.35); scl__p_begin(_c); scl__p_ellipse(_c, _cx + 8, _by + 38, 104, 12, 0, 0, SCL_TAU); scl__p_fill(_c);
    // stepped walnut plinth with brass feet
    var _pg = scl_cx_linear(_c, 0, _by, 0, _by + 36); scl__stop(_pg, 0, [106, 66, 40]); scl__stop(_pg, 1, [45, 26, 13]);
    _c.fill = _pg; scl__rr(_c, _cx - 88, _by + 12, 176, 22, 4); scl__p_fill(_c); scl__rr(_c, _cx - 64, _by, 128, 16, 3); scl__p_fill(_c);
    _c.stroke = scl__rgb([255, 220, 170], 0.25); _c.lw = 1; scl__p_begin(_c); scl__p_move(_c, _cx - 86, _by + 13.5); scl__p_line(_c, _cx + 86, _by + 13.5); scl__p_move(_c, _cx - 62, _by + 1.5); scl__p_line(_c, _cx + 62, _by + 1.5); scl__q_stroke(_c);
    var _feet = [-76, 76];
    for (var _f = 0; _f < 2; _f++) { var _dx = _feet[_f]; _c.fill = scl__brass_grad(_c, _cx + _dx - 9, 0, _cx + _dx + 9, 0); scl__p_begin(_c); scl__p_ellipse(_c, _cx + _dx, _by + 36, 10, 4, 0, 0, SCL_TAU); scl__p_fill(_c); }
    // column: fluted brass, a base collar and a capital
    var _top = _A.fy + 16, _bot = _by;
    _c.fill = scl__brass_grad(_c, _cx - 9, 0, _cx + 9, 0); scl__p_fill_rect(_c, _cx - 8, _top, 16, _bot - _top);
    _c.stroke = scl__rgb([78, 53, 16], 0.55); _c.lw = 1;
    for (var _fl = -4; _fl <= 4; _fl += 4) { scl__p_begin(_c); scl__p_move(_c, _cx + _fl + 0.5, _top + 14); scl__p_line(_c, _cx + _fl + 0.5, _bot - 14); scl__q_stroke(_c); }
    _c.fill = scl__brass_grad(_c, _cx - 16, 0, _cx + 16, 0); scl__rr(_c, _cx - 15, _bot - 14, 30, 14, 3); scl__p_fill(_c); scl__rr(_c, _cx - 12, _top, 24, 12, 3); scl__p_fill(_c);
    scl__p_begin(_c); scl__p_ellipse(_c, _cx, _bot - 16, 12, 4, 0, 0, SCL_TAU); scl__p_fill(_c);
    // the scale arc above the fulcrum
    var _R = 70, _a0 = -pi / 2 - 0.42, _a1 = -pi / 2 + 0.42;
    _c.stroke = scl__rgb(_B.mid); _c.lw = 7; scl__p_begin(_c); scl__p_arc(_c, _cx, _A.fy, _R, _a0, _a1); scl__q_stroke(_c);
    _c.stroke = scl__rgb([255, 245, 210], 0.55); _c.lw = 1; scl__p_begin(_c); scl__p_arc(_c, _cx, _A.fy, _R + 2.5, _a0, _a1); scl__q_stroke(_c);
    _c.stroke = scl__rgb(_B.dark); _c.lw = 1.2;
    for (var _k = -6; _k <= 6; _k++) {
        var _a = -pi / 2 + _k * 0.064, _l = (_k == 0) ? 10 : (((_k mod 3) == 0) ? 7 : 4);
        scl__p_begin(_c); scl__p_move(_c, _cx + cos(_a) * (_R - 3), _A.fy + sin(_a) * (_R - 3));
        scl__p_line(_c, _cx + cos(_a) * (_R + 3 + ((_k == 0) ? 4 : 0) - _l + 4), _A.fy + sin(_a) * (_R - 3 - _l)); scl__q_stroke(_c);
    }
    // two arms carrying the arc down to the capital
    _c.stroke = scl__rgb(_B.lo); _c.lw = 3; scl__p_begin(_c);
    scl__p_move(_c, _cx + cos(_a0) * _R, _A.fy + sin(_a0) * _R); scl__p_quad(_c, _cx - 40, _A.fy - 6, _cx - 10, _A.fy + 18);
    scl__p_move(_c, _cx + cos(_a1) * _R, _A.fy + sin(_a1) * _R); scl__p_quad(_c, _cx + 40, _A.fy - 6, _cx + 10, _A.fy + 18); scl__q_stroke(_c);
    scl_cx_restore(_c);
}

/// @function scl_draw_beam(ctx)
/// @description The beam, drawn about its pivot at (SCL_BEAM_OX, SCL_BEAM_OY) of its own SCL_BEAM_W x SCL_BEAM_H picture (the
/// scene rotates it): a tapered brass beam with scrolled ends, an engraved line and the pointer rising from the pivot.
function scl_draw_beam(_c) {
    if (!scl__is_ctx(_c)) return;
    var _B = scl__brass(), _ox = SCL_BEAM_OX, _oy = SCL_BEAM_OY, _L = scl_bal().arm;
    scl_cx_save(_c);
    _c.fill = scl__brass_grad(_c, _ox - 3, 0, _ox + 3, 0); scl__p_begin(_c); scl__p_move(_c, _ox - 3, _oy - 4); scl__p_line(_c, _ox, _oy - 78); scl__p_line(_c, _ox + 3, _oy - 4); scl__p_close(_c); scl__p_fill(_c);
    _c.stroke = scl__rgb(_B.dark); _c.lw = 0.8; scl__q_stroke(_c);
    var _g = scl_cx_linear(_c, 0, _oy - 9, 0, _oy + 9); scl__stop(_g, 0, _B.lite); scl__stop(_g, 0.35, _B.hi); scl__stop(_g, 0.7, _B.mid); scl__stop(_g, 1, _B.dark);
    _c.fill = _g; scl__p_begin(_c);
    scl__p_move(_c, _ox - _L, _oy - 3); scl__p_quad(_c, _ox - _L / 2, _oy - 5, _ox - 18, _oy - 9); scl__p_line(_c, _ox + 18, _oy - 9); scl__p_quad(_c, _ox + _L / 2, _oy - 5, _ox + _L, _oy - 3);
    scl__p_line(_c, _ox + _L, _oy + 3); scl__p_quad(_c, _ox + _L / 2, _oy + 5, _ox + 18, _oy + 9); scl__p_line(_c, _ox - 18, _oy + 9); scl__p_quad(_c, _ox - _L / 2, _oy + 5, _ox - _L, _oy + 3); scl__p_close(_c); scl__p_fill(_c);
    _c.stroke = scl__rgb(_B.dark); _c.lw = 1; scl__q_stroke(_c);
    // engraved line and punched dots along it
    _c.stroke = scl__rgb([78, 53, 16], 0.6); _c.lw = 0.9; scl__p_begin(_c); scl__p_move(_c, _ox - _L + 14, _oy); scl__p_line(_c, _ox - 24, _oy); scl__p_move(_c, _ox + 24, _oy); scl__p_line(_c, _ox + _L - 14, _oy); scl__q_stroke(_c);
    _c.fill = scl__rgb([78, 53, 16], 0.7);
    for (var _d = 36; _d < _L - 20; _d += 22) { scl__p_begin(_c); scl__p_arc(_c, _ox - _d, _oy - 0.2, 1.1, 0, SCL_TAU); scl__p_arc(_c, _ox + _d, _oy - 0.2, 1.1, 0, SCL_TAU); scl__p_fill(_c); }
    // scrolled ends curling up over the hook point
    var _sides = [-1, 1];
    for (var _i = 0; _i < 2; _i++) {
        var _s = _sides[_i], _ex = _ox + _s * _L;
        _c.stroke = scl__brass_grad(_c, _ex - 10, _oy - 16, _ex + 10, _oy + 4); _c.lw = 5; _c.cap = SCL_STROKE_ROUND;
        scl__p_begin(_c); scl__p_move(_c, _ex - _s * 6, _oy - 1); scl__p_quad(_c, _ex + _s * 12, _oy - 2, _ex + _s * 12, _oy - 12); scl__p_quad(_c, _ex + _s * 12, _oy - 20, _ex + _s * 4, _oy - 19); scl__p_quad(_c, _ex - _s * 2, _oy - 17, _ex + _s * 2, _oy - 11); scl__q_stroke(_c);
        _c.cap = 0;
        _c.fill = scl__rgb(_B.hi); scl__p_begin(_c); scl__p_arc(_c, _ex, _oy, 4.2, 0, SCL_TAU); scl__p_fill(_c); _c.stroke = scl__rgb(_B.dark); _c.lw = 1; scl__q_stroke(_c);
    }
    // the pivot boss
    var _bg = scl_cx_radial(_c, _ox - 4, _oy - 4, 1, _ox, _oy, 13); scl__stop(_bg, 0, _B.lite); scl__stop(_bg, 0.6, _B.mid); scl__stop(_bg, 1, _B.dark);
    _c.fill = _bg; scl__p_begin(_c); scl__p_arc(_c, _ox, _oy, 12, 0, SCL_TAU); scl__p_fill(_c); _c.stroke = scl__rgb(_B.dark); _c.lw = 1; scl__q_stroke(_c);
    _c.fill = scl__rgb(_B.dark); scl__p_begin(_c); scl__p_arc(_c, _ox, _oy, 3, 0, SCL_TAU); scl__p_fill(_c);
    scl_cx_restore(_c);
}

/// @function scl_draw_fulcrum(ctx)
/// @description The fulcrum housing that sits OVER the beam's pivot (static): a stirrup with a knife-edge cap.
function scl_draw_fulcrum(_c) {
    if (!scl__is_ctx(_c)) return;
    var _B = scl__brass(), _cx = scl_bal().fx, _cy = scl_bal().fy;
    scl_cx_save(_c);
    _c.fill = scl__brass_grad(_c, _cx - 18, 0, _cx + 18, 0);
    scl__p_begin(_c); scl__p_move(_c, _cx - 17, _cy + 16); scl__p_line(_c, _cx - 13, _cy - 18); scl__p_quad(_c, _cx, _cy - 27, _cx + 13, _cy - 18); scl__p_line(_c, _cx + 17, _cy + 16);
    scl__p_line(_c, _cx + 9, _cy + 16); scl__p_line(_c, _cx + 7, _cy - 12); scl__p_quad(_c, _cx, _cy - 17, _cx - 7, _cy - 12); scl__p_line(_c, _cx - 9, _cy + 16); scl__p_close(_c); scl__p_fill(_c);
    _c.stroke = scl__rgb(_B.dark); _c.lw = 1; scl__q_stroke(_c);
    _c.fill = scl__rgb(_B.lite); scl__p_begin(_c); scl__p_arc(_c, _cx, _cy - 22, 4, 0, SCL_TAU); scl__p_fill(_c); _c.stroke = scl__rgb(_B.dark); scl__q_stroke(_c);
    scl_cx_restore(_c);
}

// ---------------------------------------------------------------------------------------------------------------
// The ledger's beam glyph, the brass plaques, the status line and the tray cursor
// ---------------------------------------------------------------------------------------------------------------

/// @function scl_draw_beam_glyph(ctx, cx, cy, outcome)
/// @description A tiny balance drawn in ink, its beam tilted to show how a weighing fell (+1 left sank, 0 level, -1 right).
function scl_draw_beam_glyph(_c, _cx, _cy, _o) {
    var _a = (_o > 0) ? -0.35 : ((_o < 0) ? 0.35 : 0), _L = 15, _ink = scl__ink();
    scl_cx_save(_c); _c.stroke = scl__rgb(_ink); _c.fill = scl__rgb(_ink); _c.lw = 1.4;
    scl__p_begin(_c); scl__p_move(_c, _cx, _cy - 2); scl__p_line(_c, _cx, _cy + 9); scl__p_move(_c, _cx - 5, _cy + 9); scl__p_line(_c, _cx + 5, _cy + 9); scl__q_stroke(_c);
    var _lx = _cx - cos(_a) * _L, _ly = _cy - 2 + sin(_a) * _L, _rx = _cx + cos(_a) * _L, _ry = _cy - 2 - sin(_a) * _L;
    scl__p_begin(_c); scl__p_move(_c, _lx, _ly); scl__p_line(_c, _rx, _ry); scl__q_stroke(_c);
    var _ps = [[_lx, _ly], [_rx, _ry]];
    for (var _i = 0; _i < 2; _i++) { var _p = _ps[_i]; scl__p_begin(_c); scl__p_move(_c, _p[0] - 5, _p[1] + 5); scl__p_line(_c, _p[0] + 5, _p[1] + 5); scl__p_line(_c, _p[0], _p[1]); scl__p_close(_c); scl__q_stroke(_c); }
    scl_cx_restore(_c);
}

/// @function scl_draw_plaque(ctx, x, y, w, h, text, state)
/// @description A brass plaque button: state "on" (the cursor is on it), "idle" or "off" (not available now). The label is
/// fitted to the plaque.
function scl_draw_plaque(_c, _x, _y, _w, _h, _text, _state) {
    if (!scl__is_ctx(_c) || !scl__fin(_x, _y, _w, _h) || _w <= 0 || _h <= 0) return;
    if (!is_string(_text)) _text = is_undefined(_text) ? "" : string(_text);
    var _B = scl__brass(), _off = (_state == "off"), _on = (_state == "on");
    scl_cx_save(_c);
    _c.fill = scl__rgb([0, 0, 0], 0.45); scl__rr(_c, _x + 3, _y + 4, _w, _h, 6); scl__p_fill(_c);
    var _g = scl_cx_linear(_c, 0, _y, 0, _y + _h);
    if (_off) { scl__stop(_g, 0, [106, 90, 68]); scl__stop(_g, 1, [58, 46, 32]); }
    else if (_on) { scl__stop(_g, 0, [255, 240, 176]); scl__stop(_g, 0.5, [232, 184, 80]); scl__stop(_g, 1, [154, 106, 30]); }
    else { scl__stop(_g, 0, [242, 216, 144]); scl__stop(_g, 0.5, [201, 154, 66]); scl__stop(_g, 1, [138, 97, 32]); }
    _c.fill = _g; scl__rr(_c, _x, _y, _w, _h, 6); scl__p_fill(_c);
    _c.stroke = _off ? scl__rgb([30, 20, 10], 0.6) : scl__rgb([60, 40, 10], 0.75); _c.lw = 1; scl__rr(_c, _x + 3, _y + 3, _w - 6, _h - 6, 4); scl__q_stroke(_c);
    var _ps = [[_x + 8, _y + _h / 2], [_x + _w - 8, _y + _h / 2]];
    for (var _i = 0; _i < 2; _i++) { _c.fill = _off ? scl__rgb([74, 62, 48]) : scl__rgb(_B.lo); scl__p_begin(_c); scl__p_arc(_c, _ps[_i][0], _ps[_i][1], 2.4, 0, SCL_TAU); scl__p_fill(_c); }
    scl__text_align(_c, 1, 1); scl__fit_text(_c, _text, _w - 34, 15);
    _c.fill = _off ? scl__rgb([200, 180, 150], 0.45) : scl__rgb([255, 245, 210], 0.6); scl__q_text(_c, _text, _x + _w / 2 + 0.8, _y + _h / 2 + 1.8);
    _c.fill = _off ? scl__rgb([30, 20, 10], 0.8) : scl__rgb([58, 36, 8]); scl__q_text(_c, _text, _x + _w / 2, _y + _h / 2 + 1);
    scl_cx_restore(_c);
}

/// @function scl_draw_status(ctx, w, h, text)
/// @description The status line: italic, fitted to the strip, with a shadow line under it.
function scl_draw_status(_c, _W, _H, _text) {
    if (!scl__is_ctx(_c) || !scl__fin(_W, _H) || _W <= 0 || _H <= 0) return;
    if (!is_string(_text)) _text = is_undefined(_text) ? "" : string(_text);
    scl__fit_text(_c, _text, _W - 10, 17, "italic");
    scl__text_align(_c, 1, 1); _c.fill = scl__rgb([0, 0, 0], 0.65); scl__q_text(_c, _text, _W / 2 + 1, _H / 2 + 1); _c.fill = scl__rgb([241, 223, 180]); scl__q_text(_c, _text, _W / 2, _H / 2);
}

/// @function scl_draw_cursor(ctx)
/// @description The cursor over a tray slot: a gilt ring with four studs, about the centre of a 76 x 76 picture.
function scl_draw_cursor(_c) {
    _c.stroke = scl__rgb([0, 0, 0], 0.5); _c.lw = 4; scl__p_begin(_c); scl__p_arc(_c, 39, 40, 32, 0, SCL_TAU); scl__q_stroke(_c);
    _c.stroke = scl__rgb([240, 192, 80]); _c.lw = 2.5; scl__p_begin(_c); scl__p_arc(_c, 38, 38, 32, 0, SCL_TAU); scl__q_stroke(_c);
    _c.fill = scl__rgb([255, 242, 196]);
    for (var _i = 0; _i < 4; _i++) { var _a = _i * pi / 2 + pi / 4; scl__p_begin(_c); scl__p_arc(_c, 38 + cos(_a) * 32, 38 + sin(_a) * 32, 3, 0, SCL_TAU); scl__p_fill(_c); }
}

// ---------------------------------------------------------------------------------------------------------------
// Weights and goods (the measure puzzle)
// ---------------------------------------------------------------------------------------------------------------

/// @function scl_weight_h(value)
/// @description The height of the bell weight for a value (bigger weights stand taller).
/// @returns {Real}
function scl_weight_h(_v) { return scl__jround(20 + 9 * ln(1 + _v) / ln(2)); }

/// the canvas source-atop over what is already drawn, logged as the oracle logs a globalCompositeOperation change:
/// "O<mode>;" when it is set, and again when a restore puts the previous mode back
function scl__q_atop_rect(_c, _rgb, _a, _x, _y, _w, _h) {
    if (scl__logging(_c)) scl__lg_emit(_c, "Osource-atop;");
    _c.fill = scl__rgb(_rgb, _a);
    if (scl__logging(_c)) scl__lg_emit(_c, "R" + scl__lg_paint(_c.fill) + ":" + string(scl__r100(_x + _y + _w + _h)) + ":" + scl__lg_t(_c) + scl__lg_a(_c) + ";");
    // drawn: the paint premultiplied, weighted by the DESTINATION's alpha, the destination's alpha kept (source-atop)
    var _p0 = scl_cx__pt(_c, _x, _y), _p1 = scl_cx__pt(_c, _x + _w, _y + _h), _col = merge_colour(c_black, make_colour_rgb(_rgb[0], _rgb[1], _rgb[2]), _a);
    gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_dest_alpha, bm_inv_src_alpha, bm_zero, bm_one);
    draw_primitive_begin(pr_trianglestrip);
    draw_vertex_colour(_p0[0], _p0[1], _col, _a); draw_vertex_colour(_p1[0], _p0[1], _col, _a); draw_vertex_colour(_p0[0], _p1[1], _col, _a); draw_vertex_colour(_p1[0], _p1[1], _col, _a);
    draw_primitive_end(); gpu_pop_state();
    if (scl__logging(_c)) scl__lg_emit(_c, "Osource-over;");
}

/// @function scl_draw_weight(ctx, cx, base_y, value, [options])
/// @description A brass bell weight standing on (cx, base_y), stamped with its value. options = { dim: true } darkens it
/// (a weight already on a pan). Returns its width.
/// @returns {Real}
function scl_draw_weight(_c, _cx, _by, _v, _opt = undefined) {
    if (!scl__is_ctx(_c) || !scl__fin(_cx, _by, _v) || _v < 0) return 0;
    var _B = scl__brass(), _h = scl_weight_h(_v), _w = _h * 0.78, _top = _by - _h, _dim = is_struct(_opt) && (_opt[$ "dim"] == true);
    scl_cx_save(_c);
    _c.fill = scl__rgb([0, 0, 0], 0.35); scl__p_begin(_c); scl__p_ellipse(_c, _cx + 3, _by + 1, _w * 0.6, _w * 0.14, 0, 0, SCL_TAU); scl__p_fill(_c);
    var _g = scl__brass_grad(_c, _cx - _w / 2, 0, _cx + _w / 2, 0);
    _c.fill = _g; scl__p_begin(_c); scl__p_move(_c, _cx - _w / 2, _by);
    scl__p_bez(_c, _cx - _w / 2, _by - _h * 0.4, _cx - _w * 0.3, _top + _h * 0.3, _cx - _w * 0.22, _top + _h * 0.2); scl__p_line(_c, _cx + _w * 0.22, _top + _h * 0.2);
    scl__p_bez(_c, _cx + _w * 0.3, _top + _h * 0.3, _cx + _w / 2, _by - _h * 0.4, _cx + _w / 2, _by); scl__p_close(_c); scl__p_fill(_c);
    _c.stroke = scl__rgb(_B.dark); _c.lw = 1; scl__q_stroke(_c);
    _c.fill = scl__rgb(scl__shade(_B.lo, -0.1)); scl__p_begin(_c); scl__p_ellipse(_c, _cx, _by, _w / 2, _w * 0.1, 0, 0, pi); scl__p_fill(_c);
    // collar and knob
    _c.fill = _g; scl__rr(_c, _cx - _w * 0.26, _top + _h * 0.12, _w * 0.52, _h * 0.1, 2); scl__p_fill(_c); scl__q_stroke(_c);
    scl__p_begin(_c); scl__p_arc(_c, _cx, _top + _h * 0.07, max(3, _w * 0.13), 0, SCL_TAU); scl__p_fill(_c); scl__q_stroke(_c);
    // stamped value
    var _fs = max(9, scl__jround(_h * 0.34)); scl__font(_c, _fs, 0); scl__text_align(_c, 1, 1);
    _c.fill = scl__rgb([255, 245, 210], 0.55); scl__q_text(_c, string(_v), _cx + 0.8, _by - _h * 0.36 + 0.9); _c.fill = scl__rgb(_B.dark); scl__q_text(_c, string(_v), _cx, _by - _h * 0.36);
    if (_dim) scl__q_atop_rect(_c, [20, 14, 8], 0.6, _cx - _w, _top - 4, _w * 2, _h + 8);
    scl_cx_restore(_c);
    return _w;
}

/// @function scl_goods_look(goods)
/// @description The three colours a heap of goods is drawn in: [base, light, dark] as [r, g, b] (unknown goods: saffron).
/// @returns {Array<Array<Real>>}
function scl_goods_look(_g) {
    switch (_g) {
        case "pepper": return [[42, 36, 32], [74, 62, 52], [20, 16, 16]];
        case "silver dust": return [[184, 190, 196], [232, 236, 239], [122, 130, 136]];
        case "salt": return [[242, 239, 232], [255, 255, 255], [201, 196, 184]];
        case "tea": return [[74, 90, 42], [110, 122, 58], [44, 56, 24]];
        case "cloves": return [[90, 52, 32], [122, 74, 42], [58, 32, 16]];
        case "myrrh": return [[184, 112, 42], [224, 160, 80], [122, 68, 20]];
        case "indigo": return [[42, 58, 138], [74, 90, 176], [24, 32, 74]];
    }
    return [[200, 64, 30], [232, 116, 42], [138, 36, 16]];
}

/// @function scl_draw_goods(ctx, cx, rim_y, goods, seed)
/// @description A heap of goods in a dish, grain by grain, deterministic from the seed.
function scl_draw_goods(_c, _cx, _rimY, _goods, _seed) {
    if (!scl__is_ctx(_c) || !scl__fin(_cx, _rimY)) return;
    if (!scl__fin(_seed)) _seed = 1;
    var _C = scl_goods_look(_goods), _r = scl__rng((scl__u32(_seed) ^ int64($600D)) & int64($FFFFFFFF)), _w = 52, _h = 30;
    var _g = scl_cx_radial(_c, _cx - 10, _rimY - _h * 0.7, 2, _cx, _rimY - 6, _w); scl__stop(_g, 0, _C[1]); scl__stop(_g, 0.6, _C[0]); scl__stop(_g, 1, _C[2]);
    _c.fill = _g; scl__p_begin(_c); scl__p_move(_c, _cx - _w, _rimY + 2); scl__p_bez(_c, _cx - _w * 0.6, _rimY - _h * 0.9, _cx + _w * 0.6, _rimY - _h * 0.9, _cx + _w, _rimY + 2); scl__p_close(_c); scl__p_fill(_c);
    var _sticks = (_goods == "saffron" || _goods == "cloves");
    for (var _i = 0; _i < 260; _i++) {
        var _t = scl__rng_next(_r) * 2 - 1, _x = _cx + _t * _w * 0.95, _tp = _rimY + 2 - (1 - _t * _t) * _h * 0.66;
        var _y = _tp + scl__rng_next(_r) * (_rimY + 2 - _tp);
        _c.fill = scl__rgb(_C[floor(scl__rng_next(_r) * 3) mod 3]);
        if (_sticks) { scl_cx_save(_c); scl_cx_translate(_c, _x, _y); scl_cx_rotate(_c, scl__rng_next(_r) * SCL_TAU); scl__p_fill_rect(_c, -2.5, -0.6, 5, 1.2); scl_cx_restore(_c); }
        else { var _gw = 1.6 + scl__rng_next(_r) * 1.4, _gh = 1.4 + scl__rng_next(_r); scl__p_fill_rect(_c, _x, _y, _gw, _gh); }
    }
    _c.fill = scl__rgb([255, 255, 255], 0.18); scl__p_begin(_c); scl__p_ellipse(_c, _cx - 14, _rimY - _h * 0.5, 12, 4, -0.2, 0, SCL_TAU); scl__p_fill(_c);
}

// ---------------------------------------------------------------------------------------------------------------
// The coin tray and the weight box
// ---------------------------------------------------------------------------------------------------------------

/// @function scl_tray()
/// @description Where the tray (and the weight box) sits in the scene: { x, y, w, h }.
/// @returns {Struct}
function scl_tray() { static _T = { x: 26, y: 428, w: 508, h: 180 }; return _T; }

/// @function scl_tray_slots(n)
/// @description Slot centres for n coins in the tray: two rows, centred. Returns [{ x, y }].
/// @returns {Array<Struct>}
function scl_tray_slots(_n) {
    if (!scl__fin(_n) || _n < 1) return [];
    _n = floor(min(_n, 4096));
    var _T = scl_tray(), _top = ceil(_n / 2), _bot = _n - _top, _out = [], _pitch = min(70, (_T.w - 40) / max(1, _top));
    for (var _i = 0; _i < _n; _i++) { var _row = (_i < _top) ? 0 : 1, _k = _row ? _i - _top : _i, _cnt = _row ? _bot : _top; array_push(_out, { x: _T.x + _T.w / 2 + (_k - (_cnt - 1) / 2) * _pitch, y: _T.y + (_row ? 118 : 46) }); }
    return _out;
}

/// @function scl_draw_tray(ctx, n)
/// @description The wooden counting tray with a round recess and a burned number per coin (the coins are drawn on top).
function scl_draw_tray(_c, _n) {
    if (!scl__is_ctx(_c) || !scl__fin(_n) || _n < 0) return;
    var _T = scl_tray();
    scl_cx_save(_c);
    _c.fill = scl__rgb([0, 0, 0], 0.5); scl__rr(_c, _T.x + 4, _T.y + 6, _T.w, _T.h, 10); scl__p_fill(_c);
    var _g = scl_cx_linear(_c, 0, _T.y, 0, _T.y + _T.h); scl__stop(_g, 0, [138, 90, 50]); scl__stop(_g, 1, [90, 54, 28]); _c.fill = _g; scl__rr(_c, _T.x, _T.y, _T.w, _T.h, 10); scl__p_fill(_c);
    var _r = scl__rng(int64($7A7)); _c.lw = 1;
    for (var _y = _T.y + 3; _y < _T.y + _T.h - 2; _y += 2.5) {
        _c.stroke = (scl__rng_next(_r) < 0.5) ? scl__rgb([255, 220, 170], 0.06) : scl__rgb([40, 20, 5], 0.12);
        scl__p_begin(_c); scl__p_move(_c, _T.x + 4, _y); scl__p_bez(_c, _T.x + _T.w * 0.3, _y + sin(_y) * 2, _T.x + _T.w * 0.7, _y - cos(_y) * 2, _T.x + _T.w - 4, _y); scl__q_stroke(_c);
    }
    _c.stroke = scl__rgb([255, 220, 170], 0.3); scl__rr(_c, _T.x + 1.5, _T.y + 1.5, _T.w - 3, _T.h - 3, 9); scl__q_stroke(_c);
    _c.stroke = scl__rgb([30, 15, 5], 0.6); scl__rr(_c, _T.x + 8, _T.y + 8, _T.w - 16, _T.h - 16, 7); scl__q_stroke(_c);
    var _S = scl_tray_slots(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _s = _S[_i], _rg = scl_cx_radial(_c, _s.x, _s.y - 6, 4, _s.x, _s.y, 28); scl__stop(_rg, 0, [58, 34, 16]); scl__stop(_rg, 1, [94, 58, 30]);
        _c.fill = _rg; scl__p_begin(_c); scl__p_arc(_c, _s.x, _s.y, 27, 0, SCL_TAU); scl__p_fill(_c);
        _c.stroke = scl__rgb([255, 220, 170], 0.25); scl__p_begin(_c); scl__p_arc(_c, _s.x, _s.y, 27, 0.2, pi - 0.2); scl__q_stroke(_c);
        scl__font(_c, 13, 0); scl__text_align(_c, 1, 1);
        _c.fill = scl__rgb([255, 225, 180], 0.25); scl__q_text(_c, string(_i + 1), _s.x + 0.7, _s.y + 35.7); _c.fill = scl__rgb([42, 22, 8]); scl__q_text(_c, string(_i + 1), _s.x, _s.y + 35);
    }
    scl_cx_restore(_c);
}

/// @function scl_box_slots(weights)
/// @description Slot centres (and base lines) for the weight box. Returns [{ x, y }].
/// @returns {Array<Struct>}
function scl_box_slots(_weights) {
    if (!is_array(_weights) || array_length(_weights) == 0) return [];
    var _T = scl_tray(), _n = array_length(_weights), _out = [], _pitch = (_T.w - 60) / _n;
    for (var _i = 0; _i < _n; _i++) array_push(_out, { x: _T.x + 30 + _pitch * (_i + 0.5), y: _T.y + 116 });
    return _out;
}

/// @function scl_draw_box(ctx, weights, set_name)
/// @description The fitted weight box: a lined wooden case with a recess per weight and its value burned beside it.
function scl_draw_box(_c, _weights, _setName) {
    if (!scl__is_ctx(_c) || !is_array(_weights) || array_length(_weights) == 0) return;
    if (!is_string(_setName)) _setName = is_undefined(_setName) ? "" : string(_setName);
    var _T = scl_tray();
    scl_cx_save(_c);
    _c.fill = scl__rgb([0, 0, 0], 0.5); scl__rr(_c, _T.x + 4, _T.y + 6, _T.w, _T.h, 8); scl__p_fill(_c);
    var _g = scl_cx_linear(_c, 0, _T.y, 0, _T.y + _T.h); scl__stop(_g, 0, [122, 74, 40]); scl__stop(_g, 1, [74, 42, 20]); _c.fill = _g; scl__rr(_c, _T.x, _T.y, _T.w, _T.h, 8); scl__p_fill(_c);
    var _lg = scl_cx_linear(_c, 0, _T.y + 22, 0, _T.y + _T.h - 12); scl__stop(_lg, 0, [90, 26, 34]); scl__stop(_lg, 1, [58, 14, 20]); _c.fill = _lg; scl__rr(_c, _T.x + 14, _T.y + 26, _T.w - 28, _T.h - 40, 5); scl__p_fill(_c);
    var _r = scl__rng(int64($B0C5));
    for (var _i = 0; _i < 900; _i++) {
        _c.fill = (scl__rng_next(_r) < 0.5) ? scl__rgb([255, 160, 170], 0.05) : scl__rgb([0, 0, 0], 0.12);
        var _x = _T.x + 14 + scl__rng_next(_r) * (_T.w - 28), _y = _T.y + 26 + scl__rng_next(_r) * (_T.h - 40);
        scl__p_fill_rect(_c, _x, _y, 1, 1);
    }
    var _nm = string(_setName); if (string_copy(_nm, 1, 4) == "the ") _nm = "The " + string_delete(_nm, 1, 4);
    scl__font(_c, 14, 3); scl__text_align(_c, 1, 1); _c.fill = scl__rgb([255, 225, 180], 0.75); scl__q_text(_c, _nm, _T.x + _T.w / 2, _T.y + 14);
    var _S = scl_box_slots(_weights);
    for (var _k = 0; _k < array_length(_weights); _k++) {
        var _s = _S[_k], _w = scl_weight_h(_weights[_k]) * 0.78;
        _c.fill = scl__rgb([0, 0, 0], 0.45); scl__p_begin(_c); scl__p_ellipse(_c, _s.x, _s.y + 2, _w * 0.62, _w * 0.16, 0, 0, SCL_TAU); scl__p_fill(_c);
        scl__font(_c, 13, 0); _c.fill = scl__rgb([255, 215, 190], 0.55); scl__q_text(_c, string(_weights[_k]), _s.x, _s.y + 24);
    }
    scl_cx_restore(_c);
}

// ---------------------------------------------------------------------------------------------------------------
// Coins
// ---------------------------------------------------------------------------------------------------------------

/// @function scl_metal_look(metal)
/// @description A metal's four colours { face, rim, dark, lite } as [r, g, b] (unknown metal: gold).
/// @returns {Struct}
function scl_metal_look(_m) {
    switch (_m) {
        case "silver": return { face: [207, 212, 216], rim: [154, 162, 169], dark: [76, 84, 91], lite: [255, 255, 255] };
        case "copper": return { face: [207, 125, 74], rim: [156, 85, 48], dark: [78, 37, 18], lite: [255, 210, 174] };
        case "electrum": return { face: [217, 199, 122], rim: [168, 150, 78], dark: [88, 77, 32], lite: [255, 246, 200] };
        case "bronze": return { face: [184, 137, 78], rim: [138, 98, 50], dark: [67, 41, 14], lite: [240, 210, 160] };
    }
    return { face: [232, 184, 74], rim: [184, 131, 42], dark: [110, 74, 18], lite: [255, 240, 184] };
}

/// the device of a mint as a closed path in a unit circle (radius 1), built at the current transform (begins the path)
function scl__device_path(_c, _m) {
    var _i, _a, _n;
    scl__p_begin(_c);
    switch (_m.device) {
        case "star":
            _n = _m.points;
            for (_i = 0; _i < _n * 2; _i++) { _a = -pi / 2 + _i * pi / _n; var _rad = ((_i mod 2) != 0) ? _m.inner * 0.95 : 1; if (_i != 0) scl__p_line(_c, cos(_a) * _rad, sin(_a) * _rad); else scl__p_move(_c, cos(_a) * _rad, sin(_a) * _rad); }
            scl__p_close(_c); break;
        case "rosette":
            _n = _m.petals;
            for (_i = 0; _i < _n; _i++) { _a = -pi / 2 + _i * SCL_TAU / _n; scl__p_move(_c, cos(_a) * 0.18, sin(_a) * 0.18); scl__p_ellipse(_c, cos(_a) * 0.55, sin(_a) * 0.55, 0.42, 0.24, _a, 0, SCL_TAU); }
            break;
        case "cross": {
            var _t = 0.16, _f = 0.42, _P = [[_t, _t], [_f, 1], [-_f, 1], [-_t, _t]];
            for (_i = 0; _i < 4; _i++) {
                var _ang = _i * pi / 2, _co = cos(_ang), _si = sin(_ang);
                for (var _j = 0; _j < 4; _j++) { var _x = _P[_j][0] * _co - _P[_j][1] * _si, _y = _P[_j][0] * _si + _P[_j][1] * _co; if (_j != 0) scl__p_line(_c, _x, _y); else scl__p_move(_c, _x, _y); }
                scl__p_close(_c);
            }
            scl__q_rect(_c, -_t, -_t, 2 * _t, 2 * _t); break;
        }
        case "sun":
            _n = _m.rays;
            for (_i = 0; _i < _n * 2; _i++) { _a = -pi / 2 + _i * pi / _n; var _r2 = ((_i mod 2) != 0) ? 0.52 : (((_i mod 4) == 0) ? 1 : 0.82); if (_i != 0) scl__p_line(_c, cos(_a) * _r2, sin(_a) * _r2); else scl__p_move(_c, cos(_a) * _r2, sin(_a) * _r2); }
            scl__p_close(_c); break;
        case "crescent":
            scl__p_arc(_c, -0.08, 0, 0.78, pi * 0.3, pi * 1.7, false); scl__p_arc(_c, 0.26, 0, 0.62, pi * 1.62, pi * 0.38, true); scl__p_close(_c); break;
        default: // tower: a crenellated keep with a gate
            scl__p_move(_c, -0.5, 0.82); scl__p_line(_c, -0.5, -0.42);
            for (_i = 0; _i < 5; _i++) { var _x0 = -0.5 + _i * 0.25; scl__p_line(_c, _x0, -0.62); scl__p_line(_c, _x0 + 0.125, -0.62); scl__p_line(_c, _x0 + 0.125, -0.42); scl__p_line(_c, _x0 + 0.25, -0.42); }
            scl__p_line(_c, 0.5, 0.82); scl__p_line(_c, 0.17, 0.82); scl__p_line(_c, 0.17, 0.42); scl__p_arc(_c, 0, 0.42, 0.17, 0, pi, true); scl__p_line(_c, -0.17, 0.82); scl__p_close(_c);
    }
}
/// the small secondary marks of a device (pellets, stars, a window) as dots [x, y, r] in the unit circle
function scl__device_dots(_m) {
    var _out = [], _i, _a;
    if (_m.device == "star" && _m.pellets) for (_i = 0; _i < _m.points; _i++) { _a = -pi / 2 + (_i + 0.5) * SCL_TAU / _m.points; array_push(_out, [cos(_a) * 0.82, sin(_a) * 0.82, 0.07]); }
    else if (_m.device == "rosette") array_push(_out, [0, 0, 0.2]);
    else if (_m.device == "cross" && _m.pellets) for (_i = 0; _i < 4; _i++) { _a = pi / 4 + _i * pi / 2; array_push(_out, [cos(_a) * 0.62, sin(_a) * 0.62, 0.09]); }
    else if (_m.device == "sun") array_push(_out, [0, 0, 0.36]);
    else if (_m.device == "crescent") { array_push(_out, [0.55, -0.42, 0.08]); array_push(_out, [0.66, 0, 0.1]); array_push(_out, [0.55, 0.42, 0.08]); }
    else if (_m.device == "tower") { array_push(_out, [-0.25, -0.08, 0.07]); array_push(_out, [0.25, -0.08, 0.07]); }
    return _out;
}
/// @function scl_core_of(metal, dir)
/// @description What a counterfeit of this metal is made of under its skin, and the colour its cut shows: { name, colour }.
/// Heavy (+1) = a lead core; light = copper under gold, silver or electrum, tin under copper or bronze.
/// @returns {Struct}
function scl_core_of(_metal, _dir) {
    if (_dir > 0) return { name: "lead", colour: [102, 98, 93] };
    return (_metal == "copper" || _metal == "bronze") ? { name: "tin", colour: [168, 168, 158] } : { name: "copper", colour: [122, 74, 42] };
}
/// a banker's test cut: a V-shaped chisel cut from the rim toward the centre, exposing a dull base-metal core
function scl__test_cut(_c, _cx, _cy, _r, _M, _dir, _metal) {
    var _a = -pi * 0.28, _tip = [_cx + cos(_a) * _r * 0.12, _cy + sin(_a) * _r * 0.12], _w = 0.26;
    var _p1 = [_cx + cos(_a - _w) * _r * 1.02, _cy + sin(_a - _w) * _r * 1.02], _p2 = [_cx + cos(_a + _w) * _r * 1.02, _cy + sin(_a + _w) * _r * 1.02];
    var _core = scl_core_of(_metal, _dir).colour;
    var _cg = scl_cx_linear(_c, _p1[0], _p1[1], _p2[0], _p2[1]); scl__stop(_cg, 0, scl__shade(_core, -0.45)); scl__stop(_cg, 0.5, scl__shade(_core, 0.2)); scl__stop(_cg, 1, scl__shade(_core, -0.3));
    _c.fill = _cg; scl__p_begin(_c); scl__p_move(_c, _tip[0], _tip[1]); scl__p_line(_c, _p1[0], _p1[1]); scl__p_line(_c, _p2[0], _p2[1]); scl__p_close(_c); scl__p_fill(_c);
    _c.stroke = scl__rgb(_M.lite); _c.lw = max(1, _r * 0.025); scl__p_begin(_c); scl__p_move(_c, _p1[0], _p1[1]); scl__p_line(_c, _tip[0], _tip[1]); scl__q_stroke(_c);
    _c.stroke = scl__rgb(_M.dark); scl__p_begin(_c); scl__p_move(_c, _tip[0], _tip[1]); scl__p_line(_c, _p2[0], _p2[1]); scl__q_stroke(_c);
    _c.stroke = scl__rgb(_M.face); _c.lw = max(1, _r * 0.035); scl__p_begin(_c);
    scl__p_move(_c, _p1[0], _p1[1]); scl__p_line(_c, _p1[0] + (_tip[0] - _p1[0]) * 0.12, _p1[1] + (_tip[1] - _p1[1]) * 0.12);
    scl__p_move(_c, _p2[0], _p2[1]); scl__p_line(_c, _p2[0] + (_tip[0] - _p2[0]) * 0.12, _p2[1] + (_tip[1] - _p2[1]) * 0.12); scl__q_stroke(_c);
}
/// @function scl_legend_text(mint)
/// @description The legend struck round a coin: "TOWER GOLD (dot) CROWNS (dot) ", one copy.
/// @returns {String}
function scl_legend_text(_m) {
    var _n = string(_m.name); if (string_copy(_n, 1, 4) == "The ") _n = string_delete(_n, 1, 4);
    return string_upper(_n + " " + chr(183) + " " + _m.unit) + " " + chr(183) + " ";
}
/// lettering round the coin, reading clockwise from the top, struck in relief; repeated while a whole copy fits
function scl__legend(_c, _cx, _cy, _R, _text, _size, _M) {
    scl_cx_save(_c); scl__font(_c, scl__jround(_size), 0); scl__text_align(_c, 1, 1);
    var _one = scl__measure(_c, _text) + string_length(_text) * _size * 0.12, _reps = max(1, floor(SCL_TAU * _R * 0.94 / _one)), _full = "";
    for (var _q = 0; _q < _reps; _q++) _full += _text;
    var _total = 0, _ws = [], _i, _n = string_length(_full);
    for (_i = 0; _i < _n; _i++) { array_push(_ws, scl__measure(_c, string_char_at(_full, _i + 1)) + _size * 0.12); _total += _ws[_i]; }
    var _span = min(SCL_TAU * 0.96, _total / _R), _a = -pi / 2 - _span / 2;
    for (_i = 0; _i < _n; _i++) {
        var _ai = _a + _ws[_i] / 2 / _R, _ch = string_char_at(_full, _i + 1);
        scl_cx_save(_c); scl_cx_translate(_c, _cx + cos(_ai) * _R, _cy + sin(_ai) * _R); scl_cx_rotate(_c, _ai + pi / 2);
        _c.fill = scl__rgb(_M.dark); scl__q_text(_c, _ch, 0.6, 0.7); _c.fill = scl__rgb(_M.lite); scl__q_text(_c, _ch, 0, 0); scl_cx_restore(_c);
        _a += _ws[_i] / _R;
    }
    scl_cx_restore(_c);
}
/// the MZ emboss: a dot path filled dark one step down-right, then lite on top
function scl__emboss_dot(_c, _M, _x, _y, _rad, _r) {
    var _o = max(0.5, _r * 0.012);
    scl_cx_save(_c); scl_cx_translate(_c, _o, _o); scl__p_begin(_c); scl__p_arc(_c, _x, _y, _rad, 0, SCL_TAU); _c.fill = scl__rgb(_M.dark); scl__p_fill(_c); scl_cx_restore(_c);
    scl__p_begin(_c); scl__p_arc(_c, _x, _y, _rad, 0, SCL_TAU); _c.fill = scl__rgb(_M.lite); scl__p_fill(_c);
}

/// @function scl_draw_coin(ctx, cx, cy, r, mint, [options])
/// @description One coin of a mint, face on, at (cx, cy), radius r: thickness, rim treatment, legend (r >= 34), device in
/// relief, lustre. options = { cut: +1 heavy / -1 light } draws a banker's test cut showing the base metal inside (the
/// counterfeit, found); { dim: true } greys it.
function scl_draw_coin(_c, _cx, _cy, _r, _m, _opt = undefined) {
    if (!scl__is_ctx(_c) || !scl__fin(_cx, _cy, _r) || _r <= 0 || !scl__is_mint(_m)) return;
    var _o = is_struct(_opt) ? _opt : {}, _M = scl_metal_look(_m.metal), _th = max(1.5, _r * 0.09);
    scl_cx_save(_c);
    // shadow and edge thickness
    _c.fill = scl__rgb([0, 0, 0], 0.38); scl__p_begin(_c); scl__p_ellipse(_c, _cx + _r * 0.1, _cy + _r * 0.16, _r * 1.02, _r * 0.98, 0, 0, SCL_TAU); scl__p_fill(_c);
    _c.fill = scl__rgb(_M.dark); scl__p_begin(_c); scl__p_arc(_c, _cx, _cy + _th, _r, 0, SCL_TAU); scl__p_fill(_c);
    // face
    var _g = scl_cx_radial(_c, _cx - _r * 0.35, _cy - _r * 0.4, _r * 0.05, _cx, _cy, _r * 1.05); scl__stop(_g, 0, _M.lite); scl__stop(_g, 0.45, _M.face); scl__stop(_g, 1, _M.rim);
    _c.fill = _g; scl__p_begin(_c); scl__p_arc(_c, _cx, _cy, _r, 0, SCL_TAU); scl__p_fill(_c);
    // raised rim
    _c.lw = max(1.2, _r * 0.1); _c.stroke = scl__rgb(_M.rim); scl__p_begin(_c); scl__p_arc(_c, _cx, _cy, _r * 0.94, 0, SCL_TAU); scl__q_stroke(_c);
    _c.lw = max(0.6, _r * 0.025); _c.stroke = scl__rgb(_M.lite); scl__p_begin(_c); scl__p_arc(_c, _cx, _cy, _r * 0.97, pi * 1.05, pi * 1.7); scl__q_stroke(_c);
    // rim treatment
    var _i, _a, _k;
    if (_m.rim == "beaded") { _k = max(16, scl__jround(_r * 1.1)); for (_i = 0; _i < _k; _i++) { _a = _i * SCL_TAU / _k; scl__emboss_dot(_c, _M, _cx + cos(_a) * _r * 0.84, _cy + sin(_a) * _r * 0.84, max(0.7, _r * 0.035), _r); } }
    else if (_m.rim == "milled") { _k = max(24, scl__jround(_r * 1.6)); _c.stroke = scl__rgb(_M.dark); _c.lw = max(0.6, _r * 0.018); for (_i = 0; _i < _k; _i++) { _a = _i * SCL_TAU / _k; scl__p_begin(_c); scl__p_move(_c, _cx + cos(_a) * _r * 0.9, _cy + sin(_a) * _r * 0.9); scl__p_line(_c, _cx + cos(_a) * _r * 0.99, _cy + sin(_a) * _r * 0.99); scl__q_stroke(_c); } }
    else { _k = max(14, scl__jround(_r * 0.9)); _c.stroke = scl__rgb(_M.dark); _c.lw = max(0.7, _r * 0.03); for (_i = 0; _i < _k; _i++) { _a = _i * SCL_TAU / _k; var _b = _a + SCL_TAU / _k * 0.7; scl__p_begin(_c); scl__p_move(_c, _cx + cos(_a) * _r * 0.8, _cy + sin(_a) * _r * 0.8); scl__p_line(_c, _cx + cos(_b) * _r * 0.88, _cy + sin(_b) * _r * 0.88); scl__q_stroke(_c); } }
    // inner ring and legend
    var _dr = _m.ring ? 0.64 : 0.72;
    if (_m.ring) { _c.stroke = scl__rgb(_M.dark); _c.lw = max(0.6, _r * 0.02); scl__p_begin(_c); scl__p_arc(_c, _cx, _cy, _r * 0.72, 0, SCL_TAU); scl__q_stroke(_c); }
    if (_r >= 34) scl__legend(_c, _cx, _cy, _r * 0.78, scl_legend_text(_m), max(7, _r * 0.1), _M);
    else if (_m.ring) { _c.fill = scl__rgb(_M.dark); _k = _m.legend; for (_i = 0; _i < _k; _i++) { _a = -pi / 2 + (_i + 0.5) * SCL_TAU / _k; scl__p_fill_rect(_c, _cx + cos(_a) * _r * 0.77 - 0.5, _cy + sin(_a) * _r * 0.77 - 0.5, 1, 1); } }
    // device in relief
    scl_cx_save(_c); scl_cx_translate(_c, _cx, _cy); scl_cx_scale(_c, _r * _dr * 0.92, _r * _dr * 0.92);
    var _dg = scl_cx_linear(_c, -1, -1, 1, 1); scl__stop(_dg, 0, _M.lite); scl__stop(_dg, 0.5, _M.face); scl__stop(_dg, 1, _M.rim);
    scl_cx_translate(_c, 0.035, 0.05); scl__device_path(_c, _m); _c.fill = scl__rgb([0, 0, 0], 0.35); scl__p_fill(_c); scl_cx_translate(_c, -0.035, -0.05);
    scl__device_path(_c, _m); _c.fill = _dg; scl__p_fill(_c); _c.lw = 1.4 / (_r * _dr); _c.stroke = scl__rgb(_M.dark); scl__q_stroke(_c);
    var _dots = scl__device_dots(_m);
    for (_i = 0; _i < array_length(_dots); _i++) {
        var _dd = _dots[_i];
        scl__p_begin(_c); scl__p_arc(_c, _dd[0] + 0.03, _dd[1] + 0.04, _dd[2], 0, SCL_TAU); _c.fill = scl__rgb([0, 0, 0], 0.35); scl__p_fill(_c);
        scl__p_begin(_c); scl__p_arc(_c, _dd[0], _dd[1], _dd[2], 0, SCL_TAU); _c.fill = _dg; scl__p_fill(_c); _c.stroke = scl__rgb(_M.dark); scl__q_stroke(_c);
    }
    scl_cx_restore(_c);
    // lustre
    var _lg = scl_cx_radial(_c, _cx - _r * 0.4, _cy - _r * 0.45, 0, _cx - _r * 0.4, _cy - _r * 0.45, _r * 0.8); scl__stop(_lg, 0, [255, 255, 255], 0.35); scl__stop(_lg, 1, [255, 255, 255], 0);
    _c.fill = _lg; scl__p_begin(_c); scl__p_arc(_c, _cx, _cy, _r, 0, SCL_TAU); scl__p_fill(_c);
    var _cut = _o[$ "cut"];
    if (is_numeric(_cut) && _cut != 0) scl__test_cut(_c, _cx, _cy, _r, _M, _cut, _m.metal);
    if (_o[$ "dim"] == true) { _c.fill = scl__rgb([20, 14, 8], 0.55); scl__p_begin(_c); scl__p_arc(_c, _cx, _cy, _r + 1, 0, SCL_TAU); scl__p_fill(_c); }
    scl_cx_restore(_c);
}

/// @function scl_draw_coin_flat(ctx, cx, cy, rx, mint)
/// @description A coin lying in a pan, seen at the pan's low angle: a flattened disc with its edge.
function scl_draw_coin_flat(_c, _cx, _cy, _rx, _m) {
    if (!scl__is_ctx(_c) || !scl__fin(_cx, _cy, _rx) || _rx <= 0 || !scl__is_mint(_m)) return;
    var _M = scl_metal_look(_m.metal), _ry = _rx * 0.36;
    _c.fill = scl__rgb(_M.dark); scl__p_begin(_c); scl__p_ellipse(_c, _cx, _cy + 2, _rx, _ry, 0, 0, SCL_TAU); scl__p_fill(_c);
    var _g = scl_cx_linear(_c, _cx - _rx, _cy - _ry, _cx + _rx, _cy + _ry); scl__stop(_g, 0, _M.lite); scl__stop(_g, 0.5, _M.face); scl__stop(_g, 1, _M.rim);
    _c.fill = _g; scl__p_begin(_c); scl__p_ellipse(_c, _cx, _cy, _rx, _ry, 0, 0, SCL_TAU); scl__p_fill(_c);
    _c.stroke = scl__rgb(_M.rim); _c.lw = 1; scl__p_begin(_c); scl__p_ellipse(_c, _cx, _cy, _rx * 0.78, _ry * 0.72, 0, 0, SCL_TAU); scl__q_stroke(_c);
}

/// @function scl_pile_coins(ctx, cx, rim_y, count, mint)
/// @description Coins piled in a dish: rows of flattened discs, the front row lowest.
function scl_pile_coins(_c, _cx, _rimY, _count, _m) {
    if (!scl__is_ctx(_c) || !scl__fin(_cx, _rimY, _count) || _count < 1 || !scl__is_mint(_m)) return;
    _count = floor(min(_count, 64));
    var _perT = [0, 1, 2, 3, 4, 3, 3, 4, 4, 4], _per = _perT[min(9, _count)], _rows = [], _left = _count;
    if (_per == 0) _per = 4;
    while (_left > 0) { var _n = min(_left, max(1, _per - array_length(_rows))); array_push(_rows, _n); _left -= _n; }
    for (var _r = array_length(_rows) - 1; _r >= 0; _r--) for (var _i = 0; _i < _rows[_r]; _i++) scl_draw_coin_flat(_c, _cx + (_i - (_rows[_r] - 1) / 2) * 27 + (((_r mod 2) != 0) ? 6 : 0), _rimY - 2 - _r * 6.5, 15, _m);
}

// ---------------------------------------------------------------------------------------------------------------
// The pans
// ---------------------------------------------------------------------------------------------------------------

#macro SCL_PAN_W 200
#macro SCL_PAN_H 250
#macro SCL_PAN_HX 100

/// @function scl_draw_pan(ctx, [contents], [label])
/// @description A pan and its chains, drawn with the hook at (SCL_PAN_HX, 6) of its SCL_PAN_W x SCL_PAN_H picture.
/// contents(ctx, cx, rim_y) draws whatever lies in the dish, between the dish's back and its front lip (a function, or
/// undefined); label hangs under the dish on a paper tag. part (optional) draws one layer only, for a scene that keeps the
/// layers as separate pictures: 0 everything (default), 1 the chains and the dish's back, 2 the bowl and front lip, 3 the tag.
function scl_draw_pan(_c, _contents = undefined, _label = "", _part = 0) {
    if (!scl__is_ctx(_c)) return;
    if (!is_string(_label)) _label = is_undefined(_label) ? "" : string(_label);
    if (!scl__fin(_part)) _part = 0;
    var _B = scl__brass(), _A = scl_bal(), _hx = SCL_PAN_HX, _hy = 6, _rimY = _hy + _A.drop, _w = _A.dishW, _d = _A.dishD;
    scl_cx_save(_c);
    if (_part == 0 || _part == 1) {
    // hook ring
    _c.stroke = scl__rgb(_B.mid); _c.lw = 2.5; scl__p_begin(_c); scl__p_arc(_c, _hx, _hy + 4, 4, 0, SCL_TAU); scl__q_stroke(_c);
    // three chains: two outer, one to the back of the rim
    var _ends = [[_hx - _w / 2 + 6, _rimY], [_hx + _w / 2 - 6, _rimY], [_hx, _rimY - 8]];
    for (var _ci = 0; _ci < 3; _ci++) {
        var _e = _ends[_ci], _ex = _e[0] - _hx, _ey = _e[1] - _hy - 8, _len = sqrt(_ex * _ex + _ey * _ey), _n = floor(_len / 7);
        for (var _i = 0; _i < _n; _i++) {
            var _t = (_i + 0.5) / _n, _x = _hx + (_e[0] - _hx) * _t, _y = _hy + 8 + (_e[1] - _hy - 8) * _t, _ang = arctan2(_e[1] - _hy, _e[0] - _hx);
            _c.stroke = (_ci == 2) ? scl__rgb([138, 98, 32], 0.7) : scl__rgb(((_i mod 2) != 0) ? _B.mid : _B.hi); _c.lw = 1.4;
            scl__p_begin(_c);
            if ((_i mod 2) != 0) scl__p_ellipse(_c, _x, _y, 1.4, 3.6, _ang - pi / 2, 0, SCL_TAU); else scl__p_ellipse(_c, _x, _y, 3.6, 1.8, _ang, 0, SCL_TAU);
            scl__q_stroke(_c);
        }
    }
    // dish: the back of the rim, the contents, then the bowl and the front lip
    _c.fill = scl__rgb(scl__shade(_B.lo, -0.2)); scl__p_begin(_c); scl__p_ellipse(_c, _hx, _rimY, _w / 2, 9, 0, pi, SCL_TAU); scl__p_fill(_c);
    var _ig = scl_cx_linear(_c, 0, _rimY - 9, 0, _rimY + 9); scl__stop(_ig, 0, [90, 62, 20]); scl__stop(_ig, 1, [138, 98, 36]); _c.fill = _ig; scl__p_begin(_c); scl__p_ellipse(_c, _hx, _rimY, _w / 2 - 3, 7.5, 0, 0, SCL_TAU); scl__p_fill(_c);
    }
    if (_part == 0 && is_callable(_contents)) _contents(_c, _hx, _rimY);
    if (_part == 0 || _part == 2) {
    var _bg =scl_cx_linear(_c, _hx - _w / 2, 0, _hx + _w / 2, 0); scl__stop(_bg, 0, _B.dark); scl__stop(_bg, 0.25, _B.mid); scl__stop(_bg, 0.45, _B.lite); scl__stop(_bg, 0.62, _B.hi); scl__stop(_bg, 1, _B.lo);
    _c.fill = _bg; scl__p_begin(_c); scl__p_move(_c, _hx - _w / 2, _rimY); scl__p_bez(_c, _hx - _w / 2 + 12, _rimY + _d, _hx + _w / 2 - 12, _rimY + _d, _hx + _w / 2, _rimY); scl__p_ellipse(_c, _hx, _rimY, _w / 2, 9, 0, 0, pi, false); scl__p_close(_c); scl__p_fill(_c);
    _c.stroke = scl__rgb(_B.dark); _c.lw = 1; scl__q_stroke(_c);
    _c.stroke = scl__rgb(_B.lite); _c.lw = 2; scl__p_begin(_c); scl__p_ellipse(_c, _hx, _rimY, _w / 2 - 1, 8.5, 0, 0.1, pi - 0.1); scl__q_stroke(_c);
    _c.stroke = scl__rgb([78, 53, 16], 0.5); _c.lw = 0.8; scl__p_begin(_c); scl__p_ellipse(_c, _hx, _rimY + 12, _w / 2 - 22, 5, 0, 0.3, pi - 0.3); scl__q_stroke(_c);
    }
    // label: a paper tag hung under the dish
    if ((_part == 0 || _part == 3) && is_string(_label) && _label != "") {
        scl__font(_c, 14, 0); var _tw = min(SCL_PAN_W - 10, scl__measure(_c, _label) + 20), _ty = _rimY + _d + 14;
        _c.stroke = scl__rgb([210, 190, 150], 0.8); _c.lw = 1; scl__p_begin(_c); scl__p_move(_c, _hx, _rimY + _d - 4); scl__p_line(_c, _hx, _ty); scl__q_stroke(_c);
        _c.fill = scl__rgb([0, 0, 0], 0.4); scl__rr(_c, _hx - _tw / 2 + 2, _ty + 3, _tw, 22, 3); scl__p_fill(_c);
        var _pg = scl_cx_linear(_c, 0, _ty, 0, _ty + 22); scl__stop(_pg, 0, [247, 238, 216]); scl__stop(_pg, 1, [233, 218, 184]); _c.fill = _pg; scl__rr(_c, _hx - _tw / 2, _ty, _tw, 22, 3); scl__p_fill(_c);
        _c.fill = scl__rgb(scl__ink()); scl__text_align(_c, 1, 1); var _fs = 14;
        while (_fs > 9 && scl__measure(_c, _label) > _tw - 12) { _fs--; scl__font(_c, _fs, 0); }
        scl__q_text(_c, _label, _hx, _ty + 11.5);
    }
    scl_cx_restore(_c);
}

// ---------------------------------------------------------------------------------------------------------------
// Paper, the card, the ledger
// ---------------------------------------------------------------------------------------------------------------

/// the MZ paper(ctx, x, y, w, h, seed): a parchment sheet with a shadow, fibres and a darkened edge
function scl__paper(_c, _x, _y, _w, _h, _seed) {
    _c.fill = scl__rgb([0, 0, 0], 0.45); scl__rr(_c, _x + 4, _y + 6, _w, _h, 5); scl__p_fill(_c);
    var _g = scl_cx_linear(_c, 0, _y, 0, _y + _h); scl__stop(_g, 0, [247, 238, 216]); scl__stop(_g, 1, [233, 218, 184]); _c.fill = _g; scl__rr(_c, _x, _y, _w, _h, 5); scl__p_fill(_c);
    var _r = scl__rng(_seed);
    for (var _i = 0; _i < _w * _h / 70; _i++) {
        _c.fill = (scl__rng_next(_r) < 0.5) ? scl__rgb([160, 120, 70], 0.07) : scl__rgb([255, 255, 255], 0.2);
        var _fx = _x + scl__rng_next(_r) * _w, _fy = _y + scl__rng_next(_r) * _h, _fw = 1 + scl__rng_next(_r) * 2;
        scl__p_fill_rect(_c, _fx, _fy, _fw, 1);
    }
    var _eg = scl_cx_radial(_c, _x + _w / 2, _y + _h / 2, min(_w, _h) * 0.3, _x + _w / 2, _y + _h / 2, max(_w, _h) * 0.7); scl__stop(_eg, 0, [0, 0, 0], 0); scl__stop(_eg, 1, [120, 80, 30], 0.2);
    _c.fill = _eg; scl__rr(_c, _x, _y, _w, _h, 5); scl__p_fill(_c);
}

/// @function scl_draw_card(ctx, w, h, info)
/// @description The mint card (counterfeit) or the order slip (measure): info = { kicker, title, sub, task, mint } or
/// { kicker, title, sub, task, goods, seed } - a specimen coin or the goods in a small dish, a title and the task.
function scl_draw_card(_c, _w, _h, _info) {
    if (!scl__is_ctx(_c) || !scl__fin(_w, _h) || _w <= 120 || _h <= 0 || !is_struct(_info)) return;
    _info = scl__texts(_info, ["kicker", "title", "sub", "task"]);
    var _B = scl__brass(), _ink = scl__ink();
    scl__paper(_c, 0, 0, _w - 8, _h - 10, int64($CA4D));
    var _cw = _w - 8;
    _c.stroke = scl__rgb([122, 74, 26]); _c.lw = 1.2; scl__rr(_c, 6, 6, _cw - 12, _h - 22, 3); scl__q_stroke(_c);
    scl__text_align(_c, 1, 1);
    _c.fill = scl__rgb([122, 74, 26]); scl__font(_c, 11, 0); scl__q_text(_c, _info.kicker, _cw / 2, 20);
    if (is_struct(_info[$ "mint"])) scl_draw_coin(_c, 52, 74, 36, _info.mint, {});
    else if (is_string(_info[$ "goods"])) {
        scl_cx_save(_c); scl_cx_translate(_c, 52, 92); _c.fill = scl__brass_grad(_c, -40, 0, 40, 0); scl__p_begin(_c); scl__p_ellipse(_c, 0, 4, 40, 9, 0, 0, SCL_TAU); scl__p_fill(_c); _c.stroke = scl__rgb(_B.dark); _c.lw = 1; scl__q_stroke(_c);
        scl_cx_scale(_c, 0.62, 0.62); scl_draw_goods(_c, 0, 4, _info.goods, (is_numeric(_info[$ "seed"]) && _info.seed != 0) ? _info.seed : 1); scl_cx_restore(_c);
    }
    // the title is set in [100, cw - 12], inside the card's frame line at cw - 6 (the MZ edition's box, 96 + (cw - 96) / 2
    // centred and cw - 104 wide, reaches past that line on a long mint name - a named deviation, held by the oracle)
    var _tx = 100 + (_cw - 112) / 2, _tw = _cw - 112;
    scl__fit_text(_c, _info.title, _tw, 17); _c.fill = scl__rgb(_ink); scl__q_text(_c, _info.title, _tx, 56);
    scl__font(_c, 12, 2); _c.fill = scl__rgb([90, 68, 48]); var _sub = scl__wrap(_c, _info.sub, _tw);
    for (var _i = 0; _i < min(3, array_length(_sub)); _i++) scl__q_text(_c, _sub[_i], _tx, 78 + _i * 15);
    scl__font(_c, 13, 1); _c.fill = scl__rgb(_ink); var _t = scl__wrap(_c, _info.task, _cw - 28);
    for (var _j = 0; _j < min(4, array_length(_t)); _j++) scl__q_text(_c, _t[_j], _cw / 2, 128 + _j * 17);
}

/// @function scl_roman(n)
/// @returns {String} I..XII, else the number
function scl_roman(_n) { var _R = ["", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"]; return (is_numeric(_n) && _n >= 1 && _n <= 12 && _n == floor(_n)) ? _R[_n] : string(_n); }

/// @function scl_draw_ledger(ctx, w, h, info)
/// @description The ledger: the weighings allowed as brass tokens (info.allowed, info.left - or info.headline when none are
/// counted), then one line per weighing with a drawn beam showing how it fell. info.entries = [{ text, o }] with o = +1
/// left sank, 0 level, -1 right sank; info.empty is shown when there are none.
function scl_draw_ledger(_c, _w, _h, _info) {
    if (!scl__is_ctx(_c) || !scl__fin(_w, _h) || _w <= 60 || _h <= 0 || !is_struct(_info)) return;
    var _B = scl__brass(), _ink = scl__ink();
    scl__paper(_c, 0, 0, _w - 8, _h - 10, int64($1ED6));
    var _cw = _w - 8, _i;
    _c.stroke = scl__rgb([140, 40, 40], 0.5); _c.lw = 1; scl__p_begin(_c); scl__p_move(_c, 34.5, 8); scl__p_line(_c, 34.5, _h - 18); scl__q_stroke(_c);
    _c.stroke = scl__rgb([90, 110, 160], 0.22);
    for (var _y = 58; _y < _h - 16; _y += 26) { scl__p_begin(_c); scl__p_move(_c, 8, _y + 0.5); scl__p_line(_c, _cw - 8, _y + 0.5); scl__q_stroke(_c); }
    scl__text_align(_c, 1, 1); _c.fill = scl__rgb([122, 74, 26]); scl__font(_c, 12, 0); scl__q_text(_c, "THE LEDGER", _cw / 2, 18);
    var _allowed = is_numeric(_info[$ "allowed"]) ? _info.allowed : 0, _left = is_numeric(_info[$ "left"]) ? _info.left : 0;
    if (_allowed > 0) {
        var _tw = 16, _x0 = _cw / 2 - (_allowed - 1) * _tw / 2;
        for (_i = 0; _i < _allowed; _i++) {
            var _full = (_i < _left);
            _c.fill = _full ? scl__brass_grad(_c, _x0 + _i * _tw - 6, 0, _x0 + _i * _tw + 6, 0) : scl__rgb([90, 60, 30], 0.15); scl__p_begin(_c); scl__p_arc(_c, _x0 + _i * _tw, 38, 6, 0, SCL_TAU); scl__p_fill(_c);
            _c.stroke = _full ? scl__rgb(_B.dark) : scl__rgb([90, 60, 30], 0.5); scl__q_stroke(_c);
        }
    } else { scl__font(_c, 12, 2); _c.fill = scl__rgb([90, 68, 48]); scl__q_text(_c, is_string(_info[$ "headline"]) ? _info.headline : "", _cw / 2, 38); }
    var _E = is_array(_info[$ "entries"]) ? _info.entries : [], _show = min(array_length(_E), floor((_h - 70) / 26)), _start = array_length(_E) - _show;
    for (_i = 0; _i < _show; _i++) {
        var _e = _E[_start + _i], _ly = 58 + 13 + _i * 26;
        scl__font(_c, 13, 0); _c.fill = scl__rgb([122, 42, 26]); scl__text_align(_c, 1, 1); scl__q_text(_c, scl_roman(_start + _i + 1), 20, _ly);
        scl_draw_beam_glyph(_c, _cw - 26, _ly + 2, _e.o);
        scl__text_align(_c, 0, 1); scl__fit_text(_c, _e.text, _cw - 96, 13, ""); _c.fill = scl__rgb(_ink); scl__q_text(_c, _e.text, 42, _ly);
    }
    if (array_length(_E) == 0) { scl__text_align(_c, 1, 1); scl__font(_c, 13, 2); _c.fill = scl__rgb([90, 68, 48], 0.7); scl__q_text(_c, is_string(_info[$ "empty"]) && _info.empty != "" ? _info.empty : "No weighings yet.", _cw / 2, 71); }
}

// ---------------------------------------------------------------------------------------------------------------
// The verdict: the cut coin or the sealed packet, large, with a plaque
// ---------------------------------------------------------------------------------------------------------------

function scl__plaque(_c, _cx, _cy, _w, _title, _sub, _good) {
    var _has = is_string(_sub) && _sub != "", _h = _has ? 56 : 36, _x = _cx - _w / 2, _y = _cy - _h / 2;
    _c.fill = scl__rgb([0, 0, 0], 0.45); scl__rr(_c, _x + 3, _y + 4, _w, _h, 6); scl__p_fill(_c);
    var _g = scl_cx_linear(_c, 0, _y, 0, _y + _h);
    if (_good) { scl__stop(_g, 0, [246, 220, 148]); scl__stop(_g, 0.5, [201, 154, 66]); scl__stop(_g, 1, [138, 97, 32]); } else { scl__stop(_g, 0, [216, 205, 189]); scl__stop(_g, 0.5, [154, 142, 126]); scl__stop(_g, 1, [94, 84, 72]); }
    _c.fill = _g; scl__rr(_c, _x, _y, _w, _h, 6); scl__p_fill(_c); _c.stroke = scl__rgb([60, 40, 10], 0.7); _c.lw = 1; scl__rr(_c, _x + 3, _y + 3, _w - 6, _h - 6, 4); scl__q_stroke(_c);
    scl__text_align(_c, 1, 1); scl__fit_text(_c, _title, _w - 24, 19);
    _c.fill = scl__rgb([255, 245, 210], 0.6); scl__q_text(_c, _title, _cx, (_has ? _cy - 10 : _cy) + 1); _c.fill = scl__rgb([58, 36, 8]); scl__q_text(_c, _title, _cx, _has ? _cy - 10 : _cy);
    if (_has) { scl__fit_text(_c, _sub, _w - 24, 13, "italic"); _c.fill = scl__rgb([74, 48, 16]); scl__q_text(_c, _sub, _cx, _cy + 14); }
}
function scl__weights_width(_list) { var _s = 0; for (var _q = 0; _q < array_length(_list); _q++) _s += scl_weight_h(_list[_q]) * 0.78 + 8; return _s; }
function scl__weights_row(_c, _list, _x0, _cap, _y, _h) {
    // the baseline stays "middle" (the packet set it for its amount; the MZ row changes only the alignment)
    var _wx = _x0; scl__font(_c, 12, 2); _c.fill = scl__rgb([232, 212, 168]); scl__text_align(_c, 1, 1);
    scl__q_text(_c, _cap, _x0 + scl__weights_width(_list) / 2, _y + _h + 86);
    for (var _q = 0; _q < array_length(_list); _q++) { var _ww = scl_weight_h(_list[_q]) * 0.78; scl_draw_weight(_c, _wx + _ww / 2, _y + _h + 66, _list[_q]); _wx += _ww + 8; }
}

/// @function scl_draw_packet(ctx, cx, cy, info)
/// @description A paper packet of the weighed goods, folded and sealed with wax, with its label; the weights that did the
/// weighing stand under it (info = { amount, label, weights, place }).
function scl_draw_packet(_c, _cx, _cy, _info) {
    var _w = 190, _h = 150, _x = _cx - _w / 2, _y = _cy - _h / 2 - 20, _ink = scl__ink();
    _c.fill = scl__rgb([0, 0, 0], 0.45); scl__p_begin(_c); scl__p_ellipse(_c, _cx + 8, _y + _h + 12, _w * 0.6, 14, 0, 0, SCL_TAU); scl__p_fill(_c);
    var _g = scl_cx_linear(_c, _x, _y, _x + _w, _y + _h); scl__stop(_g, 0, [239, 224, 188]); scl__stop(_g, 1, [201, 180, 138]); _c.fill = _g;
    scl__p_begin(_c); scl__p_move(_c, _x, _y + 20); scl__p_line(_c, _x + _w, _y + 20); scl__p_line(_c, _x + _w - 10, _y + _h); scl__p_line(_c, _x + 10, _y + _h); scl__p_close(_c); scl__p_fill(_c);
    _c.fill = scl__rgb([217, 198, 154]); scl__p_begin(_c); scl__p_move(_c, _x - 4, _y + 20); scl__p_line(_c, _cx, _y - 18); scl__p_line(_c, _x + _w + 4, _y + 20); scl__p_line(_c, _cx, _y + 46); scl__p_close(_c); scl__p_fill(_c);
    _c.stroke = scl__rgb([90, 60, 20], 0.5); _c.lw = 1; scl__q_stroke(_c);
    _c.stroke = scl__rgb([138, 42, 32]); _c.lw = 2; scl__p_begin(_c); scl__p_move(_c, _cx, _y - 14); scl__p_line(_c, _cx, _y + _h - 2); scl__p_move(_c, _x + 8, _y + 70); scl__p_line(_c, _x + _w - 8, _y + 70); scl__q_stroke(_c);
    var _sg = scl_cx_radial(_c, _cx - 6, _y + 40, 2, _cx, _y + 46, 24); scl__stop(_sg, 0, [224, 88, 72]); scl__stop(_sg, 1, [122, 26, 20]); _c.fill = _sg; scl__p_begin(_c);
    for (var _i = 0; _i < 14; _i++) { var _a = _i / 14 * SCL_TAU, _rad = 22 + (((_i mod 2) != 0) ? 3 : 0); if (_i != 0) scl__p_line(_c, _cx + cos(_a) * _rad, _y + 46 + sin(_a) * _rad); else scl__p_move(_c, _cx + cos(_a) * _rad, _y + 46 + sin(_a) * _rad); }
    scl__p_close(_c); scl__p_fill(_c);
    _c.stroke = scl__rgb([255, 200, 180], 0.5); _c.lw = 1.5; scl__p_begin(_c); scl__p_arc(_c, _cx, _y + 46, 13, 0, SCL_TAU); scl__q_stroke(_c);
    scl__font(_c, 16, 0); scl__text_align(_c, 1, 1); _c.fill = scl__rgb([255, 220, 200], 0.8); scl__q_text(_c, string(_info.amount), _cx, _y + 47);
    scl__paper(_c, _x + 26, _y + 88, _w - 52, 44, int64($1ABE)); _c.fill = scl__rgb(_ink); scl__fit_text(_c, _info.label, _w - 64, 15); scl__q_text(_c, _info.label, _cx, _y + 110);
    if (is_array(_info[$ "weights"]) && is_array(_info[$ "place"])) {
        var _gl = [], _fr = [];
        for (var _j = 0; _j < array_length(_info.weights); _j++) { if (_info.place[_j] < 0) array_push(_gl, _info.weights[_j]); else if (_info.place[_j] > 0) array_push(_fr, _info.weights[_j]); }
        if (array_length(_gl) > 0) scl__weights_row(_c, _gl, _cx - 24 - scl__weights_width(_gl), "with the goods", _y, _h);
        scl__weights_row(_c, _fr, _cx + 24, "on the far pan", _y, _h);
    }
}

/// @function scl_draw_verdict(ctx, w, h, info)
/// @description The finished plate: { mint, dir, genuine, title, sub, won } shows the false coin with its test cut and
/// the true ones of the hoard in a row below it; { goods, amount, label, weights, place, title, sub, won } shows the
/// sealed packet. A plaque carries the title.
function scl_draw_verdict(_c, _W, _H, _info) {
    if (!scl__is_ctx(_c) || !scl__fin(_W, _H) || _W <= 0 || _H <= 0 || !is_struct(_info)) return;
    _c.fill = scl__rgb([10, 6, 3], 0.86); scl__p_fill_rect(_c, 0, 0, _W, _H);
    var _cx = 270, _cy = 262;
    var _hg = scl_cx_radial(_c, _cx, _cy, 20, _cx, _cy, 220); scl__stop(_hg, 0, [255, 210, 130], 0.22); scl__stop(_hg, 1, [255, 210, 130], 0); _c.fill = _hg; scl__p_fill_rect(_c, 0, 0, _W, _H);
    if (is_struct(_info[$ "mint"])) {
        var _dir = (is_numeric(_info[$ "dir"]) && _info.dir != 0) ? _info.dir : 1;
        scl_draw_coin(_c, _cx, _cy - 34, 112, _info.mint, { cut: _dir });
        var _gn = (is_numeric(_info[$ "genuine"]) && _info.genuine != 0) ? _info.genuine : 5, _k = min(7, max(2, _gn));
        for (var _i = 0; _i < _k; _i++) scl_draw_coin(_c, _cx + (_i - (_k - 1) / 2) * 62, _cy + 146, 25, _info.mint, {});
    } else if (is_string(_info[$ "goods"])) scl_draw_packet(_c, _cx, _cy, _info);
    scl__plaque(_c, _cx, 520, 440, _info.title, _info[$ "sub"], _info[$ "won"] == true);
}
