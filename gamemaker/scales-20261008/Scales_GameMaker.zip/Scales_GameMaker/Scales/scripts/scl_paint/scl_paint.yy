{
  "$GMScript": "v1",
  "%Name": "scl_paint",
  "name": "scl_paint",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}