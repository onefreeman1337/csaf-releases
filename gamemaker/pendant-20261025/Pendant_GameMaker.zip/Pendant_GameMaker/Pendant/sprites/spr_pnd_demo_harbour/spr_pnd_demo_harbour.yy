{
  "$GMSprite": "v2",
  "%Name": "spr_pnd_demo_harbour",
  "bboxMode": 1,
  "bbox_bottom": 428,
  "bbox_left": 0,
  "bbox_right": 639,
  "bbox_top": 0,
  "collisionKind": 1,
  "collisionTolerance": 0,
  "DynamicTexturePage": false,
  "edgeFiltering": false,
  "For3D": false,
  "frames": [
    {
      "$GMSpriteFrame": "v1",
      "%Name": "71e66b46-5812-5e7d-0a74-18369d06a229",
      "name": "71e66b46-5812-5e7d-0a74-18369d06a229",
      "resourceType": "GMSpriteFrame",
      "resourceVersion": "2.0"
    }
  ],
  "gridX": 0,
  "gridY": 0,
  "height": 429,
  "HTile": false,
  "layers": [
    {
      "$GMImageLayer": "",
      "%Name": "b7f6d789-fe37-1319-170d-47c5c649519b",
      "blendMode": 0,
      "displayName": "default",
      "isLocked": false,
      "name": "b7f6d789-fe37-1319-170d-47c5c649519b",
      "opacity": 100,
      "resourceType": "GMImageLayer",
      "resourceVersion": "2.0",
      "visible": true
    }
  ],
  "name": "spr_pnd_demo_harbour",
  "nineSlice": null,
  "origin": 0,
  "parent": {
    "name": "Sprites",
    "path": "folders/Sprites.yy"
  },
  "preMultiplyAlpha": false,
  "resourceType": "GMSprite",
  "resourceVersion": "2.0",
  "sequence": {
    "$GMSequence": "v1",
    "%Name": "spr_pnd_demo_harbour",
    "autoRecord": true,
    "backdropHeight": 768,
    "backdropImageOpacity": 0.5,
    "backdropImagePath": "",
    "backdropWidth": 1366,
    "backdropXOffset": 0,
    "backdropYOffset": 0,
    "events": {
      "$KeyframeStore<MessageEventKeyframe>": "",
      "Keyframes": [],
      "resourceType": "KeyframeStore<MessageEventKeyframe>",
      "resourceVersion": "2.0"
    },
    "eventStubScript": null,
    "eventToFunction": {},
    "length": 1,
    "lockOrigin": false,
    "moments": {
      "$KeyframeStore<MomentsEventKeyframe>": "",
      "Keyframes": [],
      "resourceType": "KeyframeStore<MomentsEventKeyframe>",
      "resourceVersion": "2.0"
    },
    "name": "spr_pnd_demo_harbour",
    "playback": 1,
    "playbackSpeed": 30,
    "playbackSpeedType": 0,
    "resourceType": "GMSequence",
    "resourceVersion": "2.0",
    "showBackdrop": true,
    "showBackdropImage": false,
    "timeUnits": 1,
    "tracks": [
      {
        "$GMSpriteFramesTrack": "",
        "builtinName": 0,
        "events": [],
        "inheritsTrackColour": true,
        "interpolation": 1,
        "isCreationTrack": false,
        "keyframes": {
          "$KeyframeStore<SpriteFrameKeyframe>": "",
          "Keyframes": [
            {
              "$Keyframe<SpriteFrameKeyframe>": "",
              "Channels": {
                "0": {
                  "$SpriteFrameKeyframe": "",
                  "Id": {
                    "name": "71e66b46-5812-5e7d-0a74-18369d06a229",
                    "path": "sprites/spr_pnd_demo_harbour/spr_pnd_demo_harbour.yy"
                  },
                  "resourceType": "SpriteFrameKeyframe",
                  "resourceVersion": "2.0"
                }
              },
              "Disabled": false,
              "id": "3f46889b-d067-de95-df93-853b821e4f70",
              "IsCreationKey": false,
              "Key": 0,
              "Length": 1,
              "resourceType": "Keyframe<SpriteFrameKeyframe>",
              "resourceVersion": "2.0",
              "Stretch": false
            }
          ],
          "resourceType": "KeyframeStore<SpriteFrameKeyframe>",
          "resourceVersion": "2.0"
        },
        "modifiers": [],
        "name": "frames",
        "resourceType": "GMSpriteFramesTrack",
        "resourceVersion": "2.0",
        "spriteId": null,
        "trackColour": 0,
        "tracks": [],
        "traits": 0
      }
    ],
    "visibleRange": null,
    "volume": 1,
    "xorigin": 0,
    "yorigin": 0
  },
  "swatchColours": null,
  "swfPrecision": 0.5,
  "textureGroupId": {
    "name": "Default",
    "path": "texturegroups/Default"
  },
  "type": 0,
  "VTile": false,
  "width": 640
}