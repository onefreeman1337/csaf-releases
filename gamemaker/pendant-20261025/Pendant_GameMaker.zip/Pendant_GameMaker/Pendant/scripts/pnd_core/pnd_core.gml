/// pnd_core.gml - Pendant's difference maker: the second copy of a picture changed in 1 to 12 places, every change MEASURED
/// to be visible before it is kept. Pure GML over pixel buffers: nothing here draws to the screen, nothing uses the
/// engine's random functions.
///
/// Pendant - Spot the Difference From Any Picture, for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// The RPG Maker MZ edition's PendantCore.js, ported line for line and held to it by the in-engine suite (pnd_selftest):
/// given the same picture bytes, seed, count and kinds, the same changes at the same places and the same output bytes.
///
/// Four kinds of change
///   add       a small drawn object that belongs on the ground it lands on (a fish in water, a star in a night sky, a key on
///             a stone wall) - pnd_object_count() objects, each in a colour picked to stand out from that ground;
///   mirror    a round detail flipped left to right, only where the patch is uneven enough for the flip to show;
///   paintout  a patch replaced by the picture beside it, with a soft irregular edge;
///   recolour  a region with an edge of its own all round, moved to a colour the picture already uses.
/// Every change must move at least PND_FLOOR_PX pixels by a clear margin, or it is undone and another place is tried.
/// Changes never overlap. The same seed always makes the same changes.
///
/// Public functions (each documented below): pnd_seed_of, pnd_image_create, pnd_image_from_sprite, pnd_image_from_surface,
/// pnd_image_copy, pnd_image_free, pnd_image_to_sprite, pnd_visibility, pnd_ground_class, pnd_add_object, pnd_mirror,
/// pnd_paint_out, pnd_recolour, pnd_make_begin, pnd_make_step, pnd_make_differences, pnd_make_free, pnd_hit.

#macro PND_VERSION "1.0.0"
#macro PND_WORK 640
#macro PND_SHORT 160
#macro PND_LONG 2400
#macro PND_FLOOR_PX 120
#macro PND_FLOOR_DELTA 60
#macro PND_CHANGED 40
#macro PND_STEP 60
#macro PND_SHARE 0.75
#macro PND_BUSY 24
#macro PND_SEP 60
#macro PND_DARK_L 45
#macro PND_DARK_C 25
#macro PND_REPEAT_AFTER 12
#macro PND_HOLD 24
/// The comparison scale used where the MZ edition decides by an exact float comparison: GameMaker applies an epsilon
/// (at least 1e-11 even under math_set_epsilon(0), wing CLAUDE.md s3) to < and >, so a DIFFERENCE is scaled past it first.
#macro PND_EXACT 1000000000000000

// ---------------------------------------------------------------------------------------------------------------
// Unsigned 32-bit arithmetic, the seed hash and the generator (the MZ edition's, exact; from Jigsaw's port)
// ---------------------------------------------------------------------------------------------------------------

/// @function pnd__imul(a, b)
/// @description Internal. JavaScript's Math.imul on unsigned 32-bit values, as int64 halves.
function pnd__imul(_a, _b) {
    var _m = int64($FFFFFFFF);
    _a = int64(_a) & _m; _b = int64(_b) & _m;
    var _lo = (_a * (_b & int64($FFFF))) & _m;
    var _hi = ((_a * (_b >> 16)) & int64($FFFF)) << 16;
    return (_lo + _hi) & _m;
}

/// @function pnd__u32(v)
/// @description Internal. JavaScript's (v >>> 0) for a number: truncated toward zero, then modulo 2^32; not a number -> 0.
function pnd__u32(_v) {
    if (!is_numeric(_v) || is_nan(_v) || is_infinity(_v)) return int64(0);
    return int64(_v) & int64($FFFFFFFF);
}

/// @function pnd__is_number_text(text)
/// @description Internal. True for a string that is a plain decimal number ("7", " 42 ", "-3.5"): such a seed is read as
/// the number. Other strings (hex, exponents, words) are hashed as text.
function pnd__is_number_text(_s) {
    var _t = string_trim(_s), _n = string_length(_t);
    if (_n == 0) return false;
    var _dot = false, _digits = 0;
    for (var _i = 1; _i <= _n; _i++) {
        var _ch = string_char_at(_t, _i);
        if (_ch == "-" && _i == 1) continue;
        if (_ch == "." && !_dot) { _dot = true; continue; }
        if (ord(_ch) < 48 || ord(_ch) > 57) return false;
        _digits++;
    }
    return _digits > 0;
}

/// @function pnd_seed_of(seed)
/// @description The unsigned 32-bit seed from a number or a word: a number (or a string that is a plain decimal number)
/// is used as it is (whole part, sign dropped); any other text is hashed (FNV-1a). Never 0. Pure.
/// @param {Real|String} seed
/// @returns {Real} 1 .. 4294967295
function pnd_seed_of(_s) {
    if (is_numeric(_s) && !is_nan(_s) && !is_infinity(_s)) { var _u = pnd__u32(floor(abs(_s))); return (_u == 0) ? 1 : real(_u); }
    if (is_string(_s) && pnd__is_number_text(_s)) { var _u2 = pnd__u32(floor(abs(real(string_trim(_s))))); return (_u2 == 0) ? 1 : real(_u2); }
    var _t = is_string(_s) ? _s : ((is_undefined(_s)) ? "undefined" : string(_s));
    var _h = int64(2166136261);
    var _n = string_length(_t);
    for (var _i = 1; _i <= _n; _i++) { _h = _h ^ int64(ord(string_char_at(_t, _i)) & $FFFF); _h = pnd__imul(_h, 16777619); }
    return (_h == 0) ? 1 : real(_h);
}

/// @function pnd__rng(seed)
/// @description Internal. The MZ edition's generator (mulberry32) as a struct { a }; draw with pnd__rng_next.
function pnd__rng(_seed) { return { a: pnd__u32(_seed) }; }

/// @function pnd__rng_next(rng)
/// @description Internal. The next draw in [0, 1).
function pnd__rng_next(_r) {
    var _m = int64($FFFFFFFF);
    _r.a = (_r.a + int64($6D2B79F5)) & _m;
    var _t = _r.a;
    _t = pnd__imul(_t ^ (_t >> 15), _t | 1);
    var _x = pnd__imul(_t ^ (_t >> 7), _t | 61);
    _t = _t ^ ((_t + _x) & _m);
    return real((_t ^ (_t >> 14)) & _m) / 4294967296;
}

// ---------------------------------------------------------------------------------------------------------------
// Small exact helpers
// ---------------------------------------------------------------------------------------------------------------

/// @function pnd__ok(v)
/// @description Internal. True for a finite number.
function pnd__ok(_v) { return is_numeric(_v) && !is_nan(_v) && !is_infinity(_v); }

/// @function pnd__img_ok(image)
/// @description Internal. True for a live image struct (w, h and an existing buffer of w x h x 4 bytes).
function pnd__img_ok(_i) {
    if (!is_struct(_i) || !variable_struct_exists(_i, "buf") || !variable_struct_exists(_i, "w") || !variable_struct_exists(_i, "h")) return false;
    if (is_undefined(_i.buf) || !pnd__ok(_i.w) || !pnd__ok(_i.h) || _i.w < 1 || _i.h < 1) return false;
    return buffer_exists(_i.buf) && buffer_get_size(_i.buf) >= _i.w * _i.h * 4;
}

/// @function pnd__round(x)
/// @description Internal. JavaScript's Math.round (halves toward +infinity).
function pnd__round(_x) { return floor(_x + 0.5); }

/// @function pnd__u8(x)
/// @description Internal. What a JavaScript Uint8ClampedArray stores for x: clamped to 0..255, rounded half to EVEN (the
/// MZ edition writes every pixel through one). NaN -> 0.
function pnd__u8(_x) {
    if (is_nan(_x) || _x * PND_EXACT <= 0) return 0;
    if ((_x - 255) * PND_EXACT >= 0) return 255;
    var _f = floor(_x), _d = (_x - _f - 0.5) * PND_EXACT;
    if (_d > 0) return _f + 1;
    if (_d < 0) return _f;
    return ((_f mod 2) == 0) ? _f : _f + 1;
}

/// @function pnd__lum(r, g, b)
/// @description Internal. Luma (Rec. 601), the MZ edition's lumOf.
function pnd__lum(_r, _g, _b) { return 0.299 * _r + 0.587 * _g + 0.114 * _b; }

/// @function pnd__hue(r, g, b)
/// @description Internal. Hue in degrees, 0 for grey (the MZ edition's hueOf; its "% 6" never changes a value here,
/// since (g - b) / c lies in [-1, 1] when red is the maximum).
/// ⛔ The channels are made REAL first. buffer_peek(..., buffer_u8) returns an int32, and on 2024.14.4.268 an int32 divided
/// by an int32 is an INTEGER division: every hue read off the picture came out a multiple of 60 degrees, the recolour's
/// palette took colours of the region's own hue, and only the suite's byte-for-byte puzzle check saw it (MEASURED
/// 2026-10-25, pnd_selftest stage 45: hue of 183,153,104 = 37.2 from literals, 0 from peeked bytes).
function pnd__hue(_r, _g, _b) {
    _r = real(_r); _g = real(_g); _b = real(_b);
    var _mx = max(_r, _g, _b), _mn = min(_r, _g, _b), _c = _mx - _mn, _h;
    if (_c == 0) return 0;
    if (_mx == _r) _h = (_g - _b) / _c; else if (_mx == _g) _h = (_b - _r) / _c + 2; else _h = (_r - _g) / _c + 4;
    _h *= 60;
    return (_h < 0) ? _h + 360 : _h;
}

/// @function pnd__hue_gap(a, b)
/// @description Internal. The shorter way round between two hues (the MZ edition's hueGap).
function pnd__hue_gap(_a, _b) { var _g = abs(_a - _b); return (_g > 180) ? 360 - _g : _g; }

/// @function pnd__clamp01(t)
function pnd__clamp01(_t) { return (_t < 0) ? 0 : ((_t > 1) ? 1 : _t); }

/// @function pnd__pick_contrast(bg, cands)
/// @description Internal. The candidate colour with the most luminance separation from bg (first on a tie).
function pnd__pick_contrast(_bg, _cands) {
    var _lb = pnd__lum(_bg[0], _bg[1], _bg[2]), _best = _cands[0], _bd = -1;
    for (var _i = 0; _i < array_length(_cands); _i++) {
        var _c = _cands[_i], _d = abs(pnd__lum(_c[0], _c[1], _c[2]) - _lb);
        if ((_d - _bd) * PND_EXACT > 0) { _bd = _d; _best = _c; }
    }
    return _best;
}

// ---------------------------------------------------------------------------------------------------------------
// Images: { w, h, buf } where buf holds w * h * 4 bytes, R, G, B, A (the order buffer_get_surface uses, MEASURED on
// 2024.14.4.268 - wing Doctrine_Craft s13)
// ---------------------------------------------------------------------------------------------------------------

/// @function pnd_image_create(w, h)
/// @description A blank (transparent black) image of w x h pixels. Free it with pnd_image_free.
/// @param {Real} w
/// @param {Real} h
/// @returns {Struct} { w, h, buf }
function pnd_image_create(_w, _h) {
    if (!pnd__ok(_w)) _w = 1; if (!pnd__ok(_h)) _h = 1;
    _w = clamp(floor(_w), 1, 8192); _h = clamp(floor(_h), 1, 8192);
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_fill(_b, 0, buffer_u8, 0, _w * _h * 4);
    return { w: _w, h: _h, buf: _b };
}

/// @function pnd_image_free(image)
/// @description Free an image's buffer. Safe on undefined and twice.
function pnd_image_free(_img) {
    if (!is_struct(_img)) return;
    if (variable_struct_exists(_img, "buf") && !is_undefined(_img.buf) && buffer_exists(_img.buf)) buffer_delete(_img.buf);
    _img.buf = undefined;
}

/// @function pnd_image_copy(image)
/// @description A new image with the same pixels.
function pnd_image_copy(_img) {
    if (!pnd__img_ok(_img)) return undefined;
    var _o = pnd_image_create(_img.w, _img.h);
    buffer_copy(_img.buf, 0, _img.w * _img.h * 4, _o.buf, 0);
    return _o;
}

/// @function pnd_work_size(w, h)
/// @description The size the differences are made at for a w x h picture: the long side at PND_WORK (640), but a long thin
/// picture keeps its short side at PND_SHORT (160) or more, and the long side is capped at PND_LONG (2400).
/// @returns {Array<Real>} [w, h]
function pnd_work_size(_pw, _ph) {
    if (!pnd__ok(_pw) || !pnd__ok(_ph) || _pw < 1 || _ph < 1) return [32, 32];
    var _k = min(max(PND_WORK / max(_pw, _ph), PND_SHORT / min(_pw, _ph)), PND_LONG / max(_pw, _ph));
    return [max(32, pnd__round(_pw * _k)), max(32, pnd__round(_ph * _k))];
}

/// @function pnd__surface_to_image(surface, w, h)
/// @description Internal. Read a w x h surface into a new image (the buffer holds the WHOLE surface: wing Doctrine_Craft s13).
function pnd__surface_to_image(_sf, _w, _h) {
    var _img = pnd_image_create(_w, _h);
    buffer_get_surface(_img.buf, _sf, 0);
    return _img;
}

/// @function pnd__draw_scaled(draw_fn, w, h, tw, th)
/// @description Internal. Draw a picture at tw x th into a new surface: halving steps (each a 2 x 2 box average, since a
/// bilinear sample at the exact centre of four texels averages them) while it is more than twice the target, then one
/// bilinear stretch. draw_fn(x, y, w, h) draws the source. Returns the surface (the caller frees it).
function pnd__draw_scaled(_draw, _w, _h, _tw, _th) {
    // under IDENTITY, handing the caller's world matrix back: a read made under a buyer's 2x matrix drew the picture at 2x
    // into its own surface (the suite's "called under a transform" arm, wing Doctrine_Craft s19)
    var _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_build_identity());
    var _cur = surface_create(_w, _h);
    gpu_push_state();
    gpu_set_blendenable(false);
    gpu_set_texfilter(false);
    surface_set_target(_cur); draw_clear_alpha(c_black, 0); _draw(0, 0, _w, _h); surface_reset_target();
    gpu_set_texfilter(true);
    var _cw = _w, _ch = _h;
    while (_cw > _tw * 2 && _ch > _th * 2) {
        var _nw = max(_tw, floor(_cw / 2)), _nh = max(_th, floor(_ch / 2));
        var _nx = surface_create(_nw, _nh);
        surface_set_target(_nx); draw_clear_alpha(c_black, 0); draw_surface_stretched(_cur, 0, 0, _nw, _nh); surface_reset_target();
        surface_free(_cur); _cur = _nx; _cw = _nw; _ch = _nh;
    }
    if (_cw != _tw || _ch != _th) {
        var _fin = surface_create(_tw, _th);
        surface_set_target(_fin); draw_clear_alpha(c_black, 0); draw_surface_stretched(_cur, 0, 0, _tw, _th); surface_reset_target();
        surface_free(_cur); _cur = _fin;
    }
    gpu_pop_state();
    matrix_set(matrix_world, _mw);
    return _cur;
}

/// @function pnd_image_from_sprite(sprite, [subimg])
/// @description The picture a puzzle is made from: a frame of any sprite, at its WORK size (pnd_work_size). A sprite that
/// is already that size is copied byte for byte. Call outside a Draw event (it draws into its own surfaces).
/// @param {Asset.GMSprite} sprite
/// @param {Real} [subimg] 0 by default
/// @returns {Struct|Undefined} an image, or undefined when the sprite does not exist
function pnd_image_from_sprite(_spr, _sub = 0) {
    var _ok = false;
    try { _ok = sprite_exists(_spr); } catch (_e) { _ok = false; }
    if (!_ok) return undefined;
    var _pw = sprite_get_width(_spr), _ph = sprite_get_height(_spr);
    if (_pw < 1 || _ph < 1) return undefined;
    var _ws = pnd_work_size(_pw, _ph);
    var _xo = sprite_get_xoffset(_spr), _yo = sprite_get_yoffset(_spr);
    var _sf = pnd__draw_scaled(method({ s: _spr, i: _sub, xo: _xo, yo: _yo, pw: _pw, ph: _ph }, function(_x, _y, _w, _h) {
        draw_sprite_ext(s, i, _x + xo * (_w / pw), _y + yo * (_h / ph), _w / pw, _h / ph, 0, c_white, 1);
    }), _pw, _ph, _ws[0], _ws[1]);
    var _img = pnd__surface_to_image(_sf, _ws[0], _ws[1]);
    surface_free(_sf);
    return _img;
}

/// @function pnd_image_from_surface(surface)
/// @description As pnd_image_from_sprite, from a surface (a capture of the room, a rendered portrait). The surface is
/// copied; you may free it afterwards. Call outside a Draw event.
/// @returns {Struct|Undefined} an image, or undefined when the surface does not exist
function pnd_image_from_surface(_src) {
    var _ok = false;
    try { _ok = surface_exists(_src); } catch (_e) { _ok = false; }
    if (!_ok) return undefined;
    var _pw = surface_get_width(_src), _ph = surface_get_height(_src);
    var _ws = pnd_work_size(_pw, _ph);
    var _sf = pnd__draw_scaled(method({ s: _src }, function(_x, _y, _w, _h) { draw_surface_stretched(s, _x, _y, _w, _h); }), _pw, _ph, _ws[0], _ws[1]);
    var _img = pnd__surface_to_image(_sf, _ws[0], _ws[1]);
    surface_free(_sf);
    return _img;
}

/// @function pnd_image_to_sprite(image)
/// @description A new sprite of the image (free it with sprite_delete in Step or Clean Up, never right after drawing it:
/// wing Doctrine_Craft s10). Call outside a Draw event.
/// @returns {Asset.GMSprite}
function pnd_image_to_sprite(_img) {
    if (!pnd__img_ok(_img)) return -1;
    var _sf = surface_create(_img.w, _img.h);
    buffer_set_surface(_img.buf, _sf, 0);
    var _spr = sprite_create_from_surface(_sf, 0, 0, _img.w, _img.h, false, false, 0, 0);
    surface_free(_sf);
    return _spr;
}

// ---------------------------------------------------------------------------------------------------------------
// The four changes (each the MZ edition's function of the same name)
// ---------------------------------------------------------------------------------------------------------------

/// @function pnd_visibility(a, b, cx, cy, r)
/// @description How visibly image b differs from image a in the square of half-size r around (cx, cy): how many pixels
/// changed by more than PND_CHANGED (the sum of the three channel differences) and their mean change. Pure.
/// @returns {Struct} { px, meanDelta }
function pnd_visibility(_a, _b, _cx, _cy, _r) {
    if (!pnd__img_ok(_a) || !pnd__img_ok(_b) || _a.w != _b.w || _a.h != _b.h || !pnd__ok(_cx) || !pnd__ok(_cy) || !pnd__ok(_r)) return { px: 0, meanDelta: 0 };
    var _W = _a.w, _H = _a.h, _n = 0, _sum = 0, _ba = _a.buf, _bb = _b.buf;
    var _x0 = max(0, pnd__round(_cx - _r)), _x1 = min(_W, pnd__round(_cx + _r)), _y0 = max(0, pnd__round(_cy - _r)), _y1 = min(_H, pnd__round(_cy + _r));
    for (var _y = _y0; _y < _y1; _y++) {
        var _i = (_y * _W + _x0) * 4;
        for (var _x = _x0; _x < _x1; _x++) {
            var _d = abs(buffer_peek(_ba, _i, buffer_u8) - buffer_peek(_bb, _i, buffer_u8)) + abs(buffer_peek(_ba, _i + 1, buffer_u8) - buffer_peek(_bb, _i + 1, buffer_u8)) + abs(buffer_peek(_ba, _i + 2, buffer_u8) - buffer_peek(_bb, _i + 2, buffer_u8));
            if (_d > PND_CHANGED) { _n++; _sum += _d; }
            _i += 4;
        }
    }
    return { px: _n, meanDelta: (_n > 0) ? pnd__round(_sum / _n) : 0 };
}

/// @function pnd__phase(cx, cy)
/// @description Internal. A fixed phase from a centre (the MZ edition's phaseOf), so a place always gets the same outline.
function pnd__phase(_cx, _cy) {
    var _m = int64($FFFFFFFF);
    var _h = (int64(_cx * 73856093) & _m) ^ (int64(_cy * 19349663) & _m);
    return real(_h mod 6283) / 1000;
}

/// @function pnd__edge_weight(x, y, r, ph)
/// @description Internal. How much of a change shows at offset (x, y): 1 in the core, easing to 0 across a rim whose reach
/// wobbles with the angle (72-100% of r), so an edit has no hard round seam. Never above 0 at or beyond r.
function pnd__edge_weight(_x, _y, _r, _ph) {
    var _dist = sqrt(_x * _x + _y * _y);
    if ((_dist - _r) * PND_EXACT >= 0) return 0;
    var _th = arctan2(_y, _x), _reach = _r * (0.86 + 0.08 * sin(3 * _th + _ph) + 0.06 * sin(2 * _th + _ph * 1.7));
    var _t = (_reach - _dist) / max(3, _r * 0.2);
    if (_t * PND_EXACT <= 0) return 0;
    if ((_t - 1) * PND_EXACT >= 0) return 1;
    return _t * _t * (3 - 2 * _t);
}

/// @function pnd__band(img, y0, y1)
/// @description Internal. A copy of whole rows y0..y1 (inclusive): the "before" pixels a mirror or a paint-out reads.
function pnd__band(_img, _y0, _y1) {
    var _n = (_y1 - _y0 + 1) * _img.w * 4, _b = buffer_create(_n, buffer_fixed, 1);
    buffer_copy(_img.buf, _y0 * _img.w * 4, _n, _b, 0);
    return _b;
}

/// @function pnd__blend_from(img, i, snap, j, w)
/// @description Internal. Blend pixel j of a snapshot into pixel i of the image by weight w (each channel stored as a
/// Uint8ClampedArray would store it).
function pnd__blend_from(_img, _i, _snap, _j, _w) {
    var _b = _img.buf;
    for (var _c = 0; _c < 3; _c++) {
        var _d = buffer_peek(_b, _i + _c, buffer_u8);
        buffer_poke(_b, _i + _c, buffer_u8, pnd__u8(_d + (buffer_peek(_snap, _j + _c, buffer_u8) - _d) * _w));
    }
}

/// @function pnd_mirror(image, cx, cy, r, [min_asym])
/// @description Mirror the round patch at (cx, cy) left to right, only if it is uneven enough to show (mean channel
/// difference against its own mirror at least min_asym of full scale, 0.08 by default). Changes the image in place.
/// @returns {Struct|Undefined} { x, y, r, asym }, or undefined (image untouched) when refused
function pnd_mirror(_img, _cx, _cy, _r, _min_asym = 0.08) {
    if (!pnd__img_ok(_img) || !pnd__ok(_cx) || !pnd__ok(_cy) || !pnd__ok(_r) || _r < 1 || !pnd__ok(_min_asym)) return undefined;
    _r = floor(_r);
    var _W = _img.w, _H = _img.h, _b = _img.buf;
    _cx = pnd__round(_cx); _cy = pnd__round(_cy);
    if (_cx - _r < 0 || _cy - _r < 0 || _cx + _r >= _W || _cy + _r >= _H) return undefined;
    var _diff = 0, _n = 0;
    for (var _y = -_r; _y <= _r; _y++) for (var _x = -_r; _x <= _r; _x++) {
        if (_x * _x + _y * _y > _r * _r) continue;
        var _i = ((_cy + _y) * _W + _cx + _x) * 4, _j = ((_cy + _y) * _W + _cx - _x) * 4;
        _diff += abs(buffer_peek(_b, _i, buffer_u8) - buffer_peek(_b, _j, buffer_u8)) + abs(buffer_peek(_b, _i + 1, buffer_u8) - buffer_peek(_b, _j + 1, buffer_u8)) + abs(buffer_peek(_b, _i + 2, buffer_u8) - buffer_peek(_b, _j + 2, buffer_u8));
        _n++;
    }
    var _asym = (_n > 0) ? _diff / _n / 765 : 0;
    if ((_asym - _min_asym) * PND_EXACT < 0) return undefined;
    var _snap = pnd__band(_img, _cy - _r, _cy + _r), _ph = pnd__phase(_cx, _cy);
    for (var _y2 = -_r; _y2 <= _r; _y2++) for (var _x2 = -_r; _x2 <= _r; _x2++) {
        var _w = pnd__edge_weight(_x2, _y2, _r, _ph);
        if (_w <= 0) continue;
        pnd__blend_from(_img, ((_cy + _y2) * _W + _cx + _x2) * 4, _snap, ((_y2 + _r) * _W + _cx - _x2) * 4, _w);
    }
    buffer_delete(_snap);
    return { x: _cx, y: _cy, r: _r, asym: pnd__round(_asym * 1000) / 1000 };
}

/// @function pnd_paint_out(image, cx, cy, r, dx)
/// @description Paint out the round patch at (cx, cy) with the picture dx pixels across, through a soft irregular edge.
/// Changes the image in place.
/// @returns {Struct|Undefined} { x, y, r, dx }, or undefined when the patch or its source would leave the picture
function pnd_paint_out(_img, _cx, _cy, _r, _dx) {
    if (!pnd__img_ok(_img) || !pnd__ok(_cx) || !pnd__ok(_cy) || !pnd__ok(_r) || _r < 1 || !pnd__ok(_dx)) return undefined;
    _r = floor(_r);
    var _W = _img.w, _H = _img.h;
    _cx = pnd__round(_cx); _cy = pnd__round(_cy); _dx = pnd__round(_dx);
    if (_cx - _r < 0 || _cy - _r < 0 || _cx + _r >= _W || _cy + _r >= _H || _cx + _dx - _r < 0 || _cx + _dx + _r >= _W) return undefined;
    var _snap = pnd__band(_img, _cy - _r, _cy + _r), _ph = pnd__phase(_cx, _cy);
    for (var _y = -_r; _y <= _r; _y++) for (var _x = -_r; _x <= _r; _x++) {
        var _w = pnd__edge_weight(_x, _y, _r, _ph);
        if (_w <= 0) continue;
        pnd__blend_from(_img, ((_cy + _y) * _W + _cx + _x) * 4, _snap, ((_y + _r) * _W + _cx + _dx + _x) * 4, _w);
    }
    buffer_delete(_snap);
    return { x: _cx, y: _cy, r: _r, dx: _dx };
}

/// @function pnd_recolour(image, sx, sy, [options])
/// @description Recolour the region around (sx, sy) - flood-filled by colour similarity inside a radius - to a colour
/// the picture already uses at a similar lightness. Refuses (undefined, image untouched) a region that is too small or
/// too large, one cut out of a field by the radius, one without an edge of its own all round (a band of sky, a shadow),
/// and a dark colourless one. Options: { radius 40, minArea 300, maxArea 6000, tol 36, pick 0..1, share 0.75 }.
/// @returns {Struct|Undefined} { x, y, r, area, to, edge, share }
function pnd_recolour(_img, _sx, _sy, _o = {}) {
    if (!pnd__img_ok(_img) || !pnd__ok(_sx) || !pnd__ok(_sy)) return undefined;
    if (!is_struct(_o)) _o = {};
    var _W = _img.w, _H = _img.h, _b = _img.buf;
    var _tol = (variable_struct_exists(_o, "tol") && _o.tol) ? _o.tol : 36;
    var _rad = (variable_struct_exists(_o, "radius") && _o.radius) ? _o.radius : 40;
    var _minA = (variable_struct_exists(_o, "minArea") && _o.minArea) ? _o.minArea : 300;
    var _maxA = (variable_struct_exists(_o, "maxArea") && _o.maxArea) ? _o.maxArea : 6000;
    var _rimMax = variable_struct_exists(_o, "rimMax") ? _o.rimMax : 0.2;
    var _shareMin = variable_struct_exists(_o, "share") ? _o.share : PND_SHARE;
    var _darkL = variable_struct_exists(_o, "darkL") ? _o.darkL : PND_DARK_L;
    _sx = pnd__round(_sx); _sy = pnd__round(_sy);
    if (_sx < 0 || _sy < 0 || _sx >= _W || _sy >= _H) return undefined;
    var _i0 = (_sy * _W + _sx) * 4, _r0 = buffer_peek(_b, _i0, buffer_u8), _g0 = buffer_peek(_b, _i0 + 1, buffer_u8), _b0 = buffer_peek(_b, _i0 + 2, buffer_u8);
    // the flood stays within rad (+1 for the neighbours of its edge) of the seed, so "seen" and "in region" are a local window
    var _half = _rad + 1, _side = _half * 2 + 1, _seen = array_create(_side * _side, 0);
    var _stack = [_sy * _W + _sx], _region = [];
    while (array_length(_stack) > 0) {
        var _p = array_pop(_stack);
        var _px = _p mod _W, _py = (_p - _px) div _W, _li = (_py - _sy + _half) * _side + (_px - _sx + _half);
        if (_seen[_li]) continue;
        _seen[_li] = 1;
        var _i = _p * 4;
        if (abs(buffer_peek(_b, _i, buffer_u8) - _r0) + abs(buffer_peek(_b, _i + 1, buffer_u8) - _g0) + abs(buffer_peek(_b, _i + 2, buffer_u8) - _b0) > _tol) continue;
        if ((_px - _sx) * (_px - _sx) + (_py - _sy) * (_py - _sy) > _rad * _rad) continue;
        array_push(_region, _p);
        if (array_length(_region) > _maxA) return undefined;
        if (_px > 0) array_push(_stack, _p - 1);
        if (_px < _W - 1) array_push(_stack, _p + 1);
        if (_py > 0) array_push(_stack, _p - _W);
        if (_py < _H - 1) array_push(_stack, _p + _W);
    }
    var _n = array_length(_region);
    if (_n < _minA) return undefined;
    // NOT A DISC: a region much of whose edge is the radius was cut out of a field (MZ edition, 2026-10-04)
    var _rim = 0, _sr = 0, _sg = 0, _sb = 0, _sxx = 0, _syy = 0, _inner = (_rad - 1.5) * (_rad - 1.5);
    var _inR = array_create(_side * _side, 0);
    for (var _k = 0; _k < _n; _k++) {
        var _q = _region[_k], _qx = _q mod _W, _qy = (_q - _qx) div _W, _j = _q * 4;
        if ((_qx - _sx) * (_qx - _sx) + (_qy - _sy) * (_qy - _sy) > _inner) _rim++;
        _sr += buffer_peek(_b, _j, buffer_u8); _sg += buffer_peek(_b, _j + 1, buffer_u8); _sb += buffer_peek(_b, _j + 2, buffer_u8); _sxx += _qx; _syy += _qy;
        _inR[(_qy - _sy + _half) * _side + (_qx - _sx + _half)] = 1;
    }
    if (_rim > 2 * pi * _rad * _rimMax) return undefined;
    // an OBJECT has an edge all round: the share of boundary steps with real contrast 3 px out
    var _cs = 0, _cn = 0, _strong = 0;
    for (var _k2 = 0; _k2 < _n; _k2++) {
        var _q2 = _region[_k2], _qx2 = _q2 mod _W, _qy2 = (_q2 - _qx2) div _W;
        for (var _e = 0; _e < 4; _e++) {
            var _ex = (_e == 0) ? 1 : ((_e == 1) ? -1 : 0), _ey = (_e == 2) ? 1 : ((_e == 3) ? -1 : 0);
            var _nx = _qx2 + _ex, _ny = _qy2 + _ey;
            if (_nx < 0 || _ny < 0 || _nx >= _W || _ny >= _H) continue;
            var _ln = (_ny - _sy + _half) * _side + (_nx - _sx + _half);
            if (_ln >= 0 && _ln < _side * _side && abs(_nx - _sx) <= _half && abs(_ny - _sy) <= _half && _inR[_ln]) continue;
            var _fx = _qx2 + _ex * 3, _fy = _qy2 + _ey * 3;
            if (_fx < 0 || _fy < 0 || _fx >= _W || _fy >= _H) continue;
            var _f = (_fy * _W + _fx) * 4, _cd = abs(buffer_peek(_b, _f, buffer_u8) - _r0) + abs(buffer_peek(_b, _f + 1, buffer_u8) - _g0) + abs(buffer_peek(_b, _f + 2, buffer_u8) - _b0);
            _cs += _cd; _cn++; if (_cd >= PND_STEP) _strong++;
        }
    }
    var _edge = (_cn > 0) ? pnd__round(_cs / _cn) : 0, _share = (_cn > 0) ? pnd__round(_strong / _cn * 100) / 100 : 0;
    if ((_share - _shareMin) * PND_EXACT < 0) return undefined;
    var _ccx = _sxx / _n, _ccy = _syy / _n, _reach2 = 0;
    for (var _k3 = 0; _k3 < _n; _k3++) { var _q3 = _region[_k3], _qx3 = _q3 mod _W, _qy3 = (_q3 - _qx3) div _W; _reach2 = max(_reach2, (_qx3 - _ccx) * (_qx3 - _ccx) + (_qy3 - _ccy) * (_qy3 - _ccy)); }
    var _mr = _sr / _n, _mg = _sg / _n, _mb = _sb / _n, _mh = pnd__hue(_mr, _mg, _mb), _ml = pnd__lum(_mr, _mg, _mb);
    // a DARK, COLOURLESS region has no colour to change (MZ edition, MEASURED 2026-10-04)
    if ((_ml - _darkL) * PND_EXACT < 0 && (max(_mr, _mg, _mb) - min(_mr, _mg, _mb) - PND_DARK_C) * PND_EXACT < 0) return undefined;
    // the new colour is one the PICTURE already uses: another hue at a similar lightness
    var _pal = [];
    for (var _y = 3; _y < _H; _y += 7) for (var _x = 3; _x < _W; _x += 7) {
        var _t = (_y * _W + _x) * 4, _tr = buffer_peek(_b, _t, buffer_u8), _tg = buffer_peek(_b, _t + 1, buffer_u8), _tb = buffer_peek(_b, _t + 2, buffer_u8);
        if (max(_tr, _tg, _tb) - min(_tr, _tg, _tb) < 40) continue;
        if ((pnd__hue_gap(pnd__hue(_tr, _tg, _tb), _mh) - 60) * PND_EXACT < 0) continue;
        if ((abs(pnd__lum(_tr, _tg, _tb) - _ml) - 60) * PND_EXACT > 0) continue;
        array_push(_pal, _t);
    }
    if (array_length(_pal) == 0) return undefined;
    var _pick = variable_struct_exists(_o, "pick") ? _o.pick : 0.5;
    if (!is_numeric(_pick) || !(_pick >= 0 && _pick < 1)) _pick = 0.5;
    var _to = _pal[floor(_pick * array_length(_pal))];
    // diagnostics for the suite only: when global.pnd__trace is an array, every accepted recolour records its palette
    if (variable_global_exists("pnd__trace") && is_array(global.pnd__trace)) array_push(global.pnd__trace, { n: _n, mr: _mr, mg: _mg, mb: _mb, mh: _mh, ml: _ml, pick: _pick, pal: _pal });
    var _tR = buffer_peek(_b, _to, buffer_u8), _tG = buffer_peek(_b, _to + 1, buffer_u8), _tB = buffer_peek(_b, _to + 2, buffer_u8);
    var _dr = _tR - _mr, _dg = _tG - _mg, _db = _tB - _mb;
    for (var _k4 = 0; _k4 < _n; _k4++) {
        var _j4 = _region[_k4] * 4;
        buffer_poke(_b, _j4, buffer_u8, pnd__u8(buffer_peek(_b, _j4, buffer_u8) + _dr));
        buffer_poke(_b, _j4 + 1, buffer_u8, pnd__u8(buffer_peek(_b, _j4 + 1, buffer_u8) + _dg));
        buffer_poke(_b, _j4 + 2, buffer_u8, pnd__u8(buffer_peek(_b, _j4 + 2, buffer_u8) + _db));
    }
    return { x: pnd__round(_ccx), y: pnd__round(_ccy), r: ceil(sqrt(_reach2)) + 1, area: _n, to: [_tR, _tG, _tB], edge: _edge, share: _share };
}

/// @function pnd_ground_class(image, cx, cy, r)
/// @description What kind of ground the round patch at (cx, cy) is: "night", "dark", "sky", "stone", "water", "field" or
/// "earth", from its mean colour and its height in the picture (the MZ edition's groundClass). An added object must
/// belong to the ground it lands on. Pure.
/// @returns {String}
function pnd_ground_class(_img, _cx, _cy, _r) {
    if (!pnd__img_ok(_img) || !pnd__ok(_cx) || !pnd__ok(_cy) || !pnd__ok(_r) || _r < 0) return undefined;
    _r = min(floor(_r), 4096);
    var _W = _img.w, _H = _img.h, _b = _img.buf, _n = 0, _sr = 0, _sg = 0, _sb = 0;
    for (var _y = -_r; _y <= _r; _y += 2) for (var _x = -_r; _x <= _r; _x += 2) {
        if (_x * _x + _y * _y > _r * _r) continue;
        var _px = pnd__round(_cx + _x), _py = pnd__round(_cy + _y);
        if (_px < 0 || _py < 0 || _px >= _W || _py >= _H) continue;
        var _i = (_py * _W + _px) * 4;
        _sr += buffer_peek(_b, _i, buffer_u8); _sg += buffer_peek(_b, _i + 1, buffer_u8); _sb += buffer_peek(_b, _i + 2, buffer_u8); _n++;
    }
    if (_n == 0) return "earth";
    var _mr = _sr / _n, _mg = _sg / _n, _mb = _sb / _n, _l = pnd__lum(_mr, _mg, _mb), _ch = max(_mr, _mg, _mb) - min(_mr, _mg, _mb), _h = pnd__hue(_mr, _mg, _mb), _up = _cy / _H;
    if (_l < 70) return (_up < 0.35 && _mb >= _mr) ? "night" : "dark";
    if (_ch < 25) return (_up < 0.45 && _l > 150) ? "sky" : "stone";
    if ((_h >= 165 && _h <= 260) || (_h >= 65 && _l > 200)) return (_up >= 0.5) ? "water" : ((_l > 110) ? "sky" : "stone");
    if (_h >= 65 && _h < 165) return "field";
    return (_up < 0.35 && _l > 140) ? "sky" : "earth";
}

/// @function pnd__corpus_list(which)
/// @description Internal. The objects a puzzle draws from: "mz12" (the MZ edition's twelve, for the held-to-the-original
/// checks) or every object (default).
function pnd__corpus_list(_which) {
    var _c = __pnd_corpus();
    if (_which == "mz12") return array_create_ext(12, method({ c: _c }, function(_i) { return c[_i]; }));
    return _c;
}

/// @function pnd__object_entry(which, corpus)
/// @description Internal. A corpus entry from an index or an id; undefined when there is none.
function pnd__object_entry(_which, _corpus) {
    if (is_string(_which)) { for (var _i = 0; _i < array_length(_corpus); _i++) if (_corpus[_i].id == _which) return _corpus[_i]; return undefined; }
    if (!is_numeric(_which) || is_nan(_which) || is_infinity(_which)) return undefined;
    var _n = array_length(_corpus), _k = ((floor(_which) mod _n) + _n) mod _n;
    return _corpus[_k];
}

/// @function pnd_add_object(image, cx, cy, r, which, [options])
/// @description Draw object `which` (an index or an id from pnd_object_ids()) into the round patch at (cx, cy), radius r.
/// Refuses (undefined, image untouched) when the ground is too busy for an object to read on or no body colour separates
/// from it. Options: { flip (bool), tilt (radians), maxBusy 24, minSep 60, corpus "all" | "mz12" }.
/// @returns {Struct|Undefined} { x, y, r, object, body, ground, busy }
function pnd_add_object(_img, _cx, _cy, _r, _which, _o = {}) {
    if (!is_struct(_o)) _o = {};
    if (!pnd__img_ok(_img) || !pnd__ok(_cx) || !pnd__ok(_cy) || !pnd__ok(_r) || _r < 2) return undefined;
    var _corpus = pnd__corpus_list(variable_struct_exists(_o, "corpus") ? _o.corpus : "all");
    var _ob = pnd__object_entry(_which, _corpus);
    if (is_undefined(_ob)) return undefined;
    var _W = _img.w, _H = _img.h, _b = _img.buf;
    _cx = pnd__round(_cx); _cy = pnd__round(_cy); _r = pnd__round(_r);
    if (_cx - _r < 0 || _cy - _r < 0 || _cx + _r >= _W || _cy + _r >= _H) return undefined;
    // the ground: its mean colour and how busy it is (luminance spread)
    var _n = 0, _sr = 0, _sg = 0, _sb = 0, _sl = 0, _sll = 0;
    for (var _y = -_r; _y <= _r; _y++) for (var _x = -_r; _x <= _r; _x++) {
        if (_x * _x + _y * _y > _r * _r) continue;
        var _i = ((_cy + _y) * _W + _cx + _x) * 4, _cr = buffer_peek(_b, _i, buffer_u8), _cg = buffer_peek(_b, _i + 1, buffer_u8), _cb = buffer_peek(_b, _i + 2, buffer_u8), _l = pnd__lum(_cr, _cg, _cb);
        _sr += _cr; _sg += _cg; _sb += _cb; _sl += _l; _sll += _l * _l; _n++;
    }
    var _gm = [_sr / _n, _sg / _n, _sb / _n], _lm = _sl / _n, _busy = sqrt(max(0, _sll / _n - _lm * _lm));
    var _maxBusy = variable_struct_exists(_o, "maxBusy") ? _o.maxBusy : PND_BUSY;
    if ((_busy - _maxBusy) * PND_EXACT > 0) return undefined;
    var _cands = _ob.body;
    var _body = pnd__pick_contrast(_gm, _cands), _minSep = variable_struct_exists(_o, "minSep") ? _o.minSep : PND_SEP;
    var _bestSep = abs(pnd__lum(_body[0], _body[1], _body[2]) - _lm);
    if ((_bestSep - _minSep) * PND_EXACT < 0) return undefined;
    var _gh = pnd__hue(_gm[0], _gm[1], _gm[2]), _gc = max(_gm[0], _gm[1], _gm[2]) - min(_gm[0], _gm[1], _gm[2]), _bestGap = -1;
    for (var _k = 0; _k < array_length(_cands); _k++) {
        var _c = _cands[_k], _csep = abs(pnd__lum(_c[0], _c[1], _c[2]) - _lm);
        if ((_csep - _minSep) * PND_EXACT < 0 || (_csep - _bestSep * 0.8) * PND_EXACT < 0) continue;
        var _cgap;
        if (_gc < 25) _cgap = array_length(_cands) - _k;
        else if (max(_c[0], _c[1], _c[2]) - min(_c[0], _c[1], _c[2]) < 40) _cgap = 0;
        else _cgap = pnd__hue_gap(pnd__hue(_c[0], _c[1], _c[2]), _gh);
        if ((_cgap - _bestGap) * PND_EXACT > 0) { _bestGap = _cgap; _body = _c; }
    }
    var _R = __pnd_role_colours();
    var _col = {
        body: _body, edge: [_body[0] * 0.36, _body[1] * 0.36, _body[2] * 0.36],
        ink: pnd__pick_contrast(_body, _R.ink), metal: pnd__pick_contrast(_gm, _R.metal), stem: pnd__pick_contrast(_gm, _R.stem),
        leaf: pnd__pick_contrast(_gm, _R.leaf), gold: pnd__pick_contrast(_body, _R.gold), cream: pnd__pick_contrast(_body, _R.cream),
        skin: pnd__pick_contrast(_gm, _R.skin), flame: pnd__pick_contrast(_gm, _R.flame), gem: pnd__pick_contrast(_body, _R.gem),
        glint: _R.glint[0], wing: _R.wing[0], eye: _R.eye[0], pupil: _R.pupil[0]
    };
    _col.inkc = pnd__pick_contrast(_col.cream, _R.inkc);
    var _s = _r / 1.2, _flip = (variable_struct_exists(_o, "flip") && _o.flip) ? -1 : 1, _tilt = variable_struct_exists(_o, "tilt") ? _o.tilt : 0;
    var _ct = cos(_tilt), _st = sin(_tilt), _pen = max(0.9, _s * 0.07);
    var _fn = _ob.fn, _nl = array_length(_ob.roles), _rc = array_create(_nl), _ow = array_create(_nl);
    for (var _q = 0; _q < _nl; _q++) { _rc[_q] = variable_struct_get(_col, _ob.roles[_q]); _ow[_q] = (_ob.pens[_q] != 0) ? _pen * _ob.pens[_q] : 0; }
    var _ek = _col.edge;
    for (var _y2 = -_r; _y2 <= _r; _y2++) for (var _x2 = -_r; _x2 <= _r; _x2++) {
        var _ii = ((_cy + _y2) * _W + _cx + _x2) * 4;
        // the pixel's channels held as the Uint8ClampedArray would hold them, written back once at the end
        var _pr = buffer_peek(_b, _ii, buffer_u8), _pg = buffer_peek(_b, _ii + 1, buffer_u8), _pb = buffer_peek(_b, _ii + 2, buffer_u8);
        var _grain = max(-12, min(12, (pnd__lum(_pr, _pg, _pb) - _lm) * 0.33));
        var _px = _x2 / _s, _py = _y2 / _s, _u = (_px * _ct + _py * _st) * _flip, _v = -_px * _st + _py * _ct;
        var _su = ((_x2 - _s * 0.08) / _s * _ct + (_y2 - _s * 0.1) / _s * _st) * _flip, _sv = -(_x2 - _s * 0.08) / _s * _st + (_y2 - _s * 0.1) / _s * _ct, _sd = 9;
        for (var _k2 = 0; _k2 < _nl; _k2++) _sd = min(_sd, _fn(_k2, _su, _sv));
        var _sa = 0.32 * pnd__clamp01(0.5 - _sd * _s / 2.5);
        var _dirty = false;
        if (_sa > 0) { _pr = pnd__u8(_pr * (1 - _sa)); _pg = pnd__u8(_pg * (1 - _sa)); _pb = pnd__u8(_pb * (1 - _sa)); _dirty = true; }
        var _shade = max(0.78, min(1.22, 1 - 0.2 * (_u * 0.55 + _v * 0.75)));
        for (var _k3 = 0; _k3 < _nl; _k3++) {
            var _dd = _fn(_k3, _u, _v) * _s, _cc = _rc[_k3], _w = _ow[_k3];
            var _co = pnd__clamp01(0.5 - _dd), _cf = pnd__clamp01(0.5 - (_dd + _w));
            if (_co <= 0) continue;
            if (_w > 0) { var _oa = _co * 0.9; _pr = pnd__u8(_pr + (_ek[0] - _pr) * _oa); _pg = pnd__u8(_pg + (_ek[1] - _pg) * _oa); _pb = pnd__u8(_pb + (_ek[2] - _pb) * _oa); }
            if (_cf > 0) { _pr = pnd__u8(_pr + (_cc[0] * _shade + _grain - _pr) * _cf); _pg = pnd__u8(_pg + (_cc[1] * _shade + _grain - _pg) * _cf); _pb = pnd__u8(_pb + (_cc[2] * _shade + _grain - _pb) * _cf); }
            _dirty = true;
        }
        if (_dirty) { buffer_poke(_b, _ii, buffer_u8, _pr); buffer_poke(_b, _ii + 1, buffer_u8, _pg); buffer_poke(_b, _ii + 2, buffer_u8, _pb); }
    }
    return { x: _cx, y: _cy, r: _r, object: _ob.id, body: _body, ground: [pnd__round(_gm[0]), pnd__round(_gm[1]), pnd__round(_gm[2])], busy: pnd__round(_busy) };
}

/// @function pnd__restore(dst, src, cx, cy, r)
/// @description Internal. Copy the square of half-size r around (cx, cy) back from src (undo a refused change).
function pnd__restore(_dst, _src, _cx, _cy, _r) {
    var _W = _src.w, _H = _src.h, _x0 = max(0, _cx - _r), _x1 = min(_W, _cx + _r + 1);
    if (_x1 <= _x0) return;
    for (var _y = max(0, _cy - _r); _y < min(_H, _cy + _r + 1); _y++) buffer_copy(_src.buf, (_y * _W + _x0) * 4, (_x1 - _x0) * 4, _dst.buf, (_y * _W + _x0) * 4);
}

// ---------------------------------------------------------------------------------------------------------------
// Making the differences: a resumable job, so a game can make them a few milliseconds per frame
// ---------------------------------------------------------------------------------------------------------------

/// @function pnd__kind_index(name)
function pnd__kind_index(_k) { switch (_k) { case "paintout": return 0; case "mirror": return 1; case "recolour": return 2; case "add": return 3; } return -1; }

/// @function pnd_make_begin(image, [options])
/// @description Start making the second picture from `image` (never changed). Options: { count 1..12 (5), seed (a number
/// or a word; "pendant" when absent), kinds (array of "add", "recolour", "mirror", "paintout"; all four when absent or
/// none recognised), corpus ("all" or "mz12") }. Advance it with pnd_make_step until it returns true, then read
/// job.changes and job.out; free it with pnd_make_free (job.out too, unless you keep it).
/// @returns {Struct} the job
function pnd_make_begin(_img, _o = {}) {
    if (!is_struct(_o)) _o = {};
    if (!pnd__img_ok(_img)) return { src: _img, out: undefined, changes: [], done: true, steps: 0, worst_us: 0, total_us: 0, places_tried: 0, cand: [], want: 0, refused_input: true };
    var _J = { src: _img, out: pnd_image_copy(_img), changes: [], done: false, steps: 0, worst_us: 0, total_us: 0, places_tried: 0 };
    var _W = _img.w, _H = _img.h;
    var _want = variable_struct_exists(_o, "count") ? _o.count : 5;
    if (!is_numeric(_want) || is_nan(_want) || is_infinity(_want)) _want = 5;
    _J.want = max(1, min(12, pnd__round(_want)));
    _J.seed = variable_struct_exists(_o, "seed") ? _o.seed : "pendant";
    _J.rng = pnd__rng(pnd_seed_of(_J.seed));
    _J.corpus = pnd__corpus_list(variable_struct_exists(_o, "corpus") ? _o.corpus : "all");
    if (_W < 32 || _H < 32) { _J.done = true; _J.cand = []; return _J; }
    var _G = 16, _cand = [];
    for (var _y = _G * 2; _y < _H - _G * 2; _y += _G) for (var _x = _G * 2; _x < _W - _G * 2; _x += _G) array_push(_cand, [_x + _G / 2, _y + _G / 2]);
    for (var _k = array_length(_cand) - 1; _k > 0; _k--) { var _j = floor(pnd__rng_next(_J.rng) * (_k + 1)), _t = _cand[_k]; _cand[_k] = _cand[_j]; _cand[_j] = _t; }
    _J.cand = _cand; _J.c = 0;
    // Each slot WANTS a kind (rotating) and keeps it across places; only after PND_HOLD refusals in a row does it take
    // whichever kind a place allows, paint-out LAST (MZ edition, balance probe 2026-10-04)
    var _rot = [3, 1, 2, 0], _ord = [[0, 1, 3, 2], [1, 3, 2, 0], [2, 3, 1, 0], [3, 1, 2, 0]];
    var _kinds = variable_struct_exists(_o, "kinds") ? _o.kinds : undefined;
    if (is_array(_kinds) && array_length(_kinds) > 0) {
        var _ok = [false, false, false, false], _any = false;
        for (var _q = 0; _q < array_length(_kinds); _q++) { var _ki = pnd__kind_index(_kinds[_q]); if (_ki >= 0) { _ok[_ki] = true; _any = true; } }
        if (_any) {
            var _r2 = []; for (var _q2 = 0; _q2 < 4; _q2++) if (_ok[_rot[_q2]]) array_push(_r2, _rot[_q2]);
            var _o2 = []; for (var _q3 = 0; _q3 < 4; _q3++) { var _row = []; for (var _q4 = 0; _q4 < 4; _q4++) if (_ok[_ord[_q3][_q4]]) array_push(_row, _ord[_q3][_q4]); array_push(_o2, _row); }
            _rot = _r2; _ord = _o2;
        }
    }
    _J.rot = _rot; _J.ord = _ord; _J.refused = 0; _J.scarce = [false, false, false, false];
    var _no = array_length(_J.corpus), _objOrder = array_create(_no);
    for (var _k2 = 0; _k2 < _no; _k2++) _objOrder[_k2] = _k2;
    for (var _k3 = _no - 1; _k3 > 0; _k3--) { var _jo = floor(pnd__rng_next(_J.rng) * (_k3 + 1)), _to = _objOrder[_k3]; _objOrder[_k3] = _objOrder[_jo]; _objOrder[_jo] = _to; }
    _J.objOrder = _objOrder; _J.objNext = 0; _J.usedObj = array_create(_no, false);
    return _J;
}

/// @function pnd__make_place(job)
/// @description Internal. Try ONE candidate place (the MZ edition's loop body, unchanged in order and in every draw).
function pnd__make_place(_J) {
    var _KN = ["paintout", "mirror", "recolour", "add"];
    var _kind0 = _J.rot[array_length(_J.changes) mod array_length(_J.rot)];
    if (_J.refused >= PND_HOLD) _J.scarce[_kind0] = true;
    var _cx = _J.cand[_J.c][0], _cy = _J.cand[_J.c][1];
    var _tries = (_J.refused < PND_HOLD && !_J.scarce[_kind0]) ? 1 : array_length(_J.ord[_kind0]);
    var _made = false, _spaced = true;
    for (var _a = 0; _a < _tries; _a++) {
        var _kind = _KN[_J.ord[_kind0][_a]], _r, _res = undefined;
        if (_kind == "recolour") _r = 40;
        else if (_kind == "add") _r = 20 + floor(pnd__rng_next(_J.rng) * 5);
        else _r = 18 + floor(pnd__rng_next(_J.rng) * 7);
        for (var _k = 0; _k < array_length(_J.changes); _k++) {
            var _ch = _J.changes[_k], _dx = _ch.x - _cx, _dy = _ch.y - _cy, _lim = _ch.r + _r + 8;
            if (_dx * _dx + _dy * _dy < _lim * _lim) { _spaced = false; break; }
        }
        if (!_spaced) break;
        if (_kind == "paintout") { var _sgn = (pnd__rng_next(_J.rng) < 0.5) ? -1 : 1; _res = pnd_paint_out(_J.out, _cx, _cy, _r, _sgn * _r * 2.2); }
        else if (_kind == "mirror") _res = pnd_mirror(_J.out, _cx, _cy, _r, 0.08);
        else if (_kind == "recolour") { var _pk = pnd__rng_next(_J.rng); _res = pnd_recolour(_J.out, _cx, _cy, { radius: _r, minArea: 300, maxArea: 6000, pick: _pk }); }
        else {
            var _cls = pnd_ground_class(_J.out, _cx, _cy, _r), _pickO = -1;
            var _flipO = pnd__rng_next(_J.rng) < 0.5;
            var _tiltO = (pnd__rng_next(_J.rng) - 0.5) * 0.5;
            var _no = array_length(_J.corpus);
            for (var _pass = 0; _pass < ((_J.refused >= PND_REPEAT_AFTER) ? 2 : 1) && is_undefined(_res); _pass++) {
                for (var _q = 0; _q < _no && is_undefined(_res); _q++) {
                    var _oi = _J.objOrder[(_J.objNext + _q) mod _no], _ob = _J.corpus[_oi];
                    if (!array_contains(_ob.where, _cls)) continue;
                    if (_pass > 0 ? !_J.usedObj[_oi] : _J.usedObj[_oi]) continue;
                    _res = pnd_add_object(_J.out, _cx, _cy, _r, _oi, { flip: _flipO, tilt: _tiltO, corpus: (_no == 12) ? "mz12" : "all" });
                    if (!is_undefined(_res)) _pickO = _oi;
                }
            }
            _J.objNext++;
            if (!is_undefined(_res)) { _res.ground = _cls; _J.usedObj[_pickO] = true; }
        }
        if (is_undefined(_res)) continue;
        var _vis = pnd_visibility(_J.src, _J.out, _cx, _cy, _r + 6);
        if (_vis.px >= PND_FLOOR_PX && _vis.meanDelta >= PND_FLOOR_DELTA) {
            var _c = { kind: _kind, x: _res.x, y: _res.y, r: _res.r };
            if (variable_struct_exists(_res, "object")) { _c.object = _res.object; _c.ground = _res.ground; }
            array_push(_J.changes, _c); _made = true; break;
        }
        pnd__restore(_J.out, _J.src, pnd__round(_cx), pnd__round(_cy), _r + 1);
    }
    if (_made) _J.refused = 0; else if (_spaced) _J.refused++;
    _J.places_tried++;
}

/// @function pnd_make_step(job, [budget_us])
/// @description Advance a job by whole candidate places until about budget_us microseconds have passed (at least one
/// place per call; 8000 by default). Returns true when the job is finished.
/// @returns {Bool}
function pnd_make_step(_J, _budget = 8000) {
    if (!is_struct(_J) || !variable_struct_exists(_J, "done") || _J.done) return true;
    if (!pnd__ok(_budget)) _budget = 8000;
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    var _t0 = get_timer();
    do {
        if (_J.c >= array_length(_J.cand) || array_length(_J.changes) >= _J.want) { _J.done = true; break; }
        pnd__make_place(_J);
        _J.c++;
        if (_J.c >= array_length(_J.cand) || array_length(_J.changes) >= _J.want) _J.done = true;
    } until (_J.done || get_timer() - _t0 >= _budget);
    math_set_epsilon(_eps);
    var _dt = get_timer() - _t0;
    _J.steps++; _J.total_us += _dt; _J.worst_us = max(_J.worst_us, _dt);
    return _J.done;
}

/// @function pnd_make_differences(image, [options])
/// @description pnd_make_begin + pnd_make_step to the end, in one call (this frame pays for all of it). Returns
/// { image (a NEW image; free it), changes: [{ kind, x, y, r, object?, ground? }] }.
/// @returns {Struct}
function pnd_make_differences(_img, _o = {}) {
    if (!pnd__img_ok(_img)) return { image: undefined, changes: [] };
    var _J = pnd_make_begin(_img, _o);
    while (!pnd_make_step(_J, 1000000000)) {}
    return { image: _J.out, changes: _J.changes };
}

/// @function pnd_make_free(job, [keep_out])
/// @description Free a job's working image (unless keep_out). The source image is the caller's and is never freed here.
function pnd_make_free(_J, _keep = false) {
    if (!is_struct(_J) || !variable_struct_exists(_J, "out")) return;
    if (!(is_bool(_keep) && _keep)) pnd_image_free(_J.out);
    _J.done = true;
}

/// @function pnd_hit(changes, x, y)
/// @description Which change (index) a point in WORK-image coordinates lands on, or -1: within the change's radius + 6.
/// @returns {Real}
function pnd_hit(_changes, _x, _y) {
    if (!is_array(_changes) || !is_numeric(_x) || !is_numeric(_y)) return -1;
    for (var _i = 0; _i < array_length(_changes); _i++) {
        var _c = _changes[_i], _dx = _c.x - _x, _dy = _c.y - _y;
        if (sqrt(_dx * _dx + _dy * _dy) <= _c.r + 6) return _i;
    }
    return -1;
}
