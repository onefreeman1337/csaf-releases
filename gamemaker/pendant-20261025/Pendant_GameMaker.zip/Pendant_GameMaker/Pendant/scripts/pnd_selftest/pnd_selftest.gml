/// pnd_selftest.gml - Pendant's in-engine test suite. Run the demo with -selftest: the result is written as
/// pnd_selftest.json in the game's save folder, and the renders (pnd_render_*.png) beside it, to be LOOKED at.
/// Stages 10-50 hold the core to the reference (pnd_oracle): the seed hash and generator, every object's distance field,
/// every object drawn, the ground classes, and whole puzzles made on both demo paintings - change for change and byte for
/// byte. The later stages test the gallery: layout, the play (finds, misses, hints, giving up, the clock), the result, the
/// drawing (inked, saved) and refusals on bad input.
///
/// Pendant - Spot the Difference From Any Picture, for GameMaker. Copyright (c) 2026 Core Systems Asset Factory.
/// Licence: see LICENSE.txt.

/// @function pnd_st_assert(state, condition, message)
/// @description Count one assertion; keep the first 80 failure messages.
function pnd_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 80) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
/// @function pnd_st_stage(state, n)
/// @description Record the stage reached (the crash handler reports it).
function pnd_st_stage(_st, _n) { _st.stage = _n; global.pnd_stage = _n; }

/// @function pnd__st_changes_text(changes)
/// @description Internal. A change list as one comparable line.
function pnd__st_changes_text(_ch) {
    var _s = "";
    for (var _i = 0; _i < array_length(_ch); _i++) {
        var _c = _ch[_i];
        _s += _c.kind + "@" + string(_c.x) + "," + string(_c.y) + "r" + string(_c.r);
        if (variable_struct_exists(_c, "object")) _s += ":" + _c.object + "/" + _c.ground;
        _s += ";";
    }
    return _s;
}

/// @function pnd__st_ground(k)
/// @description Internal. The oracle's flat ground for object k: 64 x 64, a base colour plus an integer grain.
function pnd__st_ground(_k) {
    static _GR = [[150, 190, 225], [26, 32, 64], [58, 108, 150], [104, 150, 72], [150, 108, 70], [132, 128, 122], [44, 32, 26]];
    var _img = pnd_image_create(64, 64), _c = _GR[_k mod 7];
    for (var _y = 0; _y < 64; _y++) for (var _x = 0; _x < 64; _x++) {
        var _i = (_y * 64 + _x) * 4, _n = ((_x * 7 + _y * 13) mod 9) - 4;
        buffer_poke(_img.buf, _i, buffer_u8, _c[0] + _n); buffer_poke(_img.buf, _i + 1, buffer_u8, _c[1] + _n);
        buffer_poke(_img.buf, _i + 2, buffer_u8, _c[2] + _n); buffer_poke(_img.buf, _i + 3, buffer_u8, 255);
    }
    return _img;
}

/// @function pnd_selftest_run()
/// @description Run every stage; returns the state written by pnd_selftest_write.
function pnd_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, failures: [], stage: 0, notes: {}, timings: {} };
    var _O = pnd_oracle();
    _st.notes.epsilon_default = string_format(math_get_epsilon(), 1, 12);

    // ------------------------------------------------------------ 10: the seed hash and the generator
    pnd_st_stage(_st, 10);
    for (var _i = 0; _i < array_length(_O.seeds); _i++) {
        var _got = pnd_seed_of(_O.seeds[_i][0]);
        pnd_st_assert(_st, _got == _O.seeds[_i][1], "seed_of(" + string(_O.seeds[_i][0]) + ") = " + string(_got) + ", reference " + string(_O.seeds[_i][1]));
    }
    var _g = pnd__rng(12345), _dmax = 0;
    for (var _i2 = 0; _i2 < array_length(_O.draws); _i2++) { var _v = pnd__rng_next(_g); _dmax = max(_dmax, abs(_v - _O.draws[_i2])); }
    pnd_st_assert(_st, _dmax == 0, "24 generator draws exact (max error " + string_format(_dmax, 1, 17) + ")");

    // ------------------------------------------------------------ 20: every object's distance field
    pnd_st_stage(_st, 20);
    var _eps0 = math_get_epsilon(); math_set_epsilon(0);
    var _C = __pnd_corpus(), _lmax = 0, _lbad = 0;
    for (var _i3 = 0; _i3 < array_length(_O.lattice); _i3++) {
        var _r = _O.lattice[_i3], _d = _C[_r[0]].fn(_r[1], _r[2], _r[3]), _e = abs(_d - _r[4]);
        _lmax = max(_lmax, _e); if (_e > 0.000000000001) _lbad++;
    }
    math_set_epsilon(_eps0);
    pnd_st_assert(_st, _lbad == 0, string(array_length(_O.lattice)) + " lattice distances (every layer of all " + string(array_length(_C)) + " objects) within 1e-12: " + string(_lbad) + " off, max error " + string_format(_lmax, 1, 17));
    _st.notes.lattice_max_error = string_format(_lmax, 1, 17);
    pnd_st_assert(_st, array_length(_C) == pnd_object_count() && pnd_object_count() >= 40, "the corpus has 40+ objects: " + string(pnd_object_count()));

    // ------------------------------------------------------------ 30: every object drawn
    pnd_st_stage(_st, 30);
    var _dbad = [];
    math_set_epsilon(0);
    for (var _i4 = 0; _i4 < array_length(_O.drawn); _i4++) {
        var _row = _O.drawn[_i4], _img = pnd__st_ground(_row[0]);
        var _res = pnd_add_object(_img, 32, 32, 24, _row[0], { maxBusy: 1000000000, minSep: 0, tilt: 0, flip: (_row[0] mod 2) == 1 });
        var _m = buffer_md5(_img.buf, 0, 64 * 64 * 4);
        if (is_undefined(_res) || string_lower(_m) != _row[1] || _res.body[0] != _row[2] || _res.body[1] != _row[3] || _res.body[2] != _row[4]) {
            array_push(_dbad, _C[_row[0]].id);
            buffer_save(_img.buf, "pnd_drawn_" + _C[_row[0]].id + ".raw");
        }
        pnd_image_free(_img);
    }
    math_set_epsilon(_eps0);
    pnd_st_assert(_st, array_length(_dbad) == 0, string(array_length(_O.drawn) - array_length(_dbad)) + "/" + string(array_length(_O.drawn)) + " objects drawn byte-identical to the reference; off: " + string(_dbad));

    // ------------------------------------------------------------ 40: the demo paintings and the ground classes
    pnd_st_stage(_st, 40);
    var _pics = {};
    for (var _i5 = 0; _i5 < array_length(_O.pictures); _i5++) {
        var _p = _O.pictures[_i5], _spr = (_p[0] == "village") ? spr_pnd_demo_village : spr_pnd_demo_harbour;
        var _im = pnd_image_from_sprite(_spr, 0);
        var _pm = string_lower(buffer_md5(_im.buf, 0, _im.w * _im.h * 4));
        pnd_st_assert(_st, _im.w == _p[1] && _im.h == _p[2] && _pm == _p[3], _p[0] + ": the sprite read back at its work size is the reference's bytes (" + string(_im.w) + "x" + string(_im.h) + ", md5 " + _pm + " vs " + _p[3] + ")");
        variable_struct_set(_pics, _p[0], _im);
    }
    var _gbad = 0;
    for (var _i6 = 0; _i6 < array_length(_O.ground); _i6++) {
        var _gr = _O.ground[_i6], _cls = pnd_ground_class(variable_struct_get(_pics, _gr[0]), _gr[1], _gr[2], _gr[3]);
        if (_cls != _gr[4]) { _gbad++; pnd_st_assert(_st, false, "ground class at " + _gr[0] + " " + string(_gr[1]) + "," + string(_gr[2]) + ": " + _cls + ", reference " + _gr[4]); }
    }
    pnd_st_assert(_st, _gbad == 0, string(array_length(_O.ground) - _gbad) + "/" + string(array_length(_O.ground)) + " ground classes as the reference");

    // ------------------------------------------------------------ 45: probe (the palette hue test, 2026-10-25)
    pnd_st_stage(_st, 45);
    {
        var _pb = buffer_create(4, buffer_fixed, 1);
        buffer_poke(_pb, 0, buffer_u8, 183); buffer_poke(_pb, 1, buffer_u8, 153); buffer_poke(_pb, 2, buffer_u8, 104);
        var _pr = buffer_peek(_pb, 0, buffer_u8), _pg = buffer_peek(_pb, 1, buffer_u8), _pbb = buffer_peek(_pb, 2, buffer_u8);
        var _mh = 67.17027559055117, _h1 = pnd__hue(183, 153, 104), _h2 = pnd__hue(_pr, _pg, _pbb), _gp = pnd__hue_gap(_h2, _mh);
        _st.notes.hue_probe = { typeof_peek: typeof(_pr), hue_lit: _h1, hue_peek: _h2, typeof_hue: typeof(_h2), gap: _gp, typeof_gap: typeof(_gp),
            diff: _gp - 60, prod: (_gp - 60) * PND_EXACT, typeof_prod: typeof((_gp - 60) * PND_EXACT), lt_local: ((_gp - 60) * PND_EXACT < 0),
            lt_inline: ((pnd__hue_gap(pnd__hue(_pr, _pg, _pbb), _mh) - 60) * PND_EXACT < 0), lt_plain: (_gp < 60), typeof_exact: typeof(PND_EXACT) };
        buffer_delete(_pb);
        // int32 / int32 is an integer division on this runtime: a hue from PEEKED bytes must equal the hue from literals
        pnd_st_assert(_st, typeof(_pr) == "int32", "control: buffer_peek(u8) returns an int32 here (" + typeof(_pr) + ") - if this goes red the trap below is no longer exercised");
        pnd_st_assert(_st, abs(_h2 - _h1) < 0.0001 && abs(_h1 - 37.21518987341772) < 0.0001,"the hue of PEEKED bytes is the real hue (peeked " + string(_h2) + ", literals " + string(_h1) + ")");
        pnd_st_assert(_st, _st.notes.hue_probe.lt_inline, "a palette colour 30 degrees from the region's hue is excluded");
    }

    // ------------------------------------------------------------ 50: whole puzzles, change for change and byte for byte
    pnd_st_stage(_st, 50);
    var _worst = 0, _tot = 0, _steps = 0, _nch = 0, _kinds = {};
    for (var _i7 = 0; _i7 < array_length(_O.cases); _i7++) {
        var _cs = _O.cases[_i7], _src = variable_struct_get(_pics, _cs.pic);
        var _opt = { count: _cs.count, seed: _cs.seed, corpus: _cs.corpus };
        if (!is_undefined(_cs.kinds)) _opt.kinds = _cs.kinds;
        global.pnd__trace = [];
        var _J = pnd_make_begin(_src, _opt);
        while (!pnd_make_step(_J, 8000)) {}
        if (array_length(global.pnd__trace) > 0) variable_struct_set(_st.notes, "recolour_trace_" + string(_i7), global.pnd__trace);
        global.pnd__trace = undefined;
        var _want = pnd__st_changes_text(_cs.changes), _gotc = pnd__st_changes_text(_J.changes);
        var _m2 = string_lower(buffer_md5(_J.out.buf, 0, _J.out.w * _J.out.h * 4));
        pnd_st_assert(_st, _gotc == _want, "puzzle " + string(_i7) + " (" + _cs.pic + ", seed " + string(_cs.seed) + ", " + string(_cs.count) + ", " + _cs.corpus + "): changes " + _gotc + " | reference " + _want);
        if (!pnd_st_assert(_st, _m2 == _cs.md5, "puzzle " + string(_i7) + ": second picture byte-identical (md5 " + _m2 + " vs " + _cs.md5 + ")")) buffer_save(_J.out.buf, "pnd_case_" + string(_i7) + ".raw");
        _worst = max(_worst, _J.worst_us); _tot += _J.total_us; _steps += _J.steps; _nch += array_length(_J.changes);
        for (var _q = 0; _q < array_length(_J.changes); _q++) { var _kk = _J.changes[_q].kind; variable_struct_set(_kinds, _kk, (variable_struct_exists(_kinds, _kk) ? variable_struct_get(_kinds, _kk) : 0) + 1); }
        pnd_make_free(_J);
    }
    pnd_st_assert(_st, _nch > 0, "the puzzles made changes (" + string(_nch) + ")");
    _st.timings.make = { puzzles: array_length(_O.cases), changes: _nch, total_ms: _tot / 1000, steps: _steps, worst_step_ms: _worst / 1000, kinds: _kinds };

    // ------------------------------------------------------------ 60+: the gallery (pnd_selftest_gallery)
    pnd_selftest_gallery(_st, _pics);

    var _names = variable_struct_get_names(_pics);
    for (var _i8 = 0; _i8 < array_length(_names); _i8++) pnd_image_free(variable_struct_get(_pics, _names[_i8]));
    pnd_st_stage(_st, 99);
    return _st;
}

/// @function pnd__st_ready(puzzle, [cap])
/// @description Internal. Step a puzzle until its differences are made (or cap steps); returns the steps taken.
function pnd__st_ready(_P, _cap = 5000) { var _n = 0; while (is_struct(_P) && _P.state == "making" && _n < _cap) { pnd_step(_P); _n++; } return _n; }

/// @function pnd__st_render(puzzle, w, h, name)
/// @description Internal. Draw the gallery into a w x h surface, save it as pnd_render_<name>.png, and return its bytes
/// { buf, w, h } (free buf). An opaque black ground under it, so the save shows what a player sees.
function pnd__st_render(_P, _w, _h, _name) {
    var _sf = surface_create(_w, _h);
    surface_set_target(_sf); draw_clear(c_black); pnd_draw(_P, 0, 0, 1); surface_reset_target();
    if (_name != "") surface_save(_sf, "pnd_render_" + _name + ".png");
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1); buffer_get_surface(_b, _sf, 0); surface_free(_sf);
    return { buf: _b, w: _w, h: _h };
}

/// @function pnd__st_count(read, x0, y0, x1, y1, test)
/// @description Internal. Pixels in a box for which test(r, g, b) is true.
function pnd__st_count(_rd, _x0, _y0, _x1, _y1, _test) {
    var _n = 0;
    for (var _y = max(0, floor(_y0)); _y < min(_rd.h, ceil(_y1)); _y++) for (var _x = max(0, floor(_x0)); _x < min(_rd.w, ceil(_x1)); _x++) {
        var _o = (_y * _rd.w + _x) * 4;
        if (_test(real(buffer_peek(_rd.buf, _o, buffer_u8)), real(buffer_peek(_rd.buf, _o + 1, buffer_u8)), real(buffer_peek(_rd.buf, _o + 2, buffer_u8)))) _n++;
    }
    return _n;
}

/// @function pnd__st_far_point(puzzle)
/// @description Internal. A point on the second painting at least 30 work pixels from every change (for a miss).
function pnd__st_far_point(_P) {
    for (var _v = 20; _v < _P.img.h - 20; _v += 9) for (var _u = 20; _u < _P.img.w - 20; _u += 9) {
        var _ok = true;
        for (var _i = 0; _i < array_length(_P.changes); _i++) { var _c = _P.changes[_i]; if (point_distance(_u, _v, _c.x, _c.y) < _c.r + 30) { _ok = false; break; } }
        if (_ok) return [_P.L.bx + _u * _P.sc, _P.L.by + _v * _P.sc];
    }
    return undefined;
}

/// @function pnd_selftest_gallery(state, pictures)
/// @description Stages 60-95: the layout, a played puzzle (scripted), the clock, giving up, the kinds fallback, a surface
/// picture, the drawing (inked and saved) and refusals on bad input.
function pnd_selftest_gallery(_st, _pics) {
    var _red = function(_r, _g, _b) { return _r > 140 && _g < 80 && _b < 80; };

    // ------------------------------------------------------------ 60: the layout on four screens
    pnd_st_stage(_st, 60);
    var _sizes = [[816, 624], [1280, 720], [1920, 1080], [1080, 1920]];
    for (var _i = 0; _i < array_length(_sizes); _i++) {
        var _W = _sizes[_i][0], _H = _sizes[_i][1], _L = pnd_layout(640, 429, _W, _H), _S = pnd_ui_scale(_W, _H);
        var _inA = _L.ax - _L.f >= 0 && _L.ay - _L.f >= round(20 * _S) && _L.ax + _L.w + _L.f <= _W, _inB = _L.bx + _L.w + _L.f <= _W && _L.by + _L.h + _L.f <= _H - round(60 * _S);
        var _apart = _L.stacked ? (_L.by - _L.f >= _L.ay + _L.h + _L.f) : (_L.bx - _L.f >= _L.ax + _L.w + _L.f);
        pnd_st_assert(_st, _inA && _inB && _apart, string(_W) + "x" + string(_H) + ": both frames inside the wall, clear of the rail and the plaque, not touching (" + json_stringify(_L) + ")");
        pnd_st_assert(_st, abs(_L.w / _L.h - 640 / 429) < 0.02, string(_W) + "x" + string(_H) + ": the painting keeps its aspect");
        if (_W < _H) pnd_st_assert(_st, _L.stacked, "a portrait screen hangs the pair one above the other");
        else pnd_st_assert(_st, !_L.stacked, "a landscape screen hangs the pair side by side");
    }

    // ------------------------------------------------------------ 70: a puzzle played by script
    pnd_st_stage(_st, 70);
    pnd_st_assert(_st, is_undefined(pnd_open({})) && is_undefined(pnd_open(undefined)) && is_undefined(pnd_open({ sprite: -1 })) && is_undefined(pnd_open({ sprite: "spr_none" })), "opening with no picture is refused (undefined) and does not throw");
    var _sounds = [];
    var _tOpen = get_timer();
    var _P = pnd_open({ sprite: spr_pnd_demo_village, count: 6, seed: 11, width: 1280, height: 720, hints: 2, key: "test", sound: method({ s: _sounds }, function(_n) { array_push(s, _n); }) });
    _st.timings.open_ms = (get_timer() - _tOpen) / 1000;
    pnd_st_assert(_st, is_struct(_P) && _P.state == "making", "the puzzle opens making its differences");
    var _rdM = pnd__st_render(_P, 1280, 720, "making");
    var _steps = pnd__st_ready(_P);
    pnd_st_assert(_st, _P.state == "play" && array_length(_P.changes) == 6, "the differences are made over " + string(_steps) + " steps and play begins with 6 (" + string(array_length(_P.changes)) + ")");
    _st.timings.open_village_6 = { steps: _steps, worst_step_ms: _P.job.worst_us / 1000, total_ms: _P.job.total_us / 1000, places_tried: _P.job.places_tried };
    // the drape was drawn while making: the second frame held velvet, not the picture
    var _velvet = pnd__st_count(_rdM, _P.L.bx, _P.L.by, _P.L.bx + _P.L.w, _P.L.by + _P.L.h, function(_r, _g, _b) { return _r > 50 && _r < 150 && _g < 50 && _b < 60 && _r > _g * 2; });
    pnd_st_assert(_st, _velvet > _P.L.w * _P.L.h * 0.6, "while making, the second frame shows the drape (" + string(_velvet) + " velvet px)");
    buffer_delete(_rdM.buf);
    _P.dt_us = 16667;
    // a click on the wall is nothing, on nothing is a miss
    pnd_st_assert(_st, pnd_mark(_P, 4, 4) == "none", "a click on the wall is neither a find nor a miss");
    var _far = pnd__st_far_point(_P);
    _P.inject = { x: _far[0], y: _far[1], click: true }; pnd_step(_P);
    pnd_st_assert(_st, _P.misses == 1 && array_length(_P.miss_list) == 1, "a click on the painting away from every change is a miss");
    // the hint lights the first unfound change; a second hint while it shows is refused
    var _glow = function(_r, _g, _b) { return _r > 235 && _g > 195 && _b < 175 && _r - _b > 90; };
    var _h0 = _P.changes[0], _hx = _P.L.bx + _h0.x * _P.sc, _hy = _P.L.by + _h0.y * _P.sc, _hr = max(36 * _P.S, (_h0.r + 30) * _P.sc * 2.4) / 2 + 4;
    var _rdPre = pnd__st_render(_P, 1280, 720, "");
    var _glowPre = pnd__st_count(_rdPre, _hx - _hr, _hy - _hr, _hx + _hr, _hy + _hr, _glow);
    buffer_delete(_rdPre.buf);
    pnd_st_assert(_st, pnd_hint(_P) && _P.hint_idx == 0 && _P.hints_used == 1, "a hint lights the first difference not found");
    pnd_st_assert(_st, !pnd_hint(_P) && _P.hints_used == 1, "a second hint while one shows is refused and costs nothing");
    for (var _hs = 0; _hs < 40; _hs++) pnd_step(_P);
    var _rdBefore = pnd__st_render(_P, 1280, 720, "hint");
    var _glowOn = pnd__st_count(_rdBefore, _hx - _hr, _hy - _hr, _hx + _hr, _hy + _hr, _glow);
    pnd_st_assert(_st, _glowOn - _glowPre > 150, "forty frames into a hint its lamp glow rings the difference (" + string(_glowPre) + " glow px before, " + string(_glowOn) + " with it)");
    // find change 0 on the RIGHT painting by a scripted click, change 1 on the LEFT painting
    var _c0 = _P.changes[0], _c1 = _P.changes[1];
    var _redBefore = pnd__st_count(_rdBefore, _P.L.ax + _c1.x * _P.sc - 40, _P.L.ay + _c1.y * _P.sc - 40, _P.L.ax + _c1.x * _P.sc + 40, _P.L.ay + _c1.y * _P.sc + 40, _red);
    buffer_delete(_rdBefore.buf);
    _P.inject = { x: _P.L.bx + _c0.x * _P.sc, y: _P.L.by + _c0.y * _P.sc, click: true }; pnd_step(_P);
    pnd_st_assert(_st, _P.found[0] && _P.found_n == 1 && _P.hint_age == -1, "a click on a change (second painting) finds it and puts the hint out");
    _P.inject = { x: _P.L.ax + _c1.x * _P.sc + 3, y: _P.L.ay + _c1.y * _P.sc - 2, click: true }; pnd_step(_P);
    pnd_st_assert(_st, _P.found[1] && _P.found_n == 2, "a click on a change on the FIRST painting finds it too");
    pnd_st_assert(_st, pnd_mark(_P, _P.L.bx + _c0.x * _P.sc, _P.L.by + _c0.y * _P.sc) == "repeat" && _P.found_n == 2 && _P.misses == 1, "a click on a change already found is neither");
    // the keyboard hand: walk to change 2 and press OK
    var _c2 = _P.changes[2], _tx = _P.L.bx + _c2.x * _P.sc, _ty = _P.L.by + _c2.y * _P.sc, _guard = 0;
    while ((abs(_P.hand_x - _tx) > 3 * _P.S || abs(_P.hand_y - _ty) > 3 * _P.S) && _guard < 400) {
        _P.inject = { left: _P.hand_x > _tx + 3 * _P.S, right: _P.hand_x < _tx - 3 * _P.S, up: _P.hand_y > _ty + 3 * _P.S, down: _P.hand_y < _ty - 3 * _P.S };
        pnd_step(_P); _guard++;
    }
    _P.inject = { ok: true }; pnd_step(_P);
    pnd_st_assert(_st, _P.found[2] && _P.hand_on, "the keyboard hand walks to a change (" + string(_guard) + " steps) and OK finds it");
    for (var _q = 0; _q < 20; _q++) pnd_step(_P);
    var _rdPlay = pnd__st_render(_P, 1280, 720, "play");
    var _redAfter = pnd__st_count(_rdPlay, _P.L.ax + _c1.x * _P.sc - 40, _P.L.ay + _c1.y * _P.sc - 40, _P.L.ax + _c1.x * _P.sc + 40, _P.L.ay + _c1.y * _P.sc + 40, _red);
    pnd_st_assert(_st, _redAfter - _redBefore > 60, "a find draws a red ink ring round it (" + string(_redBefore) + " red px before, " + string(_redAfter) + " after)");
    var _c5 = _P.changes[5], _redUnfound = pnd__st_count(_rdPlay, _P.L.bx + _c5.x * _P.sc - 30, _P.L.by + _c5.y * _P.sc - 30, _P.L.bx + _c5.x * _P.sc + 30, _P.L.by + _c5.y * _P.sc + 30, _red);
    _st.notes.red_near_unfound = _redUnfound;
    // the plaque: its counts are drawn on the brass (dark ink inside the plaque box)
    var _ink = pnd__st_count(_rdPlay, _P.hud_x, _P.hud_y, _P.hud_x + _P.hud_w, _P.hud_y + _P.hud_h, function(_r, _g, _b) { return _r < 70 && _g < 50; });
    pnd_st_assert(_st, _ink > 200, "the plaque carries its engraved counts (" + string(_ink) + " dark px)");
    buffer_delete(_rdPlay.buf);
    // the rest by script; the ending; the result
    for (var _k = 3; _k < 6; _k++) { var _ck = _P.changes[_k]; _P.inject = { x: _P.L.bx + _ck.x * _P.sc, y: _P.L.by + _ck.y * _P.sc, click: true }; pnd_step(_P); }
    pnd_st_assert(_st, _P.state == "done" && is_struct(_P.result) && _P.result.allFound && _P.result.found == 6 && _P.result.count == 6 && _P.result.misses == 1 && _P.result.hints == 1 && _P.result.key == "test", "every change found: ALL FOUND, and the result says 6 of 6, 1 miss, 1 hint (" + json_stringify(_P.result) + ")");
    pnd_st_assert(_st, array_contains(_sounds, "find") && array_contains(_sounds, "miss") && array_contains(_sounds, "hint") && array_contains(_sounds, "solve"), "the sound hook heard find, miss, hint and solve (" + string(_sounds) + ")");
    _P.inject = { click: true, x: 10, y: 10 }; pnd_step(_P);
    pnd_st_assert(_st, _P.state == "done", "a press in the first moments of the ending does not skip it");
    for (var _q2 = 0; _q2 < 40; _q2++) pnd_step(_P);
    var _rdEnd = pnd__st_render(_P, 1280, 720, "allfound");
    var _endInk = pnd__st_count(_rdEnd, _P.end_x, _P.end_y, _P.end_x + _P.end_w, _P.end_y + _P.end_h, function(_r, _g, _b) { return _r > 200 && _g > 180 && _b > 120; });
    pnd_st_assert(_st, _endInk > 300, "the ALL FOUND plaque is lettered (" + string(_endInk) + " pale px)");
    buffer_delete(_rdEnd.buf);
    _P.inject = { ok: true }; pnd_step(_P);
    pnd_st_assert(_st, pnd_closed(_P), "OK after the ending closes the gallery");
    var _sprs = [_P.spr_static, _P.spr_a, _P.spr_b, _P.rings[0]];
    pnd_free(_P); pnd_free(_P);
    var _alive = 0; for (var _s = 0; _s < array_length(_sprs); _s++) if (sprite_exists(_sprs[_s])) _alive++;
    pnd_st_assert(_st, _alive == 0, "pnd_free frees every sprite it made, and is safe twice (" + string(_alive) + " alive)");

    // ------------------------------------------------------------ 75: the clock, giving up, the kinds fallback, a surface
    pnd_st_stage(_st, 75);
    var _T = pnd_open({ sprite: spr_pnd_demo_harbour, count: 4, seed: 5, time: 3, width: 1280, height: 720 });
    pnd__st_ready(_T); _T.dt_us = 1000000;
    pnd_step(_T); pnd_step(_T);
    pnd_st_assert(_st, _T.state == "play", "two seconds into a three-second limit the puzzle still runs");
    pnd_step(_T);
    pnd_st_assert(_st, _T.state == "done" && _T.result.timedOut && !_T.result.allFound && _T.result.seconds == 3, "at three seconds the time runs out (" + json_stringify(_T.result) + ")");
    for (var _q3 = 0; _q3 < 41; _q3++) pnd_step(_T);
    var _rdT = pnd__st_render(_T, 1280, 720, "time");
    var _gh = 0; for (var _g = 0; _g < array_length(_T.changes); _g++) { var _cg = _T.changes[_g]; _gh += pnd__st_count(_rdT, _T.L.bx + _cg.x * _T.sc - 40, _T.L.by + _cg.y * _T.sc - 40, _T.L.bx + _cg.x * _T.sc + 40, _T.L.by + _cg.y * _T.sc + 40, function(_r, _g2, _b) { return _r > 220 && _g2 > 170 && _g2 < 215 && _b < 120; }); }
    pnd_st_assert(_st, _gh > 100, "the unfound differences are revealed with gold rings (" + string(_gh) + " gold px)");
    buffer_delete(_rdT.buf);
    pnd_free(_T);
    var _G = pnd_open({ sprite: spr_pnd_demo_harbour, count: 5, seed: 6, width: 1280, height: 720, wall: "plum" });
    pnd__st_ready(_G); _G.inject = { cancel: true }; pnd_step(_G);
    pnd_st_assert(_st, _G.state == "done" && _G.result.gaveUp && _G.result.found == 0 && !_G.result.allFound, "Cancel sets the puzzle aside (" + json_stringify(_G.result) + ")");
    for (var _q4 = 0; _q4 < 41; _q4++) pnd_step(_G);
    var _rdS = pnd__st_render(_G, 1280, 720, "setaside"); buffer_delete(_rdS.buf);
    pnd_free(_G);
    // the kinds fallback: a picture of vertical stripes has no object with an edge all round, so recolour alone finds nothing
    var _ss = surface_create(400, 300);
    surface_set_target(_ss); draw_clear(c_white);
    for (var _x = 0; _x < 400; _x += 20) { draw_set_colour(((_x div 20) mod 2) ? make_colour_rgb(40, 90, 150) : make_colour_rgb(230, 200, 120)); draw_rectangle(_x, 0, _x + 19, 299, false); }
    draw_set_colour(c_white); surface_reset_target();
    var _F = pnd_open({ surface: _ss, count: 3, seed: 2, kinds: ["recolour"], width: 1280, height: 720 });
    surface_free(_ss);
    pnd__st_ready(_F, 20000);
    pnd_st_assert(_st, is_struct(_F) && _F.state == "play" && _F.fallback && is_undefined(_F.result) && array_length(_F.changes) > 0, "recolour alone finds nothing on stripes, so the picture gets all four kinds (fallback " + string(_F.fallback) + ", " + string(array_length(_F.changes)) + " changes); the surface was copied and freed by the caller");
    pnd_free(_F);
    var _tiny = pnd_image_create(31, 31), _Jt = pnd_make_begin(_tiny, { count: 5 });
    pnd_st_assert(_st, _Jt.done && array_length(_Jt.changes) == 0, "a picture under 32 px makes no changes and the job is finished at once");
    pnd_make_free(_Jt); pnd_image_free(_tiny);

    // ------------------------------------------------------------ 80: the drawing on other screens and walls, under a transform
    pnd_st_stage(_st, 80);
    var _shapes = [[816, 624, "navy", "816"], [720, 1280, "oxblood", "portrait"]];
    for (var _i2 = 0; _i2 < array_length(_shapes); _i2++) {
        var _sh = _shapes[_i2], _Q = pnd_open({ sprite: spr_pnd_demo_village, count: 5, seed: 21, width: _sh[0], height: _sh[1], wall: _sh[2] });
        pnd__st_ready(_Q);
        for (var _f = 0; _f < 2; _f++) { var _cf = _Q.changes[_f]; _Q.inject = { x: _Q.L.bx + _cf.x * _Q.sc, y: _Q.L.by + _cf.y * _Q.sc, click: true }; pnd_step(_Q); }
        for (var _q5 = 0; _q5 < 20; _q5++) pnd_step(_Q);
        var _rd = pnd__st_render(_Q, _sh[0], _sh[1], _sh[3]);
        var _lit = pnd__st_count(_rd, 0, 0, _sh[0], _sh[1], function(_r, _g, _b) { return _r + _g + _b > 30; });
        pnd_st_assert(_st, _lit > _sh[0] * _sh[1] * 0.95, _sh[3] + ": the gallery covers its whole surface (" + string(_lit) + " px lit)");
        buffer_delete(_rd.buf);
        pnd_free(_Q);
    }
    // pnd_draw_wall stays inside the box it is given (2026-10-25: its vignette rings and edge motifs spilled past a 640 x 360
    // box in the buyer render) - a 300 x 200 wall drawn into a 400 x 300 grey surface, ink counted inside and outside
    var _ws = surface_create(400, 300);
    surface_set_target(_ws); draw_clear(make_colour_rgb(128, 128, 128)); pnd_draw_wall(300, 200, 1, "navy"); surface_reset_target();
    var _wr = { buf: buffer_create(400 * 300 * 4, buffer_fixed, 1), w: 400, h: 300 }; buffer_get_surface(_wr.buf, _ws, 0); surface_free(_ws);
    var _notGrey = function(_r, _g, _b) { return abs(_r - 128) + abs(_g - 128) + abs(_b - 128) > 6; };
    var _inW = pnd__st_count(_wr, 0, 0, 300, 200, _notGrey), _outW = pnd__st_count(_wr, 300, 0, 400, 300, _notGrey) + pnd__st_count(_wr, 0, 200, 300, 300, _notGrey);
    buffer_delete(_wr.buf);
    pnd_st_assert(_st, _inW > 300 * 200 * 0.9 && _outW == 0, "pnd_draw_wall stays inside its box (" + string(_inW) + " px inked inside, " + string(_outW) + " outside)");
    // a bake under the caller's 2x world matrix draws the same gallery and hands the matrix back (Doctrine_Craft s19)
    var _A = pnd_open({ sprite: spr_pnd_demo_village, count: 1, seed: 1, width: 640, height: 400 });
    var _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_build(0, 0, 0, 0, 0, 0, 2, 2, 1));
    var _B = pnd_open({ sprite: spr_pnd_demo_village, count: 1, seed: 1, width: 640, height: 400 });
    var _m2 = matrix_get(matrix_world);
    matrix_set(matrix_world, _mw);
    var _ra = pnd__st_render(_A, 640, 400, ""), _rb = pnd__st_render(_B, 640, 400, "");
    var _same = buffer_md5(_ra.buf, 0, 640 * 400 * 4) == buffer_md5(_rb.buf, 0, 640 * 400 * 4);
    pnd_st_assert(_st, _same && _m2[0] == 2, "opening under a 2x world matrix bakes the same gallery and leaves the caller's matrix as it was");
    buffer_delete(_ra.buf); buffer_delete(_rb.buf); pnd_free(_A); pnd_free(_B);

    // ------------------------------------------------------------ 85: the demo room
    pnd_st_stage(_st, 85);
    var _D = pnd_demo_create(1280, 720);
    pnd_demo_step(_D);
    var _sf = surface_create(1280, 720); surface_set_target(_sf); draw_clear(c_black); pnd_demo_draw(_D); surface_reset_target(); surface_save(_sf, "pnd_render_demo.png"); surface_free(_sf);
    _D.inject = { pick: 1 }; pnd_demo_step(_D); _D.inject = { count: 0 }; pnd_demo_step(_D); _D.inject = { open: true }; pnd_demo_step(_D);
    pnd_st_assert(_st, is_struct(_D.puzzle) && _D.puzzle.count == 3, "the demo opens the chosen painting with the chosen count");
    pnd__st_ready(_D.puzzle);
    _D.puzzle.inject = { cancel: true }; pnd_demo_step(_D);
    for (var _q6 = 0; _q6 < 42; _q6++) pnd_demo_step(_D);
    _D.puzzle.inject = { ok: true }; pnd_demo_step(_D);
    pnd_st_assert(_st, is_undefined(_D.puzzle) && is_struct(_D.last) && _D.last.key == "The Harbour Town", "leaving the puzzle returns to the gallery with its result");
    pnd_demo_free(_D);

    // ------------------------------------------------------------ 90: refusals on bad input
    pnd_st_stage(_st, 90);
    var _ok = true;
    try {
        pnd_step(undefined); pnd_draw(undefined); pnd_free(undefined); pnd_hint(undefined); pnd_give_up(undefined);
        if (pnd_mark(undefined, 1, 1) != "none") _ok = false;
        if (pnd_hit(undefined, 1, 1) != -1 || pnd_hit([], "a", 1) != -1) _ok = false;
        if (!pnd_closed(undefined)) _ok = false;
        var _im = pnd_image_create(64, 64);
        if (!is_undefined(pnd_add_object(_im, 32, 32, 20, "no such thing"))) _ok = false;
        if (!is_undefined(pnd_mirror(_im, 2, 2, 20))) _ok = false;
        if (!is_undefined(pnd_paint_out(_im, 32, 32, 20, 4000))) _ok = false;
        if (!is_undefined(pnd_recolour(_im, -5, -5))) _ok = false;
        if (pnd_seed_of(undefined) < 1 || pnd_seed_of("") < 1) _ok = false;
        pnd_image_free(_im); pnd_image_free(_im); pnd_image_free(undefined);
        var _O2 = pnd_open({ sprite: spr_pnd_demo_village, count: "lots", seed: undefined, hints: -5, time: "soon", wall: "pink", kinds: ["bogus"], width: 1280, height: 720 });
        if (!is_struct(_O2) || _O2.count != 5 || _O2.hints != 0 || _O2.time != 0 || _O2.wall != "green") _ok = false;
        pnd__st_ready(_O2);
        if (_O2.state != "play" || array_length(_O2.changes) != 5) _ok = false;
        pnd_free(_O2);
    } catch (_e) { _ok = false; _st.notes.refusal_crash = string(_e.message); }
    pnd_st_assert(_st, _ok, "every public call refuses bad input without a crash (bad count, seed, hints, time, wall and kinds fall back to their defaults)");
}

/// @function pnd_selftest_write(state)
/// @description Write the suite's result as pnd_selftest.json in the save folder.
function pnd_selftest_write(_st) {
    var _f = file_text_open_write("pnd_selftest.json");
    file_text_write_string(_f, json_stringify(_st));
    file_text_close(_f);
}
