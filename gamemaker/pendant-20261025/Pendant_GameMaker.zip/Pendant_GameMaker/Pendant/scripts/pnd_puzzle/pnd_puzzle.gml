/// pnd_puzzle.gml - the spot-the-difference itself: any picture hung twice in a drawn gallery, the second copy changed by
/// pnd_core, and the player finding the changes.
///
/// Pendant - Spot the Difference From Any Picture, for GameMaker. Copyright (c) 2026 Core Systems Asset Factory.
/// Licence: see LICENSE.txt.
///
/// Use: pnd_open(request) once (Create or Step); every frame pnd_step(puzzle) in Step and pnd_draw(puzzle, x, y, scale) in
/// Draw or Draw GUI; when pnd_closed(puzzle), read puzzle.result and pnd_free(puzzle).
/// Public functions (each documented below): pnd_open, pnd_step, pnd_draw, pnd_closed, pnd_free, pnd_ui_scale, pnd_layout,
/// pnd_mark, pnd_hint, pnd_give_up.

/// @function pnd_ui_scale(w, h)
/// @description The type and ornament scale for a gallery of w x h: 1 at 816 x 624 (the shorter side / 624), up to 3.
/// @returns {Real}
function pnd_ui_scale(_w, _h) { if (!pnd__ok(_w) || !pnd__ok(_h)) return 1; return max(1, min(3, min(_w, _h) / 624)); }

/// @function pnd_layout(pw, ph, w, h)
/// @description Where two pw x ph paintings hang in a w x h gallery: side by side or one above the other, whichever hangs
/// them larger, inside a margin that leaves the picture rail above and the plaque below (the MZ edition's solveLayout).
/// @returns {Struct} { w, h, f, ax, ay, bx, by, stacked } - each painting's size, its frame width, the two top-lefts
function pnd_layout(_pw, _ph, _W, _H) {
    if (!pnd__ok(_pw) || !pnd__ok(_ph) || !pnd__ok(_W) || !pnd__ok(_H) || _pw < 1 || _ph < 1 || _W < 160 || _H < 120) return undefined;
    var _S = pnd_ui_scale(_W, _H), _top = round(46 * _S), _foot = round(78 * _S), _side = round(22 * _S), _gap = round(26 * _S), _best = undefined;
    for (var _st = 0; _st < 2; _st++) {
        var _f = round(14 * _S), _w = 16, _h = 16;
        for (var _it = 0; _it < 3; _it++) {
            var _aw = _st ? _W - _side * 2 - _f * 2 : (_W - _side * 2 - _gap - _f * 4) / 2;
            var _ah = _st ? (_H - _top - _foot - _gap - _f * 4) / 2 : _H - _top - _foot - _f * 2;
            var _k = min(_aw / _pw, _ah / _ph);
            _w = max(16, floor(_pw * _k)); _h = max(16, floor(_ph * _k));
            _f = round(max(9 * _S, min(30 * _S, min(_w, _h) * 0.075)));
        }
        var _L;
        if (_st) { var _x0 = round((_W - _w) / 2), _used = _h * 2 + _f * 4 + _gap, _y0 = _top + round((_H - _top - _foot - _used) / 2) + _f; _L = { w: _w, h: _h, f: _f, ax: _x0, ay: _y0, bx: _x0, by: _y0 + _h + _f * 2 + _gap, stacked: true }; }
        else { var _usedW = _w * 2 + _f * 4 + _gap, _xa = round((_W - _usedW) / 2) + _f, _ya = _top + round((_H - _top - _foot - _h - _f * 2) / 2) + _f; _L = { w: _w, h: _h, f: _f, ax: _xa, ay: _ya, bx: _xa + _w + _f * 2 + _gap, by: _ya, stacked: false }; }
        if (is_undefined(_best) || _L.w * _L.h > _best.w * _best.h) _best = _L;
    }
    return _best;
}

/// @function pnd__req(request, name, default)
/// @description Internal. A request field, or the default when it is absent or undefined.
function pnd__req(_r, _n, _d) { if (!is_struct(_r) || !variable_struct_exists(_r, _n)) return _d; var _v = variable_struct_get(_r, _n); return is_undefined(_v) ? _d : _v; }

/// @function pnd__num(value, default, lo, hi)
/// @description Internal. A whole number in lo..hi (rounded half up), or the default when it is not a number.
function pnd__num(_v, _d, _lo, _hi) { if (!is_numeric(_v) || is_nan(_v) || is_infinity(_v)) return _d; return clamp(floor(_v + 0.5), _lo, _hi); }

/// @function pnd__sound(puzzle, name)
/// @description Internal. Call the request's sound hook, if any, with "find", "miss", "hint", "solve", "giveup" or "time".
function pnd__sound(_p, _name) { if (is_callable(_p.sound)) _p.sound(_name); }

/// @function pnd__bake(w, h, draw_fn)
/// @description Internal. Draw draw_fn() at 2x into a transparent surface, filter it down to w x h, and keep it as a sprite
/// (premultiplied: draw it with bm_one / bm_inv_src_alpha). Runs under an identity matrix and hands the caller's back (wing
/// Doctrine_Craft s19). Call in Step or Create, never in a Draw event.
function pnd__bake(_w, _h, _fn) {
    _w = max(1, ceil(_w)); _h = max(1, ceil(_h));
    var _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_build_identity());
    var _big = surface_create(_w * 2, _h * 2), _sm = surface_create(_w, _h);
    gpu_push_state();
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false); gpu_set_cullmode(cull_noculling);
    surface_set_target(_big);
    draw_clear_alpha(c_black, 0);
    matrix_set(matrix_world, matrix_build(0, 0, 0, 0, 0, 0, 2, 2, 1));
    _fn();
    matrix_set(matrix_world, matrix_build_identity());
    surface_reset_target();
    gpu_set_blendmode_ext(bm_one, bm_zero);
    gpu_set_texfilter(true);
    surface_set_target(_sm); draw_clear_alpha(c_black, 0); draw_surface_stretched(_big, 0, 0, _w, _h); surface_reset_target();
    gpu_pop_state();
    var _spr = sprite_create_from_surface(_sm, 0, 0, _w, _h, false, false, 0, 0);
    surface_free(_big); surface_free(_sm);
    matrix_set(matrix_world, _mw);
    return _spr;
}

/// @function pnd__draw_pm(sprite, x, y, scale, alpha)
/// @description Internal. Draw a premultiplied (baked) sprite at a scale, faded by alpha (colour times alpha, Doctrine_Craft s18).
function pnd__draw_pm(_spr, _x, _y, _k, _a) {
    if (_a <= 0) return;
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    var _c = make_colour_rgb(255 * _a, 255 * _a, 255 * _a);
    draw_sprite_ext(_spr, 0, _x, _y, _k, _k, 0, _c, _a);
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
}

/// @function pnd_open(request)
/// @description Open a puzzle: the picture is read at its work size, the gallery is drawn once, and the differences begin
/// (made a few milliseconds per pnd_step, behind a drape, so opening never stalls a frame for long). Request:
///   { sprite (or surface), subimg 0, count 1..12 (5), seed ("" = new differences every time), time 0..3600 seconds
///     (0 = no limit), hints 0..9 (3), wall "green" | "plum" | "navy" | "oxblood", kinds (array of "add", "recolour",
///     "mirror", "paintout"; all four by default), width / height (the GUI's by default), budget_us 8000, sound
///     function(name), key (anything; handed back in the result) }
/// Call in Create or Step, never in a Draw event. Returns undefined (and says why in the output log) with no picture.
/// @returns {Struct|Undefined} the puzzle
function pnd_open(_r) {
    var _img = undefined, _spr = pnd__req(_r, "sprite", undefined), _srf = pnd__req(_r, "surface", undefined);
    if (!is_undefined(_spr)) _img = pnd_image_from_sprite(_spr, pnd__num(pnd__req(_r, "subimg", 0), 0, 0, 100000));
    else if (!is_undefined(_srf)) _img = pnd_image_from_surface(_srf);
    if (is_undefined(_img)) { show_debug_message("Pendant: pnd_open needs a picture - { sprite: spr_x } or { surface: surf }."); return undefined; }
    var _W = pnd__req(_r, "width", display_get_gui_width()), _H = pnd__req(_r, "height", display_get_gui_height());
    if (!is_numeric(_W) || _W < 160) _W = max(160, display_get_gui_width());
    if (!is_numeric(_H) || _H < 120) _H = max(120, display_get_gui_height());
    static _counter = 0;
    _counter++;
    var _seed = pnd__req(_r, "seed", "");
    if (is_string(_seed) && string_trim(_seed) == "") _seed = "p" + string(_counter) + "t" + string(floor(get_timer() / 1000)) + "d" + string(floor(frac(date_current_datetime()) * 86400000));
    var _kinds = pnd__req(_r, "kinds", undefined);
    var _P = {
        state: "making", W: _W, H: _H, S: pnd_ui_scale(_W, _H), img: _img, seed: _seed, key: pnd__req(_r, "key", undefined),
        count: pnd__num(pnd__req(_r, "count", 5), 5, 1, 12), time: pnd__num(pnd__req(_r, "time", 0), 0, 0, 3600), hints: pnd__num(pnd__req(_r, "hints", 3), 3, 0, 9),
        wall: string(pnd__req(_r, "wall", "green")), kinds: is_array(_kinds) ? _kinds : undefined, budget: pnd__num(pnd__req(_r, "budget_us", 8000), 8000, 500, 1000000),
        sound: pnd__req(_r, "sound", undefined), fallback: false,
        changes: [], found: [], found_n: 0, misses: 0, hints_used: 0, elapsed_us: 0, frames: 0, done_age: 0, all_found: false, timed_out: false, gave_up: false,
        hand_x: 0, hand_y: 0, hand_on: false, hint_idx: -1, hint_age: -1, miss_list: [], ring_age: [], result: undefined, inject: undefined, dt_us: undefined,
        spr_static: -1, spr_hud: -1, spr_a: -1, spr_b: -1, spr_wash: -1, spr_end: -1, rings: [], ghosts: [], hud_on: true, end_y: 0, draw_x: 0, draw_y: 0, draw_k: 1
    };
    if (!variable_struct_exists(pnd_walls(), _P.wall)) _P.wall = "green";
    var _L = pnd_layout(_img.w, _img.h, _W, _H), _S = _P.S;
    _P.L = _L; _P.sc = _L.w / _img.w;
    _P.hud_w = min(_W - 40, round(460 * _S)); _P.hud_h = round(52 * _S); _P.hud_x = round((_W - _P.hud_w) / 2); _P.hud_y = _H - round(78 * _S) + round(13 * _S);
    _P.end_w = min(_W - 40, round(380 * _S)); _P.end_h = round(92 * _S); _P.end_x = round((_W - _P.end_w) / 2);
    var _below = max(_L.ay, _L.by) + _L.h + _L.f + round(6 * _S), _room = _P.hud_y - round(6 * _S) - _below;
    if (_room >= _P.end_h) { _P.end_y = _below + round((_room - _P.end_h) / 2); _P.end_over_hud = false; }
    else { _P.end_y = max(_below, _H - _P.end_h - round(6 * _S)); _P.end_over_hud = true; }
    _P.hand_x = round(_L.bx + _L.w / 2); _P.hand_y = round(_L.by + _L.h / 2);
    _P.spr_static = pnd__bake(_W, _H, method({ P: _P }, function() {
        pnd_draw_wall(P.W, P.H, P.S, P.wall);
        pnd_draw_hanging(P.L, P.S, P.W);
        pnd_draw_frame(P.L.ax, P.L.ay, P.L.w, P.L.h, P.L.f, P.S);
        pnd_draw_frame(P.L.bx, P.L.by, P.L.w, P.L.h, P.L.f, P.S);
        pnd_draw_lamps(P.L, P.S);
    }));
    // the counts plaque is its own sprite: where the ending plaque takes its place it is hidden whole (baked into the wall,
    // its brass showed at both ends of the ending plaque, first look 2026-10-25)
    _P.spr_hud = pnd__bake(_P.hud_w, _P.hud_h, method({ P: _P }, function() { pnd_draw_plaque_base(0, 0, P.hud_w, P.hud_h, P.S); }));
    _P.spr_wash = pnd__bake(_L.w + _L.f * 2, _L.h + _L.f * 2, method({ L: _L }, function() { pnd_draw_wash(L.w, L.h, L.f); }));
    _P.spr_a = pnd_image_to_sprite(_img);
    var _opt = { count: _P.count, seed: _P.seed };
    if (!is_undefined(_P.kinds)) _opt.kinds = _P.kinds;
    _P.job = pnd_make_begin(_img, _opt);
    return _P;
}

/// @function pnd__ready(puzzle)
/// @description Internal. The differences are made: the second painting, the rings, the ending plaque - then play.
function pnd__ready(_P) {
    var _J = _P.job;
    if (array_length(_J.changes) == 0 && !is_undefined(_P.kinds) && !_P.fallback) {
        // the kinds the game allows found nothing to change on THIS picture: a puzzle with no differences could never be
        // won, so it gets all four kinds instead (MZ edition), and the result says so
        show_debug_message("Pendant: the allowed kinds of change found nothing to change on this picture; using all four.");
        pnd_make_free(_J); _P.fallback = true;
        _P.job = pnd_make_begin(_P.img, { count: _P.count, seed: _P.seed });
        return;
    }
    if (array_length(_J.changes) == 0) {
        show_debug_message("Pendant: no visible difference could be made on this picture.");
        _P.state = "closed";
        _P.result = { refused: true, allFound: false, timedOut: false, gaveUp: false, found: 0, count: 0, misses: 0, hints: 0, seconds: 0, seed: _P.seed, key: _P.key, fallback: _P.fallback };
        return;
    }
    _P.changes = _J.changes;
    _P.found = array_create(array_length(_P.changes), false);
    _P.ring_age = array_create(array_length(_P.changes), 0);
    _P.spr_b = pnd_image_to_sprite(_J.out);
    pnd_make_free(_J);
    var _S = _P.S, _lw = max(1.6, 2.2 * _S);
    for (var _i = 0; _i < array_length(_P.changes); _i++) {
        var _ch = _P.changes[_i], _rr = max(9 * _S, (_ch.r + 4) * _P.sc), _pad = ceil(_rr * 0.35 + 4), _sz = ceil(_rr * 2 + _pad * 2);
        array_push(_P.rings, pnd__bake(_sz, _sz, method({ c: _sz / 2, r: _rr, ph: _i * 1.7 + 0.4, lw: _lw }, function() { pnd_draw_ring(c, c, r, ph, lw, false); })));
        array_push(_P.ghosts, pnd__bake(_sz, _sz, method({ c: _sz / 2, r: _rr, ph: _i * 1.7 + 0.4, lw: _lw }, function() { pnd_draw_ring(c, c, r, ph, lw, true); })));
    }
    _P.state = "play";
}

/// @function pnd__to_work(puzzle, x, y)
/// @description Internal. Which painting (0, 1) and which work-image point a gallery point falls on; undefined on the wall.
function pnd__to_work(_P, _x, _y) {
    var _L = _P.L, _k = _P.img.w / _L.w;
    if (_x >= _L.ax && _y >= _L.ay && _x < _L.ax + _L.w && _y < _L.ay + _L.h) return [0, (_x - _L.ax) * _k, (_y - _L.ay) * _k];
    if (_x >= _L.bx && _y >= _L.by && _x < _L.bx + _L.w && _y < _L.by + _L.h) return [1, (_x - _L.bx) * _k, (_y - _L.by) * _k];
    return undefined;
}

/// @function pnd_mark(puzzle, x, y)
/// @description Mark the gallery point (x, y): a find (ringed on both paintings), a repeat of a find (nothing), a miss (a
/// fading tick), or the wall (nothing). Returns "find", "repeat", "miss" or "none".
/// @returns {String}
function pnd_mark(_P, _x, _y) {
    if (!is_struct(_P) || !variable_struct_exists(_P, "state") || _P.state != "play" || !is_numeric(_x) || !is_numeric(_y)) return "none";
    var _w = pnd__to_work(_P, _x, _y);
    if (is_undefined(_w)) return "none";
    var _i = pnd_hit(_P.changes, _w[1], _w[2]);
    if (_i >= 0 && _P.found[_i]) return "repeat";
    if (_i >= 0) {
        _P.found[_i] = true; _P.found_n++; _P.ring_age[_i] = 1;
        if (_P.hint_age >= 0 && _P.hint_idx == _i) _P.hint_age = -1;
        pnd__sound(_P, "find");
        if (_P.found_n == array_length(_P.changes)) pnd__finish(_P, true, false);
        return "find";
    }
    _P.misses++;
    array_push(_P.miss_list, { x: _x, y: _y, a: 1, k: 1.3 });
    if (array_length(_P.miss_list) > 4) array_delete(_P.miss_list, 0, 1);
    pnd__sound(_P, "miss");
    return "miss";
}

/// @function pnd_hint(puzzle)
/// @description Spend a hint: a lamp glow settles over the first difference not yet found, on both paintings, for about
/// three seconds. Returns true when a hint was shown (false: none left, one already showing, or nothing left to find).
/// @returns {Bool}
function pnd_hint(_P) {
    if (!is_struct(_P) || !variable_struct_exists(_P, "state") || _P.state != "play" || _P.hints_used >= _P.hints || _P.hint_age >= 0) return false;
    var _i = 0;
    while (_i < array_length(_P.found) && _P.found[_i]) _i++;
    if (_i >= array_length(_P.found)) return false;
    _P.hints_used++; _P.hint_idx = _i; _P.hint_age = 0;
    pnd__sound(_P, "hint");
    return true;
}

/// @function pnd_give_up(puzzle)
/// @description Set the puzzle aside: the plaque says SET ASIDE and every difference left is marked with a dashed ring.
function pnd_give_up(_P) { if (is_struct(_P) && variable_struct_exists(_P, "state") && _P.state == "play") { _P.gave_up = true; pnd__finish(_P, false, false); pnd__sound(_P, "giveup"); } }

/// @function pnd__finish(puzzle, all_found, timed_out)
/// @description Internal. The ending, once: the result written, the unfound differences revealed.
function pnd__finish(_P, _all, _timed) {
    if (_P.state != "play") return;
    _P.state = "done"; _P.done_age = 0; _P.all_found = _all; _P.timed_out = _timed; _P.hint_age = -1;
    var _secs = floor(_P.elapsed_us / 1000000);
    _P.result = { refused: false, allFound: _all, timedOut: _timed, gaveUp: _P.gave_up, found: _P.found_n, count: array_length(_P.changes), misses: _P.misses, hints: _P.hints_used, seconds: _secs, seed: _P.seed, key: _P.key, fallback: _P.fallback };
    for (var _i = 0; _i < array_length(_P.found); _i++) if (!_P.found[_i]) _P.ring_age[_i] = 1;
    _P.spr_end = pnd__bake(_P.end_w, _P.end_h, method({ P: _P }, function() { pnd_draw_end_plaque_base(0, 0, P.end_w, P.end_h, P.S, P.all_found); }));
    if (_all) pnd__sound(_P, "solve"); else if (_timed) pnd__sound(_P, "time");
}

/// @function pnd_step(puzzle, [mouse_x], [mouse_y])
/// @description One step: making the differences (until they are made), then the hand, the clicks, the keys, the hint, the
/// clock and the ending. Pass your own mouse position (in the coordinates you draw the gallery in, before its scale) if you
/// do not draw it in the GUI layer. puzzle.inject (one step of scripted input, in gallery coordinates) takes the place of
/// the player for that step: { x, y, click }, { ok }, { hint }, { cancel }, { left, right, up, down, shift } or { dt_us }.
function pnd_step(_P, _mx = undefined, _my = undefined) {
    if (!is_struct(_P) || !variable_struct_exists(_P, "spr_static") || _P.state == "closed") return;
    if (_P.state == "making") { if (pnd_make_step(_P.job, _P.budget)) pnd__ready(_P); return; }
    var _in = _P.inject; _P.inject = undefined;
    var _dt = (is_struct(_in) && variable_struct_exists(_in, "dt_us")) ? _in.dt_us : (is_numeric(_P.dt_us) ? _P.dt_us : delta_time);
    for (var _i = 0; _i < array_length(_P.ring_age); _i++) if (_P.ring_age[_i] > 0 && _P.ring_age[_i] <= 14) _P.ring_age[_i]++;
    for (var _m = 0; _m < array_length(_P.miss_list); _m++) { var _ms = _P.miss_list[_m]; _ms.a = max(0, _ms.a - 9 / 255); _ms.k = max(1, _ms.k - 0.02); }
    if (_P.hint_age >= 0) { _P.hint_age++; if (_P.hint_age > 176) _P.hint_age = -1; }
    var _gx = is_numeric(_mx) ? _mx : (device_mouse_x_to_gui(0) - _P.draw_x) / _P.draw_k, _gy = is_numeric(_my) ? _my : (device_mouse_y_to_gui(0) - _P.draw_y) / _P.draw_k;
    var _click = false, _ok = false, _hintk = false, _cancel = false, _l = false, _rt = false, _u = false, _d = false, _shift = false;
    if (is_struct(_in)) {
        if (variable_struct_exists(_in, "x")) { _gx = _in.x; _gy = _in.y; }
        _click = pnd__req(_in, "click", false); _ok = pnd__req(_in, "ok", false); _hintk = pnd__req(_in, "hint", false); _cancel = pnd__req(_in, "cancel", false);
        _l = pnd__req(_in, "left", false); _rt = pnd__req(_in, "right", false); _u = pnd__req(_in, "up", false); _d = pnd__req(_in, "down", false); _shift = pnd__req(_in, "shift", false);
    } else {
        _click = mouse_check_button_pressed(mb_left); _cancel = mouse_check_button_pressed(mb_right) || keyboard_check_pressed(vk_escape);
        _ok = keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space) || keyboard_check_pressed(ord("Z"));
        _hintk = keyboard_check_pressed(ord("Q")) || keyboard_check_pressed(vk_pageup);
        _l = keyboard_check(vk_left); _rt = keyboard_check(vk_right); _u = keyboard_check(vk_up); _d = keyboard_check(vk_down); _shift = keyboard_check(vk_shift);
    }
    if (_P.state == "done") {
        _P.done_age++;
        _P.hand_on = false;
        if (_P.done_age > 40 && (_click || _ok || _cancel)) _P.state = "closed";
        return;
    }
    _P.frames++;
    _P.elapsed_us += _dt;
    if (_P.time > 0 && _P.elapsed_us >= _P.time * 1000000) { pnd__finish(_P, false, true); return; }
    var _dx = (_rt ? 1 : 0) - (_l ? 1 : 0), _dy = (_d ? 1 : 0) - (_u ? 1 : 0);
    if (_dx != 0 || _dy != 0) { var _sp = (_shift ? 9 : 4) * _P.S; _P.hand_on = true; _P.hand_x = clamp(_P.hand_x + _dx * _sp, 0, _P.W - 4); _P.hand_y = clamp(_P.hand_y + _dy * _sp, 0, _P.H - 4); }
    if (_ok) { _P.hand_on = true; pnd_mark(_P, _P.hand_x, _P.hand_y); }
    if (_P.state != "play") return;
    if (_hintk) pnd_hint(_P);
    if (_click) {
        if (_P.hud_on && _gx >= _P.hud_x && _gy >= _P.hud_y && _gx < _P.hud_x + _P.hud_w && _gy < _P.hud_y + _P.hud_h) pnd_hint(_P);
        else { _P.hand_on = false; pnd_mark(_P, _gx, _gy); }
    }
    if (_P.state == "play" && _cancel) pnd_give_up(_P);
}

/// @function pnd_closed(puzzle)
/// @description True once the player has left the gallery (or the picture could not be changed: result.refused).
/// @returns {Bool}
function pnd_closed(_P) { return !is_struct(_P) || !variable_struct_exists(_P, "state") || _P.state == "closed"; }

/// @function pnd__text(x, y, text, font, px, colour, alpha)
/// @description Internal. Centred text at a pixel size from a font atlas (filtered: a scaled-down atlas loses 1 px strokes
/// point-sampled, wing Doctrine_Craft s3).
function pnd__text(_x, _y, _t, _f, _px, _c, _a) {
    draw_set_font(_f); draw_set_halign(fa_center); draw_set_valign(fa_middle);
    var _k = _px / font_get_size(_f);
    draw_text_transformed_colour(_x, _y, _t, _k, _k, 0, _c, _c, _c, _c, _a);
}

/// @function pnd__engraved(x, y, text, font, px, dark, alpha)
/// @description Internal. Engraved type: a pale lower lip one pixel down, the dark cut over it.
function pnd__engraved(_x, _y, _t, _f, _px, _dark, _a) {
    pnd__text(_x, _y + 1, _t, _f, _px, make_colour_rgb(255, 240, 200), 0.55 * _a);
    pnd__text(_x, _y, _t, _f, _px, _dark, _a);
}

/// @function pnd__clock(seconds)
function pnd__clock(_s) { _s = max(0, floor(_s)); return string(_s div 60) + ":" + ((_s mod 60) < 10 ? "0" : "") + string(_s mod 60); }

/// @function pnd_draw(puzzle, [x], [y], [scale])
/// @description Draw the gallery with its top-left at (x, y) at a scale (default 0, 0, 1). The mouse is read relative to
/// where it was last drawn. Never changes the caller's blend, filter, font, alignment or matrix.
function pnd_draw(_P, _x = 0, _y = 0, _k = 1) {
    if (!is_struct(_P) || !variable_struct_exists(_P, "spr_static") || _P.state == "closed" || !sprite_exists(_P.spr_static)) return;
    if (!pnd__ok(_x)) _x = 0; if (!pnd__ok(_y)) _y = 0; if (!pnd__ok(_k) || _k <= 0) _k = 1;
    _P.draw_x = _x; _P.draw_y = _y; _P.draw_k = _k;
    var _mw = matrix_get(matrix_world), _font = draw_get_font(), _ha = draw_get_halign(), _va = draw_get_valign();
    matrix_set(matrix_world, matrix_multiply(matrix_build(_x, _y, 0, 0, 0, 0, _k, _k, 1), _mw));
    gpu_push_state();
    gpu_set_texfilter(true);
    gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    var _L = _P.L, _S = _P.S;
    draw_sprite(_P.spr_static, 0, 0, 0);
    draw_sprite_stretched(_P.spr_a, 0, _L.ax, _L.ay, _L.w, _L.h);
    if (sprite_exists(_P.spr_b)) draw_sprite_stretched(_P.spr_b, 0, _L.bx, _L.by, _L.w, _L.h);
    else pnd__drape(_P);
    pnd__draw_pm(_P.spr_wash, _L.ax - _L.f, _L.ay - _L.f, 1, 1);
    pnd__draw_pm(_P.spr_wash, _L.bx - _L.f, _L.by - _L.f, 1, 1);
    // rings: finds pop in (1.5 -> 1); at the ending the unfound settle in as dashed gold
    for (var _i = 0; _i < array_length(_P.changes); _i++) {
        var _age = _P.ring_age[_i];
        if (_age <= 0) continue;
        var _e = min(1, (_age - 1) / 13); _e = _e * _e * (3 - 2 * _e);
        var _ghost = !_P.found[_i], _spr = _ghost ? _P.ghosts[_i] : _P.rings[_i], _sc = _ghost ? 1.2 - 0.2 * _e : 1.5 - 0.5 * _e, _al = min(1, _e * 1.4);
        var _hw = sprite_get_width(_spr) / 2, _ch = _P.changes[_i];
        for (var _s = 0; _s < 2; _s++) {
            var _cx = (_s ? _L.bx : _L.ax) + _ch.x * _P.sc, _cy = (_s ? _L.by : _L.ay) + _ch.y * _P.sc;
            pnd__draw_pm(_spr, _cx - _hw * _sc, _cy - _hw * _sc, _sc, _al);
        }
    }
    for (var _m = 0; _m < array_length(_P.miss_list); _m++) { var _ms = _P.miss_list[_m]; if (_ms.a > 0) pnd_draw_miss(_ms.x, _ms.y, 26 * _S * _ms.k, _S, _ms.a); }
    if (_P.hint_age >= 0 && _P.hint_idx >= 0) {
        var _t = _P.hint_age, _op = (_t < 20) ? _t * 12 : ((_t > 150) ? max(0, 255 - (_t - 150) * 10) : 230 + round(25 * sin(_t * 0.12)));
        var _hc = _P.changes[_P.hint_idx], _want = max(36 * _S, (_hc.r + 30) * _P.sc * 2.4), _gr = _want / 2 * (1 + 0.6 * max(0, 1 - _t / 30));
        for (var _s2 = 0; _s2 < 2; _s2++) pnd_draw_hint_glow((_s2 ? _L.bx : _L.ax) + _hc.x * _P.sc, (_s2 ? _L.by : _L.ay) + _hc.y * _P.sc, _gr, clamp(_op / 255, 0, 1));
    }
    if (_P.hand_on && _P.state == "play") pnd_draw_hand(_P.hand_x, _P.hand_y, 1);
    // the plaque: FOUND, TIME (or TIME LEFT), MISSES, HINTS - or, while the differences are made, what is happening
    var _show_hud = !(_P.state == "done" && _P.end_over_hud && _P.done_age > 16);
    if (_show_hud) {
        pnd__draw_pm(_P.spr_hud, _P.hud_x, _P.hud_y, 1, 1);
        var _px = _P.hud_x, _py = _P.hud_y, _pw = _P.hud_w, _dark = make_colour_rgb(42, 26, 6);
        if (_P.state == "making") {
            pnd__engraved(_px + (_pw - 4) / 2, _py + round(16 * _S), "THE RESTORER IS AT WORK", fnt_pendant_display_s, round(12 * _S), _dark, 1);
            var _J = _P.job, _made = is_struct(_J) ? array_length(_J.changes) : 0;
            pnd__engraved(_px + (_pw - 4) / 2, _py + round(31 * _S), string(_made) + " of " + string(_P.count) + " changes painted", fnt_pendant_body_s, round(12 * _S), _dark, 0.85);
        } else {
            var _secs = floor(_P.elapsed_us / 1000000), _shown = (_P.time > 0) ? max(0, _P.time - _secs) : _secs;
            var _labels = ["FOUND", (_P.time > 0) ? "TIME LEFT" : "TIME", "MISSES", "HINTS"];
            var _vals = [string(_P.found_n) + " / " + string(array_length(_P.changes)), pnd__clock(_shown), string(_P.misses), string(_P.hints - _P.hints_used)];
            var _cw = floor((_pw - 4 - 40 * _S) / 4), _x0 = _px + round(20 * _S);
            for (var _c = 0; _c < 4; _c++) {
                var _cx2 = _x0 + _cw * _c + _cw / 2;
                pnd__engraved(_cx2, _py + round(13 * _S), _labels[_c], fnt_pendant_display_s, round(10 * _S), make_colour_rgb(44, 28, 8), 0.85);
                var _vc = (_c == 1 && _P.time > 0 && _shown <= 10) ? make_colour_rgb(106, 12, 8) : _dark;
                pnd__engraved(_cx2, _py + round(31 * _S), _vals[_c], fnt_pendant_display_s, round(18 * _S), _vc, 1);
            }
        }
    }
    if (_P.state == "done" && sprite_exists(_P.spr_end)) {
        var _ea = clamp((_P.done_age - 16) * 12 / 255, 0, 1);
        if (_ea > 0) {
            pnd__draw_pm(_P.spr_end, _P.end_x, _P.end_y, 1, _ea);
            var _ex = _P.end_x + _P.end_w / 2, _ey = _P.end_y, _r = _P.result, _tm = pnd__clock(_r.seconds);
            var _title = _P.all_found ? "A L L   F O U N D" : (_P.timed_out ? "T I M E" : "S E T   A S I D E");
            pnd__text(_ex, _ey + round(22 * _S), _title, fnt_pendant_display_l, round(23 * _S), make_colour_rgb(244, 224, 176), _ea);
            var _sub = _P.all_found ? (string(_r.count) + " differences  -  " + _tm + "  -  " + string(_r.misses) + ((_r.misses == 1) ? " miss" : " misses")) : (string(_r.found) + " of " + string(_r.count) + " found  -  " + _tm);
            pnd__text(_ex, _ey + round(49 * _S), _sub, fnt_pendant_body_s, round(16 * _S), make_colour_rgb(232, 212, 170), _ea);
            pnd__text(_ex, _ey + round(71 * _S), _P.all_found ? "OK to continue" : "the rest are marked  -  OK to continue", fnt_pendant_body_s, round(12 * _S), make_colour_rgb(232, 212, 170), 0.62 * _ea);
        }
    }
    gpu_pop_state();
    draw_set_font(_font); draw_set_halign(_ha); draw_set_valign(_va);
    matrix_set(matrix_world, _mw);
}

/// @function pnd__drape(puzzle)
/// @description Internal. While the differences are made, the second frame holds a velvet drape: vertical folds, lit from
/// the left, with a gold fringe.
function pnd__drape(_P) {
    var _L = _P.L, _n = max(5, round(_L.w / (34 * _P.S))), _fw = _L.w / _n, _deep = make_colour_rgb(58, 16, 22), _lit = make_colour_rgb(134, 40, 48), _mid = make_colour_rgb(92, 24, 32);
    for (var _i = 0; _i < _n; _i++) {
        var _x0 = _L.bx + _i * _fw, _xm = _x0 + _fw * 0.45, _x1 = _x0 + _fw;
        pnd__quad(_x0, _L.by, _x0, _L.by + _L.h, _xm, _L.by, _xm, _L.by + _L.h, _deep, 1, _deep, 1, _lit, 1, _lit, 1);
        pnd__quad(_xm, _L.by, _xm, _L.by + _L.h, _x1, _L.by, _x1, _L.by + _L.h, _lit, 1, _lit, 1, _mid, 1, _mid, 1);
    }
    var _gold = make_colour_rgb(214, 172, 92), _fy = _L.by + _L.h - 8 * _P.S;
    pnd__rect(_L.bx, _fy, _L.w, 3 * _P.S, _gold, 1);
    var _t = (_P.job.places_tried mod 40) / 40;
    for (var _k = 0; _k < _n * 3; _k++) { var _tx = _L.bx + (_k + 0.5) * _L.w / (_n * 3); pnd__stroke([_tx, _fy + 3 * _P.S, _tx + sin(_k + _t * 6.28) * _P.S, _L.by + _L.h], false, 1.2 * _P.S, _gold, 0.9); }
}

/// @function pnd_free(puzzle)
/// @description Free every sprite and image the puzzle made (in Step or Clean Up, never in a Draw event). Your own sprite or
/// surface is never touched. Safe twice.
function pnd_free(_P) {
    if (!is_struct(_P) || !variable_struct_exists(_P, "spr_static")) return;
    var _sp = [_P.spr_static, _P.spr_hud, _P.spr_a, _P.spr_b, _P.spr_wash, _P.spr_end];
    for (var _i = 0; _i < array_length(_sp); _i++) if (is_numeric(_sp[_i]) && _sp[_i] >= 0 && sprite_exists(_sp[_i])) sprite_delete(_sp[_i]);
    for (var _j = 0; _j < array_length(_P.rings); _j++) if (sprite_exists(_P.rings[_j])) sprite_delete(_P.rings[_j]);
    for (var _j2 = 0; _j2 < array_length(_P.ghosts); _j2++) if (sprite_exists(_P.ghosts[_j2])) sprite_delete(_P.ghosts[_j2]);
    _P.rings = []; _P.ghosts = []; _P.spr_static = -1; _P.spr_hud = -1; _P.spr_a = -1; _P.spr_b = -1; _P.spr_wash = -1; _P.spr_end = -1;
    if (is_struct(_P.job)) pnd_make_free(_P.job);
    pnd_image_free(_P.img);
    if (_P.state != "closed") _P.state = "closed";
}
