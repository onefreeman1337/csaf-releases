{
  "$GMScript": "v1",
  "%Name": "pnd_puzzle",
  "name": "pnd_puzzle",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}