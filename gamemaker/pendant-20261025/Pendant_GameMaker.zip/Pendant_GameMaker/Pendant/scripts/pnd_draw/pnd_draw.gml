/// pnd_draw.gml - Pendant's gallery, drawn by the package from primitives: a damask wall with a dado rail and wainscot,
/// a picture rail with cords and brass hooks, gilt frames with a lit moulding, beading and corner rosettes, picture lamps
/// and their warm wash, the brass plaque, hand-drawn ink rings, dashed reveal rings, a miss tick, a hint glow and a pointing
/// hand. No sprite, no texture, no shader: everything is vertices and the two fonts.
///
/// Pendant - Spot the Difference From Any Picture, for GameMaker. Copyright (c) 2026 Core Systems Asset Factory.
/// Licence: see LICENSE.txt.
///
/// Public functions (each documented below): pnd_walls, pnd_draw_wall, pnd_draw_frame, pnd_draw_hanging, pnd_draw_lamps,
/// pnd_draw_plaque_base, pnd_draw_ring, pnd_draw_miss, pnd_draw_hand. They draw onto whatever is the current target, in
/// its coordinates. The puzzle (pnd_puzzle) bakes the static ones once, so a frame of play costs a handful of sprites.

/// @function pnd_walls()
/// @description The gallery walls: name -> [base, damask, wainscot] colours (as [r, g, b]).
/// @returns {Struct}
function pnd_walls() {
    static _w = { green: [[30, 50, 42], [40, 64, 54], [44, 30, 22]], plum: [[52, 30, 44], [66, 40, 56], [40, 26, 22]], navy: [[24, 34, 56], [34, 46, 72], [38, 28, 22]], oxblood: [[66, 24, 24], [82, 34, 32], [36, 24, 18]] };
    return _w;
}

/// @function pnd__rgb(arr, [k])
/// @description Internal. A colour from [r, g, b], each channel times k (default 1) and capped at 255.
function pnd__rgb(_a, _k = 1) { return make_colour_rgb(min(255, round(_a[0] * _k)), min(255, round(_a[1] * _k)), min(255, round(_a[2] * _k))); }

/// @function pnd__hex(text)
/// @description Internal. A colour from "#rrggbb".
function pnd__hex(_s) {
    var _v = real("0x" + string_copy(_s, 2, 6));
    return make_colour_rgb((_v >> 16) & 255, (_v >> 8) & 255, _v & 255);
}

/// @function pnd__quad(x0, y0, x1, y1, x2, y2, x3, y3, c0, a0, c1, a1, c2, a2, c3, a3)
/// @description Internal. A quad as a strip (0-1 one edge, 2-3 the other: 0 and 2 at one end), each corner its own colour.
function pnd__quad(_x0, _y0, _x1, _y1, _x2, _y2, _x3, _y3, _c0, _a0, _c1, _a1, _c2, _a2, _c3, _a3) {
    draw_primitive_begin(pr_trianglestrip);
    draw_vertex_colour(_x0, _y0, _c0, _a0); draw_vertex_colour(_x1, _y1, _c1, _a1);
    draw_vertex_colour(_x2, _y2, _c2, _a2); draw_vertex_colour(_x3, _y3, _c3, _a3);
    draw_primitive_end();
}

/// @function pnd__rect(x, y, w, h, colour, alpha)
function pnd__rect(_x, _y, _w, _h, _c, _a) { pnd__quad(_x, _y, _x, _y + _h, _x + _w, _y, _x + _w, _y + _h, _c, _a, _c, _a, _c, _a, _c, _a); }

/// @function pnd__vband(x, y, w, h, stops)
/// @description Internal. A vertical gradient band: stops [[t, colour, alpha], ...] from top (t 0) to bottom (t 1).
function pnd__vband(_x, _y, _w, _h, _stops) {
    for (var _i = 0; _i < array_length(_stops) - 1; _i++) {
        var _s0 = _stops[_i], _s1 = _stops[_i + 1], _ya = _y + _h * _s0[0], _yb = _y + _h * _s1[0];
        pnd__quad(_x, _ya, _x + _w, _ya, _x, _yb, _x + _w, _yb, _s0[1], _s0[2], _s0[1], _s0[2], _s1[1], _s1[2], _s1[1], _s1[2]);
    }
}

/// @function pnd__disc(cx, cy, r, colour, alpha, [segments])
function pnd__disc(_cx, _cy, _r, _c, _a, _n = 0) {
    if (_n <= 0) _n = clamp(ceil(_r * 1.2), 12, 72);
    draw_primitive_begin(pr_trianglefan);
    draw_vertex_colour(_cx, _cy, _c, _a);
    for (var _i = 0; _i <= _n; _i++) { var _t = _i / _n * 2 * pi; draw_vertex_colour(_cx + cos(_t) * _r, _cy + sin(_t) * _r, _c, _a); }
    draw_primitive_end();
}

/// @function pnd__radial(cx, cy, r, stops, [segments], [sx], [sy])
/// @description Internal. A radial gradient: stops [[t, colour, alpha], ...] from the centre (t 0) to the rim (t 1), as rings
/// with per-vertex colour (exact at every stop, linear between). sx / sy stretch it into an ellipse.
function pnd__radial(_cx, _cy, _r, _stops, _n = 0, _sx = 1, _sy = 1) {
    if (_n <= 0) _n = clamp(ceil(_r * 0.9), 16, 96);
    for (var _i = 0; _i < array_length(_stops) - 1; _i++) {
        var _s0 = _stops[_i], _s1 = _stops[_i + 1], _r0 = _r * _s0[0], _r1 = _r * _s1[0];
        if (_r1 <= _r0) continue;
        draw_primitive_begin(pr_trianglestrip);
        for (var _k = 0; _k <= _n; _k++) {
            var _t = _k / _n * 2 * pi, _c = cos(_t), _s = sin(_t);
            draw_vertex_colour(_cx + _c * _r0 * _sx, _cy + _s * _r0 * _sy, _s0[1], _s0[2]);
            draw_vertex_colour(_cx + _c * _r1 * _sx, _cy + _s * _r1 * _sy, _s1[1], _s1[2]);
        }
        draw_primitive_end();
    }
}

/// @function pnd__ellipse(cx, cy, rx, ry, angle, colour, alpha)
function pnd__ellipse(_cx, _cy, _rx, _ry, _ang, _c, _a) {
    var _n = clamp(ceil(max(_rx, _ry) * 1.2), 12, 48), _ca = cos(_ang), _sa = sin(_ang);
    draw_primitive_begin(pr_trianglefan);
    draw_vertex_colour(_cx, _cy, _c, _a);
    for (var _i = 0; _i <= _n; _i++) { var _t = _i / _n * 2 * pi, _x = cos(_t) * _rx, _y = sin(_t) * _ry; draw_vertex_colour(_cx + _x * _ca - _y * _sa, _cy + _x * _sa + _y * _ca, _c, _a); }
    draw_primitive_end();
}

/// @function pnd__poly(points, colour, alpha)
/// @description Internal. A CONVEX polygon (flat [x0, y0, x1, y1, ...]) filled as a fan from its first point.
function pnd__poly(_p, _c, _a) {
    draw_primitive_begin(pr_trianglefan);
    for (var _i = 0; _i < array_length(_p); _i += 2) draw_vertex_colour(_p[_i], _p[_i + 1], _c, _a);
    draw_primitive_end();
}

/// @function pnd__stroke(points, closed, width, colour, alpha)
/// @description Internal. A polyline (flat [x0, y0, ...]) stroked as ONE triangle strip with mitred joins (capped at 2x the
/// half-width) and round ends, so a translucent line neither gaps nor darkens at its joints (wing Doctrine_Craft s3, s18).
function pnd__stroke(_p, _closed, _w, _c, _a) {
    var _n = array_length(_p) div 2;
    if (_n < 2) return;
    var _hw = _w / 2;
    draw_primitive_begin(pr_trianglestrip);
    var _cnt = _closed ? _n + 1 : _n;
    for (var _i = 0; _i < _cnt; _i++) {
        var _k = _i mod _n;
        var _kp = _closed ? ((_k - 1 + _n) mod _n) : max(0, _k - 1), _kn = _closed ? ((_k + 1) mod _n) : min(_n - 1, _k + 1);
        var _dx0 = _p[_k * 2] - _p[_kp * 2], _dy0 = _p[_k * 2 + 1] - _p[_kp * 2 + 1], _dx1 = _p[_kn * 2] - _p[_k * 2], _dy1 = _p[_kn * 2 + 1] - _p[_k * 2 + 1];
        var _l0 = sqrt(_dx0 * _dx0 + _dy0 * _dy0), _l1 = sqrt(_dx1 * _dx1 + _dy1 * _dy1);
        if (_l0 > 0) { _dx0 /= _l0; _dy0 /= _l0; } if (_l1 > 0) { _dx1 /= _l1; _dy1 /= _l1; }
        if (_l0 == 0) { _dx0 = _dx1; _dy0 = _dy1; } if (_l1 == 0) { _dx1 = _dx0; _dy1 = _dy0; }
        var _nx = -(_dy0 + _dy1), _ny = _dx0 + _dx1, _nl = sqrt(_nx * _nx + _ny * _ny);
        if (_nl < 0.0001) { _nx = -_dy0; _ny = _dx0; _nl = 1; }
        _nx /= _nl; _ny /= _nl;
        var _dot = _nx * -_dy0 + _ny * _dx0, _m = _hw / max(0.5, _dot);
        draw_vertex_colour(_p[_k * 2] + _nx * _m, _p[_k * 2 + 1] + _ny * _m, _c, _a);
        draw_vertex_colour(_p[_k * 2] - _nx * _m, _p[_k * 2 + 1] - _ny * _m, _c, _a);
    }
    draw_primitive_end();
    if (!_closed && _hw > 1) { pnd__disc(_p[0], _p[1], _hw, _c, _a); pnd__disc(_p[(_n - 1) * 2], _p[(_n - 1) * 2 + 1], _hw, _c, _a); }
}

/// @function pnd__rrect_points(x, y, w, h, r)
/// @description Internal. A rounded rectangle's outline as points (clockwise from the top-left corner's end).
function pnd__rrect_points(_x, _y, _w, _h, _r) {
    _r = min(_r, _w / 2, _h / 2);
    var _p = [], _c = [[_x + _w - _r, _y + _r, -pi / 2], [_x + _w - _r, _y + _h - _r, 0], [_x + _r, _y + _h - _r, pi / 2], [_x + _r, _y + _r, pi]];
    for (var _i = 0; _i < 4; _i++) for (var _k = 0; _k <= 6; _k++) { var _t = _c[_i][2] + _k / 6 * pi / 2; array_push(_p, _c[_i][0] + cos(_t) * _r, _c[_i][1] + sin(_t) * _r); }
    return _p;
}

/// @function pnd__rrect_fill(x, y, w, h, r, stops)
/// @description Internal. A rounded rectangle filled with a vertical gradient (stops as pnd__vband), in 1 px slices whose
/// ends follow the corners.
function pnd__rrect_fill(_x, _y, _w, _h, _r, _stops) {
    _r = min(_r, _w / 2, _h / 2);
    var _n = max(2, ceil(_h));
    for (var _i = 0; _i < _n; _i++) {
        var _ya = _y + _h * _i / _n, _yb = _y + _h * (_i + 1) / _n, _ym = (_ya + _yb) / 2, _t = (_ym - _y) / _h, _in = 0;
        if (_ym < _y + _r) { var _d = _y + _r - _ym; _in = _r - sqrt(max(0, _r * _r - _d * _d)); }
        else if (_ym > _y + _h - _r) { var _d2 = _ym - (_y + _h - _r); _in = _r - sqrt(max(0, _r * _r - _d2 * _d2)); }
        var _k = 0; while (_k < array_length(_stops) - 2 && _t > _stops[_k + 1][0]) _k++;
        var _s0 = _stops[_k], _s1 = _stops[min(_k + 1, array_length(_stops) - 1)], _f = (_s1[0] > _s0[0]) ? clamp((_t - _s0[0]) / (_s1[0] - _s0[0]), 0, 1) : 0;
        var _col = merge_colour(_s0[1], _s1[1], _f), _al = lerp(_s0[2], _s1[2], _f);
        pnd__rect(_x + _in, _ya, _w - _in * 2, _yb - _ya, _col, _al);
    }
}

/// @function pnd__quadratic(points, x0, y0, cx, cy, x1, y1, steps)
/// @description Internal. Append a quadratic curve's points (after its start) to a flat array.
function pnd__quadratic(_p, _x0, _y0, _cx, _cy, _x1, _y1, _n) {
    for (var _i = 1; _i <= _n; _i++) { var _t = _i / _n, _u = 1 - _t; array_push(_p, _u * _u * _x0 + 2 * _u * _t * _cx + _t * _t * _x1, _u * _u * _y0 + 2 * _u * _t * _cy + _t * _t * _y1); }
}

/// @function pnd_draw_wall(w, h, S, wall)
/// @description Draw the gallery wall: a damask lattice of four-petal motifs (pitch from the screen, not a count), a dado
/// rail, a panelled wainscot, and a vignette darkening the corners. wall: a name from pnd_walls() or [base, damask,
/// wainscot] colours. S is the type and ornament scale (pnd_ui_scale).
function pnd_draw_wall(_W, _H, _S, _wall) {
    if (!pnd__ok(_W) || !pnd__ok(_H) || !pnd__ok(_S) || _W < 1 || _H < 1 || _S <= 0) return;
    _W = min(_W, 8192); _H = min(_H, 8192); _S = clamp(_S, 0.25, 8);
    var _walls = pnd_walls(), _col = is_array(_wall) ? _wall : (variable_struct_exists(_walls, string(_wall)) ? variable_struct_get(_walls, string(_wall)) : _walls.green);
    var _b = _col[0], _d = _col[1], _wn = _col[2], _dado = round(_H * 0.86);
    pnd__rect(0, 0, _W, _H, pnd__rgb(_b), 1);
    var _p = round(34 * _S), _dc = pnd__rgb(_d);
    var _row = 0;
    for (var _y = -_p; _y < _dado + _p; _y += _p * 0.86) {
        for (var _x = (_row mod 2) * _p / 2 - _p; _x < _W + _p; _x += _p) {
            for (var _q = 0; _q < 4; _q++) {
                var _a = _q * pi / 2, _pts = [_x, _y];
                pnd__quadratic(_pts, _x, _y, _x + cos(_a + 0.5) * _p * 0.26, _y + sin(_a + 0.5) * _p * 0.26, _x + cos(_a) * _p * 0.22, _y + sin(_a) * _p * 0.22, 5);
                var _ex = _x + cos(_a) * _p * 0.22, _ey = _y + sin(_a) * _p * 0.22;
                pnd__quadratic(_pts, _ex, _ey, _x + cos(_a - 0.5) * _p * 0.26, _y + sin(_a - 0.5) * _p * 0.26, _x, _y, 5);
                // clipped to the wall above the rail: drawn whole, the motifs on the right edge ran past the box a caller
                // gave (the buyer render of pnd_draw_wall(640, 360), 2026-10-25)
                var _cl = pnd__clip_box(_pts, 0, 0, _W, _dado);
                if (array_length(_cl) >= 6) pnd__poly(_cl, _dc, 1);
            }
            var _dx0 = max(0, _x + _p / 2 - 1), _dy0 = max(0, _y + _p * 0.43 - 1), _dx1 = min(_W, _x + _p / 2 + 1), _dy1 = min(_dado, _y + _p * 0.43 + 1);
            if (_dx1 > _dx0 && _dy1 > _dy0) pnd__rect(_dx0, _dy0, _dx1 - _dx0, _dy1 - _dy0, _dc, 1);
        }
        _row++;
    }
    pnd__rect(0, _dado, _W, _H - _dado, pnd__rgb(_wn), 1);
    var _pn = round(120 * _S);
    // whole panels only: the last of them ends inside the box (a partial panel overhung the right edge)
    for (var _px = round((_W mod _pn) / 2); _px + _pn <= _W; _px += _pn) {
        pnd__stroke(pnd__rrect_points(_px + 8, _dado + 10 * _S, _pn - 16, _H - _dado - 18 * _S, 0.01), true, 2, c_black, 0.35);
        pnd__stroke(pnd__rrect_points(_px + 9.5, _dado + 11.5 * _S, _pn - 19, _H - _dado - 21 * _S, 0.01), true, 1, make_colour_rgb(255, 220, 170), 0.08);
    }
    pnd__vband(0, _dado - 5 * _S, _W, 10 * _S, [[0, pnd__hex("#6b4a2c"), 1], [0.45, pnd__hex("#9a7044"), 1], [1, pnd__hex("#3a2615"), 1]]);
    // the vignette as a grid of quads INSIDE the box, each corner's alpha read off the radial ramp (as rings it reached 0.75
    // of the long side from the centre and darkened a disc outside the box a caller gave)
    var _vx = _W / 2, _vy = _H * 0.42, _r0 = min(_W, _H) * 0.25, _r1 = max(_W, _H) * 0.75, _gx = 24, _gy = 16;
    for (var _j = 0; _j < _gy; _j++) for (var _i = 0; _i < _gx; _i++) {
        var _x0 = _W * _i / _gx, _x1 = _W * (_i + 1) / _gx, _y0 = _H * _j / _gy, _y1 = _H * (_j + 1) / _gy;
        pnd__quad(_x0, _y0, _x1, _y0, _x0, _y1, _x1, _y1, c_black, pnd__vig(_x0, _y0, _vx, _vy, _r0, _r1), c_black, pnd__vig(_x1, _y0, _vx, _vy, _r0, _r1), c_black, pnd__vig(_x0, _y1, _vx, _vy, _r0, _r1), c_black, pnd__vig(_x1, _y1, _vx, _vy, _r0, _r1));
    }
}

/// @function pnd__vig(x, y, cx, cy, r0, r1)
/// @description Internal. The wall vignette's darkness at a point: 0 inside r0, rising to 0.55 at r1.
function pnd__vig(_x, _y, _cx, _cy, _r0, _r1) { var _d = point_distance(_x, _y, _cx, _cy); return 0.55 * clamp((_d - _r0) / max(1, _r1 - _r0), 0, 1); }

/// @function pnd__clip_box(points, x0, y0, x1, y1)
/// @description Internal. A CONVEX polygon (flat [x0, y0, ...]) clipped to a box (Sutherland-Hodgman, four edges).
/// @returns {Array<Real>} the clipped polygon (empty when nothing is left)
function pnd__clip_box(_p, _bx0, _by0, _bx1, _by1) {
    var _cur = _p;
    for (var _e = 0; _e < 4; _e++) {
        var _out = [], _n = array_length(_cur) div 2;
        if (_n == 0) break;
        for (var _i = 0; _i < _n; _i++) {
            var _ax = _cur[_i * 2], _ay = _cur[_i * 2 + 1], _k = (_i + 1) mod _n, _bx = _cur[_k * 2], _by = _cur[_k * 2 + 1];
            var _da = (_e == 0) ? _ax - _bx0 : ((_e == 1) ? _bx1 - _ax : ((_e == 2) ? _ay - _by0 : _by1 - _ay));
            var _db = (_e == 0) ? _bx - _bx0 : ((_e == 1) ? _bx1 - _bx : ((_e == 2) ? _by - _by0 : _by1 - _by));
            if (_da >= 0) array_push(_out, _ax, _ay);
            if ((_da >= 0) != (_db >= 0)) { var _t = _da / (_da - _db); array_push(_out, _ax + (_bx - _ax) * _t, _ay + (_by - _ay) * _t); }
        }
        _cur = _out;
    }
    return _cur;
}

/// @function pnd_draw_hanging(layout, S, W)
/// @description Draw the picture rail across the top and two cords per painting meeting at a brass hook (the lower painting
/// of a stacked pair hangs from the upper frame's foot). layout: the struct pnd_layout returns. With rail false there is no
/// rail: each painting hangs from its own hook a short way above its frame (the demo's chooser, where long cords crossed
/// the title).
function pnd_draw_hanging(_L, _S, _W, _rail = true) {
    var _ry = round(14 * _S);
    if (_rail) pnd__vband(0, _ry - 5 * _S, _W, 10 * _S, [[0, pnd__hex("#2a1a0e"), 1], [0.4, pnd__hex("#8a6236"), 1], [1, pnd__hex("#24160b"), 1]]);
    var _boxes = [[_L.ax, _L.ay], [_L.bx, _L.by]];
    for (var _i = 0; _i < 2; _i++) {
        var _fx = _boxes[_i][0] - _L.f, _fy = _boxes[_i][1] - _L.f, _fw = _L.w + _L.f * 2, _hx = _fx + _fw / 2;
        var _hy = (_L.stacked && _i == 1) ? _L.ay + _L.h + _L.f : (_rail ? _ry : _fy - round(26 * _S));
        for (var _s = -1; _s <= 1; _s += 2) {
            var _ex = _hx + _s * _fw * 0.32, _ey = _fy + _L.f * 0.3;
            pnd__stroke([_hx + 2, _hy + 3, _ex + 2, _ey + 3], false, 2.6 * _S, c_black, 0.35);
            pnd__stroke([_hx, _hy, _ex, _ey], false, 1.6 * _S, pnd__hex("#b89254"), 1);
            pnd__stroke([_hx - 0.6, _hy, _ex - 0.6, _ey], false, 0.7 * _S, make_colour_rgb(255, 240, 200), 0.45);
        }
        pnd__radial(_hx, _hy, 5 * _S, [[0, pnd__hex("#fff2c8"), 1], [0.5, pnd__hex("#c9a052"), 1], [0.9, pnd__hex("#5a3c14"), 1], [1, pnd__hex("#5a3c14"), 0]], 24);
    }
}

/// @function pnd_draw_frame(x, y, w, h, f, S)
/// @description Draw a gilt frame round the picture area (x, y, w, h), f wide: a cast shadow, four mitred sides each shaded
/// by which way it faces the light (upper left) through a moulding profile (dark step, bright round, hollow, bright
/// fillet), a beaded band in the hollow whose bead count is DERIVED from each run, corner rosettes, and a dark sight edge
/// with a thin gold fillet. The picture is drawn into (x, y, w, h) afterwards.
function pnd_draw_frame(_x, _y, _w, _h, _f, _S) {
    if (!pnd__ok(_x) || !pnd__ok(_y) || !pnd__ok(_w) || !pnd__ok(_h) || !pnd__ok(_f) || !pnd__ok(_S) || _w < 1 || _h < 1 || _f < 1 || _S <= 0) return;
    _w = min(_w, 8192); _h = min(_h, 8192); _f = min(_f, 512); _S = clamp(_S, 0.25, 8);
    var _X0 = _x - _f, _Y0 = _y - _f, _X1 = _x + _w + _f, _Y1 = _y + _h + _f;
    pnd__rect(_X0 + 4 * _S, _Y0 + 6 * _S, _X1 - _X0, _Y1 - _Y0, c_black, 0.45);
    static _prof = [[0, [60, 40, 16]], [0.1, [150, 108, 44]], [0.28, [238, 200, 120]], [0.45, [176, 128, 52]], [0.62, [96, 66, 26]], [0.78, [214, 172, 92]], [0.9, [120, 84, 34]], [1, [40, 26, 10]]];
    // each side: its two outer corners, the inward direction at each (towards the inner corners), and its light factor
    var _sides = [[_X0, _Y0, _X1, _Y0, 1, 1, -1, 1, 1.18], [_X1, _Y0, _X1, _Y1, -1, 1, -1, -1, 0.78], [_X1, _Y1, _X0, _Y1, -1, -1, 1, -1, 0.66], [_X0, _Y1, _X0, _Y0, 1, -1, 1, 1, 1.04]];
    for (var _s = 0; _s < 4; _s++) {
        var _q = _sides[_s], _k = _q[8];
        for (var _i = 0; _i < array_length(_prof) - 1; _i++) {
            var _t0 = _prof[_i][0] * _f, _t1 = _prof[_i + 1][0] * _f, _c0 = pnd__rgb(_prof[_i][1], _k), _c1 = pnd__rgb(_prof[_i + 1][1], _k);
            pnd__quad(_q[0] + _q[4] * _t0, _q[1] + _q[5] * _t0, _q[2] + _q[6] * _t0, _q[3] + _q[7] * _t0,
                      _q[0] + _q[4] * _t1, _q[1] + _q[5] * _t1, _q[2] + _q[6] * _t1, _q[3] + _q[7] * _t1, _c0, 1, _c0, 1, _c1, 1, _c1, 1);
        }
    }
    // the beaded band: pitch = bead width, count derived from the real run
    var _bd = max(2.2 * _S, _f * 0.13), _off = _f * 0.62, _pitch = _bd * 1.9;
    var _runs = [[_X0 + _off, _Y0 + _off, _X1 - _off, _Y0 + _off], [_X1 - _off, _Y0 + _off, _X1 - _off, _Y1 - _off], [_X1 - _off, _Y1 - _off, _X0 + _off, _Y1 - _off], [_X0 + _off, _Y1 - _off, _X0 + _off, _Y0 + _off]];
    var _bc = pnd__hex("#c49446"), _bdk = pnd__hex("#4a3010"), _bh = pnd__hex("#fff0c0");
    for (var _r = 0; _r < 4; _r++) {
        var _R = _runs[_r], _len = point_distance(_R[0], _R[1], _R[2], _R[3]), _n = max(2, floor(_len / _pitch)), _step = _len / _n, _ux = (_R[2] - _R[0]) / _len, _uy = (_R[3] - _R[1]) / _len;
        for (var _b = 0; _b < _n; _b++) {
            var _bx = _R[0] + _ux * (_b + 0.5) * _step, _by = _R[1] + _uy * (_b + 0.5) * _step;
            pnd__radial(_bx, _by, _bd * 0.5, [[0, _bc, 1], [0.6, _bc, 1], [1, _bdk, 1]], 12);
            pnd__disc(_bx - _bd * 0.14, _by - _bd * 0.14, _bd * 0.16, _bh, 0.85, 8);
        }
    }
    var _corners = [[_X0 + _off, _Y0 + _off], [_X1 - _off, _Y0 + _off], [_X1 - _off, _Y1 - _off], [_X0 + _off, _Y1 - _off]], _rose = pnd__hex("#d8b066");
    for (var _cn = 0; _cn < 4; _cn++) {
        var _cx = _corners[_cn][0], _cy = _corners[_cn][1], _rr = _f * 0.3;
        for (var _pt = 0; _pt < 4; _pt++) { var _a = _pt * pi / 2 + pi / 4; pnd__ellipse(_cx + cos(_a) * _rr * 0.45, _cy + sin(_a) * _rr * 0.45, _rr * 0.42, _rr * 0.22, _a, _rose, 1); }
        pnd__radial(_cx - _rr * 0.05, _cy - _rr * 0.05, _rr * 0.36, [[0, pnd__hex("#fff4cc"), 1], [1, pnd__hex("#8a5e20"), 1]], 16);
    }
    pnd__rect(_x - 3, _y - 3, _w + 6, _h + 6, pnd__hex("#1a1006"), 1);
    pnd__stroke(pnd__rrect_points(_x - 1.5, _y - 1.5, _w + 3, _h + 3, 0.01), true, 1, pnd__hex("#e2c27c"), 1);
}

/// @function pnd_draw_lamps(layout, S)
/// @description Draw each painting's lamp: a brass hood on a short arm above the frame, with its lit lip.
function pnd_draw_lamps(_L, _S) {
    var _boxes = [[_L.ax, _L.ay], [_L.bx, _L.by]];
    for (var _i = 0; _i < 2; _i++) {
        var _x = _boxes[_i][0], _y = _boxes[_i][1], _lx = _x + _L.w / 2, _ly = _y - _L.f - 9 * _S, _hw = min(_L.w * 0.22, 46 * _S);
        pnd__rect(_lx - _hw + 2, _ly - 4 * _S + 3, _hw * 2, 8 * _S, c_black, 0.4);
        var _top = pnd__hex("#f2d496"), _mid = pnd__hex("#a87a36"), _bot = pnd__hex("#4a3010");
        pnd__quad(_lx - _hw * 0.8, _ly - 4 * _S, _lx + _hw * 0.8, _ly - 4 * _S, _lx - _hw * 0.9, _ly, _lx + _hw * 0.9, _ly, _top, 1, _top, 1, _mid, 1, _mid, 1);
        pnd__quad(_lx - _hw * 0.9, _ly, _lx + _hw * 0.9, _ly, _lx - _hw, _ly + 4 * _S, _lx + _hw, _ly + 4 * _S, _mid, 1, _mid, 1, _bot, 1, _bot, 1);
        pnd__rect(_lx - _hw * 0.92, _ly + 3 * _S, _hw * 1.84, 1.4 * _S, make_colour_rgb(255, 240, 190), 0.9);
    }
}

/// @function pnd_draw_wash(w, h, f)
/// @description Draw a picture lamp's warm wash over a framed painting of picture size w x h and frame width f, in a box
/// (w + 2f) x (h + 2f) whose top-left is the frame's outer corner. Very soft: it warms the upper half.
function pnd_draw_wash(_w, _h, _f) {
    var _wc = make_colour_rgb(255, 226, 160);
    pnd__radial(_f + _w / 2, 0, max(_w, _h) * 0.9, [[0, _wc, 0.16], [0.5, _wc, 0.05], [1, _wc, 0]], 64);
}

/// @function pnd_draw_plaque_base(x, y, w, h, S)
/// @description Draw the brass plaque the counts are engraved on: a shadow, a brass gradient, an engraved inner border with
/// a lit lip, and four screws.
function pnd_draw_plaque_base(_x, _y, _w, _h, _S) {
    pnd__rrect_fill(_x + 3, _y + 4, _w - 3, _h - 3, 6 * _S, [[0, c_black, 0.45], [1, c_black, 0.45]]);
    pnd__rrect_fill(_x + 0.5, _y + 0.5, _w - 4, _h - 4, 6 * _S, [[0, pnd__hex("#d9b670"), 1], [0.18, pnd__hex("#b48a44"), 1], [0.55, pnd__hex("#8e6a2e"), 1], [1, pnd__hex("#5e4318"), 1]]);
    pnd__stroke(pnd__rrect_points(_x + 4.5 * _S, _y + 4.5 * _S, _w - 4 - 9 * _S, _h - 4 - 9 * _S, 4 * _S), true, 1, make_colour_rgb(60, 40, 12), 0.8);
    pnd__stroke(pnd__rrect_points(_x + 5.5 * _S, _y + 5.5 * _S, _w - 4 - 11 * _S, _h - 4 - 11 * _S, 3.5 * _S), true, 1, make_colour_rgb(255, 240, 200), 0.5);
    var _sx = [_x + 9 * _S, _x + _w - 13 * _S], _sy = [_y + 9 * _S, _y + _h - 13 * _S];
    for (var _i = 0; _i < 2; _i++) for (var _j = 0; _j < 2; _j++) {
        pnd__disc(_sx[_i], _sy[_j], 2.2 * _S, pnd__hex("#5a3e14"), 1, 12);
        pnd__stroke([_sx[_i] - 1.5 * _S, _sy[_j] + 1.5 * _S, _sx[_i] + 1.5 * _S, _sy[_j] - 1.5 * _S], false, 1, make_colour_rgb(255, 236, 190), 0.7);
    }
}

/// @function pnd_draw_end_plaque_base(x, y, w, h, S, all_found)
/// @description Draw the ending plaque's ground: a dark lacquer panel, a gold inner rule, and two ruled ornaments flanking
/// the title (set closer for ALL FOUND, which is shorter).
function pnd_draw_end_plaque_base(_x, _y, _w, _h, _S, _all) {
    pnd__rrect_fill(_x + 0.5, _y + 0.5, _w - 1, _h - 1, 9 * _S, [[0, make_colour_rgb(20, 12, 6), 0.9], [1, make_colour_rgb(20, 12, 6), 0.9]]);
    var _g = make_colour_rgb(232, 196, 120);
    pnd__stroke(pnd__rrect_points(_x + 4.5 * _S, _y + 4.5 * _S, _w - 9 * _S, _h - 9 * _S, 6 * _S), true, max(1, _S * 0.9), _g, 0.8);
    var _gap = (_all ? 104 : 118) * _S, _fy = _y + 22 * _S;
    for (var _s = -1; _s <= 1; _s += 2) {
        var _cx = _x + _w / 2 + _s * _gap;
        pnd__stroke([_cx, _fy, _cx + _s * 30 * _S, _fy], false, max(1, _S * 0.9), _g, 0.85);
        pnd__poly([_cx + _s * 36 * _S, _fy, _cx + _s * 32 * _S, _fy - 3 * _S, _cx + _s * 28 * _S, _fy, _cx + _s * 32 * _S, _fy + 3 * _S], _g, 0.85);
    }
}

/// @function pnd_ring_points(cx, cy, r, phase, pass, ghost)
/// @description The points of a hand-drawn ring: 65 points round an ellipse-ish loop whose reach wobbles with the angle;
/// the ink pass overshoots its start a little (a pen that does not quite close), the ghost does not.
/// @returns {Array<Real>} flat [x0, y0, ...]
function pnd_ring_points(_cx, _cy, _r, _ph, _pass, _ghost) {
    var _p = [], _a0 = _ph + _pass * 0.9, _span = pi * 2 + (_ghost ? 0 : 0.35);
    for (var _t = 0; _t <= 64; _t++) {
        var _a = _a0 + _span * _t / 64, _rr = _r * (1 + 0.06 * sin(_a * 2 + _ph) + 0.03 * sin(_a * 5 + _ph * 2) + _pass * 0.05);
        array_push(_p, _cx + cos(_a) * _rr * 1.06, _cy + sin(_a) * _rr * 0.96);
    }
    return _p;
}

/// @function pnd_draw_ring(cx, cy, r, phase, lw, ghost)
/// @description Draw a find's ink ring (two red strokes over a pale underlay, not quite closing) or, with ghost, the
/// dashed gold pencil ring that marks a difference the player did not find.
function pnd_draw_ring(_cx, _cy, _r, _ph, _lw, _ghost) {
    if (!pnd__ok(_cx) || !pnd__ok(_cy) || !pnd__ok(_r) || !pnd__ok(_ph) || !pnd__ok(_lw) || _r <= 0 || _lw <= 0) return;
    _r = min(_r, 4096); _lw = min(_lw, 64); _ghost = is_bool(_ghost) ? _ghost : (pnd__ok(_ghost) && _ghost > 0);
    if (_ghost) {
        var _p = pnd_ring_points(_cx, _cy, _r, _ph, 0, true), _n = array_length(_p) div 2, _len = 0;
        var _dash = _lw * 2.4, _gap = _lw * 2, _acc = 0, _on = true, _seg = [_p[0], _p[1]];
        var _dk = make_colour_rgb(30, 18, 6), _gd = pnd__hex("#f0c058");
        var _segs = [];
        for (var _i = 1; _i < _n; _i++) {
            var _x0 = _p[_i * 2 - 2], _y0 = _p[_i * 2 - 1], _x1 = _p[_i * 2], _y1 = _p[_i * 2 + 1], _d = point_distance(_x0, _y0, _x1, _y1), _u = 0;
            while (_d - _u > 0.0001) {
                var _lim = _on ? _dash : _gap, _take = min(_d - _u, _lim - _acc);
                _u += _take; _acc += _take;
                var _px = lerp(_x0, _x1, _u / _d), _py = lerp(_y0, _y1, _u / _d);
                if (_on) array_push(_seg, _px, _py);
                if (_acc >= _lim - 0.0001) { if (_on && array_length(_seg) >= 4) array_push(_segs, _seg); _on = !_on; _acc = 0; _seg = [_px, _py]; }
            }
        }
        if (_on && array_length(_seg) >= 4) array_push(_segs, _seg);
        for (var _k = 0; _k < array_length(_segs); _k++) pnd__stroke(_segs[_k], false, _lw * 2.2, _dk, 0.6);
        for (var _k2 = 0; _k2 < array_length(_segs); _k2++) pnd__stroke(_segs[_k2], false, _lw * 1.1, _gd, 1);
        return;
    }
    for (var _pass = 0; _pass < 2; _pass++) {
        var _pp = pnd_ring_points(_cx, _cy, _r, _ph, _pass, false);
        pnd__stroke(_pp, false, _lw * (_pass ? 1.6 : 2.4), make_colour_rgb(255, 246, 226), 0.75);
        pnd__stroke(_pp, false, _lw * (_pass ? 0.8 : 1.15), _pass ? make_colour_rgb(150, 20, 16) : pnd__hex("#b3201a"), _pass ? 0.85 : 1);
    }
}

/// @function pnd_draw_miss(cx, cy, s, S, alpha)
/// @description Draw a miss: a short pencil cross, dark with a light edge so it reads on any picture, s across.
function pnd_draw_miss(_cx, _cy, _s, _S, _a) {
    var _m = _s * 0.22;
    for (var _pass = 0; _pass < 2; _pass++) {
        var _c = _pass ? make_colour_rgb(60, 40, 30) : make_colour_rgb(255, 244, 224), _w = (_pass ? 2 : 4) * _S;
        pnd__stroke([_cx - _m, _cy - _m, _cx + _m, _cy + _m], false, _w, _c, _a * (_pass ? 0.95 : 0.85));
        pnd__stroke([_cx + _m, _cy - _m, _cx - _m, _cy + _m], false, _w, _c, _a * (_pass ? 0.95 : 0.85));
    }
}

/// @function pnd_draw_hint_glow(cx, cy, r, alpha)
/// @description Draw a hint's glow: a bright lamplit ring with a dark outer edge, so it reads on a pale sky and a dark wall
/// alike (the MZ edition's measured design), r its outer radius.
function pnd_draw_hint_glow(_cx, _cy, _r, _a) {
    if (!pnd__ok(_cx) || !pnd__ok(_cy) || !pnd__ok(_r) || !pnd__ok(_a) || _r <= 0) return;
    _r = min(_r, 4096); _a = clamp(_a, 0, 1);
    var _y1 = make_colour_rgb(255, 236, 170), _y2 = make_colour_rgb(255, 238, 170), _y3 = make_colour_rgb(255, 212, 110), _d = make_colour_rgb(70, 36, 4), _d2 = make_colour_rgb(40, 20, 0);
    pnd__radial(_cx, _cy, _r, [[0, _y1, 0], [0.6, _y1, 0.06 * _a], [0.7, _y2, 0.95 * _a], [0.78, _y3, 0.95 * _a], [0.84, _d, 0.6 * _a], [0.92, _d2, 0.18 * _a], [1, _d2, 0]], 64);
}

/// @function pnd_draw_hand(x, y, S)
/// @description Draw the keyboard player's pointing hand with its tip at (x, y).
function pnd_draw_hand(_x, _y, _S) {
    var _k = _S, _cream = make_colour_rgb(255, 240, 205), _ink = make_colour_rgb(40, 25, 10);
    var _head = [_x, _y, _x, _y + 20 * _k, _x + 14 * _k, _y + 14 * _k];
    var _tail = [_x + 6 * _k, _y + 12 * _k, _x + 11 * _k, _y + 10 * _k, _x + 17 * _k, _y + 22 * _k, _x + 12 * _k, _y + 24 * _k];
    pnd__poly(_head, _cream, 0.92); pnd__poly(_tail, _cream, 0.92);
    pnd__stroke([_x, _y, _x, _y + 20 * _k, _x + 6 * _k, _y + 15 * _k, _x + 12 * _k, _y + 24 * _k, _x + 17 * _k, _y + 22 * _k, _x + 11 * _k, _y + 13 * _k, _x + 14 * _k, _y + 14 * _k], true, 2 * _k * 0.75, _ink, 0.9);
}
