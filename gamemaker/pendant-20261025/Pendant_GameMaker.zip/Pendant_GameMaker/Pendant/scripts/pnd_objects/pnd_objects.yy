{
  "$GMScript": "v1",
  "%Name": "pnd_objects",
  "name": "pnd_objects",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}