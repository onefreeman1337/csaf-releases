/// pnd_demo.gml - THE GALLERY, Pendant's demo room: two paintings hang on the wall (a riverside village and a harbour town,
/// both shipped as sprites you may use in your game); choose one, choose how many differences and which wall, and the
/// puzzle opens. When the player leaves it, the result is shown under the paintings.
/// Mouse: click a painting to open it, click a count or a wall swatch to choose. Keys: Left / Right a painting, Up / Down
/// the count, W the wall, Enter to open.
///
/// Pendant - Spot the Difference From Any Picture, for GameMaker. Copyright (c) 2026 Core Systems Asset Factory.
/// Licence: see LICENSE.txt.
///
/// Public functions: pnd_demo_create, pnd_demo_step, pnd_demo_draw, pnd_demo_free, pnd_demo_counts - the four calls in
/// obj_pnd_demo.

/// @function pnd_demo_counts()
/// @description The demo's difference counts to choose from.
/// @returns {Array<Real>}
function pnd_demo_counts() { static _c = [3, 5, 7, 9, 12]; return _c; }

/// @function pnd__demo_rects(demo)
/// @description Internal. The chooser's clickable boxes: two paintings, five counts, four walls.
function pnd__demo_rects(_D) {
    var _W = _D.W, _H = _D.H, _S = pnd_ui_scale(_W, _H), _pw = round(_W * 0.33), _ph = round(_pw * 429 / 640), _gap = round(_W * 0.08);
    var _x0 = round((_W - _pw * 2 - _gap) / 2), _y0 = round(_H * 0.24);
    var _r = { S: _S, pics: [[_x0, _y0, _pw, _ph], [_x0 + _pw + _gap, _y0, _pw, _ph]], counts: [], walls: [] };
    // the counts and the wall swatches share one row under the paintings, clear of the dado rail (on two rows the WALL
    // label landed on the rail, first look 2026-10-25)
    var _bw = round(56 * _S), _bh = round(38 * _S), _cg = round(9 * _S), _sw = round(34 * _S), _sg = round(12 * _S), _mid = round(64 * _S);
    var _total = 5 * _bw + 4 * _cg + _mid + 4 * _sw + 3 * _sg, _rx = round((_W - _total) / 2), _cy = _y0 + _ph + round(78 * _S);
    for (var _i = 0; _i < 5; _i++) array_push(_r.counts, [_rx + _i * (_bw + _cg), _cy, _bw, _bh]);
    var _wx = _rx + 5 * _bw + 4 * _cg + _mid;
    for (var _j = 0; _j < 4; _j++) array_push(_r.walls, [_wx + _j * (_sw + _sg), _cy + round((_bh - _sw) / 2), _sw, _sw]);
    return _r;
}

/// @function pnd_demo_create([width], [height])
/// @description Create THE GALLERY (the GUI's size by default). Call in Create.
/// @returns {Struct} the demo
function pnd_demo_create(_W = display_get_gui_width(), _H = display_get_gui_height()) {
    if (!pnd__ok(_W) || _W < 320) _W = max(320, display_get_gui_width());
    if (!pnd__ok(_H) || _H < 240) _H = max(240, display_get_gui_height());
    _W = min(_W, 4096); _H = min(_H, 4096);
    var _D = { W: _W, H: _H, pic: 0, count: 1, wall: 0, puzzle: undefined, last: undefined, opened: 0, spr_bg: -1, wall_names: ["green", "plum", "navy", "oxblood"], sprites: [spr_pnd_demo_village, spr_pnd_demo_harbour], names: ["The Riverside Village", "The Harbour Town"], dirty: true, inject: undefined };
    return _D;
}

/// @function pnd__demo_bake(demo)
/// @description Internal. The chooser's wall, frames and paintings, drawn once per wall colour.
function pnd__demo_bake(_D) {
    if (sprite_exists(_D.spr_bg)) sprite_delete(_D.spr_bg);
    var _R = pnd__demo_rects(_D);
    _D.spr_bg = pnd__bake(_D.W, _D.H, method({ D: _D, R: _R }, function() {
        pnd_draw_wall(D.W, D.H, R.S, D.wall_names[D.wall]);
        var _L = { ax: R.pics[0][0], ay: R.pics[0][1], bx: R.pics[1][0], by: R.pics[1][1], w: R.pics[0][2], h: R.pics[0][3], f: round(max(9 * R.S, min(30 * R.S, R.pics[0][3] * 0.075))), stacked: false };
        pnd_draw_hanging(_L, R.S, D.W, false);
        for (var _i = 0; _i < 2; _i++) {
            pnd_draw_frame(R.pics[_i][0], R.pics[_i][1], R.pics[_i][2], R.pics[_i][3], _L.f, R.S);
            draw_sprite_stretched(D.sprites[_i], 0, R.pics[_i][0], R.pics[_i][1], R.pics[_i][2], R.pics[_i][3]);
        }
        pnd_draw_lamps(_L, R.S);
        for (var _j = 0; _j < 5; _j++) pnd_draw_plaque_base(R.counts[_j][0], R.counts[_j][1], R.counts[_j][2], R.counts[_j][3], R.S * 0.7);
    }));
    _D.dirty = false;
}

/// @function pnd__demo_open(demo)
/// @description Internal. Open the chosen painting as a puzzle.
function pnd__demo_open(_D) {
    _D.opened++;
    _D.puzzle = pnd_open({ sprite: _D.sprites[_D.pic], count: pnd_demo_counts()[_D.count], wall: _D.wall_names[_D.wall], width: _D.W, height: _D.H, hints: 3, key: _D.names[_D.pic] });
}

/// @function pnd_demo_step(demo)
/// @description One step of THE GALLERY. demo.inject (one step of scripted input) takes the place of the player:
/// { pick: 0 | 1 } { count: index } { wall: index } { open: true }.
function pnd_demo_step(_D) {
    if (!is_struct(_D) || !variable_struct_exists(_D, "spr_bg")) return;
    if (!is_undefined(_D.puzzle)) {
        pnd_step(_D.puzzle);
        if (pnd_closed(_D.puzzle)) { _D.last = _D.puzzle.result; pnd_free(_D.puzzle); _D.puzzle = undefined; }
        return;
    }
    if (_D.dirty) pnd__demo_bake(_D);
    var _in = _D.inject; _D.inject = undefined;
    if (is_struct(_in)) {
        if (variable_struct_exists(_in, "pick")) _D.pic = clamp(_in.pick, 0, 1);
        if (variable_struct_exists(_in, "count")) _D.count = clamp(_in.count, 0, 4);
        if (variable_struct_exists(_in, "wall")) { _D.wall = clamp(_in.wall, 0, 3); _D.dirty = true; }
        if (variable_struct_exists(_in, "open") && _in.open) pnd__demo_open(_D);
        return;
    }
    var _R = pnd__demo_rects(_D), _mx = device_mouse_x_to_gui(0), _my = device_mouse_y_to_gui(0);
    if (keyboard_check_pressed(vk_left)) _D.pic = 0;
    if (keyboard_check_pressed(vk_right)) _D.pic = 1;
    if (keyboard_check_pressed(vk_up)) _D.count = min(4, _D.count + 1);
    if (keyboard_check_pressed(vk_down)) _D.count = max(0, _D.count - 1);
    if (keyboard_check_pressed(ord("W"))) { _D.wall = (_D.wall + 1) mod 4; _D.dirty = true; }
    if (keyboard_check_pressed(vk_enter)) { pnd__demo_open(_D); return; }
    if (mouse_check_button_pressed(mb_left)) {
        for (var _i = 0; _i < 2; _i++) { var _b = _R.pics[_i]; if (point_in_rectangle(_mx, _my, _b[0], _b[1], _b[0] + _b[2], _b[1] + _b[3])) { _D.pic = _i; pnd__demo_open(_D); return; } }
        for (var _j = 0; _j < 5; _j++) { var _c = _R.counts[_j]; if (point_in_rectangle(_mx, _my, _c[0], _c[1], _c[0] + _c[2], _c[1] + _c[3])) _D.count = _j; }
        for (var _k = 0; _k < 4; _k++) { var _w = _R.walls[_k]; if (point_in_rectangle(_mx, _my, _w[0], _w[1], _w[0] + _w[2], _w[1] + _w[3])) { _D.wall = _k; _D.dirty = true; } }
    }
}

/// @function pnd_demo_draw(demo)
/// @description Draw THE GALLERY (or the open puzzle) in the GUI layer.
function pnd_demo_draw(_D) {
    if (!is_struct(_D) || !variable_struct_exists(_D, "spr_bg")) return;
    if (!is_undefined(_D.puzzle)) { pnd_draw(_D.puzzle, 0, 0, 1); return; }
    if (!sprite_exists(_D.spr_bg)) return;
    var _R = pnd__demo_rects(_D), _S = _R.S, _font = draw_get_font(), _ha = draw_get_halign(), _va = draw_get_valign();
    gpu_push_state();
    gpu_set_texfilter(true);
    draw_sprite(_D.spr_bg, 0, 0, 0);
    var _gold = make_colour_rgb(232, 196, 120), _cream = make_colour_rgb(244, 230, 196);
    pnd__text(_D.W / 2, round(48 * _S), "T H E   G A L L E R Y", fnt_pendant_display_l, round(28 * _S), _cream, 1);
    pnd__text(_D.W / 2, round(78 * _S), "Each painting is hung twice and the second is changed. Choose one to begin.", fnt_pendant_body_s, round(15 * _S), _gold, 0.9);
    for (var _i = 0; _i < 2; _i++) {
        var _b = _R.pics[_i];
        pnd__text(_b[0] + _b[2] / 2, _b[1] + _b[3] + round(34 * _S), _D.names[_i], fnt_pendant_display_s, round(15 * _S), (_D.pic == _i) ? _cream : _gold, (_D.pic == _i) ? 1 : 0.7);
        if (_D.pic == _i) pnd__stroke(pnd__rrect_points(_b[0] - 26 * _S, _b[1] - 26 * _S, _b[2] + 52 * _S, _b[3] + 52 * _S, 6 * _S), true, 2 * _S, _gold, 0.8);
    }
    pnd__text((_R.counts[0][0] + _R.counts[4][0] + _R.counts[4][2]) / 2, _R.counts[0][1] - round(16 * _S), "DIFFERENCES", fnt_pendant_display_s, round(12 * _S), _gold, 0.85);
    for (var _j = 0; _j < 5; _j++) {
        var _c = _R.counts[_j];
        pnd__engraved(_c[0] + _c[2] / 2 - 1, _c[1] + _c[3] / 2 - 1, string(pnd_demo_counts()[_j]), fnt_pendant_display_s, round(18 * _S), make_colour_rgb(42, 26, 6), 1);
        if (_D.count == _j) pnd__stroke(pnd__rrect_points(_c[0] - 4 * _S, _c[1] - 4 * _S, _c[2] + 6 * _S, _c[3] + 6 * _S, 6 * _S), true, 2 * _S, _cream, 0.95);
    }
    pnd__text((_R.walls[0][0] + _R.walls[3][0] + _R.walls[3][2]) / 2, _R.counts[0][1] - round(16 * _S), "WALL", fnt_pendant_display_s, round(12 * _S), _gold, 0.85);
    var _walls = pnd_walls();
    for (var _k = 0; _k < 4; _k++) {
        var _w = _R.walls[_k], _wc = variable_struct_get(_walls, _D.wall_names[_k]);
        pnd__rect(_w[0], _w[1], _w[2], _w[3], pnd__rgb(_wc[1]), 1);
        pnd__stroke(pnd__rrect_points(_w[0], _w[1], _w[2], _w[3], 1), true, (_D.wall == _k) ? 3 * _S : 1, (_D.wall == _k) ? _cream : _gold, 1);
    }
    if (is_struct(_D.last)) {
        var _r = _D.last, _t = _r.refused ? "That picture could not be changed." : ((_r.allFound ? "All found" : (_r.timedOut ? "Time" : "Set aside")) + ":  " + string(_r.found) + " of " + string(_r.count) + "  -  " + pnd__clock(_r.seconds) + "  -  " + string(_r.misses) + " misses  -  " + string(_r.hints) + " hints");
        pnd__text(_D.W / 2, _D.H - round(30 * _S), "Last puzzle (" + string(_r.key) + "): " + _t, fnt_pendant_body_s, round(14 * _S), _cream, 0.9);
    } else pnd__text(_D.W / 2, _D.H - round(30 * _S), "Keys: Left / Right a painting, Up / Down the count, W the wall, Enter to open.", fnt_pendant_body_s, round(14 * _S), _gold, 0.75);
    gpu_pop_state();
    draw_set_font(_font); draw_set_halign(_ha); draw_set_valign(_va);
}

/// @function pnd_demo_free(demo)
/// @description Free what THE GALLERY made (Clean Up).
function pnd_demo_free(_D) {
    if (!is_struct(_D) || !variable_struct_exists(_D, "spr_bg")) return;
    if (!is_undefined(_D.puzzle)) { pnd_free(_D.puzzle); _D.puzzle = undefined; }
    if (sprite_exists(_D.spr_bg)) sprite_delete(_D.spr_bg);
    _D.spr_bg = -1;
}
