/// @description Free what the gallery made (guarded: Clean Up runs even when Create left early for -selftest).
if (variable_instance_exists(id, "demo") && !is_undefined(demo)) { pnd_demo_free(demo); demo = undefined; }
