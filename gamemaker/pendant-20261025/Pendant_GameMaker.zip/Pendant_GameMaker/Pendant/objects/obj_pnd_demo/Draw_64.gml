/// @description Draw the gallery (the GUI is 1280 x 720).
if (is_undefined(demo)) exit;
pnd_demo_draw(demo);
