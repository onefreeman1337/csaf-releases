/// @description Run the gallery.
if (is_undefined(demo)) exit;
pnd_demo_step(demo);
