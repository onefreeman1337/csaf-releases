# Pendant - Spot the Difference From Any Picture, for GameMaker

**Any picture in your game becomes a spot-the-difference puzzle, hung as a pair of paintings in a gallery.** A sprite, a
background, a portrait, or a surface (a capture of the room the player is standing in): Pendant hangs it twice and changes
the second copy in as many places as you ask. Every change is generated, so no two puzzles are alike and you never draw a
second picture by hand.

There are four kinds of change:

- **An object added** that belongs where it lands: a bird, a kite, a balloon, an airship or a moon in a day sky; a star, a
  comet, an owl or a paper lantern at night; a fish, a duck, a swan, a sailboat or a lily pad on water; a flower, a tulip,
  a ladybird, a snail or a pumpkin in a field; a key, a crown, a candle, a potion or a clock on a stone wall or a table.
  **51 objects** are drawn by the package (`pnd_object_count()`), each in a colour picked to stand out from what it sits
  on, outlined in its own colour taken down, with a soft shadow, and with the ground's own grain carried through the paint
  so it sits on the picture rather than floating over it. A puzzle uses a different object each time it can.
- **A detail mirrored**, left to right, only where the patch is uneven enough for the flip to show.
- **Something painted out** with the picture beside it, through a soft, irregular edge rather than a hard circle.
- **An object recoloured** to a colour your picture already uses, only where the region has an edge of its own all round
  (a roof, a sail, a board square), never a band of sky or a shadow.

Every change is **measured before it is kept**: at the size the changes are made (640 pixels on the long side) it must
move at least 120 pixels by a clear margin, or it is undone and another place is tried. Changes never overlap. The same
seed always makes the same changes; a blank seed makes new ones every time.

The gallery is drawn by the package, from primitives: a damask wall (green, plum, navy or oxblood) with a dado rail and a
panelled wainscot, a picture rail with the two paintings hung on cords from brass hooks, gilt frames with a lit moulding,
beading and corner rosettes, picture lamps with a warm wash, and a brass plaque that keeps the count, the time, the misses
and the hints. A find is ringed in red ink on both paintings. While the differences are made, the second frame holds a
velvet drape and the plaque says the restorer is at work.

Ported from our RPG Maker MZ plugin Pendant and held to it: given the same picture, seed, count and kinds, the GameMaker
core makes the same changes and the same second picture, byte for byte (see Verification). The MZ edition draws 12
objects; this edition draws 51.

## Install

1. In GameMaker, **Tools > Import Local Package**, choose `Pendant.yymps`, and import everything.
2. Run the project with `rm_pnd_demo` first in the room order. The demo is THE GALLERY: two paintings hang on the wall
   (a riverside village and a harbour town); choose one, choose how many differences (3, 5, 7, 9 or 12) and which wall,
   and the puzzle opens. Click a painting, or use the keys: Left / Right a painting, Up / Down the count, W the wall, Enter
   to open.

**The demo paintings** are `spr_pnd_demo_village` and `spr_pnd_demo_harbour` (640 x 429 each). You may use them in your
game (see LICENSE.txt, section 5).

Requires GameMaker 2024.14 or later. Built and tested on runtime 2024.14.4.268 (the VM, Windows). Pure GML: no shader, no
extension, no included file; nothing here depends on GMRT.

## Quickstart

```gml
// Create - hang a picture with 5 differences
my_puzzle = pnd_open({ sprite: spr_castle, count: 5 });

// Step - run it; when the player leaves, read the result
pnd_step(my_puzzle);
if (pnd_closed(my_puzzle)) {
    my_result = my_puzzle.result;     // { allFound, timedOut, gaveUp, found, count, misses, hints, seconds, seed, key, refused, fallback }
    pnd_free(my_puzzle);
    my_puzzle = undefined;
}

// Draw GUI - the gallery fills the GUI by default; draw it anywhere, at any scale
pnd_draw(my_puzzle, 0, 0, 1);
```

`pnd_open` reads the picture, draws the gallery once and starts making the differences; `pnd_step` makes them a few
milliseconds per frame behind the drape (see Performance), then runs the play. **Call `pnd_open` in Create or Step,
never inside a Draw event or while a surface is the render target** (it draws into its own surfaces). After the
differences are made a frame costs a handful of sprites. The mouse is read in GUI coordinates, relative to where you
draw the gallery. What a solved puzzle is worth is your game's business: `result` says how it ended.

### The request

```gml
{ sprite: spr_castle,          // the picture: any sprite (or surface: a surface, copied as the puzzle opens)
  subimg: 0,                   // which frame of the sprite
  count: 5,                    // how many differences: 1 to 12 (a picture with very little in it may get fewer)
  seed: "the north tower",     // "" or absent: new differences every time; a number or a word: the same ones every time
  time: 90,                    // seconds; 0 (the default) = no limit. At zero the puzzle ends as TIME
  hints: 3,                    // 0 to 9
  wall: "green",               // "green", "plum", "navy" or "oxblood"
  kinds: ["add", "mirror"],    // which kinds of change: "add", "recolour", "mirror", "paintout" (all four by default)
  width: 1280, height: 720,    // the gallery's size (default: the GUI's)
  budget_us: 8000,             // the making's work per frame, in microseconds
  sound: my_sound_hook,        // optional: function(name) called with "find", "miss", "hint", "solve", "giveup", "time"
  key: "chapter2|tower" }      // optional: yours, handed back in the result
```

If the kinds you allow find nothing to change on a picture (recolour alone on a picture with no edged objects), that
picture gets all four kinds instead, so a puzzle never opens with no differences, and `result.fallback` is true. If no
visible change can be made at all, the gallery closes at once with `result.refused` true.

## Playing

- **Mouse or touch:** click where the two paintings differ, on either painting. A find is ringed on both. A click on a
  painting that finds nothing is a miss and leaves a small mark that fades; a click on a difference already found, or on
  the wall, is neither. On mobile exports a first finger reads as GameMaker's mouse (device 0); we have only built and
  tested Windows.
- **Keyboard:** the arrow keys move a hand (hold Shift to move it faster); Enter, Space or Z marks the spot under it.
- **Hints:** Q (Page Up), or a click on the plaque, lights a lamp glow around a difference not yet found, on both
  paintings, for about three seconds. Each spends a hint.
- **Give up:** Escape or a right click. The plaque says SET ASIDE with how many were found, and every difference left is
  marked with a dashed gold ring.
- **The ending:** ALL FOUND gives the count, the time and the misses. The ending plays for well under a second before a
  press returns, so a key held from the last find cannot skip it.

The paintings hang for the gallery's shape: side by side, or one above the other when that hangs them larger (a portrait
screen). The plaque's type grows with the gallery.

## Reference

**The gallery** (`pnd_open` once, then every frame `pnd_step` in Step and `pnd_draw` in Draw or Draw GUI)
- `pnd_open(request)` - read the picture, draw the gallery, start the differences; returns the puzzle struct (undefined,
  with a message in the output log, when there is no picture).
- `pnd_step(puzzle, [mouse_x], [mouse_y])` - one step. Pass your own mouse position (in the coordinates you draw in,
  before the scale) if you do not draw in the GUI layer.
- `pnd_draw(puzzle, [x], [y], [scale])` - draw it with its top-left at (x, y). Never changes your blend, filter, font,
  alignment or world matrix.
- `pnd_closed(puzzle)` - true once the player has left the gallery.
- `pnd_free(puzzle)` - free every sprite and image it made (in Step or Clean Up, never in a Draw event). Your own sprite or
  surface is never touched. Safe twice.
- `pnd_mark(puzzle, x, y)` - mark a gallery point as a player's click would: returns "find", "repeat", "miss" or "none".
- `pnd_hint(puzzle)` - spend a hint; false when none is left, one is showing or nothing is left to find.
- `pnd_give_up(puzzle)` - set the puzzle aside.
- `pnd_ui_scale(w, h)` - the type and ornament scale for a gallery size (1 at 816 x 624, up to 3).
- `pnd_layout(pw, ph, w, h)` - where two pw x ph paintings hang in a w x h gallery: `{ w, h, f, ax, ay, bx, by, stacked }`.
- Fields you may set: `puzzle.inject` (scripted input for one step, in gallery coordinates: `{ x, y, click: true }`,
  `{ ok: true }`, `{ hint: true }`, `{ cancel: true }`, `{ left / right / up / down: true, shift }`, `{ dt_us }` - for a
  tutorial or a replay) and `puzzle.dt_us` (a fixed step length, for a game that runs its own clock).
- `puzzle.result` - `{ allFound, timedOut, gaveUp, found, count, misses, hints, seconds, seed, key, refused, fallback }`.
- `puzzle.changes` - the differences, each `{ kind, x, y, r, object?, ground? }` in WORK-image pixels.

**The differences on their own** (pure GML over pixel buffers; nothing drawn to the screen)
- `pnd_image_from_sprite(sprite, [subimg])`, `pnd_image_from_surface(surface)` - a picture at its work size as an image
  `{ w, h, buf }` (RGBA bytes). `pnd_image_free(image)` frees one; `pnd_image_to_sprite(image)` makes a sprite of one.
- `pnd_make_differences(image, [options])` - the second picture in one call: `{ image, changes }` (`options`: `count`,
  `seed`, `kinds`). The source image is never changed.
- `pnd_make_begin(image, [options])`, `pnd_make_step(job, [budget_us])` (true when finished), `pnd_make_free(job)` - the
  same, a few milliseconds per call.
- `pnd_hit(changes, x, y)` - which change a work-image point lands on, or -1.
- `pnd_seed_of(seed)` - the 32-bit seed from a number or a word.
- `pnd_add_object(image, cx, cy, r, which, [options])`, `pnd_mirror(image, cx, cy, r)`, `pnd_paint_out(image, cx, cy, r,
  dx)`, `pnd_recolour(image, x, y)` - one change each, in place, or undefined (image untouched) when refused.
- `pnd_ground_class(image, cx, cy, r)` - "night", "dark", "sky", "stone", "water", "field" or "earth".
- `pnd_visibility(a, b, cx, cy, r)` - `{ px, meanDelta }`: how visibly b differs from a around a point.
- `pnd_object_ids()`, `pnd_object_count()` - the 51 drawn objects, by id.

**Drawing directly** (onto whatever surface is the current target, in its coordinates)
- `pnd_walls()` - the four walls' colours; `pnd_draw_wall(w, h, scale, wall)`; `pnd_draw_frame(x, y, w, h, frame_width,
  scale)` (draw your picture into x, y, w, h afterwards); `pnd_draw_ring(cx, cy, r, phase, line_width, ghost)`;
  `pnd_draw_hint_glow(cx, cy, r, alpha)`.

**The demo room** - `pnd_demo_create([w], [h])`, `pnd_demo_step(demo)`, `pnd_demo_draw(demo)`, `pnd_demo_free(demo)`,
`pnd_demo_counts()`: THE GALLERY, the same four calls in `obj_pnd_demo`.

## Performance - read this before opening a puzzle mid-frame

<!-- measured:start -->
Measured on our test machine, a shared and busy one (runtime 2024.14.4.268, the VM, Windows), in two runs of the suite on
the same source. Yours will differ.

- **Opening** (reading a 640 x 429 painting, drawing the gallery once): 298 to 374 ms, in the frame that calls `pnd_open`.
- **Making the differences** is spread over frames behind the drape: a 6-difference puzzle on the village took 1.1 to 1.4 s of work in 25
  steps at the default 8 ms budget (51 places tried). Eight puzzles of 4 to 12 differences on the two paintings (58
  differences) took 7.4 to 7.8 s of work in all.
- **The longest single step was 261 to 280 ms.** One place is the smallest piece of work (drawing one object
  pixel by pixel cannot be split), so while the drape shows, an occasional frame takes that long. Open a puzzle behind
  your own transition if that matters to your game.
- **After that a frame costs a handful of sprites** (the gallery, the two paintings, the lamps' wash, the rings) and the
  plaque's text.
<!-- measured:end -->

## Fonts

The gallery is lettered in two faces rasterised into font resources: Cinzel Bold (the plaque, the ending plaques and the
demo's headings) and Alegreya (the lines under them), both SIL Open Font License 1.1. The licence texts and the notices are
in `Pendant/fonts/`. The atlases carry printable ASCII (32 to 126); any other character is not drawn.

## Differences from the RPG Maker MZ edition

- 51 drawn objects instead of 12. The twelve are the MZ edition's, shape for shape; the 39 new ones belong to the same
  grounds (water, sky, night, field, earth, stone, dark) and are chosen the same way.
- The differences are made a few milliseconds per frame behind a drape instead of in one go, so opening a puzzle never
  holds a frame for long (see Performance).
- A picture is read at its work size through halving steps (each a 2 x 2 average), then one bilinear stretch, instead of
  a browser canvas's resampler. A picture already at its work size is read byte for byte.
- A seed given as a hex or exponent string ("0x1F", "1e3") is read as a word, not a number; plain numbers and words make
  exactly the differences the MZ edition makes.

## Verification

GameMaker code cannot be unit-tested outside the engine, so everything below ran in real executables built by GameMaker's
own compiler (Igor, runtime 2024.14.4.268):

<!-- verification:start -->
- **The difference maker, held to the RPG Maker MZ edition.** In Node, the reference core (the MZ edition's core with its
  object list as a parameter) makes byte-identical pictures to the MZ edition on 27 puzzles (232 changes, 29 MB compared) and the
  same distance fields for its twelve objects on 7500 lattice points. In the engine, the GML core matches that reference: the seed hash and
  generator, every layer of all 51 objects on a lattice (exact), all 51 objects drawn byte for byte, the ground classes
  on both paintings, and 8 whole puzzles on both demo paintings (58 differences of all four kinds): every change at the
  same place and every second picture identical byte for byte.
- **The gallery**: the layout on four screen shapes (816 x 624, 1280 x 720, 1920 x 1080, a 1080 x 1920 portrait); a puzzle
  played by script - a click on the wall, a miss, finds on both paintings, a repeat, a hint and its glow measured in
  pixels, the keyboard hand walked to a difference - its ending and its result; the clock running out; giving up and the
  gold reveal rings; the kinds fallback on a picture of stripes; a surface picture freed by its owner; opening under a
  caller's 2x world matrix; the wall drawn into a smaller box staying inside it; every public call refusing bad input.87 in-engine checks, all passing, in both runs.
- **Fresh install**: the package imported into a blank project and this Readme's own code run, every documented function
  called and its ink counted.
- **Adversarial**: every function this Readme names called with undefined, -1, 4096 and a string (152 calls): none crashed.
<!-- verification:end -->

Two things this does not prove, stated plainly: the timings come from one shared machine and will differ on yours, and
the suite ran on Windows with the VM runtime only (other targets and YYC were not built).

## Licence

See `LICENSE.txt`. In short: use it in any number of commercial and non-commercial games; do not resell or redistribute
the package. Made by Core Systems Asset Factory, https://csaf.itch.io
