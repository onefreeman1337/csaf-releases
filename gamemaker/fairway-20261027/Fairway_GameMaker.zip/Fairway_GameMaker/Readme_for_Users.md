# Fairway - Mini Golf for GameMaker

**Fairway is a mini golf system for GameMaker (2024.14, tested on runtime 2024.14.4.268) in pure GML, with a runnable demo
room.** It generates every hole from a seed and draws it in code: felt shaded by its own slopes, mower stripes, rails in six
materials, water, sand, ramps, pipes, bumpers, the theme's windmill with turning sails, swing gates and spinners, and the
scenery round the course. Six themes, 9 or 18 hole courses, up to four players with AI rivals, a drawn paper scorecard, and
a par for every hole set by a shot planner that plays it first. No image files ship; one commercial licence covers all your
games.

Every picture on the store page was rendered by this package in a blank GameMaker project.

---

## What is in the package

| | |
| --- | --- |
| `fwy_core` | the hole generator, the height field, hazards and obstacles, the ball physics, the shot planner (par and AI), courses, the game (turns, strokes, penalties, scores) - **no drawing calls** |
| `fwy_draw` | the hole bake, the moving pieces, the ball, the aim guide, the power gauge, the scorecard, the HUD, single pieces for your own levels |
| `fwy_demo` + `obj_fwy_demo` + `rm_fwy_demo` | THE CLUBHOUSE: a 9-hole round, you against two AI rivals |
| `fwy_selftest` | the in-engine test suite (run the demo with `-selftest`) |
| 4 fonts | `fnt_fairway_display_s/_l` (Caveat Bold) and `fnt_fairway_body_s/_l` (Barlow Condensed SemiBold), both SIL OFL 1.1; licences and notices in `Fairway/fonts/` |

## Install

1. In GameMaker: **Tools > Import Local Package**, choose `Fairway.yymps`, **Add All**, **Import**.
2. Run the project with `rm_fwy_demo` first in the room order to play THE CLUBHOUSE.

The raw `.gml` sources are also in the `Fairway/` folder of this download, readable without GameMaker.

## Quickstart

```gml
// Create - a lazily made 9-hole course on a theme, you and one AI rival
my_course = fwy_course_create(7, "pirate", 9, { lazy: true });
my_game = fwy_game_create(my_course, [{ name: "YOU", ai: false }, { name: "RIVAL", ai: 0.7 }]);
my_view = fwy_hole_view(fwy_game_hole(my_game), 900, 520);
my_aim = 0;
my_power = 0.5;
```

```gml
// Step - aim with the arrow keys, putt with Space; the game runs the ball, the rival, turns and holes
var my_dt = delta_time / 1000000;
my_aim += (keyboard_check(vk_right) - keyboard_check(vk_left)) * my_dt * 1.6;
my_power = clamp(my_power + (keyboard_check(vk_up) - keyboard_check(vk_down)) * my_dt * 0.6, 0.02, 1);
if (keyboard_check_pressed(vk_space)) fwy_game_shoot(my_game, my_aim, my_power);
var my_hole_before = my_game.hole;
fwy_game_step(my_game, my_dt);
if (my_game.hole != my_hole_before) my_view = fwy_hole_view(fwy_game_hole(my_game), 900, 520);
```

```gml
// Draw GUI - the hole, the ball, what stands over it, the aim, the HUD
var my_hole = fwy_game_hole(my_game), my_ball = fwy_game_ball(my_game);
var my_x = 30 + my_view.x, my_y = 70 + my_view.y;
fwy_hole_draw(my_hole, my_x, my_y, my_view.scale, my_game.clock, my_view.crop);
fwy_ball_draw(my_ball, my_x, my_y, my_view.scale);
fwy_hole_draw_over(my_hole, my_x, my_y, my_view.scale, my_game.clock, my_ball.x, my_ball.y);
if (my_game.state == "aim") fwy_aim_draw(my_hole, my_ball, my_aim, my_power, my_x, my_y, my_view.scale);
fwy_hud_draw(my_game, 0, 0, 960);
```

Show the card between holes with `fwy_scorecard_draw(my_game, 110, 150, 740);`. Free each hole's picture when you are done
with it with `fwy_hole_free(hole)`.

## The six themes

| theme | course | rails | windmill | water | pipe | bumper |
| --- | --- | --- | --- | --- | --- | --- |
| `garden` | The Rose Garden | timber | windmill | pond with lily pads | hollow log | flower pot |
| `pirate` | Smuggler's Cove | rope and plank | lighthouse with a ship's wheel | lagoon | cannon | barrel |
| `haunted` | Hollow Manor | iron and stone | manor with tattered sails | bog | coffin | headstone |
| `candy` | Sweetshop Lane | candy cane | gingerbread mill | syrup | candy tube | gumdrop |
| `space` | Orbit Station | steel with a light strip | reactor with solar arms | the void | teleporter | beacon |
| `desert` | Sunken Ruins | sandstone | water-wheel tower | quicksand | sarcophagus | urn |

Each theme has its own ground (paving, beach, flagstones, frosting, deck plates, dunes) and four pieces of scenery placed round
every course (60 pieces in all: ten per theme, each drawn in that theme's own style; `fwy_pieces()` lists them and
`fwy_piece_draw(theme, piece, x, y, ...)` draws any one for your own levels or menus).

## How a hole is made

A lane is walked across a 14 x 8 grid of 64 px cells (no lane ever touches another except the cells before and after it, so
every lane is walled), widened into greens at its ends, and its corners are cut into 45 degree banks. The rails are the
merged boundary of the felt. Then 1 to 3 features are placed and checked against the tee, the cup and each other: a windmill
across a north-south lane (its sails close the tunnel for part of each turn), a swing gate whose whole swing stays on the
felt, a spinner, a ramp jump over a channel, a pipe that is a shortcut, bumpers, wedges, sand, a pond, hills and hollows.

**Par is set by playing the hole.** The shot planner simulates candidate shots (straight at the cup when it is in sight,
along the felt toward the cup in 16 directions, bank shots) and keeps the one that holes out or ends nearest the cup along the
felt. It plays from the tee (twice, at two clock phases, when anything on the hole moves). Par is its strokes plus one,
because it plays with exact knowledge of the physics; a hole it cannot finish in 6 strokes is thrown away and the next
attempt generated. In the test corpus of 30 holes, every first attempt was kept and par spread as
8 at par 2, 12 at par 3, 8 at par 4, 2 at par 5.

The same seed and theme always make the same hole.

## The physics

The ball rolls on a height field (sampled every 16 px) with rolling friction (`FWY_MU` 200 px/s2, sand `FWY_MU_SAND` 900),
bounces off rails with a restitution of 0.72, and drops into the cup only below `FWY_CAPTURE` (300 px/s) - faster, it lips
out. Each fixed step (`FWY_DT`, 1/120 s) is split into as many sub-steps as the speed needs so the ball never moves more than
0.6 of its radius at once: in the suite, 720 full-power shots fired in 48 directions across 15 holes hit the rails 4353 times and left the felt 0 times (the ball is checked after every step). A ball in the water costs a penalty stroke and is replayed from where it
was struck. The stroke limit is `FWY_LIMIT` (8).

## API

All public names start with `fwy_` (functions) or `FWY_` (macros). Every function checks its arguments and refuses bad input
with the value listed rather than throwing.

**Courses and holes**
- `fwy_course_create(seed, theme, [holes 9 or 18], [{ lazy }])` -> course; `fwy_course_hole(course, index)` (made on demand; `undefined` off the course); `fwy_course_par(course)` -> `[par, holesMade]`
- `fwy_hole_create(seed, theme, [{ difficulty 0..1, features: [...], solve }])` -> hole (`par`, `name`, `teeX/Y`, `cupX/Y`, `obstacles`, `hazards`, `attempts`, `fallback`)
- `fwy_themes()`, `fwy_theme(name)`, `fwy_is_felt(hole, x, y)`, `fwy_slope_at(hole, x, y)` -> `[dh/dx, dh/dy]`

**The game**
- `fwy_game_create(course, players)` - players `[{ name, colour, ai: false | skill 0..1 }]`, 1 to 4
- `fwy_game_step(game, dt)`; `game.events` lists this step's `shot`, `water`, `pipe`, `jump`, `bump`, `lipout`, `holed { strokes, par, name }`, `limit`, `next_hole`, `done`
- `fwy_game_shoot(game, angle, power)` (false unless waiting for a shot), `fwy_game_hole(game)`, `fwy_game_ball(game)`
- `fwy_game_scores(game)` -> `[player][hole]` (-1 not played), `fwy_game_total(game, player)` -> `[strokes, par, holes]`, `fwy_score_name(strokes, par)`

**A ball on its own** (your own game loop)
- `fwy_ball_create(x, y)`, `fwy_ball_shoot(ball, angle, power)`, `fwy_ball_step(hole, ball, t)` -> `{ holed, water, pipe, jump, landed, bumps, lipout, stopped }`
- `fwy_shot_sim(hole, x, y, angle, power, t0, [maxSeconds])` -> where a shot ends; `fwy_shot_suggest(hole, ball, t0, [skill])` -> `{ angle, power }`

**Drawing**
- `fwy_hole_view(hole, w, h, [maxScale])` -> `{ scale, x, y, crop }`; `fwy_hole_bake(hole, [scale])`; `fwy_hole_draw(hole, x, y, [scale], [t], [crop])`; `fwy_hole_draw_over(hole, x, y, [scale], [t], [ballX], [ballY])`; `fwy_hole_free(hole)`
- `fwy_ball_draw(ball, x, y, [scale], [colour])`, `fwy_aim_draw(hole, ball, angle, power, x, y, [scale])`, `fwy_power_draw(x, y, w, h, power, [theme])`
- `fwy_scorecard_draw(game, x, y, w, [title])` -> height drawn; `fwy_hud_draw(game, x, y, w)`
- `fwy_pieces()`, `fwy_piece_draw(theme, piece, x, y, [scale], [angle], [variant], [t])`; `fwy_draw_free()`

Every drawing call blends alpha as "over" and restores your blend state; the bake runs under its own transform and hands
yours back.

## Performance (measured, two suite runs, Windows VM build)

- Making one hole including its par: 128 ms to 135 ms on average, 363 ms to 395 ms at worst. A lazy course makes a hole as it is
  reached; the demo does it during the scorecard pause.
- A 9-hole course made all at once: 1.6 s to 1.7 s.
- Baking a hole's picture: 56 ms to 155 ms at worst.

## Limits, stated

- Holes are built on a 14 x 8 grid of 64 px cells; one ball is on the course at a time (players take turns at each hole).
- No sound ships. Hook `game.events` to your own sounds.
- Built and tested on Windows (VM). HTML5, mobile and YYC were not built.
- GML cannot be unit-tested outside the engine. Every figure above came from real Igor-built executables running the
  package's own suite (410 assertions) and a fresh install of the package into a blank project.

## Globals

Fairway keeps five globals, all namespaced: `global.fwy_gx`, `global.fwy_gy` (the slope under the ball), `global.fwy_dyn`
(moving pieces this step), `global.fwy_pv` (a draw counter) and `global.fwy_stage` (the suite's progress).

## Licence and AI disclosure

One commercial licence, unlimited games: see `LICENSE.txt`. The fonts are SIL OFL 1.1 (`Fairway/fonts/`).
Fairway was written with AI assistance (code and the drawings it makes). Copyright (c) 2026 Core Systems Asset Factory.
