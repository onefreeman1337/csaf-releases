/// @description Free what the round made (guarded: Clean Up runs even when Create left early for -selftest).
if (variable_instance_exists(id, "demo") && !is_undefined(demo)) { fwy_demo_free(demo); demo = undefined; }
