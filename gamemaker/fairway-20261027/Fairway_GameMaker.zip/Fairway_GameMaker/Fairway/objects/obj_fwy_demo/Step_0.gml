/// @description Play the round.
if (is_undefined(demo)) exit;
fwy_demo_step(demo);
