/// @description Draw the round (the GUI is 960 x 640).
if (is_undefined(demo)) exit;
fwy_demo_draw(demo);
