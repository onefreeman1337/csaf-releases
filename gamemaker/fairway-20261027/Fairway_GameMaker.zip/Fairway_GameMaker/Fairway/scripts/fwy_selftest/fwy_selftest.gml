/// fwy_selftest.gml - Fairway's in-engine test suite. Run the demo with -selftest: the result is written as
/// fwy_selftest.json in the game's save folder and the renders (fwy_render_*.png) beside it, to be LOOKED at.
/// Stages: the generator, holes on every theme (validity, rails on the felt boundary, determinism, distinctness), the
/// tunnelling hunt (full-power shots in 48 directions on every hole, the ball checked on the felt after EVERY step), the
/// cup, sand, water, slopes, the pipe and the moving pieces, the planner and par, a whole headless round between AI
/// players, refusals on bad input, then the bakes of every theme, the pieces sheet, a scorecard and a play frame - each
/// inked against a ground read off a blank surface, and saved.
///
/// Fairway - Mini Golf for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function fwy_st_assert(state, condition, message)
/// @description Count one assertion; keep the first 80 failure messages.
function fwy_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 80) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
/// @function fwy_st_stage(state, n)
/// @description Record the stage reached (the crash handler reports it).
function fwy_st_stage(_st, _n) { _st.stage = _n; global.fwy_stage = _n; }

/// @function fwy__st_read(surface)
/// @description Internal. A surface read into a buffer (RGBA bytes, the whole surface - wing doctrine s13).
function fwy__st_read(_surf) {
    var _w = surface_get_width(_surf), _h = surface_get_height(_surf);
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _surf, 0);
    return { buf: _b, w: _w, h: _h };
}
/// @function fwy__st_ink(read, rgb, tol)
/// @description Internal. Pixels that differ from rgb ([r, g, b] bytes) by more than tol in any channel (x step 2, y step 1).
function fwy__st_ink(_rd, _ref, _tol) {
    var _n = 0;
    for (var _y = 0; _y < _rd.h; _y++) for (var _x = 0; _x < _rd.w; _x += 2) {
        var _o = (_y * _rd.w + _x) * 4;
        if (abs(buffer_peek(_rd.buf, _o, buffer_u8) - _ref[0]) > _tol || abs(buffer_peek(_rd.buf, _o + 1, buffer_u8) - _ref[1]) > _tol || abs(buffer_peek(_rd.buf, _o + 2, buffer_u8) - _ref[2]) > _tol) _n++;
    }
    return _n * 2;
}
/// @function fwy__st_px(read, x, y)
/// @description Internal. [r, g, b, a] at a pixel.
function fwy__st_px(_rd, _x, _y) {
    var _o = (clamp(floor(_y), 0, _rd.h - 1) * _rd.w + clamp(floor(_x), 0, _rd.w - 1)) * 4;
    return [buffer_peek(_rd.buf, _o, buffer_u8), buffer_peek(_rd.buf, _o + 1, buffer_u8), buffer_peek(_rd.buf, _o + 2, buffer_u8), buffer_peek(_rd.buf, _o + 3, buffer_u8)];
}
/// @function fwy__st_colours(read)
/// @description Internal. Distinct colours (quantised to 16 levels a channel) over a 4 px grid - a sheet of one flat colour
/// reads 1, a drawn picture reads hundreds.
function fwy__st_colours(_rd) {
    var _seen = {}, _n = 0;
    for (var _y = 0; _y < _rd.h; _y += 4) for (var _x = 0; _x < _rd.w; _x += 4) {
        var _p = fwy__st_px(_rd, _x, _y), _k = string(_p[0] div 16) + "_" + string(_p[1] div 16) + "_" + string(_p[2] div 16);
        if (!variable_struct_exists(_seen, _k)) { _seen[$ _k] = 1; _n++; }
    }
    return _n;
}
/// @function fwy__st_hole_kinds(hole)
/// @description Internal. The obstacle kinds on a hole, joined.
function fwy__st_has_kind(_h, _k) { for (var _i = 0; _i < array_length(_h.obstacles); _i++) if (_h.obstacles[_i].kind == _k) return true; return false; }

/// @function fwy_selftest_run()
/// @description Run every stage; returns the state written by fwy_selftest_write.
function fwy_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, failures: [], stage: 0, notes: {}, timings: {} };
    _st.notes.epsilon = string_format(math_get_epsilon(), 1, 12);

    // ------------------------------------------------------------ 10: the generator
    fwy_st_stage(_st, 10);
    var _g1 = fwy_rng(42), _g2 = fwy_rng(42), _same = true;
    repeat (50) if (fwy_rand(_g1) != fwy_rand(_g2)) _same = false;
    fwy_st_assert(_st, _same, "the same seed draws the same sequence");
    var _lo = 1, _hi = 0;
    for (var _s = 0; _s < 400; _s++) { var _v = fwy_rand(fwy_rng(1000 + _s)); _lo = min(_lo, _v); _hi = max(_hi, _v); }
    fwy_st_assert(_st, _lo < 0.05 && _hi > 0.95, "first draws over 400 NEARBY seeds span [0,1): " + string(_lo) + ".." + string(_hi));
    var _inr = true, _g3 = fwy_rng(7);
    repeat (2000) { var _v = fwy_rand(_g3); if (_v < 0 || _v >= 1) _inr = false; }
    fwy_st_assert(_st, _inr, "every draw lies in [0, 1)");
    fwy_st_assert(_st, fwy_rand(undefined) == 0 && fwy_rand({}) == 0, "a non-generator draws 0 and does not throw");

    // ------------------------------------------------------------ 20: holes on every theme
    fwy_st_stage(_st, 20);
    var _themes = fwy_themes(), _holes = [], _made = 0, _fall = 0, _att = 0, _attMax = 0, _kindsSeen = {}, _parHist = [0, 0, 0, 0, 0, 0];
    var _t0 = get_timer(), _worstMs = 0;
    fwy_st_assert(_st, array_length(_themes) == 6, "six themes");
    for (var _t = 0; _t < array_length(_themes); _t++) {
        var _T = fwy_theme(_themes[_t]);
        fwy_st_assert(_st, _T.name == _themes[_t] && string_length(_T.title) > 4 && array_length(_T.favour) == 3, _themes[_t] + ": a theme description");
        for (var _s = 1; _s <= 5; _s++) {
            var _h = fwy_hole_create(_s * 13 + _t, _themes[_t], { difficulty: (_s - 1) / 4 });
            _made++; _att += _h.attempts; _attMax = max(_attMax, _h.attempts); if (_h.fallback) _fall++;
            _worstMs = max(_worstMs, _h.solveMs);
            array_push(_holes, _h);
            var _nm = _themes[_t] + " seed " + string(_s * 13 + _t);
            fwy_st_assert(_st, _h.valid && !_h.fallback, _nm + ": a valid generated hole (no fallback)");
            fwy_st_assert(_st, fwy_is_felt(_h, _h.teeX, _h.teeY) && fwy_is_felt(_h, _h.cupX, _h.cupY), _nm + ": tee and cup on the felt");
            fwy_st_assert(_st, _h.par >= 2 && _h.par <= 5, _nm + ": par " + string(_h.par) + " in 2..5");
            fwy_st_assert(_st, is_struct(_h.solve) && _h.solve.ok && _h.solve.sims > 0, _nm + ": the planner finished it (" + (is_struct(_h.solve) ? string(_h.solve.sims) : "?") + " shots simulated)");
            _parHist[clamp(_h.par, 0, 5)]++;
            for (var _k = 0; _k < array_length(_h.kinds); _k++) _kindsSeen[$ _h.kinds[_k]] = 1;
            // every rail segment lies on the felt boundary: felt just inside, not felt just outside
            var _bad = 0, _closed = 0;
            for (var _q = 0; _q < _h.railSegs; _q++) {
                var _e = _h.segs[_q], _mx = (_e.x1 + _e.x2) / 2, _my = (_e.y1 + _e.y2) / 2, _ex = _e.x2 - _e.x1, _ey = _e.y2 - _e.y1, _l = fwy__hyp(_ex, _ey);
                if (_l < 1) continue;
                var _inx = -_ey / _l, _iny = _ex / _l;
                if (!fwy_is_felt(_h, _mx + _inx * 3, _my + _iny * 3) || fwy_is_felt(_h, _mx - _inx * 3, _my - _iny * 3)) _bad++;
            }
            for (var _q = 0; _q < array_length(_h.loops); _q++) if (_h.loops[_q].closed) _closed++;
            fwy_st_assert(_st, _h.railSegs >= 4 && _bad == 0, _nm + ": every one of " + string(_h.railSegs) + " rail segments has felt inside and none outside (" + string(_bad) + " wrong)");
            fwy_st_assert(_st, _closed == array_length(_h.loops) && _closed >= 1, _nm + ": the rails close (" + string(_closed) + " of " + string(array_length(_h.loops)) + " loops)");
            fwy_st_assert(_st, fwy__potential(_h, _h.teeX, _h.teeY) < 4000, _nm + ": the cup is reachable along the felt");
            var _hz = 0; for (var _q = 0; _q < array_length(_h.hazards); _q++) { var _z = _h.hazards[_q]; if (!fwy_is_felt(_h, (_z.bx0 + _z.bx1) / 2, (_z.by0 + _z.by1) / 2)) _hz++; }
            fwy_st_assert(_st, _hz == 0, _nm + ": every hazard sits on the felt");
            fwy_st_assert(_st, array_length(_h.decor) >= 6, _nm + ": scenery placed round the course (" + string(array_length(_h.decor)) + ")");
            fwy_st_assert(_st, string_length(_h.name) > 3, _nm + ": a name (" + _h.name + ")");
        }
    }
    _st.timings.holeCreateMeanMs = (get_timer() - _t0) / 1000 / _made;
    _st.timings.holeCreateWorstMs = _worstMs;
    _st.notes.attemptsMean = _att / _made; _st.notes.attemptsMax = _attMax;
    _st.notes.parHistogram = "par2 " + string(_parHist[2]) + " par3 " + string(_parHist[3]) + " par4 " + string(_parHist[4]) + " par5 " + string(_parHist[5]);
    fwy_st_assert(_st, _fall == 0, "no hole fell back (" + string(_fall) + " of " + string(_made) + ")");
    var _kinds = ["mill", "gate", "spinner", "leap", "pipe", "bumpers", "wedges", "sand", "water", "hills"], _kn = 0, _missing = "";
    for (var _k = 0; _k < array_length(_kinds); _k++) if (variable_struct_exists(_kindsSeen, _kinds[_k])) _kn++; else _missing += _kinds[_k] + " ";
    _st.notes.kindsSeen = string(_kn) + " of 10 (missing: " + _missing + ")";
    fwy_st_assert(_st, _kn >= 8, "the corpus exercises at least 8 of the 10 feature kinds (" + string(_kn) + "; missing " + _missing + ")");
    // determinism and distinctness
    var _ha = fwy_hole_create(77, "pirate"), _hb = fwy_hole_create(77, "pirate"), _hc = fwy_hole_create(78, "pirate");
    var _eq = (_ha.teeX == _hb.teeX && _ha.cupX == _hb.cupX && _ha.par == _hb.par && array_length(_ha.segs) == array_length(_hb.segs));
    for (var _i = 0; _i < FWY_GW * FWY_GH && _eq; _i++) if (_ha.cells[_i] != _hb.cells[_i]) _eq = false;
    fwy_st_assert(_st, _eq, "the same seed and theme give the same hole");
    var _diff = 0; for (var _i = 0; _i < FWY_GW * FWY_GH; _i++) if (_ha.cells[_i] != _hc.cells[_i]) _diff++;
    fwy_st_assert(_st, _diff > 4, "a neighbouring seed gives a different hole (" + string(_diff) + " cells differ)");
    // no pile-ups: obstacle footprints apart, and off every hazard but a leap's own channel - over the corpus and over the
    // exact course that showed the defect (course 5 pirate: a lighthouse stood on a ramp jump's channel, 2026-10-27)
    var _pile = function(_hh) {
        var _n = 0, _O = _hh.obstacles, _Z = _hh.hazards;
        for (var _i = 0; _i < array_length(_O); _i++) {
            var _a = _O[_i];
            for (var _j = _i + 1; _j < array_length(_O); _j++) { var _b = _O[_j]; if (_a.bx1 > _b.bx0 && _a.bx0 < _b.bx1 && _a.by1 > _b.by0 && _a.by0 < _b.by1) _n++; }
            for (var _k = 0; _k < array_length(_Z); _k++) {
                var _z = _Z[_k];
                if (_a.kind == "leap" && _z.bx0 == _a.cx0 && _z.by0 == _a.cy0) continue;
                if (_a.bx1 > _z.bx0 && _a.bx0 < _z.bx1 && _a.by1 > _z.by0 && _a.by0 < _z.by1) _n++;
            }
        }
        return _n;
    };
    var _piles = 0, _pairsSeen = 0;
    for (var _i = 0; _i < array_length(_holes); _i++) { _piles += _pile(_holes[_i]); _pairsSeen += array_length(_holes[_i].obstacles); }
    var _pc5 = fwy_course_create(5, "pirate", 9), _piles5 = 0, _mills5 = 0;
    for (var _i = 0; _i < 9; _i++) { _piles5 += _pile(_pc5.holes[_i]); for (var _q = 0; _q < array_length(_pc5.holes[_i].obstacles); _q++) if (_pc5.holes[_i].obstacles[_q].kind == "mill") _mills5++; }
    fwy_st_assert(_st, _pairsSeen > 40, "the pile-up arm has obstacles to compare (" + string(_pairsSeen) + ")");
    fwy_st_assert(_st, _piles == 0, "no obstacle footprint overlaps another or a hazard across the corpus (" + string(_piles) + ")");
    fwy_st_assert(_st, _piles5 == 0 && _mills5 > 0, "course 5 pirate (the case that showed it) has no pile-up and still has a lighthouse (" + string(_piles5) + " overlaps, " + string(_mills5) + " mills)");
    var _layouts = {}, _distinct = 0;
    for (var _i = 0; _i < array_length(_holes); _i++) { var _k = ""; for (var _c = 0; _c < FWY_GW * FWY_GH; _c++) _k += string(_holes[_i].cells[_c]); if (!variable_struct_exists(_layouts, _k)) { _layouts[$ _k] = 1; _distinct++; } }
    fwy_st_assert(_st, _distinct >= array_length(_holes) - 2, "the 30 holes are (nearly) all different lanes: " + string(_distinct) + " distinct");

    // ------------------------------------------------------------ 30: the tunnelling hunt
    fwy_st_stage(_st, 30);
    var _escapes = 0, _contacts = 0, _shots = 0, _restMax = 0, _unrest = 0, _t1 = get_timer(), _unrestAt = "";
    for (var _i = 0; _i < array_length(_holes); _i += 2) {
        var _h = _holes[_i];
        for (var _k = 0; _k < 48; _k++) {
            var _b = fwy_ball_create(_h.teeX, _h.teeY);
            fwy_ball_shoot(_b, _k * pi * 2 / 48, 1);
            var _tt = 0, _n = 0, _out = false;
            while (_b.moving && _n < 1800) {
                var _ev = fwy_ball_step(_h, _b, _tt);
                _tt += FWY_DT; _n++;
                _contacts += _ev.bumps;
                if (!fwy_is_felt(_h, _b.x, _b.y) && _b.air <= 0) _out = true;
                if (_ev.water || _ev.holed) break;
            }
            _shots++;
            if (_out) _escapes++;
            if (_b.moving && _n >= 1800) {
                _unrest++;
                var _near = "";
                for (var _q = 0; _q < array_length(_h.obstacles); _q++) { var _o = _h.obstacles[_q]; if (_b.x > _o.bx0 - 30 && _b.x < _o.bx1 + 30 && _b.y > _o.by0 - 30 && _b.y < _o.by1 + 30) _near += _o.kind + " "; }
                fwy__grad(_h, _b.x, _b.y);
                _unrestAt += "hole " + string(_i) + " (" + _h.theme + ") dir " + string(_k) + " at " + string(floor(_b.x)) + "," + string(floor(_b.y)) + " speed " + string(fwy__hyp(_b.vx, _b.vy)) + " slope " + string(FWY_G * fwy__hyp(global.fwy_gx, global.fwy_gy)) + " haz [" + fwy__haz_at(_h, _b.x, _b.y) + "] near [" + _near + "]; ";
            }
            _restMax = max(_restMax, _n * FWY_DT);
        }
    }
    _st.timings.tunnelHuntMs = (get_timer() - _t1) / 1000;
    _st.notes.unrest = _unrestAt;
    _st.notes.tunnel = string(_shots) + " full-power shots, " + string(_contacts) + " rail contacts, " + string(_escapes) + " escapes, longest roll " + string(_restMax) + " s";
    fwy_st_assert(_st, _contacts > _shots * 2, "the hunt hit the rails (hard case exercised): " + string(_contacts) + " contacts in " + string(_shots) + " shots");
    fwy_st_assert(_st, _escapes == 0, "no full-power shot left the felt: " + string(_escapes) + " of " + string(_shots));
    fwy_st_assert(_st, _unrest == 0, "every shot came to rest inside 15 s (" + string(_unrest) + " did not)");

    // ------------------------------------------------------------ 40: cup, sand, water, slopes, pipe
    fwy_st_stage(_st, 40);
    var _f = fwy__layout_fallback(5, "garden");
    fwy_st_assert(_st, _f.valid && fwy_is_felt(_f, _f.teeX, _f.teeY), "the fallback hole is valid");
    // the cup: a slow putt from 60 px drops; a hard one does not
    var _px = _f.cupX - 50, _py = _f.cupY;
    var _slow = fwy_shot_sim(_f, _px, _py, 0, clamp((sqrt(2 * FWY_MU * 65) - 40) / (FWY_MAXV - 40), 0, 1), 0);
    var _fast = fwy_shot_sim(_f, _px, _py, 0, 0.9, 0);
    fwy_st_assert(_st, _slow.holed, "a walking-pace putt straight at the cup drops");
    fwy_st_assert(_st, fwy_is_felt(_f, _px, _py) && fwy__clear_of_rail(_f, _px, _py, FWY_BALL_R), "control: the putt starts on open felt");
    fwy_st_assert(_st, !_fast.holed, "a hard putt over the cup does not drop (capture speed " + string(FWY_CAPTURE) + ")");
    // sand: the same shot rolls shorter through a bunker laid across the lane
    var _plain = fwy_shot_sim(_f, _f.teeX, _f.teeY, 0, 0.35, 0);
    var _fs = fwy__layout_fallback(5, "garden");
    fwy__haz_add(_fs, "sand", [_f.teeX + 40, _f.teeX + 120, _f.teeX + 120, _f.teeX + 40], [_f.teeY - 60, _f.teeY - 60, _f.teeY + 60, _f.teeY + 60]);
    var _sandy = fwy_shot_sim(_fs, _f.teeX, _f.teeY, 0, 0.35, 0);
    fwy_st_assert(_st, _sandy.x < _plain.x - 20, "sand shortens a roll (" + string(_sandy.x - _f.teeX) + " px against " + string(_plain.x - _f.teeX) + ")");
    // water: the shot reports the spot it was struck from
    var _fw = fwy__layout_fallback(5, "garden");
    fwy__haz_add(_fw, "water", [_f.teeX + 50, _f.teeX + 90, _f.teeX + 90, _f.teeX + 50], [_f.teeY - 64, _f.teeY - 64, _f.teeY + 64, _f.teeY + 64]);
    var _wet = fwy_shot_sim(_fw, _f.teeX, _f.teeY, 0, 0.4, 0);
    fwy_st_assert(_st, _wet.water && _wet.x == _f.teeX && _wet.y == _f.teeY, "a ball in the water is replaced where it was struck");
    // slopes: a hill's west flank rises toward its top (dh/dx > 0) and a ball let go there rolls west
    var _fh = fwy__layout_fallback(5, "garden");
    array_push(_fh.relief, { kind: "hill", x: 400, y: 320, r: 50, h: 20 });
    fwy__height_grid(_fh);
    var _gr = fwy_slope_at(_fh, 360, 320);
    fwy_st_assert(_st, _gr[0] > 0.05 && abs(_gr[1]) < abs(_gr[0]) / 3, "a hill's west flank rises toward its top, mostly eastward: [" + string(_gr[0]) + ", " + string(_gr[1]) + "]");
    var _bh = fwy_ball_create(360, 320); _bh.moving = true;
    var _tt2 = 0; repeat (240) { fwy_ball_step(_fh, _bh, _tt2); _tt2 += FWY_DT; if (!_bh.moving) break; }
    fwy_st_assert(_st, _bh.x < 352, "a ball let go on the flank rolls downhill (x " + string(_bh.x) + ")");
    var _bf = fwy_ball_create(_f.teeX + 30, _f.teeY); _bf.moving = true; fwy_ball_step(_f, _bf, 0);
    fwy_st_assert(_st, !_bf.moving, "a ball on flat felt at rest stays at rest");
    // the pipe: a ball rolled over the intake comes out of the outlet
    var _fp = fwy__layout_fallback(5, "garden");
    array_push(_fp.obstacles, { kind: "pipe", bx0: 0, by0: 0, bx1: 0, by1: 0, ax: _f.teeX + 70, ay: _f.teeY, bx: FWY_OX + 4 * 128 + 64, by: FWY_OY + 1 * 128 + 110, bdir: -pi / 2 });
    var _pr = fwy_shot_sim(_fp, _f.teeX, _f.teeY, 0, 0.3, 0);
    fwy_st_assert(_st, _pr.pipe && _pr.y < FWY_OY + 1 * 128 + 110, "a ball rolled over the intake comes out of the outlet (" + string(_pr.x) + ", " + string(_pr.y) + ")");

    // ------------------------------------------------------------ 50: the moving pieces
    fwy_st_stage(_st, 50);
    var _gates = 0, _spins = 0, _mills = 0, _leaps = 0, _jumps = 0, _gateOk = true, _millFrac = [];
    for (var _i = 0; _i < array_length(_holes); _i++) {
        var _h = _holes[_i];
        for (var _q = 0; _q < array_length(_h.obstacles); _q++) {
            var _o = _h.obstacles[_q];
            if (_o.kind == "gate") {
                _gates++;
                for (var _k = 0; _k < 40; _k++) {
                    fwy__dyn(_h, _k * 0.13);
                    var _seg = global.fwy_dyn[0], _a = arctan2(_seg[3] - _seg[1], _seg[2] - _seg[0]);
                    var _d0 = angle_difference(radtodeg(-_a), radtodeg(-_o.a0)), _d1 = angle_difference(radtodeg(-_a), radtodeg(-_o.a1)), _span = abs(angle_difference(radtodeg(-_o.a0), radtodeg(-_o.a1)));
                    if (abs(_d0) > _span + 1 || abs(_d1) > _span + 1) _gateOk = false;
                }
            }
            if (_o.kind == "spinner") _spins++;
            if (_o.kind == "mill") { _mills++; var _bl = 0; for (var _k = 0; _k < 400; _k++) if (fwy__mill_blocked(_o, _k * _o.period / 400)) _bl++; array_push(_millFrac, _bl / 400); }
            if (_o.kind == "leap") _leaps++;
        }
    }
    fwy_st_assert(_st, _gateOk, "every gate swings only between its closed and open angles (" + string(_gates) + " gates)");
    var _mfOk = true; for (var _i = 0; _i < array_length(_millFrac); _i++) if (_millFrac[_i] < 0.2 || _millFrac[_i] > 0.6) _mfOk = false;
    fwy_st_assert(_st, _mfOk, "every windmill's sails close the tunnel for part of each turn, never all of it (" + string(_mills) + " mills)");
    _st.notes.moving = string(_gates) + " gates, " + string(_spins) + " spinners, " + string(_mills) + " mills, " + string(_leaps) + " leaps in the corpus";
    // a ramp jump clears its channel at pace (a hole searched for one, so the arm cannot pass by having none)
    var _lh = undefined;
    for (var _s = 1; _s < 60 && is_undefined(_lh); _s++) { var _c = fwy_hole_create(500 + _s, "pirate", { features: ["leap"], solve: false }); if (fwy__st_has_kind(_c, "leap")) _lh = _c; }
    fwy_st_assert(_st, !is_undefined(_lh), "a hole with a ramp jump can be generated");
    if (!is_undefined(_lh)) {
        var _L = undefined; for (var _q = 0; _q < array_length(_lh.obstacles); _q++) if (_lh.obstacles[_q].kind == "leap") _L = _lh.obstacles[_q];
        var _sx = (_L.rx0 + _L.rx1) / 2 - _L.dx * 60, _sy = (_L.ry0 + _L.ry1) / 2 - _L.dy * 60;
        var _ang = arctan2(_L.dy, _L.dx);
        var _jr = fwy_shot_sim(_lh, _sx, _sy, _ang, 0.75, 0), _sr = fwy_shot_sim(_lh, _sx, _sy, _ang, 0.12, 0);
        fwy_st_assert(_st, _jr.jump && !_jr.water, "a fast ball takes off from the ramp and clears the channel");
        fwy_st_assert(_st, !_sr.jump, "a slow ball does not take off");
    }

    // ------------------------------------------------------------ 60: the planner and par
    fwy_st_stage(_st, 60);
    var _rep = 0, _repOk = 0;
    for (var _i = 0; _i < array_length(_holes); _i += 3) {
        var _h = _holes[_i];
        var _b = fwy_ball_create(_h.teeX, _h.teeY);
        var _sg = fwy_shot_suggest(_h, _b, 1, 1);
        var _r1 = fwy_shot_sim(_h, _h.teeX, _h.teeY, _sg.angle, _sg.power, 1), _r2 = fwy_shot_sim(_h, _h.teeX, _h.teeY, _sg.angle, _sg.power, 1);
        _rep++;
        if (_r1.x == _r2.x && _r1.y == _r2.y && _r1.holed == _r2.holed) _repOk++;
    }
    fwy_st_assert(_st, _rep > 0 && _repOk == _rep, "a simulated shot replays to the same spot (" + string(_repOk) + " of " + string(_rep) + ")");
    var _gotCloser = 0, _tried = 0;
    for (var _i = 0; _i < array_length(_holes); _i += 3) {
        var _h = _holes[_i], _b = fwy_ball_create(_h.teeX, _h.teeY);
        var _sg = fwy_shot_suggest(_h, _b, 1, 1), _r = fwy_shot_sim(_h, _h.teeX, _h.teeY, _sg.angle, _sg.power, 1);
        _tried++;
        if (_r.holed || fwy__potential(_h, _r.x, _r.y) < fwy__potential(_h, _h.teeX, _h.teeY) - 40) _gotCloser++;
    }
    fwy_st_assert(_st, _gotCloser == _tried, "the planner's first shot always ends nearer the cup along the felt (" + string(_gotCloser) + " of " + string(_tried) + ")");
    var _sk = fwy_shot_suggest(_holes[0], fwy_ball_create(_holes[0].teeX, _holes[0].teeY), 1, 0);
    fwy_st_assert(_st, _sk.power >= 0.02 && _sk.power <= 1, "a skill-0 rival still plays a legal shot");

    // ------------------------------------------------------------ 70: a whole round between AI players
    fwy_st_stage(_st, 70);
    var _t2 = get_timer();
    var _course = fwy_course_create(9, "candy", 9);
    _st.timings.courseCreateMs = _course.buildMs;
    fwy_st_assert(_st, _course.made == 9 && _course.count == 9, "a 9-hole course is made (" + string(_course.made) + ")");
    var _cp = fwy_course_par(_course);
    var _names = {}, _dup = 0;
    for (var _i = 0; _i < 9; _i++) { var _nm = _course.holes[_i].name; if (variable_struct_exists(_names, _nm)) _dup++; _names[$ _nm] = 1; }
    fwy_st_assert(_st, _dup == 0, "no two holes of a course share a name (" + string(_dup) + " repeats)");
    var _c18 = fwy_course_create(5, "pirate", 18), _n18 = {}, _d18 = 0;
    for (var _i = 0; _i < 18; _i++) { var _nm = _c18.holes[_i].name; if (variable_struct_exists(_n18, _nm)) _d18++; _n18[$ _nm] = 1; }
    fwy_st_assert(_st, _d18 == 0, "no two holes of an 18-hole course share a name (" + string(_d18) + " repeats)");
    fwy_st_assert(_st, _cp[1] == 9 && _cp[0] >= 18 && _cp[0] <= 45, "the course par is the holes' sum, 18..45 (" + string(_cp[0]) + ")");
    var _G = fwy_game_create(_course, [{ name: "ACE", ai: 1 }, { name: "ROOKIE", ai: 0.3 }]);
    var _frames = 0, _holedN = 0, _waterN = 0, _limitN = 0, _shotN = 0;
    while (_G.state != "done" && _frames < 60 * 60 * 30) {
        fwy_game_step(_G, 1 / 60); _frames++;
        for (var _e = 0; _e < array_length(_G.events); _e++) { var _ty = _G.events[_e].type; if (_ty == "holed") _holedN++; if (_ty == "water") _waterN++; if (_ty == "limit") _limitN++; if (_ty == "shot") _shotN++; }
    }
    _st.timings.roundMs = (get_timer() - _t2) / 1000;
    fwy_st_assert(_st, _G.state == "done", "the round finishes (" + string(_frames) + " frames)");
    var _allScored = true, _range = true;
    for (var _p = 0; _p < 2; _p++) for (var _i = 0; _i < 9; _i++) { var _s = _G.scores[_p][_i]; if (_s < 0) _allScored = false; if (_s < 1 || _s > FWY_LIMIT) _range = false; }
    fwy_st_assert(_st, _allScored && _range, "every player has a score of 1.." + string(FWY_LIMIT) + " on every hole");
    var _ta = fwy_game_total(_G, 0), _tb = fwy_game_total(_G, 1);
    _st.notes.round = "ACE " + string(_ta[0]) + " ROOKIE " + string(_tb[0]) + " (par " + string(_ta[1]) + "), holed " + string(_holedN) + ", water " + string(_waterN) + ", picked up " + string(_limitN) + ", shots " + string(_shotN);
    fwy_st_assert(_st, _ta[2] == 9 && _ta[1] == _cp[0], "totals cover all 9 holes against the course par");
    fwy_st_assert(_st, _ta[0] <= _tb[0], "the skill-1 rival does not lose to the skill-0.3 rival (" + string(_ta[0]) + " v " + string(_tb[0]) + ")");
    fwy_st_assert(_st, _holedN + _limitN == 18, "18 hole results reported as events (" + string(_holedN) + " holed + " + string(_limitN) + " picked up)");
    fwy_st_assert(_st, _shotN >= 18, "at least one shot per player per hole (" + string(_shotN) + ")");
    fwy_st_assert(_st, fwy_score_name(1, 3) == "HOLE IN ONE" && fwy_score_name(2, 3) == "BIRDIE" && fwy_score_name(3, 3) == "PAR" && fwy_score_name(5, 3) == "DOUBLE BOGEY" && fwy_score_name(7, 3) == "+4", "score names");
    fwy_st_assert(_st, fwy_game_shoot(_G, 0, 0.5) == false, "a finished game refuses a shot");

    // ------------------------------------------------------------ 80: refusals on bad input
    fwy_st_stage(_st, 80);
    fwy_st_assert(_st, fwy_hole_create("x", 12).theme == "garden", "a bad seed and theme still make a hole");
    fwy_st_assert(_st, fwy_is_felt(undefined, 1, 2) == false && fwy_is_felt(_f, "a", 2) == false, "fwy_is_felt refuses bad input");
    var _sl = fwy_slope_at(undefined, 0, 0); fwy_st_assert(_st, _sl[0] == 0 && _sl[1] == 0, "fwy_slope_at refuses a non-hole");
    fwy_st_assert(_st, fwy_ball_shoot(undefined, 0, 1) == false && fwy_ball_shoot(fwy_ball_create(0, 0), "up", 1) == false, "fwy_ball_shoot refuses bad input");
    var _sm = fwy_shot_sim(undefined, 0, 0, 0, 1, 0); fwy_st_assert(_st, !_sm.holed && _sm.time == 0, "fwy_shot_sim refuses a non-hole");
    var _sg2 = fwy_shot_suggest(undefined, undefined, 0); fwy_st_assert(_st, _sg2.power == 0.5, "fwy_shot_suggest refuses a non-hole");
    fwy_st_assert(_st, is_undefined(fwy_game_create(undefined, [])), "fwy_game_create refuses a non-course");
    fwy_st_assert(_st, is_undefined(fwy_course_hole(_course, 40)) && is_undefined(fwy_course_hole(_course, -1)), "fwy_course_hole refuses an index off the course");
    fwy_st_assert(_st, fwy_hole_bake(undefined) == -1 && fwy_hole_draw({}, 0, 0) == false && fwy_piece_draw("garden", "teapot", 0, 0) == false && fwy_piece_draw("nowhere", "mill", 0, 0) == false, "the draw calls refuse bad input");

    // ------------------------------------------------------------ 90: bakes, pieces, card, play frame
    fwy_st_stage(_st, 90);
    var _blank = surface_create(64, 64);
    surface_set_target(_blank); draw_clear_alpha(make_colour_rgb(239, 230, 210), 1); surface_reset_target();
    var _brd = fwy__st_read(_blank), _bpx = fwy__st_px(_brd, 3, 3);
    buffer_delete(_brd.buf); surface_free(_blank);
    _st.notes.blankBytes = string(_bpx[0]) + "," + string(_bpx[1]) + "," + string(_bpx[2]) + "," + string(_bpx[3]);
    fwy_st_assert(_st, _bpx[0] == 239 && _bpx[1] == 230 && _bpx[2] == 210, "a blank surface reads back R, G, B (the ink counter's control)");
    var _bakeMs = 0;
    for (var _t = 0; _t < array_length(_themes); _t++) {
        var _h = _holes[_t * 5 + 2];
        var _spr = fwy_hole_bake(_h, 1);
        _bakeMs = max(_bakeMs, _h.bakeMs);
        var _sf = surface_create(FWY_W, FWY_H);
        surface_set_target(_sf); draw_clear_alpha(c_black, 1);
        fwy_hole_draw(_h, 0, 0, 1, 1.3);
        var _bb = fwy_ball_create(_h.teeX, _h.teeY);
        fwy_ball_draw(_bb, 0, 0, 1, c_white);
        fwy_hole_draw_over(_h, 0, 0, 1, 1.3);
        surface_reset_target();
        surface_save(_sf, "fwy_render_hole_" + _themes[_t] + ".png");
        var _rd = fwy__st_read(_sf);
        var _cols = fwy__st_colours(_rd);
        fwy_st_assert(_st, fwy__st_ink(_rd, [0, 0, 0], 8) > FWY_W * FWY_H * 0.95, _themes[_t] + ": the bake fills the hole");
        fwy_st_assert(_st, _cols > 60, _themes[_t] + ": the bake is a drawn picture (" + string(_cols) + " colours)");
        var _fp2 = fwy__st_px(_rd, _h.cupX - 6, _h.cupY + 3);
        fwy_st_assert(_st, _fp2[0] < 90 && _fp2[1] < 90 && _fp2[2] < 90, _themes[_t] + ": the cup is dark inside (beside the pole): " + string(_fp2[0]) + "," + string(_fp2[1]) + "," + string(_fp2[2]));
        buffer_delete(_rd.buf); surface_free(_sf);
        fwy_st_assert(_st, sprite_exists(_spr) && sprite_get_width(_spr) == FWY_W, _themes[_t] + ": the hole sprite is kept at " + string(FWY_W) + " px");
        // the view frames the felt: every felt cell centre lands inside the box, the crop inside the world
        var _boxes = [[900, 520], [392, 176], [300, 500]];
        for (var _bq = 0; _bq < 3; _bq++) {
            var _BW = _boxes[_bq][0], _BH = _boxes[_bq][1], _vw = fwy_hole_view(_h, _BW, _BH), _vin = true;
            for (var _cy = 0; _cy < FWY_GH; _cy++) for (var _cx = 0; _cx < FWY_GW; _cx++) if (fwy__cell(_h, _cx, _cy) != 0) for (var _cq = 0; _cq < 4; _cq++) { var _sx = _vw.x + (FWY_OX + (_cx + (_cq mod 2)) * FWY_CELL) * _vw.scale, _sy = _vw.y + (FWY_OY + (_cy + (_cq div 2)) * FWY_CELL) * _vw.scale; if (_sx < -0.5 || _sx > _BW + 0.5 || _sy < -0.5 || _sy > _BH + 0.5) _vin = false; }
            fwy_st_assert(_st, _vin && _vw.scale > 0, _themes[_t] + ": a " + string(_BW) + " x " + string(_BH) + " view keeps every felt cell corner inside the box (scale " + string(_vw.scale) + ")");
        }
    }
    _st.timings.bakeWorstMs = _bakeMs;
    // the same bake under a caller's 2x transform: same ink, the caller's matrix handed back (wing doctrine s19)
    var _h0 = _holes[0];
    var _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_build(0, 0, 0, 0, 0, 0, 2, 2, 1));
    fwy_hole_bake(_h0, 0.5);
    var _back = matrix_get(matrix_world);
    matrix_set(matrix_world, _mw);
    fwy_st_assert(_st, _back[0] == 2 && _back[5] == 2, "a bake under a 2x transform hands the caller's matrix back");
    var _sf3 = surface_create(FWY_W / 2, FWY_H / 2);
    surface_set_target(_sf3); draw_clear_alpha(c_black, 1); draw_sprite(_h0.sprite, 0, 0, 0); surface_reset_target();
    var _rd3 = fwy__st_read(_sf3);
    fwy_st_assert(_st, fwy__st_ink(_rd3, [0, 0, 0], 8) > FWY_W * FWY_H / 4 * 0.95, "the half-scale bake made under a 2x transform still fills its sprite");
    buffer_delete(_rd3.buf); surface_free(_sf3);
    fwy_hole_bake(_h0, 1);
    // the pieces: every piece of every theme draws ink
    var _sf4 = surface_create(1200, 760);
    surface_set_target(_sf4); draw_clear_alpha(make_colour_rgb(239, 230, 210), 1);
    var _pc = fwy_pieces(), _emptyP = 0;
    for (var _t = 0; _t < 6; _t++) for (var _q = 0; _q < array_length(_pc); _q++) {
        var _cx = 70 + _q * 112, _cy = 80 + _t * 120;
        fwy_piece_draw(_themes[_t], _pc[_q], _cx, _cy + ((_pc[_q] == "mill") ? 20 : 0), (_pc[_q] == "mill") ? 0.62 : 1, (_pc[_q] == "gate") ? 0 : -pi / 2, _q + _t, 0.2);
    }
    surface_reset_target();
    surface_save(_sf4, "fwy_render_pieces.png");
    var _rd4 = fwy__st_read(_sf4);
    for (var _t = 0; _t < 6; _t++) for (var _q = 0; _q < array_length(_pc); _q++) {
        var _cx = 70 + _q * 112, _cy = 80 + _t * 120, _ink = 0;
        for (var _y = _cy - 40; _y < _cy + 40; _y += 2) for (var _x = _cx - 40; _x < _cx + 40; _x += 2) { var _p = fwy__st_px(_rd4, _x, _y); if (abs(_p[0] - 239) > 12 || abs(_p[1] - 230) > 12 || abs(_p[2] - 210) > 12) _ink++; }
        if (_ink < 60) _emptyP++;
    }
    fwy_st_assert(_st, _emptyP == 0, "all 60 pieces (6 themes x 10) draw ink in their cell (" + string(_emptyP) + " empty)");
    buffer_delete(_rd4.buf); surface_free(_sf4);
    // the scorecard
    var _sf5 = surface_create(800, 400);
    surface_set_target(_sf5); draw_clear_alpha(make_colour_rgb(40, 60, 40), 1);
    var _ch = fwy_scorecard_draw(_G, 30, 30, 740);
    surface_reset_target();
    surface_save(_sf5, "fwy_render_card.png");
    var _rd5 = fwy__st_read(_sf5);
    fwy_st_assert(_st, _ch > 150 && _ch < 360, "the card is drawn, " + string(_ch) + " px tall for two players");
    fwy_st_assert(_st, fwy__st_ink(_rd5, [40, 60, 40], 10) > 740 * _ch * 0.8, "the card covers its own area");
    buffer_delete(_rd5.buf); surface_free(_sf5);
    // a play frame: the demo's own (HUD, aim, gauge, banner, key line)
    var _D = fwy_demo_create(3, "haunted");
    var _hh = fwy_game_hole(_D.game);
    var _sf6 = surface_create(960, 640);
    surface_set_target(_sf6); draw_clear_alpha(c_black, 1);
    fwy_demo_draw(_D);
    surface_reset_target();
    surface_save(_sf6, "fwy_render_play.png");
    var _rd6 = fwy__st_read(_sf6);
    fwy_st_assert(_st, fwy__st_ink(_rd6, [0, 0, 0], 8) > 960 * 640 * 0.85, "the play frame fills the room");
    buffer_delete(_rd6.buf); surface_free(_sf6);
    for (var _i = 0; _i < array_length(_holes); _i++) fwy_hole_free(_holes[_i]);
    fwy_demo_free(_D);
    fwy_draw_free();
    fwy_st_stage(_st, 99);
    return _st;
}

/// @function fwy_selftest_write(state)
/// @description Write the suite's result as fwy_selftest.json in the save folder.
function fwy_selftest_write(_st) {
    var _f = file_text_open_write("fwy_selftest.json");
    file_text_write_string(_f, json_stringify(_st));
    file_text_close(_f);
}
