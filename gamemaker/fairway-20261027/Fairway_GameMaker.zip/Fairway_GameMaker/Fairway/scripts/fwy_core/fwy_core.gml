/// fwy_core.gml - Fairway's game layer, in pure GML with NO drawing calls: the seeded hole generator (a lane walked on a
/// grid, widened into greens, its corners cut into 45 degree banks, its rails built as merged wall segments), the height
/// field (hills, hollows, tilted ramps, the bowl round the cup) and its gradient, hazards (water, sand), obstacles (windmill,
/// swing gate, spinner, bumpers, wedges, pipe, ramp jump), the ball physics with sub-steps so a full-power shot cannot pass
/// through a rail, the shot planner that sets every hole's par and plays the AI rivals, courses of 9 or 18 holes, and the
/// game (turns, strokes, penalties, the stroke limit, the scorecard). The scenery round each hole is laid out here as DATA,
/// so fwy_draw only paints what was decided.
///
/// Public functions (each documented below): fwy_rng, fwy_rand, fwy_range, fwy_themes, fwy_theme, fwy_hole_create,
/// fwy_is_felt, fwy_slope_at, fwy_ball_create, fwy_ball_shoot, fwy_ball_step, fwy_shot_sim, fwy_shot_suggest,
/// fwy_course_create, fwy_course_hole, fwy_course_par, fwy_game_create, fwy_game_step, fwy_game_shoot, fwy_game_ball,
/// fwy_game_hole, fwy_game_scores, fwy_game_total, fwy_score_name.
///
/// Units: pixels and seconds; angles in radians in room space (y down, 0 faces +x). A hole is 960 x 576 world pixels: a
/// 14 x 8 grid of 64 px cells set 32 px in from the edge, so the rails round it always have room to be drawn.
///
/// Fairway - Mini Golf for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

#macro FWY_CELL 64
#macro FWY_GW 14
#macro FWY_GH 8
#macro FWY_MW 7
#macro FWY_MH 4
#macro FWY_OX 32
#macro FWY_OY 32
#macro FWY_W 960
#macro FWY_H 576
#macro FWY_BALL_R 7
#macro FWY_CUP_R 11
#macro FWY_HG 16
#macro FWY_G 900
#macro FWY_MU 200
#macro FWY_MU_SAND 900
#macro FWY_MAXV 900
#macro FWY_DT 0.008333333333
#macro FWY_CAPTURE 300
#macro FWY_LIMIT 8

// ------------------------------------------------------------------------------------------------ the generator

/// @function fwy__mask()
/// @description Internal. 0xFFFFFFFF as an int64.
function fwy__mask() { return int64($FFFFFFFF); }

/// @function fwy__mix32(value)
/// @description Internal. A 32-bit integer hash (two multiply-xorshift rounds).
function fwy__mix32(_v) {
    var _m = fwy__mask();
    var _s = int64(floor(_v)) & _m;
    _s = ((_s ^ (_s >> 16)) * int64($45D9F3B)) & _m;
    _s = ((_s ^ (_s >> 16)) * int64($45D9F3B)) & _m;
    _s = (_s ^ (_s >> 16)) & _m;
    return _s;
}

/// @function fwy_rng(seed)
/// @description A seeded generator (xorshift32). The seed is hashed first and three draws are discarded, so nearby seeds do
/// not give nearby first draws.
/// @param {Real} seed  any whole number
/// @returns {Struct} a generator for fwy_rand / fwy_range
function fwy_rng(_seed) {
    if (!is_numeric(_seed)) _seed = 1;
    var _s = fwy__mix32(floor(_seed) * 7919 + 104729);
    if (_s == 0) _s = int64(1);
    var _g = { s: _s };
    fwy_rand(_g); fwy_rand(_g); fwy_rand(_g);
    return _g;
}

/// @function fwy_rand(generator)
/// @description The next draw in [0, 1). A non-generator returns 0.
function fwy_rand(_g) {
    if (!is_struct(_g) || !variable_struct_exists(_g, "s")) return 0;
    var _m = fwy__mask();
    var _x = int64(_g.s) & _m;
    _x = _x ^ ((_x << 13) & _m);
    _x = _x ^ (_x >> 17);
    _x = _x ^ ((_x << 5) & _m);
    _x = _x & _m;
    _g.s = _x;
    return real(_x) / 4294967296;
}

/// @function fwy_range(generator, lo, hi)
/// @description A draw in [lo, hi). A bound that is not a number reads as 0 (lo) or 1 (hi).
function fwy_range(_g, _a, _b) {
    if (!is_numeric(_a)) _a = 0;
    if (!is_numeric(_b)) _b = 1;
    return _a + (_b - _a) * fwy_rand(_g);
}

/// @function fwy__hyp(dx, dy)
/// @description Internal. sqrt(dx*dx + dy*dy).
function fwy__hyp(_x, _y) { return sqrt(_x * _x + _y * _y); }

// ------------------------------------------------------------------------------------------------ themes

/// @function fwy_themes()
/// @description The six theme names, in order.
/// @returns {Array<String>}
function fwy_themes() { return ["garden", "pirate", "haunted", "candy", "space", "desert"]; }

/// @function fwy_theme(name)
/// @description A theme's description: its course title, the name of its water, what its windmill, pipe and bumpers are, and
/// the obstacle kinds it favours. An unknown name returns the garden.
/// @param {String} name  one of fwy_themes()
/// @returns {Struct} { name, title, water, sand, mill, pipe, bumper, rail, favour[] }
function fwy_theme(_name) {
    if (!is_string(_name)) _name = "garden";
    switch (_name) {
        case "pirate":  return { name: "pirate",  title: "Smuggler's Cove", water: "lagoon", sand: "beach", mill: "lighthouse", pipe: "cannon", bumper: "barrel", rail: "rope and plank", favour: ["leap", "pipe", "bumpers"] };
        case "haunted": return { name: "haunted", title: "Hollow Manor", water: "bog", sand: "grave dirt", mill: "manor", pipe: "coffin", bumper: "headstone", rail: "iron and stone", favour: ["gate", "spinner", "hills"] };
        case "candy":   return { name: "candy",   title: "Sweetshop Lane", water: "syrup", sand: "sugar", mill: "gingerbread mill", pipe: "candy tube", bumper: "gumdrop", rail: "candy cane", favour: ["bumpers", "spinner", "hills"] };
        case "space":   return { name: "space",   title: "Orbit Station", water: "void", sand: "regolith", mill: "reactor", pipe: "teleporter", bumper: "beacon", rail: "steel", favour: ["pipe", "spinner", "leap"] };
        case "desert":  return { name: "desert",  title: "Sunken Ruins", water: "quicksand", sand: "dune", mill: "water wheel tower", pipe: "sarcophagus", bumper: "urn", rail: "sandstone", favour: ["sand", "wedges", "mill"] };
    }
    return { name: "garden", title: "The Rose Garden", water: "pond", sand: "bunker", mill: "windmill", pipe: "hollow log", bumper: "flower pot", rail: "timber", favour: ["mill", "gate", "sand"] };
}

/// @function fwy__theme_ok(name)
/// @description Internal. Whether name is a known theme.
function fwy__theme_ok(_n) { if (!is_string(_n)) return false; var _t = fwy_themes(); for (var _i = 0; _i < array_length(_t); _i++) if (_t[_i] == _n) return true; return false; }

// ------------------------------------------------------------------------------------------------ cells and felt

/// @function fwy__cell(hole, cx, cy)
/// @description Internal. The cell type at (cx, cy): 0 empty, 1 felt, 2..5 a half cell (2 NE corner cut, 3 NW, 4 SE, 5 SW).
function fwy__cell(_h, _cx, _cy) { if (_cx < 0 || _cy < 0 || _cx >= FWY_GW || _cy >= FWY_GH) return 0; return _h.cells[_cy * FWY_GW + _cx]; }

/// @function fwy__side_felt(type, side)
/// @description Internal. Whether a cell of this type is felt along its whole side (0 N, 1 E, 2 S, 3 W).
function fwy__side_felt(_t, _s) {
    switch (_t) {
        case 1: return true;
        case 2: return (_s == 3 || _s == 2);
        case 3: return (_s == 1 || _s == 2);
        case 4: return (_s == 0 || _s == 3);
        case 5: return (_s == 0 || _s == 1);
    }
    return false;
}

/// @function fwy_is_felt(hole, x, y)
/// @description Whether a world point lies on the hole's playing surface (half cells included by their diagonal).
/// @param {Struct} hole  from fwy_hole_create
/// @returns {Bool}
function fwy_is_felt(_h, _x, _y) {
    if (!is_struct(_h) || !variable_struct_exists(_h, "cells") || !is_numeric(_x) || !is_numeric(_y)) return false;
    var _gx = (_x - FWY_OX) / FWY_CELL, _gy = (_y - FWY_OY) / FWY_CELL;
    var _cx = floor(_gx), _cy = floor(_gy);
    var _t = fwy__cell(_h, _cx, _cy);
    if (_t <= 1) return (_t == 1);
    var _u = _gx - _cx, _v = _gy - _cy;
    switch (_t) { case 2: return _v >= _u; case 3: return _u + _v >= 1; case 4: return _u + _v <= 1; case 5: return _v <= _u; }
    return false;
}

/// @function fwy__walk(g, lo, hi)
/// @description Internal. A self-avoiding walk on the 7 x 4 lane grid in which no lane cell touches another except the one
/// before and after it, so every lane is walled from every other. Returns an array of [mx, my] or undefined.
function fwy__walk(_g, _lo, _hi) {
    var _best = undefined;
    var _dx = [1, 0, -1, 0], _dy = [0, 1, 0, -1];
    repeat (90) {
        var _occ = array_create(FWY_MW * FWY_MH, -1);
        var _sx, _sy, _d;
        var _side = floor(fwy_rand(_g) * 4);
        if (_side == 0) { _sx = 0; _sy = floor(fwy_rand(_g) * FWY_MH); _d = 0; }
        else if (_side == 1) { _sx = FWY_MW - 1; _sy = floor(fwy_rand(_g) * FWY_MH); _d = 2; }
        else if (_side == 2) { _sx = floor(fwy_rand(_g) * FWY_MW); _sy = 0; _d = 1; }
        else { _sx = floor(fwy_rand(_g) * FWY_MW); _sy = FWY_MH - 1; _d = 3; }
        var _path = [[_sx, _sy]];
        _occ[_sy * FWY_MW + _sx] = 0;
        var _target = _lo + floor(fwy_rand(_g) * (_hi - _lo + 1));
        while (array_length(_path) < _target) {
            var _cur = _path[array_length(_path) - 1];
            var _opts = [], _w = [], _wt = 0;
            for (var _k = 0; _k < 4; _k++) {
                if (_k == (_d + 2) mod 4) continue;
                var _nx = _cur[0] + _dx[_k], _ny = _cur[1] + _dy[_k];
                if (_nx < 0 || _ny < 0 || _nx >= FWY_MW || _ny >= FWY_MH) continue;
                if (_occ[_ny * FWY_MW + _nx] >= 0) continue;
                var _ok = true;
                for (var _q = 0; _q < 4; _q++) {
                    var _ax = _nx + _dx[_q], _ay = _ny + _dy[_q];
                    if (_ax < 0 || _ay < 0 || _ax >= FWY_MW || _ay >= FWY_MH) continue;
                    if (_occ[_ay * FWY_MW + _ax] >= 0 && !(_ax == _cur[0] && _ay == _cur[1])) { _ok = false; break; }
                }
                if (!_ok) continue;
                var _wk = (_k == _d) ? 3 : 1;
                array_push(_opts, _k); array_push(_w, _wk); _wt += _wk;
            }
            if (array_length(_opts) == 0) break;
            var _r = fwy_rand(_g) * _wt, _pick = _opts[0];
            for (var _q = 0; _q < array_length(_opts); _q++) { _r -= _w[_q]; if (_r < 0) { _pick = _opts[_q]; break; } }
            _d = _pick;
            var _nn = [_cur[0] + _dx[_d], _cur[1] + _dy[_d]];
            _occ[_nn[1] * FWY_MW + _nn[0]] = array_length(_path);
            array_push(_path, _nn);
        }
        if (array_length(_path) >= _lo) return _path;
        if (is_undefined(_best) || array_length(_path) > array_length(_best)) _best = _path;
    }
    return _best;
}

/// @function fwy__corners(cells)
/// @description Internal. Cut convex corners into 45 degree banks and fill concave ones (in place, from a snapshot).
function fwy__corners(_h, _g, _cut, _fill) {
    var _src = array_create(FWY_GW * FWY_GH, 0);
    array_copy(_src, 0, _h.cells, 0, FWY_GW * FWY_GH);
    var _at = function(_s, _x, _y) { if (_x < 0 || _y < 0 || _x >= FWY_GW || _y >= FWY_GH) return 0; return _s[_y * FWY_GW + _x]; };
    // corner c: [dx1, dy1, dx2, dy2, missing-type, keep-type]  NE, NW, SE, SW
    var _C = [[0, -1, 1, 0, 2, 5], [0, -1, -1, 0, 3, 4], [0, 1, 1, 0, 4, 3], [0, 1, -1, 0, 5, 2]];
    for (var _y = 0; _y < FWY_GH; _y++) for (var _x = 0; _x < FWY_GW; _x++) {
        var _t = _src[_y * FWY_GW + _x];
        for (var _c = 0; _c < 4; _c++) {
            var _a = _C[_c];
            var _o1 = _at(_src, _x + _a[0], _y + _a[1]), _o2 = _at(_src, _x + _a[2], _y + _a[3]);
            var _dg = _at(_src, _x + _a[0] + _a[2], _y + _a[1] + _a[3]);
            var _p1 = _at(_src, _x - _a[0], _y - _a[1]), _p2 = _at(_src, _x - _a[2], _y - _a[3]);
            if (_t == 1 && _o1 == 0 && _o2 == 0 && _dg == 0 && _p1 == 1 && _p2 == 1) {
                if (fwy_rand(_g) < _cut) { _h.cells[_y * FWY_GW + _x] = _a[4]; break; }
            } else if (_t == 0 && _o1 == 1 && _o2 == 1 && _dg == 1 && _p1 == 0 && _p2 == 0) {
                if (fwy_rand(_g) < _fill) { _h.cells[_y * FWY_GW + _x] = _a[5]; break; }
            }
        }
    }
}

/// @function fwy__walls(hole)
/// @description Internal. Every boundary edge between felt and not-felt as a segment oriented so (-dy, dx) points INTO the
/// felt, merged into straight runs, then chained into closed loops for the rail drawing.
function fwy__walls(_h) {
    var _raw = [];
    var _C = FWY_CELL;
    for (var _cy = 0; _cy < FWY_GH; _cy++) for (var _cx = 0; _cx < FWY_GW; _cx++) {
        var _t = fwy__cell(_h, _cx, _cy);
        if (_t == 0) continue;
        var _x0 = FWY_OX + _cx * _C, _y0 = FWY_OY + _cy * _C, _x1 = _x0 + _C, _y1 = _y0 + _C;
        if (fwy__side_felt(_t, 0) && !fwy__side_felt(fwy__cell(_h, _cx, _cy - 1), 2)) array_push(_raw, [_x0, _y0, _x1, _y0]);
        if (fwy__side_felt(_t, 1) && !fwy__side_felt(fwy__cell(_h, _cx + 1, _cy), 3)) array_push(_raw, [_x1, _y0, _x1, _y1]);
        if (fwy__side_felt(_t, 2) && !fwy__side_felt(fwy__cell(_h, _cx, _cy + 1), 0)) array_push(_raw, [_x1, _y1, _x0, _y1]);
        if (fwy__side_felt(_t, 3) && !fwy__side_felt(fwy__cell(_h, _cx - 1, _cy), 1)) array_push(_raw, [_x0, _y1, _x0, _y0]);
        if (_t == 2) array_push(_raw, [_x0, _y0, _x1, _y1]);
        if (_t == 3) array_push(_raw, [_x0, _y1, _x1, _y0]);
        if (_t == 4) array_push(_raw, [_x1, _y0, _x0, _y1]);
        if (_t == 5) array_push(_raw, [_x1, _y1, _x0, _y0]);
    }
    // chain into loops: key = start point
    var _n = array_length(_raw), _used = array_create(_n, false), _byStart = {};
    for (var _i = 0; _i < _n; _i++) {
        var _k = string(_raw[_i][0]) + "_" + string(_raw[_i][1]);
        if (!variable_struct_exists(_byStart, _k)) _byStart[$ _k] = [];
        array_push(_byStart[$ _k], _i);
    }
    var _loops = [];
    for (var _s = 0; _s < _n; _s++) {
        if (_used[_s]) continue;
        var _chain = [], _cur = _s, _guard = 0;
        while (_cur >= 0 && !_used[_cur] && _guard < _n + 2) {
            _used[_cur] = true; array_push(_chain, _cur); _guard++;
            var _e = _raw[_cur], _kk = string(_e[2]) + "_" + string(_e[3]), _nxt = -1;
            if (variable_struct_exists(_byStart, _kk)) { var _l = _byStart[$ _kk]; for (var _q = 0; _q < array_length(_l); _q++) if (!_used[_l[_q]]) { _nxt = _l[_q]; break; } }
            _cur = _nxt;
        }
        // merge collinear runs inside the chain into points of a polygon
        var _xs = [], _ys = [];
        for (var _q = 0; _q < array_length(_chain); _q++) {
            var _e = _raw[_chain[_q]];
            var _pv = _raw[_chain[(_q + array_length(_chain) - 1) mod array_length(_chain)]];
            var _d1x = sign(_pv[2] - _pv[0]), _d1y = sign(_pv[3] - _pv[1]), _d2x = sign(_e[2] - _e[0]), _d2y = sign(_e[3] - _e[1]);
            if (_q == 0 || _d1x != _d2x || _d1y != _d2y) { array_push(_xs, _e[0]); array_push(_ys, _e[1]); }
        }
        var _closed = (array_length(_chain) > 2) && (_raw[_chain[array_length(_chain) - 1]][2] == _raw[_chain[0]][0]) && (_raw[_chain[array_length(_chain) - 1]][3] == _raw[_chain[0]][1]);
        if (!_closed) { var _le = _raw[_chain[array_length(_chain) - 1]]; array_push(_xs, _le[2]); array_push(_ys, _le[3]); }
        array_push(_loops, { xs: _xs, ys: _ys, closed: _closed });
    }
    _h.loops = _loops;
    // the collision segments are the loop edges
    _h.segs = [];
    for (var _l = 0; _l < array_length(_loops); _l++) {
        var _L = _loops[_l], _m = array_length(_L.xs), _last = _L.closed ? _m : _m - 1;
        for (var _q = 0; _q < _last; _q++) { var _j = (_q + 1) mod _m; fwy__seg_add(_h, _L.xs[_q], _L.ys[_q], _L.xs[_j], _L.ys[_j], 0.72, "rail"); }
    }
    _h.railSegs = array_length(_h.segs);
}

/// @function fwy__seg_add(hole, x1, y1, x2, y2, restitution, kind)
/// @description Internal. One static collision segment.
function fwy__seg_add(_h, _x1, _y1, _x2, _y2, _e, _kind) { array_push(_h.segs, { x1: _x1, y1: _y1, x2: _x2, y2: _y2, e: _e, kind: _kind }); }

// ------------------------------------------------------------------------------------------------ height field

/// @function fwy__height_raw(hole, x, y)
/// @description Internal. The analytic height at a point: hills and hollows (gaussian), tilted ramps (linear, faded at their
/// edges), the cup bowl.
function fwy__height_raw(_h, _x, _y) {
    var _z = 0, _F = _h.relief;
    for (var _i = 0; _i < array_length(_F); _i++) {
        var _f = _F[_i];
        if (_f.kind == "hill") {
            var _dx = _x - _f.x, _dy = _y - _f.y, _q = (_dx * _dx + _dy * _dy) / (_f.r * _f.r);
            if (_q < 9) _z += _f.h * exp(-_q);
        } else {
            if (_x < _f.x0 || _x > _f.x1 || _y < _f.y0 || _y > _f.y1) continue;
            var _m = min(_x - _f.x0, _f.x1 - _x, _y - _f.y0, _f.y1 - _y) / 20;
            _m = clamp(_m, 0, 1); _m = _m * _m * (3 - 2 * _m);
            _z += _m * (_f.sx * (_x - (_f.x0 + _f.x1) / 2) + _f.sy * (_y - (_f.y0 + _f.y1) / 2));
        }
    }
    return _z;
}

/// @function fwy__height_grid(hole)
/// @description Internal. The height sampled every FWY_HG px (57 x 33 nodes), read back bilinearly by the physics and the
/// shading.
function fwy__height_grid(_h) {
    var _nw = FWY_W div FWY_HG + 1, _nh = FWY_H div FWY_HG + 1;
    _h.hgW = _nw; _h.hgH = _nh;
    _h.hg = array_create(_nw * _nh, 0);
    var _hmax = 0;
    for (var _j = 0; _j < _nh; _j++) for (var _i = 0; _i < _nw; _i++) {
        var _z = fwy__height_raw(_h, _i * FWY_HG, _j * FWY_HG);
        _h.hg[_j * _nw + _i] = _z;
        _hmax = max(_hmax, abs(_z));
    }
    _h.hmax = _hmax;
}

/// @function fwy_slope_at(hole, x, y)
/// @description The ground's gradient at a point, as [dh/dx, dh/dy] (height rises along the vector; a ball is pushed the
/// other way). Off the field it is [0, 0].
/// @param {Struct} hole  from fwy_hole_create
/// @returns {Array<Real>}
function fwy_slope_at(_h, _x, _y) {
    if (!is_struct(_h) || !variable_struct_exists(_h, "hg") || !is_numeric(_x) || !is_numeric(_y)) return [0, 0];
    fwy__grad(_h, _x, _y);
    return [global.fwy_gx, global.fwy_gy];
}

/// @function fwy__grad(hole, x, y)
/// @description Internal. The bilinear gradient into global.fwy_gx / global.fwy_gy (no allocation: the physics calls it every
/// sub-step).
function fwy__grad(_h, _x, _y) {
    var _fx = clamp(_x / FWY_HG, 0, _h.hgW - 1.001), _fy = clamp(_y / FWY_HG, 0, _h.hgH - 1.001);
    var _i = floor(_fx), _j = floor(_fy); _fx -= _i; _fy -= _j;
    var _w = _h.hgW, _o = _j * _w + _i;
    var _a = _h.hg[_o], _b = _h.hg[_o + 1], _c = _h.hg[_o + _w], _d = _h.hg[_o + _w + 1];
    global.fwy_gx = ((_b - _a) * (1 - _fy) + (_d - _c) * _fy) / FWY_HG;
    global.fwy_gy = ((_c - _a) * (1 - _fx) + (_d - _b) * _fx) / FWY_HG;
}

/// @function fwy__height_at(hole, x, y)
/// @description Internal. The bilinear height at a point.
function fwy__height_at(_h, _x, _y) {
    var _fx = clamp(_x / FWY_HG, 0, _h.hgW - 1.001), _fy = clamp(_y / FWY_HG, 0, _h.hgH - 1.001);
    var _i = floor(_fx), _j = floor(_fy); _fx -= _i; _fy -= _j;
    var _w = _h.hgW, _o = _j * _w + _i;
    return lerp(lerp(_h.hg[_o], _h.hg[_o + 1], _fx), lerp(_h.hg[_o + _w], _h.hg[_o + _w + 1], _fx), _fy);
}

// ------------------------------------------------------------------------------------------------ hazards and buckets

/// @function fwy__in_poly(xs, ys, x, y)
/// @description Internal. Even-odd point in polygon.
function fwy__in_poly(_xs, _ys, _x, _y) {
    var _in = false, _n = array_length(_xs), _j = _n - 1;
    for (var _i = 0; _i < _n; _i++) {
        if (((_ys[_i] > _y) != (_ys[_j] > _y)) && (_x < (_xs[_j] - _xs[_i]) * (_y - _ys[_i]) / (_ys[_j] - _ys[_i]) + _xs[_i])) _in = !_in;
        _j = _i;
    }
    return _in;
}

/// @function fwy__haz_at(hole, x, y)
/// @description Internal. "water", "sand" or "" at a point.
function fwy__haz_at(_h, _x, _y) {
    var _Z = _h.hazards;
    for (var _i = 0; _i < array_length(_Z); _i++) {
        var _z = _Z[_i];
        if (_x < _z.bx0 || _x > _z.bx1 || _y < _z.by0 || _y > _z.by1) continue;
        if (fwy__in_poly(_z.xs, _z.ys, _x, _y)) return _z.kind;
    }
    return "";
}

/// @function fwy__haz_add(hole, kind, xs, ys)
/// @description Internal. A hazard polygon with its bounding box.
function fwy__haz_add(_h, _kind, _xs, _ys) {
    var _x0 = 1000000000, _y0 = 1000000000, _x1 = -1000000000, _y1 = -1000000000;
    for (var _i = 0; _i < array_length(_xs); _i++) { _x0 = min(_x0, _xs[_i]); _y0 = min(_y0, _ys[_i]); _x1 = max(_x1, _xs[_i]); _y1 = max(_y1, _ys[_i]); }
    var _z = { kind: _kind, xs: _xs, ys: _ys, bx0: _x0, by0: _y0, bx1: _x1, by1: _y1 };
    array_push(_h.hazards, _z);
    return _z;
}

/// @function fwy__blob(g, cx, cy, rx, ry, n)
/// @description Internal. A lumpy closed outline (n points) round a centre.
function fwy__blob(_g, _cx, _cy, _rx, _ry, _n) {
    var _xs = [], _ys = [], _ph = fwy_range(_g, 0, pi * 2), _a1 = fwy_range(_g, 0.06, 0.16), _a2 = fwy_range(_g, 0.04, 0.1);
    for (var _i = 0; _i < _n; _i++) {
        var _a = _i / _n * pi * 2;
        var _r = 1 + _a1 * sin(_a * 2 + _ph) + _a2 * sin(_a * 3 - _ph * 1.7);
        array_push(_xs, _cx + cos(_a) * _rx * _r); array_push(_ys, _cy + sin(_a) * _ry * _r);
    }
    return [_xs, _ys];
}

/// @function fwy__buckets(hole)
/// @description Internal. Static segments and bumpers sorted into 64 px buckets (with the ball's reach) for the physics.
function fwy__buckets(_h) {
    var _n = FWY_GW * FWY_GH;
    _h.bseg = array_create(_n, 0); _h.bcir = array_create(_n, 0);
    for (var _i = 0; _i < _n; _i++) { _h.bseg[_i] = []; _h.bcir[_i] = []; }
    var _pad = FWY_BALL_R + 3;
    for (var _s = 0; _s < array_length(_h.segs); _s++) {
        var _e = _h.segs[_s];
        var _cx0 = max(0, floor((min(_e.x1, _e.x2) - _pad - FWY_OX) / FWY_CELL)), _cx1 = min(FWY_GW - 1, floor((max(_e.x1, _e.x2) + _pad - FWY_OX) / FWY_CELL));
        var _cy0 = max(0, floor((min(_e.y1, _e.y2) - _pad - FWY_OY) / FWY_CELL)), _cy1 = min(FWY_GH - 1, floor((max(_e.y1, _e.y2) + _pad - FWY_OY) / FWY_CELL));
        for (var _y = _cy0; _y <= _cy1; _y++) for (var _x = _cx0; _x <= _cx1; _x++) array_push(_h.bseg[_y * FWY_GW + _x], _s);
    }
    for (var _c = 0; _c < array_length(_h.circles); _c++) {
        var _o = _h.circles[_c], _rr = _o.r + _pad;
        for (var _y = max(0, floor((_o.y - _rr - FWY_OY) / FWY_CELL)); _y <= min(FWY_GH - 1, floor((_o.y + _rr - FWY_OY) / FWY_CELL)); _y++)
            for (var _x = max(0, floor((_o.x - _rr - FWY_OX) / FWY_CELL)); _x <= min(FWY_GW - 1, floor((_o.x + _rr - FWY_OX) / FWY_CELL)); _x++) array_push(_h.bcir[_y * FWY_GW + _x], _c);
    }
}

// ------------------------------------------------------------------------------------------------ the hole

/// @function fwy_hole_create(seed, theme, [opts])
/// @description Generate one hole: the lane, its greens and banks, rails, relief, hazards, obstacles and scenery, then PLAY it
/// with the shot planner to set its par; a hole the planner cannot finish in 6 strokes is thrown away and the next attempt is
/// generated (attempts are counted on the hole). The same seed and theme always give the same hole.
/// @param {Real} seed  any whole number
/// @param {String} theme  one of fwy_themes() (an unknown name reads as "garden")
/// @param {Struct} [opts]  { difficulty: 0..1 (0.5), features: [kinds to prefer], solve: true }
/// @returns {Struct} the hole: { seed, theme, cells, loops, segs, relief, hazards, obstacles, decor, teeX, teeY, cupX, cupY,
///          par, name, valid, attempts, fallback, solveMs }
function fwy_hole_create(_seed, _theme, _opts = undefined) {
    if (!is_numeric(_seed)) _seed = 1;
    if (!fwy__theme_ok(_theme)) _theme = "garden";
    if (!is_struct(_opts)) _opts = {};
    var _diff = (variable_struct_exists(_opts, "difficulty") && is_numeric(_opts.difficulty)) ? clamp(_opts.difficulty, 0, 1) : 0.5;
    var _pref = (variable_struct_exists(_opts, "features") && is_array(_opts.features)) ? _opts.features : [];
    var _solve = !(variable_struct_exists(_opts, "solve") && _opts.solve == false);
    var _t0 = get_timer();
    var _h = undefined;
    for (var _a = 0; _a < 12; _a++) {
        _h = fwy__layout(floor(_seed) * 131 + _a * 7919, _theme, _diff, _pref);
        _h.seed = floor(_seed); _h.attempts = _a + 1; _h.fallback = false;
        if (!_h.valid) continue;
        if (!_solve) break;
        if (fwy__solve(_h)) break;
        _h.valid = false;
    }
    if (is_undefined(_h) || !_h.valid) {
        _h = fwy__layout_fallback(floor(_seed), _theme);
        _h.seed = floor(_seed); _h.attempts = 13; _h.fallback = true;
        if (_solve) fwy__solve(_h);
    }
    _h.solveMs = (get_timer() - _t0) / 1000;
    return _h;
}

/// @function fwy__hole_new(theme, seed)
/// @description Internal. An empty hole record.
function fwy__hole_new(_theme, _seed) {
    return { theme: _theme, layoutSeed: _seed, cells: array_create(FWY_GW * FWY_GH, 0), path: [], plaza: [], loops: [], segs: [], circles: [],
             relief: [], hazards: [], obstacles: [], decor: [], teeX: 0, teeY: 0, cupX: 0, cupY: 0, teeDir: 0, par: 3, name: "",
             valid: false, kinds: [], railSegs: 0, sprite: -1, solve: undefined, hgW: 0, hgH: 0, hg: [], hmax: 0, geo: [], geoW: 0, geoH: 0 };
}

/// @function fwy__lane_mid(path, i)
/// @description Internal. The world centre of lane cell i.
function fwy__mid_x(_p) { return FWY_OX + _p[0] * 128 + 64; }
function fwy__mid_y(_p) { return FWY_OY + _p[1] * 128 + 64; }

/// @function fwy__layout(seed, theme, difficulty, prefer)
/// @description Internal. One attempt at a hole (no solving). Marks the hole invalid when a constraint cannot be met.
function fwy__layout(_seed, _theme, _diff, _pref) {
    var _g = fwy_rng(_seed);
    var _h = fwy__hole_new(_theme, _seed);
    var _lo = 3 + floor(_diff * 2), _hi = 5 + floor(_diff * 3);
    var _path = fwy__walk(_g, _lo, _hi);
    if (is_undefined(_path) || array_length(_path) < 3) return _h;
    _h.path = _path;
    var _np = array_length(_path);
    var _macro = array_create(FWY_MW * FWY_MH, -1);
    for (var _i = 0; _i < _np; _i++) _macro[_path[_i][1] * FWY_MW + _path[_i][0]] = _i;
    // greens: widen the cup end (and sometimes the tee end) by a neighbour that touches only its own lane cells
    var _dx = [1, 0, -1, 0], _dy = [0, 1, 0, -1];
    var _ends = [_np - 1];
    if (fwy_rand(_g) < 0.35) array_push(_ends, 0);
    for (var _e = 0; _e < array_length(_ends); _e++) {
        if (fwy_rand(_g) > 0.75 && _e == 0) continue;
        var _ix = _ends[_e], _P = _path[_ix];
        var _k0 = floor(fwy_rand(_g) * 4);
        for (var _kk = 0; _kk < 4; _kk++) {
            var _k = (_k0 + _kk) mod 4, _nx = _P[0] + _dx[_k], _ny = _P[1] + _dy[_k];
            if (_nx < 0 || _ny < 0 || _nx >= FWY_MW || _ny >= FWY_MH || _macro[_ny * FWY_MW + _nx] != -1) continue;
            var _ok = true;
            for (var _q = 0; _q < 4; _q++) {
                var _ax = _nx + _dx[_q], _ay = _ny + _dy[_q];
                if (_ax < 0 || _ay < 0 || _ax >= FWY_MW || _ay >= FWY_MH) continue;
                var _m = _macro[_ay * FWY_MW + _ax];
                if (_m == -2 || (_m >= 0 && abs(_m - _ix) > 1)) { _ok = false; break; }
            }
            if (!_ok) continue;
            _macro[_ny * FWY_MW + _nx] = -2;
            array_push(_h.plaza, [_nx, _ny, _ix]);
            break;
        }
    }
    // lane cells -> 2 x 2 felt cells
    for (var _my = 0; _my < FWY_MH; _my++) for (var _mx = 0; _mx < FWY_MW; _mx++) if (_macro[_my * FWY_MW + _mx] != -1)
        for (var _q = 0; _q < 4; _q++) _h.cells[(_my * 2 + (_q div 2)) * FWY_GW + _mx * 2 + (_q mod 2)] = 1;
    fwy__corners(_h, _g, 0.8, 0.65);
    // tee and cup
    var _p0 = _path[0], _p1 = _path[1], _pn = _path[_np - 1];
    _h.teeDir = point_direction(fwy__mid_x(_p0), fwy__mid_y(_p0), fwy__mid_x(_p1), fwy__mid_y(_p1));
    var _back = degtorad(_h.teeDir + 180);
    _h.teeX = fwy__mid_x(_p0) + cos(_back) * 30; _h.teeY = fwy__mid_y(_p0) - sin(_back) * 30;
    var _cupCx = fwy__mid_x(_pn), _cupCy = fwy__mid_y(_pn);
    for (var _q = 0; _q < array_length(_h.plaza); _q++) if (_h.plaza[_q][2] == _np - 1 && fwy_rand(_g) < 0.6) {
        _cupCx = (_cupCx + fwy__mid_x(_h.plaza[_q])) / 2; _cupCy = (_cupCy + fwy__mid_y(_h.plaza[_q])) / 2;
    }
    _h.cupX = _cupCx + fwy_range(_g, -26, 26); _h.cupY = _cupCy + fwy_range(_g, -26, 26);
    if (!fwy_is_felt(_h, _h.cupX, _h.cupY) || !fwy__clear_of_rail(_h, _h.cupX, _h.cupY, 26)) { _h.cupX = _cupCx; _h.cupY = _cupCy; }
    if (!fwy_is_felt(_h, _h.teeX, _h.teeY) || !fwy__clear_of_rail(_h, _h.teeX, _h.teeY, 20)) { _h.teeX = fwy__mid_x(_p0); _h.teeY = fwy__mid_y(_p0); }
    fwy__walls(_h);
    // features
    fwy__features(_h, _g, _diff, _pref);
    // the bowl round the cup (helps a ball that reaches it at a walking pace drop)
    array_push(_h.relief, { kind: "hill", x: _h.cupX, y: _h.cupY, r: 30, h: -5 });
    fwy__height_grid(_h);
    fwy__buckets(_h);
    fwy__decor(_h, _g);
    fwy__geodesic(_h);
    _h.valid = fwy__check(_h);
    return _h;
}

/// @function fwy__clear_of_rail(hole, x, y, d)
/// @description Internal. Whether every point within d of (x, y) on 8 compass rays is felt.
function fwy__clear_of_rail(_h, _x, _y, _d) {
    for (var _k = 0; _k < 8; _k++) { var _a = _k * pi / 4; if (!fwy_is_felt(_h, _x + cos(_a) * _d, _y + sin(_a) * _d)) return false; }
    return fwy_is_felt(_h, _x, _y);
}

/// @function fwy__runs(path)
/// @description Internal. The straight runs of the lane: [{ i0, i1, dir (0 E, 1 S, 2 W, 3 N), len }].
function fwy__runs(_path) {
    var _runs = [], _n = array_length(_path), _i0 = 0;
    var _dirOf = function(_a, _b) { if (_b[0] > _a[0]) return 0; if (_b[1] > _a[1]) return 1; if (_b[0] < _a[0]) return 2; return 3; };
    for (var _i = 1; _i < _n; _i++) {
        var _d = _dirOf(_path[_i - 1], _path[_i]);
        if (_i == _n - 1 || _dirOf(_path[_i], _path[_i + 1]) != _d) { array_push(_runs, { i0: _i0, i1: _i, dir: _d, len: _i - _i0 + 1 }); _i0 = _i; }
    }
    return _runs;
}

/// @function fwy__features(hole, g, difficulty, prefer)
/// @description Internal. Choose and place 1-3 obstacle features along the lane, hills and hazards. Every placement is checked
/// against the tee, the cup and the other pieces before it is kept.
function fwy__features(_h, _g, _diff, _pref) {
    var _T = fwy_theme(_h.theme);
    var _runs = fwy__runs(_h.path);
    var _np = array_length(_h.path);
    var _want = 1 + floor(_diff * 1.6 + fwy_rand(_g) * 1.3);
    var _kinds = ["mill", "gate", "spinner", "leap", "pipe", "bumpers", "wedges", "sand", "water", "hills"];
    var _w = array_create(array_length(_kinds), 1);
    for (var _k = 0; _k < array_length(_kinds); _k++) {
        for (var _q = 0; _q < array_length(_T.favour); _q++) if (_T.favour[_q] == _kinds[_k]) _w[_k] += 1.5;
        for (var _q = 0; _q < array_length(_pref); _q++) if (_pref[_q] == _kinds[_k]) _w[_k] += 4;
    }
    var _placed = 0, _tries = 0;
    while (_placed < _want && _tries < 24) {
        _tries++;
        var _tot = 0; for (var _k = 0; _k < array_length(_kinds); _k++) _tot += _w[_k];
        var _r = fwy_rand(_g) * _tot, _pick = 0;
        for (var _k = 0; _k < array_length(_kinds); _k++) { _r -= _w[_k]; if (_r < 0) { _pick = _k; break; } }
        var _kind = _kinds[_pick];
        if (fwy__place(_h, _g, _kind, _runs, _np)) { _placed++; _w[_pick] = 0; array_push(_h.kinds, _kind); }
        else _w[_pick] *= 0.4;
    }
    // a gentle hill or hollow on most holes, so the felt is never quite flat
    if (fwy_rand(_g) < 0.7 && !fwy__has(_h.kinds, "hills")) fwy__place(_h, _g, "hills", _runs, _np);
    _h.name = fwy__hole_name(_h, _g);
}

/// @function fwy__has(array, value)
/// @description Internal. Whether array holds value.
function fwy__has(_a, _v) { for (var _i = 0; _i < array_length(_a); _i++) if (_a[_i] == _v) return true; return false; }

/// @function fwy__free_spot(hole, x, y, r)
/// @description Internal. Whether a disc of radius r at (x, y) is felt, clear of the tee and the cup, and clear of every placed
/// obstacle footprint and hazard.
function fwy__free_spot(_h, _x, _y, _r) {
    if (!fwy__clear_of_rail(_h, _x, _y, _r + 4)) return false;
    if (fwy__hyp(_x - _h.teeX, _y - _h.teeY) < _r + 34) return false;
    if (fwy__hyp(_x - _h.cupX, _y - _h.cupY) < _r + 34) return false;
    for (var _i = 0; _i < array_length(_h.obstacles); _i++) {
        var _o = _h.obstacles[_i];
        if (_x + _r > _o.bx0 && _x - _r < _o.bx1 && _y + _r > _o.by0 && _y - _r < _o.by1) return false;
    }
    for (var _i = 0; _i < array_length(_h.hazards); _i++) {
        var _z = _h.hazards[_i];
        if (_x + _r > _z.bx0 - 6 && _x - _r < _z.bx1 + 6 && _y + _r > _z.by0 - 6 && _y - _r < _z.by1 + 6) return false;
    }
    return true;
}

/// @function fwy__obst(hole, struct)
/// @description Internal. Record an obstacle (with its footprint box bx0..by1) and return it.
function fwy__obst(_h, _o) { array_push(_h.obstacles, _o); return _o; }

/// @function fwy__place(hole, g, kind, runs, np)
/// @description Internal. Try to place one feature of a kind; true when placed.
function fwy__place(_h, _g, _kind, _runs, _np) {
    var _P = _h.path;
    switch (_kind) {
        case "mill": {
            // a building across a NORTH-SOUTH run, its tunnel in the middle, its sails turning on the south face
            for (var _r = 0; _r < array_length(_runs); _r++) {
                var _R = _runs[_r];
                if ((_R.dir != 1 && _R.dir != 3) || _R.len < 2) continue;
                var _ia = min(_R.i0, _R.i1), _ib = _ia + 1;
                var _lx0 = FWY_OX + _P[_ia][0] * 128, _lx1 = _lx0 + 128;
                var _yb = FWY_OY + max(_P[_ia][1], _P[_ib][1]) * 128;
                var _y0 = _yb - 22, _y1 = _yb + 22, _gw = 40;
                var _gx0 = (_lx0 + _lx1) / 2 - _gw / 2, _gx1 = _gx0 + _gw;
                if (fwy__hyp((_lx0 + _lx1) / 2 - _h.cupX, _yb - _h.cupY) < 80 || fwy__hyp((_lx0 + _lx1) / 2 - _h.teeX, _yb - _h.teeY) < 80) continue;
                // nothing already placed may lie under the footprint or behind the building (the felt it hides)
                var _fx0 = _lx0 - 16, _fy0 = _y1 - 150 - 16, _fx1 = _lx1 + 16, _fy1 = _y1 + 8 + 16, _clash = false;
                for (var _i = 0; _i < array_length(_h.obstacles) && !_clash; _i++) { var _q = _h.obstacles[_i]; if (_fx1 > _q.bx0 && _fx0 < _q.bx1 && _fy1 > _q.by0 && _fy0 < _q.by1) _clash = true; }
                for (var _i = 0; _i < array_length(_h.hazards) && !_clash; _i++) { var _z = _h.hazards[_i]; if (_fx1 > _z.bx0 && _fx0 < _z.bx1 && _fy1 > _z.by0 && _fy0 < _z.by1) _clash = true; }
                for (var _i = 0; _i < array_length(_h.circles) && !_clash; _i++) { var _c = _h.circles[_i]; if (_c.x + _c.r > _fx0 && _c.x - _c.r < _fx1 && _c.y + _c.r > _fy0 && _c.y - _c.r < _fy1) _clash = true; }
                if (_clash) continue;
                var _o = fwy__obst(_h, { kind: "mill", bx0: _lx0, by0: _y1 - 150, bx1: _lx1, by1: _y1 + 8, x0: _lx0, y0: _y0, x1: _lx1, y1: _y1, gx0: _gx0, gx1: _gx1,
                                          period: fwy_range(_g, 3.2, 4.6), phase: fwy_range(_g, 0, 1) });
                fwy__box_segs(_h, _lx0 - 2, _y0, _gx0, _y1, "block");
                fwy__box_segs(_h, _gx1, _y0, _lx1 + 2, _y1, "block");
                return true;
            }
            return false;
        }
        case "gate": case "spinner": case "leap": {
            for (var _r = 0; _r < array_length(_runs); _r++) {
                var _R = _runs[(_r + floor(fwy_rand(_g) * 7)) mod array_length(_runs)];
                if (_R.len < 2) continue;
                var _ia = _R.i0 + floor(fwy_rand(_g) * (_R.len - 1)), _ib = _ia + 1;
                if (_ib > _R.i1) continue;
                var _ax = fwy__mid_x(_P[_ia]), _ay = fwy__mid_y(_P[_ia]), _bx = fwy__mid_x(_P[_ib]), _by = fwy__mid_y(_P[_ib]);
                var _mx = (_ax + _bx) / 2, _my = (_ay + _by) / 2;
                var _horiz = (_R.dir == 0 || _R.dir == 2);
                var _ux = sign(_bx - _ax), _uy = sign(_by - _ay);
                if (fwy__hyp(_mx - _h.cupX, _my - _h.cupY) < 90 || fwy__hyp(_mx - _h.teeX, _my - _h.teeY) < 90) continue;
                var _bad = false;
                for (var _i = 0; _i < array_length(_h.obstacles); _i++) { var _o = _h.obstacles[_i]; if (_mx + 70 > _o.bx0 && _mx - 70 < _o.bx1 && _my + 70 > _o.by0 && _my - 70 < _o.by1) _bad = true; }
                for (var _i = 0; _i < array_length(_h.hazards); _i++) { var _z = _h.hazards[_i]; if (_mx + 70 > _z.bx0 && _mx - 70 < _z.bx1 && _my + 70 > _z.by0 && _my - 70 < _z.by1) _bad = true; }
                if (_bad) continue;
                if (_kind == "spinner") {
                    fwy__obst(_h, { kind: "spinner", bx0: _mx - 52, by0: _my - 52, bx1: _mx + 52, by1: _my + 52, x: _mx, y: _my, len: 46, arms: (fwy_rand(_g) < 0.5) ? 2 : 4,
                                    omega: fwy_range(_g, 0.9, 1.6) * ((fwy_rand(_g) < 0.5) ? -1 : 1), phase: fwy_range(_g, 0, pi) });
                    array_push(_h.circles, { x: _mx, y: _my, r: 8, e: 0.7, kind: "hub" });
                    return true;
                }
                if (_kind == "gate") {
                    // hinged on one rail, closing across the lane, opening back along the rail
                    var _side = (fwy_rand(_g) < 0.5) ? -1 : 1;
                    var _hx = _mx - _uy * _side * 64, _hy = _my + _ux * _side * 64;
                    var _closed = arctan2(_my - _hy, _mx - _hx);
                    var _sg0 = (fwy_rand(_g) < 0.5) ? 1 : -1, _open = undefined;
                    for (var _try = 0; _try < 2 && is_undefined(_open); _try++) {
                        var _sg = (_try == 0) ? _sg0 : -_sg0, _fits = true;
                        for (var _q = 0; _q <= 8 && _fits; _q++) {
                            var _a = _closed + degtorad(80) * _sg * _q / 8;
                            if (!fwy_is_felt(_h, _hx + cos(_a) * 110, _hy + sin(_a) * 110) || !fwy_is_felt(_h, _hx + cos(_a) * 58 + cos(_closed) * 4, _hy + sin(_a) * 58 + sin(_closed) * 4)) _fits = false;
                        }
                        if (_fits) _open = _closed + degtorad(80) * _sg;
                    }
                    if (is_undefined(_open)) continue;
                    fwy__obst(_h, { kind: "gate", bx0: _mx - 66, by0: _my - 66, bx1: _mx + 66, by1: _my + 66, hx: _hx, hy: _hy, len: 116,
                                    a0: _closed, a1: _open, period: fwy_range(_g, 2.6, 4), phase: fwy_range(_g, 0, 1), ux: _ux, uy: _uy });
                    array_push(_h.circles, { x: _hx, y: _hy, r: 7, e: 0.7, kind: "post" });
                    return true;
                }
                // leap: a channel across the lane at the boundary, a ramp before it (toward the tee)
                var _dirx = _ux, _diry = _uy;
                if (_ib == _np - 1 && fwy__hyp(_bx - _h.cupX, _by - _h.cupY) < 120) continue;
                var _cw = 56, _cx0, _cy0, _cx1, _cy1, _rx0, _ry0, _rx1, _ry1;
                if (_horiz) {
                    var _ly0 = FWY_OY + _P[_ia][1] * 128, _ly1 = _ly0 + 128;
                    _cx0 = _mx - _cw / 2; _cx1 = _mx + _cw / 2; _cy0 = _ly0 - 2; _cy1 = _ly1 + 2;
                    if (_dirx > 0) { _rx0 = _cx0 - 52; _rx1 = _cx0; } else { _rx0 = _cx1; _rx1 = _cx1 + 52; }
                    _ry0 = _ly0; _ry1 = _ly1;
                } else {
                    var _lx0 = FWY_OX + _P[_ia][0] * 128, _lx1 = _lx0 + 128;
                    _cy0 = _my - _cw / 2; _cy1 = _my + _cw / 2; _cx0 = _lx0 - 2; _cx1 = _lx1 + 2;
                    if (_diry > 0) { _ry0 = _cy0 - 52; _ry1 = _cy0; } else { _ry0 = _cy1; _ry1 = _cy1 + 52; }
                    _rx0 = _lx0; _rx1 = _lx1;
                }
                fwy__haz_add(_h, "water", [_cx0, _cx1, _cx1, _cx0], [_cy0, _cy0, _cy1, _cy1]);
                var _lipx = (_dirx > 0) ? _rx1 : ((_dirx < 0) ? _rx0 : 0), _lipy = (_diry > 0) ? _ry1 : ((_diry < 0) ? _ry0 : 0);
                fwy__obst(_h, { kind: "leap", bx0: min(_rx0, _cx0), by0: min(_ry0, _cy0), bx1: max(_rx1, _cx1), by1: max(_ry1, _cy1),
                                rx0: _rx0, ry0: _ry0, rx1: _rx1, ry1: _ry1, cx0: _cx0, cy0: _cy0, cx1: _cx1, cy1: _cy1, dx: _dirx, dy: _diry, lipx: _lipx, lipy: _lipy, horiz: _horiz });
                array_push(_h.relief, { kind: "tilt", x0: _rx0, y0: _ry0, x1: _rx1, y1: _ry1, sx: _dirx * 0.13, sy: _diry * 0.13 });
                return true;
            }
            return false;
        }
        case "pipe": {
            if (_np < 5) return false;
            var _ia = 1 + floor(fwy_rand(_g) * 2), _ib = min(_np - 2, _ia + 2 + floor(fwy_rand(_g) * 2));
            if (_ib <= _ia + 1) return false;
            var _A = _P[_ia], _B = _P[_ib];
            var _ax = fwy__mid_x(_A) + fwy_range(_g, -30, 30), _ay = fwy__mid_y(_A) + fwy_range(_g, -30, 30);
            var _bx = fwy__mid_x(_B) + fwy_range(_g, -30, 30), _by = fwy__mid_y(_B) + fwy_range(_g, -30, 30);
            if (!fwy__free_spot(_h, _ax, _ay, 22) || !fwy__free_spot(_h, _bx, _by, 22)) return false;
            var _nx = _P[min(_ib + 1, _np - 1)];
            var _bdir = arctan2(fwy__mid_y(_nx) - _by, fwy__mid_x(_nx) - _bx);
            if (_ib + 1 > _np - 1) _bdir = arctan2(_h.cupY - _by, _h.cupX - _bx);
            fwy__obst(_h, { kind: "pipe", bx0: _ax - 20, by0: _ay - 20, bx1: _ax + 20, by1: _ay + 20, ax: _ax, ay: _ay, bx: _bx, by: _by, bdir: _bdir });
            fwy__obst(_h, { kind: "pipeout", bx0: _bx - 20, by0: _by - 20, bx1: _bx + 20, by1: _by + 20, x: _bx, y: _by, dir: _bdir });
            return true;
        }
        case "bumpers": {
            var _n = 2 + floor(fwy_rand(_g) * 3), _put = 0;
            repeat (60) {
                if (_put >= _n) break;
                var _ix = 1 + floor(fwy_rand(_g) * (_np - 1)), _C = _P[_ix];
                var _x = fwy__mid_x(_C) + fwy_range(_g, -40, 40), _y = fwy__mid_y(_C) + fwy_range(_g, -40, 40), _rr = fwy_range(_g, 10, 14);
                if (!fwy__free_spot(_h, _x, _y, _rr + 12)) continue;
                var _ok = true;
                for (var _c = 0; _c < array_length(_h.circles); _c++) if (fwy__hyp(_h.circles[_c].x - _x, _h.circles[_c].y - _y) < _rr + _h.circles[_c].r + 26) _ok = false;
                if (!_ok) continue;
                array_push(_h.circles, { x: _x, y: _y, r: _rr, e: 1.05, kind: "bumper" });
                fwy__obst(_h, { kind: "bumper", bx0: _x - _rr, by0: _y - _rr, bx1: _x + _rr, by1: _y + _rr, x: _x, y: _y, r: _rr });
                _put++;
            }
            return _put >= 2;
        }
        case "wedges": {
            var _put = 0;
            repeat (40) {
                if (_put >= 2) break;
                var _ix = 1 + floor(fwy_rand(_g) * (_np - 1)), _C = _P[_ix];
                var _x = fwy__mid_x(_C) + fwy_range(_g, -30, 30), _y = fwy__mid_y(_C) + fwy_range(_g, -30, 30);
                if (!fwy__free_spot(_h, _x, _y, 30)) continue;
                var _a = fwy_range(_g, 0, pi * 2), _s = fwy_range(_g, 18, 24);
                var _xs = [], _ys = [];
                for (var _q = 0; _q < 3; _q++) { array_push(_xs, _x + cos(_a + _q * pi * 2 / 3) * _s); array_push(_ys, _y + sin(_a + _q * pi * 2 / 3) * _s); }
                for (var _q = 0; _q < 3; _q++) { var _j = (_q + 1) mod 3; fwy__seg_add(_h, _xs[_j], _ys[_j], _xs[_q], _ys[_q], 0.8, "wedge"); }
                fwy__obst(_h, { kind: "wedge", bx0: _x - _s, by0: _y - _s, bx1: _x + _s, by1: _y + _s, x: _x, y: _y, xs: _xs, ys: _ys });
                _put++;
            }
            return _put >= 1;
        }
        case "sand": case "water": {
            repeat (40) {
                var _ix = 1 + floor(fwy_rand(_g) * (_np - 1));
                var _C = (array_length(_h.plaza) > 0 && fwy_rand(_g) < 0.5) ? _h.plaza[0] : _P[_ix];
                var _rx = fwy_range(_g, 26, 40), _ry = fwy_range(_g, 20, 34);
                var _x = fwy__mid_x(_C) + fwy_range(_g, -30, 30), _y = fwy__mid_y(_C) + fwy_range(_g, -30, 30);
                if (!fwy__free_spot(_h, _x, _y, max(_rx, _ry) + 6)) continue;
                var _bl = fwy__blob(_g, _x, _y, _rx, _ry, 14);
                fwy__haz_add(_h, _kind, _bl[0], _bl[1]);
                return true;
            }
            return false;
        }
        case "hills": {
            var _n = 1 + floor(fwy_rand(_g) * 2), _put = 0;
            repeat (30) {
                if (_put >= _n) break;
                var _ix = floor(fwy_rand(_g) * _np), _C = _P[_ix];
                var _x = fwy__mid_x(_C) + fwy_range(_g, -36, 36), _y = fwy__mid_y(_C) + fwy_range(_g, -36, 36);
                if (fwy__hyp(_x - _h.cupX, _y - _h.cupY) < 70 || fwy__hyp(_x - _h.teeX, _y - _h.teeY) < 60) continue;
                array_push(_h.relief, { kind: "hill", x: _x, y: _y, r: fwy_range(_g, 44, 76), h: fwy_range(_g, 9, 17) * ((fwy_rand(_g) < 0.3) ? -1 : 1) });
                _put++;
            }
            return _put > 0;
        }
    }
    return false;
}

/// @function fwy__box_segs(hole, x0, y0, x1, y1, kind)
/// @description Internal. The four faces of a solid box as collision segments.
function fwy__box_segs(_h, _x0, _y0, _x1, _y1, _kind) {
    fwy__seg_add(_h, _x0, _y0, _x1, _y0, 0.6, _kind); fwy__seg_add(_h, _x1, _y0, _x1, _y1, 0.6, _kind);
    fwy__seg_add(_h, _x1, _y1, _x0, _y1, 0.6, _kind); fwy__seg_add(_h, _x0, _y1, _x0, _y0, 0.6, _kind);
}

/// @function fwy__hole_name(hole, g)
/// @description Internal. A name from the theme and the hole's main feature.
/// @function fwy__adjectives(theme)
/// @description Internal. The words a theme names its holes with.
function fwy__adjectives(_theme) {
    switch (_theme) {
        case "pirate": return ["Cutlass", "Kraken's", "Rum", "Parrot", "Bosun's", "Doubloon", "Galleon", "Lagoon", "Plank", "Compass"];
        case "haunted": return ["Raven", "Lantern", "Widow's", "Cellar", "Crypt", "Moonlit", "Cobweb", "Belfry", "Gallows", "Candle"];
        case "candy": return ["Toffee", "Sherbet", "Peppermint", "Fudge", "Marzipan", "Caramel", "Licorice", "Bonbon", "Nougat", "Gumdrop"];
        case "space": return ["Comet", "Airlock", "Nebula", "Orbital", "Docking", "Pulsar", "Quasar", "Gravity", "Meteor", "Lunar"];
        case "desert": return ["Scarab", "Pharaoh's", "Oasis", "Mirage", "Sandstone", "Jackal", "Sphinx", "Caravan", "Obelisk", "Dune"];
    }
    return ["Rose", "Hedge", "Sundial", "Bramble", "Orchard", "Lavender", "Topiary", "Wisteria", "Gazebo", "Fountain"];
}

/// @function fwy__title(s)
/// @description Internal. Every word capitalised.
function fwy__title(_s) {
    var _o = "", _up = true;
    for (var _i = 1; _i <= string_length(_s); _i++) { var _ch = string_char_at(_s, _i); _o += _up ? string_upper(_ch) : _ch; _up = (_ch == " "); }
    return _o;
}

function fwy__hole_name(_h, _g) {
    var _T = fwy_theme(_h.theme);
    var _k = (array_length(_h.kinds) > 0) ? _h.kinds[0] : "plain";
    var _adj = array_create(6, "");
    array_copy(_adj, 0, fwy__adjectives(_h.theme), 0, 6);
    var _noun;
    switch (_k) {
        case "mill": _noun = fwy__title(_T.mill); break;
        case "gate": _noun = "Gate"; break;
        case "spinner": _noun = "Spinner"; break;
        case "leap": _noun = "Leap"; break;
        case "pipe": _noun = "Shortcut"; break;
        case "bumpers": _noun = "Pinball"; break;
        case "wedges": _noun = "Ricochet"; break;
        case "sand": _noun = "Trap"; break;
        case "water": _noun = "Splash"; break;
        case "hills": _noun = "Hump"; break;
        default: _noun = "Run"; break;
    }
    return _adj[floor(fwy_rand(_g) * array_length(_adj))] + " " + _noun;
}

/// @function fwy__decor(hole, g)
/// @description Internal. Scenery round the course on the ground that is not felt: each item { kind, x, y, s, v } (kind 0..3
/// picks one of the theme's four scenery pieces).
function fwy__decor(_h, _g) {
    var _tries = 0;
    while (array_length(_h.decor) < 26 && _tries < 500) {
        _tries++;
        var _x = fwy_range(_g, 14, FWY_W - 14), _y = fwy_range(_g, 14, FWY_H - 14), _s = fwy_range(_g, 0.75, 1.25);
        var _rr = 20 * _s, _ok = true;
        for (var _k = 0; _k < 8 && _ok; _k++) { var _a = _k * pi / 4; if (fwy_is_felt(_h, _x + cos(_a) * (_rr + 14), _y + sin(_a) * (_rr + 14))) _ok = false; }
        if (!_ok || fwy_is_felt(_h, _x, _y)) continue;
        for (var _i = 0; _i < array_length(_h.decor) && _ok; _i++) { var _d = _h.decor[_i]; if (fwy__hyp(_d.x - _x, _d.y - _y) < (_d.s + _s) * 20 + 6) _ok = false; }
        if (!_ok) continue;
        array_push(_h.decor, { kind: floor(fwy_rand(_g) * 4), x: _x, y: _y, s: _s, v: fwy_rand(_g) });
    }
    // draw order: north to south, so nearer pieces overlap farther ones
    array_sort(_h.decor, function(_a, _b) { return _a.y - _b.y; });
}

/// @function fwy__geodesic(hole)
/// @description Internal. The shortest felt distance from every height-grid node to the cup (8-neighbour Dijkstra; water
/// costs four times its length, solid footprints are closed). The planner's sense of "nearer the cup".
function fwy__geodesic(_h) {
    var _w = _h.hgW, _hh = _h.hgH, _n = _w * _hh;
    var _dist = array_create(_n, 1000000000), _open = array_create(_n, false), _cost = array_create(_n, 1);
    for (var _j = 0; _j < _hh; _j++) for (var _i = 0; _i < _w; _i++) {
        var _x = _i * FWY_HG, _y = _j * FWY_HG, _o = _j * _w + _i;
        var _x2 = clamp(_x, 1, FWY_W - 1), _y2 = clamp(_y, 1, FWY_H - 1);
        if (!fwy_is_felt(_h, _x2, _y2)) continue;
        var _solid = false;
        for (var _q = 0; _q < array_length(_h.obstacles); _q++) {
            var _ob = _h.obstacles[_q];
            if (_ob.kind == "mill" && _y2 > _ob.y0 - 6 && _y2 < _ob.y1 + 6 && _x2 > _ob.x0 && _x2 < _ob.x1 && (_x2 < _ob.gx0 + 6 || _x2 > _ob.gx1 - 6)) _solid = true;
            if (_ob.kind == "wedge" && fwy__hyp(_x2 - _ob.x, _y2 - _ob.y) < 16) _solid = true;
        }
        for (var _q = 0; _q < array_length(_h.circles); _q++) if (fwy__hyp(_x2 - _h.circles[_q].x, _y2 - _h.circles[_q].y) < _h.circles[_q].r + 4) _solid = true;
        if (_solid) continue;
        _open[_o] = true;
        if (fwy__haz_at(_h, _x2, _y2) == "water") _cost[_o] = 4;
    }
    var _ci = clamp(round(_h.cupX / FWY_HG), 0, _w - 1), _cj = clamp(round(_h.cupY / FWY_HG), 0, _hh - 1);
    var _pq = ds_priority_create();
    var _seeded = 0;
    for (var _dj = -1; _dj <= 2; _dj++) for (var _di = -1; _di <= 2; _di++) {
        var _i = _ci + _di, _j = _cj + _dj;
        if (_i < 0 || _j < 0 || _i >= _w || _j >= _hh) continue;
        var _o = _j * _w + _i;
        if (!_open[_o]) continue;
        _dist[_o] = fwy__hyp(_i * FWY_HG - _h.cupX, _j * FWY_HG - _h.cupY);
        ds_priority_add(_pq, _o, _dist[_o]); _seeded++;
    }
    var _di8 = [1, -1, 0, 0, 1, 1, -1, -1], _dj8 = [0, 0, 1, -1, 1, -1, 1, -1];
    while (!ds_priority_empty(_pq)) {
        var _o = ds_priority_delete_min(_pq);
        var _i = _o mod _w, _j = _o div _w, _d0 = _dist[_o];
        for (var _k = 0; _k < 8; _k++) {
            var _a = _i + _di8[_k], _b = _j + _dj8[_k];
            if (_a < 0 || _b < 0 || _a >= _w || _b >= _hh) continue;
            var _p = _b * _w + _a;
            if (!_open[_p]) continue;
            var _st = ((_k < 4) ? 16 : 22.627) * max(_cost[_o], _cost[_p]);
            if (_d0 + _st < _dist[_p]) { _dist[_p] = _d0 + _st; ds_priority_add(_pq, _p, _dist[_p]); }
        }
    }
    ds_priority_destroy(_pq);
    _h.geo = _dist; _h.geoOpen = _open; _h.geoSeeded = _seeded;
}

/// @function fwy__potential(hole, x, y)
/// @description Internal. How far a point is from the cup along the felt: the best of the four surrounding nodes' distance plus
/// the straight step to that node.
function fwy__potential(_h, _x, _y) {
    var _w = _h.hgW, _i = clamp(floor(_x / FWY_HG), 0, _w - 2), _j = clamp(floor(_y / FWY_HG), 0, _h.hgH - 2), _best = 1000000000;
    for (var _q = 0; _q < 4; _q++) {
        var _a = _i + (_q mod 2), _b = _j + (_q div 2), _d = _h.geo[_b * _w + _a];
        if (_d < 100000000) _best = min(_best, _d + fwy__hyp(_a * FWY_HG - _x, _b * FWY_HG - _y));
    }
    if (_best >= 100000000) _best = 5000 + fwy__hyp(_x - _h.cupX, _y - _h.cupY);
    return _best;
}

/// @function fwy__check(hole)
/// @description Internal. The layout's own constraints: the tee reaches the cup along the felt, tee and cup are on felt and
/// far enough apart, every obstacle and hazard sits on felt.
function fwy__check(_h) {
    if (!fwy_is_felt(_h, _h.teeX, _h.teeY) || !fwy_is_felt(_h, _h.cupX, _h.cupY)) return false;
    if (fwy__hyp(_h.teeX - _h.cupX, _h.teeY - _h.cupY) < 180) return false;
    if (fwy__potential(_h, _h.teeX, _h.teeY) >= 4000) return false;
    if (fwy__haz_at(_h, _h.teeX, _h.teeY) != "" || fwy__haz_at(_h, _h.cupX, _h.cupY) != "") return false;
    return true;
}

/// @function fwy__layout_fallback(seed, theme)
/// @description Internal. A plain dog-leg hole that is always finishable (used, and counted, only when 12 attempts fail).
function fwy__layout_fallback(_seed, _theme) {
    var _h = fwy__hole_new(_theme, _seed);
    _h.path = [[1, 2], [2, 2], [3, 2], [4, 2], [4, 1]];
    for (var _i = 0; _i < array_length(_h.path); _i++) { var _p = _h.path[_i]; for (var _q = 0; _q < 4; _q++) _h.cells[(_p[1] * 2 + (_q div 2)) * FWY_GW + _p[0] * 2 + (_q mod 2)] = 1; }
    _h.teeX = FWY_OX + 1 * 128 + 40; _h.teeY = FWY_OY + 2 * 128 + 64; _h.teeDir = 0;
    _h.cupX = FWY_OX + 4 * 128 + 64; _h.cupY = FWY_OY + 1 * 128 + 50;
    fwy__walls(_h);
    array_push(_h.relief, { kind: "hill", x: _h.cupX, y: _h.cupY, r: 30, h: -5 });
    fwy__height_grid(_h); fwy__buckets(_h);
    fwy__decor(_h, fwy_rng(_seed));
    fwy__geodesic(_h);
    _h.name = "Practice Green"; _h.valid = true;
    return _h;
}

// ------------------------------------------------------------------------------------------------ the ball

/// @function fwy_ball_create(x, y)
/// @description A ball at rest at a point.
/// @returns {Struct} { x, y, vx, vy, air, moving, holed, lastX, lastY }
function fwy_ball_create(_x, _y) {
    if (!is_numeric(_x)) _x = 0;
    if (!is_numeric(_y)) _y = 0;
    return { x: _x, y: _y, vx: 0, vy: 0, air: 0, airT: 0, moving: false, holed: false, lastX: _x, lastY: _y, roll: 0 };
}

/// @function fwy_ball_shoot(ball, angle, power)
/// @description Strike a resting ball: angle in radians (room space), power 0..1 of a full-power shot (FWY_MAXV px/s).
/// Refused (returns false) while the ball is moving or holed, or for a non-number.
function fwy_ball_shoot(_b, _ang, _pow) {
    if (!is_struct(_b) || !variable_struct_exists(_b, "moving") || _b.moving || _b.holed) return false;
    if (!is_numeric(_ang) || !is_numeric(_pow)) return false;
    _pow = clamp(_pow, 0, 1);
    var _v = 40 + _pow * (FWY_MAXV - 40);
    _b.lastX = _b.x; _b.lastY = _b.y;
    _b.vx = cos(_ang) * _v; _b.vy = sin(_ang) * _v;
    _b.moving = true; _b.air = 0;
    return true;
}

/// @function fwy__dyn(hole, t)
/// @description Internal. The moving obstacles' collision geometry at time t into global.fwy_dyn: [x1, y1, x2, y2, vx, vy,
/// e] per segment (the velocity is the obstacle's own at the segment's midpoint).
function fwy__dyn(_h, _t) {
    var _out = [];
    for (var _i = 0; _i < array_length(_h.obstacles); _i++) {
        var _o = _h.obstacles[_i];
        if (_o.kind == "gate") {
            var _ph = 2 * pi * (_t / _o.period + _o.phase);
            var _a = _o.a0 + (_o.a1 - _o.a0) * (0.5 - 0.5 * cos(_ph));
            var _da = (_o.a1 - _o.a0) * 0.5 * sin(_ph) * 2 * pi / _o.period;
            var _ex = _o.hx + cos(_a) * _o.len, _ey = _o.hy + sin(_a) * _o.len;
            var _s = _o.len * 0.6;
            array_push(_out, [_o.hx, _o.hy, _ex, _ey, -sin(_a) * _da * _s, cos(_a) * _da * _s, 0.6]);
        } else if (_o.kind == "spinner") {
            for (var _k = 0; _k < _o.arms; _k++) {
                var _a = _o.omega * _t + _o.phase + _k * 2 * pi / _o.arms;
                var _ex = _o.x + cos(_a) * _o.len, _ey = _o.y + sin(_a) * _o.len, _s = _o.len * 0.6;
                array_push(_out, [_o.x, _o.y, _ex, _ey, -sin(_a) * _o.omega * _s, cos(_a) * _o.omega * _s, 0.6]);
            }
        } else if (_o.kind == "mill") {
            if (fwy__mill_blocked(_o, _t)) array_push(_out, [_o.gx0, _o.y1 + 2, _o.gx1, _o.y1 + 2, 0, 0, 0.5]);
        }
    }
    global.fwy_dyn = _out;
}

/// @function fwy__mill_sail(mill, t)
/// @description Internal. The sails' angle at time t (radians; a sail at pi/2 points straight down over the tunnel mouth).
function fwy__mill_sail(_o, _t) { return 2 * pi * (_t / _o.period + _o.phase); }

/// @function fwy__mill_blocked(mill, t)
/// @description Internal. Whether a sail is down across the tunnel mouth at time t.
function fwy__mill_blocked(_o, _t) {
    var _a = fwy__mill_sail(_o, _t);
    for (var _k = 0; _k < 4; _k++) {
        var _d = (_a + _k * pi / 2 - pi / 2) mod (2 * pi);
        if (_d < 0) _d += 2 * pi;
        if (_d < 0.32 || _d > 2 * pi - 0.32) return true;
    }
    return false;
}

/// @function fwy__collide_seg(ball, x1, y1, x2, y2, e, vsx, vsy)
/// @description Internal. Push the ball out of a segment and bounce it (relative to the segment's own velocity). True on a
/// bounce.
function fwy__collide_seg(_b, _x1, _y1, _x2, _y2, _e, _vsx, _vsy) {
    var _dx = _x2 - _x1, _dy = _y2 - _y1, _l2 = _dx * _dx + _dy * _dy, _u = 0;
    if (_l2 > 0) _u = clamp(((_b.x - _x1) * _dx + (_b.y - _y1) * _dy) / _l2, 0, 1);
    var _qx = _x1 + _dx * _u, _qy = _y1 + _dy * _u, _px = _b.x - _qx, _py = _b.y - _qy, _d2 = _px * _px + _py * _py;
    if (_d2 >= FWY_BALL_R * FWY_BALL_R) return false;
    var _d = sqrt(_d2), _nx, _ny;
    if (_d > 0.0001) { _nx = _px / _d; _ny = _py / _d; }
    else { var _ll = sqrt(max(_l2, 0.0001)); _nx = -_dy / _ll; _ny = _dx / _ll; }
    _b.x = _qx + _nx * FWY_BALL_R; _b.y = _qy + _ny * FWY_BALL_R;
    var _rvx = _b.vx - _vsx, _rvy = _b.vy - _vsy, _vn = _rvx * _nx + _rvy * _ny;
    if (_vn < 0) { _b.vx -= (1 + _e) * _vn * _nx; _b.vy -= (1 + _e) * _vn * _ny; return true; }
    return false;
}

/// @function fwy_ball_step(hole, ball, t)
/// @description Advance a moving ball by one fixed physics step (FWY_DT = 1/120 s) at hole time t, in as many sub-steps as
/// its speed needs (never more than 0.6 of its radius per sub-step, so it cannot pass through a rail). Returns a struct of
/// what happened this step: { holed, water, pipe, jump, landed, bumps, lipout, stopped }.
/// @param {Struct} hole  from fwy_hole_create
/// @param {Struct} ball  from fwy_ball_create
/// @param {Real} t  the hole's clock (moving obstacles are a function of it)
function fwy_ball_step(_h, _b, _t) {
    var _ev = { holed: false, water: false, pipe: false, jump: false, landed: false, bumps: 0, lipout: false, stopped: false };
    if (!is_struct(_h) || !variable_struct_exists(_h, "segs") || !is_struct(_b) || !variable_struct_exists(_b, "moving")) return _ev;
    if (!is_numeric(_t)) _t = 0;
    if (!_b.moving || _b.holed) return _ev;
    fwy__step(_h, _b, _t, _ev);
    return _ev;
}

/// @function fwy__step(hole, ball, t, ev)
/// @description Internal. The fixed step behind fwy_ball_step and the planner.
function fwy__step(_h, _b, _t, _ev) {
    fwy__dyn(_h, _t);
    var _dyn = global.fwy_dyn;
    var _sp0 = fwy__hyp(_b.vx, _b.vy);
    var _n = clamp(ceil(_sp0 * FWY_DT / (FWY_BALL_R * 0.6)), 1, 8);
    var _dt = FWY_DT / _n;
    for (var _s = 0; _s < _n; _s++) {
        var _air = (_b.air > 0);
        var _ax = 0, _ay = 0, _mu = FWY_MU;
        if (!_air) {
            fwy__grad(_h, _b.x, _b.y);
            _ax = -FWY_G * global.fwy_gx; _ay = -FWY_G * global.fwy_gy;
            if (fwy__haz_at(_h, _b.x, _b.y) == "sand") _mu = FWY_MU_SAND;
            var _cdx = _h.cupX - _b.x, _cdy = _h.cupY - _b.y, _cd = fwy__hyp(_cdx, _cdy);
            if (_cd < FWY_CUP_R + 1 && _cd > 0.01) { _ax += _cdx / _cd * 900; _ay += _cdy / _cd * 900; }
        }
        _b.vx += _ax * _dt; _b.vy += _ay * _dt;
        var _sp = fwy__hyp(_b.vx, _b.vy);
        if (!_air && _sp > 0) {
            var _dec = _mu * _dt;
            if (_sp <= _dec) { _b.vx = 0; _b.vy = 0; _sp = 0; } else { _b.vx -= _b.vx / _sp * _dec; _b.vy -= _b.vy / _sp * _dec; _sp -= _dec; }
        }
        var _ox = _b.x, _oy = _b.y;
        _b.x += _b.vx * _dt; _b.y += _b.vy * _dt;
        _b.roll += _sp * _dt;
        // static rails, blocks and wedges near the ball
        var _bk = clamp(floor((_b.y - FWY_OY) / FWY_CELL), 0, FWY_GH - 1) * FWY_GW + clamp(floor((_b.x - FWY_OX) / FWY_CELL), 0, FWY_GW - 1);
        var _L = _h.bseg[_bk];
        for (var _i = 0; _i < array_length(_L); _i++) { var _e = _h.segs[_L[_i]]; if (fwy__collide_seg(_b, _e.x1, _e.y1, _e.x2, _e.y2, _e.e, 0, 0)) _ev.bumps++; }
        var _C = _h.bcir[_bk];
        for (var _i = 0; _i < array_length(_C); _i++) {
            var _o = _h.circles[_C[_i]], _px = _b.x - _o.x, _py = _b.y - _o.y, _d = fwy__hyp(_px, _py), _rr = _o.r + FWY_BALL_R;
            if (_d < _rr && _d > 0.0001) {
                var _nx = _px / _d, _ny = _py / _d;
                _b.x = _o.x + _nx * _rr; _b.y = _o.y + _ny * _rr;
                var _vn = _b.vx * _nx + _b.vy * _ny;
                if (_vn < 0) {
                    _b.vx -= (1 + min(_o.e, 1)) * _vn * _nx; _b.vy -= (1 + min(_o.e, 1)) * _vn * _ny;
                    if (_o.kind == "bumper" && _vn < -60) { _b.vx += _nx * 70; _b.vy += _ny * 70; }
                    _ev.bumps++;
                }
            }
        }
        for (var _i = 0; _i < array_length(_dyn); _i++) { var _q = _dyn[_i]; if (fwy__collide_seg(_b, _q[0], _q[1], _q[2], _q[3], _q[6], _q[4], _q[5])) _ev.bumps++; }
        var _spc = fwy__hyp(_b.vx, _b.vy);
        if (_spc > FWY_MAXV * 1.1) { _b.vx *= FWY_MAXV * 1.1 / _spc; _b.vy *= FWY_MAXV * 1.1 / _spc; }
        // obstacles that act: the ramp lip, the pipe
        for (var _i = 0; _i < array_length(_h.obstacles); _i++) {
            var _o = _h.obstacles[_i];
            if (_o.kind == "leap" && !_air) {
                var _before = (_o.dx != 0) ? ((_ox - _o.lipx) * _o.dx < 0) : ((_oy - _o.lipy) * _o.dy < 0);
                var _after = (_o.dx != 0) ? ((_b.x - _o.lipx) * _o.dx >= 0) : ((_b.y - _o.lipy) * _o.dy >= 0);
                var _inLane = (_o.dx != 0) ? (_b.y > _o.ry0 && _b.y < _o.ry1) : (_b.x > _o.rx0 && _b.x < _o.rx1);
                if (_before && _after && _inLane) {
                    var _fwd = _b.vx * _o.dx + _b.vy * _o.dy;
                    if (_fwd > 150) { _b.airT = clamp(fwy__hyp(_b.vx, _b.vy) / 780, 0.2, 0.6); _b.air = _b.airT; _ev.jump = true; _air = true; }
                }
            } else if (_o.kind == "pipe" && !_air) {
                if (fwy__hyp(_b.x - _o.ax, _b.y - _o.ay) < 13) {
                    var _v = max(fwy__hyp(_b.vx, _b.vy) * 0.8, 170);
                    _b.x = _o.bx + cos(_o.bdir) * (FWY_BALL_R + 18); _b.y = _o.by + sin(_o.bdir) * (FWY_BALL_R + 18);
                    _b.vx = cos(_o.bdir) * _v; _b.vy = sin(_o.bdir) * _v;
                    _ev.pipe = true;
                }
            }
        }
        if (_air) {
            _b.air -= _dt;
            if (_b.air <= 0) { _b.air = 0; _ev.landed = true; _b.vx *= 0.82; _b.vy *= 0.82; }
            else continue;
        }
        // water, then the cup
        if (fwy__haz_at(_h, _b.x, _b.y) == "water") { _ev.water = true; _b.vx = 0; _b.vy = 0; _b.moving = false; return; }
        var _cd2 = fwy__hyp(_b.x - _h.cupX, _b.y - _h.cupY);
        if (_cd2 < FWY_CUP_R - 3) {
            var _spd = fwy__hyp(_b.vx, _b.vy);
            if (_spd < FWY_CAPTURE) { _b.holed = true; _b.moving = false; _b.x = _h.cupX; _b.y = _h.cupY; _b.vx = 0; _b.vy = 0; _ev.holed = true; return; }
            if (!_ev.lipout) { _ev.lipout = true; var _ang = arctan2(_b.vy, _b.vx) + ((_b.x - _h.cupX) * _b.vy - (_b.y - _h.cupY) * _b.vx > 0 ? 0.35 : -0.35); _b.vx = cos(_ang) * _spd * 0.8; _b.vy = sin(_ang) * _spd * 0.8; }
        }
    }
    // at rest?
    if (_b.air <= 0) {
        var _spf = fwy__hyp(_b.vx, _b.vy);
        fwy__grad(_h, _b.x, _b.y);
        var _slope = FWY_G * fwy__hyp(global.fwy_gx, global.fwy_gy);
        var _mu2 = (fwy__haz_at(_h, _b.x, _b.y) == "sand") ? FWY_MU_SAND : FWY_MU;
        if (_spf < 3 && _slope <= _mu2) { _b.vx = 0; _b.vy = 0; _b.moving = false; _ev.stopped = true; }
    }
}

// ------------------------------------------------------------------------------------------------ the planner

/// @function fwy_shot_sim(hole, x, y, angle, power, t0, [maxSeconds])
/// @description Play one shot headless from (x, y) at hole time t0 and report where it ends: { holed, water, x, y, time,
/// bumps, jump, pipe }. A water ball reports the spot it was struck from (where it is replaced). Nothing is drawn.
/// @param {Struct} hole  from fwy_hole_create
/// @returns {Struct}
function fwy_shot_sim(_h, _x, _y, _ang, _pow, _t0, _maxS = 10) {
    var _res = { holed: false, water: false, x: _x, y: _y, time: 0, bumps: 0, jump: false, pipe: false };
    if (!is_struct(_h) || !variable_struct_exists(_h, "segs") || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_ang) || !is_numeric(_pow)) return _res;
    if (!is_numeric(_t0)) _t0 = 0;
    if (!is_numeric(_maxS)) _maxS = 10;
    var _b = fwy_ball_create(_x, _y);
    fwy_ball_shoot(_b, _ang, _pow);
    var _ev = { holed: false, water: false, pipe: false, jump: false, landed: false, bumps: 0, lipout: false, stopped: false };
    var _t = _t0, _steps = 0, _maxSteps = ceil(_maxS / FWY_DT);
    while (_b.moving && _steps < _maxSteps) {
        fwy__step(_h, _b, _t, _ev);
        _t += FWY_DT; _steps++;
        if (_ev.water || _ev.holed) break;
    }
    _res.holed = _ev.holed; _res.water = _ev.water; _res.bumps = _ev.bumps; _res.jump = _ev.jump; _res.pipe = _ev.pipe;
    _res.time = _steps * FWY_DT;
    if (_ev.water) { _res.x = _x; _res.y = _y; } else { _res.x = _b.x; _res.y = _b.y; }
    return _res;
}

/// @function fwy__los(hole, x0, y0, x1, y1)
/// @description Internal. Whether the straight path between two points stays on open felt (8 px steps).
function fwy__los(_h, _x0, _y0, _x1, _y1) {
    var _d = fwy__hyp(_x1 - _x0, _y1 - _y0), _n = max(1, ceil(_d / 8));
    for (var _i = 1; _i <= _n; _i++) {
        var _x = lerp(_x0, _x1, _i / _n), _y = lerp(_y0, _y1, _i / _n);
        var _w = _h.hgW, _o = clamp(round(_y / FWY_HG), 0, _h.hgH - 1) * _w + clamp(round(_x / FWY_HG), 0, _w - 1);
        if (!fwy_is_felt(_h, _x, _y) || !_h.geoOpen[_o]) return false;
    }
    return true;
}

/// @function fwy__plan(hole, x, y, t0)
/// @description Internal. The candidate shots from a point: straight at the cup (if it is in sight) at three paces, toward
/// the furthest-along felt in each of 16 directions at two paces, and two bank shots at full power. Each is simulated; the
/// best is the one that holes out, else the one that finishes nearest the cup along the felt (water counts as the start
/// plus a penalty). Returns { angle, power, res, sims }.
function fwy__plan(_h, _x, _y, _t0) {
    var _cands = [];
    var _cd = fwy__hyp(_h.cupX - _x, _h.cupY - _y);
    var _toCup = arctan2(_h.cupY - _y, _h.cupX - _x);
    var _pv = function(_d) { return clamp((sqrt(2 * FWY_MU * max(_d, 1)) - 40) / (FWY_MAXV - 40), 0.02, 1); };
    if (fwy__los(_h, _x, _y, _h.cupX, _h.cupY)) {
        array_push(_cands, [_toCup, _pv(_cd + 12)]); array_push(_cands, [_toCup, _pv(_cd + 45)]); array_push(_cands, [_toCup, _pv(_cd + 110)]);
    }
    // the fan: march each direction until blocked, score the end by its felt distance to the cup
    var _fan = [];
    for (var _k = 0; _k < 16; _k++) {
        var _a = _toCup + _k * pi / 8, _ca = cos(_a), _sa = sin(_a), _best = 1000000000, _bestD = 0, _d = 12;
        while (_d < 900) {
            var _px = _x + _ca * _d, _py = _y + _sa * _d;
            if (!fwy_is_felt(_h, _px, _py)) break;
            var _w = _h.hgW, _o = clamp(round(_py / FWY_HG), 0, _h.hgH - 1) * _w + clamp(round(_px / FWY_HG), 0, _w - 1);
            if (!_h.geoOpen[_o]) break;
            var _p = fwy__potential(_h, _px, _py);
            if (_p < _best) { _best = _p; _bestD = _d; }
            _d += 12;
        }
        if (_bestD > 20) array_push(_fan, [_best, _a, _bestD]);
    }
    array_sort(_fan, function(_a, _b) { return _a[0] - _b[0]; });
    for (var _k = 0; _k < min(4, array_length(_fan)); _k++) {
        array_push(_cands, [_fan[_k][1], _pv(_fan[_k][2] * 0.95)]);
        array_push(_cands, [_fan[_k][1], _pv(_fan[_k][2] * 1.35 + 40)]);
    }
    array_push(_cands, [_toCup + 0.5, 0.85]); array_push(_cands, [_toCup - 0.5, 0.85]);
    var _bestScore = 1000000000000, _bi = 0, _bres = undefined, _ran = 0;
    var _p0 = fwy__potential(_h, _x, _y);
    for (var _i = 0; _i < array_length(_cands); _i++) {
        var _r = fwy_shot_sim(_h, _x, _y, _cands[_i][0], _cands[_i][1], _t0, 9);
        _ran++;
        var _sc = _r.holed ? -1000 + _r.time : (_r.water ? _p0 + 400 : fwy__potential(_h, _r.x, _r.y));
        if (_sc < _bestScore) { _bestScore = _sc; _bi = _i; _bres = _r; }
        if (_r.holed && _i < 3) break;
    }
    return { angle: _cands[_bi][0], power: _cands[_bi][1], res: _bres, sims: _ran };
}

/// @function fwy__solve(hole)
/// @description Internal. Play the hole from the tee with the planner (at two clock phases when anything on it moves) and
/// set its par from the strokes taken. False when the planner cannot finish within 6 strokes.
function fwy__solve(_h) {
    var _moving = false;
    for (var _i = 0; _i < array_length(_h.obstacles); _i++) { var _k = _h.obstacles[_i].kind; if (_k == "gate" || _k == "spinner" || _k == "mill") _moving = true; }
    var _phases = _moving ? [0, 1.37] : [0];
    var _worst = 0, _sims = 0, _strokesAll = [];
    for (var _p = 0; _p < array_length(_phases); _p++) {
        var _x = _h.teeX, _y = _h.teeY, _t = _phases[_p], _strokes = 0, _done = false;
        while (_strokes < 6) {
            var _pl = fwy__plan(_h, _x, _y, _t + 1);
            _sims += _pl.sims;
            _strokes++;
            if (_pl.res.water) _strokes++;
            _t += 1 + _pl.res.time;
            if (_pl.res.holed) { _done = true; break; }
            _x = _pl.res.x; _y = _pl.res.y;
        }
        if (!_done) { _h.solve = { ok: false, sims: _sims, strokes: _strokesAll }; return false; }
        array_push(_strokesAll, _strokes);
        _worst = max(_worst, _strokes);
    }
    _h.par = clamp(_worst + 1, 2, 5);
    _h.planned = _worst;
    _h.solve = { ok: true, sims: _sims, strokes: _strokesAll };
    return true;
}

/// @function fwy_shot_suggest(hole, ball, t0, [skill])
/// @description The planner's shot for a resting ball at hole time t0, with aim and pace scattered by (1 - skill) for an AI
/// rival (skill 1 plays the planner's own shot). Returns { angle, power } (a non-ball returns angle 0, power 0.5).
/// @param {Real} [skill]  0..1 (1)
function fwy_shot_suggest(_h, _b, _t0, _skill = 1) {
    if (!is_struct(_h) || !variable_struct_exists(_h, "segs") || !is_struct(_b) || !variable_struct_exists(_b, "x")) return { angle: 0, power: 0.5 };
    if (!is_numeric(_t0)) _t0 = 0;
    if (!is_numeric(_skill)) _skill = 1;
    _skill = clamp(_skill, 0, 1);
    var _pl = fwy__plan(_h, _b.x, _b.y, _t0);
    var _sc = 1 - _skill;
    var _g = fwy_rng(floor(_b.x * 31 + _b.y * 17 + _t0 * 1000));
    var _n1 = (fwy_rand(_g) + fwy_rand(_g) + fwy_rand(_g) - 1.5), _n2 = (fwy_rand(_g) + fwy_rand(_g) + fwy_rand(_g) - 1.5);
    return { angle: _pl.angle + _n1 * 0.4 * _sc, power: clamp(_pl.power * (1 + _n2 * 0.6 * _sc), 0.02, 1) };
}

// ------------------------------------------------------------------------------------------------ courses

/// @function fwy_course_create(seed, theme, [holes], [opts])
/// @description A course of 9 or 18 holes on one theme, difficulty rising through the round, the main feature varied from
/// hole to hole. With opts.lazy only the first hole is made now; fwy_course_hole makes the rest on demand.
/// @param {Real} holes  9 or 18 (9)
/// @param {Struct} [opts]  { lazy: false }
/// @returns {Struct} { seed, theme, title, count, holes[] (undefined until made), made, buildMs }
function fwy_course_create(_seed, _theme, _holes = 9, _opts = undefined) {
    if (!is_numeric(_seed)) _seed = 1;
    if (!fwy__theme_ok(_theme)) _theme = "garden";
    _holes = (is_numeric(_holes) && _holes >= 18) ? 18 : 9;
    var _lazy = is_struct(_opts) && variable_struct_exists(_opts, "lazy") && _opts.lazy == true;
    var _c = { seed: floor(_seed), theme: _theme, title: fwy_theme(_theme).title, count: _holes, holes: array_create(_holes, undefined), made: 0, buildMs: 0, recent: [] };
    var _t0 = get_timer();
    var _n = _lazy ? 1 : _holes;
    for (var _i = 0; _i < _n; _i++) fwy_course_hole(_c, _i);
    _c.buildMs = (get_timer() - _t0) / 1000;
    return _c;
}

/// @function fwy_course_hole(course, index)
/// @description The course's hole at index (0-based), made now if it has not been. undefined for an index off the course.
function fwy_course_hole(_c, _i) {
    if (!is_struct(_c) || !variable_struct_exists(_c, "holes") || !is_numeric(_i)) return undefined;
    _i = floor(_i);
    if (_i < 0 || _i >= _c.count) return undefined;
    if (is_undefined(_c.holes[_i])) {
        var _diff = clamp(0.15 + 0.8 * _i / max(1, _c.count - 1), 0, 1);
        var _all = ["mill", "gate", "spinner", "leap", "pipe", "bumpers", "wedges", "sand", "water", "hills"];
        var _pref = [_all[((_i * 3 + _c.seed) mod array_length(_all) + array_length(_all)) mod array_length(_all)]];
        var _h = fwy_hole_create(_c.seed * 1009 + _i * 97 + 11, _c.theme, { difficulty: _diff, features: _pref });
        _h.index = _i;
        // no two holes of a course share a name: move a colliding one to the theme's next unused word
        var _used = function(_cc, _nm) { for (var _q = 0; _q < _cc.count; _q++) if (!is_undefined(_cc.holes[_q]) && _cc.holes[_q].name == _nm) return true; return false; };
        if (_used(_c, _h.name)) {
            var _sp = string_pos(" ", _h.name), _noun = string_delete(_h.name, 1, _sp), _A = fwy__adjectives(_c.theme);
            for (var _q = 0; _q < array_length(_A); _q++) { var _nm = _A[(_i + _q) mod array_length(_A)] + " " + _noun; if (!_used(_c, _nm)) { _h.name = _nm; break; } }
        }
        _c.holes[_i] = _h;
        _c.made++;
    }
    return _c.holes[_i];
}

/// @function fwy_course_par(course)
/// @description The course's total par over the holes made so far, and how many that is: [par, holesMade].
function fwy_course_par(_c) {
    if (!is_struct(_c) || !variable_struct_exists(_c, "holes")) return [0, 0];
    var _p = 0, _n = 0;
    for (var _i = 0; _i < _c.count; _i++) if (!is_undefined(_c.holes[_i])) { _p += _c.holes[_i].par; _n++; }
    return [_p, _n];
}

// ------------------------------------------------------------------------------------------------ the game

/// @function fwy_game_create(course, players)
/// @description A round of mini golf on a course for 1-4 players, each { name, colour, ai: false | skill 0..1 }. Players play
/// each hole in turn, to the cup or to the stroke limit (FWY_LIMIT). A ball in the water costs a penalty stroke and is
/// replayed from where it was struck.
/// @returns {Struct} the game: { course, players, hole, turn, state ("aim" | "rolling" | "holed" | "done"), clock, scores[][],
///          events[] (this step's), ball }
function fwy_game_create(_course, _players) {
    if (!is_struct(_course) || !variable_struct_exists(_course, "holes")) return undefined;
    if (!is_array(_players) || array_length(_players) == 0) _players = [{ name: "PLAYER", colour: c_white, ai: false }];
    var _np = min(4, array_length(_players)), _ps = [];
    var _cols = [make_colour_rgb(250, 250, 246), make_colour_rgb(255, 196, 40), make_colour_rgb(255, 92, 120), make_colour_rgb(90, 200, 255)];
    for (var _i = 0; _i < _np; _i++) {
        var _p = _players[_i];
        if (!is_struct(_p)) _p = {};
        var _nm = (variable_struct_exists(_p, "name") && is_string(_p.name)) ? string_upper(string_copy(_p.name, 1, 10)) : ("PLAYER " + string(_i + 1));
        var _col = (variable_struct_exists(_p, "colour") && is_numeric(_p.colour)) ? _p.colour : _cols[_i];
        var _ai = (variable_struct_exists(_p, "ai") && is_numeric(_p.ai) && !is_bool(_p.ai)) ? clamp(_p.ai, 0, 1) : -1;
        array_push(_ps, { name: _nm, colour: _col, ai: _ai });
    }
    var _sc = [];
    for (var _i = 0; _i < _np; _i++) array_push(_sc, array_create(_course.count, -1));
    var _G = { course: _course, players: _ps, hole: 0, turn: 0, state: "aim", clock: 0, acc: 0, scores: _sc, strokes: 0, events: [],
               ball: undefined, aiPlan: undefined, aiWait: 0, held: 0, last: undefined };
    fwy__game_place(_G);
    return _G;
}

/// @function fwy__game_place(game)
/// @description Internal. Put the current player's ball on the current hole's tee.
function fwy__game_place(_G) {
    var _h = fwy_course_hole(_G.course, _G.hole);
    _G.ball = fwy_ball_create(_h.teeX, _h.teeY);
    _G.strokes = 0; _G.state = "aim"; _G.aiPlan = undefined; _G.aiWait = 0.9;
}

/// @function fwy_game_hole(game)
/// @description The hole being played.
function fwy_game_hole(_G) { if (!is_struct(_G) || !variable_struct_exists(_G, "course")) return undefined; return fwy_course_hole(_G.course, _G.hole); }

/// @function fwy_game_ball(game)
/// @description The ball in play (the current player's).
function fwy_game_ball(_G) { if (!is_struct(_G) || !variable_struct_exists(_G, "ball")) return undefined; return _G.ball; }

/// @function fwy_game_shoot(game, angle, power)
/// @description The current player strikes the ball (angle in radians, power 0..1). Refused (false) unless the game is waiting
/// for a shot.
function fwy_game_shoot(_G, _ang, _pow) {
    if (!is_struct(_G) || !variable_struct_exists(_G, "state") || _G.state != "aim") return false;
    if (!fwy_ball_shoot(_G.ball, _ang, _pow)) return false;
    _G.strokes++; _G.state = "rolling";
    array_push(_G.events, { type: "shot", player: _G.turn, strokes: _G.strokes });
    return true;
}

/// @function fwy_score_name(strokes, par)
/// @description The word for a score against par: "HOLE IN ONE", "ALBATROSS", "EAGLE", "BIRDIE", "PAR", "BOGEY", "DOUBLE
/// BOGEY", "+3"...
function fwy_score_name(_s, _par) {
    if (!is_numeric(_s) || !is_numeric(_par)) return "";
    if (_s == 1) return "HOLE IN ONE";
    switch (_s - _par) { case -3: return "ALBATROSS"; case -2: return "EAGLE"; case -1: return "BIRDIE"; case 0: return "PAR"; case 1: return "BOGEY"; case 2: return "DOUBLE BOGEY"; }
    if (_s - _par < -3) return "CONDOR";
    return "+" + string(_s - _par);
}

/// @function fwy_game_step(game, dt)
/// @description Advance the game by dt seconds: the hole clock (obstacles keep moving), the ball in fixed steps, AI turns,
/// penalties, holing out, the stroke limit, turns and holes. game.events lists what happened during this call (shot, water,
/// pipe, jump, bump, lipout, holed { strokes, par, name }, limit, next_hole, done).
function fwy_game_step(_G, _dt) {
    if (!is_struct(_G) || !variable_struct_exists(_G, "state")) return;
    if (!is_numeric(_dt)) _dt = 0;
    _dt = clamp(_dt, 0, 0.1);
    _G.events = [];
    if (_G.state == "done") return;
    var _h = fwy_game_hole(_G);
    _G.acc += _dt;
    while (_G.acc >= FWY_DT) {
        _G.acc -= FWY_DT;
        _G.clock += FWY_DT;
        if (_G.state == "rolling") {
            var _ev = { holed: false, water: false, pipe: false, jump: false, landed: false, bumps: 0, lipout: false, stopped: false };
            fwy__step(_h, _G.ball, _G.clock, _ev);
            if (_ev.bumps > 0) array_push(_G.events, { type: "bump", n: _ev.bumps });
            if (_ev.pipe) array_push(_G.events, { type: "pipe" });
            if (_ev.jump) array_push(_G.events, { type: "jump" });
            if (_ev.lipout) array_push(_G.events, { type: "lipout" });
            if (_ev.water) {
                _G.strokes++;
                _G.ball.x = _G.ball.lastX; _G.ball.y = _G.ball.lastY; _G.ball.moving = false;
                array_push(_G.events, { type: "water", strokes: _G.strokes });
            }
            if (_ev.holed) {
                _G.state = "holed"; _G.held = 2.2;
                _G.scores[_G.turn][_G.hole] = _G.strokes;
                array_push(_G.events, { type: "holed", player: _G.turn, strokes: _G.strokes, par: _h.par, name: fwy_score_name(_G.strokes, _h.par) });
            } else if (!_G.ball.moving) {
                if (_G.strokes >= FWY_LIMIT) {
                    _G.state = "holed"; _G.held = 2.2;
                    _G.scores[_G.turn][_G.hole] = FWY_LIMIT;
                    array_push(_G.events, { type: "limit", player: _G.turn, strokes: FWY_LIMIT });
                } else { _G.state = "aim"; _G.aiPlan = undefined; _G.aiWait = 0.7; }
            }
        }
    }
    if (_G.state == "aim" && _G.players[_G.turn].ai >= 0) {
        _G.aiWait -= _dt;
        if (is_undefined(_G.aiPlan)) _G.aiPlan = fwy_shot_suggest(_h, _G.ball, _G.clock + max(0, _G.aiWait), _G.players[_G.turn].ai);
        if (_G.aiWait <= 0) fwy_game_shoot(_G, _G.aiPlan.angle, _G.aiPlan.power);
    }
    if (_G.state == "holed") {
        _G.held -= _dt;
        if (_G.held <= 0) {
            _G.turn++;
            if (_G.turn >= array_length(_G.players)) {
                _G.turn = 0; _G.hole++;
                if (_G.hole >= _G.course.count) { _G.state = "done"; _G.hole = _G.course.count - 1; array_push(_G.events, { type: "done" }); return; }
                array_push(_G.events, { type: "next_hole", hole: _G.hole });
            }
            fwy__game_place(_G);
        }
    }
}

/// @function fwy_game_scores(game)
/// @description Every player's strokes per hole (-1 where not yet played): scores[player][hole].
function fwy_game_scores(_G) { if (!is_struct(_G) || !variable_struct_exists(_G, "scores")) return []; return _G.scores; }

/// @function fwy_game_total(game, player)
/// @description A player's total strokes so far and the par of the holes they have finished: [strokes, par, holes].
function fwy_game_total(_G, _p) {
    if (!is_struct(_G) || !variable_struct_exists(_G, "scores") || !is_numeric(_p)) return [0, 0, 0];
    _p = floor(_p);
    if (_p < 0 || _p >= array_length(_G.scores)) return [0, 0, 0];
    var _s = 0, _par = 0, _n = 0;
    for (var _i = 0; _i < _G.course.count; _i++) if (_G.scores[_p][_i] >= 0) { _s += _G.scores[_p][_i]; _par += _G.course.holes[_i].par; _n++; }
    return [_s, _par, _n];
}
