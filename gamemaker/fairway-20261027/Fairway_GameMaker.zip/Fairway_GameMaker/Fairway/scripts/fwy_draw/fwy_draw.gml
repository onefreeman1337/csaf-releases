/// fwy_draw.gml - Fairway's drawing: each hole baked once into a sprite (the ground round the course, the felt shaded by its
/// own slopes and striped by the mower, the nap, water and sand, the bevelled rails of six materials, the tee mat, the cup,
/// the ramps, pipes, wedges and bumpers, and the scenery), then the moving pieces drawn live over it (the theme's windmill
/// building with its turning sails, the swing gate, the spinner, the flag), the ball with its shadow and its flight, the aim
/// line with its first bounce, the power gauge, a drawn paper scorecard with pencil figures, and the HUD. Everything is drawn
/// from primitives: the package ships no image files.
///
/// Public functions: fwy_hole_bake, fwy_hole_free, fwy_hole_view, fwy_hole_draw, fwy_hole_draw_over, fwy_ball_draw, fwy_aim_draw,
/// fwy_power_draw, fwy_scorecard_draw, fwy_hud_draw, fwy_piece_draw, fwy_pieces, fwy_draw_free.
///
/// Fairway - Mini Golf for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

#macro FWY_FLUSH 900
#macro FWY_RAIL 14

// ------------------------------------------------------------------------------------------------ colour and primitives

/// @function fwy__rgb(r, g, b)
/// @description Internal. make_colour_rgb, clamped.
function fwy__rgb(_r, _g, _b) { return make_colour_rgb(clamp(_r, 0, 255), clamp(_g, 0, 255), clamp(_b, 0, 255)); }

/// @function fwy__mul(col, f)
/// @description Internal. Each channel times f (f > 1 brightens, saturating).
function fwy__mul(_c, _f) { return fwy__rgb(colour_get_red(_c) * _f, colour_get_green(_c) * _f, colour_get_blue(_c) * _f); }

/// @function fwy__mix(a, b, t)
/// @description Internal. merge_colour, clamped.
function fwy__mix(_a, _b, _t) { return merge_colour(_a, _b, clamp(_t, 0, 1)); }

/// @function fwy__pal(theme)
/// @description Internal. A theme's palette.
function fwy__pal(_t) {
    var _p = { felt: fwy__rgb(58, 150, 72), ground: fwy__rgb(214, 196, 160), ground2: fwy__rgb(196, 176, 140), joint: fwy__rgb(160, 140, 108),
               rail: fwy__rgb(150, 98, 54), railHi: fwy__rgb(206, 150, 92), railLo: fwy__rgb(92, 56, 28), accent: fwy__rgb(230, 70, 80),
               water: fwy__rgb(46, 120, 180), waterLo: fwy__rgb(24, 70, 130), waterHi: fwy__rgb(170, 220, 240), sand: fwy__rgb(232, 210, 158), sandLo: fwy__rgb(196, 168, 112),
               mat: fwy__rgb(46, 92, 54), cup: fwy__rgb(20, 22, 18), flag: fwy__rgb(230, 52, 58), shadow: fwy__rgb(20, 30, 16), glow: fwy__rgb(255, 230, 150), dark: false };
    switch (_t) {
        case "pirate":
            _p.felt = fwy__rgb(36, 146, 128); _p.ground = fwy__rgb(238, 214, 156); _p.ground2 = fwy__rgb(224, 196, 136); _p.joint = fwy__rgb(200, 170, 112);
            _p.rail = fwy__rgb(138, 96, 60); _p.railHi = fwy__rgb(196, 152, 104); _p.railLo = fwy__rgb(86, 56, 32); _p.accent = fwy__rgb(214, 186, 120);
            _p.water = fwy__rgb(30, 170, 190); _p.waterLo = fwy__rgb(16, 104, 150); _p.waterHi = fwy__rgb(210, 250, 245); _p.sand = fwy__rgb(246, 230, 186); _p.sandLo = fwy__rgb(214, 190, 136);
            _p.mat = fwy__rgb(20, 92, 86); _p.flag = fwy__rgb(24, 24, 28); _p.shadow = fwy__rgb(60, 50, 20); break;
        case "haunted":
            _p.felt = fwy__rgb(64, 104, 80); _p.ground = fwy__rgb(70, 66, 82); _p.ground2 = fwy__rgb(60, 56, 72); _p.joint = fwy__rgb(40, 38, 50);
            _p.rail = fwy__rgb(108, 106, 116); _p.railHi = fwy__rgb(160, 158, 170); _p.railLo = fwy__rgb(52, 50, 60); _p.accent = fwy__rgb(40, 40, 46);
            _p.water = fwy__rgb(70, 128, 52); _p.waterLo = fwy__rgb(36, 74, 30); _p.waterHi = fwy__rgb(180, 240, 120); _p.sand = fwy__rgb(98, 76, 58); _p.sandLo = fwy__rgb(70, 52, 38);
            _p.mat = fwy__rgb(40, 60, 50); _p.flag = fwy__rgb(250, 140, 40); _p.shadow = fwy__rgb(10, 8, 16); _p.glow = fwy__rgb(255, 196, 90); _p.dark = true; break;
        case "candy":
            _p.felt = fwy__rgb(84, 204, 168); _p.ground = fwy__rgb(252, 200, 222); _p.ground2 = fwy__rgb(246, 182, 210); _p.joint = fwy__rgb(230, 150, 186);
            _p.rail = fwy__rgb(246, 246, 246); _p.railHi = fwy__rgb(255, 255, 255); _p.railLo = fwy__rgb(200, 190, 196); _p.accent = fwy__rgb(226, 40, 60);
            _p.water = fwy__rgb(196, 102, 54); _p.waterLo = fwy__rgb(132, 62, 30); _p.waterHi = fwy__rgb(246, 196, 140); _p.sand = fwy__rgb(252, 248, 240); _p.sandLo = fwy__rgb(222, 214, 220);
            _p.mat = fwy__rgb(226, 80, 140); _p.flag = fwy__rgb(120, 70, 220); _p.shadow = fwy__rgb(150, 70, 110); break;
        case "space":
            _p.felt = fwy__rgb(40, 92, 176); _p.ground = fwy__rgb(46, 52, 66); _p.ground2 = fwy__rgb(54, 60, 76); _p.joint = fwy__rgb(26, 30, 40);
            _p.rail = fwy__rgb(150, 160, 176); _p.railHi = fwy__rgb(214, 222, 234); _p.railLo = fwy__rgb(70, 78, 94); _p.accent = fwy__rgb(80, 220, 255);
            _p.water = fwy__rgb(8, 8, 20); _p.waterLo = fwy__rgb(2, 2, 8); _p.waterHi = fwy__rgb(120, 200, 255); _p.sand = fwy__rgb(150, 146, 150); _p.sandLo = fwy__rgb(112, 108, 114);
            _p.mat = fwy__rgb(30, 40, 60); _p.flag = fwy__rgb(255, 200, 40); _p.shadow = fwy__rgb(6, 8, 14); _p.glow = fwy__rgb(120, 230, 255); _p.dark = true; break;
        case "desert":
            _p.felt = fwy__rgb(104, 150, 62); _p.ground = fwy__rgb(226, 170, 104); _p.ground2 = fwy__rgb(212, 152, 88); _p.joint = fwy__rgb(184, 126, 70);
            _p.rail = fwy__rgb(214, 176, 118); _p.railHi = fwy__rgb(244, 214, 160); _p.railLo = fwy__rgb(150, 112, 66); _p.accent = fwy__rgb(40, 110, 150);
            _p.water = fwy__rgb(196, 160, 100); _p.waterLo = fwy__rgb(150, 112, 62); _p.waterHi = fwy__rgb(238, 210, 150); _p.sand = fwy__rgb(242, 196, 128); _p.sandLo = fwy__rgb(204, 150, 88);
            _p.mat = fwy__rgb(120, 70, 40); _p.flag = fwy__rgb(40, 110, 170); _p.shadow = fwy__rgb(110, 60, 20); break;
    }
    _p.feltHi = fwy__mul(_p.felt, 1.07); _p.feltLo = fwy__mul(_p.felt, 0.9);
    return _p;
}

/// @function fwy__over()
/// @description Internal. Colour blends normally, alpha as "over" (a translucent mark keeps an opaque surface opaque, wing
/// doctrine s15). Inside gpu_push_state / gpu_pop_state.
function fwy__over() { gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha); }

/// @function fwy__quad(x1,y1,x2,y2,x3,y3,x4,y4,col,alpha)
/// @description Internal. One filled quad (corners in order round it).
function fwy__quad(_x1, _y1, _x2, _y2, _x3, _y3, _x4, _y4, _col, _al) {
    draw_primitive_begin(pr_trianglestrip);
    draw_vertex_colour(_x1, _y1, _col, _al); draw_vertex_colour(_x2, _y2, _col, _al);
    draw_vertex_colour(_x4, _y4, _col, _al); draw_vertex_colour(_x3, _y3, _col, _al);
    draw_primitive_end();
}

/// @function fwy__tri(x1,y1,x2,y2,x3,y3,col,alpha)
/// @description Internal. One filled triangle.
function fwy__tri(_x1, _y1, _x2, _y2, _x3, _y3, _col, _al) {
    draw_primitive_begin(pr_trianglelist);
    draw_vertex_colour(_x1, _y1, _col, _al); draw_vertex_colour(_x2, _y2, _col, _al); draw_vertex_colour(_x3, _y3, _col, _al);
    draw_primitive_end();
}

/// @function fwy__rect(x0, y0, x1, y1, col, alpha)
/// @description Internal. An axis-aligned filled rectangle.
function fwy__rect(_x0, _y0, _x1, _y1, _col, _al) { fwy__quad(_x0, _y0, _x1, _y0, _x1, _y1, _x0, _y1, _col, _al); }

/// @function fwy__orect(cx, cy, ang, len, dep, col, alpha)
/// @description Internal. A rectangle centred at (cx, cy), long axis at angle ang (radians, room space).
function fwy__orect(_cx, _cy, _ang, _len, _dep, _col, _al) {
    var _ex = cos(_ang) * _len / 2, _ey = sin(_ang) * _len / 2, _qx = -sin(_ang) * _dep / 2, _qy = cos(_ang) * _dep / 2;
    fwy__quad(_cx - _ex - _qx, _cy - _ey - _qy, _cx + _ex - _qx, _cy + _ey - _qy, _cx + _ex + _qx, _cy + _ey + _qy, _cx - _ex + _qx, _cy - _ey + _qy, _col, _al);
}

/// @function fwy__bar(x1, y1, x2, y2, w, col, alpha)
/// @description Internal. A bar of width w between two points (butt ends).
function fwy__bar(_x1, _y1, _x2, _y2, _w, _col, _al) {
    var _dx = _x2 - _x1, _dy = _y2 - _y1, _l = max(0.0001, sqrt(_dx * _dx + _dy * _dy)), _nx = -_dy / _l * _w / 2, _ny = _dx / _l * _w / 2;
    fwy__quad(_x1 + _nx, _y1 + _ny, _x2 + _nx, _y2 + _ny, _x2 - _nx, _y2 - _ny, _x1 - _nx, _y1 - _ny, _col, _al);
}

/// @function fwy__disc(x, y, r, col, alpha, [segments])
/// @description Internal. A filled disc.
function fwy__disc(_x, _y, _r, _col, _al, _segs = 0) {
    var _m = (_segs > 0) ? _segs : clamp(floor(_r * 0.9) + 8, 8, 48);
    draw_primitive_begin(pr_trianglefan);
    draw_vertex_colour(_x, _y, _col, _al);
    for (var _k = 0; _k <= _m; _k++) { var _a = _k / _m * pi * 2; draw_vertex_colour(_x + cos(_a) * _r, _y + sin(_a) * _r, _col, _al); }
    draw_primitive_end();
}

/// @function fwy__ellipse(x, y, rx, ry, col, alpha)
/// @description Internal. An axis-aligned filled ellipse.
function fwy__ellipse(_x, _y, _rx, _ry, _col, _al) {
    var _m = clamp(floor(max(_rx, _ry) * 0.8) + 10, 10, 56);
    draw_primitive_begin(pr_trianglefan);
    draw_vertex_colour(_x, _y, _col, _al);
    for (var _k = 0; _k <= _m; _k++) { var _a = _k / _m * pi * 2; draw_vertex_colour(_x + cos(_a) * _rx, _y + sin(_a) * _ry, _col, _al); }
    draw_primitive_end();
}

/// @function fwy__ring(x, y, r0, r1, col, alpha)
/// @description Internal. A filled annulus.
function fwy__ring(_x, _y, _r0, _r1, _col, _al) {
    var _m = clamp(floor(_r1 * 0.9) + 10, 10, 56);
    draw_primitive_begin(pr_trianglestrip);
    for (var _k = 0; _k <= _m; _k++) { var _a = _k / _m * pi * 2; draw_vertex_colour(_x + cos(_a) * _r1, _y + sin(_a) * _r1, _col, _al); draw_vertex_colour(_x + cos(_a) * _r0, _y + sin(_a) * _r0, _col, _al); }
    draw_primitive_end();
}

/// @function fwy__glow(x, y, r, col, alpha)
/// @description Internal. A radial glow (bright centre to clear rim).
function fwy__glow(_x, _y, _r, _col, _al) {
    draw_primitive_begin(pr_trianglefan);
    draw_vertex_colour(_x, _y, _col, _al);
    for (var _k = 0; _k <= 28; _k++) { var _a = _k / 28 * pi * 2; draw_vertex_colour(_x + cos(_a) * _r, _y + sin(_a) * _r, _col, 0); }
    draw_primitive_end();
}

/// @function fwy__poly(xs, ys, col, alpha)
/// @description Internal. A filled polygon, star-shaped about its centroid (a fan from the centroid).
function fwy__poly(_xs, _ys, _col, _al) {
    var _n = array_length(_xs), _cx = 0, _cy = 0;
    for (var _i = 0; _i < _n; _i++) { _cx += _xs[_i]; _cy += _ys[_i]; }
    _cx /= _n; _cy /= _n;
    draw_primitive_begin(pr_trianglefan);
    draw_vertex_colour(_cx, _cy, _col, _al);
    for (var _i = 0; _i <= _n; _i++) draw_vertex_colour(_xs[_i mod _n], _ys[_i mod _n], _col, _al);
    draw_primitive_end();
}

/// @function fwy__poly_s(xs, ys, s, ox, oy, col, alpha)
/// @description Internal. fwy__poly of the outline scaled by s about its centroid and moved by (ox, oy).
function fwy__poly_s(_xs, _ys, _s, _ox, _oy, _col, _al) {
    var _n = array_length(_xs), _cx = 0, _cy = 0, _a = [], _b = [];
    for (var _i = 0; _i < _n; _i++) { _cx += _xs[_i]; _cy += _ys[_i]; }
    _cx /= _n; _cy /= _n;
    for (var _i = 0; _i < _n; _i++) { array_push(_a, _cx + (_xs[_i] - _cx) * _s + _ox); array_push(_b, _cy + (_ys[_i] - _cy) * _s + _oy); }
    fwy__poly(_a, _b, _col, _al);
}

/// @function fwy__line(x1, y1, x2, y2, w, col, alpha)
/// @description Internal. draw_line_width with colour and alpha.
function fwy__line(_x1, _y1, _x2, _y2, _w, _col, _al) { draw_set_colour(_col); draw_set_alpha(_al); draw_line_width(_x1, _y1, _x2, _y2, _w); draw_set_alpha(1); }

/// @function fwy__pts_begin() / fwy__pt(x, y, col, alpha) / fwy__pts_end()
/// @description Internal. A point list flushed every FWY_FLUSH vertices.
function fwy__pts_begin() { global.fwy_pv = 0; draw_primitive_begin(pr_pointlist); }
function fwy__pt(_x, _y, _col, _al) { draw_vertex_colour(_x, _y, _col, _al); global.fwy_pv++; if (global.fwy_pv >= FWY_FLUSH) { draw_primitive_end(); draw_primitive_begin(pr_pointlist); global.fwy_pv = 0; } }
function fwy__pts_end() { draw_primitive_end(); }

/// @function fwy__text(x, y, s, font, scale, col, alpha, [halign], [angle])
/// @description Internal. Text with filtering on while scaled (a 1 px stroke survives a scale below 1, wing doctrine s3),
/// restoring the caller's filter, font, colour, alpha and alignment.
function fwy__text(_x, _y, _s, _font, _sc, _col, _al, _ha = fa_left, _ang = 0) {
    var _tf = gpu_get_texfilter(), _f = draw_get_font(), _hh = draw_get_halign(), _vv = draw_get_valign(), _c = draw_get_colour(), _a = draw_get_alpha();
    gpu_set_texfilter(true);
    draw_set_font(_font); draw_set_halign(_ha); draw_set_valign(fa_middle);
    draw_set_colour(_col); draw_set_alpha(_al);
    draw_text_transformed(_x, _y, _s, _sc, _sc, _ang);
    draw_set_font(_f); draw_set_halign(_hh); draw_set_valign(_vv); draw_set_colour(_c); draw_set_alpha(_a);
    gpu_set_texfilter(_tf);
}

// ------------------------------------------------------------------------------------------------ the hole bake

/// @function fwy_hole_bake(hole, [scale])
/// @description Draw everything on a hole that does not move once into a sprite (960 x 576 x scale) kept on the hole as
/// hole.sprite: ground and scenery, felt with slope shading, mower stripes and nap, water and sand, rails, tee mat, cup,
/// ramps, pipes, wedges and bumpers. Runs under its own identity transform and hands the caller's world matrix and blend
/// back, so it may be called from any event. Re-baking replaces the old sprite; the time is kept in hole.bakeMs.
/// @param {Struct} hole  from fwy_hole_create
/// @param {Real} [scale]  0.25 .. 2 (1)
/// @returns {Asset.GMSprite} the sprite, or -1 for a bad hole
function fwy_hole_bake(_h, _scale = 1) {
    if (!is_struct(_h) || !variable_struct_exists(_h, "cells") || !variable_struct_exists(_h, "hg")) return -1;
    if (!is_numeric(_scale)) _scale = 1;
    _scale = clamp(_scale, 0.25, 2);
    var _t0 = get_timer();
    var _w = max(16, floor(FWY_W * _scale)), _hh = max(16, floor(FWY_H * _scale));
    var _mw = matrix_get(matrix_world);
    var _surf = surface_create(_w, _hh);
    surface_set_target(_surf);
    draw_clear_alpha(c_black, 1);
    gpu_push_state();
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false);
    fwy__over();
    matrix_set(matrix_world, matrix_build(0, 0, 0, 0, 0, 0, _scale, _scale, 1));
    var _P = fwy__pal(_h.theme), _g = fwy_rng(_h.layoutSeed * 3 + 1);
    fwy__paint_ground(_h, _P, _g);
    fwy__paint_decor(_h, _P, true);
    fwy__paint_felt(_h, _P, _g);
    fwy__paint_hazards(_h, _P, _g);
    fwy__paint_relief_marks(_h, _P);
    fwy__paint_rails(_h, _P);
    fwy__paint_tee(_h, _P);
    fwy__paint_cup(_h, _P);
    fwy__paint_statics(_h, _P, _g);
    fwy__paint_decor(_h, _P, false);
    gpu_pop_state();
    matrix_set(matrix_world, _mw);
    surface_reset_target();
    if (variable_struct_exists(_h, "sprite") && sprite_exists(_h.sprite)) sprite_delete(_h.sprite);
    _h.sprite = sprite_create_from_surface(_surf, 0, 0, _w, _hh, false, false, 0, 0);
    _h.bakeScale = _scale;
    surface_free(_surf);
    _h.bakeMs = (get_timer() - _t0) / 1000;
    return _h.sprite;
}

/// @function fwy_hole_free(hole)
/// @description Free the hole's baked sprite. Safe to call twice.
function fwy_hole_free(_h) {
    if (!is_struct(_h)) return;
    if (variable_struct_exists(_h, "sprite") && sprite_exists(_h.sprite)) sprite_delete(_h.sprite);
    _h.sprite = -1;
}

/// @function fwy__paint_ground(hole, P, g)
/// @description Internal. The ground round the course: paving (garden), rippled beach (pirate), flagstones (haunted), iced
/// frosting with sprinkles (candy), deck plates (space), dunes and fallen blocks (desert).
function fwy__paint_ground(_h, _P, _g) {
    var _W = FWY_W, _H = FWY_H, _t = _h.theme;
    draw_rectangle_colour(0, 0, _W, _H, _P.ground, _P.ground, fwy__mul(_P.ground, 0.92), fwy__mul(_P.ground, 0.92), false);
    if (_t == "garden" || _t == "haunted") {
        // offset slabs, each a little different in tone
        var _sw = (_t == "garden") ? 48 : 40, _sh = (_t == "garden") ? 32 : 40;
        for (var _y = 0; _y < _H; _y += _sh) {
            var _off = ((_y / _sh) mod 2) * _sw / 2;
            for (var _x = -_sw; _x < _W + _sw; _x += _sw) {
                var _c = fwy__mix(_P.ground, _P.ground2, fwy_rand(_g));
                fwy__rect(_x + _off + 1.5, _y + 1.5, _x + _off + _sw - 1.5, _y + _sh - 1.5, _c, 1);
                fwy__rect(_x + _off + 1.5, _y + 1.5, _x + _off + _sw - 1.5, _y + 4, fwy__mul(_c, 1.06), 0.7);
                if (_t == "haunted" && fwy_rand(_g) < 0.25) fwy__ellipse(_x + _off + fwy_range(_g, 8, _sw - 8), _y + fwy_range(_g, 8, _sh - 8), fwy_range(_g, 5, 12), fwy_range(_g, 3, 7), fwy__rgb(64, 96, 60), 0.6);
            }
        }
    } else if (_t == "pirate" || _t == "desert") {
        // wind ripples: long shallow arcs, lit edge over dark edge
        repeat (90) {
            var _x = fwy_range(_g, -40, _W), _y = fwy_range(_g, 0, _H), _l = fwy_range(_g, 40, 110);
            for (var _k = 0; _k < 6; _k++) {
                var _x0 = _x + _l * _k / 6, _x1 = _x + _l * (_k + 1) / 6, _y0 = _y + sin(_k / 6 * pi) * 5, _y1 = _y + sin((_k + 1) / 6 * pi) * 5;
                fwy__line(_x0, _y0, _x1, _y1, 2, fwy__mul(_P.ground, 0.86), 0.55);
                fwy__line(_x0, _y0 - 2, _x1, _y1 - 2, 1.5, fwy__mul(_P.ground, 1.08), 0.6);
            }
        }
        if (_t == "pirate") repeat (40) { var _x = fwy_range(_g, 0, _W), _y = fwy_range(_g, 0, _H); fwy__ellipse(_x, _y, 3, 2, fwy__rgb(250, 240, 230), 0.9); fwy__ellipse(_x + 0.5, _y + 1, 2, 1, fwy__rgb(230, 170, 150), 0.8); }
    } else if (_t == "candy") {
        repeat (60) fwy__ellipse(fwy_range(_g, 0, _W), fwy_range(_g, 0, _H), fwy_range(_g, 30, 80), fwy_range(_g, 16, 40), fwy__mul(_P.ground, 1.05), 0.5);
        var _sc = [fwy__rgb(255, 240, 80), fwy__rgb(90, 200, 255), fwy__rgb(255, 255, 255), fwy__rgb(120, 230, 120), fwy__rgb(190, 110, 255), fwy__rgb(255, 120, 60)];
        repeat (520) { var _x = fwy_range(_g, 0, _W), _y = fwy_range(_g, 0, _H), _a = fwy_range(_g, 0, pi); fwy__bar(_x, _y, _x + cos(_a) * 6, _y + sin(_a) * 6, 2.4, _sc[floor(fwy_rand(_g) * 6)], 1); }
    } else if (_t == "space") {
        for (var _y = 0; _y < _H; _y += 64) for (var _x = 0; _x < _W; _x += 64) {
            var _c = fwy__mix(_P.ground, _P.ground2, fwy_rand(_g));
            fwy__rect(_x + 1, _y + 1, _x + 63, _y + 63, _c, 1);
            fwy__rect(_x + 1, _y + 1, _x + 63, _y + 3, fwy__mul(_c, 1.25), 0.8);
            fwy__rect(_x + 1, _y + 61, _x + 63, _y + 63, fwy__mul(_c, 0.7), 0.8);
            for (var _q = 0; _q < 4; _q++) fwy__disc(_x + 6 + (_q mod 2) * 52, _y + 6 + (_q div 2) * 52, 1.6, fwy__mul(_c, 1.4), 1);
        }
        // glowing seams
        for (var _x = 0; _x < _W; _x += 192) fwy__rect(_x - 1, 0, _x + 1, _H, _P.accent, 0.25);
    }
}

/// @function fwy__node_shade(hole, i, j)
/// @description Internal. Light on the felt at a height node: one lamp up and to the left, by the slope there.
function fwy__node_shade(_h, _i, _j) {
    var _w = _h.hgW, _hn = _h.hgH;
    var _a = _h.hg[_j * _w + clamp(_i + 1, 0, _w - 1)], _b = _h.hg[_j * _w + clamp(_i - 1, 0, _w - 1)];
    var _c = _h.hg[clamp(_j + 1, 0, _hn - 1) * _w + _i], _d = _h.hg[clamp(_j - 1, 0, _hn - 1) * _w + _i];
    var _gx = (_a - _b) / (2 * FWY_HG), _gy = (_c - _d) / (2 * FWY_HG);
    return clamp(1 + 2.6 * (0.6 * _gx + 0.8 * _gy), 0.62, 1.38);
}

/// @function fwy__paint_felt(hole, P, g)
/// @description Internal. The felt: every 16 px quad of every felt cell (the diagonal of a half cell runs corner to corner
/// through its quads, so it is exact), coloured by the slope's light at its four corners and by its mower stripe; then the
/// nap.
function fwy__paint_felt(_h, _P, _g) {
    // stripes run across the hole's longest straight
    var _runs = fwy__runs(_h.path), _horiz = true, _best = 0;
    for (var _r = 0; _r < array_length(_runs); _r++) if (_runs[_r].len > _best) { _best = _runs[_r].len; _horiz = (_runs[_r].dir == 1 || _runs[_r].dir == 3); }
    var _w = _h.hgW;
    var _sh = array_create(_w * _h.hgH, 1);
    for (var _j = 0; _j < _h.hgH; _j++) for (var _i = 0; _i < _w; _i++) _sh[_j * _w + _i] = fwy__node_shade(_h, _i, _j);
    for (var _cy = 0; _cy < FWY_GH; _cy++) for (var _cx = 0; _cx < FWY_GW; _cx++) {
        var _t = fwy__cell(_h, _cx, _cy);
        if (_t == 0) continue;
        for (var _q = 0; _q < 16; _q++) {
            var _si = _q mod 4, _sj = _q div 4;
            var _inside = 1; // 1 whole quad, 0 skip, 2..5 a half quad keeping the same half as the cell
            if (_t == 2) _inside = (_sj > _si) ? 1 : ((_sj == _si) ? 2 : 0);
            else if (_t == 3) _inside = (_si + _sj > 3) ? 1 : ((_si + _sj == 3) ? 3 : 0);
            else if (_t == 4) _inside = (_si + _sj < 3) ? 1 : ((_si + _sj == 3) ? 4 : 0);
            else if (_t == 5) _inside = (_sj < _si) ? 1 : ((_sj == _si) ? 5 : 0);
            if (_inside == 0) continue;
            var _i = (FWY_OX div FWY_HG) + _cx * 4 + _si, _j = (FWY_OY div FWY_HG) + _cy * 4 + _sj;
            var _x0 = _i * FWY_HG, _y0 = _j * FWY_HG, _x1 = _x0 + FWY_HG, _y1 = _y0 + FWY_HG;
            var _stripe = (((_horiz ? _j : _i) div 2) mod 2 == 0);
            var _base = _stripe ? _P.feltHi : _P.felt;
            var _c00 = fwy__mul(_base, _sh[_j * _w + _i]), _c10 = fwy__mul(_base, _sh[_j * _w + _i + 1]);
            var _c01 = fwy__mul(_base, _sh[(_j + 1) * _w + _i]), _c11 = fwy__mul(_base, _sh[(_j + 1) * _w + _i + 1]);
            draw_primitive_begin(pr_trianglelist);
            if (_inside == 1) {
                draw_vertex_colour(_x0, _y0, _c00, 1); draw_vertex_colour(_x1, _y0, _c10, 1); draw_vertex_colour(_x1, _y1, _c11, 1);
                draw_vertex_colour(_x0, _y0, _c00, 1); draw_vertex_colour(_x1, _y1, _c11, 1); draw_vertex_colour(_x0, _y1, _c01, 1);
            } else if (_inside == 2) { draw_vertex_colour(_x0, _y0, _c00, 1); draw_vertex_colour(_x1, _y1, _c11, 1); draw_vertex_colour(_x0, _y1, _c01, 1); }
            else if (_inside == 3) { draw_vertex_colour(_x1, _y0, _c10, 1); draw_vertex_colour(_x1, _y1, _c11, 1); draw_vertex_colour(_x0, _y1, _c01, 1); }
            else if (_inside == 4) { draw_vertex_colour(_x0, _y0, _c00, 1); draw_vertex_colour(_x1, _y0, _c10, 1); draw_vertex_colour(_x0, _y1, _c01, 1); }
            else { draw_vertex_colour(_x0, _y0, _c00, 1); draw_vertex_colour(_x1, _y0, _c10, 1); draw_vertex_colour(_x1, _y1, _c11, 1); }
            draw_primitive_end();
        }
    }
    // the nap: short dark and light flecks laid with the mower
    fwy__pts_begin();
    repeat (5200) {
        var _x = fwy_range(_g, 0, FWY_W), _y = fwy_range(_g, 0, FWY_H);
        if (!fwy_is_felt(_h, _x, _y)) continue;
        fwy__pt(_x, _y, (fwy_rand(_g) < 0.5) ? _P.feltLo : fwy__mul(_P.felt, 1.16), 0.55);
    }
    fwy__pts_end();
}

/// @function fwy__paint_relief_marks(hole, P)
/// @description Internal. The ramps' boards and arrows (the hills and hollows read from the shading alone).
function fwy__paint_relief_marks(_h, _P) {
    for (var _i = 0; _i < array_length(_h.obstacles); _i++) {
        var _o = _h.obstacles[_i];
        if (_o.kind != "leap") continue;
        var _wood = fwy__mix(_P.rail, _P.ground, 0.15);
        fwy__rect(_o.rx0, _o.ry0, _o.rx1, _o.ry1, fwy__mul(_wood, 0.9), 1);
        var _n = 6;
        for (var _k = 0; _k < _n; _k++) {
            var _f0 = _k / _n, _f1 = (_k + 1) / _n, _lit = 0.82 + 0.36 * ((_o.dx + _o.dy > 0) ? _f1 : 1 - _f0);
            if (_o.dx != 0) fwy__rect(lerp(_o.rx0, _o.rx1, _f0) + 1, _o.ry0 + 2, lerp(_o.rx0, _o.rx1, _f1) - 1, _o.ry1 - 2, fwy__mul(_wood, _lit), 1);
            else fwy__rect(_o.rx0 + 2, lerp(_o.ry0, _o.ry1, _f0) + 1, _o.rx1 - 2, lerp(_o.ry0, _o.ry1, _f1) - 1, fwy__mul(_wood, _lit), 1);
        }
        // chevrons pointing over the gap
        var _cx = (_o.rx0 + _o.rx1) / 2, _cy = (_o.ry0 + _o.ry1) / 2, _a = arctan2(_o.dy, _o.dx);
        for (var _k = -1; _k <= 1; _k++) {
            var _bx = _cx + cos(_a + pi / 2) * _k * 34, _by = _cy + sin(_a + pi / 2) * _k * 34;
            fwy__bar(_bx - cos(_a) * 6 + cos(_a + 2.3) * 9, _by - sin(_a) * 6 + sin(_a + 2.3) * 9, _bx + cos(_a) * 6, _by + sin(_a) * 6, 4, fwy__rgb(255, 255, 255), 0.85);
            fwy__bar(_bx - cos(_a) * 6 + cos(_a - 2.3) * 9, _by - sin(_a) * 6 + sin(_a - 2.3) * 9, _bx + cos(_a) * 6, _by + sin(_a) * 6, 4, fwy__rgb(255, 255, 255), 0.85);
        }
    }
}

/// @function fwy__paint_hazards(hole, P, g)
/// @description Internal. Water (the theme's pond, lagoon, bog, syrup, void or quicksand) and sand, each with a lip, depth and
/// surface marks.
function fwy__paint_hazards(_h, _P, _g) {
    for (var _i = 0; _i < array_length(_h.hazards); _i++) {
        var _z = _h.hazards[_i];
        var _cx = (_z.bx0 + _z.bx1) / 2, _cy = (_z.by0 + _z.by1) / 2;
        if (_z.kind == "sand") {
            fwy__poly_s(_z.xs, _z.ys, 1.08, 1, 2, fwy__mul(_P.felt, 0.7), 0.7);
            fwy__poly(_z.xs, _z.ys, _P.sandLo, 1);
            fwy__poly_s(_z.xs, _z.ys, 0.9, -1.5, -1.5, _P.sand, 1);
            fwy__pts_begin();
            repeat (floor((_z.bx1 - _z.bx0) * (_z.by1 - _z.by0) / 6)) {
                var _x = fwy_range(_g, _z.bx0, _z.bx1), _y = fwy_range(_g, _z.by0, _z.by1);
                if (fwy__in_poly(_z.xs, _z.ys, _x, _y)) fwy__pt(_x, _y, (fwy_rand(_g) < 0.5) ? _P.sandLo : fwy__mul(_P.sand, 1.08), 0.8);
            }
            fwy__pts_end();
            // rake lines
            for (var _k = -3; _k <= 3; _k++) {
                var _yy = _cy + _k * 6;
                for (var _x = _z.bx0; _x < _z.bx1; _x += 6) if (fwy__in_poly(_z.xs, _z.ys, _x, _yy) && fwy__in_poly(_z.xs, _z.ys, _x + 6, _yy)) fwy__line(_x, _yy, _x + 6, _yy, 1, _P.sandLo, 0.45);
            }
            if (_h.theme == "candy") repeat (30) { var _x = fwy_range(_g, _z.bx0, _z.bx1), _y = fwy_range(_g, _z.by0, _z.by1); if (fwy__in_poly(_z.xs, _z.ys, _x, _y)) { fwy__line(_x - 2, _y, _x + 2, _y, 1, c_white, 1); fwy__line(_x, _y - 2, _x, _y + 2, 1, c_white, 1); } }
            continue;
        }
        // water: lip, body darkening toward the middle, surface marks
        var _rect = (array_length(_z.xs) == 4);
        if (_rect) {
            fwy__rect(_z.bx0 - 3, _z.by0 - 3, _z.bx1 + 3, _z.by1 + 3, fwy__mul(_P.rail, 0.7), 1);
            fwy__rect(_z.bx0, _z.by0, _z.bx1, _z.by1, _P.waterLo, 1);
            fwy__rect(_z.bx0 + 4, _z.by0 + 4, _z.bx1 - 4, _z.by1 - 4, _P.water, 1);
        } else {
            fwy__poly_s(_z.xs, _z.ys, 1.12, 0, 0, fwy__mix(_P.felt, _P.ground, 0.5), 1);
            fwy__poly_s(_z.xs, _z.ys, 1.04, 0, 0, _P.waterLo, 1);
            fwy__poly_s(_z.xs, _z.ys, 0.8, 1, 1, _P.water, 1);
            fwy__poly_s(_z.xs, _z.ys, 0.45, 2, 2, fwy__mix(_P.water, _P.waterLo, 0.5), 0.8);
            // rim stones
            for (var _q = 0; _q < array_length(_z.xs); _q++) {
                var _sx = lerp(_cx, _z.xs[_q], 1.1), _sy = lerp(_cy, _z.ys[_q], 1.1);
                if (_h.theme == "garden" || _h.theme == "haunted" || _h.theme == "desert") { fwy__ellipse(_sx + 1, _sy + 1.5, 6, 4, _P.shadow, 0.4); fwy__ellipse(_sx, _sy, 6, 4, fwy__mul(_P.rail, 1.05), 1); fwy__ellipse(_sx - 1, _sy - 1, 3.5, 2, _P.railHi, 0.9); }
            }
        }
        var _bw = _z.bx1 - _z.bx0, _bh = _z.by1 - _z.by0;
        switch (_h.theme) {
            case "space":
                // the void: stars, and a cold glow at the edge
                repeat (floor(_bw * _bh / 90)) { var _x = fwy_range(_g, _z.bx0, _z.bx1), _y = fwy_range(_g, _z.by0, _z.by1); if (fwy__in_poly(_z.xs, _z.ys, _x, _y)) fwy__disc(_x, _y, fwy_range(_g, 0.6, 1.4), fwy__rgb(220, 230, 255), fwy_range(_g, 0.5, 1), 6); }
                if (_rect) { fwy__rect(_z.bx0, _z.by0, _z.bx1, _z.by0 + 3, _P.accent, 0.8); fwy__rect(_z.bx0, _z.by1 - 3, _z.bx1, _z.by1, _P.accent, 0.8); }
                break;
            case "haunted":
                repeat (floor(_bw * _bh / 500) + 3) { var _x = fwy_range(_g, _z.bx0, _z.bx1), _y = fwy_range(_g, _z.by0, _z.by1); if (fwy__in_poly(_z.xs, _z.ys, _x, _y)) { var _r = fwy_range(_g, 2, 5); fwy__ring(_x, _y, _r * 0.7, _r, _P.waterHi, 0.7); fwy__disc(_x - _r * 0.3, _y - _r * 0.3, _r * 0.25, c_white, 0.6); } }
                break;
            case "candy":
                repeat (6) { var _x = fwy_range(_g, _z.bx0, _z.bx1), _y = fwy_range(_g, _z.by0, _z.by1); if (fwy__in_poly(_z.xs, _z.ys, _x, _y)) fwy__ellipse(_x, _y, fwy_range(_g, 6, 14), 2, _P.waterHi, 0.6); }
                break;
            case "desert":
                // quicksand: a slow swirl
                for (var _k = 0; _k < 3; _k++) fwy__ring(_cx, _cy, min(_bw, _bh) * (0.12 + _k * 0.12), min(_bw, _bh) * (0.12 + _k * 0.12) + 1.5, _P.waterLo, 0.6);
                break;
            default:
                repeat (floor(_bw * _bh / 300) + 4) {
                    var _x = fwy_range(_g, _z.bx0, _z.bx1), _y = fwy_range(_g, _z.by0, _z.by1), _l = fwy_range(_g, 4, 12);
                    if (fwy__in_poly(_z.xs, _z.ys, _x, _y) && fwy__in_poly(_z.xs, _z.ys, _x + _l, _y)) fwy__line(_x, _y, _x + _l, _y, 1.5, _P.waterHi, 0.6);
                }
                if (_h.theme == "garden") repeat (3) {
                    var _x = fwy_range(_g, _z.bx0 + 8, _z.bx1 - 8), _y = fwy_range(_g, _z.by0 + 8, _z.by1 - 8);
                    if (fwy__in_poly(_z.xs, _z.ys, _x, _y)) { fwy__disc(_x, _y, 6, fwy__rgb(70, 150, 70), 1); fwy__tri(_x, _y, _x + 7, _y - 2, _x + 7, _y + 2, _P.water, 1); if (fwy_rand(_g) < 0.5) fwy__disc(_x - 1, _y - 1, 2.2, fwy__rgb(250, 190, 220), 1); }
                }
                if (_h.theme == "pirate") repeat (2) {
                    var _x = fwy_range(_g, _z.bx0 + 8, _z.bx1 - 8), _y = fwy_range(_g, _z.by0 + 8, _z.by1 - 8);
                    if (fwy__in_poly(_z.xs, _z.ys, _x, _y)) { fwy__tri(_x - 4, _y + 2, _x + 4, _y + 2, _x + 1, _y - 8, fwy__rgb(70, 90, 110), 1); fwy__line(_x - 8, _y + 3, _x + 8, _y + 3, 1.5, _P.waterHi, 0.8); }
                }
                break;
        }
    }
}

/// @function fwy__rail_offset(xs, ys, closed, w)
/// @description Internal. The outer edge of a rail loop, offset away from the felt by w with mitred corners. Returns [ox, oy].
function fwy__rail_offset(_xs, _ys, _closed, _w) {
    var _n = array_length(_xs), _ox = [], _oy = [];
    for (var _k = 0; _k < _n; _k++) {
        var _kp = _closed ? (_k + _n - 1) mod _n : max(0, _k - 1), _kn = _closed ? (_k + 1) mod _n : min(_n - 1, _k + 1);
        var _ax = 0, _ay = 0, _cnt = 0, _nx1 = 0, _ny1 = 0;
        if (_kp != _k) { var _dx = _xs[_k] - _xs[_kp], _dy = _ys[_k] - _ys[_kp], _l = max(0.001, fwy__hyp(_dx, _dy)); _nx1 = _dy / _l; _ny1 = -_dx / _l; _ax += _nx1; _ay += _ny1; _cnt++; }
        if (_kn != _k) { var _dx = _xs[_kn] - _xs[_k], _dy = _ys[_kn] - _ys[_k], _l = max(0.001, fwy__hyp(_dx, _dy)); var _nx2 = _dy / _l, _ny2 = -_dx / _l; _ax += _nx2; _ay += _ny2; _cnt++; if (_cnt == 1) { _nx1 = _nx2; _ny1 = _ny2; } }
        var _al = max(0.001, fwy__hyp(_ax, _ay)); _ax /= _al; _ay /= _al;
        var _m = _w / max(0.4, _ax * _nx1 + _ay * _ny1);
        array_push(_ox, _xs[_k] + _ax * _m); array_push(_oy, _ys[_k] + _ay * _m);
    }
    return [_ox, _oy];
}

/// @function fwy__paint_rails(hole, P)
/// @description Internal. The rails: a shadow on the felt, the top face in the theme's material with its joints and marks, a
/// lit or shaded inner lip by which way it faces the lamp, a dark outer edge, and every corner closed.
function fwy__paint_rails(_h, _P) {
    var _lx = -0.6, _ly = -0.8, _W = FWY_RAIL, _t = _h.theme;
    for (var _l = 0; _l < array_length(_h.loops); _l++) {
        var _L = _h.loops[_l], _xs = _L.xs, _ys = _L.ys, _n = array_length(_xs);
        if (_n < 2) continue;
        var _O = fwy__rail_offset(_xs, _ys, _L.closed, _W), _ox = _O[0], _oy = _O[1];
        var _last = _L.closed ? _n : _n - 1;
        // shadows first (on the felt side)
        for (var _k = 0; _k < _last; _k++) {
            var _j = (_k + 1) mod _n, _dx = _xs[_j] - _xs[_k], _dy = _ys[_j] - _ys[_k], _len = max(0.001, fwy__hyp(_dx, _dy));
            var _inx = -_dy / _len, _iny = _dx / _len;
            var _sd = (_inx * 0.6 + _iny * 0.8);
            if (_sd > 0.1) fwy__quad(_xs[_k], _ys[_k], _xs[_j], _ys[_j], _xs[_j] + _inx * 7 * _sd + 3, _ys[_j] + _iny * 7 * _sd + 3, _xs[_k] + _inx * 7 * _sd + 3, _ys[_k] + _iny * 7 * _sd + 3, _P.shadow, 0.32);
        }
        for (var _k = 0; _k < _last; _k++) {
            var _j = (_k + 1) mod _n;
            var _dx = _xs[_j] - _xs[_k], _dy = _ys[_j] - _ys[_k], _len = max(0.001, fwy__hyp(_dx, _dy)), _ux = _dx / _len, _uy = _dy / _len;
            var _inx = -_uy, _iny = _ux;
            var _face = -(_inx * _lx + _iny * _ly);
            var _top = (_t == "candy") ? _P.rail : fwy__mul(_P.rail, 1 + 0.08 * _face);
            fwy__quad(_xs[_k], _ys[_k], _xs[_j], _ys[_j], _ox[_j], _oy[_j], _ox[_k], _oy[_k], _top, 1);
            // material marks along the rail, between the inner edge (o = 0) and the outer (o = W)
            switch (_t) {
                case "garden": case "pirate": {
                    var _pl = (_t == "garden") ? 44 : 30;
                    for (var _s = _pl - (_k * 13 mod _pl); _s < _len - 2; _s += _pl) fwy__bar(_xs[_k] + _ux * _s, _ys[_k] + _uy * _s, _xs[_k] + _ux * _s - _inx * _W, _ys[_k] + _uy * _s - _iny * _W, 1.5, _P.railLo, 0.8);
                    fwy__bar(_xs[_k] - _inx * _W * 0.35, _ys[_k] - _iny * _W * 0.35, _xs[_j] - _inx * _W * 0.35, _ys[_j] - _iny * _W * 0.35, 1, _P.railLo, 0.35);
                    fwy__bar(_xs[_k] - _inx * _W * 0.7, _ys[_k] - _iny * _W * 0.7, _xs[_j] - _inx * _W * 0.7, _ys[_j] - _iny * _W * 0.7, 1, _P.railHi, 0.35);
                    if (_t == "pirate") {
                        // the rope along the top: short twists
                        for (var _s = 2; _s < _len - 2; _s += 5) {
                            var _cx = _xs[_k] + _ux * _s - _inx * _W * 0.5, _cy = _ys[_k] + _uy * _s - _iny * _W * 0.5;
                            fwy__bar(_cx - _ux * 2 - _inx * 2.5, _cy - _uy * 2 - _iny * 2.5, _cx + _ux * 2 + _inx * 2.5, _cy + _uy * 2 + _iny * 2.5, 2.4, fwy__rgb(214, 186, 120), 1);
                            fwy__bar(_cx - _ux * 1 - _inx * 1.5, _cy - _uy * 1 - _iny * 1.5, _cx + _ux * 1 + _inx * 1.5, _cy + _uy * 1 + _iny * 1.5, 1, fwy__rgb(150, 120, 70), 1);
                        }
                    } else for (var _s = 10; _s < _len - 4; _s += 44) { fwy__disc(_xs[_k] + _ux * _s - _inx * 3.5, _ys[_k] + _uy * _s - _iny * 3.5, 1.1, _P.railLo, 1, 6); fwy__disc(_xs[_k] + _ux * _s - _inx * 10.5, _ys[_k] + _uy * _s - _iny * 10.5, 1.1, _P.railLo, 1, 6); }
                    break;
                }
                case "candy": {
                    for (var _s = -_W; _s < _len + _W; _s += 12) {
                        var _a0 = clamp(_s, 0, _len), _a1 = clamp(_s + 6, 0, _len), _b0 = clamp(_s + _W * 0.7, 0, _len), _b1 = clamp(_s + 6 + _W * 0.7, 0, _len);
                        if (_a1 - _a0 < 0.5 && _b1 - _b0 < 0.5) continue;
                        fwy__quad(_xs[_k] + _ux * _a0, _ys[_k] + _uy * _a0, _xs[_k] + _ux * _a1, _ys[_k] + _uy * _a1,
                                  _xs[_k] + _ux * _b1 - _inx * _W, _ys[_k] + _uy * _b1 - _iny * _W, _xs[_k] + _ux * _b0 - _inx * _W, _ys[_k] + _uy * _b0 - _iny * _W, _P.accent, 1);
                    }
                    fwy__bar(_xs[_k] - _inx * _W * 0.3, _ys[_k] - _iny * _W * 0.3, _xs[_j] - _inx * _W * 0.3, _ys[_j] - _iny * _W * 0.3, 2, c_white, 0.45);
                    break;
                }
                case "space": {
                    fwy__bar(_xs[_k] - _inx * _W * 0.5, _ys[_k] - _iny * _W * 0.5, _xs[_j] - _inx * _W * 0.5, _ys[_j] - _iny * _W * 0.5, 3, _P.accent, 0.95);
                    fwy__bar(_xs[_k] - _inx * _W * 0.5, _ys[_k] - _iny * _W * 0.5, _xs[_j] - _inx * _W * 0.5, _ys[_j] - _iny * _W * 0.5, 7, _P.accent, 0.2);
                    for (var _s = 8; _s < _len - 4; _s += 24) { fwy__disc(_xs[_k] + _ux * _s - _inx * 2.5, _ys[_k] + _uy * _s - _iny * 2.5, 1.2, _P.railHi, 1, 6); fwy__disc(_xs[_k] + _ux * _s - _inx * 11.5, _ys[_k] + _uy * _s - _iny * 11.5, 1.2, _P.railLo, 1, 6); }
                    break;
                }
                default: {
                    // stone blocks (haunted iron and stone, desert sandstone)
                    var _bl = (_t == "desert") ? 26 : 22;
                    for (var _s = _bl - (_k * 7 mod _bl); _s < _len - 2; _s += _bl) fwy__bar(_xs[_k] + _ux * _s, _ys[_k] + _uy * _s, _xs[_k] + _ux * _s - _inx * _W, _ys[_k] + _uy * _s - _iny * _W, 1.6, _P.railLo, 0.7);
                    for (var _s = 6; _s < _len - 4; _s += 9) fwy__disc(_xs[_k] + _ux * _s - _inx * (3 + ((_s * 7) mod 9)), _ys[_k] + _uy * _s - _iny * (3 + ((_s * 7) mod 9)), 0.8, (_s mod 2 == 0) ? _P.railLo : _P.railHi, 0.6, 5);
                    if (_t == "haunted") for (var _s = 8; _s < _len - 4; _s += 16) { var _px = _xs[_k] + _ux * _s - _inx * (_W - 3), _py = _ys[_k] + _uy * _s - _iny * (_W - 3); fwy__disc(_px, _py, 2.2, fwy__rgb(28, 28, 34), 1, 8); fwy__disc(_px - 0.6, _py - 0.6, 0.9, fwy__rgb(120, 120, 130), 1, 6); }
                    break;
                }
            }
            // the inner lip: lit when it faces the lamp, shaded when it faces away; the outer edge dark
            var _lip = (_face > 0) ? fwy__mix(_P.railHi, c_white, 0.15) : fwy__mul(_P.railLo, 0.9);
            fwy__bar(_xs[_k] - _inx * 1.2, _ys[_k] - _iny * 1.2, _xs[_j] - _inx * 1.2, _ys[_j] - _iny * 1.2, 2.4, _lip, 1);
            fwy__quad(_ox[_k], _oy[_k], _ox[_j], _oy[_j], _ox[_j] + _inx * 2, _oy[_j] + _iny * 2, _ox[_k] + _inx * 2, _oy[_k] + _iny * 2, fwy__mul(_P.railLo, 0.8), 1);
        }
        // corners: a small cap on each vertex so no notch shows
        for (var _k = 0; _k < _n; _k++) {
            if (!_L.closed && (_k == 0 || _k == _n - 1)) { fwy__disc((_xs[_k] + _ox[_k]) / 2, (_ys[_k] + _oy[_k]) / 2, _W * 0.55, _P.rail, 1); continue; }
        }
    }
}

/// @function fwy__paint_tee(hole, P)
/// @description Internal. The tee: a rubber mat laid toward the first turn, its border and the tee spot.
function fwy__paint_tee(_h, _P) {
    var _a = -degtorad(_h.teeDir);
    fwy__orect(_h.teeX + 2, _h.teeY + 3, _a, 44, 34, _P.shadow, 0.35);
    fwy__orect(_h.teeX, _h.teeY, _a, 44, 34, fwy__mul(_P.mat, 0.8), 1);
    fwy__orect(_h.teeX, _h.teeY, _a, 40, 30, _P.mat, 1);
    for (var _k = -2; _k <= 2; _k++) {
        var _cx = _h.teeX + cos(_a + pi / 2) * _k * 6, _cy = _h.teeY + sin(_a + pi / 2) * _k * 6;
        fwy__orect(_cx, _cy, _a, 38, 1.2, fwy__mul(_P.mat, 1.25), 0.6);
    }
    fwy__disc(_h.teeX, _h.teeY, 4, fwy__mul(_P.mat, 0.6), 1);
    fwy__disc(_h.teeX - 0.8, _h.teeY - 0.8, 2.2, fwy__mul(_P.mat, 1.4), 1);
}

/// @function fwy__paint_cup(hole, P)
/// @description Internal. The cup: a collar of shorter felt, the hole with its shaded far wall and lit near lip.
function fwy__paint_cup(_h, _P) {
    var _x = _h.cupX, _y = _h.cupY;
    fwy__disc(_x, _y, FWY_CUP_R + 6, fwy__mul(_P.felt, 1.12), 0.7);
    fwy__disc(_x, _y, FWY_CUP_R + 1.5, fwy__rgb(230, 230, 224), 1);
    fwy__disc(_x, _y, FWY_CUP_R, _P.cup, 1);
    fwy__ellipse(_x, _y + 2.5, FWY_CUP_R - 2, FWY_CUP_R - 4, fwy__rgb(60, 60, 56), 1);
    fwy__ellipse(_x, _y + 4, FWY_CUP_R - 4, FWY_CUP_R - 6.5, _P.cup, 1);
}

/// @function fwy__paint_statics(hole, P, g)
/// @description Internal. The static obstacles: wedge blocks, bumpers, pipe mouths and the footings of the moving pieces.
function fwy__paint_statics(_h, _P, _g) {
    for (var _i = 0; _i < array_length(_h.obstacles); _i++) {
        var _o = _h.obstacles[_i];
        switch (_o.kind) {
            case "wedge": {
                fwy__poly_s(_o.xs, _o.ys, 1, 3, 4, _P.shadow, 0.4);
                fwy__poly(_o.xs, _o.ys, _P.railLo, 1);
                fwy__poly_s(_o.xs, _o.ys, 0.82, -1, -1.5, _P.rail, 1);
                fwy__poly_s(_o.xs, _o.ys, 0.45, -1.5, -2, fwy__mix(_P.rail, _P.railHi, 0.6), 1);
                if (_h.theme == "candy") fwy__poly_s(_o.xs, _o.ys, 0.45, -1.5, -2, _P.accent, 0.8);
                if (_h.theme == "space") fwy__poly_s(_o.xs, _o.ys, 0.3, -1.5, -2, _P.accent, 0.8);
                break;
            }
            case "bumper": fwy_piece_draw(_h.theme, "bumper", _o.x, _o.y, _o.r / 12, 0, _o.x * 3 + _o.y); break;
            case "pipe": fwy_piece_draw(_h.theme, "pipe", _o.ax, _o.ay, 1, 0, 0); break;
            case "pipeout": fwy_piece_draw(_h.theme, "pipeout", _o.x, _o.y, 1, _o.dir, 0); break;
            case "gate": fwy__disc(_o.hx + 2, _o.hy + 3, 9, _P.shadow, 0.4); break;
            case "spinner": fwy__disc(_o.x, _o.y, _o.len + 3, fwy__mul(_P.felt, 0.86), 0.35); fwy__ring(_o.x, _o.y, _o.len + 1, _o.len + 3, fwy__mul(_P.felt, 0.8), 0.6); break;
            case "mill": fwy__rect(_o.x0, _o.y0 + 4, _o.x1, _o.y1 + 6, _P.shadow, 0.35); break;
        }
    }
}

/// @function fwy__paint_decor(hole, P, shadows)
/// @description Internal. The scenery round the course (four pieces per theme), shadows first in a pass of their own.
function fwy__paint_decor(_h, _P, _shadows) {
    for (var _i = 0; _i < array_length(_h.decor); _i++) {
        var _d = _h.decor[_i];
        if (_shadows) fwy__ellipse(_d.x + 6 * _d.s, _d.y + 8 * _d.s, 16 * _d.s, 7 * _d.s, _P.shadow, 0.3);
        else fwy_piece_draw(_h.theme, "decor" + string(_d.kind), _d.x, _d.y, _d.s, 0, floor(_d.v * 1000));
    }
}

// ------------------------------------------------------------------------------------------------ the pieces

/// @function fwy_pieces()
/// @description The names of every piece fwy_piece_draw draws: the moving obstacles, the bumper, the pipe ends and the four
/// pieces of scenery. Every theme draws every piece its own way.
/// @returns {Array<String>}
function fwy_pieces() { return ["mill", "gate", "spinner", "bumper", "pipe", "pipeout", "decor0", "decor1", "decor2", "decor3"]; }

/// @function fwy_piece_draw(theme, piece, x, y, [scale], [angle], [variant], [t])
/// @description Draw one of a theme's pieces standing at (x, y), for a buyer's own levels, a menu or a catalogue: "mill" (the
/// windmill or the theme's building, sails turning with t), "gate", "spinner", "bumper", "pipe" (the intake), "pipeout"
/// (the outlet, pointing along angle), "decor0".."decor3" (scenery). Blends alpha as "over" and restores the caller's state.
/// @param {String} theme  one of fwy_themes()
/// @param {String} piece  one of fwy_pieces()
/// @returns {Bool} false for an unknown piece
function fwy_piece_draw(_theme, _piece, _x, _y, _s = 1, _ang = 0, _var = 0, _t = 0) {
    if (!fwy__theme_ok(_theme) || !is_string(_piece) || !is_numeric(_x) || !is_numeric(_y)) return false;
    if (!is_numeric(_s)) _s = 1;
    if (!is_numeric(_ang)) _ang = 0;
    if (!is_numeric(_var)) _var = 0;
    if (!is_numeric(_t)) _t = 0;
    var _P = fwy__pal(_theme), _ok = true;
    gpu_push_state(); fwy__over();
    switch (_piece) {
        case "mill": fwy__draw_mill(_theme, _P, _x - 64 * _s, _y - 22 * _s, _x + 64 * _s, _y + 22 * _s, _x - 20 * _s, _x + 20 * _s, _t * 0.3, 1, _s); break;
        case "gate": fwy__draw_gate(_theme, _P, _x - 50 * _s, _y, _ang, 100 * _s, _s); break;
        case "spinner": fwy__draw_spinner(_theme, _P, _x, _y, 44 * _s, 4, _ang + _t, _s); break;
        case "bumper": fwy__draw_bumper(_theme, _P, _x, _y, _s, _var); break;
        case "pipe": fwy__draw_pipe(_theme, _P, _x, _y, _s, false, _ang); break;
        case "pipeout": fwy__draw_pipe(_theme, _P, _x, _y, _s, true, _ang); break;
        case "decor0": case "decor1": case "decor2": case "decor3": fwy__draw_decor(_theme, _P, real(string_char_at(_piece, 6)), _x, _y, _s, _var); break;
        default: _ok = false;
    }
    gpu_pop_state();
    return _ok;
}

/// @function fwy__draw_bumper(theme, P, x, y, s, v)
/// @description Internal. The theme's bumper, about 24 px across at s = 1: flower pot, barrel, headstone, gumdrop, beacon, urn.
function fwy__draw_bumper(_t, _P, _x, _y, _s, _v) {
    var _r = 12 * _s;
    fwy__ellipse(_x + 3 * _s, _y + 4 * _s, _r * 1.05, _r * 0.8, _P.shadow, 0.4);
    switch (_t) {
        case "pirate":
            fwy__disc(_x, _y, _r, fwy__rgb(122, 76, 40), 1);
            for (var _k = 0; _k < 8; _k++) { var _a = _k * pi / 4; fwy__line(_x + cos(_a) * _r * 0.2, _y + sin(_a) * _r * 0.2, _x + cos(_a) * _r, _y + sin(_a) * _r, 1, fwy__rgb(84, 50, 24), 0.8); }
            fwy__ring(_x, _y, _r * 0.86, _r, fwy__rgb(70, 72, 78), 1); fwy__ring(_x, _y, _r * 0.48, _r * 0.58, fwy__rgb(70, 72, 78), 1);
            fwy__disc(_x - _r * 0.35, _y - _r * 0.35, _r * 0.22, fwy__rgb(170, 120, 74), 0.7);
            break;
        case "haunted":
            fwy__rect(_x - _r * 0.75, _y - _r * 0.5, _x + _r * 0.75, _y + _r * 0.9, fwy__rgb(120, 118, 128), 1);
            fwy__disc(_x, _y - _r * 0.5, _r * 0.75, fwy__rgb(120, 118, 128), 1);
            fwy__rect(_x - _r * 0.75, _y - _r * 0.5, _x - _r * 0.45, _y + _r * 0.9, fwy__rgb(150, 148, 160), 1);
            fwy__bar(_x, _y - _r * 0.75, _x, _y + _r * 0.25, 2 * _s, fwy__rgb(70, 68, 78), 1); fwy__bar(_x - _r * 0.3, _y - _r * 0.4, _x + _r * 0.3, _y - _r * 0.4, 2 * _s, fwy__rgb(70, 68, 78), 1);
            fwy__ellipse(_x + _r * 0.4, _y + _r * 0.8, _r * 0.3, _r * 0.15, fwy__rgb(80, 110, 70), 0.9);
            break;
        case "candy":
            var _cols = [fwy__rgb(240, 60, 90), fwy__rgb(90, 200, 90), fwy__rgb(255, 170, 40), fwy__rgb(140, 90, 230)];
            var _c = _cols[abs(floor(_v)) mod 4];
            fwy__disc(_x, _y, _r, fwy__mul(_c, 0.75), 1); fwy__disc(_x - 1, _y - 1.5, _r * 0.86, _c, 1); fwy__disc(_x - _r * 0.3, _y - _r * 0.35, _r * 0.4, fwy__mix(_c, c_white, 0.45), 1);
            for (var _k = 0; _k < 10; _k++) { var _a = _k * 2.4 + _v, _rr = _r * (0.3 + (_k mod 3) * 0.2); fwy__disc(_x + cos(_a) * _rr, _y + sin(_a) * _rr, 1.1 * _s, c_white, 0.9, 6); }
            break;
        case "space":
            fwy__disc(_x, _y, _r, fwy__rgb(80, 88, 104), 1); fwy__ring(_x, _y, _r * 0.8, _r, fwy__rgb(150, 160, 176), 1);
            fwy__glow(_x, _y, _r * 1.6, _P.accent, 0.5); fwy__disc(_x, _y, _r * 0.5, _P.accent, 1); fwy__disc(_x - 1, _y - 1, _r * 0.22, c_white, 1);
            break;
        case "desert":
            fwy__disc(_x, _y, _r, fwy__rgb(176, 96, 52), 1); fwy__disc(_x - 1, _y - 1, _r * 0.84, fwy__rgb(206, 120, 68), 1);
            fwy__ring(_x, _y, _r * 0.62, _r * 0.74, fwy__rgb(40, 30, 26), 1); fwy__disc(_x, _y, _r * 0.42, fwy__rgb(60, 36, 24), 1);
            for (var _k = 0; _k < 8; _k++) { var _a = _k * pi / 4; fwy__disc(_x + cos(_a) * _r * 0.68, _y + sin(_a) * _r * 0.68, 1.2 * _s, fwy__rgb(240, 210, 150), 1, 6); }
            break;
        default:
            fwy__disc(_x, _y, _r, fwy__rgb(176, 86, 52), 1); fwy__ring(_x, _y, _r * 0.78, _r, fwy__rgb(206, 108, 66), 1);
            fwy__disc(_x, _y, _r * 0.78, fwy__rgb(84, 56, 36), 1);
            var _fc = [fwy__rgb(240, 70, 100), fwy__rgb(255, 200, 60), fwy__rgb(250, 250, 250), fwy__rgb(180, 110, 240)];
            for (var _k = 0; _k < 5; _k++) { var _a = _k * 1.256 + _v, _fx = _x + cos(_a) * _r * 0.4, _fy = _y + sin(_a) * _r * 0.4; fwy__disc(_fx + 1, _fy + 1, 3.6 * _s, fwy__rgb(50, 120, 50), 1); fwy__disc(_fx, _fy, 3 * _s, _fc[(_k + abs(floor(_v))) mod 4], 1); fwy__disc(_fx, _fy, 1 * _s, fwy__rgb(255, 230, 120), 1, 6); }
            break;
    }
}

/// @function fwy__draw_pipe(theme, P, x, y, s, out, ang)
/// @description Internal. A pipe end: the intake a ball drops into, or the outlet it comes out of (with an arrow along ang).
function fwy__draw_pipe(_t, _P, _x, _y, _s, _out, _ang) {
    var _r = 15 * _s;
    fwy__disc(_x + 3, _y + 4, _r + 2, _P.shadow, 0.35);
    var _rim, _rim2, _in;
    switch (_t) {
        case "pirate": _rim = fwy__rgb(60, 62, 68); _rim2 = fwy__rgb(120, 124, 132); _in = fwy__rgb(16, 16, 18); break;
        case "haunted": _rim = fwy__rgb(80, 54, 40); _rim2 = fwy__rgb(130, 96, 70); _in = fwy__rgb(10, 6, 10); break;
        case "candy": _rim = fwy__rgb(240, 240, 246); _rim2 = fwy__rgb(226, 40, 60); _in = fwy__rgb(120, 40, 70); break;
        case "space": _rim = fwy__rgb(120, 130, 150); _rim2 = _P.accent; _in = fwy__rgb(20, 60, 90); break;
        case "desert": _rim = fwy__rgb(200, 160, 96); _rim2 = fwy__rgb(40, 110, 150); _in = fwy__rgb(40, 24, 14); break;
        default: _rim = fwy__rgb(110, 76, 44); _rim2 = fwy__rgb(160, 120, 76); _in = fwy__rgb(30, 20, 12); break;
    }
    fwy__disc(_x, _y, _r, _rim, 1);
    if (_t == "candy") for (var _k = 0; _k < 8; _k += 2) { draw_primitive_begin(pr_trianglefan); draw_vertex_colour(_x, _y, _rim2, 1); for (var _q = 0; _q <= 6; _q++) { var _a = (_k + _q / 6) * pi / 4; draw_vertex_colour(_x + cos(_a) * _r, _y + sin(_a) * _r, _rim2, 1); } draw_primitive_end(); }
    else fwy__ring(_x, _y, _r * 0.78, _r * 0.9, _rim2, 1);
    if (_t == "garden") for (var _k = 1; _k < 4; _k++) fwy__ring(_x, _y, _r * (0.2 + _k * 0.15), _r * (0.2 + _k * 0.15) + 0.8, _rim2, 0.6);
    fwy__disc(_x, _y, _r * 0.66, _in, 1);
    fwy__ellipse(_x, _y + _r * 0.18, _r * 0.5, _r * 0.4, fwy__mul(_in, 0.5), 1);
    if (_t == "space") { fwy__glow(_x, _y, _r * 1.4, _P.accent, _out ? 0.6 : 0.35); fwy__ring(_x, _y, _r * 0.5, _r * 0.58, _P.accent, 0.9); }
    if (_out) {
        var _ax = _x + cos(_ang) * (_r + 8), _ay = _y + sin(_ang) * (_r + 8);
        fwy__tri(_ax + cos(_ang) * 8, _ay + sin(_ang) * 8, _ax + cos(_ang + 2.4) * 7, _ay + sin(_ang + 2.4) * 7, _ax + cos(_ang - 2.4) * 7, _ay + sin(_ang - 2.4) * 7, fwy__rgb(255, 255, 255), 0.85);
    }
}

/// @function fwy__draw_decor(theme, P, k, x, y, s, v)
/// @description Internal. Scenery piece k (0..3) of a theme, about 40 px across at s = 1.
function fwy__draw_decor(_t, _P, _k, _x, _y, _s, _v) {
    var _r = 18 * _s;
    switch (_t + string(_k)) {
        // garden: rose bush, clipped hedge ball, tulip bed, birdbath
        case "garden0":
            fwy__disc(_x, _y, _r, fwy__rgb(40, 104, 46), 1);
            for (var _q = 0; _q < 7; _q++) { var _a = _q * 0.9 + _v, _rr = _r * (0.55 + (_q mod 2) * 0.2); fwy__disc(_x + cos(_a) * _rr * 0.6, _y + sin(_a) * _rr * 0.6, _r * 0.42, fwy__rgb(56, 130, 58), 1); }
            for (var _q = 0; _q < 6; _q++) { var _a = _q * 1.05 + _v * 2, _fx = _x + cos(_a) * _r * 0.55, _fy = _y + sin(_a) * _r * 0.55; fwy__disc(_fx, _fy, 3.6 * _s, fwy__rgb(196, 30, 60), 1); fwy__ring(_fx, _fy, 1 * _s, 2.4 * _s, fwy__rgb(240, 80, 110), 1); }
            break;
        case "garden1":
            fwy__disc(_x, _y, _r * 0.9, fwy__rgb(36, 92, 42), 1); fwy__disc(_x - _r * 0.12, _y - _r * 0.14, _r * 0.72, fwy__rgb(52, 120, 54), 1); fwy__disc(_x - _r * 0.3, _y - _r * 0.32, _r * 0.34, fwy__rgb(86, 160, 74), 1);
            break;
        case "garden2":
            fwy__ellipse(_x, _y, _r * 1.2, _r * 0.7, fwy__rgb(110, 76, 50), 1); fwy__ellipse(_x, _y - 1, _r * 1.1, _r * 0.6, fwy__rgb(132, 92, 60), 1);
            var _tc = [fwy__rgb(250, 60, 80), fwy__rgb(255, 210, 60), fwy__rgb(250, 140, 40), fwy__rgb(240, 240, 250)];
            for (var _q = 0; _q < 9; _q++) { var _fx = _x + ((_q mod 3) - 1) * _r * 0.6, _fy = _y + ((_q div 3) - 1) * _r * 0.36; fwy__line(_fx, _fy + 3, _fx, _fy, 1.4, fwy__rgb(50, 120, 50), 1); fwy__ellipse(_fx, _fy - 1, 2.8 * _s, 3.4 * _s, _tc[(_q + floor(_v * 4)) mod 4], 1); }
            break;
        case "garden3":
            fwy__disc(_x, _y, _r * 0.85, fwy__rgb(170, 170, 160), 1); fwy__ring(_x, _y, _r * 0.62, _r * 0.85, fwy__rgb(200, 200, 190), 1);
            fwy__disc(_x, _y, _r * 0.62, fwy__rgb(120, 180, 210), 1); fwy__ellipse(_x - _r * 0.2, _y - _r * 0.2, _r * 0.25, _r * 0.1, c_white, 0.7);
            fwy__ellipse(_x + _r * 0.4, _y - _r * 0.5, 4 * _s, 3 * _s, fwy__rgb(90, 70, 50), 1); fwy__disc(_x + _r * 0.55, _y - _r * 0.62, 2 * _s, fwy__rgb(90, 70, 50), 1);
            break;
        // pirate: palm, treasure chest, barrels, anchor
        case "pirate0": case "desert1":
            fwy__disc(_x, _y, 4 * _s, fwy__rgb(120, 86, 50), 1);
            for (var _q = 0; _q < 7; _q++) {
                var _a = _q * 0.9 + _v, _ex = _x + cos(_a) * _r * 1.2, _ey = _y + sin(_a) * _r * 1.2;
                fwy__bar(_x, _y, _ex, _ey, 7 * _s, fwy__rgb(40, 120, 50), 1);
                fwy__bar(_x, _y, _ex, _ey, 2 * _s, fwy__rgb(90, 170, 70), 1);
            }
            fwy__disc(_x, _y, 3 * _s, fwy__rgb(150, 110, 60), 1);
            break;
        case "pirate1":
            fwy__rect(_x - _r, _y - _r * 0.6, _x + _r, _y + _r * 0.6, fwy__rgb(120, 76, 36), 1);
            fwy__rect(_x - _r, _y - _r * 0.6, _x + _r, _y - _r * 0.1, fwy__rgb(150, 98, 50), 1);
            fwy__rect(_x - _r, _y - _r * 0.1, _x + _r, _y, fwy__rgb(220, 180, 60), 1);
            fwy__rect(_x - 3 * _s, _y - _r * 0.2, _x + 3 * _s, _y + _r * 0.25, fwy__rgb(230, 190, 70), 1);
            for (var _q = 0; _q < 6; _q++) fwy__disc(_x - _r * 0.7 + _q * _r * 0.28, _y - _r * 0.65, 3 * _s, fwy__rgb(250, 210, 70), 1);
            break;
        case "pirate2":
            for (var _q = 0; _q < 3; _q++) { var _bx = _x + ((_q == 0) ? -_r * 0.5 : ((_q == 1) ? _r * 0.5 : 0)), _by = _y + ((_q == 2) ? -_r * 0.5 : _r * 0.2); fwy__draw_bumper("pirate", _P, _bx, _by, _s * 0.8, 0); }
            break;
        case "pirate3":
            fwy__bar(_x, _y - _r, _x, _y + _r * 0.8, 4 * _s, fwy__rgb(60, 62, 70), 1);
            fwy__bar(_x - _r * 0.6, _y - _r * 0.6, _x + _r * 0.6, _y - _r * 0.6, 4 * _s, fwy__rgb(60, 62, 70), 1);
            fwy__ring(_x, _y - _r * 1.05, 2 * _s, 4.5 * _s, fwy__rgb(60, 62, 70), 1);
            for (var _q = 0; _q <= 8; _q++) { var _a = pi * 0.15 + _q / 8 * pi * 0.7; fwy__disc(_x + cos(_a) * _r * 0.8, _y + _r * 0.1 + sin(_a) * _r * 0.7, 2.4 * _s, fwy__rgb(60, 62, 70), 1); }
            break;
        // haunted: dead tree, pumpkin, crooked lamp, raven on a post
        case "haunted0":
            for (var _q = 0; _q < 6; _q++) { var _a = _q * 1.05 + _v, _ex = _x + cos(_a) * _r * 1.1, _ey = _y + sin(_a) * _r * 1.1; fwy__bar(_x, _y, _ex, _ey, 3.4 * _s, fwy__rgb(46, 40, 44), 1); fwy__bar(_ex, _ey, _ex + cos(_a + 0.7) * _r * 0.4, _ey + sin(_a + 0.7) * _r * 0.4, 2 * _s, fwy__rgb(46, 40, 44), 1); }
            fwy__disc(_x, _y, 5 * _s, fwy__rgb(56, 48, 52), 1);
            break;
        case "haunted1":
            fwy__glow(_x, _y, _r * 1.6, _P.glow, 0.35);
            for (var _q = -2; _q <= 2; _q++) fwy__ellipse(_x + _q * _r * 0.26, _y, _r * 0.36, _r * 0.7, fwy__rgb(230, 120, 30), 1);
            fwy__ellipse(_x, _y, _r * 0.2, _r * 0.6, fwy__rgb(250, 150, 50), 1);
            fwy__tri(_x - _r * 0.45, _y - _r * 0.1, _x - _r * 0.2, _y - _r * 0.1, _x - _r * 0.32, _y - _r * 0.35, fwy__rgb(255, 230, 120), 1);
            fwy__tri(_x + _r * 0.45, _y - _r * 0.1, _x + _r * 0.2, _y - _r * 0.1, _x + _r * 0.32, _y - _r * 0.35, fwy__rgb(255, 230, 120), 1);
            fwy__rect(_x - _r * 0.4, _y + _r * 0.2, _x + _r * 0.4, _y + _r * 0.32, fwy__rgb(255, 230, 120), 1);
            fwy__bar(_x, _y - _r * 0.6, _x + 2 * _s, _y - _r * 0.9, 3 * _s, fwy__rgb(70, 90, 40), 1);
            break;
        case "haunted2":
            fwy__glow(_x, _y - _r, _r * 2, _P.glow, 0.4);
            fwy__bar(_x, _y + _r * 0.6, _x + 2 * _s, _y - _r * 0.8, 3 * _s, fwy__rgb(30, 30, 36), 1);
            fwy__rect(_x - 5 * _s, _y - _r * 1.2, _x + 7 * _s, _y - _r * 0.7, fwy__rgb(30, 30, 36), 1);
            fwy__rect(_x - 3 * _s, _y - _r * 1.12, _x + 5 * _s, _y - _r * 0.78, _P.glow, 1);
            fwy__ellipse(_x, _y + _r * 0.6, 7 * _s, 3 * _s, fwy__rgb(30, 30, 36), 1);
            break;
        case "haunted3":
            fwy__rect(_x - 3 * _s, _y - _r * 0.6, _x + 3 * _s, _y + _r * 0.7, fwy__rgb(70, 54, 44), 1);
            fwy__ellipse(_x, _y - _r * 0.75, 7 * _s, 5 * _s, fwy__rgb(20, 20, 26), 1);
            fwy__disc(_x + 5 * _s, _y - _r * 0.95, 3.4 * _s, fwy__rgb(20, 20, 26), 1);
            fwy__tri(_x + 7.5 * _s, _y - _r * 0.98, _x + 11 * _s, _y - _r * 0.92, _x + 7.5 * _s, _y - _r * 0.86, fwy__rgb(230, 180, 60), 1);
            fwy__tri(_x - 6 * _s, _y - _r * 0.75, _x - 13 * _s, _y - _r * 0.9, _x - 5 * _s, _y - _r * 0.6, fwy__rgb(20, 20, 26), 1);
            fwy__disc(_x + 5.5 * _s, _y - _r * 1.0, 0.9 * _s, fwy__rgb(255, 80, 60), 1, 6);
            break;
        // candy: lollipop, cupcake, gumdrop heap, peppermint
        case "candy0":
            fwy__bar(_x, _y, _x + 2 * _s, _y + _r * 1.1, 3 * _s, fwy__rgb(250, 250, 250), 1);
            fwy__disc(_x, _y, _r * 0.8, fwy__rgb(250, 90, 150), 1);
            for (var _q = 0; _q < 30; _q++) { var _a = _q * 0.55, _rr = _q / 30 * _r * 0.78; fwy__disc(_x + cos(_a) * _rr, _y + sin(_a) * _rr, 2.4 * _s, fwy__rgb(255, 255, 255), 1, 8); }
            fwy__disc(_x - _r * 0.3, _y - _r * 0.3, _r * 0.18, c_white, 0.6);
            break;
        case "candy1":
            fwy__rect(_x - _r * 0.7, _y, _x + _r * 0.7, _y + _r * 0.8, fwy__rgb(230, 160, 70), 1);
            for (var _q = -3; _q <= 3; _q++) fwy__line(_x + _q * _r * 0.2, _y + 1, _x + _q * _r * 0.2, _y + _r * 0.8, 1, fwy__rgb(190, 120, 40), 1);
            fwy__disc(_x, _y - _r * 0.1, _r * 0.8, fwy__rgb(255, 230, 240), 1); fwy__disc(_x - _r * 0.15, _y - _r * 0.3, _r * 0.55, fwy__rgb(255, 245, 250), 1);
            fwy__disc(_x, _y - _r * 0.7, 4 * _s, fwy__rgb(220, 30, 50), 1); fwy__disc(_x - 1, _y - _r * 0.75, 1.4 * _s, c_white, 0.8, 6);
            break;
        case "candy2":
            for (var _q = 0; _q < 5; _q++) { var _a = _q * 1.256 + _v; fwy__draw_bumper("candy", _P, _x + cos(_a) * _r * 0.55, _y + sin(_a) * _r * 0.45, _s * 0.6, _q); }
            break;
        case "candy3":
            fwy__disc(_x, _y, _r * 0.85, c_white, 1);
            for (var _k2 = 0; _k2 < 8; _k2 += 2) { draw_primitive_begin(pr_trianglefan); draw_vertex_colour(_x, _y, fwy__rgb(226, 40, 60), 1); for (var _q = 0; _q <= 6; _q++) { var _a = (_k2 + _q / 6) * pi / 4 + _v; draw_vertex_colour(_x + cos(_a) * _r * 0.85, _y + sin(_a) * _r * 0.85, fwy__rgb(226, 40, 60), 1); } draw_primitive_end(); }
            fwy__ring(_x, _y, _r * 0.85, _r * 0.95, fwy__rgb(230, 220, 226), 1);
            break;
        // space: antenna dish, cargo crates, light pylon, planet globe
        case "space0":
            // a dish on a mast: the base, the mast, the bowl tilted to the sky, the feed on its tripod
            fwy__ellipse(_x, _y + _r * 0.6, _r * 0.5, _r * 0.18, _P.shadow, 0.35);
            fwy__rect(_x - _r * 0.3, _y + _r * 0.35, _x + _r * 0.3, _y + _r * 0.6, fwy__rgb(80, 86, 100), 1);
            fwy__bar(_x, _y + _r * 0.4, _x, _y - _r * 0.1, 3 * _s, fwy__rgb(110, 118, 132), 1);
            fwy__ellipse(_x, _y - _r * 0.35, _r * 0.95, _r * 0.5, fwy__rgb(150, 158, 172), 1);
            fwy__ellipse(_x, _y - _r * 0.42, _r * 0.8, _r * 0.38, fwy__rgb(214, 220, 230), 1);
            fwy__ellipse(_x - _r * 0.2, _y - _r * 0.5, _r * 0.3, _r * 0.12, c_white, 0.7);
            fwy__bar(_x - _r * 0.55, _y - _r * 0.35, _x, _y - _r * 1.05, 1.2 * _s, fwy__rgb(80, 86, 100), 1); fwy__bar(_x + _r * 0.55, _y - _r * 0.35, _x, _y - _r * 1.05, 1.2 * _s, fwy__rgb(80, 86, 100), 1);
            fwy__disc(_x, _y - _r * 1.05, 2.6 * _s, _P.accent, 1); fwy__glow(_x, _y - _r * 1.05, 8 * _s, _P.accent, 0.5);
            break;
        case "space1":
            for (var _q = 0; _q < 3; _q++) { var _bx = _x + ((_q mod 2) * 2 - 1) * _r * 0.45, _by = _y + ((_q == 2) ? -_r * 0.5 : _r * 0.2), _c = (_q == 1) ? fwy__rgb(220, 160, 40) : fwy__rgb(110, 120, 136);
                fwy__rect(_bx - _r * 0.42, _by - _r * 0.42, _bx + _r * 0.42, _by + _r * 0.42, fwy__mul(_c, 0.75), 1); fwy__rect(_bx - _r * 0.36, _by - _r * 0.36, _bx + _r * 0.36, _by + _r * 0.36, _c, 1);
                fwy__bar(_bx - _r * 0.36, _by - _r * 0.36, _bx + _r * 0.36, _by + _r * 0.36, 1.4, fwy__mul(_c, 0.7), 1); fwy__bar(_bx + _r * 0.36, _by - _r * 0.36, _bx - _r * 0.36, _by + _r * 0.36, 1.4, fwy__mul(_c, 0.7), 1); }
            break;
        case "space2":
            fwy__glow(_x, _y, _r * 1.8, _P.accent, 0.45); fwy__disc(_x, _y, _r * 0.4, fwy__rgb(60, 66, 80), 1); fwy__disc(_x, _y, _r * 0.24, _P.accent, 1); fwy__disc(_x, _y, _r * 0.1, c_white, 1);
            break;
        case "space3":
            fwy__disc(_x, _y, _r * 0.85, fwy__rgb(200, 110, 70), 1); fwy__ellipse(_x, _y - _r * 0.2, _r * 0.8, _r * 0.15, fwy__rgb(230, 160, 110), 1); fwy__ellipse(_x, _y + _r * 0.3, _r * 0.7, _r * 0.12, fwy__rgb(170, 80, 50), 1);
            fwy__disc(_x - _r * 0.3, _y - _r * 0.3, _r * 0.25, fwy__rgb(255, 210, 170), 0.5);
            fwy__ring(_x, _y, _r * 1.05, _r * 1.15, fwy__rgb(230, 220, 200), 0.7);
            break;
        // desert: saguaro cactus, palm (shared drawing, case above), broken column, amphora
        case "desert0": {
            // a saguaro standing on its foot: trunk, two arms bent upward, ribs, a flower on top
            var _cg = fwy__rgb(66, 140, 74), _cl = fwy__rgb(104, 180, 104), _cd = fwy__rgb(40, 100, 52), _tw = _r * 0.26;
            fwy__ellipse(_x, _y + _r * 0.55, _r * 0.4, _r * 0.14, _P.shadow, 0.3);
            fwy__rect(_x - _tw, _y - _r * 0.9, _x + _tw, _y + _r * 0.55, _cg, 1); fwy__disc(_x, _y - _r * 0.9, _tw, _cg, 1);
            fwy__rect(_x - _r * 0.75, _y - _r * 0.05, _x - _tw + 1, _y + _r * 0.17, _cg, 1); fwy__rect(_x - _r * 0.75, _y - _r * 0.6, _x - _r * 0.5, _y + _r * 0.17, _cg, 1); fwy__disc(_x - _r * 0.625, _y - _r * 0.6, _r * 0.125, _cg, 1);
            fwy__rect(_x + _tw - 1, _y - _r * 0.3, _x + _r * 0.7, _y - _r * 0.1, _cg, 1); fwy__rect(_x + _r * 0.46, _y - _r * 0.78, _x + _r * 0.7, _y - _r * 0.1, _cg, 1); fwy__disc(_x + _r * 0.58, _y - _r * 0.78, _r * 0.12, _cg, 1);
            fwy__rect(_x - _tw * 0.55, _y - _r * 0.9, _x - _tw * 0.15, _y + _r * 0.5, _cl, 0.8); fwy__rect(_x + _tw * 0.4, _y - _r * 0.85, _x + _tw * 0.75, _y + _r * 0.5, _cd, 0.7);
            fwy__disc(_x, _y - _r * 1.12, 2.4 * _s, fwy__rgb(250, 120, 160), 1, 8);
            break;
        }
        case "desert2":
            fwy__disc(_x, _y, _r * 0.7, fwy__rgb(226, 196, 140), 1);
            for (var _q = 0; _q < 12; _q++) { var _a = _q * pi / 6; fwy__disc(_x + cos(_a) * _r * 0.62, _y + sin(_a) * _r * 0.62, 2.4 * _s, fwy__rgb(196, 166, 110), 1); }
            fwy__disc(_x - 2, _y - 2, _r * 0.45, fwy__rgb(240, 214, 160), 1);
            fwy__orect(_x + _r * 0.9, _y + _r * 0.4, 0.4, _r * 0.9, _r * 0.5, fwy__rgb(214, 182, 124), 1);
            break;
        case "desert3":
            fwy__ellipse(_x, _y, _r * 0.55, _r * 0.8, fwy__rgb(176, 96, 52), 1); fwy__ellipse(_x - 2, _y - 2, _r * 0.42, _r * 0.62, fwy__rgb(206, 120, 68), 1);
            fwy__rect(_x - _r * 0.2, _y - _r * 1.05, _x + _r * 0.2, _y - _r * 0.7, fwy__rgb(176, 96, 52), 1);
            fwy__rect(_x - _r * 0.5, _y - _r * 0.1, _x + _r * 0.5, _y + _r * 0.02, fwy__rgb(30, 24, 20), 1);
            break;
        default: fwy__disc(_x, _y, _r * 0.5, _P.rail, 1);
    }
}

// ------------------------------------------------------------------------------------------------ the moving pieces

/// @function fwy__draw_mill(theme, P, x0, y0, x1, y1, gx0, gx1, t, alpha, s)
/// @description Internal. The theme's building standing on the footprint (x0..x1, y0..y1) with its tunnel between gx0 and gx1
/// and its four arms turning on the south face (t in sail turns: fwy__mill_sail's angle / 2pi): windmill, lighthouse with a
/// ship's wheel, manor with tattered sails, gingerbread mill with candy-cane sails, reactor with solar arms, water-wheel tower.
function fwy__draw_mill(_t, _P, _x0, _y0, _x1, _y1, _gx0, _gx1, _turn, _al, _s) {
    var _cx = (_x0 + _x1) / 2, _w = (_x1 - _x0) * 0.62, _hgt = 74 * _s;
    var _wall, _wallLo, _roof, _roofLo, _arm, _armLo;
    switch (_t) {
        case "pirate": _wall = fwy__rgb(240, 236, 228); _wallLo = fwy__rgb(196, 190, 182); _roof = fwy__rgb(196, 40, 40); _roofLo = fwy__rgb(140, 26, 26); _arm = fwy__rgb(140, 90, 50); _armLo = fwy__rgb(96, 60, 30); break;
        case "haunted": _wall = fwy__rgb(96, 92, 108); _wallLo = fwy__rgb(66, 62, 76); _roof = fwy__rgb(46, 40, 56); _roofLo = fwy__rgb(30, 26, 38); _arm = fwy__rgb(40, 36, 44); _armLo = fwy__rgb(24, 22, 28); break;
        case "candy": _wall = fwy__rgb(196, 124, 64); _wallLo = fwy__rgb(156, 92, 44); _roof = fwy__rgb(255, 250, 250); _roofLo = fwy__rgb(230, 210, 220); _arm = fwy__rgb(250, 250, 250); _armLo = fwy__rgb(226, 40, 60); break;
        case "space": _wall = fwy__rgb(190, 198, 210); _wallLo = fwy__rgb(130, 140, 156); _roof = fwy__rgb(150, 160, 176); _roofLo = fwy__rgb(100, 110, 126); _arm = fwy__rgb(40, 80, 160); _armLo = fwy__rgb(120, 200, 255); break;
        case "desert": _wall = fwy__rgb(222, 184, 124); _wallLo = fwy__rgb(176, 138, 84); _roof = fwy__rgb(196, 156, 98); _roofLo = fwy__rgb(150, 112, 66); _arm = fwy__rgb(130, 86, 46); _armLo = fwy__rgb(90, 58, 30); break;
        default: _wall = fwy__rgb(236, 230, 214); _wallLo = fwy__rgb(196, 186, 166); _roof = fwy__rgb(120, 62, 46); _roofLo = fwy__rgb(84, 40, 30); _arm = fwy__rgb(160, 110, 66); _armLo = fwy__rgb(240, 236, 220); break;
    }
    // the plinth across the whole footprint (the collision blocks are exactly this wide)
    var _ph = 9 * _s;
    fwy__rect(_x0, _y0 - _ph, _x1, _y1 - _ph, fwy__mul(_wall, 1.06), _al);
    fwy__rect(_x0, _y1 - _ph, _x1, _y1, _wallLo, _al);
    fwy__rect(_x0, _y0 - _ph, _x1, _y0 - _ph + 2, fwy__mul(_wall, 1.2), _al);
    fwy__rect(_x0, _y1 - 2, _x1, _y1, fwy__mul(_wallLo, 0.75), _al);
    for (var _k = 1; _k < 8; _k++) fwy__line(lerp(_x0, _x1, _k / 8), _y1 - _ph, lerp(_x0, _x1, _k / 8), _y1, 1, fwy__mul(_wallLo, 0.8), 0.6 * _al);
    var _yb = _y1 - _ph, _yt = _yb - _hgt;
    // body: a tapered tower (or a house for the manor and the gingerbread mill)
    var _tw = (_t == "haunted" || _t == "candy") ? _w * 0.5 : _w * 0.36;
    fwy__quad(_cx - _w * 0.5, _yb, _cx + _w * 0.5, _yb, _cx + _tw, _yt, _cx - _tw, _yt, _wall, _al);
    fwy__quad(_cx + _w * 0.18, _yb, _cx + _w * 0.5, _yb, _cx + _tw, _yt, _cx + _tw * 0.45, _yt, _wallLo, _al);
    if (_t == "pirate") for (var _k = 0; _k < 3; _k++) { var _f0 = 0.2 + _k * 0.28, _f1 = _f0 + 0.13; fwy__quad(_cx - lerp(_w * 0.5, _tw, _f0), _yb - _hgt * _f0, _cx + lerp(_w * 0.5, _tw, _f0), _yb - _hgt * _f0, _cx + lerp(_w * 0.5, _tw, _f1), _yb - _hgt * _f1, _cx - lerp(_w * 0.5, _tw, _f1), _yb - _hgt * _f1, _roof, _al); }
    if (_t == "desert" || _t == "garden") for (var _k = 1; _k < 6; _k++) { var _yy = _yb - _hgt * _k / 6, _hw = lerp(_w * 0.5, _tw, _k / 6); fwy__line(_cx - _hw, _yy, _cx + _hw, _yy, 1, _wallLo, 0.5 * _al); }
    if (_t == "candy") { for (var _k = 0; _k < 7; _k++) fwy__disc(_cx - _tw + 6 + _k * (_tw * 2 - 12) / 6, _yt + 6, 4 * _s, fwy__rgb(255, 250, 250), _al); fwy__disc(_cx - _w * 0.25, _yb - _hgt * 0.45, 4 * _s, fwy__rgb(80, 200, 120), _al); fwy__disc(_cx + _w * 0.25, _yb - _hgt * 0.55, 4 * _s, fwy__rgb(250, 80, 120), _al); }
    if (_t == "space") { fwy__rect(_cx - _tw, _yb - _hgt * 0.62, _cx + _tw, _yb - _hgt * 0.56, _P.accent, _al); }
    // windows (lit after dark)
    var _wc = _P.dark ? _P.glow : fwy__rgb(60, 70, 90);
    fwy__rect(_cx - 5 * _s, _yb - _hgt * 0.66, _cx + 5 * _s, _yb - _hgt * 0.5, _wc, _al);
    if (_t == "haunted") { fwy__rect(_cx - _tw + 6, _yb - _hgt * 0.4, _cx - _tw + 14, _yb - _hgt * 0.28, _wc, _al); fwy__rect(_cx + _tw - 14, _yb - _hgt * 0.4, _cx + _tw - 6, _yb - _hgt * 0.28, _wc, _al); }
    // roof
    switch (_t) {
        case "pirate":
            fwy__rect(_cx - _tw - 3, _yt - 18 * _s, _cx + _tw + 3, _yt, fwy__rgb(40, 40, 46), _al);
            fwy__rect(_cx - _tw + 2, _yt - 15 * _s, _cx + _tw - 2, _yt - 3, fwy__rgb(255, 230, 120), _al);
            fwy__glow(_cx, _yt - 9 * _s, 36 * _s, fwy__rgb(255, 240, 160), 0.45 * _al);
            fwy__tri(_cx - _tw - 5, _yt - 18 * _s, _cx + _tw + 5, _yt - 18 * _s, _cx, _yt - 34 * _s, _roof, _al);
            break;
        case "haunted":
            fwy__tri(_cx - _tw - 8, _yt, _cx + _tw + 8, _yt, _cx, _yt - 40 * _s, _roof, _al);
            fwy__tri(_cx, _yt, _cx + _tw + 8, _yt, _cx, _yt - 40 * _s, _roofLo, _al);
            fwy__bar(_cx, _yt - 40 * _s, _cx, _yt - 52 * _s, 2 * _s, _roofLo, _al);
            break;
        case "candy":
            fwy__tri(_cx - _tw - 8, _yt + 2, _cx + _tw + 8, _yt + 2, _cx, _yt - 32 * _s, fwy__rgb(150, 86, 40), _al);
            for (var _k = 0; _k < 6; _k++) { var _f = (_k + 0.5) / 6; fwy__disc(lerp(_cx - _tw - 8, _cx, _f), lerp(_yt + 2, _yt - 32 * _s, _f), 3.4 * _s, _roof, _al); fwy__disc(lerp(_cx + _tw + 8, _cx, _f), lerp(_yt + 2, _yt - 32 * _s, _f), 3.4 * _s, _roof, _al); }
            break;
        case "space":
            draw_primitive_begin(pr_trianglefan); draw_vertex_colour(_cx, _yt, _roof, _al);
            for (var _k = 0; _k <= 16; _k++) { var _a = pi + _k / 16 * pi; draw_vertex_colour(_cx + cos(_a) * (_tw + 4), _yt + sin(_a) * 24 * _s, (_k > 8) ? _roofLo : _roof, _al); }
            draw_primitive_end();
            fwy__disc(_cx, _yt - 26 * _s, 3 * _s, fwy__rgb(255, 80, 80), _al);
            break;
        default:
            fwy__tri(_cx - _tw - 7, _yt + 1, _cx + _tw + 7, _yt + 1, _cx, _yt - 28 * _s, _roof, _al);
            fwy__tri(_cx, _yt + 1, _cx + _tw + 7, _yt + 1, _cx, _yt - 28 * _s, _roofLo, _al);
            break;
    }
    // the tunnel mouth at the foot
    var _gw = (_gx1 - _gx0);
    fwy__rect(_gx0, _y1 - 20 * _s, _gx1, _y1, fwy__rgb(16, 14, 12), _al);
    fwy__disc((_gx0 + _gx1) / 2, _y1 - 20 * _s, _gw / 2, fwy__rgb(16, 14, 12), _al);
    fwy__ring((_gx0 + _gx1) / 2, _y1 - 20 * _s, _gw / 2, _gw / 2 + 3, _wallLo, _al);
    // the four arms on the south face
    var _hx = _cx, _hy = _yb - _hgt * 0.72, _L = 62 * _s, _a0 = _turn * 2 * pi;
    for (var _k = 0; _k < 4; _k++) {
        var _a = _a0 + _k * pi / 2, _ca = cos(_a), _sa = sin(_a);
        var _ex = _hx + _ca * _L, _ey = _hy + _sa * _L;
        switch (_t) {
            case "pirate":
                fwy__bar(_hx, _hy, _ex, _ey, 4 * _s, _arm, _al); fwy__disc(_ex, _ey, 4 * _s, _armLo, _al);
                break;
            case "space":
                fwy__bar(_hx, _hy, _hx + _ca * 12 * _s, _hy + _sa * 12 * _s, 3 * _s, _wallLo, _al);
                fwy__quad(_hx + _ca * 12 * _s - _sa * 9 * _s, _hy + _sa * 12 * _s + _ca * 9 * _s, _ex - _sa * 9 * _s, _ey + _ca * 9 * _s, _ex + _sa * 9 * _s, _ey - _ca * 9 * _s, _hx + _ca * 12 * _s + _sa * 9 * _s, _hy + _sa * 12 * _s - _ca * 9 * _s, _arm, _al);
                for (var _q = 1; _q < 5; _q++) { var _px = lerp(_hx + _ca * 12 * _s, _ex, _q / 5), _py = lerp(_hy + _sa * 12 * _s, _ey, _q / 5); fwy__line(_px - _sa * 9 * _s, _py + _ca * 9 * _s, _px + _sa * 9 * _s, _py - _ca * 9 * _s, 1, _armLo, _al * 0.8); }
                break;
            case "desert":
                fwy__bar(_hx, _hy, _ex, _ey, 3 * _s, _arm, _al);
                fwy__orect(_ex - _ca * 8 * _s, _ey - _sa * 8 * _s, _a + pi / 2, 18 * _s, 10 * _s, _armLo, _al);
                break;
            default:
                // lattice sail: a spar and a canvas frame beside it
                fwy__bar(_hx, _hy, _ex, _ey, 3 * _s, _arm, _al);
                var _f0 = 0.25, _sw2 = (_t == "haunted") ? 10 * _s : 12 * _s;
                var _px0 = _hx + _ca * _L * _f0, _py0 = _hy + _sa * _L * _f0;
                var _cnv = (_t == "candy") ? fwy__rgb(250, 250, 250) : ((_t == "haunted") ? fwy__rgb(30, 28, 34) : _armLo);
                fwy__quad(_px0, _py0, _ex, _ey, _ex - _sa * _sw2, _ey + _ca * _sw2, _px0 - _sa * _sw2, _py0 + _ca * _sw2, _cnv, _al * ((_t == "haunted") ? 0.85 : 0.95));
                if (_t == "candy") for (var _q = 0; _q < 5; _q++) { var _f = 0.3 + _q * 0.14; var _qx = _hx + _ca * _L * _f, _qy = _hy + _sa * _L * _f; fwy__quad(_qx, _qy, _qx + _ca * 4, _qy + _sa * 4, _qx + _ca * 4 - _sa * _sw2, _qy + _sa * 4 + _ca * _sw2, _qx - _sa * _sw2, _qy + _ca * _sw2, fwy__rgb(226, 40, 60), _al); }
                else for (var _q = 1; _q < 4; _q++) { var _f = _f0 + (1 - _f0) * _q / 4, _qx = _hx + _ca * _L * _f, _qy = _hy + _sa * _L * _f; fwy__line(_qx, _qy, _qx - _sa * _sw2, _qy + _ca * _sw2, 1, _arm, _al); }
                break;
        }
    }
    fwy__disc(_hx, _hy, 6 * _s, _armLo, _al); fwy__disc(_hx - 1, _hy - 1, 3 * _s, _arm, _al);
}

/// @function fwy__draw_gate(theme, P, hx, hy, ang, len, s)
/// @description Internal. A gate bar hinged at (hx, hy) pointing along ang, in the theme's material, with its post.
function fwy__draw_gate(_t, _P, _hx, _hy, _ang, _len, _s) {
    var _ex = _hx + cos(_ang) * _len, _ey = _hy + sin(_ang) * _len;
    fwy__bar(_hx + 3, _hy + 4, _ex + 3, _ey + 4, 10 * _s, _P.shadow, 0.35);
    switch (_t) {
        case "space":
            fwy__bar(_hx, _hy, _ex, _ey, 12 * _s, _P.accent, 0.25); fwy__bar(_hx, _hy, _ex, _ey, 4 * _s, _P.accent, 0.9); fwy__bar(_hx, _hy, _ex, _ey, 1.5 * _s, c_white, 1);
            fwy__disc(_ex, _ey, 5 * _s, fwy__rgb(120, 130, 150), 1);
            break;
        case "haunted":
            fwy__bar(_hx, _hy, _ex, _ey, 3 * _s, fwy__rgb(30, 30, 36), 1);
            for (var _k = 1; _k < 12; _k++) { var _px = lerp(_hx, _ex, _k / 12), _py = lerp(_hy, _ey, _k / 12); fwy__disc(_px, _py, 2.6 * _s, fwy__rgb(30, 30, 36), 1, 8); fwy__disc(_px - 0.5, _py - 0.5, 1 * _s, fwy__rgb(110, 110, 120), 1, 6); }
            break;
        case "candy":
            fwy__bar(_hx, _hy, _ex, _ey, 8 * _s, fwy__rgb(250, 250, 250), 1);
            for (var _k = 0; _k < 10; _k += 2) fwy__bar(lerp(_hx, _ex, _k / 10), lerp(_hy, _ey, _k / 10), lerp(_hx, _ex, (_k + 1) / 10), lerp(_hy, _ey, (_k + 1) / 10), 8 * _s, _P.accent, 1);
            break;
        default:
            var _c = (_t == "desert") ? fwy__rgb(200, 162, 104) : _P.rail;
            fwy__bar(_hx, _hy, _ex, _ey, 9 * _s, fwy__mul(_c, 0.75), 1); fwy__bar(_hx, _hy, _ex, _ey, 6 * _s, _c, 1);
            fwy__bar(_hx - sin(_ang) * 1.5, _hy + cos(_ang) * 1.5, _ex - sin(_ang) * 1.5, _ey + cos(_ang) * 1.5, 1.4 * _s, fwy__mul(_c, 1.25), 1);
            if (_t != "desert") for (var _k = 1; _k < 6; _k++) fwy__disc(lerp(_hx, _ex, _k / 6), lerp(_hy, _ey, _k / 6), 1.2 * _s, fwy__mul(_c, 0.5), 1, 6);
            fwy__disc(_ex, _ey, 4.5 * _s, fwy__mul(_c, 0.8), 1);
            break;
    }
    fwy__disc(_hx, _hy, 7 * _s, fwy__mul(_P.rail, 0.7), 1); fwy__disc(_hx - 1, _hy - 1, 4.5 * _s, _P.railHi, 1);
}

/// @function fwy__draw_spinner(theme, P, x, y, len, arms, ang, s)
/// @description Internal. A spinner: arms of the theme's material round a hub, turned to ang.
function fwy__draw_spinner(_t, _P, _x, _y, _len, _arms, _ang, _s) {
    for (var _k = 0; _k < _arms; _k++) {
        var _a = _ang + _k * 2 * pi / _arms, _ex = _x + cos(_a) * _len, _ey = _y + sin(_a) * _len;
        fwy__bar(_x + 3, _y + 4, _ex + 3, _ey + 4, 8 * _s, _P.shadow, 0.35);
        switch (_t) {
            case "space": fwy__bar(_x, _y, _ex, _ey, 10 * _s, _P.accent, 0.25); fwy__bar(_x, _y, _ex, _ey, 3.5 * _s, _P.accent, 1); fwy__disc(_ex, _ey, 4 * _s, c_white, 1); break;
            case "haunted": fwy__bar(_x, _y, _ex, _ey, 3 * _s, fwy__rgb(70, 50, 36), 1); fwy__tri(_ex, _ey, _ex - cos(_a) * 16 * _s + cos(_a + pi / 2) * 10 * _s, _ey - sin(_a) * 16 * _s + sin(_a + pi / 2) * 10 * _s, _ex - cos(_a) * 6 * _s, _ey - sin(_a) * 6 * _s, fwy__rgb(190, 196, 206), 1); break;
            case "candy": fwy__bar(_x, _y, _ex, _ey, 5 * _s, c_white, 1); fwy__disc(_ex, _ey, 8 * _s, fwy__rgb(250, 90, 150), 1); fwy__ring(_ex, _ey, 3 * _s, 5 * _s, c_white, 1); break;
            case "pirate": fwy__bar(_x, _y, _ex, _ey, 6 * _s, fwy__rgb(150, 100, 56), 1); fwy__orect(_ex - cos(_a) * 8 * _s, _ey - sin(_a) * 8 * _s, _a, 18 * _s, 10 * _s, fwy__rgb(170, 120, 70), 1); break;
            default: var _c = (_t == "desert") ? fwy__rgb(206, 170, 112) : _P.rail; fwy__bar(_x, _y, _ex, _ey, 8 * _s, fwy__mul(_c, 0.75), 1); fwy__bar(_x, _y, _ex, _ey, 5 * _s, _c, 1); fwy__disc(_ex, _ey, 4 * _s, fwy__mul(_c, 0.8), 1); break;
        }
    }
    fwy__disc(_x, _y, 9 * _s, fwy__mul(_P.rail, 0.6), 1); fwy__disc(_x - 1, _y - 1, 6 * _s, _P.railHi, 1); fwy__disc(_x - 2, _y - 2, 2 * _s, c_white, 0.7);
}

// ------------------------------------------------------------------------------------------------ drawing a hole in play

/// @function fwy_hole_view(hole, w, h, [maxScale])
/// @description Frame a hole for a w x h box: the felt and its rails, the windmill's height and the flag, widened to the box's
/// shape, kept inside the world, scaled up to maxScale (1.6). The felt is never cut: when it cannot fit a box of a very
/// different shape at the scale that fills the box, the view scales to fit it and leaves bands (the crop then runs past the
/// world, and fwy_hole_draw draws only the world's part of it). Returns { scale, x, y, crop } - draw with
/// fwy_hole_draw(hole, boxX + view.x, boxY + view.y, view.scale, t, view.crop) and the ball and the overlay at the same
/// x, y, scale; a world point (wx, wy) lands at boxX + view.x + wx * view.scale.
/// @returns {Struct}
function fwy_hole_view(_h, _w, _hh, _max = 1.6) {
    if (!is_struct(_h) || !variable_struct_exists(_h, "cells") || !is_numeric(_w) || !is_numeric(_hh) || _w < 8 || _hh < 8) return { scale: 1, x: 0, y: 0, crop: [0, 0, FWY_W, FWY_H] };
    if (!is_numeric(_max)) _max = 1.6;
    var _x0 = FWY_W, _y0 = FWY_H, _x1 = 0, _y1 = 0;
    for (var _cy = 0; _cy < FWY_GH; _cy++) for (var _cx = 0; _cx < FWY_GW; _cx++) if (fwy__cell(_h, _cx, _cy) != 0) {
        _x0 = min(_x0, FWY_OX + _cx * FWY_CELL); _y0 = min(_y0, FWY_OY + _cy * FWY_CELL); _x1 = max(_x1, FWY_OX + (_cx + 1) * FWY_CELL); _y1 = max(_y1, FWY_OY + (_cy + 1) * FWY_CELL);
    }
    _y0 = min(_y0, _h.cupY - 56);
    for (var _i = 0; _i < array_length(_h.obstacles); _i++) if (_h.obstacles[_i].kind == "mill") _y0 = min(_y0, _h.obstacles[_i].y1 - 150);
    _x0 -= 30; _y0 -= 30; _x1 += 30; _y1 += 30;
    var _A = _w / _hh, _cw0 = _x1 - _x0, _ch0 = _y1 - _y0, _bw = _cw0, _bh = _ch0;
    if (_bw / _bh < _A) _bw = _bh * _A; else _bh = _bw / _A;
    var _fill = max(_w / FWY_W, _hh / FWY_H), _fit = min(_w / _cw0, _hh / _ch0);
    var _s = clamp(_w / _bw, _fill, max(_max, _fill));
    if (_fit < _fill) _s = _fit;
    _bw = _w / _s; _bh = _hh / _s;
    var _cx2 = (_bw <= FWY_W) ? clamp((_x0 + _x1) / 2, _bw / 2, FWY_W - _bw / 2) : (_x0 + _x1) / 2;
    var _cy2 = (_bh <= FWY_H) ? clamp((_y0 + _y1) / 2, _bh / 2, FWY_H - _bh / 2) : (_y0 + _y1) / 2;
    var _wx = _cx2 - _bw / 2, _wy = _cy2 - _bh / 2;
    return { scale: _s, x: -_wx * _s, y: -_wy * _s, crop: [_wx, _wy, _bw, _bh] };
}

/// @function fwy_hole_draw(hole, x, y, [scale], [t], [crop])
/// @description Draw the hole with its world origin at (x, y) at a scale (its baked sprite, made now if it has none), with the
/// moving pieces that sit at ball height at hole time t (the gate, the spinner). crop ([wx, wy, ww, wh] in world pixels, from
/// fwy_hole_view) limits the picture to that part of the world. Draw the ball next, then fwy_hole_draw_over.
/// @returns {Bool} false for a bad hole
function fwy_hole_draw(_h, _x, _y, _sc = 1, _t = 0, _crop = undefined) {
    if (!is_struct(_h) || !variable_struct_exists(_h, "cells") || !is_numeric(_x) || !is_numeric(_y)) return false;
    if (!is_numeric(_sc)) _sc = 1;
    if (!is_numeric(_t)) _t = 0;
    if (!variable_struct_exists(_h, "sprite") || !sprite_exists(_h.sprite)) fwy_hole_bake(_h, max(1, _sc));
    gpu_push_state(); fwy__over();
    var _bs = _h.bakeScale;
    if (is_array(_crop) && array_length(_crop) == 4) {
        var _cx0 = clamp(_crop[0], 0, FWY_W), _cy0 = clamp(_crop[1], 0, FWY_H), _cw = clamp(_crop[2], 1, FWY_W - _cx0), _ch = clamp(_crop[3], 1, FWY_H - _cy0);
        draw_sprite_part_ext(_h.sprite, 0, _cx0 * _bs, _cy0 * _bs, _cw * _bs, _ch * _bs, _x + _cx0 * _sc, _y + _cy0 * _sc, _sc / _bs, _sc / _bs, c_white, 1);
    } else draw_sprite_ext(_h.sprite, 0, _x, _y, _sc / _bs, _sc / _bs, 0, c_white, 1);
    var _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_multiply(matrix_build(_x, _y, 0, 0, 0, 0, _sc, _sc, 1), _mw));
    var _P = fwy__pal(_h.theme);
    for (var _i = 0; _i < array_length(_h.obstacles); _i++) {
        var _o = _h.obstacles[_i];
        if (_o.kind == "gate") {
            var _ph = 2 * pi * (_t / _o.period + _o.phase), _a = _o.a0 + (_o.a1 - _o.a0) * (0.5 - 0.5 * cos(_ph));
            fwy__draw_gate(_h.theme, _P, _o.hx, _o.hy, _a, _o.len, 1);
        } else if (_o.kind == "spinner") fwy__draw_spinner(_h.theme, _P, _o.x, _o.y, _o.len, _o.arms, _o.omega * _t + _o.phase, 1);
    }
    matrix_set(matrix_world, _mw);
    gpu_pop_state();
    return true;
}

/// @function fwy_hole_draw_over(hole, x, y, [scale], [t], [ballX], [ballY])
/// @description Draw what stands taller than the ball: the theme's windmill building (seen through when the ball is behind
/// it) and the flag in the cup, waving.
function fwy_hole_draw_over(_h, _x, _y, _sc = 1, _t = 0, _bx = -1000, _by = -1000) {
    if (!is_struct(_h) || !variable_struct_exists(_h, "cells") || !is_numeric(_x) || !is_numeric(_y)) return false;
    if (!is_numeric(_sc)) _sc = 1;
    if (!is_numeric(_t)) _t = 0;
    if (!is_numeric(_bx)) _bx = -1000;
    if (!is_numeric(_by)) _by = -1000;
    gpu_push_state(); fwy__over();
    var _mw = matrix_get(matrix_world);
    matrix_set(matrix_world, matrix_multiply(matrix_build(_x, _y, 0, 0, 0, 0, _sc, _sc, 1), _mw));
    var _P = fwy__pal(_h.theme);
    for (var _i = 0; _i < array_length(_h.obstacles); _i++) {
        var _o = _h.obstacles[_i];
        if (_o.kind != "mill") continue;
        var _behind = (_bx > _o.x0 - 10 && _bx < _o.x1 + 10 && _by < _o.y1 && _by > _o.y1 - 140);
        fwy__draw_mill(_h.theme, _P, _o.x0, _o.y0, _o.x1, _o.y1, _o.gx0, _o.gx1, fwy__mill_sail(_o, _t) / (2 * pi), _behind ? 0.45 : 1, 1);
    }
    // the flag
    var _fx = _h.cupX, _fy = _h.cupY;
    fwy__line(_fx + 1, _fy, _fx + 14, _fy + 6, 2, _P.shadow, 0.35);
    fwy__bar(_fx, _fy, _fx, _fy - 46, 2.4, fwy__rgb(236, 236, 230), 1);
    draw_primitive_begin(pr_trianglestrip);
    for (var _k = 0; _k <= 8; _k++) {
        var _u = _k / 8, _wv = sin(_t * 6 + _u * 4) * 3 * _u;
        draw_vertex_colour(_fx + _u * 26, _fy - 46 + _wv + _u * 4, _P.flag, 1);
        draw_vertex_colour(_fx + _u * 26, _fy - 30 + _wv - _u * 4, fwy__mul(_P.flag, 0.8), 1);
    }
    draw_primitive_end();
    fwy__disc(_fx, _fy - 47, 2.4, fwy__rgb(250, 220, 90), 1);
    matrix_set(matrix_world, _mw);
    gpu_pop_state();
    return true;
}

/// @function fwy_ball_draw(ball, x, y, [scale], [colour])
/// @description Draw a ball (from fwy_ball_create) for a hole drawn at (x, y): its shadow, and in flight the ball lifted off
/// its shadow and grown, with a highlight and the dimples turning as it rolls.
function fwy_ball_draw(_b, _x, _y, _sc = 1, _col = c_white) {
    if (!is_struct(_b) || !variable_struct_exists(_b, "x") || !is_numeric(_x) || !is_numeric(_y)) return false;
    if (!is_numeric(_sc)) _sc = 1;
    if (!is_numeric(_col)) _col = c_white;
    if (_b.holed) return true;
    gpu_push_state(); fwy__over();
    var _lift = 0;
    if (_b.air > 0 && _b.airT > 0) { var _u = 1 - _b.air / _b.airT; _lift = sin(_u * pi) * 26; }
    var _bx = _x + _b.x * _sc, _by = _y + _b.y * _sc, _r = FWY_BALL_R * _sc * (1 + _lift / 60);
    fwy__ellipse(_bx + (2 + _lift * 0.5) * _sc, _by + (3 + _lift * 0.7) * _sc, FWY_BALL_R * _sc * 1.05, FWY_BALL_R * _sc * 0.75, c_black, 0.35 - min(0.2, _lift / 120));
    _by -= _lift * _sc;
    fwy__disc(_bx, _by, _r, fwy__mul(_col, 0.62), 1, 20);
    fwy__disc(_bx - _r * 0.12, _by - _r * 0.12, _r * 0.84, fwy__mul(_col, 0.86), 1, 20);
    fwy__disc(_bx - _r * 0.22, _by - _r * 0.22, _r * 0.6, _col, 1, 20);
    var _rot = _b.roll / (FWY_BALL_R * 1.2);
    for (var _k = 0; _k < 5; _k++) { var _a = _rot + _k * 1.256, _q = (_k mod 2 == 0) ? 0.45 : 0.25; fwy__disc(_bx + cos(_a) * _r * _q, _by + sin(_a * 1.3) * _r * _q, max(0.6, _r * 0.1), fwy__mul(_col, 0.72), 0.7, 6); }
    fwy__disc(_bx - _r * 0.38, _by - _r * 0.42, _r * 0.2, c_white, 0.9, 10);
    gpu_pop_state();
    return true;
}

/// @function fwy_aim_draw(hole, ball, angle, power, x, y, [scale])
/// @description The aim guide for a resting ball: a dotted line along the shot whose length follows the power, carried round
/// its first rail bounce (traced on the rails, not on moving pieces), and a ring at the ball.
function fwy_aim_draw(_h, _b, _ang, _pow, _x, _y, _sc = 1) {
    if (!is_struct(_h) || !variable_struct_exists(_h, "segs") || !is_struct(_b) || !variable_struct_exists(_b, "x")) return false;
    if (!is_numeric(_ang) || !is_numeric(_pow) || !is_numeric(_x) || !is_numeric(_y)) return false;
    if (!is_numeric(_sc)) _sc = 1;
    _pow = clamp(_pow, 0, 1);
    gpu_push_state(); fwy__over();
    var _len = 40 + _pow * 300, _px = _b.x, _py = _b.y, _dx = cos(_ang), _dy = sin(_ang), _done = 0, _bounced = false;
    var _col = fwy__mix(fwy__rgb(120, 255, 140), fwy__rgb(255, 80, 60), _pow);
    fwy__ring(_x + _px * _sc, _y + _py * _sc, (FWY_BALL_R + 4) * _sc, (FWY_BALL_R + 6) * _sc, c_white, 0.75);
    var _step = 6;
    while (_done < _len) {
        var _nx = _px + _dx * _step, _ny = _py + _dy * _step;
        if (!_bounced) {
            for (var _s = 0; _s < _h.railSegs; _s++) {
                var _e = _h.segs[_s];
                var _ex = _e.x2 - _e.x1, _ey = _e.y2 - _e.y1, _el = max(0.001, fwy__hyp(_ex, _ey));
                var _inx = -_ey / _el, _iny = _ex / _el;
                var _d0 = (_px - _e.x1) * _inx + (_py - _e.y1) * _iny, _d1 = (_nx - _e.x1) * _inx + (_ny - _e.y1) * _iny;
                if (_d0 >= FWY_BALL_R && _d1 < FWY_BALL_R) {
                    var _u = ((_nx - _e.x1) * _ex + (_ny - _e.y1) * _ey) / (_el * _el);
                    if (_u >= 0 && _u <= 1) { var _dn = _dx * _inx + _dy * _iny; _dx -= 2 * _dn * _inx; _dy -= 2 * _dn * _iny; _bounced = true; _nx = _px; _ny = _py; break; }
                }
            }
        }
        if ((_done div _step) mod 2 == 0) fwy__disc(_x + _nx * _sc, _y + _ny * _sc, 2.2 * _sc * (1 - _done / _len * 0.5), _col, 0.9 * (1 - _done / _len * 0.6), 8);
        _px = _nx; _py = _ny; _done += _step;
    }
    gpu_pop_state();
    return true;
}

/// @function fwy_power_draw(x, y, w, h, power, [theme])
/// @description A power gauge: a rounded tube filling from green through amber to red, tick marks, the figure.
function fwy_power_draw(_x, _y, _w, _h, _pow, _theme = "garden") {
    if (!is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_h) || !is_numeric(_pow)) return false;
    _pow = clamp(_pow, 0, 1);
    gpu_push_state(); fwy__over();
    fwy__rect(_x + 2, _y + 3, _x + _w + 2, _y + _h + 3, c_black, 0.35);
    fwy__rect(_x, _y, _x + _w, _y + _h, fwy__rgb(30, 32, 36), 0.92);
    var _n = 24;
    for (var _k = 0; _k < _n; _k++) {
        var _f = (_k + 1) / _n;
        var _c = (_f < 0.5) ? fwy__mix(fwy__rgb(90, 220, 110), fwy__rgb(255, 200, 60), _f * 2) : fwy__mix(fwy__rgb(255, 200, 60), fwy__rgb(255, 70, 60), (_f - 0.5) * 2);
        var _lit = (_f <= _pow + 0.0001);
        var _y0 = _y + _h - 4 - (_h - 8) * (_k + 1) / _n, _y1 = _y + _h - 4 - (_h - 8) * _k / _n;
        fwy__rect(_x + 4, _y0 + 1, _x + _w - 4, _y1 - 1, _lit ? _c : fwy__mul(_c, 0.25), 1);
    }
    gpu_pop_state();
    return true;
}

/// @function fwy_scorecard_draw(game, x, y, w, [title])
/// @description A drawn paper scorecard for a game: the course title in pen, a printed grid (holes, OUT/IN/TOTAL), the PAR row,
/// one row per player with their figures pencilled in (a circle under par, a square over, a star for a hole in one), the
/// player on the tee marked. 9 holes in one block, 18 in two. Returns the height drawn.
/// @returns {Real}
function fwy_scorecard_draw(_G, _x, _y, _w, _title = "") {
    if (!is_struct(_G) || !variable_struct_exists(_G, "scores") || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w)) return 0;
    if (!is_string(_title) || _title == "") _title = _G.course.title;
    gpu_push_state(); fwy__over();
    var _C = _G.course, _np = array_length(_G.players), _blocks = (_C.count > 9) ? 2 : 1;
    var _rowH = 30, _headH = 56, _cols = 9 + 2, _nameW = _w * 0.2, _cellW = (_w - _nameW - 24) / _cols;
    var _blockH = _rowH * (2 + _np) + 12;
    var _hgt = _headH + _blockH * _blocks + 20;
    var _paper = fwy__rgb(250, 246, 232), _ruled = fwy__rgb(120, 150, 200), _ink = fwy__rgb(40, 50, 80), _pencil = fwy__rgb(64, 64, 72);
    // card, shadow, perforated top edge
    fwy__rect(_x + 6, _y + 8, _x + _w + 6, _y + _hgt + 8, c_black, 0.3);
    fwy__rect(_x, _y, _x + _w, _y + _hgt, _paper, 1);
    for (var _k = 0; _k < _w; _k += 12) fwy__disc(_x + 6 + _k, _y + 4, 2, fwy__rgb(220, 214, 196), 1, 8);
    fwy__rect(_x, _y + _hgt - 4, _x + _w, _y + _hgt, fwy__rgb(232, 226, 208), 1);
    fwy__text(_x + 16, _y + 28, _title, fnt_fairway_display_l, 0.52, _ink, 1, fa_left, 1.5);
    fwy__text(_x + _w - 16, _y + 30, "MINI GOLF  -  " + string(_C.count) + " HOLES", fnt_fairway_body_s, 0.62, _ruled, 1, fa_right);
    var _g = fwy_rng(_C.seed * 5 + 3);
    for (var _b = 0; _b < _blocks; _b++) {
        var _by = _y + _headH + _b * _blockH, _h0 = _b * 9;
        var _x0 = _x + 12, _x1 = _x + _w - 12;
        // grid
        fwy__rect(_x0, _by, _x1, _by + _rowH, fwy__rgb(226, 234, 246), 1);
        for (var _r = 0; _r <= 2 + _np; _r++) fwy__rect(_x0, _by + _r * _rowH - 0.75, _x1, _by + _r * _rowH + 0.75, _ruled, (_r == 0 || _r == 2 + _np) ? 1 : 0.7);
        fwy__rect(_x0 - 0.75, _by, _x0 + 0.75, _by + (2 + _np) * _rowH, _ruled, 1);
        for (var _c = 0; _c <= _cols; _c++) { var _cx = _x0 + _nameW + _c * _cellW; fwy__rect(_cx - 0.75, _by, _cx + 0.75, _by + (2 + _np) * _rowH, _ruled, (_c == 9) ? 1 : 0.6); }
        fwy__text(_x0 + 8, _by + _rowH / 2, "HOLE", fnt_fairway_body_s, 0.6, _ink, 1);
        fwy__text(_x0 + 8, _by + _rowH * 1.5, "PAR", fnt_fairway_body_s, 0.6, _ink, 1);
        for (var _c = 0; _c < 9; _c++) {
            var _hi = _h0 + _c, _cx = _x0 + _nameW + (_c + 0.5) * _cellW;
            fwy__text(_cx, _by + _rowH / 2, string(_hi + 1), fnt_fairway_body_s, 0.6, _ink, 1, fa_center);
            if (_hi < _C.count && !is_undefined(_C.holes[_hi])) fwy__text(_cx, _by + _rowH * 1.5, string(_C.holes[_hi].par), fnt_fairway_body_s, 0.6, _ink, 1, fa_center);
            if (_hi == _G.hole && _G.state != "done") fwy__rect(_cx - _cellW / 2 + 1, _by + 1, _cx + _cellW / 2 - 1, _by + _rowH * (2 + _np) - 1, fwy__rgb(255, 230, 90), 0.22);
        }
        var _labA = (_blocks == 2) ? ((_b == 0) ? "OUT" : "IN") : "OUT", _labB = (_b == _blocks - 1) ? "TOTAL" : "";
        fwy__text(_x0 + _nameW + 9.5 * _cellW, _by + _rowH / 2, _labA, fnt_fairway_body_s, 0.56, _ink, 1, fa_center);
        if (_labB != "") fwy__text(_x0 + _nameW + 10.5 * _cellW, _by + _rowH / 2, _labB, fnt_fairway_body_s, 0.5, _ink, 1, fa_center);
        var _parSum = 0, _parAll = 0;
        for (var _c = 0; _c < 9; _c++) if (!is_undefined(_C.holes[_h0 + _c])) _parSum += _C.holes[_h0 + _c].par;
        for (var _c = 0; _c < _C.count; _c++) if (!is_undefined(_C.holes[_c])) _parAll += _C.holes[_c].par;
        fwy__text(_x0 + _nameW + 9.5 * _cellW, _by + _rowH * 1.5, string(_parSum), fnt_fairway_body_s, 0.6, _ink, 1, fa_center);
        if (_labB != "") fwy__text(_x0 + _nameW + 10.5 * _cellW, _by + _rowH * 1.5, string(_parAll), fnt_fairway_body_s, 0.6, _ink, 1, fa_center);
        for (var _p = 0; _p < _np; _p++) {
            var _ry = _by + _rowH * (2.5 + _p), _P = _G.players[_p];
            fwy__disc(_x0 + 12, _ry, 5, _P.colour, 1, 12); fwy__ring(_x0 + 12, _ry, 5, 6, _ink, 0.6);
            if (_G.turn == _p && _G.state != "done") fwy__tri(_x0 + 22, _ry - 5, _x0 + 22, _ry + 5, _x0 + 28, _ry, fwy__rgb(230, 60, 60), 1);
            fwy__text(_x0 + 32, _ry, _P.name, fnt_fairway_body_s, 0.56, _ink, 1);
            var _sum = 0, _any = false;
            for (var _c = 0; _c < 9; _c++) {
                var _hi = _h0 + _c; if (_hi >= _C.count) continue;
                var _s = _G.scores[_p][_hi];
                var _jx = fwy_range(_g, -2, 2), _jy = fwy_range(_g, -2, 2), _ja = fwy_range(_g, -8, 8);
                if (_s < 0) continue;
                _sum += _s; _any = true;
                var _cx = _x0 + _nameW + (_c + 0.5) * _cellW, _par = _C.holes[_hi].par;
                if (_s == 1) { for (var _q = 0; _q < 5; _q++) { var _a0 = -pi / 2 + _q * 2 * pi / 5, _a1 = _a0 + 4 * pi / 5; fwy__line(_cx + cos(_a0) * 12, _ry + sin(_a0) * 12, _cx + cos(_a1) * 12, _ry + sin(_a1) * 12, 1.4, fwy__rgb(220, 60, 60), 0.9); } }
                else if (_s < _par) { fwy__ring(_cx + _jx * 0.5, _ry, 10, 11.4, _pencil, 0.85); if (_s <= _par - 2) fwy__ring(_cx + _jx * 0.5, _ry, 12.5, 13.6, _pencil, 0.7); }
                else if (_s > _par) { var _q2 = 10; fwy__line(_cx - _q2, _ry - _q2, _cx + _q2, _ry - _q2, 1.2, _pencil, 0.8); fwy__line(_cx + _q2, _ry - _q2, _cx + _q2, _ry + _q2, 1.2, _pencil, 0.8); fwy__line(_cx + _q2, _ry + _q2, _cx - _q2, _ry + _q2, 1.2, _pencil, 0.8); fwy__line(_cx - _q2, _ry + _q2, _cx - _q2, _ry - _q2, 1.2, _pencil, 0.8); }
                fwy__text(_cx + _jx, _ry + _jy - 1, string(_s), fnt_fairway_display_s, 0.72, _pencil, 1, fa_center, _ja);
            }
            if (_any) fwy__text(_x0 + _nameW + 9.5 * _cellW, _ry - 1, string(_sum), fnt_fairway_display_s, 0.72, _pencil, 1, fa_center, fwy_range(_g, -6, 6));
            if (_b == _blocks - 1) { var _tt = fwy_game_total(_G, _p); if (_tt[2] > 0) fwy__text(_x0 + _nameW + ((_blocks == 2) ? 10.5 : 10.5) * _cellW, _ry - 1, string(_tt[0]), fnt_fairway_display_s, 0.78, fwy__rgb(190, 40, 50), 1, fa_center); }
        }
    }
    // a pencil lying across the corner
    var _px = _x + _w - 120, _py = _y + _hgt - 10, _pa = -0.12;
    fwy__orect(_px + 4, _py + 4, _pa, 120, 9, c_black, 0.25);
    fwy__orect(_px, _py, _pa, 100, 9, fwy__rgb(250, 196, 50), 1);
    fwy__orect(_px, _py - 1.5, _pa, 100, 3, fwy__rgb(255, 222, 110), 1);
    fwy__orect(_px + cos(_pa) * 55, _py + sin(_pa) * 55, _pa, 10, 9, fwy__rgb(210, 200, 196), 1);
    fwy__orect(_px + cos(_pa) * 63, _py + sin(_pa) * 63, _pa, 7, 9, fwy__rgb(240, 120, 140), 1);
    var _tx = _px - cos(_pa) * 50, _ty = _py - sin(_pa) * 50;
    fwy__tri(_tx, _ty - 4.5, _tx, _ty + 4.5, _tx - cos(_pa) * 14, _ty - sin(_pa) * 14, fwy__rgb(236, 206, 160), 1);
    fwy__tri(_tx - cos(_pa) * 9, _ty - sin(_pa) * 9 - 1.6, _tx - cos(_pa) * 9, _ty - sin(_pa) * 9 + 1.6, _tx - cos(_pa) * 14, _ty - sin(_pa) * 14, fwy__rgb(60, 60, 64), 1);
    gpu_pop_state();
    return _hgt;
}

/// @function fwy_hud_draw(game, x, y, w)
/// @description The band above the hole: hole number and name, par, the player on the tee with their strokes, and every
/// player's running score against par.
function fwy_hud_draw(_G, _x, _y, _w) {
    if (!is_struct(_G) || !variable_struct_exists(_G, "scores") || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w)) return false;
    gpu_push_state(); fwy__over();
    var _h = fwy_game_hole(_G), _P = fwy__pal(_h.theme);
    fwy__rect(_x, _y, _x + _w, _y + 56, fwy__rgb(24, 26, 30), 0.94);
    fwy__rect(_x, _y + 54, _x + _w, _y + 56, _P.felt, 1);
    fwy__text(_x + 14, _y + 22, "HOLE " + string(_G.hole + 1), fnt_fairway_display_s, 0.9, c_white, 1);
    fwy__text(_x + 14, _y + 44, _h.name, fnt_fairway_body_s, 0.56, fwy__rgb(190, 196, 206), 1);
    fwy__text(_x + 168, _y + 22, "PAR " + string(_h.par), fnt_fairway_body_s, 0.8, fwy__rgb(255, 220, 110), 1);
    var _pl = _G.players[_G.turn];
    fwy__disc(_x + 176, _y + 43, 5, _pl.colour, 1, 12);
    fwy__text(_x + 186, _y + 43, _pl.name + "  -  STROKE " + string(_G.strokes + ((_G.state == "aim") ? 1 : 0)), fnt_fairway_body_s, 0.56, c_white, 1);
    var _cx = _x + _w - 12;
    for (var _p = array_length(_G.players) - 1; _p >= 0; _p--) {
        var _t = fwy_game_total(_G, _p), _d = _t[0] - _t[1];
        var _s = (_t[2] == 0) ? "-" : ((_d == 0) ? "E" : ((_d > 0) ? "+" + string(_d) : string(_d)));
        var _bw = 96;
        fwy__rect(_cx - _bw, _y + 10, _cx, _y + 46, (_p == _G.turn) ? fwy__rgb(56, 60, 70) : fwy__rgb(38, 40, 46), 1);
        fwy__disc(_cx - _bw + 12, _y + 28, 6, _G.players[_p].colour, 1, 12);
        fwy__text(_cx - _bw + 24, _y + 21, _G.players[_p].name, fnt_fairway_body_s, 0.46, fwy__rgb(200, 204, 214), 1);
        fwy__text(_cx - _bw + 24, _y + 37, _s + ((_t[2] > 0) ? "  (" + string(_t[0]) + ")" : ""), fnt_fairway_body_s, 0.56, (_d < 0) ? fwy__rgb(120, 230, 140) : c_white, 1);
        _cx -= _bw + 6;
    }
    gpu_pop_state();
    return true;
}

/// @function fwy_draw_free()
/// @description Free anything the drawing layer keeps between calls (nothing is cached across holes; each hole's sprite is
/// freed by fwy_hole_free). Safe to call any time.
function fwy_draw_free() { global.fwy_pv = 0; }
