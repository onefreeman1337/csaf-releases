/// fwy_demo.gml - THE CLUBHOUSE, Fairway's demo room: a 9-hole course on one of six themes, you against two AI rivals, with
/// the HUD, the aim guide, the power gauge and the paper scorecard.
/// Aim: drag back from the ball with the mouse (or a finger) and let go; or LEFT / RIGHT to turn, UP / DOWN for power and
/// SPACE to putt; or a gamepad's left stick to aim, D-pad up / down for power and A to putt.
/// Keys: N a new course - T the next theme - C the scorecard - X autopilot (the planner putts for you) - R replay the hole
/// order from hole 1 - 1 / 2 / 3 / 4 players.
///
/// Fairway - Mini Golf for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function fwy_demo_create(seed, theme)
/// @description Build the demo: a lazily made course (each hole is generated as it is reached) and a game.
function fwy_demo_create(_seed, _theme) {
    var _D = { seed: _seed, theme: _theme, players: 3, course: undefined, game: undefined, aim: 0, power: 0.45, drag: false,
               autopilot: false, card: false, msg: "", msgT: 0, msgCol: c_white, banner: 3, lastHole: -1, hx: 34, hy: 60, sc: 1, crop: undefined };
    fwy_demo_rebuild(_D);
    return _D;
}

/// @function fwy_demo_rebuild(demo)
/// @description A fresh course and game with the current seed, theme and player count.
function fwy_demo_rebuild(_D) {
    if (!is_undefined(_D.course)) for (var _i = 0; _i < _D.course.count; _i++) if (!is_undefined(_D.course.holes[_i])) fwy_hole_free(_D.course.holes[_i]);
    _D.course = fwy_course_create(_D.seed, _D.theme, 9, { lazy: true });
    var _ps = [{ name: "YOU", ai: false }];
    var _rivals = [{ name: "MARGO", ai: 0.85 }, { name: "BRUNO", ai: 0.6 }, { name: "IVY", ai: 0.75 }];
    for (var _i = 1; _i < _D.players; _i++) array_push(_ps, _rivals[_i - 1]);
    _D.game = fwy_game_create(_D.course, _ps);
    _D.lastHole = -1; _D.banner = 3;
    fwy_demo_frame(_D);
    fwy_demo_point_aim(_D);
}

/// @function fwy_demo_frame(demo)
/// @description Frame the hole being played into the box below the HUD (fwy_hole_view) and bake it at that scale.
function fwy_demo_frame(_D) {
    var _h = fwy_game_hole(_D.game), _v = fwy_hole_view(_h, 922, 552, 1.6);
    _D.hx = 34 + _v.x; _D.hy = 60 + _v.y; _D.sc = _v.scale; _D.crop = _v.crop;
    fwy_hole_bake(_h, min(2, _v.scale));
}

/// @function fwy_demo_point_aim(demo)
/// @description Point the aim at the cup (or along the tee mat when the cup is round a corner).
function fwy_demo_point_aim(_D) {
    var _h = fwy_game_hole(_D.game), _b = fwy_game_ball(_D.game);
    _D.aim = fwy__los(_h, _b.x, _b.y, _h.cupX, _h.cupY) ? arctan2(_h.cupY - _b.y, _h.cupX - _b.x) : -degtorad(_h.teeDir);
}

/// @function fwy_demo_say(demo, text, colour)
/// @description Show a message over the hole.
function fwy_demo_say(_D, _s, _c) { _D.msg = _s; _D.msgT = 1.8; _D.msgCol = _c; }

/// @function fwy_demo_step(demo)
/// @description Read the controls, run the game one frame, react to its events.
function fwy_demo_step(_D) {
    var _dt = clamp(delta_time / 1000000, 0, 0.05);
    var _G = _D.game;
    if (keyboard_check_pressed(ord("N"))) { _D.seed += 1; fwy_demo_rebuild(_D); return; }
    if (keyboard_check_pressed(ord("T"))) {
        var _th = fwy_themes(), _ix = 0;
        for (var _i = 0; _i < array_length(_th); _i++) if (_th[_i] == _D.theme) _ix = _i;
        _D.theme = _th[(_ix + 1) mod array_length(_th)];
        fwy_demo_rebuild(_D); return;
    }
    for (var _k = 1; _k <= 4; _k++) if (keyboard_check_pressed(ord(string(_k)))) { _D.players = _k; fwy_demo_rebuild(_D); return; }
    if (keyboard_check_pressed(ord("R"))) { fwy_demo_rebuild(_D); return; }
    if (keyboard_check_pressed(ord("C"))) _D.card = !_D.card;
    if (keyboard_check_pressed(ord("X"))) { _D.autopilot = !_D.autopilot; _G.players[0].ai = _D.autopilot ? 1 : -1; }
    var _human = (_G.state == "aim" && _G.players[_G.turn].ai < 0);
    if (_human) {
        var _b = fwy_game_ball(_G);
        var _mx = (mouse_x - _D.hx) / _D.sc, _my = (mouse_y - _D.hy) / _D.sc;
        if (mouse_check_button_pressed(mb_left) && fwy__hyp(_mx - _b.x, _my - _b.y) < 60) _D.drag = true;
        if (_D.drag) {
            var _dd = fwy__hyp(_b.x - _mx, _b.y - _my);
            if (_dd > 4) _D.aim = arctan2(_b.y - _my, _b.x - _mx);
            _D.power = clamp(_dd / 160, 0, 1);
            if (mouse_check_button_released(mb_left)) { _D.drag = false; if (_D.power > 0.03) fwy_game_shoot(_G, _D.aim, _D.power); }
        }
        _D.aim += ((keyboard_check(vk_left) ? -1 : 0) + (keyboard_check(vk_right) ? 1 : 0)) * _dt * (keyboard_check(vk_shift) ? 0.35 : 1.6);
        _D.power = clamp(_D.power + ((keyboard_check(vk_up) ? 1 : 0) - (keyboard_check(vk_down) ? 1 : 0)) * _dt * 0.6, 0.02, 1);
        if (keyboard_check_pressed(vk_space)) fwy_game_shoot(_G, _D.aim, _D.power);
        if (gamepad_is_connected(0)) {
            var _ax = gamepad_axis_value(0, gp_axislh), _ay = gamepad_axis_value(0, gp_axislv);
            if (fwy__hyp(_ax, _ay) > 0.4) _D.aim = arctan2(_ay, _ax);
            _D.power = clamp(_D.power + ((gamepad_button_check(0, gp_padu) ? 1 : 0) - (gamepad_button_check(0, gp_padd) ? 1 : 0)) * _dt * 0.6, 0.02, 1);
            if (gamepad_button_check_pressed(0, gp_face1)) fwy_game_shoot(_G, _D.aim, _D.power);
        }
    }
    fwy_game_step(_G, _dt);
    for (var _e = 0; _e < array_length(_G.events); _e++) {
        var _ev = _G.events[_e];
        switch (_ev.type) {
            case "holed": fwy_demo_say(_D, _ev.name + "!", (_ev.strokes < _ev.par) ? fwy__rgb(120, 240, 140) : ((_ev.strokes == _ev.par) ? c_white : fwy__rgb(255, 190, 120))); break;
            case "water": fwy_demo_say(_D, "SPLASH  +1", fwy__rgb(120, 200, 255)); break;
            case "pipe": fwy_demo_say(_D, "SHORTCUT", fwy__rgb(255, 230, 120)); break;
            case "jump": fwy_demo_say(_D, "AIRBORNE", fwy__rgb(255, 230, 120)); break;
            case "lipout": fwy_demo_say(_D, "LIPPED OUT", fwy__rgb(255, 170, 120)); break;
            case "limit": fwy_demo_say(_D, "PICKED UP", fwy__rgb(255, 170, 120)); break;
            case "done": _D.card = true; break;
        }
    }
    if (_G.hole != _D.lastHole) {
        if (_D.lastHole >= 0) { var _old = fwy_course_hole(_D.course, _D.lastHole); fwy_hole_free(_old); }
        _D.lastHole = _G.hole; _D.banner = 2.6;
        fwy_demo_frame(_D);
    }
    if (_G.state == "aim" && _G.strokes == 0 && _G.players[_G.turn].ai < 0 && !_D.drag && _D.banner > 2.5) fwy_demo_point_aim(_D);
    if (_D.msgT > 0) _D.msgT -= _dt;
    if (_D.banner > 0) _D.banner -= _dt;
}

/// @function fwy_demo_draw(demo)
/// @description Draw the room: the hole, the ball, what stands over it, the aim, the HUD, the gauge, messages, the card.
function fwy_demo_draw(_D) {
    var _G = _D.game, _h = fwy_game_hole(_G), _b = fwy_game_ball(_G), _P = fwy__pal(_h.theme);
    draw_clear(fwy__mul(_P.ground, 0.55));
    fwy_hole_draw(_h, _D.hx, _D.hy, _D.sc, _G.clock, _D.crop);
    fwy_ball_draw(_b, _D.hx, _D.hy, _D.sc, _G.players[_G.turn].colour);
    fwy_hole_draw_over(_h, _D.hx, _D.hy, _D.sc, _G.clock, _b.x, _b.y);
    if (_G.state == "aim" && _G.players[_G.turn].ai < 0) fwy_aim_draw(_h, _b, _D.aim, _D.power, _D.hx, _D.hy, _D.sc);
    fwy_hud_draw(_G, 0, 0, 960);
    fwy_power_draw(6, 120, 20, 400, _D.power, _h.theme);
    if (_D.banner > 0 && _G.state != "done") {
        var _a = clamp(_D.banner, 0, 1);
        fwy__rect(250, 250, 710, 350, fwy__rgb(20, 22, 26), 0.82 * _a);
        fwy__text(480, 286, _h.name, fnt_fairway_display_l, 0.62, c_white, _a, fa_center);
        fwy__text(480, 326, "HOLE " + string(_G.hole + 1) + "  -  PAR " + string(_h.par) + "  -  " + string_upper(_D.course.title), fnt_fairway_body_s, 0.62, fwy__rgb(210, 214, 222), _a, fa_center);
    }
    if (_D.msgT > 0) fwy__text(480, 140, _D.msg, fnt_fairway_display_l, 0.8, _D.msgCol, clamp(_D.msgT, 0, 1), fa_center);
    if (_D.card || _G.state == "holed" && _G.turn == array_length(_G.players) - 1) fwy_scorecard_draw(_G, 110, 150, 740);
    fwy__text(36, 628, "DRAG BACK from the ball and let go   ARROWS + SPACE   N course  T theme  C card  X autopilot  1-4 players", fnt_fairway_body_s, 0.5, fwy__rgb(230, 232, 236), 0.9);
}

/// @function fwy_demo_free(demo)
/// @description Free what the demo made.
function fwy_demo_free(_D) {
    if (!is_struct(_D)) return;
    if (!is_undefined(_D.course)) for (var _i = 0; _i < _D.course.count; _i++) if (!is_undefined(_D.course.holes[_i])) fwy_hole_free(_D.course.holes[_i]);
    fwy_draw_free();
}
