# Charter — A Chart That Inks Itself As Your Player Explores

**GameMaker 2024.14+ · pure GML · no sprites.** Every mark is geometry, so the package has no
`sprites/` folder at all. The only textures it ships are the two font resources it draws labels
with (`fnt_charter`, `fnt_charter_title`).

Every mark, hatch, compass rose and torn page edge in this package is drawn at run time from data.
There is no `sprites/` directory, because there is nothing to put in one.

---

## Why this exists

Buy a minimap asset and you get a rectangle with dots on it. Buy an icon pack and you get PNGs and
no system — and you still owe someone a drawing for every kind of place in your world, at every
size, in every art style you might change your mind about.

Charter is both halves, and the second half is the one nobody sells: as the player explores, it
inks a **hand-drawn manuscript chart** of what they have actually seen. Unexplored ground is
**unpainted parchment with a torn edge**, not a black rectangle — which is the single most common
way an auto-map announces that it is a widget.

- **44 landmark marks**, hand-authored in six families — 8 settlement · 7 relic · 6 sacred ·
  7 passage · 8 wild · 8 works.
- **4 ink hands** — the scribe drawing the chart. `survey` draws pure outline like a technical pen;
  `field` is heavy, wobbly and leaves its shapes open; `chancery` is formal; `illuminated` doubles
  every contour. The same mark is visibly a different drawing in each.
- **3 landmark states** — `rumoured` is faint, dashed, annotated with a query, and deliberately in
  the **wrong place**; `sighted` is contour only, with no name; `visited` is fully inked and named.
- **6 parchment palettes** computed in Oklch, including `nocturne`, which inverts the whole
  polarity — silver ink on a dark ground, and the unpainted fog goes *darker* than the page.
- **8 compass roses**, **6 cartouche frames**, **8 terrain fills**, **4 page edges**,
  **5 border treatments**.

> 44 marks × 4 hands × 3 states = **528 distinct mark renderings**, before palette.
> Across 6 pages: **3,168 distinct appearances**. Zero PNGs.

The in-engine self-test asserts every one of those counts on each run, so this Readme cannot drift
away from the product.

---

## Install (2 minutes)

1. In GameMaker: **Tools → Import Local Package**, choose `Charter.yymps`, **Add All**.
2. Open `rm_charter_demo` and press **Run**.

That is the whole installation. Nothing to configure, no texture group to set up, no sprite to
import.

---

## The whole integration, in six calls

```gml
// Create — a chart over any rectangle of your world.
chart = cht_chart_create(0, 0, room_width, room_height, 48, 32);
cht_chart_set_title(chart, "The Marchlands", "surveyed in the eleventh year");

// Tell it what is out there. The last argument is whether the chart carries a RUMOUR of the place
// before the player has been near it; false hides it entirely until it is sighted.
cht_chart_add_landmark(chart, "ostmarch", "city", "Ostmarch", 1200, 800, true);
cht_chart_add_landmark(chart, "cave",     "cave", "The Whispering", 4100, 2600, false);

// Terrain, clipped to any polygon - not to a box. A rectangular forest looks like a widget.
cht_chart_add_region(chart, "woodland", [[200,300],[900,260],[1100,700],[400,820]]);

// Step — the one line that does everything.
cht_chart_observe(chart, player.x, player.y);

// Draw — the whole page, re-inked only when something has changed.
cht_chart_draw_cached(chart, 64, 64, 960, 720);

// Clean Up.
cht_chart_free(chart);
```

### Demo room controls

| Key | What it does |
| --- | --- |
| `SPACE` | walk / halt the explorer |
| `1` | cycle the page palette |
| `2` | cycle the ink hand |
| `3` | cycle the compass rose |
| `4` | cycle the cartouche |
| `5` | cycle the border treatment |
| `6` | cycle the page edge |
| `R` | reveal the whole chart |
| `F` | forget everything — knowledge only; registrations survive |
| `S` / `L` | save the chart's knowledge to a string, and load it back |
| `F1` | run the in-engine self-test and show the result on the page |
| click | identify the landmark under the cursor |

---

## What you just imported

| Script | What it is |
| --- | --- |
| `cht_geom` | five drawing primitives, curve sampling, transforms, a seeded hash |
| `cht_palette` | Oklab → sRGB with a per-lightness chroma ceiling |
| `cht_marks` | **the corpus** — 44 landmark marks, six families |
| `cht_hands` | the four ink hands, and the three landmark states |
| `cht_pages` | six parchment palettes, page edges, borders, foxing |
| `cht_rose` | eight compass roses, six cartouche frames |
| `cht_terrain` | eight terrain fills, and the polygon machinery under them |
| `cht_chart` | **the system** — discovery grid, landmark registry, route, save/load |
| `cht_label` | leader lines, annotations, the scale bar, the query glyph |
| `cht_render` | the only file in the package that talks to the GPU |
| `cht_bake` | renders the store sheets — every image on the listing came from here |
| `cht_selftest` | the in-engine suite; press `F1`, or run the exe with `-selftest` |

---

## The API you will actually use

| Function | What it does |
| --- | --- |
| `cht_chart_create(wx0, wy0, wx1, wy1, cols, rows)` | a chart over a rectangle of your world |
| `cht_chart_observe(chart, wx, wy)` | reveal ground, advance landmark states, extend the route |
| `cht_chart_discover(chart, wx, wy, r)` | reveal explicitly, at a radius you choose |
| `cht_chart_add_landmark(chart, id, kind, name, wx, wy, rumoured)` | register a place |
| `cht_chart_set_state(chart, id, state)` | scripted reveals — a map bought from a trader |
| `cht_chart_add_region(chart, terrain, poly)` | terrain, clipped to any polygon |
| `cht_chart_pick(chart, px, py, x0, y0, x1, y1)` | the landmark under a mouse click |
| `cht_chart_counts(chart)` | what the chart knows, for your journal UI |
| `cht_chart_save_string(chart)` / `cht_chart_load_string(chart, s)` | knowledge, as a string your own save can hold |
| `cht_chart_draw(chart, x0, y0, x1, y1, opts)` | the whole page, in one call |
| `cht_chart_draw_cached(...)` | the same page, re-inked only when it changes |
| `cht_chart_free(chart)` | release the cached surface |
| `cht_draw_mark(kind, page, hand, state, cx, cy, s, seed)` | one mark, anywhere, at any size |
| `cht_export_mark(...)` / `cht_export_chart(...)` | either one to a PNG, at any resolution |

`opts` is an optional struct — `{ labels, rose, title, scale_bar, route, foxing }`, each defaulting
to `true`. Drawing the chart as a small corner panel usually means turning the furniture off and
keeping the marks.

---

## Things worth knowing

**Nothing in this package calls `random()`.** Every wobble, torn edge, foxing spot and scattered
tree comes from a seeded hash of the thing it belongs to, so a chart looks the same on every frame
and in every session. A page edge that re-tears itself each frame is the one defect a buyer notices
immediately and cannot work around.

**Every global and macro is namespaced `cht_` / `CHT_`.** GML's global namespace is flat and a
collision inside your project is a support ticket nobody can debug remotely.

**Two coordinate spaces, and only two.** You hand Charter WORLD coordinates — your game's own. It
produces PAGE pixels internally. `cht_chart_w2p` and `cht_chart_p2w` convert, and nothing else in
the package needs to.

**`cht_chart_draw_cached` is the one to use on a HUD.** A full page is a few thousand draw calls;
the cached form re-inks only when something has actually changed, and every mutator signals that
for you. Surfaces are volatile in GameMaker — freed on a resolution change or at the driver's whim
— so the cache re-creates its own surface whenever it has to, and you never have to check.

**Mark sizes.** The chart draws a landmark at `clamp(min(w, h) * 0.055, 10, 46)` pixels. 32 px is a
comfortable size on a half-page panel and 96 px suits a full page or a journal entry; the corpus is
designed silhouette-first so the outermost contour carries the identification at either.

**Save/load carries KNOWLEDGE, not the world.** Registrations, regions and page settings are rebuilt
by your own code on load, because they come from your game. What travels is the revealed grid, each
landmark's state, and the route. A save from a different grid resolution is **refused** rather than
half-applied, so changing `cols`/`rows` between builds of your game cannot corrupt a player's map.

---

## Licence

One commercial licence per developer. Use it in as many of your own projects as you like, including
commercial ones. Do not redistribute the source as an asset.

The two fonts are Open Sans, Apache-2.0 — see `THIRD-PARTY-NOTICES.txt` inside the package.

© 2026 Core Systems Asset Factory
