{
  "$GMScript": "v1",
  "%Name": "cht_selftest",
  "isCompatibility": false,
  "isDnD": false,
  "name": "cht_selftest",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}