/// ============================================================================================
/// CHARTER - cht_selftest: the suite that keeps the store page honest.
///
/// GML cannot be unit-tested outside the engine. There is no headless mock, no batch-mode runner,
/// and no way to assert a picture. What CAN be asserted from inside the engine is that every
/// corpus function returns the number of things the listing claims, that no two of them collapse
/// into the same drawing, that the coordinate contract holds on REAL PLACED GEOMETRY in every
/// hand and every state, that the polygon machinery under the terrain fills is correct on a
/// concave shape, and that the chart system behaves the way its documentation says. Those are the
/// claims a buyer pays for, and they are exactly the ones that rot silently when someone edits a
/// switch.
///
/// -- HOW TO RUN IT -----------------------------------------------------------------------------
///   In the demo room: press F1. The result is drawn on the page.
///   Headless:         run the built executable with `-selftest`. The suite runs, writes a JSON
///                     evidence block to the sandboxed save area, and ends the game.
/// The second path is why cht_selftest_main() exists: a suite that can only be run by a human
/// clicking something is a suite that stops being run.
///
/// -- EVERY COMPARATOR HAS A NEGATIVE CONTROL, AND THAT IS NOT CEREMONY -------------------------
/// This wing shipped a distinctness family that passed VACUOUSLY: it compared with a tolerance of
/// 1e-7, GML's default math epsilon is 1e-6 and participates in comparisons, so `abs(a-b) < 1e-7`
/// was false for EVERY pair of values including equal ones - a suite full of green assertions,
/// none of which could ever have gone red. The rule out of that is "a test that has only ever
/// passed is not a test".
///
/// Breaking one on purpose once does not survive the next edit, so the controls are ASSERTIONS.
/// Stage 0 proves the tolerance can say both yes and no, that the signature comparator can tell
/// two different drawings apart AND match a drawing with itself, and that the reach measurer grows
/// with distance. If a future edit re-introduces the epsilon bug, stage 0 goes red before anything
/// that depends on it can go quietly green.
/// ============================================================================================

/// ⛔ NEVER WRITE A TOLERANCE BELOW ~1e-5 IN GML, AND NEVER WRITE ONE INLINE. Stated once, here,
/// and proven in both directions by stage 0.
#macro CHT_ST_EPS 0.0001

/// How far the suite has got. Read by the crash handler, so a thrown error becomes a NUMBER rather
/// than a modal dialog nobody is present to dismiss.
function cht_st_stage(_n) {
    if (!variable_global_exists("__cht_stage")) global.__cht_stage = 0;
    global.__cht_stage = _n;
}

function cht_st_near(_a, _b) {
    return abs(_a - _b) < CHT_ST_EPS;
}

/// Record one assertion.
function cht_st_ok(_r, _cond, _msg) {
    _r.total++;
    if (_cond) { _r.passed++; return true; }
    array_push(_r.lines, _msg);
    return false;
}

/// ============================================================================================
/// MEASURERS
/// ============================================================================================

/// Fold one number into a running checksum. Every intermediate stays under 2^53: _acc is below
/// 1e9, so _acc * 33 peaks near 3.3e10, well short of where doubles stop being exact.
function cht_st_fold(_acc, _v) {
    return ((_acc * 33) + round(_v * 1000) + 500000) % 1000000000;
}

/// A comparable fingerprint of a part list: the count of each primitive kind, the total vertex
/// count, and a checksum over EVERY coordinate. Two part lists sharing this are, for this
/// product's purposes, the same drawing.
///
/// ⚠️ IT HASHES COORDINATES, NOT A CENTROID. This wing shipped a comparator that folded op count,
/// kind counts and the mean centroid, which makes any two centred two-op shapes identical - it
/// declared a 16-point star and a rounded rectangle "the same shape" and reported that changing a
/// motif's frame changed nothing. A comparator that is too COARSE produces false RED, and a false
/// red costs exactly what a false green does.
function cht_st_signature(_parts) {
    var _k = [0, 0, 0, 0, 0];
    var _pts = 0;
    var _acc = 7;
    for (var _i = 0; _i < array_length(_parts); _i++) {
        var _p = _parts[_i];
        _k[_p.kind]++;
        _acc = cht_st_fold(_acc, _p.kind);
        switch (_p.kind) {
            case CHT_DOT:
                _acc = cht_st_fold(cht_st_fold(cht_st_fold(_acc, _p.cx), _p.cy), _p.r);
                _pts++;
                break;
            case CHT_ARC:
                _acc = cht_st_fold(cht_st_fold(cht_st_fold(_acc, _p.cx), _p.cy), _p.r);
                _acc = cht_st_fold(cht_st_fold(cht_st_fold(_acc, _p.a0), _p.a1), _p.w);
                _pts++;
                break;
            case CHT_STRIP:
                for (var _q = 0; _q < array_length(_p.a); _q++) {
                    _acc = cht_st_fold(cht_st_fold(_acc, _p.a[_q][0]), _p.a[_q][1]);
                    _pts++;
                }
                for (var _q = 0; _q < array_length(_p.b); _q++) {
                    _acc = cht_st_fold(cht_st_fold(_acc, _p.b[_q][0]), _p.b[_q][1]);
                    _pts++;
                }
                break;
            // ⛔ CHT_FILL HAS NO `w`, AND FOLDING IT INTO THE `default` BRANCH CRASHED THE WHOLE
            // SUITE AT STAGE 0. A fan is an area, not a stroke, so cht_geom's cht_fill() builds a
            // struct with `pts` and `role` and nothing else - while cht_place's own switch does
            // list FILL explicitly, which is the shape this branch was written from and the detail
            // it dropped. The headless run turned it into
            // "CRASH at stage 0: Variable <unknown_object>.w(...) not set before reading it",
            // which is exactly what the crash handler exists to produce: a modal dialog nobody
            // could dismiss would have been a 180-second timeout with no cause attached.
            case CHT_FILL:
                for (var _q = 0; _q < array_length(_p.pts); _q++) {
                    _acc = cht_st_fold(cht_st_fold(_acc, _p.pts[_q][0]), _p.pts[_q][1]);
                    _pts++;
                }
                break;
            default:
                _acc = cht_st_fold(_acc, _p.w);
                for (var _q = 0; _q < array_length(_p.pts); _q++) {
                    _acc = cht_st_fold(cht_st_fold(_acc, _p.pts[_q][0]), _p.pts[_q][1]);
                    _pts++;
                }
                break;
        }
    }
    return string(_k[0]) + "." + string(_k[1]) + "." + string(_k[2]) + "." + string(_k[3])
         + "." + string(_k[4]) + "." + string(_pts) + "." + string(_acc);
}

/// The furthest any point of a part list gets from (_ox,_oy).
///
/// ⚠️ A PARTIAL ARC IS SAMPLED, NOT TREATED AS A FULL CIRCLE. The first version of this function
/// measured every arc as `hypot(cx,cy) + r`, which is correct for a ring and badly wrong for a
/// half-arc: `town`'s wall arc is centred at (0, 0.24) with r = 0.40 and sweeps only the upper
/// half, so it never gets near 0.64 - and the conservative formula would have reported the whole
/// corpus in breach of a contract it keeps. A false RED costs exactly what a false green does, and
/// it costs it by sending someone to redraw marks that were right.
///
/// 24 samples on a full circle, scaled by the sweep. A dot keeps `hypot + r`, which for a filled
/// disc is exact.
function cht_st_reach(_parts, _ox, _oy) {
    var _far = 0;
    for (var _i = 0; _i < array_length(_parts); _i++) {
        var _p = _parts[_i];
        switch (_p.kind) {
            case CHT_DOT:
                _far = max(_far, point_distance(_ox, _oy, _p.cx, _p.cy) + _p.r);
                break;
            case CHT_ARC: {
                var _sweep = abs(_p.a1 - _p.a0);
                var _n = max(6, ceil(_sweep * 24 / CHT_TAU) * 4);
                for (var _q = 0; _q <= _n; _q++) {
                    var _a = lerp(_p.a0, _p.a1, _q / _n);
                    _far = max(_far, point_distance(_ox, _oy,
                                                    _p.cx + cos(_a) * _p.r,
                                                    _p.cy + sin(_a) * _p.r));
                }
                break;
            }
            case CHT_STRIP:
                for (var _q = 0; _q < array_length(_p.a); _q++) {
                    _far = max(_far, point_distance(_ox, _oy, _p.a[_q][0], _p.a[_q][1]));
                }
                for (var _q = 0; _q < array_length(_p.b); _q++) {
                    _far = max(_far, point_distance(_ox, _oy, _p.b[_q][0], _p.b[_q][1]));
                }
                break;
            default:
                for (var _q = 0; _q < array_length(_p.pts); _q++) {
                    _far = max(_far, point_distance(_ox, _oy, _p.pts[_q][0], _p.pts[_q][1]));
                }
                break;
        }
    }
    return _far;
}

/// sRGB relative luminance, 0..1, from a GameMaker colour.
///
/// ⚠️ MEASURED OFF THE RENDERED COLOUR, NEVER OFF THE AUTHORED OKLCH TRIPLE. cht_palette applies a
/// per-lightness chroma ceiling and then walks chroma down until the colour fits in sRGB, so the
/// number that reaches the screen is not the number that was typed. Asserting the authored L would
/// be asserting our intention rather than the product.
function cht_st_lum(_col) {
    var _r = colour_get_red(_col)   / 255;
    var _g = colour_get_green(_col) / 255;
    var _b = colour_get_blue(_col)  / 255;
    return 0.2126 * _r + 0.7152 * _g + 0.0722 * _b;
}

/// The total length of a polyline part list. Used to prove a dashed line is SHORTER than the line
/// it came from - which is the only cheap way to prove it actually dashed.
function cht_st_ink_length(_parts) {
    var _t = 0;
    for (var _i = 0; _i < array_length(_parts); _i++) {
        var _p = _parts[_i];
        if (_p.kind != CHT_POLY) continue;
        for (var _q = 1; _q < array_length(_p.pts); _q++) {
            _t += point_distance(_p.pts[_q - 1][0], _p.pts[_q - 1][1],
                                 _p.pts[_q][0], _p.pts[_q][1]);
        }
    }
    return _t;
}

/// ============================================================================================
/// THE SUITE
/// ============================================================================================

function cht_selftest() {
    var _r = { passed: 0, total: 0, lines: [] };

    cht_st_stage(0);  cht_st_controls(_r);
    cht_st_stage(1);  cht_st_counts(_r);
    cht_st_stage(2);  cht_st_contract(_r);
    cht_st_stage(3);  cht_st_distinct(_r);
    cht_st_stage(4);  cht_st_pages(_r);
    cht_st_stage(5);  cht_st_determinism(_r);
    cht_st_stage(6);  cht_st_polygon(_r);
    cht_st_stage(7);  cht_st_terrain(_r);
    cht_st_stage(8);  cht_st_furniture(_r);
    cht_st_stage(9);  cht_st_labels(_r);
    cht_st_stage(10); cht_st_system(_r);
    cht_st_stage(11);

    return _r;
}

/// ============================================================================================
/// 0. NEGATIVE CONTROLS - prove the comparators can fail before trusting what they pass
/// ============================================================================================

function cht_st_controls(_r) {
    // THE EPSILON GUARD. If CHT_ST_EPS ever drops below GML's 1e-6 default math epsilon, the first
    // of these goes red - which is the failure that used to be invisible.
    cht_st_ok(_r, cht_st_near(1.0, 1.0),
        "CONTROL cht_st_near says two EQUAL values differ - the tolerance is below GML's 1e-6 epsilon");
    cht_st_ok(_r, cht_st_near(0.5, 0.5 + 0.00001),
        "CONTROL cht_st_near is too tight for a 1e-5 difference");
    cht_st_ok(_r, !cht_st_near(1.0, 1.01),
        "CONTROL cht_st_near says two DIFFERENT values match - the tolerance is too loose");
    cht_st_ok(_r, !cht_st_near(0, 1), "CONTROL cht_st_near cannot tell 0 from 1");

    // THE SIGNATURE GUARD. A comparator returning a constant would make every assertion in stage 3
    // pass without comparing anything.
    var _sa = cht_st_signature(cht_mark("hamlet"));
    var _sb = cht_st_signature(cht_mark("hamlet"));
    var _sc = cht_st_signature(cht_mark("city"));
    cht_st_ok(_r, _sa == _sb, "CONTROL the signature of a mark differs from itself");
    cht_st_ok(_r, _sa != _sc, "CONTROL hamlet and city produce the SAME signature - the comparator is blind");

    // THE REACH GUARD. cht_st_reach returning a constant would make stage 2 vacuous.
    var _small = cht_st_reach([cht_dot(0, 0, 0.01, CHT_R_INK)], 0, 0);
    var _big   = cht_st_reach([cht_dot(0.4, 0, 0.01, CHT_R_INK)], 0, 0);
    cht_st_ok(_r, _small < _big, "CONTROL cht_st_reach does not grow with distance from the origin");
    cht_st_ok(_r, cht_st_near(_big, 0.41),
        "CONTROL cht_st_reach mis-measures a dot at 0.4 with r=0.01: " + string(_big));

    // THE LUMINANCE GUARD. Stage 4's whole argument is an ordering of these numbers.
    cht_st_ok(_r, cht_st_lum(c_white) > cht_st_lum(c_black),
        "CONTROL cht_st_lum says white is not lighter than black");
    cht_st_ok(_r, cht_st_lum(c_white) > 0.95 && cht_st_lum(c_black) < 0.05,
        "CONTROL cht_st_lum is not on a 0..1 scale");
}

/// ============================================================================================
/// 1. COUNTS - every number the store page claims
/// ============================================================================================

function cht_st_counts(_r) {
    var _marks = cht_mark_ids();
    cht_st_ok(_r, array_length(_marks) == 44,
        "the corpus has " + string(array_length(_marks)) + " marks, not the 44 the listing claims");
    cht_st_ok(_r, array_length(cht_family_ids()) == 6, "there are not 6 families");
    cht_st_ok(_r, array_length(cht_hand_ids()) == CHT_HAND_COUNT, "there are not 4 ink hands");
    cht_st_ok(_r, array_length(cht_page_ids()) == CHT_PAGE_COUNT, "there are not 6 page palettes");
    cht_st_ok(_r, array_length(cht_state_ids()) == 3, "there are not 3 landmark states");
    cht_st_ok(_r, array_length(cht_rose_ids()) == CHT_ROSE_COUNT, "there are not 8 compass roses");
    cht_st_ok(_r, array_length(cht_cartouche_ids()) == CHT_CARTOUCHE_COUNT, "there are not 6 cartouches");
    cht_st_ok(_r, array_length(cht_terrain_ids()) == CHT_TERRAIN_COUNT, "there are not 8 terrain fills");
    cht_st_ok(_r, array_length(cht_edge_ids()) == 4, "there are not 4 page edges");
    cht_st_ok(_r, array_length(cht_border_ids()) == 5, "there are not 5 border treatments");

    // Family boundaries must partition the corpus exactly. A boundary that drifts by one is how a
    // relic ends up filed as a settlement, and nothing about the drawing would show it.
    var _tally = { settlement: 0, relic: 0, sacred: 0, passage: 0, wild: 0, works: 0 };
    for (var _i = 0; _i < array_length(_marks); _i++) {
        var _f = cht_mark_family(_i);
        variable_struct_set(_tally, _f, variable_struct_get(_tally, _f) + 1);
    }
    cht_st_ok(_r, _tally.settlement == 8, "settlement holds " + string(_tally.settlement) + ", not 8");
    cht_st_ok(_r, _tally.relic == 7,      "relic holds " + string(_tally.relic) + ", not 7");
    cht_st_ok(_r, _tally.sacred == 6,     "sacred holds " + string(_tally.sacred) + ", not 6");
    cht_st_ok(_r, _tally.passage == 7,    "passage holds " + string(_tally.passage) + ", not 7");
    cht_st_ok(_r, _tally.wild == 8,       "wild holds " + string(_tally.wild) + ", not 8");
    cht_st_ok(_r, _tally.works == 8,      "works holds " + string(_tally.works) + ", not 8");

    // Every mark must be wired end to end: a name, and geometry with real content in it. A mark
    // returning 2 parts is a bug that looks exactly like a minimalist choice.
    for (var _i = 0; _i < array_length(_marks); _i++) {
        var _id = _marks[_i];
        cht_st_ok(_r, cht_mark_name(_id) != "Unknown", "mark \"" + _id + "\" has no name case");
        var _p = cht_mark(_id);
        cht_st_ok(_r, array_length(_p) >= 3,
            "mark \"" + _id + "\" emits only " + string(array_length(_p)) + " parts");
    }
    for (var _i = 0; _i < array_length(cht_hand_ids()); _i++) {
        cht_st_ok(_r, cht_hand_name(cht_hand_ids()[_i]) != "Unknown",
            "hand \"" + cht_hand_ids()[_i] + "\" has no name case");
    }
    for (var _i = 0; _i < array_length(cht_page_ids()); _i++) {
        cht_st_ok(_r, cht_page_name(cht_page_ids()[_i]) != "Unknown",
            "page \"" + cht_page_ids()[_i] + "\" has no name case");
    }
    for (var _i = 0; _i < array_length(cht_rose_ids()); _i++) {
        cht_st_ok(_r, cht_rose_name(cht_rose_ids()[_i]) != "Unknown",
            "rose \"" + cht_rose_ids()[_i] + "\" has no name case");
    }
    for (var _i = 0; _i < array_length(cht_terrain_ids()); _i++) {
        cht_st_ok(_r, cht_terrain_name(cht_terrain_ids()[_i]) != "Unknown",
            "terrain \"" + cht_terrain_ids()[_i] + "\" has no name case");
    }
    for (var _i = 0; _i < array_length(cht_cartouche_ids()); _i++) {
        cht_st_ok(_r, cht_cartouche_name(cht_cartouche_ids()[_i]) != "Unknown",
            "cartouche \"" + cht_cartouche_ids()[_i] + "\" has no name case");
    }
}

/// ============================================================================================
/// 2. THE COORDINATE CONTRACT - on real placed geometry, in every hand and every state
///
/// This is the stage that would have caught the defect the arithmetic missed. check_marks.js can
/// only re-do the SUM; only the engine can run a hand over a mark and measure what came out.
/// ============================================================================================

function cht_st_contract(_r) {
    // The arithmetic first, from the macros themselves.
    cht_st_ok(_r, (CHT_MARK_BOX + CHT_HAND_GROW) * CHT_MARK_FIT <= CHT_MARK_CELL,
        "the contract arithmetic itself is broken: (" + string(CHT_MARK_BOX) + " + "
        + string(CHT_HAND_GROW) + ") * " + string(CHT_MARK_FIT) + " > " + string(CHT_MARK_CELL));
    cht_st_ok(_r, CHT_HAND_GROW >= CHT_JITTER_MAX,
        "CHT_HAND_GROW is below CHT_JITTER_MAX - jitter alone would break the contract");
    cht_st_ok(_r, CHT_MARK_FIT <= 1, "CHT_MARK_FIT > 1 would magnify a mark past its authored box");

    var _marks = cht_mark_ids();
    var _hands = cht_hand_ids();
    var _worst = 0, _worst_id = "", _worst_hand = "";
    var _worst_grow = 0, _grow_id = "";

    for (var _m = 0; _m < array_length(_marks); _m++) {
        var _id = _marks[_m];
        var _base = cht_mark(_id);
        var _authored = cht_st_reach(_base, 0, 0);
        cht_st_ok(_r, _authored <= CHT_MARK_BOX + CHT_ST_EPS,
            "AUTHORED \"" + _id + "\" reaches " + string(_authored) + " > CHT_MARK_BOX");

        for (var _h = 0; _h < array_length(_hands); _h++) {
            var _hand = cht_hand(_hands[_h]);
            for (var _s = CHT_ST_RUMOURED; _s <= CHT_ST_VISITED; _s++) {
                var _p = cht_state_apply(cht_hand_apply(_base, _hand, cht_hash32(_id)), _s);
                var _grown = cht_st_reach(_p, 0, 0);
                if (_grown - _authored > _worst_grow) {
                    _worst_grow = _grown - _authored; _grow_id = _id + "/" + _hands[_h];
                }
                var _placed = cht_st_reach(cht_place_mark(_p, 0, 0, 1.0, 0, undefined), 0, 0);
                if (_placed > _worst) {
                    _worst = _placed; _worst_id = _id; _worst_hand = _hands[_h];
                }
            }
        }
    }

    cht_st_ok(_r, _worst <= CHT_MARK_CELL + CHT_ST_EPS,
        "PLACED \"" + _worst_id + "\" in the " + _worst_hand + " hand reaches "
        + string(_worst) + " > CHT_MARK_CELL " + string(CHT_MARK_CELL)
        + " - it would overlap its neighbour");

    // And the growth budget itself, measured rather than asserted from the table. This is the
    // assertion that fails if someone raises a hand's overshoot or its doubled-contour offset
    // without going through cht_hand_overshoot_cap.
    cht_st_ok(_r, _worst_grow <= CHT_HAND_GROW + CHT_ST_EPS,
        "a hand grew a mark by " + string(_worst_grow) + " (" + _grow_id
        + "), past CHT_HAND_GROW " + string(CHT_HAND_GROW));

    // THE FAN-APEX SIGNATURE, BOTH DIRECTIONS. The survey hand traces borders instead of filling
    // them, and it has to know whether a fan's point 0 is an interior apex or a real corner. It
    // guessed "always an apex" first and the store sheet grew a stray diagonal across four marks.
    var _ring = cht_ring_fill(cht_ellipse_pts(0, 0, 0.3, 0.2, 10), CHT_R_MASS, 0, 0);
    var _quad = cht_rect_fill(-0.2, -0.2, 0.2, 0.2, CHT_R_MASS);
    var _tri  = cht_fill([[0, -0.3], [0.3, 0.3], [-0.3, 0.3]], CHT_R_MASS);
    cht_st_ok(_r, cht_fan_has_apex(_ring.pts),
        "CONTROL a cht_ring_fill is not recognised as having an interior apex");
    cht_st_ok(_r, !cht_fan_has_apex(_quad.pts),
        "CONTROL a plain rectangle fill is read as having an interior apex - a real corner would be dropped");
    cht_st_ok(_r, !cht_fan_has_apex(_tri.pts),
        "CONTROL a plain triangle fill is read as having an interior apex");

    // And the behaviour that depends on it: the survey hand must emit an OUTLINE for a mass, and
    // that outline must not be a fill.
    var _surveyed = cht_hand_apply([_quad], cht_hand("survey"), 5);
    var _filled   = cht_hand_apply([_quad], cht_hand("chancery"), 5);
    cht_st_ok(_r, array_length(_surveyed) == 1 && _surveyed[0].kind == CHT_POLY,
        "the survey hand did not reduce a mass to an outline");
    cht_st_ok(_r, array_length(_filled) == 1 && _filled[0].kind == CHT_FILL,
        "CONTROL the chancery hand stopped filling its masses");
    cht_st_ok(_r, array_length(_surveyed[0].pts) == array_length(_quad.pts),
        "the survey hand's outline of a 4-corner mass has "
        + string(array_length(_surveyed[0].pts)) + " points, not 4 - it dropped a real corner");

    // A control on the measurement itself: the field hand MUST actually move something, or the
    // assertion above is passing because nothing happened.
    var _f = cht_hand("field");
    var _plain = cht_st_signature(cht_mark("keep"));
    var _wobbled = cht_st_signature(cht_hand_apply(cht_mark("keep"), _f, 991));
    cht_st_ok(_r, _plain != _wobbled,
        "CONTROL the field hand changed nothing - the growth assertion above is vacuous");
}

/// ============================================================================================
/// 3. DISTINCTNESS - the 44 x 4 x 3 claim, checked rather than asserted in prose
/// ============================================================================================

function cht_st_distinct(_r) {
    var _marks = cht_mark_ids();
    var _n = array_length(_marks);
    var _sigs = array_create(_n);
    for (var _i = 0; _i < _n; _i++) _sigs[_i] = cht_st_signature(cht_mark(_marks[_i]));

    var _collisions = 0, _first = "";
    for (var _i = 0; _i < _n; _i++) {
        for (var _j = _i + 1; _j < _n; _j++) {
            if (_sigs[_i] == _sigs[_j]) {
                _collisions++;
                if (_first == "") _first = _marks[_i] + " / " + _marks[_j];
            }
        }
    }
    cht_st_ok(_r, _collisions == 0,
        string(_collisions) + " pair(s) of marks are the SAME drawing, first: " + _first);

    // Four hands must produce four different drawings of the same mark, or the 4x multiplier on
    // the store page is not true. `survey` and `chancery` differ only in weight and hatch, which
    // the signature does fold in.
    var _hands = cht_hand_ids();
    var _hand_dupes = 0, _hfirst = "";
    for (var _m = 0; _m < _n; _m++) {
        var _base = cht_mark(_marks[_m]);
        var _hs = array_create(array_length(_hands));
        for (var _h = 0; _h < array_length(_hands); _h++) {
            _hs[_h] = cht_st_signature(cht_hand_apply(_base, cht_hand(_hands[_h]),
                                                      cht_hash32(_marks[_m])));
        }
        for (var _a = 0; _a < array_length(_hands); _a++) {
            for (var _b = _a + 1; _b < array_length(_hands); _b++) {
                if (_hs[_a] == _hs[_b]) {
                    _hand_dupes++;
                    if (_hfirst == "") _hfirst = _marks[_m] + ": " + _hands[_a] + " = " + _hands[_b];
                }
            }
        }
    }
    cht_st_ok(_r, _hand_dupes == 0,
        string(_hand_dupes) + " mark/hand pair(s) draw identically, first: " + _hfirst);

    // Three states must differ too. A rumour that looks like a visit is the product's central
    // claim failing silently.
    var _state_dupes = 0, _sfirst = "";
    for (var _m = 0; _m < _n; _m++) {
        var _base = cht_mark(_marks[_m]);
        var _ss = array_create(3);
        for (var _s = 0; _s < 3; _s++) _ss[_s] = cht_st_signature(cht_state_apply(_base, _s));
        for (var _a = 0; _a < 3; _a++) {
            for (var _b = _a + 1; _b < 3; _b++) {
                if (_ss[_a] == _ss[_b]) {
                    _state_dupes++;
                    if (_sfirst == "") _sfirst = _marks[_m] + ": state " + string(_a) + " = " + string(_b);
                }
            }
        }
    }
    cht_st_ok(_r, _state_dupes == 0,
        string(_state_dupes) + " mark/state pair(s) draw identically, first: " + _sfirst);
}

/// ============================================================================================
/// 4. THE PAGES - the invariant every mark's second level of detail depends on
/// ============================================================================================

function cht_st_pages(_r) {
    var _ids = cht_page_ids();
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _pg = cht_page(_ids[_i]);
        var _g = cht_st_lum(_pg.ground);
        var _k = cht_st_lum(_pg.ink);
        var _ha = cht_st_lum(_pg.hatch);
        var _ms = cht_st_lum(_pg.mass);
        var _vd = cht_st_lum(_pg.vd);
        var _fg = cht_st_lum(_pg.fog);
        var _nm = _ids[_i];

        // 1. Ink must be readable against its ground, on every page.
        cht_st_ok(_r, abs(_k - _g) >= 0.22,
            _nm + ": ink and ground differ by only " + string_format(abs(_k - _g), 1, 3)
            + " luminance - the ink does not read");

        // 2. Hatch sits BETWEEN ground and ink. Not "lighter than ink" - `nocturne` inverts the
        //    polarity and its hatch is DARKER than its silver ink while still sitting between.
        var _between = ((_k > _g) && (_ha > _g) && (_ha < _k))
                    || ((_k < _g) && (_ha < _g) && (_ha > _k));
        cht_st_ok(_r, _between,
            _nm + ": hatch " + string_format(_ha, 1, 3) + " is not between ground "
            + string_format(_g, 1, 3) + " and ink " + string_format(_k, 1, 3)
            + " - every mark's second level of detail collapses");

        // 3. Mass is at least as far from the ground as ink is: a solid roof must not read lighter
        //    than the line around it.
        cht_st_ok(_r, abs(_ms - _g) >= abs(_k - _g) - CHT_ST_EPS,
            _nm + ": mass is closer to the ground than ink is");

        // 4. `void` is the ground, knocked out of a mass - so it must be indistinguishable from it.
        cht_st_ok(_r, abs(_vd - _g) <= 0.05,
            _nm + ": void differs from ground by " + string_format(abs(_vd - _g), 1, 3)
            + " - a knocked-out window would show as a panel");

        // 5. Fog is UNPAINTED page, so it lies on the opposite side of the ground from the ink.
        //    On vellum that means lighter; on nocturne it means darker. Both are the same rule.
        var _fog_ok = ((_k < _g) && (_fg > _g)) || ((_k > _g) && (_fg < _g));
        cht_st_ok(_r, _fog_ok,
            _nm + ": fog " + string_format(_fg, 1, 3) + " is on the INK side of ground "
            + string_format(_g, 1, 3) + " - unexplored ground would read as inked");
    }

    // No two pages may be the same page.
    var _dupes = 0;
    for (var _i = 0; _i < array_length(_ids); _i++) {
        for (var _j = _i + 1; _j < array_length(_ids); _j++) {
            var _a = cht_page(_ids[_i]), _b = cht_page(_ids[_j]);
            if (_a.ground == _b.ground && _a.ink == _b.ink) _dupes++;
        }
    }
    cht_st_ok(_r, _dupes == 0, string(_dupes) + " page palette pair(s) share a ground and an ink");
}

/// ============================================================================================
/// 5. DETERMINISM - nothing in this package may look different on two consecutive frames
/// ============================================================================================

function cht_st_determinism(_r) {
    // The generator itself. Two freshly seeded rngs must agree on their whole sequence; this wing
    // has already lost a session to a generator whose state did not stay with the generator.
    var _a = cht_rng(12345), _b = cht_rng(12345);
    var _same = true;
    for (var _i = 0; _i < 12; _i++) {
        if (!cht_st_near(cht_rng_next(_a), cht_rng_next(_b))) _same = false;
    }
    cht_st_ok(_r, _same, "two rngs seeded identically produce different sequences");

    var _c = cht_rng(12345), _d = cht_rng(54321);
    cht_st_ok(_r, !cht_st_near(cht_rng_next(_c), cht_rng_next(_d)),
        "CONTROL two DIFFERENTLY seeded rngs produce the same first value");

    // The hash, which every seed in the product comes from.
    cht_st_ok(_r, cht_hash32("barrow") == cht_hash32("barrow"), "cht_hash32 is not stable");
    cht_st_ok(_r, cht_hash32("barrow") != cht_hash32("barrows"), "cht_hash32 collides on one letter");

    // Everything seeded, called twice.
    cht_st_ok(_r, cht_st_signature(cht_hand_apply(cht_mark("wreck"), cht_hand("field"), 77))
               == cht_st_signature(cht_hand_apply(cht_mark("wreck"), cht_hand("field"), 77)),
        "the field hand draws the same mark differently on two identical calls");
    cht_st_ok(_r, cht_st_signature(cht_hand_apply(cht_mark("wreck"), cht_hand("field"), 77))
               != cht_st_signature(cht_hand_apply(cht_mark("wreck"), cht_hand("field"), 78)),
        "CONTROL the field hand ignores its seed");

    var _e1 = cht_page_outline(0, 0, 400, 300, CHT_EDGE_TORN, 4, 9);
    var _e2 = cht_page_outline(0, 0, 400, 300, CHT_EDGE_TORN, 4, 9);
    cht_st_ok(_r, cht_st_signature([cht_poly(_e1, true, 1, CHT_R_INK)])
               == cht_st_signature([cht_poly(_e2, true, 1, CHT_R_INK)]),
        "a torn page edge re-tears itself between two identical calls");

    cht_st_ok(_r, cht_st_signature(cht_foxing(0, 0, 400, 300, 20, 3))
               == cht_st_signature(cht_foxing(0, 0, 400, 300, 20, 3)),
        "foxing is not deterministic");

    var _sq = [[0, 0], [200, 0], [200, 200], [0, 200]];
    cht_st_ok(_r, cht_st_signature(cht_terrain_fill("woodland", _sq, 6, 1.0, 5))
               == cht_st_signature(cht_terrain_fill("woodland", _sq, 6, 1.0, 5)),
        "a woodland fill scatters differently on two identical calls");

    cht_st_ok(_r, cht_st_signature(cht_rose("mariner", 100, 100, 40, undefined))
               == cht_st_signature(cht_rose("mariner", 100, 100, 40, undefined)),
        "a compass rose is not deterministic");
}

/// ============================================================================================
/// 6. THE POLYGON MACHINERY - the one piece that cannot be settled by looking
/// ============================================================================================

function cht_st_polygon(_r) {
    var _sq = [[0, 0], [100, 0], [100, 100], [0, 100]];
    cht_st_ok(_r, cht_pt_in_poly(50, 50, _sq), "a point at the centre of a square reads as outside");
    cht_st_ok(_r, !cht_pt_in_poly(150, 50, _sq), "a point outside a square reads as inside");
    cht_st_ok(_r, !cht_pt_in_poly(50, -10, _sq), "a point above a square reads as inside");

    var _spans = cht_poly_spans(-50, 50, 150, 50, _sq);
    cht_st_ok(_r, array_length(_spans) == 1,
        "a line across a convex square gives " + string(array_length(_spans)) + " spans, not 1");
    if (array_length(_spans) == 1) {
        cht_st_ok(_r, cht_st_near(_spans[0][0], 0.25) && cht_st_near(_spans[0][1], 0.75),
            "the span across a square is " + string(_spans[0][0]) + ".." + string(_spans[0][1])
            + ", not 0.25..0.75");
    } else {
        cht_st_ok(_r, false, "skipped the span-position check because the span count was wrong");
    }

    // ⛔ THE ASSERTION THIS WHOLE STAGE EXISTS FOR. A C-shape, and a ray straight through BOTH
    // ARMS. A naive first-hit-to-last-hit implementation returns ONE span and paints across the
    // notch; the correct one returns TWO. This is not a hypothetical - it is the obvious way to
    // write the function, and on a coastline with a bay it hatches the sea.
    //
    // ⚠️ AND THE FIRST VERSION OF THIS TEST WAS ITSELF WRONG, WHICH IS WORTH LEAVING WRITTEN DOWN.
    // It fired a HORIZONTAL ray at y=50 and demanded two spans. The C below opens to the RIGHT, so
    // at y=50 the polygon runs from x=0 to x=40 and then there is nothing but outside all the way
    // to the edge of the page: ONE span is the correct answer, and the suite reported a failure
    // against code that was right. A false RED costs exactly what a false green does - it just
    // spends the time on a rewrite instead of on a bug. The ray has to cross both ARMS, which
    // means going down the notch, not across it.
    var _c = [[0, 0], [100, 0], [100, 30], [40, 30], [40, 70], [100, 70], [100, 100], [0, 100]];
    var _cs = cht_poly_spans(70, -20, 70, 120, _c);
    cht_st_ok(_r, array_length(_cs) == 2,
        "a line through BOTH ARMS of a C gives " + string(array_length(_cs))
        + " spans, not 2 - the splitter paints across concavities");
    if (array_length(_cs) == 2) {
        // The gap between the two spans must BE the notch: 30..70 of a 140-long ray starting at
        // -20, i.e. t = 0.357 .. 0.643. Checking the positions and not just the count is what
        // stops "two spans" from passing on two spans in the wrong places.
        cht_st_ok(_r, cht_st_near(_cs[0][1], 50 / 140) && cht_st_near(_cs[1][0], 90 / 140),
            "the two spans are " + string(_cs[0][1]) + " and " + string(_cs[1][0])
            + " - the gap is not the notch");
    } else {
        cht_st_ok(_r, false, "skipped the notch-position check because the span count was wrong");
    }

    // And the horizontal ray, asserted for what it ACTUALLY is: this C opens to the right, so a
    // ray at y=50 enters at x=0, leaves at x=40, and never comes back.
    var _cross = cht_poly_spans(-20, 50, 120, 50, _c);
    cht_st_ok(_r, array_length(_cross) == 1,
        "a ray across the open side of a C gives " + string(array_length(_cross)) + " spans, not 1");

    // A line wholly inside must be one full span; one wholly outside, none.
    var _inside = cht_poly_spans(10, 50, 30, 50, _c);
    cht_st_ok(_r, array_length(_inside) == 1, "a segment wholly inside gives no span");
    if (array_length(_inside) == 1) {
        cht_st_ok(_r, cht_st_near(_inside[0][0], 0) && cht_st_near(_inside[0][1], 1),
            "a segment wholly inside is not reported as its whole length");
    } else {
        cht_st_ok(_r, false, "skipped the wholly-inside extent check");
    }
    cht_st_ok(_r, array_length(cht_poly_spans(200, 200, 300, 300, _c)) == 0,
        "a segment wholly outside gives a span");

    var _bb = cht_poly_bbox(_c);
    cht_st_ok(_r, _bb[0] == 0 && _bb[1] == 0 && _bb[2] == 100 && _bb[3] == 100,
        "cht_poly_bbox is wrong on a C");
}

/// ============================================================================================
/// 7. TERRAIN
/// ============================================================================================

function cht_st_terrain(_r) {
    var _poly = [[0, 0], [240, 0], [240, 180], [0, 180]];
    var _ids = cht_terrain_ids();
    var _sigs = array_create(array_length(_ids));

    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _id = _ids[_i];
        var _f = cht_terrain_fill(_id, _poly, 7, 1.0, 100 + _i);
        _sigs[_i] = cht_st_signature(_f);
        cht_st_ok(_r, array_length(_f) >= 8,
            "terrain \"" + _id + "\" produced only " + string(array_length(_f))
            + " parts on a 240x180 region");

        // Nothing may escape the region's bounding box by more than a symbol. A fill that leaks is
        // a forest growing out of the sea, and it is the failure mode of every clipping bug.
        var _out = 0;
        for (var _k = 0; _k < array_length(_f); _k++) {
            var _a = cht_part_anchor(_f[_k]);
            if (_a[0] < -14 || _a[0] > 254 || _a[1] < -14 || _a[1] > 194) _out++;
        }
        cht_st_ok(_r, _out == 0,
            "terrain \"" + _id + "\" put " + string(_out) + " part(s) outside its region");
    }

    var _dupes = 0, _first = "";
    for (var _i = 0; _i < array_length(_ids); _i++) {
        for (var _j = _i + 1; _j < array_length(_ids); _j++) {
            if (_sigs[_i] == _sigs[_j]) {
                _dupes++;
                if (_first == "") _first = _ids[_i] + " / " + _ids[_j];
            }
        }
    }
    cht_st_ok(_r, _dupes == 0, string(_dupes) + " terrain fill(s) are identical, first: " + _first);

    // Density must actually change the density. A parameter that does nothing is worse than an
    // absent one: it is documented, so a buyer will spend an afternoon on it.
    var _sparse = array_length(cht_terrain_fill("woodland", _poly, 7, 0.5, 4));
    var _dense  = array_length(cht_terrain_fill("woodland", _poly, 7, 2.0, 4));
    cht_st_ok(_r, _dense > _sparse * 2,
        "density did almost nothing: 0.5 gave " + string(_sparse) + " parts, 2.0 gave "
        + string(_dense));

    // The C again, this time through a real fill: no symbol may land in the mouth.
    var _c = [[0, 0], [200, 0], [200, 60], [80, 60], [80, 140], [200, 140], [200, 200], [0, 200]];
    var _cf = cht_terrain_fill("conifer", _c, 7, 1.2, 9);
    var _inmouth = 0;
    for (var _k = 0; _k < array_length(_cf); _k++) {
        var _a = cht_part_anchor(_cf[_k]);
        if (_a[0] > 95 && _a[0] < 195 && _a[1] > 75 && _a[1] < 125) _inmouth++;
    }
    cht_st_ok(_r, _inmouth == 0,
        string(_inmouth) + " conifer(s) grew in the MOUTH of a concave region");
}

/// ============================================================================================
/// 8. PAGE FURNITURE
/// ============================================================================================

function cht_st_furniture(_r) {
    var _ids = cht_rose_ids();
    var _sigs = array_create(array_length(_ids));
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _rose = cht_rose(_ids[_i], 200, 200, 60, undefined);
        _sigs[_i] = cht_st_signature(_rose);
        cht_st_ok(_r, array_length(_rose) >= 6,
            "rose \"" + _ids[_i] + "\" has only " + string(array_length(_rose)) + " parts");

        // NORTH IS UP, and it is the LONGEST ray. y is down, so the topmost ink must be further
        // above the centre than the bottommost is below it. A rose whose north drifted is a defect
        // no compile could see and no buyer would forgive.
        var _up = 0, _down = 0;
        for (var _k = 0; _k < array_length(_rose); _k++) {
            var _p = _rose[_k];
            if (_p.kind == CHT_DOT || _p.kind == CHT_ARC) continue;
            if (_p.kind == CHT_STRIP) continue;
            for (var _q = 0; _q < array_length(_p.pts); _q++) {
                _up   = max(_up,   200 - _p.pts[_q][1]);
                _down = max(_down, _p.pts[_q][1] - 200);
            }
        }
        cht_st_ok(_r, _up >= _down - CHT_ST_EPS,
            "rose \"" + _ids[_i] + "\" reaches " + string(_down) + " down and only "
            + string(_up) + " up - north is not the long ray");
    }
    var _dupes = 0;
    for (var _i = 0; _i < array_length(_ids); _i++) {
        for (var _j = _i + 1; _j < array_length(_ids); _j++) {
            if (_sigs[_i] == _sigs[_j]) _dupes++;
        }
    }
    cht_st_ok(_r, _dupes == 0, string(_dupes) + " compass rose pair(s) are the same drawing");

    var _cids = cht_cartouche_ids();
    var _csigs = array_create(array_length(_cids));
    for (var _i = 0; _i < array_length(_cids); _i++) {
        var _cf = cht_cartouche(_cids[_i], 100, 100, 400, 180, undefined);
        _csigs[_i] = cht_st_signature(_cf);
        cht_st_ok(_r, array_length(_cf) >= 1,
            "cartouche \"" + _cids[_i] + "\" produced nothing");
        var _in = cht_cartouche_inset(_cids[_i]);
        cht_st_ok(_r, _in > 0 && _in < 0.5,
            "cartouche \"" + _cids[_i] + "\" reports an inset of " + string(_in)
            + ", which would leave no room for a title");
    }
    var _cd = 0;
    for (var _i = 0; _i < array_length(_cids); _i++) {
        for (var _j = _i + 1; _j < array_length(_cids); _j++) {
            if (_csigs[_i] == _csigs[_j]) _cd++;
        }
    }
    cht_st_ok(_r, _cd == 0, string(_cd) + " cartouche pair(s) are the same frame");

    // Edges and borders must each be four and five DIFFERENT things.
    var _e = [CHT_EDGE_DECKLE, CHT_EDGE_TORN, CHT_EDGE_BURNT, CHT_EDGE_CUT];
    var _esig = array_create(4);
    for (var _i = 0; _i < 4; _i++) {
        _esig[_i] = cht_st_signature([cht_poly(cht_page_outline(0, 0, 400, 300, _e[_i], 5, 21),
                                               true, 1, CHT_R_INK)]);
    }
    var _ed = 0;
    for (var _i = 0; _i < 4; _i++) {
        for (var _j = _i + 1; _j < 4; _j++) if (_esig[_i] == _esig[_j]) _ed++;
    }
    cht_st_ok(_r, _ed == 0, string(_ed) + " page edge pair(s) are identical");

    var _bids = cht_border_ids();
    var _bsig = array_create(array_length(_bids));
    for (var _i = 0; _i < array_length(_bids); _i++) {
        _bsig[_i] = cht_st_signature(cht_border(0, 0, 400, 300, _bids[_i], 14, 1.2));
    }
    var _bd = 0;
    for (var _i = 0; _i < array_length(_bids); _i++) {
        for (var _j = _i + 1; _j < array_length(_bids); _j++) if (_bsig[_i] == _bsig[_j]) _bd++;
    }
    cht_st_ok(_r, _bd == 0, string(_bd) + " border pair(s) are identical");
}

/// ============================================================================================
/// 9. LABELS, LEADERS, DASHES
/// ============================================================================================

function cht_st_labels(_r) {
    var _ld = cht_leader(100, 100, 20, -20, 16, 1.1);
    cht_st_ok(_r, array_length(_ld.parts) == 2, "a leader is not two parts");
    cht_st_ok(_r, _ld.tip[0] > 100, "a leader running right ends to the LEFT of its mark");
    cht_st_ok(_r, cht_st_near(_ld.tip[1], 80), "a leader's tip is not level with its elbow");

    var _left = cht_leader(100, 100, -20, -20, 16, 1.1);
    cht_st_ok(_r, _left.tip[0] < 100, "a leader running left ends to the RIGHT of its mark");

    var _an = cht_label_annotation("Ashford", 200, 200, true, false, 30, cht_hand("chancery"), undefined);
    cht_st_ok(_r, array_length(_an.labels) == 1, "an annotation did not produce exactly one label");
    cht_st_ok(_r, _an.labels[0].text == "Ashford", "an annotation lost its text");
    cht_st_ok(_r, array_length(_an.parts) >= 2, "an annotation produced no leader");

    // The hand writes the text too - and `survey` must NOT tilt, or the effect is noise.
    var _tf = cht_label_tilt(cht_hand("field"), "Ashford");
    var _ts = cht_label_tilt(cht_hand("survey"), "Ashford");
    cht_st_ok(_r, _ts == 0, "the survey hand tilted its label");
    cht_st_ok(_r, abs(_tf) > 0, "the field hand did not tilt its label");
    cht_st_ok(_r, abs(_tf) <= 2.4, "the field hand tilted a label by " + string(_tf) + " degrees");
    cht_st_ok(_r, cht_st_near(_tf, cht_label_tilt(cht_hand("field"), "Ashford")),
        "a label's tilt is not deterministic");
    cht_st_ok(_r, !cht_st_near(_tf, cht_label_tilt(cht_hand("field"), "Bramble")),
        "CONTROL two different names get the identical tilt");

    // Dashing must actually dash: more pieces than the input, and strictly less ink.
    var _line = [[0, 0], [300, 0]];
    var _solid = cht_st_ink_length([cht_poly(_line, false, 1, CHT_R_INK)]);
    var _dashes = cht_dash_poly(_line, false, 1, CHT_R_INK);
    cht_st_ok(_r, array_length(_dashes) > 1,
        "cht_dash_poly returned " + string(array_length(_dashes)) + " piece(s) - it did not dash");
    var _dashed = cht_st_ink_length(_dashes);
    cht_st_ok(_r, _dashed < _solid * 0.85,
        "a dashed line carries " + string_format(_dashed / max(1, _solid) * 100, 1, 0)
        + "% of the solid line's ink - the gaps are not there");
    cht_st_ok(_r, _dashed > _solid * 0.30,
        "a dashed line carries almost no ink at all - the dashes are not there either");

    // Scale-free: the SAME shape at ten times the size must dash into the same number of pieces.
    var _big = cht_dash_poly([[0, 0], [3000, 0]], false, 1, CHT_R_INK);
    cht_st_ok(_r, array_length(_big) == array_length(_dashes),
        "dashing is not scale-free: " + string(array_length(_dashes)) + " pieces at 300px, "
        + string(array_length(_big)) + " at 3000px");

    cht_st_ok(_r, array_length(cht_label_query(0, 0, 12, undefined)) == 3,
        "the query glyph is not three strokes");

    var _sb = cht_label_scale_bar(0, 0, 200, 8, 4, "leagues", cht_hand("survey"), undefined);
    cht_st_ok(_r, array_length(_sb.labels) == 2, "the scale bar does not carry exactly two numbers");
    cht_st_ok(_r, array_length(_sb.parts) >= 9,
        "the scale bar has " + string(array_length(_sb.parts)) + " parts - it lost its divisions");

    var _tb = cht_label_title_block("scroll", 0, 0, 300, 70, "Marchlands", "surveyed 1187",
                                    cht_hand("chancery"), undefined);
    cht_st_ok(_r, array_length(_tb.labels) == 2, "a title block with a subtitle produced one label");
    var _tb1 = cht_label_title_block("rule", 0, 0, 300, 70, "Marchlands", "", undefined, undefined);
    cht_st_ok(_r, array_length(_tb1.labels) == 1, "a title block with no subtitle produced two labels");
}

/// ============================================================================================
/// 10. THE SYSTEM - discovery, states, route, save and load
/// ============================================================================================

function cht_st_system(_r) {
    var _c = cht_chart_create(0, 0, 1000, 800, 20, 16);
    cht_st_ok(_r, cht_chart_progress(_c) == 0, "a new chart is not blank");
    cht_st_ok(_r, array_length(_c.seen) == 320, "the discovery grid is the wrong size");

    // Mapping, both ways.
    var _p = cht_chart_w2p(_c, 500, 400, 0, 0, 200, 160);
    cht_st_ok(_r, cht_st_near(_p[0], 100) && cht_st_near(_p[1], 80),
        "world->page put the centre at " + string(_p[0]) + "," + string(_p[1]));
    var _w = cht_chart_p2w(_c, _p[0], _p[1], 0, 0, 200, 160);
    cht_st_ok(_r, cht_st_near(_w[0], 500) && cht_st_near(_w[1], 400),
        "page->world did not round-trip");

    var _cell = cht_chart_cell_of(_c, 25, 25);
    cht_st_ok(_r, _cell[0] == 0 && _cell[1] == 0, "the top-left world point is not in cell 0,0");
    var _cl = cht_chart_cell_of(_c, -500, -500);
    cht_st_ok(_r, _cl[0] == 0 && _cl[1] == 0, "a point outside the chart did not clamp to an edge cell");

    // Landmarks and their states.
    cht_chart_add_landmark(_c, "home", "hamlet", "Wickthorn", 100, 100, true);
    cht_chart_add_landmark(_c, "far",  "citadel", "Highwatch", 900, 700, true);
    cht_chart_add_landmark(_c, "secret", "barrow", "The Long Barrow", 500, 400, false);
    cht_st_ok(_r, array_length(_c.landmarks) == 3, "three landmarks did not register");
    cht_st_ok(_r, !is_undefined(cht_chart_landmark(_c, "home")), "a registered landmark cannot be found");
    cht_st_ok(_r, is_undefined(cht_chart_landmark(_c, "nowhere")),
        "CONTROL an unregistered id returned a landmark");

    var _home = cht_chart_landmark(_c, "home");
    var _secret = cht_chart_landmark(_c, "secret");
    cht_st_ok(_r, _home.state == CHT_ST_RUMOURED, "a new landmark is not rumoured");
    cht_st_ok(_r, _home.known, "a rumoured landmark is not known to the chart");
    cht_st_ok(_r, !_secret.known, "a landmark registered with _rumoured false is visible anyway");

    // A rumour is drawn in the WRONG PLACE, and the same wrong place every time.
    var _rp = cht_chart_landmark_pos(_home);
    cht_st_ok(_r, !cht_st_near(_rp[0], 100) || !cht_st_near(_rp[1], 100),
        "a rumoured landmark is drawn at its true position - the rumour is not a rumour");
    cht_st_ok(_r, point_distance(_rp[0], _rp[1], 100, 100) < 80,
        "a rumour's offset is larger than the chart can absorb: "
        + string(point_distance(_rp[0], _rp[1], 100, 100)));

    // Discovery.
    cht_chart_set_ranges(_c, 150, 40);
    var _new = cht_chart_discover(_c, 100, 100, 150);
    cht_st_ok(_r, _new > 0, "discovering around the player revealed nothing");
    cht_st_ok(_r, cht_chart_seen_at(_c, 100, 100), "the player's own cell was not revealed");
    cht_st_ok(_r, !cht_chart_seen_at(_c, 900, 700), "a distant cell was revealed");
    cht_st_ok(_r, _home.state == CHT_ST_VISITED,
        "standing on a landmark did not mark it visited (state " + string(_home.state) + ")");

    var _before = _c.seen_count;
    cht_chart_discover(_c, 100, 100, 150);
    cht_st_ok(_r, _c.seen_count == _before, "re-discovering the same ground revealed new cells");

    // Sighted, not visited: close enough to see, too far to arrive.
    cht_chart_discover(_c, 500, 300, 150);
    cht_st_ok(_r, _secret.known, "a hidden landmark stayed hidden after being sighted");
    cht_st_ok(_r, _secret.state == CHT_ST_SIGHTED,
        "a landmark 100 units away with sight 150 and visit 40 is state " + string(_secret.state));
    var _sp = cht_chart_landmark_pos(_secret);
    cht_st_ok(_r, cht_st_near(_sp[0], 500) && cht_st_near(_sp[1], 400),
        "a sighted landmark is still drawn at its rumoured offset");

    // States never regress.
    cht_chart_discover(_c, 0, 0, 10);
    cht_st_ok(_r, _home.state == CHT_ST_VISITED, "walking away un-visited a landmark");

    // Route.
    var _c2 = cht_chart_create(0, 0, 1000, 800, 20, 16);
    for (var _i = 0; _i < 40; _i++) cht_chart_observe(_c2, _i * 20, 400);
    cht_st_ok(_r, array_length(_c2.route) > 5,
        "walking 800 units recorded " + string(array_length(_c2.route)) + " route points");
    var _rn = array_length(_c2.route);
    cht_chart_observe(_c2, 780, 400);
    cht_st_ok(_r, array_length(_c2.route) == _rn,
        "standing still added a route point");

    // Counts.
    var _k = cht_chart_counts(_c);
    cht_st_ok(_r, _k.landmarks == 3, "counts disagrees about how many landmarks there are");
    cht_st_ok(_r, _k.visited + _k.sighted + _k.rumoured + _k.hidden == 3,
        "the state tally does not add up to the landmark count");
    cht_st_ok(_r, _k.progress > 0 && _k.progress < 1, "progress is not strictly between 0 and 1");

    // Reveal and forget.
    cht_chart_reveal_all(_c);
    cht_st_ok(_r, cht_st_near(cht_chart_progress(_c), 1), "reveal_all did not reveal everything");
    cht_st_ok(_r, cht_chart_counts(_c).visited == 3, "reveal_all did not visit every landmark");
    cht_chart_forget(_c);
    cht_st_ok(_r, cht_chart_progress(_c) == 0, "forget did not clear the grid");
    cht_st_ok(_r, array_length(_c.landmarks) == 3, "forget deleted the REGISTRATIONS, not the knowledge");
    cht_st_ok(_r, !cht_chart_landmark(_c, "secret").known,
        "forget left a hidden landmark visible");

    // Save and load.
    var _src = cht_chart_create(0, 0, 1000, 800, 20, 16);
    cht_chart_add_landmark(_src, "home", "hamlet", "Wickthorn", 100, 100, true);
    cht_chart_add_landmark(_src, "far", "citadel", "Highwatch", 900, 700, true);
    cht_chart_set_ranges(_src, 150, 40);
    cht_chart_observe(_src, 100, 100);
    cht_chart_observe(_src, 300, 200);
    var _saved = cht_chart_save_string(_src);
    cht_st_ok(_r, string_length(_saved) > 100, "a saved chart is suspiciously short");

    var _dst = cht_chart_create(0, 0, 1000, 800, 20, 16);
    cht_chart_add_landmark(_dst, "home", "hamlet", "Wickthorn", 100, 100, true);
    cht_chart_add_landmark(_dst, "far", "citadel", "Highwatch", 900, 700, true);
    cht_st_ok(_r, cht_chart_load_string(_dst, _saved), "a chart refused to load its own save");
    cht_st_ok(_r, _dst.seen_count == _src.seen_count,
        "load restored " + string(_dst.seen_count) + " cells, not " + string(_src.seen_count));
    cht_st_ok(_r, cht_chart_landmark(_dst, "home").state == cht_chart_landmark(_src, "home").state,
        "load did not restore a landmark state");
    cht_st_ok(_r, array_length(_dst.route) == array_length(_src.route),
        "load did not restore the route");

    // A grid-size mismatch must be REFUSED, not half-applied. The realistic cause is a buyer
    // changing their resolution between builds, and a product that corrupts a player's map over
    // that is a product nobody keeps.
    var _wrong = cht_chart_create(0, 0, 1000, 800, 24, 16);
    cht_st_ok(_r, !cht_chart_load_string(_wrong, _saved),
        "a save from a 20x16 grid loaded onto a 24x16 chart");
    cht_st_ok(_r, _wrong.seen_count == 0, "the refused load still touched the grid");
    cht_st_ok(_r, !cht_chart_load_string(_wrong, "not json at all"),
        "load accepted a string that is not a save");

    // Regions.
    cht_chart_add_region_rect(_src, "woodland", 100, 100, 400, 300);
    cht_st_ok(_r, array_length(_src.regions) == 1, "a region did not register");
    var _pg = cht_chart_region_page(_src, _src.regions[0], 0, 0, 200, 160);
    cht_st_ok(_r, array_length(_pg) == 4, "a rectangular region is not four points in page space");
    cht_st_ok(_r, cht_st_near(_pg[0][0], 20) && cht_st_near(_pg[0][1], 20),
        "a region's first corner mapped to " + string(_pg[0][0]) + "," + string(_pg[0][1]));

    // fit_rect must preserve the world's aspect.
    var _fr = cht_chart_fit_rect(_src, 0, 0, 400, 400);
    var _aspect = (_fr[2] - _fr[0]) / (_fr[3] - _fr[1]);
    cht_st_ok(_r, cht_st_near(_aspect, 1000 / 800),
        "fit_rect produced an aspect of " + string(_aspect) + ", not 1.25");
}

/// ============================================================================================
/// HEADLESS ENTRY POINT
/// ============================================================================================

/// Write the evidence block to the sandboxed save area.
///
/// ⚠️ A FILE, BECAUSE THE OTHER TWO ROUTES WERE MEASURED AND BOTH FAIL SILENTLY IN A RELEASE BUILD:
/// the runner's `-debugoutput` flag produces the ENGINE's boot lines and nothing from user code,
/// and game_end(n) does NOT propagate its argument to the process exit code. A sandboxed file write
/// needs no runner flag and survives packaging.
function cht_st_write(_json, _lines) {
    var _f = file_text_open_write("charter_selftest.json");
    file_text_write_string(_f, _json);
    file_text_writeln(_f);
    for (var _i = 0; _i < array_length(_lines); _i++) {
        file_text_write_string(_f, "FAIL " + _lines[_i]);
        file_text_writeln(_f);
    }
    file_text_close(_f);
}

/// Was -selftest passed on the command line?
///
/// Scanned from 0 to parameter_count() INCLUSIVE. GameMaker has never been consistent about whether
/// index 0 is the executable path or the first real argument, and the cost of being wrong is a flag
/// that is silently never seen - the least debuggable failure a headless runner has.
function cht_selftest_requested() {
    for (var _i = 0; _i <= parameter_count(); _i++) {
        if (string_lower(parameter_string(_i)) == "-selftest") return true;
    }
    return false;
}

/// Run the suite, write the evidence block, and end the game.
function cht_selftest_main() {
    // ⛔ INSTALL THE CRASH HANDLER FIRST. A GML runtime error opens a MODAL DIALOG, and headless
    // there is nobody to dismiss it - the process simply never exits and every runner reports a
    // meaningless timeout. With this handler an error becomes a decodable stage number instead.
    exception_unhandled_handler(function(_ex) {
        if (!variable_global_exists("__cht_stage")) global.__cht_stage = 0;
        var _msg = "CRASH at stage " + string(global.__cht_stage) + ": " + string(_ex.message);
        show_debug_message("CHARTER SELFTEST " + _msg);
        cht_st_write("{\"ran\":false,\"blocked\":true,\"passed\":0,\"total\":0,\"failed\":0,"
            + "\"suite\":\"cht_selftest\",\"product\":\"Charter\",\"reason\":\"" + _msg + "\"}", []);
        game_end(1);
    });
    cht_st_stage(0);

    var _t0 = get_timer();
    var _r = cht_selftest();
    var _ms = (get_timer() - _t0) / 1000;

    show_debug_message("CHARTER SELFTEST  " + string(_r.passed) + "/" + string(_r.total)
        + "  in " + string_format(_ms, 1, 1) + " ms");
    for (var _i = 0; _i < array_length(_r.lines); _i++) {
        show_debug_message("CHARTER SELFTEST FAIL  " + _r.lines[_i]);
    }

    var _json = "{\"ran\":true,\"blocked\":false,\"passed\":" + string(_r.passed)
        + ",\"total\":" + string(_r.total)
        + ",\"failed\":" + string(_r.total - _r.passed)
        + ",\"durationMs\":" + string_format(_ms, 1, 1)
        + ",\"suite\":\"cht_selftest\",\"product\":\"Charter\",\"version\":\"" + CHT_VERSION + "\"}";

    show_debug_message("CHARTER_TESTS_JSON_BEGIN");
    show_debug_message(_json);
    show_debug_message("CHARTER_TESTS_JSON_END");

    cht_st_write(_json, _r.lines);
    game_end(_r.passed == _r.total ? 0 : 1);
}
