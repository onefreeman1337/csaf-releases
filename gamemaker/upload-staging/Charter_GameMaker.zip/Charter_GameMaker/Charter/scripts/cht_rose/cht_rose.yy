{
  "$GMScript": "v1",
  "%Name": "cht_rose",
  "isCompatibility": false,
  "isDnD": false,
  "name": "cht_rose",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}