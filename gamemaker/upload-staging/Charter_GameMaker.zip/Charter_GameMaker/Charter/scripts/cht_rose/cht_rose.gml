/// ============================================================================================
/// CHARTER - cht_rose: eight compass roses and six cartouche frames. The page furniture.
///
/// The furniture is not decoration. A chart page without a rose and a title cartouche reads as a
/// diagram; with them it reads as a document somebody made. This is the cheapest large increase in
/// perceived craft in the whole product, and it is why the corpus document budgets eight roses
/// rather than one - a buyer choosing between eight is choosing their game's identity, and a buyer
/// given one is being handed our taste.
///
/// -- COORDINATES -------------------------------------------------------------------------------
/// Unlike cht_marks, everything here is authored directly in PAGE coordinates: a rose is placed at
/// (_cx,_cy) with radius _r and a cartouche is fitted to a rectangle. Roses and frames are laid out
/// against the page, never against a cell, so a unit box would be an indirection with nothing on
/// the other end of it.
///
/// Stroke widths are expressed as a fraction of _r for the same reason cht_marks expresses them as
/// a fraction of the mark box: a rose drawn at 40px and one drawn at 200px must look like the same
/// object. cht_render's 0.55px floor keeps the finest ticks visible at the small end.
///
/// -- NORTH IS UP AND THAT IS ASSERTED ----------------------------------------------------------
/// y is DOWN throughout this package (GML's convention, and cht_geom's), so north is -y and the
/// north ray is authored at angle -pi/2. Every rose here puts its LONGEST or most decorated ray
/// there, and cht_selftest asserts that the topmost ink of every rose is nearer the top than the
/// bottommost is to the bottom. A rose whose north drifted would be a defect no compile can see.
/// ============================================================================================

#macro CHT_ROSE_COUNT      8
#macro CHT_CARTOUCHE_COUNT 6

#macro CHT_NORTH (-pi * 0.5)

function cht_rose_ids() {
    return ["quarter", "eight", "sixteen", "windrose", "fleur", "lodestone", "astrolabe", "mariner"];
}

function cht_rose_name(_id) {
    switch (_id) {
        case "quarter":   return "Quarter Rose";
        case "eight":     return "Eight Point";
        case "sixteen":   return "Sixteen Point";
        case "windrose":  return "Portolan Wind Rose";
        case "fleur":     return "Fleur North";
        case "lodestone": return "Lodestone";
        case "astrolabe": return "Astrolabe";
        case "mariner":   return "Mariner's Card";
    }
    return "Unknown";
}

/// ============================================================================================
/// SHARED PIECES
/// ============================================================================================

/// One compass point, as a kite: tip on the bearing, two shoulders at a third of the way out, and
/// the base at the centre.
///
/// The kite is a FAN about its TIP, and that ordering matters - cht_geom's header records that a
/// fan walks centre-first and never closes the last edge, so the point list is authored in the
/// order the fan wants rather than in drawing order.
function cht_rose_point(_cx, _cy, _ang, _len, _wide, _role) {
    var _tx = _cx + cos(_ang) * _len, _ty = _cy + sin(_ang) * _len;
    var _px = -sin(_ang) * _wide, _py = cos(_ang) * _wide;
    var _sx = _cx + cos(_ang) * _len * 0.34, _sy = _cy + sin(_ang) * _len * 0.34;
    return cht_fill([[_tx, _ty], [_sx + _px, _sy + _py], [_cx, _cy], [_sx - _px, _sy - _py]], _role);
}

/// The same point as an OUTLINE. Half a compass card is hollow and half is solid - that alternation
/// is what makes a rose read as engraved rather than as a starburst.
function cht_rose_point_open(_cx, _cy, _ang, _len, _wide, _w, _role) {
    var _tx = _cx + cos(_ang) * _len, _ty = _cy + sin(_ang) * _len;
    var _px = -sin(_ang) * _wide, _py = cos(_ang) * _wide;
    var _sx = _cx + cos(_ang) * _len * 0.34, _sy = _cy + sin(_ang) * _len * 0.34;
    return cht_poly([[_tx, _ty], [_sx + _px, _sy + _py], [_cx, _cy], [_sx - _px, _sy - _py]],
                    true, _w, _role);
}

/// A ring of graduation ticks, every `_every`-th one long.
function cht_rose_ticks(_cx, _cy, _r, _count, _every, _short, _long, _w, _role) {
    var _out = [];
    for (var _i = 0; _i < _count; _i++) {
        var _a = CHT_NORTH + (_i / _count) * CHT_TAU;
        var _l = ((_i % _every) == 0) ? _long : _short;
        array_push(_out, cht_poly([
            [_cx + cos(_a) * _r,        _cy + sin(_a) * _r],
            [_cx + cos(_a) * (_r - _l), _cy + sin(_a) * (_r - _l)]
        ], false, _w, _role));
    }
    return _out;
}

/// A fleur-de-lis, pointing along -y, sized to _len. The traditional north mark, and the single
/// most recognisable piece of furniture a chart can carry.
///
/// Built from three lobes and a banded waist rather than one outline: the silhouette has to survive
/// being 12px tall on a small page, and a single traced outline at that size turns to mud.
/// ⛔ REDRAWN 2026-08-22, AND THE OLD ONE WAS ON THE HERO STORE IMAGE. The first version curled its
/// two side lobes OUTWARD AND UP from a point below the waist, which is a precise description of a
/// pair of horns - and that is exactly what it looked like: a red devil's head sitting in the
/// corner of the flagship chart, on the rose that is the product's default. Nothing mechanical
/// could see it. The rose passed its part count, passed north-is-up, passed distinctness against
/// the other seven, and passed the ink-bounds check.
///
/// A fleur-de-lis reads from three facts, and the old one had none of them: the side lobes hang
/// DOWN at their tips rather than rising, they are FILLED masses rather than open curls, and the
/// band sits low with a tail below it. Built from filled lobes for the same reason the corpus is:
/// at 14px an outline is a smudge and a mass is a shape.
function cht_rose_fleur(_cx, _cy, _len, _w, _role) {
    var _u = _len;
    var _out = [];
    // Central lobe: a lancet, wide at the waist, drawn to a point.
    array_push(_out, cht_fill([
        [_cx, _cy - _u],
        [_cx + _u * 0.16, _cy - _u * 0.44],
        [_cx + _u * 0.09, _cy - _u * 0.16],
        [_cx,             _cy - _u * 0.06],
        [_cx - _u * 0.09, _cy - _u * 0.16],
        [_cx - _u * 0.16, _cy - _u * 0.44]
    ], _role));

    // The two side lobes. Each rises from the waist, arcs OUTWARD, and comes back DOWN to a tip
    // that hangs BELOW where it started - which is the whole difference between a lily and a horn.
    for (var _s = -1; _s <= 1; _s += 2) {
        var _root = [_cx + _s * _u * 0.06, _cy - _u * 0.30];
        var _top  = [_cx + _s * _u * 0.40, _cy - _u * 0.52];
        var _tip  = [_cx + _s * _u * 0.46, _cy - _u * 0.10];
        var _back = [_cx + _s * _u * 0.20, _cy - _u * 0.18];
        var _outer = cht_qbez(_root, [_cx + _s * _u * 0.30, _cy - _u * 0.58], _top, 8);
        var _down  = cht_qbez(_top,  [_cx + _s * _u * 0.54, _cy - _u * 0.34], _tip, 8);
        var _inner = cht_qbez(_tip,  [_cx + _s * _u * 0.30, _cy - _u * 0.16], _back, 8);
        var _lobe = [];
        _lobe = cht_append(_lobe, _outer);
        for (var _i = 1; _i < array_length(_down); _i++)  array_push(_lobe, _down[_i]);
        for (var _i = 1; _i < array_length(_inner); _i++) array_push(_lobe, _inner[_i]);
        array_push(_out, cht_ring_fill(_lobe, _role, undefined, undefined));
    }

    // The band across the waist, and the tail below it. The band is what says fleur-de-lis rather
    // than trefoil; the tail is what stops the whole mark reading as a crown.
    array_push(_out, cht_rect_fill(_cx - _u * 0.30, _cy - _u * 0.10,
                                   _cx + _u * 0.30, _cy - _u * 0.02, _role));
    array_push(_out, cht_fill([
        [_cx, _cy + _u * 0.22],
        [_cx + _u * 0.09, _cy - _u * 0.02],
        [_cx - _u * 0.09, _cy - _u * 0.02]
    ], _role));
    return _out;
}

/// ============================================================================================
/// THE EIGHT ROSES
/// ============================================================================================

/// Four points, one ring, nothing else. For a page that wants the rose to be a mark rather than an
/// ornament - and the only rose here that stays legible below about 24px.
function cht_rs_quarter(_cx, _cy, _r, _w) {
    var _out = [];
    array_push(_out, cht_ring(_cx, _cy, _r, _w, CHT_R_INK));
    for (var _i = 0; _i < 4; _i++) {
        var _a = CHT_NORTH + (_i / 4) * CHT_TAU;
        array_push(_out, cht_rose_point(_cx, _cy, _a, _r * 0.96, _r * 0.15,
                                        (_i == 0) ? CHT_R_ACCENT : CHT_R_MASS));
    }
    array_push(_out, cht_dot(_cx, _cy, _r * 0.055, CHT_R_INK));
    return _out;
}

/// Eight points: four cardinal solid, four intercardinal hollow. The alternation is the whole
/// design and it is what a printed card actually does.
function cht_rs_eight(_cx, _cy, _r, _w) {
    var _out = [];
    array_push(_out, cht_ring(_cx, _cy, _r * 1.04, _w, CHT_R_INK));
    for (var _i = 0; _i < 8; _i++) {
        var _a = CHT_NORTH + (_i / 8) * CHT_TAU;
        var _card = ((_i % 2) == 0);
        if (_card) {
            array_push(_out, cht_rose_point(_cx, _cy, _a, _r, _r * 0.13,
                                            (_i == 0) ? CHT_R_ACCENT : CHT_R_MASS));
        } else {
            array_push(_out, cht_rose_point_open(_cx, _cy, _a, _r * 0.66, _r * 0.10, _w, CHT_R_INK));
        }
    }
    array_push(_out, cht_ring(_cx, _cy, _r * 0.11, _w, CHT_R_INK));
    return _out;
}

/// Sixteen points in three lengths, inside a double ring with half-wind ticks between them.
function cht_rs_sixteen(_cx, _cy, _r, _w) {
    var _out = [];
    array_push(_out, cht_ring(_cx, _cy, _r * 1.08, _w, CHT_R_INK));
    array_push(_out, cht_ring(_cx, _cy, _r * 1.00, _w * 0.55, CHT_R_INK));
    _out = cht_append(_out, cht_rose_ticks(_cx, _cy, _r * 1.00, 32, 4, _r * 0.05, _r * 0.10,
                                           _w * 0.55, CHT_R_HATCH));
    for (var _i = 0; _i < 16; _i++) {
        var _a = CHT_NORTH + (_i / 16) * CHT_TAU;
        if ((_i % 4) == 0) {
            array_push(_out, cht_rose_point(_cx, _cy, _a, _r * 0.94, _r * 0.10,
                                            (_i == 0) ? CHT_R_ACCENT : CHT_R_MASS));
        } else if ((_i % 2) == 0) {
            array_push(_out, cht_rose_point_open(_cx, _cy, _a, _r * 0.62, _r * 0.075, _w, CHT_R_INK));
        } else {
            array_push(_out, cht_poly([[_cx, _cy],
                                       [_cx + cos(_a) * _r * 0.40, _cy + sin(_a) * _r * 0.40]],
                                      false, _w * 0.6, CHT_R_HATCH));
        }
    }
    array_push(_out, cht_dot(_cx, _cy, _r * 0.05, CHT_R_INK));
    return _out;
}

/// The portolan wind rose: thirty-two rhumb lines drawn straight through the circle, which is how
/// a fourteenth-century chart actually organised itself. The rays are the navigation grid, and the
/// rose is just where they meet.
function cht_rs_windrose(_cx, _cy, _r, _w) {
    var _out = [];
    for (var _i = 0; _i < 32; _i++) {
        var _a = CHT_NORTH + (_i / 32) * CHT_TAU;
        var _len = ((_i % 8) == 0) ? _r * 1.20 : (((_i % 4) == 0) ? _r * 1.06 : _r * 0.98);
        var _role = ((_i % 8) == 0) ? CHT_R_INK : CHT_R_HATCH;
        array_push(_out, cht_poly([[_cx, _cy], [_cx + cos(_a) * _len, _cy + sin(_a) * _len]],
                                  false, ((_i % 8) == 0) ? _w : _w * 0.5, _role));
    }
    array_push(_out, cht_ring(_cx, _cy, _r * 0.84, _w * 0.6, CHT_R_INK));
    array_push(_out, cht_ring(_cx, _cy, _r * 0.30, _w * 0.6, CHT_R_INK));
    array_push(_out, cht_rose_point(_cx, _cy, CHT_NORTH, _r * 1.34, _r * 0.09, CHT_R_ACCENT));
    return _out;
}

/// Eight points with a fleur-de-lis for north - the most ornamental rose in the set, and the one
/// most buyers will reach for first.
function cht_rs_fleur(_cx, _cy, _r, _w) {
    var _out = [];
    array_push(_out, cht_ring(_cx, _cy, _r * 1.02, _w, CHT_R_INK));
    array_push(_out, cht_ring(_cx, _cy, _r * 0.94, _w * 0.5, CHT_R_INK));
    for (var _i = 1; _i < 8; _i++) {
        var _a = CHT_NORTH + (_i / 8) * CHT_TAU;
        if ((_i % 2) == 0) array_push(_out, cht_rose_point(_cx, _cy, _a, _r * 0.90, _r * 0.11, CHT_R_MASS));
        else array_push(_out, cht_rose_point_open(_cx, _cy, _a, _r * 0.58, _r * 0.085, _w, CHT_R_INK));
    }
    // North is the fleur, so the north KITE is omitted above rather than drawn under it - two
    // marks stacked on one bearing is the commonest way an ornate rose turns muddy.
    _out = cht_append(_out, cht_rose_fleur(_cx, _cy - _r * 0.18, _r * 0.92, _w, CHT_R_ACCENT));
    array_push(_out, cht_ring(_cx, _cy, _r * 0.10, _w, CHT_R_INK));
    return _out;
}

/// A lodestone needle: a lozenge on a pivot over a graduated ring. Instrument, not ornament - the
/// right rose for a survey page.
function cht_rs_lodestone(_cx, _cy, _r, _w) {
    var _out = [];
    array_push(_out, cht_ring(_cx, _cy, _r, _w, CHT_R_INK));
    _out = cht_append(_out, cht_rose_ticks(_cx, _cy, _r, 24, 6, _r * 0.06, _r * 0.14,
                                           _w * 0.6, CHT_R_HATCH));
    // The needle: the north half solid, the south half hollow - which is how a real card is
    // painted, and it is the only cue that tells the two ends apart.
    array_push(_out, cht_fill([[_cx, _cy - _r * 0.80], [_cx + _r * 0.11, _cy],
                               [_cx, _cy + _r * 0.06], [_cx - _r * 0.11, _cy]], CHT_R_ACCENT));
    array_push(_out, cht_poly([[_cx, _cy + _r * 0.80], [_cx + _r * 0.11, _cy],
                               [_cx, _cy - _r * 0.06], [_cx - _r * 0.11, _cy]],
                              true, _w, CHT_R_INK));
    array_push(_out, cht_ring(_cx, _cy, _r * 0.09, _w, CHT_R_INK));
    array_push(_out, cht_dot(_cx, _cy, _r * 0.035, CHT_R_MASS));
    return _out;
}

/// Concentric graduated rings with a crossed alidade. The densest rose in the set and the one that
/// carries a large page best.
function cht_rs_astrolabe(_cx, _cy, _r, _w) {
    var _out = [];
    array_push(_out, cht_ring(_cx, _cy, _r,        _w,        CHT_R_INK));
    array_push(_out, cht_ring(_cx, _cy, _r * 0.90, _w * 0.5,  CHT_R_INK));
    array_push(_out, cht_ring(_cx, _cy, _r * 0.62, _w * 0.5,  CHT_R_INK));
    array_push(_out, cht_ring(_cx, _cy, _r * 0.34, _w * 0.5,  CHT_R_INK));
    _out = cht_append(_out, cht_rose_ticks(_cx, _cy, _r * 0.90, 72, 6, _r * 0.05, _r * 0.13,
                                           _w * 0.45, CHT_R_HATCH));
    _out = cht_append(_out, cht_rose_ticks(_cx, _cy, _r * 0.62, 24, 3, _r * 0.04, _r * 0.08,
                                           _w * 0.45, CHT_R_HATCH));
    // The alidade: a straight rule across the whole instrument with a sight vane at each end.
    var _a = CHT_NORTH + degtorad(24);
    array_push(_out, cht_poly([[_cx - cos(_a) * _r * 0.96, _cy - sin(_a) * _r * 0.96],
                               [_cx + cos(_a) * _r * 0.96, _cy + sin(_a) * _r * 0.96]],
                              false, _w * 0.9, CHT_R_INK));
    for (var _s = -1; _s <= 1; _s += 2) {
        var _vx = _cx + cos(_a) * _r * 0.80 * _s, _vy = _cy + sin(_a) * _r * 0.80 * _s;
        array_push(_out, cht_rect_poly(_vx - _r * 0.055, _vy - _r * 0.055,
                                       _vx + _r * 0.055, _vy + _r * 0.055, _w * 0.7, CHT_R_INK));
    }
    array_push(_out, cht_rose_point(_cx, _cy, CHT_NORTH, _r * 0.30, _r * 0.07, CHT_R_ACCENT));
    array_push(_out, cht_dot(_cx, _cy, _r * 0.045, CHT_R_MASS));
    return _out;
}

/// A mariner's card: thirty-two points of the compass in four lengths, alternating solid and
/// hollow, on a lettered ring. The busiest silhouette here and the most "printed" looking.
function cht_rs_mariner(_cx, _cy, _r, _w) {
    var _out = [];
    array_push(_out, cht_ring(_cx, _cy, _r * 1.10, _w * 0.9, CHT_R_INK));
    array_push(_out, cht_ring(_cx, _cy, _r * 1.02, _w * 0.45, CHT_R_INK));
    _out = cht_append(_out, cht_rose_ticks(_cx, _cy, _r * 1.02, 32, 8, _r * 0.045, _r * 0.09,
                                           _w * 0.45, CHT_R_HATCH));
    for (var _i = 0; _i < 32; _i++) {
        var _a = CHT_NORTH + (_i / 32) * CHT_TAU;
        var _len, _wide;
        if ((_i % 8) == 0)      { _len = _r * 0.98; _wide = _r * 0.095; }
        else if ((_i % 4) == 0) { _len = _r * 0.74; _wide = _r * 0.075; }
        else if ((_i % 2) == 0) { _len = _r * 0.52; _wide = _r * 0.055; }
        else                    { _len = _r * 0.34; _wide = _r * 0.040; }
        if ((_i % 2) == 0) {
            array_push(_out, cht_rose_point(_cx, _cy, _a, _len, _wide,
                                            (_i == 0) ? CHT_R_ACCENT : CHT_R_MASS));
        } else {
            array_push(_out, cht_rose_point_open(_cx, _cy, _a, _len, _wide, _w * 0.55, CHT_R_INK));
        }
    }
    array_push(_out, cht_ring(_cx, _cy, _r * 0.12, _w * 0.8, CHT_R_INK));
    array_push(_out, cht_dot(_cx, _cy, _r * 0.05, CHT_R_MASS));
    return _out;
}

/// The rose dispatcher. _r is the rose's OUTER radius in page pixels; _w defaults to a proportion
/// of it, so a caller only ever has to supply a size.
function cht_rose(_id, _cx, _cy, _r, _w) {
    if (is_undefined(_w)) _w = max(0.6, _r * 0.030);
    switch (_id) {
        case "quarter":   return cht_rs_quarter(_cx, _cy, _r, _w);
        case "eight":     return cht_rs_eight(_cx, _cy, _r, _w);
        case "sixteen":   return cht_rs_sixteen(_cx, _cy, _r, _w);
        case "windrose":  return cht_rs_windrose(_cx, _cy, _r, _w);
        case "fleur":     return cht_rs_fleur(_cx, _cy, _r, _w);
        case "lodestone": return cht_rs_lodestone(_cx, _cy, _r, _w);
        case "astrolabe": return cht_rs_astrolabe(_cx, _cy, _r, _w);
        case "mariner":   return cht_rs_mariner(_cx, _cy, _r, _w);
    }
    return [];
}

/// ============================================================================================
/// THE SIX CARTOUCHES
///
/// A cartouche is the frame the region's title sits in. It is fitted to a RECTANGLE and returns
/// only the frame - the text is a label (cht_label) drawn by cht_render, because this file is
/// geometry and knows nothing about fonts.
///
/// Every one of them leaves the interior rectangle clear, which is stated because it is the
/// contract the label layer depends on: cht_cartouche_inset() reports how far in the text must
/// start, per style, and cht_selftest asserts no frame part intrudes past it.
/// ============================================================================================

function cht_cartouche_ids() {
    return ["rule", "double", "scroll", "strapwork", "banderole", "shield"];
}

function cht_cartouche_name(_id) {
    switch (_id) {
        case "rule":      return "Plain Rule";
        case "double":    return "Double Rule";
        case "scroll":    return "Scrolled";
        case "strapwork": return "Strapwork";
        case "banderole": return "Banderole";
        case "shield":    return "Shield";
    }
    return "Unknown";
}

/// How far inside the cartouche rectangle the TEXT must start, as a fraction of the box height.
/// The label layer asks; it never guesses.
function cht_cartouche_inset(_id) {
    switch (_id) {
        case "scroll":    return 0.30;
        case "strapwork": return 0.26;
        case "banderole": return 0.34;
        case "shield":    return 0.22;
    }
    return 0.16;
}

function cht_cartouche(_id, _x0, _y0, _x1, _y1, _w) {
    if (is_undefined(_w)) _w = max(0.7, (_y1 - _y0) * 0.035);
    var _hh = (_y1 - _y0);
    var _out = [];

    switch (_id) {

        case "double":
            array_push(_out, cht_rect_poly(_x0, _y0, _x1, _y1, _w, CHT_R_INK));
            array_push(_out, cht_rect_poly(_x0 + _hh * 0.09, _y0 + _hh * 0.09,
                                           _x1 - _hh * 0.09, _y1 - _hh * 0.09,
                                           _w * 0.5, CHT_R_INK));
            break;

        case "scroll": {
            // A panel whose ends roll up. The two rolls are the identification; the panel between
            // them is deliberately plain so the title has somewhere quiet to sit.
            var _r = _hh * 0.34;
            array_push(_out, cht_poly([[_x0 + _r, _y0], [_x1 - _r, _y0]], false, _w, CHT_R_INK));
            array_push(_out, cht_poly([[_x0 + _r, _y1], [_x1 - _r, _y1]], false, _w, CHT_R_INK));
            for (var _s = 0; _s < 2; _s++) {
                var _cx = (_s == 0) ? (_x0 + _r) : (_x1 - _r);
                var _dir = (_s == 0) ? 1 : -1;
                // The roll: an outer curl and an inner spiral turn.
                array_push(_out, cht_poly(cht_arc_pts(_cx, (_y0 + _y1) * 0.5, _r,
                                                      (_s == 0) ? (pi * 0.5) : (pi * 1.5),
                                                      (_s == 0) ? (pi * 1.5) : (pi * 2.5), 14),
                                          false, _w, CHT_R_INK));
                array_push(_out, cht_ring(_cx - _dir * _r * 0.18, (_y0 + _y1) * 0.5, _r * 0.30,
                                          _w * 0.7, CHT_R_INK));
            }
        } break;

        case "strapwork": {
            // Interlaced bands with pierced corners - the sixteenth-century engraved look.
            var _k = _hh * 0.22;
            array_push(_out, cht_rect_poly(_x0, _y0, _x1, _y1, _w, CHT_R_INK));
            array_push(_out, cht_rect_poly(_x0 + _k * 0.45, _y0 + _k * 0.45,
                                           _x1 - _k * 0.45, _y1 - _k * 0.45, _w * 0.55, CHT_R_INK));
            var _cs = [[_x0, _y0], [_x1, _y0], [_x1, _y1], [_x0, _y1]];
            for (var _i = 0; _i < 4; _i++) {
                array_push(_out, cht_ring(_cs[_i][0], _cs[_i][1], _k * 0.42, _w * 0.8, CHT_R_INK));
                array_push(_out, cht_dot(_cs[_i][0], _cs[_i][1], _k * 0.13, CHT_R_MASS));
            }
            // Two straps crossing each long side, which is what "interlaced" reads as at page size.
            for (var _i = 1; _i <= 2; _i++) {
                var _x = lerp(_x0, _x1, _i / 3);
                array_push(_out, cht_poly([[_x - _k * 0.3, _y0 - _k * 0.25],
                                           [_x + _k * 0.3, _y0 + _k * 0.25]], false, _w * 0.7, CHT_R_INK));
                array_push(_out, cht_poly([[_x - _k * 0.3, _y1 - _k * 0.25],
                                           [_x + _k * 0.3, _y1 + _k * 0.25]], false, _w * 0.7, CHT_R_INK));
            }
        } break;

        case "banderole": {
            // A ribbon with swallow-tailed ends and a fold on each side. The tails hang BELOW the
            // box, so the label layer's inset only has to clear the folds.
            var _t = _hh * 0.42;
            array_push(_out, cht_poly([
                [_x0 + _t, _y0], [_x1 - _t, _y0], [_x1 - _t, _y1], [_x0 + _t, _y1]
            ], true, _w, CHT_R_INK));
            for (var _s = 0; _s < 2; _s++) {
                var _ix = (_s == 0) ? (_x0 + _t) : (_x1 - _t);
                var _ox = (_s == 0) ? _x0 : _x1;
                var _mid = (_y0 + _y1) * 0.5;
                array_push(_out, cht_poly([
                    [_ix, _y0 - _t * 0.28], [_ox, _y0 + _t * 0.10],
                    [_ox + (_s == 0 ? 1 : -1) * _t * 0.42, _mid],
                    [_ox, _y1 - _t * 0.10], [_ix, _y1 + _t * 0.28]
                ], false, _w, CHT_R_INK));
                array_push(_out, cht_poly([[_ix, _y0 - _t * 0.28], [_ix, _y1 + _t * 0.28]],
                                          false, _w * 0.6, CHT_R_HATCH));
            }
        } break;

        case "shield": {
            // A heater shield: straight shoulders, curved flanks, a point at the base. Fitted to
            // the box, so a wide box gives a broad shield and a tall one a narrow shield.
            var _cx = (_x0 + _x1) * 0.5;
            var _pts = [[_x0, _y0], [_x1, _y0]];
            var _right = cht_qbez([_x1, _y0 + _hh * 0.10], [_x1, _y1 - _hh * 0.22], [_cx, _y1], 12);
            for (var _i = 0; _i < array_length(_right); _i++) array_push(_pts, _right[_i]);
            var _left = cht_qbez([_cx, _y1], [_x0, _y1 - _hh * 0.22], [_x0, _y0 + _hh * 0.10], 12);
            for (var _i = 0; _i < array_length(_left); _i++) array_push(_pts, _left[_i]);
            array_push(_out, cht_poly(_pts, true, _w, CHT_R_INK));
            array_push(_out, cht_poly([[_x0 + _hh * 0.10, _y0 + _hh * 0.14],
                                       [_x1 - _hh * 0.10, _y0 + _hh * 0.14]],
                                      false, _w * 0.5, CHT_R_HATCH));
        } break;

        default:
            array_push(_out, cht_rect_poly(_x0, _y0, _x1, _y1, _w, CHT_R_INK));
            break;
    }
    return _out;
}
