{
  "$GMScript": "v1",
  "%Name": "cht_marks",
  "isCompatibility": false,
  "isDnD": false,
  "name": "cht_marks",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}