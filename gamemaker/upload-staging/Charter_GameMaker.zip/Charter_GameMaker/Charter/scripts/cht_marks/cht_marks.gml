/// ============================================================================================
/// CHARTER - cht_marks: THE CORPUS. 44 landmark marks, drawn in line-work, in six families.
///
/// This is the product. Everything else in the package exists to put these on a page.
///
/// -- WHAT A MARK IS ----------------------------------------------------------------------------
/// A mark is a FUNCTION that returns an array of geometry parts (see cht_geom). It draws nothing.
/// There is no sprite, no atlas and no texture page anywhere in this package - `sprites/` does not
/// exist - so a mark is resolution-independent, recolourable by role, and re-inked by whichever
/// hand (cht_hands) the chart is written in.
///
/// -- THE COORDINATE CONTRACT -------------------------------------------------------------------
/// Every mark is authored in a unit box: x and y in [-0.5, 0.5], y DOWN, origin at the mark's
/// optical centre. The macros below are the contract, and they are ARITHMETIC, so they can be
/// checked rather than believed:
///
///     (CHT_MARK_BOX + CHT_HAND_GROW) * CHT_MARK_FIT  <=  CHT_MARK_CELL
///     (0.50         + 0.060)         * 0.86          =   0.4816  <=  0.50
///
/// Internal_Ops/check_marks.js reads those numbers OUT OF THIS FILE and re-does that arithmetic;
/// cht_selftest re-does it again in-engine against real emitted geometry, for every mark in every
/// hand in every state. Neither carries its own copy of the numbers, because a checker holding a
/// private copy of the value it is checking is how the two drift apart silently.
///
/// ⛔ THE CONTRACT USED TO READ `BOX * FIT + JITTER = 0.460` AND IT WAS WRONG - IT COUNTED ONLY
/// HALF OF WHAT A HAND ADDS. Found 2026-08-22 while writing cht_render, by asking what the pipeline
/// actually does rather than what the arithmetic said. An ink hand displaces a point by jitter
/// (<= CHT_JITTER_MAX) AND, on the `field` hand, extends the ends of every open stroke past their
/// endpoints by `overshoot` stroke widths - and the second term is the LARGER of the two:
/// CHT_W_HEAVY 0.045 x wscale 1.35 x overshoot 1.8 = 0.109, against a jitter of 0.030. The old
/// arithmetic omitted it entirely, so the worst authored mark (`outpost`, reach 0.500) would have
/// been placed at (0.500 + 0.030 + 0.109) x 0.86 = 0.549 against a cell half-extent of 0.50 - a
/// mark overlapping its neighbour, on one hand only, invisible to every check that existed.
///
/// ⚠️ AND NOTE WHICH NUMBER WAS CHANGED, BECAUSE THE OTHER MOVE WAS AVAILABLE AND IS FORBIDDEN.
/// CHT_MARK_BOX is untouched and no mark was redrawn. What changed is that the FLOURISH is now
/// bounded by the contract instead of the contract by the flourish: cht_hand_apply clamps jitter +
/// overshoot to CHT_HAND_GROW. Raising CHT_MARK_BOX or CHT_MARK_CELL to fit what got drawn is the
/// move master CLAUDE.md §4.2b names and forbids, and it was never on the table.
///
/// ⛔ CHT_MARK_BOX IS A DISC, NOT A SQUARE. The extent test is hypot(x, y) <= BOX, so a mark may
/// not put a point at (0.45, 0.45). That is deliberate: a mark is placed at an arbitrary rotation
/// on a chart, and a square budget would let a corner swing outside its cell when rotated. It also
/// means WIDE marks must be LOW - `farmstead` reaches x = +-0.45 and is only 0.20 tall for exactly
/// this reason.
///
/// ⛔ AND WHEN THE CHECKER REPORTS A VIOLATION, REDRAW THE MARK. Do not raise CHT_MARK_BOX to
/// whatever got drawn. The limit was set in Internal_Ops/Motif_Corpus.md §2 before any geometry
/// existed, precisely so it could not later be negotiated by the thing it constrains.
///
/// -- THE ACCEPTANCE CRITERION ------------------------------------------------------------------
/// Every mark carries a 14px SILHOUETTE NOTE in Motif_Corpus.md §3, and that note is the test, not
/// decoration: filled solid at 14px and shown unlabelled, no mark may be confusable with another.
/// Three rules fall out and they constrain the geometry below:
///   1. the outermost contour carries the identification; hatching is always the SECOND read
///   2. at most three levels of detail - contour, one structural line, texture
///   3. distinguish by SHAPE, never by size or by count alone
/// Motif_Corpus.md §4 names the ten pairs that would collapse if drawn naively, and the specific
/// separation each one uses. Read it before editing a mark.
///
/// -- ROLES -------------------------------------------------------------------------------------
/// Five, and no more. Five roles is what makes 528 mark renderings look like ONE product rather
/// than 528 decisions. cht_pages binds them to actual colours per parchment palette.
/// ============================================================================================

#macro CHT_MARK_BOX   0.50    // authored centre-line budget: hypot(x,y) may not exceed this
#macro CHT_MARK_FIT   0.86    // scale cht_place_mark applies when putting a mark on the chart
#macro CHT_JITTER_MAX 0.030   // largest displacement any ink hand may add (the `field` hand)
#macro CHT_HAND_GROW  0.060   // TOTAL radial growth a hand may add: jitter PLUS stroke overshoot
#macro CHT_MARK_CELL  0.50    // half-extent a PLACED mark may occupy on the chart

/// Stroke weights, in mark-box units, authored as HERO weights (a mark drawn large).
/// cht_place_mark scales them by scale/CHT_SC_MARK, and cht_render applies a 0.55px floor so a
/// 14px mark's strokes do not vanish. Constant PROPORTION plus a pixel floor - not constant
/// screen-space width, which this wing measured as making small marks render as solid blobs.
#macro CHT_W_HEAVY 0.045
#macro CHT_W_MID   0.030
#macro CHT_W_FINE  0.018
#macro CHT_W_HAIR  0.011

/// The scale a mark's authored weights assume. cht_place_mark divides by this.
#macro CHT_SC_MARK 1.0

#macro CHT_R_INK    "ink"      // the pen line
#macro CHT_R_MASS   "mass"     // a solid ink mass (a roof, a shadowed mouth)
#macro CHT_R_HATCH  "hatch"    // texture: hatching, stipple, flutes
#macro CHT_R_VOID   "void"     // page showing through, knocked out of a mass
#macro CHT_R_ACCENT "accent"   // rubrication: a light, a spark, a warning

/// ============================================================================================
/// SHARED OUTLINE BUILDERS
///
/// These return POINT LISTS, never parts. That is deliberate: every mark below still calls the
/// cht_* primitives itself, so the mark's geometry is readable in one place and the static op
/// check in check_marks.js stays meaningful. A helper that returned finished parts would hide
/// both.
/// ============================================================================================

/// A gabled building outline, closed: two eaves, two wall feet, one ridge.
function cht_pts_gable(_cx, _cy, _w, _h, _roof) {
    var _hw = _w * 0.5;
    return [
        [_cx - _hw, _cy], [_cx - _hw, _cy - _h], [_cx, _cy - _h - _roof],
        [_cx + _hw, _cy - _h], [_cx + _hw, _cy]
    ];
}

/// A crenellated tower outline, closed. _merlons is the number of raised teeth on the top edge.
function cht_pts_tower(_cx, _cy, _w, _h, _merlons) {
    var _hw = _w * 0.5;
    var _step = _w / (_merlons * 2 - 1);
    var _tooth = _h * 0.16;
    var _out = [[_cx - _hw, _cy], [_cx - _hw, _cy - _h]];
    for (var _i = 0; _i < _merlons * 2 - 1; _i++) {
        var _x0 = _cx - _hw + _i * _step;
        var _up = (_i % 2 == 0);
        var _y = _cy - _h - (_up ? _tooth : 0);
        array_push(_out, [_x0, _y], [_x0 + _step, _y]);
    }
    array_push(_out, [_cx + _hw, _cy - _h], [_cx + _hw, _cy]);
    return _out;
}

/// An irregular lobed contour - a hill, a canopy, a spoil heap. Deterministic from _seed, because
/// nothing in this package may look different on two consecutive frames.
function cht_pts_lobed(_cx, _cy, _rx, _ry, _n, _amp, _seed) {
    var _st = cht_rng(_seed);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _a = (_i / _n) * CHT_TAU;
        var _k = 1 + (cht_rng_next(_st) - 0.5) * 2 * _amp;
        _out[_i] = [_cx + cos(_a) * _rx * _k, _cy + sin(_a) * _ry * _k];
    }
    return _out;
}

/// The top half of a mound: a flattened arc from left foot to right foot, ends ON the base line.
function cht_pts_mound(_cx, _cy, _rx, _ry) {
    return cht_arc_pts(_cx, _cy, 1, pi, CHT_TAU, 18 * 0 + 18)
        ; // placeholder replaced below - see cht_pts_mound_xy
}

/// A mound with independent x and y radii. cht_arc_pts is circular, so an ellipse needs its own
/// walk; this is that walk, from the left foot round the top to the right foot.
function cht_pts_mound_xy(_cx, _cy, _rx, _ry, _n) {
    var _out = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _a = pi + (_i / _n) * pi;
        _out[_i] = [_cx + cos(_a) * _rx, _cy + sin(_a) * _ry];
    }
    return _out;
}

/// A round-topped slab (a headstone): straight sides, a semicircular cap.
function cht_pts_slab_round(_cx, _cy, _w, _h) {
    var _hw = _w * 0.5;
    var _cap = cht_pts_mound_xy(_cx, _cy - _h + _hw, _hw, _hw, 10);
    var _out = [[_cx - _hw, _cy]];
    for (var _i = 0; _i <= 10; _i++) array_push(_out, _cap[_i]);
    array_push(_out, [_cx + _hw, _cy]);
    return _out;
}

/// ============================================================================================
/// THE CORPUS - ids, names, families
/// ============================================================================================

/// The 44 ids, in family order. Boundaries: 8 / 15 / 21 / 28 / 36 / 44.
function cht_mark_ids() {
    return [
        "hamlet", "village", "town", "city", "keep", "citadel", "outpost", "farmstead",
        "ruin", "column", "barrow", "menhir", "circle", "arch", "wreck",
        "shrine", "chapel", "abbey", "grave", "ossuary", "idol",
        "bridge", "ford", "gate", "pass", "stair", "tunnel", "ferry",
        "cave", "spring", "falls", "gorge", "crater", "geyser", "grove", "mire",
        "mine", "quarry", "kiln", "mill", "forge", "saltern", "weir", "pharos"
    ];
}

function cht_family_ids() {
    return ["settlement", "relic", "sacred", "passage", "wild", "works"];
}

/// The family of the mark at corpus INDEX _i. Boundaries are declared here and re-checked against
/// Motif_Corpus.md §3 by check_marks.js - the doc and the code are not allowed to drift.
function cht_mark_family(_i) {
    if (_i < 8) return "settlement";
    if (_i < 15) return "relic";
    if (_i < 21) return "sacred";
    if (_i < 28) return "passage";
    if (_i < 36) return "wild";
    if (_i < 44) return "works";
    return "settlement";
}

/// Human-readable name, for labels and for the buyer's own UI.
function cht_mark_name(_id) {
    switch (_id) {
        case "hamlet":    return "Hamlet";
        case "village":   return "Village";
        case "town":      return "Town";
        case "city":      return "City";
        case "keep":      return "Keep";
        case "citadel":   return "Citadel";
        case "outpost":   return "Outpost";
        case "farmstead": return "Farmstead";
        case "ruin":      return "Ruin";
        case "column":    return "Broken Column";
        case "barrow":    return "Barrow";
        case "menhir":    return "Standing Stone";
        case "circle":    return "Stone Circle";
        case "arch":      return "Fallen Arch";
        case "wreck":     return "Wreck";
        case "shrine":    return "Shrine";
        case "chapel":    return "Chapel";
        case "abbey":     return "Abbey";
        case "grave":     return "Grave";
        case "ossuary":   return "Ossuary";
        case "idol":      return "Idol";
        case "bridge":    return "Bridge";
        case "ford":      return "Ford";
        case "gate":      return "Gate";
        case "pass":      return "Pass";
        case "stair":     return "Cut Stair";
        case "tunnel":    return "Tunnel";
        case "ferry":     return "Ferry";
        case "cave":      return "Cave";
        case "spring":    return "Spring";
        case "falls":     return "Falls";
        case "gorge":     return "Gorge";
        case "crater":    return "Crater";
        case "geyser":    return "Geyser";
        case "grove":     return "Grove";
        case "mire":      return "Mire";
        case "mine":      return "Mine";
        case "quarry":    return "Quarry";
        case "kiln":      return "Kiln";
        case "mill":      return "Mill";
        case "forge":     return "Forge";
        case "saltern":   return "Saltern";
        case "weir":      return "Weir";
        case "pharos":    return "Pharos";
    }
    return "Unknown";
}

/// The dispatcher. Returns the mark's parts in the authoring unit box.
function cht_mark(_id) {
    switch (_id) {
        case "hamlet":    return cht_mk_hamlet();
        case "village":   return cht_mk_village();
        case "town":      return cht_mk_town();
        case "city":      return cht_mk_city();
        case "keep":      return cht_mk_keep();
        case "citadel":   return cht_mk_citadel();
        case "outpost":   return cht_mk_outpost();
        case "farmstead": return cht_mk_farmstead();
        case "ruin":      return cht_mk_ruin();
        case "column":    return cht_mk_column();
        case "barrow":    return cht_mk_barrow();
        case "menhir":    return cht_mk_menhir();
        case "circle":    return cht_mk_circle();
        case "arch":      return cht_mk_arch();
        case "wreck":     return cht_mk_wreck();
        case "shrine":    return cht_mk_shrine();
        case "chapel":    return cht_mk_chapel();
        case "abbey":     return cht_mk_abbey();
        case "grave":     return cht_mk_grave();
        case "ossuary":   return cht_mk_ossuary();
        case "idol":      return cht_mk_idol();
        case "bridge":    return cht_mk_bridge();
        case "ford":      return cht_mk_ford();
        case "gate":      return cht_mk_gate();
        case "pass":      return cht_mk_pass();
        case "stair":     return cht_mk_stair();
        case "tunnel":    return cht_mk_tunnel();
        case "ferry":     return cht_mk_ferry();
        case "cave":      return cht_mk_cave();
        case "spring":    return cht_mk_spring();
        case "falls":     return cht_mk_falls();
        case "gorge":     return cht_mk_gorge();
        case "crater":    return cht_mk_crater();
        case "geyser":    return cht_mk_geyser();
        case "grove":     return cht_mk_grove();
        case "mire":      return cht_mk_mire();
        case "mine":      return cht_mk_mine();
        case "quarry":    return cht_mk_quarry();
        case "kiln":      return cht_mk_kiln();
        case "mill":      return cht_mk_mill();
        case "forge":     return cht_mk_forge();
        case "saltern":   return cht_mk_saltern();
        case "weir":      return cht_mk_weir();
        case "pharos":    return cht_mk_pharos();
    }
    return [];
}

/// Place a mark from its authoring box onto the chart at (_cx,_cy) at _scale, in mark-box units.
/// Authored weights are HERO weights, so the weight scale is _scale relative to CHT_SC_MARK.
function cht_place_mark(_parts, _cx, _cy, _scale, _rot, _map) {
    return cht_place(_parts, _cx, _cy, _scale * CHT_MARK_FIT, _rot,
                     (_scale * CHT_MARK_FIT) / CHT_SC_MARK, _map);
}

/// ============================================================================================
/// FAMILY 1 - SETTLEMENT (8). Places people live.
///
/// The corpus's hardest cluster is hamlet/village/town/city, and Motif_Corpus.md §4 resolves it by
/// four DIFFERENT OUTER CONTOURS - low-wide, spiked, domed, crowned - never by counting roofs,
/// which is invisible at 14px.
/// ============================================================================================

/// LOW AND WIDE: a shallow saw-tooth, the flattest mark in the family.
function cht_mk_hamlet() {
    var _p = [];
    array_push(_p, cht_poly(cht_pts_gable(-0.28, 0.30, 0.20, 0.10, 0.10), true, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_poly(cht_pts_gable( 0.00, 0.30, 0.24, 0.12, 0.11), true, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_poly(cht_pts_gable( 0.28, 0.30, 0.20, 0.09, 0.10), true, CHT_W_MID, CHT_R_INK));
    // The roofs are massed so the silhouette reads as a saw-tooth and not as three empty boxes.
    array_push(_p, cht_fill([[-0.38, 0.20], [-0.28, 0.10], [-0.18, 0.20]], CHT_R_MASS));
    array_push(_p, cht_fill([[-0.12, 0.18], [0.00, 0.07], [0.12, 0.18]], CHT_R_MASS));
    array_push(_p, cht_fill([[0.18, 0.21], [0.28, 0.11], [0.38, 0.21]], CHT_R_MASS));
    return _p;
}

/// SPIKED: one vertical stroke breaking a low mass. The spire IS the identification.
function cht_mk_village() {
    var _p = [];
    array_push(_p, cht_poly(cht_pts_gable(-0.27, 0.30, 0.22, 0.11, 0.10), true, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_poly(cht_pts_gable( 0.27, 0.30, 0.22, 0.11, 0.10), true, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_fill([[-0.38, 0.19], [-0.27, 0.09], [-0.16, 0.19]], CHT_R_MASS));
    array_push(_p, cht_fill([[0.16, 0.19], [0.27, 0.09], [0.38, 0.19]], CHT_R_MASS));
    // Tower and spire: the spire is a filled mass so it survives being reduced to a silhouette.
    array_push(_p, cht_rect_poly(-0.075, 0.30, 0.075, -0.14, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_fill([[-0.095, -0.14], [0.00, -0.44], [0.095, -0.14]], CHT_R_MASS));
    array_push(_p, cht_dot(0.00, -0.46, 0.022, CHT_R_INK));
    return _p;
}

/// DOMED: a half-round cap over a broken base. The wall arc is OPEN at the front, so the mark
/// reads as a dome rather than as `city`'s closed ring.
function cht_mk_town() {
    var _p = [];
    array_push(_p, cht_arc(0.00, 0.24, 0.40, pi * 1.06, CHT_TAU - pi * 0.06, CHT_W_HEAVY, CHT_R_INK));
    array_push(_p, cht_poly(cht_pts_gable(-0.16, 0.24, 0.18, 0.10, 0.09), true, CHT_W_FINE, CHT_R_INK));
    array_push(_p, cht_poly(cht_pts_gable( 0.16, 0.24, 0.18, 0.10, 0.09), true, CHT_W_FINE, CHT_R_INK));
    array_push(_p, cht_fill([[-0.25, 0.14], [-0.16, 0.05], [-0.07, 0.14]], CHT_R_MASS));
    array_push(_p, cht_fill([[0.07, 0.14], [0.16, 0.05], [0.25, 0.14]], CHT_R_MASS));
    array_push(_p, cht_poly([[-0.40, 0.24], [0.40, 0.24]], false, CHT_W_MID, CHT_R_INK));
    return _p;
}

/// CROWNED: a closed ring with regular notches on top. Contrast `town`, which is open.
function cht_mk_city() {
    var _p = [];
    array_push(_p, cht_ring(0.00, 0.00, 0.36, CHT_W_HEAVY, CHT_R_INK));
    array_push(_p, cht_ring(0.00, 0.00, 0.29, CHT_W_HAIR, CHT_R_HATCH));
    // Six wall towers ON the ring. A loop, so check_marks.js reports this mark's op count as a
    // LOWER BOUND and says so rather than exempting it.
    for (var _i = 0; _i < 6; _i++) {
        var _a = -pi * 0.5 + (_i / 6) * CHT_TAU;
        var _cx = cos(_a) * 0.36, _cy = sin(_a) * 0.36;
        array_push(_p, cht_fill([
            [_cx - 0.055, _cy + 0.055], [_cx - 0.055, _cy - 0.055],
            [_cx + 0.055, _cy - 0.055], [_cx + 0.055, _cy + 0.055]
        ], CHT_R_MASS));
    }
    // The gate: a void knocked out of the ring at the bottom, so the crown reads as a wall.
    array_push(_p, cht_fill([[-0.07, 0.40], [-0.07, 0.28], [0.07, 0.28], [0.07, 0.40]], CHT_R_VOID));
    array_push(_p, cht_arc(0.00, 0.30, 0.07, pi, CHT_TAU, CHT_W_MID, CHT_R_INK));
    return _p;
}

/// BLOCKY: a solid rectangle with a toothed top edge, one mass, on a low motte.
function cht_mk_keep() {
    var _p = [];
    array_push(_p, cht_ring_fill(cht_pts_mound_xy(0.00, 0.30, 0.38, 0.12, 16), CHT_R_HATCH, 0.00, 0.32));
    array_push(_p, cht_poly(cht_pts_mound_xy(0.00, 0.30, 0.38, 0.12, 16), false, CHT_W_FINE, CHT_R_INK));
    array_push(_p, cht_poly(cht_pts_tower(0.00, 0.28, 0.34, 0.46, 3), true, CHT_W_HEAVY, CHT_R_INK));
    array_push(_p, cht_fill([[-0.05, 0.28], [-0.05, 0.14], [0.05, 0.14], [0.05, 0.28]], CHT_R_MASS));
    array_push(_p, cht_fill([[-0.11, 0.02], [-0.11, -0.08], [-0.04, -0.08], [-0.04, 0.02]], CHT_R_MASS));
    array_push(_p, cht_fill([[0.04, 0.02], [0.04, -0.08], [0.11, -0.08], [0.11, 0.02]], CHT_R_MASS));
    return _p;
}

/// STEPPED TRIANGLE: a staircase profile climbing left to right, on a crag.
function cht_mk_citadel() {
    var _p = [];
    array_push(_p, cht_poly([[-0.38, 0.30], [-0.28, 0.20], [-0.06, 0.14], [0.14, -0.02],
                             [0.32, -0.06], [0.38, 0.30]], true, CHT_W_FINE, CHT_R_INK));
    array_push(_p, cht_poly(cht_pts_tower(-0.22, 0.20, 0.20, 0.20, 2), true, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_poly(cht_pts_tower( 0.02, 0.10, 0.22, 0.26, 2), true, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_poly(cht_pts_tower( 0.24, -0.04, 0.18, 0.26, 2), true, CHT_W_MID, CHT_R_INK));
    // Crag hatching, one direction only - the crag must not compete with the stepped silhouette.
    for (var _i = 0; _i < 5; _i++) {
        var _x = -0.32 + _i * 0.14;
        array_push(_p, cht_poly([[_x, 0.30], [_x + 0.07, 0.20]], false, CHT_W_HAIR, CHT_R_HATCH));
    }
    return _p;
}

/// FLAGGED: a small box with a pennant off the top-right. The pennant is the identification.
function cht_mk_outpost() {
    var _p = [];
    array_push(_p, cht_rect_poly(-0.32, 0.32, 0.20, -0.02, CHT_W_MID, CHT_R_INK));
    // Sharpened palisade stakes along the top edge.
    for (var _i = 0; _i < 7; _i++) {
        var _x = -0.32 + _i * (0.52 / 6);
        array_push(_p, cht_poly([[_x, -0.02], [_x, -0.10], [_x + 0.026, -0.02]], false, CHT_W_FINE, CHT_R_INK));
    }
    array_push(_p, cht_poly([[0.30, 0.32], [0.30, -0.40]], false, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_fill([[0.30, -0.40], [0.30, -0.22], [0.10, -0.31]], CHT_R_MASS));
    array_push(_p, cht_poly([[-0.32, 0.32], [0.20, 0.32]], false, CHT_W_HEAVY, CHT_R_INK));
    return _p;
}

/// A LONG LOW BAR with a bump - the widest aspect in the corpus, and therefore the shortest.
/// It reaches x = +-0.45, so its height is capped at 0.20 by the disc budget (see the header).
function cht_mk_farmstead() {
    var _p = [];
    array_push(_p, cht_poly([[-0.45, 0.20], [-0.45, 0.02], [-0.30, -0.09], [-0.15, 0.02],
                             [-0.15, 0.20]], true, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_fill([[-0.45, 0.02], [-0.30, -0.09], [-0.15, 0.02]], CHT_R_MASS));
    array_push(_p, cht_rect_poly(-0.15, 0.20, 0.16, 0.04, CHT_W_MID, CHT_R_INK));
    // Furrows: the field, ruled. Regular, because a ploughed field is regular.
    for (var _i = 0; _i < 5; _i++) {
        var _y = 0.06 + _i * 0.035;
        array_push(_p, cht_poly([[0.20, _y], [0.45, _y]], false, CHT_W_HAIR, CHT_R_HATCH));
    }
    return _p;
}

/// ============================================================================================
/// FAMILY 2 - RELIC (7). What is left of them.
/// ============================================================================================

/// TWO UNEVEN PILLARS, no capital, tops torn. Contrast `column`, which has a wide cap.
function cht_mk_ruin() {
    var _p = [];
    array_push(_p, cht_poly([[-0.32, 0.30], [-0.32, -0.18], [-0.24, -0.28], [-0.16, -0.12],
                             [-0.10, -0.22], [-0.10, 0.30]], true, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_poly([[0.06, 0.30], [0.06, 0.02], [0.14, -0.10], [0.20, 0.04],
                             [0.26, 0.30]], true, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_fill([[0.30, 0.30], [0.30, 0.22], [0.38, 0.22], [0.38, 0.30]], CHT_R_MASS));
    array_push(_p, cht_poly([[-0.38, 0.30], [0.38, 0.30]], false, CHT_W_FINE, CHT_R_INK));
    return _p;
}

/// T-TOPPED SHAFT: one vertical with a distinct WIDE cap. That cap separates it from `menhir`.
function cht_mk_column() {
    var _p = [];
    array_push(_p, cht_poly([[-0.10, 0.32], [-0.09, -0.20], [0.09, -0.20], [0.10, 0.32]],
                            true, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_fill([[-0.20, -0.20], [-0.20, -0.30], [0.20, -0.30], [0.20, -0.20]], CHT_R_MASS));
    // Broken top: the capital's upper edge is torn, not ruled.
    array_push(_p, cht_poly([[-0.20, -0.30], [-0.10, -0.36], [0.02, -0.28], [0.12, -0.38],
                             [0.20, -0.30]], false, CHT_W_FINE, CHT_R_INK));
    for (var _i = 0; _i < 3; _i++) {
        var _x = -0.045 + _i * 0.045;
        array_push(_p, cht_poly([[_x, 0.26], [_x, -0.16]], false, CHT_W_HAIR, CHT_R_HATCH));
    }
    array_push(_p, cht_fill([[-0.17, 0.32], [-0.17, 0.24], [0.17, 0.24], [0.17, 0.32]], CHT_R_MASS));
    return _p;
}

/// HALF-DOME WITH A DOORWAY NOTCH at its base: a grassed mound cut by a trilithon entrance.
function cht_mk_barrow() {
    var _p = [];
    var _m = cht_pts_mound_xy(0.00, 0.30, 0.38, 0.32, 22);
    array_push(_p, cht_ring_fill(_m, CHT_R_HATCH, 0.00, 0.28));
    array_push(_p, cht_poly(_m, false, CHT_W_HEAVY, CHT_R_INK));
    array_push(_p, cht_fill([[-0.09, 0.30], [-0.09, 0.06], [0.09, 0.06], [0.09, 0.30]], CHT_R_MASS));
    array_push(_p, cht_fill([[-0.15, 0.06], [-0.15, -0.02], [0.15, -0.02], [0.15, 0.06]], CHT_R_MASS));
    array_push(_p, cht_poly([[-0.38, 0.30], [0.38, 0.30]], false, CHT_W_FINE, CHT_R_INK));
    return _p;
}

/// ONE LEANING BAR. The lean IS the identification - it is what says "not a column".
function cht_mk_menhir() {
    var _p = [];
    array_push(_p, cht_fill([[-0.09, 0.32], [-0.02, -0.36], [0.14, -0.34], [0.13, 0.32]], CHT_R_MASS));
    array_push(_p, cht_poly([[-0.09, 0.32], [-0.02, -0.36], [0.14, -0.34], [0.13, 0.32]],
                            true, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_poly([[0.02, -0.20], [0.06, 0.10]], false, CHT_W_HAIR, CHT_R_HATCH));
    array_push(_p, cht_fill([[-0.26, 0.32], [-0.20, 0.24], [-0.12, 0.32]], CHT_R_MASS));
    array_push(_p, cht_poly([[-0.34, 0.32], [0.30, 0.32]], false, CHT_W_FINE, CHT_R_INK));
    return _p;
}

/// A DOTTED ELLIPSE - separated marks, NEVER a continuous ring. That is what separates it from
/// `crater`, whose ring is closed.
function cht_mk_circle() {
    var _p = [];
    // Nine stones on a foreshortened ellipse. Near stones are taller: the perspective is what
    // makes this read as a ring of standing stones and not as a dotted circle.
    for (var _i = 0; _i < 9; _i++) {
        var _a = (_i / 9) * CHT_TAU;
        var _x = cos(_a) * 0.40;
        var _y = 0.10 + sin(_a) * 0.20;
        var _h = 0.13 + (sin(_a) + 1) * 0.055;
        array_push(_p, cht_fill([[_x - 0.045, _y], [_x - 0.035, _y - _h],
                                 [_x + 0.035, _y - _h], [_x + 0.045, _y]], CHT_R_MASS));
    }
    array_push(_p, cht_poly(cht_ellipse_pts(0.00, 0.10, 0.40, 0.20, 24), true, CHT_W_HAIR, CHT_R_HATCH));
    return _p;
}

/// ASYMMETRIC INVERTED U: one long leg, one collapsed to a stub.
function cht_mk_arch() {
    var _p = [];
    var _outer = cht_arc_pts(-0.02, 0.06, 0.30, pi, CHT_TAU, 16);
    var _inner = cht_arc_pts(-0.02, 0.06, 0.19, pi, CHT_TAU, 16);
    array_push(_p, cht_strip(_outer, _inner, CHT_R_MASS));
    array_push(_p, cht_poly(_outer, false, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_fill([[-0.32, 0.30], [-0.32, 0.06], [-0.21, 0.06], [-0.21, 0.30]], CHT_R_MASS));
    array_push(_p, cht_fill([[0.17, 0.30], [0.19, 0.14], [0.30, 0.10], [0.28, 0.30]], CHT_R_MASS));
    array_push(_p, cht_poly([[-0.38, 0.30], [0.38, 0.30]], false, CHT_W_FINE, CHT_R_INK));
    return _p;
}

/// A CURVED RIB COMB, tilted off vertical, NO MAST. The mast is what makes `ferry` a boat and this
/// a corpse.
function cht_mk_wreck() {
    var _p = [];
    array_push(_p, cht_poly([[-0.42, 0.10], [0.34, 0.30]], false, CHT_W_HEAVY, CHT_R_INK));
    for (var _i = 0; _i < 6; _i++) {
        var _t = _i / 5;
        var _bx = lerp(-0.36, 0.28, _t), _by = lerp(0.12, 0.28, _t);
        var _h = 0.34 - abs(_t - 0.35) * 0.30;
        array_push(_p, cht_poly(cht_qbez([_bx, _by], [_bx - 0.10, _by - _h * 0.6],
                                         [_bx - 0.03, _by - _h], 8), false, CHT_W_FINE, CHT_R_INK));
    }
    // The bank the wreck is buried in - hatched, so the hull reads as half-sunk.
    //
    // ⛔ REDRAWN 2026-08-22. This ran from x = -0.42 at y = 0.34, which is r = 0.541 against a
    // CHT_MARK_BOX of 0.50 - the worst breach in the corpus, and the ONLY one. It survived
    // check_marks.js because the strokes are built in a LOOP and a static reader of the source
    // cannot evaluate `-0.42 + _i * 0.15`; the checker says so itself, listing `wreck` among the
    // 26 marks whose op counts it can only lower-bound. The in-engine suite measures the geometry
    // that actually comes out, which is the entire argument for having one.
    //
    // ⚠️ CHT_MARK_BOX IS A DISC. At y = 0.34 the budget allows |x| <= sqrt(0.25 - 0.34^2) = 0.366,
    // so a bank that is legal at the mark's waist is illegal at its foot. The fix narrows and
    // raises the bank rather than shortening it - six strokes is what makes it read as a bank
    // instead of as three stray ticks.
    for (var _i = 0; _i < 6; _i++) {
        var _x = -0.34 + _i * 0.13;
        array_push(_p, cht_poly([[_x, 0.32], [_x + 0.07, 0.23]], false, CHT_W_HAIR, CHT_R_HATCH));
    }
    return _p;
}

/// ============================================================================================
/// FAMILY 3 - SACRED (6).
/// ============================================================================================

/// PYRAMID BASE WITH A TEARDROP ABOVE, detached. The gap is deliberate: a flame touching the altar
/// merges with it at 14px and the mark becomes a triangle.
function cht_mk_shrine() {
    var _p = [];
    array_push(_p, cht_fill([[-0.38, 0.32], [-0.30, 0.20], [0.30, 0.20], [0.38, 0.32]], CHT_R_MASS));
    array_push(_p, cht_fill([[-0.28, 0.20], [-0.21, 0.08], [0.21, 0.08], [0.28, 0.20]], CHT_R_MASS));
    array_push(_p, cht_rect_poly(-0.19, 0.08, 0.19, -0.02, CHT_W_MID, CHT_R_INK));
    var _fl = [];
    array_push(_fl, [0.00, -0.36]);
    _fl = cht_append(_fl, cht_qbez([0.00, -0.36], [0.14, -0.18], [0.00, -0.06], 8));
    _fl = cht_append(_fl, cht_qbez([0.00, -0.06], [-0.14, -0.18], [0.00, -0.36], 8));
    array_push(_p, cht_ring_fill(_fl, CHT_R_ACCENT, 0.00, -0.20));
    array_push(_p, cht_poly(_fl, true, CHT_W_FINE, CHT_R_INK));
    return _p;
}

/// LITTLE HOUSE WITH ONE SPIKE. Its roofline is deliberately STEEPER than `hamlet`'s.
function cht_mk_chapel() {
    var _p = [];
    array_push(_p, cht_poly(cht_pts_gable(0.00, 0.32, 0.40, 0.20, 0.30), true, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_fill([[-0.20, 0.12], [0.00, -0.18], [0.20, 0.12]], CHT_R_MASS));
    array_push(_p, cht_poly([[0.00, -0.18], [0.00, -0.40]], false, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_poly([[-0.06, -0.33], [0.06, -0.33]], false, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_fill([[-0.06, 0.32], [-0.06, 0.20], [0.06, 0.20], [0.06, 0.32]], CHT_R_MASS));
    array_push(_p, cht_arc(0.00, 0.20, 0.06, pi, CHT_TAU, CHT_W_FINE, CHT_R_INK));
    return _p;
}

/// A LONG BLOCK WITH A TOWER AT ONE END - asymmetric, which is what separates it from `chapel`.
function cht_mk_abbey() {
    var _p = [];
    array_push(_p, cht_rect_poly(-0.11, 0.30, 0.38, 0.02, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_fill([[-0.11, 0.02], [-0.03, -0.10], [0.38, -0.10], [0.38, 0.02]], CHT_R_MASS));
    array_push(_p, cht_poly(cht_pts_tower(-0.25, 0.30, 0.24, 0.48, 3), true, CHT_W_HEAVY, CHT_R_INK));
    for (var _i = 0; _i < 4; _i++) {
        var _x = 0.01 + _i * 0.09;
        array_push(_p, cht_arc(_x, 0.16, 0.035, pi, CHT_TAU, CHT_W_HAIR, CHT_R_HATCH));
    }
    array_push(_p, cht_fill([[-0.31, 0.02], [-0.31, -0.14], [-0.19, -0.14], [-0.19, 0.02]], CHT_R_MASS));
    return _p;
}

/// LOLLIPOP-ON-A-HUMP: a rounded slab over a low swell.
function cht_mk_grave() {
    var _p = [];
    array_push(_p, cht_poly(cht_pts_mound_xy(0.00, 0.30, 0.38, 0.12, 16), false, CHT_W_FINE, CHT_R_INK));
    array_push(_p, cht_ring_fill(cht_pts_mound_xy(0.00, 0.30, 0.38, 0.12, 16), CHT_R_HATCH, 0.00, 0.32));
    var _st = cht_pts_slab_round(0.00, 0.26, 0.30, 0.56);
    array_push(_p, cht_ring_fill(_st, CHT_R_MASS, 0.00, 0.10));
    array_push(_p, cht_poly(_st, true, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_poly([[-0.08, -0.08], [0.08, -0.08]], false, CHT_W_HAIR, CHT_R_VOID));
    array_push(_p, cht_poly([[-0.08, 0.00], [0.08, 0.00]], false, CHT_W_HAIR, CHT_R_VOID));
    return _p;
}

/// A DIVIDED RECTANGLE - the only gridded mark in the family.
function cht_mk_ossuary() {
    var _p = [];
    array_push(_p, cht_rect_poly(-0.40, 0.30, 0.40, -0.24, CHT_W_HEAVY, CHT_R_INK));
    for (var _r = 0; _r < 2; _r++) {
        for (var _c = 0; _c < 3; _c++) {
            var _x0 = -0.33 + _c * 0.235, _y0 = -0.16 + _r * 0.235;
            array_push(_p, cht_fill([[_x0, _y0], [_x0 + 0.19, _y0],
                                     [_x0 + 0.19, _y0 + 0.18], [_x0, _y0 + 0.18]], CHT_R_MASS));
        }
    }
    array_push(_p, cht_poly([[-0.39, 0.30], [0.39, 0.30]], false, CHT_W_MID, CHT_R_INK));
    return _p;
}

/// TOP-HEAVY: a wide mass on a thin stem.
function cht_mk_idol() {
    var _p = [];
    var _head = cht_pts_lobed(0.00, -0.16, 0.26, 0.24, 14, 0.06, 8801);
    array_push(_p, cht_ring_fill(_head, CHT_R_MASS, 0.00, -0.16));
    array_push(_p, cht_poly(_head, true, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_dot(-0.09, -0.20, 0.035, CHT_R_VOID));
    array_push(_p, cht_dot( 0.09, -0.20, 0.035, CHT_R_VOID));
    array_push(_p, cht_fill([[-0.08, 0.08], [-0.08, 0.24], [0.08, 0.24], [0.08, 0.08]], CHT_R_MASS));
    array_push(_p, cht_fill([[-0.24, 0.24], [-0.24, 0.34], [0.24, 0.34], [0.24, 0.24]], CHT_R_MASS));
    return _p;
}

/// ============================================================================================
/// FAMILY 4 - PASSAGE (7). How you get across or through.
///
/// Three of these sit over water strokes. The water is drawn the SAME way in all three so that the
/// crossing - arch, dashes, boat - is what the eye separates on.
/// ============================================================================================

/// AN ARCH OVER PARALLEL LINES.
function cht_mk_bridge() {
    var _p = [];
    for (var _i = 0; _i < 3; _i++) {
        var _y = 0.20 + _i * 0.06;
        array_push(_p, cht_poly(cht_qbez([-0.38, _y], [0.00, _y + 0.04], [0.38, _y], 10),
                                false, CHT_W_HAIR, CHT_R_HATCH));
    }
    var _o = cht_arc_pts(0.00, 0.20, 0.26, pi, CHT_TAU, 16);
    var _in = cht_arc_pts(0.00, 0.20, 0.17, pi, CHT_TAU, 16);
    array_push(_p, cht_strip(_o, _in, CHT_R_MASS));
    array_push(_p, cht_poly([[-0.44, -0.06], [0.44, -0.06]], false, CHT_W_HEAVY, CHT_R_INK));
    array_push(_p, cht_fill([[-0.44, -0.06], [-0.44, 0.20], [-0.26, 0.20], [-0.26, -0.06]], CHT_R_MASS));
    array_push(_p, cht_fill([[0.26, -0.06], [0.26, 0.20], [0.44, 0.20], [0.44, -0.06]], CHT_R_MASS));
    return _p;
}

/// A BROKEN LINE CROSSING PARALLEL LINES. The dashes are the tell.
function cht_mk_ford() {
    var _p = [];
    for (var _i = 0; _i < 4; _i++) {
        var _y = 0.02 + _i * 0.08;
        array_push(_p, cht_poly(cht_qbez([-0.40, _y], [0.00, _y + 0.05], [0.40, _y], 10),
                                false, CHT_W_FINE, CHT_R_HATCH));
    }
    for (var _i = 0; _i < 5; _i++) {
        var _x = -0.36 + _i * 0.18;
        array_push(_p, cht_poly([[_x, 0.34 - _i * 0.10], [_x + 0.09, 0.30 - _i * 0.10]],
                                false, CHT_W_HEAVY, CHT_R_INK));
    }
    array_push(_p, cht_dot(-0.16, 0.20, 0.045, CHT_R_MASS));
    array_push(_p, cht_dot( 0.10, 0.10, 0.040, CHT_R_MASS));
    return _p;
}

/// TWO VERTICALS WITH A GAP, joined by a lintel. Contrast `keep`, which is ONE mass.
function cht_mk_gate() {
    var _p = [];
    array_push(_p, cht_poly(cht_pts_tower(-0.26, 0.30, 0.22, 0.46, 2), true, CHT_W_HEAVY, CHT_R_INK));
    array_push(_p, cht_poly(cht_pts_tower( 0.26, 0.30, 0.22, 0.46, 2), true, CHT_W_HEAVY, CHT_R_INK));
    array_push(_p, cht_fill([[-0.16, -0.06], [-0.16, -0.18], [0.16, -0.18], [0.16, -0.06]], CHT_R_MASS));
    var _o = cht_arc_pts(0.00, 0.12, 0.15, pi, CHT_TAU, 14);
    var _arch = [[-0.15, 0.30]];
    for (var _i = 0; _i <= 14; _i++) array_push(_arch, _o[_i]);
    array_push(_arch, [0.15, 0.30]);
    array_push(_p, cht_ring_fill(_arch, CHT_R_MASS, 0.00, 0.20));
    array_push(_p, cht_poly([[-0.38, 0.30], [0.38, 0.30]], false, CHT_W_FINE, CHT_R_INK));
    return _p;
}

/// A W: two chevrons meeting at a low centre. The peaks point OUTWARD, which is what separates it
/// from `gorge`, whose scarps face inward.
function cht_mk_pass() {
    var _p = [];
    array_push(_p, cht_fill([[-0.39, 0.30], [-0.22, -0.30], [-0.02, 0.30]], CHT_R_MASS));
    array_push(_p, cht_fill([[0.02, 0.30], [0.22, -0.30], [0.39, 0.30]], CHT_R_MASS));
    array_push(_p, cht_poly([[-0.39, 0.30], [-0.22, -0.30], [-0.02, 0.30]], false, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_poly([[0.02, 0.30], [0.22, -0.30], [0.39, 0.30]], false, CHT_W_MID, CHT_R_INK));
    // The path threading the saddle, dashed - it is a route, not a wall.
    for (var _i = 0; _i < 4; _i++) {
        var _y = 0.30 - _i * 0.11;
        array_push(_p, cht_poly([[0.00 - _i * 0.012, _y], [0.00 - _i * 0.012, _y - 0.06]],
                                false, CHT_W_FINE, CHT_R_INK));
    }
    return _p;
}

/// A THIN DIAGONAL LADDER. Narrow, unlike `quarry`'s broad flat-topped terraces.
function cht_mk_stair() {
    var _p = [];
    array_push(_p, cht_poly([[-0.36, 0.32], [-0.10, 0.10], [0.14, -0.14], [0.34, -0.32]],
                            false, CHT_W_FINE, CHT_R_INK));
    for (var _i = 0; _i < 8; _i++) {
        var _t = _i / 7;
        var _x = lerp(-0.32, 0.24, _t), _y = lerp(0.28, -0.26, _t);
        array_push(_p, cht_fill([[_x, _y], [_x + 0.09, _y], [_x + 0.09, _y + 0.05], [_x, _y + 0.05]],
                                CHT_R_MASS));
    }
    array_push(_p, cht_poly([[-0.36, 0.32], [0.34, 0.32]], false, CHT_W_HAIR, CHT_R_HATCH));
    array_push(_p, cht_poly([[0.34, -0.32], [0.34, 0.32]], false, CHT_W_HAIR, CHT_R_HATCH));
    return _p;
}

/// A RECTANGLE WITH A DARK ARCH AND A LINE LEAVING IT. Squared and man-made, unlike `cave`, whose
/// host contour is irregular and lobed.
function cht_mk_tunnel() {
    var _p = [];
    array_push(_p, cht_rect_poly(-0.34, 0.32, 0.34, -0.24, CHT_W_HEAVY, CHT_R_INK));
    var _o = cht_arc_pts(0.00, 0.10, 0.19, pi, CHT_TAU, 14);
    var _mouth = [[-0.19, 0.32]];
    for (var _i = 0; _i <= 14; _i++) array_push(_mouth, _o[_i]);
    array_push(_mouth, [0.19, 0.32]);
    array_push(_p, cht_ring_fill(_mouth, CHT_R_MASS, 0.00, 0.20));
    array_push(_p, cht_fill([[-0.05, -0.09], [0.00, -0.16], [0.05, -0.09]], CHT_R_MASS));
    for (var _i = 0; _i < 4; _i++) {
        var _x = -0.28 + _i * 0.19;
        array_push(_p, cht_poly([[_x, -0.24], [_x + 0.06, -0.32]], false, CHT_W_HAIR, CHT_R_HATCH));
    }
    return _p;
}

/// A BOAT ON A WIRE. The mast is the separation from `wreck`, which has none.
function cht_mk_ferry() {
    var _p = [];
    array_push(_p, cht_poly([[-0.46, -0.02], [0.46, -0.02]], false, CHT_W_HAIR, CHT_R_HATCH));
    array_push(_p, cht_fill([[-0.38, 0.30], [-0.38, 0.10], [-0.28, 0.10], [-0.28, 0.30]], CHT_R_MASS));
    array_push(_p, cht_fill([[0.28, 0.30], [0.28, 0.10], [0.38, 0.10], [0.38, 0.30]], CHT_R_MASS));
    array_push(_p, cht_fill([[-0.22, 0.10], [0.22, 0.10], [0.15, 0.26], [-0.15, 0.26]], CHT_R_MASS));
    array_push(_p, cht_poly([[0.00, 0.10], [0.00, -0.30]], false, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_fill([[0.00, -0.30], [0.00, -0.10], [-0.20, -0.20]], CHT_R_MASS));
    return _p;
}

/// ============================================================================================
/// FAMILY 5 - WILD (8). Features nobody made.
/// ============================================================================================

/// A LUMPY HILL WITH A BLACK BITE OUT OF ITS BASE.
function cht_mk_cave() {
    var _p = [];
    var _h = [[-0.38, 0.30], [-0.36, 0.06], [-0.24, -0.10], [-0.12, -0.04], [0.02, -0.22],
              [0.20, -0.12], [0.32, 0.04], [0.38, 0.30]];
    array_push(_p, cht_ring_fill(_h, CHT_R_HATCH, 0.00, 0.20));
    array_push(_p, cht_poly(_h, false, CHT_W_HEAVY, CHT_R_INK));
    var _o = cht_arc_pts(-0.02, 0.30, 0.18, pi, CHT_TAU, 14);
    var _mouth = [[-0.20, 0.30]];
    for (var _i = 0; _i <= 14; _i++) array_push(_mouth, _o[_i]);
    array_push(_mouth, [0.16, 0.30]);
    array_push(_p, cht_ring_fill(_mouth, CHT_R_MASS, -0.02, 0.23));
    for (var _i = 0; _i < 4; _i++) {
        var _x = -0.32 + _i * 0.05;
        array_push(_p, cht_poly([[_x, 0.30], [_x + 0.05, 0.20]], false, CHT_W_HAIR, CHT_R_HATCH));
    }
    return _p;
}

/// A CIRCLE WITH A TAIL. The stream leaving downhill is the ONLY thing separating this from
/// `crater` at 14px, so it is drawn heavy and it leaves the disc's edge.
/// ⛔ REDRAWN 2026-08-22 - IT READ AS A FRYING PAN. The old version was a filled disc with a single
/// smooth ribbon leaving it at a constant angle, which is a saucepan with a handle and not a
/// spring with a stream. The silhouette note above was satisfied to the letter ("a circle with a
/// tail") and the drawing still failed, which is the useful lesson: a note is a constraint on the
/// shape, not a specification of it.
///
/// Two changes, and both are what a real spring symbol does. The stream MEANDERS - two bends, not
/// one arc - because a straight tail is read as a handle by anyone who has ever seen a pan. And it
/// TAPERS as it runs, which says water leaving a source rather than a rod attached to a pot.
function cht_mk_spring() {
    var _p = [];
    array_push(_p, cht_ring_fill(cht_ellipse_pts(-0.18, -0.14, 0.22, 0.18, 20), CHT_R_HATCH, -0.18, -0.14));
    array_push(_p, cht_poly(cht_ellipse_pts(-0.18, -0.14, 0.22, 0.18, 20), true, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_dot(-0.18, -0.14, 0.055, CHT_R_MASS));
    // Concentric ripples in the basin - the source welling up, and the second read that says
    // "water" before the eye reaches the stream at all.
    array_push(_p, cht_arc(-0.18, -0.14, 0.125, 0, CHT_TAU, CHT_W_HAIR, CHT_R_INK));

    // The stream: out of the basin, one bend right, one bend back left, tapering as it goes.
    var _s1 = cht_qbez([-0.02, -0.08], [0.14, -0.02], [0.10, 0.12], 10);
    var _s2 = cht_qbez([0.10, 0.12], [0.06, 0.26], [0.24, 0.36], 10);
    var _s = [];
    _s = cht_append(_s, _s1);
    for (var _i = 1; _i < array_length(_s2); _i++) array_push(_s, _s2[_i]);
    array_push(_p, cht_taper_ribbon(_s, 0.042, 0.014, CHT_R_MASS));
    array_push(_p, cht_poly(_s, false, CHT_W_HAIR, CHT_R_INK));
    return _p;
}

/// A RAGGED HORIZONTAL WITH A FRINGE HANGING FROM IT. Irregular - that is what separates it from
/// `weir`, whose teeth are evenly spaced.
function cht_mk_falls() {
    var _p = [];
    array_push(_p, cht_poly([[-0.46, -0.14], [-0.28, -0.20], [-0.10, -0.12], [0.10, -0.22],
                             [0.30, -0.13], [0.46, -0.18]], false, CHT_W_HEAVY, CHT_R_INK));
    var _st = cht_rng(4409);
    for (var _i = 0; _i < 9; _i++) {
        var _x = -0.42 + _i * 0.105;
        var _len = 0.22 + cht_rng_next(_st) * 0.20;
        array_push(_p, cht_poly([[_x, -0.14], [_x + 0.02, -0.14 + _len]], false, CHT_W_FINE, CHT_R_INK));
    }
    array_push(_p, cht_poly(cht_ellipse_pts(0.00, 0.30, 0.34, 0.10, 20), true, CHT_W_FINE, CHT_R_HATCH));
    array_push(_p, cht_dot(-0.20, 0.24, 0.022, CHT_R_HATCH));
    array_push(_p, cht_dot(0.22, 0.22, 0.022, CHT_R_HATCH));
    return _p;
}

/// TWO INWARD-FACING COMBS WITH A GAP. Contrast `pass`, whose peaks point outward.
function cht_mk_gorge() {
    var _p = [];
    array_push(_p, cht_fill([[-0.38, -0.32], [-0.12, -0.32], [-0.09, 0.32], [-0.38, 0.32]], CHT_R_HATCH));
    array_push(_p, cht_fill([[0.38, -0.32], [0.12, -0.32], [0.09, 0.32], [0.38, 0.32]], CHT_R_HATCH));
    array_push(_p, cht_poly([[-0.12, -0.32], [-0.09, 0.32]], false, CHT_W_HEAVY, CHT_R_INK));
    array_push(_p, cht_poly([[0.12, -0.32], [0.09, 0.32]], false, CHT_W_HEAVY, CHT_R_INK));
    // Hatch strokes point INTO the gap from both walls - the direction is the identification.
    for (var _i = 0; _i < 6; _i++) {
        var _y = -0.28 + _i * 0.12;
        array_push(_p, cht_poly([[-0.30, _y], [-0.13, _y + 0.03]], false, CHT_W_HAIR, CHT_R_INK));
        array_push(_p, cht_poly([[0.30, _y], [0.13, _y + 0.03]], false, CHT_W_HAIR, CHT_R_INK));
    }
    array_push(_p, cht_poly([[-0.02, -0.32], [0.02, 0.32]], false, CHT_W_FINE, CHT_R_HATCH));
    return _p;
}

/// A RING WITH RADIAL SPOKES, CLOSED, NO TAIL.
function cht_mk_crater() {
    var _p = [];
    array_push(_p, cht_ring(0.00, 0.00, 0.36, CHT_W_HEAVY, CHT_R_INK));
    array_push(_p, cht_ring_fill(cht_ellipse_pts(0.00, 0.02, 0.22, 0.19, 20), CHT_R_MASS, 0.00, 0.02));
    array_push(_p, cht_ring(0.00, 0.00, 0.27, CHT_W_HAIR, CHT_R_HATCH));
    for (var _i = 0; _i < 12; _i++) {
        var _a = (_i / 12) * CHT_TAU;
        array_push(_p, cht_poly([[cos(_a) * 0.36, sin(_a) * 0.36],
                                 [cos(_a) * 0.48, sin(_a) * 0.48]], false, CHT_W_FINE, CHT_R_INK));
    }
    return _p;
}

/// A PLUME - narrow at the bottom, ragged and WIDE at the top. The widening is the identification.
///
/// ⛔ REDRAWN 2026-08-22 - IT READ AS A WINE GLASS. The old version was a smooth tapered ribbon on
/// a trapezoid foot, with two clean curves outside it: a stem, a bowl and a base. Every element
/// satisfied the note - it WAS narrow at the bottom and wide at the top - and the silhouette was a
/// goblet, because the thing the note does not say is that a plume must be RAGGED. A smooth
/// widening curve is glassware; an uneven one is spray.
///
/// The fix is a torn top edge rather than a smooth one, jets of different heights, and the vent
/// widened into a proper ground line so the mark sits on something.
function cht_mk_geyser() {
    var _p = [];
    // The vent: a low mound with a dark slot, so the plume is clearly coming OUT of the ground.
    array_push(_p, cht_fill([[-0.22, 0.36], [-0.12, 0.24], [0.12, 0.24], [0.22, 0.36]], CHT_R_MASS));
    array_push(_p, cht_rect_fill(-0.05, 0.24, 0.05, 0.30, CHT_R_VOID));

    // The plume as ONE ragged mass: up the left side, across a torn top, down the right. Built as
    // an explicit outline rather than a ribbon, because a ribbon of any taper is smooth by
    // construction and smooth is exactly the defect.
    array_push(_p, cht_ring_fill([
        [-0.05, 0.24], [-0.09, 0.10], [-0.07, -0.02], [-0.15, -0.12], [-0.11, -0.20],
        [-0.20, -0.30], [-0.12, -0.28], [-0.09, -0.38], [-0.03, -0.27], [0.01, -0.40],
        [0.05, -0.26], [0.12, -0.34], [0.10, -0.22], [0.19, -0.26], [0.13, -0.14],
        [0.09, -0.02], [0.08, 0.11], [0.05, 0.24]
    ], CHT_R_HATCH, 0.00, 0.00));

    // Two jets breaking clear of the mass at different heights - the detail that says the plume is
    // moving. Different heights on purpose: a matched pair reads as a decorative flourish.
    array_push(_p, cht_poly([[0.16, -0.16], [0.27, -0.31]], false, CHT_W_FINE, CHT_R_INK));
    array_push(_p, cht_poly([[-0.16, -0.16], [-0.28, -0.24]], false, CHT_W_FINE, CHT_R_INK));
    array_push(_p, cht_dot(0.30, -0.35, 0.028, CHT_R_INK));
    array_push(_p, cht_dot(-0.31, -0.28, 0.024, CHT_R_INK));
    return _p;
}

/// THREE LOLLIPOPS: round canopies on short stems. Contrast `mire`, whose tufts are straight.
function cht_mk_grove() {
    var _p = [];
    var _a = cht_pts_lobed(-0.28, -0.04, 0.17, 0.16, 12, 0.16, 1201);
    var _b = cht_pts_lobed( 0.02, -0.16, 0.20, 0.19, 12, 0.16, 5507);
    var _c = cht_pts_lobed( 0.30, -0.02, 0.16, 0.15, 12, 0.16, 9109);
    array_push(_p, cht_ring_fill(_a, CHT_R_HATCH, -0.28, -0.04));
    array_push(_p, cht_ring_fill(_b, CHT_R_HATCH, 0.02, -0.16));
    array_push(_p, cht_ring_fill(_c, CHT_R_HATCH, 0.30, -0.02));
    array_push(_p, cht_poly(_a, true, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_poly(_b, true, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_poly(_c, true, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_poly([[-0.28, 0.12], [-0.28, 0.32]], false, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_poly([[0.02, 0.03], [0.02, 0.32]], false, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_poly([[0.30, 0.13], [0.30, 0.32]], false, CHT_W_MID, CHT_R_INK));
    return _p;
}

/// A SCATTER OF SHORT VERTICALS on a flat base.
function cht_mk_mire() {
    var _p = [];
    array_push(_p, cht_ring_fill(cht_ellipse_pts(0.00, 0.18, 0.44, 0.16, 22), CHT_R_HATCH, 0.00, 0.18));
    array_push(_p, cht_poly(cht_ellipse_pts(0.00, 0.18, 0.44, 0.16, 22), true, CHT_W_FINE, CHT_R_INK));
    var _st = cht_rng(7717);
    for (var _i = 0; _i < 9; _i++) {
        var _x = -0.36 + _i * 0.09;
        var _y = 0.10 + (cht_rng_next(_st) - 0.5) * 0.16;
        var _h = 0.14 + cht_rng_next(_st) * 0.16;
        array_push(_p, cht_poly([[_x, _y], [_x - 0.02, _y - _h]], false, CHT_W_FINE, CHT_R_INK));
        array_push(_p, cht_poly([[_x, _y], [_x + 0.04, _y - _h * 0.7]], false, CHT_W_HAIR, CHT_R_INK));
    }
    array_push(_p, cht_poly([[-0.30, 0.24], [-0.10, 0.24]], false, CHT_W_HAIR, CHT_R_INK));
    return _p;
}

/// ============================================================================================
/// FAMILY 6 - WORKS (8). What people built to take something out of the ground.
/// ============================================================================================

/// A TRIANGLE OVER A DARK SLOT.
function cht_mk_mine() {
    var _p = [];
    array_push(_p, cht_poly([[-0.26, 0.30], [0.00, -0.34], [0.26, 0.30]], false, CHT_W_HEAVY, CHT_R_INK));
    array_push(_p, cht_poly([[-0.15, 0.02], [0.15, 0.02]], false, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_dot(0.00, -0.30, 0.055, CHT_R_MASS));
    array_push(_p, cht_poly([[0.00, -0.26], [0.00, 0.12]], false, CHT_W_FINE, CHT_R_INK));
    array_push(_p, cht_fill([[-0.13, 0.30], [-0.13, 0.14], [0.13, 0.14], [0.13, 0.30]], CHT_R_MASS));
    array_push(_p, cht_fill([[0.24, 0.30], [0.31, 0.16], [0.38, 0.30]], CHT_R_HATCH));
    return _p;
}

/// BROAD TERRACES - wide and flat-topped, unlike `stair`'s thin diagonal.
function cht_mk_quarry() {
    var _p = [];
    array_push(_p, cht_fill([[-0.39, 0.30], [-0.39, 0.06], [0.10, 0.06], [0.10, 0.30]], CHT_R_HATCH));
    array_push(_p, cht_poly([[-0.39, 0.06], [0.10, 0.06]], false, CHT_W_HEAVY, CHT_R_INK));
    array_push(_p, cht_poly([[-0.30, -0.10], [0.26, -0.10]], false, CHT_W_HEAVY, CHT_R_INK));
    array_push(_p, cht_poly([[-0.14, -0.26], [0.40, -0.26]], false, CHT_W_HEAVY, CHT_R_INK));
    // The face of each bench, hatched downward. Regular, because a quarry bench is cut.
    for (var _i = 0; _i < 9; _i++) {
        var _x = -0.28 + _i * 0.07;
        array_push(_p, cht_poly([[_x, -0.10], [_x, 0.04]], false, CHT_W_HAIR, CHT_R_INK));
        array_push(_p, cht_poly([[_x + 0.14, -0.26], [_x + 0.14, -0.12]], false, CHT_W_HAIR, CHT_R_INK));
    }
    array_push(_p, cht_fill([[0.18, 0.30], [0.28, 0.14], [0.38, 0.30]], CHT_R_MASS));
    return _p;
}

/// A BOTTLE - the only curved-taper mass in the corpus.
function cht_mk_kiln() {
    var _p = [];
    var _l = cht_qbez([-0.26, 0.32], [-0.24, -0.06], [-0.07, -0.24], 12);
    var _r = cht_qbez([0.26, 0.32], [0.24, -0.06], [0.07, -0.24], 12);
    var _body = [];
    for (var _i = 0; _i <= 12; _i++) array_push(_body, _l[_i]);
    for (var _i = 12; _i >= 0; _i--) array_push(_body, _r[_i]);
    array_push(_p, cht_ring_fill(_body, CHT_R_HATCH, 0.00, 0.10));
    array_push(_p, cht_poly(_body, true, CHT_W_HEAVY, CHT_R_INK));
    array_push(_p, cht_fill([[-0.09, 0.32], [-0.09, 0.14], [0.09, 0.14], [0.09, 0.32]], CHT_R_MASS));
    array_push(_p, cht_poly([[-0.22, 0.06], [0.22, 0.06]], false, CHT_W_FINE, CHT_R_INK));
    array_push(_p, cht_poly(cht_qbez([0.00, -0.26], [0.22, -0.34], [0.10, -0.44], 10),
                            false, CHT_W_FINE, CHT_R_HATCH));
    return _p;
}

/// A SPOKED CIRCLE BESIDE A BOX.
function cht_mk_mill() {
    var _p = [];
    array_push(_p, cht_ring(-0.20, 0.02, 0.26, CHT_W_HEAVY, CHT_R_INK));
    array_push(_p, cht_ring(-0.20, 0.02, 0.20, CHT_W_HAIR, CHT_R_INK));
    for (var _i = 0; _i < 8; _i++) {
        var _a = (_i / 8) * CHT_TAU;
        array_push(_p, cht_fill([
            [-0.20 + cos(_a) * 0.20, 0.02 + sin(_a) * 0.20],
            [-0.20 + cos(_a + 0.22) * 0.20, 0.02 + sin(_a + 0.22) * 0.20],
            [-0.20 + cos(_a + 0.22) * 0.26, 0.02 + sin(_a + 0.22) * 0.26],
            [-0.20 + cos(_a) * 0.26, 0.02 + sin(_a) * 0.26]
        ], CHT_R_MASS));
    }
    array_push(_p, cht_poly(cht_pts_gable(0.24, 0.30, 0.28, 0.20, 0.15), true, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_fill([[0.10, 0.10], [0.24, -0.05], [0.38, 0.10]], CHT_R_MASS));
    array_push(_p, cht_poly([[-0.38, 0.30], [0.38, 0.30]], false, CHT_W_FINE, CHT_R_HATCH));
    return _p;
}

/// AN ANVIL. The horn makes it asymmetric, which is the whole identification.
function cht_mk_forge() {
    var _p = [];
    array_push(_p, cht_fill([[-0.34, 0.02], [-0.10, -0.06], [0.22, -0.06], [0.30, 0.00],
                             [0.20, 0.04], [0.10, 0.02], [0.10, 0.14], [-0.10, 0.14],
                             [-0.10, 0.02]], CHT_R_MASS));
    array_push(_p, cht_fill([[-0.20, 0.14], [0.20, 0.14], [0.26, 0.32], [-0.26, 0.32]], CHT_R_MASS));
    array_push(_p, cht_poly([[-0.38, -0.30], [0.00, -0.42], [0.38, -0.30]], false, CHT_W_HEAVY, CHT_R_INK));
    array_push(_p, cht_poly([[-0.36, -0.30], [-0.36, 0.16]], false, CHT_W_FINE, CHT_R_INK));
    array_push(_p, cht_poly([[0.36, -0.30], [0.36, 0.16]], false, CHT_W_FINE, CHT_R_INK));
    array_push(_p, cht_dot(-0.20, -0.14, 0.030, CHT_R_ACCENT));
    array_push(_p, cht_dot(-0.06, -0.20, 0.022, CHT_R_ACCENT));
    array_push(_p, cht_dot(0.06, -0.12, 0.026, CHT_R_ACCENT));
    return _p;
}

/// A CHECKERBOARD - the only regular grid in the corpus.
function cht_mk_saltern() {
    var _p = [];
    for (var _r = 0; _r < 3; _r++) {
        for (var _c = 0; _c < 3; _c++) {
            var _x0 = -0.38 + _c * 0.26, _y0 = -0.27 + _r * 0.21;
            var _solid = ((_r + _c) % 2 == 0);
            var _pan = [[_x0, _y0], [_x0 + 0.22, _y0], [_x0 + 0.22, _y0 + 0.17], [_x0, _y0 + 0.17]];
            array_push(_p, _solid ? cht_fill(_pan, CHT_R_MASS)
                                  : cht_poly(_pan, true, CHT_W_FINE, CHT_R_INK));
        }
    }
    array_push(_p, cht_poly([[-0.38, 0.32], [0.38, 0.28]], false, CHT_W_HEAVY, CHT_R_INK));
    array_push(_p, cht_poly([[-0.38, -0.32], [0.38, -0.30]], false, CHT_W_HAIR, CHT_R_HATCH));
    return _p;
}

/// A STRAIGHT BAR WITH EVEN TEETH. The REGULARITY separates it from `falls`.
function cht_mk_weir() {
    var _p = [];
    for (var _i = 0; _i < 3; _i++) {
        var _y = -0.30 + _i * 0.08;
        array_push(_p, cht_poly([[-0.38, _y], [0.38, _y]], false, CHT_W_HAIR, CHT_R_HATCH));
    }
    array_push(_p, cht_fill([[-0.44, -0.05], [0.44, -0.05], [0.44, 0.03], [-0.44, 0.03]], CHT_R_MASS));
    for (var _i = 0; _i < 8; _i++) {
        var _x = -0.38 + _i * 0.11;
        array_push(_p, cht_fill([[_x, 0.03], [_x + 0.06, 0.03], [_x + 0.06, 0.17], [_x, 0.17]],
                                CHT_R_MASS));
    }
    array_push(_p, cht_poly([[-0.40, 0.26], [0.40, 0.26]], false, CHT_W_FINE, CHT_R_HATCH));
    array_push(_p, cht_poly([[-0.36, 0.32], [0.36, 0.32]], false, CHT_W_FINE, CHT_R_HATCH));
    return _p;
}

/// A TAPERED TOWER WITH RAYS.
function cht_mk_pharos() {
    var _p = [];
    array_push(_p, cht_fill([[-0.17, 0.34], [-0.09, -0.12], [0.09, -0.12], [0.17, 0.34]], CHT_R_MASS));
    array_push(_p, cht_poly([[-0.17, 0.34], [-0.09, -0.12], [0.09, -0.12], [0.17, 0.34]],
                            true, CHT_W_MID, CHT_R_INK));
    array_push(_p, cht_rect_poly(-0.13, -0.12, 0.13, -0.20, CHT_W_FINE, CHT_R_INK));
    array_push(_p, cht_fill([[-0.09, -0.20], [-0.07, -0.32], [0.07, -0.32], [0.09, -0.20]], CHT_R_ACCENT));
    for (var _i = 0; _i < 6; _i++) {
        var _a = -pi * 0.5 + (_i - 2.5) * 0.34;
        array_push(_p, cht_poly([[cos(_a) * 0.13, -0.25 + sin(_a) * 0.13],
                                 [cos(_a) * 0.24, -0.25 + sin(_a) * 0.24]],
                                false, CHT_W_FINE, CHT_R_ACCENT));
    }
    array_push(_p, cht_fill([[-0.34, 0.30], [-0.24, 0.22], [-0.14, 0.30]], CHT_R_HATCH));
    return _p;
}
