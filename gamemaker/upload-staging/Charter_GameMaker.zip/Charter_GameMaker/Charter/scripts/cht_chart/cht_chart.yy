{
  "$GMScript": "v1",
  "%Name": "cht_chart",
  "isCompatibility": false,
  "isDnD": false,
  "name": "cht_chart",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}