/// ============================================================================================
/// CHARTER - cht_chart: THE SYSTEM. What the chart knows, and how it comes to know it.
///
/// Everything else in this package draws. This file is the part that makes Charter a system rather
/// than an icon set with a nice frame: a discovery grid, a landmark registry with states that
/// advance from the player's own movement, a route trail, terrain regions, and save/load.
///
/// The wing's price law is blunt about why that matters - complete systems clear the band and
/// single-behaviour utilities are stuck at $1-10 regardless of quality. A folder of beautiful
/// marks is a utility. A chart that fills itself in as the player explores, remembers what it
/// learned across a save, and can be asked what it knows, is a system.
///
/// -- THE ONE IDEA ------------------------------------------------------------------------------
/// The chart records what the player KNOWS, not what exists. Unexplored ground is UNPAINTED
/// PARCHMENT - the page, lighter (or on a dark page, darker) than the inked ground, with a torn
/// boundary - never a black rectangle. A black rectangle is the single loudest way an auto-map
/// announces that it is a widget, and avoiding it is most of why this product looks different from
/// the minimap assets it sits beside.
///
/// -- COORDINATE SPACES, AND THERE ARE EXACTLY TWO ----------------------------------------------
///   WORLD   your game's coordinates. Everything you hand this file is in world units.
///   PAGE    pixels on the drawn chart. Produced only by cht_chart_w2p, consumed only by cht_render.
/// Nothing in this file draws, and nothing in cht_render knows what a landmark means. That split is
/// what lets the whole system be asserted headlessly by cht_selftest with no GPU in the room.
///
/// -- NAMESPACE ---------------------------------------------------------------------------------
/// Every function here is `cht_`, every macro `CHT_`. GML's global namespace is flat and a
/// collision inside a buyer's project is a support ticket nobody can debug remotely.
/// ============================================================================================

/// How far a landmark may be from the player and still be SIGHTED / VISITED, as a fraction of the
/// world's smaller dimension. Both are per-chart fields; these are only the defaults.
#macro CHT_DEF_SIGHT 0.14
#macro CHT_DEF_VISIT 0.045

/// The route trail is decimated rather than truncated when it reaches this many points - see
/// cht_chart_route_push. A truncated trail loses where the player has BEEN, which is the one thing
/// the trail is for.
#macro CHT_ROUTE_MAX 3000

/// ============================================================================================
/// CONSTRUCTION
/// ============================================================================================

/// Create a chart over a rectangle of your world.
///
/// @param _wx0,_wy0,_wx1,_wy1  the world rectangle this chart covers
/// @param _cols,_rows          discovery grid resolution. 48x32 is a good starting point: fine
///                             enough that the revealed edge follows the player, coarse enough
///                             that a full page is a few hundred blobs rather than thousands.
function cht_chart_create(_wx0, _wy0, _wx1, _wy1, _cols, _rows) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_real(_wx0) || !is_real(_wy0) || !is_real(_wx1) || !is_real(_wy1)) return undefined;
    if (is_undefined(_cols)) _cols = 48;
    if (is_undefined(_rows)) _rows = 32;
    _cols = max(2, floor(_cols));
    _rows = max(2, floor(_rows));

    var _short = min(abs(_wx1 - _wx0), abs(_wy1 - _wy0));
    var _c = {
        wx0: min(_wx0, _wx1), wy0: min(_wy0, _wy1),
        wx1: max(_wx0, _wx1), wy1: max(_wy0, _wy1),
        cols: _cols, rows: _rows,
        seen: array_create(_cols * _rows, 0),
        seen_count: 0,

        landmarks: [],
        // A struct used as a dictionary. GML has no map literal and ds_map is a manual-free
        // resource - a struct is garbage-collected with the chart, which matters because a buyer
        // who forgets to destroy a chart should leak nothing but memory the runtime will reclaim.
        index: {},

        route: [],
        route_min: _short * 0.012,   // don't record a point until the player has actually moved
        regions: [],

        sight_r: _short * CHT_DEF_SIGHT,
        visit_r: _short * CHT_DEF_VISIT,

        page_id: "vellum",
        hand_id: "chancery",
        edge: CHT_EDGE_DECKLE,
        border: "graticule",
        rose: "fleur",
        cartouche: "scroll",
        title: "",
        subtitle: "",

        seed: 1409,
        // Owned by cht_render, declared here so the whole chart is one struct. -1 means "no cache
        // yet"; cht_chart_free releases it.
        surf: -1,
        surf_w: 0, surf_h: 0,
        dirty: true
    };
    return _c;
}

/// Mark the chart as needing a re-ink. Every mutator below calls this; a buyer changing something
/// by hand should call it too.
function cht_chart_touch(_chart) {
    _chart.dirty = true;
}

function cht_chart_set_page(_chart, _id)      { _chart.page_id = _id;   cht_chart_touch(_chart); }
function cht_chart_set_hand(_chart, _id)      { _chart.hand_id = _id;   cht_chart_touch(_chart); }
function cht_chart_set_edge(_chart, _kind)    { _chart.edge = _kind;    cht_chart_touch(_chart); }
function cht_chart_set_border(_chart, _id)    { _chart.border = _id;    cht_chart_touch(_chart); }
function cht_chart_set_rose(_chart, _id)      { _chart.rose = _id;      cht_chart_touch(_chart); }
function cht_chart_set_cartouche(_chart, _id) { _chart.cartouche = _id; cht_chart_touch(_chart); }

function cht_chart_set_title(_chart, _title, _subtitle) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_chart)) return;
    _chart.title = _title;
    _chart.subtitle = is_undefined(_subtitle) ? "" : _subtitle;
    cht_chart_touch(_chart);
}

/// Sight and visit radii, in WORLD units. Set these to match your game's camera and your idea of
/// "arrived" - the defaults are a fraction of the world and are only a starting point.
function cht_chart_set_ranges(_chart, _sight, _visit) {
    _chart.sight_r = max(0, _sight);
    _chart.visit_r = max(0, _visit);
}

/// ============================================================================================
/// COORDINATE MAPPING
/// ============================================================================================

/// World -> page. _x0.._y1 is the page rectangle the chart is drawn into.
///
/// ⚠️ ASPECT IS NOT PRESERVED, DELIBERATELY. The chart fills the rectangle it is given, because a
/// page with letterboxing on it does not look like a page. Hand it a rectangle whose aspect matches
/// your world if you want square cells - cht_chart_fit_rect below does that arithmetic for you.
function cht_chart_w2p(_chart, _wx, _wy, _x0, _y0, _x1, _y1) {
    var _u = (_wx - _chart.wx0) / max(0.00001, _chart.wx1 - _chart.wx0);
    var _v = (_wy - _chart.wy0) / max(0.00001, _chart.wy1 - _chart.wy0);
    return [lerp(_x0, _x1, _u), lerp(_y0, _y1, _v)];
}

/// Page -> world. The inverse, for hit-testing a click on the chart.
function cht_chart_p2w(_chart, _px, _py, _x0, _y0, _x1, _y1) {
    var _u = (_px - _x0) / max(0.00001, _x1 - _x0);
    var _v = (_py - _y0) / max(0.00001, _y1 - _y0);
    return [lerp(_chart.wx0, _chart.wx1, _u), lerp(_chart.wy0, _chart.wy1, _v)];
}

/// The largest world-aspect rectangle that fits inside the given box, centred, as [x0,y0,x1,y1].
/// Use it when you want square cells and are willing to give up some of the box.
function cht_chart_fit_rect(_chart, _x0, _y0, _x1, _y1) {
    var _bw = _x1 - _x0, _bh = _y1 - _y0;
    var _aw = _chart.wx1 - _chart.wx0, _ah = _chart.wy1 - _chart.wy0;
    if (_aw <= 0 || _ah <= 0 || _bw <= 0 || _bh <= 0) return [_x0, _y0, _x1, _y1];
    var _s = min(_bw / _aw, _bh / _ah);
    var _w = _aw * _s, _h = _ah * _s;
    var _cx = (_x0 + _x1) * 0.5, _cy = (_y0 + _y1) * 0.5;
    return [_cx - _w * 0.5, _cy - _h * 0.5, _cx + _w * 0.5, _cy + _h * 0.5];
}

/// The grid cell containing a world point, as [col, row]. Clamped, so a point just outside the
/// chart maps to the edge cell rather than to a negative index.
function cht_chart_cell_of(_chart, _wx, _wy) {
    var _u = (_wx - _chart.wx0) / max(0.00001, _chart.wx1 - _chart.wx0);
    var _v = (_wy - _chart.wy0) / max(0.00001, _chart.wy1 - _chart.wy0);
    return [clamp(floor(_u * _chart.cols), 0, _chart.cols - 1),
            clamp(floor(_v * _chart.rows), 0, _chart.rows - 1)];
}

/// The world-space centre of a cell, as [wx, wy].
function cht_chart_cell_centre(_chart, _col, _row) {
    return [lerp(_chart.wx0, _chart.wx1, (_col + 0.5) / _chart.cols),
            lerp(_chart.wy0, _chart.wy1, (_row + 0.5) / _chart.rows)];
}

/// ============================================================================================
/// DISCOVERY
/// ============================================================================================

/// Has this cell been revealed?
function cht_chart_seen(_chart, _col, _row) {
    if (_col < 0 || _row < 0 || _col >= _chart.cols || _row >= _chart.rows) return false;
    return _chart.seen[_row * _chart.cols + _col] == 1;
}

/// Has the cell containing this world point been revealed?
function cht_chart_seen_at(_chart, _wx, _wy) {
    var _c = cht_chart_cell_of(_chart, _wx, _wy);
    return cht_chart_seen(_chart, _c[0], _c[1]);
}

/// The fraction of the chart the player has revealed, 0..1.
function cht_chart_progress(_chart) {
    return _chart.seen_count / max(1, _chart.cols * _chart.rows);
}

/// Reveal every cell within _r world units of (_wx,_wy), and advance any landmark the player is
/// now close enough to see or to have reached. Returns the number of NEWLY revealed cells, so a
/// caller can cheaply tell whether anything changed.
///
/// ⚠️ ONLY THE BOUNDING BOX OF THE RADIUS IS WALKED, not the whole grid. Called every step from a
/// buyer's player object, a full grid walk at 48x32 is 1536 distance tests per frame for a radius
/// that usually touches a dozen cells. This walks the box and tests the disc inside it.
function cht_chart_discover(_chart, _wx, _wy, _r) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_chart)) return 0;
    if (is_undefined(_r)) _r = _chart.sight_r;
    var _cw = (_chart.wx1 - _chart.wx0) / _chart.cols;
    var _ch = (_chart.wy1 - _chart.wy0) / _chart.rows;
    var _lo = cht_chart_cell_of(_chart, _wx - _r, _wy - _r);
    var _hi = cht_chart_cell_of(_chart, _wx + _r, _wy + _r);
    var _new = 0;

    for (var _row = _lo[1]; _row <= _hi[1]; _row++) {
        for (var _col = _lo[0]; _col <= _hi[0]; _col++) {
            var _i = _row * _chart.cols + _col;
            if (_chart.seen[_i] == 1) continue;
            var _cx = _chart.wx0 + (_col + 0.5) * _cw;
            var _cy = _chart.wy0 + (_row + 0.5) * _ch;
            if (point_distance(_cx, _cy, _wx, _wy) > _r) continue;
            _chart.seen[_i] = 1;
            _chart.seen_count++;
            _new++;
        }
    }

    // Landmark states never regress. A chart is a record; walking away from a place you have been
    // does not un-visit it, and a buyer who wants that behaviour has cht_chart_set_state.
    var _n = array_length(_chart.landmarks);
    for (var _k = 0; _k < _n; _k++) {
        var _lm = _chart.landmarks[_k];
        if (_lm.state == CHT_ST_VISITED) continue;
        var _d = point_distance(_lm.wx, _lm.wy, _wx, _wy);
        if (_d <= _chart.visit_r) {
            _lm.state = CHT_ST_VISITED; _lm.known = true; _new++;
        } else if (_d <= _chart.sight_r && _lm.state < CHT_ST_SIGHTED) {
            _lm.state = CHT_ST_SIGHTED; _lm.known = true; _new++;
        }
    }

    if (_new > 0) cht_chart_touch(_chart);
    return _new;
}

/// The one call a buyer puts in their player's Step event: reveal around the player, advance
/// landmark states, and extend the route trail.
function cht_chart_observe(_chart, _wx, _wy) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_chart)) return 0;
    var _n = cht_chart_discover(_chart, _wx, _wy, _chart.sight_r);
    if (cht_chart_route_push(_chart, _wx, _wy)) _n++;
    return _n;
}

/// Append a point to the route, if the player has moved far enough to be worth recording.
/// Returns whether a point was added.
///
/// ⛔ AT THE CAP THE TRAIL IS DECIMATED, NEVER TRUNCATED. Dropping the oldest points would erase
/// where the player has BEEN, which is the only thing a route trail is for; dropping every other
/// point halves the memory and keeps the whole shape, at a resolution nobody can see on a page.
function cht_chart_route_push(_chart, _wx, _wy) {
    var _n = array_length(_chart.route);
    if (_n > 0) {
        var _last = _chart.route[_n - 1];
        if (point_distance(_last[0], _last[1], _wx, _wy) < _chart.route_min) return false;
    }
    array_push(_chart.route, [_wx, _wy]);
    if (array_length(_chart.route) >= CHT_ROUTE_MAX) {
        var _thin = [];
        for (var _i = 0; _i < array_length(_chart.route); _i += 2) {
            array_push(_thin, _chart.route[_i]);
        }
        _chart.route = _thin;
        _chart.route_min *= 2;
    }
    cht_chart_touch(_chart);
    return true;
}

/// Reveal the whole chart and mark every landmark visited. The buyer's "give me the full map"
/// pickup, and the fastest way to look at a page while building one.
function cht_chart_reveal_all(_chart) {
    for (var _i = 0; _i < _chart.cols * _chart.rows; _i++) _chart.seen[_i] = 1;
    _chart.seen_count = _chart.cols * _chart.rows;
    for (var _k = 0; _k < array_length(_chart.landmarks); _k++) {
        _chart.landmarks[_k].state = CHT_ST_VISITED;
        _chart.landmarks[_k].known = true;
    }
    cht_chart_touch(_chart);
}

/// Forget everything: unpainted parchment again, every landmark back to a rumour, no route.
/// Registrations survive - this erases KNOWLEDGE, not the world.
function cht_chart_forget(_chart) {
    for (var _i = 0; _i < _chart.cols * _chart.rows; _i++) _chart.seen[_i] = 0;
    _chart.seen_count = 0;
    for (var _k = 0; _k < array_length(_chart.landmarks); _k++) {
        _chart.landmarks[_k].state = CHT_ST_RUMOURED;
        _chart.landmarks[_k].known = _chart.landmarks[_k].rumoured;
    }
    _chart.route = [];
    cht_chart_touch(_chart);
}

/// ============================================================================================
/// LANDMARKS
/// ============================================================================================

/// Register a landmark.
///
/// @param _id        your own key, unique on this chart
/// @param _kind      one of cht_mark_ids() - the mark drawn for it
/// @param _name      the label written beside it once it is visited
/// @param _wx,_wy    where it is, in WORLD coordinates
/// @param _rumoured  OPTIONAL, default true. True means the chart carries a rumour of the place
///                   before the player has been anywhere near it - drawn faint, dashed, and
///                   deliberately in the WRONG PLACE. False hides it until it is sighted.
///
/// The rumour offset is derived from the id's own hash, so a rumour sits in the same wrong place
/// every time the game is played, and snaps to the truth the moment the place is sighted. That is
/// the product's argument in one behaviour: the chart is a record of belief, and belief is wrong
/// before it is right.
function cht_chart_add_landmark(_chart, _id, _kind, _name, _wx, _wy, _rumoured) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_chart)) return undefined;
    if (is_undefined(_rumoured)) _rumoured = true;
    var _h = cht_hash32(_id);
    var _st = cht_rng(_h);
    var _short = min(_chart.wx1 - _chart.wx0, _chart.wy1 - _chart.wy0);
    var _off = _short * 0.035;
    var _lm = {
        id: _id, kind: _kind, name: _name,
        wx: _wx, wy: _wy,
        state: CHT_ST_RUMOURED,
        known: _rumoured, rumoured: _rumoured,
        seed: _h,
        ox: (cht_rng_next(_st) - 0.5) * 2 * _off,
        oy: (cht_rng_next(_st) - 0.5) * 2 * _off,
        scale: 1.0
    };
    variable_struct_set(_chart.index, _id, array_length(_chart.landmarks));
    array_push(_chart.landmarks, _lm);
    cht_chart_touch(_chart);
    return _lm;
}

/// The landmark struct for an id, or undefined.
function cht_chart_landmark(_chart, _id) {
    if (!variable_struct_exists(_chart.index, _id)) return undefined;
    return _chart.landmarks[variable_struct_get(_chart.index, _id)];
}

/// Force a landmark's state. For scripted reveals: a quest that tells the player where something
/// is, a map bought from a trader, a rumour heard in a tavern.
function cht_chart_set_state(_chart, _id, _state) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_chart)) return false;
    var _lm = cht_chart_landmark(_chart, _id);
    if (is_undefined(_lm)) return false;
    _lm.state = clamp(_state, CHT_ST_RUMOURED, CHT_ST_VISITED);
    _lm.known = true;
    cht_chart_touch(_chart);
    return true;
}

/// Where a landmark is DRAWN, in world coordinates: its true position once sighted, and its
/// rumoured (offset) position before that.
function cht_chart_landmark_pos(_lm) {
    if (_lm.state == CHT_ST_RUMOURED) return [_lm.wx + _lm.ox, _lm.wy + _lm.oy];
    return [_lm.wx, _lm.wy];
}

/// The landmark nearest to a PAGE point, within _tol pixels, or undefined. This is what a buyer
/// wires a mouse click to.
function cht_chart_pick(_chart, _px, _py, _x0, _y0, _x1, _y1, _tol) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_chart)) return undefined;
    if (is_undefined(_tol)) _tol = 14;
    var _best = undefined, _bd = _tol;
    for (var _i = 0; _i < array_length(_chart.landmarks); _i++) {
        var _lm = _chart.landmarks[_i];
        if (!_lm.known) continue;
        var _w = cht_chart_landmark_pos(_lm);
        var _p = cht_chart_w2p(_chart, _w[0], _w[1], _x0, _y0, _x1, _y1);
        var _d = point_distance(_p[0], _p[1], _px, _py);
        if (_d <= _bd) { _bd = _d; _best = _lm; }
    }
    return _best;
}

/// A tally of what the chart knows. Cheap, and it is what a buyer puts in their journal UI.
function cht_chart_counts(_chart) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_chart)) return { rumoured: 0, sighted: 0, visited: 0, hidden: 0 };
    var _r = 0, _s = 0, _v = 0, _hidden = 0;
    for (var _i = 0; _i < array_length(_chart.landmarks); _i++) {
        var _lm = _chart.landmarks[_i];
        if (!_lm.known) { _hidden++; continue; }
        switch (_lm.state) {
            case CHT_ST_VISITED:  _v++; break;
            case CHT_ST_SIGHTED:  _s++; break;
            default:              _r++; break;
        }
    }
    return {
        landmarks: array_length(_chart.landmarks),
        rumoured: _r, sighted: _s, visited: _v, hidden: _hidden,
        regions: array_length(_chart.regions),
        route: array_length(_chart.route),
        cells: _chart.cols * _chart.rows,
        seen: _chart.seen_count,
        progress: cht_chart_progress(_chart)
    };
}

/// ============================================================================================
/// TERRAIN REGIONS
/// ============================================================================================

/// Register a terrain region. _poly is an array of [wx,wy] in WORLD coordinates; it is converted
/// to page coordinates at draw time, so one registration survives the chart being drawn at any
/// size, in any panel, on any page.
function cht_chart_add_region(_chart, _terrain, _poly) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_chart)) return undefined;
    var _r = { terrain: _terrain, poly: _poly,
               seed: cht_hash32(_terrain + "#" + string(array_length(_chart.regions))) };
    array_push(_chart.regions, _r);
    cht_chart_touch(_chart);
    return _r;
}

/// A rectangular region, for the common case. Wrapped rather than special-cased, so the drawing
/// path only ever sees polygons.
function cht_chart_add_region_rect(_chart, _terrain, _wx0, _wy0, _wx1, _wy1) {
    return cht_chart_add_region(_chart, _terrain,
        [[_wx0, _wy0], [_wx1, _wy0], [_wx1, _wy1], [_wx0, _wy1]]);
}

/// A region's polygon in PAGE coordinates.
function cht_chart_region_page(_chart, _region, _x0, _y0, _x1, _y1) {
    var _n = array_length(_region.poly);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        _out[_i] = cht_chart_w2p(_chart, _region.poly[_i][0], _region.poly[_i][1],
                                 _x0, _y0, _x1, _y1);
    }
    return _out;
}

/// ============================================================================================
/// SAVE AND LOAD
///
/// A chart that forgets everything when the player quits is a toy. This is the half of "system"
/// that a buyer discovers they need on the day they ship, and it is the half an icon set does not
/// have.
///
/// The format is deliberately a STRING rather than a file: a buyer's own save system already knows
/// how to persist a string, and a product that insists on writing its own file into their sandbox
/// is a product that fights their save format.
///
/// ⚠️ WHAT IS SAVED IS KNOWLEDGE, NOT THE WORLD. Registrations, regions and page settings are
/// rebuilt by the buyer's own code on load - they come from the game, not from the player. What
/// cannot be rebuilt is what the player learned, so that is exactly what travels: the revealed
/// cells, each landmark's state, and the route.
/// ============================================================================================

function cht_chart_save_string(_chart) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_chart)) return "";
    // The grid packs to one character per cell. At 48x32 that is 1536 characters, which is nothing
    // beside a normal save, and it stays human-readable - a buyer debugging a save can SEE the
    // shape of what the player explored.
    var _bits = "";
    for (var _i = 0; _i < _chart.cols * _chart.rows; _i++) {
        _bits += (_chart.seen[_i] == 1) ? "1" : "0";
    }
    var _states = [];
    for (var _i = 0; _i < array_length(_chart.landmarks); _i++) {
        var _lm = _chart.landmarks[_i];
        array_push(_states, { id: _lm.id, s: _lm.state, k: _lm.known });
    }
    return json_stringify({
        v: CHT_VERSION, cols: _chart.cols, rows: _chart.rows,
        seen: _bits, marks: _states, route: _chart.route
    });
}

/// Restore knowledge onto a chart that has already been created and populated.
///
/// Returns true on success. It returns FALSE rather than throwing on a grid-size mismatch, because
/// the realistic cause is a buyer changing their grid resolution between two builds of their game
/// and loading an old save - and a product that crashes a player's game over that is a product
/// nobody keeps. The chart is left untouched and the caller can decide.
function cht_chart_load_string(_chart, _s) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_chart)) return false;
    if (!is_string(_s) || string_length(_s) < 2) return false;
    var _d;
    try { _d = json_parse(_s); } catch (_e) { return false; }
    if (!is_struct(_d)) return false;
    if (!variable_struct_exists(_d, "seen") || !variable_struct_exists(_d, "cols")) return false;
    if (_d.cols != _chart.cols || _d.rows != _chart.rows) return false;

    var _bits = _d.seen;
    var _cells = _chart.cols * _chart.rows;
    if (string_length(_bits) != _cells) return false;

    var _count = 0;
    for (var _i = 0; _i < _cells; _i++) {
        var _on = (string_char_at(_bits, _i + 1) == "1") ? 1 : 0;
        _chart.seen[_i] = _on;
        _count += _on;
    }
    _chart.seen_count = _count;

    if (variable_struct_exists(_d, "marks")) {
        for (var _i = 0; _i < array_length(_d.marks); _i++) {
            var _m = _d.marks[_i];
            var _lm = cht_chart_landmark(_chart, _m.id);
            // A landmark in the save that no longer exists in the game is SKIPPED, not an error.
            // Content changes between patches; a save that refuses to load because a village was
            // renamed is worse than one that quietly forgets the village.
            if (is_undefined(_lm)) continue;
            _lm.state = clamp(_m.s, CHT_ST_RUMOURED, CHT_ST_VISITED);
            _lm.known = _m.k;
        }
    }
    if (variable_struct_exists(_d, "route")) _chart.route = _d.route;

    cht_chart_touch(_chart);
    return true;
}
