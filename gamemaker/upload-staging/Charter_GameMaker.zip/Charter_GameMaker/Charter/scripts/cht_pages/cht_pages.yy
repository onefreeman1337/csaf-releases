{
  "$GMScript": "v1",
  "%Name": "cht_pages",
  "isCompatibility": false,
  "isDnD": false,
  "name": "cht_pages",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}