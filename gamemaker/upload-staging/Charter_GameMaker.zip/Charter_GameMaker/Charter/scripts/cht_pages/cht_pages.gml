/// ============================================================================================
/// CHARTER - cht_pages: the six parchment palettes, and the page itself.
///
/// A page is a GROUND plus five inks, computed in Oklch (cht_palette), never a baked table. Five
/// roles and no more - ink, mass, hatch, void, accent - which is what makes 44 marks x 4 hands x
/// 3 states look like ONE chart rather than 528 decisions.
///
/// -- THE ONE INVARIANT, AND IT IS ASSERTED -----------------------------------------------------
/// `hatch` ALWAYS sits BETWEEN `ground` and `ink`, and `ink` is ALWAYS far enough from `ground` to
/// read. Every mark in the corpus puts hatching UNDER its contour; if the two ever converge, the
/// second level of detail disappears and every mark collapses to a silhouette - which is the exact
/// failure the 14px test is designed around, arriving by accident at full size. cht_selftest
/// asserts both gaps for all six palettes, on the RENDERED colours rather than on the authored
/// Oklch triples - the chroma ceiling and the gamut walk both move a colour after it is authored.
///
/// ⛔ THIS SAID "hatch is ALWAYS LIGHTER than ink" AND THAT IS FALSE ON `nocturne`. Corrected
/// 2026-08-22 while writing the assertion it claims to be asserted by. Nocturne inverts the
/// polarity - silver ink on a dark ground, L 0.900 against 0.205 - so its hatch at 0.615 is DARKER
/// than its ink, not lighter, and an assertion written from the old wording would have gone red on
/// a palette that is perfectly correct. BETWEEN is the property that actually holds on all six,
/// and it is the property the marks depend on.
///
/// -- `void` IS NOT TRANSPARENT ---------------------------------------------------------------
/// It is the GROUND colour, drawn deliberately on top of a mass - a window knocked out of a wall,
/// the inscription cut into a headstone. It has to be an opaque colour rather than an alpha hole
/// because a mark is drawn over hatched terrain, and a real hole would show the hatching through
/// the tower.
/// ============================================================================================

#macro CHT_PAGE_COUNT 6

/// The six page ids, in the order the store sheets show them.
function cht_page_ids() {
    return ["vellum", "sepia", "survey", "charcoal", "nocturne", "foxed"];
}

function cht_page_name(_id) {
    switch (_id) {
        case "vellum":   return "Vellum & Iron Gall";
        case "sepia":    return "Sepia Wash";
        case "survey":   return "Survey Blue";
        case "charcoal": return "Charcoal & Chalk";
        case "nocturne": return "Nocturne";
        case "foxed":    return "Foxed & Faded";
    }
    return "Unknown";
}

/// A page: ground plus the five ink roles, plus the rule and label tones the furniture uses.
///
/// The numbers are Oklch triples - lightness 0..1, chroma, hue in degrees. They are AUTHORED per
/// page rather than walked, for the same reason cht_palette's donor authored its hues: `vellum`
/// has to look like aged calfskin and iron-gall ink, and a well-spread generated hue would be
/// perfectly even and completely wrong.
function cht_page(_id) {
    switch (_id) {
        case "vellum": return {
            id: _id,
            ground: cht_oklch(0.918, 0.030, 88),    // warm cream calfskin
            ink:    cht_oklch(0.310, 0.036, 62),    // iron gall: brown-black, never pure black
            mass:   cht_oklch(0.255, 0.030, 60),
            hatch:  cht_oklch(0.575, 0.030, 66),
            vd:     cht_oklch(0.905, 0.028, 88),
            accent: cht_oklch(0.505, 0.145, 28),    // rubrication
            rule:   cht_oklch(0.470, 0.032, 64),
            fog:    cht_oklch(0.945, 0.020, 90)     // unpainted parchment: LIGHTER than the ground
        };
        case "sepia": return {
            id: _id,
            ground: cht_oklch(0.880, 0.044, 74),
            ink:    cht_oklch(0.345, 0.070, 52),
            mass:   cht_oklch(0.285, 0.062, 50),
            hatch:  cht_oklch(0.590, 0.056, 58),
            vd:     cht_oklch(0.868, 0.042, 74),
            accent: cht_oklch(0.545, 0.130, 42),
            rule:   cht_oklch(0.480, 0.062, 55),
            fog:    cht_oklch(0.922, 0.030, 78)
        };
        case "survey": return {
            id: _id,
            ground: cht_oklch(0.905, 0.016, 232),   // pale blue-grey drafting stock
            ink:    cht_oklch(0.330, 0.076, 252),   // prussian
            mass:   cht_oklch(0.275, 0.068, 254),
            hatch:  cht_oklch(0.605, 0.044, 244),
            vd:     cht_oklch(0.893, 0.015, 232),
            accent: cht_oklch(0.530, 0.160, 26),    // red survey marks
            rule:   cht_oklch(0.470, 0.060, 248),
            fog:    cht_oklch(0.944, 0.010, 230)
        };
        case "charcoal": return {
            id: _id,
            ground: cht_oklch(0.760, 0.006, 250),   // grey sugar paper
            ink:    cht_oklch(0.230, 0.008, 250),
            mass:   cht_oklch(0.175, 0.008, 250),
            hatch:  cht_oklch(0.480, 0.006, 250),
            vd:     cht_oklch(0.748, 0.006, 250),
            accent: cht_oklch(0.960, 0.010, 90),    // white chalk - the ONE light accent
            rule:   cht_oklch(0.390, 0.006, 250),
            fog:    cht_oklch(0.822, 0.005, 250)
        };
        case "nocturne": return {
            id: _id,
            ground: cht_oklch(0.205, 0.038, 264),   // dark blue-black - a star chart
            ink:    cht_oklch(0.900, 0.020, 250),   // silver-white: the polarity INVERTS here
            mass:   cht_oklch(0.955, 0.014, 250),
            hatch:  cht_oklch(0.615, 0.030, 254),
            vd:     cht_oklch(0.215, 0.038, 264),
            accent: cht_oklch(0.815, 0.130, 88),    // gold
            rule:   cht_oklch(0.740, 0.026, 252),
            fog:    cht_oklch(0.152, 0.030, 266)    // and so does the fog: DARKER than the ground
        };
        case "foxed": return {
            id: _id,
            ground: cht_oklch(0.858, 0.038, 82),
            ink:    cht_oklch(0.420, 0.048, 58),    // faded brown - the weakest ink on purpose
            mass:   cht_oklch(0.350, 0.044, 56),
            hatch:  cht_oklch(0.645, 0.040, 64),
            vd:     cht_oklch(0.845, 0.036, 82),
            accent: cht_oklch(0.560, 0.110, 36),
            rule:   cht_oklch(0.545, 0.044, 60),
            fog:    cht_oklch(0.900, 0.026, 84)
        };
    }
    return cht_page("vellum");
}

/// Resolve a role to a colour on a page.
///
/// ⛔ THE ROLE STRING `void` CANNOT BE A STRUCT KEY HERE - it is a GML reserved-ish name in some
/// contexts and, more to the point, this wing has already lost a build cycle to `end` being the
/// legacy synonym for `}` while the error pointed at the line ABOVE. The struct field is `vd` and
/// the ROLE is still "void", mapped explicitly below. Suspect a reserved word before you suspect
/// your braces.
function cht_page_colour(_page, _role) {
    switch (_role) {
        case CHT_R_INK:    return _page.ink;
        case CHT_R_MASS:   return _page.mass;
        case CHT_R_HATCH:  return _page.hatch;
        case CHT_R_VOID:   return _page.vd;
        case CHT_R_ACCENT: return _page.accent;
    }
    return _page.ink;
}

/// ============================================================================================
/// THE PAGE ITSELF - edges, borders, foxing
/// ============================================================================================

#macro CHT_EDGE_DECKLE 0
#macro CHT_EDGE_TORN   1
#macro CHT_EDGE_BURNT  2
#macro CHT_EDGE_CUT    3

function cht_edge_ids() { return ["deckle", "torn", "burnt", "cut"]; }
function cht_border_ids() { return ["plain", "double", "rope", "chain", "graticule"]; }

/// The wobble of one page edge, as a polyline along a straight run from (_x0,_y0) to (_x1,_y1).
///
/// Deterministic from _seed: a page edge that re-wobbled every frame would be the single most
/// obvious defect in the product, and it is the reason nothing in this package calls random().
function cht_edge_pts(_x0, _y0, _x1, _y1, _kind, _amp, _n, _seed) {
    var _st = cht_rng(_seed);
    var _out = array_create(_n + 1);
    var _dx = _x1 - _x0, _dy = _y1 - _y0;
    var _len = point_distance(0, 0, _dx, _dy);
    if (_len == 0) _len = 1;
    var _nx = -_dy / _len, _ny = _dx / _len;
    var _run = 0;
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n;
        var _o = 0;
        switch (_kind) {
            case CHT_EDGE_DECKLE:
                // A laid-paper deckle: many small irregularities, all on one side of the trim.
                _o = cht_rng_next(_st) * _amp;
                break;
            case CHT_EDGE_TORN:
                // A tear runs: it commits to a direction for a few steps, then jumps.
                _run += (cht_rng_next(_st) - 0.5) * _amp * 0.9;
                _run = clamp(_run, -_amp, _amp);
                _o = _run;
                break;
            case CHT_EDGE_BURNT:
                // Scalloped: a burn eats in lobes, always inward, deepest in the middle of a lobe.
                _o = (0.55 + 0.45 * sin(_t * CHT_TAU * 5.5)) * _amp * (0.5 + cht_rng_next(_st) * 0.5);
                break;
            default:
                _o = 0;   // CUT: a guillotine edge is straight, and that is the point of offering it
                break;
        }
        _out[_i] = [_x0 + _dx * _t + _nx * _o, _y0 + _dy * _t + _ny * _o];
    }
    return _out;
}

/// The whole page outline, as one closed polyline. Corners are shared, so the four edges cannot
/// disagree about where the page ends.
function cht_page_outline(_x0, _y0, _x1, _y1, _kind, _amp, _seed) {
    var _pts = [];
    _pts = cht_append(_pts, cht_edge_pts(_x0, _y0, _x1, _y0, _kind, _amp, 26, _seed + 11));
    _pts = cht_append(_pts, cht_edge_pts(_x1, _y0, _x1, _y1, _kind, _amp, 26, _seed + 22));
    _pts = cht_append(_pts, cht_edge_pts(_x1, _y1, _x0, _y1, _kind, _amp, 26, _seed + 33));
    _pts = cht_append(_pts, cht_edge_pts(_x0, _y1, _x0, _y0, _kind, _amp, 26, _seed + 44));
    return _pts;
}

/// Foxing: the rust-brown age spots on old paper. Returns dots, deterministic, avoiding a margin
/// so a spot never lands half off the page.
function cht_foxing(_x0, _y0, _x1, _y1, _count, _seed) {
    var _st = cht_rng(_seed);
    var _out = array_create(_count);
    var _mx = (_x1 - _x0) * 0.04, _my = (_y1 - _y0) * 0.04;
    for (var _i = 0; _i < _count; _i++) {
        var _x = lerp(_x0 + _mx, _x1 - _mx, cht_rng_next(_st));
        var _y = lerp(_y0 + _my, _y1 - _my, cht_rng_next(_st));
        var _r = (0.0015 + cht_rng_next(_st) * 0.0055) * (_x1 - _x0);
        _out[_i] = cht_dot(_x, _y, _r, CHT_R_HATCH);
    }
    return _out;
}

/// A page border, inset by _inset from the page rectangle. Five treatments.
function cht_border(_x0, _y0, _x1, _y1, _style, _inset, _w) {
    var _a = _x0 + _inset, _b = _y0 + _inset, _c = _x1 - _inset, _d = _y1 - _inset;
    var _out = [];
    array_push(_out, cht_rect_poly(_a, _b, _c, _d, _w, CHT_R_RULE_OR_INK()));
    switch (_style) {
        case "double":
            array_push(_out, cht_rect_poly(_a + _inset * 0.35, _b + _inset * 0.35,
                                           _c - _inset * 0.35, _d - _inset * 0.35,
                                           _w * 0.5, CHT_R_INK));
            break;
        case "rope": {
            // Alternating short strokes across the rule read as a twisted rope at page scale.
            var _step = (_c - _a) / 34;
            for (var _i = 0; _i < 34; _i++) {
                var _x = _a + _i * _step;
                array_push(_out, cht_poly([[_x, _b - _w * 1.6], [_x + _step * 0.7, _b + _w * 1.6]],
                                          false, _w * 0.6, CHT_R_INK));
                array_push(_out, cht_poly([[_x, _d - _w * 1.6], [_x + _step * 0.7, _d + _w * 1.6]],
                                          false, _w * 0.6, CHT_R_INK));
            }
        } break;
        case "chain": {
            var _stepc = (_c - _a) / 22;
            for (var _i = 0; _i < 22; _i++) {
                array_push(_out, cht_ring(_a + (_i + 0.5) * _stepc, _b, _w * 1.5, _w * 0.6, CHT_R_INK));
                array_push(_out, cht_ring(_a + (_i + 0.5) * _stepc, _d, _w * 1.5, _w * 0.6, CHT_R_INK));
            }
        } break;
        case "graticule": {
            // Survey ticks: the border becomes a scale. Longer every fifth tick.
            var _stepg = (_c - _a) / 40;
            for (var _i = 0; _i <= 40; _i++) {
                var _x = _a + _i * _stepg;
                var _len = ((_i % 5) == 0) ? _inset * 0.55 : _inset * 0.28;
                array_push(_out, cht_poly([[_x, _b], [_x, _b - _len]], false, _w * 0.7, CHT_R_INK));
                array_push(_out, cht_poly([[_x, _d], [_x, _d + _len]], false, _w * 0.7, CHT_R_INK));
            }
        } break;
    }
    return _out;
}

/// The page carries a `rule` tone that is not one of the five mark roles, and the border would
/// like it. Five roles is the whole discipline that makes 528 mark renderings look like one
/// product, so the vocabulary is NOT widened for one line: the border asks for ink and gets ink.
///
/// ⚠️ THIS FUNCTION USED TO CLAIM "cht_render is told to substitute", AND NOTHING SUBSTITUTED
/// ANYTHING. Corrected 2026-08-22 by the author of cht_render, who went looking for the
/// substitution and found there was nowhere it could happen - the role IS ink by the time the
/// renderer sees it, so the renderer cannot tell a border rule from a mark contour. The comment
/// described an intention; the code was always this. `page.rule` remains available to a buyer
/// drawing their own furniture, which is why it is still on the page struct.
function CHT_R_RULE_OR_INK() { return CHT_R_INK; }
