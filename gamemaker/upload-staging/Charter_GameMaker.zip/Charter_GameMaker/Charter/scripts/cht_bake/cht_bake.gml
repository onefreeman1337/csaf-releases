/// ============================================================================================
/// CHARTER - cht_bake: the store gallery, rendered BY THE PRODUCT.
///
/// Run the built executable with `-bake` and it writes eight sheets to the sandboxed save area,
/// drawn with the product's own page palettes, its own shipped fonts and its own public draw
/// functions. There is no side previewer and no design tool anywhere in this pipeline.
///
/// -- WHY THAT MATTERS MORE THAN IT SOUNDS ------------------------------------------------------
/// A gallery rendered by a re-implementation is a picture of the re-implementation. This wing has
/// measured that exactly: a previous product's JavaScript previewer carried a defect that was
/// plainly visible in the engine and invisible in the previewer, and the store page would have been
/// selling pixels the shipped GML does not produce. Baking from the executable also lets the
/// listing say "every image on this page was rendered by the product itself" and have it be true.
///
/// -- EVERY SHEET IS MEASURED, AND THE MEASUREMENT IS THE PIXELS -------------------------------
/// Each sheet function returns the y it finished at, which answers exactly ONE question: did the
/// last thing drawn fall off the bottom. That check shipped two defects on this wing's previous
/// product - a sheet running two lines of body copy off the RIGHT EDGE, and a sheet leaving 35% of
/// itself as bare page - and reported both as ok, because vertically they finished fine.
///
/// So the real check is cht_bk_ink_bounds: read the rendered surface back into a buffer and find
/// the bounding box of everything that is not page ground. That answers clipping AND emptiness in
/// one number pair, off the pixels rather than off the drawing code's own opinion of where it got
/// to. Where the two disagree, THE INK BOX IS RIGHT - a hand-maintained arithmetic expression about
/// where drawing reached is a claim; the pixels are evidence.
///
/// ⚠️ AND ITS OWN HONEST LIMIT: the x-axis FILL floor is largely neutralised here, because every
/// sheet carries a full-width rule under its title and that one line satisfies the x span whatever
/// else is on the page. The x floor earns its keep through the EDGE-CLIP test, not the fill test.
/// Saying so is the point; quoting the width percentage as if it measured coverage would not be.
/// ============================================================================================

#macro CHT_SHEET_W 1600
#macro CHT_SHEET_H 1100

/// Was -bake passed on the command line? Same inclusive scan as the self-test, for the same
/// reason: GameMaker has never been consistent about whether index 0 is the executable path.
function cht_bake_requested() {
    for (var _i = 0; _i <= parameter_count(); _i++) {
        if (string_lower(parameter_string(_i)) == "-bake") return true;
    }
    return false;
}

function cht_gif_requested() {
    for (var _i = 0; _i <= parameter_count(); _i++) {
        if (string_lower(parameter_string(_i)) == "-gif") return true;
    }
    return false;
}

/// The page every sheet is set on, except the ones that are showing other pages.
function cht_bk_page() { return cht_page("vellum"); }

/// ============================================================================================
/// LAYOUT HELPERS
/// ============================================================================================

function cht_bk_text(_text, _x, _y, _ha, _scale, _role, _size) {
    var _lb = cht_label_make(_text, _x, _y, _ha, fa_top,
                             is_undefined(_role) ? CHT_R_INK : _role,
                             is_undefined(_size) ? CHT_LB_BODY : _size,
                             is_undefined(_scale) ? 1.0 : _scale, 0);
    cht_draw_labels([_lb], cht_bk_page(), 1);
}

/// A sheet header: title, subtitle, and the rule under both. Returns the y to start content at.
function cht_bk_title(_title, _sub) {
    cht_bk_text(_title, 64, 46, fa_left, 1.45, CHT_R_INK, CHT_LB_TITLE);
    cht_bk_text(_sub, 64, 100, fa_left, 1.0, CHT_R_HATCH, CHT_LB_BODY);
    cht_draw_parts([cht_poly([[64, 134], [CHT_SHEET_W - 64, 134]], false, 2.0, CHT_R_INK)],
                   cht_bk_page(), 1);
    cht_draw_parts([cht_poly([[64, 139], [CHT_SHEET_W - 64, 139]], false, 0.9, CHT_R_HATCH)],
                   cht_bk_page(), 1);
    return 168;
}

/// A section caption with a short rule beside it. Returns the y after it.
function cht_bk_caption(_text, _x, _y, _w) {
    cht_bk_text(_text, _x, _y, fa_left, 0.92, CHT_R_ACCENT, CHT_LB_BODY);
    cht_draw_parts([cht_poly([[_x, _y + 24], [_x + _w, _y + 24]], false, 0.8, CHT_R_HATCH)],
                   cht_bk_page(), 0.7);
    return _y + 34;
}

/// The demonstration chart every vignette and the hero sheet are drawn from.
///
/// ONE builder, used by three sheets and echoed by the demo room, so the store page and the thing
/// a buyer opens after importing are the same chart. A gallery showing a world the package does not
/// contain is the oldest trick in asset-store photography and this product does not need it.
function cht_bk_demo_chart(_page_id, _hand_id, _explored) {
    var _c = cht_chart_create(0, 0, 1600, 1100, 44, 30);
    cht_chart_set_page(_c, _page_id);
    cht_chart_set_hand(_c, _hand_id);
    cht_chart_set_title(_c, "The Marchlands", "surveyed in the eleventh year");
    cht_chart_set_rose(_c, "fleur");
    cht_chart_set_cartouche(_c, "scroll");
    cht_chart_set_border(_c, "graticule");
    cht_chart_set_edge(_c, CHT_EDGE_DECKLE);
    cht_chart_set_ranges(_c, 210, 66);

    cht_chart_add_region(_c, "water", [[0, 690], [280, 640], [520, 700], [760, 660],
                                       [1010, 720], [1240, 690], [1600, 740],
                                       [1600, 1100], [0, 1100]]);
    cht_chart_add_region(_c, "woodland", [[120, 150], [520, 110], [640, 300], [430, 430], [150, 380]]);
    cht_chart_add_region(_c, "conifer", [[980, 90], [1400, 130], [1470, 340], [1080, 380]]);
    cht_chart_add_region(_c, "marsh", [[560, 500], [860, 470], [900, 620], [600, 640]]);
    cht_chart_add_region(_c, "moor", [[60, 440], [400, 470], [420, 640], [90, 620]]);
    cht_chart_add_region(_c, "scree", [[1150, 400], [1480, 430], [1500, 600], [1180, 590]]);
    cht_chart_add_region(_c, "cultivated", [[660, 190], [960, 170], [980, 400], [690, 420]]);
    cht_chart_add_region(_c, "dune", [[1230, 760], [1560, 790], [1540, 900], [1250, 880]]);

    cht_chart_add_landmark(_c, "lm_city",   "city",      "Ostmarch",         340,  300, true);
    cht_chart_add_landmark(_c, "lm_town",   "town",      "Wickthorn",        780,  330, true);
    cht_chart_add_landmark(_c, "lm_hamlet", "hamlet",    "Little Fen",       640,  560, true);
    cht_chart_add_landmark(_c, "lm_keep",   "keep",      "Greyward Keep",    200,  520, true);
    cht_chart_add_landmark(_c, "lm_cit",    "citadel",   "Highwatch",       1310,  240, true);
    cht_chart_add_landmark(_c, "lm_farm",   "farmstead", "Barleyhold",       830,  240, true);
    cht_chart_add_landmark(_c, "lm_bridge", "bridge",    "The Long Bridge",  520,  690, true);
    cht_chart_add_landmark(_c, "lm_ford",   "ford",      "Cattle Ford",      980,  700, true);
    cht_chart_add_landmark(_c, "lm_pharos", "pharos",    "The Pharos",      1470,  790, true);
    cht_chart_add_landmark(_c, "lm_mine",   "mine",      "Deepcut",         1240,  480, true);
    cht_chart_add_landmark(_c, "lm_mill",   "mill",      "Ashmill",          700,  430, true);
    cht_chart_add_landmark(_c, "lm_barrow", "barrow",    "The Long Barrow",  420,  180, true);
    cht_chart_add_landmark(_c, "lm_circle", "circle",    "The Nine",         160,  200, true);
    cht_chart_add_landmark(_c, "lm_abbey",  "abbey",     "St Cuthman's",    1080,  330, true);
    cht_chart_add_landmark(_c, "lm_pass",   "pass",      "Hollow Pass",     1400,  500, true);
    cht_chart_add_landmark(_c, "lm_cave",   "cave",      "The Whispering",  1330,  620, true);
    cht_chart_add_landmark(_c, "lm_wreck",  "wreck",     "The Grace",       1120,  860, true);
    cht_chart_add_landmark(_c, "lm_grove",  "grove",     "Hanging Grove",    300,  620, true);
    cht_chart_add_landmark(_c, "lm_ruin",   "ruin",      "Old Wall",         560,  420, true);
    cht_chart_add_landmark(_c, "lm_shrine", "shrine",    "The Wayshrine",    900,  520, true);

    // A journey, walked rather than declared: the discovery pattern IS the route, which is what
    // gives the explored region its shape. A hand-drawn "revealed area" would not match the trail.
    if (_explored) {
        var _path = [[200, 260], [340, 300], [470, 250], [560, 420], [700, 430], [780, 330],
                     [860, 260], [1000, 330], [1080, 330], [1180, 420], [1240, 480], [1330, 340],
                     [1310, 240], [1180, 300], [1040, 430], [900, 520], [780, 560], [640, 560],
                     [520, 640], [430, 560], [300, 620], [200, 520], [160, 340]];
        for (var _i = 1; _i < array_length(_path); _i++) {
            var _a = _path[_i - 1], _b = _path[_i];
            var _n = max(2, ceil(point_distance(_a[0], _a[1], _b[0], _b[1]) / 22));
            for (var _k = 0; _k <= _n; _k++) {
                cht_chart_observe(_c, lerp(_a[0], _b[0], _k / _n), lerp(_a[1], _b[1], _k / _n));
            }
        }
    }
    return _c;
}

/// ============================================================================================
/// SHEET 1 - THE CORPUS
/// ============================================================================================

function cht_bk_corpus() {
    var _y = cht_bk_title("44 landmark marks, drawn from data",
        "Six families. No sprite, no atlas, no texture page - this package has no sprites/ folder.");
    var _page = cht_bk_page();
    var _hand = cht_hand("chancery");
    var _ids = cht_mark_ids();
    var _fams = cht_family_ids();
    var _counts = [8, 7, 6, 7, 8, 8];
    var _at = 0;

    // ⚠️ THE PITCH IS MEASURED, NOT CHOSEN. The first bake overran at y=1152 on an 1100px sheet
    // (caption 34 + row 130, six times, over a 168px header). 6 x 152 + 168 = 1080 fits with 20px
    // of air. Put the arithmetic in the comment or the next edit silently re-clips it.
    var _cap_h = 28, _row_h = 124;
    for (var _f = 0; _f < 6; _f++) {
        cht_bk_caption(string_upper(_fams[_f]) + "   " + string(_counts[_f]),
                       64, _y, CHT_SHEET_W - 128);
        _y += _cap_h;
        var _cellw = (CHT_SHEET_W - 128) / 8;
        for (var _i = 0; _i < _counts[_f]; _i++) {
            var _id = _ids[_at + _i];
            var _cx = 64 + _cellw * (_i + 0.5);
            cht_draw_parts(cht_mark_parts(_id, _hand, CHT_ST_VISITED, _cx, _y + 44, 78,
                                          cht_hash32(_id), 0), _page, 1);
            cht_bk_text(cht_mark_name(_id), _cx, _y + 88, fa_center, 0.76, CHT_R_HATCH);
        }
        _at += _counts[_f];
        _y += _row_h;
    }
    return _y;
}

/// ============================================================================================
/// SHEET 2 - THE FOUR HANDS
/// ============================================================================================

function cht_bk_hands() {
    var _y = cht_bk_title("Four ink hands. The same mark, four different scribes.",
        "A hand changes weight, jitter, hatch and how a stroke ends - so 44 marks are 176 drawings.");
    var _page = cht_bk_page();
    var _hands = cht_hand_ids();
    var _rows = ["city", "barrow", "bridge", "pharos", "cave", "mill"];
    var _colw = (CHT_SHEET_W - 300) / 4;

    for (var _h = 0; _h < 4; _h++) {
        cht_bk_text(cht_hand_name(_hands[_h]), 300 + _colw * (_h + 0.5), _y, fa_center, 1.0,
                    CHT_R_ACCENT);
    }
    _y += 34;
    cht_draw_parts([cht_poly([[64, _y], [CHT_SHEET_W - 64, _y]], false, 0.8, CHT_R_HATCH)], _page, 0.7);
    _y += 12;

    // ⚠️ 145, MEASURED. At a row pitch of 148 this finished at y=1102 on an 1100px sheet - over by
    // two pixels, which is exactly the size of miss that a returned-y check catches and an eye
    // does not. 168 + 46 + 6 x 145 = 1084.
    var _row_h = 145;
    for (var _m = 0; _m < array_length(_rows); _m++) {
        var _id = _rows[_m];
        var _cy = _y + 72;
        cht_bk_text(cht_mark_name(_id), 250, _cy - 12, fa_right, 1.0, CHT_R_INK);
        for (var _h = 0; _h < 4; _h++) {
            var _cx = 300 + _colw * (_h + 0.5);
            cht_draw_parts(cht_mark_parts(_id, cht_hand(_hands[_h]), CHT_ST_VISITED,
                                          _cx, _cy, 126, cht_hash32(_id), 0), _page, 1);
        }
        _y += _row_h;
        cht_draw_parts([cht_poly([[64, _y - 8], [CHT_SHEET_W - 64, _y - 8]], false, 0.6, CHT_R_HATCH)],
                       _page, 0.35);
    }
    return _y;
}

/// ============================================================================================
/// SHEET 3 - THE THREE STATES
/// ============================================================================================

function cht_bk_states() {
    var _y = cht_bk_title("The chart records what the player KNOWS",
        "Rumoured: faint, dashed, and deliberately in the wrong place. Sighted: contour only, no name. Visited: everything.");
    var _page = cht_bk_page();
    var _hand = cht_hand("chancery");
    var _rows = ["citadel", "abbey", "pharos", "circle", "kiln", "gorge"];
    var _caps = ["Rumoured", "Sighted", "Visited"];
    var _notes = ["a query in the margin", "a shape on the horizon", "inked, named, certain"];
    var _colw = (CHT_SHEET_W - 300) / 3;

    for (var _s = 0; _s < 3; _s++) {
        var _cx = 300 + _colw * (_s + 0.5);
        cht_bk_text(_caps[_s], _cx, _y, fa_center, 1.05, CHT_R_ACCENT);
        cht_bk_text(_notes[_s], _cx, _y + 26, fa_center, 0.8, CHT_R_HATCH);
    }
    _y += 58;
    cht_draw_parts([cht_poly([[64, _y], [CHT_SHEET_W - 64, _y]], false, 0.8, CHT_R_HATCH)], _page, 0.7);
    _y += 12;

    for (var _m = 0; _m < array_length(_rows); _m++) {
        var _id = _rows[_m];
        var _cy = _y + 68;
        cht_bk_text(cht_mark_name(_id), 250, _cy - 12, fa_right, 1.0, CHT_R_INK);
        for (var _s = 0; _s < 3; _s++) {
            var _cx = 300 + _colw * (_s + 0.5);
            var _alpha = (_s == CHT_ST_RUMOURED) ? 0.6 : ((_s == CHT_ST_SIGHTED) ? 0.88 : 1.0);
            cht_draw_parts(cht_mark_parts(_id, _hand, _s, _cx, _cy, 120, cht_hash32(_id), 0),
                           _page, _alpha);
            if (_s == CHT_ST_RUMOURED) {
                cht_draw_parts(cht_label_query(_cx + 62, _cy - 40, 42, undefined), _page, 0.85);
            }
        }
        _y += 136;
    }
    return _y;
}

/// ============================================================================================
/// SHEET 4 - THE SIX PAGES
/// ============================================================================================

function cht_bk_pages() {
    var _y = cht_bk_title("Six parchment palettes, computed in Oklch",
        "Ground, ink, mass, hatch, void and a rubrication accent - and an UNPAINTED fog that inverts with the page.");
    var _ids = cht_page_ids();
    var _vw = (CHT_SHEET_W - 128 - 40) / 3;
    var _vh = 380;

    for (var _i = 0; _i < 6; _i++) {
        var _col = _i % 3, _row = _i div 3;
        var _x = 64 + _col * (_vw + 20);
        var _vy = _y + _row * (_vh + 62);
        var _c = cht_bk_demo_chart(_ids[_i], "chancery", true);
        cht_chart_set_title(_c, cht_page_name(_ids[_i]), "");
        cht_chart_draw(_c, _x, _vy, _x + _vw, _vy + _vh,
                       { rose: true, title: false, scale_bar: false, labels: false });
        cht_chart_free(_c);
        cht_bk_text(cht_page_name(_ids[_i]), _x + _vw * 0.5, _vy + _vh + 10, fa_center, 0.95,
                    CHT_R_INK);
        cht_bk_text(_ids[_i], _x + _vw * 0.5, _vy + _vh + 34, fa_center, 0.78, CHT_R_HATCH);
    }
    return _y + 2 * (_vh + 62);
}

/// ============================================================================================
/// SHEET 5 - THE HERO. One chart page, mid-exploration.
/// ============================================================================================

function cht_bk_hero() {
    var _c = cht_bk_demo_chart("vellum", "chancery", true);
    cht_chart_draw(_c, 0, 0, CHT_SHEET_W, CHT_SHEET_H, {});
    cht_chart_free(_c);
    return CHT_SHEET_H - 8;
}

/// A second hero on the inverted palette, because `nocturne` is the page that proves the palette
/// system is a system: the ink goes silver, the fog goes DARKER than the ground, and every mark and
/// every hatch follows without a single special case.
function cht_bk_hero_night() {
    var _c = cht_bk_demo_chart("nocturne", "illuminated", true);
    cht_chart_set_rose(_c, "astrolabe");
    cht_chart_set_cartouche(_c, "strapwork");
    cht_chart_set_border(_c, "chain");
    cht_chart_set_edge(_c, CHT_EDGE_TORN);
    cht_chart_draw(_c, 0, 0, CHT_SHEET_W, CHT_SHEET_H, {});
    cht_chart_free(_c);
    return CHT_SHEET_H - 8;
}

/// ============================================================================================
/// SHEET 6 - THE FURNITURE
/// ============================================================================================

function cht_bk_furniture() {
    var _y = cht_bk_title("Eight compass roses, six cartouches, eight terrain fills",
        "Page furniture is not decoration: it is what makes a page read as a document instead of a diagram.");
    var _page = cht_bk_page();

    // ⚠️ EVERY BLOCK BELOW WAS ENLARGED AFTER THE FIRST BAKE MEASURED THE INK AT 79% OF THE SHEET
    // HEIGHT, one point under the floor. That is not a threshold to nudge: master CLAUDE.md §4.2b
    // is explicit that a gallery image's job is to argue there is a LOT in the product, and a fifth
    // of the sheet being bare page argues the opposite. The content grew; the floor did not move.
    _y = cht_bk_caption("COMPASS ROSES   8", 64, _y, CHT_SHEET_W - 128);
    var _rids = cht_rose_ids();
    var _rw = (CHT_SHEET_W - 128) / 8;
    for (var _i = 0; _i < 8; _i++) {
        var _cx = 64 + _rw * (_i + 0.5);
        cht_draw_parts(cht_rose(_rids[_i], _cx, _y + 84, 72, undefined), _page, 1);
        cht_bk_text(cht_rose_name(_rids[_i]), _cx, _y + 172, fa_center, 0.74, CHT_R_HATCH);
    }
    _y += 214;

    _y = cht_bk_caption("CARTOUCHES   6", 64, _y, CHT_SHEET_W - 128);
    var _cids = cht_cartouche_ids();
    var _cw = (CHT_SHEET_W - 128 - 40) / 2;
    for (var _i = 0; _i < 6; _i++) {
        var _col = _i % 2, _row = _i div 2;
        var _x = 64 + _col * (_cw + 40);
        var _cy = _y + _row * 118;
        var _tb = cht_label_title_block(_cids[_i], _x + 40, _cy + 8, _x + _cw - 40, _cy + 88,
                                        cht_cartouche_name(_cids[_i]), "", cht_hand("chancery"),
                                        undefined);
        cht_draw_parts(_tb.parts, _page, 1);
        cht_draw_labels(_tb.labels, _page, 1);
    }
    _y += 366;

    _y = cht_bk_caption("TERRAIN FILLS   8   (clipped to any polygon, not to a box)",
                        64, _y, CHT_SHEET_W - 128);
    var _tids = cht_terrain_ids();
    var _tw = (CHT_SHEET_W - 128) / 8;
    for (var _i = 0; _i < 8; _i++) {
        var _x = 64 + _tw * _i + 6;
        var _sw = _tw - 12;
        // A lobed patch, not a rectangle: a rectangular swatch would be a swatch of a fill that
        // this product never draws rectangularly, which is a small lie in a store image.
        // ⚠️ WATER GETS A SMOOTHER, DENSER SWATCH, AND THAT IS A LAYOUT DECISION RATHER THAN A
        // PRODUCT ONE. Water is the only fill here that lines the SHORE rather than filling the
        // interior, so it is the only one whose look depends on the polygon's edges being long
        // relative to the ring spacing. An eleven-lobed pond the size of a postage stamp is not a
        // coastline and showed one lonely contour; a real sea is what the hero sheet shows it doing.
        // Fewer lobes and a higher density here demonstrate the fill honestly at swatch scale -
        // nothing about the fill itself changes.
        var _lobes = (_tids[_i] == "water") ? 7 : 11;
        var _amp   = (_tids[_i] == "water") ? 0.07 : 0.14;
        var _dens  = (_tids[_i] == "water") ? 2.4 : 1.15;
        var _poly = cht_pts_lobed(_x + _sw * 0.5, _y + 84, _sw * 0.46, 76, _lobes, _amp, 700 + _i);
        cht_draw_parts([cht_poly(_poly, true, 0.9, CHT_R_HATCH)], _page, 0.45);
        cht_draw_parts(cht_terrain_fill(_tids[_i], _poly, 7, _dens, 300 + _i), _page, 1);
        cht_bk_text(cht_terrain_name(_tids[_i]), _x + _sw * 0.5, _y + 172, fa_center, 0.74,
                    CHT_R_HATCH);
    }
    return _y + 196;
}

/// ============================================================================================
/// SHEET 7 - THE LEGIBILITY LADDER
///
/// ⛔ THIS SHEET USED TO BE HEADED "The 14px test - the size your players actually see" AND THE
/// IMAGE UNDERNEATH DISPROVED IT. Baked, opened, looked at: 44 marks at 14px are grey dust. Not
/// "hard to tell apart" - not resolvable as shapes at all. The claim was printed at 1600px directly
/// above the evidence against it, which is the single worst place in the product to put an
/// overstatement, and no mechanical check in the package could see it. The ink-bounds test was
/// green. 369 assertions were green. Only opening the PNG found it.
///
/// ⚠️ WHAT WAS WRONG WAS THE CLAIM, NOT THE CORPUS - AND THE DISTINCTION MATTERS BECAUSE THE
/// TEMPTING FIX WAS THE OTHER ONE. Motif_Corpus.md §1 sets 14px as a DESIGN CONSTRAINT, to force
/// every mark to lead with its outermost contour instead of its detail, and that constraint did its
/// job: the corpus is silhouette-led and 44/44 distinct. What does not follow is that line-drawn
/// geometry with a one-pixel stroke RESOLVES at 14px. Quietly deleting the constraint would have
/// thrown away the thing that made the corpus good in order to rescue a sentence.
///
/// So the constraint stays and the sentence goes. What replaces it is more useful to a buyer
/// anyway: the same corpus at two sizes, captioned with where each one belongs, so they can pick a
/// mark size for their own page instead of taking our word for one.
/// ============================================================================================

function cht_bk_silhouette() {
    var _y = cht_bk_title("One corpus, at the sizes a page actually uses",
        "The same 44 marks at 32 and 96 pixels. Charter draws them at whatever size your chart needs - these are the two that matter.");
    var _page = cht_bk_page();
    // chancery, not survey: the survey hand no longer FILLS its masses (see cht_hands), and this
    // sheet is about the SILHOUETTE.
    var _hand = cht_hand("chancery");
    var _ids = cht_mark_ids();

    // ⚠️ ELEVEN COLUMNS, NOT TWELVE. 44 = 4 x 11 exactly, so the grid closes; at twelve the last
    // row ran four slots short and the sheet's bottom-right corner read as unfinished.
    var _cols = 11;
    var _pitch = (CHT_SHEET_W - 128) / _cols;

    _y = cht_bk_caption("32 PIXELS   -   a landmark on a half-page chart panel",
                        64, _y, CHT_SHEET_W - 128);
    for (var _i = 0; _i < 44; _i++) {
        var _cx = 64 + _pitch * ((_i % _cols) + 0.5);
        var _cy = _y + 32 + (_i div _cols) * 58;
        cht_draw_parts(cht_mark_parts(_ids[_i], _hand, CHT_ST_VISITED, _cx, _cy, 32,
                                      cht_hash32(_ids[_i]), 0), _page, 1);
    }
    _y += 32 + 4 * 58 + 28;

    _y = cht_bk_caption("96 PIXELS   -   a full-page chart, or a journal entry",
                        64, _y, CHT_SHEET_W - 128);
    for (var _i = 0; _i < 44; _i++) {
        var _cx = 64 + _pitch * ((_i % _cols) + 0.5);
        var _cy = _y + 62 + (_i div _cols) * 132;
        cht_draw_parts(cht_mark_parts(_ids[_i], _hand, CHT_ST_VISITED, _cx, _cy, 96,
                                      cht_hash32(_ids[_i]), 0), _page, 1);
    }
    return _y + 62 + 3 * 132 + 56;
}

/// ============================================================================================
/// SHEET 8 - WHAT SHIPS
///
/// Every number on this sheet is COUNTED at draw time from the arrays that produce them, never
/// typed. A store image that states a count is a claim, and a claim typed into a string is a claim
/// that goes stale the first time somebody adds a mark.
/// ============================================================================================

function cht_bk_system() {
    var _y = cht_bk_title("What is in the package",
        "Every figure on this sheet is counted from the shipped arrays at the moment it is drawn.");
    var _page = cht_bk_page();

    var _marks = array_length(cht_mark_ids());
    var _hands = array_length(cht_hand_ids());
    var _pages = array_length(cht_page_ids());
    var _states = array_length(cht_state_ids());

    var _keys = ["landmark marks", "ink hands", "landmark states", "page palettes",
                 "compass roses", "cartouche frames", "terrain fills", "page edges",
                 "border treatments"];
    var _vals = [_marks, _hands, _states, _pages,
                 array_length(cht_rose_ids()), array_length(cht_cartouche_ids()),
                 array_length(cht_terrain_ids()), array_length(cht_edge_ids()),
                 array_length(cht_border_ids())];

    _y = cht_bk_caption("THE CORPUS", 64, _y, 660);
    var _ry = _y;
    for (var _i = 0; _i < array_length(_keys); _i++) {
        cht_bk_text(string(_vals[_i]), 150, _ry, fa_right, 1.25, CHT_R_ACCENT);
        cht_bk_text(_keys[_i], 172, _ry + 4, fa_left, 1.0, CHT_R_INK);
        _ry += 46;
    }

    _ry += 14;
    cht_draw_parts([cht_poly([[64, _ry], [724, _ry]], false, 1.4, CHT_R_INK)], _page, 1);
    _ry += 16;
    cht_bk_text(string(_marks * _hands * _states), 150, _ry, fa_right, 1.6, CHT_R_ACCENT);
    cht_bk_text("distinct mark renderings", 172, _ry + 8, fa_left, 1.05, CHT_R_INK);
    _ry += 46;
    cht_bk_text(string(_marks * _hands * _states * _pages), 150, _ry, fa_right, 1.6, CHT_R_ACCENT);
    cht_bk_text("distinct appearances, across every page", 172, _ry + 8, fa_left, 1.05, CHT_R_INK);
    _ry += 56;
    cht_bk_text("0", 150, _ry, fa_right, 1.6, CHT_R_ACCENT);
    cht_bk_text("sprites, atlases and texture pages", 172, _ry + 8, fa_left, 1.05, CHT_R_INK);
    _ry += 30;
    cht_bk_text("this package has no sprites/ folder at all", 172, _ry + 8, fa_left, 0.82,
                CHT_R_HATCH);

    var _sx = 800;
    var _sy = cht_bk_caption("THE SYSTEM UNDERNEATH", _sx, _y, CHT_SHEET_W - 64 - _sx);
    var _sys = [
        "cht_chart_create       a chart over any rectangle of your world",
        "cht_chart_observe      one call in your player's Step event",
        "cht_chart_discover     reveal ground, advance landmark states",
        "cht_chart_add_landmark register a place; it starts as a rumour",
        "cht_chart_add_region   terrain, clipped to any polygon",
        "cht_chart_pick         the landmark under a mouse click",
        "cht_chart_counts       what the chart knows, for your journal UI",
        "cht_chart_save_string  knowledge, as a string your save can hold",
        "cht_chart_load_string  and back again, refusing a mismatched grid",
        "cht_chart_draw         the whole page, in one call",
        "cht_chart_draw_cached  the same page, re-inked only when it changes",
        "cht_draw_mark          one mark, anywhere, at any size",
        "cht_export_mark        one mark to a PNG",
        "cht_export_chart       the whole page to a PNG, at any resolution",
        // ⛔ NO ASSERTION COUNT ON THIS LINE. The first draft typeset "218 assertions", which is
        // the figure from a DIFFERENT product in this wing and was never true of this one. A
        // number printed into a store image is a claim, and a claim nobody measured is exactly the
        // failure the factory's honesty rule exists to stop - at 1600px, forever.
        "cht_selftest           the in-engine suite, runnable from the demo room"
    ];
    for (var _i = 0; _i < array_length(_sys); _i++) {
        cht_bk_text(_sys[_i], _sx, _sy, fa_left, 0.86, CHT_R_INK);
        _sy += 38;
    }
    _sy += 12;
    cht_draw_parts([cht_poly([[_sx, _sy], [CHT_SHEET_W - 64, _sy]], false, 1.2, CHT_R_INK)], _page, 1);
    _sy += 18;
    cht_bk_text("Raw, readable GML. Every global and macro namespaced cht_ / CHT_.",
                _sx, _sy, fa_left, 0.92, CHT_R_INK);
    _sy += 30;
    cht_bk_text("A runnable demo room. No absolute paths, no hardcoded room or layer indices.",
                _sx, _sy, fa_left, 0.92, CHT_R_INK);

    // -- THE FOOTER STRIP, and it exists because the sheet was MEASURED at 65% height fill.
    // Two columns of type over a 1100px sheet leaves a third of it bare, and master CLAUDE.md
    // §4.2b's whole argument is that a store image has to argue there is a lot in the product.
    // A rule of the corpus in miniature does that AND is the sheet's own subject: these are the
    // same 44 marks the API above draws, at the size the API above draws them.
    var _fy = max(_ry, _sy) + 54;
    cht_draw_parts([cht_poly([[64, _fy], [CHT_SHEET_W - 64, _fy]], false, 1.4, CHT_R_INK)], _page, 1);
    _fy += 22;
    cht_bk_text("all 44, at 22px", 64, _fy, fa_left, 0.82, CHT_R_ACCENT);
    _fy += 34;
    var _ids = cht_mark_ids();
    var _hand = cht_hand("chancery");
    var _pitch = (CHT_SHEET_W - 128) / 22;
    for (var _i = 0; _i < 44; _i++) {
        cht_draw_parts(cht_mark_parts(_ids[_i], _hand, CHT_ST_VISITED,
                                      64 + _pitch * ((_i % 22) + 0.5),
                                      _fy + 16 + (_i div 22) * 44, 22,
                                      cht_hash32(_ids[_i]), 0), _page, 1);
    }
    return _fy + 16 + 44 + 20;
}

/// ============================================================================================
/// THE GIF - the chart inking itself
///
/// This is the single most persuasive thing the product can show, and it is the ONE image on the
/// listing that a still cannot substitute for. Every static sheet argues "here is a nice chart";
/// this one shows a blank sheet of parchment becoming that chart as somebody walks, which is the
/// entire product in six seconds. Master §1a-3 puts a GIF above the fold on every listing for
/// exactly this reason.
///
/// The frames are rendered by the SHIPPED executable through the SAME public draw call a buyer
/// makes, feeding the SAME cht_chart_observe a buyer calls from their player's Step event. There is
/// no animation code here at all - the motion is the system running.
/// ============================================================================================

#macro CHT_GIF_W      900
#macro CHT_GIF_H      620
#macro CHT_GIF_FRAMES 84

/// The walk, densely sampled. Same circuit the demo room walks, so the GIF and the room a buyer
/// opens after importing show the same journey.
function cht_gif_path() {
    return [[200, 260], [340, 300], [470, 250], [420, 180], [160, 200], [200, 520], [300, 620],
            [430, 560], [560, 420], [640, 560], [780, 560], [900, 520], [700, 430], [780, 330],
            [830, 240], [1000, 330], [1080, 330], [1180, 420], [1240, 480], [1330, 340],
            [1310, 240], [1400, 500], [1330, 620], [1240, 690], [1120, 860], [980, 700],
            [760, 660], [520, 690], [300, 620], [200, 400]];
}

/// Every observation point along the circuit, in order. Sampled by DISTANCE rather than per leg, so
/// the explorer moves at a constant speed - a walker that crosses a short leg as fast as a long one
/// visibly accelerates, and it is the first thing anyone notices in a loop.
function cht_gif_samples() {
    var _path = cht_gif_path();
    var _out = [];
    for (var _i = 1; _i < array_length(_path); _i++) {
        var _a = _path[_i - 1], _b = _path[_i];
        var _n = max(2, ceil(point_distance(_a[0], _a[1], _b[0], _b[1]) / 16));
        for (var _k = 0; _k < _n; _k++) {
            array_push(_out, [lerp(_a[0], _b[0], _k / _n), lerp(_a[1], _b[1], _k / _n)]);
        }
    }
    return _out;
}

/// Render every GIF frame, verify the ink on a sample, and end the game.
function cht_gif_main() {
    exception_unhandled_handler(function(_ex) {
        var _msg = "CRASH during gif: " + string(_ex.message);
        show_debug_message("CHARTER GIF " + _msg);
        var _f = file_text_open_write("charter_gif.json");
        file_text_write_string(_f, "{\"ran\":false,\"blocked\":true,\"reason\":\"" + _msg + "\"}");
        file_text_writeln(_f);
        file_text_close(_f);
        game_end(1);
    });

    // An UNEXPLORED chart - the whole point is watching it fill in.
    var _c = cht_bk_demo_chart("vellum", "chancery", false);
    var _samples = cht_gif_samples();
    var _total = array_length(_samples);
    var _fed = 0;
    var _bad = 0;
    var _lines = [];

    for (var _i = 0; _i < CHT_GIF_FRAMES; _i++) {
        // Hold the first few frames on bare parchment so a looping GIF opens on the "before"
        // rather than mid-way through. Without the hold the loop reads as a chart that flickers.
        var _hold = 6;
        var _t = clamp((_i - _hold) / max(1, CHT_GIF_FRAMES - _hold - 4), 0, 1);
        var _target = round(_t * _total);
        while (_fed < _target) {
            cht_chart_observe(_c, _samples[_fed][0], _samples[_fed][1]);
            _fed++;
        }

        var _surf = surface_create(CHT_GIF_W, CHT_GIF_H);
        if (!surface_exists(_surf)) {
            _bad++;
            array_push(_lines, "frame " + string(_i) + ": surface_create failed");
            continue;
        }
        surface_set_target(_surf);
        draw_clear(cht_page("vellum").fog);
        cht_chart_draw(_c, 0, 0, CHT_GIF_W, CHT_GIF_H, {});

        // The explorer's own marker, in the page's accent - the same two parts the demo room draws.
        if (_fed > 0) {
            var _w = _samples[max(0, _fed - 1)];
            var _p = cht_chart_w2p(_c, _w[0], _w[1], 0, 0, CHT_GIF_W, CHT_GIF_H);
            cht_draw_parts([cht_ring(_p[0], _p[1], 6, 1.6, CHT_R_ACCENT),
                            cht_dot(_p[0], _p[1], 2.4, CHT_R_ACCENT)], cht_page("vellum"), 1);
        }
        surface_reset_target();

        // Measure a SAMPLE rather than every frame: the ink box is a full surface read and 84 of
        // them is minutes, not seconds. First, middle and last catch a page that never draws, one
        // that has stopped drawing, and one that runs off an edge.
        if (_i == 0 || _i == floor(CHT_GIF_FRAMES / 2) || _i == CHT_GIF_FRAMES - 1) {
            var _ink = cht_bk_ink_bounds(_surf, cht_page("vellum").fog);
            if (!_ink.ok) {
                _bad++;
                array_push(_lines, "frame " + string(_i) + " drew NOTHING");
            } else {
                show_debug_message("CHARTER GIF  frame " + string(_i) + "  ink "
                    + string(_ink.x0) + ".." + string(_ink.x1) + " x "
                    + string(_ink.y0) + ".." + string(_ink.y1));
            }
        }

        var _n = string(_i);
        while (string_length(_n) < 3) _n = "0" + _n;
        surface_save(_surf, "gifframe_" + _n + ".png");
        surface_free(_surf);
    }

    // The LAST frame must be substantially more explored than the FIRST, or the GIF is a still.
    // A loop that renders 84 identical frames passes every other check in this function: the ink
    // box is happy, the frame count is right, and nothing moves.
    //
    // ⚠️ READ BEFORE THE FREE. cht_chart_free only releases the cached surface and the counters
    // would survive it, but reading a struct after handing it to something called `free` is how a
    // later edit turns a correct line into a use-after-free.
    var _progress = cht_chart_progress(_c);
    cht_chart_free(_c);

    if (_progress < 0.20) {
        _bad++;
        array_push(_lines, "the walk revealed only "
            + string_format(_progress * 100, 1, 1) + "% of the chart - the GIF barely moves");
    }

    var _json = "{\"ran\":true,\"blocked\":false,\"frames\":" + string(CHT_GIF_FRAMES)
        + ",\"bad\":" + string(_bad)
        + ",\"progress\":" + string_format(_progress, 1, 3)
        + ",\"width\":" + string(CHT_GIF_W) + ",\"height\":" + string(CHT_GIF_H)
        + ",\"product\":\"Charter\",\"version\":\"" + CHT_VERSION + "\"}";

    var _f = file_text_open_write("charter_gif.json");
    file_text_write_string(_f, _json);
    file_text_writeln(_f);
    for (var _i = 0; _i < array_length(_lines); _i++) {
        file_text_write_string(_f, "BAD " + _lines[_i]);
        file_text_writeln(_f);
    }
    file_text_close(_f);

    show_debug_message("CHARTER_GIF_JSON_BEGIN");
    show_debug_message(_json);
    show_debug_message("CHARTER_GIF_JSON_END");
    game_end(_bad == 0 ? 0 : 1);
}

/// ============================================================================================
/// THE RUN
/// ============================================================================================

/// The bounding box of everything that is not the page ground, as {x0,y0,x1,y1,ok}.
/// `ok` is false when the sheet is entirely blank.
function cht_bk_ink_bounds(_surf, _ground) {
    var _w = surface_get_width(_surf), _h = surface_get_height(_surf);
    var _buf = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_buf, _surf, 0);
    var _gr = colour_get_red(_ground), _gg = colour_get_green(_ground), _gb = colour_get_blue(_ground);
    var _x0 = _w, _y0 = _h, _x1 = -1, _y1 = -1;
    // Stride 2. A 1px hairline can be missed, and nothing this sheet set cares about is 1px wide;
    // 1.7M buffer_peek calls per sheet is not worth the precision.
    var _step = 2;
    for (var _y = 0; _y < _h; _y += _step) {
        var _row = _y * _w * 4;
        for (var _x = 0; _x < _w; _x += _step) {
            var _o = _row + _x * 4;
            var _r = buffer_peek(_buf, _o,     buffer_u8);
            var _g = buffer_peek(_buf, _o + 1, buffer_u8);
            var _b = buffer_peek(_buf, _o + 2, buffer_u8);
            // 10/255 of slack absorbs the encoder's rounding without letting real ink hide.
            if (abs(_r - _gr) <= 10 && abs(_g - _gg) <= 10 && abs(_b - _gb) <= 10) continue;
            if (_x < _x0) _x0 = _x;
            if (_x > _x1) _x1 = _x;
            if (_y < _y0) _y0 = _y;
            if (_y > _y1) _y1 = _y;
        }
    }
    buffer_delete(_buf);
    return { x0: _x0, y0: _y0, x1: _x1, y1: _y1, ok: (_x1 >= 0) };
}

/// Render one sheet to a PNG and report its measured extent AND its measured ink box.
///
/// ⛔ THE FIELD IS `extent`, NEVER `end`. `end` is a GML RESERVED WORD - the legacy synonym for
/// `}` - so `{ end: -1 }` fails to parse with "unexpected symbol ':' in expression", reported
/// against the line ABOVE it, which reads exactly like a typo somewhere else. This wing spent two
/// builds on that before the keyword became the suspect rather than the punctuation.
function cht_bk_render(_name, _fn, _ground) {
    var _surf = surface_create(CHT_SHEET_W, CHT_SHEET_H);
    if (!surface_exists(_surf)) {
        var _bad = { x0: 0, y0: 0, x1: -1, y1: -1, ok: false };
        return { extent: -1, ink: _bad };
    }
    surface_set_target(_surf);
    draw_clear(_ground);
    var _reached = _fn();
    surface_reset_target();
    var _ink = cht_bk_ink_bounds(_surf, _ground);
    surface_save(_surf, _name + ".png");
    surface_free(_surf);
    return { extent: _reached, ink: _ink };
}

/// Render every sheet, write an evidence block, and end the game.
function cht_bake_main() {
    // Same crash handler as the suite, for the same reason: a GML runtime error opens a modal
    // dialog and headless there is nobody to dismiss it, so the process hangs instead of failing.
    exception_unhandled_handler(function(_ex) {
        var _msg = "CRASH during bake: " + string(_ex.message);
        show_debug_message("CHARTER BAKE " + _msg);
        var _f = file_text_open_write("charter_bake.json");
        file_text_write_string(_f, "{\"ran\":false,\"blocked\":true,\"reason\":\"" + _msg + "\"}");
        file_text_writeln(_f);
        file_text_close(_f);
        game_end(1);
    });

    var _names = ["sheet_1_hero", "sheet_2_corpus", "sheet_3_silhouette", "sheet_4_hands",
                  "sheet_5_states", "sheet_6_pages", "sheet_7_furniture", "sheet_8_system",
                  "sheet_9_nocturne"];
    var _fns   = [cht_bk_hero, cht_bk_corpus, cht_bk_silhouette, cht_bk_hands,
                  cht_bk_states, cht_bk_pages, cht_bk_furniture, cht_bk_system,
                  cht_bk_hero_night];
    // Each sheet is measured against ITS OWN background. The two hero sheets are whole chart pages
    // and clear to that page's unpainted fog; a nocturne page measured against vellum would report
    // 100% ink and prove nothing at all.
    var _grounds = [cht_page("vellum").fog, cht_bk_page().ground, cht_bk_page().ground,
                    cht_bk_page().ground, cht_bk_page().ground, cht_bk_page().ground,
                    cht_bk_page().ground, cht_bk_page().ground, cht_page("nocturne").fog];
    // ⛔ FULL-BLEED SHEETS ARE MEASURED THE OTHER WAY ROUND, AND THIS IS NOT AN EXEMPTION.
    // The first run flagged sheet_1_hero for "ink at x=1594 on a 1600px surface - something runs
    // off the RIGHT EDGE". Nothing runs off it: the hero IS a chart page filling the whole sheet,
    // and the ink at 1594 is its deckle edge, drawn exactly where it was asked to be. A rule that
    // fires on a sheet doing precisely its job is a false red, and a false red costs what a false
    // green does - here it would have been paid by cropping the best image in the gallery.
    //
    // But the answer is NOT to skip the check. For a full-bleed sheet the interesting failure is
    // the OPPOSITE one: the page not reaching the edge, leaving a band of dead surface down one
    // side. So the test inverts - ink must arrive within `_edge` of all four sides - and every
    // sheet still gets a measurement it can fail.
    var _bleed = [true, false, false, false, false, false, false, false, true];

    var _lines = [];
    var _clipped = 0;
    var _edge = 6;
    var _min_fill_x = 0.86;
    var _min_fill_y = 0.80;

    for (var _i = 0; _i < array_length(_names); _i++) {
        var _res = cht_bk_render(_names[_i], _fns[_i], _grounds[_i]);
        var _reached = _res.extent;
        var _ink = _res.ink;
        var _ok = (_reached > 0 && _reached <= CHT_SHEET_H);
        if (!_ok) {
            _clipped++;
            array_push(_lines, _names[_i] + " finished drawing at y=" + string(_reached)
                + " on a " + string(CHT_SHEET_H) + "px surface");
        }
        var _note = "";
        if (!_ink.ok) {
            _clipped++;
            array_push(_lines, _names[_i] + " drew NOTHING - the surface is bare page ground");
        } else if (_bleed[_i]) {
            _note = "  ink " + string(_ink.x0) + ".." + string(_ink.x1)
                  + " x " + string(_ink.y0) + ".." + string(_ink.y1) + "  FULL BLEED";
            if (_ink.x0 > _edge || _ink.y0 > _edge
             || _ink.x1 < CHT_SHEET_W - _edge || _ink.y1 < CHT_SHEET_H - _edge) {
                _clipped++;
                array_push(_lines, _names[_i] + " is a FULL-BLEED page and does not reach its own"
                    + " edges: ink " + string(_ink.x0) + ".." + string(_ink.x1)
                    + " x " + string(_ink.y0) + ".." + string(_ink.y1)
                    + " on " + string(CHT_SHEET_W) + "x" + string(CHT_SHEET_H));
                _note += "  SHORT";
            }
        } else {
            var _fx = (_ink.x1 - _ink.x0) / CHT_SHEET_W;
            var _fy = (_ink.y1 - _ink.y0) / CHT_SHEET_H;
            _note = "  ink " + string(_ink.x0) + ".." + string(_ink.x1)
                  + " x " + string(_ink.y0) + ".." + string(_ink.y1)
                  + "  fill " + string_format(_fx * 100, 1, 0) + "%/"
                  + string_format(_fy * 100, 1, 0) + "%";
            if (_ink.x1 >= CHT_SHEET_W - _edge) {
                _clipped++;
                array_push(_lines, _names[_i] + " has ink at x=" + string(_ink.x1)
                    + " on a " + string(CHT_SHEET_W) + "px surface - something runs off the RIGHT EDGE");
                _note += "  CLIPPED-X";
            }
            if (_ink.y1 >= CHT_SHEET_H - _edge) {
                _clipped++;
                array_push(_lines, _names[_i] + " has ink at y=" + string(_ink.y1)
                    + " on a " + string(CHT_SHEET_H) + "px surface - something runs off the BOTTOM");
                _note += "  CLIPPED-Y";
            }
            if (_fx < _min_fill_x) {
                _clipped++;
                array_push(_lines, _names[_i] + " ink spans only "
                    + string_format(_fx * 100, 1, 0) + "% of the WIDTH - the rest is empty page");
                _note += "  THIN-X";
            }
            if (_fy < _min_fill_y) {
                _clipped++;
                array_push(_lines, _names[_i] + " ink spans only "
                    + string_format(_fy * 100, 1, 0) + "% of the HEIGHT - the rest is empty page");
                _note += "  THIN-Y";
            }
        }
        show_debug_message("CHARTER BAKE  " + _names[_i] + "  extent " + string(_reached)
            + " / " + string(CHT_SHEET_H) + (_ok ? "  ok" : "  CLIPPED") + _note);
    }

    var _json = "{\"ran\":true,\"blocked\":false,\"sheets\":" + string(array_length(_names))
        + ",\"clipped\":" + string(_clipped)
        + ",\"width\":" + string(CHT_SHEET_W) + ",\"height\":" + string(CHT_SHEET_H)
        + ",\"product\":\"Charter\",\"version\":\"" + CHT_VERSION + "\"}";

    var _f = file_text_open_write("charter_bake.json");
    file_text_write_string(_f, _json);
    file_text_writeln(_f);
    for (var _i = 0; _i < array_length(_lines); _i++) {
        file_text_write_string(_f, "CLIPPED " + _lines[_i]);
        file_text_writeln(_f);
    }
    file_text_close(_f);

    show_debug_message("CHARTER_BAKE_JSON_BEGIN");
    show_debug_message(_json);
    show_debug_message("CHARTER_BAKE_JSON_END");
    game_end(_clipped == 0 ? 0 : 1);
}
