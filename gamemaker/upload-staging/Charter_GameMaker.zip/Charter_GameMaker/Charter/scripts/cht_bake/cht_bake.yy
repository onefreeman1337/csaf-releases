{
  "$GMScript": "v1",
  "%Name": "cht_bake",
  "isCompatibility": false,
  "isDnD": false,
  "name": "cht_bake",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}