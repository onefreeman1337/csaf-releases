/// ============================================================================================
/// CHARTER - cht_render: the ONLY file in this package that talks to the GPU.
///
/// Everything above this file produces DATA. cht_marks returns arrays of structs, cht_chart keeps
/// a grid and a registry, cht_label returns text with coordinates attached. None of them can draw
/// and none of them knows what a surface is. This file turns all of it into draw calls and knows
/// nothing about what a `barrow`, a `rumour` or a `saltern` means.
///
/// That split is not tidiness. It is what lets cht_selftest assert the entire corpus, the whole
/// coordinate contract and the whole discovery system HEADLESSLY, on a machine with no window - and
/// this wing's constitution is explicit that GML has no other route to an automated test.
///
/// -- COORDINATES: ABSOLUTE PAGE PIXELS ---------------------------------------------------------
/// A part reaching this file has already been placed: its coordinates ARE pixels and its widths ARE
/// pixels. cht_place / cht_place_mark did that mapping. So there is no cx/cy/scale triple in any
/// signature here, unlike the donor renderer this wing has shipped four times - a chart page is not
/// an icon in a slot, and pretending it is would put a second coordinate space in the one file that
/// most needs to be dull.
///
/// -- STATE IS SAVED AND RESTORED, EVERY ENTRY POINT --------------------------------------------
/// Colour, alpha, font, halign, valign, blend mode. A renderer that leaks GPU state into a buyer's
/// Draw event produces a bug three files away from its cause, in their code, which they cannot
/// reproduce and we cannot debug remotely. Every public function here puts back what it found.
/// ============================================================================================

/// The stroke floor. NOT a rounding tweak and NOT tunable per call.
///
/// Stroke widths in this package are a PROPORTION of the mark, so a landmark drawn at 14px on a
/// chart has a hairline of 0.011 * 14 = 0.15px and GameMaker draws nothing at all. Without a floor
/// the corpus renders beautifully on a 1600px store sheet and DISSOLVES at the size a buyer's
/// players actually see - the failure they find in playtest and we never would.
///
/// ⛔ AND A SINGLE 0.55px FLOOR DID NOT ACHIEVE THAT. Measured 2026-08-22 by baking the silhouette
/// sheet and LOOKING AT IT: the 44 marks at 14px were grey dust, and the sheet's own headline -
/// "every mark is designed to be identifiable at 14 pixels" - was disproved by the picture printed
/// underneath it. A 0.55px line is a half-covered pixel, so every stroke rendered at roughly half
/// intensity and the shapes never resolved. Nothing mechanical could have caught this: the geometry
/// was correct, the extent check was green, the ink-bounds check was green, and 369 assertions
/// passed. It took opening the PNG.
///
/// ⚠️ THE FLOOR IS PER-ROLE, AND THAT IS THE WHOLE FIX. Raising one global floor to 1.0 would have
/// made every terrain hairline a solid black line and turned the page from a chart into a
/// woodcut - the hatch is SUPPOSED to be faint, it is the second read. The five roles already
/// encode exactly this distinction, so the floor uses them: a line that carries IDENTIFICATION
/// gets a whole pixel, and a line that carries TEXTURE keeps the half-covered one.
#macro CHT_W_FLOOR_INK   1.00
#macro CHT_W_FLOOR_HATCH 0.55

function cht_w_floor(_role) {
    return (_role == CHT_R_HATCH) ? CHT_W_FLOOR_HATCH : CHT_W_FLOOR_INK;
}

/// Resolve a label's size to one of the two shipped fonts.
function cht_font(_size) {
    return (_size == CHT_LB_TITLE) ? fnt_charter_title : fnt_charter;
}

/// Read a boolean out of an options struct, defaulting to ON.
///
/// ⚠️ A TOP-LEVEL FUNCTION, NOT A LOCAL `var _f = function(...)`. A function literal assigned to a
/// local is a METHOD in GML, bound to whatever `self` was at the point it was created - and this
/// file is called from a script, from the demo object's Draw GUI event and from the headless bake
/// entry point, which are three different selves. cht_geom's header records the session this wing
/// lost to exactly that binding rule (a struct with a next() method whose generator state did not
/// stay with the generator). Four lines at file scope are cheaper than rediscovering it.
function cht_opt(_o, _k) {
    if (!variable_struct_exists(_o, _k)) return true;
    return variable_struct_get(_o, _k);
}

/// ============================================================================================
/// PRIMITIVES
/// ============================================================================================

/// Draw one placed part. Internal - call cht_draw_parts.
function cht_draw_part(_p, _page) {
    draw_set_colour(cht_page_colour(_page, _p.role));

    switch (_p.kind) {

        case CHT_DOT:
            draw_circle(_p.cx, _p.cy, max(0.4, _p.r), false);
            return;

        case CHT_ARC: {
            // Sampled, not draw_circle's outline: an arc here may be partial, and GameMaker's
            // circle outline ignores line width - and width carries meaning across this whole
            // corpus, from a hairline flute to a heavy wall.
            var _sweep = abs(_p.a1 - _p.a0);
            var _steps = max(10, ceil(_sweep * 14));
            var _w = max(cht_w_floor(_p.role), _p.w);
            var _px = _p.cx + cos(_p.a0) * _p.r;
            var _py = _p.cy + sin(_p.a0) * _p.r;
            for (var _i = 1; _i <= _steps; _i++) {
                var _a = lerp(_p.a0, _p.a1, _i / _steps);
                var _nx = _p.cx + cos(_a) * _p.r;
                var _ny = _p.cy + sin(_a) * _p.r;
                draw_line_width(_px, _py, _nx, _ny, _w);
                _px = _nx; _py = _ny;
            }
            return;
        }

        case CHT_FILL: {
            var _n = array_length(_p.pts);
            if (_n < 3) return;
            draw_primitive_begin(pr_trianglefan);
            for (var _i = 0; _i < _n; _i++) draw_vertex(_p.pts[_i][0], _p.pts[_i][1]);
            draw_primitive_end();
            return;
        }

        case CHT_STRIP: {
            // ONE primitive, not N quads. Adjacent triangles in a strip share their edges; drawing
            // the same band as separate quads leaves a hairline of page showing through every join,
            // which on a river or a route reads as a dotted line rather than as a line.
            var _n = min(array_length(_p.a), array_length(_p.b));
            if (_n < 2) return;
            draw_primitive_begin(pr_trianglestrip);
            for (var _i = 0; _i < _n; _i++) {
                draw_vertex(_p.a[_i][0], _p.a[_i][1]);
                draw_vertex(_p.b[_i][0], _p.b[_i][1]);
            }
            draw_primitive_end();
            return;
        }

        default: {
            var _n = array_length(_p.pts);
            if (_n < 2) return;
            var _w = max(cht_w_floor(_p.role), _p.w);
            for (var _i = 1; _i < _n; _i++) {
                draw_line_width(_p.pts[_i - 1][0], _p.pts[_i - 1][1],
                                _p.pts[_i][0], _p.pts[_i][1], _w);
            }
            if (_p.closed) {
                draw_line_width(_p.pts[_n - 1][0], _p.pts[_n - 1][1],
                                _p.pts[0][0], _p.pts[0][1], _w);
            }
            return;
        }
    }
}

/// Draw a placed part list on a page. _alpha is optional and is what fades a rumour.
function cht_draw_parts(_parts, _page, _alpha) {
    if (is_undefined(_alpha)) _alpha = 1;
    var _oldC = draw_get_colour(), _oldA = draw_get_alpha();
    if (_alpha != 1) draw_set_alpha(_alpha);
    var _n = array_length(_parts);
    for (var _i = 0; _i < _n; _i++) cht_draw_part(_parts[_i], _page);
    draw_set_colour(_oldC);
    draw_set_alpha(_oldA);
}

/// Draw a label list.
function cht_draw_labels(_labels, _page, _alpha) {
    if (is_undefined(_alpha)) _alpha = 1;
    var _oldC = draw_get_colour(), _oldA = draw_get_alpha();
    var _oldF = draw_get_font(), _oldH = draw_get_halign(), _oldV = draw_get_valign();
    var _n = array_length(_labels);
    for (var _i = 0; _i < _n; _i++) {
        var _lb = _labels[_i];
        draw_set_font(cht_font(_lb.size));
        draw_set_halign(_lb.ha);
        draw_set_valign(_lb.va);
        draw_set_colour(cht_page_colour(_page, _lb.role));
        draw_set_alpha(_alpha * _lb.alpha);
        // Transformed even at angle 0 and scale 1: one code path, so a tilted label and a level
        // one cannot drift apart in their kerning or their baseline.
        draw_text_transformed(_lb.x, _lb.y, _lb.text, _lb.scale, _lb.scale, _lb.angle);
    }
    draw_set_font(_oldF);
    draw_set_halign(_oldH);
    draw_set_valign(_oldV);
    draw_set_colour(_oldC);
    draw_set_alpha(_oldA);
}

/// ============================================================================================
/// ONE MARK
/// ============================================================================================

/// Compose one landmark mark through the full pipeline and return the PLACED parts.
///
/// ⛔ THE ORDER OF THESE FOUR CALLS IS THE COORDINATE CONTRACT AND IS NOT INTERCHANGEABLE.
///   cht_mark          authoring box, [-0.5, 0.5]
///   cht_hand_apply    still the authoring box - its jitter and overshoot are in AUTHORING units,
///                     so applied after placement a `field` hand would wobble a mark by 0.03 of a
///                     PIXEL and do visibly nothing
///   cht_state_apply   still the authoring box - a sighted mark demotes fills to CHT_W_FINE, an
///                     authored weight, which cht_place_mark then scales
///   cht_place_mark    authoring box -> page pixels, coordinates AND widths
function cht_mark_parts(_kind, _hand, _state, _cx, _cy, _s, _seed, _rot) {
    if (is_undefined(_rot)) _rot = 0;
    var _p = cht_mark(_kind);
    _p = cht_hand_apply(_p, _hand, _seed);
    _p = cht_state_apply(_p, _state);
    return cht_place_mark(_p, _cx, _cy, _s, _rot, undefined);
}

/// Draw one landmark mark. The function most buyers call first.
///
/// It composes every call, which is right for a store sheet, a legend or a menu and wasteful for
/// a chart of two hundred landmarks redrawn every frame - which is what the chart's own dirty
/// surface (cht_chart_draw_cached) is for.
function cht_draw_mark(_kind, _page, _hand, _state, _cx, _cy, _s, _seed, _alpha) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_page) || !is_struct(_hand)) return;
    if (is_undefined(_seed)) _seed = cht_hash32(_kind);
    cht_draw_parts(cht_mark_parts(_kind, _hand, _state, _cx, _cy, _s, _seed, 0), _page, _alpha);
}

/// ============================================================================================
/// LABEL COLLISION
///
/// ⚠️ MEASURING A STRING NEEDS A FONT, WHICH IS WHY THIS LIVES HERE AND NOT IN cht_label.
/// string_width is a GPU-side query against the currently-set font, so it is the one part of
/// label layout that cannot be done in the geometry layer. cht_label produces the label; this file
/// is the only thing that can ask how wide it turned out.
/// ============================================================================================

/// The screen rectangle a label will occupy, as [x0, y0, x1, y1].
function cht_label_box(_lb) {
    var _old = draw_get_font();
    draw_set_font(cht_font(_lb.size));
    var _w = string_width(_lb.text) * _lb.scale;
    var _h = string_height(_lb.text) * _lb.scale;
    draw_set_font(_old);
    var _x = _lb.x, _y = _lb.y;
    if (_lb.ha == fa_center) _x -= _w * 0.5;
    else if (_lb.ha == fa_right) _x -= _w;
    if (_lb.va == fa_middle) _y -= _h * 0.5;
    else if (_lb.va == fa_bottom) _y -= _h;
    // A two-pixel gutter, so two names that merely touch still count as colliding. Names that
    // abut with no gap read as one longer name, which is the defect this is here to prevent.
    return [_x - 2, _y - 2, _x + _w + 2, _y + _h + 2];
}

/// Does this box overlap any box already placed?
function cht_boxes_hit(_box, _taken) {
    for (var _i = 0; _i < array_length(_taken); _i++) {
        var _t = _taken[_i];
        if (_box[0] < _t[2] && _box[2] > _t[0] && _box[1] < _t[3] && _box[3] > _t[1]) return true;
    }
    return false;
}

/// A representative point for a part, used to decide whether it falls on revealed ground.
///
/// ⚠️ ONE POINT PER PART, ON PURPOSE. Testing every vertex would let a single tree straddling the
/// fog boundary be half-drawn, and a half-drawn tree is worse than an absent one. Terrain symbols
/// are small relative to a discovery cell, so the anchor is a good proxy and the boundary stays
/// crisp.
function cht_part_anchor(_p) {
    switch (_p.kind) {
        case CHT_DOT:   return [_p.cx, _p.cy];
        case CHT_ARC:   return [_p.cx, _p.cy];
        case CHT_STRIP: return [_p.a[0][0], _p.a[0][1]];
        default:        return [_p.pts[0][0], _p.pts[0][1]];
    }
}

/// Keep only the parts whose anchor lands on ground the player has revealed.
function cht_parts_in_seen(_parts, _chart, _x0, _y0, _x1, _y1) {
    var _out = [];
    for (var _i = 0; _i < array_length(_parts); _i++) {
        var _a = cht_part_anchor(_parts[_i]);
        var _w = cht_chart_p2w(_chart, _a[0], _a[1], _x0, _y0, _x1, _y1);
        if (cht_chart_seen_at(_chart, _w[0], _w[1])) array_push(_out, _parts[_i]);
    }
    return _out;
}

/// ============================================================================================
/// THE PAGE
/// ============================================================================================

/// The revealed ground, painted over the unpainted parchment.
///
/// -- WHY IT IS THREE PASSES AND NOT ONE --------------------------------------------------------
/// The obvious implementation draws one irregular blob per revealed cell and lets them overlap.
/// It produces a lovely torn boundary and it also leaves PINHOLES between four adjacent blobs in
/// the middle of a fully-explored region, because a lobed blob of radius 0.8 cells does not quite
/// reach the corner where four cells meet. A hole in the middle of ground the player has walked
/// across reads as a bug, and it is one.
///
/// So: solid rectangles first, guaranteeing no interior hole; irregular blobs only on the BOUNDARY
/// cells, bulging the edge outward; then fog-coloured blobs biting back in from the unrevealed
/// side. Two directions of irregularity is what makes the boundary look torn rather than
/// airbrushed - a wash that only ever bulges outward reads as a soft-edged circle.
function cht_draw_reveal(_chart, _page, _x0, _y0, _x1, _y1) {
    var _cw = (_x1 - _x0) / _chart.cols;
    var _ch = (_y1 - _y0) / _chart.rows;
    var _oldC = draw_get_colour();

    // Pass A - solid interior. Half a pixel of overlap kills the seam between adjacent rectangles
    // that GameMaker's rasteriser would otherwise leave on a non-integer grid.
    draw_set_colour(_page.ground);
    for (var _row = 0; _row < _chart.rows; _row++) {
        for (var _col = 0; _col < _chart.cols; _col++) {
            if (_chart.seen[_row * _chart.cols + _col] == 0) continue;
            var _px = _x0 + _col * _cw, _py = _y0 + _row * _ch;
            draw_rectangle(_px - 0.5, _py - 0.5, _px + _cw + 0.5, _py + _ch + 0.5, false);
        }
    }

    // Pass B and C - the torn boundary. Both blobs are deterministic from the cell index, so the
    // coastline of the explored region is stable forever; a boundary that re-tore every frame is
    // the one defect a buyer would notice instantly and could not work around.
    var _bulge = [];
    var _bite = [];
    for (var _row = 0; _row < _chart.rows; _row++) {
        for (var _col = 0; _col < _chart.cols; _col++) {
            var _i = _row * _chart.cols + _col;
            var _me = (_chart.seen[_i] == 1);
            var _edge = false;
            if (cht_chart_seen(_chart, _col - 1, _row) != _me) _edge = true;
            if (cht_chart_seen(_chart, _col + 1, _row) != _me) _edge = true;
            if (cht_chart_seen(_chart, _col, _row - 1) != _me) _edge = true;
            if (cht_chart_seen(_chart, _col, _row + 1) != _me) _edge = true;
            if (!_edge) continue;
            var _cx = _x0 + (_col + 0.5) * _cw, _cy = _y0 + (_row + 0.5) * _ch;
            var _seed = _chart.seed + _i * 7919;
            if (_me) {
                array_push(_bulge, cht_ring_fill(
                    cht_pts_lobed(_cx, _cy, _cw * 0.78, _ch * 0.78, 9, 0.30, _seed),
                    CHT_R_INK, _cx, _cy));
            } else {
                array_push(_bite, cht_ring_fill(
                    cht_pts_lobed(_cx, _cy, _cw * 0.42, _ch * 0.42, 8, 0.42, _seed + 31),
                    CHT_R_INK, _cx, _cy));
            }
        }
    }
    // Drawn with explicit colours rather than through cht_draw_parts, because these two passes are
    // the one place in the product where geometry is coloured by which SIDE of the boundary it is
    // on rather than by its role.
    draw_set_colour(_page.ground);
    for (var _i = 0; _i < array_length(_bulge); _i++) cht_draw_raw_fill(_bulge[_i]);
    draw_set_colour(_page.fog);
    for (var _i = 0; _i < array_length(_bite); _i++) cht_draw_raw_fill(_bite[_i]);

    draw_set_colour(_oldC);
}

/// Draw a CHT_FILL part in whatever colour is already set. Internal to the reveal pass.
function cht_draw_raw_fill(_p) {
    var _n = array_length(_p.pts);
    if (_n < 3) return;
    draw_primitive_begin(pr_trianglefan);
    for (var _i = 0; _i < _n; _i++) draw_vertex(_p.pts[_i][0], _p.pts[_i][1]);
    draw_primitive_end();
}

/// The route the player actually walked, as a survey line with periodic ticks.
function cht_route_parts(_chart, _x0, _y0, _x1, _y1) {
    var _n = array_length(_chart.route);
    if (_n < 2) return [];
    var _pts = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        _pts[_i] = cht_chart_w2p(_chart, _chart.route[_i][0], _chart.route[_i][1],
                                 _x0, _y0, _x1, _y1);
    }
    var _out = [cht_poly(_pts, false, 1.4, CHT_R_ACCENT)];
    // Cross ticks every twelfth point, perpendicular to the walk. A plain line is a line; a line
    // with survey ticks on it is a RECORD of a journey, which is what the trail is claiming to be.
    for (var _i = 6; _i < _n - 1; _i += 12) {
        var _ax = _pts[_i][0], _ay = _pts[_i][1];
        var _bx = _pts[_i + 1][0], _by = _pts[_i + 1][1];
        var _dx = _bx - _ax, _dy = _by - _ay;
        var _l = point_distance(0, 0, _dx, _dy);
        if (_l < 0.001) continue;
        var _nx = -_dy / _l * 3.0, _ny = _dx / _l * 3.0;
        array_push(_out, cht_poly([[_ax - _nx, _ay - _ny], [_ax + _nx, _ay + _ny]],
                                  false, 1.0, CHT_R_ACCENT));
    }
    return _out;
}

/// ============================================================================================
/// THE WHOLE CHART
/// ============================================================================================

/// Draw a chart into a page rectangle, immediately.
///
/// @param _opts  OPTIONAL struct. `labels` (default true), `rose` (true), `title` (true),
///               `scale_bar` (true), `route` (true), `foxing` (true). A buyer drawing the chart as
///               a small corner panel turns the furniture off and keeps the marks.
///
/// This is the function the whole package exists to provide, and it is deliberately ONE call: a
/// product whose quickstart is fourteen lines of setup is a product with a bad quickstart.
function cht_chart_draw(_chart, _x0, _y0, _x1, _y1, _opts) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_chart)) return;
    if (is_undefined(_opts)) _opts = {};
    var _page = cht_page(_chart.page_id);
    var _hand = cht_hand(_chart.hand_id);
    var _w = _x1 - _x0, _h = _y1 - _y0;
    var _small = min(_w, _h);

    var _oldC = draw_get_colour(), _oldA = draw_get_alpha();

    // 1. THE SHEET. Unpainted parchment, with its own torn outline - so the page is a sheet lying
    //    on the buyer's own background rather than a rectangle cut out of it.
    var _amp = _small * 0.006;
    var _outline = cht_page_outline(_x0 + _amp, _y0 + _amp, _x1 - _amp, _y1 - _amp,
                                    _chart.edge, _amp, _chart.seed);
    draw_set_colour(_page.fog);
    cht_draw_raw_fill(cht_ring_fill(_outline, CHT_R_INK,
                                    (_x0 + _x1) * 0.5, (_y0 + _y1) * 0.5));

    // 2. THE REVEALED GROUND.
    cht_draw_reveal(_chart, _page, _x0, _y0, _x1, _y1);

    // 3. AGE. Foxing over both, so the sheet ages as one object rather than the explored half
    //    ageing and the unexplored half staying new.
    if (cht_opt(_opts, "foxing")) {
        cht_draw_parts(cht_foxing(_x0, _y0, _x1, _y1, 26, _chart.seed + 5), _page, 0.30);
    }

    // 4. TERRAIN, clipped to what the player has seen. A forest the player has never walked into
    //    is not on their chart, and that is the whole conceit.
    var _sym = clamp(_small * 0.014, 3.0, 12.0);
    for (var _i = 0; _i < array_length(_chart.regions); _i++) {
        var _rg = _chart.regions[_i];
        // ⚠️ THE FILL IS CACHED ON THE REGION, AND IT HAS TO BE. A scatter fill runs a jittered
        // lattice and a point-in-polygon test per candidate; eight regions on a full page is a few
        // thousand of each. That is fine once and ruinous at 60fps - and the chart is DIRTY on
        // almost every frame while a player is walking, so "only when dirty" is not the same as
        // "rarely". What actually changes as the player explores is which parts are DRAWN, not
        // which exist, so the geometry is generated once per page geometry and per hand, and only
        // the cheap seen-filter runs per frame.
        var _key = string(_x0) + "," + string(_y0) + "," + string(_x1) + "," + string(_y1)
                 + "," + string(_sym) + "," + string(_hand.hatch);
        if (!variable_struct_exists(_rg, "cache") || _rg.cache_key != _key) {
            var _poly = cht_chart_region_page(_chart, _rg, _x0, _y0, _x1, _y1);
            _rg.cache = cht_terrain_fill(_rg.terrain, _poly, _sym, _hand.hatch, _rg.seed);
            _rg.cache_key = _key;
        }
        cht_draw_parts(cht_parts_in_seen(_rg.cache, _chart, _x0, _y0, _x1, _y1), _page, 0.9);
    }

    // 5. ROUTE.
    if (cht_opt(_opts, "route")) cht_draw_parts(cht_route_parts(_chart, _x0, _y0, _x1, _y1), _page, 0.75);

    // 6. LANDMARKS, and their annotations.
    var _ms = clamp(_small * 0.055, 10, 46);
    var _labels = [];
    var _taken = [];
    // Declared HERE and not down in the furniture section where it is also used: GML hoists `var`
    // to function scope but assigns where the statement sits, so a later declaration would leave
    // this `undefined` for the whole label pass - and comparing a number against undefined is a
    // runtime error inside a buyer's draw event.
    var _inset = _small * 0.035;
    for (var _i = 0; _i < array_length(_chart.landmarks); _i++) {
        var _lm = _chart.landmarks[_i];
        if (!_lm.known) continue;
        var _wp = cht_chart_landmark_pos(_lm);
        var _p = cht_chart_w2p(_chart, _wp[0], _wp[1], _x0, _y0, _x1, _y1);
        var _s = _ms * _lm.scale;
        var _alpha = (_lm.state == CHT_ST_RUMOURED) ? 0.55
                   : ((_lm.state == CHT_ST_SIGHTED) ? 0.85 : 1.0);

        cht_draw_parts(cht_mark_parts(_lm.kind, _hand, _lm.state, _p[0], _p[1], _s, _lm.seed, 0),
                       _page, _alpha);

        if (_lm.state == CHT_ST_RUMOURED) {
            // The scribe's query, beside the rumour. This is the annotation that tells the player
            // the chart is guessing, and it is drawn rather than typeset so it stays in the hand.
            cht_draw_parts(cht_label_query(_p[0] + _s * 0.52, _p[1] - _s * 0.34, _s * 0.42),
                           _page, 0.8);
        } else if (_lm.state == CHT_ST_VISITED && cht_opt(_opts, "labels")) {
            // Only a VISITED place gets its name. A sighted one is a shape on the horizon and the
            // player has not been told what it is called - which is the product's argument again,
            // said in the label layer this time.
            //
            // ⛔ THE FOUR-WAY SEARCH IS NOT POLISH. Without it the hero chart printed
            // "WickthorSt Cuthman's" - two names landing on the same pixels and overprinting into
            // a word that is not a place. A chart whose labels collide is not a chart, it is a
            // draft, and no mechanical check in this package can see it: the ink-bounds test is
            // perfectly happy with two strings on top of each other.
            //
            // ⚠️ SIX CANDIDATES, AND THE LAST TWO HAVE NO LEADER. Four diagonal placements are
            // not enough for a landmark hard against a margin: on the 900px GIF page every one of
            // the four ran "The Whispering" off the right edge, and the loop's accept-anyway
            // fallback then shipped the clipped one. A name set CENTRED under its mark - the
            // ordinary cartographic treatment when there is no room for a leader - fits almost
            // anywhere, because it is only half a label wide either side of a point already on
            // the page.
            var _placed = false;
            for (var _try = 0; _try < 6 && !_placed; _try++) {
                // Preferred side first (away from the nearer edge), then the other three corners,
                // then centred below, then centred above.
                var _right = (_p[0] < (_x0 + _x1) * 0.5);
                var _up = (_p[1] > (_y0 + _y1) * 0.5);
                if (_try == 1) _right = !_right;
                if (_try == 2) _up = !_up;
                if (_try == 3) { _right = !_right; _up = !_up; }

                var _an;
                if (_try >= 4) {
                    var _dy = (_try == 4) ? (_s * 0.62) : (-_s * 0.62);
                    var _cl = cht_label_make(_lm.name, _p[0], _p[1] + _dy, fa_center,
                                             (_try == 4) ? fa_top : fa_bottom,
                                             CHT_R_INK, CHT_LB_BODY, 1.0, 0);
                    cht_label_hand(_cl, _hand);
                    _an = { parts: [], labels: [_cl] };
                } else {
                    _an = cht_label_annotation(_lm.name, _p[0], _p[1], _right, _up, _s, _hand);
                }
                var _lb = _an.labels[0];
                var _box = cht_label_box(_lb);
                // ⛔ THE PAGE EDGE IS A CONSTRAINT TOO, AND LEAVING IT OUT SHIPPED VISIBLY.
                // The first version only checked labels against each other, so a landmark near the
                // left or right margin got a name that ran off the sheet - "Hanging Grove" cut to
                // "anging Grove", "The Whispering" to "The Whisper". Caught on the GIF, where the
                // page is 900px wide and the margins are tighter than on a 1600px hero, which is
                // the useful part: the SAME chart drawn smaller is where a layout rule that only
                // works at one size gives itself away.
                var _fits = (_box[0] >= _x0 + _inset * 0.5) && (_box[2] <= _x1 - _inset * 0.5)
                         && (_box[1] >= _y0 + _inset * 0.5) && (_box[3] <= _y1 - _inset * 0.5);
                if (_try < 5 && (!_fits || cht_boxes_hit(_box, _taken))) continue;
                array_push(_taken, _box);
                cht_draw_parts(_an.parts, _page, 0.85);
                _labels = cht_append(_labels, _an.labels);
                _placed = true;
            }
        }
    }

    // 7. FURNITURE, over the ink. Border first so a mark near the edge sits under the rule rather
    //    than on top of it - a landmark drawn across the page border is the tell that the chart is
    //    a rectangle of pixels and not a sheet.
    cht_draw_parts(cht_border(_x0 + _amp, _y0 + _amp, _x1 - _amp, _y1 - _amp,
                              _chart.border, _inset, max(0.8, _small * 0.0035)), _page, 1);

    if (cht_opt(_opts, "rose")) {
        var _rr = clamp(_small * 0.085, 14, 70);
        cht_draw_parts(cht_rose(_chart.rose, _x1 - _inset - _rr * 1.25,
                                _y0 + _inset + _rr * 1.25, _rr, undefined), _page, 0.92);
    }

    if (cht_opt(_opts, "title") && _chart.title != "") {
        var _tw = clamp(_w * 0.42, 120, 520);
        var _th = clamp(_h * 0.11, 30, 90);
        var _tb = cht_label_title_block(_chart.cartouche,
                                        _x0 + _inset * 1.6, _y0 + _inset * 1.4,
                                        _x0 + _inset * 1.6 + _tw, _y0 + _inset * 1.4 + _th,
                                        _chart.title, _chart.subtitle, _hand, undefined);
        cht_draw_parts(_tb.parts, _page, 1);
        _labels = cht_append(_labels, _tb.labels);
    }

    if (cht_opt(_opts, "scale_bar")) {
        var _sb = cht_label_scale_bar(_x0 + _inset * 1.6, _y1 - _inset * 2.4,
                                      clamp(_w * 0.20, 60, 220), clamp(_h * 0.012, 4, 11),
                                      4, "leagues", _hand, undefined);
        cht_draw_parts(_sb.parts, _page, 0.9);
        _labels = cht_append(_labels, _sb.labels);
    }

    // 8. TEXT LAST, so nothing is drawn over a name.
    cht_draw_labels(_labels, _page, 1);

    // 9. The sheet's own edge, stroked over everything - the deckle has to read as the paper's
    //    boundary, which means it is in front of the ink that runs up to it.
    cht_draw_parts([cht_poly(_outline, true, max(0.9, _small * 0.003), CHT_R_HATCH)], _page, 0.7);

    draw_set_colour(_oldC);
    draw_set_alpha(_oldA);
}

/// ============================================================================================
/// THE CACHE
/// ============================================================================================

/// Draw the chart through its own surface, re-inking only when something has changed.
///
/// A full page is a few thousand draw calls. At 60fps with nothing moving, that is a few thousand
/// draw calls a frame to produce an identical picture - which is the difference between a chart a
/// buyer leaves on screen and one they hide behind a key press. cht_chart_touch is called by every
/// mutator in cht_chart, so the invalidation is not something a buyer has to remember.
///
/// ⚠️ SURFACES ARE VOLATILE. GameMaker frees them on a resolution change, an alt-tab, or at the
/// whim of the driver, so surface_exists is checked EVERY frame and not only at creation. A cached
/// renderer that assumes its surface survived is the commonest crash in GameMaker, and it happens
/// on the buyer's machine and not ours.
function cht_chart_draw_cached(_chart, _x0, _y0, _x1, _y1, _opts) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_chart)) return;
    var _w = max(1, ceil(_x1 - _x0)), _h = max(1, ceil(_y1 - _y0));

    if (_chart.surf >= 0 && (!surface_exists(_chart.surf)
        || _chart.surf_w != _w || _chart.surf_h != _h)) {
        if (surface_exists(_chart.surf)) surface_free(_chart.surf);
        _chart.surf = -1;
    }
    if (_chart.surf < 0) {
        _chart.surf = surface_create(_w, _h);
        _chart.surf_w = _w; _chart.surf_h = _h;
        _chart.dirty = true;
        if (!surface_exists(_chart.surf)) {
            // Out of video memory, or a driver that refused. Draw straight to the screen rather
            // than drawing nothing: a missing chart is a worse outcome than a slow one.
            _chart.surf = -1;
            cht_chart_draw(_chart, _x0, _y0, _x1, _y1, _opts);
            return false;
        }
    }

    if (_chart.dirty) {
        surface_set_target(_chart.surf);
        draw_clear_alpha(c_black, 0);
        // Drawn at the ORIGIN, then blitted. Drawing at _x0,_y0 into a surface whose own origin is
        // 0,0 is the classic off-by-a-page bug in every cached renderer ever written.
        cht_chart_draw(_chart, 0, 0, _w, _h, _opts);
        surface_reset_target();
        _chart.dirty = false;
    }
    draw_surface(_chart.surf, _x0, _y0);
    return true;
}

/// Release the chart's cached surface. Call it when the chart goes away - typically the Clean Up
/// event of whatever object owns it. Safe to call twice, and safe on a chart that never cached.
function cht_chart_free(_chart) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_chart)) return;
    if (_chart.surf >= 0 && surface_exists(_chart.surf)) surface_free(_chart.surf);
    _chart.surf = -1;
    _chart.surf_w = 0;
    _chart.surf_h = 0;
}

/// ============================================================================================
/// EXPORT
///
/// A generator that can only draw to the screen is half a tool. The obvious things to do with 44
/// marks in 4 hands is to put a sheet of them in a design document, hand one to an artist, or bake
/// a set for a project that would rather not compose at runtime - and all three need a file.
///
/// ⚠️ THE SANDBOX. Unless a project disables it, the path is relative to the game's own save area
/// (%LOCALAPPDATA%\<Game>\), NOT the working directory. That is not a limitation to route around:
/// it is the same path cht_selftest and cht_bake use to get results out of a headless build, and
/// this wing measured the two alternatives - the runner's -debugoutput flag and game_end's exit
/// code - both failing silently in a release build.
/// ============================================================================================

/// The largest surface either exporter will ATTEMPT, per side.
///
/// ⛔ WHY AN UPPER BOUND EXISTS AT ALL. Both exporters below already guarded the failure case with
/// `if (!surface_exists(_surf)) return false;` — which is the right intent and fires too late,
/// because the allocation is attempted first. MEASURED 2026-09-07 by the generated adversarial
/// harness: `cht_export_chart(chart, 99999, 99999, ...)` asks for a ~40 GB surface and the process
/// stops responding, so a caller who typos a size gets a HUNG GAME rather than a `false`. A hang
/// inside a bought library is the support ticket a seller cannot debug remotely.
///
/// ⚠️ IT REFUSES RATHER THAN CLAMPING, DELIBERATELY. Silently writing a 8192 px file when the
/// caller asked for 99999 would satisfy the return contract while producing an image nobody asked
/// for; both functions document their return as "whether it was written", so refusing is the
/// honest answer and the caller can see it.
#macro CHT_EXPORT_MAX_PX 8192

/// Render one mark to a transparent PNG, _px square. Returns whether it was written.
function cht_export_mark(_kind, _page_id, _hand_id, _state, _px, _file, _seed) {
    if (!is_real(_px)) return false;
    // ⛔ `surface_save`'s second argument is a FILENAME. Handed a number it reports "invalid
    // reference to (buffer)" and throws, which is a crash in the buyer's game rather than a false
    // return (MEASURED 2026-09-07 by the generated adversarial harness).
    if (!is_string(_file) || _file == "") return false;
    var _n = ceil(_px);
    if (_n < 4) return false;
    if (_n > CHT_EXPORT_MAX_PX) return false;
    var _surf = surface_create(_n, _n);
    if (!surface_exists(_surf)) return false;
    if (is_undefined(_seed)) _seed = cht_hash32(_kind);
    surface_set_target(_surf);
    draw_clear_alpha(c_black, 0);
    cht_draw_mark(_kind, cht_page(_page_id), cht_hand(_hand_id), _state,
                  _n * 0.5, _n * 0.5, _n, _seed, 1);
    surface_reset_target();
    surface_save(_surf, _file);
    surface_free(_surf);
    return true;
}

/// Render a whole chart page to a PNG at any size, independent of the window.
function cht_export_chart(_chart, _w, _h, _file, _opts) {
    if (!is_real(_w) || !is_real(_h)) return false;
    // See cht_export_mark: a non-string filename throws inside surface_save.
    if (!is_string(_file) || _file == "") return false;
    var _sw = max(8, ceil(_w)), _sh = max(8, ceil(_h));
    // See CHT_EXPORT_MAX_PX: the surface_exists guard below cannot help, because an absurd request
    // hangs inside surface_create before it is ever reached.
    if (_sw > CHT_EXPORT_MAX_PX || _sh > CHT_EXPORT_MAX_PX) return false;
    var _surf = surface_create(_sw, _sh);
    if (!surface_exists(_surf)) return false;
    surface_set_target(_surf);
    draw_clear_alpha(c_black, 0);
    cht_chart_draw(_chart, 0, 0, _sw, _sh, _opts);
    surface_reset_target();
    surface_save(_surf, _file);
    surface_free(_surf);
    return true;
}
