{
  "$GMScript": "v1",
  "%Name": "cht_render",
  "isCompatibility": false,
  "isDnD": false,
  "name": "cht_render",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}