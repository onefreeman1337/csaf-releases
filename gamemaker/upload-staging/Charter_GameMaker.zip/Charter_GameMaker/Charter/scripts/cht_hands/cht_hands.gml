/// ============================================================================================
/// CHARTER - cht_hands: the four ink hands. The SAME mark, drawn by four different scribes.
///
/// A hand is a transform over a placed part list. It changes stroke weight, adds jitter, decides
/// hatch density and how a stroke terminates - so `barrow` in `field` is visibly a different
/// drawing from `barrow` in `chancery`, not a recolour of it.
///
/// This is the axis that turns 44 marks into 528 renderings (44 x 4 hands x 3 states), and it is
/// worth being precise about why it works: a hand does not change WHAT is drawn, so the 14px
/// silhouette test in Motif_Corpus.md §1 still holds in every hand. It changes HOW, which is the
/// half a buyer recognises as craft.
///
/// ⛔ EVERY HAND IS DETERMINISTIC. Jitter is seeded from the landmark's own id, never random(), so
/// a mark's wobble is stable forever. A chart that re-wobbles every frame is the one defect a
/// buyer notices instantly and cannot work around, and it is why cht_geom ships a seeded rng at
/// all. Never call random() in this package.
///
/// ⚠️ AND THE JITTER IS CAPPED BY THE COORDINATE CONTRACT, not by taste. CHT_JITTER_MAX is one of
/// the numbers in cht_marks' contract, check_marks.js re-does the arithmetic, and cht_selftest
/// re-does it again in-engine. A hand that displaced further than that could push a mark out of
/// its cell and over its neighbour.
///
/// ⛔ A HAND IS APPLIED TO AUTHORING-BOX GEOMETRY, BEFORE cht_place_mark - NEVER AFTER.
/// This paragraph used to say "a placed part list", and that wording is not a detail: every
/// displacement below is expressed in AUTHORING units, so applied to placed geometry a `field`
/// hand would jitter a mark by 0.03 PIXELS and do visibly nothing. The pipeline is
/// `cht_mark -> cht_hand_apply -> cht_state_apply -> cht_place_mark`, and it is that way round
/// because both of the first two speak in the unit box.
///
/// ⛔ AND OVERSHOOT IS THE BIGGER HALF OF WHAT A HAND ADDS, WHICH THE CONTRACT MISSED FOR A DAY.
/// Jitter is 0.030. The `field` hand's overshoot on a heavy stroke is 0.045 x 1.35 x 1.8 = 0.109 -
/// three and a half times larger, and it was in no arithmetic anywhere. cht_hand_apply now clamps
/// the two together to CHT_HAND_GROW, so the flourish is bounded by the contract rather than the
/// other way round. See cht_marks' header for the full note; the fix redraws nothing.
/// ============================================================================================

#macro CHT_HAND_COUNT 4

function cht_hand_ids() { return ["chancery", "survey", "field", "illuminated"]; }

function cht_hand_name(_id) {
    switch (_id) {
        case "chancery":    return "Chancery";
        case "survey":      return "Survey";
        case "field":       return "Field Sketch";
        case "illuminated": return "Illuminated";
    }
    return "Unknown";
}

/// A hand's parameters.
///   wscale   multiplies every stroke width
///   jitter   max displacement, as a fraction of CHT_JITTER_MAX (so the contract binds all four)
///   hatch    density multiplier for terrain and mark hatching
///   overshoot how far a stroke runs past its endpoint, in stroke widths (a quick hand overshoots)
///   doubled  draw contours twice, slightly offset - the illuminated hand's tell
///   closed   whether outlines close cleanly (formal) or are left open (quick)
///   fills    whether solid MASSES are filled, or reduced to their outline
///
/// ⛔ `fills` AND THE WIDENED WEIGHT SPREAD EXIST BECAUSE THE FOUR HANDS LOOKED THE SAME.
/// The self-test's distinctness stage was green - all four produce different geometry, and it
/// proved it on 44 marks. Then the store sheet was baked and LOOKED AT, and three of the four are
/// indistinguishable at a glance: chancery, survey and illuminated differed only by a 13% weight
/// change and an inner contour too faint to see. The product was selling a 4x multiplier a buyer
/// cannot perceive, and every mechanical check in the package agreed it was fine.
///
/// That is the exact gap master CLAUDE.md's Gate 1 is about, and the numbers below are the fix:
///   - `survey` DOES NOT FILL. A technical pen draws outlines; a survey sheet has no solid masses
///     on it at all. This is the single most legible difference available and it costs one flag.
///   - the weight spread is now 0.55 -> 1.55, nearly 3x end to end, instead of 0.75 -> 1.35.
///   - `illuminated`'s doubled contour is drawn heavier and offset further, so it reads as a
///     double rule rather than as a slightly thick line.
function cht_hand(_id) {
    switch (_id) {
        case "chancery": return {
            id: _id, wscale: 1.00, jitter: 0.10, hatch: 1.35,
            overshoot: 0.0, doubled: false, closed: true, fills: true
        };
        case "survey": return {
            id: _id, wscale: 0.55, jitter: 0.00, hatch: 0.80,
            overshoot: 0.0, doubled: false, closed: true, fills: false
        };
        case "field": return {
            id: _id, wscale: 1.55, jitter: 1.00, hatch: 0.55,
            overshoot: 1.8, doubled: false, closed: false, fills: true
        };
        case "illuminated": return {
            id: _id, wscale: 1.10, jitter: 0.25, hatch: 1.10,
            overshoot: 0.0, doubled: true, closed: true, fills: true
        };
    }
    return cht_hand("chancery");
}

/// Displace one point by the hand's jitter. `_k` is a per-point counter so consecutive points on
/// one polyline do not all move the same way - otherwise the whole shape translates and the mark
/// looks moved rather than hand-drawn.
/// ⛔ THE DISPLACEMENT IS POLAR, NOT PER-AXIS, AND THAT IS A CORRECTNESS FIX RATHER THAN A STYLE
/// ONE. This drew an independent offset on each axis, so a point could move by CHT_JITTER_MAX in x
/// AND CHT_JITTER_MAX in y at once - a true maximum displacement of 0.030 x sqrt(2) = 0.0424, which
/// is 41% more than the number the macro is named after and more than the whole contract budgeted.
/// The in-engine suite measured it exactly: `a hand grew a mark by 0.07 (ford/field), past
/// CHT_HAND_GROW 0.06` - 0.0424 of jitter plus 0.030 of capped overshoot. Nothing static could
/// have seen it, because both terms are individually within their stated limits and it is only
/// their DIAGONAL SUM that is not.
///
/// Drawing an angle and a radius makes |displacement| <= CHT_JITTER_MAX exactly, which is what the
/// macro has claimed all along. It also looks better: a box jitter concentrates displacement into
/// the corners, so a wobbled contour picks up a faint diagonal grain.
function cht_hand_jitter_pt(_p, _hand, _st) {
    if (_hand.jitter <= 0) return _p;
    var _amp = CHT_JITTER_MAX * _hand.jitter;
    var _a = cht_rng_next(_st) * CHT_TAU;
    var _r = cht_rng_next(_st) * _amp;
    return [_p[0] + cos(_a) * _r, _p[1] + sin(_a) * _r];
}

/// Extend a polyline past both ends by _by, along its own end directions. This is what a quick
/// hand actually does: the pen is already moving when it meets the corner.
/// ⚠️ Written out twice rather than through a local `var _ex = function(...)`. A function literal
/// assigned to a local is a METHOD bound to the calling scope in GML, and this file is called from
/// a script, from the demo object and from the headless bake entry point - three different selves.
/// This wing has already lost a build cycle to a GML binding subtlety (cht_geom's rng was a struct
/// with a next() method and generator state did not stay with the generator). Six duplicated lines
/// are cheaper than rediscovering that.
function cht_hand_overshoot(_pts, _by) {
    var _n = array_length(_pts);
    if (_n < 2 || _by <= 0) return _pts;
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) _out[_i] = _pts[_i];

    var _dx = _pts[0][0] - _pts[1][0], _dy = _pts[0][1] - _pts[1][1];
    var _l = point_distance(0, 0, _dx, _dy);
    if (_l > 0) _out[0] = [_pts[0][0] + _dx / _l * _by, _pts[0][1] + _dy / _l * _by];

    _dx = _pts[_n - 1][0] - _pts[_n - 2][0]; _dy = _pts[_n - 1][1] - _pts[_n - 2][1];
    _l = point_distance(0, 0, _dx, _dy);
    if (_l > 0) _out[_n - 1] = [_pts[_n - 1][0] + _dx / _l * _by, _pts[_n - 1][1] + _dy / _l * _by];

    return _out;
}

/// The largest distance THIS hand may extend a stroke past its endpoint, in authoring units.
///
/// Derived, never typed: whatever CHT_HAND_GROW allows minus whatever this hand's jitter already
/// spends. Stating it as a function rather than a constant is what keeps the two terms adding up
/// to the contract's single number no matter how the hand table is tuned later.
function cht_hand_overshoot_cap(_hand) {
    return max(0, CHT_HAND_GROW - CHT_JITTER_MAX * _hand.jitter);
}

/// Does this fan's point list begin with an INTERIOR APEX rather than with a real corner?
///
/// cht_ring_fill builds [apex, p0, p1, ... pn-1, p0] - it repeats the first rim point at the end so
/// the fan closes (cht_geom's header explains why a fan that does not is missing a wedge). A plain
/// cht_fill just lists its corners. The repeat is therefore an exact signature, and it is the only
/// thing that separates "point 0 is the middle of the shape" from "point 0 is the top-left corner".
///
/// Stated as one named function because two places need the answer and a copy of this test that
/// drifted would silently draw a spoke through every rounded mark in the corpus.
function cht_fan_has_apex(_pts) {
    var _n = array_length(_pts);
    if (_n < 4) return false;
    return (_pts[_n - 1][0] == _pts[1][0]) && (_pts[_n - 1][1] == _pts[1][1]);
}

/// Offset a contour INWARD by _d, whichever way round it happens to be wound.
///
/// ⛔ THIS EXISTS BECAUSE "just inside" WAS A HOPE, NOT A PROPERTY. The illuminated hand's second
/// contour was `cht_offset_pts(_pts, _w * 1.5)`, whose sign is fixed - so which side it lands on
/// depends entirely on the WINDING of the mark that was authored, and the 44 marks in this corpus
/// are not wound consistently (some are built anticlockwise from a helper, some clockwise by hand).
/// On an outward-wound mark the second line sat OUTSIDE the first, which is wrong twice over: it
/// does not look like an illuminated double rule, and on a CHT_W_HEAVY contour it grows the mark's
/// radius by 0.045 x 1.05 x 1.5 = 0.071 - past the whole CHT_HAND_GROW budget of 0.060, pushing the
/// mark over its cell and onto its neighbour.
///
/// The side is decided by MEASUREMENT rather than by reasoning about which way GML's normal points:
/// offset both ways, keep the one whose mean distance from the contour's own centroid is smaller.
/// Every mark contour in this corpus is roughly star-shaped about its centroid, so that answer is
/// unambiguous - and it stays right if cht_offset_pts is ever changed underneath it, which a
/// hand-derived sign would not.
function cht_hand_inward(_pts, _d) {
    var _n = array_length(_pts);
    if (_n < 3 || _d <= 0) return _pts;
    var _cx = 0, _cy = 0;
    for (var _i = 0; _i < _n; _i++) { _cx += _pts[_i][0]; _cy += _pts[_i][1]; }
    _cx /= _n; _cy /= _n;

    var _a = cht_offset_pts(_pts, _d);
    var _b = cht_offset_pts(_pts, -_d);
    var _ra = 0, _rb = 0;
    for (var _i = 0; _i < _n; _i++) {
        _ra += point_distance(_cx, _cy, _a[_i][0], _a[_i][1]);
        _rb += point_distance(_cx, _cy, _b[_i][0], _b[_i][1]);
    }
    return (_ra <= _rb) ? _a : _b;
}

/// Apply a hand to an AUTHORING-BOX part list - before cht_place_mark, never after (see header).
/// Returns a NEW list; the input is never mutated, because the same corpus part list is handed to
/// every hand on the store sheets and a mutating pass would make sheet 2 depend on sheet 1 having
/// been drawn.
///
/// _seed is the landmark's own hash, so the same landmark wobbles the same way forever.
function cht_hand_apply(_parts, _hand, _seed) {
    var _st = cht_rng(_seed == 0 ? 1 : _seed);
    var _cap = cht_hand_overshoot_cap(_hand);
    var _n = array_length(_parts);
    var _out = [];
    for (var _i = 0; _i < _n; _i++) {
        var _p = _parts[_i];
        switch (_p.kind) {
            case CHT_DOT: {
                var _q = cht_hand_jitter_pt([_p.cx, _p.cy], _hand, _st);
                array_push(_out, cht_dot(_q[0], _q[1], _p.r, _p.role));
            } break;

            case CHT_ARC: {
                var _q = cht_hand_jitter_pt([_p.cx, _p.cy], _hand, _st);
                array_push(_out, cht_arc(_q[0], _q[1], _p.r, _p.a0, _p.a1,
                                         _p.w * _hand.wscale, _p.role));
            } break;

            case CHT_FILL: {
                // A FAN's outline must stay star-shaped about pts[0] (cht_geom's header). Jitter
                // is small relative to any mark's features, so the property survives - but the
                // FIRST point is left ALONE, because that is the fan's apex and moving it is the
                // one displacement that can invert a wedge.
                var _np = array_length(_p.pts);
                var _pts = array_create(_np);
                _pts[0] = _p.pts[0];
                for (var _k = 1; _k < _np; _k++) _pts[_k] = cht_hand_jitter_pt(_p.pts[_k], _hand, _st);
                if (_hand.fills) {
                    array_push(_out, cht_fill(_pts, _p.role));
                } else {
                    // ⛔ THE SURVEY HAND DOES NOT FILL, SO IT HAS TO TRACE THE BORDER - AND THIS
                    // PACKAGE HAS TWO KINDS OF FAN, WHICH IS THE WHOLE SUBTLETY.
                    //
                    // cht_ring_fill emits [apex, p0, p1, ... pn-1, p0]: the first point is an
                    // INTERIOR centroid, not part of the border. Tracing that list as a polyline
                    // draws a spoke from the middle of the shape out to its rim.
                    // A plain cht_fill emits its corners directly, and there the first point IS a
                    // corner - dropping it deletes a vertex and opens the outline.
                    //
                    // The first attempt dropped point 0 unconditionally, and the store sheet showed
                    // it immediately: barrow, bridge, pharos and cave all grew a stray diagonal
                    // where a real corner had been removed. The two shapes are told apart exactly,
                    // not heuristically - a ring fill REPEATS its first rim point at the end, so
                    // `last == pts[1]` is the signature, and cht_selftest asserts both directions.
                    //
                    // ⚠️ TESTED ON THE ORIGINAL POINTS, NOT THE JITTERED ONES. Jitter displaces
                    // every point independently, so the repeated rim point and its twin stop being
                    // equal the moment a hand with any wobble touches them - the signature has to
                    // be read off the geometry as authored. It happens that `survey` is the only
                    // non-filling hand and its jitter is zero, so this is currently belt and
                    // braces; it stops being belt and braces the day someone adds a fifth hand.
                    var _ring = cht_fan_has_apex(_p.pts);
                    var _from = _ring ? 1 : 0;
                    var _to = _ring ? (_np - 1) : _np;
                    var _edge = array_create(max(0, _to - _from));
                    for (var _k = _from; _k < _to; _k++) _edge[_k - _from] = _pts[_k];
                    if (array_length(_edge) >= 2) {
                        array_push(_out, cht_poly(_edge, true, CHT_W_FINE * _hand.wscale, CHT_R_INK));
                    }
                }
            } break;

            case CHT_STRIP: {
                // Both rails must keep EQUAL LENGTH - cht_render walks them in lockstep - so the
                // two are jittered independently but never resampled.
                var _na = array_length(_p.a), _nb = array_length(_p.b);
                var _a = array_create(_na), _b = array_create(_nb);
                for (var _k = 0; _k < _na; _k++) _a[_k] = cht_hand_jitter_pt(_p.a[_k], _hand, _st);
                for (var _k = 0; _k < _nb; _k++) _b[_k] = cht_hand_jitter_pt(_p.b[_k], _hand, _st);
                array_push(_out, cht_strip(_a, _b, _p.role));
            } break;

            default: {
                var _np = array_length(_p.pts);
                var _pts = array_create(_np);
                for (var _k = 0; _k < _np; _k++) _pts[_k] = cht_hand_jitter_pt(_p.pts[_k], _hand, _st);
                var _w = _p.w * _hand.wscale;
                var _closed = _p.closed && _hand.closed;
                if (!_closed && _p.closed) {
                    // An "open" hand does not close a shape - it stops just short, which is what a
                    // quick pen does. Repeat all but the last step so the gap is visible.
                    var _open = array_create(_np);
                    for (var _k = 0; _k < _np; _k++) _open[_k] = _pts[_k];
                    array_push(_open, [lerp(_pts[_np - 1][0], _pts[0][0], 0.72),
                                       lerp(_pts[_np - 1][1], _pts[0][1], 0.72)]);
                    _pts = _open;
                }
                // ⛔ CLAMPED. `_w * overshoot` on a heavy stroke is 0.109 in authoring units,
                // which is more than three times the jitter budget and was in no arithmetic
                // anywhere until 2026-08-22. The cap is what makes CHT_HAND_GROW true.
                if (_hand.overshoot > 0) {
                    _pts = cht_hand_overshoot(_pts, min(_cap, _w * _hand.overshoot));
                }
                array_push(_out, cht_poly(_pts, _closed, _w, _p.role));
                if (_hand.doubled && _p.role == CHT_R_INK) {
                    // The illuminated hand's double contour: a second line just inside.
                    //
                    // ⚠️ OFFSET AND WEIGHT BOTH RAISED after the store sheet was looked at - at
                    // `_w * 1.5` inward and 0.45 weight the second line sat under the first and
                    // read as nothing but a slightly thicker contour. A double rule has to be
                    // visibly TWO lines with page between them or it is not a double rule.
                    array_push(_out, cht_poly(cht_hand_inward(_pts, min(_cap, _w * 2.6)),
                                              _closed, _w * 0.60, _p.role));
                }
            } break;
        }
    }
    return _out;
}

/// ============================================================================================
/// LANDMARK STATE - what the chart knows, said in ink
/// ============================================================================================

#macro CHT_ST_RUMOURED 0
#macro CHT_ST_SIGHTED  1
#macro CHT_ST_VISITED  2

function cht_state_ids() { return ["rumoured", "sighted", "visited"]; }

function cht_state_name(_s) {
    switch (_s) {
        case CHT_ST_RUMOURED: return "Rumoured";
        case CHT_ST_SIGHTED:  return "Sighted";
        case CHT_ST_VISITED:  return "Visited";
    }
    return "Unknown";
}

/// Apply a landmark's STATE to its parts. This is the product's argument in one function: the
/// chart draws what the player KNOWS, not what exists.
///
///   rumoured  faint, DASHED, no interior detail. The position is deliberately imprecise.
///   sighted   contour only - seen from a distance, so texture and mass are dropped.
///   visited   everything.
function cht_state_apply(_parts, _state) {
    if (_state == CHT_ST_VISITED) return _parts;
    var _n = array_length(_parts);
    var _out = [];
    for (var _i = 0; _i < _n; _i++) {
        var _p = _parts[_i];
        if (_state == CHT_ST_SIGHTED) {
            // Keep the contour, drop the second and third levels of detail. A sighted landmark is
            // a shape on the horizon.
            if (_p.role == CHT_R_HATCH || _p.role == CHT_R_VOID) continue;
            if (_p.role == CHT_R_MASS && _p.kind == CHT_FILL) {
                array_push(_out, cht_poly(_p.pts, true, CHT_W_FINE, CHT_R_INK));
                continue;
            }
            array_push(_out, _p);
            continue;
        }
        // RUMOURED: outline only, and dashed. Fills become their own outline so nothing is solid -
        // a solid mass would read as certainty, which is exactly what a rumour is not.
        if (_p.kind == CHT_DOT) continue;
        if (_p.role == CHT_R_HATCH || _p.role == CHT_R_VOID) continue;
        if (_p.kind == CHT_FILL) {
            _out = cht_append(_out, cht_dash_poly(_p.pts, true, CHT_W_HAIR, CHT_R_HATCH));
        } else if (_p.kind == CHT_POLY) {
            _out = cht_append(_out, cht_dash_poly(_p.pts, _p.closed, CHT_W_HAIR, CHT_R_HATCH));
        } else if (_p.kind == CHT_ARC) {
            array_push(_out, cht_arc(_p.cx, _p.cy, _p.r, _p.a0, _p.a1, CHT_W_HAIR, CHT_R_HATCH));
        }
    }
    return _out;
}

/// Break a polyline into dashes. Returns a list of short polys.
///
/// ⚠️ Walks by ARC LENGTH, not by vertex, so a curve sampled densely and a straight run sampled
/// with two points dash at the same visible rate. Dashing per-segment was the first attempt and it
/// made every sampled arc in the corpus look solid while every straight edge looked dotted.
///
/// ⛔ AND THE DASH LENGTH IS DERIVED FROM THE SHAPE, NOT A CONSTANT. It was written as a literal
/// 0.030 first, which is correct in the mark-AUTHORING box and meaningless everywhere else - this
/// function is handed PLACED geometry, in chart units, at whatever scale the landmark was drawn
/// at. A fixed constant makes a large mark look solid and a small one vanish. Deriving ~14 dashes
/// from the path's own length is scale-free, which is the property this needs.
function cht_dash_poly(_pts, _closed, _w, _role) {
    var _n = array_length(_pts);
    if (_n < 2) return [];
    var _walk = array_create(_closed ? _n + 1 : _n);
    for (var _i = 0; _i < _n; _i++) _walk[_i] = _pts[_i];
    if (_closed) _walk[_n] = _pts[0];
    var _wn = array_length(_walk);

    var _total = 0;
    for (var _i = 1; _i < _wn; _i++) {
        _total += point_distance(_walk[_i - 1][0], _walk[_i - 1][1], _walk[_i][0], _walk[_i][1]);
    }
    if (_total <= 0) return [];
    var _dash = _total / 22;
    var _gap = _dash * 0.75;
    var _out = [];
    var _acc = 0;                // distance travelled within the current dash/gap
    var _on = true;
    var _cur = [_walk[0]];
    for (var _i = 1; _i < _wn; _i++) {
        var _ax = _walk[_i - 1][0], _ay = _walk[_i - 1][1];
        var _bx = _walk[_i][0], _by = _walk[_i][1];
        var _seg = point_distance(_ax, _ay, _bx, _by);
        var _t = 0;
        while (_t < _seg) {
            var _need = (_on ? _dash : _gap) - _acc;
            var _take = min(_need, _seg - _t);
            _t += _take; _acc += _take;
            // ⛔ Both guards below are RELATIVE to the dash length, never an absolute literal.
            // GML's default epsilon is 1e-6 and participates in comparisons, so anything written
            // below about 1e-5 can never fire in either direction - this wing's constitution
            // records a whole suite of distinctness assertions passing vacuously for exactly that
            // reason. A relative guard also survives this function being handed geometry at any
            // chart scale, which is the same defect the dash length itself had.
            var _den = max(_seg, _dash * 0.001);
            var _px = lerp(_ax, _bx, _t / _den);
            var _py = lerp(_ay, _by, _t / _den);
            if (_on) array_push(_cur, [_px, _py]);
            if (_acc >= (_on ? _dash : _gap) - _dash * 0.001) {
                if (_on && array_length(_cur) > 1) array_push(_out, cht_poly(_cur, false, _w, _role));
                _on = !_on;
                _acc = 0;
                _cur = [[_px, _py]];
            }
        }
    }
    if (_on && array_length(_cur) > 1) array_push(_out, cht_poly(_cur, false, _w, _role));
    return _out;
}
