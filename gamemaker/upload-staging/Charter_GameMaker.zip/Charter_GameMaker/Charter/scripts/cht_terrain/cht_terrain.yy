{
  "$GMScript": "v1",
  "%Name": "cht_terrain",
  "isCompatibility": false,
  "isDnD": false,
  "name": "cht_terrain",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}