/// ============================================================================================
/// CHARTER - cht_terrain: the eight cartographic hatch fills, and the polygon machinery under them.
///
/// A chart is not a grid of icons. What makes a page read as a MAP is the ground between the
/// landmarks: woodland stippled with canopies, marsh in reed tufts, water in shore-parallel lining.
/// This file draws that ground, and it draws it INSIDE AN ARBITRARY POLYGON, which is the part that
/// takes real work and is the reason a buyer would not write this themselves in an afternoon.
///
/// -- WHY POLYGONS AND NOT RECTANGLES -----------------------------------------------------------
/// A rectangular "forest" announces itself as a widget. Regions on a real chart follow coastlines
/// and ridge lines, so the fill has to be clipped to a shape rather than a box. Two primitives do
/// all of it and both are exact rather than sampled:
///
///   cht_pt_in_poly   even-odd crossing test, for the SCATTER fills (a symbol is kept or dropped)
///   cht_poly_spans   ray/edge intersection sort, for the LINE fills (a line is cut into the runs
///                    that lie inside, so a water lining stops at the shore instead of at a bbox)
///
/// ⚠️ THE SPAN SPLITTER IS THE ONE PIECE THAT CANNOT BE EYEBALLED, so cht_selftest asserts it
/// against a shape with a genuine concavity - a C, where a horizontal ray crosses FOUR edges and a
/// naive "first hit to last hit" implementation would paint straight across the mouth of the C.
/// That is the whole reason the function returns an ARRAY of spans and not a pair.
///
/// -- EVERY FILL IS DETERMINISTIC ---------------------------------------------------------------
/// Scatter positions come from cht_rng seeded on the region, never from random(). A forest whose
/// trees rearrange themselves every frame is the single most obvious defect this product could
/// ship, and it would be invisible in a screenshot.
///
/// -- ROLE -------------------------------------------------------------------------------------
/// Everything here is CHT_R_HATCH. Terrain is the SECOND read on a chart: it must be present enough
/// to give the page texture and quiet enough that a landmark mark still wins the eye. Drawing
/// terrain in ink is how an auto-map turns into noise.
/// ============================================================================================

#macro CHT_TERRAIN_COUNT 8

/// The eight fills, in the order the store sheet shows them.
function cht_terrain_ids() {
    return ["woodland", "conifer", "marsh", "dune", "moor", "scree", "water", "cultivated"];
}

function cht_terrain_name(_id) {
    switch (_id) {
        case "woodland":   return "Woodland";
        case "conifer":    return "Conifer Forest";
        case "marsh":      return "Marsh";
        case "dune":       return "Dunes";
        case "moor":       return "Moor";
        case "scree":      return "Scree";
        case "water":      return "Water";
        case "cultivated": return "Cultivated";
    }
    return "Unknown";
}

/// Is this fill drawn by scattering a symbol, or by ruling lines across the region?
/// Stated once, here, because both the fill dispatcher and the self-test need to know and two
/// copies of the answer would drift.
function cht_terrain_is_scatter(_id) {
    return (_id == "woodland" || _id == "conifer" || _id == "marsh"
         || _id == "dune"     || _id == "moor"    || _id == "scree");
}

/// ============================================================================================
/// POLYGON MACHINERY
/// ============================================================================================

/// The axis-aligned bounding box of a polygon, as [x0, y0, x1, y1].
function cht_poly_bbox(_poly) {
    var _n = array_length(_poly);
    if (_n == 0) return [0, 0, 0, 0];
    var _x0 = _poly[0][0], _y0 = _poly[0][1], _x1 = _x0, _y1 = _y0;
    for (var _i = 1; _i < _n; _i++) {
        _x0 = min(_x0, _poly[_i][0]); _x1 = max(_x1, _poly[_i][0]);
        _y0 = min(_y0, _poly[_i][1]); _y1 = max(_y1, _poly[_i][1]);
    }
    return [_x0, _y0, _x1, _y1];
}

/// Even-odd point-in-polygon. Works for any simple polygon, convex or not.
///
/// The half-open edge test `(yi > _y) != (yj > _y)` is not a style choice: it counts a vertex that
/// sits exactly on the ray ONCE rather than twice, which is what stops a scatter lattice - whose
/// points land on suspiciously round numbers - from producing a row of dropouts along one y.
function cht_pt_in_poly(_x, _y, _poly) {
    var _n = array_length(_poly);
    var _in = false;
    var _j = _n - 1;
    for (var _i = 0; _i < _n; _i++) {
        var _yi = _poly[_i][1], _yj = _poly[_j][1];
        if ((_yi > _y) != (_yj > _y)) {
            var _xi = _poly[_i][0], _xj = _poly[_j][0];
            var _t = (_y - _yi) / (_yj - _yi);
            if (_x < _xi + _t * (_xj - _xi)) _in = !_in;
        }
        _j = _i;
    }
    return _in;
}

/// The runs of the segment (_ax,_ay)-(_bx,_by) that lie INSIDE _poly, as an array of [t0, t1] in
/// 0..1 along the segment.
///
/// ⛔ IT RETURNS AN ARRAY, AND THAT IS THE POINT. The tempting implementation takes the first and
/// last crossing and calls the middle "inside", which paints straight across the mouth of any
/// concave region - a bay on a coastline, the inside of a C. Sorting every crossing and taking
/// alternate runs costs six more lines and is correct for any simple polygon. cht_selftest asserts
/// it on a C, where a naive version returns one span and this returns two.
///
/// A segment that starts inside is handled by seeding the parity from the start point rather than
/// assuming a crossing at t=0.
function cht_poly_spans(_ax, _ay, _bx, _by, _poly) {
    var _n = array_length(_poly);
    var _ts = [];
    var _dx = _bx - _ax, _dy = _by - _ay;
    var _j = _n - 1;
    for (var _i = 0; _i < _n; _i++) {
        var _px = _poly[_j][0], _py = _poly[_j][1];
        var _qx = _poly[_i][0], _qy = _poly[_i][1];
        var _ex = _qx - _px, _ey = _qy - _py;
        var _den = _dx * _ey - _dy * _ex;
        // ⛔ NEVER a tolerance below ~1e-5 in GML: math_get_epsilon defaults to 1e-6 and
        // participates in comparisons, so a tighter guard can never fire in either direction.
        if (abs(_den) < 0.00001) { _j = _i; continue; }     // parallel
        var _t = ((_px - _ax) * _ey - (_py - _ay) * _ex) / _den;
        var _u = ((_px - _ax) * _dy - (_py - _ay) * _dx) / _den;
        if (_t >= 0 && _t <= 1 && _u >= 0 && _u < 1) array_push(_ts, _t);
        _j = _i;
    }
    array_sort(_ts, true);

    var _out = [];
    var _inside = cht_pt_in_poly(_ax, _ay, _poly);
    var _cursor = 0;
    var _m = array_length(_ts);
    for (var _k = 0; _k < _m; _k++) {
        if (_inside && _ts[_k] > _cursor) array_push(_out, [_cursor, _ts[_k]]);
        _cursor = _ts[_k];
        _inside = !_inside;
    }
    if (_inside && _cursor < 1) array_push(_out, [_cursor, 1]);
    return _out;
}

/// A convenience for the caller who wants the clipped pieces as polylines rather than as spans.
///
/// ⛔ `_maxlen` IS NOT AN OPTIMISATION - IT IS WHAT MAKES A LINE FILL RESPECT THE FOG.
/// cht_render decides whether a part is on revealed ground by testing ONE anchor point per part,
/// and it has to: testing every vertex would half-draw a tree straddling the boundary. That is the
/// right trade for a scatter symbol, which is smaller than a discovery cell - and completely wrong
/// for a water lining, which can be 1,500px long. Measured on the hero chart: a single lining
/// anchored in one revealed cell near the shore drew as a rail straight across the entire
/// unexplored sea, so the bottom third of the page was crossed by scratches through ground the
/// player has never seen. Cutting a long run into cell-sized pieces gives each piece its own
/// anchor, and the fill then stops exactly where the exploration does.
function cht_poly_clip_line(_ax, _ay, _bx, _by, _poly, _w, _role, _maxlen) {
    var _spans = cht_poly_spans(_ax, _ay, _bx, _by, _poly);
    var _full = point_distance(_ax, _ay, _bx, _by);
    var _out = [];
    for (var _i = 0; _i < array_length(_spans); _i++) {
        var _s = _spans[_i];
        var _cuts = 1;
        if (!is_undefined(_maxlen) && _maxlen > 0 && _full > 0) {
            _cuts = clamp(ceil((_s[1] - _s[0]) * _full / _maxlen), 1, 200);
        }
        for (var _k = 0; _k < _cuts; _k++) {
            var _t0 = lerp(_s[0], _s[1], _k / _cuts);
            var _t1 = lerp(_s[0], _s[1], (_k + 1) / _cuts);
            array_push(_out, cht_poly([
                [lerp(_ax, _bx, _t0), lerp(_ay, _by, _t0)],
                [lerp(_ax, _bx, _t1), lerp(_ay, _by, _t1)]
            ], false, _w, _role));
        }
    }
    return _out;
}

/// ============================================================================================
/// THE EIGHT SYMBOLS
///
/// Each returns parts in PAGE coordinates, centred on (_x,_y), _s wide. They are small - a canopy
/// is 5-9 px on a real page - so every one is built from two or three strokes and no more. The
/// three-levels-of-detail rule in Motif_Corpus.md §1 binds here too, and harder: at this size the
/// SECOND level is already invisible.
/// ============================================================================================

/// A deciduous canopy on a stem: the classic woodland symbol.
function cht_tr_tree(_x, _y, _s, _w) {
    var _r = _s * 0.38;
    var _p = [];
    array_push(_p, cht_poly([[_x, _y], [_x, _y - _r * 0.85]], false, _w, CHT_R_HATCH));
    array_push(_p, cht_poly(cht_arc_pts(_x, _y - _r * 1.25, _r, 0, CHT_TAU, 9), true, _w, CHT_R_HATCH));
    return _p;
}

/// A conifer: a narrow triangle over a short stem. Kept NARROW - a wide triangle at this size is
/// indistinguishable from a scree mark, which is the one confusion in this set.
function cht_tr_conifer(_x, _y, _s, _w) {
    var _h = _s * 0.95, _hw = _s * 0.26;
    var _p = [];
    array_push(_p, cht_poly([[_x, _y], [_x, _y - _h * 0.28]], false, _w, CHT_R_HATCH));
    array_push(_p, cht_poly([[_x - _hw, _y - _h * 0.28], [_x, _y - _h],
                             [_x + _hw, _y - _h * 0.28]], false, _w, CHT_R_HATCH));
    return _p;
}

/// Marsh: two or three short reeds standing on a water line. The horizontal is what separates it
/// from `moor` at page scale - reeds stand in water and tussocks do not.
function cht_tr_reed(_x, _y, _s, _w) {
    var _p = [];
    array_push(_p, cht_poly([[_x - _s * 0.45, _y], [_x + _s * 0.45, _y]], false, _w, CHT_R_HATCH));
    array_push(_p, cht_poly([[_x - _s * 0.20, _y], [_x - _s * 0.26, _y - _s * 0.55]], false, _w, CHT_R_HATCH));
    array_push(_p, cht_poly([[_x,             _y], [_x,             _y - _s * 0.72]], false, _w, CHT_R_HATCH));
    array_push(_p, cht_poly([[_x + _s * 0.20, _y], [_x + _s * 0.27, _y - _s * 0.50]], false, _w, CHT_R_HATCH));
    return _p;
}

/// Dune: a crescent, open downwind. Two arcs of the same centre, so the horns close.
function cht_tr_dune(_x, _y, _s, _w) {
    return [cht_poly(cht_arc_pts(_x, _y + _s * 0.30, _s * 0.52, pi * 1.12, pi * 1.88, 8),
                     false, _w, CHT_R_HATCH)];
}

/// Moor: a tussock - a low V of two blades, no ground line.
function cht_tr_tuft(_x, _y, _s, _w) {
    var _p = [];
    array_push(_p, cht_poly([[_x - _s * 0.32, _y], [_x - _s * 0.06, _y - _s * 0.52]], false, _w, CHT_R_HATCH));
    array_push(_p, cht_poly([[_x + _s * 0.32, _y], [_x + _s * 0.08, _y - _s * 0.46]], false, _w, CHT_R_HATCH));
    return _p;
}

/// Scree: a scatter of angular chips. Filled, not outlined - at 4px an outlined triangle is a blob
/// with a hole in it, and the fill is what makes scree read as loose stone rather than as forest.
function cht_tr_chip(_x, _y, _s, _w) {
    var _h = _s * 0.34;
    return [cht_fill([[_x - _h, _y + _h * 0.7], [_x, _y - _h], [_x + _h * 0.9, _y + _h * 0.7]],
                     CHT_R_HATCH)];
}

/// ============================================================================================
/// THE FILLS
/// ============================================================================================

/// A jittered lattice of points inside _poly. Rows are offset by half a step so the lattice does
/// not read as a grid, and every point is displaced deterministically.
///
/// ⚠️ THE INSIDE TEST IS DONE ON THE JITTERED POINT, not the lattice point. Testing before the
/// jitter lets a symbol walk over the region boundary, which on a coastline puts trees in the sea.
function cht_terrain_points(_poly, _step, _seed) {
    var _bb = cht_poly_bbox(_poly);
    var _st = cht_rng(_seed == 0 ? 1 : _seed);
    var _out = [];
    if (_step <= 0) return _out;
    var _rows = min(400, ceil((_bb[3] - _bb[1]) / _step) + 1);
    var _cols = min(400, ceil((_bb[2] - _bb[0]) / _step) + 1);
    for (var _r = 0; _r <= _rows; _r++) {
        var _y = _bb[1] + _r * _step;
        var _off = ((_r % 2) == 0) ? 0 : _step * 0.5;
        for (var _c = 0; _c <= _cols; _c++) {
            var _x = _bb[0] + _off + _c * _step;
            var _jx = _x + (cht_rng_next(_st) - 0.5) * _step * 0.55;
            var _jy = _y + (cht_rng_next(_st) - 0.5) * _step * 0.55;
            if (cht_pt_in_poly(_jx, _jy, _poly)) array_push(_out, [_jx, _jy]);
        }
    }
    return _out;
}

/// Water lining: lines that follow the SHORE rather than the page.
///
/// This is the one fill that would be wrong as plain hatching. Nineteenth-century charts line water
/// with strokes parallel to the coast, progressively further apart as they leave it, and that is
/// what makes an inlet read as water at a glance.
///
/// ⛔ IT WAS A CENTROID SHRINK AND THAT FAILED ON THE ONLY SHAPE THAT MATTERS. Every edge was
/// pulled toward the polygon's average point, which is a fine approximation of an inward offset for
/// a blob and a bad one for anything long. The hero chart's sea is exactly the bad case: a coastal
/// strip the full width of the page and a fifth of its height, whose centroid sits in the middle -
/// so the "linings" came out as near-horizontal rails running the entire 1600px, one of them
/// leaving the page. It looked like scratches on the plate. On the furniture sheet's compact
/// swatch it looked perfect, which is why the fill has to be judged on the shape it will actually
/// be given.
///
/// Now each EDGE is offset along its OWN inward normal and clipped back to the polygon. That is a
/// true shore-parallel lining: an inlet's two shores each get their own set, and they stop where
/// the water stops.
///
/// ⚠️ Overlapping offsets at a concave corner are left overlapping ON PURPOSE. The correct fix is a
/// mitre join with self-intersection cleanup, which is a lot of code whose failure mode is a
/// lining that crosses itself in front of a buyer. Two lines meeting at a corner and slightly
/// doubling is what a pen does anyway.
function cht_terrain_water(_poly, _step, _seed) {
    var _n = array_length(_poly);
    if (_n < 3) return [];
    var _bb = cht_poly_bbox(_poly);
    // Rings are budgeted from the SHORTER dimension, because that is what runs out first. Budgeting
    // from the longer one is what let the old version keep drawing rails after it had crossed the
    // whole body of water.
    var _thin = min(_bb[2] - _bb[0], _bb[3] - _bb[1]) * 0.5;
    // ⚠️ FIVE RINGS, NOT TEN, AND THAT IS A CARTOGRAPHIC FACT RATHER THAN A BUDGET. A chart lines
    // the water NEAR THE SHORE and leaves open water bare - the lining is there to say "this edge
    // is a coast", not to fill the sea. Ten rings on the hero's bay reached the middle of the
    // page and turned a lining into a hatch, which is the look the whole fill exists to avoid.
    var _rings = clamp(floor(_thin / max(1, _step)), 1, 5);
    var _out = [];

    for (var _i = 0; _i < _n; _i++) {
        var _a = _poly[_i], _b = _poly[(_i + 1) % _n];
        var _dx = _b[0] - _a[0], _dy = _b[1] - _a[1];
        var _len = point_distance(0, 0, _dx, _dy);
        if (_len < 0.001) continue;
        _dx /= _len; _dy /= _len;

        // Which normal points INTO the polygon? Decided by testing, not by assuming a winding -
        // this product accepts a buyer's polygon in whatever order they wrote it.
        var _nx = -_dy, _ny = _dx;
        var _mx = (_a[0] + _b[0]) * 0.5, _my = (_a[1] + _b[1]) * 0.5;
        if (!cht_pt_in_poly(_mx + _nx * 0.75, _my + _ny * 0.75, _poly)) { _nx = -_nx; _ny = -_ny; }

        for (var _k = 1; _k <= _rings; _k++) {
            // Spacing widens with distance from the shore. That is the classic look, and it also
            // keeps the outer lines from crowding on a gentle curve.
            var _d = _step * _k * (1 + _k * 0.14);
            if (_d > _thin) break;
            // ⛔ AN EDGE STOPS EMITTING ONCE THE OFFSET OUTGROWS IT. Per-edge offsetting is right
            // for a long shore and wrong for a small many-sided blob: on the furniture sheet's
            // 11-vertex swatch every one of the eleven short edges threw five long lines inward and
            // they all crossed, so a fill that looked correct on the hero's coastline rendered as a
            // scribble at swatch size. Measured by baking both and looking - the hero was right and
            // the swatch was a mess, from the same code.
            //
            // An offset line whose reach exceeds the edge that generated it is contributing noise
            // rather than shore, so it is not drawn. `break`, not `continue`: _d only grows.
            if (_len < _d * 1.5) break;
            // Run past both ends so that after clipping, adjacent edges' linings meet at a corner
            // instead of leaving a notch. One step, not 1.6 x the offset distance - the larger
            // extension made an outer ring overshoot its own edge by more than the edge is long.
            var _ext = _step;
            var _ax = _a[0] + _nx * _d - _dx * _ext, _ay = _a[1] + _ny * _d - _dy * _ext;
            var _bx = _b[0] + _nx * _d + _dx * _ext, _by = _b[1] + _ny * _d + _dy * _ext;
            var _w = (_k == 1) ? CHT_W_FINE : CHT_W_HAIR;
            _out = cht_append(_out, cht_poly_clip_line(_ax, _ay, _bx, _by, _poly,
                                                       _w * _step * 1.6, CHT_R_HATCH, _step * 2));
        }
    }
    return _out;
}

/// Cultivated: furrows. Parallel rules at a fixed bearing, every third one dotted, clipped to the
/// region. The bearing is the region's own, so two adjacent fields do not share a grain - which is
/// what stops a patchwork of farmland reading as one big hatch.
function cht_terrain_furrows(_poly, _step, _seed) {
    var _bb = cht_poly_bbox(_poly);
    var _st = cht_rng(_seed == 0 ? 1 : _seed);
    var _ang = degtorad(12 + cht_rng_next(_st) * 46);
    var _dx = cos(_ang), _dy = sin(_ang);
    var _nx = -_dy, _ny = _dx;
    var _cx = (_bb[0] + _bb[2]) * 0.5, _cy = (_bb[1] + _bb[3]) * 0.5;
    var _span = point_distance(_bb[0], _bb[1], _bb[2], _bb[3]);
    var _lines = min(220, floor(_span / max(1, _step)));
    var _out = [];
    for (var _i = -_lines; _i <= _lines; _i++) {
        var _ox = _cx + _nx * _i * _step, _oy = _cy + _ny * _i * _step;
        var _ax = _ox - _dx * _span, _ay = _oy - _dy * _span;
        var _bx = _ox + _dx * _span, _by = _oy + _dy * _span;
        // Cut into cell-sized pieces for the same reason the water lining is - a furrow crossing a
        // large field is long enough to reach out of the revealed area on one anchor.
        var _pieces = cht_poly_clip_line(_ax, _ay, _bx, _by, _poly,
                                         CHT_W_HAIR * _step * 2.2, CHT_R_HATCH, _step * 3);
        if ((abs(_i) % 3) == 0) {
            // Every third furrow is dashed: a ploughed field is not a set of continuous rules, and
            // the alternation is what gives the fill its texture at page scale.
            for (var _k = 0; _k < array_length(_pieces); _k++) {
                _out = cht_append(_out, cht_dash_poly(_pieces[_k].pts, false,
                                                      _pieces[_k].w, CHT_R_HATCH));
            }
        } else {
            _out = cht_append(_out, _pieces);
        }
    }
    return _out;
}

/// Fill a region with one of the eight terrains.
///
/// @param _id       one of cht_terrain_ids()
/// @param _poly     the region, as an array of [x,y] in PAGE coordinates
/// @param _scale    the page's symbol scale in pixels - roughly one symbol's width
/// @param _density  0.5 sparse .. 2.0 dense. The ink hand's own `hatch` multiplier is applied by
///                  the caller (cht_render), so a `field` hand thins every terrain on the page.
/// @param _seed     any integer; the same seed always produces the same fill
function cht_terrain_fill(_id, _poly, _scale, _density, _seed) {
    if (array_length(_poly) < 3) return [];
    var _d = clamp(_density, 0.25, 3.0);
    var _step = max(2.0, _scale * 2.1 / _d);
    var _w = CHT_W_HAIR * _scale * 2.4;

    switch (_id) {
        case "water":      return cht_terrain_water(_poly, _step * 0.7, _seed);
        case "cultivated": return cht_terrain_furrows(_poly, _step * 0.55, _seed);
    }

    var _pts = cht_terrain_points(_poly, _step, _seed);
    var _out = [];
    var _n = array_length(_pts);
    for (var _i = 0; _i < _n; _i++) {
        var _x = _pts[_i][0], _y = _pts[_i][1];
        switch (_id) {
            case "woodland": _out = cht_append(_out, cht_tr_tree(_x, _y, _scale, _w)); break;
            case "conifer":  _out = cht_append(_out, cht_tr_conifer(_x, _y, _scale, _w)); break;
            case "marsh":    _out = cht_append(_out, cht_tr_reed(_x, _y, _scale, _w)); break;
            case "dune":     _out = cht_append(_out, cht_tr_dune(_x, _y, _scale, _w)); break;
            case "moor":     _out = cht_append(_out, cht_tr_tuft(_x, _y, _scale, _w)); break;
            case "scree":    _out = cht_append(_out, cht_tr_chip(_x, _y, _scale, _w)); break;
            default:         _out = cht_append(_out, cht_tr_tree(_x, _y, _scale, _w)); break;
        }
    }
    return _out;
}

/// A region's own boundary, as a light dotted contour. Optional - most cartographic fills have no
/// outline at all, and the fill itself is the boundary. Offered because a buyer laying out a
/// political map wants one, and because the dotted treatment keeps it out of the ink's read.
function cht_terrain_edge(_poly, _w) {
    if (array_length(_poly) < 3) return [];
    return cht_dash_poly(_poly, true, _w, CHT_R_HATCH);
}
