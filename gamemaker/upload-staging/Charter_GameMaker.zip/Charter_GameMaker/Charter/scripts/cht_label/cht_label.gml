/// ============================================================================================
/// CHARTER - cht_label: the scribe's annotations. Leader lines, names, the scale bar, the query.
///
/// -- LABELS ARE DATA, NOT DRAW CALLS -----------------------------------------------------------
/// This file produces two things and draws neither: GEOMETRY (leaders, the query glyph, the scale
/// bar's rules) and LABEL STRUCTS (text, where it goes, which hand wrote it). cht_render is still
/// the only file in the package that talks to the GPU.
///
/// ⛔ AND LABELS TRAVEL IN THEIR OWN ARRAY, NEVER MIXED INTO A PART LIST. A label is not a
/// cht_geom part - it has no `kind` in the 0..4 range - so a label that found its way into a part
/// array would fall through cht_place's switch into the POLY branch and be read as a polyline with
/// no `pts`. That is a runtime error inside a buyer's draw event, which on a headless build is a
/// modal dialog nobody can dismiss. Two arrays, always. Every function here that produces both
/// returns a struct with `parts` and `labels` so the two cannot be confused at the call site.
///
/// -- THE HAND WRITES THE TEXT TOO --------------------------------------------------------------
/// A chart where the marks are hand-drawn and the names are set in perfect horizontal type is a
/// chart with two authors. So a hand supplies a small deterministic TILT and a size trim, seeded
/// from the label's own text - the `field` hand slants its annotations, `survey` sets them dead
/// level, `chancery` and `illuminated` sit between. It is a two-degree effect and it is the
/// difference between "annotated" and "labelled".
/// ============================================================================================

/// Which of the two shipped fonts a label uses. Two, not five: a chart with five type sizes on it
/// reads as a UI, and the whole product is arguing that it is a document.
#macro CHT_LB_TITLE 0
#macro CHT_LB_BODY  1

/// A label. `ha`/`va` are GML's fa_* alignment constants, resolved by cht_render.
function cht_label_make(_text, _x, _y, _ha, _va, _role, _size, _scale, _angle) {
    return {
        text: _text, x: _x, y: _y,
        ha: is_undefined(_ha) ? fa_left : _ha,
        va: is_undefined(_va) ? fa_top : _va,
        role: is_undefined(_role) ? CHT_R_INK : _role,
        size: is_undefined(_size) ? CHT_LB_BODY : _size,
        scale: is_undefined(_scale) ? 1.0 : _scale,
        angle: is_undefined(_angle) ? 0 : _angle,
        alpha: 1.0
    };
}

/// The tilt, in degrees, that a given hand gives a given piece of text. Deterministic from the
/// text itself, so one name does not wobble between frames while its neighbour stays still.
function cht_label_tilt(_hand, _text) {
    if (_hand.jitter <= 0) return 0;
    var _st = cht_rng(cht_hash32(_text));
    return (cht_rng_next(_st) - 0.5) * 2 * (2.2 * _hand.jitter);
}

/// Apply a hand to a label, in place. Returns the label so it can be used inline.
function cht_label_hand(_lb, _hand) {
    _lb.angle = cht_label_tilt(_hand, _lb.text);
    // A quick field hand writes smaller and less carefully; a formal one writes at full size.
    _lb.scale *= lerp(1.0, 0.94, _hand.jitter);
    return _lb;
}

/// ============================================================================================
/// LEADER LINES
/// ============================================================================================

/// A leader from a mark to a label anchor: a short diagonal out of the mark, an elbow, and a level
/// run under where the text will sit.
///
/// The level run is not decoration - it is what stops the text from appearing to float. A leader
/// that meets its text at an angle reads as an arrow pointing AT the words; one that flattens
/// under them reads as the words being attached to the place, which is what an annotation is.
///
/// Returns { parts, tip } where `tip` is [x,y], the end of the level run - the point the label
/// should be anchored to.
function cht_leader(_mx, _my, _dx, _dy, _run, _w) {
    if (is_undefined(_run)) _run = 16;
    if (is_undefined(_w))   _w = 1.1;
    var _ex = _mx + _dx, _ey = _my + _dy;
    var _sign = (_dx >= 0) ? 1 : -1;
    var _tx = _ex + _sign * _run;
    var _out = [];
    array_push(_out, cht_poly([[_mx, _my], [_ex, _ey], [_tx, _ey]], false, _w, CHT_R_HATCH));
    // A small open circle at the mark end. A filled dot competes with the mark itself; an open one
    // reads as a pointer.
    array_push(_out, cht_ring(_mx, _my, max(1.2, _w * 1.6), _w * 0.8, CHT_R_HATCH));
    return { parts: _out, tip: [_tx, _ey] };
}

/// A complete landmark annotation: leader plus name, laid out on the side that has room.
///
/// @param _name    the text
/// @param _mx,_my  the mark's page position
/// @param _right   put the label to the right (true) or the left (false)
/// @param _up      run the leader up (true) or down (false)
/// @param _s       the mark's drawn size in pixels - the leader starts clear of it
/// @param _hand    the ink hand, for the tilt
///
/// Returns { parts, labels }.
function cht_label_annotation(_name, _mx, _my, _right, _up, _s, _hand, _w) {
    if (is_undefined(_w)) _w = max(0.8, _s * 0.035);
    var _sx = _right ? 1 : -1;
    var _sy = _up ? -1 : 1;
    // Start OUTSIDE the mark, never at its centre: a leader emerging from under a drawn building
    // looks like a mistake, and at small sizes it looks like part of the building.
    var _ox = _mx + _sx * _s * 0.42, _oy = _my + _sy * _s * 0.30;
    var _ld = cht_leader(_ox, _oy, _sx * _s * 0.55, _sy * _s * 0.55, _s * 0.55, _w);
    var _lb = cht_label_make(_name, _ld.tip[0] + _sx * 3, _ld.tip[1],
                             _right ? fa_left : fa_right, fa_middle,
                             CHT_R_INK, CHT_LB_BODY, 1.0, 0);
    if (!is_undefined(_hand)) cht_label_hand(_lb, _hand);
    return { parts: _ld.parts, labels: [_lb] };
}

/// ============================================================================================
/// THE QUERY - what the scribe writes beside a rumour
/// ============================================================================================

/// A drawn question mark, in the page's ink rather than in the font.
///
/// It is geometry and not a glyph on purpose: the query sits on top of a dashed rumour mark at
/// roughly a third of its size, and a font glyph at 6px is a smudge while three strokes at 6px is
/// still a question mark. It also keeps the annotation in the same hand as everything else, which
/// a font cannot do.
function cht_label_query(_x, _y, _s, _w) {
    if (is_undefined(_w)) _w = max(0.8, _s * 0.16);
    var _r = _s * 0.30;
    var _out = [];
    // The hook: three-quarters of a circle opening at the bottom right, then down to the stem.
    array_push(_out, cht_poly(cht_arc_pts(_x, _y - _s * 0.22, _r, pi * 0.92, pi * 2.30, 12),
                              false, _w, CHT_R_ACCENT));
    array_push(_out, cht_poly([[_x + _r * 0.62, _y - _s * 0.22 + _r * 0.62],
                               [_x, _y + _s * 0.10]], false, _w, CHT_R_ACCENT));
    array_push(_out, cht_dot(_x, _y + _s * 0.32, _w * 0.9, CHT_R_ACCENT));
    return _out;
}

/// ============================================================================================
/// PAGE FURNITURE THAT CARRIES TEXT
/// ============================================================================================

/// A scale bar: a ruled bar divided into alternating filled and open cells, with a caption.
///
/// The alternation is the whole point - a plain rule with numbers on it is a ruler, and a chart
/// wants the checkered bar that says "this is a survey drawing". Returns { parts, labels }.
///
/// @param _units  the text written at the right-hand end, e.g. "leagues"
/// @param _divs   how many cells; 4 or 6 reads best
function cht_label_scale_bar(_x, _y, _w, _h, _divs, _units, _hand, _wt) {
    if (is_undefined(_divs)) _divs = 4;
    if (is_undefined(_wt)) _wt = max(0.8, _h * 0.18);
    _divs = max(2, floor(_divs));
    var _parts = [], _labels = [];
    var _step = _w / _divs;
    for (var _i = 0; _i < _divs; _i++) {
        var _x0 = _x + _i * _step, _x1 = _x0 + _step;
        if ((_i % 2) == 0) array_push(_parts, cht_rect_fill(_x0, _y, _x1, _y + _h, CHT_R_MASS));
        else               array_push(_parts, cht_rect_poly(_x0, _y, _x1, _y + _h, _wt, CHT_R_INK));
    }
    array_push(_parts, cht_rect_poly(_x, _y, _x + _w, _y + _h, _wt, CHT_R_INK));
    // Ticks under the divisions, and a number at each end. Two numbers, not five: a scale bar
    // crowded with figures is unreadable at the size a chart actually shows it.
    for (var _i = 0; _i <= _divs; _i++) {
        var _tx = _x + _i * _step;
        array_push(_parts, cht_poly([[_tx, _y + _h], [_tx, _y + _h * 1.5]], false, _wt * 0.8, CHT_R_HATCH));
    }
    var _l0 = cht_label_make("0", _x, _y + _h * 1.7, fa_center, fa_top, CHT_R_HATCH, CHT_LB_BODY, 0.8);
    var _l1 = cht_label_make(string(_divs) + " " + _units, _x + _w, _y + _h * 1.7,
                             fa_center, fa_top, CHT_R_HATCH, CHT_LB_BODY, 0.8);
    if (!is_undefined(_hand)) { cht_label_hand(_l0, _hand); cht_label_hand(_l1, _hand); }
    array_push(_labels, _l0, _l1);
    return { parts: _parts, labels: _labels };
}

/// The title block: a cartouche with the region's name inside it, correctly inset for the frame
/// style. Returns { parts, labels }.
///
/// ⚠️ THE INSET COMES FROM cht_cartouche_inset, NEVER FROM A NUMBER TYPED HERE. A scroll's rolls
/// eat a third of its box and a plain rule eats a sixteenth; a shared constant would either put the
/// title through the scroll's curl or leave the plain rule looking empty. The frame owns the
/// answer because the frame is what changes.
function cht_label_title_block(_style, _x0, _y0, _x1, _y1, _title, _subtitle, _hand, _w) {
    var _parts = cht_cartouche(_style, _x0, _y0, _x1, _y1, _w);
    var _h = _y1 - _y0;
    var _pad = _h * cht_cartouche_inset(_style);
    var _cx = (_x0 + _x1) * 0.5;
    var _labels = [];
    var _has_sub = (!is_undefined(_subtitle) && _subtitle != "");

    var _ty = _has_sub ? (_y0 + _h * 0.34) : ((_y0 + _y1) * 0.5);
    var _t = cht_label_make(_title, _cx, _ty, fa_center, fa_middle, CHT_R_INK, CHT_LB_TITLE,
                            clamp((_h - _pad * 2) / 46, 0.45, 1.6));
    if (!is_undefined(_hand)) cht_label_hand(_t, _hand);
    array_push(_labels, _t);

    if (_has_sub) {
        var _s = cht_label_make(_subtitle, _cx, _y0 + _h * 0.68, fa_center, fa_middle,
                                CHT_R_HATCH, CHT_LB_BODY, clamp((_h - _pad * 2) / 62, 0.5, 1.2));
        if (!is_undefined(_hand)) cht_label_hand(_s, _hand);
        array_push(_labels, _s);
    }
    return { parts: _parts, labels: _labels };
}

/// A marginal note in the page's hand - the line of prose a cartographer writes in the empty
/// corner. Wrapped by the renderer, which is the only thing that can measure a string.
function cht_label_margin(_text, _x, _y, _hand, _scale) {
    var _lb = cht_label_make(_text, _x, _y, fa_left, fa_top, CHT_R_HATCH, CHT_LB_BODY,
                             is_undefined(_scale) ? 0.9 : _scale);
    if (!is_undefined(_hand)) cht_label_hand(_lb, _hand);
    return _lb;
}
