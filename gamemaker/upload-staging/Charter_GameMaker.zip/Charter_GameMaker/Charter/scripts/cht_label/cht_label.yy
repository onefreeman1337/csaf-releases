{
  "$GMScript": "v1",
  "%Name": "cht_label",
  "isCompatibility": false,
  "isDnD": false,
  "name": "cht_label",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}