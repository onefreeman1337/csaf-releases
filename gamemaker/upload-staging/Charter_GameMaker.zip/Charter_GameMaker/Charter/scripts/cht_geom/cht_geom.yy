{
  "$GMScript": "v1",
  "%Name": "cht_geom",
  "isCompatibility": false,
  "isDnD": false,
  "name": "cht_geom",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}