{
  "$GMScript": "v1",
  "%Name": "cht_palette",
  "isCompatibility": false,
  "isDnD": false,
  "name": "cht_palette",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}