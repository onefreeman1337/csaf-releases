/// CHARTER - demo. Clean Up.
///
/// The chart owns a cached SURFACE, and a surface is one of the few things in GameMaker that is not
/// garbage-collected. Freeing it here is the whole of the product's teardown story, and the demo
/// does it so a buyer copying this room copies the habit.
///
/// ⚠️ Guarded on `headless`, because the -selftest and -bake entry points return from Create before
/// `chart` is ever assigned - and Clean Up still runs on game_end(). Reading an unassigned instance
/// variable throws, and headless a thrown error is a MODAL DIALOG nobody is present to dismiss:
/// the process would hang on its way out and the harness would report a timeout on a run that had
/// already succeeded. Cheap guard, expensive omission.

if (headless) exit;

cht_chart_free(chart);
