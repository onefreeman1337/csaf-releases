/// CHARTER - demo. Draw GUI.
///
/// Draw GUI rather than Draw, because a chart page is interface: it is resolution-independent here
/// and it does not move with a view. Everything below is a public cht_ function - there is no
/// demo-only drawing path, so what a buyer sees in this room is what their own two lines produce.

if (headless) exit;

var _page = cht_page(cht_page_ids()[page_i]);
var _hand = cht_hand(cht_hand_ids()[hand_i]);

// -- THE CHART. One call. -------------------------------------------------------------------------
// The cached form: the page is re-inked only when something has actually changed, which every
// mutator in cht_chart signals for you.
cht_chart_draw_cached(chart, page_x0, page_y0, page_x1, page_y1, {});

// -- the walker -------------------------------------------------------------------------------------
// Drawn on top of the page, in the page's own accent, so the demo does not introduce a colour the
// product does not have.
var _wp = cht_chart_w2p(chart, px, py, page_x0, page_y0, page_x1, page_y1);
cht_draw_parts([
    cht_ring(_wp[0], _wp[1], 7, 1.6, CHT_R_ACCENT),
    cht_dot(_wp[0], _wp[1], 2.6, CHT_R_ACCENT)
], _page, walking ? 1 : 0.45);

// -- the legend panel ---------------------------------------------------------------------------------
var _lx = page_x1 + 26;
var _ly = page_y0 + 6;
var _lw = 1280 - _lx - 28;

draw_set_font(fnt_charter_title);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_colour(_page.ink);
draw_text(_lx, _ly, "CHARTER");
draw_set_font(fnt_charter);
draw_set_colour(_page.hatch);
draw_text(_lx, _ly + 40, "illuminated auto-cartography");
draw_text(_lx, _ly + 62, "v" + CHT_VERSION);

draw_set_colour(_page.rule);
draw_line_width(_lx, _ly + 92, _lx + _lw, _ly + 92, 1.4);

var _k = cht_chart_counts(chart);
var _rows = [
    ["page",       cht_page_name(cht_page_ids()[page_i])],
    ["hand",       cht_hand_name(cht_hand_ids()[hand_i])],
    ["rose",       cht_rose_name(cht_rose_ids()[rose_i])],
    ["cartouche",  cht_cartouche_name(cht_cartouche_ids()[cart_i])],
    ["border",     cht_border_ids()[border_i]],
    ["edge",       cht_edge_ids()[edge_i]],
    ["",           ""],
    ["charted",    string_format(_k.progress * 100, 1, 1) + "%  ("
                   + string(_k.seen) + " of " + string(_k.cells) + " cells)"],
    ["visited",    string(_k.visited)],
    ["sighted",    string(_k.sighted)],
    ["rumoured",   string(_k.rumoured)],
    ["undiscovered", string(_k.hidden)],
    ["route",      string(_k.route) + " points"]
];
var _ry = _ly + 106;
for (var _i = 0; _i < array_length(_rows); _i++) {
    if (_rows[_i][0] == "") { _ry += 12; continue; }
    draw_set_colour(_page.hatch);
    draw_text(_lx, _ry, _rows[_i][0]);
    draw_set_colour(_page.ink);
    draw_text(_lx + 120, _ry, _rows[_i][1]);
    _ry += 24;
}

_ry += 10;
draw_set_colour(_page.rule);
draw_line_width(_lx, _ry, _lx + _lw, _ry, 1.0);
_ry += 12;

var _keys = [
    "SPACE   walk / halt",
    "1  page palette      2  ink hand",
    "3  compass rose      4  cartouche",
    "5  border            6  page edge",
    "R  reveal all        F  forget",
    "S  save to a string  L  load it back",
    "F1 run the in-engine self-test",
    "click a landmark to identify it"
];
draw_set_colour(_page.hatch);
for (var _i = 0; _i < array_length(_keys); _i++) {
    draw_text(_lx, _ry, _keys[_i]);
    _ry += 22;
}

// -- what the mouse is over ---------------------------------------------------------------------------
if (!is_undefined(picked)) {
    _ry += 12;
    draw_set_colour(_page.accent);
    draw_text(_lx, _ry, picked.name);
    draw_set_colour(_page.hatch);
    draw_text(_lx, _ry + 22, cht_mark_name(picked.kind) + "  -  "
              + cht_state_name(picked.state));
}

// -- the self-test result, if F1 was pressed ----------------------------------------------------------
// Drawn on the page rather than printed, because a release build emits no console a player can see -
// which is the same measured fact that makes the headless harness read a FILE rather than stdout.
if (!is_undefined(test_result)) {
    var _pass = (test_result.passed == test_result.total);
    var _bx = page_x0 + 40, _by = page_y1 - 130;
    draw_set_colour(_page.ground);
    draw_rectangle(_bx, _by, _bx + 520, _by + 96, false);
    draw_set_colour(_pass ? _page.ink : _page.accent);
    draw_rectangle(_bx, _by, _bx + 520, _by + 96, true);
    draw_set_font(fnt_charter_title);
    draw_text(_bx + 16, _by + 12, "cht_selftest   " + string(test_result.passed)
              + " / " + string(test_result.total));
    draw_set_font(fnt_charter);
    draw_set_colour(_page.hatch);
    if (_pass) {
        draw_text(_bx + 16, _by + 58, "every assertion passed - and every comparator has a "
                  + "negative control");
    } else {
        draw_text(_bx + 16, _by + 58, test_result.lines[0]);
    }
}

// Put the font and alignment back. This demo is the buyer's first read of the product, and a
// quickstart that leaks draw state teaches them that the package does.
draw_set_font(-1);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_colour(c_white);
draw_set_alpha(1);
