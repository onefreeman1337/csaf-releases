/// CHARTER - demo. Step.
///
/// The walker moves, and ONE call tells the chart about it. That call is the whole integration
/// story for a buyer: cht_chart_observe reveals ground around the player, advances any landmark
/// they are now near enough to see or to have reached, and extends the route trail.

if (headless) exit;

// -- the walker ------------------------------------------------------------------------------------
if (walking) {
    var _n = array_length(tour);
    var _a = tour[leg];
    var _b = tour[(leg + 1) % _n];
    var _len = max(1, point_distance(_a[0], _a[1], _b[0], _b[1]));
    // Constant SPEED, not constant time per leg: a walker that crosses a short leg at the same
    // rate as a long one visibly accelerates, and it is the first thing anyone notices in a GIF.
    leg_t += leg_speed * 260 / _len;
    while (leg_t >= 1) {
        leg_t -= 1;
        leg = (leg + 1) % _n;
        _a = tour[leg];
        _b = tour[(leg + 1) % _n];
        _len = max(1, point_distance(_a[0], _a[1], _b[0], _b[1]));
    }
    px = lerp(_a[0], _b[0], leg_t);
    py = lerp(_a[1], _b[1], leg_t);

    // ⬅ THE ONE LINE. Everything the chart knows comes from this.
    cht_chart_observe(chart, px, py);
}

// -- controls ----------------------------------------------------------------------------------------
if (keyboard_check_pressed(vk_space)) walking = !walking;

if (keyboard_check_pressed(ord("1"))) {
    page_i = (page_i + 1) % array_length(cht_page_ids());
    cht_chart_set_page(chart, cht_page_ids()[page_i]);
}
if (keyboard_check_pressed(ord("2"))) {
    hand_i = (hand_i + 1) % array_length(cht_hand_ids());
    cht_chart_set_hand(chart, cht_hand_ids()[hand_i]);
}
if (keyboard_check_pressed(ord("3"))) {
    rose_i = (rose_i + 1) % array_length(cht_rose_ids());
    cht_chart_set_rose(chart, cht_rose_ids()[rose_i]);
}
if (keyboard_check_pressed(ord("4"))) {
    cart_i = (cart_i + 1) % array_length(cht_cartouche_ids());
    cht_chart_set_cartouche(chart, cht_cartouche_ids()[cart_i]);
}
if (keyboard_check_pressed(ord("5"))) {
    border_i = (border_i + 1) % array_length(cht_border_ids());
    cht_chart_set_border(chart, cht_border_ids()[border_i]);
}
if (keyboard_check_pressed(ord("6"))) {
    edge_i = (edge_i + 1) % 4;
    cht_chart_set_edge(chart, edge_i);
}

if (keyboard_check_pressed(ord("R"))) cht_chart_reveal_all(chart);
if (keyboard_check_pressed(ord("F"))) cht_chart_forget(chart);

// Save and load, on the same string a buyer would put in their own save file. Wired to keys in the
// demo because "it persists" is a claim, and a claim a buyer can press a key to check is a claim
// they will believe.
if (keyboard_check_pressed(ord("S"))) saved_state = cht_chart_save_string(chart);
if (keyboard_check_pressed(ord("L")) && saved_state != "") cht_chart_load_string(chart, saved_state);

// The in-engine suite. Same code the headless -selftest flag runs.
if (keyboard_check_pressed(vk_f1)) test_result = cht_selftest();

// Click a landmark to read it back - the same cht_chart_pick a buyer wires to their own UI.
picked = cht_chart_pick(chart, device_mouse_x_to_gui(0), device_mouse_y_to_gui(0),
                        page_x0, page_y0, page_x1, page_y1, 18);
