/// CHARTER - demo. Create.
///
/// This room is the buyer's quickstart, the GIF source, and the only real smoke test this engine
/// allows - GML cannot be unit-tested outside it. Everything drawn here comes from the same public
/// functions a buyer calls; there is no demo-only drawing path, deliberately, because a demo that
/// reaches into private helpers proves nothing about the product.

// -- headless entry points ----------------------------------------------------------------------
// Run the built executable with -selftest to run the suite, -bake to render the store sheets, or
// -gif to render the animation frames. Any of them and it never reaches the demo.
//
// ⚠️ `headless` IS LOAD-BEARING, AND THIS WING PAID A 180-SECOND TIMEOUT TO LEARN IT. game_end()
// does NOT stop the engine where it is called - it is honoured at the END of the current step. So
// Create returns early, nothing is initialised, and the Draw event then reads a variable that was
// never set, throws, and opens a MODAL error dialog. Headless there is nobody to dismiss it: the
// process never exits and the harness reports a meaningless timeout with no clue why.
//
// Set BEFORE the branches and cleared only if none fired, so a headless mode added later cannot
// forget to raise it. Step, Draw and Clean Up all check it first.
headless = true;
if (cht_selftest_requested()) { cht_selftest_main(); exit; }
if (cht_bake_requested())     { cht_bake_main();     exit; }
if (cht_gif_requested())      { cht_gif_main();      exit; }
headless = false;

// -- THE QUICKSTART. This is the block a buyer copies first. ------------------------------------
// Six calls to a live chart: create it over your world, tell it what is out there, tell it what
// the ground is made of, and then call observe() from your player. Nothing else is required.

world_w = 1600;
world_h = 1100;

chart = cht_chart_create(0, 0, world_w, world_h, 44, 30);
cht_chart_set_title(chart, "The Marchlands", "surveyed in the eleventh year");
cht_chart_set_ranges(chart, 210, 66);

// Terrain: any polygon, in world coordinates. The coast is a polygon rather than a rectangle
// because a rectangular sea is the fastest way to tell a player they are looking at a widget.
cht_chart_add_region(chart, "water", [[0, 690], [280, 640], [520, 700], [760, 660],
                                      [1010, 720], [1240, 690], [1600, 740],
                                      [1600, 1100], [0, 1100]]);
cht_chart_add_region(chart, "woodland", [[120, 150], [520, 110], [640, 300], [430, 430], [150, 380]]);
cht_chart_add_region(chart, "conifer", [[980, 90], [1400, 130], [1470, 340], [1080, 380]]);
cht_chart_add_region(chart, "marsh", [[560, 500], [860, 470], [900, 620], [600, 640]]);
cht_chart_add_region(chart, "moor", [[60, 440], [400, 470], [420, 640], [90, 620]]);
cht_chart_add_region(chart, "scree", [[1150, 400], [1480, 430], [1500, 600], [1180, 590]]);
cht_chart_add_region(chart, "cultivated", [[660, 190], [960, 170], [980, 400], [690, 420]]);
cht_chart_add_region(chart, "dune", [[1230, 760], [1560, 790], [1540, 900], [1250, 880]]);

// Landmarks. The last argument is whether the chart carries a RUMOUR of the place before the
// player has been near it - a rumoured landmark is drawn faint, dashed, and deliberately in the
// wrong place, and snaps to the truth the moment it is sighted. `The Whispering` and `The Grace`
// are registered with `false`, so they do not appear at all until they are found.
cht_chart_add_landmark(chart, "lm_city",   "city",      "Ostmarch",         340,  300, true);
cht_chart_add_landmark(chart, "lm_town",   "town",      "Wickthorn",        780,  330, true);
cht_chart_add_landmark(chart, "lm_hamlet", "hamlet",    "Little Fen",       640,  560, true);
cht_chart_add_landmark(chart, "lm_keep",   "keep",      "Greyward Keep",    200,  520, true);
cht_chart_add_landmark(chart, "lm_cit",    "citadel",   "Highwatch",       1310,  240, true);
cht_chart_add_landmark(chart, "lm_farm",   "farmstead", "Barleyhold",       830,  240, true);
cht_chart_add_landmark(chart, "lm_bridge", "bridge",    "The Long Bridge",  520,  690, true);
cht_chart_add_landmark(chart, "lm_ford",   "ford",      "Cattle Ford",      980,  700, true);
cht_chart_add_landmark(chart, "lm_pharos", "pharos",    "The Pharos",      1470,  790, true);
cht_chart_add_landmark(chart, "lm_mine",   "mine",      "Deepcut",         1240,  480, true);
cht_chart_add_landmark(chart, "lm_mill",   "mill",      "Ashmill",          700,  430, true);
cht_chart_add_landmark(chart, "lm_barrow", "barrow",    "The Long Barrow",  420,  180, true);
cht_chart_add_landmark(chart, "lm_circle", "circle",    "The Nine",         160,  200, true);
cht_chart_add_landmark(chart, "lm_abbey",  "abbey",     "St Cuthman's",    1080,  330, true);
cht_chart_add_landmark(chart, "lm_pass",   "pass",      "Hollow Pass",     1400,  500, true);
cht_chart_add_landmark(chart, "lm_ruin",   "ruin",      "Old Wall",         560,  420, true);
cht_chart_add_landmark(chart, "lm_shrine", "shrine",    "The Wayshrine",    900,  520, true);
cht_chart_add_landmark(chart, "lm_grove",  "grove",     "Hanging Grove",    300,  620, true);
cht_chart_add_landmark(chart, "lm_cave",   "cave",      "The Whispering",  1330,  620, false);
cht_chart_add_landmark(chart, "lm_wreck",  "wreck",     "The Grace",       1120,  860, false);

// -- the demo's own explorer ----------------------------------------------------------------------
// A walker following a fixed circuit, standing in for the buyer's player object. Its position is
// driven by a step counter and NOT by random(), so the demo produces the same journey every run -
// which is what makes it usable as a GIF source and as a smoke test at the same time.
tour = [[200, 260], [340, 300], [470, 250], [420, 180], [160, 200], [200, 520], [300, 620],
        [430, 560], [560, 420], [640, 560], [780, 560], [900, 520], [700, 430], [780, 330],
        [830, 240], [1000, 330], [1080, 330], [1180, 420], [1240, 480], [1330, 340],
        [1310, 240], [1400, 500], [1330, 620], [1240, 690], [1120, 860], [980, 700],
        [760, 660], [520, 690], [300, 620], [200, 400]];
leg = 0;
leg_t = 0;
leg_speed = 0.018;
walking = true;
px = tour[0][0];
py = tour[0][1];

// -- page settings the buyer can cycle -------------------------------------------------------------
page_i = 0;
hand_i = 0;
rose_i = 4;         // fleur
cart_i = 2;         // scroll
edge_i = 0;
border_i = 4;       // graticule
cht_chart_set_rose(chart, cht_rose_ids()[rose_i]);
cht_chart_set_cartouche(chart, cht_cartouche_ids()[cart_i]);
cht_chart_set_border(chart, cht_border_ids()[border_i]);

// -- the F1 suite ---------------------------------------------------------------------------------
// Held rather than printed to the console, because a release build emits nothing a player can see.
test_result = undefined;
saved_state = "";
// Assigned every Step, but declared here too: Draw GUI reading a variable that Step has not
// created yet is a runtime error, and the one frame where that could happen is the frame a buyer
// sees first.
picked = undefined;

// The chart page occupies the left of the room; the legend sits to its right.
page_x0 = 28;
page_y0 = 28;
page_x1 = 900;
page_y1 = 692;
