# Hearth — interiors that furnish themselves from purpose and occupant

**For GameMaker 2024.11 and newer. Pure GML. No sprites, no shaders, no extensions.**

You tell Hearth what a room is FOR and WHO LIVES IN IT. It furnishes the room: it chooses the
pieces, solves where they stand, decides what is lying about, ages the surfaces, lights the fire
and draws the whole thing.

A kitchen is a kitchen. But a kitchen belonging to a miser and a kitchen belonging to a healer are
not the same room — one has tally sticks, a locked box and a single crust, the other has a mortar,
drying herbs and a shelf of jars. Every interior asset pack on the market sells you the furniture
and leaves the assembly to you. **The assembly is this product.**

Everything on the store page was rendered by this package. There is not one image file in it.

---

## Install

1. In the IDE: **Tools ▸ Import Local Package**, choose `Hearth.yymps`.
2. Import **all** resources when the dialog asks.
3. Open **`rm_hearth_demo`** and press **Run**.

That room is the quickstart and it is also the smoke test — if it runs, the package imported
cleanly. Arrow keys walk through the twelve purposes and the ten households; W, T, P and G throw
the four continuous fields from one end of their range to the other.

### What you get

| | |
| --- | --- |
| `scripts/hth_*` | 14 scripts, raw readable GML, header-documented |
| `objects/obj_hearth_demo` | the demo driver — read it, it is the shortest usage example there is |
| `rooms/rm_hearth_demo` | the runnable demo room |
| `fonts/fnt_hearth*` | Open Sans, used **only** by the demo readout (see *Fonts* below) |

---

## The whole thing in three calls

```gml
// Create — a purpose, an occupant, and one integer seed
room = hth_room_of("kitchen", "healer", 1618);
pal  = hth_palette_build(room);

// Draw — the whole room, inside this rectangle
hth_room_draw(room, pal, 0, 0, room_width, room_height);
```

That is the entire required API. Everything below is optional.

```gml
hth_room_create(seed)                     // a room with everything seeded, purpose included
hth_room_derive(room)                     // ⛔ after ANY direct field assignment
hth_room_furnish(room, x, y, w, h)        // solve and check the layout without drawing
hth_item_draw(form, room, pal, x, y, s)   // one piece of furniture, on its own
```

### Bad input is refused, not fatal

Nothing in this package throws at your code. The four calls that **return a room or a palette**
(`hth_room_of`, `hth_room_create`, `hth_room_derive`, `hth_palette_build`, `hth_room_furnish`)
return `undefined` if you hand them something they cannot use — check with `is_struct()`. The two
**draw** calls (`hth_room_draw`, `hth_item_draw`) draw nothing and return. The two **sprite** calls
return `-1`, which `sprite_exists()` reports as false.

That covers wrong types *and* wrong names: `hth_room_of("kitchan", "healer", 1)` is refused, because
a misspelled purpose is the likeliest mistake anyone makes with this API and a type check cannot see
it. The 36-attack adversarial suite that establishes this is described under *Verification*.

---

## What you can steer

| field | range | what it moves |
| --- | --- | --- |
| `purpose` | 12 named | which furniture slots exist and what fills the ones that define the room |
| `occupant` | 10 named | the personal objects, the clutter vocabulary, the colour of the cloth |
| `prosperity` | 0..1 | pine or beech or oak; rushes or boards or cut flags; turned legs; upholstery |
| `tidiness` | 0..1 | how much incidental clutter, and how evenly anything is placed |
| `age` | 0..1 | every surface darkens, desaturates and flattens; smoke blackens the chimney |
| `warmth` | 0..1 | whether the fire is lit, and the light the room throws on everything in it |
| `region` | 6 named | wall surface, floor and whether the ceiling is beamed |

**Purposes:** kitchen · bedchamber · workshop · shop · taproom · study · chapel · storeroom ·
guardroom · infirmary · parlour · cell

**Occupants:** farmer · smith · healer · scholar · miser · soldier · merchant · priest · widow ·
child

---

## The corpus, counted

**72 distinct generated entities: 30 pieces of furniture and 42 personal objects.**

That number is counted by the package's own in-engine test suite and printed in its result file —
it is not twelve purposes multiplied by thirty forms. Every one of the 72 is drawn from GML
geometry shaded by surface normal against a single fixed lamp; there is no sprite, no atlas and no
texture page, and `sprites/` does not exist in this project.

Furniture: hearth · stove · bed · cot · cradle · table · trestle · bench · chair · stool · chest ·
wardrobe · shelf · dresser · counter · barrel · crate · rug · loom · anvil · desk · altar ·
cauldron · rack · basin · lamp · sack · tub · screen · bookcase

---

## The layout is solved, and it is checked before anything is drawn

This is the part that is not decoration. A generated room can be drawn perfectly and still be
obviously wrong to a human: a wardrobe floating clear of the wall, a bed standing where the door
opens, furniture at a perfectly even pitch, the only window behind the chimney breast. Every one
of those is valid geometry, so no drawing check can see any of them.

So Hearth solves the layout first and asserts it, and **retries with a fresh arrangement rather
than drawing a room that failed**:

- every piece stands inside the room, not through a side wall
- no two pieces in the same depth band occupy the same floor
- the door's swing is clear of everything, including anything hung on the wall
- the window is given a piece of wall that nothing tall is standing in front of
- a primary furnishing slot is never dropped — a chapel always has its altar

The package's test suite runs those checks over **all 360 rooms** of the corpus — twelve purposes
crossed with ten occupants at three seeds each — and requires zero defects. `room.layout.defects`
is on every room you make, so you can read the verdict yourself.

---

## Verification, stated honestly

GML cannot be unit-tested outside the engine. What this package does instead is test itself
**inside** it: `Hearth.exe -selftest` runs **3,523 assertions** against the shipping build and
writes the result to a file. They cover the corpus being complete and joined up, every declared
extent against its real measured geometry, every triangle fan's star-shaped precondition, every
palette role resolving, the 360-room layout sweep, furniture spacing that is never a ruler,
purposes and occupants being measurably distinct, the drawing staying inside the rectangle it was
given, and determinism.

What those assertions **cannot** do is judge a picture. The store gallery was reviewed by eye, and
seven rounds of corrections came out of that review rather than out of the suite.

---

## Performance

A furnished room is a few thousand triangles. Build it once — `hth_room_of` and
`hth_room_furnish` are the expensive calls and neither belongs in a Step event. If you want a busy
room for free, cache it into a sprite once and blit that; the demo draws live every frame because
at demo size it costs nothing.

```gml
// Create — cache the whole furnished room. YOU own the sprite; sprite_delete it in Clean Up.
spr = hth_room_to_sprite(room, pal, 512, 320);

// Draw
draw_sprite(spr, 0, x, y);
```

`hth_room_to_sprite(room, pal, w, h)` returns `-1` rather than a blank sprite if you hand it
something that is not a room. There is also `hth_render_to_sprite(parts, pal, w, h, pad)` for
caching **one piece of furniture** on its own — it takes a part list, not a room, and likewise
returns `-1` if given anything else. Neither may be called from a Draw event: nesting render
targets can silently produce an empty sprite.

Nothing in this package calls `random()`. Everything comes from a seeded hash, so the same seed is
the same room forever and nothing flickers between frames.

---

## Namespacing

Every global, macro and function in this package is prefixed `hth_` / `HTH_`. GML's global
namespace is flat and a collision in your project is a support ticket nobody can debug remotely.
The two font resources are `fnt_hearth` and `fnt_hearth_title`.

---

## Fonts

`fnt_hearth` and `fnt_hearth_title` are rendered from **Open Sans**, licensed Apache-2.0. They are
used **only** by the demo room's readout. The rooms themselves draw no text at all, so if you
delete both fonts after importing you lose the readout and nothing else.

The licence text and the required notice travel in `fonts/` — `Apache-2.0.txt` and
`THIRD-PARTY-NOTICES.txt`. Keep them if you redistribute the compiled result.

---

## Compatibility

Built and gate-verified against GameMaker runtime **2024.14.4.268** (the stable GMS2 runtime), on
Windows, through a real Igor package build. It is pure GML with no extensions, no shaders and no
platform calls, so it carries to every export target GameMaker supports.

GMRT is not a dependency and is not claimed. The GMS2 runtime is supported by the vendor until at
least Q1 2028.

---

## Licence

One licence per developer who works with the source. Build anything you like with it, commercial
or free, forever. Do not resell or redistribute the package itself. Full terms in `LICENSE.txt`.

---

*Hearth is the interiors half of a pair. Its sibling,* **Borough**, *draws the outsides of the same
buildings, at the same scale, lit by the same lamp, in the same six regions — they are designed to
sit on one screen.*

**AI disclosure:** the code and the graphics in this package were written and generated with AI
assistance. Every claim on this page was measured by the tooling described above.
