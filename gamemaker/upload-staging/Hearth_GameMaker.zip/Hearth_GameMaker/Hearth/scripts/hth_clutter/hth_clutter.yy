{
  "$GMScript": "v1",
  "%Name": "hth_clutter",
  "isCompatibility": false,
  "isDnD": false,
  "name": "hth_clutter",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}