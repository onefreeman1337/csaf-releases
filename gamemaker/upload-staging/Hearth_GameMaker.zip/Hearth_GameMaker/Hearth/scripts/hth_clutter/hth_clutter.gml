/// HEARTH - hth_clutter. THE OTHER HALF OF THE CORPUS: forty-two personal objects.
///
/// ⛔ THIS FILE IS THE HALF OF THE PRODUCT THAT ANSWERS "WHOSE ROOM IS THIS?" The furniture
/// answers what the room is FOR. Every interior asset pack on the market can put a table and a
/// dresser in a kitchen; none of them can tell you whether the kitchen belongs to a healer or to
/// a miser, because that difference is not in the furniture, it is in the mortar and the jars
/// and the bundles of drying herbs, or in the tally sticks and the single crust.
///
/// Each occupant carries a vocabulary of six objects and the first TWO are the signature: the
/// solver never drops them, however tidy or however poor the room is. Tidiness controls how much
/// INCIDENTAL clutter there is; it does not control whether a smith owns tongs.
///
/// -- SCALE AND WHY THESE ARE NOT JUST SMALL FURNITURE ------------------------------------------
/// A clutter object is authored in the same unit box as a piece of furniture and to the SAME
/// scale, so a bowl is genuinely bowl-sized next to the table it stands on. That is what makes
/// them read; a generator that scales its props to fit the space it has left produces a room
/// with a bucket the size of a chair in it, and no check catches that because both are correctly
/// drawn.
///
/// ⚠️ THEY ARE ALSO THE SMALLEST MASSES IN THE PACKAGE, WHICH MAKES THEM THE BEVEL'S WORST CASE.
/// A quill is 0.006 wide. hth_bev_for takes the SMALLER dimension for exactly this reason - a
/// single package-wide bevel constant would turn every object on this page inside out, and
/// nothing mechanical would see it: the outline is fine, the winding is fine, the ink is fine,
/// the picture is wrong.
/// ============================================================================================

/// Every clutter form, in corpus order. hth_selftest asserts that this list and the union of all
/// ten occupant vocabularies are the SAME SET in both directions - so an object nobody owns and
/// an object with no builder are each a red test rather than an invisible gap.
function hth_clutter_names() {
    return ["basket", "boots", "loaf", "apples", "jug", "sickle",
            "tongs", "billet", "bucket", "hammer", "rag",
            "mortar", "herbs", "jars", "bowl", "cloth", "candle",
            "book", "scroll", "quill", "spectacles", "inkpot",
            "strongbox", "tally", "purse", "crust", "keys",
            "helm", "spear", "whetstone", "tankard",
            "scales", "ledger", "bolt",
            "icon", "censer",
            "distaff", "portrait", "shroud",
            "doll", "ball", "top"];
}

/// The declared extent of a clutter form, in unit-box units. Same contract as the furniture
/// table: hth_selftest measures the real rendered bounds and requires them to agree, because the
/// clutter solver reads THIS to decide whether two objects on a table collide.
function hth_clutter_extent(_form) {
    switch (_form) {
        case "basket":     return { hw: 0.052, h: 0.095 };
        case "boots":      return { hw: 0.050, h: 0.058 };
        case "loaf":       return { hw: 0.042, h: 0.036 };
        case "apples":     return { hw: 0.046, h: 0.052 };
        case "jug":        return { hw: 0.040, h: 0.070 };
        case "sickle":     return { hw: 0.048, h: 0.052 };
        case "tongs":      return { hw: 0.030, h: 0.086 };
        case "billet":     return { hw: 0.048, h: 0.024 };
        case "bucket":     return { hw: 0.044, h: 0.094 };
        case "hammer":     return { hw: 0.034, h: 0.076 };
        case "rag":        return { hw: 0.044, h: 0.024 };
        case "mortar":     return { hw: 0.038, h: 0.052 };
        case "herbs":      return { hw: 0.038, h: 0.084 };
        case "jars":       return { hw: 0.052, h: 0.058 };
        case "bowl":       return { hw: 0.042, h: 0.030 };
        case "cloth":      return { hw: 0.053, h: 0.030 };
        case "candle":     return { hw: 0.020, h: 0.082 };
        case "book":       return { hw: 0.040, h: 0.030 };
        case "scroll":     return { hw: 0.050, h: 0.026 };
        case "quill":      return { hw: 0.022, h: 0.070 };
        case "spectacles": return { hw: 0.040, h: 0.024 };
        case "inkpot":     return { hw: 0.024, h: 0.034 };
        case "strongbox":  return { hw: 0.052, h: 0.048 };
        case "tally":      return { hw: 0.044, h: 0.058 };
        case "purse":      return { hw: 0.030, h: 0.044 };
        case "crust":      return { hw: 0.026, h: 0.020 };
        case "keys":       return { hw: 0.026, h: 0.057 };
        case "helm":       return { hw: 0.042, h: 0.056 };
        case "spear":      return { hw: 0.026, h: 0.190 };
        case "whetstone":  return { hw: 0.036, h: 0.020 };
        case "tankard":    return { hw: 0.046, h: 0.054 };
        case "scales":     return { hw: 0.071, h: 0.076 };
        case "ledger":     return { hw: 0.044, h: 0.034 };
        case "bolt":       return { hw: 0.050, h: 0.046 };
        case "icon":       return { hw: 0.040, h: 0.062 };
        case "censer":     return { hw: 0.034, h: 0.072 };
        case "distaff":    return { hw: 0.030, h: 0.150 };
        case "portrait":   return { hw: 0.044, h: 0.058 };
        case "shroud":     return { hw: 0.048, h: 0.040 };
        case "doll":       return { hw: 0.026, h: 0.058 };
        case "ball":       return { hw: 0.026, h: 0.052 };
        case "top":        return { hw: 0.024, h: 0.040 };
    }
    return { hw: 0.030, h: 0.030 };
}

/// ============================================================================================
/// THE OBJECTS
///
/// Every one is authored with its footprint on HTH_GROUND, like everything else in the package.
/// ============================================================================================

/// -- the farmer ------------------------------------------------------------------------------

/// A basket: a woven body flaring to the rim, with a bail handle drawn as an arc. Wicker is a
/// matte material with almost no ramp span, and it is the weave that identifies it.
function hth_c_basket(_room, _st) {
    var _e = hth_clutter_extent("basket"), _hw = _e.hw, _h = _e.h;
    // The rim sits at 0.55 of the box and the bail fills the rest of it. Drawn with the rim
    // at 0.72 and the handle added above, a basket measured 1.24 times its declared height.
    var _rim = HTH_G - _h * 0.55;
    var _out = hth_mass([[-_hw, _rim], [_hw, _rim],
                         [_hw * 0.68, HTH_G], [-_hw * 0.68, HTH_G]],
                        "wicker", hth_bev_for(_hw * 2, _h * 0.55), 2);
    for (var _i = 1; _i < 4; _i++) {
        var _t = _i / 4;
        var _y = lerp(_rim, HTH_G, _t);
        var _w = lerp(_hw, _hw * 0.68, _t);
        _out = hth_append(_out, hth_line_in(-_w, _y, _w, _y, "wicker", 0.003));
    }
    array_push(_out, hth_arc(0, _rim, min(_hw * 0.86, _h * 0.42), pi, HTH_TAU, 0.005,
                             "wicker1"));
    return _out;
}

/// A pair of boots, one fallen over. The FALLEN one is the whole idea: a pair standing neatly
/// side by side reads as a shop display, and a room is not a shop.
function hth_c_boots(_room, _st) {
    var _e = hth_clutter_extent("boots"), _hw = _e.hw, _h = _e.h;
    var _out = [];
    _out = hth_append(_out, hth_member(-_hw, HTH_G - _h, -_hw * 0.30, HTH_G - _h * 0.24,
                                        "leather"));
    _out = hth_append(_out, hth_member(-_hw, HTH_G - _h * 0.30, -_hw * 0.02, HTH_G, "leather"));
    // The fallen one: a low lying mass, wider than it is tall.
    _out = hth_append(_out, hth_mass([[_hw * 0.06, HTH_G - _h * 0.34], [_hw, HTH_G - _h * 0.26],
                                      [_hw, HTH_G], [_hw * 0.06, HTH_G]],
                                     "leather", 0.006, 1));
    return _out;
}

/// A loaf: a domed mass with three slashes across the top. The slashes are what stop it reading
/// as a stone.
function hth_c_loaf(_room, _st) {
    var _e = hth_clutter_extent("loaf"), _hw = _e.hw, _h = _e.h;
    var _out = hth_dome_mass(0, HTH_G, _hw, _h, "clay", 14);
    for (var _i = 0; _i < 3; _i++) {
        var _t = (_i + 1) / 4;
        var _x = lerp(-_hw * 0.7, _hw * 0.7, _t);
        _out = hth_append(_out, hth_line_in(_x - _hw * 0.10, HTH_G - _h * 0.62,
                                            _x + _hw * 0.10, HTH_G - _h * 0.86, "clay", 0.004));
    }
    return _out;
}

/// A heap of apples: overlapping discs at three heights. A heap is a SILHOUETTE with bumps on
/// its top edge, which is what separates it from a bowl.
function hth_c_apples(_room, _st) {
    var _e = hth_clutter_extent("apples"), _hw = _e.hw, _h = _e.h;
    var _out = [];
    // The heap is two courses and its TOP is the top of the box: an upper disc centred a
    // half-box up plus its own radius measured 1.36 times the declared height.
    var _r = _h * 0.30;
    var _pos = [[-_hw * 0.62, 0], [_hw * 0.62, 0], [0, 0], [-_hw * 0.31, -_h * 0.40],
                [_hw * 0.33, -_h * 0.40]];
    for (var _i = 0; _i < array_length(_pos); _i++) {
        _out = hth_append(_out, hth_mass(hth_ellipse_pts(_pos[_i][0], HTH_G - _r + _pos[_i][1],
                                                         _r, _r, 12),
                                         "cloth", _r * 0.34, 2));
    }
    return _out;
}

/// A jug: a bellied body, a narrow neck, a flaring lip and one handle. The handle is an ARC,
/// because a fan cannot draw a C and a jug without a handle is a vase.
function hth_c_jug(_room, _st) {
    var _e = hth_clutter_extent("jug"), _hw = _e.hw, _h = _e.h;
    var _n = 14, _pts = [];
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n;
        var _y = lerp(HTH_G, HTH_G - _h * 0.74, _t);
        var _w = _hw * (0.62 + 0.38 * sin(pi * min(1, _t * 1.35)));
        array_push(_pts, [_w, _y]);
    }
    for (var _i = _n; _i >= 0; _i--) {
        var _t = _i / _n;
        var _y = lerp(HTH_G, HTH_G - _h * 0.74, _t);
        var _w = _hw * (0.62 + 0.38 * sin(pi * min(1, _t * 1.35)));
        array_push(_pts, [-_w, _y]);
    }
    var _out = hth_mass(_pts, "clay", hth_bev_for(_hw * 2, _h * 0.74) * 0.8, 2);
    _out = hth_append(_out, hth_member(-_hw * 0.42, HTH_G - _h, _hw * 0.42, HTH_G - _h * 0.72,
                                        "clay"));
    // The handle is drawn INSIDE the half-width, not hung off it. An arc contributes its
    // centre plus its radius PLUS its stroke half-width to the bounds, which is the part
    // that is easy to forget and was worth 19% of this object.
    array_push(_out, hth_arc(_hw * 0.42, HTH_G - _h * 0.52, _hw * 0.40, -pi * 0.5, pi * 0.5,
                             0.006, "clay1"));
    return _out;
}

/// A sickle: a wooden grip and a curved blade. The CURVE is the identity and it is drawn as a
/// stroked arc, never as a filled crescent - a lune is concave about every point on it and a fan
/// would silently fill the whole half disc. This wing shipped exactly that defect once, on a
/// moon.
function hth_c_sickle(_room, _st) {
    var _e = hth_clutter_extent("sickle"), _hw = _e.hw, _h = _e.h;
    var _out = hth_member(-_hw, HTH_G - _h * 0.22, -_hw * 0.30, HTH_G, "wood2");
    array_push(_out, hth_arc(_hw * 0.10, HTH_G - _h * 0.16, _h * 0.72,
                             pi * 1.10, pi * 1.92, 0.007, "iron3"));
    array_push(_out, hth_arc(_hw * 0.10, HTH_G - _h * 0.16, _h * 0.63,
                             pi * 1.14, pi * 1.88, 0.004, "iron1"));
    return _out;
}

/// -- the smith -------------------------------------------------------------------------------

/// Tongs: two legs crossing at a rivet, jaws at the top. Two straight members meeting at a point
/// read as an X and no framing stops the eye completing it - so the jaws are SPLAYED apart at
/// the top, which is what a real pair of tongs does and what stops the X.
function hth_c_tongs(_room, _st) {
    var _e = hth_clutter_extent("tongs"), _hw = _e.hw, _h = _e.h;
    var _out = [];
    for (var _s = -1; _s <= 1; _s += 2) {
        array_push(_out, hth_fill([[_s * _hw * 0.92, HTH_G - _h],
                                   [_s * _hw * 0.62, HTH_G - _h],
                                   [_s * 0.004, HTH_G],
                                   [_s * 0.010, HTH_G]], "iron2"));
    }
    array_push(_out, hth_dot(0, HTH_G - _h * 0.28, 0.006, "iron4"));
    return _out;
}

/// A billet: a bar of iron on the floor, one end still bright from the fire.
function hth_c_billet(_room, _st) {
    var _e = hth_clutter_extent("billet"), _hw = _e.hw, _h = _e.h;
    var _out = hth_member(-_hw, HTH_G - _h, _hw, HTH_G, "iron");
    if (_room.fire_lit) {
        array_push(_out, hth_fill([[_hw * 0.42, HTH_G - _h * 0.86], [_hw * 0.94, HTH_G - _h * 0.86],
                                   [_hw * 0.94, HTH_G - _h * 0.16], [_hw * 0.42, HTH_G - _h * 0.16]],
                                  "ember"));
    }
    return _out;
}

/// A bucket: a tapered vessel with a hoop and a bail. Narrower at the bottom, unlike a tub,
/// which flares - a silhouette difference, not a fill difference.
function hth_c_bucket(_room, _st) {
    var _e = hth_clutter_extent("bucket"), _hw = _e.hw, _h = _e.h;
    // Same law as the basket: the bail is part of the bucket, so the rim comes down to 0.58
    // and the handle fills the top of the box.
    var _rim = HTH_G - _h * 0.58;
    var _out = hth_mass([[-_hw, _rim], [_hw, _rim],
                         [_hw * 0.66, HTH_G], [-_hw * 0.66, HTH_G]],
                        "wood2", hth_bev_for(_hw * 2, _h * 0.58), 2);
    _out = hth_append(_out, hth_member(-_hw * 0.94, HTH_G - _h * 0.36, _hw * 0.94,
                                        HTH_G - _h * 0.29, "iron"));
    array_push(_out, hth_arc(0, _rim, min(_hw * 0.94, _h * 0.38), pi, HTH_TAU, 0.005,
                             "iron1"));
    return _out;
}

/// A hammer: a haft and a head. Two masses whose silhouette STEPS, which is what makes them read
/// as two objects rather than as one bar with a colour change.
function hth_c_hammer(_room, _st) {
    var _e = hth_clutter_extent("hammer"), _hw = _e.hw, _h = _e.h;
    var _out = hth_member(-0.007, HTH_G - _h * 0.80, 0.007, HTH_G, "wood2");
    _out = hth_append(_out, hth_member(-_hw, HTH_G - _h, _hw * 0.58, HTH_G - _h * 0.74, "iron"));
    _out = hth_append(_out, hth_mass([[_hw * 0.58, HTH_G - _h * 0.99], [_hw, HTH_G - _h * 0.92],
                                      [_hw, HTH_G - _h * 0.82], [_hw * 0.58, HTH_G - _h * 0.75]],
                                     "iron", 0.005, 1));
    return _out;
}

/// A rag: a crumpled cloth, drawn as three overlapping low lobes so its top edge is irregular.
/// A rectangle of cloth on a floor reads as a mat.
function hth_c_rag(_room, _st) {
    var _e = hth_clutter_extent("rag"), _hw = _e.hw, _h = _e.h;
    var _out = [];
    var _lobes = 3;
    for (var _i = 0; _i < _lobes; _i++) {
        var _t = (_i + 0.5) / _lobes;
        var _cx = lerp(-_hw * 0.62, _hw * 0.62, _t);
        var _r = _hw * (0.42 + 0.16 * hth_rng_next(_st));
        _out = hth_append(_out, hth_dome_mass(_cx, HTH_G, _r, _h * (0.62 + 0.38 * ((_i + 1) % 2)),
                                              "linen", 10));
    }
    return _out;
}

/// -- the healer ------------------------------------------------------------------------------

/// A mortar with its pestle leaning in it. The pestle at an ANGLE is the identity; upright it
/// reads as a candle in a pot.
function hth_c_mortar(_room, _st) {
    var _e = hth_clutter_extent("mortar"), _hw = _e.hw, _h = _e.h;
    var _out = hth_mass([[-_hw, HTH_G - _h * 0.64], [_hw, HTH_G - _h * 0.64],
                         [_hw * 0.54, HTH_G], [-_hw * 0.54, HTH_G]],
                        "stone", hth_bev_for(_hw * 2, _h * 0.64), 2);
    _out = hth_append(_out, hth_mass([[-_hw * 0.30, HTH_G - _h], [-_hw * 0.10, HTH_G - _h],
                                      [_hw * 0.44, HTH_G - _h * 0.58], [_hw * 0.24, HTH_G - _h * 0.58]],
                                     "wood", 0.005, 1));
    return _out;
}

/// A bundle of drying herbs, hung head down. Stems gathered at the top, leaves splaying below -
/// so its silhouette WIDENS downward, which nothing else in the corpus does.
function hth_c_herbs(_room, _st) {
    var _e = hth_clutter_extent("herbs"), _hw = _e.hw, _h = _e.h;
    var _out = hth_member(-0.006, HTH_G - _h, 0.006, HTH_G - _h * 0.74, "wood2");
    _out = hth_append(_out, hth_member(-_hw * 0.30, HTH_G - _h * 0.80, _hw * 0.30,
                                        HTH_G - _h * 0.70, "cloth"));
    var _n = 7;
    for (var _i = 0; _i < _n; _i++) {
        var _t = (_i + 0.5) / _n;
        var _tipx = lerp(-_hw, _hw, _t);
        var _tipy = HTH_G - _h * (0.10 + 0.26 * abs(0.5 - _t) * 2);
        array_push(_out, hth_poly([[0, HTH_G - _h * 0.70], [_tipx * 0.55, _tipy - _h * 0.16],
                                   [_tipx, _tipy]], false, 0.005, "cloth1"));
    }
    return _out;
}

/// Three jars of different heights, stoppered with cloth. THREE, and unequal: two identical jars
/// read as a pattern, three unequal ones read as a shelf somebody uses.
function hth_c_jars(_room, _st) {
    var _e = hth_clutter_extent("jars"), _hw = _e.hw, _h = _e.h;
    var _out = [];
    var _hs = [1.00, 0.72, 0.88];
    for (var _i = 0; _i < 3; _i++) {
        var _cx = lerp(-_hw * 0.66, _hw * 0.66, _i / 2);
        var _jh = _h * _hs[_i];
        var _jw = _hw * 0.28;
        _out = hth_append(_out, hth_member(_cx - _jw, HTH_G - _jh * 0.84, _cx + _jw, HTH_G,
                                           "clay"));
        _out = hth_append(_out, hth_dome_mass(_cx, HTH_G - _jh * 0.84, _jw * 1.05, _jh * 0.16,
                                              "linen", 8));
    }
    return _out;
}

/// A bowl: a shallow inverted dome, wider at the rim than at the foot.
function hth_c_bowl(_room, _st) {
    var _e = hth_clutter_extent("bowl"), _hw = _e.hw, _h = _e.h;
    var _mat = (_room.prosperity > 0.6) ? "pewter" : "clay";
    var _out = hth_mass([[-_hw, HTH_G - _h], [_hw, HTH_G - _h],
                         [_hw * 0.46, HTH_G], [-_hw * 0.46, HTH_G]],
                        _mat, hth_bev_for(_hw * 2, _h), 2);
    _out = hth_append(_out, hth_member(-_hw, HTH_G - _h, _hw, HTH_G - _h * 0.76, _mat));
    return _out;
}

/// A folded cloth: three stacked bands, each slightly offset. The OFFSET is what makes it read
/// as folded rather than as a striped block.
function hth_c_cloth(_room, _st) {
    var _e = hth_clutter_extent("cloth"), _hw = _e.hw, _h = _e.h;
    var _out = [];
    for (var _i = 0; _i < 3; _i++) {
        var _off = (_i - 1) * _hw * 0.14;
        var _y1 = HTH_G - _h * (_i / 3);
        var _y0 = HTH_G - _h * ((_i + 1) / 3);
        _out = hth_append(_out, hth_member(-_hw + _off, _y0, _hw + _off, _y1,
                                           (_i == 1) ? "cloth" : "linen"));
    }
    return _out;
}

/// A candle in a holder, lit if there is any warmth in the room at all.
function hth_c_candle(_room, _st) {
    var _e = hth_clutter_extent("candle"), _hw = _e.hw, _h = _e.h;
    var _out = hth_mass([[-_hw, HTH_G - _h * 0.14], [_hw, HTH_G - _h * 0.14],
                         [_hw * 0.50, HTH_G], [-_hw * 0.50, HTH_G]], "brass", 0.005, 1);
    _out = hth_append(_out, hth_member(-_hw * 0.36, HTH_G - _h * 0.86, _hw * 0.36,
                                        HTH_G - _h * 0.14, "linen"));
    if (_room.warmth > 0.20) {
        array_push(_out, hth_fill([[-_hw * 0.24, HTH_G - _h * 0.86], [0, HTH_G - _h * 1.02],
                                   [_hw * 0.24, HTH_G - _h * 0.86]], "flame"));
        array_push(_out, hth_dot(0, HTH_G - _h * 0.90, _hw * 0.12, "flame_hi"));
    }
    return _out;
}

/// -- the scholar -----------------------------------------------------------------------------

/// A book lying flat, with a leather cover, a block of leaves and a clasp.
function hth_c_book(_room, _st) {
    var _e = hth_clutter_extent("book"), _hw = _e.hw, _h = _e.h;
    var _out = hth_member(-_hw, HTH_G - _h * 0.62, _hw, HTH_G, "linen");
    _out = hth_append(_out, hth_member(-_hw, HTH_G - _h, _hw, HTH_G - _h * 0.56, "leather"));
    _out = hth_append(_out, hth_member(_hw * 0.68, HTH_G - _h * 0.86, _hw * 1.00,
                                        HTH_G - _h * 0.30, "brass"));
    return _out;
}

/// A rolled scroll with a ribbon round it. Lying down, so it is wider than it is tall - which is
/// the difference between a scroll and a candle at four pixels.
function hth_c_scroll(_room, _st) {
    var _e = hth_clutter_extent("scroll"), _hw = _e.hw, _h = _e.h;
    var _out = hth_dome_mass(0, HTH_G, _hw, _h, "linen", 12);
    _out = hth_append(_out, hth_member(-_hw * 0.16, HTH_G - _h * 1.02, _hw * 0.16, HTH_G,
                                        "cloth"));
    return _out;
}

/// A quill standing in an inkpot. The FEATHER is a taper leaning off vertical, which is the only
/// thing that separates it from a candle.
function hth_c_quill(_room, _st) {
    var _e = hth_clutter_extent("quill"), _hw = _e.hw, _h = _e.h;
    var _out = hth_mass([[-_hw * 0.62, HTH_G - _h * 0.26], [_hw * 0.62, HTH_G - _h * 0.26],
                         [_hw * 0.46, HTH_G], [-_hw * 0.46, HTH_G]], "clay", 0.005, 1);
    _out = hth_append(_out, hth_mass([[-0.004, HTH_G - _h * 0.30], [0.004, HTH_G - _h * 0.30],
                                      [_hw * 0.72, HTH_G - _h * 0.96], [_hw * 0.60, HTH_G - _h * 0.98]],
                                     "linen", 0.004, 1));
    return _out;
}

/// Spectacles: two rings joined by a bridge. Rings, not discs - a lens is glass and glass is not
/// a fill.
function hth_c_spectacles(_room, _st) {
    var _e = hth_clutter_extent("spectacles"), _hw = _e.hw, _h = _e.h;
    var _r = _h * 0.46;
    var _out = [];
    for (var _s = -1; _s <= 1; _s += 2) {
        array_push(_out, hth_dot(_s * _hw * 0.52, HTH_G - _r, _r, "glass"));
        array_push(_out, hth_ring(_s * _hw * 0.52, HTH_G - _r, _r, 0.005, "brass3"));
    }
    _out = hth_append(_out, hth_line_in(-_hw * 0.16, HTH_G - _r, _hw * 0.16, HTH_G - _r,
                                        "brass", 0.005));
    return _out;
}

/// An inkpot: a small squat vessel with a dark mouth. The dark mouth is the whole object.
function hth_c_inkpot(_room, _st) {
    var _e = hth_clutter_extent("inkpot"), _hw = _e.hw, _h = _e.h;
    var _out = hth_mass([[-_hw * 0.72, HTH_G - _h], [_hw * 0.72, HTH_G - _h],
                         [_hw, HTH_G], [-_hw, HTH_G]], "clay", 0.006, 2);
    _out = hth_append(_out, hth_recess(-_hw * 0.48, HTH_G - _h * 1.06, _hw * 0.48,
                                        HTH_G - _h * 0.84, "soot"));
    return _out;
}

/// -- the miser -------------------------------------------------------------------------------

/// A strongbox: a small iron-bound chest with a big lock plate. It is the LOCK that says miser.
function hth_c_strongbox(_room, _st) {
    var _e = hth_clutter_extent("strongbox"), _hw = _e.hw, _h = _e.h;
    var _out = hth_member(-_hw, HTH_G - _h * 0.82, _hw, HTH_G, "wood");
    _out = hth_append(_out, hth_member(-_hw, HTH_G - _h, _hw, HTH_G - _h * 0.74, "iron"));
    for (var _s = -1; _s <= 1; _s += 2) {
        _out = hth_append(_out, hth_member(_s * _hw * 0.72 - 0.006, HTH_G - _h,
                                           _s * _hw * 0.72 + 0.006, HTH_G, "iron"));
    }
    _out = hth_append(_out, hth_member(-_hw * 0.20, HTH_G - _h * 0.78, _hw * 0.20,
                                        HTH_G - _h * 0.32, "iron"));
    array_push(_out, hth_dot(0, HTH_G - _h * 0.54, 0.006, "soot0"));
    return _out;
}

/// Tally sticks: notched rods leaning together. Their notches are the count, and the count is
/// carried by how MANY notches there are, never by how wide the notch is drawn.
function hth_c_tally(_room, _st) {
    var _e = hth_clutter_extent("tally"), _hw = _e.hw, _h = _e.h;
    var _out = [];
    for (var _i = 0; _i < 3; _i++) {
        var _lean = (_i - 1) * _hw * 0.52;
        array_push(_out, hth_fill([[_lean - 0.006, HTH_G - _h], [_lean + 0.006, HTH_G - _h],
                                   [_lean * 0.24 + 0.006, HTH_G], [_lean * 0.24 - 0.006, HTH_G]],
                                  "wood22"));
        for (var _k = 1; _k < 5; _k++) {
            var _t = _k / 5;
            var _nx = lerp(_lean, _lean * 0.24, _t);
            _out = hth_append(_out, hth_line_in(_nx - 0.006, lerp(HTH_G - _h, HTH_G, _t),
                                                _nx + 0.006, lerp(HTH_G - _h, HTH_G, _t),
                                                "wood2", 0.003));
        }
    }
    return _out;
}

/// A purse: a drawn bag with a pinched neck and a cord.
function hth_c_purse(_room, _st) {
    var _e = hth_clutter_extent("purse"), _hw = _e.hw, _h = _e.h;
    var _out = hth_dome_mass(0, HTH_G, _hw, _h * 0.72, "leather", 12);
    _out = hth_append(_out, hth_member(-_hw * 0.34, HTH_G - _h * 0.90, _hw * 0.34,
                                        HTH_G - _h * 0.64, "leather"));
    _out = hth_append(_out, hth_line_in(-_hw * 0.40, HTH_G - _h * 0.76, _hw * 0.40,
                                        HTH_G - _h * 0.76, "cloth", 0.004));
    return _out;
}

/// A crust of bread. Small, irregular, and the whole point is that it is ALONE on the table.
function hth_c_crust(_room, _st) {
    var _e = hth_clutter_extent("crust"), _hw = _e.hw, _h = _e.h;
    return hth_mass([[-_hw, HTH_G], [-_hw * 0.44, HTH_G - _h], [_hw * 0.62, HTH_G - _h * 0.78],
                     [_hw, HTH_G]], "clay", 0.005, 1);
}

/// A ring of keys hung on a nail. The RING is an arc and the keys hang from it.
function hth_c_keys(_room, _st) {
    var _e = hth_clutter_extent("keys"), _hw = _e.hw, _h = _e.h;
    var _out = [];
    array_push(_out, hth_ring(0, HTH_G - _h * 0.80, _hw * 0.52, 0.005, "iron2"));
    for (var _i = 0; _i < 3; _i++) {
        var _kx = lerp(-_hw * 0.60, _hw * 0.60, _i / 2);
        _out = hth_append(_out, hth_member(_kx - 0.004, HTH_G - _h * 0.72, _kx + 0.004,
                                           HTH_G - _h * 0.14, "iron"));
        _out = hth_append(_out, hth_member(_kx - 0.004, HTH_G - _h * 0.26, _kx + 0.012,
                                           HTH_G - _h * 0.14, "iron"));
    }
    return _out;
}

/// -- the soldier -----------------------------------------------------------------------------

/// A helm: a domed skull with a nasal bar and a rim. The NASAL is what makes it a helm rather
/// than a pot, and it is a silhouette notch.
function hth_c_helm(_room, _st) {
    var _e = hth_clutter_extent("helm"), _hw = _e.hw, _h = _e.h;
    var _out = hth_dome_mass(0, HTH_G - _h * 0.18, _hw, _h * 0.82, "iron", 14);
    _out = hth_append(_out, hth_member(-_hw * 1.02, HTH_G - _h * 0.26, _hw * 1.02,
                                        HTH_G - _h * 0.12, "iron"));
    _out = hth_append(_out, hth_member(-0.006, HTH_G - _h * 0.44, 0.006, HTH_G, "iron"));
    return _out;
}

/// A spear leaning against a wall: a long shaft and a leaf head. The tallest clutter object in
/// the corpus, which is why the solver treats it as floor-standing and never puts it on a table.
function hth_c_spear(_room, _st) {
    var _e = hth_clutter_extent("spear"), _hw = _e.hw, _h = _e.h;
    var _out = hth_mass([[-0.006, HTH_G - _h * 0.78], [0.006, HTH_G - _h * 0.78],
                         [_hw * 0.90 + 0.006, HTH_G], [_hw * 0.90 - 0.006, HTH_G]],
                        "wood2", 0.004, 1);
    _out = hth_append(_out, hth_mass([[-_hw * 0.42, HTH_G - _h * 0.80], [0, HTH_G - _h],
                                      [_hw * 0.42, HTH_G - _h * 0.80], [0, HTH_G - _h * 0.68]],
                                     "iron", 0.005, 1));
    return _out;
}

/// A whetstone: a low flat block with one worn, dished face. The DISH is the wear and it is a
/// silhouette, so it survives to game size.
function hth_c_whetstone(_room, _st) {
    var _e = hth_clutter_extent("whetstone"), _hw = _e.hw, _h = _e.h;
    var _n = 10, _pts = [];
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n;
        array_push(_pts, [-_hw + 2 * _hw * _t, HTH_G - _h + _h * 0.34 * sin(pi * _t)]);
    }
    array_push(_pts, [_hw, HTH_G]);
    array_push(_pts, [-_hw, HTH_G]);
    return hth_mass(_pts, "stone", hth_bev_for(_hw * 2, _h) * 0.8, 2);
}

/// A tankard: a straight-sided vessel with a handle and a lid. Straight sides are the whole
/// difference from a jug, which bellies.
function hth_c_tankard(_room, _st) {
    var _e = hth_clutter_extent("tankard"), _hw = _e.hw, _h = _e.h;
    var _out = hth_mass([[-_hw * 0.80, HTH_G - _h * 0.88], [_hw * 0.80, HTH_G - _h * 0.88],
                         [_hw * 0.68, HTH_G], [-_hw * 0.68, HTH_G]], "pewter", 0.006, 2);
    _out = hth_append(_out, hth_member(-_hw * 0.86, HTH_G - _h, _hw * 0.86, HTH_G - _h * 0.84,
                                        "pewter"));
    array_push(_out, hth_arc(_hw * 0.56, HTH_G - _h * 0.48, _hw * 0.36, -pi * 0.5, pi * 0.5,
                             0.006, "pewter1"));
    return _out;
}

/// -- the merchant ----------------------------------------------------------------------------

/// A balance: a post, a beam, and two pans on cords. The beam TILTS, because a level balance
/// reads as a symbol and a tilted one reads as an object in use.
function hth_c_scales(_room, _st) {
    var _e = hth_clutter_extent("scales"), _hw = _e.hw, _h = _e.h;
    var _tilt = _h * 0.10;
    var _out = hth_member(-0.006, HTH_G - _h * 0.86, 0.006, HTH_G, "brass");
    _out = hth_append(_out, hth_member(-_hw * 0.24, HTH_G - _h * 0.10, _hw * 0.24, HTH_G,
                                        "brass"));
    // THE PANS ARE THE WIDEST PART OF A BALANCE, so the beam ends come in to 0.76 and the
    // pans reach the declared half-width. Hung off a full-width beam they measured 1.26.
    var _arm = _hw * 0.76;
    _out = hth_append(_out, hth_mass([[-_arm, HTH_G - _h * 0.86 - _tilt - 0.004],
                                      [_arm, HTH_G - _h * 0.86 + _tilt - 0.004],
                                      [_arm, HTH_G - _h * 0.86 + _tilt + 0.004],
                                      [-_arm, HTH_G - _h * 0.86 - _tilt + 0.004]],
                                     "brass", 0.003, 1));
    for (var _s = -1; _s <= 1; _s += 2) {
        var _py = HTH_G - _h * 0.86 + _s * _tilt + _h * 0.24;
        _out = hth_append(_out, hth_line_in(_s * _arm, HTH_G - _h * 0.86 + _s * _tilt,
                                            _s * _arm, _py, "brass", 0.003));
        _out = hth_append(_out, hth_mass([[_s * _arm - _hw * 0.24, _py],
                                          [_s * _arm + _hw * 0.24, _py],
                                          [_s * _arm + _hw * 0.14, _py + _h * 0.10],
                                          [_s * _arm - _hw * 0.14, _py + _h * 0.10]],
                                         "brass", 0.004, 1));
    }
    return _out;
}

/// A ledger: a thick book standing upright, leaning, with a ribbon marker.
function hth_c_ledger(_room, _st) {
    var _e = hth_clutter_extent("ledger"), _hw = _e.hw, _h = _e.h;
    var _out = hth_mass([[-_hw * 0.72, HTH_G - _h], [_hw * 0.30, HTH_G - _h * 0.92],
                         [_hw, HTH_G], [-_hw * 0.10, HTH_G]], "leather", 0.006, 2);
    _out = hth_append(_out, hth_line_in(_hw * 0.10, HTH_G - _h * 0.86, _hw * 0.34, HTH_G - _h * 0.10,
                                        "cloth", 0.005));
    return _out;
}

/// A bolt of cloth: a rolled cylinder lying on its side with the end of the cloth hanging free.
function hth_c_bolt(_room, _st) {
    var _e = hth_clutter_extent("bolt"), _hw = _e.hw, _h = _e.h;
    var _out = hth_dome_mass(0, HTH_G, _hw, _h * 0.74, "cloth", 14);
    _out = hth_append(_out, hth_mass([[_hw * 0.30, HTH_G - _h * 0.70], [_hw * 0.98, HTH_G - _h * 0.52],
                                      [_hw * 1.02, HTH_G], [_hw * 0.44, HTH_G]],
                                     "cloth", 0.006, 1));
    for (var _i = 1; _i < 4; _i++) {
        var _t = _i / 4;
        _out = hth_append(_out, hth_line_in(-_hw * 0.86, HTH_G - _h * 0.70 * _t,
                                            _hw * 0.20, HTH_G - _h * 0.74 * _t, "cloth", 0.003));
    }
    return _out;
}

/// -- the priest ------------------------------------------------------------------------------

/// An icon: a small panel on a stand, with a gilt ground and a dark figure. The GILT is the
/// object; a plain panel is a board.
function hth_c_icon(_room, _st) {
    var _e = hth_clutter_extent("icon"), _hw = _e.hw, _h = _e.h;
    var _out = hth_member(-_hw, HTH_G - _h, _hw, HTH_G - _h * 0.10, "wood");
    array_push(_out, hth_rect_fill(-_hw * 0.78, HTH_G - _h * 0.90, _hw * 0.78,
                                   HTH_G - _h * 0.18, "gild"));
    _out = hth_append(_out, hth_dome_mass(0, HTH_G - _h * 0.22, _hw * 0.34, _h * 0.46,
                                          "soot", 10));
    array_push(_out, hth_dot(0, HTH_G - _h * 0.66, _hw * 0.20, "linen3"));
    _out = hth_append(_out, hth_member(-_hw * 0.34, HTH_G - _h * 0.14, _hw * 0.34, HTH_G, "wood"));
    return _out;
}

/// A censer on three chains, with smoke rising. The CHAINS are what say censer, and they are
/// strokes because a chain is a line.
function hth_c_censer(_room, _st) {
    var _e = hth_clutter_extent("censer"), _hw = _e.hw, _h = _e.h;
    var _out = [];
    for (var _s = -1; _s <= 1; _s += 2) {
        _out = hth_append(_out, hth_line_in(_s * _hw * 0.10, HTH_G - _h,
                                            _s * _hw * 0.80, HTH_G - _h * 0.40, "brass", 0.004));
    }
    _out = hth_append(_out, hth_dome_mass(0, HTH_G - _h * 0.06, _hw * 0.86, _h * 0.36,
                                          "brass", 12));
    _out = hth_append(_out, hth_member(-_hw * 0.86, HTH_G - _h * 0.44, _hw * 0.86,
                                        HTH_G - _h * 0.36, "brass"));
    array_push(_out, hth_dot(0, HTH_G - _h * 0.20, _hw * 0.24, "ember"));
    return _out;
}

/// -- the widow -------------------------------------------------------------------------------

/// A distaff: a tall staff wound with unspun wool, and a spindle hanging. The wound MASS at the
/// top is what makes it a distaff rather than a broom.
function hth_c_distaff(_room, _st) {
    var _e = hth_clutter_extent("distaff"), _hw = _e.hw, _h = _e.h;
    var _out = hth_member(-0.005, HTH_G - _h, 0.005, HTH_G, "wood2");
    _out = hth_append(_out, hth_dome_mass(0, HTH_G - _h * 0.62, _hw * 0.94, _h * 0.30,
                                          "linen", 14));
    for (var _i = 1; _i < 5; _i++) {
        var _t = _i / 5;
        _out = hth_append(_out, hth_line_in(-_hw * 0.80, HTH_G - _h * (0.66 + 0.20 * _t),
                                            _hw * 0.80, HTH_G - _h * (0.70 + 0.20 * _t),
                                            "linen", 0.003));
    }
    array_push(_out, hth_dot(_hw * 0.62, HTH_G - _h * 0.20, _hw * 0.24, "wood1"));
    return _out;
}

/// A framed portrait on a stand, the face turned away into shadow. It is the only object in the
/// corpus that is deliberately illegible, and that is the point.
function hth_c_portrait(_room, _st) {
    var _e = hth_clutter_extent("portrait"), _hw = _e.hw, _h = _e.h;
    var _out = hth_member(-_hw, HTH_G - _h, _hw, HTH_G - _h * 0.06, "wood");
    _out = hth_append(_out, hth_recess(-_hw * 0.76, HTH_G - _h * 0.88, _hw * 0.76,
                                        HTH_G - _h * 0.18, "soot"));
    _out = hth_append(_out, hth_dome_mass(0, HTH_G - _h * 0.24, _hw * 0.34, _h * 0.34,
                                          "soot", 10));
    _out = hth_append(_out, hth_member(-_hw * 0.10, HTH_G - _h * 0.10, _hw * 0.30, HTH_G, "wood"));
    return _out;
}

/// A folded shroud: linen, folded twice, with a black band across it.
function hth_c_shroud(_room, _st) {
    var _e = hth_clutter_extent("shroud"), _hw = _e.hw, _h = _e.h;
    var _out = hth_member(-_hw, HTH_G - _h * 0.62, _hw, HTH_G, "linen");
    _out = hth_append(_out, hth_member(-_hw * 0.88, HTH_G - _h, _hw * 0.88, HTH_G - _h * 0.56,
                                        "linen"));
    _out = hth_append(_out, hth_member(-_hw * 0.88, HTH_G - _h * 0.42, _hw * 0.88,
                                        HTH_G - _h * 0.26, "soot"));
    return _out;
}

/// -- the child -------------------------------------------------------------------------------

/// A rag doll: a head, a body and two stub arms. Its ARMS are what make it a doll rather than a
/// skittle, and they are a silhouette step.
function hth_c_doll(_room, _st) {
    var _e = hth_clutter_extent("doll"), _hw = _e.hw, _h = _e.h;
    var _out = hth_mass(hth_ellipse_pts(0, HTH_G - _h * 0.82, _hw * 0.66, _h * 0.20, 12),
                        "linen", 0.005, 2);
    _out = hth_append(_out, hth_mass([[-_hw * 0.46, HTH_G - _h * 0.66], [_hw * 0.46, HTH_G - _h * 0.66],
                                      [_hw * 0.62, HTH_G], [-_hw * 0.62, HTH_G]],
                                     "cloth", 0.006, 2));
    for (var _s = -1; _s <= 1; _s += 2) {
        _out = hth_append(_out, hth_mass([[_s * _hw * 0.40, HTH_G - _h * 0.62],
                                          [_s * _hw, HTH_G - _h * 0.44],
                                          [_s * _hw, HTH_G - _h * 0.32],
                                          [_s * _hw * 0.40, HTH_G - _h * 0.46]],
                                         "linen", 0.004, 1));
    }
    return _out;
}

/// A ball: a sewn leather sphere with a seam. The SEAM is what stops it reading as a dot.
function hth_c_ball(_room, _st) {
    var _e = hth_clutter_extent("ball"), _hw = _e.hw, _h = _e.h;
    var _r = min(_hw, _h * 0.5);
    var _out = hth_mass(hth_ellipse_pts(0, HTH_G - _r, _r, _r, 16), "leather", _r * 0.32, 2);
    array_push(_out, hth_arc(0, HTH_G - _r, _r * 0.62, pi * 0.15, pi * 0.85, 0.004, "leather0"));
    return _out;
}

/// A spinning top, fallen on its side. Fallen, because a top standing upright is a top that
/// nobody has been playing with.
function hth_c_top(_room, _st) {
    var _e = hth_clutter_extent("top"), _hw = _e.hw, _h = _e.h;
    var _out = hth_mass([[-_hw, HTH_G - _h * 0.82], [_hw * 0.20, HTH_G - _h],
                         [_hw * 0.20, HTH_G - _h * 0.18], [-_hw, HTH_G]],
                        "wood", 0.006, 2);
    _out = hth_append(_out, hth_mass([[_hw * 0.20, HTH_G - _h * 0.86], [_hw, HTH_G - _h * 0.60],
                                      [_hw, HTH_G - _h * 0.48], [_hw * 0.20, HTH_G - _h * 0.34]],
                                     "wood", 0.004, 1));
    return _out;
}

/// ============================================================================================
/// DISPATCH AND PLACEMENT
/// ============================================================================================

/// Build one clutter object, fitted to its declared box. See hth_fit_to_extent in hth_furniture
/// for why the box is made true here rather than by editing the number: every builder reads its
/// own extent as its drawing scale, so the measured-to-declared ratio is scale-invariant and no
/// edit to the table can ever move it. A basket's bail handle and a balance's pans are correct
/// objects that stand outside the box they claim.
function hth_clutter_build(_form, _room, _seed) {
    return hth_fit_to_extent(hth_clutter_build_raw(_form, _room, _seed),
                             hth_clutter_extent(_form));
}

/// The dispatch itself, BEFORE the fit.
function hth_clutter_build_raw(_form, _room, _seed) {
    var _st = hth_rng(hth_hash32("clutter|" + _form + "|" + string(_seed)));
    switch (_form) {
        case "basket":     return hth_c_basket(_room, _st);
        case "boots":      return hth_c_boots(_room, _st);
        case "loaf":       return hth_c_loaf(_room, _st);
        case "apples":     return hth_c_apples(_room, _st);
        case "jug":        return hth_c_jug(_room, _st);
        case "sickle":     return hth_c_sickle(_room, _st);
        case "tongs":      return hth_c_tongs(_room, _st);
        case "billet":     return hth_c_billet(_room, _st);
        case "bucket":     return hth_c_bucket(_room, _st);
        case "hammer":     return hth_c_hammer(_room, _st);
        case "rag":        return hth_c_rag(_room, _st);
        case "mortar":     return hth_c_mortar(_room, _st);
        case "herbs":      return hth_c_herbs(_room, _st);
        case "jars":       return hth_c_jars(_room, _st);
        case "bowl":       return hth_c_bowl(_room, _st);
        case "cloth":      return hth_c_cloth(_room, _st);
        case "candle":     return hth_c_candle(_room, _st);
        case "book":       return hth_c_book(_room, _st);
        case "scroll":     return hth_c_scroll(_room, _st);
        case "quill":      return hth_c_quill(_room, _st);
        case "spectacles": return hth_c_spectacles(_room, _st);
        case "inkpot":     return hth_c_inkpot(_room, _st);
        case "strongbox":  return hth_c_strongbox(_room, _st);
        case "tally":      return hth_c_tally(_room, _st);
        case "purse":      return hth_c_purse(_room, _st);
        case "crust":      return hth_c_crust(_room, _st);
        case "keys":       return hth_c_keys(_room, _st);
        case "helm":       return hth_c_helm(_room, _st);
        case "spear":      return hth_c_spear(_room, _st);
        case "whetstone":  return hth_c_whetstone(_room, _st);
        case "tankard":    return hth_c_tankard(_room, _st);
        case "scales":     return hth_c_scales(_room, _st);
        case "ledger":     return hth_c_ledger(_room, _st);
        case "bolt":       return hth_c_bolt(_room, _st);
        case "icon":       return hth_c_icon(_room, _st);
        case "censer":     return hth_c_censer(_room, _st);
        case "distaff":    return hth_c_distaff(_room, _st);
        case "portrait":   return hth_c_portrait(_room, _st);
        case "shroud":     return hth_c_shroud(_room, _st);
        case "doll":       return hth_c_doll(_room, _st);
        case "ball":       return hth_c_ball(_room, _st);
        case "top":        return hth_c_top(_room, _st);
    }
    return [];
}

/// Which furniture forms have a FLAT TOP you can put something down on, and how high it is.
///
/// ⚠️ NOT EVERYTHING WITH A TOP QUALIFIES. A desk's top is sloped and a dresser's shelves are
/// already full of the household's pewter; putting a bowl on either produces an object visibly
/// floating at an angle, which is the "wardrobe hovering off the wall" failure arriving on a
/// different surface. Returning undefined is a decision, not an omission.
function hth_form_surface(_form) {
    switch (_form) {
        case "table":    return { y: 0.310, frac: 0.86 };
        case "trestle":  return { y: 0.310, frac: 0.90 };
        case "counter":  return { y: 0.420, frac: 0.90 };
        case "chest":    return { y: 0.250, frac: 0.78 };
        case "stool":    return { y: 0.190, frac: 0.66 };
        case "bench":    return { y: 0.190, frac: 0.84 };
        case "crate":    return { y: 0.240, frac: 0.78 };
        case "barrel":   return { y: 0.360, frac: 0.54 };
        case "altar":    return { y: 0.400, frac: 0.70 };
    }
    return undefined;
}

/// Solve where the occupant's objects go.
///
/// ⛔ THE FIRST TWO OBJECTS ARE PLACED FIRST AND NEVER DROPPED. They are the occupant's
/// signature, and a solver that lets tidiness or poverty remove them has thrown away the axis
/// the product sells. Everything after them is incidental clutter, and how much of it there is
/// comes from the occupant's WORK (hth_occupant_density) multiplied by untidiness - two
/// deliberately orthogonal fields, which is the only reason the corpus looks varied.
///
/// Returns world-space placements: { form, x, y, s }.
function hth_clutter_solve(_room, _geom) {
    var _lay = _room.layout;
    var _st = hth_rng(hth_hash32("clut|" + _room.purpose + "|" + _room.occupant + "|"
                                 + string(_room.seed)));
    var _objs = _room.objects;
    // ⛔ FOUR OBJECTS IS NOT A HOUSEHOLD. Measured from this formula's own numbers at the hero
    // sheet's state - density 0.76, tidiness 0.55, prosperity 0.48 - the old
    // `2 + round(6 * 0.76 * 0.64 * 0.71)` gave FOUR, so the difference between a farmer's kitchen
    // and a miser's kitchen was being carried by four small things on the one image a buyer
    // decides from. The occupant axis is the product; it has to be visible without a caption.
    // Floor four, range nine: a working kitchen lands at eight or nine, a miser's cell at five,
    // so the two differ in DENSITY as well as in kind.
    // The tidiness multiplier runs 0.30 to 1.30 rather than 0.45 to 1.00: at the dials sheet's
    // own state that is four objects against eleven, which is a difference visible without
    // reading the caption. At the old swing it was about two.
    var _want = 3 + round(10 * _room.density * (0.30 + 1.00 * (1 - _room.tidiness))
                            * (0.55 + 0.45 * _room.prosperity));
    _want = min(_want, array_length(_objs) * 2);

    // Collect the surfaces the room offers, plus the floor.
    var _surf = [];
    for (var _i = 0; _i < array_length(_lay.items); _i++) {
        var _it = _lay.items[_i];
        var _s = hth_form_surface(_it.form);
        if (is_undefined(_s)) continue;
        var _scale = hth_band_scale(_geom, _it.band);
        array_push(_surf, {
            x:  _geom.x + _geom.w * _it.x,
            y:  hth_band_floor(_geom, _it.band) - _s.y * _scale,
            hw: _it.hw * _geom.w * _s.frac,
            s:  _scale,
            band: _it.band,
        });
    }

    var _out = [];
    var _placed_on = array_create(max(1, array_length(_surf)), 0);

    for (var _o = 0; _o < _want; _o++) {
        var _form = _objs[_o % array_length(_objs)];
        var _ce = hth_clutter_extent(_form);

        // A tall object never goes on a table: it goes on the floor, leaning on something. The
        // spear is the case that forces this and it is a real physical fact, not a special case.
        var _tall = (_ce.h > 0.11);
        var _use_floor = _tall || (array_length(_surf) == 0)
                         || (hth_rng_next(_st) < 0.30 + 0.35 * (1 - _room.tidiness));

        if (!_use_floor) {
            var _si = floor(hth_rng_next(_st) * array_length(_surf));
            var _sf = _surf[_si];
            var _n = _placed_on[_si];
            if (_n >= 3) { _use_floor = true; }
            else {
                _placed_on[_si] = _n + 1;
                // Objects on a surface are spread across it, jittered by untidiness. A tidy
                // household lines them up near the middle; an untidy one pushes them to the edge.
                var _slots_n = 3;
                var _t = (_n + 0.5) / _slots_n
                         + (hth_rng_next(_st) - 0.5) * 0.34 * (1 - _room.tidiness);
                array_push(_out, {
                    form: _form,
                    x:    _sf.x + (_t - 0.5) * 2 * _sf.hw,
                    y:    _sf.y,
                    s:    _sf.s,
                });
                continue;
            }
        }

        // The floor. Keep out of the door swing, and keep to the near band where the eye is.
        var _cx = 0;
        var _ok = false;
        for (var _try = 0; _try < 12 && !_ok; _try++) {
            _cx = HTH_MARGIN + hth_rng_next(_st) * (1 - 2 * HTH_MARGIN);
            var _chw = (_ce.hw * _geom.sfree) / _geom.w;
            if (!hth_spans_overlap(_cx - _chw, _cx + _chw,
                                   _lay.door_clear[0], _lay.door_clear[1])) _ok = true;
        }
        if (!_ok) continue;
        array_push(_out, {
            form: _form,
            x:    _geom.x + _geom.w * _cx,
            y:    _geom.yfront - (_geom.yfront - _geom.yback) * 0.10 * hth_rng_next(_st),
            s:    _geom.sfree,
        });
    }
    return _out;
}
