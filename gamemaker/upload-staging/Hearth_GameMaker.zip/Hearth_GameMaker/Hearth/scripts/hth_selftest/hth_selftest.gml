/// HEARTH - hth_selftest. The assertions, run in-engine against a real Igor-built executable.
///
/// GML CANNOT BE UNIT-TESTED OUTSIDE THE ENGINE. That is a standing fact about this wing and it
/// is not being papered over. What does NOT follow is that the engine cannot test itself
/// unattended: Internal_Ops/run_engine.ps1 builds through gm_gate.ps1, unzips the package, runs
/// the executable with -selftest and reads the result file. Everything below runs on the
/// shipping build, not on a side re-implementation.
///
/// ⛔ AND THE THING THESE ASSERTIONS CANNOT DO IS JUDGE A PICTURE. A sibling product in this wing
/// passed 369 in-engine assertions, an extent check AND an ink-bounds check, and shipped a
/// gallery with seven defects - every one found by opening the PNG and looking at it. These make
/// NAMED failure modes unshippable. They are not the review.
///
/// ⚠️ A TEST THAT HAS ONLY EVER PASSED IS NOT A TEST. STAGE 0 feeds every instrument in this file
/// a shape it MUST reject, because an instrument that cannot fail proves nothing about the thing
/// it is pointed at. This wing has shipped a suite whose every distinctness assertion passed
/// vacuously, forever, and could not have gone red for any input.
/// ============================================================================================

/// ⛔ 0.0001, NOT 0.00001, AND THE DIFFERENCE IS MEASURED RATHER THAN STYLISTIC.
/// math_get_epsilon() returns 0.00001 on this runtime and PARTICIPATES IN COMPARISONS, so a
/// tolerance at or below it can never fire in the `<` direction - a sibling product's suite had
/// every distinctness assertion passing vacuously. Writing the tolerance exactly AT the epsilon
/// fails the other way: a difference of ZERO compares as "equal", and equal is not less-than,
/// producing a false RED on two points that are the same array object. Stay an order of
/// magnitude clear in BOTH directions. GML has no exponent-literal syntax at all: `1e-4` is a
/// lexer error that reads like a bracket bug.
#macro HTH_ST_EPS 0.0001

/// How far outside the unit box a part may reach. Not zero: a stroke has half-width, and a
/// mantel shelf deliberately oversails its chimney breast.
#macro HTH_ST_BOX 0.62

/// The Jaccard distance two rooms must exceed to count as different rooms. Reported beside its
/// measurement in the result file so the number can be re-derived and argued with.
#macro HTH_ST_ROOM_FLOOR 0.20

/// Nothing in the corpus may space its furniture like a ruler. Uniform-by-construction measures
/// exactly 1.000, so this is barely above it on purpose: it is a check for a MECHANISM having
/// been replaced by a constant, not a taste judgement, and it is applied to the WORST room in the
/// sweep. See hth_layout_gap_ratio for why this replaced a variance floor that produced a false
/// red on its first run.
#macro HTH_ST_RATIO_MIN 1.020

/// And the TYPICAL room must be visibly uneven, which a minimum can never say. Applied to the
/// median of the whole sweep.
#macro HTH_ST_RATIO_MED 1.350

/// How much a form may be shrunk to fit its own declared box before that stops being an oversail
/// and starts being a builder that is simply wrong about its size.
#macro HTH_ST_FIT_FLOOR 0.850

function hth_st_new() { return { pass: 0, fail: 0, failures: [] }; }

function hth_st_ok(_r, _cond, _what) {
    if (_cond) { _r.pass++; return true; }
    _r.fail++;
    array_push(_r.failures, _what);
    return false;
}

/// ============================================================================================
/// THE INSTRUMENTS
/// ============================================================================================

/// Is this fill's outline STAR-SHAPED ABOUT pts[0]?
///
/// ⛔ THIS IS THE PRECONDITION hth_render_fill DOCUMENTS AND CANNOT ENFORCE. pr_trianglefan walks
/// pts[0] -> pts[i] -> pts[i+1]; hand it a concave outline and it spans the concavity SILENTLY -
/// no error, no failed assertion, just a wrong picture. This wing shipped every moon crescent as
/// a quarter for exactly that reason, on a product whose geometry suite was passing honestly the
/// whole time, because A SUITE THAT COMPUTES POINTS CAN NEVER SEE A FILL RULE.
///
/// The test: every triangle from pts[0] must wind the same way. A crescent, a C, an L or a star
/// produces both signs and is rejected.
function hth_st_fan_ok(_pts) {
    var _n = array_length(_pts);
    if (_n < 3) return false;
    var _pos = false, _neg = false;
    for (var _i = 1; _i < _n - 1; _i++) {
        var _ax = _pts[_i][0]     - _pts[0][0], _ay = _pts[_i][1]     - _pts[0][1];
        var _bx = _pts[_i + 1][0] - _pts[0][0], _by = _pts[_i + 1][1] - _pts[0][1];
        var _cr = _ax * _by - _ay * _bx;
        if (_cr >  HTH_ST_EPS) _pos = true;
        if (_cr < -HTH_ST_EPS) _neg = true;
    }
    return !(_pos && _neg);
}

/// Jaccard distance between two lists of names, 0 = identical set, 1 = share nothing.
///
/// ⛔ IT REFUSES AN EMPTY PAIR RATHER THAN RETURNING 0. `[].every()` is true and a strict-subset
/// check over zero entries passes VACUOUSLY - this factory has shipped exactly that and reported
/// clean. Returning -1 on an empty input makes the caller's assertion go red instead.
function hth_st_jaccard(_a, _b) {
    var _na = array_length(_a), _nb = array_length(_b);
    if (_na == 0 || _nb == 0) return -1;
    var _inter = 0, _seen = [];
    for (var _i = 0; _i < _na; _i++) {
        var _v = _a[_i];
        var _dup = false;
        for (var _k = 0; _k < array_length(_seen); _k++) if (_seen[_k] == _v) _dup = true;
        if (_dup) continue;
        array_push(_seen, _v);
        for (var _j = 0; _j < _nb; _j++) if (_b[_j] == _v) { _inter++; break; }
    }
    var _ub = [];
    for (var _i = 0; _i < _na; _i++) {
        var _dup2 = false;
        for (var _k = 0; _k < array_length(_ub); _k++) if (_ub[_k] == _a[_i]) _dup2 = true;
        if (!_dup2) array_push(_ub, _a[_i]);
    }
    for (var _j = 0; _j < _nb; _j++) {
        var _dup3 = false;
        for (var _k = 0; _k < array_length(_ub); _k++) if (_ub[_k] == _b[_j]) _dup3 = true;
        if (!_dup3) array_push(_ub, _b[_j]);
    }
    var _uni = array_length(_ub);
    if (_uni == 0) return -1;
    return 1 - (_inter / _uni);
}

/// The forms a furnished room actually contains, as a flat list of names.
function hth_st_room_forms(_room) {
    var _out = [];
    var _lay = _room.layout;
    for (var _i = 0; _i < array_length(_lay.items); _i++) array_push(_out, _lay.items[_i].form);
    for (var _i = 0; _i < array_length(_lay.hung);  _i++) array_push(_out, _lay.hung[_i].form);
    for (var _i = 0; _i < array_length(_lay.rugs);  _i++) array_push(_out, _lay.rugs[_i].form);
    return _out;
}

/// A standard room at a standard rect, so every assertion measures the same thing.
function hth_st_room(_purpose, _occupant, _seed) {
    var _r = hth_room_of(_purpose, _occupant, _seed);
    return hth_room_furnish(_r, 0, 0, 640, 400);
}

/// ============================================================================================
/// THE RUN
/// ============================================================================================

function hth_selftest_run() {
    var _r = hth_st_new();
    var _diag = {};

    // -- STAGE 0: PROVE EVERY INSTRUMENT CAN GO RED --------------------------------------------
    global.hth_stage = 0;

    // A crescent: the lit region of a moon, concave about every point on it. This is the exact
    // shape that shipped wrong in this wing, and the fan test must refuse it.
    var _cres = [];
    for (var _i = 0; _i <= 12; _i++) {
        var _t = _i / 12;
        array_push(_cres, [cos(pi * _t), sin(pi * _t)]);
    }
    for (var _i = 12; _i >= 0; _i--) {
        var _t = _i / 12;
        array_push(_cres, [cos(pi * _t) * 0.45, sin(pi * _t)]);
    }
    hth_st_ok(_r, !hth_st_fan_ok(_cres),
              "STAGE 0: the fan test ACCEPTED a crescent - it cannot detect the failure it exists for");
    hth_st_ok(_r, hth_st_fan_ok([[0, 0], [1, 0], [1, 1], [0, 1]]),
              "STAGE 0: the fan test REJECTED a square - false red");
    hth_st_ok(_r, hth_st_jaccard(["a", "b"], ["a", "b"]) < HTH_ST_EPS,
              "STAGE 0: jaccard called two identical sets different");
    hth_st_ok(_r, hth_st_jaccard(["a"], ["b"]) > 0.99,
              "STAGE 0: jaccard called two disjoint sets the same");
    hth_st_ok(_r, hth_st_jaccard([], ["b"]) < 0,
              "STAGE 0: jaccard returned a number for an EMPTY set instead of refusing - "
              + "every distinctness assertion in this suite would then pass vacuously");

    // The layout checker must reject a layout it should reject. Two pieces on the same line at
    // the same x is the clearest case, and if this passes the checker is decoration.
    var _fake_room = hth_st_room("kitchen", "farmer", 4001);
    var _fake = {
        items: [hth_place_item("table", "free", "primary", 0.5, 0.15, 0.31),
                hth_place_item("bench", "free", "secondary", 0.52, 0.15, 0.19)],
        hung: [], rugs: [], has_window: false, window_x: 0.5, window_hw: 0.05,
        door: [0, 0.2], door_clear: [0, 0.26], run: [0.26, 0.97], attempt: 0,
    };
    hth_st_ok(_r, array_length(hth_layout_check(_fake, _fake_room)) > 0,
              "STAGE 0: hth_layout_check PASSED two pieces standing in the same place");

    // ⛔ THE FITTER IS NOW STRUCTURAL, SO IT NEEDS PROVING IN BOTH DIRECTIONS. It makes STAGE 3's
    // upper bound true by construction, and a mechanism that silently guarantees an assertion is
    // exactly the vacuous green this file exists to prevent. So: it must SHRINK something too
    // big, and it must LEAVE ALONE something that already fits. Either half missing and it is
    // not a test.
    var _big = [hth_rect_fill(-0.40, HTH_GROUND - 0.40, 0.40, HTH_GROUND, "m2")];
    var _fitk = hth_fit_factor(_big, { hw: 0.10, h: 0.10 });
    hth_st_ok(_r, _fitk < 0.30,
              "STAGE 0: the fitter left a form four times its declared box alone (k = "
              + string_format(_fitk, 1, 3) + ")");
    var _bb_fit = hth_render_bounds(hth_fit_to_extent(_big, { hw: 0.10, h: 0.10 }));
    hth_st_ok(_r, max(abs(_bb_fit[0]), abs(_bb_fit[2])) <= 0.1005,
              "STAGE 0: the fitter ran and the result still does not fit");
    hth_st_ok(_r, abs(_bb_fit[3] - HTH_GROUND) < 0.002,
              "STAGE 0: the fitter shrank a form OFF the ground line - it must scale about the "
              + "point where the piece meets the floor, or every piece in the room floats");
    var _small = [hth_rect_fill(-0.05, HTH_GROUND - 0.05, 0.05, HTH_GROUND, "m2")];
    hth_st_ok(_r, hth_fit_factor(_small, { hw: 0.10, h: 0.10 }) >= 0.999,
              "STAGE 0: the fitter shrank a form that already fitted");

    // -- STAGE 1: THE ENVIRONMENT ---------------------------------------------------------------
    global.hth_stage = 1;
    var _eps = math_get_epsilon();
    _diag.math_epsilon = string_format(_eps, 1, 12);

    // ⛔ WRITTEN AS TWO CLAUSES ON PURPOSE. The natural single clause
    // `math_get_epsilon() > 0 && ... < TOL` goes RED on its first clause: the difference between
    // the epsilon and zero IS the epsilon, GML therefore calls them equal, and equal is not
    // greater-than. Split, and phrased as !(_e > 0), it becomes a POSITIVE test that the runtime
    // still applies an epsilon - and goes red the day a release stops.
    hth_st_ok(_r, !(_eps > 0),
              "STAGE 1: math_get_epsilon() compared GREATER than zero - the runtime has stopped "
              + "applying a comparison epsilon and every tolerance in this package can be tightened");
    hth_st_ok(_r, _eps < 0.001,
              "STAGE 1: math_get_epsilon() is larger than 0.001, which is coarser than several "
              + "tolerances in this package: " + string(_eps));

    // The lamp globals are assigned by top-level script code at game start, before the first
    // room. If GML ever stops doing that, every relief role in the package resolves against
    // undefined and the whole product draws in the fallback ink colour.
    hth_st_ok(_r, !is_undefined(global.hth_lx) && !is_undefined(global.hth_ly),
              "STAGE 1: the lamp globals were not set at game start");
    hth_st_ok(_r, abs(global.hth_lx * global.hth_lx + global.hth_ly * global.hth_ly - 1) < 0.001,
              "STAGE 1: the default lamp direction is not a unit vector");

    // -- STAGE 2: THE CORPUS IS COMPLETE AND JOINED UP -------------------------------------------
    global.hth_stage = 2;
    var _forms = hth_form_names();
    var _clut  = hth_clutter_names();
    var _purps = hth_purpose_names();
    var _occs  = hth_occupant_names();
    var _mats  = hth_material_names();

    _diag.form_count     = array_length(_forms);
    _diag.clutter_count  = array_length(_clut);
    _diag.purpose_count  = array_length(_purps);
    _diag.occupant_count = array_length(_occs);
    _diag.material_count = array_length(_mats);
    _diag.entity_count   = array_length(_forms) + array_length(_clut);

    hth_st_ok(_r, array_length(_mats) == HTH_MAT_N,
              "STAGE 2: HTH_MAT_N says " + string(HTH_MAT_N) + " but the name list has "
              + string(array_length(_mats)));

    // ⛔ THE HEADLINE NUMBER IS COUNTED HERE AND ONLY THEN WRITTEN ON THE LISTING. A combinatorial
    // figure - twelve purposes times thirty forms - is not a measured number of distinguishable
    // things, and this wing has a standing rule against quoting one.
    hth_st_ok(_r, _diag.entity_count >= 40,
              "STAGE 2: the corpus holds only " + string(_diag.entity_count)
              + " distinct generated entities; the product's own floor is 40");

    var _test_room = hth_st_room("kitchen", "farmer", 991);
    for (var _i = 0; _i < array_length(_forms); _i++) {
        var _p = hth_form_build(_forms[_i], _test_room, 7);
        hth_st_ok(_r, array_length(_p) > 0,
                  "STAGE 2: form " + _forms[_i] + " built an EMPTY part list");
    }
    for (var _i = 0; _i < array_length(_clut); _i++) {
        var _p2 = hth_clutter_build(_clut[_i], _test_room, 7);
        hth_st_ok(_r, array_length(_p2) > 0,
                  "STAGE 2: clutter " + _clut[_i] + " built an EMPTY part list");
    }

    // Every slot in every purpose names a form that exists.
    for (var _i = 0; _i < array_length(_purps); _i++) {
        var _sl = hth_purpose_slots(_purps[_i]);
        for (var _s = 0; _s < array_length(_sl); _s++) {
            var _known = false;
            for (var _k = 0; _k < array_length(_forms); _k++) {
                if (_forms[_k] == _sl[_s].form) _known = true;
            }
            hth_st_ok(_r, _known, "STAGE 2: purpose " + _purps[_i] + " names unknown form "
                                  + _sl[_s].form);
        }
    }

    // ⛔ BOTH DIRECTIONS. An object nobody owns and an object with no builder are different bugs
    // and a one-way subset check finds only one of them.
    var _owned = [];
    for (var _i = 0; _i < array_length(_occs); _i++) {
        var _v = hth_occupant_objects(_occs[_i]);
        for (var _k = 0; _k < array_length(_v); _k++) array_push(_owned, _v[_k]);
    }
    hth_st_ok(_r, array_length(_owned) > 0,
              "STAGE 2: the union of every occupant's objects is EMPTY - the checks below would "
              + "pass over nothing");
    for (var _i = 0; _i < array_length(_owned); _i++) {
        var _has = false;
        for (var _k = 0; _k < array_length(_clut); _k++) if (_clut[_k] == _owned[_i]) _has = true;
        hth_st_ok(_r, _has, "STAGE 2: an occupant owns " + _owned[_i] + ", which has no builder");
    }
    for (var _i = 0; _i < array_length(_clut); _i++) {
        var _has2 = false;
        for (var _k = 0; _k < array_length(_owned); _k++) if (_owned[_k] == _clut[_i]) _has2 = true;
        hth_st_ok(_r, _has2, "STAGE 2: clutter form " + _clut[_i] + " belongs to no occupant and "
                             + "can therefore never appear in a room");
    }

    // -- STAGE 3: DECLARED EXTENT AGAINST MEASURED BOUNDS ----------------------------------------
    global.hth_stage = 3;
    // ⛔ A DECLARED EXTENT IS A CLAIM AND THE VERTICES ARE EVIDENCE. The layout solver reads the
    // declaration to decide whether two pieces collide, so a form WIDER than it says it is
    // overlaps its neighbour with every other check still green.
    //
    // ⚠️ THE UPPER BOUND IS NOW STRUCTURAL AND IS ASSERTED ANYWAY, WHICH IS NOT THE SAME AS
    // TESTING IT. hth_form_build fits every form into its declared box, so "measured <= declared"
    // holds by construction; it is checked below only because a fitter that stopped working
    // should not be silent, and STAGE 0 is what actually proves the fitter can fail. The two
    // assertions with real teeth here are the CORRECTION FACTOR - how much the fitter had to do,
    // which catches a builder that is simply wrong about its size rather than merely oversailing
    // - and the LOWER bound, which catches a form that under-fills the space the room gave it.
    var _worst_fit = 1, _worst_fit_name = "-";
    for (var _i = 0; _i < array_length(_forms); _i++) {
        var _f = _forms[_i];
        var _e = hth_form_extent(_f);
        var _k = hth_fit_factor(hth_form_build_raw(_f, _test_room, 7), _e);
        if (_k < _worst_fit) { _worst_fit = _k; _worst_fit_name = _f; }
        hth_st_ok(_r, _k > HTH_ST_FIT_FLOOR,
                  "STAGE 3: " + _f + " had to be shrunk to " + string_format(_k, 1, 3)
                  + " to fit its own declared box - that is a builder that is wrong about its "
                  + "size, not a cornice that oversails");

        var _bb = hth_render_bounds(hth_form_build(_f, _test_room, 7));
        var _mhw = max(abs(_bb[0]), abs(_bb[2]));
        var _mh  = HTH_GROUND - _bb[1];
        hth_st_ok(_r, _mhw <= _e.hw * 1.01,
                  "STAGE 3: " + _f + " measures " + string_format(_mhw, 1, 4)
                  + " half-wide after fitting but declares " + string(_e.hw)
                  + " - the fitter is not doing its job");
        hth_st_ok(_r, _mhw >= _e.hw * 0.70,
                  "STAGE 3: " + _f + " declares " + string(_e.hw) + " half-width and only fills "
                  + string_format(_mhw, 1, 4) + " - the room will furnish half empty");
        hth_st_ok(_r, _mh <= _e.h * 1.01,
                  "STAGE 3: " + _f + " measures " + string_format(_mh, 1, 4)
                  + " tall after fitting but declares " + string(_e.h));
        hth_st_ok(_r, _bb[3] <= HTH_GROUND + 0.06,
                  "STAGE 3: " + _f + " reaches below the floor line to "
                  + string_format(_bb[3], 1, 4));
    }
    _diag.worst_fit_factor = string_format(_worst_fit, 1, 4);
    _diag.worst_fit_form   = _worst_fit_name;

    var _worst_cfit = 1, _worst_cfit_name = "-";
    for (var _i = 0; _i < array_length(_clut); _i++) {
        var _cf = _clut[_i];
        var _ce = hth_clutter_extent(_cf);
        var _ck = hth_fit_factor(hth_clutter_build_raw(_cf, _test_room, 7), _ce);
        if (_ck < _worst_cfit) { _worst_cfit = _ck; _worst_cfit_name = _cf; }
        hth_st_ok(_r, _ck > HTH_ST_FIT_FLOOR,
                  "STAGE 3: clutter " + _cf + " had to be shrunk to " + string_format(_ck, 1, 3)
                  + " to fit its own declared box");
        var _cb = hth_render_bounds(hth_clutter_build(_cf, _test_room, 7));
        var _cmhw = max(abs(_cb[0]), abs(_cb[2]));
        hth_st_ok(_r, _cmhw <= _ce.hw * 1.01,
                  "STAGE 3: clutter " + _cf + " measures " + string_format(_cmhw, 1, 4)
                  + " half-wide after fitting but declares " + string(_ce.hw));
        hth_st_ok(_r, (HTH_GROUND - _cb[1]) <= _ce.h * 1.01,
                  "STAGE 3: clutter " + _cf + " measures "
                  + string_format(HTH_GROUND - _cb[1], 1, 4) + " tall after fitting but declares "
                  + string(_ce.h));
    }
    _diag.worst_clutter_fit = string_format(_worst_cfit, 1, 4);
    _diag.worst_clutter_form = _worst_cfit_name;

    // -- STAGE 4: EVERY FILL IS STAR-SHAPED, AND NOTHING LEAVES THE UNIT BOX ---------------------
    global.hth_stage = 4;
    var _fills = 0;
    for (var _i = 0; _i < array_length(_forms); _i++) {
        var _parts = hth_form_build(_forms[_i], _test_room, 7);
        for (var _p = 0; _p < array_length(_parts); _p++) {
            var _pt = _parts[_p];
            if (_pt.kind != HTH_FILL) continue;
            _fills++;
            if (!hth_st_fan_ok(_pt.pts)) {
                hth_st_ok(_r, false, "STAGE 4: " + _forms[_i] + " emits a fill that is NOT "
                                     + "star-shaped about its first point - the triangle fan will "
                                     + "span the concavity silently");
            } else { _r.pass++; }
        }
        var _bb2 = hth_render_bounds(_parts);
        hth_st_ok(_r, _bb2[0] > -HTH_ST_BOX && _bb2[2] < HTH_ST_BOX
                   && _bb2[1] > -HTH_ST_BOX && _bb2[3] < HTH_ST_BOX,
                  "STAGE 4: " + _forms[_i] + " reaches outside the unit box");
    }
    for (var _i = 0; _i < array_length(_clut); _i++) {
        var _cp = hth_clutter_build(_clut[_i], _test_room, 7);
        for (var _p = 0; _p < array_length(_cp); _p++) {
            if (_cp[_p].kind != HTH_FILL) continue;
            _fills++;
            if (!hth_st_fan_ok(_cp[_p].pts)) {
                hth_st_ok(_r, false, "STAGE 4: clutter " + _clut[_i]
                                     + " emits a fill that is NOT star-shaped");
            } else { _r.pass++; }
        }
    }
    _diag.fills_checked = _fills;
    hth_st_ok(_r, _fills > 400,
              "STAGE 4: only " + string(_fills) + " fills were checked - the corpus should emit "
              + "thousands, so this stage has run over almost nothing");

    // -- STAGE 5: EVERY ROLE RESOLVES IN THE PALETTE ---------------------------------------------
    global.hth_stage = 5;
    // ⚠️ hth_render_colour falls back to _pal.line for an unknown role, so a typo does not crash -
    // it draws a whole blanket in the ink colour and looks like a shading bug. This is the only
    // way to catch it.
    var _rooms3 = [hth_st_room("kitchen", "healer", 12),
                   hth_st_room("study", "scholar", 34),
                   hth_st_room("cell", "miser", 56)];
    for (var _q = 0; _q < 3; _q++) {
        var _pal = hth_palette_build(_rooms3[_q]);
        var _names = hth_palette_roles(_pal);
        hth_st_ok(_r, array_length(_names) > 40,
                  "STAGE 5: the palette holds only " + string(array_length(_names))
                  + " roles - the subset check below would pass over almost nothing");
        var _used = hth_roles_used(hth_room_parts(_rooms3[_q], _rooms3[_q].layout.geom));
        hth_st_ok(_r, array_length(_used) > 8,
                  "STAGE 5: room " + string(_q) + " emitted only " + string(array_length(_used))
                  + " distinct roles");
        for (var _u = 0; _u < array_length(_used); _u++) {
            hth_st_ok(_r, variable_struct_exists(_pal, _used[_u]),
                      "STAGE 5: role " + _used[_u] + " is emitted but is not in the palette - it "
                      + "will draw in the fallback ink colour");
        }
    }

    // -- STAGE 6: THE LAYOUT SWEEP -----------------------------------------------------------------
    global.hth_stage = 6;
    // ⛔ THE WHOLE CORPUS, NOT A SAMPLE. Twelve purposes crossed with ten occupants at three seeds
    // is 360 rooms, and the failures this stage exists for are exactly the ones that hide in one
    // combination. A degenerate case hides behind a healthy average.
    var _rooms_checked = 0, _defects = 0, _first_defect = "-";
    var _min_ratio = 999, _min_ratio_where = "-";
    var _ratios = [];
    for (var _p = 0; _p < array_length(_purps); _p++) {
        for (var _o = 0; _o < array_length(_occs); _o++) {
            for (var _s = 0; _s < 3; _s++) {
                var _rm = hth_st_room(_purps[_p], _occs[_o], 100 + _s * 977);
                _rooms_checked++;
                var _bad = _rm.layout.defects;
                if (array_length(_bad) > 0) {
                    _defects += array_length(_bad);
                    if (_first_defect == "-") {
                        _first_defect = _purps[_p] + "/" + _occs[_o] + ": " + _bad[0];
                    }
                }
                var _v = hth_layout_gap_ratio(_rm.layout, "free");
                if (_v >= 0) {
                    array_push(_ratios, _v);
                    if (_v < _min_ratio) {
                        _min_ratio = _v;
                        _min_ratio_where = _purps[_p] + "/" + _occs[_o];
                    }
                }
            }
        }
    }
    var _nrat = array_length(_ratios);
    array_sort(_ratios, true);
    var _med = (_nrat > 0) ? _ratios[floor(_nrat / 2)] : -1;

    _diag.rooms_checked    = _rooms_checked;
    _diag.layout_defects   = _defects;
    _diag.first_defect     = _first_defect;
    _diag.min_gap_ratio    = string_format(_min_ratio, 1, 4);
    _diag.min_gap_ratio_at = _min_ratio_where;
    _diag.med_gap_ratio    = string_format(_med, 1, 4);
    _diag.ratio_sample     = _nrat;

    hth_st_ok(_r, _rooms_checked == array_length(_purps) * array_length(_occs) * 3,
              "STAGE 6: the sweep visited " + string(_rooms_checked) + " rooms, not the whole corpus");
    hth_st_ok(_r, _defects == 0,
              "STAGE 6: " + string(_defects) + " layout defects across the corpus. First: "
              + _first_defect);

    // ⛔ TWO ASSERTIONS, BECAUSE ONE OF THEM ALONE IS ALWAYS SATISFIABLE THE WRONG WAY. The
    // minimum catches a room spaced like a ruler, which is the loudest possible tell that
    // furniture was generated rather than placed - and it passes every geometric check ever
    // written, because a ruler is legal. The median catches the case a minimum cannot see: every
    // room barely clearing the floor, so the corpus is technically uneven and visibly regular.
    hth_st_ok(_r, _nrat > 60,
              "STAGE 6: gap spacing was measurable on only " + string(_nrat)
              + " rooms - the floors below would be asserted over almost nothing");
    hth_st_ok(_r, _min_ratio > HTH_ST_RATIO_MIN,
              "STAGE 6: the worst room (" + _min_ratio_where + ") spaces its furniture at ratio "
              + string_format(_min_ratio, 1, 4) + ", below " + string(HTH_ST_RATIO_MIN)
              + " - that room is a ruler");
    hth_st_ok(_r, _med > HTH_ST_RATIO_MED,
              "STAGE 6: the MEDIAN room spaces at ratio " + string_format(_med, 1, 4)
              + ", below " + string(HTH_ST_RATIO_MED)
              + " - the typical room is too regular to read as furnished");

    // -- STAGE 7: PURPOSE AND OCCUPANT ARE BOTH REAL AXES -------------------------------------------
    global.hth_stage = 7;
    // ⛔ THIS IS THE PRODUCT'S HEADLINE CLAIM, ASSERTED IN BOTH DIRECTIONS. If two purposes
    // furnish alike the product is an interior generator like any other; if two occupants clutter
    // alike it is the same room with a different nameplate, which is precisely what the incumbent
    // art packs already are.
    var _min_pd = 9, _min_pd_where = "-";
    for (var _a = 0; _a < array_length(_purps); _a++) {
        for (var _b = _a + 1; _b < array_length(_purps); _b++) {
            var _ra = hth_st_room(_purps[_a], "farmer", 555);
            var _rb = hth_st_room(_purps[_b], "farmer", 555);
            var _d = hth_st_jaccard(hth_st_room_forms(_ra), hth_st_room_forms(_rb));
            if (_d < _min_pd) { _min_pd = _d; _min_pd_where = _purps[_a] + " vs " + _purps[_b]; }
        }
    }
    _diag.min_purpose_distance = string_format(_min_pd, 1, 4);
    _diag.min_purpose_pair     = _min_pd_where;
    hth_st_ok(_r, _min_pd > HTH_ST_ROOM_FLOOR,
              "STAGE 7: the closest pair of purposes (" + _min_pd_where + ") differ by only "
              + string_format(_min_pd, 1, 4) + " - they furnish the same room");

    var _min_od = 9, _min_od_where = "-";
    for (var _a = 0; _a < array_length(_occs); _a++) {
        for (var _b = _a + 1; _b < array_length(_occs); _b++) {
            var _oa = hth_occupant_objects(_occs[_a]);
            var _ob = hth_occupant_objects(_occs[_b]);
            var _d2 = hth_st_jaccard(_oa, _ob);
            if (_d2 < _min_od) { _min_od = _d2; _min_od_where = _occs[_a] + " vs " + _occs[_b]; }
        }
    }
    _diag.min_occupant_distance = string_format(_min_od, 1, 4);
    _diag.min_occupant_pair     = _min_od_where;
    hth_st_ok(_r, _min_od > 0.45,
              "STAGE 7: the closest pair of occupants (" + _min_od_where + ") share too much: "
              + string_format(_min_od, 1, 4));

    // And the same PURPOSE with two different occupants must still differ, which is the claim a
    // buyer is actually paying for.
    var _k1 = hth_st_room("kitchen", "miser", 808);
    var _k2 = hth_st_room("kitchen", "healer", 808);
    var _c1 = hth_clutter_solve(_k1, _k1.layout.geom);
    var _c2 = hth_clutter_solve(_k2, _k2.layout.geom);
    var _n1 = [], _n2 = [];
    for (var _i = 0; _i < array_length(_c1); _i++) array_push(_n1, _c1[_i].form);
    for (var _i = 0; _i < array_length(_c2); _i++) array_push(_n2, _c2[_i].form);
    var _kd = hth_st_jaccard(_n1, _n2);
    _diag.kitchen_occupant_distance = string_format(_kd, 1, 4);

    // ⛔ THIS ASSERTION WAS REWRITTEN AFTER IT WENT RED, AND THE REASON MATTERS. It read `> 0.90`
    // and measured exactly 0.9000 the moment the clutter count was raised: at four objects per
    // room neither household reached the fourth entry of its vocabulary, and at eight or nine
    // both did - where a miser and a healer each own a CANDLE. The red was real and the check was
    // wrong, because a shared candle does not make two rooms the same room. Lowering the number
    // to make it pass would have been tuning away a check; what it needed was to test the claim
    // it was named for.
    //
    // The claim is that the OCCUPANT is what the room is full of, so it is split in two: the
    // SIGNATURE objects - the two the solver never drops - must be disjoint for every pair of
    // occupants in the corpus, and the whole set must still differ by a real margin. The first
    // half is now asserted over all 45 pairs rather than one, so it is a strictly stronger test
    // than the one it replaced.
    hth_st_ok(_r, _kd > 0.70,
              "STAGE 7: a miser's kitchen and a healer's kitchen hold nearly the same objects ("
              + string_format(_kd, 1, 4) + ") - the product's core idea is not working");

    var _sig_bad = 0, _sig_where = "-";
    for (var _a = 0; _a < array_length(_occs); _a++) {
        for (var _b = _a + 1; _b < array_length(_occs); _b++) {
            var _sa = hth_occupant_objects(_occs[_a]);
            var _sb = hth_occupant_objects(_occs[_b]);
            for (var _i = 0; _i < 2; _i++) {
                for (var _j = 0; _j < 2; _j++) {
                    if (_sa[_i] != _sb[_j]) continue;
                    _sig_bad++;
                    if (_sig_where == "-") {
                        _sig_where = _occs[_a] + " and " + _occs[_b] + " both signed by " + _sa[_i];
                    }
                }
            }
        }
    }
    _diag.signature_collisions = _sig_bad;
    hth_st_ok(_r, _sig_bad == 0,
              "STAGE 7: " + string(_sig_bad) + " occupant pairs share a SIGNATURE object - "
              + _sig_where + ". Incidental objects may overlap; the two the solver never drops "
              + "may not, because they are the whole occupant axis");

    // The signature objects are never dropped, however tidy and however poor.
    var _spare = hth_room_of("cell", "miser", 42);
    _spare.tidiness = 1.0; _spare.prosperity = 0.02; _spare.density = 0.0;
    hth_room_derive(_spare);
    hth_room_furnish(_spare, 0, 0, 640, 400);
    var _sc = hth_clutter_solve(_spare, _spare.layout.geom);
    var _sig = hth_occupant_objects("miser");
    var _found0 = false, _found1 = false;
    for (var _i = 0; _i < array_length(_sc); _i++) {
        if (_sc[_i].form == _sig[0]) _found0 = true;
        if (_sc[_i].form == _sig[1]) _found1 = true;
    }
    hth_st_ok(_r, _found0 && _found1,
              "STAGE 7: the two signature objects were dropped from a spotless, destitute room - "
              + "tidiness must control incidental clutter, never whether a miser owns a strongbox");

    // -- STAGE 8: A ROOM STAYS INSIDE THE RECT IT IS GIVEN ------------------------------------------
    global.hth_stage = 8;
    // ⛔ A PUBLIC DRAW CALL THAT TAKES A RECT AND DRAWS OUTSIDE IT PAINTS OVER WHATEVER SITS
    // BESIDE IT IN THE BUYER'S GAME. This wing shipped exactly that once: a rainbow that bled out
    // of the sky rect it was handed and into the neighbouring cell.
    var _rects = [[0, 0, 640, 400], [100, 50, 300, 300], [0, 0, 900, 240]];
    for (var _q = 0; _q < array_length(_rects); _q++) {
        var _rc = _rects[_q];
        var _rr = hth_room_of("kitchen", "smith", 700 + _q);
        // ⛔ THE FIXTURE'S STATE IS SET, NOT HOPED FOR. The light-containment assertions below
        // only exist when the room HAS a fire, and seed 700 happens to roll a warmth under the
        // threshold - so on its first run the vacuity guard at the end of this stage went red and
        // caught three assertions testing nothing at all.
        _rr.warmth = 0.92;
        hth_room_derive(_rr);
        hth_room_furnish(_rr, _rc[0], _rc[1], _rc[2], _rc[3]);
        var _bb3 = hth_render_bounds(hth_room_parts(_rr, _rr.layout.geom));
        // A generous margin: a contact shadow and a mantel oversail are meant to reach a little.
        var _mx = _rc[2] * 0.06, _my = _rc[3] * 0.06;
        hth_st_ok(_r, _bb3[0] > _rc[0] - _mx && _bb3[2] < _rc[0] + _rc[2] + _mx,
                  "STAGE 8: a room drawn in rect " + string(_q) + " reaches horizontally from "
                  + string_format(_bb3[0], 1, 1) + " to " + string_format(_bb3[2], 1, 1));
        hth_st_ok(_r, _bb3[1] > _rc[1] - _my && _bb3[3] < _rc[1] + _rc[3] + _my,
                  "STAGE 8: a room drawn in rect " + string(_q) + " reaches vertically from "
                  + string_format(_bb3[1], 1, 1) + " to " + string_format(_bb3[3], 1, 1));

        // ⛔ AND THE LIGHT WASHES, WHICH THE CHECK ABOVE CANNOT REACH. They are direct draw calls
        // and emit no parts, so walking hth_room_parts was blind to them - and the firelight glow
        // was in fact drawing hundreds of pixels outside the rect on a wide room, found by opening
        // a sheet. Testing the CONTRACT when the picture is unreachable is the same move this
        // package makes for the triangle fan's star-shaped precondition.
        var _lb = hth_light_boxes(_rr.layout.geom, _rr);
        if (!is_undefined(_lb)) {
            hth_st_ok(_r, _lb.glow[0] >= _rc[0] - 0.5 && _lb.glow[1] >= _rc[1] - 0.5
                       && _lb.glow[2] <= _rc[0] + _rc[2] + 0.5
                       && _lb.glow[3] <= _rc[1] + _rc[3] + 0.5,
                      "STAGE 8: the firelight GLOW draws outside rect " + string(_q)
                      + " - it will paint over whatever sits beside the room");
            hth_st_ok(_r, _lb.pool[0] >= _rc[0] - 0.5 && _lb.pool[1] >= _rc[1] - 0.5
                       && _lb.pool[2] <= _rc[0] + _rc[2] + 0.5
                       && _lb.pool[3] <= _rc[1] + _rc[3] + 0.5,
                      "STAGE 8: the firelight POOL draws outside rect " + string(_q));
        }
    }
    // ⚠️ A ROOM WITH NO FIRE RETURNS NO BOXES, AND THEN THE BLOCK ABOVE ASSERTS NOTHING. The
    // three rects all use a lit smith's kitchen, but that is an accident of the fixture rather
    // than a guarantee, so it is checked: without this the whole containment test could pass
    // vacuously the day someone changes the fixture's warmth.
    var _lit = hth_room_of("kitchen", "smith", 700);
    _lit.warmth = 0.92;
    hth_room_derive(_lit);
    hth_room_furnish(_lit, 0, 0, 640, 400);
    hth_st_ok(_r, !is_undefined(hth_light_boxes(_lit.layout.geom, _lit)),
              "STAGE 8: the containment fixture has no fire, so the two assertions above ran "
              + "over nothing");

    // -- STAGE 9: DETERMINISM ------------------------------------------------------------------------
    global.hth_stage = 9;
    // Nothing in this package calls random() and nothing may. A room that re-jitters every frame
    // is the one bug a buyer notices immediately and cannot work around.
    var _d1 = hth_st_room("taproom", "merchant", 31337);
    var _d2 = hth_st_room("taproom", "merchant", 31337);
    var _p1 = hth_room_parts(_d1, _d1.layout.geom);
    var _p2 = hth_room_parts(_d2, _d2.layout.geom);
    hth_st_ok(_r, array_length(_p1) == array_length(_p2),
              "STAGE 9: the same seed produced " + string(array_length(_p1)) + " and "
              + string(array_length(_p2)) + " parts");
    var _drift = 0;
    var _bb4 = hth_render_bounds(_p1), _bb5 = hth_render_bounds(_p2);
    for (var _i = 0; _i < 4; _i++) _drift += abs(_bb4[_i] - _bb5[_i]);
    hth_st_ok(_r, _drift < 0.001,
              "STAGE 9: the same seed drew to different bounds, drift " + string(_drift));
    hth_st_ok(_r, array_length(_p1) > 200,
              "STAGE 9: a furnished taproom is only " + string(array_length(_p1))
              + " parts - the comparison above ran over almost nothing");

    // -- STAGE 10: DERIVE IS IDEMPOTENT ---------------------------------------------------------------
    global.hth_stage = 10;
    // ⚠️ A previous product in this wing accumulated a hue shift on every derive, because one
    // line read what the line above it had just written. Deriving a derived room must be a no-op.
    var _id = hth_room_create(2468);
    var _h1 = _id.hue_shift, _w1 = _id.wood_mat, _dy = _id.dye_hue;
    hth_room_derive(_id); hth_room_derive(_id);
    hth_st_ok(_r, _id.hue_shift == _h1 && _id.wood_mat == _w1 && _id.dye_hue == _dy,
              "STAGE 10: hth_room_derive is not idempotent - a derived field drifted on re-derive");

    // -- write the result ------------------------------------------------------------------------------
    global.hth_stage = 11;
    hth_st_write(_r, _diag);
    return _r;
}

/// Write the result file. ⛔ file_text_open_write into %LOCALAPPDATA%\Hearth\ is the ONE route
/// that works: show_debug_message is dead in a release build (the -debugoutput file holds only
/// engine boot lines) and game_end(n) does not propagate its argument (a run that ended 152000
/// exited 0). Both measured in this wing.
function hth_st_write(_r, _diag) {
    var _f = file_text_open_write("hth_selftest.json");
    file_text_write_string(_f, "{\"pass\":" + string(_r.pass)
                             + ",\"fail\":" + string(_r.fail)
                             + ",\"version\":\"" + HTH_VERSION + "\"");
    var _keys = variable_struct_get_names(_diag);
    for (var _i = 0; _i < array_length(_keys); _i++) {
        var _v = variable_struct_get(_diag, _keys[_i]);
        file_text_write_string(_f, ",\"" + _keys[_i] + "\":\"" + string(_v) + "\"");
    }
    file_text_write_string(_f, ",\"failures\":[");
    for (var _i = 0; _i < array_length(_r.failures); _i++) {
        if (_i > 0) file_text_write_string(_f, ",");
        file_text_write_string(_f, "\"" + string_replace_all(string(_r.failures[_i]), "\"", "'")
                                        + "\"");
    }
    file_text_write_string(_f, "]}");
    file_text_close(_f);
}
