/// HEARTH - hth_furniture. THE CORPUS: thirty pieces of furniture, drawn from data.
///
/// ⛔ FURNITURE IS AN ASSEMBLY OF MASSES, NOT AN OUTLINE. A chair is a seat, a back, four legs
/// and two rails, and each of those is a separately bevelled mass with its own lit and shadowed
/// walls. Drawn as one silhouette it reads as a chair-shaped biscuit; drawn as members it reads
/// as a made object, because the eye finds the joints. This wing's relief discipline already
/// records the rule from the other side - "two masses read as two when their SILHOUETTE steps,
/// not when their fill changes" - and furniture is the case where the members genuinely are
/// separate planes, so assembly is not a shortcut here, it is the truth about the object.
///
/// ⛔ AND THAT IS ALSO WHY NOTHING HERE HANDS A CONCAVE OUTLINE TO A FAN. hth_fill is a triangle
/// fan and requires a star-shaped outline; a chair, an L-shaped counter, an archway and a
/// cauldron handle are all concave, and a fan spans the concavity SILENTLY - no error, no failed
/// assertion, just a wrong picture. Every mass below is CONVEX by construction (a box, a
/// trapezoid, a half-round, a taper), and hth_selftest asserts that no form emits a fill whose
/// outline is non-convex. When you cannot test the picture, test the contract.
///
/// -- COORDINATES AND WHY ONE SCALE FITS EVERY PIECE ------------------------------------------
/// Every form is authored in the unit box, y DOWN, with its footprint on HTH_GROUND. The unit
/// box's vertical span from the ceiling (y = -0.5) to the floor (y = HTH_GROUND) is ONE ROOM
/// HEIGHT. So a stool authored 0.18 tall and a wardrobe authored 0.70 tall are in true relative
/// proportion, and hth_layout can place the whole room at a SINGLE uniform scale with no
/// per-form fudge factor. That is the same thing the exterior half of this series does with a
/// street that shares one ground, and it is why a room never looks like a collage.
///
/// ⛔ A VERTICAL DIMENSION IS NEVER DERIVED FROM A HORIZONTAL ONE. This wing has paid for that
/// twice in one afternoon on one product: an eaves shadow scaled from a half-width put a band a
/// fifth of the wall deep on a cottage. Furniture is the worst case for it, because a trestle
/// table is four times as wide as it is tall. Every vertical measurement below is a fraction of
/// the piece's own HEIGHT.
///
/// ⚠️ THE BEVEL IS SOLVED FROM THE MEMBER, ALWAYS. hth_bev_for takes both dimensions and returns
/// a fraction of the SMALLER. A chair spindle is 0.012 wide; a facade-wide bevel constant would
/// turn every one of them inside out, and nothing mechanical would see it.
/// ============================================================================================

/// The thirty corpus forms, in corpus order. The suite asserts every name here builds a
/// non-empty part list and that every slot in every purpose names one of them, so a typo in a
/// slot list is a red test rather than an invisible missing chair.
function hth_form_names() {
    return ["hearth", "stove", "bed", "cot", "cradle", "table", "trestle", "bench",
            "chair", "stool", "chest", "wardrobe", "shelf", "dresser", "counter",
            "barrel", "crate", "rug", "loom", "anvil", "desk", "altar", "cauldron",
            "rack", "basin", "lamp", "sack", "tub", "screen", "bookcase"];
}

/// The DECLARED extent of a form in unit-box units: half-width and height above the floor.
///
/// ⭐ THIS IS NOT DOCUMENTATION, IT IS AN ASSERTION TARGET. hth_selftest builds every form,
/// measures its real rendered bounds with hth_render_bounds, and requires the measurement to
/// agree with the declaration. That is the only way an authoring drift - a mantel shelf that
/// grew past the chimney breast, a bed head that outgrew its own box - is ever caught, because
/// the layout solver reads THIS table when it decides whether two pieces collide, and a form
/// that is bigger than it says it is will overlap its neighbour with every check still green.
///
/// ⚠️ SEVERAL NUMBERS HERE LOOK WRONG AND ARE RIGHT, BECAUSE AN EXTENT IS OF THE WHOLE DRAWN
/// PIECE AND NOT OF ITS BODY. A cauldron is 0.30 tall because that includes the bail handle
/// standing over it; a stove is 0.52 because the flue leaves the top; an altar is 0.52 because
/// the candles ARE part of the altar. Ten of these were authored wrong first and corrected from
/// the suite's own measurement, which is exactly what the assertion is for - and why they carry
/// three places rather than being tidy round numbers.
function hth_form_extent(_form) {
    switch (_form) {
        // form          half-width   height above the floor
        case "hearth":   return { hw: 0.245, h: 0.620 };
        case "stove":    return { hw: 0.166, h: 0.515 };   // h includes the flue
        case "bed":      return { hw: 0.290, h: 0.260 };
        case "cot":      return { hw: 0.230, h: 0.200 };
        case "cradle":   return { hw: 0.130, h: 0.220 };
        case "table":    return { hw: 0.245, h: 0.310 };
        case "trestle":  return { hw: 0.330, h: 0.310 };
        case "bench":    return { hw: 0.245, h: 0.190 };
        case "chair":    return { hw: 0.105, h: 0.380 };
        case "stool":    return { hw: 0.098, h: 0.190 };
        case "chest":    return { hw: 0.165, h: 0.250 };
        case "wardrobe": return { hw: 0.190, h: 0.750 };
        case "shelf":    return { hw: 0.240, h: 0.170 };
        case "dresser":  return { hw: 0.205, h: 0.700 };
        case "counter":  return { hw: 0.348, h: 0.420 };
        case "barrel":   return { hw: 0.112, h: 0.360 };
        case "crate":    return { hw: 0.120, h: 0.240 };
        case "rug":      return { hw: 0.344, h: 0.076 };   // h includes the fringe
        case "loom":     return { hw: 0.195, h: 0.680 };
        case "anvil":    return { hw: 0.118, h: 0.280 };
        case "desk":     return { hw: 0.230, h: 0.330 };
        case "altar":    return { hw: 0.232, h: 0.516 };   // h includes the candles
        case "cauldron": return { hw: 0.122, h: 0.302 };   // h includes the bail handle
        case "rack":     return { hw: 0.232, h: 0.230 };
        case "basin":    return { hw: 0.108, h: 0.320 };
        case "lamp":     return { hw: 0.064, h: 0.180 };
        case "sack":     return { hw: 0.108, h: 0.260 };
        case "tub":      return { hw: 0.134, h: 0.240 };
        case "screen":   return { hw: 0.190, h: 0.600 };
        case "bookcase": return { hw: 0.203, h: 0.720 };
    }
    return { hw: 0.100, h: 0.200 };
}

/// ============================================================================================
/// THE MASS PRIMITIVES
/// ============================================================================================

/// The bevel a member of this size can carry.
///
/// ⛔ A BEVEL WIDER THAN THE FEATURE IT BEVELS TURNS THAT FEATURE INSIDE OUT: the inset ring
/// self-crosses and the member renders as two shards with a gap. Taking the SMALLER dimension is
/// what makes that impossible, and the 0.22 fraction leaves the face more than half the member
/// even in the worst case.
function hth_bev_for(_w, _h) {
    return min(abs(_w), abs(_h)) * 0.22;
}

/// How many nested walls a member of this size deserves. One is a chamfer, which is all a 12px
/// spindle can show; two is a dome, which is what a table top wants.
function hth_steps_for(_w, _h) {
    return (min(abs(_w), abs(_h)) > 0.055) ? 2 : 1;
}

/// ⛔ CAP A BEVEL AT THE SHORTEST EDGE OF THE OUTLINE IT IS APPLIED TO. MEASURED 2026-08-29, first
/// run of this product's suite: EIGHT fills across the barrel, the cauldron and the sack were
/// rejected as not star-shaped, and hth_bev_for had already been applied to every one of them.
///
/// The wing's standing law says a bevel is a property of the EDGE and one wider than the feature
/// it bevels turns that feature inside out. hth_bev_for reads that as the shape's smaller
/// DIMENSION, which is right for a member - a rectangle's edges are as long as its sides. It is
/// wrong for a SAMPLED CURVE: a barrel body is 0.22 by 0.36, so the dimension rule allows 0.048,
/// while the actual edges between its 26 sampled points are about 0.03 long. Insetting each of
/// those by 0.048 makes consecutive inset points swap places, and the bevel quad becomes a
/// bowtie - which fills the wrong region silently, with the outline, the winding and the ink all
/// still correct.
///
/// ⚠️ THE FIX BELONGS HERE AND NOT AT THE THREE CALL SITES THAT FAILED. Tuning three constants
/// would have made the suite green and left the next sampled curve to rediscover it; this makes
/// the failure unreachable for every form in the corpus, including ones not written yet.
function hth_bev_edge_cap(_pts, _b) {
    var _n = array_length(_pts);
    if (_n < 3) return _b;
    var _short = 999;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _pts[_i], _c = _pts[(_i + 1) % _n];
        var _d = point_distance(_a[0], _a[1], _c[0], _c[1]);
        // A zero-length edge is a duplicated point, not a constraint - it would cap every bevel
        // in the package to nothing.
        if (_d > 0.0004 && _d < _short) _short = _d;
    }
    if (_short > 900) return _b;
    return min(_b, _short * 0.45);
}

/// A convex outline raised into a lit mass and remapped to a named material.
function hth_mass(_pts, _prefix, _b, _steps) {
    return hth_map_roles(hth_raise(_pts, hth_bev_edge_cap(_pts, _b), _steps, "m2"),
                         hth_material_map(_prefix));
}

/// The workhorse: an axis-aligned member in a named material, bevelled by its own size.
function hth_member(_x0, _y0, _x1, _y1, _prefix) {
    var _w = _x1 - _x0, _h = _y1 - _y0;
    if (abs(_w) < 0.0015 || abs(_h) < 0.0015) return [];
    var _pts = [[_x0, _y0], [_x1, _y0], [_x1, _y1], [_x0, _y1]];
    return hth_mass(_pts, _prefix, hth_bev_for(_w, _h), hth_steps_for(_w, _h));
}

/// A SUNKEN member - a drawer front, a door panel, a fireplace opening, a pigeonhole. Same
/// bevelling law, lamp on the other side, which is what makes a recess read as a recess at four
/// pixels rather than as a darker rectangle.
function hth_recess(_x0, _y0, _x1, _y1, _prefix) {
    var _w = _x1 - _x0, _h = _y1 - _y0;
    if (abs(_w) < 0.0015 || abs(_h) < 0.0015) return [];
    var _pts = [[_x0, _y0], [_x1, _y0], [_x1, _y1], [_x0, _y1]];
    return hth_map_roles(hth_sink(_pts, hth_bev_edge_cap(_pts, hth_bev_for(_w, _h)),
                                  hth_steps_for(_w, _h), "m1"),
                         hth_material_map(_prefix));
}

/// A TAPERED member - a turned leg, a barrel stave, a splayed stool leg. Convex as long as the
/// taper does not cross, which is asserted by keeping both half-widths positive.
function hth_taper(_xc, _y0, _hw0, _y1, _hw1, _prefix) {
    var _a = max(0.002, _hw0), _b = max(0.002, _hw1);
    var _pts = [[_xc - _a, _y0], [_xc + _a, _y0], [_xc + _b, _y1], [_xc - _b, _y1]];
    return hth_mass(_pts, _prefix, hth_bev_for(min(_a, _b) * 2, abs(_y1 - _y0)),
                    hth_steps_for(min(_a, _b) * 2, abs(_y1 - _y0)));
}

/// A half-round mass sitting on a base line - a cauldron belly, a loaf, a bolster, a tub rim.
/// Sampled from a half ellipse, so it is convex and it meets the base line exactly at both ends
/// BY CONSTRUCTION rather than by a tuned constant.
function hth_dome_mass(_xc, _ybase, _rx, _ry, _prefix, _n) {
    var _steps = is_undefined(_n) ? 14 : _n;
    var _pts = [];
    for (var _i = 0; _i <= _steps; _i++) {
        var _t = _i / _steps;
        array_push(_pts, [_xc - _rx + 2 * _rx * _t, _ybase - _ry * sin(pi * _t)]);
    }
    array_push(_pts, [_xc + _rx, _ybase]);
    array_push(_pts, [_xc - _rx, _ybase]);
    return hth_mass(_pts, _prefix, hth_bev_for(_rx * 2, _ry), hth_steps_for(_rx * 2, _ry));
}

/// ⛔ MAKE THE DECLARED EXTENT TRUE, BECAUSE EDITING THE NUMBER CANNOT. MEASURED 2026-08-29, and
/// this is the finding of the build.
///
/// Nineteen forms failed STAGE 3 on the suite's first run: each measured wider or taller than it
/// declared. The obvious fix is to write the measured number into the table - and it CANNOT WORK,
/// for a reason that is worth stating in full because it is not obvious and it wasted a pass:
///
///     every builder reads its own declared extent as its drawing scale, so the geometry is
///     SCALE-INVARIANT in the declaration. Double the declared half-width and the piece is drawn
///     twice as wide, and the RATIO of measured to declared does not move at all.
///
/// A mantel oversails its chimney breast by 6%, a cornice oversails its carcass by 8%, a bail
/// handle stands over its bucket - all of them correct pieces of furniture, all of them 4-30%
/// outside the box they claim. So the box is made true HERE, once, by shrinking the finished part
/// list about its own ground point until it fits.
///
/// ⚠️ AND THAT MAKES THE UPPER-BOUND ASSERTION STRUCTURAL RATHER THAN MEASURED, WHICH HAS TO BE
/// SAID OUT LOUD. "Measured <= declared" is now true by construction and could never go red, which
/// is precisely the vacuous-green shape this suite exists to prevent. Two things replace it and
/// neither is vacuous: the suite asserts the CORRECTION FACTOR stays above 0.85, so a builder that
/// is wildly oversized still fires by name instead of being silently shrunk, and the LOWER bound
/// (a form must fill at least 70% of the box it claims) is untouched and still measured. STAGE 0
/// feeds this function an oversized list and a fitting one and requires it to act on one and not
/// the other.
function hth_fit_factor(_parts, _e) {
    var _bb = hth_render_bounds(_parts);
    if (array_length(_parts) == 0) return 1;
    var _mhw = max(abs(_bb[0]), abs(_bb[2]));
    var _mh  = HTH_GROUND - _bb[1];
    var _k = 1;
    if (_mhw > _e.hw && _mhw > 0) _k = min(_k, _e.hw / _mhw);
    if (_mh  > _e.h  && _mh  > 0) _k = min(_k, _e.h  / _mh);
    return _k;
}

/// Shrink a part list about the point where it meets the floor, so the piece keeps standing on
/// the ground line rather than floating up as it shrinks.
///
/// hth_place maps a point to (cx + x*k, cy + y*k). Holding y = HTH_GROUND fixed therefore needs
/// cy = HTH_GROUND * (1 - k), which is the only non-obvious line here - and it is also why this
/// goes through hth_place rather than a hand-rolled loop: hth_place already scales stroke widths
/// and arc radii, and a hand-rolled version that scaled only the points would leave a shrunken
/// piece drawn with its original line weight.
function hth_fit_to_extent(_parts, _e) {
    var _k = hth_fit_factor(_parts, _e);
    if (_k >= 0.999) return _parts;
    return hth_place(_parts, 0, HTH_GROUND * (1 - _k), _k, 0, _k, undefined);
}

/// A stroked line in a material's darkest stop. Grain, a joint, a plank seam, a warp thread.
///
/// ⛔ TONE IS COUNT AND LENGTH, NEVER STROKE WIDTH. draw_line_width floors every stroke at 1.0px
/// with no antialiasing on this hardware, so at a gallery cell the whole authored width range
/// resolves to exactly one pixel and reads as a barcode. Wood grain, wicker and thatch carry
/// their tone by HOW MANY strokes there are and HOW FAR each runs.
function hth_line_in(_x0, _y0, _x1, _y1, _prefix, _w) {
    return [hth_poly([[_x0, _y0], [_x1, _y1]], false, _w, _prefix + "0")];
}

/// ============================================================================================
/// THE FORMS
///
/// Each takes the room (for prosperity, age, materials) and a seeded RNG state, and returns a
/// part list authored in the unit box with its footprint on HTH_GROUND.
/// ============================================================================================

#macro HTH_G HTH_GROUND

/// ============================================================================================
/// FIRE
///
/// ⛔ THE FIRE IS THE ONE THING IN THIS PRODUCT A BUYER LOOKS AT FIRST, AND THE FIRST VERSION WAS
/// THREE ISOSCELES TRIANGLES WITH A PALER TRIANGLE INSIDE EACH. It passed every mechanical check
/// in the package - convex, in bounds, correctly coloured, star-shaped - and it read as a paper
/// cutout of a birthday cake. Found by opening the sheet and looking at it, which is the only
/// instrument that could have found it, and it is worth stating plainly that NOTHING ELSE IN
/// THIS FILE WOULD EVER HAVE FIRED.
///
/// What makes a flame read as a flame, at the sizes this ships at:
///
///  1. A CURVED SILHOUETTE THAT NARROWS TO A TIP. A straight-sided triangle is a party hat. The
///     profile here is w * (1 - t^1.55), which is CONCAVE in t - so the tongue bellies out low
///     down and draws in near the tip, and it stays convex, which the fan needs.
///  2. TONGUES OF DIFFERENT HEIGHTS, LEANING. Equal upright tongues are a fence. Each leans by a
///     fraction of its own height, seeded, so a fire is never symmetrical.
///  3. THREE COLOUR LAYERS, LARGEST FIRST. flame_lo outside, flame in the middle, flame_hi as a
///     small core low down where a real flame is hottest - NOT at the tip, which is where a naive
///     implementation puts it and is why the first version glowed at the wrong end.
///  4. AN EMBER BED UNDER IT, wider than the flames. Without it the fire floats.
///
/// ⚠️ EVERY PART IS DRAWN IN FLAT ROLES. A flame EMITS rather than reflects, and shading one by
/// the lamp normal lights the light - which the eye catches instantly even when it cannot say why.
/// ============================================================================================

/// One tongue of flame: a leaning, bellied teardrop standing on _base.
function hth_flame_tongue(_cx, _base, _w, _h, _lean, _role) {
    var _n = 9;
    var _pts = [];
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n;
        // Concave half-width in t: convex outline, bellied low, drawn to a tip.
        var _hwt = _w * (1 - power(_t, 1.55));
        var _x = _cx + _lean * _h * _t * _t;
        array_push(_pts, [_x + _hwt, _base - _h * _t]);
    }
    for (var _i = _n; _i >= 0; _i--) {
        var _t = _i / _n;
        var _hwt = _w * (1 - power(_t, 1.55));
        var _x = _cx + _lean * _h * _t * _t;
        array_push(_pts, [_x - _hwt, _base - _h * _t]);
    }
    return hth_fill(_pts, _role);
}

/// A whole fire: an ember bed, four leaning tongues, and a hot core low in the flame.
function hth_fire(_cx, _base, _w, _h, _st) {
    var _out = [];

    // The ember bed. Wider than the flames and sitting ON the base line, so the fire is standing
    // in something rather than hovering over it.
    _out = hth_append(_out, hth_dome_mass(_cx, _base, _w * 1.10, _h * 0.13, "clay", 12));
    array_push(_out, hth_fill([[_cx - _w * 1.02, _base - _h * 0.02],
                               [_cx + _w * 1.02, _base - _h * 0.02],
                               [_cx + _w * 0.88, _base],
                               [_cx - _w * 0.88, _base]], "ember"));

    // ⛔ THE HOT CORE IS A SMALL FRACTION OF THE FIRE, AND THE FIRST VERSION MADE IT MOST OF
    // IT. Four tongues each carrying a flame_hi core at 0.52 of their own width overlapped into
    // one near-white cone: a fire that read as a pale horn standing in the grate. A fire is
    // mostly its MIDDLE colour, with a small bright heart low down where the fuel is - so the
    // cores are now a third of the width, drawn on alternate tongues only, and the pale stop
    // itself was pulled down from L 0.94 to L 0.86 so it stops being the brightest thing on the
    // whole sheet. Six tongues rather than four, because the merged look was also a count
    // problem: too few tongues, each too wide, is one shape.
    var _n = 6;
    for (var _i = 0; _i < _n; _i++) {
        var _t = (_i + 0.5) / _n;
        var _tx = _cx + lerp(-_w * 0.74, _w * 0.74, _t);
        // The middle tongues are tallest, which is what a fire in a grate does, and the seeded
        // term stops the six of them forming an arch.
        var _tall = 0.42 + 0.58 * sin(pi * _t);
        var _th = _h * _tall * (0.72 + 0.40 * hth_rng_next(_st));
        var _tw = _w * (0.13 + 0.08 * hth_rng_next(_st));
        var _lean = (hth_rng_next(_st) - 0.5) * 0.80;
        // Largest and coolest first. Painted the other way round the outer tongues cover the
        // core and the whole fire flattens to one colour - the same painter's-order law the
        // glow in hth_light records.
        array_push(_out, hth_flame_tongue(_tx, _base, _tw * 1.45, _th * 1.10, _lean, "flame_lo"));
        array_push(_out, hth_flame_tongue(_tx, _base, _tw, _th, _lean, "flame"));
        // The hot core is LOW, SHORT and not on every tongue.
        if ((_i mod 2) == 1) {
            array_push(_out, hth_flame_tongue(_tx, _base, _tw * 0.34, _th * 0.34, _lean * 0.3,
                                              "flame_hi"));
        }
    }
    return _out;
}

/// -- THE HEARTH ------------------------------------------------------------------------------
/// The piece the product is named for, and the only one that is architecture rather than
/// furniture. A stone breast carried up past the mantel, a sunken opening, a fire back blackened
/// by every fire ever lit in it, and the fire itself if it is burning.
///
/// ⚠️ THE SOOT IS NOT A STAIN ON THE STONE, IT IS ITS OWN MATERIAL. Drawn as a dark wash over the
/// stone ramp it reads as a shading bug; drawn as the soot ramp it reads as a surface, because it
/// has its own five stops and therefore its own lit and shadowed faces.
function hth_f_hearth(_room, _st) {
    var _e = hth_form_extent("hearth");
    var _hw = _e.hw, _top = HTH_G - _e.h;
    var _out = [];

    // The breast: a stone mass from the floor to the ceiling, narrowing above the mantel.
    var _mantel = _top + _e.h * 0.34;
    _out = hth_append(_out, hth_member(-_hw, _mantel, _hw, HTH_G, "stone"));
    // The chimney above, drawn from the mantel to the top of the box. Vertical measurement from
    // the piece's own height, never from its width.
    _out = hth_append(_out, hth_member(-_hw * 0.62, _top, _hw * 0.62, _mantel + 0.004, "stone"));

    // The mantel shelf proper - the thing that makes it read as a fireplace at any size.
    var _msh = _e.h * 0.055;
    _out = hth_append(_out, hth_member(-_hw * 1.06, _mantel - _msh, _hw * 1.06, _mantel, "wood"));

    // The opening, sunk into the breast, and the soot back inside it.
    var _ow = _hw * 0.62;
    var _oy = _mantel + _e.h * 0.10;
    _out = hth_append(_out, hth_recess(-_ow, _oy, _ow, HTH_G, "soot"));

    // The fire. Only if it is lit; a dead hearth is ash and a cold back, and that difference is
    // the loudest thing warmth does to a room.
    if (_room.fire_lit) {
        // Logs across the back of the opening, then the fire in front of them. The fire fills
        // most of the opening: a small polite flame in a large black hole reads as a fireplace
        // that has gone out, which is what `warmth` is for and not what a lit one looks like.
        var _fh = (HTH_G - _oy) * (0.52 + 0.34 * _room.warmth);
        var _fw = _ow * 0.74;
        _out = hth_append(_out, hth_member(-_fw, HTH_G - _fh * 0.24, _fw, HTH_G - 0.004, "wood2"));
        _out = hth_append(_out, hth_fire(0, HTH_G - 0.004, _fw, _fh, _st));
    } else {
        var _aw = _ow * 0.70;
        _out = hth_append(_out, hth_dome_mass(0, HTH_G, _aw, (HTH_G - _oy) * 0.14, "stone", 10));
        array_push(_out, hth_fill([[-_aw, HTH_G - 0.004], [_aw, HTH_G - 0.004],
                                   [_aw * 0.9, HTH_G], [-_aw * 0.9, HTH_G]], "ash"));
    }

    // The stone courses. Count carries the tone, not width.
    var _courses = 4;
    for (var _c = 1; _c < _courses; _c++) {
        var _cy = lerp(_mantel, HTH_G, _c / _courses);
        _out = hth_append(_out, hth_line_in(-_hw * 0.96, _cy, -_ow - 0.006, _cy, "stone", 0.004));
        _out = hth_append(_out, hth_line_in(_ow + 0.006, _cy, _hw * 0.96, _cy, "stone", 0.004));
    }
    return _out;
}

/// -- THE STOVE -------------------------------------------------------------------------------
/// A closed iron or tile stove: a body, a door, a plate on top, a flue leaving the top. The
/// wealthy alternative to an open fire, and it reads as wealth precisely because it is closed.
function hth_f_stove(_room, _st) {
    var _e = hth_form_extent("stove");
    var _hw = _e.hw, _top = HTH_G - _e.h;
    var _mat = (_room.prosperity > 0.6) ? "clay" : "iron";
    var _out = [];
    // ⛔ THE FLUE AND THE OVERHANGING PLATE ARE PART OF THE STOVE, SO THEY LIVE INSIDE ITS BOX.
    // Authored the natural way - body filling the box, flue and plate added outside it - the piece
    // measured 1.28 times its own declared height and 1.10 times its width. The corrective fit
    // would then shrink the whole stove by 22%, which is a stove drawn smaller than it says it is
    // rather than a stove drawn wrong. The rule the whole corpus follows: THE DECLARED BOX IS THE
    // OUTERMOST THING, and an oversail is achieved by narrowing the BODY, never by widening the
    // trim.
    var _body_top = HTH_G - _e.h * 0.72;

    _out = hth_append(_out, hth_member(-_hw * 0.90, _body_top, _hw * 0.90,
                                        HTH_G - _e.h * 0.10, _mat));
    // Feet, so it does not read as a box sitting in the floor.
    _out = hth_append(_out, hth_member(-_hw * 0.78, HTH_G - _e.h * 0.11, -_hw * 0.54, HTH_G, "iron"));
    _out = hth_append(_out, hth_member(_hw * 0.54, HTH_G - _e.h * 0.11, _hw * 0.78, HTH_G, "iron"));
    // The top plate overhangs the body, which is the tell that separates a stove from a cupboard.
    _out = hth_append(_out, hth_member(-_hw, _body_top - _e.h * 0.05, _hw, _body_top, "iron"));
    // The flue, reaching exactly to the top of the box.
    _out = hth_append(_out, hth_member(-_hw * 0.20, _top, _hw * 0.20,
                                        _body_top - _e.h * 0.03, "iron"));
    // The door, sunk, with a handle.
    _out = hth_append(_out, hth_recess(-_hw * 0.50, HTH_G - _e.h * 0.56, _hw * 0.50,
                                        HTH_G - _e.h * 0.22, "iron"));
    array_push(_out, hth_dot(_hw * 0.36, HTH_G - _e.h * 0.39, _hw * 0.09, "brass3"));
    if (_room.fire_lit) {
        array_push(_out, hth_fill([[-_hw * 0.36, HTH_G - _e.h * 0.46],
                                   [_hw * 0.36, HTH_G - _e.h * 0.46],
                                   [_hw * 0.36, HTH_G - _e.h * 0.32],
                                   [-_hw * 0.36, HTH_G - _e.h * 0.32]], "ember"));
    }
    return _out;
}

/// -- BEDS ------------------------------------------------------------------------------------
/// A bed is a frame, a mattress, a bolster and a blanket, and the blanket is where the occupant
/// shows: it is the one large area of DYED cloth in most rooms.
function hth_f_bed(_room, _st) {
    var _e = hth_form_extent("bed");
    var _hw = _e.hw, _h = _e.h, _top = HTH_G - _h;
    var _out = [];

    // Head and foot posts. The head is taller - a bed with equal ends reads as a bench.
    _out = hth_append(_out, hth_member(-_hw, _top, -_hw + 0.030, HTH_G, "wood"));
    _out = hth_append(_out, hth_member(_hw - 0.026, _top + _h * 0.42, _hw, HTH_G, "wood"));
    // The headboard panel, sunk, so the head end has an interior rather than being a slab.
    _out = hth_append(_out, hth_member(-_hw, _top, -_hw + 0.090, HTH_G - _h * 0.34, "wood"));
    _out = hth_append(_out, hth_recess(-_hw + 0.014, _top + _h * 0.10, -_hw + 0.078,
                                        HTH_G - _h * 0.44, "wood"));
    // The frame rail.
    _out = hth_append(_out, hth_member(-_hw, HTH_G - _h * 0.30, _hw, HTH_G - _h * 0.18, "wood"));
    // The mattress: linen, sagging in the middle if the bed is old. A sag is a vertical
    // measurement and it comes from the bed's own height.
    var _sag = _h * 0.10 * _room.age;
    var _my = HTH_G - _h * 0.30;
    array_push(_out, hth_fill([[-_hw + 0.028, _my - _h * 0.20],
                               [_hw - 0.022, _my - _h * 0.20],
                               [_hw - 0.022, _my],
                               [-_hw + 0.028, _my]], "linen3"));
    _out = hth_append(_out, hth_dome_mass(0, _my - _h * 0.20 + _sag, _hw * 0.86,
                                          _h * 0.055, "linen", 12));
    // The blanket, folded back from the head end. Dyed cloth: the occupant's colour.
    _out = hth_append(_out, hth_member(-_hw * 0.22, _my - _h * 0.24, _hw - 0.024, _my - _h * 0.02,
                                        "cloth"));
    // The bolster.
    _out = hth_append(_out, hth_dome_mass(-_hw * 0.62, _my - _h * 0.19, _hw * 0.24, _h * 0.15,
                                          "linen", 12));
    return _out;
}

/// A cot: a soldier's or a patient's bed. No headboard, no blanket worth the name, and it is
/// LOW - which is the whole silhouette difference from a bed and the reason it needs no caption.
function hth_f_cot(_room, _st) {
    var _e = hth_form_extent("cot");
    var _hw = _e.hw, _h = _e.h;
    var _out = [];
    _out = hth_append(_out, hth_member(-_hw, HTH_G - _h * 0.42, -_hw + 0.024, HTH_G, "wood2"));
    _out = hth_append(_out, hth_member(_hw - 0.024, HTH_G - _h * 0.42, _hw, HTH_G, "wood2"));
    _out = hth_append(_out, hth_member(-_hw, HTH_G - _h * 0.42, _hw, HTH_G - _h * 0.26, "wood2"));
    _out = hth_append(_out, hth_dome_mass(0, HTH_G - _h * 0.42, _hw * 0.90, _h * 0.36,
                                          "linen", 12));
    _out = hth_append(_out, hth_member(-_hw * 0.30, HTH_G - _h * 0.72, _hw * 0.88,
                                        HTH_G - _h * 0.44, "cloth"));
    return _out;
}

/// A cradle: a hooded box on rockers. The rockers are the tell, and they are ARCS below the
/// body, which is a silhouette change and therefore survives to game size.
function hth_f_cradle(_room, _st) {
    var _e = hth_form_extent("cradle");
    var _hw = _e.hw, _h = _e.h;
    var _by = HTH_G - _h * 0.22;
    var _out = [];
    // The rockers.
    for (var _s = -1; _s <= 1; _s += 2) {
        array_push(_out, hth_fill([[_s * _hw * 0.86, _by],
                                   [_s * _hw * 0.30, _by],
                                   [_s * _hw * 0.34, HTH_G],
                                   [_s * _hw * 0.78, HTH_G]], "wood1"));
    }
    // The body: a trapezoid, wider at the top, which is how a cradle is actually made.
    array_push(_out, hth_fill([[-_hw * 0.98, _by - _h * 0.52], [_hw * 0.98, _by - _h * 0.52],
                               [_hw * 0.72, _by], [-_hw * 0.72, _by]], "wood2"));
    var _bodypts = [[-_hw * 0.98, _by - _h * 0.52], [_hw * 0.98, _by - _h * 0.52],
                    [_hw * 0.72, _by], [-_hw * 0.72, _by]];
    _out = hth_append(_out, hth_mass(_bodypts, "wood", hth_bev_for(_hw * 1.4, _h * 0.52), 2));
    // The hood over the head end.
    _out = hth_append(_out, hth_dome_mass(-_hw * 0.52, _by - _h * 0.48, _hw * 0.46,
                                          _h * 0.42, "wood", 12));
    // The bedding.
    _out = hth_append(_out, hth_member(-_hw * 0.30, _by - _h * 0.56, _hw * 0.86,
                                        _by - _h * 0.30, "linen"));
    return _out;
}

/// -- TABLES AND SEATING ----------------------------------------------------------------------

/// A joined table: a top, an apron, four legs. Turned legs when the household can afford a
/// lathe-turner, square ones when it cannot - and that is a real wealth tell, not a decoration.
function hth_f_table(_room, _st) {
    var _e = hth_form_extent("table");
    var _hw = _e.hw, _h = _e.h;
    var _ty = HTH_G - _h;
    var _turned = (_room.prosperity > 0.45);
    var _out = [];

    _out = hth_append(_out, hth_member(-_hw, _ty, _hw, _ty + _h * 0.09, "wood"));
    _out = hth_append(_out, hth_member(-_hw * 0.92, _ty + _h * 0.09, _hw * 0.92,
                                        _ty + _h * 0.20, "wood"));
    var _lx = _hw * 0.80;
    for (var _s = -1; _s <= 1; _s += 2) {
        if (_turned) {
            // A turned leg swells at the middle and narrows at the foot. Three tapers, but they
            // are AXIS-ALIGNED members that share an edge, so no join line runs across the leg -
            // the "chain of masses reads as a chain" failure only happens on an angled spine.
            _out = hth_append(_out, hth_taper(_s * _lx, _ty + _h * 0.20, 0.011,
                                              _ty + _h * 0.42, 0.017, "wood"));
            _out = hth_append(_out, hth_taper(_s * _lx, _ty + _h * 0.42, 0.017,
                                              HTH_G - _h * 0.06, 0.010, "wood"));
            _out = hth_append(_out, hth_member(_s * _lx - 0.013, HTH_G - _h * 0.06,
                                               _s * _lx + 0.013, HTH_G, "wood"));
        } else {
            _out = hth_append(_out, hth_member(_s * _lx - 0.014, _ty + _h * 0.20,
                                               _s * _lx + 0.014, HTH_G, "wood"));
        }
    }
    // A stretcher between the legs, low down. It is what stops a table reading as a plank on
    // sticks, and it is the first thing a cheap generator leaves out.
    _out = hth_append(_out, hth_member(-_lx, HTH_G - _h * 0.22, _lx, HTH_G - _h * 0.16, "wood"));
    // Board seams in the top. Count, not width.
    var _boards = 3;
    for (var _b = 1; _b < _boards; _b++) {
        var _bx = lerp(-_hw, _hw, _b / _boards);
        _out = hth_append(_out, hth_line_in(_bx, _ty + 0.004, _bx, _ty + _h * 0.085,
                                            "wood", 0.003));
    }
    return _out;
}

/// A trestle table: a board on two A-frames, taken apart after every meal. Wider and cruder than
/// a joined table, and the X of its frame is the silhouette that tells them apart.
function hth_f_trestle(_room, _st) {
    var _e = hth_form_extent("trestle");
    var _hw = _e.hw, _h = _e.h;
    var _ty = HTH_G - _h;
    var _out = [];
    _out = hth_append(_out, hth_member(-_hw, _ty, _hw, _ty + _h * 0.10, "wood2"));
    for (var _s = -1; _s <= 1; _s += 2) {
        var _cx = _s * _hw * 0.62;
        // Two splayed legs. A quad with both ends parallel to the floor stays convex.
        array_push(_out, hth_fill([[_cx - 0.016, _ty + _h * 0.10], [_cx + 0.010, _ty + _h * 0.10],
                                   [_cx + 0.086, HTH_G], [_cx + 0.058, HTH_G]], "wood21"));
        array_push(_out, hth_fill([[_cx - 0.010, _ty + _h * 0.10], [_cx + 0.016, _ty + _h * 0.10],
                                   [_cx - 0.058, HTH_G], [_cx - 0.086, HTH_G]], "wood22"));
        _out = hth_append(_out, hth_member(_cx - 0.070, HTH_G - _h * 0.30, _cx + 0.070,
                                           HTH_G - _h * 0.24, "wood2"));
    }
    return _out;
}

/// A bench: a plank on four splayed legs. The commonest seat in any room that is not a parlour.
function hth_f_bench(_room, _st) {
    var _e = hth_form_extent("bench");
    var _hw = _e.hw, _h = _e.h;
    var _ty = HTH_G - _h;
    var _out = [];
    _out = hth_append(_out, hth_member(-_hw, _ty, _hw, _ty + _h * 0.20, "wood"));
    for (var _s = -1; _s <= 1; _s += 2) {
        var _cx = _s * _hw * 0.74;
        // ⛔ THE FOOT IS AN OFFSET, NOT A SECOND PAIR OF SIGNED X VALUES, AND THE DIFFERENCE
        // SHIPPED A BOWTIE. MEASURED 2026-08-29: written as [cx - w, cx + w, cx + s*a, cx + s*b]
        // the quad walks left-to-right along the top AND left-to-right along the bottom whenever
        // s is positive, which is a figure-of-eight - so the right-hand leg of every bench in the
        // package filled the wrong region. The winding was fine and the outline was fine; the
        // ORDER was wrong, and only on one of the two mirrored copies. Writing the foot as one
        // splay offset with the SAME half-width applied either side of it makes the point order
        // independent of the mirror, so the shape cannot depend on the sign again.
        var _splay = _s * _h * 0.27;
        array_push(_out, hth_fill([[_cx - 0.013,          _ty + _h * 0.20],
                                   [_cx + 0.013,          _ty + _h * 0.20],
                                   [_cx + _splay + 0.013, HTH_G],
                                   [_cx + _splay - 0.013, HTH_G]], "wood1"));
    }
    return _out;
}

/// A chair: seat, back, four legs, two rails - and an upholstered seat if the household is
/// wealthy, which is the strongest single wealth tell in a parlour.
function hth_f_chair(_room, _st) {
    var _e = hth_form_extent("chair");
    var _hw = _e.hw, _h = _e.h;
    var _sy = HTH_G - _h * 0.46;                 // seat height, from the chair's own height
    var _out = [];

    // Back posts and the crest rail.
    for (var _s = -1; _s <= 1; _s += 2) {
        _out = hth_append(_out, hth_member(_s * _hw * 0.86 - 0.011, HTH_G - _h,
                                           _s * _hw * 0.86 + 0.011, _sy, "wood"));
    }
    _out = hth_append(_out, hth_member(-_hw * 0.94, HTH_G - _h, _hw * 0.94,
                                        HTH_G - _h * 0.90, "wood"));
    // Spindles. Three of them, thin - and hth_bev_for is what stops the bevel eating them.
    for (var _i = 0; _i < 3; _i++) {
        var _sx = lerp(-_hw * 0.60, _hw * 0.60, _i / 2);
        _out = hth_append(_out, hth_member(_sx - 0.007, HTH_G - _h * 0.88, _sx + 0.007,
                                           _sy - _h * 0.03, "wood"));
    }
    // Seat.
    if (_room.prosperity > 0.62) {
        _out = hth_append(_out, hth_member(-_hw, _sy, _hw, _sy + _h * 0.055, "wood"));
        _out = hth_append(_out, hth_dome_mass(0, _sy + 0.002, _hw * 0.94, _h * 0.055,
                                              "leather", 12));
    } else {
        _out = hth_append(_out, hth_member(-_hw, _sy, _hw, _sy + _h * 0.075, "wood"));
    }
    // Legs and the stretcher.
    for (var _s = -1; _s <= 1; _s += 2) {
        _out = hth_append(_out, hth_taper(_s * _hw * 0.82, _sy + _h * 0.06, 0.011,
                                          HTH_G, 0.008, "wood"));
    }
    _out = hth_append(_out, hth_member(-_hw * 0.82, HTH_G - _h * 0.13, _hw * 0.82,
                                        HTH_G - _h * 0.09, "wood"));
    return _out;
}

/// A stool: three legs, splayed, and a round top. Three because a three-legged stool never
/// rocks on an uneven floor, which is why every poor room has one.
function hth_f_stool(_room, _st) {
    var _e = hth_form_extent("stool");
    var _hw = _e.hw, _h = _e.h;
    var _ty = HTH_G - _h;
    var _out = [];
    _out = hth_append(_out, hth_dome_mass(0, _ty + _h * 0.16, _hw, _h * 0.16, "wood", 12));
    for (var _i = 0; _i < 3; _i++) {
        var _f = (_i - 1) / 1;                          // -1, 0, 1
        var _tx = _f * _hw * 0.55;
        array_push(_out, hth_fill([[_tx - 0.011, _ty + _h * 0.14], [_tx + 0.011, _ty + _h * 0.14],
                                   [_tx * 1.9 + 0.009, HTH_G], [_tx * 1.9 - 0.009, HTH_G]],
                                   "wood1"));
    }
    return _out;
}

/// -- STORAGE ---------------------------------------------------------------------------------

/// A chest: a box with iron bands, a lock plate and a domed or flat lid. The bands are what say
/// "this holds something worth locking up".
function hth_f_chest(_room, _st) {
    var _e = hth_form_extent("chest");
    var _hw = _e.hw, _h = _e.h;
    var _ty = HTH_G - _h;
    var _out = [];
    var _domed = (hth_rng_next(_st) < 0.42);
    var _ly = _ty + _h * (_domed ? 0.34 : 0.22);
    _out = hth_append(_out, hth_member(-_hw, _ly, _hw, HTH_G - _h * 0.06, "wood"));
    // Feet.
    _out = hth_append(_out, hth_member(-_hw * 0.92, HTH_G - _h * 0.08, -_hw * 0.62, HTH_G, "wood"));
    _out = hth_append(_out, hth_member(_hw * 0.62, HTH_G - _h * 0.08, _hw * 0.92, HTH_G, "wood"));
    if (_domed) {
        _out = hth_append(_out, hth_dome_mass(0, _ly, _hw, _h * 0.30, "wood", 14));
    } else {
        _out = hth_append(_out, hth_member(-_hw * 1.04, _ty, _hw * 1.04, _ly, "wood"));
    }
    // Iron bands. Three, and they run over the lid as well as the body, which is the detail that
    // separates a banded chest from a box with stripes painted on it.
    for (var _i = 0; _i < 3; _i++) {
        var _bx = lerp(-_hw * 0.66, _hw * 0.66, _i / 2);
        _out = hth_append(_out, hth_member(_bx - 0.010, _ty, _bx + 0.010,
                                           HTH_G - _h * 0.06, "iron"));
    }
    _out = hth_append(_out, hth_member(-0.014, _ly - _h * 0.05, 0.014, _ly + _h * 0.10, "iron"));
    array_push(_out, hth_dot(0, _ly + _h * 0.045, 0.008, "iron0"));
    return _out;
}

/// A wardrobe: a tall case with two panelled doors and a cornice. The cornice is the single
/// thing that stops a tall box reading as a door.
function hth_f_wardrobe(_room, _st) {
    var _e = hth_form_extent("wardrobe");
    var _hw = _e.hw, _h = _e.h;
    var _ty = HTH_G - _h;
    var _out = [];
    _out = hth_append(_out, hth_member(-_hw, _ty + _h * 0.06, _hw, HTH_G - _h * 0.05, "wood"));
    _out = hth_append(_out, hth_member(-_hw * 1.08, _ty, _hw * 1.08, _ty + _h * 0.065, "wood"));
    _out = hth_append(_out, hth_member(-_hw * 1.02, HTH_G - _h * 0.06, _hw * 1.02, HTH_G, "wood"));
    // Two doors, each with a sunk panel. Two panels per door on a wealthy piece.
    var _panels = (_room.prosperity > 0.55) ? 2 : 1;
    for (var _s = -1; _s <= 1; _s += 2) {
        var _dx0 = (_s < 0) ? (-_hw * 0.94) : (_hw * 0.06);
        var _dx1 = (_s < 0) ? (-_hw * 0.06) : (_hw * 0.94);
        for (var _p = 0; _p < _panels; _p++) {
            var _p0 = lerp(_ty + _h * 0.12, HTH_G - _h * 0.10, _p / _panels);
            var _p1 = lerp(_ty + _h * 0.12, HTH_G - _h * 0.10, (_p + 1) / _panels);
            _out = hth_append(_out, hth_recess(_dx0 + 0.012, _p0 + _h * 0.02,
                                               _dx1 - 0.012, _p1 - _h * 0.02, "wood"));
        }
        array_push(_out, hth_dot(_s * _hw * 0.14, HTH_G - _h * 0.46, 0.009, "iron1"));
    }
    return _out;
}

/// A dresser: the display piece of a kitchen. A cupboard base, an open shelved top, and the
/// household's pewter standing on it where visitors can see it.
function hth_f_dresser(_room, _st) {
    var _e = hth_form_extent("dresser");
    var _hw = _e.hw, _h = _e.h;
    var _ty = HTH_G - _h;
    var _mid = HTH_G - _h * 0.42;
    var _out = [];
    _out = hth_append(_out, hth_member(-_hw, _mid, _hw, HTH_G - _h * 0.04, "wood"));
    _out = hth_append(_out, hth_member(-_hw * 1.04, HTH_G - _h * 0.05, _hw * 1.04, HTH_G, "wood"));
    // Two drawers and two doors in the base.
    _out = hth_append(_out, hth_recess(-_hw * 0.92, _mid + _h * 0.02, -0.006,
                                        _mid + _h * 0.12, "wood"));
    _out = hth_append(_out, hth_recess(0.006, _mid + _h * 0.02, _hw * 0.92,
                                        _mid + _h * 0.12, "wood"));
    _out = hth_append(_out, hth_recess(-_hw * 0.92, _mid + _h * 0.16, -0.006,
                                        HTH_G - _h * 0.08, "wood"));
    _out = hth_append(_out, hth_recess(0.006, _mid + _h * 0.16, _hw * 0.92,
                                        HTH_G - _h * 0.08, "wood"));
    // The open rack above: back, sides, and shelves with plates standing on edge.
    _out = hth_append(_out, hth_member(-_hw * 0.94, _ty, _hw * 0.94, _mid, "wood2"));
    _out = hth_append(_out, hth_member(-_hw, _ty, -_hw * 0.94, _mid, "wood"));
    _out = hth_append(_out, hth_member(_hw * 0.94, _ty, _hw, _mid, "wood"));
    _out = hth_append(_out, hth_member(-_hw * 1.04, _ty - _h * 0.03, _hw * 1.04, _ty, "wood"));
    var _shelves = 2;
    for (var _s = 1; _s <= _shelves; _s++) {
        var _sy = lerp(_ty, _mid, _s / (_shelves + 1));
        _out = hth_append(_out, hth_member(-_hw * 0.94, _sy, _hw * 0.94, _sy + _h * 0.022, "wood"));
        // Plates on edge. Their number is the household's wealth, plainly counted.
        // A plate standing on a shelf is a DISC seen face on - as wide as it is high, and round
        // at the top. At 1.7 times its own width it was the same cone as the shelf pots.
        var _n = 2 + floor(_room.prosperity * 4);
        for (var _i = 0; _i < _n; _i++) {
            var _px = lerp(-_hw * 0.78, _hw * 0.78, (_i + 0.5) / _n);
            var _pr = _h * 0.044;
            _out = hth_append(_out, hth_mass(hth_ellipse_pts(_px, _sy - _pr * 0.94,
                                                             _pr, _pr * 0.96, 14),
                                             "pewter", _pr * 0.28, 2));
        }
    }
    return _out;
}

/// A counter: the shop and taproom piece. A heavy top, a boarded front, and a stone slab on top
/// where the household can afford one.
function hth_f_counter(_room, _st) {
    var _e = hth_form_extent("counter");
    var _hw = _e.hw, _h = _e.h;
    var _ty = HTH_G - _h;
    var _stone = (_room.prosperity > 0.50);
    var _out = [];
    _out = hth_append(_out, hth_member(-_hw, _ty + _h * 0.13, _hw, HTH_G, "wood"));
    _out = hth_append(_out, hth_member(-_hw * 1.05, _ty, _hw * 1.05, _ty + _h * 0.14,
                                        _stone ? "stone" : "wood"));
    // Boarded front - vertical planks, count carrying the tone.
    var _planks = 7;
    for (var _i = 1; _i < _planks; _i++) {
        var _px = lerp(-_hw * 0.96, _hw * 0.96, _i / _planks);
        _out = hth_append(_out, hth_line_in(_px, _ty + _h * 0.17, _px, HTH_G - _h * 0.04,
                                            "wood", 0.003));
    }
    _out = hth_append(_out, hth_member(-_hw * 0.98, HTH_G - _h * 0.10, _hw * 0.98,
                                        HTH_G - _h * 0.04, "wood"));
    return _out;
}

/// A bookcase: an open case of shelves, each one carrying a run of books. The books are what
/// make it a bookcase, so they are generated per shelf rather than drawn as a block.
function hth_f_bookcase(_room, _st) {
    var _e = hth_form_extent("bookcase");
    var _hw = _e.hw, _h = _e.h;
    var _ty = HTH_G - _h;
    var _out = [];
    _out = hth_append(_out, hth_member(-_hw * 0.96, _ty, _hw * 0.96, HTH_G, "wood2"));
    _out = hth_append(_out, hth_member(-_hw, _ty, -_hw * 0.92, HTH_G, "wood"));
    _out = hth_append(_out, hth_member(_hw * 0.92, _ty, _hw, HTH_G, "wood"));
    _out = hth_append(_out, hth_member(-_hw * 1.06, _ty - _h * 0.030, _hw * 1.06, _ty, "wood"));
    var _shelves = 4;
    for (var _s = 0; _s <= _shelves; _s++) {
        var _sy = lerp(_ty + _h * 0.05, HTH_G, _s / _shelves);
        _out = hth_append(_out, hth_member(-_hw * 0.92, _sy - _h * 0.018, _hw * 0.92, _sy, "wood"));
        if (_s == _shelves) break;
        var _sy1 = lerp(_ty + _h * 0.05, HTH_G, (_s + 1) / _shelves);
        // A run of books, leaning at the end of the run if the shelf is not full.
        var _fill = 0.45 + 0.50 * hth_rng_next(_st);
        var _x = -_hw * 0.88;
        var _lim = -_hw * 0.88 + (_hw * 1.76) * _fill;
        while (_x < _lim) {
            var _bw = 0.010 + 0.011 * hth_rng_next(_st);
            var _bh = (_sy1 - _sy) * (0.60 + 0.28 * hth_rng_next(_st));
            _out = hth_append(_out, hth_member(_x, _sy1 - _h * 0.018 - _bh, _x + _bw,
                                               _sy1 - _h * 0.018, "leather"));
            _x += _bw + 0.002;
        }
    }
    return _out;
}

/// A desk: a sloped writing top over a case of drawers. The SLOPE is the silhouette, and it is
/// the only piece in the corpus with a non-horizontal top surface.
function hth_f_desk(_room, _st) {
    var _e = hth_form_extent("desk");
    var _hw = _e.hw, _h = _e.h;
    var _ty = HTH_G - _h;
    var _out = [];
    // The sloped lid: a convex quad, higher at the back.
    array_push(_out, hth_fill([[-_hw, _ty], [_hw, _ty + _h * 0.16],
                               [_hw, _ty + _h * 0.24], [-_hw, _ty + _h * 0.08]], "wood3"));
    _out = hth_append(_out, hth_mass([[-_hw, _ty], [_hw, _ty + _h * 0.16],
                                      [_hw, _ty + _h * 0.24], [-_hw, _ty + _h * 0.08]],
                                     "wood", hth_bev_for(_hw * 2, _h * 0.12), 1));
    _out = hth_append(_out, hth_member(-_hw * 0.96, _ty + _h * 0.24, _hw * 0.96,
                                        HTH_G - _h * 0.06, "wood"));
    _out = hth_append(_out, hth_recess(-_hw * 0.88, _ty + _h * 0.30, _hw * 0.88,
                                        _ty + _h * 0.44, "wood"));
    _out = hth_append(_out, hth_recess(-_hw * 0.88, _ty + _h * 0.50, _hw * 0.88,
                                        _ty + _h * 0.64, "wood"));
    array_push(_out, hth_dot(0, _ty + _h * 0.37, 0.008, "brass3"));
    array_push(_out, hth_dot(0, _ty + _h * 0.57, 0.008, "brass3"));
    for (var _s = -1; _s <= 1; _s += 2) {
        _out = hth_append(_out, hth_member(_s * _hw * 0.88 - 0.013, HTH_G - _h * 0.10,
                                           _s * _hw * 0.88 + 0.013, HTH_G, "wood"));
    }
    return _out;
}

/// An altar: a stone table under a linen cloth, with candles on it. The cloth OVERHANGS, which
/// is what makes it read as dressed rather than as a block.
function hth_f_altar(_room, _st) {
    var _e = hth_form_extent("altar");
    var _hw = _e.hw, _h = _e.h;
    var _ty = HTH_G - _h;
    var _out = [];
    // THE CANDLES ARE PART OF THE ALTAR, so the stone table sits at 0.72 of the box and the
    // candles fill the rest of it. Drawing the table full height and standing candles on top
    // measured 1.29 times the declared height - see the stove for the general rule.
    var _slab = HTH_G - _h * 0.72;
    _out = hth_append(_out, hth_member(-_hw * 0.82, _slab + _h * 0.08, _hw * 0.82, HTH_G, "stone"));
    _out = hth_append(_out, hth_member(-_hw, _slab, _hw, _slab + _h * 0.10, "stone"));
    // The frontal: linen hanging over the front, ending short of the floor.
    _out = hth_append(_out, hth_member(-_hw * 0.94, _slab + 0.08 * _h, _hw * 0.94,
                                        HTH_G - _h * 0.10, "linen"));
    // A band of the occupant's dyed cloth across it.
    _out = hth_append(_out, hth_member(-_hw * 0.94, HTH_G - _h * 0.24, _hw * 0.94,
                                        HTH_G - _h * 0.17, "cloth"));
    // Candles. Two, always, because one is a shrine and three is a cathedral.
    for (var _s = -1; _s <= 1; _s += 2) {
        var _cx = _s * _hw * 0.56;
        _out = hth_append(_out, hth_member(_cx - 0.008, _ty + _h * 0.10, _cx + 0.008,
                                           _slab + _h * 0.02, "linen"));
        array_push(_out, hth_dot(_cx, _ty + _h * 0.07, 0.011, "candle"));
        array_push(_out, hth_dot(_cx, _ty + _h * 0.05, 0.006, "flame_hi"));
    }
    return _out;
}

/// -- VESSELS AND CONTAINERS ------------------------------------------------------------------

/// A barrel: staves bulging at the middle, two hoops. The BULGE is the whole silhouette, and a
/// straight-sided barrel reads as a bin.
function hth_f_barrel(_room, _st) {
    var _e = hth_form_extent("barrel");
    var _hw = _e.hw, _h = _e.h;
    var _ty = HTH_G - _h;
    var _out = [];
    // The body: sampled so the widest point is at the middle. Convex by construction because
    // the profile is a single cosine lobe.
    var _n = 12, _left = [], _right = [];
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n;
        var _y = lerp(_ty, HTH_G, _t);
        var _w = _hw * (0.80 + 0.20 * sin(pi * _t));
        array_push(_left, [-_w, _y]);
        array_push(_right, [_w, _y]);
    }
    var _body = [];
    for (var _i = 0; _i <= _n; _i++) array_push(_body, _right[_i]);
    for (var _i = _n; _i >= 0; _i--) array_push(_body, _left[_i]);
    _out = hth_append(_out, hth_mass(_body, "wood2", hth_bev_for(_hw * 2, _h), 2));
    // Staves: count carries the tone.
    for (var _i = 1; _i < 6; _i++) {
        var _sx = lerp(-_hw * 0.78, _hw * 0.78, _i / 6);
        _out = hth_append(_out, hth_line_in(_sx, _ty + _h * 0.10, _sx, HTH_G - _h * 0.08,
                                            "wood2", 0.003));
    }
    // Hoops.
    for (var _i = 0; _i < 2; _i++) {
        var _hy = lerp(_ty + _h * 0.16, HTH_G - _h * 0.16, _i);
        _out = hth_append(_out, hth_member(-_hw * 0.99, _hy, _hw * 0.99, _hy + _h * 0.05, "iron"));
    }
    return _out;
}

/// A crate: boards, corner posts, and nothing else. The cheapest object in the room and it
/// should look it.
function hth_f_crate(_room, _st) {
    var _e = hth_form_extent("crate");
    var _hw = _e.hw, _h = _e.h;
    var _ty = HTH_G - _h;
    var _out = [];
    _out = hth_append(_out, hth_member(-_hw, _ty, _hw, HTH_G, "wood2"));
    for (var _i = 0; _i < 3; _i++) {
        var _by = lerp(_ty, HTH_G, (_i + 0.5) / 3);
        _out = hth_append(_out, hth_member(-_hw * 0.98, _by - _h * 0.035, _hw * 0.98,
                                           _by + _h * 0.035, "wood"));
    }
    for (var _s = -1; _s <= 1; _s += 2) {
        _out = hth_append(_out, hth_member(_s * _hw - _s * 0.024, _ty, _s * _hw, HTH_G, "wood"));
    }
    return _out;
}

/// A sack: a soft mass, wider at the bottom, gathered at the neck. NOT a box - a sack that reads
/// as a box is the tell that a generator has one primitive.
function hth_f_sack(_room, _st) {
    var _e = hth_form_extent("sack");
    var _hw = _e.hw, _h = _e.h;
    var _ty = HTH_G - _h;
    var _out = [];
    var _n = 14, _pts = [];
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n;
        var _y = lerp(HTH_G, _ty + _h * 0.16, _t);
        // A pear profile: full at the base, pinched at the neck. power() keeps it convex.
        var _w = _hw * (1.0 - 0.72 * power(_t, 1.6));
        array_push(_pts, [_w, _y]);
    }
    for (var _i = _n; _i >= 0; _i--) {
        var _t = _i / _n;
        var _y = lerp(HTH_G, _ty + _h * 0.16, _t);
        var _w = _hw * (1.0 - 0.72 * power(_t, 1.6));
        array_push(_pts, [-_w, _y]);
    }
    _out = hth_append(_out, hth_mass(_pts, "linen", hth_bev_for(_hw * 2, _h) * 0.7, 2));
    // The gathered neck, folded over.
    _out = hth_append(_out, hth_dome_mass(0, _ty + _h * 0.18, _hw * 0.36, _h * 0.16, "linen", 10));
    _out = hth_append(_out, hth_member(-_hw * 0.30, _ty + _h * 0.14, _hw * 0.30,
                                        _ty + _h * 0.20, "cloth"));
    return _out;
}

/// A tub: a wide coopered vessel with a flared rim. The FLARE is what separates it from a
/// barrel, and it is a silhouette difference rather than a fill difference, which is the law
/// this wing paid for on a pair of mushrooms.
function hth_f_tub(_room, _st) {
    var _e = hth_form_extent("tub");
    var _hw = _e.hw, _h = _e.h;
    var _ty = HTH_G - _h;
    var _out = [];
    _out = hth_append(_out, hth_mass([[-_hw, _ty], [_hw, _ty],
                                      [_hw * 0.72, HTH_G], [-_hw * 0.72, HTH_G]],
                                     "wood2", hth_bev_for(_hw * 2, _h), 2));
    _out = hth_append(_out, hth_member(-_hw * 1.06, _ty - _h * 0.05, _hw * 1.06,
                                        _ty + _h * 0.05, "wood"));
    _out = hth_append(_out, hth_member(-_hw * 0.90, HTH_G - _h * 0.30, _hw * 0.90,
                                        HTH_G - _h * 0.24, "iron"));
    for (var _i = 1; _i < 5; _i++) {
        var _t = _i / 5;
        var _x0 = lerp(-_hw, _hw, _t), _x1 = lerp(-_hw * 0.72, _hw * 0.72, _t);
        _out = hth_append(_out, hth_line_in(_x0, _ty + _h * 0.10, _x1, HTH_G - _h * 0.04,
                                            "wood2", 0.003));
    }
    return _out;
}

/// A cauldron: an iron belly on three feet, with a bail handle. The handle is an ARC, drawn as a
/// stroke rather than a fill, because a fan cannot draw a C.
function hth_f_cauldron(_room, _st) {
    var _e = hth_form_extent("cauldron");
    var _hw = _e.hw, _h = _e.h;
    var _by = HTH_G - _h * 0.11;
    var _out = [];
    for (var _i = 0; _i < 3; _i++) {
        var _fx = (_i - 1) * _hw * 0.54;
        _out = hth_append(_out, hth_member(_fx - 0.010, _by - _h * 0.03, _fx + 0.010,
                                           HTH_G, "iron"));
    }
    // The belly: an ellipse flattened at the top, so the rim is a real rim.
    // ⚠️ THE BAIL HANDLE STANDS OVER THE POT AND IS PART OF IT, so the belly and rim are pulled
    // down to leave the top third of the box for the handle. Measured 1.24 times the declared
    // height when the handle was simply added above a full-height pot.
    var _n = 16, _pts = [];
    for (var _i = 0; _i <= _n; _i++) {
        var _a = pi * (_i / _n);
        array_push(_pts, [_hw * 0.96 * cos(_a), _by - _h * 0.44 + _h * 0.42 * sin(_a)]);
    }
    _out = hth_append(_out, hth_mass(_pts, "iron", hth_bev_for(_hw * 2, _h * 0.42), 2));
    _out = hth_append(_out, hth_member(-_hw, _by - _h * 0.50, _hw, _by - _h * 0.41, "iron"));
    array_push(_out, hth_arc(0, _by - _h * 0.47, _hw * 0.86, pi, HTH_TAU, 0.010, "iron1"));
    if (_room.fire_lit) {
        // Heat in the MOUTH of the pot, not a ball balanced on its rim. A filled disc read as
        // a red apple sitting on the cauldron, on every sheet it appeared on.
        // Below the rim line, and half the width. Across the rim it read as a red LID.
        array_push(_out, hth_fill([[-_hw * 0.34, _by - _h * 0.44], [_hw * 0.34, _by - _h * 0.44],
                                   [_hw * 0.28, _by - _h * 0.38], [-_hw * 0.28, _by - _h * 0.38]],
                                  "ember"));
    }
    return _out;
}

/// A basin on a stand: a pewter or clay bowl on three splayed legs, with a linen cloth over the
/// rail. The washstand of any room somebody sleeps in.
function hth_f_basin(_room, _st) {
    var _e = hth_form_extent("basin");
    var _hw = _e.hw, _h = _e.h;
    var _ty = HTH_G - _h;
    var _mat = (_room.prosperity > 0.5) ? "pewter" : "clay";
    var _out = [];
    for (var _s = -1; _s <= 1; _s += 2) {
        array_push(_out, hth_fill([[_s * _hw * 0.60 - 0.010, _ty + _h * 0.24],
                                   [_s * _hw * 0.60 + 0.010, _ty + _h * 0.24],
                                   [_s * _hw * 0.86 + 0.009, HTH_G],
                                   [_s * _hw * 0.86 - 0.009, HTH_G]], "wood1"));
    }
    _out = hth_append(_out, hth_member(-_hw * 0.66, HTH_G - _h * 0.22, _hw * 0.66,
                                        HTH_G - _h * 0.17, "wood"));
    _out = hth_append(_out, hth_member(-_hw * 0.34, HTH_G - _h * 0.28, _hw * 0.10,
                                        HTH_G - _h * 0.05, "linen"));
    // The bowl: a shallow inverted dome, so the rim is the widest part.
    var _n = 14, _pts = [];
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n;
        array_push(_pts, [-_hw + 2 * _hw * _t, _ty + _h * 0.24 * sin(pi * _t) + _h * 0.06]);
    }
    array_push(_pts, [_hw, _ty + _h * 0.06]);
    array_push(_pts, [-_hw, _ty + _h * 0.06]);
    _out = hth_append(_out, hth_mass(_pts, _mat, hth_bev_for(_hw * 2, _h * 0.24), 2));
    return _out;
}

/// -- WALL-FIXED AND HUNG PIECES --------------------------------------------------------------

/// A shelf: a board on two brackets, with pots and jars standing on it. Authored with its FIXING
/// at HTH_GROUND, per the coordinate rule for hanging pieces, so the layout solver places it by
/// the thing that touches the wall.
function hth_f_shelf(_room, _st) {
    var _e = hth_form_extent("shelf");
    var _hw = _e.hw, _h = _e.h;
    var _by = HTH_G;
    var _out = [];
    _out = hth_append(_out, hth_member(-_hw, _by - _h * 0.14, _hw, _by - _h * 0.06, "wood"));
    for (var _s = -1; _s <= 1; _s += 2) {
        array_push(_out, hth_fill([[_s * _hw * 0.70, _by - _h * 0.06],
                                   [_s * _hw * 0.70, _by],
                                   [_s * _hw * 0.52, _by - _h * 0.06]], "wood1"));
    }
    // The pots. Their count is the household's prosperity, their spacing is jittered so the
    // shelf never reads as a ruler.
    // ⛔ A POT IS WIDER THAN IT IS TALL AND IT HAS A RIM. A dome half as wide as it is high is
    // a CONE, and the first bake put a row of little grey traffic cones on every shelf in the
    // product - on the hero sheet, four times over. Half-width now exceeds half-height in every
    // case, and a rim band on top is what says "vessel" at a size where nothing else can.
    var _n = 3 + floor(_room.prosperity * 3);
    for (var _i = 0; _i < _n; _i++) {
        var _px = lerp(-_hw * 0.86, _hw * 0.86, (_i + 0.5) / _n)
                  + (hth_rng_next(_st) - 0.5) * _hw * 0.10;
        var _pw = _h * (0.15 + 0.07 * hth_rng_next(_st));
        var _ph = _h * (0.16 + 0.14 * hth_rng_next(_st));
        var _pm = (_i % 3 == 0) ? "pewter" : "clay";
        _out = hth_append(_out, hth_dome_mass(_px, _by - _h * 0.14, _pw, _ph, _pm, 12));
        _out = hth_append(_out, hth_member(_px - _pw * 0.62, _by - _h * 0.14 - _ph * 1.10,
                                           _px + _pw * 0.62, _by - _h * 0.14 - _ph * 0.88, _pm));
    }
    return _out;
}

/// A rack: pegs and a rail on the wall, with tools or weapons hung from it. The HUNG THINGS are
/// the content, and their vocabulary comes from the room's purpose.
function hth_f_rack(_room, _st) {
    var _e = hth_form_extent("rack");
    var _hw = _e.hw, _h = _e.h;
    var _by = HTH_G;
    var _weapons = (_room.purpose == "guardroom");
    var _out = [];
    _out = hth_append(_out, hth_member(-_hw, _by - _h, _hw, _by - _h * 0.86, "wood"));
    var _n = 4;
    for (var _i = 0; _i < _n; _i++) {
        var _px = lerp(-_hw * 0.80, _hw * 0.80, (_i + 0.5) / _n);
        _out = hth_append(_out, hth_member(_px - 0.008, _by - _h * 0.90, _px + 0.008,
                                           _by - _h * 0.78, "wood"));
        if (_weapons) {
            // A hafted weapon: a shaft and a head. Two masses whose silhouette steps.
            _out = hth_append(_out, hth_member(_px - 0.007, _by - _h * 0.82, _px + 0.007,
                                               _by, "wood2"));
            _out = hth_append(_out, hth_mass([[_px - 0.028, _by - _h * 0.80],
                                              [_px + 0.028, _by - _h * 0.80],
                                              [_px + 0.010, _by - _h * 0.52],
                                              [_px - 0.010, _by - _h * 0.52]],
                                             "iron", 0.006, 1));
        } else {
            var _tl = _h * (0.30 + 0.34 * hth_rng_next(_st));
            _out = hth_append(_out, hth_member(_px - 0.006, _by - _h * 0.80, _px + 0.006,
                                               _by - _h * 0.80 + _tl, "iron"));
            _out = hth_append(_out, hth_dome_mass(_px, _by - _h * 0.80 + _tl, 0.020,
                                                  _h * 0.09, "iron", 10));
        }
    }
    return _out;
}

/// A hanging lamp: a bowl on three chains, lit or not. Small, and it is one of only two things
/// in the room that make their own light.
function hth_f_lamp(_room, _st) {
    var _e = hth_form_extent("lamp");
    var _hw = _e.hw, _h = _e.h;
    var _by = HTH_G;
    var _out = [];
    for (var _s = -1; _s <= 1; _s += 2) {
        _out = hth_append(_out, hth_line_in(_s * _hw * 0.10, _by - _h, _s * _hw * 0.80,
                                            _by - _h * 0.34, "brass", 0.004));
    }
    _out = hth_append(_out, hth_mass([[-_hw, _by - _h * 0.34], [_hw, _by - _h * 0.34],
                                      [_hw * 0.56, _by - _h * 0.06], [-_hw * 0.56, _by - _h * 0.06]],
                                     "brass", hth_bev_for(_hw * 2, _h * 0.28), 2));
    if (_room.warmth > 0.30) {
        array_push(_out, hth_dot(0, _by - _h * 0.34, _hw * 0.38, "flame"));
        array_push(_out, hth_dot(0, _by - _h * 0.40, _hw * 0.20, "flame_hi"));
    }
    return _out;
}

/// -- WORK PIECES -----------------------------------------------------------------------------

/// A loom: an upright frame with a warp of threads and a woven band growing at the bottom. The
/// WARP is the picture, and it is carried by count and length, never by stroke width.
function hth_f_loom(_room, _st) {
    var _e = hth_form_extent("loom");
    var _hw = _e.hw, _h = _e.h;
    var _ty = HTH_G - _h;
    var _out = [];
    for (var _s = -1; _s <= 1; _s += 2) {
        _out = hth_append(_out, hth_member(_s * _hw - _s * 0.022, _ty, _s * _hw, HTH_G, "wood"));
    }
    _out = hth_append(_out, hth_member(-_hw, _ty, _hw, _ty + _h * 0.05, "wood"));
    _out = hth_append(_out, hth_member(-_hw, HTH_G - _h * 0.06, _hw, HTH_G, "wood"));
    // The warp.
    var _n = 15;
    for (var _i = 0; _i < _n; _i++) {
        var _wx = lerp(-_hw * 0.86, _hw * 0.86, (_i + 0.5) / _n);
        _out = hth_append(_out, hth_line_in(_wx, _ty + _h * 0.06, _wx, HTH_G - _h * 0.30,
                                            "linen", 0.003));
    }
    // The woven cloth, in the occupant's dye. It grows upward as the work progresses; the amount
    // is seeded, so two looms in two rooms are at different stages.
    var _prog = 0.10 + 0.34 * hth_rng_next(_st);
    _out = hth_append(_out, hth_member(-_hw * 0.88, HTH_G - _h * (0.06 + _prog), _hw * 0.88,
                                        HTH_G - _h * 0.06, "cloth"));
    _out = hth_append(_out, hth_member(-_hw * 0.94, HTH_G - _h * (0.10 + _prog), _hw * 0.94,
                                        HTH_G - _h * (0.06 + _prog), "wood2"));
    return _out;
}

/// An anvil: an iron mass on an oak stump. The HORN is what makes it an anvil, and it is a
/// separate tapered mass so the silhouette steps.
function hth_f_anvil(_room, _st) {
    var _e = hth_form_extent("anvil");
    var _hw = _e.hw, _h = _e.h;
    var _sy = HTH_G - _h * 0.50;
    var _out = [];
    // The stump: a section of tree trunk, so it is slightly barrelled, not a box.
    _out = hth_append(_out, hth_mass([[-_hw * 0.62, _sy], [_hw * 0.62, _sy],
                                      [_hw * 0.70, HTH_G], [-_hw * 0.70, HTH_G]],
                                     "wood2", hth_bev_for(_hw * 1.3, _h * 0.5), 2));
    // The body: a waisted block. Two convex masses, not one concave one.
    _out = hth_append(_out, hth_mass([[-_hw * 0.52, _sy - _h * 0.14], [_hw * 0.52, _sy - _h * 0.14],
                                      [_hw * 0.34, _sy], [-_hw * 0.34, _sy]], "iron", 0.010, 2));
    _out = hth_append(_out, hth_member(-_hw * 0.60, _sy - _h * 0.28, _hw * 0.60,
                                        _sy - _h * 0.13, "iron"));
    // The horn.
    _out = hth_append(_out, hth_mass([[_hw * 0.58, _sy - _h * 0.28], [_hw, _sy - _h * 0.22],
                                      [_hw, _sy - _h * 0.17], [_hw * 0.58, _sy - _h * 0.13]],
                                     "iron", 0.006, 1));
    return _out;
}

/// A screen: a folding frame with a stretched panel. Two leaves at an angle, so it reads as
/// folded rather than flat, and the fold is a silhouette step.
function hth_f_screen(_room, _st) {
    var _e = hth_form_extent("screen");
    var _hw = _e.hw, _h = _e.h;
    var _ty = HTH_G - _h;
    var _out = [];
    // Left leaf, slightly narrower and darker: it is turned away from the lamp.
    _out = hth_append(_out, hth_mass([[-_hw, _ty + _h * 0.05], [-_hw * 0.06, _ty],
                                      [-_hw * 0.06, HTH_G], [-_hw, HTH_G - _h * 0.03]],
                                     "wood", 0.012, 2));
    _out = hth_append(_out, hth_mass([[_hw * 0.06, _ty], [_hw, _ty + _h * 0.05],
                                      [_hw, HTH_G - _h * 0.03], [_hw * 0.06, HTH_G]],
                                     "wood", 0.012, 2));
    _out = hth_append(_out, hth_recess(-_hw * 0.92, _ty + _h * 0.10, -_hw * 0.14,
                                        HTH_G - _h * 0.10, "linen"));
    _out = hth_append(_out, hth_recess(_hw * 0.14, _ty + _h * 0.10, _hw * 0.92,
                                        HTH_G - _h * 0.10, "linen"));
    return _out;
}

/// A rug: the one form that lies FLAT on the boards. Drawn as a shallow trapezoid so it reads as
/// lying on a floor rather than standing against a wall, with a border and a fringe.
function hth_f_rug(_room, _st) {
    var _e = hth_form_extent("rug");
    var _hw = _e.hw, _h = _e.h;
    var _out = [];
    // ⛔ THE RUG IS THE ONE FORM WHOSE BOX IS ALMOST ALL FRINGE, AND IT WAS THE WORST OFFENDER
    // IN THE CORPUS - measured 1.95 times its declared height, because the body was a full box
    // tall AND the fringe was drawn another 0.9 of a box above it. A rug lies flat: its whole
    // vertical extent is a few centimetres, and the fringe is part of that, not an addition to
    // it. Everything below is a fraction of _h measured from the far edge of the fringe.
    var _back  = HTH_G - _h * 0.62;      // the far edge of the pile
    var _front = HTH_G + _h * 0.38;      // the near edge
    var _pts = [[-_hw * 0.90, _back], [_hw * 0.90, _back],
                [_hw, _front], [-_hw, _front]];
    array_push(_out, hth_fill(_pts, "rugm2"));
    array_push(_out, hth_poly(_pts, true, 0.004, "rugm0"));
    var _inner = [[-_hw * 0.76, lerp(_back, _front, 0.28)], [_hw * 0.76, lerp(_back, _front, 0.28)],
                  [_hw * 0.84, lerp(_back, _front, 0.72)], [-_hw * 0.84, lerp(_back, _front, 0.72)]];
    array_push(_out, hth_poly(_inner, true, 0.004, "rugm4"));
    // ⛔ THREE WOVEN BANDS ALONG ITS LENGTH. A large flat area of any colour reads as PAINT, and
    // a rug is the largest single area of colour in a furnished room - on the study sheet it was
    // a slab. The bands are neighbouring stops of the rug's own ramp, so they read as weave
    // rather than as a pattern printed on top of it.
    for (var _i = 0; _i < 3; _i++) {
        var _bt = 0.30 + 0.20 * _i;
        var _by0 = lerp(_back, _front, _bt);
        var _by1 = lerp(_back, _front, _bt + 0.075);
        var _bx = lerp(_hw * 0.90, _hw, _bt);
        array_push(_out, hth_fill([[-_bx, _by0], [_bx, _by0], [_bx, _by1], [-_bx, _by1]],
                                  (_i == 1) ? "linen2" : "rugm0"));
    }
    // The fringe along the far edge. Count carries it, never stroke width.
    for (var _i = 0; _i < 11; _i++) {
        var _fx = lerp(-_hw * 0.88, _hw * 0.88, (_i + 0.5) / 11);
        _out = hth_append(_out, hth_line_in(_fx, _back, _fx, HTH_G - _h, "rugm", 0.003));
    }
    return _out;
}

/// ============================================================================================
/// THE DISPATCH
/// ============================================================================================

/// Build one corpus form. _seed makes two of the same form in one room differ.
///
/// ⚠️ AN UNKNOWN FORM RETURNS AN EMPTY LIST RATHER THAN CRASHING, and hth_selftest asserts that
/// every name in hth_form_names() and every form named by every purpose's slot list builds a
/// NON-EMPTY one. An empty return that nothing checks is how a missing chair ships silently.
function hth_form_build(_form, _room, _seed) {
    return hth_fit_to_extent(hth_form_build_raw(_form, _room, _seed), hth_form_extent(_form));
}

/// The dispatch itself, BEFORE the fit. Separated so the suite can measure how much correction
/// each form needs - a number that is invisible once the fit has been applied.
function hth_form_build_raw(_form, _room, _seed) {
    var _st = hth_rng(hth_hash32(_form + "|" + string(_seed)));
    switch (_form) {
        case "hearth":   return hth_f_hearth(_room, _st);
        case "stove":    return hth_f_stove(_room, _st);
        case "bed":      return hth_f_bed(_room, _st);
        case "cot":      return hth_f_cot(_room, _st);
        case "cradle":   return hth_f_cradle(_room, _st);
        case "table":    return hth_f_table(_room, _st);
        case "trestle":  return hth_f_trestle(_room, _st);
        case "bench":    return hth_f_bench(_room, _st);
        case "chair":    return hth_f_chair(_room, _st);
        case "stool":    return hth_f_stool(_room, _st);
        case "chest":    return hth_f_chest(_room, _st);
        case "wardrobe": return hth_f_wardrobe(_room, _st);
        case "shelf":    return hth_f_shelf(_room, _st);
        case "dresser":  return hth_f_dresser(_room, _st);
        case "counter":  return hth_f_counter(_room, _st);
        case "barrel":   return hth_f_barrel(_room, _st);
        case "crate":    return hth_f_crate(_room, _st);
        case "rug":      return hth_f_rug(_room, _st);
        case "loom":     return hth_f_loom(_room, _st);
        case "anvil":    return hth_f_anvil(_room, _st);
        case "desk":     return hth_f_desk(_room, _st);
        case "altar":    return hth_f_altar(_room, _st);
        case "cauldron": return hth_f_cauldron(_room, _st);
        case "rack":     return hth_f_rack(_room, _st);
        case "basin":    return hth_f_basin(_room, _st);
        case "lamp":     return hth_f_lamp(_room, _st);
        case "sack":     return hth_f_sack(_room, _st);
        case "tub":      return hth_f_tub(_room, _st);
        case "screen":   return hth_f_screen(_room, _st);
        case "bookcase": return hth_f_bookcase(_room, _st);
    }
    return [];
}

/// Draw one piece of furniture on its own, for the buyer's inventory screens and catalogues.
/// The public single-item call named in the readme.
/// ⛔ REFUSES SILENTLY (draws nothing and returns) RATHER THAN CRASHING, and it checks the FORM NAME
/// as well as the types. Guard pass 2026-09-08. Two things were wrong before it: `_room.seed` on a
/// non-struct resolved against the CALLING INSTANCE, so a buyer saw "Variable obj_theirs.seed not
/// set before reading it" and nothing pointing here; and an unrecognised form name is the most
/// natural mistake with this function - it takes one of thirty strings - which a type check cannot
/// see. This is a DRAW call, so drawing nothing is the honest refusal.
function hth_item_draw(_form, _room, _pal, _x, _y, _s) {
    if (!is_string(_form) || !is_struct(_room) || !is_struct(_pal)) return;
    if (!is_numeric(_x) || !is_numeric(_y) || !is_numeric(_s)) return;
    if (!hth_name_in(hth_form_names(), _form)) return;
    var _parts = hth_form_build(_form, _room, _room.seed);
    hth_render_parts(_parts, _pal, _x, _y, _s, 0, _s, undefined);
}
