{
  "$GMScript": "v1",
  "%Name": "hth_furniture",
  "isCompatibility": false,
  "isDnD": false,
  "name": "hth_furniture",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}