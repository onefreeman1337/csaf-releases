{
  "$GMScript": "v1",
  "%Name": "hth_material",
  "isCompatibility": false,
  "isDnD": false,
  "name": "hth_material",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}