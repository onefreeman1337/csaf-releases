/// HEARTH - hth_material. What a room is MADE of, as five-stop relief ramps.
///
/// Every colour in this product is COMPUTED. There is no table of hex values in this package,
/// because a hex table is a thing a buyer cannot steer: ask it for "the same oak, forty years
/// more smoke-darkened" and a table has no answer, while a ramp does.
///
/// -- WHAT A RAMP IS --------------------------------------------------------------------------
/// hth_relief shades a surface by how squarely it faces the lamp and returns one of five role
/// names, "m0" (facing away) through "m4" (facing the lamp). A MATERIAL is therefore five
/// colours, and hth_material_ramp() produces them. Hand the same material two different wear
/// values and you get two ramps that are recognisably the same oak at different ages.
///
/// ⛔ THE STOPS ARE SPACED IN OKLAB LIGHTNESS, NOT IN RGB. That is the whole reason hth_palette
/// exists. Five RGB-spaced stops on warm pine and five on cold pewter have visibly different
/// contrast, and in this product those two materials stand on the SAME TABLE, lit by the same
/// fire. Perceptual spacing is what lets one lamp light both correctly.
///
/// -- HOW A SECOND MATERIAL GETS ITS OWN RAMP -------------------------------------------------
/// hth_relief always emits m0..m4. A bed frame and the blanket on it are different materials, so
/// the blanket's parts are built in m0..m4 and then REMAPPED, once, at construction:
///
///     var _blanket = hth_map_roles(hth_raise(_pts, 0.02, 2), hth_material_map("cloth"));
///
/// hth_map_roles produces a new part list, which is exactly right for a property decided when
/// the piece is built and never changed again. Do NOT use the renderer's draw-time role map for
/// this - that one exists for drawing one borrowed mark once.
///
/// ⚠️ EVERY PREFIX USED IN A MAP MUST EXIST IN THE PALETTE. hth_render_colour falls back to
/// _pal.line for an unknown role, so a typo does not crash - it draws the whole blanket in the
/// ink colour and looks like a shading bug. hth_selftest asserts that every role any corpus form
/// emits resolves in the palette, which is the only way to catch it.
///
/// -- WHY AN INTERIOR NEEDS MORE MATERIALS THAN AN EXTERIOR ------------------------------------
/// A facade is masonry, timber, roof and glass. A room is wood AND cloth AND metal AND fired
/// clay AND leather, all within a metre of each other, and the eye is close enough to tell them
/// apart. The SPAN column below is what does that work: linen and pewter at the same span read
/// as the same stuff in two colours, which is the palette-swap failure this product exists to
/// avoid. Cloth has almost no span because cloth does not catch a lamp; polished pewter has
/// nearly twice as much as anything else in the list.
/// ============================================================================================

/// The number of named materials. Asserted against hth_material_names() by the suite, so the
/// list below and the switch above it can never drift apart silently.
#macro HTH_MAT_N 17

/// Each material is a base lightness, a chroma, a hue in degrees, and how far the ramp spans in
/// lightness. A high span reads as a hard, polished surface (pewter, glass, iron); a low span
/// reads as a soft matte one (wool, rush, plaster).
function hth_material_spec(_mat) {
    switch (_mat) {
        // name          L      C      hue    span   the surface being described
        case "oak":      return { L: 0.330, C: 0.046, h:  58, span: 0.32 }; // dark joined hardwood
        case "pine":     return { L: 0.640, C: 0.058, h:  74, span: 0.24 }; // pale sawn softwood
        case "beech":    return { L: 0.500, C: 0.050, h:  66, span: 0.28 }; // turned legs, spindles
        case "board":    return { L: 0.430, C: 0.054, h:  60, span: 0.30 }; // floorboards, waxed
        case "wicker":   return { L: 0.590, C: 0.066, h:  80, span: 0.13 }; // basketry, matte
        case "rush":     return { L: 0.660, C: 0.052, h:  86, span: 0.11 }; // rush matting, seats
        case "iron":     return { L: 0.255, C: 0.010, h: 250, span: 0.44 }; // hinges, hooks, anvil
        case "pewter":   return { L: 0.560, C: 0.008, h: 248, span: 0.50 }; // plate, tankards
        case "brass":    return { L: 0.580, C: 0.092, h:  88, span: 0.40 }; // lamps, fittings
        case "linen":    return { L: 0.790, C: 0.020, h:  84, span: 0.15 }; // sheets, undyed cloth
        case "wool":     return { L: 0.440, C: 0.098, h:  24, span: 0.17 }; // dyed blanket, rug
        case "leather":  return { L: 0.365, C: 0.072, h:  44, span: 0.26 }; // upholstery, straps
        case "clay":     return { L: 0.470, C: 0.084, h:  36, span: 0.22 }; // jars, crocks, tiles
        case "plaster":  return { L: 0.760, C: 0.024, h:  86, span: 0.17 }; // limewash over daub
        // ⛔ EARTH PLASTER IS ITS OWN MATERIAL AND IT IS NOT THE JAR MATERIAL. A poor wall used
        // to borrow "clay", whose chroma of 0.084 is right for a crock and turns four square
        // metres of wall into dusty rose - one pink room among eleven limewashed ones on the
        // dials sheet. Over a large flat area, chroma has to come down.
        case "daub":     return { L: 0.605, C: 0.034, h:  52, span: 0.15 }; // earth plaster wall
        case "flag":     return { L: 0.455, C: 0.012, h:  78, span: 0.25 }; // stone flags, hearth
        case "soot":     return { L: 0.200, C: 0.008, h:  58, span: 0.30 }; // blackened chimney back
    }
    return { L: 0.500, C: 0.030, h: 70, span: 0.26 };
}

/// The material names, in corpus order. Used by the self-test and the store sheets so that
/// neither can drift from the switch above without going red.
function hth_material_names() {
    return ["oak", "pine", "beech", "board", "wicker", "rush", "iron", "pewter",
            "brass", "linen", "wool", "leather", "clay", "plaster", "daub", "flag", "soot"];
}

/// Five stops for one material at one wear level.
///
/// _wear is 0..1 and does three things at once, because that is what age and smoke do: they
/// DARKEN the surface, they DESATURATE it, and they COMPRESS the ramp. The third is the one that
/// matters and the one a naive implementation misses - a worn surface is not just a darker
/// surface, it is one whose lit and shadowed faces have moved closer together, because it has
/// stopped being smooth enough to catch the lamp cleanly. A soot-black beam with a bright
/// highlight on it reads as wet plastic.
///
/// _hue_shift lets one material serve a whole region without becoming a palette swap: the SAME
/// oak runs cool and grey where it is scrubbed with sand and warm and red where it is oiled,
/// which is a real difference between real households rather than a recolour of one texture.
function hth_material_ramp(_mat, _wear, _hue_shift) {
    var _s = hth_material_spec(_mat);
    var _w = clamp(_wear, 0, 1);
    var _hs = is_undefined(_hue_shift) ? 0 : _hue_shift;

    // Darken, desaturate, compress. The three coefficients are the material law above.
    var _L = _s.L * (1 - 0.38 * _w);
    var _C = _s.C * (1 - 0.55 * _w);
    var _span = _s.span * (1 - 0.45 * _w);

    var _out = array_create(HTH_RAMP_N);
    for (var _i = 0; _i < HTH_RAMP_N; _i++) {
        // -0.5 .. +0.5 across the five stops, so the nominal L stays the mid stop and a spec can
        // be read as "the colour of the surface" rather than "the colour of its shadow".
        var _t = (_i / (HTH_RAMP_N - 1)) - 0.5;
        var _Li = clamp(_L + _span * _t, 0.05, 0.97);
        // Chroma falls in the shadows, as it does in life: the dark face of a red-dyed blanket is
        // browner than its lit face, never a more saturated red.
        var _Ci = _C * (1 + 0.35 * _t);
        _out[_i] = hth_oklch(_Li, max(0, _Ci), _s.h + _hs);
    }
    return _out;
}

/// The role map that points hth_relief's m0..m4 at a named ramp in the palette.
///
/// Returned as a fresh struct every call rather than cached, because hth_map_roles reads it once
/// and a shared mutable map is the kind of thing that works until two rooms are built in the
/// same frame.
function hth_material_map(_prefix) {
    return {
        m0: _prefix + "0", m1: _prefix + "1", m2: _prefix + "2",
        m3: _prefix + "3", m4: _prefix + "4",
    };
}

/// Write one material's five stops into a palette struct under a prefix.
function hth_material_into(_pal, _prefix, _mat, _wear, _hue_shift) {
    var _r = hth_material_ramp(_mat, _wear, _hue_shift);
    for (var _i = 0; _i < HTH_RAMP_N; _i++) {
        variable_struct_set(_pal, _prefix + string(_i), _r[_i]);
    }
    return _pal;
}

/// The primary furniture wood for a household at this prosperity.
///
/// ⚠️ THIS IS A WEALTH TELL AND IT IS SUPPOSED TO BE READABLE WITHOUT A CAPTION. A poor room is
/// pine because pine is what you can saw yourself; a rich room is oak because oak has to be
/// bought, seasoned and joined by somebody who was paid. Beech sits in the middle because it
/// turns beautifully on a pole lathe and costs almost nothing.
function hth_wood_for(_prosperity) {
    if (_prosperity < 0.34) return "pine";
    if (_prosperity < 0.68) return "beech";
    return "oak";
}

/// The floor a household at this prosperity walks on. Same reasoning: earth and rush below,
/// boards in the middle, cut stone flags at the top.
function hth_floor_for(_prosperity) {
    if (_prosperity < 0.30) return "rush";
    if (_prosperity < 0.72) return "board";
    return "flag";
}

/// ============================================================================================
/// THE ROOM PALETTE
///
/// One struct holding every ramp a room needs. Built once per room, handed to every draw call,
/// and never rebuilt per frame - it is about ninety colour conversions and there is no reason to
/// pay for them ninety times a second.
///
/// ⚠️ THE FLAT ROLES AT THE BOTTOM ARE NOT RELIEF ROLES and must not be shaded. `glass` is one
/// colour because a pane is one plane; giving it a five-stop ramp would light the OUTSIDE of the
/// window from the INSIDE lamp, which is the tell that says "this is a texture, not a room".
/// ============================================================================================
/// ⛔ REFUSES A NON-ROOM WITH `undefined` (guard pass 2026-09-08). Handed a number this read
/// `.age` off the CALLING INSTANCE instead of the argument, because GML resolves a field access on
/// a non-struct against instance scope - so the buyer got "Variable obj_theirs.age not set before
/// reading it" and no clue that our function was at fault.
function hth_palette_build(_room) {
    if (!is_struct(_room)) return undefined;
    var _age  = clamp(_room.age, 0, 1);
    var _pros = clamp(_room.prosperity, 0, 1);
    var _warm = clamp(_room.warmth, 0, 1);
    var _tidy = clamp(_room.tidiness, 0, 1);

    // Wear is age plus grime, and an untidy house is a grimier house at the same age. A scrubbed
    // two-hundred-year-old farmhouse table is paler than a neglected twenty-year-old one, and
    // that is the single most legible thing about an interior after the light.
    // ⛔ AGE AT 0.62 MOVED THE PICTURE BY ALMOST NOTHING. Across its whole range it shifted
    // wear by 0.58, and wear only darkens by 0.30 of that - so the dials sheet showed three
    // near-identical rooms captioned 0.08, 0.50 and 0.94. A field a buyer can set and cannot see
    // is not a feature. 0.85, and the darkening coefficient raised with it.
    var _wear = clamp(_age * 0.85 + (1 - _tidy) * 0.24, 0, 1);

    // Smoke wear. A room whose fire burns all winter blackens its beams and its chimney back
    // whatever its age. This is what makes a WARM room feel lived in rather than merely lit.
    var _smoke = clamp(_wear * 0.55 + _warm * 0.45, 0, 1);

    var _hs = _room.hue_shift;

    var _pal = {};

    hth_material_into(_pal, "wood",    _room.wood_mat,  _wear,                     _hs);
    hth_material_into(_pal, "wood2",   "pine",          _wear * 1.10,              _hs);
    hth_material_into(_pal, "floor",   _room.floor_mat, clamp(_wear + 0.18, 0, 1), _hs);
    hth_material_into(_pal, "wall",    _room.wall_mat,  _smoke * 0.80,             _hs);
    hth_material_into(_pal, "beam",    "oak",           _smoke,                    _hs * 0.5);
    hth_material_into(_pal, "iron",    "iron",          _wear * 0.85,              0);
    hth_material_into(_pal, "brass",   "brass",         _wear * 0.55,              0);
    hth_material_into(_pal, "pewter",  "pewter",        _wear * 0.50,              0);
    hth_material_into(_pal, "cloth",   _room.cloth_mat, _wear * 0.90,              _room.dye_hue);
    hth_material_into(_pal, "linen",   "linen",         _wear * 0.75,              _hs);
    hth_material_into(_pal, "leather", "leather",       _wear,                     _hs);
    hth_material_into(_pal, "clay",    "clay",          _wear * 0.70,              _hs);
    hth_material_into(_pal, "stone",   "flag",          _wear * 0.60,              _hs);
    hth_material_into(_pal, "soot",    "soot",          _smoke * 0.40,             0);
    hth_material_into(_pal, "wicker",  "wicker",        _wear,                     _hs);
    // ⛔ A RUG IS ALWAYS DYED WOOL, NEVER THE BEDDING MATERIAL. Drawn in the "cloth" ramp it
    // inherited hth_occupant_cloth, which returns LINEN for a scholar and a priest - so a
    // scholar's study had a white plank lying across the floor. Bedding may be linen; a rug that
    // is not dyed is a dust sheet.
    // ⛔ A RUG CARRIES MORE WEAR THAN ANY OTHER CLOTH IN THE ROOM, and that is not a fudge to
    // dull a colour - it is the one textile that is walked on. At plain cloth wear a woad-dyed
    // rug came out a saturated cyan slab covering a third of the floor and took the eye clean off
    // the fire. The material model turns extra wear into darker, less saturated AND flatter,
    // which is exactly what a trodden rug looks like.
    hth_material_into(_pal, "rugm",    "wool",          clamp(_wear * 0.85 + 0.50, 0, 1),
                      _room.dye_hue);

    // m0..m4 unmapped default to the primary WOOD, so a form that forgets to remap draws as a
    // piece of furniture rather than as the ink colour. A visible-but-wrong material is far
    // easier to spot than a black one.
    for (var _i = 0; _i < HTH_RAMP_N; _i++) {
        variable_struct_set(_pal, "m" + string(_i),
                            variable_struct_get(_pal, "wood" + string(_i)));
    }

    // -- flat roles ------------------------------------------------------------------------------
    // Glazing goes DARKER and colder as a household gets poorer, because poorer glazing is
    // thicker, greener and set in smaller panes; a wealthy house has clearer, paler glass. One
    // line, and one of the strongest wealth tells in the room.
    // ⛔ CHROMA DOWN BY A THIRD. At 0.034 the window was the only saturated cool object in a
    // warm room and the eye went to it instead of to the fire - measured by looking at the hero
    // sheet, where four teal rectangles were the first thing visible on the page.
    _pal.glass     = hth_oklch(0.34 + 0.20 * _pros, 0.022 - 0.009 * _pros, 214);
    _pal.glass_bar = hth_oklch(0.22, 0.010, 250);                 // leading between panes
    _pal.shutter   = hth_oklch(0.28, 0.030, 62);

    // -- the fire ------------------------------------------------------------------------------
    // ⛔ THE FIRE IS THE ONLY THING IN THE ROOM THAT EMITS RATHER THAN REFLECTS, and it is drawn
    // in flat roles for exactly that reason. Shading a flame by the lamp normal would light the
    // light, which is nonsense the eye catches instantly.
    // ⛔ 0.86, NOT 0.94. At 0.94 the heart of the fire was the lightest thing in the whole
    // product - lighter than limewashed plaster in full lamplight - so every store sheet's eye
    // went to a white blob in a grate instead of to the room. A fire is bright RELATIVE to a
    // dark hearth, which is a contrast, not an absolute.
    _pal.flame_hi  = hth_oklch(0.86, 0.110, 92);                  // the pale heart of the flame
    _pal.flame     = hth_oklch(0.78, 0.160, 68);
    _pal.flame_lo  = hth_oklch(0.60, 0.170, 42);
    _pal.ember     = hth_oklch(0.46, 0.150, 34);
    _pal.ash       = hth_oklch(0.60, 0.008, 250);
    // The colour the fire THROWS. Used at low alpha over everything near the hearth; it is warm
    // and it is not very saturated, because a saturated wash turns a room into a filter effect.
    _pal.firelight = hth_oklch(0.72, 0.075, 62);
    _pal.lamplight = hth_oklch(0.76, 0.060, 78);

    _pal.candle    = hth_oklch(0.90, 0.050, 88);
    _pal.gild      = hth_oklch(0.78, 0.095, 88);                  // gilding, prosperity 4 only
    _pal.dust      = hth_oklch(0.52, 0.010, 250);

    // ⛔ THE LABEL COLOUR IS FIXED AND IS NOT DERIVED FROM ANY MATERIAL. The wing has paid for
    // this twice: captions drawn in a material's lightest stop are illegible on whichever
    // backdrop that material happens to be near. There is no single label colour that reads on a
    // limewashed wall AND on a dark page, so the label does not try - it is drawn light with a
    // dark shadow under it, and the PAIR reads on both.
    _pal.label     = hth_oklch(0.94, 0.018, 86);
    _pal.label_sh  = hth_oklch(0.12, 0.010, 250);
    _pal.line      = hth_oklch(0.22, 0.010, 70);                  // the fallback ink
    _pal.ground    = hth_oklch(0.15, 0.014, 250);                 // page/backdrop base
    _pal.felt      = hth_oklch(0.23, 0.016, 250);                 // UI well face
    _pal.shadow    = hth_oklch(0.12, 0.012, 254);                 // contact shadow under a piece

    return _pal;
}

/// Every role name a palette built by hth_palette_build actually contains.
///
/// ⛔ THIS EXISTS SO THE SELF-TEST CAN CHECK A NON-EMPTY SET. An "every role a form emits
/// resolves in the palette" assertion is vacuously true if the role list comes back empty, and
/// this factory has shipped exactly that: a strict-subset check that passed over zero extracted
/// entries and reported clean. The suite asserts this list is long BEFORE it asserts anything
/// with it.
function hth_palette_roles(_pal) {
    return variable_struct_get_names(_pal);
}
