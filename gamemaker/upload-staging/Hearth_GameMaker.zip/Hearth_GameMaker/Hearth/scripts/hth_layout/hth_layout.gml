/// HEARTH - hth_layout. Where the furniture goes, and the four assertions that say it is right.
///
/// ⛔ THIS IS THE PRODUCT'S REAL ENGINEERING AND ITS ONLY NOVEL RISK. Every other gate in this
/// wing tests DRAWING - is the outline convex, is the ink inside the surface, do two forms
/// differ. A generated room can pass all of them and still be obviously wrong to a human:
///
///   | failure                                    | why no drawing check sees it              |
///   | a wardrobe floating clear of the wall      | it is ink, in bounds, convex and deduped  |
///   | a bed placed where the door swings         | geometry valid; the CONFLICT is between   |
///   |                                            | two objects, and neither is malformed     |
///   | clutter at perfectly uniform spacing       | perfectly regular is perfectly legal      |
///   | the only window behind the chimney breast  | both are correctly drawn                  |
///
/// So the layout carries its own assertions, they run BEFORE anything is drawn, and the solver
/// RETRIES rather than shipping a bad room. hth_selftest runs them over the whole corpus sweep -
/// every purpose crossed with every occupant - rather than a sample, and requires zero defects.
///
/// -- THE PROJECTION, DECIDED ONCE --------------------------------------------------------------
/// ⛔ WALLS IN TRUE ELEVATION, FLOOR AS A SHALLOW PLANE. That is the whole projection and nothing
/// in this package mixes it. The back wall is drawn flat-on; the floor is a band between a BACK
/// floor line and a FRONT floor line, and that band is the only depth cue in the product.
/// Furniture stands on one line or the other:
///
///     band "wall"   stands on the BACK line, against the wall, drawn first
///     band "hung"   fixed TO the wall above the floor, drawn with the wall
///     band "floor"  lies flat on the plane (a rug), drawn before everything that stands
///     band "free"   stands on the FRONT line, out in the room, drawn last and slightly larger
///
/// The near band is scaled up by HTH_NEAR, which is the ONLY perspective in the product. A
/// second vanishing point, a receding side wall or a foreshortened top would each be a separate
/// projection, and mixing two is what makes a generated interior look like a collage.
///
/// -- WHY THE SOLVER WORKS IN NORMALISED x ------------------------------------------------------
/// Every function below is PURE - no draw call, no surface, no engine state - and works in room
/// coordinates where 0 is the left wall and 1 is the right. GML cannot be unit-tested outside the
/// engine, so the compensation this wing uses is to push as much logic as possible into functions
/// that hold no engine call at all, and then assert them from a headless in-engine suite. The
/// layout is the largest piece of pure logic in the package and it is the piece most worth
/// testing, which is not a coincidence.
/// ============================================================================================

/// How much of the room's height the floor plane occupies. The rest is wall.
#macro HTH_DEPTH 0.135

/// How much larger a piece standing on the front floor line is than the same piece against the
/// back wall. The only perspective in the product.
#macro HTH_NEAR 1.115

/// The clear strip left at each side wall, in normalised room x.
#macro HTH_MARGIN 0.030

/// How far into the room a door swings, as a multiple of its own width. A door leaf is as long
/// as the opening is wide, and this is the arc it sweeps.
#macro HTH_SWING 1.30

/// The height on the wall at which a window sill sits, as a fraction of the wall height measured
/// UP from the floor. Anything against the wall taller than this fights the window for the same
/// piece of wall.
#macro HTH_SILL 0.46

/// ============================================================================================
/// ROOM GEOMETRY
/// ============================================================================================

/// Resolve a drawing rect into the lines and scales every other function needs.
///
/// ⚠️ THE TWO SCALES ARE NOT INTERCHANGEABLE and a form measured with the wrong one is the
/// commonest way a layout check passes over a picture that is wrong. A form's half-width in
/// NORMALISED room units depends on which band it stands in, because the near band is bigger.
function hth_layout_geom(_x, _y, _w, _h) {
    var _wall_h = _h * (1 - HTH_DEPTH);
    // The unit box spans one room height from the ceiling to HTH_GROUND, which is 0.94 of it.
    var _swall = _wall_h / (HTH_GROUND + 0.5);
    return {
        x: _x, y: _y, w: _w, h: _h,
        ytop:   _y,
        yback:  _y + _wall_h,
        yfront: _y + _h,
        swall:  _swall,
        sfree:  _swall * HTH_NEAR,
    };
}

/// The scale a band is drawn at.
function hth_band_scale(_geom, _band) {
    return (_band == "free") ? _geom.sfree : _geom.swall;
}

/// The floor line a band stands on.
function hth_band_floor(_geom, _band) {
    return (_band == "free") ? _geom.yfront : _geom.yback;
}

/// A form's half-width in NORMALISED room x, for the band it will stand in.
function hth_form_halfw(_form, _band, _geom) {
    var _e = hth_form_extent(_form);
    return (_e.hw * hth_band_scale(_geom, _band)) / _geom.w;
}

/// ============================================================================================
/// THE DOOR
/// ============================================================================================

/// The span the door itself occupies, as [x0, x1] in normalised room x.
function hth_door_span(_room) {
    if (_room.door_left) return [0, _room.door_span];
    return [1 - _room.door_span, 1];
}

/// The span a door SWEEPS, which is what furniture has to keep out of. Wider than the door, and
/// the reason this is a separate function is that the two are different numbers and confusing
/// them is exactly how a bed ends up in a doorway with every check green.
function hth_door_clear(_room) {
    var _s = _room.door_span * HTH_SWING;
    if (_room.door_left) return [0, min(0.72, _s)];
    return [max(0.28, 1 - _s), 1];
}

/// ============================================================================================
/// THE SOLVER
/// ============================================================================================

/// One placed piece.
function hth_place_item(_form, _band, _rank, _x, _hw, _h) {
    return { form: _form, band: _band, rank: _rank, x: _x, hw: _hw, h: _h };
}

/// Lay a list of forms out along a clear run, left to right, with SEEDED, UNEVEN gaps.
///
/// ⛔ THE GAPS ARE NOT EQUAL AND THAT IS A REQUIREMENT, NOT A GARNISH. Furniture at uniform
/// spacing is the single loudest tell that a room was generated rather than furnished, and it is
/// perfectly legal to every geometric check ever written - a ruler passes every test. The gap
/// weights below are drawn from the room's own seeded stream, so the variance is deterministic
/// and hth_layout_check can put a FLOOR under it.
///
/// ⚠️ THE FLOOR IS ASSERTED AS A MINIMUM OVER A SWEEP, NEVER AS A MEAN. This wing's sibling law
/// from another product: a degenerate case hides behind a healthy average, so the suite takes the
/// worst room in the whole corpus and requires THAT one to clear the floor.
///
/// _spread is how uneven the gaps are allowed to be: a tidy household lines things up, a
/// slovenly one does not. It never reaches zero, because even a scrubbed kitchen has a table of
/// one width and a dresser of another.
function hth_layout_run(_forms, _bands, _ranks, _hws, _x0, _x1, _spread, _st) {
    var _n = array_length(_forms);
    var _out = [];
    if (_n <= 0) return _out;

    var _total = 0;
    for (var _i = 0; _i < _n; _i++) _total += _hws[_i] * 2;
    var _run = _x1 - _x0;
    var _slack = _run - _total;
    if (_slack < 0) return _out;                  // caller must drop something first

    // n+1 gaps: one before the first piece, one after the last, one between each pair.
    var _gaps = array_create(_n + 1);
    var _sum = 0;
    for (var _g = 0; _g <= _n; _g++) {
        // The end gaps are half-weighted, so a room does not habitually leave a bigger hole at
        // the wall than between two pieces - which reads as furniture huddling in the middle.
        var _endw = (_g == 0 || _g == _n) ? 0.55 : 1.0;
        _gaps[_g] = _endw * (0.55 + _spread * hth_rng_next(_st));
        _sum += _gaps[_g];
    }

    var _cx = _x0;
    for (var _i = 0; _i < _n; _i++) {
        _cx += (_gaps[_i] / _sum) * _slack;
        array_push(_out, hth_place_item(_forms[_i], _bands[_i], _ranks[_i],
                                        _cx + _hws[_i], _hws[_i],
                                        hth_form_extent(_forms[_i]).h));
        _cx += _hws[_i] * 2;
    }
    return _out;
}

/// Does [a0,a1] overlap [b0,b1] by more than a tolerance?
///
/// ⚠️ THE TOLERANCE IS 0.0008 AND IT IS DELIBERATELY NOT SMALLER. GML applies a default epsilon
/// of 0.00001 to numeric comparisons, so a tolerance at or below that can never fire in either
/// direction: an overlap test written with one passes vacuously forever. Never write a tolerance
/// below about 0.0001 in this package. And GML has no exponent-literal syntax at all - 0.0008
/// spelled 8e-4 is a lexer error that reads like a bracket bug.
function hth_spans_overlap(_a0, _a1, _b0, _b1) {
    return (_a0 < _b1 - 0.0008) && (_b0 < _a1 - 0.0008);
}

/// Solve one room's layout. Returns a struct the drawing stage reads and the suite checks.
///
/// _attempt lets hth_room_furnish retry with a different jitter rather than shipping a room that
/// failed its own assertions.
function hth_layout_solve(_room, _geom, _attempt) {
    var _st = hth_rng(hth_hash32("layout|" + _room.purpose + "|" + _room.occupant + "|"
                                 + string(_room.seed) + "|" + string(_attempt)));

    var _clear = hth_door_clear(_room);
    var _spread = 0.30 + 1.45 * (1 - _room.tidiness);

    // -- which slots survive -------------------------------------------------------------------
    // Primaries are never dropped: a bedchamber without a bed is a bug, not a poor bedchamber.
    // Secondaries need room, fillers need room AND a household that can afford to fill it.
    var _budget = 0.42 + 0.48 * _room.prosperity;
    var _wall_f = [], _wall_b = [], _wall_r = [], _wall_hw = [];
    var _free_f = [], _free_b = [], _free_r = [], _free_hw = [];
    var _hung = [], _floor = [];

    var _wall_used = 0, _free_used = 0;
    var _slots = _room.slots;
    for (var _i = 0; _i < array_length(_slots); _i++) {
        var _sl = _slots[_i];
        var _hw = hth_form_halfw(_sl.form, _sl.band, _geom);

        if (_sl.rank != "primary") {
            if (_sl.rank == "filler" && _room.prosperity < 0.34) continue;
            if (_sl.rank == "filler" && hth_rng_next(_st) > (0.35 + 0.55 * _room.prosperity)) continue;
            if (_sl.band == "wall" && _wall_used + _hw * 2 > _budget) continue;
            if (_sl.band == "free" && _free_used + _hw * 2 > _budget) continue;
        }

        switch (_sl.band) {
            case "wall":
                array_push(_wall_f, _sl.form); array_push(_wall_b, "wall");
                array_push(_wall_r, _sl.rank); array_push(_wall_hw, _hw);
                _wall_used += _hw * 2;
                break;
            case "free":
                array_push(_free_f, _sl.form); array_push(_free_b, "free");
                array_push(_free_r, _sl.rank); array_push(_free_hw, _hw);
                _free_used += _hw * 2;
                break;
            // ⚠️ THE WHOLE SLOT, NOT ITS NAME. The hung pass below places primaries before the
            // window and everything else after it, so it needs the rank - and a list of bare
            // strings is exactly how that ordering got lost the first time.
            case "hung":  array_push(_hung, _sl);       break;
            case "floor": array_push(_floor, _sl.form); break;
        }
    }

    // -- the clear runs -------------------------------------------------------------------------
    // The door eats one end of both runs. A room whose door is on the left is furnished from the
    // swing rightward; a room whose door is on the right is furnished up to the swing.
    var _wx0 = HTH_MARGIN, _wx1 = 1 - HTH_MARGIN;
    if (_room.door_left) _wx0 = max(_wx0, _clear[1]);
    else                 _wx1 = min(_wx1, _clear[0]);

    // The free band keeps clear of the same swing, so it gets the same run. Keeping them
    // identical is what lets ONE assertion cover both, which is worth more than the few
    // centimetres a separate near-band run would recover.
    var _fx0 = _wx0, _fx1 = _wx1;

    // ⛔ A HUNG PRIMARY GETS A RESERVED SLICE OF WALL, AT THE END AWAY FROM THE DOOR. MEASURED
    // 2026-08-29: without this, eleven rooms across the corpus still reported "primary slot rack
    // was dropped" even after the placement order was fixed, and the reason is CONTIGUITY rather
    // than area. A workshop's chimney breast takes 0.28 of a 0.64 run and sits near the middle,
    // so the wall that is left is two gaps of 0.18 - plenty of room in total, and nowhere a
    // 0.27-wide tool rack can hang. No amount of retrying finds a space that does not exist.
    //
    // ⚠️ ONLY THE WALL RUN SHRINKS. A free-standing piece may stand in front of a rack, because
    // it does; it is a piece standing AGAINST that wall that hides it. Shrinking both runs would
    // have cost the room a table for no reason.
    // ⛔ AND IT IS AN ESCALATION, NOT A DEFAULT, WHICH IS THE SECOND HALF OF THE SAME LESSON.
    // MEASURED 2026-08-29: reserving on every attempt fixed the workshop and BROKE THE SHOP -
    // twenty-two rooms then reported "primary slot counter was dropped", because a shop's counter
    // is 0.40 wide and the reservation left it 0.35. The two rooms are not the same problem: a
    // shop's counter is 0.42 tall, BELOW the sill, so a shelf hangs happily above it and no
    // reservation was ever needed. Reserving wall from a room that was not contested is how a fix
    // for one purpose becomes a defect in another.
    //
    // So the solver tries the cheap arrangement first and only reserves once it has failed - the
    // retry loop is already there, and this makes those retries mean something different from
    // each other instead of being eight rolls of the same dice.
    var _hp = 0;
    if (_attempt >= 3) {
        for (var _i = 0; _i < array_length(_hung); _i++) {
            if (_hung[_i].rank != "primary") continue;
            _hp += hth_form_halfw(_hung[_i].form, "wall", _geom) * 2 + 0.01;
        }
    }
    var _hp_lo = _wx0, _hp_hi = _wx1;
    if (_hp > 0 && _hp < (_wx1 - _wx0) * 0.62) {
        if (_room.door_left) { _hp_lo = _wx1 - _hp; _wx1 -= _hp; }
        else                 { _hp_hi = _wx0 + _hp; _wx0 += _hp; }
    }

    // -- drop from the back until the run fits, lowest rank first -------------------------------
    var _wfit = hth_layout_fit(_wall_f, _wall_b, _wall_r, _wall_hw, _wx1 - _wx0);
    var _ffit = hth_layout_fit(_free_f, _free_b, _free_r, _free_hw, _fx1 - _fx0);
    _wall_f = _wfit.f; _wall_b = _wfit.b; _wall_r = _wfit.r; _wall_hw = _wfit.hw;
    _free_f = _ffit.f; _free_b = _ffit.b; _free_r = _ffit.r; _free_hw = _ffit.hw;

    // ⛔ THE FIRE GOES AT THE END OF THE WALL AWAY FROM THE DOOR. hth_layout_run places in array
    // order, left to right, so this is a sort and not a special case - and it is also simply where
    // a chimney is: against a gable, not in the middle of a through wall. It matters here because
    // the free band is laid across the same run, and a table landing in front of the fire reads
    // as a fire burning under the furniture.
    var _fire_i = -1;
    for (var _i = 0; _i < array_length(_wall_f); _i++) {
        if (_wall_f[_i] == "hearth" || _wall_f[_i] == "stove") _fire_i = _i;
    }
    if (_fire_i >= 0) {
        var _tf = _wall_f[_fire_i], _tb = _wall_b[_fire_i];
        var _tr = _wall_r[_fire_i], _th2 = _wall_hw[_fire_i];
        array_delete(_wall_f, _fire_i, 1);  array_delete(_wall_b, _fire_i, 1);
        array_delete(_wall_r, _fire_i, 1);  array_delete(_wall_hw, _fire_i, 1);
        if (_room.door_left) {
            array_push(_wall_f, _tf); array_push(_wall_b, _tb);
            array_push(_wall_r, _tr); array_push(_wall_hw, _th2);
        } else {
            array_insert(_wall_f, 0, _tf); array_insert(_wall_b, 0, _tb);
            array_insert(_wall_r, 0, _tr); array_insert(_wall_hw, 0, _th2);
        }
    }

    var _items = [];
    _items = hth_append(_items, hth_layout_run(_wall_f, _wall_b, _wall_r, _wall_hw,
                                               _wx0, _wx1, _spread, _st));

    // ⛔ AND THE FREE BAND IS OFFERED THE CLEAR SIDE FIRST. If everything free fits beside the
    // fire, it goes beside the fire; if it does not, the whole run is used rather than dropping a
    // table to protect a composition. A quality rule that costs a room its primary furniture is
    // not a quality rule, and this wing has the same escalation two hundred lines above.
    var _free_total = 0;
    for (var _i = 0; _i < array_length(_free_hw); _i++) _free_total += _free_hw[_i] * 2;
    if (_fire_i >= 0 && array_length(_items) > 0) {
        for (var _i = 0; _i < array_length(_items); _i++) {
            if (_items[_i].form != "hearth" && _items[_i].form != "stove") continue;
            var _fs0 = _items[_i].x - _items[_i].hw;
            var _fs1 = _items[_i].x + _items[_i].hw;
            var _left = _fs0 - _fx0, _right = _fx1 - _fs1;
            if (_left >= _free_total && _left >= _right)       { _fx1 = _fs0; }
            else if (_right >= _free_total)                    { _fx0 = _fs1; }
        }
    }
    _items = hth_append(_items, hth_layout_run(_free_f, _free_b, _free_r, _free_hw,
                                               _fx0, _fx1, _spread, _st));

    // -- the wall above the furniture --------------------------------------------------------------
    // ⛔ PRIORITY ORDER: HUNG PRIMARIES, THEN THE WINDOW, THEN EVERYTHING ELSE. MEASURED
    // 2026-08-29: with the window solved first, 29 rooms across the corpus reported "primary slot
    // rack was dropped" - a workshop with no tool rack and an infirmary with no shelf, which are
    // not those rooms. A window is ALLOWED to vanish (a room with no clear wall simply has none,
    // and that is a real room); a primary furnishing slot is not. Ordering the two by which one
    // may legitimately fail is the whole fix.
    var _win_hw = 0.055;
    var _win_x = _room.window_x;
    var _has_window = _room.has_window;
    var _hung_items = [];

    for (var _pass = 0; _pass < 2; _pass++) {
        if (_pass == 1) {
            // The window, placed between the two hung passes.
            if (_has_window) {
                var _ok = false;
                for (var _t = 0; _t < 16; _t++) {
                    var _cand0 = 0.16 + 0.68 * ((_t == 0) ? _room.window_x : hth_rng_next(_st));
                    if (!hth_wall_clear(_cand0, _win_hw, _items)) continue;
                    if (!hth_spans_free(_cand0, _win_hw, _hung_items)) continue;
                    _win_x = _cand0; _ok = true; break;
                }
                if (!_ok) _has_window = false;
            }
        }
        for (var _i = 0; _i < array_length(_hung); _i++) {
            var _sl2 = _hung[_i];
            var _is_primary = (_sl2.rank == "primary");
            if ((_pass == 0) != _is_primary) continue;

            var _f = _sl2.form;
            var _hw2 = hth_form_halfw(_f, "wall", _geom);
            // A primary searches only its reserved slice; everything else searches whatever wall
            // is left over, which is most of it in most rooms.
            var _lo = _is_primary ? (_hp_lo + _hw2) : (HTH_MARGIN + _hw2);
            var _hi = _is_primary ? (_hp_hi - _hw2) : (1 - HTH_MARGIN - _hw2);
            var _span = max(0.001, _hi - _lo);
            var _placed = false;
            // ⚠️ RANDOM TRIES FIRST, THEN A SYSTEMATIC SWEEP. Random sampling alone was the other
            // half of the dropped-rack defect: when a hearth splits the wall into two narrow
            // gaps, eighteen random draws can miss both. The sweep cannot, and running it second
            // keeps the placement varied in the common case where there is plenty of room.
            for (var _try = 0; _try < 40 && !_placed; _try++) {
                var _cand = (_try < 12)
                    ? (_lo + hth_rng_next(_st) * _span)
                    : (_lo + _span * ((_try - 12) / 27));
                if (hth_spans_overlap(_cand - _hw2, _cand + _hw2, _clear[0], _clear[1])) continue;
                if (_pass == 1 && _has_window
                 && hth_spans_overlap(_cand - _hw2, _cand + _hw2,
                                      _win_x - _win_hw, _win_x + _win_hw)) continue;
                if (!hth_wall_clear(_cand, _hw2, _items)) continue;
                if (!hth_spans_free(_cand, _hw2, _hung_items)) continue;
                array_push(_hung_items, hth_place_item(_f, "hung", _sl2.rank, _cand, _hw2,
                                                       hth_form_extent(_f).h));
                _placed = true;
            }
            // A non-primary hung piece that cannot find clear wall is simply not hung. A PRIMARY
            // one that cannot is left unplaced on purpose, so hth_layout_check reports it and the
            // solver retries with a different arrangement rather than shipping the room.
        }
    }

    var _floor_items = [];
    for (var _i = 0; _i < array_length(_floor); _i++) {
        var _f = _floor[_i];
        var _hw3 = hth_form_halfw(_f, "free", _geom);
        var _cx = clamp(0.42 + 0.16 * hth_rng_next(_st), _hw3 + HTH_MARGIN,
                        1 - _hw3 - HTH_MARGIN);
        array_push(_floor_items, hth_place_item(_f, "floor", "filler", _cx, _hw3,
                                                hth_form_extent(_f).h));
    }

    return {
        items:      _items,
        hung:       _hung_items,
        rugs:       _floor_items,
        window_x:   _win_x,
        window_hw:  _win_hw,
        has_window: _has_window,
        door:       hth_door_span(_room),
        door_clear: _clear,
        run:        [_wx0, _wx1],
        attempt:    _attempt,
    };
}

/// Drop the lowest-ranked pieces until the run fits. Never drops a primary, which is why a
/// too-narrow room comes back over-full and hth_layout_check reports it rather than silently
/// producing a chapel with no altar.
function hth_layout_fit(_f, _b, _r, _hw, _run) {
    var _order = ["filler", "secondary"];
    var _guard = 0;
    while (_guard < 64) {
        _guard += 1;
        var _total = 0;
        for (var _i = 0; _i < array_length(_hw); _i++) _total += _hw[_i] * 2;
        if (_total <= _run) break;
        var _cut = -1;
        for (var _o = 0; _o < 2 && _cut < 0; _o++) {
            for (var _i = array_length(_r) - 1; _i >= 0; _i--) {
                if (_r[_i] == _order[_o]) { _cut = _i; break; }
            }
        }
        if (_cut < 0) break;                       // only primaries left: report, do not mangle
        array_delete(_f, _cut, 1); array_delete(_b, _cut, 1);
        array_delete(_r, _cut, 1); array_delete(_hw, _cut, 1);
    }
    return { f: _f, b: _b, r: _r, hw: _hw };
}

/// Is a candidate span of WALL clear of every tall piece standing in front of it?
///
/// ⚠️ ONE FUNCTION, TWO CALLERS, DELIBERATELY. The window and a hung shelf are asking exactly
/// the same question - "is this piece of wall visible?" - and writing it twice under two names
/// is how the two copies drift until a shelf obeys a rule the window does not. Pieces BELOW the
/// sill height never argue: a chest in front of a window is a room, not a defect.
/// Is a candidate span clear of every placed item in a list? The list holds anything with an `x`
/// and an `hw`, which is every placement this file produces.
function hth_spans_free(_x, _hw, _list) {
    for (var _i = 0; _i < array_length(_list); _i++) {
        var _it = _list[_i];
        if (hth_spans_overlap(_x - _hw, _x + _hw, _it.x - _it.hw, _it.x + _it.hw)) return false;
    }
    return true;
}

function hth_wall_clear(_x, _hw, _items) {
    for (var _i = 0; _i < array_length(_items); _i++) {
        var _it = _items[_i];
        if (_it.band != "wall") continue;
        if (_it.h < HTH_SILL) continue;
        if (hth_spans_overlap(_x - _hw, _x + _hw, _it.x - _it.hw, _it.x + _it.hw)) return false;
    }
    return true;
}

/// ============================================================================================
/// THE FOUR ASSERTIONS
///
/// Returns an array of defect strings, EMPTY when the layout is sound. Called by the solver
/// before anything is drawn and by hth_selftest over the entire corpus.
///
/// ⛔ IT RETURNS THE DEFECTS RATHER THAN A BOOLEAN because a boolean gate tells a future session
/// that something is wrong and nothing about what. Every string below names the two pieces
/// involved and the number that failed.
/// ============================================================================================
function hth_layout_check(_layout, _room) {
    var _bad = [];
    var _items = _layout.items;
    var _n = array_length(_items);

    // 1. INSIDE THE ROOM. A piece hanging through the side wall is the failure the declared
    //    extent table exists to make catchable.
    for (var _i = 0; _i < _n; _i++) {
        var _it = _items[_i];
        if (_it.x - _it.hw < -0.002) {
            array_push(_bad, _it.form + " crosses the left wall at " + string(_it.x - _it.hw));
        }
        if (_it.x + _it.hw > 1.002) {
            array_push(_bad, _it.form + " crosses the right wall at " + string(_it.x + _it.hw));
        }
    }

    // 2. NO TWO PIECES IN THE SAME BAND OVERLAP. Two bands may pass in front of each other -
    //    that is what a room looks like - but two things standing on the SAME line cannot
    //    occupy the same floor.
    for (var _i = 0; _i < _n; _i++) {
        for (var _j = _i + 1; _j < _n; _j++) {
            var _a = _items[_i], _b = _items[_j];
            if (_a.band != _b.band) continue;
            if (hth_spans_overlap(_a.x - _a.hw, _a.x + _a.hw, _b.x - _b.hw, _b.x + _b.hw)) {
                array_push(_bad, _a.form + " overlaps " + _b.form + " in the " + _a.band + " band");
            }
        }
    }

    // 3. THE DOOR SWING IS CLEAR. The commonest and ugliest generated-room failure.
    var _c = _layout.door_clear;
    for (var _i = 0; _i < _n; _i++) {
        var _it = _items[_i];
        if (hth_spans_overlap(_it.x - _it.hw, _it.x + _it.hw, _c[0], _c[1])) {
            array_push(_bad, _it.form + " stands in the door swing ["
                             + string(_c[0]) + ".." + string(_c[1]) + "]");
        }
    }
    for (var _i = 0; _i < array_length(_layout.hung); _i++) {
        var _it = _layout.hung[_i];
        if (hth_spans_overlap(_it.x - _it.hw, _it.x + _it.hw, _c[0], _c[1])) {
            array_push(_bad, _it.form + " hangs over the door swing");
        }
    }

    // 4. THE WINDOW IS NOT BEHIND ANYTHING TALL.
    if (_layout.has_window) {
        if (!hth_wall_clear(_layout.window_x, _layout.window_hw, _items)) {
            array_push(_bad, "the window is behind a tall piece at " + string(_layout.window_x));
        }
    }

    // 5. EVERY PRIMARY SURVIVED. The solver is allowed to drop furnishing; it is not allowed to
    //    drop the thing that makes the room what it is.
    var _slots = _room.slots;
    for (var _s = 0; _s < array_length(_slots); _s++) {
        if (_slots[_s].rank != "primary") continue;
        var _found = false;
        for (var _i = 0; _i < _n && !_found; _i++) {
            if (_items[_i].form == _slots[_s].form) _found = true;
        }
        for (var _i = 0; _i < array_length(_layout.hung) && !_found; _i++) {
            if (_layout.hung[_i].form == _slots[_s].form) _found = true;
        }
        if (!_found) array_push(_bad, "primary slot " + _slots[_s].form + " was dropped");
    }

    return _bad;
}

/// The variance of the gaps between pieces standing in one band.
///
/// ⚠️ REPORTED, NOT ASSERTED HERE. The floor belongs in the suite, where it can be taken as the
/// MINIMUM over the whole corpus sweep - the worst room, not the average one. A variance floor
/// applied per room would either be so low it never fires or would refuse the legitimately tidy
/// rooms this product is also supposed to produce.
/// The RATIO of the largest gap to the smallest, in one band. 1.0 means a ruler.
///
/// ⛔ THIS REPLACED A VARIANCE FLOOR, AND THE REPLACEMENT IS THE POINT. MEASURED 2026-08-29: the
/// worst room in the corpus sweep spaced its furniture at variance 0.0000073 against a floor of
/// 0.00004 and went red - and it was a FALSE RED. A room with three free-standing pieces has TWO
/// inner gaps, and the variance of two samples drawn from a healthy random spread is near zero
/// often enough that any floor either never fires or refuses legitimate rooms. Variance is also
/// not scale-free, so a narrow room fails a floor a wide one passes with identical spacing.
///
/// A ratio is scale-free, defined for two samples, and measures the thing actually feared: gaps
/// that are all the same length. Uniform-by-construction gives exactly 1.000, so a floor just
/// above 1 catches the real failure and cannot refuse a room for being unlucky. The suite then
/// asserts TWO different things with it - the worst room clears 1.02 (nothing is a literal ruler)
/// and the median room clears 1.35 (the typical room is visibly uneven) - because a minimum alone
/// says nothing about whether the spread is any good, and a median alone lets one degenerate room
/// hide behind a healthy average.
function hth_layout_gap_ratio(_layout, _band) {
    var _g = [];
    var _items = _layout.items;
    var _prev = undefined;
    for (var _i = 0; _i < array_length(_items); _i++) {
        var _it = _items[_i];
        if (_it.band != _band) continue;
        if (!is_undefined(_prev)) array_push(_g, (_it.x - _it.hw) - _prev);
        _prev = _it.x + _it.hw;
    }
    var _n = array_length(_g);
    if (_n < 2) return -1;                         // not enough pieces to have a rhythm at all
    var _lo = 999, _hi = -999;
    for (var _i = 0; _i < _n; _i++) {
        if (_g[_i] < _lo) _lo = _g[_i];
        if (_g[_i] > _hi) _hi = _g[_i];
    }
    // A gap can legitimately be zero-ish where two pieces stand shoulder to shoulder, and a
    // ratio against zero is not a number. Floor the denominator rather than discarding the room.
    return _hi / max(_lo, 0.002);
}

function hth_layout_gap_variance(_layout, _band) {
    var _g = [];
    var _items = _layout.items;
    var _prev = undefined;
    for (var _i = 0; _i < array_length(_items); _i++) {
        var _it = _items[_i];
        if (_it.band != _band) continue;
        if (!is_undefined(_prev)) array_push(_g, (_it.x - _it.hw) - _prev);
        _prev = _it.x + _it.hw;
    }
    var _n = array_length(_g);
    if (_n < 2) return -1;                         // not enough pieces to have a rhythm at all
    var _mean = 0;
    for (var _i = 0; _i < _n; _i++) _mean += _g[_i];
    _mean /= _n;
    var _v = 0;
    for (var _i = 0; _i < _n; _i++) _v += (_g[_i] - _mean) * (_g[_i] - _mean);
    return _v / _n;
}

/// ============================================================================================
/// THE PUBLIC CALL
/// ============================================================================================

/// Solve a room's layout, retrying with a fresh jitter while it fails its own assertions.
///
/// ⛔ THE RETRY IS THE POINT. A solver that reports a defect and draws the room anyway has
/// bought nothing; a solver that refuses has broken the buyer's game. Retrying with a different
/// seeded stream costs microseconds and almost always succeeds, and the final defect list is
/// carried on the layout so the suite can require it to be empty and the buyer can read it.
/// ⛔ REFUSES A NON-ROOM OR A NON-NUMERIC RECTANGLE WITH `undefined` (guard pass 2026-09-08). A
/// rectangle is four separate arguments, which is four separate chances to pass a string, and the
/// failure surfaced as "DoMul :: Execution Error" deep inside the solver with no argument named.
function hth_room_furnish(_room, _x, _y, _w, _h) {
    if (!is_struct(_room)) return undefined;
    if (!is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_h)) return undefined;
    var _geom = hth_layout_geom(_x, _y, _w, _h);
    var _best = undefined;
    var _best_bad = undefined;
    for (var _a = 0; _a < 8; _a++) {
        var _lay = hth_layout_solve(_room, _geom, _a);
        var _bad = hth_layout_check(_lay, _room);
        if (array_length(_bad) == 0) {
            _lay.geom = _geom;
            _lay.defects = [];
            _room.layout = _lay;
            return _room;
        }
        if (is_undefined(_best) || array_length(_bad) < array_length(_best_bad)) {
            _best = _lay; _best_bad = _bad;
        }
    }
    _best.geom = _geom;
    _best.defects = _best_bad;
    _room.layout = _best;
    return _room;
}
