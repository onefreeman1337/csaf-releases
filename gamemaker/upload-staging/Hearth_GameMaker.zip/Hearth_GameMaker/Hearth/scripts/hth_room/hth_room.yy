{
  "$GMScript": "v1",
  "%Name": "hth_room",
  "isCompatibility": false,
  "isDnD": false,
  "name": "hth_room",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}