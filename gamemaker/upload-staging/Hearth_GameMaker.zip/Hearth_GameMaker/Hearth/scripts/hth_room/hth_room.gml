/// HEARTH - hth_room. The state of a room, and the two enums the whole product turns on.
///
/// ⛔ `purpose` AND `occupant` ARE DELIBERATELY SEPARATE AND THIS IS THE PRODUCT'S CORE IDEA.
/// A kitchen is a kitchen: it has a hearth, a table, somewhere to put a pot. But a kitchen
/// belonging to a miser and a kitchen belonging to a healer are not the same room, and every
/// interior asset pack on the market makes them the same room with a different nameplate.
///
///     purpose  ->  which SLOTS exist, and what fills the ones that define the room
///     occupant ->  the personal objects, the clutter vocabulary, and where the wear falls
///
/// If those two axes render alike, the product has failed at the thing it sells, and
/// hth_selftest asserts they do not: every purpose pair and every occupant pair is required to
/// differ by a measured distance floor, over the whole corpus rather than a sample.
///
/// -- THE FIELDS ------------------------------------------------------------------------------
/// | field      | range | what it moves                                                        |
/// | purpose    | enum  | which furniture slots exist and what fills the primary ones          |
/// | occupant   | enum  | the personal objects, the clutter vocabulary, the wear pattern       |
/// | prosperity | 0..1  | material grade, upholstery, how much of the floor is furnished       |
/// | tidiness   | 0..1  | clutter density, and whether clutter is aligned or scattered         |
/// | age        | 0..1  | wear on surfaces, sag, patina, soot above the hearth                 |
/// | warmth     | 0..1  | fire lit or dead, lamps, and the light the room throws               |
/// | region     | enum  | the same six as the exterior half of this series                    |
///
/// ⚠️ CALL hth_room_derive AFTER ANY DIRECT FIELD ASSIGNMENT. The derived fields - materials,
/// hue shifts, the door side, the slot list - are computed once and read everywhere. Setting
/// `room.prosperity = 0.9` and drawing without deriving gives a rich household furnished in
/// pine, which looks like a shading bug rather than a stale field.
/// ============================================================================================

/// The twelve room purposes, in corpus order.
function hth_purpose_names() {
    return ["kitchen", "bedchamber", "workshop", "shop", "taproom", "study",
            "chapel", "storeroom", "guardroom", "infirmary", "parlour", "cell"];
}

/// The ten occupants, in corpus order.
function hth_occupant_names() {
    return ["farmer", "smith", "healer", "scholar", "miser", "soldier",
            "merchant", "priest", "widow", "child"];
}

/// The six regions, shared with the exterior half of the series so a buyer who owns both can put
/// a house and its inside on one screen without them looking like two different studios.
function hth_region_names() {
    return ["lowland", "upland", "coastal", "forest", "southern", "alpine"];
}

/// The regional hue shift in degrees, applied to the local materials only - the timber, the
/// plaster, the floor. Iron, pewter and brass are traded goods and look the same everywhere,
/// which is itself a real thing about a pre-industrial household and reads correctly without
/// being explained.
function hth_region_hue(_region) {
    switch (_region) {
        case "lowland":  return   0;
        case "upland":   return -14;   // colder, greyer stone and lime
        case "coastal":  return -22;   // salt-bleached, grey
        case "forest":   return   8;   // warmer timber and daub
        case "southern": return  16;   // warm lime, sand
        case "alpine":   return -10;
    }
    return 0;
}

/// The WALL a region builds its inside faces from at a given prosperity.
///
/// ⚠️ THIS IS A SILHOUETTE-FREE TELL AND SO IT HAS TO BE STRONG. An interior has no roof pitch
/// to distinguish a region by, which is the exterior half's whole regional signal. What is left
/// is the wall surface and the floor, so they carry it: a forest room is boarded and dark, a
/// southern one is limewashed and pale, an upland one is bare stone.
function hth_region_wall(_region, _prosperity) {
    var _p = clamp(_prosperity, 0, 1);
    switch (_region) {
        case "upland":   return (_p > 0.62) ? "plaster" : "flag";
        case "alpine":   return (_p > 0.70) ? "plaster" : "board";
        case "coastal":  return (_p > 0.55) ? "plaster" : "flag";
        case "forest":   return (_p > 0.78) ? "plaster" : "board";
        case "southern": return "plaster";
        case "lowland":  return (_p > 0.40) ? "plaster" : "daub";
    }
    return "plaster";
}

/// Whether this region CEILS its rooms with exposed beams. A beamed ceiling is the single
/// cheapest way to say "timber country" and it costs one boolean.
function hth_region_beams(_region) {
    return (_region == "forest" || _region == "alpine" || _region == "lowland");
}

/// ============================================================================================
/// THE SLOT MODEL
///
/// A room is not a list of furniture, it is a list of SLOTS. A slot names a form, says how the
/// form relates to the room, and says how much it matters:
///
///     form   the corpus form to build (see hth_furniture)
///     band   "wall"  - stands against the back wall, drawn first, in the far depth band
///            "free"  - stands out on the floor, drawn second, in the near band
///            "hung"  - fixed to the wall above the floor, drawn with the wall
///            "floor" - lies flat on the boards (a rug), drawn before everything
///     rank   "primary"   - the room is not this room without it
///            "secondary" - normal furnishing
///            "filler"    - present only if the household can afford to fill the space
///     span   how much of the wall or floor run it occupies, 0..1
///
/// ⛔ THE SLOT LIST IS AUTHORED PER PURPOSE AND IS NOT GENERATED. This is the difference between
/// a product that furnishes a room and a product that scatters furniture in one. A chapel with
/// a wardrobe in it is not a chapel, and no amount of tuned randomness fixes that.
/// ============================================================================================

/// One slot.
function hth_slot(_form, _band, _rank, _span) {
    return { form: _form, band: _band, rank: _rank, span: _span };
}

/// The authored slot list for a purpose, richest form first.
///
/// ⚠️ THE PRIMARY SLOTS ARE THE DEFINITION OF THE ROOM and the layout solver is forbidden from
/// dropping one. Everything else may be cut when the household is poor or the room is small; a
/// bedchamber without a bed is a bug, not a poor bedchamber.
function hth_purpose_slots(_purpose) {
    switch (_purpose) {
        case "kitchen": return [
            hth_slot("hearth",   "wall",  "primary",   0.30),
            hth_slot("table",    "free",  "primary",   0.30),
            hth_slot("dresser",  "wall",  "secondary", 0.22),
            hth_slot("bench",    "free",  "secondary", 0.24),
            hth_slot("cauldron", "free",  "secondary", 0.12),
            hth_slot("shelf",    "hung",  "secondary", 0.24),
            hth_slot("barrel",   "free",  "filler",    0.12),
            hth_slot("stool",    "free",  "filler",    0.10),
        ];
        case "bedchamber": return [
            hth_slot("bed",      "wall",  "primary",   0.34),
            hth_slot("chest",    "wall",  "secondary", 0.18),
            hth_slot("wardrobe", "wall",  "secondary", 0.20),
            hth_slot("basin",    "free",  "secondary", 0.12),
            hth_slot("stool",    "free",  "filler",    0.10),
            hth_slot("rug",      "floor", "filler",    0.34),
            hth_slot("lamp",     "hung",  "filler",    0.08),
        ];
        case "workshop": return [
            hth_slot("bench",    "free",  "primary",   0.32),
            hth_slot("rack",     "hung",  "primary",   0.28),
            hth_slot("anvil",    "free",  "secondary", 0.14),
            hth_slot("hearth",   "wall",  "secondary", 0.26),
            hth_slot("crate",    "free",  "secondary", 0.14),
            hth_slot("stool",    "free",  "filler",    0.10),
            hth_slot("shelf",    "hung",  "filler",    0.22),
        ];
        case "shop": return [
            hth_slot("counter",  "wall",  "primary",   0.36),
            hth_slot("shelf",    "hung",  "primary",   0.30),
            hth_slot("crate",    "free",  "secondary", 0.14),
            hth_slot("barrel",   "free",  "secondary", 0.13),
            hth_slot("chest",    "wall",  "secondary", 0.18),
            hth_slot("stool",    "free",  "filler",    0.10),
            hth_slot("sack",     "free",  "filler",    0.12),
        ];
        case "taproom": return [
            hth_slot("counter",  "wall",  "primary",   0.34),
            hth_slot("trestle",  "free",  "primary",   0.34),
            hth_slot("bench",    "free",  "secondary", 0.26),
            hth_slot("barrel",   "free",  "secondary", 0.13),
            hth_slot("hearth",   "wall",  "secondary", 0.26),
            hth_slot("rack",     "hung",  "filler",    0.24),
            hth_slot("stool",    "free",  "filler",    0.10),
        ];
        case "study": return [
            hth_slot("desk",     "wall",  "primary",   0.30),
            hth_slot("bookcase", "wall",  "primary",   0.26),
            hth_slot("chair",    "free",  "secondary", 0.14),
            hth_slot("lamp",     "hung",  "secondary", 0.08),
            hth_slot("chest",    "wall",  "filler",    0.18),
            hth_slot("rug",      "floor", "filler",    0.32),
            hth_slot("shelf",    "hung",  "filler",    0.22),
        ];
        case "chapel": return [
            hth_slot("altar",    "wall",  "primary",   0.30),
            hth_slot("bench",    "free",  "primary",   0.30),
            hth_slot("lamp",     "hung",  "secondary", 0.08),
            hth_slot("screen",   "free",  "secondary", 0.18),
            hth_slot("chest",    "wall",  "filler",    0.18),
            hth_slot("rug",      "floor", "filler",    0.30),
        ];
        case "storeroom": return [
            hth_slot("crate",    "free",  "primary",   0.16),
            hth_slot("barrel",   "free",  "primary",   0.14),
            hth_slot("shelf",    "hung",  "secondary", 0.28),
            hth_slot("sack",     "free",  "secondary", 0.13),
            hth_slot("chest",    "wall",  "secondary", 0.18),
            hth_slot("rack",     "hung",  "filler",    0.24),
            hth_slot("tub",      "free",  "filler",    0.13),
        ];
        case "guardroom": return [
            hth_slot("rack",     "hung",  "primary",   0.28),
            hth_slot("trestle",  "free",  "primary",   0.32),
            hth_slot("cot",      "wall",  "secondary", 0.26),
            hth_slot("bench",    "free",  "secondary", 0.24),
            hth_slot("hearth",   "wall",  "secondary", 0.26),
            hth_slot("chest",    "wall",  "filler",    0.18),
            hth_slot("stool",    "free",  "filler",    0.10),
        ];
        case "infirmary": return [
            hth_slot("cot",      "wall",  "primary",   0.28),
            hth_slot("shelf",    "hung",  "primary",   0.26),
            hth_slot("basin",    "free",  "secondary", 0.12),
            hth_slot("screen",   "free",  "secondary", 0.18),
            hth_slot("stool",    "free",  "secondary", 0.10),
            hth_slot("chest",    "wall",  "filler",    0.18),
            hth_slot("hearth",   "wall",  "filler",    0.26),
        ];
        case "parlour": return [
            hth_slot("hearth",   "wall",  "primary",   0.28),
            hth_slot("chair",    "free",  "primary",   0.15),
            hth_slot("table",    "free",  "secondary", 0.26),
            hth_slot("dresser",  "wall",  "secondary", 0.22),
            hth_slot("rug",      "floor", "secondary", 0.36),
            hth_slot("lamp",     "hung",  "filler",    0.08),
            hth_slot("stool",    "free",  "filler",    0.10),
        ];
        case "cell": return [
            hth_slot("cot",      "wall",  "primary",   0.26),
            hth_slot("stool",    "free",  "secondary", 0.10),
            hth_slot("shelf",    "hung",  "filler",    0.20),
            hth_slot("tub",      "free",  "filler",    0.12),
        ];
    }
    return [hth_slot("stool", "free", "primary", 0.10)];
}

/// ============================================================================================
/// THE OCCUPANT
/// ============================================================================================

/// The personal objects an occupant leaves in a room, richest first. These are drawn as clutter
/// ON furniture and on the floor, and they are the second half of the product's core idea: the
/// SAME kitchen with a different occupant is a different room.
///
/// ⚠️ THE FIRST TWO ENTRIES ARE THE SIGNATURE and the clutter solver never drops them, even in a
/// spotless room. Tidiness controls how much INCIDENTAL clutter there is; it does not control
/// whether a smith owns tongs.
function hth_occupant_objects(_occupant) {
    switch (_occupant) {
        case "farmer":   return ["basket", "boots", "loaf", "apples", "jug", "sickle"];
        case "smith":    return ["tongs", "billet", "bucket", "hammer", "jug", "rag"];
        case "healer":   return ["mortar", "herbs", "jars", "bowl", "cloth", "candle"];
        case "scholar":  return ["book", "scroll", "quill", "candle", "spectacles", "inkpot"];
        case "miser":    return ["strongbox", "tally", "purse", "candle", "crust", "keys"];
        case "soldier":  return ["helm", "spear", "whetstone", "tankard", "boots", "rag"];
        case "merchant": return ["scales", "ledger", "bolt", "purse", "jug", "keys"];
        case "priest":   return ["icon", "candle", "censer", "book", "bowl", "cloth"];
        case "widow":    return ["distaff", "portrait", "shroud", "candle", "bowl", "keys"];
        case "child":    return ["doll", "ball", "top", "crust", "bowl", "boots"];
    }
    return ["bowl", "jug"];
}

/// How much incidental clutter this occupant generates before tidiness is applied.
///
/// ⛔ THIS IS NOT A NEATNESS SCORE - `tidiness` is already that field, and duplicating it here
/// would make the two axes redundant. This is about WORK: a smith's room fills with work in
/// progress however carefully he sweeps it, and a miser's room is bare however slovenly he is,
/// because he owns almost nothing. Occupancy and tidiness are orthogonal and the corpus only
/// looks varied because they are.
function hth_occupant_density(_occupant) {
    switch (_occupant) {
        case "smith":    return 1.00;
        case "healer":   return 0.92;
        case "scholar":  return 0.88;
        case "child":    return 0.84;
        case "farmer":   return 0.76;
        case "merchant": return 0.70;
        case "soldier":  return 0.58;
        case "priest":   return 0.46;
        case "widow":    return 0.40;
        case "miser":    return 0.22;
    }
    return 0.5;
}

/// The dye an occupant's cloth is coloured with, as a hue offset from the base wool hue.
///
/// Cloth is the one thing in a room that is coloured by CHOICE rather than by what the local
/// earth happens to be, so it is the natural place to put a personal signal that survives every
/// regional material change.
function hth_occupant_dye(_occupant) {
    switch (_occupant) {
        case "farmer":   return   8;   // madder, cheap and orange-red
        case "smith":    return  -6;
        case "healer":   return  86;   // weld yellow-green
        case "scholar":  return 196;   // woad, expensive blue
        case "miser":    return  46;   // undyed, brownish
        case "soldier":  return -18;
        case "merchant": return 214;   // deep indigo, a status colour
        case "priest":   return 300;   // purple, a status colour
        case "widow":    return 254;   // near-black blue
        case "child":    return  36;
    }
    return 0;
}

/// The cloth this occupant can afford. Linen for anyone who can keep it clean; wool otherwise.
function hth_occupant_cloth(_occupant, _prosperity) {
    if (_prosperity > 0.66) return "linen";
    if (_occupant == "priest" || _occupant == "scholar") return "linen";
    return "wool";
}

/// ============================================================================================
/// CONSTRUCTION
/// ============================================================================================

/// Build a room from a seed alone. Every field is drawn from the seeded hash, so the same seed
/// is the same room forever and nothing in this product calls random().
///
/// ⛔ REFUSES A NON-NUMERIC SEED WITH `undefined` RATHER THAN CRASHING THE BUYER'S GAME. Measured
/// 2026-09-08 by the generated adversarial harness: 26 of 36 hostile calls against the nine
/// DOCUMENTED entry points took the room down, and hth_room_create(undefined) died inside the hash
/// with "DoMod :2: undefined value" - a message that names nothing a buyer could act on. The guards
/// added across this pass enumerate the KINDS of bad input, not just the range: a guard that catches
/// "off the end" and not "not a number" fails on the most natural typo there is.
function hth_room_create(_seed) {
    if (!is_numeric(_seed)) return undefined;
    var _st = hth_rng(_seed);

    var _purposes  = hth_purpose_names();
    var _occupants = hth_occupant_names();
    var _regions   = hth_region_names();

    var _room = {
        seed:       _seed,
        purpose:    _purposes [floor(hth_rng_next(_st) * array_length(_purposes))],
        occupant:   _occupants[floor(hth_rng_next(_st) * array_length(_occupants))],
        region:     _regions  [floor(hth_rng_next(_st) * array_length(_regions))],
        prosperity: hth_rng_next(_st),
        tidiness:   hth_rng_next(_st),
        age:        hth_rng_next(_st),
        warmth:     hth_rng_next(_st),
    };
    return hth_room_derive(_room);
}

/// Build a room with a purpose and an occupant chosen explicitly and everything else seeded.
/// This is the call the product is named for and the one most buyers will use.
///
/// ⛔ IT REFUSES AN UNKNOWN PURPOSE OR OCCUPANT, NOT ONLY A WRONG TYPE. The Readme documents twelve
/// named purposes and ten named occupants, so "kitchan" is the likeliest mistake anyone makes with
/// this function, and it is the one a type check alone sails straight past. Refusing with
/// `undefined` is checkable with is_struct(); the alternative is a room that silently has no
/// defining furniture because nothing matched its purpose.
function hth_room_of(_purpose, _occupant, _seed) {
    if (!is_string(_purpose) || !is_string(_occupant)) return undefined;
    if (!hth_name_in(hth_purpose_names(), _purpose))   return undefined;
    if (!hth_name_in(hth_occupant_names(), _occupant)) return undefined;
    var _room = hth_room_create(_seed);
    if (!is_struct(_room)) return undefined;
    _room.purpose  = _purpose;
    _room.occupant = _occupant;
    return hth_room_derive(_room);
}

/// Is _want one of the names in _list. Used by the guards above so that "is this a real purpose"
/// is asked in exactly one place.
function hth_name_in(_list, _want) {
    for (var _i = 0; _i < array_length(_list); _i++) if (_list[_i] == _want) return true;
    return false;
}

/// Recompute every derived field. ⛔ CALL THIS AFTER ANY DIRECT FIELD ASSIGNMENT.
///
/// ⚠️ IT MUST BE SAFE TO CALL TWICE. Every value below is computed from the seven authored
/// fields and never from another derived one, so deriving a derived room is a no-op rather than
/// a slow drift. A previous product in this wing accumulated a hue shift on every derive because
/// one line read what the line above it had just written.
///
/// ⛔ REFUSES A NON-ROOM WITH `undefined`. The Readme tells a buyer to call this "after ANY direct
/// field assignment", so it is reached with whatever variable they were holding; handed a number it
/// crashed with "Variable obj_<their object>.prosperity not set before reading it", which blames
/// THEIR object for OUR unchecked dereference. GML resolves `.field` on a non-struct against the
/// calling instance's scope, so a bad argument here surfaces as a bewildering error somewhere else.
function hth_room_derive(_room) {
    if (!is_struct(_room)) return undefined;
    _room.prosperity = clamp(_room.prosperity, 0, 1);
    _room.tidiness   = clamp(_room.tidiness,   0, 1);
    _room.age        = clamp(_room.age,        0, 1);
    _room.warmth     = clamp(_room.warmth,     0, 1);

    var _st = hth_rng(hth_hash32(_room.purpose + "|" + _room.occupant + "|"
                                 + string(_room.seed)));

    _room.hue_shift = hth_region_hue(_room.region);
    _room.wall_mat  = hth_region_wall(_room.region, _room.prosperity);
    _room.floor_mat = hth_floor_for(_room.prosperity);
    _room.wood_mat  = hth_wood_for(_room.prosperity);
    _room.cloth_mat = hth_occupant_cloth(_room.occupant, _room.prosperity);
    _room.dye_hue   = hth_occupant_dye(_room.occupant);
    _room.beams     = hth_region_beams(_room.region);
    _room.density   = hth_occupant_density(_room.occupant);
    _room.objects   = hth_occupant_objects(_room.occupant);
    _room.slots     = hth_purpose_slots(_room.purpose);

    // Which side the door is on, and how wide its swing is. The solver keeps that span clear of
    // every solid, which is the assertion that stops the commonest and ugliest generated-room
    // failure: a bed placed where the door opens.
    _room.door_left  = (hth_rng_next(_st) < 0.5);
    // ⛔ 0.20-0.25 OF THE WALL WAS A DOOR THE SIZE OF A BARN, AND IT DOMINATED EVERY PICTURE.
    // Found by looking at the first bake: the door leaf was the largest, palest object in every
    // cell and the least interesting thing in the room, and it was also eating a quarter of the
    // wall the furniture had to share. A real interior door is about a ninth of a wall's width.
    _room.door_span  = 0.105 + 0.030 * hth_rng_next(_st);

    // A window on the back wall, unless this is a cell or a storeroom - the two purposes for
    // which a window is a contradiction rather than a variation.
    _room.has_window = (_room.purpose != "cell" && _room.purpose != "storeroom")
                       && (hth_rng_next(_st) < 0.78);
    _room.window_x   = 0.30 + 0.40 * hth_rng_next(_st);

    // Is the fire lit? A hearth is in the slot list for six purposes; whether it BURNS is the
    // warmth field, and it is the one thing that changes a whole room's light.
    _room.fire_lit = (_room.warmth > 0.42);

    // The room's own jitter seed, so two rooms with identical fields but different seeds are
    // furnished in a different order rather than being the same picture.
    _room.jitter = hth_rng_next(_st);

    return _room;
}

/// A short human label for a room, for the store sheets and the demo. Purpose and occupant only,
/// because those are the two axes the product sells.
function hth_room_label(_room) {
    return string_upper(string_copy(_room.occupant, 1, 1)) + string_delete(_room.occupant, 1, 1)
         + "'s " + _room.purpose;
}
