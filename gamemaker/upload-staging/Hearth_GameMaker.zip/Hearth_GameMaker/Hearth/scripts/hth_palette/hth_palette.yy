{
  "$GMScript": "v1",
  "%Name": "hth_palette",
  "isCompatibility": false,
  "isDnD": false,
  "name": "hth_palette",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}