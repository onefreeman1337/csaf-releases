/// HEARTH - hth_shell. The room itself: wall, floor, ceiling, window, door, beams.
///
/// The shell is drawn in ROOM coordinates rather than in the unit box, because unlike a piece of
/// furniture it is never placed twice and never scaled independently - it IS the rect. Every
/// function here takes the geom struct from hth_layout_geom and writes straight into it.
///
/// ⛔ THE SHELL IS WHAT MAKES THE REGION READABLE, AND IT IS CARRYING MORE WEIGHT HERE THAN THE
/// EXTERIOR HALF OF THIS SERIES GIVES IT. Outside, a region is a roof pitch - a silhouette you
/// can read at forty pixels. An interior has no roof, so the only regional signals left are the
/// wall surface, the floor surface and whether the ceiling is beamed. They are three flat areas
/// covering most of the picture, which means they are also most of what a buyer sees first.
///
/// ⚠️ AND THE FLOOR PLANE IS THE ONE PLACE THIS PRODUCT USES PERSPECTIVE. Its back edge is
/// narrower than its front edge, by exactly the near-band scale factor, so the floor and the
/// furniture standing on it agree. Getting those two out of step is what makes a generated
/// interior look like a stage flat with objects glued to it.
/// ============================================================================================

/// The wall surface: a flat field in the wall material with a skirting board at the bottom.
///
/// ⚠️ IT IS NOT A GRADIENT. A vertically graded wall reads as a photographed studio backdrop and
/// fights the relief on every piece of furniture in front of it, because the furniture is lit by
/// a fixed diagonal lamp and a graded wall implies a different one. The wall's variation comes
/// from its COURSING and its skirting, both of which are geometry.
function hth_shell_wall(_geom, _room, _pal) {
    var _g = _geom;

    // The wall field.
    draw_set_colour(variable_struct_get(_pal, "wall2"));
    draw_rectangle(_g.x, _g.ytop, _g.x + _g.w, _g.yback, false);

    // Coursing or boarding, depending on what the wall is made of. Count carries the tone: this
    // wing has paid three times over for the law that stroke width is quantised to one pixel at
    // shipped scales and cannot carry a gradient.
    var _wall_h = _g.yback - _g.ytop;
    if (_room.wall_mat == "board") {
        var _n = 11;
        draw_set_colour(variable_struct_get(_pal, "wall1"));
        for (var _i = 1; _i < _n; _i++) {
            var _px = _g.x + _g.w * (_i / _n);
            draw_line(_px, _g.ytop, _px, _g.yback);
        }
    } else if (_room.wall_mat == "flag") {
        var _rows = 6;
        draw_set_colour(variable_struct_get(_pal, "wall1"));
        for (var _r = 1; _r < _rows; _r++) {
            var _py = _g.ytop + _wall_h * (_r / _rows);
            draw_line(_g.x, _py, _g.x + _g.w, _py);
            // Stagger the perpends by half a stone every other course, which is what makes
            // coursed rubble read as masonry rather than as a grid.
            var _cols = 5;
            for (var _c = 0; _c < _cols; _c++) {
                var _off = ((_r % 2) == 0) ? 0.5 : 0.0;
                var _px = _g.x + _g.w * ((_c + _off) / _cols);
                if (_px <= _g.x || _px >= _g.x + _g.w) continue;
                draw_line(_px, _py, _px, _py + _wall_h / _rows);
            }
        }
    }

    // The skirting. A wall that meets the floor with no board is the single fastest way to make
    // a room look unfinished, and it costs two rectangles.
    var _sk = _wall_h * 0.045;
    draw_set_colour(variable_struct_get(_pal, "wood2"));
    draw_rectangle(_g.x, _g.yback - _sk, _g.x + _g.w, _g.yback, false);
    draw_set_colour(variable_struct_get(_pal, "wood4"));
    draw_rectangle(_g.x, _g.yback - _sk, _g.x + _g.w, _g.yback - _sk * 0.72, false);
}

/// The ceiling: a band at the top, with joists if the region builds them.
function hth_shell_ceiling(_geom, _room, _pal) {
    var _g = _geom;
    var _wall_h = _g.yback - _g.ytop;
    var _ch = _wall_h * 0.075;

    // ⛔ THE CEILING IS DARKER THAN THE WALL, AND THE FIRST VERSION HAD IT LIGHTER. Pale joist
    // stubs hanging off a pale band, evenly spaced, read as CRENELLATIONS - every room on the
    // first bake looked like the top of a castle. Two things fix it and both are also true of a
    // real room: the space above head height is in shadow, so it is dark; and joists are darker
    // than the plaster between them, not lighter. Nothing mechanical could have seen this.
    draw_set_colour(variable_struct_get(_pal, "beam0"));
    draw_rectangle(_g.x, _g.ytop, _g.x + _g.w, _g.ytop + _ch, false);

    if (!_room.beams) return;

    // Exposed joists. They run INTO the picture, so they are drawn as short stubs hanging below
    // the ceiling band rather than as long horizontals - a horizontal beam across the whole wall
    // reads as a picture rail, which is the wrong century and the wrong room.
    var _n = 5;
    for (var _i = 0; _i < _n; _i++) {
        var _px = _g.x + _g.w * ((_i + 0.5) / _n);
        var _bw = _g.w * 0.022;
        draw_set_colour(variable_struct_get(_pal, "beam1"));
        draw_rectangle(_px - _bw, _g.ytop + _ch, _px + _bw, _g.ytop + _ch * 1.55, false);
        draw_set_colour(variable_struct_get(_pal, "beam2"));
        draw_rectangle(_px - _bw, _g.ytop + _ch, _px - _bw * 0.50, _g.ytop + _ch * 1.55, false);
    }
    // The bressummer the joists sit on.
    draw_set_colour(variable_struct_get(_pal, "beam1"));
    draw_rectangle(_g.x, _g.ytop + _ch * 0.74, _g.x + _g.w, _g.ytop + _ch, false);
}

/// The floor plane: a trapezoid narrowing to the back, in the floor material.
///
/// ⛔ THE BACK EDGE IS NARROWER BY THE NEAR-BAND FACTOR, NOT BY A TUNED CONSTANT. The furniture
/// standing on the front line is drawn HTH_NEAR times bigger than the same piece against the
/// wall; if the floor recedes by any other amount the two disagree and the room reads as a flat
/// backdrop with cut-outs standing on it. One number, used twice, is the whole fix.
function hth_shell_floor(_geom, _room, _pal) {
    var _g = _geom;
    var _inset = _g.w * (1 - 1 / HTH_NEAR) * 0.5;

    draw_set_colour(variable_struct_get(_pal, "floor2"));
    draw_primitive_begin(pr_trianglefan);
    draw_vertex(_g.x + _inset,          _g.yback);
    draw_vertex(_g.x + _g.w - _inset,   _g.yback);
    draw_vertex(_g.x + _g.w,            _g.yfront);
    draw_vertex(_g.x,                   _g.yfront);
    draw_primitive_end();

    // Boards or flags, drawn as receding lines so the plane has a direction. The lines converge
    // on the same vanishing arrangement as the trapezoid, which is why they are drawn from
    // matched fractions of the back and front edges rather than as parallels.
    var _n = (_room.floor_mat == "flag") ? 6 : 10;
    draw_set_colour(variable_struct_get(_pal, "floor1"));
    for (var _i = 1; _i < _n; _i++) {
        var _t = _i / _n;
        draw_line(_g.x + _inset + (_g.w - _inset * 2) * _t, _g.yback,
                  _g.x + _g.w * _t,                          _g.yfront);
    }
    if (_room.floor_mat == "flag") {
        // Flags also course across, which boards do not. That difference is the material.
        var _rows = 3;
        for (var _r = 1; _r < _rows; _r++) {
            var _t = _r / _rows;
            var _y = lerp(_g.yback, _g.yfront, _t);
            var _in = lerp(_inset, 0, _t);
            draw_line(_g.x + _in, _y, _g.x + _g.w - _in, _y);
        }
    }
    if (_room.floor_mat == "rush") {
        // Rush matting: a woven grid, and it does not recede, because matting is laid in squares
        // on whatever is underneath.
        draw_set_colour(variable_struct_get(_pal, "floor3"));
        var _rows = 4;
        for (var _r = 1; _r < _rows; _r++) {
            var _t = _r / _rows;
            var _y = lerp(_g.yback, _g.yfront, _t);
            var _in = lerp(_inset, 0, _t);
            draw_line(_g.x + _in, _y, _g.x + _g.w - _in, _y);
        }
    }

    // The line where the floor meets the wall. Without it the two planes bleed into one another
    // and the room loses its corner.
    draw_set_colour(variable_struct_get(_pal, "floor0"));
    draw_line(_g.x + _inset, _g.yback, _g.x + _g.w - _inset, _g.yback);
}

/// A window in the back wall: a recessed reveal, leaded panes, a sill, and daylight.
///
/// ⛔ AN OPENING IS A SUBTRACTED AREA WITH A RECESSED REVEAL, never lines drawn on a filled wall.
/// At game scale a drawn rectangle is a smudge and a recessed one is a window, because the
/// reveal is LIT ON ONE SIDE AND DARK ON THE OTHER and that asymmetry survives down to about
/// four pixels.
function hth_shell_window(_geom, _room, _pal) {
    if (!_room.layout.has_window) return;
    var _g = _geom;
    var _wall_h = _g.yback - _g.ytop;
    var _cx = _g.x + _g.w * _room.layout.window_x;
    var _hw = _g.w * _room.layout.window_hw;
    var _y0 = _g.ytop + _wall_h * 0.22;
    var _y1 = _g.yback - _wall_h * HTH_SILL;

    // The reveal, solved from the opening's own SMALLER dimension. A reveal wider than the
    // feature it reveals turns that feature inside out, and a tall narrow window is exactly the
    // shape that catches a fixed constant out.
    var _rev = min(_hw * 2, _y1 - _y0) * 0.16;

    draw_set_colour(variable_struct_get(_pal, "wall0"));
    draw_rectangle(_cx - _hw - _rev, _y0 - _rev, _cx + _hw + _rev, _y1, false);
    draw_set_colour(variable_struct_get(_pal, "wall4"));
    draw_rectangle(_cx - _hw - _rev, _y0 - _rev, _cx - _hw, _y1, false);

    draw_set_colour(_pal.glass);
    draw_rectangle(_cx - _hw, _y0, _cx + _hw, _y1, false);

    // Leading. A poor household has small panes and therefore MORE bars, which is the opposite
    // of the intuition and is the correct history: glass was sold by the piece.
    var _cols = (_room.prosperity > 0.62) ? 2 : 3;
    var _rows = (_room.prosperity > 0.62) ? 3 : 4;
    draw_set_colour(_pal.glass_bar);
    for (var _i = 1; _i < _cols; _i++) {
        var _px = lerp(_cx - _hw, _cx + _hw, _i / _cols);
        draw_line(_px, _y0, _px, _y1);
    }
    for (var _i = 1; _i < _rows; _i++) {
        var _py = lerp(_y0, _y1, _i / _rows);
        draw_line(_cx - _hw, _py, _cx + _hw, _py);
    }

    // The sill, overhanging on both sides.
    draw_set_colour(variable_struct_get(_pal, "stone3"));
    draw_rectangle(_cx - _hw - _rev * 1.6, _y1, _cx + _hw + _rev * 1.6, _y1 + _wall_h * 0.030,
                   false);
    draw_set_colour(variable_struct_get(_pal, "stone1"));
    draw_rectangle(_cx - _hw - _rev * 1.6, _y1 + _wall_h * 0.022,
                   _cx + _hw + _rev * 1.6, _y1 + _wall_h * 0.030, false);
}

/// The door in a side wall, drawn as a plank leaf standing in a recessed opening.
///
/// It is drawn on the wall rather than in perspective, because the projection is elevation and
/// a foreshortened door would be a second projection. What sells it is the ledged planking and
/// the strap hinges, both of which are flat-on details.
function hth_shell_door(_geom, _room, _pal) {
    var _g = _geom;
    var _wall_h = _g.yback - _g.ytop;
    var _sp = hth_door_span(_room);
    var _x0 = _g.x + _g.w * _sp[0];
    var _x1 = _g.x + _g.w * _sp[1];
    // Keep the leaf off the very edge of the picture so its frame is visible on both sides.
    if (_room.door_left) _x0 += _g.w * 0.012; else _x1 -= _g.w * 0.012;

    // ⛔ THE HEAD SITS AT 0.38 OF THE WALL, NOT AT 0.17. In the first bake the door ran nearly
    // floor to ceiling in a pale softwood and was the loudest object on every sheet - a slab
    // three times the size of the bed beside it. A door is a hole in a wall, so what should read
    // is the DARK OPENING and the ironwork; the leaf itself is the least interesting plane in
    // the room and is drawn in the smoke-darkened beam ramp for exactly that reason.
    var _y0 = _g.ytop + _wall_h * 0.38;
    var _rev = min(_x1 - _x0, _g.yback - _y0) * 0.075;

    draw_set_colour(variable_struct_get(_pal, "wall0"));
    draw_rectangle(_x0 - _rev, _y0 - _rev, _x1 + _rev, _g.yback, false);

    draw_set_colour(variable_struct_get(_pal, "beam2"));
    draw_rectangle(_x0, _y0, _x1, _g.yback, false);

    // Vertical planks: count carries the tone.
    draw_set_colour(variable_struct_get(_pal, "beam0"));
    var _n = 3;
    for (var _i = 1; _i < _n; _i++) {
        var _px = lerp(_x0, _x1, _i / _n);
        draw_line(_px, _y0, _px, _g.yback);
    }
    // Two ledges across, and the strap hinges over them. The hinge is the detail that says
    // "door" at any size, and at this size it is most of what says it.
    draw_set_colour(variable_struct_get(_pal, "beam3"));
    for (var _i = 0; _i < 2; _i++) {
        var _ly = lerp(_y0, _g.yback, 0.22 + 0.50 * _i);
        draw_rectangle(_x0, _ly, _x1, _ly + _wall_h * 0.016, false);
    }
    draw_set_colour(variable_struct_get(_pal, "iron2"));
    for (var _i = 0; _i < 2; _i++) {
        var _ly = lerp(_y0, _g.yback, 0.22 + 0.50 * _i);
        var _hx0 = _room.door_left ? _x1 - (_x1 - _x0) * 0.68 : _x0;
        var _hx1 = _room.door_left ? _x1 : _x0 + (_x1 - _x0) * 0.68;
        draw_rectangle(_hx0, _ly + _wall_h * 0.003, _hx1, _ly + _wall_h * 0.013, false);
    }
    // The ring handle, on the side away from the hinges.
    draw_set_colour(variable_struct_get(_pal, "iron3"));
    var _rx = _room.door_left ? (_x0 + (_x1 - _x0) * 0.24) : (_x1 - (_x1 - _x0) * 0.24);
    draw_circle(_rx, lerp(_y0, _g.yback, 0.50), _wall_h * 0.014, false);
    draw_set_colour(variable_struct_get(_pal, "beam1"));
    draw_circle(_rx, lerp(_y0, _g.yback, 0.50), _wall_h * 0.007, false);

    // The frame.
    draw_set_colour(variable_struct_get(_pal, "wood3"));
    draw_rectangle(_x0 - _rev, _y0 - _rev, _x0, _g.yback, false);
    draw_rectangle(_x1, _y0 - _rev, _x1 + _rev, _g.yback, false);
    draw_rectangle(_x0 - _rev, _y0 - _rev, _x1 + _rev, _y0, false);
}

/// The contact shadow a standing piece throws where it meets the floor.
///
/// ⚠️ IT IS AN ELLIPSE, IT IS SOFT, AND IT IS DRAWN BEFORE THE PIECE. Without it every object in
/// the room appears to hover a few pixels above the boards - which is precisely the first
/// failure the layout header lists, arriving from the drawing side instead of the geometric one.
/// A layout can be perfect and the picture still says the wardrobe is floating.
///
/// ⚠️ IT IS NARROWER AND FAINTER THAN THE FIRST VERSION, WHICH WAS MEASURED BY LOOKING. A shadow
/// as wide as the piece and a third as deep read as a dark PUDDLE the furniture was standing in -
/// worst on the wide low forms (a bed, a trestle, a bench), which are exactly the ones that need
/// it least because their own mass already meets the floor. A contact shadow's job is to stop a
/// piece hovering, and it does that at 0.9 of the width and a fifth of the alpha; past that it
/// stops being contact and starts being weather.
function hth_shell_contact(_x, _yfloor, _hw, _pal, _alpha) {
    var _a = is_undefined(_alpha) ? 0.20 : (_alpha * 0.55);
    draw_set_colour(_pal.shadow);
    for (var _i = 0; _i < 3; _i++) {
        var _k = 0.90 - _i * 0.26;
        draw_set_alpha(_a * (0.26 + 0.30 * _i));
        draw_ellipse(_x - _hw * _k, _yfloor - _hw * 0.11 * _k,
                     _x + _hw * _k, _yfloor + _hw * 0.11 * _k, false);
    }
    draw_set_alpha(1);
}
