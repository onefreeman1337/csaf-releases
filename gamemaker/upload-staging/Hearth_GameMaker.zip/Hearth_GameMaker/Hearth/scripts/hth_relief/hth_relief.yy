{
  "$GMScript": "v1",
  "%Name": "hth_relief",
  "isCompatibility": false,
  "isDnD": false,
  "name": "hth_relief",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}