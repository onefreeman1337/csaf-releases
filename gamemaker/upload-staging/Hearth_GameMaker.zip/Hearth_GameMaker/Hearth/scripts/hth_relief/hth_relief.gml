/// HEARTH - hth_relief. Part of the shared drawing foundation.
///
/// This file is the studio's cross-product drawing/colour layer, carried forward with more
/// than 2,300 in-engine assertions behind it - including the GML default-epsilon fix
/// described below, which had produced a suite of assertions that could never go red.
///
/// ⛔ GML APPLIES A DEFAULT EPSILON TO NUMERIC COMPARISONS, and it is 0.00001 on this runtime
/// - MEASURED by hth_selftest, which prints math_get_epsilon() into its own result file at
/// twelve decimals. Any tolerance at or below about 0.00001 can NEVER fire, in either
/// direction, so a distinctness assertion written that way passes vacuously forever and an
/// equality assertion written that way goes red on two values that are the same object.
/// Never write one here. And GML has no exponent-literal syntax at all: `1e-5` is a lexer
/// error that reads like a bracket bug.
///
/// Shade any outline by its own surface normal. This file is why a building looks like a
/// building and not like a rectangle with a triangle on top.
///
/// ⛔ MOST GENERATED ART DRAWS FLAT MASSES. This draws RELIEF, and the difference is one
/// idea: a closed outline is not a silhouette, it is the top of a raised shape, and the
/// little wall between the top and the field around it points a different way on every side.
/// Light that wall from a single lamp and the shape stops being a sticker.
///
/// ⛔ AND ARCHITECTURE IS THE CASE WHERE THIS IS THE WHOLE PRODUCT, NOT A GARNISH. A facade
/// built from GML primitives goes flat and boxy by default, and a flat facade reads as the
/// engine. An eave overhang is only an eave because of the shadow it throws on the wall
/// under it; a window is only recessed because its reveal is lit on one side and dark on the
/// other; a string course is only proud of the wall because its lower edge is dark. Every one
/// of those is this file, re-aimed. Relief is applied from the first render here, never
/// retrofitted.
///
/// ⭐ THE LAMP IS SETTABLE, AND IT DEFAULTS TO THE STUDIO'S FIXED DIAGONAL. Call nothing and
/// every mass in the package lights exactly as it does everywhere else in this catalogue. It
/// stays settable because a street lit at a chosen hour is a legitimate thing a buyer wants -
/// a game with a day cycle wants its west-facing terrace lit from the west at evening - and
/// removing a working capability during a port is a regression, not a simplification.
///
/// -- HOW A BEVEL IS BUILT --------------------------------------------------------------
/// Given a closed outline, walk it edge by edge. Each edge has an outward normal; the wall
/// under that edge is a quad running from the outline inward. Colour the quad from the
/// material's five-stop ramp by how squarely its normal faces the lamp, and the shape now
/// has a lit side and a shadowed side. Nest two or three of those walls at decreasing tilt
/// and the edge stops being a chamfer and becomes a dome.
/// ============================================================================================
#macro HTH_LX -0.7071067811865476
#macro HTH_LY -0.7071067811865476

/// ============================================================================================
/// THE LAMP
///
/// Set once, or once per frame if the buyer's game moves its light. Defaults to the studio's
/// fixed diagonal so that every wall, reveal, eave and cornice in the package lights the way
/// it always has.
///
/// ⚠️ THESE TWO LINES RUN AT GAME START, not on first use. GML executes top-level script code
/// once when the game boots, before the first room. hth_selftest asserts that it happened.
/// ============================================================================================
global.hth_lx = HTH_LX;
global.hth_ly = HTH_LY;

/// Point the lamp. _lx,_ly is a direction TOWARDS the light; it is normalised here so a caller
/// can hand in the difference between a light position and the building without thinking
/// about it.
///
/// ⛔ A ZERO VECTOR IS NOT AN ERROR AND MUST NOT BE ONE - a caller subtracting two positions
/// gets exactly zero the moment the light passes over the building, and throwing an exception
/// at that one frame is the worst possible failure mode. A zero length falls back to the
/// default diagonal.
function hth_lamp_set(_lx, _ly) {
    var _m = sqrt(_lx * _lx + _ly * _ly);
    if (_m < 0.0001) { global.hth_lx = HTH_LX; global.hth_ly = HTH_LY; return; }
    global.hth_lx = _lx / _m;
    global.hth_ly = _ly / _m;
}

/// Put the lamp back where the rest of the package expects it. Call after any hth_lamp_set and
/// before drawing anything you did not intend to relight, or a signboard will be lit from below.
function hth_lamp_reset() {
    global.hth_lx = HTH_LX;
    global.hth_ly = HTH_LY;
}

/// The five ramp roles, in order. Named here so nothing else in the package has to know that the
/// material ramp is five stops long.
#macro HTH_RAMP_N 5

/// ============================================================================================
/// OUTLINE GEOMETRY
/// ============================================================================================

/// Twice the signed area of a closed polygon. Sign tells us the winding, which tells us which of
/// the two perpendiculars points OUT.
///
/// ⚠️ THE PACKAGE DOES NOT REQUIRE A WINDING CONVENTION FROM ITS AUTHORS, AND THAT IS DELIBERATE.
/// Every form in the corpus is authored by hand; a rule that says "always list your points clockwise"
/// is a rule that will be broken silently, and the failure mode - a mark lit from the wrong side
/// while everything around it is lit correctly - is subtle enough to ship. Measuring the winding
/// costs one loop and makes the rule unnecessary.
function hth_area2(_pts) {
    var _n = array_length(_pts);
    if (_n < 3) return 0;
    var _s = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _pts[_i], _b = _pts[(_i + 1) % _n];
        _s += _a[0] * _b[1] - _b[0] * _a[1];
    }
    return _s;
}

/// The outward unit normal of the edge leaving vertex _i of a closed polygon.
function hth_edge_normal(_pts, _i, _sign) {
    var _n = array_length(_pts);
    var _a = _pts[_i], _b = _pts[(_i + 1) % _n];
    var _dx = _b[0] - _a[0], _dy = _b[1] - _a[1];
    var _len = point_distance(0, 0, _dx, _dy);
    if (_len == 0) return [0, 0];
    return [(_dy / _len) * _sign, (-_dx / _len) * _sign];
}

/// Move every vertex of a CLOSED polygon inward by _d along its averaged vertex normal.
///
/// Wraps at both ends, unlike the primitive layer's open-polyline offset. A ring whose first and
/// last vertices were offset one-sidedly develops a notch exactly where the seam is, and on a
/// circle - which is most of this product - the seam is at three o'clock, in plain view.
function hth_inset(_pts, _d, _sign) {
    var _n = array_length(_pts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _pts[(_i + _n - 1) % _n], _q = _pts[(_i + 1) % _n];
        var _dx = _q[0] - _p[0], _dy = _q[1] - _p[1];
        var _len = point_distance(0, 0, _dx, _dy);
        if (_len == 0) { _out[_i] = [_pts[_i][0], _pts[_i][1]]; continue; }
        var _nx = (_dy / _len) * _sign, _ny = (-_dx / _len) * _sign;
        _out[_i] = [_pts[_i][0] - _nx * _d, _pts[_i][1] - _ny * _d];
    }
    return _out;
}

/// The winding sign to pass to hth_edge_normal / hth_inset so that "normal" means OUTWARD.
function hth_out_sign(_pts) {
    return (hth_area2(_pts) > 0) ? 1 : -1;
}

/// Scale a closed outline about its own centroid. Used for nesting rings and for the recessed
/// field inside a mass - a window reveal, a sunk door panel, a blind arcade.
function hth_scale_pts(_pts, _k) {
    var _n = array_length(_pts);
    var _cx = 0, _cy = 0;
    for (var _i = 0; _i < _n; _i++) { _cx += _pts[_i][0]; _cy += _pts[_i][1]; }
    _cx /= _n; _cy /= _n;
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        _out[_i] = [_cx + (_pts[_i][0] - _cx) * _k, _cy + (_pts[_i][1] - _cy) * _k];
    }
    return _out;
}

/// Translate a closed outline.
function hth_move_pts(_pts, _dx, _dy) {
    var _n = array_length(_pts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) _out[_i] = [_pts[_i][0] + _dx, _pts[_i][1] + _dy];
    return _out;
}

/// ============================================================================================
/// THE RAMP LOOKUP
/// ============================================================================================

/// Which of the five material stops a wall with this outward normal shows.
///
/// _tilt is how far the wall leans away from the face: 1.0 is a vertical wall that swings across
/// the whole ramp, 0.0 is flat and always shows the face value. See the header for why nesting
/// rings at constant tilt draws a target.
///
/// ⚠️ THE BANDS ARE HARD, NOT INTERPOLATED, AND THAT IS THE CORRECT CHOICE HERE rather than a
/// limitation. Five discrete values around a rim is what a made coin photographs like, and it is
/// what makes the material readable - a continuous gradient would need hundreds of colours and would
/// average out to a flat disc at inventory size, which is precisely where the tier has to read.
function hth_relief_role(_nx, _ny, _tilt) {
    var _d = _nx * global.hth_lx + _ny * global.hth_ly;
    var _t = 0.5 + 0.5 * _d * _tilt;
    if (_t < 0.190) return "m0";
    if (_t < 0.385) return "m1";
    if (_t < 0.615) return "m2";
    if (_t < 0.810) return "m3";
    return "m4";
}

/// ============================================================================================
/// THE BEVEL
/// ============================================================================================

/// A domed wall running inward from a closed outline, as normal-shaded quads.
///
/// _b      how far in the wall reaches, in unit-box units
/// _steps  how many nested rings (1 = a flat chamfer, 3 = a convincing dome)
/// _invert true for a SUNKEN shape, where the wall faces inward and the lit side swaps
///
/// Each quad is [outer_i, outer_i+1, inner_i+1, inner_i] - convex, so the fan primitive draws it
/// correctly with no special casing.
function hth_bevel(_pts, _b, _steps, _invert) {
    var _n = array_length(_pts);
    var _out = [];
    if (_n < 3 || _b <= 0) return _out;
    var _st = max(1, _steps);
    var _sign = hth_out_sign(_pts) * (_invert ? -1 : 1);
    var _geo = hth_out_sign(_pts);

    var _rings = array_create(_st + 1);
    for (var _s = 0; _s <= _st; _s++) _rings[_s] = hth_inset(_pts, _b * (_s / _st), _geo);

    for (var _s = 0; _s < _st; _s++) {
        // Outer walls are steep, inner walls are nearly flat. 0.30 rather than 0 at the innermost
        // ring because a wall that shows exactly the face value is a wall you cannot see, and the
        // dome then ends in a visible step instead of easing into the field.
        var _tilt = lerp(1.0, 0.30, (_s + 0.5) / _st);
        var _a = _rings[_s], _c = _rings[_s + 1];
        for (var _i = 0; _i < _n; _i++) {
            var _k = (_i + 1) % _n;
            var _nm = hth_edge_normal(_pts, _i, _sign);
            array_push(_out, hth_fill([_a[_i], _a[_k], _c[_k], _c[_i]],
                                      hth_relief_role(_nm[0], _nm[1], _tilt)));
        }
    }
    return _out;
}

/// ============================================================================================
/// THE TWO COMPOSITES EVERYTHING ELSE IS BUILT FROM
/// ============================================================================================

/// A RAISED shape: a flat top at _face, walled all round by a lit dome.
///
/// ⛔ THE FACE IS DRAWN FIRST AND THE WALL SECOND, AND SWAPPING THEM COSTS THE WHOLE EFFECT. The
/// wall's inner ring and the face overlap by design - the fan that fills the face is star-shaped
/// about its centroid and cannot be trusted to land exactly on the wall's inner edge on a
/// concave outline, so the wall is painted over the face rather than butted against it. Drawn the
/// other way round, every concave mark grows a hairline of face colour outside its own bevel.
function hth_raise(_pts, _b, _steps, _face) {
    var _out = [hth_ring_fill(_pts, is_undefined(_face) ? "m2" : _face, undefined, undefined)];
    return hth_append(_out, hth_bevel(_pts, _b, _steps, false));
}

/// A SUNKEN shape: a recessed floor, walled by a dome lit from the opposite side.
function hth_sink(_pts, _b, _steps, _face) {
    var _out = [hth_ring_fill(_pts, is_undefined(_face) ? "m1" : _face, undefined, undefined)];
    return hth_append(_out, hth_bevel(_pts, _b, _steps, true));
}

/// ============================================================================================
/// STROKES - a line that is a groove, and a line that is a wire
/// ============================================================================================

/// An INCISED line: a groove cut into the metal.
///
/// Physically there are two walls. The one on the far side of the groove from the lamp faces the
/// lamp and is lit; the one on the near side is turned away and is dark. Offsetting one copy of
/// the stroke toward the lamp and darkening it, and one away and lightening it, is the whole trick
/// - and the order matters, because getting it backwards produces a line that reads as RAISED,
/// which is a real and useful effect and the wrong one here.
///
/// ⚠️ THE OFFSET IS A FRACTION OF THE STROKE WIDTH AND HAS A FLOOR IN THE RENDERER. hth_render
/// floors every stroke at 1 px, so at inventory size the three strokes of a groove collapse onto
/// each other and the groove becomes a plain line. That is correct behaviour and not a defect: a
/// groove 0.4 px wide is not visible on any monitor, and the alternative - scaling the offset up so
/// it survives - would draw a groove three pixels wide on a form twenty pixels across.
function hth_incise(_pts, _closed, _w) {
    var _o = _w * 0.55;
    return [
        hth_poly(hth_shift(_pts, HTH_LX * _o, HTH_LY * _o), _closed, _w, "m0"),
        hth_poly(hth_shift(_pts, -HTH_LX * _o, -HTH_LY * _o), _closed, _w, "m3"),
        hth_poly(_pts, _closed, _w * 0.8, "m1")
    ];
}

/// A RAISED line: a wire laid on the field. The same three strokes with the two walls swapped.
function hth_ridge(_pts, _closed, _w) {
    var _o = _w * 0.55;
    return [
        hth_poly(hth_shift(_pts, -HTH_LX * _o, -HTH_LY * _o), _closed, _w, "m0"),
        hth_poly(hth_shift(_pts, HTH_LX * _o, HTH_LY * _o), _closed, _w, "m4"),
        hth_poly(_pts, _closed, _w * 0.8, "m3")
    ];
}

/// Translate a polyline. Separate from hth_move_pts only so that reading a call site tells you
/// whether the thing being moved is an outline or a stroke path.
function hth_shift(_pts, _dx, _dy) {
    return hth_move_pts(_pts, _dx, _dy);
}

/// ============================================================================================
/// SMALL RAISED FURNITURE
/// ============================================================================================

/// A raised dome - a door stud, a rivet head, a boss on a strap hinge, a cobble.
///
/// Sampled at 12 points at the size these are used, which is 3 to 10 px on screen; a smoother
/// circle is invisible and this product draws a lot of them (a studded carriage door carries 48
/// of these, and a paved street in front of a row can hold several hundred).
function hth_boss(_cx, _cy, _r, _segs) {
    var _n = is_undefined(_segs) ? 12 : _segs;
    var _pts = hth_ellipse_pts(_cx, _cy, _r, _r, _n);
    return hth_raise(_pts, _r * 0.62, 2, "m3");
}

/// A sunken pit - a punch mark, a countersink.
function hth_pit(_cx, _cy, _r, _segs) {
    var _n = is_undefined(_segs) ? 12 : _segs;
    var _pts = hth_ellipse_pts(_cx, _cy, _r, _r, _n);
    return hth_sink(_pts, _r * 0.62, 2, "m1");
}

/// ============================================================================================
/// UI FURNITURE - the same relief engine, pointed at a rectangle
///
/// The settlement readout and the demo room's panels are made of the same light as the walls
/// themselves, and they are bevelled by the same function against the same lamp. That is the whole
/// reason the product's interface does not look like a GameMaker default: there is no windowskin
/// here and no nine-slice, only a rounded outline handed to hth_bevel.
/// ============================================================================================

/// A rounded rectangle as a closed outline. _seg is the points per corner.
///
/// ⛔ THE CORNERS ARE WALKED TOP-RIGHT, BOTTOM-RIGHT, BOTTOM-LEFT, TOP-LEFT, AND THE FIRST VERSION
/// WALKED THEM TR, TL, BL, BR. MEASURED 2026-08-25 in this studio's shared layer by opening a store sheet and looking at
/// it: every panel, well and progress bar in the product had little hooks at its corners, a bright
/// bar across it, and no proper fill.
///
/// The order is not cosmetic. Each corner arc ENDS pointing at where the next one must BEGIN - the
/// top-right arc finishes on the right edge, so the next corner has to be the bottom-right. Walked
/// TR then TL, the outline jumps back across the top of the rectangle, the polygon self-intersects
/// into a bowtie, and two things go wrong at once: the fan fill covers the wrong region, and
/// hth_inset - which offsets along vertex normals - throws points a long way outside the shape,
/// which is why the ink check reported the sheet clipped at x=0 when nothing was drawn there.
///
/// ⚠️ AND NOTHING MECHANICAL CAUGHT IT. The gate compiled, 711 assertions passed, the containment
/// checks passed because they test the form corpus rather than the UI furniture, and the ink check
/// reported "clipped" - true, but pointing at a symptom two steps downstream. It was found by
/// opening the PNG, which remains the only way.
function hth_round_rect_pts(_x0, _y0, _x1, _y1, _r, _seg) {
    var _s = max(1, is_undefined(_seg) ? 4 : _seg);
    var _rr = min(_r, min(abs(_x1 - _x0), abs(_y1 - _y0)) * 0.5);
    var _out = [];
    var _cx = [_x1 - _rr, _x1 - _rr, _x0 + _rr, _x0 + _rr];
    var _cy = [_y0 + _rr, _y1 - _rr, _y1 - _rr, _y0 + _rr];
    var _a0 = [-HTH_TAU * 0.25, 0, HTH_TAU * 0.25, HTH_TAU * 0.5];
    for (var _c = 0; _c < 4; _c++) {
        for (var _i = 0; _i <= _s; _i++) {
            var _a = _a0[_c] + (_i / _s) * (HTH_TAU * 0.25);
            array_push(_out, [_cx[_c] + cos(_a) * _rr, _cy[_c] + sin(_a) * _rr]);
        }
    }
    return _out;
}

/// A raised panel: a rounded rectangle with a lit dome all round it.
function hth_ui_panel(_x0, _y0, _x1, _y1, _r, _b, _face) {
    return hth_raise(hth_round_rect_pts(_x0, _y0, _x1, _y1, _r, 4), _b, 3,
                     is_undefined(_face) ? "panel" : _face);
}

/// A sunken well - a recess a form sits in, or a progress track.
function hth_ui_well(_x0, _y0, _x1, _y1, _r, _b, _face) {
    return hth_sink(hth_round_rect_pts(_x0, _y0, _x1, _y1, _r, 4), _b, 2,
                    is_undefined(_face) ? "felt" : _face);
}

/// ============================================================================================
/// PART-LIST UTILITIES
/// ============================================================================================

/// Translate a whole part list. Used by the shadow an eave casts onto the wall below it, and by
/// the shadow the whole building casts onto the street.
function hth_offset_parts(_parts, _dx, _dy) {
    var _n = array_length(_parts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _parts[_i];
        switch (_p.kind) {
            case HTH_DOT: _out[_i] = hth_dot(_p.cx + _dx, _p.cy + _dy, _p.r, _p.role); break;
            case HTH_ARC: _out[_i] = hth_arc(_p.cx + _dx, _p.cy + _dy, _p.r, _p.a0, _p.a1,
                                             _p.w, _p.role); break;
            case HTH_STRIP: {
                _out[_i] = hth_strip(hth_move_pts(_p.a, _dx, _dy),
                                     hth_move_pts(_p.b, _dx, _dy), _p.role);
            } break;
            case HTH_FILL: _out[_i] = hth_fill(hth_move_pts(_p.pts, _dx, _dy), _p.role); break;
            default: _out[_i] = hth_poly(hth_move_pts(_p.pts, _dx, _dy), _p.closed,
                                         _p.w, _p.role); break;
        }
    }
    return _out;
}

/// Rewrite every role in a part list through a lookup struct, permanently.
///
/// ⚠️ NOT THE SAME AS THE RENDERER'S role map, and both exist on purpose. The renderer's map is
/// applied at DRAW time and is right for "draw this mark in the locked palette just this once".
/// This one produces a new part list and is right for building a thing whose roles are decided at
/// construction - a wall, whose material and weathering stops are chosen when the building is
/// created and then never change for as long as it stands.
/// ⛔ IT ACCEPTS A SINGLE PART AS WELL AS A LIST, AND THAT IS A FIX, NOT A CONVENIENCE.
///
/// MEASURED 2026-08-28, first headless run of this product. Most of the constructors in this layer
/// return a LIST (hth_raise, hth_sink, hth_bevel, hth_incise, hth_ridge) but three return ONE PART
/// (hth_ring_fill, hth_dot, hth_ring), and the two are indistinguishable at a call site. Handed a
/// single part, `array_length` gave 0 and this function returned an EMPTY LIST - so the caller's
/// mark was silently DELETED FROM THE PICTURE with no error, no warning and nothing to grep for.
///
/// Two call sites had it: a dormer's gablet and a door's timber leaf. The door leaf is the largest
/// single mark on a facade. It surfaced only because the empty list was then pushed as if it were a
/// part and hth_render_bounds tried to `switch` on an array - a type error two steps downstream of
/// a defect that was otherwise perfectly silent, and the wing's own catalogue is full of exactly
/// this shape. Wrapping here removes the trap for every future call site instead of documenting it.
function hth_map_roles(_parts_in, _map) {
    var _parts = is_array(_parts_in) ? _parts_in : [_parts_in];
    var _n = array_length(_parts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _parts[_i];
        var _r = variable_struct_exists(_map, _p.role) ? variable_struct_get(_map, _p.role) : _p.role;
        switch (_p.kind) {
            case HTH_DOT: _out[_i] = hth_dot(_p.cx, _p.cy, _p.r, _r); break;
            case HTH_ARC: _out[_i] = hth_arc(_p.cx, _p.cy, _p.r, _p.a0, _p.a1, _p.w, _r); break;
            case HTH_STRIP: _out[_i] = hth_strip(_p.a, _p.b, _r); break;
            case HTH_FILL: _out[_i] = hth_fill(_p.pts, _r); break;
            default: _out[_i] = hth_poly(_p.pts, _p.closed, _p.w, _r); break;
        }
    }
    return _out;
}

/// Every distinct role a part list asks for, as an array of strings.
///
/// Exists for hth_selftest, which asserts that no part in the whole product ever asks for a role
/// the surface does not carry. The renderer falls back to `line` on a miss - loudly wrong rather
/// than invisible - and that fallback is a diagnostic, not a licence to leave one in.
function hth_roles_used(_parts) {
    var _seen = {};
    var _out = [];
    for (var _i = 0; _i < array_length(_parts); _i++) {
        var _r = _parts[_i].role;
        if (!variable_struct_exists(_seen, _r)) {
            variable_struct_set(_seen, _r, true);
            array_push(_out, _r);
        }
    }
    return _out;
}
