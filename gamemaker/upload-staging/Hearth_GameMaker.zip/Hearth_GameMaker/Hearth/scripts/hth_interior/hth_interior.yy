{
  "$GMScript": "v1",
  "%Name": "hth_interior",
  "isCompatibility": false,
  "isDnD": false,
  "name": "hth_interior",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}