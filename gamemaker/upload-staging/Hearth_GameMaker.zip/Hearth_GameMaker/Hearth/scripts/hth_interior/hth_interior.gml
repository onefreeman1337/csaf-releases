/// HEARTH - hth_interior. The one call a buyer makes, and the order everything is drawn in.
///
/// -- THE PUBLIC API, ENTIRE -------------------------------------------------------------------
///
///     hth_room_create(seed)                        the state struct, everything seeded
///     hth_room_of(purpose, occupant, seed)         the call this product is named for
///     hth_room_derive(room)                        ⛔ after ANY direct field assignment
///     hth_room_furnish(room, x, y, w, h)           solve and assert the layout
///     hth_palette_build(room)                      the material ramps for this room's state
///     hth_room_draw(room, pal, x, y, w, h)         draw it, inside the rect it is given
///     hth_item_draw(form, room, pal, x, y, s)      one piece of furniture, on its own
///
/// Six functions and a state struct. Everything else in the package is machinery a buyer never
/// has to name, and that is deliberate: a generator whose API is forty functions is a generator
/// a buyer configures instead of using.
///
/// -- THE ORDER, AND WHY IT IS NOT NEGOTIABLE --------------------------------------------------
/// 1  wall           the flat field, its coursing, its skirting
/// 2  ceiling        the band and, in timber regions, the joists
/// 3  window + door  openings in the wall, recessed, before anything stands in front of them
/// 4  daylight       the shaft from the window, so furniture is lit BY it rather than over it
/// 5  floor          the receding plane
/// 6  firelight pool on the floor, under everything that stands on the floor
/// 7  rugs           lying flat
/// 8  hung pieces    shelves, racks, lamps - ON the wall, so furniture can stand in front
/// 9  wall band      furniture against the back wall, each with its contact shadow first
/// 10 free band      furniture out on the floor, drawn larger
/// 11 clutter        the occupant's objects, on the surfaces and on the boards
/// 12 vignette       the dark the light does not reach
/// 13 glow           the fire's own halo, painted last and brightest
///
/// ⛔ THE CONTACT SHADOW IS DRAWN BEFORE ITS OWN PIECE AND AFTER THE PIECE BEHIND IT. Drawn after
/// its own piece it paints a grey band across the piece's feet; drawn before everything it lands
/// under the wrong furniture. It belongs in the gap, and that is why the two bands are separate
/// loops rather than one sorted pass.
///
/// ⚠️ AND A ROOM IS BUILT ONCE, NOT PER FRAME. hth_room_furnish solves the layout and
/// hth_form_build assembles the geometry; a busy room is a few thousand triangles and there is
/// no reason to rebuild it sixty times a second. A buyer who wants it free should render it into
/// a sprite once with hth_render_to_sprite and blit that - the readme says so, and the demo
/// object does it.
/// ============================================================================================

/// Draw one placed piece, with its contact shadow.
function hth_interior_piece(_it, _room, _pal, _geom) {
    var _s     = hth_band_scale(_geom, _it.band);
    var _floor = hth_band_floor(_geom, _it.band);
    var _cx    = _geom.x + _geom.w * _it.x;
    // The unit box's floor line is HTH_GROUND, so the box centre sits that far ABOVE the floor.
    var _cy    = _floor - HTH_GROUND * _s;

    if (_it.band != "hung" && _it.band != "floor") {
        hth_shell_contact(_cx, _floor, _it.hw * _geom.w, _pal, 0.40);
    }

    var _parts = hth_form_build(_it.form, _room, _room.seed + hth_hash32(_it.form));
    hth_render_parts(_parts, _pal, _cx, _cy, _s, 0, _s, undefined);
}

/// Draw a hung piece. Its FIXING is on HTH_GROUND in the unit box, so it is placed by the point
/// that touches the wall - and then lifted to the height a shelf or a lamp actually hangs at.
function hth_interior_hung(_it, _room, _pal, _geom) {
    var _s  = _geom.swall;
    var _cx = _geom.x + _geom.w * _it.x;
    var _wall_h = _geom.yback - _geom.ytop;
    // A shelf and a rack hang at chest height; a lamp hangs from the ceiling.
    var _hang = (_it.form == "lamp") ? 0.80 : 0.46;
    var _cy = (_geom.yback - _wall_h * _hang) - HTH_GROUND * _s;

    var _parts = hth_form_build(_it.form, _room, _room.seed + hth_hash32("hung" + _it.form));
    hth_render_parts(_parts, _pal, _cx, _cy, _s, 0, _s, undefined);
}

/// Draw the whole room inside the rect it is given.
///
/// ⛔ IT STAYS INSIDE THAT RECT. A public draw call that takes a rect and then draws outside it
/// paints over whatever sits beside it in the buyer's game, and this wing has shipped exactly
/// that - a rainbow that bled out of the sky rect it was handed and into the neighbouring cell.
/// hth_selftest measures the ink of a rendered room against its own rect and requires it inside.
/// ⛔ REFUSES SILENTLY (draws nothing and returns) RATHER THAN CRASHING. This is a DRAW call, so
/// there is no return value a caller could check and no refusal value worth inventing: the honest
/// behaviour for bad input is to draw nothing. Guard pass 2026-09-08, after the adversarial harness
/// measured this taking the room down on undefined, on a negative number, on 4096 and on a string.
function hth_room_draw(_room, _pal, _x, _y, _w, _h) {
    if (!is_struct(_room) || !is_struct(_pal)) return;
    if (!is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_h)) return;
    // Furnish on demand, so a buyer can call draw without having called furnish. Re-furnishing an
    // already-furnished room at the same rect would be wasted work, so it is skipped.
    if (!variable_struct_exists(_room, "layout")
     || _room.layout.geom.w != _w || _room.layout.geom.h != _h
     || _room.layout.geom.x != _x || _room.layout.geom.y != _y) {
        hth_room_furnish(_room, _x, _y, _w, _h);
    }
    var _geom = _room.layout.geom;
    var _lay  = _room.layout;

    hth_shell_wall(_geom, _room, _pal);
    hth_shell_ceiling(_geom, _room, _pal);
    hth_shell_window(_geom, _room, _pal);
    hth_shell_door(_geom, _room, _pal);
    hth_light_day(_geom, _room, _pal);
    hth_shell_floor(_geom, _room, _pal);
    hth_light_pool(_geom, _room, _pal);

    for (var _i = 0; _i < array_length(_lay.rugs); _i++) {
        var _r = _lay.rugs[_i];
        var _s = _geom.sfree;
        hth_render_parts(hth_form_build(_r.form, _room, _room.seed + 7), _pal,
                         _geom.x + _geom.w * _r.x,
                         _geom.yfront - (_geom.yfront - _geom.yback) * 0.34 - HTH_GROUND * _s,
                         _s, 0, _s, undefined);
    }

    for (var _i = 0; _i < array_length(_lay.hung); _i++) {
        hth_interior_hung(_lay.hung[_i], _room, _pal, _geom);
    }

    for (var _i = 0; _i < array_length(_lay.items); _i++) {
        if (_lay.items[_i].band != "wall") continue;
        hth_interior_piece(_lay.items[_i], _room, _pal, _geom);
    }
    for (var _i = 0; _i < array_length(_lay.items); _i++) {
        if (_lay.items[_i].band != "free") continue;
        hth_interior_piece(_lay.items[_i], _room, _pal, _geom);
    }

    var _clut = hth_clutter_solve(_room, _geom);
    for (var _i = 0; _i < array_length(_clut); _i++) {
        var _c = _clut[_i];
        var _parts = hth_clutter_build(_c.form, _room, _room.seed + _i * 31 + 5);
        hth_render_parts(_parts, _pal, _c.x, _c.y - HTH_GROUND * _c.s, _c.s, 0, _c.s, undefined);
    }

    hth_light_vignette(_geom, _room, _pal);
    hth_light_glow(_geom, _room, _pal);
}

/// Every part a room is made of, as ONE list, without drawing any of it.
///
/// ⭐ THIS IS WHAT MAKES THE PRODUCT TESTABLE AT ALL. GML cannot be unit-tested outside the
/// engine, so the compensation is that the geometry can be produced and measured without a
/// single draw call: the suite builds a room, walks its parts, and asserts convexity, extent,
/// role resolution and distinctness on the DATA. Only the flat shell and the light washes are
/// unreachable this way, and both are simple rectangles.
///
/// ⚠️ IT IS ALSO WHAT A BUYER USES TO BAKE A ROOM INTO A SPRITE, so the two purposes keep each
/// other honest: if this list ever stopped matching what hth_room_draw actually draws, the demo
/// would go visibly wrong.
function hth_room_parts(_room, _geom) {
    var _out = [];
    var _lay = _room.layout;

    for (var _i = 0; _i < array_length(_lay.rugs); _i++) {
        var _r = _lay.rugs[_i];
        _out = hth_append(_out, hth_place(hth_form_build(_r.form, _room, _room.seed + 7),
                                          _geom.x + _geom.w * _r.x,
                                          _geom.yfront - HTH_GROUND * _geom.sfree,
                                          _geom.sfree, 0, _geom.sfree, undefined));
    }
    for (var _i = 0; _i < array_length(_lay.hung); _i++) {
        var _it = _lay.hung[_i];
        var _wall_h = _geom.yback - _geom.ytop;
        var _hang = (_it.form == "lamp") ? 0.80 : 0.46;
        _out = hth_append(_out, hth_place(
            hth_form_build(_it.form, _room, _room.seed + hth_hash32("hung" + _it.form)),
            _geom.x + _geom.w * _it.x,
            (_geom.yback - _wall_h * _hang) - HTH_GROUND * _geom.swall,
            _geom.swall, 0, _geom.swall, undefined));
    }
    for (var _i = 0; _i < array_length(_lay.items); _i++) {
        var _it2 = _lay.items[_i];
        var _s = hth_band_scale(_geom, _it2.band);
        _out = hth_append(_out, hth_place(
            hth_form_build(_it2.form, _room, _room.seed + hth_hash32(_it2.form)),
            _geom.x + _geom.w * _it2.x,
            hth_band_floor(_geom, _it2.band) - HTH_GROUND * _s,
            _s, 0, _s, undefined));
    }
    var _clut = hth_clutter_solve(_room, _geom);
    for (var _i = 0; _i < array_length(_clut); _i++) {
        var _c = _clut[_i];
        _out = hth_append(_out, hth_place(
            hth_clutter_build(_c.form, _room, _room.seed + _i * 31 + 5),
            _c.x, _c.y - HTH_GROUND * _c.s, _c.s, 0, _c.s, undefined));
    }
    return _out;
}

/// A one-line summary of what a room came out as, for the demo's overlay and the store sheets.
function hth_room_describe(_room) {
    var _lay = _room.layout;
    var _n = array_length(_lay.items) + array_length(_lay.hung) + array_length(_lay.rugs);
    return hth_room_label(_room) + "  -  " + string(_n) + " pieces  -  "
         + _room.region + "  -  " + (_room.fire_lit ? "fire lit" : "hearth cold");
}
