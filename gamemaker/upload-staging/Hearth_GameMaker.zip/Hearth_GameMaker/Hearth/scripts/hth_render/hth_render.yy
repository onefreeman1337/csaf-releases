{
  "$GMScript": "v1",
  "%Name": "hth_render",
  "isCompatibility": false,
  "isDnD": false,
  "name": "hth_render",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}