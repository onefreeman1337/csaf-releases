/// HEARTH - hth_light. The light a room makes, and the dark it does not reach.
///
/// ⛔ THIS IS THE ONE FILE THAT MAY BREAK THE LAMP RULE, AND IT BREAKS IT ON PURPOSE. Everything
/// else in the package is shaded by one fixed diagonal lamp, which is what lets a bed authored
/// today and a chest authored last week stand in the same room without arguing. But a room with
/// a fire in it has a SECOND light, in the picture, at a known position - and the whole reason
/// `warmth` is a field is that a lit hearth and a dead one are different rooms. So the fire is
/// painted as a WASH over the finished picture rather than as a second shading model: the relief
/// stays consistent, and the warmth sits on top of it.
///
/// ⛔ PAINTER'S ORDER IS NOT A DETAIL WHEN THE LAYERS ARE TRANSLUCENT - IT IS THE GRADIENT. A
/// glow drawn smallest-disc-first has every dim outer disc painted over the bright core and
/// flattens to a uniform donut. Largest first, brightest last, every time. This wing has already
/// shipped the donut once.
///
/// ⚠️ AND THE WASH IS NOT VERY SATURATED. A strongly coloured overlay turns a room into a filter
/// effect and destroys every material distinction underneath it - the pewter and the linen and
/// the limewash all become the same orange. `firelight` is chroma 0.075, which is about a
/// quarter of what the flame itself is drawn at, and that difference is deliberate.
/// ============================================================================================

/// Where the room's own light comes from, in world coordinates, or undefined if nothing burns.
///
/// A hearth beats a stove beats a lamp beats a candle. The order matters because a kitchen with
/// a fire AND a hanging lamp should throw its light from the fire, which is bigger, lower and
/// warmer, and getting that backwards puts the room's shadows in the wrong direction.
function hth_light_source(_room, _geom) {
    var _lay = _room.layout;
    if (!_room.fire_lit && _room.warmth <= 0.30) return undefined;

    if (_room.fire_lit) {
        for (var _i = 0; _i < array_length(_lay.items); _i++) {
            var _it = _lay.items[_i];
            if (_it.form != "hearth" && _it.form != "stove") continue;
            var _s = hth_band_scale(_geom, _it.band);
            var _e = hth_form_extent(_it.form);
            return {
                x: _geom.x + _geom.w * _it.x,
                y: hth_band_floor(_geom, _it.band) - _e.h * _s * 0.28,
                // ⛔ BOUNDED BY THE ROOM'S HEIGHT AS WELL AS ITS WIDTH. A fire's reach is a
                // physical distance; 0.62 of the WIDTH alone made a wide hero room sit entirely
                // at peak glow, and every material in it flattened toward one warm grey.
                r: min(_geom.w * 0.62, _geom.h * 1.05),
                strength: 0.55 + 0.45 * _room.warmth,
            };
        }
    }
    for (var _i = 0; _i < array_length(_lay.hung); _i++) {
        var _it = _lay.hung[_i];
        if (_it.form != "lamp") continue;
        var _e2 = hth_form_extent("lamp");
        return {
            x: _geom.x + _geom.w * _it.x,
            y: _geom.yback - _e2.h * _geom.swall * 0.62,
            r: min(_geom.w * 0.42, _geom.h * 0.80),
            strength: 0.30 + 0.30 * _room.warmth,
        };
    }
    return undefined;
}

/// ⛔ THE BOXES THE TWO WASHES DRAW INTO, CLAMPED TO THE ROOM RECT, COMPUTED IN ONE PLACE.
///
/// The glow's radius is a fraction of the room's WIDTH, so on a wide shallow room it is far taller
/// than the room - measured on the solver sheet, where a 1520x470 room threw an ellipse 1357
/// pixels across and painted hundreds of pixels of warm light onto the page above and below it.
/// In a buyer's game that is light spilled over whatever sits next to the room.
///
/// ⭐ IT IS A SEPARATE FUNCTION SO THE SUITE CAN ASSERT IT. The washes are direct draw calls and
/// emit no geometry, so STAGE 8's containment check - which walks hth_room_parts - could never
/// have seen this failure however many rects it was given. Testing the CONTRACT a renderer
/// documents, when the picture itself is unreachable, is the same move this wing made for the
/// triangle fan's star-shaped precondition.
function hth_light_boxes(_geom, _room) {
    var _src = hth_light_source(_room, _geom);
    if (is_undefined(_src)) return undefined;
    var _g = _geom;
    var _gr = _src.r * 0.62;
    return {
        glow: [max(_g.x, _src.x - _gr), max(_g.y, _src.y - _gr),
               min(_g.x + _g.w, _src.x + _gr), min(_g.y + _g.h, _src.y + _gr)],
        pool: [max(_g.x, _src.x - _src.r), max(_g.y, _g.yback - _src.r * 0.16),
               min(_g.x + _g.w, _src.x + _src.r), min(_g.y + _g.h, _g.yfront + _src.r * 0.10)],
        strength: _src.strength,
    };
}

/// The pool of light the fire throws on the floor in front of it.
///
/// Drawn AFTER the floor and BEFORE anything stands on it, so furniture casts its contact shadow
/// over the pool rather than the pool washing over the furniture's feet. That ordering is the
/// difference between a room lit by a fire and a room with an orange circle painted on it.
function hth_light_pool(_geom, _room, _pal) {
    var _src = hth_light_source(_room, _geom);
    if (is_undefined(_src)) return;

    // ⛔ ONE GRADIENT, NOT FIVE DISCS. Nested translucent discs are visible STEPS, and on a flat
    // floor five of them read as five rings - which is precisely the banding artefact this file's
    // vignette comment warns about, arriving through the pool instead. draw_ellipse_colour
    // interpolates between a centre and an edge colour, and under additive blend BLACK IS THE
    // IDENTITY, so an ellipse from firelight to black is a true radial falloff with nothing to
    // band. It is also one draw call instead of five.
    var _b = hth_light_boxes(_geom, _room);
    if (is_undefined(_b)) return;
    gpu_set_blendmode(bm_add);
    draw_set_alpha(0.24 * _b.strength);
    draw_ellipse_colour(_b.pool[0], _b.pool[1], _b.pool[2], _b.pool[3],
                        _pal.firelight, c_black, false);
    draw_set_alpha(1);
    gpu_set_blendmode(bm_normal);
}

/// The glow around the source itself, painted over the finished room.
function hth_light_glow(_geom, _room, _pal) {
    var _src = hth_light_source(_room, _geom);
    if (is_undefined(_src)) return;

    // Same as the pool: one radial gradient rather than seven nested discs, which painted seven
    // visible arcs across every wall in the first bake. Clamped to the rect, and at 0.17 rather
    // than 0.30 - at a third of an additive pass over a whole room every material underneath it
    // flattens into the same orange, which is the filter effect this file's header warns about.
    var _b = hth_light_boxes(_geom, _room);
    if (is_undefined(_b)) return;
    gpu_set_blendmode(bm_add);
    draw_set_alpha(0.17 * _b.strength);
    draw_ellipse_colour(_b.glow[0], _b.glow[1], _b.glow[2], _b.glow[3],
                        _pal.firelight, c_black, false);
    draw_set_alpha(1);
    gpu_set_blendmode(bm_normal);
}

/// The dark the light does not reach: a scrim that deepens with distance from the source, and
/// deepens everywhere in a cold room.
///
/// ⚠️ IT IS DRAWN AS FOUR EDGE BANDS, NOT AS A RADIAL DARKENING. GameMaker has no cheap radial
/// alpha primitive without a surface, and faking one with concentric filled circles at low alpha
/// gives visible banding on a flat wall - the exact artefact that says "generated". Four graded
/// bands off the edges of the rect read as a room falling away into its corners, cost four
/// gradient rectangles, and never band.
function hth_light_vignette(_geom, _room, _pal) {
    var _g = _geom;
    var _src = hth_light_source(_room, _g);
    // A cold, dead room is darker overall AND more even, because there is nothing in it making a
    // gradient. A lit room is brighter in the middle and much darker at the edges.
    var _base = is_undefined(_src) ? 0.30 : 0.16;
    var _edge = is_undefined(_src) ? 0.34 : 0.52;

    var _c = _pal.shadow;
    var _bw = _g.w * 0.22;
    var _bh = _g.h * 0.20;

    // Each band is a short run of strips, because GameMaker has no per-vertex ALPHA on
    // draw_rectangle_colour - only per-vertex colour, which would tint rather than darken.
    hth_light_band(_g.x, _g.y, _bw, _g.h, _c, _edge, _base, true, false);
    hth_light_band(_g.x + _g.w - _bw, _g.y, _bw, _g.h, _c, _base, _edge, true, false);
    hth_light_band(_g.x, _g.y, _g.w, _bh, _c, _edge, _base, false, true);
    hth_light_band(_g.x, _g.y + _g.h - _bh, _g.w, _bh, _c, _base, _edge, false, true);
    draw_set_alpha(1);
}

/// One graded band of darkness. _horizontal ramps left-to-right, _vertical top-to-bottom.
function hth_light_band(_x, _y, _w, _h, _col, _a0, _a1, _horizontal, _vertical) {
    // 24, not 12. At twelve steps the alpha increment is about five levels of 255 and the bands
    // are visible as stripes down the side of every room; at twenty-four it is two, which is at
    // the limit of what an 8-bit channel can show.
    var _steps = 24;
    draw_set_colour(_col);
    for (var _i = 0; _i < _steps; _i++) {
        var _t0 = _i / _steps, _t1 = (_i + 1) / _steps;
        draw_set_alpha(lerp(_a0, _a1, (_t0 + _t1) * 0.5) * 0.5);
        if (_horizontal) {
            draw_rectangle(_x + _w * _t0, _y, _x + _w * _t1, _y + _h, false);
        } else if (_vertical) {
            draw_rectangle(_x, _y + _h * _t0, _x + _w, _y + _h * _t1, false);
        }
    }
    draw_set_alpha(1);
}

/// Daylight through the window, as a shaft falling on the wall and floor below it.
///
/// ⛔ IT IS DRAWN BEFORE THE FURNITURE AND IT IS A QUADRILATERAL, NOT A CONE. A cone of light
/// implies a point source; a window is an aperture, so its shaft has parallel sides that spread
/// only by the angle of the sun. Getting that wrong makes the window look like a lamp.
function hth_light_day(_geom, _room, _pal) {
    if (!_room.layout.has_window) return;
    var _g = _geom;
    var _cx = _g.x + _g.w * _room.layout.window_x;
    var _hw = _g.w * _room.layout.window_hw;
    var _wall_h = _g.yback - _g.ytop;
    var _y1 = _g.yback - _wall_h * HTH_SILL;

    // The shaft leans in the direction the fixed lamp comes from, so the daylight and the relief
    // shading agree about where the sun is. That agreement is free and its absence is glaring.
    var _lean = _g.w * 0.16 * ((global.hth_lx < 0) ? 1 : -1);

    // The shaft is a single quad with per-vertex colour: bright where it leaves the window and
    // black - the additive identity - where it reaches the floor. Four stacked flat quads at low
    // alpha were three visible edges down the middle of the room.
    // ⛔ draw_vertex_colour CARRIES ITS OWN ALPHA AND IGNORES draw_set_alpha. Written with a
    // per-vertex alpha of 1 under draw_set_alpha(0.16), this quad drew at FULL additive strength
    // and put an opaque white slab across two of the four rooms on the hero sheet. The alpha
    // belongs in the vertex call, and the fade to nothing at the floor is an ALPHA fade rather
    // than a fade to black - black is the additive identity, but fading the alpha is what makes
    // the shaft disappear into the boards instead of into a dark smear.
    gpu_set_blendmode(bm_add);
    draw_primitive_begin(pr_trianglefan);
    draw_vertex_colour(_cx - _hw * 1.05,         _y1,        _pal.lamplight, 0.17);
    draw_vertex_colour(_cx + _hw * 1.05,         _y1,        _pal.lamplight, 0.17);
    draw_vertex_colour(_cx + _hw * 1.35 + _lean, _g.yfront,  _pal.lamplight, 0.00);
    draw_vertex_colour(_cx - _hw * 1.35 + _lean, _g.yfront,  _pal.lamplight, 0.00);
    draw_primitive_end();
    gpu_set_blendmode(bm_normal);
}
