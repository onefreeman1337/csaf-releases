/// HEARTH - hth_bake. The store gallery, rendered by the product itself.
///
/// Hearth.exe -bake writes every store sheet from the SHIPPED GML, using the product's own
/// palettes, its own fonts and its own public draw calls. Internal_Ops/run_engine.ps1 drives it
/// through gm_gate.ps1 and collects the PNGs.
///
/// ⛔ A GALLERY RENDERED BY A SIDE PREVIEWER IS A PICTURE OF A RE-IMPLEMENTATION. A sibling
/// product in this wing had a defect that was invisible in its JavaScript previewer and plainly
/// visible in engine. Baking is what lets the listing say, truthfully, that every image on the
/// page was rendered by the product a buyer is about to download.
///
/// -- WHAT THE CONTENT CHECK CAN AND CANNOT SEE -------------------------------------------------
/// It measures the fraction of ROWS carrying something other than that row's own leftmost pixel.
///
/// ⛔ AND IT IS BLIND IN THE ONE DIRECTION THAT MATTERS MOST: A BOUNDING BOX CANNOT SEE THE SPACE
/// INSIDE ITSELF. Three small rooms adrift on a wide page score well and look like nothing. The
/// floor catches EMPTY and CLIPPED; it cannot catch SPARSE at any threshold, and the answer to a
/// sparse sheet is more content, never a lower number. The only instrument for that is opening
/// the PNG and looking at it, and that is a required step of every publish in this wing.
///
/// ⚠️ DO NOT ADD LEADER RULES OR HAIRLINE DIVIDERS TO MAKE A SHEET LOOK FINISHED. One hairline
/// per row turns the coverage floor back into decoration and the check stops meaning anything.
/// ============================================================================================

/// Rows must be this fraction non-uniform for a sheet to pass.
/// ⚠️ REPORTED BESIDE ITS MEASUREMENT so it can be argued with rather than trusted.
#macro HTH_BK_CONTENT_FLOOR 0.55

/// How far a channel may drift before two pixels count as different colours.
#macro HTH_BK_TOL 6

/// The measure described in the header.
///
/// ⛔ y STEPS BY 1, NOT BY 2. This wing measured the cost of an even-only scan on another
/// product: a one-pixel rule sitting on an ODD row was walked past entirely, and a clipped
/// hairline is precisely the shape that lands on one row. x may step by 2 - nothing here draws a
/// one-pixel-wide VERTICAL feature at sheet scale.
function hth_bk_content(_surf, _w, _h) {
    var _buf = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_buf, _surf, 0);

    var _rows = 0;
    var _x0 = _w, _y0 = _h, _x1 = -1, _y1 = -1;

    for (var _y = 0; _y < _h; _y++) {
        var _base = _y * _w * 4;
        var _r0 = buffer_peek(_buf, _base, buffer_u8);
        var _g0 = buffer_peek(_buf, _base + 1, buffer_u8);
        var _b0 = buffer_peek(_buf, _base + 2, buffer_u8);
        var _hit = false;
        for (var _x = 2; _x < _w; _x += 2) {
            var _o = _base + _x * 4;
            var _rr = buffer_peek(_buf, _o, buffer_u8);
            var _gg = buffer_peek(_buf, _o + 1, buffer_u8);
            var _bb = buffer_peek(_buf, _o + 2, buffer_u8);
            if (abs(_rr - _r0) > HTH_BK_TOL || abs(_gg - _g0) > HTH_BK_TOL
             || abs(_bb - _b0) > HTH_BK_TOL) {
                _hit = true;
                if (_x < _x0) _x0 = _x;
                if (_x > _x1) _x1 = _x;
                if (_y < _y0) _y0 = _y;
                if (_y > _y1) _y1 = _y;
            }
        }
        if (_hit) _rows++;
    }
    buffer_delete(_buf);

    return { rows: _rows, frac: (_h > 0) ? (_rows / _h) : 0,
             x0: _x0, y0: _y0, x1: _x1, y1: _y1 };
}

/// Render one sheet, save it, measure it, and report.
function hth_bk_sheet(_name, _w, _h, _fn) {
    var _surf = surface_create(_w, _h);
    surface_set_target(_surf);
    draw_clear_alpha(c_black, 1);

    _fn(_w, _h);

    surface_reset_target();

    var _c = hth_bk_content(_surf, _w, _h);
    surface_save(_surf, _name + ".png");
    surface_free(_surf);

    var _ok = (_c.frac >= HTH_BK_CONTENT_FLOOR) && (_c.x1 > 0);
    var _reason = _ok ? "ok"
        : ("only " + string_format(_c.frac * 100, 1, 1) + "% of rows carry anything");

    return { sheet: _name, ok: _ok, frac: _c.frac, rows: _c.rows,
             content: [_c.x0, _c.y0, _c.x1, _c.y1], reason: _reason };
}

/// A caption. Sized from the MEASURED string, never from an assumed length.
///
/// ⛔ THIS WING HAS SHIPPED AN OVERPRINTED CAPTION TWICE - two names collided into a word that is
/// not a word, and a fix that shortened the DATA rather than the LAYOUT let it come straight back
/// on the next product. hth_text_label takes a max width and scales to it, so renaming a purpose
/// can never re-open it. NO INK CHECK WILL EVER CATCH THIS: overprinted text is ink exactly where
/// ink belongs. It is found by reading the sheet.
/// ⛔ LIGHT FACE OVER A DARK SHADOW, ALWAYS - NEVER ONE FLAT COLOUR. A caption on these sheets
/// can land on a limewashed wall, on a dark page or on a fire, and no single colour reads on all
/// three. The pair does, because whichever the background is close to, the other separates.
function hth_bk_caption(_text, _x, _y, _maxw, _px, _pal) {
    draw_set_font(fnt_hearth);
    hth_text_label(_text, _x, _y, _maxw, _px, _pal.label_sh, _pal.label);
}

/// A sheet title, in the title face.
///
/// ⛔ hth_text_fit CENTRES ON THE x IT IS GIVEN, AND THIS FUNCTION IS THE FOURTH CALL SITE IN THIS
/// STUDIO TO GET THAT WRONG. Its own header names the previous three - a cover that lost its first
/// letter, a wordmark hanging off its panel, a heading floating over a well - and every sheet in
/// this product's first bake read "FORMS, ONE GROUND LINE" because the title was centred on the
/// left MARGIN and half of it fell off the page. The fix is one term, and it is written here, once,
/// so no future sheet has to remember: _x is a LEFT EDGE at every call site on this page, so the
/// centre is _x + _maxw/2.
function hth_bk_title(_text, _x, _y, _maxw, _px, _pal) {
    draw_set_font(fnt_hearth_title);
    hth_text_fit(string_upper(_text), _x + _maxw * 0.5, _y, _maxw, _px,
                 _pal.label_sh, _pal.label);
    draw_set_font(fnt_hearth);
}

/// The page ground a catalogue sheet sits on, so the sheet reads as a plate rather than as a
/// screenshot.
function hth_bk_page(_w, _h, _pal) {
    draw_set_colour(_pal.ground);
    draw_rectangle(0, 0, _w, _h, false);
}

/// A room built to order, for a sheet.
function hth_bk_room(_purpose, _occupant, _seed, _region, _pros, _tidy, _age, _warm) {
    var _r = hth_room_of(_purpose, _occupant, _seed);
    _r.region = _region;
    _r.prosperity = _pros; _r.tidiness = _tidy; _r.age = _age; _r.warmth = _warm;
    return hth_room_derive(_r);
}

/// Draw one room into a cell and caption it. Returns the y the caption finished at, so a caller
/// can stack rows without a magic constant.
function hth_bk_cell(_room, _x, _y, _w, _h, _caption, _px) {
    var _pal = hth_palette_build(_room);
    hth_room_draw(_room, _pal, _x, _y, _w, _h);
    // A thin frame, so a cell reads as a plate and not as a window onto the page behind it.
    draw_set_colour(_pal.felt);
    draw_rectangle(_x, _y, _x + _w, _y + _h, true);
    hth_bk_caption(_caption, _x, _y + _h + 6, _w, _px, _pal);
    return _y + _h + 6 + _px + 4;
}

/// ============================================================================================
/// THE SHEETS
/// ============================================================================================
function hth_bake_run() {
    var _res = [];
    var _W = 1600, _H = 900;
    var _refpal = hth_palette_build(hth_room_create(1));

    // -- 1. THE HERO: one kitchen, four households --------------------------------------------
    // Same purpose, same seed, same region, same everything except WHO LIVES THERE. This is the
    // product's whole claim in one image and it is the sheet a buyer decides on.
    array_push(_res, hth_bk_sheet("sheet_1_same_room_four_lives", _W, _H, function(_w, _h) {
        var _pal = hth_palette_build(hth_room_create(1));
        hth_bk_page(_w, _h, _pal);
        hth_bk_title("The same kitchen, four households", 40, 26, _w - 80, 40, _pal);
        hth_bk_caption("TOP - one kitchen, two households. BOTTOM - one household, two rooms. "
                       + "Same seed, same region, same materials throughout: what changes is who "
                       + "lives there and what the room is for.",
                       40, 76, _w - 80, 20, _pal);

        // ⛔ 2x2, AND THE STRIP THAT USED TO SIT UNDER IT IS GONE BECAUSE IT OVERLAPPED ROW TWO.
        // Four big cells at an aspect near 2.2 carry both halves of the claim; six small ones
        // carried neither, and the two that collided carried it wrong.
        var _cw = (_w - 92) / 2;
        var _ch = 336;
        var _cells = [
            ["kitchen",  "farmer",  "THE FARMER'S KITCHEN"],
            ["kitchen",  "miser",   "THE MISER'S KITCHEN"],
            ["study",    "scholar", "THE SCHOLAR'S STUDY"],
            ["workshop", "scholar", "THE SCHOLAR'S WORKSHOP"],
        ];
        for (var _i = 0; _i < 4; _i++) {
            var _rm = hth_bk_room(_cells[_i][0], _cells[_i][1], 4242, "lowland",
                                  0.48, 0.55, 0.50, 0.80);
            hth_bk_cell(_rm, 40 + (_i mod 2) * (_cw + 12), 118 + floor(_i / 2) * (_ch + 46),
                        _cw, _ch, _cells[_i][2], 20);
        }
    }));

    // -- 2. THE TWELVE PURPOSES ----------------------------------------------------------------
    array_push(_res, hth_bk_sheet("sheet_2_twelve_purposes", _W, _H, function(_w, _h) {
        var _pal = hth_palette_build(hth_room_create(2));
        hth_bk_page(_w, _h, _pal);
        hth_bk_title("Twelve room purposes", 40, 26, _w - 80, 36, _pal);
        hth_bk_caption("Each purpose owns an authored slot list - which pieces exist, which are "
                       + "primary, and how much wall or floor each takes. A chapel is not a "
                       + "bedchamber with different furniture in it.",
                       40, 70, _w - 80, 19, _pal);

        var _p = hth_purpose_names();
        var _cols = 4, _rows = 3;
        var _cw = (_w - 80 - (_cols - 1) * 10) / _cols;
        var _ch = 186;                                   // aspect ~2.0, see _fix_sheets.js
        for (var _i = 0; _i < array_length(_p); _i++) {
            var _cx = 40 + (_i mod _cols) * (_cw + 10);
            var _cy = 116 + floor(_i / _cols) * (_ch + 44);
            var _rm = hth_bk_room(_p[_i], "farmer", 900 + _i, "lowland", 0.50, 0.55, 0.45, 0.70);
            hth_bk_cell(_rm, _cx, _cy, _cw, _ch, string_upper(_p[_i]), 18);
        }
    }));

    // -- 3. THE TEN OCCUPANTS ------------------------------------------------------------------
    array_push(_res, hth_bk_sheet("sheet_3_ten_occupants", _W, _H, function(_w, _h) {
        var _pal = hth_palette_build(hth_room_create(3));
        hth_bk_page(_w, _h, _pal);
        hth_bk_title("Ten households, ten sets of things", 40, 26, _w - 80, 36, _pal);
        hth_bk_caption("Every occupant owns six objects and the first two are a signature the "
                       + "solver never drops. No two households in the corpus share a signature. "
                       + "The strip along the bottom is the room those things stand in - the "
                       + "SAME parlour every time, which is the whole point.",
                       40, 70, _w - 80, 19, _pal);

        var _o = hth_occupant_names();
        var _cols = 5;
        var _cw = (_w - 80 - (_cols - 1) * 12) / _cols;
        var _ch = 232;

        for (var _i = 0; _i < array_length(_o); _i++) {
            var _cx = 40 + (_i mod _cols) * (_cw + 12);
            var _cy = 126 + floor(_i / _cols) * (_ch + 44);
            var _rm = hth_bk_room("parlour", _o[_i], 777, "lowland", 0.55, 0.45, 0.45, 0.75);
            var _cp = hth_palette_build(_rm);

            // The plate the still life stands on.
            draw_set_colour(_cp.felt);
            draw_rectangle(_cx, _cy, _cx + _cw, _cy + _ch, false);
            draw_set_colour(_cp.line);
            draw_rectangle(_cx, _cy, _cx + _cw, _cy + _ch, true);

            var _objs = hth_occupant_objects(_o[_i]);
            var _n = array_length(_objs);
            var _ground = _cy + _ch * 0.86;

            // ⛔ ONE SCALE PER CELL, SOLVED FROM THE TALLEST AND WIDEST OBJECT THE HOUSEHOLD OWNS.
            // Fitting each object to its own slot would make a crust and a spear the same size,
            // which is the proportion failure the furniture sheet exists to avoid - and here it
            // would also hide the real difference between a soldier's things and a scholar's.
            var _tall = 0, _wide = 0;
            for (var _k = 0; _k < _n; _k++) {
                var _ke = hth_clutter_extent(_objs[_k]);
                _tall = max(_tall, _ke.h);
                _wide = max(_wide, _ke.hw);
            }
            // TWO SHELVES OF THREE, NOT ONE OF SIX. With six across, the WIDTH constraint
            // binds and solves a scale that leaves the top 60% of every cell empty - the sparse
            // failure the content floor cannot see. Three across lets the height constraint bind,
            // which is the one that makes the objects legible. And 0.66 rather than 0.78 because
            // at 0.78 the outermost object crossed the cell frame into its neighbour.
            var _per = 3;
            var _rows2 = ceil(_n / _per);
            var _s = min((_ch * 0.34) / max(_tall, 0.001),
                         (_cw / _per * 0.42) / max(_wide, 0.001));
            for (var _sr = 0; _sr < _rows2; _sr++) {
                var _gy = _cy + _ch * (0.46 + 0.44 * _sr);
                draw_set_colour(_cp.line);
                draw_line(_cx + 10, _gy, _cx + _cw - 10, _gy);
                for (var _k = 0; _k < _per; _k++) {
                    var _oi = _sr * _per + _k;
                    if (_oi >= _n) break;
                    var _ox = _cx + _cw * ((_k + 0.5) / _per);
                    hth_shell_contact(_ox, _gy, hth_clutter_extent(_objs[_oi]).hw * _s * 1.2,
                                      _cp, 0.5);
                    hth_render_parts(hth_clutter_build(_objs[_oi], _rm, 7), _cp,
                                     _ox, _gy - HTH_GROUND * _s, _s, 0, _s, undefined);
                }
            }
            hth_bk_caption(string_upper(_o[_i]), _cx, _cy + _ch + 6, _cw, 18, _cp);
        }

        // The strip: the same parlour, three households. Wide enough that the objects standing in
        // it are still legible, which the old five-across version was not.
        var _sw = (_w - 104) / 3;
        var _pick = ["smith", "scholar", "miser"];
        for (var _i = 0; _i < 3; _i++) {
            var _rm3 = hth_bk_room("parlour", _pick[_i], 777, "lowland", 0.55, 0.45, 0.45, 0.75);
            hth_bk_cell(_rm3, 40 + _i * (_sw + 12), 700, _sw, 148,
                        "THE " + string_upper(_pick[_i]) + "'S PARLOUR", 17);
        }
    }));

    // -- 4. THE FURNITURE CATALOGUE ------------------------------------------------------------
    // ⚠️ EVERY PIECE IS DRAWN AT THE SAME SCALE AND ON THE SAME GROUND LINE, which is the whole
    // point of authoring the corpus in one unit box. A catalogue that fits each form to its own
    // cell makes a stool and a wardrobe the same size and throws away the proportion that says
    // what a piece IS.
    array_push(_res, hth_bk_sheet("sheet_4_furniture_corpus", _W, _H, function(_w, _h) {
        var _pal = hth_palette_build(hth_bk_room("kitchen", "farmer", 5, "lowland",
                                                 0.62, 0.60, 0.40, 0.70));
        var _rm = hth_bk_room("kitchen", "farmer", 5, "lowland", 0.62, 0.60, 0.40, 0.70);
        hth_bk_page(_w, _h, _pal);
        hth_bk_title("Thirty furniture forms, one ground line", 40, 26, _w - 80, 36, _pal);
        hth_bk_caption("Drawn from GML at a single shared scale, so a stool is stool-sized "
                       + "beside a wardrobe. No sprite, no atlas, no texture page - this "
                       + "package has no sprites folder.",
                       40, 70, _w - 80, 19, _pal);

        var _f = hth_form_names();
        // ⚠️ THE PIECES WERE POSTAGE STAMPS ON THE FIRST BAKE and the sheet read as empty.
        // The scale is solved from the TALLEST form so proportion is preserved - that is the
        // sheet's whole claim - which means the only lever is the cell height, and the answer to
        // a sparse sheet is always more content, never a lower threshold.
        var _cols = 6, _rowsn = 5;
        var _cw = (_w - 60) / _cols;
        var _ch = (_h - 138) / _rowsn;
        // ⛔ ONE SCALE FOR THE WHOLE SHEET, SOLVED FROM THE TALLEST FORM IN THE CORPUS. Choosing
        // it per cell is the failure above; choosing it from an assumed maximum is how a taller
        // form added later silently clips.
        var _tallest = 0;
        for (var _i = 0; _i < array_length(_f); _i++) {
            _tallest = max(_tallest, hth_form_extent(_f[_i]).h);
        }
        var _s = (_ch * 0.88) / _tallest;
        for (var _i = 0; _i < array_length(_f); _i++) {
            var _cx = 30 + (_i mod _cols) * _cw + _cw * 0.5;
            var _cy = 120 + floor(_i / _cols) * _ch;
            var _ground = _cy + _ch * 0.88;
            draw_set_colour(_pal.felt);
            draw_line(_cx - _cw * 0.42, _ground, _cx + _cw * 0.42, _ground);
            hth_shell_contact(_cx, _ground, hth_form_extent(_f[_i]).hw * _s, _pal, 0.5);
            hth_render_parts(hth_form_build(_f[_i], _rm, 7), _pal,
                             _cx, _ground - HTH_GROUND * _s, _s, 0, _s, undefined);
            // Centred under its own piece - see the object sheet for why.
            draw_set_font(fnt_hearth);
            hth_text_fit(string_upper(_f[_i]), _cx, _ground + 16, _cw * 0.92, 15,
                         _pal.label_sh, _pal.label);
        }
    }));

    // -- 5. THE CLUTTER CATALOGUE --------------------------------------------------------------
    array_push(_res, hth_bk_sheet("sheet_5_object_corpus", _W, _H, function(_w, _h) {
        var _rm = hth_bk_room("kitchen", "healer", 6, "lowland", 0.60, 0.55, 0.40, 0.75);
        var _pal = hth_palette_build(_rm);
        hth_bk_page(_w, _h, _pal);
        hth_bk_title("Forty-two personal objects", 40, 26, _w - 80, 36, _pal);
        hth_bk_caption("Each occupant owns six of these, and the first two are a signature the "
                       + "solver never drops. This is the half of the product that answers whose "
                       + "room it is. Shown here at their own scales so the small ones are "
                       + "legible - the sheet before this one is the one that shares a ground "
                       + "line, and in a room they are drawn to it.",
                       40, 70, _w - 80, 19, _pal);

        var _c = hth_clutter_names();
        var _cols = 7;
        var _rowsn = ceil(array_length(_c) / _cols);
        var _cw = (_w - 80) / _cols;
        var _ch = (_h - 150) / _rowsn;
        // ⛔ EACH OBJECT IS FITTED TO ITS OWN CELL, AND THE CAPTION SAYS SO. These span a 9.5x
        // height range - a spear against a crust - so one shared scale renders the small half of
        // the corpus at ten pixels and half the page is empty. Sheet 4 is where the shared ground
        // line is claimed and it still holds it; fitting here without saying so would be the
        // dishonest version of the same fix.
        for (var _i = 0; _i < array_length(_c); _i++) {
            var _cx = 40 + (_i mod _cols) * _cw + _cw * 0.5;
            var _cy = 120 + floor(_i / _cols) * _ch;
            var _ground = _cy + _ch * 0.86;
            var _ce = hth_clutter_extent(_c[_i]);
            var _s = min((_ch * 0.62) / max(_ce.h, 0.001),
                         (_cw * 0.40) / max(_ce.hw, 0.001));
            hth_shell_contact(_cx, _ground, _ce.hw * _s * 1.15, _pal, 0.45);
            hth_render_parts(hth_clutter_build(_c[_i], _rm, 7), _pal,
                             _cx, _ground - HTH_GROUND * _s, _s, 0, _s, undefined);
            // ⛔ CENTRED UNDER ITS OWN OBJECT. hth_text_label is LEFT-aligned and the objects are
            // centre-drawn, so a label written from the cell's left edge sat under the gap and
            // read as belonging to the object on its left - forty-two labels, all one cell out.
            draw_set_font(fnt_hearth);
            hth_text_fit(string_upper(_c[_i]), _cx, _ground + 14, _cw * 0.92, 14,
                         _pal.label_sh, _pal.label);
        }
    }));

    // -- 6. THE FOUR DIALS ---------------------------------------------------------------------
    array_push(_res, hth_bk_sheet("sheet_6_four_dials", _W, _H, function(_w, _h) {
        var _pal = hth_palette_build(hth_room_create(7));
        hth_bk_page(_w, _h, _pal);
        hth_bk_title("Four dials, one room", 40, 26, _w - 80, 36, _pal);
        hth_bk_caption("Prosperity, tidiness, age and warmth. The purpose, the occupant, the "
                       + "region and the seed are identical down every column - only the named "
                       + "field moves, and it moves continuously rather than switching.",
                       40, 70, _w - 80, 19, _pal);

        // ⛔ THREE WIDE COLUMNS BY FOUR ROWS, NOT A 4x3 GRID. dedupe.js measured the previous
        // version at Hamming distance 5 from the twelve-purposes sheet - both were 4x3 grids of
        // small rooms on the same page, so a buyer scrolling the gallery saw one picture twice.
        // A different SEED would not have moved that hash, because the hash was reading the
        // composition. Reading across a row is also simply clearer: it is one field moving.
        var _cols = 3;
        var _cw = (_w - 80 - (_cols - 1) * 12) / _cols;
        var _ch = 152;
        var _names = ["prosperity", "tidiness", "age", "warmth"];
        var _vals = [0.08, 0.50, 0.94];
        var _heads = ["LOW", "MIDDLE", "HIGH"];
        for (var _i = 0; _i < 3; _i++) {
            hth_bk_caption(_heads[_i], 40 + _i * (_cw + 12), 106, _cw, 17, _pal);
        }
        for (var _f = 0; _f < 4; _f++) {
            for (var _c = 0; _c < 3; _c++) {
                var _v = _vals[_c];
                var _rm = hth_bk_room("kitchen", "farmer", 3131, "lowland",
                                      (_f == 0) ? _v : 0.5,
                                      (_f == 1) ? _v : 0.5,
                                      (_f == 2) ? _v : 0.4,
                                      (_f == 3) ? _v : 0.6);
                hth_bk_cell(_rm, 40 + _c * (_cw + 12), 132 + _f * (_ch + 42), _cw, _ch,
                            string_upper(_names[_f]) + "  " + string_format(_v, 1, 2), 17);
            }
        }
    }));

    // -- 7. THE SOLVER, SHOWN --------------------------------------------------------------------
    // ⭐ THE ONE SHEET THAT SELLS THE ENGINEERING RATHER THAN THE ART. A buyer choosing between
    // this and a sprite pack is choosing not to place things by hand, so the thing to show is
    // the placement being solved: bands, the door swing kept clear, the window found a wall.
    array_push(_res, hth_bk_sheet("sheet_7_the_solver", _W, _H, function(_w, _h) {
        var _rm = hth_bk_room("taproom", "merchant", 2024, "forest", 0.58, 0.42, 0.55, 0.88);
        var _pal = hth_palette_build(_rm);
        hth_bk_page(_w, _h, _pal);
        hth_bk_title("The layout is solved, then asserted, then drawn", 40, 26, _w - 80, 34, _pal);
        hth_bk_caption("Pieces are placed into two depth bands with uneven, seeded gaps; the "
                       + "door swing is kept clear; the window is given a piece of wall nothing "
                       + "tall is standing in front of. Every generated room in the package is "
                       + "checked against those rules before a pixel is drawn.",
                       40, 68, _w - 80, 19, _pal);

        var _rx = 40, _ry = 128, _rw = _w - 80, _rh = 560;
        hth_room_draw(_rm, _pal, _rx, _ry, _rw, _rh);

        var _lay = _rm.layout;
        var _g = _lay.geom;

        // The door swing, marked. Drawn OVER the room at low alpha, because it is an annotation
        // and pretending otherwise would be a diagram wearing a screenshot's clothes.
        // A diagram line, not a light. At 0.30 it tinted a fifth of the room orange.
        draw_set_alpha(0.16);
        draw_set_colour(_pal.flame);
        draw_rectangle(_g.x + _g.w * _lay.door_clear[0], _g.y,
                       _g.x + _g.w * _lay.door_clear[1], _g.y + _g.h, false);
        draw_set_alpha(1);
        hth_bk_caption("DOOR SWING - KEPT CLEAR",
                       _g.x + _g.w * _lay.door_clear[0] + 6, _ry + 10,
                       _g.w * (_lay.door_clear[1] - _lay.door_clear[0]) - 12, 15, _pal);

        // ⛔ TWO ROWS OF LABELS, ONE PER BAND. A wall piece and a free piece stand in different
        // depth bands, so their x spans are ALLOWED to overlap - and two correctly-sized labels
        // at overlapping x still collide. This sheet shipped "HEARTH / walBARREL / free" in its
        // first bake, which is the third overprinted caption in this studio and the first one
        // that scaling the string could not have prevented.
        for (var _b = 0; _b < 2; _b++) {
            var _band = (_b == 0) ? "wall" : "free";
            var _y = _ry + _rh + 20 + _b * 40;
            for (var _i = 0; _i < array_length(_lay.items); _i++) {
                var _it = _lay.items[_i];
                if (_it.band != _band) continue;
                var _mx = _g.x + _g.w * _it.x;
                draw_set_colour((_band == "free") ? _pal.label : _pal.dust);
                draw_line(_mx - _it.hw * _g.w, _y, _mx + _it.hw * _g.w, _y);
                hth_bk_caption(string_upper(_it.form) + " / " + _band,
                               _mx - _it.hw * _g.w, _y + 6, _it.hw * _g.w * 2, 14, _pal);
            }
        }

        var _txt = "bands: WALL then FREE    pieces placed: "
                 + string(array_length(_lay.items) + array_length(_lay.hung))
                 + "    layout defects: " + string(array_length(_lay.defects))
                 + "    window: " + (_lay.has_window ? "placed" : "no clear wall");
        hth_bk_caption(_txt, 40, _h - 42, _w - 80, 20, _pal);
    }));

    // -- 8. THE SIX REGIONS ----------------------------------------------------------------------
    array_push(_res, hth_bk_sheet("sheet_8_six_regions", _W, _H, function(_w, _h) {
        var _pal = hth_palette_build(hth_room_create(9));
        hth_bk_page(_w, _h, _pal);
        hth_bk_title("Six regions, one household", 40, 26, _w - 80, 36, _pal);
        hth_bk_caption("An interior has no roof pitch to tell a region by, so the wall surface, "
                       + "the floor and whether the ceiling is beamed carry it - three flat "
                       + "areas covering most of the picture. Matched to the exterior half of "
                       + "this series, lamp for lamp.",
                       40, 70, _w - 80, 19, _pal);

        var _rg = hth_region_names();
        var _cols = 3;
        var _cw = (_w - 80 - (_cols - 1) * 12) / _cols;
        var _ch = 250;                                   // aspect ~2.0, see _fix_sheets.js
        for (var _i = 0; _i < array_length(_rg); _i++) {
            var _cx = 40 + (_i mod _cols) * (_cw + 12);
            var _cy = 170 + floor(_i / _cols) * (_ch + 54);
            var _rm = hth_bk_room("bedchamber", "widow", 616, _rg[_i], 0.52, 0.62, 0.55, 0.45);
            hth_bk_cell(_rm, _cx, _cy, _cw, _ch, string_upper(_rg[_i]), 18);
        }
    }));

    // -- the report ------------------------------------------------------------------------------
    var _f = file_text_open_write("hth_bake.json");
    // ⚠️ THE FLOOR IS WRITTEN INTO THE RESULT, NOT ONLY APPLIED. A verdict without the threshold
    // it was measured against is a number nobody can argue with, and the runner prints both.
    file_text_write_string(_f, "{\"floor\":" + string(HTH_BK_CONTENT_FLOOR) + ",\"sheets\":[");
    for (var _i = 0; _i < array_length(_res); _i++) {
        var _s = _res[_i];
        if (_i > 0) file_text_write_string(_f, ",");
        file_text_write_string(_f,
            "{\"sheet\":\"" + _s.sheet + "\",\"ok\":" + (_s.ok ? "true" : "false")
            + ",\"frac\":" + string_format(_s.frac, 1, 4)
            + ",\"rows\":" + string(_s.rows)
            + ",\"content\":[" + string(_s.content[0]) + "," + string(_s.content[1]) + ","
            + string(_s.content[2]) + "," + string(_s.content[3]) + "]"
            + ",\"reason\":\"" + _s.reason + "\"}");
    }
    file_text_write_string(_f, "]}");
    file_text_close(_f);
    return _res;
}
