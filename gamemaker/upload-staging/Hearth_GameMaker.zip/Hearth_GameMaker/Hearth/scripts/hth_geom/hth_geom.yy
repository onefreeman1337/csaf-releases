{
  "$GMScript": "v1",
  "%Name": "hth_geom",
  "isCompatibility": false,
  "isDnD": false,
  "name": "hth_geom",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}