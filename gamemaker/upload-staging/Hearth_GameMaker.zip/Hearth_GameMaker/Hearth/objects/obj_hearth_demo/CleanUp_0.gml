/// @description Clean Up

// ⛔ DELIBERATELY EMPTY, AND THE EMPTINESS IS THE FIX. Clean Up runs at game end even when Create
// took one of its headless early exits, so anything read here that Create declared AFTER the
// branch throws "variable not set before reading it" - a crash that arrives AFTER a fully green
// self-test, fails the run, and hides the result it was about to report. A sibling product in
// this wing shipped exactly that.
//
// This object therefore owns no surface, no sprite and no buffer: the demo draws live every
// frame, which is a few thousand triangles and costs nothing at this size. A buyer who wants a
// busy room for free should render it once into a sprite - see the readme - and free that sprite
// somewhere other than here.
