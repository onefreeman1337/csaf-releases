/// @description Draw GUI

// The whole product, in one call. Everything above and below this line is the demo's readout.
draw_set_colour(pal.ground);
draw_rectangle(0, 0, room_width, room_height, false);

hth_room_draw(room, pal, rx, ry, rw, rh);

// -- the readout --------------------------------------------------------------------------------
// ⚠️ THE OVERLAY IS DRAWN WITH THE PACKAGE'S OWN TEXT HELPERS, which measure the string and scale
// it to the cell it is given. This wing has shipped an overprinted caption twice - once because a
// later fix SHORTENED the data and re-opened a defect a hand-tuned size had been hiding. Measuring
// is the only thing that makes renaming safe, and no ink check will ever catch overprinted text,
// because overprinted text is ink exactly where ink belongs.
var _lbl = hth_room_describe(room);
// hth_text_fit CENTRES on the x it is given - see its header, and see hth_bk_title, which is the
// fourth call site in this studio to have passed it a left edge and lost half the string.
draw_set_font(fnt_hearth_title);
hth_text_fit(string_upper(_lbl), rx + rw * 0.5, 30, rw, 30, pal.label_sh, pal.label);

draw_set_font(fnt_hearth);
var _state = "prosperity " + string_format(room.prosperity, 1, 2)
           + "   tidiness " + string_format(room.tidiness, 1, 2)
           + "   age " + string_format(room.age, 1, 2)
           + "   warmth " + string_format(room.warmth, 1, 2)
           + "   " + room.wood_mat + " / " + room.floor_mat + " / " + room.wall_mat;
hth_text_line(_state, rx, ry + rh + 16, rw, 17, pal.label, false);

var _keys = "LEFT/RIGHT purpose    UP/DOWN occupant    SPACE reseed    "
          + "W warmth   T tidiness   P prosperity   G age   A autoplay";
hth_text_line(_keys, rx, ry + rh + 42, rw, 15, pal.dust, false);

// ⛔ THE LAYOUT'S OWN VERDICT IS ON SCREEN, NOT HIDDEN. If the solver ever ships a room that
// failed its own assertions, the demo says so in red rather than letting it look fine. A gate a
// buyer cannot see is a gate that can quietly stop working.
if (array_length(room.layout.defects) > 0) {
    hth_text_line("LAYOUT DEFECT: " + room.layout.defects[0], rx, ry + rh + 66, rw, 15,
                  pal.flame, true);
}
