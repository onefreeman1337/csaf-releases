/// @description Create

// ⛔ THE FIRST LINE OF ANY HEADLESS ENTRY POINT, AND IT IS NOT OPTIONAL.
// A GML runtime error opens a MODAL DIALOG. Headless, nothing dismisses it and the process never
// exits - a build robot then reports a 180-second timeout instead of a defect. Installing a
// handler that records the stage number and ends the game turns an opaque hang into a named line
// in a result file. This wing measured that exact conversion on a previous product: an opaque
// 180 s hang became "CRASH at stage 5: Variable Index [25] out of range [25]", a real bug.
//
// ⛔ AND IT RECORDS THE STACKTRACE, NOT JUST THE MESSAGE. A stage is a whole block calling
// hundreds of functions, so the message alone sends you guessing through the call graph. GML's
// exception struct carries .stacktrace, which names the function AND the line, and writing it
// costs one string. A diagnostic that narrows to a 300-line block is barely better than none.
global.hth_stage = -1;
exception_unhandled_handler(function(_ex) {
    var _st = "";
    try {
        var _tr = _ex.stacktrace;
        for (var _i = 0; _i < array_length(_tr); _i++) {
            if (_i > 0) _st += " <- ";
            _st += string(_tr[_i]);
        }
    } catch (_e) { _st = "(no stacktrace)"; }
    var _f = file_text_open_write("hth_crash.json");
    file_text_write_string(_f, "{\"stage\":" + string(global.hth_stage)
        + ",\"message\":\"" + string_replace_all(string(_ex.message), "\"", "'") + "\""
        + ",\"where\":\"" + string_replace_all(_st, "\"", "'") + "\"}");
    file_text_close(_f);
    game_end(1);
});

// ⛔ THE HEADLESS BRANCHES BELOW LEAVE Create PART WAY THROUGH, AND Clean Up STILL RUNS AT GAME
// END. A sibling product in this wing threw "variable not set before reading it" AFTER a fully
// green self-test, because its Clean Up read an instance variable that the early `exit` had
// skipped past - a crash after the work is done still fails the run and still hides the result.
// The fix chosen here is the one with no moving parts: NOTHING this object's other events touch
// is declared after the branch, and Clean Up is deliberately empty. If a future edit adds a
// surface or a sprite cache to this object, it must be created BEFORE the branch or freed
// somewhere other than Clean Up.
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i + 1) + " ";

// -- headless modes: run, write the result file, exit -----------------------------------------
if (string_pos("-selftest", _args) > 0) {
    hth_selftest_run();
    game_end(0);
    exit;
}
if (string_pos("-bake", _args) > 0) {
    hth_bake_run();
    game_end(0);
    exit;
}

// -- the interactive demo ---------------------------------------------------------------------
// ⛔ A RUNNABLE DEMO ROOM IS MANDATORY IN THIS WING. It is the buyer's quickstart, the source of
// the store GIF, and the only real smoke test GML permits - all three at once. A buyer who
// cannot press Play cannot evaluate the product.
//
// It is deliberately the SHORTEST CORRECT USE OF THE API:
//     pick a purpose and an occupant -> build a palette -> draw the room.
// Everything else in these events is the readout that shows what the state currently is.
purposes  = hth_purpose_names();
occupants = hth_occupant_names();
pi_idx    = 0;
oi_idx    = 0;
seed      = 1;

room = hth_room_of(purposes[pi_idx], occupants[oi_idx], seed);
pal  = hth_palette_build(room);

auto  = true;
timer = 0;

// The rect the room is drawn into. Deliberately not the whole window: the margin is what proves
// hth_room_draw stays inside the rect it is given, and a buyer can see that it does.
rx = 90;
ry = 70;
rw = 1100;
rh = 500;
