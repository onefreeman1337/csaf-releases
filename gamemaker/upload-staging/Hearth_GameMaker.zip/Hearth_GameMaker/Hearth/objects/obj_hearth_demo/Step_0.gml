/// @description Step

// ⚠️ ONE PLACE REBUILDS THE ROOM, AND EVERY CONTROL ROUTES THROUGH IT. A demo that rebuilds
// inline at each key handler is a demo where one branch forgets to rebuild the palette, and the
// symptom is a room whose materials belong to the previous occupant. Deriving and rebuilding
// together, once, makes that impossible.
var _rebuild = false;

if (keyboard_check_pressed(vk_right)) { pi_idx = (pi_idx + 1) mod array_length(purposes);  _rebuild = true; }
if (keyboard_check_pressed(vk_left))  { pi_idx = (pi_idx + array_length(purposes) - 1) mod array_length(purposes); _rebuild = true; }
if (keyboard_check_pressed(vk_down))  { oi_idx = (oi_idx + 1) mod array_length(occupants); _rebuild = true; }
if (keyboard_check_pressed(vk_up))    { oi_idx = (oi_idx + array_length(occupants) - 1) mod array_length(occupants); _rebuild = true; }
if (keyboard_check_pressed(vk_space)) { seed += 1; _rebuild = true; }
if (keyboard_check_pressed(ord("A"))) { auto = !auto; }

// The four continuous fields, on four keys. These are the ones a buyer will want to feel: they
// are what turn a room into THIS household's room.
if (keyboard_check_pressed(ord("W"))) {
    room.warmth = (room.warmth > 0.5) ? 0.05 : 0.95; _rebuild = true;
}
if (keyboard_check_pressed(ord("T"))) {
    room.tidiness = (room.tidiness > 0.5) ? 0.05 : 0.95; _rebuild = true;
}
if (keyboard_check_pressed(ord("P"))) {
    room.prosperity = (room.prosperity > 0.5) ? 0.10 : 0.92; _rebuild = true;
}
if (keyboard_check_pressed(ord("G"))) {
    room.age = (room.age > 0.5) ? 0.05 : 0.90; _rebuild = true;
}

if (auto) {
    timer += 1;
    if (timer > 150) {
        timer = 0;
        oi_idx = (oi_idx + 1) mod array_length(occupants);
        if (oi_idx == 0) pi_idx = (pi_idx + 1) mod array_length(purposes);
        _rebuild = true;
    }
}

if (_rebuild) {
    // ⛔ THE FOUR CONTINUOUS FIELDS ARE CARRIED ACROSS THE REBUILD BY HAND. hth_room_of reseeds
    // them, which is right for a fresh room and wrong for "the same room, warmer" - and losing
    // them silently is exactly the kind of thing that makes a demo feel like it ignores its own
    // controls.
    var _w = room.warmth, _t = room.tidiness, _p = room.prosperity, _g = room.age;
    room = hth_room_of(purposes[pi_idx], occupants[oi_idx], seed);
    room.warmth = _w; room.tidiness = _t; room.prosperity = _p; room.age = _g;
    hth_room_derive(room);
    pal = hth_palette_build(room);
    hth_room_furnish(room, rx, ry, rw, rh);
}
