{
  "$GMScript": "v1",
  "%Name": "rps_garnish",
  "name": "rps_garnish",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}