/// REPAST - rps_garnish. The CORPUS, part 5: six garnish and finishing forms.
///
/// Same contract as rps_ingredient, with one difference worth stating: these forms are authored
/// to be drawn ON TOP of other forms rather than beside them, so several of them sit high in the
/// unit box and their "contact" is with the food below rather than with the plate.
///
/// ⭐ WHY A GARNISH GROUP EXISTS AT ALL. Two plates carrying identical food, one finished with a
/// sprig, a scatter of seeds and a wisp of steam and one not, do not read as the same dish at the
/// same quality - they read as a cooked meal and as an ingredient. In a game where cooking has
/// QUALITY TIERS, the garnish layer is how the tier becomes visible without a number on the
/// screen, and rps_plate adds these automatically as quality rises. That is the single most
/// valuable thing in this package for a buyer who wants cooking to feel rewarding.
/// ============================================================================================

/// A herb sprig: a stem with paired leaves running up it.
function rps_form_sprig(_seed) {
    var _out = [];
    var _st = rps_rng(_seed);
    // The stem arcs rather than standing straight - a straight stem reads as a stick.
    var _stem = rps_qbez([-0.20, RPS_GROUND - 0.020], [-0.02, RPS_GROUND - 0.190],
                         [0.21, RPS_GROUND - 0.330], 16);
    array_push(_out, rps_taper_ribbon(_stem, 0.014, 0.005, "m1"));
    // Five pairs of leaves, getting smaller toward the tip, each turned by a jittered angle so the
    // sprig does not read as a stencil.
    for (var _i = 0; _i < 5; _i++) {
        var _t = 0.15 + _i * 0.185;
        var _idx = min(15, floor(_t * 16));
        var _p = _stem[_idx];
        var _len = 0.135 * (1 - _i * 0.13);
        for (var _s = 0; _s < 2; _s++) {
            var _dir = (_s == 0) ? 1 : -1;
            var _a = -0.9 * _dir + (rps_rng_next(_st) - 0.5) * 0.5;
            var _tip = [_p[0] + cos(_a) * _len, _p[1] + sin(_a) * _len];
            var _mid = [_p[0] + cos(_a) * _len * 0.5 - sin(_a) * 0.030 * _dir,
                        _p[1] + sin(_a) * _len * 0.5 + cos(_a) * 0.030 * _dir];
            // A leaf is a closed lens: out along one curve, back along the mirror of it.
            var _f = rps_qbez(_p, _mid, _tip, 7);
            var _b = rps_qbez(_tip,
                              [_p[0] + cos(_a) * _len * 0.5 + sin(_a) * 0.030 * _dir,
                               _p[1] + sin(_a) * _len * 0.5 - cos(_a) * 0.030 * _dir],
                              _p, 7);
            rps_append(_out, rps_raise(rps_append(rps_append([], _f), _b), 0.012, 2, "m3"));
        }
    }
    return _out;
}

/// A single broad leaf - bay, vine, shiso - with a midrib and side veins.
function rps_form_leafwhole(_seed) {
    var _out = [];
    var _base = [-0.29, RPS_GROUND - 0.055];
    var _tip = [0.30, RPS_GROUND - 0.255];
    var _up = rps_qbez(_base, [0.00, RPS_GROUND - 0.290], _tip, 12);
    var _dn = rps_qbez(_tip, [0.00, RPS_GROUND - 0.020], _base, 12);
    var _leaf = rps_append(rps_append([], _up), _dn);
    rps_append(_out, rps_raise(_leaf, 0.024, 3, "m3"));
    // The midrib is a RIDGE and the veins are INCISED. That asymmetry is what a real leaf does -
    // the midrib stands proud on the underside and the veins are creases - and doing both as one
    // kind of mark makes the leaf read as a printed shape.
    var _rib = rps_qbez(_base, [0.00, RPS_GROUND - 0.155], _tip, 12);
    rps_append(_out, rps_ridge(_rib, false, 0.014));
    for (var _i = 1; _i < 6; _i++) {
        var _p = _rib[_i * 2];
        for (var _s = 0; _s < 2; _s++) {
            var _dir = (_s == 0) ? -1 : 1;
            rps_append(_out, rps_incise([[_p[0], _p[1]],
                                         [_p[0] + 0.075, _p[1] + _dir * 0.070]], false, 0.008));
        }
    }
    return _out;
}

/// A scatter of seeds, nuts or capers across whatever is under it.
///
/// ⚠️ THE SPREAD IS WIDE AND SHALLOW ON PURPOSE. A garnish scatter that fills a circle reads as a
/// pile; one that runs across the dish reads as having been thrown by a hand. Two clusters at
/// different densities rather than one even field, because an even field is the tell of a loop.
function rps_form_seeds(_seed) {
    var _out = [];
    rps_append(_out, rps_scatter(-0.06, RPS_GROUND - 0.115, 0.255, 0.085, 16, 0.021, _seed));
    rps_append(_out, rps_scatter(0.16, RPS_GROUND - 0.075, 0.115, 0.050, 6, 0.019, _seed + 3));
    return _out;
}

/// A dusting - sugar, flour, ground spice, grated cheese. Very many very small marks.
///
/// ⛔ THIS IS THE FORM THAT PROVES THE COUNT-AND-LENGTH LAW. There is no way to draw a dusting
/// with line width: at any width above the 1px floor it is a scatter of visible dots, and below
/// it there is no such thing. It is drawn as 90 dots at three sizes, and it works.
function rps_form_dusting(_seed) {
    var _out = [];
    var _st = rps_rng(_seed);
    for (var _i = 0; _i < 90; _i++) {
        var _a = rps_rng_next(_st) * RPS_TAU;
        var _u = sqrt(rps_rng_next(_st));
        var _x = cos(_a) * 0.33 * _u;
        var _y = RPS_GROUND - 0.115 + sin(_a) * 0.115 * _u;
        var _r = 0.005 + rps_rng_next(_st) * 0.007;
        array_push(_out, rps_dot(_x, _y, _r, "crumb"));
    }
    return _out;
}

/// A pool of sauce with a gloss run across it - the thing a dish is plated ON.
function rps_form_saucepool(_seed) {
    var _out = [];
    var _pool = rps_blob_pts(0, RPS_GROUND - 0.045, 0.375, 0.085, 30, 0.115, _seed);
    rps_append(_out, rps_map_roles(rps_raise(_pool, 0.020, 2, "m2"),
                                   rps_material_map("sauce")));
    // ⭐ THE GLOSS IS WHAT MAKES IT WET, and it is a BROKEN highlight rather than a continuous
    // one. A single unbroken arc reads as a scratch on the plate; three short runs at slightly
    // different radii read as light on a moving surface.
    for (var _i = 0; _i < 3; _i++) {
        var _a0 = 3.5 + _i * 0.75;
        array_push(_out, rps_ribbon(rps_arc_pts(-0.03, RPS_GROUND - 0.055,
                                                0.235 - _i * 0.045, _a0, _a0 + 0.55, 8),
                                    0.008, "gloss"));
    }
    return _out;
}

/// Rising steam. Three wisps, thinning and fading upward.
///
/// ⛔ STEAM IS DRAWN IN FLAT ROLES AND MUST NEVER BE SHADED. Vapour has no surface to catch a
/// lamp; giving it a lit face and a shadowed face is the single fastest way to make a plate look
/// like a sprite sheet. It is also the only form in the corpus with no contact shadow, for the
/// obvious reason.
///
/// ⚠️ AND IT IS AUTHORED AS THE TOP HALF OF THE BOX. rps_plate draws it ABOVE the dish rather
/// than on it, so a form that sat on RPS_GROUND like everything else would put steam inside the
/// food. This is a deliberate, documented exception to corpus rule 1 and the self-test knows
/// about it by name rather than by a general escape hatch.
function rps_form_steam(_seed) {
    var _out = [];
    var _st = rps_rng(_seed);
    for (var _i = 0; _i < 3; _i++) {
        var _x = -0.16 + _i * 0.16 + (rps_rng_next(_st) - 0.5) * 0.05;
        var _sway = (rps_rng_next(_st) - 0.5) * 0.20;
        // Two S-curves per wisp: the lower one thicker and in the brighter role, the upper one
        // thinner and dimmer, which reads as steam dispersing without needing alpha.
        var _lo = rps_qbez([_x, RPS_GROUND - 0.060], [_x + _sway, RPS_GROUND - 0.210],
                           [_x - _sway * 0.6, RPS_GROUND - 0.320], 12);
        var _hi = rps_qbez([_x - _sway * 0.6, RPS_GROUND - 0.320],
                           [_x - _sway * 1.4, RPS_GROUND - 0.410],
                           [_x + _sway * 0.4, RPS_GROUND - 0.480], 10);
        array_push(_out, rps_taper_ribbon(_lo, 0.026, 0.014, "steam_lo"));
        array_push(_out, rps_taper_ribbon(_hi, 0.014, 0.004, "steam"));
    }
    return _out;
}
