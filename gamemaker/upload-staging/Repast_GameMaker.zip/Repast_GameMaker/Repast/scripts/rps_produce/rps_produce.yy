{
  "$GMScript": "v1",
  "%Name": "rps_produce",
  "name": "rps_produce",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}