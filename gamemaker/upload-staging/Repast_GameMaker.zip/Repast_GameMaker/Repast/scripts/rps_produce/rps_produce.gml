/// REPAST - rps_produce. The CORPUS, part 2: twelve vegetable forms.
///
/// Same contract as rps_ingredient: every function takes (_seed), returns a part list in the unit
/// box, sits on RPS_GROUND, stays inside the box, and emits only m0..m4 plus named flat roles.
///
/// ⭐ VEGETABLES ARE THE HARDEST GROUP IN THE CORPUS AND IT IS WORTH SAYING WHY. Meat is a mass
/// with a surface, and relief does most of the work. A vegetable is usually a STRUCTURE - rings,
/// layers, florets, a cut face showing what is inside - and a structure drawn as a mass reads as
/// a lump of the right colour. So most of the forms below are built from a repeated element
/// placed by a rule, which is also what makes them survive being scaled down to an inventory
/// icon: the rule stays legible when the detail stops being resolvable.
/// ============================================================================================

/// A tapered root - carrot, parsnip, salsify - with its shoulder, its taper and a fringe of top.
function rps_form_root(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0.02, 0.70));
    // The body is a spine with a taper, not an outline: that way the same form serves a fat swede
    // and a thin salsify by changing two numbers.
    var _spine = rps_qbez([-0.30, RPS_GROUND - 0.075], [0.02, RPS_GROUND - 0.16],
                          [0.30, RPS_GROUND - 0.105], 16);
    rps_append(_out, [rps_taper_ribbon(_spine, 0.105, 0.014, "m2")]);
    // Lit crown along the top of the taper. Offsetting the SAME spine is what keeps the highlight
    // following the form instead of sitting on it as a separate shape.
    rps_append(_out, [rps_taper_ribbon(rps_move_pts(_spine, 0, -0.030), 0.038, 0.006, "m4")]);
    // Growth rings: short incisions across the taper, closer together toward the tip, because
    // that is where the root grew slowest.
    for (var _i = 0; _i < 7; _i++) {
        var _t = 0.14 + _i * 0.115;
        var _idx = min(15, floor(_t * 16));
        var _p = _spine[_idx];
        var _h = 0.088 * (1 - _t * 0.82);
        rps_append(_out, rps_incise([[_p[0], _p[1] - _h], [_p[0] - 0.012, _p[1] + _h]],
                                    false, 0.011));
    }
    // The leafy top, in the garnish ramp so it is green whatever the root is.
    for (var _i = 0; _i < 4; _i++) {
        rps_append(_out, rps_map_roles(
            rps_strand([-0.30, RPS_GROUND - 0.085],
                       [-0.40 + _i * 0.02, RPS_GROUND - 0.20 - _i * 0.03],
                       [-0.33 - _i * 0.04, RPS_GROUND - 0.34 - _i * 0.02], 0.016, 0.003, "m3"),
            rps_material_map("leafm")));
    }
    return _out;
}

/// A roast potato: an irregular faceted lump. FACETS, not a blob - a roast potato is cut, and its
/// flat cut faces are what catch the fat and go crisp.
function rps_form_roastpotato(_seed) {
    var _out = [];
    var _st = rps_rng(_seed);
    rps_append(_out, rps_contact(0, 0.58));
    // A coarse polygon with jittered radii: few points, so the silhouette reads as CUT.
    var _pts = array_create(9);
    for (var _i = 0; _i < 9; _i++) {
        var _a = RPS_TAU * (_i / 9) + 0.3;
        var _r = 0.185 * (0.80 + 0.34 * rps_rng_next(_st));
        _pts[_i] = [cos(_a) * _r, RPS_GROUND - 0.155 + sin(_a) * _r * 0.86];
    }
    rps_append(_out, rps_raise(_pts, 0.055, 3, "m2"));
    // Two crisped facets, drawn as small raised plates in the lightest stop on the lamp side.
    rps_append(_out, rps_raise([[-0.10, RPS_GROUND - 0.245], [0.05, RPS_GROUND - 0.275],
                                [0.10, RPS_GROUND - 0.185], [-0.06, RPS_GROUND - 0.160]],
                               0.020, 2, "m4"));
    rps_append(_out, rps_raise([[0.06, RPS_GROUND - 0.165], [0.17, RPS_GROUND - 0.130],
                                [0.13, RPS_GROUND - 0.055], [0.03, RPS_GROUND - 0.085]],
                               0.016, 2, "m3"));
    return _out;
}

/// A mound of mash with fork ridges dragged across it.
function rps_form_mash(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.80));
    var _pts = rps_blob_pts(0, RPS_GROUND - 0.115, 0.32, 0.145, 26, 0.055, _seed);
    rps_append(_out, rps_raise(_pts, 0.070, 3, "m2"));
    // ⭐ THE FORK RIDGES ARE THE WHOLE FORM. Without them this is a beige hill. They are RIDGES,
    // not incisions: a fork dragged through mash pushes material up either side of the tine, so
    // the mark stands proud. Four passes of four tines, at slightly different angles, because a
    // real plate is not combed in one direction.
    for (var _p = 0; _p < 4; _p++) {
        var _rot = -0.55 + _p * 0.34;
        var _y = RPS_GROUND - 0.20 + _p * 0.038;
        for (var _t = 0; _t < 4; _t++) {
            var _x0 = -0.20 + _t * 0.006;
            var _c = rps_qbez([_x0, _y + _t * 0.020],
                              [0.00, _y - 0.030 + _t * 0.020],
                              [0.20, _y + _t * 0.020], 8);
            rps_append(_out, rps_ridge(_c, false, 0.012));
        }
    }
    return _out;
}

/// An onion ring seen face on - concentric rings, which is the one thing an onion always is.
function rps_form_onionring(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.60));
    var _cy = RPS_GROUND - 0.155;
    // Four nested rings, alternating raised and sunken so the layers read as separate leaves
    // rather than as a target.
    for (var _i = 0; _i < 4; _i++) {
        var _r = 0.185 - _i * 0.040;
        var _ring = rps_ellipse_pts(0, _cy, _r, _r * 0.90, 22);
        if (_i % 2 == 0) rps_append(_out, rps_raise(_ring, 0.018, 2, "m3"));
        else rps_append(_out, rps_sink(_ring, 0.014, 2, "m1"));
    }
    // The centre, and a break in the outermost ring - an onion ring is a C, not an O, and the
    // break is what stops it reading as a machined washer.
    rps_append(_out, rps_raise(rps_ellipse_pts(0, _cy, 0.030, 0.028, 12), 0.010, 2, "m4"));
    rps_append(_out, rps_incise(rps_arc_pts(0, _cy, 0.185, 0.55, 0.95, 6), false, 0.022));
    return _out;
}

/// A sliced leek round: tight concentric rings with a bright core.
function rps_form_leek(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.52));
    var _cy = RPS_GROUND - 0.140;
    rps_append(_out, rps_raise(rps_ellipse_pts(0, _cy, 0.165, 0.155, 22), 0.028, 3, "m2"));
    // Six rings, each an arc rather than a full circle, rotated by the golden angle so the gaps
    // never line up into a visible seam.
    for (var _i = 0; _i < 6; _i++) {
        var _r = 0.148 - _i * 0.022;
        var _a0 = degtorad(RPS_GOLDEN_ANGLE * _i);
        array_push(_out, rps_arc(0, _cy, _r, _a0, _a0 + 5.6, 0.008, (_i % 2 == 0) ? "m4" : "m1"));
    }
    return _out;
}

/// A mushroom: domed cap, gills under the rim, a stipe standing on the plate.
function rps_form_mushroom(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.54));
    // The stipe first, so the cap is painted over its top.
    rps_append(_out, rps_raise(rps_round_rect_pts(-0.052, RPS_GROUND - 0.185, 0.052,
                                                  RPS_GROUND - 0.010, 0.030, 4), 0.026, 2, "m3"));
    // The gill band: drawn as many short radial strokes, count-carried. This is the one part of a
    // mushroom that a buyer will notice is missing.
    for (var _i = 0; _i < 15; _i++) {
        var _a = pi + (_i / 14) * pi;
        var _r0 = 0.075, _r1 = 0.205;
        array_push(_out, rps_poly([[cos(_a) * _r0, RPS_GROUND - 0.175 - sin(_a) * _r0 * 0.30],
                                   [cos(_a) * _r1, RPS_GROUND - 0.175 - sin(_a) * _r1 * 0.30]],
                                  false, 0.006, "m0"));
    }
    // The cap: a half-ellipse dome, wider than the stipe, raised hard so it domes.
    var _cap = [];
    for (var _i = 0; _i <= 22; _i++) {
        var _a = pi + (_i / 22) * pi;
        array_push(_cap, [cos(_a) * 0.225, RPS_GROUND - 0.190 + sin(_a) * 0.150]);
    }
    array_push(_cap, [0.225, RPS_GROUND - 0.175]);
    array_push(_cap, [-0.225, RPS_GROUND - 0.175]);
    rps_append(_out, rps_raise(_cap, 0.062, 3, "m2"));
    return _out;
}

/// A wedge of cabbage, cut through the heart so the layers show.
function rps_form_cabbage(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.68));
    var _wedge = [[-0.26, RPS_GROUND - 0.020], [-0.19, RPS_GROUND - 0.300],
                  [0.14, RPS_GROUND - 0.330], [0.27, RPS_GROUND - 0.045]];
    rps_append(_out, rps_raise(_wedge, 0.045, 3, "m2"));
    // ⭐ THE CUT FACE IS THE FORM. Nested arcs running from the stem outward, which is exactly how
    // a cabbage is built and instantly legible even at icon size. They are INCISED, so the leaves
    // read as pressed layers rather than as drawn-on stripes.
    for (var _i = 0; _i < 7; _i++) {
        var _r = 0.055 + _i * 0.038;
        rps_append(_out, rps_incise(rps_arc_pts(-0.02, RPS_GROUND - 0.030, _r, 3.35, 6.05, 12),
                                    false, 0.013));
    }
    // The stem, pale and solid at the base.
    rps_append(_out, rps_raise(rps_ellipse_pts(-0.02, RPS_GROUND - 0.040, 0.055, 0.032, 12),
                               0.016, 2, "m4"));
    return _out;
}

/// A halved sprout: the cut face with its tight whorl, and the loose outer leaves.
function rps_form_sprout(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.44));
    var _body = rps_blob_pts(0, RPS_GROUND - 0.130, 0.155, 0.140, 20, 0.045, _seed);
    rps_append(_out, rps_raise(_body, 0.038, 3, "m2"));
    for (var _i = 0; _i < 4; _i++) {
        rps_append(_out, rps_incise(rps_arc_pts(0, RPS_GROUND - 0.055, 0.045 + _i * 0.030,
                                                3.5, 5.95, 10), false, 0.011));
    }
    // Two loose outer leaves, which are what stop a sprout reading as a green ball.
    for (var _i = 0; _i < 2; _i++) {
        var _sx = (_i == 0) ? -1 : 1;
        rps_append(_out, rps_raise(rps_ellipse_pts(_sx * 0.155, RPS_GROUND - 0.155,
                                                   0.070, 0.100, 12), 0.018, 2, "m1"));
    }
    // The cut face is flat and pale - a knife has been through it and it does not catch the lamp
    // the way the leaves do.
    rps_append(_out, rps_score(-0.075, RPS_GROUND - 0.185, 0.075, RPS_GROUND - 0.085, 3, "m4", 0));
    return _out;
}

/// A scatter of peas. Not one form repeated - a rule that places them, which is why fifteen peas
/// never look like a stamped pattern.
function rps_form_peas(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.72));
    rps_append(_out, rps_scatter(0, RPS_GROUND - 0.055, 0.27, 0.075, 17, 0.052, _seed));
    // A second, sparser layer sitting slightly higher, so the pile has depth rather than being a
    // single sheet of circles.
    rps_append(_out, rps_scatter(-0.02, RPS_GROUND - 0.115, 0.17, 0.048, 7, 0.050, _seed + 7));
    return _out;
}

/// A bean pod, split along its seam with the beans showing.
function rps_form_pod(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.76));
    var _spine = rps_qbez([-0.33, RPS_GROUND - 0.055], [0.00, RPS_GROUND - 0.215],
                          [0.33, RPS_GROUND - 0.060], 16);
    rps_append(_out, [rps_taper_ribbon(_spine, 0.030, 0.030, "m2")]);
    // The open half, lifted, showing the beans in a row along the seam.
    rps_append(_out, [rps_taper_ribbon(rps_move_pts(_spine, 0, -0.042), 0.020, 0.020, "m1")]);
    for (var _i = 2; _i < 15; _i += 3) {
        rps_append(_out, rps_map_roles(rps_boss(_spine[_i][0], _spine[_i][1] - 0.016, 0.036, 10),
                                       rps_material_map("side")));
    }
    return _out;
}

/// A crescent slice of squash: rind, flesh and a seed cavity.
function rps_form_squash(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.78));
    // Outer arc and inner arc, joined - a crescent, which is what a slice through a hollow gourd
    // actually is and is far more legible than a wedge.
    // ⚠️ THE CENTRE IS ABOVE THE GROUND LINE, NOT BELOW IT. At +0.145 the inner arc's endpoints
    // landed at y=0.530, outside the unit box — measured in engine. The crescent is the same
    // shape; it simply sits where it fits.
    var _outer = rps_arc_pts(0, RPS_GROUND + 0.100, 0.345, 3.45, 5.98, 18);
    var _inner = rps_arc_pts(0, RPS_GROUND + 0.100, 0.185, 5.98, 3.45, 14);
    var _ring = rps_append(rps_append([], _outer), _inner);
    rps_append(_out, rps_raise(_ring, 0.040, 3, "m2"));
    // The rind: a darker band along the outer edge only.
    rps_append(_out, [rps_taper_ribbon(_outer, 0.024, 0.024, "m0")]);
    // Seeds in the hollow.
    rps_append(_out, rps_map_roles(rps_scatter(0, RPS_GROUND - 0.135, 0.10, 0.035, 6, 0.026,
                                               _seed + 3), rps_material_map("side")));
    return _out;
}

/// A parsnip-style root roasted whole and split: the same taper as rps_form_root, cut open.
///
/// ⚠️ IT IS A SEPARATE FORM RATHER THAN A FLAG ON THE ROOT, and that is deliberate. A split root
/// shows its CORE, which is a different colour and a different texture from its flesh, and a
/// boolean that changes what a form is made of is how a corpus turns into a pile of special
/// cases. Two forms, each honest about what it draws.
function rps_form_splitroot(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0.02, 0.72));
    var _spine = rps_qbez([-0.31, RPS_GROUND - 0.085], [0.02, RPS_GROUND - 0.175],
                          [0.31, RPS_GROUND - 0.100], 16);
    rps_append(_out, [rps_taper_ribbon(_spine, 0.115, 0.016, "m2")]);
    // The cut face runs the whole length, slightly above the spine, and the woody core inside it
    // is what says "parsnip" rather than "carrot".
    rps_append(_out, [rps_taper_ribbon(rps_move_pts(_spine, 0, -0.018), 0.078, 0.008, "m4")]);
    rps_append(_out, [rps_taper_ribbon(rps_move_pts(_spine, 0, -0.018), 0.034, 0.004, "m3")]);
    // Caramelised edges where the cut face met the pan.
    for (var _i = 1; _i < 15; _i += 2) {
        var _p = _spine[_i];
        array_push(_out, rps_poly([[_p[0], _p[1] - 0.070], [_p[0] + 0.02, _p[1] - 0.045]],
                                  false, 0.006, "scorch"));
    }
    return _out;
}
