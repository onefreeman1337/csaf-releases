{
  "$GMScript": "v1",
  "%Name": "rps_plate",
  "name": "rps_plate",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}