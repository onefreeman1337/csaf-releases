/// REPAST - rps_plate. The vessel, and the composition that puts a dish on it.
///
/// ⭐ THIS IS THE FILE THE PRODUCT IS SOLD ON. Everything before it draws one thing; this one
/// decides where several things go, and that decision is the difference between "a cooking system
/// with icons" and "a cooking system whose output a player wants to look at".
///
/// -- THE COMPOSITION RULE ----------------------------------------------------------------------
/// A plated dish has four slots and they are drawn in this order, which is painter's order and is
/// also the order food is actually put on a plate:
///
///   base   a bed the rest sits on - mash, rice, noodles, a sauce pool. Widest, lowest, at the
///          back. Optional; plenty of dishes have none.
///   hero   the one thing the dish is named after. Centre, slightly forward, largest single form.
///   side   accompaniments, one to three of them, fanned either side of the hero and behind it.
///   garn   finishing - a sprig, seeds, a dusting, steam. Drawn last, ON the food, small.
///
/// ⛔ THE SIDES FAN, THEY DO NOT QUEUE. The obvious implementation lays components out left to
/// right at even spacing, and it produces a row of objects on a disc - a shop shelf, not a plate.
/// Real plating puts accompaniments on an ARC behind and around the hero, at slightly different
/// depths, and the depth difference is what makes the plate read as having a front and a back.
///
/// ⛔ AND NOTHING IS EVER PLACED AT THE CENTRE OF THE PLATE. Dead-centre composition is the most
/// reliable way to make food look like a stock icon. The hero sits just below and left of centre,
/// on the lamp side, so its lit face is the first thing the eye lands on.
/// ============================================================================================

/// The number of quality tiers. A tier is not a multiplier on a number - it changes what is ON
/// the plate, which is the whole point.
#macro RPS_TIER_N 5

/// Where the plate's surface sits in the composed unit box.
///
/// ⛔ IT IS NOT RPS_GROUND, AND THE DIFFERENCE IS WHY THE FIRST GALLERY LOOKED WRONG. RPS_GROUND
/// (0.44) is where a form's contact line sits INSIDE ITS OWN unit box, and a form's ink runs from
/// roughly y=0.08 to y=0.49 of that box — i.e. entirely in the lower half. Composing the plate at
/// 0.42 therefore stacked everything into the bottom of the frame: the top half of every image was
/// empty, every caption overprinted the plate, and seven of the eight store sheets failed their
/// content-coverage floor. MEASURED 2026-08-30 by baking the sheets and LOOKING at them; no
/// assertion in the 59-check suite could see it, because nothing was out of bounds and nothing
/// crashed. Putting the surface near the middle of the box centres the composition.
#macro RPS_PLATE_Y 0.09

/// The tier names, worst to best.
function rps_tier_names() {
    return ["ruined", "plain", "good", "fine", "masterwork"];
}

/// -- THE VESSEL --------------------------------------------------------------------------------

/// The plate, bowl or board itself, as a part list in the unit box.
///
/// _ware is a name from rps_ware_names(). _deep is 0 for a flat plate, 1 for a deep bowl; it is
/// continuous, so a buyer can have a shallow bowl.
///
/// ⚠️ THE RIM IS DRAWN AS A SEPARATE SUNKEN WELL RATHER THAN AS A RING ON A DISC. A ring drawn on
/// a disc is a line; a well is a change of surface, and it is what makes the food look like it is
/// sitting IN something. The difference costs about ten lines and it is most of why the plate
/// does not read as a coaster.
function rps_plate_form(_ware, _deep, _seed) {
    var _out = [];
    var _d = clamp(_deep, 0, 1);
    var _cy = RPS_PLATE_Y;

    // The outer disc, seen in a shallow three-quarter view: wider than it is tall.
    var _ry = 0.115 + _d * 0.055;
    var _outer = rps_ellipse_pts(0, _cy, 0.470, _ry, 34);
    rps_append(_out, rps_map_roles(rps_raise(_outer, 0.030 + _d * 0.030, 3, "m2"),
                                   rps_material_map("ware")));

    // The well. Deeper vessels have a proportionally smaller and lower well.
    var _wr = 0.470 * (0.84 - _d * 0.16);
    var _well = rps_ellipse_pts(0, _cy + _d * 0.014, _wr, _ry * (0.82 - _d * 0.10), 30);
    rps_append(_out, rps_map_roles(rps_sink(_well, 0.026 + _d * 0.026, 3, "m1"),
                                   rps_material_map("ware2")));

    // A wooden board gets a grain, and it is the only ware that does - grain on porcelain would
    // be a texture bug, and this is where a "just tint the plate" implementation gives itself
    // away.
    if (_ware == "board") {
        var _st = rps_rng(_seed);
        for (var _i = 0; _i < 9; _i++) {
            var _y = _cy - _ry * 0.72 + (_i / 8) * _ry * 1.44;
            var _c = rps_qbez([-0.44, _y], [0, _y + (rps_rng_next(_st) - 0.5) * 0.030],
                              [0.44, _y], 10);
            rps_append(_out, rps_map_roles(rps_incise(_c, false, 0.008),
                                           rps_material_map("ware2")));
        }
    }
    return _out;
}

/// A rim treatment. Only fine and masterwork dishes get one, which is a wealth and skill tell the
/// player reads without a caption.
///
/// ⛔ THE RIM IS TWO HALVES AND THEY LIVE ON OPPOSITE SIDES OF THE FOOD. This used to be one
/// closed ellipse appended LAST, on the reasoning that the rim should sit over anything
/// overhanging the plate edge. That reasoning is right about the NEAR edge and wrong about the
/// far one: the back of the rim is BEHIND anything standing on the plate, so drawing the whole
/// ring last ran a gilt line straight across the hero, the herbs and the garnish. MEASURED
/// 2026-08-30 by cropping sheet_1_hero.png and enlarging it - the band crosses the steak at
/// full opacity, on the hero image of the store page.
///
/// ⚠️ Nothing mechanical could see it. The ink box, the extent check and the density floor all
/// pass - a gilt line is ink, and it is ink exactly where the plate is. Splitting the ring is the
/// fix; the two functions below are called from different points in rps_plate_compose and must
/// stay that way.
///
/// _a in (0, pi) is the NEAR half because y grows downward. See rps_ellipse_arc_pts.

/// The far half of the rim. Belongs with the vessel, UNDER the food.
function rps_plate_rim_back(_ware, _deep, _tier) {
    var _out = [];
    if (_tier < 3) return _out;
    var _cy = RPS_PLATE_Y;
    var _ry = 0.115 + clamp(_deep, 0, 1) * 0.055;
    // A gilt line just inside the rim. Flat role: gilding is a reflection, not a shaded surface.
    array_push(_out, rps_ribbon(rps_ellipse_arc_pts(0, _cy, 0.432, _ry * 0.90, pi, RPS_TAU, 17), 0.007, "gild"));
    if (_tier >= 4) {
        // Masterwork adds a beaded rim - many small marks, count-carried.
        for (var _i = 0; _i < 30; _i++) {
            var _a = RPS_TAU * (_i / 30);
            if (sin(_a) < 0) {
                array_push(_out, rps_dot(cos(_a) * 0.452, _cy + sin(_a) * _ry * 0.95, 0.008, "gild"));
            }
        }
    }
    return _out;
}

/// The near half of the rim. Drawn LAST, so it still covers food overhanging the front edge -
/// which is the whole point the original single-ring version was reaching for.
function rps_plate_rim_front(_ware, _deep, _tier) {
    var _out = [];
    if (_tier < 3) return _out;
    var _cy = RPS_PLATE_Y;
    var _ry = 0.115 + clamp(_deep, 0, 1) * 0.055;
    array_push(_out, rps_ribbon(rps_ellipse_arc_pts(0, _cy, 0.432, _ry * 0.90, 0, pi, 17), 0.007, "gild"));
    if (_tier >= 4) {
        for (var _i = 0; _i < 30; _i++) {
            var _a = RPS_TAU * (_i / 30);
            if (sin(_a) >= 0) {
                array_push(_out, rps_dot(cos(_a) * 0.452, _cy + sin(_a) * _ry * 0.95, 0.008, "gild"));
            }
        }
    }
    return _out;
}

/// -- THE COMPOSITION ---------------------------------------------------------------------------

/// Where a component of _slot, index _i of _n, sits on the plate.
///
/// Returns { x, gy, s } — the x centre, the y where the component's CONTACT LINE lands, and its
/// scale. This is the whole layout rule and it is deliberately one readable function rather than
/// four scattered ones, because a buyer who wants a different look will edit exactly this.
///
/// ⛔ IT RETURNS A GROUND LINE, NOT A CENTRE, AND THAT DISTINCTION IS A REAL BUG THIS FILE ALREADY
/// SHIPPED ONCE. rps_place puts a part list's unit-box CENTRE at the point it is given — but every
/// form in this corpus is authored with its contact line at RPS_GROUND = 0.44, which is nowhere
/// near its centre. Returning a centre therefore put each form's ground at `y + 0.44 * s`, i.e.
/// well below wherever it was aimed, and MEASURED on the first in-engine run all twelve starter
/// recipes overflowed the box. Composing by the ground line is also simply the right model:
/// plating is a question about where things SIT, not where their bounding boxes are centred.
/// rps_plate_compose converts with `cy = gy - RPS_GROUND * s`.
function rps_plate_site(_slot, _i, _n, _w) {
    switch (_slot) {
        case "base":
            // Wide, low, centred, behind everything. Scale is driven by the form's own width want.
            return { x: 0.02, gy: RPS_PLATE_Y + 0.012, s: 0.70 * _w + 0.25 };

        case "hero":
            // ⛔ NOT AT THE CENTRE OF THE PLATE. Down and left, on the lamp side — dead-centre
            // composition is the most reliable way to make food look like a stock icon.
            return { x: -0.040, gy: RPS_PLATE_Y, s: 0.66 * _w + 0.30 };

        case "side": {
            // The fan. Sides are placed on an arc BEHIND the hero, spread by count so two sides
            // sit wide apart and three tuck closer together. The depth difference is what gives
            // the plate a front and a back.
            var _spread = (_n <= 1) ? 0 : ((_i / (_n - 1)) - 0.5) * 2;   // -1 .. +1
            // ⚠️ THE SPREAD IS 0.150, NOT 0.215, AND THE SCALE IS SMALLER. At the old numbers a
            // side's centre reached x = 0.33 and its own half width added 0.235 — 0.565 against a
            // plate radius of 0.47, so accompaniments floated off the edge of the plate. Measured
            // by looking at the recipe sheet.
            return {
                x: 0.095 + _spread * 0.150,
                gy: RPS_PLATE_Y - 0.028 - (1 - abs(_spread)) * 0.020,
                s: 0.30 * _w + 0.13,
            };
        }

        case "garn": {
            // Garnish sits high and small, offset from the hero so it does not bisect it.
            var _g = (_n <= 1) ? 0 : ((_i / (_n - 1)) - 0.5) * 2;
            return { x: -0.02 + _g * 0.195, gy: RPS_PLATE_Y - 0.075, s: 0.34 * _w + 0.14 };
        }
    }
    return { x: 0, gy: RPS_PLATE_Y - 0.020, s: 0.45 };
}

/// The unit-box centre a component must be placed at so its contact line lands on _gy at scale _s.
///
/// One line, in one place, so no call site can get the conversion subtly wrong — which is exactly
/// how the defect above survived being written four times in rps_plate_compose.
function rps_plate_centre(_gy, _s) {
    return _gy - RPS_GROUND * _s;
}

/// Compose a whole plated dish into one part list, ready to draw or to bake into a sprite.
///
/// _dish is the struct rps_recipe_cook() returns. This function reads it and never mutates it.
///
/// ⚠️ EVERY COMPONENT IS PLACED THROUGH rps_place, WHICH SCALES STROKE WIDTHS AND ARC RADII TOO.
/// Placing by editing point coordinates directly would leave a garnish drawn at 0.4 scale
/// carrying full-size stroke widths - the exact defect that makes small elements look like they
/// were pasted from a different drawing.
function rps_plate_compose(_dish) {
    var _out = [];
    var _seed = _dish.seed;

    // 1. The vessel, and with it the FAR half of the rim - it is behind everything that stands on
    // the plate. See rps_plate_rim_back for why this is not one ring drawn at the end.
    rps_append(_out, rps_plate_form(_dish.ware, _dish.deep, _seed));
    rps_append(_out, rps_plate_rim_back(_dish.ware, _dish.deep, _dish.tier));

    // 2. The base, if the dish has one.
    if (_dish.base_form != "") {
        var _bs = rps_corpus_spec(_dish.base_form);
        var _bp = rps_plate_site("base", 0, 1, _bs.w);
        rps_append(_out, rps_map_roles(
            rps_place(rps_ingredient_form(_dish.base_form, _seed), _bp.x, rps_plate_centre(_bp.gy, _bp.s), _bp.s, 0,
                      _bp.s, undefined),
            rps_material_map("base")));
    }

    // 3. The hero.
    if (_dish.hero_form != "") {
        var _hs = rps_corpus_spec(_dish.hero_form);
        var _hp = rps_plate_site("hero", 0, 1, _hs.w);
        rps_append(_out, rps_map_roles(
            rps_place(rps_ingredient_form(_dish.hero_form, _seed + 1), _hp.x, rps_plate_centre(_hp.gy, _hp.s), _hp.s, 0,
                      _hp.s, undefined),
            rps_material_map("hero")));
    }

    // 4. The sides, fanned.
    var _sn = array_length(_dish.side_forms);
    for (var _i = 0; _i < _sn; _i++) {
        var _nm = _dish.side_forms[_i];
        var _sp = rps_plate_site("side", _i, _sn, rps_corpus_spec(_nm).w);
        rps_append(_out, rps_map_roles(
            rps_place(rps_ingredient_form(_nm, _seed + 7 + _i), _sp.x, rps_plate_centre(_sp.gy, _sp.s), _sp.s, 0,
                      _sp.s, undefined),
            rps_material_map("side")));
    }

    // 5. The garnish. Tier-gated - see rps_recipe_cook, which decides how many a dish earns.
    var _gn = array_length(_dish.garn_forms);
    for (var _i = 0; _i < _gn; _i++) {
        var _nm2 = _dish.garn_forms[_i];
        var _gp = rps_plate_site("garn", _i, _gn, rps_corpus_spec(_nm2).w);
        // ⚠️ STEAM IS PLACED HIGHER THAN ITS SITE SAYS, because it is authored in the top half of
        // the box (rps_corpus_is_airborne). Placing it like a normal garnish buries it in the
        // food. This is the one place in the package that asks the corpus that question.
        var _gy = rps_corpus_is_airborne(_nm2) ? (RPS_PLATE_Y - 0.140) : _gp.gy;
        rps_append(_out, rps_map_roles(
            rps_place(rps_ingredient_form(_nm2, _seed + 23 + _i), _gp.x, rps_plate_centre(_gy, _gp.s), _gp.s, 0,
                      _gp.s, undefined),
            rps_material_map("garn")));
    }

    // 6. The NEAR half of the rim goes LAST so it sits over anything that overhangs the front
    // edge of the plate. The far half was laid down with the vessel in step 1.
    rps_append(_out, rps_plate_rim_front(_dish.ware, _dish.deep, _dish.tier));

    return _out;
}

/// Draw a composed dish directly into a rectangle.
/// ⛔ A DRAW CALL REFUSES BY DRAWING NOTHING. There is no return value a caller could check and no
/// refusal value worth inventing, so drawing nothing is the honest behaviour for bad input.
function rps_plate_draw(_dish, _pal, _x, _y, _w, _h) {
    if (!is_struct(_dish) || !is_struct(_pal)) return;
    if (!is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_h)) return;
    rps_render_in_rect(rps_plate_compose(_dish), _pal, _x, _y, _w, _h, 0, undefined);
}

/// Bake a composed dish into a sprite.
///
/// ⚠️ THE CALLER OWNS THE SPRITE AND MUST sprite_delete IT, and this is the normal path for this
/// product rather than an optimisation: a cooked dish is an inventory item drawn into a slot, a
/// tooltip and a recipe page, often on one frame, and it does not change again until it is eaten.
/// Re-deriving that geometry every frame for every slot is the pathological case.
///
/// ⚠️ AND IT MUST NOT BE CALLED FROM A DRAW EVENT - see rps_render_to_sprite's own header.
/// ⛔ RETURNS -1 RATHER THAN A BLANK SPRITE, which sprite_exists() reports as false. A valid but EMPTY
/// sprite is the worst outcome for a buyer: nothing errors and the blit is simply invisible.
function rps_plate_to_sprite(_dish, _pal, _w, _h) {
    if (!is_struct(_dish) || !is_struct(_pal)) return -1;
    if (!is_numeric(_w) || !is_numeric(_h) || _w <= 0 || _h <= 0) return -1;
    return rps_render_to_sprite(rps_plate_compose(_dish), _pal, _w, _h, 0.04);
}
