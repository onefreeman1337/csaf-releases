{
  "$GMScript": "v1",
  "%Name": "rps_larder",
  "name": "rps_larder",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}