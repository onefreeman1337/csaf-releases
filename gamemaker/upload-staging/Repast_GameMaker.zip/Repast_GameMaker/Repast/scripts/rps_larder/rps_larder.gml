/// REPAST - rps_larder. The CORPUS, part 3: twelve egg, dairy, grain and pastry forms.
///
/// Same contract as rps_ingredient. See that file's header for the three rules every form keeps.
///
/// ⭐ THIS GROUP IS WHERE THE COOK MODEL EARNS ITS KEEP. A loaf, a pastry lid and a cheese are the
/// three things in a kitchen whose whole visual identity is BROWNING - pale dough and a dark crust
/// are the same object at two points on one trajectory. Every form here is authored PALE and let
/// the cook state darken it, rather than authored brown; that is why "underbaked" and "burnt" are
/// real states of these forms instead of two extra sprites nobody drew.
/// ============================================================================================

/// A fried egg: set white with a domed yolk sitting proud of it.
function rps_form_egg_fried(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.82));
    // The white is a wide irregular blob - the irregularity IS the form. A round white reads as a
    // poached egg or a sticker; a fried egg spreads unevenly in the pan.
    var _white = rps_blob_pts(0, RPS_GROUND - 0.075, 0.325, 0.115, 30, 0.155, _seed);
    rps_append(_out, rps_raise(_white, 0.030, 2, "m4"));
    // Lacy browned edge, on the lamp side only, carried by count.
    //
    // ⛔ SHORT POLYLINES, NOT rps_arc. An RPS_ARC part is bounded by its WHOLE CIRCLE — the corpus
    // measurement computes cy + r + w and does not sample the sweep — so eleven small arcs on the
    // upper rim of a circle centred at y=0.365 with r=0.32 reported this form's lowest ink at
    // y=0.696 when nothing was drawn below y=0.40. MEASURED by the in-engine self-test. Sampling
    // each arc into two points makes the reported bounds equal the real geometry, which keeps the
    // containment rule strict instead of teaching it to cry wolf.
    for (var _i = 0; _i < 11; _i++) {
        var _a = 3.3 + (_i / 10) * 2.6;
        var _r = 0.300 + (_i % 3) * 0.012;
        array_push(_out, rps_poly([[cos(_a) * _r, RPS_GROUND - 0.075 + sin(_a) * _r],
                                   [cos(_a + 0.16) * _r,
                                    RPS_GROUND - 0.075 + sin(_a + 0.16) * _r]],
                                  false, 0.007, "scorch"));
    }
    // The yolk, in its OWN fixed ramp, domed hard so it reads as liquid under a skin.
    rps_append(_out, rps_map_roles(rps_boss(-0.03, RPS_GROUND - 0.105, 0.115, 20),
                                   rps_material_map("yolk")));
    return _out;
}

/// A halved boiled egg: the white shell of it, and the yolk disc in the cup.
function rps_form_egg_halved(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.50));
    var _white = rps_ellipse_pts(0, RPS_GROUND - 0.135, 0.165, 0.135, 24);
    rps_append(_out, rps_raise(_white, 0.042, 3, "m4"));
    // The yolk sits in a SUNKEN cup, not on top: a halved egg's yolk is recessed into the white,
    // and drawing it raised is the single tell that says nobody looked at one.
    rps_append(_out, rps_map_roles(
        rps_sink(rps_ellipse_pts(0, RPS_GROUND - 0.135, 0.090, 0.078, 18), 0.020, 2, "m3"),
        rps_material_map("yolk")));
    return _out;
}

/// A wedge of cheese: a rind on two faces and an open paste with eyes in it.
function rps_form_cheese(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.70));
    var _wedge = [[-0.30, RPS_GROUND - 0.030], [-0.22, RPS_GROUND - 0.265],
                  [0.28, RPS_GROUND - 0.185], [0.30, RPS_GROUND - 0.035]];
    rps_append(_out, rps_raise(_wedge, 0.038, 3, "m3"));
    // The rind: a band along the top and right edges only. A rind all the way round would read as
    // an outline, which is the thing this whole package avoids.
    rps_append(_out, [rps_taper_ribbon([[-0.22, RPS_GROUND - 0.265], [0.28, RPS_GROUND - 0.185]],
                                       0.026, 0.026, "m0")]);
    rps_append(_out, [rps_taper_ribbon([[0.28, RPS_GROUND - 0.185], [0.30, RPS_GROUND - 0.035]],
                                       0.022, 0.022, "m0")]);
    // Eyes in the paste - sunken, various sizes, placed by the seeded scatter so no two wedges
    // of cheese in a game are the same wedge.
    var _st = rps_rng(_seed + 11);
    for (var _i = 0; _i < 7; _i++) {
        var _x = -0.20 + rps_rng_next(_st) * 0.44;
        var _y = RPS_GROUND - 0.055 - rps_rng_next(_st) * 0.155;
        rps_append(_out, rps_pit(_x, _y, 0.018 + rps_rng_next(_st) * 0.022, 10));
    }
    return _out;
}

/// A curl of butter on a dish - the one purely decorative form in the corpus, and it is here
/// because a pat of butter melting on something hot is a strong "this is a meal" signal.
function rps_form_butter(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.42));
    var _pat = rps_round_rect_pts(-0.135, RPS_GROUND - 0.135, 0.135, RPS_GROUND - 0.020,
                                  0.028, 3);
    rps_append(_out, rps_raise(_pat, 0.034, 3, "m4"));
    // The curl on top: three nested arcs, each smaller, which reads as a rolled ribbon of butter.
    for (var _i = 0; _i < 3; _i++) {
        rps_append(_out, rps_ridge(rps_arc_pts(0, RPS_GROUND - 0.085, 0.090 - _i * 0.026,
                                               3.5, 6.0, 10), false, 0.014));
    }
    // A melt pool spreading from the base, in the sauce ramp.
    rps_append(_out, rps_map_roles(
        [rps_fill(rps_blob_pts(0.02, RPS_GROUND + 0.005, 0.185, 0.038, 20, 0.20, _seed), "m1")],
        rps_material_map("sauce")));
    return _out;
}

/// A round loaf or roll: domed, with a slashed top that has opened in the oven.
function rps_form_loaf(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.76));
    var _body = rps_blob_pts(0, RPS_GROUND - 0.175, 0.285, 0.180, 26, 0.035, _seed);
    rps_append(_out, rps_raise(_body, 0.075, 3, "m2"));
    // ⭐ THE SLASH IS THE FORM AND IT IS A RIDGE, NOT A LINE. A baker's slash opens as the loaf
    // rises, so its lips stand PROUD of the crust either side. Drawn as an incision it reads as a
    // crack in a rock; drawn as a ridge with a pale lip it reads as bread.
    for (var _i = 0; _i < 3; _i++) {
        var _y = RPS_GROUND - 0.265 + _i * 0.070;
        var _c = rps_qbez([-0.155 + _i * 0.020, _y], [0.0, _y - 0.028],
                          [0.155 - _i * 0.020, _y], 10);
        rps_append(_out, rps_ridge(_c, false, 0.026));
        array_push(_out, rps_ribbon(_c, 0.008, "m4"));
    }
    // Flour dusting, count-carried.
    rps_append(_out, rps_scatter(0, RPS_GROUND - 0.215, 0.20, 0.075, 12, 0.011, _seed + 5));
    return _out;
}

/// A cut slice of bread: crust round three sides, open crumb inside.
function rps_form_breadslice(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.62));
    var _slice = [[-0.235, RPS_GROUND - 0.020], [-0.245, RPS_GROUND - 0.245],
                  [-0.10, RPS_GROUND - 0.325], [0.10, RPS_GROUND - 0.325],
                  [0.245, RPS_GROUND - 0.245], [0.235, RPS_GROUND - 0.020]];
    rps_append(_out, rps_raise(_slice, 0.030, 2, "m4"));
    // The crust band follows the domed top only, which is where a tin loaf's crust actually is.
    rps_append(_out, [rps_taper_ribbon([[-0.245, RPS_GROUND - 0.245], [-0.10, RPS_GROUND - 0.325],
                                        [0.10, RPS_GROUND - 0.325], [0.245, RPS_GROUND - 0.245]],
                                       0.028, 0.028, "m1")]);
    // ⭐ CRUMB IS THE HARDEST TEXTURE IN THE CORPUS AND IT IS PURE COUNT. Twenty-six small pits at
    // varying sizes. Any attempt to draw it with line width collapses to a grey wash at icon size.
    rps_append(_out, rps_scatter(0, RPS_GROUND - 0.165, 0.185, 0.115, 26, 0.017, _seed + 2));
    return _out;
}

/// A lattice-topped pie or tart: woven strips with filling showing between them.
function rps_form_lattice(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.86));
    // The filling first, so the lattice sits over it.
    rps_append(_out, rps_map_roles(
        [rps_fill(rps_ellipse_pts(0, RPS_GROUND - 0.155, 0.290, 0.160, 24), "m1")],
        rps_material_map("side")));
    // ⭐ THE WEAVE IS WHY THIS FORM EXISTS. Strips in one direction, then the other, with the
    // second set drawn OVER the first - a real lattice alternates, but at plate scale the
    // over-under is invisible and what reads is the grid plus the shadow each strip casts. Doing
    // the honest alternation costs a lot of geometry for nothing a player will ever see.
    for (var _i = 0; _i < 5; _i++) {
        var _x = -0.20 + _i * 0.10;
        var _c = rps_qbez([_x, RPS_GROUND - 0.290], [_x * 1.10, RPS_GROUND - 0.155],
                          [_x, RPS_GROUND - 0.020], 10);
        rps_append(_out, [rps_taper_ribbon(_c, 0.026, 0.026, "m3")]);
    }
    for (var _i = 0; _i < 4; _i++) {
        var _y = RPS_GROUND - 0.245 + _i * 0.062;
        var _c = rps_qbez([-0.265, _y], [0.0, _y - 0.020], [0.265, _y], 10);
        rps_append(_out, [rps_taper_ribbon(_c, 0.026, 0.026, "m4")]);
    }
    // The rim: a crimped edge all round, which is what makes it a pie rather than a grid.
    //
    // ⚠️ 28 SMALL CRIMPS, NOT 22 LARGE ONES. At r=0.028 the beads were bigger than the gaps
    // between them and the pie read as a caterpillar on the recipe sheet. A crimped pastry edge is
    // MANY SHALLOW folds - which is the count-and-length law again, applied to a rim.
    for (var _i = 0; _i < 28; _i++) {
        var _a = RPS_TAU * (_i / 28);
        rps_append(_out, rps_boss(cos(_a) * 0.290, RPS_GROUND - 0.155 + sin(_a) * 0.160,
                                  0.017, 8));
    }
    return _out;
}

/// A pleated dumpling: the belly, and the crimped seam along the top.
function rps_form_dumpling(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.60));
    var _body = rps_blob_pts(0, RPS_GROUND - 0.125, 0.215, 0.125, 22, 0.045, _seed);
    rps_append(_out, rps_raise(_body, 0.048, 3, "m3"));
    // The pleats: six, along an arc over the top. Each is a small ridge, and they are what turn a
    // pale lump into something a player recognises instantly.
    for (var _i = 0; _i < 6; _i++) {
        var _t = (_i + 0.5) / 6;
        var _x = lerp(-0.165, 0.165, _t);
        var _y = RPS_GROUND - 0.225 + abs(_t - 0.5) * 0.115;
        rps_append(_out, rps_ridge([[_x, _y], [_x + 0.020, _y + 0.075]], false, 0.020));
    }
    // A crisped base where it met the pan - the difference between steamed and fried, and the
    // cook model changes its colour without this form knowing anything about it.
    // ⚠️ r=0.175, NOT 0.200. At 0.200 the ribbon's lowest point plus its half width reached
    // y=0.535, outside the box — measured in engine. A slightly tighter base is also the better
    // drawing: the crisped foot of a dumpling is narrower than its belly.
    rps_append(_out, [rps_taper_ribbon(rps_arc_pts(0, RPS_GROUND - 0.135, 0.175, 0.35, 2.79, 12),
                                       0.020, 0.020, "m0")]);
    return _out;
}

/// A mound of rice or grain. Individual grains at the edge, mass in the middle - which is how a
/// pile of grain actually reads, and it is far cheaper than drawing four hundred grains.
function rps_form_grainmound(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.80));
    var _mound = rps_blob_pts(0, RPS_GROUND - 0.120, 0.300, 0.145, 26, 0.050, _seed);
    rps_append(_out, rps_raise(_mound, 0.060, 3, "m3"));
    // Grains: short strokes at the silhouette edge, at many angles, count-carried.
    var _st = rps_rng(_seed + 4);
    for (var _i = 0; _i < 34; _i++) {
        var _a = RPS_TAU * (_i / 34);
        var _r = 0.90 + rps_rng_next(_st) * 0.20;
        var _px = cos(_a) * 0.300 * _r;
        var _py = RPS_GROUND - 0.120 + sin(_a) * 0.145 * _r;
        var _ang = rps_rng_next(_st) * RPS_TAU;
        array_push(_out, rps_poly([[_px, _py],
                                   [_px + cos(_ang) * 0.030, _py + sin(_ang) * 0.018]],
                                  false, 0.007, "m4"));
    }
    return _out;
}

/// A nest of noodles: long strands coiled, with a few loose ends lifting out of the pile.
function rps_form_noodles(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.84));
    var _st = rps_rng(_seed + 6);
    // The coil: seven strands at different radii and phases. Overlapping ribbons ARE the form -
    // there is no underlying mass, which is right, because a nest of noodles is all edge.
    for (var _i = 0; _i < 7; _i++) {
        var _r = 0.115 + _i * 0.026;
        var _ph = rps_rng_next(_st) * RPS_TAU;
        var _pts = [];
        for (var _k = 0; _k <= 20; _k++) {
            var _a = _ph + (_k / 20) * 5.4;
            array_push(_pts, [cos(_a) * _r, RPS_GROUND - 0.120 + sin(_a) * _r * 0.52]);
        }
        rps_append(_out, [rps_taper_ribbon(_pts, 0.017, 0.017, (_i % 2 == 0) ? "m3" : "m2")]);
    }
    // Two loose ends lifting - the thing that stops a nest reading as a flat spiral.
    //
    // ⛔ LOW AND SHORT. The first version arced to y = RPS_GROUND - 0.29, which is well above the
    // nest itself, so in every dish using noodles a dark strand hooped OVER the food and read as a
    // carrying handle rather than as a noodle - clearly visible on the spoilage sheet, where it was
    // the dominant shape in all six cells. A strand lifting out of a nest rises a little and falls
    // back; it does not span the plate.
    for (var _i = 0; _i < 2; _i++) {
        var _sx = -0.10 + _i * 0.17;
        rps_append(_out, rps_strand(
            [_sx, RPS_GROUND - 0.150], [_sx + 0.04, RPS_GROUND - 0.215],
            [_sx + 0.11, RPS_GROUND - 0.170], 0.013, 0.008, "m4"));
    }
    return _out;
}

/// A wedge of tart: a pastry base, a set filling and a fruited top, seen from the side.
function rps_form_tartslice(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.74));
    // The pastry case, a shallow V so the slice reads as cut from a round.
    var _case = [[-0.28, RPS_GROUND - 0.020], [0.28, RPS_GROUND - 0.020],
                 [0.235, RPS_GROUND - 0.115], [-0.235, RPS_GROUND - 0.115]];
    rps_append(_out, rps_raise(_case, 0.026, 2, "m2"));
    // The filling, in the side ramp, sitting on the case.
    rps_append(_out, rps_map_roles(
        rps_raise([[-0.235, RPS_GROUND - 0.115], [0.235, RPS_GROUND - 0.115],
                   [0.205, RPS_GROUND - 0.215], [-0.205, RPS_GROUND - 0.215]], 0.024, 2, "m2"),
        rps_material_map("side")));
    // Fruit on top, in the garnish ramp.
    for (var _i = 0; _i < 4; _i++) {
        rps_append(_out, rps_map_roles(
            rps_boss(-0.145 + _i * 0.098, RPS_GROUND - 0.240, 0.055, 14),
            rps_material_map("garn")));
    }
    // A fluted edge on the pastry - four flutes, incised.
    for (var _i = 0; _i < 4; _i++) {
        var _x = -0.21 + _i * 0.14;
        rps_append(_out, rps_incise([[_x, RPS_GROUND - 0.022], [_x, RPS_GROUND - 0.110]],
                                    false, 0.014));
    }
    return _out;
}

/// A ladle of stew or pottage: a pool with pieces breaking the surface.
///
/// ⚠️ THE PIECES ARE HALF-SUNK, NOT SITTING ON TOP. A stew where every lump is fully drawn reads
/// as a pile of food with brown paint round it. Clipping each piece against the pool's own
/// silhouette is what makes it read as liquid with solids IN it.
function rps_form_stew(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.90));
    var _pool = rps_blob_pts(0, RPS_GROUND - 0.075, 0.345, 0.105, 28, 0.070, _seed);
    rps_append(_out, rps_map_roles(rps_raise(_pool, 0.026, 2, "m2"),
                                   rps_material_map("sauce")));
    var _st = rps_rng(_seed + 8);
    for (var _i = 0; _i < 7; _i++) {
        var _x = -0.24 + rps_rng_next(_st) * 0.48;
        var _y = RPS_GROUND - 0.055 - rps_rng_next(_st) * 0.070;
        var _r = 0.038 + rps_rng_next(_st) * 0.032;
        // A half-disc: the top of a piece showing above the surface.
        var _pts = rps_arc_pts(_x, _y, _r, pi, RPS_TAU, 10);
        array_push(_pts, [_x + _r, _y]);
        array_push(_pts, [_x - _r, _y]);
        rps_append(_out, rps_raise(_pts, _r * 0.45, 2, "m3"));
    }
    // A gloss highlight on the liquid, which is what says "wet".
    array_push(_out, rps_ribbon(rps_arc_pts(-0.05, RPS_GROUND - 0.085, 0.185, 3.6, 4.9, 10),
                                0.010, "gloss"));
    return _out;
}
