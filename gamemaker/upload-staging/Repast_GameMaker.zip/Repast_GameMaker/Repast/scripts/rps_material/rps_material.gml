/// REPAST - rps_material. What food is MADE of, and what COOKING does to it, as five-stop
/// relief ramps.
///
/// Every colour in this product is COMPUTED. There is no table of hex values in this package,
/// because a hex table is a thing a buyer cannot steer: ask it for "the same beef, four minutes
/// longer in the pan" and a table has no answer, while a ramp does.
///
/// -- WHAT A RAMP IS --------------------------------------------------------------------------
/// rps_relief shades a surface by how squarely it faces the lamp and returns one of five role
/// names, "m0" (facing away) through "m4" (facing the lamp). A MATERIAL is therefore five
/// colours, and rps_material_ramp() produces them.
///
/// ⛔ THE STOPS ARE SPACED IN OKLAB LIGHTNESS, NOT IN RGB. That is the whole reason rps_palette
/// exists. Five RGB-spaced stops on a pale poached egg and five on a dark braised shin have
/// visibly different contrast, and in this product those two sit ON THE SAME PLATE, lit by the
/// same lamp. Perceptual spacing is what lets one lamp light both correctly.
///
/// -- THE IDEA THIS FILE EXISTS FOR ------------------------------------------------------------
/// ⭐ A COOK STATE IS NOT A RECOLOUR. IT IS A TRAJECTORY.
///
/// The obvious implementation of "seared beef" is a second hex colour next to "raw beef". That
/// is what a texture pack does, and it is why a texture pack cannot answer "sear it a little
/// less". Here, a cook state is a set of COEFFICIENTS applied to whatever material it is given,
/// scaled by a continuous doneness 0..1 - so the same searing law browns beef, halloumi, a scallop
/// and a slice of bread, each from its own starting colour, and every intermediate value between
/// raw and done is a real colour rather than a blend of two pictures.
///
/// The coefficients are not arbitrary. They are what the Maillard reaction and caramelisation
/// actually do to a surface, in the three terms this colour model has:
///
///   LIGHTNESS  falls, always, and fastest at the end - browning accelerates once it starts.
///   CHROMA     RISES first (raw grey-pink beef -> saturated red-brown crust) and then COLLAPSES
///              as carbon takes over. A model that only darkens gives you mud at every setting;
///              the rise is what makes a crust look appetising rather than dirty.
///   HUE        travels toward red-amber (about 40 degrees) as sugars and amino acids brown, and
///              then toward neutral as it chars.
///   SPAN       widens when a surface crisps or glazes (a fried edge catches the lamp hard) and
///              narrows when it goes matte (ash, flour, a boiled surface).
///
/// ⚠️ THE CHROMA ARCH IS THE ONE TERM THAT MUST NOT BE SIMPLIFIED TO A LINE. It is why "charred"
/// and "seared" are different-looking states rather than the same state at two darknesses.
///
/// -- HOW A SECOND MATERIAL GETS ITS OWN RAMP -------------------------------------------------
/// rps_relief always emits m0..m4. A chop and the sauce under it are different materials, so the
/// sauce's parts are built in m0..m4 and then REMAPPED, once, at construction:
///
///     var _sauce = rps_map_roles(rps_raise(_pts, 0.02, 2), rps_material_map("sauce"));
///
/// rps_map_roles produces a new part list, which is exactly right for a property decided when the
/// piece is built and never changed again. Do NOT use the renderer's draw-time role map for this
/// - that one exists for drawing one borrowed mark once.
///
/// ⚠️ EVERY PREFIX USED IN A MAP MUST EXIST IN THE PALETTE. rps_render_colour falls back to
/// _pal.line for an unknown role, so a typo does not crash - it draws the whole sauce in the ink
/// colour and looks like a shading bug. rps_selftest asserts that every role any corpus form
/// emits resolves in the palette, which is the only way to catch it.
/// ============================================================================================

/// The number of named substances. Asserted against rps_material_names() by the suite, so the
/// list below and the names function can never drift apart silently.
#macro RPS_MAT_N 24

/// The chroma a browned crust carries, regardless of what it was before.
///
/// ⛔ BROWNING MANUFACTURES PIGMENT. See rps_material_ramp: a purely multiplicative chroma model
/// cannot brown a pale substance, because there is nothing to multiply — dough's raw chroma is
/// 0.036 and no sane multiplier turns that into a crust. MEASURED 2026-08-30: the trajectory sheet
/// showed a loaf going cream to GREY across ten steps, and the density gate flagged it at 288
/// colours. Beef starts at 0.098 and looked correct throughout, which is exactly why the error
/// survived: the model was tuned on the one substance that did not need this term.
#macro RPS_BROWN_C 0.088

/// The number of named cook states. Same contract.
#macro RPS_COOK_N 12

/// Each substance is a base lightness, a chroma, a hue in degrees, and how far the ramp spans in
/// lightness. A high span reads as a wet, glossy or crisp surface (glaze, fat, fish skin); a low
/// span reads as a soft matte one (flour, pulse, ash).
///
/// ⚠️ THESE ARE RAW VALUES. Every one of them is the substance BEFORE any heat; the cook state
/// supplies the rest. Reading a spec here should tell you what the thing looks like on the board,
/// not on the plate.
function rps_material_spec(_mat) {
    switch (_mat) {
        // name           L      C      hue    span   the surface being described
        case "beef":     return { L: 0.470, C: 0.098, h:  20, span: 0.26 }; // red muscle, wet
        case "pork":     return { L: 0.660, C: 0.062, h:  22, span: 0.24 }; // pale muscle
        case "poultry":  return { L: 0.760, C: 0.040, h:  70, span: 0.22 }; // breast meat
        case "game":     return { L: 0.380, C: 0.086, h:  14, span: 0.25 }; // dark close-grained
        case "fish":     return { L: 0.780, C: 0.028, h:  62, span: 0.34 }; // white flake, wet
        case "salmon":   return { L: 0.680, C: 0.120, h:  44, span: 0.32 }; // oily pink flesh
        case "shell":    return { L: 0.720, C: 0.078, h:  38, span: 0.40 }; // prawn, scallop
        case "fat":      return { L: 0.880, C: 0.030, h:  92, span: 0.42 }; // suet, rind, marbling
        case "root":     return { L: 0.640, C: 0.120, h:  62, span: 0.20 }; // carrot, parsnip, swede
        case "tuber":    return { L: 0.740, C: 0.048, h:  84, span: 0.18 }; // potato flesh
        case "brassica": return { L: 0.520, C: 0.104, h: 140, span: 0.19 }; // cabbage, sprout, kale
        case "leaf":     return { L: 0.560, C: 0.128, h: 132, span: 0.16 }; // herb, salad, spinach
        case "allium":   return { L: 0.820, C: 0.036, h:  96, span: 0.23 }; // onion, leek, garlic
        case "gourd":    return { L: 0.700, C: 0.140, h:  70, span: 0.21 }; // squash, pumpkin
        case "fungus":   return { L: 0.560, C: 0.040, h:  74, span: 0.20 }; // mushroom cap and stipe
        case "pulse":    return { L: 0.600, C: 0.068, h:  76, span: 0.14 }; // bean, lentil, pea
        case "grain":    return { L: 0.780, C: 0.052, h:  88, span: 0.15 }; // rice, barley, groats
        case "dough":    return { L: 0.850, C: 0.036, h:  90, span: 0.17 }; // raw paste, pastry
        case "cheese":   return { L: 0.810, C: 0.084, h:  92, span: 0.24 }; // pressed curd
        case "egg":      return { L: 0.930, C: 0.020, h:  96, span: 0.30 }; // set white
        case "yolk":     return { L: 0.800, C: 0.170, h:  84, span: 0.36 }; // the one saturated thing
        case "berry":    return { L: 0.420, C: 0.150, h:   2, span: 0.33 }; // dark fruit, glossy
        case "citrus":   return { L: 0.800, C: 0.155, h:  92, span: 0.30 }; // peel and segment
        case "nut":      return { L: 0.620, C: 0.078, h:  58, span: 0.22 }; // kernel
    }
    // ⚠️ A FALLBACK THAT LOOKS LIKE FOOD, NOT LIKE AN ERROR - a mistyped substance should be
    // findable by eye on a sheet of forty dishes, which a magenta placeholder would be, but it
    // must not crash a buyer's game mid-frame. The suite catches the typo; this keeps the game up.
    return { L: 0.600, C: 0.040, h: 74, span: 0.22 };
}

/// The substance names, in corpus order. Used by the self-test and the store sheets so that
/// neither can drift from the switch above without going red.
function rps_material_names() {
    return ["beef", "pork", "poultry", "game", "fish", "salmon", "shell", "fat",
            "root", "tuber", "brassica", "leaf", "allium", "gourd", "fungus", "pulse",
            "grain", "dough", "cheese", "egg", "yolk", "berry", "citrus", "nut"];
}

/// -- THE COOK STATES ---------------------------------------------------------------------------
///
/// dL     how far lightness falls at full doneness (negative raises it - blanching brightens)
/// dC     chroma multiplier at the PEAK of the arch (see arch below)
/// arch   where along 0..1 the chroma peak sits. 1.0 means chroma rises the whole way and never
///        collapses (candying); 0.35 means it peaks early and falls (charring).
/// flr    where the FALLING limb lands at full doneness, as a chroma multiplier
/// htgt   the hue this state browns TOWARD, in degrees
/// pull   how far toward htgt the hue travels at full doneness, 0..1
/// dspan  span multiplier at full doneness - above 1 crisps, below 1 goes matte
///
/// ⛔⛔ BROWNING IS A DESTINATION, NOT A DISPLACEMENT, AND GETTING THAT WRONG TURNED HALF THE
/// CORPUS OLIVE. This used to be a single \`dh\` added to the substance's own hue. For beef
/// (hue 20) +26 lands on 46, which is correct amber — so the model looked right on the one
/// substance it was tuned against. For poultry (hue 70) +32 lands on 102, which is yellow-GREEN,
/// and a roast bird came out the colour of a swamp. Dough, grain and allium went the same way.
/// MEASURED 2026-08-30 by baking the recipe sheet and LOOKING at it; nothing in the 59-assertion
/// suite could see it, because an olive chop is not out of gamut, not out of bounds and not a
/// crash. Everything that browns converges on the same amber from wherever it started, so the
/// state names a TARGET and a strength and the direction falls out of the arithmetic.
///
/// ⛔ `flr` IS PER STATE AND IT USED TO BE ONE HARD-CODED 0.18 FOR EVERYTHING. That made every
/// falling state arrive at the same chroma: seared and charred both ended at 0.180, which is the
/// exact "one texture at two brightnesses" failure the arch exists to prevent. The suite asserted
/// it and caught it on the first in-engine run. A seared crust taken to maximum is dark brown and
/// still chromatic; a charred one is carbon and close to neutral. Those are different floors.
///
/// ⚠️ AND THE WET METHODS WERE TOO WEAK TO SEE. At dL -0.03, steaming moved the mid ramp stop by
/// less than the suite's visibility threshold, so 47 of 264 substance/cook pairs came back
/// visually identical raw and done - which would have made three of the twelve methods decorative
/// names. Boiling really does pale and dull; steaming really does soften and set; candying really
/// does brighten and glaze. The coefficients now say so.
function rps_cook_spec(_cook) {
    switch (_cook) {
        // name            dL      dC    arch    flr   htgt  pull   dspan   what is happening
        case "raw":       return { dL:  0.00, dC: 1.00, arch: 1.00, flr: 1.00, htgt: 46, pull: 0.00, dspan: 1.00 };
        case "blanched":  return { dL: -0.09, dC: 1.28, arch: 1.00, flr: 1.28, htgt: 46, pull: 0.04, dspan: 1.12 }; // set colour
        case "steamed":   return { dL: -0.11, dC: 0.76, arch: 1.00, flr: 0.76, htgt: 46, pull: 0.03, dspan: 0.70 }; // soft matte
        case "boiled":    return { dL:  0.07, dC: 0.50, arch: 1.00, flr: 0.50, htgt: 50, pull: 0.10, dspan: 0.58 }; // leached
        case "poached":   return { dL: -0.08, dC: 0.78, arch: 1.00, flr: 0.78, htgt: 46, pull: 0.05, dspan: 1.04 }; // pale, wet
        case "seared":    return { dL:  0.20, dC: 1.45, arch: 0.78, flr: 0.62, htgt: 44, pull: 0.62, dspan: 1.26 }; // Maillard
        case "roasted":   return { dL:  0.26, dC: 1.38, arch: 0.66, flr: 0.55, htgt: 46, pull: 0.70, dspan: 1.16 };
        case "fried":     return { dL:  0.22, dC: 1.52, arch: 0.74, flr: 0.70, htgt: 52, pull: 0.66, dspan: 1.42 }; // crisp, glossy
        case "braised":   return { dL:  0.30, dC: 1.10, arch: 0.58, flr: 0.48, htgt: 40, pull: 0.78, dspan: 0.94 }; // long, wet
        case "charred":   return { dL:  0.52, dC: 1.30, arch: 0.32, flr: 0.10, htgt: 38, pull: 0.55, dspan: 0.62 }; // carbon
        case "candied":   return { dL: -0.13, dC: 1.65, arch: 1.00, flr: 1.65, htgt: 58, pull: 0.42, dspan: 1.70 }; // glassy sugar
        case "cured":     return { dL:  0.14, dC: 1.34, arch: 0.86, flr: 0.80, htgt: 18, pull: 0.45, dspan: 0.78 }; // salt, time
    }
    return { dL: 0.00, dC: 1.00, arch: 1.00, flr: 1.00, htgt: 46, pull: 0.00, dspan: 1.00 };
}

function rps_cook_names() {
    return ["raw", "blanched", "steamed", "boiled", "poached", "seared",
            "roasted", "fried", "braised", "charred", "candied", "cured"];
}

/// The chroma arch. Returns the chroma MULTIPLIER at doneness _t for a state whose peak
/// multiplier is _peak and whose peak sits at _arch.
///
/// ⛔ THIS IS THE FUNCTION THAT MAKES COOKED FOOD LOOK LIKE FOOD, and getting it wrong is the
/// difference between a crust and a stain. Below the peak, chroma climbs from 1.0 to _peak.
/// Above it, it falls toward a near-grey floor. A single linear ramp - the obvious version -
/// makes "charred" and "seared" the same hue at two lightnesses, which is exactly the "one
/// texture, two brightnesses" tell this product is sold against.
///
/// ⚠️ THE FLOOR IS NEVER 0, AND IT IS PER STATE. Pure carbon is neutral, but a real charred
/// surface still carries the food under it and reads warm-black rather than blue-black; at 0 the
/// darkest state went slightly COOL, because the chroma ceiling in rps_palette pulls low-L colours
/// toward neutral and neutral against a warm plate reads blue. And a SEARED surface's floor is
/// nowhere near a charred one's - see rps_cook_spec.flr.
function rps_cook_chroma(_t, _peak, _arch, _floor) {
    var _a = clamp(_arch, 0.02, 1.0);
    var _f = is_undefined(_floor) ? 0.18 : _floor;
    if (_t <= _a) {
        // Rising limb. Normalised so t=0 gives 1.0 and t=_a gives _peak.
        return 1.0 + (_peak - 1.0) * (_t / _a);
    }
    // Falling limb, from _peak at t=_a down toward this state's own floor at t=1.
    var _u = (_t - _a) / max(0.02, 1.0 - _a);
    return _peak + (_f - _peak) * _u;
}

/// Five stops for one substance at one cook state and doneness.
///
/// _done is 0..1 within the state. At 0 the food is exactly its raw spec whatever state is named,
/// which is deliberate: it means a buyer can drive one dial from raw to done without switching
/// state names, and it means the raw corpus and the cooked corpus are the same corpus.
///
/// _hue_shift lets one substance serve a whole cuisine without becoming a palette swap: the SAME
/// root runs orange as carrot and pale gold as parsnip, which is a real difference between real
/// ingredients rather than a recolour of one texture.
function rps_material_ramp(_mat, _cook, _done, _hue_shift) {
    var _s = rps_material_spec(_mat);
    var _c = rps_cook_spec(_cook);
    var _t = clamp(_done, 0, 1);
    var _hs = is_undefined(_hue_shift) ? 0 : _hue_shift;

    // ⛔ LIGHTNESS FALLS ON A CURVE, NOT A LINE. Browning accelerates: the first half of a sear
    // barely changes the colour and the second half changes all of it. A linear fall put the
    // visible change in the wrong half of the dial, so every dish at done=0.5 already looked
    // cooked and the top half of the range did nothing.
    var _fall = _t * _t * (3 - 2 * _t);   // smoothstep
    var _L = clamp(_s.L - _c.dL * _fall, 0.05, 0.97);

    // ⛔ PULL TOWARD THE CRUST CHROMA FIRST, THEN APPLY THE ARCH. The pull is what lets a pale
    // substance brown at all; the arch is what makes a crust rise and then collapse into carbon.
    // Doing only the second gives you grey bread.
    var _Cb = _s.C + (RPS_BROWN_C - _s.C) * _c.pull * _fall;
    var _C = max(0, _Cb * rps_cook_chroma(_t, _c.dC, _c.arch, _c.flr));
    // ⛔ A PULL TOWARD THE TARGET, NEVER AN ADDITION. See rps_cook_spec's header: adding a fixed
    // displacement browns beef correctly and turns poultry, dough and grain olive, because they
    // start on the other side of the target.
    var _h = _s.h + (_c.htgt - _s.h) * _c.pull * _fall + _hs;
    var _span = _s.span * (1 + (_c.dspan - 1) * _t);

    var _out = array_create(RPS_RAMP_N);
    for (var _i = 0; _i < RPS_RAMP_N; _i++) {
        // -0.5 .. +0.5 across the five stops, so the nominal L stays the mid stop and a spec can
        // be read as "the colour of the food" rather than "the colour of its shadow".
        var _k = (_i / (RPS_RAMP_N - 1)) - 0.5;
        var _Li = clamp(_L + _span * _k, 0.04, 0.98);
        // Chroma falls in the shadows, as it does in life: the dark side of a red berry is browner
        // than its lit side, never a more saturated red.
        var _Ci = _C * (1 + 0.35 * _k);
        _out[_i] = rps_oklch(_Li, max(0, _Ci), _h);
    }
    return _out;
}

/// The role map that points rps_relief's m0..m4 at a named ramp in the palette.
///
/// Returned as a fresh struct every call rather than cached, because rps_map_roles reads it once
/// and a shared mutable map is the kind of thing that works until two dishes are plated in the
/// same frame.
function rps_material_map(_prefix) {
    return {
        m0: _prefix + "0", m1: _prefix + "1", m2: _prefix + "2",
        m3: _prefix + "3", m4: _prefix + "4",
    };
}

/// Write one substance's five stops into a palette struct under a prefix.
function rps_material_into(_pal, _prefix, _mat, _cook, _done, _hue_shift) {
    var _r = rps_material_ramp(_mat, _cook, _done, _hue_shift);
    for (var _i = 0; _i < RPS_RAMP_N; _i++) {
        variable_struct_set(_pal, _prefix + string(_i), _r[_i]);
    }
    return _pal;
}

/// -- SERVICE WARE ------------------------------------------------------------------------------
/// The plate is not food and does not brown, so it has its own small spec table rather than
/// sharing the cook model. Eight of them, and they are a large part of why two dishes with the
/// same contents do not look alike.
#macro RPS_WARE_N 8

function rps_ware_spec(_ware) {
    switch (_ware) {
        // name            L      C      hue    span   the vessel being described
        case "earthen":  return { L: 0.520, C: 0.072, h:  42, span: 0.26 }; // red earthenware
        case "porcelain":return { L: 0.900, C: 0.010, h: 240, span: 0.34 }; // fine white, glazed
        case "stoneware":return { L: 0.640, C: 0.026, h:  76, span: 0.22 }; // grey-buff, matte
        case "pewter":   return { L: 0.560, C: 0.008, h: 248, span: 0.50 }; // struck metal
        case "copper":   return { L: 0.560, C: 0.110, h:  46, span: 0.48 }; // pan, beaten
        case "iron":     return { L: 0.255, C: 0.010, h: 250, span: 0.44 }; // skillet, black
        case "board":    return { L: 0.480, C: 0.058, h:  62, span: 0.28 }; // wooden trencher
        case "leafware": return { L: 0.470, C: 0.110, h: 138, span: 0.20 }; // banana leaf, husk
    }
    return { L: 0.600, C: 0.030, h: 70, span: 0.26 };
}

/// Is _want one of the names in _list. Lives beside rps_ware_names so "is this a real vessel" is
/// asked in exactly one place.
function rps_name_in(_list, _want) {
    for (var _i = 0; _i < array_length(_list); _i++) if (_list[_i] == _want) return true;
    return false;
}

function rps_ware_names() {
    return ["earthen", "porcelain", "stoneware", "pewter",
            "copper", "iron", "board", "leafware"];
}

/// Five stops for a vessel. _wear is age and use: it darkens, desaturates and COMPRESSES, the
/// same three-term law the rest of this catalogue uses for age.
function rps_ware_ramp(_ware, _wear, _hue_shift) {
    var _s = rps_ware_spec(_ware);
    var _w = clamp(_wear, 0, 1);
    var _hs = is_undefined(_hue_shift) ? 0 : _hue_shift;

    var _L = _s.L * (1 - 0.34 * _w);
    var _C = _s.C * (1 - 0.50 * _w);
    var _span = _s.span * (1 - 0.42 * _w);

    var _out = array_create(RPS_RAMP_N);
    for (var _i = 0; _i < RPS_RAMP_N; _i++) {
        var _k = (_i / (RPS_RAMP_N - 1)) - 0.5;
        _out[_i] = rps_oklch(clamp(_L + _span * _k, 0.04, 0.98),
                             max(0, _C * (1 + 0.35 * _k)), _s.h + _hs);
    }
    return _out;
}

function rps_ware_into(_pal, _prefix, _ware, _wear, _hue_shift) {
    var _r = rps_ware_ramp(_ware, _wear, _hue_shift);
    for (var _i = 0; _i < RPS_RAMP_N; _i++) {
        variable_struct_set(_pal, _prefix + string(_i), _r[_i]);
    }
    return _pal;
}

/// ============================================================================================
/// THE DISH PALETTE
///
/// One struct holding every ramp a plated dish needs. Built once per dish, handed to every draw
/// call, and never rebuilt per frame - it is about a hundred colour conversions and there is no
/// reason to pay for them a hundred times a second.
///
/// ⚠️ THE FLAT ROLES AT THE BOTTOM ARE NOT RELIEF ROLES and must not be shaded. `steam` is one
/// colour because vapour has no surface; giving it a five-stop ramp would light a cloud from a
/// lamp it does not reflect, which is the tell that says "this is a sprite, not a dish".
/// ============================================================================================
function rps_palette_build(_dish) {
    if (!is_struct(_dish)) return undefined;
    var _wear = clamp(_dish.ware_wear, 0, 1);
    var _hs   = _dish.hue_shift;

    var _pal = {};

    // The vessel, and the rim treatment which is a WEALTH TELL: the same shape in porcelain with
    // a gilt line and in a worn wooden trencher are two different meals.
    rps_ware_into(_pal, "ware",  _dish.ware,  _wear,                     _hs * 0.4);
    rps_ware_into(_pal, "ware2", _dish.ware,  clamp(_wear + 0.22, 0, 1), _hs * 0.4);
    rps_ware_into(_pal, "board", "board",     clamp(_wear + 0.10, 0, 1), _hs * 0.4);
    rps_ware_into(_pal, "metal", "pewter",    _wear * 0.8,               0);
    // ⛔ THE INTERFACE NEEDS ITS OWN RAMP. rps_ui_panel and rps_ui_well build on rps_raise/rps_sink,
    // whose bevel walls emit m0..m4 — and m0..m4 default to the HERO ramp, so an unmapped panel is
    // drawn in the colour of the meat. Giving the UI a ramp of its own is what lets the chrome be
    // lit by the same lamp as the food without being made of it.
    rps_ware_into(_pal, "ui",    "stoneware", 0.42,                      _hs * 0.2);

    // The food. FOUR component slots, because a plated dish in this product is a base, a hero,
    // an accompaniment and a garnish - and every recipe fills them from its own ingredients.
    rps_material_into(_pal, "base",  _dish.base_mat,  _dish.base_cook,  _dish.base_done,  _hs);
    rps_material_into(_pal, "hero",  _dish.hero_mat,  _dish.hero_cook,  _dish.hero_done,  _hs);
    rps_material_into(_pal, "side",  _dish.side_mat,  _dish.side_cook,  _dish.side_done,  _hs);
    rps_material_into(_pal, "garn",  _dish.garn_mat,  _dish.garn_cook,  _dish.garn_done,  _hs);

    // ⛔ THREE RAMPS THAT DO NOT DEPEND ON THE RECIPE, because three things on a plate have a
    // fixed identity. An egg yolk is yolk-coloured in every dish ever cooked; a herb leaf is
    // green; citrus peel is citrus. These were originally drawn through the recipe's garn slot,
    // which meant a fried egg served with a herb garnish had a GREEN YOLK — measured by opening
    // the corpus sheet and looking at it. A slot is for what the recipe chooses; these are not
    // choices.
    rps_material_into(_pal, "yolk",  "yolk",   "raw", 0, _hs * 0.3);
    rps_material_into(_pal, "leafm", "leaf",   "raw", 0, _hs * 0.3);
    rps_material_into(_pal, "peel",  "citrus", "raw", 0, _hs * 0.3);
    // ⛔ BONE IS NOT THE PLATE. Every bone, eye and knuckle in the corpus was drawn through the
    // "ware" ramp - the ramp of whatever the dish is SERVED ON - because both happen to be pale.
    // On a pewter plate the chop's bone came out grey metal (visible on the cook sheet, where it
    // reads as a bolt); on copper it would be copper and on iron it would be black. A bone is
    // cream in every kitchen there has ever been. MEASURED by looking at the baked sheet.
    rps_material_into(_pal, "bone",  "fat",    "raw", 0, _hs * 0.2);

    // The sauce is derived from the hero rather than named separately, because a sauce made in the
    // pan IS the hero's browning dissolved into liquid. Deriving it is what stops a buyer having
    // to pick a sauce colour that matches the meat they chose.
    // ⛔ ONE STOP DARKER AND MORE CHROMATIC THAN THE HERO, NOT THE SAME. Drawn in the hero ramp
    // the sauce vanished into the meat it was poured over on every dark dish - two objects, one
    // colour, no edge. A sauce reads as a sauce because it is GLOSSIER and DEEPER than the thing
    // under it.
    rps_material_into(_pal, "sauce", _dish.hero_mat, "braised",
                      clamp(_dish.hero_done * 0.7 + 0.35, 0, 1), _hs + 6);

    // m0..m4 unmapped default to the HERO, so a form that forgets to remap draws as the main
    // ingredient rather than as the ink colour. A visible-but-wrong material is far easier to
    // spot than a black one.
    for (var _i = 0; _i < RPS_RAMP_N; _i++) {
        variable_struct_set(_pal, "m" + string(_i),
                            variable_struct_get(_pal, "hero" + string(_i)));
    }

    // -- flat roles ----------------------------------------------------------------------------
    // ⛔ STEAM IS THE ONLY THING ON THE PLATE THAT IS NOT A SURFACE, and it is drawn in flat roles
    // for exactly that reason. Shading vapour by the lamp normal would give a cloud a lit face and
    // a shadowed face, which the eye reads instantly as a cotton-wool sprite.
    _pal.steam     = rps_oklch(0.88, 0.008, 240);
    _pal.steam_lo  = rps_oklch(0.72, 0.010, 236);

    // Gloss and gilding. Gloss is a HIGHLIGHT colour, not a material: it is drawn as a thin mark
    // on top of whatever it sits on, at the lamp side, and it is what separates a glazed carrot
    // from a boiled one at a glance.
    _pal.gloss     = rps_oklch(0.96, 0.020, 92);
    _pal.gild      = rps_oklch(0.78, 0.095, 88);
    _pal.scorch    = rps_oklch(0.16, 0.014, 44);   // scorch marks, grill bars
    _pal.crumb     = rps_oklch(0.74, 0.048, 78);   // scattered crumb, dusting, seed
    _pal.ash       = rps_oklch(0.60, 0.008, 250);

    // ⛔ THE LABEL COLOUR IS FIXED AND IS NOT DERIVED FROM ANY MATERIAL. The wing has paid for
    // this twice: captions drawn in a material's lightest stop are illegible on whichever backdrop
    // that material happens to be near. There is no single label colour that reads on a white
    // porcelain plate AND on a dark page, so the label does not try - it is drawn light with a
    // dark shadow under it, and the PAIR reads on both.
    _pal.label     = rps_oklch(0.94, 0.018, 86);
    _pal.label_sh  = rps_oklch(0.12, 0.010, 250);
    _pal.line      = rps_oklch(0.22, 0.010, 70);   // the fallback ink
    _pal.ground    = rps_oklch(0.15, 0.014, 250);  // page/backdrop base
    _pal.felt      = rps_oklch(0.23, 0.016, 250);  // UI well face
    _pal.panel     = rps_oklch(0.31, 0.014, 252);  // UI panel face
    _pal.cloth     = rps_oklch(0.30, 0.020, 60);   // table linen under the plate
    _pal.shadow    = rps_oklch(0.12, 0.012, 254);  // contact shadow under a piece

    return _pal;
}

/// Every role name a palette built by rps_palette_build actually contains.
///
/// ⛔ THIS EXISTS SO THE SELF-TEST CAN CHECK A NON-EMPTY SET. An "every role a form emits resolves
/// in the palette" assertion is vacuously true if the role list comes back empty, and this factory
/// has shipped exactly that: a strict-subset check that passed over zero extracted entries and
/// reported clean. The suite asserts this list is long BEFORE it asserts anything with it.
function rps_palette_roles(_pal) {
    return variable_struct_get_names(_pal);
}
