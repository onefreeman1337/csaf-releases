/// REPAST - rps_ingredient. The CORPUS: forty-six hand-authored ingredient forms.
///
/// This file is the product's moat and it is the file to read first if you are deciding whether
/// this package is worth its price. Everything else here is machinery; this is content, and
/// content is the thing an afternoon with a code generator does not produce.
///
/// ⛔ THERE IS NO SPRITE, NO ATLAS AND NO TEXTURE PAGE IN THIS PACKAGE. `sprites/` does not
/// exist. Every form below is geometry, authored by hand in a unit box, and shaded at draw time
/// by rps_relief against one lamp. That is why a carrot cooked three different ways is three
/// genuinely different pictures instead of one picture tinted three times.
///
/// -- THE CONTRACT EVERY FORM KEEPS -------------------------------------------------------------
/// A form function takes (_seed) and returns a PART LIST in the unit box, [-0.5, 0.5] on both
/// axes, y DOWN. It obeys three rules and the self-test checks all three:
///
///   1. IT SITS ON RPS_GROUND. The lowest drawn point of the form is at y = RPS_GROUND, so any
///      two forms authored months apart sit on the same plate without a per-form fudge.
///   2. IT STAYS INSIDE THE UNIT BOX. rps_render_bounds must not exceed [-0.5, 0.5].
///   3. IT EMITS ONLY m0..m4 (plus the flat roles named in its spec). The caller decides what
///      substance it is made of by remapping, which is what lets ONE dumpling form serve a pork
///      dumpling, a prawn dumpling and a sweet one.
///
/// ⚠️ RULE 3 IS WHY THE CORPUS IS SMALLER THAN THE CATALOGUE IT PRODUCES. 46 forms x 24
/// substances x 12 cook states is not a marketing number, it is the literal size of the space,
/// because the form, the substance and the cook state are three independent axes by construction.
///
/// -- WHAT MAKES A FORM GOOD RATHER THAN PRESENT ------------------------------------------------
/// ⛔ THE TEMPTATION IS AN OUTLINE WITH A FILL. That reads as a sticker and it is what the engine
/// gives you for free. Every form here carries at least one of: a RAISED mass with a bevelled
/// wall (so it has a lit and a shadowed side), an INCISED or RIDGED line (so it has surface),
/// and a CONTACT SHADOW (so it sits on the plate rather than floating over it).
///
/// ⚠️ AND THE DETAIL IS CARRIED BY COUNT AND LENGTH, NEVER BY LINE WIDTH. draw_line_width floors
/// every stroke at 1.0px unantialiased, so at a 64px inventory icon an authored width range
/// collapses to one pixel and a carefully tuned gradient becomes a barcode. Where a form needs
/// tone - the crumb of a loaf, the grain of a cut of meat - it uses MORE, SHORTER strokes, never
/// wider ones. This cost the wing a session on a previous product and the rule is not negotiable.
/// ============================================================================================

/// The number of authored forms. Asserted against rps_ingredient_names() by the suite so the
/// dispatch and the list can never drift apart silently.
#macro RPS_FORM_N 46

/// ============================================================================================
/// SHARED FORM HELPERS
///
/// Small builders used by several forms. They are here rather than in rps_geom because they know
/// what food looks like, and rps_geom deliberately knows nothing about the subject.
/// ============================================================================================

/// The contact shadow every form that touches the plate carries.
///
/// ⛔ AN ELLIPSE, NOT A COPY OF THE SILHOUETTE. A silhouette-shaped shadow reads as a second flat
/// object lying under the first, because a real contact shadow is softened by the distance
/// between the object and the surface and loses the outline almost immediately. The ellipse is
/// wider than the form and much shallower, which is what a small object on a flat plate casts.
///
/// ⛔ THE DEPTH COEFFICIENT IS 0.045 AND IT USED TO BE 0.10, WHICH DID NOT FIT. At 0.10 the widest
/// forms put their shadow's lowest point at RPS_GROUND + 0.012 + 0.09 = 0.542, and the unit box
/// ends at 0.5 - so stew, lattice, noodles, fish, mash, bird and sausage all failed the corpus
/// containment rule. MEASURED by the first in-engine self-test run. The fix is a shallower shadow
/// rather than a wider tolerance, and it is also more truthful: a contact shadow is very shallow,
/// and a deep one reads as a second object lying under the first.
function rps_contact(_cx, _w, _dark) {
    var _d = is_undefined(_dark) ? "shadow" : _dark;
    return [rps_fill(rps_ellipse_pts(_cx, RPS_GROUND + 0.012, _w * 0.54, _w * 0.045, 20), _d)];
}

/// A rounded organic blob: an ellipse pushed around by a seeded noise so no two are identical.
///
/// ⚠️ THE WOBBLE IS IN THE RADIUS, NOT IN THE POINTS. Jittering each point independently makes a
/// crinkled edge that reads as damage; modulating the radius with two slow sine terms makes an
/// edge that reads as a natural, slightly irregular object, which is what almost everything in a
/// kitchen actually is.
function rps_blob_pts(_cx, _cy, _rx, _ry, _n, _amp, _seed) {
    var _st = rps_rng(_seed);
    var _p0 = rps_rng_next(_st) * RPS_TAU;
    var _p1 = rps_rng_next(_st) * RPS_TAU;
    var _pts = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _a = RPS_TAU * (_i / _n);
        var _k = 1 + _amp * (sin(_a * 3 + _p0) * 0.6 + sin(_a * 5 + _p1) * 0.4);
        _pts[_i] = [_cx + cos(_a) * _rx * _k, _cy + sin(_a) * _ry * _k];
    }
    return _pts;
}

/// Rotate a point about a pivot.
///
/// ⛔ THIS EXISTS BECAUSE rps_map_pt IS NOT IT, AND THE DIFFERENCE SHIPPED A BROKEN FORM.
/// rps_map_pt maps a point FROM THE UNIT-BOX ORIGIN to a centre - it is a PLACEMENT transform.
/// Handing it a point that is already in form space translates it by the pivot a SECOND time.
/// MEASURED 2026-08-30 by the first in-engine self-test run: the grill bars drawn on the steak
/// were not on the steak, and chop and egg_fried reported their lowest ink at y=0.622 and y=0.696
/// against a unit box that ends at 0.5. Nothing that only reads the source could have seen it -
/// both calls type-check and both compile.
function rps_rot_about(_p, _cx, _cy, _cos, _sin) {
    var _dx = _p[0] - _cx, _dy = _p[1] - _cy;
    return [_cx + _dx * _cos - _dy * _sin, _cy + _dx * _sin + _dy * _cos];
}

/// Parallel scoring across a shape - grill bars, knife scores, the ridges of a fork through mash.
/// COUNT and LENGTH carry the tone; the width is left at the floor deliberately.
function rps_score(_x0, _y0, _x1, _y1, _count, _role, _rot) {
    var _out = [];
    var _r = is_undefined(_rot) ? 0 : _rot;
    var _cx = (_x0 + _x1) * 0.5, _cy = (_y0 + _y1) * 0.5;
    var _c = cos(_r), _s = sin(_r);
    for (var _i = 0; _i < _count; _i++) {
        var _t = (_i + 0.5) / _count;
        var _y = lerp(_y0, _y1, _t);
        var _a = [_x0, _y], _b = [_x1, _y];
        if (_r != 0) {
            _a = rps_rot_about(_a, _cx, _cy, _c, _s);
            _b = rps_rot_about(_b, _cx, _cy, _c, _s);
        }
        array_push(_out, rps_poly([_a, _b], false, 0.006, _role));
    }
    return _out;
}

/// A scatter of small raised beads inside an ellipse - seeds, peppercorns, capers, pomegranate.
/// Deterministic from the seed, so the same dish looks the same every time it is drawn.
function rps_scatter(_cx, _cy, _rx, _ry, _count, _r, _seed) {
    var _st = rps_rng(_seed);
    var _out = [];
    for (var _i = 0; _i < _count; _i++) {
        // Rejection-free placement: pick an angle and a SQUARE-ROOT radius so the beads are
        // uniform over the area rather than piled in the middle, which is what a naive uniform
        // radius does and it looks like a target.
        var _a = rps_rng_next(_st) * RPS_TAU;
        var _u = sqrt(rps_rng_next(_st));
        var _rr = _r * (0.72 + 0.56 * rps_rng_next(_st));
        rps_append(_out, rps_boss(_cx + cos(_a) * _rx * _u, _cy + sin(_a) * _ry * _u, _rr, 8));
    }
    return _out;
}

/// A tapered organic strand - a herb stem, a noodle, a drizzle of sauce.
function rps_strand(_p0, _p1, _p2, _w0, _w1, _role) {
    return [rps_taper_ribbon(rps_qbez(_p0, _p1, _p2, 14), _w0, _w1, _role)];
}

/// ============================================================================================
/// THE CORPUS - 46 FORMS
///
/// Grouped by what they are, because that is how a buyer looks for one. Every function is
/// rps_form_<name> and every one is reachable through rps_ingredient_form().
/// ============================================================================================

/// -- MEAT AND FISH (10) ------------------------------------------------------------------------

/// A bone-in chop: the eye of meat, a rim of fat, and the bone standing proud of both.
function rps_form_chop(_seed) {
    var _out = [];
    var _eye = rps_blob_pts(-0.04, RPS_GROUND - 0.17, 0.24, 0.155, 26, 0.075, _seed);
    rps_append(_out, rps_contact(-0.02, 0.56));
    // The fat rim is drawn FIRST and slightly larger, so the meat sits inside it rather than
    // being outlined by it. An outline would read as ink; this reads as a different substance.
    // ⚠️ rps_inset WITH A NEGATIVE DISTANCE, NOT rps_offset_pts. The primitive layer's offset is
    // for OPEN polylines and does not wrap, so on a closed ring it leaves a notch at the seam -
    // which on a blob is at three o'clock, in plain view. rps_inset wraps at both ends and a
    // negative distance grows the ring outward, which is what a rim of fat around an eye of meat
    // actually is.
    rps_append(_out, rps_map_roles(
        rps_raise(rps_inset(_eye, -0.028, rps_out_sign(_eye)), 0.030, 2, "m3"),
        rps_material_map("side")));
    rps_append(_out, rps_raise(_eye, 0.042, 3, "m2"));
    // Grain. Short strokes, many of them - never wider ones.
    rps_append(_out, rps_score(-0.20, RPS_GROUND - 0.26, 0.12, RPS_GROUND - 0.09, 7, "m1", 0.18));
    // The bone: a pale wedge with a marrow pit, standing out of the right of the eye.
    var _bone = rps_round_rect_pts(0.20, RPS_GROUND - 0.20, 0.34, RPS_GROUND - 0.05, 0.035, 3);
    rps_append(_out, rps_map_roles(rps_raise(_bone, 0.030, 2, "m4"), rps_material_map("bone")));
    rps_append(_out, rps_map_roles(rps_pit(0.27, RPS_GROUND - 0.125, 0.035, 10),
                                   rps_material_map("bone")));
    return _out;
}

/// A thick steak seen from above: a domed mass with a seared crust and grill bars across it.
function rps_form_steak(_seed) {
    var _out = [];
    var _pts = rps_blob_pts(0, RPS_GROUND - 0.16, 0.30, 0.155, 30, 0.055, _seed);
    rps_append(_out, rps_contact(0, 0.66));
    rps_append(_out, rps_raise(_pts, 0.050, 3, "m2"));
    // ⚠️ GRILL BARS ARE CHAR, NOT SHADING. They are drawn in the flat `char` role, not in a dark
    // ramp stop: a bar shaded by the lamp would be lit on one side, and a scorch mark is not a
    // raised feature, it is a stain. Drawn in m0 they read as dents.
    rps_append(_out, rps_score(-0.24, RPS_GROUND - 0.25, 0.24, RPS_GROUND - 0.07, 5, "scorch", -0.12));
    // A seam of fat along the top edge.
    //
    // ⛔ IT FOLLOWS THE MEAT'S OWN ELLIPSE, NOT A CIRCLE. Drawn on a circle of radius 0.285 over a
    // blob only 0.155 tall, the seam arced high above the steak and read as a white handle bolted
    // to it - clearly visible on the trajectory sheet. A trim of fat sits ON the edge of the cut,
    // so it has to be sampled from the same ellipse the cut is.
    var _seam = [];
    for (var _i = 0; _i <= 14; _i++) {
        var _sa = 3.35 + (_i / 14) * 2.55;
        array_push(_seam, [cos(_sa) * 0.305, RPS_GROUND - 0.16 + sin(_sa) * 0.163]);
    }
    rps_append(_out, [rps_taper_ribbon(_seam, 0.020, 0.030, "side3")]);
    return _out;
}

/// A tied roasting joint: a barrel of meat with three turns of string biting into it.
function rps_form_joint(_seed) {
    var _out = [];
    var _body = rps_blob_pts(0, RPS_GROUND - 0.20, 0.27, 0.185, 28, 0.045, _seed);
    rps_append(_out, rps_contact(0, 0.62));
    rps_append(_out, rps_raise(_body, 0.055, 3, "m2"));
    // ⭐ THE STRING IS WHAT MAKES THIS READ AS A JOINT RATHER THAN AS A LOAF, and it works because
    // it is INCISED rather than drawn on top: a cord under tension pulls the meat in, so the mark
    // it leaves is a groove with the meat swelling either side of it, not a line lying over it.
    for (var _i = 0; _i < 3; _i++) {
        var _x = -0.15 + _i * 0.15;
        var _c = rps_qbez([_x, RPS_GROUND - 0.375], [_x + 0.012, RPS_GROUND - 0.20],
                          [_x, RPS_GROUND - 0.025], 10);
        rps_append(_out, rps_incise(_c, false, 0.020));
        // The cord itself is drawn in the FLAT `crumb` role, not a ramp. Butcher's twine is a
        // matte pale fibre about a millimetre across; giving it a five-stop ramp would light a
        // lit and a shadowed side onto something too thin to have either.
        array_push(_out, rps_ribbon(_c, 0.007, "crumb"));
    }
    return _out;
}

/// A coiled sausage: one thick strand wound into a spiral, pinched into links.
function rps_form_sausage(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.70));
    // A spiral sampled as one polyline, then given body by a ribbon and a bevel along it.
    var _pts = [];
    var _turns = 2.15;
    for (var _i = 0; _i <= 46; _i++) {
        var _t = _i / 46;
        var _a = _t * RPS_TAU * _turns - 1.2;
        var _r = 0.075 + _t * 0.195;
        array_push(_pts, [cos(_a) * _r, RPS_GROUND - 0.16 + sin(_a) * _r * 0.62]);
    }
    rps_append(_out, [rps_taper_ribbon(_pts, 0.052, 0.062, "m2")]);
    // The lit top of the coil, offset toward the lamp - this is what stops a ribbon reading flat.
    rps_append(_out, [rps_taper_ribbon(rps_move_pts(_pts, -0.010, -0.012), 0.024, 0.030, "m4")]);
    // Link pinches, spaced along the coil.
    for (var _i = 6; _i < 44; _i += 11) {
        rps_append(_out, rps_incise([_pts[_i], _pts[_i + 1]], false, 0.030));
    }
    return _out;
}

/// A poultry drumstick: a plump body tapering to a bared bone with a cap on the end.
function rps_form_drumstick(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(-0.04, 0.56));
    var _body = rps_blob_pts(-0.10, RPS_GROUND - 0.17, 0.195, 0.150, 24, 0.070, _seed);
    rps_append(_out, rps_raise(_body, 0.048, 3, "m2"));
    // Crisped skin: short arcs on the lit shoulder, count-carried tone.
    for (var _i = 0; _i < 6; _i++) {
        var _a0 = 3.5 + _i * 0.22;
        array_push(_out, rps_arc(-0.10, RPS_GROUND - 0.17, 0.14 + (_i % 2) * 0.025,
                                 _a0, _a0 + 0.30, 0.007, "m4"));
    }
    var _bone = rps_round_rect_pts(0.06, RPS_GROUND - 0.135, 0.26, RPS_GROUND - 0.085, 0.024, 3);
    rps_append(_out, rps_map_roles(rps_raise(_bone, 0.020, 2, "m4"), rps_material_map("bone")));
    rps_append(_out, rps_map_roles(rps_boss(0.275, RPS_GROUND - 0.110, 0.048, 12),
                                   rps_material_map("bone")));
    return _out;
}

/// A whole small bird, trussed: breast up, legs crossed, wings tucked.
function rps_form_bird(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.72));
    var _breast = rps_blob_pts(0, RPS_GROUND - 0.21, 0.255, 0.190, 28, 0.050, _seed);
    rps_append(_out, rps_raise(_breast, 0.062, 3, "m2"));
    // The keel line down the middle: a ridge, so the bird has two sides.
    rps_append(_out, rps_ridge(rps_qbez([-0.01, RPS_GROUND - 0.395], [0.01, RPS_GROUND - 0.24],
                                        [0.00, RPS_GROUND - 0.075], 10), false, 0.018));
    // ⚠️ THE BREAST HIGHLIGHT IS WHAT SAYS "ROASTED". Without it the mass reads as a helmet: a
    // roast bird's crown catches the most heat and browns hardest, and that gradient across the
    // top is most of what a viewer recognises. Count-carried, on the lamp side.
    for (var _i = 0; _i < 8; _i++) {
        var _a = 3.55 + _i * 0.28;
        array_push(_out, rps_arc(0, RPS_GROUND - 0.21, 0.175 + (_i % 2) * 0.030,
                                 _a, _a + 0.22, 0.008, "m4"));
    }

    // Crossed legs at the front. Thicker, longer and lower than the first version, which drew
    // them so short they read as two nubs rather than as legs.
    for (var _i = 0; _i < 2; _i++) {
        var _sx = (_i == 0) ? -1 : 1;
        var _leg = rps_qbez([_sx * 0.05, RPS_GROUND - 0.150], [_sx * 0.19, RPS_GROUND - 0.105],
                            [_sx * 0.235, RPS_GROUND - 0.020], 10);
        rps_append(_out, [rps_taper_ribbon(_leg, 0.048, 0.020, "m3")]);
        // The lit top of each leg, so it is a limb rather than a stripe.
        rps_append(_out, [rps_taper_ribbon(rps_move_pts(_leg, 0, -0.014), 0.020, 0.008, "m4")]);
        rps_append(_out, rps_map_roles(rps_boss(_sx * 0.240, RPS_GROUND - 0.016, 0.032, 10),
                                       rps_material_map("bone")));
    }
    // Wing shoulders, as shallow raised lobes either side.
    for (var _i = 0; _i < 2; _i++) {
        var _sx = (_i == 0) ? -1 : 1;
        rps_append(_out, rps_raise(rps_ellipse_pts(_sx * 0.185, RPS_GROUND - 0.235, 0.070,
                                                   0.105, 14), 0.024, 2, "m1"));
    }
    return _out;
}

/// A whole fish, head on: body, tail, gill line, eye and a run of scales.
function rps_form_fish(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.80));
    // The body is a lens rather than a blob - a fish is the one thing here with a hard silhouette.
    var _body = [];
    for (var _i = 0; _i <= 30; _i++) {
        var _t = _i / 30;
        var _x = lerp(-0.34, 0.24, _t);
        var _k = sin(_t * pi);
        array_push(_body, [_x, RPS_GROUND - 0.13 - _k * 0.115]);
    }
    for (var _i = 30; _i >= 0; _i--) {
        var _t2 = _i / 30;
        var _x2 = lerp(-0.34, 0.24, _t2);
        var _k2 = sin(_t2 * pi);
        array_push(_body, [_x2, RPS_GROUND - 0.13 + _k2 * 0.100]);
    }
    rps_append(_out, rps_raise(_body, 0.045, 3, "m2"));
    // Tail: a notched triangle off the right.
    rps_append(_out, rps_raise([[0.22, RPS_GROUND - 0.13], [0.40, RPS_GROUND - 0.235],
                                [0.345, RPS_GROUND - 0.13], [0.40, RPS_GROUND - 0.025]],
                               0.022, 2, "m1"));
    // Gill plate, incised so it has depth.
    rps_append(_out, rps_incise(rps_arc_pts(-0.245, RPS_GROUND - 0.13, 0.085, 4.4, 8.0, 10),
                                false, 0.016));
    rps_append(_out, rps_map_roles(rps_boss(-0.275, RPS_GROUND - 0.165, 0.030, 12),
                                   rps_material_map("bone")));
    // Scales: many short arcs, count-carried.
    for (var _r = 0; _r < 3; _r++) {
        for (var _c = 0; _c < 7; _c++) {
            var _sx = -0.13 + _c * 0.048;
            var _sy = RPS_GROUND - 0.175 + _r * 0.042;
            array_push(_out, rps_arc(_sx, _sy, 0.030, 3.5, 5.9, 0.006, "m4"));
        }
    }
    return _out;
}

/// A cooked fillet, flaking apart along its muscle seams.
function rps_form_fillet(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.62));
    var _pts = rps_blob_pts(0, RPS_GROUND - 0.145, 0.275, 0.130, 24, 0.060, _seed);
    rps_append(_out, rps_raise(_pts, 0.040, 3, "m2"));
    // ⭐ THE FLAKES ARE THE FORM. A fillet without seams is a slab; the seams are what say "this is
    // cooked". Each is an incised curve, and they fan rather than run parallel because muscle
    // blocks in a fillet are wedge-shaped.
    for (var _i = 0; _i < 5; _i++) {
        var _t = (_i + 0.5) / 5;
        var _x = lerp(-0.21, 0.21, _t);
        var _c = rps_qbez([_x - 0.02, RPS_GROUND - 0.255], [_x + 0.03, RPS_GROUND - 0.145],
                          [_x - 0.01, RPS_GROUND - 0.035], 10);
        rps_append(_out, rps_incise(_c, false, 0.017));
    }
    // A dark crisped skin strip along the top edge.
    rps_append(_out, [rps_taper_ribbon(rps_arc_pts(0, RPS_GROUND - 0.145, 0.255, 3.45, 5.85, 14),
                                       0.018, 0.026, "m0")]);
    return _out;
}

/// A curled prawn: the tail fan, the segmented body, the curl.
function rps_form_prawn(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.52));
    var _spine = rps_arc_pts(0.02, RPS_GROUND - 0.155, 0.165, 2.5, 6.1, 18);
    rps_append(_out, [rps_taper_ribbon(_spine, 0.062, 0.022, "m2")]);
    // Segments: incised across the curl. Seven, because a prawn has six visible and one is hidden
    // by the tail - counting them is the kind of thing that makes a form read as observed.
    for (var _i = 1; _i < 8; _i++) {
        var _p = _spine[_i * 2];
        var _q = [_p[0] - (_p[0] - 0.02) * 0.35, _p[1] - (_p[1] - (RPS_GROUND - 0.155)) * 0.35];
        rps_append(_out, rps_incise([_p, _q], false, 0.014));
    }
    // Tail fan.
    var _tip = _spine[array_length(_spine) - 1];
    rps_append(_out, rps_raise([[_tip[0], _tip[1]], [_tip[0] + 0.085, _tip[1] - 0.075],
                                [_tip[0] + 0.105, _tip[1]], [_tip[0] + 0.080, _tip[1] + 0.070]],
                               0.016, 2, "m3"));
    return _out;
}

/// A seared scallop: a low cylinder with a caramelised face and a crosshatch of pan marks.
function rps_form_scallop(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.50));
    var _top = rps_blob_pts(0, RPS_GROUND - 0.135, 0.175, 0.145, 22, 0.030, _seed);
    // The SIDE of the cylinder first, then the face on top of it: a scallop is tall enough that
    // its wall is a visible part of the form rather than an edge.
    rps_append(_out, rps_raise(rps_move_pts(_top, 0, 0.055), 0.030, 2, "m1"));
    rps_append(_out, rps_raise(_top, 0.038, 3, "m3"));
    rps_append(_out, rps_score(-0.13, RPS_GROUND - 0.20, 0.13, RPS_GROUND - 0.07, 4, "scorch", 0.30));
    rps_append(_out, rps_score(-0.13, RPS_GROUND - 0.20, 0.13, RPS_GROUND - 0.07, 4, "scorch", -0.30));
    return _out;
}
