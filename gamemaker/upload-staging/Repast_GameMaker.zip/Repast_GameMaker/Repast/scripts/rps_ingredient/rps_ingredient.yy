{
  "$GMScript": "v1",
  "%Name": "rps_ingredient",
  "name": "rps_ingredient",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}