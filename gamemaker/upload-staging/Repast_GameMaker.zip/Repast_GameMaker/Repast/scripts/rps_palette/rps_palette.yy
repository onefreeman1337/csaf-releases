{
  "$GMScript": "v1",
  "%Name": "rps_palette",
  "name": "rps_palette",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}