{
  "$GMScript": "v1",
  "%Name": "rps_recipe",
  "name": "rps_recipe",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}